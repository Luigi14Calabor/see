<?php  if ( ! defined('BASEPATH')) exit('No direct script access allowed'); ?>

DEBUG - 2011-05-06 00:28:20 --> Config Class Initialized
DEBUG - 2011-05-06 00:28:20 --> Hooks Class Initialized
DEBUG - 2011-05-06 00:28:20 --> Utf8 Class Initialized
DEBUG - 2011-05-06 00:28:20 --> UTF-8 Support Enabled
DEBUG - 2011-05-06 00:28:20 --> URI Class Initialized
DEBUG - 2011-05-06 00:28:20 --> Router Class Initialized
DEBUG - 2011-05-06 00:28:20 --> Output Class Initialized
DEBUG - 2011-05-06 00:28:20 --> Input Class Initialized
DEBUG - 2011-05-06 00:28:20 --> Global POST and COOKIE data sanitized
DEBUG - 2011-05-06 00:28:20 --> Language Class Initialized
DEBUG - 2011-05-06 00:28:20 --> Loader Class Initialized
DEBUG - 2011-05-06 00:28:20 --> Controller Class Initialized
ERROR - 2011-05-06 00:28:20 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-05-06 00:28:20 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-05-06 00:28:20 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-05-06 00:28:20 --> Model Class Initialized
DEBUG - 2011-05-06 00:28:20 --> Model Class Initialized
DEBUG - 2011-05-06 00:28:20 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-05-06 00:28:20 --> Database Driver Class Initialized
DEBUG - 2011-05-06 00:28:20 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-05-06 00:28:20 --> Helper loaded: url_helper
DEBUG - 2011-05-06 00:28:20 --> File loaded: application/views/common/header.php
DEBUG - 2011-05-06 00:28:20 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-05-06 00:28:20 --> File loaded: application/views/common/footer.php
DEBUG - 2011-05-06 00:28:20 --> File loaded: application/views/layout/main.php
DEBUG - 2011-05-06 00:28:20 --> Final output sent to browser
DEBUG - 2011-05-06 00:28:20 --> Total execution time: 0.2312
DEBUG - 2011-05-06 00:28:24 --> Config Class Initialized
DEBUG - 2011-05-06 00:28:24 --> Hooks Class Initialized
DEBUG - 2011-05-06 00:28:24 --> Utf8 Class Initialized
DEBUG - 2011-05-06 00:28:24 --> UTF-8 Support Enabled
DEBUG - 2011-05-06 00:28:24 --> URI Class Initialized
DEBUG - 2011-05-06 00:28:24 --> Router Class Initialized
DEBUG - 2011-05-06 00:28:24 --> Output Class Initialized
DEBUG - 2011-05-06 00:28:24 --> Input Class Initialized
DEBUG - 2011-05-06 00:28:24 --> Global POST and COOKIE data sanitized
DEBUG - 2011-05-06 00:28:24 --> Language Class Initialized
DEBUG - 2011-05-06 00:28:24 --> Loader Class Initialized
DEBUG - 2011-05-06 00:28:24 --> Controller Class Initialized
DEBUG - 2011-05-06 00:28:24 --> Model Class Initialized
DEBUG - 2011-05-06 00:28:24 --> Model Class Initialized
DEBUG - 2011-05-06 00:28:24 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-05-06 00:28:24 --> Database Driver Class Initialized
DEBUG - 2011-05-06 00:28:25 --> Config Class Initialized
DEBUG - 2011-05-06 00:28:25 --> Hooks Class Initialized
DEBUG - 2011-05-06 00:28:25 --> Utf8 Class Initialized
DEBUG - 2011-05-06 00:28:25 --> UTF-8 Support Enabled
DEBUG - 2011-05-06 00:28:25 --> URI Class Initialized
DEBUG - 2011-05-06 00:28:25 --> Router Class Initialized
DEBUG - 2011-05-06 00:28:25 --> Output Class Initialized
DEBUG - 2011-05-06 00:28:25 --> Input Class Initialized
DEBUG - 2011-05-06 00:28:25 --> Global POST and COOKIE data sanitized
DEBUG - 2011-05-06 00:28:25 --> Language Class Initialized
DEBUG - 2011-05-06 00:28:25 --> Loader Class Initialized
DEBUG - 2011-05-06 00:28:25 --> Controller Class Initialized
ERROR - 2011-05-06 00:28:25 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-05-06 00:28:25 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-05-06 00:28:25 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-05-06 00:28:25 --> Model Class Initialized
DEBUG - 2011-05-06 00:28:25 --> Model Class Initialized
DEBUG - 2011-05-06 00:28:25 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-05-06 00:28:25 --> Database Driver Class Initialized
DEBUG - 2011-05-06 00:28:25 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-05-06 00:28:25 --> Helper loaded: url_helper
DEBUG - 2011-05-06 00:28:25 --> File loaded: application/views/common/header.php
DEBUG - 2011-05-06 00:28:25 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-05-06 00:28:25 --> File loaded: application/views/common/footer.php
DEBUG - 2011-05-06 00:28:25 --> File loaded: application/views/layout/main.php
DEBUG - 2011-05-06 00:28:25 --> Final output sent to browser
DEBUG - 2011-05-06 00:28:25 --> Total execution time: 0.0286
DEBUG - 2011-05-06 00:28:25 --> Final output sent to browser
DEBUG - 2011-05-06 00:28:25 --> Total execution time: 0.6140
DEBUG - 2011-05-06 02:52:22 --> Config Class Initialized
DEBUG - 2011-05-06 02:52:22 --> Hooks Class Initialized
DEBUG - 2011-05-06 02:52:22 --> Utf8 Class Initialized
DEBUG - 2011-05-06 02:52:22 --> UTF-8 Support Enabled
DEBUG - 2011-05-06 02:52:22 --> URI Class Initialized
DEBUG - 2011-05-06 02:52:22 --> Router Class Initialized
DEBUG - 2011-05-06 02:52:22 --> No URI present. Default controller set.
DEBUG - 2011-05-06 02:52:22 --> Output Class Initialized
DEBUG - 2011-05-06 02:52:22 --> Input Class Initialized
DEBUG - 2011-05-06 02:52:22 --> Global POST and COOKIE data sanitized
DEBUG - 2011-05-06 02:52:22 --> Language Class Initialized
DEBUG - 2011-05-06 02:52:22 --> Loader Class Initialized
DEBUG - 2011-05-06 02:52:22 --> Controller Class Initialized
DEBUG - 2011-05-06 02:52:22 --> File loaded: application/views/splash/main.php
DEBUG - 2011-05-06 02:52:22 --> Helper loaded: url_helper
DEBUG - 2011-05-06 02:52:22 --> File loaded: application/views/common/header.php
DEBUG - 2011-05-06 02:52:22 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-05-06 02:52:22 --> File loaded: application/views/common/footer.php
DEBUG - 2011-05-06 02:52:22 --> File loaded: application/views/layout/main.php
DEBUG - 2011-05-06 02:52:22 --> Final output sent to browser
DEBUG - 2011-05-06 02:52:22 --> Total execution time: 0.3288
DEBUG - 2011-05-06 04:15:38 --> Config Class Initialized
DEBUG - 2011-05-06 04:15:38 --> Hooks Class Initialized
DEBUG - 2011-05-06 04:15:38 --> Utf8 Class Initialized
DEBUG - 2011-05-06 04:15:38 --> UTF-8 Support Enabled
DEBUG - 2011-05-06 04:15:38 --> URI Class Initialized
DEBUG - 2011-05-06 04:15:38 --> Router Class Initialized
ERROR - 2011-05-06 04:15:38 --> 404 Page Not Found --> robots.txt
DEBUG - 2011-05-06 04:15:39 --> Config Class Initialized
DEBUG - 2011-05-06 04:15:39 --> Hooks Class Initialized
DEBUG - 2011-05-06 04:15:39 --> Utf8 Class Initialized
DEBUG - 2011-05-06 04:15:39 --> UTF-8 Support Enabled
DEBUG - 2011-05-06 04:15:39 --> URI Class Initialized
DEBUG - 2011-05-06 04:15:39 --> Router Class Initialized
DEBUG - 2011-05-06 04:15:39 --> Output Class Initialized
DEBUG - 2011-05-06 04:15:39 --> Input Class Initialized
DEBUG - 2011-05-06 04:15:39 --> Global POST and COOKIE data sanitized
DEBUG - 2011-05-06 04:15:39 --> Language Class Initialized
DEBUG - 2011-05-06 04:15:39 --> Loader Class Initialized
DEBUG - 2011-05-06 04:15:39 --> Controller Class Initialized
DEBUG - 2011-05-06 04:15:39 --> Model Class Initialized
DEBUG - 2011-05-06 04:15:39 --> Model Class Initialized
DEBUG - 2011-05-06 04:15:39 --> Model Class Initialized
DEBUG - 2011-05-06 04:15:40 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-05-06 04:15:40 --> Database Driver Class Initialized
DEBUG - 2011-05-06 04:15:46 --> File loaded: application/views/table/main.php
DEBUG - 2011-05-06 04:15:46 --> Helper loaded: url_helper
DEBUG - 2011-05-06 04:15:46 --> File loaded: application/views/common/header.php
DEBUG - 2011-05-06 04:15:46 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-05-06 04:15:46 --> File loaded: application/views/common/footer.php
DEBUG - 2011-05-06 04:15:46 --> File loaded: application/views/layout/main.php
DEBUG - 2011-05-06 04:15:46 --> Final output sent to browser
DEBUG - 2011-05-06 04:15:46 --> Total execution time: 6.6837
DEBUG - 2011-05-06 04:15:47 --> Config Class Initialized
DEBUG - 2011-05-06 04:15:47 --> Hooks Class Initialized
DEBUG - 2011-05-06 04:15:47 --> Utf8 Class Initialized
DEBUG - 2011-05-06 04:15:47 --> UTF-8 Support Enabled
DEBUG - 2011-05-06 04:15:47 --> URI Class Initialized
DEBUG - 2011-05-06 04:15:47 --> Router Class Initialized
DEBUG - 2011-05-06 04:15:47 --> Output Class Initialized
DEBUG - 2011-05-06 04:15:47 --> Input Class Initialized
DEBUG - 2011-05-06 04:15:47 --> Global POST and COOKIE data sanitized
DEBUG - 2011-05-06 04:15:47 --> Language Class Initialized
DEBUG - 2011-05-06 04:15:47 --> Loader Class Initialized
DEBUG - 2011-05-06 04:15:47 --> Controller Class Initialized
ERROR - 2011-05-06 04:15:47 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-05-06 04:15:47 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-05-06 04:15:47 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-05-06 04:15:47 --> Model Class Initialized
DEBUG - 2011-05-06 04:15:47 --> Model Class Initialized
DEBUG - 2011-05-06 04:15:47 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-05-06 04:15:47 --> Database Driver Class Initialized
DEBUG - 2011-05-06 04:15:47 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-05-06 04:15:47 --> Helper loaded: url_helper
DEBUG - 2011-05-06 04:15:47 --> File loaded: application/views/common/header.php
DEBUG - 2011-05-06 04:15:47 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-05-06 04:15:47 --> File loaded: application/views/common/footer.php
DEBUG - 2011-05-06 04:15:47 --> File loaded: application/views/layout/main.php
DEBUG - 2011-05-06 04:15:47 --> Final output sent to browser
DEBUG - 2011-05-06 04:15:47 --> Total execution time: 0.1366
DEBUG - 2011-05-06 04:19:27 --> Config Class Initialized
DEBUG - 2011-05-06 04:19:27 --> Hooks Class Initialized
DEBUG - 2011-05-06 04:19:27 --> Utf8 Class Initialized
DEBUG - 2011-05-06 04:19:27 --> UTF-8 Support Enabled
DEBUG - 2011-05-06 04:19:27 --> URI Class Initialized
DEBUG - 2011-05-06 04:19:27 --> Router Class Initialized
DEBUG - 2011-05-06 04:19:27 --> Output Class Initialized
DEBUG - 2011-05-06 04:19:27 --> Input Class Initialized
DEBUG - 2011-05-06 04:19:27 --> Global POST and COOKIE data sanitized
DEBUG - 2011-05-06 04:19:27 --> Language Class Initialized
DEBUG - 2011-05-06 04:19:27 --> Loader Class Initialized
DEBUG - 2011-05-06 04:19:27 --> Controller Class Initialized
DEBUG - 2011-05-06 04:19:27 --> Model Class Initialized
DEBUG - 2011-05-06 04:19:27 --> Model Class Initialized
DEBUG - 2011-05-06 04:19:27 --> Model Class Initialized
DEBUG - 2011-05-06 04:19:27 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-05-06 04:19:27 --> Database Driver Class Initialized
DEBUG - 2011-05-06 04:19:27 --> File loaded: application/views/table/main.php
DEBUG - 2011-05-06 04:19:27 --> Helper loaded: url_helper
DEBUG - 2011-05-06 04:19:27 --> File loaded: application/views/common/header.php
DEBUG - 2011-05-06 04:19:27 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-05-06 04:19:27 --> File loaded: application/views/common/footer.php
DEBUG - 2011-05-06 04:19:27 --> File loaded: application/views/layout/main.php
DEBUG - 2011-05-06 04:19:27 --> Final output sent to browser
DEBUG - 2011-05-06 04:19:27 --> Total execution time: 0.1003
DEBUG - 2011-05-06 04:19:29 --> Config Class Initialized
DEBUG - 2011-05-06 04:19:29 --> Hooks Class Initialized
DEBUG - 2011-05-06 04:19:29 --> Utf8 Class Initialized
DEBUG - 2011-05-06 04:19:29 --> UTF-8 Support Enabled
DEBUG - 2011-05-06 04:19:29 --> URI Class Initialized
DEBUG - 2011-05-06 04:19:29 --> Router Class Initialized
ERROR - 2011-05-06 04:19:29 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-05-06 04:19:40 --> Config Class Initialized
DEBUG - 2011-05-06 04:19:40 --> Hooks Class Initialized
DEBUG - 2011-05-06 04:19:40 --> Utf8 Class Initialized
DEBUG - 2011-05-06 04:19:40 --> UTF-8 Support Enabled
DEBUG - 2011-05-06 04:19:40 --> URI Class Initialized
DEBUG - 2011-05-06 04:19:40 --> Router Class Initialized
ERROR - 2011-05-06 04:19:40 --> 404 Page Not Found --> robots.txt
DEBUG - 2011-05-06 04:19:40 --> Config Class Initialized
DEBUG - 2011-05-06 04:19:40 --> Hooks Class Initialized
DEBUG - 2011-05-06 04:19:40 --> Utf8 Class Initialized
DEBUG - 2011-05-06 04:19:40 --> UTF-8 Support Enabled
DEBUG - 2011-05-06 04:19:40 --> URI Class Initialized
DEBUG - 2011-05-06 04:19:40 --> Router Class Initialized
DEBUG - 2011-05-06 04:19:40 --> Output Class Initialized
DEBUG - 2011-05-06 04:19:40 --> Input Class Initialized
DEBUG - 2011-05-06 04:19:40 --> Global POST and COOKIE data sanitized
DEBUG - 2011-05-06 04:19:40 --> Language Class Initialized
DEBUG - 2011-05-06 04:19:40 --> Loader Class Initialized
DEBUG - 2011-05-06 04:19:40 --> Controller Class Initialized
DEBUG - 2011-05-06 04:19:40 --> Model Class Initialized
DEBUG - 2011-05-06 04:19:40 --> Model Class Initialized
DEBUG - 2011-05-06 04:19:40 --> Model Class Initialized
DEBUG - 2011-05-06 04:19:40 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-05-06 04:19:40 --> Database Driver Class Initialized
DEBUG - 2011-05-06 04:19:40 --> File loaded: application/views/table/main.php
DEBUG - 2011-05-06 04:19:40 --> Helper loaded: url_helper
DEBUG - 2011-05-06 04:19:40 --> File loaded: application/views/common/header.php
DEBUG - 2011-05-06 04:19:40 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-05-06 04:19:40 --> File loaded: application/views/common/footer.php
DEBUG - 2011-05-06 04:19:40 --> File loaded: application/views/layout/main.php
DEBUG - 2011-05-06 04:19:40 --> Final output sent to browser
DEBUG - 2011-05-06 04:19:40 --> Total execution time: 0.0676
DEBUG - 2011-05-06 04:19:46 --> Config Class Initialized
DEBUG - 2011-05-06 04:19:46 --> Hooks Class Initialized
DEBUG - 2011-05-06 04:19:46 --> Utf8 Class Initialized
DEBUG - 2011-05-06 04:19:46 --> UTF-8 Support Enabled
DEBUG - 2011-05-06 04:19:46 --> URI Class Initialized
DEBUG - 2011-05-06 04:19:46 --> Router Class Initialized
DEBUG - 2011-05-06 04:19:46 --> Output Class Initialized
DEBUG - 2011-05-06 04:19:46 --> Input Class Initialized
DEBUG - 2011-05-06 04:19:46 --> Global POST and COOKIE data sanitized
DEBUG - 2011-05-06 04:19:46 --> Language Class Initialized
DEBUG - 2011-05-06 04:19:46 --> Loader Class Initialized
DEBUG - 2011-05-06 04:19:46 --> Controller Class Initialized
ERROR - 2011-05-06 04:19:46 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-05-06 04:19:46 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-05-06 04:19:46 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-05-06 04:19:46 --> Model Class Initialized
DEBUG - 2011-05-06 04:19:46 --> Model Class Initialized
DEBUG - 2011-05-06 04:19:46 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-05-06 04:19:46 --> Database Driver Class Initialized
DEBUG - 2011-05-06 04:19:46 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-05-06 04:19:46 --> Helper loaded: url_helper
DEBUG - 2011-05-06 04:19:46 --> File loaded: application/views/common/header.php
DEBUG - 2011-05-06 04:19:46 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-05-06 04:19:46 --> File loaded: application/views/common/footer.php
DEBUG - 2011-05-06 04:19:46 --> File loaded: application/views/layout/main.php
DEBUG - 2011-05-06 04:19:46 --> Final output sent to browser
DEBUG - 2011-05-06 04:19:46 --> Total execution time: 0.0401
DEBUG - 2011-05-06 04:19:46 --> Config Class Initialized
DEBUG - 2011-05-06 04:19:46 --> Hooks Class Initialized
DEBUG - 2011-05-06 04:19:46 --> Utf8 Class Initialized
DEBUG - 2011-05-06 04:19:46 --> UTF-8 Support Enabled
DEBUG - 2011-05-06 04:19:46 --> URI Class Initialized
DEBUG - 2011-05-06 04:19:46 --> Router Class Initialized
DEBUG - 2011-05-06 04:19:47 --> Output Class Initialized
DEBUG - 2011-05-06 04:19:47 --> Input Class Initialized
DEBUG - 2011-05-06 04:19:47 --> Global POST and COOKIE data sanitized
DEBUG - 2011-05-06 04:19:47 --> Language Class Initialized
DEBUG - 2011-05-06 04:19:47 --> Loader Class Initialized
DEBUG - 2011-05-06 04:19:47 --> Controller Class Initialized
DEBUG - 2011-05-06 04:19:47 --> Model Class Initialized
DEBUG - 2011-05-06 04:19:47 --> Model Class Initialized
DEBUG - 2011-05-06 04:19:47 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-05-06 04:19:47 --> Database Driver Class Initialized
DEBUG - 2011-05-06 04:19:48 --> Final output sent to browser
DEBUG - 2011-05-06 04:19:48 --> Total execution time: 1.0438
DEBUG - 2011-05-06 04:19:49 --> Config Class Initialized
DEBUG - 2011-05-06 04:19:49 --> Hooks Class Initialized
DEBUG - 2011-05-06 04:19:49 --> Utf8 Class Initialized
DEBUG - 2011-05-06 04:19:49 --> UTF-8 Support Enabled
DEBUG - 2011-05-06 04:19:49 --> URI Class Initialized
DEBUG - 2011-05-06 04:19:49 --> Router Class Initialized
ERROR - 2011-05-06 04:19:49 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-05-06 04:19:52 --> Config Class Initialized
DEBUG - 2011-05-06 04:19:52 --> Hooks Class Initialized
DEBUG - 2011-05-06 04:19:52 --> Utf8 Class Initialized
DEBUG - 2011-05-06 04:19:52 --> UTF-8 Support Enabled
DEBUG - 2011-05-06 04:19:52 --> URI Class Initialized
DEBUG - 2011-05-06 04:19:52 --> Router Class Initialized
DEBUG - 2011-05-06 04:19:52 --> Output Class Initialized
DEBUG - 2011-05-06 04:19:52 --> Input Class Initialized
DEBUG - 2011-05-06 04:19:52 --> Global POST and COOKIE data sanitized
DEBUG - 2011-05-06 04:19:52 --> Language Class Initialized
DEBUG - 2011-05-06 04:19:52 --> Loader Class Initialized
DEBUG - 2011-05-06 04:19:52 --> Controller Class Initialized
ERROR - 2011-05-06 04:19:52 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-05-06 04:19:52 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-05-06 04:19:52 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-05-06 04:19:52 --> Model Class Initialized
DEBUG - 2011-05-06 04:19:52 --> Model Class Initialized
DEBUG - 2011-05-06 04:19:52 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-05-06 04:19:52 --> Database Driver Class Initialized
DEBUG - 2011-05-06 04:19:52 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-05-06 04:19:52 --> Helper loaded: url_helper
DEBUG - 2011-05-06 04:19:52 --> File loaded: application/views/common/header.php
DEBUG - 2011-05-06 04:19:52 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-05-06 04:19:52 --> File loaded: application/views/common/footer.php
DEBUG - 2011-05-06 04:19:52 --> File loaded: application/views/layout/main.php
DEBUG - 2011-05-06 04:19:52 --> Final output sent to browser
DEBUG - 2011-05-06 04:19:52 --> Total execution time: 0.0288
DEBUG - 2011-05-06 04:23:35 --> Config Class Initialized
DEBUG - 2011-05-06 04:23:35 --> Hooks Class Initialized
DEBUG - 2011-05-06 04:23:35 --> Utf8 Class Initialized
DEBUG - 2011-05-06 04:23:35 --> UTF-8 Support Enabled
DEBUG - 2011-05-06 04:23:35 --> URI Class Initialized
DEBUG - 2011-05-06 04:23:35 --> Router Class Initialized
DEBUG - 2011-05-06 04:23:35 --> Output Class Initialized
DEBUG - 2011-05-06 04:23:35 --> Input Class Initialized
DEBUG - 2011-05-06 04:23:35 --> Global POST and COOKIE data sanitized
DEBUG - 2011-05-06 04:23:35 --> Language Class Initialized
DEBUG - 2011-05-06 04:23:35 --> Loader Class Initialized
DEBUG - 2011-05-06 04:23:35 --> Controller Class Initialized
ERROR - 2011-05-06 04:23:35 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-05-06 04:23:35 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-05-06 04:23:35 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-05-06 04:23:35 --> Model Class Initialized
DEBUG - 2011-05-06 04:23:35 --> Model Class Initialized
DEBUG - 2011-05-06 04:23:35 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-05-06 04:23:35 --> Database Driver Class Initialized
DEBUG - 2011-05-06 04:23:35 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-05-06 04:23:35 --> Helper loaded: url_helper
DEBUG - 2011-05-06 04:23:35 --> File loaded: application/views/common/header.php
DEBUG - 2011-05-06 04:23:35 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-05-06 04:23:35 --> File loaded: application/views/common/footer.php
DEBUG - 2011-05-06 04:23:35 --> File loaded: application/views/layout/main.php
DEBUG - 2011-05-06 04:23:35 --> Final output sent to browser
DEBUG - 2011-05-06 04:23:35 --> Total execution time: 0.1342
DEBUG - 2011-05-06 04:23:41 --> Config Class Initialized
DEBUG - 2011-05-06 04:23:41 --> Hooks Class Initialized
DEBUG - 2011-05-06 04:23:41 --> Utf8 Class Initialized
DEBUG - 2011-05-06 04:23:41 --> UTF-8 Support Enabled
DEBUG - 2011-05-06 04:23:41 --> URI Class Initialized
DEBUG - 2011-05-06 04:23:41 --> Router Class Initialized
DEBUG - 2011-05-06 04:23:41 --> Output Class Initialized
DEBUG - 2011-05-06 04:23:41 --> Input Class Initialized
DEBUG - 2011-05-06 04:23:41 --> Global POST and COOKIE data sanitized
DEBUG - 2011-05-06 04:23:41 --> Language Class Initialized
DEBUG - 2011-05-06 04:23:41 --> Loader Class Initialized
DEBUG - 2011-05-06 04:23:41 --> Controller Class Initialized
DEBUG - 2011-05-06 04:23:41 --> Model Class Initialized
DEBUG - 2011-05-06 04:23:41 --> Model Class Initialized
DEBUG - 2011-05-06 04:23:41 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-05-06 04:23:41 --> Database Driver Class Initialized
DEBUG - 2011-05-06 04:23:44 --> Final output sent to browser
DEBUG - 2011-05-06 04:23:44 --> Total execution time: 3.2325
DEBUG - 2011-05-06 04:23:51 --> Config Class Initialized
DEBUG - 2011-05-06 04:23:51 --> Hooks Class Initialized
DEBUG - 2011-05-06 04:23:51 --> Utf8 Class Initialized
DEBUG - 2011-05-06 04:23:51 --> UTF-8 Support Enabled
DEBUG - 2011-05-06 04:23:51 --> URI Class Initialized
DEBUG - 2011-05-06 04:23:51 --> Router Class Initialized
ERROR - 2011-05-06 04:23:51 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-05-06 04:29:30 --> Config Class Initialized
DEBUG - 2011-05-06 04:29:30 --> Hooks Class Initialized
DEBUG - 2011-05-06 04:29:30 --> Utf8 Class Initialized
DEBUG - 2011-05-06 04:29:30 --> UTF-8 Support Enabled
DEBUG - 2011-05-06 04:29:30 --> URI Class Initialized
DEBUG - 2011-05-06 04:29:30 --> Router Class Initialized
DEBUG - 2011-05-06 04:29:30 --> Output Class Initialized
DEBUG - 2011-05-06 04:29:30 --> Input Class Initialized
DEBUG - 2011-05-06 04:29:30 --> Global POST and COOKIE data sanitized
DEBUG - 2011-05-06 04:29:30 --> Language Class Initialized
DEBUG - 2011-05-06 04:29:30 --> Loader Class Initialized
DEBUG - 2011-05-06 04:29:30 --> Controller Class Initialized
DEBUG - 2011-05-06 04:29:30 --> Model Class Initialized
DEBUG - 2011-05-06 04:29:30 --> Model Class Initialized
DEBUG - 2011-05-06 04:29:30 --> Model Class Initialized
DEBUG - 2011-05-06 04:29:30 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-05-06 04:29:30 --> Database Driver Class Initialized
DEBUG - 2011-05-06 04:29:31 --> File loaded: application/views/table/main.php
DEBUG - 2011-05-06 04:29:31 --> Helper loaded: url_helper
DEBUG - 2011-05-06 04:29:31 --> File loaded: application/views/common/header.php
DEBUG - 2011-05-06 04:29:31 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-05-06 04:29:31 --> File loaded: application/views/common/footer.php
DEBUG - 2011-05-06 04:29:31 --> File loaded: application/views/layout/main.php
DEBUG - 2011-05-06 04:29:31 --> Final output sent to browser
DEBUG - 2011-05-06 04:29:31 --> Total execution time: 0.1841
DEBUG - 2011-05-06 04:29:45 --> Config Class Initialized
DEBUG - 2011-05-06 04:29:45 --> Hooks Class Initialized
DEBUG - 2011-05-06 04:29:45 --> Utf8 Class Initialized
DEBUG - 2011-05-06 04:29:45 --> UTF-8 Support Enabled
DEBUG - 2011-05-06 04:29:45 --> URI Class Initialized
DEBUG - 2011-05-06 04:29:45 --> Router Class Initialized
DEBUG - 2011-05-06 04:29:45 --> Output Class Initialized
DEBUG - 2011-05-06 04:29:45 --> Input Class Initialized
DEBUG - 2011-05-06 04:29:45 --> Global POST and COOKIE data sanitized
DEBUG - 2011-05-06 04:29:45 --> Language Class Initialized
DEBUG - 2011-05-06 04:29:45 --> Loader Class Initialized
DEBUG - 2011-05-06 04:29:45 --> Controller Class Initialized
ERROR - 2011-05-06 04:29:45 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-05-06 04:29:45 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-05-06 04:29:45 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-05-06 04:29:45 --> Model Class Initialized
DEBUG - 2011-05-06 04:29:45 --> Model Class Initialized
DEBUG - 2011-05-06 04:29:45 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-05-06 04:29:45 --> Database Driver Class Initialized
DEBUG - 2011-05-06 04:29:45 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-05-06 04:29:45 --> Helper loaded: url_helper
DEBUG - 2011-05-06 04:29:45 --> File loaded: application/views/common/header.php
DEBUG - 2011-05-06 04:29:45 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-05-06 04:29:45 --> File loaded: application/views/common/footer.php
DEBUG - 2011-05-06 04:29:45 --> File loaded: application/views/layout/main.php
DEBUG - 2011-05-06 04:29:45 --> Final output sent to browser
DEBUG - 2011-05-06 04:29:45 --> Total execution time: 0.2954
DEBUG - 2011-05-06 04:40:07 --> Config Class Initialized
DEBUG - 2011-05-06 04:40:07 --> Hooks Class Initialized
DEBUG - 2011-05-06 04:40:07 --> Utf8 Class Initialized
DEBUG - 2011-05-06 04:40:07 --> UTF-8 Support Enabled
DEBUG - 2011-05-06 04:40:07 --> URI Class Initialized
DEBUG - 2011-05-06 04:40:07 --> Router Class Initialized
DEBUG - 2011-05-06 04:40:07 --> Output Class Initialized
DEBUG - 2011-05-06 04:40:07 --> Input Class Initialized
DEBUG - 2011-05-06 04:40:07 --> Global POST and COOKIE data sanitized
DEBUG - 2011-05-06 04:40:07 --> Language Class Initialized
DEBUG - 2011-05-06 04:40:07 --> Loader Class Initialized
DEBUG - 2011-05-06 04:40:07 --> Controller Class Initialized
ERROR - 2011-05-06 04:40:07 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-05-06 04:40:07 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-05-06 04:40:07 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-05-06 04:40:07 --> Model Class Initialized
DEBUG - 2011-05-06 04:40:07 --> Model Class Initialized
DEBUG - 2011-05-06 04:40:07 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-05-06 04:40:08 --> Database Driver Class Initialized
DEBUG - 2011-05-06 04:40:08 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-05-06 04:40:08 --> Helper loaded: url_helper
DEBUG - 2011-05-06 04:40:08 --> File loaded: application/views/common/header.php
DEBUG - 2011-05-06 04:40:08 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-05-06 04:40:08 --> File loaded: application/views/common/footer.php
DEBUG - 2011-05-06 04:40:08 --> File loaded: application/views/layout/main.php
DEBUG - 2011-05-06 04:40:08 --> Final output sent to browser
DEBUG - 2011-05-06 04:40:08 --> Total execution time: 0.8808
DEBUG - 2011-05-06 04:40:10 --> Config Class Initialized
DEBUG - 2011-05-06 04:40:10 --> Hooks Class Initialized
DEBUG - 2011-05-06 04:40:10 --> Utf8 Class Initialized
DEBUG - 2011-05-06 04:40:10 --> UTF-8 Support Enabled
DEBUG - 2011-05-06 04:40:10 --> URI Class Initialized
DEBUG - 2011-05-06 04:40:10 --> Router Class Initialized
DEBUG - 2011-05-06 04:40:10 --> Output Class Initialized
DEBUG - 2011-05-06 04:40:10 --> Input Class Initialized
DEBUG - 2011-05-06 04:40:10 --> Global POST and COOKIE data sanitized
DEBUG - 2011-05-06 04:40:10 --> Language Class Initialized
DEBUG - 2011-05-06 04:40:10 --> Loader Class Initialized
DEBUG - 2011-05-06 04:40:10 --> Controller Class Initialized
DEBUG - 2011-05-06 04:40:10 --> Model Class Initialized
DEBUG - 2011-05-06 04:40:10 --> Model Class Initialized
DEBUG - 2011-05-06 04:40:10 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-05-06 04:40:10 --> Database Driver Class Initialized
DEBUG - 2011-05-06 04:40:27 --> Final output sent to browser
DEBUG - 2011-05-06 04:40:27 --> Total execution time: 16.8872
DEBUG - 2011-05-06 04:40:29 --> Config Class Initialized
DEBUG - 2011-05-06 04:40:29 --> Hooks Class Initialized
DEBUG - 2011-05-06 04:40:29 --> Utf8 Class Initialized
DEBUG - 2011-05-06 04:40:29 --> UTF-8 Support Enabled
DEBUG - 2011-05-06 04:40:29 --> URI Class Initialized
DEBUG - 2011-05-06 04:40:29 --> Router Class Initialized
ERROR - 2011-05-06 04:40:29 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-05-06 04:57:39 --> Config Class Initialized
DEBUG - 2011-05-06 04:57:39 --> Hooks Class Initialized
DEBUG - 2011-05-06 04:57:39 --> Utf8 Class Initialized
DEBUG - 2011-05-06 04:57:39 --> UTF-8 Support Enabled
DEBUG - 2011-05-06 04:57:39 --> URI Class Initialized
DEBUG - 2011-05-06 04:57:39 --> Router Class Initialized
DEBUG - 2011-05-06 04:57:39 --> No URI present. Default controller set.
DEBUG - 2011-05-06 04:57:39 --> Output Class Initialized
DEBUG - 2011-05-06 04:57:39 --> Input Class Initialized
DEBUG - 2011-05-06 04:57:39 --> Global POST and COOKIE data sanitized
DEBUG - 2011-05-06 04:57:39 --> Language Class Initialized
DEBUG - 2011-05-06 04:57:39 --> Loader Class Initialized
DEBUG - 2011-05-06 04:57:39 --> Controller Class Initialized
DEBUG - 2011-05-06 04:57:39 --> File loaded: application/views/splash/main.php
DEBUG - 2011-05-06 04:57:39 --> Helper loaded: url_helper
DEBUG - 2011-05-06 04:57:39 --> File loaded: application/views/common/header.php
DEBUG - 2011-05-06 04:57:39 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-05-06 04:57:39 --> File loaded: application/views/common/footer.php
DEBUG - 2011-05-06 04:57:39 --> File loaded: application/views/layout/main.php
DEBUG - 2011-05-06 04:57:39 --> Final output sent to browser
DEBUG - 2011-05-06 04:57:39 --> Total execution time: 0.2848
DEBUG - 2011-05-06 06:20:05 --> Config Class Initialized
DEBUG - 2011-05-06 06:20:05 --> Hooks Class Initialized
DEBUG - 2011-05-06 06:20:05 --> Utf8 Class Initialized
DEBUG - 2011-05-06 06:20:05 --> UTF-8 Support Enabled
DEBUG - 2011-05-06 06:20:05 --> URI Class Initialized
DEBUG - 2011-05-06 06:20:05 --> Router Class Initialized
DEBUG - 2011-05-06 06:20:05 --> Output Class Initialized
DEBUG - 2011-05-06 06:20:05 --> Input Class Initialized
DEBUG - 2011-05-06 06:20:05 --> Global POST and COOKIE data sanitized
DEBUG - 2011-05-06 06:20:05 --> Language Class Initialized
DEBUG - 2011-05-06 06:20:05 --> Loader Class Initialized
DEBUG - 2011-05-06 06:20:05 --> Controller Class Initialized
DEBUG - 2011-05-06 06:20:05 --> Model Class Initialized
DEBUG - 2011-05-06 06:20:05 --> Model Class Initialized
DEBUG - 2011-05-06 06:20:05 --> Model Class Initialized
DEBUG - 2011-05-06 06:20:05 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-05-06 06:20:06 --> Database Driver Class Initialized
DEBUG - 2011-05-06 06:20:09 --> File loaded: application/views/table/main.php
DEBUG - 2011-05-06 06:20:09 --> Helper loaded: url_helper
DEBUG - 2011-05-06 06:20:09 --> File loaded: application/views/common/header.php
DEBUG - 2011-05-06 06:20:10 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-05-06 06:20:10 --> File loaded: application/views/common/footer.php
DEBUG - 2011-05-06 06:20:10 --> File loaded: application/views/layout/main.php
DEBUG - 2011-05-06 06:20:10 --> Final output sent to browser
DEBUG - 2011-05-06 06:20:10 --> Total execution time: 4.7457
DEBUG - 2011-05-06 06:20:12 --> Config Class Initialized
DEBUG - 2011-05-06 06:20:12 --> Hooks Class Initialized
DEBUG - 2011-05-06 06:20:12 --> Utf8 Class Initialized
DEBUG - 2011-05-06 06:20:12 --> UTF-8 Support Enabled
DEBUG - 2011-05-06 06:20:12 --> URI Class Initialized
DEBUG - 2011-05-06 06:20:12 --> Router Class Initialized
DEBUG - 2011-05-06 06:20:12 --> Output Class Initialized
DEBUG - 2011-05-06 06:20:12 --> Input Class Initialized
DEBUG - 2011-05-06 06:20:12 --> Global POST and COOKIE data sanitized
DEBUG - 2011-05-06 06:20:12 --> Language Class Initialized
DEBUG - 2011-05-06 06:20:12 --> Loader Class Initialized
DEBUG - 2011-05-06 06:20:12 --> Controller Class Initialized
ERROR - 2011-05-06 06:20:15 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-05-06 06:20:15 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-05-06 06:20:15 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-05-06 06:20:15 --> Model Class Initialized
DEBUG - 2011-05-06 06:20:15 --> Model Class Initialized
DEBUG - 2011-05-06 06:20:15 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-05-06 06:20:15 --> Database Driver Class Initialized
DEBUG - 2011-05-06 06:20:15 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-05-06 06:20:15 --> Helper loaded: url_helper
DEBUG - 2011-05-06 06:20:15 --> File loaded: application/views/common/header.php
DEBUG - 2011-05-06 06:20:15 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-05-06 06:20:15 --> File loaded: application/views/common/footer.php
DEBUG - 2011-05-06 06:20:15 --> File loaded: application/views/layout/main.php
DEBUG - 2011-05-06 06:20:15 --> Final output sent to browser
DEBUG - 2011-05-06 06:20:15 --> Total execution time: 2.4179
DEBUG - 2011-05-06 09:51:55 --> Config Class Initialized
DEBUG - 2011-05-06 09:51:55 --> Hooks Class Initialized
DEBUG - 2011-05-06 09:51:55 --> Utf8 Class Initialized
DEBUG - 2011-05-06 09:51:55 --> UTF-8 Support Enabled
DEBUG - 2011-05-06 09:51:55 --> URI Class Initialized
DEBUG - 2011-05-06 09:51:55 --> Router Class Initialized
DEBUG - 2011-05-06 09:51:55 --> Output Class Initialized
DEBUG - 2011-05-06 09:51:55 --> Input Class Initialized
DEBUG - 2011-05-06 09:51:55 --> Global POST and COOKIE data sanitized
DEBUG - 2011-05-06 09:51:55 --> Language Class Initialized
DEBUG - 2011-05-06 09:51:55 --> Loader Class Initialized
DEBUG - 2011-05-06 09:51:55 --> Controller Class Initialized
DEBUG - 2011-05-06 09:51:55 --> Model Class Initialized
DEBUG - 2011-05-06 09:51:56 --> Model Class Initialized
DEBUG - 2011-05-06 09:51:56 --> Model Class Initialized
DEBUG - 2011-05-06 09:51:56 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-05-06 09:51:56 --> Database Driver Class Initialized
DEBUG - 2011-05-06 09:51:56 --> File loaded: application/views/table/main.php
DEBUG - 2011-05-06 09:51:56 --> Helper loaded: url_helper
DEBUG - 2011-05-06 09:51:56 --> File loaded: application/views/common/header.php
DEBUG - 2011-05-06 09:51:56 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-05-06 09:51:57 --> File loaded: application/views/common/footer.php
DEBUG - 2011-05-06 09:51:57 --> File loaded: application/views/layout/main.php
DEBUG - 2011-05-06 09:51:57 --> Final output sent to browser
DEBUG - 2011-05-06 09:51:57 --> Total execution time: 1.1639
DEBUG - 2011-05-06 09:52:10 --> Config Class Initialized
DEBUG - 2011-05-06 09:52:10 --> Hooks Class Initialized
DEBUG - 2011-05-06 09:52:10 --> Utf8 Class Initialized
DEBUG - 2011-05-06 09:52:10 --> UTF-8 Support Enabled
DEBUG - 2011-05-06 09:52:10 --> URI Class Initialized
DEBUG - 2011-05-06 09:52:10 --> Router Class Initialized
DEBUG - 2011-05-06 09:52:10 --> Output Class Initialized
DEBUG - 2011-05-06 09:52:10 --> Input Class Initialized
DEBUG - 2011-05-06 09:52:10 --> Global POST and COOKIE data sanitized
DEBUG - 2011-05-06 09:52:10 --> Language Class Initialized
DEBUG - 2011-05-06 09:52:10 --> Loader Class Initialized
DEBUG - 2011-05-06 09:52:10 --> Controller Class Initialized
ERROR - 2011-05-06 09:52:10 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-05-06 09:52:10 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-05-06 09:52:10 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-05-06 09:52:10 --> Model Class Initialized
DEBUG - 2011-05-06 09:52:10 --> Model Class Initialized
DEBUG - 2011-05-06 09:52:10 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-05-06 09:52:10 --> Database Driver Class Initialized
DEBUG - 2011-05-06 09:52:11 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-05-06 09:52:11 --> Helper loaded: url_helper
DEBUG - 2011-05-06 09:52:11 --> File loaded: application/views/common/header.php
DEBUG - 2011-05-06 09:52:11 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-05-06 09:52:11 --> File loaded: application/views/common/footer.php
DEBUG - 2011-05-06 09:52:11 --> File loaded: application/views/layout/main.php
DEBUG - 2011-05-06 09:52:11 --> Final output sent to browser
DEBUG - 2011-05-06 09:52:11 --> Total execution time: 0.9858
DEBUG - 2011-05-06 09:54:46 --> Config Class Initialized
DEBUG - 2011-05-06 09:54:46 --> Hooks Class Initialized
DEBUG - 2011-05-06 09:54:46 --> Utf8 Class Initialized
DEBUG - 2011-05-06 09:54:46 --> UTF-8 Support Enabled
DEBUG - 2011-05-06 09:54:46 --> URI Class Initialized
DEBUG - 2011-05-06 09:54:46 --> Router Class Initialized
DEBUG - 2011-05-06 09:54:46 --> Config Class Initialized
DEBUG - 2011-05-06 09:54:46 --> Hooks Class Initialized
DEBUG - 2011-05-06 09:54:46 --> Utf8 Class Initialized
DEBUG - 2011-05-06 09:54:46 --> UTF-8 Support Enabled
DEBUG - 2011-05-06 09:54:47 --> URI Class Initialized
DEBUG - 2011-05-06 09:54:47 --> Router Class Initialized
DEBUG - 2011-05-06 09:54:49 --> Config Class Initialized
DEBUG - 2011-05-06 09:54:49 --> Hooks Class Initialized
DEBUG - 2011-05-06 09:54:49 --> Utf8 Class Initialized
DEBUG - 2011-05-06 09:54:49 --> UTF-8 Support Enabled
DEBUG - 2011-05-06 09:54:49 --> URI Class Initialized
DEBUG - 2011-05-06 09:54:49 --> Router Class Initialized
DEBUG - 2011-05-06 09:54:49 --> No URI present. Default controller set.
DEBUG - 2011-05-06 09:54:49 --> Output Class Initialized
DEBUG - 2011-05-06 09:54:49 --> Input Class Initialized
DEBUG - 2011-05-06 09:54:49 --> Global POST and COOKIE data sanitized
DEBUG - 2011-05-06 09:54:49 --> Language Class Initialized
DEBUG - 2011-05-06 09:54:49 --> Loader Class Initialized
DEBUG - 2011-05-06 09:54:49 --> Controller Class Initialized
DEBUG - 2011-05-06 09:54:49 --> File loaded: application/views/splash/main.php
DEBUG - 2011-05-06 09:54:49 --> Helper loaded: url_helper
DEBUG - 2011-05-06 09:54:49 --> File loaded: application/views/common/header.php
DEBUG - 2011-05-06 09:54:49 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-05-06 09:54:49 --> File loaded: application/views/common/footer.php
DEBUG - 2011-05-06 09:54:49 --> File loaded: application/views/layout/main.php
DEBUG - 2011-05-06 09:54:49 --> Final output sent to browser
DEBUG - 2011-05-06 09:54:49 --> Total execution time: 0.0692
DEBUG - 2011-05-06 09:55:10 --> Config Class Initialized
DEBUG - 2011-05-06 09:55:10 --> Hooks Class Initialized
DEBUG - 2011-05-06 09:55:10 --> Utf8 Class Initialized
DEBUG - 2011-05-06 09:55:10 --> UTF-8 Support Enabled
DEBUG - 2011-05-06 09:55:10 --> URI Class Initialized
DEBUG - 2011-05-06 09:55:10 --> Router Class Initialized
DEBUG - 2011-05-06 10:29:25 --> Config Class Initialized
DEBUG - 2011-05-06 10:29:25 --> Hooks Class Initialized
DEBUG - 2011-05-06 10:29:25 --> Utf8 Class Initialized
DEBUG - 2011-05-06 10:29:25 --> UTF-8 Support Enabled
DEBUG - 2011-05-06 10:29:25 --> URI Class Initialized
DEBUG - 2011-05-06 10:29:25 --> Router Class Initialized
DEBUG - 2011-05-06 10:29:25 --> Output Class Initialized
DEBUG - 2011-05-06 10:29:25 --> Input Class Initialized
DEBUG - 2011-05-06 10:29:25 --> Global POST and COOKIE data sanitized
DEBUG - 2011-05-06 10:29:25 --> Language Class Initialized
DEBUG - 2011-05-06 10:29:25 --> Loader Class Initialized
DEBUG - 2011-05-06 10:29:25 --> Controller Class Initialized
DEBUG - 2011-05-06 10:29:25 --> Model Class Initialized
DEBUG - 2011-05-06 10:29:25 --> Model Class Initialized
DEBUG - 2011-05-06 10:29:25 --> Model Class Initialized
DEBUG - 2011-05-06 10:29:25 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-05-06 10:29:26 --> Database Driver Class Initialized
DEBUG - 2011-05-06 10:29:26 --> File loaded: application/views/table/main.php
DEBUG - 2011-05-06 10:29:26 --> Helper loaded: url_helper
DEBUG - 2011-05-06 10:29:26 --> File loaded: application/views/common/header.php
DEBUG - 2011-05-06 10:29:26 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-05-06 10:29:26 --> File loaded: application/views/common/footer.php
DEBUG - 2011-05-06 10:29:26 --> File loaded: application/views/layout/main.php
DEBUG - 2011-05-06 10:29:26 --> Final output sent to browser
DEBUG - 2011-05-06 10:29:26 --> Total execution time: 0.9217
DEBUG - 2011-05-06 10:29:29 --> Config Class Initialized
DEBUG - 2011-05-06 10:29:29 --> Hooks Class Initialized
DEBUG - 2011-05-06 10:29:29 --> Utf8 Class Initialized
DEBUG - 2011-05-06 10:29:29 --> UTF-8 Support Enabled
DEBUG - 2011-05-06 10:29:29 --> URI Class Initialized
DEBUG - 2011-05-06 10:29:29 --> Router Class Initialized
ERROR - 2011-05-06 10:29:29 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-05-06 10:29:29 --> Config Class Initialized
DEBUG - 2011-05-06 10:29:29 --> Hooks Class Initialized
DEBUG - 2011-05-06 10:29:29 --> Utf8 Class Initialized
DEBUG - 2011-05-06 10:29:29 --> UTF-8 Support Enabled
DEBUG - 2011-05-06 10:29:29 --> URI Class Initialized
DEBUG - 2011-05-06 10:29:29 --> Router Class Initialized
ERROR - 2011-05-06 10:29:29 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-05-06 10:29:29 --> Config Class Initialized
DEBUG - 2011-05-06 10:29:29 --> Hooks Class Initialized
DEBUG - 2011-05-06 10:29:29 --> Utf8 Class Initialized
DEBUG - 2011-05-06 10:29:29 --> UTF-8 Support Enabled
DEBUG - 2011-05-06 10:29:30 --> URI Class Initialized
DEBUG - 2011-05-06 10:29:30 --> Router Class Initialized
ERROR - 2011-05-06 10:29:30 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-05-06 10:35:04 --> Config Class Initialized
DEBUG - 2011-05-06 10:35:04 --> Hooks Class Initialized
DEBUG - 2011-05-06 10:35:04 --> Utf8 Class Initialized
DEBUG - 2011-05-06 10:35:04 --> UTF-8 Support Enabled
DEBUG - 2011-05-06 10:35:04 --> URI Class Initialized
DEBUG - 2011-05-06 10:35:04 --> Router Class Initialized
DEBUG - 2011-05-06 10:35:05 --> Output Class Initialized
DEBUG - 2011-05-06 10:35:05 --> Input Class Initialized
DEBUG - 2011-05-06 10:35:05 --> Global POST and COOKIE data sanitized
DEBUG - 2011-05-06 10:35:05 --> Language Class Initialized
DEBUG - 2011-05-06 10:35:05 --> Loader Class Initialized
DEBUG - 2011-05-06 10:35:05 --> Controller Class Initialized
ERROR - 2011-05-06 10:35:05 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-05-06 10:35:05 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-05-06 10:35:05 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-05-06 10:35:05 --> Model Class Initialized
DEBUG - 2011-05-06 10:35:05 --> Model Class Initialized
DEBUG - 2011-05-06 10:35:05 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-05-06 10:35:05 --> Database Driver Class Initialized
DEBUG - 2011-05-06 10:35:05 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-05-06 10:35:05 --> Helper loaded: url_helper
DEBUG - 2011-05-06 10:35:05 --> File loaded: application/views/common/header.php
DEBUG - 2011-05-06 10:35:05 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-05-06 10:35:05 --> File loaded: application/views/common/footer.php
DEBUG - 2011-05-06 10:35:05 --> File loaded: application/views/layout/main.php
DEBUG - 2011-05-06 10:35:05 --> Final output sent to browser
DEBUG - 2011-05-06 10:35:05 --> Total execution time: 1.0835
DEBUG - 2011-05-06 10:35:07 --> Config Class Initialized
DEBUG - 2011-05-06 10:35:07 --> Hooks Class Initialized
DEBUG - 2011-05-06 10:35:07 --> Utf8 Class Initialized
DEBUG - 2011-05-06 10:35:07 --> UTF-8 Support Enabled
DEBUG - 2011-05-06 10:35:07 --> URI Class Initialized
DEBUG - 2011-05-06 10:35:07 --> Router Class Initialized
DEBUG - 2011-05-06 10:35:07 --> Output Class Initialized
DEBUG - 2011-05-06 10:35:07 --> Input Class Initialized
DEBUG - 2011-05-06 10:35:07 --> Global POST and COOKIE data sanitized
DEBUG - 2011-05-06 10:35:07 --> Language Class Initialized
DEBUG - 2011-05-06 10:35:07 --> Loader Class Initialized
DEBUG - 2011-05-06 10:35:07 --> Controller Class Initialized
DEBUG - 2011-05-06 10:35:07 --> Model Class Initialized
DEBUG - 2011-05-06 10:35:07 --> Model Class Initialized
DEBUG - 2011-05-06 10:35:07 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-05-06 10:35:07 --> Database Driver Class Initialized
DEBUG - 2011-05-06 10:35:08 --> Final output sent to browser
DEBUG - 2011-05-06 10:35:08 --> Total execution time: 1.1108
DEBUG - 2011-05-06 10:35:09 --> Config Class Initialized
DEBUG - 2011-05-06 10:35:09 --> Hooks Class Initialized
DEBUG - 2011-05-06 10:35:09 --> Utf8 Class Initialized
DEBUG - 2011-05-06 10:35:09 --> UTF-8 Support Enabled
DEBUG - 2011-05-06 10:35:09 --> URI Class Initialized
DEBUG - 2011-05-06 10:35:09 --> Router Class Initialized
ERROR - 2011-05-06 10:35:09 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-05-06 10:35:33 --> Config Class Initialized
DEBUG - 2011-05-06 10:35:33 --> Hooks Class Initialized
DEBUG - 2011-05-06 10:35:33 --> Utf8 Class Initialized
DEBUG - 2011-05-06 10:35:33 --> UTF-8 Support Enabled
DEBUG - 2011-05-06 10:35:33 --> URI Class Initialized
DEBUG - 2011-05-06 10:35:33 --> Router Class Initialized
DEBUG - 2011-05-06 10:35:33 --> Output Class Initialized
DEBUG - 2011-05-06 10:35:33 --> Input Class Initialized
DEBUG - 2011-05-06 10:35:33 --> Global POST and COOKIE data sanitized
DEBUG - 2011-05-06 10:35:33 --> Language Class Initialized
DEBUG - 2011-05-06 10:35:33 --> Loader Class Initialized
DEBUG - 2011-05-06 10:35:33 --> Controller Class Initialized
ERROR - 2011-05-06 10:35:33 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-05-06 10:35:33 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-05-06 10:35:33 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-05-06 10:35:33 --> Model Class Initialized
DEBUG - 2011-05-06 10:35:33 --> Model Class Initialized
DEBUG - 2011-05-06 10:35:33 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-05-06 10:35:33 --> Database Driver Class Initialized
DEBUG - 2011-05-06 10:35:33 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-05-06 10:35:33 --> Helper loaded: url_helper
DEBUG - 2011-05-06 10:35:33 --> File loaded: application/views/common/header.php
DEBUG - 2011-05-06 10:35:33 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-05-06 10:35:33 --> File loaded: application/views/common/footer.php
DEBUG - 2011-05-06 10:35:33 --> File loaded: application/views/layout/main.php
DEBUG - 2011-05-06 10:35:33 --> Final output sent to browser
DEBUG - 2011-05-06 10:35:33 --> Total execution time: 0.0289
DEBUG - 2011-05-06 10:35:34 --> Config Class Initialized
DEBUG - 2011-05-06 10:35:34 --> Hooks Class Initialized
DEBUG - 2011-05-06 10:35:34 --> Utf8 Class Initialized
DEBUG - 2011-05-06 10:35:34 --> UTF-8 Support Enabled
DEBUG - 2011-05-06 10:35:34 --> URI Class Initialized
DEBUG - 2011-05-06 10:35:34 --> Router Class Initialized
DEBUG - 2011-05-06 10:35:34 --> Output Class Initialized
DEBUG - 2011-05-06 10:35:34 --> Input Class Initialized
DEBUG - 2011-05-06 10:35:34 --> Global POST and COOKIE data sanitized
DEBUG - 2011-05-06 10:35:34 --> Language Class Initialized
DEBUG - 2011-05-06 10:35:34 --> Loader Class Initialized
DEBUG - 2011-05-06 10:35:34 --> Controller Class Initialized
DEBUG - 2011-05-06 10:35:34 --> Model Class Initialized
DEBUG - 2011-05-06 10:35:34 --> Model Class Initialized
DEBUG - 2011-05-06 10:35:34 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-05-06 10:35:34 --> Database Driver Class Initialized
DEBUG - 2011-05-06 10:35:34 --> Final output sent to browser
DEBUG - 2011-05-06 10:35:34 --> Total execution time: 0.5887
DEBUG - 2011-05-06 10:35:35 --> Config Class Initialized
DEBUG - 2011-05-06 10:35:35 --> Hooks Class Initialized
DEBUG - 2011-05-06 10:35:35 --> Utf8 Class Initialized
DEBUG - 2011-05-06 10:35:35 --> UTF-8 Support Enabled
DEBUG - 2011-05-06 10:35:35 --> URI Class Initialized
DEBUG - 2011-05-06 10:35:35 --> Router Class Initialized
ERROR - 2011-05-06 10:35:35 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-05-06 10:36:41 --> Config Class Initialized
DEBUG - 2011-05-06 10:36:41 --> Hooks Class Initialized
DEBUG - 2011-05-06 10:36:41 --> Utf8 Class Initialized
DEBUG - 2011-05-06 10:36:41 --> UTF-8 Support Enabled
DEBUG - 2011-05-06 10:36:41 --> URI Class Initialized
DEBUG - 2011-05-06 10:36:41 --> Router Class Initialized
DEBUG - 2011-05-06 10:36:41 --> Output Class Initialized
DEBUG - 2011-05-06 10:36:41 --> Input Class Initialized
DEBUG - 2011-05-06 10:36:41 --> Global POST and COOKIE data sanitized
DEBUG - 2011-05-06 10:36:41 --> Language Class Initialized
DEBUG - 2011-05-06 10:36:41 --> Loader Class Initialized
DEBUG - 2011-05-06 10:36:41 --> Controller Class Initialized
ERROR - 2011-05-06 10:36:41 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-05-06 10:36:41 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-05-06 10:36:41 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-05-06 10:36:41 --> Model Class Initialized
DEBUG - 2011-05-06 10:36:41 --> Model Class Initialized
DEBUG - 2011-05-06 10:36:41 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-05-06 10:36:41 --> Database Driver Class Initialized
DEBUG - 2011-05-06 10:36:41 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-05-06 10:36:41 --> Helper loaded: url_helper
DEBUG - 2011-05-06 10:36:41 --> File loaded: application/views/common/header.php
DEBUG - 2011-05-06 10:36:41 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-05-06 10:36:41 --> File loaded: application/views/common/footer.php
DEBUG - 2011-05-06 10:36:41 --> File loaded: application/views/layout/main.php
DEBUG - 2011-05-06 10:36:41 --> Final output sent to browser
DEBUG - 2011-05-06 10:36:41 --> Total execution time: 0.1170
DEBUG - 2011-05-06 10:36:42 --> Config Class Initialized
DEBUG - 2011-05-06 10:36:42 --> Hooks Class Initialized
DEBUG - 2011-05-06 10:36:42 --> Utf8 Class Initialized
DEBUG - 2011-05-06 10:36:42 --> UTF-8 Support Enabled
DEBUG - 2011-05-06 10:36:42 --> URI Class Initialized
DEBUG - 2011-05-06 10:36:42 --> Router Class Initialized
DEBUG - 2011-05-06 10:36:42 --> Output Class Initialized
DEBUG - 2011-05-06 10:36:42 --> Input Class Initialized
DEBUG - 2011-05-06 10:36:42 --> Global POST and COOKIE data sanitized
DEBUG - 2011-05-06 10:36:42 --> Language Class Initialized
DEBUG - 2011-05-06 10:36:42 --> Loader Class Initialized
DEBUG - 2011-05-06 10:36:42 --> Controller Class Initialized
DEBUG - 2011-05-06 10:36:42 --> Model Class Initialized
DEBUG - 2011-05-06 10:36:42 --> Model Class Initialized
DEBUG - 2011-05-06 10:36:42 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-05-06 10:36:42 --> Database Driver Class Initialized
DEBUG - 2011-05-06 10:36:43 --> Final output sent to browser
DEBUG - 2011-05-06 10:36:43 --> Total execution time: 0.6457
DEBUG - 2011-05-06 10:36:44 --> Config Class Initialized
DEBUG - 2011-05-06 10:36:44 --> Hooks Class Initialized
DEBUG - 2011-05-06 10:36:44 --> Utf8 Class Initialized
DEBUG - 2011-05-06 10:36:44 --> UTF-8 Support Enabled
DEBUG - 2011-05-06 10:36:44 --> URI Class Initialized
DEBUG - 2011-05-06 10:36:44 --> Router Class Initialized
ERROR - 2011-05-06 10:36:44 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-05-06 10:37:05 --> Config Class Initialized
DEBUG - 2011-05-06 10:37:05 --> Hooks Class Initialized
DEBUG - 2011-05-06 10:37:05 --> Utf8 Class Initialized
DEBUG - 2011-05-06 10:37:05 --> UTF-8 Support Enabled
DEBUG - 2011-05-06 10:37:05 --> URI Class Initialized
DEBUG - 2011-05-06 10:37:05 --> Router Class Initialized
DEBUG - 2011-05-06 10:37:05 --> Output Class Initialized
DEBUG - 2011-05-06 10:37:05 --> Input Class Initialized
DEBUG - 2011-05-06 10:37:05 --> Global POST and COOKIE data sanitized
DEBUG - 2011-05-06 10:37:05 --> Language Class Initialized
DEBUG - 2011-05-06 10:37:05 --> Loader Class Initialized
DEBUG - 2011-05-06 10:37:05 --> Controller Class Initialized
ERROR - 2011-05-06 10:37:05 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-05-06 10:37:05 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-05-06 10:37:05 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-05-06 10:37:05 --> Model Class Initialized
DEBUG - 2011-05-06 10:37:05 --> Model Class Initialized
DEBUG - 2011-05-06 10:37:05 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-05-06 10:37:05 --> Database Driver Class Initialized
DEBUG - 2011-05-06 10:37:05 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-05-06 10:37:05 --> Helper loaded: url_helper
DEBUG - 2011-05-06 10:37:05 --> File loaded: application/views/common/header.php
DEBUG - 2011-05-06 10:37:05 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-05-06 10:37:05 --> File loaded: application/views/common/footer.php
DEBUG - 2011-05-06 10:37:05 --> File loaded: application/views/layout/main.php
DEBUG - 2011-05-06 10:37:05 --> Final output sent to browser
DEBUG - 2011-05-06 10:37:05 --> Total execution time: 0.0274
DEBUG - 2011-05-06 10:37:06 --> Config Class Initialized
DEBUG - 2011-05-06 10:37:06 --> Hooks Class Initialized
DEBUG - 2011-05-06 10:37:06 --> Utf8 Class Initialized
DEBUG - 2011-05-06 10:37:06 --> UTF-8 Support Enabled
DEBUG - 2011-05-06 10:37:06 --> URI Class Initialized
DEBUG - 2011-05-06 10:37:06 --> Router Class Initialized
DEBUG - 2011-05-06 10:37:06 --> Output Class Initialized
DEBUG - 2011-05-06 10:37:06 --> Input Class Initialized
DEBUG - 2011-05-06 10:37:06 --> Global POST and COOKIE data sanitized
DEBUG - 2011-05-06 10:37:06 --> Language Class Initialized
DEBUG - 2011-05-06 10:37:06 --> Loader Class Initialized
DEBUG - 2011-05-06 10:37:06 --> Controller Class Initialized
DEBUG - 2011-05-06 10:37:06 --> Model Class Initialized
DEBUG - 2011-05-06 10:37:06 --> Model Class Initialized
DEBUG - 2011-05-06 10:37:06 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-05-06 10:37:06 --> Database Driver Class Initialized
DEBUG - 2011-05-06 10:37:07 --> Final output sent to browser
DEBUG - 2011-05-06 10:37:07 --> Total execution time: 0.6470
DEBUG - 2011-05-06 10:37:08 --> Config Class Initialized
DEBUG - 2011-05-06 10:37:08 --> Hooks Class Initialized
DEBUG - 2011-05-06 10:37:08 --> Utf8 Class Initialized
DEBUG - 2011-05-06 10:37:08 --> UTF-8 Support Enabled
DEBUG - 2011-05-06 10:37:08 --> URI Class Initialized
DEBUG - 2011-05-06 10:37:08 --> Router Class Initialized
ERROR - 2011-05-06 10:37:08 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-05-06 10:37:08 --> Config Class Initialized
DEBUG - 2011-05-06 10:37:08 --> Hooks Class Initialized
DEBUG - 2011-05-06 10:37:08 --> Utf8 Class Initialized
DEBUG - 2011-05-06 10:37:08 --> UTF-8 Support Enabled
DEBUG - 2011-05-06 10:37:08 --> URI Class Initialized
DEBUG - 2011-05-06 10:37:08 --> Router Class Initialized
DEBUG - 2011-05-06 10:37:08 --> Output Class Initialized
DEBUG - 2011-05-06 10:37:08 --> Input Class Initialized
DEBUG - 2011-05-06 10:37:08 --> Global POST and COOKIE data sanitized
DEBUG - 2011-05-06 10:37:08 --> Language Class Initialized
DEBUG - 2011-05-06 10:37:08 --> Loader Class Initialized
DEBUG - 2011-05-06 10:37:08 --> Controller Class Initialized
ERROR - 2011-05-06 10:37:08 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-05-06 10:37:08 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-05-06 10:37:08 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-05-06 10:37:08 --> Model Class Initialized
DEBUG - 2011-05-06 10:37:08 --> Model Class Initialized
DEBUG - 2011-05-06 10:37:08 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-05-06 10:37:08 --> Database Driver Class Initialized
DEBUG - 2011-05-06 10:37:09 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-05-06 10:37:09 --> Helper loaded: url_helper
DEBUG - 2011-05-06 10:37:09 --> File loaded: application/views/common/header.php
DEBUG - 2011-05-06 10:37:09 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-05-06 10:37:09 --> File loaded: application/views/common/footer.php
DEBUG - 2011-05-06 10:37:09 --> File loaded: application/views/layout/main.php
DEBUG - 2011-05-06 10:37:09 --> Final output sent to browser
DEBUG - 2011-05-06 10:37:09 --> Total execution time: 0.0366
DEBUG - 2011-05-06 10:37:27 --> Config Class Initialized
DEBUG - 2011-05-06 10:37:27 --> Hooks Class Initialized
DEBUG - 2011-05-06 10:37:27 --> Utf8 Class Initialized
DEBUG - 2011-05-06 10:37:27 --> UTF-8 Support Enabled
DEBUG - 2011-05-06 10:37:27 --> URI Class Initialized
DEBUG - 2011-05-06 10:37:27 --> Router Class Initialized
DEBUG - 2011-05-06 10:37:27 --> Output Class Initialized
DEBUG - 2011-05-06 10:37:27 --> Input Class Initialized
DEBUG - 2011-05-06 10:37:27 --> Global POST and COOKIE data sanitized
DEBUG - 2011-05-06 10:37:27 --> Language Class Initialized
DEBUG - 2011-05-06 10:37:27 --> Loader Class Initialized
DEBUG - 2011-05-06 10:37:27 --> Controller Class Initialized
ERROR - 2011-05-06 10:37:27 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-05-06 10:37:27 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-05-06 10:37:27 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-05-06 10:37:27 --> Model Class Initialized
DEBUG - 2011-05-06 10:37:27 --> Model Class Initialized
DEBUG - 2011-05-06 10:37:27 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-05-06 10:37:27 --> Database Driver Class Initialized
DEBUG - 2011-05-06 10:37:27 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-05-06 10:37:27 --> Helper loaded: url_helper
DEBUG - 2011-05-06 10:37:27 --> File loaded: application/views/common/header.php
DEBUG - 2011-05-06 10:37:27 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-05-06 10:37:27 --> File loaded: application/views/common/footer.php
DEBUG - 2011-05-06 10:37:27 --> File loaded: application/views/layout/main.php
DEBUG - 2011-05-06 10:37:27 --> Final output sent to browser
DEBUG - 2011-05-06 10:37:27 --> Total execution time: 0.1992
DEBUG - 2011-05-06 10:37:28 --> Config Class Initialized
DEBUG - 2011-05-06 10:37:28 --> Hooks Class Initialized
DEBUG - 2011-05-06 10:37:28 --> Utf8 Class Initialized
DEBUG - 2011-05-06 10:37:28 --> UTF-8 Support Enabled
DEBUG - 2011-05-06 10:37:28 --> URI Class Initialized
DEBUG - 2011-05-06 10:37:28 --> Router Class Initialized
DEBUG - 2011-05-06 10:37:28 --> Output Class Initialized
DEBUG - 2011-05-06 10:37:28 --> Input Class Initialized
DEBUG - 2011-05-06 10:37:28 --> Global POST and COOKIE data sanitized
DEBUG - 2011-05-06 10:37:28 --> Language Class Initialized
DEBUG - 2011-05-06 10:37:28 --> Loader Class Initialized
DEBUG - 2011-05-06 10:37:28 --> Controller Class Initialized
DEBUG - 2011-05-06 10:37:28 --> Model Class Initialized
DEBUG - 2011-05-06 10:37:28 --> Model Class Initialized
DEBUG - 2011-05-06 10:37:28 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-05-06 10:37:28 --> Database Driver Class Initialized
DEBUG - 2011-05-06 10:37:29 --> Final output sent to browser
DEBUG - 2011-05-06 10:37:29 --> Total execution time: 0.8132
DEBUG - 2011-05-06 10:37:30 --> Config Class Initialized
DEBUG - 2011-05-06 10:37:30 --> Hooks Class Initialized
DEBUG - 2011-05-06 10:37:30 --> Utf8 Class Initialized
DEBUG - 2011-05-06 10:37:30 --> UTF-8 Support Enabled
DEBUG - 2011-05-06 10:37:30 --> URI Class Initialized
DEBUG - 2011-05-06 10:37:30 --> Router Class Initialized
ERROR - 2011-05-06 10:37:30 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-05-06 10:37:47 --> Config Class Initialized
DEBUG - 2011-05-06 10:37:47 --> Hooks Class Initialized
DEBUG - 2011-05-06 10:37:47 --> Utf8 Class Initialized
DEBUG - 2011-05-06 10:37:47 --> UTF-8 Support Enabled
DEBUG - 2011-05-06 10:37:47 --> URI Class Initialized
DEBUG - 2011-05-06 10:37:47 --> Router Class Initialized
DEBUG - 2011-05-06 10:37:47 --> Output Class Initialized
DEBUG - 2011-05-06 10:37:47 --> Input Class Initialized
DEBUG - 2011-05-06 10:37:47 --> Global POST and COOKIE data sanitized
DEBUG - 2011-05-06 10:37:47 --> Language Class Initialized
DEBUG - 2011-05-06 10:37:47 --> Loader Class Initialized
DEBUG - 2011-05-06 10:37:47 --> Controller Class Initialized
ERROR - 2011-05-06 10:37:47 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-05-06 10:37:47 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-05-06 10:37:47 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-05-06 10:37:47 --> Model Class Initialized
DEBUG - 2011-05-06 10:37:47 --> Model Class Initialized
DEBUG - 2011-05-06 10:37:47 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-05-06 10:37:47 --> Database Driver Class Initialized
DEBUG - 2011-05-06 10:37:47 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-05-06 10:37:47 --> Helper loaded: url_helper
DEBUG - 2011-05-06 10:37:47 --> File loaded: application/views/common/header.php
DEBUG - 2011-05-06 10:37:47 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-05-06 10:37:47 --> File loaded: application/views/common/footer.php
DEBUG - 2011-05-06 10:37:47 --> File loaded: application/views/layout/main.php
DEBUG - 2011-05-06 10:37:47 --> Final output sent to browser
DEBUG - 2011-05-06 10:37:47 --> Total execution time: 0.0297
DEBUG - 2011-05-06 10:37:48 --> Config Class Initialized
DEBUG - 2011-05-06 10:37:48 --> Hooks Class Initialized
DEBUG - 2011-05-06 10:37:48 --> Utf8 Class Initialized
DEBUG - 2011-05-06 10:37:48 --> UTF-8 Support Enabled
DEBUG - 2011-05-06 10:37:48 --> URI Class Initialized
DEBUG - 2011-05-06 10:37:48 --> Router Class Initialized
DEBUG - 2011-05-06 10:37:48 --> Output Class Initialized
DEBUG - 2011-05-06 10:37:48 --> Input Class Initialized
DEBUG - 2011-05-06 10:37:48 --> Global POST and COOKIE data sanitized
DEBUG - 2011-05-06 10:37:48 --> Language Class Initialized
DEBUG - 2011-05-06 10:37:48 --> Loader Class Initialized
DEBUG - 2011-05-06 10:37:48 --> Controller Class Initialized
DEBUG - 2011-05-06 10:37:48 --> Model Class Initialized
DEBUG - 2011-05-06 10:37:48 --> Model Class Initialized
DEBUG - 2011-05-06 10:37:48 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-05-06 10:37:48 --> Database Driver Class Initialized
DEBUG - 2011-05-06 10:37:48 --> Final output sent to browser
DEBUG - 2011-05-06 10:37:48 --> Total execution time: 0.5842
DEBUG - 2011-05-06 10:37:49 --> Config Class Initialized
DEBUG - 2011-05-06 10:37:49 --> Hooks Class Initialized
DEBUG - 2011-05-06 10:37:49 --> Utf8 Class Initialized
DEBUG - 2011-05-06 10:37:49 --> UTF-8 Support Enabled
DEBUG - 2011-05-06 10:37:49 --> URI Class Initialized
DEBUG - 2011-05-06 10:37:49 --> Router Class Initialized
ERROR - 2011-05-06 10:37:49 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-05-06 10:37:50 --> Config Class Initialized
DEBUG - 2011-05-06 10:37:50 --> Hooks Class Initialized
DEBUG - 2011-05-06 10:37:50 --> Utf8 Class Initialized
DEBUG - 2011-05-06 10:37:50 --> UTF-8 Support Enabled
DEBUG - 2011-05-06 10:37:50 --> URI Class Initialized
DEBUG - 2011-05-06 10:37:50 --> Router Class Initialized
DEBUG - 2011-05-06 10:37:50 --> Output Class Initialized
DEBUG - 2011-05-06 10:37:50 --> Input Class Initialized
DEBUG - 2011-05-06 10:37:50 --> Global POST and COOKIE data sanitized
DEBUG - 2011-05-06 10:37:50 --> Language Class Initialized
DEBUG - 2011-05-06 10:37:50 --> Loader Class Initialized
DEBUG - 2011-05-06 10:37:50 --> Controller Class Initialized
ERROR - 2011-05-06 10:37:50 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-05-06 10:37:50 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-05-06 10:37:50 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-05-06 10:37:50 --> Model Class Initialized
DEBUG - 2011-05-06 10:37:50 --> Model Class Initialized
DEBUG - 2011-05-06 10:37:50 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-05-06 10:37:50 --> Database Driver Class Initialized
DEBUG - 2011-05-06 10:37:50 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-05-06 10:37:50 --> Helper loaded: url_helper
DEBUG - 2011-05-06 10:37:50 --> File loaded: application/views/common/header.php
DEBUG - 2011-05-06 10:37:50 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-05-06 10:37:50 --> File loaded: application/views/common/footer.php
DEBUG - 2011-05-06 10:37:50 --> File loaded: application/views/layout/main.php
DEBUG - 2011-05-06 10:37:50 --> Final output sent to browser
DEBUG - 2011-05-06 10:37:50 --> Total execution time: 0.0300
DEBUG - 2011-05-06 10:37:51 --> Config Class Initialized
DEBUG - 2011-05-06 10:37:51 --> Hooks Class Initialized
DEBUG - 2011-05-06 10:37:51 --> Utf8 Class Initialized
DEBUG - 2011-05-06 10:37:51 --> UTF-8 Support Enabled
DEBUG - 2011-05-06 10:37:51 --> URI Class Initialized
DEBUG - 2011-05-06 10:37:51 --> Router Class Initialized
DEBUG - 2011-05-06 10:37:51 --> Output Class Initialized
DEBUG - 2011-05-06 10:37:51 --> Input Class Initialized
DEBUG - 2011-05-06 10:37:51 --> Global POST and COOKIE data sanitized
DEBUG - 2011-05-06 10:37:51 --> Language Class Initialized
DEBUG - 2011-05-06 10:37:51 --> Loader Class Initialized
DEBUG - 2011-05-06 10:37:51 --> Controller Class Initialized
DEBUG - 2011-05-06 10:37:51 --> Model Class Initialized
DEBUG - 2011-05-06 10:37:51 --> Model Class Initialized
DEBUG - 2011-05-06 10:37:51 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-05-06 10:37:51 --> Database Driver Class Initialized
DEBUG - 2011-05-06 10:37:51 --> Final output sent to browser
DEBUG - 2011-05-06 10:37:51 --> Total execution time: 0.5589
DEBUG - 2011-05-06 10:37:52 --> Config Class Initialized
DEBUG - 2011-05-06 10:37:52 --> Hooks Class Initialized
DEBUG - 2011-05-06 10:37:52 --> Utf8 Class Initialized
DEBUG - 2011-05-06 10:37:52 --> UTF-8 Support Enabled
DEBUG - 2011-05-06 10:37:52 --> URI Class Initialized
DEBUG - 2011-05-06 10:37:52 --> Router Class Initialized
ERROR - 2011-05-06 10:37:52 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-05-06 10:38:03 --> Config Class Initialized
DEBUG - 2011-05-06 10:38:03 --> Hooks Class Initialized
DEBUG - 2011-05-06 10:38:03 --> Utf8 Class Initialized
DEBUG - 2011-05-06 10:38:03 --> UTF-8 Support Enabled
DEBUG - 2011-05-06 10:38:03 --> URI Class Initialized
DEBUG - 2011-05-06 10:38:03 --> Router Class Initialized
DEBUG - 2011-05-06 10:38:03 --> Output Class Initialized
DEBUG - 2011-05-06 10:38:03 --> Input Class Initialized
DEBUG - 2011-05-06 10:38:03 --> Global POST and COOKIE data sanitized
DEBUG - 2011-05-06 10:38:03 --> Language Class Initialized
DEBUG - 2011-05-06 10:38:03 --> Loader Class Initialized
DEBUG - 2011-05-06 10:38:03 --> Controller Class Initialized
ERROR - 2011-05-06 10:38:03 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-05-06 10:38:03 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-05-06 10:38:03 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-05-06 10:38:03 --> Model Class Initialized
DEBUG - 2011-05-06 10:38:03 --> Model Class Initialized
DEBUG - 2011-05-06 10:38:03 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-05-06 10:38:03 --> Database Driver Class Initialized
DEBUG - 2011-05-06 10:38:03 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-05-06 10:38:03 --> Helper loaded: url_helper
DEBUG - 2011-05-06 10:38:03 --> File loaded: application/views/common/header.php
DEBUG - 2011-05-06 10:38:03 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-05-06 10:38:03 --> File loaded: application/views/common/footer.php
DEBUG - 2011-05-06 10:38:03 --> File loaded: application/views/layout/main.php
DEBUG - 2011-05-06 10:38:03 --> Final output sent to browser
DEBUG - 2011-05-06 10:38:03 --> Total execution time: 0.0416
DEBUG - 2011-05-06 10:38:03 --> Config Class Initialized
DEBUG - 2011-05-06 10:38:03 --> Hooks Class Initialized
DEBUG - 2011-05-06 10:38:03 --> Utf8 Class Initialized
DEBUG - 2011-05-06 10:38:03 --> UTF-8 Support Enabled
DEBUG - 2011-05-06 10:38:03 --> URI Class Initialized
DEBUG - 2011-05-06 10:38:03 --> Router Class Initialized
DEBUG - 2011-05-06 10:38:03 --> Output Class Initialized
DEBUG - 2011-05-06 10:38:03 --> Input Class Initialized
DEBUG - 2011-05-06 10:38:03 --> Global POST and COOKIE data sanitized
DEBUG - 2011-05-06 10:38:03 --> Language Class Initialized
DEBUG - 2011-05-06 10:38:03 --> Loader Class Initialized
DEBUG - 2011-05-06 10:38:03 --> Controller Class Initialized
DEBUG - 2011-05-06 10:38:03 --> Model Class Initialized
DEBUG - 2011-05-06 10:38:03 --> Model Class Initialized
DEBUG - 2011-05-06 10:38:03 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-05-06 10:38:03 --> Database Driver Class Initialized
DEBUG - 2011-05-06 10:38:04 --> Final output sent to browser
DEBUG - 2011-05-06 10:38:04 --> Total execution time: 0.5739
DEBUG - 2011-05-06 10:38:05 --> Config Class Initialized
DEBUG - 2011-05-06 10:38:05 --> Hooks Class Initialized
DEBUG - 2011-05-06 10:38:05 --> Utf8 Class Initialized
DEBUG - 2011-05-06 10:38:05 --> UTF-8 Support Enabled
DEBUG - 2011-05-06 10:38:05 --> URI Class Initialized
DEBUG - 2011-05-06 10:38:05 --> Router Class Initialized
ERROR - 2011-05-06 10:38:05 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-05-06 10:38:12 --> Config Class Initialized
DEBUG - 2011-05-06 10:38:12 --> Hooks Class Initialized
DEBUG - 2011-05-06 10:38:12 --> Utf8 Class Initialized
DEBUG - 2011-05-06 10:38:12 --> UTF-8 Support Enabled
DEBUG - 2011-05-06 10:38:12 --> URI Class Initialized
DEBUG - 2011-05-06 10:38:12 --> Router Class Initialized
DEBUG - 2011-05-06 10:38:12 --> Output Class Initialized
DEBUG - 2011-05-06 10:38:12 --> Input Class Initialized
DEBUG - 2011-05-06 10:38:12 --> Global POST and COOKIE data sanitized
DEBUG - 2011-05-06 10:38:12 --> Language Class Initialized
DEBUG - 2011-05-06 10:38:12 --> Loader Class Initialized
DEBUG - 2011-05-06 10:38:12 --> Controller Class Initialized
ERROR - 2011-05-06 10:38:12 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-05-06 10:38:12 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-05-06 10:38:12 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-05-06 10:38:12 --> Model Class Initialized
DEBUG - 2011-05-06 10:38:12 --> Model Class Initialized
DEBUG - 2011-05-06 10:38:12 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-05-06 10:38:12 --> Database Driver Class Initialized
DEBUG - 2011-05-06 10:38:12 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-05-06 10:38:12 --> Helper loaded: url_helper
DEBUG - 2011-05-06 10:38:12 --> File loaded: application/views/common/header.php
DEBUG - 2011-05-06 10:38:12 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-05-06 10:38:12 --> File loaded: application/views/common/footer.php
DEBUG - 2011-05-06 10:38:12 --> File loaded: application/views/layout/main.php
DEBUG - 2011-05-06 10:38:12 --> Final output sent to browser
DEBUG - 2011-05-06 10:38:12 --> Total execution time: 0.0719
DEBUG - 2011-05-06 10:38:13 --> Config Class Initialized
DEBUG - 2011-05-06 10:38:13 --> Hooks Class Initialized
DEBUG - 2011-05-06 10:38:13 --> Utf8 Class Initialized
DEBUG - 2011-05-06 10:38:13 --> UTF-8 Support Enabled
DEBUG - 2011-05-06 10:38:13 --> URI Class Initialized
DEBUG - 2011-05-06 10:38:13 --> Router Class Initialized
DEBUG - 2011-05-06 10:38:13 --> Output Class Initialized
DEBUG - 2011-05-06 10:38:13 --> Input Class Initialized
DEBUG - 2011-05-06 10:38:13 --> Global POST and COOKIE data sanitized
DEBUG - 2011-05-06 10:38:13 --> Language Class Initialized
DEBUG - 2011-05-06 10:38:13 --> Loader Class Initialized
DEBUG - 2011-05-06 10:38:13 --> Controller Class Initialized
DEBUG - 2011-05-06 10:38:13 --> Model Class Initialized
DEBUG - 2011-05-06 10:38:13 --> Model Class Initialized
DEBUG - 2011-05-06 10:38:13 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-05-06 10:38:13 --> Database Driver Class Initialized
DEBUG - 2011-05-06 10:38:14 --> Final output sent to browser
DEBUG - 2011-05-06 10:38:14 --> Total execution time: 0.5896
DEBUG - 2011-05-06 10:38:15 --> Config Class Initialized
DEBUG - 2011-05-06 10:38:15 --> Hooks Class Initialized
DEBUG - 2011-05-06 10:38:15 --> Utf8 Class Initialized
DEBUG - 2011-05-06 10:38:15 --> UTF-8 Support Enabled
DEBUG - 2011-05-06 10:38:15 --> URI Class Initialized
DEBUG - 2011-05-06 10:38:15 --> Router Class Initialized
ERROR - 2011-05-06 10:38:15 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-05-06 10:38:24 --> Config Class Initialized
DEBUG - 2011-05-06 10:38:24 --> Hooks Class Initialized
DEBUG - 2011-05-06 10:38:24 --> Utf8 Class Initialized
DEBUG - 2011-05-06 10:38:24 --> UTF-8 Support Enabled
DEBUG - 2011-05-06 10:38:24 --> URI Class Initialized
DEBUG - 2011-05-06 10:38:24 --> Router Class Initialized
DEBUG - 2011-05-06 10:38:24 --> Output Class Initialized
DEBUG - 2011-05-06 10:38:24 --> Input Class Initialized
DEBUG - 2011-05-06 10:38:24 --> Global POST and COOKIE data sanitized
DEBUG - 2011-05-06 10:38:24 --> Language Class Initialized
DEBUG - 2011-05-06 10:38:24 --> Loader Class Initialized
DEBUG - 2011-05-06 10:38:24 --> Controller Class Initialized
ERROR - 2011-05-06 10:38:24 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-05-06 10:38:24 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-05-06 10:38:24 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-05-06 10:38:24 --> Model Class Initialized
DEBUG - 2011-05-06 10:38:24 --> Model Class Initialized
DEBUG - 2011-05-06 10:38:24 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-05-06 10:38:24 --> Database Driver Class Initialized
DEBUG - 2011-05-06 10:38:24 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-05-06 10:38:24 --> Helper loaded: url_helper
DEBUG - 2011-05-06 10:38:24 --> File loaded: application/views/common/header.php
DEBUG - 2011-05-06 10:38:24 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-05-06 10:38:24 --> File loaded: application/views/common/footer.php
DEBUG - 2011-05-06 10:38:24 --> File loaded: application/views/layout/main.php
DEBUG - 2011-05-06 10:38:24 --> Final output sent to browser
DEBUG - 2011-05-06 10:38:24 --> Total execution time: 0.1605
DEBUG - 2011-05-06 10:38:25 --> Config Class Initialized
DEBUG - 2011-05-06 10:38:25 --> Hooks Class Initialized
DEBUG - 2011-05-06 10:38:25 --> Utf8 Class Initialized
DEBUG - 2011-05-06 10:38:25 --> UTF-8 Support Enabled
DEBUG - 2011-05-06 10:38:25 --> URI Class Initialized
DEBUG - 2011-05-06 10:38:25 --> Router Class Initialized
DEBUG - 2011-05-06 10:38:25 --> Output Class Initialized
DEBUG - 2011-05-06 10:38:25 --> Input Class Initialized
DEBUG - 2011-05-06 10:38:25 --> Global POST and COOKIE data sanitized
DEBUG - 2011-05-06 10:38:25 --> Language Class Initialized
DEBUG - 2011-05-06 10:38:25 --> Loader Class Initialized
DEBUG - 2011-05-06 10:38:25 --> Controller Class Initialized
DEBUG - 2011-05-06 10:38:25 --> Model Class Initialized
DEBUG - 2011-05-06 10:38:25 --> Model Class Initialized
DEBUG - 2011-05-06 10:38:25 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-05-06 10:38:25 --> Database Driver Class Initialized
DEBUG - 2011-05-06 10:38:25 --> Final output sent to browser
DEBUG - 2011-05-06 10:38:25 --> Total execution time: 0.7119
DEBUG - 2011-05-06 10:38:27 --> Config Class Initialized
DEBUG - 2011-05-06 10:38:27 --> Hooks Class Initialized
DEBUG - 2011-05-06 10:38:27 --> Utf8 Class Initialized
DEBUG - 2011-05-06 10:38:27 --> UTF-8 Support Enabled
DEBUG - 2011-05-06 10:38:27 --> URI Class Initialized
DEBUG - 2011-05-06 10:38:27 --> Router Class Initialized
ERROR - 2011-05-06 10:38:27 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-05-06 10:38:38 --> Config Class Initialized
DEBUG - 2011-05-06 10:38:38 --> Hooks Class Initialized
DEBUG - 2011-05-06 10:38:38 --> Utf8 Class Initialized
DEBUG - 2011-05-06 10:38:38 --> UTF-8 Support Enabled
DEBUG - 2011-05-06 10:38:38 --> URI Class Initialized
DEBUG - 2011-05-06 10:38:38 --> Router Class Initialized
DEBUG - 2011-05-06 10:38:38 --> Output Class Initialized
DEBUG - 2011-05-06 10:38:38 --> Input Class Initialized
DEBUG - 2011-05-06 10:38:38 --> Global POST and COOKIE data sanitized
DEBUG - 2011-05-06 10:38:38 --> Language Class Initialized
DEBUG - 2011-05-06 10:38:38 --> Loader Class Initialized
DEBUG - 2011-05-06 10:38:38 --> Controller Class Initialized
ERROR - 2011-05-06 10:38:38 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-05-06 10:38:38 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-05-06 10:38:38 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-05-06 10:38:38 --> Model Class Initialized
DEBUG - 2011-05-06 10:38:38 --> Model Class Initialized
DEBUG - 2011-05-06 10:38:38 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-05-06 10:38:38 --> Database Driver Class Initialized
DEBUG - 2011-05-06 10:38:38 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-05-06 10:38:38 --> Helper loaded: url_helper
DEBUG - 2011-05-06 10:38:38 --> File loaded: application/views/common/header.php
DEBUG - 2011-05-06 10:38:38 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-05-06 10:38:38 --> File loaded: application/views/common/footer.php
DEBUG - 2011-05-06 10:38:38 --> File loaded: application/views/layout/main.php
DEBUG - 2011-05-06 10:38:38 --> Final output sent to browser
DEBUG - 2011-05-06 10:38:38 --> Total execution time: 0.0415
DEBUG - 2011-05-06 10:38:39 --> Config Class Initialized
DEBUG - 2011-05-06 10:38:39 --> Hooks Class Initialized
DEBUG - 2011-05-06 10:38:39 --> Utf8 Class Initialized
DEBUG - 2011-05-06 10:38:39 --> UTF-8 Support Enabled
DEBUG - 2011-05-06 10:38:39 --> URI Class Initialized
DEBUG - 2011-05-06 10:38:39 --> Router Class Initialized
DEBUG - 2011-05-06 10:38:39 --> Output Class Initialized
DEBUG - 2011-05-06 10:38:39 --> Input Class Initialized
DEBUG - 2011-05-06 10:38:39 --> Global POST and COOKIE data sanitized
DEBUG - 2011-05-06 10:38:39 --> Language Class Initialized
DEBUG - 2011-05-06 10:38:39 --> Loader Class Initialized
DEBUG - 2011-05-06 10:38:39 --> Controller Class Initialized
DEBUG - 2011-05-06 10:38:39 --> Model Class Initialized
DEBUG - 2011-05-06 10:38:39 --> Model Class Initialized
DEBUG - 2011-05-06 10:38:39 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-05-06 10:38:39 --> Database Driver Class Initialized
DEBUG - 2011-05-06 10:38:40 --> Final output sent to browser
DEBUG - 2011-05-06 10:38:40 --> Total execution time: 0.8545
DEBUG - 2011-05-06 10:38:40 --> Config Class Initialized
DEBUG - 2011-05-06 10:38:40 --> Hooks Class Initialized
DEBUG - 2011-05-06 10:38:40 --> Utf8 Class Initialized
DEBUG - 2011-05-06 10:38:40 --> UTF-8 Support Enabled
DEBUG - 2011-05-06 10:38:40 --> URI Class Initialized
DEBUG - 2011-05-06 10:38:40 --> Router Class Initialized
DEBUG - 2011-05-06 10:38:40 --> Output Class Initialized
DEBUG - 2011-05-06 10:38:40 --> Input Class Initialized
DEBUG - 2011-05-06 10:38:40 --> Global POST and COOKIE data sanitized
DEBUG - 2011-05-06 10:38:40 --> Language Class Initialized
DEBUG - 2011-05-06 10:38:40 --> Loader Class Initialized
DEBUG - 2011-05-06 10:38:40 --> Controller Class Initialized
ERROR - 2011-05-06 10:38:40 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-05-06 10:38:40 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-05-06 10:38:40 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-05-06 10:38:40 --> Model Class Initialized
DEBUG - 2011-05-06 10:38:40 --> Model Class Initialized
DEBUG - 2011-05-06 10:38:40 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-05-06 10:38:40 --> Database Driver Class Initialized
DEBUG - 2011-05-06 10:38:40 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-05-06 10:38:40 --> Helper loaded: url_helper
DEBUG - 2011-05-06 10:38:40 --> File loaded: application/views/common/header.php
DEBUG - 2011-05-06 10:38:40 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-05-06 10:38:40 --> File loaded: application/views/common/footer.php
DEBUG - 2011-05-06 10:38:40 --> File loaded: application/views/layout/main.php
DEBUG - 2011-05-06 10:38:40 --> Final output sent to browser
DEBUG - 2011-05-06 10:38:40 --> Total execution time: 0.0283
DEBUG - 2011-05-06 10:38:41 --> Config Class Initialized
DEBUG - 2011-05-06 10:38:41 --> Hooks Class Initialized
DEBUG - 2011-05-06 10:38:41 --> Utf8 Class Initialized
DEBUG - 2011-05-06 10:38:41 --> UTF-8 Support Enabled
DEBUG - 2011-05-06 10:38:41 --> URI Class Initialized
DEBUG - 2011-05-06 10:38:41 --> Router Class Initialized
ERROR - 2011-05-06 10:38:41 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-05-06 10:39:05 --> Config Class Initialized
DEBUG - 2011-05-06 10:39:05 --> Hooks Class Initialized
DEBUG - 2011-05-06 10:39:05 --> Utf8 Class Initialized
DEBUG - 2011-05-06 10:39:05 --> UTF-8 Support Enabled
DEBUG - 2011-05-06 10:39:05 --> URI Class Initialized
DEBUG - 2011-05-06 10:39:05 --> Router Class Initialized
DEBUG - 2011-05-06 10:39:05 --> Output Class Initialized
DEBUG - 2011-05-06 10:39:05 --> Input Class Initialized
DEBUG - 2011-05-06 10:39:05 --> Global POST and COOKIE data sanitized
DEBUG - 2011-05-06 10:39:05 --> Language Class Initialized
DEBUG - 2011-05-06 10:39:05 --> Loader Class Initialized
DEBUG - 2011-05-06 10:39:05 --> Controller Class Initialized
ERROR - 2011-05-06 10:39:05 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-05-06 10:39:05 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-05-06 10:39:05 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-05-06 10:39:05 --> Model Class Initialized
DEBUG - 2011-05-06 10:39:05 --> Model Class Initialized
DEBUG - 2011-05-06 10:39:05 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-05-06 10:39:05 --> Database Driver Class Initialized
DEBUG - 2011-05-06 10:39:05 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-05-06 10:39:05 --> Helper loaded: url_helper
DEBUG - 2011-05-06 10:39:05 --> File loaded: application/views/common/header.php
DEBUG - 2011-05-06 10:39:05 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-05-06 10:39:05 --> File loaded: application/views/common/footer.php
DEBUG - 2011-05-06 10:39:05 --> File loaded: application/views/layout/main.php
DEBUG - 2011-05-06 10:39:05 --> Final output sent to browser
DEBUG - 2011-05-06 10:39:05 --> Total execution time: 0.0647
DEBUG - 2011-05-06 10:39:05 --> Config Class Initialized
DEBUG - 2011-05-06 10:39:05 --> Hooks Class Initialized
DEBUG - 2011-05-06 10:39:05 --> Utf8 Class Initialized
DEBUG - 2011-05-06 10:39:05 --> UTF-8 Support Enabled
DEBUG - 2011-05-06 10:39:05 --> URI Class Initialized
DEBUG - 2011-05-06 10:39:05 --> Router Class Initialized
DEBUG - 2011-05-06 10:39:05 --> Output Class Initialized
DEBUG - 2011-05-06 10:39:05 --> Input Class Initialized
DEBUG - 2011-05-06 10:39:05 --> Global POST and COOKIE data sanitized
DEBUG - 2011-05-06 10:39:05 --> Language Class Initialized
DEBUG - 2011-05-06 10:39:05 --> Loader Class Initialized
DEBUG - 2011-05-06 10:39:05 --> Controller Class Initialized
DEBUG - 2011-05-06 10:39:05 --> Model Class Initialized
DEBUG - 2011-05-06 10:39:05 --> Model Class Initialized
DEBUG - 2011-05-06 10:39:05 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-05-06 10:39:05 --> Database Driver Class Initialized
DEBUG - 2011-05-06 10:39:06 --> Final output sent to browser
DEBUG - 2011-05-06 10:39:06 --> Total execution time: 1.0162
DEBUG - 2011-05-06 10:39:08 --> Config Class Initialized
DEBUG - 2011-05-06 10:39:08 --> Hooks Class Initialized
DEBUG - 2011-05-06 10:39:08 --> Utf8 Class Initialized
DEBUG - 2011-05-06 10:39:08 --> UTF-8 Support Enabled
DEBUG - 2011-05-06 10:39:08 --> URI Class Initialized
DEBUG - 2011-05-06 10:39:08 --> Router Class Initialized
ERROR - 2011-05-06 10:39:08 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-05-06 10:39:44 --> Config Class Initialized
DEBUG - 2011-05-06 10:39:44 --> Hooks Class Initialized
DEBUG - 2011-05-06 10:39:44 --> Utf8 Class Initialized
DEBUG - 2011-05-06 10:39:44 --> UTF-8 Support Enabled
DEBUG - 2011-05-06 10:39:44 --> URI Class Initialized
DEBUG - 2011-05-06 10:39:44 --> Router Class Initialized
DEBUG - 2011-05-06 10:39:44 --> Output Class Initialized
DEBUG - 2011-05-06 10:39:44 --> Input Class Initialized
DEBUG - 2011-05-06 10:39:44 --> Global POST and COOKIE data sanitized
DEBUG - 2011-05-06 10:39:44 --> Language Class Initialized
DEBUG - 2011-05-06 10:39:44 --> Loader Class Initialized
DEBUG - 2011-05-06 10:39:44 --> Controller Class Initialized
ERROR - 2011-05-06 10:39:44 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-05-06 10:39:44 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-05-06 10:39:44 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-05-06 10:39:44 --> Model Class Initialized
DEBUG - 2011-05-06 10:39:44 --> Model Class Initialized
DEBUG - 2011-05-06 10:39:44 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-05-06 10:39:44 --> Database Driver Class Initialized
DEBUG - 2011-05-06 10:39:44 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-05-06 10:39:44 --> Helper loaded: url_helper
DEBUG - 2011-05-06 10:39:44 --> File loaded: application/views/common/header.php
DEBUG - 2011-05-06 10:39:44 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-05-06 10:39:44 --> File loaded: application/views/common/footer.php
DEBUG - 2011-05-06 10:39:44 --> File loaded: application/views/layout/main.php
DEBUG - 2011-05-06 10:39:44 --> Final output sent to browser
DEBUG - 2011-05-06 10:39:44 --> Total execution time: 0.1374
DEBUG - 2011-05-06 10:39:45 --> Config Class Initialized
DEBUG - 2011-05-06 10:39:45 --> Hooks Class Initialized
DEBUG - 2011-05-06 10:39:45 --> Utf8 Class Initialized
DEBUG - 2011-05-06 10:39:45 --> UTF-8 Support Enabled
DEBUG - 2011-05-06 10:39:45 --> URI Class Initialized
DEBUG - 2011-05-06 10:39:45 --> Router Class Initialized
DEBUG - 2011-05-06 10:39:45 --> Output Class Initialized
DEBUG - 2011-05-06 10:39:45 --> Input Class Initialized
DEBUG - 2011-05-06 10:39:45 --> Global POST and COOKIE data sanitized
DEBUG - 2011-05-06 10:39:45 --> Language Class Initialized
DEBUG - 2011-05-06 10:39:45 --> Loader Class Initialized
DEBUG - 2011-05-06 10:39:45 --> Controller Class Initialized
DEBUG - 2011-05-06 10:39:45 --> Model Class Initialized
DEBUG - 2011-05-06 10:39:45 --> Model Class Initialized
DEBUG - 2011-05-06 10:39:45 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-05-06 10:39:45 --> Database Driver Class Initialized
DEBUG - 2011-05-06 10:39:45 --> Config Class Initialized
DEBUG - 2011-05-06 10:39:45 --> Hooks Class Initialized
DEBUG - 2011-05-06 10:39:45 --> Utf8 Class Initialized
DEBUG - 2011-05-06 10:39:45 --> UTF-8 Support Enabled
DEBUG - 2011-05-06 10:39:45 --> URI Class Initialized
DEBUG - 2011-05-06 10:39:45 --> Router Class Initialized
DEBUG - 2011-05-06 10:39:45 --> Output Class Initialized
DEBUG - 2011-05-06 10:39:45 --> Input Class Initialized
DEBUG - 2011-05-06 10:39:45 --> Global POST and COOKIE data sanitized
DEBUG - 2011-05-06 10:39:45 --> Language Class Initialized
DEBUG - 2011-05-06 10:39:45 --> Loader Class Initialized
DEBUG - 2011-05-06 10:39:45 --> Controller Class Initialized
ERROR - 2011-05-06 10:39:45 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-05-06 10:39:45 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-05-06 10:39:45 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-05-06 10:39:45 --> Model Class Initialized
DEBUG - 2011-05-06 10:39:45 --> Model Class Initialized
DEBUG - 2011-05-06 10:39:45 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-05-06 10:39:45 --> Database Driver Class Initialized
DEBUG - 2011-05-06 10:39:45 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-05-06 10:39:45 --> Helper loaded: url_helper
DEBUG - 2011-05-06 10:39:45 --> File loaded: application/views/common/header.php
DEBUG - 2011-05-06 10:39:45 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-05-06 10:39:45 --> File loaded: application/views/common/footer.php
DEBUG - 2011-05-06 10:39:45 --> File loaded: application/views/layout/main.php
DEBUG - 2011-05-06 10:39:45 --> Final output sent to browser
DEBUG - 2011-05-06 10:39:45 --> Total execution time: 0.0643
DEBUG - 2011-05-06 10:39:45 --> Final output sent to browser
DEBUG - 2011-05-06 10:39:45 --> Total execution time: 0.6780
DEBUG - 2011-05-06 10:39:47 --> Config Class Initialized
DEBUG - 2011-05-06 10:39:47 --> Hooks Class Initialized
DEBUG - 2011-05-06 10:39:47 --> Utf8 Class Initialized
DEBUG - 2011-05-06 10:39:47 --> UTF-8 Support Enabled
DEBUG - 2011-05-06 10:39:47 --> URI Class Initialized
DEBUG - 2011-05-06 10:39:47 --> Router Class Initialized
ERROR - 2011-05-06 10:39:47 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-05-06 10:39:53 --> Config Class Initialized
DEBUG - 2011-05-06 10:39:53 --> Hooks Class Initialized
DEBUG - 2011-05-06 10:39:53 --> Utf8 Class Initialized
DEBUG - 2011-05-06 10:39:53 --> UTF-8 Support Enabled
DEBUG - 2011-05-06 10:39:53 --> URI Class Initialized
DEBUG - 2011-05-06 10:39:53 --> Router Class Initialized
DEBUG - 2011-05-06 10:39:54 --> Output Class Initialized
DEBUG - 2011-05-06 10:39:54 --> Input Class Initialized
DEBUG - 2011-05-06 10:39:54 --> Global POST and COOKIE data sanitized
DEBUG - 2011-05-06 10:39:54 --> Language Class Initialized
DEBUG - 2011-05-06 10:39:54 --> Loader Class Initialized
DEBUG - 2011-05-06 10:39:54 --> Controller Class Initialized
ERROR - 2011-05-06 10:39:54 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-05-06 10:39:54 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-05-06 10:39:54 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-05-06 10:39:54 --> Model Class Initialized
DEBUG - 2011-05-06 10:39:54 --> Model Class Initialized
DEBUG - 2011-05-06 10:39:54 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-05-06 10:39:54 --> Database Driver Class Initialized
DEBUG - 2011-05-06 10:39:54 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-05-06 10:39:54 --> Helper loaded: url_helper
DEBUG - 2011-05-06 10:39:54 --> File loaded: application/views/common/header.php
DEBUG - 2011-05-06 10:39:54 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-05-06 10:39:54 --> File loaded: application/views/common/footer.php
DEBUG - 2011-05-06 10:39:54 --> File loaded: application/views/layout/main.php
DEBUG - 2011-05-06 10:39:54 --> Final output sent to browser
DEBUG - 2011-05-06 10:39:54 --> Total execution time: 0.0892
DEBUG - 2011-05-06 10:39:55 --> Config Class Initialized
DEBUG - 2011-05-06 10:39:55 --> Hooks Class Initialized
DEBUG - 2011-05-06 10:39:55 --> Utf8 Class Initialized
DEBUG - 2011-05-06 10:39:55 --> UTF-8 Support Enabled
DEBUG - 2011-05-06 10:39:55 --> URI Class Initialized
DEBUG - 2011-05-06 10:39:55 --> Router Class Initialized
DEBUG - 2011-05-06 10:39:55 --> Output Class Initialized
DEBUG - 2011-05-06 10:39:55 --> Input Class Initialized
DEBUG - 2011-05-06 10:39:55 --> Global POST and COOKIE data sanitized
DEBUG - 2011-05-06 10:39:55 --> Language Class Initialized
DEBUG - 2011-05-06 10:39:55 --> Loader Class Initialized
DEBUG - 2011-05-06 10:39:55 --> Controller Class Initialized
DEBUG - 2011-05-06 10:39:55 --> Model Class Initialized
DEBUG - 2011-05-06 10:39:55 --> Model Class Initialized
DEBUG - 2011-05-06 10:39:55 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-05-06 10:39:55 --> Database Driver Class Initialized
DEBUG - 2011-05-06 10:39:55 --> Config Class Initialized
DEBUG - 2011-05-06 10:39:55 --> Hooks Class Initialized
DEBUG - 2011-05-06 10:39:55 --> Utf8 Class Initialized
DEBUG - 2011-05-06 10:39:55 --> UTF-8 Support Enabled
DEBUG - 2011-05-06 10:39:55 --> URI Class Initialized
DEBUG - 2011-05-06 10:39:55 --> Router Class Initialized
DEBUG - 2011-05-06 10:39:55 --> Output Class Initialized
DEBUG - 2011-05-06 10:39:55 --> Input Class Initialized
DEBUG - 2011-05-06 10:39:55 --> Global POST and COOKIE data sanitized
DEBUG - 2011-05-06 10:39:55 --> Language Class Initialized
DEBUG - 2011-05-06 10:39:55 --> Loader Class Initialized
DEBUG - 2011-05-06 10:39:55 --> Controller Class Initialized
ERROR - 2011-05-06 10:39:55 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-05-06 10:39:55 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-05-06 10:39:55 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-05-06 10:39:55 --> Model Class Initialized
DEBUG - 2011-05-06 10:39:55 --> Model Class Initialized
DEBUG - 2011-05-06 10:39:55 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-05-06 10:39:55 --> Database Driver Class Initialized
DEBUG - 2011-05-06 10:39:55 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-05-06 10:39:55 --> Helper loaded: url_helper
DEBUG - 2011-05-06 10:39:55 --> File loaded: application/views/common/header.php
DEBUG - 2011-05-06 10:39:55 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-05-06 10:39:55 --> File loaded: application/views/common/footer.php
DEBUG - 2011-05-06 10:39:55 --> File loaded: application/views/layout/main.php
DEBUG - 2011-05-06 10:39:55 --> Final output sent to browser
DEBUG - 2011-05-06 10:39:55 --> Total execution time: 0.0774
DEBUG - 2011-05-06 10:39:56 --> Final output sent to browser
DEBUG - 2011-05-06 10:39:56 --> Total execution time: 1.2701
DEBUG - 2011-05-06 10:39:57 --> Config Class Initialized
DEBUG - 2011-05-06 10:39:57 --> Hooks Class Initialized
DEBUG - 2011-05-06 10:39:57 --> Utf8 Class Initialized
DEBUG - 2011-05-06 10:39:57 --> UTF-8 Support Enabled
DEBUG - 2011-05-06 10:39:57 --> URI Class Initialized
DEBUG - 2011-05-06 10:39:57 --> Router Class Initialized
ERROR - 2011-05-06 10:39:57 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-05-06 10:40:07 --> Config Class Initialized
DEBUG - 2011-05-06 10:40:07 --> Hooks Class Initialized
DEBUG - 2011-05-06 10:40:07 --> Utf8 Class Initialized
DEBUG - 2011-05-06 10:40:07 --> UTF-8 Support Enabled
DEBUG - 2011-05-06 10:40:07 --> URI Class Initialized
DEBUG - 2011-05-06 10:40:07 --> Router Class Initialized
DEBUG - 2011-05-06 10:40:07 --> Output Class Initialized
DEBUG - 2011-05-06 10:40:07 --> Input Class Initialized
DEBUG - 2011-05-06 10:40:07 --> Global POST and COOKIE data sanitized
DEBUG - 2011-05-06 10:40:07 --> Language Class Initialized
DEBUG - 2011-05-06 10:40:07 --> Loader Class Initialized
DEBUG - 2011-05-06 10:40:07 --> Controller Class Initialized
ERROR - 2011-05-06 10:40:07 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-05-06 10:40:07 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-05-06 10:40:07 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-05-06 10:40:07 --> Model Class Initialized
DEBUG - 2011-05-06 10:40:07 --> Model Class Initialized
DEBUG - 2011-05-06 10:40:07 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-05-06 10:40:07 --> Database Driver Class Initialized
DEBUG - 2011-05-06 10:40:07 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-05-06 10:40:07 --> Helper loaded: url_helper
DEBUG - 2011-05-06 10:40:07 --> File loaded: application/views/common/header.php
DEBUG - 2011-05-06 10:40:07 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-05-06 10:40:07 --> File loaded: application/views/common/footer.php
DEBUG - 2011-05-06 10:40:07 --> File loaded: application/views/layout/main.php
DEBUG - 2011-05-06 10:40:07 --> Final output sent to browser
DEBUG - 2011-05-06 10:40:07 --> Total execution time: 0.0755
DEBUG - 2011-05-06 10:40:07 --> Config Class Initialized
DEBUG - 2011-05-06 10:40:07 --> Hooks Class Initialized
DEBUG - 2011-05-06 10:40:07 --> Utf8 Class Initialized
DEBUG - 2011-05-06 10:40:07 --> UTF-8 Support Enabled
DEBUG - 2011-05-06 10:40:07 --> URI Class Initialized
DEBUG - 2011-05-06 10:40:07 --> Router Class Initialized
DEBUG - 2011-05-06 10:40:07 --> Output Class Initialized
DEBUG - 2011-05-06 10:40:07 --> Input Class Initialized
DEBUG - 2011-05-06 10:40:07 --> Global POST and COOKIE data sanitized
DEBUG - 2011-05-06 10:40:07 --> Language Class Initialized
DEBUG - 2011-05-06 10:40:07 --> Loader Class Initialized
DEBUG - 2011-05-06 10:40:07 --> Controller Class Initialized
DEBUG - 2011-05-06 10:40:07 --> Model Class Initialized
DEBUG - 2011-05-06 10:40:07 --> Model Class Initialized
DEBUG - 2011-05-06 10:40:07 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-05-06 10:40:07 --> Database Driver Class Initialized
DEBUG - 2011-05-06 10:40:08 --> Final output sent to browser
DEBUG - 2011-05-06 10:40:08 --> Total execution time: 0.6731
DEBUG - 2011-05-06 10:40:10 --> Config Class Initialized
DEBUG - 2011-05-06 10:40:10 --> Hooks Class Initialized
DEBUG - 2011-05-06 10:40:10 --> Utf8 Class Initialized
DEBUG - 2011-05-06 10:40:10 --> UTF-8 Support Enabled
DEBUG - 2011-05-06 10:40:10 --> URI Class Initialized
DEBUG - 2011-05-06 10:40:10 --> Router Class Initialized
ERROR - 2011-05-06 10:40:10 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-05-06 10:40:11 --> Config Class Initialized
DEBUG - 2011-05-06 10:40:11 --> Hooks Class Initialized
DEBUG - 2011-05-06 10:40:11 --> Utf8 Class Initialized
DEBUG - 2011-05-06 10:40:11 --> UTF-8 Support Enabled
DEBUG - 2011-05-06 10:40:11 --> URI Class Initialized
DEBUG - 2011-05-06 10:40:11 --> Router Class Initialized
DEBUG - 2011-05-06 10:40:11 --> Output Class Initialized
DEBUG - 2011-05-06 10:40:11 --> Input Class Initialized
DEBUG - 2011-05-06 10:40:11 --> Global POST and COOKIE data sanitized
DEBUG - 2011-05-06 10:40:11 --> Language Class Initialized
DEBUG - 2011-05-06 10:40:11 --> Loader Class Initialized
DEBUG - 2011-05-06 10:40:11 --> Controller Class Initialized
ERROR - 2011-05-06 10:40:11 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-05-06 10:40:11 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-05-06 10:40:11 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-05-06 10:40:11 --> Model Class Initialized
DEBUG - 2011-05-06 10:40:11 --> Model Class Initialized
DEBUG - 2011-05-06 10:40:11 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-05-06 10:40:11 --> Database Driver Class Initialized
DEBUG - 2011-05-06 10:40:11 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-05-06 10:40:11 --> Helper loaded: url_helper
DEBUG - 2011-05-06 10:40:11 --> File loaded: application/views/common/header.php
DEBUG - 2011-05-06 10:40:11 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-05-06 10:40:11 --> File loaded: application/views/common/footer.php
DEBUG - 2011-05-06 10:40:11 --> File loaded: application/views/layout/main.php
DEBUG - 2011-05-06 10:40:11 --> Final output sent to browser
DEBUG - 2011-05-06 10:40:11 --> Total execution time: 0.0334
DEBUG - 2011-05-06 10:41:13 --> Config Class Initialized
DEBUG - 2011-05-06 10:41:13 --> Hooks Class Initialized
DEBUG - 2011-05-06 10:41:13 --> Utf8 Class Initialized
DEBUG - 2011-05-06 10:41:13 --> UTF-8 Support Enabled
DEBUG - 2011-05-06 10:41:13 --> URI Class Initialized
DEBUG - 2011-05-06 10:41:13 --> Router Class Initialized
DEBUG - 2011-05-06 10:41:13 --> Output Class Initialized
DEBUG - 2011-05-06 10:41:13 --> Input Class Initialized
DEBUG - 2011-05-06 10:41:13 --> Global POST and COOKIE data sanitized
DEBUG - 2011-05-06 10:41:13 --> Language Class Initialized
DEBUG - 2011-05-06 10:41:13 --> Loader Class Initialized
DEBUG - 2011-05-06 10:41:13 --> Controller Class Initialized
ERROR - 2011-05-06 10:41:13 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-05-06 10:41:13 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-05-06 10:41:13 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-05-06 10:41:13 --> Model Class Initialized
DEBUG - 2011-05-06 10:41:13 --> Model Class Initialized
DEBUG - 2011-05-06 10:41:13 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-05-06 10:41:13 --> Database Driver Class Initialized
DEBUG - 2011-05-06 10:41:13 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-05-06 10:41:13 --> Helper loaded: url_helper
DEBUG - 2011-05-06 10:41:13 --> File loaded: application/views/common/header.php
DEBUG - 2011-05-06 10:41:13 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-05-06 10:41:13 --> File loaded: application/views/common/footer.php
DEBUG - 2011-05-06 10:41:13 --> File loaded: application/views/layout/main.php
DEBUG - 2011-05-06 10:41:13 --> Final output sent to browser
DEBUG - 2011-05-06 10:41:13 --> Total execution time: 0.0923
DEBUG - 2011-05-06 10:41:14 --> Config Class Initialized
DEBUG - 2011-05-06 10:41:14 --> Hooks Class Initialized
DEBUG - 2011-05-06 10:41:14 --> Utf8 Class Initialized
DEBUG - 2011-05-06 10:41:14 --> UTF-8 Support Enabled
DEBUG - 2011-05-06 10:41:14 --> URI Class Initialized
DEBUG - 2011-05-06 10:41:14 --> Router Class Initialized
DEBUG - 2011-05-06 10:41:14 --> Output Class Initialized
DEBUG - 2011-05-06 10:41:14 --> Input Class Initialized
DEBUG - 2011-05-06 10:41:14 --> Global POST and COOKIE data sanitized
DEBUG - 2011-05-06 10:41:14 --> Language Class Initialized
DEBUG - 2011-05-06 10:41:14 --> Loader Class Initialized
DEBUG - 2011-05-06 10:41:14 --> Controller Class Initialized
DEBUG - 2011-05-06 10:41:14 --> Model Class Initialized
DEBUG - 2011-05-06 10:41:14 --> Model Class Initialized
DEBUG - 2011-05-06 10:41:14 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-05-06 10:41:14 --> Database Driver Class Initialized
DEBUG - 2011-05-06 10:41:15 --> Final output sent to browser
DEBUG - 2011-05-06 10:41:15 --> Total execution time: 1.0130
DEBUG - 2011-05-06 10:41:17 --> Config Class Initialized
DEBUG - 2011-05-06 10:41:17 --> Hooks Class Initialized
DEBUG - 2011-05-06 10:41:17 --> Utf8 Class Initialized
DEBUG - 2011-05-06 10:41:17 --> UTF-8 Support Enabled
DEBUG - 2011-05-06 10:41:17 --> URI Class Initialized
DEBUG - 2011-05-06 10:41:17 --> Router Class Initialized
ERROR - 2011-05-06 10:41:17 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-05-06 10:41:33 --> Config Class Initialized
DEBUG - 2011-05-06 10:41:33 --> Hooks Class Initialized
DEBUG - 2011-05-06 10:41:33 --> Utf8 Class Initialized
DEBUG - 2011-05-06 10:41:33 --> UTF-8 Support Enabled
DEBUG - 2011-05-06 10:41:33 --> URI Class Initialized
DEBUG - 2011-05-06 10:41:33 --> Router Class Initialized
DEBUG - 2011-05-06 10:41:33 --> Output Class Initialized
DEBUG - 2011-05-06 10:41:33 --> Input Class Initialized
DEBUG - 2011-05-06 10:41:33 --> Global POST and COOKIE data sanitized
DEBUG - 2011-05-06 10:41:33 --> Language Class Initialized
DEBUG - 2011-05-06 10:41:33 --> Loader Class Initialized
DEBUG - 2011-05-06 10:41:33 --> Controller Class Initialized
ERROR - 2011-05-06 10:41:33 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-05-06 10:41:33 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-05-06 10:41:33 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-05-06 10:41:33 --> Model Class Initialized
DEBUG - 2011-05-06 10:41:33 --> Model Class Initialized
DEBUG - 2011-05-06 10:41:33 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-05-06 10:41:33 --> Database Driver Class Initialized
DEBUG - 2011-05-06 10:41:33 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-05-06 10:41:33 --> Helper loaded: url_helper
DEBUG - 2011-05-06 10:41:33 --> File loaded: application/views/common/header.php
DEBUG - 2011-05-06 10:41:33 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-05-06 10:41:33 --> File loaded: application/views/common/footer.php
DEBUG - 2011-05-06 10:41:33 --> File loaded: application/views/layout/main.php
DEBUG - 2011-05-06 10:41:33 --> Final output sent to browser
DEBUG - 2011-05-06 10:41:33 --> Total execution time: 0.0296
DEBUG - 2011-05-06 10:41:34 --> Config Class Initialized
DEBUG - 2011-05-06 10:41:34 --> Hooks Class Initialized
DEBUG - 2011-05-06 10:41:34 --> Utf8 Class Initialized
DEBUG - 2011-05-06 10:41:34 --> UTF-8 Support Enabled
DEBUG - 2011-05-06 10:41:34 --> URI Class Initialized
DEBUG - 2011-05-06 10:41:34 --> Router Class Initialized
DEBUG - 2011-05-06 10:41:34 --> Output Class Initialized
DEBUG - 2011-05-06 10:41:34 --> Input Class Initialized
DEBUG - 2011-05-06 10:41:34 --> Global POST and COOKIE data sanitized
DEBUG - 2011-05-06 10:41:34 --> Language Class Initialized
DEBUG - 2011-05-06 10:41:34 --> Loader Class Initialized
DEBUG - 2011-05-06 10:41:34 --> Controller Class Initialized
DEBUG - 2011-05-06 10:41:34 --> Model Class Initialized
DEBUG - 2011-05-06 10:41:34 --> Model Class Initialized
DEBUG - 2011-05-06 10:41:34 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-05-06 10:41:34 --> Database Driver Class Initialized
DEBUG - 2011-05-06 10:41:35 --> Final output sent to browser
DEBUG - 2011-05-06 10:41:35 --> Total execution time: 0.7212
DEBUG - 2011-05-06 10:41:36 --> Config Class Initialized
DEBUG - 2011-05-06 10:41:36 --> Hooks Class Initialized
DEBUG - 2011-05-06 10:41:36 --> Utf8 Class Initialized
DEBUG - 2011-05-06 10:41:36 --> UTF-8 Support Enabled
DEBUG - 2011-05-06 10:41:36 --> URI Class Initialized
DEBUG - 2011-05-06 10:41:36 --> Router Class Initialized
ERROR - 2011-05-06 10:41:36 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-05-06 10:41:39 --> Config Class Initialized
DEBUG - 2011-05-06 10:41:39 --> Hooks Class Initialized
DEBUG - 2011-05-06 10:41:39 --> Utf8 Class Initialized
DEBUG - 2011-05-06 10:41:39 --> UTF-8 Support Enabled
DEBUG - 2011-05-06 10:41:39 --> URI Class Initialized
DEBUG - 2011-05-06 10:41:39 --> Router Class Initialized
DEBUG - 2011-05-06 10:41:39 --> Output Class Initialized
DEBUG - 2011-05-06 10:41:39 --> Input Class Initialized
DEBUG - 2011-05-06 10:41:39 --> Global POST and COOKIE data sanitized
DEBUG - 2011-05-06 10:41:39 --> Language Class Initialized
DEBUG - 2011-05-06 10:41:39 --> Loader Class Initialized
DEBUG - 2011-05-06 10:41:39 --> Controller Class Initialized
ERROR - 2011-05-06 10:41:39 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-05-06 10:41:39 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-05-06 10:41:39 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-05-06 10:41:39 --> Model Class Initialized
DEBUG - 2011-05-06 10:41:39 --> Model Class Initialized
DEBUG - 2011-05-06 10:41:39 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-05-06 10:41:39 --> Database Driver Class Initialized
DEBUG - 2011-05-06 10:41:39 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-05-06 10:41:39 --> Helper loaded: url_helper
DEBUG - 2011-05-06 10:41:39 --> File loaded: application/views/common/header.php
DEBUG - 2011-05-06 10:41:39 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-05-06 10:41:39 --> File loaded: application/views/common/footer.php
DEBUG - 2011-05-06 10:41:39 --> File loaded: application/views/layout/main.php
DEBUG - 2011-05-06 10:41:39 --> Final output sent to browser
DEBUG - 2011-05-06 10:41:39 --> Total execution time: 0.0370
DEBUG - 2011-05-06 10:41:53 --> Config Class Initialized
DEBUG - 2011-05-06 10:41:53 --> Hooks Class Initialized
DEBUG - 2011-05-06 10:41:53 --> Utf8 Class Initialized
DEBUG - 2011-05-06 10:41:53 --> UTF-8 Support Enabled
DEBUG - 2011-05-06 10:41:53 --> URI Class Initialized
DEBUG - 2011-05-06 10:41:53 --> Router Class Initialized
DEBUG - 2011-05-06 10:41:53 --> Output Class Initialized
DEBUG - 2011-05-06 10:41:53 --> Input Class Initialized
DEBUG - 2011-05-06 10:41:53 --> Global POST and COOKIE data sanitized
DEBUG - 2011-05-06 10:41:53 --> Language Class Initialized
DEBUG - 2011-05-06 10:41:53 --> Loader Class Initialized
DEBUG - 2011-05-06 10:41:53 --> Controller Class Initialized
ERROR - 2011-05-06 10:41:53 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-05-06 10:41:53 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-05-06 10:41:53 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-05-06 10:41:53 --> Model Class Initialized
DEBUG - 2011-05-06 10:41:53 --> Model Class Initialized
DEBUG - 2011-05-06 10:41:53 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-05-06 10:41:53 --> Database Driver Class Initialized
DEBUG - 2011-05-06 10:41:53 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-05-06 10:41:53 --> Helper loaded: url_helper
DEBUG - 2011-05-06 10:41:53 --> File loaded: application/views/common/header.php
DEBUG - 2011-05-06 10:41:53 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-05-06 10:41:53 --> File loaded: application/views/common/footer.php
DEBUG - 2011-05-06 10:41:53 --> File loaded: application/views/layout/main.php
DEBUG - 2011-05-06 10:41:53 --> Final output sent to browser
DEBUG - 2011-05-06 10:41:53 --> Total execution time: 0.0326
DEBUG - 2011-05-06 10:41:54 --> Config Class Initialized
DEBUG - 2011-05-06 10:41:54 --> Hooks Class Initialized
DEBUG - 2011-05-06 10:41:54 --> Utf8 Class Initialized
DEBUG - 2011-05-06 10:41:54 --> UTF-8 Support Enabled
DEBUG - 2011-05-06 10:41:54 --> URI Class Initialized
DEBUG - 2011-05-06 10:41:54 --> Router Class Initialized
DEBUG - 2011-05-06 10:41:54 --> Output Class Initialized
DEBUG - 2011-05-06 10:41:54 --> Input Class Initialized
DEBUG - 2011-05-06 10:41:54 --> Global POST and COOKIE data sanitized
DEBUG - 2011-05-06 10:41:54 --> Language Class Initialized
DEBUG - 2011-05-06 10:41:54 --> Loader Class Initialized
DEBUG - 2011-05-06 10:41:54 --> Controller Class Initialized
DEBUG - 2011-05-06 10:41:54 --> Model Class Initialized
DEBUG - 2011-05-06 10:41:54 --> Model Class Initialized
DEBUG - 2011-05-06 10:41:54 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-05-06 10:41:54 --> Database Driver Class Initialized
DEBUG - 2011-05-06 10:41:54 --> Config Class Initialized
DEBUG - 2011-05-06 10:41:54 --> Hooks Class Initialized
DEBUG - 2011-05-06 10:41:54 --> Utf8 Class Initialized
DEBUG - 2011-05-06 10:41:54 --> UTF-8 Support Enabled
DEBUG - 2011-05-06 10:41:54 --> URI Class Initialized
DEBUG - 2011-05-06 10:41:54 --> Router Class Initialized
DEBUG - 2011-05-06 10:41:54 --> Output Class Initialized
DEBUG - 2011-05-06 10:41:54 --> Input Class Initialized
DEBUG - 2011-05-06 10:41:54 --> Global POST and COOKIE data sanitized
DEBUG - 2011-05-06 10:41:54 --> Language Class Initialized
DEBUG - 2011-05-06 10:41:54 --> Loader Class Initialized
DEBUG - 2011-05-06 10:41:54 --> Controller Class Initialized
ERROR - 2011-05-06 10:41:54 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-05-06 10:41:54 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-05-06 10:41:54 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-05-06 10:41:54 --> Model Class Initialized
DEBUG - 2011-05-06 10:41:54 --> Model Class Initialized
DEBUG - 2011-05-06 10:41:54 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-05-06 10:41:54 --> Database Driver Class Initialized
DEBUG - 2011-05-06 10:41:54 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-05-06 10:41:54 --> Helper loaded: url_helper
DEBUG - 2011-05-06 10:41:54 --> File loaded: application/views/common/header.php
DEBUG - 2011-05-06 10:41:54 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-05-06 10:41:54 --> File loaded: application/views/common/footer.php
DEBUG - 2011-05-06 10:41:54 --> File loaded: application/views/layout/main.php
DEBUG - 2011-05-06 10:41:54 --> Final output sent to browser
DEBUG - 2011-05-06 10:41:54 --> Total execution time: 0.0720
DEBUG - 2011-05-06 10:41:54 --> Final output sent to browser
DEBUG - 2011-05-06 10:41:54 --> Total execution time: 0.6269
DEBUG - 2011-05-06 10:41:56 --> Config Class Initialized
DEBUG - 2011-05-06 10:41:56 --> Hooks Class Initialized
DEBUG - 2011-05-06 10:41:56 --> Utf8 Class Initialized
DEBUG - 2011-05-06 10:41:56 --> UTF-8 Support Enabled
DEBUG - 2011-05-06 10:41:56 --> URI Class Initialized
DEBUG - 2011-05-06 10:41:56 --> Router Class Initialized
ERROR - 2011-05-06 10:41:56 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-05-06 10:42:03 --> Config Class Initialized
DEBUG - 2011-05-06 10:42:03 --> Hooks Class Initialized
DEBUG - 2011-05-06 10:42:03 --> Utf8 Class Initialized
DEBUG - 2011-05-06 10:42:03 --> UTF-8 Support Enabled
DEBUG - 2011-05-06 10:42:03 --> URI Class Initialized
DEBUG - 2011-05-06 10:42:03 --> Router Class Initialized
DEBUG - 2011-05-06 10:42:03 --> Output Class Initialized
DEBUG - 2011-05-06 10:42:03 --> Input Class Initialized
DEBUG - 2011-05-06 10:42:03 --> Global POST and COOKIE data sanitized
DEBUG - 2011-05-06 10:42:03 --> Language Class Initialized
DEBUG - 2011-05-06 10:42:03 --> Loader Class Initialized
DEBUG - 2011-05-06 10:42:03 --> Controller Class Initialized
ERROR - 2011-05-06 10:42:03 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-05-06 10:42:03 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-05-06 10:42:03 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-05-06 10:42:03 --> Model Class Initialized
DEBUG - 2011-05-06 10:42:03 --> Model Class Initialized
DEBUG - 2011-05-06 10:42:03 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-05-06 10:42:03 --> Database Driver Class Initialized
DEBUG - 2011-05-06 10:42:03 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-05-06 10:42:03 --> Helper loaded: url_helper
DEBUG - 2011-05-06 10:42:03 --> File loaded: application/views/common/header.php
DEBUG - 2011-05-06 10:42:03 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-05-06 10:42:03 --> File loaded: application/views/common/footer.php
DEBUG - 2011-05-06 10:42:03 --> File loaded: application/views/layout/main.php
DEBUG - 2011-05-06 10:42:03 --> Final output sent to browser
DEBUG - 2011-05-06 10:42:03 --> Total execution time: 0.0453
DEBUG - 2011-05-06 10:42:04 --> Config Class Initialized
DEBUG - 2011-05-06 10:42:04 --> Hooks Class Initialized
DEBUG - 2011-05-06 10:42:04 --> Utf8 Class Initialized
DEBUG - 2011-05-06 10:42:04 --> UTF-8 Support Enabled
DEBUG - 2011-05-06 10:42:04 --> URI Class Initialized
DEBUG - 2011-05-06 10:42:04 --> Router Class Initialized
DEBUG - 2011-05-06 10:42:04 --> Output Class Initialized
DEBUG - 2011-05-06 10:42:04 --> Input Class Initialized
DEBUG - 2011-05-06 10:42:04 --> Global POST and COOKIE data sanitized
DEBUG - 2011-05-06 10:42:04 --> Language Class Initialized
DEBUG - 2011-05-06 10:42:04 --> Loader Class Initialized
DEBUG - 2011-05-06 10:42:04 --> Controller Class Initialized
DEBUG - 2011-05-06 10:42:04 --> Model Class Initialized
DEBUG - 2011-05-06 10:42:04 --> Model Class Initialized
DEBUG - 2011-05-06 10:42:04 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-05-06 10:42:04 --> Database Driver Class Initialized
DEBUG - 2011-05-06 10:42:05 --> Final output sent to browser
DEBUG - 2011-05-06 10:42:05 --> Total execution time: 0.5346
DEBUG - 2011-05-06 10:42:06 --> Config Class Initialized
DEBUG - 2011-05-06 10:42:06 --> Hooks Class Initialized
DEBUG - 2011-05-06 10:42:06 --> Utf8 Class Initialized
DEBUG - 2011-05-06 10:42:06 --> UTF-8 Support Enabled
DEBUG - 2011-05-06 10:42:06 --> URI Class Initialized
DEBUG - 2011-05-06 10:42:06 --> Router Class Initialized
ERROR - 2011-05-06 10:42:06 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-05-06 10:42:08 --> Config Class Initialized
DEBUG - 2011-05-06 10:42:08 --> Hooks Class Initialized
DEBUG - 2011-05-06 10:42:08 --> Utf8 Class Initialized
DEBUG - 2011-05-06 10:42:08 --> UTF-8 Support Enabled
DEBUG - 2011-05-06 10:42:08 --> URI Class Initialized
DEBUG - 2011-05-06 10:42:08 --> Router Class Initialized
DEBUG - 2011-05-06 10:42:08 --> Output Class Initialized
DEBUG - 2011-05-06 10:42:08 --> Input Class Initialized
DEBUG - 2011-05-06 10:42:08 --> Global POST and COOKIE data sanitized
DEBUG - 2011-05-06 10:42:08 --> Language Class Initialized
DEBUG - 2011-05-06 10:42:08 --> Loader Class Initialized
DEBUG - 2011-05-06 10:42:08 --> Controller Class Initialized
ERROR - 2011-05-06 10:42:08 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-05-06 10:42:08 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-05-06 10:42:08 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-05-06 10:42:08 --> Model Class Initialized
DEBUG - 2011-05-06 10:42:08 --> Model Class Initialized
DEBUG - 2011-05-06 10:42:08 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-05-06 10:42:08 --> Database Driver Class Initialized
DEBUG - 2011-05-06 10:42:08 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-05-06 10:42:08 --> Helper loaded: url_helper
DEBUG - 2011-05-06 10:42:08 --> File loaded: application/views/common/header.php
DEBUG - 2011-05-06 10:42:08 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-05-06 10:42:08 --> File loaded: application/views/common/footer.php
DEBUG - 2011-05-06 10:42:08 --> File loaded: application/views/layout/main.php
DEBUG - 2011-05-06 10:42:08 --> Final output sent to browser
DEBUG - 2011-05-06 10:42:08 --> Total execution time: 0.0721
DEBUG - 2011-05-06 10:42:46 --> Config Class Initialized
DEBUG - 2011-05-06 10:42:46 --> Hooks Class Initialized
DEBUG - 2011-05-06 10:42:46 --> Utf8 Class Initialized
DEBUG - 2011-05-06 10:42:46 --> UTF-8 Support Enabled
DEBUG - 2011-05-06 10:42:46 --> URI Class Initialized
DEBUG - 2011-05-06 10:42:46 --> Router Class Initialized
DEBUG - 2011-05-06 10:42:46 --> Output Class Initialized
DEBUG - 2011-05-06 10:42:46 --> Input Class Initialized
DEBUG - 2011-05-06 10:42:46 --> Global POST and COOKIE data sanitized
DEBUG - 2011-05-06 10:42:46 --> Language Class Initialized
DEBUG - 2011-05-06 10:42:46 --> Loader Class Initialized
DEBUG - 2011-05-06 10:42:46 --> Controller Class Initialized
ERROR - 2011-05-06 10:42:46 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-05-06 10:42:46 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-05-06 10:42:46 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-05-06 10:42:46 --> Model Class Initialized
DEBUG - 2011-05-06 10:42:46 --> Model Class Initialized
DEBUG - 2011-05-06 10:42:46 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-05-06 10:42:46 --> Database Driver Class Initialized
DEBUG - 2011-05-06 10:42:46 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-05-06 10:42:46 --> Helper loaded: url_helper
DEBUG - 2011-05-06 10:42:46 --> File loaded: application/views/common/header.php
DEBUG - 2011-05-06 10:42:46 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-05-06 10:42:46 --> File loaded: application/views/common/footer.php
DEBUG - 2011-05-06 10:42:46 --> File loaded: application/views/layout/main.php
DEBUG - 2011-05-06 10:42:46 --> Final output sent to browser
DEBUG - 2011-05-06 10:42:46 --> Total execution time: 0.0549
DEBUG - 2011-05-06 10:42:47 --> Config Class Initialized
DEBUG - 2011-05-06 10:42:47 --> Hooks Class Initialized
DEBUG - 2011-05-06 10:42:47 --> Utf8 Class Initialized
DEBUG - 2011-05-06 10:42:47 --> UTF-8 Support Enabled
DEBUG - 2011-05-06 10:42:47 --> URI Class Initialized
DEBUG - 2011-05-06 10:42:47 --> Router Class Initialized
DEBUG - 2011-05-06 10:42:47 --> Output Class Initialized
DEBUG - 2011-05-06 10:42:47 --> Input Class Initialized
DEBUG - 2011-05-06 10:42:47 --> Global POST and COOKIE data sanitized
DEBUG - 2011-05-06 10:42:47 --> Language Class Initialized
DEBUG - 2011-05-06 10:42:47 --> Loader Class Initialized
DEBUG - 2011-05-06 10:42:47 --> Controller Class Initialized
DEBUG - 2011-05-06 10:42:47 --> Model Class Initialized
DEBUG - 2011-05-06 10:42:47 --> Model Class Initialized
DEBUG - 2011-05-06 10:42:47 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-05-06 10:42:47 --> Database Driver Class Initialized
DEBUG - 2011-05-06 10:42:47 --> Final output sent to browser
DEBUG - 2011-05-06 10:42:47 --> Total execution time: 0.5422
DEBUG - 2011-05-06 10:42:49 --> Config Class Initialized
DEBUG - 2011-05-06 10:42:49 --> Hooks Class Initialized
DEBUG - 2011-05-06 10:42:49 --> Utf8 Class Initialized
DEBUG - 2011-05-06 10:42:49 --> UTF-8 Support Enabled
DEBUG - 2011-05-06 10:42:49 --> URI Class Initialized
DEBUG - 2011-05-06 10:42:49 --> Router Class Initialized
ERROR - 2011-05-06 10:42:49 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-05-06 10:43:01 --> Config Class Initialized
DEBUG - 2011-05-06 10:43:01 --> Hooks Class Initialized
DEBUG - 2011-05-06 10:43:01 --> Utf8 Class Initialized
DEBUG - 2011-05-06 10:43:01 --> UTF-8 Support Enabled
DEBUG - 2011-05-06 10:43:01 --> URI Class Initialized
DEBUG - 2011-05-06 10:43:01 --> Router Class Initialized
DEBUG - 2011-05-06 10:43:01 --> Output Class Initialized
DEBUG - 2011-05-06 10:43:01 --> Input Class Initialized
DEBUG - 2011-05-06 10:43:01 --> Global POST and COOKIE data sanitized
DEBUG - 2011-05-06 10:43:01 --> Language Class Initialized
DEBUG - 2011-05-06 10:43:01 --> Loader Class Initialized
DEBUG - 2011-05-06 10:43:01 --> Controller Class Initialized
ERROR - 2011-05-06 10:43:01 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-05-06 10:43:01 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-05-06 10:43:01 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-05-06 10:43:01 --> Model Class Initialized
DEBUG - 2011-05-06 10:43:01 --> Model Class Initialized
DEBUG - 2011-05-06 10:43:01 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-05-06 10:43:01 --> Database Driver Class Initialized
DEBUG - 2011-05-06 10:43:01 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-05-06 10:43:01 --> Helper loaded: url_helper
DEBUG - 2011-05-06 10:43:01 --> File loaded: application/views/common/header.php
DEBUG - 2011-05-06 10:43:01 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-05-06 10:43:01 --> File loaded: application/views/common/footer.php
DEBUG - 2011-05-06 10:43:01 --> File loaded: application/views/layout/main.php
DEBUG - 2011-05-06 10:43:01 --> Final output sent to browser
DEBUG - 2011-05-06 10:43:01 --> Total execution time: 0.0608
DEBUG - 2011-05-06 10:43:02 --> Config Class Initialized
DEBUG - 2011-05-06 10:43:02 --> Hooks Class Initialized
DEBUG - 2011-05-06 10:43:02 --> Utf8 Class Initialized
DEBUG - 2011-05-06 10:43:02 --> UTF-8 Support Enabled
DEBUG - 2011-05-06 10:43:02 --> URI Class Initialized
DEBUG - 2011-05-06 10:43:02 --> Router Class Initialized
DEBUG - 2011-05-06 10:43:02 --> Output Class Initialized
DEBUG - 2011-05-06 10:43:02 --> Input Class Initialized
DEBUG - 2011-05-06 10:43:02 --> Global POST and COOKIE data sanitized
DEBUG - 2011-05-06 10:43:02 --> Language Class Initialized
DEBUG - 2011-05-06 10:43:02 --> Loader Class Initialized
DEBUG - 2011-05-06 10:43:02 --> Controller Class Initialized
DEBUG - 2011-05-06 10:43:02 --> Model Class Initialized
DEBUG - 2011-05-06 10:43:02 --> Model Class Initialized
DEBUG - 2011-05-06 10:43:02 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-05-06 10:43:02 --> Database Driver Class Initialized
DEBUG - 2011-05-06 10:43:04 --> Final output sent to browser
DEBUG - 2011-05-06 10:43:04 --> Total execution time: 1.4336
DEBUG - 2011-05-06 10:43:05 --> Config Class Initialized
DEBUG - 2011-05-06 10:43:05 --> Hooks Class Initialized
DEBUG - 2011-05-06 10:43:05 --> Utf8 Class Initialized
DEBUG - 2011-05-06 10:43:05 --> UTF-8 Support Enabled
DEBUG - 2011-05-06 10:43:05 --> URI Class Initialized
DEBUG - 2011-05-06 10:43:05 --> Router Class Initialized
ERROR - 2011-05-06 10:43:05 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-05-06 11:18:15 --> Config Class Initialized
DEBUG - 2011-05-06 11:18:15 --> Hooks Class Initialized
DEBUG - 2011-05-06 11:18:15 --> Utf8 Class Initialized
DEBUG - 2011-05-06 11:18:15 --> UTF-8 Support Enabled
DEBUG - 2011-05-06 11:18:15 --> URI Class Initialized
DEBUG - 2011-05-06 11:18:15 --> Router Class Initialized
DEBUG - 2011-05-06 11:18:15 --> Output Class Initialized
DEBUG - 2011-05-06 11:18:15 --> Input Class Initialized
DEBUG - 2011-05-06 11:18:15 --> Global POST and COOKIE data sanitized
DEBUG - 2011-05-06 11:18:15 --> Language Class Initialized
DEBUG - 2011-05-06 11:18:15 --> Loader Class Initialized
DEBUG - 2011-05-06 11:18:15 --> Controller Class Initialized
ERROR - 2011-05-06 11:18:15 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-05-06 11:18:15 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-05-06 11:18:15 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-05-06 11:18:15 --> Model Class Initialized
DEBUG - 2011-05-06 11:18:15 --> Model Class Initialized
DEBUG - 2011-05-06 11:18:15 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-05-06 11:18:15 --> Database Driver Class Initialized
DEBUG - 2011-05-06 11:18:15 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-05-06 11:18:15 --> Helper loaded: url_helper
DEBUG - 2011-05-06 11:18:15 --> File loaded: application/views/common/header.php
DEBUG - 2011-05-06 11:18:15 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-05-06 11:18:15 --> File loaded: application/views/common/footer.php
DEBUG - 2011-05-06 11:18:15 --> File loaded: application/views/layout/main.php
DEBUG - 2011-05-06 11:18:15 --> Final output sent to browser
DEBUG - 2011-05-06 11:18:15 --> Total execution time: 0.3564
DEBUG - 2011-05-06 11:18:16 --> Config Class Initialized
DEBUG - 2011-05-06 11:18:16 --> Hooks Class Initialized
DEBUG - 2011-05-06 11:18:16 --> Utf8 Class Initialized
DEBUG - 2011-05-06 11:18:16 --> UTF-8 Support Enabled
DEBUG - 2011-05-06 11:18:16 --> URI Class Initialized
DEBUG - 2011-05-06 11:18:16 --> Router Class Initialized
DEBUG - 2011-05-06 11:18:16 --> Output Class Initialized
DEBUG - 2011-05-06 11:18:16 --> Input Class Initialized
DEBUG - 2011-05-06 11:18:16 --> Global POST and COOKIE data sanitized
DEBUG - 2011-05-06 11:18:16 --> Language Class Initialized
DEBUG - 2011-05-06 11:18:16 --> Loader Class Initialized
DEBUG - 2011-05-06 11:18:16 --> Controller Class Initialized
DEBUG - 2011-05-06 11:18:16 --> Model Class Initialized
DEBUG - 2011-05-06 11:18:16 --> Model Class Initialized
DEBUG - 2011-05-06 11:18:16 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-05-06 11:18:16 --> Database Driver Class Initialized
DEBUG - 2011-05-06 11:18:17 --> Final output sent to browser
DEBUG - 2011-05-06 11:18:17 --> Total execution time: 0.8526
DEBUG - 2011-05-06 11:18:18 --> Config Class Initialized
DEBUG - 2011-05-06 11:18:18 --> Hooks Class Initialized
DEBUG - 2011-05-06 11:18:18 --> Utf8 Class Initialized
DEBUG - 2011-05-06 11:18:18 --> UTF-8 Support Enabled
DEBUG - 2011-05-06 11:18:18 --> URI Class Initialized
DEBUG - 2011-05-06 11:18:18 --> Router Class Initialized
ERROR - 2011-05-06 11:18:18 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-05-06 11:19:14 --> Config Class Initialized
DEBUG - 2011-05-06 11:19:14 --> Hooks Class Initialized
DEBUG - 2011-05-06 11:19:14 --> Utf8 Class Initialized
DEBUG - 2011-05-06 11:19:14 --> UTF-8 Support Enabled
DEBUG - 2011-05-06 11:19:14 --> URI Class Initialized
DEBUG - 2011-05-06 11:19:14 --> Router Class Initialized
DEBUG - 2011-05-06 11:19:14 --> Output Class Initialized
DEBUG - 2011-05-06 11:19:14 --> Input Class Initialized
DEBUG - 2011-05-06 11:19:14 --> Global POST and COOKIE data sanitized
DEBUG - 2011-05-06 11:19:14 --> Language Class Initialized
DEBUG - 2011-05-06 11:19:14 --> Loader Class Initialized
DEBUG - 2011-05-06 11:19:14 --> Controller Class Initialized
ERROR - 2011-05-06 11:19:14 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-05-06 11:19:14 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-05-06 11:19:14 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-05-06 11:19:14 --> Model Class Initialized
DEBUG - 2011-05-06 11:19:14 --> Model Class Initialized
DEBUG - 2011-05-06 11:19:14 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-05-06 11:19:14 --> Database Driver Class Initialized
DEBUG - 2011-05-06 11:19:14 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-05-06 11:19:14 --> Helper loaded: url_helper
DEBUG - 2011-05-06 11:19:14 --> File loaded: application/views/common/header.php
DEBUG - 2011-05-06 11:19:14 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-05-06 11:19:14 --> File loaded: application/views/common/footer.php
DEBUG - 2011-05-06 11:19:14 --> File loaded: application/views/layout/main.php
DEBUG - 2011-05-06 11:19:14 --> Final output sent to browser
DEBUG - 2011-05-06 11:19:14 --> Total execution time: 0.1255
DEBUG - 2011-05-06 11:19:14 --> Config Class Initialized
DEBUG - 2011-05-06 11:19:14 --> Hooks Class Initialized
DEBUG - 2011-05-06 11:19:14 --> Utf8 Class Initialized
DEBUG - 2011-05-06 11:19:14 --> UTF-8 Support Enabled
DEBUG - 2011-05-06 11:19:14 --> URI Class Initialized
DEBUG - 2011-05-06 11:19:14 --> Router Class Initialized
DEBUG - 2011-05-06 11:19:14 --> Output Class Initialized
DEBUG - 2011-05-06 11:19:14 --> Input Class Initialized
DEBUG - 2011-05-06 11:19:14 --> Global POST and COOKIE data sanitized
DEBUG - 2011-05-06 11:19:14 --> Language Class Initialized
DEBUG - 2011-05-06 11:19:14 --> Loader Class Initialized
DEBUG - 2011-05-06 11:19:14 --> Controller Class Initialized
DEBUG - 2011-05-06 11:19:14 --> Model Class Initialized
DEBUG - 2011-05-06 11:19:14 --> Model Class Initialized
DEBUG - 2011-05-06 11:19:14 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-05-06 11:19:14 --> Database Driver Class Initialized
DEBUG - 2011-05-06 11:19:15 --> Final output sent to browser
DEBUG - 2011-05-06 11:19:15 --> Total execution time: 0.8766
DEBUG - 2011-05-06 11:19:16 --> Config Class Initialized
DEBUG - 2011-05-06 11:19:16 --> Hooks Class Initialized
DEBUG - 2011-05-06 11:19:16 --> Utf8 Class Initialized
DEBUG - 2011-05-06 11:19:16 --> UTF-8 Support Enabled
DEBUG - 2011-05-06 11:19:16 --> URI Class Initialized
DEBUG - 2011-05-06 11:19:16 --> Router Class Initialized
ERROR - 2011-05-06 11:19:16 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-05-06 11:19:26 --> Config Class Initialized
DEBUG - 2011-05-06 11:19:26 --> Hooks Class Initialized
DEBUG - 2011-05-06 11:19:26 --> Utf8 Class Initialized
DEBUG - 2011-05-06 11:19:26 --> UTF-8 Support Enabled
DEBUG - 2011-05-06 11:19:26 --> URI Class Initialized
DEBUG - 2011-05-06 11:19:26 --> Router Class Initialized
DEBUG - 2011-05-06 11:19:26 --> Output Class Initialized
DEBUG - 2011-05-06 11:19:26 --> Input Class Initialized
DEBUG - 2011-05-06 11:19:26 --> Global POST and COOKIE data sanitized
DEBUG - 2011-05-06 11:19:26 --> Language Class Initialized
DEBUG - 2011-05-06 11:19:26 --> Loader Class Initialized
DEBUG - 2011-05-06 11:19:26 --> Controller Class Initialized
ERROR - 2011-05-06 11:19:26 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-05-06 11:19:26 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-05-06 11:19:26 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-05-06 11:19:26 --> Model Class Initialized
DEBUG - 2011-05-06 11:19:26 --> Model Class Initialized
DEBUG - 2011-05-06 11:19:26 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-05-06 11:19:26 --> Database Driver Class Initialized
DEBUG - 2011-05-06 11:19:26 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-05-06 11:19:26 --> Helper loaded: url_helper
DEBUG - 2011-05-06 11:19:26 --> File loaded: application/views/common/header.php
DEBUG - 2011-05-06 11:19:26 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-05-06 11:19:26 --> File loaded: application/views/common/footer.php
DEBUG - 2011-05-06 11:19:26 --> File loaded: application/views/layout/main.php
DEBUG - 2011-05-06 11:19:26 --> Final output sent to browser
DEBUG - 2011-05-06 11:19:26 --> Total execution time: 0.0632
DEBUG - 2011-05-06 11:19:27 --> Config Class Initialized
DEBUG - 2011-05-06 11:19:27 --> Hooks Class Initialized
DEBUG - 2011-05-06 11:19:27 --> Utf8 Class Initialized
DEBUG - 2011-05-06 11:19:27 --> UTF-8 Support Enabled
DEBUG - 2011-05-06 11:19:27 --> URI Class Initialized
DEBUG - 2011-05-06 11:19:27 --> Router Class Initialized
DEBUG - 2011-05-06 11:19:27 --> Output Class Initialized
DEBUG - 2011-05-06 11:19:27 --> Input Class Initialized
DEBUG - 2011-05-06 11:19:27 --> Global POST and COOKIE data sanitized
DEBUG - 2011-05-06 11:19:27 --> Language Class Initialized
DEBUG - 2011-05-06 11:19:27 --> Loader Class Initialized
DEBUG - 2011-05-06 11:19:27 --> Controller Class Initialized
DEBUG - 2011-05-06 11:19:27 --> Model Class Initialized
DEBUG - 2011-05-06 11:19:27 --> Model Class Initialized
DEBUG - 2011-05-06 11:19:27 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-05-06 11:19:27 --> Database Driver Class Initialized
DEBUG - 2011-05-06 11:19:27 --> Final output sent to browser
DEBUG - 2011-05-06 11:19:27 --> Total execution time: 0.5809
DEBUG - 2011-05-06 11:19:28 --> Config Class Initialized
DEBUG - 2011-05-06 11:19:28 --> Hooks Class Initialized
DEBUG - 2011-05-06 11:19:28 --> Utf8 Class Initialized
DEBUG - 2011-05-06 11:19:28 --> UTF-8 Support Enabled
DEBUG - 2011-05-06 11:19:28 --> URI Class Initialized
DEBUG - 2011-05-06 11:19:28 --> Router Class Initialized
ERROR - 2011-05-06 11:19:28 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-05-06 11:19:36 --> Config Class Initialized
DEBUG - 2011-05-06 11:19:36 --> Hooks Class Initialized
DEBUG - 2011-05-06 11:19:36 --> Utf8 Class Initialized
DEBUG - 2011-05-06 11:19:36 --> UTF-8 Support Enabled
DEBUG - 2011-05-06 11:19:36 --> URI Class Initialized
DEBUG - 2011-05-06 11:19:36 --> Router Class Initialized
DEBUG - 2011-05-06 11:19:36 --> Output Class Initialized
DEBUG - 2011-05-06 11:19:36 --> Input Class Initialized
DEBUG - 2011-05-06 11:19:36 --> Global POST and COOKIE data sanitized
DEBUG - 2011-05-06 11:19:36 --> Language Class Initialized
DEBUG - 2011-05-06 11:19:36 --> Loader Class Initialized
DEBUG - 2011-05-06 11:19:36 --> Controller Class Initialized
ERROR - 2011-05-06 11:19:36 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-05-06 11:19:36 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-05-06 11:19:36 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-05-06 11:19:36 --> Model Class Initialized
DEBUG - 2011-05-06 11:19:36 --> Model Class Initialized
DEBUG - 2011-05-06 11:19:36 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-05-06 11:19:36 --> Database Driver Class Initialized
DEBUG - 2011-05-06 11:19:36 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-05-06 11:19:36 --> Helper loaded: url_helper
DEBUG - 2011-05-06 11:19:36 --> File loaded: application/views/common/header.php
DEBUG - 2011-05-06 11:19:36 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-05-06 11:19:36 --> File loaded: application/views/common/footer.php
DEBUG - 2011-05-06 11:19:36 --> File loaded: application/views/layout/main.php
DEBUG - 2011-05-06 11:19:36 --> Final output sent to browser
DEBUG - 2011-05-06 11:19:36 --> Total execution time: 0.1075
DEBUG - 2011-05-06 11:19:37 --> Config Class Initialized
DEBUG - 2011-05-06 11:19:37 --> Hooks Class Initialized
DEBUG - 2011-05-06 11:19:37 --> Utf8 Class Initialized
DEBUG - 2011-05-06 11:19:37 --> UTF-8 Support Enabled
DEBUG - 2011-05-06 11:19:37 --> URI Class Initialized
DEBUG - 2011-05-06 11:19:37 --> Router Class Initialized
DEBUG - 2011-05-06 11:19:37 --> Output Class Initialized
DEBUG - 2011-05-06 11:19:37 --> Input Class Initialized
DEBUG - 2011-05-06 11:19:37 --> Global POST and COOKIE data sanitized
DEBUG - 2011-05-06 11:19:37 --> Language Class Initialized
DEBUG - 2011-05-06 11:19:37 --> Loader Class Initialized
DEBUG - 2011-05-06 11:19:37 --> Controller Class Initialized
DEBUG - 2011-05-06 11:19:37 --> Model Class Initialized
DEBUG - 2011-05-06 11:19:37 --> Model Class Initialized
DEBUG - 2011-05-06 11:19:37 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-05-06 11:19:37 --> Database Driver Class Initialized
DEBUG - 2011-05-06 11:19:38 --> Final output sent to browser
DEBUG - 2011-05-06 11:19:38 --> Total execution time: 0.6519
DEBUG - 2011-05-06 11:19:38 --> Config Class Initialized
DEBUG - 2011-05-06 11:19:38 --> Hooks Class Initialized
DEBUG - 2011-05-06 11:19:38 --> Utf8 Class Initialized
DEBUG - 2011-05-06 11:19:38 --> UTF-8 Support Enabled
DEBUG - 2011-05-06 11:19:38 --> URI Class Initialized
DEBUG - 2011-05-06 11:19:38 --> Router Class Initialized
ERROR - 2011-05-06 11:19:38 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-05-06 11:22:15 --> Config Class Initialized
DEBUG - 2011-05-06 11:22:15 --> Hooks Class Initialized
DEBUG - 2011-05-06 11:22:15 --> Utf8 Class Initialized
DEBUG - 2011-05-06 11:22:15 --> UTF-8 Support Enabled
DEBUG - 2011-05-06 11:22:15 --> URI Class Initialized
DEBUG - 2011-05-06 11:22:15 --> Router Class Initialized
ERROR - 2011-05-06 11:22:15 --> 404 Page Not Found --> robots.txt
DEBUG - 2011-05-06 11:23:10 --> Config Class Initialized
DEBUG - 2011-05-06 11:23:10 --> Hooks Class Initialized
DEBUG - 2011-05-06 11:23:10 --> Utf8 Class Initialized
DEBUG - 2011-05-06 11:23:10 --> UTF-8 Support Enabled
DEBUG - 2011-05-06 11:23:10 --> URI Class Initialized
DEBUG - 2011-05-06 11:23:10 --> Router Class Initialized
DEBUG - 2011-05-06 11:23:10 --> No URI present. Default controller set.
DEBUG - 2011-05-06 11:23:10 --> Output Class Initialized
DEBUG - 2011-05-06 11:23:10 --> Input Class Initialized
DEBUG - 2011-05-06 11:23:10 --> Global POST and COOKIE data sanitized
DEBUG - 2011-05-06 11:23:10 --> Language Class Initialized
DEBUG - 2011-05-06 11:23:10 --> Loader Class Initialized
DEBUG - 2011-05-06 11:23:10 --> Controller Class Initialized
DEBUG - 2011-05-06 11:23:10 --> File loaded: application/views/splash/main.php
DEBUG - 2011-05-06 11:23:10 --> Helper loaded: url_helper
DEBUG - 2011-05-06 11:23:10 --> File loaded: application/views/common/header.php
DEBUG - 2011-05-06 11:23:10 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-05-06 11:23:10 --> File loaded: application/views/common/footer.php
DEBUG - 2011-05-06 11:23:10 --> File loaded: application/views/layout/main.php
DEBUG - 2011-05-06 11:23:10 --> Final output sent to browser
DEBUG - 2011-05-06 11:23:10 --> Total execution time: 0.1014
DEBUG - 2011-05-06 11:30:18 --> Config Class Initialized
DEBUG - 2011-05-06 11:30:18 --> Hooks Class Initialized
DEBUG - 2011-05-06 11:30:18 --> Utf8 Class Initialized
DEBUG - 2011-05-06 11:30:18 --> UTF-8 Support Enabled
DEBUG - 2011-05-06 11:30:18 --> URI Class Initialized
DEBUG - 2011-05-06 11:30:18 --> Router Class Initialized
DEBUG - 2011-05-06 11:30:20 --> Output Class Initialized
DEBUG - 2011-05-06 11:30:20 --> Config Class Initialized
DEBUG - 2011-05-06 11:30:20 --> Hooks Class Initialized
DEBUG - 2011-05-06 11:30:20 --> Utf8 Class Initialized
DEBUG - 2011-05-06 11:30:20 --> UTF-8 Support Enabled
DEBUG - 2011-05-06 11:30:20 --> URI Class Initialized
DEBUG - 2011-05-06 11:30:20 --> Router Class Initialized
DEBUG - 2011-05-06 11:30:20 --> Output Class Initialized
DEBUG - 2011-05-06 11:30:20 --> Input Class Initialized
DEBUG - 2011-05-06 11:30:20 --> Input Class Initialized
DEBUG - 2011-05-06 11:30:20 --> Global POST and COOKIE data sanitized
DEBUG - 2011-05-06 11:30:20 --> Global POST and COOKIE data sanitized
DEBUG - 2011-05-06 11:30:20 --> Language Class Initialized
DEBUG - 2011-05-06 11:30:20 --> Language Class Initialized
DEBUG - 2011-05-06 11:30:21 --> Loader Class Initialized
DEBUG - 2011-05-06 11:30:21 --> Loader Class Initialized
DEBUG - 2011-05-06 11:30:21 --> Controller Class Initialized
DEBUG - 2011-05-06 11:30:21 --> Controller Class Initialized
ERROR - 2011-05-06 11:30:22 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-05-06 11:30:22 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-05-06 11:30:22 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-05-06 11:30:22 --> File loaded: application/views/snakes/main.php
ERROR - 2011-05-06 11:30:22 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-05-06 11:30:22 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-05-06 11:30:22 --> Model Class Initialized
DEBUG - 2011-05-06 11:30:22 --> Model Class Initialized
DEBUG - 2011-05-06 11:30:22 --> Model Class Initialized
DEBUG - 2011-05-06 11:30:22 --> Model Class Initialized
DEBUG - 2011-05-06 11:30:22 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-05-06 11:30:22 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-05-06 11:30:23 --> Database Driver Class Initialized
DEBUG - 2011-05-06 11:30:23 --> Database Driver Class Initialized
DEBUG - 2011-05-06 11:30:24 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-05-06 11:30:24 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-05-06 11:30:25 --> Helper loaded: url_helper
DEBUG - 2011-05-06 11:30:25 --> Helper loaded: url_helper
DEBUG - 2011-05-06 11:30:25 --> File loaded: application/views/common/header.php
DEBUG - 2011-05-06 11:30:25 --> File loaded: application/views/common/header.php
DEBUG - 2011-05-06 11:30:25 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-05-06 11:30:25 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-05-06 11:30:25 --> File loaded: application/views/common/footer.php
DEBUG - 2011-05-06 11:30:25 --> File loaded: application/views/layout/main.php
DEBUG - 2011-05-06 11:30:25 --> Final output sent to browser
DEBUG - 2011-05-06 11:30:25 --> Total execution time: 7.6003
DEBUG - 2011-05-06 11:30:25 --> File loaded: application/views/common/footer.php
DEBUG - 2011-05-06 11:30:25 --> File loaded: application/views/layout/main.php
DEBUG - 2011-05-06 11:30:25 --> Final output sent to browser
DEBUG - 2011-05-06 11:30:25 --> Total execution time: 4.9884
DEBUG - 2011-05-06 11:30:26 --> Config Class Initialized
DEBUG - 2011-05-06 11:30:26 --> Hooks Class Initialized
DEBUG - 2011-05-06 11:30:26 --> Utf8 Class Initialized
DEBUG - 2011-05-06 11:30:26 --> UTF-8 Support Enabled
DEBUG - 2011-05-06 11:30:26 --> URI Class Initialized
DEBUG - 2011-05-06 11:30:26 --> Router Class Initialized
DEBUG - 2011-05-06 11:30:26 --> Output Class Initialized
DEBUG - 2011-05-06 11:30:26 --> Input Class Initialized
DEBUG - 2011-05-06 11:30:26 --> Global POST and COOKIE data sanitized
DEBUG - 2011-05-06 11:30:26 --> Language Class Initialized
DEBUG - 2011-05-06 11:30:26 --> Loader Class Initialized
DEBUG - 2011-05-06 11:30:26 --> Controller Class Initialized
DEBUG - 2011-05-06 11:30:26 --> Model Class Initialized
DEBUG - 2011-05-06 11:30:26 --> Model Class Initialized
DEBUG - 2011-05-06 11:30:26 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-05-06 11:30:26 --> Database Driver Class Initialized
DEBUG - 2011-05-06 11:30:27 --> Final output sent to browser
DEBUG - 2011-05-06 11:30:27 --> Total execution time: 0.7868
DEBUG - 2011-05-06 11:30:31 --> Config Class Initialized
DEBUG - 2011-05-06 11:30:31 --> Hooks Class Initialized
DEBUG - 2011-05-06 11:30:31 --> Utf8 Class Initialized
DEBUG - 2011-05-06 11:30:31 --> UTF-8 Support Enabled
DEBUG - 2011-05-06 11:30:31 --> URI Class Initialized
DEBUG - 2011-05-06 11:30:31 --> Router Class Initialized
ERROR - 2011-05-06 11:30:31 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-05-06 11:30:33 --> Config Class Initialized
DEBUG - 2011-05-06 11:30:33 --> Hooks Class Initialized
DEBUG - 2011-05-06 11:30:33 --> Utf8 Class Initialized
DEBUG - 2011-05-06 11:30:33 --> UTF-8 Support Enabled
DEBUG - 2011-05-06 11:30:33 --> URI Class Initialized
DEBUG - 2011-05-06 11:30:33 --> Router Class Initialized
ERROR - 2011-05-06 11:30:33 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-05-06 11:30:34 --> Config Class Initialized
DEBUG - 2011-05-06 11:30:34 --> Hooks Class Initialized
DEBUG - 2011-05-06 11:30:34 --> Utf8 Class Initialized
DEBUG - 2011-05-06 11:30:34 --> UTF-8 Support Enabled
DEBUG - 2011-05-06 11:30:34 --> URI Class Initialized
DEBUG - 2011-05-06 11:30:34 --> Router Class Initialized
ERROR - 2011-05-06 11:30:34 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-05-06 11:59:11 --> Config Class Initialized
DEBUG - 2011-05-06 11:59:11 --> Hooks Class Initialized
DEBUG - 2011-05-06 11:59:11 --> Utf8 Class Initialized
DEBUG - 2011-05-06 11:59:11 --> UTF-8 Support Enabled
DEBUG - 2011-05-06 11:59:11 --> URI Class Initialized
DEBUG - 2011-05-06 11:59:11 --> Router Class Initialized
DEBUG - 2011-05-06 11:59:11 --> Output Class Initialized
DEBUG - 2011-05-06 11:59:11 --> Input Class Initialized
DEBUG - 2011-05-06 11:59:11 --> Global POST and COOKIE data sanitized
DEBUG - 2011-05-06 11:59:11 --> Language Class Initialized
DEBUG - 2011-05-06 11:59:12 --> Loader Class Initialized
DEBUG - 2011-05-06 11:59:12 --> Controller Class Initialized
DEBUG - 2011-05-06 11:59:12 --> Model Class Initialized
DEBUG - 2011-05-06 11:59:13 --> Model Class Initialized
DEBUG - 2011-05-06 11:59:13 --> Model Class Initialized
DEBUG - 2011-05-06 11:59:13 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-05-06 11:59:15 --> Database Driver Class Initialized
DEBUG - 2011-05-06 11:59:15 --> Config Class Initialized
DEBUG - 2011-05-06 11:59:15 --> Hooks Class Initialized
DEBUG - 2011-05-06 11:59:15 --> Utf8 Class Initialized
DEBUG - 2011-05-06 11:59:15 --> UTF-8 Support Enabled
DEBUG - 2011-05-06 11:59:15 --> URI Class Initialized
DEBUG - 2011-05-06 11:59:15 --> Router Class Initialized
DEBUG - 2011-05-06 11:59:16 --> Output Class Initialized
DEBUG - 2011-05-06 11:59:16 --> Input Class Initialized
DEBUG - 2011-05-06 11:59:16 --> Global POST and COOKIE data sanitized
DEBUG - 2011-05-06 11:59:16 --> Language Class Initialized
DEBUG - 2011-05-06 11:59:16 --> Loader Class Initialized
DEBUG - 2011-05-06 11:59:16 --> Controller Class Initialized
DEBUG - 2011-05-06 11:59:16 --> File loaded: application/views/table/main.php
ERROR - 2011-05-06 11:59:17 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-05-06 11:59:17 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-05-06 11:59:17 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-05-06 11:59:17 --> Model Class Initialized
DEBUG - 2011-05-06 11:59:17 --> Model Class Initialized
DEBUG - 2011-05-06 11:59:17 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-05-06 11:59:17 --> Database Driver Class Initialized
DEBUG - 2011-05-06 11:59:17 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-05-06 11:59:17 --> Helper loaded: url_helper
DEBUG - 2011-05-06 11:59:17 --> File loaded: application/views/common/header.php
DEBUG - 2011-05-06 11:59:17 --> Helper loaded: url_helper
DEBUG - 2011-05-06 11:59:17 --> File loaded: application/views/common/header.php
DEBUG - 2011-05-06 11:59:18 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-05-06 11:59:18 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-05-06 11:59:18 --> File loaded: application/views/common/footer.php
DEBUG - 2011-05-06 11:59:18 --> File loaded: application/views/common/footer.php
DEBUG - 2011-05-06 11:59:18 --> File loaded: application/views/layout/main.php
DEBUG - 2011-05-06 11:59:18 --> File loaded: application/views/layout/main.php
DEBUG - 2011-05-06 11:59:18 --> Final output sent to browser
DEBUG - 2011-05-06 11:59:18 --> Total execution time: 2.9543
DEBUG - 2011-05-06 11:59:18 --> Final output sent to browser
DEBUG - 2011-05-06 11:59:18 --> Total execution time: 7.2569
DEBUG - 2011-05-06 11:59:19 --> Config Class Initialized
DEBUG - 2011-05-06 11:59:19 --> Hooks Class Initialized
DEBUG - 2011-05-06 11:59:19 --> Utf8 Class Initialized
DEBUG - 2011-05-06 11:59:19 --> UTF-8 Support Enabled
DEBUG - 2011-05-06 11:59:19 --> URI Class Initialized
DEBUG - 2011-05-06 11:59:19 --> Router Class Initialized
ERROR - 2011-05-06 11:59:19 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-05-06 11:59:20 --> Config Class Initialized
DEBUG - 2011-05-06 11:59:20 --> Hooks Class Initialized
DEBUG - 2011-05-06 11:59:20 --> Utf8 Class Initialized
DEBUG - 2011-05-06 11:59:20 --> UTF-8 Support Enabled
DEBUG - 2011-05-06 11:59:20 --> URI Class Initialized
DEBUG - 2011-05-06 11:59:20 --> Router Class Initialized
DEBUG - 2011-05-06 11:59:20 --> Output Class Initialized
DEBUG - 2011-05-06 11:59:20 --> Input Class Initialized
DEBUG - 2011-05-06 11:59:20 --> Global POST and COOKIE data sanitized
DEBUG - 2011-05-06 11:59:20 --> Language Class Initialized
DEBUG - 2011-05-06 11:59:20 --> Loader Class Initialized
DEBUG - 2011-05-06 11:59:20 --> Controller Class Initialized
DEBUG - 2011-05-06 11:59:20 --> Model Class Initialized
DEBUG - 2011-05-06 11:59:20 --> Model Class Initialized
DEBUG - 2011-05-06 11:59:20 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-05-06 11:59:20 --> Database Driver Class Initialized
DEBUG - 2011-05-06 11:59:21 --> Final output sent to browser
DEBUG - 2011-05-06 11:59:21 --> Total execution time: 1.1841
DEBUG - 2011-05-06 11:59:21 --> Config Class Initialized
DEBUG - 2011-05-06 11:59:21 --> Hooks Class Initialized
DEBUG - 2011-05-06 11:59:21 --> Utf8 Class Initialized
DEBUG - 2011-05-06 11:59:21 --> UTF-8 Support Enabled
DEBUG - 2011-05-06 11:59:21 --> URI Class Initialized
DEBUG - 2011-05-06 11:59:21 --> Router Class Initialized
ERROR - 2011-05-06 11:59:21 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-05-06 11:59:22 --> Config Class Initialized
DEBUG - 2011-05-06 11:59:22 --> Hooks Class Initialized
DEBUG - 2011-05-06 11:59:22 --> Utf8 Class Initialized
DEBUG - 2011-05-06 11:59:22 --> UTF-8 Support Enabled
DEBUG - 2011-05-06 11:59:22 --> URI Class Initialized
DEBUG - 2011-05-06 11:59:22 --> Router Class Initialized
ERROR - 2011-05-06 11:59:22 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-05-06 12:00:02 --> Config Class Initialized
DEBUG - 2011-05-06 12:00:02 --> Hooks Class Initialized
DEBUG - 2011-05-06 12:00:02 --> Utf8 Class Initialized
DEBUG - 2011-05-06 12:00:02 --> UTF-8 Support Enabled
DEBUG - 2011-05-06 12:00:02 --> URI Class Initialized
DEBUG - 2011-05-06 12:00:02 --> Router Class Initialized
DEBUG - 2011-05-06 12:00:02 --> Output Class Initialized
DEBUG - 2011-05-06 12:00:02 --> Input Class Initialized
DEBUG - 2011-05-06 12:00:02 --> Global POST and COOKIE data sanitized
DEBUG - 2011-05-06 12:00:02 --> Language Class Initialized
DEBUG - 2011-05-06 12:00:02 --> Loader Class Initialized
DEBUG - 2011-05-06 12:00:02 --> Controller Class Initialized
DEBUG - 2011-05-06 12:00:02 --> Model Class Initialized
DEBUG - 2011-05-06 12:00:02 --> Model Class Initialized
DEBUG - 2011-05-06 12:00:02 --> Model Class Initialized
DEBUG - 2011-05-06 12:00:02 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-05-06 12:00:02 --> Database Driver Class Initialized
DEBUG - 2011-05-06 12:00:04 --> File loaded: application/views/table/main.php
DEBUG - 2011-05-06 12:00:04 --> Helper loaded: url_helper
DEBUG - 2011-05-06 12:00:04 --> File loaded: application/views/common/header.php
DEBUG - 2011-05-06 12:00:04 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-05-06 12:00:04 --> File loaded: application/views/common/footer.php
DEBUG - 2011-05-06 12:00:04 --> File loaded: application/views/layout/main.php
DEBUG - 2011-05-06 12:00:04 --> Final output sent to browser
DEBUG - 2011-05-06 12:00:04 --> Total execution time: 2.3238
DEBUG - 2011-05-06 12:00:06 --> Config Class Initialized
DEBUG - 2011-05-06 12:00:06 --> Hooks Class Initialized
DEBUG - 2011-05-06 12:00:06 --> Utf8 Class Initialized
DEBUG - 2011-05-06 12:00:06 --> UTF-8 Support Enabled
DEBUG - 2011-05-06 12:00:06 --> URI Class Initialized
DEBUG - 2011-05-06 12:00:06 --> Router Class Initialized
ERROR - 2011-05-06 12:00:06 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-05-06 12:00:07 --> Config Class Initialized
DEBUG - 2011-05-06 12:00:07 --> Hooks Class Initialized
DEBUG - 2011-05-06 12:00:07 --> Utf8 Class Initialized
DEBUG - 2011-05-06 12:00:07 --> UTF-8 Support Enabled
DEBUG - 2011-05-06 12:00:07 --> URI Class Initialized
DEBUG - 2011-05-06 12:00:07 --> Router Class Initialized
ERROR - 2011-05-06 12:00:07 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-05-06 12:00:25 --> Config Class Initialized
DEBUG - 2011-05-06 12:00:25 --> Hooks Class Initialized
DEBUG - 2011-05-06 12:00:25 --> Utf8 Class Initialized
DEBUG - 2011-05-06 12:00:25 --> UTF-8 Support Enabled
DEBUG - 2011-05-06 12:00:25 --> URI Class Initialized
DEBUG - 2011-05-06 12:00:25 --> Router Class Initialized
DEBUG - 2011-05-06 12:00:25 --> Output Class Initialized
DEBUG - 2011-05-06 12:00:25 --> Input Class Initialized
DEBUG - 2011-05-06 12:00:25 --> Global POST and COOKIE data sanitized
DEBUG - 2011-05-06 12:00:25 --> Language Class Initialized
DEBUG - 2011-05-06 12:00:25 --> Loader Class Initialized
DEBUG - 2011-05-06 12:00:25 --> Controller Class Initialized
DEBUG - 2011-05-06 12:00:25 --> Model Class Initialized
DEBUG - 2011-05-06 12:00:25 --> Model Class Initialized
DEBUG - 2011-05-06 12:00:25 --> Model Class Initialized
DEBUG - 2011-05-06 12:00:25 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-05-06 12:00:25 --> Database Driver Class Initialized
DEBUG - 2011-05-06 12:00:29 --> File loaded: application/views/table/main.php
DEBUG - 2011-05-06 12:00:29 --> Helper loaded: url_helper
DEBUG - 2011-05-06 12:00:29 --> File loaded: application/views/common/header.php
DEBUG - 2011-05-06 12:00:29 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-05-06 12:00:29 --> File loaded: application/views/common/footer.php
DEBUG - 2011-05-06 12:00:29 --> File loaded: application/views/layout/main.php
DEBUG - 2011-05-06 12:00:29 --> Final output sent to browser
DEBUG - 2011-05-06 12:00:29 --> Total execution time: 4.1163
DEBUG - 2011-05-06 12:00:31 --> Config Class Initialized
DEBUG - 2011-05-06 12:00:31 --> Hooks Class Initialized
DEBUG - 2011-05-06 12:00:31 --> Utf8 Class Initialized
DEBUG - 2011-05-06 12:00:31 --> UTF-8 Support Enabled
DEBUG - 2011-05-06 12:00:31 --> URI Class Initialized
DEBUG - 2011-05-06 12:00:31 --> Router Class Initialized
ERROR - 2011-05-06 12:00:31 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-05-06 12:00:38 --> Config Class Initialized
DEBUG - 2011-05-06 12:00:38 --> Hooks Class Initialized
DEBUG - 2011-05-06 12:00:38 --> Utf8 Class Initialized
DEBUG - 2011-05-06 12:00:38 --> UTF-8 Support Enabled
DEBUG - 2011-05-06 12:00:38 --> URI Class Initialized
DEBUG - 2011-05-06 12:00:38 --> Router Class Initialized
DEBUG - 2011-05-06 12:00:38 --> Output Class Initialized
DEBUG - 2011-05-06 12:00:38 --> Input Class Initialized
DEBUG - 2011-05-06 12:00:38 --> Global POST and COOKIE data sanitized
DEBUG - 2011-05-06 12:00:38 --> Language Class Initialized
DEBUG - 2011-05-06 12:00:38 --> Loader Class Initialized
DEBUG - 2011-05-06 12:00:38 --> Controller Class Initialized
DEBUG - 2011-05-06 12:00:38 --> Model Class Initialized
DEBUG - 2011-05-06 12:00:38 --> Model Class Initialized
DEBUG - 2011-05-06 12:00:38 --> Model Class Initialized
DEBUG - 2011-05-06 12:00:38 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-05-06 12:00:38 --> Database Driver Class Initialized
DEBUG - 2011-05-06 12:00:39 --> File loaded: application/views/table/main.php
DEBUG - 2011-05-06 12:00:39 --> Helper loaded: url_helper
DEBUG - 2011-05-06 12:00:39 --> File loaded: application/views/common/header.php
DEBUG - 2011-05-06 12:00:39 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-05-06 12:00:39 --> File loaded: application/views/common/footer.php
DEBUG - 2011-05-06 12:00:39 --> File loaded: application/views/layout/main.php
DEBUG - 2011-05-06 12:00:39 --> Final output sent to browser
DEBUG - 2011-05-06 12:00:39 --> Total execution time: 1.7633
DEBUG - 2011-05-06 12:00:41 --> Config Class Initialized
DEBUG - 2011-05-06 12:00:41 --> Hooks Class Initialized
DEBUG - 2011-05-06 12:00:41 --> Utf8 Class Initialized
DEBUG - 2011-05-06 12:00:41 --> UTF-8 Support Enabled
DEBUG - 2011-05-06 12:00:41 --> URI Class Initialized
DEBUG - 2011-05-06 12:00:41 --> Router Class Initialized
ERROR - 2011-05-06 12:00:41 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-05-06 12:01:06 --> Config Class Initialized
DEBUG - 2011-05-06 12:01:06 --> Hooks Class Initialized
DEBUG - 2011-05-06 12:01:06 --> Utf8 Class Initialized
DEBUG - 2011-05-06 12:01:06 --> UTF-8 Support Enabled
DEBUG - 2011-05-06 12:01:06 --> URI Class Initialized
DEBUG - 2011-05-06 12:01:06 --> Router Class Initialized
DEBUG - 2011-05-06 12:01:06 --> Output Class Initialized
DEBUG - 2011-05-06 12:01:06 --> Input Class Initialized
DEBUG - 2011-05-06 12:01:06 --> Global POST and COOKIE data sanitized
DEBUG - 2011-05-06 12:01:06 --> Language Class Initialized
DEBUG - 2011-05-06 12:01:06 --> Loader Class Initialized
DEBUG - 2011-05-06 12:01:06 --> Controller Class Initialized
DEBUG - 2011-05-06 12:01:06 --> Model Class Initialized
DEBUG - 2011-05-06 12:01:06 --> Model Class Initialized
DEBUG - 2011-05-06 12:01:06 --> Model Class Initialized
DEBUG - 2011-05-06 12:01:06 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-05-06 12:01:06 --> Database Driver Class Initialized
DEBUG - 2011-05-06 12:01:06 --> File loaded: application/views/table/main.php
DEBUG - 2011-05-06 12:01:06 --> Helper loaded: url_helper
DEBUG - 2011-05-06 12:01:06 --> File loaded: application/views/common/header.php
DEBUG - 2011-05-06 12:01:06 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-05-06 12:01:06 --> File loaded: application/views/common/footer.php
DEBUG - 2011-05-06 12:01:06 --> File loaded: application/views/layout/main.php
DEBUG - 2011-05-06 12:01:06 --> Final output sent to browser
DEBUG - 2011-05-06 12:01:06 --> Total execution time: 0.2026
DEBUG - 2011-05-06 12:01:08 --> Config Class Initialized
DEBUG - 2011-05-06 12:01:08 --> Hooks Class Initialized
DEBUG - 2011-05-06 12:01:08 --> Utf8 Class Initialized
DEBUG - 2011-05-06 12:01:08 --> UTF-8 Support Enabled
DEBUG - 2011-05-06 12:01:08 --> URI Class Initialized
DEBUG - 2011-05-06 12:01:08 --> Router Class Initialized
ERROR - 2011-05-06 12:01:08 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-05-06 12:01:24 --> Config Class Initialized
DEBUG - 2011-05-06 12:01:24 --> Hooks Class Initialized
DEBUG - 2011-05-06 12:01:24 --> Utf8 Class Initialized
DEBUG - 2011-05-06 12:01:24 --> UTF-8 Support Enabled
DEBUG - 2011-05-06 12:01:24 --> URI Class Initialized
DEBUG - 2011-05-06 12:01:24 --> Router Class Initialized
DEBUG - 2011-05-06 12:01:24 --> Output Class Initialized
DEBUG - 2011-05-06 12:01:24 --> Input Class Initialized
DEBUG - 2011-05-06 12:01:24 --> Global POST and COOKIE data sanitized
DEBUG - 2011-05-06 12:01:24 --> Language Class Initialized
DEBUG - 2011-05-06 12:01:24 --> Loader Class Initialized
DEBUG - 2011-05-06 12:01:24 --> Controller Class Initialized
DEBUG - 2011-05-06 12:01:24 --> Model Class Initialized
DEBUG - 2011-05-06 12:01:24 --> Model Class Initialized
DEBUG - 2011-05-06 12:01:24 --> Model Class Initialized
DEBUG - 2011-05-06 12:01:24 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-05-06 12:01:24 --> Database Driver Class Initialized
DEBUG - 2011-05-06 12:01:24 --> File loaded: application/views/table/main.php
DEBUG - 2011-05-06 12:01:24 --> Helper loaded: url_helper
DEBUG - 2011-05-06 12:01:24 --> File loaded: application/views/common/header.php
DEBUG - 2011-05-06 12:01:24 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-05-06 12:01:24 --> File loaded: application/views/common/footer.php
DEBUG - 2011-05-06 12:01:24 --> File loaded: application/views/layout/main.php
DEBUG - 2011-05-06 12:01:24 --> Final output sent to browser
DEBUG - 2011-05-06 12:01:24 --> Total execution time: 0.1730
DEBUG - 2011-05-06 12:01:25 --> Config Class Initialized
DEBUG - 2011-05-06 12:01:25 --> Hooks Class Initialized
DEBUG - 2011-05-06 12:01:25 --> Utf8 Class Initialized
DEBUG - 2011-05-06 12:01:25 --> UTF-8 Support Enabled
DEBUG - 2011-05-06 12:01:25 --> URI Class Initialized
DEBUG - 2011-05-06 12:01:25 --> Router Class Initialized
DEBUG - 2011-05-06 12:01:25 --> Output Class Initialized
DEBUG - 2011-05-06 12:01:25 --> Input Class Initialized
DEBUG - 2011-05-06 12:01:25 --> Global POST and COOKIE data sanitized
DEBUG - 2011-05-06 12:01:25 --> Language Class Initialized
DEBUG - 2011-05-06 12:01:25 --> Loader Class Initialized
DEBUG - 2011-05-06 12:01:25 --> Controller Class Initialized
DEBUG - 2011-05-06 12:01:25 --> Model Class Initialized
DEBUG - 2011-05-06 12:01:25 --> Model Class Initialized
DEBUG - 2011-05-06 12:01:25 --> Model Class Initialized
DEBUG - 2011-05-06 12:01:25 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-05-06 12:01:25 --> Database Driver Class Initialized
DEBUG - 2011-05-06 12:01:25 --> File loaded: application/views/table/main.php
DEBUG - 2011-05-06 12:01:25 --> Helper loaded: url_helper
DEBUG - 2011-05-06 12:01:25 --> File loaded: application/views/common/header.php
DEBUG - 2011-05-06 12:01:25 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-05-06 12:01:25 --> File loaded: application/views/common/footer.php
DEBUG - 2011-05-06 12:01:25 --> File loaded: application/views/layout/main.php
DEBUG - 2011-05-06 12:01:25 --> Final output sent to browser
DEBUG - 2011-05-06 12:01:25 --> Total execution time: 0.0965
DEBUG - 2011-05-06 12:01:29 --> Config Class Initialized
DEBUG - 2011-05-06 12:01:29 --> Hooks Class Initialized
DEBUG - 2011-05-06 12:01:29 --> Utf8 Class Initialized
DEBUG - 2011-05-06 12:01:29 --> UTF-8 Support Enabled
DEBUG - 2011-05-06 12:01:29 --> URI Class Initialized
DEBUG - 2011-05-06 12:01:29 --> Router Class Initialized
DEBUG - 2011-05-06 12:01:29 --> Output Class Initialized
DEBUG - 2011-05-06 12:01:29 --> Input Class Initialized
DEBUG - 2011-05-06 12:01:29 --> Global POST and COOKIE data sanitized
DEBUG - 2011-05-06 12:01:29 --> Language Class Initialized
DEBUG - 2011-05-06 12:01:29 --> Loader Class Initialized
DEBUG - 2011-05-06 12:01:29 --> Controller Class Initialized
DEBUG - 2011-05-06 12:01:29 --> Model Class Initialized
DEBUG - 2011-05-06 12:01:29 --> Model Class Initialized
DEBUG - 2011-05-06 12:01:29 --> Model Class Initialized
DEBUG - 2011-05-06 12:01:29 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-05-06 12:01:29 --> Database Driver Class Initialized
DEBUG - 2011-05-06 12:01:29 --> File loaded: application/views/table/main.php
DEBUG - 2011-05-06 12:01:29 --> Helper loaded: url_helper
DEBUG - 2011-05-06 12:01:29 --> File loaded: application/views/common/header.php
DEBUG - 2011-05-06 12:01:29 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-05-06 12:01:29 --> File loaded: application/views/common/footer.php
DEBUG - 2011-05-06 12:01:29 --> File loaded: application/views/layout/main.php
DEBUG - 2011-05-06 12:01:29 --> Final output sent to browser
DEBUG - 2011-05-06 12:01:29 --> Total execution time: 0.1633
DEBUG - 2011-05-06 12:18:36 --> Config Class Initialized
DEBUG - 2011-05-06 12:18:36 --> Hooks Class Initialized
DEBUG - 2011-05-06 12:18:36 --> Utf8 Class Initialized
DEBUG - 2011-05-06 12:18:36 --> UTF-8 Support Enabled
DEBUG - 2011-05-06 12:18:36 --> URI Class Initialized
DEBUG - 2011-05-06 12:18:36 --> Router Class Initialized
ERROR - 2011-05-06 12:18:36 --> 404 Page Not Found --> robots.txt
DEBUG - 2011-05-06 12:19:09 --> Config Class Initialized
DEBUG - 2011-05-06 12:19:09 --> Hooks Class Initialized
DEBUG - 2011-05-06 12:19:09 --> Utf8 Class Initialized
DEBUG - 2011-05-06 12:19:09 --> UTF-8 Support Enabled
DEBUG - 2011-05-06 12:19:09 --> URI Class Initialized
DEBUG - 2011-05-06 12:19:09 --> Router Class Initialized
DEBUG - 2011-05-06 12:19:09 --> No URI present. Default controller set.
DEBUG - 2011-05-06 12:19:09 --> Output Class Initialized
DEBUG - 2011-05-06 12:19:09 --> Input Class Initialized
DEBUG - 2011-05-06 12:19:09 --> Global POST and COOKIE data sanitized
DEBUG - 2011-05-06 12:19:09 --> Language Class Initialized
DEBUG - 2011-05-06 12:19:09 --> Loader Class Initialized
DEBUG - 2011-05-06 12:19:09 --> Controller Class Initialized
DEBUG - 2011-05-06 12:19:09 --> File loaded: application/views/splash/main.php
DEBUG - 2011-05-06 12:19:09 --> Helper loaded: url_helper
DEBUG - 2011-05-06 12:19:09 --> File loaded: application/views/common/header.php
DEBUG - 2011-05-06 12:19:09 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-05-06 12:19:09 --> File loaded: application/views/common/footer.php
DEBUG - 2011-05-06 12:19:09 --> File loaded: application/views/layout/main.php
DEBUG - 2011-05-06 12:19:09 --> Final output sent to browser
DEBUG - 2011-05-06 12:19:09 --> Total execution time: 0.1937
DEBUG - 2011-05-06 12:44:40 --> Config Class Initialized
DEBUG - 2011-05-06 12:44:40 --> Hooks Class Initialized
DEBUG - 2011-05-06 12:44:40 --> Utf8 Class Initialized
DEBUG - 2011-05-06 12:44:40 --> UTF-8 Support Enabled
DEBUG - 2011-05-06 12:44:40 --> URI Class Initialized
DEBUG - 2011-05-06 12:44:40 --> Router Class Initialized
DEBUG - 2011-05-06 12:44:40 --> Output Class Initialized
DEBUG - 2011-05-06 12:44:40 --> Input Class Initialized
DEBUG - 2011-05-06 12:44:40 --> Global POST and COOKIE data sanitized
DEBUG - 2011-05-06 12:44:40 --> Language Class Initialized
DEBUG - 2011-05-06 12:44:40 --> Loader Class Initialized
DEBUG - 2011-05-06 12:44:40 --> Controller Class Initialized
ERROR - 2011-05-06 12:44:40 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-05-06 12:44:40 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-05-06 12:44:40 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-05-06 12:44:40 --> Model Class Initialized
DEBUG - 2011-05-06 12:44:40 --> Model Class Initialized
DEBUG - 2011-05-06 12:44:40 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-05-06 12:44:40 --> Database Driver Class Initialized
DEBUG - 2011-05-06 12:44:40 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-05-06 12:44:40 --> Helper loaded: url_helper
DEBUG - 2011-05-06 12:44:40 --> File loaded: application/views/common/header.php
DEBUG - 2011-05-06 12:44:40 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-05-06 12:44:40 --> File loaded: application/views/common/footer.php
DEBUG - 2011-05-06 12:44:40 --> File loaded: application/views/layout/main.php
DEBUG - 2011-05-06 12:44:40 --> Final output sent to browser
DEBUG - 2011-05-06 12:44:40 --> Total execution time: 0.4367
DEBUG - 2011-05-06 12:44:41 --> Config Class Initialized
DEBUG - 2011-05-06 12:44:41 --> Hooks Class Initialized
DEBUG - 2011-05-06 12:44:41 --> Utf8 Class Initialized
DEBUG - 2011-05-06 12:44:41 --> UTF-8 Support Enabled
DEBUG - 2011-05-06 12:44:41 --> URI Class Initialized
DEBUG - 2011-05-06 12:44:41 --> Router Class Initialized
DEBUG - 2011-05-06 12:44:41 --> Output Class Initialized
DEBUG - 2011-05-06 12:44:41 --> Input Class Initialized
DEBUG - 2011-05-06 12:44:41 --> Global POST and COOKIE data sanitized
DEBUG - 2011-05-06 12:44:41 --> Language Class Initialized
DEBUG - 2011-05-06 12:44:41 --> Loader Class Initialized
DEBUG - 2011-05-06 12:44:41 --> Controller Class Initialized
DEBUG - 2011-05-06 12:44:41 --> Model Class Initialized
DEBUG - 2011-05-06 12:44:41 --> Model Class Initialized
DEBUG - 2011-05-06 12:44:41 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-05-06 12:44:41 --> Database Driver Class Initialized
DEBUG - 2011-05-06 12:44:42 --> Final output sent to browser
DEBUG - 2011-05-06 12:44:42 --> Total execution time: 0.7846
DEBUG - 2011-05-06 12:44:43 --> Config Class Initialized
DEBUG - 2011-05-06 12:44:43 --> Hooks Class Initialized
DEBUG - 2011-05-06 12:44:43 --> Utf8 Class Initialized
DEBUG - 2011-05-06 12:44:43 --> UTF-8 Support Enabled
DEBUG - 2011-05-06 12:44:43 --> URI Class Initialized
DEBUG - 2011-05-06 12:44:43 --> Router Class Initialized
ERROR - 2011-05-06 12:44:43 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-05-06 12:44:45 --> Config Class Initialized
DEBUG - 2011-05-06 12:44:45 --> Hooks Class Initialized
DEBUG - 2011-05-06 12:44:45 --> Utf8 Class Initialized
DEBUG - 2011-05-06 12:44:45 --> UTF-8 Support Enabled
DEBUG - 2011-05-06 12:44:45 --> URI Class Initialized
DEBUG - 2011-05-06 12:44:45 --> Router Class Initialized
ERROR - 2011-05-06 12:44:45 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-05-06 12:57:02 --> Config Class Initialized
DEBUG - 2011-05-06 12:57:02 --> Hooks Class Initialized
DEBUG - 2011-05-06 12:57:02 --> Utf8 Class Initialized
DEBUG - 2011-05-06 12:57:02 --> UTF-8 Support Enabled
DEBUG - 2011-05-06 12:57:02 --> URI Class Initialized
DEBUG - 2011-05-06 12:57:02 --> Router Class Initialized
DEBUG - 2011-05-06 12:57:02 --> Output Class Initialized
DEBUG - 2011-05-06 12:57:02 --> Input Class Initialized
DEBUG - 2011-05-06 12:57:02 --> Global POST and COOKIE data sanitized
DEBUG - 2011-05-06 12:57:02 --> Language Class Initialized
DEBUG - 2011-05-06 12:57:02 --> Loader Class Initialized
DEBUG - 2011-05-06 12:57:02 --> Controller Class Initialized
DEBUG - 2011-05-06 12:57:02 --> Model Class Initialized
DEBUG - 2011-05-06 12:57:02 --> Model Class Initialized
DEBUG - 2011-05-06 12:57:02 --> Model Class Initialized
DEBUG - 2011-05-06 12:57:02 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-05-06 12:57:02 --> Database Driver Class Initialized
DEBUG - 2011-05-06 12:57:02 --> File loaded: application/views/table/main.php
DEBUG - 2011-05-06 12:57:02 --> Helper loaded: url_helper
DEBUG - 2011-05-06 12:57:02 --> File loaded: application/views/common/header.php
DEBUG - 2011-05-06 12:57:02 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-05-06 12:57:02 --> File loaded: application/views/common/footer.php
DEBUG - 2011-05-06 12:57:02 --> File loaded: application/views/layout/main.php
DEBUG - 2011-05-06 12:57:02 --> Final output sent to browser
DEBUG - 2011-05-06 12:57:02 --> Total execution time: 0.4634
DEBUG - 2011-05-06 13:57:21 --> Config Class Initialized
DEBUG - 2011-05-06 13:57:21 --> Hooks Class Initialized
DEBUG - 2011-05-06 13:57:21 --> Utf8 Class Initialized
DEBUG - 2011-05-06 13:57:21 --> UTF-8 Support Enabled
DEBUG - 2011-05-06 13:57:21 --> URI Class Initialized
DEBUG - 2011-05-06 13:57:21 --> Router Class Initialized
DEBUG - 2011-05-06 13:57:21 --> Output Class Initialized
DEBUG - 2011-05-06 13:57:21 --> Input Class Initialized
DEBUG - 2011-05-06 13:57:21 --> Global POST and COOKIE data sanitized
DEBUG - 2011-05-06 13:57:21 --> Language Class Initialized
DEBUG - 2011-05-06 13:57:21 --> Loader Class Initialized
DEBUG - 2011-05-06 13:57:21 --> Controller Class Initialized
ERROR - 2011-05-06 13:57:21 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-05-06 13:57:21 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-05-06 13:57:21 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-05-06 13:57:21 --> Model Class Initialized
DEBUG - 2011-05-06 13:57:21 --> Model Class Initialized
DEBUG - 2011-05-06 13:57:21 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-05-06 13:57:21 --> Database Driver Class Initialized
DEBUG - 2011-05-06 13:57:21 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-05-06 13:57:21 --> Helper loaded: url_helper
DEBUG - 2011-05-06 13:57:21 --> File loaded: application/views/common/header.php
DEBUG - 2011-05-06 13:57:21 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-05-06 13:57:21 --> File loaded: application/views/common/footer.php
DEBUG - 2011-05-06 13:57:21 --> File loaded: application/views/layout/main.php
DEBUG - 2011-05-06 13:57:21 --> Final output sent to browser
DEBUG - 2011-05-06 13:57:21 --> Total execution time: 0.4079
DEBUG - 2011-05-06 13:57:21 --> Config Class Initialized
DEBUG - 2011-05-06 13:57:21 --> Hooks Class Initialized
DEBUG - 2011-05-06 13:57:21 --> Utf8 Class Initialized
DEBUG - 2011-05-06 13:57:21 --> UTF-8 Support Enabled
DEBUG - 2011-05-06 13:57:21 --> URI Class Initialized
DEBUG - 2011-05-06 13:57:21 --> Router Class Initialized
DEBUG - 2011-05-06 13:57:21 --> Output Class Initialized
DEBUG - 2011-05-06 13:57:21 --> Input Class Initialized
DEBUG - 2011-05-06 13:57:21 --> Global POST and COOKIE data sanitized
DEBUG - 2011-05-06 13:57:21 --> Language Class Initialized
DEBUG - 2011-05-06 13:57:21 --> Loader Class Initialized
DEBUG - 2011-05-06 13:57:21 --> Controller Class Initialized
DEBUG - 2011-05-06 13:57:21 --> Model Class Initialized
DEBUG - 2011-05-06 13:57:21 --> Model Class Initialized
DEBUG - 2011-05-06 13:57:21 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-05-06 13:57:21 --> Database Driver Class Initialized
DEBUG - 2011-05-06 13:57:22 --> Final output sent to browser
DEBUG - 2011-05-06 13:57:22 --> Total execution time: 0.7355
DEBUG - 2011-05-06 13:57:25 --> Config Class Initialized
DEBUG - 2011-05-06 13:57:25 --> Hooks Class Initialized
DEBUG - 2011-05-06 13:57:25 --> Utf8 Class Initialized
DEBUG - 2011-05-06 13:57:25 --> UTF-8 Support Enabled
DEBUG - 2011-05-06 13:57:25 --> URI Class Initialized
DEBUG - 2011-05-06 13:57:25 --> Router Class Initialized
ERROR - 2011-05-06 13:57:25 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-05-06 14:26:56 --> Config Class Initialized
DEBUG - 2011-05-06 14:26:56 --> Hooks Class Initialized
DEBUG - 2011-05-06 14:26:56 --> Utf8 Class Initialized
DEBUG - 2011-05-06 14:26:56 --> UTF-8 Support Enabled
DEBUG - 2011-05-06 14:26:56 --> URI Class Initialized
DEBUG - 2011-05-06 14:26:56 --> Router Class Initialized
DEBUG - 2011-05-06 14:26:56 --> Output Class Initialized
DEBUG - 2011-05-06 14:26:56 --> Input Class Initialized
DEBUG - 2011-05-06 14:26:56 --> Global POST and COOKIE data sanitized
DEBUG - 2011-05-06 14:26:56 --> Language Class Initialized
DEBUG - 2011-05-06 14:26:56 --> Loader Class Initialized
DEBUG - 2011-05-06 14:26:56 --> Controller Class Initialized
ERROR - 2011-05-06 14:26:56 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-05-06 14:26:56 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-05-06 14:26:56 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-05-06 14:26:56 --> Model Class Initialized
DEBUG - 2011-05-06 14:26:56 --> Model Class Initialized
DEBUG - 2011-05-06 14:26:56 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-05-06 14:26:56 --> Database Driver Class Initialized
DEBUG - 2011-05-06 14:26:57 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-05-06 14:26:57 --> Helper loaded: url_helper
DEBUG - 2011-05-06 14:26:57 --> File loaded: application/views/common/header.php
DEBUG - 2011-05-06 14:26:57 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-05-06 14:26:57 --> File loaded: application/views/common/footer.php
DEBUG - 2011-05-06 14:26:57 --> File loaded: application/views/layout/main.php
DEBUG - 2011-05-06 14:26:57 --> Final output sent to browser
DEBUG - 2011-05-06 14:26:57 --> Total execution time: 0.5889
DEBUG - 2011-05-06 15:50:13 --> Config Class Initialized
DEBUG - 2011-05-06 15:50:13 --> Hooks Class Initialized
DEBUG - 2011-05-06 15:50:13 --> Utf8 Class Initialized
DEBUG - 2011-05-06 15:50:13 --> UTF-8 Support Enabled
DEBUG - 2011-05-06 15:50:13 --> URI Class Initialized
DEBUG - 2011-05-06 15:50:13 --> Router Class Initialized
DEBUG - 2011-05-06 15:50:13 --> Output Class Initialized
DEBUG - 2011-05-06 15:50:14 --> Input Class Initialized
DEBUG - 2011-05-06 15:50:14 --> Global POST and COOKIE data sanitized
DEBUG - 2011-05-06 15:50:14 --> Language Class Initialized
DEBUG - 2011-05-06 15:50:14 --> Loader Class Initialized
DEBUG - 2011-05-06 15:50:14 --> Controller Class Initialized
DEBUG - 2011-05-06 15:50:15 --> Config Class Initialized
DEBUG - 2011-05-06 15:50:15 --> Hooks Class Initialized
DEBUG - 2011-05-06 15:50:15 --> Utf8 Class Initialized
DEBUG - 2011-05-06 15:50:15 --> UTF-8 Support Enabled
DEBUG - 2011-05-06 15:50:15 --> URI Class Initialized
DEBUG - 2011-05-06 15:50:15 --> Router Class Initialized
DEBUG - 2011-05-06 15:50:15 --> Output Class Initialized
DEBUG - 2011-05-06 15:50:15 --> Input Class Initialized
DEBUG - 2011-05-06 15:50:15 --> Global POST and COOKIE data sanitized
DEBUG - 2011-05-06 15:50:15 --> Language Class Initialized
DEBUG - 2011-05-06 15:50:15 --> Loader Class Initialized
DEBUG - 2011-05-06 15:50:15 --> Controller Class Initialized
DEBUG - 2011-05-06 15:50:15 --> Model Class Initialized
DEBUG - 2011-05-06 15:50:15 --> Model Class Initialized
DEBUG - 2011-05-06 15:50:15 --> Model Class Initialized
DEBUG - 2011-05-06 15:50:15 --> Model Class Initialized
DEBUG - 2011-05-06 15:50:15 --> Model Class Initialized
DEBUG - 2011-05-06 15:50:15 --> Model Class Initialized
DEBUG - 2011-05-06 15:50:15 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-05-06 15:50:15 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-05-06 15:50:16 --> Database Driver Class Initialized
DEBUG - 2011-05-06 15:50:16 --> Database Driver Class Initialized
DEBUG - 2011-05-06 15:50:16 --> File loaded: application/views/table/main.php
DEBUG - 2011-05-06 15:50:16 --> File loaded: application/views/table/main.php
DEBUG - 2011-05-06 15:50:17 --> Helper loaded: url_helper
DEBUG - 2011-05-06 15:50:17 --> Helper loaded: url_helper
DEBUG - 2011-05-06 15:50:17 --> File loaded: application/views/common/header.php
DEBUG - 2011-05-06 15:50:17 --> File loaded: application/views/common/header.php
DEBUG - 2011-05-06 15:50:17 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-05-06 15:50:17 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-05-06 15:50:17 --> File loaded: application/views/common/footer.php
DEBUG - 2011-05-06 15:50:17 --> File loaded: application/views/common/footer.php
DEBUG - 2011-05-06 15:50:17 --> File loaded: application/views/layout/main.php
DEBUG - 2011-05-06 15:50:17 --> File loaded: application/views/layout/main.php
DEBUG - 2011-05-06 15:50:17 --> Final output sent to browser
DEBUG - 2011-05-06 15:50:17 --> Final output sent to browser
DEBUG - 2011-05-06 15:50:17 --> Total execution time: 2.5767
DEBUG - 2011-05-06 15:50:17 --> Total execution time: 4.4213
DEBUG - 2011-05-06 15:50:23 --> Config Class Initialized
DEBUG - 2011-05-06 15:50:23 --> Hooks Class Initialized
DEBUG - 2011-05-06 15:50:23 --> Utf8 Class Initialized
DEBUG - 2011-05-06 15:50:23 --> UTF-8 Support Enabled
DEBUG - 2011-05-06 15:50:23 --> URI Class Initialized
DEBUG - 2011-05-06 15:50:23 --> Router Class Initialized
DEBUG - 2011-05-06 15:50:23 --> Config Class Initialized
DEBUG - 2011-05-06 15:50:23 --> Hooks Class Initialized
DEBUG - 2011-05-06 15:50:23 --> Utf8 Class Initialized
DEBUG - 2011-05-06 15:50:23 --> UTF-8 Support Enabled
DEBUG - 2011-05-06 15:50:23 --> URI Class Initialized
DEBUG - 2011-05-06 15:50:23 --> Router Class Initialized
DEBUG - 2011-05-06 15:50:23 --> Output Class Initialized
DEBUG - 2011-05-06 15:50:23 --> Output Class Initialized
DEBUG - 2011-05-06 15:50:23 --> Input Class Initialized
DEBUG - 2011-05-06 15:50:23 --> Input Class Initialized
DEBUG - 2011-05-06 15:50:23 --> Global POST and COOKIE data sanitized
DEBUG - 2011-05-06 15:50:23 --> Global POST and COOKIE data sanitized
DEBUG - 2011-05-06 15:50:23 --> Language Class Initialized
DEBUG - 2011-05-06 15:50:23 --> Language Class Initialized
DEBUG - 2011-05-06 15:50:23 --> Loader Class Initialized
DEBUG - 2011-05-06 15:50:23 --> Controller Class Initialized
DEBUG - 2011-05-06 15:50:23 --> Loader Class Initialized
DEBUG - 2011-05-06 15:50:23 --> Controller Class Initialized
ERROR - 2011-05-06 15:50:23 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-05-06 15:50:23 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-05-06 15:50:23 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-05-06 15:50:23 --> Model Class Initialized
DEBUG - 2011-05-06 15:50:23 --> Model Class Initialized
DEBUG - 2011-05-06 15:50:23 --> Database config for development environment is not found. Trying global config.
ERROR - 2011-05-06 15:50:23 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-05-06 15:50:23 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-05-06 15:50:23 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-05-06 15:50:23 --> Model Class Initialized
DEBUG - 2011-05-06 15:50:23 --> Model Class Initialized
DEBUG - 2011-05-06 15:50:23 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-05-06 15:50:23 --> Database Driver Class Initialized
DEBUG - 2011-05-06 15:50:23 --> Database Driver Class Initialized
DEBUG - 2011-05-06 15:50:23 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-05-06 15:50:23 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-05-06 15:50:23 --> Helper loaded: url_helper
DEBUG - 2011-05-06 15:50:23 --> File loaded: application/views/common/header.php
DEBUG - 2011-05-06 15:50:23 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-05-06 15:50:23 --> File loaded: application/views/common/footer.php
DEBUG - 2011-05-06 15:50:23 --> File loaded: application/views/layout/main.php
DEBUG - 2011-05-06 15:50:23 --> Final output sent to browser
DEBUG - 2011-05-06 15:50:23 --> Total execution time: 0.9206
DEBUG - 2011-05-06 15:50:23 --> Helper loaded: url_helper
DEBUG - 2011-05-06 15:50:23 --> File loaded: application/views/common/header.php
DEBUG - 2011-05-06 15:50:23 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-05-06 15:50:23 --> File loaded: application/views/common/footer.php
DEBUG - 2011-05-06 15:50:23 --> File loaded: application/views/layout/main.php
DEBUG - 2011-05-06 15:50:23 --> Final output sent to browser
DEBUG - 2011-05-06 15:50:23 --> Total execution time: 0.9422
DEBUG - 2011-05-06 16:18:58 --> Config Class Initialized
DEBUG - 2011-05-06 16:18:58 --> Hooks Class Initialized
DEBUG - 2011-05-06 16:18:58 --> Utf8 Class Initialized
DEBUG - 2011-05-06 16:18:58 --> UTF-8 Support Enabled
DEBUG - 2011-05-06 16:18:58 --> URI Class Initialized
DEBUG - 2011-05-06 16:18:58 --> Router Class Initialized
DEBUG - 2011-05-06 16:18:58 --> Output Class Initialized
DEBUG - 2011-05-06 16:18:58 --> Input Class Initialized
DEBUG - 2011-05-06 16:18:58 --> Global POST and COOKIE data sanitized
DEBUG - 2011-05-06 16:18:58 --> Language Class Initialized
DEBUG - 2011-05-06 16:18:58 --> Loader Class Initialized
DEBUG - 2011-05-06 16:18:58 --> Controller Class Initialized
ERROR - 2011-05-06 16:18:58 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-05-06 16:18:58 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-05-06 16:18:58 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-05-06 16:18:58 --> Model Class Initialized
DEBUG - 2011-05-06 16:18:58 --> Model Class Initialized
DEBUG - 2011-05-06 16:18:58 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-05-06 16:18:58 --> Database Driver Class Initialized
DEBUG - 2011-05-06 16:18:58 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-05-06 16:18:58 --> Helper loaded: url_helper
DEBUG - 2011-05-06 16:18:58 --> File loaded: application/views/common/header.php
DEBUG - 2011-05-06 16:18:58 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-05-06 16:18:58 --> File loaded: application/views/common/footer.php
DEBUG - 2011-05-06 16:18:58 --> File loaded: application/views/layout/main.php
DEBUG - 2011-05-06 16:18:58 --> Final output sent to browser
DEBUG - 2011-05-06 16:18:58 --> Total execution time: 0.1946
DEBUG - 2011-05-06 16:18:59 --> Config Class Initialized
DEBUG - 2011-05-06 16:18:59 --> Hooks Class Initialized
DEBUG - 2011-05-06 16:18:59 --> Utf8 Class Initialized
DEBUG - 2011-05-06 16:18:59 --> UTF-8 Support Enabled
DEBUG - 2011-05-06 16:18:59 --> URI Class Initialized
DEBUG - 2011-05-06 16:18:59 --> Router Class Initialized
DEBUG - 2011-05-06 16:18:59 --> Output Class Initialized
DEBUG - 2011-05-06 16:18:59 --> Input Class Initialized
DEBUG - 2011-05-06 16:18:59 --> Global POST and COOKIE data sanitized
DEBUG - 2011-05-06 16:18:59 --> Language Class Initialized
DEBUG - 2011-05-06 16:18:59 --> Loader Class Initialized
DEBUG - 2011-05-06 16:18:59 --> Controller Class Initialized
DEBUG - 2011-05-06 16:18:59 --> Model Class Initialized
DEBUG - 2011-05-06 16:18:59 --> Model Class Initialized
DEBUG - 2011-05-06 16:18:59 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-05-06 16:18:59 --> Database Driver Class Initialized
DEBUG - 2011-05-06 16:19:00 --> Final output sent to browser
DEBUG - 2011-05-06 16:19:00 --> Total execution time: 0.9696
DEBUG - 2011-05-06 16:19:02 --> Config Class Initialized
DEBUG - 2011-05-06 16:19:02 --> Hooks Class Initialized
DEBUG - 2011-05-06 16:19:02 --> Utf8 Class Initialized
DEBUG - 2011-05-06 16:19:02 --> UTF-8 Support Enabled
DEBUG - 2011-05-06 16:19:02 --> URI Class Initialized
DEBUG - 2011-05-06 16:19:02 --> Router Class Initialized
ERROR - 2011-05-06 16:19:02 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-05-06 16:19:02 --> Config Class Initialized
DEBUG - 2011-05-06 16:19:02 --> Hooks Class Initialized
DEBUG - 2011-05-06 16:19:02 --> Utf8 Class Initialized
DEBUG - 2011-05-06 16:19:02 --> UTF-8 Support Enabled
DEBUG - 2011-05-06 16:19:02 --> URI Class Initialized
DEBUG - 2011-05-06 16:19:02 --> Router Class Initialized
ERROR - 2011-05-06 16:19:02 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-05-06 16:32:45 --> Config Class Initialized
DEBUG - 2011-05-06 16:32:45 --> Hooks Class Initialized
DEBUG - 2011-05-06 16:32:45 --> Utf8 Class Initialized
DEBUG - 2011-05-06 16:32:45 --> UTF-8 Support Enabled
DEBUG - 2011-05-06 16:32:45 --> URI Class Initialized
DEBUG - 2011-05-06 16:32:45 --> Router Class Initialized
DEBUG - 2011-05-06 16:32:45 --> Config Class Initialized
DEBUG - 2011-05-06 16:32:45 --> Hooks Class Initialized
DEBUG - 2011-05-06 16:32:45 --> Utf8 Class Initialized
DEBUG - 2011-05-06 16:32:45 --> UTF-8 Support Enabled
DEBUG - 2011-05-06 16:32:45 --> URI Class Initialized
DEBUG - 2011-05-06 16:32:45 --> Router Class Initialized
DEBUG - 2011-05-06 16:32:45 --> No URI present. Default controller set.
DEBUG - 2011-05-06 16:32:45 --> Output Class Initialized
DEBUG - 2011-05-06 16:32:45 --> Input Class Initialized
DEBUG - 2011-05-06 16:32:45 --> Global POST and COOKIE data sanitized
DEBUG - 2011-05-06 16:32:45 --> Language Class Initialized
DEBUG - 2011-05-06 16:32:45 --> Loader Class Initialized
DEBUG - 2011-05-06 16:32:45 --> Controller Class Initialized
DEBUG - 2011-05-06 16:32:45 --> No URI present. Default controller set.
DEBUG - 2011-05-06 16:32:45 --> Output Class Initialized
DEBUG - 2011-05-06 16:32:45 --> Input Class Initialized
DEBUG - 2011-05-06 16:32:45 --> Global POST and COOKIE data sanitized
DEBUG - 2011-05-06 16:32:45 --> Language Class Initialized
DEBUG - 2011-05-06 16:32:45 --> Loader Class Initialized
DEBUG - 2011-05-06 16:32:45 --> Controller Class Initialized
DEBUG - 2011-05-06 16:32:45 --> File loaded: application/views/splash/main.php
DEBUG - 2011-05-06 16:32:45 --> File loaded: application/views/splash/main.php
DEBUG - 2011-05-06 16:32:45 --> Helper loaded: url_helper
DEBUG - 2011-05-06 16:32:45 --> File loaded: application/views/common/header.php
DEBUG - 2011-05-06 16:32:45 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-05-06 16:32:45 --> File loaded: application/views/common/footer.php
DEBUG - 2011-05-06 16:32:45 --> File loaded: application/views/layout/main.php
DEBUG - 2011-05-06 16:32:45 --> Final output sent to browser
DEBUG - 2011-05-06 16:32:45 --> Total execution time: 0.0906
DEBUG - 2011-05-06 16:32:45 --> Helper loaded: url_helper
DEBUG - 2011-05-06 16:32:45 --> File loaded: application/views/common/header.php
DEBUG - 2011-05-06 16:32:45 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-05-06 16:32:45 --> File loaded: application/views/common/footer.php
DEBUG - 2011-05-06 16:32:45 --> File loaded: application/views/layout/main.php
DEBUG - 2011-05-06 16:32:45 --> Final output sent to browser
DEBUG - 2011-05-06 16:32:45 --> Total execution time: 0.0865
DEBUG - 2011-05-06 18:02:30 --> Config Class Initialized
DEBUG - 2011-05-06 18:02:30 --> Hooks Class Initialized
DEBUG - 2011-05-06 18:02:30 --> Utf8 Class Initialized
DEBUG - 2011-05-06 18:02:30 --> UTF-8 Support Enabled
DEBUG - 2011-05-06 18:02:30 --> URI Class Initialized
DEBUG - 2011-05-06 18:02:30 --> Router Class Initialized
DEBUG - 2011-05-06 18:02:30 --> Output Class Initialized
DEBUG - 2011-05-06 18:02:30 --> Input Class Initialized
DEBUG - 2011-05-06 18:02:30 --> Global POST and COOKIE data sanitized
DEBUG - 2011-05-06 18:02:30 --> Language Class Initialized
DEBUG - 2011-05-06 18:02:30 --> Loader Class Initialized
DEBUG - 2011-05-06 18:02:30 --> Controller Class Initialized
ERROR - 2011-05-06 18:02:30 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-05-06 18:02:30 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-05-06 18:02:30 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-05-06 18:02:30 --> Model Class Initialized
DEBUG - 2011-05-06 18:02:30 --> Model Class Initialized
DEBUG - 2011-05-06 18:02:30 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-05-06 18:02:30 --> Database Driver Class Initialized
DEBUG - 2011-05-06 18:02:31 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-05-06 18:02:31 --> Helper loaded: url_helper
DEBUG - 2011-05-06 18:02:31 --> File loaded: application/views/common/header.php
DEBUG - 2011-05-06 18:02:31 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-05-06 18:02:31 --> File loaded: application/views/common/footer.php
DEBUG - 2011-05-06 18:02:31 --> File loaded: application/views/layout/main.php
DEBUG - 2011-05-06 18:02:31 --> Final output sent to browser
DEBUG - 2011-05-06 18:02:31 --> Total execution time: 1.0904
DEBUG - 2011-05-06 18:02:32 --> Config Class Initialized
DEBUG - 2011-05-06 18:02:32 --> Hooks Class Initialized
DEBUG - 2011-05-06 18:02:32 --> Utf8 Class Initialized
DEBUG - 2011-05-06 18:02:32 --> UTF-8 Support Enabled
DEBUG - 2011-05-06 18:02:32 --> URI Class Initialized
DEBUG - 2011-05-06 18:02:32 --> Router Class Initialized
DEBUG - 2011-05-06 18:02:32 --> Output Class Initialized
DEBUG - 2011-05-06 18:02:32 --> Input Class Initialized
DEBUG - 2011-05-06 18:02:32 --> Global POST and COOKIE data sanitized
DEBUG - 2011-05-06 18:02:32 --> Language Class Initialized
DEBUG - 2011-05-06 18:02:32 --> Loader Class Initialized
DEBUG - 2011-05-06 18:02:32 --> Controller Class Initialized
DEBUG - 2011-05-06 18:02:32 --> Model Class Initialized
DEBUG - 2011-05-06 18:02:32 --> Model Class Initialized
DEBUG - 2011-05-06 18:02:32 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-05-06 18:02:32 --> Database Driver Class Initialized
DEBUG - 2011-05-06 18:02:33 --> Final output sent to browser
DEBUG - 2011-05-06 18:02:33 --> Total execution time: 1.1450
DEBUG - 2011-05-06 18:25:05 --> Config Class Initialized
DEBUG - 2011-05-06 18:25:06 --> Hooks Class Initialized
DEBUG - 2011-05-06 18:25:06 --> Utf8 Class Initialized
DEBUG - 2011-05-06 18:25:06 --> UTF-8 Support Enabled
DEBUG - 2011-05-06 18:25:06 --> URI Class Initialized
DEBUG - 2011-05-06 18:25:06 --> Router Class Initialized
DEBUG - 2011-05-06 18:25:06 --> Output Class Initialized
DEBUG - 2011-05-06 18:25:06 --> Input Class Initialized
DEBUG - 2011-05-06 18:25:06 --> Global POST and COOKIE data sanitized
DEBUG - 2011-05-06 18:25:06 --> Language Class Initialized
DEBUG - 2011-05-06 18:25:06 --> Loader Class Initialized
DEBUG - 2011-05-06 18:25:06 --> Controller Class Initialized
DEBUG - 2011-05-06 18:25:06 --> Model Class Initialized
DEBUG - 2011-05-06 18:25:06 --> Model Class Initialized
DEBUG - 2011-05-06 18:25:06 --> Model Class Initialized
DEBUG - 2011-05-06 18:25:06 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-05-06 18:25:06 --> Database Driver Class Initialized
DEBUG - 2011-05-06 18:25:06 --> File loaded: application/views/table/main.php
DEBUG - 2011-05-06 18:25:06 --> Helper loaded: url_helper
DEBUG - 2011-05-06 18:25:06 --> File loaded: application/views/common/header.php
DEBUG - 2011-05-06 18:25:06 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-05-06 18:25:06 --> File loaded: application/views/common/footer.php
DEBUG - 2011-05-06 18:25:06 --> File loaded: application/views/layout/main.php
DEBUG - 2011-05-06 18:25:06 --> Final output sent to browser
DEBUG - 2011-05-06 18:25:06 --> Total execution time: 0.8474
DEBUG - 2011-05-06 18:25:30 --> Config Class Initialized
DEBUG - 2011-05-06 18:25:30 --> Hooks Class Initialized
DEBUG - 2011-05-06 18:25:30 --> Utf8 Class Initialized
DEBUG - 2011-05-06 18:25:30 --> UTF-8 Support Enabled
DEBUG - 2011-05-06 18:25:30 --> URI Class Initialized
DEBUG - 2011-05-06 18:25:30 --> Router Class Initialized
DEBUG - 2011-05-06 18:25:30 --> Output Class Initialized
DEBUG - 2011-05-06 18:25:30 --> Input Class Initialized
DEBUG - 2011-05-06 18:25:30 --> Global POST and COOKIE data sanitized
DEBUG - 2011-05-06 18:25:30 --> Language Class Initialized
DEBUG - 2011-05-06 18:25:30 --> Loader Class Initialized
DEBUG - 2011-05-06 18:25:30 --> Controller Class Initialized
DEBUG - 2011-05-06 18:25:30 --> Model Class Initialized
DEBUG - 2011-05-06 18:25:30 --> Model Class Initialized
DEBUG - 2011-05-06 18:25:30 --> Model Class Initialized
DEBUG - 2011-05-06 18:25:30 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-05-06 18:25:30 --> Database Driver Class Initialized
DEBUG - 2011-05-06 18:25:30 --> File loaded: application/views/table/main.php
DEBUG - 2011-05-06 18:25:30 --> Helper loaded: url_helper
DEBUG - 2011-05-06 18:25:30 --> File loaded: application/views/common/header.php
DEBUG - 2011-05-06 18:25:30 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-05-06 18:25:30 --> File loaded: application/views/common/footer.php
DEBUG - 2011-05-06 18:25:30 --> File loaded: application/views/layout/main.php
DEBUG - 2011-05-06 18:25:30 --> Final output sent to browser
DEBUG - 2011-05-06 18:25:30 --> Total execution time: 0.0435
DEBUG - 2011-05-06 21:15:13 --> Config Class Initialized
DEBUG - 2011-05-06 21:15:14 --> Hooks Class Initialized
DEBUG - 2011-05-06 21:15:14 --> Utf8 Class Initialized
DEBUG - 2011-05-06 21:15:14 --> UTF-8 Support Enabled
DEBUG - 2011-05-06 21:15:14 --> URI Class Initialized
DEBUG - 2011-05-06 21:15:14 --> Router Class Initialized
DEBUG - 2011-05-06 21:15:14 --> Output Class Initialized
DEBUG - 2011-05-06 21:15:14 --> Input Class Initialized
DEBUG - 2011-05-06 21:15:14 --> Global POST and COOKIE data sanitized
DEBUG - 2011-05-06 21:15:14 --> Language Class Initialized
DEBUG - 2011-05-06 21:15:14 --> Loader Class Initialized
DEBUG - 2011-05-06 21:15:14 --> Controller Class Initialized
DEBUG - 2011-05-06 21:15:15 --> Model Class Initialized
DEBUG - 2011-05-06 21:15:15 --> Model Class Initialized
DEBUG - 2011-05-06 21:15:15 --> Model Class Initialized
DEBUG - 2011-05-06 21:15:15 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-05-06 21:15:16 --> Database Driver Class Initialized
DEBUG - 2011-05-06 21:15:18 --> File loaded: application/views/table/main.php
DEBUG - 2011-05-06 21:15:20 --> Helper loaded: url_helper
DEBUG - 2011-05-06 21:15:20 --> File loaded: application/views/common/header.php
DEBUG - 2011-05-06 21:15:20 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-05-06 21:15:20 --> File loaded: application/views/common/footer.php
DEBUG - 2011-05-06 21:15:20 --> File loaded: application/views/layout/main.php
DEBUG - 2011-05-06 21:15:20 --> Final output sent to browser
DEBUG - 2011-05-06 21:15:20 --> Total execution time: 7.5718
DEBUG - 2011-05-06 21:15:21 --> Config Class Initialized
DEBUG - 2011-05-06 21:15:21 --> Hooks Class Initialized
DEBUG - 2011-05-06 21:15:21 --> Utf8 Class Initialized
DEBUG - 2011-05-06 21:15:21 --> UTF-8 Support Enabled
DEBUG - 2011-05-06 21:15:21 --> URI Class Initialized
DEBUG - 2011-05-06 21:15:21 --> Router Class Initialized
DEBUG - 2011-05-06 21:15:22 --> Output Class Initialized
DEBUG - 2011-05-06 21:15:22 --> Input Class Initialized
DEBUG - 2011-05-06 21:15:22 --> Global POST and COOKIE data sanitized
DEBUG - 2011-05-06 21:15:22 --> Language Class Initialized
DEBUG - 2011-05-06 21:15:22 --> Loader Class Initialized
DEBUG - 2011-05-06 21:15:22 --> Controller Class Initialized
ERROR - 2011-05-06 21:15:23 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-05-06 21:15:23 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-05-06 21:15:23 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-05-06 21:15:23 --> Model Class Initialized
DEBUG - 2011-05-06 21:15:23 --> Model Class Initialized
DEBUG - 2011-05-06 21:15:23 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-05-06 21:15:23 --> Database Driver Class Initialized
DEBUG - 2011-05-06 21:15:23 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-05-06 21:15:23 --> Helper loaded: url_helper
DEBUG - 2011-05-06 21:15:23 --> File loaded: application/views/common/header.php
DEBUG - 2011-05-06 21:15:23 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-05-06 21:15:23 --> File loaded: application/views/common/footer.php
DEBUG - 2011-05-06 21:15:23 --> File loaded: application/views/layout/main.php
DEBUG - 2011-05-06 21:15:23 --> Final output sent to browser
DEBUG - 2011-05-06 21:15:23 --> Total execution time: 1.2014
DEBUG - 2011-05-06 21:48:55 --> Config Class Initialized
DEBUG - 2011-05-06 21:48:55 --> Hooks Class Initialized
DEBUG - 2011-05-06 21:48:55 --> Utf8 Class Initialized
DEBUG - 2011-05-06 21:48:55 --> UTF-8 Support Enabled
DEBUG - 2011-05-06 21:48:55 --> URI Class Initialized
DEBUG - 2011-05-06 21:48:55 --> Router Class Initialized
DEBUG - 2011-05-06 21:48:55 --> Output Class Initialized
DEBUG - 2011-05-06 21:48:55 --> Input Class Initialized
DEBUG - 2011-05-06 21:48:55 --> Global POST and COOKIE data sanitized
DEBUG - 2011-05-06 21:48:55 --> Language Class Initialized
DEBUG - 2011-05-06 21:48:55 --> Loader Class Initialized
DEBUG - 2011-05-06 21:48:55 --> Controller Class Initialized
ERROR - 2011-05-06 21:48:55 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-05-06 21:48:55 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-05-06 21:48:55 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-05-06 21:48:55 --> Model Class Initialized
DEBUG - 2011-05-06 21:48:55 --> Model Class Initialized
DEBUG - 2011-05-06 21:48:55 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-05-06 21:48:55 --> Database Driver Class Initialized
DEBUG - 2011-05-06 21:48:55 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-05-06 21:48:55 --> Helper loaded: url_helper
DEBUG - 2011-05-06 21:48:55 --> File loaded: application/views/common/header.php
DEBUG - 2011-05-06 21:48:55 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-05-06 21:48:55 --> File loaded: application/views/common/footer.php
DEBUG - 2011-05-06 21:48:55 --> File loaded: application/views/layout/main.php
DEBUG - 2011-05-06 21:48:55 --> Final output sent to browser
DEBUG - 2011-05-06 21:48:55 --> Total execution time: 0.0775
DEBUG - 2011-05-06 21:49:00 --> Config Class Initialized
DEBUG - 2011-05-06 21:49:00 --> Hooks Class Initialized
DEBUG - 2011-05-06 21:49:00 --> Utf8 Class Initialized
DEBUG - 2011-05-06 21:49:00 --> UTF-8 Support Enabled
DEBUG - 2011-05-06 21:49:00 --> URI Class Initialized
DEBUG - 2011-05-06 21:49:00 --> Router Class Initialized
DEBUG - 2011-05-06 21:49:00 --> Output Class Initialized
DEBUG - 2011-05-06 21:49:00 --> Input Class Initialized
DEBUG - 2011-05-06 21:49:00 --> Global POST and COOKIE data sanitized
DEBUG - 2011-05-06 21:49:00 --> Language Class Initialized
DEBUG - 2011-05-06 21:49:00 --> Loader Class Initialized
DEBUG - 2011-05-06 21:49:00 --> Controller Class Initialized
DEBUG - 2011-05-06 21:49:00 --> Model Class Initialized
DEBUG - 2011-05-06 21:49:00 --> Model Class Initialized
DEBUG - 2011-05-06 21:49:00 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-05-06 21:49:00 --> Database Driver Class Initialized
DEBUG - 2011-05-06 21:49:01 --> Final output sent to browser
DEBUG - 2011-05-06 21:49:01 --> Total execution time: 0.7358
DEBUG - 2011-05-06 21:49:03 --> Config Class Initialized
DEBUG - 2011-05-06 21:49:03 --> Hooks Class Initialized
DEBUG - 2011-05-06 21:49:03 --> Utf8 Class Initialized
DEBUG - 2011-05-06 21:49:03 --> UTF-8 Support Enabled
DEBUG - 2011-05-06 21:49:03 --> URI Class Initialized
DEBUG - 2011-05-06 21:49:03 --> Router Class Initialized
ERROR - 2011-05-06 21:49:03 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-05-06 23:49:58 --> Config Class Initialized
DEBUG - 2011-05-06 23:49:58 --> Hooks Class Initialized
DEBUG - 2011-05-06 23:49:58 --> Utf8 Class Initialized
DEBUG - 2011-05-06 23:49:58 --> UTF-8 Support Enabled
DEBUG - 2011-05-06 23:49:58 --> URI Class Initialized
DEBUG - 2011-05-06 23:49:58 --> Router Class Initialized
ERROR - 2011-05-06 23:49:58 --> 404 Page Not Found --> robots.txt
DEBUG - 2011-05-06 23:49:58 --> Config Class Initialized
DEBUG - 2011-05-06 23:49:58 --> Hooks Class Initialized
DEBUG - 2011-05-06 23:49:58 --> Utf8 Class Initialized
DEBUG - 2011-05-06 23:49:58 --> UTF-8 Support Enabled
DEBUG - 2011-05-06 23:49:58 --> URI Class Initialized
DEBUG - 2011-05-06 23:49:58 --> Router Class Initialized
DEBUG - 2011-05-06 23:49:58 --> Output Class Initialized
DEBUG - 2011-05-06 23:49:58 --> Input Class Initialized
DEBUG - 2011-05-06 23:49:58 --> Global POST and COOKIE data sanitized
DEBUG - 2011-05-06 23:49:58 --> Language Class Initialized
DEBUG - 2011-05-06 23:49:58 --> Loader Class Initialized
DEBUG - 2011-05-06 23:49:58 --> Controller Class Initialized
ERROR - 2011-05-06 23:49:58 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-05-06 23:49:58 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-05-06 23:49:58 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-05-06 23:49:58 --> Model Class Initialized
DEBUG - 2011-05-06 23:49:58 --> Model Class Initialized
DEBUG - 2011-05-06 23:49:58 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-05-06 23:49:58 --> Database Driver Class Initialized
DEBUG - 2011-05-06 23:49:58 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-05-06 23:49:58 --> Helper loaded: url_helper
DEBUG - 2011-05-06 23:49:58 --> File loaded: application/views/common/header.php
DEBUG - 2011-05-06 23:49:58 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-05-06 23:49:58 --> File loaded: application/views/common/footer.php
DEBUG - 2011-05-06 23:49:58 --> File loaded: application/views/layout/main.php
DEBUG - 2011-05-06 23:49:58 --> Final output sent to browser
DEBUG - 2011-05-06 23:49:58 --> Total execution time: 0.3273

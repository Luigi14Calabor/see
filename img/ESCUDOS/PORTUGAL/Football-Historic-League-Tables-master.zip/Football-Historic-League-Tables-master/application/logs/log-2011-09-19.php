<?php  if ( ! defined('BASEPATH')) exit('No direct script access allowed'); ?>

DEBUG - 2011-09-19 01:39:57 --> Config Class Initialized
DEBUG - 2011-09-19 01:39:57 --> Hooks Class Initialized
DEBUG - 2011-09-19 01:39:57 --> Utf8 Class Initialized
DEBUG - 2011-09-19 01:39:57 --> UTF-8 Support Enabled
DEBUG - 2011-09-19 01:39:57 --> URI Class Initialized
DEBUG - 2011-09-19 01:39:57 --> Router Class Initialized
DEBUG - 2011-09-19 01:39:57 --> No URI present. Default controller set.
DEBUG - 2011-09-19 01:39:57 --> Output Class Initialized
DEBUG - 2011-09-19 01:39:57 --> Input Class Initialized
DEBUG - 2011-09-19 01:39:57 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-19 01:39:57 --> Language Class Initialized
DEBUG - 2011-09-19 01:39:57 --> Loader Class Initialized
DEBUG - 2011-09-19 01:39:57 --> Controller Class Initialized
DEBUG - 2011-09-19 01:39:57 --> File loaded: application/views/splash/main.php
DEBUG - 2011-09-19 01:39:57 --> Helper loaded: url_helper
DEBUG - 2011-09-19 01:39:57 --> File loaded: application/views/common/header.php
DEBUG - 2011-09-19 01:39:57 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-09-19 01:39:57 --> File loaded: application/views/common/footer.php
DEBUG - 2011-09-19 01:39:57 --> File loaded: application/views/layout/main.php
DEBUG - 2011-09-19 01:39:57 --> Final output sent to browser
DEBUG - 2011-09-19 01:39:57 --> Total execution time: 0.1380
DEBUG - 2011-09-19 01:54:07 --> Config Class Initialized
DEBUG - 2011-09-19 01:54:07 --> Hooks Class Initialized
DEBUG - 2011-09-19 01:54:07 --> Utf8 Class Initialized
DEBUG - 2011-09-19 01:54:07 --> UTF-8 Support Enabled
DEBUG - 2011-09-19 01:54:07 --> URI Class Initialized
DEBUG - 2011-09-19 01:54:07 --> Router Class Initialized
DEBUG - 2011-09-19 01:54:07 --> Output Class Initialized
DEBUG - 2011-09-19 01:54:07 --> Input Class Initialized
DEBUG - 2011-09-19 01:54:07 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-19 01:54:07 --> Language Class Initialized
DEBUG - 2011-09-19 01:54:07 --> Loader Class Initialized
DEBUG - 2011-09-19 01:54:07 --> Controller Class Initialized
DEBUG - 2011-09-19 01:54:07 --> Model Class Initialized
DEBUG - 2011-09-19 01:54:07 --> Model Class Initialized
DEBUG - 2011-09-19 01:54:07 --> Model Class Initialized
DEBUG - 2011-09-19 01:54:07 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-19 01:54:07 --> Database Driver Class Initialized
DEBUG - 2011-09-19 01:54:11 --> File loaded: application/views/table/main.php
DEBUG - 2011-09-19 01:54:11 --> Helper loaded: url_helper
DEBUG - 2011-09-19 01:54:11 --> File loaded: application/views/common/header.php
DEBUG - 2011-09-19 01:54:11 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-09-19 01:54:11 --> File loaded: application/views/common/footer.php
DEBUG - 2011-09-19 01:54:11 --> File loaded: application/views/layout/main.php
DEBUG - 2011-09-19 01:54:11 --> Final output sent to browser
DEBUG - 2011-09-19 01:54:11 --> Total execution time: 4.6270
DEBUG - 2011-09-19 01:54:12 --> Config Class Initialized
DEBUG - 2011-09-19 01:54:12 --> Hooks Class Initialized
DEBUG - 2011-09-19 01:54:12 --> Utf8 Class Initialized
DEBUG - 2011-09-19 01:54:12 --> UTF-8 Support Enabled
DEBUG - 2011-09-19 01:54:12 --> URI Class Initialized
DEBUG - 2011-09-19 01:54:12 --> Router Class Initialized
DEBUG - 2011-09-19 01:54:12 --> Output Class Initialized
DEBUG - 2011-09-19 01:54:12 --> Input Class Initialized
DEBUG - 2011-09-19 01:54:12 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-19 01:54:12 --> Language Class Initialized
DEBUG - 2011-09-19 01:54:12 --> Loader Class Initialized
DEBUG - 2011-09-19 01:54:12 --> Controller Class Initialized
ERROR - 2011-09-19 01:54:12 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-09-19 01:54:12 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-09-19 01:54:12 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-09-19 01:54:12 --> Model Class Initialized
DEBUG - 2011-09-19 01:54:12 --> Model Class Initialized
DEBUG - 2011-09-19 01:54:12 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-19 01:54:12 --> Database Driver Class Initialized
DEBUG - 2011-09-19 01:54:12 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-09-19 01:54:12 --> Helper loaded: url_helper
DEBUG - 2011-09-19 01:54:12 --> File loaded: application/views/common/header.php
DEBUG - 2011-09-19 01:54:12 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-09-19 01:54:12 --> File loaded: application/views/common/footer.php
DEBUG - 2011-09-19 01:54:12 --> File loaded: application/views/layout/main.php
DEBUG - 2011-09-19 01:54:12 --> Final output sent to browser
DEBUG - 2011-09-19 01:54:12 --> Total execution time: 0.0980
DEBUG - 2011-09-19 01:54:13 --> Config Class Initialized
DEBUG - 2011-09-19 01:54:13 --> Hooks Class Initialized
DEBUG - 2011-09-19 01:54:13 --> Utf8 Class Initialized
DEBUG - 2011-09-19 01:54:13 --> UTF-8 Support Enabled
DEBUG - 2011-09-19 01:54:13 --> URI Class Initialized
DEBUG - 2011-09-19 01:54:13 --> Router Class Initialized
DEBUG - 2011-09-19 01:54:13 --> Output Class Initialized
DEBUG - 2011-09-19 01:54:13 --> Input Class Initialized
DEBUG - 2011-09-19 01:54:13 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-19 01:54:13 --> Language Class Initialized
DEBUG - 2011-09-19 01:54:13 --> Loader Class Initialized
DEBUG - 2011-09-19 01:54:13 --> Controller Class Initialized
DEBUG - 2011-09-19 01:54:13 --> Model Class Initialized
DEBUG - 2011-09-19 01:54:13 --> Model Class Initialized
DEBUG - 2011-09-19 01:54:13 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-19 01:54:13 --> Database Driver Class Initialized
DEBUG - 2011-09-19 01:54:14 --> Final output sent to browser
DEBUG - 2011-09-19 01:54:14 --> Total execution time: 0.6305
DEBUG - 2011-09-19 01:54:15 --> Config Class Initialized
DEBUG - 2011-09-19 01:54:15 --> Hooks Class Initialized
DEBUG - 2011-09-19 01:54:15 --> Utf8 Class Initialized
DEBUG - 2011-09-19 01:54:15 --> UTF-8 Support Enabled
DEBUG - 2011-09-19 01:54:15 --> URI Class Initialized
DEBUG - 2011-09-19 01:54:15 --> Router Class Initialized
ERROR - 2011-09-19 01:54:15 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-09-19 01:54:15 --> Config Class Initialized
DEBUG - 2011-09-19 01:54:15 --> Hooks Class Initialized
DEBUG - 2011-09-19 01:54:15 --> Utf8 Class Initialized
DEBUG - 2011-09-19 01:54:15 --> UTF-8 Support Enabled
DEBUG - 2011-09-19 01:54:15 --> URI Class Initialized
DEBUG - 2011-09-19 01:54:15 --> Router Class Initialized
ERROR - 2011-09-19 01:54:15 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-09-19 01:54:42 --> Config Class Initialized
DEBUG - 2011-09-19 01:54:42 --> Hooks Class Initialized
DEBUG - 2011-09-19 01:54:42 --> Utf8 Class Initialized
DEBUG - 2011-09-19 01:54:42 --> UTF-8 Support Enabled
DEBUG - 2011-09-19 01:54:42 --> URI Class Initialized
DEBUG - 2011-09-19 01:54:42 --> Router Class Initialized
DEBUG - 2011-09-19 01:54:42 --> Output Class Initialized
DEBUG - 2011-09-19 01:54:42 --> Input Class Initialized
DEBUG - 2011-09-19 01:54:42 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-19 01:54:42 --> Language Class Initialized
DEBUG - 2011-09-19 01:54:42 --> Loader Class Initialized
DEBUG - 2011-09-19 01:54:42 --> Controller Class Initialized
DEBUG - 2011-09-19 01:54:42 --> Model Class Initialized
DEBUG - 2011-09-19 01:54:42 --> Model Class Initialized
DEBUG - 2011-09-19 01:54:42 --> Model Class Initialized
DEBUG - 2011-09-19 01:54:42 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-19 01:54:42 --> Database Driver Class Initialized
DEBUG - 2011-09-19 01:54:44 --> File loaded: application/views/table/main.php
DEBUG - 2011-09-19 01:54:44 --> Helper loaded: url_helper
DEBUG - 2011-09-19 01:54:44 --> File loaded: application/views/common/header.php
DEBUG - 2011-09-19 01:54:44 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-09-19 01:54:44 --> File loaded: application/views/common/footer.php
DEBUG - 2011-09-19 01:54:44 --> File loaded: application/views/layout/main.php
DEBUG - 2011-09-19 01:54:44 --> Final output sent to browser
DEBUG - 2011-09-19 01:54:44 --> Total execution time: 2.4576
DEBUG - 2011-09-19 01:55:02 --> Config Class Initialized
DEBUG - 2011-09-19 01:55:02 --> Hooks Class Initialized
DEBUG - 2011-09-19 01:55:02 --> Utf8 Class Initialized
DEBUG - 2011-09-19 01:55:02 --> UTF-8 Support Enabled
DEBUG - 2011-09-19 01:55:02 --> URI Class Initialized
DEBUG - 2011-09-19 01:55:02 --> Router Class Initialized
DEBUG - 2011-09-19 01:55:02 --> Output Class Initialized
DEBUG - 2011-09-19 01:55:02 --> Input Class Initialized
DEBUG - 2011-09-19 01:55:02 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-19 01:55:02 --> Language Class Initialized
DEBUG - 2011-09-19 01:55:02 --> Loader Class Initialized
DEBUG - 2011-09-19 01:55:02 --> Controller Class Initialized
DEBUG - 2011-09-19 01:55:02 --> Model Class Initialized
DEBUG - 2011-09-19 01:55:02 --> Model Class Initialized
DEBUG - 2011-09-19 01:55:02 --> Model Class Initialized
DEBUG - 2011-09-19 01:55:02 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-19 01:55:02 --> Database Driver Class Initialized
DEBUG - 2011-09-19 01:55:03 --> File loaded: application/views/table/main.php
DEBUG - 2011-09-19 01:55:03 --> Helper loaded: url_helper
DEBUG - 2011-09-19 01:55:03 --> File loaded: application/views/common/header.php
DEBUG - 2011-09-19 01:55:03 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-09-19 01:55:03 --> File loaded: application/views/common/footer.php
DEBUG - 2011-09-19 01:55:03 --> File loaded: application/views/layout/main.php
DEBUG - 2011-09-19 01:55:03 --> Final output sent to browser
DEBUG - 2011-09-19 01:55:03 --> Total execution time: 1.0945
DEBUG - 2011-09-19 01:55:17 --> Config Class Initialized
DEBUG - 2011-09-19 01:55:17 --> Hooks Class Initialized
DEBUG - 2011-09-19 01:55:17 --> Utf8 Class Initialized
DEBUG - 2011-09-19 01:55:17 --> UTF-8 Support Enabled
DEBUG - 2011-09-19 01:55:17 --> URI Class Initialized
DEBUG - 2011-09-19 01:55:17 --> Router Class Initialized
DEBUG - 2011-09-19 01:55:17 --> Output Class Initialized
DEBUG - 2011-09-19 01:55:17 --> Input Class Initialized
DEBUG - 2011-09-19 01:55:17 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-19 01:55:17 --> Language Class Initialized
DEBUG - 2011-09-19 01:55:17 --> Loader Class Initialized
DEBUG - 2011-09-19 01:55:17 --> Controller Class Initialized
DEBUG - 2011-09-19 01:55:17 --> Model Class Initialized
DEBUG - 2011-09-19 01:55:17 --> Model Class Initialized
DEBUG - 2011-09-19 01:55:17 --> Model Class Initialized
DEBUG - 2011-09-19 01:55:17 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-19 01:55:17 --> Database Driver Class Initialized
DEBUG - 2011-09-19 01:55:20 --> File loaded: application/views/table/main.php
DEBUG - 2011-09-19 01:55:20 --> Helper loaded: url_helper
DEBUG - 2011-09-19 01:55:20 --> File loaded: application/views/common/header.php
DEBUG - 2011-09-19 01:55:20 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-09-19 01:55:20 --> File loaded: application/views/common/footer.php
DEBUG - 2011-09-19 01:55:20 --> File loaded: application/views/layout/main.php
DEBUG - 2011-09-19 01:55:20 --> Final output sent to browser
DEBUG - 2011-09-19 01:55:20 --> Total execution time: 3.0567
DEBUG - 2011-09-19 01:55:29 --> Config Class Initialized
DEBUG - 2011-09-19 01:55:29 --> Hooks Class Initialized
DEBUG - 2011-09-19 01:55:29 --> Utf8 Class Initialized
DEBUG - 2011-09-19 01:55:29 --> UTF-8 Support Enabled
DEBUG - 2011-09-19 01:55:29 --> URI Class Initialized
DEBUG - 2011-09-19 01:55:29 --> Router Class Initialized
DEBUG - 2011-09-19 01:55:29 --> Output Class Initialized
DEBUG - 2011-09-19 01:55:29 --> Input Class Initialized
DEBUG - 2011-09-19 01:55:29 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-19 01:55:29 --> Language Class Initialized
DEBUG - 2011-09-19 01:55:29 --> Loader Class Initialized
DEBUG - 2011-09-19 01:55:29 --> Controller Class Initialized
DEBUG - 2011-09-19 01:55:29 --> Model Class Initialized
DEBUG - 2011-09-19 01:55:29 --> Model Class Initialized
DEBUG - 2011-09-19 01:55:29 --> Model Class Initialized
DEBUG - 2011-09-19 01:55:29 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-19 01:55:29 --> Database Driver Class Initialized
DEBUG - 2011-09-19 01:55:36 --> File loaded: application/views/table/main.php
DEBUG - 2011-09-19 01:55:36 --> Helper loaded: url_helper
DEBUG - 2011-09-19 01:55:36 --> File loaded: application/views/common/header.php
DEBUG - 2011-09-19 01:55:36 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-09-19 01:55:36 --> File loaded: application/views/common/footer.php
DEBUG - 2011-09-19 01:55:36 --> File loaded: application/views/layout/main.php
DEBUG - 2011-09-19 01:55:36 --> Final output sent to browser
DEBUG - 2011-09-19 01:55:36 --> Total execution time: 7.0058
DEBUG - 2011-09-19 01:56:08 --> Config Class Initialized
DEBUG - 2011-09-19 01:56:08 --> Hooks Class Initialized
DEBUG - 2011-09-19 01:56:08 --> Utf8 Class Initialized
DEBUG - 2011-09-19 01:56:08 --> UTF-8 Support Enabled
DEBUG - 2011-09-19 01:56:08 --> URI Class Initialized
DEBUG - 2011-09-19 01:56:08 --> Router Class Initialized
DEBUG - 2011-09-19 01:56:08 --> Output Class Initialized
DEBUG - 2011-09-19 01:56:08 --> Input Class Initialized
DEBUG - 2011-09-19 01:56:08 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-19 01:56:08 --> Language Class Initialized
DEBUG - 2011-09-19 01:56:08 --> Loader Class Initialized
DEBUG - 2011-09-19 01:56:08 --> Controller Class Initialized
DEBUG - 2011-09-19 01:56:08 --> Model Class Initialized
DEBUG - 2011-09-19 01:56:08 --> Model Class Initialized
DEBUG - 2011-09-19 01:56:08 --> Model Class Initialized
DEBUG - 2011-09-19 01:56:08 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-19 01:56:08 --> Database Driver Class Initialized
DEBUG - 2011-09-19 01:56:09 --> File loaded: application/views/table/main.php
DEBUG - 2011-09-19 01:56:09 --> Helper loaded: url_helper
DEBUG - 2011-09-19 01:56:09 --> File loaded: application/views/common/header.php
DEBUG - 2011-09-19 01:56:09 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-09-19 01:56:09 --> File loaded: application/views/common/footer.php
DEBUG - 2011-09-19 01:56:09 --> File loaded: application/views/layout/main.php
DEBUG - 2011-09-19 01:56:09 --> Final output sent to browser
DEBUG - 2011-09-19 01:56:09 --> Total execution time: 0.9286
DEBUG - 2011-09-19 01:56:46 --> Config Class Initialized
DEBUG - 2011-09-19 01:56:46 --> Hooks Class Initialized
DEBUG - 2011-09-19 01:56:46 --> Utf8 Class Initialized
DEBUG - 2011-09-19 01:56:46 --> UTF-8 Support Enabled
DEBUG - 2011-09-19 01:56:46 --> URI Class Initialized
DEBUG - 2011-09-19 01:56:46 --> Router Class Initialized
DEBUG - 2011-09-19 01:56:46 --> Output Class Initialized
DEBUG - 2011-09-19 01:56:46 --> Input Class Initialized
DEBUG - 2011-09-19 01:56:46 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-19 01:56:46 --> Language Class Initialized
DEBUG - 2011-09-19 01:56:46 --> Loader Class Initialized
DEBUG - 2011-09-19 01:56:46 --> Controller Class Initialized
DEBUG - 2011-09-19 01:56:46 --> Model Class Initialized
DEBUG - 2011-09-19 01:56:46 --> Model Class Initialized
DEBUG - 2011-09-19 01:56:46 --> Model Class Initialized
DEBUG - 2011-09-19 01:56:46 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-19 01:56:46 --> Database Driver Class Initialized
DEBUG - 2011-09-19 01:56:46 --> File loaded: application/views/table/main.php
DEBUG - 2011-09-19 01:56:46 --> Helper loaded: url_helper
DEBUG - 2011-09-19 01:56:46 --> File loaded: application/views/common/header.php
DEBUG - 2011-09-19 01:56:46 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-09-19 01:56:46 --> File loaded: application/views/common/footer.php
DEBUG - 2011-09-19 01:56:46 --> File loaded: application/views/layout/main.php
DEBUG - 2011-09-19 01:56:46 --> Final output sent to browser
DEBUG - 2011-09-19 01:56:46 --> Total execution time: 0.2810
DEBUG - 2011-09-19 01:57:03 --> Config Class Initialized
DEBUG - 2011-09-19 01:57:03 --> Hooks Class Initialized
DEBUG - 2011-09-19 01:57:03 --> Utf8 Class Initialized
DEBUG - 2011-09-19 01:57:03 --> UTF-8 Support Enabled
DEBUG - 2011-09-19 01:57:03 --> URI Class Initialized
DEBUG - 2011-09-19 01:57:03 --> Router Class Initialized
DEBUG - 2011-09-19 01:57:03 --> Output Class Initialized
DEBUG - 2011-09-19 01:57:03 --> Input Class Initialized
DEBUG - 2011-09-19 01:57:03 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-19 01:57:03 --> Language Class Initialized
DEBUG - 2011-09-19 01:57:03 --> Loader Class Initialized
DEBUG - 2011-09-19 01:57:03 --> Controller Class Initialized
DEBUG - 2011-09-19 01:57:03 --> Model Class Initialized
DEBUG - 2011-09-19 01:57:03 --> Model Class Initialized
DEBUG - 2011-09-19 01:57:03 --> Model Class Initialized
DEBUG - 2011-09-19 01:57:03 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-19 01:57:03 --> Database Driver Class Initialized
DEBUG - 2011-09-19 01:57:04 --> File loaded: application/views/table/main.php
DEBUG - 2011-09-19 01:57:04 --> Helper loaded: url_helper
DEBUG - 2011-09-19 01:57:04 --> File loaded: application/views/common/header.php
DEBUG - 2011-09-19 01:57:04 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-09-19 01:57:04 --> File loaded: application/views/common/footer.php
DEBUG - 2011-09-19 01:57:04 --> File loaded: application/views/layout/main.php
DEBUG - 2011-09-19 01:57:04 --> Final output sent to browser
DEBUG - 2011-09-19 01:57:04 --> Total execution time: 1.3622
DEBUG - 2011-09-19 01:57:18 --> Config Class Initialized
DEBUG - 2011-09-19 01:57:18 --> Hooks Class Initialized
DEBUG - 2011-09-19 01:57:18 --> Utf8 Class Initialized
DEBUG - 2011-09-19 01:57:18 --> UTF-8 Support Enabled
DEBUG - 2011-09-19 01:57:18 --> URI Class Initialized
DEBUG - 2011-09-19 01:57:18 --> Router Class Initialized
DEBUG - 2011-09-19 01:57:18 --> Output Class Initialized
DEBUG - 2011-09-19 01:57:18 --> Input Class Initialized
DEBUG - 2011-09-19 01:57:18 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-19 01:57:18 --> Language Class Initialized
DEBUG - 2011-09-19 01:57:18 --> Loader Class Initialized
DEBUG - 2011-09-19 01:57:18 --> Controller Class Initialized
DEBUG - 2011-09-19 01:57:18 --> Model Class Initialized
DEBUG - 2011-09-19 01:57:18 --> Model Class Initialized
DEBUG - 2011-09-19 01:57:18 --> Model Class Initialized
DEBUG - 2011-09-19 01:57:18 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-19 01:57:18 --> Database Driver Class Initialized
DEBUG - 2011-09-19 01:57:19 --> File loaded: application/views/table/main.php
DEBUG - 2011-09-19 01:57:19 --> Helper loaded: url_helper
DEBUG - 2011-09-19 01:57:19 --> File loaded: application/views/common/header.php
DEBUG - 2011-09-19 01:57:19 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-09-19 01:57:19 --> File loaded: application/views/common/footer.php
DEBUG - 2011-09-19 01:57:19 --> File loaded: application/views/layout/main.php
DEBUG - 2011-09-19 01:57:19 --> Final output sent to browser
DEBUG - 2011-09-19 01:57:19 --> Total execution time: 1.2815
DEBUG - 2011-09-19 01:57:34 --> Config Class Initialized
DEBUG - 2011-09-19 01:57:34 --> Hooks Class Initialized
DEBUG - 2011-09-19 01:57:34 --> Utf8 Class Initialized
DEBUG - 2011-09-19 01:57:34 --> UTF-8 Support Enabled
DEBUG - 2011-09-19 01:57:34 --> URI Class Initialized
DEBUG - 2011-09-19 01:57:34 --> Router Class Initialized
DEBUG - 2011-09-19 01:57:34 --> Output Class Initialized
DEBUG - 2011-09-19 01:57:34 --> Input Class Initialized
DEBUG - 2011-09-19 01:57:34 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-19 01:57:34 --> Language Class Initialized
DEBUG - 2011-09-19 01:57:34 --> Loader Class Initialized
DEBUG - 2011-09-19 01:57:34 --> Controller Class Initialized
DEBUG - 2011-09-19 01:57:34 --> Model Class Initialized
DEBUG - 2011-09-19 01:57:34 --> Model Class Initialized
DEBUG - 2011-09-19 01:57:34 --> Model Class Initialized
DEBUG - 2011-09-19 01:57:34 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-19 01:57:34 --> Database Driver Class Initialized
DEBUG - 2011-09-19 01:57:36 --> File loaded: application/views/table/main.php
DEBUG - 2011-09-19 01:57:36 --> Helper loaded: url_helper
DEBUG - 2011-09-19 01:57:36 --> File loaded: application/views/common/header.php
DEBUG - 2011-09-19 01:57:36 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-09-19 01:57:36 --> File loaded: application/views/common/footer.php
DEBUG - 2011-09-19 01:57:36 --> File loaded: application/views/layout/main.php
DEBUG - 2011-09-19 01:57:36 --> Final output sent to browser
DEBUG - 2011-09-19 01:57:36 --> Total execution time: 1.7175
DEBUG - 2011-09-19 01:57:47 --> Config Class Initialized
DEBUG - 2011-09-19 01:57:47 --> Hooks Class Initialized
DEBUG - 2011-09-19 01:57:47 --> Utf8 Class Initialized
DEBUG - 2011-09-19 01:57:47 --> UTF-8 Support Enabled
DEBUG - 2011-09-19 01:57:47 --> URI Class Initialized
DEBUG - 2011-09-19 01:57:47 --> Router Class Initialized
DEBUG - 2011-09-19 01:57:47 --> Output Class Initialized
DEBUG - 2011-09-19 01:57:47 --> Input Class Initialized
DEBUG - 2011-09-19 01:57:47 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-19 01:57:47 --> Language Class Initialized
DEBUG - 2011-09-19 01:57:47 --> Loader Class Initialized
DEBUG - 2011-09-19 01:57:47 --> Controller Class Initialized
DEBUG - 2011-09-19 01:57:47 --> Model Class Initialized
DEBUG - 2011-09-19 01:57:47 --> Model Class Initialized
DEBUG - 2011-09-19 01:57:47 --> Model Class Initialized
DEBUG - 2011-09-19 01:57:47 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-19 01:57:47 --> Database Driver Class Initialized
DEBUG - 2011-09-19 01:57:48 --> File loaded: application/views/table/main.php
DEBUG - 2011-09-19 01:57:48 --> Helper loaded: url_helper
DEBUG - 2011-09-19 01:57:48 --> File loaded: application/views/common/header.php
DEBUG - 2011-09-19 01:57:48 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-09-19 01:57:48 --> File loaded: application/views/common/footer.php
DEBUG - 2011-09-19 01:57:48 --> File loaded: application/views/layout/main.php
DEBUG - 2011-09-19 01:57:48 --> Final output sent to browser
DEBUG - 2011-09-19 01:57:48 --> Total execution time: 1.5023
DEBUG - 2011-09-19 01:58:19 --> Config Class Initialized
DEBUG - 2011-09-19 01:58:19 --> Hooks Class Initialized
DEBUG - 2011-09-19 01:58:19 --> Utf8 Class Initialized
DEBUG - 2011-09-19 01:58:19 --> UTF-8 Support Enabled
DEBUG - 2011-09-19 01:58:19 --> URI Class Initialized
DEBUG - 2011-09-19 01:58:19 --> Router Class Initialized
DEBUG - 2011-09-19 01:58:19 --> Output Class Initialized
DEBUG - 2011-09-19 01:58:19 --> Input Class Initialized
DEBUG - 2011-09-19 01:58:19 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-19 01:58:19 --> Language Class Initialized
DEBUG - 2011-09-19 01:58:19 --> Loader Class Initialized
DEBUG - 2011-09-19 01:58:19 --> Controller Class Initialized
DEBUG - 2011-09-19 01:58:19 --> Model Class Initialized
DEBUG - 2011-09-19 01:58:19 --> Model Class Initialized
DEBUG - 2011-09-19 01:58:19 --> Model Class Initialized
DEBUG - 2011-09-19 01:58:19 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-19 01:58:19 --> Database Driver Class Initialized
DEBUG - 2011-09-19 01:58:22 --> File loaded: application/views/table/main.php
DEBUG - 2011-09-19 01:58:22 --> Helper loaded: url_helper
DEBUG - 2011-09-19 01:58:22 --> File loaded: application/views/common/header.php
DEBUG - 2011-09-19 01:58:22 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-09-19 01:58:22 --> File loaded: application/views/common/footer.php
DEBUG - 2011-09-19 01:58:22 --> File loaded: application/views/layout/main.php
DEBUG - 2011-09-19 01:58:22 --> Final output sent to browser
DEBUG - 2011-09-19 01:58:22 --> Total execution time: 3.6062
DEBUG - 2011-09-19 01:58:45 --> Config Class Initialized
DEBUG - 2011-09-19 01:58:45 --> Hooks Class Initialized
DEBUG - 2011-09-19 01:58:45 --> Utf8 Class Initialized
DEBUG - 2011-09-19 01:58:45 --> UTF-8 Support Enabled
DEBUG - 2011-09-19 01:58:45 --> URI Class Initialized
DEBUG - 2011-09-19 01:58:45 --> Router Class Initialized
DEBUG - 2011-09-19 01:58:45 --> Output Class Initialized
DEBUG - 2011-09-19 01:58:45 --> Input Class Initialized
DEBUG - 2011-09-19 01:58:45 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-19 01:58:45 --> Language Class Initialized
DEBUG - 2011-09-19 01:58:45 --> Loader Class Initialized
DEBUG - 2011-09-19 01:58:45 --> Controller Class Initialized
DEBUG - 2011-09-19 01:58:45 --> Model Class Initialized
DEBUG - 2011-09-19 01:58:45 --> Model Class Initialized
DEBUG - 2011-09-19 01:58:45 --> Model Class Initialized
DEBUG - 2011-09-19 01:58:45 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-19 01:58:45 --> Database Driver Class Initialized
DEBUG - 2011-09-19 01:58:45 --> File loaded: application/views/table/main.php
DEBUG - 2011-09-19 01:58:45 --> Helper loaded: url_helper
DEBUG - 2011-09-19 01:58:45 --> File loaded: application/views/common/header.php
DEBUG - 2011-09-19 01:58:45 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-09-19 01:58:45 --> File loaded: application/views/common/footer.php
DEBUG - 2011-09-19 01:58:45 --> File loaded: application/views/layout/main.php
DEBUG - 2011-09-19 01:58:45 --> Final output sent to browser
DEBUG - 2011-09-19 01:58:45 --> Total execution time: 0.5934
DEBUG - 2011-09-19 01:59:12 --> Config Class Initialized
DEBUG - 2011-09-19 01:59:12 --> Hooks Class Initialized
DEBUG - 2011-09-19 01:59:12 --> Utf8 Class Initialized
DEBUG - 2011-09-19 01:59:12 --> UTF-8 Support Enabled
DEBUG - 2011-09-19 01:59:12 --> URI Class Initialized
DEBUG - 2011-09-19 01:59:12 --> Router Class Initialized
DEBUG - 2011-09-19 01:59:12 --> Output Class Initialized
DEBUG - 2011-09-19 01:59:12 --> Input Class Initialized
DEBUG - 2011-09-19 01:59:12 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-19 01:59:12 --> Language Class Initialized
DEBUG - 2011-09-19 01:59:12 --> Loader Class Initialized
DEBUG - 2011-09-19 01:59:12 --> Controller Class Initialized
DEBUG - 2011-09-19 01:59:12 --> Model Class Initialized
DEBUG - 2011-09-19 01:59:12 --> Model Class Initialized
DEBUG - 2011-09-19 01:59:12 --> Model Class Initialized
DEBUG - 2011-09-19 01:59:12 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-19 01:59:12 --> Database Driver Class Initialized
DEBUG - 2011-09-19 01:59:13 --> File loaded: application/views/table/main.php
DEBUG - 2011-09-19 01:59:13 --> Helper loaded: url_helper
DEBUG - 2011-09-19 01:59:13 --> File loaded: application/views/common/header.php
DEBUG - 2011-09-19 01:59:13 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-09-19 01:59:13 --> File loaded: application/views/common/footer.php
DEBUG - 2011-09-19 01:59:13 --> File loaded: application/views/layout/main.php
DEBUG - 2011-09-19 01:59:13 --> Final output sent to browser
DEBUG - 2011-09-19 01:59:13 --> Total execution time: 0.5884
DEBUG - 2011-09-19 01:59:30 --> Config Class Initialized
DEBUG - 2011-09-19 01:59:30 --> Hooks Class Initialized
DEBUG - 2011-09-19 01:59:30 --> Utf8 Class Initialized
DEBUG - 2011-09-19 01:59:30 --> UTF-8 Support Enabled
DEBUG - 2011-09-19 01:59:30 --> URI Class Initialized
DEBUG - 2011-09-19 01:59:30 --> Router Class Initialized
DEBUG - 2011-09-19 01:59:30 --> Output Class Initialized
DEBUG - 2011-09-19 01:59:30 --> Input Class Initialized
DEBUG - 2011-09-19 01:59:30 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-19 01:59:30 --> Language Class Initialized
DEBUG - 2011-09-19 01:59:30 --> Loader Class Initialized
DEBUG - 2011-09-19 01:59:30 --> Controller Class Initialized
DEBUG - 2011-09-19 01:59:30 --> Model Class Initialized
DEBUG - 2011-09-19 01:59:30 --> Model Class Initialized
DEBUG - 2011-09-19 01:59:30 --> Model Class Initialized
DEBUG - 2011-09-19 01:59:30 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-19 01:59:30 --> Database Driver Class Initialized
DEBUG - 2011-09-19 01:59:32 --> File loaded: application/views/table/main.php
DEBUG - 2011-09-19 01:59:32 --> Helper loaded: url_helper
DEBUG - 2011-09-19 01:59:32 --> File loaded: application/views/common/header.php
DEBUG - 2011-09-19 01:59:32 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-09-19 01:59:32 --> File loaded: application/views/common/footer.php
DEBUG - 2011-09-19 01:59:32 --> File loaded: application/views/layout/main.php
DEBUG - 2011-09-19 01:59:32 --> Final output sent to browser
DEBUG - 2011-09-19 01:59:32 --> Total execution time: 2.2159
DEBUG - 2011-09-19 01:59:51 --> Config Class Initialized
DEBUG - 2011-09-19 01:59:51 --> Hooks Class Initialized
DEBUG - 2011-09-19 01:59:51 --> Utf8 Class Initialized
DEBUG - 2011-09-19 01:59:51 --> UTF-8 Support Enabled
DEBUG - 2011-09-19 01:59:51 --> URI Class Initialized
DEBUG - 2011-09-19 01:59:51 --> Router Class Initialized
DEBUG - 2011-09-19 01:59:51 --> Output Class Initialized
DEBUG - 2011-09-19 01:59:51 --> Input Class Initialized
DEBUG - 2011-09-19 01:59:51 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-19 01:59:51 --> Language Class Initialized
DEBUG - 2011-09-19 01:59:51 --> Loader Class Initialized
DEBUG - 2011-09-19 01:59:51 --> Controller Class Initialized
DEBUG - 2011-09-19 01:59:51 --> Model Class Initialized
DEBUG - 2011-09-19 01:59:51 --> Model Class Initialized
DEBUG - 2011-09-19 01:59:51 --> Model Class Initialized
DEBUG - 2011-09-19 01:59:51 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-19 01:59:51 --> Database Driver Class Initialized
DEBUG - 2011-09-19 01:59:52 --> File loaded: application/views/table/main.php
DEBUG - 2011-09-19 01:59:52 --> Helper loaded: url_helper
DEBUG - 2011-09-19 01:59:52 --> File loaded: application/views/common/header.php
DEBUG - 2011-09-19 01:59:52 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-09-19 01:59:52 --> File loaded: application/views/common/footer.php
DEBUG - 2011-09-19 01:59:52 --> File loaded: application/views/layout/main.php
DEBUG - 2011-09-19 01:59:52 --> Final output sent to browser
DEBUG - 2011-09-19 01:59:52 --> Total execution time: 1.1266
DEBUG - 2011-09-19 02:00:11 --> Config Class Initialized
DEBUG - 2011-09-19 02:00:11 --> Hooks Class Initialized
DEBUG - 2011-09-19 02:00:11 --> Utf8 Class Initialized
DEBUG - 2011-09-19 02:00:11 --> UTF-8 Support Enabled
DEBUG - 2011-09-19 02:00:11 --> URI Class Initialized
DEBUG - 2011-09-19 02:00:11 --> Router Class Initialized
DEBUG - 2011-09-19 02:00:11 --> Output Class Initialized
DEBUG - 2011-09-19 02:00:11 --> Input Class Initialized
DEBUG - 2011-09-19 02:00:11 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-19 02:00:11 --> Language Class Initialized
DEBUG - 2011-09-19 02:00:11 --> Loader Class Initialized
DEBUG - 2011-09-19 02:00:11 --> Controller Class Initialized
DEBUG - 2011-09-19 02:00:11 --> Model Class Initialized
DEBUG - 2011-09-19 02:00:11 --> Model Class Initialized
DEBUG - 2011-09-19 02:00:11 --> Model Class Initialized
DEBUG - 2011-09-19 02:00:11 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-19 02:00:11 --> Database Driver Class Initialized
DEBUG - 2011-09-19 02:00:14 --> File loaded: application/views/table/main.php
DEBUG - 2011-09-19 02:00:14 --> Helper loaded: url_helper
DEBUG - 2011-09-19 02:00:14 --> File loaded: application/views/common/header.php
DEBUG - 2011-09-19 02:00:14 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-09-19 02:00:14 --> File loaded: application/views/common/footer.php
DEBUG - 2011-09-19 02:00:14 --> File loaded: application/views/layout/main.php
DEBUG - 2011-09-19 02:00:14 --> Final output sent to browser
DEBUG - 2011-09-19 02:00:14 --> Total execution time: 2.7831
DEBUG - 2011-09-19 02:00:24 --> Config Class Initialized
DEBUG - 2011-09-19 02:00:24 --> Hooks Class Initialized
DEBUG - 2011-09-19 02:00:24 --> Utf8 Class Initialized
DEBUG - 2011-09-19 02:00:24 --> UTF-8 Support Enabled
DEBUG - 2011-09-19 02:00:24 --> URI Class Initialized
DEBUG - 2011-09-19 02:00:24 --> Router Class Initialized
DEBUG - 2011-09-19 02:00:24 --> Output Class Initialized
DEBUG - 2011-09-19 02:00:24 --> Input Class Initialized
DEBUG - 2011-09-19 02:00:24 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-19 02:00:24 --> Language Class Initialized
DEBUG - 2011-09-19 02:00:24 --> Loader Class Initialized
DEBUG - 2011-09-19 02:00:24 --> Controller Class Initialized
DEBUG - 2011-09-19 02:00:24 --> Model Class Initialized
DEBUG - 2011-09-19 02:00:24 --> Model Class Initialized
DEBUG - 2011-09-19 02:00:24 --> Model Class Initialized
DEBUG - 2011-09-19 02:00:24 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-19 02:00:24 --> Database Driver Class Initialized
DEBUG - 2011-09-19 02:00:46 --> File loaded: application/views/table/main.php
DEBUG - 2011-09-19 02:00:46 --> Helper loaded: url_helper
DEBUG - 2011-09-19 02:00:46 --> File loaded: application/views/common/header.php
DEBUG - 2011-09-19 02:00:46 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-09-19 02:00:46 --> File loaded: application/views/common/footer.php
DEBUG - 2011-09-19 02:00:46 --> File loaded: application/views/layout/main.php
DEBUG - 2011-09-19 02:00:46 --> Final output sent to browser
DEBUG - 2011-09-19 02:00:46 --> Total execution time: 22.4562
DEBUG - 2011-09-19 02:01:01 --> Config Class Initialized
DEBUG - 2011-09-19 02:01:01 --> Hooks Class Initialized
DEBUG - 2011-09-19 02:01:01 --> Utf8 Class Initialized
DEBUG - 2011-09-19 02:01:01 --> UTF-8 Support Enabled
DEBUG - 2011-09-19 02:01:01 --> URI Class Initialized
DEBUG - 2011-09-19 02:01:01 --> Router Class Initialized
DEBUG - 2011-09-19 02:01:01 --> Output Class Initialized
DEBUG - 2011-09-19 02:01:01 --> Input Class Initialized
DEBUG - 2011-09-19 02:01:01 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-19 02:01:01 --> Language Class Initialized
DEBUG - 2011-09-19 02:01:01 --> Loader Class Initialized
DEBUG - 2011-09-19 02:01:01 --> Controller Class Initialized
DEBUG - 2011-09-19 02:01:01 --> Model Class Initialized
DEBUG - 2011-09-19 02:01:01 --> Model Class Initialized
DEBUG - 2011-09-19 02:01:01 --> Model Class Initialized
DEBUG - 2011-09-19 02:01:01 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-19 02:01:01 --> Database Driver Class Initialized
DEBUG - 2011-09-19 02:01:02 --> File loaded: application/views/table/main.php
DEBUG - 2011-09-19 02:01:02 --> Helper loaded: url_helper
DEBUG - 2011-09-19 02:01:02 --> File loaded: application/views/common/header.php
DEBUG - 2011-09-19 02:01:02 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-09-19 02:01:02 --> File loaded: application/views/common/footer.php
DEBUG - 2011-09-19 02:01:02 --> File loaded: application/views/layout/main.php
DEBUG - 2011-09-19 02:01:02 --> Final output sent to browser
DEBUG - 2011-09-19 02:01:02 --> Total execution time: 1.5726
DEBUG - 2011-09-19 02:01:14 --> Config Class Initialized
DEBUG - 2011-09-19 02:01:14 --> Hooks Class Initialized
DEBUG - 2011-09-19 02:01:14 --> Utf8 Class Initialized
DEBUG - 2011-09-19 02:01:14 --> UTF-8 Support Enabled
DEBUG - 2011-09-19 02:01:14 --> URI Class Initialized
DEBUG - 2011-09-19 02:01:14 --> Router Class Initialized
DEBUG - 2011-09-19 02:01:14 --> Output Class Initialized
DEBUG - 2011-09-19 02:01:14 --> Input Class Initialized
DEBUG - 2011-09-19 02:01:14 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-19 02:01:14 --> Language Class Initialized
DEBUG - 2011-09-19 02:01:14 --> Loader Class Initialized
DEBUG - 2011-09-19 02:01:14 --> Controller Class Initialized
DEBUG - 2011-09-19 02:01:14 --> Model Class Initialized
DEBUG - 2011-09-19 02:01:14 --> Model Class Initialized
DEBUG - 2011-09-19 02:01:14 --> Model Class Initialized
DEBUG - 2011-09-19 02:01:14 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-19 02:01:14 --> Database Driver Class Initialized
DEBUG - 2011-09-19 02:01:15 --> File loaded: application/views/table/main.php
DEBUG - 2011-09-19 02:01:15 --> Helper loaded: url_helper
DEBUG - 2011-09-19 02:01:15 --> File loaded: application/views/common/header.php
DEBUG - 2011-09-19 02:01:15 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-09-19 02:01:15 --> File loaded: application/views/common/footer.php
DEBUG - 2011-09-19 02:01:15 --> File loaded: application/views/layout/main.php
DEBUG - 2011-09-19 02:01:15 --> Final output sent to browser
DEBUG - 2011-09-19 02:01:15 --> Total execution time: 0.5501
DEBUG - 2011-09-19 02:01:29 --> Config Class Initialized
DEBUG - 2011-09-19 02:01:29 --> Hooks Class Initialized
DEBUG - 2011-09-19 02:01:29 --> Utf8 Class Initialized
DEBUG - 2011-09-19 02:01:29 --> UTF-8 Support Enabled
DEBUG - 2011-09-19 02:01:29 --> URI Class Initialized
DEBUG - 2011-09-19 02:01:29 --> Router Class Initialized
DEBUG - 2011-09-19 02:01:29 --> Output Class Initialized
DEBUG - 2011-09-19 02:01:29 --> Input Class Initialized
DEBUG - 2011-09-19 02:01:29 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-19 02:01:29 --> Language Class Initialized
DEBUG - 2011-09-19 02:01:29 --> Loader Class Initialized
DEBUG - 2011-09-19 02:01:29 --> Controller Class Initialized
DEBUG - 2011-09-19 02:01:29 --> Model Class Initialized
DEBUG - 2011-09-19 02:01:29 --> Model Class Initialized
DEBUG - 2011-09-19 02:01:29 --> Model Class Initialized
DEBUG - 2011-09-19 02:01:29 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-19 02:01:29 --> Database Driver Class Initialized
DEBUG - 2011-09-19 02:01:29 --> File loaded: application/views/table/main.php
DEBUG - 2011-09-19 02:01:29 --> Helper loaded: url_helper
DEBUG - 2011-09-19 02:01:29 --> File loaded: application/views/common/header.php
DEBUG - 2011-09-19 02:01:29 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-09-19 02:01:29 --> File loaded: application/views/common/footer.php
DEBUG - 2011-09-19 02:01:30 --> File loaded: application/views/layout/main.php
DEBUG - 2011-09-19 02:01:30 --> Final output sent to browser
DEBUG - 2011-09-19 02:01:30 --> Total execution time: 0.2472
DEBUG - 2011-09-19 02:01:37 --> Config Class Initialized
DEBUG - 2011-09-19 02:01:37 --> Hooks Class Initialized
DEBUG - 2011-09-19 02:01:37 --> Utf8 Class Initialized
DEBUG - 2011-09-19 02:01:37 --> UTF-8 Support Enabled
DEBUG - 2011-09-19 02:01:37 --> URI Class Initialized
DEBUG - 2011-09-19 02:01:37 --> Router Class Initialized
DEBUG - 2011-09-19 02:01:37 --> Output Class Initialized
DEBUG - 2011-09-19 02:01:37 --> Input Class Initialized
DEBUG - 2011-09-19 02:01:37 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-19 02:01:37 --> Language Class Initialized
DEBUG - 2011-09-19 02:01:37 --> Loader Class Initialized
DEBUG - 2011-09-19 02:01:37 --> Controller Class Initialized
DEBUG - 2011-09-19 02:01:37 --> Model Class Initialized
DEBUG - 2011-09-19 02:01:37 --> Model Class Initialized
DEBUG - 2011-09-19 02:01:37 --> Model Class Initialized
DEBUG - 2011-09-19 02:01:37 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-19 02:01:37 --> Database Driver Class Initialized
DEBUG - 2011-09-19 02:01:39 --> File loaded: application/views/table/main.php
DEBUG - 2011-09-19 02:01:39 --> Helper loaded: url_helper
DEBUG - 2011-09-19 02:01:39 --> File loaded: application/views/common/header.php
DEBUG - 2011-09-19 02:01:39 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-09-19 02:01:39 --> File loaded: application/views/common/footer.php
DEBUG - 2011-09-19 02:01:39 --> File loaded: application/views/layout/main.php
DEBUG - 2011-09-19 02:01:39 --> Final output sent to browser
DEBUG - 2011-09-19 02:01:39 --> Total execution time: 1.1593
DEBUG - 2011-09-19 02:01:46 --> Config Class Initialized
DEBUG - 2011-09-19 02:01:46 --> Hooks Class Initialized
DEBUG - 2011-09-19 02:01:46 --> Utf8 Class Initialized
DEBUG - 2011-09-19 02:01:46 --> UTF-8 Support Enabled
DEBUG - 2011-09-19 02:01:46 --> URI Class Initialized
DEBUG - 2011-09-19 02:01:46 --> Router Class Initialized
DEBUG - 2011-09-19 02:01:46 --> Output Class Initialized
DEBUG - 2011-09-19 02:01:46 --> Input Class Initialized
DEBUG - 2011-09-19 02:01:46 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-19 02:01:46 --> Language Class Initialized
DEBUG - 2011-09-19 02:01:46 --> Loader Class Initialized
DEBUG - 2011-09-19 02:01:46 --> Controller Class Initialized
DEBUG - 2011-09-19 02:01:46 --> Model Class Initialized
DEBUG - 2011-09-19 02:01:46 --> Model Class Initialized
DEBUG - 2011-09-19 02:01:46 --> Model Class Initialized
DEBUG - 2011-09-19 02:01:46 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-19 02:01:46 --> Database Driver Class Initialized
DEBUG - 2011-09-19 02:01:46 --> File loaded: application/views/table/main.php
DEBUG - 2011-09-19 02:01:46 --> Helper loaded: url_helper
DEBUG - 2011-09-19 02:01:46 --> File loaded: application/views/common/header.php
DEBUG - 2011-09-19 02:01:46 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-09-19 02:01:46 --> File loaded: application/views/common/footer.php
DEBUG - 2011-09-19 02:01:46 --> File loaded: application/views/layout/main.php
DEBUG - 2011-09-19 02:01:46 --> Final output sent to browser
DEBUG - 2011-09-19 02:01:46 --> Total execution time: 0.5401
DEBUG - 2011-09-19 02:01:55 --> Config Class Initialized
DEBUG - 2011-09-19 02:01:55 --> Hooks Class Initialized
DEBUG - 2011-09-19 02:01:55 --> Utf8 Class Initialized
DEBUG - 2011-09-19 02:01:55 --> UTF-8 Support Enabled
DEBUG - 2011-09-19 02:01:55 --> URI Class Initialized
DEBUG - 2011-09-19 02:01:55 --> Router Class Initialized
DEBUG - 2011-09-19 02:01:55 --> Output Class Initialized
DEBUG - 2011-09-19 02:01:55 --> Input Class Initialized
DEBUG - 2011-09-19 02:01:55 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-19 02:01:55 --> Language Class Initialized
DEBUG - 2011-09-19 02:01:55 --> Loader Class Initialized
DEBUG - 2011-09-19 02:01:55 --> Controller Class Initialized
DEBUG - 2011-09-19 02:01:55 --> Model Class Initialized
DEBUG - 2011-09-19 02:01:55 --> Model Class Initialized
DEBUG - 2011-09-19 02:01:55 --> Model Class Initialized
DEBUG - 2011-09-19 02:01:55 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-19 02:01:55 --> Database Driver Class Initialized
DEBUG - 2011-09-19 02:01:57 --> File loaded: application/views/table/main.php
DEBUG - 2011-09-19 02:01:57 --> Helper loaded: url_helper
DEBUG - 2011-09-19 02:01:57 --> File loaded: application/views/common/header.php
DEBUG - 2011-09-19 02:01:57 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-09-19 02:01:57 --> File loaded: application/views/common/footer.php
DEBUG - 2011-09-19 02:01:57 --> File loaded: application/views/layout/main.php
DEBUG - 2011-09-19 02:01:57 --> Final output sent to browser
DEBUG - 2011-09-19 02:01:57 --> Total execution time: 2.2665
DEBUG - 2011-09-19 02:02:08 --> Config Class Initialized
DEBUG - 2011-09-19 02:02:08 --> Hooks Class Initialized
DEBUG - 2011-09-19 02:02:08 --> Utf8 Class Initialized
DEBUG - 2011-09-19 02:02:08 --> UTF-8 Support Enabled
DEBUG - 2011-09-19 02:02:08 --> URI Class Initialized
DEBUG - 2011-09-19 02:02:08 --> Router Class Initialized
DEBUG - 2011-09-19 02:02:08 --> Output Class Initialized
DEBUG - 2011-09-19 02:02:08 --> Input Class Initialized
DEBUG - 2011-09-19 02:02:08 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-19 02:02:08 --> Language Class Initialized
DEBUG - 2011-09-19 02:02:08 --> Loader Class Initialized
DEBUG - 2011-09-19 02:02:08 --> Controller Class Initialized
DEBUG - 2011-09-19 02:02:08 --> Model Class Initialized
DEBUG - 2011-09-19 02:02:08 --> Model Class Initialized
DEBUG - 2011-09-19 02:02:08 --> Model Class Initialized
DEBUG - 2011-09-19 02:02:08 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-19 02:02:08 --> Database Driver Class Initialized
DEBUG - 2011-09-19 02:02:10 --> File loaded: application/views/table/main.php
DEBUG - 2011-09-19 02:02:10 --> Helper loaded: url_helper
DEBUG - 2011-09-19 02:02:10 --> File loaded: application/views/common/header.php
DEBUG - 2011-09-19 02:02:10 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-09-19 02:02:10 --> File loaded: application/views/common/footer.php
DEBUG - 2011-09-19 02:02:10 --> File loaded: application/views/layout/main.php
DEBUG - 2011-09-19 02:02:10 --> Final output sent to browser
DEBUG - 2011-09-19 02:02:10 --> Total execution time: 1.8719
DEBUG - 2011-09-19 02:02:28 --> Config Class Initialized
DEBUG - 2011-09-19 02:02:28 --> Hooks Class Initialized
DEBUG - 2011-09-19 02:02:28 --> Utf8 Class Initialized
DEBUG - 2011-09-19 02:02:28 --> UTF-8 Support Enabled
DEBUG - 2011-09-19 02:02:28 --> URI Class Initialized
DEBUG - 2011-09-19 02:02:28 --> Router Class Initialized
DEBUG - 2011-09-19 02:02:28 --> Output Class Initialized
DEBUG - 2011-09-19 02:02:28 --> Input Class Initialized
DEBUG - 2011-09-19 02:02:28 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-19 02:02:28 --> Language Class Initialized
DEBUG - 2011-09-19 02:02:28 --> Loader Class Initialized
DEBUG - 2011-09-19 02:02:28 --> Controller Class Initialized
DEBUG - 2011-09-19 02:02:28 --> Model Class Initialized
DEBUG - 2011-09-19 02:02:28 --> Model Class Initialized
DEBUG - 2011-09-19 02:02:28 --> Model Class Initialized
DEBUG - 2011-09-19 02:02:28 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-19 02:02:28 --> Database Driver Class Initialized
DEBUG - 2011-09-19 02:02:29 --> File loaded: application/views/table/main.php
DEBUG - 2011-09-19 02:02:29 --> Helper loaded: url_helper
DEBUG - 2011-09-19 02:02:29 --> File loaded: application/views/common/header.php
DEBUG - 2011-09-19 02:02:29 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-09-19 02:02:29 --> File loaded: application/views/common/footer.php
DEBUG - 2011-09-19 02:02:29 --> File loaded: application/views/layout/main.php
DEBUG - 2011-09-19 02:02:29 --> Final output sent to browser
DEBUG - 2011-09-19 02:02:29 --> Total execution time: 1.1666
DEBUG - 2011-09-19 02:02:41 --> Config Class Initialized
DEBUG - 2011-09-19 02:02:41 --> Hooks Class Initialized
DEBUG - 2011-09-19 02:02:41 --> Utf8 Class Initialized
DEBUG - 2011-09-19 02:02:41 --> UTF-8 Support Enabled
DEBUG - 2011-09-19 02:02:41 --> URI Class Initialized
DEBUG - 2011-09-19 02:02:41 --> Router Class Initialized
DEBUG - 2011-09-19 02:02:41 --> Output Class Initialized
DEBUG - 2011-09-19 02:02:41 --> Input Class Initialized
DEBUG - 2011-09-19 02:02:41 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-19 02:02:41 --> Language Class Initialized
DEBUG - 2011-09-19 02:02:41 --> Loader Class Initialized
DEBUG - 2011-09-19 02:02:41 --> Controller Class Initialized
DEBUG - 2011-09-19 02:02:41 --> Model Class Initialized
DEBUG - 2011-09-19 02:02:41 --> Model Class Initialized
DEBUG - 2011-09-19 02:02:41 --> Model Class Initialized
DEBUG - 2011-09-19 02:02:41 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-19 02:02:41 --> Database Driver Class Initialized
DEBUG - 2011-09-19 02:02:44 --> File loaded: application/views/table/main.php
DEBUG - 2011-09-19 02:02:44 --> Helper loaded: url_helper
DEBUG - 2011-09-19 02:02:44 --> File loaded: application/views/common/header.php
DEBUG - 2011-09-19 02:02:44 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-09-19 02:02:44 --> File loaded: application/views/common/footer.php
DEBUG - 2011-09-19 02:02:44 --> File loaded: application/views/layout/main.php
DEBUG - 2011-09-19 02:02:44 --> Final output sent to browser
DEBUG - 2011-09-19 02:02:44 --> Total execution time: 3.8400
DEBUG - 2011-09-19 02:02:56 --> Config Class Initialized
DEBUG - 2011-09-19 02:02:56 --> Hooks Class Initialized
DEBUG - 2011-09-19 02:02:56 --> Utf8 Class Initialized
DEBUG - 2011-09-19 02:02:56 --> UTF-8 Support Enabled
DEBUG - 2011-09-19 02:02:56 --> URI Class Initialized
DEBUG - 2011-09-19 02:02:56 --> Router Class Initialized
DEBUG - 2011-09-19 02:02:56 --> Output Class Initialized
DEBUG - 2011-09-19 02:02:56 --> Input Class Initialized
DEBUG - 2011-09-19 02:02:56 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-19 02:02:56 --> Language Class Initialized
DEBUG - 2011-09-19 02:02:56 --> Loader Class Initialized
DEBUG - 2011-09-19 02:02:56 --> Controller Class Initialized
DEBUG - 2011-09-19 02:02:56 --> Model Class Initialized
DEBUG - 2011-09-19 02:02:56 --> Model Class Initialized
DEBUG - 2011-09-19 02:02:56 --> Model Class Initialized
DEBUG - 2011-09-19 02:02:56 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-19 02:02:56 --> Database Driver Class Initialized
DEBUG - 2011-09-19 02:02:58 --> File loaded: application/views/table/main.php
DEBUG - 2011-09-19 02:02:58 --> Helper loaded: url_helper
DEBUG - 2011-09-19 02:02:58 --> File loaded: application/views/common/header.php
DEBUG - 2011-09-19 02:02:58 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-09-19 02:02:58 --> File loaded: application/views/common/footer.php
DEBUG - 2011-09-19 02:02:58 --> File loaded: application/views/layout/main.php
DEBUG - 2011-09-19 02:02:58 --> Final output sent to browser
DEBUG - 2011-09-19 02:02:58 --> Total execution time: 2.4790
DEBUG - 2011-09-19 02:03:07 --> Config Class Initialized
DEBUG - 2011-09-19 02:03:07 --> Hooks Class Initialized
DEBUG - 2011-09-19 02:03:07 --> Utf8 Class Initialized
DEBUG - 2011-09-19 02:03:07 --> UTF-8 Support Enabled
DEBUG - 2011-09-19 02:03:07 --> URI Class Initialized
DEBUG - 2011-09-19 02:03:07 --> Router Class Initialized
DEBUG - 2011-09-19 02:03:07 --> Output Class Initialized
DEBUG - 2011-09-19 02:03:07 --> Input Class Initialized
DEBUG - 2011-09-19 02:03:07 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-19 02:03:07 --> Language Class Initialized
DEBUG - 2011-09-19 02:03:07 --> Loader Class Initialized
DEBUG - 2011-09-19 02:03:07 --> Controller Class Initialized
DEBUG - 2011-09-19 02:03:07 --> Model Class Initialized
DEBUG - 2011-09-19 02:03:07 --> Model Class Initialized
DEBUG - 2011-09-19 02:03:07 --> Model Class Initialized
DEBUG - 2011-09-19 02:03:07 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-19 02:03:07 --> Database Driver Class Initialized
DEBUG - 2011-09-19 02:03:09 --> File loaded: application/views/table/main.php
DEBUG - 2011-09-19 02:03:09 --> Helper loaded: url_helper
DEBUG - 2011-09-19 02:03:09 --> File loaded: application/views/common/header.php
DEBUG - 2011-09-19 02:03:09 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-09-19 02:03:09 --> File loaded: application/views/common/footer.php
DEBUG - 2011-09-19 02:03:09 --> File loaded: application/views/layout/main.php
DEBUG - 2011-09-19 02:03:09 --> Final output sent to browser
DEBUG - 2011-09-19 02:03:09 --> Total execution time: 2.1412
DEBUG - 2011-09-19 02:03:16 --> Config Class Initialized
DEBUG - 2011-09-19 02:03:16 --> Hooks Class Initialized
DEBUG - 2011-09-19 02:03:16 --> Utf8 Class Initialized
DEBUG - 2011-09-19 02:03:16 --> UTF-8 Support Enabled
DEBUG - 2011-09-19 02:03:16 --> URI Class Initialized
DEBUG - 2011-09-19 02:03:16 --> Router Class Initialized
DEBUG - 2011-09-19 02:03:16 --> Output Class Initialized
DEBUG - 2011-09-19 02:03:16 --> Input Class Initialized
DEBUG - 2011-09-19 02:03:16 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-19 02:03:16 --> Language Class Initialized
DEBUG - 2011-09-19 02:03:16 --> Loader Class Initialized
DEBUG - 2011-09-19 02:03:16 --> Controller Class Initialized
DEBUG - 2011-09-19 02:03:16 --> Model Class Initialized
DEBUG - 2011-09-19 02:03:16 --> Model Class Initialized
DEBUG - 2011-09-19 02:03:16 --> Model Class Initialized
DEBUG - 2011-09-19 02:03:16 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-19 02:03:16 --> Database Driver Class Initialized
DEBUG - 2011-09-19 02:03:17 --> File loaded: application/views/table/main.php
DEBUG - 2011-09-19 02:03:17 --> Helper loaded: url_helper
DEBUG - 2011-09-19 02:03:17 --> File loaded: application/views/common/header.php
DEBUG - 2011-09-19 02:03:17 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-09-19 02:03:17 --> File loaded: application/views/common/footer.php
DEBUG - 2011-09-19 02:03:17 --> File loaded: application/views/layout/main.php
DEBUG - 2011-09-19 02:03:17 --> Final output sent to browser
DEBUG - 2011-09-19 02:03:17 --> Total execution time: 1.1998
DEBUG - 2011-09-19 02:06:29 --> Config Class Initialized
DEBUG - 2011-09-19 02:06:29 --> Hooks Class Initialized
DEBUG - 2011-09-19 02:06:29 --> Utf8 Class Initialized
DEBUG - 2011-09-19 02:06:29 --> UTF-8 Support Enabled
DEBUG - 2011-09-19 02:06:29 --> URI Class Initialized
DEBUG - 2011-09-19 02:06:29 --> Router Class Initialized
ERROR - 2011-09-19 02:06:29 --> 404 Page Not Found --> robots.txt
DEBUG - 2011-09-19 02:06:30 --> Config Class Initialized
DEBUG - 2011-09-19 02:06:30 --> Hooks Class Initialized
DEBUG - 2011-09-19 02:06:30 --> Utf8 Class Initialized
DEBUG - 2011-09-19 02:06:30 --> UTF-8 Support Enabled
DEBUG - 2011-09-19 02:06:30 --> URI Class Initialized
DEBUG - 2011-09-19 02:06:30 --> Router Class Initialized
DEBUG - 2011-09-19 02:06:30 --> Output Class Initialized
DEBUG - 2011-09-19 02:06:30 --> Input Class Initialized
DEBUG - 2011-09-19 02:06:30 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-19 02:06:30 --> Language Class Initialized
DEBUG - 2011-09-19 02:06:30 --> Loader Class Initialized
DEBUG - 2011-09-19 02:06:30 --> Controller Class Initialized
DEBUG - 2011-09-19 02:06:30 --> Model Class Initialized
DEBUG - 2011-09-19 02:06:30 --> Model Class Initialized
DEBUG - 2011-09-19 02:06:30 --> Model Class Initialized
DEBUG - 2011-09-19 02:06:30 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-19 02:06:30 --> Database Driver Class Initialized
DEBUG - 2011-09-19 02:06:30 --> File loaded: application/views/table/main.php
DEBUG - 2011-09-19 02:06:30 --> Helper loaded: url_helper
DEBUG - 2011-09-19 02:06:30 --> File loaded: application/views/common/header.php
DEBUG - 2011-09-19 02:06:30 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-09-19 02:06:30 --> File loaded: application/views/common/footer.php
DEBUG - 2011-09-19 02:06:30 --> File loaded: application/views/layout/main.php
DEBUG - 2011-09-19 02:06:30 --> Final output sent to browser
DEBUG - 2011-09-19 02:06:30 --> Total execution time: 0.0838
DEBUG - 2011-09-19 02:07:02 --> Config Class Initialized
DEBUG - 2011-09-19 02:07:02 --> Hooks Class Initialized
DEBUG - 2011-09-19 02:07:02 --> Utf8 Class Initialized
DEBUG - 2011-09-19 02:07:02 --> UTF-8 Support Enabled
DEBUG - 2011-09-19 02:07:02 --> URI Class Initialized
DEBUG - 2011-09-19 02:07:02 --> Router Class Initialized
DEBUG - 2011-09-19 02:07:02 --> Output Class Initialized
DEBUG - 2011-09-19 02:07:03 --> Input Class Initialized
DEBUG - 2011-09-19 02:07:03 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-19 02:07:03 --> Language Class Initialized
DEBUG - 2011-09-19 02:07:03 --> Loader Class Initialized
DEBUG - 2011-09-19 02:07:03 --> Controller Class Initialized
DEBUG - 2011-09-19 02:07:03 --> Model Class Initialized
DEBUG - 2011-09-19 02:07:03 --> Model Class Initialized
DEBUG - 2011-09-19 02:07:03 --> Model Class Initialized
DEBUG - 2011-09-19 02:07:03 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-19 02:07:03 --> Database Driver Class Initialized
DEBUG - 2011-09-19 02:07:03 --> File loaded: application/views/table/main.php
DEBUG - 2011-09-19 02:07:03 --> Helper loaded: url_helper
DEBUG - 2011-09-19 02:07:03 --> File loaded: application/views/common/header.php
DEBUG - 2011-09-19 02:07:03 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-09-19 02:07:03 --> File loaded: application/views/common/footer.php
DEBUG - 2011-09-19 02:07:03 --> File loaded: application/views/layout/main.php
DEBUG - 2011-09-19 02:07:03 --> Final output sent to browser
DEBUG - 2011-09-19 02:07:03 --> Total execution time: 0.0882
DEBUG - 2011-09-19 02:08:21 --> Config Class Initialized
DEBUG - 2011-09-19 02:08:21 --> Hooks Class Initialized
DEBUG - 2011-09-19 02:08:21 --> Utf8 Class Initialized
DEBUG - 2011-09-19 02:08:21 --> UTF-8 Support Enabled
DEBUG - 2011-09-19 02:08:21 --> URI Class Initialized
DEBUG - 2011-09-19 02:08:21 --> Router Class Initialized
DEBUG - 2011-09-19 02:08:21 --> Output Class Initialized
DEBUG - 2011-09-19 02:08:21 --> Input Class Initialized
DEBUG - 2011-09-19 02:08:21 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-19 02:08:21 --> Language Class Initialized
DEBUG - 2011-09-19 02:08:21 --> Loader Class Initialized
DEBUG - 2011-09-19 02:08:21 --> Controller Class Initialized
DEBUG - 2011-09-19 02:08:21 --> Model Class Initialized
DEBUG - 2011-09-19 02:08:21 --> Model Class Initialized
DEBUG - 2011-09-19 02:08:21 --> Model Class Initialized
DEBUG - 2011-09-19 02:08:21 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-19 02:08:21 --> Database Driver Class Initialized
DEBUG - 2011-09-19 02:08:21 --> File loaded: application/views/table/main.php
DEBUG - 2011-09-19 02:08:21 --> Helper loaded: url_helper
DEBUG - 2011-09-19 02:08:21 --> File loaded: application/views/common/header.php
DEBUG - 2011-09-19 02:08:21 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-09-19 02:08:21 --> File loaded: application/views/common/footer.php
DEBUG - 2011-09-19 02:08:21 --> File loaded: application/views/layout/main.php
DEBUG - 2011-09-19 02:08:21 --> Final output sent to browser
DEBUG - 2011-09-19 02:08:21 --> Total execution time: 0.1511
DEBUG - 2011-09-19 02:08:28 --> Config Class Initialized
DEBUG - 2011-09-19 02:08:28 --> Hooks Class Initialized
DEBUG - 2011-09-19 02:08:28 --> Utf8 Class Initialized
DEBUG - 2011-09-19 02:08:28 --> UTF-8 Support Enabled
DEBUG - 2011-09-19 02:08:28 --> URI Class Initialized
DEBUG - 2011-09-19 02:08:28 --> Router Class Initialized
DEBUG - 2011-09-19 02:08:28 --> Output Class Initialized
DEBUG - 2011-09-19 02:08:28 --> Input Class Initialized
DEBUG - 2011-09-19 02:08:28 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-19 02:08:28 --> Language Class Initialized
DEBUG - 2011-09-19 02:08:28 --> Loader Class Initialized
DEBUG - 2011-09-19 02:08:28 --> Controller Class Initialized
DEBUG - 2011-09-19 02:08:28 --> Model Class Initialized
DEBUG - 2011-09-19 02:08:28 --> Model Class Initialized
DEBUG - 2011-09-19 02:08:28 --> Model Class Initialized
DEBUG - 2011-09-19 02:08:28 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-19 02:08:29 --> Database Driver Class Initialized
DEBUG - 2011-09-19 02:08:29 --> File loaded: application/views/table/main.php
DEBUG - 2011-09-19 02:08:29 --> Helper loaded: url_helper
DEBUG - 2011-09-19 02:08:29 --> File loaded: application/views/common/header.php
DEBUG - 2011-09-19 02:08:29 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-09-19 02:08:29 --> File loaded: application/views/common/footer.php
DEBUG - 2011-09-19 02:08:29 --> File loaded: application/views/layout/main.php
DEBUG - 2011-09-19 02:08:29 --> Final output sent to browser
DEBUG - 2011-09-19 02:08:29 --> Total execution time: 0.0525
DEBUG - 2011-09-19 02:08:32 --> Config Class Initialized
DEBUG - 2011-09-19 02:08:32 --> Hooks Class Initialized
DEBUG - 2011-09-19 02:08:32 --> Utf8 Class Initialized
DEBUG - 2011-09-19 02:08:32 --> UTF-8 Support Enabled
DEBUG - 2011-09-19 02:08:32 --> URI Class Initialized
DEBUG - 2011-09-19 02:08:32 --> Router Class Initialized
DEBUG - 2011-09-19 02:08:32 --> Output Class Initialized
DEBUG - 2011-09-19 02:08:32 --> Input Class Initialized
DEBUG - 2011-09-19 02:08:32 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-19 02:08:32 --> Language Class Initialized
DEBUG - 2011-09-19 02:08:32 --> Loader Class Initialized
DEBUG - 2011-09-19 02:08:32 --> Controller Class Initialized
DEBUG - 2011-09-19 02:08:32 --> Model Class Initialized
DEBUG - 2011-09-19 02:08:32 --> Model Class Initialized
DEBUG - 2011-09-19 02:08:32 --> Model Class Initialized
DEBUG - 2011-09-19 02:08:32 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-19 02:08:32 --> Database Driver Class Initialized
DEBUG - 2011-09-19 02:08:32 --> File loaded: application/views/table/main.php
DEBUG - 2011-09-19 02:08:32 --> Helper loaded: url_helper
DEBUG - 2011-09-19 02:08:32 --> File loaded: application/views/common/header.php
DEBUG - 2011-09-19 02:08:32 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-09-19 02:08:32 --> File loaded: application/views/common/footer.php
DEBUG - 2011-09-19 02:08:32 --> File loaded: application/views/layout/main.php
DEBUG - 2011-09-19 02:08:32 --> Final output sent to browser
DEBUG - 2011-09-19 02:08:32 --> Total execution time: 0.0513
DEBUG - 2011-09-19 02:08:34 --> Config Class Initialized
DEBUG - 2011-09-19 02:08:34 --> Hooks Class Initialized
DEBUG - 2011-09-19 02:08:34 --> Utf8 Class Initialized
DEBUG - 2011-09-19 02:08:34 --> UTF-8 Support Enabled
DEBUG - 2011-09-19 02:08:34 --> URI Class Initialized
DEBUG - 2011-09-19 02:08:34 --> Router Class Initialized
DEBUG - 2011-09-19 02:08:34 --> Output Class Initialized
DEBUG - 2011-09-19 02:08:34 --> Input Class Initialized
DEBUG - 2011-09-19 02:08:34 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-19 02:08:34 --> Language Class Initialized
DEBUG - 2011-09-19 02:08:34 --> Loader Class Initialized
DEBUG - 2011-09-19 02:08:34 --> Controller Class Initialized
DEBUG - 2011-09-19 02:08:34 --> Model Class Initialized
DEBUG - 2011-09-19 02:08:34 --> Model Class Initialized
DEBUG - 2011-09-19 02:08:34 --> Model Class Initialized
DEBUG - 2011-09-19 02:08:34 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-19 02:08:34 --> Database Driver Class Initialized
DEBUG - 2011-09-19 02:08:34 --> File loaded: application/views/table/main.php
DEBUG - 2011-09-19 02:08:34 --> Helper loaded: url_helper
DEBUG - 2011-09-19 02:08:34 --> File loaded: application/views/common/header.php
DEBUG - 2011-09-19 02:08:34 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-09-19 02:08:34 --> File loaded: application/views/common/footer.php
DEBUG - 2011-09-19 02:08:34 --> File loaded: application/views/layout/main.php
DEBUG - 2011-09-19 02:08:34 --> Final output sent to browser
DEBUG - 2011-09-19 02:08:34 --> Total execution time: 0.0503
DEBUG - 2011-09-19 02:08:34 --> Config Class Initialized
DEBUG - 2011-09-19 02:08:34 --> Hooks Class Initialized
DEBUG - 2011-09-19 02:08:34 --> Utf8 Class Initialized
DEBUG - 2011-09-19 02:08:34 --> UTF-8 Support Enabled
DEBUG - 2011-09-19 02:08:34 --> URI Class Initialized
DEBUG - 2011-09-19 02:08:34 --> Router Class Initialized
DEBUG - 2011-09-19 02:08:34 --> Output Class Initialized
DEBUG - 2011-09-19 02:08:34 --> Input Class Initialized
DEBUG - 2011-09-19 02:08:34 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-19 02:08:34 --> Language Class Initialized
DEBUG - 2011-09-19 02:08:34 --> Loader Class Initialized
DEBUG - 2011-09-19 02:08:34 --> Controller Class Initialized
DEBUG - 2011-09-19 02:08:34 --> Model Class Initialized
DEBUG - 2011-09-19 02:08:34 --> Model Class Initialized
DEBUG - 2011-09-19 02:08:34 --> Model Class Initialized
DEBUG - 2011-09-19 02:08:34 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-19 02:08:34 --> Database Driver Class Initialized
DEBUG - 2011-09-19 02:08:34 --> File loaded: application/views/table/main.php
DEBUG - 2011-09-19 02:08:34 --> Helper loaded: url_helper
DEBUG - 2011-09-19 02:08:34 --> File loaded: application/views/common/header.php
DEBUG - 2011-09-19 02:08:34 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-09-19 02:08:34 --> File loaded: application/views/common/footer.php
DEBUG - 2011-09-19 02:08:34 --> File loaded: application/views/layout/main.php
DEBUG - 2011-09-19 02:08:34 --> Final output sent to browser
DEBUG - 2011-09-19 02:08:34 --> Total execution time: 0.0488
DEBUG - 2011-09-19 02:08:37 --> Config Class Initialized
DEBUG - 2011-09-19 02:08:37 --> Hooks Class Initialized
DEBUG - 2011-09-19 02:08:37 --> Utf8 Class Initialized
DEBUG - 2011-09-19 02:08:37 --> UTF-8 Support Enabled
DEBUG - 2011-09-19 02:08:37 --> URI Class Initialized
DEBUG - 2011-09-19 02:08:37 --> Router Class Initialized
DEBUG - 2011-09-19 02:08:37 --> Output Class Initialized
DEBUG - 2011-09-19 02:08:37 --> Input Class Initialized
DEBUG - 2011-09-19 02:08:37 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-19 02:08:37 --> Language Class Initialized
DEBUG - 2011-09-19 02:08:37 --> Loader Class Initialized
DEBUG - 2011-09-19 02:08:37 --> Controller Class Initialized
DEBUG - 2011-09-19 02:08:37 --> Model Class Initialized
DEBUG - 2011-09-19 02:08:37 --> Model Class Initialized
DEBUG - 2011-09-19 02:08:37 --> Model Class Initialized
DEBUG - 2011-09-19 02:08:37 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-19 02:08:37 --> Database Driver Class Initialized
DEBUG - 2011-09-19 02:08:37 --> File loaded: application/views/table/main.php
DEBUG - 2011-09-19 02:08:37 --> Helper loaded: url_helper
DEBUG - 2011-09-19 02:08:37 --> File loaded: application/views/common/header.php
DEBUG - 2011-09-19 02:08:37 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-09-19 02:08:37 --> File loaded: application/views/common/footer.php
DEBUG - 2011-09-19 02:08:37 --> File loaded: application/views/layout/main.php
DEBUG - 2011-09-19 02:08:37 --> Final output sent to browser
DEBUG - 2011-09-19 02:08:37 --> Total execution time: 0.0795
DEBUG - 2011-09-19 02:08:42 --> Config Class Initialized
DEBUG - 2011-09-19 02:08:43 --> Hooks Class Initialized
DEBUG - 2011-09-19 02:08:43 --> Utf8 Class Initialized
DEBUG - 2011-09-19 02:08:43 --> UTF-8 Support Enabled
DEBUG - 2011-09-19 02:08:43 --> URI Class Initialized
DEBUG - 2011-09-19 02:08:43 --> Router Class Initialized
DEBUG - 2011-09-19 02:08:43 --> Output Class Initialized
DEBUG - 2011-09-19 02:08:43 --> Input Class Initialized
DEBUG - 2011-09-19 02:08:43 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-19 02:08:43 --> Language Class Initialized
DEBUG - 2011-09-19 02:08:43 --> Loader Class Initialized
DEBUG - 2011-09-19 02:08:43 --> Controller Class Initialized
DEBUG - 2011-09-19 02:08:43 --> Model Class Initialized
DEBUG - 2011-09-19 02:08:43 --> Model Class Initialized
DEBUG - 2011-09-19 02:08:43 --> Model Class Initialized
DEBUG - 2011-09-19 02:08:43 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-19 02:08:43 --> Database Driver Class Initialized
DEBUG - 2011-09-19 02:08:43 --> File loaded: application/views/table/main.php
DEBUG - 2011-09-19 02:08:43 --> Helper loaded: url_helper
DEBUG - 2011-09-19 02:08:43 --> File loaded: application/views/common/header.php
DEBUG - 2011-09-19 02:08:43 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-09-19 02:08:43 --> File loaded: application/views/common/footer.php
DEBUG - 2011-09-19 02:08:43 --> File loaded: application/views/layout/main.php
DEBUG - 2011-09-19 02:08:43 --> Final output sent to browser
DEBUG - 2011-09-19 02:08:43 --> Total execution time: 0.5005
DEBUG - 2011-09-19 02:08:43 --> Config Class Initialized
DEBUG - 2011-09-19 02:08:43 --> Hooks Class Initialized
DEBUG - 2011-09-19 02:08:43 --> Utf8 Class Initialized
DEBUG - 2011-09-19 02:08:43 --> UTF-8 Support Enabled
DEBUG - 2011-09-19 02:08:43 --> URI Class Initialized
DEBUG - 2011-09-19 02:08:43 --> Router Class Initialized
DEBUG - 2011-09-19 02:08:43 --> Output Class Initialized
DEBUG - 2011-09-19 02:08:43 --> Input Class Initialized
DEBUG - 2011-09-19 02:08:43 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-19 02:08:43 --> Language Class Initialized
DEBUG - 2011-09-19 02:08:43 --> Loader Class Initialized
DEBUG - 2011-09-19 02:08:43 --> Controller Class Initialized
DEBUG - 2011-09-19 02:08:43 --> Model Class Initialized
DEBUG - 2011-09-19 02:08:43 --> Model Class Initialized
DEBUG - 2011-09-19 02:08:43 --> Model Class Initialized
DEBUG - 2011-09-19 02:08:43 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-19 02:08:43 --> Database Driver Class Initialized
DEBUG - 2011-09-19 02:08:43 --> File loaded: application/views/table/main.php
DEBUG - 2011-09-19 02:08:43 --> Helper loaded: url_helper
DEBUG - 2011-09-19 02:08:43 --> File loaded: application/views/common/header.php
DEBUG - 2011-09-19 02:08:43 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-09-19 02:08:43 --> File loaded: application/views/common/footer.php
DEBUG - 2011-09-19 02:08:43 --> File loaded: application/views/layout/main.php
DEBUG - 2011-09-19 02:08:43 --> Final output sent to browser
DEBUG - 2011-09-19 02:08:43 --> Total execution time: 0.0916
DEBUG - 2011-09-19 02:08:45 --> Config Class Initialized
DEBUG - 2011-09-19 02:08:45 --> Hooks Class Initialized
DEBUG - 2011-09-19 02:08:45 --> Utf8 Class Initialized
DEBUG - 2011-09-19 02:08:45 --> UTF-8 Support Enabled
DEBUG - 2011-09-19 02:08:45 --> URI Class Initialized
DEBUG - 2011-09-19 02:08:45 --> Router Class Initialized
DEBUG - 2011-09-19 02:08:45 --> Output Class Initialized
DEBUG - 2011-09-19 02:08:45 --> Input Class Initialized
DEBUG - 2011-09-19 02:08:45 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-19 02:08:45 --> Language Class Initialized
DEBUG - 2011-09-19 02:08:45 --> Loader Class Initialized
DEBUG - 2011-09-19 02:08:45 --> Controller Class Initialized
DEBUG - 2011-09-19 02:08:45 --> Model Class Initialized
DEBUG - 2011-09-19 02:08:45 --> Model Class Initialized
DEBUG - 2011-09-19 02:08:45 --> Model Class Initialized
DEBUG - 2011-09-19 02:08:45 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-19 02:08:45 --> Database Driver Class Initialized
DEBUG - 2011-09-19 02:08:45 --> File loaded: application/views/table/main.php
DEBUG - 2011-09-19 02:08:45 --> Helper loaded: url_helper
DEBUG - 2011-09-19 02:08:45 --> File loaded: application/views/common/header.php
DEBUG - 2011-09-19 02:08:45 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-09-19 02:08:45 --> File loaded: application/views/common/footer.php
DEBUG - 2011-09-19 02:08:45 --> File loaded: application/views/layout/main.php
DEBUG - 2011-09-19 02:08:45 --> Final output sent to browser
DEBUG - 2011-09-19 02:08:45 --> Total execution time: 0.0873
DEBUG - 2011-09-19 02:08:48 --> Config Class Initialized
DEBUG - 2011-09-19 02:08:48 --> Hooks Class Initialized
DEBUG - 2011-09-19 02:08:48 --> Utf8 Class Initialized
DEBUG - 2011-09-19 02:08:48 --> UTF-8 Support Enabled
DEBUG - 2011-09-19 02:08:48 --> URI Class Initialized
DEBUG - 2011-09-19 02:08:48 --> Router Class Initialized
DEBUG - 2011-09-19 02:08:48 --> Output Class Initialized
DEBUG - 2011-09-19 02:08:48 --> Input Class Initialized
DEBUG - 2011-09-19 02:08:48 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-19 02:08:48 --> Language Class Initialized
DEBUG - 2011-09-19 02:08:48 --> Loader Class Initialized
DEBUG - 2011-09-19 02:08:48 --> Controller Class Initialized
DEBUG - 2011-09-19 02:08:48 --> Model Class Initialized
DEBUG - 2011-09-19 02:08:48 --> Model Class Initialized
DEBUG - 2011-09-19 02:08:48 --> Model Class Initialized
DEBUG - 2011-09-19 02:08:48 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-19 02:08:48 --> Database Driver Class Initialized
DEBUG - 2011-09-19 02:08:48 --> File loaded: application/views/table/main.php
DEBUG - 2011-09-19 02:08:48 --> Helper loaded: url_helper
DEBUG - 2011-09-19 02:08:48 --> File loaded: application/views/common/header.php
DEBUG - 2011-09-19 02:08:48 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-09-19 02:08:48 --> File loaded: application/views/common/footer.php
DEBUG - 2011-09-19 02:08:48 --> File loaded: application/views/layout/main.php
DEBUG - 2011-09-19 02:08:48 --> Final output sent to browser
DEBUG - 2011-09-19 02:08:48 --> Total execution time: 0.0977
DEBUG - 2011-09-19 02:08:51 --> Config Class Initialized
DEBUG - 2011-09-19 02:08:51 --> Hooks Class Initialized
DEBUG - 2011-09-19 02:08:51 --> Utf8 Class Initialized
DEBUG - 2011-09-19 02:08:51 --> UTF-8 Support Enabled
DEBUG - 2011-09-19 02:08:51 --> URI Class Initialized
DEBUG - 2011-09-19 02:08:51 --> Router Class Initialized
DEBUG - 2011-09-19 02:08:51 --> Output Class Initialized
DEBUG - 2011-09-19 02:08:51 --> Input Class Initialized
DEBUG - 2011-09-19 02:08:51 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-19 02:08:51 --> Language Class Initialized
DEBUG - 2011-09-19 02:08:51 --> Loader Class Initialized
DEBUG - 2011-09-19 02:08:51 --> Controller Class Initialized
DEBUG - 2011-09-19 02:08:51 --> Model Class Initialized
DEBUG - 2011-09-19 02:08:51 --> Model Class Initialized
DEBUG - 2011-09-19 02:08:51 --> Model Class Initialized
DEBUG - 2011-09-19 02:08:51 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-19 02:08:51 --> Database Driver Class Initialized
DEBUG - 2011-09-19 02:08:52 --> File loaded: application/views/table/main.php
DEBUG - 2011-09-19 02:08:52 --> Helper loaded: url_helper
DEBUG - 2011-09-19 02:08:52 --> File loaded: application/views/common/header.php
DEBUG - 2011-09-19 02:08:52 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-09-19 02:08:52 --> File loaded: application/views/common/footer.php
DEBUG - 2011-09-19 02:08:52 --> File loaded: application/views/layout/main.php
DEBUG - 2011-09-19 02:08:52 --> Final output sent to browser
DEBUG - 2011-09-19 02:08:52 --> Total execution time: 0.1343
DEBUG - 2011-09-19 02:08:52 --> Config Class Initialized
DEBUG - 2011-09-19 02:08:52 --> Hooks Class Initialized
DEBUG - 2011-09-19 02:08:52 --> Utf8 Class Initialized
DEBUG - 2011-09-19 02:08:52 --> UTF-8 Support Enabled
DEBUG - 2011-09-19 02:08:52 --> URI Class Initialized
DEBUG - 2011-09-19 02:08:52 --> Router Class Initialized
DEBUG - 2011-09-19 02:08:52 --> Output Class Initialized
DEBUG - 2011-09-19 02:08:52 --> Input Class Initialized
DEBUG - 2011-09-19 02:08:52 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-19 02:08:52 --> Language Class Initialized
DEBUG - 2011-09-19 02:08:52 --> Loader Class Initialized
DEBUG - 2011-09-19 02:08:52 --> Controller Class Initialized
DEBUG - 2011-09-19 02:08:52 --> Model Class Initialized
DEBUG - 2011-09-19 02:08:53 --> Model Class Initialized
DEBUG - 2011-09-19 02:08:53 --> Model Class Initialized
DEBUG - 2011-09-19 02:08:53 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-19 02:08:53 --> Database Driver Class Initialized
DEBUG - 2011-09-19 02:08:53 --> File loaded: application/views/table/main.php
DEBUG - 2011-09-19 02:08:53 --> Helper loaded: url_helper
DEBUG - 2011-09-19 02:08:53 --> File loaded: application/views/common/header.php
DEBUG - 2011-09-19 02:08:53 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-09-19 02:08:53 --> File loaded: application/views/common/footer.php
DEBUG - 2011-09-19 02:08:53 --> File loaded: application/views/layout/main.php
DEBUG - 2011-09-19 02:08:53 --> Final output sent to browser
DEBUG - 2011-09-19 02:08:53 --> Total execution time: 0.0598
DEBUG - 2011-09-19 02:08:55 --> Config Class Initialized
DEBUG - 2011-09-19 02:08:55 --> Hooks Class Initialized
DEBUG - 2011-09-19 02:08:55 --> Utf8 Class Initialized
DEBUG - 2011-09-19 02:08:55 --> UTF-8 Support Enabled
DEBUG - 2011-09-19 02:08:55 --> URI Class Initialized
DEBUG - 2011-09-19 02:08:55 --> Router Class Initialized
DEBUG - 2011-09-19 02:08:55 --> Output Class Initialized
DEBUG - 2011-09-19 02:08:55 --> Input Class Initialized
DEBUG - 2011-09-19 02:08:55 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-19 02:08:55 --> Language Class Initialized
DEBUG - 2011-09-19 02:08:55 --> Loader Class Initialized
DEBUG - 2011-09-19 02:08:55 --> Controller Class Initialized
DEBUG - 2011-09-19 02:08:55 --> Model Class Initialized
DEBUG - 2011-09-19 02:08:55 --> Model Class Initialized
DEBUG - 2011-09-19 02:08:55 --> Model Class Initialized
DEBUG - 2011-09-19 02:08:55 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-19 02:08:55 --> Database Driver Class Initialized
DEBUG - 2011-09-19 02:08:55 --> File loaded: application/views/table/main.php
DEBUG - 2011-09-19 02:08:55 --> Helper loaded: url_helper
DEBUG - 2011-09-19 02:08:55 --> File loaded: application/views/common/header.php
DEBUG - 2011-09-19 02:08:55 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-09-19 02:08:55 --> File loaded: application/views/common/footer.php
DEBUG - 2011-09-19 02:08:55 --> File loaded: application/views/layout/main.php
DEBUG - 2011-09-19 02:08:55 --> Final output sent to browser
DEBUG - 2011-09-19 02:08:55 --> Total execution time: 0.0647
DEBUG - 2011-09-19 02:08:55 --> Config Class Initialized
DEBUG - 2011-09-19 02:08:55 --> Hooks Class Initialized
DEBUG - 2011-09-19 02:08:55 --> Utf8 Class Initialized
DEBUG - 2011-09-19 02:08:55 --> UTF-8 Support Enabled
DEBUG - 2011-09-19 02:08:55 --> URI Class Initialized
DEBUG - 2011-09-19 02:08:55 --> Router Class Initialized
DEBUG - 2011-09-19 02:08:55 --> Output Class Initialized
DEBUG - 2011-09-19 02:08:55 --> Input Class Initialized
DEBUG - 2011-09-19 02:08:55 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-19 02:08:55 --> Language Class Initialized
DEBUG - 2011-09-19 02:08:55 --> Loader Class Initialized
DEBUG - 2011-09-19 02:08:55 --> Controller Class Initialized
DEBUG - 2011-09-19 02:08:55 --> Model Class Initialized
DEBUG - 2011-09-19 02:08:55 --> Model Class Initialized
DEBUG - 2011-09-19 02:08:55 --> Model Class Initialized
DEBUG - 2011-09-19 02:08:55 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-19 02:08:55 --> Database Driver Class Initialized
DEBUG - 2011-09-19 02:08:55 --> File loaded: application/views/table/main.php
DEBUG - 2011-09-19 02:08:55 --> Helper loaded: url_helper
DEBUG - 2011-09-19 02:08:55 --> File loaded: application/views/common/header.php
DEBUG - 2011-09-19 02:08:55 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-09-19 02:08:55 --> File loaded: application/views/common/footer.php
DEBUG - 2011-09-19 02:08:55 --> File loaded: application/views/layout/main.php
DEBUG - 2011-09-19 02:08:55 --> Final output sent to browser
DEBUG - 2011-09-19 02:08:55 --> Total execution time: 0.0445
DEBUG - 2011-09-19 02:09:00 --> Config Class Initialized
DEBUG - 2011-09-19 02:09:00 --> Hooks Class Initialized
DEBUG - 2011-09-19 02:09:00 --> Utf8 Class Initialized
DEBUG - 2011-09-19 02:09:00 --> UTF-8 Support Enabled
DEBUG - 2011-09-19 02:09:00 --> URI Class Initialized
DEBUG - 2011-09-19 02:09:00 --> Router Class Initialized
DEBUG - 2011-09-19 02:09:00 --> Output Class Initialized
DEBUG - 2011-09-19 02:09:00 --> Input Class Initialized
DEBUG - 2011-09-19 02:09:00 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-19 02:09:00 --> Language Class Initialized
DEBUG - 2011-09-19 02:09:00 --> Loader Class Initialized
DEBUG - 2011-09-19 02:09:00 --> Controller Class Initialized
DEBUG - 2011-09-19 02:09:00 --> Model Class Initialized
DEBUG - 2011-09-19 02:09:00 --> Model Class Initialized
DEBUG - 2011-09-19 02:09:00 --> Model Class Initialized
DEBUG - 2011-09-19 02:09:00 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-19 02:09:00 --> Database Driver Class Initialized
DEBUG - 2011-09-19 02:09:00 --> File loaded: application/views/table/main.php
DEBUG - 2011-09-19 02:09:00 --> Helper loaded: url_helper
DEBUG - 2011-09-19 02:09:00 --> File loaded: application/views/common/header.php
DEBUG - 2011-09-19 02:09:00 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-09-19 02:09:00 --> File loaded: application/views/common/footer.php
DEBUG - 2011-09-19 02:09:00 --> File loaded: application/views/layout/main.php
DEBUG - 2011-09-19 02:09:00 --> Final output sent to browser
DEBUG - 2011-09-19 02:09:00 --> Total execution time: 0.1078
DEBUG - 2011-09-19 02:09:51 --> Config Class Initialized
DEBUG - 2011-09-19 02:09:51 --> Hooks Class Initialized
DEBUG - 2011-09-19 02:09:51 --> Utf8 Class Initialized
DEBUG - 2011-09-19 02:09:51 --> UTF-8 Support Enabled
DEBUG - 2011-09-19 02:09:51 --> URI Class Initialized
DEBUG - 2011-09-19 02:09:51 --> Router Class Initialized
DEBUG - 2011-09-19 02:09:51 --> Output Class Initialized
DEBUG - 2011-09-19 02:09:51 --> Input Class Initialized
DEBUG - 2011-09-19 02:09:51 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-19 02:09:51 --> Language Class Initialized
DEBUG - 2011-09-19 02:09:51 --> Loader Class Initialized
DEBUG - 2011-09-19 02:09:51 --> Controller Class Initialized
DEBUG - 2011-09-19 02:09:51 --> Model Class Initialized
DEBUG - 2011-09-19 02:09:51 --> Model Class Initialized
DEBUG - 2011-09-19 02:09:51 --> Model Class Initialized
DEBUG - 2011-09-19 02:09:51 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-19 02:09:51 --> Database Driver Class Initialized
DEBUG - 2011-09-19 02:09:52 --> File loaded: application/views/table/main.php
DEBUG - 2011-09-19 02:09:52 --> Helper loaded: url_helper
DEBUG - 2011-09-19 02:09:52 --> File loaded: application/views/common/header.php
DEBUG - 2011-09-19 02:09:52 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-09-19 02:09:52 --> File loaded: application/views/common/footer.php
DEBUG - 2011-09-19 02:09:52 --> File loaded: application/views/layout/main.php
DEBUG - 2011-09-19 02:09:52 --> Final output sent to browser
DEBUG - 2011-09-19 02:09:52 --> Total execution time: 0.3315
DEBUG - 2011-09-19 02:09:53 --> Config Class Initialized
DEBUG - 2011-09-19 02:09:53 --> Hooks Class Initialized
DEBUG - 2011-09-19 02:09:53 --> Utf8 Class Initialized
DEBUG - 2011-09-19 02:09:53 --> UTF-8 Support Enabled
DEBUG - 2011-09-19 02:09:53 --> URI Class Initialized
DEBUG - 2011-09-19 02:09:53 --> Router Class Initialized
DEBUG - 2011-09-19 02:09:53 --> Output Class Initialized
DEBUG - 2011-09-19 02:09:53 --> Input Class Initialized
DEBUG - 2011-09-19 02:09:53 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-19 02:09:53 --> Language Class Initialized
DEBUG - 2011-09-19 02:09:53 --> Loader Class Initialized
DEBUG - 2011-09-19 02:09:53 --> Controller Class Initialized
DEBUG - 2011-09-19 02:09:53 --> Model Class Initialized
DEBUG - 2011-09-19 02:09:53 --> Model Class Initialized
DEBUG - 2011-09-19 02:09:53 --> Model Class Initialized
DEBUG - 2011-09-19 02:09:53 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-19 02:09:53 --> Database Driver Class Initialized
DEBUG - 2011-09-19 02:09:53 --> File loaded: application/views/table/main.php
DEBUG - 2011-09-19 02:09:53 --> Helper loaded: url_helper
DEBUG - 2011-09-19 02:09:53 --> File loaded: application/views/common/header.php
DEBUG - 2011-09-19 02:09:53 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-09-19 02:09:53 --> File loaded: application/views/common/footer.php
DEBUG - 2011-09-19 02:09:53 --> File loaded: application/views/layout/main.php
DEBUG - 2011-09-19 02:09:53 --> Final output sent to browser
DEBUG - 2011-09-19 02:09:53 --> Total execution time: 0.0909
DEBUG - 2011-09-19 02:09:54 --> Config Class Initialized
DEBUG - 2011-09-19 02:09:54 --> Hooks Class Initialized
DEBUG - 2011-09-19 02:09:54 --> Utf8 Class Initialized
DEBUG - 2011-09-19 02:09:54 --> UTF-8 Support Enabled
DEBUG - 2011-09-19 02:09:54 --> URI Class Initialized
DEBUG - 2011-09-19 02:09:54 --> Router Class Initialized
DEBUG - 2011-09-19 02:09:54 --> Output Class Initialized
DEBUG - 2011-09-19 02:09:54 --> Input Class Initialized
DEBUG - 2011-09-19 02:09:54 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-19 02:09:54 --> Language Class Initialized
DEBUG - 2011-09-19 02:09:54 --> Loader Class Initialized
DEBUG - 2011-09-19 02:09:54 --> Controller Class Initialized
DEBUG - 2011-09-19 02:09:54 --> Model Class Initialized
DEBUG - 2011-09-19 02:09:54 --> Model Class Initialized
DEBUG - 2011-09-19 02:09:54 --> Model Class Initialized
DEBUG - 2011-09-19 02:09:54 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-19 02:09:54 --> Database Driver Class Initialized
DEBUG - 2011-09-19 02:09:55 --> File loaded: application/views/table/main.php
DEBUG - 2011-09-19 02:09:55 --> Helper loaded: url_helper
DEBUG - 2011-09-19 02:09:55 --> File loaded: application/views/common/header.php
DEBUG - 2011-09-19 02:09:55 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-09-19 02:09:55 --> File loaded: application/views/common/footer.php
DEBUG - 2011-09-19 02:09:55 --> File loaded: application/views/layout/main.php
DEBUG - 2011-09-19 02:09:55 --> Final output sent to browser
DEBUG - 2011-09-19 02:09:55 --> Total execution time: 0.0557
DEBUG - 2011-09-19 02:09:59 --> Config Class Initialized
DEBUG - 2011-09-19 02:09:59 --> Hooks Class Initialized
DEBUG - 2011-09-19 02:09:59 --> Utf8 Class Initialized
DEBUG - 2011-09-19 02:09:59 --> UTF-8 Support Enabled
DEBUG - 2011-09-19 02:09:59 --> URI Class Initialized
DEBUG - 2011-09-19 02:09:59 --> Router Class Initialized
DEBUG - 2011-09-19 02:09:59 --> Output Class Initialized
DEBUG - 2011-09-19 02:09:59 --> Input Class Initialized
DEBUG - 2011-09-19 02:09:59 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-19 02:10:00 --> Language Class Initialized
DEBUG - 2011-09-19 02:10:00 --> Loader Class Initialized
DEBUG - 2011-09-19 02:10:00 --> Controller Class Initialized
DEBUG - 2011-09-19 02:10:00 --> Model Class Initialized
DEBUG - 2011-09-19 02:10:00 --> Model Class Initialized
DEBUG - 2011-09-19 02:10:00 --> Model Class Initialized
DEBUG - 2011-09-19 02:10:00 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-19 02:10:00 --> Database Driver Class Initialized
DEBUG - 2011-09-19 02:10:00 --> File loaded: application/views/table/main.php
DEBUG - 2011-09-19 02:10:00 --> Helper loaded: url_helper
DEBUG - 2011-09-19 02:10:00 --> File loaded: application/views/common/header.php
DEBUG - 2011-09-19 02:10:00 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-09-19 02:10:00 --> File loaded: application/views/common/footer.php
DEBUG - 2011-09-19 02:10:00 --> File loaded: application/views/layout/main.php
DEBUG - 2011-09-19 02:10:00 --> Final output sent to browser
DEBUG - 2011-09-19 02:10:00 --> Total execution time: 0.1343
DEBUG - 2011-09-19 02:11:23 --> Config Class Initialized
DEBUG - 2011-09-19 02:11:23 --> Hooks Class Initialized
DEBUG - 2011-09-19 02:11:23 --> Utf8 Class Initialized
DEBUG - 2011-09-19 02:11:23 --> UTF-8 Support Enabled
DEBUG - 2011-09-19 02:11:23 --> URI Class Initialized
DEBUG - 2011-09-19 02:11:23 --> Router Class Initialized
DEBUG - 2011-09-19 02:11:23 --> Output Class Initialized
DEBUG - 2011-09-19 02:11:23 --> Input Class Initialized
DEBUG - 2011-09-19 02:11:23 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-19 02:11:23 --> Language Class Initialized
DEBUG - 2011-09-19 02:11:23 --> Loader Class Initialized
DEBUG - 2011-09-19 02:11:23 --> Controller Class Initialized
DEBUG - 2011-09-19 02:11:23 --> Model Class Initialized
DEBUG - 2011-09-19 02:11:23 --> Model Class Initialized
DEBUG - 2011-09-19 02:11:23 --> Model Class Initialized
DEBUG - 2011-09-19 02:11:23 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-19 02:11:23 --> Database Driver Class Initialized
DEBUG - 2011-09-19 02:11:24 --> File loaded: application/views/table/main.php
DEBUG - 2011-09-19 02:11:24 --> Helper loaded: url_helper
DEBUG - 2011-09-19 02:11:24 --> File loaded: application/views/common/header.php
DEBUG - 2011-09-19 02:11:24 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-09-19 02:11:24 --> File loaded: application/views/common/footer.php
DEBUG - 2011-09-19 02:11:24 --> File loaded: application/views/layout/main.php
DEBUG - 2011-09-19 02:11:24 --> Final output sent to browser
DEBUG - 2011-09-19 02:11:24 --> Total execution time: 0.7058
DEBUG - 2011-09-19 02:11:48 --> Config Class Initialized
DEBUG - 2011-09-19 02:11:48 --> Hooks Class Initialized
DEBUG - 2011-09-19 02:11:48 --> Utf8 Class Initialized
DEBUG - 2011-09-19 02:11:48 --> UTF-8 Support Enabled
DEBUG - 2011-09-19 02:11:48 --> URI Class Initialized
DEBUG - 2011-09-19 02:11:48 --> Router Class Initialized
DEBUG - 2011-09-19 02:11:48 --> Output Class Initialized
DEBUG - 2011-09-19 02:11:48 --> Input Class Initialized
DEBUG - 2011-09-19 02:11:48 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-19 02:11:48 --> Language Class Initialized
DEBUG - 2011-09-19 02:11:48 --> Loader Class Initialized
DEBUG - 2011-09-19 02:11:48 --> Controller Class Initialized
DEBUG - 2011-09-19 02:11:48 --> Model Class Initialized
DEBUG - 2011-09-19 02:11:48 --> Model Class Initialized
DEBUG - 2011-09-19 02:11:48 --> Model Class Initialized
DEBUG - 2011-09-19 02:11:48 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-19 02:11:48 --> Database Driver Class Initialized
DEBUG - 2011-09-19 02:11:48 --> File loaded: application/views/table/main.php
DEBUG - 2011-09-19 02:11:48 --> Helper loaded: url_helper
DEBUG - 2011-09-19 02:11:48 --> File loaded: application/views/common/header.php
DEBUG - 2011-09-19 02:11:48 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-09-19 02:11:48 --> File loaded: application/views/common/footer.php
DEBUG - 2011-09-19 02:11:48 --> File loaded: application/views/layout/main.php
DEBUG - 2011-09-19 02:11:48 --> Final output sent to browser
DEBUG - 2011-09-19 02:11:48 --> Total execution time: 0.0480
DEBUG - 2011-09-19 02:12:02 --> Config Class Initialized
DEBUG - 2011-09-19 02:12:02 --> Hooks Class Initialized
DEBUG - 2011-09-19 02:12:02 --> Utf8 Class Initialized
DEBUG - 2011-09-19 02:12:02 --> UTF-8 Support Enabled
DEBUG - 2011-09-19 02:12:02 --> URI Class Initialized
DEBUG - 2011-09-19 02:12:02 --> Router Class Initialized
DEBUG - 2011-09-19 02:12:02 --> Output Class Initialized
DEBUG - 2011-09-19 02:12:02 --> Input Class Initialized
DEBUG - 2011-09-19 02:12:02 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-19 02:12:02 --> Language Class Initialized
DEBUG - 2011-09-19 02:12:02 --> Loader Class Initialized
DEBUG - 2011-09-19 02:12:02 --> Controller Class Initialized
DEBUG - 2011-09-19 02:12:02 --> Model Class Initialized
DEBUG - 2011-09-19 02:12:02 --> Model Class Initialized
DEBUG - 2011-09-19 02:12:02 --> Model Class Initialized
DEBUG - 2011-09-19 02:12:02 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-19 02:12:02 --> Database Driver Class Initialized
DEBUG - 2011-09-19 02:12:02 --> File loaded: application/views/table/main.php
DEBUG - 2011-09-19 02:12:02 --> Helper loaded: url_helper
DEBUG - 2011-09-19 02:12:02 --> File loaded: application/views/common/header.php
DEBUG - 2011-09-19 02:12:02 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-09-19 02:12:02 --> File loaded: application/views/common/footer.php
DEBUG - 2011-09-19 02:12:02 --> File loaded: application/views/layout/main.php
DEBUG - 2011-09-19 02:12:02 --> Final output sent to browser
DEBUG - 2011-09-19 02:12:02 --> Total execution time: 0.1333
DEBUG - 2011-09-19 02:12:19 --> Config Class Initialized
DEBUG - 2011-09-19 02:12:19 --> Hooks Class Initialized
DEBUG - 2011-09-19 02:12:19 --> Utf8 Class Initialized
DEBUG - 2011-09-19 02:12:19 --> UTF-8 Support Enabled
DEBUG - 2011-09-19 02:12:19 --> URI Class Initialized
DEBUG - 2011-09-19 02:12:19 --> Router Class Initialized
DEBUG - 2011-09-19 02:12:19 --> Output Class Initialized
DEBUG - 2011-09-19 02:12:19 --> Input Class Initialized
DEBUG - 2011-09-19 02:12:19 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-19 02:12:19 --> Language Class Initialized
DEBUG - 2011-09-19 02:12:19 --> Loader Class Initialized
DEBUG - 2011-09-19 02:12:19 --> Controller Class Initialized
DEBUG - 2011-09-19 02:12:19 --> Model Class Initialized
DEBUG - 2011-09-19 02:12:19 --> Model Class Initialized
DEBUG - 2011-09-19 02:12:19 --> Model Class Initialized
DEBUG - 2011-09-19 02:12:19 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-19 02:12:19 --> Database Driver Class Initialized
DEBUG - 2011-09-19 02:12:19 --> File loaded: application/views/table/main.php
DEBUG - 2011-09-19 02:12:19 --> Helper loaded: url_helper
DEBUG - 2011-09-19 02:12:19 --> File loaded: application/views/common/header.php
DEBUG - 2011-09-19 02:12:19 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-09-19 02:12:19 --> File loaded: application/views/common/footer.php
DEBUG - 2011-09-19 02:12:19 --> File loaded: application/views/layout/main.php
DEBUG - 2011-09-19 02:12:19 --> Final output sent to browser
DEBUG - 2011-09-19 02:12:19 --> Total execution time: 0.1370
DEBUG - 2011-09-19 02:12:20 --> Config Class Initialized
DEBUG - 2011-09-19 02:12:20 --> Hooks Class Initialized
DEBUG - 2011-09-19 02:12:20 --> Utf8 Class Initialized
DEBUG - 2011-09-19 02:12:20 --> UTF-8 Support Enabled
DEBUG - 2011-09-19 02:12:20 --> URI Class Initialized
DEBUG - 2011-09-19 02:12:20 --> Router Class Initialized
DEBUG - 2011-09-19 02:12:20 --> Output Class Initialized
DEBUG - 2011-09-19 02:12:20 --> Input Class Initialized
DEBUG - 2011-09-19 02:12:20 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-19 02:12:20 --> Language Class Initialized
DEBUG - 2011-09-19 02:12:20 --> Loader Class Initialized
DEBUG - 2011-09-19 02:12:20 --> Controller Class Initialized
DEBUG - 2011-09-19 02:12:20 --> Model Class Initialized
DEBUG - 2011-09-19 02:12:20 --> Model Class Initialized
DEBUG - 2011-09-19 02:12:20 --> Model Class Initialized
DEBUG - 2011-09-19 02:12:20 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-19 02:12:20 --> Database Driver Class Initialized
DEBUG - 2011-09-19 02:12:20 --> File loaded: application/views/table/main.php
DEBUG - 2011-09-19 02:12:20 --> Helper loaded: url_helper
DEBUG - 2011-09-19 02:12:20 --> File loaded: application/views/common/header.php
DEBUG - 2011-09-19 02:12:20 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-09-19 02:12:20 --> File loaded: application/views/common/footer.php
DEBUG - 2011-09-19 02:12:20 --> File loaded: application/views/layout/main.php
DEBUG - 2011-09-19 02:12:20 --> Final output sent to browser
DEBUG - 2011-09-19 02:12:20 --> Total execution time: 0.0778
DEBUG - 2011-09-19 02:12:22 --> Config Class Initialized
DEBUG - 2011-09-19 02:12:22 --> Hooks Class Initialized
DEBUG - 2011-09-19 02:12:22 --> Utf8 Class Initialized
DEBUG - 2011-09-19 02:12:22 --> UTF-8 Support Enabled
DEBUG - 2011-09-19 02:12:22 --> URI Class Initialized
DEBUG - 2011-09-19 02:12:22 --> Router Class Initialized
DEBUG - 2011-09-19 02:12:22 --> Output Class Initialized
DEBUG - 2011-09-19 02:12:22 --> Input Class Initialized
DEBUG - 2011-09-19 02:12:22 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-19 02:12:22 --> Language Class Initialized
DEBUG - 2011-09-19 02:12:22 --> Loader Class Initialized
DEBUG - 2011-09-19 02:12:22 --> Controller Class Initialized
DEBUG - 2011-09-19 02:12:22 --> Model Class Initialized
DEBUG - 2011-09-19 02:12:22 --> Model Class Initialized
DEBUG - 2011-09-19 02:12:22 --> Model Class Initialized
DEBUG - 2011-09-19 02:12:22 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-19 02:12:22 --> Database Driver Class Initialized
DEBUG - 2011-09-19 02:12:22 --> File loaded: application/views/table/main.php
DEBUG - 2011-09-19 02:12:22 --> Helper loaded: url_helper
DEBUG - 2011-09-19 02:12:22 --> File loaded: application/views/common/header.php
DEBUG - 2011-09-19 02:12:22 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-09-19 02:12:22 --> File loaded: application/views/common/footer.php
DEBUG - 2011-09-19 02:12:22 --> File loaded: application/views/layout/main.php
DEBUG - 2011-09-19 02:12:22 --> Final output sent to browser
DEBUG - 2011-09-19 02:12:22 --> Total execution time: 0.1967
DEBUG - 2011-09-19 02:15:54 --> Config Class Initialized
DEBUG - 2011-09-19 02:15:54 --> Hooks Class Initialized
DEBUG - 2011-09-19 02:15:54 --> Utf8 Class Initialized
DEBUG - 2011-09-19 02:15:54 --> UTF-8 Support Enabled
DEBUG - 2011-09-19 02:15:54 --> URI Class Initialized
DEBUG - 2011-09-19 02:15:54 --> Router Class Initialized
DEBUG - 2011-09-19 02:15:54 --> Output Class Initialized
DEBUG - 2011-09-19 02:15:54 --> Input Class Initialized
DEBUG - 2011-09-19 02:15:54 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-19 02:15:54 --> Language Class Initialized
DEBUG - 2011-09-19 02:15:54 --> Loader Class Initialized
DEBUG - 2011-09-19 02:15:54 --> Controller Class Initialized
DEBUG - 2011-09-19 02:15:54 --> Model Class Initialized
DEBUG - 2011-09-19 02:15:54 --> Model Class Initialized
DEBUG - 2011-09-19 02:15:54 --> Model Class Initialized
DEBUG - 2011-09-19 02:15:54 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-19 02:15:54 --> Database Driver Class Initialized
DEBUG - 2011-09-19 02:15:56 --> File loaded: application/views/table/main.php
DEBUG - 2011-09-19 02:15:56 --> Helper loaded: url_helper
DEBUG - 2011-09-19 02:15:56 --> File loaded: application/views/common/header.php
DEBUG - 2011-09-19 02:15:56 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-09-19 02:15:56 --> File loaded: application/views/common/footer.php
DEBUG - 2011-09-19 02:15:56 --> File loaded: application/views/layout/main.php
DEBUG - 2011-09-19 02:15:56 --> Final output sent to browser
DEBUG - 2011-09-19 02:15:56 --> Total execution time: 1.9821
DEBUG - 2011-09-19 02:15:56 --> Config Class Initialized
DEBUG - 2011-09-19 02:15:56 --> Hooks Class Initialized
DEBUG - 2011-09-19 02:15:56 --> Utf8 Class Initialized
DEBUG - 2011-09-19 02:15:56 --> UTF-8 Support Enabled
DEBUG - 2011-09-19 02:15:56 --> URI Class Initialized
DEBUG - 2011-09-19 02:15:56 --> Router Class Initialized
DEBUG - 2011-09-19 02:15:56 --> Output Class Initialized
DEBUG - 2011-09-19 02:15:56 --> Input Class Initialized
DEBUG - 2011-09-19 02:15:56 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-19 02:15:56 --> Language Class Initialized
DEBUG - 2011-09-19 02:15:56 --> Loader Class Initialized
DEBUG - 2011-09-19 02:15:56 --> Controller Class Initialized
ERROR - 2011-09-19 02:15:56 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-09-19 02:15:56 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-09-19 02:15:56 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-09-19 02:15:56 --> Model Class Initialized
DEBUG - 2011-09-19 02:15:56 --> Model Class Initialized
DEBUG - 2011-09-19 02:15:56 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-19 02:15:56 --> Database Driver Class Initialized
DEBUG - 2011-09-19 02:15:56 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-09-19 02:15:56 --> Helper loaded: url_helper
DEBUG - 2011-09-19 02:15:56 --> File loaded: application/views/common/header.php
DEBUG - 2011-09-19 02:15:56 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-09-19 02:15:56 --> File loaded: application/views/common/footer.php
DEBUG - 2011-09-19 02:15:56 --> File loaded: application/views/layout/main.php
DEBUG - 2011-09-19 02:15:56 --> Final output sent to browser
DEBUG - 2011-09-19 02:15:56 --> Total execution time: 0.0360
DEBUG - 2011-09-19 02:16:09 --> Config Class Initialized
DEBUG - 2011-09-19 02:16:09 --> Hooks Class Initialized
DEBUG - 2011-09-19 02:16:09 --> Utf8 Class Initialized
DEBUG - 2011-09-19 02:16:09 --> UTF-8 Support Enabled
DEBUG - 2011-09-19 02:16:09 --> URI Class Initialized
DEBUG - 2011-09-19 02:16:09 --> Router Class Initialized
DEBUG - 2011-09-19 02:16:09 --> Output Class Initialized
DEBUG - 2011-09-19 02:16:09 --> Input Class Initialized
DEBUG - 2011-09-19 02:16:09 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-19 02:16:09 --> Language Class Initialized
DEBUG - 2011-09-19 02:16:09 --> Loader Class Initialized
DEBUG - 2011-09-19 02:16:09 --> Controller Class Initialized
DEBUG - 2011-09-19 02:16:09 --> Model Class Initialized
DEBUG - 2011-09-19 02:16:09 --> Model Class Initialized
DEBUG - 2011-09-19 02:16:09 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-19 02:16:09 --> Database Driver Class Initialized
DEBUG - 2011-09-19 02:16:10 --> Final output sent to browser
DEBUG - 2011-09-19 02:16:10 --> Total execution time: 1.2975
DEBUG - 2011-09-19 02:16:13 --> Config Class Initialized
DEBUG - 2011-09-19 02:16:13 --> Hooks Class Initialized
DEBUG - 2011-09-19 02:16:13 --> Utf8 Class Initialized
DEBUG - 2011-09-19 02:16:13 --> UTF-8 Support Enabled
DEBUG - 2011-09-19 02:16:13 --> URI Class Initialized
DEBUG - 2011-09-19 02:16:13 --> Router Class Initialized
ERROR - 2011-09-19 02:16:13 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-09-19 02:16:26 --> Config Class Initialized
DEBUG - 2011-09-19 02:16:26 --> Hooks Class Initialized
DEBUG - 2011-09-19 02:16:26 --> Utf8 Class Initialized
DEBUG - 2011-09-19 02:16:26 --> UTF-8 Support Enabled
DEBUG - 2011-09-19 02:16:26 --> URI Class Initialized
DEBUG - 2011-09-19 02:16:26 --> Router Class Initialized
DEBUG - 2011-09-19 02:16:26 --> Output Class Initialized
DEBUG - 2011-09-19 02:16:26 --> Input Class Initialized
DEBUG - 2011-09-19 02:16:26 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-19 02:16:26 --> Language Class Initialized
DEBUG - 2011-09-19 02:16:26 --> Loader Class Initialized
DEBUG - 2011-09-19 02:16:26 --> Controller Class Initialized
DEBUG - 2011-09-19 02:16:26 --> Model Class Initialized
DEBUG - 2011-09-19 02:16:26 --> Model Class Initialized
DEBUG - 2011-09-19 02:16:26 --> Model Class Initialized
DEBUG - 2011-09-19 02:16:26 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-19 02:16:26 --> Database Driver Class Initialized
DEBUG - 2011-09-19 02:16:26 --> File loaded: application/views/table/main.php
DEBUG - 2011-09-19 02:16:26 --> Helper loaded: url_helper
DEBUG - 2011-09-19 02:16:26 --> File loaded: application/views/common/header.php
DEBUG - 2011-09-19 02:16:26 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-09-19 02:16:26 --> File loaded: application/views/common/footer.php
DEBUG - 2011-09-19 02:16:26 --> File loaded: application/views/layout/main.php
DEBUG - 2011-09-19 02:16:26 --> Final output sent to browser
DEBUG - 2011-09-19 02:16:26 --> Total execution time: 0.2104
DEBUG - 2011-09-19 02:16:47 --> Config Class Initialized
DEBUG - 2011-09-19 02:16:47 --> Hooks Class Initialized
DEBUG - 2011-09-19 02:16:47 --> Utf8 Class Initialized
DEBUG - 2011-09-19 02:16:47 --> UTF-8 Support Enabled
DEBUG - 2011-09-19 02:16:47 --> URI Class Initialized
DEBUG - 2011-09-19 02:16:47 --> Router Class Initialized
DEBUG - 2011-09-19 02:16:47 --> Output Class Initialized
DEBUG - 2011-09-19 02:16:47 --> Input Class Initialized
DEBUG - 2011-09-19 02:16:47 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-19 02:16:47 --> Language Class Initialized
DEBUG - 2011-09-19 02:16:47 --> Loader Class Initialized
DEBUG - 2011-09-19 02:16:47 --> Controller Class Initialized
DEBUG - 2011-09-19 02:16:47 --> Model Class Initialized
DEBUG - 2011-09-19 02:16:47 --> Model Class Initialized
DEBUG - 2011-09-19 02:16:47 --> Model Class Initialized
DEBUG - 2011-09-19 02:16:47 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-19 02:16:47 --> Database Driver Class Initialized
DEBUG - 2011-09-19 02:16:47 --> File loaded: application/views/table/main.php
DEBUG - 2011-09-19 02:16:47 --> Helper loaded: url_helper
DEBUG - 2011-09-19 02:16:47 --> File loaded: application/views/common/header.php
DEBUG - 2011-09-19 02:16:47 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-09-19 02:16:47 --> File loaded: application/views/common/footer.php
DEBUG - 2011-09-19 02:16:47 --> File loaded: application/views/layout/main.php
DEBUG - 2011-09-19 02:16:47 --> Final output sent to browser
DEBUG - 2011-09-19 02:16:47 --> Total execution time: 0.0444
DEBUG - 2011-09-19 02:17:03 --> Config Class Initialized
DEBUG - 2011-09-19 02:17:03 --> Hooks Class Initialized
DEBUG - 2011-09-19 02:17:03 --> Utf8 Class Initialized
DEBUG - 2011-09-19 02:17:03 --> UTF-8 Support Enabled
DEBUG - 2011-09-19 02:17:03 --> URI Class Initialized
DEBUG - 2011-09-19 02:17:03 --> Router Class Initialized
DEBUG - 2011-09-19 02:17:03 --> Output Class Initialized
DEBUG - 2011-09-19 02:17:03 --> Input Class Initialized
DEBUG - 2011-09-19 02:17:03 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-19 02:17:03 --> Language Class Initialized
DEBUG - 2011-09-19 02:17:03 --> Loader Class Initialized
DEBUG - 2011-09-19 02:17:03 --> Controller Class Initialized
DEBUG - 2011-09-19 02:17:03 --> Model Class Initialized
DEBUG - 2011-09-19 02:17:03 --> Model Class Initialized
DEBUG - 2011-09-19 02:17:03 --> Model Class Initialized
DEBUG - 2011-09-19 02:17:03 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-19 02:17:04 --> Database Driver Class Initialized
DEBUG - 2011-09-19 02:17:04 --> File loaded: application/views/table/main.php
DEBUG - 2011-09-19 02:17:04 --> Helper loaded: url_helper
DEBUG - 2011-09-19 02:17:04 --> File loaded: application/views/common/header.php
DEBUG - 2011-09-19 02:17:04 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-09-19 02:17:04 --> File loaded: application/views/common/footer.php
DEBUG - 2011-09-19 02:17:04 --> File loaded: application/views/layout/main.php
DEBUG - 2011-09-19 02:17:04 --> Final output sent to browser
DEBUG - 2011-09-19 02:17:04 --> Total execution time: 0.0674
DEBUG - 2011-09-19 02:17:19 --> Config Class Initialized
DEBUG - 2011-09-19 02:17:19 --> Hooks Class Initialized
DEBUG - 2011-09-19 02:17:19 --> Utf8 Class Initialized
DEBUG - 2011-09-19 02:17:19 --> UTF-8 Support Enabled
DEBUG - 2011-09-19 02:17:19 --> URI Class Initialized
DEBUG - 2011-09-19 02:17:19 --> Router Class Initialized
DEBUG - 2011-09-19 02:17:19 --> Output Class Initialized
DEBUG - 2011-09-19 02:17:19 --> Input Class Initialized
DEBUG - 2011-09-19 02:17:19 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-19 02:17:19 --> Language Class Initialized
DEBUG - 2011-09-19 02:17:19 --> Loader Class Initialized
DEBUG - 2011-09-19 02:17:19 --> Controller Class Initialized
DEBUG - 2011-09-19 02:17:19 --> Model Class Initialized
DEBUG - 2011-09-19 02:17:19 --> Model Class Initialized
DEBUG - 2011-09-19 02:17:19 --> Model Class Initialized
DEBUG - 2011-09-19 02:17:19 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-19 02:17:19 --> Database Driver Class Initialized
DEBUG - 2011-09-19 02:17:20 --> File loaded: application/views/table/main.php
DEBUG - 2011-09-19 02:17:20 --> Helper loaded: url_helper
DEBUG - 2011-09-19 02:17:20 --> File loaded: application/views/common/header.php
DEBUG - 2011-09-19 02:17:20 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-09-19 02:17:20 --> File loaded: application/views/common/footer.php
DEBUG - 2011-09-19 02:17:20 --> File loaded: application/views/layout/main.php
DEBUG - 2011-09-19 02:17:20 --> Final output sent to browser
DEBUG - 2011-09-19 02:17:20 --> Total execution time: 0.9667
DEBUG - 2011-09-19 02:17:48 --> Config Class Initialized
DEBUG - 2011-09-19 02:17:48 --> Hooks Class Initialized
DEBUG - 2011-09-19 02:17:48 --> Utf8 Class Initialized
DEBUG - 2011-09-19 02:17:48 --> UTF-8 Support Enabled
DEBUG - 2011-09-19 02:17:48 --> URI Class Initialized
DEBUG - 2011-09-19 02:17:48 --> Router Class Initialized
DEBUG - 2011-09-19 02:17:48 --> Output Class Initialized
DEBUG - 2011-09-19 02:17:48 --> Input Class Initialized
DEBUG - 2011-09-19 02:17:48 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-19 02:17:48 --> Language Class Initialized
DEBUG - 2011-09-19 02:17:48 --> Loader Class Initialized
DEBUG - 2011-09-19 02:17:48 --> Controller Class Initialized
DEBUG - 2011-09-19 02:17:48 --> Model Class Initialized
DEBUG - 2011-09-19 02:17:48 --> Model Class Initialized
DEBUG - 2011-09-19 02:17:48 --> Model Class Initialized
DEBUG - 2011-09-19 02:17:48 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-19 02:17:48 --> Database Driver Class Initialized
DEBUG - 2011-09-19 02:17:48 --> File loaded: application/views/table/main.php
DEBUG - 2011-09-19 02:17:48 --> Helper loaded: url_helper
DEBUG - 2011-09-19 02:17:48 --> File loaded: application/views/common/header.php
DEBUG - 2011-09-19 02:17:48 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-09-19 02:17:48 --> File loaded: application/views/common/footer.php
DEBUG - 2011-09-19 02:17:48 --> File loaded: application/views/layout/main.php
DEBUG - 2011-09-19 02:17:48 --> Final output sent to browser
DEBUG - 2011-09-19 02:17:48 --> Total execution time: 0.1652
DEBUG - 2011-09-19 02:28:06 --> Config Class Initialized
DEBUG - 2011-09-19 02:28:06 --> Hooks Class Initialized
DEBUG - 2011-09-19 02:28:06 --> Utf8 Class Initialized
DEBUG - 2011-09-19 02:28:06 --> UTF-8 Support Enabled
DEBUG - 2011-09-19 02:28:06 --> URI Class Initialized
DEBUG - 2011-09-19 02:28:06 --> Router Class Initialized
DEBUG - 2011-09-19 02:28:06 --> Output Class Initialized
DEBUG - 2011-09-19 02:28:06 --> Input Class Initialized
DEBUG - 2011-09-19 02:28:06 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-19 02:28:06 --> Language Class Initialized
DEBUG - 2011-09-19 02:28:06 --> Loader Class Initialized
DEBUG - 2011-09-19 02:28:06 --> Controller Class Initialized
DEBUG - 2011-09-19 02:28:06 --> Model Class Initialized
DEBUG - 2011-09-19 02:28:06 --> Model Class Initialized
DEBUG - 2011-09-19 02:28:06 --> Model Class Initialized
DEBUG - 2011-09-19 02:28:06 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-19 02:28:06 --> Database Driver Class Initialized
DEBUG - 2011-09-19 02:28:06 --> File loaded: application/views/table/main.php
DEBUG - 2011-09-19 02:28:06 --> Helper loaded: url_helper
DEBUG - 2011-09-19 02:28:06 --> File loaded: application/views/common/header.php
DEBUG - 2011-09-19 02:28:06 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-09-19 02:28:06 --> File loaded: application/views/common/footer.php
DEBUG - 2011-09-19 02:28:06 --> File loaded: application/views/layout/main.php
DEBUG - 2011-09-19 02:28:06 --> Final output sent to browser
DEBUG - 2011-09-19 02:28:06 --> Total execution time: 0.2489
DEBUG - 2011-09-19 02:30:25 --> Config Class Initialized
DEBUG - 2011-09-19 02:30:25 --> Hooks Class Initialized
DEBUG - 2011-09-19 02:30:25 --> Utf8 Class Initialized
DEBUG - 2011-09-19 02:30:25 --> UTF-8 Support Enabled
DEBUG - 2011-09-19 02:30:25 --> URI Class Initialized
DEBUG - 2011-09-19 02:30:25 --> Router Class Initialized
DEBUG - 2011-09-19 02:30:25 --> Output Class Initialized
DEBUG - 2011-09-19 02:30:25 --> Input Class Initialized
DEBUG - 2011-09-19 02:30:25 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-19 02:30:25 --> Language Class Initialized
DEBUG - 2011-09-19 02:30:25 --> Loader Class Initialized
DEBUG - 2011-09-19 02:30:25 --> Controller Class Initialized
DEBUG - 2011-09-19 02:30:25 --> Model Class Initialized
DEBUG - 2011-09-19 02:30:25 --> Model Class Initialized
DEBUG - 2011-09-19 02:30:25 --> Model Class Initialized
DEBUG - 2011-09-19 02:30:25 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-19 02:30:25 --> Database Driver Class Initialized
DEBUG - 2011-09-19 02:30:42 --> File loaded: application/views/table/main.php
DEBUG - 2011-09-19 02:30:42 --> Helper loaded: url_helper
DEBUG - 2011-09-19 02:30:42 --> File loaded: application/views/common/header.php
DEBUG - 2011-09-19 02:30:42 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-09-19 02:30:42 --> File loaded: application/views/common/footer.php
DEBUG - 2011-09-19 02:30:42 --> File loaded: application/views/layout/main.php
DEBUG - 2011-09-19 02:30:42 --> Final output sent to browser
DEBUG - 2011-09-19 02:30:42 --> Total execution time: 17.3380
DEBUG - 2011-09-19 02:31:03 --> Config Class Initialized
DEBUG - 2011-09-19 02:31:03 --> Hooks Class Initialized
DEBUG - 2011-09-19 02:31:03 --> Utf8 Class Initialized
DEBUG - 2011-09-19 02:31:03 --> UTF-8 Support Enabled
DEBUG - 2011-09-19 02:31:03 --> URI Class Initialized
DEBUG - 2011-09-19 02:31:03 --> Router Class Initialized
DEBUG - 2011-09-19 02:31:03 --> Output Class Initialized
DEBUG - 2011-09-19 02:31:03 --> Input Class Initialized
DEBUG - 2011-09-19 02:31:03 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-19 02:31:03 --> Language Class Initialized
DEBUG - 2011-09-19 02:31:03 --> Loader Class Initialized
DEBUG - 2011-09-19 02:31:03 --> Controller Class Initialized
DEBUG - 2011-09-19 02:31:03 --> Model Class Initialized
DEBUG - 2011-09-19 02:31:03 --> Model Class Initialized
DEBUG - 2011-09-19 02:31:03 --> Model Class Initialized
DEBUG - 2011-09-19 02:31:03 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-19 02:31:03 --> Database Driver Class Initialized
DEBUG - 2011-09-19 02:31:03 --> File loaded: application/views/table/main.php
DEBUG - 2011-09-19 02:31:03 --> Helper loaded: url_helper
DEBUG - 2011-09-19 02:31:03 --> File loaded: application/views/common/header.php
DEBUG - 2011-09-19 02:31:03 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-09-19 02:31:03 --> File loaded: application/views/common/footer.php
DEBUG - 2011-09-19 02:31:03 --> File loaded: application/views/layout/main.php
DEBUG - 2011-09-19 02:31:03 --> Final output sent to browser
DEBUG - 2011-09-19 02:31:03 --> Total execution time: 0.0628
DEBUG - 2011-09-19 02:31:13 --> Config Class Initialized
DEBUG - 2011-09-19 02:31:13 --> Hooks Class Initialized
DEBUG - 2011-09-19 02:31:13 --> Utf8 Class Initialized
DEBUG - 2011-09-19 02:31:13 --> UTF-8 Support Enabled
DEBUG - 2011-09-19 02:31:13 --> URI Class Initialized
DEBUG - 2011-09-19 02:31:13 --> Router Class Initialized
DEBUG - 2011-09-19 02:31:13 --> Output Class Initialized
DEBUG - 2011-09-19 02:31:13 --> Input Class Initialized
DEBUG - 2011-09-19 02:31:13 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-19 02:31:13 --> Language Class Initialized
DEBUG - 2011-09-19 02:31:13 --> Loader Class Initialized
DEBUG - 2011-09-19 02:31:13 --> Controller Class Initialized
DEBUG - 2011-09-19 02:31:13 --> Model Class Initialized
DEBUG - 2011-09-19 02:31:13 --> Model Class Initialized
DEBUG - 2011-09-19 02:31:13 --> Model Class Initialized
DEBUG - 2011-09-19 02:31:13 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-19 02:31:13 --> Database Driver Class Initialized
DEBUG - 2011-09-19 02:31:15 --> File loaded: application/views/table/main.php
DEBUG - 2011-09-19 02:31:15 --> Helper loaded: url_helper
DEBUG - 2011-09-19 02:31:15 --> File loaded: application/views/common/header.php
DEBUG - 2011-09-19 02:31:15 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-09-19 02:31:15 --> File loaded: application/views/common/footer.php
DEBUG - 2011-09-19 02:31:15 --> File loaded: application/views/layout/main.php
DEBUG - 2011-09-19 02:31:15 --> Final output sent to browser
DEBUG - 2011-09-19 02:31:15 --> Total execution time: 2.1170
DEBUG - 2011-09-19 02:32:07 --> Config Class Initialized
DEBUG - 2011-09-19 02:32:07 --> Hooks Class Initialized
DEBUG - 2011-09-19 02:32:07 --> Utf8 Class Initialized
DEBUG - 2011-09-19 02:32:07 --> UTF-8 Support Enabled
DEBUG - 2011-09-19 02:32:07 --> URI Class Initialized
DEBUG - 2011-09-19 02:32:07 --> Router Class Initialized
DEBUG - 2011-09-19 02:32:07 --> Output Class Initialized
DEBUG - 2011-09-19 02:32:07 --> Input Class Initialized
DEBUG - 2011-09-19 02:32:07 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-19 02:32:07 --> Language Class Initialized
DEBUG - 2011-09-19 02:32:07 --> Loader Class Initialized
DEBUG - 2011-09-19 02:32:07 --> Controller Class Initialized
DEBUG - 2011-09-19 02:32:07 --> Model Class Initialized
DEBUG - 2011-09-19 02:32:07 --> Model Class Initialized
DEBUG - 2011-09-19 02:32:07 --> Model Class Initialized
DEBUG - 2011-09-19 02:32:07 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-19 02:32:07 --> Database Driver Class Initialized
DEBUG - 2011-09-19 02:32:07 --> File loaded: application/views/table/main.php
DEBUG - 2011-09-19 02:32:07 --> Helper loaded: url_helper
DEBUG - 2011-09-19 02:32:07 --> File loaded: application/views/common/header.php
DEBUG - 2011-09-19 02:32:07 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-09-19 02:32:07 --> File loaded: application/views/common/footer.php
DEBUG - 2011-09-19 02:32:07 --> File loaded: application/views/layout/main.php
DEBUG - 2011-09-19 02:32:07 --> Final output sent to browser
DEBUG - 2011-09-19 02:32:07 --> Total execution time: 0.0655
DEBUG - 2011-09-19 02:32:34 --> Config Class Initialized
DEBUG - 2011-09-19 02:32:34 --> Hooks Class Initialized
DEBUG - 2011-09-19 02:32:34 --> Utf8 Class Initialized
DEBUG - 2011-09-19 02:32:34 --> UTF-8 Support Enabled
DEBUG - 2011-09-19 02:32:34 --> URI Class Initialized
DEBUG - 2011-09-19 02:32:34 --> Router Class Initialized
DEBUG - 2011-09-19 02:32:34 --> Output Class Initialized
DEBUG - 2011-09-19 02:32:34 --> Input Class Initialized
DEBUG - 2011-09-19 02:32:34 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-19 02:32:34 --> Language Class Initialized
DEBUG - 2011-09-19 02:32:34 --> Loader Class Initialized
DEBUG - 2011-09-19 02:32:34 --> Controller Class Initialized
DEBUG - 2011-09-19 02:32:34 --> Model Class Initialized
DEBUG - 2011-09-19 02:32:34 --> Model Class Initialized
DEBUG - 2011-09-19 02:32:34 --> Model Class Initialized
DEBUG - 2011-09-19 02:32:34 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-19 02:32:34 --> Database Driver Class Initialized
DEBUG - 2011-09-19 02:32:34 --> File loaded: application/views/table/main.php
DEBUG - 2011-09-19 02:32:34 --> Helper loaded: url_helper
DEBUG - 2011-09-19 02:32:34 --> File loaded: application/views/common/header.php
DEBUG - 2011-09-19 02:32:34 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-09-19 02:32:34 --> File loaded: application/views/common/footer.php
DEBUG - 2011-09-19 02:32:34 --> File loaded: application/views/layout/main.php
DEBUG - 2011-09-19 02:32:34 --> Final output sent to browser
DEBUG - 2011-09-19 02:32:34 --> Total execution time: 0.4270
DEBUG - 2011-09-19 02:33:49 --> Config Class Initialized
DEBUG - 2011-09-19 02:33:49 --> Hooks Class Initialized
DEBUG - 2011-09-19 02:33:49 --> Utf8 Class Initialized
DEBUG - 2011-09-19 02:33:49 --> UTF-8 Support Enabled
DEBUG - 2011-09-19 02:33:49 --> URI Class Initialized
DEBUG - 2011-09-19 02:33:49 --> Router Class Initialized
DEBUG - 2011-09-19 02:33:49 --> Output Class Initialized
DEBUG - 2011-09-19 02:33:49 --> Input Class Initialized
DEBUG - 2011-09-19 02:33:49 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-19 02:33:49 --> Language Class Initialized
DEBUG - 2011-09-19 02:33:49 --> Loader Class Initialized
DEBUG - 2011-09-19 02:33:49 --> Controller Class Initialized
DEBUG - 2011-09-19 02:33:49 --> Model Class Initialized
DEBUG - 2011-09-19 02:33:49 --> Model Class Initialized
DEBUG - 2011-09-19 02:33:49 --> Model Class Initialized
DEBUG - 2011-09-19 02:33:49 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-19 02:33:49 --> Database Driver Class Initialized
DEBUG - 2011-09-19 02:33:50 --> File loaded: application/views/table/main.php
DEBUG - 2011-09-19 02:33:50 --> Helper loaded: url_helper
DEBUG - 2011-09-19 02:33:50 --> File loaded: application/views/common/header.php
DEBUG - 2011-09-19 02:33:50 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-09-19 02:33:50 --> File loaded: application/views/common/footer.php
DEBUG - 2011-09-19 02:33:50 --> File loaded: application/views/layout/main.php
DEBUG - 2011-09-19 02:33:50 --> Final output sent to browser
DEBUG - 2011-09-19 02:33:50 --> Total execution time: 0.4489
DEBUG - 2011-09-19 02:34:51 --> Config Class Initialized
DEBUG - 2011-09-19 02:34:51 --> Hooks Class Initialized
DEBUG - 2011-09-19 02:34:51 --> Utf8 Class Initialized
DEBUG - 2011-09-19 02:34:51 --> UTF-8 Support Enabled
DEBUG - 2011-09-19 02:34:51 --> URI Class Initialized
DEBUG - 2011-09-19 02:34:51 --> Router Class Initialized
DEBUG - 2011-09-19 02:34:51 --> Output Class Initialized
DEBUG - 2011-09-19 02:34:51 --> Input Class Initialized
DEBUG - 2011-09-19 02:34:51 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-19 02:34:51 --> Language Class Initialized
DEBUG - 2011-09-19 02:34:51 --> Loader Class Initialized
DEBUG - 2011-09-19 02:34:51 --> Controller Class Initialized
DEBUG - 2011-09-19 02:34:51 --> Model Class Initialized
DEBUG - 2011-09-19 02:34:51 --> Model Class Initialized
DEBUG - 2011-09-19 02:34:51 --> Model Class Initialized
DEBUG - 2011-09-19 02:34:51 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-19 02:34:51 --> Database Driver Class Initialized
DEBUG - 2011-09-19 02:34:52 --> File loaded: application/views/table/main.php
DEBUG - 2011-09-19 02:34:52 --> Helper loaded: url_helper
DEBUG - 2011-09-19 02:34:52 --> File loaded: application/views/common/header.php
DEBUG - 2011-09-19 02:34:52 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-09-19 02:34:52 --> File loaded: application/views/common/footer.php
DEBUG - 2011-09-19 02:34:52 --> File loaded: application/views/layout/main.php
DEBUG - 2011-09-19 02:34:52 --> Final output sent to browser
DEBUG - 2011-09-19 02:34:52 --> Total execution time: 0.7591
DEBUG - 2011-09-19 02:39:43 --> Config Class Initialized
DEBUG - 2011-09-19 02:39:43 --> Hooks Class Initialized
DEBUG - 2011-09-19 02:39:43 --> Utf8 Class Initialized
DEBUG - 2011-09-19 02:39:43 --> UTF-8 Support Enabled
DEBUG - 2011-09-19 02:39:43 --> URI Class Initialized
DEBUG - 2011-09-19 02:39:43 --> Router Class Initialized
DEBUG - 2011-09-19 02:39:43 --> Output Class Initialized
DEBUG - 2011-09-19 02:39:43 --> Input Class Initialized
DEBUG - 2011-09-19 02:39:43 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-19 02:39:43 --> Language Class Initialized
DEBUG - 2011-09-19 02:39:43 --> Loader Class Initialized
DEBUG - 2011-09-19 02:39:43 --> Controller Class Initialized
DEBUG - 2011-09-19 02:39:43 --> Model Class Initialized
DEBUG - 2011-09-19 02:39:43 --> Model Class Initialized
DEBUG - 2011-09-19 02:39:43 --> Model Class Initialized
DEBUG - 2011-09-19 02:39:43 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-19 02:39:43 --> Database Driver Class Initialized
DEBUG - 2011-09-19 02:39:47 --> File loaded: application/views/table/main.php
DEBUG - 2011-09-19 02:39:47 --> Helper loaded: url_helper
DEBUG - 2011-09-19 02:39:47 --> File loaded: application/views/common/header.php
DEBUG - 2011-09-19 02:39:47 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-09-19 02:39:47 --> File loaded: application/views/common/footer.php
DEBUG - 2011-09-19 02:39:47 --> File loaded: application/views/layout/main.php
DEBUG - 2011-09-19 02:39:47 --> Final output sent to browser
DEBUG - 2011-09-19 02:39:47 --> Total execution time: 4.5936
DEBUG - 2011-09-19 02:48:06 --> Config Class Initialized
DEBUG - 2011-09-19 02:48:06 --> Hooks Class Initialized
DEBUG - 2011-09-19 02:48:06 --> Utf8 Class Initialized
DEBUG - 2011-09-19 02:48:06 --> UTF-8 Support Enabled
DEBUG - 2011-09-19 02:48:06 --> URI Class Initialized
DEBUG - 2011-09-19 02:48:06 --> Router Class Initialized
DEBUG - 2011-09-19 02:48:06 --> Output Class Initialized
DEBUG - 2011-09-19 02:48:06 --> Input Class Initialized
DEBUG - 2011-09-19 02:48:06 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-19 02:48:06 --> Language Class Initialized
DEBUG - 2011-09-19 02:48:06 --> Loader Class Initialized
DEBUG - 2011-09-19 02:48:06 --> Controller Class Initialized
DEBUG - 2011-09-19 02:48:06 --> Model Class Initialized
DEBUG - 2011-09-19 02:48:06 --> Model Class Initialized
DEBUG - 2011-09-19 02:48:06 --> Model Class Initialized
DEBUG - 2011-09-19 02:48:06 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-19 02:48:06 --> Database Driver Class Initialized
DEBUG - 2011-09-19 02:48:06 --> File loaded: application/views/table/main.php
DEBUG - 2011-09-19 02:48:06 --> Helper loaded: url_helper
DEBUG - 2011-09-19 02:48:06 --> File loaded: application/views/common/header.php
DEBUG - 2011-09-19 02:48:06 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-09-19 02:48:06 --> File loaded: application/views/common/footer.php
DEBUG - 2011-09-19 02:48:06 --> File loaded: application/views/layout/main.php
DEBUG - 2011-09-19 02:48:06 --> Final output sent to browser
DEBUG - 2011-09-19 02:48:06 --> Total execution time: 0.1657
DEBUG - 2011-09-19 02:48:50 --> Config Class Initialized
DEBUG - 2011-09-19 02:48:50 --> Hooks Class Initialized
DEBUG - 2011-09-19 02:48:50 --> Utf8 Class Initialized
DEBUG - 2011-09-19 02:48:50 --> UTF-8 Support Enabled
DEBUG - 2011-09-19 02:48:50 --> URI Class Initialized
DEBUG - 2011-09-19 02:48:50 --> Router Class Initialized
DEBUG - 2011-09-19 02:48:50 --> Output Class Initialized
DEBUG - 2011-09-19 02:48:50 --> Input Class Initialized
DEBUG - 2011-09-19 02:48:50 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-19 02:48:50 --> Language Class Initialized
DEBUG - 2011-09-19 02:48:50 --> Loader Class Initialized
DEBUG - 2011-09-19 02:48:50 --> Controller Class Initialized
DEBUG - 2011-09-19 02:48:50 --> Model Class Initialized
DEBUG - 2011-09-19 02:48:50 --> Model Class Initialized
DEBUG - 2011-09-19 02:48:50 --> Model Class Initialized
DEBUG - 2011-09-19 02:48:50 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-19 02:48:50 --> Database Driver Class Initialized
DEBUG - 2011-09-19 02:48:50 --> File loaded: application/views/table/main.php
DEBUG - 2011-09-19 02:48:50 --> Helper loaded: url_helper
DEBUG - 2011-09-19 02:48:50 --> File loaded: application/views/common/header.php
DEBUG - 2011-09-19 02:48:50 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-09-19 02:48:50 --> File loaded: application/views/common/footer.php
DEBUG - 2011-09-19 02:48:50 --> File loaded: application/views/layout/main.php
DEBUG - 2011-09-19 02:48:50 --> Final output sent to browser
DEBUG - 2011-09-19 02:48:50 --> Total execution time: 0.5000
DEBUG - 2011-09-19 02:50:15 --> Config Class Initialized
DEBUG - 2011-09-19 02:50:15 --> Hooks Class Initialized
DEBUG - 2011-09-19 02:50:15 --> Utf8 Class Initialized
DEBUG - 2011-09-19 02:50:15 --> UTF-8 Support Enabled
DEBUG - 2011-09-19 02:50:15 --> URI Class Initialized
DEBUG - 2011-09-19 02:50:15 --> Router Class Initialized
DEBUG - 2011-09-19 02:50:15 --> Output Class Initialized
DEBUG - 2011-09-19 02:50:15 --> Input Class Initialized
DEBUG - 2011-09-19 02:50:15 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-19 02:50:15 --> Language Class Initialized
DEBUG - 2011-09-19 02:50:15 --> Loader Class Initialized
DEBUG - 2011-09-19 02:50:15 --> Controller Class Initialized
DEBUG - 2011-09-19 02:50:15 --> Model Class Initialized
DEBUG - 2011-09-19 02:50:15 --> Model Class Initialized
DEBUG - 2011-09-19 02:50:15 --> Model Class Initialized
DEBUG - 2011-09-19 02:50:15 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-19 02:50:15 --> Database Driver Class Initialized
DEBUG - 2011-09-19 02:50:17 --> File loaded: application/views/table/main.php
DEBUG - 2011-09-19 02:50:17 --> Helper loaded: url_helper
DEBUG - 2011-09-19 02:50:17 --> File loaded: application/views/common/header.php
DEBUG - 2011-09-19 02:50:17 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-09-19 02:50:17 --> File loaded: application/views/common/footer.php
DEBUG - 2011-09-19 02:50:17 --> File loaded: application/views/layout/main.php
DEBUG - 2011-09-19 02:50:17 --> Final output sent to browser
DEBUG - 2011-09-19 02:50:17 --> Total execution time: 2.1084
DEBUG - 2011-09-19 02:50:56 --> Config Class Initialized
DEBUG - 2011-09-19 02:50:56 --> Hooks Class Initialized
DEBUG - 2011-09-19 02:50:56 --> Utf8 Class Initialized
DEBUG - 2011-09-19 02:50:56 --> UTF-8 Support Enabled
DEBUG - 2011-09-19 02:50:56 --> URI Class Initialized
DEBUG - 2011-09-19 02:50:56 --> Router Class Initialized
DEBUG - 2011-09-19 02:50:56 --> Output Class Initialized
DEBUG - 2011-09-19 02:50:56 --> Input Class Initialized
DEBUG - 2011-09-19 02:50:56 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-19 02:50:56 --> Language Class Initialized
DEBUG - 2011-09-19 02:50:56 --> Loader Class Initialized
DEBUG - 2011-09-19 02:50:56 --> Controller Class Initialized
DEBUG - 2011-09-19 02:50:56 --> Model Class Initialized
DEBUG - 2011-09-19 02:50:56 --> Model Class Initialized
DEBUG - 2011-09-19 02:50:56 --> Model Class Initialized
DEBUG - 2011-09-19 02:50:56 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-19 02:50:56 --> Database Driver Class Initialized
DEBUG - 2011-09-19 02:50:56 --> File loaded: application/views/table/main.php
DEBUG - 2011-09-19 02:50:56 --> Helper loaded: url_helper
DEBUG - 2011-09-19 02:50:56 --> File loaded: application/views/common/header.php
DEBUG - 2011-09-19 02:50:56 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-09-19 02:50:56 --> File loaded: application/views/common/footer.php
DEBUG - 2011-09-19 02:50:56 --> File loaded: application/views/layout/main.php
DEBUG - 2011-09-19 02:50:56 --> Final output sent to browser
DEBUG - 2011-09-19 02:50:56 --> Total execution time: 0.8247
DEBUG - 2011-09-19 02:51:30 --> Config Class Initialized
DEBUG - 2011-09-19 02:51:30 --> Hooks Class Initialized
DEBUG - 2011-09-19 02:51:30 --> Utf8 Class Initialized
DEBUG - 2011-09-19 02:51:30 --> UTF-8 Support Enabled
DEBUG - 2011-09-19 02:51:30 --> URI Class Initialized
DEBUG - 2011-09-19 02:51:30 --> Router Class Initialized
DEBUG - 2011-09-19 02:51:30 --> Output Class Initialized
DEBUG - 2011-09-19 02:51:30 --> Input Class Initialized
DEBUG - 2011-09-19 02:51:30 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-19 02:51:30 --> Language Class Initialized
DEBUG - 2011-09-19 02:51:30 --> Loader Class Initialized
DEBUG - 2011-09-19 02:51:30 --> Controller Class Initialized
DEBUG - 2011-09-19 02:51:30 --> Model Class Initialized
DEBUG - 2011-09-19 02:51:30 --> Model Class Initialized
DEBUG - 2011-09-19 02:51:30 --> Model Class Initialized
DEBUG - 2011-09-19 02:51:30 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-19 02:51:30 --> Database Driver Class Initialized
DEBUG - 2011-09-19 02:51:31 --> File loaded: application/views/table/main.php
DEBUG - 2011-09-19 02:51:31 --> Helper loaded: url_helper
DEBUG - 2011-09-19 02:51:31 --> File loaded: application/views/common/header.php
DEBUG - 2011-09-19 02:51:31 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-09-19 02:51:31 --> File loaded: application/views/common/footer.php
DEBUG - 2011-09-19 02:51:31 --> File loaded: application/views/layout/main.php
DEBUG - 2011-09-19 02:51:31 --> Final output sent to browser
DEBUG - 2011-09-19 02:51:31 --> Total execution time: 0.8192
DEBUG - 2011-09-19 02:52:10 --> Config Class Initialized
DEBUG - 2011-09-19 02:52:10 --> Hooks Class Initialized
DEBUG - 2011-09-19 02:52:10 --> Utf8 Class Initialized
DEBUG - 2011-09-19 02:52:10 --> UTF-8 Support Enabled
DEBUG - 2011-09-19 02:52:10 --> URI Class Initialized
DEBUG - 2011-09-19 02:52:10 --> Router Class Initialized
DEBUG - 2011-09-19 02:52:10 --> Output Class Initialized
DEBUG - 2011-09-19 02:52:10 --> Input Class Initialized
DEBUG - 2011-09-19 02:52:10 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-19 02:52:10 --> Language Class Initialized
DEBUG - 2011-09-19 02:52:10 --> Loader Class Initialized
DEBUG - 2011-09-19 02:52:10 --> Controller Class Initialized
DEBUG - 2011-09-19 02:52:10 --> Model Class Initialized
DEBUG - 2011-09-19 02:52:10 --> Model Class Initialized
DEBUG - 2011-09-19 02:52:10 --> Model Class Initialized
DEBUG - 2011-09-19 02:52:10 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-19 02:52:10 --> Database Driver Class Initialized
DEBUG - 2011-09-19 02:52:11 --> File loaded: application/views/table/main.php
DEBUG - 2011-09-19 02:52:11 --> Helper loaded: url_helper
DEBUG - 2011-09-19 02:52:11 --> File loaded: application/views/common/header.php
DEBUG - 2011-09-19 02:52:11 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-09-19 02:52:11 --> File loaded: application/views/common/footer.php
DEBUG - 2011-09-19 02:52:11 --> File loaded: application/views/layout/main.php
DEBUG - 2011-09-19 02:52:11 --> Final output sent to browser
DEBUG - 2011-09-19 02:52:11 --> Total execution time: 0.7178
DEBUG - 2011-09-19 02:52:36 --> Config Class Initialized
DEBUG - 2011-09-19 02:52:36 --> Hooks Class Initialized
DEBUG - 2011-09-19 02:52:36 --> Utf8 Class Initialized
DEBUG - 2011-09-19 02:52:36 --> UTF-8 Support Enabled
DEBUG - 2011-09-19 02:52:36 --> URI Class Initialized
DEBUG - 2011-09-19 02:52:36 --> Router Class Initialized
DEBUG - 2011-09-19 02:52:36 --> Output Class Initialized
DEBUG - 2011-09-19 02:52:36 --> Input Class Initialized
DEBUG - 2011-09-19 02:52:36 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-19 02:52:36 --> Language Class Initialized
DEBUG - 2011-09-19 02:52:36 --> Loader Class Initialized
DEBUG - 2011-09-19 02:52:36 --> Controller Class Initialized
DEBUG - 2011-09-19 02:52:36 --> Model Class Initialized
DEBUG - 2011-09-19 02:52:36 --> Model Class Initialized
DEBUG - 2011-09-19 02:52:36 --> Model Class Initialized
DEBUG - 2011-09-19 02:52:36 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-19 02:52:36 --> Database Driver Class Initialized
DEBUG - 2011-09-19 02:52:36 --> File loaded: application/views/table/main.php
DEBUG - 2011-09-19 02:52:36 --> Helper loaded: url_helper
DEBUG - 2011-09-19 02:52:36 --> File loaded: application/views/common/header.php
DEBUG - 2011-09-19 02:52:36 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-09-19 02:52:36 --> File loaded: application/views/common/footer.php
DEBUG - 2011-09-19 02:52:36 --> File loaded: application/views/layout/main.php
DEBUG - 2011-09-19 02:52:36 --> Final output sent to browser
DEBUG - 2011-09-19 02:52:36 --> Total execution time: 0.2746
DEBUG - 2011-09-19 02:52:51 --> Config Class Initialized
DEBUG - 2011-09-19 02:52:51 --> Hooks Class Initialized
DEBUG - 2011-09-19 02:52:51 --> Utf8 Class Initialized
DEBUG - 2011-09-19 02:52:51 --> UTF-8 Support Enabled
DEBUG - 2011-09-19 02:52:51 --> URI Class Initialized
DEBUG - 2011-09-19 02:52:51 --> Router Class Initialized
DEBUG - 2011-09-19 02:52:51 --> Output Class Initialized
DEBUG - 2011-09-19 02:52:51 --> Input Class Initialized
DEBUG - 2011-09-19 02:52:51 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-19 02:52:51 --> Language Class Initialized
DEBUG - 2011-09-19 02:52:51 --> Loader Class Initialized
DEBUG - 2011-09-19 02:52:51 --> Controller Class Initialized
DEBUG - 2011-09-19 02:52:51 --> Model Class Initialized
DEBUG - 2011-09-19 02:52:51 --> Model Class Initialized
DEBUG - 2011-09-19 02:52:51 --> Model Class Initialized
DEBUG - 2011-09-19 02:52:51 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-19 02:52:52 --> Database Driver Class Initialized
DEBUG - 2011-09-19 02:52:52 --> File loaded: application/views/table/main.php
DEBUG - 2011-09-19 02:52:52 --> Helper loaded: url_helper
DEBUG - 2011-09-19 02:52:52 --> File loaded: application/views/common/header.php
DEBUG - 2011-09-19 02:52:52 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-09-19 02:52:52 --> File loaded: application/views/common/footer.php
DEBUG - 2011-09-19 02:52:52 --> File loaded: application/views/layout/main.php
DEBUG - 2011-09-19 02:52:52 --> Final output sent to browser
DEBUG - 2011-09-19 02:52:52 --> Total execution time: 0.0845
DEBUG - 2011-09-19 02:53:06 --> Config Class Initialized
DEBUG - 2011-09-19 02:53:06 --> Hooks Class Initialized
DEBUG - 2011-09-19 02:53:06 --> Utf8 Class Initialized
DEBUG - 2011-09-19 02:53:06 --> UTF-8 Support Enabled
DEBUG - 2011-09-19 02:53:06 --> URI Class Initialized
DEBUG - 2011-09-19 02:53:06 --> Router Class Initialized
DEBUG - 2011-09-19 02:53:06 --> Output Class Initialized
DEBUG - 2011-09-19 02:53:06 --> Input Class Initialized
DEBUG - 2011-09-19 02:53:06 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-19 02:53:06 --> Language Class Initialized
DEBUG - 2011-09-19 02:53:06 --> Loader Class Initialized
DEBUG - 2011-09-19 02:53:06 --> Controller Class Initialized
DEBUG - 2011-09-19 02:53:06 --> Model Class Initialized
DEBUG - 2011-09-19 02:53:06 --> Model Class Initialized
DEBUG - 2011-09-19 02:53:06 --> Model Class Initialized
DEBUG - 2011-09-19 02:53:06 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-19 02:53:06 --> Database Driver Class Initialized
DEBUG - 2011-09-19 02:53:07 --> File loaded: application/views/table/main.php
DEBUG - 2011-09-19 02:53:07 --> Helper loaded: url_helper
DEBUG - 2011-09-19 02:53:07 --> File loaded: application/views/common/header.php
DEBUG - 2011-09-19 02:53:07 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-09-19 02:53:07 --> File loaded: application/views/common/footer.php
DEBUG - 2011-09-19 02:53:07 --> File loaded: application/views/layout/main.php
DEBUG - 2011-09-19 02:53:07 --> Final output sent to browser
DEBUG - 2011-09-19 02:53:07 --> Total execution time: 1.0326
DEBUG - 2011-09-19 02:53:10 --> Config Class Initialized
DEBUG - 2011-09-19 02:53:10 --> Hooks Class Initialized
DEBUG - 2011-09-19 02:53:10 --> Utf8 Class Initialized
DEBUG - 2011-09-19 02:53:10 --> UTF-8 Support Enabled
DEBUG - 2011-09-19 02:53:10 --> URI Class Initialized
DEBUG - 2011-09-19 02:53:10 --> Router Class Initialized
DEBUG - 2011-09-19 02:53:10 --> Output Class Initialized
DEBUG - 2011-09-19 02:53:10 --> Input Class Initialized
DEBUG - 2011-09-19 02:53:10 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-19 02:53:10 --> Language Class Initialized
DEBUG - 2011-09-19 02:53:10 --> Loader Class Initialized
DEBUG - 2011-09-19 02:53:10 --> Controller Class Initialized
DEBUG - 2011-09-19 02:53:10 --> Model Class Initialized
DEBUG - 2011-09-19 02:53:10 --> Model Class Initialized
DEBUG - 2011-09-19 02:53:10 --> Model Class Initialized
DEBUG - 2011-09-19 02:53:10 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-19 02:53:10 --> Database Driver Class Initialized
DEBUG - 2011-09-19 02:53:11 --> File loaded: application/views/table/main.php
DEBUG - 2011-09-19 02:53:11 --> Helper loaded: url_helper
DEBUG - 2011-09-19 02:53:11 --> File loaded: application/views/common/header.php
DEBUG - 2011-09-19 02:53:11 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-09-19 02:53:11 --> File loaded: application/views/common/footer.php
DEBUG - 2011-09-19 02:53:11 --> File loaded: application/views/layout/main.php
DEBUG - 2011-09-19 02:53:11 --> Final output sent to browser
DEBUG - 2011-09-19 02:53:11 --> Total execution time: 0.0919
DEBUG - 2011-09-19 02:53:29 --> Config Class Initialized
DEBUG - 2011-09-19 02:53:29 --> Hooks Class Initialized
DEBUG - 2011-09-19 02:53:29 --> Utf8 Class Initialized
DEBUG - 2011-09-19 02:53:29 --> UTF-8 Support Enabled
DEBUG - 2011-09-19 02:53:29 --> URI Class Initialized
DEBUG - 2011-09-19 02:53:29 --> Router Class Initialized
DEBUG - 2011-09-19 02:53:29 --> Output Class Initialized
DEBUG - 2011-09-19 02:53:29 --> Input Class Initialized
DEBUG - 2011-09-19 02:53:29 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-19 02:53:29 --> Language Class Initialized
DEBUG - 2011-09-19 02:53:29 --> Loader Class Initialized
DEBUG - 2011-09-19 02:53:29 --> Controller Class Initialized
DEBUG - 2011-09-19 02:53:29 --> Model Class Initialized
DEBUG - 2011-09-19 02:53:29 --> Model Class Initialized
DEBUG - 2011-09-19 02:53:29 --> Model Class Initialized
DEBUG - 2011-09-19 02:53:29 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-19 02:53:29 --> Database Driver Class Initialized
DEBUG - 2011-09-19 02:53:30 --> File loaded: application/views/table/main.php
DEBUG - 2011-09-19 02:53:30 --> Helper loaded: url_helper
DEBUG - 2011-09-19 02:53:30 --> File loaded: application/views/common/header.php
DEBUG - 2011-09-19 02:53:30 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-09-19 02:53:30 --> File loaded: application/views/common/footer.php
DEBUG - 2011-09-19 02:53:30 --> File loaded: application/views/layout/main.php
DEBUG - 2011-09-19 02:53:30 --> Final output sent to browser
DEBUG - 2011-09-19 02:53:30 --> Total execution time: 0.6074
DEBUG - 2011-09-19 02:53:32 --> Config Class Initialized
DEBUG - 2011-09-19 02:53:32 --> Hooks Class Initialized
DEBUG - 2011-09-19 02:53:32 --> Utf8 Class Initialized
DEBUG - 2011-09-19 02:53:32 --> UTF-8 Support Enabled
DEBUG - 2011-09-19 02:53:32 --> URI Class Initialized
DEBUG - 2011-09-19 02:53:32 --> Router Class Initialized
DEBUG - 2011-09-19 02:53:32 --> Output Class Initialized
DEBUG - 2011-09-19 02:53:32 --> Input Class Initialized
DEBUG - 2011-09-19 02:53:32 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-19 02:53:32 --> Language Class Initialized
DEBUG - 2011-09-19 02:53:32 --> Loader Class Initialized
DEBUG - 2011-09-19 02:53:32 --> Controller Class Initialized
DEBUG - 2011-09-19 02:53:32 --> Model Class Initialized
DEBUG - 2011-09-19 02:53:32 --> Model Class Initialized
DEBUG - 2011-09-19 02:53:32 --> Model Class Initialized
DEBUG - 2011-09-19 02:53:32 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-19 02:53:32 --> Database Driver Class Initialized
DEBUG - 2011-09-19 02:53:32 --> File loaded: application/views/table/main.php
DEBUG - 2011-09-19 02:53:32 --> Helper loaded: url_helper
DEBUG - 2011-09-19 02:53:32 --> File loaded: application/views/common/header.php
DEBUG - 2011-09-19 02:53:32 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-09-19 02:53:32 --> File loaded: application/views/common/footer.php
DEBUG - 2011-09-19 02:53:32 --> File loaded: application/views/layout/main.php
DEBUG - 2011-09-19 02:53:32 --> Final output sent to browser
DEBUG - 2011-09-19 02:53:32 --> Total execution time: 0.0536
DEBUG - 2011-09-19 02:53:55 --> Config Class Initialized
DEBUG - 2011-09-19 02:53:55 --> Hooks Class Initialized
DEBUG - 2011-09-19 02:53:55 --> Utf8 Class Initialized
DEBUG - 2011-09-19 02:53:55 --> UTF-8 Support Enabled
DEBUG - 2011-09-19 02:53:55 --> URI Class Initialized
DEBUG - 2011-09-19 02:53:55 --> Router Class Initialized
DEBUG - 2011-09-19 02:53:55 --> Output Class Initialized
DEBUG - 2011-09-19 02:53:55 --> Input Class Initialized
DEBUG - 2011-09-19 02:53:55 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-19 02:53:55 --> Language Class Initialized
DEBUG - 2011-09-19 02:53:55 --> Loader Class Initialized
DEBUG - 2011-09-19 02:53:55 --> Controller Class Initialized
DEBUG - 2011-09-19 02:53:55 --> Model Class Initialized
DEBUG - 2011-09-19 02:53:55 --> Model Class Initialized
DEBUG - 2011-09-19 02:53:55 --> Model Class Initialized
DEBUG - 2011-09-19 02:53:55 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-19 02:53:55 --> Database Driver Class Initialized
DEBUG - 2011-09-19 02:53:56 --> File loaded: application/views/table/main.php
DEBUG - 2011-09-19 02:53:56 --> Helper loaded: url_helper
DEBUG - 2011-09-19 02:53:56 --> File loaded: application/views/common/header.php
DEBUG - 2011-09-19 02:53:56 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-09-19 02:53:56 --> File loaded: application/views/common/footer.php
DEBUG - 2011-09-19 02:53:56 --> File loaded: application/views/layout/main.php
DEBUG - 2011-09-19 02:53:56 --> Final output sent to browser
DEBUG - 2011-09-19 02:53:56 --> Total execution time: 1.0928
DEBUG - 2011-09-19 02:54:01 --> Config Class Initialized
DEBUG - 2011-09-19 02:54:01 --> Hooks Class Initialized
DEBUG - 2011-09-19 02:54:01 --> Utf8 Class Initialized
DEBUG - 2011-09-19 02:54:01 --> UTF-8 Support Enabled
DEBUG - 2011-09-19 02:54:01 --> URI Class Initialized
DEBUG - 2011-09-19 02:54:01 --> Router Class Initialized
DEBUG - 2011-09-19 02:54:01 --> Output Class Initialized
DEBUG - 2011-09-19 02:54:01 --> Input Class Initialized
DEBUG - 2011-09-19 02:54:01 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-19 02:54:01 --> Language Class Initialized
DEBUG - 2011-09-19 02:54:01 --> Loader Class Initialized
DEBUG - 2011-09-19 02:54:01 --> Controller Class Initialized
DEBUG - 2011-09-19 02:54:01 --> Model Class Initialized
DEBUG - 2011-09-19 02:54:01 --> Model Class Initialized
DEBUG - 2011-09-19 02:54:01 --> Model Class Initialized
DEBUG - 2011-09-19 02:54:01 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-19 02:54:01 --> Database Driver Class Initialized
DEBUG - 2011-09-19 02:54:01 --> File loaded: application/views/table/main.php
DEBUG - 2011-09-19 02:54:01 --> Helper loaded: url_helper
DEBUG - 2011-09-19 02:54:01 --> File loaded: application/views/common/header.php
DEBUG - 2011-09-19 02:54:01 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-09-19 02:54:01 --> File loaded: application/views/common/footer.php
DEBUG - 2011-09-19 02:54:01 --> File loaded: application/views/layout/main.php
DEBUG - 2011-09-19 02:54:01 --> Final output sent to browser
DEBUG - 2011-09-19 02:54:01 --> Total execution time: 0.0936
DEBUG - 2011-09-19 03:40:25 --> Config Class Initialized
DEBUG - 2011-09-19 03:40:25 --> Hooks Class Initialized
DEBUG - 2011-09-19 03:40:25 --> Utf8 Class Initialized
DEBUG - 2011-09-19 03:40:25 --> UTF-8 Support Enabled
DEBUG - 2011-09-19 03:40:25 --> URI Class Initialized
DEBUG - 2011-09-19 03:40:25 --> Router Class Initialized
DEBUG - 2011-09-19 03:40:25 --> Output Class Initialized
DEBUG - 2011-09-19 03:40:25 --> Input Class Initialized
DEBUG - 2011-09-19 03:40:25 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-19 03:40:25 --> Language Class Initialized
DEBUG - 2011-09-19 03:40:26 --> Loader Class Initialized
DEBUG - 2011-09-19 03:40:27 --> Controller Class Initialized
DEBUG - 2011-09-19 03:40:27 --> Model Class Initialized
DEBUG - 2011-09-19 03:40:27 --> Model Class Initialized
DEBUG - 2011-09-19 03:40:27 --> Model Class Initialized
DEBUG - 2011-09-19 03:40:27 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-19 03:40:27 --> Database Driver Class Initialized
DEBUG - 2011-09-19 03:40:44 --> File loaded: application/views/table/main.php
DEBUG - 2011-09-19 03:40:44 --> Helper loaded: url_helper
DEBUG - 2011-09-19 03:40:44 --> File loaded: application/views/common/header.php
DEBUG - 2011-09-19 03:40:44 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-09-19 03:40:44 --> File loaded: application/views/common/footer.php
DEBUG - 2011-09-19 03:40:44 --> File loaded: application/views/layout/main.php
DEBUG - 2011-09-19 03:40:44 --> Final output sent to browser
DEBUG - 2011-09-19 03:40:44 --> Total execution time: 18.8004
DEBUG - 2011-09-19 03:40:48 --> Config Class Initialized
DEBUG - 2011-09-19 03:40:48 --> Hooks Class Initialized
DEBUG - 2011-09-19 03:40:48 --> Utf8 Class Initialized
DEBUG - 2011-09-19 03:40:48 --> UTF-8 Support Enabled
DEBUG - 2011-09-19 03:40:48 --> URI Class Initialized
DEBUG - 2011-09-19 03:40:48 --> Router Class Initialized
DEBUG - 2011-09-19 03:40:48 --> Output Class Initialized
DEBUG - 2011-09-19 03:40:48 --> Input Class Initialized
DEBUG - 2011-09-19 03:40:48 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-19 03:40:48 --> Language Class Initialized
DEBUG - 2011-09-19 03:40:48 --> Loader Class Initialized
DEBUG - 2011-09-19 03:40:48 --> Controller Class Initialized
ERROR - 2011-09-19 03:40:48 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-09-19 03:40:48 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-09-19 03:40:48 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-09-19 03:40:48 --> Model Class Initialized
DEBUG - 2011-09-19 03:40:48 --> Model Class Initialized
DEBUG - 2011-09-19 03:40:48 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-19 03:40:48 --> Database Driver Class Initialized
DEBUG - 2011-09-19 03:40:48 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-09-19 03:40:48 --> Helper loaded: url_helper
DEBUG - 2011-09-19 03:40:48 --> File loaded: application/views/common/header.php
DEBUG - 2011-09-19 03:40:48 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-09-19 03:40:48 --> File loaded: application/views/common/footer.php
DEBUG - 2011-09-19 03:40:48 --> File loaded: application/views/layout/main.php
DEBUG - 2011-09-19 03:40:48 --> Final output sent to browser
DEBUG - 2011-09-19 03:40:48 --> Total execution time: 0.0857
DEBUG - 2011-09-19 03:41:37 --> Config Class Initialized
DEBUG - 2011-09-19 03:41:37 --> Hooks Class Initialized
DEBUG - 2011-09-19 03:41:37 --> Utf8 Class Initialized
DEBUG - 2011-09-19 03:41:37 --> UTF-8 Support Enabled
DEBUG - 2011-09-19 03:41:37 --> URI Class Initialized
DEBUG - 2011-09-19 03:41:37 --> Router Class Initialized
DEBUG - 2011-09-19 03:41:37 --> Output Class Initialized
DEBUG - 2011-09-19 03:41:37 --> Input Class Initialized
DEBUG - 2011-09-19 03:41:37 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-19 03:41:37 --> Language Class Initialized
DEBUG - 2011-09-19 03:41:37 --> Loader Class Initialized
DEBUG - 2011-09-19 03:41:37 --> Controller Class Initialized
DEBUG - 2011-09-19 03:41:37 --> Model Class Initialized
DEBUG - 2011-09-19 03:41:37 --> Model Class Initialized
DEBUG - 2011-09-19 03:41:37 --> Model Class Initialized
DEBUG - 2011-09-19 03:41:37 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-19 03:41:37 --> Database Driver Class Initialized
DEBUG - 2011-09-19 03:41:37 --> File loaded: application/views/table/main.php
DEBUG - 2011-09-19 03:41:37 --> Helper loaded: url_helper
DEBUG - 2011-09-19 03:41:37 --> File loaded: application/views/common/header.php
DEBUG - 2011-09-19 03:41:37 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-09-19 03:41:37 --> File loaded: application/views/common/footer.php
DEBUG - 2011-09-19 03:41:37 --> File loaded: application/views/layout/main.php
DEBUG - 2011-09-19 03:41:37 --> Final output sent to browser
DEBUG - 2011-09-19 03:41:37 --> Total execution time: 0.0741
DEBUG - 2011-09-19 03:41:50 --> Config Class Initialized
DEBUG - 2011-09-19 03:41:50 --> Hooks Class Initialized
DEBUG - 2011-09-19 03:41:50 --> Utf8 Class Initialized
DEBUG - 2011-09-19 03:41:50 --> UTF-8 Support Enabled
DEBUG - 2011-09-19 03:41:50 --> URI Class Initialized
DEBUG - 2011-09-19 03:41:50 --> Router Class Initialized
DEBUG - 2011-09-19 03:41:50 --> Output Class Initialized
DEBUG - 2011-09-19 03:41:50 --> Input Class Initialized
DEBUG - 2011-09-19 03:41:50 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-19 03:41:50 --> Language Class Initialized
DEBUG - 2011-09-19 03:41:50 --> Loader Class Initialized
DEBUG - 2011-09-19 03:41:50 --> Controller Class Initialized
ERROR - 2011-09-19 03:41:50 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-09-19 03:41:50 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-09-19 03:41:50 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-09-19 03:41:50 --> Model Class Initialized
DEBUG - 2011-09-19 03:41:50 --> Model Class Initialized
DEBUG - 2011-09-19 03:41:50 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-19 03:41:50 --> Database Driver Class Initialized
DEBUG - 2011-09-19 03:41:50 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-09-19 03:41:50 --> Helper loaded: url_helper
DEBUG - 2011-09-19 03:41:50 --> File loaded: application/views/common/header.php
DEBUG - 2011-09-19 03:41:50 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-09-19 03:41:50 --> File loaded: application/views/common/footer.php
DEBUG - 2011-09-19 03:41:50 --> File loaded: application/views/layout/main.php
DEBUG - 2011-09-19 03:41:50 --> Final output sent to browser
DEBUG - 2011-09-19 03:41:50 --> Total execution time: 0.1141
DEBUG - 2011-09-19 04:08:29 --> Config Class Initialized
DEBUG - 2011-09-19 04:08:29 --> Hooks Class Initialized
DEBUG - 2011-09-19 04:08:29 --> Utf8 Class Initialized
DEBUG - 2011-09-19 04:08:29 --> UTF-8 Support Enabled
DEBUG - 2011-09-19 04:08:29 --> URI Class Initialized
DEBUG - 2011-09-19 04:08:29 --> Router Class Initialized
DEBUG - 2011-09-19 04:08:29 --> Output Class Initialized
DEBUG - 2011-09-19 04:08:29 --> Input Class Initialized
DEBUG - 2011-09-19 04:08:29 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-19 04:08:29 --> Language Class Initialized
DEBUG - 2011-09-19 04:08:29 --> Loader Class Initialized
DEBUG - 2011-09-19 04:08:29 --> Controller Class Initialized
ERROR - 2011-09-19 04:08:29 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-09-19 04:08:29 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-09-19 04:08:29 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-09-19 04:08:29 --> Model Class Initialized
DEBUG - 2011-09-19 04:08:29 --> Model Class Initialized
DEBUG - 2011-09-19 04:08:29 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-19 04:08:29 --> Database Driver Class Initialized
DEBUG - 2011-09-19 04:08:29 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-09-19 04:08:30 --> Helper loaded: url_helper
DEBUG - 2011-09-19 04:08:30 --> File loaded: application/views/common/header.php
DEBUG - 2011-09-19 04:08:30 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-09-19 04:08:30 --> File loaded: application/views/common/footer.php
DEBUG - 2011-09-19 04:08:30 --> File loaded: application/views/layout/main.php
DEBUG - 2011-09-19 04:08:30 --> Final output sent to browser
DEBUG - 2011-09-19 04:08:30 --> Total execution time: 0.9520
DEBUG - 2011-09-19 04:08:32 --> Config Class Initialized
DEBUG - 2011-09-19 04:08:32 --> Hooks Class Initialized
DEBUG - 2011-09-19 04:08:32 --> Utf8 Class Initialized
DEBUG - 2011-09-19 04:08:32 --> UTF-8 Support Enabled
DEBUG - 2011-09-19 04:08:32 --> URI Class Initialized
DEBUG - 2011-09-19 04:08:32 --> Router Class Initialized
DEBUG - 2011-09-19 04:08:32 --> Output Class Initialized
DEBUG - 2011-09-19 04:08:32 --> Input Class Initialized
DEBUG - 2011-09-19 04:08:32 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-19 04:08:32 --> Language Class Initialized
DEBUG - 2011-09-19 04:08:32 --> Loader Class Initialized
DEBUG - 2011-09-19 04:08:32 --> Controller Class Initialized
DEBUG - 2011-09-19 04:08:32 --> Model Class Initialized
DEBUG - 2011-09-19 04:08:32 --> Model Class Initialized
DEBUG - 2011-09-19 04:08:32 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-19 04:08:32 --> Database Driver Class Initialized
DEBUG - 2011-09-19 04:08:33 --> Final output sent to browser
DEBUG - 2011-09-19 04:08:33 --> Total execution time: 1.0142
DEBUG - 2011-09-19 04:08:35 --> Config Class Initialized
DEBUG - 2011-09-19 04:08:35 --> Hooks Class Initialized
DEBUG - 2011-09-19 04:08:35 --> Utf8 Class Initialized
DEBUG - 2011-09-19 04:08:35 --> UTF-8 Support Enabled
DEBUG - 2011-09-19 04:08:35 --> URI Class Initialized
DEBUG - 2011-09-19 04:08:35 --> Router Class Initialized
ERROR - 2011-09-19 04:08:35 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-09-19 04:14:38 --> Config Class Initialized
DEBUG - 2011-09-19 04:14:38 --> Hooks Class Initialized
DEBUG - 2011-09-19 04:14:38 --> Utf8 Class Initialized
DEBUG - 2011-09-19 04:14:38 --> UTF-8 Support Enabled
DEBUG - 2011-09-19 04:14:38 --> URI Class Initialized
DEBUG - 2011-09-19 04:14:38 --> Router Class Initialized
DEBUG - 2011-09-19 04:14:38 --> Output Class Initialized
DEBUG - 2011-09-19 04:14:38 --> Input Class Initialized
DEBUG - 2011-09-19 04:14:38 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-19 04:14:38 --> Language Class Initialized
DEBUG - 2011-09-19 04:14:38 --> Loader Class Initialized
DEBUG - 2011-09-19 04:14:38 --> Controller Class Initialized
DEBUG - 2011-09-19 04:14:38 --> Model Class Initialized
DEBUG - 2011-09-19 04:14:38 --> Model Class Initialized
DEBUG - 2011-09-19 04:14:38 --> Model Class Initialized
DEBUG - 2011-09-19 04:14:38 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-19 04:14:38 --> Database Driver Class Initialized
DEBUG - 2011-09-19 04:14:39 --> File loaded: application/views/table/main.php
DEBUG - 2011-09-19 04:14:39 --> Helper loaded: url_helper
DEBUG - 2011-09-19 04:14:39 --> File loaded: application/views/common/header.php
DEBUG - 2011-09-19 04:14:39 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-09-19 04:14:39 --> File loaded: application/views/common/footer.php
DEBUG - 2011-09-19 04:14:39 --> File loaded: application/views/layout/main.php
DEBUG - 2011-09-19 04:14:39 --> Final output sent to browser
DEBUG - 2011-09-19 04:14:39 --> Total execution time: 0.9201
DEBUG - 2011-09-19 04:14:43 --> Config Class Initialized
DEBUG - 2011-09-19 04:14:43 --> Hooks Class Initialized
DEBUG - 2011-09-19 04:14:43 --> Utf8 Class Initialized
DEBUG - 2011-09-19 04:14:43 --> UTF-8 Support Enabled
DEBUG - 2011-09-19 04:14:43 --> URI Class Initialized
DEBUG - 2011-09-19 04:14:43 --> Router Class Initialized
ERROR - 2011-09-19 04:14:43 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-09-19 04:14:43 --> Config Class Initialized
DEBUG - 2011-09-19 04:14:43 --> Hooks Class Initialized
DEBUG - 2011-09-19 04:14:43 --> Utf8 Class Initialized
DEBUG - 2011-09-19 04:14:43 --> UTF-8 Support Enabled
DEBUG - 2011-09-19 04:14:43 --> URI Class Initialized
DEBUG - 2011-09-19 04:14:43 --> Router Class Initialized
ERROR - 2011-09-19 04:14:43 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-09-19 04:14:44 --> Config Class Initialized
DEBUG - 2011-09-19 04:14:44 --> Hooks Class Initialized
DEBUG - 2011-09-19 04:14:44 --> Utf8 Class Initialized
DEBUG - 2011-09-19 04:14:44 --> UTF-8 Support Enabled
DEBUG - 2011-09-19 04:14:44 --> URI Class Initialized
DEBUG - 2011-09-19 04:14:44 --> Router Class Initialized
ERROR - 2011-09-19 04:14:44 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-09-19 04:32:37 --> Config Class Initialized
DEBUG - 2011-09-19 04:32:37 --> Hooks Class Initialized
DEBUG - 2011-09-19 04:32:37 --> Utf8 Class Initialized
DEBUG - 2011-09-19 04:32:37 --> UTF-8 Support Enabled
DEBUG - 2011-09-19 04:32:37 --> URI Class Initialized
DEBUG - 2011-09-19 04:32:37 --> Router Class Initialized
DEBUG - 2011-09-19 04:32:37 --> Output Class Initialized
DEBUG - 2011-09-19 04:32:37 --> Input Class Initialized
DEBUG - 2011-09-19 04:32:37 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-19 04:32:37 --> Language Class Initialized
DEBUG - 2011-09-19 04:32:37 --> Loader Class Initialized
DEBUG - 2011-09-19 04:32:37 --> Controller Class Initialized
ERROR - 2011-09-19 04:32:37 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-09-19 04:32:37 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-09-19 04:32:37 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-09-19 04:32:37 --> Model Class Initialized
DEBUG - 2011-09-19 04:32:37 --> Model Class Initialized
DEBUG - 2011-09-19 04:32:37 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-19 04:32:37 --> Database Driver Class Initialized
DEBUG - 2011-09-19 04:32:37 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-09-19 04:32:37 --> Helper loaded: url_helper
DEBUG - 2011-09-19 04:32:37 --> File loaded: application/views/common/header.php
DEBUG - 2011-09-19 04:32:37 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-09-19 04:32:37 --> File loaded: application/views/common/footer.php
DEBUG - 2011-09-19 04:32:37 --> File loaded: application/views/layout/main.php
DEBUG - 2011-09-19 04:32:37 --> Final output sent to browser
DEBUG - 2011-09-19 04:32:37 --> Total execution time: 0.2197
DEBUG - 2011-09-19 04:32:39 --> Config Class Initialized
DEBUG - 2011-09-19 04:32:39 --> Hooks Class Initialized
DEBUG - 2011-09-19 04:32:39 --> Utf8 Class Initialized
DEBUG - 2011-09-19 04:32:39 --> UTF-8 Support Enabled
DEBUG - 2011-09-19 04:32:39 --> URI Class Initialized
DEBUG - 2011-09-19 04:32:39 --> Router Class Initialized
DEBUG - 2011-09-19 04:32:39 --> Output Class Initialized
DEBUG - 2011-09-19 04:32:39 --> Input Class Initialized
DEBUG - 2011-09-19 04:32:39 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-19 04:32:39 --> Language Class Initialized
DEBUG - 2011-09-19 04:32:39 --> Loader Class Initialized
DEBUG - 2011-09-19 04:32:39 --> Controller Class Initialized
DEBUG - 2011-09-19 04:32:39 --> Model Class Initialized
DEBUG - 2011-09-19 04:32:39 --> Model Class Initialized
DEBUG - 2011-09-19 04:32:39 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-19 04:32:39 --> Database Driver Class Initialized
DEBUG - 2011-09-19 04:32:40 --> Final output sent to browser
DEBUG - 2011-09-19 04:32:40 --> Total execution time: 0.7845
DEBUG - 2011-09-19 04:46:05 --> Config Class Initialized
DEBUG - 2011-09-19 04:46:05 --> Hooks Class Initialized
DEBUG - 2011-09-19 04:46:05 --> Utf8 Class Initialized
DEBUG - 2011-09-19 04:46:05 --> UTF-8 Support Enabled
DEBUG - 2011-09-19 04:46:05 --> URI Class Initialized
DEBUG - 2011-09-19 04:46:05 --> Router Class Initialized
DEBUG - 2011-09-19 04:46:05 --> Output Class Initialized
DEBUG - 2011-09-19 04:46:05 --> Input Class Initialized
DEBUG - 2011-09-19 04:46:05 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-19 04:46:05 --> Language Class Initialized
DEBUG - 2011-09-19 04:46:05 --> Loader Class Initialized
DEBUG - 2011-09-19 04:46:05 --> Controller Class Initialized
DEBUG - 2011-09-19 04:46:05 --> Model Class Initialized
DEBUG - 2011-09-19 04:46:05 --> Model Class Initialized
DEBUG - 2011-09-19 04:46:05 --> Model Class Initialized
DEBUG - 2011-09-19 04:46:05 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-19 04:46:05 --> Database Driver Class Initialized
DEBUG - 2011-09-19 04:46:06 --> File loaded: application/views/table/main.php
DEBUG - 2011-09-19 04:46:06 --> Helper loaded: url_helper
DEBUG - 2011-09-19 04:46:06 --> File loaded: application/views/common/header.php
DEBUG - 2011-09-19 04:46:06 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-09-19 04:46:06 --> File loaded: application/views/common/footer.php
DEBUG - 2011-09-19 04:46:06 --> File loaded: application/views/layout/main.php
DEBUG - 2011-09-19 04:46:06 --> Final output sent to browser
DEBUG - 2011-09-19 04:46:06 --> Total execution time: 0.8323
DEBUG - 2011-09-19 04:46:07 --> Config Class Initialized
DEBUG - 2011-09-19 04:46:07 --> Hooks Class Initialized
DEBUG - 2011-09-19 04:46:07 --> Utf8 Class Initialized
DEBUG - 2011-09-19 04:46:07 --> UTF-8 Support Enabled
DEBUG - 2011-09-19 04:46:07 --> URI Class Initialized
DEBUG - 2011-09-19 04:46:07 --> Router Class Initialized
DEBUG - 2011-09-19 04:46:07 --> Output Class Initialized
DEBUG - 2011-09-19 04:46:07 --> Input Class Initialized
DEBUG - 2011-09-19 04:46:07 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-19 04:46:07 --> Language Class Initialized
DEBUG - 2011-09-19 04:46:07 --> Loader Class Initialized
DEBUG - 2011-09-19 04:46:07 --> Controller Class Initialized
ERROR - 2011-09-19 04:46:07 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-09-19 04:46:07 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-09-19 04:46:07 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-09-19 04:46:07 --> Model Class Initialized
DEBUG - 2011-09-19 04:46:07 --> Model Class Initialized
DEBUG - 2011-09-19 04:46:07 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-19 04:46:07 --> Database Driver Class Initialized
DEBUG - 2011-09-19 04:46:07 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-09-19 04:46:07 --> Helper loaded: url_helper
DEBUG - 2011-09-19 04:46:07 --> File loaded: application/views/common/header.php
DEBUG - 2011-09-19 04:46:07 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-09-19 04:46:07 --> File loaded: application/views/common/footer.php
DEBUG - 2011-09-19 04:46:07 --> File loaded: application/views/layout/main.php
DEBUG - 2011-09-19 04:46:07 --> Final output sent to browser
DEBUG - 2011-09-19 04:46:07 --> Total execution time: 0.0624
DEBUG - 2011-09-19 04:46:16 --> Config Class Initialized
DEBUG - 2011-09-19 04:46:16 --> Hooks Class Initialized
DEBUG - 2011-09-19 04:46:16 --> Utf8 Class Initialized
DEBUG - 2011-09-19 04:46:16 --> UTF-8 Support Enabled
DEBUG - 2011-09-19 04:46:16 --> URI Class Initialized
DEBUG - 2011-09-19 04:46:16 --> Router Class Initialized
DEBUG - 2011-09-19 04:46:16 --> Output Class Initialized
DEBUG - 2011-09-19 04:46:16 --> Input Class Initialized
DEBUG - 2011-09-19 04:46:16 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-19 04:46:16 --> Language Class Initialized
DEBUG - 2011-09-19 04:46:16 --> Loader Class Initialized
DEBUG - 2011-09-19 04:46:16 --> Controller Class Initialized
DEBUG - 2011-09-19 04:46:16 --> Model Class Initialized
DEBUG - 2011-09-19 04:46:16 --> Model Class Initialized
DEBUG - 2011-09-19 04:46:16 --> Model Class Initialized
DEBUG - 2011-09-19 04:46:16 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-19 04:46:16 --> Database Driver Class Initialized
DEBUG - 2011-09-19 04:46:16 --> File loaded: application/views/table/main.php
DEBUG - 2011-09-19 04:46:16 --> Helper loaded: url_helper
DEBUG - 2011-09-19 04:46:16 --> File loaded: application/views/common/header.php
DEBUG - 2011-09-19 04:46:16 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-09-19 04:46:16 --> File loaded: application/views/common/footer.php
DEBUG - 2011-09-19 04:46:16 --> File loaded: application/views/layout/main.php
DEBUG - 2011-09-19 04:46:16 --> Final output sent to browser
DEBUG - 2011-09-19 04:46:16 --> Total execution time: 0.2443
DEBUG - 2011-09-19 04:46:17 --> Config Class Initialized
DEBUG - 2011-09-19 04:46:17 --> Hooks Class Initialized
DEBUG - 2011-09-19 04:46:17 --> Utf8 Class Initialized
DEBUG - 2011-09-19 04:46:17 --> UTF-8 Support Enabled
DEBUG - 2011-09-19 04:46:17 --> URI Class Initialized
DEBUG - 2011-09-19 04:46:17 --> Router Class Initialized
DEBUG - 2011-09-19 04:46:17 --> Output Class Initialized
DEBUG - 2011-09-19 04:46:17 --> Input Class Initialized
DEBUG - 2011-09-19 04:46:17 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-19 04:46:17 --> Language Class Initialized
DEBUG - 2011-09-19 04:46:17 --> Loader Class Initialized
DEBUG - 2011-09-19 04:46:17 --> Controller Class Initialized
ERROR - 2011-09-19 04:46:17 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-09-19 04:46:17 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-09-19 04:46:17 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-09-19 04:46:17 --> Model Class Initialized
DEBUG - 2011-09-19 04:46:17 --> Model Class Initialized
DEBUG - 2011-09-19 04:46:17 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-19 04:46:17 --> Database Driver Class Initialized
DEBUG - 2011-09-19 04:46:17 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-09-19 04:46:17 --> Helper loaded: url_helper
DEBUG - 2011-09-19 04:46:17 --> File loaded: application/views/common/header.php
DEBUG - 2011-09-19 04:46:17 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-09-19 04:46:17 --> File loaded: application/views/common/footer.php
DEBUG - 2011-09-19 04:46:17 --> File loaded: application/views/layout/main.php
DEBUG - 2011-09-19 04:46:17 --> Final output sent to browser
DEBUG - 2011-09-19 04:46:17 --> Total execution time: 0.0920
DEBUG - 2011-09-19 04:52:13 --> Config Class Initialized
DEBUG - 2011-09-19 04:52:13 --> Hooks Class Initialized
DEBUG - 2011-09-19 04:52:13 --> Utf8 Class Initialized
DEBUG - 2011-09-19 04:52:13 --> UTF-8 Support Enabled
DEBUG - 2011-09-19 04:52:13 --> URI Class Initialized
DEBUG - 2011-09-19 04:52:13 --> Router Class Initialized
DEBUG - 2011-09-19 04:52:13 --> Output Class Initialized
DEBUG - 2011-09-19 04:52:13 --> Input Class Initialized
DEBUG - 2011-09-19 04:52:13 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-19 04:52:13 --> Language Class Initialized
DEBUG - 2011-09-19 04:52:13 --> Loader Class Initialized
DEBUG - 2011-09-19 04:52:13 --> Controller Class Initialized
DEBUG - 2011-09-19 04:52:13 --> Model Class Initialized
DEBUG - 2011-09-19 04:52:13 --> Model Class Initialized
DEBUG - 2011-09-19 04:52:13 --> Model Class Initialized
DEBUG - 2011-09-19 04:52:13 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-19 04:52:13 --> Database Driver Class Initialized
DEBUG - 2011-09-19 04:52:13 --> File loaded: application/views/table/main.php
DEBUG - 2011-09-19 04:52:13 --> Helper loaded: url_helper
DEBUG - 2011-09-19 04:52:13 --> File loaded: application/views/common/header.php
DEBUG - 2011-09-19 04:52:13 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-09-19 04:52:13 --> File loaded: application/views/common/footer.php
DEBUG - 2011-09-19 04:52:13 --> File loaded: application/views/layout/main.php
DEBUG - 2011-09-19 04:52:13 --> Final output sent to browser
DEBUG - 2011-09-19 04:52:13 --> Total execution time: 0.2873
DEBUG - 2011-09-19 04:54:49 --> Config Class Initialized
DEBUG - 2011-09-19 04:54:49 --> Hooks Class Initialized
DEBUG - 2011-09-19 04:54:49 --> Utf8 Class Initialized
DEBUG - 2011-09-19 04:54:49 --> UTF-8 Support Enabled
DEBUG - 2011-09-19 04:54:49 --> URI Class Initialized
DEBUG - 2011-09-19 04:54:49 --> Router Class Initialized
DEBUG - 2011-09-19 04:54:49 --> No URI present. Default controller set.
DEBUG - 2011-09-19 04:54:49 --> Output Class Initialized
DEBUG - 2011-09-19 04:54:49 --> Input Class Initialized
DEBUG - 2011-09-19 04:54:49 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-19 04:54:49 --> Language Class Initialized
DEBUG - 2011-09-19 04:54:50 --> Loader Class Initialized
DEBUG - 2011-09-19 04:54:50 --> Controller Class Initialized
DEBUG - 2011-09-19 04:54:50 --> File loaded: application/views/splash/main.php
DEBUG - 2011-09-19 04:54:50 --> Helper loaded: url_helper
DEBUG - 2011-09-19 04:54:50 --> File loaded: application/views/common/header.php
DEBUG - 2011-09-19 04:54:50 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-09-19 04:54:50 --> File loaded: application/views/common/footer.php
DEBUG - 2011-09-19 04:54:50 --> File loaded: application/views/layout/main.php
DEBUG - 2011-09-19 04:54:50 --> Final output sent to browser
DEBUG - 2011-09-19 04:54:50 --> Total execution time: 0.0947
DEBUG - 2011-09-19 05:40:35 --> Config Class Initialized
DEBUG - 2011-09-19 05:40:35 --> Config Class Initialized
DEBUG - 2011-09-19 05:40:35 --> Hooks Class Initialized
DEBUG - 2011-09-19 05:40:35 --> Hooks Class Initialized
DEBUG - 2011-09-19 05:40:35 --> Utf8 Class Initialized
DEBUG - 2011-09-19 05:40:35 --> Utf8 Class Initialized
DEBUG - 2011-09-19 05:40:35 --> UTF-8 Support Enabled
DEBUG - 2011-09-19 05:40:35 --> UTF-8 Support Enabled
DEBUG - 2011-09-19 05:40:35 --> URI Class Initialized
DEBUG - 2011-09-19 05:40:35 --> URI Class Initialized
DEBUG - 2011-09-19 05:40:35 --> Router Class Initialized
DEBUG - 2011-09-19 05:40:35 --> Router Class Initialized
DEBUG - 2011-09-19 05:40:35 --> Output Class Initialized
DEBUG - 2011-09-19 05:40:35 --> Output Class Initialized
DEBUG - 2011-09-19 05:40:36 --> Input Class Initialized
DEBUG - 2011-09-19 05:40:36 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-19 05:40:36 --> Input Class Initialized
DEBUG - 2011-09-19 05:40:36 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-19 05:40:36 --> Language Class Initialized
DEBUG - 2011-09-19 05:40:36 --> Language Class Initialized
DEBUG - 2011-09-19 05:40:36 --> Loader Class Initialized
DEBUG - 2011-09-19 05:40:36 --> Loader Class Initialized
DEBUG - 2011-09-19 05:40:36 --> Controller Class Initialized
DEBUG - 2011-09-19 05:40:36 --> Controller Class Initialized
DEBUG - 2011-09-19 05:40:36 --> Model Class Initialized
DEBUG - 2011-09-19 05:40:36 --> Model Class Initialized
ERROR - 2011-09-19 05:40:36 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-09-19 05:40:36 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-09-19 05:40:36 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-09-19 05:40:36 --> Model Class Initialized
DEBUG - 2011-09-19 05:40:36 --> Model Class Initialized
DEBUG - 2011-09-19 05:40:36 --> Model Class Initialized
DEBUG - 2011-09-19 05:40:37 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-19 05:40:37 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-19 05:40:37 --> Database Driver Class Initialized
DEBUG - 2011-09-19 05:40:37 --> Database Driver Class Initialized
DEBUG - 2011-09-19 05:40:38 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-09-19 05:40:38 --> Helper loaded: url_helper
DEBUG - 2011-09-19 05:40:38 --> File loaded: application/views/common/header.php
DEBUG - 2011-09-19 05:40:38 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-09-19 05:40:38 --> File loaded: application/views/common/footer.php
DEBUG - 2011-09-19 05:40:38 --> File loaded: application/views/layout/main.php
DEBUG - 2011-09-19 05:40:38 --> Final output sent to browser
DEBUG - 2011-09-19 05:40:38 --> Total execution time: 2.7881
DEBUG - 2011-09-19 05:40:38 --> File loaded: application/views/table/main.php
DEBUG - 2011-09-19 05:40:38 --> Helper loaded: url_helper
DEBUG - 2011-09-19 05:40:38 --> File loaded: application/views/common/header.php
DEBUG - 2011-09-19 05:40:38 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-09-19 05:40:38 --> File loaded: application/views/common/footer.php
DEBUG - 2011-09-19 05:40:38 --> File loaded: application/views/layout/main.php
DEBUG - 2011-09-19 05:40:38 --> Final output sent to browser
DEBUG - 2011-09-19 05:40:38 --> Total execution time: 3.4068
DEBUG - 2011-09-19 06:11:51 --> Config Class Initialized
DEBUG - 2011-09-19 06:11:51 --> Hooks Class Initialized
DEBUG - 2011-09-19 06:11:51 --> Utf8 Class Initialized
DEBUG - 2011-09-19 06:11:51 --> UTF-8 Support Enabled
DEBUG - 2011-09-19 06:11:51 --> URI Class Initialized
DEBUG - 2011-09-19 06:11:51 --> Router Class Initialized
ERROR - 2011-09-19 06:11:51 --> 404 Page Not Found --> robots.txt
DEBUG - 2011-09-19 06:12:35 --> Config Class Initialized
DEBUG - 2011-09-19 06:12:35 --> Hooks Class Initialized
DEBUG - 2011-09-19 06:12:35 --> Utf8 Class Initialized
DEBUG - 2011-09-19 06:12:35 --> UTF-8 Support Enabled
DEBUG - 2011-09-19 06:12:35 --> URI Class Initialized
DEBUG - 2011-09-19 06:12:35 --> Router Class Initialized
DEBUG - 2011-09-19 06:12:35 --> No URI present. Default controller set.
DEBUG - 2011-09-19 06:12:35 --> Output Class Initialized
DEBUG - 2011-09-19 06:12:35 --> Input Class Initialized
DEBUG - 2011-09-19 06:12:35 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-19 06:12:35 --> Language Class Initialized
DEBUG - 2011-09-19 06:12:35 --> Loader Class Initialized
DEBUG - 2011-09-19 06:12:35 --> Controller Class Initialized
DEBUG - 2011-09-19 06:12:35 --> File loaded: application/views/splash/main.php
DEBUG - 2011-09-19 06:12:35 --> Helper loaded: url_helper
DEBUG - 2011-09-19 06:12:35 --> File loaded: application/views/common/header.php
DEBUG - 2011-09-19 06:12:35 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-09-19 06:12:35 --> File loaded: application/views/common/footer.php
DEBUG - 2011-09-19 06:12:35 --> File loaded: application/views/layout/main.php
DEBUG - 2011-09-19 06:12:35 --> Final output sent to browser
DEBUG - 2011-09-19 06:12:35 --> Total execution time: 0.0832
DEBUG - 2011-09-19 06:50:26 --> Config Class Initialized
DEBUG - 2011-09-19 06:50:26 --> Hooks Class Initialized
DEBUG - 2011-09-19 06:50:26 --> Utf8 Class Initialized
DEBUG - 2011-09-19 06:50:26 --> UTF-8 Support Enabled
DEBUG - 2011-09-19 06:50:26 --> URI Class Initialized
DEBUG - 2011-09-19 06:50:26 --> Router Class Initialized
ERROR - 2011-09-19 06:50:26 --> 404 Page Not Found --> robots.txt
DEBUG - 2011-09-19 06:50:26 --> Config Class Initialized
DEBUG - 2011-09-19 06:50:26 --> Hooks Class Initialized
DEBUG - 2011-09-19 06:50:26 --> Utf8 Class Initialized
DEBUG - 2011-09-19 06:50:26 --> UTF-8 Support Enabled
DEBUG - 2011-09-19 06:50:26 --> URI Class Initialized
DEBUG - 2011-09-19 06:50:26 --> Router Class Initialized
DEBUG - 2011-09-19 06:50:27 --> Output Class Initialized
DEBUG - 2011-09-19 06:50:27 --> Input Class Initialized
DEBUG - 2011-09-19 06:50:27 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-19 06:50:27 --> Language Class Initialized
DEBUG - 2011-09-19 06:50:27 --> Loader Class Initialized
DEBUG - 2011-09-19 06:50:27 --> Controller Class Initialized
DEBUG - 2011-09-19 06:50:27 --> Model Class Initialized
DEBUG - 2011-09-19 06:50:28 --> Model Class Initialized
DEBUG - 2011-09-19 06:50:28 --> Model Class Initialized
DEBUG - 2011-09-19 06:50:28 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-19 06:50:30 --> Database Driver Class Initialized
DEBUG - 2011-09-19 06:50:35 --> File loaded: application/views/table/main.php
DEBUG - 2011-09-19 06:50:35 --> Helper loaded: url_helper
DEBUG - 2011-09-19 06:50:35 --> File loaded: application/views/common/header.php
DEBUG - 2011-09-19 06:50:35 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-09-19 06:50:35 --> File loaded: application/views/common/footer.php
DEBUG - 2011-09-19 06:50:35 --> File loaded: application/views/layout/main.php
DEBUG - 2011-09-19 06:50:35 --> Final output sent to browser
DEBUG - 2011-09-19 06:50:35 --> Total execution time: 8.7297
DEBUG - 2011-09-19 07:42:38 --> Config Class Initialized
DEBUG - 2011-09-19 07:42:38 --> Hooks Class Initialized
DEBUG - 2011-09-19 07:42:38 --> Utf8 Class Initialized
DEBUG - 2011-09-19 07:42:38 --> UTF-8 Support Enabled
DEBUG - 2011-09-19 07:42:38 --> URI Class Initialized
DEBUG - 2011-09-19 07:42:38 --> Router Class Initialized
DEBUG - 2011-09-19 07:42:38 --> Output Class Initialized
DEBUG - 2011-09-19 07:42:38 --> Input Class Initialized
DEBUG - 2011-09-19 07:42:38 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-19 07:42:38 --> Language Class Initialized
DEBUG - 2011-09-19 07:42:38 --> Loader Class Initialized
DEBUG - 2011-09-19 07:42:38 --> Controller Class Initialized
DEBUG - 2011-09-19 07:42:38 --> Model Class Initialized
DEBUG - 2011-09-19 07:42:38 --> Model Class Initialized
DEBUG - 2011-09-19 07:42:38 --> Model Class Initialized
DEBUG - 2011-09-19 07:42:38 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-19 07:42:38 --> Database Driver Class Initialized
DEBUG - 2011-09-19 07:42:39 --> File loaded: application/views/table/main.php
DEBUG - 2011-09-19 07:42:40 --> Helper loaded: url_helper
DEBUG - 2011-09-19 07:42:40 --> File loaded: application/views/common/header.php
DEBUG - 2011-09-19 07:42:40 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-09-19 07:42:40 --> File loaded: application/views/common/footer.php
DEBUG - 2011-09-19 07:42:40 --> File loaded: application/views/layout/main.php
DEBUG - 2011-09-19 07:42:40 --> Final output sent to browser
DEBUG - 2011-09-19 07:42:40 --> Total execution time: 1.3434
DEBUG - 2011-09-19 07:42:40 --> Config Class Initialized
DEBUG - 2011-09-19 07:42:40 --> Hooks Class Initialized
DEBUG - 2011-09-19 07:42:40 --> Utf8 Class Initialized
DEBUG - 2011-09-19 07:42:40 --> UTF-8 Support Enabled
DEBUG - 2011-09-19 07:42:40 --> URI Class Initialized
DEBUG - 2011-09-19 07:42:40 --> Router Class Initialized
DEBUG - 2011-09-19 07:42:40 --> Output Class Initialized
DEBUG - 2011-09-19 07:42:40 --> Input Class Initialized
DEBUG - 2011-09-19 07:42:40 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-19 07:42:40 --> Language Class Initialized
DEBUG - 2011-09-19 07:42:40 --> Loader Class Initialized
DEBUG - 2011-09-19 07:42:40 --> Controller Class Initialized
ERROR - 2011-09-19 07:42:40 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-09-19 07:42:40 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-09-19 07:42:40 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-09-19 07:42:40 --> Model Class Initialized
DEBUG - 2011-09-19 07:42:40 --> Model Class Initialized
DEBUG - 2011-09-19 07:42:40 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-19 07:42:40 --> Database Driver Class Initialized
DEBUG - 2011-09-19 07:42:40 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-09-19 07:42:40 --> Helper loaded: url_helper
DEBUG - 2011-09-19 07:42:40 --> File loaded: application/views/common/header.php
DEBUG - 2011-09-19 07:42:40 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-09-19 07:42:40 --> File loaded: application/views/common/footer.php
DEBUG - 2011-09-19 07:42:40 --> File loaded: application/views/layout/main.php
DEBUG - 2011-09-19 07:42:40 --> Final output sent to browser
DEBUG - 2011-09-19 07:42:40 --> Total execution time: 0.1362
DEBUG - 2011-09-19 07:42:56 --> Config Class Initialized
DEBUG - 2011-09-19 07:42:56 --> Hooks Class Initialized
DEBUG - 2011-09-19 07:42:56 --> Utf8 Class Initialized
DEBUG - 2011-09-19 07:42:56 --> UTF-8 Support Enabled
DEBUG - 2011-09-19 07:42:56 --> URI Class Initialized
DEBUG - 2011-09-19 07:42:56 --> Router Class Initialized
ERROR - 2011-09-19 07:42:56 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-09-19 07:43:08 --> Config Class Initialized
DEBUG - 2011-09-19 07:43:08 --> Hooks Class Initialized
DEBUG - 2011-09-19 07:43:08 --> Utf8 Class Initialized
DEBUG - 2011-09-19 07:43:08 --> UTF-8 Support Enabled
DEBUG - 2011-09-19 07:43:08 --> URI Class Initialized
DEBUG - 2011-09-19 07:43:08 --> Router Class Initialized
DEBUG - 2011-09-19 07:43:08 --> Output Class Initialized
DEBUG - 2011-09-19 07:43:08 --> Input Class Initialized
DEBUG - 2011-09-19 07:43:08 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-19 07:43:08 --> Language Class Initialized
DEBUG - 2011-09-19 07:43:08 --> Loader Class Initialized
DEBUG - 2011-09-19 07:43:08 --> Controller Class Initialized
DEBUG - 2011-09-19 07:43:08 --> Model Class Initialized
DEBUG - 2011-09-19 07:43:08 --> Model Class Initialized
DEBUG - 2011-09-19 07:43:08 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-19 07:43:08 --> Database Driver Class Initialized
DEBUG - 2011-09-19 07:43:09 --> Config Class Initialized
DEBUG - 2011-09-19 07:43:09 --> Hooks Class Initialized
DEBUG - 2011-09-19 07:43:09 --> Utf8 Class Initialized
DEBUG - 2011-09-19 07:43:09 --> UTF-8 Support Enabled
DEBUG - 2011-09-19 07:43:09 --> URI Class Initialized
DEBUG - 2011-09-19 07:43:09 --> Router Class Initialized
ERROR - 2011-09-19 07:43:09 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-09-19 07:43:13 --> Config Class Initialized
DEBUG - 2011-09-19 07:43:13 --> Hooks Class Initialized
DEBUG - 2011-09-19 07:43:13 --> Utf8 Class Initialized
DEBUG - 2011-09-19 07:43:13 --> UTF-8 Support Enabled
DEBUG - 2011-09-19 07:43:13 --> URI Class Initialized
DEBUG - 2011-09-19 07:43:13 --> Router Class Initialized
ERROR - 2011-09-19 07:43:13 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-09-19 07:43:14 --> Config Class Initialized
DEBUG - 2011-09-19 07:43:14 --> Hooks Class Initialized
DEBUG - 2011-09-19 07:43:14 --> Utf8 Class Initialized
DEBUG - 2011-09-19 07:43:14 --> UTF-8 Support Enabled
DEBUG - 2011-09-19 07:43:14 --> URI Class Initialized
DEBUG - 2011-09-19 07:43:14 --> Router Class Initialized
ERROR - 2011-09-19 07:43:14 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-09-19 07:43:15 --> Final output sent to browser
DEBUG - 2011-09-19 07:43:15 --> Total execution time: 6.8873
DEBUG - 2011-09-19 07:43:25 --> Config Class Initialized
DEBUG - 2011-09-19 07:43:25 --> Hooks Class Initialized
DEBUG - 2011-09-19 07:43:25 --> Utf8 Class Initialized
DEBUG - 2011-09-19 07:43:25 --> UTF-8 Support Enabled
DEBUG - 2011-09-19 07:43:25 --> URI Class Initialized
DEBUG - 2011-09-19 07:43:25 --> Router Class Initialized
DEBUG - 2011-09-19 07:43:25 --> Output Class Initialized
DEBUG - 2011-09-19 07:43:25 --> Input Class Initialized
DEBUG - 2011-09-19 07:43:25 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-19 07:43:25 --> Language Class Initialized
DEBUG - 2011-09-19 07:43:25 --> Loader Class Initialized
DEBUG - 2011-09-19 07:43:25 --> Controller Class Initialized
ERROR - 2011-09-19 07:43:25 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-09-19 07:43:25 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-09-19 07:43:25 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-09-19 07:43:25 --> Model Class Initialized
DEBUG - 2011-09-19 07:43:25 --> Model Class Initialized
DEBUG - 2011-09-19 07:43:25 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-19 07:43:25 --> Database Driver Class Initialized
DEBUG - 2011-09-19 07:43:25 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-09-19 07:43:25 --> Helper loaded: url_helper
DEBUG - 2011-09-19 07:43:25 --> File loaded: application/views/common/header.php
DEBUG - 2011-09-19 07:43:25 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-09-19 07:43:25 --> File loaded: application/views/common/footer.php
DEBUG - 2011-09-19 07:43:25 --> File loaded: application/views/layout/main.php
DEBUG - 2011-09-19 07:43:25 --> Final output sent to browser
DEBUG - 2011-09-19 07:43:25 --> Total execution time: 0.0452
DEBUG - 2011-09-19 07:43:54 --> Config Class Initialized
DEBUG - 2011-09-19 07:43:54 --> Hooks Class Initialized
DEBUG - 2011-09-19 07:43:54 --> Utf8 Class Initialized
DEBUG - 2011-09-19 07:43:54 --> UTF-8 Support Enabled
DEBUG - 2011-09-19 07:43:54 --> URI Class Initialized
DEBUG - 2011-09-19 07:43:54 --> Router Class Initialized
DEBUG - 2011-09-19 07:43:54 --> Output Class Initialized
DEBUG - 2011-09-19 07:43:54 --> Input Class Initialized
DEBUG - 2011-09-19 07:43:54 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-19 07:43:54 --> Language Class Initialized
DEBUG - 2011-09-19 07:43:54 --> Loader Class Initialized
DEBUG - 2011-09-19 07:43:54 --> Controller Class Initialized
DEBUG - 2011-09-19 07:43:54 --> Model Class Initialized
DEBUG - 2011-09-19 07:43:54 --> Model Class Initialized
DEBUG - 2011-09-19 07:43:54 --> Model Class Initialized
DEBUG - 2011-09-19 07:43:54 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-19 07:43:54 --> Database Driver Class Initialized
DEBUG - 2011-09-19 07:43:54 --> File loaded: application/views/table/main.php
DEBUG - 2011-09-19 07:43:54 --> Helper loaded: url_helper
DEBUG - 2011-09-19 07:43:54 --> File loaded: application/views/common/header.php
DEBUG - 2011-09-19 07:43:54 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-09-19 07:43:54 --> File loaded: application/views/common/footer.php
DEBUG - 2011-09-19 07:43:54 --> File loaded: application/views/layout/main.php
DEBUG - 2011-09-19 07:43:54 --> Final output sent to browser
DEBUG - 2011-09-19 07:43:54 --> Total execution time: 0.3357
DEBUG - 2011-09-19 07:44:06 --> Config Class Initialized
DEBUG - 2011-09-19 07:44:06 --> Hooks Class Initialized
DEBUG - 2011-09-19 07:44:06 --> Utf8 Class Initialized
DEBUG - 2011-09-19 07:44:06 --> UTF-8 Support Enabled
DEBUG - 2011-09-19 07:44:06 --> URI Class Initialized
DEBUG - 2011-09-19 07:44:06 --> Router Class Initialized
ERROR - 2011-09-19 07:44:06 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-09-19 09:06:43 --> Config Class Initialized
DEBUG - 2011-09-19 09:06:43 --> Hooks Class Initialized
DEBUG - 2011-09-19 09:06:43 --> Utf8 Class Initialized
DEBUG - 2011-09-19 09:06:43 --> UTF-8 Support Enabled
DEBUG - 2011-09-19 09:06:43 --> URI Class Initialized
DEBUG - 2011-09-19 09:06:43 --> Router Class Initialized
DEBUG - 2011-09-19 09:06:43 --> No URI present. Default controller set.
DEBUG - 2011-09-19 09:06:43 --> Output Class Initialized
DEBUG - 2011-09-19 09:06:43 --> Input Class Initialized
DEBUG - 2011-09-19 09:06:43 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-19 09:06:43 --> Language Class Initialized
DEBUG - 2011-09-19 09:06:43 --> Loader Class Initialized
DEBUG - 2011-09-19 09:06:43 --> Controller Class Initialized
DEBUG - 2011-09-19 09:06:43 --> File loaded: application/views/splash/main.php
DEBUG - 2011-09-19 09:06:43 --> Helper loaded: url_helper
DEBUG - 2011-09-19 09:06:43 --> File loaded: application/views/common/header.php
DEBUG - 2011-09-19 09:06:43 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-09-19 09:06:43 --> File loaded: application/views/common/footer.php
DEBUG - 2011-09-19 09:06:43 --> File loaded: application/views/layout/main.php
DEBUG - 2011-09-19 09:06:43 --> Final output sent to browser
DEBUG - 2011-09-19 09:06:43 --> Total execution time: 0.2496
DEBUG - 2011-09-19 09:21:46 --> Config Class Initialized
DEBUG - 2011-09-19 09:21:46 --> Hooks Class Initialized
DEBUG - 2011-09-19 09:21:46 --> Utf8 Class Initialized
DEBUG - 2011-09-19 09:21:46 --> UTF-8 Support Enabled
DEBUG - 2011-09-19 09:21:46 --> URI Class Initialized
DEBUG - 2011-09-19 09:21:46 --> Router Class Initialized
DEBUG - 2011-09-19 09:21:46 --> Output Class Initialized
DEBUG - 2011-09-19 09:21:46 --> Input Class Initialized
DEBUG - 2011-09-19 09:21:46 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-19 09:21:46 --> Language Class Initialized
DEBUG - 2011-09-19 09:21:47 --> Loader Class Initialized
DEBUG - 2011-09-19 09:21:47 --> Controller Class Initialized
DEBUG - 2011-09-19 09:21:47 --> Model Class Initialized
DEBUG - 2011-09-19 09:21:47 --> Model Class Initialized
DEBUG - 2011-09-19 09:21:47 --> Model Class Initialized
DEBUG - 2011-09-19 09:21:47 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-19 09:21:47 --> Database Driver Class Initialized
DEBUG - 2011-09-19 09:21:50 --> File loaded: application/views/table/main.php
DEBUG - 2011-09-19 09:21:50 --> Helper loaded: url_helper
DEBUG - 2011-09-19 09:21:50 --> File loaded: application/views/common/header.php
DEBUG - 2011-09-19 09:21:50 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-09-19 09:21:50 --> File loaded: application/views/common/footer.php
DEBUG - 2011-09-19 09:21:50 --> File loaded: application/views/layout/main.php
DEBUG - 2011-09-19 09:21:50 --> Final output sent to browser
DEBUG - 2011-09-19 09:21:50 --> Total execution time: 3.5106
DEBUG - 2011-09-19 09:21:52 --> Config Class Initialized
DEBUG - 2011-09-19 09:21:52 --> Hooks Class Initialized
DEBUG - 2011-09-19 09:21:52 --> Utf8 Class Initialized
DEBUG - 2011-09-19 09:21:52 --> UTF-8 Support Enabled
DEBUG - 2011-09-19 09:21:52 --> URI Class Initialized
DEBUG - 2011-09-19 09:21:52 --> Router Class Initialized
ERROR - 2011-09-19 09:21:52 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-09-19 09:22:37 --> Config Class Initialized
DEBUG - 2011-09-19 09:22:37 --> Hooks Class Initialized
DEBUG - 2011-09-19 09:22:37 --> Utf8 Class Initialized
DEBUG - 2011-09-19 09:22:37 --> UTF-8 Support Enabled
DEBUG - 2011-09-19 09:22:37 --> URI Class Initialized
DEBUG - 2011-09-19 09:22:37 --> Router Class Initialized
DEBUG - 2011-09-19 09:22:37 --> Output Class Initialized
DEBUG - 2011-09-19 09:22:37 --> Input Class Initialized
DEBUG - 2011-09-19 09:22:37 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-19 09:22:37 --> Language Class Initialized
DEBUG - 2011-09-19 09:22:37 --> Loader Class Initialized
DEBUG - 2011-09-19 09:22:37 --> Controller Class Initialized
DEBUG - 2011-09-19 09:22:37 --> Model Class Initialized
DEBUG - 2011-09-19 09:22:37 --> Model Class Initialized
DEBUG - 2011-09-19 09:22:37 --> Model Class Initialized
DEBUG - 2011-09-19 09:22:37 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-19 09:22:37 --> Database Driver Class Initialized
DEBUG - 2011-09-19 09:22:38 --> File loaded: application/views/table/main.php
DEBUG - 2011-09-19 09:22:38 --> Helper loaded: url_helper
DEBUG - 2011-09-19 09:22:38 --> File loaded: application/views/common/header.php
DEBUG - 2011-09-19 09:22:38 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-09-19 09:22:38 --> File loaded: application/views/common/footer.php
DEBUG - 2011-09-19 09:22:38 --> File loaded: application/views/layout/main.php
DEBUG - 2011-09-19 09:22:38 --> Final output sent to browser
DEBUG - 2011-09-19 09:22:38 --> Total execution time: 0.7290
DEBUG - 2011-09-19 09:22:40 --> Config Class Initialized
DEBUG - 2011-09-19 09:22:40 --> Hooks Class Initialized
DEBUG - 2011-09-19 09:22:40 --> Utf8 Class Initialized
DEBUG - 2011-09-19 09:22:40 --> UTF-8 Support Enabled
DEBUG - 2011-09-19 09:22:40 --> URI Class Initialized
DEBUG - 2011-09-19 09:22:40 --> Router Class Initialized
ERROR - 2011-09-19 09:22:40 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-09-19 09:22:59 --> Config Class Initialized
DEBUG - 2011-09-19 09:22:59 --> Hooks Class Initialized
DEBUG - 2011-09-19 09:22:59 --> Utf8 Class Initialized
DEBUG - 2011-09-19 09:22:59 --> UTF-8 Support Enabled
DEBUG - 2011-09-19 09:22:59 --> URI Class Initialized
DEBUG - 2011-09-19 09:22:59 --> Router Class Initialized
DEBUG - 2011-09-19 09:22:59 --> Output Class Initialized
DEBUG - 2011-09-19 09:22:59 --> Input Class Initialized
DEBUG - 2011-09-19 09:22:59 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-19 09:22:59 --> Language Class Initialized
DEBUG - 2011-09-19 09:22:59 --> Loader Class Initialized
DEBUG - 2011-09-19 09:22:59 --> Controller Class Initialized
DEBUG - 2011-09-19 09:22:59 --> Model Class Initialized
DEBUG - 2011-09-19 09:22:59 --> Model Class Initialized
DEBUG - 2011-09-19 09:22:59 --> Model Class Initialized
DEBUG - 2011-09-19 09:22:59 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-19 09:22:59 --> Database Driver Class Initialized
DEBUG - 2011-09-19 09:23:00 --> File loaded: application/views/table/main.php
DEBUG - 2011-09-19 09:23:00 --> Helper loaded: url_helper
DEBUG - 2011-09-19 09:23:00 --> File loaded: application/views/common/header.php
DEBUG - 2011-09-19 09:23:00 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-09-19 09:23:00 --> File loaded: application/views/common/footer.php
DEBUG - 2011-09-19 09:23:00 --> File loaded: application/views/layout/main.php
DEBUG - 2011-09-19 09:23:00 --> Final output sent to browser
DEBUG - 2011-09-19 09:23:00 --> Total execution time: 0.5830
DEBUG - 2011-09-19 09:23:01 --> Config Class Initialized
DEBUG - 2011-09-19 09:23:01 --> Hooks Class Initialized
DEBUG - 2011-09-19 09:23:01 --> Utf8 Class Initialized
DEBUG - 2011-09-19 09:23:01 --> UTF-8 Support Enabled
DEBUG - 2011-09-19 09:23:01 --> URI Class Initialized
DEBUG - 2011-09-19 09:23:01 --> Router Class Initialized
DEBUG - 2011-09-19 09:23:01 --> Output Class Initialized
DEBUG - 2011-09-19 09:23:01 --> Input Class Initialized
DEBUG - 2011-09-19 09:23:01 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-19 09:23:01 --> Language Class Initialized
DEBUG - 2011-09-19 09:23:01 --> Loader Class Initialized
DEBUG - 2011-09-19 09:23:01 --> Controller Class Initialized
DEBUG - 2011-09-19 09:23:01 --> Model Class Initialized
DEBUG - 2011-09-19 09:23:01 --> Model Class Initialized
DEBUG - 2011-09-19 09:23:01 --> Model Class Initialized
DEBUG - 2011-09-19 09:23:01 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-19 09:23:01 --> Config Class Initialized
DEBUG - 2011-09-19 09:23:01 --> Hooks Class Initialized
DEBUG - 2011-09-19 09:23:01 --> Utf8 Class Initialized
DEBUG - 2011-09-19 09:23:01 --> UTF-8 Support Enabled
DEBUG - 2011-09-19 09:23:01 --> URI Class Initialized
DEBUG - 2011-09-19 09:23:01 --> Router Class Initialized
ERROR - 2011-09-19 09:23:01 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-09-19 09:23:01 --> Database Driver Class Initialized
DEBUG - 2011-09-19 09:23:01 --> File loaded: application/views/table/main.php
DEBUG - 2011-09-19 09:23:01 --> Helper loaded: url_helper
DEBUG - 2011-09-19 09:23:01 --> File loaded: application/views/common/header.php
DEBUG - 2011-09-19 09:23:01 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-09-19 09:23:01 --> File loaded: application/views/common/footer.php
DEBUG - 2011-09-19 09:23:01 --> File loaded: application/views/layout/main.php
DEBUG - 2011-09-19 09:23:01 --> Final output sent to browser
DEBUG - 2011-09-19 09:23:01 --> Total execution time: 0.0977
DEBUG - 2011-09-19 09:23:27 --> Config Class Initialized
DEBUG - 2011-09-19 09:23:27 --> Hooks Class Initialized
DEBUG - 2011-09-19 09:23:27 --> Utf8 Class Initialized
DEBUG - 2011-09-19 09:23:27 --> UTF-8 Support Enabled
DEBUG - 2011-09-19 09:23:27 --> URI Class Initialized
DEBUG - 2011-09-19 09:23:27 --> Router Class Initialized
DEBUG - 2011-09-19 09:23:27 --> Output Class Initialized
DEBUG - 2011-09-19 09:23:27 --> Input Class Initialized
DEBUG - 2011-09-19 09:23:27 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-19 09:23:27 --> Language Class Initialized
DEBUG - 2011-09-19 09:23:27 --> Loader Class Initialized
DEBUG - 2011-09-19 09:23:27 --> Controller Class Initialized
DEBUG - 2011-09-19 09:23:27 --> Model Class Initialized
DEBUG - 2011-09-19 09:23:27 --> Model Class Initialized
DEBUG - 2011-09-19 09:23:27 --> Model Class Initialized
DEBUG - 2011-09-19 09:23:27 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-19 09:23:27 --> Database Driver Class Initialized
DEBUG - 2011-09-19 09:23:28 --> File loaded: application/views/table/main.php
DEBUG - 2011-09-19 09:23:28 --> Helper loaded: url_helper
DEBUG - 2011-09-19 09:23:28 --> File loaded: application/views/common/header.php
DEBUG - 2011-09-19 09:23:28 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-09-19 09:23:28 --> File loaded: application/views/common/footer.php
DEBUG - 2011-09-19 09:23:28 --> File loaded: application/views/layout/main.php
DEBUG - 2011-09-19 09:23:28 --> Final output sent to browser
DEBUG - 2011-09-19 09:23:28 --> Total execution time: 0.0515
DEBUG - 2011-09-19 09:23:29 --> Config Class Initialized
DEBUG - 2011-09-19 09:23:29 --> Hooks Class Initialized
DEBUG - 2011-09-19 09:23:29 --> Utf8 Class Initialized
DEBUG - 2011-09-19 09:23:29 --> UTF-8 Support Enabled
DEBUG - 2011-09-19 09:23:29 --> URI Class Initialized
DEBUG - 2011-09-19 09:23:29 --> Router Class Initialized
ERROR - 2011-09-19 09:23:29 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-09-19 09:23:40 --> Config Class Initialized
DEBUG - 2011-09-19 09:23:40 --> Hooks Class Initialized
DEBUG - 2011-09-19 09:23:40 --> Utf8 Class Initialized
DEBUG - 2011-09-19 09:23:40 --> UTF-8 Support Enabled
DEBUG - 2011-09-19 09:23:40 --> URI Class Initialized
DEBUG - 2011-09-19 09:23:40 --> Router Class Initialized
DEBUG - 2011-09-19 09:23:40 --> Output Class Initialized
DEBUG - 2011-09-19 09:23:40 --> Input Class Initialized
DEBUG - 2011-09-19 09:23:40 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-19 09:23:40 --> Language Class Initialized
DEBUG - 2011-09-19 09:23:40 --> Loader Class Initialized
DEBUG - 2011-09-19 09:23:40 --> Controller Class Initialized
DEBUG - 2011-09-19 09:23:40 --> Model Class Initialized
DEBUG - 2011-09-19 09:23:40 --> Model Class Initialized
DEBUG - 2011-09-19 09:23:40 --> Model Class Initialized
DEBUG - 2011-09-19 09:23:40 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-19 09:23:40 --> Database Driver Class Initialized
DEBUG - 2011-09-19 09:23:40 --> File loaded: application/views/table/main.php
DEBUG - 2011-09-19 09:23:40 --> Helper loaded: url_helper
DEBUG - 2011-09-19 09:23:40 --> File loaded: application/views/common/header.php
DEBUG - 2011-09-19 09:23:40 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-09-19 09:23:40 --> File loaded: application/views/common/footer.php
DEBUG - 2011-09-19 09:23:40 --> File loaded: application/views/layout/main.php
DEBUG - 2011-09-19 09:23:40 --> Final output sent to browser
DEBUG - 2011-09-19 09:23:40 --> Total execution time: 0.1010
DEBUG - 2011-09-19 09:23:42 --> Config Class Initialized
DEBUG - 2011-09-19 09:23:42 --> Hooks Class Initialized
DEBUG - 2011-09-19 09:23:42 --> Utf8 Class Initialized
DEBUG - 2011-09-19 09:23:42 --> UTF-8 Support Enabled
DEBUG - 2011-09-19 09:23:42 --> URI Class Initialized
DEBUG - 2011-09-19 09:23:42 --> Router Class Initialized
ERROR - 2011-09-19 09:23:42 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-09-19 09:23:51 --> Config Class Initialized
DEBUG - 2011-09-19 09:23:51 --> Hooks Class Initialized
DEBUG - 2011-09-19 09:23:51 --> Utf8 Class Initialized
DEBUG - 2011-09-19 09:23:51 --> UTF-8 Support Enabled
DEBUG - 2011-09-19 09:23:51 --> URI Class Initialized
DEBUG - 2011-09-19 09:23:51 --> Router Class Initialized
DEBUG - 2011-09-19 09:23:51 --> Output Class Initialized
DEBUG - 2011-09-19 09:23:51 --> Input Class Initialized
DEBUG - 2011-09-19 09:23:51 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-19 09:23:51 --> Language Class Initialized
DEBUG - 2011-09-19 09:23:51 --> Loader Class Initialized
DEBUG - 2011-09-19 09:23:51 --> Controller Class Initialized
DEBUG - 2011-09-19 09:23:51 --> Model Class Initialized
DEBUG - 2011-09-19 09:23:51 --> Model Class Initialized
DEBUG - 2011-09-19 09:23:51 --> Model Class Initialized
DEBUG - 2011-09-19 09:23:51 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-19 09:23:51 --> Database Driver Class Initialized
DEBUG - 2011-09-19 09:23:51 --> File loaded: application/views/table/main.php
DEBUG - 2011-09-19 09:23:51 --> Helper loaded: url_helper
DEBUG - 2011-09-19 09:23:51 --> File loaded: application/views/common/header.php
DEBUG - 2011-09-19 09:23:51 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-09-19 09:23:51 --> File loaded: application/views/common/footer.php
DEBUG - 2011-09-19 09:23:51 --> File loaded: application/views/layout/main.php
DEBUG - 2011-09-19 09:23:51 --> Final output sent to browser
DEBUG - 2011-09-19 09:23:51 --> Total execution time: 0.0950
DEBUG - 2011-09-19 09:23:58 --> Config Class Initialized
DEBUG - 2011-09-19 09:23:58 --> Hooks Class Initialized
DEBUG - 2011-09-19 09:23:58 --> Utf8 Class Initialized
DEBUG - 2011-09-19 09:23:58 --> UTF-8 Support Enabled
DEBUG - 2011-09-19 09:23:58 --> URI Class Initialized
DEBUG - 2011-09-19 09:23:58 --> Router Class Initialized
DEBUG - 2011-09-19 09:23:58 --> Output Class Initialized
DEBUG - 2011-09-19 09:23:58 --> Input Class Initialized
DEBUG - 2011-09-19 09:23:58 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-19 09:23:58 --> Language Class Initialized
DEBUG - 2011-09-19 09:23:58 --> Loader Class Initialized
DEBUG - 2011-09-19 09:23:58 --> Controller Class Initialized
DEBUG - 2011-09-19 09:23:58 --> Model Class Initialized
DEBUG - 2011-09-19 09:23:58 --> Model Class Initialized
DEBUG - 2011-09-19 09:23:58 --> Model Class Initialized
DEBUG - 2011-09-19 09:23:58 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-19 09:23:58 --> Database Driver Class Initialized
DEBUG - 2011-09-19 09:23:58 --> File loaded: application/views/table/main.php
DEBUG - 2011-09-19 09:23:58 --> Helper loaded: url_helper
DEBUG - 2011-09-19 09:23:58 --> File loaded: application/views/common/header.php
DEBUG - 2011-09-19 09:23:58 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-09-19 09:23:58 --> File loaded: application/views/common/footer.php
DEBUG - 2011-09-19 09:23:58 --> File loaded: application/views/layout/main.php
DEBUG - 2011-09-19 09:23:58 --> Final output sent to browser
DEBUG - 2011-09-19 09:23:58 --> Total execution time: 0.2226
DEBUG - 2011-09-19 09:24:00 --> Config Class Initialized
DEBUG - 2011-09-19 09:24:00 --> Hooks Class Initialized
DEBUG - 2011-09-19 09:24:00 --> Utf8 Class Initialized
DEBUG - 2011-09-19 09:24:00 --> UTF-8 Support Enabled
DEBUG - 2011-09-19 09:24:00 --> URI Class Initialized
DEBUG - 2011-09-19 09:24:00 --> Router Class Initialized
ERROR - 2011-09-19 09:24:00 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-09-19 09:24:46 --> Config Class Initialized
DEBUG - 2011-09-19 09:24:46 --> Hooks Class Initialized
DEBUG - 2011-09-19 09:24:46 --> Utf8 Class Initialized
DEBUG - 2011-09-19 09:24:46 --> UTF-8 Support Enabled
DEBUG - 2011-09-19 09:24:46 --> URI Class Initialized
DEBUG - 2011-09-19 09:24:46 --> Router Class Initialized
DEBUG - 2011-09-19 09:24:46 --> Output Class Initialized
DEBUG - 2011-09-19 09:24:46 --> Input Class Initialized
DEBUG - 2011-09-19 09:24:46 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-19 09:24:46 --> Language Class Initialized
DEBUG - 2011-09-19 09:24:46 --> Loader Class Initialized
DEBUG - 2011-09-19 09:24:46 --> Controller Class Initialized
DEBUG - 2011-09-19 09:24:46 --> Model Class Initialized
DEBUG - 2011-09-19 09:24:46 --> Model Class Initialized
DEBUG - 2011-09-19 09:24:46 --> Model Class Initialized
DEBUG - 2011-09-19 09:24:46 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-19 09:24:46 --> Database Driver Class Initialized
DEBUG - 2011-09-19 09:24:46 --> File loaded: application/views/table/main.php
DEBUG - 2011-09-19 09:24:46 --> Helper loaded: url_helper
DEBUG - 2011-09-19 09:24:46 --> File loaded: application/views/common/header.php
DEBUG - 2011-09-19 09:24:46 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-09-19 09:24:46 --> File loaded: application/views/common/footer.php
DEBUG - 2011-09-19 09:24:46 --> File loaded: application/views/layout/main.php
DEBUG - 2011-09-19 09:24:46 --> Final output sent to browser
DEBUG - 2011-09-19 09:24:46 --> Total execution time: 0.4171
DEBUG - 2011-09-19 09:24:47 --> Config Class Initialized
DEBUG - 2011-09-19 09:24:47 --> Hooks Class Initialized
DEBUG - 2011-09-19 09:24:47 --> Utf8 Class Initialized
DEBUG - 2011-09-19 09:24:47 --> UTF-8 Support Enabled
DEBUG - 2011-09-19 09:24:47 --> URI Class Initialized
DEBUG - 2011-09-19 09:24:47 --> Router Class Initialized
ERROR - 2011-09-19 09:24:47 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-09-19 09:25:52 --> Config Class Initialized
DEBUG - 2011-09-19 09:25:52 --> Hooks Class Initialized
DEBUG - 2011-09-19 09:25:52 --> Utf8 Class Initialized
DEBUG - 2011-09-19 09:25:52 --> UTF-8 Support Enabled
DEBUG - 2011-09-19 09:25:52 --> URI Class Initialized
DEBUG - 2011-09-19 09:25:52 --> Router Class Initialized
DEBUG - 2011-09-19 09:25:52 --> Output Class Initialized
DEBUG - 2011-09-19 09:25:52 --> Input Class Initialized
DEBUG - 2011-09-19 09:25:52 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-19 09:25:52 --> Language Class Initialized
DEBUG - 2011-09-19 09:25:52 --> Loader Class Initialized
DEBUG - 2011-09-19 09:25:52 --> Controller Class Initialized
DEBUG - 2011-09-19 09:25:52 --> Model Class Initialized
DEBUG - 2011-09-19 09:25:52 --> Model Class Initialized
DEBUG - 2011-09-19 09:25:52 --> Model Class Initialized
DEBUG - 2011-09-19 09:25:52 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-19 09:25:52 --> Database Driver Class Initialized
DEBUG - 2011-09-19 09:25:52 --> File loaded: application/views/table/main.php
DEBUG - 2011-09-19 09:25:52 --> Helper loaded: url_helper
DEBUG - 2011-09-19 09:25:52 --> File loaded: application/views/common/header.php
DEBUG - 2011-09-19 09:25:52 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-09-19 09:25:52 --> File loaded: application/views/common/footer.php
DEBUG - 2011-09-19 09:25:52 --> File loaded: application/views/layout/main.php
DEBUG - 2011-09-19 09:25:52 --> Final output sent to browser
DEBUG - 2011-09-19 09:25:52 --> Total execution time: 0.7778
DEBUG - 2011-09-19 09:25:54 --> Config Class Initialized
DEBUG - 2011-09-19 09:25:54 --> Hooks Class Initialized
DEBUG - 2011-09-19 09:25:54 --> Utf8 Class Initialized
DEBUG - 2011-09-19 09:25:54 --> UTF-8 Support Enabled
DEBUG - 2011-09-19 09:25:54 --> URI Class Initialized
DEBUG - 2011-09-19 09:25:54 --> Router Class Initialized
ERROR - 2011-09-19 09:25:54 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-09-19 09:26:05 --> Config Class Initialized
DEBUG - 2011-09-19 09:26:05 --> Hooks Class Initialized
DEBUG - 2011-09-19 09:26:05 --> Utf8 Class Initialized
DEBUG - 2011-09-19 09:26:05 --> UTF-8 Support Enabled
DEBUG - 2011-09-19 09:26:05 --> URI Class Initialized
DEBUG - 2011-09-19 09:26:05 --> Router Class Initialized
DEBUG - 2011-09-19 09:26:05 --> Output Class Initialized
DEBUG - 2011-09-19 09:26:05 --> Input Class Initialized
DEBUG - 2011-09-19 09:26:05 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-19 09:26:05 --> Language Class Initialized
DEBUG - 2011-09-19 09:26:05 --> Loader Class Initialized
DEBUG - 2011-09-19 09:26:05 --> Controller Class Initialized
DEBUG - 2011-09-19 09:26:05 --> Model Class Initialized
DEBUG - 2011-09-19 09:26:05 --> Model Class Initialized
DEBUG - 2011-09-19 09:26:05 --> Model Class Initialized
DEBUG - 2011-09-19 09:26:05 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-19 09:26:05 --> Database Driver Class Initialized
DEBUG - 2011-09-19 09:26:05 --> File loaded: application/views/table/main.php
DEBUG - 2011-09-19 09:26:05 --> Helper loaded: url_helper
DEBUG - 2011-09-19 09:26:05 --> File loaded: application/views/common/header.php
DEBUG - 2011-09-19 09:26:05 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-09-19 09:26:05 --> File loaded: application/views/common/footer.php
DEBUG - 2011-09-19 09:26:05 --> File loaded: application/views/layout/main.php
DEBUG - 2011-09-19 09:26:05 --> Final output sent to browser
DEBUG - 2011-09-19 09:26:05 --> Total execution time: 0.1210
DEBUG - 2011-09-19 09:26:26 --> Config Class Initialized
DEBUG - 2011-09-19 09:26:26 --> Hooks Class Initialized
DEBUG - 2011-09-19 09:26:26 --> Utf8 Class Initialized
DEBUG - 2011-09-19 09:26:26 --> UTF-8 Support Enabled
DEBUG - 2011-09-19 09:26:26 --> URI Class Initialized
DEBUG - 2011-09-19 09:26:26 --> Router Class Initialized
DEBUG - 2011-09-19 09:26:26 --> Output Class Initialized
DEBUG - 2011-09-19 09:26:26 --> Input Class Initialized
DEBUG - 2011-09-19 09:26:26 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-19 09:26:26 --> Language Class Initialized
DEBUG - 2011-09-19 09:26:26 --> Loader Class Initialized
DEBUG - 2011-09-19 09:26:26 --> Controller Class Initialized
DEBUG - 2011-09-19 09:26:26 --> Model Class Initialized
DEBUG - 2011-09-19 09:26:26 --> Model Class Initialized
DEBUG - 2011-09-19 09:26:26 --> Model Class Initialized
DEBUG - 2011-09-19 09:26:26 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-19 09:26:26 --> Database Driver Class Initialized
DEBUG - 2011-09-19 09:26:26 --> File loaded: application/views/table/main.php
DEBUG - 2011-09-19 09:26:26 --> Helper loaded: url_helper
DEBUG - 2011-09-19 09:26:26 --> File loaded: application/views/common/header.php
DEBUG - 2011-09-19 09:26:26 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-09-19 09:26:26 --> File loaded: application/views/common/footer.php
DEBUG - 2011-09-19 09:26:26 --> File loaded: application/views/layout/main.php
DEBUG - 2011-09-19 09:26:26 --> Final output sent to browser
DEBUG - 2011-09-19 09:26:26 --> Total execution time: 0.0613
DEBUG - 2011-09-19 09:26:49 --> Config Class Initialized
DEBUG - 2011-09-19 09:26:49 --> Hooks Class Initialized
DEBUG - 2011-09-19 09:26:49 --> Utf8 Class Initialized
DEBUG - 2011-09-19 09:26:49 --> UTF-8 Support Enabled
DEBUG - 2011-09-19 09:26:49 --> URI Class Initialized
DEBUG - 2011-09-19 09:26:49 --> Router Class Initialized
DEBUG - 2011-09-19 09:26:49 --> Output Class Initialized
DEBUG - 2011-09-19 09:26:49 --> Input Class Initialized
DEBUG - 2011-09-19 09:26:49 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-19 09:26:49 --> Language Class Initialized
DEBUG - 2011-09-19 09:26:49 --> Loader Class Initialized
DEBUG - 2011-09-19 09:26:49 --> Controller Class Initialized
DEBUG - 2011-09-19 09:26:49 --> Model Class Initialized
DEBUG - 2011-09-19 09:26:49 --> Model Class Initialized
DEBUG - 2011-09-19 09:26:49 --> Model Class Initialized
DEBUG - 2011-09-19 09:26:49 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-19 09:26:49 --> Database Driver Class Initialized
DEBUG - 2011-09-19 09:26:50 --> File loaded: application/views/table/main.php
DEBUG - 2011-09-19 09:26:50 --> Helper loaded: url_helper
DEBUG - 2011-09-19 09:26:50 --> File loaded: application/views/common/header.php
DEBUG - 2011-09-19 09:26:50 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-09-19 09:26:50 --> File loaded: application/views/common/footer.php
DEBUG - 2011-09-19 09:26:50 --> File loaded: application/views/layout/main.php
DEBUG - 2011-09-19 09:26:50 --> Final output sent to browser
DEBUG - 2011-09-19 09:26:50 --> Total execution time: 0.0885
DEBUG - 2011-09-19 09:26:56 --> Config Class Initialized
DEBUG - 2011-09-19 09:26:56 --> Hooks Class Initialized
DEBUG - 2011-09-19 09:26:56 --> Utf8 Class Initialized
DEBUG - 2011-09-19 09:26:56 --> UTF-8 Support Enabled
DEBUG - 2011-09-19 09:26:56 --> URI Class Initialized
DEBUG - 2011-09-19 09:26:56 --> Router Class Initialized
ERROR - 2011-09-19 09:26:56 --> 404 Page Not Found --> robots.txt
DEBUG - 2011-09-19 09:54:22 --> Config Class Initialized
DEBUG - 2011-09-19 09:54:22 --> Hooks Class Initialized
DEBUG - 2011-09-19 09:54:22 --> Utf8 Class Initialized
DEBUG - 2011-09-19 09:54:22 --> UTF-8 Support Enabled
DEBUG - 2011-09-19 09:54:23 --> URI Class Initialized
DEBUG - 2011-09-19 09:54:23 --> Router Class Initialized
DEBUG - 2011-09-19 09:54:23 --> Output Class Initialized
DEBUG - 2011-09-19 09:54:23 --> Input Class Initialized
DEBUG - 2011-09-19 09:54:23 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-19 09:54:23 --> Language Class Initialized
DEBUG - 2011-09-19 09:54:23 --> Loader Class Initialized
DEBUG - 2011-09-19 09:54:23 --> Controller Class Initialized
ERROR - 2011-09-19 09:54:23 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-09-19 09:54:23 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-09-19 09:54:23 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-09-19 09:54:23 --> Model Class Initialized
DEBUG - 2011-09-19 09:54:23 --> Model Class Initialized
DEBUG - 2011-09-19 09:54:23 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-19 09:54:23 --> Database Driver Class Initialized
DEBUG - 2011-09-19 09:54:23 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-09-19 09:54:23 --> Helper loaded: url_helper
DEBUG - 2011-09-19 09:54:23 --> File loaded: application/views/common/header.php
DEBUG - 2011-09-19 09:54:23 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-09-19 09:54:23 --> File loaded: application/views/common/footer.php
DEBUG - 2011-09-19 09:54:23 --> File loaded: application/views/layout/main.php
DEBUG - 2011-09-19 09:54:23 --> Final output sent to browser
DEBUG - 2011-09-19 09:54:23 --> Total execution time: 0.1259
DEBUG - 2011-09-19 09:54:24 --> Config Class Initialized
DEBUG - 2011-09-19 09:54:24 --> Hooks Class Initialized
DEBUG - 2011-09-19 09:54:24 --> Utf8 Class Initialized
DEBUG - 2011-09-19 09:54:24 --> UTF-8 Support Enabled
DEBUG - 2011-09-19 09:54:24 --> URI Class Initialized
DEBUG - 2011-09-19 09:54:24 --> Router Class Initialized
DEBUG - 2011-09-19 09:54:24 --> Output Class Initialized
DEBUG - 2011-09-19 09:54:24 --> Input Class Initialized
DEBUG - 2011-09-19 09:54:24 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-19 09:54:24 --> Language Class Initialized
DEBUG - 2011-09-19 09:54:24 --> Loader Class Initialized
DEBUG - 2011-09-19 09:54:24 --> Controller Class Initialized
DEBUG - 2011-09-19 09:54:24 --> Model Class Initialized
DEBUG - 2011-09-19 09:54:24 --> Model Class Initialized
DEBUG - 2011-09-19 09:54:24 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-19 09:54:24 --> Database Driver Class Initialized
DEBUG - 2011-09-19 09:54:25 --> Final output sent to browser
DEBUG - 2011-09-19 09:54:25 --> Total execution time: 0.6125
DEBUG - 2011-09-19 09:54:27 --> Config Class Initialized
DEBUG - 2011-09-19 09:54:27 --> Hooks Class Initialized
DEBUG - 2011-09-19 09:54:27 --> Utf8 Class Initialized
DEBUG - 2011-09-19 09:54:27 --> UTF-8 Support Enabled
DEBUG - 2011-09-19 09:54:27 --> URI Class Initialized
DEBUG - 2011-09-19 09:54:27 --> Router Class Initialized
ERROR - 2011-09-19 09:54:27 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-09-19 09:54:38 --> Config Class Initialized
DEBUG - 2011-09-19 09:54:38 --> Hooks Class Initialized
DEBUG - 2011-09-19 09:54:38 --> Utf8 Class Initialized
DEBUG - 2011-09-19 09:54:38 --> UTF-8 Support Enabled
DEBUG - 2011-09-19 09:54:38 --> URI Class Initialized
DEBUG - 2011-09-19 09:54:38 --> Router Class Initialized
DEBUG - 2011-09-19 09:54:38 --> Output Class Initialized
DEBUG - 2011-09-19 09:54:38 --> Input Class Initialized
DEBUG - 2011-09-19 09:54:38 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-19 09:54:38 --> Language Class Initialized
DEBUG - 2011-09-19 09:54:38 --> Loader Class Initialized
DEBUG - 2011-09-19 09:54:38 --> Controller Class Initialized
ERROR - 2011-09-19 09:54:38 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-09-19 09:54:38 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-09-19 09:54:38 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-09-19 09:54:38 --> Model Class Initialized
DEBUG - 2011-09-19 09:54:38 --> Model Class Initialized
DEBUG - 2011-09-19 09:54:38 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-19 09:54:38 --> Database Driver Class Initialized
DEBUG - 2011-09-19 09:54:38 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-09-19 09:54:38 --> Helper loaded: url_helper
DEBUG - 2011-09-19 09:54:38 --> File loaded: application/views/common/header.php
DEBUG - 2011-09-19 09:54:38 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-09-19 09:54:38 --> File loaded: application/views/common/footer.php
DEBUG - 2011-09-19 09:54:38 --> File loaded: application/views/layout/main.php
DEBUG - 2011-09-19 09:54:38 --> Final output sent to browser
DEBUG - 2011-09-19 09:54:38 --> Total execution time: 0.0612
DEBUG - 2011-09-19 09:54:39 --> Config Class Initialized
DEBUG - 2011-09-19 09:54:39 --> Hooks Class Initialized
DEBUG - 2011-09-19 09:54:39 --> Utf8 Class Initialized
DEBUG - 2011-09-19 09:54:39 --> UTF-8 Support Enabled
DEBUG - 2011-09-19 09:54:39 --> URI Class Initialized
DEBUG - 2011-09-19 09:54:39 --> Router Class Initialized
DEBUG - 2011-09-19 09:54:39 --> Output Class Initialized
DEBUG - 2011-09-19 09:54:39 --> Input Class Initialized
DEBUG - 2011-09-19 09:54:39 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-19 09:54:39 --> Language Class Initialized
DEBUG - 2011-09-19 09:54:39 --> Loader Class Initialized
DEBUG - 2011-09-19 09:54:39 --> Controller Class Initialized
DEBUG - 2011-09-19 09:54:39 --> Model Class Initialized
DEBUG - 2011-09-19 09:54:39 --> Model Class Initialized
DEBUG - 2011-09-19 09:54:39 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-19 09:54:39 --> Database Driver Class Initialized
DEBUG - 2011-09-19 09:54:40 --> Final output sent to browser
DEBUG - 2011-09-19 09:54:40 --> Total execution time: 0.7409
DEBUG - 2011-09-19 09:54:43 --> Config Class Initialized
DEBUG - 2011-09-19 09:54:43 --> Hooks Class Initialized
DEBUG - 2011-09-19 09:54:43 --> Utf8 Class Initialized
DEBUG - 2011-09-19 09:54:43 --> UTF-8 Support Enabled
DEBUG - 2011-09-19 09:54:43 --> URI Class Initialized
DEBUG - 2011-09-19 09:54:43 --> Router Class Initialized
ERROR - 2011-09-19 09:54:43 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-09-19 12:19:17 --> Config Class Initialized
DEBUG - 2011-09-19 12:19:17 --> Hooks Class Initialized
DEBUG - 2011-09-19 12:19:17 --> Utf8 Class Initialized
DEBUG - 2011-09-19 12:19:17 --> UTF-8 Support Enabled
DEBUG - 2011-09-19 12:19:17 --> URI Class Initialized
DEBUG - 2011-09-19 12:19:17 --> Router Class Initialized
DEBUG - 2011-09-19 12:19:17 --> Output Class Initialized
DEBUG - 2011-09-19 12:19:17 --> Input Class Initialized
DEBUG - 2011-09-19 12:19:17 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-19 12:19:17 --> Language Class Initialized
DEBUG - 2011-09-19 12:19:17 --> Loader Class Initialized
DEBUG - 2011-09-19 12:19:17 --> Controller Class Initialized
ERROR - 2011-09-19 12:19:17 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-09-19 12:19:17 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-09-19 12:19:17 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-09-19 12:19:17 --> Model Class Initialized
DEBUG - 2011-09-19 12:19:17 --> Model Class Initialized
DEBUG - 2011-09-19 12:19:17 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-19 12:19:17 --> Database Driver Class Initialized
DEBUG - 2011-09-19 12:19:17 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-09-19 12:19:17 --> Helper loaded: url_helper
DEBUG - 2011-09-19 12:19:17 --> File loaded: application/views/common/header.php
DEBUG - 2011-09-19 12:19:17 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-09-19 12:19:17 --> File loaded: application/views/common/footer.php
DEBUG - 2011-09-19 12:19:17 --> File loaded: application/views/layout/main.php
DEBUG - 2011-09-19 12:19:17 --> Final output sent to browser
DEBUG - 2011-09-19 12:19:17 --> Total execution time: 0.6824
DEBUG - 2011-09-19 12:19:19 --> Config Class Initialized
DEBUG - 2011-09-19 12:19:19 --> Hooks Class Initialized
DEBUG - 2011-09-19 12:19:19 --> Utf8 Class Initialized
DEBUG - 2011-09-19 12:19:19 --> UTF-8 Support Enabled
DEBUG - 2011-09-19 12:19:19 --> URI Class Initialized
DEBUG - 2011-09-19 12:19:19 --> Router Class Initialized
DEBUG - 2011-09-19 12:19:19 --> Output Class Initialized
DEBUG - 2011-09-19 12:19:19 --> Input Class Initialized
DEBUG - 2011-09-19 12:19:19 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-19 12:19:19 --> Language Class Initialized
DEBUG - 2011-09-19 12:19:19 --> Loader Class Initialized
DEBUG - 2011-09-19 12:19:19 --> Controller Class Initialized
DEBUG - 2011-09-19 12:19:19 --> Model Class Initialized
DEBUG - 2011-09-19 12:19:19 --> Model Class Initialized
DEBUG - 2011-09-19 12:19:19 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-19 12:19:19 --> Database Driver Class Initialized
DEBUG - 2011-09-19 12:19:21 --> Final output sent to browser
DEBUG - 2011-09-19 12:19:21 --> Total execution time: 1.9889
DEBUG - 2011-09-19 12:19:21 --> Config Class Initialized
DEBUG - 2011-09-19 12:19:21 --> Hooks Class Initialized
DEBUG - 2011-09-19 12:19:21 --> Utf8 Class Initialized
DEBUG - 2011-09-19 12:19:21 --> UTF-8 Support Enabled
DEBUG - 2011-09-19 12:19:21 --> URI Class Initialized
DEBUG - 2011-09-19 12:19:21 --> Router Class Initialized
ERROR - 2011-09-19 12:19:21 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-09-19 12:25:30 --> Config Class Initialized
DEBUG - 2011-09-19 12:25:30 --> Hooks Class Initialized
DEBUG - 2011-09-19 12:25:30 --> Utf8 Class Initialized
DEBUG - 2011-09-19 12:25:30 --> UTF-8 Support Enabled
DEBUG - 2011-09-19 12:25:30 --> URI Class Initialized
DEBUG - 2011-09-19 12:25:30 --> Router Class Initialized
DEBUG - 2011-09-19 12:25:30 --> No URI present. Default controller set.
DEBUG - 2011-09-19 12:25:30 --> Output Class Initialized
DEBUG - 2011-09-19 12:25:30 --> Input Class Initialized
DEBUG - 2011-09-19 12:25:30 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-19 12:25:30 --> Language Class Initialized
DEBUG - 2011-09-19 12:25:30 --> Loader Class Initialized
DEBUG - 2011-09-19 12:25:30 --> Controller Class Initialized
DEBUG - 2011-09-19 12:25:31 --> File loaded: application/views/splash/main.php
DEBUG - 2011-09-19 12:25:31 --> Helper loaded: url_helper
DEBUG - 2011-09-19 12:25:31 --> File loaded: application/views/common/header.php
DEBUG - 2011-09-19 12:25:31 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-09-19 12:25:31 --> File loaded: application/views/common/footer.php
DEBUG - 2011-09-19 12:25:31 --> File loaded: application/views/layout/main.php
DEBUG - 2011-09-19 12:25:31 --> Final output sent to browser
DEBUG - 2011-09-19 12:25:31 --> Total execution time: 0.9544
DEBUG - 2011-09-19 14:24:43 --> Config Class Initialized
DEBUG - 2011-09-19 14:24:43 --> Hooks Class Initialized
DEBUG - 2011-09-19 14:24:43 --> Utf8 Class Initialized
DEBUG - 2011-09-19 14:24:43 --> UTF-8 Support Enabled
DEBUG - 2011-09-19 14:24:43 --> URI Class Initialized
DEBUG - 2011-09-19 14:24:43 --> Router Class Initialized
DEBUG - 2011-09-19 14:24:43 --> Output Class Initialized
DEBUG - 2011-09-19 14:24:43 --> Input Class Initialized
DEBUG - 2011-09-19 14:24:43 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-19 14:24:43 --> Language Class Initialized
DEBUG - 2011-09-19 14:24:43 --> Loader Class Initialized
DEBUG - 2011-09-19 14:24:43 --> Controller Class Initialized
ERROR - 2011-09-19 14:24:43 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-09-19 14:24:43 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-09-19 14:24:43 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-09-19 14:24:43 --> Model Class Initialized
DEBUG - 2011-09-19 14:24:43 --> Model Class Initialized
DEBUG - 2011-09-19 14:24:43 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-19 14:24:43 --> Database Driver Class Initialized
DEBUG - 2011-09-19 14:24:44 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-09-19 14:24:44 --> Helper loaded: url_helper
DEBUG - 2011-09-19 14:24:44 --> File loaded: application/views/common/header.php
DEBUG - 2011-09-19 14:24:44 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-09-19 14:24:44 --> File loaded: application/views/common/footer.php
DEBUG - 2011-09-19 14:24:44 --> File loaded: application/views/layout/main.php
DEBUG - 2011-09-19 14:24:44 --> Final output sent to browser
DEBUG - 2011-09-19 14:24:44 --> Total execution time: 1.0938
DEBUG - 2011-09-19 15:24:56 --> Config Class Initialized
DEBUG - 2011-09-19 15:24:56 --> Hooks Class Initialized
DEBUG - 2011-09-19 15:24:56 --> Utf8 Class Initialized
DEBUG - 2011-09-19 15:24:56 --> UTF-8 Support Enabled
DEBUG - 2011-09-19 15:24:56 --> URI Class Initialized
DEBUG - 2011-09-19 15:24:56 --> Router Class Initialized
DEBUG - 2011-09-19 15:24:56 --> Output Class Initialized
DEBUG - 2011-09-19 15:24:56 --> Input Class Initialized
DEBUG - 2011-09-19 15:24:56 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-19 15:24:56 --> Language Class Initialized
DEBUG - 2011-09-19 15:24:56 --> Loader Class Initialized
DEBUG - 2011-09-19 15:24:56 --> Controller Class Initialized
DEBUG - 2011-09-19 15:24:56 --> Model Class Initialized
DEBUG - 2011-09-19 15:24:56 --> Model Class Initialized
DEBUG - 2011-09-19 15:24:56 --> Model Class Initialized
DEBUG - 2011-09-19 15:24:56 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-19 15:24:56 --> Database Driver Class Initialized
DEBUG - 2011-09-19 15:24:57 --> File loaded: application/views/table/main.php
DEBUG - 2011-09-19 15:24:57 --> Helper loaded: url_helper
DEBUG - 2011-09-19 15:24:57 --> File loaded: application/views/common/header.php
DEBUG - 2011-09-19 15:24:57 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-09-19 15:24:57 --> File loaded: application/views/common/footer.php
DEBUG - 2011-09-19 15:24:57 --> File loaded: application/views/layout/main.php
DEBUG - 2011-09-19 15:24:57 --> Final output sent to browser
DEBUG - 2011-09-19 15:24:57 --> Total execution time: 0.8366
DEBUG - 2011-09-19 15:25:00 --> Config Class Initialized
DEBUG - 2011-09-19 15:25:00 --> Hooks Class Initialized
DEBUG - 2011-09-19 15:25:00 --> Utf8 Class Initialized
DEBUG - 2011-09-19 15:25:00 --> UTF-8 Support Enabled
DEBUG - 2011-09-19 15:25:00 --> URI Class Initialized
DEBUG - 2011-09-19 15:25:00 --> Router Class Initialized
ERROR - 2011-09-19 15:25:00 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-09-19 15:25:05 --> Config Class Initialized
DEBUG - 2011-09-19 15:25:05 --> Hooks Class Initialized
DEBUG - 2011-09-19 15:25:05 --> Utf8 Class Initialized
DEBUG - 2011-09-19 15:25:05 --> UTF-8 Support Enabled
DEBUG - 2011-09-19 15:25:05 --> URI Class Initialized
DEBUG - 2011-09-19 15:25:05 --> Router Class Initialized
DEBUG - 2011-09-19 15:25:05 --> Output Class Initialized
DEBUG - 2011-09-19 15:25:05 --> Input Class Initialized
DEBUG - 2011-09-19 15:25:05 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-19 15:25:05 --> Language Class Initialized
DEBUG - 2011-09-19 15:25:05 --> Loader Class Initialized
DEBUG - 2011-09-19 15:25:05 --> Controller Class Initialized
ERROR - 2011-09-19 15:25:05 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-09-19 15:25:05 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-09-19 15:25:05 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-09-19 15:25:05 --> Model Class Initialized
DEBUG - 2011-09-19 15:25:05 --> Model Class Initialized
DEBUG - 2011-09-19 15:25:05 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-19 15:25:05 --> Database Driver Class Initialized
DEBUG - 2011-09-19 15:25:05 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-09-19 15:25:05 --> Helper loaded: url_helper
DEBUG - 2011-09-19 15:25:05 --> File loaded: application/views/common/header.php
DEBUG - 2011-09-19 15:25:05 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-09-19 15:25:05 --> File loaded: application/views/common/footer.php
DEBUG - 2011-09-19 15:25:05 --> File loaded: application/views/layout/main.php
DEBUG - 2011-09-19 15:25:05 --> Final output sent to browser
DEBUG - 2011-09-19 15:25:05 --> Total execution time: 0.2029
DEBUG - 2011-09-19 15:25:06 --> Config Class Initialized
DEBUG - 2011-09-19 15:25:06 --> Hooks Class Initialized
DEBUG - 2011-09-19 15:25:07 --> Utf8 Class Initialized
DEBUG - 2011-09-19 15:25:07 --> UTF-8 Support Enabled
DEBUG - 2011-09-19 15:25:07 --> URI Class Initialized
DEBUG - 2011-09-19 15:25:07 --> Router Class Initialized
DEBUG - 2011-09-19 15:25:07 --> Output Class Initialized
DEBUG - 2011-09-19 15:25:07 --> Input Class Initialized
DEBUG - 2011-09-19 15:25:07 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-19 15:25:07 --> Language Class Initialized
DEBUG - 2011-09-19 15:25:07 --> Loader Class Initialized
DEBUG - 2011-09-19 15:25:07 --> Controller Class Initialized
DEBUG - 2011-09-19 15:25:07 --> Model Class Initialized
DEBUG - 2011-09-19 15:25:07 --> Model Class Initialized
DEBUG - 2011-09-19 15:25:07 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-19 15:25:07 --> Database Driver Class Initialized
DEBUG - 2011-09-19 15:25:07 --> Final output sent to browser
DEBUG - 2011-09-19 15:25:07 --> Total execution time: 0.8987
DEBUG - 2011-09-19 15:25:09 --> Config Class Initialized
DEBUG - 2011-09-19 15:25:09 --> Hooks Class Initialized
DEBUG - 2011-09-19 15:25:09 --> Utf8 Class Initialized
DEBUG - 2011-09-19 15:25:09 --> UTF-8 Support Enabled
DEBUG - 2011-09-19 15:25:09 --> URI Class Initialized
DEBUG - 2011-09-19 15:25:09 --> Router Class Initialized
ERROR - 2011-09-19 15:25:09 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-09-19 15:34:30 --> Config Class Initialized
DEBUG - 2011-09-19 15:34:30 --> Hooks Class Initialized
DEBUG - 2011-09-19 15:34:30 --> Utf8 Class Initialized
DEBUG - 2011-09-19 15:34:30 --> UTF-8 Support Enabled
DEBUG - 2011-09-19 15:34:30 --> URI Class Initialized
DEBUG - 2011-09-19 15:34:30 --> Router Class Initialized
DEBUG - 2011-09-19 15:34:30 --> Output Class Initialized
DEBUG - 2011-09-19 15:34:30 --> Input Class Initialized
DEBUG - 2011-09-19 15:34:30 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-19 15:34:30 --> Language Class Initialized
DEBUG - 2011-09-19 15:34:30 --> Loader Class Initialized
DEBUG - 2011-09-19 15:34:30 --> Controller Class Initialized
DEBUG - 2011-09-19 15:34:30 --> Model Class Initialized
DEBUG - 2011-09-19 15:34:30 --> Model Class Initialized
DEBUG - 2011-09-19 15:34:30 --> Model Class Initialized
DEBUG - 2011-09-19 15:34:30 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-19 15:34:30 --> Database Driver Class Initialized
DEBUG - 2011-09-19 15:34:30 --> File loaded: application/views/table/main.php
DEBUG - 2011-09-19 15:34:30 --> Helper loaded: url_helper
DEBUG - 2011-09-19 15:34:30 --> File loaded: application/views/common/header.php
DEBUG - 2011-09-19 15:34:30 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-09-19 15:34:30 --> File loaded: application/views/common/footer.php
DEBUG - 2011-09-19 15:34:30 --> File loaded: application/views/layout/main.php
DEBUG - 2011-09-19 15:34:30 --> Final output sent to browser
DEBUG - 2011-09-19 15:34:30 --> Total execution time: 0.0506
DEBUG - 2011-09-19 15:34:32 --> Config Class Initialized
DEBUG - 2011-09-19 15:34:32 --> Hooks Class Initialized
DEBUG - 2011-09-19 15:34:32 --> Utf8 Class Initialized
DEBUG - 2011-09-19 15:34:32 --> UTF-8 Support Enabled
DEBUG - 2011-09-19 15:34:32 --> URI Class Initialized
DEBUG - 2011-09-19 15:34:32 --> Router Class Initialized
ERROR - 2011-09-19 15:34:32 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-09-19 15:34:32 --> Config Class Initialized
DEBUG - 2011-09-19 15:34:32 --> Hooks Class Initialized
DEBUG - 2011-09-19 15:34:32 --> Utf8 Class Initialized
DEBUG - 2011-09-19 15:34:32 --> UTF-8 Support Enabled
DEBUG - 2011-09-19 15:34:32 --> URI Class Initialized
DEBUG - 2011-09-19 15:34:32 --> Router Class Initialized
ERROR - 2011-09-19 15:34:32 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-09-19 15:34:40 --> Config Class Initialized
DEBUG - 2011-09-19 15:34:40 --> Hooks Class Initialized
DEBUG - 2011-09-19 15:34:40 --> Utf8 Class Initialized
DEBUG - 2011-09-19 15:34:40 --> UTF-8 Support Enabled
DEBUG - 2011-09-19 15:34:40 --> URI Class Initialized
DEBUG - 2011-09-19 15:34:40 --> Router Class Initialized
DEBUG - 2011-09-19 15:34:40 --> Output Class Initialized
DEBUG - 2011-09-19 15:34:40 --> Input Class Initialized
DEBUG - 2011-09-19 15:34:40 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-19 15:34:40 --> Language Class Initialized
DEBUG - 2011-09-19 15:34:40 --> Loader Class Initialized
DEBUG - 2011-09-19 15:34:40 --> Controller Class Initialized
ERROR - 2011-09-19 15:34:40 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-09-19 15:34:40 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-09-19 15:34:40 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-09-19 15:34:40 --> Model Class Initialized
DEBUG - 2011-09-19 15:34:40 --> Model Class Initialized
DEBUG - 2011-09-19 15:34:40 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-19 15:34:40 --> Database Driver Class Initialized
DEBUG - 2011-09-19 15:34:40 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-09-19 15:34:40 --> Helper loaded: url_helper
DEBUG - 2011-09-19 15:34:40 --> File loaded: application/views/common/header.php
DEBUG - 2011-09-19 15:34:40 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-09-19 15:34:40 --> File loaded: application/views/common/footer.php
DEBUG - 2011-09-19 15:34:40 --> File loaded: application/views/layout/main.php
DEBUG - 2011-09-19 15:34:40 --> Final output sent to browser
DEBUG - 2011-09-19 15:34:40 --> Total execution time: 0.0295
DEBUG - 2011-09-19 15:34:40 --> Config Class Initialized
DEBUG - 2011-09-19 15:34:40 --> Hooks Class Initialized
DEBUG - 2011-09-19 15:34:40 --> Utf8 Class Initialized
DEBUG - 2011-09-19 15:34:40 --> UTF-8 Support Enabled
DEBUG - 2011-09-19 15:34:40 --> URI Class Initialized
DEBUG - 2011-09-19 15:34:40 --> Router Class Initialized
DEBUG - 2011-09-19 15:34:40 --> Output Class Initialized
DEBUG - 2011-09-19 15:34:40 --> Input Class Initialized
DEBUG - 2011-09-19 15:34:40 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-19 15:34:40 --> Language Class Initialized
DEBUG - 2011-09-19 15:34:40 --> Loader Class Initialized
DEBUG - 2011-09-19 15:34:40 --> Controller Class Initialized
DEBUG - 2011-09-19 15:34:40 --> Model Class Initialized
DEBUG - 2011-09-19 15:34:40 --> Model Class Initialized
DEBUG - 2011-09-19 15:34:40 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-19 15:34:40 --> Database Driver Class Initialized
DEBUG - 2011-09-19 15:34:40 --> Final output sent to browser
DEBUG - 2011-09-19 15:34:40 --> Total execution time: 0.5169
DEBUG - 2011-09-19 15:34:55 --> Config Class Initialized
DEBUG - 2011-09-19 15:34:55 --> Hooks Class Initialized
DEBUG - 2011-09-19 15:34:55 --> Utf8 Class Initialized
DEBUG - 2011-09-19 15:34:55 --> UTF-8 Support Enabled
DEBUG - 2011-09-19 15:34:55 --> URI Class Initialized
DEBUG - 2011-09-19 15:34:55 --> Router Class Initialized
DEBUG - 2011-09-19 15:34:55 --> Output Class Initialized
DEBUG - 2011-09-19 15:34:56 --> Input Class Initialized
DEBUG - 2011-09-19 15:34:56 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-19 15:34:56 --> Language Class Initialized
DEBUG - 2011-09-19 15:34:56 --> Loader Class Initialized
DEBUG - 2011-09-19 15:34:56 --> Controller Class Initialized
ERROR - 2011-09-19 15:34:56 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-09-19 15:34:56 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-09-19 15:34:56 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-09-19 15:34:56 --> Model Class Initialized
DEBUG - 2011-09-19 15:34:56 --> Model Class Initialized
DEBUG - 2011-09-19 15:34:56 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-19 15:34:56 --> Database Driver Class Initialized
DEBUG - 2011-09-19 15:34:56 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-09-19 15:34:56 --> Helper loaded: url_helper
DEBUG - 2011-09-19 15:34:56 --> File loaded: application/views/common/header.php
DEBUG - 2011-09-19 15:34:56 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-09-19 15:34:56 --> File loaded: application/views/common/footer.php
DEBUG - 2011-09-19 15:34:56 --> File loaded: application/views/layout/main.php
DEBUG - 2011-09-19 15:34:56 --> Final output sent to browser
DEBUG - 2011-09-19 15:34:56 --> Total execution time: 0.0559
DEBUG - 2011-09-19 15:34:56 --> Config Class Initialized
DEBUG - 2011-09-19 15:34:56 --> Hooks Class Initialized
DEBUG - 2011-09-19 15:34:56 --> Utf8 Class Initialized
DEBUG - 2011-09-19 15:34:56 --> UTF-8 Support Enabled
DEBUG - 2011-09-19 15:34:56 --> URI Class Initialized
DEBUG - 2011-09-19 15:34:56 --> Router Class Initialized
DEBUG - 2011-09-19 15:34:56 --> Output Class Initialized
DEBUG - 2011-09-19 15:34:56 --> Input Class Initialized
DEBUG - 2011-09-19 15:34:56 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-19 15:34:56 --> Language Class Initialized
DEBUG - 2011-09-19 15:34:56 --> Loader Class Initialized
DEBUG - 2011-09-19 15:34:56 --> Controller Class Initialized
DEBUG - 2011-09-19 15:34:56 --> Model Class Initialized
DEBUG - 2011-09-19 15:34:56 --> Model Class Initialized
DEBUG - 2011-09-19 15:34:56 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-19 15:34:56 --> Database Driver Class Initialized
DEBUG - 2011-09-19 15:34:57 --> Final output sent to browser
DEBUG - 2011-09-19 15:34:57 --> Total execution time: 0.6964
DEBUG - 2011-09-19 15:35:09 --> Config Class Initialized
DEBUG - 2011-09-19 15:35:09 --> Hooks Class Initialized
DEBUG - 2011-09-19 15:35:09 --> Utf8 Class Initialized
DEBUG - 2011-09-19 15:35:09 --> UTF-8 Support Enabled
DEBUG - 2011-09-19 15:35:09 --> URI Class Initialized
DEBUG - 2011-09-19 15:35:09 --> Router Class Initialized
DEBUG - 2011-09-19 15:35:09 --> Output Class Initialized
DEBUG - 2011-09-19 15:35:09 --> Input Class Initialized
DEBUG - 2011-09-19 15:35:09 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-19 15:35:09 --> Language Class Initialized
DEBUG - 2011-09-19 15:35:09 --> Loader Class Initialized
DEBUG - 2011-09-19 15:35:09 --> Controller Class Initialized
ERROR - 2011-09-19 15:35:09 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-09-19 15:35:09 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-09-19 15:35:09 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-09-19 15:35:09 --> Model Class Initialized
DEBUG - 2011-09-19 15:35:09 --> Model Class Initialized
DEBUG - 2011-09-19 15:35:09 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-19 15:35:09 --> Database Driver Class Initialized
DEBUG - 2011-09-19 15:35:09 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-09-19 15:35:09 --> Helper loaded: url_helper
DEBUG - 2011-09-19 15:35:09 --> File loaded: application/views/common/header.php
DEBUG - 2011-09-19 15:35:09 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-09-19 15:35:09 --> File loaded: application/views/common/footer.php
DEBUG - 2011-09-19 15:35:09 --> File loaded: application/views/layout/main.php
DEBUG - 2011-09-19 15:35:09 --> Final output sent to browser
DEBUG - 2011-09-19 15:35:09 --> Total execution time: 0.0995
DEBUG - 2011-09-19 15:35:10 --> Config Class Initialized
DEBUG - 2011-09-19 15:35:10 --> Hooks Class Initialized
DEBUG - 2011-09-19 15:35:10 --> Utf8 Class Initialized
DEBUG - 2011-09-19 15:35:10 --> UTF-8 Support Enabled
DEBUG - 2011-09-19 15:35:10 --> URI Class Initialized
DEBUG - 2011-09-19 15:35:10 --> Router Class Initialized
DEBUG - 2011-09-19 15:35:10 --> Output Class Initialized
DEBUG - 2011-09-19 15:35:10 --> Input Class Initialized
DEBUG - 2011-09-19 15:35:10 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-19 15:35:10 --> Language Class Initialized
DEBUG - 2011-09-19 15:35:10 --> Loader Class Initialized
DEBUG - 2011-09-19 15:35:10 --> Controller Class Initialized
DEBUG - 2011-09-19 15:35:10 --> Model Class Initialized
DEBUG - 2011-09-19 15:35:10 --> Model Class Initialized
DEBUG - 2011-09-19 15:35:10 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-19 15:35:10 --> Database Driver Class Initialized
DEBUG - 2011-09-19 15:35:10 --> Final output sent to browser
DEBUG - 2011-09-19 15:35:10 --> Total execution time: 0.6406
DEBUG - 2011-09-19 15:35:28 --> Config Class Initialized
DEBUG - 2011-09-19 15:35:28 --> Hooks Class Initialized
DEBUG - 2011-09-19 15:35:28 --> Utf8 Class Initialized
DEBUG - 2011-09-19 15:35:28 --> UTF-8 Support Enabled
DEBUG - 2011-09-19 15:35:28 --> URI Class Initialized
DEBUG - 2011-09-19 15:35:28 --> Router Class Initialized
DEBUG - 2011-09-19 15:35:28 --> Output Class Initialized
DEBUG - 2011-09-19 15:35:28 --> Input Class Initialized
DEBUG - 2011-09-19 15:35:28 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-19 15:35:28 --> Language Class Initialized
DEBUG - 2011-09-19 15:35:28 --> Loader Class Initialized
DEBUG - 2011-09-19 15:35:28 --> Controller Class Initialized
ERROR - 2011-09-19 15:35:28 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-09-19 15:35:28 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-09-19 15:35:28 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-09-19 15:35:28 --> Model Class Initialized
DEBUG - 2011-09-19 15:35:28 --> Model Class Initialized
DEBUG - 2011-09-19 15:35:28 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-19 15:35:28 --> Database Driver Class Initialized
DEBUG - 2011-09-19 15:35:28 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-09-19 15:35:28 --> Helper loaded: url_helper
DEBUG - 2011-09-19 15:35:28 --> File loaded: application/views/common/header.php
DEBUG - 2011-09-19 15:35:28 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-09-19 15:35:28 --> File loaded: application/views/common/footer.php
DEBUG - 2011-09-19 15:35:28 --> File loaded: application/views/layout/main.php
DEBUG - 2011-09-19 15:35:28 --> Final output sent to browser
DEBUG - 2011-09-19 15:35:28 --> Total execution time: 0.0509
DEBUG - 2011-09-19 15:35:29 --> Config Class Initialized
DEBUG - 2011-09-19 15:35:29 --> Hooks Class Initialized
DEBUG - 2011-09-19 15:35:29 --> Utf8 Class Initialized
DEBUG - 2011-09-19 15:35:29 --> UTF-8 Support Enabled
DEBUG - 2011-09-19 15:35:29 --> URI Class Initialized
DEBUG - 2011-09-19 15:35:29 --> Router Class Initialized
DEBUG - 2011-09-19 15:35:29 --> Output Class Initialized
DEBUG - 2011-09-19 15:35:29 --> Input Class Initialized
DEBUG - 2011-09-19 15:35:29 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-19 15:35:29 --> Language Class Initialized
DEBUG - 2011-09-19 15:35:29 --> Loader Class Initialized
DEBUG - 2011-09-19 15:35:29 --> Controller Class Initialized
DEBUG - 2011-09-19 15:35:29 --> Model Class Initialized
DEBUG - 2011-09-19 15:35:29 --> Model Class Initialized
DEBUG - 2011-09-19 15:35:29 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-19 15:35:29 --> Database Driver Class Initialized
DEBUG - 2011-09-19 15:35:30 --> Final output sent to browser
DEBUG - 2011-09-19 15:35:30 --> Total execution time: 0.7487
DEBUG - 2011-09-19 15:40:36 --> Config Class Initialized
DEBUG - 2011-09-19 15:40:36 --> Hooks Class Initialized
DEBUG - 2011-09-19 15:40:36 --> Utf8 Class Initialized
DEBUG - 2011-09-19 15:40:36 --> UTF-8 Support Enabled
DEBUG - 2011-09-19 15:40:36 --> URI Class Initialized
DEBUG - 2011-09-19 15:40:36 --> Router Class Initialized
DEBUG - 2011-09-19 15:40:36 --> Output Class Initialized
DEBUG - 2011-09-19 15:40:36 --> Input Class Initialized
DEBUG - 2011-09-19 15:40:36 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-19 15:40:36 --> Language Class Initialized
DEBUG - 2011-09-19 15:40:36 --> Loader Class Initialized
DEBUG - 2011-09-19 15:40:36 --> Controller Class Initialized
ERROR - 2011-09-19 15:40:36 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-09-19 15:40:36 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-09-19 15:40:36 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-09-19 15:40:36 --> Model Class Initialized
DEBUG - 2011-09-19 15:40:36 --> Model Class Initialized
DEBUG - 2011-09-19 15:40:36 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-19 15:40:36 --> Database Driver Class Initialized
DEBUG - 2011-09-19 15:40:36 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-09-19 15:40:36 --> Helper loaded: url_helper
DEBUG - 2011-09-19 15:40:36 --> File loaded: application/views/common/header.php
DEBUG - 2011-09-19 15:40:36 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-09-19 15:40:36 --> File loaded: application/views/common/footer.php
DEBUG - 2011-09-19 15:40:36 --> File loaded: application/views/layout/main.php
DEBUG - 2011-09-19 15:40:36 --> Final output sent to browser
DEBUG - 2011-09-19 15:40:36 --> Total execution time: 0.0408
DEBUG - 2011-09-19 15:40:36 --> Config Class Initialized
DEBUG - 2011-09-19 15:40:36 --> Hooks Class Initialized
DEBUG - 2011-09-19 15:40:36 --> Utf8 Class Initialized
DEBUG - 2011-09-19 15:40:36 --> UTF-8 Support Enabled
DEBUG - 2011-09-19 15:40:36 --> URI Class Initialized
DEBUG - 2011-09-19 15:40:36 --> Router Class Initialized
DEBUG - 2011-09-19 15:40:36 --> Output Class Initialized
DEBUG - 2011-09-19 15:40:36 --> Input Class Initialized
DEBUG - 2011-09-19 15:40:36 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-19 15:40:36 --> Language Class Initialized
DEBUG - 2011-09-19 15:40:36 --> Loader Class Initialized
DEBUG - 2011-09-19 15:40:36 --> Controller Class Initialized
DEBUG - 2011-09-19 15:40:36 --> Model Class Initialized
DEBUG - 2011-09-19 15:40:36 --> Model Class Initialized
DEBUG - 2011-09-19 15:40:36 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-19 15:40:36 --> Database Driver Class Initialized
DEBUG - 2011-09-19 15:40:37 --> Final output sent to browser
DEBUG - 2011-09-19 15:40:37 --> Total execution time: 0.4491
DEBUG - 2011-09-19 15:40:40 --> Config Class Initialized
DEBUG - 2011-09-19 15:40:40 --> Hooks Class Initialized
DEBUG - 2011-09-19 15:40:40 --> Utf8 Class Initialized
DEBUG - 2011-09-19 15:40:40 --> UTF-8 Support Enabled
DEBUG - 2011-09-19 15:40:40 --> URI Class Initialized
DEBUG - 2011-09-19 15:40:40 --> Router Class Initialized
ERROR - 2011-09-19 15:40:40 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-09-19 15:40:40 --> Config Class Initialized
DEBUG - 2011-09-19 15:40:40 --> Hooks Class Initialized
DEBUG - 2011-09-19 15:40:40 --> Utf8 Class Initialized
DEBUG - 2011-09-19 15:40:40 --> UTF-8 Support Enabled
DEBUG - 2011-09-19 15:40:40 --> URI Class Initialized
DEBUG - 2011-09-19 15:40:40 --> Router Class Initialized
ERROR - 2011-09-19 15:40:40 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-09-19 15:40:59 --> Config Class Initialized
DEBUG - 2011-09-19 15:40:59 --> Hooks Class Initialized
DEBUG - 2011-09-19 15:40:59 --> Utf8 Class Initialized
DEBUG - 2011-09-19 15:40:59 --> UTF-8 Support Enabled
DEBUG - 2011-09-19 15:40:59 --> URI Class Initialized
DEBUG - 2011-09-19 15:40:59 --> Router Class Initialized
DEBUG - 2011-09-19 15:40:59 --> Output Class Initialized
DEBUG - 2011-09-19 15:40:59 --> Input Class Initialized
DEBUG - 2011-09-19 15:40:59 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-19 15:40:59 --> Language Class Initialized
DEBUG - 2011-09-19 15:40:59 --> Loader Class Initialized
DEBUG - 2011-09-19 15:40:59 --> Controller Class Initialized
ERROR - 2011-09-19 15:40:59 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-09-19 15:40:59 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-09-19 15:40:59 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-09-19 15:40:59 --> Model Class Initialized
DEBUG - 2011-09-19 15:40:59 --> Model Class Initialized
DEBUG - 2011-09-19 15:40:59 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-19 15:40:59 --> Database Driver Class Initialized
DEBUG - 2011-09-19 15:40:59 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-09-19 15:40:59 --> Helper loaded: url_helper
DEBUG - 2011-09-19 15:40:59 --> File loaded: application/views/common/header.php
DEBUG - 2011-09-19 15:40:59 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-09-19 15:40:59 --> File loaded: application/views/common/footer.php
DEBUG - 2011-09-19 15:40:59 --> File loaded: application/views/layout/main.php
DEBUG - 2011-09-19 15:40:59 --> Final output sent to browser
DEBUG - 2011-09-19 15:40:59 --> Total execution time: 0.0287
DEBUG - 2011-09-19 15:41:00 --> Config Class Initialized
DEBUG - 2011-09-19 15:41:00 --> Hooks Class Initialized
DEBUG - 2011-09-19 15:41:00 --> Utf8 Class Initialized
DEBUG - 2011-09-19 15:41:00 --> UTF-8 Support Enabled
DEBUG - 2011-09-19 15:41:00 --> URI Class Initialized
DEBUG - 2011-09-19 15:41:00 --> Router Class Initialized
DEBUG - 2011-09-19 15:41:00 --> Output Class Initialized
DEBUG - 2011-09-19 15:41:00 --> Input Class Initialized
DEBUG - 2011-09-19 15:41:00 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-19 15:41:00 --> Language Class Initialized
DEBUG - 2011-09-19 15:41:00 --> Loader Class Initialized
DEBUG - 2011-09-19 15:41:00 --> Controller Class Initialized
DEBUG - 2011-09-19 15:41:00 --> Model Class Initialized
DEBUG - 2011-09-19 15:41:00 --> Model Class Initialized
DEBUG - 2011-09-19 15:41:00 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-19 15:41:00 --> Database Driver Class Initialized
DEBUG - 2011-09-19 15:41:00 --> Final output sent to browser
DEBUG - 2011-09-19 15:41:00 --> Total execution time: 0.6987
DEBUG - 2011-09-19 16:22:36 --> Config Class Initialized
DEBUG - 2011-09-19 16:22:36 --> Hooks Class Initialized
DEBUG - 2011-09-19 16:22:36 --> Utf8 Class Initialized
DEBUG - 2011-09-19 16:22:36 --> UTF-8 Support Enabled
DEBUG - 2011-09-19 16:22:36 --> URI Class Initialized
DEBUG - 2011-09-19 16:22:36 --> Router Class Initialized
DEBUG - 2011-09-19 16:22:36 --> No URI present. Default controller set.
DEBUG - 2011-09-19 16:22:36 --> Output Class Initialized
DEBUG - 2011-09-19 16:22:36 --> Input Class Initialized
DEBUG - 2011-09-19 16:22:36 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-19 16:22:36 --> Language Class Initialized
DEBUG - 2011-09-19 16:22:36 --> Loader Class Initialized
DEBUG - 2011-09-19 16:22:36 --> Controller Class Initialized
DEBUG - 2011-09-19 16:22:36 --> File loaded: application/views/splash/main.php
DEBUG - 2011-09-19 16:22:36 --> Helper loaded: url_helper
DEBUG - 2011-09-19 16:22:36 --> File loaded: application/views/common/header.php
DEBUG - 2011-09-19 16:22:36 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-09-19 16:22:36 --> File loaded: application/views/common/footer.php
DEBUG - 2011-09-19 16:22:36 --> File loaded: application/views/layout/main.php
DEBUG - 2011-09-19 16:22:36 --> Final output sent to browser
DEBUG - 2011-09-19 16:22:36 --> Total execution time: 0.0691
DEBUG - 2011-09-19 17:50:57 --> Config Class Initialized
DEBUG - 2011-09-19 17:50:57 --> Hooks Class Initialized
DEBUG - 2011-09-19 17:50:57 --> Utf8 Class Initialized
DEBUG - 2011-09-19 17:50:57 --> UTF-8 Support Enabled
DEBUG - 2011-09-19 17:50:57 --> URI Class Initialized
DEBUG - 2011-09-19 17:50:57 --> Router Class Initialized
ERROR - 2011-09-19 17:50:57 --> 404 Page Not Found --> robots.txt
DEBUG - 2011-09-19 17:51:35 --> Config Class Initialized
DEBUG - 2011-09-19 17:51:35 --> Hooks Class Initialized
DEBUG - 2011-09-19 17:51:35 --> Utf8 Class Initialized
DEBUG - 2011-09-19 17:51:35 --> UTF-8 Support Enabled
DEBUG - 2011-09-19 17:51:35 --> URI Class Initialized
DEBUG - 2011-09-19 17:51:35 --> Router Class Initialized
DEBUG - 2011-09-19 17:51:35 --> Output Class Initialized
DEBUG - 2011-09-19 17:51:35 --> Input Class Initialized
DEBUG - 2011-09-19 17:51:35 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-19 17:51:35 --> Language Class Initialized
DEBUG - 2011-09-19 17:51:35 --> Loader Class Initialized
DEBUG - 2011-09-19 17:51:35 --> Controller Class Initialized
ERROR - 2011-09-19 17:51:35 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-09-19 17:51:35 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-09-19 17:51:35 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-09-19 17:51:35 --> Model Class Initialized
DEBUG - 2011-09-19 17:51:35 --> Model Class Initialized
DEBUG - 2011-09-19 17:51:35 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-19 17:51:35 --> Database Driver Class Initialized
DEBUG - 2011-09-19 17:51:35 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-09-19 17:51:35 --> Helper loaded: url_helper
DEBUG - 2011-09-19 17:51:35 --> File loaded: application/views/common/header.php
DEBUG - 2011-09-19 17:51:35 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-09-19 17:51:35 --> File loaded: application/views/common/footer.php
DEBUG - 2011-09-19 17:51:35 --> File loaded: application/views/layout/main.php
DEBUG - 2011-09-19 17:51:35 --> Final output sent to browser
DEBUG - 2011-09-19 17:51:35 --> Total execution time: 0.4784
DEBUG - 2011-09-19 18:54:58 --> Config Class Initialized
DEBUG - 2011-09-19 18:54:58 --> Hooks Class Initialized
DEBUG - 2011-09-19 18:54:58 --> Utf8 Class Initialized
DEBUG - 2011-09-19 18:54:58 --> UTF-8 Support Enabled
DEBUG - 2011-09-19 18:54:58 --> URI Class Initialized
DEBUG - 2011-09-19 18:54:58 --> Router Class Initialized
DEBUG - 2011-09-19 18:54:58 --> Output Class Initialized
DEBUG - 2011-09-19 18:54:58 --> Input Class Initialized
DEBUG - 2011-09-19 18:54:58 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-19 18:54:58 --> Language Class Initialized
DEBUG - 2011-09-19 18:54:58 --> Loader Class Initialized
DEBUG - 2011-09-19 18:54:58 --> Controller Class Initialized
ERROR - 2011-09-19 18:54:58 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-09-19 18:54:58 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-09-19 18:54:58 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-09-19 18:54:58 --> Model Class Initialized
DEBUG - 2011-09-19 18:54:58 --> Model Class Initialized
DEBUG - 2011-09-19 18:54:58 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-19 18:54:58 --> Database Driver Class Initialized
DEBUG - 2011-09-19 18:54:59 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-09-19 18:54:59 --> Helper loaded: url_helper
DEBUG - 2011-09-19 18:54:59 --> File loaded: application/views/common/header.php
DEBUG - 2011-09-19 18:54:59 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-09-19 18:54:59 --> File loaded: application/views/common/footer.php
DEBUG - 2011-09-19 18:54:59 --> File loaded: application/views/layout/main.php
DEBUG - 2011-09-19 18:54:59 --> Final output sent to browser
DEBUG - 2011-09-19 18:54:59 --> Total execution time: 0.4799
DEBUG - 2011-09-19 18:55:00 --> Config Class Initialized
DEBUG - 2011-09-19 18:55:00 --> Hooks Class Initialized
DEBUG - 2011-09-19 18:55:00 --> Utf8 Class Initialized
DEBUG - 2011-09-19 18:55:00 --> UTF-8 Support Enabled
DEBUG - 2011-09-19 18:55:00 --> URI Class Initialized
DEBUG - 2011-09-19 18:55:00 --> Router Class Initialized
DEBUG - 2011-09-19 18:55:00 --> Output Class Initialized
DEBUG - 2011-09-19 18:55:00 --> Input Class Initialized
DEBUG - 2011-09-19 18:55:00 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-19 18:55:00 --> Language Class Initialized
DEBUG - 2011-09-19 18:55:00 --> Loader Class Initialized
DEBUG - 2011-09-19 18:55:00 --> Controller Class Initialized
DEBUG - 2011-09-19 18:55:00 --> Model Class Initialized
DEBUG - 2011-09-19 18:55:00 --> Model Class Initialized
DEBUG - 2011-09-19 18:55:00 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-19 18:55:00 --> Database Driver Class Initialized
DEBUG - 2011-09-19 18:55:00 --> Final output sent to browser
DEBUG - 2011-09-19 18:55:00 --> Total execution time: 0.6964
DEBUG - 2011-09-19 18:55:01 --> Config Class Initialized
DEBUG - 2011-09-19 18:55:01 --> Hooks Class Initialized
DEBUG - 2011-09-19 18:55:01 --> Utf8 Class Initialized
DEBUG - 2011-09-19 18:55:01 --> UTF-8 Support Enabled
DEBUG - 2011-09-19 18:55:01 --> URI Class Initialized
DEBUG - 2011-09-19 18:55:01 --> Router Class Initialized
ERROR - 2011-09-19 18:55:01 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-09-19 18:55:03 --> Config Class Initialized
DEBUG - 2011-09-19 18:55:03 --> Hooks Class Initialized
DEBUG - 2011-09-19 18:55:03 --> Utf8 Class Initialized
DEBUG - 2011-09-19 18:55:03 --> UTF-8 Support Enabled
DEBUG - 2011-09-19 18:55:03 --> URI Class Initialized
DEBUG - 2011-09-19 18:55:03 --> Router Class Initialized
ERROR - 2011-09-19 18:55:03 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-09-19 18:55:38 --> Config Class Initialized
DEBUG - 2011-09-19 18:55:38 --> Hooks Class Initialized
DEBUG - 2011-09-19 18:55:38 --> Utf8 Class Initialized
DEBUG - 2011-09-19 18:55:38 --> UTF-8 Support Enabled
DEBUG - 2011-09-19 18:55:38 --> URI Class Initialized
DEBUG - 2011-09-19 18:55:38 --> Router Class Initialized
DEBUG - 2011-09-19 18:55:38 --> Output Class Initialized
DEBUG - 2011-09-19 18:55:38 --> Input Class Initialized
DEBUG - 2011-09-19 18:55:38 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-19 18:55:38 --> Language Class Initialized
DEBUG - 2011-09-19 18:55:38 --> Loader Class Initialized
DEBUG - 2011-09-19 18:55:38 --> Controller Class Initialized
ERROR - 2011-09-19 18:55:38 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-09-19 18:55:38 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-09-19 18:55:38 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-09-19 18:55:38 --> Model Class Initialized
DEBUG - 2011-09-19 18:55:38 --> Model Class Initialized
DEBUG - 2011-09-19 18:55:38 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-19 18:55:38 --> Database Driver Class Initialized
DEBUG - 2011-09-19 18:55:38 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-09-19 18:55:38 --> Helper loaded: url_helper
DEBUG - 2011-09-19 18:55:38 --> File loaded: application/views/common/header.php
DEBUG - 2011-09-19 18:55:38 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-09-19 18:55:38 --> File loaded: application/views/common/footer.php
DEBUG - 2011-09-19 18:55:38 --> File loaded: application/views/layout/main.php
DEBUG - 2011-09-19 18:55:38 --> Final output sent to browser
DEBUG - 2011-09-19 18:55:38 --> Total execution time: 0.0527
DEBUG - 2011-09-19 18:55:38 --> Config Class Initialized
DEBUG - 2011-09-19 18:55:38 --> Hooks Class Initialized
DEBUG - 2011-09-19 18:55:38 --> Utf8 Class Initialized
DEBUG - 2011-09-19 18:55:38 --> UTF-8 Support Enabled
DEBUG - 2011-09-19 18:55:38 --> URI Class Initialized
DEBUG - 2011-09-19 18:55:38 --> Router Class Initialized
DEBUG - 2011-09-19 18:55:38 --> Output Class Initialized
DEBUG - 2011-09-19 18:55:38 --> Input Class Initialized
DEBUG - 2011-09-19 18:55:38 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-19 18:55:38 --> Language Class Initialized
DEBUG - 2011-09-19 18:55:38 --> Loader Class Initialized
DEBUG - 2011-09-19 18:55:38 --> Controller Class Initialized
DEBUG - 2011-09-19 18:55:38 --> Model Class Initialized
DEBUG - 2011-09-19 18:55:38 --> Model Class Initialized
DEBUG - 2011-09-19 18:55:38 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-19 18:55:38 --> Database Driver Class Initialized
DEBUG - 2011-09-19 18:55:39 --> Final output sent to browser
DEBUG - 2011-09-19 18:55:39 --> Total execution time: 0.6108
DEBUG - 2011-09-19 18:55:48 --> Config Class Initialized
DEBUG - 2011-09-19 18:55:48 --> Hooks Class Initialized
DEBUG - 2011-09-19 18:55:48 --> Utf8 Class Initialized
DEBUG - 2011-09-19 18:55:48 --> UTF-8 Support Enabled
DEBUG - 2011-09-19 18:55:48 --> URI Class Initialized
DEBUG - 2011-09-19 18:55:48 --> Router Class Initialized
DEBUG - 2011-09-19 18:55:48 --> Output Class Initialized
DEBUG - 2011-09-19 18:55:48 --> Input Class Initialized
DEBUG - 2011-09-19 18:55:48 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-19 18:55:48 --> Language Class Initialized
DEBUG - 2011-09-19 18:55:48 --> Loader Class Initialized
DEBUG - 2011-09-19 18:55:48 --> Controller Class Initialized
ERROR - 2011-09-19 18:55:48 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-09-19 18:55:48 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-09-19 18:55:48 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-09-19 18:55:48 --> Model Class Initialized
DEBUG - 2011-09-19 18:55:48 --> Model Class Initialized
DEBUG - 2011-09-19 18:55:48 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-19 18:55:48 --> Database Driver Class Initialized
DEBUG - 2011-09-19 18:55:48 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-09-19 18:55:48 --> Helper loaded: url_helper
DEBUG - 2011-09-19 18:55:48 --> File loaded: application/views/common/header.php
DEBUG - 2011-09-19 18:55:48 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-09-19 18:55:48 --> File loaded: application/views/common/footer.php
DEBUG - 2011-09-19 18:55:48 --> File loaded: application/views/layout/main.php
DEBUG - 2011-09-19 18:55:48 --> Final output sent to browser
DEBUG - 2011-09-19 18:55:48 --> Total execution time: 0.0660
DEBUG - 2011-09-19 18:55:49 --> Config Class Initialized
DEBUG - 2011-09-19 18:55:49 --> Hooks Class Initialized
DEBUG - 2011-09-19 18:55:49 --> Utf8 Class Initialized
DEBUG - 2011-09-19 18:55:49 --> UTF-8 Support Enabled
DEBUG - 2011-09-19 18:55:49 --> URI Class Initialized
DEBUG - 2011-09-19 18:55:49 --> Router Class Initialized
DEBUG - 2011-09-19 18:55:49 --> Output Class Initialized
DEBUG - 2011-09-19 18:55:49 --> Input Class Initialized
DEBUG - 2011-09-19 18:55:49 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-19 18:55:49 --> Language Class Initialized
DEBUG - 2011-09-19 18:55:49 --> Loader Class Initialized
DEBUG - 2011-09-19 18:55:49 --> Controller Class Initialized
DEBUG - 2011-09-19 18:55:49 --> Model Class Initialized
DEBUG - 2011-09-19 18:55:49 --> Model Class Initialized
DEBUG - 2011-09-19 18:55:49 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-19 18:55:49 --> Database Driver Class Initialized
DEBUG - 2011-09-19 18:55:50 --> Final output sent to browser
DEBUG - 2011-09-19 18:55:50 --> Total execution time: 0.6422
DEBUG - 2011-09-19 18:56:00 --> Config Class Initialized
DEBUG - 2011-09-19 18:56:00 --> Hooks Class Initialized
DEBUG - 2011-09-19 18:56:00 --> Utf8 Class Initialized
DEBUG - 2011-09-19 18:56:00 --> UTF-8 Support Enabled
DEBUG - 2011-09-19 18:56:00 --> URI Class Initialized
DEBUG - 2011-09-19 18:56:00 --> Router Class Initialized
DEBUG - 2011-09-19 18:56:00 --> Output Class Initialized
DEBUG - 2011-09-19 18:56:00 --> Input Class Initialized
DEBUG - 2011-09-19 18:56:00 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-19 18:56:00 --> Language Class Initialized
DEBUG - 2011-09-19 18:56:00 --> Loader Class Initialized
DEBUG - 2011-09-19 18:56:00 --> Controller Class Initialized
ERROR - 2011-09-19 18:56:00 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-09-19 18:56:00 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-09-19 18:56:00 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-09-19 18:56:00 --> Model Class Initialized
DEBUG - 2011-09-19 18:56:00 --> Model Class Initialized
DEBUG - 2011-09-19 18:56:00 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-19 18:56:00 --> Database Driver Class Initialized
DEBUG - 2011-09-19 18:56:00 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-09-19 18:56:00 --> Helper loaded: url_helper
DEBUG - 2011-09-19 18:56:00 --> File loaded: application/views/common/header.php
DEBUG - 2011-09-19 18:56:00 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-09-19 18:56:00 --> File loaded: application/views/common/footer.php
DEBUG - 2011-09-19 18:56:00 --> File loaded: application/views/layout/main.php
DEBUG - 2011-09-19 18:56:00 --> Final output sent to browser
DEBUG - 2011-09-19 18:56:00 --> Total execution time: 0.0304
DEBUG - 2011-09-19 18:56:01 --> Config Class Initialized
DEBUG - 2011-09-19 18:56:01 --> Hooks Class Initialized
DEBUG - 2011-09-19 18:56:01 --> Utf8 Class Initialized
DEBUG - 2011-09-19 18:56:01 --> UTF-8 Support Enabled
DEBUG - 2011-09-19 18:56:01 --> URI Class Initialized
DEBUG - 2011-09-19 18:56:01 --> Router Class Initialized
DEBUG - 2011-09-19 18:56:01 --> Output Class Initialized
DEBUG - 2011-09-19 18:56:01 --> Input Class Initialized
DEBUG - 2011-09-19 18:56:01 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-19 18:56:01 --> Language Class Initialized
DEBUG - 2011-09-19 18:56:01 --> Loader Class Initialized
DEBUG - 2011-09-19 18:56:01 --> Controller Class Initialized
DEBUG - 2011-09-19 18:56:01 --> Model Class Initialized
DEBUG - 2011-09-19 18:56:01 --> Model Class Initialized
DEBUG - 2011-09-19 18:56:01 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-19 18:56:01 --> Database Driver Class Initialized
DEBUG - 2011-09-19 18:56:02 --> Final output sent to browser
DEBUG - 2011-09-19 18:56:02 --> Total execution time: 0.5281
DEBUG - 2011-09-19 19:08:50 --> Config Class Initialized
DEBUG - 2011-09-19 19:08:50 --> Hooks Class Initialized
DEBUG - 2011-09-19 19:08:50 --> Utf8 Class Initialized
DEBUG - 2011-09-19 19:08:50 --> UTF-8 Support Enabled
DEBUG - 2011-09-19 19:08:50 --> URI Class Initialized
DEBUG - 2011-09-19 19:08:50 --> Router Class Initialized
ERROR - 2011-09-19 19:08:50 --> 404 Page Not Found --> robots.txt
DEBUG - 2011-09-19 19:13:18 --> Config Class Initialized
DEBUG - 2011-09-19 19:13:18 --> Hooks Class Initialized
DEBUG - 2011-09-19 19:13:18 --> Utf8 Class Initialized
DEBUG - 2011-09-19 19:13:18 --> UTF-8 Support Enabled
DEBUG - 2011-09-19 19:13:18 --> URI Class Initialized
DEBUG - 2011-09-19 19:13:18 --> Router Class Initialized
DEBUG - 2011-09-19 19:13:18 --> No URI present. Default controller set.
DEBUG - 2011-09-19 19:13:18 --> Output Class Initialized
DEBUG - 2011-09-19 19:13:18 --> Input Class Initialized
DEBUG - 2011-09-19 19:13:18 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-19 19:13:18 --> Language Class Initialized
DEBUG - 2011-09-19 19:13:19 --> Loader Class Initialized
DEBUG - 2011-09-19 19:13:19 --> Controller Class Initialized
DEBUG - 2011-09-19 19:13:19 --> File loaded: application/views/splash/main.php
DEBUG - 2011-09-19 19:13:19 --> Helper loaded: url_helper
DEBUG - 2011-09-19 19:13:19 --> File loaded: application/views/common/header.php
DEBUG - 2011-09-19 19:13:19 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-09-19 19:13:19 --> File loaded: application/views/common/footer.php
DEBUG - 2011-09-19 19:13:19 --> File loaded: application/views/layout/main.php
DEBUG - 2011-09-19 19:13:19 --> Final output sent to browser
DEBUG - 2011-09-19 19:13:19 --> Total execution time: 0.0568
DEBUG - 2011-09-19 19:15:56 --> Config Class Initialized
DEBUG - 2011-09-19 19:15:56 --> Hooks Class Initialized
DEBUG - 2011-09-19 19:15:56 --> Utf8 Class Initialized
DEBUG - 2011-09-19 19:15:56 --> UTF-8 Support Enabled
DEBUG - 2011-09-19 19:15:56 --> URI Class Initialized
DEBUG - 2011-09-19 19:15:56 --> Router Class Initialized
DEBUG - 2011-09-19 19:15:56 --> Output Class Initialized
DEBUG - 2011-09-19 19:15:56 --> Input Class Initialized
DEBUG - 2011-09-19 19:15:56 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-19 19:15:56 --> Language Class Initialized
DEBUG - 2011-09-19 19:15:56 --> Loader Class Initialized
DEBUG - 2011-09-19 19:15:56 --> Controller Class Initialized
ERROR - 2011-09-19 19:15:56 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-09-19 19:15:56 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-09-19 19:15:56 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-09-19 19:15:56 --> Model Class Initialized
DEBUG - 2011-09-19 19:15:56 --> Model Class Initialized
DEBUG - 2011-09-19 19:15:56 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-19 19:15:56 --> Database Driver Class Initialized
DEBUG - 2011-09-19 19:15:56 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-09-19 19:15:56 --> Helper loaded: url_helper
DEBUG - 2011-09-19 19:15:56 --> File loaded: application/views/common/header.php
DEBUG - 2011-09-19 19:15:56 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-09-19 19:15:56 --> File loaded: application/views/common/footer.php
DEBUG - 2011-09-19 19:15:56 --> File loaded: application/views/layout/main.php
DEBUG - 2011-09-19 19:15:56 --> Final output sent to browser
DEBUG - 2011-09-19 19:15:56 --> Total execution time: 0.0297
DEBUG - 2011-09-19 19:15:57 --> Config Class Initialized
DEBUG - 2011-09-19 19:15:57 --> Hooks Class Initialized
DEBUG - 2011-09-19 19:15:57 --> Utf8 Class Initialized
DEBUG - 2011-09-19 19:15:57 --> UTF-8 Support Enabled
DEBUG - 2011-09-19 19:15:57 --> URI Class Initialized
DEBUG - 2011-09-19 19:15:57 --> Router Class Initialized
DEBUG - 2011-09-19 19:15:57 --> Output Class Initialized
DEBUG - 2011-09-19 19:15:57 --> Input Class Initialized
DEBUG - 2011-09-19 19:15:57 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-19 19:15:57 --> Language Class Initialized
DEBUG - 2011-09-19 19:15:57 --> Loader Class Initialized
DEBUG - 2011-09-19 19:15:57 --> Controller Class Initialized
DEBUG - 2011-09-19 19:15:57 --> Model Class Initialized
DEBUG - 2011-09-19 19:15:57 --> Model Class Initialized
DEBUG - 2011-09-19 19:15:57 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-19 19:15:57 --> Database Driver Class Initialized
DEBUG - 2011-09-19 19:15:58 --> Final output sent to browser
DEBUG - 2011-09-19 19:15:58 --> Total execution time: 0.4782
DEBUG - 2011-09-19 19:15:59 --> Config Class Initialized
DEBUG - 2011-09-19 19:15:59 --> Hooks Class Initialized
DEBUG - 2011-09-19 19:15:59 --> Utf8 Class Initialized
DEBUG - 2011-09-19 19:15:59 --> UTF-8 Support Enabled
DEBUG - 2011-09-19 19:15:59 --> URI Class Initialized
DEBUG - 2011-09-19 19:15:59 --> Router Class Initialized
ERROR - 2011-09-19 19:15:59 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-09-19 19:16:31 --> Config Class Initialized
DEBUG - 2011-09-19 19:16:31 --> Hooks Class Initialized
DEBUG - 2011-09-19 19:16:31 --> Utf8 Class Initialized
DEBUG - 2011-09-19 19:16:31 --> UTF-8 Support Enabled
DEBUG - 2011-09-19 19:16:31 --> URI Class Initialized
DEBUG - 2011-09-19 19:16:31 --> Router Class Initialized
DEBUG - 2011-09-19 19:16:31 --> Output Class Initialized
DEBUG - 2011-09-19 19:16:31 --> Input Class Initialized
DEBUG - 2011-09-19 19:16:31 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-19 19:16:31 --> Language Class Initialized
DEBUG - 2011-09-19 19:16:31 --> Loader Class Initialized
DEBUG - 2011-09-19 19:16:31 --> Controller Class Initialized
ERROR - 2011-09-19 19:16:31 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-09-19 19:16:31 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-09-19 19:16:31 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-09-19 19:16:31 --> Model Class Initialized
DEBUG - 2011-09-19 19:16:31 --> Model Class Initialized
DEBUG - 2011-09-19 19:16:31 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-19 19:16:31 --> Database Driver Class Initialized
DEBUG - 2011-09-19 19:16:31 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-09-19 19:16:31 --> Helper loaded: url_helper
DEBUG - 2011-09-19 19:16:31 --> File loaded: application/views/common/header.php
DEBUG - 2011-09-19 19:16:31 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-09-19 19:16:31 --> File loaded: application/views/common/footer.php
DEBUG - 2011-09-19 19:16:31 --> File loaded: application/views/layout/main.php
DEBUG - 2011-09-19 19:16:31 --> Final output sent to browser
DEBUG - 2011-09-19 19:16:31 --> Total execution time: 0.0368
DEBUG - 2011-09-19 19:16:32 --> Config Class Initialized
DEBUG - 2011-09-19 19:16:32 --> Hooks Class Initialized
DEBUG - 2011-09-19 19:16:32 --> Utf8 Class Initialized
DEBUG - 2011-09-19 19:16:32 --> UTF-8 Support Enabled
DEBUG - 2011-09-19 19:16:32 --> URI Class Initialized
DEBUG - 2011-09-19 19:16:32 --> Router Class Initialized
DEBUG - 2011-09-19 19:16:32 --> Output Class Initialized
DEBUG - 2011-09-19 19:16:32 --> Input Class Initialized
DEBUG - 2011-09-19 19:16:32 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-19 19:16:32 --> Language Class Initialized
DEBUG - 2011-09-19 19:16:32 --> Loader Class Initialized
DEBUG - 2011-09-19 19:16:32 --> Controller Class Initialized
DEBUG - 2011-09-19 19:16:32 --> Model Class Initialized
DEBUG - 2011-09-19 19:16:32 --> Model Class Initialized
DEBUG - 2011-09-19 19:16:32 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-19 19:16:32 --> Database Driver Class Initialized
DEBUG - 2011-09-19 19:16:32 --> Final output sent to browser
DEBUG - 2011-09-19 19:16:32 --> Total execution time: 0.7325
DEBUG - 2011-09-19 19:16:34 --> Config Class Initialized
DEBUG - 2011-09-19 19:16:34 --> Hooks Class Initialized
DEBUG - 2011-09-19 19:16:34 --> Utf8 Class Initialized
DEBUG - 2011-09-19 19:16:34 --> UTF-8 Support Enabled
DEBUG - 2011-09-19 19:16:34 --> URI Class Initialized
DEBUG - 2011-09-19 19:16:34 --> Router Class Initialized
ERROR - 2011-09-19 19:16:34 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-09-19 19:16:39 --> Config Class Initialized
DEBUG - 2011-09-19 19:16:39 --> Hooks Class Initialized
DEBUG - 2011-09-19 19:16:39 --> Utf8 Class Initialized
DEBUG - 2011-09-19 19:16:39 --> UTF-8 Support Enabled
DEBUG - 2011-09-19 19:16:39 --> URI Class Initialized
DEBUG - 2011-09-19 19:16:39 --> Router Class Initialized
DEBUG - 2011-09-19 19:16:39 --> Output Class Initialized
DEBUG - 2011-09-19 19:16:39 --> Input Class Initialized
DEBUG - 2011-09-19 19:16:39 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-19 19:16:39 --> Language Class Initialized
DEBUG - 2011-09-19 19:16:39 --> Loader Class Initialized
DEBUG - 2011-09-19 19:16:39 --> Controller Class Initialized
ERROR - 2011-09-19 19:16:39 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-09-19 19:16:39 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-09-19 19:16:39 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-09-19 19:16:39 --> Model Class Initialized
DEBUG - 2011-09-19 19:16:39 --> Model Class Initialized
DEBUG - 2011-09-19 19:16:39 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-19 19:16:39 --> Database Driver Class Initialized
DEBUG - 2011-09-19 19:16:39 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-09-19 19:16:39 --> Helper loaded: url_helper
DEBUG - 2011-09-19 19:16:39 --> File loaded: application/views/common/header.php
DEBUG - 2011-09-19 19:16:39 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-09-19 19:16:39 --> File loaded: application/views/common/footer.php
DEBUG - 2011-09-19 19:16:39 --> File loaded: application/views/layout/main.php
DEBUG - 2011-09-19 19:16:39 --> Final output sent to browser
DEBUG - 2011-09-19 19:16:39 --> Total execution time: 0.0297
DEBUG - 2011-09-19 19:16:40 --> Config Class Initialized
DEBUG - 2011-09-19 19:16:40 --> Hooks Class Initialized
DEBUG - 2011-09-19 19:16:40 --> Utf8 Class Initialized
DEBUG - 2011-09-19 19:16:40 --> UTF-8 Support Enabled
DEBUG - 2011-09-19 19:16:40 --> URI Class Initialized
DEBUG - 2011-09-19 19:16:40 --> Router Class Initialized
DEBUG - 2011-09-19 19:16:40 --> Output Class Initialized
DEBUG - 2011-09-19 19:16:40 --> Input Class Initialized
DEBUG - 2011-09-19 19:16:40 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-19 19:16:40 --> Language Class Initialized
DEBUG - 2011-09-19 19:16:40 --> Loader Class Initialized
DEBUG - 2011-09-19 19:16:40 --> Controller Class Initialized
DEBUG - 2011-09-19 19:16:40 --> Model Class Initialized
DEBUG - 2011-09-19 19:16:40 --> Model Class Initialized
DEBUG - 2011-09-19 19:16:40 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-19 19:16:40 --> Database Driver Class Initialized
DEBUG - 2011-09-19 19:16:40 --> Final output sent to browser
DEBUG - 2011-09-19 19:16:40 --> Total execution time: 0.5827
DEBUG - 2011-09-19 19:16:41 --> Config Class Initialized
DEBUG - 2011-09-19 19:16:41 --> Hooks Class Initialized
DEBUG - 2011-09-19 19:16:41 --> Utf8 Class Initialized
DEBUG - 2011-09-19 19:16:41 --> UTF-8 Support Enabled
DEBUG - 2011-09-19 19:16:41 --> URI Class Initialized
DEBUG - 2011-09-19 19:16:41 --> Router Class Initialized
ERROR - 2011-09-19 19:16:41 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-09-19 19:16:48 --> Config Class Initialized
DEBUG - 2011-09-19 19:16:48 --> Hooks Class Initialized
DEBUG - 2011-09-19 19:16:48 --> Utf8 Class Initialized
DEBUG - 2011-09-19 19:16:48 --> UTF-8 Support Enabled
DEBUG - 2011-09-19 19:16:48 --> URI Class Initialized
DEBUG - 2011-09-19 19:16:48 --> Router Class Initialized
DEBUG - 2011-09-19 19:16:48 --> Output Class Initialized
DEBUG - 2011-09-19 19:16:48 --> Input Class Initialized
DEBUG - 2011-09-19 19:16:48 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-19 19:16:48 --> Language Class Initialized
DEBUG - 2011-09-19 19:16:48 --> Loader Class Initialized
DEBUG - 2011-09-19 19:16:48 --> Controller Class Initialized
ERROR - 2011-09-19 19:16:48 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-09-19 19:16:48 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-09-19 19:16:48 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-09-19 19:16:48 --> Model Class Initialized
DEBUG - 2011-09-19 19:16:48 --> Model Class Initialized
DEBUG - 2011-09-19 19:16:48 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-19 19:16:48 --> Database Driver Class Initialized
DEBUG - 2011-09-19 19:16:48 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-09-19 19:16:48 --> Helper loaded: url_helper
DEBUG - 2011-09-19 19:16:48 --> File loaded: application/views/common/header.php
DEBUG - 2011-09-19 19:16:48 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-09-19 19:16:48 --> File loaded: application/views/common/footer.php
DEBUG - 2011-09-19 19:16:48 --> File loaded: application/views/layout/main.php
DEBUG - 2011-09-19 19:16:48 --> Final output sent to browser
DEBUG - 2011-09-19 19:16:48 --> Total execution time: 0.1137
DEBUG - 2011-09-19 19:16:49 --> Config Class Initialized
DEBUG - 2011-09-19 19:16:49 --> Hooks Class Initialized
DEBUG - 2011-09-19 19:16:49 --> Utf8 Class Initialized
DEBUG - 2011-09-19 19:16:49 --> UTF-8 Support Enabled
DEBUG - 2011-09-19 19:16:49 --> URI Class Initialized
DEBUG - 2011-09-19 19:16:49 --> Router Class Initialized
DEBUG - 2011-09-19 19:16:49 --> Output Class Initialized
DEBUG - 2011-09-19 19:16:49 --> Input Class Initialized
DEBUG - 2011-09-19 19:16:49 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-19 19:16:49 --> Language Class Initialized
DEBUG - 2011-09-19 19:16:49 --> Loader Class Initialized
DEBUG - 2011-09-19 19:16:49 --> Controller Class Initialized
DEBUG - 2011-09-19 19:16:49 --> Model Class Initialized
DEBUG - 2011-09-19 19:16:49 --> Model Class Initialized
DEBUG - 2011-09-19 19:16:49 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-19 19:16:49 --> Database Driver Class Initialized
DEBUG - 2011-09-19 19:16:50 --> Final output sent to browser
DEBUG - 2011-09-19 19:16:50 --> Total execution time: 0.6956
DEBUG - 2011-09-19 19:16:51 --> Config Class Initialized
DEBUG - 2011-09-19 19:16:51 --> Hooks Class Initialized
DEBUG - 2011-09-19 19:16:51 --> Utf8 Class Initialized
DEBUG - 2011-09-19 19:16:51 --> UTF-8 Support Enabled
DEBUG - 2011-09-19 19:16:51 --> URI Class Initialized
DEBUG - 2011-09-19 19:16:51 --> Router Class Initialized
ERROR - 2011-09-19 19:16:51 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-09-19 19:16:58 --> Config Class Initialized
DEBUG - 2011-09-19 19:16:58 --> Hooks Class Initialized
DEBUG - 2011-09-19 19:16:58 --> Utf8 Class Initialized
DEBUG - 2011-09-19 19:16:58 --> UTF-8 Support Enabled
DEBUG - 2011-09-19 19:16:58 --> URI Class Initialized
DEBUG - 2011-09-19 19:16:58 --> Router Class Initialized
DEBUG - 2011-09-19 19:16:58 --> Output Class Initialized
DEBUG - 2011-09-19 19:16:58 --> Input Class Initialized
DEBUG - 2011-09-19 19:16:58 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-19 19:16:58 --> Language Class Initialized
DEBUG - 2011-09-19 19:16:58 --> Loader Class Initialized
DEBUG - 2011-09-19 19:16:58 --> Controller Class Initialized
ERROR - 2011-09-19 19:16:58 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-09-19 19:16:58 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-09-19 19:16:58 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-09-19 19:16:58 --> Model Class Initialized
DEBUG - 2011-09-19 19:16:58 --> Model Class Initialized
DEBUG - 2011-09-19 19:16:58 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-19 19:16:58 --> Database Driver Class Initialized
DEBUG - 2011-09-19 19:16:58 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-09-19 19:16:58 --> Helper loaded: url_helper
DEBUG - 2011-09-19 19:16:58 --> File loaded: application/views/common/header.php
DEBUG - 2011-09-19 19:16:58 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-09-19 19:16:58 --> File loaded: application/views/common/footer.php
DEBUG - 2011-09-19 19:16:58 --> File loaded: application/views/layout/main.php
DEBUG - 2011-09-19 19:16:58 --> Final output sent to browser
DEBUG - 2011-09-19 19:16:58 --> Total execution time: 0.0810
DEBUG - 2011-09-19 19:16:59 --> Config Class Initialized
DEBUG - 2011-09-19 19:16:59 --> Hooks Class Initialized
DEBUG - 2011-09-19 19:16:59 --> Utf8 Class Initialized
DEBUG - 2011-09-19 19:16:59 --> UTF-8 Support Enabled
DEBUG - 2011-09-19 19:16:59 --> URI Class Initialized
DEBUG - 2011-09-19 19:16:59 --> Router Class Initialized
DEBUG - 2011-09-19 19:16:59 --> Output Class Initialized
DEBUG - 2011-09-19 19:16:59 --> Input Class Initialized
DEBUG - 2011-09-19 19:16:59 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-19 19:16:59 --> Language Class Initialized
DEBUG - 2011-09-19 19:16:59 --> Loader Class Initialized
DEBUG - 2011-09-19 19:16:59 --> Controller Class Initialized
DEBUG - 2011-09-19 19:16:59 --> Model Class Initialized
DEBUG - 2011-09-19 19:16:59 --> Model Class Initialized
DEBUG - 2011-09-19 19:16:59 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-19 19:16:59 --> Database Driver Class Initialized
DEBUG - 2011-09-19 19:16:59 --> Final output sent to browser
DEBUG - 2011-09-19 19:16:59 --> Total execution time: 0.5517
DEBUG - 2011-09-19 19:17:01 --> Config Class Initialized
DEBUG - 2011-09-19 19:17:01 --> Hooks Class Initialized
DEBUG - 2011-09-19 19:17:01 --> Utf8 Class Initialized
DEBUG - 2011-09-19 19:17:01 --> UTF-8 Support Enabled
DEBUG - 2011-09-19 19:17:01 --> URI Class Initialized
DEBUG - 2011-09-19 19:17:01 --> Router Class Initialized
ERROR - 2011-09-19 19:17:01 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-09-19 19:17:13 --> Config Class Initialized
DEBUG - 2011-09-19 19:17:13 --> Hooks Class Initialized
DEBUG - 2011-09-19 19:17:13 --> Utf8 Class Initialized
DEBUG - 2011-09-19 19:17:13 --> UTF-8 Support Enabled
DEBUG - 2011-09-19 19:17:13 --> URI Class Initialized
DEBUG - 2011-09-19 19:17:13 --> Router Class Initialized
DEBUG - 2011-09-19 19:17:13 --> Output Class Initialized
DEBUG - 2011-09-19 19:17:13 --> Input Class Initialized
DEBUG - 2011-09-19 19:17:13 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-19 19:17:13 --> Language Class Initialized
DEBUG - 2011-09-19 19:17:13 --> Loader Class Initialized
DEBUG - 2011-09-19 19:17:13 --> Controller Class Initialized
ERROR - 2011-09-19 19:17:13 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-09-19 19:17:13 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-09-19 19:17:13 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-09-19 19:17:13 --> Model Class Initialized
DEBUG - 2011-09-19 19:17:13 --> Model Class Initialized
DEBUG - 2011-09-19 19:17:13 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-19 19:17:13 --> Database Driver Class Initialized
DEBUG - 2011-09-19 19:17:13 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-09-19 19:17:13 --> Helper loaded: url_helper
DEBUG - 2011-09-19 19:17:13 --> File loaded: application/views/common/header.php
DEBUG - 2011-09-19 19:17:13 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-09-19 19:17:13 --> File loaded: application/views/common/footer.php
DEBUG - 2011-09-19 19:17:13 --> File loaded: application/views/layout/main.php
DEBUG - 2011-09-19 19:17:13 --> Final output sent to browser
DEBUG - 2011-09-19 19:17:13 --> Total execution time: 0.0283
DEBUG - 2011-09-19 19:17:14 --> Config Class Initialized
DEBUG - 2011-09-19 19:17:14 --> Hooks Class Initialized
DEBUG - 2011-09-19 19:17:14 --> Utf8 Class Initialized
DEBUG - 2011-09-19 19:17:14 --> UTF-8 Support Enabled
DEBUG - 2011-09-19 19:17:14 --> URI Class Initialized
DEBUG - 2011-09-19 19:17:14 --> Router Class Initialized
DEBUG - 2011-09-19 19:17:14 --> Output Class Initialized
DEBUG - 2011-09-19 19:17:14 --> Input Class Initialized
DEBUG - 2011-09-19 19:17:14 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-19 19:17:14 --> Language Class Initialized
DEBUG - 2011-09-19 19:17:14 --> Loader Class Initialized
DEBUG - 2011-09-19 19:17:14 --> Controller Class Initialized
DEBUG - 2011-09-19 19:17:14 --> Model Class Initialized
DEBUG - 2011-09-19 19:17:14 --> Model Class Initialized
DEBUG - 2011-09-19 19:17:14 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-19 19:17:14 --> Database Driver Class Initialized
DEBUG - 2011-09-19 19:17:15 --> Final output sent to browser
DEBUG - 2011-09-19 19:17:15 --> Total execution time: 0.4982
DEBUG - 2011-09-19 19:17:16 --> Config Class Initialized
DEBUG - 2011-09-19 19:17:16 --> Hooks Class Initialized
DEBUG - 2011-09-19 19:17:16 --> Utf8 Class Initialized
DEBUG - 2011-09-19 19:17:16 --> UTF-8 Support Enabled
DEBUG - 2011-09-19 19:17:16 --> URI Class Initialized
DEBUG - 2011-09-19 19:17:16 --> Router Class Initialized
ERROR - 2011-09-19 19:17:16 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-09-19 19:38:43 --> Config Class Initialized
DEBUG - 2011-09-19 19:38:43 --> Hooks Class Initialized
DEBUG - 2011-09-19 19:38:43 --> Utf8 Class Initialized
DEBUG - 2011-09-19 19:38:43 --> UTF-8 Support Enabled
DEBUG - 2011-09-19 19:38:43 --> URI Class Initialized
DEBUG - 2011-09-19 19:38:43 --> Router Class Initialized
DEBUG - 2011-09-19 19:38:43 --> Output Class Initialized
DEBUG - 2011-09-19 19:38:43 --> Input Class Initialized
DEBUG - 2011-09-19 19:38:43 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-19 19:38:43 --> Language Class Initialized
DEBUG - 2011-09-19 19:38:43 --> Loader Class Initialized
DEBUG - 2011-09-19 19:38:43 --> Controller Class Initialized
DEBUG - 2011-09-19 19:38:43 --> Model Class Initialized
DEBUG - 2011-09-19 19:38:43 --> Model Class Initialized
DEBUG - 2011-09-19 19:38:43 --> Model Class Initialized
DEBUG - 2011-09-19 19:38:43 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-19 19:38:43 --> Database Driver Class Initialized
DEBUG - 2011-09-19 19:38:43 --> File loaded: application/views/table/main.php
DEBUG - 2011-09-19 19:38:43 --> Helper loaded: url_helper
DEBUG - 2011-09-19 19:38:43 --> File loaded: application/views/common/header.php
DEBUG - 2011-09-19 19:38:43 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-09-19 19:38:43 --> File loaded: application/views/common/footer.php
DEBUG - 2011-09-19 19:38:43 --> File loaded: application/views/layout/main.php
DEBUG - 2011-09-19 19:38:43 --> Final output sent to browser
DEBUG - 2011-09-19 19:38:43 --> Total execution time: 0.7131
DEBUG - 2011-09-19 19:38:44 --> Config Class Initialized
DEBUG - 2011-09-19 19:38:44 --> Hooks Class Initialized
DEBUG - 2011-09-19 19:38:44 --> Utf8 Class Initialized
DEBUG - 2011-09-19 19:38:44 --> UTF-8 Support Enabled
DEBUG - 2011-09-19 19:38:44 --> URI Class Initialized
DEBUG - 2011-09-19 19:38:44 --> Router Class Initialized
DEBUG - 2011-09-19 19:38:44 --> Output Class Initialized
DEBUG - 2011-09-19 19:38:44 --> Input Class Initialized
DEBUG - 2011-09-19 19:38:44 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-19 19:38:44 --> Language Class Initialized
DEBUG - 2011-09-19 19:38:44 --> Loader Class Initialized
DEBUG - 2011-09-19 19:38:44 --> Controller Class Initialized
DEBUG - 2011-09-19 19:38:44 --> Model Class Initialized
DEBUG - 2011-09-19 19:38:44 --> Model Class Initialized
DEBUG - 2011-09-19 19:38:44 --> Model Class Initialized
DEBUG - 2011-09-19 19:38:44 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-19 19:38:44 --> Database Driver Class Initialized
DEBUG - 2011-09-19 19:38:44 --> File loaded: application/views/table/main.php
DEBUG - 2011-09-19 19:38:44 --> Helper loaded: url_helper
DEBUG - 2011-09-19 19:38:44 --> File loaded: application/views/common/header.php
DEBUG - 2011-09-19 19:38:44 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-09-19 19:38:44 --> File loaded: application/views/common/footer.php
DEBUG - 2011-09-19 19:38:44 --> File loaded: application/views/layout/main.php
DEBUG - 2011-09-19 19:38:44 --> Final output sent to browser
DEBUG - 2011-09-19 19:38:44 --> Total execution time: 0.0428
DEBUG - 2011-09-19 19:38:47 --> Config Class Initialized
DEBUG - 2011-09-19 19:38:47 --> Hooks Class Initialized
DEBUG - 2011-09-19 19:38:47 --> Utf8 Class Initialized
DEBUG - 2011-09-19 19:38:47 --> UTF-8 Support Enabled
DEBUG - 2011-09-19 19:38:47 --> URI Class Initialized
DEBUG - 2011-09-19 19:38:47 --> Router Class Initialized
ERROR - 2011-09-19 19:38:47 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-09-19 20:05:30 --> Config Class Initialized
DEBUG - 2011-09-19 20:05:30 --> Hooks Class Initialized
DEBUG - 2011-09-19 20:05:30 --> Utf8 Class Initialized
DEBUG - 2011-09-19 20:05:30 --> UTF-8 Support Enabled
DEBUG - 2011-09-19 20:05:30 --> URI Class Initialized
DEBUG - 2011-09-19 20:05:30 --> Router Class Initialized
DEBUG - 2011-09-19 20:05:30 --> Output Class Initialized
DEBUG - 2011-09-19 20:05:30 --> Input Class Initialized
DEBUG - 2011-09-19 20:05:30 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-19 20:05:30 --> Language Class Initialized
DEBUG - 2011-09-19 20:05:30 --> Loader Class Initialized
DEBUG - 2011-09-19 20:05:30 --> Controller Class Initialized
ERROR - 2011-09-19 20:05:30 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-09-19 20:05:30 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-09-19 20:05:30 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-09-19 20:05:30 --> Model Class Initialized
DEBUG - 2011-09-19 20:05:30 --> Model Class Initialized
DEBUG - 2011-09-19 20:05:30 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-19 20:05:30 --> Database Driver Class Initialized
DEBUG - 2011-09-19 20:05:30 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-09-19 20:05:30 --> Helper loaded: url_helper
DEBUG - 2011-09-19 20:05:30 --> File loaded: application/views/common/header.php
DEBUG - 2011-09-19 20:05:30 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-09-19 20:05:30 --> File loaded: application/views/common/footer.php
DEBUG - 2011-09-19 20:05:30 --> File loaded: application/views/layout/main.php
DEBUG - 2011-09-19 20:05:30 --> Final output sent to browser
DEBUG - 2011-09-19 20:05:30 --> Total execution time: 0.1634
DEBUG - 2011-09-19 23:38:45 --> Config Class Initialized
DEBUG - 2011-09-19 23:38:45 --> Hooks Class Initialized
DEBUG - 2011-09-19 23:38:45 --> Utf8 Class Initialized
DEBUG - 2011-09-19 23:38:45 --> UTF-8 Support Enabled
DEBUG - 2011-09-19 23:38:45 --> URI Class Initialized
DEBUG - 2011-09-19 23:38:45 --> Router Class Initialized
DEBUG - 2011-09-19 23:38:45 --> No URI present. Default controller set.
DEBUG - 2011-09-19 23:38:45 --> Output Class Initialized
DEBUG - 2011-09-19 23:38:45 --> Input Class Initialized
DEBUG - 2011-09-19 23:38:45 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-19 23:38:45 --> Language Class Initialized
DEBUG - 2011-09-19 23:38:45 --> Loader Class Initialized
DEBUG - 2011-09-19 23:38:45 --> Controller Class Initialized
DEBUG - 2011-09-19 23:38:45 --> File loaded: application/views/splash/main.php
DEBUG - 2011-09-19 23:38:45 --> Helper loaded: url_helper
DEBUG - 2011-09-19 23:38:45 --> File loaded: application/views/common/header.php
DEBUG - 2011-09-19 23:38:45 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-09-19 23:38:45 --> File loaded: application/views/common/footer.php
DEBUG - 2011-09-19 23:38:45 --> File loaded: application/views/layout/main.php
DEBUG - 2011-09-19 23:38:45 --> Final output sent to browser
DEBUG - 2011-09-19 23:38:45 --> Total execution time: 0.4868

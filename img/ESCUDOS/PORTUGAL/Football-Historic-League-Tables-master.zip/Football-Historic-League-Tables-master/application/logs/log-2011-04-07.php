<?php  if ( ! defined('BASEPATH')) exit('No direct script access allowed'); ?>

DEBUG - 2011-04-07 00:41:44 --> Config Class Initialized
DEBUG - 2011-04-07 00:41:44 --> Hooks Class Initialized
DEBUG - 2011-04-07 00:41:44 --> Utf8 Class Initialized
DEBUG - 2011-04-07 00:41:44 --> UTF-8 Support Enabled
DEBUG - 2011-04-07 00:41:44 --> URI Class Initialized
DEBUG - 2011-04-07 00:41:44 --> Router Class Initialized
ERROR - 2011-04-07 00:41:44 --> 404 Page Not Found --> robots.txt
DEBUG - 2011-04-07 00:41:45 --> Config Class Initialized
DEBUG - 2011-04-07 00:41:45 --> Hooks Class Initialized
DEBUG - 2011-04-07 00:41:45 --> Utf8 Class Initialized
DEBUG - 2011-04-07 00:41:45 --> UTF-8 Support Enabled
DEBUG - 2011-04-07 00:41:45 --> URI Class Initialized
DEBUG - 2011-04-07 00:41:45 --> Router Class Initialized
DEBUG - 2011-04-07 00:41:45 --> Output Class Initialized
DEBUG - 2011-04-07 00:41:45 --> Input Class Initialized
DEBUG - 2011-04-07 00:41:45 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-07 00:41:45 --> Language Class Initialized
DEBUG - 2011-04-07 00:41:45 --> Loader Class Initialized
DEBUG - 2011-04-07 00:41:45 --> Controller Class Initialized
ERROR - 2011-04-07 00:41:45 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-04-07 00:41:45 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-04-07 00:41:45 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-04-07 00:41:45 --> Model Class Initialized
DEBUG - 2011-04-07 00:41:45 --> Model Class Initialized
DEBUG - 2011-04-07 00:41:45 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-07 00:41:45 --> Database Driver Class Initialized
DEBUG - 2011-04-07 00:41:45 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-04-07 00:41:45 --> Helper loaded: url_helper
DEBUG - 2011-04-07 00:41:45 --> File loaded: application/views/common/header.php
DEBUG - 2011-04-07 00:41:45 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-04-07 00:41:45 --> File loaded: application/views/common/footer.php
DEBUG - 2011-04-07 00:41:45 --> File loaded: application/views/layout/main.php
DEBUG - 2011-04-07 00:41:45 --> Final output sent to browser
DEBUG - 2011-04-07 00:41:45 --> Total execution time: 0.2736
DEBUG - 2011-04-07 01:28:41 --> Config Class Initialized
DEBUG - 2011-04-07 01:28:41 --> Hooks Class Initialized
DEBUG - 2011-04-07 01:28:41 --> Utf8 Class Initialized
DEBUG - 2011-04-07 01:28:41 --> UTF-8 Support Enabled
DEBUG - 2011-04-07 01:28:41 --> URI Class Initialized
DEBUG - 2011-04-07 01:28:41 --> Router Class Initialized
DEBUG - 2011-04-07 01:28:41 --> Output Class Initialized
DEBUG - 2011-04-07 01:28:42 --> Input Class Initialized
DEBUG - 2011-04-07 01:28:42 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-07 01:28:42 --> Language Class Initialized
DEBUG - 2011-04-07 01:28:42 --> Loader Class Initialized
DEBUG - 2011-04-07 01:28:42 --> Controller Class Initialized
DEBUG - 2011-04-07 01:28:42 --> Model Class Initialized
DEBUG - 2011-04-07 01:28:42 --> Model Class Initialized
DEBUG - 2011-04-07 01:28:42 --> Model Class Initialized
DEBUG - 2011-04-07 01:28:42 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-07 01:28:42 --> Database Driver Class Initialized
DEBUG - 2011-04-07 01:28:42 --> File loaded: application/views/table/main.php
DEBUG - 2011-04-07 01:28:42 --> Helper loaded: url_helper
DEBUG - 2011-04-07 01:28:42 --> File loaded: application/views/common/header.php
DEBUG - 2011-04-07 01:28:42 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-04-07 01:28:42 --> File loaded: application/views/common/footer.php
DEBUG - 2011-04-07 01:28:42 --> File loaded: application/views/layout/main.php
DEBUG - 2011-04-07 01:28:42 --> Final output sent to browser
DEBUG - 2011-04-07 01:28:42 --> Total execution time: 0.5000
DEBUG - 2011-04-07 01:28:44 --> Config Class Initialized
DEBUG - 2011-04-07 01:28:44 --> Hooks Class Initialized
DEBUG - 2011-04-07 01:28:44 --> Utf8 Class Initialized
DEBUG - 2011-04-07 01:28:44 --> UTF-8 Support Enabled
DEBUG - 2011-04-07 01:28:44 --> URI Class Initialized
DEBUG - 2011-04-07 01:28:44 --> Router Class Initialized
ERROR - 2011-04-07 01:28:44 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-04-07 01:28:57 --> Config Class Initialized
DEBUG - 2011-04-07 01:28:57 --> Hooks Class Initialized
DEBUG - 2011-04-07 01:28:57 --> Utf8 Class Initialized
DEBUG - 2011-04-07 01:28:57 --> UTF-8 Support Enabled
DEBUG - 2011-04-07 01:28:57 --> URI Class Initialized
DEBUG - 2011-04-07 01:28:57 --> Router Class Initialized
DEBUG - 2011-04-07 01:28:57 --> Output Class Initialized
DEBUG - 2011-04-07 01:28:57 --> Input Class Initialized
DEBUG - 2011-04-07 01:28:57 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-07 01:28:57 --> Language Class Initialized
DEBUG - 2011-04-07 01:28:57 --> Loader Class Initialized
DEBUG - 2011-04-07 01:28:57 --> Controller Class Initialized
DEBUG - 2011-04-07 01:28:57 --> Model Class Initialized
DEBUG - 2011-04-07 01:28:57 --> Model Class Initialized
DEBUG - 2011-04-07 01:28:57 --> Model Class Initialized
DEBUG - 2011-04-07 01:28:57 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-07 01:28:57 --> Database Driver Class Initialized
DEBUG - 2011-04-07 01:28:57 --> File loaded: application/views/table/main.php
DEBUG - 2011-04-07 01:28:57 --> Helper loaded: url_helper
DEBUG - 2011-04-07 01:28:57 --> File loaded: application/views/common/header.php
DEBUG - 2011-04-07 01:28:57 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-04-07 01:28:57 --> File loaded: application/views/common/footer.php
DEBUG - 2011-04-07 01:28:57 --> File loaded: application/views/layout/main.php
DEBUG - 2011-04-07 01:28:57 --> Final output sent to browser
DEBUG - 2011-04-07 01:28:57 --> Total execution time: 0.2093
DEBUG - 2011-04-07 01:28:58 --> Config Class Initialized
DEBUG - 2011-04-07 01:28:58 --> Hooks Class Initialized
DEBUG - 2011-04-07 01:28:58 --> Utf8 Class Initialized
DEBUG - 2011-04-07 01:28:58 --> UTF-8 Support Enabled
DEBUG - 2011-04-07 01:28:58 --> URI Class Initialized
DEBUG - 2011-04-07 01:28:58 --> Router Class Initialized
ERROR - 2011-04-07 01:28:58 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-04-07 01:29:00 --> Config Class Initialized
DEBUG - 2011-04-07 01:29:00 --> Hooks Class Initialized
DEBUG - 2011-04-07 01:29:00 --> Utf8 Class Initialized
DEBUG - 2011-04-07 01:29:00 --> UTF-8 Support Enabled
DEBUG - 2011-04-07 01:29:00 --> URI Class Initialized
DEBUG - 2011-04-07 01:29:00 --> Router Class Initialized
DEBUG - 2011-04-07 01:29:00 --> Output Class Initialized
DEBUG - 2011-04-07 01:29:00 --> Input Class Initialized
DEBUG - 2011-04-07 01:29:00 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-07 01:29:00 --> Language Class Initialized
DEBUG - 2011-04-07 01:29:00 --> Loader Class Initialized
DEBUG - 2011-04-07 01:29:00 --> Controller Class Initialized
DEBUG - 2011-04-07 01:29:00 --> Model Class Initialized
DEBUG - 2011-04-07 01:29:00 --> Model Class Initialized
DEBUG - 2011-04-07 01:29:00 --> Model Class Initialized
DEBUG - 2011-04-07 01:29:00 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-07 01:29:00 --> Database Driver Class Initialized
DEBUG - 2011-04-07 01:29:00 --> File loaded: application/views/table/main.php
DEBUG - 2011-04-07 01:29:00 --> Helper loaded: url_helper
DEBUG - 2011-04-07 01:29:00 --> File loaded: application/views/common/header.php
DEBUG - 2011-04-07 01:29:00 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-04-07 01:29:00 --> File loaded: application/views/common/footer.php
DEBUG - 2011-04-07 01:29:00 --> File loaded: application/views/layout/main.php
DEBUG - 2011-04-07 01:29:00 --> Final output sent to browser
DEBUG - 2011-04-07 01:29:00 --> Total execution time: 0.0480
DEBUG - 2011-04-07 01:29:05 --> Config Class Initialized
DEBUG - 2011-04-07 01:29:05 --> Hooks Class Initialized
DEBUG - 2011-04-07 01:29:05 --> Utf8 Class Initialized
DEBUG - 2011-04-07 01:29:05 --> UTF-8 Support Enabled
DEBUG - 2011-04-07 01:29:05 --> URI Class Initialized
DEBUG - 2011-04-07 01:29:05 --> Router Class Initialized
DEBUG - 2011-04-07 01:29:05 --> Output Class Initialized
DEBUG - 2011-04-07 01:29:05 --> Input Class Initialized
DEBUG - 2011-04-07 01:29:05 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-07 01:29:05 --> Language Class Initialized
DEBUG - 2011-04-07 01:29:05 --> Loader Class Initialized
DEBUG - 2011-04-07 01:29:05 --> Controller Class Initialized
DEBUG - 2011-04-07 01:29:05 --> Model Class Initialized
DEBUG - 2011-04-07 01:29:05 --> Model Class Initialized
DEBUG - 2011-04-07 01:29:05 --> Model Class Initialized
DEBUG - 2011-04-07 01:29:05 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-07 01:29:05 --> Database Driver Class Initialized
DEBUG - 2011-04-07 01:29:05 --> File loaded: application/views/table/main.php
DEBUG - 2011-04-07 01:29:05 --> Helper loaded: url_helper
DEBUG - 2011-04-07 01:29:05 --> File loaded: application/views/common/header.php
DEBUG - 2011-04-07 01:29:05 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-04-07 01:29:05 --> File loaded: application/views/common/footer.php
DEBUG - 2011-04-07 01:29:05 --> File loaded: application/views/layout/main.php
DEBUG - 2011-04-07 01:29:05 --> Final output sent to browser
DEBUG - 2011-04-07 01:29:05 --> Total execution time: 0.0792
DEBUG - 2011-04-07 01:29:07 --> Config Class Initialized
DEBUG - 2011-04-07 01:29:07 --> Hooks Class Initialized
DEBUG - 2011-04-07 01:29:07 --> Utf8 Class Initialized
DEBUG - 2011-04-07 01:29:07 --> UTF-8 Support Enabled
DEBUG - 2011-04-07 01:29:07 --> URI Class Initialized
DEBUG - 2011-04-07 01:29:07 --> Router Class Initialized
ERROR - 2011-04-07 01:29:07 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-04-07 01:29:12 --> Config Class Initialized
DEBUG - 2011-04-07 01:29:12 --> Hooks Class Initialized
DEBUG - 2011-04-07 01:29:12 --> Utf8 Class Initialized
DEBUG - 2011-04-07 01:29:12 --> UTF-8 Support Enabled
DEBUG - 2011-04-07 01:29:12 --> URI Class Initialized
DEBUG - 2011-04-07 01:29:12 --> Router Class Initialized
DEBUG - 2011-04-07 01:29:12 --> Output Class Initialized
DEBUG - 2011-04-07 01:29:12 --> Input Class Initialized
DEBUG - 2011-04-07 01:29:12 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-07 01:29:12 --> Language Class Initialized
DEBUG - 2011-04-07 01:29:12 --> Loader Class Initialized
DEBUG - 2011-04-07 01:29:12 --> Controller Class Initialized
DEBUG - 2011-04-07 01:29:12 --> Model Class Initialized
DEBUG - 2011-04-07 01:29:12 --> Model Class Initialized
DEBUG - 2011-04-07 01:29:12 --> Model Class Initialized
DEBUG - 2011-04-07 01:29:12 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-07 01:29:12 --> Database Driver Class Initialized
DEBUG - 2011-04-07 01:29:13 --> File loaded: application/views/table/main.php
DEBUG - 2011-04-07 01:29:13 --> Helper loaded: url_helper
DEBUG - 2011-04-07 01:29:13 --> File loaded: application/views/common/header.php
DEBUG - 2011-04-07 01:29:13 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-04-07 01:29:13 --> File loaded: application/views/common/footer.php
DEBUG - 2011-04-07 01:29:13 --> File loaded: application/views/layout/main.php
DEBUG - 2011-04-07 01:29:13 --> Final output sent to browser
DEBUG - 2011-04-07 01:29:13 --> Total execution time: 0.3141
DEBUG - 2011-04-07 01:29:14 --> Config Class Initialized
DEBUG - 2011-04-07 01:29:14 --> Hooks Class Initialized
DEBUG - 2011-04-07 01:29:14 --> Utf8 Class Initialized
DEBUG - 2011-04-07 01:29:14 --> UTF-8 Support Enabled
DEBUG - 2011-04-07 01:29:14 --> URI Class Initialized
DEBUG - 2011-04-07 01:29:14 --> Router Class Initialized
ERROR - 2011-04-07 01:29:14 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-04-07 01:29:22 --> Config Class Initialized
DEBUG - 2011-04-07 01:29:22 --> Hooks Class Initialized
DEBUG - 2011-04-07 01:29:22 --> Utf8 Class Initialized
DEBUG - 2011-04-07 01:29:22 --> UTF-8 Support Enabled
DEBUG - 2011-04-07 01:29:22 --> URI Class Initialized
DEBUG - 2011-04-07 01:29:22 --> Router Class Initialized
DEBUG - 2011-04-07 01:29:22 --> Output Class Initialized
DEBUG - 2011-04-07 01:29:22 --> Input Class Initialized
DEBUG - 2011-04-07 01:29:22 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-07 01:29:22 --> Language Class Initialized
DEBUG - 2011-04-07 01:29:22 --> Loader Class Initialized
DEBUG - 2011-04-07 01:29:22 --> Controller Class Initialized
DEBUG - 2011-04-07 01:29:22 --> Model Class Initialized
DEBUG - 2011-04-07 01:29:22 --> Model Class Initialized
DEBUG - 2011-04-07 01:29:22 --> Model Class Initialized
DEBUG - 2011-04-07 01:29:22 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-07 01:29:22 --> Database Driver Class Initialized
DEBUG - 2011-04-07 01:29:22 --> File loaded: application/views/table/main.php
DEBUG - 2011-04-07 01:29:22 --> Helper loaded: url_helper
DEBUG - 2011-04-07 01:29:22 --> File loaded: application/views/common/header.php
DEBUG - 2011-04-07 01:29:22 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-04-07 01:29:22 --> File loaded: application/views/common/footer.php
DEBUG - 2011-04-07 01:29:22 --> File loaded: application/views/layout/main.php
DEBUG - 2011-04-07 01:29:22 --> Final output sent to browser
DEBUG - 2011-04-07 01:29:22 --> Total execution time: 0.2156
DEBUG - 2011-04-07 01:29:23 --> Config Class Initialized
DEBUG - 2011-04-07 01:29:23 --> Hooks Class Initialized
DEBUG - 2011-04-07 01:29:23 --> Utf8 Class Initialized
DEBUG - 2011-04-07 01:29:23 --> UTF-8 Support Enabled
DEBUG - 2011-04-07 01:29:23 --> URI Class Initialized
DEBUG - 2011-04-07 01:29:23 --> Router Class Initialized
DEBUG - 2011-04-07 01:29:23 --> Output Class Initialized
DEBUG - 2011-04-07 01:29:23 --> Input Class Initialized
DEBUG - 2011-04-07 01:29:23 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-07 01:29:23 --> Language Class Initialized
DEBUG - 2011-04-07 01:29:23 --> Loader Class Initialized
DEBUG - 2011-04-07 01:29:23 --> Controller Class Initialized
DEBUG - 2011-04-07 01:29:23 --> Model Class Initialized
DEBUG - 2011-04-07 01:29:23 --> Model Class Initialized
DEBUG - 2011-04-07 01:29:23 --> Model Class Initialized
DEBUG - 2011-04-07 01:29:23 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-07 01:29:23 --> Database Driver Class Initialized
DEBUG - 2011-04-07 01:29:23 --> File loaded: application/views/table/main.php
DEBUG - 2011-04-07 01:29:23 --> Helper loaded: url_helper
DEBUG - 2011-04-07 01:29:23 --> File loaded: application/views/common/header.php
DEBUG - 2011-04-07 01:29:23 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-04-07 01:29:23 --> File loaded: application/views/common/footer.php
DEBUG - 2011-04-07 01:29:23 --> File loaded: application/views/layout/main.php
DEBUG - 2011-04-07 01:29:23 --> Final output sent to browser
DEBUG - 2011-04-07 01:29:23 --> Total execution time: 0.0443
DEBUG - 2011-04-07 01:29:23 --> Config Class Initialized
DEBUG - 2011-04-07 01:29:23 --> Hooks Class Initialized
DEBUG - 2011-04-07 01:29:23 --> Utf8 Class Initialized
DEBUG - 2011-04-07 01:29:23 --> UTF-8 Support Enabled
DEBUG - 2011-04-07 01:29:23 --> URI Class Initialized
DEBUG - 2011-04-07 01:29:23 --> Router Class Initialized
ERROR - 2011-04-07 01:29:23 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-04-07 01:29:48 --> Config Class Initialized
DEBUG - 2011-04-07 01:29:48 --> Hooks Class Initialized
DEBUG - 2011-04-07 01:29:48 --> Utf8 Class Initialized
DEBUG - 2011-04-07 01:29:48 --> UTF-8 Support Enabled
DEBUG - 2011-04-07 01:29:48 --> URI Class Initialized
DEBUG - 2011-04-07 01:29:48 --> Router Class Initialized
DEBUG - 2011-04-07 01:29:48 --> Output Class Initialized
DEBUG - 2011-04-07 01:29:48 --> Input Class Initialized
DEBUG - 2011-04-07 01:29:48 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-07 01:29:48 --> Language Class Initialized
DEBUG - 2011-04-07 01:29:48 --> Loader Class Initialized
DEBUG - 2011-04-07 01:29:48 --> Controller Class Initialized
DEBUG - 2011-04-07 01:29:48 --> Model Class Initialized
DEBUG - 2011-04-07 01:29:48 --> Model Class Initialized
DEBUG - 2011-04-07 01:29:48 --> Model Class Initialized
DEBUG - 2011-04-07 01:29:48 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-07 01:29:48 --> Database Driver Class Initialized
DEBUG - 2011-04-07 01:29:48 --> File loaded: application/views/table/main.php
DEBUG - 2011-04-07 01:29:48 --> Helper loaded: url_helper
DEBUG - 2011-04-07 01:29:48 --> File loaded: application/views/common/header.php
DEBUG - 2011-04-07 01:29:48 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-04-07 01:29:48 --> File loaded: application/views/common/footer.php
DEBUG - 2011-04-07 01:29:48 --> File loaded: application/views/layout/main.php
DEBUG - 2011-04-07 01:29:48 --> Final output sent to browser
DEBUG - 2011-04-07 01:29:48 --> Total execution time: 0.2020
DEBUG - 2011-04-07 01:29:49 --> Config Class Initialized
DEBUG - 2011-04-07 01:29:49 --> Hooks Class Initialized
DEBUG - 2011-04-07 01:29:49 --> Utf8 Class Initialized
DEBUG - 2011-04-07 01:29:49 --> UTF-8 Support Enabled
DEBUG - 2011-04-07 01:29:49 --> URI Class Initialized
DEBUG - 2011-04-07 01:29:49 --> Router Class Initialized
ERROR - 2011-04-07 01:29:49 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-04-07 01:29:50 --> Config Class Initialized
DEBUG - 2011-04-07 01:29:50 --> Hooks Class Initialized
DEBUG - 2011-04-07 01:29:50 --> Utf8 Class Initialized
DEBUG - 2011-04-07 01:29:50 --> UTF-8 Support Enabled
DEBUG - 2011-04-07 01:29:50 --> URI Class Initialized
DEBUG - 2011-04-07 01:29:50 --> Router Class Initialized
DEBUG - 2011-04-07 01:29:50 --> Output Class Initialized
DEBUG - 2011-04-07 01:29:50 --> Input Class Initialized
DEBUG - 2011-04-07 01:29:50 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-07 01:29:50 --> Language Class Initialized
DEBUG - 2011-04-07 01:29:50 --> Loader Class Initialized
DEBUG - 2011-04-07 01:29:50 --> Controller Class Initialized
DEBUG - 2011-04-07 01:29:50 --> Model Class Initialized
DEBUG - 2011-04-07 01:29:50 --> Model Class Initialized
DEBUG - 2011-04-07 01:29:50 --> Model Class Initialized
DEBUG - 2011-04-07 01:29:50 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-07 01:29:50 --> Database Driver Class Initialized
DEBUG - 2011-04-07 01:29:50 --> File loaded: application/views/table/main.php
DEBUG - 2011-04-07 01:29:50 --> Helper loaded: url_helper
DEBUG - 2011-04-07 01:29:50 --> File loaded: application/views/common/header.php
DEBUG - 2011-04-07 01:29:50 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-04-07 01:29:50 --> File loaded: application/views/common/footer.php
DEBUG - 2011-04-07 01:29:50 --> File loaded: application/views/layout/main.php
DEBUG - 2011-04-07 01:29:50 --> Final output sent to browser
DEBUG - 2011-04-07 01:29:50 --> Total execution time: 0.0416
DEBUG - 2011-04-07 01:29:53 --> Config Class Initialized
DEBUG - 2011-04-07 01:29:53 --> Hooks Class Initialized
DEBUG - 2011-04-07 01:29:53 --> Utf8 Class Initialized
DEBUG - 2011-04-07 01:29:53 --> UTF-8 Support Enabled
DEBUG - 2011-04-07 01:29:53 --> URI Class Initialized
DEBUG - 2011-04-07 01:29:53 --> Router Class Initialized
DEBUG - 2011-04-07 01:29:53 --> Output Class Initialized
DEBUG - 2011-04-07 01:29:53 --> Input Class Initialized
DEBUG - 2011-04-07 01:29:53 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-07 01:29:53 --> Language Class Initialized
DEBUG - 2011-04-07 01:29:53 --> Loader Class Initialized
DEBUG - 2011-04-07 01:29:53 --> Controller Class Initialized
DEBUG - 2011-04-07 01:29:53 --> Model Class Initialized
DEBUG - 2011-04-07 01:29:53 --> Model Class Initialized
DEBUG - 2011-04-07 01:29:53 --> Model Class Initialized
DEBUG - 2011-04-07 01:29:53 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-07 01:29:53 --> Database Driver Class Initialized
DEBUG - 2011-04-07 01:29:53 --> File loaded: application/views/table/main.php
DEBUG - 2011-04-07 01:29:53 --> Helper loaded: url_helper
DEBUG - 2011-04-07 01:29:53 --> File loaded: application/views/common/header.php
DEBUG - 2011-04-07 01:29:53 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-04-07 01:29:53 --> File loaded: application/views/common/footer.php
DEBUG - 2011-04-07 01:29:53 --> File loaded: application/views/layout/main.php
DEBUG - 2011-04-07 01:29:53 --> Final output sent to browser
DEBUG - 2011-04-07 01:29:53 --> Total execution time: 0.2048
DEBUG - 2011-04-07 01:29:54 --> Config Class Initialized
DEBUG - 2011-04-07 01:29:54 --> Hooks Class Initialized
DEBUG - 2011-04-07 01:29:54 --> Utf8 Class Initialized
DEBUG - 2011-04-07 01:29:54 --> UTF-8 Support Enabled
DEBUG - 2011-04-07 01:29:54 --> URI Class Initialized
DEBUG - 2011-04-07 01:29:54 --> Router Class Initialized
ERROR - 2011-04-07 01:29:54 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-04-07 01:29:56 --> Config Class Initialized
DEBUG - 2011-04-07 01:29:56 --> Hooks Class Initialized
DEBUG - 2011-04-07 01:29:56 --> Utf8 Class Initialized
DEBUG - 2011-04-07 01:29:56 --> UTF-8 Support Enabled
DEBUG - 2011-04-07 01:29:56 --> URI Class Initialized
DEBUG - 2011-04-07 01:29:56 --> Router Class Initialized
DEBUG - 2011-04-07 01:29:56 --> Output Class Initialized
DEBUG - 2011-04-07 01:29:56 --> Input Class Initialized
DEBUG - 2011-04-07 01:29:56 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-07 01:29:56 --> Language Class Initialized
DEBUG - 2011-04-07 01:29:56 --> Loader Class Initialized
DEBUG - 2011-04-07 01:29:56 --> Controller Class Initialized
DEBUG - 2011-04-07 01:29:56 --> Model Class Initialized
DEBUG - 2011-04-07 01:29:56 --> Model Class Initialized
DEBUG - 2011-04-07 01:29:56 --> Model Class Initialized
DEBUG - 2011-04-07 01:29:56 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-07 01:29:56 --> Database Driver Class Initialized
DEBUG - 2011-04-07 01:29:56 --> File loaded: application/views/table/main.php
DEBUG - 2011-04-07 01:29:56 --> Helper loaded: url_helper
DEBUG - 2011-04-07 01:29:56 --> File loaded: application/views/common/header.php
DEBUG - 2011-04-07 01:29:56 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-04-07 01:29:56 --> File loaded: application/views/common/footer.php
DEBUG - 2011-04-07 01:29:56 --> File loaded: application/views/layout/main.php
DEBUG - 2011-04-07 01:29:56 --> Final output sent to browser
DEBUG - 2011-04-07 01:29:56 --> Total execution time: 0.0571
DEBUG - 2011-04-07 01:29:57 --> Config Class Initialized
DEBUG - 2011-04-07 01:29:57 --> Hooks Class Initialized
DEBUG - 2011-04-07 01:29:57 --> Utf8 Class Initialized
DEBUG - 2011-04-07 01:29:57 --> UTF-8 Support Enabled
DEBUG - 2011-04-07 01:29:57 --> URI Class Initialized
DEBUG - 2011-04-07 01:29:57 --> Router Class Initialized
DEBUG - 2011-04-07 01:29:57 --> Output Class Initialized
DEBUG - 2011-04-07 01:29:57 --> Input Class Initialized
DEBUG - 2011-04-07 01:29:57 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-07 01:29:57 --> Language Class Initialized
DEBUG - 2011-04-07 01:29:57 --> Loader Class Initialized
DEBUG - 2011-04-07 01:29:57 --> Controller Class Initialized
DEBUG - 2011-04-07 01:29:57 --> Model Class Initialized
DEBUG - 2011-04-07 01:29:57 --> Model Class Initialized
DEBUG - 2011-04-07 01:29:57 --> Model Class Initialized
DEBUG - 2011-04-07 01:29:57 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-07 01:29:57 --> Database Driver Class Initialized
DEBUG - 2011-04-07 01:29:58 --> File loaded: application/views/table/main.php
DEBUG - 2011-04-07 01:29:58 --> Helper loaded: url_helper
DEBUG - 2011-04-07 01:29:58 --> File loaded: application/views/common/header.php
DEBUG - 2011-04-07 01:29:58 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-04-07 01:29:58 --> File loaded: application/views/common/footer.php
DEBUG - 2011-04-07 01:29:58 --> File loaded: application/views/layout/main.php
DEBUG - 2011-04-07 01:29:58 --> Final output sent to browser
DEBUG - 2011-04-07 01:29:58 --> Total execution time: 0.3945
DEBUG - 2011-04-07 01:29:59 --> Config Class Initialized
DEBUG - 2011-04-07 01:29:59 --> Hooks Class Initialized
DEBUG - 2011-04-07 01:29:59 --> Utf8 Class Initialized
DEBUG - 2011-04-07 01:29:59 --> UTF-8 Support Enabled
DEBUG - 2011-04-07 01:29:59 --> URI Class Initialized
DEBUG - 2011-04-07 01:29:59 --> Router Class Initialized
ERROR - 2011-04-07 01:29:59 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-04-07 01:30:00 --> Config Class Initialized
DEBUG - 2011-04-07 01:30:00 --> Hooks Class Initialized
DEBUG - 2011-04-07 01:30:00 --> Utf8 Class Initialized
DEBUG - 2011-04-07 01:30:00 --> UTF-8 Support Enabled
DEBUG - 2011-04-07 01:30:00 --> URI Class Initialized
DEBUG - 2011-04-07 01:30:00 --> Router Class Initialized
DEBUG - 2011-04-07 01:30:00 --> Output Class Initialized
DEBUG - 2011-04-07 01:30:00 --> Input Class Initialized
DEBUG - 2011-04-07 01:30:00 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-07 01:30:00 --> Language Class Initialized
DEBUG - 2011-04-07 01:30:00 --> Loader Class Initialized
DEBUG - 2011-04-07 01:30:00 --> Controller Class Initialized
DEBUG - 2011-04-07 01:30:00 --> Model Class Initialized
DEBUG - 2011-04-07 01:30:00 --> Model Class Initialized
DEBUG - 2011-04-07 01:30:00 --> Model Class Initialized
DEBUG - 2011-04-07 01:30:00 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-07 01:30:00 --> Database Driver Class Initialized
DEBUG - 2011-04-07 01:30:00 --> File loaded: application/views/table/main.php
DEBUG - 2011-04-07 01:30:00 --> Helper loaded: url_helper
DEBUG - 2011-04-07 01:30:00 --> File loaded: application/views/common/header.php
DEBUG - 2011-04-07 01:30:00 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-04-07 01:30:00 --> File loaded: application/views/common/footer.php
DEBUG - 2011-04-07 01:30:00 --> File loaded: application/views/layout/main.php
DEBUG - 2011-04-07 01:30:00 --> Final output sent to browser
DEBUG - 2011-04-07 01:30:00 --> Total execution time: 0.0468
DEBUG - 2011-04-07 01:30:04 --> Config Class Initialized
DEBUG - 2011-04-07 01:30:04 --> Hooks Class Initialized
DEBUG - 2011-04-07 01:30:04 --> Utf8 Class Initialized
DEBUG - 2011-04-07 01:30:04 --> UTF-8 Support Enabled
DEBUG - 2011-04-07 01:30:04 --> URI Class Initialized
DEBUG - 2011-04-07 01:30:04 --> Router Class Initialized
DEBUG - 2011-04-07 01:30:04 --> Output Class Initialized
DEBUG - 2011-04-07 01:30:04 --> Input Class Initialized
DEBUG - 2011-04-07 01:30:04 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-07 01:30:04 --> Language Class Initialized
DEBUG - 2011-04-07 01:30:04 --> Loader Class Initialized
DEBUG - 2011-04-07 01:30:04 --> Controller Class Initialized
DEBUG - 2011-04-07 01:30:04 --> Model Class Initialized
DEBUG - 2011-04-07 01:30:04 --> Model Class Initialized
DEBUG - 2011-04-07 01:30:04 --> Model Class Initialized
DEBUG - 2011-04-07 01:30:04 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-07 01:30:04 --> Database Driver Class Initialized
DEBUG - 2011-04-07 01:30:05 --> File loaded: application/views/table/main.php
DEBUG - 2011-04-07 01:30:05 --> Helper loaded: url_helper
DEBUG - 2011-04-07 01:30:05 --> File loaded: application/views/common/header.php
DEBUG - 2011-04-07 01:30:05 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-04-07 01:30:05 --> File loaded: application/views/common/footer.php
DEBUG - 2011-04-07 01:30:05 --> File loaded: application/views/layout/main.php
DEBUG - 2011-04-07 01:30:05 --> Final output sent to browser
DEBUG - 2011-04-07 01:30:05 --> Total execution time: 1.4338
DEBUG - 2011-04-07 01:30:06 --> Config Class Initialized
DEBUG - 2011-04-07 01:30:06 --> Hooks Class Initialized
DEBUG - 2011-04-07 01:30:06 --> Utf8 Class Initialized
DEBUG - 2011-04-07 01:30:06 --> UTF-8 Support Enabled
DEBUG - 2011-04-07 01:30:06 --> URI Class Initialized
DEBUG - 2011-04-07 01:30:06 --> Router Class Initialized
DEBUG - 2011-04-07 01:30:06 --> Output Class Initialized
DEBUG - 2011-04-07 01:30:06 --> Input Class Initialized
DEBUG - 2011-04-07 01:30:06 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-07 01:30:06 --> Language Class Initialized
DEBUG - 2011-04-07 01:30:06 --> Loader Class Initialized
DEBUG - 2011-04-07 01:30:06 --> Controller Class Initialized
DEBUG - 2011-04-07 01:30:06 --> Model Class Initialized
DEBUG - 2011-04-07 01:30:06 --> Model Class Initialized
DEBUG - 2011-04-07 01:30:06 --> Model Class Initialized
DEBUG - 2011-04-07 01:30:06 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-07 01:30:07 --> Database Driver Class Initialized
DEBUG - 2011-04-07 01:30:07 --> File loaded: application/views/table/main.php
DEBUG - 2011-04-07 01:30:07 --> Helper loaded: url_helper
DEBUG - 2011-04-07 01:30:07 --> File loaded: application/views/common/header.php
DEBUG - 2011-04-07 01:30:07 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-04-07 01:30:07 --> File loaded: application/views/common/footer.php
DEBUG - 2011-04-07 01:30:07 --> File loaded: application/views/layout/main.php
DEBUG - 2011-04-07 01:30:07 --> Final output sent to browser
DEBUG - 2011-04-07 01:30:07 --> Total execution time: 0.3458
DEBUG - 2011-04-07 01:30:07 --> Config Class Initialized
DEBUG - 2011-04-07 01:30:07 --> Hooks Class Initialized
DEBUG - 2011-04-07 01:30:07 --> Utf8 Class Initialized
DEBUG - 2011-04-07 01:30:07 --> UTF-8 Support Enabled
DEBUG - 2011-04-07 01:30:07 --> URI Class Initialized
DEBUG - 2011-04-07 01:30:07 --> Router Class Initialized
ERROR - 2011-04-07 01:30:07 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-04-07 01:30:10 --> Config Class Initialized
DEBUG - 2011-04-07 01:30:10 --> Hooks Class Initialized
DEBUG - 2011-04-07 01:30:10 --> Utf8 Class Initialized
DEBUG - 2011-04-07 01:30:10 --> UTF-8 Support Enabled
DEBUG - 2011-04-07 01:30:10 --> URI Class Initialized
DEBUG - 2011-04-07 01:30:10 --> Router Class Initialized
DEBUG - 2011-04-07 01:30:10 --> Output Class Initialized
DEBUG - 2011-04-07 01:30:10 --> Input Class Initialized
DEBUG - 2011-04-07 01:30:10 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-07 01:30:10 --> Language Class Initialized
DEBUG - 2011-04-07 01:30:10 --> Loader Class Initialized
DEBUG - 2011-04-07 01:30:10 --> Controller Class Initialized
DEBUG - 2011-04-07 01:30:10 --> Model Class Initialized
DEBUG - 2011-04-07 01:30:10 --> Model Class Initialized
DEBUG - 2011-04-07 01:30:10 --> Model Class Initialized
DEBUG - 2011-04-07 01:30:10 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-07 01:30:10 --> Database Driver Class Initialized
DEBUG - 2011-04-07 01:30:11 --> File loaded: application/views/table/main.php
DEBUG - 2011-04-07 01:30:11 --> Helper loaded: url_helper
DEBUG - 2011-04-07 01:30:11 --> File loaded: application/views/common/header.php
DEBUG - 2011-04-07 01:30:11 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-04-07 01:30:11 --> File loaded: application/views/common/footer.php
DEBUG - 2011-04-07 01:30:11 --> File loaded: application/views/layout/main.php
DEBUG - 2011-04-07 01:30:11 --> Final output sent to browser
DEBUG - 2011-04-07 01:30:11 --> Total execution time: 0.7863
DEBUG - 2011-04-07 01:30:12 --> Config Class Initialized
DEBUG - 2011-04-07 01:30:12 --> Hooks Class Initialized
DEBUG - 2011-04-07 01:30:12 --> Utf8 Class Initialized
DEBUG - 2011-04-07 01:30:12 --> UTF-8 Support Enabled
DEBUG - 2011-04-07 01:30:12 --> URI Class Initialized
DEBUG - 2011-04-07 01:30:12 --> Router Class Initialized
DEBUG - 2011-04-07 01:30:12 --> Output Class Initialized
DEBUG - 2011-04-07 01:30:12 --> Input Class Initialized
DEBUG - 2011-04-07 01:30:12 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-07 01:30:12 --> Language Class Initialized
DEBUG - 2011-04-07 01:30:12 --> Loader Class Initialized
DEBUG - 2011-04-07 01:30:12 --> Controller Class Initialized
DEBUG - 2011-04-07 01:30:12 --> Model Class Initialized
DEBUG - 2011-04-07 01:30:12 --> Model Class Initialized
DEBUG - 2011-04-07 01:30:12 --> Model Class Initialized
DEBUG - 2011-04-07 01:30:12 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-07 01:30:12 --> Database Driver Class Initialized
DEBUG - 2011-04-07 01:30:12 --> Config Class Initialized
DEBUG - 2011-04-07 01:30:12 --> Hooks Class Initialized
DEBUG - 2011-04-07 01:30:12 --> Utf8 Class Initialized
DEBUG - 2011-04-07 01:30:12 --> UTF-8 Support Enabled
DEBUG - 2011-04-07 01:30:12 --> URI Class Initialized
DEBUG - 2011-04-07 01:30:12 --> Router Class Initialized
ERROR - 2011-04-07 01:30:12 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-04-07 01:30:12 --> File loaded: application/views/table/main.php
DEBUG - 2011-04-07 01:30:12 --> Helper loaded: url_helper
DEBUG - 2011-04-07 01:30:12 --> File loaded: application/views/common/header.php
DEBUG - 2011-04-07 01:30:12 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-04-07 01:30:12 --> File loaded: application/views/common/footer.php
DEBUG - 2011-04-07 01:30:12 --> File loaded: application/views/layout/main.php
DEBUG - 2011-04-07 01:30:12 --> Final output sent to browser
DEBUG - 2011-04-07 01:30:12 --> Total execution time: 0.1906
DEBUG - 2011-04-07 01:30:16 --> Config Class Initialized
DEBUG - 2011-04-07 01:30:16 --> Hooks Class Initialized
DEBUG - 2011-04-07 01:30:16 --> Utf8 Class Initialized
DEBUG - 2011-04-07 01:30:16 --> UTF-8 Support Enabled
DEBUG - 2011-04-07 01:30:16 --> URI Class Initialized
DEBUG - 2011-04-07 01:30:16 --> Router Class Initialized
DEBUG - 2011-04-07 01:30:16 --> Output Class Initialized
DEBUG - 2011-04-07 01:30:16 --> Input Class Initialized
DEBUG - 2011-04-07 01:30:16 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-07 01:30:16 --> Language Class Initialized
DEBUG - 2011-04-07 01:30:16 --> Loader Class Initialized
DEBUG - 2011-04-07 01:30:16 --> Controller Class Initialized
DEBUG - 2011-04-07 01:30:16 --> Model Class Initialized
DEBUG - 2011-04-07 01:30:16 --> Model Class Initialized
DEBUG - 2011-04-07 01:30:16 --> Model Class Initialized
DEBUG - 2011-04-07 01:30:16 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-07 01:30:16 --> Database Driver Class Initialized
DEBUG - 2011-04-07 01:30:16 --> File loaded: application/views/table/main.php
DEBUG - 2011-04-07 01:30:16 --> Helper loaded: url_helper
DEBUG - 2011-04-07 01:30:16 --> File loaded: application/views/common/header.php
DEBUG - 2011-04-07 01:30:16 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-04-07 01:30:16 --> File loaded: application/views/common/footer.php
DEBUG - 2011-04-07 01:30:16 --> File loaded: application/views/layout/main.php
DEBUG - 2011-04-07 01:30:16 --> Final output sent to browser
DEBUG - 2011-04-07 01:30:16 --> Total execution time: 0.1941
DEBUG - 2011-04-07 01:30:17 --> Config Class Initialized
DEBUG - 2011-04-07 01:30:17 --> Hooks Class Initialized
DEBUG - 2011-04-07 01:30:17 --> Utf8 Class Initialized
DEBUG - 2011-04-07 01:30:17 --> UTF-8 Support Enabled
DEBUG - 2011-04-07 01:30:17 --> URI Class Initialized
DEBUG - 2011-04-07 01:30:17 --> Router Class Initialized
DEBUG - 2011-04-07 01:30:17 --> Output Class Initialized
DEBUG - 2011-04-07 01:30:17 --> Input Class Initialized
DEBUG - 2011-04-07 01:30:17 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-07 01:30:17 --> Language Class Initialized
DEBUG - 2011-04-07 01:30:17 --> Loader Class Initialized
DEBUG - 2011-04-07 01:30:17 --> Controller Class Initialized
DEBUG - 2011-04-07 01:30:17 --> Model Class Initialized
DEBUG - 2011-04-07 01:30:17 --> Model Class Initialized
DEBUG - 2011-04-07 01:30:17 --> Model Class Initialized
DEBUG - 2011-04-07 01:30:17 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-07 01:30:17 --> Database Driver Class Initialized
DEBUG - 2011-04-07 01:30:17 --> File loaded: application/views/table/main.php
DEBUG - 2011-04-07 01:30:17 --> Helper loaded: url_helper
DEBUG - 2011-04-07 01:30:17 --> File loaded: application/views/common/header.php
DEBUG - 2011-04-07 01:30:17 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-04-07 01:30:17 --> File loaded: application/views/common/footer.php
DEBUG - 2011-04-07 01:30:17 --> File loaded: application/views/layout/main.php
DEBUG - 2011-04-07 01:30:17 --> Final output sent to browser
DEBUG - 2011-04-07 01:30:17 --> Total execution time: 0.0566
DEBUG - 2011-04-07 01:30:17 --> Config Class Initialized
DEBUG - 2011-04-07 01:30:17 --> Hooks Class Initialized
DEBUG - 2011-04-07 01:30:17 --> Utf8 Class Initialized
DEBUG - 2011-04-07 01:30:17 --> UTF-8 Support Enabled
DEBUG - 2011-04-07 01:30:17 --> URI Class Initialized
DEBUG - 2011-04-07 01:30:17 --> Router Class Initialized
ERROR - 2011-04-07 01:30:17 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-04-07 01:30:32 --> Config Class Initialized
DEBUG - 2011-04-07 01:30:32 --> Hooks Class Initialized
DEBUG - 2011-04-07 01:30:32 --> Utf8 Class Initialized
DEBUG - 2011-04-07 01:30:32 --> UTF-8 Support Enabled
DEBUG - 2011-04-07 01:30:32 --> URI Class Initialized
DEBUG - 2011-04-07 01:30:32 --> Router Class Initialized
DEBUG - 2011-04-07 01:30:32 --> Output Class Initialized
DEBUG - 2011-04-07 01:30:32 --> Input Class Initialized
DEBUG - 2011-04-07 01:30:32 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-07 01:30:32 --> Language Class Initialized
DEBUG - 2011-04-07 01:30:32 --> Loader Class Initialized
DEBUG - 2011-04-07 01:30:32 --> Controller Class Initialized
DEBUG - 2011-04-07 01:30:32 --> Model Class Initialized
DEBUG - 2011-04-07 01:30:32 --> Model Class Initialized
DEBUG - 2011-04-07 01:30:32 --> Model Class Initialized
DEBUG - 2011-04-07 01:30:32 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-07 01:30:32 --> Database Driver Class Initialized
DEBUG - 2011-04-07 01:30:32 --> File loaded: application/views/table/main.php
DEBUG - 2011-04-07 01:30:32 --> Helper loaded: url_helper
DEBUG - 2011-04-07 01:30:32 --> File loaded: application/views/common/header.php
DEBUG - 2011-04-07 01:30:32 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-04-07 01:30:32 --> File loaded: application/views/common/footer.php
DEBUG - 2011-04-07 01:30:32 --> File loaded: application/views/layout/main.php
DEBUG - 2011-04-07 01:30:32 --> Final output sent to browser
DEBUG - 2011-04-07 01:30:32 --> Total execution time: 0.1928
DEBUG - 2011-04-07 01:30:33 --> Config Class Initialized
DEBUG - 2011-04-07 01:30:33 --> Hooks Class Initialized
DEBUG - 2011-04-07 01:30:33 --> Utf8 Class Initialized
DEBUG - 2011-04-07 01:30:33 --> UTF-8 Support Enabled
DEBUG - 2011-04-07 01:30:33 --> URI Class Initialized
DEBUG - 2011-04-07 01:30:33 --> Router Class Initialized
DEBUG - 2011-04-07 01:30:33 --> Output Class Initialized
DEBUG - 2011-04-07 01:30:33 --> Input Class Initialized
DEBUG - 2011-04-07 01:30:33 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-07 01:30:33 --> Language Class Initialized
DEBUG - 2011-04-07 01:30:33 --> Loader Class Initialized
DEBUG - 2011-04-07 01:30:33 --> Controller Class Initialized
DEBUG - 2011-04-07 01:30:33 --> Model Class Initialized
DEBUG - 2011-04-07 01:30:33 --> Model Class Initialized
DEBUG - 2011-04-07 01:30:33 --> Model Class Initialized
DEBUG - 2011-04-07 01:30:33 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-07 01:30:33 --> Database Driver Class Initialized
DEBUG - 2011-04-07 01:30:33 --> File loaded: application/views/table/main.php
DEBUG - 2011-04-07 01:30:33 --> Helper loaded: url_helper
DEBUG - 2011-04-07 01:30:33 --> File loaded: application/views/common/header.php
DEBUG - 2011-04-07 01:30:33 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-04-07 01:30:33 --> File loaded: application/views/common/footer.php
DEBUG - 2011-04-07 01:30:33 --> File loaded: application/views/layout/main.php
DEBUG - 2011-04-07 01:30:33 --> Final output sent to browser
DEBUG - 2011-04-07 01:30:33 --> Total execution time: 0.0534
DEBUG - 2011-04-07 01:30:33 --> Config Class Initialized
DEBUG - 2011-04-07 01:30:33 --> Hooks Class Initialized
DEBUG - 2011-04-07 01:30:33 --> Utf8 Class Initialized
DEBUG - 2011-04-07 01:30:33 --> UTF-8 Support Enabled
DEBUG - 2011-04-07 01:30:33 --> URI Class Initialized
DEBUG - 2011-04-07 01:30:33 --> Router Class Initialized
ERROR - 2011-04-07 01:30:33 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-04-07 01:35:46 --> Config Class Initialized
DEBUG - 2011-04-07 01:35:46 --> Hooks Class Initialized
DEBUG - 2011-04-07 01:35:46 --> Utf8 Class Initialized
DEBUG - 2011-04-07 01:35:46 --> UTF-8 Support Enabled
DEBUG - 2011-04-07 01:35:46 --> URI Class Initialized
DEBUG - 2011-04-07 01:35:46 --> Router Class Initialized
ERROR - 2011-04-07 01:35:46 --> 404 Page Not Found --> robots.txt
DEBUG - 2011-04-07 01:36:35 --> Config Class Initialized
DEBUG - 2011-04-07 01:36:35 --> Hooks Class Initialized
DEBUG - 2011-04-07 01:36:35 --> Utf8 Class Initialized
DEBUG - 2011-04-07 01:36:35 --> UTF-8 Support Enabled
DEBUG - 2011-04-07 01:36:35 --> URI Class Initialized
DEBUG - 2011-04-07 01:36:35 --> Router Class Initialized
DEBUG - 2011-04-07 01:36:35 --> No URI present. Default controller set.
DEBUG - 2011-04-07 01:36:35 --> Output Class Initialized
DEBUG - 2011-04-07 01:36:35 --> Input Class Initialized
DEBUG - 2011-04-07 01:36:35 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-07 01:36:35 --> Language Class Initialized
DEBUG - 2011-04-07 01:36:35 --> Loader Class Initialized
DEBUG - 2011-04-07 01:36:35 --> Controller Class Initialized
DEBUG - 2011-04-07 01:36:35 --> File loaded: application/views/splash/main.php
DEBUG - 2011-04-07 01:36:35 --> Helper loaded: url_helper
DEBUG - 2011-04-07 01:36:35 --> File loaded: application/views/common/header.php
DEBUG - 2011-04-07 01:36:35 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-04-07 01:36:35 --> File loaded: application/views/common/footer.php
DEBUG - 2011-04-07 01:36:35 --> File loaded: application/views/layout/main.php
DEBUG - 2011-04-07 01:36:35 --> Final output sent to browser
DEBUG - 2011-04-07 01:36:35 --> Total execution time: 0.2205
DEBUG - 2011-04-07 02:17:31 --> Config Class Initialized
DEBUG - 2011-04-07 02:17:31 --> Hooks Class Initialized
DEBUG - 2011-04-07 02:17:32 --> Utf8 Class Initialized
DEBUG - 2011-04-07 02:17:32 --> UTF-8 Support Enabled
DEBUG - 2011-04-07 02:17:32 --> URI Class Initialized
DEBUG - 2011-04-07 02:17:32 --> Router Class Initialized
DEBUG - 2011-04-07 02:17:34 --> Output Class Initialized
DEBUG - 2011-04-07 02:17:34 --> Input Class Initialized
DEBUG - 2011-04-07 02:17:34 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-07 02:17:35 --> Language Class Initialized
DEBUG - 2011-04-07 02:17:35 --> Loader Class Initialized
DEBUG - 2011-04-07 02:17:35 --> Controller Class Initialized
ERROR - 2011-04-07 02:17:35 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-04-07 02:17:35 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-04-07 02:17:35 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-04-07 02:17:36 --> Model Class Initialized
DEBUG - 2011-04-07 02:17:36 --> Model Class Initialized
DEBUG - 2011-04-07 02:17:36 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-07 02:17:36 --> Database Driver Class Initialized
DEBUG - 2011-04-07 02:17:36 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-04-07 02:17:37 --> Helper loaded: url_helper
DEBUG - 2011-04-07 02:17:37 --> File loaded: application/views/common/header.php
DEBUG - 2011-04-07 02:17:37 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-04-07 02:17:37 --> File loaded: application/views/common/footer.php
DEBUG - 2011-04-07 02:17:37 --> File loaded: application/views/layout/main.php
DEBUG - 2011-04-07 02:17:37 --> Final output sent to browser
DEBUG - 2011-04-07 02:17:37 --> Total execution time: 7.6493
DEBUG - 2011-04-07 02:17:42 --> Config Class Initialized
DEBUG - 2011-04-07 02:17:42 --> Hooks Class Initialized
DEBUG - 2011-04-07 02:17:42 --> Utf8 Class Initialized
DEBUG - 2011-04-07 02:17:42 --> UTF-8 Support Enabled
DEBUG - 2011-04-07 02:17:42 --> URI Class Initialized
DEBUG - 2011-04-07 02:17:42 --> Router Class Initialized
ERROR - 2011-04-07 02:17:42 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-04-07 02:17:46 --> Config Class Initialized
DEBUG - 2011-04-07 02:17:46 --> Hooks Class Initialized
DEBUG - 2011-04-07 02:17:46 --> Utf8 Class Initialized
DEBUG - 2011-04-07 02:17:46 --> UTF-8 Support Enabled
DEBUG - 2011-04-07 02:17:46 --> URI Class Initialized
DEBUG - 2011-04-07 02:17:46 --> Router Class Initialized
ERROR - 2011-04-07 02:17:46 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-04-07 03:58:03 --> Config Class Initialized
DEBUG - 2011-04-07 03:58:03 --> Hooks Class Initialized
DEBUG - 2011-04-07 03:58:03 --> Utf8 Class Initialized
DEBUG - 2011-04-07 03:58:03 --> UTF-8 Support Enabled
DEBUG - 2011-04-07 03:58:03 --> URI Class Initialized
DEBUG - 2011-04-07 03:58:03 --> Router Class Initialized
DEBUG - 2011-04-07 03:58:03 --> No URI present. Default controller set.
DEBUG - 2011-04-07 03:58:03 --> Output Class Initialized
DEBUG - 2011-04-07 03:58:03 --> Input Class Initialized
DEBUG - 2011-04-07 03:58:03 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-07 03:58:03 --> Language Class Initialized
DEBUG - 2011-04-07 03:58:03 --> Loader Class Initialized
DEBUG - 2011-04-07 03:58:03 --> Controller Class Initialized
DEBUG - 2011-04-07 03:58:03 --> File loaded: application/views/splash/main.php
DEBUG - 2011-04-07 03:58:03 --> Helper loaded: url_helper
DEBUG - 2011-04-07 03:58:03 --> File loaded: application/views/common/header.php
DEBUG - 2011-04-07 03:58:03 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-04-07 03:58:03 --> File loaded: application/views/common/footer.php
DEBUG - 2011-04-07 03:58:03 --> File loaded: application/views/layout/main.php
DEBUG - 2011-04-07 03:58:03 --> Final output sent to browser
DEBUG - 2011-04-07 03:58:03 --> Total execution time: 0.1312
DEBUG - 2011-04-07 03:58:09 --> Config Class Initialized
DEBUG - 2011-04-07 03:58:09 --> Hooks Class Initialized
DEBUG - 2011-04-07 03:58:09 --> Utf8 Class Initialized
DEBUG - 2011-04-07 03:58:09 --> UTF-8 Support Enabled
DEBUG - 2011-04-07 03:58:09 --> URI Class Initialized
DEBUG - 2011-04-07 03:58:09 --> Router Class Initialized
ERROR - 2011-04-07 03:58:09 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-04-07 04:03:15 --> Config Class Initialized
DEBUG - 2011-04-07 04:03:15 --> Hooks Class Initialized
DEBUG - 2011-04-07 04:03:15 --> Utf8 Class Initialized
DEBUG - 2011-04-07 04:03:15 --> UTF-8 Support Enabled
DEBUG - 2011-04-07 04:03:15 --> URI Class Initialized
DEBUG - 2011-04-07 04:03:15 --> Router Class Initialized
ERROR - 2011-04-07 04:03:15 --> 404 Page Not Found --> robots.txt
DEBUG - 2011-04-07 04:04:20 --> Config Class Initialized
DEBUG - 2011-04-07 04:04:20 --> Hooks Class Initialized
DEBUG - 2011-04-07 04:04:20 --> Utf8 Class Initialized
DEBUG - 2011-04-07 04:04:20 --> UTF-8 Support Enabled
DEBUG - 2011-04-07 04:04:20 --> URI Class Initialized
DEBUG - 2011-04-07 04:04:20 --> Router Class Initialized
DEBUG - 2011-04-07 04:04:20 --> Output Class Initialized
DEBUG - 2011-04-07 04:04:21 --> Input Class Initialized
DEBUG - 2011-04-07 04:04:21 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-07 04:04:21 --> Language Class Initialized
DEBUG - 2011-04-07 04:04:21 --> Loader Class Initialized
DEBUG - 2011-04-07 04:04:21 --> Controller Class Initialized
DEBUG - 2011-04-07 04:04:21 --> Model Class Initialized
DEBUG - 2011-04-07 04:04:21 --> Model Class Initialized
DEBUG - 2011-04-07 04:04:21 --> Model Class Initialized
DEBUG - 2011-04-07 04:04:22 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-07 04:04:22 --> Database Driver Class Initialized
DEBUG - 2011-04-07 04:04:36 --> File loaded: application/views/table/main.php
DEBUG - 2011-04-07 04:04:36 --> Helper loaded: url_helper
DEBUG - 2011-04-07 04:04:36 --> File loaded: application/views/common/header.php
DEBUG - 2011-04-07 04:04:36 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-04-07 04:04:36 --> File loaded: application/views/common/footer.php
DEBUG - 2011-04-07 04:04:36 --> File loaded: application/views/layout/main.php
DEBUG - 2011-04-07 04:04:36 --> Final output sent to browser
DEBUG - 2011-04-07 04:04:36 --> Total execution time: 16.3687
DEBUG - 2011-04-07 04:05:20 --> Config Class Initialized
DEBUG - 2011-04-07 04:05:20 --> Hooks Class Initialized
DEBUG - 2011-04-07 04:05:20 --> Utf8 Class Initialized
DEBUG - 2011-04-07 04:05:20 --> UTF-8 Support Enabled
DEBUG - 2011-04-07 04:05:20 --> URI Class Initialized
DEBUG - 2011-04-07 04:05:20 --> Router Class Initialized
DEBUG - 2011-04-07 04:05:20 --> Output Class Initialized
DEBUG - 2011-04-07 04:05:20 --> Input Class Initialized
DEBUG - 2011-04-07 04:05:20 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-07 04:05:20 --> Language Class Initialized
DEBUG - 2011-04-07 04:05:20 --> Loader Class Initialized
DEBUG - 2011-04-07 04:05:20 --> Controller Class Initialized
ERROR - 2011-04-07 04:05:20 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-04-07 04:05:20 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-04-07 04:05:20 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-04-07 04:05:20 --> Model Class Initialized
DEBUG - 2011-04-07 04:05:20 --> Model Class Initialized
DEBUG - 2011-04-07 04:05:20 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-07 04:05:20 --> Database Driver Class Initialized
DEBUG - 2011-04-07 04:05:20 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-04-07 04:05:20 --> Helper loaded: url_helper
DEBUG - 2011-04-07 04:05:20 --> File loaded: application/views/common/header.php
DEBUG - 2011-04-07 04:05:20 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-04-07 04:05:20 --> File loaded: application/views/common/footer.php
DEBUG - 2011-04-07 04:05:20 --> File loaded: application/views/layout/main.php
DEBUG - 2011-04-07 04:05:20 --> Final output sent to browser
DEBUG - 2011-04-07 04:05:20 --> Total execution time: 0.1921
DEBUG - 2011-04-07 04:06:28 --> Config Class Initialized
DEBUG - 2011-04-07 04:06:28 --> Hooks Class Initialized
DEBUG - 2011-04-07 04:06:28 --> Utf8 Class Initialized
DEBUG - 2011-04-07 04:06:28 --> UTF-8 Support Enabled
DEBUG - 2011-04-07 04:06:28 --> URI Class Initialized
DEBUG - 2011-04-07 04:06:28 --> Router Class Initialized
DEBUG - 2011-04-07 04:06:28 --> No URI present. Default controller set.
DEBUG - 2011-04-07 04:06:28 --> Output Class Initialized
DEBUG - 2011-04-07 04:06:28 --> Input Class Initialized
DEBUG - 2011-04-07 04:06:28 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-07 04:06:28 --> Language Class Initialized
DEBUG - 2011-04-07 04:06:29 --> Loader Class Initialized
DEBUG - 2011-04-07 04:06:29 --> Controller Class Initialized
DEBUG - 2011-04-07 04:06:29 --> File loaded: application/views/splash/main.php
DEBUG - 2011-04-07 04:06:30 --> Helper loaded: url_helper
DEBUG - 2011-04-07 04:06:30 --> File loaded: application/views/common/header.php
DEBUG - 2011-04-07 04:06:30 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-04-07 04:06:30 --> File loaded: application/views/common/footer.php
DEBUG - 2011-04-07 04:06:30 --> File loaded: application/views/layout/main.php
DEBUG - 2011-04-07 04:06:30 --> Final output sent to browser
DEBUG - 2011-04-07 04:06:30 --> Total execution time: 2.7520
DEBUG - 2011-04-07 04:56:38 --> Config Class Initialized
DEBUG - 2011-04-07 04:56:38 --> Hooks Class Initialized
DEBUG - 2011-04-07 04:56:38 --> Utf8 Class Initialized
DEBUG - 2011-04-07 04:56:38 --> UTF-8 Support Enabled
DEBUG - 2011-04-07 04:56:38 --> URI Class Initialized
DEBUG - 2011-04-07 04:56:38 --> Router Class Initialized
DEBUG - 2011-04-07 04:56:38 --> No URI present. Default controller set.
DEBUG - 2011-04-07 04:56:38 --> Output Class Initialized
DEBUG - 2011-04-07 04:56:38 --> Input Class Initialized
DEBUG - 2011-04-07 04:56:38 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-07 04:56:38 --> Language Class Initialized
DEBUG - 2011-04-07 04:56:38 --> Loader Class Initialized
DEBUG - 2011-04-07 04:56:38 --> Controller Class Initialized
DEBUG - 2011-04-07 04:56:38 --> File loaded: application/views/splash/main.php
DEBUG - 2011-04-07 04:56:38 --> Helper loaded: url_helper
DEBUG - 2011-04-07 04:56:38 --> File loaded: application/views/common/header.php
DEBUG - 2011-04-07 04:56:38 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-04-07 04:56:38 --> File loaded: application/views/common/footer.php
DEBUG - 2011-04-07 04:56:38 --> File loaded: application/views/layout/main.php
DEBUG - 2011-04-07 04:56:38 --> Final output sent to browser
DEBUG - 2011-04-07 04:56:38 --> Total execution time: 0.2603
DEBUG - 2011-04-07 04:56:39 --> Config Class Initialized
DEBUG - 2011-04-07 04:56:39 --> Hooks Class Initialized
DEBUG - 2011-04-07 04:56:39 --> Utf8 Class Initialized
DEBUG - 2011-04-07 04:56:39 --> UTF-8 Support Enabled
DEBUG - 2011-04-07 04:56:39 --> URI Class Initialized
DEBUG - 2011-04-07 04:56:39 --> Router Class Initialized
ERROR - 2011-04-07 04:56:39 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-04-07 04:56:42 --> Config Class Initialized
DEBUG - 2011-04-07 04:56:42 --> Hooks Class Initialized
DEBUG - 2011-04-07 04:56:42 --> Utf8 Class Initialized
DEBUG - 2011-04-07 04:56:42 --> UTF-8 Support Enabled
DEBUG - 2011-04-07 04:56:42 --> URI Class Initialized
DEBUG - 2011-04-07 04:56:42 --> Router Class Initialized
ERROR - 2011-04-07 04:56:42 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-04-07 04:58:53 --> Config Class Initialized
DEBUG - 2011-04-07 04:58:53 --> Hooks Class Initialized
DEBUG - 2011-04-07 04:58:53 --> Utf8 Class Initialized
DEBUG - 2011-04-07 04:58:53 --> UTF-8 Support Enabled
DEBUG - 2011-04-07 04:58:53 --> URI Class Initialized
DEBUG - 2011-04-07 04:58:53 --> Router Class Initialized
DEBUG - 2011-04-07 04:58:53 --> Output Class Initialized
DEBUG - 2011-04-07 04:58:53 --> Input Class Initialized
DEBUG - 2011-04-07 04:58:53 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-07 04:58:53 --> Language Class Initialized
DEBUG - 2011-04-07 04:58:53 --> Loader Class Initialized
DEBUG - 2011-04-07 04:58:53 --> Controller Class Initialized
ERROR - 2011-04-07 04:58:53 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-04-07 04:58:53 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-04-07 04:58:53 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-04-07 04:58:53 --> Model Class Initialized
DEBUG - 2011-04-07 04:58:53 --> Model Class Initialized
DEBUG - 2011-04-07 04:58:53 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-07 04:58:53 --> Database Driver Class Initialized
DEBUG - 2011-04-07 04:58:53 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-04-07 04:58:53 --> Helper loaded: url_helper
DEBUG - 2011-04-07 04:58:53 --> File loaded: application/views/common/header.php
DEBUG - 2011-04-07 04:58:53 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-04-07 04:58:53 --> File loaded: application/views/common/footer.php
DEBUG - 2011-04-07 04:58:53 --> File loaded: application/views/layout/main.php
DEBUG - 2011-04-07 04:58:53 --> Final output sent to browser
DEBUG - 2011-04-07 04:58:53 --> Total execution time: 0.5334
DEBUG - 2011-04-07 04:58:54 --> Config Class Initialized
DEBUG - 2011-04-07 04:58:54 --> Hooks Class Initialized
DEBUG - 2011-04-07 04:58:54 --> Utf8 Class Initialized
DEBUG - 2011-04-07 04:58:54 --> UTF-8 Support Enabled
DEBUG - 2011-04-07 04:58:54 --> URI Class Initialized
DEBUG - 2011-04-07 04:58:54 --> Router Class Initialized
DEBUG - 2011-04-07 04:58:54 --> Output Class Initialized
DEBUG - 2011-04-07 04:58:54 --> Input Class Initialized
DEBUG - 2011-04-07 04:58:54 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-07 04:58:54 --> Language Class Initialized
DEBUG - 2011-04-07 04:58:54 --> Loader Class Initialized
DEBUG - 2011-04-07 04:58:54 --> Controller Class Initialized
DEBUG - 2011-04-07 04:58:54 --> Model Class Initialized
DEBUG - 2011-04-07 04:58:54 --> Model Class Initialized
DEBUG - 2011-04-07 04:58:54 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-07 04:58:54 --> Database Driver Class Initialized
DEBUG - 2011-04-07 04:58:56 --> Final output sent to browser
DEBUG - 2011-04-07 04:58:56 --> Total execution time: 2.1974
DEBUG - 2011-04-07 04:59:12 --> Config Class Initialized
DEBUG - 2011-04-07 04:59:12 --> Hooks Class Initialized
DEBUG - 2011-04-07 04:59:12 --> Utf8 Class Initialized
DEBUG - 2011-04-07 04:59:12 --> UTF-8 Support Enabled
DEBUG - 2011-04-07 04:59:12 --> URI Class Initialized
DEBUG - 2011-04-07 04:59:12 --> Router Class Initialized
DEBUG - 2011-04-07 04:59:12 --> Output Class Initialized
DEBUG - 2011-04-07 04:59:12 --> Input Class Initialized
DEBUG - 2011-04-07 04:59:12 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-07 04:59:12 --> Language Class Initialized
DEBUG - 2011-04-07 04:59:13 --> Loader Class Initialized
DEBUG - 2011-04-07 04:59:13 --> Controller Class Initialized
ERROR - 2011-04-07 04:59:13 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-04-07 04:59:13 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-04-07 04:59:13 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-04-07 04:59:13 --> Model Class Initialized
DEBUG - 2011-04-07 04:59:13 --> Model Class Initialized
DEBUG - 2011-04-07 04:59:13 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-07 04:59:13 --> Database Driver Class Initialized
DEBUG - 2011-04-07 04:59:13 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-04-07 04:59:13 --> Helper loaded: url_helper
DEBUG - 2011-04-07 04:59:13 --> File loaded: application/views/common/header.php
DEBUG - 2011-04-07 04:59:13 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-04-07 04:59:13 --> File loaded: application/views/common/footer.php
DEBUG - 2011-04-07 04:59:13 --> File loaded: application/views/layout/main.php
DEBUG - 2011-04-07 04:59:13 --> Final output sent to browser
DEBUG - 2011-04-07 04:59:13 --> Total execution time: 0.0464
DEBUG - 2011-04-07 04:59:14 --> Config Class Initialized
DEBUG - 2011-04-07 04:59:14 --> Hooks Class Initialized
DEBUG - 2011-04-07 04:59:14 --> Utf8 Class Initialized
DEBUG - 2011-04-07 04:59:14 --> UTF-8 Support Enabled
DEBUG - 2011-04-07 04:59:14 --> URI Class Initialized
DEBUG - 2011-04-07 04:59:14 --> Router Class Initialized
DEBUG - 2011-04-07 04:59:14 --> Output Class Initialized
DEBUG - 2011-04-07 04:59:14 --> Input Class Initialized
DEBUG - 2011-04-07 04:59:14 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-07 04:59:14 --> Language Class Initialized
DEBUG - 2011-04-07 04:59:14 --> Loader Class Initialized
DEBUG - 2011-04-07 04:59:14 --> Controller Class Initialized
DEBUG - 2011-04-07 04:59:14 --> Model Class Initialized
DEBUG - 2011-04-07 04:59:14 --> Model Class Initialized
DEBUG - 2011-04-07 04:59:14 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-07 04:59:14 --> Database Driver Class Initialized
DEBUG - 2011-04-07 04:59:14 --> Final output sent to browser
DEBUG - 2011-04-07 04:59:14 --> Total execution time: 0.8371
DEBUG - 2011-04-07 04:59:33 --> Config Class Initialized
DEBUG - 2011-04-07 04:59:33 --> Hooks Class Initialized
DEBUG - 2011-04-07 04:59:33 --> Utf8 Class Initialized
DEBUG - 2011-04-07 04:59:33 --> UTF-8 Support Enabled
DEBUG - 2011-04-07 04:59:33 --> URI Class Initialized
DEBUG - 2011-04-07 04:59:33 --> Router Class Initialized
DEBUG - 2011-04-07 04:59:33 --> Output Class Initialized
DEBUG - 2011-04-07 04:59:33 --> Input Class Initialized
DEBUG - 2011-04-07 04:59:33 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-07 04:59:33 --> Language Class Initialized
DEBUG - 2011-04-07 04:59:33 --> Loader Class Initialized
DEBUG - 2011-04-07 04:59:33 --> Controller Class Initialized
ERROR - 2011-04-07 04:59:33 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-04-07 04:59:33 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-04-07 04:59:33 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-04-07 04:59:33 --> Model Class Initialized
DEBUG - 2011-04-07 04:59:33 --> Model Class Initialized
DEBUG - 2011-04-07 04:59:33 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-07 04:59:33 --> Database Driver Class Initialized
DEBUG - 2011-04-07 04:59:33 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-04-07 04:59:33 --> Helper loaded: url_helper
DEBUG - 2011-04-07 04:59:33 --> File loaded: application/views/common/header.php
DEBUG - 2011-04-07 04:59:33 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-04-07 04:59:33 --> File loaded: application/views/common/footer.php
DEBUG - 2011-04-07 04:59:33 --> File loaded: application/views/layout/main.php
DEBUG - 2011-04-07 04:59:33 --> Final output sent to browser
DEBUG - 2011-04-07 04:59:33 --> Total execution time: 0.0291
DEBUG - 2011-04-07 04:59:35 --> Config Class Initialized
DEBUG - 2011-04-07 04:59:35 --> Hooks Class Initialized
DEBUG - 2011-04-07 04:59:35 --> Utf8 Class Initialized
DEBUG - 2011-04-07 04:59:35 --> UTF-8 Support Enabled
DEBUG - 2011-04-07 04:59:35 --> URI Class Initialized
DEBUG - 2011-04-07 04:59:35 --> Router Class Initialized
DEBUG - 2011-04-07 04:59:35 --> Output Class Initialized
DEBUG - 2011-04-07 04:59:35 --> Input Class Initialized
DEBUG - 2011-04-07 04:59:35 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-07 04:59:35 --> Language Class Initialized
DEBUG - 2011-04-07 04:59:35 --> Loader Class Initialized
DEBUG - 2011-04-07 04:59:35 --> Controller Class Initialized
DEBUG - 2011-04-07 04:59:35 --> Model Class Initialized
DEBUG - 2011-04-07 04:59:35 --> Model Class Initialized
DEBUG - 2011-04-07 04:59:35 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-07 04:59:35 --> Database Driver Class Initialized
DEBUG - 2011-04-07 04:59:40 --> Final output sent to browser
DEBUG - 2011-04-07 04:59:40 --> Total execution time: 4.7759
DEBUG - 2011-04-07 04:59:49 --> Config Class Initialized
DEBUG - 2011-04-07 04:59:49 --> Hooks Class Initialized
DEBUG - 2011-04-07 04:59:49 --> Utf8 Class Initialized
DEBUG - 2011-04-07 04:59:49 --> UTF-8 Support Enabled
DEBUG - 2011-04-07 04:59:49 --> URI Class Initialized
DEBUG - 2011-04-07 04:59:49 --> Router Class Initialized
DEBUG - 2011-04-07 04:59:49 --> Output Class Initialized
DEBUG - 2011-04-07 04:59:49 --> Input Class Initialized
DEBUG - 2011-04-07 04:59:49 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-07 04:59:49 --> Language Class Initialized
DEBUG - 2011-04-07 04:59:49 --> Loader Class Initialized
DEBUG - 2011-04-07 04:59:49 --> Controller Class Initialized
ERROR - 2011-04-07 04:59:49 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-04-07 04:59:49 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-04-07 04:59:49 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-04-07 04:59:49 --> Model Class Initialized
DEBUG - 2011-04-07 04:59:49 --> Model Class Initialized
DEBUG - 2011-04-07 04:59:49 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-07 04:59:49 --> Database Driver Class Initialized
DEBUG - 2011-04-07 04:59:49 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-04-07 04:59:49 --> Helper loaded: url_helper
DEBUG - 2011-04-07 04:59:49 --> File loaded: application/views/common/header.php
DEBUG - 2011-04-07 04:59:49 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-04-07 04:59:49 --> File loaded: application/views/common/footer.php
DEBUG - 2011-04-07 04:59:49 --> File loaded: application/views/layout/main.php
DEBUG - 2011-04-07 04:59:49 --> Final output sent to browser
DEBUG - 2011-04-07 04:59:49 --> Total execution time: 0.0727
DEBUG - 2011-04-07 04:59:49 --> Config Class Initialized
DEBUG - 2011-04-07 04:59:49 --> Hooks Class Initialized
DEBUG - 2011-04-07 04:59:49 --> Utf8 Class Initialized
DEBUG - 2011-04-07 04:59:49 --> UTF-8 Support Enabled
DEBUG - 2011-04-07 04:59:49 --> URI Class Initialized
DEBUG - 2011-04-07 04:59:49 --> Router Class Initialized
DEBUG - 2011-04-07 04:59:49 --> Output Class Initialized
DEBUG - 2011-04-07 04:59:49 --> Input Class Initialized
DEBUG - 2011-04-07 04:59:49 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-07 04:59:49 --> Language Class Initialized
DEBUG - 2011-04-07 04:59:49 --> Loader Class Initialized
DEBUG - 2011-04-07 04:59:49 --> Controller Class Initialized
DEBUG - 2011-04-07 04:59:49 --> Model Class Initialized
DEBUG - 2011-04-07 04:59:49 --> Model Class Initialized
DEBUG - 2011-04-07 04:59:49 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-07 04:59:49 --> Database Driver Class Initialized
DEBUG - 2011-04-07 04:59:52 --> Final output sent to browser
DEBUG - 2011-04-07 04:59:52 --> Total execution time: 2.6196
DEBUG - 2011-04-07 05:00:07 --> Config Class Initialized
DEBUG - 2011-04-07 05:00:07 --> Hooks Class Initialized
DEBUG - 2011-04-07 05:00:07 --> Utf8 Class Initialized
DEBUG - 2011-04-07 05:00:07 --> UTF-8 Support Enabled
DEBUG - 2011-04-07 05:00:07 --> URI Class Initialized
DEBUG - 2011-04-07 05:00:07 --> Router Class Initialized
DEBUG - 2011-04-07 05:00:07 --> Output Class Initialized
DEBUG - 2011-04-07 05:00:07 --> Input Class Initialized
DEBUG - 2011-04-07 05:00:07 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-07 05:00:07 --> Language Class Initialized
DEBUG - 2011-04-07 05:00:07 --> Loader Class Initialized
DEBUG - 2011-04-07 05:00:07 --> Controller Class Initialized
ERROR - 2011-04-07 05:00:07 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-04-07 05:00:07 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-04-07 05:00:07 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-04-07 05:00:07 --> Model Class Initialized
DEBUG - 2011-04-07 05:00:07 --> Model Class Initialized
DEBUG - 2011-04-07 05:00:07 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-07 05:00:07 --> Database Driver Class Initialized
DEBUG - 2011-04-07 05:00:07 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-04-07 05:00:07 --> Helper loaded: url_helper
DEBUG - 2011-04-07 05:00:07 --> File loaded: application/views/common/header.php
DEBUG - 2011-04-07 05:00:07 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-04-07 05:00:07 --> File loaded: application/views/common/footer.php
DEBUG - 2011-04-07 05:00:07 --> File loaded: application/views/layout/main.php
DEBUG - 2011-04-07 05:00:07 --> Final output sent to browser
DEBUG - 2011-04-07 05:00:07 --> Total execution time: 0.1090
DEBUG - 2011-04-07 05:00:08 --> Config Class Initialized
DEBUG - 2011-04-07 05:00:08 --> Hooks Class Initialized
DEBUG - 2011-04-07 05:00:08 --> Utf8 Class Initialized
DEBUG - 2011-04-07 05:00:08 --> UTF-8 Support Enabled
DEBUG - 2011-04-07 05:00:08 --> URI Class Initialized
DEBUG - 2011-04-07 05:00:08 --> Router Class Initialized
DEBUG - 2011-04-07 05:00:08 --> Output Class Initialized
DEBUG - 2011-04-07 05:00:08 --> Input Class Initialized
DEBUG - 2011-04-07 05:00:08 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-07 05:00:08 --> Language Class Initialized
DEBUG - 2011-04-07 05:00:08 --> Loader Class Initialized
DEBUG - 2011-04-07 05:00:08 --> Controller Class Initialized
DEBUG - 2011-04-07 05:00:08 --> Model Class Initialized
DEBUG - 2011-04-07 05:00:08 --> Model Class Initialized
DEBUG - 2011-04-07 05:00:08 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-07 05:00:08 --> Database Driver Class Initialized
DEBUG - 2011-04-07 05:00:09 --> Final output sent to browser
DEBUG - 2011-04-07 05:00:09 --> Total execution time: 0.7661
DEBUG - 2011-04-07 05:00:13 --> Config Class Initialized
DEBUG - 2011-04-07 05:00:13 --> Hooks Class Initialized
DEBUG - 2011-04-07 05:00:13 --> Utf8 Class Initialized
DEBUG - 2011-04-07 05:00:13 --> UTF-8 Support Enabled
DEBUG - 2011-04-07 05:00:13 --> URI Class Initialized
DEBUG - 2011-04-07 05:00:13 --> Router Class Initialized
DEBUG - 2011-04-07 05:00:13 --> Output Class Initialized
DEBUG - 2011-04-07 05:00:13 --> Input Class Initialized
DEBUG - 2011-04-07 05:00:13 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-07 05:00:13 --> Language Class Initialized
DEBUG - 2011-04-07 05:00:13 --> Loader Class Initialized
DEBUG - 2011-04-07 05:00:13 --> Controller Class Initialized
ERROR - 2011-04-07 05:00:13 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-04-07 05:00:13 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-04-07 05:00:13 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-04-07 05:00:13 --> Model Class Initialized
DEBUG - 2011-04-07 05:00:13 --> Model Class Initialized
DEBUG - 2011-04-07 05:00:13 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-07 05:00:13 --> Database Driver Class Initialized
DEBUG - 2011-04-07 05:00:13 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-04-07 05:00:13 --> Helper loaded: url_helper
DEBUG - 2011-04-07 05:00:13 --> File loaded: application/views/common/header.php
DEBUG - 2011-04-07 05:00:13 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-04-07 05:00:13 --> File loaded: application/views/common/footer.php
DEBUG - 2011-04-07 05:00:13 --> File loaded: application/views/layout/main.php
DEBUG - 2011-04-07 05:00:13 --> Final output sent to browser
DEBUG - 2011-04-07 05:00:13 --> Total execution time: 0.0351
DEBUG - 2011-04-07 05:00:14 --> Config Class Initialized
DEBUG - 2011-04-07 05:00:14 --> Hooks Class Initialized
DEBUG - 2011-04-07 05:00:14 --> Utf8 Class Initialized
DEBUG - 2011-04-07 05:00:14 --> UTF-8 Support Enabled
DEBUG - 2011-04-07 05:00:14 --> URI Class Initialized
DEBUG - 2011-04-07 05:00:14 --> Router Class Initialized
DEBUG - 2011-04-07 05:00:14 --> Output Class Initialized
DEBUG - 2011-04-07 05:00:14 --> Input Class Initialized
DEBUG - 2011-04-07 05:00:14 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-07 05:00:14 --> Language Class Initialized
DEBUG - 2011-04-07 05:00:14 --> Loader Class Initialized
DEBUG - 2011-04-07 05:00:14 --> Controller Class Initialized
DEBUG - 2011-04-07 05:00:14 --> Model Class Initialized
DEBUG - 2011-04-07 05:00:14 --> Model Class Initialized
DEBUG - 2011-04-07 05:00:14 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-07 05:00:14 --> Database Driver Class Initialized
DEBUG - 2011-04-07 05:00:20 --> Final output sent to browser
DEBUG - 2011-04-07 05:00:20 --> Total execution time: 5.8373
DEBUG - 2011-04-07 05:14:32 --> Config Class Initialized
DEBUG - 2011-04-07 05:14:32 --> Hooks Class Initialized
DEBUG - 2011-04-07 05:14:32 --> Utf8 Class Initialized
DEBUG - 2011-04-07 05:14:32 --> UTF-8 Support Enabled
DEBUG - 2011-04-07 05:14:32 --> URI Class Initialized
DEBUG - 2011-04-07 05:14:32 --> Router Class Initialized
DEBUG - 2011-04-07 05:14:32 --> Output Class Initialized
DEBUG - 2011-04-07 05:14:32 --> Input Class Initialized
DEBUG - 2011-04-07 05:14:32 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-07 05:14:32 --> Language Class Initialized
DEBUG - 2011-04-07 05:14:32 --> Loader Class Initialized
DEBUG - 2011-04-07 05:14:32 --> Controller Class Initialized
DEBUG - 2011-04-07 05:14:32 --> Model Class Initialized
DEBUG - 2011-04-07 05:14:32 --> Model Class Initialized
DEBUG - 2011-04-07 05:14:32 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-07 05:14:32 --> Database Driver Class Initialized
DEBUG - 2011-04-07 05:14:37 --> Final output sent to browser
DEBUG - 2011-04-07 05:14:37 --> Total execution time: 4.7867
DEBUG - 2011-04-07 05:20:43 --> Config Class Initialized
DEBUG - 2011-04-07 05:20:43 --> Hooks Class Initialized
DEBUG - 2011-04-07 05:20:43 --> Utf8 Class Initialized
DEBUG - 2011-04-07 05:20:43 --> UTF-8 Support Enabled
DEBUG - 2011-04-07 05:20:43 --> URI Class Initialized
DEBUG - 2011-04-07 05:20:43 --> Router Class Initialized
ERROR - 2011-04-07 05:20:43 --> 404 Page Not Found --> robots.txt
DEBUG - 2011-04-07 05:20:44 --> Config Class Initialized
DEBUG - 2011-04-07 05:20:44 --> Hooks Class Initialized
DEBUG - 2011-04-07 05:20:44 --> Utf8 Class Initialized
DEBUG - 2011-04-07 05:20:44 --> UTF-8 Support Enabled
DEBUG - 2011-04-07 05:20:44 --> URI Class Initialized
DEBUG - 2011-04-07 05:20:44 --> Router Class Initialized
DEBUG - 2011-04-07 05:20:44 --> No URI present. Default controller set.
DEBUG - 2011-04-07 05:20:44 --> Output Class Initialized
DEBUG - 2011-04-07 05:20:44 --> Input Class Initialized
DEBUG - 2011-04-07 05:20:44 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-07 05:20:44 --> Language Class Initialized
DEBUG - 2011-04-07 05:20:44 --> Loader Class Initialized
DEBUG - 2011-04-07 05:20:44 --> Controller Class Initialized
DEBUG - 2011-04-07 05:20:45 --> File loaded: application/views/splash/main.php
DEBUG - 2011-04-07 05:20:45 --> Helper loaded: url_helper
DEBUG - 2011-04-07 05:20:45 --> File loaded: application/views/common/header.php
DEBUG - 2011-04-07 05:20:45 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-04-07 05:20:45 --> File loaded: application/views/common/footer.php
DEBUG - 2011-04-07 05:20:45 --> File loaded: application/views/layout/main.php
DEBUG - 2011-04-07 05:20:45 --> Final output sent to browser
DEBUG - 2011-04-07 05:20:45 --> Total execution time: 0.2185
DEBUG - 2011-04-07 05:39:24 --> Config Class Initialized
DEBUG - 2011-04-07 05:39:24 --> Hooks Class Initialized
DEBUG - 2011-04-07 05:39:24 --> Utf8 Class Initialized
DEBUG - 2011-04-07 05:39:24 --> UTF-8 Support Enabled
DEBUG - 2011-04-07 05:39:24 --> URI Class Initialized
DEBUG - 2011-04-07 05:39:24 --> Router Class Initialized
DEBUG - 2011-04-07 05:39:24 --> Output Class Initialized
DEBUG - 2011-04-07 05:39:24 --> Input Class Initialized
DEBUG - 2011-04-07 05:39:24 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-07 05:39:24 --> Language Class Initialized
DEBUG - 2011-04-07 05:39:24 --> Loader Class Initialized
DEBUG - 2011-04-07 05:39:24 --> Controller Class Initialized
ERROR - 2011-04-07 05:39:24 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-04-07 05:39:24 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-04-07 05:39:24 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-04-07 05:39:24 --> Model Class Initialized
DEBUG - 2011-04-07 05:39:24 --> Model Class Initialized
DEBUG - 2011-04-07 05:39:24 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-07 05:39:24 --> Database Driver Class Initialized
DEBUG - 2011-04-07 05:39:24 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-04-07 05:39:24 --> Helper loaded: url_helper
DEBUG - 2011-04-07 05:39:24 --> File loaded: application/views/common/header.php
DEBUG - 2011-04-07 05:39:24 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-04-07 05:39:24 --> File loaded: application/views/common/footer.php
DEBUG - 2011-04-07 05:39:24 --> File loaded: application/views/layout/main.php
DEBUG - 2011-04-07 05:39:24 --> Final output sent to browser
DEBUG - 2011-04-07 05:39:24 --> Total execution time: 0.3985
DEBUG - 2011-04-07 06:47:22 --> Config Class Initialized
DEBUG - 2011-04-07 06:47:22 --> Hooks Class Initialized
DEBUG - 2011-04-07 06:47:22 --> Utf8 Class Initialized
DEBUG - 2011-04-07 06:47:22 --> UTF-8 Support Enabled
DEBUG - 2011-04-07 06:47:22 --> URI Class Initialized
DEBUG - 2011-04-07 06:47:22 --> Router Class Initialized
DEBUG - 2011-04-07 06:47:22 --> Output Class Initialized
DEBUG - 2011-04-07 06:47:22 --> Input Class Initialized
DEBUG - 2011-04-07 06:47:22 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-07 06:47:22 --> Language Class Initialized
DEBUG - 2011-04-07 06:47:22 --> Loader Class Initialized
DEBUG - 2011-04-07 06:47:22 --> Controller Class Initialized
DEBUG - 2011-04-07 06:47:22 --> Model Class Initialized
DEBUG - 2011-04-07 06:47:22 --> Model Class Initialized
DEBUG - 2011-04-07 06:47:22 --> Model Class Initialized
DEBUG - 2011-04-07 06:47:22 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-07 06:47:22 --> Database Driver Class Initialized
DEBUG - 2011-04-07 06:47:23 --> File loaded: application/views/table/main.php
DEBUG - 2011-04-07 06:47:23 --> Helper loaded: url_helper
DEBUG - 2011-04-07 06:47:23 --> File loaded: application/views/common/header.php
DEBUG - 2011-04-07 06:47:23 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-04-07 06:47:23 --> File loaded: application/views/common/footer.php
DEBUG - 2011-04-07 06:47:23 --> File loaded: application/views/layout/main.php
DEBUG - 2011-04-07 06:47:23 --> Final output sent to browser
DEBUG - 2011-04-07 06:47:23 --> Total execution time: 0.7576
DEBUG - 2011-04-07 08:28:25 --> Config Class Initialized
DEBUG - 2011-04-07 08:28:25 --> Hooks Class Initialized
DEBUG - 2011-04-07 08:28:25 --> Utf8 Class Initialized
DEBUG - 2011-04-07 08:28:25 --> UTF-8 Support Enabled
DEBUG - 2011-04-07 08:28:25 --> URI Class Initialized
DEBUG - 2011-04-07 08:28:25 --> Router Class Initialized
ERROR - 2011-04-07 08:28:25 --> 404 Page Not Found --> robots.txt
DEBUG - 2011-04-07 09:00:23 --> Config Class Initialized
DEBUG - 2011-04-07 09:00:23 --> Hooks Class Initialized
DEBUG - 2011-04-07 09:00:23 --> Utf8 Class Initialized
DEBUG - 2011-04-07 09:00:23 --> UTF-8 Support Enabled
DEBUG - 2011-04-07 09:00:23 --> URI Class Initialized
DEBUG - 2011-04-07 09:00:23 --> Router Class Initialized
DEBUG - 2011-04-07 09:00:24 --> Output Class Initialized
DEBUG - 2011-04-07 09:00:24 --> Input Class Initialized
DEBUG - 2011-04-07 09:00:24 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-07 09:00:24 --> Language Class Initialized
DEBUG - 2011-04-07 09:00:24 --> Loader Class Initialized
DEBUG - 2011-04-07 09:00:24 --> Controller Class Initialized
ERROR - 2011-04-07 09:00:24 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-04-07 09:00:24 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-04-07 09:00:24 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-04-07 09:00:24 --> Model Class Initialized
DEBUG - 2011-04-07 09:00:24 --> Model Class Initialized
DEBUG - 2011-04-07 09:00:24 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-07 09:00:24 --> Database Driver Class Initialized
DEBUG - 2011-04-07 09:00:28 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-04-07 09:00:28 --> Helper loaded: url_helper
DEBUG - 2011-04-07 09:00:28 --> File loaded: application/views/common/header.php
DEBUG - 2011-04-07 09:00:28 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-04-07 09:00:28 --> File loaded: application/views/common/footer.php
DEBUG - 2011-04-07 09:00:28 --> File loaded: application/views/layout/main.php
DEBUG - 2011-04-07 09:00:28 --> Final output sent to browser
DEBUG - 2011-04-07 09:00:28 --> Total execution time: 4.7731
DEBUG - 2011-04-07 09:01:03 --> Config Class Initialized
DEBUG - 2011-04-07 09:01:03 --> Hooks Class Initialized
DEBUG - 2011-04-07 09:01:03 --> Utf8 Class Initialized
DEBUG - 2011-04-07 09:01:03 --> UTF-8 Support Enabled
DEBUG - 2011-04-07 09:01:03 --> URI Class Initialized
DEBUG - 2011-04-07 09:01:03 --> Router Class Initialized
DEBUG - 2011-04-07 09:01:03 --> No URI present. Default controller set.
DEBUG - 2011-04-07 09:01:03 --> Output Class Initialized
DEBUG - 2011-04-07 09:01:03 --> Input Class Initialized
DEBUG - 2011-04-07 09:01:03 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-07 09:01:03 --> Language Class Initialized
DEBUG - 2011-04-07 09:01:03 --> Loader Class Initialized
DEBUG - 2011-04-07 09:01:03 --> Controller Class Initialized
DEBUG - 2011-04-07 09:01:04 --> File loaded: application/views/splash/main.php
DEBUG - 2011-04-07 09:01:04 --> Helper loaded: url_helper
DEBUG - 2011-04-07 09:01:04 --> File loaded: application/views/common/header.php
DEBUG - 2011-04-07 09:01:04 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-04-07 09:01:04 --> File loaded: application/views/common/footer.php
DEBUG - 2011-04-07 09:01:04 --> File loaded: application/views/layout/main.php
DEBUG - 2011-04-07 09:01:04 --> Final output sent to browser
DEBUG - 2011-04-07 09:01:04 --> Total execution time: 1.0657
DEBUG - 2011-04-07 09:02:07 --> Config Class Initialized
DEBUG - 2011-04-07 09:02:07 --> Hooks Class Initialized
DEBUG - 2011-04-07 09:02:07 --> Utf8 Class Initialized
DEBUG - 2011-04-07 09:02:07 --> UTF-8 Support Enabled
DEBUG - 2011-04-07 09:02:07 --> URI Class Initialized
DEBUG - 2011-04-07 09:02:07 --> Router Class Initialized
ERROR - 2011-04-07 09:02:07 --> 404 Page Not Found --> robots.txt
DEBUG - 2011-04-07 09:02:10 --> Config Class Initialized
DEBUG - 2011-04-07 09:02:10 --> Hooks Class Initialized
DEBUG - 2011-04-07 09:02:10 --> Utf8 Class Initialized
DEBUG - 2011-04-07 09:02:10 --> UTF-8 Support Enabled
DEBUG - 2011-04-07 09:02:10 --> URI Class Initialized
DEBUG - 2011-04-07 09:02:10 --> Router Class Initialized
DEBUG - 2011-04-07 09:02:10 --> Output Class Initialized
DEBUG - 2011-04-07 09:02:10 --> Input Class Initialized
DEBUG - 2011-04-07 09:02:10 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-07 09:02:10 --> Language Class Initialized
DEBUG - 2011-04-07 09:02:10 --> Loader Class Initialized
DEBUG - 2011-04-07 09:02:10 --> Controller Class Initialized
DEBUG - 2011-04-07 09:02:10 --> Model Class Initialized
DEBUG - 2011-04-07 09:02:10 --> Model Class Initialized
DEBUG - 2011-04-07 09:02:10 --> Model Class Initialized
DEBUG - 2011-04-07 09:02:10 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-07 09:02:10 --> Database Driver Class Initialized
DEBUG - 2011-04-07 09:02:11 --> File loaded: application/views/table/main.php
DEBUG - 2011-04-07 09:02:11 --> Helper loaded: url_helper
DEBUG - 2011-04-07 09:02:11 --> File loaded: application/views/common/header.php
DEBUG - 2011-04-07 09:02:11 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-04-07 09:02:11 --> File loaded: application/views/common/footer.php
DEBUG - 2011-04-07 09:02:11 --> File loaded: application/views/layout/main.php
DEBUG - 2011-04-07 09:02:11 --> Final output sent to browser
DEBUG - 2011-04-07 09:02:11 --> Total execution time: 0.4017
DEBUG - 2011-04-07 09:31:26 --> Config Class Initialized
DEBUG - 2011-04-07 09:31:27 --> Hooks Class Initialized
DEBUG - 2011-04-07 09:31:27 --> Utf8 Class Initialized
DEBUG - 2011-04-07 09:31:27 --> UTF-8 Support Enabled
DEBUG - 2011-04-07 09:31:27 --> URI Class Initialized
DEBUG - 2011-04-07 09:31:27 --> Router Class Initialized
DEBUG - 2011-04-07 09:31:28 --> No URI present. Default controller set.
DEBUG - 2011-04-07 09:31:28 --> Output Class Initialized
DEBUG - 2011-04-07 09:31:28 --> Input Class Initialized
DEBUG - 2011-04-07 09:31:28 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-07 09:31:28 --> Language Class Initialized
DEBUG - 2011-04-07 09:31:29 --> Loader Class Initialized
DEBUG - 2011-04-07 09:31:29 --> Controller Class Initialized
DEBUG - 2011-04-07 09:31:30 --> File loaded: application/views/splash/main.php
DEBUG - 2011-04-07 09:31:31 --> Helper loaded: url_helper
DEBUG - 2011-04-07 09:31:31 --> File loaded: application/views/common/header.php
DEBUG - 2011-04-07 09:31:32 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-04-07 09:31:32 --> File loaded: application/views/common/footer.php
DEBUG - 2011-04-07 09:31:32 --> File loaded: application/views/layout/main.php
DEBUG - 2011-04-07 09:31:32 --> Final output sent to browser
DEBUG - 2011-04-07 09:31:32 --> Total execution time: 6.1170
DEBUG - 2011-04-07 09:31:34 --> Config Class Initialized
DEBUG - 2011-04-07 09:31:34 --> Hooks Class Initialized
DEBUG - 2011-04-07 09:31:34 --> Utf8 Class Initialized
DEBUG - 2011-04-07 09:31:34 --> UTF-8 Support Enabled
DEBUG - 2011-04-07 09:31:34 --> URI Class Initialized
DEBUG - 2011-04-07 09:31:34 --> Router Class Initialized
ERROR - 2011-04-07 09:31:34 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-04-07 09:31:35 --> Config Class Initialized
DEBUG - 2011-04-07 09:31:35 --> Hooks Class Initialized
DEBUG - 2011-04-07 09:31:35 --> Utf8 Class Initialized
DEBUG - 2011-04-07 09:31:35 --> UTF-8 Support Enabled
DEBUG - 2011-04-07 09:31:35 --> URI Class Initialized
DEBUG - 2011-04-07 09:31:35 --> Router Class Initialized
ERROR - 2011-04-07 09:31:35 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-04-07 09:31:37 --> Config Class Initialized
DEBUG - 2011-04-07 09:31:37 --> Hooks Class Initialized
DEBUG - 2011-04-07 09:31:37 --> Utf8 Class Initialized
DEBUG - 2011-04-07 09:31:37 --> UTF-8 Support Enabled
DEBUG - 2011-04-07 09:31:37 --> URI Class Initialized
DEBUG - 2011-04-07 09:31:37 --> Router Class Initialized
DEBUG - 2011-04-07 09:31:37 --> Output Class Initialized
DEBUG - 2011-04-07 09:31:37 --> Input Class Initialized
DEBUG - 2011-04-07 09:31:37 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-07 09:31:37 --> Language Class Initialized
DEBUG - 2011-04-07 09:31:38 --> Loader Class Initialized
DEBUG - 2011-04-07 09:31:38 --> Controller Class Initialized
DEBUG - 2011-04-07 09:31:38 --> Model Class Initialized
DEBUG - 2011-04-07 09:31:39 --> Model Class Initialized
DEBUG - 2011-04-07 09:31:39 --> Model Class Initialized
DEBUG - 2011-04-07 09:31:39 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-07 09:31:39 --> Database Driver Class Initialized
DEBUG - 2011-04-07 09:31:41 --> File loaded: application/views/table/main.php
DEBUG - 2011-04-07 09:31:41 --> Helper loaded: url_helper
DEBUG - 2011-04-07 09:31:41 --> File loaded: application/views/common/header.php
DEBUG - 2011-04-07 09:31:41 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-04-07 09:31:41 --> File loaded: application/views/common/footer.php
DEBUG - 2011-04-07 09:31:41 --> File loaded: application/views/layout/main.php
DEBUG - 2011-04-07 09:31:41 --> Final output sent to browser
DEBUG - 2011-04-07 09:31:41 --> Total execution time: 3.6273
DEBUG - 2011-04-07 09:31:42 --> Config Class Initialized
DEBUG - 2011-04-07 09:31:42 --> Hooks Class Initialized
DEBUG - 2011-04-07 09:31:42 --> Utf8 Class Initialized
DEBUG - 2011-04-07 09:31:42 --> UTF-8 Support Enabled
DEBUG - 2011-04-07 09:31:42 --> URI Class Initialized
DEBUG - 2011-04-07 09:31:42 --> Router Class Initialized
ERROR - 2011-04-07 09:31:42 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-04-07 09:32:00 --> Config Class Initialized
DEBUG - 2011-04-07 09:32:00 --> Hooks Class Initialized
DEBUG - 2011-04-07 09:32:00 --> Utf8 Class Initialized
DEBUG - 2011-04-07 09:32:00 --> UTF-8 Support Enabled
DEBUG - 2011-04-07 09:32:00 --> URI Class Initialized
DEBUG - 2011-04-07 09:32:00 --> Router Class Initialized
DEBUG - 2011-04-07 09:32:00 --> Output Class Initialized
DEBUG - 2011-04-07 09:32:00 --> Input Class Initialized
DEBUG - 2011-04-07 09:32:00 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-07 09:32:00 --> Language Class Initialized
DEBUG - 2011-04-07 09:32:00 --> Loader Class Initialized
DEBUG - 2011-04-07 09:32:00 --> Controller Class Initialized
DEBUG - 2011-04-07 09:32:00 --> Model Class Initialized
DEBUG - 2011-04-07 09:32:00 --> Model Class Initialized
DEBUG - 2011-04-07 09:32:00 --> Model Class Initialized
DEBUG - 2011-04-07 09:32:00 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-07 09:32:00 --> Database Driver Class Initialized
DEBUG - 2011-04-07 09:32:15 --> File loaded: application/views/table/main.php
DEBUG - 2011-04-07 09:32:15 --> Helper loaded: url_helper
DEBUG - 2011-04-07 09:32:15 --> File loaded: application/views/common/header.php
DEBUG - 2011-04-07 09:32:15 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-04-07 09:32:15 --> File loaded: application/views/common/footer.php
DEBUG - 2011-04-07 09:32:15 --> File loaded: application/views/layout/main.php
DEBUG - 2011-04-07 09:32:15 --> Final output sent to browser
DEBUG - 2011-04-07 09:32:15 --> Total execution time: 15.2300
DEBUG - 2011-04-07 09:32:17 --> Config Class Initialized
DEBUG - 2011-04-07 09:32:17 --> Hooks Class Initialized
DEBUG - 2011-04-07 09:32:17 --> Utf8 Class Initialized
DEBUG - 2011-04-07 09:32:17 --> UTF-8 Support Enabled
DEBUG - 2011-04-07 09:32:17 --> URI Class Initialized
DEBUG - 2011-04-07 09:32:17 --> Router Class Initialized
ERROR - 2011-04-07 09:32:17 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-04-07 09:32:31 --> Config Class Initialized
DEBUG - 2011-04-07 09:32:31 --> Hooks Class Initialized
DEBUG - 2011-04-07 09:32:31 --> Utf8 Class Initialized
DEBUG - 2011-04-07 09:32:31 --> UTF-8 Support Enabled
DEBUG - 2011-04-07 09:32:31 --> URI Class Initialized
DEBUG - 2011-04-07 09:32:31 --> Router Class Initialized
DEBUG - 2011-04-07 09:32:31 --> Output Class Initialized
DEBUG - 2011-04-07 09:32:31 --> Input Class Initialized
DEBUG - 2011-04-07 09:32:31 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-07 09:32:31 --> Language Class Initialized
DEBUG - 2011-04-07 09:32:31 --> Loader Class Initialized
DEBUG - 2011-04-07 09:32:31 --> Controller Class Initialized
DEBUG - 2011-04-07 09:32:31 --> Model Class Initialized
DEBUG - 2011-04-07 09:32:31 --> Model Class Initialized
DEBUG - 2011-04-07 09:32:31 --> Model Class Initialized
DEBUG - 2011-04-07 09:32:31 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-07 09:32:31 --> Database Driver Class Initialized
DEBUG - 2011-04-07 09:32:35 --> File loaded: application/views/table/main.php
DEBUG - 2011-04-07 09:32:35 --> Helper loaded: url_helper
DEBUG - 2011-04-07 09:32:35 --> File loaded: application/views/common/header.php
DEBUG - 2011-04-07 09:32:35 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-04-07 09:32:35 --> File loaded: application/views/common/footer.php
DEBUG - 2011-04-07 09:32:35 --> File loaded: application/views/layout/main.php
DEBUG - 2011-04-07 09:32:35 --> Final output sent to browser
DEBUG - 2011-04-07 09:32:35 --> Total execution time: 3.7502
DEBUG - 2011-04-07 09:32:36 --> Config Class Initialized
DEBUG - 2011-04-07 09:32:36 --> Hooks Class Initialized
DEBUG - 2011-04-07 09:32:36 --> Utf8 Class Initialized
DEBUG - 2011-04-07 09:32:36 --> UTF-8 Support Enabled
DEBUG - 2011-04-07 09:32:36 --> URI Class Initialized
DEBUG - 2011-04-07 09:32:36 --> Router Class Initialized
ERROR - 2011-04-07 09:32:36 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-04-07 09:33:50 --> Config Class Initialized
DEBUG - 2011-04-07 09:33:50 --> Hooks Class Initialized
DEBUG - 2011-04-07 09:33:50 --> Utf8 Class Initialized
DEBUG - 2011-04-07 09:33:50 --> UTF-8 Support Enabled
DEBUG - 2011-04-07 09:33:50 --> URI Class Initialized
DEBUG - 2011-04-07 09:33:50 --> Router Class Initialized
DEBUG - 2011-04-07 09:33:50 --> Output Class Initialized
DEBUG - 2011-04-07 09:33:50 --> Input Class Initialized
DEBUG - 2011-04-07 09:33:50 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-07 09:33:50 --> Language Class Initialized
DEBUG - 2011-04-07 09:33:50 --> Loader Class Initialized
DEBUG - 2011-04-07 09:33:50 --> Controller Class Initialized
DEBUG - 2011-04-07 09:33:50 --> Model Class Initialized
DEBUG - 2011-04-07 09:33:50 --> Model Class Initialized
DEBUG - 2011-04-07 09:33:50 --> Model Class Initialized
DEBUG - 2011-04-07 09:33:50 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-07 09:33:50 --> Database Driver Class Initialized
DEBUG - 2011-04-07 09:33:50 --> File loaded: application/views/table/main.php
DEBUG - 2011-04-07 09:33:50 --> Helper loaded: url_helper
DEBUG - 2011-04-07 09:33:50 --> File loaded: application/views/common/header.php
DEBUG - 2011-04-07 09:33:50 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-04-07 09:33:50 --> File loaded: application/views/common/footer.php
DEBUG - 2011-04-07 09:33:50 --> File loaded: application/views/layout/main.php
DEBUG - 2011-04-07 09:33:50 --> Final output sent to browser
DEBUG - 2011-04-07 09:33:50 --> Total execution time: 0.0576
DEBUG - 2011-04-07 09:33:51 --> Config Class Initialized
DEBUG - 2011-04-07 09:33:51 --> Hooks Class Initialized
DEBUG - 2011-04-07 09:33:51 --> Utf8 Class Initialized
DEBUG - 2011-04-07 09:33:51 --> UTF-8 Support Enabled
DEBUG - 2011-04-07 09:33:51 --> URI Class Initialized
DEBUG - 2011-04-07 09:33:51 --> Router Class Initialized
ERROR - 2011-04-07 09:33:51 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-04-07 09:38:04 --> Config Class Initialized
DEBUG - 2011-04-07 09:38:04 --> Hooks Class Initialized
DEBUG - 2011-04-07 09:38:04 --> Utf8 Class Initialized
DEBUG - 2011-04-07 09:38:04 --> UTF-8 Support Enabled
DEBUG - 2011-04-07 09:38:04 --> URI Class Initialized
DEBUG - 2011-04-07 09:38:04 --> Router Class Initialized
DEBUG - 2011-04-07 09:38:04 --> Output Class Initialized
DEBUG - 2011-04-07 09:38:04 --> Input Class Initialized
DEBUG - 2011-04-07 09:38:04 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-07 09:38:04 --> Language Class Initialized
DEBUG - 2011-04-07 09:38:04 --> Loader Class Initialized
DEBUG - 2011-04-07 09:38:04 --> Controller Class Initialized
DEBUG - 2011-04-07 09:38:04 --> Model Class Initialized
DEBUG - 2011-04-07 09:38:04 --> Model Class Initialized
DEBUG - 2011-04-07 09:38:04 --> Model Class Initialized
DEBUG - 2011-04-07 09:38:04 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-07 09:38:04 --> Database Driver Class Initialized
DEBUG - 2011-04-07 09:38:04 --> File loaded: application/views/table/main.php
DEBUG - 2011-04-07 09:38:04 --> Helper loaded: url_helper
DEBUG - 2011-04-07 09:38:04 --> File loaded: application/views/common/header.php
DEBUG - 2011-04-07 09:38:04 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-04-07 09:38:04 --> File loaded: application/views/common/footer.php
DEBUG - 2011-04-07 09:38:04 --> File loaded: application/views/layout/main.php
DEBUG - 2011-04-07 09:38:04 --> Final output sent to browser
DEBUG - 2011-04-07 09:38:04 --> Total execution time: 0.3932
DEBUG - 2011-04-07 09:38:08 --> Config Class Initialized
DEBUG - 2011-04-07 09:38:08 --> Hooks Class Initialized
DEBUG - 2011-04-07 09:38:08 --> Utf8 Class Initialized
DEBUG - 2011-04-07 09:38:08 --> UTF-8 Support Enabled
DEBUG - 2011-04-07 09:38:08 --> URI Class Initialized
DEBUG - 2011-04-07 09:38:08 --> Router Class Initialized
ERROR - 2011-04-07 09:38:08 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-04-07 09:39:08 --> Config Class Initialized
DEBUG - 2011-04-07 09:39:08 --> Hooks Class Initialized
DEBUG - 2011-04-07 09:39:08 --> Utf8 Class Initialized
DEBUG - 2011-04-07 09:39:08 --> UTF-8 Support Enabled
DEBUG - 2011-04-07 09:39:08 --> URI Class Initialized
DEBUG - 2011-04-07 09:39:08 --> Router Class Initialized
DEBUG - 2011-04-07 09:39:08 --> Output Class Initialized
DEBUG - 2011-04-07 09:39:08 --> Input Class Initialized
DEBUG - 2011-04-07 09:39:08 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-07 09:39:08 --> Language Class Initialized
DEBUG - 2011-04-07 09:39:08 --> Loader Class Initialized
DEBUG - 2011-04-07 09:39:08 --> Controller Class Initialized
DEBUG - 2011-04-07 09:39:08 --> Model Class Initialized
DEBUG - 2011-04-07 09:39:08 --> Model Class Initialized
DEBUG - 2011-04-07 09:39:08 --> Model Class Initialized
DEBUG - 2011-04-07 09:39:08 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-07 09:39:08 --> Database Driver Class Initialized
DEBUG - 2011-04-07 09:39:08 --> File loaded: application/views/table/main.php
DEBUG - 2011-04-07 09:39:08 --> Helper loaded: url_helper
DEBUG - 2011-04-07 09:39:08 --> File loaded: application/views/common/header.php
DEBUG - 2011-04-07 09:39:08 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-04-07 09:39:08 --> File loaded: application/views/common/footer.php
DEBUG - 2011-04-07 09:39:08 --> File loaded: application/views/layout/main.php
DEBUG - 2011-04-07 09:39:08 --> Final output sent to browser
DEBUG - 2011-04-07 09:39:08 --> Total execution time: 0.3789
DEBUG - 2011-04-07 09:39:16 --> Config Class Initialized
DEBUG - 2011-04-07 09:39:16 --> Hooks Class Initialized
DEBUG - 2011-04-07 09:39:16 --> Utf8 Class Initialized
DEBUG - 2011-04-07 09:39:16 --> UTF-8 Support Enabled
DEBUG - 2011-04-07 09:39:16 --> URI Class Initialized
DEBUG - 2011-04-07 09:39:16 --> Router Class Initialized
DEBUG - 2011-04-07 09:39:16 --> Output Class Initialized
DEBUG - 2011-04-07 09:39:16 --> Input Class Initialized
DEBUG - 2011-04-07 09:39:16 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-07 09:39:16 --> Language Class Initialized
DEBUG - 2011-04-07 09:39:16 --> Loader Class Initialized
DEBUG - 2011-04-07 09:39:16 --> Controller Class Initialized
DEBUG - 2011-04-07 09:39:16 --> Model Class Initialized
DEBUG - 2011-04-07 09:39:16 --> Model Class Initialized
DEBUG - 2011-04-07 09:39:16 --> Model Class Initialized
DEBUG - 2011-04-07 09:39:16 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-07 09:39:16 --> Database Driver Class Initialized
DEBUG - 2011-04-07 09:39:16 --> File loaded: application/views/table/main.php
DEBUG - 2011-04-07 09:39:16 --> Helper loaded: url_helper
DEBUG - 2011-04-07 09:39:16 --> File loaded: application/views/common/header.php
DEBUG - 2011-04-07 09:39:16 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-04-07 09:39:16 --> File loaded: application/views/common/footer.php
DEBUG - 2011-04-07 09:39:16 --> File loaded: application/views/layout/main.php
DEBUG - 2011-04-07 09:39:16 --> Final output sent to browser
DEBUG - 2011-04-07 09:39:16 --> Total execution time: 0.2082
DEBUG - 2011-04-07 09:39:22 --> Config Class Initialized
DEBUG - 2011-04-07 09:39:22 --> Hooks Class Initialized
DEBUG - 2011-04-07 09:39:22 --> Utf8 Class Initialized
DEBUG - 2011-04-07 09:39:22 --> UTF-8 Support Enabled
DEBUG - 2011-04-07 09:39:22 --> URI Class Initialized
DEBUG - 2011-04-07 09:39:22 --> Router Class Initialized
DEBUG - 2011-04-07 09:39:22 --> Output Class Initialized
DEBUG - 2011-04-07 09:39:22 --> Input Class Initialized
DEBUG - 2011-04-07 09:39:22 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-07 09:39:22 --> Language Class Initialized
DEBUG - 2011-04-07 09:39:22 --> Loader Class Initialized
DEBUG - 2011-04-07 09:39:22 --> Controller Class Initialized
DEBUG - 2011-04-07 09:39:22 --> Model Class Initialized
DEBUG - 2011-04-07 09:39:22 --> Model Class Initialized
DEBUG - 2011-04-07 09:39:22 --> Model Class Initialized
DEBUG - 2011-04-07 09:39:22 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-07 09:39:22 --> Database Driver Class Initialized
DEBUG - 2011-04-07 09:39:23 --> File loaded: application/views/table/main.php
DEBUG - 2011-04-07 09:39:23 --> Helper loaded: url_helper
DEBUG - 2011-04-07 09:39:23 --> File loaded: application/views/common/header.php
DEBUG - 2011-04-07 09:39:23 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-04-07 09:39:23 --> File loaded: application/views/common/footer.php
DEBUG - 2011-04-07 09:39:23 --> File loaded: application/views/layout/main.php
DEBUG - 2011-04-07 09:39:23 --> Final output sent to browser
DEBUG - 2011-04-07 09:39:23 --> Total execution time: 0.6735
DEBUG - 2011-04-07 09:39:31 --> Config Class Initialized
DEBUG - 2011-04-07 09:39:31 --> Hooks Class Initialized
DEBUG - 2011-04-07 09:39:31 --> Utf8 Class Initialized
DEBUG - 2011-04-07 09:39:31 --> UTF-8 Support Enabled
DEBUG - 2011-04-07 09:39:31 --> URI Class Initialized
DEBUG - 2011-04-07 09:39:31 --> Router Class Initialized
DEBUG - 2011-04-07 09:39:31 --> Output Class Initialized
DEBUG - 2011-04-07 09:39:31 --> Input Class Initialized
DEBUG - 2011-04-07 09:39:31 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-07 09:39:31 --> Language Class Initialized
DEBUG - 2011-04-07 09:39:31 --> Loader Class Initialized
DEBUG - 2011-04-07 09:39:31 --> Controller Class Initialized
DEBUG - 2011-04-07 09:39:31 --> Model Class Initialized
DEBUG - 2011-04-07 09:39:31 --> Model Class Initialized
DEBUG - 2011-04-07 09:39:31 --> Model Class Initialized
DEBUG - 2011-04-07 09:39:31 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-07 09:39:31 --> Database Driver Class Initialized
DEBUG - 2011-04-07 09:39:31 --> File loaded: application/views/table/main.php
DEBUG - 2011-04-07 09:39:31 --> Helper loaded: url_helper
DEBUG - 2011-04-07 09:39:31 --> File loaded: application/views/common/header.php
DEBUG - 2011-04-07 09:39:31 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-04-07 09:39:31 --> File loaded: application/views/common/footer.php
DEBUG - 2011-04-07 09:39:31 --> File loaded: application/views/layout/main.php
DEBUG - 2011-04-07 09:39:31 --> Final output sent to browser
DEBUG - 2011-04-07 09:39:31 --> Total execution time: 0.1896
DEBUG - 2011-04-07 09:39:37 --> Config Class Initialized
DEBUG - 2011-04-07 09:39:37 --> Hooks Class Initialized
DEBUG - 2011-04-07 09:39:37 --> Utf8 Class Initialized
DEBUG - 2011-04-07 09:39:37 --> UTF-8 Support Enabled
DEBUG - 2011-04-07 09:39:37 --> URI Class Initialized
DEBUG - 2011-04-07 09:39:37 --> Router Class Initialized
DEBUG - 2011-04-07 09:39:37 --> Output Class Initialized
DEBUG - 2011-04-07 09:39:37 --> Input Class Initialized
DEBUG - 2011-04-07 09:39:37 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-07 09:39:37 --> Language Class Initialized
DEBUG - 2011-04-07 09:39:37 --> Loader Class Initialized
DEBUG - 2011-04-07 09:39:37 --> Controller Class Initialized
DEBUG - 2011-04-07 09:39:37 --> Model Class Initialized
DEBUG - 2011-04-07 09:39:37 --> Model Class Initialized
DEBUG - 2011-04-07 09:39:37 --> Model Class Initialized
DEBUG - 2011-04-07 09:39:37 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-07 09:39:37 --> Database Driver Class Initialized
DEBUG - 2011-04-07 09:39:37 --> File loaded: application/views/table/main.php
DEBUG - 2011-04-07 09:39:37 --> Helper loaded: url_helper
DEBUG - 2011-04-07 09:39:37 --> File loaded: application/views/common/header.php
DEBUG - 2011-04-07 09:39:37 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-04-07 09:39:37 --> File loaded: application/views/common/footer.php
DEBUG - 2011-04-07 09:39:37 --> File loaded: application/views/layout/main.php
DEBUG - 2011-04-07 09:39:37 --> Final output sent to browser
DEBUG - 2011-04-07 09:39:37 --> Total execution time: 0.2273
DEBUG - 2011-04-07 09:39:43 --> Config Class Initialized
DEBUG - 2011-04-07 09:39:43 --> Hooks Class Initialized
DEBUG - 2011-04-07 09:39:43 --> Utf8 Class Initialized
DEBUG - 2011-04-07 09:39:43 --> UTF-8 Support Enabled
DEBUG - 2011-04-07 09:39:43 --> URI Class Initialized
DEBUG - 2011-04-07 09:39:43 --> Router Class Initialized
DEBUG - 2011-04-07 09:39:43 --> Output Class Initialized
DEBUG - 2011-04-07 09:39:43 --> Input Class Initialized
DEBUG - 2011-04-07 09:39:43 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-07 09:39:43 --> Language Class Initialized
DEBUG - 2011-04-07 09:39:43 --> Loader Class Initialized
DEBUG - 2011-04-07 09:39:43 --> Controller Class Initialized
DEBUG - 2011-04-07 09:39:43 --> Model Class Initialized
DEBUG - 2011-04-07 09:39:43 --> Model Class Initialized
DEBUG - 2011-04-07 09:39:43 --> Model Class Initialized
DEBUG - 2011-04-07 09:39:43 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-07 09:39:43 --> Database Driver Class Initialized
DEBUG - 2011-04-07 09:39:44 --> File loaded: application/views/table/main.php
DEBUG - 2011-04-07 09:39:44 --> Helper loaded: url_helper
DEBUG - 2011-04-07 09:39:44 --> File loaded: application/views/common/header.php
DEBUG - 2011-04-07 09:39:44 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-04-07 09:39:44 --> File loaded: application/views/common/footer.php
DEBUG - 2011-04-07 09:39:44 --> File loaded: application/views/layout/main.php
DEBUG - 2011-04-07 09:39:44 --> Final output sent to browser
DEBUG - 2011-04-07 09:39:44 --> Total execution time: 1.1576
DEBUG - 2011-04-07 09:39:49 --> Config Class Initialized
DEBUG - 2011-04-07 09:39:49 --> Hooks Class Initialized
DEBUG - 2011-04-07 09:39:49 --> Utf8 Class Initialized
DEBUG - 2011-04-07 09:39:49 --> UTF-8 Support Enabled
DEBUG - 2011-04-07 09:39:49 --> URI Class Initialized
DEBUG - 2011-04-07 09:39:49 --> Router Class Initialized
DEBUG - 2011-04-07 09:39:49 --> Output Class Initialized
DEBUG - 2011-04-07 09:39:49 --> Input Class Initialized
DEBUG - 2011-04-07 09:39:49 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-07 09:39:49 --> Language Class Initialized
DEBUG - 2011-04-07 09:39:49 --> Loader Class Initialized
DEBUG - 2011-04-07 09:39:49 --> Controller Class Initialized
DEBUG - 2011-04-07 09:39:49 --> Model Class Initialized
DEBUG - 2011-04-07 09:39:49 --> Model Class Initialized
DEBUG - 2011-04-07 09:39:49 --> Model Class Initialized
DEBUG - 2011-04-07 09:39:49 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-07 09:39:49 --> Database Driver Class Initialized
DEBUG - 2011-04-07 09:39:50 --> File loaded: application/views/table/main.php
DEBUG - 2011-04-07 09:39:50 --> Helper loaded: url_helper
DEBUG - 2011-04-07 09:39:50 --> File loaded: application/views/common/header.php
DEBUG - 2011-04-07 09:39:50 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-04-07 09:39:50 --> File loaded: application/views/common/footer.php
DEBUG - 2011-04-07 09:39:50 --> File loaded: application/views/layout/main.php
DEBUG - 2011-04-07 09:39:50 --> Final output sent to browser
DEBUG - 2011-04-07 09:39:50 --> Total execution time: 1.0004
DEBUG - 2011-04-07 09:39:57 --> Config Class Initialized
DEBUG - 2011-04-07 09:39:57 --> Hooks Class Initialized
DEBUG - 2011-04-07 09:39:57 --> Utf8 Class Initialized
DEBUG - 2011-04-07 09:39:57 --> UTF-8 Support Enabled
DEBUG - 2011-04-07 09:39:57 --> URI Class Initialized
DEBUG - 2011-04-07 09:39:57 --> Router Class Initialized
DEBUG - 2011-04-07 09:39:57 --> Output Class Initialized
DEBUG - 2011-04-07 09:39:57 --> Input Class Initialized
DEBUG - 2011-04-07 09:39:57 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-07 09:39:57 --> Language Class Initialized
DEBUG - 2011-04-07 09:39:57 --> Loader Class Initialized
DEBUG - 2011-04-07 09:39:57 --> Controller Class Initialized
DEBUG - 2011-04-07 09:39:57 --> Model Class Initialized
DEBUG - 2011-04-07 09:39:57 --> Model Class Initialized
DEBUG - 2011-04-07 09:39:57 --> Model Class Initialized
DEBUG - 2011-04-07 09:39:57 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-07 09:39:57 --> Database Driver Class Initialized
DEBUG - 2011-04-07 09:39:57 --> File loaded: application/views/table/main.php
DEBUG - 2011-04-07 09:39:58 --> Helper loaded: url_helper
DEBUG - 2011-04-07 09:39:58 --> File loaded: application/views/common/header.php
DEBUG - 2011-04-07 09:39:58 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-04-07 09:39:58 --> File loaded: application/views/common/footer.php
DEBUG - 2011-04-07 09:39:58 --> File loaded: application/views/layout/main.php
DEBUG - 2011-04-07 09:39:58 --> Final output sent to browser
DEBUG - 2011-04-07 09:39:58 --> Total execution time: 1.8478
DEBUG - 2011-04-07 09:49:14 --> Config Class Initialized
DEBUG - 2011-04-07 09:49:14 --> Hooks Class Initialized
DEBUG - 2011-04-07 09:49:14 --> Utf8 Class Initialized
DEBUG - 2011-04-07 09:49:14 --> UTF-8 Support Enabled
DEBUG - 2011-04-07 09:49:14 --> URI Class Initialized
DEBUG - 2011-04-07 09:49:14 --> Router Class Initialized
ERROR - 2011-04-07 09:49:14 --> 404 Page Not Found --> robots.txt
DEBUG - 2011-04-07 09:49:14 --> Config Class Initialized
DEBUG - 2011-04-07 09:49:14 --> Hooks Class Initialized
DEBUG - 2011-04-07 09:49:14 --> Utf8 Class Initialized
DEBUG - 2011-04-07 09:49:14 --> UTF-8 Support Enabled
DEBUG - 2011-04-07 09:49:14 --> URI Class Initialized
DEBUG - 2011-04-07 09:49:14 --> Router Class Initialized
DEBUG - 2011-04-07 09:49:14 --> Output Class Initialized
DEBUG - 2011-04-07 09:49:14 --> Input Class Initialized
DEBUG - 2011-04-07 09:49:14 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-07 09:49:14 --> Language Class Initialized
DEBUG - 2011-04-07 09:49:14 --> Loader Class Initialized
DEBUG - 2011-04-07 09:49:14 --> Controller Class Initialized
DEBUG - 2011-04-07 09:49:14 --> Model Class Initialized
DEBUG - 2011-04-07 09:49:14 --> Model Class Initialized
DEBUG - 2011-04-07 09:49:14 --> Model Class Initialized
DEBUG - 2011-04-07 09:49:14 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-07 09:49:14 --> Database Driver Class Initialized
DEBUG - 2011-04-07 09:49:15 --> File loaded: application/views/table/main.php
DEBUG - 2011-04-07 09:49:15 --> Helper loaded: url_helper
DEBUG - 2011-04-07 09:49:15 --> File loaded: application/views/common/header.php
DEBUG - 2011-04-07 09:49:15 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-04-07 09:49:15 --> File loaded: application/views/common/footer.php
DEBUG - 2011-04-07 09:49:15 --> File loaded: application/views/layout/main.php
DEBUG - 2011-04-07 09:49:15 --> Final output sent to browser
DEBUG - 2011-04-07 09:49:15 --> Total execution time: 0.4756
DEBUG - 2011-04-07 09:49:21 --> Config Class Initialized
DEBUG - 2011-04-07 09:49:21 --> Hooks Class Initialized
DEBUG - 2011-04-07 09:49:21 --> Utf8 Class Initialized
DEBUG - 2011-04-07 09:49:21 --> UTF-8 Support Enabled
DEBUG - 2011-04-07 09:49:21 --> URI Class Initialized
DEBUG - 2011-04-07 09:49:21 --> Router Class Initialized
DEBUG - 2011-04-07 09:49:21 --> Output Class Initialized
DEBUG - 2011-04-07 09:49:21 --> Input Class Initialized
DEBUG - 2011-04-07 09:49:21 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-07 09:49:21 --> Language Class Initialized
DEBUG - 2011-04-07 09:49:21 --> Loader Class Initialized
DEBUG - 2011-04-07 09:49:21 --> Controller Class Initialized
DEBUG - 2011-04-07 09:49:21 --> Model Class Initialized
DEBUG - 2011-04-07 09:49:21 --> Model Class Initialized
DEBUG - 2011-04-07 09:49:21 --> Model Class Initialized
DEBUG - 2011-04-07 09:49:21 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-07 09:49:21 --> Database Driver Class Initialized
DEBUG - 2011-04-07 09:49:21 --> File loaded: application/views/table/main.php
DEBUG - 2011-04-07 09:49:21 --> Helper loaded: url_helper
DEBUG - 2011-04-07 09:49:21 --> File loaded: application/views/common/header.php
DEBUG - 2011-04-07 09:49:21 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-04-07 09:49:21 --> File loaded: application/views/common/footer.php
DEBUG - 2011-04-07 09:49:21 --> File loaded: application/views/layout/main.php
DEBUG - 2011-04-07 09:49:21 --> Final output sent to browser
DEBUG - 2011-04-07 09:49:21 --> Total execution time: 0.2179
DEBUG - 2011-04-07 09:49:21 --> Config Class Initialized
DEBUG - 2011-04-07 09:49:21 --> Hooks Class Initialized
DEBUG - 2011-04-07 09:49:21 --> Utf8 Class Initialized
DEBUG - 2011-04-07 09:49:21 --> UTF-8 Support Enabled
DEBUG - 2011-04-07 09:49:21 --> URI Class Initialized
DEBUG - 2011-04-07 09:49:21 --> Router Class Initialized
DEBUG - 2011-04-07 09:49:21 --> Output Class Initialized
DEBUG - 2011-04-07 09:49:21 --> Input Class Initialized
DEBUG - 2011-04-07 09:49:21 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-07 09:49:21 --> Language Class Initialized
DEBUG - 2011-04-07 09:49:21 --> Loader Class Initialized
DEBUG - 2011-04-07 09:49:21 --> Controller Class Initialized
DEBUG - 2011-04-07 09:49:21 --> Model Class Initialized
DEBUG - 2011-04-07 09:49:21 --> Model Class Initialized
DEBUG - 2011-04-07 09:49:21 --> Model Class Initialized
DEBUG - 2011-04-07 09:49:21 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-07 09:49:21 --> Database Driver Class Initialized
DEBUG - 2011-04-07 09:49:22 --> File loaded: application/views/table/main.php
DEBUG - 2011-04-07 09:49:22 --> Helper loaded: url_helper
DEBUG - 2011-04-07 09:49:22 --> File loaded: application/views/common/header.php
DEBUG - 2011-04-07 09:49:22 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-04-07 09:49:22 --> File loaded: application/views/common/footer.php
DEBUG - 2011-04-07 09:49:22 --> File loaded: application/views/layout/main.php
DEBUG - 2011-04-07 09:49:22 --> Final output sent to browser
DEBUG - 2011-04-07 09:49:22 --> Total execution time: 0.2489
DEBUG - 2011-04-07 09:49:25 --> Config Class Initialized
DEBUG - 2011-04-07 09:49:25 --> Hooks Class Initialized
DEBUG - 2011-04-07 09:49:25 --> Utf8 Class Initialized
DEBUG - 2011-04-07 09:49:25 --> UTF-8 Support Enabled
DEBUG - 2011-04-07 09:49:25 --> URI Class Initialized
DEBUG - 2011-04-07 09:49:25 --> Router Class Initialized
DEBUG - 2011-04-07 09:49:25 --> Output Class Initialized
DEBUG - 2011-04-07 09:49:25 --> Input Class Initialized
DEBUG - 2011-04-07 09:49:25 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-07 09:49:25 --> Language Class Initialized
DEBUG - 2011-04-07 09:49:25 --> Loader Class Initialized
DEBUG - 2011-04-07 09:49:25 --> Controller Class Initialized
DEBUG - 2011-04-07 09:49:25 --> Model Class Initialized
DEBUG - 2011-04-07 09:49:25 --> Model Class Initialized
DEBUG - 2011-04-07 09:49:25 --> Model Class Initialized
DEBUG - 2011-04-07 09:49:25 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-07 09:49:25 --> Database Driver Class Initialized
DEBUG - 2011-04-07 09:49:25 --> File loaded: application/views/table/main.php
DEBUG - 2011-04-07 09:49:25 --> Helper loaded: url_helper
DEBUG - 2011-04-07 09:49:25 --> File loaded: application/views/common/header.php
DEBUG - 2011-04-07 09:49:25 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-04-07 09:49:25 --> File loaded: application/views/common/footer.php
DEBUG - 2011-04-07 09:49:25 --> File loaded: application/views/layout/main.php
DEBUG - 2011-04-07 09:49:25 --> Final output sent to browser
DEBUG - 2011-04-07 09:49:25 --> Total execution time: 0.1987
DEBUG - 2011-04-07 09:49:26 --> Config Class Initialized
DEBUG - 2011-04-07 09:49:26 --> Hooks Class Initialized
DEBUG - 2011-04-07 09:49:26 --> Utf8 Class Initialized
DEBUG - 2011-04-07 09:49:26 --> UTF-8 Support Enabled
DEBUG - 2011-04-07 09:49:26 --> URI Class Initialized
DEBUG - 2011-04-07 09:49:26 --> Router Class Initialized
DEBUG - 2011-04-07 09:49:26 --> Output Class Initialized
DEBUG - 2011-04-07 09:49:26 --> Input Class Initialized
DEBUG - 2011-04-07 09:49:26 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-07 09:49:26 --> Language Class Initialized
DEBUG - 2011-04-07 09:49:26 --> Loader Class Initialized
DEBUG - 2011-04-07 09:49:26 --> Controller Class Initialized
DEBUG - 2011-04-07 09:49:26 --> Model Class Initialized
DEBUG - 2011-04-07 09:49:26 --> Model Class Initialized
DEBUG - 2011-04-07 09:49:26 --> Model Class Initialized
DEBUG - 2011-04-07 09:49:26 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-07 09:49:26 --> Database Driver Class Initialized
DEBUG - 2011-04-07 09:49:26 --> File loaded: application/views/table/main.php
DEBUG - 2011-04-07 09:49:26 --> Helper loaded: url_helper
DEBUG - 2011-04-07 09:49:26 --> File loaded: application/views/common/header.php
DEBUG - 2011-04-07 09:49:26 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-04-07 09:49:26 --> File loaded: application/views/common/footer.php
DEBUG - 2011-04-07 09:49:26 --> File loaded: application/views/layout/main.php
DEBUG - 2011-04-07 09:49:26 --> Final output sent to browser
DEBUG - 2011-04-07 09:49:26 --> Total execution time: 0.2896
DEBUG - 2011-04-07 09:50:05 --> Config Class Initialized
DEBUG - 2011-04-07 09:50:05 --> Hooks Class Initialized
DEBUG - 2011-04-07 09:50:05 --> Utf8 Class Initialized
DEBUG - 2011-04-07 09:50:05 --> UTF-8 Support Enabled
DEBUG - 2011-04-07 09:50:05 --> URI Class Initialized
DEBUG - 2011-04-07 09:50:05 --> Router Class Initialized
DEBUG - 2011-04-07 09:50:05 --> Output Class Initialized
DEBUG - 2011-04-07 09:50:05 --> Input Class Initialized
DEBUG - 2011-04-07 09:50:05 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-07 09:50:05 --> Language Class Initialized
DEBUG - 2011-04-07 09:50:05 --> Loader Class Initialized
DEBUG - 2011-04-07 09:50:05 --> Controller Class Initialized
DEBUG - 2011-04-07 09:50:05 --> Model Class Initialized
DEBUG - 2011-04-07 09:50:05 --> Model Class Initialized
DEBUG - 2011-04-07 09:50:05 --> Model Class Initialized
DEBUG - 2011-04-07 09:50:05 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-07 09:50:05 --> Database Driver Class Initialized
DEBUG - 2011-04-07 09:50:05 --> Config Class Initialized
DEBUG - 2011-04-07 09:50:05 --> Hooks Class Initialized
DEBUG - 2011-04-07 09:50:05 --> Utf8 Class Initialized
DEBUG - 2011-04-07 09:50:05 --> UTF-8 Support Enabled
DEBUG - 2011-04-07 09:50:05 --> URI Class Initialized
DEBUG - 2011-04-07 09:50:05 --> Router Class Initialized
DEBUG - 2011-04-07 09:50:05 --> Output Class Initialized
DEBUG - 2011-04-07 09:50:05 --> Input Class Initialized
DEBUG - 2011-04-07 09:50:05 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-07 09:50:05 --> Language Class Initialized
DEBUG - 2011-04-07 09:50:05 --> Loader Class Initialized
DEBUG - 2011-04-07 09:50:05 --> Controller Class Initialized
DEBUG - 2011-04-07 09:50:05 --> Model Class Initialized
DEBUG - 2011-04-07 09:50:05 --> Model Class Initialized
DEBUG - 2011-04-07 09:50:05 --> Model Class Initialized
DEBUG - 2011-04-07 09:50:05 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-07 09:50:05 --> Database Driver Class Initialized
DEBUG - 2011-04-07 09:50:05 --> File loaded: application/views/table/main.php
DEBUG - 2011-04-07 09:50:05 --> Helper loaded: url_helper
DEBUG - 2011-04-07 09:50:05 --> File loaded: application/views/common/header.php
DEBUG - 2011-04-07 09:50:05 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-04-07 09:50:05 --> File loaded: application/views/common/footer.php
DEBUG - 2011-04-07 09:50:05 --> File loaded: application/views/layout/main.php
DEBUG - 2011-04-07 09:50:05 --> Final output sent to browser
DEBUG - 2011-04-07 09:50:05 --> Total execution time: 0.5765
DEBUG - 2011-04-07 09:50:06 --> Config Class Initialized
DEBUG - 2011-04-07 09:50:06 --> Hooks Class Initialized
DEBUG - 2011-04-07 09:50:06 --> Utf8 Class Initialized
DEBUG - 2011-04-07 09:50:06 --> UTF-8 Support Enabled
DEBUG - 2011-04-07 09:50:06 --> URI Class Initialized
DEBUG - 2011-04-07 09:50:06 --> Router Class Initialized
DEBUG - 2011-04-07 09:50:06 --> Output Class Initialized
DEBUG - 2011-04-07 09:50:06 --> Input Class Initialized
DEBUG - 2011-04-07 09:50:06 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-07 09:50:06 --> Language Class Initialized
DEBUG - 2011-04-07 09:50:06 --> Loader Class Initialized
DEBUG - 2011-04-07 09:50:06 --> Controller Class Initialized
DEBUG - 2011-04-07 09:50:06 --> Model Class Initialized
DEBUG - 2011-04-07 09:50:06 --> Model Class Initialized
DEBUG - 2011-04-07 09:50:06 --> Model Class Initialized
DEBUG - 2011-04-07 09:50:06 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-07 09:50:06 --> Database Driver Class Initialized
DEBUG - 2011-04-07 09:50:07 --> File loaded: application/views/table/main.php
DEBUG - 2011-04-07 09:50:07 --> Helper loaded: url_helper
DEBUG - 2011-04-07 09:50:07 --> File loaded: application/views/common/header.php
DEBUG - 2011-04-07 09:50:07 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-04-07 09:50:07 --> File loaded: application/views/common/footer.php
DEBUG - 2011-04-07 09:50:07 --> File loaded: application/views/layout/main.php
DEBUG - 2011-04-07 09:50:07 --> Final output sent to browser
DEBUG - 2011-04-07 09:50:07 --> Total execution time: 1.5042
DEBUG - 2011-04-07 09:50:07 --> File loaded: application/views/table/main.php
DEBUG - 2011-04-07 09:50:07 --> Helper loaded: url_helper
DEBUG - 2011-04-07 09:50:07 --> File loaded: application/views/common/header.php
DEBUG - 2011-04-07 09:50:07 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-04-07 09:50:07 --> File loaded: application/views/common/footer.php
DEBUG - 2011-04-07 09:50:07 --> File loaded: application/views/layout/main.php
DEBUG - 2011-04-07 09:50:07 --> Final output sent to browser
DEBUG - 2011-04-07 09:50:07 --> Total execution time: 1.1194
DEBUG - 2011-04-07 09:50:07 --> Config Class Initialized
DEBUG - 2011-04-07 09:50:07 --> Hooks Class Initialized
DEBUG - 2011-04-07 09:50:07 --> Utf8 Class Initialized
DEBUG - 2011-04-07 09:50:07 --> UTF-8 Support Enabled
DEBUG - 2011-04-07 09:50:07 --> URI Class Initialized
DEBUG - 2011-04-07 09:50:07 --> Router Class Initialized
DEBUG - 2011-04-07 09:50:07 --> Output Class Initialized
DEBUG - 2011-04-07 09:50:07 --> Input Class Initialized
DEBUG - 2011-04-07 09:50:07 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-07 09:50:07 --> Language Class Initialized
DEBUG - 2011-04-07 09:50:07 --> Loader Class Initialized
DEBUG - 2011-04-07 09:50:07 --> Controller Class Initialized
DEBUG - 2011-04-07 09:50:07 --> Model Class Initialized
DEBUG - 2011-04-07 09:50:07 --> Model Class Initialized
DEBUG - 2011-04-07 09:50:07 --> Model Class Initialized
DEBUG - 2011-04-07 09:50:07 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-07 09:50:07 --> Database Driver Class Initialized
DEBUG - 2011-04-07 09:50:09 --> File loaded: application/views/table/main.php
DEBUG - 2011-04-07 09:50:09 --> Helper loaded: url_helper
DEBUG - 2011-04-07 09:50:09 --> File loaded: application/views/common/header.php
DEBUG - 2011-04-07 09:50:09 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-04-07 09:50:09 --> File loaded: application/views/common/footer.php
DEBUG - 2011-04-07 09:50:09 --> File loaded: application/views/layout/main.php
DEBUG - 2011-04-07 09:50:09 --> Final output sent to browser
DEBUG - 2011-04-07 09:50:09 --> Total execution time: 1.4497
DEBUG - 2011-04-07 09:50:25 --> Config Class Initialized
DEBUG - 2011-04-07 09:50:25 --> Hooks Class Initialized
DEBUG - 2011-04-07 09:50:25 --> Utf8 Class Initialized
DEBUG - 2011-04-07 09:50:25 --> UTF-8 Support Enabled
DEBUG - 2011-04-07 09:50:25 --> URI Class Initialized
DEBUG - 2011-04-07 09:50:25 --> Router Class Initialized
DEBUG - 2011-04-07 09:50:25 --> Output Class Initialized
DEBUG - 2011-04-07 09:50:25 --> Input Class Initialized
DEBUG - 2011-04-07 09:50:25 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-07 09:50:25 --> Language Class Initialized
DEBUG - 2011-04-07 09:50:25 --> Loader Class Initialized
DEBUG - 2011-04-07 09:50:25 --> Controller Class Initialized
DEBUG - 2011-04-07 09:50:25 --> Model Class Initialized
DEBUG - 2011-04-07 09:50:25 --> Model Class Initialized
DEBUG - 2011-04-07 09:50:25 --> Model Class Initialized
DEBUG - 2011-04-07 09:50:25 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-07 09:50:25 --> Database Driver Class Initialized
DEBUG - 2011-04-07 09:50:25 --> File loaded: application/views/table/main.php
DEBUG - 2011-04-07 09:50:25 --> Helper loaded: url_helper
DEBUG - 2011-04-07 09:50:25 --> File loaded: application/views/common/header.php
DEBUG - 2011-04-07 09:50:25 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-04-07 09:50:25 --> File loaded: application/views/common/footer.php
DEBUG - 2011-04-07 09:50:25 --> File loaded: application/views/layout/main.php
DEBUG - 2011-04-07 09:50:25 --> Final output sent to browser
DEBUG - 2011-04-07 09:50:25 --> Total execution time: 0.4788
DEBUG - 2011-04-07 09:59:09 --> Config Class Initialized
DEBUG - 2011-04-07 09:59:09 --> Hooks Class Initialized
DEBUG - 2011-04-07 09:59:09 --> Utf8 Class Initialized
DEBUG - 2011-04-07 09:59:09 --> UTF-8 Support Enabled
DEBUG - 2011-04-07 09:59:09 --> URI Class Initialized
DEBUG - 2011-04-07 09:59:09 --> Router Class Initialized
DEBUG - 2011-04-07 09:59:09 --> Output Class Initialized
DEBUG - 2011-04-07 09:59:09 --> Input Class Initialized
DEBUG - 2011-04-07 09:59:09 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-07 09:59:09 --> Language Class Initialized
DEBUG - 2011-04-07 09:59:09 --> Loader Class Initialized
DEBUG - 2011-04-07 09:59:09 --> Controller Class Initialized
DEBUG - 2011-04-07 09:59:09 --> Model Class Initialized
DEBUG - 2011-04-07 09:59:09 --> Model Class Initialized
DEBUG - 2011-04-07 09:59:09 --> Model Class Initialized
DEBUG - 2011-04-07 09:59:09 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-07 09:59:09 --> Database Driver Class Initialized
DEBUG - 2011-04-07 09:59:10 --> File loaded: application/views/table/main.php
DEBUG - 2011-04-07 09:59:10 --> Helper loaded: url_helper
DEBUG - 2011-04-07 09:59:10 --> File loaded: application/views/common/header.php
DEBUG - 2011-04-07 09:59:10 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-04-07 09:59:10 --> File loaded: application/views/common/footer.php
DEBUG - 2011-04-07 09:59:10 --> File loaded: application/views/layout/main.php
DEBUG - 2011-04-07 09:59:10 --> Final output sent to browser
DEBUG - 2011-04-07 09:59:10 --> Total execution time: 1.3040
DEBUG - 2011-04-07 09:59:11 --> Config Class Initialized
DEBUG - 2011-04-07 09:59:11 --> Hooks Class Initialized
DEBUG - 2011-04-07 09:59:11 --> Utf8 Class Initialized
DEBUG - 2011-04-07 09:59:11 --> UTF-8 Support Enabled
DEBUG - 2011-04-07 09:59:11 --> URI Class Initialized
DEBUG - 2011-04-07 09:59:11 --> Router Class Initialized
ERROR - 2011-04-07 09:59:11 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-04-07 09:59:11 --> Config Class Initialized
DEBUG - 2011-04-07 09:59:11 --> Hooks Class Initialized
DEBUG - 2011-04-07 09:59:11 --> Utf8 Class Initialized
DEBUG - 2011-04-07 09:59:11 --> UTF-8 Support Enabled
DEBUG - 2011-04-07 09:59:11 --> URI Class Initialized
DEBUG - 2011-04-07 09:59:11 --> Router Class Initialized
DEBUG - 2011-04-07 09:59:11 --> Output Class Initialized
DEBUG - 2011-04-07 09:59:11 --> Input Class Initialized
DEBUG - 2011-04-07 09:59:11 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-07 09:59:11 --> Language Class Initialized
DEBUG - 2011-04-07 09:59:11 --> Loader Class Initialized
DEBUG - 2011-04-07 09:59:11 --> Controller Class Initialized
DEBUG - 2011-04-07 09:59:11 --> Model Class Initialized
DEBUG - 2011-04-07 09:59:11 --> Model Class Initialized
DEBUG - 2011-04-07 09:59:11 --> Model Class Initialized
DEBUG - 2011-04-07 09:59:11 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-07 09:59:11 --> Database Driver Class Initialized
DEBUG - 2011-04-07 09:59:11 --> File loaded: application/views/table/main.php
DEBUG - 2011-04-07 09:59:11 --> Helper loaded: url_helper
DEBUG - 2011-04-07 09:59:11 --> File loaded: application/views/common/header.php
DEBUG - 2011-04-07 09:59:11 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-04-07 09:59:11 --> File loaded: application/views/common/footer.php
DEBUG - 2011-04-07 09:59:11 --> File loaded: application/views/layout/main.php
DEBUG - 2011-04-07 09:59:11 --> Final output sent to browser
DEBUG - 2011-04-07 09:59:11 --> Total execution time: 0.0680
DEBUG - 2011-04-07 09:59:17 --> Config Class Initialized
DEBUG - 2011-04-07 09:59:17 --> Hooks Class Initialized
DEBUG - 2011-04-07 09:59:17 --> Utf8 Class Initialized
DEBUG - 2011-04-07 09:59:17 --> UTF-8 Support Enabled
DEBUG - 2011-04-07 09:59:17 --> URI Class Initialized
DEBUG - 2011-04-07 09:59:17 --> Router Class Initialized
DEBUG - 2011-04-07 09:59:17 --> Output Class Initialized
DEBUG - 2011-04-07 09:59:17 --> Input Class Initialized
DEBUG - 2011-04-07 09:59:17 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-07 09:59:17 --> Language Class Initialized
DEBUG - 2011-04-07 09:59:17 --> Loader Class Initialized
DEBUG - 2011-04-07 09:59:17 --> Controller Class Initialized
DEBUG - 2011-04-07 09:59:17 --> Model Class Initialized
DEBUG - 2011-04-07 09:59:17 --> Model Class Initialized
DEBUG - 2011-04-07 09:59:17 --> Model Class Initialized
DEBUG - 2011-04-07 09:59:17 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-07 09:59:17 --> Database Driver Class Initialized
DEBUG - 2011-04-07 09:59:17 --> File loaded: application/views/table/main.php
DEBUG - 2011-04-07 09:59:17 --> Helper loaded: url_helper
DEBUG - 2011-04-07 09:59:17 --> File loaded: application/views/common/header.php
DEBUG - 2011-04-07 09:59:17 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-04-07 09:59:17 --> File loaded: application/views/common/footer.php
DEBUG - 2011-04-07 09:59:17 --> File loaded: application/views/layout/main.php
DEBUG - 2011-04-07 09:59:17 --> Final output sent to browser
DEBUG - 2011-04-07 09:59:17 --> Total execution time: 0.3859
DEBUG - 2011-04-07 09:59:19 --> Config Class Initialized
DEBUG - 2011-04-07 09:59:19 --> Hooks Class Initialized
DEBUG - 2011-04-07 09:59:19 --> Utf8 Class Initialized
DEBUG - 2011-04-07 09:59:19 --> UTF-8 Support Enabled
DEBUG - 2011-04-07 09:59:19 --> URI Class Initialized
DEBUG - 2011-04-07 09:59:19 --> Router Class Initialized
DEBUG - 2011-04-07 09:59:19 --> Output Class Initialized
DEBUG - 2011-04-07 09:59:19 --> Input Class Initialized
DEBUG - 2011-04-07 09:59:19 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-07 09:59:19 --> Language Class Initialized
DEBUG - 2011-04-07 09:59:19 --> Loader Class Initialized
DEBUG - 2011-04-07 09:59:19 --> Controller Class Initialized
DEBUG - 2011-04-07 09:59:19 --> Model Class Initialized
DEBUG - 2011-04-07 09:59:19 --> Model Class Initialized
DEBUG - 2011-04-07 09:59:19 --> Model Class Initialized
DEBUG - 2011-04-07 09:59:19 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-07 09:59:19 --> Config Class Initialized
DEBUG - 2011-04-07 09:59:19 --> Hooks Class Initialized
DEBUG - 2011-04-07 09:59:19 --> Utf8 Class Initialized
DEBUG - 2011-04-07 09:59:19 --> UTF-8 Support Enabled
DEBUG - 2011-04-07 09:59:19 --> Database Driver Class Initialized
DEBUG - 2011-04-07 09:59:19 --> URI Class Initialized
DEBUG - 2011-04-07 09:59:19 --> Router Class Initialized
ERROR - 2011-04-07 09:59:19 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-04-07 09:59:19 --> File loaded: application/views/table/main.php
DEBUG - 2011-04-07 09:59:19 --> Helper loaded: url_helper
DEBUG - 2011-04-07 09:59:19 --> File loaded: application/views/common/header.php
DEBUG - 2011-04-07 09:59:19 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-04-07 09:59:19 --> File loaded: application/views/common/footer.php
DEBUG - 2011-04-07 09:59:19 --> File loaded: application/views/layout/main.php
DEBUG - 2011-04-07 09:59:19 --> Final output sent to browser
DEBUG - 2011-04-07 09:59:19 --> Total execution time: 0.1545
DEBUG - 2011-04-07 09:59:21 --> Config Class Initialized
DEBUG - 2011-04-07 09:59:21 --> Hooks Class Initialized
DEBUG - 2011-04-07 09:59:21 --> Utf8 Class Initialized
DEBUG - 2011-04-07 09:59:21 --> UTF-8 Support Enabled
DEBUG - 2011-04-07 09:59:21 --> URI Class Initialized
DEBUG - 2011-04-07 09:59:21 --> Router Class Initialized
DEBUG - 2011-04-07 09:59:21 --> Output Class Initialized
DEBUG - 2011-04-07 09:59:21 --> Input Class Initialized
DEBUG - 2011-04-07 09:59:21 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-07 09:59:21 --> Language Class Initialized
DEBUG - 2011-04-07 09:59:21 --> Loader Class Initialized
DEBUG - 2011-04-07 09:59:21 --> Controller Class Initialized
DEBUG - 2011-04-07 09:59:21 --> Model Class Initialized
DEBUG - 2011-04-07 09:59:21 --> Model Class Initialized
DEBUG - 2011-04-07 09:59:21 --> Model Class Initialized
DEBUG - 2011-04-07 09:59:21 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-07 09:59:22 --> Database Driver Class Initialized
DEBUG - 2011-04-07 09:59:22 --> File loaded: application/views/table/main.php
DEBUG - 2011-04-07 09:59:22 --> Helper loaded: url_helper
DEBUG - 2011-04-07 09:59:22 --> File loaded: application/views/common/header.php
DEBUG - 2011-04-07 09:59:22 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-04-07 09:59:22 --> File loaded: application/views/common/footer.php
DEBUG - 2011-04-07 09:59:22 --> File loaded: application/views/layout/main.php
DEBUG - 2011-04-07 09:59:22 --> Final output sent to browser
DEBUG - 2011-04-07 09:59:22 --> Total execution time: 0.2364
DEBUG - 2011-04-07 09:59:23 --> Config Class Initialized
DEBUG - 2011-04-07 09:59:23 --> Hooks Class Initialized
DEBUG - 2011-04-07 09:59:23 --> Utf8 Class Initialized
DEBUG - 2011-04-07 09:59:23 --> UTF-8 Support Enabled
DEBUG - 2011-04-07 09:59:23 --> URI Class Initialized
DEBUG - 2011-04-07 09:59:23 --> Router Class Initialized
DEBUG - 2011-04-07 09:59:23 --> Output Class Initialized
DEBUG - 2011-04-07 09:59:23 --> Input Class Initialized
DEBUG - 2011-04-07 09:59:23 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-07 09:59:23 --> Language Class Initialized
DEBUG - 2011-04-07 09:59:23 --> Loader Class Initialized
DEBUG - 2011-04-07 09:59:23 --> Controller Class Initialized
DEBUG - 2011-04-07 09:59:23 --> Model Class Initialized
DEBUG - 2011-04-07 09:59:23 --> Model Class Initialized
DEBUG - 2011-04-07 09:59:23 --> Model Class Initialized
DEBUG - 2011-04-07 09:59:23 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-07 09:59:23 --> Database Driver Class Initialized
DEBUG - 2011-04-07 09:59:23 --> File loaded: application/views/table/main.php
DEBUG - 2011-04-07 09:59:23 --> Helper loaded: url_helper
DEBUG - 2011-04-07 09:59:23 --> File loaded: application/views/common/header.php
DEBUG - 2011-04-07 09:59:23 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-04-07 09:59:23 --> File loaded: application/views/common/footer.php
DEBUG - 2011-04-07 09:59:23 --> File loaded: application/views/layout/main.php
DEBUG - 2011-04-07 09:59:23 --> Final output sent to browser
DEBUG - 2011-04-07 09:59:23 --> Total execution time: 0.0851
DEBUG - 2011-04-07 09:59:23 --> Config Class Initialized
DEBUG - 2011-04-07 09:59:23 --> Hooks Class Initialized
DEBUG - 2011-04-07 09:59:23 --> Utf8 Class Initialized
DEBUG - 2011-04-07 09:59:23 --> UTF-8 Support Enabled
DEBUG - 2011-04-07 09:59:23 --> URI Class Initialized
DEBUG - 2011-04-07 09:59:23 --> Router Class Initialized
ERROR - 2011-04-07 09:59:23 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-04-07 09:59:27 --> Config Class Initialized
DEBUG - 2011-04-07 09:59:27 --> Hooks Class Initialized
DEBUG - 2011-04-07 09:59:27 --> Utf8 Class Initialized
DEBUG - 2011-04-07 09:59:27 --> UTF-8 Support Enabled
DEBUG - 2011-04-07 09:59:27 --> URI Class Initialized
DEBUG - 2011-04-07 09:59:27 --> Router Class Initialized
DEBUG - 2011-04-07 09:59:27 --> Output Class Initialized
DEBUG - 2011-04-07 09:59:27 --> Input Class Initialized
DEBUG - 2011-04-07 09:59:27 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-07 09:59:27 --> Language Class Initialized
DEBUG - 2011-04-07 09:59:27 --> Loader Class Initialized
DEBUG - 2011-04-07 09:59:27 --> Controller Class Initialized
DEBUG - 2011-04-07 09:59:27 --> Model Class Initialized
DEBUG - 2011-04-07 09:59:27 --> Model Class Initialized
DEBUG - 2011-04-07 09:59:27 --> Model Class Initialized
DEBUG - 2011-04-07 09:59:27 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-07 09:59:27 --> Database Driver Class Initialized
DEBUG - 2011-04-07 09:59:27 --> File loaded: application/views/table/main.php
DEBUG - 2011-04-07 09:59:27 --> Helper loaded: url_helper
DEBUG - 2011-04-07 09:59:27 --> File loaded: application/views/common/header.php
DEBUG - 2011-04-07 09:59:27 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-04-07 09:59:27 --> File loaded: application/views/common/footer.php
DEBUG - 2011-04-07 09:59:27 --> File loaded: application/views/layout/main.php
DEBUG - 2011-04-07 09:59:27 --> Final output sent to browser
DEBUG - 2011-04-07 09:59:27 --> Total execution time: 0.1045
DEBUG - 2011-04-07 09:59:28 --> Config Class Initialized
DEBUG - 2011-04-07 09:59:28 --> Hooks Class Initialized
DEBUG - 2011-04-07 09:59:28 --> Utf8 Class Initialized
DEBUG - 2011-04-07 09:59:28 --> UTF-8 Support Enabled
DEBUG - 2011-04-07 09:59:28 --> URI Class Initialized
DEBUG - 2011-04-07 09:59:28 --> Router Class Initialized
ERROR - 2011-04-07 09:59:28 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-04-07 10:00:29 --> Config Class Initialized
DEBUG - 2011-04-07 10:00:29 --> Hooks Class Initialized
DEBUG - 2011-04-07 10:00:29 --> Utf8 Class Initialized
DEBUG - 2011-04-07 10:00:29 --> UTF-8 Support Enabled
DEBUG - 2011-04-07 10:00:29 --> URI Class Initialized
DEBUG - 2011-04-07 10:00:29 --> Router Class Initialized
DEBUG - 2011-04-07 10:00:29 --> Output Class Initialized
DEBUG - 2011-04-07 10:00:29 --> Input Class Initialized
DEBUG - 2011-04-07 10:00:29 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-07 10:00:29 --> Language Class Initialized
DEBUG - 2011-04-07 10:00:29 --> Loader Class Initialized
DEBUG - 2011-04-07 10:00:29 --> Controller Class Initialized
ERROR - 2011-04-07 10:00:29 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-04-07 10:00:29 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-04-07 10:00:29 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-04-07 10:00:29 --> Model Class Initialized
DEBUG - 2011-04-07 10:00:29 --> Model Class Initialized
DEBUG - 2011-04-07 10:00:29 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-07 10:00:29 --> Database Driver Class Initialized
DEBUG - 2011-04-07 10:00:29 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-04-07 10:00:29 --> Helper loaded: url_helper
DEBUG - 2011-04-07 10:00:29 --> File loaded: application/views/common/header.php
DEBUG - 2011-04-07 10:00:29 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-04-07 10:00:29 --> File loaded: application/views/common/footer.php
DEBUG - 2011-04-07 10:00:29 --> File loaded: application/views/layout/main.php
DEBUG - 2011-04-07 10:00:29 --> Final output sent to browser
DEBUG - 2011-04-07 10:00:29 --> Total execution time: 0.3277
DEBUG - 2011-04-07 10:21:35 --> Config Class Initialized
DEBUG - 2011-04-07 10:21:35 --> Hooks Class Initialized
DEBUG - 2011-04-07 10:21:35 --> Utf8 Class Initialized
DEBUG - 2011-04-07 10:21:35 --> UTF-8 Support Enabled
DEBUG - 2011-04-07 10:21:35 --> URI Class Initialized
DEBUG - 2011-04-07 10:21:35 --> Router Class Initialized
DEBUG - 2011-04-07 10:21:35 --> Output Class Initialized
DEBUG - 2011-04-07 10:21:35 --> Input Class Initialized
DEBUG - 2011-04-07 10:21:35 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-07 10:21:35 --> Language Class Initialized
DEBUG - 2011-04-07 10:21:35 --> Loader Class Initialized
DEBUG - 2011-04-07 10:21:35 --> Controller Class Initialized
DEBUG - 2011-04-07 10:21:35 --> Model Class Initialized
DEBUG - 2011-04-07 10:21:35 --> Model Class Initialized
DEBUG - 2011-04-07 10:21:35 --> Model Class Initialized
DEBUG - 2011-04-07 10:21:35 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-07 10:21:36 --> Database Driver Class Initialized
DEBUG - 2011-04-07 10:21:37 --> File loaded: application/views/table/main.php
DEBUG - 2011-04-07 10:21:38 --> Helper loaded: url_helper
DEBUG - 2011-04-07 10:21:38 --> File loaded: application/views/common/header.php
DEBUG - 2011-04-07 10:21:38 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-04-07 10:21:38 --> File loaded: application/views/common/footer.php
DEBUG - 2011-04-07 10:21:38 --> File loaded: application/views/layout/main.php
DEBUG - 2011-04-07 10:21:38 --> Final output sent to browser
DEBUG - 2011-04-07 10:21:38 --> Total execution time: 3.4161
DEBUG - 2011-04-07 10:21:42 --> Config Class Initialized
DEBUG - 2011-04-07 10:21:42 --> Hooks Class Initialized
DEBUG - 2011-04-07 10:21:42 --> Utf8 Class Initialized
DEBUG - 2011-04-07 10:21:42 --> UTF-8 Support Enabled
DEBUG - 2011-04-07 10:21:42 --> URI Class Initialized
DEBUG - 2011-04-07 10:21:42 --> Router Class Initialized
ERROR - 2011-04-07 10:21:42 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-04-07 10:52:43 --> Config Class Initialized
DEBUG - 2011-04-07 10:52:43 --> Hooks Class Initialized
DEBUG - 2011-04-07 10:52:43 --> Utf8 Class Initialized
DEBUG - 2011-04-07 10:52:43 --> UTF-8 Support Enabled
DEBUG - 2011-04-07 10:52:43 --> URI Class Initialized
DEBUG - 2011-04-07 10:52:43 --> Router Class Initialized
DEBUG - 2011-04-07 10:52:43 --> Output Class Initialized
DEBUG - 2011-04-07 10:52:43 --> Input Class Initialized
DEBUG - 2011-04-07 10:52:43 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-07 10:52:43 --> Language Class Initialized
DEBUG - 2011-04-07 10:52:43 --> Loader Class Initialized
DEBUG - 2011-04-07 10:52:43 --> Controller Class Initialized
DEBUG - 2011-04-07 10:52:43 --> Model Class Initialized
DEBUG - 2011-04-07 10:52:43 --> Model Class Initialized
DEBUG - 2011-04-07 10:52:43 --> Model Class Initialized
DEBUG - 2011-04-07 10:52:43 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-07 10:52:43 --> Database Driver Class Initialized
DEBUG - 2011-04-07 10:52:43 --> File loaded: application/views/table/main.php
DEBUG - 2011-04-07 10:52:43 --> Helper loaded: url_helper
DEBUG - 2011-04-07 10:52:43 --> File loaded: application/views/common/header.php
DEBUG - 2011-04-07 10:52:43 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-04-07 10:52:43 --> File loaded: application/views/common/footer.php
DEBUG - 2011-04-07 10:52:43 --> File loaded: application/views/layout/main.php
DEBUG - 2011-04-07 10:52:43 --> Final output sent to browser
DEBUG - 2011-04-07 10:52:43 --> Total execution time: 0.5745
DEBUG - 2011-04-07 10:52:46 --> Config Class Initialized
DEBUG - 2011-04-07 10:52:46 --> Hooks Class Initialized
DEBUG - 2011-04-07 10:52:46 --> Utf8 Class Initialized
DEBUG - 2011-04-07 10:52:46 --> UTF-8 Support Enabled
DEBUG - 2011-04-07 10:52:46 --> URI Class Initialized
DEBUG - 2011-04-07 10:52:46 --> Router Class Initialized
ERROR - 2011-04-07 10:52:46 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-04-07 10:52:47 --> Config Class Initialized
DEBUG - 2011-04-07 10:52:47 --> Hooks Class Initialized
DEBUG - 2011-04-07 10:52:47 --> Utf8 Class Initialized
DEBUG - 2011-04-07 10:52:47 --> UTF-8 Support Enabled
DEBUG - 2011-04-07 10:52:47 --> URI Class Initialized
DEBUG - 2011-04-07 10:52:47 --> Router Class Initialized
ERROR - 2011-04-07 10:52:47 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-04-07 10:53:10 --> Config Class Initialized
DEBUG - 2011-04-07 10:53:10 --> Hooks Class Initialized
DEBUG - 2011-04-07 10:53:10 --> Utf8 Class Initialized
DEBUG - 2011-04-07 10:53:10 --> UTF-8 Support Enabled
DEBUG - 2011-04-07 10:53:10 --> URI Class Initialized
DEBUG - 2011-04-07 10:53:10 --> Router Class Initialized
DEBUG - 2011-04-07 10:53:10 --> Output Class Initialized
DEBUG - 2011-04-07 10:53:10 --> Input Class Initialized
DEBUG - 2011-04-07 10:53:10 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-07 10:53:10 --> Language Class Initialized
DEBUG - 2011-04-07 10:53:10 --> Loader Class Initialized
DEBUG - 2011-04-07 10:53:10 --> Controller Class Initialized
DEBUG - 2011-04-07 10:53:10 --> Model Class Initialized
DEBUG - 2011-04-07 10:53:10 --> Model Class Initialized
DEBUG - 2011-04-07 10:53:10 --> Model Class Initialized
DEBUG - 2011-04-07 10:53:10 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-07 10:53:10 --> Database Driver Class Initialized
DEBUG - 2011-04-07 10:53:10 --> File loaded: application/views/table/main.php
DEBUG - 2011-04-07 10:53:10 --> Helper loaded: url_helper
DEBUG - 2011-04-07 10:53:10 --> File loaded: application/views/common/header.php
DEBUG - 2011-04-07 10:53:10 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-04-07 10:53:10 --> File loaded: application/views/common/footer.php
DEBUG - 2011-04-07 10:53:10 --> File loaded: application/views/layout/main.php
DEBUG - 2011-04-07 10:53:10 --> Final output sent to browser
DEBUG - 2011-04-07 10:53:10 --> Total execution time: 0.2300
DEBUG - 2011-04-07 10:53:11 --> Config Class Initialized
DEBUG - 2011-04-07 10:53:11 --> Hooks Class Initialized
DEBUG - 2011-04-07 10:53:11 --> Utf8 Class Initialized
DEBUG - 2011-04-07 10:53:11 --> UTF-8 Support Enabled
DEBUG - 2011-04-07 10:53:11 --> URI Class Initialized
DEBUG - 2011-04-07 10:53:11 --> Router Class Initialized
DEBUG - 2011-04-07 10:53:11 --> Output Class Initialized
DEBUG - 2011-04-07 10:53:11 --> Input Class Initialized
DEBUG - 2011-04-07 10:53:11 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-07 10:53:11 --> Language Class Initialized
DEBUG - 2011-04-07 10:53:11 --> Loader Class Initialized
DEBUG - 2011-04-07 10:53:11 --> Controller Class Initialized
DEBUG - 2011-04-07 10:53:11 --> Model Class Initialized
DEBUG - 2011-04-07 10:53:11 --> Model Class Initialized
DEBUG - 2011-04-07 10:53:11 --> Model Class Initialized
DEBUG - 2011-04-07 10:53:11 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-07 10:53:11 --> Database Driver Class Initialized
DEBUG - 2011-04-07 10:53:11 --> File loaded: application/views/table/main.php
DEBUG - 2011-04-07 10:53:11 --> Helper loaded: url_helper
DEBUG - 2011-04-07 10:53:11 --> File loaded: application/views/common/header.php
DEBUG - 2011-04-07 10:53:11 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-04-07 10:53:11 --> File loaded: application/views/common/footer.php
DEBUG - 2011-04-07 10:53:11 --> File loaded: application/views/layout/main.php
DEBUG - 2011-04-07 10:53:11 --> Final output sent to browser
DEBUG - 2011-04-07 10:53:11 --> Total execution time: 0.1499
DEBUG - 2011-04-07 10:53:11 --> Config Class Initialized
DEBUG - 2011-04-07 10:53:11 --> Hooks Class Initialized
DEBUG - 2011-04-07 10:53:11 --> Utf8 Class Initialized
DEBUG - 2011-04-07 10:53:11 --> UTF-8 Support Enabled
DEBUG - 2011-04-07 10:53:11 --> URI Class Initialized
DEBUG - 2011-04-07 10:53:11 --> Router Class Initialized
ERROR - 2011-04-07 10:53:11 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-04-07 10:53:15 --> Config Class Initialized
DEBUG - 2011-04-07 10:53:15 --> Hooks Class Initialized
DEBUG - 2011-04-07 10:53:15 --> Utf8 Class Initialized
DEBUG - 2011-04-07 10:53:15 --> UTF-8 Support Enabled
DEBUG - 2011-04-07 10:53:15 --> URI Class Initialized
DEBUG - 2011-04-07 10:53:15 --> Router Class Initialized
ERROR - 2011-04-07 10:53:15 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-04-07 10:53:31 --> Config Class Initialized
DEBUG - 2011-04-07 10:53:31 --> Hooks Class Initialized
DEBUG - 2011-04-07 10:53:31 --> Utf8 Class Initialized
DEBUG - 2011-04-07 10:53:31 --> UTF-8 Support Enabled
DEBUG - 2011-04-07 10:53:31 --> URI Class Initialized
DEBUG - 2011-04-07 10:53:31 --> Router Class Initialized
DEBUG - 2011-04-07 10:53:31 --> Output Class Initialized
DEBUG - 2011-04-07 10:53:31 --> Input Class Initialized
DEBUG - 2011-04-07 10:53:31 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-07 10:53:31 --> Language Class Initialized
DEBUG - 2011-04-07 10:53:31 --> Loader Class Initialized
DEBUG - 2011-04-07 10:53:31 --> Controller Class Initialized
ERROR - 2011-04-07 10:53:31 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-04-07 10:53:31 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-04-07 10:53:31 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-04-07 10:53:31 --> Model Class Initialized
DEBUG - 2011-04-07 10:53:31 --> Model Class Initialized
DEBUG - 2011-04-07 10:53:31 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-07 10:53:31 --> Database Driver Class Initialized
DEBUG - 2011-04-07 10:53:31 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-04-07 10:53:31 --> Helper loaded: url_helper
DEBUG - 2011-04-07 10:53:31 --> File loaded: application/views/common/header.php
DEBUG - 2011-04-07 10:53:31 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-04-07 10:53:31 --> File loaded: application/views/common/footer.php
DEBUG - 2011-04-07 10:53:31 --> File loaded: application/views/layout/main.php
DEBUG - 2011-04-07 10:53:31 --> Final output sent to browser
DEBUG - 2011-04-07 10:53:31 --> Total execution time: 0.0953
DEBUG - 2011-04-07 10:53:32 --> Config Class Initialized
DEBUG - 2011-04-07 10:53:32 --> Hooks Class Initialized
DEBUG - 2011-04-07 10:53:32 --> Utf8 Class Initialized
DEBUG - 2011-04-07 10:53:32 --> UTF-8 Support Enabled
DEBUG - 2011-04-07 10:53:32 --> URI Class Initialized
DEBUG - 2011-04-07 10:53:32 --> Router Class Initialized
DEBUG - 2011-04-07 10:53:32 --> Output Class Initialized
DEBUG - 2011-04-07 10:53:32 --> Input Class Initialized
DEBUG - 2011-04-07 10:53:32 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-07 10:53:32 --> Language Class Initialized
DEBUG - 2011-04-07 10:53:32 --> Loader Class Initialized
DEBUG - 2011-04-07 10:53:32 --> Controller Class Initialized
DEBUG - 2011-04-07 10:53:32 --> Model Class Initialized
DEBUG - 2011-04-07 10:53:32 --> Model Class Initialized
DEBUG - 2011-04-07 10:53:32 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-07 10:53:32 --> Database Driver Class Initialized
DEBUG - 2011-04-07 10:53:32 --> Config Class Initialized
DEBUG - 2011-04-07 10:53:32 --> Hooks Class Initialized
DEBUG - 2011-04-07 10:53:32 --> Utf8 Class Initialized
DEBUG - 2011-04-07 10:53:32 --> UTF-8 Support Enabled
DEBUG - 2011-04-07 10:53:32 --> URI Class Initialized
DEBUG - 2011-04-07 10:53:32 --> Router Class Initialized
DEBUG - 2011-04-07 10:53:32 --> Output Class Initialized
DEBUG - 2011-04-07 10:53:32 --> Input Class Initialized
DEBUG - 2011-04-07 10:53:32 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-07 10:53:32 --> Language Class Initialized
DEBUG - 2011-04-07 10:53:32 --> Loader Class Initialized
DEBUG - 2011-04-07 10:53:32 --> Controller Class Initialized
ERROR - 2011-04-07 10:53:32 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-04-07 10:53:32 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-04-07 10:53:32 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-04-07 10:53:32 --> Model Class Initialized
DEBUG - 2011-04-07 10:53:32 --> Model Class Initialized
DEBUG - 2011-04-07 10:53:32 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-07 10:53:32 --> Database Driver Class Initialized
DEBUG - 2011-04-07 10:53:33 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-04-07 10:53:33 --> Helper loaded: url_helper
DEBUG - 2011-04-07 10:53:33 --> File loaded: application/views/common/header.php
DEBUG - 2011-04-07 10:53:33 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-04-07 10:53:33 --> File loaded: application/views/common/footer.php
DEBUG - 2011-04-07 10:53:33 --> File loaded: application/views/layout/main.php
DEBUG - 2011-04-07 10:53:33 --> Final output sent to browser
DEBUG - 2011-04-07 10:53:33 --> Total execution time: 0.0352
DEBUG - 2011-04-07 10:53:33 --> Final output sent to browser
DEBUG - 2011-04-07 10:53:33 --> Total execution time: 0.9606
DEBUG - 2011-04-07 10:53:34 --> Config Class Initialized
DEBUG - 2011-04-07 10:53:34 --> Hooks Class Initialized
DEBUG - 2011-04-07 10:53:34 --> Utf8 Class Initialized
DEBUG - 2011-04-07 10:53:34 --> UTF-8 Support Enabled
DEBUG - 2011-04-07 10:53:34 --> URI Class Initialized
DEBUG - 2011-04-07 10:53:34 --> Router Class Initialized
ERROR - 2011-04-07 10:53:34 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-04-07 10:54:19 --> Config Class Initialized
DEBUG - 2011-04-07 10:54:19 --> Hooks Class Initialized
DEBUG - 2011-04-07 10:54:19 --> Utf8 Class Initialized
DEBUG - 2011-04-07 10:54:19 --> UTF-8 Support Enabled
DEBUG - 2011-04-07 10:54:19 --> URI Class Initialized
DEBUG - 2011-04-07 10:54:19 --> Router Class Initialized
DEBUG - 2011-04-07 10:54:19 --> Output Class Initialized
DEBUG - 2011-04-07 10:54:19 --> Input Class Initialized
DEBUG - 2011-04-07 10:54:19 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-07 10:54:19 --> Language Class Initialized
DEBUG - 2011-04-07 10:54:19 --> Loader Class Initialized
DEBUG - 2011-04-07 10:54:19 --> Controller Class Initialized
ERROR - 2011-04-07 10:54:19 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-04-07 10:54:19 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-04-07 10:54:19 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-04-07 10:54:19 --> Model Class Initialized
DEBUG - 2011-04-07 10:54:19 --> Model Class Initialized
DEBUG - 2011-04-07 10:54:19 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-07 10:54:19 --> Database Driver Class Initialized
DEBUG - 2011-04-07 10:54:19 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-04-07 10:54:19 --> Helper loaded: url_helper
DEBUG - 2011-04-07 10:54:19 --> File loaded: application/views/common/header.php
DEBUG - 2011-04-07 10:54:19 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-04-07 10:54:19 --> File loaded: application/views/common/footer.php
DEBUG - 2011-04-07 10:54:19 --> File loaded: application/views/layout/main.php
DEBUG - 2011-04-07 10:54:19 --> Final output sent to browser
DEBUG - 2011-04-07 10:54:19 --> Total execution time: 0.0940
DEBUG - 2011-04-07 10:54:20 --> Config Class Initialized
DEBUG - 2011-04-07 10:54:20 --> Hooks Class Initialized
DEBUG - 2011-04-07 10:54:20 --> Utf8 Class Initialized
DEBUG - 2011-04-07 10:54:20 --> UTF-8 Support Enabled
DEBUG - 2011-04-07 10:54:20 --> URI Class Initialized
DEBUG - 2011-04-07 10:54:20 --> Router Class Initialized
DEBUG - 2011-04-07 10:54:20 --> Output Class Initialized
DEBUG - 2011-04-07 10:54:20 --> Input Class Initialized
DEBUG - 2011-04-07 10:54:20 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-07 10:54:20 --> Language Class Initialized
DEBUG - 2011-04-07 10:54:20 --> Loader Class Initialized
DEBUG - 2011-04-07 10:54:20 --> Controller Class Initialized
DEBUG - 2011-04-07 10:54:20 --> Model Class Initialized
DEBUG - 2011-04-07 10:54:20 --> Model Class Initialized
DEBUG - 2011-04-07 10:54:20 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-07 10:54:20 --> Database Driver Class Initialized
DEBUG - 2011-04-07 10:54:21 --> Config Class Initialized
DEBUG - 2011-04-07 10:54:21 --> Hooks Class Initialized
DEBUG - 2011-04-07 10:54:21 --> Utf8 Class Initialized
DEBUG - 2011-04-07 10:54:21 --> UTF-8 Support Enabled
DEBUG - 2011-04-07 10:54:21 --> URI Class Initialized
DEBUG - 2011-04-07 10:54:21 --> Router Class Initialized
DEBUG - 2011-04-07 10:54:21 --> Output Class Initialized
DEBUG - 2011-04-07 10:54:21 --> Input Class Initialized
DEBUG - 2011-04-07 10:54:21 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-07 10:54:21 --> Language Class Initialized
DEBUG - 2011-04-07 10:54:21 --> Loader Class Initialized
DEBUG - 2011-04-07 10:54:21 --> Controller Class Initialized
ERROR - 2011-04-07 10:54:21 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-04-07 10:54:21 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-04-07 10:54:21 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-04-07 10:54:21 --> Model Class Initialized
DEBUG - 2011-04-07 10:54:21 --> Model Class Initialized
DEBUG - 2011-04-07 10:54:21 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-07 10:54:21 --> Database Driver Class Initialized
DEBUG - 2011-04-07 10:54:21 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-04-07 10:54:21 --> Helper loaded: url_helper
DEBUG - 2011-04-07 10:54:21 --> File loaded: application/views/common/header.php
DEBUG - 2011-04-07 10:54:21 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-04-07 10:54:21 --> File loaded: application/views/common/footer.php
DEBUG - 2011-04-07 10:54:21 --> File loaded: application/views/layout/main.php
DEBUG - 2011-04-07 10:54:21 --> Final output sent to browser
DEBUG - 2011-04-07 10:54:21 --> Total execution time: 0.0853
DEBUG - 2011-04-07 10:54:23 --> Final output sent to browser
DEBUG - 2011-04-07 10:54:23 --> Total execution time: 3.6860
DEBUG - 2011-04-07 10:54:24 --> Config Class Initialized
DEBUG - 2011-04-07 10:54:24 --> Hooks Class Initialized
DEBUG - 2011-04-07 10:54:24 --> Utf8 Class Initialized
DEBUG - 2011-04-07 10:54:24 --> UTF-8 Support Enabled
DEBUG - 2011-04-07 10:54:24 --> URI Class Initialized
DEBUG - 2011-04-07 10:54:24 --> Router Class Initialized
ERROR - 2011-04-07 10:54:24 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-04-07 10:54:50 --> Config Class Initialized
DEBUG - 2011-04-07 10:54:50 --> Hooks Class Initialized
DEBUG - 2011-04-07 10:54:50 --> Utf8 Class Initialized
DEBUG - 2011-04-07 10:54:50 --> UTF-8 Support Enabled
DEBUG - 2011-04-07 10:54:50 --> URI Class Initialized
DEBUG - 2011-04-07 10:54:50 --> Router Class Initialized
DEBUG - 2011-04-07 10:54:50 --> Output Class Initialized
DEBUG - 2011-04-07 10:54:50 --> Input Class Initialized
DEBUG - 2011-04-07 10:54:50 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-07 10:54:50 --> Language Class Initialized
DEBUG - 2011-04-07 10:54:50 --> Loader Class Initialized
DEBUG - 2011-04-07 10:54:50 --> Controller Class Initialized
ERROR - 2011-04-07 10:54:50 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-04-07 10:54:50 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-04-07 10:54:50 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-04-07 10:54:50 --> Model Class Initialized
DEBUG - 2011-04-07 10:54:50 --> Model Class Initialized
DEBUG - 2011-04-07 10:54:50 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-07 10:54:50 --> Database Driver Class Initialized
DEBUG - 2011-04-07 10:54:50 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-04-07 10:54:50 --> Helper loaded: url_helper
DEBUG - 2011-04-07 10:54:50 --> File loaded: application/views/common/header.php
DEBUG - 2011-04-07 10:54:50 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-04-07 10:54:50 --> File loaded: application/views/common/footer.php
DEBUG - 2011-04-07 10:54:50 --> File loaded: application/views/layout/main.php
DEBUG - 2011-04-07 10:54:50 --> Final output sent to browser
DEBUG - 2011-04-07 10:54:50 --> Total execution time: 0.0320
DEBUG - 2011-04-07 10:54:51 --> Config Class Initialized
DEBUG - 2011-04-07 10:54:51 --> Hooks Class Initialized
DEBUG - 2011-04-07 10:54:51 --> Utf8 Class Initialized
DEBUG - 2011-04-07 10:54:51 --> UTF-8 Support Enabled
DEBUG - 2011-04-07 10:54:51 --> URI Class Initialized
DEBUG - 2011-04-07 10:54:51 --> Router Class Initialized
DEBUG - 2011-04-07 10:54:51 --> Output Class Initialized
DEBUG - 2011-04-07 10:54:51 --> Input Class Initialized
DEBUG - 2011-04-07 10:54:51 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-07 10:54:51 --> Language Class Initialized
DEBUG - 2011-04-07 10:54:51 --> Loader Class Initialized
DEBUG - 2011-04-07 10:54:51 --> Controller Class Initialized
DEBUG - 2011-04-07 10:54:51 --> Model Class Initialized
DEBUG - 2011-04-07 10:54:51 --> Model Class Initialized
DEBUG - 2011-04-07 10:54:51 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-07 10:54:51 --> Database Driver Class Initialized
DEBUG - 2011-04-07 10:54:52 --> Final output sent to browser
DEBUG - 2011-04-07 10:54:52 --> Total execution time: 0.8352
DEBUG - 2011-04-07 10:54:53 --> Config Class Initialized
DEBUG - 2011-04-07 10:54:53 --> Hooks Class Initialized
DEBUG - 2011-04-07 10:54:53 --> Utf8 Class Initialized
DEBUG - 2011-04-07 10:54:53 --> UTF-8 Support Enabled
DEBUG - 2011-04-07 10:54:53 --> URI Class Initialized
DEBUG - 2011-04-07 10:54:53 --> Router Class Initialized
ERROR - 2011-04-07 10:54:53 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-04-07 10:55:09 --> Config Class Initialized
DEBUG - 2011-04-07 10:55:09 --> Hooks Class Initialized
DEBUG - 2011-04-07 10:55:09 --> Utf8 Class Initialized
DEBUG - 2011-04-07 10:55:09 --> UTF-8 Support Enabled
DEBUG - 2011-04-07 10:55:09 --> URI Class Initialized
DEBUG - 2011-04-07 10:55:09 --> Router Class Initialized
DEBUG - 2011-04-07 10:55:10 --> Output Class Initialized
DEBUG - 2011-04-07 10:55:10 --> Input Class Initialized
DEBUG - 2011-04-07 10:55:10 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-07 10:55:10 --> Language Class Initialized
DEBUG - 2011-04-07 10:55:10 --> Loader Class Initialized
DEBUG - 2011-04-07 10:55:10 --> Controller Class Initialized
ERROR - 2011-04-07 10:55:10 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-04-07 10:55:10 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-04-07 10:55:10 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-04-07 10:55:10 --> Model Class Initialized
DEBUG - 2011-04-07 10:55:10 --> Model Class Initialized
DEBUG - 2011-04-07 10:55:10 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-07 10:55:10 --> Database Driver Class Initialized
DEBUG - 2011-04-07 10:55:10 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-04-07 10:55:10 --> Helper loaded: url_helper
DEBUG - 2011-04-07 10:55:10 --> File loaded: application/views/common/header.php
DEBUG - 2011-04-07 10:55:10 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-04-07 10:55:10 --> File loaded: application/views/common/footer.php
DEBUG - 2011-04-07 10:55:10 --> File loaded: application/views/layout/main.php
DEBUG - 2011-04-07 10:55:10 --> Final output sent to browser
DEBUG - 2011-04-07 10:55:10 --> Total execution time: 0.1846
DEBUG - 2011-04-07 10:55:11 --> Config Class Initialized
DEBUG - 2011-04-07 10:55:11 --> Hooks Class Initialized
DEBUG - 2011-04-07 10:55:11 --> Utf8 Class Initialized
DEBUG - 2011-04-07 10:55:11 --> UTF-8 Support Enabled
DEBUG - 2011-04-07 10:55:11 --> URI Class Initialized
DEBUG - 2011-04-07 10:55:11 --> Router Class Initialized
DEBUG - 2011-04-07 10:55:11 --> Output Class Initialized
DEBUG - 2011-04-07 10:55:11 --> Input Class Initialized
DEBUG - 2011-04-07 10:55:11 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-07 10:55:11 --> Language Class Initialized
DEBUG - 2011-04-07 10:55:11 --> Loader Class Initialized
DEBUG - 2011-04-07 10:55:11 --> Controller Class Initialized
DEBUG - 2011-04-07 10:55:11 --> Model Class Initialized
DEBUG - 2011-04-07 10:55:11 --> Model Class Initialized
DEBUG - 2011-04-07 10:55:11 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-07 10:55:11 --> Database Driver Class Initialized
DEBUG - 2011-04-07 10:55:12 --> Final output sent to browser
DEBUG - 2011-04-07 10:55:12 --> Total execution time: 0.9774
DEBUG - 2011-04-07 10:55:13 --> Config Class Initialized
DEBUG - 2011-04-07 10:55:13 --> Hooks Class Initialized
DEBUG - 2011-04-07 10:55:13 --> Utf8 Class Initialized
DEBUG - 2011-04-07 10:55:13 --> UTF-8 Support Enabled
DEBUG - 2011-04-07 10:55:13 --> URI Class Initialized
DEBUG - 2011-04-07 10:55:13 --> Router Class Initialized
ERROR - 2011-04-07 10:55:13 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-04-07 10:55:37 --> Config Class Initialized
DEBUG - 2011-04-07 10:55:37 --> Hooks Class Initialized
DEBUG - 2011-04-07 10:55:37 --> Utf8 Class Initialized
DEBUG - 2011-04-07 10:55:37 --> UTF-8 Support Enabled
DEBUG - 2011-04-07 10:55:37 --> URI Class Initialized
DEBUG - 2011-04-07 10:55:37 --> Router Class Initialized
DEBUG - 2011-04-07 10:55:37 --> Output Class Initialized
DEBUG - 2011-04-07 10:55:37 --> Input Class Initialized
DEBUG - 2011-04-07 10:55:37 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-07 10:55:37 --> Language Class Initialized
DEBUG - 2011-04-07 10:55:37 --> Loader Class Initialized
DEBUG - 2011-04-07 10:55:37 --> Controller Class Initialized
ERROR - 2011-04-07 10:55:37 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-04-07 10:55:37 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-04-07 10:55:37 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-04-07 10:55:37 --> Model Class Initialized
DEBUG - 2011-04-07 10:55:37 --> Model Class Initialized
DEBUG - 2011-04-07 10:55:37 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-07 10:55:37 --> Database Driver Class Initialized
DEBUG - 2011-04-07 10:55:37 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-04-07 10:55:37 --> Helper loaded: url_helper
DEBUG - 2011-04-07 10:55:37 --> File loaded: application/views/common/header.php
DEBUG - 2011-04-07 10:55:37 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-04-07 10:55:37 --> File loaded: application/views/common/footer.php
DEBUG - 2011-04-07 10:55:37 --> File loaded: application/views/layout/main.php
DEBUG - 2011-04-07 10:55:37 --> Final output sent to browser
DEBUG - 2011-04-07 10:55:37 --> Total execution time: 0.1429
DEBUG - 2011-04-07 10:55:38 --> Config Class Initialized
DEBUG - 2011-04-07 10:55:38 --> Hooks Class Initialized
DEBUG - 2011-04-07 10:55:38 --> Utf8 Class Initialized
DEBUG - 2011-04-07 10:55:38 --> UTF-8 Support Enabled
DEBUG - 2011-04-07 10:55:38 --> URI Class Initialized
DEBUG - 2011-04-07 10:55:38 --> Router Class Initialized
DEBUG - 2011-04-07 10:55:38 --> Output Class Initialized
DEBUG - 2011-04-07 10:55:38 --> Input Class Initialized
DEBUG - 2011-04-07 10:55:38 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-07 10:55:38 --> Language Class Initialized
DEBUG - 2011-04-07 10:55:38 --> Loader Class Initialized
DEBUG - 2011-04-07 10:55:38 --> Controller Class Initialized
DEBUG - 2011-04-07 10:55:38 --> Model Class Initialized
DEBUG - 2011-04-07 10:55:38 --> Model Class Initialized
DEBUG - 2011-04-07 10:55:38 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-07 10:55:38 --> Database Driver Class Initialized
DEBUG - 2011-04-07 10:55:39 --> Final output sent to browser
DEBUG - 2011-04-07 10:55:39 --> Total execution time: 0.7413
DEBUG - 2011-04-07 10:55:40 --> Config Class Initialized
DEBUG - 2011-04-07 10:55:40 --> Hooks Class Initialized
DEBUG - 2011-04-07 10:55:40 --> Utf8 Class Initialized
DEBUG - 2011-04-07 10:55:40 --> UTF-8 Support Enabled
DEBUG - 2011-04-07 10:55:40 --> URI Class Initialized
DEBUG - 2011-04-07 10:55:40 --> Router Class Initialized
ERROR - 2011-04-07 10:55:40 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-04-07 10:56:05 --> Config Class Initialized
DEBUG - 2011-04-07 10:56:05 --> Hooks Class Initialized
DEBUG - 2011-04-07 10:56:05 --> Utf8 Class Initialized
DEBUG - 2011-04-07 10:56:05 --> UTF-8 Support Enabled
DEBUG - 2011-04-07 10:56:05 --> URI Class Initialized
DEBUG - 2011-04-07 10:56:05 --> Router Class Initialized
DEBUG - 2011-04-07 10:56:05 --> Output Class Initialized
DEBUG - 2011-04-07 10:56:05 --> Input Class Initialized
DEBUG - 2011-04-07 10:56:05 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-07 10:56:05 --> Language Class Initialized
DEBUG - 2011-04-07 10:56:05 --> Loader Class Initialized
DEBUG - 2011-04-07 10:56:05 --> Controller Class Initialized
ERROR - 2011-04-07 10:56:05 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-04-07 10:56:05 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-04-07 10:56:05 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-04-07 10:56:05 --> Model Class Initialized
DEBUG - 2011-04-07 10:56:05 --> Model Class Initialized
DEBUG - 2011-04-07 10:56:05 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-07 10:56:05 --> Database Driver Class Initialized
DEBUG - 2011-04-07 10:56:05 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-04-07 10:56:05 --> Helper loaded: url_helper
DEBUG - 2011-04-07 10:56:05 --> File loaded: application/views/common/header.php
DEBUG - 2011-04-07 10:56:05 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-04-07 10:56:05 --> File loaded: application/views/common/footer.php
DEBUG - 2011-04-07 10:56:05 --> File loaded: application/views/layout/main.php
DEBUG - 2011-04-07 10:56:05 --> Final output sent to browser
DEBUG - 2011-04-07 10:56:05 --> Total execution time: 0.0288
DEBUG - 2011-04-07 10:56:06 --> Config Class Initialized
DEBUG - 2011-04-07 10:56:06 --> Hooks Class Initialized
DEBUG - 2011-04-07 10:56:06 --> Utf8 Class Initialized
DEBUG - 2011-04-07 10:56:06 --> UTF-8 Support Enabled
DEBUG - 2011-04-07 10:56:06 --> URI Class Initialized
DEBUG - 2011-04-07 10:56:06 --> Router Class Initialized
DEBUG - 2011-04-07 10:56:06 --> Output Class Initialized
DEBUG - 2011-04-07 10:56:06 --> Input Class Initialized
DEBUG - 2011-04-07 10:56:06 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-07 10:56:06 --> Language Class Initialized
DEBUG - 2011-04-07 10:56:06 --> Loader Class Initialized
DEBUG - 2011-04-07 10:56:06 --> Controller Class Initialized
DEBUG - 2011-04-07 10:56:06 --> Model Class Initialized
DEBUG - 2011-04-07 10:56:06 --> Model Class Initialized
DEBUG - 2011-04-07 10:56:06 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-07 10:56:06 --> Database Driver Class Initialized
DEBUG - 2011-04-07 10:56:15 --> Final output sent to browser
DEBUG - 2011-04-07 10:56:15 --> Total execution time: 8.9568
DEBUG - 2011-04-07 10:56:16 --> Config Class Initialized
DEBUG - 2011-04-07 10:56:16 --> Hooks Class Initialized
DEBUG - 2011-04-07 10:56:16 --> Utf8 Class Initialized
DEBUG - 2011-04-07 10:56:16 --> UTF-8 Support Enabled
DEBUG - 2011-04-07 10:56:16 --> URI Class Initialized
DEBUG - 2011-04-07 10:56:16 --> Router Class Initialized
ERROR - 2011-04-07 10:56:16 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-04-07 10:56:25 --> Config Class Initialized
DEBUG - 2011-04-07 10:56:25 --> Hooks Class Initialized
DEBUG - 2011-04-07 10:56:25 --> Utf8 Class Initialized
DEBUG - 2011-04-07 10:56:25 --> UTF-8 Support Enabled
DEBUG - 2011-04-07 10:56:25 --> URI Class Initialized
DEBUG - 2011-04-07 10:56:25 --> Router Class Initialized
DEBUG - 2011-04-07 10:56:25 --> Output Class Initialized
DEBUG - 2011-04-07 10:56:25 --> Input Class Initialized
DEBUG - 2011-04-07 10:56:25 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-07 10:56:25 --> Language Class Initialized
DEBUG - 2011-04-07 10:56:25 --> Loader Class Initialized
DEBUG - 2011-04-07 10:56:25 --> Controller Class Initialized
ERROR - 2011-04-07 10:56:25 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-04-07 10:56:25 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-04-07 10:56:25 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-04-07 10:56:25 --> Model Class Initialized
DEBUG - 2011-04-07 10:56:25 --> Model Class Initialized
DEBUG - 2011-04-07 10:56:25 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-07 10:56:25 --> Database Driver Class Initialized
DEBUG - 2011-04-07 10:56:25 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-04-07 10:56:25 --> Helper loaded: url_helper
DEBUG - 2011-04-07 10:56:25 --> File loaded: application/views/common/header.php
DEBUG - 2011-04-07 10:56:25 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-04-07 10:56:25 --> File loaded: application/views/common/footer.php
DEBUG - 2011-04-07 10:56:25 --> File loaded: application/views/layout/main.php
DEBUG - 2011-04-07 10:56:25 --> Final output sent to browser
DEBUG - 2011-04-07 10:56:25 --> Total execution time: 0.2264
DEBUG - 2011-04-07 10:56:27 --> Config Class Initialized
DEBUG - 2011-04-07 10:56:27 --> Hooks Class Initialized
DEBUG - 2011-04-07 10:56:27 --> Utf8 Class Initialized
DEBUG - 2011-04-07 10:56:27 --> UTF-8 Support Enabled
DEBUG - 2011-04-07 10:56:27 --> URI Class Initialized
DEBUG - 2011-04-07 10:56:27 --> Router Class Initialized
DEBUG - 2011-04-07 10:56:27 --> Output Class Initialized
DEBUG - 2011-04-07 10:56:27 --> Input Class Initialized
DEBUG - 2011-04-07 10:56:27 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-07 10:56:27 --> Language Class Initialized
DEBUG - 2011-04-07 10:56:27 --> Loader Class Initialized
DEBUG - 2011-04-07 10:56:27 --> Controller Class Initialized
DEBUG - 2011-04-07 10:56:27 --> Model Class Initialized
DEBUG - 2011-04-07 10:56:27 --> Model Class Initialized
DEBUG - 2011-04-07 10:56:27 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-07 10:56:27 --> Database Driver Class Initialized
DEBUG - 2011-04-07 10:56:28 --> Final output sent to browser
DEBUG - 2011-04-07 10:56:28 --> Total execution time: 1.3732
DEBUG - 2011-04-07 10:56:31 --> Config Class Initialized
DEBUG - 2011-04-07 10:56:31 --> Hooks Class Initialized
DEBUG - 2011-04-07 10:56:31 --> Utf8 Class Initialized
DEBUG - 2011-04-07 10:56:31 --> UTF-8 Support Enabled
DEBUG - 2011-04-07 10:56:31 --> URI Class Initialized
DEBUG - 2011-04-07 10:56:31 --> Router Class Initialized
ERROR - 2011-04-07 10:56:31 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-04-07 10:56:43 --> Config Class Initialized
DEBUG - 2011-04-07 10:56:43 --> Hooks Class Initialized
DEBUG - 2011-04-07 10:56:43 --> Utf8 Class Initialized
DEBUG - 2011-04-07 10:56:43 --> UTF-8 Support Enabled
DEBUG - 2011-04-07 10:56:43 --> URI Class Initialized
DEBUG - 2011-04-07 10:56:43 --> Router Class Initialized
DEBUG - 2011-04-07 10:56:43 --> Output Class Initialized
DEBUG - 2011-04-07 10:56:43 --> Input Class Initialized
DEBUG - 2011-04-07 10:56:43 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-07 10:56:43 --> Language Class Initialized
DEBUG - 2011-04-07 10:56:43 --> Loader Class Initialized
DEBUG - 2011-04-07 10:56:43 --> Controller Class Initialized
ERROR - 2011-04-07 10:56:43 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-04-07 10:56:43 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-04-07 10:56:43 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-04-07 10:56:43 --> Model Class Initialized
DEBUG - 2011-04-07 10:56:43 --> Model Class Initialized
DEBUG - 2011-04-07 10:56:43 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-07 10:56:43 --> Database Driver Class Initialized
DEBUG - 2011-04-07 10:56:43 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-04-07 10:56:43 --> Helper loaded: url_helper
DEBUG - 2011-04-07 10:56:43 --> File loaded: application/views/common/header.php
DEBUG - 2011-04-07 10:56:43 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-04-07 10:56:43 --> File loaded: application/views/common/footer.php
DEBUG - 2011-04-07 10:56:43 --> File loaded: application/views/layout/main.php
DEBUG - 2011-04-07 10:56:43 --> Final output sent to browser
DEBUG - 2011-04-07 10:56:43 --> Total execution time: 0.2404
DEBUG - 2011-04-07 10:56:44 --> Config Class Initialized
DEBUG - 2011-04-07 10:56:44 --> Hooks Class Initialized
DEBUG - 2011-04-07 10:56:44 --> Utf8 Class Initialized
DEBUG - 2011-04-07 10:56:44 --> UTF-8 Support Enabled
DEBUG - 2011-04-07 10:56:44 --> URI Class Initialized
DEBUG - 2011-04-07 10:56:44 --> Router Class Initialized
DEBUG - 2011-04-07 10:56:44 --> Output Class Initialized
DEBUG - 2011-04-07 10:56:44 --> Input Class Initialized
DEBUG - 2011-04-07 10:56:44 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-07 10:56:44 --> Language Class Initialized
DEBUG - 2011-04-07 10:56:44 --> Loader Class Initialized
DEBUG - 2011-04-07 10:56:44 --> Controller Class Initialized
DEBUG - 2011-04-07 10:56:44 --> Model Class Initialized
DEBUG - 2011-04-07 10:56:44 --> Model Class Initialized
DEBUG - 2011-04-07 10:56:44 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-07 10:56:44 --> Database Driver Class Initialized
DEBUG - 2011-04-07 10:56:45 --> Final output sent to browser
DEBUG - 2011-04-07 10:56:45 --> Total execution time: 0.9427
DEBUG - 2011-04-07 10:56:47 --> Config Class Initialized
DEBUG - 2011-04-07 10:56:47 --> Hooks Class Initialized
DEBUG - 2011-04-07 10:56:47 --> Utf8 Class Initialized
DEBUG - 2011-04-07 10:56:47 --> UTF-8 Support Enabled
DEBUG - 2011-04-07 10:56:47 --> URI Class Initialized
DEBUG - 2011-04-07 10:56:47 --> Router Class Initialized
ERROR - 2011-04-07 10:56:47 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-04-07 10:57:05 --> Config Class Initialized
DEBUG - 2011-04-07 10:57:05 --> Hooks Class Initialized
DEBUG - 2011-04-07 10:57:05 --> Utf8 Class Initialized
DEBUG - 2011-04-07 10:57:05 --> UTF-8 Support Enabled
DEBUG - 2011-04-07 10:57:05 --> URI Class Initialized
DEBUG - 2011-04-07 10:57:05 --> Router Class Initialized
DEBUG - 2011-04-07 10:57:05 --> Output Class Initialized
DEBUG - 2011-04-07 10:57:05 --> Input Class Initialized
DEBUG - 2011-04-07 10:57:05 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-07 10:57:05 --> Language Class Initialized
DEBUG - 2011-04-07 10:57:05 --> Loader Class Initialized
DEBUG - 2011-04-07 10:57:05 --> Controller Class Initialized
ERROR - 2011-04-07 10:57:05 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-04-07 10:57:05 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-04-07 10:57:05 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-04-07 10:57:05 --> Model Class Initialized
DEBUG - 2011-04-07 10:57:05 --> Model Class Initialized
DEBUG - 2011-04-07 10:57:05 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-07 10:57:05 --> Database Driver Class Initialized
DEBUG - 2011-04-07 10:57:05 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-04-07 10:57:05 --> Helper loaded: url_helper
DEBUG - 2011-04-07 10:57:05 --> File loaded: application/views/common/header.php
DEBUG - 2011-04-07 10:57:05 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-04-07 10:57:05 --> File loaded: application/views/common/footer.php
DEBUG - 2011-04-07 10:57:05 --> File loaded: application/views/layout/main.php
DEBUG - 2011-04-07 10:57:05 --> Final output sent to browser
DEBUG - 2011-04-07 10:57:05 --> Total execution time: 0.0771
DEBUG - 2011-04-07 10:57:06 --> Config Class Initialized
DEBUG - 2011-04-07 10:57:06 --> Hooks Class Initialized
DEBUG - 2011-04-07 10:57:06 --> Utf8 Class Initialized
DEBUG - 2011-04-07 10:57:06 --> UTF-8 Support Enabled
DEBUG - 2011-04-07 10:57:06 --> URI Class Initialized
DEBUG - 2011-04-07 10:57:06 --> Router Class Initialized
DEBUG - 2011-04-07 10:57:06 --> Output Class Initialized
DEBUG - 2011-04-07 10:57:06 --> Input Class Initialized
DEBUG - 2011-04-07 10:57:06 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-07 10:57:06 --> Language Class Initialized
DEBUG - 2011-04-07 10:57:06 --> Loader Class Initialized
DEBUG - 2011-04-07 10:57:06 --> Controller Class Initialized
DEBUG - 2011-04-07 10:57:06 --> Model Class Initialized
DEBUG - 2011-04-07 10:57:06 --> Model Class Initialized
DEBUG - 2011-04-07 10:57:06 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-07 10:57:06 --> Database Driver Class Initialized
DEBUG - 2011-04-07 10:57:08 --> Final output sent to browser
DEBUG - 2011-04-07 10:57:08 --> Total execution time: 2.0319
DEBUG - 2011-04-07 10:57:10 --> Config Class Initialized
DEBUG - 2011-04-07 10:57:10 --> Hooks Class Initialized
DEBUG - 2011-04-07 10:57:10 --> Utf8 Class Initialized
DEBUG - 2011-04-07 10:57:10 --> UTF-8 Support Enabled
DEBUG - 2011-04-07 10:57:10 --> URI Class Initialized
DEBUG - 2011-04-07 10:57:10 --> Router Class Initialized
ERROR - 2011-04-07 10:57:10 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-04-07 10:57:18 --> Config Class Initialized
DEBUG - 2011-04-07 10:57:18 --> Hooks Class Initialized
DEBUG - 2011-04-07 10:57:18 --> Utf8 Class Initialized
DEBUG - 2011-04-07 10:57:18 --> UTF-8 Support Enabled
DEBUG - 2011-04-07 10:57:18 --> URI Class Initialized
DEBUG - 2011-04-07 10:57:18 --> Router Class Initialized
DEBUG - 2011-04-07 10:57:18 --> Output Class Initialized
DEBUG - 2011-04-07 10:57:18 --> Input Class Initialized
DEBUG - 2011-04-07 10:57:18 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-07 10:57:18 --> Language Class Initialized
DEBUG - 2011-04-07 10:57:18 --> Loader Class Initialized
DEBUG - 2011-04-07 10:57:18 --> Controller Class Initialized
ERROR - 2011-04-07 10:57:18 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-04-07 10:57:18 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-04-07 10:57:18 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-04-07 10:57:18 --> Model Class Initialized
DEBUG - 2011-04-07 10:57:18 --> Model Class Initialized
DEBUG - 2011-04-07 10:57:18 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-07 10:57:18 --> Database Driver Class Initialized
DEBUG - 2011-04-07 10:57:18 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-04-07 10:57:18 --> Helper loaded: url_helper
DEBUG - 2011-04-07 10:57:18 --> File loaded: application/views/common/header.php
DEBUG - 2011-04-07 10:57:18 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-04-07 10:57:18 --> File loaded: application/views/common/footer.php
DEBUG - 2011-04-07 10:57:18 --> File loaded: application/views/layout/main.php
DEBUG - 2011-04-07 10:57:18 --> Final output sent to browser
DEBUG - 2011-04-07 10:57:18 --> Total execution time: 0.0322
DEBUG - 2011-04-07 10:57:19 --> Config Class Initialized
DEBUG - 2011-04-07 10:57:19 --> Hooks Class Initialized
DEBUG - 2011-04-07 10:57:19 --> Utf8 Class Initialized
DEBUG - 2011-04-07 10:57:19 --> UTF-8 Support Enabled
DEBUG - 2011-04-07 10:57:19 --> URI Class Initialized
DEBUG - 2011-04-07 10:57:19 --> Router Class Initialized
DEBUG - 2011-04-07 10:57:19 --> Output Class Initialized
DEBUG - 2011-04-07 10:57:19 --> Input Class Initialized
DEBUG - 2011-04-07 10:57:19 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-07 10:57:19 --> Language Class Initialized
DEBUG - 2011-04-07 10:57:19 --> Loader Class Initialized
DEBUG - 2011-04-07 10:57:19 --> Controller Class Initialized
DEBUG - 2011-04-07 10:57:19 --> Model Class Initialized
DEBUG - 2011-04-07 10:57:19 --> Model Class Initialized
DEBUG - 2011-04-07 10:57:19 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-07 10:57:19 --> Database Driver Class Initialized
DEBUG - 2011-04-07 10:57:21 --> Final output sent to browser
DEBUG - 2011-04-07 10:57:21 --> Total execution time: 1.6046
DEBUG - 2011-04-07 10:57:22 --> Config Class Initialized
DEBUG - 2011-04-07 10:57:22 --> Hooks Class Initialized
DEBUG - 2011-04-07 10:57:22 --> Utf8 Class Initialized
DEBUG - 2011-04-07 10:57:22 --> UTF-8 Support Enabled
DEBUG - 2011-04-07 10:57:22 --> URI Class Initialized
DEBUG - 2011-04-07 10:57:22 --> Router Class Initialized
ERROR - 2011-04-07 10:57:22 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-04-07 10:58:07 --> Config Class Initialized
DEBUG - 2011-04-07 10:58:07 --> Hooks Class Initialized
DEBUG - 2011-04-07 10:58:07 --> Utf8 Class Initialized
DEBUG - 2011-04-07 10:58:07 --> UTF-8 Support Enabled
DEBUG - 2011-04-07 10:58:07 --> URI Class Initialized
DEBUG - 2011-04-07 10:58:07 --> Router Class Initialized
ERROR - 2011-04-07 10:58:07 --> 404 Page Not Found --> robots.txt
DEBUG - 2011-04-07 10:58:07 --> Config Class Initialized
DEBUG - 2011-04-07 10:58:07 --> Hooks Class Initialized
DEBUG - 2011-04-07 10:58:07 --> Utf8 Class Initialized
DEBUG - 2011-04-07 10:58:07 --> UTF-8 Support Enabled
DEBUG - 2011-04-07 10:58:07 --> URI Class Initialized
DEBUG - 2011-04-07 10:58:07 --> Router Class Initialized
DEBUG - 2011-04-07 10:58:07 --> Output Class Initialized
DEBUG - 2011-04-07 10:58:07 --> Input Class Initialized
DEBUG - 2011-04-07 10:58:07 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-07 10:58:07 --> Language Class Initialized
DEBUG - 2011-04-07 10:58:07 --> Loader Class Initialized
DEBUG - 2011-04-07 10:58:07 --> Controller Class Initialized
ERROR - 2011-04-07 10:58:07 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-04-07 10:58:07 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-04-07 10:58:07 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-04-07 10:58:07 --> Model Class Initialized
DEBUG - 2011-04-07 10:58:07 --> Model Class Initialized
DEBUG - 2011-04-07 10:58:07 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-07 10:58:07 --> Database Driver Class Initialized
DEBUG - 2011-04-07 10:58:07 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-04-07 10:58:07 --> Helper loaded: url_helper
DEBUG - 2011-04-07 10:58:07 --> File loaded: application/views/common/header.php
DEBUG - 2011-04-07 10:58:07 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-04-07 10:58:07 --> File loaded: application/views/common/footer.php
DEBUG - 2011-04-07 10:58:07 --> File loaded: application/views/layout/main.php
DEBUG - 2011-04-07 10:58:07 --> Final output sent to browser
DEBUG - 2011-04-07 10:58:07 --> Total execution time: 0.1201
DEBUG - 2011-04-07 10:58:38 --> Config Class Initialized
DEBUG - 2011-04-07 10:58:38 --> Hooks Class Initialized
DEBUG - 2011-04-07 10:58:38 --> Utf8 Class Initialized
DEBUG - 2011-04-07 10:58:38 --> UTF-8 Support Enabled
DEBUG - 2011-04-07 10:58:38 --> URI Class Initialized
DEBUG - 2011-04-07 10:58:38 --> Router Class Initialized
DEBUG - 2011-04-07 10:58:38 --> Output Class Initialized
DEBUG - 2011-04-07 10:58:38 --> Input Class Initialized
DEBUG - 2011-04-07 10:58:38 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-07 10:58:38 --> Language Class Initialized
DEBUG - 2011-04-07 10:58:38 --> Loader Class Initialized
DEBUG - 2011-04-07 10:58:38 --> Controller Class Initialized
DEBUG - 2011-04-07 10:58:38 --> Model Class Initialized
DEBUG - 2011-04-07 10:58:38 --> Model Class Initialized
DEBUG - 2011-04-07 10:58:38 --> Model Class Initialized
DEBUG - 2011-04-07 10:58:38 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-07 10:58:38 --> Database Driver Class Initialized
DEBUG - 2011-04-07 10:58:38 --> File loaded: application/views/table/main.php
DEBUG - 2011-04-07 10:58:38 --> Helper loaded: url_helper
DEBUG - 2011-04-07 10:58:38 --> File loaded: application/views/common/header.php
DEBUG - 2011-04-07 10:58:38 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-04-07 10:58:38 --> File loaded: application/views/common/footer.php
DEBUG - 2011-04-07 10:58:38 --> File loaded: application/views/layout/main.php
DEBUG - 2011-04-07 10:58:38 --> Final output sent to browser
DEBUG - 2011-04-07 10:58:38 --> Total execution time: 0.0948
DEBUG - 2011-04-07 11:00:13 --> Config Class Initialized
DEBUG - 2011-04-07 11:00:13 --> Hooks Class Initialized
DEBUG - 2011-04-07 11:00:13 --> Utf8 Class Initialized
DEBUG - 2011-04-07 11:00:13 --> UTF-8 Support Enabled
DEBUG - 2011-04-07 11:00:13 --> URI Class Initialized
DEBUG - 2011-04-07 11:00:13 --> Router Class Initialized
DEBUG - 2011-04-07 11:00:13 --> No URI present. Default controller set.
DEBUG - 2011-04-07 11:00:13 --> Output Class Initialized
DEBUG - 2011-04-07 11:00:13 --> Input Class Initialized
DEBUG - 2011-04-07 11:00:13 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-07 11:00:13 --> Language Class Initialized
DEBUG - 2011-04-07 11:00:13 --> Loader Class Initialized
DEBUG - 2011-04-07 11:00:13 --> Controller Class Initialized
DEBUG - 2011-04-07 11:00:14 --> File loaded: application/views/splash/main.php
DEBUG - 2011-04-07 11:00:14 --> Helper loaded: url_helper
DEBUG - 2011-04-07 11:00:14 --> File loaded: application/views/common/header.php
DEBUG - 2011-04-07 11:00:14 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-04-07 11:00:14 --> File loaded: application/views/common/footer.php
DEBUG - 2011-04-07 11:00:14 --> File loaded: application/views/layout/main.php
DEBUG - 2011-04-07 11:00:14 --> Final output sent to browser
DEBUG - 2011-04-07 11:00:14 --> Total execution time: 0.0707
DEBUG - 2011-04-07 12:27:07 --> Config Class Initialized
DEBUG - 2011-04-07 12:27:07 --> Hooks Class Initialized
DEBUG - 2011-04-07 12:27:07 --> Utf8 Class Initialized
DEBUG - 2011-04-07 12:27:07 --> UTF-8 Support Enabled
DEBUG - 2011-04-07 12:27:07 --> URI Class Initialized
DEBUG - 2011-04-07 12:27:07 --> Router Class Initialized
DEBUG - 2011-04-07 12:27:07 --> No URI present. Default controller set.
DEBUG - 2011-04-07 12:27:07 --> Output Class Initialized
DEBUG - 2011-04-07 12:27:07 --> Input Class Initialized
DEBUG - 2011-04-07 12:27:07 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-07 12:27:07 --> Language Class Initialized
DEBUG - 2011-04-07 12:27:07 --> Loader Class Initialized
DEBUG - 2011-04-07 12:27:07 --> Controller Class Initialized
DEBUG - 2011-04-07 12:27:07 --> File loaded: application/views/splash/main.php
DEBUG - 2011-04-07 12:27:07 --> Helper loaded: url_helper
DEBUG - 2011-04-07 12:27:07 --> File loaded: application/views/common/header.php
DEBUG - 2011-04-07 12:27:07 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-04-07 12:27:07 --> File loaded: application/views/common/footer.php
DEBUG - 2011-04-07 12:27:07 --> File loaded: application/views/layout/main.php
DEBUG - 2011-04-07 12:27:07 --> Final output sent to browser
DEBUG - 2011-04-07 12:27:07 --> Total execution time: 0.2243
DEBUG - 2011-04-07 12:27:32 --> Config Class Initialized
DEBUG - 2011-04-07 12:27:32 --> Hooks Class Initialized
DEBUG - 2011-04-07 12:27:32 --> Utf8 Class Initialized
DEBUG - 2011-04-07 12:27:32 --> UTF-8 Support Enabled
DEBUG - 2011-04-07 12:27:32 --> URI Class Initialized
DEBUG - 2011-04-07 12:27:32 --> Router Class Initialized
ERROR - 2011-04-07 12:27:32 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-04-07 12:28:32 --> Config Class Initialized
DEBUG - 2011-04-07 12:28:32 --> Hooks Class Initialized
DEBUG - 2011-04-07 12:28:32 --> Utf8 Class Initialized
DEBUG - 2011-04-07 12:28:32 --> UTF-8 Support Enabled
DEBUG - 2011-04-07 12:28:32 --> URI Class Initialized
DEBUG - 2011-04-07 12:28:32 --> Router Class Initialized
DEBUG - 2011-04-07 12:28:32 --> No URI present. Default controller set.
DEBUG - 2011-04-07 12:28:32 --> Output Class Initialized
DEBUG - 2011-04-07 12:28:32 --> Input Class Initialized
DEBUG - 2011-04-07 12:28:32 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-07 12:28:32 --> Language Class Initialized
DEBUG - 2011-04-07 12:28:32 --> Loader Class Initialized
DEBUG - 2011-04-07 12:28:32 --> Controller Class Initialized
DEBUG - 2011-04-07 12:28:32 --> File loaded: application/views/splash/main.php
DEBUG - 2011-04-07 12:28:32 --> Helper loaded: url_helper
DEBUG - 2011-04-07 12:28:32 --> File loaded: application/views/common/header.php
DEBUG - 2011-04-07 12:28:32 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-04-07 12:28:32 --> File loaded: application/views/common/footer.php
DEBUG - 2011-04-07 12:28:32 --> File loaded: application/views/layout/main.php
DEBUG - 2011-04-07 12:28:32 --> Final output sent to browser
DEBUG - 2011-04-07 12:28:32 --> Total execution time: 0.0286
DEBUG - 2011-04-07 12:28:34 --> Config Class Initialized
DEBUG - 2011-04-07 12:28:34 --> Hooks Class Initialized
DEBUG - 2011-04-07 12:28:34 --> Utf8 Class Initialized
DEBUG - 2011-04-07 12:28:34 --> UTF-8 Support Enabled
DEBUG - 2011-04-07 12:28:34 --> URI Class Initialized
DEBUG - 2011-04-07 12:28:34 --> Router Class Initialized
ERROR - 2011-04-07 12:28:34 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-04-07 12:28:38 --> Config Class Initialized
DEBUG - 2011-04-07 12:28:38 --> Hooks Class Initialized
DEBUG - 2011-04-07 12:28:38 --> Utf8 Class Initialized
DEBUG - 2011-04-07 12:28:38 --> UTF-8 Support Enabled
DEBUG - 2011-04-07 12:28:38 --> URI Class Initialized
DEBUG - 2011-04-07 12:28:38 --> Router Class Initialized
DEBUG - 2011-04-07 12:28:38 --> Output Class Initialized
DEBUG - 2011-04-07 12:28:38 --> Input Class Initialized
DEBUG - 2011-04-07 12:28:38 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-07 12:28:38 --> Language Class Initialized
DEBUG - 2011-04-07 12:28:38 --> Loader Class Initialized
DEBUG - 2011-04-07 12:28:38 --> Controller Class Initialized
DEBUG - 2011-04-07 12:28:38 --> Model Class Initialized
DEBUG - 2011-04-07 12:28:38 --> Model Class Initialized
DEBUG - 2011-04-07 12:28:38 --> Model Class Initialized
DEBUG - 2011-04-07 12:28:38 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-07 12:28:38 --> Database Driver Class Initialized
DEBUG - 2011-04-07 12:28:40 --> File loaded: application/views/table/main.php
DEBUG - 2011-04-07 12:28:40 --> Helper loaded: url_helper
DEBUG - 2011-04-07 12:28:40 --> File loaded: application/views/common/header.php
DEBUG - 2011-04-07 12:28:40 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-04-07 12:28:40 --> File loaded: application/views/common/footer.php
DEBUG - 2011-04-07 12:28:40 --> File loaded: application/views/layout/main.php
DEBUG - 2011-04-07 12:28:40 --> Final output sent to browser
DEBUG - 2011-04-07 12:28:40 --> Total execution time: 2.2795
DEBUG - 2011-04-07 12:28:42 --> Config Class Initialized
DEBUG - 2011-04-07 12:28:42 --> Hooks Class Initialized
DEBUG - 2011-04-07 12:28:42 --> Utf8 Class Initialized
DEBUG - 2011-04-07 12:28:42 --> UTF-8 Support Enabled
DEBUG - 2011-04-07 12:28:42 --> URI Class Initialized
DEBUG - 2011-04-07 12:28:42 --> Router Class Initialized
ERROR - 2011-04-07 12:28:42 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-04-07 12:28:56 --> Config Class Initialized
DEBUG - 2011-04-07 12:28:56 --> Hooks Class Initialized
DEBUG - 2011-04-07 12:28:56 --> Utf8 Class Initialized
DEBUG - 2011-04-07 12:28:56 --> UTF-8 Support Enabled
DEBUG - 2011-04-07 12:28:56 --> URI Class Initialized
DEBUG - 2011-04-07 12:28:56 --> Router Class Initialized
DEBUG - 2011-04-07 12:28:56 --> Output Class Initialized
DEBUG - 2011-04-07 12:28:56 --> Input Class Initialized
DEBUG - 2011-04-07 12:28:56 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-07 12:28:56 --> Language Class Initialized
DEBUG - 2011-04-07 12:28:56 --> Loader Class Initialized
DEBUG - 2011-04-07 12:28:56 --> Controller Class Initialized
DEBUG - 2011-04-07 12:28:56 --> Model Class Initialized
DEBUG - 2011-04-07 12:28:56 --> Model Class Initialized
DEBUG - 2011-04-07 12:28:56 --> Model Class Initialized
DEBUG - 2011-04-07 12:28:56 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-07 12:28:56 --> Database Driver Class Initialized
DEBUG - 2011-04-07 12:28:57 --> File loaded: application/views/table/main.php
DEBUG - 2011-04-07 12:28:57 --> Helper loaded: url_helper
DEBUG - 2011-04-07 12:28:57 --> File loaded: application/views/common/header.php
DEBUG - 2011-04-07 12:28:57 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-04-07 12:28:57 --> File loaded: application/views/common/footer.php
DEBUG - 2011-04-07 12:28:57 --> File loaded: application/views/layout/main.php
DEBUG - 2011-04-07 12:28:57 --> Final output sent to browser
DEBUG - 2011-04-07 12:28:57 --> Total execution time: 1.5491
DEBUG - 2011-04-07 12:28:59 --> Config Class Initialized
DEBUG - 2011-04-07 12:28:59 --> Hooks Class Initialized
DEBUG - 2011-04-07 12:28:59 --> Utf8 Class Initialized
DEBUG - 2011-04-07 12:28:59 --> UTF-8 Support Enabled
DEBUG - 2011-04-07 12:28:59 --> URI Class Initialized
DEBUG - 2011-04-07 12:28:59 --> Router Class Initialized
ERROR - 2011-04-07 12:28:59 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-04-07 12:28:59 --> Config Class Initialized
DEBUG - 2011-04-07 12:28:59 --> Hooks Class Initialized
DEBUG - 2011-04-07 12:28:59 --> Utf8 Class Initialized
DEBUG - 2011-04-07 12:28:59 --> UTF-8 Support Enabled
DEBUG - 2011-04-07 12:28:59 --> URI Class Initialized
DEBUG - 2011-04-07 12:28:59 --> Router Class Initialized
DEBUG - 2011-04-07 12:28:59 --> Output Class Initialized
DEBUG - 2011-04-07 12:28:59 --> Input Class Initialized
DEBUG - 2011-04-07 12:28:59 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-07 12:28:59 --> Language Class Initialized
DEBUG - 2011-04-07 12:28:59 --> Loader Class Initialized
DEBUG - 2011-04-07 12:28:59 --> Controller Class Initialized
DEBUG - 2011-04-07 12:28:59 --> Model Class Initialized
DEBUG - 2011-04-07 12:28:59 --> Model Class Initialized
DEBUG - 2011-04-07 12:28:59 --> Model Class Initialized
DEBUG - 2011-04-07 12:28:59 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-07 12:28:59 --> Database Driver Class Initialized
DEBUG - 2011-04-07 12:28:59 --> File loaded: application/views/table/main.php
DEBUG - 2011-04-07 12:28:59 --> Helper loaded: url_helper
DEBUG - 2011-04-07 12:28:59 --> File loaded: application/views/common/header.php
DEBUG - 2011-04-07 12:28:59 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-04-07 12:28:59 --> File loaded: application/views/common/footer.php
DEBUG - 2011-04-07 12:28:59 --> File loaded: application/views/layout/main.php
DEBUG - 2011-04-07 12:28:59 --> Final output sent to browser
DEBUG - 2011-04-07 12:28:59 --> Total execution time: 0.2391
DEBUG - 2011-04-07 12:29:32 --> Config Class Initialized
DEBUG - 2011-04-07 12:29:32 --> Hooks Class Initialized
DEBUG - 2011-04-07 12:29:32 --> Utf8 Class Initialized
DEBUG - 2011-04-07 12:29:32 --> UTF-8 Support Enabled
DEBUG - 2011-04-07 12:29:32 --> URI Class Initialized
DEBUG - 2011-04-07 12:29:32 --> Router Class Initialized
DEBUG - 2011-04-07 12:29:32 --> Output Class Initialized
DEBUG - 2011-04-07 12:29:32 --> Input Class Initialized
DEBUG - 2011-04-07 12:29:32 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-07 12:29:32 --> Language Class Initialized
DEBUG - 2011-04-07 12:29:32 --> Loader Class Initialized
DEBUG - 2011-04-07 12:29:32 --> Controller Class Initialized
DEBUG - 2011-04-07 12:29:32 --> Model Class Initialized
DEBUG - 2011-04-07 12:29:32 --> Model Class Initialized
DEBUG - 2011-04-07 12:29:32 --> Model Class Initialized
DEBUG - 2011-04-07 12:29:32 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-07 12:29:32 --> Database Driver Class Initialized
DEBUG - 2011-04-07 12:29:32 --> File loaded: application/views/table/main.php
DEBUG - 2011-04-07 12:29:32 --> Helper loaded: url_helper
DEBUG - 2011-04-07 12:29:32 --> File loaded: application/views/common/header.php
DEBUG - 2011-04-07 12:29:32 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-04-07 12:29:32 --> File loaded: application/views/common/footer.php
DEBUG - 2011-04-07 12:29:32 --> File loaded: application/views/layout/main.php
DEBUG - 2011-04-07 12:29:32 --> Final output sent to browser
DEBUG - 2011-04-07 12:29:32 --> Total execution time: 0.1038
DEBUG - 2011-04-07 12:32:22 --> Config Class Initialized
DEBUG - 2011-04-07 12:32:22 --> Hooks Class Initialized
DEBUG - 2011-04-07 12:32:22 --> Utf8 Class Initialized
DEBUG - 2011-04-07 12:32:22 --> UTF-8 Support Enabled
DEBUG - 2011-04-07 12:32:22 --> URI Class Initialized
DEBUG - 2011-04-07 12:32:22 --> Router Class Initialized
ERROR - 2011-04-07 12:32:22 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-04-07 12:37:28 --> Config Class Initialized
DEBUG - 2011-04-07 12:37:28 --> Hooks Class Initialized
DEBUG - 2011-04-07 12:37:28 --> Utf8 Class Initialized
DEBUG - 2011-04-07 12:37:28 --> UTF-8 Support Enabled
DEBUG - 2011-04-07 12:37:28 --> URI Class Initialized
DEBUG - 2011-04-07 12:37:28 --> Router Class Initialized
DEBUG - 2011-04-07 12:37:28 --> No URI present. Default controller set.
DEBUG - 2011-04-07 12:37:28 --> Output Class Initialized
DEBUG - 2011-04-07 12:37:28 --> Input Class Initialized
DEBUG - 2011-04-07 12:37:28 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-07 12:37:28 --> Language Class Initialized
DEBUG - 2011-04-07 12:37:29 --> Loader Class Initialized
DEBUG - 2011-04-07 12:37:29 --> Controller Class Initialized
DEBUG - 2011-04-07 12:37:29 --> File loaded: application/views/splash/main.php
DEBUG - 2011-04-07 12:37:29 --> Helper loaded: url_helper
DEBUG - 2011-04-07 12:37:29 --> File loaded: application/views/common/header.php
DEBUG - 2011-04-07 12:37:29 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-04-07 12:37:29 --> File loaded: application/views/common/footer.php
DEBUG - 2011-04-07 12:37:29 --> File loaded: application/views/layout/main.php
DEBUG - 2011-04-07 12:37:29 --> Final output sent to browser
DEBUG - 2011-04-07 12:37:29 --> Total execution time: 0.0302
DEBUG - 2011-04-07 12:37:29 --> Config Class Initialized
DEBUG - 2011-04-07 12:37:29 --> Hooks Class Initialized
DEBUG - 2011-04-07 12:37:29 --> Utf8 Class Initialized
DEBUG - 2011-04-07 12:37:29 --> UTF-8 Support Enabled
DEBUG - 2011-04-07 12:37:29 --> URI Class Initialized
DEBUG - 2011-04-07 12:37:29 --> Router Class Initialized
ERROR - 2011-04-07 12:37:29 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-04-07 12:37:30 --> Config Class Initialized
DEBUG - 2011-04-07 12:37:30 --> Hooks Class Initialized
DEBUG - 2011-04-07 12:37:30 --> Utf8 Class Initialized
DEBUG - 2011-04-07 12:37:30 --> UTF-8 Support Enabled
DEBUG - 2011-04-07 12:37:30 --> URI Class Initialized
DEBUG - 2011-04-07 12:37:30 --> Router Class Initialized
ERROR - 2011-04-07 12:37:30 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-04-07 12:37:39 --> Config Class Initialized
DEBUG - 2011-04-07 12:37:39 --> Hooks Class Initialized
DEBUG - 2011-04-07 12:37:39 --> Utf8 Class Initialized
DEBUG - 2011-04-07 12:37:39 --> UTF-8 Support Enabled
DEBUG - 2011-04-07 12:37:39 --> URI Class Initialized
DEBUG - 2011-04-07 12:37:39 --> Router Class Initialized
DEBUG - 2011-04-07 12:37:39 --> Output Class Initialized
DEBUG - 2011-04-07 12:37:39 --> Input Class Initialized
DEBUG - 2011-04-07 12:37:39 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-07 12:37:39 --> Language Class Initialized
DEBUG - 2011-04-07 12:37:39 --> Loader Class Initialized
DEBUG - 2011-04-07 12:37:39 --> Controller Class Initialized
ERROR - 2011-04-07 12:37:39 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-04-07 12:37:39 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-04-07 12:37:39 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-04-07 12:37:39 --> Model Class Initialized
DEBUG - 2011-04-07 12:37:39 --> Model Class Initialized
DEBUG - 2011-04-07 12:37:39 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-07 12:37:39 --> Database Driver Class Initialized
DEBUG - 2011-04-07 12:37:39 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-04-07 12:37:39 --> Helper loaded: url_helper
DEBUG - 2011-04-07 12:37:39 --> File loaded: application/views/common/header.php
DEBUG - 2011-04-07 12:37:39 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-04-07 12:37:39 --> File loaded: application/views/common/footer.php
DEBUG - 2011-04-07 12:37:39 --> File loaded: application/views/layout/main.php
DEBUG - 2011-04-07 12:37:39 --> Final output sent to browser
DEBUG - 2011-04-07 12:37:39 --> Total execution time: 0.0987
DEBUG - 2011-04-07 12:37:39 --> Config Class Initialized
DEBUG - 2011-04-07 12:37:39 --> Hooks Class Initialized
DEBUG - 2011-04-07 12:37:39 --> Utf8 Class Initialized
DEBUG - 2011-04-07 12:37:39 --> UTF-8 Support Enabled
DEBUG - 2011-04-07 12:37:39 --> URI Class Initialized
DEBUG - 2011-04-07 12:37:39 --> Router Class Initialized
DEBUG - 2011-04-07 12:37:39 --> Output Class Initialized
DEBUG - 2011-04-07 12:37:39 --> Input Class Initialized
DEBUG - 2011-04-07 12:37:39 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-07 12:37:39 --> Language Class Initialized
DEBUG - 2011-04-07 12:37:39 --> Loader Class Initialized
DEBUG - 2011-04-07 12:37:39 --> Controller Class Initialized
DEBUG - 2011-04-07 12:37:39 --> Model Class Initialized
DEBUG - 2011-04-07 12:37:39 --> Model Class Initialized
DEBUG - 2011-04-07 12:37:39 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-07 12:37:39 --> Database Driver Class Initialized
DEBUG - 2011-04-07 12:37:40 --> Final output sent to browser
DEBUG - 2011-04-07 12:37:40 --> Total execution time: 1.1580
DEBUG - 2011-04-07 12:37:41 --> Config Class Initialized
DEBUG - 2011-04-07 12:37:41 --> Hooks Class Initialized
DEBUG - 2011-04-07 12:37:41 --> Utf8 Class Initialized
DEBUG - 2011-04-07 12:37:41 --> UTF-8 Support Enabled
DEBUG - 2011-04-07 12:37:41 --> URI Class Initialized
DEBUG - 2011-04-07 12:37:41 --> Router Class Initialized
ERROR - 2011-04-07 12:37:41 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-04-07 12:37:58 --> Config Class Initialized
DEBUG - 2011-04-07 12:37:58 --> Hooks Class Initialized
DEBUG - 2011-04-07 12:37:58 --> Utf8 Class Initialized
DEBUG - 2011-04-07 12:37:58 --> UTF-8 Support Enabled
DEBUG - 2011-04-07 12:37:58 --> URI Class Initialized
DEBUG - 2011-04-07 12:37:58 --> Router Class Initialized
DEBUG - 2011-04-07 12:37:58 --> Output Class Initialized
DEBUG - 2011-04-07 12:37:58 --> Input Class Initialized
DEBUG - 2011-04-07 12:37:58 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-07 12:37:58 --> Language Class Initialized
DEBUG - 2011-04-07 12:37:58 --> Loader Class Initialized
DEBUG - 2011-04-07 12:37:58 --> Controller Class Initialized
ERROR - 2011-04-07 12:37:58 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-04-07 12:37:58 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-04-07 12:37:58 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-04-07 12:37:58 --> Model Class Initialized
DEBUG - 2011-04-07 12:37:58 --> Model Class Initialized
DEBUG - 2011-04-07 12:37:58 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-07 12:37:58 --> Database Driver Class Initialized
DEBUG - 2011-04-07 12:37:58 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-04-07 12:37:58 --> Helper loaded: url_helper
DEBUG - 2011-04-07 12:37:58 --> File loaded: application/views/common/header.php
DEBUG - 2011-04-07 12:37:58 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-04-07 12:37:58 --> File loaded: application/views/common/footer.php
DEBUG - 2011-04-07 12:37:58 --> File loaded: application/views/layout/main.php
DEBUG - 2011-04-07 12:37:58 --> Final output sent to browser
DEBUG - 2011-04-07 12:37:58 --> Total execution time: 0.0312
DEBUG - 2011-04-07 12:37:58 --> Config Class Initialized
DEBUG - 2011-04-07 12:37:58 --> Hooks Class Initialized
DEBUG - 2011-04-07 12:37:58 --> Utf8 Class Initialized
DEBUG - 2011-04-07 12:37:58 --> UTF-8 Support Enabled
DEBUG - 2011-04-07 12:37:58 --> URI Class Initialized
DEBUG - 2011-04-07 12:37:58 --> Router Class Initialized
DEBUG - 2011-04-07 12:37:58 --> Output Class Initialized
DEBUG - 2011-04-07 12:37:58 --> Input Class Initialized
DEBUG - 2011-04-07 12:37:58 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-07 12:37:58 --> Language Class Initialized
DEBUG - 2011-04-07 12:37:58 --> Loader Class Initialized
DEBUG - 2011-04-07 12:37:58 --> Controller Class Initialized
DEBUG - 2011-04-07 12:37:58 --> Model Class Initialized
DEBUG - 2011-04-07 12:37:58 --> Model Class Initialized
DEBUG - 2011-04-07 12:37:58 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-07 12:37:58 --> Database Driver Class Initialized
DEBUG - 2011-04-07 12:38:00 --> Config Class Initialized
DEBUG - 2011-04-07 12:38:00 --> Hooks Class Initialized
DEBUG - 2011-04-07 12:38:00 --> Utf8 Class Initialized
DEBUG - 2011-04-07 12:38:00 --> UTF-8 Support Enabled
DEBUG - 2011-04-07 12:38:00 --> URI Class Initialized
DEBUG - 2011-04-07 12:38:00 --> Router Class Initialized
DEBUG - 2011-04-07 12:38:00 --> Output Class Initialized
DEBUG - 2011-04-07 12:38:00 --> Input Class Initialized
DEBUG - 2011-04-07 12:38:00 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-07 12:38:00 --> Language Class Initialized
DEBUG - 2011-04-07 12:38:00 --> Loader Class Initialized
DEBUG - 2011-04-07 12:38:00 --> Controller Class Initialized
ERROR - 2011-04-07 12:38:00 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-04-07 12:38:00 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-04-07 12:38:00 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-04-07 12:38:00 --> Model Class Initialized
DEBUG - 2011-04-07 12:38:00 --> Model Class Initialized
DEBUG - 2011-04-07 12:38:00 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-07 12:38:00 --> Database Driver Class Initialized
DEBUG - 2011-04-07 12:38:00 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-04-07 12:38:00 --> Helper loaded: url_helper
DEBUG - 2011-04-07 12:38:00 --> File loaded: application/views/common/header.php
DEBUG - 2011-04-07 12:38:00 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-04-07 12:38:00 --> File loaded: application/views/common/footer.php
DEBUG - 2011-04-07 12:38:00 --> File loaded: application/views/layout/main.php
DEBUG - 2011-04-07 12:38:00 --> Final output sent to browser
DEBUG - 2011-04-07 12:38:00 --> Total execution time: 0.0304
DEBUG - 2011-04-07 12:38:04 --> Final output sent to browser
DEBUG - 2011-04-07 12:38:04 --> Total execution time: 5.6830
DEBUG - 2011-04-07 12:38:04 --> Config Class Initialized
DEBUG - 2011-04-07 12:38:04 --> Hooks Class Initialized
DEBUG - 2011-04-07 12:38:04 --> Utf8 Class Initialized
DEBUG - 2011-04-07 12:38:04 --> UTF-8 Support Enabled
DEBUG - 2011-04-07 12:38:04 --> URI Class Initialized
DEBUG - 2011-04-07 12:38:04 --> Router Class Initialized
ERROR - 2011-04-07 12:38:04 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-04-07 12:38:11 --> Config Class Initialized
DEBUG - 2011-04-07 12:38:11 --> Hooks Class Initialized
DEBUG - 2011-04-07 12:38:11 --> Utf8 Class Initialized
DEBUG - 2011-04-07 12:38:11 --> UTF-8 Support Enabled
DEBUG - 2011-04-07 12:38:11 --> URI Class Initialized
DEBUG - 2011-04-07 12:38:11 --> Router Class Initialized
DEBUG - 2011-04-07 12:38:11 --> Output Class Initialized
DEBUG - 2011-04-07 12:38:11 --> Input Class Initialized
DEBUG - 2011-04-07 12:38:11 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-07 12:38:11 --> Language Class Initialized
DEBUG - 2011-04-07 12:38:11 --> Loader Class Initialized
DEBUG - 2011-04-07 12:38:11 --> Controller Class Initialized
ERROR - 2011-04-07 12:38:11 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-04-07 12:38:11 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-04-07 12:38:11 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-04-07 12:38:11 --> Model Class Initialized
DEBUG - 2011-04-07 12:38:11 --> Model Class Initialized
DEBUG - 2011-04-07 12:38:11 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-07 12:38:11 --> Database Driver Class Initialized
DEBUG - 2011-04-07 12:38:11 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-04-07 12:38:11 --> Helper loaded: url_helper
DEBUG - 2011-04-07 12:38:11 --> File loaded: application/views/common/header.php
DEBUG - 2011-04-07 12:38:11 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-04-07 12:38:11 --> File loaded: application/views/common/footer.php
DEBUG - 2011-04-07 12:38:11 --> File loaded: application/views/layout/main.php
DEBUG - 2011-04-07 12:38:11 --> Final output sent to browser
DEBUG - 2011-04-07 12:38:11 --> Total execution time: 0.0352
DEBUG - 2011-04-07 12:38:11 --> Config Class Initialized
DEBUG - 2011-04-07 12:38:11 --> Hooks Class Initialized
DEBUG - 2011-04-07 12:38:11 --> Utf8 Class Initialized
DEBUG - 2011-04-07 12:38:11 --> UTF-8 Support Enabled
DEBUG - 2011-04-07 12:38:11 --> URI Class Initialized
DEBUG - 2011-04-07 12:38:11 --> Router Class Initialized
DEBUG - 2011-04-07 12:38:11 --> Output Class Initialized
DEBUG - 2011-04-07 12:38:11 --> Input Class Initialized
DEBUG - 2011-04-07 12:38:11 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-07 12:38:11 --> Language Class Initialized
DEBUG - 2011-04-07 12:38:11 --> Loader Class Initialized
DEBUG - 2011-04-07 12:38:11 --> Controller Class Initialized
DEBUG - 2011-04-07 12:38:11 --> Model Class Initialized
DEBUG - 2011-04-07 12:38:11 --> Model Class Initialized
DEBUG - 2011-04-07 12:38:11 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-07 12:38:11 --> Database Driver Class Initialized
DEBUG - 2011-04-07 12:38:12 --> Final output sent to browser
DEBUG - 2011-04-07 12:38:12 --> Total execution time: 0.8542
DEBUG - 2011-04-07 12:38:13 --> Config Class Initialized
DEBUG - 2011-04-07 12:38:13 --> Hooks Class Initialized
DEBUG - 2011-04-07 12:38:13 --> Utf8 Class Initialized
DEBUG - 2011-04-07 12:38:13 --> UTF-8 Support Enabled
DEBUG - 2011-04-07 12:38:13 --> URI Class Initialized
DEBUG - 2011-04-07 12:38:13 --> Router Class Initialized
ERROR - 2011-04-07 12:38:13 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-04-07 12:38:26 --> Config Class Initialized
DEBUG - 2011-04-07 12:38:26 --> Hooks Class Initialized
DEBUG - 2011-04-07 12:38:26 --> Utf8 Class Initialized
DEBUG - 2011-04-07 12:38:26 --> UTF-8 Support Enabled
DEBUG - 2011-04-07 12:38:26 --> URI Class Initialized
DEBUG - 2011-04-07 12:38:26 --> Router Class Initialized
DEBUG - 2011-04-07 12:38:26 --> Output Class Initialized
DEBUG - 2011-04-07 12:38:26 --> Input Class Initialized
DEBUG - 2011-04-07 12:38:26 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-07 12:38:26 --> Language Class Initialized
DEBUG - 2011-04-07 12:38:26 --> Loader Class Initialized
DEBUG - 2011-04-07 12:38:26 --> Controller Class Initialized
ERROR - 2011-04-07 12:38:26 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-04-07 12:38:26 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-04-07 12:38:26 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-04-07 12:38:26 --> Model Class Initialized
DEBUG - 2011-04-07 12:38:26 --> Model Class Initialized
DEBUG - 2011-04-07 12:38:26 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-07 12:38:26 --> Database Driver Class Initialized
DEBUG - 2011-04-07 12:38:26 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-04-07 12:38:26 --> Helper loaded: url_helper
DEBUG - 2011-04-07 12:38:26 --> File loaded: application/views/common/header.php
DEBUG - 2011-04-07 12:38:26 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-04-07 12:38:26 --> File loaded: application/views/common/footer.php
DEBUG - 2011-04-07 12:38:26 --> File loaded: application/views/layout/main.php
DEBUG - 2011-04-07 12:38:26 --> Final output sent to browser
DEBUG - 2011-04-07 12:38:26 --> Total execution time: 0.0951
DEBUG - 2011-04-07 12:38:27 --> Config Class Initialized
DEBUG - 2011-04-07 12:38:27 --> Hooks Class Initialized
DEBUG - 2011-04-07 12:38:27 --> Utf8 Class Initialized
DEBUG - 2011-04-07 12:38:27 --> UTF-8 Support Enabled
DEBUG - 2011-04-07 12:38:27 --> URI Class Initialized
DEBUG - 2011-04-07 12:38:27 --> Router Class Initialized
DEBUG - 2011-04-07 12:38:27 --> Output Class Initialized
DEBUG - 2011-04-07 12:38:27 --> Input Class Initialized
DEBUG - 2011-04-07 12:38:27 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-07 12:38:27 --> Language Class Initialized
DEBUG - 2011-04-07 12:38:27 --> Loader Class Initialized
DEBUG - 2011-04-07 12:38:27 --> Controller Class Initialized
DEBUG - 2011-04-07 12:38:27 --> Model Class Initialized
DEBUG - 2011-04-07 12:38:27 --> Model Class Initialized
DEBUG - 2011-04-07 12:38:27 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-07 12:38:27 --> Database Driver Class Initialized
DEBUG - 2011-04-07 12:38:27 --> Config Class Initialized
DEBUG - 2011-04-07 12:38:27 --> Hooks Class Initialized
DEBUG - 2011-04-07 12:38:27 --> Utf8 Class Initialized
DEBUG - 2011-04-07 12:38:27 --> UTF-8 Support Enabled
DEBUG - 2011-04-07 12:38:27 --> URI Class Initialized
DEBUG - 2011-04-07 12:38:27 --> Router Class Initialized
DEBUG - 2011-04-07 12:38:27 --> Output Class Initialized
DEBUG - 2011-04-07 12:38:27 --> Input Class Initialized
DEBUG - 2011-04-07 12:38:27 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-07 12:38:27 --> Language Class Initialized
DEBUG - 2011-04-07 12:38:27 --> Loader Class Initialized
DEBUG - 2011-04-07 12:38:27 --> Controller Class Initialized
ERROR - 2011-04-07 12:38:27 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-04-07 12:38:27 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-04-07 12:38:27 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-04-07 12:38:27 --> Model Class Initialized
DEBUG - 2011-04-07 12:38:27 --> Model Class Initialized
DEBUG - 2011-04-07 12:38:27 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-07 12:38:28 --> Database Driver Class Initialized
DEBUG - 2011-04-07 12:38:28 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-04-07 12:38:28 --> Helper loaded: url_helper
DEBUG - 2011-04-07 12:38:28 --> File loaded: application/views/common/header.php
DEBUG - 2011-04-07 12:38:28 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-04-07 12:38:28 --> File loaded: application/views/common/footer.php
DEBUG - 2011-04-07 12:38:28 --> File loaded: application/views/layout/main.php
DEBUG - 2011-04-07 12:38:28 --> Final output sent to browser
DEBUG - 2011-04-07 12:38:28 --> Total execution time: 0.1254
DEBUG - 2011-04-07 12:38:28 --> Final output sent to browser
DEBUG - 2011-04-07 12:38:28 --> Total execution time: 0.8616
DEBUG - 2011-04-07 12:38:29 --> Config Class Initialized
DEBUG - 2011-04-07 12:38:29 --> Hooks Class Initialized
DEBUG - 2011-04-07 12:38:29 --> Utf8 Class Initialized
DEBUG - 2011-04-07 12:38:29 --> UTF-8 Support Enabled
DEBUG - 2011-04-07 12:38:29 --> URI Class Initialized
DEBUG - 2011-04-07 12:38:29 --> Router Class Initialized
ERROR - 2011-04-07 12:38:29 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-04-07 12:38:36 --> Config Class Initialized
DEBUG - 2011-04-07 12:38:36 --> Hooks Class Initialized
DEBUG - 2011-04-07 12:38:36 --> Utf8 Class Initialized
DEBUG - 2011-04-07 12:38:36 --> UTF-8 Support Enabled
DEBUG - 2011-04-07 12:38:36 --> URI Class Initialized
DEBUG - 2011-04-07 12:38:36 --> Router Class Initialized
DEBUG - 2011-04-07 12:38:36 --> Output Class Initialized
DEBUG - 2011-04-07 12:38:36 --> Input Class Initialized
DEBUG - 2011-04-07 12:38:36 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-07 12:38:36 --> Language Class Initialized
DEBUG - 2011-04-07 12:38:36 --> Loader Class Initialized
DEBUG - 2011-04-07 12:38:36 --> Controller Class Initialized
ERROR - 2011-04-07 12:38:36 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-04-07 12:38:36 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-04-07 12:38:36 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-04-07 12:38:36 --> Model Class Initialized
DEBUG - 2011-04-07 12:38:36 --> Model Class Initialized
DEBUG - 2011-04-07 12:38:36 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-07 12:38:36 --> Database Driver Class Initialized
DEBUG - 2011-04-07 12:38:36 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-04-07 12:38:36 --> Helper loaded: url_helper
DEBUG - 2011-04-07 12:38:36 --> File loaded: application/views/common/header.php
DEBUG - 2011-04-07 12:38:36 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-04-07 12:38:36 --> File loaded: application/views/common/footer.php
DEBUG - 2011-04-07 12:38:36 --> File loaded: application/views/layout/main.php
DEBUG - 2011-04-07 12:38:36 --> Final output sent to browser
DEBUG - 2011-04-07 12:38:36 --> Total execution time: 0.0278
DEBUG - 2011-04-07 12:38:37 --> Config Class Initialized
DEBUG - 2011-04-07 12:38:37 --> Hooks Class Initialized
DEBUG - 2011-04-07 12:38:37 --> Utf8 Class Initialized
DEBUG - 2011-04-07 12:38:37 --> UTF-8 Support Enabled
DEBUG - 2011-04-07 12:38:37 --> URI Class Initialized
DEBUG - 2011-04-07 12:38:37 --> Router Class Initialized
DEBUG - 2011-04-07 12:38:37 --> Output Class Initialized
DEBUG - 2011-04-07 12:38:37 --> Input Class Initialized
DEBUG - 2011-04-07 12:38:37 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-07 12:38:37 --> Language Class Initialized
DEBUG - 2011-04-07 12:38:37 --> Loader Class Initialized
DEBUG - 2011-04-07 12:38:37 --> Controller Class Initialized
DEBUG - 2011-04-07 12:38:37 --> Model Class Initialized
DEBUG - 2011-04-07 12:38:37 --> Model Class Initialized
DEBUG - 2011-04-07 12:38:37 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-07 12:38:37 --> Database Driver Class Initialized
DEBUG - 2011-04-07 12:38:37 --> Config Class Initialized
DEBUG - 2011-04-07 12:38:37 --> Hooks Class Initialized
DEBUG - 2011-04-07 12:38:37 --> Utf8 Class Initialized
DEBUG - 2011-04-07 12:38:37 --> UTF-8 Support Enabled
DEBUG - 2011-04-07 12:38:37 --> URI Class Initialized
DEBUG - 2011-04-07 12:38:37 --> Router Class Initialized
DEBUG - 2011-04-07 12:38:37 --> Output Class Initialized
DEBUG - 2011-04-07 12:38:37 --> Input Class Initialized
DEBUG - 2011-04-07 12:38:37 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-07 12:38:37 --> Language Class Initialized
DEBUG - 2011-04-07 12:38:37 --> Loader Class Initialized
DEBUG - 2011-04-07 12:38:37 --> Controller Class Initialized
ERROR - 2011-04-07 12:38:37 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-04-07 12:38:37 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-04-07 12:38:37 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-04-07 12:38:37 --> Model Class Initialized
DEBUG - 2011-04-07 12:38:37 --> Model Class Initialized
DEBUG - 2011-04-07 12:38:37 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-07 12:38:37 --> Database Driver Class Initialized
DEBUG - 2011-04-07 12:38:37 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-04-07 12:38:37 --> Helper loaded: url_helper
DEBUG - 2011-04-07 12:38:37 --> File loaded: application/views/common/header.php
DEBUG - 2011-04-07 12:38:37 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-04-07 12:38:37 --> File loaded: application/views/common/footer.php
DEBUG - 2011-04-07 12:38:37 --> File loaded: application/views/layout/main.php
DEBUG - 2011-04-07 12:38:37 --> Final output sent to browser
DEBUG - 2011-04-07 12:38:37 --> Total execution time: 0.0289
DEBUG - 2011-04-07 12:38:37 --> Final output sent to browser
DEBUG - 2011-04-07 12:38:37 --> Total execution time: 0.7104
DEBUG - 2011-04-07 12:38:38 --> Config Class Initialized
DEBUG - 2011-04-07 12:38:38 --> Hooks Class Initialized
DEBUG - 2011-04-07 12:38:38 --> Utf8 Class Initialized
DEBUG - 2011-04-07 12:38:38 --> UTF-8 Support Enabled
DEBUG - 2011-04-07 12:38:38 --> URI Class Initialized
DEBUG - 2011-04-07 12:38:38 --> Router Class Initialized
ERROR - 2011-04-07 12:38:38 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-04-07 12:38:43 --> Config Class Initialized
DEBUG - 2011-04-07 12:38:43 --> Hooks Class Initialized
DEBUG - 2011-04-07 12:38:43 --> Utf8 Class Initialized
DEBUG - 2011-04-07 12:38:43 --> UTF-8 Support Enabled
DEBUG - 2011-04-07 12:38:43 --> URI Class Initialized
DEBUG - 2011-04-07 12:38:43 --> Router Class Initialized
DEBUG - 2011-04-07 12:38:43 --> Output Class Initialized
DEBUG - 2011-04-07 12:38:43 --> Input Class Initialized
DEBUG - 2011-04-07 12:38:43 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-07 12:38:43 --> Language Class Initialized
DEBUG - 2011-04-07 12:38:43 --> Loader Class Initialized
DEBUG - 2011-04-07 12:38:43 --> Controller Class Initialized
ERROR - 2011-04-07 12:38:43 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-04-07 12:38:43 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-04-07 12:38:43 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-04-07 12:38:43 --> Model Class Initialized
DEBUG - 2011-04-07 12:38:43 --> Model Class Initialized
DEBUG - 2011-04-07 12:38:43 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-07 12:38:43 --> Database Driver Class Initialized
DEBUG - 2011-04-07 12:38:43 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-04-07 12:38:43 --> Helper loaded: url_helper
DEBUG - 2011-04-07 12:38:43 --> File loaded: application/views/common/header.php
DEBUG - 2011-04-07 12:38:43 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-04-07 12:38:43 --> File loaded: application/views/common/footer.php
DEBUG - 2011-04-07 12:38:43 --> File loaded: application/views/layout/main.php
DEBUG - 2011-04-07 12:38:43 --> Final output sent to browser
DEBUG - 2011-04-07 12:38:43 --> Total execution time: 0.0286
DEBUG - 2011-04-07 12:38:44 --> Config Class Initialized
DEBUG - 2011-04-07 12:38:44 --> Hooks Class Initialized
DEBUG - 2011-04-07 12:38:44 --> Utf8 Class Initialized
DEBUG - 2011-04-07 12:38:44 --> UTF-8 Support Enabled
DEBUG - 2011-04-07 12:38:44 --> URI Class Initialized
DEBUG - 2011-04-07 12:38:44 --> Router Class Initialized
DEBUG - 2011-04-07 12:38:44 --> Output Class Initialized
DEBUG - 2011-04-07 12:38:44 --> Input Class Initialized
DEBUG - 2011-04-07 12:38:44 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-07 12:38:44 --> Language Class Initialized
DEBUG - 2011-04-07 12:38:44 --> Loader Class Initialized
DEBUG - 2011-04-07 12:38:44 --> Controller Class Initialized
DEBUG - 2011-04-07 12:38:44 --> Model Class Initialized
DEBUG - 2011-04-07 12:38:44 --> Model Class Initialized
DEBUG - 2011-04-07 12:38:44 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-07 12:38:44 --> Database Driver Class Initialized
DEBUG - 2011-04-07 12:38:45 --> Final output sent to browser
DEBUG - 2011-04-07 12:38:45 --> Total execution time: 0.9195
DEBUG - 2011-04-07 12:38:45 --> Config Class Initialized
DEBUG - 2011-04-07 12:38:45 --> Hooks Class Initialized
DEBUG - 2011-04-07 12:38:45 --> Utf8 Class Initialized
DEBUG - 2011-04-07 12:38:45 --> UTF-8 Support Enabled
DEBUG - 2011-04-07 12:38:45 --> URI Class Initialized
DEBUG - 2011-04-07 12:38:45 --> Router Class Initialized
ERROR - 2011-04-07 12:38:45 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-04-07 12:38:51 --> Config Class Initialized
DEBUG - 2011-04-07 12:38:51 --> Hooks Class Initialized
DEBUG - 2011-04-07 12:38:51 --> Utf8 Class Initialized
DEBUG - 2011-04-07 12:38:51 --> UTF-8 Support Enabled
DEBUG - 2011-04-07 12:38:51 --> URI Class Initialized
DEBUG - 2011-04-07 12:38:51 --> Router Class Initialized
DEBUG - 2011-04-07 12:38:51 --> Output Class Initialized
DEBUG - 2011-04-07 12:38:51 --> Input Class Initialized
DEBUG - 2011-04-07 12:38:51 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-07 12:38:51 --> Language Class Initialized
DEBUG - 2011-04-07 12:38:51 --> Loader Class Initialized
DEBUG - 2011-04-07 12:38:51 --> Controller Class Initialized
ERROR - 2011-04-07 12:38:51 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-04-07 12:38:51 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-04-07 12:38:51 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-04-07 12:38:51 --> Model Class Initialized
DEBUG - 2011-04-07 12:38:51 --> Model Class Initialized
DEBUG - 2011-04-07 12:38:51 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-07 12:38:51 --> Database Driver Class Initialized
DEBUG - 2011-04-07 12:38:51 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-04-07 12:38:51 --> Helper loaded: url_helper
DEBUG - 2011-04-07 12:38:51 --> File loaded: application/views/common/header.php
DEBUG - 2011-04-07 12:38:51 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-04-07 12:38:51 --> File loaded: application/views/common/footer.php
DEBUG - 2011-04-07 12:38:51 --> File loaded: application/views/layout/main.php
DEBUG - 2011-04-07 12:38:51 --> Final output sent to browser
DEBUG - 2011-04-07 12:38:51 --> Total execution time: 0.1698
DEBUG - 2011-04-07 12:38:52 --> Config Class Initialized
DEBUG - 2011-04-07 12:38:52 --> Hooks Class Initialized
DEBUG - 2011-04-07 12:38:52 --> Utf8 Class Initialized
DEBUG - 2011-04-07 12:38:52 --> UTF-8 Support Enabled
DEBUG - 2011-04-07 12:38:52 --> URI Class Initialized
DEBUG - 2011-04-07 12:38:52 --> Router Class Initialized
DEBUG - 2011-04-07 12:38:52 --> Output Class Initialized
DEBUG - 2011-04-07 12:38:52 --> Input Class Initialized
DEBUG - 2011-04-07 12:38:52 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-07 12:38:52 --> Language Class Initialized
DEBUG - 2011-04-07 12:38:52 --> Loader Class Initialized
DEBUG - 2011-04-07 12:38:52 --> Controller Class Initialized
DEBUG - 2011-04-07 12:38:52 --> Model Class Initialized
DEBUG - 2011-04-07 12:38:52 --> Model Class Initialized
DEBUG - 2011-04-07 12:38:52 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-07 12:38:52 --> Database Driver Class Initialized
DEBUG - 2011-04-07 12:38:52 --> Final output sent to browser
DEBUG - 2011-04-07 12:38:52 --> Total execution time: 0.7892
DEBUG - 2011-04-07 12:38:53 --> Config Class Initialized
DEBUG - 2011-04-07 12:38:53 --> Hooks Class Initialized
DEBUG - 2011-04-07 12:38:53 --> Utf8 Class Initialized
DEBUG - 2011-04-07 12:38:53 --> UTF-8 Support Enabled
DEBUG - 2011-04-07 12:38:53 --> URI Class Initialized
DEBUG - 2011-04-07 12:38:53 --> Router Class Initialized
ERROR - 2011-04-07 12:38:53 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-04-07 12:38:58 --> Config Class Initialized
DEBUG - 2011-04-07 12:38:58 --> Hooks Class Initialized
DEBUG - 2011-04-07 12:38:58 --> Utf8 Class Initialized
DEBUG - 2011-04-07 12:38:58 --> UTF-8 Support Enabled
DEBUG - 2011-04-07 12:38:58 --> URI Class Initialized
DEBUG - 2011-04-07 12:38:58 --> Router Class Initialized
DEBUG - 2011-04-07 12:38:58 --> Output Class Initialized
DEBUG - 2011-04-07 12:38:58 --> Input Class Initialized
DEBUG - 2011-04-07 12:38:58 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-07 12:38:58 --> Language Class Initialized
DEBUG - 2011-04-07 12:38:58 --> Loader Class Initialized
DEBUG - 2011-04-07 12:38:58 --> Controller Class Initialized
ERROR - 2011-04-07 12:38:58 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-04-07 12:38:58 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-04-07 12:38:58 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-04-07 12:38:58 --> Model Class Initialized
DEBUG - 2011-04-07 12:38:58 --> Model Class Initialized
DEBUG - 2011-04-07 12:38:58 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-07 12:38:58 --> Database Driver Class Initialized
DEBUG - 2011-04-07 12:38:58 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-04-07 12:38:58 --> Helper loaded: url_helper
DEBUG - 2011-04-07 12:38:58 --> File loaded: application/views/common/header.php
DEBUG - 2011-04-07 12:38:58 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-04-07 12:38:58 --> File loaded: application/views/common/footer.php
DEBUG - 2011-04-07 12:38:58 --> File loaded: application/views/layout/main.php
DEBUG - 2011-04-07 12:38:58 --> Final output sent to browser
DEBUG - 2011-04-07 12:38:58 --> Total execution time: 0.0551
DEBUG - 2011-04-07 12:38:59 --> Config Class Initialized
DEBUG - 2011-04-07 12:38:59 --> Hooks Class Initialized
DEBUG - 2011-04-07 12:38:59 --> Utf8 Class Initialized
DEBUG - 2011-04-07 12:38:59 --> UTF-8 Support Enabled
DEBUG - 2011-04-07 12:38:59 --> URI Class Initialized
DEBUG - 2011-04-07 12:38:59 --> Router Class Initialized
DEBUG - 2011-04-07 12:38:59 --> Output Class Initialized
DEBUG - 2011-04-07 12:38:59 --> Input Class Initialized
DEBUG - 2011-04-07 12:38:59 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-07 12:38:59 --> Language Class Initialized
DEBUG - 2011-04-07 12:38:59 --> Loader Class Initialized
DEBUG - 2011-04-07 12:38:59 --> Controller Class Initialized
DEBUG - 2011-04-07 12:38:59 --> Model Class Initialized
DEBUG - 2011-04-07 12:38:59 --> Model Class Initialized
DEBUG - 2011-04-07 12:38:59 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-07 12:38:59 --> Database Driver Class Initialized
DEBUG - 2011-04-07 12:38:59 --> Final output sent to browser
DEBUG - 2011-04-07 12:38:59 --> Total execution time: 0.7212
DEBUG - 2011-04-07 12:39:00 --> Config Class Initialized
DEBUG - 2011-04-07 12:39:00 --> Hooks Class Initialized
DEBUG - 2011-04-07 12:39:00 --> Utf8 Class Initialized
DEBUG - 2011-04-07 12:39:00 --> UTF-8 Support Enabled
DEBUG - 2011-04-07 12:39:00 --> URI Class Initialized
DEBUG - 2011-04-07 12:39:00 --> Router Class Initialized
ERROR - 2011-04-07 12:39:00 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-04-07 12:39:05 --> Config Class Initialized
DEBUG - 2011-04-07 12:39:05 --> Hooks Class Initialized
DEBUG - 2011-04-07 12:39:05 --> Utf8 Class Initialized
DEBUG - 2011-04-07 12:39:05 --> UTF-8 Support Enabled
DEBUG - 2011-04-07 12:39:05 --> URI Class Initialized
DEBUG - 2011-04-07 12:39:05 --> Router Class Initialized
DEBUG - 2011-04-07 12:39:05 --> Output Class Initialized
DEBUG - 2011-04-07 12:39:05 --> Input Class Initialized
DEBUG - 2011-04-07 12:39:05 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-07 12:39:05 --> Language Class Initialized
DEBUG - 2011-04-07 12:39:05 --> Loader Class Initialized
DEBUG - 2011-04-07 12:39:05 --> Controller Class Initialized
ERROR - 2011-04-07 12:39:05 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-04-07 12:39:05 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-04-07 12:39:05 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-04-07 12:39:05 --> Model Class Initialized
DEBUG - 2011-04-07 12:39:05 --> Model Class Initialized
DEBUG - 2011-04-07 12:39:05 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-07 12:39:05 --> Database Driver Class Initialized
DEBUG - 2011-04-07 12:39:05 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-04-07 12:39:05 --> Helper loaded: url_helper
DEBUG - 2011-04-07 12:39:05 --> File loaded: application/views/common/header.php
DEBUG - 2011-04-07 12:39:05 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-04-07 12:39:05 --> File loaded: application/views/common/footer.php
DEBUG - 2011-04-07 12:39:05 --> File loaded: application/views/layout/main.php
DEBUG - 2011-04-07 12:39:05 --> Final output sent to browser
DEBUG - 2011-04-07 12:39:05 --> Total execution time: 0.0377
DEBUG - 2011-04-07 12:39:05 --> Config Class Initialized
DEBUG - 2011-04-07 12:39:05 --> Hooks Class Initialized
DEBUG - 2011-04-07 12:39:05 --> Utf8 Class Initialized
DEBUG - 2011-04-07 12:39:05 --> UTF-8 Support Enabled
DEBUG - 2011-04-07 12:39:05 --> URI Class Initialized
DEBUG - 2011-04-07 12:39:05 --> Router Class Initialized
DEBUG - 2011-04-07 12:39:05 --> Output Class Initialized
DEBUG - 2011-04-07 12:39:05 --> Input Class Initialized
DEBUG - 2011-04-07 12:39:05 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-07 12:39:05 --> Language Class Initialized
DEBUG - 2011-04-07 12:39:05 --> Loader Class Initialized
DEBUG - 2011-04-07 12:39:05 --> Controller Class Initialized
DEBUG - 2011-04-07 12:39:05 --> Model Class Initialized
DEBUG - 2011-04-07 12:39:05 --> Model Class Initialized
DEBUG - 2011-04-07 12:39:05 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-07 12:39:05 --> Database Driver Class Initialized
DEBUG - 2011-04-07 12:39:06 --> Final output sent to browser
DEBUG - 2011-04-07 12:39:06 --> Total execution time: 0.7011
DEBUG - 2011-04-07 12:39:07 --> Config Class Initialized
DEBUG - 2011-04-07 12:39:07 --> Hooks Class Initialized
DEBUG - 2011-04-07 12:39:07 --> Utf8 Class Initialized
DEBUG - 2011-04-07 12:39:07 --> UTF-8 Support Enabled
DEBUG - 2011-04-07 12:39:07 --> URI Class Initialized
DEBUG - 2011-04-07 12:39:07 --> Router Class Initialized
ERROR - 2011-04-07 12:39:07 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-04-07 12:39:18 --> Config Class Initialized
DEBUG - 2011-04-07 12:39:18 --> Hooks Class Initialized
DEBUG - 2011-04-07 12:39:18 --> Utf8 Class Initialized
DEBUG - 2011-04-07 12:39:18 --> UTF-8 Support Enabled
DEBUG - 2011-04-07 12:39:18 --> URI Class Initialized
DEBUG - 2011-04-07 12:39:18 --> Router Class Initialized
DEBUG - 2011-04-07 12:39:18 --> Output Class Initialized
DEBUG - 2011-04-07 12:39:18 --> Input Class Initialized
DEBUG - 2011-04-07 12:39:18 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-07 12:39:18 --> Language Class Initialized
DEBUG - 2011-04-07 12:39:18 --> Loader Class Initialized
DEBUG - 2011-04-07 12:39:18 --> Controller Class Initialized
ERROR - 2011-04-07 12:39:18 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-04-07 12:39:18 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-04-07 12:39:18 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-04-07 12:39:18 --> Model Class Initialized
DEBUG - 2011-04-07 12:39:18 --> Model Class Initialized
DEBUG - 2011-04-07 12:39:18 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-07 12:39:18 --> Database Driver Class Initialized
DEBUG - 2011-04-07 12:39:18 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-04-07 12:39:18 --> Helper loaded: url_helper
DEBUG - 2011-04-07 12:39:18 --> File loaded: application/views/common/header.php
DEBUG - 2011-04-07 12:39:18 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-04-07 12:39:18 --> File loaded: application/views/common/footer.php
DEBUG - 2011-04-07 12:39:18 --> File loaded: application/views/layout/main.php
DEBUG - 2011-04-07 12:39:18 --> Final output sent to browser
DEBUG - 2011-04-07 12:39:18 --> Total execution time: 0.2441
DEBUG - 2011-04-07 12:39:19 --> Config Class Initialized
DEBUG - 2011-04-07 12:39:19 --> Hooks Class Initialized
DEBUG - 2011-04-07 12:39:19 --> Utf8 Class Initialized
DEBUG - 2011-04-07 12:39:19 --> UTF-8 Support Enabled
DEBUG - 2011-04-07 12:39:19 --> URI Class Initialized
DEBUG - 2011-04-07 12:39:19 --> Router Class Initialized
DEBUG - 2011-04-07 12:39:19 --> Output Class Initialized
DEBUG - 2011-04-07 12:39:19 --> Input Class Initialized
DEBUG - 2011-04-07 12:39:19 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-07 12:39:19 --> Language Class Initialized
DEBUG - 2011-04-07 12:39:19 --> Loader Class Initialized
DEBUG - 2011-04-07 12:39:19 --> Controller Class Initialized
DEBUG - 2011-04-07 12:39:19 --> Model Class Initialized
DEBUG - 2011-04-07 12:39:19 --> Model Class Initialized
DEBUG - 2011-04-07 12:39:19 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-07 12:39:19 --> Database Driver Class Initialized
DEBUG - 2011-04-07 12:39:20 --> Final output sent to browser
DEBUG - 2011-04-07 12:39:20 --> Total execution time: 0.7737
DEBUG - 2011-04-07 12:39:22 --> Config Class Initialized
DEBUG - 2011-04-07 12:39:22 --> Hooks Class Initialized
DEBUG - 2011-04-07 12:39:22 --> Utf8 Class Initialized
DEBUG - 2011-04-07 12:39:22 --> UTF-8 Support Enabled
DEBUG - 2011-04-07 12:39:22 --> URI Class Initialized
DEBUG - 2011-04-07 12:39:22 --> Router Class Initialized
ERROR - 2011-04-07 12:39:22 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-04-07 12:39:25 --> Config Class Initialized
DEBUG - 2011-04-07 12:39:25 --> Hooks Class Initialized
DEBUG - 2011-04-07 12:39:25 --> Utf8 Class Initialized
DEBUG - 2011-04-07 12:39:25 --> UTF-8 Support Enabled
DEBUG - 2011-04-07 12:39:25 --> URI Class Initialized
DEBUG - 2011-04-07 12:39:25 --> Router Class Initialized
DEBUG - 2011-04-07 12:39:25 --> Output Class Initialized
DEBUG - 2011-04-07 12:39:25 --> Input Class Initialized
DEBUG - 2011-04-07 12:39:25 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-07 12:39:25 --> Language Class Initialized
DEBUG - 2011-04-07 12:39:25 --> Loader Class Initialized
DEBUG - 2011-04-07 12:39:25 --> Controller Class Initialized
ERROR - 2011-04-07 12:39:25 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-04-07 12:39:25 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-04-07 12:39:25 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-04-07 12:39:25 --> Model Class Initialized
DEBUG - 2011-04-07 12:39:25 --> Model Class Initialized
DEBUG - 2011-04-07 12:39:25 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-07 12:39:26 --> Database Driver Class Initialized
DEBUG - 2011-04-07 12:39:26 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-04-07 12:39:26 --> Helper loaded: url_helper
DEBUG - 2011-04-07 12:39:26 --> File loaded: application/views/common/header.php
DEBUG - 2011-04-07 12:39:26 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-04-07 12:39:26 --> File loaded: application/views/common/footer.php
DEBUG - 2011-04-07 12:39:26 --> File loaded: application/views/layout/main.php
DEBUG - 2011-04-07 12:39:26 --> Final output sent to browser
DEBUG - 2011-04-07 12:39:26 --> Total execution time: 0.9322
DEBUG - 2011-04-07 12:39:26 --> Config Class Initialized
DEBUG - 2011-04-07 12:39:26 --> Hooks Class Initialized
DEBUG - 2011-04-07 12:39:26 --> Utf8 Class Initialized
DEBUG - 2011-04-07 12:39:26 --> UTF-8 Support Enabled
DEBUG - 2011-04-07 12:39:26 --> URI Class Initialized
DEBUG - 2011-04-07 12:39:26 --> Router Class Initialized
DEBUG - 2011-04-07 12:39:26 --> Output Class Initialized
DEBUG - 2011-04-07 12:39:26 --> Input Class Initialized
DEBUG - 2011-04-07 12:39:26 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-07 12:39:26 --> Language Class Initialized
DEBUG - 2011-04-07 12:39:26 --> Loader Class Initialized
DEBUG - 2011-04-07 12:39:26 --> Controller Class Initialized
DEBUG - 2011-04-07 12:39:26 --> Model Class Initialized
DEBUG - 2011-04-07 12:39:26 --> Model Class Initialized
DEBUG - 2011-04-07 12:39:26 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-07 12:39:26 --> Database Driver Class Initialized
DEBUG - 2011-04-07 12:39:27 --> Final output sent to browser
DEBUG - 2011-04-07 12:39:27 --> Total execution time: 0.8814
DEBUG - 2011-04-07 12:39:28 --> Config Class Initialized
DEBUG - 2011-04-07 12:39:28 --> Hooks Class Initialized
DEBUG - 2011-04-07 12:39:28 --> Utf8 Class Initialized
DEBUG - 2011-04-07 12:39:28 --> UTF-8 Support Enabled
DEBUG - 2011-04-07 12:39:28 --> URI Class Initialized
DEBUG - 2011-04-07 12:39:28 --> Router Class Initialized
ERROR - 2011-04-07 12:39:28 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-04-07 12:39:34 --> Config Class Initialized
DEBUG - 2011-04-07 12:39:34 --> Hooks Class Initialized
DEBUG - 2011-04-07 12:39:34 --> Utf8 Class Initialized
DEBUG - 2011-04-07 12:39:34 --> UTF-8 Support Enabled
DEBUG - 2011-04-07 12:39:34 --> URI Class Initialized
DEBUG - 2011-04-07 12:39:34 --> Router Class Initialized
DEBUG - 2011-04-07 12:39:34 --> Output Class Initialized
DEBUG - 2011-04-07 12:39:34 --> Input Class Initialized
DEBUG - 2011-04-07 12:39:34 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-07 12:39:34 --> Language Class Initialized
DEBUG - 2011-04-07 12:39:34 --> Loader Class Initialized
DEBUG - 2011-04-07 12:39:34 --> Controller Class Initialized
ERROR - 2011-04-07 12:39:34 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-04-07 12:39:34 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-04-07 12:39:34 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-04-07 12:39:34 --> Model Class Initialized
DEBUG - 2011-04-07 12:39:34 --> Model Class Initialized
DEBUG - 2011-04-07 12:39:34 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-07 12:39:34 --> Database Driver Class Initialized
DEBUG - 2011-04-07 12:39:34 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-04-07 12:39:34 --> Helper loaded: url_helper
DEBUG - 2011-04-07 12:39:34 --> File loaded: application/views/common/header.php
DEBUG - 2011-04-07 12:39:34 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-04-07 12:39:34 --> File loaded: application/views/common/footer.php
DEBUG - 2011-04-07 12:39:34 --> File loaded: application/views/layout/main.php
DEBUG - 2011-04-07 12:39:34 --> Final output sent to browser
DEBUG - 2011-04-07 12:39:34 --> Total execution time: 0.0890
DEBUG - 2011-04-07 12:39:35 --> Config Class Initialized
DEBUG - 2011-04-07 12:39:35 --> Hooks Class Initialized
DEBUG - 2011-04-07 12:39:35 --> Utf8 Class Initialized
DEBUG - 2011-04-07 12:39:35 --> UTF-8 Support Enabled
DEBUG - 2011-04-07 12:39:35 --> URI Class Initialized
DEBUG - 2011-04-07 12:39:35 --> Router Class Initialized
DEBUG - 2011-04-07 12:39:35 --> Output Class Initialized
DEBUG - 2011-04-07 12:39:35 --> Input Class Initialized
DEBUG - 2011-04-07 12:39:35 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-07 12:39:35 --> Language Class Initialized
DEBUG - 2011-04-07 12:39:35 --> Loader Class Initialized
DEBUG - 2011-04-07 12:39:35 --> Controller Class Initialized
DEBUG - 2011-04-07 12:39:35 --> Model Class Initialized
DEBUG - 2011-04-07 12:39:35 --> Model Class Initialized
DEBUG - 2011-04-07 12:39:35 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-07 12:39:35 --> Database Driver Class Initialized
DEBUG - 2011-04-07 12:39:36 --> Final output sent to browser
DEBUG - 2011-04-07 12:39:36 --> Total execution time: 0.6984
DEBUG - 2011-04-07 12:39:37 --> Config Class Initialized
DEBUG - 2011-04-07 12:39:37 --> Hooks Class Initialized
DEBUG - 2011-04-07 12:39:37 --> Utf8 Class Initialized
DEBUG - 2011-04-07 12:39:37 --> UTF-8 Support Enabled
DEBUG - 2011-04-07 12:39:37 --> URI Class Initialized
DEBUG - 2011-04-07 12:39:37 --> Router Class Initialized
ERROR - 2011-04-07 12:39:37 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-04-07 12:39:51 --> Config Class Initialized
DEBUG - 2011-04-07 12:39:51 --> Hooks Class Initialized
DEBUG - 2011-04-07 12:39:51 --> Utf8 Class Initialized
DEBUG - 2011-04-07 12:39:51 --> UTF-8 Support Enabled
DEBUG - 2011-04-07 12:39:51 --> URI Class Initialized
DEBUG - 2011-04-07 12:39:51 --> Router Class Initialized
DEBUG - 2011-04-07 12:39:51 --> Output Class Initialized
DEBUG - 2011-04-07 12:39:51 --> Input Class Initialized
DEBUG - 2011-04-07 12:39:51 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-07 12:39:51 --> Language Class Initialized
DEBUG - 2011-04-07 12:39:51 --> Loader Class Initialized
DEBUG - 2011-04-07 12:39:51 --> Controller Class Initialized
ERROR - 2011-04-07 12:39:51 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-04-07 12:39:51 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-04-07 12:39:51 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-04-07 12:39:51 --> Model Class Initialized
DEBUG - 2011-04-07 12:39:51 --> Model Class Initialized
DEBUG - 2011-04-07 12:39:51 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-07 12:39:51 --> Database Driver Class Initialized
DEBUG - 2011-04-07 12:39:51 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-04-07 12:39:51 --> Helper loaded: url_helper
DEBUG - 2011-04-07 12:39:51 --> File loaded: application/views/common/header.php
DEBUG - 2011-04-07 12:39:51 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-04-07 12:39:51 --> File loaded: application/views/common/footer.php
DEBUG - 2011-04-07 12:39:51 --> File loaded: application/views/layout/main.php
DEBUG - 2011-04-07 12:39:51 --> Final output sent to browser
DEBUG - 2011-04-07 12:39:51 --> Total execution time: 0.1035
DEBUG - 2011-04-07 12:39:52 --> Config Class Initialized
DEBUG - 2011-04-07 12:39:52 --> Hooks Class Initialized
DEBUG - 2011-04-07 12:39:52 --> Utf8 Class Initialized
DEBUG - 2011-04-07 12:39:52 --> UTF-8 Support Enabled
DEBUG - 2011-04-07 12:39:52 --> URI Class Initialized
DEBUG - 2011-04-07 12:39:52 --> Router Class Initialized
DEBUG - 2011-04-07 12:39:52 --> Output Class Initialized
DEBUG - 2011-04-07 12:39:52 --> Input Class Initialized
DEBUG - 2011-04-07 12:39:52 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-07 12:39:52 --> Language Class Initialized
DEBUG - 2011-04-07 12:39:52 --> Loader Class Initialized
DEBUG - 2011-04-07 12:39:52 --> Controller Class Initialized
DEBUG - 2011-04-07 12:39:52 --> Model Class Initialized
DEBUG - 2011-04-07 12:39:52 --> Model Class Initialized
DEBUG - 2011-04-07 12:39:52 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-07 12:39:52 --> Database Driver Class Initialized
DEBUG - 2011-04-07 12:39:54 --> Final output sent to browser
DEBUG - 2011-04-07 12:39:54 --> Total execution time: 2.3033
DEBUG - 2011-04-07 12:39:56 --> Config Class Initialized
DEBUG - 2011-04-07 12:39:56 --> Hooks Class Initialized
DEBUG - 2011-04-07 12:39:56 --> Utf8 Class Initialized
DEBUG - 2011-04-07 12:39:56 --> UTF-8 Support Enabled
DEBUG - 2011-04-07 12:39:56 --> URI Class Initialized
DEBUG - 2011-04-07 12:39:56 --> Router Class Initialized
ERROR - 2011-04-07 12:39:56 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-04-07 12:39:56 --> Config Class Initialized
DEBUG - 2011-04-07 12:39:56 --> Hooks Class Initialized
DEBUG - 2011-04-07 12:39:56 --> Utf8 Class Initialized
DEBUG - 2011-04-07 12:39:56 --> UTF-8 Support Enabled
DEBUG - 2011-04-07 12:39:56 --> URI Class Initialized
DEBUG - 2011-04-07 12:39:56 --> Router Class Initialized
DEBUG - 2011-04-07 12:39:56 --> Output Class Initialized
DEBUG - 2011-04-07 12:39:56 --> Input Class Initialized
DEBUG - 2011-04-07 12:39:56 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-07 12:39:56 --> Language Class Initialized
DEBUG - 2011-04-07 12:39:56 --> Loader Class Initialized
DEBUG - 2011-04-07 12:39:56 --> Controller Class Initialized
ERROR - 2011-04-07 12:39:56 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-04-07 12:39:56 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-04-07 12:39:56 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-04-07 12:39:56 --> Model Class Initialized
DEBUG - 2011-04-07 12:39:56 --> Model Class Initialized
DEBUG - 2011-04-07 12:39:56 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-07 12:39:56 --> Database Driver Class Initialized
DEBUG - 2011-04-07 12:39:56 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-04-07 12:39:56 --> Helper loaded: url_helper
DEBUG - 2011-04-07 12:39:56 --> File loaded: application/views/common/header.php
DEBUG - 2011-04-07 12:39:56 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-04-07 12:39:56 --> File loaded: application/views/common/footer.php
DEBUG - 2011-04-07 12:39:56 --> File loaded: application/views/layout/main.php
DEBUG - 2011-04-07 12:39:56 --> Final output sent to browser
DEBUG - 2011-04-07 12:39:56 --> Total execution time: 0.1577
DEBUG - 2011-04-07 12:39:57 --> Config Class Initialized
DEBUG - 2011-04-07 12:39:57 --> Hooks Class Initialized
DEBUG - 2011-04-07 12:39:57 --> Utf8 Class Initialized
DEBUG - 2011-04-07 12:39:57 --> UTF-8 Support Enabled
DEBUG - 2011-04-07 12:39:57 --> URI Class Initialized
DEBUG - 2011-04-07 12:39:57 --> Router Class Initialized
DEBUG - 2011-04-07 12:39:57 --> Output Class Initialized
DEBUG - 2011-04-07 12:39:57 --> Input Class Initialized
DEBUG - 2011-04-07 12:39:57 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-07 12:39:57 --> Language Class Initialized
DEBUG - 2011-04-07 12:39:57 --> Loader Class Initialized
DEBUG - 2011-04-07 12:39:57 --> Controller Class Initialized
DEBUG - 2011-04-07 12:39:57 --> Model Class Initialized
DEBUG - 2011-04-07 12:39:57 --> Model Class Initialized
DEBUG - 2011-04-07 12:39:57 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-07 12:39:57 --> Database Driver Class Initialized
DEBUG - 2011-04-07 12:39:59 --> Final output sent to browser
DEBUG - 2011-04-07 12:39:59 --> Total execution time: 1.6485
DEBUG - 2011-04-07 12:40:00 --> Config Class Initialized
DEBUG - 2011-04-07 12:40:00 --> Hooks Class Initialized
DEBUG - 2011-04-07 12:40:00 --> Utf8 Class Initialized
DEBUG - 2011-04-07 12:40:00 --> UTF-8 Support Enabled
DEBUG - 2011-04-07 12:40:00 --> URI Class Initialized
DEBUG - 2011-04-07 12:40:00 --> Router Class Initialized
ERROR - 2011-04-07 12:40:00 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-04-07 12:40:05 --> Config Class Initialized
DEBUG - 2011-04-07 12:40:05 --> Hooks Class Initialized
DEBUG - 2011-04-07 12:40:05 --> Utf8 Class Initialized
DEBUG - 2011-04-07 12:40:05 --> UTF-8 Support Enabled
DEBUG - 2011-04-07 12:40:05 --> URI Class Initialized
DEBUG - 2011-04-07 12:40:05 --> Router Class Initialized
DEBUG - 2011-04-07 12:40:05 --> Output Class Initialized
DEBUG - 2011-04-07 12:40:05 --> Input Class Initialized
DEBUG - 2011-04-07 12:40:05 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-07 12:40:05 --> Language Class Initialized
DEBUG - 2011-04-07 12:40:05 --> Loader Class Initialized
DEBUG - 2011-04-07 12:40:05 --> Controller Class Initialized
ERROR - 2011-04-07 12:40:05 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-04-07 12:40:05 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-04-07 12:40:05 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-04-07 12:40:05 --> Model Class Initialized
DEBUG - 2011-04-07 12:40:05 --> Model Class Initialized
DEBUG - 2011-04-07 12:40:05 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-07 12:40:05 --> Database Driver Class Initialized
DEBUG - 2011-04-07 12:40:05 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-04-07 12:40:05 --> Helper loaded: url_helper
DEBUG - 2011-04-07 12:40:05 --> File loaded: application/views/common/header.php
DEBUG - 2011-04-07 12:40:05 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-04-07 12:40:05 --> File loaded: application/views/common/footer.php
DEBUG - 2011-04-07 12:40:05 --> File loaded: application/views/layout/main.php
DEBUG - 2011-04-07 12:40:05 --> Final output sent to browser
DEBUG - 2011-04-07 12:40:05 --> Total execution time: 0.0626
DEBUG - 2011-04-07 12:40:06 --> Config Class Initialized
DEBUG - 2011-04-07 12:40:06 --> Hooks Class Initialized
DEBUG - 2011-04-07 12:40:06 --> Utf8 Class Initialized
DEBUG - 2011-04-07 12:40:06 --> UTF-8 Support Enabled
DEBUG - 2011-04-07 12:40:06 --> URI Class Initialized
DEBUG - 2011-04-07 12:40:06 --> Router Class Initialized
DEBUG - 2011-04-07 12:40:06 --> Output Class Initialized
DEBUG - 2011-04-07 12:40:06 --> Input Class Initialized
DEBUG - 2011-04-07 12:40:06 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-07 12:40:06 --> Language Class Initialized
DEBUG - 2011-04-07 12:40:06 --> Loader Class Initialized
DEBUG - 2011-04-07 12:40:06 --> Controller Class Initialized
DEBUG - 2011-04-07 12:40:06 --> Model Class Initialized
DEBUG - 2011-04-07 12:40:06 --> Model Class Initialized
DEBUG - 2011-04-07 12:40:06 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-07 12:40:06 --> Database Driver Class Initialized
DEBUG - 2011-04-07 12:40:07 --> Final output sent to browser
DEBUG - 2011-04-07 12:40:07 --> Total execution time: 0.7871
DEBUG - 2011-04-07 12:40:07 --> Config Class Initialized
DEBUG - 2011-04-07 12:40:07 --> Hooks Class Initialized
DEBUG - 2011-04-07 12:40:07 --> Utf8 Class Initialized
DEBUG - 2011-04-07 12:40:07 --> UTF-8 Support Enabled
DEBUG - 2011-04-07 12:40:07 --> URI Class Initialized
DEBUG - 2011-04-07 12:40:07 --> Router Class Initialized
ERROR - 2011-04-07 12:40:07 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-04-07 12:40:13 --> Config Class Initialized
DEBUG - 2011-04-07 12:40:13 --> Hooks Class Initialized
DEBUG - 2011-04-07 12:40:13 --> Utf8 Class Initialized
DEBUG - 2011-04-07 12:40:13 --> UTF-8 Support Enabled
DEBUG - 2011-04-07 12:40:13 --> URI Class Initialized
DEBUG - 2011-04-07 12:40:13 --> Router Class Initialized
DEBUG - 2011-04-07 12:40:13 --> Output Class Initialized
DEBUG - 2011-04-07 12:40:13 --> Input Class Initialized
DEBUG - 2011-04-07 12:40:13 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-07 12:40:13 --> Language Class Initialized
DEBUG - 2011-04-07 12:40:13 --> Loader Class Initialized
DEBUG - 2011-04-07 12:40:13 --> Controller Class Initialized
ERROR - 2011-04-07 12:40:13 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-04-07 12:40:13 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-04-07 12:40:13 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-04-07 12:40:13 --> Model Class Initialized
DEBUG - 2011-04-07 12:40:13 --> Model Class Initialized
DEBUG - 2011-04-07 12:40:13 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-07 12:40:13 --> Database Driver Class Initialized
DEBUG - 2011-04-07 12:40:13 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-04-07 12:40:13 --> Helper loaded: url_helper
DEBUG - 2011-04-07 12:40:13 --> File loaded: application/views/common/header.php
DEBUG - 2011-04-07 12:40:13 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-04-07 12:40:13 --> File loaded: application/views/common/footer.php
DEBUG - 2011-04-07 12:40:13 --> File loaded: application/views/layout/main.php
DEBUG - 2011-04-07 12:40:13 --> Final output sent to browser
DEBUG - 2011-04-07 12:40:13 --> Total execution time: 0.4887
DEBUG - 2011-04-07 12:40:14 --> Config Class Initialized
DEBUG - 2011-04-07 12:40:14 --> Hooks Class Initialized
DEBUG - 2011-04-07 12:40:14 --> Utf8 Class Initialized
DEBUG - 2011-04-07 12:40:14 --> UTF-8 Support Enabled
DEBUG - 2011-04-07 12:40:14 --> URI Class Initialized
DEBUG - 2011-04-07 12:40:14 --> Router Class Initialized
DEBUG - 2011-04-07 12:40:14 --> Output Class Initialized
DEBUG - 2011-04-07 12:40:14 --> Input Class Initialized
DEBUG - 2011-04-07 12:40:14 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-07 12:40:14 --> Language Class Initialized
DEBUG - 2011-04-07 12:40:14 --> Loader Class Initialized
DEBUG - 2011-04-07 12:40:14 --> Controller Class Initialized
DEBUG - 2011-04-07 12:40:14 --> Model Class Initialized
DEBUG - 2011-04-07 12:40:14 --> Model Class Initialized
DEBUG - 2011-04-07 12:40:14 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-07 12:40:14 --> Database Driver Class Initialized
DEBUG - 2011-04-07 12:40:14 --> Final output sent to browser
DEBUG - 2011-04-07 12:40:14 --> Total execution time: 0.6467
DEBUG - 2011-04-07 12:40:15 --> Config Class Initialized
DEBUG - 2011-04-07 12:40:15 --> Hooks Class Initialized
DEBUG - 2011-04-07 12:40:15 --> Utf8 Class Initialized
DEBUG - 2011-04-07 12:40:15 --> UTF-8 Support Enabled
DEBUG - 2011-04-07 12:40:15 --> URI Class Initialized
DEBUG - 2011-04-07 12:40:15 --> Router Class Initialized
ERROR - 2011-04-07 12:40:15 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-04-07 12:40:16 --> Config Class Initialized
DEBUG - 2011-04-07 12:40:16 --> Hooks Class Initialized
DEBUG - 2011-04-07 12:40:16 --> Utf8 Class Initialized
DEBUG - 2011-04-07 12:40:16 --> UTF-8 Support Enabled
DEBUG - 2011-04-07 12:40:16 --> URI Class Initialized
DEBUG - 2011-04-07 12:40:16 --> Router Class Initialized
DEBUG - 2011-04-07 12:40:16 --> Output Class Initialized
DEBUG - 2011-04-07 12:40:16 --> Input Class Initialized
DEBUG - 2011-04-07 12:40:16 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-07 12:40:16 --> Language Class Initialized
DEBUG - 2011-04-07 12:40:16 --> Loader Class Initialized
DEBUG - 2011-04-07 12:40:16 --> Controller Class Initialized
ERROR - 2011-04-07 12:40:16 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-04-07 12:40:16 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-04-07 12:40:16 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-04-07 12:40:16 --> Model Class Initialized
DEBUG - 2011-04-07 12:40:16 --> Model Class Initialized
DEBUG - 2011-04-07 12:40:17 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-07 12:40:17 --> Database Driver Class Initialized
DEBUG - 2011-04-07 12:40:17 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-04-07 12:40:17 --> Helper loaded: url_helper
DEBUG - 2011-04-07 12:40:17 --> File loaded: application/views/common/header.php
DEBUG - 2011-04-07 12:40:17 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-04-07 12:40:17 --> File loaded: application/views/common/footer.php
DEBUG - 2011-04-07 12:40:17 --> File loaded: application/views/layout/main.php
DEBUG - 2011-04-07 12:40:17 --> Final output sent to browser
DEBUG - 2011-04-07 12:40:17 --> Total execution time: 0.0303
DEBUG - 2011-04-07 12:40:17 --> Config Class Initialized
DEBUG - 2011-04-07 12:40:17 --> Hooks Class Initialized
DEBUG - 2011-04-07 12:40:17 --> Utf8 Class Initialized
DEBUG - 2011-04-07 12:40:17 --> UTF-8 Support Enabled
DEBUG - 2011-04-07 12:40:17 --> URI Class Initialized
DEBUG - 2011-04-07 12:40:17 --> Router Class Initialized
DEBUG - 2011-04-07 12:40:17 --> Output Class Initialized
DEBUG - 2011-04-07 12:40:17 --> Input Class Initialized
DEBUG - 2011-04-07 12:40:17 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-07 12:40:17 --> Language Class Initialized
DEBUG - 2011-04-07 12:40:17 --> Loader Class Initialized
DEBUG - 2011-04-07 12:40:17 --> Controller Class Initialized
DEBUG - 2011-04-07 12:40:17 --> Model Class Initialized
DEBUG - 2011-04-07 12:40:17 --> Model Class Initialized
DEBUG - 2011-04-07 12:40:17 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-07 12:40:17 --> Database Driver Class Initialized
DEBUG - 2011-04-07 12:40:18 --> Final output sent to browser
DEBUG - 2011-04-07 12:40:18 --> Total execution time: 0.7841
DEBUG - 2011-04-07 12:40:20 --> Config Class Initialized
DEBUG - 2011-04-07 12:40:20 --> Hooks Class Initialized
DEBUG - 2011-04-07 12:40:20 --> Utf8 Class Initialized
DEBUG - 2011-04-07 12:40:20 --> UTF-8 Support Enabled
DEBUG - 2011-04-07 12:40:20 --> URI Class Initialized
DEBUG - 2011-04-07 12:40:20 --> Router Class Initialized
ERROR - 2011-04-07 12:40:20 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-04-07 13:38:02 --> Config Class Initialized
DEBUG - 2011-04-07 13:38:02 --> Hooks Class Initialized
DEBUG - 2011-04-07 13:38:02 --> Utf8 Class Initialized
DEBUG - 2011-04-07 13:38:02 --> UTF-8 Support Enabled
DEBUG - 2011-04-07 13:38:02 --> URI Class Initialized
DEBUG - 2011-04-07 13:38:02 --> Router Class Initialized
DEBUG - 2011-04-07 13:38:02 --> Output Class Initialized
DEBUG - 2011-04-07 13:38:02 --> Input Class Initialized
DEBUG - 2011-04-07 13:38:02 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-07 13:38:02 --> Language Class Initialized
DEBUG - 2011-04-07 13:38:02 --> Loader Class Initialized
DEBUG - 2011-04-07 13:38:02 --> Controller Class Initialized
ERROR - 2011-04-07 13:38:02 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-04-07 13:38:02 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-04-07 13:38:02 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-04-07 13:38:02 --> Model Class Initialized
DEBUG - 2011-04-07 13:38:02 --> Model Class Initialized
DEBUG - 2011-04-07 13:38:02 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-07 13:38:02 --> Database Driver Class Initialized
DEBUG - 2011-04-07 13:38:02 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-04-07 13:38:02 --> Helper loaded: url_helper
DEBUG - 2011-04-07 13:38:02 --> File loaded: application/views/common/header.php
DEBUG - 2011-04-07 13:38:02 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-04-07 13:38:02 --> File loaded: application/views/common/footer.php
DEBUG - 2011-04-07 13:38:02 --> File loaded: application/views/layout/main.php
DEBUG - 2011-04-07 13:38:02 --> Final output sent to browser
DEBUG - 2011-04-07 13:38:02 --> Total execution time: 0.3507
DEBUG - 2011-04-07 13:41:46 --> Config Class Initialized
DEBUG - 2011-04-07 13:41:46 --> Hooks Class Initialized
DEBUG - 2011-04-07 13:41:46 --> Utf8 Class Initialized
DEBUG - 2011-04-07 13:41:46 --> UTF-8 Support Enabled
DEBUG - 2011-04-07 13:41:46 --> URI Class Initialized
DEBUG - 2011-04-07 13:41:46 --> Router Class Initialized
ERROR - 2011-04-07 13:41:46 --> 404 Page Not Found --> robots.txt
DEBUG - 2011-04-07 13:41:47 --> Config Class Initialized
DEBUG - 2011-04-07 13:41:47 --> Hooks Class Initialized
DEBUG - 2011-04-07 13:41:47 --> Utf8 Class Initialized
DEBUG - 2011-04-07 13:41:47 --> UTF-8 Support Enabled
DEBUG - 2011-04-07 13:41:47 --> URI Class Initialized
DEBUG - 2011-04-07 13:41:47 --> Router Class Initialized
DEBUG - 2011-04-07 13:41:47 --> No URI present. Default controller set.
DEBUG - 2011-04-07 13:41:47 --> Output Class Initialized
DEBUG - 2011-04-07 13:41:47 --> Input Class Initialized
DEBUG - 2011-04-07 13:41:47 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-07 13:41:47 --> Language Class Initialized
DEBUG - 2011-04-07 13:41:47 --> Loader Class Initialized
DEBUG - 2011-04-07 13:41:47 --> Controller Class Initialized
DEBUG - 2011-04-07 13:41:47 --> File loaded: application/views/splash/main.php
DEBUG - 2011-04-07 13:41:47 --> Helper loaded: url_helper
DEBUG - 2011-04-07 13:41:47 --> File loaded: application/views/common/header.php
DEBUG - 2011-04-07 13:41:47 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-04-07 13:41:47 --> File loaded: application/views/common/footer.php
DEBUG - 2011-04-07 13:41:47 --> File loaded: application/views/layout/main.php
DEBUG - 2011-04-07 13:41:47 --> Final output sent to browser
DEBUG - 2011-04-07 13:41:47 --> Total execution time: 0.2557
DEBUG - 2011-04-07 13:53:16 --> Config Class Initialized
DEBUG - 2011-04-07 13:53:16 --> Hooks Class Initialized
DEBUG - 2011-04-07 13:53:16 --> Utf8 Class Initialized
DEBUG - 2011-04-07 13:53:16 --> UTF-8 Support Enabled
DEBUG - 2011-04-07 13:53:16 --> URI Class Initialized
DEBUG - 2011-04-07 13:53:16 --> Router Class Initialized
DEBUG - 2011-04-07 13:53:16 --> Output Class Initialized
DEBUG - 2011-04-07 13:53:16 --> Input Class Initialized
DEBUG - 2011-04-07 13:53:16 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-07 13:53:16 --> Language Class Initialized
DEBUG - 2011-04-07 13:53:16 --> Loader Class Initialized
DEBUG - 2011-04-07 13:53:16 --> Controller Class Initialized
ERROR - 2011-04-07 13:53:16 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-04-07 13:53:16 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-04-07 13:53:16 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-04-07 13:53:16 --> Model Class Initialized
DEBUG - 2011-04-07 13:53:16 --> Model Class Initialized
DEBUG - 2011-04-07 13:53:16 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-07 13:53:16 --> Database Driver Class Initialized
DEBUG - 2011-04-07 13:53:16 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-04-07 13:53:16 --> Helper loaded: url_helper
DEBUG - 2011-04-07 13:53:16 --> File loaded: application/views/common/header.php
DEBUG - 2011-04-07 13:53:16 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-04-07 13:53:16 --> File loaded: application/views/common/footer.php
DEBUG - 2011-04-07 13:53:16 --> File loaded: application/views/layout/main.php
DEBUG - 2011-04-07 13:53:16 --> Final output sent to browser
DEBUG - 2011-04-07 13:53:16 --> Total execution time: 0.3584
DEBUG - 2011-04-07 13:53:17 --> Config Class Initialized
DEBUG - 2011-04-07 13:53:17 --> Hooks Class Initialized
DEBUG - 2011-04-07 13:53:17 --> Utf8 Class Initialized
DEBUG - 2011-04-07 13:53:17 --> UTF-8 Support Enabled
DEBUG - 2011-04-07 13:53:17 --> URI Class Initialized
DEBUG - 2011-04-07 13:53:17 --> Router Class Initialized
DEBUG - 2011-04-07 13:53:17 --> Output Class Initialized
DEBUG - 2011-04-07 13:53:17 --> Input Class Initialized
DEBUG - 2011-04-07 13:53:17 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-07 13:53:17 --> Language Class Initialized
DEBUG - 2011-04-07 13:53:17 --> Loader Class Initialized
DEBUG - 2011-04-07 13:53:17 --> Controller Class Initialized
DEBUG - 2011-04-07 13:53:17 --> Model Class Initialized
DEBUG - 2011-04-07 13:53:17 --> Model Class Initialized
DEBUG - 2011-04-07 13:53:17 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-07 13:53:17 --> Database Driver Class Initialized
DEBUG - 2011-04-07 13:53:17 --> Final output sent to browser
DEBUG - 2011-04-07 13:53:17 --> Total execution time: 0.7459
DEBUG - 2011-04-07 13:53:18 --> Config Class Initialized
DEBUG - 2011-04-07 13:53:18 --> Hooks Class Initialized
DEBUG - 2011-04-07 13:53:18 --> Utf8 Class Initialized
DEBUG - 2011-04-07 13:53:18 --> UTF-8 Support Enabled
DEBUG - 2011-04-07 13:53:18 --> URI Class Initialized
DEBUG - 2011-04-07 13:53:18 --> Router Class Initialized
ERROR - 2011-04-07 13:53:18 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-04-07 13:54:16 --> Config Class Initialized
DEBUG - 2011-04-07 13:54:16 --> Hooks Class Initialized
DEBUG - 2011-04-07 13:54:16 --> Utf8 Class Initialized
DEBUG - 2011-04-07 13:54:16 --> UTF-8 Support Enabled
DEBUG - 2011-04-07 13:54:16 --> URI Class Initialized
DEBUG - 2011-04-07 13:54:16 --> Router Class Initialized
DEBUG - 2011-04-07 13:54:16 --> Output Class Initialized
DEBUG - 2011-04-07 13:54:16 --> Input Class Initialized
DEBUG - 2011-04-07 13:54:16 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-07 13:54:16 --> Language Class Initialized
DEBUG - 2011-04-07 13:54:16 --> Loader Class Initialized
DEBUG - 2011-04-07 13:54:16 --> Controller Class Initialized
ERROR - 2011-04-07 13:54:16 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-04-07 13:54:16 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-04-07 13:54:16 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-04-07 13:54:16 --> Model Class Initialized
DEBUG - 2011-04-07 13:54:16 --> Model Class Initialized
DEBUG - 2011-04-07 13:54:16 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-07 13:54:16 --> Database Driver Class Initialized
DEBUG - 2011-04-07 13:54:16 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-04-07 13:54:16 --> Helper loaded: url_helper
DEBUG - 2011-04-07 13:54:16 --> File loaded: application/views/common/header.php
DEBUG - 2011-04-07 13:54:16 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-04-07 13:54:16 --> File loaded: application/views/common/footer.php
DEBUG - 2011-04-07 13:54:16 --> File loaded: application/views/layout/main.php
DEBUG - 2011-04-07 13:54:16 --> Final output sent to browser
DEBUG - 2011-04-07 13:54:16 --> Total execution time: 0.3615
DEBUG - 2011-04-07 13:54:17 --> Config Class Initialized
DEBUG - 2011-04-07 13:54:17 --> Hooks Class Initialized
DEBUG - 2011-04-07 13:54:17 --> Utf8 Class Initialized
DEBUG - 2011-04-07 13:54:17 --> UTF-8 Support Enabled
DEBUG - 2011-04-07 13:54:17 --> URI Class Initialized
DEBUG - 2011-04-07 13:54:17 --> Router Class Initialized
DEBUG - 2011-04-07 13:54:17 --> Output Class Initialized
DEBUG - 2011-04-07 13:54:17 --> Input Class Initialized
DEBUG - 2011-04-07 13:54:17 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-07 13:54:17 --> Language Class Initialized
DEBUG - 2011-04-07 13:54:17 --> Loader Class Initialized
DEBUG - 2011-04-07 13:54:17 --> Controller Class Initialized
DEBUG - 2011-04-07 13:54:17 --> Model Class Initialized
DEBUG - 2011-04-07 13:54:17 --> Model Class Initialized
DEBUG - 2011-04-07 13:54:17 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-07 13:54:17 --> Database Driver Class Initialized
DEBUG - 2011-04-07 13:54:19 --> Final output sent to browser
DEBUG - 2011-04-07 13:54:19 --> Total execution time: 1.9211
DEBUG - 2011-04-07 13:54:20 --> Config Class Initialized
DEBUG - 2011-04-07 13:54:20 --> Hooks Class Initialized
DEBUG - 2011-04-07 13:54:20 --> Utf8 Class Initialized
DEBUG - 2011-04-07 13:54:20 --> UTF-8 Support Enabled
DEBUG - 2011-04-07 13:54:20 --> URI Class Initialized
DEBUG - 2011-04-07 13:54:20 --> Router Class Initialized
ERROR - 2011-04-07 13:54:20 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-04-07 13:54:32 --> Config Class Initialized
DEBUG - 2011-04-07 13:54:32 --> Hooks Class Initialized
DEBUG - 2011-04-07 13:54:32 --> Utf8 Class Initialized
DEBUG - 2011-04-07 13:54:32 --> UTF-8 Support Enabled
DEBUG - 2011-04-07 13:54:32 --> URI Class Initialized
DEBUG - 2011-04-07 13:54:32 --> Router Class Initialized
DEBUG - 2011-04-07 13:54:32 --> Output Class Initialized
DEBUG - 2011-04-07 13:54:32 --> Input Class Initialized
DEBUG - 2011-04-07 13:54:32 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-07 13:54:32 --> Language Class Initialized
DEBUG - 2011-04-07 13:54:32 --> Loader Class Initialized
DEBUG - 2011-04-07 13:54:32 --> Controller Class Initialized
ERROR - 2011-04-07 13:54:32 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-04-07 13:54:32 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-04-07 13:54:32 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-04-07 13:54:32 --> Model Class Initialized
DEBUG - 2011-04-07 13:54:32 --> Model Class Initialized
DEBUG - 2011-04-07 13:54:32 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-07 13:54:32 --> Database Driver Class Initialized
DEBUG - 2011-04-07 13:54:32 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-04-07 13:54:32 --> Helper loaded: url_helper
DEBUG - 2011-04-07 13:54:32 --> File loaded: application/views/common/header.php
DEBUG - 2011-04-07 13:54:32 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-04-07 13:54:32 --> File loaded: application/views/common/footer.php
DEBUG - 2011-04-07 13:54:32 --> File loaded: application/views/layout/main.php
DEBUG - 2011-04-07 13:54:32 --> Final output sent to browser
DEBUG - 2011-04-07 13:54:32 --> Total execution time: 0.0282
DEBUG - 2011-04-07 13:54:32 --> Config Class Initialized
DEBUG - 2011-04-07 13:54:32 --> Hooks Class Initialized
DEBUG - 2011-04-07 13:54:32 --> Utf8 Class Initialized
DEBUG - 2011-04-07 13:54:32 --> UTF-8 Support Enabled
DEBUG - 2011-04-07 13:54:32 --> URI Class Initialized
DEBUG - 2011-04-07 13:54:32 --> Router Class Initialized
DEBUG - 2011-04-07 13:54:32 --> Output Class Initialized
DEBUG - 2011-04-07 13:54:32 --> Input Class Initialized
DEBUG - 2011-04-07 13:54:32 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-07 13:54:32 --> Language Class Initialized
DEBUG - 2011-04-07 13:54:32 --> Loader Class Initialized
DEBUG - 2011-04-07 13:54:32 --> Controller Class Initialized
DEBUG - 2011-04-07 13:54:32 --> Model Class Initialized
DEBUG - 2011-04-07 13:54:32 --> Model Class Initialized
DEBUG - 2011-04-07 13:54:32 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-07 13:54:32 --> Database Driver Class Initialized
DEBUG - 2011-04-07 13:54:41 --> Final output sent to browser
DEBUG - 2011-04-07 13:54:41 --> Total execution time: 8.5140
DEBUG - 2011-04-07 13:54:42 --> Config Class Initialized
DEBUG - 2011-04-07 13:54:42 --> Hooks Class Initialized
DEBUG - 2011-04-07 13:54:42 --> Utf8 Class Initialized
DEBUG - 2011-04-07 13:54:42 --> UTF-8 Support Enabled
DEBUG - 2011-04-07 13:54:42 --> URI Class Initialized
DEBUG - 2011-04-07 13:54:42 --> Router Class Initialized
ERROR - 2011-04-07 13:54:42 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-04-07 13:55:10 --> Config Class Initialized
DEBUG - 2011-04-07 13:55:10 --> Hooks Class Initialized
DEBUG - 2011-04-07 13:55:10 --> Utf8 Class Initialized
DEBUG - 2011-04-07 13:55:10 --> UTF-8 Support Enabled
DEBUG - 2011-04-07 13:55:10 --> URI Class Initialized
DEBUG - 2011-04-07 13:55:10 --> Router Class Initialized
DEBUG - 2011-04-07 13:55:10 --> Output Class Initialized
DEBUG - 2011-04-07 13:55:10 --> Input Class Initialized
DEBUG - 2011-04-07 13:55:10 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-07 13:55:10 --> Language Class Initialized
DEBUG - 2011-04-07 13:55:10 --> Loader Class Initialized
DEBUG - 2011-04-07 13:55:10 --> Controller Class Initialized
ERROR - 2011-04-07 13:55:10 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-04-07 13:55:10 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-04-07 13:55:10 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-04-07 13:55:10 --> Model Class Initialized
DEBUG - 2011-04-07 13:55:10 --> Model Class Initialized
DEBUG - 2011-04-07 13:55:10 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-07 13:55:10 --> Database Driver Class Initialized
DEBUG - 2011-04-07 13:55:10 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-04-07 13:55:10 --> Helper loaded: url_helper
DEBUG - 2011-04-07 13:55:10 --> File loaded: application/views/common/header.php
DEBUG - 2011-04-07 13:55:10 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-04-07 13:55:10 --> File loaded: application/views/common/footer.php
DEBUG - 2011-04-07 13:55:10 --> File loaded: application/views/layout/main.php
DEBUG - 2011-04-07 13:55:10 --> Final output sent to browser
DEBUG - 2011-04-07 13:55:10 --> Total execution time: 0.1377
DEBUG - 2011-04-07 13:55:11 --> Config Class Initialized
DEBUG - 2011-04-07 13:55:11 --> Hooks Class Initialized
DEBUG - 2011-04-07 13:55:11 --> Utf8 Class Initialized
DEBUG - 2011-04-07 13:55:11 --> UTF-8 Support Enabled
DEBUG - 2011-04-07 13:55:11 --> URI Class Initialized
DEBUG - 2011-04-07 13:55:11 --> Router Class Initialized
DEBUG - 2011-04-07 13:55:11 --> Output Class Initialized
DEBUG - 2011-04-07 13:55:11 --> Input Class Initialized
DEBUG - 2011-04-07 13:55:11 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-07 13:55:11 --> Language Class Initialized
DEBUG - 2011-04-07 13:55:11 --> Loader Class Initialized
DEBUG - 2011-04-07 13:55:11 --> Controller Class Initialized
DEBUG - 2011-04-07 13:55:11 --> Model Class Initialized
DEBUG - 2011-04-07 13:55:11 --> Model Class Initialized
DEBUG - 2011-04-07 13:55:11 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-07 13:55:11 --> Database Driver Class Initialized
DEBUG - 2011-04-07 13:55:12 --> Final output sent to browser
DEBUG - 2011-04-07 13:55:12 --> Total execution time: 1.1169
DEBUG - 2011-04-07 13:55:13 --> Config Class Initialized
DEBUG - 2011-04-07 13:55:13 --> Hooks Class Initialized
DEBUG - 2011-04-07 13:55:13 --> Utf8 Class Initialized
DEBUG - 2011-04-07 13:55:13 --> UTF-8 Support Enabled
DEBUG - 2011-04-07 13:55:13 --> URI Class Initialized
DEBUG - 2011-04-07 13:55:13 --> Router Class Initialized
ERROR - 2011-04-07 13:55:13 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-04-07 15:37:22 --> Config Class Initialized
DEBUG - 2011-04-07 15:37:22 --> Hooks Class Initialized
DEBUG - 2011-04-07 15:37:22 --> Utf8 Class Initialized
DEBUG - 2011-04-07 15:37:22 --> UTF-8 Support Enabled
DEBUG - 2011-04-07 15:37:22 --> URI Class Initialized
DEBUG - 2011-04-07 15:37:22 --> Router Class Initialized
DEBUG - 2011-04-07 15:37:22 --> No URI present. Default controller set.
DEBUG - 2011-04-07 15:37:22 --> Output Class Initialized
DEBUG - 2011-04-07 15:37:22 --> Input Class Initialized
DEBUG - 2011-04-07 15:37:22 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-07 15:37:22 --> Language Class Initialized
DEBUG - 2011-04-07 15:37:22 --> Loader Class Initialized
DEBUG - 2011-04-07 15:37:22 --> Controller Class Initialized
DEBUG - 2011-04-07 15:37:22 --> File loaded: application/views/splash/main.php
DEBUG - 2011-04-07 15:37:23 --> Helper loaded: url_helper
DEBUG - 2011-04-07 15:37:23 --> File loaded: application/views/common/header.php
DEBUG - 2011-04-07 15:37:23 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-04-07 15:37:23 --> File loaded: application/views/common/footer.php
DEBUG - 2011-04-07 15:37:23 --> File loaded: application/views/layout/main.php
DEBUG - 2011-04-07 15:37:23 --> Final output sent to browser
DEBUG - 2011-04-07 15:37:23 --> Total execution time: 0.2245
DEBUG - 2011-04-07 16:10:39 --> Config Class Initialized
DEBUG - 2011-04-07 16:10:39 --> Hooks Class Initialized
DEBUG - 2011-04-07 16:10:39 --> Utf8 Class Initialized
DEBUG - 2011-04-07 16:10:39 --> UTF-8 Support Enabled
DEBUG - 2011-04-07 16:10:39 --> URI Class Initialized
DEBUG - 2011-04-07 16:10:39 --> Router Class Initialized
DEBUG - 2011-04-07 16:10:39 --> Output Class Initialized
DEBUG - 2011-04-07 16:10:39 --> Input Class Initialized
DEBUG - 2011-04-07 16:10:39 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-07 16:10:39 --> Language Class Initialized
DEBUG - 2011-04-07 16:10:39 --> Loader Class Initialized
DEBUG - 2011-04-07 16:10:39 --> Controller Class Initialized
DEBUG - 2011-04-07 16:10:39 --> Model Class Initialized
DEBUG - 2011-04-07 16:10:39 --> Model Class Initialized
DEBUG - 2011-04-07 16:10:39 --> Model Class Initialized
DEBUG - 2011-04-07 16:10:39 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-07 16:10:39 --> Database Driver Class Initialized
DEBUG - 2011-04-07 16:10:39 --> File loaded: application/views/table/main.php
DEBUG - 2011-04-07 16:10:39 --> Helper loaded: url_helper
DEBUG - 2011-04-07 16:10:39 --> File loaded: application/views/common/header.php
DEBUG - 2011-04-07 16:10:39 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-04-07 16:10:39 --> File loaded: application/views/common/footer.php
DEBUG - 2011-04-07 16:10:39 --> File loaded: application/views/layout/main.php
DEBUG - 2011-04-07 16:10:39 --> Final output sent to browser
DEBUG - 2011-04-07 16:10:39 --> Total execution time: 0.4820
DEBUG - 2011-04-07 16:10:41 --> Config Class Initialized
DEBUG - 2011-04-07 16:10:41 --> Hooks Class Initialized
DEBUG - 2011-04-07 16:10:41 --> Utf8 Class Initialized
DEBUG - 2011-04-07 16:10:41 --> UTF-8 Support Enabled
DEBUG - 2011-04-07 16:10:41 --> URI Class Initialized
DEBUG - 2011-04-07 16:10:41 --> Router Class Initialized
ERROR - 2011-04-07 16:10:42 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-04-07 16:10:44 --> Config Class Initialized
DEBUG - 2011-04-07 16:10:44 --> Hooks Class Initialized
DEBUG - 2011-04-07 16:10:44 --> Utf8 Class Initialized
DEBUG - 2011-04-07 16:10:44 --> UTF-8 Support Enabled
DEBUG - 2011-04-07 16:10:44 --> URI Class Initialized
DEBUG - 2011-04-07 16:10:44 --> Router Class Initialized
ERROR - 2011-04-07 16:10:44 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-04-07 16:10:48 --> Config Class Initialized
DEBUG - 2011-04-07 16:10:48 --> Hooks Class Initialized
DEBUG - 2011-04-07 16:10:48 --> Utf8 Class Initialized
DEBUG - 2011-04-07 16:10:48 --> UTF-8 Support Enabled
DEBUG - 2011-04-07 16:10:48 --> URI Class Initialized
DEBUG - 2011-04-07 16:10:48 --> Router Class Initialized
DEBUG - 2011-04-07 16:10:48 --> Output Class Initialized
DEBUG - 2011-04-07 16:10:48 --> Input Class Initialized
DEBUG - 2011-04-07 16:10:48 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-07 16:10:48 --> Language Class Initialized
DEBUG - 2011-04-07 16:10:48 --> Loader Class Initialized
DEBUG - 2011-04-07 16:10:48 --> Controller Class Initialized
DEBUG - 2011-04-07 16:10:48 --> Model Class Initialized
DEBUG - 2011-04-07 16:10:48 --> Model Class Initialized
DEBUG - 2011-04-07 16:10:48 --> Model Class Initialized
DEBUG - 2011-04-07 16:10:48 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-07 16:10:48 --> Database Driver Class Initialized
DEBUG - 2011-04-07 16:10:48 --> File loaded: application/views/table/main.php
DEBUG - 2011-04-07 16:10:48 --> Helper loaded: url_helper
DEBUG - 2011-04-07 16:10:48 --> File loaded: application/views/common/header.php
DEBUG - 2011-04-07 16:10:48 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-04-07 16:10:48 --> File loaded: application/views/common/footer.php
DEBUG - 2011-04-07 16:10:48 --> File loaded: application/views/layout/main.php
DEBUG - 2011-04-07 16:10:48 --> Final output sent to browser
DEBUG - 2011-04-07 16:10:48 --> Total execution time: 0.0475
DEBUG - 2011-04-07 18:37:02 --> Config Class Initialized
DEBUG - 2011-04-07 18:37:02 --> Hooks Class Initialized
DEBUG - 2011-04-07 18:37:02 --> Utf8 Class Initialized
DEBUG - 2011-04-07 18:37:02 --> UTF-8 Support Enabled
DEBUG - 2011-04-07 18:37:02 --> URI Class Initialized
DEBUG - 2011-04-07 18:37:02 --> Router Class Initialized
DEBUG - 2011-04-07 18:37:02 --> No URI present. Default controller set.
DEBUG - 2011-04-07 18:37:02 --> Output Class Initialized
DEBUG - 2011-04-07 18:37:02 --> Input Class Initialized
DEBUG - 2011-04-07 18:37:02 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-07 18:37:02 --> Language Class Initialized
DEBUG - 2011-04-07 18:37:02 --> Loader Class Initialized
DEBUG - 2011-04-07 18:37:02 --> Controller Class Initialized
DEBUG - 2011-04-07 18:37:02 --> File loaded: application/views/splash/main.php
DEBUG - 2011-04-07 18:37:02 --> Helper loaded: url_helper
DEBUG - 2011-04-07 18:37:02 --> File loaded: application/views/common/header.php
DEBUG - 2011-04-07 18:37:02 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-04-07 18:37:02 --> File loaded: application/views/common/footer.php
DEBUG - 2011-04-07 18:37:02 --> File loaded: application/views/layout/main.php
DEBUG - 2011-04-07 18:37:02 --> Final output sent to browser
DEBUG - 2011-04-07 18:37:02 --> Total execution time: 0.2073
DEBUG - 2011-04-07 18:43:00 --> Config Class Initialized
DEBUG - 2011-04-07 18:43:00 --> Hooks Class Initialized
DEBUG - 2011-04-07 18:43:00 --> Utf8 Class Initialized
DEBUG - 2011-04-07 18:43:00 --> UTF-8 Support Enabled
DEBUG - 2011-04-07 18:43:00 --> URI Class Initialized
DEBUG - 2011-04-07 18:43:00 --> Router Class Initialized
DEBUG - 2011-04-07 18:43:00 --> No URI present. Default controller set.
DEBUG - 2011-04-07 18:43:00 --> Output Class Initialized
DEBUG - 2011-04-07 18:43:00 --> Input Class Initialized
DEBUG - 2011-04-07 18:43:00 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-07 18:43:00 --> Language Class Initialized
DEBUG - 2011-04-07 18:43:00 --> Loader Class Initialized
DEBUG - 2011-04-07 18:43:00 --> Controller Class Initialized
DEBUG - 2011-04-07 18:43:00 --> File loaded: application/views/splash/main.php
DEBUG - 2011-04-07 18:43:00 --> Helper loaded: url_helper
DEBUG - 2011-04-07 18:43:00 --> File loaded: application/views/common/header.php
DEBUG - 2011-04-07 18:43:00 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-04-07 18:43:00 --> File loaded: application/views/common/footer.php
DEBUG - 2011-04-07 18:43:00 --> File loaded: application/views/layout/main.php
DEBUG - 2011-04-07 18:43:00 --> Final output sent to browser
DEBUG - 2011-04-07 18:43:00 --> Total execution time: 0.0183
DEBUG - 2011-04-07 18:43:01 --> Config Class Initialized
DEBUG - 2011-04-07 18:43:01 --> Hooks Class Initialized
DEBUG - 2011-04-07 18:43:01 --> Utf8 Class Initialized
DEBUG - 2011-04-07 18:43:01 --> UTF-8 Support Enabled
DEBUG - 2011-04-07 18:43:01 --> URI Class Initialized
DEBUG - 2011-04-07 18:43:01 --> Router Class Initialized
ERROR - 2011-04-07 18:43:01 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-04-07 18:43:01 --> Config Class Initialized
DEBUG - 2011-04-07 18:43:01 --> Hooks Class Initialized
DEBUG - 2011-04-07 18:43:01 --> Utf8 Class Initialized
DEBUG - 2011-04-07 18:43:01 --> UTF-8 Support Enabled
DEBUG - 2011-04-07 18:43:01 --> URI Class Initialized
DEBUG - 2011-04-07 18:43:01 --> Router Class Initialized
ERROR - 2011-04-07 18:43:01 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-04-07 18:43:01 --> Config Class Initialized
DEBUG - 2011-04-07 18:43:01 --> Hooks Class Initialized
DEBUG - 2011-04-07 18:43:01 --> Utf8 Class Initialized
DEBUG - 2011-04-07 18:43:01 --> UTF-8 Support Enabled
DEBUG - 2011-04-07 18:43:01 --> URI Class Initialized
DEBUG - 2011-04-07 18:43:01 --> Router Class Initialized
ERROR - 2011-04-07 18:43:01 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-04-07 19:26:58 --> Config Class Initialized
DEBUG - 2011-04-07 19:26:58 --> Hooks Class Initialized
DEBUG - 2011-04-07 19:26:58 --> Utf8 Class Initialized
DEBUG - 2011-04-07 19:26:58 --> UTF-8 Support Enabled
DEBUG - 2011-04-07 19:26:58 --> URI Class Initialized
DEBUG - 2011-04-07 19:26:58 --> Router Class Initialized
DEBUG - 2011-04-07 19:26:58 --> No URI present. Default controller set.
DEBUG - 2011-04-07 19:26:58 --> Output Class Initialized
DEBUG - 2011-04-07 19:26:58 --> Input Class Initialized
DEBUG - 2011-04-07 19:26:58 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-07 19:26:58 --> Language Class Initialized
DEBUG - 2011-04-07 19:26:58 --> Loader Class Initialized
DEBUG - 2011-04-07 19:26:58 --> Controller Class Initialized
DEBUG - 2011-04-07 19:26:58 --> File loaded: application/views/splash/main.php
DEBUG - 2011-04-07 19:26:58 --> Helper loaded: url_helper
DEBUG - 2011-04-07 19:26:58 --> File loaded: application/views/common/header.php
DEBUG - 2011-04-07 19:26:58 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-04-07 19:26:58 --> File loaded: application/views/common/footer.php
DEBUG - 2011-04-07 19:26:58 --> File loaded: application/views/layout/main.php
DEBUG - 2011-04-07 19:26:58 --> Final output sent to browser
DEBUG - 2011-04-07 19:26:58 --> Total execution time: 0.0451
DEBUG - 2011-04-07 19:26:59 --> Config Class Initialized
DEBUG - 2011-04-07 19:26:59 --> Hooks Class Initialized
DEBUG - 2011-04-07 19:26:59 --> Utf8 Class Initialized
DEBUG - 2011-04-07 19:26:59 --> UTF-8 Support Enabled
DEBUG - 2011-04-07 19:26:59 --> URI Class Initialized
DEBUG - 2011-04-07 19:26:59 --> Router Class Initialized
ERROR - 2011-04-07 19:26:59 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-04-07 19:26:59 --> Config Class Initialized
DEBUG - 2011-04-07 19:26:59 --> Hooks Class Initialized
DEBUG - 2011-04-07 19:26:59 --> Utf8 Class Initialized
DEBUG - 2011-04-07 19:26:59 --> UTF-8 Support Enabled
DEBUG - 2011-04-07 19:26:59 --> URI Class Initialized
DEBUG - 2011-04-07 19:26:59 --> Router Class Initialized
ERROR - 2011-04-07 19:26:59 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-04-07 19:27:05 --> Config Class Initialized
DEBUG - 2011-04-07 19:27:05 --> Hooks Class Initialized
DEBUG - 2011-04-07 19:27:05 --> Utf8 Class Initialized
DEBUG - 2011-04-07 19:27:05 --> UTF-8 Support Enabled
DEBUG - 2011-04-07 19:27:05 --> URI Class Initialized
DEBUG - 2011-04-07 19:27:05 --> Router Class Initialized
DEBUG - 2011-04-07 19:27:05 --> Output Class Initialized
DEBUG - 2011-04-07 19:27:05 --> Input Class Initialized
DEBUG - 2011-04-07 19:27:05 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-07 19:27:05 --> Language Class Initialized
DEBUG - 2011-04-07 19:27:05 --> Loader Class Initialized
DEBUG - 2011-04-07 19:27:05 --> Controller Class Initialized
DEBUG - 2011-04-07 19:27:05 --> Model Class Initialized
DEBUG - 2011-04-07 19:27:05 --> Model Class Initialized
DEBUG - 2011-04-07 19:27:05 --> Model Class Initialized
DEBUG - 2011-04-07 19:27:05 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-07 19:27:05 --> Database Driver Class Initialized
DEBUG - 2011-04-07 19:27:05 --> File loaded: application/views/table/main.php
DEBUG - 2011-04-07 19:27:05 --> Helper loaded: url_helper
DEBUG - 2011-04-07 19:27:05 --> File loaded: application/views/common/header.php
DEBUG - 2011-04-07 19:27:05 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-04-07 19:27:06 --> File loaded: application/views/common/footer.php
DEBUG - 2011-04-07 19:27:06 --> File loaded: application/views/layout/main.php
DEBUG - 2011-04-07 19:27:06 --> Final output sent to browser
DEBUG - 2011-04-07 19:27:06 --> Total execution time: 0.3508
DEBUG - 2011-04-07 19:27:07 --> Config Class Initialized
DEBUG - 2011-04-07 19:27:07 --> Hooks Class Initialized
DEBUG - 2011-04-07 19:27:07 --> Utf8 Class Initialized
DEBUG - 2011-04-07 19:27:07 --> UTF-8 Support Enabled
DEBUG - 2011-04-07 19:27:07 --> URI Class Initialized
DEBUG - 2011-04-07 19:27:07 --> Router Class Initialized
ERROR - 2011-04-07 19:27:07 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-04-07 19:27:31 --> Config Class Initialized
DEBUG - 2011-04-07 19:27:31 --> Hooks Class Initialized
DEBUG - 2011-04-07 19:27:31 --> Utf8 Class Initialized
DEBUG - 2011-04-07 19:27:31 --> UTF-8 Support Enabled
DEBUG - 2011-04-07 19:27:31 --> URI Class Initialized
DEBUG - 2011-04-07 19:27:31 --> Router Class Initialized
DEBUG - 2011-04-07 19:27:31 --> Output Class Initialized
DEBUG - 2011-04-07 19:27:31 --> Input Class Initialized
DEBUG - 2011-04-07 19:27:31 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-07 19:27:31 --> Language Class Initialized
DEBUG - 2011-04-07 19:27:31 --> Loader Class Initialized
DEBUG - 2011-04-07 19:27:31 --> Controller Class Initialized
DEBUG - 2011-04-07 19:27:31 --> Model Class Initialized
DEBUG - 2011-04-07 19:27:31 --> Model Class Initialized
DEBUG - 2011-04-07 19:27:31 --> Model Class Initialized
DEBUG - 2011-04-07 19:27:31 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-07 19:27:31 --> Database Driver Class Initialized
DEBUG - 2011-04-07 19:27:31 --> File loaded: application/views/table/main.php
DEBUG - 2011-04-07 19:27:31 --> Helper loaded: url_helper
DEBUG - 2011-04-07 19:27:31 --> File loaded: application/views/common/header.php
DEBUG - 2011-04-07 19:27:31 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-04-07 19:27:31 --> File loaded: application/views/common/footer.php
DEBUG - 2011-04-07 19:27:31 --> File loaded: application/views/layout/main.php
DEBUG - 2011-04-07 19:27:31 --> Final output sent to browser
DEBUG - 2011-04-07 19:27:31 --> Total execution time: 0.1938
DEBUG - 2011-04-07 19:27:40 --> Config Class Initialized
DEBUG - 2011-04-07 19:27:40 --> Hooks Class Initialized
DEBUG - 2011-04-07 19:27:40 --> Utf8 Class Initialized
DEBUG - 2011-04-07 19:27:40 --> UTF-8 Support Enabled
DEBUG - 2011-04-07 19:27:40 --> URI Class Initialized
DEBUG - 2011-04-07 19:27:40 --> Router Class Initialized
ERROR - 2011-04-07 19:27:40 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-04-07 19:27:50 --> Config Class Initialized
DEBUG - 2011-04-07 19:27:50 --> Hooks Class Initialized
DEBUG - 2011-04-07 19:27:50 --> Utf8 Class Initialized
DEBUG - 2011-04-07 19:27:50 --> UTF-8 Support Enabled
DEBUG - 2011-04-07 19:27:50 --> URI Class Initialized
DEBUG - 2011-04-07 19:27:50 --> Router Class Initialized
ERROR - 2011-04-07 19:27:50 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-04-07 19:27:54 --> Config Class Initialized
DEBUG - 2011-04-07 19:27:54 --> Hooks Class Initialized
DEBUG - 2011-04-07 19:27:54 --> Utf8 Class Initialized
DEBUG - 2011-04-07 19:27:54 --> UTF-8 Support Enabled
DEBUG - 2011-04-07 19:27:54 --> URI Class Initialized
DEBUG - 2011-04-07 19:27:54 --> Router Class Initialized
ERROR - 2011-04-07 19:27:54 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-04-07 20:13:14 --> Config Class Initialized
DEBUG - 2011-04-07 20:13:14 --> Hooks Class Initialized
DEBUG - 2011-04-07 20:13:14 --> Utf8 Class Initialized
DEBUG - 2011-04-07 20:13:14 --> UTF-8 Support Enabled
DEBUG - 2011-04-07 20:13:14 --> URI Class Initialized
DEBUG - 2011-04-07 20:13:14 --> Router Class Initialized
DEBUG - 2011-04-07 20:13:14 --> No URI present. Default controller set.
DEBUG - 2011-04-07 20:13:14 --> Output Class Initialized
DEBUG - 2011-04-07 20:13:14 --> Input Class Initialized
DEBUG - 2011-04-07 20:13:14 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-07 20:13:14 --> Language Class Initialized
DEBUG - 2011-04-07 20:13:14 --> Loader Class Initialized
DEBUG - 2011-04-07 20:13:14 --> Controller Class Initialized
DEBUG - 2011-04-07 20:13:14 --> File loaded: application/views/splash/main.php
DEBUG - 2011-04-07 20:13:14 --> Helper loaded: url_helper
DEBUG - 2011-04-07 20:13:14 --> File loaded: application/views/common/header.php
DEBUG - 2011-04-07 20:13:14 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-04-07 20:13:14 --> File loaded: application/views/common/footer.php
DEBUG - 2011-04-07 20:13:14 --> File loaded: application/views/layout/main.php
DEBUG - 2011-04-07 20:13:14 --> Final output sent to browser
DEBUG - 2011-04-07 20:13:14 --> Total execution time: 0.1374
DEBUG - 2011-04-07 20:13:19 --> Config Class Initialized
DEBUG - 2011-04-07 20:13:19 --> Hooks Class Initialized
DEBUG - 2011-04-07 20:13:19 --> Utf8 Class Initialized
DEBUG - 2011-04-07 20:13:19 --> UTF-8 Support Enabled
DEBUG - 2011-04-07 20:13:19 --> URI Class Initialized
DEBUG - 2011-04-07 20:13:19 --> Router Class Initialized
ERROR - 2011-04-07 20:13:19 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-04-07 20:13:20 --> Config Class Initialized
DEBUG - 2011-04-07 20:13:20 --> Hooks Class Initialized
DEBUG - 2011-04-07 20:13:20 --> Utf8 Class Initialized
DEBUG - 2011-04-07 20:13:20 --> UTF-8 Support Enabled
DEBUG - 2011-04-07 20:13:20 --> URI Class Initialized
DEBUG - 2011-04-07 20:13:20 --> Router Class Initialized
DEBUG - 2011-04-07 20:13:20 --> Output Class Initialized
DEBUG - 2011-04-07 20:13:20 --> Input Class Initialized
DEBUG - 2011-04-07 20:13:20 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-07 20:13:20 --> Language Class Initialized
DEBUG - 2011-04-07 20:13:20 --> Loader Class Initialized
DEBUG - 2011-04-07 20:13:20 --> Controller Class Initialized
DEBUG - 2011-04-07 20:13:20 --> Model Class Initialized
DEBUG - 2011-04-07 20:13:20 --> Model Class Initialized
DEBUG - 2011-04-07 20:13:20 --> Model Class Initialized
DEBUG - 2011-04-07 20:13:20 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-07 20:13:20 --> Database Driver Class Initialized
DEBUG - 2011-04-07 20:13:20 --> File loaded: application/views/table/main.php
DEBUG - 2011-04-07 20:13:20 --> Helper loaded: url_helper
DEBUG - 2011-04-07 20:13:20 --> File loaded: application/views/common/header.php
DEBUG - 2011-04-07 20:13:20 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-04-07 20:13:20 --> File loaded: application/views/common/footer.php
DEBUG - 2011-04-07 20:13:20 --> File loaded: application/views/layout/main.php
DEBUG - 2011-04-07 20:13:20 --> Final output sent to browser
DEBUG - 2011-04-07 20:13:20 --> Total execution time: 0.1856
DEBUG - 2011-04-07 20:13:22 --> Config Class Initialized
DEBUG - 2011-04-07 20:13:22 --> Hooks Class Initialized
DEBUG - 2011-04-07 20:13:22 --> Utf8 Class Initialized
DEBUG - 2011-04-07 20:13:22 --> UTF-8 Support Enabled
DEBUG - 2011-04-07 20:13:22 --> URI Class Initialized
DEBUG - 2011-04-07 20:13:22 --> Router Class Initialized
ERROR - 2011-04-07 20:13:22 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-04-07 20:23:47 --> Config Class Initialized
DEBUG - 2011-04-07 20:23:47 --> Hooks Class Initialized
DEBUG - 2011-04-07 20:23:47 --> Utf8 Class Initialized
DEBUG - 2011-04-07 20:23:47 --> UTF-8 Support Enabled
DEBUG - 2011-04-07 20:23:47 --> URI Class Initialized
DEBUG - 2011-04-07 20:23:47 --> Router Class Initialized
DEBUG - 2011-04-07 20:23:47 --> Output Class Initialized
DEBUG - 2011-04-07 20:23:47 --> Input Class Initialized
DEBUG - 2011-04-07 20:23:47 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-07 20:23:47 --> Language Class Initialized
DEBUG - 2011-04-07 20:23:47 --> Loader Class Initialized
DEBUG - 2011-04-07 20:23:47 --> Controller Class Initialized
ERROR - 2011-04-07 20:23:47 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-04-07 20:23:47 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-04-07 20:23:47 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-04-07 20:23:47 --> Model Class Initialized
DEBUG - 2011-04-07 20:23:47 --> Model Class Initialized
DEBUG - 2011-04-07 20:23:47 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-07 20:23:47 --> Database Driver Class Initialized
DEBUG - 2011-04-07 20:23:47 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-04-07 20:23:47 --> Helper loaded: url_helper
DEBUG - 2011-04-07 20:23:47 --> File loaded: application/views/common/header.php
DEBUG - 2011-04-07 20:23:47 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-04-07 20:23:47 --> File loaded: application/views/common/footer.php
DEBUG - 2011-04-07 20:23:47 --> File loaded: application/views/layout/main.php
DEBUG - 2011-04-07 20:23:47 --> Final output sent to browser
DEBUG - 2011-04-07 20:23:47 --> Total execution time: 0.3155
DEBUG - 2011-04-07 21:30:55 --> Config Class Initialized
DEBUG - 2011-04-07 21:30:55 --> Hooks Class Initialized
DEBUG - 2011-04-07 21:30:55 --> Utf8 Class Initialized
DEBUG - 2011-04-07 21:30:55 --> UTF-8 Support Enabled
DEBUG - 2011-04-07 21:30:55 --> URI Class Initialized
DEBUG - 2011-04-07 21:30:55 --> Router Class Initialized
DEBUG - 2011-04-07 21:30:55 --> Output Class Initialized
DEBUG - 2011-04-07 21:30:55 --> Input Class Initialized
DEBUG - 2011-04-07 21:30:55 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-07 21:30:55 --> Language Class Initialized
DEBUG - 2011-04-07 21:30:55 --> Loader Class Initialized
DEBUG - 2011-04-07 21:30:55 --> Controller Class Initialized
ERROR - 2011-04-07 21:30:55 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-04-07 21:30:55 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-04-07 21:30:55 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-04-07 21:30:55 --> Model Class Initialized
DEBUG - 2011-04-07 21:30:55 --> Model Class Initialized
DEBUG - 2011-04-07 21:30:55 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-07 21:30:55 --> Database Driver Class Initialized
DEBUG - 2011-04-07 21:30:55 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-04-07 21:30:55 --> Helper loaded: url_helper
DEBUG - 2011-04-07 21:30:55 --> File loaded: application/views/common/header.php
DEBUG - 2011-04-07 21:30:55 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-04-07 21:30:55 --> File loaded: application/views/common/footer.php
DEBUG - 2011-04-07 21:30:55 --> File loaded: application/views/layout/main.php
DEBUG - 2011-04-07 21:30:55 --> Final output sent to browser
DEBUG - 2011-04-07 21:30:55 --> Total execution time: 0.4225
DEBUG - 2011-04-07 22:46:58 --> Config Class Initialized
DEBUG - 2011-04-07 22:46:58 --> Hooks Class Initialized
DEBUG - 2011-04-07 22:46:58 --> Utf8 Class Initialized
DEBUG - 2011-04-07 22:46:58 --> UTF-8 Support Enabled
DEBUG - 2011-04-07 22:46:58 --> URI Class Initialized
DEBUG - 2011-04-07 22:46:58 --> Router Class Initialized
DEBUG - 2011-04-07 22:46:58 --> Output Class Initialized
DEBUG - 2011-04-07 22:46:58 --> Input Class Initialized
DEBUG - 2011-04-07 22:46:58 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-07 22:46:58 --> Language Class Initialized
DEBUG - 2011-04-07 22:46:58 --> Loader Class Initialized
DEBUG - 2011-04-07 22:46:58 --> Controller Class Initialized
ERROR - 2011-04-07 22:46:58 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-04-07 22:46:58 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-04-07 22:46:58 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-04-07 22:46:58 --> Model Class Initialized
DEBUG - 2011-04-07 22:46:58 --> Model Class Initialized
DEBUG - 2011-04-07 22:46:58 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-07 22:46:58 --> Database Driver Class Initialized
DEBUG - 2011-04-07 22:46:58 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-04-07 22:46:58 --> Helper loaded: url_helper
DEBUG - 2011-04-07 22:46:58 --> File loaded: application/views/common/header.php
DEBUG - 2011-04-07 22:46:58 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-04-07 22:46:58 --> File loaded: application/views/common/footer.php
DEBUG - 2011-04-07 22:46:58 --> File loaded: application/views/layout/main.php
DEBUG - 2011-04-07 22:46:58 --> Final output sent to browser
DEBUG - 2011-04-07 22:46:58 --> Total execution time: 0.2814
DEBUG - 2011-04-07 22:47:14 --> Config Class Initialized
DEBUG - 2011-04-07 22:47:14 --> Hooks Class Initialized
DEBUG - 2011-04-07 22:47:14 --> Utf8 Class Initialized
DEBUG - 2011-04-07 22:47:14 --> UTF-8 Support Enabled
DEBUG - 2011-04-07 22:47:14 --> URI Class Initialized
DEBUG - 2011-04-07 22:47:14 --> Router Class Initialized
DEBUG - 2011-04-07 22:47:14 --> Output Class Initialized
DEBUG - 2011-04-07 22:47:14 --> Input Class Initialized
DEBUG - 2011-04-07 22:47:14 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-07 22:47:14 --> Language Class Initialized
DEBUG - 2011-04-07 22:47:14 --> Loader Class Initialized
DEBUG - 2011-04-07 22:47:14 --> Controller Class Initialized
DEBUG - 2011-04-07 22:47:14 --> Model Class Initialized
DEBUG - 2011-04-07 22:47:14 --> Model Class Initialized
DEBUG - 2011-04-07 22:47:14 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-07 22:47:14 --> Database Driver Class Initialized
DEBUG - 2011-04-07 22:47:18 --> Final output sent to browser
DEBUG - 2011-04-07 22:47:18 --> Total execution time: 3.8703
DEBUG - 2011-04-07 22:47:25 --> Config Class Initialized
DEBUG - 2011-04-07 22:47:25 --> Hooks Class Initialized
DEBUG - 2011-04-07 22:47:25 --> Utf8 Class Initialized
DEBUG - 2011-04-07 22:47:25 --> UTF-8 Support Enabled
DEBUG - 2011-04-07 22:47:25 --> URI Class Initialized
DEBUG - 2011-04-07 22:47:25 --> Router Class Initialized
ERROR - 2011-04-07 22:47:25 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-04-07 22:48:23 --> Config Class Initialized
DEBUG - 2011-04-07 22:48:23 --> Hooks Class Initialized
DEBUG - 2011-04-07 22:48:23 --> Utf8 Class Initialized
DEBUG - 2011-04-07 22:48:23 --> UTF-8 Support Enabled
DEBUG - 2011-04-07 22:48:23 --> URI Class Initialized
DEBUG - 2011-04-07 22:48:23 --> Router Class Initialized
DEBUG - 2011-04-07 22:48:23 --> Output Class Initialized
DEBUG - 2011-04-07 22:48:23 --> Input Class Initialized
DEBUG - 2011-04-07 22:48:23 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-07 22:48:23 --> Language Class Initialized
DEBUG - 2011-04-07 22:48:23 --> Loader Class Initialized
DEBUG - 2011-04-07 22:48:23 --> Controller Class Initialized
ERROR - 2011-04-07 22:48:23 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-04-07 22:48:23 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-04-07 22:48:23 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-04-07 22:48:23 --> Model Class Initialized
DEBUG - 2011-04-07 22:48:23 --> Model Class Initialized
DEBUG - 2011-04-07 22:48:23 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-07 22:48:23 --> Database Driver Class Initialized
DEBUG - 2011-04-07 22:48:23 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-04-07 22:48:23 --> Helper loaded: url_helper
DEBUG - 2011-04-07 22:48:23 --> File loaded: application/views/common/header.php
DEBUG - 2011-04-07 22:48:23 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-04-07 22:48:23 --> File loaded: application/views/common/footer.php
DEBUG - 2011-04-07 22:48:23 --> File loaded: application/views/layout/main.php
DEBUG - 2011-04-07 22:48:23 --> Final output sent to browser
DEBUG - 2011-04-07 22:48:23 --> Total execution time: 0.0354
DEBUG - 2011-04-07 22:48:24 --> Config Class Initialized
DEBUG - 2011-04-07 22:48:24 --> Hooks Class Initialized
DEBUG - 2011-04-07 22:48:24 --> Utf8 Class Initialized
DEBUG - 2011-04-07 22:48:24 --> UTF-8 Support Enabled
DEBUG - 2011-04-07 22:48:24 --> URI Class Initialized
DEBUG - 2011-04-07 22:48:24 --> Router Class Initialized
DEBUG - 2011-04-07 22:48:24 --> Output Class Initialized
DEBUG - 2011-04-07 22:48:24 --> Input Class Initialized
DEBUG - 2011-04-07 22:48:24 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-07 22:48:24 --> Language Class Initialized
DEBUG - 2011-04-07 22:48:24 --> Loader Class Initialized
DEBUG - 2011-04-07 22:48:24 --> Controller Class Initialized
DEBUG - 2011-04-07 22:48:24 --> Model Class Initialized
DEBUG - 2011-04-07 22:48:24 --> Model Class Initialized
DEBUG - 2011-04-07 22:48:24 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-07 22:48:24 --> Database Driver Class Initialized
DEBUG - 2011-04-07 22:48:25 --> Final output sent to browser
DEBUG - 2011-04-07 22:48:25 --> Total execution time: 0.6388
DEBUG - 2011-04-07 22:48:26 --> Config Class Initialized
DEBUG - 2011-04-07 22:48:26 --> Hooks Class Initialized
DEBUG - 2011-04-07 22:48:26 --> Utf8 Class Initialized
DEBUG - 2011-04-07 22:48:26 --> UTF-8 Support Enabled
DEBUG - 2011-04-07 22:48:26 --> URI Class Initialized
DEBUG - 2011-04-07 22:48:26 --> Router Class Initialized
ERROR - 2011-04-07 22:48:26 --> 404 Page Not Found --> robots.txt
DEBUG - 2011-04-07 22:48:26 --> Config Class Initialized
DEBUG - 2011-04-07 22:48:26 --> Hooks Class Initialized
DEBUG - 2011-04-07 22:48:26 --> Utf8 Class Initialized
DEBUG - 2011-04-07 22:48:26 --> UTF-8 Support Enabled
DEBUG - 2011-04-07 22:48:26 --> URI Class Initialized
DEBUG - 2011-04-07 22:48:26 --> Router Class Initialized
DEBUG - 2011-04-07 22:48:26 --> Output Class Initialized
DEBUG - 2011-04-07 22:48:26 --> Input Class Initialized
DEBUG - 2011-04-07 22:48:26 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-07 22:48:26 --> Language Class Initialized
DEBUG - 2011-04-07 22:48:26 --> Loader Class Initialized
DEBUG - 2011-04-07 22:48:26 --> Controller Class Initialized
ERROR - 2011-04-07 22:48:26 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-04-07 22:48:26 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-04-07 22:48:26 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-04-07 22:48:26 --> Model Class Initialized
DEBUG - 2011-04-07 22:48:26 --> Model Class Initialized
DEBUG - 2011-04-07 22:48:26 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-07 22:48:26 --> Database Driver Class Initialized
DEBUG - 2011-04-07 22:48:26 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-04-07 22:48:26 --> Helper loaded: url_helper
DEBUG - 2011-04-07 22:48:26 --> File loaded: application/views/common/header.php
DEBUG - 2011-04-07 22:48:26 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-04-07 22:48:26 --> File loaded: application/views/common/footer.php
DEBUG - 2011-04-07 22:48:26 --> File loaded: application/views/layout/main.php
DEBUG - 2011-04-07 22:48:26 --> Final output sent to browser
DEBUG - 2011-04-07 22:48:26 --> Total execution time: 0.0303
DEBUG - 2011-04-07 22:49:25 --> Config Class Initialized
DEBUG - 2011-04-07 22:49:25 --> Hooks Class Initialized
DEBUG - 2011-04-07 22:49:25 --> Utf8 Class Initialized
DEBUG - 2011-04-07 22:49:25 --> UTF-8 Support Enabled
DEBUG - 2011-04-07 22:49:25 --> URI Class Initialized
DEBUG - 2011-04-07 22:49:25 --> Router Class Initialized
DEBUG - 2011-04-07 22:49:25 --> No URI present. Default controller set.
DEBUG - 2011-04-07 22:49:25 --> Output Class Initialized
DEBUG - 2011-04-07 22:49:25 --> Input Class Initialized
DEBUG - 2011-04-07 22:49:25 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-07 22:49:25 --> Language Class Initialized
DEBUG - 2011-04-07 22:49:25 --> Loader Class Initialized
DEBUG - 2011-04-07 22:49:25 --> Controller Class Initialized
DEBUG - 2011-04-07 22:49:26 --> File loaded: application/views/splash/main.php
DEBUG - 2011-04-07 22:49:26 --> Helper loaded: url_helper
DEBUG - 2011-04-07 22:49:26 --> File loaded: application/views/common/header.php
DEBUG - 2011-04-07 22:49:26 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-04-07 22:49:26 --> File loaded: application/views/common/footer.php
DEBUG - 2011-04-07 22:49:26 --> File loaded: application/views/layout/main.php
DEBUG - 2011-04-07 22:49:26 --> Final output sent to browser
DEBUG - 2011-04-07 22:49:26 --> Total execution time: 0.2557
DEBUG - 2011-04-07 22:52:35 --> Config Class Initialized
DEBUG - 2011-04-07 22:52:35 --> Hooks Class Initialized
DEBUG - 2011-04-07 22:52:35 --> Utf8 Class Initialized
DEBUG - 2011-04-07 22:52:35 --> UTF-8 Support Enabled
DEBUG - 2011-04-07 22:52:35 --> URI Class Initialized
DEBUG - 2011-04-07 22:52:35 --> Router Class Initialized
DEBUG - 2011-04-07 22:52:35 --> Output Class Initialized
DEBUG - 2011-04-07 22:52:35 --> Input Class Initialized
DEBUG - 2011-04-07 22:52:35 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-07 22:52:35 --> Language Class Initialized
DEBUG - 2011-04-07 22:52:35 --> Loader Class Initialized
DEBUG - 2011-04-07 22:52:35 --> Controller Class Initialized
DEBUG - 2011-04-07 22:52:35 --> Model Class Initialized
DEBUG - 2011-04-07 22:52:35 --> Model Class Initialized
DEBUG - 2011-04-07 22:52:35 --> Model Class Initialized
DEBUG - 2011-04-07 22:52:35 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-07 22:52:35 --> Database Driver Class Initialized
DEBUG - 2011-04-07 22:52:35 --> File loaded: application/views/table/main.php
DEBUG - 2011-04-07 22:52:35 --> Helper loaded: url_helper
DEBUG - 2011-04-07 22:52:35 --> File loaded: application/views/common/header.php
DEBUG - 2011-04-07 22:52:35 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-04-07 22:52:35 --> File loaded: application/views/common/footer.php
DEBUG - 2011-04-07 22:52:35 --> File loaded: application/views/layout/main.php
DEBUG - 2011-04-07 22:52:35 --> Final output sent to browser
DEBUG - 2011-04-07 22:52:35 --> Total execution time: 0.2222
DEBUG - 2011-04-07 22:54:51 --> Config Class Initialized
DEBUG - 2011-04-07 22:54:51 --> Hooks Class Initialized
DEBUG - 2011-04-07 22:54:51 --> Utf8 Class Initialized
DEBUG - 2011-04-07 22:54:51 --> UTF-8 Support Enabled
DEBUG - 2011-04-07 22:54:51 --> URI Class Initialized
DEBUG - 2011-04-07 22:54:51 --> Router Class Initialized
DEBUG - 2011-04-07 22:54:51 --> Output Class Initialized
DEBUG - 2011-04-07 22:54:51 --> Input Class Initialized
DEBUG - 2011-04-07 22:54:51 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-07 22:54:51 --> Language Class Initialized
DEBUG - 2011-04-07 22:54:51 --> Loader Class Initialized
DEBUG - 2011-04-07 22:54:51 --> Controller Class Initialized
DEBUG - 2011-04-07 22:54:51 --> Model Class Initialized
DEBUG - 2011-04-07 22:54:51 --> Model Class Initialized
DEBUG - 2011-04-07 22:54:51 --> Model Class Initialized
DEBUG - 2011-04-07 22:54:51 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-07 22:54:51 --> Database Driver Class Initialized
DEBUG - 2011-04-07 22:54:51 --> File loaded: application/views/table/main.php
DEBUG - 2011-04-07 22:54:51 --> Helper loaded: url_helper
DEBUG - 2011-04-07 22:54:51 --> File loaded: application/views/common/header.php
DEBUG - 2011-04-07 22:54:51 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-04-07 22:54:51 --> File loaded: application/views/common/footer.php
DEBUG - 2011-04-07 22:54:51 --> File loaded: application/views/layout/main.php
DEBUG - 2011-04-07 22:54:51 --> Final output sent to browser
DEBUG - 2011-04-07 22:54:51 --> Total execution time: 0.1826

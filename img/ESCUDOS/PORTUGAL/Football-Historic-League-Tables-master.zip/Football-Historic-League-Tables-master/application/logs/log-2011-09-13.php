<?php  if ( ! defined('BASEPATH')) exit('No direct script access allowed'); ?>

DEBUG - 2011-09-13 00:49:07 --> Config Class Initialized
DEBUG - 2011-09-13 00:49:07 --> Hooks Class Initialized
DEBUG - 2011-09-13 00:49:07 --> Utf8 Class Initialized
DEBUG - 2011-09-13 00:49:07 --> UTF-8 Support Enabled
DEBUG - 2011-09-13 00:49:07 --> URI Class Initialized
DEBUG - 2011-09-13 00:49:07 --> Router Class Initialized
DEBUG - 2011-09-13 00:49:07 --> Output Class Initialized
DEBUG - 2011-09-13 00:49:07 --> Input Class Initialized
DEBUG - 2011-09-13 00:49:07 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-13 00:49:07 --> Language Class Initialized
DEBUG - 2011-09-13 00:49:07 --> Loader Class Initialized
DEBUG - 2011-09-13 00:49:07 --> Controller Class Initialized
DEBUG - 2011-09-13 00:49:07 --> Model Class Initialized
DEBUG - 2011-09-13 00:49:07 --> Model Class Initialized
DEBUG - 2011-09-13 00:49:07 --> Model Class Initialized
DEBUG - 2011-09-13 00:49:07 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-13 00:49:07 --> Database Driver Class Initialized
DEBUG - 2011-09-13 00:49:07 --> Config Class Initialized
DEBUG - 2011-09-13 00:49:07 --> Hooks Class Initialized
DEBUG - 2011-09-13 00:49:07 --> Utf8 Class Initialized
DEBUG - 2011-09-13 00:49:07 --> UTF-8 Support Enabled
DEBUG - 2011-09-13 00:49:07 --> URI Class Initialized
DEBUG - 2011-09-13 00:49:07 --> Router Class Initialized
ERROR - 2011-09-13 00:49:07 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-09-13 00:49:07 --> File loaded: application/views/table/main.php
DEBUG - 2011-09-13 00:49:07 --> Helper loaded: url_helper
DEBUG - 2011-09-13 00:49:07 --> File loaded: application/views/common/header.php
DEBUG - 2011-09-13 00:49:07 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-09-13 00:49:07 --> File loaded: application/views/common/footer.php
DEBUG - 2011-09-13 00:49:07 --> File loaded: application/views/layout/main.php
DEBUG - 2011-09-13 00:49:07 --> Final output sent to browser
DEBUG - 2011-09-13 00:49:07 --> Total execution time: 0.5854
DEBUG - 2011-09-13 01:05:29 --> Config Class Initialized
DEBUG - 2011-09-13 01:05:29 --> Hooks Class Initialized
DEBUG - 2011-09-13 01:05:29 --> Utf8 Class Initialized
DEBUG - 2011-09-13 01:05:29 --> UTF-8 Support Enabled
DEBUG - 2011-09-13 01:05:29 --> URI Class Initialized
DEBUG - 2011-09-13 01:05:29 --> Router Class Initialized
DEBUG - 2011-09-13 01:05:29 --> Output Class Initialized
DEBUG - 2011-09-13 01:05:29 --> Input Class Initialized
DEBUG - 2011-09-13 01:05:29 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-13 01:05:29 --> Language Class Initialized
DEBUG - 2011-09-13 01:05:29 --> Loader Class Initialized
DEBUG - 2011-09-13 01:05:29 --> Controller Class Initialized
DEBUG - 2011-09-13 01:05:29 --> Model Class Initialized
DEBUG - 2011-09-13 01:05:29 --> Model Class Initialized
DEBUG - 2011-09-13 01:05:29 --> Model Class Initialized
DEBUG - 2011-09-13 01:05:29 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-13 01:05:29 --> Database Driver Class Initialized
DEBUG - 2011-09-13 01:05:31 --> File loaded: application/views/table/main.php
DEBUG - 2011-09-13 01:05:31 --> Helper loaded: url_helper
DEBUG - 2011-09-13 01:05:31 --> File loaded: application/views/common/header.php
DEBUG - 2011-09-13 01:05:31 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-09-13 01:05:31 --> File loaded: application/views/common/footer.php
DEBUG - 2011-09-13 01:05:31 --> File loaded: application/views/layout/main.php
DEBUG - 2011-09-13 01:05:31 --> Final output sent to browser
DEBUG - 2011-09-13 01:05:31 --> Total execution time: 2.2596
DEBUG - 2011-09-13 01:05:38 --> Config Class Initialized
DEBUG - 2011-09-13 01:05:38 --> Hooks Class Initialized
DEBUG - 2011-09-13 01:05:38 --> Utf8 Class Initialized
DEBUG - 2011-09-13 01:05:38 --> UTF-8 Support Enabled
DEBUG - 2011-09-13 01:05:38 --> URI Class Initialized
DEBUG - 2011-09-13 01:05:38 --> Router Class Initialized
DEBUG - 2011-09-13 01:05:38 --> Output Class Initialized
DEBUG - 2011-09-13 01:05:38 --> Input Class Initialized
DEBUG - 2011-09-13 01:05:38 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-13 01:05:38 --> Language Class Initialized
DEBUG - 2011-09-13 01:05:38 --> Loader Class Initialized
DEBUG - 2011-09-13 01:05:38 --> Controller Class Initialized
DEBUG - 2011-09-13 01:05:38 --> Model Class Initialized
DEBUG - 2011-09-13 01:05:38 --> Model Class Initialized
DEBUG - 2011-09-13 01:05:38 --> Model Class Initialized
DEBUG - 2011-09-13 01:05:38 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-13 01:05:38 --> Database Driver Class Initialized
DEBUG - 2011-09-13 01:05:38 --> File loaded: application/views/table/main.php
DEBUG - 2011-09-13 01:05:38 --> Helper loaded: url_helper
DEBUG - 2011-09-13 01:05:38 --> File loaded: application/views/common/header.php
DEBUG - 2011-09-13 01:05:38 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-09-13 01:05:38 --> File loaded: application/views/common/footer.php
DEBUG - 2011-09-13 01:05:38 --> File loaded: application/views/layout/main.php
DEBUG - 2011-09-13 01:05:38 --> Final output sent to browser
DEBUG - 2011-09-13 01:05:38 --> Total execution time: 0.0463
DEBUG - 2011-09-13 01:06:14 --> Config Class Initialized
DEBUG - 2011-09-13 01:06:14 --> Hooks Class Initialized
DEBUG - 2011-09-13 01:06:14 --> Utf8 Class Initialized
DEBUG - 2011-09-13 01:06:14 --> UTF-8 Support Enabled
DEBUG - 2011-09-13 01:06:14 --> URI Class Initialized
DEBUG - 2011-09-13 01:06:14 --> Router Class Initialized
DEBUG - 2011-09-13 01:06:14 --> Output Class Initialized
DEBUG - 2011-09-13 01:06:14 --> Input Class Initialized
DEBUG - 2011-09-13 01:06:14 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-13 01:06:14 --> Language Class Initialized
DEBUG - 2011-09-13 01:06:14 --> Loader Class Initialized
DEBUG - 2011-09-13 01:06:14 --> Controller Class Initialized
DEBUG - 2011-09-13 01:06:14 --> Model Class Initialized
DEBUG - 2011-09-13 01:06:14 --> Model Class Initialized
DEBUG - 2011-09-13 01:06:14 --> Model Class Initialized
DEBUG - 2011-09-13 01:06:14 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-13 01:06:14 --> Database Driver Class Initialized
DEBUG - 2011-09-13 01:06:14 --> File loaded: application/views/table/main.php
DEBUG - 2011-09-13 01:06:14 --> Helper loaded: url_helper
DEBUG - 2011-09-13 01:06:14 --> File loaded: application/views/common/header.php
DEBUG - 2011-09-13 01:06:14 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-09-13 01:06:14 --> File loaded: application/views/common/footer.php
DEBUG - 2011-09-13 01:06:14 --> File loaded: application/views/layout/main.php
DEBUG - 2011-09-13 01:06:14 --> Final output sent to browser
DEBUG - 2011-09-13 01:06:14 --> Total execution time: 0.2665
DEBUG - 2011-09-13 01:06:17 --> Config Class Initialized
DEBUG - 2011-09-13 01:06:17 --> Hooks Class Initialized
DEBUG - 2011-09-13 01:06:17 --> Utf8 Class Initialized
DEBUG - 2011-09-13 01:06:17 --> UTF-8 Support Enabled
DEBUG - 2011-09-13 01:06:17 --> URI Class Initialized
DEBUG - 2011-09-13 01:06:17 --> Router Class Initialized
DEBUG - 2011-09-13 01:06:17 --> Output Class Initialized
DEBUG - 2011-09-13 01:06:17 --> Input Class Initialized
DEBUG - 2011-09-13 01:06:17 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-13 01:06:17 --> Language Class Initialized
DEBUG - 2011-09-13 01:06:17 --> Loader Class Initialized
DEBUG - 2011-09-13 01:06:17 --> Controller Class Initialized
DEBUG - 2011-09-13 01:06:17 --> Model Class Initialized
DEBUG - 2011-09-13 01:06:17 --> Model Class Initialized
DEBUG - 2011-09-13 01:06:17 --> Model Class Initialized
DEBUG - 2011-09-13 01:06:17 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-13 01:06:17 --> Database Driver Class Initialized
DEBUG - 2011-09-13 01:06:17 --> File loaded: application/views/table/main.php
DEBUG - 2011-09-13 01:06:17 --> Helper loaded: url_helper
DEBUG - 2011-09-13 01:06:17 --> File loaded: application/views/common/header.php
DEBUG - 2011-09-13 01:06:17 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-09-13 01:06:17 --> File loaded: application/views/common/footer.php
DEBUG - 2011-09-13 01:06:17 --> File loaded: application/views/layout/main.php
DEBUG - 2011-09-13 01:06:17 --> Final output sent to browser
DEBUG - 2011-09-13 01:06:17 --> Total execution time: 0.0724
DEBUG - 2011-09-13 01:06:54 --> Config Class Initialized
DEBUG - 2011-09-13 01:06:54 --> Hooks Class Initialized
DEBUG - 2011-09-13 01:06:54 --> Utf8 Class Initialized
DEBUG - 2011-09-13 01:06:54 --> UTF-8 Support Enabled
DEBUG - 2011-09-13 01:06:54 --> URI Class Initialized
DEBUG - 2011-09-13 01:06:54 --> Router Class Initialized
DEBUG - 2011-09-13 01:06:54 --> Output Class Initialized
DEBUG - 2011-09-13 01:06:54 --> Input Class Initialized
DEBUG - 2011-09-13 01:06:54 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-13 01:06:54 --> Language Class Initialized
DEBUG - 2011-09-13 01:06:54 --> Loader Class Initialized
DEBUG - 2011-09-13 01:06:54 --> Controller Class Initialized
DEBUG - 2011-09-13 01:06:54 --> Model Class Initialized
DEBUG - 2011-09-13 01:06:54 --> Model Class Initialized
DEBUG - 2011-09-13 01:06:54 --> Model Class Initialized
DEBUG - 2011-09-13 01:06:54 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-13 01:06:54 --> Database Driver Class Initialized
DEBUG - 2011-09-13 01:06:54 --> File loaded: application/views/table/main.php
DEBUG - 2011-09-13 01:06:54 --> Helper loaded: url_helper
DEBUG - 2011-09-13 01:06:54 --> File loaded: application/views/common/header.php
DEBUG - 2011-09-13 01:06:54 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-09-13 01:06:54 --> File loaded: application/views/common/footer.php
DEBUG - 2011-09-13 01:06:54 --> File loaded: application/views/layout/main.php
DEBUG - 2011-09-13 01:06:54 --> Final output sent to browser
DEBUG - 2011-09-13 01:06:54 --> Total execution time: 0.3280
DEBUG - 2011-09-13 01:07:08 --> Config Class Initialized
DEBUG - 2011-09-13 01:07:08 --> Hooks Class Initialized
DEBUG - 2011-09-13 01:07:08 --> Utf8 Class Initialized
DEBUG - 2011-09-13 01:07:08 --> UTF-8 Support Enabled
DEBUG - 2011-09-13 01:07:08 --> URI Class Initialized
DEBUG - 2011-09-13 01:07:08 --> Router Class Initialized
DEBUG - 2011-09-13 01:07:08 --> Output Class Initialized
DEBUG - 2011-09-13 01:07:08 --> Input Class Initialized
DEBUG - 2011-09-13 01:07:08 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-13 01:07:08 --> Language Class Initialized
DEBUG - 2011-09-13 01:07:08 --> Loader Class Initialized
DEBUG - 2011-09-13 01:07:08 --> Controller Class Initialized
DEBUG - 2011-09-13 01:07:08 --> Model Class Initialized
DEBUG - 2011-09-13 01:07:08 --> Model Class Initialized
DEBUG - 2011-09-13 01:07:08 --> Model Class Initialized
DEBUG - 2011-09-13 01:07:08 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-13 01:07:08 --> Database Driver Class Initialized
DEBUG - 2011-09-13 01:07:08 --> File loaded: application/views/table/main.php
DEBUG - 2011-09-13 01:07:08 --> Helper loaded: url_helper
DEBUG - 2011-09-13 01:07:08 --> File loaded: application/views/common/header.php
DEBUG - 2011-09-13 01:07:08 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-09-13 01:07:08 --> File loaded: application/views/common/footer.php
DEBUG - 2011-09-13 01:07:08 --> File loaded: application/views/layout/main.php
DEBUG - 2011-09-13 01:07:08 --> Final output sent to browser
DEBUG - 2011-09-13 01:07:08 --> Total execution time: 0.0456
DEBUG - 2011-09-13 01:07:37 --> Config Class Initialized
DEBUG - 2011-09-13 01:07:37 --> Hooks Class Initialized
DEBUG - 2011-09-13 01:07:37 --> Utf8 Class Initialized
DEBUG - 2011-09-13 01:07:37 --> UTF-8 Support Enabled
DEBUG - 2011-09-13 01:07:37 --> URI Class Initialized
DEBUG - 2011-09-13 01:07:37 --> Router Class Initialized
DEBUG - 2011-09-13 01:07:37 --> Output Class Initialized
DEBUG - 2011-09-13 01:07:37 --> Input Class Initialized
DEBUG - 2011-09-13 01:07:37 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-13 01:07:37 --> Language Class Initialized
DEBUG - 2011-09-13 01:07:37 --> Loader Class Initialized
DEBUG - 2011-09-13 01:07:37 --> Controller Class Initialized
DEBUG - 2011-09-13 01:07:37 --> Model Class Initialized
DEBUG - 2011-09-13 01:07:37 --> Model Class Initialized
DEBUG - 2011-09-13 01:07:37 --> Model Class Initialized
DEBUG - 2011-09-13 01:07:37 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-13 01:07:37 --> Database Driver Class Initialized
DEBUG - 2011-09-13 01:07:37 --> File loaded: application/views/table/main.php
DEBUG - 2011-09-13 01:07:37 --> Helper loaded: url_helper
DEBUG - 2011-09-13 01:07:37 --> File loaded: application/views/common/header.php
DEBUG - 2011-09-13 01:07:37 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-09-13 01:07:37 --> File loaded: application/views/common/footer.php
DEBUG - 2011-09-13 01:07:37 --> File loaded: application/views/layout/main.php
DEBUG - 2011-09-13 01:07:37 --> Final output sent to browser
DEBUG - 2011-09-13 01:07:37 --> Total execution time: 0.4864
DEBUG - 2011-09-13 01:07:39 --> Config Class Initialized
DEBUG - 2011-09-13 01:07:39 --> Hooks Class Initialized
DEBUG - 2011-09-13 01:07:39 --> Utf8 Class Initialized
DEBUG - 2011-09-13 01:07:39 --> UTF-8 Support Enabled
DEBUG - 2011-09-13 01:07:39 --> URI Class Initialized
DEBUG - 2011-09-13 01:07:39 --> Router Class Initialized
DEBUG - 2011-09-13 01:07:39 --> Output Class Initialized
DEBUG - 2011-09-13 01:07:39 --> Input Class Initialized
DEBUG - 2011-09-13 01:07:39 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-13 01:07:39 --> Language Class Initialized
DEBUG - 2011-09-13 01:07:39 --> Loader Class Initialized
DEBUG - 2011-09-13 01:07:39 --> Controller Class Initialized
DEBUG - 2011-09-13 01:07:39 --> Model Class Initialized
DEBUG - 2011-09-13 01:07:39 --> Model Class Initialized
DEBUG - 2011-09-13 01:07:39 --> Model Class Initialized
DEBUG - 2011-09-13 01:07:39 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-13 01:07:39 --> Database Driver Class Initialized
DEBUG - 2011-09-13 01:07:39 --> File loaded: application/views/table/main.php
DEBUG - 2011-09-13 01:07:39 --> Helper loaded: url_helper
DEBUG - 2011-09-13 01:07:39 --> File loaded: application/views/common/header.php
DEBUG - 2011-09-13 01:07:39 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-09-13 01:07:39 --> File loaded: application/views/common/footer.php
DEBUG - 2011-09-13 01:07:39 --> File loaded: application/views/layout/main.php
DEBUG - 2011-09-13 01:07:39 --> Final output sent to browser
DEBUG - 2011-09-13 01:07:39 --> Total execution time: 0.0575
DEBUG - 2011-09-13 01:08:11 --> Config Class Initialized
DEBUG - 2011-09-13 01:08:11 --> Hooks Class Initialized
DEBUG - 2011-09-13 01:08:11 --> Utf8 Class Initialized
DEBUG - 2011-09-13 01:08:11 --> UTF-8 Support Enabled
DEBUG - 2011-09-13 01:08:11 --> URI Class Initialized
DEBUG - 2011-09-13 01:08:11 --> Router Class Initialized
DEBUG - 2011-09-13 01:08:11 --> Output Class Initialized
DEBUG - 2011-09-13 01:08:11 --> Input Class Initialized
DEBUG - 2011-09-13 01:08:11 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-13 01:08:11 --> Language Class Initialized
DEBUG - 2011-09-13 01:08:11 --> Loader Class Initialized
DEBUG - 2011-09-13 01:08:11 --> Controller Class Initialized
DEBUG - 2011-09-13 01:08:11 --> Model Class Initialized
DEBUG - 2011-09-13 01:08:11 --> Model Class Initialized
DEBUG - 2011-09-13 01:08:11 --> Model Class Initialized
DEBUG - 2011-09-13 01:08:11 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-13 01:08:11 --> Database Driver Class Initialized
DEBUG - 2011-09-13 01:08:11 --> File loaded: application/views/table/main.php
DEBUG - 2011-09-13 01:08:11 --> Helper loaded: url_helper
DEBUG - 2011-09-13 01:08:11 --> File loaded: application/views/common/header.php
DEBUG - 2011-09-13 01:08:11 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-09-13 01:08:11 --> File loaded: application/views/common/footer.php
DEBUG - 2011-09-13 01:08:11 --> File loaded: application/views/layout/main.php
DEBUG - 2011-09-13 01:08:11 --> Final output sent to browser
DEBUG - 2011-09-13 01:08:11 --> Total execution time: 0.0819
DEBUG - 2011-09-13 01:08:26 --> Config Class Initialized
DEBUG - 2011-09-13 01:08:26 --> Hooks Class Initialized
DEBUG - 2011-09-13 01:08:26 --> Utf8 Class Initialized
DEBUG - 2011-09-13 01:08:26 --> UTF-8 Support Enabled
DEBUG - 2011-09-13 01:08:26 --> URI Class Initialized
DEBUG - 2011-09-13 01:08:26 --> Router Class Initialized
DEBUG - 2011-09-13 01:08:26 --> Output Class Initialized
DEBUG - 2011-09-13 01:08:26 --> Input Class Initialized
DEBUG - 2011-09-13 01:08:26 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-13 01:08:26 --> Language Class Initialized
DEBUG - 2011-09-13 01:08:26 --> Loader Class Initialized
DEBUG - 2011-09-13 01:08:26 --> Controller Class Initialized
DEBUG - 2011-09-13 01:08:26 --> Model Class Initialized
DEBUG - 2011-09-13 01:08:26 --> Model Class Initialized
DEBUG - 2011-09-13 01:08:26 --> Model Class Initialized
DEBUG - 2011-09-13 01:08:26 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-13 01:08:26 --> Database Driver Class Initialized
DEBUG - 2011-09-13 01:08:26 --> File loaded: application/views/table/main.php
DEBUG - 2011-09-13 01:08:26 --> Helper loaded: url_helper
DEBUG - 2011-09-13 01:08:26 --> File loaded: application/views/common/header.php
DEBUG - 2011-09-13 01:08:26 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-09-13 01:08:26 --> File loaded: application/views/common/footer.php
DEBUG - 2011-09-13 01:08:26 --> File loaded: application/views/layout/main.php
DEBUG - 2011-09-13 01:08:26 --> Final output sent to browser
DEBUG - 2011-09-13 01:08:26 --> Total execution time: 0.4683
DEBUG - 2011-09-13 01:08:55 --> Config Class Initialized
DEBUG - 2011-09-13 01:08:55 --> Hooks Class Initialized
DEBUG - 2011-09-13 01:08:55 --> Utf8 Class Initialized
DEBUG - 2011-09-13 01:08:55 --> UTF-8 Support Enabled
DEBUG - 2011-09-13 01:08:55 --> URI Class Initialized
DEBUG - 2011-09-13 01:08:55 --> Router Class Initialized
DEBUG - 2011-09-13 01:08:55 --> Output Class Initialized
DEBUG - 2011-09-13 01:08:55 --> Input Class Initialized
DEBUG - 2011-09-13 01:08:55 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-13 01:08:55 --> Language Class Initialized
DEBUG - 2011-09-13 01:08:55 --> Loader Class Initialized
DEBUG - 2011-09-13 01:08:55 --> Controller Class Initialized
DEBUG - 2011-09-13 01:08:55 --> Model Class Initialized
DEBUG - 2011-09-13 01:08:55 --> Model Class Initialized
DEBUG - 2011-09-13 01:08:55 --> Model Class Initialized
DEBUG - 2011-09-13 01:08:55 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-13 01:08:55 --> Database Driver Class Initialized
DEBUG - 2011-09-13 01:08:56 --> File loaded: application/views/table/main.php
DEBUG - 2011-09-13 01:08:56 --> Helper loaded: url_helper
DEBUG - 2011-09-13 01:08:56 --> File loaded: application/views/common/header.php
DEBUG - 2011-09-13 01:08:56 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-09-13 01:08:56 --> File loaded: application/views/common/footer.php
DEBUG - 2011-09-13 01:08:56 --> File loaded: application/views/layout/main.php
DEBUG - 2011-09-13 01:08:56 --> Final output sent to browser
DEBUG - 2011-09-13 01:08:56 --> Total execution time: 0.2690
DEBUG - 2011-09-13 01:09:12 --> Config Class Initialized
DEBUG - 2011-09-13 01:09:12 --> Hooks Class Initialized
DEBUG - 2011-09-13 01:09:12 --> Utf8 Class Initialized
DEBUG - 2011-09-13 01:09:12 --> UTF-8 Support Enabled
DEBUG - 2011-09-13 01:09:12 --> URI Class Initialized
DEBUG - 2011-09-13 01:09:12 --> Router Class Initialized
DEBUG - 2011-09-13 01:09:12 --> Output Class Initialized
DEBUG - 2011-09-13 01:09:12 --> Input Class Initialized
DEBUG - 2011-09-13 01:09:12 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-13 01:09:12 --> Language Class Initialized
DEBUG - 2011-09-13 01:09:12 --> Loader Class Initialized
DEBUG - 2011-09-13 01:09:12 --> Controller Class Initialized
DEBUG - 2011-09-13 01:09:12 --> Model Class Initialized
DEBUG - 2011-09-13 01:09:12 --> Model Class Initialized
DEBUG - 2011-09-13 01:09:12 --> Model Class Initialized
DEBUG - 2011-09-13 01:09:12 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-13 01:09:12 --> Database Driver Class Initialized
DEBUG - 2011-09-13 01:09:12 --> File loaded: application/views/table/main.php
DEBUG - 2011-09-13 01:09:12 --> Helper loaded: url_helper
DEBUG - 2011-09-13 01:09:12 --> File loaded: application/views/common/header.php
DEBUG - 2011-09-13 01:09:12 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-09-13 01:09:12 --> File loaded: application/views/common/footer.php
DEBUG - 2011-09-13 01:09:12 --> File loaded: application/views/layout/main.php
DEBUG - 2011-09-13 01:09:12 --> Final output sent to browser
DEBUG - 2011-09-13 01:09:12 --> Total execution time: 0.0547
DEBUG - 2011-09-13 01:09:21 --> Config Class Initialized
DEBUG - 2011-09-13 01:09:21 --> Hooks Class Initialized
DEBUG - 2011-09-13 01:09:21 --> Utf8 Class Initialized
DEBUG - 2011-09-13 01:09:21 --> UTF-8 Support Enabled
DEBUG - 2011-09-13 01:09:21 --> URI Class Initialized
DEBUG - 2011-09-13 01:09:21 --> Router Class Initialized
DEBUG - 2011-09-13 01:09:21 --> Output Class Initialized
DEBUG - 2011-09-13 01:09:21 --> Input Class Initialized
DEBUG - 2011-09-13 01:09:21 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-13 01:09:21 --> Language Class Initialized
DEBUG - 2011-09-13 01:09:21 --> Loader Class Initialized
DEBUG - 2011-09-13 01:09:21 --> Controller Class Initialized
DEBUG - 2011-09-13 01:09:21 --> Model Class Initialized
DEBUG - 2011-09-13 01:09:21 --> Model Class Initialized
DEBUG - 2011-09-13 01:09:21 --> Model Class Initialized
DEBUG - 2011-09-13 01:09:21 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-13 01:09:21 --> Database Driver Class Initialized
DEBUG - 2011-09-13 01:09:21 --> File loaded: application/views/table/main.php
DEBUG - 2011-09-13 01:09:21 --> Helper loaded: url_helper
DEBUG - 2011-09-13 01:09:21 --> File loaded: application/views/common/header.php
DEBUG - 2011-09-13 01:09:21 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-09-13 01:09:21 --> File loaded: application/views/common/footer.php
DEBUG - 2011-09-13 01:09:21 --> File loaded: application/views/layout/main.php
DEBUG - 2011-09-13 01:09:21 --> Final output sent to browser
DEBUG - 2011-09-13 01:09:21 --> Total execution time: 0.2539
DEBUG - 2011-09-13 01:09:37 --> Config Class Initialized
DEBUG - 2011-09-13 01:09:37 --> Hooks Class Initialized
DEBUG - 2011-09-13 01:09:37 --> Utf8 Class Initialized
DEBUG - 2011-09-13 01:09:37 --> UTF-8 Support Enabled
DEBUG - 2011-09-13 01:09:37 --> URI Class Initialized
DEBUG - 2011-09-13 01:09:37 --> Router Class Initialized
DEBUG - 2011-09-13 01:09:37 --> Output Class Initialized
DEBUG - 2011-09-13 01:09:37 --> Input Class Initialized
DEBUG - 2011-09-13 01:09:37 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-13 01:09:37 --> Language Class Initialized
DEBUG - 2011-09-13 01:09:37 --> Loader Class Initialized
DEBUG - 2011-09-13 01:09:37 --> Controller Class Initialized
DEBUG - 2011-09-13 01:09:37 --> Model Class Initialized
DEBUG - 2011-09-13 01:09:37 --> Model Class Initialized
DEBUG - 2011-09-13 01:09:37 --> Model Class Initialized
DEBUG - 2011-09-13 01:09:37 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-13 01:09:37 --> Database Driver Class Initialized
DEBUG - 2011-09-13 01:09:38 --> File loaded: application/views/table/main.php
DEBUG - 2011-09-13 01:09:38 --> Helper loaded: url_helper
DEBUG - 2011-09-13 01:09:38 --> File loaded: application/views/common/header.php
DEBUG - 2011-09-13 01:09:38 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-09-13 01:09:38 --> File loaded: application/views/common/footer.php
DEBUG - 2011-09-13 01:09:38 --> File loaded: application/views/layout/main.php
DEBUG - 2011-09-13 01:09:38 --> Final output sent to browser
DEBUG - 2011-09-13 01:09:38 --> Total execution time: 0.2482
DEBUG - 2011-09-13 01:09:47 --> Config Class Initialized
DEBUG - 2011-09-13 01:09:47 --> Hooks Class Initialized
DEBUG - 2011-09-13 01:09:47 --> Utf8 Class Initialized
DEBUG - 2011-09-13 01:09:47 --> UTF-8 Support Enabled
DEBUG - 2011-09-13 01:09:47 --> URI Class Initialized
DEBUG - 2011-09-13 01:09:47 --> Router Class Initialized
DEBUG - 2011-09-13 01:09:47 --> Output Class Initialized
DEBUG - 2011-09-13 01:09:47 --> Input Class Initialized
DEBUG - 2011-09-13 01:09:47 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-13 01:09:47 --> Language Class Initialized
DEBUG - 2011-09-13 01:09:47 --> Loader Class Initialized
DEBUG - 2011-09-13 01:09:47 --> Controller Class Initialized
DEBUG - 2011-09-13 01:09:47 --> Model Class Initialized
DEBUG - 2011-09-13 01:09:47 --> Model Class Initialized
DEBUG - 2011-09-13 01:09:47 --> Model Class Initialized
DEBUG - 2011-09-13 01:09:47 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-13 01:09:47 --> Database Driver Class Initialized
DEBUG - 2011-09-13 01:09:47 --> File loaded: application/views/table/main.php
DEBUG - 2011-09-13 01:09:47 --> Helper loaded: url_helper
DEBUG - 2011-09-13 01:09:47 --> File loaded: application/views/common/header.php
DEBUG - 2011-09-13 01:09:47 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-09-13 01:09:47 --> File loaded: application/views/common/footer.php
DEBUG - 2011-09-13 01:09:47 --> File loaded: application/views/layout/main.php
DEBUG - 2011-09-13 01:09:47 --> Final output sent to browser
DEBUG - 2011-09-13 01:09:47 --> Total execution time: 0.0483
DEBUG - 2011-09-13 01:09:50 --> Config Class Initialized
DEBUG - 2011-09-13 01:09:50 --> Hooks Class Initialized
DEBUG - 2011-09-13 01:09:50 --> Utf8 Class Initialized
DEBUG - 2011-09-13 01:09:50 --> UTF-8 Support Enabled
DEBUG - 2011-09-13 01:09:50 --> URI Class Initialized
DEBUG - 2011-09-13 01:09:50 --> Router Class Initialized
DEBUG - 2011-09-13 01:09:50 --> Output Class Initialized
DEBUG - 2011-09-13 01:09:50 --> Input Class Initialized
DEBUG - 2011-09-13 01:09:50 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-13 01:09:50 --> Language Class Initialized
DEBUG - 2011-09-13 01:09:50 --> Loader Class Initialized
DEBUG - 2011-09-13 01:09:50 --> Controller Class Initialized
DEBUG - 2011-09-13 01:09:50 --> Model Class Initialized
DEBUG - 2011-09-13 01:09:50 --> Model Class Initialized
DEBUG - 2011-09-13 01:09:50 --> Model Class Initialized
DEBUG - 2011-09-13 01:09:50 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-13 01:09:50 --> Database Driver Class Initialized
DEBUG - 2011-09-13 01:09:51 --> File loaded: application/views/table/main.php
DEBUG - 2011-09-13 01:09:51 --> Helper loaded: url_helper
DEBUG - 2011-09-13 01:09:51 --> File loaded: application/views/common/header.php
DEBUG - 2011-09-13 01:09:51 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-09-13 01:09:51 --> File loaded: application/views/common/footer.php
DEBUG - 2011-09-13 01:09:51 --> File loaded: application/views/layout/main.php
DEBUG - 2011-09-13 01:09:51 --> Final output sent to browser
DEBUG - 2011-09-13 01:09:51 --> Total execution time: 0.2158
DEBUG - 2011-09-13 01:10:07 --> Config Class Initialized
DEBUG - 2011-09-13 01:10:07 --> Hooks Class Initialized
DEBUG - 2011-09-13 01:10:07 --> Utf8 Class Initialized
DEBUG - 2011-09-13 01:10:07 --> UTF-8 Support Enabled
DEBUG - 2011-09-13 01:10:07 --> URI Class Initialized
DEBUG - 2011-09-13 01:10:07 --> Router Class Initialized
DEBUG - 2011-09-13 01:10:07 --> Output Class Initialized
DEBUG - 2011-09-13 01:10:07 --> Input Class Initialized
DEBUG - 2011-09-13 01:10:07 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-13 01:10:07 --> Language Class Initialized
DEBUG - 2011-09-13 01:10:07 --> Loader Class Initialized
DEBUG - 2011-09-13 01:10:07 --> Controller Class Initialized
DEBUG - 2011-09-13 01:10:07 --> Model Class Initialized
DEBUG - 2011-09-13 01:10:07 --> Model Class Initialized
DEBUG - 2011-09-13 01:10:07 --> Model Class Initialized
DEBUG - 2011-09-13 01:10:07 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-13 01:10:07 --> Database Driver Class Initialized
DEBUG - 2011-09-13 01:10:07 --> File loaded: application/views/table/main.php
DEBUG - 2011-09-13 01:10:07 --> Helper loaded: url_helper
DEBUG - 2011-09-13 01:10:07 --> File loaded: application/views/common/header.php
DEBUG - 2011-09-13 01:10:07 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-09-13 01:10:07 --> File loaded: application/views/common/footer.php
DEBUG - 2011-09-13 01:10:07 --> File loaded: application/views/layout/main.php
DEBUG - 2011-09-13 01:10:07 --> Final output sent to browser
DEBUG - 2011-09-13 01:10:07 --> Total execution time: 0.0743
DEBUG - 2011-09-13 01:10:08 --> Config Class Initialized
DEBUG - 2011-09-13 01:10:08 --> Hooks Class Initialized
DEBUG - 2011-09-13 01:10:08 --> Utf8 Class Initialized
DEBUG - 2011-09-13 01:10:08 --> UTF-8 Support Enabled
DEBUG - 2011-09-13 01:10:08 --> URI Class Initialized
DEBUG - 2011-09-13 01:10:08 --> Router Class Initialized
DEBUG - 2011-09-13 01:10:08 --> Output Class Initialized
DEBUG - 2011-09-13 01:10:08 --> Input Class Initialized
DEBUG - 2011-09-13 01:10:08 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-13 01:10:08 --> Language Class Initialized
DEBUG - 2011-09-13 01:10:08 --> Loader Class Initialized
DEBUG - 2011-09-13 01:10:08 --> Controller Class Initialized
DEBUG - 2011-09-13 01:10:08 --> Model Class Initialized
DEBUG - 2011-09-13 01:10:08 --> Model Class Initialized
DEBUG - 2011-09-13 01:10:08 --> Model Class Initialized
DEBUG - 2011-09-13 01:10:08 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-13 01:10:08 --> Database Driver Class Initialized
DEBUG - 2011-09-13 01:10:09 --> File loaded: application/views/table/main.php
DEBUG - 2011-09-13 01:10:09 --> Helper loaded: url_helper
DEBUG - 2011-09-13 01:10:09 --> File loaded: application/views/common/header.php
DEBUG - 2011-09-13 01:10:09 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-09-13 01:10:09 --> File loaded: application/views/common/footer.php
DEBUG - 2011-09-13 01:10:09 --> File loaded: application/views/layout/main.php
DEBUG - 2011-09-13 01:10:09 --> Final output sent to browser
DEBUG - 2011-09-13 01:10:09 --> Total execution time: 0.7055
DEBUG - 2011-09-13 01:10:18 --> Config Class Initialized
DEBUG - 2011-09-13 01:10:18 --> Hooks Class Initialized
DEBUG - 2011-09-13 01:10:18 --> Utf8 Class Initialized
DEBUG - 2011-09-13 01:10:18 --> UTF-8 Support Enabled
DEBUG - 2011-09-13 01:10:18 --> URI Class Initialized
DEBUG - 2011-09-13 01:10:18 --> Router Class Initialized
DEBUG - 2011-09-13 01:10:18 --> Output Class Initialized
DEBUG - 2011-09-13 01:10:18 --> Input Class Initialized
DEBUG - 2011-09-13 01:10:18 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-13 01:10:18 --> Language Class Initialized
DEBUG - 2011-09-13 01:10:18 --> Loader Class Initialized
DEBUG - 2011-09-13 01:10:18 --> Controller Class Initialized
DEBUG - 2011-09-13 01:10:18 --> Model Class Initialized
DEBUG - 2011-09-13 01:10:18 --> Model Class Initialized
DEBUG - 2011-09-13 01:10:18 --> Model Class Initialized
DEBUG - 2011-09-13 01:10:18 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-13 01:10:18 --> Database Driver Class Initialized
DEBUG - 2011-09-13 01:10:18 --> File loaded: application/views/table/main.php
DEBUG - 2011-09-13 01:10:18 --> Helper loaded: url_helper
DEBUG - 2011-09-13 01:10:18 --> File loaded: application/views/common/header.php
DEBUG - 2011-09-13 01:10:18 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-09-13 01:10:18 --> File loaded: application/views/common/footer.php
DEBUG - 2011-09-13 01:10:18 --> File loaded: application/views/layout/main.php
DEBUG - 2011-09-13 01:10:18 --> Final output sent to browser
DEBUG - 2011-09-13 01:10:18 --> Total execution time: 0.2174
DEBUG - 2011-09-13 01:10:21 --> Config Class Initialized
DEBUG - 2011-09-13 01:10:21 --> Hooks Class Initialized
DEBUG - 2011-09-13 01:10:21 --> Utf8 Class Initialized
DEBUG - 2011-09-13 01:10:21 --> UTF-8 Support Enabled
DEBUG - 2011-09-13 01:10:21 --> URI Class Initialized
DEBUG - 2011-09-13 01:10:21 --> Router Class Initialized
DEBUG - 2011-09-13 01:10:21 --> Output Class Initialized
DEBUG - 2011-09-13 01:10:21 --> Input Class Initialized
DEBUG - 2011-09-13 01:10:21 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-13 01:10:21 --> Language Class Initialized
DEBUG - 2011-09-13 01:10:21 --> Loader Class Initialized
DEBUG - 2011-09-13 01:10:21 --> Controller Class Initialized
DEBUG - 2011-09-13 01:10:21 --> Model Class Initialized
DEBUG - 2011-09-13 01:10:21 --> Model Class Initialized
DEBUG - 2011-09-13 01:10:21 --> Model Class Initialized
DEBUG - 2011-09-13 01:10:21 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-13 01:10:21 --> Database Driver Class Initialized
DEBUG - 2011-09-13 01:10:21 --> File loaded: application/views/table/main.php
DEBUG - 2011-09-13 01:10:21 --> Helper loaded: url_helper
DEBUG - 2011-09-13 01:10:21 --> File loaded: application/views/common/header.php
DEBUG - 2011-09-13 01:10:21 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-09-13 01:10:21 --> File loaded: application/views/common/footer.php
DEBUG - 2011-09-13 01:10:21 --> File loaded: application/views/layout/main.php
DEBUG - 2011-09-13 01:10:21 --> Final output sent to browser
DEBUG - 2011-09-13 01:10:21 --> Total execution time: 0.1620
DEBUG - 2011-09-13 01:10:22 --> Config Class Initialized
DEBUG - 2011-09-13 01:10:22 --> Hooks Class Initialized
DEBUG - 2011-09-13 01:10:22 --> Utf8 Class Initialized
DEBUG - 2011-09-13 01:10:22 --> UTF-8 Support Enabled
DEBUG - 2011-09-13 01:10:22 --> URI Class Initialized
DEBUG - 2011-09-13 01:10:22 --> Router Class Initialized
DEBUG - 2011-09-13 01:10:22 --> Output Class Initialized
DEBUG - 2011-09-13 01:10:22 --> Input Class Initialized
DEBUG - 2011-09-13 01:10:22 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-13 01:10:22 --> Language Class Initialized
DEBUG - 2011-09-13 01:10:22 --> Loader Class Initialized
DEBUG - 2011-09-13 01:10:22 --> Controller Class Initialized
DEBUG - 2011-09-13 01:10:22 --> Model Class Initialized
DEBUG - 2011-09-13 01:10:22 --> Model Class Initialized
DEBUG - 2011-09-13 01:10:22 --> Model Class Initialized
DEBUG - 2011-09-13 01:10:22 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-13 01:10:22 --> Database Driver Class Initialized
DEBUG - 2011-09-13 01:10:22 --> File loaded: application/views/table/main.php
DEBUG - 2011-09-13 01:10:22 --> Helper loaded: url_helper
DEBUG - 2011-09-13 01:10:22 --> File loaded: application/views/common/header.php
DEBUG - 2011-09-13 01:10:22 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-09-13 01:10:22 --> File loaded: application/views/common/footer.php
DEBUG - 2011-09-13 01:10:22 --> File loaded: application/views/layout/main.php
DEBUG - 2011-09-13 01:10:22 --> Final output sent to browser
DEBUG - 2011-09-13 01:10:22 --> Total execution time: 0.0500
DEBUG - 2011-09-13 01:10:25 --> Config Class Initialized
DEBUG - 2011-09-13 01:10:25 --> Hooks Class Initialized
DEBUG - 2011-09-13 01:10:25 --> Utf8 Class Initialized
DEBUG - 2011-09-13 01:10:25 --> UTF-8 Support Enabled
DEBUG - 2011-09-13 01:10:25 --> URI Class Initialized
DEBUG - 2011-09-13 01:10:25 --> Router Class Initialized
DEBUG - 2011-09-13 01:10:25 --> Output Class Initialized
DEBUG - 2011-09-13 01:10:25 --> Input Class Initialized
DEBUG - 2011-09-13 01:10:25 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-13 01:10:25 --> Language Class Initialized
DEBUG - 2011-09-13 01:10:25 --> Loader Class Initialized
DEBUG - 2011-09-13 01:10:25 --> Controller Class Initialized
DEBUG - 2011-09-13 01:10:25 --> Model Class Initialized
DEBUG - 2011-09-13 01:10:25 --> Model Class Initialized
DEBUG - 2011-09-13 01:10:25 --> Model Class Initialized
DEBUG - 2011-09-13 01:10:25 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-13 01:10:25 --> Database Driver Class Initialized
DEBUG - 2011-09-13 01:10:25 --> File loaded: application/views/table/main.php
DEBUG - 2011-09-13 01:10:25 --> Helper loaded: url_helper
DEBUG - 2011-09-13 01:10:25 --> File loaded: application/views/common/header.php
DEBUG - 2011-09-13 01:10:25 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-09-13 01:10:25 --> File loaded: application/views/common/footer.php
DEBUG - 2011-09-13 01:10:25 --> File loaded: application/views/layout/main.php
DEBUG - 2011-09-13 01:10:25 --> Final output sent to browser
DEBUG - 2011-09-13 01:10:25 --> Total execution time: 0.0710
DEBUG - 2011-09-13 01:10:28 --> Config Class Initialized
DEBUG - 2011-09-13 01:10:28 --> Hooks Class Initialized
DEBUG - 2011-09-13 01:10:28 --> Utf8 Class Initialized
DEBUG - 2011-09-13 01:10:28 --> UTF-8 Support Enabled
DEBUG - 2011-09-13 01:10:28 --> URI Class Initialized
DEBUG - 2011-09-13 01:10:28 --> Router Class Initialized
DEBUG - 2011-09-13 01:10:28 --> Output Class Initialized
DEBUG - 2011-09-13 01:10:28 --> Input Class Initialized
DEBUG - 2011-09-13 01:10:28 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-13 01:10:28 --> Language Class Initialized
DEBUG - 2011-09-13 01:10:28 --> Loader Class Initialized
DEBUG - 2011-09-13 01:10:28 --> Controller Class Initialized
DEBUG - 2011-09-13 01:10:28 --> Model Class Initialized
DEBUG - 2011-09-13 01:10:28 --> Model Class Initialized
DEBUG - 2011-09-13 01:10:28 --> Model Class Initialized
DEBUG - 2011-09-13 01:10:28 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-13 01:10:28 --> Database Driver Class Initialized
DEBUG - 2011-09-13 01:10:28 --> File loaded: application/views/table/main.php
DEBUG - 2011-09-13 01:10:28 --> Helper loaded: url_helper
DEBUG - 2011-09-13 01:10:28 --> File loaded: application/views/common/header.php
DEBUG - 2011-09-13 01:10:28 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-09-13 01:10:28 --> File loaded: application/views/common/footer.php
DEBUG - 2011-09-13 01:10:28 --> File loaded: application/views/layout/main.php
DEBUG - 2011-09-13 01:10:28 --> Final output sent to browser
DEBUG - 2011-09-13 01:10:28 --> Total execution time: 0.0560
DEBUG - 2011-09-13 01:10:30 --> Config Class Initialized
DEBUG - 2011-09-13 01:10:30 --> Hooks Class Initialized
DEBUG - 2011-09-13 01:10:30 --> Utf8 Class Initialized
DEBUG - 2011-09-13 01:10:30 --> UTF-8 Support Enabled
DEBUG - 2011-09-13 01:10:30 --> URI Class Initialized
DEBUG - 2011-09-13 01:10:30 --> Router Class Initialized
DEBUG - 2011-09-13 01:10:30 --> Output Class Initialized
DEBUG - 2011-09-13 01:10:30 --> Input Class Initialized
DEBUG - 2011-09-13 01:10:30 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-13 01:10:30 --> Language Class Initialized
DEBUG - 2011-09-13 01:10:30 --> Loader Class Initialized
DEBUG - 2011-09-13 01:10:30 --> Controller Class Initialized
DEBUG - 2011-09-13 01:10:30 --> Model Class Initialized
DEBUG - 2011-09-13 01:10:30 --> Model Class Initialized
DEBUG - 2011-09-13 01:10:30 --> Model Class Initialized
DEBUG - 2011-09-13 01:10:30 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-13 01:10:30 --> Database Driver Class Initialized
DEBUG - 2011-09-13 01:10:30 --> File loaded: application/views/table/main.php
DEBUG - 2011-09-13 01:10:30 --> Helper loaded: url_helper
DEBUG - 2011-09-13 01:10:30 --> File loaded: application/views/common/header.php
DEBUG - 2011-09-13 01:10:30 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-09-13 01:10:30 --> File loaded: application/views/common/footer.php
DEBUG - 2011-09-13 01:10:30 --> File loaded: application/views/layout/main.php
DEBUG - 2011-09-13 01:10:30 --> Final output sent to browser
DEBUG - 2011-09-13 01:10:30 --> Total execution time: 0.1490
DEBUG - 2011-09-13 01:10:31 --> Config Class Initialized
DEBUG - 2011-09-13 01:10:31 --> Hooks Class Initialized
DEBUG - 2011-09-13 01:10:31 --> Utf8 Class Initialized
DEBUG - 2011-09-13 01:10:31 --> UTF-8 Support Enabled
DEBUG - 2011-09-13 01:10:31 --> URI Class Initialized
DEBUG - 2011-09-13 01:10:31 --> Router Class Initialized
DEBUG - 2011-09-13 01:10:31 --> Output Class Initialized
DEBUG - 2011-09-13 01:10:31 --> Input Class Initialized
DEBUG - 2011-09-13 01:10:31 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-13 01:10:31 --> Language Class Initialized
DEBUG - 2011-09-13 01:10:31 --> Loader Class Initialized
DEBUG - 2011-09-13 01:10:31 --> Controller Class Initialized
DEBUG - 2011-09-13 01:10:31 --> Model Class Initialized
DEBUG - 2011-09-13 01:10:31 --> Model Class Initialized
DEBUG - 2011-09-13 01:10:31 --> Model Class Initialized
DEBUG - 2011-09-13 01:10:31 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-13 01:10:31 --> Database Driver Class Initialized
DEBUG - 2011-09-13 01:10:31 --> File loaded: application/views/table/main.php
DEBUG - 2011-09-13 01:10:31 --> Helper loaded: url_helper
DEBUG - 2011-09-13 01:10:31 --> File loaded: application/views/common/header.php
DEBUG - 2011-09-13 01:10:31 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-09-13 01:10:31 --> File loaded: application/views/common/footer.php
DEBUG - 2011-09-13 01:10:31 --> File loaded: application/views/layout/main.php
DEBUG - 2011-09-13 01:10:31 --> Final output sent to browser
DEBUG - 2011-09-13 01:10:31 --> Total execution time: 0.3444
DEBUG - 2011-09-13 01:10:36 --> Config Class Initialized
DEBUG - 2011-09-13 01:10:36 --> Hooks Class Initialized
DEBUG - 2011-09-13 01:10:36 --> Utf8 Class Initialized
DEBUG - 2011-09-13 01:10:36 --> UTF-8 Support Enabled
DEBUG - 2011-09-13 01:10:36 --> URI Class Initialized
DEBUG - 2011-09-13 01:10:36 --> Router Class Initialized
DEBUG - 2011-09-13 01:10:36 --> Output Class Initialized
DEBUG - 2011-09-13 01:10:36 --> Input Class Initialized
DEBUG - 2011-09-13 01:10:36 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-13 01:10:36 --> Language Class Initialized
DEBUG - 2011-09-13 01:10:36 --> Loader Class Initialized
DEBUG - 2011-09-13 01:10:36 --> Controller Class Initialized
DEBUG - 2011-09-13 01:10:36 --> Model Class Initialized
DEBUG - 2011-09-13 01:10:36 --> Model Class Initialized
DEBUG - 2011-09-13 01:10:36 --> Model Class Initialized
DEBUG - 2011-09-13 01:10:36 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-13 01:10:36 --> Database Driver Class Initialized
DEBUG - 2011-09-13 01:10:36 --> File loaded: application/views/table/main.php
DEBUG - 2011-09-13 01:10:36 --> Helper loaded: url_helper
DEBUG - 2011-09-13 01:10:36 --> File loaded: application/views/common/header.php
DEBUG - 2011-09-13 01:10:36 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-09-13 01:10:36 --> File loaded: application/views/common/footer.php
DEBUG - 2011-09-13 01:10:36 --> File loaded: application/views/layout/main.php
DEBUG - 2011-09-13 01:10:36 --> Final output sent to browser
DEBUG - 2011-09-13 01:10:36 --> Total execution time: 0.0457
DEBUG - 2011-09-13 01:10:48 --> Config Class Initialized
DEBUG - 2011-09-13 01:10:48 --> Hooks Class Initialized
DEBUG - 2011-09-13 01:10:48 --> Utf8 Class Initialized
DEBUG - 2011-09-13 01:10:48 --> UTF-8 Support Enabled
DEBUG - 2011-09-13 01:10:48 --> URI Class Initialized
DEBUG - 2011-09-13 01:10:48 --> Router Class Initialized
DEBUG - 2011-09-13 01:10:48 --> Output Class Initialized
DEBUG - 2011-09-13 01:10:48 --> Input Class Initialized
DEBUG - 2011-09-13 01:10:48 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-13 01:10:48 --> Language Class Initialized
DEBUG - 2011-09-13 01:10:48 --> Loader Class Initialized
DEBUG - 2011-09-13 01:10:48 --> Controller Class Initialized
DEBUG - 2011-09-13 01:10:48 --> Model Class Initialized
DEBUG - 2011-09-13 01:10:48 --> Model Class Initialized
DEBUG - 2011-09-13 01:10:48 --> Model Class Initialized
DEBUG - 2011-09-13 01:10:48 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-13 01:10:48 --> Database Driver Class Initialized
DEBUG - 2011-09-13 01:10:48 --> File loaded: application/views/table/main.php
DEBUG - 2011-09-13 01:10:48 --> Helper loaded: url_helper
DEBUG - 2011-09-13 01:10:48 --> File loaded: application/views/common/header.php
DEBUG - 2011-09-13 01:10:48 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-09-13 01:10:48 --> File loaded: application/views/common/footer.php
DEBUG - 2011-09-13 01:10:48 --> File loaded: application/views/layout/main.php
DEBUG - 2011-09-13 01:10:48 --> Final output sent to browser
DEBUG - 2011-09-13 01:10:48 --> Total execution time: 0.3589
DEBUG - 2011-09-13 01:10:52 --> Config Class Initialized
DEBUG - 2011-09-13 01:10:52 --> Hooks Class Initialized
DEBUG - 2011-09-13 01:10:52 --> Utf8 Class Initialized
DEBUG - 2011-09-13 01:10:52 --> UTF-8 Support Enabled
DEBUG - 2011-09-13 01:10:52 --> URI Class Initialized
DEBUG - 2011-09-13 01:10:52 --> Router Class Initialized
DEBUG - 2011-09-13 01:10:52 --> Output Class Initialized
DEBUG - 2011-09-13 01:10:52 --> Input Class Initialized
DEBUG - 2011-09-13 01:10:52 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-13 01:10:52 --> Language Class Initialized
DEBUG - 2011-09-13 01:10:52 --> Loader Class Initialized
DEBUG - 2011-09-13 01:10:52 --> Controller Class Initialized
DEBUG - 2011-09-13 01:10:52 --> Model Class Initialized
DEBUG - 2011-09-13 01:10:52 --> Model Class Initialized
DEBUG - 2011-09-13 01:10:52 --> Model Class Initialized
DEBUG - 2011-09-13 01:10:52 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-13 01:10:52 --> Database Driver Class Initialized
DEBUG - 2011-09-13 01:10:52 --> File loaded: application/views/table/main.php
DEBUG - 2011-09-13 01:10:52 --> Helper loaded: url_helper
DEBUG - 2011-09-13 01:10:52 --> File loaded: application/views/common/header.php
DEBUG - 2011-09-13 01:10:52 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-09-13 01:10:52 --> File loaded: application/views/common/footer.php
DEBUG - 2011-09-13 01:10:52 --> File loaded: application/views/layout/main.php
DEBUG - 2011-09-13 01:10:52 --> Final output sent to browser
DEBUG - 2011-09-13 01:10:52 --> Total execution time: 0.0465
DEBUG - 2011-09-13 01:10:58 --> Config Class Initialized
DEBUG - 2011-09-13 01:10:58 --> Hooks Class Initialized
DEBUG - 2011-09-13 01:10:58 --> Utf8 Class Initialized
DEBUG - 2011-09-13 01:10:58 --> UTF-8 Support Enabled
DEBUG - 2011-09-13 01:10:58 --> URI Class Initialized
DEBUG - 2011-09-13 01:10:58 --> Router Class Initialized
DEBUG - 2011-09-13 01:10:58 --> Output Class Initialized
DEBUG - 2011-09-13 01:10:58 --> Input Class Initialized
DEBUG - 2011-09-13 01:10:58 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-13 01:10:58 --> Language Class Initialized
DEBUG - 2011-09-13 01:10:58 --> Loader Class Initialized
DEBUG - 2011-09-13 01:10:58 --> Controller Class Initialized
DEBUG - 2011-09-13 01:10:58 --> Model Class Initialized
DEBUG - 2011-09-13 01:10:58 --> Model Class Initialized
DEBUG - 2011-09-13 01:10:58 --> Model Class Initialized
DEBUG - 2011-09-13 01:10:58 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-13 01:10:58 --> Database Driver Class Initialized
DEBUG - 2011-09-13 01:10:59 --> File loaded: application/views/table/main.php
DEBUG - 2011-09-13 01:10:59 --> Helper loaded: url_helper
DEBUG - 2011-09-13 01:10:59 --> File loaded: application/views/common/header.php
DEBUG - 2011-09-13 01:10:59 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-09-13 01:10:59 --> File loaded: application/views/common/footer.php
DEBUG - 2011-09-13 01:10:59 --> File loaded: application/views/layout/main.php
DEBUG - 2011-09-13 01:10:59 --> Final output sent to browser
DEBUG - 2011-09-13 01:10:59 --> Total execution time: 0.5671
DEBUG - 2011-09-13 01:11:01 --> Config Class Initialized
DEBUG - 2011-09-13 01:11:01 --> Hooks Class Initialized
DEBUG - 2011-09-13 01:11:01 --> Utf8 Class Initialized
DEBUG - 2011-09-13 01:11:01 --> UTF-8 Support Enabled
DEBUG - 2011-09-13 01:11:01 --> URI Class Initialized
DEBUG - 2011-09-13 01:11:01 --> Router Class Initialized
DEBUG - 2011-09-13 01:11:01 --> Output Class Initialized
DEBUG - 2011-09-13 01:11:01 --> Input Class Initialized
DEBUG - 2011-09-13 01:11:01 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-13 01:11:01 --> Language Class Initialized
DEBUG - 2011-09-13 01:11:01 --> Loader Class Initialized
DEBUG - 2011-09-13 01:11:01 --> Controller Class Initialized
DEBUG - 2011-09-13 01:11:01 --> Model Class Initialized
DEBUG - 2011-09-13 01:11:01 --> Model Class Initialized
DEBUG - 2011-09-13 01:11:01 --> Model Class Initialized
DEBUG - 2011-09-13 01:11:01 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-13 01:11:01 --> Database Driver Class Initialized
DEBUG - 2011-09-13 01:11:01 --> File loaded: application/views/table/main.php
DEBUG - 2011-09-13 01:11:01 --> Helper loaded: url_helper
DEBUG - 2011-09-13 01:11:01 --> File loaded: application/views/common/header.php
DEBUG - 2011-09-13 01:11:01 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-09-13 01:11:01 --> File loaded: application/views/common/footer.php
DEBUG - 2011-09-13 01:11:01 --> File loaded: application/views/layout/main.php
DEBUG - 2011-09-13 01:11:01 --> Final output sent to browser
DEBUG - 2011-09-13 01:11:01 --> Total execution time: 0.2399
DEBUG - 2011-09-13 01:11:08 --> Config Class Initialized
DEBUG - 2011-09-13 01:11:08 --> Hooks Class Initialized
DEBUG - 2011-09-13 01:11:08 --> Utf8 Class Initialized
DEBUG - 2011-09-13 01:11:08 --> UTF-8 Support Enabled
DEBUG - 2011-09-13 01:11:08 --> URI Class Initialized
DEBUG - 2011-09-13 01:11:08 --> Router Class Initialized
DEBUG - 2011-09-13 01:11:08 --> Output Class Initialized
DEBUG - 2011-09-13 01:11:08 --> Input Class Initialized
DEBUG - 2011-09-13 01:11:08 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-13 01:11:08 --> Language Class Initialized
DEBUG - 2011-09-13 01:11:08 --> Loader Class Initialized
DEBUG - 2011-09-13 01:11:08 --> Controller Class Initialized
DEBUG - 2011-09-13 01:11:08 --> Model Class Initialized
DEBUG - 2011-09-13 01:11:08 --> Model Class Initialized
DEBUG - 2011-09-13 01:11:08 --> Model Class Initialized
DEBUG - 2011-09-13 01:11:08 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-13 01:11:08 --> Database Driver Class Initialized
DEBUG - 2011-09-13 01:11:09 --> File loaded: application/views/table/main.php
DEBUG - 2011-09-13 01:11:09 --> Helper loaded: url_helper
DEBUG - 2011-09-13 01:11:09 --> File loaded: application/views/common/header.php
DEBUG - 2011-09-13 01:11:09 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-09-13 01:11:09 --> File loaded: application/views/common/footer.php
DEBUG - 2011-09-13 01:11:09 --> File loaded: application/views/layout/main.php
DEBUG - 2011-09-13 01:11:09 --> Final output sent to browser
DEBUG - 2011-09-13 01:11:09 --> Total execution time: 0.4062
DEBUG - 2011-09-13 01:11:18 --> Config Class Initialized
DEBUG - 2011-09-13 01:11:18 --> Hooks Class Initialized
DEBUG - 2011-09-13 01:11:18 --> Utf8 Class Initialized
DEBUG - 2011-09-13 01:11:18 --> UTF-8 Support Enabled
DEBUG - 2011-09-13 01:11:18 --> URI Class Initialized
DEBUG - 2011-09-13 01:11:18 --> Router Class Initialized
DEBUG - 2011-09-13 01:11:18 --> Output Class Initialized
DEBUG - 2011-09-13 01:11:18 --> Input Class Initialized
DEBUG - 2011-09-13 01:11:18 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-13 01:11:18 --> Language Class Initialized
DEBUG - 2011-09-13 01:11:18 --> Loader Class Initialized
DEBUG - 2011-09-13 01:11:18 --> Controller Class Initialized
DEBUG - 2011-09-13 01:11:18 --> Model Class Initialized
DEBUG - 2011-09-13 01:11:18 --> Model Class Initialized
DEBUG - 2011-09-13 01:11:18 --> Model Class Initialized
DEBUG - 2011-09-13 01:11:18 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-13 01:11:18 --> Database Driver Class Initialized
DEBUG - 2011-09-13 01:11:18 --> File loaded: application/views/table/main.php
DEBUG - 2011-09-13 01:11:18 --> Helper loaded: url_helper
DEBUG - 2011-09-13 01:11:18 --> File loaded: application/views/common/header.php
DEBUG - 2011-09-13 01:11:18 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-09-13 01:11:18 --> File loaded: application/views/common/footer.php
DEBUG - 2011-09-13 01:11:18 --> File loaded: application/views/layout/main.php
DEBUG - 2011-09-13 01:11:18 --> Final output sent to browser
DEBUG - 2011-09-13 01:11:18 --> Total execution time: 0.1186
DEBUG - 2011-09-13 01:11:20 --> Config Class Initialized
DEBUG - 2011-09-13 01:11:20 --> Hooks Class Initialized
DEBUG - 2011-09-13 01:11:20 --> Utf8 Class Initialized
DEBUG - 2011-09-13 01:11:20 --> UTF-8 Support Enabled
DEBUG - 2011-09-13 01:11:20 --> URI Class Initialized
DEBUG - 2011-09-13 01:11:20 --> Router Class Initialized
DEBUG - 2011-09-13 01:11:20 --> Output Class Initialized
DEBUG - 2011-09-13 01:11:20 --> Input Class Initialized
DEBUG - 2011-09-13 01:11:20 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-13 01:11:20 --> Language Class Initialized
DEBUG - 2011-09-13 01:11:20 --> Loader Class Initialized
DEBUG - 2011-09-13 01:11:20 --> Controller Class Initialized
DEBUG - 2011-09-13 01:11:20 --> Model Class Initialized
DEBUG - 2011-09-13 01:11:20 --> Model Class Initialized
DEBUG - 2011-09-13 01:11:20 --> Model Class Initialized
DEBUG - 2011-09-13 01:11:20 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-13 01:11:20 --> Database Driver Class Initialized
DEBUG - 2011-09-13 01:11:20 --> File loaded: application/views/table/main.php
DEBUG - 2011-09-13 01:11:20 --> Helper loaded: url_helper
DEBUG - 2011-09-13 01:11:20 --> File loaded: application/views/common/header.php
DEBUG - 2011-09-13 01:11:20 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-09-13 01:11:20 --> File loaded: application/views/common/footer.php
DEBUG - 2011-09-13 01:11:20 --> File loaded: application/views/layout/main.php
DEBUG - 2011-09-13 01:11:20 --> Final output sent to browser
DEBUG - 2011-09-13 01:11:20 --> Total execution time: 0.3015
DEBUG - 2011-09-13 01:11:22 --> Config Class Initialized
DEBUG - 2011-09-13 01:11:22 --> Hooks Class Initialized
DEBUG - 2011-09-13 01:11:22 --> Utf8 Class Initialized
DEBUG - 2011-09-13 01:11:22 --> UTF-8 Support Enabled
DEBUG - 2011-09-13 01:11:22 --> URI Class Initialized
DEBUG - 2011-09-13 01:11:22 --> Router Class Initialized
DEBUG - 2011-09-13 01:11:22 --> Output Class Initialized
DEBUG - 2011-09-13 01:11:22 --> Input Class Initialized
DEBUG - 2011-09-13 01:11:22 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-13 01:11:22 --> Language Class Initialized
DEBUG - 2011-09-13 01:11:22 --> Loader Class Initialized
DEBUG - 2011-09-13 01:11:22 --> Controller Class Initialized
DEBUG - 2011-09-13 01:11:22 --> Model Class Initialized
DEBUG - 2011-09-13 01:11:22 --> Model Class Initialized
DEBUG - 2011-09-13 01:11:22 --> Model Class Initialized
DEBUG - 2011-09-13 01:11:22 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-13 01:11:22 --> Database Driver Class Initialized
DEBUG - 2011-09-13 01:11:22 --> File loaded: application/views/table/main.php
DEBUG - 2011-09-13 01:11:22 --> Helper loaded: url_helper
DEBUG - 2011-09-13 01:11:22 --> File loaded: application/views/common/header.php
DEBUG - 2011-09-13 01:11:22 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-09-13 01:11:22 --> File loaded: application/views/common/footer.php
DEBUG - 2011-09-13 01:11:22 --> File loaded: application/views/layout/main.php
DEBUG - 2011-09-13 01:11:22 --> Final output sent to browser
DEBUG - 2011-09-13 01:11:22 --> Total execution time: 0.0841
DEBUG - 2011-09-13 01:11:34 --> Config Class Initialized
DEBUG - 2011-09-13 01:11:34 --> Hooks Class Initialized
DEBUG - 2011-09-13 01:11:34 --> Utf8 Class Initialized
DEBUG - 2011-09-13 01:11:34 --> UTF-8 Support Enabled
DEBUG - 2011-09-13 01:11:34 --> URI Class Initialized
DEBUG - 2011-09-13 01:11:34 --> Router Class Initialized
DEBUG - 2011-09-13 01:11:34 --> Output Class Initialized
DEBUG - 2011-09-13 01:11:34 --> Input Class Initialized
DEBUG - 2011-09-13 01:11:34 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-13 01:11:34 --> Language Class Initialized
DEBUG - 2011-09-13 01:11:34 --> Loader Class Initialized
DEBUG - 2011-09-13 01:11:34 --> Controller Class Initialized
DEBUG - 2011-09-13 01:11:34 --> Model Class Initialized
DEBUG - 2011-09-13 01:11:34 --> Model Class Initialized
DEBUG - 2011-09-13 01:11:34 --> Model Class Initialized
DEBUG - 2011-09-13 01:11:34 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-13 01:11:34 --> Database Driver Class Initialized
DEBUG - 2011-09-13 01:11:34 --> File loaded: application/views/table/main.php
DEBUG - 2011-09-13 01:11:34 --> Helper loaded: url_helper
DEBUG - 2011-09-13 01:11:34 --> File loaded: application/views/common/header.php
DEBUG - 2011-09-13 01:11:34 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-09-13 01:11:34 --> File loaded: application/views/common/footer.php
DEBUG - 2011-09-13 01:11:34 --> File loaded: application/views/layout/main.php
DEBUG - 2011-09-13 01:11:34 --> Final output sent to browser
DEBUG - 2011-09-13 01:11:34 --> Total execution time: 0.2526
DEBUG - 2011-09-13 01:11:35 --> Config Class Initialized
DEBUG - 2011-09-13 01:11:35 --> Hooks Class Initialized
DEBUG - 2011-09-13 01:11:35 --> Utf8 Class Initialized
DEBUG - 2011-09-13 01:11:35 --> UTF-8 Support Enabled
DEBUG - 2011-09-13 01:11:35 --> URI Class Initialized
DEBUG - 2011-09-13 01:11:35 --> Router Class Initialized
DEBUG - 2011-09-13 01:11:35 --> Output Class Initialized
DEBUG - 2011-09-13 01:11:35 --> Input Class Initialized
DEBUG - 2011-09-13 01:11:35 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-13 01:11:35 --> Language Class Initialized
DEBUG - 2011-09-13 01:11:35 --> Loader Class Initialized
DEBUG - 2011-09-13 01:11:35 --> Controller Class Initialized
DEBUG - 2011-09-13 01:11:35 --> Model Class Initialized
DEBUG - 2011-09-13 01:11:35 --> Model Class Initialized
DEBUG - 2011-09-13 01:11:35 --> Model Class Initialized
DEBUG - 2011-09-13 01:11:35 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-13 01:11:35 --> Database Driver Class Initialized
DEBUG - 2011-09-13 01:11:36 --> File loaded: application/views/table/main.php
DEBUG - 2011-09-13 01:11:36 --> Helper loaded: url_helper
DEBUG - 2011-09-13 01:11:36 --> File loaded: application/views/common/header.php
DEBUG - 2011-09-13 01:11:36 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-09-13 01:11:36 --> File loaded: application/views/common/footer.php
DEBUG - 2011-09-13 01:11:36 --> File loaded: application/views/layout/main.php
DEBUG - 2011-09-13 01:11:36 --> Final output sent to browser
DEBUG - 2011-09-13 01:11:36 --> Total execution time: 0.0429
DEBUG - 2011-09-13 01:11:43 --> Config Class Initialized
DEBUG - 2011-09-13 01:11:43 --> Hooks Class Initialized
DEBUG - 2011-09-13 01:11:43 --> Utf8 Class Initialized
DEBUG - 2011-09-13 01:11:43 --> UTF-8 Support Enabled
DEBUG - 2011-09-13 01:11:43 --> URI Class Initialized
DEBUG - 2011-09-13 01:11:43 --> Router Class Initialized
DEBUG - 2011-09-13 01:11:43 --> Output Class Initialized
DEBUG - 2011-09-13 01:11:43 --> Input Class Initialized
DEBUG - 2011-09-13 01:11:43 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-13 01:11:43 --> Language Class Initialized
DEBUG - 2011-09-13 01:11:43 --> Loader Class Initialized
DEBUG - 2011-09-13 01:11:43 --> Controller Class Initialized
DEBUG - 2011-09-13 01:11:43 --> Model Class Initialized
DEBUG - 2011-09-13 01:11:43 --> Model Class Initialized
DEBUG - 2011-09-13 01:11:43 --> Model Class Initialized
DEBUG - 2011-09-13 01:11:43 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-13 01:11:43 --> Database Driver Class Initialized
DEBUG - 2011-09-13 01:11:44 --> File loaded: application/views/table/main.php
DEBUG - 2011-09-13 01:11:44 --> Helper loaded: url_helper
DEBUG - 2011-09-13 01:11:44 --> File loaded: application/views/common/header.php
DEBUG - 2011-09-13 01:11:44 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-09-13 01:11:44 --> File loaded: application/views/common/footer.php
DEBUG - 2011-09-13 01:11:44 --> File loaded: application/views/layout/main.php
DEBUG - 2011-09-13 01:11:44 --> Final output sent to browser
DEBUG - 2011-09-13 01:11:44 --> Total execution time: 0.2351
DEBUG - 2011-09-13 01:11:46 --> Config Class Initialized
DEBUG - 2011-09-13 01:11:46 --> Hooks Class Initialized
DEBUG - 2011-09-13 01:11:46 --> Utf8 Class Initialized
DEBUG - 2011-09-13 01:11:46 --> UTF-8 Support Enabled
DEBUG - 2011-09-13 01:11:46 --> URI Class Initialized
DEBUG - 2011-09-13 01:11:46 --> Router Class Initialized
DEBUG - 2011-09-13 01:11:46 --> Output Class Initialized
DEBUG - 2011-09-13 01:11:46 --> Input Class Initialized
DEBUG - 2011-09-13 01:11:46 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-13 01:11:46 --> Language Class Initialized
DEBUG - 2011-09-13 01:11:46 --> Loader Class Initialized
DEBUG - 2011-09-13 01:11:46 --> Controller Class Initialized
DEBUG - 2011-09-13 01:11:46 --> Model Class Initialized
DEBUG - 2011-09-13 01:11:46 --> Model Class Initialized
DEBUG - 2011-09-13 01:11:46 --> Model Class Initialized
DEBUG - 2011-09-13 01:11:46 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-13 01:11:46 --> Database Driver Class Initialized
DEBUG - 2011-09-13 01:11:46 --> File loaded: application/views/table/main.php
DEBUG - 2011-09-13 01:11:46 --> Helper loaded: url_helper
DEBUG - 2011-09-13 01:11:46 --> File loaded: application/views/common/header.php
DEBUG - 2011-09-13 01:11:46 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-09-13 01:11:46 --> File loaded: application/views/common/footer.php
DEBUG - 2011-09-13 01:11:46 --> File loaded: application/views/layout/main.php
DEBUG - 2011-09-13 01:11:46 --> Final output sent to browser
DEBUG - 2011-09-13 01:11:46 --> Total execution time: 0.0474
DEBUG - 2011-09-13 01:12:11 --> Config Class Initialized
DEBUG - 2011-09-13 01:12:11 --> Hooks Class Initialized
DEBUG - 2011-09-13 01:12:11 --> Utf8 Class Initialized
DEBUG - 2011-09-13 01:12:11 --> UTF-8 Support Enabled
DEBUG - 2011-09-13 01:12:11 --> URI Class Initialized
DEBUG - 2011-09-13 01:12:11 --> Router Class Initialized
DEBUG - 2011-09-13 01:12:11 --> Output Class Initialized
DEBUG - 2011-09-13 01:12:11 --> Input Class Initialized
DEBUG - 2011-09-13 01:12:11 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-13 01:12:11 --> Language Class Initialized
DEBUG - 2011-09-13 01:12:11 --> Loader Class Initialized
DEBUG - 2011-09-13 01:12:11 --> Controller Class Initialized
DEBUG - 2011-09-13 01:12:11 --> Model Class Initialized
DEBUG - 2011-09-13 01:12:11 --> Model Class Initialized
DEBUG - 2011-09-13 01:12:11 --> Model Class Initialized
DEBUG - 2011-09-13 01:12:11 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-13 01:12:11 --> Database Driver Class Initialized
DEBUG - 2011-09-13 01:12:11 --> File loaded: application/views/table/main.php
DEBUG - 2011-09-13 01:12:11 --> Helper loaded: url_helper
DEBUG - 2011-09-13 01:12:11 --> File loaded: application/views/common/header.php
DEBUG - 2011-09-13 01:12:11 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-09-13 01:12:11 --> File loaded: application/views/common/footer.php
DEBUG - 2011-09-13 01:12:11 --> File loaded: application/views/layout/main.php
DEBUG - 2011-09-13 01:12:11 --> Final output sent to browser
DEBUG - 2011-09-13 01:12:11 --> Total execution time: 0.4350
DEBUG - 2011-09-13 01:12:14 --> Config Class Initialized
DEBUG - 2011-09-13 01:12:14 --> Hooks Class Initialized
DEBUG - 2011-09-13 01:12:14 --> Utf8 Class Initialized
DEBUG - 2011-09-13 01:12:14 --> UTF-8 Support Enabled
DEBUG - 2011-09-13 01:12:14 --> URI Class Initialized
DEBUG - 2011-09-13 01:12:14 --> Router Class Initialized
DEBUG - 2011-09-13 01:12:14 --> Output Class Initialized
DEBUG - 2011-09-13 01:12:14 --> Input Class Initialized
DEBUG - 2011-09-13 01:12:14 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-13 01:12:14 --> Language Class Initialized
DEBUG - 2011-09-13 01:12:14 --> Loader Class Initialized
DEBUG - 2011-09-13 01:12:14 --> Controller Class Initialized
DEBUG - 2011-09-13 01:12:14 --> Model Class Initialized
DEBUG - 2011-09-13 01:12:14 --> Model Class Initialized
DEBUG - 2011-09-13 01:12:14 --> Model Class Initialized
DEBUG - 2011-09-13 01:12:14 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-13 01:12:14 --> Database Driver Class Initialized
DEBUG - 2011-09-13 01:12:14 --> File loaded: application/views/table/main.php
DEBUG - 2011-09-13 01:12:14 --> Helper loaded: url_helper
DEBUG - 2011-09-13 01:12:14 --> File loaded: application/views/common/header.php
DEBUG - 2011-09-13 01:12:14 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-09-13 01:12:14 --> File loaded: application/views/common/footer.php
DEBUG - 2011-09-13 01:12:14 --> File loaded: application/views/layout/main.php
DEBUG - 2011-09-13 01:12:14 --> Final output sent to browser
DEBUG - 2011-09-13 01:12:14 --> Total execution time: 0.0421
DEBUG - 2011-09-13 01:12:34 --> Config Class Initialized
DEBUG - 2011-09-13 01:12:34 --> Hooks Class Initialized
DEBUG - 2011-09-13 01:12:34 --> Utf8 Class Initialized
DEBUG - 2011-09-13 01:12:34 --> UTF-8 Support Enabled
DEBUG - 2011-09-13 01:12:34 --> URI Class Initialized
DEBUG - 2011-09-13 01:12:34 --> Router Class Initialized
DEBUG - 2011-09-13 01:12:34 --> Output Class Initialized
DEBUG - 2011-09-13 01:12:34 --> Input Class Initialized
DEBUG - 2011-09-13 01:12:34 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-13 01:12:34 --> Language Class Initialized
DEBUG - 2011-09-13 01:12:34 --> Loader Class Initialized
DEBUG - 2011-09-13 01:12:34 --> Controller Class Initialized
DEBUG - 2011-09-13 01:12:34 --> Model Class Initialized
DEBUG - 2011-09-13 01:12:34 --> Model Class Initialized
DEBUG - 2011-09-13 01:12:34 --> Model Class Initialized
DEBUG - 2011-09-13 01:12:34 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-13 01:12:34 --> Database Driver Class Initialized
DEBUG - 2011-09-13 01:12:34 --> File loaded: application/views/table/main.php
DEBUG - 2011-09-13 01:12:34 --> Helper loaded: url_helper
DEBUG - 2011-09-13 01:12:34 --> File loaded: application/views/common/header.php
DEBUG - 2011-09-13 01:12:34 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-09-13 01:12:34 --> File loaded: application/views/common/footer.php
DEBUG - 2011-09-13 01:12:34 --> File loaded: application/views/layout/main.php
DEBUG - 2011-09-13 01:12:34 --> Final output sent to browser
DEBUG - 2011-09-13 01:12:34 --> Total execution time: 0.0684
DEBUG - 2011-09-13 01:12:50 --> Config Class Initialized
DEBUG - 2011-09-13 01:12:50 --> Hooks Class Initialized
DEBUG - 2011-09-13 01:12:50 --> Utf8 Class Initialized
DEBUG - 2011-09-13 01:12:50 --> UTF-8 Support Enabled
DEBUG - 2011-09-13 01:12:50 --> URI Class Initialized
DEBUG - 2011-09-13 01:12:50 --> Router Class Initialized
DEBUG - 2011-09-13 01:12:50 --> Output Class Initialized
DEBUG - 2011-09-13 01:12:50 --> Input Class Initialized
DEBUG - 2011-09-13 01:12:50 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-13 01:12:50 --> Language Class Initialized
DEBUG - 2011-09-13 01:12:51 --> Loader Class Initialized
DEBUG - 2011-09-13 01:12:51 --> Controller Class Initialized
DEBUG - 2011-09-13 01:12:51 --> Model Class Initialized
DEBUG - 2011-09-13 01:12:51 --> Model Class Initialized
DEBUG - 2011-09-13 01:12:51 --> Model Class Initialized
DEBUG - 2011-09-13 01:12:51 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-13 01:12:51 --> Database Driver Class Initialized
DEBUG - 2011-09-13 01:12:51 --> File loaded: application/views/table/main.php
DEBUG - 2011-09-13 01:12:51 --> Helper loaded: url_helper
DEBUG - 2011-09-13 01:12:51 --> File loaded: application/views/common/header.php
DEBUG - 2011-09-13 01:12:51 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-09-13 01:12:51 --> File loaded: application/views/common/footer.php
DEBUG - 2011-09-13 01:12:51 --> File loaded: application/views/layout/main.php
DEBUG - 2011-09-13 01:12:51 --> Final output sent to browser
DEBUG - 2011-09-13 01:12:51 --> Total execution time: 0.9588
DEBUG - 2011-09-13 01:12:53 --> Config Class Initialized
DEBUG - 2011-09-13 01:12:53 --> Hooks Class Initialized
DEBUG - 2011-09-13 01:12:53 --> Utf8 Class Initialized
DEBUG - 2011-09-13 01:12:53 --> UTF-8 Support Enabled
DEBUG - 2011-09-13 01:12:53 --> URI Class Initialized
DEBUG - 2011-09-13 01:12:53 --> Router Class Initialized
DEBUG - 2011-09-13 01:12:53 --> Output Class Initialized
DEBUG - 2011-09-13 01:12:53 --> Input Class Initialized
DEBUG - 2011-09-13 01:12:53 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-13 01:12:53 --> Language Class Initialized
DEBUG - 2011-09-13 01:12:53 --> Loader Class Initialized
DEBUG - 2011-09-13 01:12:53 --> Controller Class Initialized
DEBUG - 2011-09-13 01:12:53 --> Model Class Initialized
DEBUG - 2011-09-13 01:12:53 --> Model Class Initialized
DEBUG - 2011-09-13 01:12:53 --> Model Class Initialized
DEBUG - 2011-09-13 01:12:53 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-13 01:12:53 --> Database Driver Class Initialized
DEBUG - 2011-09-13 01:12:53 --> File loaded: application/views/table/main.php
DEBUG - 2011-09-13 01:12:53 --> Helper loaded: url_helper
DEBUG - 2011-09-13 01:12:53 --> File loaded: application/views/common/header.php
DEBUG - 2011-09-13 01:12:53 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-09-13 01:12:53 --> File loaded: application/views/common/footer.php
DEBUG - 2011-09-13 01:12:53 --> File loaded: application/views/layout/main.php
DEBUG - 2011-09-13 01:12:53 --> Final output sent to browser
DEBUG - 2011-09-13 01:12:53 --> Total execution time: 0.0780
DEBUG - 2011-09-13 01:13:12 --> Config Class Initialized
DEBUG - 2011-09-13 01:13:12 --> Hooks Class Initialized
DEBUG - 2011-09-13 01:13:12 --> Utf8 Class Initialized
DEBUG - 2011-09-13 01:13:12 --> UTF-8 Support Enabled
DEBUG - 2011-09-13 01:13:12 --> URI Class Initialized
DEBUG - 2011-09-13 01:13:12 --> Router Class Initialized
DEBUG - 2011-09-13 01:13:12 --> Output Class Initialized
DEBUG - 2011-09-13 01:13:12 --> Input Class Initialized
DEBUG - 2011-09-13 01:13:12 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-13 01:13:12 --> Language Class Initialized
DEBUG - 2011-09-13 01:13:12 --> Loader Class Initialized
DEBUG - 2011-09-13 01:13:12 --> Controller Class Initialized
DEBUG - 2011-09-13 01:13:12 --> Model Class Initialized
DEBUG - 2011-09-13 01:13:12 --> Model Class Initialized
DEBUG - 2011-09-13 01:13:12 --> Model Class Initialized
DEBUG - 2011-09-13 01:13:12 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-13 01:13:12 --> Database Driver Class Initialized
DEBUG - 2011-09-13 01:13:12 --> File loaded: application/views/table/main.php
DEBUG - 2011-09-13 01:13:12 --> Helper loaded: url_helper
DEBUG - 2011-09-13 01:13:12 --> File loaded: application/views/common/header.php
DEBUG - 2011-09-13 01:13:12 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-09-13 01:13:12 --> File loaded: application/views/common/footer.php
DEBUG - 2011-09-13 01:13:12 --> File loaded: application/views/layout/main.php
DEBUG - 2011-09-13 01:13:12 --> Final output sent to browser
DEBUG - 2011-09-13 01:13:12 --> Total execution time: 0.2600
DEBUG - 2011-09-13 01:13:16 --> Config Class Initialized
DEBUG - 2011-09-13 01:13:16 --> Hooks Class Initialized
DEBUG - 2011-09-13 01:13:16 --> Utf8 Class Initialized
DEBUG - 2011-09-13 01:13:16 --> UTF-8 Support Enabled
DEBUG - 2011-09-13 01:13:16 --> URI Class Initialized
DEBUG - 2011-09-13 01:13:16 --> Router Class Initialized
DEBUG - 2011-09-13 01:13:16 --> Output Class Initialized
DEBUG - 2011-09-13 01:13:16 --> Input Class Initialized
DEBUG - 2011-09-13 01:13:16 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-13 01:13:16 --> Language Class Initialized
DEBUG - 2011-09-13 01:13:16 --> Loader Class Initialized
DEBUG - 2011-09-13 01:13:16 --> Controller Class Initialized
DEBUG - 2011-09-13 01:13:16 --> Model Class Initialized
DEBUG - 2011-09-13 01:13:16 --> Model Class Initialized
DEBUG - 2011-09-13 01:13:16 --> Model Class Initialized
DEBUG - 2011-09-13 01:13:16 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-13 01:13:16 --> Database Driver Class Initialized
DEBUG - 2011-09-13 01:13:16 --> File loaded: application/views/table/main.php
DEBUG - 2011-09-13 01:13:16 --> Helper loaded: url_helper
DEBUG - 2011-09-13 01:13:16 --> File loaded: application/views/common/header.php
DEBUG - 2011-09-13 01:13:16 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-09-13 01:13:16 --> File loaded: application/views/common/footer.php
DEBUG - 2011-09-13 01:13:16 --> File loaded: application/views/layout/main.php
DEBUG - 2011-09-13 01:13:16 --> Final output sent to browser
DEBUG - 2011-09-13 01:13:16 --> Total execution time: 0.0460
DEBUG - 2011-09-13 01:13:37 --> Config Class Initialized
DEBUG - 2011-09-13 01:13:37 --> Hooks Class Initialized
DEBUG - 2011-09-13 01:13:37 --> Utf8 Class Initialized
DEBUG - 2011-09-13 01:13:37 --> UTF-8 Support Enabled
DEBUG - 2011-09-13 01:13:37 --> URI Class Initialized
DEBUG - 2011-09-13 01:13:37 --> Router Class Initialized
DEBUG - 2011-09-13 01:13:37 --> Output Class Initialized
DEBUG - 2011-09-13 01:13:37 --> Input Class Initialized
DEBUG - 2011-09-13 01:13:37 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-13 01:13:37 --> Language Class Initialized
DEBUG - 2011-09-13 01:13:37 --> Loader Class Initialized
DEBUG - 2011-09-13 01:13:37 --> Controller Class Initialized
DEBUG - 2011-09-13 01:13:37 --> Model Class Initialized
DEBUG - 2011-09-13 01:13:37 --> Model Class Initialized
DEBUG - 2011-09-13 01:13:37 --> Model Class Initialized
DEBUG - 2011-09-13 01:13:37 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-13 01:13:37 --> Database Driver Class Initialized
DEBUG - 2011-09-13 01:13:37 --> File loaded: application/views/table/main.php
DEBUG - 2011-09-13 01:13:37 --> Helper loaded: url_helper
DEBUG - 2011-09-13 01:13:37 --> File loaded: application/views/common/header.php
DEBUG - 2011-09-13 01:13:37 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-09-13 01:13:37 --> File loaded: application/views/common/footer.php
DEBUG - 2011-09-13 01:13:37 --> File loaded: application/views/layout/main.php
DEBUG - 2011-09-13 01:13:37 --> Final output sent to browser
DEBUG - 2011-09-13 01:13:37 --> Total execution time: 0.2118
DEBUG - 2011-09-13 01:13:40 --> Config Class Initialized
DEBUG - 2011-09-13 01:13:40 --> Hooks Class Initialized
DEBUG - 2011-09-13 01:13:40 --> Utf8 Class Initialized
DEBUG - 2011-09-13 01:13:40 --> UTF-8 Support Enabled
DEBUG - 2011-09-13 01:13:40 --> URI Class Initialized
DEBUG - 2011-09-13 01:13:40 --> Router Class Initialized
DEBUG - 2011-09-13 01:13:40 --> Output Class Initialized
DEBUG - 2011-09-13 01:13:40 --> Input Class Initialized
DEBUG - 2011-09-13 01:13:40 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-13 01:13:40 --> Language Class Initialized
DEBUG - 2011-09-13 01:13:40 --> Loader Class Initialized
DEBUG - 2011-09-13 01:13:40 --> Controller Class Initialized
DEBUG - 2011-09-13 01:13:40 --> Model Class Initialized
DEBUG - 2011-09-13 01:13:40 --> Model Class Initialized
DEBUG - 2011-09-13 01:13:40 --> Model Class Initialized
DEBUG - 2011-09-13 01:13:40 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-13 01:13:40 --> Database Driver Class Initialized
DEBUG - 2011-09-13 01:13:40 --> File loaded: application/views/table/main.php
DEBUG - 2011-09-13 01:13:40 --> Helper loaded: url_helper
DEBUG - 2011-09-13 01:13:40 --> File loaded: application/views/common/header.php
DEBUG - 2011-09-13 01:13:40 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-09-13 01:13:40 --> File loaded: application/views/common/footer.php
DEBUG - 2011-09-13 01:13:40 --> File loaded: application/views/layout/main.php
DEBUG - 2011-09-13 01:13:40 --> Final output sent to browser
DEBUG - 2011-09-13 01:13:40 --> Total execution time: 0.0451
DEBUG - 2011-09-13 01:23:44 --> Config Class Initialized
DEBUG - 2011-09-13 01:23:44 --> Hooks Class Initialized
DEBUG - 2011-09-13 01:23:44 --> Utf8 Class Initialized
DEBUG - 2011-09-13 01:23:44 --> UTF-8 Support Enabled
DEBUG - 2011-09-13 01:23:44 --> URI Class Initialized
DEBUG - 2011-09-13 01:23:44 --> Router Class Initialized
DEBUG - 2011-09-13 01:23:44 --> Output Class Initialized
DEBUG - 2011-09-13 01:23:44 --> Input Class Initialized
DEBUG - 2011-09-13 01:23:44 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-13 01:23:44 --> Language Class Initialized
DEBUG - 2011-09-13 01:23:44 --> Loader Class Initialized
DEBUG - 2011-09-13 01:23:44 --> Controller Class Initialized
ERROR - 2011-09-13 01:23:44 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-09-13 01:23:44 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-09-13 01:23:44 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-09-13 01:23:44 --> Model Class Initialized
DEBUG - 2011-09-13 01:23:44 --> Model Class Initialized
DEBUG - 2011-09-13 01:23:44 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-13 01:23:44 --> Database Driver Class Initialized
DEBUG - 2011-09-13 01:23:44 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-09-13 01:23:44 --> Helper loaded: url_helper
DEBUG - 2011-09-13 01:23:44 --> File loaded: application/views/common/header.php
DEBUG - 2011-09-13 01:23:44 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-09-13 01:23:44 --> File loaded: application/views/common/footer.php
DEBUG - 2011-09-13 01:23:44 --> File loaded: application/views/layout/main.php
DEBUG - 2011-09-13 01:23:44 --> Final output sent to browser
DEBUG - 2011-09-13 01:23:44 --> Total execution time: 0.0473
DEBUG - 2011-09-13 01:23:48 --> Config Class Initialized
DEBUG - 2011-09-13 01:23:48 --> Hooks Class Initialized
DEBUG - 2011-09-13 01:23:48 --> Utf8 Class Initialized
DEBUG - 2011-09-13 01:23:48 --> UTF-8 Support Enabled
DEBUG - 2011-09-13 01:23:48 --> URI Class Initialized
DEBUG - 2011-09-13 01:23:48 --> Router Class Initialized
DEBUG - 2011-09-13 01:23:48 --> Output Class Initialized
DEBUG - 2011-09-13 01:23:48 --> Input Class Initialized
DEBUG - 2011-09-13 01:23:48 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-13 01:23:48 --> Language Class Initialized
DEBUG - 2011-09-13 01:23:48 --> Loader Class Initialized
DEBUG - 2011-09-13 01:23:48 --> Controller Class Initialized
ERROR - 2011-09-13 01:23:48 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-09-13 01:23:48 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-09-13 01:23:48 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-09-13 01:23:48 --> Model Class Initialized
DEBUG - 2011-09-13 01:23:48 --> Model Class Initialized
DEBUG - 2011-09-13 01:23:48 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-13 01:23:48 --> Database Driver Class Initialized
DEBUG - 2011-09-13 01:23:48 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-09-13 01:23:48 --> Helper loaded: url_helper
DEBUG - 2011-09-13 01:23:48 --> File loaded: application/views/common/header.php
DEBUG - 2011-09-13 01:23:48 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-09-13 01:23:48 --> File loaded: application/views/common/footer.php
DEBUG - 2011-09-13 01:23:48 --> File loaded: application/views/layout/main.php
DEBUG - 2011-09-13 01:23:48 --> Final output sent to browser
DEBUG - 2011-09-13 01:23:48 --> Total execution time: 0.2203
DEBUG - 2011-09-13 01:23:55 --> Config Class Initialized
DEBUG - 2011-09-13 01:23:55 --> Hooks Class Initialized
DEBUG - 2011-09-13 01:23:55 --> Utf8 Class Initialized
DEBUG - 2011-09-13 01:23:55 --> UTF-8 Support Enabled
DEBUG - 2011-09-13 01:23:55 --> URI Class Initialized
DEBUG - 2011-09-13 01:23:55 --> Router Class Initialized
DEBUG - 2011-09-13 01:23:55 --> Output Class Initialized
DEBUG - 2011-09-13 01:23:55 --> Input Class Initialized
DEBUG - 2011-09-13 01:23:55 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-13 01:23:55 --> Language Class Initialized
DEBUG - 2011-09-13 01:23:55 --> Loader Class Initialized
DEBUG - 2011-09-13 01:23:55 --> Controller Class Initialized
DEBUG - 2011-09-13 01:23:55 --> Model Class Initialized
DEBUG - 2011-09-13 01:23:55 --> Model Class Initialized
DEBUG - 2011-09-13 01:23:55 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-13 01:23:55 --> Database Driver Class Initialized
DEBUG - 2011-09-13 01:23:55 --> Final output sent to browser
DEBUG - 2011-09-13 01:23:55 --> Total execution time: 0.6070
DEBUG - 2011-09-13 04:24:07 --> Config Class Initialized
DEBUG - 2011-09-13 04:24:07 --> Hooks Class Initialized
DEBUG - 2011-09-13 04:24:07 --> Utf8 Class Initialized
DEBUG - 2011-09-13 04:24:07 --> UTF-8 Support Enabled
DEBUG - 2011-09-13 04:24:07 --> URI Class Initialized
DEBUG - 2011-09-13 04:24:07 --> Router Class Initialized
DEBUG - 2011-09-13 04:24:07 --> No URI present. Default controller set.
DEBUG - 2011-09-13 04:24:07 --> Output Class Initialized
DEBUG - 2011-09-13 04:24:07 --> Input Class Initialized
DEBUG - 2011-09-13 04:24:07 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-13 04:24:07 --> Language Class Initialized
DEBUG - 2011-09-13 04:24:07 --> Loader Class Initialized
DEBUG - 2011-09-13 04:24:07 --> Controller Class Initialized
DEBUG - 2011-09-13 04:24:07 --> File loaded: application/views/splash/main.php
DEBUG - 2011-09-13 04:24:07 --> Helper loaded: url_helper
DEBUG - 2011-09-13 04:24:07 --> File loaded: application/views/common/header.php
DEBUG - 2011-09-13 04:24:07 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-09-13 04:24:07 --> File loaded: application/views/common/footer.php
DEBUG - 2011-09-13 04:24:07 --> File loaded: application/views/layout/main.php
DEBUG - 2011-09-13 04:24:07 --> Final output sent to browser
DEBUG - 2011-09-13 04:24:07 --> Total execution time: 0.1003
DEBUG - 2011-09-13 04:34:08 --> Config Class Initialized
DEBUG - 2011-09-13 04:34:08 --> Hooks Class Initialized
DEBUG - 2011-09-13 04:34:08 --> Utf8 Class Initialized
DEBUG - 2011-09-13 04:34:08 --> UTF-8 Support Enabled
DEBUG - 2011-09-13 04:34:08 --> URI Class Initialized
DEBUG - 2011-09-13 04:34:08 --> Router Class Initialized
ERROR - 2011-09-13 04:34:08 --> 404 Page Not Found --> robots.txt
DEBUG - 2011-09-13 04:34:17 --> Config Class Initialized
DEBUG - 2011-09-13 04:34:17 --> Hooks Class Initialized
DEBUG - 2011-09-13 04:34:17 --> Utf8 Class Initialized
DEBUG - 2011-09-13 04:34:17 --> UTF-8 Support Enabled
DEBUG - 2011-09-13 04:34:17 --> URI Class Initialized
DEBUG - 2011-09-13 04:34:17 --> Router Class Initialized
DEBUG - 2011-09-13 04:34:17 --> No URI present. Default controller set.
DEBUG - 2011-09-13 04:34:17 --> Output Class Initialized
DEBUG - 2011-09-13 04:34:17 --> Input Class Initialized
DEBUG - 2011-09-13 04:34:17 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-13 04:34:17 --> Language Class Initialized
DEBUG - 2011-09-13 04:34:17 --> Loader Class Initialized
DEBUG - 2011-09-13 04:34:17 --> Controller Class Initialized
DEBUG - 2011-09-13 04:34:17 --> File loaded: application/views/splash/main.php
DEBUG - 2011-09-13 04:34:17 --> Helper loaded: url_helper
DEBUG - 2011-09-13 04:34:17 --> File loaded: application/views/common/header.php
DEBUG - 2011-09-13 04:34:17 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-09-13 04:34:17 --> File loaded: application/views/common/footer.php
DEBUG - 2011-09-13 04:34:17 --> File loaded: application/views/layout/main.php
DEBUG - 2011-09-13 04:34:17 --> Final output sent to browser
DEBUG - 2011-09-13 04:34:17 --> Total execution time: 0.0120
DEBUG - 2011-09-13 04:48:07 --> Config Class Initialized
DEBUG - 2011-09-13 04:48:07 --> Hooks Class Initialized
DEBUG - 2011-09-13 04:48:07 --> Utf8 Class Initialized
DEBUG - 2011-09-13 04:48:07 --> UTF-8 Support Enabled
DEBUG - 2011-09-13 04:48:07 --> URI Class Initialized
DEBUG - 2011-09-13 04:48:07 --> Router Class Initialized
DEBUG - 2011-09-13 04:48:07 --> Output Class Initialized
DEBUG - 2011-09-13 04:48:07 --> Input Class Initialized
DEBUG - 2011-09-13 04:48:07 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-13 04:48:07 --> Language Class Initialized
DEBUG - 2011-09-13 04:48:07 --> Loader Class Initialized
DEBUG - 2011-09-13 04:48:07 --> Controller Class Initialized
DEBUG - 2011-09-13 04:48:07 --> Model Class Initialized
DEBUG - 2011-09-13 04:48:07 --> Model Class Initialized
DEBUG - 2011-09-13 04:48:07 --> Model Class Initialized
DEBUG - 2011-09-13 04:48:07 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-13 04:48:08 --> Database Driver Class Initialized
DEBUG - 2011-09-13 04:48:08 --> File loaded: application/views/table/main.php
DEBUG - 2011-09-13 04:48:08 --> Helper loaded: url_helper
DEBUG - 2011-09-13 04:48:08 --> File loaded: application/views/common/header.php
DEBUG - 2011-09-13 04:48:08 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-09-13 04:48:08 --> File loaded: application/views/common/footer.php
DEBUG - 2011-09-13 04:48:08 --> File loaded: application/views/layout/main.php
DEBUG - 2011-09-13 04:48:08 --> Final output sent to browser
DEBUG - 2011-09-13 04:48:08 --> Total execution time: 0.5073
DEBUG - 2011-09-13 04:48:30 --> Config Class Initialized
DEBUG - 2011-09-13 04:48:30 --> Hooks Class Initialized
DEBUG - 2011-09-13 04:48:30 --> Utf8 Class Initialized
DEBUG - 2011-09-13 04:48:30 --> UTF-8 Support Enabled
DEBUG - 2011-09-13 04:48:30 --> URI Class Initialized
DEBUG - 2011-09-13 04:48:30 --> Router Class Initialized
DEBUG - 2011-09-13 04:48:30 --> Output Class Initialized
DEBUG - 2011-09-13 04:48:30 --> Input Class Initialized
DEBUG - 2011-09-13 04:48:30 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-13 04:48:30 --> Language Class Initialized
DEBUG - 2011-09-13 04:48:30 --> Loader Class Initialized
DEBUG - 2011-09-13 04:48:30 --> Controller Class Initialized
DEBUG - 2011-09-13 04:48:30 --> Model Class Initialized
DEBUG - 2011-09-13 04:48:30 --> Model Class Initialized
DEBUG - 2011-09-13 04:48:30 --> Model Class Initialized
DEBUG - 2011-09-13 04:48:30 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-13 04:48:30 --> Database Driver Class Initialized
DEBUG - 2011-09-13 04:48:31 --> File loaded: application/views/table/main.php
DEBUG - 2011-09-13 04:48:31 --> Helper loaded: url_helper
DEBUG - 2011-09-13 04:48:31 --> File loaded: application/views/common/header.php
DEBUG - 2011-09-13 04:48:31 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-09-13 04:48:31 --> File loaded: application/views/common/footer.php
DEBUG - 2011-09-13 04:48:31 --> File loaded: application/views/layout/main.php
DEBUG - 2011-09-13 04:48:31 --> Final output sent to browser
DEBUG - 2011-09-13 04:48:31 --> Total execution time: 0.2320
DEBUG - 2011-09-13 04:48:48 --> Config Class Initialized
DEBUG - 2011-09-13 04:48:48 --> Hooks Class Initialized
DEBUG - 2011-09-13 04:48:48 --> Utf8 Class Initialized
DEBUG - 2011-09-13 04:48:48 --> UTF-8 Support Enabled
DEBUG - 2011-09-13 04:48:48 --> URI Class Initialized
DEBUG - 2011-09-13 04:48:48 --> Router Class Initialized
DEBUG - 2011-09-13 04:48:48 --> Output Class Initialized
DEBUG - 2011-09-13 04:48:48 --> Input Class Initialized
DEBUG - 2011-09-13 04:48:48 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-13 04:48:48 --> Language Class Initialized
DEBUG - 2011-09-13 04:48:48 --> Loader Class Initialized
DEBUG - 2011-09-13 04:48:48 --> Controller Class Initialized
DEBUG - 2011-09-13 04:48:48 --> Model Class Initialized
DEBUG - 2011-09-13 04:48:48 --> Model Class Initialized
DEBUG - 2011-09-13 04:48:48 --> Model Class Initialized
DEBUG - 2011-09-13 04:48:48 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-13 04:48:48 --> Database Driver Class Initialized
DEBUG - 2011-09-13 04:48:49 --> File loaded: application/views/table/main.php
DEBUG - 2011-09-13 04:48:49 --> Helper loaded: url_helper
DEBUG - 2011-09-13 04:48:49 --> File loaded: application/views/common/header.php
DEBUG - 2011-09-13 04:48:49 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-09-13 04:48:49 --> File loaded: application/views/common/footer.php
DEBUG - 2011-09-13 04:48:49 --> File loaded: application/views/layout/main.php
DEBUG - 2011-09-13 04:48:49 --> Final output sent to browser
DEBUG - 2011-09-13 04:48:49 --> Total execution time: 0.1965
DEBUG - 2011-09-13 04:49:03 --> Config Class Initialized
DEBUG - 2011-09-13 04:49:03 --> Hooks Class Initialized
DEBUG - 2011-09-13 04:49:03 --> Utf8 Class Initialized
DEBUG - 2011-09-13 04:49:03 --> UTF-8 Support Enabled
DEBUG - 2011-09-13 04:49:03 --> URI Class Initialized
DEBUG - 2011-09-13 04:49:03 --> Router Class Initialized
DEBUG - 2011-09-13 04:49:03 --> Output Class Initialized
DEBUG - 2011-09-13 04:49:03 --> Input Class Initialized
DEBUG - 2011-09-13 04:49:03 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-13 04:49:03 --> Language Class Initialized
DEBUG - 2011-09-13 04:49:03 --> Loader Class Initialized
DEBUG - 2011-09-13 04:49:03 --> Controller Class Initialized
DEBUG - 2011-09-13 04:49:03 --> Model Class Initialized
DEBUG - 2011-09-13 04:49:03 --> Model Class Initialized
DEBUG - 2011-09-13 04:49:03 --> Model Class Initialized
DEBUG - 2011-09-13 04:49:03 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-13 04:49:03 --> Database Driver Class Initialized
DEBUG - 2011-09-13 04:49:03 --> File loaded: application/views/table/main.php
DEBUG - 2011-09-13 04:49:03 --> Helper loaded: url_helper
DEBUG - 2011-09-13 04:49:03 --> File loaded: application/views/common/header.php
DEBUG - 2011-09-13 04:49:03 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-09-13 04:49:03 --> File loaded: application/views/common/footer.php
DEBUG - 2011-09-13 04:49:03 --> File loaded: application/views/layout/main.php
DEBUG - 2011-09-13 04:49:03 --> Final output sent to browser
DEBUG - 2011-09-13 04:49:03 --> Total execution time: 0.0550
DEBUG - 2011-09-13 04:49:04 --> Config Class Initialized
DEBUG - 2011-09-13 04:49:04 --> Hooks Class Initialized
DEBUG - 2011-09-13 04:49:04 --> Utf8 Class Initialized
DEBUG - 2011-09-13 04:49:04 --> UTF-8 Support Enabled
DEBUG - 2011-09-13 04:49:04 --> URI Class Initialized
DEBUG - 2011-09-13 04:49:04 --> Router Class Initialized
DEBUG - 2011-09-13 04:49:04 --> Output Class Initialized
DEBUG - 2011-09-13 04:49:04 --> Input Class Initialized
DEBUG - 2011-09-13 04:49:04 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-13 04:49:04 --> Language Class Initialized
DEBUG - 2011-09-13 04:49:04 --> Loader Class Initialized
DEBUG - 2011-09-13 04:49:04 --> Controller Class Initialized
ERROR - 2011-09-13 04:49:04 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-09-13 04:49:04 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-09-13 04:49:04 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-09-13 04:49:04 --> Model Class Initialized
DEBUG - 2011-09-13 04:49:04 --> Model Class Initialized
DEBUG - 2011-09-13 04:49:04 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-13 04:49:04 --> Database Driver Class Initialized
DEBUG - 2011-09-13 04:49:04 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-09-13 04:49:04 --> Helper loaded: url_helper
DEBUG - 2011-09-13 04:49:04 --> File loaded: application/views/common/header.php
DEBUG - 2011-09-13 04:49:04 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-09-13 04:49:04 --> File loaded: application/views/common/footer.php
DEBUG - 2011-09-13 04:49:04 --> File loaded: application/views/layout/main.php
DEBUG - 2011-09-13 04:49:04 --> Final output sent to browser
DEBUG - 2011-09-13 04:49:04 --> Total execution time: 0.0805
DEBUG - 2011-09-13 04:49:13 --> Config Class Initialized
DEBUG - 2011-09-13 04:49:13 --> Hooks Class Initialized
DEBUG - 2011-09-13 04:49:13 --> Utf8 Class Initialized
DEBUG - 2011-09-13 04:49:13 --> UTF-8 Support Enabled
DEBUG - 2011-09-13 04:49:13 --> URI Class Initialized
DEBUG - 2011-09-13 04:49:13 --> Router Class Initialized
DEBUG - 2011-09-13 04:49:13 --> Output Class Initialized
DEBUG - 2011-09-13 04:49:13 --> Input Class Initialized
DEBUG - 2011-09-13 04:49:13 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-13 04:49:13 --> Language Class Initialized
DEBUG - 2011-09-13 04:49:13 --> Loader Class Initialized
DEBUG - 2011-09-13 04:49:13 --> Controller Class Initialized
ERROR - 2011-09-13 04:49:13 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-09-13 04:49:13 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-09-13 04:49:13 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-09-13 04:49:13 --> Model Class Initialized
DEBUG - 2011-09-13 04:49:13 --> Model Class Initialized
DEBUG - 2011-09-13 04:49:13 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-13 04:49:13 --> Database Driver Class Initialized
DEBUG - 2011-09-13 04:49:13 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-09-13 04:49:13 --> Helper loaded: url_helper
DEBUG - 2011-09-13 04:49:13 --> File loaded: application/views/common/header.php
DEBUG - 2011-09-13 04:49:13 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-09-13 04:49:13 --> File loaded: application/views/common/footer.php
DEBUG - 2011-09-13 04:49:13 --> File loaded: application/views/layout/main.php
DEBUG - 2011-09-13 04:49:13 --> Final output sent to browser
DEBUG - 2011-09-13 04:49:13 --> Total execution time: 0.0279
DEBUG - 2011-09-13 04:49:14 --> Config Class Initialized
DEBUG - 2011-09-13 04:49:14 --> Hooks Class Initialized
DEBUG - 2011-09-13 04:49:14 --> Utf8 Class Initialized
DEBUG - 2011-09-13 04:49:14 --> UTF-8 Support Enabled
DEBUG - 2011-09-13 04:49:14 --> URI Class Initialized
DEBUG - 2011-09-13 04:49:14 --> Router Class Initialized
DEBUG - 2011-09-13 04:49:14 --> Output Class Initialized
DEBUG - 2011-09-13 04:49:14 --> Input Class Initialized
DEBUG - 2011-09-13 04:49:14 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-13 04:49:14 --> Language Class Initialized
DEBUG - 2011-09-13 04:49:15 --> Loader Class Initialized
DEBUG - 2011-09-13 04:49:15 --> Controller Class Initialized
DEBUG - 2011-09-13 04:49:15 --> Model Class Initialized
DEBUG - 2011-09-13 04:49:15 --> Model Class Initialized
DEBUG - 2011-09-13 04:49:15 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-13 04:49:15 --> Database Driver Class Initialized
DEBUG - 2011-09-13 04:49:15 --> Final output sent to browser
DEBUG - 2011-09-13 04:49:15 --> Total execution time: 0.7271
DEBUG - 2011-09-13 04:53:04 --> Config Class Initialized
DEBUG - 2011-09-13 04:53:04 --> Hooks Class Initialized
DEBUG - 2011-09-13 04:53:04 --> Utf8 Class Initialized
DEBUG - 2011-09-13 04:53:04 --> UTF-8 Support Enabled
DEBUG - 2011-09-13 04:53:04 --> URI Class Initialized
DEBUG - 2011-09-13 04:53:04 --> Router Class Initialized
DEBUG - 2011-09-13 04:53:04 --> Output Class Initialized
DEBUG - 2011-09-13 04:53:04 --> Input Class Initialized
DEBUG - 2011-09-13 04:53:04 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-13 04:53:04 --> Language Class Initialized
DEBUG - 2011-09-13 04:53:04 --> Loader Class Initialized
DEBUG - 2011-09-13 04:53:04 --> Controller Class Initialized
ERROR - 2011-09-13 04:53:04 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-09-13 04:53:04 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-09-13 04:53:04 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-09-13 04:53:04 --> Model Class Initialized
DEBUG - 2011-09-13 04:53:04 --> Model Class Initialized
DEBUG - 2011-09-13 04:53:04 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-13 04:53:04 --> Database Driver Class Initialized
DEBUG - 2011-09-13 04:53:04 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-09-13 04:53:04 --> Helper loaded: url_helper
DEBUG - 2011-09-13 04:53:04 --> File loaded: application/views/common/header.php
DEBUG - 2011-09-13 04:53:04 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-09-13 04:53:04 --> File loaded: application/views/common/footer.php
DEBUG - 2011-09-13 04:53:04 --> File loaded: application/views/layout/main.php
DEBUG - 2011-09-13 04:53:04 --> Final output sent to browser
DEBUG - 2011-09-13 04:53:04 --> Total execution time: 0.0347
DEBUG - 2011-09-13 05:21:42 --> Config Class Initialized
DEBUG - 2011-09-13 05:21:42 --> Hooks Class Initialized
DEBUG - 2011-09-13 05:21:42 --> Utf8 Class Initialized
DEBUG - 2011-09-13 05:21:42 --> UTF-8 Support Enabled
DEBUG - 2011-09-13 05:21:42 --> URI Class Initialized
DEBUG - 2011-09-13 05:21:42 --> Router Class Initialized
DEBUG - 2011-09-13 05:21:42 --> Output Class Initialized
DEBUG - 2011-09-13 05:21:42 --> Input Class Initialized
DEBUG - 2011-09-13 05:21:42 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-13 05:21:42 --> Language Class Initialized
DEBUG - 2011-09-13 05:21:42 --> Loader Class Initialized
DEBUG - 2011-09-13 05:21:42 --> Controller Class Initialized
ERROR - 2011-09-13 05:21:42 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-09-13 05:21:42 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-09-13 05:21:42 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-09-13 05:21:42 --> Model Class Initialized
DEBUG - 2011-09-13 05:21:42 --> Model Class Initialized
DEBUG - 2011-09-13 05:21:42 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-13 05:21:42 --> Database Driver Class Initialized
DEBUG - 2011-09-13 05:21:42 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-09-13 05:21:42 --> Helper loaded: url_helper
DEBUG - 2011-09-13 05:21:42 --> File loaded: application/views/common/header.php
DEBUG - 2011-09-13 05:21:42 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-09-13 05:21:42 --> File loaded: application/views/common/footer.php
DEBUG - 2011-09-13 05:21:42 --> File loaded: application/views/layout/main.php
DEBUG - 2011-09-13 05:21:42 --> Final output sent to browser
DEBUG - 2011-09-13 05:21:42 --> Total execution time: 0.1131
DEBUG - 2011-09-13 05:21:45 --> Config Class Initialized
DEBUG - 2011-09-13 05:21:45 --> Hooks Class Initialized
DEBUG - 2011-09-13 05:21:45 --> Utf8 Class Initialized
DEBUG - 2011-09-13 05:21:45 --> UTF-8 Support Enabled
DEBUG - 2011-09-13 05:21:45 --> URI Class Initialized
DEBUG - 2011-09-13 05:21:45 --> Router Class Initialized
DEBUG - 2011-09-13 05:21:45 --> Output Class Initialized
DEBUG - 2011-09-13 05:21:45 --> Input Class Initialized
DEBUG - 2011-09-13 05:21:45 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-13 05:21:45 --> Language Class Initialized
DEBUG - 2011-09-13 05:21:45 --> Loader Class Initialized
DEBUG - 2011-09-13 05:21:45 --> Controller Class Initialized
DEBUG - 2011-09-13 05:21:45 --> Model Class Initialized
DEBUG - 2011-09-13 05:21:45 --> Model Class Initialized
DEBUG - 2011-09-13 05:21:45 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-13 05:21:45 --> Database Driver Class Initialized
DEBUG - 2011-09-13 05:21:45 --> Final output sent to browser
DEBUG - 2011-09-13 05:21:45 --> Total execution time: 0.5793
DEBUG - 2011-09-13 05:21:48 --> Config Class Initialized
DEBUG - 2011-09-13 05:21:48 --> Hooks Class Initialized
DEBUG - 2011-09-13 05:21:48 --> Utf8 Class Initialized
DEBUG - 2011-09-13 05:21:48 --> UTF-8 Support Enabled
DEBUG - 2011-09-13 05:21:48 --> URI Class Initialized
DEBUG - 2011-09-13 05:21:48 --> Router Class Initialized
ERROR - 2011-09-13 05:21:48 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-09-13 05:23:50 --> Config Class Initialized
DEBUG - 2011-09-13 05:23:50 --> Hooks Class Initialized
DEBUG - 2011-09-13 05:23:50 --> Utf8 Class Initialized
DEBUG - 2011-09-13 05:23:50 --> UTF-8 Support Enabled
DEBUG - 2011-09-13 05:23:50 --> URI Class Initialized
DEBUG - 2011-09-13 05:23:50 --> Router Class Initialized
DEBUG - 2011-09-13 05:23:50 --> Output Class Initialized
DEBUG - 2011-09-13 05:23:50 --> Input Class Initialized
DEBUG - 2011-09-13 05:23:50 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-13 05:23:50 --> Language Class Initialized
DEBUG - 2011-09-13 05:23:50 --> Loader Class Initialized
DEBUG - 2011-09-13 05:23:50 --> Controller Class Initialized
DEBUG - 2011-09-13 05:23:50 --> Model Class Initialized
DEBUG - 2011-09-13 05:23:50 --> Model Class Initialized
DEBUG - 2011-09-13 05:23:50 --> Model Class Initialized
DEBUG - 2011-09-13 05:23:50 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-13 05:23:50 --> Database Driver Class Initialized
DEBUG - 2011-09-13 05:23:50 --> File loaded: application/views/table/main.php
DEBUG - 2011-09-13 05:23:50 --> Helper loaded: url_helper
DEBUG - 2011-09-13 05:23:50 --> File loaded: application/views/common/header.php
DEBUG - 2011-09-13 05:23:50 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-09-13 05:23:50 --> File loaded: application/views/common/footer.php
DEBUG - 2011-09-13 05:23:50 --> File loaded: application/views/layout/main.php
DEBUG - 2011-09-13 05:23:50 --> Final output sent to browser
DEBUG - 2011-09-13 05:23:50 --> Total execution time: 0.2886
DEBUG - 2011-09-13 05:25:11 --> Config Class Initialized
DEBUG - 2011-09-13 05:25:11 --> Hooks Class Initialized
DEBUG - 2011-09-13 05:25:11 --> Utf8 Class Initialized
DEBUG - 2011-09-13 05:25:11 --> UTF-8 Support Enabled
DEBUG - 2011-09-13 05:25:11 --> URI Class Initialized
DEBUG - 2011-09-13 05:25:11 --> Router Class Initialized
DEBUG - 2011-09-13 05:25:11 --> Output Class Initialized
DEBUG - 2011-09-13 05:25:11 --> Input Class Initialized
DEBUG - 2011-09-13 05:25:11 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-13 05:25:11 --> Language Class Initialized
DEBUG - 2011-09-13 05:25:11 --> Loader Class Initialized
DEBUG - 2011-09-13 05:25:11 --> Controller Class Initialized
DEBUG - 2011-09-13 05:25:11 --> Model Class Initialized
DEBUG - 2011-09-13 05:25:11 --> Model Class Initialized
DEBUG - 2011-09-13 05:25:11 --> Model Class Initialized
DEBUG - 2011-09-13 05:25:11 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-13 05:25:11 --> Database Driver Class Initialized
DEBUG - 2011-09-13 05:25:12 --> File loaded: application/views/table/main.php
DEBUG - 2011-09-13 05:25:12 --> Helper loaded: url_helper
DEBUG - 2011-09-13 05:25:12 --> File loaded: application/views/common/header.php
DEBUG - 2011-09-13 05:25:12 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-09-13 05:25:12 --> File loaded: application/views/common/footer.php
DEBUG - 2011-09-13 05:25:12 --> File loaded: application/views/layout/main.php
DEBUG - 2011-09-13 05:25:12 --> Final output sent to browser
DEBUG - 2011-09-13 05:25:12 --> Total execution time: 0.3773
DEBUG - 2011-09-13 05:26:10 --> Config Class Initialized
DEBUG - 2011-09-13 05:26:10 --> Hooks Class Initialized
DEBUG - 2011-09-13 05:26:10 --> Utf8 Class Initialized
DEBUG - 2011-09-13 05:26:10 --> UTF-8 Support Enabled
DEBUG - 2011-09-13 05:26:10 --> URI Class Initialized
DEBUG - 2011-09-13 05:26:10 --> Router Class Initialized
DEBUG - 2011-09-13 05:26:10 --> Output Class Initialized
DEBUG - 2011-09-13 05:26:10 --> Input Class Initialized
DEBUG - 2011-09-13 05:26:10 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-13 05:26:10 --> Language Class Initialized
DEBUG - 2011-09-13 05:26:10 --> Loader Class Initialized
DEBUG - 2011-09-13 05:26:10 --> Controller Class Initialized
DEBUG - 2011-09-13 05:26:10 --> Model Class Initialized
DEBUG - 2011-09-13 05:26:10 --> Model Class Initialized
DEBUG - 2011-09-13 05:26:10 --> Model Class Initialized
DEBUG - 2011-09-13 05:26:10 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-13 05:26:10 --> Database Driver Class Initialized
DEBUG - 2011-09-13 05:26:11 --> File loaded: application/views/table/main.php
DEBUG - 2011-09-13 05:26:11 --> Helper loaded: url_helper
DEBUG - 2011-09-13 05:26:11 --> File loaded: application/views/common/header.php
DEBUG - 2011-09-13 05:26:11 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-09-13 05:26:11 --> File loaded: application/views/common/footer.php
DEBUG - 2011-09-13 05:26:11 --> File loaded: application/views/layout/main.php
DEBUG - 2011-09-13 05:26:11 --> Final output sent to browser
DEBUG - 2011-09-13 05:26:11 --> Total execution time: 0.2716
DEBUG - 2011-09-13 05:26:54 --> Config Class Initialized
DEBUG - 2011-09-13 05:26:54 --> Hooks Class Initialized
DEBUG - 2011-09-13 05:26:54 --> Utf8 Class Initialized
DEBUG - 2011-09-13 05:26:54 --> UTF-8 Support Enabled
DEBUG - 2011-09-13 05:26:54 --> URI Class Initialized
DEBUG - 2011-09-13 05:26:54 --> Router Class Initialized
DEBUG - 2011-09-13 05:26:54 --> Output Class Initialized
DEBUG - 2011-09-13 05:26:54 --> Input Class Initialized
DEBUG - 2011-09-13 05:26:54 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-13 05:26:54 --> Language Class Initialized
DEBUG - 2011-09-13 05:26:54 --> Loader Class Initialized
DEBUG - 2011-09-13 05:26:54 --> Controller Class Initialized
DEBUG - 2011-09-13 05:26:54 --> Model Class Initialized
DEBUG - 2011-09-13 05:26:54 --> Model Class Initialized
DEBUG - 2011-09-13 05:26:54 --> Model Class Initialized
DEBUG - 2011-09-13 05:26:54 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-13 05:26:54 --> Database Driver Class Initialized
DEBUG - 2011-09-13 05:26:54 --> File loaded: application/views/table/main.php
DEBUG - 2011-09-13 05:26:54 --> Helper loaded: url_helper
DEBUG - 2011-09-13 05:26:54 --> File loaded: application/views/common/header.php
DEBUG - 2011-09-13 05:26:54 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-09-13 05:26:54 --> File loaded: application/views/common/footer.php
DEBUG - 2011-09-13 05:26:54 --> File loaded: application/views/layout/main.php
DEBUG - 2011-09-13 05:26:54 --> Final output sent to browser
DEBUG - 2011-09-13 05:26:54 --> Total execution time: 0.2512
DEBUG - 2011-09-13 05:28:55 --> Config Class Initialized
DEBUG - 2011-09-13 05:28:55 --> Hooks Class Initialized
DEBUG - 2011-09-13 05:28:55 --> Utf8 Class Initialized
DEBUG - 2011-09-13 05:28:55 --> UTF-8 Support Enabled
DEBUG - 2011-09-13 05:28:55 --> URI Class Initialized
DEBUG - 2011-09-13 05:28:55 --> Router Class Initialized
DEBUG - 2011-09-13 05:28:55 --> Output Class Initialized
DEBUG - 2011-09-13 05:28:55 --> Input Class Initialized
DEBUG - 2011-09-13 05:28:55 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-13 05:28:55 --> Language Class Initialized
DEBUG - 2011-09-13 05:28:55 --> Loader Class Initialized
DEBUG - 2011-09-13 05:28:55 --> Controller Class Initialized
DEBUG - 2011-09-13 05:28:55 --> Model Class Initialized
DEBUG - 2011-09-13 05:28:55 --> Model Class Initialized
DEBUG - 2011-09-13 05:28:55 --> Model Class Initialized
DEBUG - 2011-09-13 05:28:55 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-13 05:28:55 --> Database Driver Class Initialized
DEBUG - 2011-09-13 05:28:55 --> File loaded: application/views/table/main.php
DEBUG - 2011-09-13 05:28:55 --> Helper loaded: url_helper
DEBUG - 2011-09-13 05:28:55 --> File loaded: application/views/common/header.php
DEBUG - 2011-09-13 05:28:55 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-09-13 05:28:55 --> File loaded: application/views/common/footer.php
DEBUG - 2011-09-13 05:28:55 --> File loaded: application/views/layout/main.php
DEBUG - 2011-09-13 05:28:55 --> Final output sent to browser
DEBUG - 2011-09-13 05:28:55 --> Total execution time: 0.2621
DEBUG - 2011-09-13 05:29:19 --> Config Class Initialized
DEBUG - 2011-09-13 05:29:19 --> Hooks Class Initialized
DEBUG - 2011-09-13 05:29:19 --> Utf8 Class Initialized
DEBUG - 2011-09-13 05:29:19 --> UTF-8 Support Enabled
DEBUG - 2011-09-13 05:29:19 --> URI Class Initialized
DEBUG - 2011-09-13 05:29:19 --> Router Class Initialized
DEBUG - 2011-09-13 05:29:19 --> Output Class Initialized
DEBUG - 2011-09-13 05:29:19 --> Input Class Initialized
DEBUG - 2011-09-13 05:29:19 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-13 05:29:19 --> Language Class Initialized
DEBUG - 2011-09-13 05:29:19 --> Loader Class Initialized
DEBUG - 2011-09-13 05:29:19 --> Controller Class Initialized
DEBUG - 2011-09-13 05:29:19 --> Model Class Initialized
DEBUG - 2011-09-13 05:29:19 --> Model Class Initialized
DEBUG - 2011-09-13 05:29:19 --> Model Class Initialized
DEBUG - 2011-09-13 05:29:19 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-13 05:29:19 --> Database Driver Class Initialized
DEBUG - 2011-09-13 05:29:19 --> File loaded: application/views/table/main.php
DEBUG - 2011-09-13 05:29:19 --> Helper loaded: url_helper
DEBUG - 2011-09-13 05:29:19 --> File loaded: application/views/common/header.php
DEBUG - 2011-09-13 05:29:19 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-09-13 05:29:19 --> File loaded: application/views/common/footer.php
DEBUG - 2011-09-13 05:29:19 --> File loaded: application/views/layout/main.php
DEBUG - 2011-09-13 05:29:19 --> Final output sent to browser
DEBUG - 2011-09-13 05:29:19 --> Total execution time: 0.3468
DEBUG - 2011-09-13 05:30:09 --> Config Class Initialized
DEBUG - 2011-09-13 05:30:09 --> Hooks Class Initialized
DEBUG - 2011-09-13 05:30:09 --> Utf8 Class Initialized
DEBUG - 2011-09-13 05:30:09 --> UTF-8 Support Enabled
DEBUG - 2011-09-13 05:30:09 --> URI Class Initialized
DEBUG - 2011-09-13 05:30:09 --> Router Class Initialized
DEBUG - 2011-09-13 05:30:09 --> Output Class Initialized
DEBUG - 2011-09-13 05:30:09 --> Input Class Initialized
DEBUG - 2011-09-13 05:30:09 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-13 05:30:09 --> Language Class Initialized
DEBUG - 2011-09-13 05:30:09 --> Loader Class Initialized
DEBUG - 2011-09-13 05:30:09 --> Controller Class Initialized
DEBUG - 2011-09-13 05:30:09 --> Model Class Initialized
DEBUG - 2011-09-13 05:30:09 --> Model Class Initialized
DEBUG - 2011-09-13 05:30:09 --> Model Class Initialized
DEBUG - 2011-09-13 05:30:09 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-13 05:30:09 --> Database Driver Class Initialized
DEBUG - 2011-09-13 05:30:10 --> File loaded: application/views/table/main.php
DEBUG - 2011-09-13 05:30:10 --> Helper loaded: url_helper
DEBUG - 2011-09-13 05:30:10 --> File loaded: application/views/common/header.php
DEBUG - 2011-09-13 05:30:10 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-09-13 05:30:10 --> File loaded: application/views/common/footer.php
DEBUG - 2011-09-13 05:30:10 --> File loaded: application/views/layout/main.php
DEBUG - 2011-09-13 05:30:10 --> Final output sent to browser
DEBUG - 2011-09-13 05:30:10 --> Total execution time: 0.6342
DEBUG - 2011-09-13 05:30:50 --> Config Class Initialized
DEBUG - 2011-09-13 05:30:50 --> Hooks Class Initialized
DEBUG - 2011-09-13 05:30:50 --> Utf8 Class Initialized
DEBUG - 2011-09-13 05:30:50 --> UTF-8 Support Enabled
DEBUG - 2011-09-13 05:30:50 --> URI Class Initialized
DEBUG - 2011-09-13 05:30:50 --> Router Class Initialized
DEBUG - 2011-09-13 05:30:50 --> Output Class Initialized
DEBUG - 2011-09-13 05:30:50 --> Input Class Initialized
DEBUG - 2011-09-13 05:30:50 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-13 05:30:50 --> Language Class Initialized
DEBUG - 2011-09-13 05:30:50 --> Loader Class Initialized
DEBUG - 2011-09-13 05:30:50 --> Controller Class Initialized
DEBUG - 2011-09-13 05:30:50 --> Model Class Initialized
DEBUG - 2011-09-13 05:30:50 --> Model Class Initialized
DEBUG - 2011-09-13 05:30:50 --> Model Class Initialized
DEBUG - 2011-09-13 05:30:50 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-13 05:30:50 --> Database Driver Class Initialized
DEBUG - 2011-09-13 05:30:50 --> File loaded: application/views/table/main.php
DEBUG - 2011-09-13 05:30:50 --> Helper loaded: url_helper
DEBUG - 2011-09-13 05:30:50 --> File loaded: application/views/common/header.php
DEBUG - 2011-09-13 05:30:50 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-09-13 05:30:50 --> File loaded: application/views/common/footer.php
DEBUG - 2011-09-13 05:30:50 --> File loaded: application/views/layout/main.php
DEBUG - 2011-09-13 05:30:50 --> Final output sent to browser
DEBUG - 2011-09-13 05:30:50 --> Total execution time: 0.2054
DEBUG - 2011-09-13 05:31:33 --> Config Class Initialized
DEBUG - 2011-09-13 05:31:33 --> Hooks Class Initialized
DEBUG - 2011-09-13 05:31:33 --> Utf8 Class Initialized
DEBUG - 2011-09-13 05:31:33 --> UTF-8 Support Enabled
DEBUG - 2011-09-13 05:31:33 --> URI Class Initialized
DEBUG - 2011-09-13 05:31:33 --> Router Class Initialized
DEBUG - 2011-09-13 05:31:33 --> Output Class Initialized
DEBUG - 2011-09-13 05:31:33 --> Input Class Initialized
DEBUG - 2011-09-13 05:31:33 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-13 05:31:33 --> Language Class Initialized
DEBUG - 2011-09-13 05:31:33 --> Loader Class Initialized
DEBUG - 2011-09-13 05:31:33 --> Controller Class Initialized
DEBUG - 2011-09-13 05:31:33 --> Model Class Initialized
DEBUG - 2011-09-13 05:31:33 --> Model Class Initialized
DEBUG - 2011-09-13 05:31:33 --> Model Class Initialized
DEBUG - 2011-09-13 05:31:33 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-13 05:31:33 --> Database Driver Class Initialized
DEBUG - 2011-09-13 05:31:33 --> File loaded: application/views/table/main.php
DEBUG - 2011-09-13 05:31:33 --> Helper loaded: url_helper
DEBUG - 2011-09-13 05:31:33 --> File loaded: application/views/common/header.php
DEBUG - 2011-09-13 05:31:33 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-09-13 05:31:33 --> File loaded: application/views/common/footer.php
DEBUG - 2011-09-13 05:31:33 --> File loaded: application/views/layout/main.php
DEBUG - 2011-09-13 05:31:33 --> Final output sent to browser
DEBUG - 2011-09-13 05:31:33 --> Total execution time: 0.3933
DEBUG - 2011-09-13 05:32:23 --> Config Class Initialized
DEBUG - 2011-09-13 05:32:23 --> Hooks Class Initialized
DEBUG - 2011-09-13 05:32:23 --> Utf8 Class Initialized
DEBUG - 2011-09-13 05:32:23 --> UTF-8 Support Enabled
DEBUG - 2011-09-13 05:32:23 --> URI Class Initialized
DEBUG - 2011-09-13 05:32:23 --> Router Class Initialized
DEBUG - 2011-09-13 05:32:23 --> Output Class Initialized
DEBUG - 2011-09-13 05:32:23 --> Input Class Initialized
DEBUG - 2011-09-13 05:32:23 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-13 05:32:23 --> Language Class Initialized
DEBUG - 2011-09-13 05:32:23 --> Loader Class Initialized
DEBUG - 2011-09-13 05:32:23 --> Controller Class Initialized
DEBUG - 2011-09-13 05:32:23 --> Model Class Initialized
DEBUG - 2011-09-13 05:32:23 --> Model Class Initialized
DEBUG - 2011-09-13 05:32:23 --> Model Class Initialized
DEBUG - 2011-09-13 05:32:23 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-13 05:32:23 --> Database Driver Class Initialized
DEBUG - 2011-09-13 05:32:23 --> File loaded: application/views/table/main.php
DEBUG - 2011-09-13 05:32:23 --> Helper loaded: url_helper
DEBUG - 2011-09-13 05:32:23 --> File loaded: application/views/common/header.php
DEBUG - 2011-09-13 05:32:23 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-09-13 05:32:23 --> File loaded: application/views/common/footer.php
DEBUG - 2011-09-13 05:32:23 --> File loaded: application/views/layout/main.php
DEBUG - 2011-09-13 05:32:23 --> Final output sent to browser
DEBUG - 2011-09-13 05:32:23 --> Total execution time: 0.2450
DEBUG - 2011-09-13 06:18:06 --> Config Class Initialized
DEBUG - 2011-09-13 06:18:06 --> Hooks Class Initialized
DEBUG - 2011-09-13 06:18:06 --> Utf8 Class Initialized
DEBUG - 2011-09-13 06:18:06 --> UTF-8 Support Enabled
DEBUG - 2011-09-13 06:18:06 --> URI Class Initialized
DEBUG - 2011-09-13 06:18:06 --> Router Class Initialized
DEBUG - 2011-09-13 06:18:06 --> Output Class Initialized
DEBUG - 2011-09-13 06:18:06 --> Input Class Initialized
DEBUG - 2011-09-13 06:18:06 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-13 06:18:06 --> Language Class Initialized
DEBUG - 2011-09-13 06:18:06 --> Loader Class Initialized
DEBUG - 2011-09-13 06:18:06 --> Controller Class Initialized
ERROR - 2011-09-13 06:18:06 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-09-13 06:18:06 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-09-13 06:18:06 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-09-13 06:18:06 --> Model Class Initialized
DEBUG - 2011-09-13 06:18:06 --> Model Class Initialized
DEBUG - 2011-09-13 06:18:06 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-13 06:18:06 --> Database Driver Class Initialized
DEBUG - 2011-09-13 06:18:06 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-09-13 06:18:06 --> Helper loaded: url_helper
DEBUG - 2011-09-13 06:18:06 --> File loaded: application/views/common/header.php
DEBUG - 2011-09-13 06:18:06 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-09-13 06:18:06 --> File loaded: application/views/common/footer.php
DEBUG - 2011-09-13 06:18:06 --> File loaded: application/views/layout/main.php
DEBUG - 2011-09-13 06:18:06 --> Final output sent to browser
DEBUG - 2011-09-13 06:18:06 --> Total execution time: 0.0464
DEBUG - 2011-09-13 06:18:07 --> Config Class Initialized
DEBUG - 2011-09-13 06:18:07 --> Hooks Class Initialized
DEBUG - 2011-09-13 06:18:07 --> Utf8 Class Initialized
DEBUG - 2011-09-13 06:18:07 --> UTF-8 Support Enabled
DEBUG - 2011-09-13 06:18:07 --> URI Class Initialized
DEBUG - 2011-09-13 06:18:07 --> Router Class Initialized
DEBUG - 2011-09-13 06:18:07 --> Output Class Initialized
DEBUG - 2011-09-13 06:18:07 --> Input Class Initialized
DEBUG - 2011-09-13 06:18:07 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-13 06:18:07 --> Language Class Initialized
DEBUG - 2011-09-13 06:18:07 --> Loader Class Initialized
DEBUG - 2011-09-13 06:18:07 --> Controller Class Initialized
DEBUG - 2011-09-13 06:18:07 --> Model Class Initialized
DEBUG - 2011-09-13 06:18:07 --> Model Class Initialized
DEBUG - 2011-09-13 06:18:07 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-13 06:18:07 --> Database Driver Class Initialized
DEBUG - 2011-09-13 06:18:08 --> Final output sent to browser
DEBUG - 2011-09-13 06:18:08 --> Total execution time: 0.6991
DEBUG - 2011-09-13 06:18:09 --> Config Class Initialized
DEBUG - 2011-09-13 06:18:09 --> Hooks Class Initialized
DEBUG - 2011-09-13 06:18:09 --> Utf8 Class Initialized
DEBUG - 2011-09-13 06:18:09 --> UTF-8 Support Enabled
DEBUG - 2011-09-13 06:18:09 --> URI Class Initialized
DEBUG - 2011-09-13 06:18:09 --> Router Class Initialized
ERROR - 2011-09-13 06:18:09 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-09-13 06:18:38 --> Config Class Initialized
DEBUG - 2011-09-13 06:18:38 --> Hooks Class Initialized
DEBUG - 2011-09-13 06:18:38 --> Utf8 Class Initialized
DEBUG - 2011-09-13 06:18:38 --> UTF-8 Support Enabled
DEBUG - 2011-09-13 06:18:38 --> URI Class Initialized
DEBUG - 2011-09-13 06:18:38 --> Router Class Initialized
DEBUG - 2011-09-13 06:18:38 --> Output Class Initialized
DEBUG - 2011-09-13 06:18:38 --> Input Class Initialized
DEBUG - 2011-09-13 06:18:38 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-13 06:18:38 --> Language Class Initialized
DEBUG - 2011-09-13 06:18:38 --> Loader Class Initialized
DEBUG - 2011-09-13 06:18:38 --> Controller Class Initialized
ERROR - 2011-09-13 06:18:38 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-09-13 06:18:38 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-09-13 06:18:38 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-09-13 06:18:38 --> Model Class Initialized
DEBUG - 2011-09-13 06:18:38 --> Model Class Initialized
DEBUG - 2011-09-13 06:18:38 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-13 06:18:38 --> Database Driver Class Initialized
DEBUG - 2011-09-13 06:18:38 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-09-13 06:18:38 --> Helper loaded: url_helper
DEBUG - 2011-09-13 06:18:38 --> File loaded: application/views/common/header.php
DEBUG - 2011-09-13 06:18:38 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-09-13 06:18:38 --> File loaded: application/views/common/footer.php
DEBUG - 2011-09-13 06:18:38 --> File loaded: application/views/layout/main.php
DEBUG - 2011-09-13 06:18:38 --> Final output sent to browser
DEBUG - 2011-09-13 06:18:38 --> Total execution time: 0.0283
DEBUG - 2011-09-13 06:38:28 --> Config Class Initialized
DEBUG - 2011-09-13 06:38:28 --> Hooks Class Initialized
DEBUG - 2011-09-13 06:38:28 --> Utf8 Class Initialized
DEBUG - 2011-09-13 06:38:28 --> UTF-8 Support Enabled
DEBUG - 2011-09-13 06:38:28 --> URI Class Initialized
DEBUG - 2011-09-13 06:38:28 --> Router Class Initialized
DEBUG - 2011-09-13 06:38:28 --> Output Class Initialized
DEBUG - 2011-09-13 06:38:28 --> Input Class Initialized
DEBUG - 2011-09-13 06:38:28 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-13 06:38:28 --> Language Class Initialized
DEBUG - 2011-09-13 06:38:28 --> Loader Class Initialized
DEBUG - 2011-09-13 06:38:28 --> Controller Class Initialized
ERROR - 2011-09-13 06:38:28 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-09-13 06:38:28 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-09-13 06:38:28 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-09-13 06:38:28 --> Model Class Initialized
DEBUG - 2011-09-13 06:38:28 --> Model Class Initialized
DEBUG - 2011-09-13 06:38:28 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-13 06:38:28 --> Database Driver Class Initialized
DEBUG - 2011-09-13 06:38:28 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-09-13 06:38:28 --> Helper loaded: url_helper
DEBUG - 2011-09-13 06:38:28 --> File loaded: application/views/common/header.php
DEBUG - 2011-09-13 06:38:28 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-09-13 06:38:28 --> File loaded: application/views/common/footer.php
DEBUG - 2011-09-13 06:38:28 --> File loaded: application/views/layout/main.php
DEBUG - 2011-09-13 06:38:28 --> Final output sent to browser
DEBUG - 2011-09-13 06:38:28 --> Total execution time: 0.0373
DEBUG - 2011-09-13 06:38:29 --> Config Class Initialized
DEBUG - 2011-09-13 06:38:29 --> Hooks Class Initialized
DEBUG - 2011-09-13 06:38:29 --> Utf8 Class Initialized
DEBUG - 2011-09-13 06:38:29 --> UTF-8 Support Enabled
DEBUG - 2011-09-13 06:38:29 --> URI Class Initialized
DEBUG - 2011-09-13 06:38:29 --> Router Class Initialized
DEBUG - 2011-09-13 06:38:29 --> Output Class Initialized
DEBUG - 2011-09-13 06:38:29 --> Input Class Initialized
DEBUG - 2011-09-13 06:38:29 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-13 06:38:29 --> Language Class Initialized
DEBUG - 2011-09-13 06:38:29 --> Loader Class Initialized
DEBUG - 2011-09-13 06:38:29 --> Controller Class Initialized
DEBUG - 2011-09-13 06:38:29 --> Model Class Initialized
DEBUG - 2011-09-13 06:38:29 --> Model Class Initialized
DEBUG - 2011-09-13 06:38:29 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-13 06:38:29 --> Database Driver Class Initialized
DEBUG - 2011-09-13 06:38:29 --> Final output sent to browser
DEBUG - 2011-09-13 06:38:29 --> Total execution time: 0.4779
DEBUG - 2011-09-13 06:39:37 --> Config Class Initialized
DEBUG - 2011-09-13 06:39:37 --> Hooks Class Initialized
DEBUG - 2011-09-13 06:39:37 --> Utf8 Class Initialized
DEBUG - 2011-09-13 06:39:37 --> UTF-8 Support Enabled
DEBUG - 2011-09-13 06:39:37 --> URI Class Initialized
DEBUG - 2011-09-13 06:39:37 --> Router Class Initialized
DEBUG - 2011-09-13 06:39:37 --> Output Class Initialized
DEBUG - 2011-09-13 06:39:37 --> Input Class Initialized
DEBUG - 2011-09-13 06:39:37 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-13 06:39:37 --> Language Class Initialized
DEBUG - 2011-09-13 06:39:37 --> Loader Class Initialized
DEBUG - 2011-09-13 06:39:37 --> Controller Class Initialized
DEBUG - 2011-09-13 06:39:37 --> Model Class Initialized
DEBUG - 2011-09-13 06:39:37 --> Model Class Initialized
DEBUG - 2011-09-13 06:39:37 --> Model Class Initialized
DEBUG - 2011-09-13 06:39:37 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-13 06:39:37 --> Database Driver Class Initialized
DEBUG - 2011-09-13 06:39:37 --> File loaded: application/views/table/main.php
DEBUG - 2011-09-13 06:39:37 --> Helper loaded: url_helper
DEBUG - 2011-09-13 06:39:37 --> File loaded: application/views/common/header.php
DEBUG - 2011-09-13 06:39:37 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-09-13 06:39:37 --> File loaded: application/views/common/footer.php
DEBUG - 2011-09-13 06:39:37 --> File loaded: application/views/layout/main.php
DEBUG - 2011-09-13 06:39:37 --> Final output sent to browser
DEBUG - 2011-09-13 06:39:37 --> Total execution time: 0.2212
DEBUG - 2011-09-13 07:10:54 --> Config Class Initialized
DEBUG - 2011-09-13 07:10:54 --> Hooks Class Initialized
DEBUG - 2011-09-13 07:10:54 --> Utf8 Class Initialized
DEBUG - 2011-09-13 07:10:54 --> UTF-8 Support Enabled
DEBUG - 2011-09-13 07:10:54 --> URI Class Initialized
DEBUG - 2011-09-13 07:10:54 --> Router Class Initialized
DEBUG - 2011-09-13 07:10:54 --> Output Class Initialized
DEBUG - 2011-09-13 07:10:54 --> Input Class Initialized
DEBUG - 2011-09-13 07:10:54 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-13 07:10:54 --> Language Class Initialized
DEBUG - 2011-09-13 07:10:54 --> Loader Class Initialized
DEBUG - 2011-09-13 07:10:54 --> Controller Class Initialized
DEBUG - 2011-09-13 07:10:54 --> Model Class Initialized
DEBUG - 2011-09-13 07:10:54 --> Model Class Initialized
DEBUG - 2011-09-13 07:10:54 --> Model Class Initialized
DEBUG - 2011-09-13 07:10:54 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-13 07:10:54 --> Database Driver Class Initialized
DEBUG - 2011-09-13 07:10:54 --> File loaded: application/views/table/main.php
DEBUG - 2011-09-13 07:10:54 --> Helper loaded: url_helper
DEBUG - 2011-09-13 07:10:54 --> File loaded: application/views/common/header.php
DEBUG - 2011-09-13 07:10:54 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-09-13 07:10:54 --> File loaded: application/views/common/footer.php
DEBUG - 2011-09-13 07:10:54 --> File loaded: application/views/layout/main.php
DEBUG - 2011-09-13 07:10:54 --> Final output sent to browser
DEBUG - 2011-09-13 07:10:54 --> Total execution time: 0.3001
DEBUG - 2011-09-13 07:10:55 --> Config Class Initialized
DEBUG - 2011-09-13 07:10:55 --> Hooks Class Initialized
DEBUG - 2011-09-13 07:10:55 --> Utf8 Class Initialized
DEBUG - 2011-09-13 07:10:55 --> UTF-8 Support Enabled
DEBUG - 2011-09-13 07:10:55 --> URI Class Initialized
DEBUG - 2011-09-13 07:10:55 --> Router Class Initialized
ERROR - 2011-09-13 07:10:55 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-09-13 07:12:08 --> Config Class Initialized
DEBUG - 2011-09-13 07:12:08 --> Hooks Class Initialized
DEBUG - 2011-09-13 07:12:08 --> Utf8 Class Initialized
DEBUG - 2011-09-13 07:12:08 --> UTF-8 Support Enabled
DEBUG - 2011-09-13 07:12:08 --> URI Class Initialized
DEBUG - 2011-09-13 07:12:08 --> Router Class Initialized
DEBUG - 2011-09-13 07:12:08 --> Output Class Initialized
DEBUG - 2011-09-13 07:12:08 --> Input Class Initialized
DEBUG - 2011-09-13 07:12:08 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-13 07:12:08 --> Language Class Initialized
DEBUG - 2011-09-13 07:12:08 --> Loader Class Initialized
DEBUG - 2011-09-13 07:12:08 --> Controller Class Initialized
DEBUG - 2011-09-13 07:12:08 --> Model Class Initialized
DEBUG - 2011-09-13 07:12:08 --> Model Class Initialized
DEBUG - 2011-09-13 07:12:08 --> Model Class Initialized
DEBUG - 2011-09-13 07:12:08 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-13 07:12:08 --> Database Driver Class Initialized
DEBUG - 2011-09-13 07:12:08 --> File loaded: application/views/table/main.php
DEBUG - 2011-09-13 07:12:08 --> Helper loaded: url_helper
DEBUG - 2011-09-13 07:12:08 --> File loaded: application/views/common/header.php
DEBUG - 2011-09-13 07:12:08 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-09-13 07:12:08 --> File loaded: application/views/common/footer.php
DEBUG - 2011-09-13 07:12:08 --> File loaded: application/views/layout/main.php
DEBUG - 2011-09-13 07:12:08 --> Final output sent to browser
DEBUG - 2011-09-13 07:12:08 --> Total execution time: 0.2141
DEBUG - 2011-09-13 07:12:09 --> Config Class Initialized
DEBUG - 2011-09-13 07:12:09 --> Hooks Class Initialized
DEBUG - 2011-09-13 07:12:09 --> Utf8 Class Initialized
DEBUG - 2011-09-13 07:12:09 --> UTF-8 Support Enabled
DEBUG - 2011-09-13 07:12:09 --> URI Class Initialized
DEBUG - 2011-09-13 07:12:09 --> Router Class Initialized
ERROR - 2011-09-13 07:12:09 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-09-13 07:23:30 --> Config Class Initialized
DEBUG - 2011-09-13 07:23:30 --> Hooks Class Initialized
DEBUG - 2011-09-13 07:23:30 --> Utf8 Class Initialized
DEBUG - 2011-09-13 07:23:30 --> UTF-8 Support Enabled
DEBUG - 2011-09-13 07:23:30 --> URI Class Initialized
DEBUG - 2011-09-13 07:23:30 --> Router Class Initialized
DEBUG - 2011-09-13 07:23:30 --> Output Class Initialized
DEBUG - 2011-09-13 07:23:30 --> Input Class Initialized
DEBUG - 2011-09-13 07:23:30 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-13 07:23:30 --> Language Class Initialized
DEBUG - 2011-09-13 07:23:30 --> Loader Class Initialized
DEBUG - 2011-09-13 07:23:30 --> Controller Class Initialized
DEBUG - 2011-09-13 07:23:30 --> Model Class Initialized
DEBUG - 2011-09-13 07:23:30 --> Model Class Initialized
DEBUG - 2011-09-13 07:23:30 --> Model Class Initialized
DEBUG - 2011-09-13 07:23:30 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-13 07:23:30 --> Database Driver Class Initialized
DEBUG - 2011-09-13 07:23:30 --> File loaded: application/views/table/main.php
DEBUG - 2011-09-13 07:23:30 --> Helper loaded: url_helper
DEBUG - 2011-09-13 07:23:30 --> File loaded: application/views/common/header.php
DEBUG - 2011-09-13 07:23:30 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-09-13 07:23:30 --> File loaded: application/views/common/footer.php
DEBUG - 2011-09-13 07:23:30 --> File loaded: application/views/layout/main.php
DEBUG - 2011-09-13 07:23:30 --> Final output sent to browser
DEBUG - 2011-09-13 07:23:30 --> Total execution time: 0.0450
DEBUG - 2011-09-13 07:23:32 --> Config Class Initialized
DEBUG - 2011-09-13 07:23:32 --> Hooks Class Initialized
DEBUG - 2011-09-13 07:23:32 --> Utf8 Class Initialized
DEBUG - 2011-09-13 07:23:32 --> UTF-8 Support Enabled
DEBUG - 2011-09-13 07:23:32 --> URI Class Initialized
DEBUG - 2011-09-13 07:23:32 --> Router Class Initialized
ERROR - 2011-09-13 07:23:32 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-09-13 07:46:02 --> Config Class Initialized
DEBUG - 2011-09-13 07:46:02 --> Hooks Class Initialized
DEBUG - 2011-09-13 07:46:02 --> Utf8 Class Initialized
DEBUG - 2011-09-13 07:46:02 --> UTF-8 Support Enabled
DEBUG - 2011-09-13 07:46:02 --> URI Class Initialized
DEBUG - 2011-09-13 07:46:02 --> Router Class Initialized
DEBUG - 2011-09-13 07:46:02 --> Output Class Initialized
DEBUG - 2011-09-13 07:46:02 --> Input Class Initialized
DEBUG - 2011-09-13 07:46:02 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-13 07:46:02 --> Language Class Initialized
DEBUG - 2011-09-13 07:46:02 --> Loader Class Initialized
DEBUG - 2011-09-13 07:46:02 --> Controller Class Initialized
ERROR - 2011-09-13 07:46:02 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-09-13 07:46:02 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-09-13 07:46:02 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-09-13 07:46:02 --> Model Class Initialized
DEBUG - 2011-09-13 07:46:02 --> Model Class Initialized
DEBUG - 2011-09-13 07:46:02 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-13 07:46:02 --> Database Driver Class Initialized
DEBUG - 2011-09-13 07:46:02 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-09-13 07:46:02 --> Helper loaded: url_helper
DEBUG - 2011-09-13 07:46:02 --> File loaded: application/views/common/header.php
DEBUG - 2011-09-13 07:46:02 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-09-13 07:46:02 --> File loaded: application/views/common/footer.php
DEBUG - 2011-09-13 07:46:02 --> File loaded: application/views/layout/main.php
DEBUG - 2011-09-13 07:46:02 --> Final output sent to browser
DEBUG - 2011-09-13 07:46:02 --> Total execution time: 0.0330
DEBUG - 2011-09-13 07:46:02 --> Config Class Initialized
DEBUG - 2011-09-13 07:46:02 --> Hooks Class Initialized
DEBUG - 2011-09-13 07:46:02 --> Utf8 Class Initialized
DEBUG - 2011-09-13 07:46:02 --> UTF-8 Support Enabled
DEBUG - 2011-09-13 07:46:02 --> URI Class Initialized
DEBUG - 2011-09-13 07:46:02 --> Router Class Initialized
DEBUG - 2011-09-13 07:46:02 --> Output Class Initialized
DEBUG - 2011-09-13 07:46:02 --> Input Class Initialized
DEBUG - 2011-09-13 07:46:02 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-13 07:46:02 --> Language Class Initialized
DEBUG - 2011-09-13 07:46:02 --> Loader Class Initialized
DEBUG - 2011-09-13 07:46:02 --> Controller Class Initialized
DEBUG - 2011-09-13 07:46:02 --> Model Class Initialized
DEBUG - 2011-09-13 07:46:02 --> Model Class Initialized
DEBUG - 2011-09-13 07:46:02 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-13 07:46:02 --> Database Driver Class Initialized
DEBUG - 2011-09-13 07:46:03 --> Final output sent to browser
DEBUG - 2011-09-13 07:46:03 --> Total execution time: 0.7290
DEBUG - 2011-09-13 07:46:04 --> Config Class Initialized
DEBUG - 2011-09-13 07:46:04 --> Hooks Class Initialized
DEBUG - 2011-09-13 07:46:04 --> Utf8 Class Initialized
DEBUG - 2011-09-13 07:46:04 --> UTF-8 Support Enabled
DEBUG - 2011-09-13 07:46:04 --> URI Class Initialized
DEBUG - 2011-09-13 07:46:04 --> Router Class Initialized
ERROR - 2011-09-13 07:46:04 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-09-13 07:46:04 --> Config Class Initialized
DEBUG - 2011-09-13 07:46:04 --> Hooks Class Initialized
DEBUG - 2011-09-13 07:46:04 --> Utf8 Class Initialized
DEBUG - 2011-09-13 07:46:04 --> UTF-8 Support Enabled
DEBUG - 2011-09-13 07:46:04 --> URI Class Initialized
DEBUG - 2011-09-13 07:46:04 --> Router Class Initialized
ERROR - 2011-09-13 07:46:04 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-09-13 07:46:43 --> Config Class Initialized
DEBUG - 2011-09-13 07:46:43 --> Hooks Class Initialized
DEBUG - 2011-09-13 07:46:43 --> Utf8 Class Initialized
DEBUG - 2011-09-13 07:46:43 --> UTF-8 Support Enabled
DEBUG - 2011-09-13 07:46:43 --> URI Class Initialized
DEBUG - 2011-09-13 07:46:43 --> Router Class Initialized
DEBUG - 2011-09-13 07:46:43 --> Output Class Initialized
DEBUG - 2011-09-13 07:46:43 --> Input Class Initialized
DEBUG - 2011-09-13 07:46:43 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-13 07:46:43 --> Language Class Initialized
DEBUG - 2011-09-13 07:46:43 --> Loader Class Initialized
DEBUG - 2011-09-13 07:46:43 --> Controller Class Initialized
DEBUG - 2011-09-13 07:46:43 --> Model Class Initialized
DEBUG - 2011-09-13 07:46:43 --> Model Class Initialized
DEBUG - 2011-09-13 07:46:43 --> Model Class Initialized
DEBUG - 2011-09-13 07:46:43 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-13 07:46:43 --> Database Driver Class Initialized
DEBUG - 2011-09-13 07:46:43 --> File loaded: application/views/table/main.php
DEBUG - 2011-09-13 07:46:43 --> Helper loaded: url_helper
DEBUG - 2011-09-13 07:46:43 --> File loaded: application/views/common/header.php
DEBUG - 2011-09-13 07:46:43 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-09-13 07:46:43 --> File loaded: application/views/common/footer.php
DEBUG - 2011-09-13 07:46:43 --> File loaded: application/views/layout/main.php
DEBUG - 2011-09-13 07:46:43 --> Final output sent to browser
DEBUG - 2011-09-13 07:46:43 --> Total execution time: 0.3923
DEBUG - 2011-09-13 08:49:55 --> Config Class Initialized
DEBUG - 2011-09-13 08:49:55 --> Hooks Class Initialized
DEBUG - 2011-09-13 08:49:55 --> Utf8 Class Initialized
DEBUG - 2011-09-13 08:49:55 --> UTF-8 Support Enabled
DEBUG - 2011-09-13 08:49:55 --> URI Class Initialized
DEBUG - 2011-09-13 08:49:55 --> Router Class Initialized
DEBUG - 2011-09-13 08:49:55 --> Output Class Initialized
DEBUG - 2011-09-13 08:49:55 --> Input Class Initialized
DEBUG - 2011-09-13 08:49:55 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-13 08:49:55 --> Language Class Initialized
DEBUG - 2011-09-13 08:49:55 --> Loader Class Initialized
DEBUG - 2011-09-13 08:49:55 --> Controller Class Initialized
ERROR - 2011-09-13 08:49:55 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-09-13 08:49:55 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-09-13 08:49:55 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-09-13 08:49:55 --> Model Class Initialized
DEBUG - 2011-09-13 08:49:55 --> Model Class Initialized
DEBUG - 2011-09-13 08:49:55 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-13 08:49:55 --> Database Driver Class Initialized
DEBUG - 2011-09-13 08:49:55 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-09-13 08:49:55 --> Helper loaded: url_helper
DEBUG - 2011-09-13 08:49:55 --> File loaded: application/views/common/header.php
DEBUG - 2011-09-13 08:49:55 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-09-13 08:49:55 --> File loaded: application/views/common/footer.php
DEBUG - 2011-09-13 08:49:55 --> File loaded: application/views/layout/main.php
DEBUG - 2011-09-13 08:49:55 --> Final output sent to browser
DEBUG - 2011-09-13 08:49:55 --> Total execution time: 0.0564
DEBUG - 2011-09-13 08:49:56 --> Config Class Initialized
DEBUG - 2011-09-13 08:49:56 --> Hooks Class Initialized
DEBUG - 2011-09-13 08:49:56 --> Utf8 Class Initialized
DEBUG - 2011-09-13 08:49:56 --> UTF-8 Support Enabled
DEBUG - 2011-09-13 08:49:56 --> URI Class Initialized
DEBUG - 2011-09-13 08:49:56 --> Router Class Initialized
DEBUG - 2011-09-13 08:49:56 --> Output Class Initialized
DEBUG - 2011-09-13 08:49:56 --> Input Class Initialized
DEBUG - 2011-09-13 08:49:56 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-13 08:49:56 --> Language Class Initialized
DEBUG - 2011-09-13 08:49:56 --> Loader Class Initialized
DEBUG - 2011-09-13 08:49:56 --> Controller Class Initialized
DEBUG - 2011-09-13 08:49:56 --> Model Class Initialized
DEBUG - 2011-09-13 08:49:56 --> Model Class Initialized
DEBUG - 2011-09-13 08:49:56 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-13 08:49:56 --> Database Driver Class Initialized
DEBUG - 2011-09-13 08:49:56 --> Final output sent to browser
DEBUG - 2011-09-13 08:49:56 --> Total execution time: 0.5827
DEBUG - 2011-09-13 08:49:58 --> Config Class Initialized
DEBUG - 2011-09-13 08:49:58 --> Hooks Class Initialized
DEBUG - 2011-09-13 08:49:58 --> Utf8 Class Initialized
DEBUG - 2011-09-13 08:49:58 --> UTF-8 Support Enabled
DEBUG - 2011-09-13 08:49:58 --> URI Class Initialized
DEBUG - 2011-09-13 08:49:58 --> Router Class Initialized
ERROR - 2011-09-13 08:49:58 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-09-13 08:49:58 --> Config Class Initialized
DEBUG - 2011-09-13 08:49:58 --> Hooks Class Initialized
DEBUG - 2011-09-13 08:49:58 --> Utf8 Class Initialized
DEBUG - 2011-09-13 08:49:58 --> UTF-8 Support Enabled
DEBUG - 2011-09-13 08:49:58 --> URI Class Initialized
DEBUG - 2011-09-13 08:49:58 --> Router Class Initialized
ERROR - 2011-09-13 08:49:58 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-09-13 08:49:58 --> Config Class Initialized
DEBUG - 2011-09-13 08:49:58 --> Hooks Class Initialized
DEBUG - 2011-09-13 08:49:58 --> Utf8 Class Initialized
DEBUG - 2011-09-13 08:49:58 --> UTF-8 Support Enabled
DEBUG - 2011-09-13 08:49:58 --> URI Class Initialized
DEBUG - 2011-09-13 08:49:58 --> Router Class Initialized
ERROR - 2011-09-13 08:49:58 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-09-13 09:06:37 --> Config Class Initialized
DEBUG - 2011-09-13 09:06:37 --> Hooks Class Initialized
DEBUG - 2011-09-13 09:06:37 --> Utf8 Class Initialized
DEBUG - 2011-09-13 09:06:37 --> UTF-8 Support Enabled
DEBUG - 2011-09-13 09:06:37 --> URI Class Initialized
DEBUG - 2011-09-13 09:06:37 --> Router Class Initialized
DEBUG - 2011-09-13 09:06:37 --> Output Class Initialized
DEBUG - 2011-09-13 09:06:37 --> Input Class Initialized
DEBUG - 2011-09-13 09:06:37 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-13 09:06:37 --> Language Class Initialized
DEBUG - 2011-09-13 09:06:37 --> Loader Class Initialized
DEBUG - 2011-09-13 09:06:37 --> Controller Class Initialized
DEBUG - 2011-09-13 09:06:37 --> Model Class Initialized
DEBUG - 2011-09-13 09:06:37 --> Model Class Initialized
DEBUG - 2011-09-13 09:06:37 --> Model Class Initialized
DEBUG - 2011-09-13 09:06:37 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-13 09:06:37 --> Database Driver Class Initialized
DEBUG - 2011-09-13 09:06:39 --> File loaded: application/views/table/main.php
DEBUG - 2011-09-13 09:06:39 --> Helper loaded: url_helper
DEBUG - 2011-09-13 09:06:39 --> File loaded: application/views/common/header.php
DEBUG - 2011-09-13 09:06:39 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-09-13 09:06:39 --> File loaded: application/views/common/footer.php
DEBUG - 2011-09-13 09:06:39 --> File loaded: application/views/layout/main.php
DEBUG - 2011-09-13 09:06:39 --> Final output sent to browser
DEBUG - 2011-09-13 09:06:39 --> Total execution time: 1.9533
DEBUG - 2011-09-13 09:06:40 --> Config Class Initialized
DEBUG - 2011-09-13 09:06:40 --> Hooks Class Initialized
DEBUG - 2011-09-13 09:06:40 --> Utf8 Class Initialized
DEBUG - 2011-09-13 09:06:40 --> UTF-8 Support Enabled
DEBUG - 2011-09-13 09:06:40 --> URI Class Initialized
DEBUG - 2011-09-13 09:06:40 --> Router Class Initialized
DEBUG - 2011-09-13 09:06:40 --> Output Class Initialized
DEBUG - 2011-09-13 09:06:40 --> Input Class Initialized
DEBUG - 2011-09-13 09:06:40 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-13 09:06:40 --> Language Class Initialized
DEBUG - 2011-09-13 09:06:40 --> Loader Class Initialized
DEBUG - 2011-09-13 09:06:40 --> Controller Class Initialized
DEBUG - 2011-09-13 09:06:40 --> Model Class Initialized
DEBUG - 2011-09-13 09:06:40 --> Model Class Initialized
DEBUG - 2011-09-13 09:06:40 --> Model Class Initialized
DEBUG - 2011-09-13 09:06:40 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-13 09:06:40 --> Database Driver Class Initialized
DEBUG - 2011-09-13 09:06:40 --> File loaded: application/views/table/main.php
DEBUG - 2011-09-13 09:06:40 --> Helper loaded: url_helper
DEBUG - 2011-09-13 09:06:40 --> File loaded: application/views/common/header.php
DEBUG - 2011-09-13 09:06:40 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-09-13 09:06:40 --> File loaded: application/views/common/footer.php
DEBUG - 2011-09-13 09:06:40 --> File loaded: application/views/layout/main.php
DEBUG - 2011-09-13 09:06:40 --> Final output sent to browser
DEBUG - 2011-09-13 09:06:40 --> Total execution time: 0.1596
DEBUG - 2011-09-13 09:06:41 --> Config Class Initialized
DEBUG - 2011-09-13 09:06:41 --> Hooks Class Initialized
DEBUG - 2011-09-13 09:06:41 --> Utf8 Class Initialized
DEBUG - 2011-09-13 09:06:41 --> UTF-8 Support Enabled
DEBUG - 2011-09-13 09:06:41 --> URI Class Initialized
DEBUG - 2011-09-13 09:06:41 --> Router Class Initialized
ERROR - 2011-09-13 09:06:41 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-09-13 09:06:42 --> Config Class Initialized
DEBUG - 2011-09-13 09:06:42 --> Hooks Class Initialized
DEBUG - 2011-09-13 09:06:42 --> Utf8 Class Initialized
DEBUG - 2011-09-13 09:06:42 --> UTF-8 Support Enabled
DEBUG - 2011-09-13 09:06:42 --> URI Class Initialized
DEBUG - 2011-09-13 09:06:42 --> Router Class Initialized
ERROR - 2011-09-13 09:06:42 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-09-13 09:52:59 --> Config Class Initialized
DEBUG - 2011-09-13 09:52:59 --> Hooks Class Initialized
DEBUG - 2011-09-13 09:52:59 --> Utf8 Class Initialized
DEBUG - 2011-09-13 09:52:59 --> UTF-8 Support Enabled
DEBUG - 2011-09-13 09:52:59 --> URI Class Initialized
DEBUG - 2011-09-13 09:52:59 --> Router Class Initialized
DEBUG - 2011-09-13 09:52:59 --> Output Class Initialized
DEBUG - 2011-09-13 09:52:59 --> Input Class Initialized
DEBUG - 2011-09-13 09:52:59 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-13 09:52:59 --> Language Class Initialized
DEBUG - 2011-09-13 09:52:59 --> Loader Class Initialized
DEBUG - 2011-09-13 09:52:59 --> Controller Class Initialized
ERROR - 2011-09-13 09:52:59 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-09-13 09:52:59 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-09-13 09:52:59 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-09-13 09:52:59 --> Model Class Initialized
DEBUG - 2011-09-13 09:52:59 --> Model Class Initialized
DEBUG - 2011-09-13 09:52:59 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-13 09:52:59 --> Database Driver Class Initialized
DEBUG - 2011-09-13 09:52:59 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-09-13 09:52:59 --> Helper loaded: url_helper
DEBUG - 2011-09-13 09:52:59 --> File loaded: application/views/common/header.php
DEBUG - 2011-09-13 09:52:59 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-09-13 09:52:59 --> File loaded: application/views/common/footer.php
DEBUG - 2011-09-13 09:52:59 --> File loaded: application/views/layout/main.php
DEBUG - 2011-09-13 09:52:59 --> Final output sent to browser
DEBUG - 2011-09-13 09:52:59 --> Total execution time: 0.1430
DEBUG - 2011-09-13 09:53:03 --> Config Class Initialized
DEBUG - 2011-09-13 09:53:03 --> Hooks Class Initialized
DEBUG - 2011-09-13 09:53:03 --> Utf8 Class Initialized
DEBUG - 2011-09-13 09:53:03 --> UTF-8 Support Enabled
DEBUG - 2011-09-13 09:53:03 --> URI Class Initialized
DEBUG - 2011-09-13 09:53:03 --> Router Class Initialized
DEBUG - 2011-09-13 09:53:03 --> Output Class Initialized
DEBUG - 2011-09-13 09:53:03 --> Input Class Initialized
DEBUG - 2011-09-13 09:53:03 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-13 09:53:03 --> Language Class Initialized
DEBUG - 2011-09-13 09:53:03 --> Loader Class Initialized
DEBUG - 2011-09-13 09:53:03 --> Controller Class Initialized
DEBUG - 2011-09-13 09:53:03 --> Model Class Initialized
DEBUG - 2011-09-13 09:53:03 --> Model Class Initialized
DEBUG - 2011-09-13 09:53:03 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-13 09:53:03 --> Database Driver Class Initialized
DEBUG - 2011-09-13 09:53:03 --> Final output sent to browser
DEBUG - 2011-09-13 09:53:03 --> Total execution time: 0.6720
DEBUG - 2011-09-13 09:58:52 --> Config Class Initialized
DEBUG - 2011-09-13 09:58:52 --> Hooks Class Initialized
DEBUG - 2011-09-13 09:58:52 --> Utf8 Class Initialized
DEBUG - 2011-09-13 09:58:52 --> UTF-8 Support Enabled
DEBUG - 2011-09-13 09:58:52 --> URI Class Initialized
DEBUG - 2011-09-13 09:58:52 --> Router Class Initialized
DEBUG - 2011-09-13 09:58:52 --> Output Class Initialized
DEBUG - 2011-09-13 09:58:52 --> Input Class Initialized
DEBUG - 2011-09-13 09:58:52 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-13 09:58:52 --> Language Class Initialized
DEBUG - 2011-09-13 09:58:52 --> Loader Class Initialized
DEBUG - 2011-09-13 09:58:52 --> Controller Class Initialized
DEBUG - 2011-09-13 09:58:52 --> Model Class Initialized
DEBUG - 2011-09-13 09:58:52 --> Model Class Initialized
DEBUG - 2011-09-13 09:58:52 --> Model Class Initialized
DEBUG - 2011-09-13 09:58:52 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-13 09:58:52 --> Database Driver Class Initialized
DEBUG - 2011-09-13 09:58:53 --> File loaded: application/views/table/main.php
DEBUG - 2011-09-13 09:58:53 --> Helper loaded: url_helper
DEBUG - 2011-09-13 09:58:53 --> File loaded: application/views/common/header.php
DEBUG - 2011-09-13 09:58:53 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-09-13 09:58:53 --> File loaded: application/views/common/footer.php
DEBUG - 2011-09-13 09:58:53 --> File loaded: application/views/layout/main.php
DEBUG - 2011-09-13 09:58:53 --> Final output sent to browser
DEBUG - 2011-09-13 09:58:53 --> Total execution time: 1.0613
DEBUG - 2011-09-13 09:58:55 --> Config Class Initialized
DEBUG - 2011-09-13 09:58:55 --> Hooks Class Initialized
DEBUG - 2011-09-13 09:58:55 --> Utf8 Class Initialized
DEBUG - 2011-09-13 09:58:55 --> UTF-8 Support Enabled
DEBUG - 2011-09-13 09:58:55 --> URI Class Initialized
DEBUG - 2011-09-13 09:58:55 --> Router Class Initialized
ERROR - 2011-09-13 09:58:55 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-09-13 09:58:59 --> Config Class Initialized
DEBUG - 2011-09-13 09:58:59 --> Hooks Class Initialized
DEBUG - 2011-09-13 09:58:59 --> Utf8 Class Initialized
DEBUG - 2011-09-13 09:58:59 --> UTF-8 Support Enabled
DEBUG - 2011-09-13 09:58:59 --> URI Class Initialized
DEBUG - 2011-09-13 09:58:59 --> Router Class Initialized
ERROR - 2011-09-13 09:58:59 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-09-13 09:59:22 --> Config Class Initialized
DEBUG - 2011-09-13 09:59:22 --> Hooks Class Initialized
DEBUG - 2011-09-13 09:59:22 --> Utf8 Class Initialized
DEBUG - 2011-09-13 09:59:22 --> UTF-8 Support Enabled
DEBUG - 2011-09-13 09:59:22 --> URI Class Initialized
DEBUG - 2011-09-13 09:59:22 --> Router Class Initialized
DEBUG - 2011-09-13 09:59:22 --> Output Class Initialized
DEBUG - 2011-09-13 09:59:22 --> Input Class Initialized
DEBUG - 2011-09-13 09:59:22 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-13 09:59:22 --> Language Class Initialized
DEBUG - 2011-09-13 09:59:22 --> Loader Class Initialized
DEBUG - 2011-09-13 09:59:22 --> Controller Class Initialized
DEBUG - 2011-09-13 09:59:22 --> Model Class Initialized
DEBUG - 2011-09-13 09:59:22 --> Model Class Initialized
DEBUG - 2011-09-13 09:59:22 --> Model Class Initialized
DEBUG - 2011-09-13 09:59:22 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-13 09:59:22 --> Database Driver Class Initialized
DEBUG - 2011-09-13 09:59:23 --> File loaded: application/views/table/main.php
DEBUG - 2011-09-13 09:59:23 --> Helper loaded: url_helper
DEBUG - 2011-09-13 09:59:23 --> File loaded: application/views/common/header.php
DEBUG - 2011-09-13 09:59:23 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-09-13 09:59:23 --> File loaded: application/views/common/footer.php
DEBUG - 2011-09-13 09:59:23 --> File loaded: application/views/layout/main.php
DEBUG - 2011-09-13 09:59:23 --> Final output sent to browser
DEBUG - 2011-09-13 09:59:23 --> Total execution time: 0.5399
DEBUG - 2011-09-13 09:59:24 --> Config Class Initialized
DEBUG - 2011-09-13 09:59:24 --> Hooks Class Initialized
DEBUG - 2011-09-13 09:59:24 --> Utf8 Class Initialized
DEBUG - 2011-09-13 09:59:24 --> UTF-8 Support Enabled
DEBUG - 2011-09-13 09:59:24 --> URI Class Initialized
DEBUG - 2011-09-13 09:59:24 --> Router Class Initialized
ERROR - 2011-09-13 09:59:24 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-09-13 09:59:28 --> Config Class Initialized
DEBUG - 2011-09-13 09:59:28 --> Hooks Class Initialized
DEBUG - 2011-09-13 09:59:28 --> Utf8 Class Initialized
DEBUG - 2011-09-13 09:59:28 --> UTF-8 Support Enabled
DEBUG - 2011-09-13 09:59:28 --> URI Class Initialized
DEBUG - 2011-09-13 09:59:28 --> Router Class Initialized
DEBUG - 2011-09-13 09:59:28 --> Output Class Initialized
DEBUG - 2011-09-13 09:59:28 --> Input Class Initialized
DEBUG - 2011-09-13 09:59:28 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-13 09:59:28 --> Language Class Initialized
DEBUG - 2011-09-13 09:59:28 --> Loader Class Initialized
DEBUG - 2011-09-13 09:59:28 --> Controller Class Initialized
DEBUG - 2011-09-13 09:59:28 --> Model Class Initialized
DEBUG - 2011-09-13 09:59:28 --> Model Class Initialized
DEBUG - 2011-09-13 09:59:28 --> Model Class Initialized
DEBUG - 2011-09-13 09:59:28 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-13 09:59:28 --> Database Driver Class Initialized
DEBUG - 2011-09-13 09:59:28 --> File loaded: application/views/table/main.php
DEBUG - 2011-09-13 09:59:28 --> Helper loaded: url_helper
DEBUG - 2011-09-13 09:59:28 --> File loaded: application/views/common/header.php
DEBUG - 2011-09-13 09:59:28 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-09-13 09:59:28 --> File loaded: application/views/common/footer.php
DEBUG - 2011-09-13 09:59:28 --> File loaded: application/views/layout/main.php
DEBUG - 2011-09-13 09:59:28 --> Final output sent to browser
DEBUG - 2011-09-13 09:59:28 --> Total execution time: 0.4289
DEBUG - 2011-09-13 09:59:30 --> Config Class Initialized
DEBUG - 2011-09-13 09:59:30 --> Hooks Class Initialized
DEBUG - 2011-09-13 09:59:30 --> Utf8 Class Initialized
DEBUG - 2011-09-13 09:59:30 --> UTF-8 Support Enabled
DEBUG - 2011-09-13 09:59:30 --> URI Class Initialized
DEBUG - 2011-09-13 09:59:30 --> Router Class Initialized
ERROR - 2011-09-13 09:59:30 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-09-13 09:59:36 --> Config Class Initialized
DEBUG - 2011-09-13 09:59:36 --> Hooks Class Initialized
DEBUG - 2011-09-13 09:59:36 --> Utf8 Class Initialized
DEBUG - 2011-09-13 09:59:36 --> UTF-8 Support Enabled
DEBUG - 2011-09-13 09:59:36 --> URI Class Initialized
DEBUG - 2011-09-13 09:59:36 --> Router Class Initialized
DEBUG - 2011-09-13 09:59:36 --> Output Class Initialized
DEBUG - 2011-09-13 09:59:36 --> Input Class Initialized
DEBUG - 2011-09-13 09:59:36 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-13 09:59:36 --> Language Class Initialized
DEBUG - 2011-09-13 09:59:36 --> Loader Class Initialized
DEBUG - 2011-09-13 09:59:36 --> Controller Class Initialized
DEBUG - 2011-09-13 09:59:36 --> Model Class Initialized
DEBUG - 2011-09-13 09:59:36 --> Model Class Initialized
DEBUG - 2011-09-13 09:59:36 --> Model Class Initialized
DEBUG - 2011-09-13 09:59:36 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-13 09:59:36 --> Database Driver Class Initialized
DEBUG - 2011-09-13 09:59:36 --> File loaded: application/views/table/main.php
DEBUG - 2011-09-13 09:59:36 --> Helper loaded: url_helper
DEBUG - 2011-09-13 09:59:36 --> File loaded: application/views/common/header.php
DEBUG - 2011-09-13 09:59:36 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-09-13 09:59:36 --> File loaded: application/views/common/footer.php
DEBUG - 2011-09-13 09:59:36 --> File loaded: application/views/layout/main.php
DEBUG - 2011-09-13 09:59:36 --> Final output sent to browser
DEBUG - 2011-09-13 09:59:36 --> Total execution time: 0.3752
DEBUG - 2011-09-13 09:59:38 --> Config Class Initialized
DEBUG - 2011-09-13 09:59:38 --> Hooks Class Initialized
DEBUG - 2011-09-13 09:59:38 --> Utf8 Class Initialized
DEBUG - 2011-09-13 09:59:38 --> UTF-8 Support Enabled
DEBUG - 2011-09-13 09:59:38 --> URI Class Initialized
DEBUG - 2011-09-13 09:59:38 --> Router Class Initialized
ERROR - 2011-09-13 09:59:38 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-09-13 09:59:44 --> Config Class Initialized
DEBUG - 2011-09-13 09:59:44 --> Hooks Class Initialized
DEBUG - 2011-09-13 09:59:44 --> Utf8 Class Initialized
DEBUG - 2011-09-13 09:59:44 --> UTF-8 Support Enabled
DEBUG - 2011-09-13 09:59:44 --> URI Class Initialized
DEBUG - 2011-09-13 09:59:44 --> Router Class Initialized
DEBUG - 2011-09-13 09:59:44 --> Output Class Initialized
DEBUG - 2011-09-13 09:59:44 --> Input Class Initialized
DEBUG - 2011-09-13 09:59:44 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-13 09:59:44 --> Language Class Initialized
DEBUG - 2011-09-13 09:59:44 --> Loader Class Initialized
DEBUG - 2011-09-13 09:59:44 --> Controller Class Initialized
DEBUG - 2011-09-13 09:59:44 --> Model Class Initialized
DEBUG - 2011-09-13 09:59:44 --> Model Class Initialized
DEBUG - 2011-09-13 09:59:44 --> Model Class Initialized
DEBUG - 2011-09-13 09:59:44 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-13 09:59:44 --> Database Driver Class Initialized
DEBUG - 2011-09-13 09:59:44 --> File loaded: application/views/table/main.php
DEBUG - 2011-09-13 09:59:44 --> Helper loaded: url_helper
DEBUG - 2011-09-13 09:59:44 --> File loaded: application/views/common/header.php
DEBUG - 2011-09-13 09:59:44 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-09-13 09:59:44 --> File loaded: application/views/common/footer.php
DEBUG - 2011-09-13 09:59:44 --> File loaded: application/views/layout/main.php
DEBUG - 2011-09-13 09:59:44 --> Final output sent to browser
DEBUG - 2011-09-13 09:59:44 --> Total execution time: 0.5467
DEBUG - 2011-09-13 09:59:45 --> Config Class Initialized
DEBUG - 2011-09-13 09:59:45 --> Hooks Class Initialized
DEBUG - 2011-09-13 09:59:45 --> Utf8 Class Initialized
DEBUG - 2011-09-13 09:59:45 --> UTF-8 Support Enabled
DEBUG - 2011-09-13 09:59:45 --> URI Class Initialized
DEBUG - 2011-09-13 09:59:45 --> Router Class Initialized
ERROR - 2011-09-13 09:59:45 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-09-13 09:59:51 --> Config Class Initialized
DEBUG - 2011-09-13 09:59:51 --> Hooks Class Initialized
DEBUG - 2011-09-13 09:59:51 --> Utf8 Class Initialized
DEBUG - 2011-09-13 09:59:51 --> UTF-8 Support Enabled
DEBUG - 2011-09-13 09:59:51 --> URI Class Initialized
DEBUG - 2011-09-13 09:59:51 --> Router Class Initialized
DEBUG - 2011-09-13 09:59:51 --> Output Class Initialized
DEBUG - 2011-09-13 09:59:51 --> Input Class Initialized
DEBUG - 2011-09-13 09:59:51 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-13 09:59:51 --> Language Class Initialized
DEBUG - 2011-09-13 09:59:51 --> Loader Class Initialized
DEBUG - 2011-09-13 09:59:51 --> Controller Class Initialized
DEBUG - 2011-09-13 09:59:51 --> Model Class Initialized
DEBUG - 2011-09-13 09:59:51 --> Model Class Initialized
DEBUG - 2011-09-13 09:59:51 --> Model Class Initialized
DEBUG - 2011-09-13 09:59:51 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-13 09:59:51 --> Database Driver Class Initialized
DEBUG - 2011-09-13 09:59:52 --> File loaded: application/views/table/main.php
DEBUG - 2011-09-13 09:59:52 --> Helper loaded: url_helper
DEBUG - 2011-09-13 09:59:52 --> File loaded: application/views/common/header.php
DEBUG - 2011-09-13 09:59:52 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-09-13 09:59:52 --> File loaded: application/views/common/footer.php
DEBUG - 2011-09-13 09:59:52 --> File loaded: application/views/layout/main.php
DEBUG - 2011-09-13 09:59:52 --> Final output sent to browser
DEBUG - 2011-09-13 09:59:52 --> Total execution time: 0.3533
DEBUG - 2011-09-13 09:59:53 --> Config Class Initialized
DEBUG - 2011-09-13 09:59:53 --> Hooks Class Initialized
DEBUG - 2011-09-13 09:59:53 --> Utf8 Class Initialized
DEBUG - 2011-09-13 09:59:53 --> UTF-8 Support Enabled
DEBUG - 2011-09-13 09:59:53 --> URI Class Initialized
DEBUG - 2011-09-13 09:59:53 --> Router Class Initialized
ERROR - 2011-09-13 09:59:53 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-09-13 09:59:56 --> Config Class Initialized
DEBUG - 2011-09-13 09:59:56 --> Hooks Class Initialized
DEBUG - 2011-09-13 09:59:56 --> Utf8 Class Initialized
DEBUG - 2011-09-13 09:59:56 --> UTF-8 Support Enabled
DEBUG - 2011-09-13 09:59:56 --> URI Class Initialized
DEBUG - 2011-09-13 09:59:56 --> Router Class Initialized
DEBUG - 2011-09-13 09:59:56 --> Output Class Initialized
DEBUG - 2011-09-13 09:59:56 --> Input Class Initialized
DEBUG - 2011-09-13 09:59:56 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-13 09:59:56 --> Language Class Initialized
DEBUG - 2011-09-13 09:59:56 --> Loader Class Initialized
DEBUG - 2011-09-13 09:59:56 --> Controller Class Initialized
ERROR - 2011-09-13 09:59:56 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-09-13 09:59:56 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-09-13 09:59:56 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-09-13 09:59:56 --> Model Class Initialized
DEBUG - 2011-09-13 09:59:56 --> Model Class Initialized
DEBUG - 2011-09-13 09:59:56 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-13 09:59:56 --> Database Driver Class Initialized
DEBUG - 2011-09-13 09:59:56 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-09-13 09:59:56 --> Helper loaded: url_helper
DEBUG - 2011-09-13 09:59:56 --> File loaded: application/views/common/header.php
DEBUG - 2011-09-13 09:59:56 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-09-13 09:59:56 --> File loaded: application/views/common/footer.php
DEBUG - 2011-09-13 09:59:56 --> File loaded: application/views/layout/main.php
DEBUG - 2011-09-13 09:59:56 --> Final output sent to browser
DEBUG - 2011-09-13 09:59:56 --> Total execution time: 0.0292
DEBUG - 2011-09-13 09:59:57 --> Config Class Initialized
DEBUG - 2011-09-13 09:59:57 --> Hooks Class Initialized
DEBUG - 2011-09-13 09:59:57 --> Utf8 Class Initialized
DEBUG - 2011-09-13 09:59:57 --> UTF-8 Support Enabled
DEBUG - 2011-09-13 09:59:57 --> URI Class Initialized
DEBUG - 2011-09-13 09:59:57 --> Router Class Initialized
DEBUG - 2011-09-13 09:59:57 --> Output Class Initialized
DEBUG - 2011-09-13 09:59:57 --> Input Class Initialized
DEBUG - 2011-09-13 09:59:57 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-13 09:59:57 --> Language Class Initialized
DEBUG - 2011-09-13 09:59:57 --> Loader Class Initialized
DEBUG - 2011-09-13 09:59:57 --> Controller Class Initialized
DEBUG - 2011-09-13 09:59:57 --> Model Class Initialized
DEBUG - 2011-09-13 09:59:57 --> Model Class Initialized
DEBUG - 2011-09-13 09:59:57 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-13 09:59:57 --> Database Driver Class Initialized
DEBUG - 2011-09-13 09:59:58 --> Final output sent to browser
DEBUG - 2011-09-13 09:59:58 --> Total execution time: 0.7128
DEBUG - 2011-09-13 10:14:19 --> Config Class Initialized
DEBUG - 2011-09-13 10:14:19 --> Hooks Class Initialized
DEBUG - 2011-09-13 10:14:19 --> Utf8 Class Initialized
DEBUG - 2011-09-13 10:14:19 --> UTF-8 Support Enabled
DEBUG - 2011-09-13 10:14:19 --> URI Class Initialized
DEBUG - 2011-09-13 10:14:19 --> Router Class Initialized
DEBUG - 2011-09-13 10:14:19 --> Output Class Initialized
DEBUG - 2011-09-13 10:14:19 --> Input Class Initialized
DEBUG - 2011-09-13 10:14:19 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-13 10:14:19 --> Language Class Initialized
DEBUG - 2011-09-13 10:14:19 --> Loader Class Initialized
DEBUG - 2011-09-13 10:14:19 --> Controller Class Initialized
ERROR - 2011-09-13 10:14:19 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-09-13 10:14:19 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-09-13 10:14:19 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-09-13 10:14:19 --> Model Class Initialized
DEBUG - 2011-09-13 10:14:19 --> Model Class Initialized
DEBUG - 2011-09-13 10:14:19 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-13 10:14:19 --> Database Driver Class Initialized
DEBUG - 2011-09-13 10:14:19 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-09-13 10:14:19 --> Helper loaded: url_helper
DEBUG - 2011-09-13 10:14:19 --> File loaded: application/views/common/header.php
DEBUG - 2011-09-13 10:14:19 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-09-13 10:14:19 --> File loaded: application/views/common/footer.php
DEBUG - 2011-09-13 10:14:19 --> File loaded: application/views/layout/main.php
DEBUG - 2011-09-13 10:14:19 --> Final output sent to browser
DEBUG - 2011-09-13 10:14:19 --> Total execution time: 0.0294
DEBUG - 2011-09-13 10:14:20 --> Config Class Initialized
DEBUG - 2011-09-13 10:14:20 --> Hooks Class Initialized
DEBUG - 2011-09-13 10:14:20 --> Utf8 Class Initialized
DEBUG - 2011-09-13 10:14:20 --> UTF-8 Support Enabled
DEBUG - 2011-09-13 10:14:20 --> URI Class Initialized
DEBUG - 2011-09-13 10:14:20 --> Router Class Initialized
DEBUG - 2011-09-13 10:14:20 --> Output Class Initialized
DEBUG - 2011-09-13 10:14:20 --> Input Class Initialized
DEBUG - 2011-09-13 10:14:20 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-13 10:14:20 --> Language Class Initialized
DEBUG - 2011-09-13 10:14:20 --> Loader Class Initialized
DEBUG - 2011-09-13 10:14:20 --> Controller Class Initialized
DEBUG - 2011-09-13 10:14:20 --> Model Class Initialized
DEBUG - 2011-09-13 10:14:20 --> Model Class Initialized
DEBUG - 2011-09-13 10:14:20 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-13 10:14:20 --> Database Driver Class Initialized
DEBUG - 2011-09-13 10:14:21 --> Final output sent to browser
DEBUG - 2011-09-13 10:14:21 --> Total execution time: 0.6708
DEBUG - 2011-09-13 10:14:22 --> Config Class Initialized
DEBUG - 2011-09-13 10:14:22 --> Hooks Class Initialized
DEBUG - 2011-09-13 10:14:22 --> Utf8 Class Initialized
DEBUG - 2011-09-13 10:14:22 --> UTF-8 Support Enabled
DEBUG - 2011-09-13 10:14:22 --> URI Class Initialized
DEBUG - 2011-09-13 10:14:22 --> Router Class Initialized
ERROR - 2011-09-13 10:14:22 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-09-13 10:14:49 --> Config Class Initialized
DEBUG - 2011-09-13 10:14:49 --> Hooks Class Initialized
DEBUG - 2011-09-13 10:14:49 --> Utf8 Class Initialized
DEBUG - 2011-09-13 10:14:49 --> UTF-8 Support Enabled
DEBUG - 2011-09-13 10:14:49 --> URI Class Initialized
DEBUG - 2011-09-13 10:14:49 --> Router Class Initialized
DEBUG - 2011-09-13 10:14:49 --> Output Class Initialized
DEBUG - 2011-09-13 10:14:49 --> Input Class Initialized
DEBUG - 2011-09-13 10:14:49 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-13 10:14:49 --> Language Class Initialized
DEBUG - 2011-09-13 10:14:49 --> Loader Class Initialized
DEBUG - 2011-09-13 10:14:49 --> Controller Class Initialized
ERROR - 2011-09-13 10:14:49 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-09-13 10:14:49 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-09-13 10:14:49 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-09-13 10:14:49 --> Model Class Initialized
DEBUG - 2011-09-13 10:14:49 --> Model Class Initialized
DEBUG - 2011-09-13 10:14:49 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-13 10:14:49 --> Database Driver Class Initialized
DEBUG - 2011-09-13 10:14:49 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-09-13 10:14:49 --> Helper loaded: url_helper
DEBUG - 2011-09-13 10:14:49 --> File loaded: application/views/common/header.php
DEBUG - 2011-09-13 10:14:49 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-09-13 10:14:49 --> File loaded: application/views/common/footer.php
DEBUG - 2011-09-13 10:14:49 --> File loaded: application/views/layout/main.php
DEBUG - 2011-09-13 10:14:49 --> Final output sent to browser
DEBUG - 2011-09-13 10:14:49 --> Total execution time: 0.0318
DEBUG - 2011-09-13 10:14:49 --> Config Class Initialized
DEBUG - 2011-09-13 10:14:49 --> Hooks Class Initialized
DEBUG - 2011-09-13 10:14:49 --> Utf8 Class Initialized
DEBUG - 2011-09-13 10:14:49 --> UTF-8 Support Enabled
DEBUG - 2011-09-13 10:14:49 --> URI Class Initialized
DEBUG - 2011-09-13 10:14:49 --> Router Class Initialized
DEBUG - 2011-09-13 10:14:49 --> Output Class Initialized
DEBUG - 2011-09-13 10:14:49 --> Input Class Initialized
DEBUG - 2011-09-13 10:14:49 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-13 10:14:49 --> Language Class Initialized
DEBUG - 2011-09-13 10:14:49 --> Loader Class Initialized
DEBUG - 2011-09-13 10:14:49 --> Controller Class Initialized
DEBUG - 2011-09-13 10:14:49 --> Model Class Initialized
DEBUG - 2011-09-13 10:14:49 --> Model Class Initialized
DEBUG - 2011-09-13 10:14:49 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-13 10:14:49 --> Database Driver Class Initialized
DEBUG - 2011-09-13 10:14:50 --> Final output sent to browser
DEBUG - 2011-09-13 10:14:50 --> Total execution time: 0.7201
DEBUG - 2011-09-13 10:14:55 --> Config Class Initialized
DEBUG - 2011-09-13 10:14:55 --> Hooks Class Initialized
DEBUG - 2011-09-13 10:14:55 --> Utf8 Class Initialized
DEBUG - 2011-09-13 10:14:55 --> UTF-8 Support Enabled
DEBUG - 2011-09-13 10:14:55 --> URI Class Initialized
DEBUG - 2011-09-13 10:14:55 --> Router Class Initialized
ERROR - 2011-09-13 10:14:55 --> 404 Page Not Found --> robots.txt
DEBUG - 2011-09-13 10:14:55 --> Config Class Initialized
DEBUG - 2011-09-13 10:14:55 --> Hooks Class Initialized
DEBUG - 2011-09-13 10:14:55 --> Utf8 Class Initialized
DEBUG - 2011-09-13 10:14:55 --> UTF-8 Support Enabled
DEBUG - 2011-09-13 10:14:55 --> URI Class Initialized
DEBUG - 2011-09-13 10:14:55 --> Router Class Initialized
DEBUG - 2011-09-13 10:14:55 --> Output Class Initialized
DEBUG - 2011-09-13 10:14:55 --> Input Class Initialized
DEBUG - 2011-09-13 10:14:55 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-13 10:14:55 --> Language Class Initialized
DEBUG - 2011-09-13 10:14:55 --> Loader Class Initialized
DEBUG - 2011-09-13 10:14:55 --> Controller Class Initialized
ERROR - 2011-09-13 10:14:55 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-09-13 10:14:55 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-09-13 10:14:55 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-09-13 10:14:55 --> Model Class Initialized
DEBUG - 2011-09-13 10:14:55 --> Model Class Initialized
DEBUG - 2011-09-13 10:14:55 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-13 10:14:55 --> Database Driver Class Initialized
DEBUG - 2011-09-13 10:14:55 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-09-13 10:14:55 --> Helper loaded: url_helper
DEBUG - 2011-09-13 10:14:55 --> File loaded: application/views/common/header.php
DEBUG - 2011-09-13 10:14:55 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-09-13 10:14:55 --> File loaded: application/views/common/footer.php
DEBUG - 2011-09-13 10:14:55 --> File loaded: application/views/layout/main.php
DEBUG - 2011-09-13 10:14:55 --> Final output sent to browser
DEBUG - 2011-09-13 10:14:55 --> Total execution time: 0.0277
DEBUG - 2011-09-13 10:15:09 --> Config Class Initialized
DEBUG - 2011-09-13 10:15:09 --> Hooks Class Initialized
DEBUG - 2011-09-13 10:15:09 --> Utf8 Class Initialized
DEBUG - 2011-09-13 10:15:09 --> UTF-8 Support Enabled
DEBUG - 2011-09-13 10:15:09 --> URI Class Initialized
DEBUG - 2011-09-13 10:15:09 --> Router Class Initialized
DEBUG - 2011-09-13 10:15:09 --> Output Class Initialized
DEBUG - 2011-09-13 10:15:09 --> Input Class Initialized
DEBUG - 2011-09-13 10:15:09 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-13 10:15:09 --> Language Class Initialized
DEBUG - 2011-09-13 10:15:09 --> Loader Class Initialized
DEBUG - 2011-09-13 10:15:09 --> Controller Class Initialized
ERROR - 2011-09-13 10:15:09 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-09-13 10:15:09 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-09-13 10:15:09 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-09-13 10:15:09 --> Model Class Initialized
DEBUG - 2011-09-13 10:15:09 --> Model Class Initialized
DEBUG - 2011-09-13 10:15:09 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-13 10:15:09 --> Database Driver Class Initialized
DEBUG - 2011-09-13 10:15:09 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-09-13 10:15:09 --> Helper loaded: url_helper
DEBUG - 2011-09-13 10:15:09 --> File loaded: application/views/common/header.php
DEBUG - 2011-09-13 10:15:09 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-09-13 10:15:09 --> File loaded: application/views/common/footer.php
DEBUG - 2011-09-13 10:15:09 --> File loaded: application/views/layout/main.php
DEBUG - 2011-09-13 10:15:09 --> Final output sent to browser
DEBUG - 2011-09-13 10:15:09 --> Total execution time: 0.0568
DEBUG - 2011-09-13 10:15:10 --> Config Class Initialized
DEBUG - 2011-09-13 10:15:10 --> Hooks Class Initialized
DEBUG - 2011-09-13 10:15:10 --> Utf8 Class Initialized
DEBUG - 2011-09-13 10:15:10 --> UTF-8 Support Enabled
DEBUG - 2011-09-13 10:15:10 --> URI Class Initialized
DEBUG - 2011-09-13 10:15:10 --> Router Class Initialized
DEBUG - 2011-09-13 10:15:10 --> Output Class Initialized
DEBUG - 2011-09-13 10:15:10 --> Input Class Initialized
DEBUG - 2011-09-13 10:15:10 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-13 10:15:10 --> Language Class Initialized
DEBUG - 2011-09-13 10:15:10 --> Loader Class Initialized
DEBUG - 2011-09-13 10:15:10 --> Controller Class Initialized
DEBUG - 2011-09-13 10:15:10 --> Model Class Initialized
DEBUG - 2011-09-13 10:15:10 --> Model Class Initialized
DEBUG - 2011-09-13 10:15:10 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-13 10:15:10 --> Database Driver Class Initialized
DEBUG - 2011-09-13 10:15:11 --> Final output sent to browser
DEBUG - 2011-09-13 10:15:11 --> Total execution time: 0.6504
DEBUG - 2011-09-13 10:55:35 --> Config Class Initialized
DEBUG - 2011-09-13 10:55:35 --> Hooks Class Initialized
DEBUG - 2011-09-13 10:55:35 --> Utf8 Class Initialized
DEBUG - 2011-09-13 10:55:35 --> UTF-8 Support Enabled
DEBUG - 2011-09-13 10:55:35 --> URI Class Initialized
DEBUG - 2011-09-13 10:55:35 --> Router Class Initialized
DEBUG - 2011-09-13 10:55:35 --> Output Class Initialized
DEBUG - 2011-09-13 10:55:35 --> Input Class Initialized
DEBUG - 2011-09-13 10:55:35 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-13 10:55:35 --> Language Class Initialized
DEBUG - 2011-09-13 10:55:35 --> Loader Class Initialized
DEBUG - 2011-09-13 10:55:35 --> Controller Class Initialized
ERROR - 2011-09-13 10:55:35 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-09-13 10:55:35 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-09-13 10:55:35 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-09-13 10:55:35 --> Model Class Initialized
DEBUG - 2011-09-13 10:55:35 --> Model Class Initialized
DEBUG - 2011-09-13 10:55:35 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-13 10:55:35 --> Database Driver Class Initialized
DEBUG - 2011-09-13 10:55:35 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-09-13 10:55:35 --> Helper loaded: url_helper
DEBUG - 2011-09-13 10:55:35 --> File loaded: application/views/common/header.php
DEBUG - 2011-09-13 10:55:35 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-09-13 10:55:35 --> File loaded: application/views/common/footer.php
DEBUG - 2011-09-13 10:55:35 --> File loaded: application/views/layout/main.php
DEBUG - 2011-09-13 10:55:35 --> Final output sent to browser
DEBUG - 2011-09-13 10:55:35 --> Total execution time: 0.0428
DEBUG - 2011-09-13 10:55:36 --> Config Class Initialized
DEBUG - 2011-09-13 10:55:36 --> Hooks Class Initialized
DEBUG - 2011-09-13 10:55:36 --> Utf8 Class Initialized
DEBUG - 2011-09-13 10:55:36 --> UTF-8 Support Enabled
DEBUG - 2011-09-13 10:55:36 --> URI Class Initialized
DEBUG - 2011-09-13 10:55:36 --> Router Class Initialized
DEBUG - 2011-09-13 10:55:36 --> Output Class Initialized
DEBUG - 2011-09-13 10:55:36 --> Input Class Initialized
DEBUG - 2011-09-13 10:55:36 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-13 10:55:36 --> Language Class Initialized
DEBUG - 2011-09-13 10:55:36 --> Loader Class Initialized
DEBUG - 2011-09-13 10:55:36 --> Controller Class Initialized
DEBUG - 2011-09-13 10:55:36 --> Model Class Initialized
DEBUG - 2011-09-13 10:55:36 --> Model Class Initialized
DEBUG - 2011-09-13 10:55:36 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-13 10:55:36 --> Database Driver Class Initialized
DEBUG - 2011-09-13 10:55:36 --> Final output sent to browser
DEBUG - 2011-09-13 10:55:36 --> Total execution time: 0.6493
DEBUG - 2011-09-13 10:55:37 --> Config Class Initialized
DEBUG - 2011-09-13 10:55:37 --> Hooks Class Initialized
DEBUG - 2011-09-13 10:55:37 --> Utf8 Class Initialized
DEBUG - 2011-09-13 10:55:37 --> UTF-8 Support Enabled
DEBUG - 2011-09-13 10:55:37 --> URI Class Initialized
DEBUG - 2011-09-13 10:55:37 --> Router Class Initialized
ERROR - 2011-09-13 10:55:37 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-09-13 10:55:37 --> Config Class Initialized
DEBUG - 2011-09-13 10:55:37 --> Hooks Class Initialized
DEBUG - 2011-09-13 10:55:37 --> Utf8 Class Initialized
DEBUG - 2011-09-13 10:55:37 --> UTF-8 Support Enabled
DEBUG - 2011-09-13 10:55:37 --> URI Class Initialized
DEBUG - 2011-09-13 10:55:37 --> Router Class Initialized
ERROR - 2011-09-13 10:55:37 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-09-13 10:55:38 --> Config Class Initialized
DEBUG - 2011-09-13 10:55:38 --> Hooks Class Initialized
DEBUG - 2011-09-13 10:55:38 --> Utf8 Class Initialized
DEBUG - 2011-09-13 10:55:38 --> UTF-8 Support Enabled
DEBUG - 2011-09-13 10:55:38 --> URI Class Initialized
DEBUG - 2011-09-13 10:55:38 --> Router Class Initialized
ERROR - 2011-09-13 10:55:38 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-09-13 11:10:38 --> Config Class Initialized
DEBUG - 2011-09-13 11:10:38 --> Hooks Class Initialized
DEBUG - 2011-09-13 11:10:38 --> Utf8 Class Initialized
DEBUG - 2011-09-13 11:10:38 --> UTF-8 Support Enabled
DEBUG - 2011-09-13 11:10:38 --> URI Class Initialized
DEBUG - 2011-09-13 11:10:38 --> Router Class Initialized
DEBUG - 2011-09-13 11:10:38 --> Output Class Initialized
DEBUG - 2011-09-13 11:10:38 --> Input Class Initialized
DEBUG - 2011-09-13 11:10:38 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-13 11:10:38 --> Language Class Initialized
DEBUG - 2011-09-13 11:10:38 --> Loader Class Initialized
DEBUG - 2011-09-13 11:10:38 --> Controller Class Initialized
DEBUG - 2011-09-13 11:10:38 --> Model Class Initialized
DEBUG - 2011-09-13 11:10:38 --> Model Class Initialized
DEBUG - 2011-09-13 11:10:38 --> Model Class Initialized
DEBUG - 2011-09-13 11:10:38 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-13 11:10:38 --> Database Driver Class Initialized
DEBUG - 2011-09-13 11:10:38 --> File loaded: application/views/table/main.php
DEBUG - 2011-09-13 11:10:38 --> Helper loaded: url_helper
DEBUG - 2011-09-13 11:10:38 --> File loaded: application/views/common/header.php
DEBUG - 2011-09-13 11:10:38 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-09-13 11:10:38 --> File loaded: application/views/common/footer.php
DEBUG - 2011-09-13 11:10:38 --> File loaded: application/views/layout/main.php
DEBUG - 2011-09-13 11:10:38 --> Final output sent to browser
DEBUG - 2011-09-13 11:10:38 --> Total execution time: 0.2948
DEBUG - 2011-09-13 11:13:48 --> Config Class Initialized
DEBUG - 2011-09-13 11:13:48 --> Hooks Class Initialized
DEBUG - 2011-09-13 11:13:48 --> Utf8 Class Initialized
DEBUG - 2011-09-13 11:13:48 --> UTF-8 Support Enabled
DEBUG - 2011-09-13 11:13:48 --> URI Class Initialized
DEBUG - 2011-09-13 11:13:48 --> Router Class Initialized
DEBUG - 2011-09-13 11:13:48 --> No URI present. Default controller set.
DEBUG - 2011-09-13 11:13:48 --> Output Class Initialized
DEBUG - 2011-09-13 11:13:48 --> Input Class Initialized
DEBUG - 2011-09-13 11:13:48 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-13 11:13:48 --> Language Class Initialized
DEBUG - 2011-09-13 11:13:48 --> Loader Class Initialized
DEBUG - 2011-09-13 11:13:48 --> Controller Class Initialized
DEBUG - 2011-09-13 11:13:48 --> File loaded: application/views/splash/main.php
DEBUG - 2011-09-13 11:13:48 --> Helper loaded: url_helper
DEBUG - 2011-09-13 11:13:48 --> File loaded: application/views/common/header.php
DEBUG - 2011-09-13 11:13:48 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-09-13 11:13:48 --> File loaded: application/views/common/footer.php
DEBUG - 2011-09-13 11:13:48 --> File loaded: application/views/layout/main.php
DEBUG - 2011-09-13 11:13:48 --> Final output sent to browser
DEBUG - 2011-09-13 11:13:48 --> Total execution time: 0.0643
DEBUG - 2011-09-13 11:21:56 --> Config Class Initialized
DEBUG - 2011-09-13 11:21:56 --> Hooks Class Initialized
DEBUG - 2011-09-13 11:21:56 --> Utf8 Class Initialized
DEBUG - 2011-09-13 11:21:56 --> UTF-8 Support Enabled
DEBUG - 2011-09-13 11:21:56 --> URI Class Initialized
DEBUG - 2011-09-13 11:21:56 --> Router Class Initialized
ERROR - 2011-09-13 11:21:56 --> 404 Page Not Found --> robots.txt
DEBUG - 2011-09-13 11:22:35 --> Config Class Initialized
DEBUG - 2011-09-13 11:22:35 --> Hooks Class Initialized
DEBUG - 2011-09-13 11:22:35 --> Utf8 Class Initialized
DEBUG - 2011-09-13 11:22:35 --> UTF-8 Support Enabled
DEBUG - 2011-09-13 11:22:35 --> URI Class Initialized
DEBUG - 2011-09-13 11:22:35 --> Router Class Initialized
DEBUG - 2011-09-13 11:22:35 --> Output Class Initialized
DEBUG - 2011-09-13 11:22:35 --> Input Class Initialized
DEBUG - 2011-09-13 11:22:35 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-13 11:22:35 --> Language Class Initialized
DEBUG - 2011-09-13 11:22:35 --> Loader Class Initialized
DEBUG - 2011-09-13 11:22:35 --> Controller Class Initialized
DEBUG - 2011-09-13 11:22:35 --> Model Class Initialized
DEBUG - 2011-09-13 11:22:35 --> Model Class Initialized
DEBUG - 2011-09-13 11:22:35 --> Model Class Initialized
DEBUG - 2011-09-13 11:22:35 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-13 11:22:35 --> Database Driver Class Initialized
DEBUG - 2011-09-13 11:22:35 --> File loaded: application/views/table/main.php
DEBUG - 2011-09-13 11:22:35 --> Helper loaded: url_helper
DEBUG - 2011-09-13 11:22:35 --> File loaded: application/views/common/header.php
DEBUG - 2011-09-13 11:22:35 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-09-13 11:22:35 --> File loaded: application/views/common/footer.php
DEBUG - 2011-09-13 11:22:35 --> File loaded: application/views/layout/main.php
DEBUG - 2011-09-13 11:22:35 --> Final output sent to browser
DEBUG - 2011-09-13 11:22:35 --> Total execution time: 0.0436
DEBUG - 2011-09-13 12:00:34 --> Config Class Initialized
DEBUG - 2011-09-13 12:00:34 --> Hooks Class Initialized
DEBUG - 2011-09-13 12:00:34 --> Utf8 Class Initialized
DEBUG - 2011-09-13 12:00:34 --> UTF-8 Support Enabled
DEBUG - 2011-09-13 12:00:34 --> URI Class Initialized
DEBUG - 2011-09-13 12:00:34 --> Router Class Initialized
DEBUG - 2011-09-13 12:00:34 --> Output Class Initialized
DEBUG - 2011-09-13 12:00:34 --> Input Class Initialized
DEBUG - 2011-09-13 12:00:34 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-13 12:00:34 --> Language Class Initialized
DEBUG - 2011-09-13 12:00:34 --> Loader Class Initialized
DEBUG - 2011-09-13 12:00:34 --> Controller Class Initialized
ERROR - 2011-09-13 12:00:34 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-09-13 12:00:34 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-09-13 12:00:34 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-09-13 12:00:34 --> Model Class Initialized
DEBUG - 2011-09-13 12:00:34 --> Model Class Initialized
DEBUG - 2011-09-13 12:00:34 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-13 12:00:34 --> Database Driver Class Initialized
DEBUG - 2011-09-13 12:00:34 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-09-13 12:00:34 --> Helper loaded: url_helper
DEBUG - 2011-09-13 12:00:34 --> File loaded: application/views/common/header.php
DEBUG - 2011-09-13 12:00:34 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-09-13 12:00:34 --> File loaded: application/views/common/footer.php
DEBUG - 2011-09-13 12:00:34 --> File loaded: application/views/layout/main.php
DEBUG - 2011-09-13 12:00:34 --> Final output sent to browser
DEBUG - 2011-09-13 12:00:34 --> Total execution time: 0.3541
DEBUG - 2011-09-13 12:25:52 --> Config Class Initialized
DEBUG - 2011-09-13 12:25:52 --> Hooks Class Initialized
DEBUG - 2011-09-13 12:25:52 --> Utf8 Class Initialized
DEBUG - 2011-09-13 12:25:52 --> UTF-8 Support Enabled
DEBUG - 2011-09-13 12:25:52 --> URI Class Initialized
DEBUG - 2011-09-13 12:25:52 --> Router Class Initialized
DEBUG - 2011-09-13 12:25:52 --> Output Class Initialized
DEBUG - 2011-09-13 12:25:52 --> Input Class Initialized
DEBUG - 2011-09-13 12:25:52 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-13 12:25:52 --> Language Class Initialized
DEBUG - 2011-09-13 12:25:52 --> Loader Class Initialized
DEBUG - 2011-09-13 12:25:52 --> Controller Class Initialized
ERROR - 2011-09-13 12:25:52 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-09-13 12:25:52 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-09-13 12:25:52 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-09-13 12:25:52 --> Model Class Initialized
DEBUG - 2011-09-13 12:25:52 --> Model Class Initialized
DEBUG - 2011-09-13 12:25:52 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-13 12:25:52 --> Database Driver Class Initialized
DEBUG - 2011-09-13 12:25:52 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-09-13 12:25:52 --> Helper loaded: url_helper
DEBUG - 2011-09-13 12:25:52 --> File loaded: application/views/common/header.php
DEBUG - 2011-09-13 12:25:52 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-09-13 12:25:52 --> File loaded: application/views/common/footer.php
DEBUG - 2011-09-13 12:25:52 --> File loaded: application/views/layout/main.php
DEBUG - 2011-09-13 12:25:52 --> Final output sent to browser
DEBUG - 2011-09-13 12:25:52 --> Total execution time: 0.0369
DEBUG - 2011-09-13 13:11:21 --> Config Class Initialized
DEBUG - 2011-09-13 13:11:21 --> Hooks Class Initialized
DEBUG - 2011-09-13 13:11:21 --> Utf8 Class Initialized
DEBUG - 2011-09-13 13:11:21 --> UTF-8 Support Enabled
DEBUG - 2011-09-13 13:11:21 --> URI Class Initialized
DEBUG - 2011-09-13 13:11:21 --> Router Class Initialized
DEBUG - 2011-09-13 13:11:21 --> Output Class Initialized
DEBUG - 2011-09-13 13:11:21 --> Input Class Initialized
DEBUG - 2011-09-13 13:11:21 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-13 13:11:21 --> Language Class Initialized
DEBUG - 2011-09-13 13:11:21 --> Loader Class Initialized
DEBUG - 2011-09-13 13:11:21 --> Controller Class Initialized
DEBUG - 2011-09-13 13:11:21 --> Model Class Initialized
DEBUG - 2011-09-13 13:11:21 --> Model Class Initialized
DEBUG - 2011-09-13 13:11:21 --> Model Class Initialized
DEBUG - 2011-09-13 13:11:21 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-13 13:11:21 --> Database Driver Class Initialized
DEBUG - 2011-09-13 13:11:21 --> File loaded: application/views/table/main.php
DEBUG - 2011-09-13 13:11:21 --> Helper loaded: url_helper
DEBUG - 2011-09-13 13:11:21 --> File loaded: application/views/common/header.php
DEBUG - 2011-09-13 13:11:21 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-09-13 13:11:21 --> File loaded: application/views/common/footer.php
DEBUG - 2011-09-13 13:11:21 --> File loaded: application/views/layout/main.php
DEBUG - 2011-09-13 13:11:21 --> Final output sent to browser
DEBUG - 2011-09-13 13:11:21 --> Total execution time: 0.6260
DEBUG - 2011-09-13 13:11:23 --> Config Class Initialized
DEBUG - 2011-09-13 13:11:23 --> Hooks Class Initialized
DEBUG - 2011-09-13 13:11:23 --> Utf8 Class Initialized
DEBUG - 2011-09-13 13:11:23 --> UTF-8 Support Enabled
DEBUG - 2011-09-13 13:11:23 --> URI Class Initialized
DEBUG - 2011-09-13 13:11:23 --> Router Class Initialized
ERROR - 2011-09-13 13:11:23 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-09-13 13:11:31 --> Config Class Initialized
DEBUG - 2011-09-13 13:11:31 --> Hooks Class Initialized
DEBUG - 2011-09-13 13:11:31 --> Utf8 Class Initialized
DEBUG - 2011-09-13 13:11:31 --> UTF-8 Support Enabled
DEBUG - 2011-09-13 13:11:31 --> URI Class Initialized
DEBUG - 2011-09-13 13:11:31 --> Router Class Initialized
DEBUG - 2011-09-13 13:11:31 --> Output Class Initialized
DEBUG - 2011-09-13 13:11:31 --> Input Class Initialized
DEBUG - 2011-09-13 13:11:31 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-13 13:11:31 --> Language Class Initialized
DEBUG - 2011-09-13 13:11:31 --> Loader Class Initialized
DEBUG - 2011-09-13 13:11:31 --> Controller Class Initialized
ERROR - 2011-09-13 13:11:31 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-09-13 13:11:31 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-09-13 13:11:31 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-09-13 13:11:31 --> Model Class Initialized
DEBUG - 2011-09-13 13:11:31 --> Model Class Initialized
DEBUG - 2011-09-13 13:11:31 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-13 13:11:31 --> Database Driver Class Initialized
DEBUG - 2011-09-13 13:11:31 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-09-13 13:11:31 --> Helper loaded: url_helper
DEBUG - 2011-09-13 13:11:31 --> File loaded: application/views/common/header.php
DEBUG - 2011-09-13 13:11:31 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-09-13 13:11:31 --> File loaded: application/views/common/footer.php
DEBUG - 2011-09-13 13:11:31 --> File loaded: application/views/layout/main.php
DEBUG - 2011-09-13 13:11:31 --> Final output sent to browser
DEBUG - 2011-09-13 13:11:31 --> Total execution time: 0.0349
DEBUG - 2011-09-13 13:11:32 --> Config Class Initialized
DEBUG - 2011-09-13 13:11:32 --> Hooks Class Initialized
DEBUG - 2011-09-13 13:11:32 --> Utf8 Class Initialized
DEBUG - 2011-09-13 13:11:32 --> UTF-8 Support Enabled
DEBUG - 2011-09-13 13:11:32 --> URI Class Initialized
DEBUG - 2011-09-13 13:11:32 --> Router Class Initialized
DEBUG - 2011-09-13 13:11:32 --> Output Class Initialized
DEBUG - 2011-09-13 13:11:32 --> Input Class Initialized
DEBUG - 2011-09-13 13:11:32 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-13 13:11:32 --> Language Class Initialized
DEBUG - 2011-09-13 13:11:32 --> Loader Class Initialized
DEBUG - 2011-09-13 13:11:32 --> Controller Class Initialized
DEBUG - 2011-09-13 13:11:32 --> Model Class Initialized
DEBUG - 2011-09-13 13:11:32 --> Model Class Initialized
DEBUG - 2011-09-13 13:11:32 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-13 13:11:32 --> Database Driver Class Initialized
DEBUG - 2011-09-13 13:11:32 --> Final output sent to browser
DEBUG - 2011-09-13 13:11:32 --> Total execution time: 0.5614
DEBUG - 2011-09-13 13:11:34 --> Config Class Initialized
DEBUG - 2011-09-13 13:11:34 --> Hooks Class Initialized
DEBUG - 2011-09-13 13:11:34 --> Utf8 Class Initialized
DEBUG - 2011-09-13 13:11:34 --> UTF-8 Support Enabled
DEBUG - 2011-09-13 13:11:34 --> URI Class Initialized
DEBUG - 2011-09-13 13:11:34 --> Router Class Initialized
ERROR - 2011-09-13 13:11:34 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-09-13 13:11:43 --> Config Class Initialized
DEBUG - 2011-09-13 13:11:43 --> Hooks Class Initialized
DEBUG - 2011-09-13 13:11:43 --> Utf8 Class Initialized
DEBUG - 2011-09-13 13:11:43 --> UTF-8 Support Enabled
DEBUG - 2011-09-13 13:11:43 --> URI Class Initialized
DEBUG - 2011-09-13 13:11:43 --> Router Class Initialized
DEBUG - 2011-09-13 13:11:43 --> Output Class Initialized
DEBUG - 2011-09-13 13:11:43 --> Input Class Initialized
DEBUG - 2011-09-13 13:11:43 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-13 13:11:43 --> Language Class Initialized
DEBUG - 2011-09-13 13:11:43 --> Loader Class Initialized
DEBUG - 2011-09-13 13:11:43 --> Controller Class Initialized
ERROR - 2011-09-13 13:11:43 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-09-13 13:11:43 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-09-13 13:11:43 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-09-13 13:11:43 --> Model Class Initialized
DEBUG - 2011-09-13 13:11:43 --> Model Class Initialized
DEBUG - 2011-09-13 13:11:43 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-13 13:11:43 --> Database Driver Class Initialized
DEBUG - 2011-09-13 13:11:43 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-09-13 13:11:43 --> Helper loaded: url_helper
DEBUG - 2011-09-13 13:11:43 --> File loaded: application/views/common/header.php
DEBUG - 2011-09-13 13:11:43 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-09-13 13:11:43 --> File loaded: application/views/common/footer.php
DEBUG - 2011-09-13 13:11:43 --> File loaded: application/views/layout/main.php
DEBUG - 2011-09-13 13:11:43 --> Final output sent to browser
DEBUG - 2011-09-13 13:11:43 --> Total execution time: 0.0273
DEBUG - 2011-09-13 13:11:43 --> Config Class Initialized
DEBUG - 2011-09-13 13:11:43 --> Hooks Class Initialized
DEBUG - 2011-09-13 13:11:43 --> Utf8 Class Initialized
DEBUG - 2011-09-13 13:11:43 --> UTF-8 Support Enabled
DEBUG - 2011-09-13 13:11:43 --> URI Class Initialized
DEBUG - 2011-09-13 13:11:43 --> Router Class Initialized
DEBUG - 2011-09-13 13:11:43 --> Output Class Initialized
DEBUG - 2011-09-13 13:11:43 --> Input Class Initialized
DEBUG - 2011-09-13 13:11:43 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-13 13:11:43 --> Language Class Initialized
DEBUG - 2011-09-13 13:11:43 --> Loader Class Initialized
DEBUG - 2011-09-13 13:11:43 --> Controller Class Initialized
DEBUG - 2011-09-13 13:11:43 --> Model Class Initialized
DEBUG - 2011-09-13 13:11:43 --> Model Class Initialized
DEBUG - 2011-09-13 13:11:43 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-13 13:11:43 --> Database Driver Class Initialized
DEBUG - 2011-09-13 13:11:44 --> Final output sent to browser
DEBUG - 2011-09-13 13:11:44 --> Total execution time: 0.7630
DEBUG - 2011-09-13 13:11:45 --> Config Class Initialized
DEBUG - 2011-09-13 13:11:45 --> Hooks Class Initialized
DEBUG - 2011-09-13 13:11:45 --> Utf8 Class Initialized
DEBUG - 2011-09-13 13:11:45 --> UTF-8 Support Enabled
DEBUG - 2011-09-13 13:11:45 --> URI Class Initialized
DEBUG - 2011-09-13 13:11:45 --> Router Class Initialized
ERROR - 2011-09-13 13:11:45 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-09-13 13:11:47 --> Config Class Initialized
DEBUG - 2011-09-13 13:11:47 --> Hooks Class Initialized
DEBUG - 2011-09-13 13:11:47 --> Utf8 Class Initialized
DEBUG - 2011-09-13 13:11:47 --> UTF-8 Support Enabled
DEBUG - 2011-09-13 13:11:47 --> URI Class Initialized
DEBUG - 2011-09-13 13:11:47 --> Router Class Initialized
DEBUG - 2011-09-13 13:11:47 --> Output Class Initialized
DEBUG - 2011-09-13 13:11:47 --> Input Class Initialized
DEBUG - 2011-09-13 13:11:47 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-13 13:11:47 --> Language Class Initialized
DEBUG - 2011-09-13 13:11:47 --> Loader Class Initialized
DEBUG - 2011-09-13 13:11:47 --> Controller Class Initialized
ERROR - 2011-09-13 13:11:47 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-09-13 13:11:47 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-09-13 13:11:47 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-09-13 13:11:47 --> Model Class Initialized
DEBUG - 2011-09-13 13:11:47 --> Model Class Initialized
DEBUG - 2011-09-13 13:11:47 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-13 13:11:47 --> Database Driver Class Initialized
DEBUG - 2011-09-13 13:11:47 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-09-13 13:11:47 --> Helper loaded: url_helper
DEBUG - 2011-09-13 13:11:47 --> File loaded: application/views/common/header.php
DEBUG - 2011-09-13 13:11:47 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-09-13 13:11:47 --> File loaded: application/views/common/footer.php
DEBUG - 2011-09-13 13:11:47 --> File loaded: application/views/layout/main.php
DEBUG - 2011-09-13 13:11:47 --> Final output sent to browser
DEBUG - 2011-09-13 13:11:47 --> Total execution time: 0.0335
DEBUG - 2011-09-13 13:11:48 --> Config Class Initialized
DEBUG - 2011-09-13 13:11:48 --> Hooks Class Initialized
DEBUG - 2011-09-13 13:11:48 --> Utf8 Class Initialized
DEBUG - 2011-09-13 13:11:48 --> UTF-8 Support Enabled
DEBUG - 2011-09-13 13:11:48 --> URI Class Initialized
DEBUG - 2011-09-13 13:11:48 --> Router Class Initialized
DEBUG - 2011-09-13 13:11:48 --> Output Class Initialized
DEBUG - 2011-09-13 13:11:48 --> Input Class Initialized
DEBUG - 2011-09-13 13:11:48 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-13 13:11:48 --> Language Class Initialized
DEBUG - 2011-09-13 13:11:48 --> Loader Class Initialized
DEBUG - 2011-09-13 13:11:48 --> Controller Class Initialized
DEBUG - 2011-09-13 13:11:48 --> Model Class Initialized
DEBUG - 2011-09-13 13:11:48 --> Model Class Initialized
DEBUG - 2011-09-13 13:11:48 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-13 13:11:48 --> Database Driver Class Initialized
DEBUG - 2011-09-13 13:11:49 --> Final output sent to browser
DEBUG - 2011-09-13 13:11:49 --> Total execution time: 0.5866
DEBUG - 2011-09-13 13:11:49 --> Config Class Initialized
DEBUG - 2011-09-13 13:11:49 --> Hooks Class Initialized
DEBUG - 2011-09-13 13:11:49 --> Utf8 Class Initialized
DEBUG - 2011-09-13 13:11:49 --> UTF-8 Support Enabled
DEBUG - 2011-09-13 13:11:49 --> URI Class Initialized
DEBUG - 2011-09-13 13:11:49 --> Router Class Initialized
ERROR - 2011-09-13 13:11:49 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-09-13 13:12:21 --> Config Class Initialized
DEBUG - 2011-09-13 13:12:21 --> Hooks Class Initialized
DEBUG - 2011-09-13 13:12:21 --> Utf8 Class Initialized
DEBUG - 2011-09-13 13:12:21 --> UTF-8 Support Enabled
DEBUG - 2011-09-13 13:12:21 --> URI Class Initialized
DEBUG - 2011-09-13 13:12:21 --> Router Class Initialized
DEBUG - 2011-09-13 13:12:21 --> Output Class Initialized
DEBUG - 2011-09-13 13:12:21 --> Input Class Initialized
DEBUG - 2011-09-13 13:12:21 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-13 13:12:21 --> Language Class Initialized
DEBUG - 2011-09-13 13:12:21 --> Loader Class Initialized
DEBUG - 2011-09-13 13:12:21 --> Controller Class Initialized
ERROR - 2011-09-13 13:12:21 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-09-13 13:12:21 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-09-13 13:12:21 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-09-13 13:12:21 --> Model Class Initialized
DEBUG - 2011-09-13 13:12:21 --> Model Class Initialized
DEBUG - 2011-09-13 13:12:21 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-13 13:12:21 --> Database Driver Class Initialized
DEBUG - 2011-09-13 13:12:21 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-09-13 13:12:21 --> Helper loaded: url_helper
DEBUG - 2011-09-13 13:12:21 --> File loaded: application/views/common/header.php
DEBUG - 2011-09-13 13:12:21 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-09-13 13:12:21 --> File loaded: application/views/common/footer.php
DEBUG - 2011-09-13 13:12:21 --> File loaded: application/views/layout/main.php
DEBUG - 2011-09-13 13:12:21 --> Final output sent to browser
DEBUG - 2011-09-13 13:12:21 --> Total execution time: 0.0786
DEBUG - 2011-09-13 13:12:22 --> Config Class Initialized
DEBUG - 2011-09-13 13:12:22 --> Hooks Class Initialized
DEBUG - 2011-09-13 13:12:22 --> Utf8 Class Initialized
DEBUG - 2011-09-13 13:12:22 --> UTF-8 Support Enabled
DEBUG - 2011-09-13 13:12:22 --> URI Class Initialized
DEBUG - 2011-09-13 13:12:22 --> Router Class Initialized
DEBUG - 2011-09-13 13:12:22 --> Output Class Initialized
DEBUG - 2011-09-13 13:12:22 --> Input Class Initialized
DEBUG - 2011-09-13 13:12:22 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-13 13:12:22 --> Language Class Initialized
DEBUG - 2011-09-13 13:12:22 --> Loader Class Initialized
DEBUG - 2011-09-13 13:12:22 --> Controller Class Initialized
DEBUG - 2011-09-13 13:12:22 --> Model Class Initialized
DEBUG - 2011-09-13 13:12:22 --> Model Class Initialized
DEBUG - 2011-09-13 13:12:22 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-13 13:12:22 --> Database Driver Class Initialized
DEBUG - 2011-09-13 13:12:23 --> Final output sent to browser
DEBUG - 2011-09-13 13:12:23 --> Total execution time: 0.6763
DEBUG - 2011-09-13 13:12:23 --> Config Class Initialized
DEBUG - 2011-09-13 13:12:23 --> Hooks Class Initialized
DEBUG - 2011-09-13 13:12:23 --> Utf8 Class Initialized
DEBUG - 2011-09-13 13:12:23 --> UTF-8 Support Enabled
DEBUG - 2011-09-13 13:12:23 --> URI Class Initialized
DEBUG - 2011-09-13 13:12:23 --> Router Class Initialized
ERROR - 2011-09-13 13:12:23 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-09-13 13:25:36 --> Config Class Initialized
DEBUG - 2011-09-13 13:25:36 --> Hooks Class Initialized
DEBUG - 2011-09-13 13:25:36 --> Utf8 Class Initialized
DEBUG - 2011-09-13 13:25:36 --> UTF-8 Support Enabled
DEBUG - 2011-09-13 13:25:36 --> URI Class Initialized
DEBUG - 2011-09-13 13:25:36 --> Router Class Initialized
DEBUG - 2011-09-13 13:25:36 --> Output Class Initialized
DEBUG - 2011-09-13 13:25:36 --> Input Class Initialized
DEBUG - 2011-09-13 13:25:36 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-13 13:25:36 --> Language Class Initialized
DEBUG - 2011-09-13 13:25:36 --> Loader Class Initialized
DEBUG - 2011-09-13 13:25:36 --> Controller Class Initialized
DEBUG - 2011-09-13 13:25:36 --> Model Class Initialized
DEBUG - 2011-09-13 13:25:36 --> Model Class Initialized
DEBUG - 2011-09-13 13:25:36 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-13 13:25:36 --> Database Driver Class Initialized
DEBUG - 2011-09-13 13:25:37 --> Final output sent to browser
DEBUG - 2011-09-13 13:25:37 --> Total execution time: 0.5149
DEBUG - 2011-09-13 13:39:13 --> Config Class Initialized
DEBUG - 2011-09-13 13:39:13 --> Hooks Class Initialized
DEBUG - 2011-09-13 13:39:13 --> Utf8 Class Initialized
DEBUG - 2011-09-13 13:39:13 --> UTF-8 Support Enabled
DEBUG - 2011-09-13 13:39:13 --> URI Class Initialized
DEBUG - 2011-09-13 13:39:13 --> Router Class Initialized
DEBUG - 2011-09-13 13:39:13 --> Output Class Initialized
DEBUG - 2011-09-13 13:39:13 --> Input Class Initialized
DEBUG - 2011-09-13 13:39:13 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-13 13:39:13 --> Language Class Initialized
DEBUG - 2011-09-13 13:39:13 --> Loader Class Initialized
DEBUG - 2011-09-13 13:39:13 --> Controller Class Initialized
DEBUG - 2011-09-13 13:39:13 --> Model Class Initialized
DEBUG - 2011-09-13 13:39:13 --> Model Class Initialized
DEBUG - 2011-09-13 13:39:13 --> Model Class Initialized
DEBUG - 2011-09-13 13:39:13 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-13 13:39:13 --> Database Driver Class Initialized
DEBUG - 2011-09-13 13:39:14 --> File loaded: application/views/table/main.php
DEBUG - 2011-09-13 13:39:14 --> Helper loaded: url_helper
DEBUG - 2011-09-13 13:39:14 --> File loaded: application/views/common/header.php
DEBUG - 2011-09-13 13:39:14 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-09-13 13:39:14 --> File loaded: application/views/common/footer.php
DEBUG - 2011-09-13 13:39:14 --> File loaded: application/views/layout/main.php
DEBUG - 2011-09-13 13:39:14 --> Final output sent to browser
DEBUG - 2011-09-13 13:39:14 --> Total execution time: 0.3708
DEBUG - 2011-09-13 13:39:17 --> Config Class Initialized
DEBUG - 2011-09-13 13:39:17 --> Hooks Class Initialized
DEBUG - 2011-09-13 13:39:17 --> Utf8 Class Initialized
DEBUG - 2011-09-13 13:39:17 --> UTF-8 Support Enabled
DEBUG - 2011-09-13 13:39:17 --> URI Class Initialized
DEBUG - 2011-09-13 13:39:17 --> Router Class Initialized
ERROR - 2011-09-13 13:39:17 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-09-13 13:39:18 --> Config Class Initialized
DEBUG - 2011-09-13 13:39:18 --> Hooks Class Initialized
DEBUG - 2011-09-13 13:39:18 --> Utf8 Class Initialized
DEBUG - 2011-09-13 13:39:18 --> UTF-8 Support Enabled
DEBUG - 2011-09-13 13:39:18 --> URI Class Initialized
DEBUG - 2011-09-13 13:39:18 --> Router Class Initialized
ERROR - 2011-09-13 13:39:18 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-09-13 13:39:18 --> Config Class Initialized
DEBUG - 2011-09-13 13:39:18 --> Hooks Class Initialized
DEBUG - 2011-09-13 13:39:18 --> Utf8 Class Initialized
DEBUG - 2011-09-13 13:39:18 --> UTF-8 Support Enabled
DEBUG - 2011-09-13 13:39:18 --> URI Class Initialized
DEBUG - 2011-09-13 13:39:18 --> Router Class Initialized
ERROR - 2011-09-13 13:39:18 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-09-13 13:44:58 --> Config Class Initialized
DEBUG - 2011-09-13 13:44:58 --> Hooks Class Initialized
DEBUG - 2011-09-13 13:44:58 --> Utf8 Class Initialized
DEBUG - 2011-09-13 13:44:58 --> UTF-8 Support Enabled
DEBUG - 2011-09-13 13:44:58 --> URI Class Initialized
DEBUG - 2011-09-13 13:44:58 --> Router Class Initialized
DEBUG - 2011-09-13 13:44:58 --> Output Class Initialized
DEBUG - 2011-09-13 13:44:58 --> Input Class Initialized
DEBUG - 2011-09-13 13:44:58 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-13 13:44:58 --> Language Class Initialized
DEBUG - 2011-09-13 13:44:58 --> Loader Class Initialized
DEBUG - 2011-09-13 13:44:58 --> Controller Class Initialized
ERROR - 2011-09-13 13:44:58 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-09-13 13:44:58 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-09-13 13:44:58 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-09-13 13:44:58 --> Model Class Initialized
DEBUG - 2011-09-13 13:44:58 --> Model Class Initialized
DEBUG - 2011-09-13 13:44:58 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-13 13:44:58 --> Database Driver Class Initialized
DEBUG - 2011-09-13 13:44:58 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-09-13 13:44:58 --> Helper loaded: url_helper
DEBUG - 2011-09-13 13:44:58 --> File loaded: application/views/common/header.php
DEBUG - 2011-09-13 13:44:58 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-09-13 13:44:58 --> File loaded: application/views/common/footer.php
DEBUG - 2011-09-13 13:44:58 --> File loaded: application/views/layout/main.php
DEBUG - 2011-09-13 13:44:58 --> Final output sent to browser
DEBUG - 2011-09-13 13:44:58 --> Total execution time: 0.0309
DEBUG - 2011-09-13 13:45:00 --> Config Class Initialized
DEBUG - 2011-09-13 13:45:00 --> Hooks Class Initialized
DEBUG - 2011-09-13 13:45:00 --> Utf8 Class Initialized
DEBUG - 2011-09-13 13:45:00 --> UTF-8 Support Enabled
DEBUG - 2011-09-13 13:45:00 --> URI Class Initialized
DEBUG - 2011-09-13 13:45:00 --> Router Class Initialized
DEBUG - 2011-09-13 13:45:00 --> Output Class Initialized
DEBUG - 2011-09-13 13:45:00 --> Input Class Initialized
DEBUG - 2011-09-13 13:45:00 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-13 13:45:00 --> Language Class Initialized
DEBUG - 2011-09-13 13:45:00 --> Loader Class Initialized
DEBUG - 2011-09-13 13:45:00 --> Controller Class Initialized
DEBUG - 2011-09-13 13:45:00 --> Model Class Initialized
DEBUG - 2011-09-13 13:45:00 --> Model Class Initialized
DEBUG - 2011-09-13 13:45:00 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-13 13:45:00 --> Database Driver Class Initialized
DEBUG - 2011-09-13 13:45:01 --> Final output sent to browser
DEBUG - 2011-09-13 13:45:01 --> Total execution time: 0.6226
DEBUG - 2011-09-13 13:45:04 --> Config Class Initialized
DEBUG - 2011-09-13 13:45:04 --> Hooks Class Initialized
DEBUG - 2011-09-13 13:45:04 --> Utf8 Class Initialized
DEBUG - 2011-09-13 13:45:04 --> UTF-8 Support Enabled
DEBUG - 2011-09-13 13:45:04 --> URI Class Initialized
DEBUG - 2011-09-13 13:45:04 --> Router Class Initialized
ERROR - 2011-09-13 13:45:04 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-09-13 13:45:33 --> Config Class Initialized
DEBUG - 2011-09-13 13:45:33 --> Hooks Class Initialized
DEBUG - 2011-09-13 13:45:33 --> Utf8 Class Initialized
DEBUG - 2011-09-13 13:45:33 --> UTF-8 Support Enabled
DEBUG - 2011-09-13 13:45:33 --> URI Class Initialized
DEBUG - 2011-09-13 13:45:33 --> Router Class Initialized
DEBUG - 2011-09-13 13:45:33 --> Output Class Initialized
DEBUG - 2011-09-13 13:45:33 --> Input Class Initialized
DEBUG - 2011-09-13 13:45:33 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-13 13:45:33 --> Language Class Initialized
DEBUG - 2011-09-13 13:45:33 --> Loader Class Initialized
DEBUG - 2011-09-13 13:45:33 --> Controller Class Initialized
ERROR - 2011-09-13 13:45:33 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-09-13 13:45:33 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-09-13 13:45:33 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-09-13 13:45:33 --> Model Class Initialized
DEBUG - 2011-09-13 13:45:33 --> Model Class Initialized
DEBUG - 2011-09-13 13:45:33 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-13 13:45:33 --> Database Driver Class Initialized
DEBUG - 2011-09-13 13:45:33 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-09-13 13:45:33 --> Helper loaded: url_helper
DEBUG - 2011-09-13 13:45:33 --> File loaded: application/views/common/header.php
DEBUG - 2011-09-13 13:45:33 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-09-13 13:45:33 --> File loaded: application/views/common/footer.php
DEBUG - 2011-09-13 13:45:33 --> File loaded: application/views/layout/main.php
DEBUG - 2011-09-13 13:45:33 --> Final output sent to browser
DEBUG - 2011-09-13 13:45:33 --> Total execution time: 0.0277
DEBUG - 2011-09-13 13:45:34 --> Config Class Initialized
DEBUG - 2011-09-13 13:45:34 --> Hooks Class Initialized
DEBUG - 2011-09-13 13:45:34 --> Utf8 Class Initialized
DEBUG - 2011-09-13 13:45:34 --> UTF-8 Support Enabled
DEBUG - 2011-09-13 13:45:34 --> URI Class Initialized
DEBUG - 2011-09-13 13:45:34 --> Router Class Initialized
DEBUG - 2011-09-13 13:45:34 --> Output Class Initialized
DEBUG - 2011-09-13 13:45:34 --> Input Class Initialized
DEBUG - 2011-09-13 13:45:34 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-13 13:45:34 --> Language Class Initialized
DEBUG - 2011-09-13 13:45:34 --> Loader Class Initialized
DEBUG - 2011-09-13 13:45:34 --> Controller Class Initialized
DEBUG - 2011-09-13 13:45:34 --> Model Class Initialized
DEBUG - 2011-09-13 13:45:34 --> Model Class Initialized
DEBUG - 2011-09-13 13:45:34 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-13 13:45:34 --> Database Driver Class Initialized
DEBUG - 2011-09-13 13:45:34 --> Final output sent to browser
DEBUG - 2011-09-13 13:45:34 --> Total execution time: 0.6284
DEBUG - 2011-09-13 13:45:36 --> Config Class Initialized
DEBUG - 2011-09-13 13:45:36 --> Hooks Class Initialized
DEBUG - 2011-09-13 13:45:36 --> Utf8 Class Initialized
DEBUG - 2011-09-13 13:45:36 --> UTF-8 Support Enabled
DEBUG - 2011-09-13 13:45:36 --> URI Class Initialized
DEBUG - 2011-09-13 13:45:36 --> Router Class Initialized
ERROR - 2011-09-13 13:45:36 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-09-13 13:45:44 --> Config Class Initialized
DEBUG - 2011-09-13 13:45:44 --> Hooks Class Initialized
DEBUG - 2011-09-13 13:45:44 --> Utf8 Class Initialized
DEBUG - 2011-09-13 13:45:44 --> UTF-8 Support Enabled
DEBUG - 2011-09-13 13:45:44 --> URI Class Initialized
DEBUG - 2011-09-13 13:45:44 --> Router Class Initialized
DEBUG - 2011-09-13 13:45:44 --> Output Class Initialized
DEBUG - 2011-09-13 13:45:44 --> Input Class Initialized
DEBUG - 2011-09-13 13:45:44 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-13 13:45:44 --> Language Class Initialized
DEBUG - 2011-09-13 13:45:44 --> Loader Class Initialized
DEBUG - 2011-09-13 13:45:44 --> Controller Class Initialized
ERROR - 2011-09-13 13:45:44 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-09-13 13:45:44 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-09-13 13:45:44 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-09-13 13:45:44 --> Model Class Initialized
DEBUG - 2011-09-13 13:45:44 --> Model Class Initialized
DEBUG - 2011-09-13 13:45:44 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-13 13:45:44 --> Database Driver Class Initialized
DEBUG - 2011-09-13 13:45:44 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-09-13 13:45:44 --> Helper loaded: url_helper
DEBUG - 2011-09-13 13:45:44 --> File loaded: application/views/common/header.php
DEBUG - 2011-09-13 13:45:44 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-09-13 13:45:44 --> File loaded: application/views/common/footer.php
DEBUG - 2011-09-13 13:45:44 --> File loaded: application/views/layout/main.php
DEBUG - 2011-09-13 13:45:44 --> Final output sent to browser
DEBUG - 2011-09-13 13:45:44 --> Total execution time: 0.0283
DEBUG - 2011-09-13 13:45:45 --> Config Class Initialized
DEBUG - 2011-09-13 13:45:45 --> Hooks Class Initialized
DEBUG - 2011-09-13 13:45:45 --> Utf8 Class Initialized
DEBUG - 2011-09-13 13:45:45 --> UTF-8 Support Enabled
DEBUG - 2011-09-13 13:45:45 --> URI Class Initialized
DEBUG - 2011-09-13 13:45:45 --> Router Class Initialized
DEBUG - 2011-09-13 13:45:45 --> Output Class Initialized
DEBUG - 2011-09-13 13:45:45 --> Input Class Initialized
DEBUG - 2011-09-13 13:45:45 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-13 13:45:45 --> Language Class Initialized
DEBUG - 2011-09-13 13:45:45 --> Loader Class Initialized
DEBUG - 2011-09-13 13:45:45 --> Controller Class Initialized
DEBUG - 2011-09-13 13:45:45 --> Model Class Initialized
DEBUG - 2011-09-13 13:45:45 --> Model Class Initialized
DEBUG - 2011-09-13 13:45:45 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-13 13:45:45 --> Database Driver Class Initialized
DEBUG - 2011-09-13 13:45:45 --> Final output sent to browser
DEBUG - 2011-09-13 13:45:45 --> Total execution time: 0.5577
DEBUG - 2011-09-13 13:45:48 --> Config Class Initialized
DEBUG - 2011-09-13 13:45:48 --> Hooks Class Initialized
DEBUG - 2011-09-13 13:45:48 --> Utf8 Class Initialized
DEBUG - 2011-09-13 13:45:48 --> UTF-8 Support Enabled
DEBUG - 2011-09-13 13:45:48 --> URI Class Initialized
DEBUG - 2011-09-13 13:45:48 --> Router Class Initialized
ERROR - 2011-09-13 13:45:48 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-09-13 13:47:33 --> Config Class Initialized
DEBUG - 2011-09-13 13:47:33 --> Hooks Class Initialized
DEBUG - 2011-09-13 13:47:33 --> Utf8 Class Initialized
DEBUG - 2011-09-13 13:47:33 --> UTF-8 Support Enabled
DEBUG - 2011-09-13 13:47:33 --> URI Class Initialized
DEBUG - 2011-09-13 13:47:33 --> Router Class Initialized
DEBUG - 2011-09-13 13:47:33 --> Output Class Initialized
DEBUG - 2011-09-13 13:47:33 --> Input Class Initialized
DEBUG - 2011-09-13 13:47:33 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-13 13:47:33 --> Language Class Initialized
DEBUG - 2011-09-13 13:47:33 --> Loader Class Initialized
DEBUG - 2011-09-13 13:47:33 --> Controller Class Initialized
ERROR - 2011-09-13 13:47:33 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-09-13 13:47:33 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-09-13 13:47:33 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-09-13 13:47:33 --> Model Class Initialized
DEBUG - 2011-09-13 13:47:33 --> Model Class Initialized
DEBUG - 2011-09-13 13:47:33 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-13 13:47:33 --> Database Driver Class Initialized
DEBUG - 2011-09-13 13:47:33 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-09-13 13:47:33 --> Helper loaded: url_helper
DEBUG - 2011-09-13 13:47:33 --> File loaded: application/views/common/header.php
DEBUG - 2011-09-13 13:47:33 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-09-13 13:47:33 --> File loaded: application/views/common/footer.php
DEBUG - 2011-09-13 13:47:33 --> File loaded: application/views/layout/main.php
DEBUG - 2011-09-13 13:47:33 --> Final output sent to browser
DEBUG - 2011-09-13 13:47:33 --> Total execution time: 0.0273
DEBUG - 2011-09-13 13:47:34 --> Config Class Initialized
DEBUG - 2011-09-13 13:47:34 --> Hooks Class Initialized
DEBUG - 2011-09-13 13:47:34 --> Utf8 Class Initialized
DEBUG - 2011-09-13 13:47:34 --> UTF-8 Support Enabled
DEBUG - 2011-09-13 13:47:34 --> URI Class Initialized
DEBUG - 2011-09-13 13:47:34 --> Router Class Initialized
DEBUG - 2011-09-13 13:47:34 --> Output Class Initialized
DEBUG - 2011-09-13 13:47:34 --> Input Class Initialized
DEBUG - 2011-09-13 13:47:34 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-13 13:47:34 --> Language Class Initialized
DEBUG - 2011-09-13 13:47:34 --> Loader Class Initialized
DEBUG - 2011-09-13 13:47:34 --> Controller Class Initialized
DEBUG - 2011-09-13 13:47:34 --> Model Class Initialized
DEBUG - 2011-09-13 13:47:34 --> Model Class Initialized
DEBUG - 2011-09-13 13:47:34 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-13 13:47:34 --> Database Driver Class Initialized
DEBUG - 2011-09-13 13:47:34 --> Final output sent to browser
DEBUG - 2011-09-13 13:47:34 --> Total execution time: 0.5401
DEBUG - 2011-09-13 13:47:59 --> Config Class Initialized
DEBUG - 2011-09-13 13:47:59 --> Hooks Class Initialized
DEBUG - 2011-09-13 13:47:59 --> Utf8 Class Initialized
DEBUG - 2011-09-13 13:47:59 --> UTF-8 Support Enabled
DEBUG - 2011-09-13 13:47:59 --> URI Class Initialized
DEBUG - 2011-09-13 13:47:59 --> Router Class Initialized
DEBUG - 2011-09-13 13:47:59 --> Output Class Initialized
DEBUG - 2011-09-13 13:47:59 --> Input Class Initialized
DEBUG - 2011-09-13 13:47:59 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-13 13:47:59 --> Language Class Initialized
DEBUG - 2011-09-13 13:47:59 --> Loader Class Initialized
DEBUG - 2011-09-13 13:47:59 --> Controller Class Initialized
ERROR - 2011-09-13 13:47:59 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-09-13 13:47:59 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-09-13 13:47:59 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-09-13 13:47:59 --> Model Class Initialized
DEBUG - 2011-09-13 13:47:59 --> Model Class Initialized
DEBUG - 2011-09-13 13:47:59 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-13 13:47:59 --> Database Driver Class Initialized
DEBUG - 2011-09-13 13:47:59 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-09-13 13:47:59 --> Helper loaded: url_helper
DEBUG - 2011-09-13 13:47:59 --> File loaded: application/views/common/header.php
DEBUG - 2011-09-13 13:47:59 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-09-13 13:47:59 --> File loaded: application/views/common/footer.php
DEBUG - 2011-09-13 13:47:59 --> File loaded: application/views/layout/main.php
DEBUG - 2011-09-13 13:47:59 --> Final output sent to browser
DEBUG - 2011-09-13 13:47:59 --> Total execution time: 0.0804
DEBUG - 2011-09-13 13:48:00 --> Config Class Initialized
DEBUG - 2011-09-13 13:48:00 --> Hooks Class Initialized
DEBUG - 2011-09-13 13:48:00 --> Utf8 Class Initialized
DEBUG - 2011-09-13 13:48:00 --> UTF-8 Support Enabled
DEBUG - 2011-09-13 13:48:00 --> URI Class Initialized
DEBUG - 2011-09-13 13:48:00 --> Router Class Initialized
DEBUG - 2011-09-13 13:48:00 --> Output Class Initialized
DEBUG - 2011-09-13 13:48:00 --> Input Class Initialized
DEBUG - 2011-09-13 13:48:00 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-13 13:48:00 --> Language Class Initialized
DEBUG - 2011-09-13 13:48:00 --> Loader Class Initialized
DEBUG - 2011-09-13 13:48:00 --> Controller Class Initialized
DEBUG - 2011-09-13 13:48:00 --> Model Class Initialized
DEBUG - 2011-09-13 13:48:00 --> Model Class Initialized
DEBUG - 2011-09-13 13:48:00 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-13 13:48:00 --> Database Driver Class Initialized
DEBUG - 2011-09-13 13:48:01 --> Final output sent to browser
DEBUG - 2011-09-13 13:48:01 --> Total execution time: 1.4303
DEBUG - 2011-09-13 13:48:15 --> Config Class Initialized
DEBUG - 2011-09-13 13:48:15 --> Hooks Class Initialized
DEBUG - 2011-09-13 13:48:15 --> Utf8 Class Initialized
DEBUG - 2011-09-13 13:48:15 --> UTF-8 Support Enabled
DEBUG - 2011-09-13 13:48:15 --> URI Class Initialized
DEBUG - 2011-09-13 13:48:15 --> Router Class Initialized
DEBUG - 2011-09-13 13:48:15 --> Output Class Initialized
DEBUG - 2011-09-13 13:48:15 --> Input Class Initialized
DEBUG - 2011-09-13 13:48:15 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-13 13:48:15 --> Language Class Initialized
DEBUG - 2011-09-13 13:48:15 --> Loader Class Initialized
DEBUG - 2011-09-13 13:48:15 --> Controller Class Initialized
ERROR - 2011-09-13 13:48:15 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-09-13 13:48:15 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-09-13 13:48:15 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-09-13 13:48:15 --> Model Class Initialized
DEBUG - 2011-09-13 13:48:15 --> Model Class Initialized
DEBUG - 2011-09-13 13:48:15 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-13 13:48:15 --> Database Driver Class Initialized
DEBUG - 2011-09-13 13:48:15 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-09-13 13:48:15 --> Helper loaded: url_helper
DEBUG - 2011-09-13 13:48:15 --> File loaded: application/views/common/header.php
DEBUG - 2011-09-13 13:48:15 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-09-13 13:48:15 --> File loaded: application/views/common/footer.php
DEBUG - 2011-09-13 13:48:15 --> File loaded: application/views/layout/main.php
DEBUG - 2011-09-13 13:48:15 --> Final output sent to browser
DEBUG - 2011-09-13 13:48:15 --> Total execution time: 0.0305
DEBUG - 2011-09-13 13:48:17 --> Config Class Initialized
DEBUG - 2011-09-13 13:48:17 --> Hooks Class Initialized
DEBUG - 2011-09-13 13:48:17 --> Utf8 Class Initialized
DEBUG - 2011-09-13 13:48:17 --> UTF-8 Support Enabled
DEBUG - 2011-09-13 13:48:17 --> URI Class Initialized
DEBUG - 2011-09-13 13:48:17 --> Router Class Initialized
DEBUG - 2011-09-13 13:48:17 --> Output Class Initialized
DEBUG - 2011-09-13 13:48:17 --> Input Class Initialized
DEBUG - 2011-09-13 13:48:17 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-13 13:48:17 --> Language Class Initialized
DEBUG - 2011-09-13 13:48:17 --> Loader Class Initialized
DEBUG - 2011-09-13 13:48:17 --> Controller Class Initialized
DEBUG - 2011-09-13 13:48:17 --> Model Class Initialized
DEBUG - 2011-09-13 13:48:17 --> Model Class Initialized
DEBUG - 2011-09-13 13:48:17 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-13 13:48:17 --> Database Driver Class Initialized
DEBUG - 2011-09-13 13:48:17 --> Final output sent to browser
DEBUG - 2011-09-13 13:48:17 --> Total execution time: 0.5249
DEBUG - 2011-09-13 14:04:41 --> Config Class Initialized
DEBUG - 2011-09-13 14:04:41 --> Hooks Class Initialized
DEBUG - 2011-09-13 14:04:41 --> Utf8 Class Initialized
DEBUG - 2011-09-13 14:04:41 --> UTF-8 Support Enabled
DEBUG - 2011-09-13 14:04:41 --> URI Class Initialized
DEBUG - 2011-09-13 14:04:41 --> Router Class Initialized
DEBUG - 2011-09-13 14:04:41 --> Output Class Initialized
DEBUG - 2011-09-13 14:04:41 --> Input Class Initialized
DEBUG - 2011-09-13 14:04:41 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-13 14:04:41 --> Language Class Initialized
DEBUG - 2011-09-13 14:04:41 --> Loader Class Initialized
DEBUG - 2011-09-13 14:04:41 --> Controller Class Initialized
DEBUG - 2011-09-13 14:04:41 --> Model Class Initialized
DEBUG - 2011-09-13 14:04:41 --> Model Class Initialized
DEBUG - 2011-09-13 14:04:41 --> Model Class Initialized
DEBUG - 2011-09-13 14:04:41 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-13 14:04:41 --> Database Driver Class Initialized
DEBUG - 2011-09-13 14:04:41 --> File loaded: application/views/table/main.php
DEBUG - 2011-09-13 14:04:41 --> Helper loaded: url_helper
DEBUG - 2011-09-13 14:04:41 --> File loaded: application/views/common/header.php
DEBUG - 2011-09-13 14:04:41 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-09-13 14:04:41 --> File loaded: application/views/common/footer.php
DEBUG - 2011-09-13 14:04:41 --> File loaded: application/views/layout/main.php
DEBUG - 2011-09-13 14:04:41 --> Final output sent to browser
DEBUG - 2011-09-13 14:04:41 --> Total execution time: 0.3129
DEBUG - 2011-09-13 14:04:42 --> Config Class Initialized
DEBUG - 2011-09-13 14:04:42 --> Hooks Class Initialized
DEBUG - 2011-09-13 14:04:42 --> Utf8 Class Initialized
DEBUG - 2011-09-13 14:04:42 --> UTF-8 Support Enabled
DEBUG - 2011-09-13 14:04:42 --> URI Class Initialized
DEBUG - 2011-09-13 14:04:42 --> Router Class Initialized
ERROR - 2011-09-13 14:04:42 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-09-13 14:04:42 --> Config Class Initialized
DEBUG - 2011-09-13 14:04:42 --> Hooks Class Initialized
DEBUG - 2011-09-13 14:04:42 --> Utf8 Class Initialized
DEBUG - 2011-09-13 14:04:42 --> UTF-8 Support Enabled
DEBUG - 2011-09-13 14:04:42 --> URI Class Initialized
DEBUG - 2011-09-13 14:04:42 --> Router Class Initialized
DEBUG - 2011-09-13 14:04:42 --> Output Class Initialized
DEBUG - 2011-09-13 14:04:42 --> Input Class Initialized
DEBUG - 2011-09-13 14:04:42 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-13 14:04:42 --> Language Class Initialized
DEBUG - 2011-09-13 14:04:42 --> Loader Class Initialized
DEBUG - 2011-09-13 14:04:42 --> Controller Class Initialized
DEBUG - 2011-09-13 14:04:42 --> Model Class Initialized
DEBUG - 2011-09-13 14:04:42 --> Model Class Initialized
DEBUG - 2011-09-13 14:04:42 --> Model Class Initialized
DEBUG - 2011-09-13 14:04:42 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-13 14:04:42 --> Database Driver Class Initialized
DEBUG - 2011-09-13 14:04:42 --> File loaded: application/views/table/main.php
DEBUG - 2011-09-13 14:04:42 --> Helper loaded: url_helper
DEBUG - 2011-09-13 14:04:42 --> File loaded: application/views/common/header.php
DEBUG - 2011-09-13 14:04:42 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-09-13 14:04:42 --> File loaded: application/views/common/footer.php
DEBUG - 2011-09-13 14:04:42 --> File loaded: application/views/layout/main.php
DEBUG - 2011-09-13 14:04:42 --> Final output sent to browser
DEBUG - 2011-09-13 14:04:42 --> Total execution time: 0.0632
DEBUG - 2011-09-13 14:11:14 --> Config Class Initialized
DEBUG - 2011-09-13 14:11:14 --> Hooks Class Initialized
DEBUG - 2011-09-13 14:11:14 --> Utf8 Class Initialized
DEBUG - 2011-09-13 14:11:14 --> UTF-8 Support Enabled
DEBUG - 2011-09-13 14:11:14 --> URI Class Initialized
DEBUG - 2011-09-13 14:11:14 --> Router Class Initialized
DEBUG - 2011-09-13 14:11:14 --> Output Class Initialized
DEBUG - 2011-09-13 14:11:14 --> Input Class Initialized
DEBUG - 2011-09-13 14:11:14 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-13 14:11:14 --> Language Class Initialized
DEBUG - 2011-09-13 14:11:14 --> Loader Class Initialized
DEBUG - 2011-09-13 14:11:14 --> Controller Class Initialized
DEBUG - 2011-09-13 14:11:14 --> Model Class Initialized
DEBUG - 2011-09-13 14:11:14 --> Model Class Initialized
DEBUG - 2011-09-13 14:11:14 --> Model Class Initialized
DEBUG - 2011-09-13 14:11:14 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-13 14:11:14 --> Database Driver Class Initialized
DEBUG - 2011-09-13 14:11:14 --> File loaded: application/views/table/main.php
DEBUG - 2011-09-13 14:11:14 --> Helper loaded: url_helper
DEBUG - 2011-09-13 14:11:14 --> File loaded: application/views/common/header.php
DEBUG - 2011-09-13 14:11:14 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-09-13 14:11:14 --> File loaded: application/views/common/footer.php
DEBUG - 2011-09-13 14:11:14 --> File loaded: application/views/layout/main.php
DEBUG - 2011-09-13 14:11:14 --> Final output sent to browser
DEBUG - 2011-09-13 14:11:14 --> Total execution time: 0.1369
DEBUG - 2011-09-13 14:11:20 --> Config Class Initialized
DEBUG - 2011-09-13 14:11:20 --> Hooks Class Initialized
DEBUG - 2011-09-13 14:11:20 --> Utf8 Class Initialized
DEBUG - 2011-09-13 14:11:20 --> UTF-8 Support Enabled
DEBUG - 2011-09-13 14:11:20 --> URI Class Initialized
DEBUG - 2011-09-13 14:11:20 --> Router Class Initialized
ERROR - 2011-09-13 14:11:20 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-09-13 14:11:28 --> Config Class Initialized
DEBUG - 2011-09-13 14:11:28 --> Hooks Class Initialized
DEBUG - 2011-09-13 14:11:28 --> Utf8 Class Initialized
DEBUG - 2011-09-13 14:11:28 --> UTF-8 Support Enabled
DEBUG - 2011-09-13 14:11:28 --> URI Class Initialized
DEBUG - 2011-09-13 14:11:28 --> Router Class Initialized
DEBUG - 2011-09-13 14:11:28 --> Output Class Initialized
DEBUG - 2011-09-13 14:11:28 --> Input Class Initialized
DEBUG - 2011-09-13 14:11:28 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-13 14:11:28 --> Language Class Initialized
DEBUG - 2011-09-13 14:11:28 --> Loader Class Initialized
DEBUG - 2011-09-13 14:11:28 --> Controller Class Initialized
ERROR - 2011-09-13 14:11:28 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-09-13 14:11:28 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-09-13 14:11:28 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-09-13 14:11:28 --> Model Class Initialized
DEBUG - 2011-09-13 14:11:28 --> Model Class Initialized
DEBUG - 2011-09-13 14:11:28 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-13 14:11:28 --> Database Driver Class Initialized
DEBUG - 2011-09-13 14:11:28 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-09-13 14:11:28 --> Helper loaded: url_helper
DEBUG - 2011-09-13 14:11:28 --> File loaded: application/views/common/header.php
DEBUG - 2011-09-13 14:11:28 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-09-13 14:11:28 --> File loaded: application/views/common/footer.php
DEBUG - 2011-09-13 14:11:28 --> File loaded: application/views/layout/main.php
DEBUG - 2011-09-13 14:11:28 --> Final output sent to browser
DEBUG - 2011-09-13 14:11:28 --> Total execution time: 0.0309
DEBUG - 2011-09-13 14:11:30 --> Config Class Initialized
DEBUG - 2011-09-13 14:11:30 --> Hooks Class Initialized
DEBUG - 2011-09-13 14:11:30 --> Utf8 Class Initialized
DEBUG - 2011-09-13 14:11:30 --> UTF-8 Support Enabled
DEBUG - 2011-09-13 14:11:30 --> URI Class Initialized
DEBUG - 2011-09-13 14:11:30 --> Router Class Initialized
DEBUG - 2011-09-13 14:11:30 --> Output Class Initialized
DEBUG - 2011-09-13 14:11:30 --> Input Class Initialized
DEBUG - 2011-09-13 14:11:30 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-13 14:11:30 --> Language Class Initialized
DEBUG - 2011-09-13 14:11:30 --> Loader Class Initialized
DEBUG - 2011-09-13 14:11:30 --> Controller Class Initialized
DEBUG - 2011-09-13 14:11:30 --> Model Class Initialized
DEBUG - 2011-09-13 14:11:30 --> Model Class Initialized
DEBUG - 2011-09-13 14:11:30 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-13 14:11:30 --> Database Driver Class Initialized
DEBUG - 2011-09-13 14:11:31 --> Final output sent to browser
DEBUG - 2011-09-13 14:11:31 --> Total execution time: 0.5949
DEBUG - 2011-09-13 14:11:32 --> Config Class Initialized
DEBUG - 2011-09-13 14:11:32 --> Hooks Class Initialized
DEBUG - 2011-09-13 14:11:32 --> Utf8 Class Initialized
DEBUG - 2011-09-13 14:11:32 --> UTF-8 Support Enabled
DEBUG - 2011-09-13 14:11:32 --> URI Class Initialized
DEBUG - 2011-09-13 14:11:32 --> Router Class Initialized
ERROR - 2011-09-13 14:11:32 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-09-13 14:21:25 --> Config Class Initialized
DEBUG - 2011-09-13 14:21:25 --> Hooks Class Initialized
DEBUG - 2011-09-13 14:21:25 --> Utf8 Class Initialized
DEBUG - 2011-09-13 14:21:25 --> UTF-8 Support Enabled
DEBUG - 2011-09-13 14:21:25 --> URI Class Initialized
DEBUG - 2011-09-13 14:21:25 --> Router Class Initialized
DEBUG - 2011-09-13 14:21:25 --> Output Class Initialized
DEBUG - 2011-09-13 14:21:25 --> Input Class Initialized
DEBUG - 2011-09-13 14:21:25 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-13 14:21:25 --> Language Class Initialized
DEBUG - 2011-09-13 14:21:25 --> Loader Class Initialized
DEBUG - 2011-09-13 14:21:25 --> Controller Class Initialized
DEBUG - 2011-09-13 14:21:25 --> Model Class Initialized
DEBUG - 2011-09-13 14:21:25 --> Model Class Initialized
DEBUG - 2011-09-13 14:21:25 --> Model Class Initialized
DEBUG - 2011-09-13 14:21:25 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-13 14:21:25 --> Database Driver Class Initialized
DEBUG - 2011-09-13 14:21:25 --> File loaded: application/views/table/main.php
DEBUG - 2011-09-13 14:21:25 --> Helper loaded: url_helper
DEBUG - 2011-09-13 14:21:25 --> File loaded: application/views/common/header.php
DEBUG - 2011-09-13 14:21:25 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-09-13 14:21:25 --> File loaded: application/views/common/footer.php
DEBUG - 2011-09-13 14:21:25 --> File loaded: application/views/layout/main.php
DEBUG - 2011-09-13 14:21:25 --> Final output sent to browser
DEBUG - 2011-09-13 14:21:25 --> Total execution time: 0.0463
DEBUG - 2011-09-13 14:21:30 --> Config Class Initialized
DEBUG - 2011-09-13 14:21:30 --> Hooks Class Initialized
DEBUG - 2011-09-13 14:21:30 --> Utf8 Class Initialized
DEBUG - 2011-09-13 14:21:30 --> UTF-8 Support Enabled
DEBUG - 2011-09-13 14:21:30 --> URI Class Initialized
DEBUG - 2011-09-13 14:21:30 --> Router Class Initialized
ERROR - 2011-09-13 14:21:30 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-09-13 14:21:39 --> Config Class Initialized
DEBUG - 2011-09-13 14:21:39 --> Hooks Class Initialized
DEBUG - 2011-09-13 14:21:39 --> Utf8 Class Initialized
DEBUG - 2011-09-13 14:21:39 --> UTF-8 Support Enabled
DEBUG - 2011-09-13 14:21:39 --> URI Class Initialized
DEBUG - 2011-09-13 14:21:39 --> Router Class Initialized
DEBUG - 2011-09-13 14:21:39 --> Output Class Initialized
DEBUG - 2011-09-13 14:21:39 --> Input Class Initialized
DEBUG - 2011-09-13 14:21:39 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-13 14:21:39 --> Language Class Initialized
DEBUG - 2011-09-13 14:21:39 --> Loader Class Initialized
DEBUG - 2011-09-13 14:21:39 --> Controller Class Initialized
DEBUG - 2011-09-13 14:21:39 --> Model Class Initialized
DEBUG - 2011-09-13 14:21:39 --> Model Class Initialized
DEBUG - 2011-09-13 14:21:39 --> Model Class Initialized
DEBUG - 2011-09-13 14:21:39 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-13 14:21:39 --> Database Driver Class Initialized
DEBUG - 2011-09-13 14:21:39 --> File loaded: application/views/table/main.php
DEBUG - 2011-09-13 14:21:39 --> Helper loaded: url_helper
DEBUG - 2011-09-13 14:21:39 --> File loaded: application/views/common/header.php
DEBUG - 2011-09-13 14:21:39 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-09-13 14:21:39 --> File loaded: application/views/common/footer.php
DEBUG - 2011-09-13 14:21:39 --> File loaded: application/views/layout/main.php
DEBUG - 2011-09-13 14:21:39 --> Final output sent to browser
DEBUG - 2011-09-13 14:21:39 --> Total execution time: 0.4364
DEBUG - 2011-09-13 14:21:41 --> Config Class Initialized
DEBUG - 2011-09-13 14:21:41 --> Hooks Class Initialized
DEBUG - 2011-09-13 14:21:41 --> Utf8 Class Initialized
DEBUG - 2011-09-13 14:21:41 --> UTF-8 Support Enabled
DEBUG - 2011-09-13 14:21:41 --> URI Class Initialized
DEBUG - 2011-09-13 14:21:41 --> Router Class Initialized
ERROR - 2011-09-13 14:21:41 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-09-13 14:21:48 --> Config Class Initialized
DEBUG - 2011-09-13 14:21:48 --> Hooks Class Initialized
DEBUG - 2011-09-13 14:21:48 --> Utf8 Class Initialized
DEBUG - 2011-09-13 14:21:48 --> UTF-8 Support Enabled
DEBUG - 2011-09-13 14:21:48 --> URI Class Initialized
DEBUG - 2011-09-13 14:21:48 --> Router Class Initialized
DEBUG - 2011-09-13 14:21:48 --> Output Class Initialized
DEBUG - 2011-09-13 14:21:48 --> Input Class Initialized
DEBUG - 2011-09-13 14:21:48 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-13 14:21:48 --> Language Class Initialized
DEBUG - 2011-09-13 14:21:48 --> Loader Class Initialized
DEBUG - 2011-09-13 14:21:48 --> Controller Class Initialized
DEBUG - 2011-09-13 14:21:48 --> Model Class Initialized
DEBUG - 2011-09-13 14:21:48 --> Model Class Initialized
DEBUG - 2011-09-13 14:21:48 --> Model Class Initialized
DEBUG - 2011-09-13 14:21:48 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-13 14:21:48 --> Database Driver Class Initialized
DEBUG - 2011-09-13 14:21:49 --> File loaded: application/views/table/main.php
DEBUG - 2011-09-13 14:21:49 --> Helper loaded: url_helper
DEBUG - 2011-09-13 14:21:49 --> File loaded: application/views/common/header.php
DEBUG - 2011-09-13 14:21:49 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-09-13 14:21:49 --> File loaded: application/views/common/footer.php
DEBUG - 2011-09-13 14:21:49 --> File loaded: application/views/layout/main.php
DEBUG - 2011-09-13 14:21:49 --> Final output sent to browser
DEBUG - 2011-09-13 14:21:49 --> Total execution time: 0.9813
DEBUG - 2011-09-13 14:21:52 --> Config Class Initialized
DEBUG - 2011-09-13 14:21:52 --> Hooks Class Initialized
DEBUG - 2011-09-13 14:21:52 --> Utf8 Class Initialized
DEBUG - 2011-09-13 14:21:52 --> UTF-8 Support Enabled
DEBUG - 2011-09-13 14:21:52 --> URI Class Initialized
DEBUG - 2011-09-13 14:21:52 --> Router Class Initialized
ERROR - 2011-09-13 14:21:52 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-09-13 14:21:53 --> Config Class Initialized
DEBUG - 2011-09-13 14:21:53 --> Hooks Class Initialized
DEBUG - 2011-09-13 14:21:53 --> Utf8 Class Initialized
DEBUG - 2011-09-13 14:21:53 --> UTF-8 Support Enabled
DEBUG - 2011-09-13 14:21:53 --> URI Class Initialized
DEBUG - 2011-09-13 14:21:53 --> Router Class Initialized
DEBUG - 2011-09-13 14:21:53 --> Output Class Initialized
DEBUG - 2011-09-13 14:21:53 --> Input Class Initialized
DEBUG - 2011-09-13 14:21:53 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-13 14:21:53 --> Language Class Initialized
DEBUG - 2011-09-13 14:21:53 --> Loader Class Initialized
DEBUG - 2011-09-13 14:21:53 --> Controller Class Initialized
DEBUG - 2011-09-13 14:21:53 --> Model Class Initialized
DEBUG - 2011-09-13 14:21:53 --> Model Class Initialized
DEBUG - 2011-09-13 14:21:53 --> Model Class Initialized
DEBUG - 2011-09-13 14:21:53 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-13 14:21:53 --> Database Driver Class Initialized
DEBUG - 2011-09-13 14:21:54 --> File loaded: application/views/table/main.php
DEBUG - 2011-09-13 14:21:54 --> Helper loaded: url_helper
DEBUG - 2011-09-13 14:21:54 --> File loaded: application/views/common/header.php
DEBUG - 2011-09-13 14:21:54 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-09-13 14:21:54 --> File loaded: application/views/common/footer.php
DEBUG - 2011-09-13 14:21:54 --> File loaded: application/views/layout/main.php
DEBUG - 2011-09-13 14:21:54 --> Final output sent to browser
DEBUG - 2011-09-13 14:21:54 --> Total execution time: 0.9883
DEBUG - 2011-09-13 14:22:50 --> Config Class Initialized
DEBUG - 2011-09-13 14:22:50 --> Hooks Class Initialized
DEBUG - 2011-09-13 14:22:50 --> Utf8 Class Initialized
DEBUG - 2011-09-13 14:22:50 --> UTF-8 Support Enabled
DEBUG - 2011-09-13 14:22:50 --> URI Class Initialized
DEBUG - 2011-09-13 14:22:50 --> Router Class Initialized
DEBUG - 2011-09-13 14:22:50 --> Output Class Initialized
DEBUG - 2011-09-13 14:22:50 --> Input Class Initialized
DEBUG - 2011-09-13 14:22:50 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-13 14:22:50 --> Language Class Initialized
DEBUG - 2011-09-13 14:22:50 --> Loader Class Initialized
DEBUG - 2011-09-13 14:22:50 --> Controller Class Initialized
DEBUG - 2011-09-13 14:22:50 --> Model Class Initialized
DEBUG - 2011-09-13 14:22:50 --> Model Class Initialized
DEBUG - 2011-09-13 14:22:50 --> Model Class Initialized
DEBUG - 2011-09-13 14:22:50 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-13 14:22:50 --> Database Driver Class Initialized
DEBUG - 2011-09-13 14:22:51 --> File loaded: application/views/table/main.php
DEBUG - 2011-09-13 14:22:51 --> Helper loaded: url_helper
DEBUG - 2011-09-13 14:22:51 --> File loaded: application/views/common/header.php
DEBUG - 2011-09-13 14:22:51 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-09-13 14:22:51 --> File loaded: application/views/common/footer.php
DEBUG - 2011-09-13 14:22:51 --> File loaded: application/views/layout/main.php
DEBUG - 2011-09-13 14:22:51 --> Final output sent to browser
DEBUG - 2011-09-13 14:22:51 --> Total execution time: 0.0996
DEBUG - 2011-09-13 14:23:07 --> Config Class Initialized
DEBUG - 2011-09-13 14:23:07 --> Hooks Class Initialized
DEBUG - 2011-09-13 14:23:07 --> Utf8 Class Initialized
DEBUG - 2011-09-13 14:23:07 --> UTF-8 Support Enabled
DEBUG - 2011-09-13 14:23:07 --> URI Class Initialized
DEBUG - 2011-09-13 14:23:07 --> Router Class Initialized
ERROR - 2011-09-13 14:23:07 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-09-13 14:23:14 --> Config Class Initialized
DEBUG - 2011-09-13 14:23:14 --> Hooks Class Initialized
DEBUG - 2011-09-13 14:23:14 --> Utf8 Class Initialized
DEBUG - 2011-09-13 14:23:14 --> UTF-8 Support Enabled
DEBUG - 2011-09-13 14:23:14 --> URI Class Initialized
DEBUG - 2011-09-13 14:23:14 --> Router Class Initialized
DEBUG - 2011-09-13 14:23:14 --> Output Class Initialized
DEBUG - 2011-09-13 14:23:14 --> Input Class Initialized
DEBUG - 2011-09-13 14:23:14 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-13 14:23:14 --> Language Class Initialized
DEBUG - 2011-09-13 14:23:14 --> Loader Class Initialized
DEBUG - 2011-09-13 14:23:14 --> Controller Class Initialized
DEBUG - 2011-09-13 14:23:14 --> Model Class Initialized
DEBUG - 2011-09-13 14:23:14 --> Model Class Initialized
DEBUG - 2011-09-13 14:23:14 --> Model Class Initialized
DEBUG - 2011-09-13 14:23:14 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-13 14:23:14 --> Database Driver Class Initialized
DEBUG - 2011-09-13 14:23:14 --> File loaded: application/views/table/main.php
DEBUG - 2011-09-13 14:23:14 --> Helper loaded: url_helper
DEBUG - 2011-09-13 14:23:14 --> File loaded: application/views/common/header.php
DEBUG - 2011-09-13 14:23:14 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-09-13 14:23:14 --> File loaded: application/views/common/footer.php
DEBUG - 2011-09-13 14:23:14 --> File loaded: application/views/layout/main.php
DEBUG - 2011-09-13 14:23:14 --> Final output sent to browser
DEBUG - 2011-09-13 14:23:14 --> Total execution time: 0.1382
DEBUG - 2011-09-13 14:23:19 --> Config Class Initialized
DEBUG - 2011-09-13 14:23:19 --> Hooks Class Initialized
DEBUG - 2011-09-13 14:23:19 --> Utf8 Class Initialized
DEBUG - 2011-09-13 14:23:19 --> UTF-8 Support Enabled
DEBUG - 2011-09-13 14:23:19 --> URI Class Initialized
DEBUG - 2011-09-13 14:23:19 --> Router Class Initialized
DEBUG - 2011-09-13 14:23:19 --> Output Class Initialized
DEBUG - 2011-09-13 14:23:19 --> Input Class Initialized
DEBUG - 2011-09-13 14:23:19 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-13 14:23:19 --> Language Class Initialized
DEBUG - 2011-09-13 14:23:19 --> Loader Class Initialized
DEBUG - 2011-09-13 14:23:19 --> Controller Class Initialized
DEBUG - 2011-09-13 14:23:19 --> Model Class Initialized
DEBUG - 2011-09-13 14:23:19 --> Model Class Initialized
DEBUG - 2011-09-13 14:23:19 --> Model Class Initialized
DEBUG - 2011-09-13 14:23:19 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-13 14:23:19 --> Database Driver Class Initialized
DEBUG - 2011-09-13 14:23:19 --> File loaded: application/views/table/main.php
DEBUG - 2011-09-13 14:23:19 --> Helper loaded: url_helper
DEBUG - 2011-09-13 14:23:19 --> File loaded: application/views/common/header.php
DEBUG - 2011-09-13 14:23:19 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-09-13 14:23:19 --> File loaded: application/views/common/footer.php
DEBUG - 2011-09-13 14:23:19 --> File loaded: application/views/layout/main.php
DEBUG - 2011-09-13 14:23:19 --> Final output sent to browser
DEBUG - 2011-09-13 14:23:19 --> Total execution time: 0.7247
DEBUG - 2011-09-13 14:23:24 --> Config Class Initialized
DEBUG - 2011-09-13 14:23:24 --> Hooks Class Initialized
DEBUG - 2011-09-13 14:23:24 --> Utf8 Class Initialized
DEBUG - 2011-09-13 14:23:24 --> UTF-8 Support Enabled
DEBUG - 2011-09-13 14:23:24 --> URI Class Initialized
DEBUG - 2011-09-13 14:23:24 --> Router Class Initialized
ERROR - 2011-09-13 14:23:24 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-09-13 14:23:30 --> Config Class Initialized
DEBUG - 2011-09-13 14:23:30 --> Hooks Class Initialized
DEBUG - 2011-09-13 14:23:30 --> Utf8 Class Initialized
DEBUG - 2011-09-13 14:23:30 --> UTF-8 Support Enabled
DEBUG - 2011-09-13 14:23:30 --> URI Class Initialized
DEBUG - 2011-09-13 14:23:30 --> Router Class Initialized
DEBUG - 2011-09-13 14:23:30 --> Output Class Initialized
DEBUG - 2011-09-13 14:23:30 --> Input Class Initialized
DEBUG - 2011-09-13 14:23:30 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-13 14:23:30 --> Language Class Initialized
DEBUG - 2011-09-13 14:23:30 --> Loader Class Initialized
DEBUG - 2011-09-13 14:23:30 --> Controller Class Initialized
DEBUG - 2011-09-13 14:23:30 --> Model Class Initialized
DEBUG - 2011-09-13 14:23:30 --> Model Class Initialized
DEBUG - 2011-09-13 14:23:30 --> Model Class Initialized
DEBUG - 2011-09-13 14:23:30 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-13 14:23:30 --> Database Driver Class Initialized
DEBUG - 2011-09-13 14:23:31 --> File loaded: application/views/table/main.php
DEBUG - 2011-09-13 14:23:31 --> Helper loaded: url_helper
DEBUG - 2011-09-13 14:23:31 --> File loaded: application/views/common/header.php
DEBUG - 2011-09-13 14:23:31 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-09-13 14:23:31 --> File loaded: application/views/common/footer.php
DEBUG - 2011-09-13 14:23:31 --> File loaded: application/views/layout/main.php
DEBUG - 2011-09-13 14:23:31 --> Final output sent to browser
DEBUG - 2011-09-13 14:23:31 --> Total execution time: 1.3852
DEBUG - 2011-09-13 14:23:35 --> Config Class Initialized
DEBUG - 2011-09-13 14:23:35 --> Hooks Class Initialized
DEBUG - 2011-09-13 14:23:35 --> Utf8 Class Initialized
DEBUG - 2011-09-13 14:23:35 --> UTF-8 Support Enabled
DEBUG - 2011-09-13 14:23:35 --> URI Class Initialized
DEBUG - 2011-09-13 14:23:35 --> Router Class Initialized
ERROR - 2011-09-13 14:23:35 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-09-13 14:23:41 --> Config Class Initialized
DEBUG - 2011-09-13 14:23:41 --> Hooks Class Initialized
DEBUG - 2011-09-13 14:23:41 --> Utf8 Class Initialized
DEBUG - 2011-09-13 14:23:41 --> UTF-8 Support Enabled
DEBUG - 2011-09-13 14:23:41 --> URI Class Initialized
DEBUG - 2011-09-13 14:23:41 --> Router Class Initialized
DEBUG - 2011-09-13 14:23:41 --> Output Class Initialized
DEBUG - 2011-09-13 14:23:41 --> Input Class Initialized
DEBUG - 2011-09-13 14:23:41 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-13 14:23:41 --> Language Class Initialized
DEBUG - 2011-09-13 14:23:41 --> Loader Class Initialized
DEBUG - 2011-09-13 14:23:41 --> Controller Class Initialized
DEBUG - 2011-09-13 14:23:41 --> Model Class Initialized
DEBUG - 2011-09-13 14:23:41 --> Model Class Initialized
DEBUG - 2011-09-13 14:23:41 --> Model Class Initialized
DEBUG - 2011-09-13 14:23:41 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-13 14:23:41 --> Database Driver Class Initialized
DEBUG - 2011-09-13 14:23:41 --> File loaded: application/views/table/main.php
DEBUG - 2011-09-13 14:23:41 --> Helper loaded: url_helper
DEBUG - 2011-09-13 14:23:41 --> File loaded: application/views/common/header.php
DEBUG - 2011-09-13 14:23:41 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-09-13 14:23:41 --> File loaded: application/views/common/footer.php
DEBUG - 2011-09-13 14:23:41 --> File loaded: application/views/layout/main.php
DEBUG - 2011-09-13 14:23:41 --> Final output sent to browser
DEBUG - 2011-09-13 14:23:41 --> Total execution time: 0.1813
DEBUG - 2011-09-13 14:23:45 --> Config Class Initialized
DEBUG - 2011-09-13 14:23:45 --> Hooks Class Initialized
DEBUG - 2011-09-13 14:23:45 --> Utf8 Class Initialized
DEBUG - 2011-09-13 14:23:45 --> UTF-8 Support Enabled
DEBUG - 2011-09-13 14:23:45 --> URI Class Initialized
DEBUG - 2011-09-13 14:23:45 --> Router Class Initialized
ERROR - 2011-09-13 14:23:45 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-09-13 14:23:52 --> Config Class Initialized
DEBUG - 2011-09-13 14:23:52 --> Hooks Class Initialized
DEBUG - 2011-09-13 14:23:52 --> Utf8 Class Initialized
DEBUG - 2011-09-13 14:23:52 --> UTF-8 Support Enabled
DEBUG - 2011-09-13 14:23:52 --> URI Class Initialized
DEBUG - 2011-09-13 14:23:52 --> Router Class Initialized
DEBUG - 2011-09-13 14:23:52 --> Output Class Initialized
DEBUG - 2011-09-13 14:23:52 --> Input Class Initialized
DEBUG - 2011-09-13 14:23:52 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-13 14:23:52 --> Language Class Initialized
DEBUG - 2011-09-13 14:23:52 --> Loader Class Initialized
DEBUG - 2011-09-13 14:23:52 --> Controller Class Initialized
DEBUG - 2011-09-13 14:23:52 --> Model Class Initialized
DEBUG - 2011-09-13 14:23:52 --> Model Class Initialized
DEBUG - 2011-09-13 14:23:52 --> Model Class Initialized
DEBUG - 2011-09-13 14:23:52 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-13 14:23:52 --> Database Driver Class Initialized
DEBUG - 2011-09-13 14:23:54 --> File loaded: application/views/table/main.php
DEBUG - 2011-09-13 14:23:54 --> Helper loaded: url_helper
DEBUG - 2011-09-13 14:23:54 --> File loaded: application/views/common/header.php
DEBUG - 2011-09-13 14:23:54 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-09-13 14:23:54 --> File loaded: application/views/common/footer.php
DEBUG - 2011-09-13 14:23:54 --> File loaded: application/views/layout/main.php
DEBUG - 2011-09-13 14:23:54 --> Final output sent to browser
DEBUG - 2011-09-13 14:23:54 --> Total execution time: 2.4700
DEBUG - 2011-09-13 14:23:58 --> Config Class Initialized
DEBUG - 2011-09-13 14:23:58 --> Hooks Class Initialized
DEBUG - 2011-09-13 14:23:58 --> Utf8 Class Initialized
DEBUG - 2011-09-13 14:23:58 --> UTF-8 Support Enabled
DEBUG - 2011-09-13 14:23:58 --> URI Class Initialized
DEBUG - 2011-09-13 14:23:58 --> Router Class Initialized
ERROR - 2011-09-13 14:23:58 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-09-13 14:23:59 --> Config Class Initialized
DEBUG - 2011-09-13 14:23:59 --> Hooks Class Initialized
DEBUG - 2011-09-13 14:23:59 --> Utf8 Class Initialized
DEBUG - 2011-09-13 14:23:59 --> UTF-8 Support Enabled
DEBUG - 2011-09-13 14:23:59 --> URI Class Initialized
DEBUG - 2011-09-13 14:23:59 --> Router Class Initialized
ERROR - 2011-09-13 14:23:59 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-09-13 14:24:07 --> Config Class Initialized
DEBUG - 2011-09-13 14:24:07 --> Hooks Class Initialized
DEBUG - 2011-09-13 14:24:07 --> Utf8 Class Initialized
DEBUG - 2011-09-13 14:24:07 --> UTF-8 Support Enabled
DEBUG - 2011-09-13 14:24:07 --> URI Class Initialized
DEBUG - 2011-09-13 14:24:07 --> Router Class Initialized
DEBUG - 2011-09-13 14:24:07 --> Output Class Initialized
DEBUG - 2011-09-13 14:24:07 --> Input Class Initialized
DEBUG - 2011-09-13 14:24:07 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-13 14:24:07 --> Language Class Initialized
DEBUG - 2011-09-13 14:24:07 --> Loader Class Initialized
DEBUG - 2011-09-13 14:24:07 --> Controller Class Initialized
DEBUG - 2011-09-13 14:24:07 --> Model Class Initialized
DEBUG - 2011-09-13 14:24:07 --> Model Class Initialized
DEBUG - 2011-09-13 14:24:07 --> Model Class Initialized
DEBUG - 2011-09-13 14:24:07 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-13 14:24:07 --> Database Driver Class Initialized
DEBUG - 2011-09-13 14:24:08 --> File loaded: application/views/table/main.php
DEBUG - 2011-09-13 14:24:08 --> Helper loaded: url_helper
DEBUG - 2011-09-13 14:24:08 --> File loaded: application/views/common/header.php
DEBUG - 2011-09-13 14:24:08 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-09-13 14:24:08 --> File loaded: application/views/common/footer.php
DEBUG - 2011-09-13 14:24:08 --> File loaded: application/views/layout/main.php
DEBUG - 2011-09-13 14:24:08 --> Final output sent to browser
DEBUG - 2011-09-13 14:24:08 --> Total execution time: 0.9894
DEBUG - 2011-09-13 14:24:12 --> Config Class Initialized
DEBUG - 2011-09-13 14:24:12 --> Hooks Class Initialized
DEBUG - 2011-09-13 14:24:12 --> Utf8 Class Initialized
DEBUG - 2011-09-13 14:24:12 --> UTF-8 Support Enabled
DEBUG - 2011-09-13 14:24:12 --> URI Class Initialized
DEBUG - 2011-09-13 14:24:12 --> Router Class Initialized
ERROR - 2011-09-13 14:24:12 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-09-13 14:24:20 --> Config Class Initialized
DEBUG - 2011-09-13 14:24:20 --> Hooks Class Initialized
DEBUG - 2011-09-13 14:24:20 --> Utf8 Class Initialized
DEBUG - 2011-09-13 14:24:20 --> UTF-8 Support Enabled
DEBUG - 2011-09-13 14:24:20 --> URI Class Initialized
DEBUG - 2011-09-13 14:24:20 --> Router Class Initialized
DEBUG - 2011-09-13 14:24:20 --> Output Class Initialized
DEBUG - 2011-09-13 14:24:20 --> Input Class Initialized
DEBUG - 2011-09-13 14:24:20 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-13 14:24:20 --> Language Class Initialized
DEBUG - 2011-09-13 14:24:20 --> Loader Class Initialized
DEBUG - 2011-09-13 14:24:20 --> Controller Class Initialized
DEBUG - 2011-09-13 14:24:20 --> Model Class Initialized
DEBUG - 2011-09-13 14:24:20 --> Model Class Initialized
DEBUG - 2011-09-13 14:24:20 --> Model Class Initialized
DEBUG - 2011-09-13 14:24:20 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-13 14:24:20 --> Database Driver Class Initialized
DEBUG - 2011-09-13 14:24:21 --> File loaded: application/views/table/main.php
DEBUG - 2011-09-13 14:24:21 --> Helper loaded: url_helper
DEBUG - 2011-09-13 14:24:21 --> File loaded: application/views/common/header.php
DEBUG - 2011-09-13 14:24:21 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-09-13 14:24:21 --> File loaded: application/views/common/footer.php
DEBUG - 2011-09-13 14:24:21 --> File loaded: application/views/layout/main.php
DEBUG - 2011-09-13 14:24:21 --> Final output sent to browser
DEBUG - 2011-09-13 14:24:21 --> Total execution time: 0.6704
DEBUG - 2011-09-13 14:24:23 --> Config Class Initialized
DEBUG - 2011-09-13 14:24:23 --> Hooks Class Initialized
DEBUG - 2011-09-13 14:24:23 --> Utf8 Class Initialized
DEBUG - 2011-09-13 14:24:23 --> UTF-8 Support Enabled
DEBUG - 2011-09-13 14:24:23 --> URI Class Initialized
DEBUG - 2011-09-13 14:24:23 --> Router Class Initialized
ERROR - 2011-09-13 14:24:23 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-09-13 14:24:32 --> Config Class Initialized
DEBUG - 2011-09-13 14:24:32 --> Hooks Class Initialized
DEBUG - 2011-09-13 14:24:32 --> Utf8 Class Initialized
DEBUG - 2011-09-13 14:24:32 --> UTF-8 Support Enabled
DEBUG - 2011-09-13 14:24:32 --> URI Class Initialized
DEBUG - 2011-09-13 14:24:32 --> Router Class Initialized
DEBUG - 2011-09-13 14:24:32 --> Output Class Initialized
DEBUG - 2011-09-13 14:24:32 --> Input Class Initialized
DEBUG - 2011-09-13 14:24:32 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-13 14:24:32 --> Language Class Initialized
DEBUG - 2011-09-13 14:24:32 --> Loader Class Initialized
DEBUG - 2011-09-13 14:24:32 --> Controller Class Initialized
DEBUG - 2011-09-13 14:24:32 --> Model Class Initialized
DEBUG - 2011-09-13 14:24:32 --> Model Class Initialized
DEBUG - 2011-09-13 14:24:32 --> Model Class Initialized
DEBUG - 2011-09-13 14:24:32 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-13 14:24:32 --> Database Driver Class Initialized
DEBUG - 2011-09-13 14:24:33 --> File loaded: application/views/table/main.php
DEBUG - 2011-09-13 14:24:33 --> Helper loaded: url_helper
DEBUG - 2011-09-13 14:24:33 --> File loaded: application/views/common/header.php
DEBUG - 2011-09-13 14:24:33 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-09-13 14:24:33 --> File loaded: application/views/common/footer.php
DEBUG - 2011-09-13 14:24:33 --> File loaded: application/views/layout/main.php
DEBUG - 2011-09-13 14:24:33 --> Final output sent to browser
DEBUG - 2011-09-13 14:24:33 --> Total execution time: 0.8823
DEBUG - 2011-09-13 14:24:39 --> Config Class Initialized
DEBUG - 2011-09-13 14:24:39 --> Hooks Class Initialized
DEBUG - 2011-09-13 14:24:39 --> Utf8 Class Initialized
DEBUG - 2011-09-13 14:24:39 --> UTF-8 Support Enabled
DEBUG - 2011-09-13 14:24:39 --> URI Class Initialized
DEBUG - 2011-09-13 14:24:39 --> Router Class Initialized
ERROR - 2011-09-13 14:24:39 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-09-13 14:25:00 --> Config Class Initialized
DEBUG - 2011-09-13 14:25:00 --> Hooks Class Initialized
DEBUG - 2011-09-13 14:25:00 --> Utf8 Class Initialized
DEBUG - 2011-09-13 14:25:00 --> UTF-8 Support Enabled
DEBUG - 2011-09-13 14:25:00 --> URI Class Initialized
DEBUG - 2011-09-13 14:25:00 --> Router Class Initialized
DEBUG - 2011-09-13 14:25:00 --> Output Class Initialized
DEBUG - 2011-09-13 14:25:00 --> Input Class Initialized
DEBUG - 2011-09-13 14:25:00 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-13 14:25:00 --> Language Class Initialized
DEBUG - 2011-09-13 14:25:00 --> Loader Class Initialized
DEBUG - 2011-09-13 14:25:00 --> Controller Class Initialized
DEBUG - 2011-09-13 14:25:00 --> Model Class Initialized
DEBUG - 2011-09-13 14:25:00 --> Model Class Initialized
DEBUG - 2011-09-13 14:25:00 --> Model Class Initialized
DEBUG - 2011-09-13 14:25:00 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-13 14:25:00 --> Database Driver Class Initialized
DEBUG - 2011-09-13 14:25:01 --> File loaded: application/views/table/main.php
DEBUG - 2011-09-13 14:25:01 --> Helper loaded: url_helper
DEBUG - 2011-09-13 14:25:01 --> File loaded: application/views/common/header.php
DEBUG - 2011-09-13 14:25:01 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-09-13 14:25:01 --> File loaded: application/views/common/footer.php
DEBUG - 2011-09-13 14:25:01 --> File loaded: application/views/layout/main.php
DEBUG - 2011-09-13 14:25:01 --> Final output sent to browser
DEBUG - 2011-09-13 14:25:01 --> Total execution time: 0.3608
DEBUG - 2011-09-13 14:25:04 --> Config Class Initialized
DEBUG - 2011-09-13 14:25:04 --> Hooks Class Initialized
DEBUG - 2011-09-13 14:25:04 --> Utf8 Class Initialized
DEBUG - 2011-09-13 14:25:04 --> UTF-8 Support Enabled
DEBUG - 2011-09-13 14:25:04 --> URI Class Initialized
DEBUG - 2011-09-13 14:25:04 --> Router Class Initialized
ERROR - 2011-09-13 14:25:04 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-09-13 14:25:15 --> Config Class Initialized
DEBUG - 2011-09-13 14:25:15 --> Hooks Class Initialized
DEBUG - 2011-09-13 14:25:15 --> Utf8 Class Initialized
DEBUG - 2011-09-13 14:25:15 --> UTF-8 Support Enabled
DEBUG - 2011-09-13 14:25:15 --> URI Class Initialized
DEBUG - 2011-09-13 14:25:15 --> Router Class Initialized
DEBUG - 2011-09-13 14:25:15 --> Output Class Initialized
DEBUG - 2011-09-13 14:25:15 --> Input Class Initialized
DEBUG - 2011-09-13 14:25:15 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-13 14:25:15 --> Language Class Initialized
DEBUG - 2011-09-13 14:25:15 --> Loader Class Initialized
DEBUG - 2011-09-13 14:25:15 --> Controller Class Initialized
DEBUG - 2011-09-13 14:25:15 --> Model Class Initialized
DEBUG - 2011-09-13 14:25:15 --> Model Class Initialized
DEBUG - 2011-09-13 14:25:15 --> Model Class Initialized
DEBUG - 2011-09-13 14:25:15 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-13 14:25:16 --> Database Driver Class Initialized
DEBUG - 2011-09-13 14:25:16 --> File loaded: application/views/table/main.php
DEBUG - 2011-09-13 14:25:16 --> Helper loaded: url_helper
DEBUG - 2011-09-13 14:25:16 --> File loaded: application/views/common/header.php
DEBUG - 2011-09-13 14:25:16 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-09-13 14:25:16 --> File loaded: application/views/common/footer.php
DEBUG - 2011-09-13 14:25:16 --> File loaded: application/views/layout/main.php
DEBUG - 2011-09-13 14:25:16 --> Final output sent to browser
DEBUG - 2011-09-13 14:25:16 --> Total execution time: 0.6500
DEBUG - 2011-09-13 14:25:20 --> Config Class Initialized
DEBUG - 2011-09-13 14:25:20 --> Hooks Class Initialized
DEBUG - 2011-09-13 14:25:20 --> Utf8 Class Initialized
DEBUG - 2011-09-13 14:25:20 --> UTF-8 Support Enabled
DEBUG - 2011-09-13 14:25:20 --> URI Class Initialized
DEBUG - 2011-09-13 14:25:20 --> Router Class Initialized
ERROR - 2011-09-13 14:25:20 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-09-13 14:25:23 --> Config Class Initialized
DEBUG - 2011-09-13 14:25:23 --> Hooks Class Initialized
DEBUG - 2011-09-13 14:25:23 --> Utf8 Class Initialized
DEBUG - 2011-09-13 14:25:23 --> UTF-8 Support Enabled
DEBUG - 2011-09-13 14:25:23 --> URI Class Initialized
DEBUG - 2011-09-13 14:25:23 --> Router Class Initialized
DEBUG - 2011-09-13 14:25:23 --> Output Class Initialized
DEBUG - 2011-09-13 14:25:23 --> Input Class Initialized
DEBUG - 2011-09-13 14:25:23 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-13 14:25:23 --> Language Class Initialized
DEBUG - 2011-09-13 14:25:23 --> Loader Class Initialized
DEBUG - 2011-09-13 14:25:23 --> Controller Class Initialized
DEBUG - 2011-09-13 14:25:23 --> Model Class Initialized
DEBUG - 2011-09-13 14:25:23 --> Model Class Initialized
DEBUG - 2011-09-13 14:25:23 --> Model Class Initialized
DEBUG - 2011-09-13 14:25:23 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-13 14:25:23 --> Database Driver Class Initialized
DEBUG - 2011-09-13 14:25:23 --> File loaded: application/views/table/main.php
DEBUG - 2011-09-13 14:25:23 --> Helper loaded: url_helper
DEBUG - 2011-09-13 14:25:23 --> File loaded: application/views/common/header.php
DEBUG - 2011-09-13 14:25:23 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-09-13 14:25:23 --> File loaded: application/views/common/footer.php
DEBUG - 2011-09-13 14:25:23 --> File loaded: application/views/layout/main.php
DEBUG - 2011-09-13 14:25:23 --> Final output sent to browser
DEBUG - 2011-09-13 14:25:23 --> Total execution time: 0.7796
DEBUG - 2011-09-13 14:25:27 --> Config Class Initialized
DEBUG - 2011-09-13 14:25:27 --> Hooks Class Initialized
DEBUG - 2011-09-13 14:25:27 --> Utf8 Class Initialized
DEBUG - 2011-09-13 14:25:27 --> UTF-8 Support Enabled
DEBUG - 2011-09-13 14:25:27 --> URI Class Initialized
DEBUG - 2011-09-13 14:25:27 --> Router Class Initialized
ERROR - 2011-09-13 14:25:27 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-09-13 14:25:31 --> Config Class Initialized
DEBUG - 2011-09-13 14:25:31 --> Hooks Class Initialized
DEBUG - 2011-09-13 14:25:31 --> Utf8 Class Initialized
DEBUG - 2011-09-13 14:25:31 --> UTF-8 Support Enabled
DEBUG - 2011-09-13 14:25:31 --> URI Class Initialized
DEBUG - 2011-09-13 14:25:31 --> Router Class Initialized
DEBUG - 2011-09-13 14:25:31 --> Output Class Initialized
DEBUG - 2011-09-13 14:25:31 --> Input Class Initialized
DEBUG - 2011-09-13 14:25:31 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-13 14:25:31 --> Language Class Initialized
DEBUG - 2011-09-13 14:25:31 --> Loader Class Initialized
DEBUG - 2011-09-13 14:25:31 --> Controller Class Initialized
DEBUG - 2011-09-13 14:25:31 --> Model Class Initialized
DEBUG - 2011-09-13 14:25:31 --> Model Class Initialized
DEBUG - 2011-09-13 14:25:31 --> Model Class Initialized
DEBUG - 2011-09-13 14:25:31 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-13 14:25:31 --> Database Driver Class Initialized
DEBUG - 2011-09-13 14:25:31 --> File loaded: application/views/table/main.php
DEBUG - 2011-09-13 14:25:31 --> Helper loaded: url_helper
DEBUG - 2011-09-13 14:25:31 --> File loaded: application/views/common/header.php
DEBUG - 2011-09-13 14:25:31 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-09-13 14:25:31 --> File loaded: application/views/common/footer.php
DEBUG - 2011-09-13 14:25:31 --> File loaded: application/views/layout/main.php
DEBUG - 2011-09-13 14:25:31 --> Final output sent to browser
DEBUG - 2011-09-13 14:25:31 --> Total execution time: 0.9631
DEBUG - 2011-09-13 14:25:34 --> Config Class Initialized
DEBUG - 2011-09-13 14:25:34 --> Hooks Class Initialized
DEBUG - 2011-09-13 14:25:34 --> Utf8 Class Initialized
DEBUG - 2011-09-13 14:25:34 --> UTF-8 Support Enabled
DEBUG - 2011-09-13 14:25:34 --> URI Class Initialized
DEBUG - 2011-09-13 14:25:34 --> Router Class Initialized
ERROR - 2011-09-13 14:25:34 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-09-13 14:25:39 --> Config Class Initialized
DEBUG - 2011-09-13 14:25:39 --> Hooks Class Initialized
DEBUG - 2011-09-13 14:25:39 --> Utf8 Class Initialized
DEBUG - 2011-09-13 14:25:39 --> UTF-8 Support Enabled
DEBUG - 2011-09-13 14:25:39 --> URI Class Initialized
DEBUG - 2011-09-13 14:25:39 --> Router Class Initialized
DEBUG - 2011-09-13 14:25:39 --> Output Class Initialized
DEBUG - 2011-09-13 14:25:39 --> Input Class Initialized
DEBUG - 2011-09-13 14:25:39 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-13 14:25:39 --> Language Class Initialized
DEBUG - 2011-09-13 14:25:39 --> Loader Class Initialized
DEBUG - 2011-09-13 14:25:39 --> Controller Class Initialized
DEBUG - 2011-09-13 14:25:39 --> Model Class Initialized
DEBUG - 2011-09-13 14:25:39 --> Model Class Initialized
DEBUG - 2011-09-13 14:25:39 --> Model Class Initialized
DEBUG - 2011-09-13 14:25:39 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-13 14:25:39 --> Database Driver Class Initialized
DEBUG - 2011-09-13 14:25:39 --> File loaded: application/views/table/main.php
DEBUG - 2011-09-13 14:25:39 --> Helper loaded: url_helper
DEBUG - 2011-09-13 14:25:39 --> File loaded: application/views/common/header.php
DEBUG - 2011-09-13 14:25:39 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-09-13 14:25:39 --> File loaded: application/views/common/footer.php
DEBUG - 2011-09-13 14:25:39 --> File loaded: application/views/layout/main.php
DEBUG - 2011-09-13 14:25:39 --> Final output sent to browser
DEBUG - 2011-09-13 14:25:39 --> Total execution time: 0.3398
DEBUG - 2011-09-13 14:25:42 --> Config Class Initialized
DEBUG - 2011-09-13 14:25:42 --> Hooks Class Initialized
DEBUG - 2011-09-13 14:25:42 --> Utf8 Class Initialized
DEBUG - 2011-09-13 14:25:42 --> UTF-8 Support Enabled
DEBUG - 2011-09-13 14:25:42 --> URI Class Initialized
DEBUG - 2011-09-13 14:25:42 --> Router Class Initialized
ERROR - 2011-09-13 14:25:42 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-09-13 14:25:54 --> Config Class Initialized
DEBUG - 2011-09-13 14:25:54 --> Hooks Class Initialized
DEBUG - 2011-09-13 14:25:54 --> Utf8 Class Initialized
DEBUG - 2011-09-13 14:25:54 --> UTF-8 Support Enabled
DEBUG - 2011-09-13 14:25:54 --> URI Class Initialized
DEBUG - 2011-09-13 14:25:54 --> Router Class Initialized
DEBUG - 2011-09-13 14:25:54 --> Output Class Initialized
DEBUG - 2011-09-13 14:25:54 --> Input Class Initialized
DEBUG - 2011-09-13 14:25:54 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-13 14:25:54 --> Language Class Initialized
DEBUG - 2011-09-13 14:25:54 --> Loader Class Initialized
DEBUG - 2011-09-13 14:25:54 --> Controller Class Initialized
DEBUG - 2011-09-13 14:25:54 --> Model Class Initialized
DEBUG - 2011-09-13 14:25:54 --> Model Class Initialized
DEBUG - 2011-09-13 14:25:54 --> Model Class Initialized
DEBUG - 2011-09-13 14:25:54 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-13 14:25:54 --> Database Driver Class Initialized
DEBUG - 2011-09-13 14:25:55 --> File loaded: application/views/table/main.php
DEBUG - 2011-09-13 14:25:55 --> Helper loaded: url_helper
DEBUG - 2011-09-13 14:25:55 --> File loaded: application/views/common/header.php
DEBUG - 2011-09-13 14:25:55 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-09-13 14:25:55 --> File loaded: application/views/common/footer.php
DEBUG - 2011-09-13 14:25:55 --> File loaded: application/views/layout/main.php
DEBUG - 2011-09-13 14:25:55 --> Final output sent to browser
DEBUG - 2011-09-13 14:25:55 --> Total execution time: 1.1056
DEBUG - 2011-09-13 14:26:02 --> Config Class Initialized
DEBUG - 2011-09-13 14:26:02 --> Hooks Class Initialized
DEBUG - 2011-09-13 14:26:02 --> Utf8 Class Initialized
DEBUG - 2011-09-13 14:26:02 --> UTF-8 Support Enabled
DEBUG - 2011-09-13 14:26:02 --> URI Class Initialized
DEBUG - 2011-09-13 14:26:02 --> Router Class Initialized
ERROR - 2011-09-13 14:26:02 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-09-13 14:26:02 --> Config Class Initialized
DEBUG - 2011-09-13 14:26:02 --> Hooks Class Initialized
DEBUG - 2011-09-13 14:26:02 --> Utf8 Class Initialized
DEBUG - 2011-09-13 14:26:02 --> UTF-8 Support Enabled
DEBUG - 2011-09-13 14:26:02 --> URI Class Initialized
DEBUG - 2011-09-13 14:26:02 --> Router Class Initialized
DEBUG - 2011-09-13 14:26:02 --> Output Class Initialized
DEBUG - 2011-09-13 14:26:02 --> Input Class Initialized
DEBUG - 2011-09-13 14:26:02 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-13 14:26:02 --> Language Class Initialized
DEBUG - 2011-09-13 14:26:02 --> Loader Class Initialized
DEBUG - 2011-09-13 14:26:02 --> Controller Class Initialized
DEBUG - 2011-09-13 14:26:02 --> Model Class Initialized
DEBUG - 2011-09-13 14:26:02 --> Model Class Initialized
DEBUG - 2011-09-13 14:26:02 --> Model Class Initialized
DEBUG - 2011-09-13 14:26:02 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-13 14:26:02 --> Database Driver Class Initialized
DEBUG - 2011-09-13 14:26:02 --> File loaded: application/views/table/main.php
DEBUG - 2011-09-13 14:26:02 --> Helper loaded: url_helper
DEBUG - 2011-09-13 14:26:02 --> File loaded: application/views/common/header.php
DEBUG - 2011-09-13 14:26:02 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-09-13 14:26:02 --> File loaded: application/views/common/footer.php
DEBUG - 2011-09-13 14:26:02 --> File loaded: application/views/layout/main.php
DEBUG - 2011-09-13 14:26:02 --> Final output sent to browser
DEBUG - 2011-09-13 14:26:02 --> Total execution time: 0.5346
DEBUG - 2011-09-13 14:26:07 --> Config Class Initialized
DEBUG - 2011-09-13 14:26:07 --> Hooks Class Initialized
DEBUG - 2011-09-13 14:26:07 --> Utf8 Class Initialized
DEBUG - 2011-09-13 14:26:07 --> UTF-8 Support Enabled
DEBUG - 2011-09-13 14:26:07 --> URI Class Initialized
DEBUG - 2011-09-13 14:26:07 --> Router Class Initialized
ERROR - 2011-09-13 14:26:07 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-09-13 14:26:14 --> Config Class Initialized
DEBUG - 2011-09-13 14:26:14 --> Hooks Class Initialized
DEBUG - 2011-09-13 14:26:14 --> Utf8 Class Initialized
DEBUG - 2011-09-13 14:26:14 --> UTF-8 Support Enabled
DEBUG - 2011-09-13 14:26:14 --> URI Class Initialized
DEBUG - 2011-09-13 14:26:14 --> Router Class Initialized
DEBUG - 2011-09-13 14:26:14 --> Output Class Initialized
DEBUG - 2011-09-13 14:26:14 --> Input Class Initialized
DEBUG - 2011-09-13 14:26:14 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-13 14:26:14 --> Language Class Initialized
DEBUG - 2011-09-13 14:26:14 --> Loader Class Initialized
DEBUG - 2011-09-13 14:26:14 --> Controller Class Initialized
DEBUG - 2011-09-13 14:26:14 --> Model Class Initialized
DEBUG - 2011-09-13 14:26:14 --> Model Class Initialized
DEBUG - 2011-09-13 14:26:14 --> Model Class Initialized
DEBUG - 2011-09-13 14:26:14 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-13 14:26:14 --> Database Driver Class Initialized
DEBUG - 2011-09-13 14:26:14 --> File loaded: application/views/table/main.php
DEBUG - 2011-09-13 14:26:14 --> Helper loaded: url_helper
DEBUG - 2011-09-13 14:26:14 --> File loaded: application/views/common/header.php
DEBUG - 2011-09-13 14:26:14 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-09-13 14:26:14 --> File loaded: application/views/common/footer.php
DEBUG - 2011-09-13 14:26:14 --> File loaded: application/views/layout/main.php
DEBUG - 2011-09-13 14:26:14 --> Final output sent to browser
DEBUG - 2011-09-13 14:26:14 --> Total execution time: 0.3383
DEBUG - 2011-09-13 14:26:17 --> Config Class Initialized
DEBUG - 2011-09-13 14:26:17 --> Hooks Class Initialized
DEBUG - 2011-09-13 14:26:17 --> Utf8 Class Initialized
DEBUG - 2011-09-13 14:26:17 --> UTF-8 Support Enabled
DEBUG - 2011-09-13 14:26:17 --> URI Class Initialized
DEBUG - 2011-09-13 14:26:17 --> Router Class Initialized
ERROR - 2011-09-13 14:26:17 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-09-13 14:26:20 --> Config Class Initialized
DEBUG - 2011-09-13 14:26:20 --> Hooks Class Initialized
DEBUG - 2011-09-13 14:26:20 --> Utf8 Class Initialized
DEBUG - 2011-09-13 14:26:20 --> UTF-8 Support Enabled
DEBUG - 2011-09-13 14:26:20 --> URI Class Initialized
DEBUG - 2011-09-13 14:26:20 --> Router Class Initialized
DEBUG - 2011-09-13 14:26:20 --> Output Class Initialized
DEBUG - 2011-09-13 14:26:20 --> Input Class Initialized
DEBUG - 2011-09-13 14:26:20 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-13 14:26:20 --> Language Class Initialized
DEBUG - 2011-09-13 14:26:20 --> Loader Class Initialized
DEBUG - 2011-09-13 14:26:20 --> Controller Class Initialized
DEBUG - 2011-09-13 14:26:20 --> Model Class Initialized
DEBUG - 2011-09-13 14:26:20 --> Model Class Initialized
DEBUG - 2011-09-13 14:26:20 --> Model Class Initialized
DEBUG - 2011-09-13 14:26:20 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-13 14:26:20 --> Database Driver Class Initialized
DEBUG - 2011-09-13 14:26:21 --> File loaded: application/views/table/main.php
DEBUG - 2011-09-13 14:26:21 --> Helper loaded: url_helper
DEBUG - 2011-09-13 14:26:21 --> File loaded: application/views/common/header.php
DEBUG - 2011-09-13 14:26:21 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-09-13 14:26:21 --> File loaded: application/views/common/footer.php
DEBUG - 2011-09-13 14:26:21 --> File loaded: application/views/layout/main.php
DEBUG - 2011-09-13 14:26:21 --> Final output sent to browser
DEBUG - 2011-09-13 14:26:21 --> Total execution time: 0.6507
DEBUG - 2011-09-13 14:26:23 --> Config Class Initialized
DEBUG - 2011-09-13 14:26:23 --> Hooks Class Initialized
DEBUG - 2011-09-13 14:26:23 --> Utf8 Class Initialized
DEBUG - 2011-09-13 14:26:23 --> UTF-8 Support Enabled
DEBUG - 2011-09-13 14:26:23 --> URI Class Initialized
DEBUG - 2011-09-13 14:26:23 --> Router Class Initialized
ERROR - 2011-09-13 14:26:23 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-09-13 14:26:31 --> Config Class Initialized
DEBUG - 2011-09-13 14:26:31 --> Hooks Class Initialized
DEBUG - 2011-09-13 14:26:31 --> Utf8 Class Initialized
DEBUG - 2011-09-13 14:26:31 --> UTF-8 Support Enabled
DEBUG - 2011-09-13 14:26:31 --> URI Class Initialized
DEBUG - 2011-09-13 14:26:31 --> Router Class Initialized
DEBUG - 2011-09-13 14:26:31 --> Output Class Initialized
DEBUG - 2011-09-13 14:26:31 --> Input Class Initialized
DEBUG - 2011-09-13 14:26:31 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-13 14:26:31 --> Language Class Initialized
DEBUG - 2011-09-13 14:26:31 --> Loader Class Initialized
DEBUG - 2011-09-13 14:26:31 --> Controller Class Initialized
DEBUG - 2011-09-13 14:26:31 --> Model Class Initialized
DEBUG - 2011-09-13 14:26:31 --> Model Class Initialized
DEBUG - 2011-09-13 14:26:31 --> Model Class Initialized
DEBUG - 2011-09-13 14:26:31 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-13 14:26:31 --> Database Driver Class Initialized
DEBUG - 2011-09-13 14:26:32 --> File loaded: application/views/table/main.php
DEBUG - 2011-09-13 14:26:32 --> Helper loaded: url_helper
DEBUG - 2011-09-13 14:26:32 --> File loaded: application/views/common/header.php
DEBUG - 2011-09-13 14:26:32 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-09-13 14:26:32 --> File loaded: application/views/common/footer.php
DEBUG - 2011-09-13 14:26:32 --> File loaded: application/views/layout/main.php
DEBUG - 2011-09-13 14:26:32 --> Final output sent to browser
DEBUG - 2011-09-13 14:26:32 --> Total execution time: 0.4992
DEBUG - 2011-09-13 14:26:34 --> Config Class Initialized
DEBUG - 2011-09-13 14:26:34 --> Hooks Class Initialized
DEBUG - 2011-09-13 14:26:34 --> Utf8 Class Initialized
DEBUG - 2011-09-13 14:26:34 --> UTF-8 Support Enabled
DEBUG - 2011-09-13 14:26:34 --> URI Class Initialized
DEBUG - 2011-09-13 14:26:34 --> Router Class Initialized
ERROR - 2011-09-13 14:26:34 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-09-13 14:26:46 --> Config Class Initialized
DEBUG - 2011-09-13 14:26:46 --> Hooks Class Initialized
DEBUG - 2011-09-13 14:26:46 --> Utf8 Class Initialized
DEBUG - 2011-09-13 14:26:46 --> UTF-8 Support Enabled
DEBUG - 2011-09-13 14:26:46 --> URI Class Initialized
DEBUG - 2011-09-13 14:26:46 --> Router Class Initialized
DEBUG - 2011-09-13 14:26:46 --> Output Class Initialized
DEBUG - 2011-09-13 14:26:46 --> Input Class Initialized
DEBUG - 2011-09-13 14:26:46 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-13 14:26:46 --> Language Class Initialized
DEBUG - 2011-09-13 14:26:46 --> Loader Class Initialized
DEBUG - 2011-09-13 14:26:46 --> Controller Class Initialized
ERROR - 2011-09-13 14:26:46 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-09-13 14:26:46 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-09-13 14:26:46 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-09-13 14:26:46 --> Model Class Initialized
DEBUG - 2011-09-13 14:26:46 --> Model Class Initialized
DEBUG - 2011-09-13 14:26:46 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-13 14:26:46 --> Database Driver Class Initialized
DEBUG - 2011-09-13 14:26:46 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-09-13 14:26:46 --> Helper loaded: url_helper
DEBUG - 2011-09-13 14:26:46 --> File loaded: application/views/common/header.php
DEBUG - 2011-09-13 14:26:46 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-09-13 14:26:46 --> File loaded: application/views/common/footer.php
DEBUG - 2011-09-13 14:26:46 --> File loaded: application/views/layout/main.php
DEBUG - 2011-09-13 14:26:46 --> Final output sent to browser
DEBUG - 2011-09-13 14:26:46 --> Total execution time: 0.0422
DEBUG - 2011-09-13 14:26:48 --> Config Class Initialized
DEBUG - 2011-09-13 14:26:48 --> Hooks Class Initialized
DEBUG - 2011-09-13 14:26:48 --> Utf8 Class Initialized
DEBUG - 2011-09-13 14:26:48 --> UTF-8 Support Enabled
DEBUG - 2011-09-13 14:26:48 --> URI Class Initialized
DEBUG - 2011-09-13 14:26:48 --> Router Class Initialized
DEBUG - 2011-09-13 14:26:48 --> Output Class Initialized
DEBUG - 2011-09-13 14:26:48 --> Input Class Initialized
DEBUG - 2011-09-13 14:26:48 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-13 14:26:48 --> Language Class Initialized
DEBUG - 2011-09-13 14:26:48 --> Loader Class Initialized
DEBUG - 2011-09-13 14:26:48 --> Controller Class Initialized
DEBUG - 2011-09-13 14:26:48 --> Model Class Initialized
DEBUG - 2011-09-13 14:26:48 --> Model Class Initialized
DEBUG - 2011-09-13 14:26:48 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-13 14:26:48 --> Database Driver Class Initialized
DEBUG - 2011-09-13 14:26:49 --> Final output sent to browser
DEBUG - 2011-09-13 14:26:49 --> Total execution time: 0.6039
DEBUG - 2011-09-13 14:26:50 --> Config Class Initialized
DEBUG - 2011-09-13 14:26:50 --> Hooks Class Initialized
DEBUG - 2011-09-13 14:26:50 --> Utf8 Class Initialized
DEBUG - 2011-09-13 14:26:50 --> UTF-8 Support Enabled
DEBUG - 2011-09-13 14:26:50 --> URI Class Initialized
DEBUG - 2011-09-13 14:26:50 --> Router Class Initialized
ERROR - 2011-09-13 14:26:50 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-09-13 14:31:01 --> Config Class Initialized
DEBUG - 2011-09-13 14:31:01 --> Hooks Class Initialized
DEBUG - 2011-09-13 14:31:01 --> Utf8 Class Initialized
DEBUG - 2011-09-13 14:31:01 --> UTF-8 Support Enabled
DEBUG - 2011-09-13 14:31:01 --> URI Class Initialized
DEBUG - 2011-09-13 14:31:01 --> Router Class Initialized
ERROR - 2011-09-13 14:31:01 --> 404 Page Not Found --> robots.txt
DEBUG - 2011-09-13 14:31:02 --> Config Class Initialized
DEBUG - 2011-09-13 14:31:02 --> Hooks Class Initialized
DEBUG - 2011-09-13 14:31:02 --> Utf8 Class Initialized
DEBUG - 2011-09-13 14:31:02 --> UTF-8 Support Enabled
DEBUG - 2011-09-13 14:31:02 --> URI Class Initialized
DEBUG - 2011-09-13 14:31:02 --> Router Class Initialized
DEBUG - 2011-09-13 14:31:02 --> Output Class Initialized
DEBUG - 2011-09-13 14:31:02 --> Input Class Initialized
DEBUG - 2011-09-13 14:31:02 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-13 14:31:02 --> Language Class Initialized
DEBUG - 2011-09-13 14:31:02 --> Loader Class Initialized
DEBUG - 2011-09-13 14:31:02 --> Controller Class Initialized
ERROR - 2011-09-13 14:31:02 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-09-13 14:31:02 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-09-13 14:31:02 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-09-13 14:31:02 --> Model Class Initialized
DEBUG - 2011-09-13 14:31:02 --> Model Class Initialized
DEBUG - 2011-09-13 14:31:02 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-13 14:31:02 --> Database Driver Class Initialized
DEBUG - 2011-09-13 14:31:02 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-09-13 14:31:02 --> Helper loaded: url_helper
DEBUG - 2011-09-13 14:31:02 --> File loaded: application/views/common/header.php
DEBUG - 2011-09-13 14:31:02 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-09-13 14:31:02 --> File loaded: application/views/common/footer.php
DEBUG - 2011-09-13 14:31:02 --> File loaded: application/views/layout/main.php
DEBUG - 2011-09-13 14:31:02 --> Final output sent to browser
DEBUG - 2011-09-13 14:31:02 --> Total execution time: 0.1572
DEBUG - 2011-09-13 14:40:40 --> Config Class Initialized
DEBUG - 2011-09-13 14:40:40 --> Hooks Class Initialized
DEBUG - 2011-09-13 14:40:40 --> Utf8 Class Initialized
DEBUG - 2011-09-13 14:40:40 --> UTF-8 Support Enabled
DEBUG - 2011-09-13 14:40:40 --> URI Class Initialized
DEBUG - 2011-09-13 14:40:40 --> Router Class Initialized
ERROR - 2011-09-13 14:40:40 --> 404 Page Not Found --> robots.txt
DEBUG - 2011-09-13 14:40:40 --> Config Class Initialized
DEBUG - 2011-09-13 14:40:40 --> Hooks Class Initialized
DEBUG - 2011-09-13 14:40:40 --> Utf8 Class Initialized
DEBUG - 2011-09-13 14:40:40 --> UTF-8 Support Enabled
DEBUG - 2011-09-13 14:40:40 --> URI Class Initialized
DEBUG - 2011-09-13 14:40:40 --> Router Class Initialized
DEBUG - 2011-09-13 14:40:40 --> Output Class Initialized
DEBUG - 2011-09-13 14:40:40 --> Input Class Initialized
DEBUG - 2011-09-13 14:40:40 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-13 14:40:40 --> Language Class Initialized
DEBUG - 2011-09-13 14:40:40 --> Loader Class Initialized
DEBUG - 2011-09-13 14:40:40 --> Controller Class Initialized
ERROR - 2011-09-13 14:40:40 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-09-13 14:40:40 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-09-13 14:40:40 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-09-13 14:40:40 --> Model Class Initialized
DEBUG - 2011-09-13 14:40:40 --> Model Class Initialized
DEBUG - 2011-09-13 14:40:40 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-13 14:40:40 --> Database Driver Class Initialized
DEBUG - 2011-09-13 14:40:40 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-09-13 14:40:40 --> Helper loaded: url_helper
DEBUG - 2011-09-13 14:40:40 --> File loaded: application/views/common/header.php
DEBUG - 2011-09-13 14:40:40 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-09-13 14:40:40 --> File loaded: application/views/common/footer.php
DEBUG - 2011-09-13 14:40:40 --> File loaded: application/views/layout/main.php
DEBUG - 2011-09-13 14:40:40 --> Final output sent to browser
DEBUG - 2011-09-13 14:40:40 --> Total execution time: 0.1125
DEBUG - 2011-09-13 14:46:32 --> Config Class Initialized
DEBUG - 2011-09-13 14:46:32 --> Hooks Class Initialized
DEBUG - 2011-09-13 14:46:32 --> Utf8 Class Initialized
DEBUG - 2011-09-13 14:46:32 --> UTF-8 Support Enabled
DEBUG - 2011-09-13 14:46:32 --> URI Class Initialized
DEBUG - 2011-09-13 14:46:32 --> Router Class Initialized
DEBUG - 2011-09-13 14:46:32 --> Output Class Initialized
DEBUG - 2011-09-13 14:46:32 --> Input Class Initialized
DEBUG - 2011-09-13 14:46:33 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-13 14:46:33 --> Language Class Initialized
DEBUG - 2011-09-13 14:46:33 --> Loader Class Initialized
DEBUG - 2011-09-13 14:46:33 --> Controller Class Initialized
DEBUG - 2011-09-13 14:46:33 --> Model Class Initialized
DEBUG - 2011-09-13 14:46:33 --> Model Class Initialized
DEBUG - 2011-09-13 14:46:33 --> Model Class Initialized
DEBUG - 2011-09-13 14:46:33 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-13 14:46:33 --> Database Driver Class Initialized
DEBUG - 2011-09-13 14:46:33 --> File loaded: application/views/table/main.php
DEBUG - 2011-09-13 14:46:33 --> Helper loaded: url_helper
DEBUG - 2011-09-13 14:46:33 --> File loaded: application/views/common/header.php
DEBUG - 2011-09-13 14:46:33 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-09-13 14:46:33 --> File loaded: application/views/common/footer.php
DEBUG - 2011-09-13 14:46:33 --> File loaded: application/views/layout/main.php
DEBUG - 2011-09-13 14:46:33 --> Final output sent to browser
DEBUG - 2011-09-13 14:46:33 --> Total execution time: 0.3059
DEBUG - 2011-09-13 14:46:35 --> Config Class Initialized
DEBUG - 2011-09-13 14:46:35 --> Hooks Class Initialized
DEBUG - 2011-09-13 14:46:35 --> Utf8 Class Initialized
DEBUG - 2011-09-13 14:46:35 --> UTF-8 Support Enabled
DEBUG - 2011-09-13 14:46:35 --> URI Class Initialized
DEBUG - 2011-09-13 14:46:35 --> Router Class Initialized
ERROR - 2011-09-13 14:46:35 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-09-13 14:46:58 --> Config Class Initialized
DEBUG - 2011-09-13 14:46:58 --> Hooks Class Initialized
DEBUG - 2011-09-13 14:46:58 --> Utf8 Class Initialized
DEBUG - 2011-09-13 14:46:58 --> UTF-8 Support Enabled
DEBUG - 2011-09-13 14:46:58 --> URI Class Initialized
DEBUG - 2011-09-13 14:46:58 --> Router Class Initialized
DEBUG - 2011-09-13 14:46:58 --> Output Class Initialized
DEBUG - 2011-09-13 14:46:58 --> Input Class Initialized
DEBUG - 2011-09-13 14:46:58 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-13 14:46:58 --> Language Class Initialized
DEBUG - 2011-09-13 14:46:58 --> Loader Class Initialized
DEBUG - 2011-09-13 14:46:58 --> Controller Class Initialized
DEBUG - 2011-09-13 14:46:58 --> Model Class Initialized
DEBUG - 2011-09-13 14:46:58 --> Model Class Initialized
DEBUG - 2011-09-13 14:46:58 --> Model Class Initialized
DEBUG - 2011-09-13 14:46:58 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-13 14:46:58 --> Database Driver Class Initialized
DEBUG - 2011-09-13 14:46:58 --> File loaded: application/views/table/main.php
DEBUG - 2011-09-13 14:46:58 --> Helper loaded: url_helper
DEBUG - 2011-09-13 14:46:58 --> File loaded: application/views/common/header.php
DEBUG - 2011-09-13 14:46:58 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-09-13 14:46:58 --> File loaded: application/views/common/footer.php
DEBUG - 2011-09-13 14:46:58 --> File loaded: application/views/layout/main.php
DEBUG - 2011-09-13 14:46:58 --> Final output sent to browser
DEBUG - 2011-09-13 14:46:58 --> Total execution time: 0.4503
DEBUG - 2011-09-13 14:47:34 --> Config Class Initialized
DEBUG - 2011-09-13 14:47:34 --> Hooks Class Initialized
DEBUG - 2011-09-13 14:47:34 --> Utf8 Class Initialized
DEBUG - 2011-09-13 14:47:34 --> UTF-8 Support Enabled
DEBUG - 2011-09-13 14:47:34 --> URI Class Initialized
DEBUG - 2011-09-13 14:47:34 --> Router Class Initialized
DEBUG - 2011-09-13 14:47:34 --> Output Class Initialized
DEBUG - 2011-09-13 14:47:34 --> Input Class Initialized
DEBUG - 2011-09-13 14:47:34 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-13 14:47:34 --> Language Class Initialized
DEBUG - 2011-09-13 14:47:34 --> Loader Class Initialized
DEBUG - 2011-09-13 14:47:34 --> Controller Class Initialized
ERROR - 2011-09-13 14:47:34 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-09-13 14:47:34 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-09-13 14:47:34 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-09-13 14:47:34 --> Model Class Initialized
DEBUG - 2011-09-13 14:47:34 --> Model Class Initialized
DEBUG - 2011-09-13 14:47:34 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-13 14:47:34 --> Database Driver Class Initialized
DEBUG - 2011-09-13 14:47:34 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-09-13 14:47:34 --> Helper loaded: url_helper
DEBUG - 2011-09-13 14:47:34 --> File loaded: application/views/common/header.php
DEBUG - 2011-09-13 14:47:34 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-09-13 14:47:34 --> File loaded: application/views/common/footer.php
DEBUG - 2011-09-13 14:47:34 --> File loaded: application/views/layout/main.php
DEBUG - 2011-09-13 14:47:34 --> Final output sent to browser
DEBUG - 2011-09-13 14:47:34 --> Total execution time: 0.0542
DEBUG - 2011-09-13 14:47:35 --> Config Class Initialized
DEBUG - 2011-09-13 14:47:35 --> Hooks Class Initialized
DEBUG - 2011-09-13 14:47:35 --> Utf8 Class Initialized
DEBUG - 2011-09-13 14:47:35 --> UTF-8 Support Enabled
DEBUG - 2011-09-13 14:47:35 --> URI Class Initialized
DEBUG - 2011-09-13 14:47:35 --> Router Class Initialized
DEBUG - 2011-09-13 14:47:35 --> Output Class Initialized
DEBUG - 2011-09-13 14:47:35 --> Input Class Initialized
DEBUG - 2011-09-13 14:47:35 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-13 14:47:35 --> Language Class Initialized
DEBUG - 2011-09-13 14:47:35 --> Loader Class Initialized
DEBUG - 2011-09-13 14:47:35 --> Controller Class Initialized
DEBUG - 2011-09-13 14:47:35 --> Model Class Initialized
DEBUG - 2011-09-13 14:47:35 --> Model Class Initialized
DEBUG - 2011-09-13 14:47:35 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-13 14:47:35 --> Database Driver Class Initialized
DEBUG - 2011-09-13 14:47:36 --> Final output sent to browser
DEBUG - 2011-09-13 14:47:36 --> Total execution time: 0.6924
DEBUG - 2011-09-13 14:47:37 --> Config Class Initialized
DEBUG - 2011-09-13 14:47:37 --> Hooks Class Initialized
DEBUG - 2011-09-13 14:47:37 --> Utf8 Class Initialized
DEBUG - 2011-09-13 14:47:37 --> UTF-8 Support Enabled
DEBUG - 2011-09-13 14:47:37 --> URI Class Initialized
DEBUG - 2011-09-13 14:47:37 --> Router Class Initialized
ERROR - 2011-09-13 14:47:37 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-09-13 14:47:55 --> Config Class Initialized
DEBUG - 2011-09-13 14:47:55 --> Hooks Class Initialized
DEBUG - 2011-09-13 14:47:55 --> Utf8 Class Initialized
DEBUG - 2011-09-13 14:47:55 --> UTF-8 Support Enabled
DEBUG - 2011-09-13 14:47:55 --> URI Class Initialized
DEBUG - 2011-09-13 14:47:55 --> Router Class Initialized
DEBUG - 2011-09-13 14:47:55 --> Output Class Initialized
DEBUG - 2011-09-13 14:47:55 --> Input Class Initialized
DEBUG - 2011-09-13 14:47:55 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-13 14:47:55 --> Language Class Initialized
DEBUG - 2011-09-13 14:47:55 --> Loader Class Initialized
DEBUG - 2011-09-13 14:47:55 --> Controller Class Initialized
ERROR - 2011-09-13 14:47:55 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-09-13 14:47:55 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-09-13 14:47:55 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-09-13 14:47:55 --> Model Class Initialized
DEBUG - 2011-09-13 14:47:55 --> Model Class Initialized
DEBUG - 2011-09-13 14:47:55 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-13 14:47:55 --> Database Driver Class Initialized
DEBUG - 2011-09-13 14:47:55 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-09-13 14:47:55 --> Helper loaded: url_helper
DEBUG - 2011-09-13 14:47:55 --> File loaded: application/views/common/header.php
DEBUG - 2011-09-13 14:47:55 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-09-13 14:47:55 --> File loaded: application/views/common/footer.php
DEBUG - 2011-09-13 14:47:55 --> File loaded: application/views/layout/main.php
DEBUG - 2011-09-13 14:47:55 --> Final output sent to browser
DEBUG - 2011-09-13 14:47:55 --> Total execution time: 0.0277
DEBUG - 2011-09-13 14:47:55 --> Config Class Initialized
DEBUG - 2011-09-13 14:47:55 --> Hooks Class Initialized
DEBUG - 2011-09-13 14:47:55 --> Utf8 Class Initialized
DEBUG - 2011-09-13 14:47:55 --> UTF-8 Support Enabled
DEBUG - 2011-09-13 14:47:55 --> URI Class Initialized
DEBUG - 2011-09-13 14:47:55 --> Router Class Initialized
DEBUG - 2011-09-13 14:47:55 --> Output Class Initialized
DEBUG - 2011-09-13 14:47:55 --> Input Class Initialized
DEBUG - 2011-09-13 14:47:55 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-13 14:47:55 --> Language Class Initialized
DEBUG - 2011-09-13 14:47:55 --> Loader Class Initialized
DEBUG - 2011-09-13 14:47:55 --> Controller Class Initialized
DEBUG - 2011-09-13 14:47:55 --> Model Class Initialized
DEBUG - 2011-09-13 14:47:55 --> Model Class Initialized
DEBUG - 2011-09-13 14:47:55 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-13 14:47:55 --> Database Driver Class Initialized
DEBUG - 2011-09-13 14:47:56 --> Final output sent to browser
DEBUG - 2011-09-13 14:47:56 --> Total execution time: 1.2611
DEBUG - 2011-09-13 14:47:58 --> Config Class Initialized
DEBUG - 2011-09-13 14:47:58 --> Hooks Class Initialized
DEBUG - 2011-09-13 14:47:58 --> Utf8 Class Initialized
DEBUG - 2011-09-13 14:47:58 --> UTF-8 Support Enabled
DEBUG - 2011-09-13 14:47:58 --> URI Class Initialized
DEBUG - 2011-09-13 14:47:58 --> Router Class Initialized
ERROR - 2011-09-13 14:47:58 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-09-13 14:51:06 --> Config Class Initialized
DEBUG - 2011-09-13 14:51:06 --> Hooks Class Initialized
DEBUG - 2011-09-13 14:51:06 --> Utf8 Class Initialized
DEBUG - 2011-09-13 14:51:06 --> UTF-8 Support Enabled
DEBUG - 2011-09-13 14:51:06 --> URI Class Initialized
DEBUG - 2011-09-13 14:51:06 --> Router Class Initialized
DEBUG - 2011-09-13 14:51:06 --> Output Class Initialized
DEBUG - 2011-09-13 14:51:06 --> Input Class Initialized
DEBUG - 2011-09-13 14:51:06 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-13 14:51:06 --> Language Class Initialized
DEBUG - 2011-09-13 14:51:06 --> Loader Class Initialized
DEBUG - 2011-09-13 14:51:06 --> Controller Class Initialized
DEBUG - 2011-09-13 14:51:06 --> Model Class Initialized
DEBUG - 2011-09-13 14:51:06 --> Model Class Initialized
DEBUG - 2011-09-13 14:51:06 --> Model Class Initialized
DEBUG - 2011-09-13 14:51:06 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-13 14:51:06 --> Database Driver Class Initialized
DEBUG - 2011-09-13 14:51:06 --> File loaded: application/views/table/main.php
DEBUG - 2011-09-13 14:51:06 --> Helper loaded: url_helper
DEBUG - 2011-09-13 14:51:06 --> File loaded: application/views/common/header.php
DEBUG - 2011-09-13 14:51:06 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-09-13 14:51:06 --> File loaded: application/views/common/footer.php
DEBUG - 2011-09-13 14:51:06 --> File loaded: application/views/layout/main.php
DEBUG - 2011-09-13 14:51:06 --> Final output sent to browser
DEBUG - 2011-09-13 14:51:06 --> Total execution time: 0.0527
DEBUG - 2011-09-13 14:51:11 --> Config Class Initialized
DEBUG - 2011-09-13 14:51:11 --> Hooks Class Initialized
DEBUG - 2011-09-13 14:51:11 --> Utf8 Class Initialized
DEBUG - 2011-09-13 14:51:11 --> UTF-8 Support Enabled
DEBUG - 2011-09-13 14:51:11 --> URI Class Initialized
DEBUG - 2011-09-13 14:51:11 --> Router Class Initialized
ERROR - 2011-09-13 14:51:11 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-09-13 14:51:11 --> Config Class Initialized
DEBUG - 2011-09-13 14:51:11 --> Hooks Class Initialized
DEBUG - 2011-09-13 14:51:11 --> Utf8 Class Initialized
DEBUG - 2011-09-13 14:51:11 --> UTF-8 Support Enabled
DEBUG - 2011-09-13 14:51:11 --> URI Class Initialized
DEBUG - 2011-09-13 14:51:11 --> Router Class Initialized
ERROR - 2011-09-13 14:51:11 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-09-13 14:59:05 --> Config Class Initialized
DEBUG - 2011-09-13 14:59:05 --> Hooks Class Initialized
DEBUG - 2011-09-13 14:59:05 --> Utf8 Class Initialized
DEBUG - 2011-09-13 14:59:05 --> UTF-8 Support Enabled
DEBUG - 2011-09-13 14:59:05 --> URI Class Initialized
DEBUG - 2011-09-13 14:59:05 --> Router Class Initialized
DEBUG - 2011-09-13 14:59:05 --> Output Class Initialized
DEBUG - 2011-09-13 14:59:05 --> Input Class Initialized
DEBUG - 2011-09-13 14:59:05 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-13 14:59:05 --> Language Class Initialized
DEBUG - 2011-09-13 14:59:05 --> Loader Class Initialized
DEBUG - 2011-09-13 14:59:05 --> Controller Class Initialized
DEBUG - 2011-09-13 14:59:05 --> Model Class Initialized
DEBUG - 2011-09-13 14:59:05 --> Model Class Initialized
DEBUG - 2011-09-13 14:59:05 --> Model Class Initialized
DEBUG - 2011-09-13 14:59:05 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-13 14:59:05 --> Database Driver Class Initialized
DEBUG - 2011-09-13 14:59:05 --> File loaded: application/views/table/main.php
DEBUG - 2011-09-13 14:59:05 --> Helper loaded: url_helper
DEBUG - 2011-09-13 14:59:05 --> File loaded: application/views/common/header.php
DEBUG - 2011-09-13 14:59:05 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-09-13 14:59:05 --> File loaded: application/views/common/footer.php
DEBUG - 2011-09-13 14:59:05 --> File loaded: application/views/layout/main.php
DEBUG - 2011-09-13 14:59:05 --> Final output sent to browser
DEBUG - 2011-09-13 14:59:05 --> Total execution time: 0.0481
DEBUG - 2011-09-13 14:59:08 --> Config Class Initialized
DEBUG - 2011-09-13 14:59:08 --> Hooks Class Initialized
DEBUG - 2011-09-13 14:59:08 --> Utf8 Class Initialized
DEBUG - 2011-09-13 14:59:08 --> UTF-8 Support Enabled
DEBUG - 2011-09-13 14:59:08 --> URI Class Initialized
DEBUG - 2011-09-13 14:59:08 --> Router Class Initialized
ERROR - 2011-09-13 14:59:08 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-09-13 14:59:08 --> Config Class Initialized
DEBUG - 2011-09-13 14:59:08 --> Hooks Class Initialized
DEBUG - 2011-09-13 14:59:08 --> Utf8 Class Initialized
DEBUG - 2011-09-13 14:59:08 --> UTF-8 Support Enabled
DEBUG - 2011-09-13 14:59:08 --> URI Class Initialized
DEBUG - 2011-09-13 14:59:08 --> Router Class Initialized
ERROR - 2011-09-13 14:59:08 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-09-13 14:59:29 --> Config Class Initialized
DEBUG - 2011-09-13 14:59:29 --> Hooks Class Initialized
DEBUG - 2011-09-13 14:59:29 --> Utf8 Class Initialized
DEBUG - 2011-09-13 14:59:29 --> UTF-8 Support Enabled
DEBUG - 2011-09-13 14:59:29 --> URI Class Initialized
DEBUG - 2011-09-13 14:59:29 --> Router Class Initialized
DEBUG - 2011-09-13 14:59:29 --> Output Class Initialized
DEBUG - 2011-09-13 14:59:29 --> Input Class Initialized
DEBUG - 2011-09-13 14:59:29 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-13 14:59:29 --> Language Class Initialized
DEBUG - 2011-09-13 14:59:29 --> Loader Class Initialized
DEBUG - 2011-09-13 14:59:29 --> Controller Class Initialized
DEBUG - 2011-09-13 14:59:29 --> Model Class Initialized
DEBUG - 2011-09-13 14:59:29 --> Model Class Initialized
DEBUG - 2011-09-13 14:59:29 --> Model Class Initialized
DEBUG - 2011-09-13 14:59:29 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-13 14:59:29 --> Database Driver Class Initialized
DEBUG - 2011-09-13 14:59:29 --> File loaded: application/views/table/main.php
DEBUG - 2011-09-13 14:59:29 --> Helper loaded: url_helper
DEBUG - 2011-09-13 14:59:29 --> File loaded: application/views/common/header.php
DEBUG - 2011-09-13 14:59:29 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-09-13 14:59:29 --> File loaded: application/views/common/footer.php
DEBUG - 2011-09-13 14:59:29 --> File loaded: application/views/layout/main.php
DEBUG - 2011-09-13 14:59:29 --> Final output sent to browser
DEBUG - 2011-09-13 14:59:29 --> Total execution time: 0.2485
DEBUG - 2011-09-13 14:59:41 --> Config Class Initialized
DEBUG - 2011-09-13 14:59:41 --> Hooks Class Initialized
DEBUG - 2011-09-13 14:59:41 --> Utf8 Class Initialized
DEBUG - 2011-09-13 14:59:41 --> UTF-8 Support Enabled
DEBUG - 2011-09-13 14:59:41 --> URI Class Initialized
DEBUG - 2011-09-13 14:59:41 --> Router Class Initialized
DEBUG - 2011-09-13 14:59:41 --> Output Class Initialized
DEBUG - 2011-09-13 14:59:41 --> Input Class Initialized
DEBUG - 2011-09-13 14:59:41 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-13 14:59:41 --> Language Class Initialized
DEBUG - 2011-09-13 14:59:41 --> Loader Class Initialized
DEBUG - 2011-09-13 14:59:41 --> Controller Class Initialized
DEBUG - 2011-09-13 14:59:41 --> Model Class Initialized
DEBUG - 2011-09-13 14:59:41 --> Model Class Initialized
DEBUG - 2011-09-13 14:59:41 --> Model Class Initialized
DEBUG - 2011-09-13 14:59:41 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-13 14:59:41 --> Database Driver Class Initialized
DEBUG - 2011-09-13 14:59:42 --> File loaded: application/views/table/main.php
DEBUG - 2011-09-13 14:59:42 --> Helper loaded: url_helper
DEBUG - 2011-09-13 14:59:42 --> File loaded: application/views/common/header.php
DEBUG - 2011-09-13 14:59:42 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-09-13 14:59:42 --> File loaded: application/views/common/footer.php
DEBUG - 2011-09-13 14:59:42 --> File loaded: application/views/layout/main.php
DEBUG - 2011-09-13 14:59:42 --> Final output sent to browser
DEBUG - 2011-09-13 14:59:42 --> Total execution time: 0.3640
DEBUG - 2011-09-13 14:59:53 --> Config Class Initialized
DEBUG - 2011-09-13 14:59:53 --> Hooks Class Initialized
DEBUG - 2011-09-13 14:59:53 --> Utf8 Class Initialized
DEBUG - 2011-09-13 14:59:53 --> UTF-8 Support Enabled
DEBUG - 2011-09-13 14:59:53 --> URI Class Initialized
DEBUG - 2011-09-13 14:59:53 --> Router Class Initialized
DEBUG - 2011-09-13 14:59:53 --> Output Class Initialized
DEBUG - 2011-09-13 14:59:53 --> Input Class Initialized
DEBUG - 2011-09-13 14:59:53 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-13 14:59:53 --> Language Class Initialized
DEBUG - 2011-09-13 14:59:53 --> Loader Class Initialized
DEBUG - 2011-09-13 14:59:53 --> Controller Class Initialized
DEBUG - 2011-09-13 14:59:53 --> Model Class Initialized
DEBUG - 2011-09-13 14:59:53 --> Model Class Initialized
DEBUG - 2011-09-13 14:59:53 --> Model Class Initialized
DEBUG - 2011-09-13 14:59:53 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-13 14:59:53 --> Database Driver Class Initialized
DEBUG - 2011-09-13 14:59:54 --> File loaded: application/views/table/main.php
DEBUG - 2011-09-13 14:59:54 --> Helper loaded: url_helper
DEBUG - 2011-09-13 14:59:54 --> File loaded: application/views/common/header.php
DEBUG - 2011-09-13 14:59:54 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-09-13 14:59:54 --> File loaded: application/views/common/footer.php
DEBUG - 2011-09-13 14:59:54 --> File loaded: application/views/layout/main.php
DEBUG - 2011-09-13 14:59:54 --> Final output sent to browser
DEBUG - 2011-09-13 14:59:54 --> Total execution time: 0.8327
DEBUG - 2011-09-13 14:59:58 --> Config Class Initialized
DEBUG - 2011-09-13 14:59:58 --> Hooks Class Initialized
DEBUG - 2011-09-13 14:59:58 --> Utf8 Class Initialized
DEBUG - 2011-09-13 14:59:58 --> UTF-8 Support Enabled
DEBUG - 2011-09-13 14:59:58 --> URI Class Initialized
DEBUG - 2011-09-13 14:59:58 --> Router Class Initialized
DEBUG - 2011-09-13 14:59:58 --> Output Class Initialized
DEBUG - 2011-09-13 14:59:58 --> Input Class Initialized
DEBUG - 2011-09-13 14:59:58 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-13 14:59:58 --> Language Class Initialized
DEBUG - 2011-09-13 14:59:58 --> Loader Class Initialized
DEBUG - 2011-09-13 14:59:58 --> Controller Class Initialized
DEBUG - 2011-09-13 14:59:58 --> Model Class Initialized
DEBUG - 2011-09-13 14:59:58 --> Model Class Initialized
DEBUG - 2011-09-13 14:59:58 --> Model Class Initialized
DEBUG - 2011-09-13 14:59:58 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-13 14:59:58 --> Database Driver Class Initialized
DEBUG - 2011-09-13 14:59:59 --> File loaded: application/views/table/main.php
DEBUG - 2011-09-13 14:59:59 --> Helper loaded: url_helper
DEBUG - 2011-09-13 14:59:59 --> File loaded: application/views/common/header.php
DEBUG - 2011-09-13 14:59:59 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-09-13 14:59:59 --> File loaded: application/views/common/footer.php
DEBUG - 2011-09-13 14:59:59 --> File loaded: application/views/layout/main.php
DEBUG - 2011-09-13 14:59:59 --> Final output sent to browser
DEBUG - 2011-09-13 14:59:59 --> Total execution time: 0.2955
DEBUG - 2011-09-13 14:59:59 --> Config Class Initialized
DEBUG - 2011-09-13 14:59:59 --> Hooks Class Initialized
DEBUG - 2011-09-13 14:59:59 --> Utf8 Class Initialized
DEBUG - 2011-09-13 14:59:59 --> UTF-8 Support Enabled
DEBUG - 2011-09-13 14:59:59 --> URI Class Initialized
DEBUG - 2011-09-13 14:59:59 --> Router Class Initialized
DEBUG - 2011-09-13 14:59:59 --> Output Class Initialized
DEBUG - 2011-09-13 14:59:59 --> Input Class Initialized
DEBUG - 2011-09-13 14:59:59 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-13 14:59:59 --> Language Class Initialized
DEBUG - 2011-09-13 14:59:59 --> Loader Class Initialized
DEBUG - 2011-09-13 14:59:59 --> Controller Class Initialized
DEBUG - 2011-09-13 14:59:59 --> Model Class Initialized
DEBUG - 2011-09-13 14:59:59 --> Model Class Initialized
DEBUG - 2011-09-13 14:59:59 --> Model Class Initialized
DEBUG - 2011-09-13 14:59:59 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-13 14:59:59 --> Database Driver Class Initialized
DEBUG - 2011-09-13 14:59:59 --> File loaded: application/views/table/main.php
DEBUG - 2011-09-13 14:59:59 --> Helper loaded: url_helper
DEBUG - 2011-09-13 14:59:59 --> File loaded: application/views/common/header.php
DEBUG - 2011-09-13 14:59:59 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-09-13 14:59:59 --> File loaded: application/views/common/footer.php
DEBUG - 2011-09-13 14:59:59 --> File loaded: application/views/layout/main.php
DEBUG - 2011-09-13 14:59:59 --> Final output sent to browser
DEBUG - 2011-09-13 14:59:59 --> Total execution time: 0.0449
DEBUG - 2011-09-13 15:00:02 --> Config Class Initialized
DEBUG - 2011-09-13 15:00:02 --> Hooks Class Initialized
DEBUG - 2011-09-13 15:00:02 --> Utf8 Class Initialized
DEBUG - 2011-09-13 15:00:02 --> UTF-8 Support Enabled
DEBUG - 2011-09-13 15:00:02 --> URI Class Initialized
DEBUG - 2011-09-13 15:00:02 --> Router Class Initialized
DEBUG - 2011-09-13 15:00:02 --> Output Class Initialized
DEBUG - 2011-09-13 15:00:02 --> Input Class Initialized
DEBUG - 2011-09-13 15:00:02 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-13 15:00:02 --> Language Class Initialized
DEBUG - 2011-09-13 15:00:02 --> Loader Class Initialized
DEBUG - 2011-09-13 15:00:02 --> Controller Class Initialized
DEBUG - 2011-09-13 15:00:02 --> Model Class Initialized
DEBUG - 2011-09-13 15:00:02 --> Model Class Initialized
DEBUG - 2011-09-13 15:00:02 --> Model Class Initialized
DEBUG - 2011-09-13 15:00:02 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-13 15:00:02 --> Database Driver Class Initialized
DEBUG - 2011-09-13 15:00:04 --> File loaded: application/views/table/main.php
DEBUG - 2011-09-13 15:00:04 --> Helper loaded: url_helper
DEBUG - 2011-09-13 15:00:04 --> File loaded: application/views/common/header.php
DEBUG - 2011-09-13 15:00:04 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-09-13 15:00:04 --> File loaded: application/views/common/footer.php
DEBUG - 2011-09-13 15:00:04 --> File loaded: application/views/layout/main.php
DEBUG - 2011-09-13 15:00:04 --> Final output sent to browser
DEBUG - 2011-09-13 15:00:04 --> Total execution time: 2.1464
DEBUG - 2011-09-13 15:00:08 --> Config Class Initialized
DEBUG - 2011-09-13 15:00:08 --> Hooks Class Initialized
DEBUG - 2011-09-13 15:00:08 --> Utf8 Class Initialized
DEBUG - 2011-09-13 15:00:08 --> UTF-8 Support Enabled
DEBUG - 2011-09-13 15:00:08 --> URI Class Initialized
DEBUG - 2011-09-13 15:00:08 --> Router Class Initialized
DEBUG - 2011-09-13 15:00:08 --> Output Class Initialized
DEBUG - 2011-09-13 15:00:08 --> Input Class Initialized
DEBUG - 2011-09-13 15:00:08 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-13 15:00:08 --> Language Class Initialized
DEBUG - 2011-09-13 15:00:08 --> Loader Class Initialized
DEBUG - 2011-09-13 15:00:08 --> Controller Class Initialized
DEBUG - 2011-09-13 15:00:08 --> Model Class Initialized
DEBUG - 2011-09-13 15:00:08 --> Model Class Initialized
DEBUG - 2011-09-13 15:00:08 --> Model Class Initialized
DEBUG - 2011-09-13 15:00:08 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-13 15:00:08 --> Database Driver Class Initialized
DEBUG - 2011-09-13 15:00:08 --> File loaded: application/views/table/main.php
DEBUG - 2011-09-13 15:00:08 --> Helper loaded: url_helper
DEBUG - 2011-09-13 15:00:09 --> File loaded: application/views/common/header.php
DEBUG - 2011-09-13 15:00:09 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-09-13 15:00:09 --> File loaded: application/views/common/footer.php
DEBUG - 2011-09-13 15:00:09 --> File loaded: application/views/layout/main.php
DEBUG - 2011-09-13 15:00:09 --> Final output sent to browser
DEBUG - 2011-09-13 15:00:09 --> Total execution time: 0.8378
DEBUG - 2011-09-13 15:04:42 --> Config Class Initialized
DEBUG - 2011-09-13 15:04:42 --> Hooks Class Initialized
DEBUG - 2011-09-13 15:04:42 --> Utf8 Class Initialized
DEBUG - 2011-09-13 15:04:42 --> UTF-8 Support Enabled
DEBUG - 2011-09-13 15:04:42 --> URI Class Initialized
DEBUG - 2011-09-13 15:04:42 --> Router Class Initialized
DEBUG - 2011-09-13 15:04:42 --> Output Class Initialized
DEBUG - 2011-09-13 15:04:42 --> Input Class Initialized
DEBUG - 2011-09-13 15:04:42 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-13 15:04:42 --> Language Class Initialized
DEBUG - 2011-09-13 15:04:42 --> Loader Class Initialized
DEBUG - 2011-09-13 15:04:42 --> Controller Class Initialized
DEBUG - 2011-09-13 15:04:42 --> Model Class Initialized
DEBUG - 2011-09-13 15:04:42 --> Model Class Initialized
DEBUG - 2011-09-13 15:04:42 --> Model Class Initialized
DEBUG - 2011-09-13 15:04:42 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-13 15:04:42 --> Database Driver Class Initialized
DEBUG - 2011-09-13 15:04:42 --> File loaded: application/views/table/main.php
DEBUG - 2011-09-13 15:04:42 --> Helper loaded: url_helper
DEBUG - 2011-09-13 15:04:42 --> File loaded: application/views/common/header.php
DEBUG - 2011-09-13 15:04:42 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-09-13 15:04:42 --> File loaded: application/views/common/footer.php
DEBUG - 2011-09-13 15:04:42 --> File loaded: application/views/layout/main.php
DEBUG - 2011-09-13 15:04:42 --> Final output sent to browser
DEBUG - 2011-09-13 15:04:42 --> Total execution time: 0.0498
DEBUG - 2011-09-13 15:04:45 --> Config Class Initialized
DEBUG - 2011-09-13 15:04:45 --> Hooks Class Initialized
DEBUG - 2011-09-13 15:04:45 --> Utf8 Class Initialized
DEBUG - 2011-09-13 15:04:45 --> UTF-8 Support Enabled
DEBUG - 2011-09-13 15:04:45 --> URI Class Initialized
DEBUG - 2011-09-13 15:04:45 --> Router Class Initialized
DEBUG - 2011-09-13 15:04:45 --> Output Class Initialized
DEBUG - 2011-09-13 15:04:45 --> Input Class Initialized
DEBUG - 2011-09-13 15:04:45 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-13 15:04:45 --> Language Class Initialized
DEBUG - 2011-09-13 15:04:45 --> Loader Class Initialized
DEBUG - 2011-09-13 15:04:45 --> Controller Class Initialized
DEBUG - 2011-09-13 15:04:45 --> Model Class Initialized
DEBUG - 2011-09-13 15:04:45 --> Model Class Initialized
DEBUG - 2011-09-13 15:04:45 --> Model Class Initialized
DEBUG - 2011-09-13 15:04:45 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-13 15:04:45 --> Database Driver Class Initialized
DEBUG - 2011-09-13 15:04:45 --> File loaded: application/views/table/main.php
DEBUG - 2011-09-13 15:04:45 --> Helper loaded: url_helper
DEBUG - 2011-09-13 15:04:45 --> File loaded: application/views/common/header.php
DEBUG - 2011-09-13 15:04:45 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-09-13 15:04:45 --> File loaded: application/views/common/footer.php
DEBUG - 2011-09-13 15:04:45 --> File loaded: application/views/layout/main.php
DEBUG - 2011-09-13 15:04:45 --> Final output sent to browser
DEBUG - 2011-09-13 15:04:45 --> Total execution time: 0.0515
DEBUG - 2011-09-13 15:04:49 --> Config Class Initialized
DEBUG - 2011-09-13 15:04:49 --> Hooks Class Initialized
DEBUG - 2011-09-13 15:04:49 --> Utf8 Class Initialized
DEBUG - 2011-09-13 15:04:49 --> UTF-8 Support Enabled
DEBUG - 2011-09-13 15:04:49 --> URI Class Initialized
DEBUG - 2011-09-13 15:04:49 --> Router Class Initialized
ERROR - 2011-09-13 15:04:49 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-09-13 15:06:05 --> Config Class Initialized
DEBUG - 2011-09-13 15:06:05 --> Hooks Class Initialized
DEBUG - 2011-09-13 15:06:05 --> Utf8 Class Initialized
DEBUG - 2011-09-13 15:06:05 --> UTF-8 Support Enabled
DEBUG - 2011-09-13 15:06:05 --> URI Class Initialized
DEBUG - 2011-09-13 15:06:05 --> Router Class Initialized
DEBUG - 2011-09-13 15:06:05 --> Output Class Initialized
DEBUG - 2011-09-13 15:06:05 --> Input Class Initialized
DEBUG - 2011-09-13 15:06:05 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-13 15:06:05 --> Language Class Initialized
DEBUG - 2011-09-13 15:06:05 --> Loader Class Initialized
DEBUG - 2011-09-13 15:06:05 --> Controller Class Initialized
ERROR - 2011-09-13 15:06:05 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-09-13 15:06:05 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-09-13 15:06:05 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-09-13 15:06:05 --> Model Class Initialized
DEBUG - 2011-09-13 15:06:05 --> Model Class Initialized
DEBUG - 2011-09-13 15:06:05 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-13 15:06:05 --> Database Driver Class Initialized
DEBUG - 2011-09-13 15:06:05 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-09-13 15:06:05 --> Helper loaded: url_helper
DEBUG - 2011-09-13 15:06:05 --> File loaded: application/views/common/header.php
DEBUG - 2011-09-13 15:06:05 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-09-13 15:06:05 --> File loaded: application/views/common/footer.php
DEBUG - 2011-09-13 15:06:05 --> File loaded: application/views/layout/main.php
DEBUG - 2011-09-13 15:06:05 --> Final output sent to browser
DEBUG - 2011-09-13 15:06:05 --> Total execution time: 0.0433
DEBUG - 2011-09-13 15:06:10 --> Config Class Initialized
DEBUG - 2011-09-13 15:06:10 --> Hooks Class Initialized
DEBUG - 2011-09-13 15:06:10 --> Utf8 Class Initialized
DEBUG - 2011-09-13 15:06:10 --> UTF-8 Support Enabled
DEBUG - 2011-09-13 15:06:10 --> URI Class Initialized
DEBUG - 2011-09-13 15:06:10 --> Router Class Initialized
DEBUG - 2011-09-13 15:06:10 --> Output Class Initialized
DEBUG - 2011-09-13 15:06:10 --> Input Class Initialized
DEBUG - 2011-09-13 15:06:10 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-13 15:06:10 --> Language Class Initialized
DEBUG - 2011-09-13 15:06:10 --> Loader Class Initialized
DEBUG - 2011-09-13 15:06:10 --> Controller Class Initialized
DEBUG - 2011-09-13 15:06:10 --> Model Class Initialized
DEBUG - 2011-09-13 15:06:10 --> Model Class Initialized
DEBUG - 2011-09-13 15:06:10 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-13 15:06:10 --> Database Driver Class Initialized
DEBUG - 2011-09-13 15:06:11 --> Final output sent to browser
DEBUG - 2011-09-13 15:06:11 --> Total execution time: 0.5858
DEBUG - 2011-09-13 15:06:20 --> Config Class Initialized
DEBUG - 2011-09-13 15:06:20 --> Hooks Class Initialized
DEBUG - 2011-09-13 15:06:20 --> Utf8 Class Initialized
DEBUG - 2011-09-13 15:06:20 --> UTF-8 Support Enabled
DEBUG - 2011-09-13 15:06:20 --> URI Class Initialized
DEBUG - 2011-09-13 15:06:20 --> Router Class Initialized
DEBUG - 2011-09-13 15:06:20 --> Output Class Initialized
DEBUG - 2011-09-13 15:06:20 --> Input Class Initialized
DEBUG - 2011-09-13 15:06:20 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-13 15:06:20 --> Language Class Initialized
DEBUG - 2011-09-13 15:06:20 --> Loader Class Initialized
DEBUG - 2011-09-13 15:06:20 --> Controller Class Initialized
ERROR - 2011-09-13 15:06:20 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-09-13 15:06:20 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-09-13 15:06:20 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-09-13 15:06:20 --> Model Class Initialized
DEBUG - 2011-09-13 15:06:20 --> Model Class Initialized
DEBUG - 2011-09-13 15:06:20 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-13 15:06:20 --> Database Driver Class Initialized
DEBUG - 2011-09-13 15:06:20 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-09-13 15:06:20 --> Helper loaded: url_helper
DEBUG - 2011-09-13 15:06:20 --> File loaded: application/views/common/header.php
DEBUG - 2011-09-13 15:06:20 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-09-13 15:06:20 --> File loaded: application/views/common/footer.php
DEBUG - 2011-09-13 15:06:20 --> File loaded: application/views/layout/main.php
DEBUG - 2011-09-13 15:06:20 --> Final output sent to browser
DEBUG - 2011-09-13 15:06:20 --> Total execution time: 0.0276
DEBUG - 2011-09-13 15:06:22 --> Config Class Initialized
DEBUG - 2011-09-13 15:06:22 --> Hooks Class Initialized
DEBUG - 2011-09-13 15:06:22 --> Utf8 Class Initialized
DEBUG - 2011-09-13 15:06:22 --> UTF-8 Support Enabled
DEBUG - 2011-09-13 15:06:22 --> URI Class Initialized
DEBUG - 2011-09-13 15:06:22 --> Router Class Initialized
DEBUG - 2011-09-13 15:06:22 --> Output Class Initialized
DEBUG - 2011-09-13 15:06:22 --> Input Class Initialized
DEBUG - 2011-09-13 15:06:22 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-13 15:06:22 --> Language Class Initialized
DEBUG - 2011-09-13 15:06:22 --> Loader Class Initialized
DEBUG - 2011-09-13 15:06:22 --> Controller Class Initialized
DEBUG - 2011-09-13 15:06:22 --> Model Class Initialized
DEBUG - 2011-09-13 15:06:22 --> Model Class Initialized
DEBUG - 2011-09-13 15:06:22 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-13 15:06:22 --> Database Driver Class Initialized
DEBUG - 2011-09-13 15:06:22 --> Final output sent to browser
DEBUG - 2011-09-13 15:06:22 --> Total execution time: 0.4705
DEBUG - 2011-09-13 15:06:38 --> Config Class Initialized
DEBUG - 2011-09-13 15:06:38 --> Hooks Class Initialized
DEBUG - 2011-09-13 15:06:38 --> Utf8 Class Initialized
DEBUG - 2011-09-13 15:06:38 --> UTF-8 Support Enabled
DEBUG - 2011-09-13 15:06:38 --> URI Class Initialized
DEBUG - 2011-09-13 15:06:38 --> Router Class Initialized
DEBUG - 2011-09-13 15:06:38 --> Output Class Initialized
DEBUG - 2011-09-13 15:06:38 --> Input Class Initialized
DEBUG - 2011-09-13 15:06:38 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-13 15:06:38 --> Language Class Initialized
DEBUG - 2011-09-13 15:06:38 --> Loader Class Initialized
DEBUG - 2011-09-13 15:06:38 --> Controller Class Initialized
ERROR - 2011-09-13 15:06:38 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-09-13 15:06:38 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-09-13 15:06:38 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-09-13 15:06:38 --> Model Class Initialized
DEBUG - 2011-09-13 15:06:38 --> Model Class Initialized
DEBUG - 2011-09-13 15:06:38 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-13 15:06:38 --> Database Driver Class Initialized
DEBUG - 2011-09-13 15:06:38 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-09-13 15:06:38 --> Helper loaded: url_helper
DEBUG - 2011-09-13 15:06:38 --> File loaded: application/views/common/header.php
DEBUG - 2011-09-13 15:06:38 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-09-13 15:06:38 --> File loaded: application/views/common/footer.php
DEBUG - 2011-09-13 15:06:38 --> File loaded: application/views/layout/main.php
DEBUG - 2011-09-13 15:06:38 --> Final output sent to browser
DEBUG - 2011-09-13 15:06:38 --> Total execution time: 0.0307
DEBUG - 2011-09-13 15:06:39 --> Config Class Initialized
DEBUG - 2011-09-13 15:06:39 --> Hooks Class Initialized
DEBUG - 2011-09-13 15:06:39 --> Utf8 Class Initialized
DEBUG - 2011-09-13 15:06:39 --> UTF-8 Support Enabled
DEBUG - 2011-09-13 15:06:39 --> URI Class Initialized
DEBUG - 2011-09-13 15:06:39 --> Router Class Initialized
DEBUG - 2011-09-13 15:06:39 --> Output Class Initialized
DEBUG - 2011-09-13 15:06:39 --> Input Class Initialized
DEBUG - 2011-09-13 15:06:39 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-13 15:06:39 --> Language Class Initialized
DEBUG - 2011-09-13 15:06:39 --> Loader Class Initialized
DEBUG - 2011-09-13 15:06:39 --> Controller Class Initialized
DEBUG - 2011-09-13 15:06:39 --> Model Class Initialized
DEBUG - 2011-09-13 15:06:39 --> Model Class Initialized
DEBUG - 2011-09-13 15:06:39 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-13 15:06:39 --> Database Driver Class Initialized
DEBUG - 2011-09-13 15:06:40 --> Final output sent to browser
DEBUG - 2011-09-13 15:06:40 --> Total execution time: 0.8175
DEBUG - 2011-09-13 15:27:37 --> Config Class Initialized
DEBUG - 2011-09-13 15:27:37 --> Hooks Class Initialized
DEBUG - 2011-09-13 15:27:37 --> Utf8 Class Initialized
DEBUG - 2011-09-13 15:27:37 --> UTF-8 Support Enabled
DEBUG - 2011-09-13 15:27:37 --> URI Class Initialized
DEBUG - 2011-09-13 15:27:37 --> Router Class Initialized
DEBUG - 2011-09-13 15:27:37 --> Output Class Initialized
DEBUG - 2011-09-13 15:27:37 --> Input Class Initialized
DEBUG - 2011-09-13 15:27:37 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-13 15:27:37 --> Language Class Initialized
DEBUG - 2011-09-13 15:27:37 --> Loader Class Initialized
DEBUG - 2011-09-13 15:27:37 --> Controller Class Initialized
DEBUG - 2011-09-13 15:27:37 --> Model Class Initialized
DEBUG - 2011-09-13 15:27:37 --> Model Class Initialized
DEBUG - 2011-09-13 15:27:37 --> Model Class Initialized
DEBUG - 2011-09-13 15:27:37 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-13 15:27:37 --> Database Driver Class Initialized
DEBUG - 2011-09-13 15:27:38 --> File loaded: application/views/table/main.php
DEBUG - 2011-09-13 15:27:38 --> Helper loaded: url_helper
DEBUG - 2011-09-13 15:27:38 --> File loaded: application/views/common/header.php
DEBUG - 2011-09-13 15:27:38 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-09-13 15:27:38 --> File loaded: application/views/common/footer.php
DEBUG - 2011-09-13 15:27:38 --> File loaded: application/views/layout/main.php
DEBUG - 2011-09-13 15:27:38 --> Final output sent to browser
DEBUG - 2011-09-13 15:27:38 --> Total execution time: 0.5185
DEBUG - 2011-09-13 15:31:48 --> Config Class Initialized
DEBUG - 2011-09-13 15:31:48 --> Hooks Class Initialized
DEBUG - 2011-09-13 15:31:48 --> Utf8 Class Initialized
DEBUG - 2011-09-13 15:31:48 --> UTF-8 Support Enabled
DEBUG - 2011-09-13 15:31:48 --> URI Class Initialized
DEBUG - 2011-09-13 15:31:48 --> Router Class Initialized
DEBUG - 2011-09-13 15:31:48 --> Output Class Initialized
DEBUG - 2011-09-13 15:31:48 --> Input Class Initialized
DEBUG - 2011-09-13 15:31:48 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-13 15:31:48 --> Language Class Initialized
DEBUG - 2011-09-13 15:31:48 --> Loader Class Initialized
DEBUG - 2011-09-13 15:31:48 --> Controller Class Initialized
ERROR - 2011-09-13 15:31:48 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-09-13 15:31:48 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-09-13 15:31:48 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-09-13 15:31:48 --> Model Class Initialized
DEBUG - 2011-09-13 15:31:48 --> Model Class Initialized
DEBUG - 2011-09-13 15:31:48 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-13 15:31:48 --> Database Driver Class Initialized
DEBUG - 2011-09-13 15:31:48 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-09-13 15:31:48 --> Helper loaded: url_helper
DEBUG - 2011-09-13 15:31:48 --> File loaded: application/views/common/header.php
DEBUG - 2011-09-13 15:31:48 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-09-13 15:31:48 --> File loaded: application/views/common/footer.php
DEBUG - 2011-09-13 15:31:48 --> File loaded: application/views/layout/main.php
DEBUG - 2011-09-13 15:31:48 --> Final output sent to browser
DEBUG - 2011-09-13 15:31:48 --> Total execution time: 0.0303
DEBUG - 2011-09-13 15:31:49 --> Config Class Initialized
DEBUG - 2011-09-13 15:31:49 --> Hooks Class Initialized
DEBUG - 2011-09-13 15:31:49 --> Utf8 Class Initialized
DEBUG - 2011-09-13 15:31:49 --> UTF-8 Support Enabled
DEBUG - 2011-09-13 15:31:49 --> URI Class Initialized
DEBUG - 2011-09-13 15:31:49 --> Router Class Initialized
DEBUG - 2011-09-13 15:31:49 --> Output Class Initialized
DEBUG - 2011-09-13 15:31:49 --> Input Class Initialized
DEBUG - 2011-09-13 15:31:49 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-13 15:31:49 --> Language Class Initialized
DEBUG - 2011-09-13 15:31:49 --> Loader Class Initialized
DEBUG - 2011-09-13 15:31:49 --> Controller Class Initialized
DEBUG - 2011-09-13 15:31:49 --> Model Class Initialized
DEBUG - 2011-09-13 15:31:49 --> Model Class Initialized
DEBUG - 2011-09-13 15:31:49 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-13 15:31:49 --> Database Driver Class Initialized
DEBUG - 2011-09-13 15:31:50 --> Final output sent to browser
DEBUG - 2011-09-13 15:31:50 --> Total execution time: 0.6386
DEBUG - 2011-09-13 15:31:53 --> Config Class Initialized
DEBUG - 2011-09-13 15:31:53 --> Hooks Class Initialized
DEBUG - 2011-09-13 15:31:53 --> Utf8 Class Initialized
DEBUG - 2011-09-13 15:31:53 --> UTF-8 Support Enabled
DEBUG - 2011-09-13 15:31:53 --> URI Class Initialized
DEBUG - 2011-09-13 15:31:53 --> Router Class Initialized
ERROR - 2011-09-13 15:31:53 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-09-13 15:31:57 --> Config Class Initialized
DEBUG - 2011-09-13 15:31:57 --> Hooks Class Initialized
DEBUG - 2011-09-13 15:31:57 --> Utf8 Class Initialized
DEBUG - 2011-09-13 15:31:57 --> UTF-8 Support Enabled
DEBUG - 2011-09-13 15:31:57 --> URI Class Initialized
DEBUG - 2011-09-13 15:31:57 --> Router Class Initialized
DEBUG - 2011-09-13 15:31:57 --> Output Class Initialized
DEBUG - 2011-09-13 15:31:57 --> Input Class Initialized
DEBUG - 2011-09-13 15:31:57 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-13 15:31:57 --> Language Class Initialized
DEBUG - 2011-09-13 15:31:57 --> Loader Class Initialized
DEBUG - 2011-09-13 15:31:57 --> Controller Class Initialized
ERROR - 2011-09-13 15:31:57 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-09-13 15:31:57 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-09-13 15:31:57 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-09-13 15:31:57 --> Model Class Initialized
DEBUG - 2011-09-13 15:31:57 --> Model Class Initialized
DEBUG - 2011-09-13 15:31:57 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-13 15:31:57 --> Database Driver Class Initialized
DEBUG - 2011-09-13 15:31:57 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-09-13 15:31:57 --> Helper loaded: url_helper
DEBUG - 2011-09-13 15:31:57 --> File loaded: application/views/common/header.php
DEBUG - 2011-09-13 15:31:57 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-09-13 15:31:57 --> File loaded: application/views/common/footer.php
DEBUG - 2011-09-13 15:31:57 --> File loaded: application/views/layout/main.php
DEBUG - 2011-09-13 15:31:57 --> Final output sent to browser
DEBUG - 2011-09-13 15:31:57 --> Total execution time: 0.0283
DEBUG - 2011-09-13 15:31:58 --> Config Class Initialized
DEBUG - 2011-09-13 15:31:58 --> Hooks Class Initialized
DEBUG - 2011-09-13 15:31:58 --> Utf8 Class Initialized
DEBUG - 2011-09-13 15:31:58 --> UTF-8 Support Enabled
DEBUG - 2011-09-13 15:31:58 --> URI Class Initialized
DEBUG - 2011-09-13 15:31:58 --> Router Class Initialized
DEBUG - 2011-09-13 15:31:58 --> Output Class Initialized
DEBUG - 2011-09-13 15:31:58 --> Input Class Initialized
DEBUG - 2011-09-13 15:31:58 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-13 15:31:58 --> Language Class Initialized
DEBUG - 2011-09-13 15:31:58 --> Loader Class Initialized
DEBUG - 2011-09-13 15:31:58 --> Controller Class Initialized
ERROR - 2011-09-13 15:31:58 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-09-13 15:31:58 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-09-13 15:31:58 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-09-13 15:31:58 --> Model Class Initialized
DEBUG - 2011-09-13 15:31:58 --> Model Class Initialized
DEBUG - 2011-09-13 15:31:58 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-13 15:31:58 --> Database Driver Class Initialized
DEBUG - 2011-09-13 15:31:58 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-09-13 15:31:58 --> Helper loaded: url_helper
DEBUG - 2011-09-13 15:31:58 --> File loaded: application/views/common/header.php
DEBUG - 2011-09-13 15:31:58 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-09-13 15:31:58 --> File loaded: application/views/common/footer.php
DEBUG - 2011-09-13 15:31:58 --> File loaded: application/views/layout/main.php
DEBUG - 2011-09-13 15:31:58 --> Final output sent to browser
DEBUG - 2011-09-13 15:31:58 --> Total execution time: 0.0287
DEBUG - 2011-09-13 15:31:59 --> Config Class Initialized
DEBUG - 2011-09-13 15:31:59 --> Hooks Class Initialized
DEBUG - 2011-09-13 15:31:59 --> Utf8 Class Initialized
DEBUG - 2011-09-13 15:31:59 --> UTF-8 Support Enabled
DEBUG - 2011-09-13 15:31:59 --> URI Class Initialized
DEBUG - 2011-09-13 15:31:59 --> Router Class Initialized
DEBUG - 2011-09-13 15:31:59 --> Output Class Initialized
DEBUG - 2011-09-13 15:31:59 --> Input Class Initialized
DEBUG - 2011-09-13 15:31:59 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-13 15:31:59 --> Language Class Initialized
DEBUG - 2011-09-13 15:31:59 --> Loader Class Initialized
DEBUG - 2011-09-13 15:31:59 --> Controller Class Initialized
DEBUG - 2011-09-13 15:31:59 --> Model Class Initialized
DEBUG - 2011-09-13 15:31:59 --> Model Class Initialized
DEBUG - 2011-09-13 15:31:59 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-13 15:31:59 --> Database Driver Class Initialized
DEBUG - 2011-09-13 15:31:59 --> Config Class Initialized
DEBUG - 2011-09-13 15:31:59 --> Hooks Class Initialized
DEBUG - 2011-09-13 15:31:59 --> Utf8 Class Initialized
DEBUG - 2011-09-13 15:31:59 --> UTF-8 Support Enabled
DEBUG - 2011-09-13 15:31:59 --> URI Class Initialized
DEBUG - 2011-09-13 15:31:59 --> Router Class Initialized
DEBUG - 2011-09-13 15:31:59 --> Output Class Initialized
DEBUG - 2011-09-13 15:31:59 --> Input Class Initialized
DEBUG - 2011-09-13 15:31:59 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-13 15:31:59 --> Language Class Initialized
DEBUG - 2011-09-13 15:31:59 --> Loader Class Initialized
DEBUG - 2011-09-13 15:31:59 --> Controller Class Initialized
DEBUG - 2011-09-13 15:31:59 --> Model Class Initialized
DEBUG - 2011-09-13 15:31:59 --> Model Class Initialized
DEBUG - 2011-09-13 15:31:59 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-13 15:31:59 --> Database Driver Class Initialized
DEBUG - 2011-09-13 15:31:59 --> Final output sent to browser
DEBUG - 2011-09-13 15:31:59 --> Total execution time: 0.6296
DEBUG - 2011-09-13 15:32:00 --> Final output sent to browser
DEBUG - 2011-09-13 15:32:00 --> Total execution time: 0.5492
DEBUG - 2011-09-13 15:32:01 --> Config Class Initialized
DEBUG - 2011-09-13 15:32:01 --> Hooks Class Initialized
DEBUG - 2011-09-13 15:32:01 --> Utf8 Class Initialized
DEBUG - 2011-09-13 15:32:01 --> UTF-8 Support Enabled
DEBUG - 2011-09-13 15:32:01 --> URI Class Initialized
DEBUG - 2011-09-13 15:32:01 --> Router Class Initialized
ERROR - 2011-09-13 15:32:01 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-09-13 15:32:01 --> Config Class Initialized
DEBUG - 2011-09-13 15:32:01 --> Hooks Class Initialized
DEBUG - 2011-09-13 15:32:01 --> Utf8 Class Initialized
DEBUG - 2011-09-13 15:32:01 --> UTF-8 Support Enabled
DEBUG - 2011-09-13 15:32:01 --> URI Class Initialized
DEBUG - 2011-09-13 15:32:01 --> Router Class Initialized
ERROR - 2011-09-13 15:32:01 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-09-13 15:32:06 --> Config Class Initialized
DEBUG - 2011-09-13 15:32:06 --> Hooks Class Initialized
DEBUG - 2011-09-13 15:32:06 --> Utf8 Class Initialized
DEBUG - 2011-09-13 15:32:06 --> UTF-8 Support Enabled
DEBUG - 2011-09-13 15:32:06 --> URI Class Initialized
DEBUG - 2011-09-13 15:32:06 --> Router Class Initialized
DEBUG - 2011-09-13 15:32:06 --> Output Class Initialized
DEBUG - 2011-09-13 15:32:06 --> Input Class Initialized
DEBUG - 2011-09-13 15:32:06 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-13 15:32:06 --> Language Class Initialized
DEBUG - 2011-09-13 15:32:06 --> Loader Class Initialized
DEBUG - 2011-09-13 15:32:06 --> Controller Class Initialized
ERROR - 2011-09-13 15:32:06 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-09-13 15:32:06 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-09-13 15:32:06 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-09-13 15:32:06 --> Model Class Initialized
DEBUG - 2011-09-13 15:32:06 --> Model Class Initialized
DEBUG - 2011-09-13 15:32:06 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-13 15:32:06 --> Database Driver Class Initialized
DEBUG - 2011-09-13 15:32:06 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-09-13 15:32:06 --> Helper loaded: url_helper
DEBUG - 2011-09-13 15:32:06 --> File loaded: application/views/common/header.php
DEBUG - 2011-09-13 15:32:06 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-09-13 15:32:06 --> File loaded: application/views/common/footer.php
DEBUG - 2011-09-13 15:32:06 --> File loaded: application/views/layout/main.php
DEBUG - 2011-09-13 15:32:06 --> Final output sent to browser
DEBUG - 2011-09-13 15:32:06 --> Total execution time: 0.0968
DEBUG - 2011-09-13 15:32:15 --> Config Class Initialized
DEBUG - 2011-09-13 15:32:15 --> Hooks Class Initialized
DEBUG - 2011-09-13 15:32:15 --> Utf8 Class Initialized
DEBUG - 2011-09-13 15:32:15 --> UTF-8 Support Enabled
DEBUG - 2011-09-13 15:32:15 --> URI Class Initialized
DEBUG - 2011-09-13 15:32:15 --> Router Class Initialized
DEBUG - 2011-09-13 15:32:15 --> Output Class Initialized
DEBUG - 2011-09-13 15:32:15 --> Input Class Initialized
DEBUG - 2011-09-13 15:32:15 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-13 15:32:15 --> Language Class Initialized
DEBUG - 2011-09-13 15:32:15 --> Loader Class Initialized
DEBUG - 2011-09-13 15:32:15 --> Controller Class Initialized
ERROR - 2011-09-13 15:32:15 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-09-13 15:32:15 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-09-13 15:32:15 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-09-13 15:32:15 --> Model Class Initialized
DEBUG - 2011-09-13 15:32:15 --> Model Class Initialized
DEBUG - 2011-09-13 15:32:15 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-13 15:32:15 --> Database Driver Class Initialized
DEBUG - 2011-09-13 15:32:15 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-09-13 15:32:15 --> Helper loaded: url_helper
DEBUG - 2011-09-13 15:32:15 --> File loaded: application/views/common/header.php
DEBUG - 2011-09-13 15:32:15 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-09-13 15:32:15 --> File loaded: application/views/common/footer.php
DEBUG - 2011-09-13 15:32:15 --> File loaded: application/views/layout/main.php
DEBUG - 2011-09-13 15:32:15 --> Final output sent to browser
DEBUG - 2011-09-13 15:32:15 --> Total execution time: 0.0275
DEBUG - 2011-09-13 15:32:15 --> Config Class Initialized
DEBUG - 2011-09-13 15:32:15 --> Hooks Class Initialized
DEBUG - 2011-09-13 15:32:15 --> Utf8 Class Initialized
DEBUG - 2011-09-13 15:32:15 --> UTF-8 Support Enabled
DEBUG - 2011-09-13 15:32:15 --> URI Class Initialized
DEBUG - 2011-09-13 15:32:15 --> Router Class Initialized
DEBUG - 2011-09-13 15:32:15 --> Output Class Initialized
DEBUG - 2011-09-13 15:32:15 --> Input Class Initialized
DEBUG - 2011-09-13 15:32:15 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-13 15:32:15 --> Language Class Initialized
DEBUG - 2011-09-13 15:32:15 --> Loader Class Initialized
DEBUG - 2011-09-13 15:32:15 --> Controller Class Initialized
DEBUG - 2011-09-13 15:32:15 --> Model Class Initialized
DEBUG - 2011-09-13 15:32:15 --> Model Class Initialized
DEBUG - 2011-09-13 15:32:15 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-13 15:32:15 --> Database Driver Class Initialized
DEBUG - 2011-09-13 15:32:16 --> Final output sent to browser
DEBUG - 2011-09-13 15:32:16 --> Total execution time: 0.6745
DEBUG - 2011-09-13 15:32:17 --> Config Class Initialized
DEBUG - 2011-09-13 15:32:17 --> Hooks Class Initialized
DEBUG - 2011-09-13 15:32:17 --> Utf8 Class Initialized
DEBUG - 2011-09-13 15:32:17 --> UTF-8 Support Enabled
DEBUG - 2011-09-13 15:32:17 --> URI Class Initialized
DEBUG - 2011-09-13 15:32:17 --> Router Class Initialized
ERROR - 2011-09-13 15:32:17 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-09-13 15:32:25 --> Config Class Initialized
DEBUG - 2011-09-13 15:32:25 --> Hooks Class Initialized
DEBUG - 2011-09-13 15:32:25 --> Utf8 Class Initialized
DEBUG - 2011-09-13 15:32:25 --> UTF-8 Support Enabled
DEBUG - 2011-09-13 15:32:25 --> URI Class Initialized
DEBUG - 2011-09-13 15:32:25 --> Router Class Initialized
DEBUG - 2011-09-13 15:32:25 --> Output Class Initialized
DEBUG - 2011-09-13 15:32:25 --> Input Class Initialized
DEBUG - 2011-09-13 15:32:25 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-13 15:32:25 --> Language Class Initialized
DEBUG - 2011-09-13 15:32:25 --> Loader Class Initialized
DEBUG - 2011-09-13 15:32:25 --> Controller Class Initialized
ERROR - 2011-09-13 15:32:25 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-09-13 15:32:25 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-09-13 15:32:25 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-09-13 15:32:25 --> Model Class Initialized
DEBUG - 2011-09-13 15:32:25 --> Model Class Initialized
DEBUG - 2011-09-13 15:32:25 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-13 15:32:25 --> Database Driver Class Initialized
DEBUG - 2011-09-13 15:32:25 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-09-13 15:32:25 --> Helper loaded: url_helper
DEBUG - 2011-09-13 15:32:25 --> File loaded: application/views/common/header.php
DEBUG - 2011-09-13 15:32:25 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-09-13 15:32:25 --> File loaded: application/views/common/footer.php
DEBUG - 2011-09-13 15:32:25 --> File loaded: application/views/layout/main.php
DEBUG - 2011-09-13 15:32:25 --> Final output sent to browser
DEBUG - 2011-09-13 15:32:25 --> Total execution time: 0.0389
DEBUG - 2011-09-13 15:32:25 --> Config Class Initialized
DEBUG - 2011-09-13 15:32:25 --> Hooks Class Initialized
DEBUG - 2011-09-13 15:32:25 --> Utf8 Class Initialized
DEBUG - 2011-09-13 15:32:25 --> UTF-8 Support Enabled
DEBUG - 2011-09-13 15:32:25 --> URI Class Initialized
DEBUG - 2011-09-13 15:32:25 --> Router Class Initialized
DEBUG - 2011-09-13 15:32:25 --> Output Class Initialized
DEBUG - 2011-09-13 15:32:25 --> Input Class Initialized
DEBUG - 2011-09-13 15:32:25 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-13 15:32:25 --> Language Class Initialized
DEBUG - 2011-09-13 15:32:25 --> Loader Class Initialized
DEBUG - 2011-09-13 15:32:25 --> Controller Class Initialized
DEBUG - 2011-09-13 15:32:25 --> Model Class Initialized
DEBUG - 2011-09-13 15:32:25 --> Model Class Initialized
DEBUG - 2011-09-13 15:32:25 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-13 15:32:25 --> Database Driver Class Initialized
DEBUG - 2011-09-13 15:32:26 --> Final output sent to browser
DEBUG - 2011-09-13 15:32:26 --> Total execution time: 0.5504
DEBUG - 2011-09-13 15:32:27 --> Config Class Initialized
DEBUG - 2011-09-13 15:32:27 --> Hooks Class Initialized
DEBUG - 2011-09-13 15:32:27 --> Utf8 Class Initialized
DEBUG - 2011-09-13 15:32:27 --> UTF-8 Support Enabled
DEBUG - 2011-09-13 15:32:27 --> URI Class Initialized
DEBUG - 2011-09-13 15:32:27 --> Router Class Initialized
ERROR - 2011-09-13 15:32:27 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-09-13 15:32:39 --> Config Class Initialized
DEBUG - 2011-09-13 15:32:39 --> Hooks Class Initialized
DEBUG - 2011-09-13 15:32:39 --> Utf8 Class Initialized
DEBUG - 2011-09-13 15:32:39 --> UTF-8 Support Enabled
DEBUG - 2011-09-13 15:32:39 --> URI Class Initialized
DEBUG - 2011-09-13 15:32:39 --> Router Class Initialized
DEBUG - 2011-09-13 15:32:39 --> Output Class Initialized
DEBUG - 2011-09-13 15:32:39 --> Input Class Initialized
DEBUG - 2011-09-13 15:32:39 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-13 15:32:39 --> Language Class Initialized
DEBUG - 2011-09-13 15:32:39 --> Loader Class Initialized
DEBUG - 2011-09-13 15:32:39 --> Controller Class Initialized
ERROR - 2011-09-13 15:32:39 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-09-13 15:32:39 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-09-13 15:32:39 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-09-13 15:32:39 --> Model Class Initialized
DEBUG - 2011-09-13 15:32:39 --> Model Class Initialized
DEBUG - 2011-09-13 15:32:39 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-13 15:32:39 --> Database Driver Class Initialized
DEBUG - 2011-09-13 15:32:39 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-09-13 15:32:39 --> Helper loaded: url_helper
DEBUG - 2011-09-13 15:32:39 --> File loaded: application/views/common/header.php
DEBUG - 2011-09-13 15:32:39 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-09-13 15:32:39 --> File loaded: application/views/common/footer.php
DEBUG - 2011-09-13 15:32:39 --> File loaded: application/views/layout/main.php
DEBUG - 2011-09-13 15:32:39 --> Final output sent to browser
DEBUG - 2011-09-13 15:32:39 --> Total execution time: 0.0401
DEBUG - 2011-09-13 15:32:39 --> Config Class Initialized
DEBUG - 2011-09-13 15:32:39 --> Hooks Class Initialized
DEBUG - 2011-09-13 15:32:39 --> Utf8 Class Initialized
DEBUG - 2011-09-13 15:32:39 --> UTF-8 Support Enabled
DEBUG - 2011-09-13 15:32:39 --> URI Class Initialized
DEBUG - 2011-09-13 15:32:39 --> Router Class Initialized
DEBUG - 2011-09-13 15:32:39 --> Output Class Initialized
DEBUG - 2011-09-13 15:32:39 --> Input Class Initialized
DEBUG - 2011-09-13 15:32:39 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-13 15:32:39 --> Language Class Initialized
DEBUG - 2011-09-13 15:32:39 --> Loader Class Initialized
DEBUG - 2011-09-13 15:32:39 --> Controller Class Initialized
DEBUG - 2011-09-13 15:32:39 --> Model Class Initialized
DEBUG - 2011-09-13 15:32:39 --> Model Class Initialized
DEBUG - 2011-09-13 15:32:39 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-13 15:32:39 --> Database Driver Class Initialized
DEBUG - 2011-09-13 15:32:40 --> Final output sent to browser
DEBUG - 2011-09-13 15:32:40 --> Total execution time: 0.4766
DEBUG - 2011-09-13 15:32:42 --> Config Class Initialized
DEBUG - 2011-09-13 15:32:42 --> Hooks Class Initialized
DEBUG - 2011-09-13 15:32:42 --> Utf8 Class Initialized
DEBUG - 2011-09-13 15:32:42 --> UTF-8 Support Enabled
DEBUG - 2011-09-13 15:32:42 --> URI Class Initialized
DEBUG - 2011-09-13 15:32:42 --> Router Class Initialized
DEBUG - 2011-09-13 15:32:42 --> Output Class Initialized
DEBUG - 2011-09-13 15:32:42 --> Input Class Initialized
DEBUG - 2011-09-13 15:32:42 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-13 15:32:42 --> Language Class Initialized
DEBUG - 2011-09-13 15:32:42 --> Loader Class Initialized
DEBUG - 2011-09-13 15:32:42 --> Controller Class Initialized
ERROR - 2011-09-13 15:32:42 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-09-13 15:32:42 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-09-13 15:32:42 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-09-13 15:32:42 --> Model Class Initialized
DEBUG - 2011-09-13 15:32:42 --> Model Class Initialized
DEBUG - 2011-09-13 15:32:42 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-13 15:32:42 --> Database Driver Class Initialized
DEBUG - 2011-09-13 15:32:42 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-09-13 15:32:42 --> Helper loaded: url_helper
DEBUG - 2011-09-13 15:32:42 --> File loaded: application/views/common/header.php
DEBUG - 2011-09-13 15:32:42 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-09-13 15:32:42 --> File loaded: application/views/common/footer.php
DEBUG - 2011-09-13 15:32:42 --> File loaded: application/views/layout/main.php
DEBUG - 2011-09-13 15:32:42 --> Final output sent to browser
DEBUG - 2011-09-13 15:32:42 --> Total execution time: 0.0511
DEBUG - 2011-09-13 15:32:42 --> Config Class Initialized
DEBUG - 2011-09-13 15:32:42 --> Hooks Class Initialized
DEBUG - 2011-09-13 15:32:42 --> Utf8 Class Initialized
DEBUG - 2011-09-13 15:32:42 --> UTF-8 Support Enabled
DEBUG - 2011-09-13 15:32:42 --> URI Class Initialized
DEBUG - 2011-09-13 15:32:42 --> Router Class Initialized
ERROR - 2011-09-13 15:32:42 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-09-13 15:32:42 --> Config Class Initialized
DEBUG - 2011-09-13 15:32:42 --> Hooks Class Initialized
DEBUG - 2011-09-13 15:32:42 --> Utf8 Class Initialized
DEBUG - 2011-09-13 15:32:42 --> UTF-8 Support Enabled
DEBUG - 2011-09-13 15:32:42 --> URI Class Initialized
DEBUG - 2011-09-13 15:32:42 --> Router Class Initialized
DEBUG - 2011-09-13 15:32:42 --> Output Class Initialized
DEBUG - 2011-09-13 15:32:42 --> Input Class Initialized
DEBUG - 2011-09-13 15:32:42 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-13 15:32:42 --> Language Class Initialized
DEBUG - 2011-09-13 15:32:42 --> Loader Class Initialized
DEBUG - 2011-09-13 15:32:42 --> Controller Class Initialized
DEBUG - 2011-09-13 15:32:42 --> Model Class Initialized
DEBUG - 2011-09-13 15:32:42 --> Model Class Initialized
DEBUG - 2011-09-13 15:32:42 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-13 15:32:42 --> Database Driver Class Initialized
DEBUG - 2011-09-13 15:32:43 --> Final output sent to browser
DEBUG - 2011-09-13 15:32:43 --> Total execution time: 0.6611
DEBUG - 2011-09-13 15:32:44 --> Config Class Initialized
DEBUG - 2011-09-13 15:32:44 --> Hooks Class Initialized
DEBUG - 2011-09-13 15:32:44 --> Utf8 Class Initialized
DEBUG - 2011-09-13 15:32:44 --> UTF-8 Support Enabled
DEBUG - 2011-09-13 15:32:44 --> URI Class Initialized
DEBUG - 2011-09-13 15:32:44 --> Router Class Initialized
ERROR - 2011-09-13 15:32:44 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-09-13 15:32:46 --> Config Class Initialized
DEBUG - 2011-09-13 15:32:46 --> Hooks Class Initialized
DEBUG - 2011-09-13 15:32:46 --> Utf8 Class Initialized
DEBUG - 2011-09-13 15:32:46 --> UTF-8 Support Enabled
DEBUG - 2011-09-13 15:32:46 --> URI Class Initialized
DEBUG - 2011-09-13 15:32:46 --> Router Class Initialized
DEBUG - 2011-09-13 15:32:46 --> Output Class Initialized
DEBUG - 2011-09-13 15:32:46 --> Input Class Initialized
DEBUG - 2011-09-13 15:32:46 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-13 15:32:46 --> Language Class Initialized
DEBUG - 2011-09-13 15:32:46 --> Loader Class Initialized
DEBUG - 2011-09-13 15:32:46 --> Controller Class Initialized
ERROR - 2011-09-13 15:32:46 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-09-13 15:32:46 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-09-13 15:32:46 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-09-13 15:32:46 --> Model Class Initialized
DEBUG - 2011-09-13 15:32:46 --> Model Class Initialized
DEBUG - 2011-09-13 15:32:46 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-13 15:32:46 --> Database Driver Class Initialized
DEBUG - 2011-09-13 15:32:46 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-09-13 15:32:46 --> Helper loaded: url_helper
DEBUG - 2011-09-13 15:32:46 --> File loaded: application/views/common/header.php
DEBUG - 2011-09-13 15:32:46 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-09-13 15:32:46 --> File loaded: application/views/common/footer.php
DEBUG - 2011-09-13 15:32:46 --> File loaded: application/views/layout/main.php
DEBUG - 2011-09-13 15:32:46 --> Final output sent to browser
DEBUG - 2011-09-13 15:32:46 --> Total execution time: 0.0752
DEBUG - 2011-09-13 15:32:47 --> Config Class Initialized
DEBUG - 2011-09-13 15:32:47 --> Hooks Class Initialized
DEBUG - 2011-09-13 15:32:47 --> Utf8 Class Initialized
DEBUG - 2011-09-13 15:32:47 --> UTF-8 Support Enabled
DEBUG - 2011-09-13 15:32:47 --> URI Class Initialized
DEBUG - 2011-09-13 15:32:47 --> Router Class Initialized
DEBUG - 2011-09-13 15:32:47 --> Output Class Initialized
DEBUG - 2011-09-13 15:32:47 --> Input Class Initialized
DEBUG - 2011-09-13 15:32:47 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-13 15:32:47 --> Language Class Initialized
DEBUG - 2011-09-13 15:32:47 --> Loader Class Initialized
DEBUG - 2011-09-13 15:32:47 --> Controller Class Initialized
DEBUG - 2011-09-13 15:32:47 --> Model Class Initialized
DEBUG - 2011-09-13 15:32:47 --> Model Class Initialized
DEBUG - 2011-09-13 15:32:47 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-13 15:32:47 --> Database Driver Class Initialized
DEBUG - 2011-09-13 15:32:47 --> Final output sent to browser
DEBUG - 2011-09-13 15:32:47 --> Total execution time: 0.5060
DEBUG - 2011-09-13 15:32:49 --> Config Class Initialized
DEBUG - 2011-09-13 15:32:49 --> Hooks Class Initialized
DEBUG - 2011-09-13 15:32:49 --> Utf8 Class Initialized
DEBUG - 2011-09-13 15:32:49 --> UTF-8 Support Enabled
DEBUG - 2011-09-13 15:32:49 --> URI Class Initialized
DEBUG - 2011-09-13 15:32:49 --> Router Class Initialized
ERROR - 2011-09-13 15:32:49 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-09-13 15:33:10 --> Config Class Initialized
DEBUG - 2011-09-13 15:33:10 --> Hooks Class Initialized
DEBUG - 2011-09-13 15:33:10 --> Utf8 Class Initialized
DEBUG - 2011-09-13 15:33:10 --> UTF-8 Support Enabled
DEBUG - 2011-09-13 15:33:10 --> URI Class Initialized
DEBUG - 2011-09-13 15:33:10 --> Router Class Initialized
ERROR - 2011-09-13 15:33:10 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-09-13 15:33:51 --> Config Class Initialized
DEBUG - 2011-09-13 15:33:51 --> Hooks Class Initialized
DEBUG - 2011-09-13 15:33:51 --> Utf8 Class Initialized
DEBUG - 2011-09-13 15:33:51 --> UTF-8 Support Enabled
DEBUG - 2011-09-13 15:33:51 --> URI Class Initialized
DEBUG - 2011-09-13 15:33:51 --> Router Class Initialized
DEBUG - 2011-09-13 15:33:51 --> Output Class Initialized
DEBUG - 2011-09-13 15:33:51 --> Input Class Initialized
DEBUG - 2011-09-13 15:33:51 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-13 15:33:51 --> Language Class Initialized
DEBUG - 2011-09-13 15:33:51 --> Loader Class Initialized
DEBUG - 2011-09-13 15:33:51 --> Controller Class Initialized
DEBUG - 2011-09-13 15:33:51 --> Model Class Initialized
DEBUG - 2011-09-13 15:33:51 --> Model Class Initialized
DEBUG - 2011-09-13 15:33:51 --> Model Class Initialized
DEBUG - 2011-09-13 15:33:51 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-13 15:33:51 --> Database Driver Class Initialized
DEBUG - 2011-09-13 15:33:51 --> File loaded: application/views/table/main.php
DEBUG - 2011-09-13 15:33:51 --> Helper loaded: url_helper
DEBUG - 2011-09-13 15:33:51 --> File loaded: application/views/common/header.php
DEBUG - 2011-09-13 15:33:51 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-09-13 15:33:51 --> File loaded: application/views/common/footer.php
DEBUG - 2011-09-13 15:33:51 --> File loaded: application/views/layout/main.php
DEBUG - 2011-09-13 15:33:51 --> Final output sent to browser
DEBUG - 2011-09-13 15:33:51 --> Total execution time: 0.0631
DEBUG - 2011-09-13 15:34:57 --> Config Class Initialized
DEBUG - 2011-09-13 15:34:57 --> Hooks Class Initialized
DEBUG - 2011-09-13 15:34:57 --> Utf8 Class Initialized
DEBUG - 2011-09-13 15:34:57 --> UTF-8 Support Enabled
DEBUG - 2011-09-13 15:34:57 --> URI Class Initialized
DEBUG - 2011-09-13 15:34:57 --> Router Class Initialized
DEBUG - 2011-09-13 15:34:57 --> Output Class Initialized
DEBUG - 2011-09-13 15:34:57 --> Input Class Initialized
DEBUG - 2011-09-13 15:34:57 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-13 15:34:57 --> Language Class Initialized
DEBUG - 2011-09-13 15:34:57 --> Loader Class Initialized
DEBUG - 2011-09-13 15:34:57 --> Controller Class Initialized
DEBUG - 2011-09-13 15:34:57 --> Model Class Initialized
DEBUG - 2011-09-13 15:34:57 --> Model Class Initialized
DEBUG - 2011-09-13 15:34:57 --> Model Class Initialized
DEBUG - 2011-09-13 15:34:57 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-13 15:34:57 --> Database Driver Class Initialized
DEBUG - 2011-09-13 15:34:57 --> File loaded: application/views/table/main.php
DEBUG - 2011-09-13 15:34:57 --> Helper loaded: url_helper
DEBUG - 2011-09-13 15:34:57 --> File loaded: application/views/common/header.php
DEBUG - 2011-09-13 15:34:57 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-09-13 15:34:57 --> File loaded: application/views/common/footer.php
DEBUG - 2011-09-13 15:34:57 --> File loaded: application/views/layout/main.php
DEBUG - 2011-09-13 15:34:57 --> Final output sent to browser
DEBUG - 2011-09-13 15:34:57 --> Total execution time: 0.2693
DEBUG - 2011-09-13 15:35:01 --> Config Class Initialized
DEBUG - 2011-09-13 15:35:01 --> Hooks Class Initialized
DEBUG - 2011-09-13 15:35:01 --> Utf8 Class Initialized
DEBUG - 2011-09-13 15:35:01 --> UTF-8 Support Enabled
DEBUG - 2011-09-13 15:35:01 --> URI Class Initialized
DEBUG - 2011-09-13 15:35:01 --> Router Class Initialized
DEBUG - 2011-09-13 15:35:01 --> Output Class Initialized
DEBUG - 2011-09-13 15:35:01 --> Input Class Initialized
DEBUG - 2011-09-13 15:35:01 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-13 15:35:01 --> Language Class Initialized
DEBUG - 2011-09-13 15:35:01 --> Loader Class Initialized
DEBUG - 2011-09-13 15:35:01 --> Controller Class Initialized
DEBUG - 2011-09-13 15:35:01 --> Model Class Initialized
DEBUG - 2011-09-13 15:35:01 --> Model Class Initialized
DEBUG - 2011-09-13 15:35:01 --> Model Class Initialized
DEBUG - 2011-09-13 15:35:01 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-13 15:35:01 --> Database Driver Class Initialized
DEBUG - 2011-09-13 15:35:01 --> File loaded: application/views/table/main.php
DEBUG - 2011-09-13 15:35:01 --> Helper loaded: url_helper
DEBUG - 2011-09-13 15:35:01 --> File loaded: application/views/common/header.php
DEBUG - 2011-09-13 15:35:01 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-09-13 15:35:01 --> File loaded: application/views/common/footer.php
DEBUG - 2011-09-13 15:35:01 --> File loaded: application/views/layout/main.php
DEBUG - 2011-09-13 15:35:01 --> Final output sent to browser
DEBUG - 2011-09-13 15:35:01 --> Total execution time: 0.0514
DEBUG - 2011-09-13 15:35:41 --> Config Class Initialized
DEBUG - 2011-09-13 15:35:41 --> Hooks Class Initialized
DEBUG - 2011-09-13 15:35:41 --> Utf8 Class Initialized
DEBUG - 2011-09-13 15:35:41 --> UTF-8 Support Enabled
DEBUG - 2011-09-13 15:35:41 --> URI Class Initialized
DEBUG - 2011-09-13 15:35:41 --> Router Class Initialized
DEBUG - 2011-09-13 15:35:41 --> Output Class Initialized
DEBUG - 2011-09-13 15:35:41 --> Input Class Initialized
DEBUG - 2011-09-13 15:35:41 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-13 15:35:41 --> Language Class Initialized
DEBUG - 2011-09-13 15:35:41 --> Loader Class Initialized
DEBUG - 2011-09-13 15:35:41 --> Controller Class Initialized
DEBUG - 2011-09-13 15:35:41 --> Model Class Initialized
DEBUG - 2011-09-13 15:35:41 --> Model Class Initialized
DEBUG - 2011-09-13 15:35:41 --> Model Class Initialized
DEBUG - 2011-09-13 15:35:41 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-13 15:35:41 --> Database Driver Class Initialized
DEBUG - 2011-09-13 15:35:41 --> File loaded: application/views/table/main.php
DEBUG - 2011-09-13 15:35:41 --> Helper loaded: url_helper
DEBUG - 2011-09-13 15:35:41 --> File loaded: application/views/common/header.php
DEBUG - 2011-09-13 15:35:41 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-09-13 15:35:41 --> File loaded: application/views/common/footer.php
DEBUG - 2011-09-13 15:35:41 --> File loaded: application/views/layout/main.php
DEBUG - 2011-09-13 15:35:41 --> Final output sent to browser
DEBUG - 2011-09-13 15:35:41 --> Total execution time: 0.0500
DEBUG - 2011-09-13 15:35:54 --> Config Class Initialized
DEBUG - 2011-09-13 15:35:54 --> Hooks Class Initialized
DEBUG - 2011-09-13 15:35:54 --> Utf8 Class Initialized
DEBUG - 2011-09-13 15:35:54 --> UTF-8 Support Enabled
DEBUG - 2011-09-13 15:35:54 --> URI Class Initialized
DEBUG - 2011-09-13 15:35:54 --> Router Class Initialized
DEBUG - 2011-09-13 15:35:54 --> Output Class Initialized
DEBUG - 2011-09-13 15:35:54 --> Input Class Initialized
DEBUG - 2011-09-13 15:35:54 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-13 15:35:54 --> Language Class Initialized
DEBUG - 2011-09-13 15:35:54 --> Loader Class Initialized
DEBUG - 2011-09-13 15:35:54 --> Controller Class Initialized
DEBUG - 2011-09-13 15:35:54 --> Model Class Initialized
DEBUG - 2011-09-13 15:35:54 --> Model Class Initialized
DEBUG - 2011-09-13 15:35:54 --> Model Class Initialized
DEBUG - 2011-09-13 15:35:54 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-13 15:35:54 --> Database Driver Class Initialized
DEBUG - 2011-09-13 15:35:54 --> File loaded: application/views/table/main.php
DEBUG - 2011-09-13 15:35:54 --> Helper loaded: url_helper
DEBUG - 2011-09-13 15:35:54 --> File loaded: application/views/common/header.php
DEBUG - 2011-09-13 15:35:54 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-09-13 15:35:54 --> File loaded: application/views/common/footer.php
DEBUG - 2011-09-13 15:35:54 --> File loaded: application/views/layout/main.php
DEBUG - 2011-09-13 15:35:54 --> Final output sent to browser
DEBUG - 2011-09-13 15:35:54 --> Total execution time: 0.2353
DEBUG - 2011-09-13 15:36:20 --> Config Class Initialized
DEBUG - 2011-09-13 15:36:20 --> Hooks Class Initialized
DEBUG - 2011-09-13 15:36:20 --> Utf8 Class Initialized
DEBUG - 2011-09-13 15:36:20 --> UTF-8 Support Enabled
DEBUG - 2011-09-13 15:36:20 --> URI Class Initialized
DEBUG - 2011-09-13 15:36:20 --> Router Class Initialized
DEBUG - 2011-09-13 15:36:20 --> Output Class Initialized
DEBUG - 2011-09-13 15:36:20 --> Input Class Initialized
DEBUG - 2011-09-13 15:36:20 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-13 15:36:20 --> Language Class Initialized
DEBUG - 2011-09-13 15:36:20 --> Loader Class Initialized
DEBUG - 2011-09-13 15:36:20 --> Controller Class Initialized
DEBUG - 2011-09-13 15:36:20 --> Model Class Initialized
DEBUG - 2011-09-13 15:36:20 --> Model Class Initialized
DEBUG - 2011-09-13 15:36:20 --> Model Class Initialized
DEBUG - 2011-09-13 15:36:20 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-13 15:36:20 --> Database Driver Class Initialized
DEBUG - 2011-09-13 15:36:21 --> File loaded: application/views/table/main.php
DEBUG - 2011-09-13 15:36:21 --> Helper loaded: url_helper
DEBUG - 2011-09-13 15:36:21 --> File loaded: application/views/common/header.php
DEBUG - 2011-09-13 15:36:21 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-09-13 15:36:21 --> File loaded: application/views/common/footer.php
DEBUG - 2011-09-13 15:36:21 --> File loaded: application/views/layout/main.php
DEBUG - 2011-09-13 15:36:21 --> Final output sent to browser
DEBUG - 2011-09-13 15:36:21 --> Total execution time: 0.2362
DEBUG - 2011-09-13 15:36:44 --> Config Class Initialized
DEBUG - 2011-09-13 15:36:44 --> Hooks Class Initialized
DEBUG - 2011-09-13 15:36:44 --> Utf8 Class Initialized
DEBUG - 2011-09-13 15:36:44 --> UTF-8 Support Enabled
DEBUG - 2011-09-13 15:36:44 --> URI Class Initialized
DEBUG - 2011-09-13 15:36:44 --> Router Class Initialized
DEBUG - 2011-09-13 15:36:44 --> Output Class Initialized
DEBUG - 2011-09-13 15:36:44 --> Input Class Initialized
DEBUG - 2011-09-13 15:36:44 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-13 15:36:44 --> Language Class Initialized
DEBUG - 2011-09-13 15:36:44 --> Loader Class Initialized
DEBUG - 2011-09-13 15:36:44 --> Controller Class Initialized
DEBUG - 2011-09-13 15:36:44 --> Model Class Initialized
DEBUG - 2011-09-13 15:36:44 --> Model Class Initialized
DEBUG - 2011-09-13 15:36:44 --> Model Class Initialized
DEBUG - 2011-09-13 15:36:44 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-13 15:36:44 --> Database Driver Class Initialized
DEBUG - 2011-09-13 15:36:44 --> File loaded: application/views/table/main.php
DEBUG - 2011-09-13 15:36:44 --> Helper loaded: url_helper
DEBUG - 2011-09-13 15:36:44 --> File loaded: application/views/common/header.php
DEBUG - 2011-09-13 15:36:44 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-09-13 15:36:44 --> File loaded: application/views/common/footer.php
DEBUG - 2011-09-13 15:36:44 --> File loaded: application/views/layout/main.php
DEBUG - 2011-09-13 15:36:44 --> Final output sent to browser
DEBUG - 2011-09-13 15:36:44 --> Total execution time: 0.3691
DEBUG - 2011-09-13 15:37:10 --> Config Class Initialized
DEBUG - 2011-09-13 15:37:10 --> Hooks Class Initialized
DEBUG - 2011-09-13 15:37:10 --> Utf8 Class Initialized
DEBUG - 2011-09-13 15:37:10 --> UTF-8 Support Enabled
DEBUG - 2011-09-13 15:37:10 --> URI Class Initialized
DEBUG - 2011-09-13 15:37:10 --> Router Class Initialized
DEBUG - 2011-09-13 15:37:10 --> Output Class Initialized
DEBUG - 2011-09-13 15:37:10 --> Input Class Initialized
DEBUG - 2011-09-13 15:37:10 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-13 15:37:10 --> Language Class Initialized
DEBUG - 2011-09-13 15:37:10 --> Loader Class Initialized
DEBUG - 2011-09-13 15:37:10 --> Controller Class Initialized
DEBUG - 2011-09-13 15:37:10 --> Model Class Initialized
DEBUG - 2011-09-13 15:37:10 --> Model Class Initialized
DEBUG - 2011-09-13 15:37:10 --> Model Class Initialized
DEBUG - 2011-09-13 15:37:10 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-13 15:37:10 --> Database Driver Class Initialized
DEBUG - 2011-09-13 15:37:10 --> File loaded: application/views/table/main.php
DEBUG - 2011-09-13 15:37:10 --> Helper loaded: url_helper
DEBUG - 2011-09-13 15:37:10 --> File loaded: application/views/common/header.php
DEBUG - 2011-09-13 15:37:10 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-09-13 15:37:10 --> File loaded: application/views/common/footer.php
DEBUG - 2011-09-13 15:37:10 --> File loaded: application/views/layout/main.php
DEBUG - 2011-09-13 15:37:10 --> Final output sent to browser
DEBUG - 2011-09-13 15:37:10 --> Total execution time: 0.3093
DEBUG - 2011-09-13 15:37:32 --> Config Class Initialized
DEBUG - 2011-09-13 15:37:32 --> Hooks Class Initialized
DEBUG - 2011-09-13 15:37:32 --> Utf8 Class Initialized
DEBUG - 2011-09-13 15:37:32 --> UTF-8 Support Enabled
DEBUG - 2011-09-13 15:37:32 --> URI Class Initialized
DEBUG - 2011-09-13 15:37:32 --> Router Class Initialized
DEBUG - 2011-09-13 15:37:32 --> Output Class Initialized
DEBUG - 2011-09-13 15:37:32 --> Input Class Initialized
DEBUG - 2011-09-13 15:37:32 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-13 15:37:32 --> Language Class Initialized
DEBUG - 2011-09-13 15:37:32 --> Loader Class Initialized
DEBUG - 2011-09-13 15:37:32 --> Controller Class Initialized
DEBUG - 2011-09-13 15:37:32 --> Model Class Initialized
DEBUG - 2011-09-13 15:37:32 --> Model Class Initialized
DEBUG - 2011-09-13 15:37:32 --> Model Class Initialized
DEBUG - 2011-09-13 15:37:32 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-13 15:37:32 --> Database Driver Class Initialized
DEBUG - 2011-09-13 15:37:32 --> File loaded: application/views/table/main.php
DEBUG - 2011-09-13 15:37:32 --> Helper loaded: url_helper
DEBUG - 2011-09-13 15:37:32 --> File loaded: application/views/common/header.php
DEBUG - 2011-09-13 15:37:32 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-09-13 15:37:32 --> File loaded: application/views/common/footer.php
DEBUG - 2011-09-13 15:37:32 --> File loaded: application/views/layout/main.php
DEBUG - 2011-09-13 15:37:32 --> Final output sent to browser
DEBUG - 2011-09-13 15:37:32 --> Total execution time: 0.2645
DEBUG - 2011-09-13 15:38:01 --> Config Class Initialized
DEBUG - 2011-09-13 15:38:01 --> Hooks Class Initialized
DEBUG - 2011-09-13 15:38:01 --> Utf8 Class Initialized
DEBUG - 2011-09-13 15:38:01 --> UTF-8 Support Enabled
DEBUG - 2011-09-13 15:38:01 --> URI Class Initialized
DEBUG - 2011-09-13 15:38:01 --> Router Class Initialized
DEBUG - 2011-09-13 15:38:01 --> Output Class Initialized
DEBUG - 2011-09-13 15:38:01 --> Input Class Initialized
DEBUG - 2011-09-13 15:38:01 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-13 15:38:01 --> Language Class Initialized
DEBUG - 2011-09-13 15:38:01 --> Loader Class Initialized
DEBUG - 2011-09-13 15:38:01 --> Controller Class Initialized
DEBUG - 2011-09-13 15:38:01 --> Model Class Initialized
DEBUG - 2011-09-13 15:38:01 --> Model Class Initialized
DEBUG - 2011-09-13 15:38:01 --> Model Class Initialized
DEBUG - 2011-09-13 15:38:01 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-13 15:38:01 --> Database Driver Class Initialized
DEBUG - 2011-09-13 15:38:01 --> File loaded: application/views/table/main.php
DEBUG - 2011-09-13 15:38:01 --> Helper loaded: url_helper
DEBUG - 2011-09-13 15:38:01 --> File loaded: application/views/common/header.php
DEBUG - 2011-09-13 15:38:01 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-09-13 15:38:01 --> File loaded: application/views/common/footer.php
DEBUG - 2011-09-13 15:38:01 --> File loaded: application/views/layout/main.php
DEBUG - 2011-09-13 15:38:01 --> Final output sent to browser
DEBUG - 2011-09-13 15:38:01 --> Total execution time: 0.1987
DEBUG - 2011-09-13 15:38:25 --> Config Class Initialized
DEBUG - 2011-09-13 15:38:25 --> Hooks Class Initialized
DEBUG - 2011-09-13 15:38:25 --> Utf8 Class Initialized
DEBUG - 2011-09-13 15:38:25 --> UTF-8 Support Enabled
DEBUG - 2011-09-13 15:38:25 --> URI Class Initialized
DEBUG - 2011-09-13 15:38:25 --> Router Class Initialized
DEBUG - 2011-09-13 15:38:25 --> Output Class Initialized
DEBUG - 2011-09-13 15:38:25 --> Input Class Initialized
DEBUG - 2011-09-13 15:38:25 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-13 15:38:25 --> Language Class Initialized
DEBUG - 2011-09-13 15:38:25 --> Loader Class Initialized
DEBUG - 2011-09-13 15:38:25 --> Controller Class Initialized
DEBUG - 2011-09-13 15:38:25 --> Model Class Initialized
DEBUG - 2011-09-13 15:38:25 --> Model Class Initialized
DEBUG - 2011-09-13 15:38:25 --> Model Class Initialized
DEBUG - 2011-09-13 15:38:25 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-13 15:38:25 --> Database Driver Class Initialized
DEBUG - 2011-09-13 15:38:26 --> File loaded: application/views/table/main.php
DEBUG - 2011-09-13 15:38:26 --> Helper loaded: url_helper
DEBUG - 2011-09-13 15:38:26 --> File loaded: application/views/common/header.php
DEBUG - 2011-09-13 15:38:26 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-09-13 15:38:26 --> File loaded: application/views/common/footer.php
DEBUG - 2011-09-13 15:38:26 --> File loaded: application/views/layout/main.php
DEBUG - 2011-09-13 15:38:26 --> Final output sent to browser
DEBUG - 2011-09-13 15:38:26 --> Total execution time: 0.2068
DEBUG - 2011-09-13 15:39:03 --> Config Class Initialized
DEBUG - 2011-09-13 15:39:03 --> Hooks Class Initialized
DEBUG - 2011-09-13 15:39:03 --> Utf8 Class Initialized
DEBUG - 2011-09-13 15:39:03 --> UTF-8 Support Enabled
DEBUG - 2011-09-13 15:39:03 --> URI Class Initialized
DEBUG - 2011-09-13 15:39:03 --> Router Class Initialized
DEBUG - 2011-09-13 15:39:03 --> Output Class Initialized
DEBUG - 2011-09-13 15:39:03 --> Input Class Initialized
DEBUG - 2011-09-13 15:39:03 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-13 15:39:03 --> Language Class Initialized
DEBUG - 2011-09-13 15:39:03 --> Loader Class Initialized
DEBUG - 2011-09-13 15:39:03 --> Controller Class Initialized
DEBUG - 2011-09-13 15:39:03 --> Model Class Initialized
DEBUG - 2011-09-13 15:39:03 --> Model Class Initialized
DEBUG - 2011-09-13 15:39:03 --> Model Class Initialized
DEBUG - 2011-09-13 15:39:03 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-13 15:39:03 --> Database Driver Class Initialized
DEBUG - 2011-09-13 15:39:03 --> File loaded: application/views/table/main.php
DEBUG - 2011-09-13 15:39:03 --> Helper loaded: url_helper
DEBUG - 2011-09-13 15:39:03 --> File loaded: application/views/common/header.php
DEBUG - 2011-09-13 15:39:03 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-09-13 15:39:03 --> File loaded: application/views/common/footer.php
DEBUG - 2011-09-13 15:39:03 --> File loaded: application/views/layout/main.php
DEBUG - 2011-09-13 15:39:03 --> Final output sent to browser
DEBUG - 2011-09-13 15:39:03 --> Total execution time: 0.3194
DEBUG - 2011-09-13 15:39:20 --> Config Class Initialized
DEBUG - 2011-09-13 15:39:20 --> Hooks Class Initialized
DEBUG - 2011-09-13 15:39:20 --> Utf8 Class Initialized
DEBUG - 2011-09-13 15:39:20 --> UTF-8 Support Enabled
DEBUG - 2011-09-13 15:39:20 --> URI Class Initialized
DEBUG - 2011-09-13 15:39:20 --> Router Class Initialized
DEBUG - 2011-09-13 15:39:20 --> Output Class Initialized
DEBUG - 2011-09-13 15:39:20 --> Input Class Initialized
DEBUG - 2011-09-13 15:39:20 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-13 15:39:20 --> Language Class Initialized
DEBUG - 2011-09-13 15:39:20 --> Loader Class Initialized
DEBUG - 2011-09-13 15:39:20 --> Controller Class Initialized
DEBUG - 2011-09-13 15:39:20 --> Model Class Initialized
DEBUG - 2011-09-13 15:39:20 --> Model Class Initialized
DEBUG - 2011-09-13 15:39:20 --> Model Class Initialized
DEBUG - 2011-09-13 15:39:20 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-13 15:39:20 --> Database Driver Class Initialized
DEBUG - 2011-09-13 15:39:20 --> File loaded: application/views/table/main.php
DEBUG - 2011-09-13 15:39:20 --> Helper loaded: url_helper
DEBUG - 2011-09-13 15:39:20 --> File loaded: application/views/common/header.php
DEBUG - 2011-09-13 15:39:20 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-09-13 15:39:20 --> File loaded: application/views/common/footer.php
DEBUG - 2011-09-13 15:39:20 --> File loaded: application/views/layout/main.php
DEBUG - 2011-09-13 15:39:20 --> Final output sent to browser
DEBUG - 2011-09-13 15:39:20 --> Total execution time: 0.1937
DEBUG - 2011-09-13 15:39:57 --> Config Class Initialized
DEBUG - 2011-09-13 15:39:57 --> Hooks Class Initialized
DEBUG - 2011-09-13 15:39:57 --> Utf8 Class Initialized
DEBUG - 2011-09-13 15:39:57 --> UTF-8 Support Enabled
DEBUG - 2011-09-13 15:39:57 --> URI Class Initialized
DEBUG - 2011-09-13 15:39:57 --> Router Class Initialized
DEBUG - 2011-09-13 15:39:57 --> Output Class Initialized
DEBUG - 2011-09-13 15:39:57 --> Input Class Initialized
DEBUG - 2011-09-13 15:39:57 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-13 15:39:57 --> Language Class Initialized
DEBUG - 2011-09-13 15:39:57 --> Loader Class Initialized
DEBUG - 2011-09-13 15:39:57 --> Controller Class Initialized
DEBUG - 2011-09-13 15:39:57 --> Model Class Initialized
DEBUG - 2011-09-13 15:39:57 --> Model Class Initialized
DEBUG - 2011-09-13 15:39:57 --> Model Class Initialized
DEBUG - 2011-09-13 15:39:57 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-13 15:39:57 --> Database Driver Class Initialized
DEBUG - 2011-09-13 15:39:57 --> File loaded: application/views/table/main.php
DEBUG - 2011-09-13 15:39:57 --> Helper loaded: url_helper
DEBUG - 2011-09-13 15:39:57 --> File loaded: application/views/common/header.php
DEBUG - 2011-09-13 15:39:57 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-09-13 15:39:57 --> File loaded: application/views/common/footer.php
DEBUG - 2011-09-13 15:39:57 --> File loaded: application/views/layout/main.php
DEBUG - 2011-09-13 15:39:57 --> Final output sent to browser
DEBUG - 2011-09-13 15:39:57 --> Total execution time: 0.3227
DEBUG - 2011-09-13 15:40:09 --> Config Class Initialized
DEBUG - 2011-09-13 15:40:09 --> Hooks Class Initialized
DEBUG - 2011-09-13 15:40:09 --> Utf8 Class Initialized
DEBUG - 2011-09-13 15:40:09 --> UTF-8 Support Enabled
DEBUG - 2011-09-13 15:40:09 --> URI Class Initialized
DEBUG - 2011-09-13 15:40:09 --> Router Class Initialized
DEBUG - 2011-09-13 15:40:09 --> Output Class Initialized
DEBUG - 2011-09-13 15:40:09 --> Input Class Initialized
DEBUG - 2011-09-13 15:40:09 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-13 15:40:09 --> Language Class Initialized
DEBUG - 2011-09-13 15:40:09 --> Loader Class Initialized
DEBUG - 2011-09-13 15:40:09 --> Controller Class Initialized
DEBUG - 2011-09-13 15:40:09 --> Model Class Initialized
DEBUG - 2011-09-13 15:40:09 --> Model Class Initialized
DEBUG - 2011-09-13 15:40:09 --> Model Class Initialized
DEBUG - 2011-09-13 15:40:09 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-13 15:40:09 --> Database Driver Class Initialized
DEBUG - 2011-09-13 15:40:09 --> File loaded: application/views/table/main.php
DEBUG - 2011-09-13 15:40:09 --> Helper loaded: url_helper
DEBUG - 2011-09-13 15:40:09 --> File loaded: application/views/common/header.php
DEBUG - 2011-09-13 15:40:09 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-09-13 15:40:09 --> File loaded: application/views/common/footer.php
DEBUG - 2011-09-13 15:40:09 --> File loaded: application/views/layout/main.php
DEBUG - 2011-09-13 15:40:09 --> Final output sent to browser
DEBUG - 2011-09-13 15:40:09 --> Total execution time: 0.5670
DEBUG - 2011-09-13 15:50:02 --> Config Class Initialized
DEBUG - 2011-09-13 15:50:02 --> Hooks Class Initialized
DEBUG - 2011-09-13 15:50:02 --> Utf8 Class Initialized
DEBUG - 2011-09-13 15:50:02 --> UTF-8 Support Enabled
DEBUG - 2011-09-13 15:50:02 --> URI Class Initialized
DEBUG - 2011-09-13 15:50:02 --> Router Class Initialized
DEBUG - 2011-09-13 15:50:02 --> Output Class Initialized
DEBUG - 2011-09-13 15:50:02 --> Input Class Initialized
DEBUG - 2011-09-13 15:50:02 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-13 15:50:02 --> Language Class Initialized
DEBUG - 2011-09-13 15:50:02 --> Loader Class Initialized
DEBUG - 2011-09-13 15:50:02 --> Controller Class Initialized
ERROR - 2011-09-13 15:50:02 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-09-13 15:50:02 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-09-13 15:50:02 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-09-13 15:50:02 --> Model Class Initialized
DEBUG - 2011-09-13 15:50:02 --> Model Class Initialized
DEBUG - 2011-09-13 15:50:02 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-13 15:50:02 --> Database Driver Class Initialized
DEBUG - 2011-09-13 15:50:02 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-09-13 15:50:02 --> Helper loaded: url_helper
DEBUG - 2011-09-13 15:50:02 --> File loaded: application/views/common/header.php
DEBUG - 2011-09-13 15:50:02 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-09-13 15:50:02 --> File loaded: application/views/common/footer.php
DEBUG - 2011-09-13 15:50:02 --> File loaded: application/views/layout/main.php
DEBUG - 2011-09-13 15:50:02 --> Final output sent to browser
DEBUG - 2011-09-13 15:50:02 --> Total execution time: 0.1270
DEBUG - 2011-09-13 15:50:05 --> Config Class Initialized
DEBUG - 2011-09-13 15:50:05 --> Hooks Class Initialized
DEBUG - 2011-09-13 15:50:05 --> Utf8 Class Initialized
DEBUG - 2011-09-13 15:50:05 --> UTF-8 Support Enabled
DEBUG - 2011-09-13 15:50:05 --> URI Class Initialized
DEBUG - 2011-09-13 15:50:05 --> Router Class Initialized
DEBUG - 2011-09-13 15:50:05 --> Output Class Initialized
DEBUG - 2011-09-13 15:50:05 --> Input Class Initialized
DEBUG - 2011-09-13 15:50:05 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-13 15:50:05 --> Language Class Initialized
DEBUG - 2011-09-13 15:50:05 --> Loader Class Initialized
DEBUG - 2011-09-13 15:50:05 --> Controller Class Initialized
DEBUG - 2011-09-13 15:50:05 --> Model Class Initialized
DEBUG - 2011-09-13 15:50:05 --> Model Class Initialized
DEBUG - 2011-09-13 15:50:05 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-13 15:50:05 --> Database Driver Class Initialized
DEBUG - 2011-09-13 15:50:06 --> Final output sent to browser
DEBUG - 2011-09-13 15:50:06 --> Total execution time: 0.6542
DEBUG - 2011-09-13 15:51:31 --> Config Class Initialized
DEBUG - 2011-09-13 15:51:31 --> Hooks Class Initialized
DEBUG - 2011-09-13 15:51:31 --> Utf8 Class Initialized
DEBUG - 2011-09-13 15:51:31 --> UTF-8 Support Enabled
DEBUG - 2011-09-13 15:51:31 --> URI Class Initialized
DEBUG - 2011-09-13 15:51:31 --> Router Class Initialized
DEBUG - 2011-09-13 15:51:31 --> Output Class Initialized
DEBUG - 2011-09-13 15:51:31 --> Input Class Initialized
DEBUG - 2011-09-13 15:51:31 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-13 15:51:31 --> Language Class Initialized
DEBUG - 2011-09-13 15:51:31 --> Loader Class Initialized
DEBUG - 2011-09-13 15:51:31 --> Controller Class Initialized
ERROR - 2011-09-13 15:51:31 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-09-13 15:51:31 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-09-13 15:51:31 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-09-13 15:51:31 --> Model Class Initialized
DEBUG - 2011-09-13 15:51:31 --> Model Class Initialized
DEBUG - 2011-09-13 15:51:31 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-13 15:51:31 --> Database Driver Class Initialized
DEBUG - 2011-09-13 15:51:31 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-09-13 15:51:31 --> Helper loaded: url_helper
DEBUG - 2011-09-13 15:51:31 --> File loaded: application/views/common/header.php
DEBUG - 2011-09-13 15:51:31 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-09-13 15:51:31 --> File loaded: application/views/common/footer.php
DEBUG - 2011-09-13 15:51:31 --> File loaded: application/views/layout/main.php
DEBUG - 2011-09-13 15:51:31 --> Final output sent to browser
DEBUG - 2011-09-13 15:51:31 --> Total execution time: 0.0814
DEBUG - 2011-09-13 15:51:34 --> Config Class Initialized
DEBUG - 2011-09-13 15:51:34 --> Hooks Class Initialized
DEBUG - 2011-09-13 15:51:34 --> Utf8 Class Initialized
DEBUG - 2011-09-13 15:51:34 --> UTF-8 Support Enabled
DEBUG - 2011-09-13 15:51:34 --> URI Class Initialized
DEBUG - 2011-09-13 15:51:34 --> Router Class Initialized
DEBUG - 2011-09-13 15:51:34 --> Output Class Initialized
DEBUG - 2011-09-13 15:51:34 --> Input Class Initialized
DEBUG - 2011-09-13 15:51:34 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-13 15:51:34 --> Language Class Initialized
DEBUG - 2011-09-13 15:51:34 --> Loader Class Initialized
DEBUG - 2011-09-13 15:51:34 --> Controller Class Initialized
DEBUG - 2011-09-13 15:51:34 --> Model Class Initialized
DEBUG - 2011-09-13 15:51:34 --> Model Class Initialized
DEBUG - 2011-09-13 15:51:34 --> Model Class Initialized
DEBUG - 2011-09-13 15:51:34 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-13 15:51:34 --> Database Driver Class Initialized
DEBUG - 2011-09-13 15:51:34 --> File loaded: application/views/table/main.php
DEBUG - 2011-09-13 15:51:34 --> Helper loaded: url_helper
DEBUG - 2011-09-13 15:51:34 --> File loaded: application/views/common/header.php
DEBUG - 2011-09-13 15:51:34 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-09-13 15:51:34 --> File loaded: application/views/common/footer.php
DEBUG - 2011-09-13 15:51:34 --> File loaded: application/views/layout/main.php
DEBUG - 2011-09-13 15:51:34 --> Final output sent to browser
DEBUG - 2011-09-13 15:51:34 --> Total execution time: 0.0485
DEBUG - 2011-09-13 15:51:47 --> Config Class Initialized
DEBUG - 2011-09-13 15:51:47 --> Hooks Class Initialized
DEBUG - 2011-09-13 15:51:47 --> Utf8 Class Initialized
DEBUG - 2011-09-13 15:51:47 --> UTF-8 Support Enabled
DEBUG - 2011-09-13 15:51:47 --> URI Class Initialized
DEBUG - 2011-09-13 15:51:47 --> Router Class Initialized
DEBUG - 2011-09-13 15:51:47 --> Output Class Initialized
DEBUG - 2011-09-13 15:51:47 --> Input Class Initialized
DEBUG - 2011-09-13 15:51:47 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-13 15:51:47 --> Language Class Initialized
DEBUG - 2011-09-13 15:51:47 --> Loader Class Initialized
DEBUG - 2011-09-13 15:51:47 --> Controller Class Initialized
DEBUG - 2011-09-13 15:51:47 --> Model Class Initialized
DEBUG - 2011-09-13 15:51:47 --> Model Class Initialized
DEBUG - 2011-09-13 15:51:47 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-13 15:51:47 --> Database Driver Class Initialized
DEBUG - 2011-09-13 15:51:47 --> Final output sent to browser
DEBUG - 2011-09-13 15:51:47 --> Total execution time: 0.5917
DEBUG - 2011-09-13 15:52:41 --> Config Class Initialized
DEBUG - 2011-09-13 15:52:41 --> Hooks Class Initialized
DEBUG - 2011-09-13 15:52:41 --> Utf8 Class Initialized
DEBUG - 2011-09-13 15:52:41 --> UTF-8 Support Enabled
DEBUG - 2011-09-13 15:52:41 --> URI Class Initialized
DEBUG - 2011-09-13 15:52:41 --> Router Class Initialized
ERROR - 2011-09-13 15:52:41 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-09-13 16:10:37 --> Config Class Initialized
DEBUG - 2011-09-13 16:10:37 --> Hooks Class Initialized
DEBUG - 2011-09-13 16:10:37 --> Utf8 Class Initialized
DEBUG - 2011-09-13 16:10:37 --> UTF-8 Support Enabled
DEBUG - 2011-09-13 16:10:37 --> URI Class Initialized
DEBUG - 2011-09-13 16:10:37 --> Router Class Initialized
DEBUG - 2011-09-13 16:10:37 --> Output Class Initialized
DEBUG - 2011-09-13 16:10:37 --> Input Class Initialized
DEBUG - 2011-09-13 16:10:37 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-13 16:10:37 --> Language Class Initialized
DEBUG - 2011-09-13 16:10:37 --> Loader Class Initialized
DEBUG - 2011-09-13 16:10:37 --> Controller Class Initialized
ERROR - 2011-09-13 16:10:37 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-09-13 16:10:37 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-09-13 16:10:37 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-09-13 16:10:37 --> Model Class Initialized
DEBUG - 2011-09-13 16:10:37 --> Model Class Initialized
DEBUG - 2011-09-13 16:10:37 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-13 16:10:37 --> Database Driver Class Initialized
DEBUG - 2011-09-13 16:10:37 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-09-13 16:10:37 --> Helper loaded: url_helper
DEBUG - 2011-09-13 16:10:37 --> File loaded: application/views/common/header.php
DEBUG - 2011-09-13 16:10:37 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-09-13 16:10:37 --> File loaded: application/views/common/footer.php
DEBUG - 2011-09-13 16:10:37 --> File loaded: application/views/layout/main.php
DEBUG - 2011-09-13 16:10:37 --> Final output sent to browser
DEBUG - 2011-09-13 16:10:37 --> Total execution time: 0.0319
DEBUG - 2011-09-13 16:10:38 --> Config Class Initialized
DEBUG - 2011-09-13 16:10:38 --> Hooks Class Initialized
DEBUG - 2011-09-13 16:10:38 --> Utf8 Class Initialized
DEBUG - 2011-09-13 16:10:38 --> UTF-8 Support Enabled
DEBUG - 2011-09-13 16:10:38 --> URI Class Initialized
DEBUG - 2011-09-13 16:10:38 --> Router Class Initialized
DEBUG - 2011-09-13 16:10:38 --> Output Class Initialized
DEBUG - 2011-09-13 16:10:38 --> Input Class Initialized
DEBUG - 2011-09-13 16:10:38 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-13 16:10:38 --> Language Class Initialized
DEBUG - 2011-09-13 16:10:38 --> Loader Class Initialized
DEBUG - 2011-09-13 16:10:38 --> Controller Class Initialized
DEBUG - 2011-09-13 16:10:38 --> Model Class Initialized
DEBUG - 2011-09-13 16:10:38 --> Model Class Initialized
DEBUG - 2011-09-13 16:10:38 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-13 16:10:38 --> Database Driver Class Initialized
DEBUG - 2011-09-13 16:10:38 --> Final output sent to browser
DEBUG - 2011-09-13 16:10:38 --> Total execution time: 0.5947
DEBUG - 2011-09-13 16:10:41 --> Config Class Initialized
DEBUG - 2011-09-13 16:10:41 --> Hooks Class Initialized
DEBUG - 2011-09-13 16:10:41 --> Utf8 Class Initialized
DEBUG - 2011-09-13 16:10:41 --> UTF-8 Support Enabled
DEBUG - 2011-09-13 16:10:41 --> URI Class Initialized
DEBUG - 2011-09-13 16:10:41 --> Router Class Initialized
ERROR - 2011-09-13 16:10:41 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-09-13 16:10:42 --> Config Class Initialized
DEBUG - 2011-09-13 16:10:42 --> Hooks Class Initialized
DEBUG - 2011-09-13 16:10:42 --> Utf8 Class Initialized
DEBUG - 2011-09-13 16:10:42 --> UTF-8 Support Enabled
DEBUG - 2011-09-13 16:10:42 --> URI Class Initialized
DEBUG - 2011-09-13 16:10:42 --> Router Class Initialized
ERROR - 2011-09-13 16:10:42 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-09-13 16:38:39 --> Config Class Initialized
DEBUG - 2011-09-13 16:38:39 --> Hooks Class Initialized
DEBUG - 2011-09-13 16:38:39 --> Utf8 Class Initialized
DEBUG - 2011-09-13 16:38:39 --> UTF-8 Support Enabled
DEBUG - 2011-09-13 16:38:39 --> URI Class Initialized
DEBUG - 2011-09-13 16:38:39 --> Router Class Initialized
DEBUG - 2011-09-13 16:38:39 --> Output Class Initialized
DEBUG - 2011-09-13 16:38:39 --> Input Class Initialized
DEBUG - 2011-09-13 16:38:39 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-13 16:38:39 --> Language Class Initialized
DEBUG - 2011-09-13 16:38:39 --> Loader Class Initialized
DEBUG - 2011-09-13 16:38:39 --> Controller Class Initialized
ERROR - 2011-09-13 16:38:39 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-09-13 16:38:39 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-09-13 16:38:39 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-09-13 16:38:39 --> Model Class Initialized
DEBUG - 2011-09-13 16:38:39 --> Model Class Initialized
DEBUG - 2011-09-13 16:38:39 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-13 16:38:39 --> Database Driver Class Initialized
DEBUG - 2011-09-13 16:38:39 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-09-13 16:38:39 --> Helper loaded: url_helper
DEBUG - 2011-09-13 16:38:39 --> File loaded: application/views/common/header.php
DEBUG - 2011-09-13 16:38:39 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-09-13 16:38:39 --> File loaded: application/views/common/footer.php
DEBUG - 2011-09-13 16:38:39 --> File loaded: application/views/layout/main.php
DEBUG - 2011-09-13 16:38:39 --> Final output sent to browser
DEBUG - 2011-09-13 16:38:39 --> Total execution time: 0.4269
DEBUG - 2011-09-13 16:38:40 --> Config Class Initialized
DEBUG - 2011-09-13 16:38:40 --> Hooks Class Initialized
DEBUG - 2011-09-13 16:38:40 --> Utf8 Class Initialized
DEBUG - 2011-09-13 16:38:40 --> UTF-8 Support Enabled
DEBUG - 2011-09-13 16:38:40 --> URI Class Initialized
DEBUG - 2011-09-13 16:38:40 --> Router Class Initialized
DEBUG - 2011-09-13 16:38:40 --> Output Class Initialized
DEBUG - 2011-09-13 16:38:40 --> Input Class Initialized
DEBUG - 2011-09-13 16:38:40 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-13 16:38:40 --> Language Class Initialized
DEBUG - 2011-09-13 16:38:40 --> Loader Class Initialized
DEBUG - 2011-09-13 16:38:40 --> Controller Class Initialized
DEBUG - 2011-09-13 16:38:40 --> Model Class Initialized
DEBUG - 2011-09-13 16:38:40 --> Model Class Initialized
DEBUG - 2011-09-13 16:38:40 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-13 16:38:40 --> Database Driver Class Initialized
DEBUG - 2011-09-13 16:38:40 --> Final output sent to browser
DEBUG - 2011-09-13 16:38:40 --> Total execution time: 0.6916
DEBUG - 2011-09-13 16:38:42 --> Config Class Initialized
DEBUG - 2011-09-13 16:38:42 --> Hooks Class Initialized
DEBUG - 2011-09-13 16:38:42 --> Utf8 Class Initialized
DEBUG - 2011-09-13 16:38:42 --> UTF-8 Support Enabled
DEBUG - 2011-09-13 16:38:42 --> URI Class Initialized
DEBUG - 2011-09-13 16:38:42 --> Router Class Initialized
ERROR - 2011-09-13 16:38:42 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-09-13 16:38:42 --> Config Class Initialized
DEBUG - 2011-09-13 16:38:42 --> Hooks Class Initialized
DEBUG - 2011-09-13 16:38:42 --> Utf8 Class Initialized
DEBUG - 2011-09-13 16:38:42 --> UTF-8 Support Enabled
DEBUG - 2011-09-13 16:38:42 --> URI Class Initialized
DEBUG - 2011-09-13 16:38:42 --> Router Class Initialized
ERROR - 2011-09-13 16:38:42 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-09-13 16:38:52 --> Config Class Initialized
DEBUG - 2011-09-13 16:38:52 --> Hooks Class Initialized
DEBUG - 2011-09-13 16:38:52 --> Utf8 Class Initialized
DEBUG - 2011-09-13 16:38:52 --> UTF-8 Support Enabled
DEBUG - 2011-09-13 16:38:52 --> URI Class Initialized
DEBUG - 2011-09-13 16:38:52 --> Router Class Initialized
DEBUG - 2011-09-13 16:38:52 --> Output Class Initialized
DEBUG - 2011-09-13 16:38:52 --> Input Class Initialized
DEBUG - 2011-09-13 16:38:52 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-13 16:38:52 --> Language Class Initialized
DEBUG - 2011-09-13 16:38:52 --> Loader Class Initialized
DEBUG - 2011-09-13 16:38:52 --> Controller Class Initialized
ERROR - 2011-09-13 16:38:52 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-09-13 16:38:52 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-09-13 16:38:52 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-09-13 16:38:52 --> Model Class Initialized
DEBUG - 2011-09-13 16:38:52 --> Model Class Initialized
DEBUG - 2011-09-13 16:38:52 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-13 16:38:52 --> Database Driver Class Initialized
DEBUG - 2011-09-13 16:38:52 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-09-13 16:38:52 --> Helper loaded: url_helper
DEBUG - 2011-09-13 16:38:52 --> File loaded: application/views/common/header.php
DEBUG - 2011-09-13 16:38:52 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-09-13 16:38:52 --> File loaded: application/views/common/footer.php
DEBUG - 2011-09-13 16:38:52 --> File loaded: application/views/layout/main.php
DEBUG - 2011-09-13 16:38:52 --> Final output sent to browser
DEBUG - 2011-09-13 16:38:52 --> Total execution time: 0.0265
DEBUG - 2011-09-13 16:38:52 --> Config Class Initialized
DEBUG - 2011-09-13 16:38:52 --> Hooks Class Initialized
DEBUG - 2011-09-13 16:38:52 --> Utf8 Class Initialized
DEBUG - 2011-09-13 16:38:52 --> UTF-8 Support Enabled
DEBUG - 2011-09-13 16:38:52 --> URI Class Initialized
DEBUG - 2011-09-13 16:38:52 --> Router Class Initialized
DEBUG - 2011-09-13 16:38:52 --> Output Class Initialized
DEBUG - 2011-09-13 16:38:52 --> Input Class Initialized
DEBUG - 2011-09-13 16:38:52 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-13 16:38:52 --> Language Class Initialized
DEBUG - 2011-09-13 16:38:52 --> Loader Class Initialized
DEBUG - 2011-09-13 16:38:52 --> Controller Class Initialized
DEBUG - 2011-09-13 16:38:52 --> Model Class Initialized
DEBUG - 2011-09-13 16:38:52 --> Model Class Initialized
DEBUG - 2011-09-13 16:38:52 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-13 16:38:52 --> Database Driver Class Initialized
DEBUG - 2011-09-13 16:38:53 --> Final output sent to browser
DEBUG - 2011-09-13 16:38:53 --> Total execution time: 0.5345
DEBUG - 2011-09-13 16:38:59 --> Config Class Initialized
DEBUG - 2011-09-13 16:38:59 --> Hooks Class Initialized
DEBUG - 2011-09-13 16:38:59 --> Utf8 Class Initialized
DEBUG - 2011-09-13 16:38:59 --> UTF-8 Support Enabled
DEBUG - 2011-09-13 16:38:59 --> URI Class Initialized
DEBUG - 2011-09-13 16:38:59 --> Router Class Initialized
DEBUG - 2011-09-13 16:38:59 --> Output Class Initialized
DEBUG - 2011-09-13 16:38:59 --> Input Class Initialized
DEBUG - 2011-09-13 16:38:59 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-13 16:38:59 --> Language Class Initialized
DEBUG - 2011-09-13 16:38:59 --> Loader Class Initialized
DEBUG - 2011-09-13 16:38:59 --> Controller Class Initialized
ERROR - 2011-09-13 16:38:59 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-09-13 16:38:59 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-09-13 16:38:59 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-09-13 16:38:59 --> Model Class Initialized
DEBUG - 2011-09-13 16:38:59 --> Model Class Initialized
DEBUG - 2011-09-13 16:38:59 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-13 16:38:59 --> Database Driver Class Initialized
DEBUG - 2011-09-13 16:38:59 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-09-13 16:38:59 --> Helper loaded: url_helper
DEBUG - 2011-09-13 16:38:59 --> File loaded: application/views/common/header.php
DEBUG - 2011-09-13 16:38:59 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-09-13 16:38:59 --> File loaded: application/views/common/footer.php
DEBUG - 2011-09-13 16:38:59 --> File loaded: application/views/layout/main.php
DEBUG - 2011-09-13 16:38:59 --> Final output sent to browser
DEBUG - 2011-09-13 16:38:59 --> Total execution time: 0.0307
DEBUG - 2011-09-13 16:38:59 --> Config Class Initialized
DEBUG - 2011-09-13 16:38:59 --> Hooks Class Initialized
DEBUG - 2011-09-13 16:38:59 --> Utf8 Class Initialized
DEBUG - 2011-09-13 16:38:59 --> UTF-8 Support Enabled
DEBUG - 2011-09-13 16:38:59 --> URI Class Initialized
DEBUG - 2011-09-13 16:38:59 --> Router Class Initialized
DEBUG - 2011-09-13 16:38:59 --> Output Class Initialized
DEBUG - 2011-09-13 16:38:59 --> Input Class Initialized
DEBUG - 2011-09-13 16:38:59 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-13 16:38:59 --> Language Class Initialized
DEBUG - 2011-09-13 16:38:59 --> Loader Class Initialized
DEBUG - 2011-09-13 16:38:59 --> Controller Class Initialized
DEBUG - 2011-09-13 16:38:59 --> Model Class Initialized
DEBUG - 2011-09-13 16:38:59 --> Model Class Initialized
DEBUG - 2011-09-13 16:38:59 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-13 16:38:59 --> Database Driver Class Initialized
DEBUG - 2011-09-13 16:39:00 --> Final output sent to browser
DEBUG - 2011-09-13 16:39:00 --> Total execution time: 0.7494
DEBUG - 2011-09-13 16:39:26 --> Config Class Initialized
DEBUG - 2011-09-13 16:39:26 --> Hooks Class Initialized
DEBUG - 2011-09-13 16:39:26 --> Utf8 Class Initialized
DEBUG - 2011-09-13 16:39:26 --> UTF-8 Support Enabled
DEBUG - 2011-09-13 16:39:26 --> URI Class Initialized
DEBUG - 2011-09-13 16:39:26 --> Router Class Initialized
DEBUG - 2011-09-13 16:39:26 --> Output Class Initialized
DEBUG - 2011-09-13 16:39:26 --> Input Class Initialized
DEBUG - 2011-09-13 16:39:26 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-13 16:39:26 --> Language Class Initialized
DEBUG - 2011-09-13 16:39:26 --> Loader Class Initialized
DEBUG - 2011-09-13 16:39:26 --> Controller Class Initialized
ERROR - 2011-09-13 16:39:26 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-09-13 16:39:26 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-09-13 16:39:26 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-09-13 16:39:26 --> Model Class Initialized
DEBUG - 2011-09-13 16:39:26 --> Model Class Initialized
DEBUG - 2011-09-13 16:39:26 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-13 16:39:26 --> Database Driver Class Initialized
DEBUG - 2011-09-13 16:39:26 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-09-13 16:39:26 --> Helper loaded: url_helper
DEBUG - 2011-09-13 16:39:26 --> File loaded: application/views/common/header.php
DEBUG - 2011-09-13 16:39:26 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-09-13 16:39:26 --> File loaded: application/views/common/footer.php
DEBUG - 2011-09-13 16:39:26 --> File loaded: application/views/layout/main.php
DEBUG - 2011-09-13 16:39:26 --> Final output sent to browser
DEBUG - 2011-09-13 16:39:26 --> Total execution time: 0.0283
DEBUG - 2011-09-13 16:39:27 --> Config Class Initialized
DEBUG - 2011-09-13 16:39:27 --> Hooks Class Initialized
DEBUG - 2011-09-13 16:39:27 --> Utf8 Class Initialized
DEBUG - 2011-09-13 16:39:27 --> UTF-8 Support Enabled
DEBUG - 2011-09-13 16:39:27 --> URI Class Initialized
DEBUG - 2011-09-13 16:39:27 --> Router Class Initialized
DEBUG - 2011-09-13 16:39:27 --> Output Class Initialized
DEBUG - 2011-09-13 16:39:27 --> Input Class Initialized
DEBUG - 2011-09-13 16:39:27 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-13 16:39:27 --> Language Class Initialized
DEBUG - 2011-09-13 16:39:27 --> Loader Class Initialized
DEBUG - 2011-09-13 16:39:27 --> Controller Class Initialized
DEBUG - 2011-09-13 16:39:27 --> Model Class Initialized
DEBUG - 2011-09-13 16:39:27 --> Model Class Initialized
DEBUG - 2011-09-13 16:39:27 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-13 16:39:27 --> Database Driver Class Initialized
DEBUG - 2011-09-13 16:39:27 --> Final output sent to browser
DEBUG - 2011-09-13 16:39:27 --> Total execution time: 0.6373
DEBUG - 2011-09-13 16:39:36 --> Config Class Initialized
DEBUG - 2011-09-13 16:39:36 --> Hooks Class Initialized
DEBUG - 2011-09-13 16:39:36 --> Utf8 Class Initialized
DEBUG - 2011-09-13 16:39:36 --> UTF-8 Support Enabled
DEBUG - 2011-09-13 16:39:36 --> URI Class Initialized
DEBUG - 2011-09-13 16:39:36 --> Router Class Initialized
DEBUG - 2011-09-13 16:39:36 --> Output Class Initialized
DEBUG - 2011-09-13 16:39:36 --> Input Class Initialized
DEBUG - 2011-09-13 16:39:36 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-13 16:39:36 --> Language Class Initialized
DEBUG - 2011-09-13 16:39:36 --> Loader Class Initialized
DEBUG - 2011-09-13 16:39:36 --> Controller Class Initialized
ERROR - 2011-09-13 16:39:36 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-09-13 16:39:36 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-09-13 16:39:36 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-09-13 16:39:36 --> Model Class Initialized
DEBUG - 2011-09-13 16:39:36 --> Model Class Initialized
DEBUG - 2011-09-13 16:39:36 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-13 16:39:36 --> Database Driver Class Initialized
DEBUG - 2011-09-13 16:39:36 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-09-13 16:39:36 --> Helper loaded: url_helper
DEBUG - 2011-09-13 16:39:36 --> File loaded: application/views/common/header.php
DEBUG - 2011-09-13 16:39:36 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-09-13 16:39:36 --> File loaded: application/views/common/footer.php
DEBUG - 2011-09-13 16:39:36 --> File loaded: application/views/layout/main.php
DEBUG - 2011-09-13 16:39:36 --> Final output sent to browser
DEBUG - 2011-09-13 16:39:36 --> Total execution time: 0.1648
DEBUG - 2011-09-13 16:39:37 --> Config Class Initialized
DEBUG - 2011-09-13 16:39:37 --> Hooks Class Initialized
DEBUG - 2011-09-13 16:39:37 --> Utf8 Class Initialized
DEBUG - 2011-09-13 16:39:37 --> UTF-8 Support Enabled
DEBUG - 2011-09-13 16:39:37 --> URI Class Initialized
DEBUG - 2011-09-13 16:39:37 --> Router Class Initialized
DEBUG - 2011-09-13 16:39:37 --> Output Class Initialized
DEBUG - 2011-09-13 16:39:37 --> Input Class Initialized
DEBUG - 2011-09-13 16:39:37 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-13 16:39:37 --> Language Class Initialized
DEBUG - 2011-09-13 16:39:37 --> Loader Class Initialized
DEBUG - 2011-09-13 16:39:37 --> Controller Class Initialized
DEBUG - 2011-09-13 16:39:37 --> Model Class Initialized
DEBUG - 2011-09-13 16:39:37 --> Model Class Initialized
DEBUG - 2011-09-13 16:39:37 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-13 16:39:37 --> Database Driver Class Initialized
DEBUG - 2011-09-13 16:39:38 --> Final output sent to browser
DEBUG - 2011-09-13 16:39:38 --> Total execution time: 0.5135
DEBUG - 2011-09-13 16:40:12 --> Config Class Initialized
DEBUG - 2011-09-13 16:40:12 --> Hooks Class Initialized
DEBUG - 2011-09-13 16:40:12 --> Utf8 Class Initialized
DEBUG - 2011-09-13 16:40:12 --> UTF-8 Support Enabled
DEBUG - 2011-09-13 16:40:12 --> URI Class Initialized
DEBUG - 2011-09-13 16:40:12 --> Router Class Initialized
DEBUG - 2011-09-13 16:40:12 --> Output Class Initialized
DEBUG - 2011-09-13 16:40:12 --> Input Class Initialized
DEBUG - 2011-09-13 16:40:12 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-13 16:40:12 --> Language Class Initialized
DEBUG - 2011-09-13 16:40:12 --> Loader Class Initialized
DEBUG - 2011-09-13 16:40:12 --> Controller Class Initialized
ERROR - 2011-09-13 16:40:12 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-09-13 16:40:12 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-09-13 16:40:12 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-09-13 16:40:12 --> Model Class Initialized
DEBUG - 2011-09-13 16:40:12 --> Model Class Initialized
DEBUG - 2011-09-13 16:40:12 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-13 16:40:12 --> Database Driver Class Initialized
DEBUG - 2011-09-13 16:40:12 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-09-13 16:40:12 --> Helper loaded: url_helper
DEBUG - 2011-09-13 16:40:12 --> File loaded: application/views/common/header.php
DEBUG - 2011-09-13 16:40:12 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-09-13 16:40:12 --> File loaded: application/views/common/footer.php
DEBUG - 2011-09-13 16:40:12 --> File loaded: application/views/layout/main.php
DEBUG - 2011-09-13 16:40:12 --> Final output sent to browser
DEBUG - 2011-09-13 16:40:12 --> Total execution time: 0.0325
DEBUG - 2011-09-13 16:40:13 --> Config Class Initialized
DEBUG - 2011-09-13 16:40:13 --> Hooks Class Initialized
DEBUG - 2011-09-13 16:40:13 --> Utf8 Class Initialized
DEBUG - 2011-09-13 16:40:13 --> UTF-8 Support Enabled
DEBUG - 2011-09-13 16:40:13 --> URI Class Initialized
DEBUG - 2011-09-13 16:40:13 --> Router Class Initialized
DEBUG - 2011-09-13 16:40:13 --> Output Class Initialized
DEBUG - 2011-09-13 16:40:13 --> Input Class Initialized
DEBUG - 2011-09-13 16:40:13 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-13 16:40:13 --> Language Class Initialized
DEBUG - 2011-09-13 16:40:13 --> Loader Class Initialized
DEBUG - 2011-09-13 16:40:13 --> Controller Class Initialized
DEBUG - 2011-09-13 16:40:13 --> Model Class Initialized
DEBUG - 2011-09-13 16:40:13 --> Model Class Initialized
DEBUG - 2011-09-13 16:40:13 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-13 16:40:13 --> Database Driver Class Initialized
DEBUG - 2011-09-13 16:40:14 --> Final output sent to browser
DEBUG - 2011-09-13 16:40:14 --> Total execution time: 0.5169
DEBUG - 2011-09-13 16:40:30 --> Config Class Initialized
DEBUG - 2011-09-13 16:40:30 --> Hooks Class Initialized
DEBUG - 2011-09-13 16:40:30 --> Utf8 Class Initialized
DEBUG - 2011-09-13 16:40:30 --> UTF-8 Support Enabled
DEBUG - 2011-09-13 16:40:30 --> URI Class Initialized
DEBUG - 2011-09-13 16:40:30 --> Router Class Initialized
DEBUG - 2011-09-13 16:40:30 --> Output Class Initialized
DEBUG - 2011-09-13 16:40:30 --> Input Class Initialized
DEBUG - 2011-09-13 16:40:30 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-13 16:40:30 --> Language Class Initialized
DEBUG - 2011-09-13 16:40:30 --> Loader Class Initialized
DEBUG - 2011-09-13 16:40:30 --> Controller Class Initialized
ERROR - 2011-09-13 16:40:30 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-09-13 16:40:30 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-09-13 16:40:30 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-09-13 16:40:30 --> Model Class Initialized
DEBUG - 2011-09-13 16:40:30 --> Model Class Initialized
DEBUG - 2011-09-13 16:40:30 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-13 16:40:30 --> Database Driver Class Initialized
DEBUG - 2011-09-13 16:40:30 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-09-13 16:40:30 --> Helper loaded: url_helper
DEBUG - 2011-09-13 16:40:30 --> File loaded: application/views/common/header.php
DEBUG - 2011-09-13 16:40:30 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-09-13 16:40:30 --> File loaded: application/views/common/footer.php
DEBUG - 2011-09-13 16:40:30 --> File loaded: application/views/layout/main.php
DEBUG - 2011-09-13 16:40:30 --> Final output sent to browser
DEBUG - 2011-09-13 16:40:30 --> Total execution time: 0.0283
DEBUG - 2011-09-13 16:40:30 --> Config Class Initialized
DEBUG - 2011-09-13 16:40:30 --> Hooks Class Initialized
DEBUG - 2011-09-13 16:40:30 --> Utf8 Class Initialized
DEBUG - 2011-09-13 16:40:30 --> UTF-8 Support Enabled
DEBUG - 2011-09-13 16:40:30 --> URI Class Initialized
DEBUG - 2011-09-13 16:40:30 --> Router Class Initialized
DEBUG - 2011-09-13 16:40:30 --> Output Class Initialized
DEBUG - 2011-09-13 16:40:30 --> Input Class Initialized
DEBUG - 2011-09-13 16:40:30 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-13 16:40:30 --> Language Class Initialized
DEBUG - 2011-09-13 16:40:30 --> Loader Class Initialized
DEBUG - 2011-09-13 16:40:30 --> Controller Class Initialized
DEBUG - 2011-09-13 16:40:30 --> Model Class Initialized
DEBUG - 2011-09-13 16:40:30 --> Model Class Initialized
DEBUG - 2011-09-13 16:40:30 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-13 16:40:30 --> Database Driver Class Initialized
DEBUG - 2011-09-13 16:40:31 --> Final output sent to browser
DEBUG - 2011-09-13 16:40:31 --> Total execution time: 0.5206
DEBUG - 2011-09-13 16:40:46 --> Config Class Initialized
DEBUG - 2011-09-13 16:40:46 --> Hooks Class Initialized
DEBUG - 2011-09-13 16:40:46 --> Utf8 Class Initialized
DEBUG - 2011-09-13 16:40:46 --> UTF-8 Support Enabled
DEBUG - 2011-09-13 16:40:46 --> URI Class Initialized
DEBUG - 2011-09-13 16:40:46 --> Router Class Initialized
DEBUG - 2011-09-13 16:40:46 --> Output Class Initialized
DEBUG - 2011-09-13 16:40:46 --> Input Class Initialized
DEBUG - 2011-09-13 16:40:46 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-13 16:40:46 --> Language Class Initialized
DEBUG - 2011-09-13 16:40:46 --> Loader Class Initialized
DEBUG - 2011-09-13 16:40:46 --> Controller Class Initialized
ERROR - 2011-09-13 16:40:46 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-09-13 16:40:46 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-09-13 16:40:46 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-09-13 16:40:46 --> Model Class Initialized
DEBUG - 2011-09-13 16:40:46 --> Model Class Initialized
DEBUG - 2011-09-13 16:40:46 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-13 16:40:46 --> Database Driver Class Initialized
DEBUG - 2011-09-13 16:40:46 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-09-13 16:40:46 --> Helper loaded: url_helper
DEBUG - 2011-09-13 16:40:46 --> File loaded: application/views/common/header.php
DEBUG - 2011-09-13 16:40:46 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-09-13 16:40:46 --> File loaded: application/views/common/footer.php
DEBUG - 2011-09-13 16:40:46 --> File loaded: application/views/layout/main.php
DEBUG - 2011-09-13 16:40:46 --> Final output sent to browser
DEBUG - 2011-09-13 16:40:46 --> Total execution time: 0.0264
DEBUG - 2011-09-13 16:40:47 --> Config Class Initialized
DEBUG - 2011-09-13 16:40:47 --> Hooks Class Initialized
DEBUG - 2011-09-13 16:40:47 --> Utf8 Class Initialized
DEBUG - 2011-09-13 16:40:47 --> UTF-8 Support Enabled
DEBUG - 2011-09-13 16:40:47 --> URI Class Initialized
DEBUG - 2011-09-13 16:40:47 --> Router Class Initialized
DEBUG - 2011-09-13 16:40:47 --> Output Class Initialized
DEBUG - 2011-09-13 16:40:47 --> Input Class Initialized
DEBUG - 2011-09-13 16:40:47 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-13 16:40:47 --> Language Class Initialized
DEBUG - 2011-09-13 16:40:47 --> Loader Class Initialized
DEBUG - 2011-09-13 16:40:47 --> Controller Class Initialized
DEBUG - 2011-09-13 16:40:47 --> Model Class Initialized
DEBUG - 2011-09-13 16:40:47 --> Model Class Initialized
DEBUG - 2011-09-13 16:40:47 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-13 16:40:47 --> Database Driver Class Initialized
DEBUG - 2011-09-13 16:40:47 --> Final output sent to browser
DEBUG - 2011-09-13 16:40:47 --> Total execution time: 0.5207
DEBUG - 2011-09-13 16:40:58 --> Config Class Initialized
DEBUG - 2011-09-13 16:40:58 --> Hooks Class Initialized
DEBUG - 2011-09-13 16:40:58 --> Utf8 Class Initialized
DEBUG - 2011-09-13 16:40:58 --> UTF-8 Support Enabled
DEBUG - 2011-09-13 16:40:58 --> URI Class Initialized
DEBUG - 2011-09-13 16:40:58 --> Router Class Initialized
DEBUG - 2011-09-13 16:40:58 --> Output Class Initialized
DEBUG - 2011-09-13 16:40:58 --> Input Class Initialized
DEBUG - 2011-09-13 16:40:58 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-13 16:40:58 --> Language Class Initialized
DEBUG - 2011-09-13 16:40:58 --> Loader Class Initialized
DEBUG - 2011-09-13 16:40:58 --> Controller Class Initialized
ERROR - 2011-09-13 16:40:58 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-09-13 16:40:58 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-09-13 16:40:58 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-09-13 16:40:58 --> Model Class Initialized
DEBUG - 2011-09-13 16:40:58 --> Model Class Initialized
DEBUG - 2011-09-13 16:40:58 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-13 16:40:58 --> Database Driver Class Initialized
DEBUG - 2011-09-13 16:40:58 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-09-13 16:40:58 --> Helper loaded: url_helper
DEBUG - 2011-09-13 16:40:58 --> File loaded: application/views/common/header.php
DEBUG - 2011-09-13 16:40:58 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-09-13 16:40:58 --> File loaded: application/views/common/footer.php
DEBUG - 2011-09-13 16:40:58 --> File loaded: application/views/layout/main.php
DEBUG - 2011-09-13 16:40:58 --> Final output sent to browser
DEBUG - 2011-09-13 16:40:58 --> Total execution time: 0.0276
DEBUG - 2011-09-13 16:40:58 --> Config Class Initialized
DEBUG - 2011-09-13 16:40:58 --> Hooks Class Initialized
DEBUG - 2011-09-13 16:40:58 --> Utf8 Class Initialized
DEBUG - 2011-09-13 16:40:58 --> UTF-8 Support Enabled
DEBUG - 2011-09-13 16:40:58 --> URI Class Initialized
DEBUG - 2011-09-13 16:40:58 --> Router Class Initialized
DEBUG - 2011-09-13 16:40:58 --> Output Class Initialized
DEBUG - 2011-09-13 16:40:58 --> Input Class Initialized
DEBUG - 2011-09-13 16:40:58 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-13 16:40:58 --> Language Class Initialized
DEBUG - 2011-09-13 16:40:58 --> Loader Class Initialized
DEBUG - 2011-09-13 16:40:58 --> Controller Class Initialized
DEBUG - 2011-09-13 16:40:58 --> Model Class Initialized
DEBUG - 2011-09-13 16:40:58 --> Model Class Initialized
DEBUG - 2011-09-13 16:40:58 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-13 16:40:58 --> Database Driver Class Initialized
DEBUG - 2011-09-13 16:40:59 --> Final output sent to browser
DEBUG - 2011-09-13 16:40:59 --> Total execution time: 0.6312
DEBUG - 2011-09-13 16:41:13 --> Config Class Initialized
DEBUG - 2011-09-13 16:41:13 --> Hooks Class Initialized
DEBUG - 2011-09-13 16:41:13 --> Utf8 Class Initialized
DEBUG - 2011-09-13 16:41:13 --> UTF-8 Support Enabled
DEBUG - 2011-09-13 16:41:13 --> URI Class Initialized
DEBUG - 2011-09-13 16:41:13 --> Router Class Initialized
DEBUG - 2011-09-13 16:41:13 --> Output Class Initialized
DEBUG - 2011-09-13 16:41:13 --> Input Class Initialized
DEBUG - 2011-09-13 16:41:13 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-13 16:41:13 --> Language Class Initialized
DEBUG - 2011-09-13 16:41:13 --> Loader Class Initialized
DEBUG - 2011-09-13 16:41:13 --> Controller Class Initialized
ERROR - 2011-09-13 16:41:13 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-09-13 16:41:13 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-09-13 16:41:13 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-09-13 16:41:13 --> Model Class Initialized
DEBUG - 2011-09-13 16:41:13 --> Model Class Initialized
DEBUG - 2011-09-13 16:41:13 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-13 16:41:13 --> Database Driver Class Initialized
DEBUG - 2011-09-13 16:41:13 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-09-13 16:41:13 --> Helper loaded: url_helper
DEBUG - 2011-09-13 16:41:13 --> File loaded: application/views/common/header.php
DEBUG - 2011-09-13 16:41:13 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-09-13 16:41:13 --> File loaded: application/views/common/footer.php
DEBUG - 2011-09-13 16:41:13 --> File loaded: application/views/layout/main.php
DEBUG - 2011-09-13 16:41:13 --> Final output sent to browser
DEBUG - 2011-09-13 16:41:13 --> Total execution time: 0.0334
DEBUG - 2011-09-13 16:41:13 --> Config Class Initialized
DEBUG - 2011-09-13 16:41:13 --> Hooks Class Initialized
DEBUG - 2011-09-13 16:41:13 --> Utf8 Class Initialized
DEBUG - 2011-09-13 16:41:13 --> UTF-8 Support Enabled
DEBUG - 2011-09-13 16:41:13 --> URI Class Initialized
DEBUG - 2011-09-13 16:41:13 --> Router Class Initialized
DEBUG - 2011-09-13 16:41:13 --> Output Class Initialized
DEBUG - 2011-09-13 16:41:13 --> Input Class Initialized
DEBUG - 2011-09-13 16:41:13 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-13 16:41:13 --> Language Class Initialized
DEBUG - 2011-09-13 16:41:13 --> Loader Class Initialized
DEBUG - 2011-09-13 16:41:13 --> Controller Class Initialized
DEBUG - 2011-09-13 16:41:13 --> Model Class Initialized
DEBUG - 2011-09-13 16:41:13 --> Model Class Initialized
DEBUG - 2011-09-13 16:41:13 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-13 16:41:13 --> Database Driver Class Initialized
DEBUG - 2011-09-13 16:41:14 --> Final output sent to browser
DEBUG - 2011-09-13 16:41:14 --> Total execution time: 0.5448
DEBUG - 2011-09-13 16:41:28 --> Config Class Initialized
DEBUG - 2011-09-13 16:41:28 --> Hooks Class Initialized
DEBUG - 2011-09-13 16:41:28 --> Utf8 Class Initialized
DEBUG - 2011-09-13 16:41:28 --> UTF-8 Support Enabled
DEBUG - 2011-09-13 16:41:28 --> URI Class Initialized
DEBUG - 2011-09-13 16:41:28 --> Router Class Initialized
DEBUG - 2011-09-13 16:41:28 --> Output Class Initialized
DEBUG - 2011-09-13 16:41:28 --> Input Class Initialized
DEBUG - 2011-09-13 16:41:28 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-13 16:41:28 --> Language Class Initialized
DEBUG - 2011-09-13 16:41:28 --> Loader Class Initialized
DEBUG - 2011-09-13 16:41:28 --> Controller Class Initialized
ERROR - 2011-09-13 16:41:28 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-09-13 16:41:28 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-09-13 16:41:28 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-09-13 16:41:28 --> Model Class Initialized
DEBUG - 2011-09-13 16:41:28 --> Model Class Initialized
DEBUG - 2011-09-13 16:41:28 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-13 16:41:28 --> Database Driver Class Initialized
DEBUG - 2011-09-13 16:41:28 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-09-13 16:41:28 --> Helper loaded: url_helper
DEBUG - 2011-09-13 16:41:28 --> File loaded: application/views/common/header.php
DEBUG - 2011-09-13 16:41:28 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-09-13 16:41:28 --> File loaded: application/views/common/footer.php
DEBUG - 2011-09-13 16:41:28 --> File loaded: application/views/layout/main.php
DEBUG - 2011-09-13 16:41:28 --> Final output sent to browser
DEBUG - 2011-09-13 16:41:28 --> Total execution time: 0.0306
DEBUG - 2011-09-13 16:41:28 --> Config Class Initialized
DEBUG - 2011-09-13 16:41:28 --> Hooks Class Initialized
DEBUG - 2011-09-13 16:41:28 --> Utf8 Class Initialized
DEBUG - 2011-09-13 16:41:28 --> UTF-8 Support Enabled
DEBUG - 2011-09-13 16:41:28 --> URI Class Initialized
DEBUG - 2011-09-13 16:41:28 --> Router Class Initialized
DEBUG - 2011-09-13 16:41:28 --> Output Class Initialized
DEBUG - 2011-09-13 16:41:28 --> Input Class Initialized
DEBUG - 2011-09-13 16:41:28 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-13 16:41:28 --> Language Class Initialized
DEBUG - 2011-09-13 16:41:28 --> Loader Class Initialized
DEBUG - 2011-09-13 16:41:28 --> Controller Class Initialized
DEBUG - 2011-09-13 16:41:28 --> Model Class Initialized
DEBUG - 2011-09-13 16:41:28 --> Model Class Initialized
DEBUG - 2011-09-13 16:41:28 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-13 16:41:28 --> Database Driver Class Initialized
DEBUG - 2011-09-13 16:41:28 --> Final output sent to browser
DEBUG - 2011-09-13 16:41:28 --> Total execution time: 0.6114
DEBUG - 2011-09-13 16:41:34 --> Config Class Initialized
DEBUG - 2011-09-13 16:41:34 --> Hooks Class Initialized
DEBUG - 2011-09-13 16:41:34 --> Utf8 Class Initialized
DEBUG - 2011-09-13 16:41:34 --> UTF-8 Support Enabled
DEBUG - 2011-09-13 16:41:34 --> URI Class Initialized
DEBUG - 2011-09-13 16:41:34 --> Router Class Initialized
DEBUG - 2011-09-13 16:41:34 --> Output Class Initialized
DEBUG - 2011-09-13 16:41:34 --> Input Class Initialized
DEBUG - 2011-09-13 16:41:34 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-13 16:41:34 --> Language Class Initialized
DEBUG - 2011-09-13 16:41:34 --> Loader Class Initialized
DEBUG - 2011-09-13 16:41:34 --> Controller Class Initialized
ERROR - 2011-09-13 16:41:34 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-09-13 16:41:34 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-09-13 16:41:34 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-09-13 16:41:34 --> Model Class Initialized
DEBUG - 2011-09-13 16:41:34 --> Model Class Initialized
DEBUG - 2011-09-13 16:41:34 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-13 16:41:34 --> Database Driver Class Initialized
DEBUG - 2011-09-13 16:41:34 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-09-13 16:41:34 --> Helper loaded: url_helper
DEBUG - 2011-09-13 16:41:34 --> File loaded: application/views/common/header.php
DEBUG - 2011-09-13 16:41:34 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-09-13 16:41:34 --> File loaded: application/views/common/footer.php
DEBUG - 2011-09-13 16:41:34 --> File loaded: application/views/layout/main.php
DEBUG - 2011-09-13 16:41:34 --> Final output sent to browser
DEBUG - 2011-09-13 16:41:34 --> Total execution time: 0.0322
DEBUG - 2011-09-13 16:41:35 --> Config Class Initialized
DEBUG - 2011-09-13 16:41:35 --> Hooks Class Initialized
DEBUG - 2011-09-13 16:41:35 --> Utf8 Class Initialized
DEBUG - 2011-09-13 16:41:35 --> UTF-8 Support Enabled
DEBUG - 2011-09-13 16:41:35 --> URI Class Initialized
DEBUG - 2011-09-13 16:41:35 --> Router Class Initialized
DEBUG - 2011-09-13 16:41:35 --> Output Class Initialized
DEBUG - 2011-09-13 16:41:35 --> Input Class Initialized
DEBUG - 2011-09-13 16:41:35 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-13 16:41:35 --> Language Class Initialized
DEBUG - 2011-09-13 16:41:35 --> Loader Class Initialized
DEBUG - 2011-09-13 16:41:35 --> Controller Class Initialized
DEBUG - 2011-09-13 16:41:35 --> Model Class Initialized
DEBUG - 2011-09-13 16:41:35 --> Model Class Initialized
DEBUG - 2011-09-13 16:41:35 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-13 16:41:35 --> Database Driver Class Initialized
DEBUG - 2011-09-13 16:41:35 --> Final output sent to browser
DEBUG - 2011-09-13 16:41:35 --> Total execution time: 0.4825
DEBUG - 2011-09-13 16:41:40 --> Config Class Initialized
DEBUG - 2011-09-13 16:41:40 --> Hooks Class Initialized
DEBUG - 2011-09-13 16:41:40 --> Utf8 Class Initialized
DEBUG - 2011-09-13 16:41:40 --> UTF-8 Support Enabled
DEBUG - 2011-09-13 16:41:40 --> URI Class Initialized
DEBUG - 2011-09-13 16:41:40 --> Router Class Initialized
DEBUG - 2011-09-13 16:41:40 --> Output Class Initialized
DEBUG - 2011-09-13 16:41:40 --> Input Class Initialized
DEBUG - 2011-09-13 16:41:40 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-13 16:41:40 --> Language Class Initialized
DEBUG - 2011-09-13 16:41:40 --> Loader Class Initialized
DEBUG - 2011-09-13 16:41:40 --> Controller Class Initialized
ERROR - 2011-09-13 16:41:40 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-09-13 16:41:40 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-09-13 16:41:40 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-09-13 16:41:40 --> Model Class Initialized
DEBUG - 2011-09-13 16:41:40 --> Model Class Initialized
DEBUG - 2011-09-13 16:41:40 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-13 16:41:40 --> Database Driver Class Initialized
DEBUG - 2011-09-13 16:41:40 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-09-13 16:41:40 --> Helper loaded: url_helper
DEBUG - 2011-09-13 16:41:40 --> File loaded: application/views/common/header.php
DEBUG - 2011-09-13 16:41:40 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-09-13 16:41:40 --> File loaded: application/views/common/footer.php
DEBUG - 2011-09-13 16:41:40 --> File loaded: application/views/layout/main.php
DEBUG - 2011-09-13 16:41:40 --> Final output sent to browser
DEBUG - 2011-09-13 16:41:40 --> Total execution time: 0.0265
DEBUG - 2011-09-13 16:41:40 --> Config Class Initialized
DEBUG - 2011-09-13 16:41:40 --> Hooks Class Initialized
DEBUG - 2011-09-13 16:41:40 --> Utf8 Class Initialized
DEBUG - 2011-09-13 16:41:40 --> UTF-8 Support Enabled
DEBUG - 2011-09-13 16:41:40 --> URI Class Initialized
DEBUG - 2011-09-13 16:41:40 --> Router Class Initialized
DEBUG - 2011-09-13 16:41:40 --> Output Class Initialized
DEBUG - 2011-09-13 16:41:40 --> Input Class Initialized
DEBUG - 2011-09-13 16:41:40 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-13 16:41:40 --> Language Class Initialized
DEBUG - 2011-09-13 16:41:40 --> Loader Class Initialized
DEBUG - 2011-09-13 16:41:40 --> Controller Class Initialized
DEBUG - 2011-09-13 16:41:40 --> Model Class Initialized
DEBUG - 2011-09-13 16:41:40 --> Model Class Initialized
DEBUG - 2011-09-13 16:41:40 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-13 16:41:40 --> Database Driver Class Initialized
DEBUG - 2011-09-13 16:41:41 --> Final output sent to browser
DEBUG - 2011-09-13 16:41:41 --> Total execution time: 0.5902
DEBUG - 2011-09-13 16:41:50 --> Config Class Initialized
DEBUG - 2011-09-13 16:41:50 --> Hooks Class Initialized
DEBUG - 2011-09-13 16:41:50 --> Utf8 Class Initialized
DEBUG - 2011-09-13 16:41:50 --> UTF-8 Support Enabled
DEBUG - 2011-09-13 16:41:50 --> URI Class Initialized
DEBUG - 2011-09-13 16:41:50 --> Router Class Initialized
DEBUG - 2011-09-13 16:41:50 --> Output Class Initialized
DEBUG - 2011-09-13 16:41:50 --> Input Class Initialized
DEBUG - 2011-09-13 16:41:50 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-13 16:41:50 --> Language Class Initialized
DEBUG - 2011-09-13 16:41:50 --> Loader Class Initialized
DEBUG - 2011-09-13 16:41:50 --> Controller Class Initialized
ERROR - 2011-09-13 16:41:50 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-09-13 16:41:50 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-09-13 16:41:50 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-09-13 16:41:50 --> Model Class Initialized
DEBUG - 2011-09-13 16:41:50 --> Model Class Initialized
DEBUG - 2011-09-13 16:41:50 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-13 16:41:50 --> Database Driver Class Initialized
DEBUG - 2011-09-13 16:41:50 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-09-13 16:41:50 --> Helper loaded: url_helper
DEBUG - 2011-09-13 16:41:50 --> File loaded: application/views/common/header.php
DEBUG - 2011-09-13 16:41:50 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-09-13 16:41:50 --> File loaded: application/views/common/footer.php
DEBUG - 2011-09-13 16:41:50 --> File loaded: application/views/layout/main.php
DEBUG - 2011-09-13 16:41:50 --> Final output sent to browser
DEBUG - 2011-09-13 16:41:50 --> Total execution time: 0.0886
DEBUG - 2011-09-13 16:41:51 --> Config Class Initialized
DEBUG - 2011-09-13 16:41:51 --> Hooks Class Initialized
DEBUG - 2011-09-13 16:41:51 --> Utf8 Class Initialized
DEBUG - 2011-09-13 16:41:51 --> UTF-8 Support Enabled
DEBUG - 2011-09-13 16:41:51 --> URI Class Initialized
DEBUG - 2011-09-13 16:41:51 --> Router Class Initialized
DEBUG - 2011-09-13 16:41:51 --> Output Class Initialized
DEBUG - 2011-09-13 16:41:51 --> Input Class Initialized
DEBUG - 2011-09-13 16:41:51 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-13 16:41:51 --> Language Class Initialized
DEBUG - 2011-09-13 16:41:51 --> Loader Class Initialized
DEBUG - 2011-09-13 16:41:51 --> Controller Class Initialized
DEBUG - 2011-09-13 16:41:51 --> Model Class Initialized
DEBUG - 2011-09-13 16:41:51 --> Model Class Initialized
DEBUG - 2011-09-13 16:41:51 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-13 16:41:51 --> Database Driver Class Initialized
DEBUG - 2011-09-13 16:41:52 --> Final output sent to browser
DEBUG - 2011-09-13 16:41:52 --> Total execution time: 0.7743
DEBUG - 2011-09-13 16:42:03 --> Config Class Initialized
DEBUG - 2011-09-13 16:42:03 --> Hooks Class Initialized
DEBUG - 2011-09-13 16:42:03 --> Utf8 Class Initialized
DEBUG - 2011-09-13 16:42:03 --> UTF-8 Support Enabled
DEBUG - 2011-09-13 16:42:03 --> URI Class Initialized
DEBUG - 2011-09-13 16:42:03 --> Router Class Initialized
DEBUG - 2011-09-13 16:42:03 --> Output Class Initialized
DEBUG - 2011-09-13 16:42:03 --> Input Class Initialized
DEBUG - 2011-09-13 16:42:03 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-13 16:42:03 --> Language Class Initialized
DEBUG - 2011-09-13 16:42:03 --> Loader Class Initialized
DEBUG - 2011-09-13 16:42:03 --> Controller Class Initialized
ERROR - 2011-09-13 16:42:03 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-09-13 16:42:03 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-09-13 16:42:03 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-09-13 16:42:03 --> Model Class Initialized
DEBUG - 2011-09-13 16:42:03 --> Model Class Initialized
DEBUG - 2011-09-13 16:42:03 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-13 16:42:03 --> Database Driver Class Initialized
DEBUG - 2011-09-13 16:42:03 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-09-13 16:42:03 --> Helper loaded: url_helper
DEBUG - 2011-09-13 16:42:03 --> File loaded: application/views/common/header.php
DEBUG - 2011-09-13 16:42:03 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-09-13 16:42:03 --> File loaded: application/views/common/footer.php
DEBUG - 2011-09-13 16:42:03 --> File loaded: application/views/layout/main.php
DEBUG - 2011-09-13 16:42:03 --> Final output sent to browser
DEBUG - 2011-09-13 16:42:03 --> Total execution time: 0.0294
DEBUG - 2011-09-13 16:42:04 --> Config Class Initialized
DEBUG - 2011-09-13 16:42:04 --> Hooks Class Initialized
DEBUG - 2011-09-13 16:42:04 --> Utf8 Class Initialized
DEBUG - 2011-09-13 16:42:04 --> UTF-8 Support Enabled
DEBUG - 2011-09-13 16:42:04 --> URI Class Initialized
DEBUG - 2011-09-13 16:42:04 --> Router Class Initialized
DEBUG - 2011-09-13 16:42:04 --> Output Class Initialized
DEBUG - 2011-09-13 16:42:04 --> Input Class Initialized
DEBUG - 2011-09-13 16:42:04 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-13 16:42:04 --> Language Class Initialized
DEBUG - 2011-09-13 16:42:04 --> Loader Class Initialized
DEBUG - 2011-09-13 16:42:04 --> Controller Class Initialized
DEBUG - 2011-09-13 16:42:04 --> Model Class Initialized
DEBUG - 2011-09-13 16:42:04 --> Model Class Initialized
DEBUG - 2011-09-13 16:42:04 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-13 16:42:04 --> Database Driver Class Initialized
DEBUG - 2011-09-13 16:42:04 --> Final output sent to browser
DEBUG - 2011-09-13 16:42:04 --> Total execution time: 0.5440
DEBUG - 2011-09-13 16:42:12 --> Config Class Initialized
DEBUG - 2011-09-13 16:42:12 --> Hooks Class Initialized
DEBUG - 2011-09-13 16:42:12 --> Utf8 Class Initialized
DEBUG - 2011-09-13 16:42:12 --> UTF-8 Support Enabled
DEBUG - 2011-09-13 16:42:12 --> URI Class Initialized
DEBUG - 2011-09-13 16:42:12 --> Router Class Initialized
DEBUG - 2011-09-13 16:42:12 --> Output Class Initialized
DEBUG - 2011-09-13 16:42:12 --> Input Class Initialized
DEBUG - 2011-09-13 16:42:12 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-13 16:42:12 --> Language Class Initialized
DEBUG - 2011-09-13 16:42:12 --> Loader Class Initialized
DEBUG - 2011-09-13 16:42:12 --> Controller Class Initialized
ERROR - 2011-09-13 16:42:12 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-09-13 16:42:12 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-09-13 16:42:12 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-09-13 16:42:12 --> Model Class Initialized
DEBUG - 2011-09-13 16:42:12 --> Model Class Initialized
DEBUG - 2011-09-13 16:42:12 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-13 16:42:12 --> Database Driver Class Initialized
DEBUG - 2011-09-13 16:42:12 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-09-13 16:42:12 --> Helper loaded: url_helper
DEBUG - 2011-09-13 16:42:12 --> File loaded: application/views/common/header.php
DEBUG - 2011-09-13 16:42:12 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-09-13 16:42:12 --> File loaded: application/views/common/footer.php
DEBUG - 2011-09-13 16:42:12 --> File loaded: application/views/layout/main.php
DEBUG - 2011-09-13 16:42:12 --> Final output sent to browser
DEBUG - 2011-09-13 16:42:12 --> Total execution time: 0.0287
DEBUG - 2011-09-13 16:42:13 --> Config Class Initialized
DEBUG - 2011-09-13 16:42:13 --> Hooks Class Initialized
DEBUG - 2011-09-13 16:42:13 --> Utf8 Class Initialized
DEBUG - 2011-09-13 16:42:13 --> UTF-8 Support Enabled
DEBUG - 2011-09-13 16:42:13 --> URI Class Initialized
DEBUG - 2011-09-13 16:42:13 --> Router Class Initialized
DEBUG - 2011-09-13 16:42:13 --> Output Class Initialized
DEBUG - 2011-09-13 16:42:13 --> Input Class Initialized
DEBUG - 2011-09-13 16:42:13 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-13 16:42:13 --> Language Class Initialized
DEBUG - 2011-09-13 16:42:13 --> Loader Class Initialized
DEBUG - 2011-09-13 16:42:13 --> Controller Class Initialized
DEBUG - 2011-09-13 16:42:13 --> Model Class Initialized
DEBUG - 2011-09-13 16:42:13 --> Model Class Initialized
DEBUG - 2011-09-13 16:42:13 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-13 16:42:13 --> Database Driver Class Initialized
DEBUG - 2011-09-13 16:42:13 --> Final output sent to browser
DEBUG - 2011-09-13 16:42:13 --> Total execution time: 0.4580
DEBUG - 2011-09-13 16:42:19 --> Config Class Initialized
DEBUG - 2011-09-13 16:42:19 --> Hooks Class Initialized
DEBUG - 2011-09-13 16:42:19 --> Utf8 Class Initialized
DEBUG - 2011-09-13 16:42:19 --> UTF-8 Support Enabled
DEBUG - 2011-09-13 16:42:19 --> URI Class Initialized
DEBUG - 2011-09-13 16:42:19 --> Router Class Initialized
DEBUG - 2011-09-13 16:42:19 --> Output Class Initialized
DEBUG - 2011-09-13 16:42:19 --> Input Class Initialized
DEBUG - 2011-09-13 16:42:19 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-13 16:42:19 --> Language Class Initialized
DEBUG - 2011-09-13 16:42:19 --> Loader Class Initialized
DEBUG - 2011-09-13 16:42:19 --> Controller Class Initialized
ERROR - 2011-09-13 16:42:19 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-09-13 16:42:19 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-09-13 16:42:19 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-09-13 16:42:19 --> Model Class Initialized
DEBUG - 2011-09-13 16:42:19 --> Model Class Initialized
DEBUG - 2011-09-13 16:42:19 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-13 16:42:19 --> Database Driver Class Initialized
DEBUG - 2011-09-13 16:42:19 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-09-13 16:42:19 --> Helper loaded: url_helper
DEBUG - 2011-09-13 16:42:19 --> File loaded: application/views/common/header.php
DEBUG - 2011-09-13 16:42:19 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-09-13 16:42:19 --> File loaded: application/views/common/footer.php
DEBUG - 2011-09-13 16:42:19 --> File loaded: application/views/layout/main.php
DEBUG - 2011-09-13 16:42:19 --> Final output sent to browser
DEBUG - 2011-09-13 16:42:19 --> Total execution time: 0.0355
DEBUG - 2011-09-13 16:42:19 --> Config Class Initialized
DEBUG - 2011-09-13 16:42:19 --> Hooks Class Initialized
DEBUG - 2011-09-13 16:42:19 --> Utf8 Class Initialized
DEBUG - 2011-09-13 16:42:19 --> UTF-8 Support Enabled
DEBUG - 2011-09-13 16:42:19 --> URI Class Initialized
DEBUG - 2011-09-13 16:42:19 --> Router Class Initialized
DEBUG - 2011-09-13 16:42:19 --> Output Class Initialized
DEBUG - 2011-09-13 16:42:19 --> Input Class Initialized
DEBUG - 2011-09-13 16:42:19 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-13 16:42:19 --> Language Class Initialized
DEBUG - 2011-09-13 16:42:19 --> Loader Class Initialized
DEBUG - 2011-09-13 16:42:19 --> Controller Class Initialized
DEBUG - 2011-09-13 16:42:19 --> Model Class Initialized
DEBUG - 2011-09-13 16:42:19 --> Model Class Initialized
DEBUG - 2011-09-13 16:42:19 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-13 16:42:19 --> Database Driver Class Initialized
DEBUG - 2011-09-13 16:42:20 --> Final output sent to browser
DEBUG - 2011-09-13 16:42:20 --> Total execution time: 0.5543
DEBUG - 2011-09-13 16:42:37 --> Config Class Initialized
DEBUG - 2011-09-13 16:42:37 --> Hooks Class Initialized
DEBUG - 2011-09-13 16:42:37 --> Utf8 Class Initialized
DEBUG - 2011-09-13 16:42:37 --> UTF-8 Support Enabled
DEBUG - 2011-09-13 16:42:37 --> URI Class Initialized
DEBUG - 2011-09-13 16:42:37 --> Router Class Initialized
DEBUG - 2011-09-13 16:42:37 --> Output Class Initialized
DEBUG - 2011-09-13 16:42:37 --> Input Class Initialized
DEBUG - 2011-09-13 16:42:37 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-13 16:42:37 --> Language Class Initialized
DEBUG - 2011-09-13 16:42:37 --> Loader Class Initialized
DEBUG - 2011-09-13 16:42:37 --> Controller Class Initialized
ERROR - 2011-09-13 16:42:37 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-09-13 16:42:37 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-09-13 16:42:37 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-09-13 16:42:37 --> Model Class Initialized
DEBUG - 2011-09-13 16:42:37 --> Model Class Initialized
DEBUG - 2011-09-13 16:42:37 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-13 16:42:37 --> Database Driver Class Initialized
DEBUG - 2011-09-13 16:42:37 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-09-13 16:42:37 --> Helper loaded: url_helper
DEBUG - 2011-09-13 16:42:37 --> File loaded: application/views/common/header.php
DEBUG - 2011-09-13 16:42:37 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-09-13 16:42:37 --> File loaded: application/views/common/footer.php
DEBUG - 2011-09-13 16:42:37 --> File loaded: application/views/layout/main.php
DEBUG - 2011-09-13 16:42:37 --> Final output sent to browser
DEBUG - 2011-09-13 16:42:37 --> Total execution time: 0.0311
DEBUG - 2011-09-13 16:42:38 --> Config Class Initialized
DEBUG - 2011-09-13 16:42:38 --> Hooks Class Initialized
DEBUG - 2011-09-13 16:42:38 --> Utf8 Class Initialized
DEBUG - 2011-09-13 16:42:38 --> UTF-8 Support Enabled
DEBUG - 2011-09-13 16:42:38 --> URI Class Initialized
DEBUG - 2011-09-13 16:42:38 --> Router Class Initialized
DEBUG - 2011-09-13 16:42:38 --> Output Class Initialized
DEBUG - 2011-09-13 16:42:38 --> Input Class Initialized
DEBUG - 2011-09-13 16:42:38 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-13 16:42:38 --> Language Class Initialized
DEBUG - 2011-09-13 16:42:38 --> Loader Class Initialized
DEBUG - 2011-09-13 16:42:38 --> Controller Class Initialized
DEBUG - 2011-09-13 16:42:38 --> Model Class Initialized
DEBUG - 2011-09-13 16:42:38 --> Model Class Initialized
DEBUG - 2011-09-13 16:42:38 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-13 16:42:38 --> Database Driver Class Initialized
DEBUG - 2011-09-13 16:42:38 --> Final output sent to browser
DEBUG - 2011-09-13 16:42:38 --> Total execution time: 0.5211
DEBUG - 2011-09-13 16:42:49 --> Config Class Initialized
DEBUG - 2011-09-13 16:42:49 --> Hooks Class Initialized
DEBUG - 2011-09-13 16:42:49 --> Utf8 Class Initialized
DEBUG - 2011-09-13 16:42:49 --> UTF-8 Support Enabled
DEBUG - 2011-09-13 16:42:49 --> URI Class Initialized
DEBUG - 2011-09-13 16:42:49 --> Router Class Initialized
DEBUG - 2011-09-13 16:42:49 --> Output Class Initialized
DEBUG - 2011-09-13 16:42:49 --> Input Class Initialized
DEBUG - 2011-09-13 16:42:49 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-13 16:42:49 --> Language Class Initialized
DEBUG - 2011-09-13 16:42:49 --> Loader Class Initialized
DEBUG - 2011-09-13 16:42:49 --> Controller Class Initialized
ERROR - 2011-09-13 16:42:49 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-09-13 16:42:49 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-09-13 16:42:49 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-09-13 16:42:49 --> Model Class Initialized
DEBUG - 2011-09-13 16:42:49 --> Model Class Initialized
DEBUG - 2011-09-13 16:42:49 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-13 16:42:49 --> Database Driver Class Initialized
DEBUG - 2011-09-13 16:42:49 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-09-13 16:42:49 --> Helper loaded: url_helper
DEBUG - 2011-09-13 16:42:49 --> File loaded: application/views/common/header.php
DEBUG - 2011-09-13 16:42:49 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-09-13 16:42:49 --> File loaded: application/views/common/footer.php
DEBUG - 2011-09-13 16:42:49 --> File loaded: application/views/layout/main.php
DEBUG - 2011-09-13 16:42:49 --> Final output sent to browser
DEBUG - 2011-09-13 16:42:49 --> Total execution time: 0.0355
DEBUG - 2011-09-13 16:42:49 --> Config Class Initialized
DEBUG - 2011-09-13 16:42:49 --> Hooks Class Initialized
DEBUG - 2011-09-13 16:42:49 --> Utf8 Class Initialized
DEBUG - 2011-09-13 16:42:49 --> UTF-8 Support Enabled
DEBUG - 2011-09-13 16:42:49 --> URI Class Initialized
DEBUG - 2011-09-13 16:42:49 --> Router Class Initialized
DEBUG - 2011-09-13 16:42:49 --> Output Class Initialized
DEBUG - 2011-09-13 16:42:49 --> Input Class Initialized
DEBUG - 2011-09-13 16:42:49 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-13 16:42:49 --> Language Class Initialized
DEBUG - 2011-09-13 16:42:49 --> Loader Class Initialized
DEBUG - 2011-09-13 16:42:49 --> Controller Class Initialized
DEBUG - 2011-09-13 16:42:49 --> Model Class Initialized
DEBUG - 2011-09-13 16:42:49 --> Model Class Initialized
DEBUG - 2011-09-13 16:42:49 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-13 16:42:49 --> Database Driver Class Initialized
DEBUG - 2011-09-13 16:42:50 --> Final output sent to browser
DEBUG - 2011-09-13 16:42:50 --> Total execution time: 0.5345
DEBUG - 2011-09-13 17:29:08 --> Config Class Initialized
DEBUG - 2011-09-13 17:29:08 --> Hooks Class Initialized
DEBUG - 2011-09-13 17:29:08 --> Utf8 Class Initialized
DEBUG - 2011-09-13 17:29:08 --> UTF-8 Support Enabled
DEBUG - 2011-09-13 17:29:08 --> URI Class Initialized
DEBUG - 2011-09-13 17:29:08 --> Router Class Initialized
DEBUG - 2011-09-13 17:29:08 --> Output Class Initialized
DEBUG - 2011-09-13 17:29:08 --> Input Class Initialized
DEBUG - 2011-09-13 17:29:08 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-13 17:29:08 --> Language Class Initialized
DEBUG - 2011-09-13 17:29:08 --> Loader Class Initialized
DEBUG - 2011-09-13 17:29:08 --> Controller Class Initialized
DEBUG - 2011-09-13 17:29:08 --> Model Class Initialized
DEBUG - 2011-09-13 17:29:08 --> Model Class Initialized
DEBUG - 2011-09-13 17:29:08 --> Model Class Initialized
DEBUG - 2011-09-13 17:29:08 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-13 17:29:08 --> Database Driver Class Initialized
DEBUG - 2011-09-13 17:29:08 --> File loaded: application/views/table/main.php
DEBUG - 2011-09-13 17:29:08 --> Helper loaded: url_helper
DEBUG - 2011-09-13 17:29:08 --> File loaded: application/views/common/header.php
DEBUG - 2011-09-13 17:29:08 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-09-13 17:29:08 --> File loaded: application/views/common/footer.php
DEBUG - 2011-09-13 17:29:08 --> File loaded: application/views/layout/main.php
DEBUG - 2011-09-13 17:29:08 --> Final output sent to browser
DEBUG - 2011-09-13 17:29:08 --> Total execution time: 0.3992
DEBUG - 2011-09-13 17:29:10 --> Config Class Initialized
DEBUG - 2011-09-13 17:29:10 --> Hooks Class Initialized
DEBUG - 2011-09-13 17:29:10 --> Utf8 Class Initialized
DEBUG - 2011-09-13 17:29:10 --> UTF-8 Support Enabled
DEBUG - 2011-09-13 17:29:10 --> URI Class Initialized
DEBUG - 2011-09-13 17:29:10 --> Router Class Initialized
ERROR - 2011-09-13 17:29:10 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-09-13 17:33:36 --> Config Class Initialized
DEBUG - 2011-09-13 17:33:36 --> Hooks Class Initialized
DEBUG - 2011-09-13 17:33:36 --> Utf8 Class Initialized
DEBUG - 2011-09-13 17:33:36 --> UTF-8 Support Enabled
DEBUG - 2011-09-13 17:33:36 --> URI Class Initialized
DEBUG - 2011-09-13 17:33:36 --> Router Class Initialized
DEBUG - 2011-09-13 17:33:36 --> Output Class Initialized
DEBUG - 2011-09-13 17:33:36 --> Input Class Initialized
DEBUG - 2011-09-13 17:33:36 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-13 17:33:36 --> Language Class Initialized
DEBUG - 2011-09-13 17:33:36 --> Loader Class Initialized
DEBUG - 2011-09-13 17:33:36 --> Controller Class Initialized
DEBUG - 2011-09-13 17:33:36 --> Model Class Initialized
DEBUG - 2011-09-13 17:33:36 --> Model Class Initialized
DEBUG - 2011-09-13 17:33:36 --> Model Class Initialized
DEBUG - 2011-09-13 17:33:36 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-13 17:33:36 --> Database Driver Class Initialized
DEBUG - 2011-09-13 17:33:36 --> File loaded: application/views/table/main.php
DEBUG - 2011-09-13 17:33:36 --> Helper loaded: url_helper
DEBUG - 2011-09-13 17:33:36 --> File loaded: application/views/common/header.php
DEBUG - 2011-09-13 17:33:36 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-09-13 17:33:36 --> File loaded: application/views/common/footer.php
DEBUG - 2011-09-13 17:33:36 --> File loaded: application/views/layout/main.php
DEBUG - 2011-09-13 17:33:36 --> Final output sent to browser
DEBUG - 2011-09-13 17:33:36 --> Total execution time: 0.0647
DEBUG - 2011-09-13 17:34:03 --> Config Class Initialized
DEBUG - 2011-09-13 17:34:03 --> Hooks Class Initialized
DEBUG - 2011-09-13 17:34:03 --> Utf8 Class Initialized
DEBUG - 2011-09-13 17:34:03 --> UTF-8 Support Enabled
DEBUG - 2011-09-13 17:34:03 --> URI Class Initialized
DEBUG - 2011-09-13 17:34:03 --> Router Class Initialized
DEBUG - 2011-09-13 17:34:03 --> Output Class Initialized
DEBUG - 2011-09-13 17:34:03 --> Input Class Initialized
DEBUG - 2011-09-13 17:34:03 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-13 17:34:03 --> Language Class Initialized
DEBUG - 2011-09-13 17:34:03 --> Loader Class Initialized
DEBUG - 2011-09-13 17:34:03 --> Controller Class Initialized
DEBUG - 2011-09-13 17:34:03 --> Model Class Initialized
DEBUG - 2011-09-13 17:34:03 --> Model Class Initialized
DEBUG - 2011-09-13 17:34:03 --> Model Class Initialized
DEBUG - 2011-09-13 17:34:03 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-13 17:34:03 --> Database Driver Class Initialized
DEBUG - 2011-09-13 17:34:03 --> File loaded: application/views/table/main.php
DEBUG - 2011-09-13 17:34:03 --> Helper loaded: url_helper
DEBUG - 2011-09-13 17:34:03 --> File loaded: application/views/common/header.php
DEBUG - 2011-09-13 17:34:03 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-09-13 17:34:03 --> File loaded: application/views/common/footer.php
DEBUG - 2011-09-13 17:34:03 --> File loaded: application/views/layout/main.php
DEBUG - 2011-09-13 17:34:03 --> Final output sent to browser
DEBUG - 2011-09-13 17:34:03 --> Total execution time: 0.0468
DEBUG - 2011-09-13 17:34:55 --> Config Class Initialized
DEBUG - 2011-09-13 17:34:55 --> Hooks Class Initialized
DEBUG - 2011-09-13 17:34:55 --> Utf8 Class Initialized
DEBUG - 2011-09-13 17:34:55 --> UTF-8 Support Enabled
DEBUG - 2011-09-13 17:34:55 --> URI Class Initialized
DEBUG - 2011-09-13 17:34:55 --> Router Class Initialized
DEBUG - 2011-09-13 17:34:55 --> Output Class Initialized
DEBUG - 2011-09-13 17:34:55 --> Input Class Initialized
DEBUG - 2011-09-13 17:34:55 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-13 17:34:55 --> Language Class Initialized
DEBUG - 2011-09-13 17:34:55 --> Loader Class Initialized
DEBUG - 2011-09-13 17:34:55 --> Controller Class Initialized
DEBUG - 2011-09-13 17:34:55 --> Model Class Initialized
DEBUG - 2011-09-13 17:34:55 --> Model Class Initialized
DEBUG - 2011-09-13 17:34:55 --> Model Class Initialized
DEBUG - 2011-09-13 17:34:55 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-13 17:34:55 --> Database Driver Class Initialized
DEBUG - 2011-09-13 17:34:55 --> File loaded: application/views/table/main.php
DEBUG - 2011-09-13 17:34:55 --> Helper loaded: url_helper
DEBUG - 2011-09-13 17:34:55 --> File loaded: application/views/common/header.php
DEBUG - 2011-09-13 17:34:55 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-09-13 17:34:55 --> File loaded: application/views/common/footer.php
DEBUG - 2011-09-13 17:34:55 --> File loaded: application/views/layout/main.php
DEBUG - 2011-09-13 17:34:55 --> Final output sent to browser
DEBUG - 2011-09-13 17:34:55 --> Total execution time: 0.0481
DEBUG - 2011-09-13 17:37:50 --> Config Class Initialized
DEBUG - 2011-09-13 17:37:50 --> Hooks Class Initialized
DEBUG - 2011-09-13 17:37:50 --> Utf8 Class Initialized
DEBUG - 2011-09-13 17:37:50 --> UTF-8 Support Enabled
DEBUG - 2011-09-13 17:37:50 --> URI Class Initialized
DEBUG - 2011-09-13 17:37:50 --> Router Class Initialized
DEBUG - 2011-09-13 17:37:50 --> Output Class Initialized
DEBUG - 2011-09-13 17:37:50 --> Input Class Initialized
DEBUG - 2011-09-13 17:37:50 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-13 17:37:50 --> Language Class Initialized
DEBUG - 2011-09-13 17:37:50 --> Loader Class Initialized
DEBUG - 2011-09-13 17:37:50 --> Controller Class Initialized
ERROR - 2011-09-13 17:37:50 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-09-13 17:37:50 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-09-13 17:37:50 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-09-13 17:37:50 --> Model Class Initialized
DEBUG - 2011-09-13 17:37:50 --> Model Class Initialized
DEBUG - 2011-09-13 17:37:50 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-13 17:37:50 --> Database Driver Class Initialized
DEBUG - 2011-09-13 17:37:50 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-09-13 17:37:50 --> Helper loaded: url_helper
DEBUG - 2011-09-13 17:37:50 --> File loaded: application/views/common/header.php
DEBUG - 2011-09-13 17:37:50 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-09-13 17:37:50 --> File loaded: application/views/common/footer.php
DEBUG - 2011-09-13 17:37:50 --> File loaded: application/views/layout/main.php
DEBUG - 2011-09-13 17:37:50 --> Final output sent to browser
DEBUG - 2011-09-13 17:37:50 --> Total execution time: 0.0296
DEBUG - 2011-09-13 17:37:51 --> Config Class Initialized
DEBUG - 2011-09-13 17:37:51 --> Hooks Class Initialized
DEBUG - 2011-09-13 17:37:51 --> Utf8 Class Initialized
DEBUG - 2011-09-13 17:37:51 --> UTF-8 Support Enabled
DEBUG - 2011-09-13 17:37:51 --> URI Class Initialized
DEBUG - 2011-09-13 17:37:51 --> Router Class Initialized
ERROR - 2011-09-13 17:37:51 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-09-13 17:37:51 --> Config Class Initialized
DEBUG - 2011-09-13 17:37:51 --> Hooks Class Initialized
DEBUG - 2011-09-13 17:37:51 --> Utf8 Class Initialized
DEBUG - 2011-09-13 17:37:51 --> UTF-8 Support Enabled
DEBUG - 2011-09-13 17:37:51 --> URI Class Initialized
DEBUG - 2011-09-13 17:37:51 --> Router Class Initialized
DEBUG - 2011-09-13 17:37:51 --> Output Class Initialized
DEBUG - 2011-09-13 17:37:51 --> Input Class Initialized
DEBUG - 2011-09-13 17:37:51 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-13 17:37:51 --> Language Class Initialized
DEBUG - 2011-09-13 17:37:51 --> Loader Class Initialized
DEBUG - 2011-09-13 17:37:51 --> Controller Class Initialized
DEBUG - 2011-09-13 17:37:51 --> Model Class Initialized
DEBUG - 2011-09-13 17:37:51 --> Model Class Initialized
DEBUG - 2011-09-13 17:37:51 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-13 17:37:51 --> Database Driver Class Initialized
DEBUG - 2011-09-13 17:37:52 --> Final output sent to browser
DEBUG - 2011-09-13 17:37:52 --> Total execution time: 0.6618
DEBUG - 2011-09-13 17:58:37 --> Config Class Initialized
DEBUG - 2011-09-13 17:58:37 --> Hooks Class Initialized
DEBUG - 2011-09-13 17:58:37 --> Utf8 Class Initialized
DEBUG - 2011-09-13 17:58:37 --> UTF-8 Support Enabled
DEBUG - 2011-09-13 17:58:37 --> URI Class Initialized
DEBUG - 2011-09-13 17:58:37 --> Router Class Initialized
DEBUG - 2011-09-13 17:58:37 --> Output Class Initialized
DEBUG - 2011-09-13 17:58:37 --> Input Class Initialized
DEBUG - 2011-09-13 17:58:37 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-13 17:58:37 --> Language Class Initialized
DEBUG - 2011-09-13 17:58:37 --> Loader Class Initialized
DEBUG - 2011-09-13 17:58:37 --> Controller Class Initialized
ERROR - 2011-09-13 17:58:37 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-09-13 17:58:37 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-09-13 17:58:37 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-09-13 17:58:37 --> Model Class Initialized
DEBUG - 2011-09-13 17:58:37 --> Model Class Initialized
DEBUG - 2011-09-13 17:58:37 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-13 17:58:37 --> Database Driver Class Initialized
DEBUG - 2011-09-13 17:58:37 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-09-13 17:58:37 --> Helper loaded: url_helper
DEBUG - 2011-09-13 17:58:37 --> File loaded: application/views/common/header.php
DEBUG - 2011-09-13 17:58:37 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-09-13 17:58:37 --> File loaded: application/views/common/footer.php
DEBUG - 2011-09-13 17:58:37 --> File loaded: application/views/layout/main.php
DEBUG - 2011-09-13 17:58:37 --> Final output sent to browser
DEBUG - 2011-09-13 17:58:37 --> Total execution time: 0.0427
DEBUG - 2011-09-13 18:10:48 --> Config Class Initialized
DEBUG - 2011-09-13 18:10:48 --> Hooks Class Initialized
DEBUG - 2011-09-13 18:10:48 --> Utf8 Class Initialized
DEBUG - 2011-09-13 18:10:48 --> UTF-8 Support Enabled
DEBUG - 2011-09-13 18:10:48 --> URI Class Initialized
DEBUG - 2011-09-13 18:10:48 --> Router Class Initialized
DEBUG - 2011-09-13 18:10:48 --> Output Class Initialized
DEBUG - 2011-09-13 18:10:48 --> Input Class Initialized
DEBUG - 2011-09-13 18:10:48 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-13 18:10:48 --> Language Class Initialized
DEBUG - 2011-09-13 18:10:48 --> Loader Class Initialized
DEBUG - 2011-09-13 18:10:48 --> Controller Class Initialized
ERROR - 2011-09-13 18:10:48 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-09-13 18:10:48 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-09-13 18:10:48 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-09-13 18:10:48 --> Model Class Initialized
DEBUG - 2011-09-13 18:10:48 --> Model Class Initialized
DEBUG - 2011-09-13 18:10:48 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-13 18:10:48 --> Database Driver Class Initialized
DEBUG - 2011-09-13 18:10:48 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-09-13 18:10:48 --> Helper loaded: url_helper
DEBUG - 2011-09-13 18:10:48 --> File loaded: application/views/common/header.php
DEBUG - 2011-09-13 18:10:48 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-09-13 18:10:48 --> File loaded: application/views/common/footer.php
DEBUG - 2011-09-13 18:10:48 --> File loaded: application/views/layout/main.php
DEBUG - 2011-09-13 18:10:48 --> Final output sent to browser
DEBUG - 2011-09-13 18:10:48 --> Total execution time: 0.0297
DEBUG - 2011-09-13 18:10:59 --> Config Class Initialized
DEBUG - 2011-09-13 18:10:59 --> Hooks Class Initialized
DEBUG - 2011-09-13 18:10:59 --> Utf8 Class Initialized
DEBUG - 2011-09-13 18:10:59 --> UTF-8 Support Enabled
DEBUG - 2011-09-13 18:10:59 --> URI Class Initialized
DEBUG - 2011-09-13 18:10:59 --> Router Class Initialized
DEBUG - 2011-09-13 18:10:59 --> Output Class Initialized
DEBUG - 2011-09-13 18:10:59 --> Input Class Initialized
DEBUG - 2011-09-13 18:10:59 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-13 18:10:59 --> Language Class Initialized
DEBUG - 2011-09-13 18:10:59 --> Loader Class Initialized
DEBUG - 2011-09-13 18:10:59 --> Controller Class Initialized
DEBUG - 2011-09-13 18:10:59 --> Model Class Initialized
DEBUG - 2011-09-13 18:10:59 --> Model Class Initialized
DEBUG - 2011-09-13 18:10:59 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-13 18:10:59 --> Database Driver Class Initialized
DEBUG - 2011-09-13 18:10:59 --> Final output sent to browser
DEBUG - 2011-09-13 18:10:59 --> Total execution time: 0.5868
DEBUG - 2011-09-13 18:11:11 --> Config Class Initialized
DEBUG - 2011-09-13 18:11:11 --> Hooks Class Initialized
DEBUG - 2011-09-13 18:11:11 --> Utf8 Class Initialized
DEBUG - 2011-09-13 18:11:11 --> UTF-8 Support Enabled
DEBUG - 2011-09-13 18:11:11 --> URI Class Initialized
DEBUG - 2011-09-13 18:11:11 --> Router Class Initialized
DEBUG - 2011-09-13 18:11:11 --> Output Class Initialized
DEBUG - 2011-09-13 18:11:11 --> Input Class Initialized
DEBUG - 2011-09-13 18:11:11 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-13 18:11:11 --> Language Class Initialized
DEBUG - 2011-09-13 18:11:11 --> Loader Class Initialized
DEBUG - 2011-09-13 18:11:11 --> Controller Class Initialized
ERROR - 2011-09-13 18:11:11 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-09-13 18:11:11 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-09-13 18:11:11 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-09-13 18:11:11 --> Model Class Initialized
DEBUG - 2011-09-13 18:11:11 --> Model Class Initialized
DEBUG - 2011-09-13 18:11:11 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-13 18:11:11 --> Database Driver Class Initialized
DEBUG - 2011-09-13 18:11:11 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-09-13 18:11:11 --> Helper loaded: url_helper
DEBUG - 2011-09-13 18:11:11 --> File loaded: application/views/common/header.php
DEBUG - 2011-09-13 18:11:11 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-09-13 18:11:11 --> File loaded: application/views/common/footer.php
DEBUG - 2011-09-13 18:11:11 --> File loaded: application/views/layout/main.php
DEBUG - 2011-09-13 18:11:11 --> Final output sent to browser
DEBUG - 2011-09-13 18:11:11 --> Total execution time: 0.0274
DEBUG - 2011-09-13 18:11:14 --> Config Class Initialized
DEBUG - 2011-09-13 18:11:14 --> Hooks Class Initialized
DEBUG - 2011-09-13 18:11:14 --> Utf8 Class Initialized
DEBUG - 2011-09-13 18:11:14 --> UTF-8 Support Enabled
DEBUG - 2011-09-13 18:11:14 --> URI Class Initialized
DEBUG - 2011-09-13 18:11:14 --> Router Class Initialized
ERROR - 2011-09-13 18:11:14 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-09-13 18:11:41 --> Config Class Initialized
DEBUG - 2011-09-13 18:11:41 --> Hooks Class Initialized
DEBUG - 2011-09-13 18:11:41 --> Utf8 Class Initialized
DEBUG - 2011-09-13 18:11:41 --> UTF-8 Support Enabled
DEBUG - 2011-09-13 18:11:41 --> URI Class Initialized
DEBUG - 2011-09-13 18:11:41 --> Router Class Initialized
ERROR - 2011-09-13 18:11:41 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-09-13 18:13:10 --> Config Class Initialized
DEBUG - 2011-09-13 18:13:10 --> Hooks Class Initialized
DEBUG - 2011-09-13 18:13:10 --> Utf8 Class Initialized
DEBUG - 2011-09-13 18:13:10 --> UTF-8 Support Enabled
DEBUG - 2011-09-13 18:13:10 --> URI Class Initialized
DEBUG - 2011-09-13 18:13:10 --> Router Class Initialized
DEBUG - 2011-09-13 18:13:10 --> Output Class Initialized
DEBUG - 2011-09-13 18:13:10 --> Input Class Initialized
DEBUG - 2011-09-13 18:13:10 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-13 18:13:10 --> Language Class Initialized
DEBUG - 2011-09-13 18:13:10 --> Loader Class Initialized
DEBUG - 2011-09-13 18:13:10 --> Controller Class Initialized
ERROR - 2011-09-13 18:13:10 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-09-13 18:13:10 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-09-13 18:13:10 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-09-13 18:13:10 --> Model Class Initialized
DEBUG - 2011-09-13 18:13:10 --> Model Class Initialized
DEBUG - 2011-09-13 18:13:10 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-13 18:13:10 --> Database Driver Class Initialized
DEBUG - 2011-09-13 18:13:10 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-09-13 18:13:10 --> Helper loaded: url_helper
DEBUG - 2011-09-13 18:13:10 --> File loaded: application/views/common/header.php
DEBUG - 2011-09-13 18:13:10 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-09-13 18:13:10 --> File loaded: application/views/common/footer.php
DEBUG - 2011-09-13 18:13:10 --> File loaded: application/views/layout/main.php
DEBUG - 2011-09-13 18:13:10 --> Final output sent to browser
DEBUG - 2011-09-13 18:13:10 --> Total execution time: 0.0338
DEBUG - 2011-09-13 18:13:11 --> Config Class Initialized
DEBUG - 2011-09-13 18:13:11 --> Hooks Class Initialized
DEBUG - 2011-09-13 18:13:11 --> Utf8 Class Initialized
DEBUG - 2011-09-13 18:13:11 --> UTF-8 Support Enabled
DEBUG - 2011-09-13 18:13:11 --> URI Class Initialized
DEBUG - 2011-09-13 18:13:11 --> Router Class Initialized
DEBUG - 2011-09-13 18:13:11 --> Output Class Initialized
DEBUG - 2011-09-13 18:13:11 --> Input Class Initialized
DEBUG - 2011-09-13 18:13:11 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-13 18:13:11 --> Language Class Initialized
DEBUG - 2011-09-13 18:13:11 --> Loader Class Initialized
DEBUG - 2011-09-13 18:13:11 --> Controller Class Initialized
DEBUG - 2011-09-13 18:13:11 --> Model Class Initialized
DEBUG - 2011-09-13 18:13:11 --> Model Class Initialized
DEBUG - 2011-09-13 18:13:11 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-13 18:13:11 --> Database Driver Class Initialized
DEBUG - 2011-09-13 18:13:11 --> Final output sent to browser
DEBUG - 2011-09-13 18:13:11 --> Total execution time: 0.7076
DEBUG - 2011-09-13 18:13:12 --> Config Class Initialized
DEBUG - 2011-09-13 18:13:12 --> Hooks Class Initialized
DEBUG - 2011-09-13 18:13:12 --> Utf8 Class Initialized
DEBUG - 2011-09-13 18:13:12 --> UTF-8 Support Enabled
DEBUG - 2011-09-13 18:13:12 --> URI Class Initialized
DEBUG - 2011-09-13 18:13:12 --> Router Class Initialized
ERROR - 2011-09-13 18:13:12 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-09-13 18:13:14 --> Config Class Initialized
DEBUG - 2011-09-13 18:13:14 --> Hooks Class Initialized
DEBUG - 2011-09-13 18:13:14 --> Utf8 Class Initialized
DEBUG - 2011-09-13 18:13:14 --> UTF-8 Support Enabled
DEBUG - 2011-09-13 18:13:14 --> URI Class Initialized
DEBUG - 2011-09-13 18:13:14 --> Router Class Initialized
ERROR - 2011-09-13 18:13:14 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-09-13 18:22:29 --> Config Class Initialized
DEBUG - 2011-09-13 18:22:29 --> Hooks Class Initialized
DEBUG - 2011-09-13 18:22:29 --> Utf8 Class Initialized
DEBUG - 2011-09-13 18:22:29 --> UTF-8 Support Enabled
DEBUG - 2011-09-13 18:22:29 --> URI Class Initialized
DEBUG - 2011-09-13 18:22:29 --> Router Class Initialized
DEBUG - 2011-09-13 18:22:29 --> No URI present. Default controller set.
DEBUG - 2011-09-13 18:22:29 --> Output Class Initialized
DEBUG - 2011-09-13 18:22:29 --> Input Class Initialized
DEBUG - 2011-09-13 18:22:29 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-13 18:22:29 --> Language Class Initialized
DEBUG - 2011-09-13 18:22:29 --> Loader Class Initialized
DEBUG - 2011-09-13 18:22:29 --> Controller Class Initialized
DEBUG - 2011-09-13 18:22:29 --> File loaded: application/views/splash/main.php
DEBUG - 2011-09-13 18:22:29 --> Helper loaded: url_helper
DEBUG - 2011-09-13 18:22:29 --> File loaded: application/views/common/header.php
DEBUG - 2011-09-13 18:22:29 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-09-13 18:22:29 --> File loaded: application/views/common/footer.php
DEBUG - 2011-09-13 18:22:29 --> File loaded: application/views/layout/main.php
DEBUG - 2011-09-13 18:22:29 --> Final output sent to browser
DEBUG - 2011-09-13 18:22:29 --> Total execution time: 0.0808
DEBUG - 2011-09-13 18:35:30 --> Config Class Initialized
DEBUG - 2011-09-13 18:35:30 --> Hooks Class Initialized
DEBUG - 2011-09-13 18:35:30 --> Utf8 Class Initialized
DEBUG - 2011-09-13 18:35:30 --> UTF-8 Support Enabled
DEBUG - 2011-09-13 18:35:30 --> URI Class Initialized
DEBUG - 2011-09-13 18:35:30 --> Router Class Initialized
DEBUG - 2011-09-13 18:35:30 --> Output Class Initialized
DEBUG - 2011-09-13 18:35:30 --> Input Class Initialized
DEBUG - 2011-09-13 18:35:30 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-13 18:35:30 --> Language Class Initialized
DEBUG - 2011-09-13 18:35:30 --> Loader Class Initialized
DEBUG - 2011-09-13 18:35:30 --> Controller Class Initialized
ERROR - 2011-09-13 18:35:30 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-09-13 18:35:30 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-09-13 18:35:30 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-09-13 18:35:30 --> Model Class Initialized
DEBUG - 2011-09-13 18:35:30 --> Model Class Initialized
DEBUG - 2011-09-13 18:35:30 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-13 18:35:30 --> Database Driver Class Initialized
DEBUG - 2011-09-13 18:35:30 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-09-13 18:35:30 --> Helper loaded: url_helper
DEBUG - 2011-09-13 18:35:30 --> File loaded: application/views/common/header.php
DEBUG - 2011-09-13 18:35:30 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-09-13 18:35:30 --> File loaded: application/views/common/footer.php
DEBUG - 2011-09-13 18:35:30 --> File loaded: application/views/layout/main.php
DEBUG - 2011-09-13 18:35:30 --> Final output sent to browser
DEBUG - 2011-09-13 18:35:30 --> Total execution time: 0.6527
DEBUG - 2011-09-13 18:35:36 --> Config Class Initialized
DEBUG - 2011-09-13 18:35:36 --> Hooks Class Initialized
DEBUG - 2011-09-13 18:35:36 --> Utf8 Class Initialized
DEBUG - 2011-09-13 18:35:36 --> UTF-8 Support Enabled
DEBUG - 2011-09-13 18:35:36 --> URI Class Initialized
DEBUG - 2011-09-13 18:35:36 --> Router Class Initialized
DEBUG - 2011-09-13 18:35:36 --> Output Class Initialized
DEBUG - 2011-09-13 18:35:36 --> Input Class Initialized
DEBUG - 2011-09-13 18:35:36 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-13 18:35:36 --> Language Class Initialized
DEBUG - 2011-09-13 18:35:36 --> Loader Class Initialized
DEBUG - 2011-09-13 18:35:36 --> Controller Class Initialized
DEBUG - 2011-09-13 18:35:36 --> Model Class Initialized
DEBUG - 2011-09-13 18:35:36 --> Model Class Initialized
DEBUG - 2011-09-13 18:35:36 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-13 18:35:36 --> Database Driver Class Initialized
DEBUG - 2011-09-13 18:35:36 --> Final output sent to browser
DEBUG - 2011-09-13 18:35:36 --> Total execution time: 0.5753
DEBUG - 2011-09-13 18:35:38 --> Config Class Initialized
DEBUG - 2011-09-13 18:35:38 --> Hooks Class Initialized
DEBUG - 2011-09-13 18:35:38 --> Utf8 Class Initialized
DEBUG - 2011-09-13 18:35:38 --> UTF-8 Support Enabled
DEBUG - 2011-09-13 18:35:38 --> URI Class Initialized
DEBUG - 2011-09-13 18:35:38 --> Router Class Initialized
ERROR - 2011-09-13 18:35:38 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-09-13 18:36:14 --> Config Class Initialized
DEBUG - 2011-09-13 18:36:14 --> Hooks Class Initialized
DEBUG - 2011-09-13 18:36:14 --> Utf8 Class Initialized
DEBUG - 2011-09-13 18:36:14 --> UTF-8 Support Enabled
DEBUG - 2011-09-13 18:36:14 --> URI Class Initialized
DEBUG - 2011-09-13 18:36:14 --> Router Class Initialized
DEBUG - 2011-09-13 18:36:14 --> Output Class Initialized
DEBUG - 2011-09-13 18:36:14 --> Input Class Initialized
DEBUG - 2011-09-13 18:36:14 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-13 18:36:14 --> Language Class Initialized
DEBUG - 2011-09-13 18:36:14 --> Loader Class Initialized
DEBUG - 2011-09-13 18:36:14 --> Controller Class Initialized
ERROR - 2011-09-13 18:36:14 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-09-13 18:36:14 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-09-13 18:36:14 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-09-13 18:36:14 --> Model Class Initialized
DEBUG - 2011-09-13 18:36:14 --> Model Class Initialized
DEBUG - 2011-09-13 18:36:14 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-13 18:36:14 --> Database Driver Class Initialized
DEBUG - 2011-09-13 18:36:14 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-09-13 18:36:14 --> Helper loaded: url_helper
DEBUG - 2011-09-13 18:36:14 --> File loaded: application/views/common/header.php
DEBUG - 2011-09-13 18:36:14 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-09-13 18:36:14 --> File loaded: application/views/common/footer.php
DEBUG - 2011-09-13 18:36:14 --> File loaded: application/views/layout/main.php
DEBUG - 2011-09-13 18:36:14 --> Final output sent to browser
DEBUG - 2011-09-13 18:36:14 --> Total execution time: 0.0288
DEBUG - 2011-09-13 18:36:15 --> Config Class Initialized
DEBUG - 2011-09-13 18:36:15 --> Hooks Class Initialized
DEBUG - 2011-09-13 18:36:15 --> Utf8 Class Initialized
DEBUG - 2011-09-13 18:36:15 --> UTF-8 Support Enabled
DEBUG - 2011-09-13 18:36:15 --> URI Class Initialized
DEBUG - 2011-09-13 18:36:15 --> Router Class Initialized
DEBUG - 2011-09-13 18:36:15 --> Output Class Initialized
DEBUG - 2011-09-13 18:36:15 --> Input Class Initialized
DEBUG - 2011-09-13 18:36:15 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-13 18:36:15 --> Language Class Initialized
DEBUG - 2011-09-13 18:36:15 --> Loader Class Initialized
DEBUG - 2011-09-13 18:36:15 --> Controller Class Initialized
DEBUG - 2011-09-13 18:36:15 --> Model Class Initialized
DEBUG - 2011-09-13 18:36:15 --> Model Class Initialized
DEBUG - 2011-09-13 18:36:15 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-13 18:36:15 --> Database Driver Class Initialized
DEBUG - 2011-09-13 18:36:15 --> Final output sent to browser
DEBUG - 2011-09-13 18:36:15 --> Total execution time: 0.5175
DEBUG - 2011-09-13 18:36:17 --> Config Class Initialized
DEBUG - 2011-09-13 18:36:17 --> Hooks Class Initialized
DEBUG - 2011-09-13 18:36:17 --> Utf8 Class Initialized
DEBUG - 2011-09-13 18:36:17 --> UTF-8 Support Enabled
DEBUG - 2011-09-13 18:36:17 --> URI Class Initialized
DEBUG - 2011-09-13 18:36:17 --> Router Class Initialized
ERROR - 2011-09-13 18:36:17 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-09-13 18:36:57 --> Config Class Initialized
DEBUG - 2011-09-13 18:36:57 --> Hooks Class Initialized
DEBUG - 2011-09-13 18:36:57 --> Utf8 Class Initialized
DEBUG - 2011-09-13 18:36:57 --> UTF-8 Support Enabled
DEBUG - 2011-09-13 18:36:57 --> URI Class Initialized
DEBUG - 2011-09-13 18:36:57 --> Router Class Initialized
DEBUG - 2011-09-13 18:36:57 --> Output Class Initialized
DEBUG - 2011-09-13 18:36:57 --> Input Class Initialized
DEBUG - 2011-09-13 18:36:57 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-13 18:36:57 --> Language Class Initialized
DEBUG - 2011-09-13 18:36:57 --> Loader Class Initialized
DEBUG - 2011-09-13 18:36:57 --> Controller Class Initialized
ERROR - 2011-09-13 18:36:57 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-09-13 18:36:57 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-09-13 18:36:57 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-09-13 18:36:57 --> Model Class Initialized
DEBUG - 2011-09-13 18:36:57 --> Model Class Initialized
DEBUG - 2011-09-13 18:36:57 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-13 18:36:57 --> Database Driver Class Initialized
DEBUG - 2011-09-13 18:36:57 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-09-13 18:36:57 --> Helper loaded: url_helper
DEBUG - 2011-09-13 18:36:57 --> File loaded: application/views/common/header.php
DEBUG - 2011-09-13 18:36:57 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-09-13 18:36:57 --> File loaded: application/views/common/footer.php
DEBUG - 2011-09-13 18:36:57 --> File loaded: application/views/layout/main.php
DEBUG - 2011-09-13 18:36:57 --> Final output sent to browser
DEBUG - 2011-09-13 18:36:57 --> Total execution time: 0.0308
DEBUG - 2011-09-13 18:36:59 --> Config Class Initialized
DEBUG - 2011-09-13 18:36:59 --> Hooks Class Initialized
DEBUG - 2011-09-13 18:36:59 --> Utf8 Class Initialized
DEBUG - 2011-09-13 18:36:59 --> UTF-8 Support Enabled
DEBUG - 2011-09-13 18:36:59 --> URI Class Initialized
DEBUG - 2011-09-13 18:36:59 --> Router Class Initialized
DEBUG - 2011-09-13 18:36:59 --> Output Class Initialized
DEBUG - 2011-09-13 18:36:59 --> Input Class Initialized
DEBUG - 2011-09-13 18:36:59 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-13 18:36:59 --> Language Class Initialized
DEBUG - 2011-09-13 18:36:59 --> Loader Class Initialized
DEBUG - 2011-09-13 18:36:59 --> Controller Class Initialized
DEBUG - 2011-09-13 18:36:59 --> Model Class Initialized
DEBUG - 2011-09-13 18:36:59 --> Model Class Initialized
DEBUG - 2011-09-13 18:36:59 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-13 18:36:59 --> Database Driver Class Initialized
DEBUG - 2011-09-13 18:36:59 --> Final output sent to browser
DEBUG - 2011-09-13 18:36:59 --> Total execution time: 0.5463
DEBUG - 2011-09-13 18:37:02 --> Config Class Initialized
DEBUG - 2011-09-13 18:37:02 --> Hooks Class Initialized
DEBUG - 2011-09-13 18:37:02 --> Utf8 Class Initialized
DEBUG - 2011-09-13 18:37:02 --> UTF-8 Support Enabled
DEBUG - 2011-09-13 18:37:02 --> URI Class Initialized
DEBUG - 2011-09-13 18:37:02 --> Router Class Initialized
ERROR - 2011-09-13 18:37:02 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-09-13 18:37:14 --> Config Class Initialized
DEBUG - 2011-09-13 18:37:14 --> Hooks Class Initialized
DEBUG - 2011-09-13 18:37:14 --> Utf8 Class Initialized
DEBUG - 2011-09-13 18:37:14 --> UTF-8 Support Enabled
DEBUG - 2011-09-13 18:37:14 --> URI Class Initialized
DEBUG - 2011-09-13 18:37:14 --> Router Class Initialized
DEBUG - 2011-09-13 18:37:14 --> Output Class Initialized
DEBUG - 2011-09-13 18:37:14 --> Input Class Initialized
DEBUG - 2011-09-13 18:37:14 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-13 18:37:14 --> Language Class Initialized
DEBUG - 2011-09-13 18:37:14 --> Loader Class Initialized
DEBUG - 2011-09-13 18:37:14 --> Controller Class Initialized
ERROR - 2011-09-13 18:37:14 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-09-13 18:37:14 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-09-13 18:37:14 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-09-13 18:37:14 --> Model Class Initialized
DEBUG - 2011-09-13 18:37:14 --> Model Class Initialized
DEBUG - 2011-09-13 18:37:14 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-13 18:37:14 --> Database Driver Class Initialized
DEBUG - 2011-09-13 18:37:14 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-09-13 18:37:14 --> Helper loaded: url_helper
DEBUG - 2011-09-13 18:37:14 --> File loaded: application/views/common/header.php
DEBUG - 2011-09-13 18:37:14 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-09-13 18:37:14 --> File loaded: application/views/common/footer.php
DEBUG - 2011-09-13 18:37:14 --> File loaded: application/views/layout/main.php
DEBUG - 2011-09-13 18:37:14 --> Final output sent to browser
DEBUG - 2011-09-13 18:37:14 --> Total execution time: 0.0337
DEBUG - 2011-09-13 18:37:16 --> Config Class Initialized
DEBUG - 2011-09-13 18:37:16 --> Hooks Class Initialized
DEBUG - 2011-09-13 18:37:16 --> Utf8 Class Initialized
DEBUG - 2011-09-13 18:37:16 --> UTF-8 Support Enabled
DEBUG - 2011-09-13 18:37:16 --> URI Class Initialized
DEBUG - 2011-09-13 18:37:16 --> Router Class Initialized
DEBUG - 2011-09-13 18:37:16 --> Output Class Initialized
DEBUG - 2011-09-13 18:37:16 --> Input Class Initialized
DEBUG - 2011-09-13 18:37:16 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-13 18:37:16 --> Language Class Initialized
DEBUG - 2011-09-13 18:37:16 --> Loader Class Initialized
DEBUG - 2011-09-13 18:37:16 --> Controller Class Initialized
DEBUG - 2011-09-13 18:37:16 --> Model Class Initialized
DEBUG - 2011-09-13 18:37:16 --> Model Class Initialized
DEBUG - 2011-09-13 18:37:16 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-13 18:37:16 --> Database Driver Class Initialized
DEBUG - 2011-09-13 18:37:16 --> Final output sent to browser
DEBUG - 2011-09-13 18:37:16 --> Total execution time: 0.5471
DEBUG - 2011-09-13 18:37:18 --> Config Class Initialized
DEBUG - 2011-09-13 18:37:18 --> Hooks Class Initialized
DEBUG - 2011-09-13 18:37:18 --> Utf8 Class Initialized
DEBUG - 2011-09-13 18:37:18 --> UTF-8 Support Enabled
DEBUG - 2011-09-13 18:37:18 --> URI Class Initialized
DEBUG - 2011-09-13 18:37:18 --> Router Class Initialized
ERROR - 2011-09-13 18:37:18 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-09-13 18:37:25 --> Config Class Initialized
DEBUG - 2011-09-13 18:37:25 --> Hooks Class Initialized
DEBUG - 2011-09-13 18:37:25 --> Utf8 Class Initialized
DEBUG - 2011-09-13 18:37:25 --> UTF-8 Support Enabled
DEBUG - 2011-09-13 18:37:25 --> URI Class Initialized
DEBUG - 2011-09-13 18:37:25 --> Router Class Initialized
DEBUG - 2011-09-13 18:37:25 --> Output Class Initialized
DEBUG - 2011-09-13 18:37:25 --> Input Class Initialized
DEBUG - 2011-09-13 18:37:25 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-13 18:37:25 --> Language Class Initialized
DEBUG - 2011-09-13 18:37:25 --> Loader Class Initialized
DEBUG - 2011-09-13 18:37:25 --> Controller Class Initialized
ERROR - 2011-09-13 18:37:25 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-09-13 18:37:25 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-09-13 18:37:25 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-09-13 18:37:25 --> Model Class Initialized
DEBUG - 2011-09-13 18:37:25 --> Model Class Initialized
DEBUG - 2011-09-13 18:37:25 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-13 18:37:25 --> Database Driver Class Initialized
DEBUG - 2011-09-13 18:37:25 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-09-13 18:37:25 --> Helper loaded: url_helper
DEBUG - 2011-09-13 18:37:25 --> File loaded: application/views/common/header.php
DEBUG - 2011-09-13 18:37:25 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-09-13 18:37:25 --> File loaded: application/views/common/footer.php
DEBUG - 2011-09-13 18:37:25 --> File loaded: application/views/layout/main.php
DEBUG - 2011-09-13 18:37:25 --> Final output sent to browser
DEBUG - 2011-09-13 18:37:25 --> Total execution time: 0.0304
DEBUG - 2011-09-13 18:37:26 --> Config Class Initialized
DEBUG - 2011-09-13 18:37:26 --> Hooks Class Initialized
DEBUG - 2011-09-13 18:37:26 --> Utf8 Class Initialized
DEBUG - 2011-09-13 18:37:26 --> UTF-8 Support Enabled
DEBUG - 2011-09-13 18:37:26 --> URI Class Initialized
DEBUG - 2011-09-13 18:37:26 --> Router Class Initialized
DEBUG - 2011-09-13 18:37:26 --> Output Class Initialized
DEBUG - 2011-09-13 18:37:26 --> Input Class Initialized
DEBUG - 2011-09-13 18:37:26 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-13 18:37:26 --> Language Class Initialized
DEBUG - 2011-09-13 18:37:26 --> Loader Class Initialized
DEBUG - 2011-09-13 18:37:26 --> Controller Class Initialized
DEBUG - 2011-09-13 18:37:26 --> Model Class Initialized
DEBUG - 2011-09-13 18:37:26 --> Model Class Initialized
DEBUG - 2011-09-13 18:37:26 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-13 18:37:26 --> Database Driver Class Initialized
DEBUG - 2011-09-13 18:37:27 --> Final output sent to browser
DEBUG - 2011-09-13 18:37:27 --> Total execution time: 0.5562
DEBUG - 2011-09-13 18:37:28 --> Config Class Initialized
DEBUG - 2011-09-13 18:37:28 --> Hooks Class Initialized
DEBUG - 2011-09-13 18:37:28 --> Utf8 Class Initialized
DEBUG - 2011-09-13 18:37:28 --> UTF-8 Support Enabled
DEBUG - 2011-09-13 18:37:28 --> URI Class Initialized
DEBUG - 2011-09-13 18:37:28 --> Router Class Initialized
ERROR - 2011-09-13 18:37:28 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-09-13 18:37:47 --> Config Class Initialized
DEBUG - 2011-09-13 18:37:47 --> Hooks Class Initialized
DEBUG - 2011-09-13 18:37:47 --> Utf8 Class Initialized
DEBUG - 2011-09-13 18:37:47 --> UTF-8 Support Enabled
DEBUG - 2011-09-13 18:37:47 --> URI Class Initialized
DEBUG - 2011-09-13 18:37:47 --> Router Class Initialized
DEBUG - 2011-09-13 18:37:47 --> Output Class Initialized
DEBUG - 2011-09-13 18:37:47 --> Input Class Initialized
DEBUG - 2011-09-13 18:37:47 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-13 18:37:47 --> Language Class Initialized
DEBUG - 2011-09-13 18:37:47 --> Loader Class Initialized
DEBUG - 2011-09-13 18:37:47 --> Controller Class Initialized
ERROR - 2011-09-13 18:37:47 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-09-13 18:37:47 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-09-13 18:37:47 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-09-13 18:37:47 --> Model Class Initialized
DEBUG - 2011-09-13 18:37:47 --> Model Class Initialized
DEBUG - 2011-09-13 18:37:47 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-13 18:37:47 --> Database Driver Class Initialized
DEBUG - 2011-09-13 18:37:47 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-09-13 18:37:47 --> Helper loaded: url_helper
DEBUG - 2011-09-13 18:37:47 --> File loaded: application/views/common/header.php
DEBUG - 2011-09-13 18:37:47 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-09-13 18:37:47 --> File loaded: application/views/common/footer.php
DEBUG - 2011-09-13 18:37:47 --> File loaded: application/views/layout/main.php
DEBUG - 2011-09-13 18:37:47 --> Final output sent to browser
DEBUG - 2011-09-13 18:37:47 --> Total execution time: 0.0284
DEBUG - 2011-09-13 18:37:48 --> Config Class Initialized
DEBUG - 2011-09-13 18:37:48 --> Hooks Class Initialized
DEBUG - 2011-09-13 18:37:48 --> Utf8 Class Initialized
DEBUG - 2011-09-13 18:37:48 --> UTF-8 Support Enabled
DEBUG - 2011-09-13 18:37:48 --> URI Class Initialized
DEBUG - 2011-09-13 18:37:48 --> Router Class Initialized
DEBUG - 2011-09-13 18:37:48 --> Output Class Initialized
DEBUG - 2011-09-13 18:37:48 --> Input Class Initialized
DEBUG - 2011-09-13 18:37:48 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-13 18:37:48 --> Language Class Initialized
DEBUG - 2011-09-13 18:37:48 --> Loader Class Initialized
DEBUG - 2011-09-13 18:37:48 --> Controller Class Initialized
DEBUG - 2011-09-13 18:37:48 --> Model Class Initialized
DEBUG - 2011-09-13 18:37:48 --> Model Class Initialized
DEBUG - 2011-09-13 18:37:48 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-13 18:37:48 --> Database Driver Class Initialized
DEBUG - 2011-09-13 18:37:49 --> Final output sent to browser
DEBUG - 2011-09-13 18:37:49 --> Total execution time: 0.5476
DEBUG - 2011-09-13 18:37:56 --> Config Class Initialized
DEBUG - 2011-09-13 18:37:56 --> Hooks Class Initialized
DEBUG - 2011-09-13 18:37:56 --> Utf8 Class Initialized
DEBUG - 2011-09-13 18:37:56 --> UTF-8 Support Enabled
DEBUG - 2011-09-13 18:37:56 --> URI Class Initialized
DEBUG - 2011-09-13 18:37:56 --> Router Class Initialized
ERROR - 2011-09-13 18:37:56 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-09-13 18:38:04 --> Config Class Initialized
DEBUG - 2011-09-13 18:38:04 --> Hooks Class Initialized
DEBUG - 2011-09-13 18:38:04 --> Utf8 Class Initialized
DEBUG - 2011-09-13 18:38:04 --> UTF-8 Support Enabled
DEBUG - 2011-09-13 18:38:04 --> URI Class Initialized
DEBUG - 2011-09-13 18:38:04 --> Router Class Initialized
DEBUG - 2011-09-13 18:38:04 --> Output Class Initialized
DEBUG - 2011-09-13 18:38:04 --> Input Class Initialized
DEBUG - 2011-09-13 18:38:04 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-13 18:38:04 --> Language Class Initialized
DEBUG - 2011-09-13 18:38:04 --> Loader Class Initialized
DEBUG - 2011-09-13 18:38:04 --> Controller Class Initialized
ERROR - 2011-09-13 18:38:04 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-09-13 18:38:04 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-09-13 18:38:04 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-09-13 18:38:04 --> Model Class Initialized
DEBUG - 2011-09-13 18:38:04 --> Model Class Initialized
DEBUG - 2011-09-13 18:38:04 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-13 18:38:04 --> Database Driver Class Initialized
DEBUG - 2011-09-13 18:38:04 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-09-13 18:38:04 --> Helper loaded: url_helper
DEBUG - 2011-09-13 18:38:04 --> File loaded: application/views/common/header.php
DEBUG - 2011-09-13 18:38:04 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-09-13 18:38:04 --> File loaded: application/views/common/footer.php
DEBUG - 2011-09-13 18:38:04 --> File loaded: application/views/layout/main.php
DEBUG - 2011-09-13 18:38:04 --> Final output sent to browser
DEBUG - 2011-09-13 18:38:04 --> Total execution time: 0.0295
DEBUG - 2011-09-13 18:38:05 --> Config Class Initialized
DEBUG - 2011-09-13 18:38:05 --> Hooks Class Initialized
DEBUG - 2011-09-13 18:38:05 --> Utf8 Class Initialized
DEBUG - 2011-09-13 18:38:05 --> UTF-8 Support Enabled
DEBUG - 2011-09-13 18:38:05 --> URI Class Initialized
DEBUG - 2011-09-13 18:38:05 --> Router Class Initialized
DEBUG - 2011-09-13 18:38:05 --> Output Class Initialized
DEBUG - 2011-09-13 18:38:05 --> Input Class Initialized
DEBUG - 2011-09-13 18:38:05 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-13 18:38:05 --> Language Class Initialized
DEBUG - 2011-09-13 18:38:05 --> Loader Class Initialized
DEBUG - 2011-09-13 18:38:05 --> Controller Class Initialized
DEBUG - 2011-09-13 18:38:05 --> Model Class Initialized
DEBUG - 2011-09-13 18:38:05 --> Model Class Initialized
DEBUG - 2011-09-13 18:38:05 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-13 18:38:05 --> Database Driver Class Initialized
DEBUG - 2011-09-13 18:38:06 --> Final output sent to browser
DEBUG - 2011-09-13 18:38:06 --> Total execution time: 0.5795
DEBUG - 2011-09-13 18:38:12 --> Config Class Initialized
DEBUG - 2011-09-13 18:38:12 --> Hooks Class Initialized
DEBUG - 2011-09-13 18:38:12 --> Utf8 Class Initialized
DEBUG - 2011-09-13 18:38:12 --> UTF-8 Support Enabled
DEBUG - 2011-09-13 18:38:12 --> URI Class Initialized
DEBUG - 2011-09-13 18:38:12 --> Router Class Initialized
ERROR - 2011-09-13 18:38:12 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-09-13 18:38:19 --> Config Class Initialized
DEBUG - 2011-09-13 18:38:19 --> Hooks Class Initialized
DEBUG - 2011-09-13 18:38:19 --> Utf8 Class Initialized
DEBUG - 2011-09-13 18:38:19 --> UTF-8 Support Enabled
DEBUG - 2011-09-13 18:38:19 --> URI Class Initialized
DEBUG - 2011-09-13 18:38:19 --> Router Class Initialized
DEBUG - 2011-09-13 18:38:19 --> Output Class Initialized
DEBUG - 2011-09-13 18:38:19 --> Input Class Initialized
DEBUG - 2011-09-13 18:38:19 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-13 18:38:19 --> Language Class Initialized
DEBUG - 2011-09-13 18:38:19 --> Loader Class Initialized
DEBUG - 2011-09-13 18:38:19 --> Controller Class Initialized
ERROR - 2011-09-13 18:38:19 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-09-13 18:38:19 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-09-13 18:38:19 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-09-13 18:38:19 --> Model Class Initialized
DEBUG - 2011-09-13 18:38:19 --> Model Class Initialized
DEBUG - 2011-09-13 18:38:19 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-13 18:38:19 --> Database Driver Class Initialized
DEBUG - 2011-09-13 18:38:19 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-09-13 18:38:19 --> Helper loaded: url_helper
DEBUG - 2011-09-13 18:38:19 --> File loaded: application/views/common/header.php
DEBUG - 2011-09-13 18:38:19 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-09-13 18:38:19 --> File loaded: application/views/common/footer.php
DEBUG - 2011-09-13 18:38:19 --> File loaded: application/views/layout/main.php
DEBUG - 2011-09-13 18:38:19 --> Final output sent to browser
DEBUG - 2011-09-13 18:38:19 --> Total execution time: 0.0291
DEBUG - 2011-09-13 18:38:22 --> Config Class Initialized
DEBUG - 2011-09-13 18:38:22 --> Hooks Class Initialized
DEBUG - 2011-09-13 18:38:22 --> Utf8 Class Initialized
DEBUG - 2011-09-13 18:38:22 --> UTF-8 Support Enabled
DEBUG - 2011-09-13 18:38:22 --> URI Class Initialized
DEBUG - 2011-09-13 18:38:22 --> Router Class Initialized
DEBUG - 2011-09-13 18:38:22 --> Output Class Initialized
DEBUG - 2011-09-13 18:38:22 --> Input Class Initialized
DEBUG - 2011-09-13 18:38:22 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-13 18:38:22 --> Language Class Initialized
DEBUG - 2011-09-13 18:38:22 --> Loader Class Initialized
DEBUG - 2011-09-13 18:38:22 --> Controller Class Initialized
DEBUG - 2011-09-13 18:38:22 --> Model Class Initialized
DEBUG - 2011-09-13 18:38:22 --> Model Class Initialized
DEBUG - 2011-09-13 18:38:22 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-13 18:38:22 --> Database Driver Class Initialized
DEBUG - 2011-09-13 18:38:22 --> Final output sent to browser
DEBUG - 2011-09-13 18:38:22 --> Total execution time: 0.6594
DEBUG - 2011-09-13 18:38:24 --> Config Class Initialized
DEBUG - 2011-09-13 18:38:24 --> Hooks Class Initialized
DEBUG - 2011-09-13 18:38:24 --> Utf8 Class Initialized
DEBUG - 2011-09-13 18:38:24 --> UTF-8 Support Enabled
DEBUG - 2011-09-13 18:38:24 --> URI Class Initialized
DEBUG - 2011-09-13 18:38:24 --> Router Class Initialized
ERROR - 2011-09-13 18:38:24 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-09-13 18:38:32 --> Config Class Initialized
DEBUG - 2011-09-13 18:38:32 --> Hooks Class Initialized
DEBUG - 2011-09-13 18:38:32 --> Utf8 Class Initialized
DEBUG - 2011-09-13 18:38:32 --> UTF-8 Support Enabled
DEBUG - 2011-09-13 18:38:32 --> URI Class Initialized
DEBUG - 2011-09-13 18:38:32 --> Router Class Initialized
DEBUG - 2011-09-13 18:38:32 --> Output Class Initialized
DEBUG - 2011-09-13 18:38:32 --> Input Class Initialized
DEBUG - 2011-09-13 18:38:32 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-13 18:38:32 --> Language Class Initialized
DEBUG - 2011-09-13 18:38:32 --> Loader Class Initialized
DEBUG - 2011-09-13 18:38:32 --> Controller Class Initialized
ERROR - 2011-09-13 18:38:32 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-09-13 18:38:32 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-09-13 18:38:32 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-09-13 18:38:32 --> Model Class Initialized
DEBUG - 2011-09-13 18:38:32 --> Model Class Initialized
DEBUG - 2011-09-13 18:38:32 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-13 18:38:32 --> Database Driver Class Initialized
DEBUG - 2011-09-13 18:38:32 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-09-13 18:38:32 --> Helper loaded: url_helper
DEBUG - 2011-09-13 18:38:32 --> File loaded: application/views/common/header.php
DEBUG - 2011-09-13 18:38:32 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-09-13 18:38:32 --> File loaded: application/views/common/footer.php
DEBUG - 2011-09-13 18:38:32 --> File loaded: application/views/layout/main.php
DEBUG - 2011-09-13 18:38:32 --> Final output sent to browser
DEBUG - 2011-09-13 18:38:32 --> Total execution time: 0.0289
DEBUG - 2011-09-13 18:38:33 --> Config Class Initialized
DEBUG - 2011-09-13 18:38:33 --> Hooks Class Initialized
DEBUG - 2011-09-13 18:38:33 --> Utf8 Class Initialized
DEBUG - 2011-09-13 18:38:33 --> UTF-8 Support Enabled
DEBUG - 2011-09-13 18:38:33 --> URI Class Initialized
DEBUG - 2011-09-13 18:38:33 --> Router Class Initialized
DEBUG - 2011-09-13 18:38:33 --> Output Class Initialized
DEBUG - 2011-09-13 18:38:33 --> Input Class Initialized
DEBUG - 2011-09-13 18:38:33 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-13 18:38:33 --> Language Class Initialized
DEBUG - 2011-09-13 18:38:33 --> Loader Class Initialized
DEBUG - 2011-09-13 18:38:33 --> Controller Class Initialized
DEBUG - 2011-09-13 18:38:33 --> Model Class Initialized
DEBUG - 2011-09-13 18:38:33 --> Model Class Initialized
DEBUG - 2011-09-13 18:38:33 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-13 18:38:33 --> Database Driver Class Initialized
DEBUG - 2011-09-13 18:38:34 --> Final output sent to browser
DEBUG - 2011-09-13 18:38:34 --> Total execution time: 0.6116
DEBUG - 2011-09-13 18:38:37 --> Config Class Initialized
DEBUG - 2011-09-13 18:38:37 --> Hooks Class Initialized
DEBUG - 2011-09-13 18:38:37 --> Utf8 Class Initialized
DEBUG - 2011-09-13 18:38:37 --> UTF-8 Support Enabled
DEBUG - 2011-09-13 18:38:37 --> URI Class Initialized
DEBUG - 2011-09-13 18:38:37 --> Router Class Initialized
ERROR - 2011-09-13 18:38:37 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-09-13 18:38:42 --> Config Class Initialized
DEBUG - 2011-09-13 18:38:42 --> Hooks Class Initialized
DEBUG - 2011-09-13 18:38:42 --> Utf8 Class Initialized
DEBUG - 2011-09-13 18:38:42 --> UTF-8 Support Enabled
DEBUG - 2011-09-13 18:38:42 --> URI Class Initialized
DEBUG - 2011-09-13 18:38:42 --> Router Class Initialized
DEBUG - 2011-09-13 18:38:42 --> Output Class Initialized
DEBUG - 2011-09-13 18:38:42 --> Input Class Initialized
DEBUG - 2011-09-13 18:38:42 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-13 18:38:42 --> Language Class Initialized
DEBUG - 2011-09-13 18:38:42 --> Loader Class Initialized
DEBUG - 2011-09-13 18:38:42 --> Controller Class Initialized
ERROR - 2011-09-13 18:38:42 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-09-13 18:38:42 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-09-13 18:38:42 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-09-13 18:38:42 --> Model Class Initialized
DEBUG - 2011-09-13 18:38:42 --> Model Class Initialized
DEBUG - 2011-09-13 18:38:42 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-13 18:38:42 --> Database Driver Class Initialized
DEBUG - 2011-09-13 18:38:42 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-09-13 18:38:42 --> Helper loaded: url_helper
DEBUG - 2011-09-13 18:38:42 --> File loaded: application/views/common/header.php
DEBUG - 2011-09-13 18:38:42 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-09-13 18:38:42 --> File loaded: application/views/common/footer.php
DEBUG - 2011-09-13 18:38:42 --> File loaded: application/views/layout/main.php
DEBUG - 2011-09-13 18:38:42 --> Final output sent to browser
DEBUG - 2011-09-13 18:38:42 --> Total execution time: 0.0343
DEBUG - 2011-09-13 18:38:43 --> Config Class Initialized
DEBUG - 2011-09-13 18:38:43 --> Hooks Class Initialized
DEBUG - 2011-09-13 18:38:43 --> Utf8 Class Initialized
DEBUG - 2011-09-13 18:38:43 --> UTF-8 Support Enabled
DEBUG - 2011-09-13 18:38:43 --> URI Class Initialized
DEBUG - 2011-09-13 18:38:43 --> Router Class Initialized
DEBUG - 2011-09-13 18:38:43 --> Output Class Initialized
DEBUG - 2011-09-13 18:38:43 --> Input Class Initialized
DEBUG - 2011-09-13 18:38:43 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-13 18:38:43 --> Language Class Initialized
DEBUG - 2011-09-13 18:38:43 --> Loader Class Initialized
DEBUG - 2011-09-13 18:38:43 --> Controller Class Initialized
DEBUG - 2011-09-13 18:38:43 --> Model Class Initialized
DEBUG - 2011-09-13 18:38:43 --> Model Class Initialized
DEBUG - 2011-09-13 18:38:43 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-13 18:38:43 --> Database Driver Class Initialized
DEBUG - 2011-09-13 18:38:44 --> Final output sent to browser
DEBUG - 2011-09-13 18:38:44 --> Total execution time: 0.8163
DEBUG - 2011-09-13 18:38:49 --> Config Class Initialized
DEBUG - 2011-09-13 18:38:49 --> Hooks Class Initialized
DEBUG - 2011-09-13 18:38:49 --> Utf8 Class Initialized
DEBUG - 2011-09-13 18:38:49 --> UTF-8 Support Enabled
DEBUG - 2011-09-13 18:38:49 --> URI Class Initialized
DEBUG - 2011-09-13 18:38:49 --> Router Class Initialized
ERROR - 2011-09-13 18:38:49 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-09-13 18:38:51 --> Config Class Initialized
DEBUG - 2011-09-13 18:38:51 --> Hooks Class Initialized
DEBUG - 2011-09-13 18:38:51 --> Utf8 Class Initialized
DEBUG - 2011-09-13 18:38:51 --> UTF-8 Support Enabled
DEBUG - 2011-09-13 18:38:51 --> URI Class Initialized
DEBUG - 2011-09-13 18:38:51 --> Router Class Initialized
DEBUG - 2011-09-13 18:38:51 --> Output Class Initialized
DEBUG - 2011-09-13 18:38:51 --> Input Class Initialized
DEBUG - 2011-09-13 18:38:51 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-13 18:38:51 --> Language Class Initialized
DEBUG - 2011-09-13 18:38:51 --> Loader Class Initialized
DEBUG - 2011-09-13 18:38:51 --> Controller Class Initialized
ERROR - 2011-09-13 18:38:51 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-09-13 18:38:51 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-09-13 18:38:51 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-09-13 18:38:51 --> Model Class Initialized
DEBUG - 2011-09-13 18:38:51 --> Model Class Initialized
DEBUG - 2011-09-13 18:38:51 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-13 18:38:51 --> Database Driver Class Initialized
DEBUG - 2011-09-13 18:38:51 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-09-13 18:38:51 --> Helper loaded: url_helper
DEBUG - 2011-09-13 18:38:51 --> File loaded: application/views/common/header.php
DEBUG - 2011-09-13 18:38:51 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-09-13 18:38:51 --> File loaded: application/views/common/footer.php
DEBUG - 2011-09-13 18:38:51 --> File loaded: application/views/layout/main.php
DEBUG - 2011-09-13 18:38:51 --> Final output sent to browser
DEBUG - 2011-09-13 18:38:51 --> Total execution time: 0.0545
DEBUG - 2011-09-13 18:38:54 --> Config Class Initialized
DEBUG - 2011-09-13 18:38:54 --> Hooks Class Initialized
DEBUG - 2011-09-13 18:38:54 --> Utf8 Class Initialized
DEBUG - 2011-09-13 18:38:54 --> UTF-8 Support Enabled
DEBUG - 2011-09-13 18:38:54 --> URI Class Initialized
DEBUG - 2011-09-13 18:38:54 --> Router Class Initialized
DEBUG - 2011-09-13 18:38:54 --> Output Class Initialized
DEBUG - 2011-09-13 18:38:54 --> Input Class Initialized
DEBUG - 2011-09-13 18:38:54 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-13 18:38:54 --> Language Class Initialized
DEBUG - 2011-09-13 18:38:54 --> Loader Class Initialized
DEBUG - 2011-09-13 18:38:54 --> Controller Class Initialized
DEBUG - 2011-09-13 18:38:54 --> Model Class Initialized
DEBUG - 2011-09-13 18:38:54 --> Model Class Initialized
DEBUG - 2011-09-13 18:38:54 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-13 18:38:54 --> Database Driver Class Initialized
DEBUG - 2011-09-13 18:38:55 --> Final output sent to browser
DEBUG - 2011-09-13 18:38:55 --> Total execution time: 0.9754
DEBUG - 2011-09-13 18:39:00 --> Config Class Initialized
DEBUG - 2011-09-13 18:39:00 --> Hooks Class Initialized
DEBUG - 2011-09-13 18:39:00 --> Utf8 Class Initialized
DEBUG - 2011-09-13 18:39:00 --> UTF-8 Support Enabled
DEBUG - 2011-09-13 18:39:00 --> URI Class Initialized
DEBUG - 2011-09-13 18:39:00 --> Router Class Initialized
ERROR - 2011-09-13 18:39:00 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-09-13 18:39:17 --> Config Class Initialized
DEBUG - 2011-09-13 18:39:17 --> Hooks Class Initialized
DEBUG - 2011-09-13 18:39:17 --> Utf8 Class Initialized
DEBUG - 2011-09-13 18:39:17 --> UTF-8 Support Enabled
DEBUG - 2011-09-13 18:39:17 --> URI Class Initialized
DEBUG - 2011-09-13 18:39:17 --> Router Class Initialized
DEBUG - 2011-09-13 18:39:17 --> Output Class Initialized
DEBUG - 2011-09-13 18:39:17 --> Input Class Initialized
DEBUG - 2011-09-13 18:39:17 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-13 18:39:17 --> Language Class Initialized
DEBUG - 2011-09-13 18:39:17 --> Loader Class Initialized
DEBUG - 2011-09-13 18:39:17 --> Controller Class Initialized
ERROR - 2011-09-13 18:39:17 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-09-13 18:39:17 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-09-13 18:39:17 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-09-13 18:39:17 --> Model Class Initialized
DEBUG - 2011-09-13 18:39:17 --> Model Class Initialized
DEBUG - 2011-09-13 18:39:17 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-13 18:39:17 --> Database Driver Class Initialized
DEBUG - 2011-09-13 18:39:17 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-09-13 18:39:17 --> Helper loaded: url_helper
DEBUG - 2011-09-13 18:39:17 --> File loaded: application/views/common/header.php
DEBUG - 2011-09-13 18:39:17 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-09-13 18:39:17 --> File loaded: application/views/common/footer.php
DEBUG - 2011-09-13 18:39:17 --> File loaded: application/views/layout/main.php
DEBUG - 2011-09-13 18:39:17 --> Final output sent to browser
DEBUG - 2011-09-13 18:39:17 --> Total execution time: 0.0492
DEBUG - 2011-09-13 18:39:18 --> Config Class Initialized
DEBUG - 2011-09-13 18:39:18 --> Hooks Class Initialized
DEBUG - 2011-09-13 18:39:18 --> Utf8 Class Initialized
DEBUG - 2011-09-13 18:39:18 --> UTF-8 Support Enabled
DEBUG - 2011-09-13 18:39:18 --> URI Class Initialized
DEBUG - 2011-09-13 18:39:18 --> Router Class Initialized
DEBUG - 2011-09-13 18:39:18 --> Output Class Initialized
DEBUG - 2011-09-13 18:39:18 --> Input Class Initialized
DEBUG - 2011-09-13 18:39:18 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-13 18:39:18 --> Language Class Initialized
DEBUG - 2011-09-13 18:39:18 --> Loader Class Initialized
DEBUG - 2011-09-13 18:39:18 --> Controller Class Initialized
DEBUG - 2011-09-13 18:39:18 --> Model Class Initialized
DEBUG - 2011-09-13 18:39:18 --> Model Class Initialized
DEBUG - 2011-09-13 18:39:18 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-13 18:39:18 --> Database Driver Class Initialized
DEBUG - 2011-09-13 18:39:19 --> Final output sent to browser
DEBUG - 2011-09-13 18:39:19 --> Total execution time: 0.6052
DEBUG - 2011-09-13 18:39:25 --> Config Class Initialized
DEBUG - 2011-09-13 18:39:25 --> Hooks Class Initialized
DEBUG - 2011-09-13 18:39:25 --> Utf8 Class Initialized
DEBUG - 2011-09-13 18:39:25 --> UTF-8 Support Enabled
DEBUG - 2011-09-13 18:39:25 --> URI Class Initialized
DEBUG - 2011-09-13 18:39:25 --> Router Class Initialized
ERROR - 2011-09-13 18:39:25 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-09-13 18:39:26 --> Config Class Initialized
DEBUG - 2011-09-13 18:39:26 --> Hooks Class Initialized
DEBUG - 2011-09-13 18:39:26 --> Utf8 Class Initialized
DEBUG - 2011-09-13 18:39:26 --> UTF-8 Support Enabled
DEBUG - 2011-09-13 18:39:26 --> URI Class Initialized
DEBUG - 2011-09-13 18:39:26 --> Router Class Initialized
ERROR - 2011-09-13 18:39:26 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-09-13 18:39:30 --> Config Class Initialized
DEBUG - 2011-09-13 18:39:30 --> Hooks Class Initialized
DEBUG - 2011-09-13 18:39:30 --> Utf8 Class Initialized
DEBUG - 2011-09-13 18:39:30 --> UTF-8 Support Enabled
DEBUG - 2011-09-13 18:39:30 --> URI Class Initialized
DEBUG - 2011-09-13 18:39:30 --> Router Class Initialized
DEBUG - 2011-09-13 18:39:30 --> Output Class Initialized
DEBUG - 2011-09-13 18:39:30 --> Input Class Initialized
DEBUG - 2011-09-13 18:39:30 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-13 18:39:30 --> Language Class Initialized
DEBUG - 2011-09-13 18:39:30 --> Loader Class Initialized
DEBUG - 2011-09-13 18:39:30 --> Controller Class Initialized
ERROR - 2011-09-13 18:39:30 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-09-13 18:39:30 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-09-13 18:39:30 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-09-13 18:39:30 --> Model Class Initialized
DEBUG - 2011-09-13 18:39:30 --> Model Class Initialized
DEBUG - 2011-09-13 18:39:30 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-13 18:39:30 --> Database Driver Class Initialized
DEBUG - 2011-09-13 18:39:30 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-09-13 18:39:30 --> Helper loaded: url_helper
DEBUG - 2011-09-13 18:39:30 --> File loaded: application/views/common/header.php
DEBUG - 2011-09-13 18:39:30 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-09-13 18:39:30 --> File loaded: application/views/common/footer.php
DEBUG - 2011-09-13 18:39:30 --> File loaded: application/views/layout/main.php
DEBUG - 2011-09-13 18:39:30 --> Final output sent to browser
DEBUG - 2011-09-13 18:39:30 --> Total execution time: 0.0608
DEBUG - 2011-09-13 18:39:31 --> Config Class Initialized
DEBUG - 2011-09-13 18:39:31 --> Hooks Class Initialized
DEBUG - 2011-09-13 18:39:31 --> Utf8 Class Initialized
DEBUG - 2011-09-13 18:39:31 --> UTF-8 Support Enabled
DEBUG - 2011-09-13 18:39:31 --> URI Class Initialized
DEBUG - 2011-09-13 18:39:31 --> Router Class Initialized
DEBUG - 2011-09-13 18:39:31 --> Output Class Initialized
DEBUG - 2011-09-13 18:39:31 --> Input Class Initialized
DEBUG - 2011-09-13 18:39:31 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-13 18:39:31 --> Language Class Initialized
DEBUG - 2011-09-13 18:39:31 --> Loader Class Initialized
DEBUG - 2011-09-13 18:39:31 --> Controller Class Initialized
DEBUG - 2011-09-13 18:39:31 --> Model Class Initialized
DEBUG - 2011-09-13 18:39:31 --> Model Class Initialized
DEBUG - 2011-09-13 18:39:31 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-13 18:39:31 --> Database Driver Class Initialized
DEBUG - 2011-09-13 18:39:32 --> Final output sent to browser
DEBUG - 2011-09-13 18:39:32 --> Total execution time: 0.6753
DEBUG - 2011-09-13 18:39:35 --> Config Class Initialized
DEBUG - 2011-09-13 18:39:35 --> Hooks Class Initialized
DEBUG - 2011-09-13 18:39:35 --> Utf8 Class Initialized
DEBUG - 2011-09-13 18:39:35 --> UTF-8 Support Enabled
DEBUG - 2011-09-13 18:39:35 --> URI Class Initialized
DEBUG - 2011-09-13 18:39:35 --> Router Class Initialized
ERROR - 2011-09-13 18:39:35 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-09-13 18:39:39 --> Config Class Initialized
DEBUG - 2011-09-13 18:39:39 --> Hooks Class Initialized
DEBUG - 2011-09-13 18:39:39 --> Utf8 Class Initialized
DEBUG - 2011-09-13 18:39:39 --> UTF-8 Support Enabled
DEBUG - 2011-09-13 18:39:39 --> URI Class Initialized
DEBUG - 2011-09-13 18:39:39 --> Router Class Initialized
DEBUG - 2011-09-13 18:39:39 --> Output Class Initialized
DEBUG - 2011-09-13 18:39:39 --> Input Class Initialized
DEBUG - 2011-09-13 18:39:39 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-13 18:39:39 --> Language Class Initialized
DEBUG - 2011-09-13 18:39:39 --> Loader Class Initialized
DEBUG - 2011-09-13 18:39:39 --> Controller Class Initialized
ERROR - 2011-09-13 18:39:39 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-09-13 18:39:39 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-09-13 18:39:39 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-09-13 18:39:39 --> Model Class Initialized
DEBUG - 2011-09-13 18:39:39 --> Model Class Initialized
DEBUG - 2011-09-13 18:39:39 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-13 18:39:39 --> Database Driver Class Initialized
DEBUG - 2011-09-13 18:39:39 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-09-13 18:39:39 --> Helper loaded: url_helper
DEBUG - 2011-09-13 18:39:39 --> File loaded: application/views/common/header.php
DEBUG - 2011-09-13 18:39:39 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-09-13 18:39:39 --> File loaded: application/views/common/footer.php
DEBUG - 2011-09-13 18:39:39 --> File loaded: application/views/layout/main.php
DEBUG - 2011-09-13 18:39:39 --> Final output sent to browser
DEBUG - 2011-09-13 18:39:39 --> Total execution time: 0.0905
DEBUG - 2011-09-13 18:39:40 --> Config Class Initialized
DEBUG - 2011-09-13 18:39:40 --> Hooks Class Initialized
DEBUG - 2011-09-13 18:39:40 --> Utf8 Class Initialized
DEBUG - 2011-09-13 18:39:40 --> UTF-8 Support Enabled
DEBUG - 2011-09-13 18:39:40 --> URI Class Initialized
DEBUG - 2011-09-13 18:39:40 --> Router Class Initialized
DEBUG - 2011-09-13 18:39:40 --> Output Class Initialized
DEBUG - 2011-09-13 18:39:40 --> Input Class Initialized
DEBUG - 2011-09-13 18:39:40 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-13 18:39:40 --> Language Class Initialized
DEBUG - 2011-09-13 18:39:40 --> Loader Class Initialized
DEBUG - 2011-09-13 18:39:40 --> Controller Class Initialized
DEBUG - 2011-09-13 18:39:40 --> Model Class Initialized
DEBUG - 2011-09-13 18:39:40 --> Model Class Initialized
DEBUG - 2011-09-13 18:39:40 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-13 18:39:40 --> Database Driver Class Initialized
DEBUG - 2011-09-13 18:39:40 --> Final output sent to browser
DEBUG - 2011-09-13 18:39:40 --> Total execution time: 0.5532
DEBUG - 2011-09-13 18:39:44 --> Config Class Initialized
DEBUG - 2011-09-13 18:39:44 --> Hooks Class Initialized
DEBUG - 2011-09-13 18:39:44 --> Utf8 Class Initialized
DEBUG - 2011-09-13 18:39:44 --> UTF-8 Support Enabled
DEBUG - 2011-09-13 18:39:44 --> URI Class Initialized
DEBUG - 2011-09-13 18:39:44 --> Router Class Initialized
ERROR - 2011-09-13 18:39:44 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-09-13 18:58:20 --> Config Class Initialized
DEBUG - 2011-09-13 18:58:20 --> Hooks Class Initialized
DEBUG - 2011-09-13 18:58:20 --> Utf8 Class Initialized
DEBUG - 2011-09-13 18:58:20 --> UTF-8 Support Enabled
DEBUG - 2011-09-13 18:58:20 --> URI Class Initialized
DEBUG - 2011-09-13 18:58:20 --> Router Class Initialized
DEBUG - 2011-09-13 18:58:20 --> Output Class Initialized
DEBUG - 2011-09-13 18:58:20 --> Input Class Initialized
DEBUG - 2011-09-13 18:58:20 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-13 18:58:20 --> Language Class Initialized
DEBUG - 2011-09-13 18:58:20 --> Loader Class Initialized
DEBUG - 2011-09-13 18:58:20 --> Controller Class Initialized
ERROR - 2011-09-13 18:58:20 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-09-13 18:58:20 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-09-13 18:58:20 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-09-13 18:58:20 --> Model Class Initialized
DEBUG - 2011-09-13 18:58:20 --> Model Class Initialized
DEBUG - 2011-09-13 18:58:20 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-13 18:58:20 --> Database Driver Class Initialized
DEBUG - 2011-09-13 18:58:20 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-09-13 18:58:20 --> Helper loaded: url_helper
DEBUG - 2011-09-13 18:58:20 --> File loaded: application/views/common/header.php
DEBUG - 2011-09-13 18:58:20 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-09-13 18:58:20 --> File loaded: application/views/common/footer.php
DEBUG - 2011-09-13 18:58:20 --> File loaded: application/views/layout/main.php
DEBUG - 2011-09-13 18:58:20 --> Final output sent to browser
DEBUG - 2011-09-13 18:58:20 --> Total execution time: 0.0380
DEBUG - 2011-09-13 18:58:22 --> Config Class Initialized
DEBUG - 2011-09-13 18:58:22 --> Hooks Class Initialized
DEBUG - 2011-09-13 18:58:22 --> Utf8 Class Initialized
DEBUG - 2011-09-13 18:58:22 --> UTF-8 Support Enabled
DEBUG - 2011-09-13 18:58:22 --> URI Class Initialized
DEBUG - 2011-09-13 18:58:22 --> Router Class Initialized
DEBUG - 2011-09-13 18:58:22 --> Output Class Initialized
DEBUG - 2011-09-13 18:58:22 --> Input Class Initialized
DEBUG - 2011-09-13 18:58:22 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-13 18:58:22 --> Language Class Initialized
DEBUG - 2011-09-13 18:58:22 --> Loader Class Initialized
DEBUG - 2011-09-13 18:58:22 --> Controller Class Initialized
DEBUG - 2011-09-13 18:58:22 --> Model Class Initialized
DEBUG - 2011-09-13 18:58:22 --> Model Class Initialized
DEBUG - 2011-09-13 18:58:22 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-13 18:58:22 --> Database Driver Class Initialized
DEBUG - 2011-09-13 18:58:22 --> Final output sent to browser
DEBUG - 2011-09-13 18:58:22 --> Total execution time: 0.6146
DEBUG - 2011-09-13 18:58:23 --> Config Class Initialized
DEBUG - 2011-09-13 18:58:23 --> Hooks Class Initialized
DEBUG - 2011-09-13 18:58:23 --> Utf8 Class Initialized
DEBUG - 2011-09-13 18:58:23 --> UTF-8 Support Enabled
DEBUG - 2011-09-13 18:58:23 --> URI Class Initialized
DEBUG - 2011-09-13 18:58:23 --> Router Class Initialized
ERROR - 2011-09-13 18:58:23 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-09-13 18:58:25 --> Config Class Initialized
DEBUG - 2011-09-13 18:58:25 --> Hooks Class Initialized
DEBUG - 2011-09-13 18:58:25 --> Utf8 Class Initialized
DEBUG - 2011-09-13 18:58:25 --> UTF-8 Support Enabled
DEBUG - 2011-09-13 18:58:25 --> URI Class Initialized
DEBUG - 2011-09-13 18:58:25 --> Router Class Initialized
ERROR - 2011-09-13 18:58:25 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-09-13 18:59:44 --> Config Class Initialized
DEBUG - 2011-09-13 18:59:44 --> Hooks Class Initialized
DEBUG - 2011-09-13 18:59:44 --> Utf8 Class Initialized
DEBUG - 2011-09-13 18:59:44 --> UTF-8 Support Enabled
DEBUG - 2011-09-13 18:59:44 --> URI Class Initialized
DEBUG - 2011-09-13 18:59:44 --> Router Class Initialized
DEBUG - 2011-09-13 18:59:44 --> Output Class Initialized
DEBUG - 2011-09-13 18:59:44 --> Input Class Initialized
DEBUG - 2011-09-13 18:59:44 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-13 18:59:44 --> Language Class Initialized
DEBUG - 2011-09-13 18:59:44 --> Loader Class Initialized
DEBUG - 2011-09-13 18:59:44 --> Controller Class Initialized
DEBUG - 2011-09-13 18:59:44 --> Model Class Initialized
DEBUG - 2011-09-13 18:59:44 --> Model Class Initialized
DEBUG - 2011-09-13 18:59:44 --> Model Class Initialized
DEBUG - 2011-09-13 18:59:44 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-13 18:59:44 --> Database Driver Class Initialized
DEBUG - 2011-09-13 18:59:45 --> File loaded: application/views/table/main.php
DEBUG - 2011-09-13 18:59:45 --> Helper loaded: url_helper
DEBUG - 2011-09-13 18:59:45 --> File loaded: application/views/common/header.php
DEBUG - 2011-09-13 18:59:45 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-09-13 18:59:45 --> File loaded: application/views/common/footer.php
DEBUG - 2011-09-13 18:59:45 --> File loaded: application/views/layout/main.php
DEBUG - 2011-09-13 18:59:45 --> Final output sent to browser
DEBUG - 2011-09-13 18:59:45 --> Total execution time: 0.6197
DEBUG - 2011-09-13 19:41:36 --> Config Class Initialized
DEBUG - 2011-09-13 19:41:36 --> Hooks Class Initialized
DEBUG - 2011-09-13 19:41:36 --> Utf8 Class Initialized
DEBUG - 2011-09-13 19:41:36 --> UTF-8 Support Enabled
DEBUG - 2011-09-13 19:41:36 --> URI Class Initialized
DEBUG - 2011-09-13 19:41:36 --> Router Class Initialized
DEBUG - 2011-09-13 19:41:36 --> Output Class Initialized
DEBUG - 2011-09-13 19:41:36 --> Input Class Initialized
DEBUG - 2011-09-13 19:41:36 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-13 19:41:36 --> Language Class Initialized
DEBUG - 2011-09-13 19:41:36 --> Loader Class Initialized
DEBUG - 2011-09-13 19:41:36 --> Controller Class Initialized
ERROR - 2011-09-13 19:41:36 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-09-13 19:41:36 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-09-13 19:41:36 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-09-13 19:41:36 --> Model Class Initialized
DEBUG - 2011-09-13 19:41:36 --> Model Class Initialized
DEBUG - 2011-09-13 19:41:36 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-13 19:41:36 --> Database Driver Class Initialized
DEBUG - 2011-09-13 19:41:36 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-09-13 19:41:36 --> Helper loaded: url_helper
DEBUG - 2011-09-13 19:41:36 --> File loaded: application/views/common/header.php
DEBUG - 2011-09-13 19:41:36 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-09-13 19:41:36 --> File loaded: application/views/common/footer.php
DEBUG - 2011-09-13 19:41:36 --> File loaded: application/views/layout/main.php
DEBUG - 2011-09-13 19:41:36 --> Final output sent to browser
DEBUG - 2011-09-13 19:41:36 --> Total execution time: 0.0973
DEBUG - 2011-09-13 19:41:46 --> Config Class Initialized
DEBUG - 2011-09-13 19:41:46 --> Hooks Class Initialized
DEBUG - 2011-09-13 19:41:46 --> Utf8 Class Initialized
DEBUG - 2011-09-13 19:41:46 --> UTF-8 Support Enabled
DEBUG - 2011-09-13 19:41:46 --> URI Class Initialized
DEBUG - 2011-09-13 19:41:46 --> Router Class Initialized
DEBUG - 2011-09-13 19:41:46 --> Output Class Initialized
DEBUG - 2011-09-13 19:41:46 --> Input Class Initialized
DEBUG - 2011-09-13 19:41:46 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-13 19:41:46 --> Language Class Initialized
DEBUG - 2011-09-13 19:41:46 --> Loader Class Initialized
DEBUG - 2011-09-13 19:41:46 --> Controller Class Initialized
DEBUG - 2011-09-13 19:41:46 --> Model Class Initialized
DEBUG - 2011-09-13 19:41:46 --> Model Class Initialized
DEBUG - 2011-09-13 19:41:46 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-13 19:41:46 --> Database Driver Class Initialized
DEBUG - 2011-09-13 19:41:47 --> Final output sent to browser
DEBUG - 2011-09-13 19:41:47 --> Total execution time: 0.8852
DEBUG - 2011-09-13 19:41:52 --> Config Class Initialized
DEBUG - 2011-09-13 19:41:52 --> Hooks Class Initialized
DEBUG - 2011-09-13 19:41:52 --> Utf8 Class Initialized
DEBUG - 2011-09-13 19:41:52 --> UTF-8 Support Enabled
DEBUG - 2011-09-13 19:41:52 --> URI Class Initialized
DEBUG - 2011-09-13 19:41:52 --> Router Class Initialized
ERROR - 2011-09-13 19:41:52 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-09-13 19:42:06 --> Config Class Initialized
DEBUG - 2011-09-13 19:42:06 --> Hooks Class Initialized
DEBUG - 2011-09-13 19:42:06 --> Utf8 Class Initialized
DEBUG - 2011-09-13 19:42:06 --> UTF-8 Support Enabled
DEBUG - 2011-09-13 19:42:06 --> URI Class Initialized
DEBUG - 2011-09-13 19:42:06 --> Router Class Initialized
DEBUG - 2011-09-13 19:42:06 --> Output Class Initialized
DEBUG - 2011-09-13 19:42:06 --> Input Class Initialized
DEBUG - 2011-09-13 19:42:06 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-13 19:42:06 --> Language Class Initialized
DEBUG - 2011-09-13 19:42:06 --> Loader Class Initialized
DEBUG - 2011-09-13 19:42:06 --> Controller Class Initialized
ERROR - 2011-09-13 19:42:06 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-09-13 19:42:06 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-09-13 19:42:06 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-09-13 19:42:06 --> Model Class Initialized
DEBUG - 2011-09-13 19:42:06 --> Model Class Initialized
DEBUG - 2011-09-13 19:42:06 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-13 19:42:06 --> Database Driver Class Initialized
DEBUG - 2011-09-13 19:42:06 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-09-13 19:42:06 --> Helper loaded: url_helper
DEBUG - 2011-09-13 19:42:06 --> File loaded: application/views/common/header.php
DEBUG - 2011-09-13 19:42:06 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-09-13 19:42:06 --> File loaded: application/views/common/footer.php
DEBUG - 2011-09-13 19:42:06 --> File loaded: application/views/layout/main.php
DEBUG - 2011-09-13 19:42:06 --> Final output sent to browser
DEBUG - 2011-09-13 19:42:06 --> Total execution time: 0.0540
DEBUG - 2011-09-13 19:42:07 --> Config Class Initialized
DEBUG - 2011-09-13 19:42:07 --> Hooks Class Initialized
DEBUG - 2011-09-13 19:42:07 --> Utf8 Class Initialized
DEBUG - 2011-09-13 19:42:07 --> UTF-8 Support Enabled
DEBUG - 2011-09-13 19:42:07 --> URI Class Initialized
DEBUG - 2011-09-13 19:42:07 --> Router Class Initialized
DEBUG - 2011-09-13 19:42:07 --> Output Class Initialized
DEBUG - 2011-09-13 19:42:07 --> Input Class Initialized
DEBUG - 2011-09-13 19:42:07 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-13 19:42:07 --> Language Class Initialized
DEBUG - 2011-09-13 19:42:07 --> Loader Class Initialized
DEBUG - 2011-09-13 19:42:07 --> Controller Class Initialized
DEBUG - 2011-09-13 19:42:07 --> Model Class Initialized
DEBUG - 2011-09-13 19:42:07 --> Model Class Initialized
DEBUG - 2011-09-13 19:42:07 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-13 19:42:07 --> Database Driver Class Initialized
DEBUG - 2011-09-13 19:42:08 --> Final output sent to browser
DEBUG - 2011-09-13 19:42:08 --> Total execution time: 0.9354
DEBUG - 2011-09-13 19:42:10 --> Config Class Initialized
DEBUG - 2011-09-13 19:42:10 --> Hooks Class Initialized
DEBUG - 2011-09-13 19:42:10 --> Utf8 Class Initialized
DEBUG - 2011-09-13 19:42:10 --> UTF-8 Support Enabled
DEBUG - 2011-09-13 19:42:10 --> URI Class Initialized
DEBUG - 2011-09-13 19:42:10 --> Router Class Initialized
ERROR - 2011-09-13 19:42:10 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-09-13 19:48:23 --> Config Class Initialized
DEBUG - 2011-09-13 19:48:23 --> Hooks Class Initialized
DEBUG - 2011-09-13 19:48:23 --> Utf8 Class Initialized
DEBUG - 2011-09-13 19:48:23 --> UTF-8 Support Enabled
DEBUG - 2011-09-13 19:48:23 --> URI Class Initialized
DEBUG - 2011-09-13 19:48:23 --> Router Class Initialized
DEBUG - 2011-09-13 19:48:23 --> Output Class Initialized
DEBUG - 2011-09-13 19:48:23 --> Input Class Initialized
DEBUG - 2011-09-13 19:48:23 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-13 19:48:23 --> Language Class Initialized
DEBUG - 2011-09-13 19:48:23 --> Loader Class Initialized
DEBUG - 2011-09-13 19:48:23 --> Controller Class Initialized
ERROR - 2011-09-13 19:48:23 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-09-13 19:48:23 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-09-13 19:48:23 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-09-13 19:48:23 --> Model Class Initialized
DEBUG - 2011-09-13 19:48:23 --> Model Class Initialized
DEBUG - 2011-09-13 19:48:23 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-13 19:48:23 --> Database Driver Class Initialized
DEBUG - 2011-09-13 19:48:23 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-09-13 19:48:23 --> Helper loaded: url_helper
DEBUG - 2011-09-13 19:48:23 --> File loaded: application/views/common/header.php
DEBUG - 2011-09-13 19:48:23 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-09-13 19:48:23 --> File loaded: application/views/common/footer.php
DEBUG - 2011-09-13 19:48:23 --> File loaded: application/views/layout/main.php
DEBUG - 2011-09-13 19:48:23 --> Final output sent to browser
DEBUG - 2011-09-13 19:48:23 --> Total execution time: 0.0486
DEBUG - 2011-09-13 19:48:24 --> Config Class Initialized
DEBUG - 2011-09-13 19:48:24 --> Hooks Class Initialized
DEBUG - 2011-09-13 19:48:24 --> Utf8 Class Initialized
DEBUG - 2011-09-13 19:48:24 --> UTF-8 Support Enabled
DEBUG - 2011-09-13 19:48:24 --> URI Class Initialized
DEBUG - 2011-09-13 19:48:24 --> Router Class Initialized
DEBUG - 2011-09-13 19:48:24 --> Output Class Initialized
DEBUG - 2011-09-13 19:48:24 --> Input Class Initialized
DEBUG - 2011-09-13 19:48:24 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-13 19:48:24 --> Language Class Initialized
DEBUG - 2011-09-13 19:48:24 --> Loader Class Initialized
DEBUG - 2011-09-13 19:48:24 --> Controller Class Initialized
DEBUG - 2011-09-13 19:48:24 --> Model Class Initialized
DEBUG - 2011-09-13 19:48:24 --> Model Class Initialized
DEBUG - 2011-09-13 19:48:24 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-13 19:48:24 --> Database Driver Class Initialized
DEBUG - 2011-09-13 19:48:26 --> Final output sent to browser
DEBUG - 2011-09-13 19:48:26 --> Total execution time: 1.3434
DEBUG - 2011-09-13 19:48:27 --> Config Class Initialized
DEBUG - 2011-09-13 19:48:27 --> Hooks Class Initialized
DEBUG - 2011-09-13 19:48:27 --> Utf8 Class Initialized
DEBUG - 2011-09-13 19:48:27 --> UTF-8 Support Enabled
DEBUG - 2011-09-13 19:48:27 --> URI Class Initialized
DEBUG - 2011-09-13 19:48:27 --> Router Class Initialized
ERROR - 2011-09-13 19:48:27 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-09-13 19:48:47 --> Config Class Initialized
DEBUG - 2011-09-13 19:48:47 --> Hooks Class Initialized
DEBUG - 2011-09-13 19:48:47 --> Utf8 Class Initialized
DEBUG - 2011-09-13 19:48:47 --> UTF-8 Support Enabled
DEBUG - 2011-09-13 19:48:47 --> URI Class Initialized
DEBUG - 2011-09-13 19:48:47 --> Router Class Initialized
DEBUG - 2011-09-13 19:48:47 --> Output Class Initialized
DEBUG - 2011-09-13 19:48:47 --> Input Class Initialized
DEBUG - 2011-09-13 19:48:47 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-13 19:48:47 --> Language Class Initialized
DEBUG - 2011-09-13 19:48:47 --> Loader Class Initialized
DEBUG - 2011-09-13 19:48:47 --> Controller Class Initialized
ERROR - 2011-09-13 19:48:47 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-09-13 19:48:47 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-09-13 19:48:47 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-09-13 19:48:47 --> Model Class Initialized
DEBUG - 2011-09-13 19:48:47 --> Model Class Initialized
DEBUG - 2011-09-13 19:48:47 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-13 19:48:47 --> Database Driver Class Initialized
DEBUG - 2011-09-13 19:48:47 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-09-13 19:48:47 --> Helper loaded: url_helper
DEBUG - 2011-09-13 19:48:47 --> File loaded: application/views/common/header.php
DEBUG - 2011-09-13 19:48:47 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-09-13 19:48:47 --> File loaded: application/views/common/footer.php
DEBUG - 2011-09-13 19:48:47 --> File loaded: application/views/layout/main.php
DEBUG - 2011-09-13 19:48:47 --> Final output sent to browser
DEBUG - 2011-09-13 19:48:47 --> Total execution time: 0.1112
DEBUG - 2011-09-13 19:48:49 --> Config Class Initialized
DEBUG - 2011-09-13 19:48:49 --> Hooks Class Initialized
DEBUG - 2011-09-13 19:48:49 --> Utf8 Class Initialized
DEBUG - 2011-09-13 19:48:49 --> UTF-8 Support Enabled
DEBUG - 2011-09-13 19:48:49 --> URI Class Initialized
DEBUG - 2011-09-13 19:48:49 --> Router Class Initialized
DEBUG - 2011-09-13 19:48:49 --> Output Class Initialized
DEBUG - 2011-09-13 19:48:49 --> Input Class Initialized
DEBUG - 2011-09-13 19:48:49 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-13 19:48:49 --> Language Class Initialized
DEBUG - 2011-09-13 19:48:49 --> Loader Class Initialized
DEBUG - 2011-09-13 19:48:49 --> Controller Class Initialized
DEBUG - 2011-09-13 19:48:49 --> Model Class Initialized
DEBUG - 2011-09-13 19:48:49 --> Model Class Initialized
DEBUG - 2011-09-13 19:48:49 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-13 19:48:49 --> Database Driver Class Initialized
DEBUG - 2011-09-13 19:48:50 --> Final output sent to browser
DEBUG - 2011-09-13 19:48:50 --> Total execution time: 0.5620
DEBUG - 2011-09-13 20:31:30 --> Config Class Initialized
DEBUG - 2011-09-13 20:31:30 --> Hooks Class Initialized
DEBUG - 2011-09-13 20:31:30 --> Utf8 Class Initialized
DEBUG - 2011-09-13 20:31:30 --> UTF-8 Support Enabled
DEBUG - 2011-09-13 20:31:30 --> URI Class Initialized
DEBUG - 2011-09-13 20:31:30 --> Router Class Initialized
DEBUG - 2011-09-13 20:31:30 --> Output Class Initialized
DEBUG - 2011-09-13 20:31:30 --> Input Class Initialized
DEBUG - 2011-09-13 20:31:30 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-13 20:31:30 --> Language Class Initialized
DEBUG - 2011-09-13 20:31:30 --> Loader Class Initialized
DEBUG - 2011-09-13 20:31:30 --> Controller Class Initialized
ERROR - 2011-09-13 20:31:30 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-09-13 20:31:30 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-09-13 20:31:30 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-09-13 20:31:30 --> Model Class Initialized
DEBUG - 2011-09-13 20:31:30 --> Model Class Initialized
DEBUG - 2011-09-13 20:31:30 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-13 20:31:30 --> Database Driver Class Initialized
DEBUG - 2011-09-13 20:31:30 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-09-13 20:31:30 --> Helper loaded: url_helper
DEBUG - 2011-09-13 20:31:30 --> File loaded: application/views/common/header.php
DEBUG - 2011-09-13 20:31:30 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-09-13 20:31:30 --> File loaded: application/views/common/footer.php
DEBUG - 2011-09-13 20:31:30 --> File loaded: application/views/layout/main.php
DEBUG - 2011-09-13 20:31:30 --> Final output sent to browser
DEBUG - 2011-09-13 20:31:30 --> Total execution time: 0.1979
DEBUG - 2011-09-13 20:31:34 --> Config Class Initialized
DEBUG - 2011-09-13 20:31:34 --> Hooks Class Initialized
DEBUG - 2011-09-13 20:31:34 --> Utf8 Class Initialized
DEBUG - 2011-09-13 20:31:34 --> UTF-8 Support Enabled
DEBUG - 2011-09-13 20:31:34 --> URI Class Initialized
DEBUG - 2011-09-13 20:31:34 --> Router Class Initialized
DEBUG - 2011-09-13 20:31:34 --> Output Class Initialized
DEBUG - 2011-09-13 20:31:34 --> Input Class Initialized
DEBUG - 2011-09-13 20:31:34 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-13 20:31:34 --> Language Class Initialized
DEBUG - 2011-09-13 20:31:34 --> Loader Class Initialized
DEBUG - 2011-09-13 20:31:34 --> Controller Class Initialized
DEBUG - 2011-09-13 20:31:34 --> Model Class Initialized
DEBUG - 2011-09-13 20:31:34 --> Model Class Initialized
DEBUG - 2011-09-13 20:31:34 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-13 20:31:34 --> Database Driver Class Initialized
DEBUG - 2011-09-13 20:31:35 --> Final output sent to browser
DEBUG - 2011-09-13 20:31:35 --> Total execution time: 0.7903
DEBUG - 2011-09-13 21:11:08 --> Config Class Initialized
DEBUG - 2011-09-13 21:11:08 --> Hooks Class Initialized
DEBUG - 2011-09-13 21:11:08 --> Utf8 Class Initialized
DEBUG - 2011-09-13 21:11:08 --> UTF-8 Support Enabled
DEBUG - 2011-09-13 21:11:08 --> URI Class Initialized
DEBUG - 2011-09-13 21:11:08 --> Router Class Initialized
DEBUG - 2011-09-13 21:11:08 --> Output Class Initialized
DEBUG - 2011-09-13 21:11:08 --> Input Class Initialized
DEBUG - 2011-09-13 21:11:08 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-13 21:11:08 --> Language Class Initialized
DEBUG - 2011-09-13 21:11:08 --> Loader Class Initialized
DEBUG - 2011-09-13 21:11:08 --> Controller Class Initialized
ERROR - 2011-09-13 21:11:08 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-09-13 21:11:08 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-09-13 21:11:08 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-09-13 21:11:08 --> Model Class Initialized
DEBUG - 2011-09-13 21:11:08 --> Model Class Initialized
DEBUG - 2011-09-13 21:11:08 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-13 21:11:08 --> Database Driver Class Initialized
DEBUG - 2011-09-13 21:11:08 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-09-13 21:11:08 --> Helper loaded: url_helper
DEBUG - 2011-09-13 21:11:08 --> File loaded: application/views/common/header.php
DEBUG - 2011-09-13 21:11:08 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-09-13 21:11:08 --> File loaded: application/views/common/footer.php
DEBUG - 2011-09-13 21:11:08 --> File loaded: application/views/layout/main.php
DEBUG - 2011-09-13 21:11:08 --> Final output sent to browser
DEBUG - 2011-09-13 21:11:08 --> Total execution time: 0.0839
DEBUG - 2011-09-13 21:11:10 --> Config Class Initialized
DEBUG - 2011-09-13 21:11:10 --> Hooks Class Initialized
DEBUG - 2011-09-13 21:11:10 --> Utf8 Class Initialized
DEBUG - 2011-09-13 21:11:10 --> UTF-8 Support Enabled
DEBUG - 2011-09-13 21:11:10 --> URI Class Initialized
DEBUG - 2011-09-13 21:11:10 --> Router Class Initialized
DEBUG - 2011-09-13 21:11:10 --> Output Class Initialized
DEBUG - 2011-09-13 21:11:10 --> Input Class Initialized
DEBUG - 2011-09-13 21:11:10 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-13 21:11:10 --> Language Class Initialized
DEBUG - 2011-09-13 21:11:10 --> Loader Class Initialized
DEBUG - 2011-09-13 21:11:10 --> Controller Class Initialized
DEBUG - 2011-09-13 21:11:10 --> Model Class Initialized
DEBUG - 2011-09-13 21:11:10 --> Model Class Initialized
DEBUG - 2011-09-13 21:11:10 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-13 21:11:10 --> Database Driver Class Initialized
DEBUG - 2011-09-13 21:11:11 --> Final output sent to browser
DEBUG - 2011-09-13 21:11:11 --> Total execution time: 0.6108
DEBUG - 2011-09-13 21:11:16 --> Config Class Initialized
DEBUG - 2011-09-13 21:11:16 --> Hooks Class Initialized
DEBUG - 2011-09-13 21:11:16 --> Utf8 Class Initialized
DEBUG - 2011-09-13 21:11:16 --> UTF-8 Support Enabled
DEBUG - 2011-09-13 21:11:16 --> URI Class Initialized
DEBUG - 2011-09-13 21:11:16 --> Router Class Initialized
ERROR - 2011-09-13 21:11:16 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-09-13 21:11:24 --> Config Class Initialized
DEBUG - 2011-09-13 21:11:24 --> Hooks Class Initialized
DEBUG - 2011-09-13 21:11:24 --> Utf8 Class Initialized
DEBUG - 2011-09-13 21:11:24 --> UTF-8 Support Enabled
DEBUG - 2011-09-13 21:11:24 --> URI Class Initialized
DEBUG - 2011-09-13 21:11:24 --> Router Class Initialized
DEBUG - 2011-09-13 21:11:24 --> Output Class Initialized
DEBUG - 2011-09-13 21:11:24 --> Input Class Initialized
DEBUG - 2011-09-13 21:11:24 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-13 21:11:24 --> Language Class Initialized
DEBUG - 2011-09-13 21:11:24 --> Loader Class Initialized
DEBUG - 2011-09-13 21:11:24 --> Controller Class Initialized
ERROR - 2011-09-13 21:11:24 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-09-13 21:11:24 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-09-13 21:11:24 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-09-13 21:11:24 --> Model Class Initialized
DEBUG - 2011-09-13 21:11:24 --> Model Class Initialized
DEBUG - 2011-09-13 21:11:24 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-13 21:11:24 --> Database Driver Class Initialized
DEBUG - 2011-09-13 21:11:24 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-09-13 21:11:24 --> Helper loaded: url_helper
DEBUG - 2011-09-13 21:11:24 --> File loaded: application/views/common/header.php
DEBUG - 2011-09-13 21:11:24 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-09-13 21:11:24 --> File loaded: application/views/common/footer.php
DEBUG - 2011-09-13 21:11:24 --> File loaded: application/views/layout/main.php
DEBUG - 2011-09-13 21:11:24 --> Final output sent to browser
DEBUG - 2011-09-13 21:11:24 --> Total execution time: 0.1589
DEBUG - 2011-09-13 21:11:25 --> Config Class Initialized
DEBUG - 2011-09-13 21:11:25 --> Hooks Class Initialized
DEBUG - 2011-09-13 21:11:25 --> Utf8 Class Initialized
DEBUG - 2011-09-13 21:11:25 --> UTF-8 Support Enabled
DEBUG - 2011-09-13 21:11:25 --> URI Class Initialized
DEBUG - 2011-09-13 21:11:25 --> Router Class Initialized
DEBUG - 2011-09-13 21:11:25 --> Output Class Initialized
DEBUG - 2011-09-13 21:11:25 --> Input Class Initialized
DEBUG - 2011-09-13 21:11:25 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-13 21:11:25 --> Language Class Initialized
DEBUG - 2011-09-13 21:11:25 --> Loader Class Initialized
DEBUG - 2011-09-13 21:11:25 --> Controller Class Initialized
DEBUG - 2011-09-13 21:11:25 --> Model Class Initialized
DEBUG - 2011-09-13 21:11:25 --> Model Class Initialized
DEBUG - 2011-09-13 21:11:25 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-13 21:11:26 --> Database Driver Class Initialized
DEBUG - 2011-09-13 21:11:26 --> Final output sent to browser
DEBUG - 2011-09-13 21:11:26 --> Total execution time: 0.6820
DEBUG - 2011-09-13 21:11:28 --> Config Class Initialized
DEBUG - 2011-09-13 21:11:28 --> Hooks Class Initialized
DEBUG - 2011-09-13 21:11:28 --> Utf8 Class Initialized
DEBUG - 2011-09-13 21:11:28 --> UTF-8 Support Enabled
DEBUG - 2011-09-13 21:11:28 --> URI Class Initialized
DEBUG - 2011-09-13 21:11:28 --> Router Class Initialized
ERROR - 2011-09-13 21:11:28 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-09-13 21:11:45 --> Config Class Initialized
DEBUG - 2011-09-13 21:11:45 --> Hooks Class Initialized
DEBUG - 2011-09-13 21:11:45 --> Utf8 Class Initialized
DEBUG - 2011-09-13 21:11:45 --> UTF-8 Support Enabled
DEBUG - 2011-09-13 21:11:45 --> URI Class Initialized
DEBUG - 2011-09-13 21:11:45 --> Router Class Initialized
DEBUG - 2011-09-13 21:11:45 --> Output Class Initialized
DEBUG - 2011-09-13 21:11:45 --> Input Class Initialized
DEBUG - 2011-09-13 21:11:45 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-13 21:11:45 --> Language Class Initialized
DEBUG - 2011-09-13 21:11:45 --> Loader Class Initialized
DEBUG - 2011-09-13 21:11:45 --> Controller Class Initialized
ERROR - 2011-09-13 21:11:45 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-09-13 21:11:45 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-09-13 21:11:45 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-09-13 21:11:45 --> Model Class Initialized
DEBUG - 2011-09-13 21:11:45 --> Model Class Initialized
DEBUG - 2011-09-13 21:11:45 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-13 21:11:45 --> Database Driver Class Initialized
DEBUG - 2011-09-13 21:11:45 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-09-13 21:11:45 --> Helper loaded: url_helper
DEBUG - 2011-09-13 21:11:45 --> File loaded: application/views/common/header.php
DEBUG - 2011-09-13 21:11:45 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-09-13 21:11:45 --> File loaded: application/views/common/footer.php
DEBUG - 2011-09-13 21:11:45 --> File loaded: application/views/layout/main.php
DEBUG - 2011-09-13 21:11:45 --> Final output sent to browser
DEBUG - 2011-09-13 21:11:45 --> Total execution time: 0.0380
DEBUG - 2011-09-13 21:11:47 --> Config Class Initialized
DEBUG - 2011-09-13 21:11:47 --> Hooks Class Initialized
DEBUG - 2011-09-13 21:11:47 --> Utf8 Class Initialized
DEBUG - 2011-09-13 21:11:47 --> UTF-8 Support Enabled
DEBUG - 2011-09-13 21:11:47 --> URI Class Initialized
DEBUG - 2011-09-13 21:11:47 --> Router Class Initialized
DEBUG - 2011-09-13 21:11:47 --> Output Class Initialized
DEBUG - 2011-09-13 21:11:47 --> Input Class Initialized
DEBUG - 2011-09-13 21:11:47 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-13 21:11:47 --> Language Class Initialized
DEBUG - 2011-09-13 21:11:47 --> Loader Class Initialized
DEBUG - 2011-09-13 21:11:47 --> Controller Class Initialized
DEBUG - 2011-09-13 21:11:47 --> Model Class Initialized
DEBUG - 2011-09-13 21:11:47 --> Model Class Initialized
DEBUG - 2011-09-13 21:11:47 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-13 21:11:47 --> Database Driver Class Initialized
DEBUG - 2011-09-13 21:11:47 --> Final output sent to browser
DEBUG - 2011-09-13 21:11:47 --> Total execution time: 0.5174
DEBUG - 2011-09-13 21:11:51 --> Config Class Initialized
DEBUG - 2011-09-13 21:11:51 --> Hooks Class Initialized
DEBUG - 2011-09-13 21:11:51 --> Utf8 Class Initialized
DEBUG - 2011-09-13 21:11:51 --> UTF-8 Support Enabled
DEBUG - 2011-09-13 21:11:51 --> URI Class Initialized
DEBUG - 2011-09-13 21:11:51 --> Router Class Initialized
ERROR - 2011-09-13 21:11:51 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-09-13 21:12:01 --> Config Class Initialized
DEBUG - 2011-09-13 21:12:01 --> Hooks Class Initialized
DEBUG - 2011-09-13 21:12:01 --> Utf8 Class Initialized
DEBUG - 2011-09-13 21:12:01 --> UTF-8 Support Enabled
DEBUG - 2011-09-13 21:12:01 --> URI Class Initialized
DEBUG - 2011-09-13 21:12:01 --> Router Class Initialized
DEBUG - 2011-09-13 21:12:01 --> Output Class Initialized
DEBUG - 2011-09-13 21:12:01 --> Input Class Initialized
DEBUG - 2011-09-13 21:12:01 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-13 21:12:01 --> Language Class Initialized
DEBUG - 2011-09-13 21:12:01 --> Loader Class Initialized
DEBUG - 2011-09-13 21:12:01 --> Controller Class Initialized
ERROR - 2011-09-13 21:12:01 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-09-13 21:12:01 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-09-13 21:12:01 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-09-13 21:12:01 --> Model Class Initialized
DEBUG - 2011-09-13 21:12:01 --> Model Class Initialized
DEBUG - 2011-09-13 21:12:01 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-13 21:12:01 --> Database Driver Class Initialized
DEBUG - 2011-09-13 21:12:01 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-09-13 21:12:01 --> Helper loaded: url_helper
DEBUG - 2011-09-13 21:12:01 --> File loaded: application/views/common/header.php
DEBUG - 2011-09-13 21:12:01 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-09-13 21:12:01 --> File loaded: application/views/common/footer.php
DEBUG - 2011-09-13 21:12:01 --> File loaded: application/views/layout/main.php
DEBUG - 2011-09-13 21:12:01 --> Final output sent to browser
DEBUG - 2011-09-13 21:12:01 --> Total execution time: 0.0753
DEBUG - 2011-09-13 21:12:02 --> Config Class Initialized
DEBUG - 2011-09-13 21:12:02 --> Hooks Class Initialized
DEBUG - 2011-09-13 21:12:02 --> Utf8 Class Initialized
DEBUG - 2011-09-13 21:12:02 --> UTF-8 Support Enabled
DEBUG - 2011-09-13 21:12:02 --> URI Class Initialized
DEBUG - 2011-09-13 21:12:02 --> Router Class Initialized
DEBUG - 2011-09-13 21:12:02 --> Output Class Initialized
DEBUG - 2011-09-13 21:12:02 --> Input Class Initialized
DEBUG - 2011-09-13 21:12:02 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-13 21:12:02 --> Language Class Initialized
DEBUG - 2011-09-13 21:12:02 --> Loader Class Initialized
DEBUG - 2011-09-13 21:12:02 --> Controller Class Initialized
DEBUG - 2011-09-13 21:12:02 --> Model Class Initialized
DEBUG - 2011-09-13 21:12:02 --> Model Class Initialized
DEBUG - 2011-09-13 21:12:02 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-13 21:12:02 --> Database Driver Class Initialized
DEBUG - 2011-09-13 21:12:02 --> Final output sent to browser
DEBUG - 2011-09-13 21:12:02 --> Total execution time: 0.7427
DEBUG - 2011-09-13 21:12:07 --> Config Class Initialized
DEBUG - 2011-09-13 21:12:07 --> Hooks Class Initialized
DEBUG - 2011-09-13 21:12:07 --> Utf8 Class Initialized
DEBUG - 2011-09-13 21:12:07 --> UTF-8 Support Enabled
DEBUG - 2011-09-13 21:12:07 --> URI Class Initialized
DEBUG - 2011-09-13 21:12:07 --> Router Class Initialized
DEBUG - 2011-09-13 21:12:07 --> Output Class Initialized
DEBUG - 2011-09-13 21:12:07 --> Input Class Initialized
DEBUG - 2011-09-13 21:12:07 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-13 21:12:07 --> Language Class Initialized
DEBUG - 2011-09-13 21:12:07 --> Loader Class Initialized
DEBUG - 2011-09-13 21:12:07 --> Controller Class Initialized
ERROR - 2011-09-13 21:12:07 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-09-13 21:12:07 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-09-13 21:12:07 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-09-13 21:12:07 --> Model Class Initialized
DEBUG - 2011-09-13 21:12:07 --> Model Class Initialized
DEBUG - 2011-09-13 21:12:07 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-13 21:12:07 --> Database Driver Class Initialized
DEBUG - 2011-09-13 21:12:07 --> Config Class Initialized
DEBUG - 2011-09-13 21:12:07 --> Hooks Class Initialized
DEBUG - 2011-09-13 21:12:07 --> Utf8 Class Initialized
DEBUG - 2011-09-13 21:12:07 --> UTF-8 Support Enabled
DEBUG - 2011-09-13 21:12:07 --> URI Class Initialized
DEBUG - 2011-09-13 21:12:07 --> Router Class Initialized
ERROR - 2011-09-13 21:12:07 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-09-13 21:12:07 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-09-13 21:12:07 --> Helper loaded: url_helper
DEBUG - 2011-09-13 21:12:07 --> File loaded: application/views/common/header.php
DEBUG - 2011-09-13 21:12:07 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-09-13 21:12:07 --> File loaded: application/views/common/footer.php
DEBUG - 2011-09-13 21:12:07 --> File loaded: application/views/layout/main.php
DEBUG - 2011-09-13 21:12:07 --> Final output sent to browser
DEBUG - 2011-09-13 21:12:07 --> Total execution time: 0.0558
DEBUG - 2011-09-13 21:12:08 --> Config Class Initialized
DEBUG - 2011-09-13 21:12:08 --> Hooks Class Initialized
DEBUG - 2011-09-13 21:12:08 --> Utf8 Class Initialized
DEBUG - 2011-09-13 21:12:08 --> UTF-8 Support Enabled
DEBUG - 2011-09-13 21:12:08 --> URI Class Initialized
DEBUG - 2011-09-13 21:12:08 --> Router Class Initialized
DEBUG - 2011-09-13 21:12:08 --> Output Class Initialized
DEBUG - 2011-09-13 21:12:08 --> Input Class Initialized
DEBUG - 2011-09-13 21:12:08 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-13 21:12:08 --> Language Class Initialized
DEBUG - 2011-09-13 21:12:08 --> Loader Class Initialized
DEBUG - 2011-09-13 21:12:08 --> Controller Class Initialized
DEBUG - 2011-09-13 21:12:08 --> Model Class Initialized
DEBUG - 2011-09-13 21:12:08 --> Model Class Initialized
DEBUG - 2011-09-13 21:12:08 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-13 21:12:08 --> Database Driver Class Initialized
DEBUG - 2011-09-13 21:12:09 --> Final output sent to browser
DEBUG - 2011-09-13 21:12:09 --> Total execution time: 0.9189
DEBUG - 2011-09-13 21:12:12 --> Config Class Initialized
DEBUG - 2011-09-13 21:12:12 --> Hooks Class Initialized
DEBUG - 2011-09-13 21:12:12 --> Utf8 Class Initialized
DEBUG - 2011-09-13 21:12:12 --> UTF-8 Support Enabled
DEBUG - 2011-09-13 21:12:12 --> URI Class Initialized
DEBUG - 2011-09-13 21:12:12 --> Router Class Initialized
ERROR - 2011-09-13 21:12:12 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-09-13 21:12:16 --> Config Class Initialized
DEBUG - 2011-09-13 21:12:16 --> Hooks Class Initialized
DEBUG - 2011-09-13 21:12:16 --> Utf8 Class Initialized
DEBUG - 2011-09-13 21:12:16 --> UTF-8 Support Enabled
DEBUG - 2011-09-13 21:12:16 --> URI Class Initialized
DEBUG - 2011-09-13 21:12:16 --> Router Class Initialized
DEBUG - 2011-09-13 21:12:16 --> Output Class Initialized
DEBUG - 2011-09-13 21:12:16 --> Input Class Initialized
DEBUG - 2011-09-13 21:12:16 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-13 21:12:16 --> Language Class Initialized
DEBUG - 2011-09-13 21:12:16 --> Loader Class Initialized
DEBUG - 2011-09-13 21:12:16 --> Controller Class Initialized
ERROR - 2011-09-13 21:12:16 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-09-13 21:12:16 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-09-13 21:12:16 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-09-13 21:12:16 --> Model Class Initialized
DEBUG - 2011-09-13 21:12:16 --> Model Class Initialized
DEBUG - 2011-09-13 21:12:16 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-13 21:12:16 --> Database Driver Class Initialized
DEBUG - 2011-09-13 21:12:16 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-09-13 21:12:16 --> Helper loaded: url_helper
DEBUG - 2011-09-13 21:12:16 --> File loaded: application/views/common/header.php
DEBUG - 2011-09-13 21:12:16 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-09-13 21:12:16 --> File loaded: application/views/common/footer.php
DEBUG - 2011-09-13 21:12:16 --> File loaded: application/views/layout/main.php
DEBUG - 2011-09-13 21:12:16 --> Final output sent to browser
DEBUG - 2011-09-13 21:12:16 --> Total execution time: 0.0295
DEBUG - 2011-09-13 21:12:17 --> Config Class Initialized
DEBUG - 2011-09-13 21:12:17 --> Hooks Class Initialized
DEBUG - 2011-09-13 21:12:17 --> Utf8 Class Initialized
DEBUG - 2011-09-13 21:12:17 --> UTF-8 Support Enabled
DEBUG - 2011-09-13 21:12:17 --> URI Class Initialized
DEBUG - 2011-09-13 21:12:17 --> Router Class Initialized
DEBUG - 2011-09-13 21:12:17 --> Output Class Initialized
DEBUG - 2011-09-13 21:12:17 --> Input Class Initialized
DEBUG - 2011-09-13 21:12:17 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-13 21:12:17 --> Language Class Initialized
DEBUG - 2011-09-13 21:12:17 --> Loader Class Initialized
DEBUG - 2011-09-13 21:12:17 --> Controller Class Initialized
DEBUG - 2011-09-13 21:12:17 --> Model Class Initialized
DEBUG - 2011-09-13 21:12:17 --> Model Class Initialized
DEBUG - 2011-09-13 21:12:17 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-13 21:12:17 --> Database Driver Class Initialized
DEBUG - 2011-09-13 21:12:17 --> Final output sent to browser
DEBUG - 2011-09-13 21:12:17 --> Total execution time: 0.5475
DEBUG - 2011-09-13 21:12:19 --> Config Class Initialized
DEBUG - 2011-09-13 21:12:19 --> Hooks Class Initialized
DEBUG - 2011-09-13 21:12:19 --> Utf8 Class Initialized
DEBUG - 2011-09-13 21:12:19 --> UTF-8 Support Enabled
DEBUG - 2011-09-13 21:12:19 --> URI Class Initialized
DEBUG - 2011-09-13 21:12:19 --> Router Class Initialized
ERROR - 2011-09-13 21:12:19 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-09-13 21:12:24 --> Config Class Initialized
DEBUG - 2011-09-13 21:12:24 --> Hooks Class Initialized
DEBUG - 2011-09-13 21:12:24 --> Utf8 Class Initialized
DEBUG - 2011-09-13 21:12:24 --> UTF-8 Support Enabled
DEBUG - 2011-09-13 21:12:24 --> URI Class Initialized
DEBUG - 2011-09-13 21:12:24 --> Router Class Initialized
DEBUG - 2011-09-13 21:12:24 --> Output Class Initialized
DEBUG - 2011-09-13 21:12:24 --> Input Class Initialized
DEBUG - 2011-09-13 21:12:24 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-13 21:12:24 --> Language Class Initialized
DEBUG - 2011-09-13 21:12:24 --> Loader Class Initialized
DEBUG - 2011-09-13 21:12:24 --> Controller Class Initialized
ERROR - 2011-09-13 21:12:24 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-09-13 21:12:24 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-09-13 21:12:24 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-09-13 21:12:24 --> Model Class Initialized
DEBUG - 2011-09-13 21:12:24 --> Model Class Initialized
DEBUG - 2011-09-13 21:12:24 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-13 21:12:24 --> Database Driver Class Initialized
DEBUG - 2011-09-13 21:12:24 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-09-13 21:12:24 --> Helper loaded: url_helper
DEBUG - 2011-09-13 21:12:24 --> File loaded: application/views/common/header.php
DEBUG - 2011-09-13 21:12:24 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-09-13 21:12:24 --> File loaded: application/views/common/footer.php
DEBUG - 2011-09-13 21:12:24 --> File loaded: application/views/layout/main.php
DEBUG - 2011-09-13 21:12:24 --> Final output sent to browser
DEBUG - 2011-09-13 21:12:24 --> Total execution time: 0.0737
DEBUG - 2011-09-13 21:12:26 --> Config Class Initialized
DEBUG - 2011-09-13 21:12:26 --> Hooks Class Initialized
DEBUG - 2011-09-13 21:12:26 --> Utf8 Class Initialized
DEBUG - 2011-09-13 21:12:26 --> UTF-8 Support Enabled
DEBUG - 2011-09-13 21:12:26 --> URI Class Initialized
DEBUG - 2011-09-13 21:12:26 --> Router Class Initialized
DEBUG - 2011-09-13 21:12:26 --> Output Class Initialized
DEBUG - 2011-09-13 21:12:26 --> Input Class Initialized
DEBUG - 2011-09-13 21:12:26 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-13 21:12:26 --> Language Class Initialized
DEBUG - 2011-09-13 21:12:26 --> Loader Class Initialized
DEBUG - 2011-09-13 21:12:26 --> Controller Class Initialized
DEBUG - 2011-09-13 21:12:26 --> Model Class Initialized
DEBUG - 2011-09-13 21:12:26 --> Model Class Initialized
DEBUG - 2011-09-13 21:12:26 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-13 21:12:26 --> Database Driver Class Initialized
DEBUG - 2011-09-13 21:12:26 --> Config Class Initialized
DEBUG - 2011-09-13 21:12:26 --> Hooks Class Initialized
DEBUG - 2011-09-13 21:12:26 --> Utf8 Class Initialized
DEBUG - 2011-09-13 21:12:26 --> UTF-8 Support Enabled
DEBUG - 2011-09-13 21:12:26 --> URI Class Initialized
DEBUG - 2011-09-13 21:12:26 --> Router Class Initialized
DEBUG - 2011-09-13 21:12:26 --> Output Class Initialized
DEBUG - 2011-09-13 21:12:26 --> Input Class Initialized
DEBUG - 2011-09-13 21:12:26 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-13 21:12:26 --> Language Class Initialized
DEBUG - 2011-09-13 21:12:26 --> Loader Class Initialized
DEBUG - 2011-09-13 21:12:26 --> Controller Class Initialized
ERROR - 2011-09-13 21:12:26 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-09-13 21:12:26 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-09-13 21:12:26 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-09-13 21:12:26 --> Model Class Initialized
DEBUG - 2011-09-13 21:12:26 --> Model Class Initialized
DEBUG - 2011-09-13 21:12:26 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-13 21:12:26 --> Database Driver Class Initialized
DEBUG - 2011-09-13 21:12:26 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-09-13 21:12:26 --> Helper loaded: url_helper
DEBUG - 2011-09-13 21:12:26 --> File loaded: application/views/common/header.php
DEBUG - 2011-09-13 21:12:26 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-09-13 21:12:26 --> File loaded: application/views/common/footer.php
DEBUG - 2011-09-13 21:12:26 --> File loaded: application/views/layout/main.php
DEBUG - 2011-09-13 21:12:26 --> Final output sent to browser
DEBUG - 2011-09-13 21:12:26 --> Total execution time: 0.0342
DEBUG - 2011-09-13 21:12:26 --> Final output sent to browser
DEBUG - 2011-09-13 21:12:26 --> Total execution time: 0.5838
DEBUG - 2011-09-13 21:12:31 --> Config Class Initialized
DEBUG - 2011-09-13 21:12:31 --> Hooks Class Initialized
DEBUG - 2011-09-13 21:12:31 --> Utf8 Class Initialized
DEBUG - 2011-09-13 21:12:31 --> UTF-8 Support Enabled
DEBUG - 2011-09-13 21:12:31 --> URI Class Initialized
DEBUG - 2011-09-13 21:12:31 --> Router Class Initialized
ERROR - 2011-09-13 21:12:31 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-09-13 21:27:30 --> Config Class Initialized
DEBUG - 2011-09-13 21:27:30 --> Hooks Class Initialized
DEBUG - 2011-09-13 21:27:30 --> Utf8 Class Initialized
DEBUG - 2011-09-13 21:27:30 --> UTF-8 Support Enabled
DEBUG - 2011-09-13 21:27:30 --> URI Class Initialized
DEBUG - 2011-09-13 21:27:30 --> Router Class Initialized
DEBUG - 2011-09-13 21:27:30 --> No URI present. Default controller set.
DEBUG - 2011-09-13 21:27:30 --> Output Class Initialized
DEBUG - 2011-09-13 21:27:30 --> Input Class Initialized
DEBUG - 2011-09-13 21:27:30 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-13 21:27:30 --> Language Class Initialized
DEBUG - 2011-09-13 21:27:30 --> Loader Class Initialized
DEBUG - 2011-09-13 21:27:30 --> Controller Class Initialized
DEBUG - 2011-09-13 21:27:30 --> File loaded: application/views/splash/main.php
DEBUG - 2011-09-13 21:27:30 --> Helper loaded: url_helper
DEBUG - 2011-09-13 21:27:30 --> File loaded: application/views/common/header.php
DEBUG - 2011-09-13 21:27:30 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-09-13 21:27:30 --> File loaded: application/views/common/footer.php
DEBUG - 2011-09-13 21:27:30 --> File loaded: application/views/layout/main.php
DEBUG - 2011-09-13 21:27:30 --> Final output sent to browser
DEBUG - 2011-09-13 21:27:30 --> Total execution time: 0.0689
DEBUG - 2011-09-13 21:45:53 --> Config Class Initialized
DEBUG - 2011-09-13 21:45:53 --> Hooks Class Initialized
DEBUG - 2011-09-13 21:45:53 --> Utf8 Class Initialized
DEBUG - 2011-09-13 21:45:53 --> UTF-8 Support Enabled
DEBUG - 2011-09-13 21:45:53 --> URI Class Initialized
DEBUG - 2011-09-13 21:45:53 --> Router Class Initialized
DEBUG - 2011-09-13 21:45:53 --> Output Class Initialized
DEBUG - 2011-09-13 21:45:53 --> Input Class Initialized
DEBUG - 2011-09-13 21:45:53 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-13 21:45:53 --> Language Class Initialized
DEBUG - 2011-09-13 21:45:53 --> Loader Class Initialized
DEBUG - 2011-09-13 21:45:53 --> Controller Class Initialized
DEBUG - 2011-09-13 21:45:53 --> Model Class Initialized
DEBUG - 2011-09-13 21:45:53 --> Model Class Initialized
DEBUG - 2011-09-13 21:45:53 --> Model Class Initialized
DEBUG - 2011-09-13 21:45:53 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-13 21:45:53 --> Database Driver Class Initialized
DEBUG - 2011-09-13 21:45:54 --> File loaded: application/views/table/main.php
DEBUG - 2011-09-13 21:45:54 --> Helper loaded: url_helper
DEBUG - 2011-09-13 21:45:54 --> File loaded: application/views/common/header.php
DEBUG - 2011-09-13 21:45:54 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-09-13 21:45:54 --> File loaded: application/views/common/footer.php
DEBUG - 2011-09-13 21:45:54 --> File loaded: application/views/layout/main.php
DEBUG - 2011-09-13 21:45:54 --> Final output sent to browser
DEBUG - 2011-09-13 21:45:54 --> Total execution time: 0.5480
DEBUG - 2011-09-13 21:45:59 --> Config Class Initialized
DEBUG - 2011-09-13 21:45:59 --> Hooks Class Initialized
DEBUG - 2011-09-13 21:45:59 --> Utf8 Class Initialized
DEBUG - 2011-09-13 21:45:59 --> UTF-8 Support Enabled
DEBUG - 2011-09-13 21:45:59 --> URI Class Initialized
DEBUG - 2011-09-13 21:45:59 --> Router Class Initialized
DEBUG - 2011-09-13 21:45:59 --> Output Class Initialized
DEBUG - 2011-09-13 21:45:59 --> Input Class Initialized
DEBUG - 2011-09-13 21:45:59 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-13 21:45:59 --> Language Class Initialized
DEBUG - 2011-09-13 21:45:59 --> Loader Class Initialized
DEBUG - 2011-09-13 21:45:59 --> Controller Class Initialized
ERROR - 2011-09-13 21:45:59 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-09-13 21:45:59 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-09-13 21:45:59 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-09-13 21:45:59 --> Model Class Initialized
DEBUG - 2011-09-13 21:45:59 --> Model Class Initialized
DEBUG - 2011-09-13 21:45:59 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-13 21:45:59 --> Database Driver Class Initialized
DEBUG - 2011-09-13 21:45:59 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-09-13 21:45:59 --> Helper loaded: url_helper
DEBUG - 2011-09-13 21:45:59 --> File loaded: application/views/common/header.php
DEBUG - 2011-09-13 21:45:59 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-09-13 21:45:59 --> File loaded: application/views/common/footer.php
DEBUG - 2011-09-13 21:45:59 --> File loaded: application/views/layout/main.php
DEBUG - 2011-09-13 21:45:59 --> Final output sent to browser
DEBUG - 2011-09-13 21:45:59 --> Total execution time: 0.0277
DEBUG - 2011-09-13 21:55:25 --> Config Class Initialized
DEBUG - 2011-09-13 21:55:25 --> Hooks Class Initialized
DEBUG - 2011-09-13 21:55:25 --> Utf8 Class Initialized
DEBUG - 2011-09-13 21:55:25 --> UTF-8 Support Enabled
DEBUG - 2011-09-13 21:55:25 --> URI Class Initialized
DEBUG - 2011-09-13 21:55:25 --> Router Class Initialized
DEBUG - 2011-09-13 21:55:25 --> Output Class Initialized
DEBUG - 2011-09-13 21:55:26 --> Input Class Initialized
DEBUG - 2011-09-13 21:55:26 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-13 21:55:26 --> Language Class Initialized
DEBUG - 2011-09-13 21:55:26 --> Loader Class Initialized
DEBUG - 2011-09-13 21:55:26 --> Controller Class Initialized
ERROR - 2011-09-13 21:55:26 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-09-13 21:55:26 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-09-13 21:55:26 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-09-13 21:55:26 --> Model Class Initialized
DEBUG - 2011-09-13 21:55:26 --> Model Class Initialized
DEBUG - 2011-09-13 21:55:26 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-13 21:55:26 --> Database Driver Class Initialized
DEBUG - 2011-09-13 21:55:26 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-09-13 21:55:26 --> Helper loaded: url_helper
DEBUG - 2011-09-13 21:55:26 --> File loaded: application/views/common/header.php
DEBUG - 2011-09-13 21:55:26 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-09-13 21:55:26 --> File loaded: application/views/common/footer.php
DEBUG - 2011-09-13 21:55:26 --> File loaded: application/views/layout/main.php
DEBUG - 2011-09-13 21:55:26 --> Final output sent to browser
DEBUG - 2011-09-13 21:55:26 --> Total execution time: 0.0734
DEBUG - 2011-09-13 21:55:39 --> Config Class Initialized
DEBUG - 2011-09-13 21:55:39 --> Hooks Class Initialized
DEBUG - 2011-09-13 21:55:39 --> Utf8 Class Initialized
DEBUG - 2011-09-13 21:55:39 --> UTF-8 Support Enabled
DEBUG - 2011-09-13 21:55:39 --> URI Class Initialized
DEBUG - 2011-09-13 21:55:39 --> Router Class Initialized
DEBUG - 2011-09-13 21:55:39 --> Output Class Initialized
DEBUG - 2011-09-13 21:55:39 --> Input Class Initialized
DEBUG - 2011-09-13 21:55:39 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-13 21:55:39 --> Language Class Initialized
DEBUG - 2011-09-13 21:55:39 --> Loader Class Initialized
DEBUG - 2011-09-13 21:55:39 --> Controller Class Initialized
DEBUG - 2011-09-13 21:55:39 --> Model Class Initialized
DEBUG - 2011-09-13 21:55:39 --> Model Class Initialized
DEBUG - 2011-09-13 21:55:39 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-13 21:55:39 --> Database Driver Class Initialized
DEBUG - 2011-09-13 21:55:40 --> Final output sent to browser
DEBUG - 2011-09-13 21:55:40 --> Total execution time: 0.5442
DEBUG - 2011-09-13 21:55:53 --> Config Class Initialized
DEBUG - 2011-09-13 21:55:53 --> Hooks Class Initialized
DEBUG - 2011-09-13 21:55:53 --> Utf8 Class Initialized
DEBUG - 2011-09-13 21:55:53 --> UTF-8 Support Enabled
DEBUG - 2011-09-13 21:55:53 --> URI Class Initialized
DEBUG - 2011-09-13 21:55:53 --> Router Class Initialized
ERROR - 2011-09-13 21:55:53 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-09-13 22:51:25 --> Config Class Initialized
DEBUG - 2011-09-13 22:51:25 --> Hooks Class Initialized
DEBUG - 2011-09-13 22:51:25 --> Utf8 Class Initialized
DEBUG - 2011-09-13 22:51:25 --> UTF-8 Support Enabled
DEBUG - 2011-09-13 22:51:25 --> URI Class Initialized
DEBUG - 2011-09-13 22:51:25 --> Router Class Initialized
DEBUG - 2011-09-13 22:51:25 --> Output Class Initialized
DEBUG - 2011-09-13 22:51:25 --> Input Class Initialized
DEBUG - 2011-09-13 22:51:25 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-13 22:51:25 --> Language Class Initialized
DEBUG - 2011-09-13 22:51:25 --> Loader Class Initialized
DEBUG - 2011-09-13 22:51:25 --> Controller Class Initialized
ERROR - 2011-09-13 22:51:25 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-09-13 22:51:25 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-09-13 22:51:25 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-09-13 22:51:25 --> Model Class Initialized
DEBUG - 2011-09-13 22:51:25 --> Model Class Initialized
DEBUG - 2011-09-13 22:51:25 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-13 22:51:25 --> Database Driver Class Initialized
DEBUG - 2011-09-13 22:51:25 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-09-13 22:51:25 --> Helper loaded: url_helper
DEBUG - 2011-09-13 22:51:25 --> File loaded: application/views/common/header.php
DEBUG - 2011-09-13 22:51:25 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-09-13 22:51:25 --> File loaded: application/views/common/footer.php
DEBUG - 2011-09-13 22:51:25 --> File loaded: application/views/layout/main.php
DEBUG - 2011-09-13 22:51:25 --> Final output sent to browser
DEBUG - 2011-09-13 22:51:25 --> Total execution time: 0.0316
DEBUG - 2011-09-13 22:51:31 --> Config Class Initialized
DEBUG - 2011-09-13 22:51:31 --> Hooks Class Initialized
DEBUG - 2011-09-13 22:51:31 --> Utf8 Class Initialized
DEBUG - 2011-09-13 22:51:31 --> UTF-8 Support Enabled
DEBUG - 2011-09-13 22:51:31 --> URI Class Initialized
DEBUG - 2011-09-13 22:51:31 --> Router Class Initialized
DEBUG - 2011-09-13 22:51:31 --> Output Class Initialized
DEBUG - 2011-09-13 22:51:31 --> Input Class Initialized
DEBUG - 2011-09-13 22:51:31 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-13 22:51:31 --> Language Class Initialized
DEBUG - 2011-09-13 22:51:31 --> Loader Class Initialized
DEBUG - 2011-09-13 22:51:31 --> Controller Class Initialized
DEBUG - 2011-09-13 22:51:31 --> Model Class Initialized
DEBUG - 2011-09-13 22:51:31 --> Model Class Initialized
DEBUG - 2011-09-13 22:51:31 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-13 22:51:31 --> Database Driver Class Initialized
DEBUG - 2011-09-13 22:51:31 --> Final output sent to browser
DEBUG - 2011-09-13 22:51:31 --> Total execution time: 0.6943
DEBUG - 2011-09-13 23:44:43 --> Config Class Initialized
DEBUG - 2011-09-13 23:44:43 --> Hooks Class Initialized
DEBUG - 2011-09-13 23:44:43 --> Utf8 Class Initialized
DEBUG - 2011-09-13 23:44:43 --> UTF-8 Support Enabled
DEBUG - 2011-09-13 23:44:43 --> URI Class Initialized
DEBUG - 2011-09-13 23:44:43 --> Router Class Initialized
DEBUG - 2011-09-13 23:44:43 --> Output Class Initialized
DEBUG - 2011-09-13 23:44:43 --> Input Class Initialized
DEBUG - 2011-09-13 23:44:43 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-13 23:44:43 --> Language Class Initialized
DEBUG - 2011-09-13 23:44:43 --> Loader Class Initialized
DEBUG - 2011-09-13 23:44:43 --> Controller Class Initialized
DEBUG - 2011-09-13 23:44:43 --> Model Class Initialized
DEBUG - 2011-09-13 23:44:43 --> Model Class Initialized
DEBUG - 2011-09-13 23:44:43 --> Model Class Initialized
DEBUG - 2011-09-13 23:44:43 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-13 23:44:43 --> Database Driver Class Initialized
DEBUG - 2011-09-13 23:44:43 --> File loaded: application/views/table/main.php
DEBUG - 2011-09-13 23:44:43 --> Helper loaded: url_helper
DEBUG - 2011-09-13 23:44:43 --> File loaded: application/views/common/header.php
DEBUG - 2011-09-13 23:44:43 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-09-13 23:44:43 --> File loaded: application/views/common/footer.php
DEBUG - 2011-09-13 23:44:43 --> File loaded: application/views/layout/main.php
DEBUG - 2011-09-13 23:44:43 --> Final output sent to browser
DEBUG - 2011-09-13 23:44:43 --> Total execution time: 0.2884
DEBUG - 2011-09-13 23:44:48 --> Config Class Initialized
DEBUG - 2011-09-13 23:44:48 --> Hooks Class Initialized
DEBUG - 2011-09-13 23:44:48 --> Utf8 Class Initialized
DEBUG - 2011-09-13 23:44:48 --> UTF-8 Support Enabled
DEBUG - 2011-09-13 23:44:48 --> URI Class Initialized
DEBUG - 2011-09-13 23:44:48 --> Router Class Initialized
ERROR - 2011-09-13 23:44:48 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-09-13 23:45:02 --> Config Class Initialized
DEBUG - 2011-09-13 23:45:02 --> Hooks Class Initialized
DEBUG - 2011-09-13 23:45:02 --> Utf8 Class Initialized
DEBUG - 2011-09-13 23:45:02 --> UTF-8 Support Enabled
DEBUG - 2011-09-13 23:45:02 --> URI Class Initialized
DEBUG - 2011-09-13 23:45:02 --> Router Class Initialized
DEBUG - 2011-09-13 23:45:02 --> Output Class Initialized
DEBUG - 2011-09-13 23:45:02 --> Input Class Initialized
DEBUG - 2011-09-13 23:45:02 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-13 23:45:02 --> Language Class Initialized
DEBUG - 2011-09-13 23:45:02 --> Loader Class Initialized
DEBUG - 2011-09-13 23:45:02 --> Controller Class Initialized
DEBUG - 2011-09-13 23:45:02 --> Model Class Initialized
DEBUG - 2011-09-13 23:45:02 --> Model Class Initialized
DEBUG - 2011-09-13 23:45:02 --> Model Class Initialized
DEBUG - 2011-09-13 23:45:02 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-13 23:45:02 --> Database Driver Class Initialized
DEBUG - 2011-09-13 23:45:03 --> File loaded: application/views/table/main.php
DEBUG - 2011-09-13 23:45:03 --> Helper loaded: url_helper
DEBUG - 2011-09-13 23:45:03 --> File loaded: application/views/common/header.php
DEBUG - 2011-09-13 23:45:03 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-09-13 23:45:03 --> File loaded: application/views/common/footer.php
DEBUG - 2011-09-13 23:45:03 --> File loaded: application/views/layout/main.php
DEBUG - 2011-09-13 23:45:03 --> Final output sent to browser
DEBUG - 2011-09-13 23:45:03 --> Total execution time: 0.9593
DEBUG - 2011-09-13 23:45:09 --> Config Class Initialized
DEBUG - 2011-09-13 23:45:09 --> Hooks Class Initialized
DEBUG - 2011-09-13 23:45:09 --> Utf8 Class Initialized
DEBUG - 2011-09-13 23:45:09 --> UTF-8 Support Enabled
DEBUG - 2011-09-13 23:45:09 --> URI Class Initialized
DEBUG - 2011-09-13 23:45:09 --> Router Class Initialized
ERROR - 2011-09-13 23:45:09 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-09-13 23:45:18 --> Config Class Initialized
DEBUG - 2011-09-13 23:45:18 --> Hooks Class Initialized
DEBUG - 2011-09-13 23:45:18 --> Utf8 Class Initialized
DEBUG - 2011-09-13 23:45:18 --> UTF-8 Support Enabled
DEBUG - 2011-09-13 23:45:18 --> URI Class Initialized
DEBUG - 2011-09-13 23:45:18 --> Router Class Initialized
DEBUG - 2011-09-13 23:45:18 --> Output Class Initialized
DEBUG - 2011-09-13 23:45:18 --> Input Class Initialized
DEBUG - 2011-09-13 23:45:18 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-13 23:45:18 --> Language Class Initialized
DEBUG - 2011-09-13 23:45:18 --> Loader Class Initialized
DEBUG - 2011-09-13 23:45:18 --> Controller Class Initialized
DEBUG - 2011-09-13 23:45:18 --> Model Class Initialized
DEBUG - 2011-09-13 23:45:18 --> Model Class Initialized
DEBUG - 2011-09-13 23:45:18 --> Model Class Initialized
DEBUG - 2011-09-13 23:45:18 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-13 23:45:18 --> Database Driver Class Initialized
DEBUG - 2011-09-13 23:45:18 --> File loaded: application/views/table/main.php
DEBUG - 2011-09-13 23:45:18 --> Helper loaded: url_helper
DEBUG - 2011-09-13 23:45:18 --> File loaded: application/views/common/header.php
DEBUG - 2011-09-13 23:45:18 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-09-13 23:45:18 --> File loaded: application/views/common/footer.php
DEBUG - 2011-09-13 23:45:18 --> File loaded: application/views/layout/main.php
DEBUG - 2011-09-13 23:45:18 --> Final output sent to browser
DEBUG - 2011-09-13 23:45:18 --> Total execution time: 0.3394
DEBUG - 2011-09-13 23:45:22 --> Config Class Initialized
DEBUG - 2011-09-13 23:45:22 --> Hooks Class Initialized
DEBUG - 2011-09-13 23:45:22 --> Utf8 Class Initialized
DEBUG - 2011-09-13 23:45:22 --> UTF-8 Support Enabled
DEBUG - 2011-09-13 23:45:22 --> URI Class Initialized
DEBUG - 2011-09-13 23:45:22 --> Router Class Initialized
ERROR - 2011-09-13 23:45:22 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-09-13 23:48:13 --> Config Class Initialized
DEBUG - 2011-09-13 23:48:13 --> Hooks Class Initialized
DEBUG - 2011-09-13 23:48:13 --> Utf8 Class Initialized
DEBUG - 2011-09-13 23:48:13 --> UTF-8 Support Enabled
DEBUG - 2011-09-13 23:48:13 --> URI Class Initialized
DEBUG - 2011-09-13 23:48:13 --> Router Class Initialized
DEBUG - 2011-09-13 23:48:13 --> Output Class Initialized
DEBUG - 2011-09-13 23:48:13 --> Input Class Initialized
DEBUG - 2011-09-13 23:48:13 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-13 23:48:13 --> Language Class Initialized
DEBUG - 2011-09-13 23:48:13 --> Loader Class Initialized
DEBUG - 2011-09-13 23:48:13 --> Controller Class Initialized
DEBUG - 2011-09-13 23:48:13 --> Model Class Initialized
DEBUG - 2011-09-13 23:48:13 --> Model Class Initialized
DEBUG - 2011-09-13 23:48:13 --> Model Class Initialized
DEBUG - 2011-09-13 23:48:13 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-13 23:48:13 --> Database Driver Class Initialized
DEBUG - 2011-09-13 23:48:13 --> File loaded: application/views/table/main.php
DEBUG - 2011-09-13 23:48:13 --> Helper loaded: url_helper
DEBUG - 2011-09-13 23:48:13 --> File loaded: application/views/common/header.php
DEBUG - 2011-09-13 23:48:13 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-09-13 23:48:13 --> File loaded: application/views/common/footer.php
DEBUG - 2011-09-13 23:48:13 --> File loaded: application/views/layout/main.php
DEBUG - 2011-09-13 23:48:13 --> Final output sent to browser
DEBUG - 2011-09-13 23:48:13 --> Total execution time: 0.0517
DEBUG - 2011-09-13 23:48:16 --> Config Class Initialized
DEBUG - 2011-09-13 23:48:16 --> Hooks Class Initialized
DEBUG - 2011-09-13 23:48:16 --> Utf8 Class Initialized
DEBUG - 2011-09-13 23:48:16 --> UTF-8 Support Enabled
DEBUG - 2011-09-13 23:48:16 --> URI Class Initialized
DEBUG - 2011-09-13 23:48:16 --> Router Class Initialized
ERROR - 2011-09-13 23:48:16 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-09-13 23:48:30 --> Config Class Initialized
DEBUG - 2011-09-13 23:48:30 --> Hooks Class Initialized
DEBUG - 2011-09-13 23:48:30 --> Utf8 Class Initialized
DEBUG - 2011-09-13 23:48:30 --> UTF-8 Support Enabled
DEBUG - 2011-09-13 23:48:30 --> URI Class Initialized
DEBUG - 2011-09-13 23:48:30 --> Router Class Initialized
DEBUG - 2011-09-13 23:48:30 --> Output Class Initialized
DEBUG - 2011-09-13 23:48:30 --> Input Class Initialized
DEBUG - 2011-09-13 23:48:30 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-13 23:48:30 --> Language Class Initialized
DEBUG - 2011-09-13 23:48:30 --> Loader Class Initialized
DEBUG - 2011-09-13 23:48:30 --> Controller Class Initialized
ERROR - 2011-09-13 23:48:30 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-09-13 23:48:30 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-09-13 23:48:30 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-09-13 23:48:30 --> Model Class Initialized
DEBUG - 2011-09-13 23:48:30 --> Model Class Initialized
DEBUG - 2011-09-13 23:48:30 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-13 23:48:30 --> Database Driver Class Initialized
DEBUG - 2011-09-13 23:48:30 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-09-13 23:48:30 --> Helper loaded: url_helper
DEBUG - 2011-09-13 23:48:30 --> File loaded: application/views/common/header.php
DEBUG - 2011-09-13 23:48:30 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-09-13 23:48:30 --> File loaded: application/views/common/footer.php
DEBUG - 2011-09-13 23:48:30 --> File loaded: application/views/layout/main.php
DEBUG - 2011-09-13 23:48:30 --> Final output sent to browser
DEBUG - 2011-09-13 23:48:30 --> Total execution time: 0.0309
DEBUG - 2011-09-13 23:48:31 --> Config Class Initialized
DEBUG - 2011-09-13 23:48:31 --> Hooks Class Initialized
DEBUG - 2011-09-13 23:48:31 --> Utf8 Class Initialized
DEBUG - 2011-09-13 23:48:31 --> UTF-8 Support Enabled
DEBUG - 2011-09-13 23:48:31 --> URI Class Initialized
DEBUG - 2011-09-13 23:48:31 --> Router Class Initialized
DEBUG - 2011-09-13 23:48:32 --> Output Class Initialized
DEBUG - 2011-09-13 23:48:32 --> Input Class Initialized
DEBUG - 2011-09-13 23:48:32 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-13 23:48:32 --> Language Class Initialized
DEBUG - 2011-09-13 23:48:32 --> Loader Class Initialized
DEBUG - 2011-09-13 23:48:32 --> Controller Class Initialized
DEBUG - 2011-09-13 23:48:32 --> Model Class Initialized
DEBUG - 2011-09-13 23:48:32 --> Model Class Initialized
DEBUG - 2011-09-13 23:48:32 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-13 23:48:32 --> Database Driver Class Initialized
DEBUG - 2011-09-13 23:48:33 --> Final output sent to browser
DEBUG - 2011-09-13 23:48:33 --> Total execution time: 1.6019
DEBUG - 2011-09-13 23:48:36 --> Config Class Initialized
DEBUG - 2011-09-13 23:48:36 --> Hooks Class Initialized
DEBUG - 2011-09-13 23:48:36 --> Utf8 Class Initialized
DEBUG - 2011-09-13 23:48:36 --> UTF-8 Support Enabled
DEBUG - 2011-09-13 23:48:36 --> URI Class Initialized
DEBUG - 2011-09-13 23:48:36 --> Router Class Initialized
DEBUG - 2011-09-13 23:48:36 --> Output Class Initialized
DEBUG - 2011-09-13 23:48:36 --> Input Class Initialized
DEBUG - 2011-09-13 23:48:36 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-13 23:48:36 --> Language Class Initialized
DEBUG - 2011-09-13 23:48:36 --> Loader Class Initialized
DEBUG - 2011-09-13 23:48:36 --> Controller Class Initialized
DEBUG - 2011-09-13 23:48:36 --> Model Class Initialized
DEBUG - 2011-09-13 23:48:36 --> Model Class Initialized
DEBUG - 2011-09-13 23:48:36 --> Model Class Initialized
DEBUG - 2011-09-13 23:48:36 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-13 23:48:36 --> Database Driver Class Initialized
DEBUG - 2011-09-13 23:48:36 --> File loaded: application/views/table/main.php
DEBUG - 2011-09-13 23:48:36 --> Helper loaded: url_helper
DEBUG - 2011-09-13 23:48:36 --> File loaded: application/views/common/header.php
DEBUG - 2011-09-13 23:48:36 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-09-13 23:48:36 --> File loaded: application/views/common/footer.php
DEBUG - 2011-09-13 23:48:36 --> File loaded: application/views/layout/main.php
DEBUG - 2011-09-13 23:48:36 --> Final output sent to browser
DEBUG - 2011-09-13 23:48:36 --> Total execution time: 0.4257
DEBUG - 2011-09-13 23:48:40 --> Config Class Initialized
DEBUG - 2011-09-13 23:48:40 --> Hooks Class Initialized
DEBUG - 2011-09-13 23:48:40 --> Utf8 Class Initialized
DEBUG - 2011-09-13 23:48:40 --> UTF-8 Support Enabled
DEBUG - 2011-09-13 23:48:40 --> URI Class Initialized
DEBUG - 2011-09-13 23:48:40 --> Router Class Initialized
ERROR - 2011-09-13 23:48:40 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-09-13 23:48:47 --> Config Class Initialized
DEBUG - 2011-09-13 23:48:47 --> Hooks Class Initialized
DEBUG - 2011-09-13 23:48:47 --> Utf8 Class Initialized
DEBUG - 2011-09-13 23:48:47 --> UTF-8 Support Enabled
DEBUG - 2011-09-13 23:48:47 --> URI Class Initialized
DEBUG - 2011-09-13 23:48:47 --> Router Class Initialized
DEBUG - 2011-09-13 23:48:47 --> Output Class Initialized
DEBUG - 2011-09-13 23:48:47 --> Input Class Initialized
DEBUG - 2011-09-13 23:48:47 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-13 23:48:47 --> Language Class Initialized
DEBUG - 2011-09-13 23:48:47 --> Loader Class Initialized
DEBUG - 2011-09-13 23:48:47 --> Controller Class Initialized
ERROR - 2011-09-13 23:48:47 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-09-13 23:48:47 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-09-13 23:48:47 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-09-13 23:48:47 --> Model Class Initialized
DEBUG - 2011-09-13 23:48:47 --> Model Class Initialized
DEBUG - 2011-09-13 23:48:47 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-13 23:48:47 --> Database Driver Class Initialized
DEBUG - 2011-09-13 23:48:47 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-09-13 23:48:47 --> Helper loaded: url_helper
DEBUG - 2011-09-13 23:48:47 --> File loaded: application/views/common/header.php
DEBUG - 2011-09-13 23:48:47 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-09-13 23:48:47 --> File loaded: application/views/common/footer.php
DEBUG - 2011-09-13 23:48:47 --> File loaded: application/views/layout/main.php
DEBUG - 2011-09-13 23:48:47 --> Final output sent to browser
DEBUG - 2011-09-13 23:48:47 --> Total execution time: 0.0453
DEBUG - 2011-09-13 23:48:48 --> Config Class Initialized
DEBUG - 2011-09-13 23:48:48 --> Hooks Class Initialized
DEBUG - 2011-09-13 23:48:48 --> Utf8 Class Initialized
DEBUG - 2011-09-13 23:48:48 --> UTF-8 Support Enabled
DEBUG - 2011-09-13 23:48:48 --> URI Class Initialized
DEBUG - 2011-09-13 23:48:48 --> Router Class Initialized
DEBUG - 2011-09-13 23:48:48 --> Output Class Initialized
DEBUG - 2011-09-13 23:48:48 --> Input Class Initialized
DEBUG - 2011-09-13 23:48:48 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-13 23:48:48 --> Language Class Initialized
DEBUG - 2011-09-13 23:48:48 --> Loader Class Initialized
DEBUG - 2011-09-13 23:48:48 --> Controller Class Initialized
DEBUG - 2011-09-13 23:48:48 --> Model Class Initialized
DEBUG - 2011-09-13 23:48:48 --> Model Class Initialized
DEBUG - 2011-09-13 23:48:48 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-13 23:48:48 --> Database Driver Class Initialized
DEBUG - 2011-09-13 23:48:49 --> Final output sent to browser
DEBUG - 2011-09-13 23:48:49 --> Total execution time: 0.6060
DEBUG - 2011-09-13 23:48:50 --> Config Class Initialized
DEBUG - 2011-09-13 23:48:50 --> Hooks Class Initialized
DEBUG - 2011-09-13 23:48:50 --> Utf8 Class Initialized
DEBUG - 2011-09-13 23:48:50 --> UTF-8 Support Enabled
DEBUG - 2011-09-13 23:48:50 --> URI Class Initialized
DEBUG - 2011-09-13 23:48:50 --> Router Class Initialized
ERROR - 2011-09-13 23:48:50 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-09-13 23:48:51 --> Config Class Initialized
DEBUG - 2011-09-13 23:48:51 --> Hooks Class Initialized
DEBUG - 2011-09-13 23:48:51 --> Utf8 Class Initialized
DEBUG - 2011-09-13 23:48:51 --> UTF-8 Support Enabled
DEBUG - 2011-09-13 23:48:51 --> URI Class Initialized
DEBUG - 2011-09-13 23:48:51 --> Router Class Initialized
DEBUG - 2011-09-13 23:48:51 --> Output Class Initialized
DEBUG - 2011-09-13 23:48:51 --> Input Class Initialized
DEBUG - 2011-09-13 23:48:51 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-13 23:48:51 --> Language Class Initialized
DEBUG - 2011-09-13 23:48:51 --> Loader Class Initialized
DEBUG - 2011-09-13 23:48:51 --> Controller Class Initialized
DEBUG - 2011-09-13 23:48:51 --> Model Class Initialized
DEBUG - 2011-09-13 23:48:51 --> Model Class Initialized
DEBUG - 2011-09-13 23:48:51 --> Model Class Initialized
DEBUG - 2011-09-13 23:48:51 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-13 23:48:51 --> Database Driver Class Initialized
DEBUG - 2011-09-13 23:48:51 --> File loaded: application/views/table/main.php
DEBUG - 2011-09-13 23:48:51 --> Helper loaded: url_helper
DEBUG - 2011-09-13 23:48:51 --> File loaded: application/views/common/header.php
DEBUG - 2011-09-13 23:48:51 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-09-13 23:48:51 --> File loaded: application/views/common/footer.php
DEBUG - 2011-09-13 23:48:51 --> File loaded: application/views/layout/main.php
DEBUG - 2011-09-13 23:48:51 --> Final output sent to browser
DEBUG - 2011-09-13 23:48:51 --> Total execution time: 0.4728
DEBUG - 2011-09-13 23:48:53 --> Config Class Initialized
DEBUG - 2011-09-13 23:48:53 --> Hooks Class Initialized
DEBUG - 2011-09-13 23:48:53 --> Utf8 Class Initialized
DEBUG - 2011-09-13 23:48:53 --> UTF-8 Support Enabled
DEBUG - 2011-09-13 23:48:53 --> URI Class Initialized
DEBUG - 2011-09-13 23:48:53 --> Router Class Initialized
ERROR - 2011-09-13 23:48:53 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-09-13 23:50:08 --> Config Class Initialized
DEBUG - 2011-09-13 23:50:08 --> Hooks Class Initialized
DEBUG - 2011-09-13 23:50:08 --> Utf8 Class Initialized
DEBUG - 2011-09-13 23:50:08 --> UTF-8 Support Enabled
DEBUG - 2011-09-13 23:50:08 --> URI Class Initialized
DEBUG - 2011-09-13 23:50:08 --> Router Class Initialized
DEBUG - 2011-09-13 23:50:08 --> Output Class Initialized
DEBUG - 2011-09-13 23:50:08 --> Input Class Initialized
DEBUG - 2011-09-13 23:50:08 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-13 23:50:08 --> Language Class Initialized
DEBUG - 2011-09-13 23:50:08 --> Loader Class Initialized
DEBUG - 2011-09-13 23:50:08 --> Controller Class Initialized
DEBUG - 2011-09-13 23:50:08 --> Model Class Initialized
DEBUG - 2011-09-13 23:50:08 --> Model Class Initialized
DEBUG - 2011-09-13 23:50:08 --> Model Class Initialized
DEBUG - 2011-09-13 23:50:08 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-13 23:50:08 --> Database Driver Class Initialized
DEBUG - 2011-09-13 23:50:08 --> File loaded: application/views/table/main.php
DEBUG - 2011-09-13 23:50:08 --> Helper loaded: url_helper
DEBUG - 2011-09-13 23:50:08 --> File loaded: application/views/common/header.php
DEBUG - 2011-09-13 23:50:08 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-09-13 23:50:08 --> File loaded: application/views/common/footer.php
DEBUG - 2011-09-13 23:50:08 --> File loaded: application/views/layout/main.php
DEBUG - 2011-09-13 23:50:08 --> Final output sent to browser
DEBUG - 2011-09-13 23:50:08 --> Total execution time: 0.4401
DEBUG - 2011-09-13 23:50:10 --> Config Class Initialized
DEBUG - 2011-09-13 23:50:10 --> Hooks Class Initialized
DEBUG - 2011-09-13 23:50:10 --> Utf8 Class Initialized
DEBUG - 2011-09-13 23:50:10 --> UTF-8 Support Enabled
DEBUG - 2011-09-13 23:50:10 --> URI Class Initialized
DEBUG - 2011-09-13 23:50:10 --> Router Class Initialized
ERROR - 2011-09-13 23:50:10 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-09-13 23:50:19 --> Config Class Initialized
DEBUG - 2011-09-13 23:50:19 --> Hooks Class Initialized
DEBUG - 2011-09-13 23:50:19 --> Utf8 Class Initialized
DEBUG - 2011-09-13 23:50:19 --> UTF-8 Support Enabled
DEBUG - 2011-09-13 23:50:19 --> URI Class Initialized
DEBUG - 2011-09-13 23:50:19 --> Router Class Initialized
DEBUG - 2011-09-13 23:50:19 --> Output Class Initialized
DEBUG - 2011-09-13 23:50:19 --> Input Class Initialized
DEBUG - 2011-09-13 23:50:19 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-13 23:50:19 --> Language Class Initialized
DEBUG - 2011-09-13 23:50:19 --> Loader Class Initialized
DEBUG - 2011-09-13 23:50:19 --> Controller Class Initialized
DEBUG - 2011-09-13 23:50:19 --> Model Class Initialized
DEBUG - 2011-09-13 23:50:19 --> Model Class Initialized
DEBUG - 2011-09-13 23:50:19 --> Model Class Initialized
DEBUG - 2011-09-13 23:50:19 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-13 23:50:19 --> Database Driver Class Initialized
DEBUG - 2011-09-13 23:50:19 --> File loaded: application/views/table/main.php
DEBUG - 2011-09-13 23:50:19 --> Helper loaded: url_helper
DEBUG - 2011-09-13 23:50:19 --> File loaded: application/views/common/header.php
DEBUG - 2011-09-13 23:50:19 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-09-13 23:50:19 --> File loaded: application/views/common/footer.php
DEBUG - 2011-09-13 23:50:19 --> File loaded: application/views/layout/main.php
DEBUG - 2011-09-13 23:50:19 --> Final output sent to browser
DEBUG - 2011-09-13 23:50:19 --> Total execution time: 0.3248
DEBUG - 2011-09-13 23:50:21 --> Config Class Initialized
DEBUG - 2011-09-13 23:50:21 --> Hooks Class Initialized
DEBUG - 2011-09-13 23:50:21 --> Utf8 Class Initialized
DEBUG - 2011-09-13 23:50:21 --> UTF-8 Support Enabled
DEBUG - 2011-09-13 23:50:21 --> URI Class Initialized
DEBUG - 2011-09-13 23:50:21 --> Router Class Initialized
ERROR - 2011-09-13 23:50:21 --> 404 Page Not Found --> favicon.ico

<?php  if ( ! defined('BASEPATH')) exit('No direct script access allowed'); ?>

DEBUG - 2011-05-25 00:25:47 --> Config Class Initialized
DEBUG - 2011-05-25 00:25:47 --> Hooks Class Initialized
DEBUG - 2011-05-25 00:25:47 --> Utf8 Class Initialized
DEBUG - 2011-05-25 00:25:47 --> UTF-8 Support Enabled
DEBUG - 2011-05-25 00:25:47 --> URI Class Initialized
DEBUG - 2011-05-25 00:25:47 --> Router Class Initialized
DEBUG - 2011-05-25 00:25:47 --> Output Class Initialized
DEBUG - 2011-05-25 00:25:47 --> Input Class Initialized
DEBUG - 2011-05-25 00:25:47 --> Global POST and COOKIE data sanitized
DEBUG - 2011-05-25 00:25:47 --> Language Class Initialized
DEBUG - 2011-05-25 00:25:47 --> Loader Class Initialized
DEBUG - 2011-05-25 00:25:47 --> Controller Class Initialized
DEBUG - 2011-05-25 00:25:48 --> Model Class Initialized
DEBUG - 2011-05-25 00:25:48 --> Model Class Initialized
DEBUG - 2011-05-25 00:25:48 --> Model Class Initialized
DEBUG - 2011-05-25 00:25:48 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-05-25 00:25:48 --> Database Driver Class Initialized
DEBUG - 2011-05-25 00:25:48 --> File loaded: application/views/table/main.php
DEBUG - 2011-05-25 00:25:48 --> Helper loaded: url_helper
DEBUG - 2011-05-25 00:25:48 --> File loaded: application/views/common/header.php
DEBUG - 2011-05-25 00:25:48 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-05-25 00:25:48 --> File loaded: application/views/common/footer.php
DEBUG - 2011-05-25 00:25:48 --> File loaded: application/views/layout/main.php
DEBUG - 2011-05-25 00:25:48 --> Final output sent to browser
DEBUG - 2011-05-25 00:25:48 --> Total execution time: 0.5398
DEBUG - 2011-05-25 00:25:49 --> Config Class Initialized
DEBUG - 2011-05-25 00:25:49 --> Hooks Class Initialized
DEBUG - 2011-05-25 00:25:49 --> Utf8 Class Initialized
DEBUG - 2011-05-25 00:25:49 --> UTF-8 Support Enabled
DEBUG - 2011-05-25 00:25:49 --> URI Class Initialized
DEBUG - 2011-05-25 00:25:49 --> Router Class Initialized
DEBUG - 2011-05-25 00:25:49 --> Output Class Initialized
DEBUG - 2011-05-25 00:25:49 --> Input Class Initialized
DEBUG - 2011-05-25 00:25:49 --> Global POST and COOKIE data sanitized
DEBUG - 2011-05-25 00:25:49 --> Language Class Initialized
DEBUG - 2011-05-25 00:25:49 --> Loader Class Initialized
DEBUG - 2011-05-25 00:25:49 --> Controller Class Initialized
ERROR - 2011-05-25 00:25:49 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-05-25 00:25:49 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-05-25 00:25:49 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-05-25 00:25:49 --> Model Class Initialized
DEBUG - 2011-05-25 00:25:49 --> Model Class Initialized
DEBUG - 2011-05-25 00:25:49 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-05-25 00:25:49 --> Database Driver Class Initialized
DEBUG - 2011-05-25 00:25:49 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-05-25 00:25:49 --> Helper loaded: url_helper
DEBUG - 2011-05-25 00:25:49 --> File loaded: application/views/common/header.php
DEBUG - 2011-05-25 00:25:49 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-05-25 00:25:49 --> File loaded: application/views/common/footer.php
DEBUG - 2011-05-25 00:25:49 --> File loaded: application/views/layout/main.php
DEBUG - 2011-05-25 00:25:49 --> Final output sent to browser
DEBUG - 2011-05-25 00:25:49 --> Total execution time: 0.6385
DEBUG - 2011-05-25 01:12:53 --> Config Class Initialized
DEBUG - 2011-05-25 01:12:53 --> Hooks Class Initialized
DEBUG - 2011-05-25 01:12:53 --> Utf8 Class Initialized
DEBUG - 2011-05-25 01:12:53 --> UTF-8 Support Enabled
DEBUG - 2011-05-25 01:12:53 --> URI Class Initialized
DEBUG - 2011-05-25 01:12:53 --> Router Class Initialized
ERROR - 2011-05-25 01:12:53 --> 404 Page Not Found --> robots.txt
DEBUG - 2011-05-25 01:12:53 --> Config Class Initialized
DEBUG - 2011-05-25 01:12:53 --> Hooks Class Initialized
DEBUG - 2011-05-25 01:12:53 --> Utf8 Class Initialized
DEBUG - 2011-05-25 01:12:53 --> UTF-8 Support Enabled
DEBUG - 2011-05-25 01:12:53 --> URI Class Initialized
DEBUG - 2011-05-25 01:12:53 --> Router Class Initialized
DEBUG - 2011-05-25 01:12:53 --> Output Class Initialized
DEBUG - 2011-05-25 01:12:53 --> Input Class Initialized
DEBUG - 2011-05-25 01:12:53 --> Global POST and COOKIE data sanitized
DEBUG - 2011-05-25 01:12:53 --> Language Class Initialized
DEBUG - 2011-05-25 01:12:53 --> Loader Class Initialized
DEBUG - 2011-05-25 01:12:53 --> Controller Class Initialized
DEBUG - 2011-05-25 01:12:53 --> Model Class Initialized
DEBUG - 2011-05-25 01:12:53 --> Model Class Initialized
DEBUG - 2011-05-25 01:12:53 --> Model Class Initialized
DEBUG - 2011-05-25 01:12:53 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-05-25 01:12:53 --> Database Driver Class Initialized
DEBUG - 2011-05-25 01:12:53 --> File loaded: application/views/table/main.php
DEBUG - 2011-05-25 01:12:53 --> Helper loaded: url_helper
DEBUG - 2011-05-25 01:12:53 --> File loaded: application/views/common/header.php
DEBUG - 2011-05-25 01:12:53 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-05-25 01:12:54 --> File loaded: application/views/common/footer.php
DEBUG - 2011-05-25 01:12:54 --> File loaded: application/views/layout/main.php
DEBUG - 2011-05-25 01:12:54 --> Final output sent to browser
DEBUG - 2011-05-25 01:12:54 --> Total execution time: 0.8666
DEBUG - 2011-05-25 01:13:25 --> Config Class Initialized
DEBUG - 2011-05-25 01:13:25 --> Hooks Class Initialized
DEBUG - 2011-05-25 01:13:25 --> Utf8 Class Initialized
DEBUG - 2011-05-25 01:13:25 --> UTF-8 Support Enabled
DEBUG - 2011-05-25 01:13:25 --> URI Class Initialized
DEBUG - 2011-05-25 01:13:25 --> Router Class Initialized
DEBUG - 2011-05-25 01:13:25 --> Output Class Initialized
DEBUG - 2011-05-25 01:13:25 --> Input Class Initialized
DEBUG - 2011-05-25 01:13:25 --> Global POST and COOKIE data sanitized
DEBUG - 2011-05-25 01:13:25 --> Language Class Initialized
DEBUG - 2011-05-25 01:13:25 --> Loader Class Initialized
DEBUG - 2011-05-25 01:13:25 --> Controller Class Initialized
ERROR - 2011-05-25 01:13:25 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-05-25 01:13:25 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-05-25 01:13:25 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-05-25 01:13:25 --> Model Class Initialized
DEBUG - 2011-05-25 01:13:25 --> Model Class Initialized
DEBUG - 2011-05-25 01:13:25 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-05-25 01:13:25 --> Database Driver Class Initialized
DEBUG - 2011-05-25 01:13:25 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-05-25 01:13:25 --> Helper loaded: url_helper
DEBUG - 2011-05-25 01:13:25 --> File loaded: application/views/common/header.php
DEBUG - 2011-05-25 01:13:25 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-05-25 01:13:25 --> File loaded: application/views/common/footer.php
DEBUG - 2011-05-25 01:13:25 --> File loaded: application/views/layout/main.php
DEBUG - 2011-05-25 01:13:25 --> Final output sent to browser
DEBUG - 2011-05-25 01:13:25 --> Total execution time: 0.1710
DEBUG - 2011-05-25 01:54:09 --> Config Class Initialized
DEBUG - 2011-05-25 01:54:09 --> Hooks Class Initialized
DEBUG - 2011-05-25 01:54:09 --> Utf8 Class Initialized
DEBUG - 2011-05-25 01:54:09 --> UTF-8 Support Enabled
DEBUG - 2011-05-25 01:54:09 --> URI Class Initialized
DEBUG - 2011-05-25 01:54:09 --> Router Class Initialized
DEBUG - 2011-05-25 01:54:09 --> Output Class Initialized
DEBUG - 2011-05-25 01:54:09 --> Input Class Initialized
DEBUG - 2011-05-25 01:54:09 --> Global POST and COOKIE data sanitized
DEBUG - 2011-05-25 01:54:09 --> Language Class Initialized
DEBUG - 2011-05-25 01:54:09 --> Loader Class Initialized
DEBUG - 2011-05-25 01:54:09 --> Controller Class Initialized
ERROR - 2011-05-25 01:54:09 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-05-25 01:54:09 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-05-25 01:54:09 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-05-25 01:54:09 --> Model Class Initialized
DEBUG - 2011-05-25 01:54:09 --> Model Class Initialized
DEBUG - 2011-05-25 01:54:09 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-05-25 01:54:09 --> Database Driver Class Initialized
DEBUG - 2011-05-25 01:54:09 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-05-25 01:54:09 --> Helper loaded: url_helper
DEBUG - 2011-05-25 01:54:09 --> File loaded: application/views/common/header.php
DEBUG - 2011-05-25 01:54:09 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-05-25 01:54:09 --> File loaded: application/views/common/footer.php
DEBUG - 2011-05-25 01:54:09 --> File loaded: application/views/layout/main.php
DEBUG - 2011-05-25 01:54:09 --> Final output sent to browser
DEBUG - 2011-05-25 01:54:09 --> Total execution time: 0.2855
DEBUG - 2011-05-25 01:54:11 --> Config Class Initialized
DEBUG - 2011-05-25 01:54:11 --> Hooks Class Initialized
DEBUG - 2011-05-25 01:54:11 --> Utf8 Class Initialized
DEBUG - 2011-05-25 01:54:11 --> UTF-8 Support Enabled
DEBUG - 2011-05-25 01:54:11 --> URI Class Initialized
DEBUG - 2011-05-25 01:54:11 --> Router Class Initialized
DEBUG - 2011-05-25 01:54:11 --> Output Class Initialized
DEBUG - 2011-05-25 01:54:11 --> Input Class Initialized
DEBUG - 2011-05-25 01:54:11 --> Global POST and COOKIE data sanitized
DEBUG - 2011-05-25 01:54:11 --> Language Class Initialized
DEBUG - 2011-05-25 01:54:11 --> Loader Class Initialized
DEBUG - 2011-05-25 01:54:11 --> Controller Class Initialized
DEBUG - 2011-05-25 01:54:11 --> Model Class Initialized
DEBUG - 2011-05-25 01:54:12 --> Model Class Initialized
DEBUG - 2011-05-25 01:54:12 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-05-25 01:54:12 --> Database Driver Class Initialized
DEBUG - 2011-05-25 01:54:13 --> Final output sent to browser
DEBUG - 2011-05-25 01:54:13 --> Total execution time: 2.4160
DEBUG - 2011-05-25 01:54:15 --> Config Class Initialized
DEBUG - 2011-05-25 01:54:15 --> Hooks Class Initialized
DEBUG - 2011-05-25 01:54:15 --> Utf8 Class Initialized
DEBUG - 2011-05-25 01:54:15 --> UTF-8 Support Enabled
DEBUG - 2011-05-25 01:54:15 --> URI Class Initialized
DEBUG - 2011-05-25 01:54:15 --> Router Class Initialized
ERROR - 2011-05-25 01:54:15 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-05-25 03:07:25 --> Config Class Initialized
DEBUG - 2011-05-25 03:07:25 --> Hooks Class Initialized
DEBUG - 2011-05-25 03:07:25 --> Utf8 Class Initialized
DEBUG - 2011-05-25 03:07:25 --> UTF-8 Support Enabled
DEBUG - 2011-05-25 03:07:25 --> URI Class Initialized
DEBUG - 2011-05-25 03:07:25 --> Router Class Initialized
DEBUG - 2011-05-25 03:07:25 --> No URI present. Default controller set.
DEBUG - 2011-05-25 03:07:25 --> Output Class Initialized
DEBUG - 2011-05-25 03:07:25 --> Input Class Initialized
DEBUG - 2011-05-25 03:07:25 --> Global POST and COOKIE data sanitized
DEBUG - 2011-05-25 03:07:25 --> Language Class Initialized
DEBUG - 2011-05-25 03:07:25 --> Loader Class Initialized
DEBUG - 2011-05-25 03:07:25 --> Controller Class Initialized
DEBUG - 2011-05-25 03:07:25 --> File loaded: application/views/splash/main.php
DEBUG - 2011-05-25 03:07:25 --> Helper loaded: url_helper
DEBUG - 2011-05-25 03:07:25 --> File loaded: application/views/common/header.php
DEBUG - 2011-05-25 03:07:25 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-05-25 03:07:25 --> File loaded: application/views/common/footer.php
DEBUG - 2011-05-25 03:07:25 --> File loaded: application/views/layout/main.php
DEBUG - 2011-05-25 03:07:25 --> Final output sent to browser
DEBUG - 2011-05-25 03:07:25 --> Total execution time: 0.3137
DEBUG - 2011-05-25 03:26:36 --> Config Class Initialized
DEBUG - 2011-05-25 03:26:36 --> Hooks Class Initialized
DEBUG - 2011-05-25 03:26:36 --> Utf8 Class Initialized
DEBUG - 2011-05-25 03:26:36 --> UTF-8 Support Enabled
DEBUG - 2011-05-25 03:26:36 --> URI Class Initialized
DEBUG - 2011-05-25 03:26:36 --> Router Class Initialized
DEBUG - 2011-05-25 03:26:36 --> No URI present. Default controller set.
DEBUG - 2011-05-25 03:26:36 --> Output Class Initialized
DEBUG - 2011-05-25 03:26:36 --> Input Class Initialized
DEBUG - 2011-05-25 03:26:36 --> Global POST and COOKIE data sanitized
DEBUG - 2011-05-25 03:26:36 --> Language Class Initialized
DEBUG - 2011-05-25 03:26:36 --> Loader Class Initialized
DEBUG - 2011-05-25 03:26:36 --> Controller Class Initialized
DEBUG - 2011-05-25 03:26:36 --> File loaded: application/views/splash/main.php
DEBUG - 2011-05-25 03:26:36 --> Helper loaded: url_helper
DEBUG - 2011-05-25 03:26:36 --> File loaded: application/views/common/header.php
DEBUG - 2011-05-25 03:26:36 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-05-25 03:26:36 --> File loaded: application/views/common/footer.php
DEBUG - 2011-05-25 03:26:36 --> File loaded: application/views/layout/main.php
DEBUG - 2011-05-25 03:26:36 --> Final output sent to browser
DEBUG - 2011-05-25 03:26:36 --> Total execution time: 0.3935
DEBUG - 2011-05-25 03:26:37 --> Config Class Initialized
DEBUG - 2011-05-25 03:26:37 --> Hooks Class Initialized
DEBUG - 2011-05-25 03:26:37 --> Utf8 Class Initialized
DEBUG - 2011-05-25 03:26:37 --> UTF-8 Support Enabled
DEBUG - 2011-05-25 03:26:37 --> URI Class Initialized
DEBUG - 2011-05-25 03:26:37 --> Router Class Initialized
ERROR - 2011-05-25 03:26:37 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-05-25 03:26:44 --> Config Class Initialized
DEBUG - 2011-05-25 03:26:44 --> Hooks Class Initialized
DEBUG - 2011-05-25 03:26:44 --> Utf8 Class Initialized
DEBUG - 2011-05-25 03:26:44 --> UTF-8 Support Enabled
DEBUG - 2011-05-25 03:26:44 --> URI Class Initialized
DEBUG - 2011-05-25 03:26:44 --> Router Class Initialized
DEBUG - 2011-05-25 03:26:44 --> Output Class Initialized
DEBUG - 2011-05-25 03:26:44 --> Input Class Initialized
DEBUG - 2011-05-25 03:26:44 --> Global POST and COOKIE data sanitized
DEBUG - 2011-05-25 03:26:44 --> Language Class Initialized
DEBUG - 2011-05-25 03:26:44 --> Loader Class Initialized
DEBUG - 2011-05-25 03:26:44 --> Controller Class Initialized
DEBUG - 2011-05-25 03:26:44 --> Model Class Initialized
DEBUG - 2011-05-25 03:26:44 --> Model Class Initialized
DEBUG - 2011-05-25 03:26:44 --> Model Class Initialized
DEBUG - 2011-05-25 03:26:44 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-05-25 03:26:44 --> Database Driver Class Initialized
DEBUG - 2011-05-25 03:26:44 --> File loaded: application/views/table/main.php
DEBUG - 2011-05-25 03:26:44 --> Helper loaded: url_helper
DEBUG - 2011-05-25 03:26:44 --> File loaded: application/views/common/header.php
DEBUG - 2011-05-25 03:26:44 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-05-25 03:26:44 --> File loaded: application/views/common/footer.php
DEBUG - 2011-05-25 03:26:44 --> File loaded: application/views/layout/main.php
DEBUG - 2011-05-25 03:26:44 --> Final output sent to browser
DEBUG - 2011-05-25 03:26:44 --> Total execution time: 0.4036
DEBUG - 2011-05-25 03:26:45 --> Config Class Initialized
DEBUG - 2011-05-25 03:26:45 --> Hooks Class Initialized
DEBUG - 2011-05-25 03:26:45 --> Utf8 Class Initialized
DEBUG - 2011-05-25 03:26:45 --> UTF-8 Support Enabled
DEBUG - 2011-05-25 03:26:45 --> URI Class Initialized
DEBUG - 2011-05-25 03:26:45 --> Router Class Initialized
ERROR - 2011-05-25 03:26:45 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-05-25 03:27:03 --> Config Class Initialized
DEBUG - 2011-05-25 03:27:03 --> Hooks Class Initialized
DEBUG - 2011-05-25 03:27:03 --> Utf8 Class Initialized
DEBUG - 2011-05-25 03:27:03 --> UTF-8 Support Enabled
DEBUG - 2011-05-25 03:27:03 --> URI Class Initialized
DEBUG - 2011-05-25 03:27:03 --> Router Class Initialized
DEBUG - 2011-05-25 03:27:03 --> Output Class Initialized
DEBUG - 2011-05-25 03:27:03 --> Input Class Initialized
DEBUG - 2011-05-25 03:27:03 --> Global POST and COOKIE data sanitized
DEBUG - 2011-05-25 03:27:03 --> Language Class Initialized
DEBUG - 2011-05-25 03:27:03 --> Loader Class Initialized
DEBUG - 2011-05-25 03:27:03 --> Controller Class Initialized
DEBUG - 2011-05-25 03:27:03 --> Model Class Initialized
DEBUG - 2011-05-25 03:27:03 --> Model Class Initialized
DEBUG - 2011-05-25 03:27:03 --> Model Class Initialized
DEBUG - 2011-05-25 03:27:03 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-05-25 03:27:03 --> Database Driver Class Initialized
DEBUG - 2011-05-25 03:27:03 --> File loaded: application/views/table/main.php
DEBUG - 2011-05-25 03:27:03 --> Helper loaded: url_helper
DEBUG - 2011-05-25 03:27:03 --> File loaded: application/views/common/header.php
DEBUG - 2011-05-25 03:27:03 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-05-25 03:27:03 --> File loaded: application/views/common/footer.php
DEBUG - 2011-05-25 03:27:03 --> File loaded: application/views/layout/main.php
DEBUG - 2011-05-25 03:27:03 --> Final output sent to browser
DEBUG - 2011-05-25 03:27:03 --> Total execution time: 0.1959
DEBUG - 2011-05-25 03:27:04 --> Config Class Initialized
DEBUG - 2011-05-25 03:27:04 --> Hooks Class Initialized
DEBUG - 2011-05-25 03:27:04 --> Utf8 Class Initialized
DEBUG - 2011-05-25 03:27:04 --> UTF-8 Support Enabled
DEBUG - 2011-05-25 03:27:04 --> URI Class Initialized
DEBUG - 2011-05-25 03:27:04 --> Router Class Initialized
ERROR - 2011-05-25 03:27:04 --> 404 Page Not Found --> robots.txt
DEBUG - 2011-05-25 03:27:04 --> Config Class Initialized
DEBUG - 2011-05-25 03:27:04 --> Hooks Class Initialized
DEBUG - 2011-05-25 03:27:04 --> Utf8 Class Initialized
DEBUG - 2011-05-25 03:27:04 --> UTF-8 Support Enabled
DEBUG - 2011-05-25 03:27:04 --> URI Class Initialized
DEBUG - 2011-05-25 03:27:04 --> Router Class Initialized
DEBUG - 2011-05-25 03:27:04 --> Output Class Initialized
DEBUG - 2011-05-25 03:27:04 --> Input Class Initialized
DEBUG - 2011-05-25 03:27:04 --> Global POST and COOKIE data sanitized
DEBUG - 2011-05-25 03:27:04 --> Language Class Initialized
DEBUG - 2011-05-25 03:27:04 --> Loader Class Initialized
DEBUG - 2011-05-25 03:27:04 --> Controller Class Initialized
DEBUG - 2011-05-25 03:27:04 --> Model Class Initialized
DEBUG - 2011-05-25 03:27:04 --> Model Class Initialized
DEBUG - 2011-05-25 03:27:04 --> Model Class Initialized
DEBUG - 2011-05-25 03:27:04 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-05-25 03:27:04 --> Database Driver Class Initialized
DEBUG - 2011-05-25 03:27:04 --> File loaded: application/views/table/main.php
DEBUG - 2011-05-25 03:27:04 --> Helper loaded: url_helper
DEBUG - 2011-05-25 03:27:04 --> File loaded: application/views/common/header.php
DEBUG - 2011-05-25 03:27:04 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-05-25 03:27:04 --> File loaded: application/views/common/footer.php
DEBUG - 2011-05-25 03:27:04 --> File loaded: application/views/layout/main.php
DEBUG - 2011-05-25 03:27:04 --> Final output sent to browser
DEBUG - 2011-05-25 03:27:04 --> Total execution time: 0.0476
DEBUG - 2011-05-25 03:27:05 --> Config Class Initialized
DEBUG - 2011-05-25 03:27:05 --> Hooks Class Initialized
DEBUG - 2011-05-25 03:27:05 --> Utf8 Class Initialized
DEBUG - 2011-05-25 03:27:05 --> UTF-8 Support Enabled
DEBUG - 2011-05-25 03:27:05 --> URI Class Initialized
DEBUG - 2011-05-25 03:27:05 --> Router Class Initialized
ERROR - 2011-05-25 03:27:05 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-05-25 03:27:20 --> Config Class Initialized
DEBUG - 2011-05-25 03:27:20 --> Hooks Class Initialized
DEBUG - 2011-05-25 03:27:20 --> Utf8 Class Initialized
DEBUG - 2011-05-25 03:27:20 --> UTF-8 Support Enabled
DEBUG - 2011-05-25 03:27:20 --> URI Class Initialized
DEBUG - 2011-05-25 03:27:20 --> Router Class Initialized
DEBUG - 2011-05-25 03:27:20 --> Output Class Initialized
DEBUG - 2011-05-25 03:27:20 --> Input Class Initialized
DEBUG - 2011-05-25 03:27:20 --> Global POST and COOKIE data sanitized
DEBUG - 2011-05-25 03:27:20 --> Language Class Initialized
DEBUG - 2011-05-25 03:27:20 --> Loader Class Initialized
DEBUG - 2011-05-25 03:27:20 --> Controller Class Initialized
DEBUG - 2011-05-25 03:27:20 --> Model Class Initialized
DEBUG - 2011-05-25 03:27:20 --> Model Class Initialized
DEBUG - 2011-05-25 03:27:20 --> Model Class Initialized
DEBUG - 2011-05-25 03:27:20 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-05-25 03:27:20 --> Database Driver Class Initialized
DEBUG - 2011-05-25 03:27:20 --> File loaded: application/views/table/main.php
DEBUG - 2011-05-25 03:27:20 --> Helper loaded: url_helper
DEBUG - 2011-05-25 03:27:20 --> File loaded: application/views/common/header.php
DEBUG - 2011-05-25 03:27:20 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-05-25 03:27:20 --> File loaded: application/views/common/footer.php
DEBUG - 2011-05-25 03:27:20 --> File loaded: application/views/layout/main.php
DEBUG - 2011-05-25 03:27:20 --> Final output sent to browser
DEBUG - 2011-05-25 03:27:20 --> Total execution time: 0.2018
DEBUG - 2011-05-25 03:27:21 --> Config Class Initialized
DEBUG - 2011-05-25 03:27:21 --> Hooks Class Initialized
DEBUG - 2011-05-25 03:27:21 --> Utf8 Class Initialized
DEBUG - 2011-05-25 03:27:21 --> UTF-8 Support Enabled
DEBUG - 2011-05-25 03:27:21 --> URI Class Initialized
DEBUG - 2011-05-25 03:27:21 --> Router Class Initialized
DEBUG - 2011-05-25 03:27:21 --> Output Class Initialized
DEBUG - 2011-05-25 03:27:21 --> Input Class Initialized
DEBUG - 2011-05-25 03:27:21 --> Global POST and COOKIE data sanitized
DEBUG - 2011-05-25 03:27:21 --> Language Class Initialized
DEBUG - 2011-05-25 03:27:21 --> Loader Class Initialized
DEBUG - 2011-05-25 03:27:21 --> Controller Class Initialized
DEBUG - 2011-05-25 03:27:21 --> Model Class Initialized
DEBUG - 2011-05-25 03:27:21 --> Model Class Initialized
DEBUG - 2011-05-25 03:27:21 --> Model Class Initialized
DEBUG - 2011-05-25 03:27:21 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-05-25 03:27:21 --> Database Driver Class Initialized
DEBUG - 2011-05-25 03:27:21 --> File loaded: application/views/table/main.php
DEBUG - 2011-05-25 03:27:21 --> Helper loaded: url_helper
DEBUG - 2011-05-25 03:27:21 --> File loaded: application/views/common/header.php
DEBUG - 2011-05-25 03:27:21 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-05-25 03:27:21 --> File loaded: application/views/common/footer.php
DEBUG - 2011-05-25 03:27:21 --> File loaded: application/views/layout/main.php
DEBUG - 2011-05-25 03:27:21 --> Final output sent to browser
DEBUG - 2011-05-25 03:27:21 --> Total execution time: 0.0816
DEBUG - 2011-05-25 03:27:21 --> Config Class Initialized
DEBUG - 2011-05-25 03:27:21 --> Hooks Class Initialized
DEBUG - 2011-05-25 03:27:21 --> Utf8 Class Initialized
DEBUG - 2011-05-25 03:27:21 --> UTF-8 Support Enabled
DEBUG - 2011-05-25 03:27:21 --> URI Class Initialized
DEBUG - 2011-05-25 03:27:21 --> Router Class Initialized
DEBUG - 2011-05-25 03:27:21 --> Output Class Initialized
DEBUG - 2011-05-25 03:27:21 --> Input Class Initialized
DEBUG - 2011-05-25 03:27:21 --> Global POST and COOKIE data sanitized
DEBUG - 2011-05-25 03:27:21 --> Language Class Initialized
DEBUG - 2011-05-25 03:27:21 --> Loader Class Initialized
DEBUG - 2011-05-25 03:27:21 --> Controller Class Initialized
DEBUG - 2011-05-25 03:27:21 --> Model Class Initialized
DEBUG - 2011-05-25 03:27:21 --> Model Class Initialized
DEBUG - 2011-05-25 03:27:21 --> Model Class Initialized
DEBUG - 2011-05-25 03:27:21 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-05-25 03:27:21 --> Database Driver Class Initialized
DEBUG - 2011-05-25 03:27:21 --> File loaded: application/views/table/main.php
DEBUG - 2011-05-25 03:27:21 --> Helper loaded: url_helper
DEBUG - 2011-05-25 03:27:21 --> File loaded: application/views/common/header.php
DEBUG - 2011-05-25 03:27:21 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-05-25 03:27:21 --> File loaded: application/views/common/footer.php
DEBUG - 2011-05-25 03:27:21 --> File loaded: application/views/layout/main.php
DEBUG - 2011-05-25 03:27:21 --> Final output sent to browser
DEBUG - 2011-05-25 03:27:21 --> Total execution time: 0.0863
DEBUG - 2011-05-25 03:27:21 --> Config Class Initialized
DEBUG - 2011-05-25 03:27:21 --> Hooks Class Initialized
DEBUG - 2011-05-25 03:27:21 --> Utf8 Class Initialized
DEBUG - 2011-05-25 03:27:21 --> UTF-8 Support Enabled
DEBUG - 2011-05-25 03:27:21 --> URI Class Initialized
DEBUG - 2011-05-25 03:27:21 --> Router Class Initialized
ERROR - 2011-05-25 03:27:21 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-05-25 04:07:32 --> Config Class Initialized
DEBUG - 2011-05-25 04:07:32 --> Hooks Class Initialized
DEBUG - 2011-05-25 04:07:32 --> Utf8 Class Initialized
DEBUG - 2011-05-25 04:07:32 --> UTF-8 Support Enabled
DEBUG - 2011-05-25 04:07:32 --> URI Class Initialized
DEBUG - 2011-05-25 04:07:32 --> Router Class Initialized
DEBUG - 2011-05-25 04:07:32 --> Output Class Initialized
DEBUG - 2011-05-25 04:07:32 --> Input Class Initialized
DEBUG - 2011-05-25 04:07:32 --> Global POST and COOKIE data sanitized
DEBUG - 2011-05-25 04:07:32 --> Language Class Initialized
DEBUG - 2011-05-25 04:07:32 --> Loader Class Initialized
DEBUG - 2011-05-25 04:07:32 --> Controller Class Initialized
DEBUG - 2011-05-25 04:07:32 --> Model Class Initialized
DEBUG - 2011-05-25 04:07:32 --> Model Class Initialized
DEBUG - 2011-05-25 04:07:32 --> Model Class Initialized
DEBUG - 2011-05-25 04:07:32 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-05-25 04:07:32 --> Database Driver Class Initialized
DEBUG - 2011-05-25 04:07:33 --> File loaded: application/views/table/main.php
DEBUG - 2011-05-25 04:07:33 --> Helper loaded: url_helper
DEBUG - 2011-05-25 04:07:33 --> File loaded: application/views/common/header.php
DEBUG - 2011-05-25 04:07:33 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-05-25 04:07:33 --> File loaded: application/views/common/footer.php
DEBUG - 2011-05-25 04:07:33 --> File loaded: application/views/layout/main.php
DEBUG - 2011-05-25 04:07:33 --> Final output sent to browser
DEBUG - 2011-05-25 04:07:33 --> Total execution time: 0.7496
DEBUG - 2011-05-25 04:07:34 --> Config Class Initialized
DEBUG - 2011-05-25 04:07:34 --> Hooks Class Initialized
DEBUG - 2011-05-25 04:07:34 --> Utf8 Class Initialized
DEBUG - 2011-05-25 04:07:34 --> UTF-8 Support Enabled
DEBUG - 2011-05-25 04:07:34 --> URI Class Initialized
DEBUG - 2011-05-25 04:07:34 --> Router Class Initialized
DEBUG - 2011-05-25 04:07:34 --> Output Class Initialized
DEBUG - 2011-05-25 04:07:34 --> Input Class Initialized
DEBUG - 2011-05-25 04:07:34 --> Global POST and COOKIE data sanitized
DEBUG - 2011-05-25 04:07:34 --> Language Class Initialized
DEBUG - 2011-05-25 04:07:34 --> Loader Class Initialized
DEBUG - 2011-05-25 04:07:34 --> Controller Class Initialized
ERROR - 2011-05-25 04:07:34 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-05-25 04:07:34 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-05-25 04:07:34 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-05-25 04:07:34 --> Model Class Initialized
DEBUG - 2011-05-25 04:07:34 --> Model Class Initialized
DEBUG - 2011-05-25 04:07:34 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-05-25 04:07:34 --> Database Driver Class Initialized
DEBUG - 2011-05-25 04:07:34 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-05-25 04:07:34 --> Helper loaded: url_helper
DEBUG - 2011-05-25 04:07:34 --> File loaded: application/views/common/header.php
DEBUG - 2011-05-25 04:07:34 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-05-25 04:07:34 --> File loaded: application/views/common/footer.php
DEBUG - 2011-05-25 04:07:34 --> File loaded: application/views/layout/main.php
DEBUG - 2011-05-25 04:07:34 --> Final output sent to browser
DEBUG - 2011-05-25 04:07:34 --> Total execution time: 0.0994
DEBUG - 2011-05-25 05:32:52 --> Config Class Initialized
DEBUG - 2011-05-25 05:32:52 --> Hooks Class Initialized
DEBUG - 2011-05-25 05:32:52 --> Utf8 Class Initialized
DEBUG - 2011-05-25 05:32:52 --> UTF-8 Support Enabled
DEBUG - 2011-05-25 05:32:52 --> URI Class Initialized
DEBUG - 2011-05-25 05:32:52 --> Router Class Initialized
ERROR - 2011-05-25 05:32:52 --> 404 Page Not Found --> robots.txt
DEBUG - 2011-05-25 05:32:53 --> Config Class Initialized
DEBUG - 2011-05-25 05:32:53 --> Hooks Class Initialized
DEBUG - 2011-05-25 05:32:53 --> Utf8 Class Initialized
DEBUG - 2011-05-25 05:32:53 --> UTF-8 Support Enabled
DEBUG - 2011-05-25 05:32:53 --> URI Class Initialized
DEBUG - 2011-05-25 05:32:53 --> Router Class Initialized
DEBUG - 2011-05-25 05:32:53 --> Output Class Initialized
DEBUG - 2011-05-25 05:32:53 --> Input Class Initialized
DEBUG - 2011-05-25 05:32:53 --> Global POST and COOKIE data sanitized
DEBUG - 2011-05-25 05:32:53 --> Language Class Initialized
DEBUG - 2011-05-25 05:32:53 --> Loader Class Initialized
DEBUG - 2011-05-25 05:32:53 --> Controller Class Initialized
ERROR - 2011-05-25 05:32:53 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-05-25 05:32:53 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-05-25 05:32:53 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-05-25 05:32:53 --> Model Class Initialized
DEBUG - 2011-05-25 05:32:53 --> Model Class Initialized
DEBUG - 2011-05-25 05:32:53 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-05-25 05:32:53 --> Database Driver Class Initialized
DEBUG - 2011-05-25 05:32:53 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-05-25 05:32:53 --> Helper loaded: url_helper
DEBUG - 2011-05-25 05:32:53 --> File loaded: application/views/common/header.php
DEBUG - 2011-05-25 05:32:53 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-05-25 05:32:53 --> File loaded: application/views/common/footer.php
DEBUG - 2011-05-25 05:32:53 --> File loaded: application/views/layout/main.php
DEBUG - 2011-05-25 05:32:53 --> Final output sent to browser
DEBUG - 2011-05-25 05:32:53 --> Total execution time: 0.3623
DEBUG - 2011-05-25 05:46:29 --> Config Class Initialized
DEBUG - 2011-05-25 05:46:29 --> Hooks Class Initialized
DEBUG - 2011-05-25 05:46:29 --> Utf8 Class Initialized
DEBUG - 2011-05-25 05:46:29 --> UTF-8 Support Enabled
DEBUG - 2011-05-25 05:46:29 --> URI Class Initialized
DEBUG - 2011-05-25 05:46:29 --> Router Class Initialized
DEBUG - 2011-05-25 05:46:29 --> Output Class Initialized
DEBUG - 2011-05-25 05:46:29 --> Input Class Initialized
DEBUG - 2011-05-25 05:46:29 --> Global POST and COOKIE data sanitized
DEBUG - 2011-05-25 05:46:29 --> Language Class Initialized
DEBUG - 2011-05-25 05:46:29 --> Loader Class Initialized
DEBUG - 2011-05-25 05:46:29 --> Controller Class Initialized
ERROR - 2011-05-25 05:46:29 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-05-25 05:46:29 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-05-25 05:46:29 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-05-25 05:46:29 --> Model Class Initialized
DEBUG - 2011-05-25 05:46:29 --> Model Class Initialized
DEBUG - 2011-05-25 05:46:29 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-05-25 05:46:29 --> Database Driver Class Initialized
DEBUG - 2011-05-25 05:46:30 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-05-25 05:46:30 --> Helper loaded: url_helper
DEBUG - 2011-05-25 05:46:30 --> File loaded: application/views/common/header.php
DEBUG - 2011-05-25 05:46:30 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-05-25 05:46:30 --> File loaded: application/views/common/footer.php
DEBUG - 2011-05-25 05:46:30 --> File loaded: application/views/layout/main.php
DEBUG - 2011-05-25 05:46:30 --> Final output sent to browser
DEBUG - 2011-05-25 05:46:30 --> Total execution time: 0.1897
DEBUG - 2011-05-25 05:46:30 --> Config Class Initialized
DEBUG - 2011-05-25 05:46:30 --> Hooks Class Initialized
DEBUG - 2011-05-25 05:46:30 --> Utf8 Class Initialized
DEBUG - 2011-05-25 05:46:30 --> UTF-8 Support Enabled
DEBUG - 2011-05-25 05:46:30 --> URI Class Initialized
DEBUG - 2011-05-25 05:46:30 --> Router Class Initialized
DEBUG - 2011-05-25 05:46:30 --> Output Class Initialized
DEBUG - 2011-05-25 05:46:30 --> Input Class Initialized
DEBUG - 2011-05-25 05:46:30 --> Global POST and COOKIE data sanitized
DEBUG - 2011-05-25 05:46:30 --> Language Class Initialized
DEBUG - 2011-05-25 05:46:30 --> Loader Class Initialized
DEBUG - 2011-05-25 05:46:30 --> Controller Class Initialized
DEBUG - 2011-05-25 05:46:30 --> Model Class Initialized
DEBUG - 2011-05-25 05:46:30 --> Model Class Initialized
DEBUG - 2011-05-25 05:46:30 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-05-25 05:46:30 --> Database Driver Class Initialized
DEBUG - 2011-05-25 05:46:31 --> Final output sent to browser
DEBUG - 2011-05-25 05:46:31 --> Total execution time: 0.7286
DEBUG - 2011-05-25 05:46:32 --> Config Class Initialized
DEBUG - 2011-05-25 05:46:32 --> Hooks Class Initialized
DEBUG - 2011-05-25 05:46:32 --> Utf8 Class Initialized
DEBUG - 2011-05-25 05:46:32 --> UTF-8 Support Enabled
DEBUG - 2011-05-25 05:46:32 --> URI Class Initialized
DEBUG - 2011-05-25 05:46:32 --> Router Class Initialized
ERROR - 2011-05-25 05:46:32 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-05-25 05:46:34 --> Config Class Initialized
DEBUG - 2011-05-25 05:46:34 --> Hooks Class Initialized
DEBUG - 2011-05-25 05:46:34 --> Utf8 Class Initialized
DEBUG - 2011-05-25 05:46:34 --> UTF-8 Support Enabled
DEBUG - 2011-05-25 05:46:34 --> URI Class Initialized
DEBUG - 2011-05-25 05:46:34 --> Router Class Initialized
ERROR - 2011-05-25 05:46:34 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-05-25 05:48:09 --> Config Class Initialized
DEBUG - 2011-05-25 05:48:09 --> Hooks Class Initialized
DEBUG - 2011-05-25 05:48:09 --> Utf8 Class Initialized
DEBUG - 2011-05-25 05:48:09 --> UTF-8 Support Enabled
DEBUG - 2011-05-25 05:48:09 --> URI Class Initialized
DEBUG - 2011-05-25 05:48:09 --> Router Class Initialized
DEBUG - 2011-05-25 05:48:09 --> Output Class Initialized
DEBUG - 2011-05-25 05:48:09 --> Input Class Initialized
DEBUG - 2011-05-25 05:48:09 --> Global POST and COOKIE data sanitized
DEBUG - 2011-05-25 05:48:09 --> Language Class Initialized
DEBUG - 2011-05-25 05:48:09 --> Loader Class Initialized
DEBUG - 2011-05-25 05:48:09 --> Controller Class Initialized
ERROR - 2011-05-25 05:48:09 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-05-25 05:48:09 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-05-25 05:48:09 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-05-25 05:48:09 --> Model Class Initialized
DEBUG - 2011-05-25 05:48:09 --> Model Class Initialized
DEBUG - 2011-05-25 05:48:09 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-05-25 05:48:09 --> Database Driver Class Initialized
DEBUG - 2011-05-25 05:48:09 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-05-25 05:48:09 --> Helper loaded: url_helper
DEBUG - 2011-05-25 05:48:09 --> File loaded: application/views/common/header.php
DEBUG - 2011-05-25 05:48:09 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-05-25 05:48:09 --> File loaded: application/views/common/footer.php
DEBUG - 2011-05-25 05:48:09 --> File loaded: application/views/layout/main.php
DEBUG - 2011-05-25 05:48:09 --> Final output sent to browser
DEBUG - 2011-05-25 05:48:09 --> Total execution time: 0.0836
DEBUG - 2011-05-25 05:48:10 --> Config Class Initialized
DEBUG - 2011-05-25 05:48:10 --> Hooks Class Initialized
DEBUG - 2011-05-25 05:48:10 --> Utf8 Class Initialized
DEBUG - 2011-05-25 05:48:10 --> UTF-8 Support Enabled
DEBUG - 2011-05-25 05:48:10 --> URI Class Initialized
DEBUG - 2011-05-25 05:48:10 --> Router Class Initialized
DEBUG - 2011-05-25 05:48:10 --> Output Class Initialized
DEBUG - 2011-05-25 05:48:10 --> Input Class Initialized
DEBUG - 2011-05-25 05:48:10 --> Global POST and COOKIE data sanitized
DEBUG - 2011-05-25 05:48:10 --> Language Class Initialized
DEBUG - 2011-05-25 05:48:10 --> Loader Class Initialized
DEBUG - 2011-05-25 05:48:10 --> Controller Class Initialized
DEBUG - 2011-05-25 05:48:10 --> Model Class Initialized
DEBUG - 2011-05-25 05:48:10 --> Model Class Initialized
DEBUG - 2011-05-25 05:48:10 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-05-25 05:48:10 --> Database Driver Class Initialized
DEBUG - 2011-05-25 05:48:10 --> Config Class Initialized
DEBUG - 2011-05-25 05:48:10 --> Hooks Class Initialized
DEBUG - 2011-05-25 05:48:10 --> Utf8 Class Initialized
DEBUG - 2011-05-25 05:48:10 --> UTF-8 Support Enabled
DEBUG - 2011-05-25 05:48:10 --> URI Class Initialized
DEBUG - 2011-05-25 05:48:10 --> Router Class Initialized
DEBUG - 2011-05-25 05:48:10 --> Output Class Initialized
DEBUG - 2011-05-25 05:48:10 --> Input Class Initialized
DEBUG - 2011-05-25 05:48:10 --> Global POST and COOKIE data sanitized
DEBUG - 2011-05-25 05:48:10 --> Language Class Initialized
DEBUG - 2011-05-25 05:48:10 --> Loader Class Initialized
DEBUG - 2011-05-25 05:48:10 --> Controller Class Initialized
ERROR - 2011-05-25 05:48:10 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-05-25 05:48:10 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-05-25 05:48:10 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-05-25 05:48:10 --> Model Class Initialized
DEBUG - 2011-05-25 05:48:10 --> Model Class Initialized
DEBUG - 2011-05-25 05:48:10 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-05-25 05:48:10 --> Database Driver Class Initialized
DEBUG - 2011-05-25 05:48:10 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-05-25 05:48:10 --> Helper loaded: url_helper
DEBUG - 2011-05-25 05:48:10 --> File loaded: application/views/common/header.php
DEBUG - 2011-05-25 05:48:10 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-05-25 05:48:10 --> File loaded: application/views/common/footer.php
DEBUG - 2011-05-25 05:48:10 --> File loaded: application/views/layout/main.php
DEBUG - 2011-05-25 05:48:10 --> Final output sent to browser
DEBUG - 2011-05-25 05:48:10 --> Total execution time: 0.1233
DEBUG - 2011-05-25 05:48:11 --> Config Class Initialized
DEBUG - 2011-05-25 05:48:11 --> Hooks Class Initialized
DEBUG - 2011-05-25 05:48:11 --> Utf8 Class Initialized
DEBUG - 2011-05-25 05:48:11 --> UTF-8 Support Enabled
DEBUG - 2011-05-25 05:48:11 --> URI Class Initialized
DEBUG - 2011-05-25 05:48:11 --> Router Class Initialized
DEBUG - 2011-05-25 05:48:11 --> Output Class Initialized
DEBUG - 2011-05-25 05:48:11 --> Input Class Initialized
DEBUG - 2011-05-25 05:48:11 --> Global POST and COOKIE data sanitized
DEBUG - 2011-05-25 05:48:11 --> Language Class Initialized
DEBUG - 2011-05-25 05:48:11 --> Loader Class Initialized
DEBUG - 2011-05-25 05:48:11 --> Controller Class Initialized
ERROR - 2011-05-25 05:48:11 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-05-25 05:48:11 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-05-25 05:48:11 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-05-25 05:48:11 --> Model Class Initialized
DEBUG - 2011-05-25 05:48:11 --> Model Class Initialized
DEBUG - 2011-05-25 05:48:11 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-05-25 05:48:11 --> Database Driver Class Initialized
DEBUG - 2011-05-25 05:48:11 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-05-25 05:48:11 --> Helper loaded: url_helper
DEBUG - 2011-05-25 05:48:11 --> File loaded: application/views/common/header.php
DEBUG - 2011-05-25 05:48:11 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-05-25 05:48:11 --> File loaded: application/views/common/footer.php
DEBUG - 2011-05-25 05:48:11 --> File loaded: application/views/layout/main.php
DEBUG - 2011-05-25 05:48:11 --> Final output sent to browser
DEBUG - 2011-05-25 05:48:11 --> Total execution time: 0.0944
DEBUG - 2011-05-25 05:48:11 --> Final output sent to browser
DEBUG - 2011-05-25 05:48:11 --> Total execution time: 0.9422
DEBUG - 2011-05-25 07:32:53 --> Config Class Initialized
DEBUG - 2011-05-25 07:32:53 --> Hooks Class Initialized
DEBUG - 2011-05-25 07:32:53 --> Utf8 Class Initialized
DEBUG - 2011-05-25 07:32:53 --> UTF-8 Support Enabled
DEBUG - 2011-05-25 07:32:53 --> URI Class Initialized
DEBUG - 2011-05-25 07:32:53 --> Router Class Initialized
DEBUG - 2011-05-25 07:32:53 --> Output Class Initialized
DEBUG - 2011-05-25 07:32:53 --> Input Class Initialized
DEBUG - 2011-05-25 07:32:53 --> Global POST and COOKIE data sanitized
DEBUG - 2011-05-25 07:32:53 --> Language Class Initialized
DEBUG - 2011-05-25 07:32:53 --> Loader Class Initialized
DEBUG - 2011-05-25 07:32:53 --> Controller Class Initialized
DEBUG - 2011-05-25 07:32:53 --> Model Class Initialized
DEBUG - 2011-05-25 07:32:53 --> Model Class Initialized
DEBUG - 2011-05-25 07:32:53 --> Model Class Initialized
DEBUG - 2011-05-25 07:32:53 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-05-25 07:32:53 --> Database Driver Class Initialized
DEBUG - 2011-05-25 07:32:54 --> File loaded: application/views/table/main.php
DEBUG - 2011-05-25 07:32:54 --> Helper loaded: url_helper
DEBUG - 2011-05-25 07:32:54 --> File loaded: application/views/common/header.php
DEBUG - 2011-05-25 07:32:54 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-05-25 07:32:54 --> File loaded: application/views/common/footer.php
DEBUG - 2011-05-25 07:32:54 --> File loaded: application/views/layout/main.php
DEBUG - 2011-05-25 07:32:54 --> Final output sent to browser
DEBUG - 2011-05-25 07:32:54 --> Total execution time: 0.5831
DEBUG - 2011-05-25 10:41:49 --> Config Class Initialized
DEBUG - 2011-05-25 10:41:49 --> Hooks Class Initialized
DEBUG - 2011-05-25 10:41:49 --> Utf8 Class Initialized
DEBUG - 2011-05-25 10:41:49 --> UTF-8 Support Enabled
DEBUG - 2011-05-25 10:41:49 --> URI Class Initialized
DEBUG - 2011-05-25 10:41:49 --> Router Class Initialized
DEBUG - 2011-05-25 10:41:49 --> Output Class Initialized
DEBUG - 2011-05-25 10:41:49 --> Input Class Initialized
DEBUG - 2011-05-25 10:41:49 --> Global POST and COOKIE data sanitized
DEBUG - 2011-05-25 10:41:49 --> Language Class Initialized
DEBUG - 2011-05-25 10:41:49 --> Loader Class Initialized
DEBUG - 2011-05-25 10:41:49 --> Controller Class Initialized
DEBUG - 2011-05-25 10:41:49 --> Model Class Initialized
DEBUG - 2011-05-25 10:41:49 --> Model Class Initialized
DEBUG - 2011-05-25 10:41:49 --> Model Class Initialized
DEBUG - 2011-05-25 10:41:49 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-05-25 10:41:49 --> Database Driver Class Initialized
DEBUG - 2011-05-25 10:41:49 --> File loaded: application/views/table/main.php
DEBUG - 2011-05-25 10:41:50 --> Helper loaded: url_helper
DEBUG - 2011-05-25 10:41:50 --> File loaded: application/views/common/header.php
DEBUG - 2011-05-25 10:41:50 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-05-25 10:41:50 --> File loaded: application/views/common/footer.php
DEBUG - 2011-05-25 10:41:50 --> File loaded: application/views/layout/main.php
DEBUG - 2011-05-25 10:41:50 --> Final output sent to browser
DEBUG - 2011-05-25 10:41:50 --> Total execution time: 0.5072
DEBUG - 2011-05-25 12:00:56 --> Config Class Initialized
DEBUG - 2011-05-25 12:00:56 --> Hooks Class Initialized
DEBUG - 2011-05-25 12:00:56 --> Utf8 Class Initialized
DEBUG - 2011-05-25 12:00:56 --> UTF-8 Support Enabled
DEBUG - 2011-05-25 12:00:56 --> URI Class Initialized
DEBUG - 2011-05-25 12:00:56 --> Router Class Initialized
ERROR - 2011-05-25 12:00:56 --> 404 Page Not Found --> robots.txt
DEBUG - 2011-05-25 12:00:56 --> Config Class Initialized
DEBUG - 2011-05-25 12:00:56 --> Hooks Class Initialized
DEBUG - 2011-05-25 12:00:56 --> Utf8 Class Initialized
DEBUG - 2011-05-25 12:00:56 --> UTF-8 Support Enabled
DEBUG - 2011-05-25 12:00:56 --> URI Class Initialized
DEBUG - 2011-05-25 12:00:56 --> Router Class Initialized
DEBUG - 2011-05-25 12:00:56 --> Output Class Initialized
DEBUG - 2011-05-25 12:00:56 --> Input Class Initialized
DEBUG - 2011-05-25 12:00:56 --> Global POST and COOKIE data sanitized
DEBUG - 2011-05-25 12:00:56 --> Language Class Initialized
DEBUG - 2011-05-25 12:00:57 --> Loader Class Initialized
DEBUG - 2011-05-25 12:00:57 --> Controller Class Initialized
DEBUG - 2011-05-25 12:00:57 --> Model Class Initialized
DEBUG - 2011-05-25 12:00:57 --> Model Class Initialized
DEBUG - 2011-05-25 12:00:57 --> Model Class Initialized
DEBUG - 2011-05-25 12:00:57 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-05-25 12:00:57 --> Database Driver Class Initialized
DEBUG - 2011-05-25 12:00:57 --> File loaded: application/views/table/main.php
DEBUG - 2011-05-25 12:00:57 --> Helper loaded: url_helper
DEBUG - 2011-05-25 12:00:57 --> File loaded: application/views/common/header.php
DEBUG - 2011-05-25 12:00:57 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-05-25 12:00:57 --> File loaded: application/views/common/footer.php
DEBUG - 2011-05-25 12:00:57 --> File loaded: application/views/layout/main.php
DEBUG - 2011-05-25 12:00:57 --> Final output sent to browser
DEBUG - 2011-05-25 12:00:57 --> Total execution time: 0.6326
DEBUG - 2011-05-25 12:01:28 --> Config Class Initialized
DEBUG - 2011-05-25 12:01:28 --> Hooks Class Initialized
DEBUG - 2011-05-25 12:01:28 --> Utf8 Class Initialized
DEBUG - 2011-05-25 12:01:28 --> UTF-8 Support Enabled
DEBUG - 2011-05-25 12:01:28 --> URI Class Initialized
DEBUG - 2011-05-25 12:01:28 --> Router Class Initialized
DEBUG - 2011-05-25 12:01:28 --> Output Class Initialized
DEBUG - 2011-05-25 12:01:28 --> Input Class Initialized
DEBUG - 2011-05-25 12:01:28 --> Global POST and COOKIE data sanitized
DEBUG - 2011-05-25 12:01:28 --> Language Class Initialized
DEBUG - 2011-05-25 12:01:28 --> Loader Class Initialized
DEBUG - 2011-05-25 12:01:28 --> Controller Class Initialized
ERROR - 2011-05-25 12:01:28 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-05-25 12:01:28 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-05-25 12:01:28 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-05-25 12:01:28 --> Model Class Initialized
DEBUG - 2011-05-25 12:01:28 --> Model Class Initialized
DEBUG - 2011-05-25 12:01:28 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-05-25 12:01:28 --> Database Driver Class Initialized
DEBUG - 2011-05-25 12:01:28 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-05-25 12:01:28 --> Helper loaded: url_helper
DEBUG - 2011-05-25 12:01:28 --> File loaded: application/views/common/header.php
DEBUG - 2011-05-25 12:01:28 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-05-25 12:01:28 --> File loaded: application/views/common/footer.php
DEBUG - 2011-05-25 12:01:28 --> File loaded: application/views/layout/main.php
DEBUG - 2011-05-25 12:01:28 --> Final output sent to browser
DEBUG - 2011-05-25 12:01:28 --> Total execution time: 0.1076
DEBUG - 2011-05-25 12:20:22 --> Config Class Initialized
DEBUG - 2011-05-25 12:20:22 --> Hooks Class Initialized
DEBUG - 2011-05-25 12:20:22 --> Utf8 Class Initialized
DEBUG - 2011-05-25 12:20:22 --> UTF-8 Support Enabled
DEBUG - 2011-05-25 12:20:22 --> URI Class Initialized
DEBUG - 2011-05-25 12:20:22 --> Router Class Initialized
DEBUG - 2011-05-25 12:20:22 --> Output Class Initialized
DEBUG - 2011-05-25 12:20:22 --> Input Class Initialized
DEBUG - 2011-05-25 12:20:22 --> Global POST and COOKIE data sanitized
DEBUG - 2011-05-25 12:20:22 --> Language Class Initialized
DEBUG - 2011-05-25 12:20:23 --> Loader Class Initialized
DEBUG - 2011-05-25 12:20:23 --> Controller Class Initialized
DEBUG - 2011-05-25 12:20:23 --> Model Class Initialized
DEBUG - 2011-05-25 12:20:23 --> Model Class Initialized
DEBUG - 2011-05-25 12:20:23 --> Model Class Initialized
DEBUG - 2011-05-25 12:20:23 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-05-25 12:20:24 --> Database Driver Class Initialized
DEBUG - 2011-05-25 12:20:24 --> File loaded: application/views/table/main.php
DEBUG - 2011-05-25 12:20:24 --> Helper loaded: url_helper
DEBUG - 2011-05-25 12:20:24 --> File loaded: application/views/common/header.php
DEBUG - 2011-05-25 12:20:24 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-05-25 12:20:24 --> File loaded: application/views/common/footer.php
DEBUG - 2011-05-25 12:20:24 --> File loaded: application/views/layout/main.php
DEBUG - 2011-05-25 12:20:24 --> Final output sent to browser
DEBUG - 2011-05-25 12:20:24 --> Total execution time: 2.2551
DEBUG - 2011-05-25 12:20:27 --> Config Class Initialized
DEBUG - 2011-05-25 12:20:27 --> Hooks Class Initialized
DEBUG - 2011-05-25 12:20:27 --> Utf8 Class Initialized
DEBUG - 2011-05-25 12:20:27 --> UTF-8 Support Enabled
DEBUG - 2011-05-25 12:20:27 --> URI Class Initialized
DEBUG - 2011-05-25 12:20:27 --> Router Class Initialized
ERROR - 2011-05-25 12:20:27 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-05-25 12:28:07 --> Config Class Initialized
DEBUG - 2011-05-25 12:28:07 --> Hooks Class Initialized
DEBUG - 2011-05-25 12:28:07 --> Utf8 Class Initialized
DEBUG - 2011-05-25 12:28:07 --> UTF-8 Support Enabled
DEBUG - 2011-05-25 12:28:07 --> URI Class Initialized
DEBUG - 2011-05-25 12:28:07 --> Router Class Initialized
DEBUG - 2011-05-25 12:28:07 --> Output Class Initialized
DEBUG - 2011-05-25 12:28:07 --> Input Class Initialized
DEBUG - 2011-05-25 12:28:07 --> Global POST and COOKIE data sanitized
DEBUG - 2011-05-25 12:28:07 --> Language Class Initialized
DEBUG - 2011-05-25 12:28:07 --> Loader Class Initialized
DEBUG - 2011-05-25 12:28:07 --> Controller Class Initialized
ERROR - 2011-05-25 12:28:07 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-05-25 12:28:07 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-05-25 12:28:07 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-05-25 12:28:07 --> Model Class Initialized
DEBUG - 2011-05-25 12:28:07 --> Model Class Initialized
DEBUG - 2011-05-25 12:28:07 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-05-25 12:28:07 --> Database Driver Class Initialized
DEBUG - 2011-05-25 12:28:07 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-05-25 12:28:07 --> Helper loaded: url_helper
DEBUG - 2011-05-25 12:28:07 --> File loaded: application/views/common/header.php
DEBUG - 2011-05-25 12:28:07 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-05-25 12:28:07 --> File loaded: application/views/common/footer.php
DEBUG - 2011-05-25 12:28:07 --> File loaded: application/views/layout/main.php
DEBUG - 2011-05-25 12:28:07 --> Final output sent to browser
DEBUG - 2011-05-25 12:28:07 --> Total execution time: 0.1876
DEBUG - 2011-05-25 12:28:08 --> Config Class Initialized
DEBUG - 2011-05-25 12:28:08 --> Hooks Class Initialized
DEBUG - 2011-05-25 12:28:08 --> Utf8 Class Initialized
DEBUG - 2011-05-25 12:28:08 --> UTF-8 Support Enabled
DEBUG - 2011-05-25 12:28:08 --> URI Class Initialized
DEBUG - 2011-05-25 12:28:08 --> Router Class Initialized
DEBUG - 2011-05-25 12:28:08 --> Output Class Initialized
DEBUG - 2011-05-25 12:28:08 --> Input Class Initialized
DEBUG - 2011-05-25 12:28:08 --> Global POST and COOKIE data sanitized
DEBUG - 2011-05-25 12:28:08 --> Language Class Initialized
DEBUG - 2011-05-25 12:28:08 --> Loader Class Initialized
DEBUG - 2011-05-25 12:28:08 --> Controller Class Initialized
DEBUG - 2011-05-25 12:28:08 --> Model Class Initialized
DEBUG - 2011-05-25 12:28:08 --> Model Class Initialized
DEBUG - 2011-05-25 12:28:08 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-05-25 12:28:08 --> Database Driver Class Initialized
DEBUG - 2011-05-25 12:28:08 --> Final output sent to browser
DEBUG - 2011-05-25 12:28:08 --> Total execution time: 0.7602
DEBUG - 2011-05-25 12:28:14 --> Config Class Initialized
DEBUG - 2011-05-25 12:28:14 --> Hooks Class Initialized
DEBUG - 2011-05-25 12:28:14 --> Utf8 Class Initialized
DEBUG - 2011-05-25 12:28:14 --> UTF-8 Support Enabled
DEBUG - 2011-05-25 12:28:14 --> URI Class Initialized
DEBUG - 2011-05-25 12:28:14 --> Router Class Initialized
ERROR - 2011-05-25 12:28:14 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-05-25 12:28:14 --> Config Class Initialized
DEBUG - 2011-05-25 12:28:14 --> Hooks Class Initialized
DEBUG - 2011-05-25 12:28:14 --> Utf8 Class Initialized
DEBUG - 2011-05-25 12:28:14 --> UTF-8 Support Enabled
DEBUG - 2011-05-25 12:28:14 --> URI Class Initialized
DEBUG - 2011-05-25 12:28:14 --> Router Class Initialized
ERROR - 2011-05-25 12:28:14 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-05-25 12:28:14 --> Config Class Initialized
DEBUG - 2011-05-25 12:28:14 --> Hooks Class Initialized
DEBUG - 2011-05-25 12:28:14 --> Utf8 Class Initialized
DEBUG - 2011-05-25 12:28:14 --> UTF-8 Support Enabled
DEBUG - 2011-05-25 12:28:14 --> URI Class Initialized
DEBUG - 2011-05-25 12:28:14 --> Router Class Initialized
ERROR - 2011-05-25 12:28:14 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-05-25 12:28:22 --> Config Class Initialized
DEBUG - 2011-05-25 12:28:22 --> Hooks Class Initialized
DEBUG - 2011-05-25 12:28:22 --> Utf8 Class Initialized
DEBUG - 2011-05-25 12:28:22 --> UTF-8 Support Enabled
DEBUG - 2011-05-25 12:28:22 --> URI Class Initialized
DEBUG - 2011-05-25 12:28:22 --> Router Class Initialized
ERROR - 2011-05-25 12:28:22 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-05-25 12:28:26 --> Config Class Initialized
DEBUG - 2011-05-25 12:28:26 --> Hooks Class Initialized
DEBUG - 2011-05-25 12:28:26 --> Utf8 Class Initialized
DEBUG - 2011-05-25 12:28:26 --> UTF-8 Support Enabled
DEBUG - 2011-05-25 12:28:26 --> URI Class Initialized
DEBUG - 2011-05-25 12:28:26 --> Router Class Initialized
ERROR - 2011-05-25 12:28:26 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-05-25 12:30:31 --> Config Class Initialized
DEBUG - 2011-05-25 12:30:31 --> Hooks Class Initialized
DEBUG - 2011-05-25 12:30:31 --> Utf8 Class Initialized
DEBUG - 2011-05-25 12:30:31 --> UTF-8 Support Enabled
DEBUG - 2011-05-25 12:30:31 --> URI Class Initialized
DEBUG - 2011-05-25 12:30:31 --> Router Class Initialized
ERROR - 2011-05-25 12:30:31 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-05-25 12:33:09 --> Config Class Initialized
DEBUG - 2011-05-25 12:33:09 --> Hooks Class Initialized
DEBUG - 2011-05-25 12:33:09 --> Utf8 Class Initialized
DEBUG - 2011-05-25 12:33:09 --> UTF-8 Support Enabled
DEBUG - 2011-05-25 12:33:09 --> URI Class Initialized
DEBUG - 2011-05-25 12:33:09 --> Router Class Initialized
DEBUG - 2011-05-25 12:33:09 --> Output Class Initialized
DEBUG - 2011-05-25 12:33:09 --> Input Class Initialized
DEBUG - 2011-05-25 12:33:09 --> Global POST and COOKIE data sanitized
DEBUG - 2011-05-25 12:33:09 --> Language Class Initialized
DEBUG - 2011-05-25 12:33:09 --> Loader Class Initialized
DEBUG - 2011-05-25 12:33:09 --> Controller Class Initialized
ERROR - 2011-05-25 12:33:09 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-05-25 12:33:09 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-05-25 12:33:09 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-05-25 12:33:09 --> Model Class Initialized
DEBUG - 2011-05-25 12:33:09 --> Model Class Initialized
DEBUG - 2011-05-25 12:33:09 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-05-25 12:33:09 --> Database Driver Class Initialized
DEBUG - 2011-05-25 12:33:09 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-05-25 12:33:09 --> Helper loaded: url_helper
DEBUG - 2011-05-25 12:33:09 --> File loaded: application/views/common/header.php
DEBUG - 2011-05-25 12:33:09 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-05-25 12:33:09 --> File loaded: application/views/common/footer.php
DEBUG - 2011-05-25 12:33:09 --> File loaded: application/views/layout/main.php
DEBUG - 2011-05-25 12:33:09 --> Final output sent to browser
DEBUG - 2011-05-25 12:33:09 --> Total execution time: 0.0381
DEBUG - 2011-05-25 12:33:10 --> Config Class Initialized
DEBUG - 2011-05-25 12:33:10 --> Hooks Class Initialized
DEBUG - 2011-05-25 12:33:10 --> Utf8 Class Initialized
DEBUG - 2011-05-25 12:33:10 --> UTF-8 Support Enabled
DEBUG - 2011-05-25 12:33:10 --> URI Class Initialized
DEBUG - 2011-05-25 12:33:10 --> Router Class Initialized
DEBUG - 2011-05-25 12:33:10 --> Output Class Initialized
DEBUG - 2011-05-25 12:33:10 --> Input Class Initialized
DEBUG - 2011-05-25 12:33:10 --> Global POST and COOKIE data sanitized
DEBUG - 2011-05-25 12:33:10 --> Language Class Initialized
DEBUG - 2011-05-25 12:33:10 --> Loader Class Initialized
DEBUG - 2011-05-25 12:33:10 --> Controller Class Initialized
DEBUG - 2011-05-25 12:33:10 --> Model Class Initialized
DEBUG - 2011-05-25 12:33:10 --> Model Class Initialized
DEBUG - 2011-05-25 12:33:10 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-05-25 12:33:10 --> Database Driver Class Initialized
DEBUG - 2011-05-25 12:33:11 --> Final output sent to browser
DEBUG - 2011-05-25 12:33:11 --> Total execution time: 1.2489
DEBUG - 2011-05-25 12:33:21 --> Config Class Initialized
DEBUG - 2011-05-25 12:33:21 --> Hooks Class Initialized
DEBUG - 2011-05-25 12:33:21 --> Utf8 Class Initialized
DEBUG - 2011-05-25 12:33:21 --> UTF-8 Support Enabled
DEBUG - 2011-05-25 12:33:21 --> URI Class Initialized
DEBUG - 2011-05-25 12:33:21 --> Router Class Initialized
ERROR - 2011-05-25 12:33:21 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-05-25 12:33:21 --> Config Class Initialized
DEBUG - 2011-05-25 12:33:21 --> Hooks Class Initialized
DEBUG - 2011-05-25 12:33:21 --> Utf8 Class Initialized
DEBUG - 2011-05-25 12:33:21 --> UTF-8 Support Enabled
DEBUG - 2011-05-25 12:33:21 --> URI Class Initialized
DEBUG - 2011-05-25 12:33:21 --> Router Class Initialized
ERROR - 2011-05-25 12:33:21 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-05-25 12:33:22 --> Config Class Initialized
DEBUG - 2011-05-25 12:33:22 --> Hooks Class Initialized
DEBUG - 2011-05-25 12:33:22 --> Utf8 Class Initialized
DEBUG - 2011-05-25 12:33:22 --> UTF-8 Support Enabled
DEBUG - 2011-05-25 12:33:22 --> URI Class Initialized
DEBUG - 2011-05-25 12:33:22 --> Router Class Initialized
ERROR - 2011-05-25 12:33:22 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-05-25 12:33:58 --> Config Class Initialized
DEBUG - 2011-05-25 12:33:58 --> Hooks Class Initialized
DEBUG - 2011-05-25 12:33:58 --> Utf8 Class Initialized
DEBUG - 2011-05-25 12:33:58 --> UTF-8 Support Enabled
DEBUG - 2011-05-25 12:33:58 --> URI Class Initialized
DEBUG - 2011-05-25 12:33:58 --> Router Class Initialized
DEBUG - 2011-05-25 12:33:58 --> Output Class Initialized
DEBUG - 2011-05-25 12:33:58 --> Input Class Initialized
DEBUG - 2011-05-25 12:33:58 --> Global POST and COOKIE data sanitized
DEBUG - 2011-05-25 12:33:58 --> Language Class Initialized
DEBUG - 2011-05-25 12:33:58 --> Loader Class Initialized
DEBUG - 2011-05-25 12:33:58 --> Controller Class Initialized
ERROR - 2011-05-25 12:33:58 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-05-25 12:33:58 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-05-25 12:33:58 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-05-25 12:33:58 --> Model Class Initialized
DEBUG - 2011-05-25 12:33:58 --> Model Class Initialized
DEBUG - 2011-05-25 12:33:58 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-05-25 12:33:58 --> Database Driver Class Initialized
DEBUG - 2011-05-25 12:33:58 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-05-25 12:33:58 --> Helper loaded: url_helper
DEBUG - 2011-05-25 12:33:58 --> File loaded: application/views/common/header.php
DEBUG - 2011-05-25 12:33:58 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-05-25 12:33:58 --> File loaded: application/views/common/footer.php
DEBUG - 2011-05-25 12:33:58 --> File loaded: application/views/layout/main.php
DEBUG - 2011-05-25 12:33:58 --> Final output sent to browser
DEBUG - 2011-05-25 12:33:58 --> Total execution time: 0.0318
DEBUG - 2011-05-25 12:33:58 --> Config Class Initialized
DEBUG - 2011-05-25 12:33:58 --> Hooks Class Initialized
DEBUG - 2011-05-25 12:33:58 --> Utf8 Class Initialized
DEBUG - 2011-05-25 12:33:58 --> UTF-8 Support Enabled
DEBUG - 2011-05-25 12:33:59 --> URI Class Initialized
DEBUG - 2011-05-25 12:33:59 --> Router Class Initialized
DEBUG - 2011-05-25 12:33:59 --> Output Class Initialized
DEBUG - 2011-05-25 12:33:59 --> Input Class Initialized
DEBUG - 2011-05-25 12:33:59 --> Global POST and COOKIE data sanitized
DEBUG - 2011-05-25 12:33:59 --> Language Class Initialized
DEBUG - 2011-05-25 12:33:59 --> Loader Class Initialized
DEBUG - 2011-05-25 12:33:59 --> Controller Class Initialized
DEBUG - 2011-05-25 12:33:59 --> Model Class Initialized
DEBUG - 2011-05-25 12:33:59 --> Model Class Initialized
DEBUG - 2011-05-25 12:33:59 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-05-25 12:33:59 --> Database Driver Class Initialized
DEBUG - 2011-05-25 12:33:59 --> Final output sent to browser
DEBUG - 2011-05-25 12:33:59 --> Total execution time: 0.5998
DEBUG - 2011-05-25 12:34:24 --> Config Class Initialized
DEBUG - 2011-05-25 12:34:24 --> Hooks Class Initialized
DEBUG - 2011-05-25 12:34:24 --> Utf8 Class Initialized
DEBUG - 2011-05-25 12:34:24 --> UTF-8 Support Enabled
DEBUG - 2011-05-25 12:34:24 --> URI Class Initialized
DEBUG - 2011-05-25 12:34:24 --> Router Class Initialized
DEBUG - 2011-05-25 12:34:24 --> Output Class Initialized
DEBUG - 2011-05-25 12:34:24 --> Input Class Initialized
DEBUG - 2011-05-25 12:34:24 --> Global POST and COOKIE data sanitized
DEBUG - 2011-05-25 12:34:24 --> Language Class Initialized
DEBUG - 2011-05-25 12:34:24 --> Loader Class Initialized
DEBUG - 2011-05-25 12:34:24 --> Controller Class Initialized
ERROR - 2011-05-25 12:34:24 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-05-25 12:34:24 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-05-25 12:34:24 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-05-25 12:34:24 --> Model Class Initialized
DEBUG - 2011-05-25 12:34:24 --> Model Class Initialized
DEBUG - 2011-05-25 12:34:24 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-05-25 12:34:24 --> Database Driver Class Initialized
DEBUG - 2011-05-25 12:34:24 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-05-25 12:34:24 --> Helper loaded: url_helper
DEBUG - 2011-05-25 12:34:24 --> File loaded: application/views/common/header.php
DEBUG - 2011-05-25 12:34:24 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-05-25 12:34:24 --> File loaded: application/views/common/footer.php
DEBUG - 2011-05-25 12:34:24 --> File loaded: application/views/layout/main.php
DEBUG - 2011-05-25 12:34:24 --> Final output sent to browser
DEBUG - 2011-05-25 12:34:24 --> Total execution time: 0.0601
DEBUG - 2011-05-25 12:34:24 --> Config Class Initialized
DEBUG - 2011-05-25 12:34:24 --> Hooks Class Initialized
DEBUG - 2011-05-25 12:34:24 --> Utf8 Class Initialized
DEBUG - 2011-05-25 12:34:24 --> UTF-8 Support Enabled
DEBUG - 2011-05-25 12:34:24 --> URI Class Initialized
DEBUG - 2011-05-25 12:34:24 --> Router Class Initialized
DEBUG - 2011-05-25 12:34:24 --> Output Class Initialized
DEBUG - 2011-05-25 12:34:24 --> Input Class Initialized
DEBUG - 2011-05-25 12:34:24 --> Global POST and COOKIE data sanitized
DEBUG - 2011-05-25 12:34:24 --> Language Class Initialized
DEBUG - 2011-05-25 12:34:24 --> Loader Class Initialized
DEBUG - 2011-05-25 12:34:24 --> Controller Class Initialized
DEBUG - 2011-05-25 12:34:24 --> Model Class Initialized
DEBUG - 2011-05-25 12:34:24 --> Model Class Initialized
DEBUG - 2011-05-25 12:34:24 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-05-25 12:34:24 --> Database Driver Class Initialized
DEBUG - 2011-05-25 12:34:26 --> Final output sent to browser
DEBUG - 2011-05-25 12:34:26 --> Total execution time: 1.5204
DEBUG - 2011-05-25 12:34:54 --> Config Class Initialized
DEBUG - 2011-05-25 12:34:54 --> Hooks Class Initialized
DEBUG - 2011-05-25 12:34:54 --> Utf8 Class Initialized
DEBUG - 2011-05-25 12:34:54 --> UTF-8 Support Enabled
DEBUG - 2011-05-25 12:34:54 --> URI Class Initialized
DEBUG - 2011-05-25 12:34:54 --> Router Class Initialized
DEBUG - 2011-05-25 12:34:54 --> Output Class Initialized
DEBUG - 2011-05-25 12:34:54 --> Input Class Initialized
DEBUG - 2011-05-25 12:34:54 --> Global POST and COOKIE data sanitized
DEBUG - 2011-05-25 12:34:54 --> Language Class Initialized
DEBUG - 2011-05-25 12:34:54 --> Loader Class Initialized
DEBUG - 2011-05-25 12:34:54 --> Controller Class Initialized
ERROR - 2011-05-25 12:34:54 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-05-25 12:34:54 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-05-25 12:34:54 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-05-25 12:34:54 --> Model Class Initialized
DEBUG - 2011-05-25 12:34:54 --> Model Class Initialized
DEBUG - 2011-05-25 12:34:54 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-05-25 12:34:54 --> Database Driver Class Initialized
DEBUG - 2011-05-25 12:34:54 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-05-25 12:34:54 --> Helper loaded: url_helper
DEBUG - 2011-05-25 12:34:54 --> File loaded: application/views/common/header.php
DEBUG - 2011-05-25 12:34:54 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-05-25 12:34:54 --> File loaded: application/views/common/footer.php
DEBUG - 2011-05-25 12:34:54 --> File loaded: application/views/layout/main.php
DEBUG - 2011-05-25 12:34:54 --> Final output sent to browser
DEBUG - 2011-05-25 12:34:54 --> Total execution time: 0.1333
DEBUG - 2011-05-25 12:34:55 --> Config Class Initialized
DEBUG - 2011-05-25 12:34:55 --> Hooks Class Initialized
DEBUG - 2011-05-25 12:34:55 --> Utf8 Class Initialized
DEBUG - 2011-05-25 12:34:55 --> UTF-8 Support Enabled
DEBUG - 2011-05-25 12:34:55 --> URI Class Initialized
DEBUG - 2011-05-25 12:34:55 --> Router Class Initialized
DEBUG - 2011-05-25 12:34:55 --> Output Class Initialized
DEBUG - 2011-05-25 12:34:55 --> Input Class Initialized
DEBUG - 2011-05-25 12:34:55 --> Global POST and COOKIE data sanitized
DEBUG - 2011-05-25 12:34:55 --> Language Class Initialized
DEBUG - 2011-05-25 12:34:55 --> Loader Class Initialized
DEBUG - 2011-05-25 12:34:55 --> Controller Class Initialized
DEBUG - 2011-05-25 12:34:55 --> Model Class Initialized
DEBUG - 2011-05-25 12:34:55 --> Model Class Initialized
DEBUG - 2011-05-25 12:34:55 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-05-25 12:34:55 --> Database Driver Class Initialized
DEBUG - 2011-05-25 12:34:56 --> Final output sent to browser
DEBUG - 2011-05-25 12:34:56 --> Total execution time: 0.6596
DEBUG - 2011-05-25 12:35:47 --> Config Class Initialized
DEBUG - 2011-05-25 12:35:47 --> Hooks Class Initialized
DEBUG - 2011-05-25 12:35:47 --> Utf8 Class Initialized
DEBUG - 2011-05-25 12:35:47 --> UTF-8 Support Enabled
DEBUG - 2011-05-25 12:35:47 --> URI Class Initialized
DEBUG - 2011-05-25 12:35:47 --> Router Class Initialized
DEBUG - 2011-05-25 12:35:47 --> Output Class Initialized
DEBUG - 2011-05-25 12:35:47 --> Input Class Initialized
DEBUG - 2011-05-25 12:35:47 --> Global POST and COOKIE data sanitized
DEBUG - 2011-05-25 12:35:47 --> Language Class Initialized
DEBUG - 2011-05-25 12:35:47 --> Loader Class Initialized
DEBUG - 2011-05-25 12:35:47 --> Controller Class Initialized
ERROR - 2011-05-25 12:35:47 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-05-25 12:35:47 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-05-25 12:35:47 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-05-25 12:35:47 --> Model Class Initialized
DEBUG - 2011-05-25 12:35:47 --> Model Class Initialized
DEBUG - 2011-05-25 12:35:47 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-05-25 12:35:47 --> Database Driver Class Initialized
DEBUG - 2011-05-25 12:35:47 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-05-25 12:35:47 --> Helper loaded: url_helper
DEBUG - 2011-05-25 12:35:47 --> File loaded: application/views/common/header.php
DEBUG - 2011-05-25 12:35:47 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-05-25 12:35:47 --> File loaded: application/views/common/footer.php
DEBUG - 2011-05-25 12:35:47 --> File loaded: application/views/layout/main.php
DEBUG - 2011-05-25 12:35:47 --> Final output sent to browser
DEBUG - 2011-05-25 12:35:47 --> Total execution time: 0.0276
DEBUG - 2011-05-25 12:35:48 --> Config Class Initialized
DEBUG - 2011-05-25 12:35:48 --> Hooks Class Initialized
DEBUG - 2011-05-25 12:35:48 --> Utf8 Class Initialized
DEBUG - 2011-05-25 12:35:48 --> UTF-8 Support Enabled
DEBUG - 2011-05-25 12:35:48 --> URI Class Initialized
DEBUG - 2011-05-25 12:35:48 --> Router Class Initialized
DEBUG - 2011-05-25 12:35:48 --> Output Class Initialized
DEBUG - 2011-05-25 12:35:48 --> Input Class Initialized
DEBUG - 2011-05-25 12:35:48 --> Global POST and COOKIE data sanitized
DEBUG - 2011-05-25 12:35:48 --> Language Class Initialized
DEBUG - 2011-05-25 12:35:48 --> Loader Class Initialized
DEBUG - 2011-05-25 12:35:48 --> Controller Class Initialized
DEBUG - 2011-05-25 12:35:48 --> Model Class Initialized
DEBUG - 2011-05-25 12:35:48 --> Model Class Initialized
DEBUG - 2011-05-25 12:35:48 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-05-25 12:35:48 --> Database Driver Class Initialized
DEBUG - 2011-05-25 12:35:48 --> Final output sent to browser
DEBUG - 2011-05-25 12:35:48 --> Total execution time: 0.5988
DEBUG - 2011-05-25 13:36:11 --> Config Class Initialized
DEBUG - 2011-05-25 13:36:11 --> Hooks Class Initialized
DEBUG - 2011-05-25 13:36:11 --> Utf8 Class Initialized
DEBUG - 2011-05-25 13:36:11 --> UTF-8 Support Enabled
DEBUG - 2011-05-25 13:36:11 --> URI Class Initialized
DEBUG - 2011-05-25 13:36:11 --> Router Class Initialized
ERROR - 2011-05-25 13:36:11 --> 404 Page Not Found --> robots.txt
DEBUG - 2011-05-25 13:36:48 --> Config Class Initialized
DEBUG - 2011-05-25 13:36:48 --> Hooks Class Initialized
DEBUG - 2011-05-25 13:36:48 --> Utf8 Class Initialized
DEBUG - 2011-05-25 13:36:48 --> UTF-8 Support Enabled
DEBUG - 2011-05-25 13:36:48 --> URI Class Initialized
DEBUG - 2011-05-25 13:36:48 --> Router Class Initialized
DEBUG - 2011-05-25 13:36:48 --> No URI present. Default controller set.
DEBUG - 2011-05-25 13:36:49 --> Output Class Initialized
DEBUG - 2011-05-25 13:36:49 --> Input Class Initialized
DEBUG - 2011-05-25 13:36:49 --> Global POST and COOKIE data sanitized
DEBUG - 2011-05-25 13:36:49 --> Language Class Initialized
DEBUG - 2011-05-25 13:36:49 --> Loader Class Initialized
DEBUG - 2011-05-25 13:36:49 --> Controller Class Initialized
DEBUG - 2011-05-25 13:36:49 --> File loaded: application/views/splash/main.php
DEBUG - 2011-05-25 13:36:49 --> Helper loaded: url_helper
DEBUG - 2011-05-25 13:36:49 --> File loaded: application/views/common/header.php
DEBUG - 2011-05-25 13:36:49 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-05-25 13:36:49 --> File loaded: application/views/common/footer.php
DEBUG - 2011-05-25 13:36:49 --> File loaded: application/views/layout/main.php
DEBUG - 2011-05-25 13:36:49 --> Final output sent to browser
DEBUG - 2011-05-25 13:36:49 --> Total execution time: 0.2776
DEBUG - 2011-05-25 13:40:41 --> Config Class Initialized
DEBUG - 2011-05-25 13:40:41 --> Hooks Class Initialized
DEBUG - 2011-05-25 13:40:41 --> Utf8 Class Initialized
DEBUG - 2011-05-25 13:40:41 --> UTF-8 Support Enabled
DEBUG - 2011-05-25 13:40:41 --> URI Class Initialized
DEBUG - 2011-05-25 13:40:41 --> Router Class Initialized
DEBUG - 2011-05-25 13:40:41 --> Output Class Initialized
DEBUG - 2011-05-25 13:40:41 --> Input Class Initialized
DEBUG - 2011-05-25 13:40:41 --> Global POST and COOKIE data sanitized
DEBUG - 2011-05-25 13:40:41 --> Language Class Initialized
DEBUG - 2011-05-25 13:40:41 --> Loader Class Initialized
DEBUG - 2011-05-25 13:40:41 --> Controller Class Initialized
DEBUG - 2011-05-25 13:40:41 --> Model Class Initialized
DEBUG - 2011-05-25 13:40:41 --> Model Class Initialized
DEBUG - 2011-05-25 13:40:41 --> Model Class Initialized
DEBUG - 2011-05-25 13:40:41 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-05-25 13:40:41 --> Database Driver Class Initialized
DEBUG - 2011-05-25 13:40:41 --> File loaded: application/views/table/main.php
DEBUG - 2011-05-25 13:40:41 --> Helper loaded: url_helper
DEBUG - 2011-05-25 13:40:41 --> File loaded: application/views/common/header.php
DEBUG - 2011-05-25 13:40:41 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-05-25 13:40:41 --> File loaded: application/views/common/footer.php
DEBUG - 2011-05-25 13:40:41 --> File loaded: application/views/layout/main.php
DEBUG - 2011-05-25 13:40:41 --> Final output sent to browser
DEBUG - 2011-05-25 13:40:41 --> Total execution time: 0.3997
DEBUG - 2011-05-25 13:40:41 --> Config Class Initialized
DEBUG - 2011-05-25 13:40:41 --> Hooks Class Initialized
DEBUG - 2011-05-25 13:40:41 --> Utf8 Class Initialized
DEBUG - 2011-05-25 13:40:41 --> UTF-8 Support Enabled
DEBUG - 2011-05-25 13:40:41 --> URI Class Initialized
DEBUG - 2011-05-25 13:40:41 --> Router Class Initialized
DEBUG - 2011-05-25 13:40:41 --> Output Class Initialized
DEBUG - 2011-05-25 13:40:41 --> Input Class Initialized
DEBUG - 2011-05-25 13:40:41 --> Global POST and COOKIE data sanitized
DEBUG - 2011-05-25 13:40:41 --> Language Class Initialized
DEBUG - 2011-05-25 13:40:41 --> Loader Class Initialized
DEBUG - 2011-05-25 13:40:41 --> Controller Class Initialized
ERROR - 2011-05-25 13:40:41 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-05-25 13:40:41 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-05-25 13:40:41 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-05-25 13:40:41 --> Model Class Initialized
DEBUG - 2011-05-25 13:40:41 --> Model Class Initialized
DEBUG - 2011-05-25 13:40:41 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-05-25 13:40:41 --> Database Driver Class Initialized
DEBUG - 2011-05-25 13:40:41 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-05-25 13:40:41 --> Helper loaded: url_helper
DEBUG - 2011-05-25 13:40:41 --> File loaded: application/views/common/header.php
DEBUG - 2011-05-25 13:40:41 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-05-25 13:40:41 --> File loaded: application/views/common/footer.php
DEBUG - 2011-05-25 13:40:41 --> File loaded: application/views/layout/main.php
DEBUG - 2011-05-25 13:40:41 --> Final output sent to browser
DEBUG - 2011-05-25 13:40:41 --> Total execution time: 0.0899
DEBUG - 2011-05-25 13:46:10 --> Config Class Initialized
DEBUG - 2011-05-25 13:46:10 --> Hooks Class Initialized
DEBUG - 2011-05-25 13:46:10 --> Utf8 Class Initialized
DEBUG - 2011-05-25 13:46:10 --> UTF-8 Support Enabled
DEBUG - 2011-05-25 13:46:10 --> URI Class Initialized
DEBUG - 2011-05-25 13:46:10 --> Router Class Initialized
DEBUG - 2011-05-25 13:46:10 --> Output Class Initialized
DEBUG - 2011-05-25 13:46:10 --> Input Class Initialized
DEBUG - 2011-05-25 13:46:10 --> Global POST and COOKIE data sanitized
DEBUG - 2011-05-25 13:46:10 --> Language Class Initialized
DEBUG - 2011-05-25 13:46:10 --> Loader Class Initialized
DEBUG - 2011-05-25 13:46:10 --> Controller Class Initialized
ERROR - 2011-05-25 13:46:10 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-05-25 13:46:10 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-05-25 13:46:10 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-05-25 13:46:10 --> Model Class Initialized
DEBUG - 2011-05-25 13:46:10 --> Model Class Initialized
DEBUG - 2011-05-25 13:46:10 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-05-25 13:46:10 --> Database Driver Class Initialized
DEBUG - 2011-05-25 13:46:10 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-05-25 13:46:10 --> Helper loaded: url_helper
DEBUG - 2011-05-25 13:46:10 --> File loaded: application/views/common/header.php
DEBUG - 2011-05-25 13:46:10 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-05-25 13:46:10 --> File loaded: application/views/common/footer.php
DEBUG - 2011-05-25 13:46:10 --> File loaded: application/views/layout/main.php
DEBUG - 2011-05-25 13:46:10 --> Final output sent to browser
DEBUG - 2011-05-25 13:46:10 --> Total execution time: 0.0381
DEBUG - 2011-05-25 13:46:12 --> Config Class Initialized
DEBUG - 2011-05-25 13:46:12 --> Hooks Class Initialized
DEBUG - 2011-05-25 13:46:12 --> Utf8 Class Initialized
DEBUG - 2011-05-25 13:46:12 --> UTF-8 Support Enabled
DEBUG - 2011-05-25 13:46:12 --> URI Class Initialized
DEBUG - 2011-05-25 13:46:12 --> Router Class Initialized
DEBUG - 2011-05-25 13:46:12 --> Output Class Initialized
DEBUG - 2011-05-25 13:46:12 --> Input Class Initialized
DEBUG - 2011-05-25 13:46:12 --> Global POST and COOKIE data sanitized
DEBUG - 2011-05-25 13:46:12 --> Language Class Initialized
DEBUG - 2011-05-25 13:46:12 --> Loader Class Initialized
DEBUG - 2011-05-25 13:46:12 --> Controller Class Initialized
DEBUG - 2011-05-25 13:46:12 --> Model Class Initialized
DEBUG - 2011-05-25 13:46:12 --> Model Class Initialized
DEBUG - 2011-05-25 13:46:12 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-05-25 13:46:12 --> Database Driver Class Initialized
DEBUG - 2011-05-25 13:46:12 --> Final output sent to browser
DEBUG - 2011-05-25 13:46:12 --> Total execution time: 0.9057
DEBUG - 2011-05-25 13:46:14 --> Config Class Initialized
DEBUG - 2011-05-25 13:46:14 --> Hooks Class Initialized
DEBUG - 2011-05-25 13:46:14 --> Utf8 Class Initialized
DEBUG - 2011-05-25 13:46:14 --> UTF-8 Support Enabled
DEBUG - 2011-05-25 13:46:14 --> URI Class Initialized
DEBUG - 2011-05-25 13:46:14 --> Router Class Initialized
ERROR - 2011-05-25 13:46:14 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-05-25 13:46:46 --> Config Class Initialized
DEBUG - 2011-05-25 13:46:46 --> Hooks Class Initialized
DEBUG - 2011-05-25 13:46:46 --> Utf8 Class Initialized
DEBUG - 2011-05-25 13:46:46 --> UTF-8 Support Enabled
DEBUG - 2011-05-25 13:46:46 --> URI Class Initialized
DEBUG - 2011-05-25 13:46:46 --> Router Class Initialized
DEBUG - 2011-05-25 13:46:46 --> Output Class Initialized
DEBUG - 2011-05-25 13:46:46 --> Input Class Initialized
DEBUG - 2011-05-25 13:46:46 --> Global POST and COOKIE data sanitized
DEBUG - 2011-05-25 13:46:46 --> Language Class Initialized
DEBUG - 2011-05-25 13:46:46 --> Loader Class Initialized
DEBUG - 2011-05-25 13:46:46 --> Controller Class Initialized
ERROR - 2011-05-25 13:46:46 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-05-25 13:46:46 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-05-25 13:46:46 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-05-25 13:46:46 --> Model Class Initialized
DEBUG - 2011-05-25 13:46:46 --> Model Class Initialized
DEBUG - 2011-05-25 13:46:46 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-05-25 13:46:46 --> Database Driver Class Initialized
DEBUG - 2011-05-25 13:46:46 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-05-25 13:46:46 --> Helper loaded: url_helper
DEBUG - 2011-05-25 13:46:46 --> File loaded: application/views/common/header.php
DEBUG - 2011-05-25 13:46:46 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-05-25 13:46:46 --> File loaded: application/views/common/footer.php
DEBUG - 2011-05-25 13:46:46 --> File loaded: application/views/layout/main.php
DEBUG - 2011-05-25 13:46:46 --> Final output sent to browser
DEBUG - 2011-05-25 13:46:46 --> Total execution time: 0.0325
DEBUG - 2011-05-25 13:46:47 --> Config Class Initialized
DEBUG - 2011-05-25 13:46:47 --> Hooks Class Initialized
DEBUG - 2011-05-25 13:46:47 --> Utf8 Class Initialized
DEBUG - 2011-05-25 13:46:47 --> UTF-8 Support Enabled
DEBUG - 2011-05-25 13:46:47 --> URI Class Initialized
DEBUG - 2011-05-25 13:46:47 --> Router Class Initialized
DEBUG - 2011-05-25 13:46:47 --> Output Class Initialized
DEBUG - 2011-05-25 13:46:47 --> Input Class Initialized
DEBUG - 2011-05-25 13:46:47 --> Global POST and COOKIE data sanitized
DEBUG - 2011-05-25 13:46:47 --> Language Class Initialized
DEBUG - 2011-05-25 13:46:47 --> Loader Class Initialized
DEBUG - 2011-05-25 13:46:47 --> Controller Class Initialized
DEBUG - 2011-05-25 13:46:47 --> Model Class Initialized
DEBUG - 2011-05-25 13:46:47 --> Model Class Initialized
DEBUG - 2011-05-25 13:46:47 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-05-25 13:46:47 --> Database Driver Class Initialized
DEBUG - 2011-05-25 13:46:48 --> Final output sent to browser
DEBUG - 2011-05-25 13:46:48 --> Total execution time: 0.5023
DEBUG - 2011-05-25 13:46:48 --> Config Class Initialized
DEBUG - 2011-05-25 13:46:48 --> Hooks Class Initialized
DEBUG - 2011-05-25 13:46:48 --> Utf8 Class Initialized
DEBUG - 2011-05-25 13:46:48 --> UTF-8 Support Enabled
DEBUG - 2011-05-25 13:46:48 --> URI Class Initialized
DEBUG - 2011-05-25 13:46:48 --> Router Class Initialized
DEBUG - 2011-05-25 13:46:48 --> Output Class Initialized
DEBUG - 2011-05-25 13:46:48 --> Input Class Initialized
DEBUG - 2011-05-25 13:46:48 --> Global POST and COOKIE data sanitized
DEBUG - 2011-05-25 13:46:48 --> Language Class Initialized
DEBUG - 2011-05-25 13:46:48 --> Loader Class Initialized
DEBUG - 2011-05-25 13:46:48 --> Controller Class Initialized
ERROR - 2011-05-25 13:46:48 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-05-25 13:46:48 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-05-25 13:46:48 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-05-25 13:46:48 --> Model Class Initialized
DEBUG - 2011-05-25 13:46:48 --> Model Class Initialized
DEBUG - 2011-05-25 13:46:48 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-05-25 13:46:48 --> Database Driver Class Initialized
DEBUG - 2011-05-25 13:46:48 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-05-25 13:46:48 --> Helper loaded: url_helper
DEBUG - 2011-05-25 13:46:48 --> File loaded: application/views/common/header.php
DEBUG - 2011-05-25 13:46:48 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-05-25 13:46:48 --> File loaded: application/views/common/footer.php
DEBUG - 2011-05-25 13:46:48 --> File loaded: application/views/layout/main.php
DEBUG - 2011-05-25 13:46:48 --> Final output sent to browser
DEBUG - 2011-05-25 13:46:48 --> Total execution time: 0.0555
DEBUG - 2011-05-25 13:46:49 --> Config Class Initialized
DEBUG - 2011-05-25 13:46:49 --> Hooks Class Initialized
DEBUG - 2011-05-25 13:46:49 --> Utf8 Class Initialized
DEBUG - 2011-05-25 13:46:49 --> UTF-8 Support Enabled
DEBUG - 2011-05-25 13:46:49 --> URI Class Initialized
DEBUG - 2011-05-25 13:46:49 --> Router Class Initialized
ERROR - 2011-05-25 13:46:49 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-05-25 13:46:55 --> Config Class Initialized
DEBUG - 2011-05-25 13:46:55 --> Hooks Class Initialized
DEBUG - 2011-05-25 13:46:55 --> Utf8 Class Initialized
DEBUG - 2011-05-25 13:46:55 --> UTF-8 Support Enabled
DEBUG - 2011-05-25 13:46:55 --> URI Class Initialized
DEBUG - 2011-05-25 13:46:55 --> Router Class Initialized
DEBUG - 2011-05-25 13:46:55 --> Output Class Initialized
DEBUG - 2011-05-25 13:46:55 --> Input Class Initialized
DEBUG - 2011-05-25 13:46:55 --> Global POST and COOKIE data sanitized
DEBUG - 2011-05-25 13:46:55 --> Language Class Initialized
DEBUG - 2011-05-25 13:46:55 --> Loader Class Initialized
DEBUG - 2011-05-25 13:46:55 --> Controller Class Initialized
ERROR - 2011-05-25 13:46:55 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-05-25 13:46:55 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-05-25 13:46:55 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-05-25 13:46:55 --> Model Class Initialized
DEBUG - 2011-05-25 13:46:55 --> Model Class Initialized
DEBUG - 2011-05-25 13:46:55 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-05-25 13:46:55 --> Database Driver Class Initialized
DEBUG - 2011-05-25 13:46:55 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-05-25 13:46:55 --> Helper loaded: url_helper
DEBUG - 2011-05-25 13:46:55 --> File loaded: application/views/common/header.php
DEBUG - 2011-05-25 13:46:55 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-05-25 13:46:55 --> File loaded: application/views/common/footer.php
DEBUG - 2011-05-25 13:46:55 --> File loaded: application/views/layout/main.php
DEBUG - 2011-05-25 13:46:55 --> Final output sent to browser
DEBUG - 2011-05-25 13:46:55 --> Total execution time: 0.0293
DEBUG - 2011-05-25 13:46:56 --> Config Class Initialized
DEBUG - 2011-05-25 13:46:56 --> Hooks Class Initialized
DEBUG - 2011-05-25 13:46:56 --> Utf8 Class Initialized
DEBUG - 2011-05-25 13:46:56 --> UTF-8 Support Enabled
DEBUG - 2011-05-25 13:46:56 --> URI Class Initialized
DEBUG - 2011-05-25 13:46:56 --> Router Class Initialized
DEBUG - 2011-05-25 13:46:56 --> Output Class Initialized
DEBUG - 2011-05-25 13:46:56 --> Input Class Initialized
DEBUG - 2011-05-25 13:46:56 --> Global POST and COOKIE data sanitized
DEBUG - 2011-05-25 13:46:56 --> Language Class Initialized
DEBUG - 2011-05-25 13:46:56 --> Loader Class Initialized
DEBUG - 2011-05-25 13:46:56 --> Controller Class Initialized
DEBUG - 2011-05-25 13:46:56 --> Model Class Initialized
DEBUG - 2011-05-25 13:46:56 --> Model Class Initialized
DEBUG - 2011-05-25 13:46:56 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-05-25 13:46:56 --> Database Driver Class Initialized
DEBUG - 2011-05-25 13:46:56 --> Config Class Initialized
DEBUG - 2011-05-25 13:46:56 --> Hooks Class Initialized
DEBUG - 2011-05-25 13:46:56 --> Utf8 Class Initialized
DEBUG - 2011-05-25 13:46:56 --> UTF-8 Support Enabled
DEBUG - 2011-05-25 13:46:56 --> URI Class Initialized
DEBUG - 2011-05-25 13:46:56 --> Router Class Initialized
DEBUG - 2011-05-25 13:46:56 --> Output Class Initialized
DEBUG - 2011-05-25 13:46:56 --> Input Class Initialized
DEBUG - 2011-05-25 13:46:56 --> Global POST and COOKIE data sanitized
DEBUG - 2011-05-25 13:46:56 --> Language Class Initialized
DEBUG - 2011-05-25 13:46:56 --> Loader Class Initialized
DEBUG - 2011-05-25 13:46:56 --> Controller Class Initialized
ERROR - 2011-05-25 13:46:56 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-05-25 13:46:56 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-05-25 13:46:56 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-05-25 13:46:56 --> Model Class Initialized
DEBUG - 2011-05-25 13:46:56 --> Model Class Initialized
DEBUG - 2011-05-25 13:46:56 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-05-25 13:46:56 --> Database Driver Class Initialized
DEBUG - 2011-05-25 13:46:56 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-05-25 13:46:56 --> Helper loaded: url_helper
DEBUG - 2011-05-25 13:46:56 --> File loaded: application/views/common/header.php
DEBUG - 2011-05-25 13:46:56 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-05-25 13:46:56 --> File loaded: application/views/common/footer.php
DEBUG - 2011-05-25 13:46:56 --> File loaded: application/views/layout/main.php
DEBUG - 2011-05-25 13:46:56 --> Final output sent to browser
DEBUG - 2011-05-25 13:46:56 --> Total execution time: 0.0380
DEBUG - 2011-05-25 13:46:56 --> Final output sent to browser
DEBUG - 2011-05-25 13:46:56 --> Total execution time: 0.6406
DEBUG - 2011-05-25 13:46:58 --> Config Class Initialized
DEBUG - 2011-05-25 13:46:58 --> Hooks Class Initialized
DEBUG - 2011-05-25 13:46:58 --> Utf8 Class Initialized
DEBUG - 2011-05-25 13:46:58 --> UTF-8 Support Enabled
DEBUG - 2011-05-25 13:46:58 --> URI Class Initialized
DEBUG - 2011-05-25 13:46:58 --> Router Class Initialized
ERROR - 2011-05-25 13:46:58 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-05-25 13:47:04 --> Config Class Initialized
DEBUG - 2011-05-25 13:47:04 --> Hooks Class Initialized
DEBUG - 2011-05-25 13:47:04 --> Utf8 Class Initialized
DEBUG - 2011-05-25 13:47:04 --> UTF-8 Support Enabled
DEBUG - 2011-05-25 13:47:04 --> URI Class Initialized
DEBUG - 2011-05-25 13:47:04 --> Router Class Initialized
DEBUG - 2011-05-25 13:47:04 --> Output Class Initialized
DEBUG - 2011-05-25 13:47:04 --> Input Class Initialized
DEBUG - 2011-05-25 13:47:04 --> Global POST and COOKIE data sanitized
DEBUG - 2011-05-25 13:47:04 --> Language Class Initialized
DEBUG - 2011-05-25 13:47:04 --> Loader Class Initialized
DEBUG - 2011-05-25 13:47:04 --> Controller Class Initialized
ERROR - 2011-05-25 13:47:04 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-05-25 13:47:04 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-05-25 13:47:04 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-05-25 13:47:04 --> Model Class Initialized
DEBUG - 2011-05-25 13:47:04 --> Model Class Initialized
DEBUG - 2011-05-25 13:47:04 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-05-25 13:47:04 --> Database Driver Class Initialized
DEBUG - 2011-05-25 13:47:04 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-05-25 13:47:04 --> Helper loaded: url_helper
DEBUG - 2011-05-25 13:47:04 --> File loaded: application/views/common/header.php
DEBUG - 2011-05-25 13:47:04 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-05-25 13:47:04 --> File loaded: application/views/common/footer.php
DEBUG - 2011-05-25 13:47:04 --> File loaded: application/views/layout/main.php
DEBUG - 2011-05-25 13:47:04 --> Final output sent to browser
DEBUG - 2011-05-25 13:47:04 --> Total execution time: 0.0293
DEBUG - 2011-05-25 13:47:04 --> Config Class Initialized
DEBUG - 2011-05-25 13:47:04 --> Hooks Class Initialized
DEBUG - 2011-05-25 13:47:04 --> Utf8 Class Initialized
DEBUG - 2011-05-25 13:47:04 --> UTF-8 Support Enabled
DEBUG - 2011-05-25 13:47:04 --> URI Class Initialized
DEBUG - 2011-05-25 13:47:04 --> Router Class Initialized
DEBUG - 2011-05-25 13:47:04 --> Output Class Initialized
DEBUG - 2011-05-25 13:47:04 --> Input Class Initialized
DEBUG - 2011-05-25 13:47:04 --> Global POST and COOKIE data sanitized
DEBUG - 2011-05-25 13:47:04 --> Language Class Initialized
DEBUG - 2011-05-25 13:47:04 --> Loader Class Initialized
DEBUG - 2011-05-25 13:47:04 --> Controller Class Initialized
DEBUG - 2011-05-25 13:47:04 --> Model Class Initialized
DEBUG - 2011-05-25 13:47:04 --> Model Class Initialized
DEBUG - 2011-05-25 13:47:04 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-05-25 13:47:04 --> Database Driver Class Initialized
DEBUG - 2011-05-25 13:47:05 --> Final output sent to browser
DEBUG - 2011-05-25 13:47:05 --> Total execution time: 0.5923
DEBUG - 2011-05-25 13:47:06 --> Config Class Initialized
DEBUG - 2011-05-25 13:47:06 --> Hooks Class Initialized
DEBUG - 2011-05-25 13:47:06 --> Utf8 Class Initialized
DEBUG - 2011-05-25 13:47:06 --> UTF-8 Support Enabled
DEBUG - 2011-05-25 13:47:06 --> URI Class Initialized
DEBUG - 2011-05-25 13:47:06 --> Router Class Initialized
ERROR - 2011-05-25 13:47:06 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-05-25 13:47:11 --> Config Class Initialized
DEBUG - 2011-05-25 13:47:11 --> Hooks Class Initialized
DEBUG - 2011-05-25 13:47:11 --> Utf8 Class Initialized
DEBUG - 2011-05-25 13:47:11 --> UTF-8 Support Enabled
DEBUG - 2011-05-25 13:47:11 --> URI Class Initialized
DEBUG - 2011-05-25 13:47:11 --> Router Class Initialized
DEBUG - 2011-05-25 13:47:11 --> Output Class Initialized
DEBUG - 2011-05-25 13:47:11 --> Input Class Initialized
DEBUG - 2011-05-25 13:47:11 --> Global POST and COOKIE data sanitized
DEBUG - 2011-05-25 13:47:11 --> Language Class Initialized
DEBUG - 2011-05-25 13:47:11 --> Loader Class Initialized
DEBUG - 2011-05-25 13:47:11 --> Controller Class Initialized
ERROR - 2011-05-25 13:47:11 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-05-25 13:47:11 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-05-25 13:47:11 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-05-25 13:47:11 --> Model Class Initialized
DEBUG - 2011-05-25 13:47:11 --> Model Class Initialized
DEBUG - 2011-05-25 13:47:11 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-05-25 13:47:11 --> Database Driver Class Initialized
DEBUG - 2011-05-25 13:47:11 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-05-25 13:47:11 --> Helper loaded: url_helper
DEBUG - 2011-05-25 13:47:11 --> File loaded: application/views/common/header.php
DEBUG - 2011-05-25 13:47:11 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-05-25 13:47:11 --> File loaded: application/views/common/footer.php
DEBUG - 2011-05-25 13:47:11 --> File loaded: application/views/layout/main.php
DEBUG - 2011-05-25 13:47:11 --> Final output sent to browser
DEBUG - 2011-05-25 13:47:11 --> Total execution time: 0.0295
DEBUG - 2011-05-25 13:47:12 --> Config Class Initialized
DEBUG - 2011-05-25 13:47:12 --> Hooks Class Initialized
DEBUG - 2011-05-25 13:47:12 --> Utf8 Class Initialized
DEBUG - 2011-05-25 13:47:12 --> UTF-8 Support Enabled
DEBUG - 2011-05-25 13:47:12 --> URI Class Initialized
DEBUG - 2011-05-25 13:47:12 --> Router Class Initialized
DEBUG - 2011-05-25 13:47:12 --> Output Class Initialized
DEBUG - 2011-05-25 13:47:12 --> Input Class Initialized
DEBUG - 2011-05-25 13:47:12 --> Global POST and COOKIE data sanitized
DEBUG - 2011-05-25 13:47:12 --> Language Class Initialized
DEBUG - 2011-05-25 13:47:12 --> Loader Class Initialized
DEBUG - 2011-05-25 13:47:12 --> Controller Class Initialized
DEBUG - 2011-05-25 13:47:12 --> Model Class Initialized
DEBUG - 2011-05-25 13:47:12 --> Model Class Initialized
DEBUG - 2011-05-25 13:47:12 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-05-25 13:47:12 --> Database Driver Class Initialized
DEBUG - 2011-05-25 13:47:12 --> Config Class Initialized
DEBUG - 2011-05-25 13:47:12 --> Hooks Class Initialized
DEBUG - 2011-05-25 13:47:12 --> Utf8 Class Initialized
DEBUG - 2011-05-25 13:47:12 --> UTF-8 Support Enabled
DEBUG - 2011-05-25 13:47:12 --> URI Class Initialized
DEBUG - 2011-05-25 13:47:12 --> Router Class Initialized
DEBUG - 2011-05-25 13:47:12 --> Output Class Initialized
DEBUG - 2011-05-25 13:47:12 --> Input Class Initialized
DEBUG - 2011-05-25 13:47:12 --> Global POST and COOKIE data sanitized
DEBUG - 2011-05-25 13:47:12 --> Language Class Initialized
DEBUG - 2011-05-25 13:47:12 --> Loader Class Initialized
DEBUG - 2011-05-25 13:47:12 --> Controller Class Initialized
ERROR - 2011-05-25 13:47:12 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-05-25 13:47:12 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-05-25 13:47:12 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-05-25 13:47:12 --> Model Class Initialized
DEBUG - 2011-05-25 13:47:12 --> Model Class Initialized
DEBUG - 2011-05-25 13:47:12 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-05-25 13:47:12 --> Database Driver Class Initialized
DEBUG - 2011-05-25 13:47:12 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-05-25 13:47:12 --> Helper loaded: url_helper
DEBUG - 2011-05-25 13:47:12 --> File loaded: application/views/common/header.php
DEBUG - 2011-05-25 13:47:12 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-05-25 13:47:12 --> File loaded: application/views/common/footer.php
DEBUG - 2011-05-25 13:47:12 --> File loaded: application/views/layout/main.php
DEBUG - 2011-05-25 13:47:12 --> Final output sent to browser
DEBUG - 2011-05-25 13:47:12 --> Total execution time: 0.0281
DEBUG - 2011-05-25 13:47:12 --> Final output sent to browser
DEBUG - 2011-05-25 13:47:12 --> Total execution time: 0.5000
DEBUG - 2011-05-25 13:47:12 --> Config Class Initialized
DEBUG - 2011-05-25 13:47:12 --> Hooks Class Initialized
DEBUG - 2011-05-25 13:47:12 --> Utf8 Class Initialized
DEBUG - 2011-05-25 13:47:12 --> UTF-8 Support Enabled
DEBUG - 2011-05-25 13:47:12 --> URI Class Initialized
DEBUG - 2011-05-25 13:47:12 --> Router Class Initialized
DEBUG - 2011-05-25 13:47:12 --> Output Class Initialized
DEBUG - 2011-05-25 13:47:12 --> Input Class Initialized
DEBUG - 2011-05-25 13:47:12 --> Global POST and COOKIE data sanitized
DEBUG - 2011-05-25 13:47:12 --> Language Class Initialized
DEBUG - 2011-05-25 13:47:12 --> Loader Class Initialized
DEBUG - 2011-05-25 13:47:12 --> Controller Class Initialized
ERROR - 2011-05-25 13:47:12 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-05-25 13:47:12 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-05-25 13:47:12 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-05-25 13:47:12 --> Model Class Initialized
DEBUG - 2011-05-25 13:47:12 --> Model Class Initialized
DEBUG - 2011-05-25 13:47:12 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-05-25 13:47:12 --> Database Driver Class Initialized
DEBUG - 2011-05-25 13:47:12 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-05-25 13:47:12 --> Helper loaded: url_helper
DEBUG - 2011-05-25 13:47:12 --> File loaded: application/views/common/header.php
DEBUG - 2011-05-25 13:47:12 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-05-25 13:47:12 --> File loaded: application/views/common/footer.php
DEBUG - 2011-05-25 13:47:12 --> File loaded: application/views/layout/main.php
DEBUG - 2011-05-25 13:47:12 --> Final output sent to browser
DEBUG - 2011-05-25 13:47:12 --> Total execution time: 0.0283
DEBUG - 2011-05-25 13:47:14 --> Config Class Initialized
DEBUG - 2011-05-25 13:47:14 --> Hooks Class Initialized
DEBUG - 2011-05-25 13:47:14 --> Utf8 Class Initialized
DEBUG - 2011-05-25 13:47:14 --> UTF-8 Support Enabled
DEBUG - 2011-05-25 13:47:14 --> URI Class Initialized
DEBUG - 2011-05-25 13:47:14 --> Router Class Initialized
ERROR - 2011-05-25 13:47:14 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-05-25 13:47:17 --> Config Class Initialized
DEBUG - 2011-05-25 13:47:17 --> Hooks Class Initialized
DEBUG - 2011-05-25 13:47:17 --> Utf8 Class Initialized
DEBUG - 2011-05-25 13:47:17 --> UTF-8 Support Enabled
DEBUG - 2011-05-25 13:47:17 --> URI Class Initialized
DEBUG - 2011-05-25 13:47:17 --> Router Class Initialized
DEBUG - 2011-05-25 13:47:17 --> Output Class Initialized
DEBUG - 2011-05-25 13:47:17 --> Input Class Initialized
DEBUG - 2011-05-25 13:47:17 --> Global POST and COOKIE data sanitized
DEBUG - 2011-05-25 13:47:17 --> Language Class Initialized
DEBUG - 2011-05-25 13:47:18 --> Loader Class Initialized
DEBUG - 2011-05-25 13:47:18 --> Controller Class Initialized
ERROR - 2011-05-25 13:47:18 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-05-25 13:47:18 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-05-25 13:47:18 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-05-25 13:47:18 --> Model Class Initialized
DEBUG - 2011-05-25 13:47:18 --> Model Class Initialized
DEBUG - 2011-05-25 13:47:18 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-05-25 13:47:18 --> Database Driver Class Initialized
DEBUG - 2011-05-25 13:47:18 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-05-25 13:47:18 --> Helper loaded: url_helper
DEBUG - 2011-05-25 13:47:18 --> File loaded: application/views/common/header.php
DEBUG - 2011-05-25 13:47:18 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-05-25 13:47:18 --> File loaded: application/views/common/footer.php
DEBUG - 2011-05-25 13:47:18 --> File loaded: application/views/layout/main.php
DEBUG - 2011-05-25 13:47:18 --> Final output sent to browser
DEBUG - 2011-05-25 13:47:18 --> Total execution time: 0.0342
DEBUG - 2011-05-25 13:47:19 --> Config Class Initialized
DEBUG - 2011-05-25 13:47:19 --> Hooks Class Initialized
DEBUG - 2011-05-25 13:47:19 --> Utf8 Class Initialized
DEBUG - 2011-05-25 13:47:19 --> UTF-8 Support Enabled
DEBUG - 2011-05-25 13:47:19 --> URI Class Initialized
DEBUG - 2011-05-25 13:47:19 --> Router Class Initialized
DEBUG - 2011-05-25 13:47:19 --> Output Class Initialized
DEBUG - 2011-05-25 13:47:19 --> Config Class Initialized
DEBUG - 2011-05-25 13:47:19 --> Hooks Class Initialized
DEBUG - 2011-05-25 13:47:19 --> Utf8 Class Initialized
DEBUG - 2011-05-25 13:47:19 --> UTF-8 Support Enabled
DEBUG - 2011-05-25 13:47:19 --> URI Class Initialized
DEBUG - 2011-05-25 13:47:19 --> Router Class Initialized
DEBUG - 2011-05-25 13:47:19 --> Output Class Initialized
DEBUG - 2011-05-25 13:47:19 --> Input Class Initialized
DEBUG - 2011-05-25 13:47:19 --> Global POST and COOKIE data sanitized
DEBUG - 2011-05-25 13:47:19 --> Language Class Initialized
DEBUG - 2011-05-25 13:47:19 --> Input Class Initialized
DEBUG - 2011-05-25 13:47:19 --> Loader Class Initialized
DEBUG - 2011-05-25 13:47:19 --> Global POST and COOKIE data sanitized
DEBUG - 2011-05-25 13:47:19 --> Language Class Initialized
DEBUG - 2011-05-25 13:47:19 --> Loader Class Initialized
DEBUG - 2011-05-25 13:47:19 --> Controller Class Initialized
DEBUG - 2011-05-25 13:47:19 --> Controller Class Initialized
DEBUG - 2011-05-25 13:47:19 --> Model Class Initialized
ERROR - 2011-05-25 13:47:19 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-05-25 13:47:19 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-05-25 13:47:19 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-05-25 13:47:19 --> Model Class Initialized
DEBUG - 2011-05-25 13:47:19 --> Model Class Initialized
DEBUG - 2011-05-25 13:47:19 --> Model Class Initialized
DEBUG - 2011-05-25 13:47:19 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-05-25 13:47:19 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-05-25 13:47:19 --> Database Driver Class Initialized
DEBUG - 2011-05-25 13:47:19 --> Database Driver Class Initialized
DEBUG - 2011-05-25 13:47:19 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-05-25 13:47:19 --> Helper loaded: url_helper
DEBUG - 2011-05-25 13:47:19 --> File loaded: application/views/common/header.php
DEBUG - 2011-05-25 13:47:19 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-05-25 13:47:19 --> File loaded: application/views/common/footer.php
DEBUG - 2011-05-25 13:47:19 --> File loaded: application/views/layout/main.php
DEBUG - 2011-05-25 13:47:19 --> Final output sent to browser
DEBUG - 2011-05-25 13:47:19 --> Total execution time: 0.1431
DEBUG - 2011-05-25 13:47:20 --> Final output sent to browser
DEBUG - 2011-05-25 13:47:20 --> Total execution time: 0.7266
DEBUG - 2011-05-25 13:47:21 --> Config Class Initialized
DEBUG - 2011-05-25 13:47:21 --> Hooks Class Initialized
DEBUG - 2011-05-25 13:47:21 --> Utf8 Class Initialized
DEBUG - 2011-05-25 13:47:21 --> UTF-8 Support Enabled
DEBUG - 2011-05-25 13:47:21 --> URI Class Initialized
DEBUG - 2011-05-25 13:47:21 --> Router Class Initialized
ERROR - 2011-05-25 13:47:21 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-05-25 13:47:24 --> Config Class Initialized
DEBUG - 2011-05-25 13:47:24 --> Hooks Class Initialized
DEBUG - 2011-05-25 13:47:24 --> Utf8 Class Initialized
DEBUG - 2011-05-25 13:47:24 --> UTF-8 Support Enabled
DEBUG - 2011-05-25 13:47:24 --> URI Class Initialized
DEBUG - 2011-05-25 13:47:24 --> Router Class Initialized
DEBUG - 2011-05-25 13:47:24 --> Output Class Initialized
DEBUG - 2011-05-25 13:47:24 --> Input Class Initialized
DEBUG - 2011-05-25 13:47:24 --> Global POST and COOKIE data sanitized
DEBUG - 2011-05-25 13:47:24 --> Language Class Initialized
DEBUG - 2011-05-25 13:47:24 --> Loader Class Initialized
DEBUG - 2011-05-25 13:47:24 --> Controller Class Initialized
ERROR - 2011-05-25 13:47:24 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-05-25 13:47:24 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-05-25 13:47:24 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-05-25 13:47:24 --> Model Class Initialized
DEBUG - 2011-05-25 13:47:24 --> Model Class Initialized
DEBUG - 2011-05-25 13:47:24 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-05-25 13:47:24 --> Database Driver Class Initialized
DEBUG - 2011-05-25 13:47:24 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-05-25 13:47:24 --> Helper loaded: url_helper
DEBUG - 2011-05-25 13:47:24 --> File loaded: application/views/common/header.php
DEBUG - 2011-05-25 13:47:24 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-05-25 13:47:24 --> File loaded: application/views/common/footer.php
DEBUG - 2011-05-25 13:47:24 --> File loaded: application/views/layout/main.php
DEBUG - 2011-05-25 13:47:24 --> Final output sent to browser
DEBUG - 2011-05-25 13:47:24 --> Total execution time: 0.0274
DEBUG - 2011-05-25 13:47:24 --> Config Class Initialized
DEBUG - 2011-05-25 13:47:24 --> Hooks Class Initialized
DEBUG - 2011-05-25 13:47:24 --> Utf8 Class Initialized
DEBUG - 2011-05-25 13:47:24 --> UTF-8 Support Enabled
DEBUG - 2011-05-25 13:47:24 --> URI Class Initialized
DEBUG - 2011-05-25 13:47:24 --> Router Class Initialized
DEBUG - 2011-05-25 13:47:24 --> Output Class Initialized
DEBUG - 2011-05-25 13:47:24 --> Input Class Initialized
DEBUG - 2011-05-25 13:47:24 --> Global POST and COOKIE data sanitized
DEBUG - 2011-05-25 13:47:24 --> Language Class Initialized
DEBUG - 2011-05-25 13:47:24 --> Loader Class Initialized
DEBUG - 2011-05-25 13:47:24 --> Controller Class Initialized
DEBUG - 2011-05-25 13:47:24 --> Model Class Initialized
DEBUG - 2011-05-25 13:47:24 --> Model Class Initialized
DEBUG - 2011-05-25 13:47:24 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-05-25 13:47:24 --> Database Driver Class Initialized
DEBUG - 2011-05-25 13:47:25 --> Final output sent to browser
DEBUG - 2011-05-25 13:47:25 --> Total execution time: 0.6165
DEBUG - 2011-05-25 13:47:25 --> Config Class Initialized
DEBUG - 2011-05-25 13:47:25 --> Hooks Class Initialized
DEBUG - 2011-05-25 13:47:25 --> Utf8 Class Initialized
DEBUG - 2011-05-25 13:47:25 --> UTF-8 Support Enabled
DEBUG - 2011-05-25 13:47:25 --> URI Class Initialized
DEBUG - 2011-05-25 13:47:25 --> Router Class Initialized
DEBUG - 2011-05-25 13:47:25 --> Output Class Initialized
DEBUG - 2011-05-25 13:47:25 --> Input Class Initialized
DEBUG - 2011-05-25 13:47:25 --> Global POST and COOKIE data sanitized
DEBUG - 2011-05-25 13:47:25 --> Language Class Initialized
DEBUG - 2011-05-25 13:47:25 --> Loader Class Initialized
DEBUG - 2011-05-25 13:47:25 --> Controller Class Initialized
ERROR - 2011-05-25 13:47:25 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-05-25 13:47:25 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-05-25 13:47:25 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-05-25 13:47:25 --> Model Class Initialized
DEBUG - 2011-05-25 13:47:25 --> Model Class Initialized
DEBUG - 2011-05-25 13:47:25 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-05-25 13:47:25 --> Database Driver Class Initialized
DEBUG - 2011-05-25 13:47:25 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-05-25 13:47:25 --> Helper loaded: url_helper
DEBUG - 2011-05-25 13:47:25 --> File loaded: application/views/common/header.php
DEBUG - 2011-05-25 13:47:25 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-05-25 13:47:25 --> File loaded: application/views/common/footer.php
DEBUG - 2011-05-25 13:47:25 --> File loaded: application/views/layout/main.php
DEBUG - 2011-05-25 13:47:25 --> Final output sent to browser
DEBUG - 2011-05-25 13:47:25 --> Total execution time: 0.0270
DEBUG - 2011-05-25 13:47:26 --> Config Class Initialized
DEBUG - 2011-05-25 13:47:26 --> Hooks Class Initialized
DEBUG - 2011-05-25 13:47:26 --> Utf8 Class Initialized
DEBUG - 2011-05-25 13:47:26 --> UTF-8 Support Enabled
DEBUG - 2011-05-25 13:47:26 --> URI Class Initialized
DEBUG - 2011-05-25 13:47:26 --> Router Class Initialized
ERROR - 2011-05-25 13:47:26 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-05-25 13:47:52 --> Config Class Initialized
DEBUG - 2011-05-25 13:47:52 --> Hooks Class Initialized
DEBUG - 2011-05-25 13:47:52 --> Utf8 Class Initialized
DEBUG - 2011-05-25 13:47:52 --> UTF-8 Support Enabled
DEBUG - 2011-05-25 13:47:52 --> URI Class Initialized
DEBUG - 2011-05-25 13:47:52 --> Router Class Initialized
DEBUG - 2011-05-25 13:47:52 --> Output Class Initialized
DEBUG - 2011-05-25 13:47:52 --> Input Class Initialized
DEBUG - 2011-05-25 13:47:52 --> Global POST and COOKIE data sanitized
DEBUG - 2011-05-25 13:47:52 --> Language Class Initialized
DEBUG - 2011-05-25 13:47:52 --> Loader Class Initialized
DEBUG - 2011-05-25 13:47:52 --> Controller Class Initialized
ERROR - 2011-05-25 13:47:52 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-05-25 13:47:52 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-05-25 13:47:52 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-05-25 13:47:52 --> Model Class Initialized
DEBUG - 2011-05-25 13:47:52 --> Model Class Initialized
DEBUG - 2011-05-25 13:47:52 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-05-25 13:47:52 --> Database Driver Class Initialized
DEBUG - 2011-05-25 13:47:52 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-05-25 13:47:52 --> Helper loaded: url_helper
DEBUG - 2011-05-25 13:47:52 --> File loaded: application/views/common/header.php
DEBUG - 2011-05-25 13:47:52 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-05-25 13:47:52 --> File loaded: application/views/common/footer.php
DEBUG - 2011-05-25 13:47:52 --> File loaded: application/views/layout/main.php
DEBUG - 2011-05-25 13:47:52 --> Final output sent to browser
DEBUG - 2011-05-25 13:47:52 --> Total execution time: 0.0455
DEBUG - 2011-05-25 13:47:53 --> Config Class Initialized
DEBUG - 2011-05-25 13:47:53 --> Hooks Class Initialized
DEBUG - 2011-05-25 13:47:53 --> Utf8 Class Initialized
DEBUG - 2011-05-25 13:47:53 --> UTF-8 Support Enabled
DEBUG - 2011-05-25 13:47:53 --> URI Class Initialized
DEBUG - 2011-05-25 13:47:53 --> Router Class Initialized
DEBUG - 2011-05-25 13:47:53 --> Output Class Initialized
DEBUG - 2011-05-25 13:47:53 --> Input Class Initialized
DEBUG - 2011-05-25 13:47:53 --> Global POST and COOKIE data sanitized
DEBUG - 2011-05-25 13:47:53 --> Language Class Initialized
DEBUG - 2011-05-25 13:47:53 --> Loader Class Initialized
DEBUG - 2011-05-25 13:47:53 --> Controller Class Initialized
DEBUG - 2011-05-25 13:47:53 --> Model Class Initialized
DEBUG - 2011-05-25 13:47:53 --> Model Class Initialized
DEBUG - 2011-05-25 13:47:53 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-05-25 13:47:53 --> Database Driver Class Initialized
DEBUG - 2011-05-25 13:47:53 --> Config Class Initialized
DEBUG - 2011-05-25 13:47:53 --> Hooks Class Initialized
DEBUG - 2011-05-25 13:47:53 --> Utf8 Class Initialized
DEBUG - 2011-05-25 13:47:53 --> UTF-8 Support Enabled
DEBUG - 2011-05-25 13:47:53 --> URI Class Initialized
DEBUG - 2011-05-25 13:47:53 --> Router Class Initialized
DEBUG - 2011-05-25 13:47:53 --> Output Class Initialized
DEBUG - 2011-05-25 13:47:53 --> Input Class Initialized
DEBUG - 2011-05-25 13:47:53 --> Global POST and COOKIE data sanitized
DEBUG - 2011-05-25 13:47:53 --> Language Class Initialized
DEBUG - 2011-05-25 13:47:53 --> Loader Class Initialized
DEBUG - 2011-05-25 13:47:53 --> Controller Class Initialized
ERROR - 2011-05-25 13:47:53 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-05-25 13:47:53 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-05-25 13:47:53 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-05-25 13:47:53 --> Model Class Initialized
DEBUG - 2011-05-25 13:47:53 --> Model Class Initialized
DEBUG - 2011-05-25 13:47:53 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-05-25 13:47:53 --> Database Driver Class Initialized
DEBUG - 2011-05-25 13:47:53 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-05-25 13:47:53 --> Helper loaded: url_helper
DEBUG - 2011-05-25 13:47:53 --> File loaded: application/views/common/header.php
DEBUG - 2011-05-25 13:47:53 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-05-25 13:47:53 --> File loaded: application/views/common/footer.php
DEBUG - 2011-05-25 13:47:53 --> File loaded: application/views/layout/main.php
DEBUG - 2011-05-25 13:47:53 --> Final output sent to browser
DEBUG - 2011-05-25 13:47:53 --> Total execution time: 0.0287
DEBUG - 2011-05-25 13:47:54 --> Final output sent to browser
DEBUG - 2011-05-25 13:47:54 --> Total execution time: 0.5522
DEBUG - 2011-05-25 13:47:55 --> Config Class Initialized
DEBUG - 2011-05-25 13:47:55 --> Hooks Class Initialized
DEBUG - 2011-05-25 13:47:55 --> Utf8 Class Initialized
DEBUG - 2011-05-25 13:47:55 --> UTF-8 Support Enabled
DEBUG - 2011-05-25 13:47:55 --> URI Class Initialized
DEBUG - 2011-05-25 13:47:55 --> Router Class Initialized
ERROR - 2011-05-25 13:47:55 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-05-25 13:48:01 --> Config Class Initialized
DEBUG - 2011-05-25 13:48:01 --> Hooks Class Initialized
DEBUG - 2011-05-25 13:48:01 --> Utf8 Class Initialized
DEBUG - 2011-05-25 13:48:01 --> UTF-8 Support Enabled
DEBUG - 2011-05-25 13:48:01 --> URI Class Initialized
DEBUG - 2011-05-25 13:48:01 --> Router Class Initialized
DEBUG - 2011-05-25 13:48:01 --> Output Class Initialized
DEBUG - 2011-05-25 13:48:01 --> Input Class Initialized
DEBUG - 2011-05-25 13:48:01 --> Global POST and COOKIE data sanitized
DEBUG - 2011-05-25 13:48:01 --> Language Class Initialized
DEBUG - 2011-05-25 13:48:01 --> Loader Class Initialized
DEBUG - 2011-05-25 13:48:01 --> Controller Class Initialized
ERROR - 2011-05-25 13:48:01 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-05-25 13:48:01 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-05-25 13:48:01 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-05-25 13:48:01 --> Model Class Initialized
DEBUG - 2011-05-25 13:48:01 --> Model Class Initialized
DEBUG - 2011-05-25 13:48:01 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-05-25 13:48:01 --> Database Driver Class Initialized
DEBUG - 2011-05-25 13:48:01 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-05-25 13:48:01 --> Helper loaded: url_helper
DEBUG - 2011-05-25 13:48:01 --> File loaded: application/views/common/header.php
DEBUG - 2011-05-25 13:48:01 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-05-25 13:48:01 --> File loaded: application/views/common/footer.php
DEBUG - 2011-05-25 13:48:01 --> File loaded: application/views/layout/main.php
DEBUG - 2011-05-25 13:48:01 --> Final output sent to browser
DEBUG - 2011-05-25 13:48:01 --> Total execution time: 0.0554
DEBUG - 2011-05-25 13:48:02 --> Config Class Initialized
DEBUG - 2011-05-25 13:48:02 --> Hooks Class Initialized
DEBUG - 2011-05-25 13:48:02 --> Utf8 Class Initialized
DEBUG - 2011-05-25 13:48:02 --> UTF-8 Support Enabled
DEBUG - 2011-05-25 13:48:02 --> URI Class Initialized
DEBUG - 2011-05-25 13:48:02 --> Router Class Initialized
DEBUG - 2011-05-25 13:48:02 --> Output Class Initialized
DEBUG - 2011-05-25 13:48:02 --> Input Class Initialized
DEBUG - 2011-05-25 13:48:02 --> Global POST and COOKIE data sanitized
DEBUG - 2011-05-25 13:48:02 --> Language Class Initialized
DEBUG - 2011-05-25 13:48:02 --> Loader Class Initialized
DEBUG - 2011-05-25 13:48:02 --> Controller Class Initialized
ERROR - 2011-05-25 13:48:02 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-05-25 13:48:02 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-05-25 13:48:02 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-05-25 13:48:02 --> Model Class Initialized
DEBUG - 2011-05-25 13:48:02 --> Model Class Initialized
DEBUG - 2011-05-25 13:48:02 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-05-25 13:48:02 --> Database Driver Class Initialized
DEBUG - 2011-05-25 13:48:02 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-05-25 13:48:02 --> Helper loaded: url_helper
DEBUG - 2011-05-25 13:48:02 --> File loaded: application/views/common/header.php
DEBUG - 2011-05-25 13:48:02 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-05-25 13:48:02 --> File loaded: application/views/common/footer.php
DEBUG - 2011-05-25 13:48:02 --> File loaded: application/views/layout/main.php
DEBUG - 2011-05-25 13:48:02 --> Final output sent to browser
DEBUG - 2011-05-25 13:48:02 --> Total execution time: 0.0385
DEBUG - 2011-05-25 13:48:02 --> Config Class Initialized
DEBUG - 2011-05-25 13:48:02 --> Hooks Class Initialized
DEBUG - 2011-05-25 13:48:02 --> Utf8 Class Initialized
DEBUG - 2011-05-25 13:48:02 --> UTF-8 Support Enabled
DEBUG - 2011-05-25 13:48:02 --> URI Class Initialized
DEBUG - 2011-05-25 13:48:02 --> Router Class Initialized
DEBUG - 2011-05-25 13:48:02 --> Output Class Initialized
DEBUG - 2011-05-25 13:48:02 --> Input Class Initialized
DEBUG - 2011-05-25 13:48:02 --> Global POST and COOKIE data sanitized
DEBUG - 2011-05-25 13:48:02 --> Language Class Initialized
DEBUG - 2011-05-25 13:48:02 --> Loader Class Initialized
DEBUG - 2011-05-25 13:48:02 --> Controller Class Initialized
DEBUG - 2011-05-25 13:48:02 --> Model Class Initialized
DEBUG - 2011-05-25 13:48:02 --> Model Class Initialized
DEBUG - 2011-05-25 13:48:02 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-05-25 13:48:02 --> Database Driver Class Initialized
DEBUG - 2011-05-25 13:48:03 --> Final output sent to browser
DEBUG - 2011-05-25 13:48:03 --> Total execution time: 0.6274
DEBUG - 2011-05-25 13:48:04 --> Config Class Initialized
DEBUG - 2011-05-25 13:48:04 --> Hooks Class Initialized
DEBUG - 2011-05-25 13:48:04 --> Utf8 Class Initialized
DEBUG - 2011-05-25 13:48:04 --> UTF-8 Support Enabled
DEBUG - 2011-05-25 13:48:04 --> URI Class Initialized
DEBUG - 2011-05-25 13:48:04 --> Router Class Initialized
ERROR - 2011-05-25 13:48:04 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-05-25 13:48:17 --> Config Class Initialized
DEBUG - 2011-05-25 13:48:17 --> Hooks Class Initialized
DEBUG - 2011-05-25 13:48:17 --> Utf8 Class Initialized
DEBUG - 2011-05-25 13:48:17 --> UTF-8 Support Enabled
DEBUG - 2011-05-25 13:48:17 --> URI Class Initialized
DEBUG - 2011-05-25 13:48:17 --> Router Class Initialized
DEBUG - 2011-05-25 13:48:17 --> Output Class Initialized
DEBUG - 2011-05-25 13:48:17 --> Input Class Initialized
DEBUG - 2011-05-25 13:48:17 --> Global POST and COOKIE data sanitized
DEBUG - 2011-05-25 13:48:17 --> Language Class Initialized
DEBUG - 2011-05-25 13:48:17 --> Loader Class Initialized
DEBUG - 2011-05-25 13:48:17 --> Controller Class Initialized
ERROR - 2011-05-25 13:48:17 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-05-25 13:48:17 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-05-25 13:48:17 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-05-25 13:48:17 --> Model Class Initialized
DEBUG - 2011-05-25 13:48:17 --> Model Class Initialized
DEBUG - 2011-05-25 13:48:17 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-05-25 13:48:17 --> Database Driver Class Initialized
DEBUG - 2011-05-25 13:48:17 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-05-25 13:48:17 --> Helper loaded: url_helper
DEBUG - 2011-05-25 13:48:17 --> File loaded: application/views/common/header.php
DEBUG - 2011-05-25 13:48:17 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-05-25 13:48:17 --> File loaded: application/views/common/footer.php
DEBUG - 2011-05-25 13:48:17 --> File loaded: application/views/layout/main.php
DEBUG - 2011-05-25 13:48:17 --> Final output sent to browser
DEBUG - 2011-05-25 13:48:17 --> Total execution time: 0.0584
DEBUG - 2011-05-25 13:48:18 --> Config Class Initialized
DEBUG - 2011-05-25 13:48:18 --> Hooks Class Initialized
DEBUG - 2011-05-25 13:48:18 --> Utf8 Class Initialized
DEBUG - 2011-05-25 13:48:18 --> UTF-8 Support Enabled
DEBUG - 2011-05-25 13:48:18 --> URI Class Initialized
DEBUG - 2011-05-25 13:48:18 --> Router Class Initialized
DEBUG - 2011-05-25 13:48:18 --> Output Class Initialized
DEBUG - 2011-05-25 13:48:18 --> Input Class Initialized
DEBUG - 2011-05-25 13:48:18 --> Global POST and COOKIE data sanitized
DEBUG - 2011-05-25 13:48:18 --> Language Class Initialized
DEBUG - 2011-05-25 13:48:18 --> Loader Class Initialized
DEBUG - 2011-05-25 13:48:18 --> Controller Class Initialized
DEBUG - 2011-05-25 13:48:18 --> Model Class Initialized
DEBUG - 2011-05-25 13:48:18 --> Model Class Initialized
DEBUG - 2011-05-25 13:48:18 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-05-25 13:48:18 --> Database Driver Class Initialized
DEBUG - 2011-05-25 13:48:18 --> Final output sent to browser
DEBUG - 2011-05-25 13:48:18 --> Total execution time: 0.5677
DEBUG - 2011-05-25 13:48:20 --> Config Class Initialized
DEBUG - 2011-05-25 13:48:20 --> Hooks Class Initialized
DEBUG - 2011-05-25 13:48:20 --> Utf8 Class Initialized
DEBUG - 2011-05-25 13:48:20 --> UTF-8 Support Enabled
DEBUG - 2011-05-25 13:48:20 --> URI Class Initialized
DEBUG - 2011-05-25 13:48:20 --> Router Class Initialized
DEBUG - 2011-05-25 13:48:20 --> Output Class Initialized
DEBUG - 2011-05-25 13:48:20 --> Input Class Initialized
DEBUG - 2011-05-25 13:48:20 --> Global POST and COOKIE data sanitized
DEBUG - 2011-05-25 13:48:20 --> Language Class Initialized
DEBUG - 2011-05-25 13:48:20 --> Loader Class Initialized
DEBUG - 2011-05-25 13:48:20 --> Controller Class Initialized
ERROR - 2011-05-25 13:48:20 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-05-25 13:48:20 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-05-25 13:48:20 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-05-25 13:48:20 --> Model Class Initialized
DEBUG - 2011-05-25 13:48:20 --> Model Class Initialized
DEBUG - 2011-05-25 13:48:20 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-05-25 13:48:20 --> Database Driver Class Initialized
DEBUG - 2011-05-25 13:48:20 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-05-25 13:48:20 --> Helper loaded: url_helper
DEBUG - 2011-05-25 13:48:20 --> File loaded: application/views/common/header.php
DEBUG - 2011-05-25 13:48:20 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-05-25 13:48:20 --> File loaded: application/views/common/footer.php
DEBUG - 2011-05-25 13:48:20 --> File loaded: application/views/layout/main.php
DEBUG - 2011-05-25 13:48:20 --> Final output sent to browser
DEBUG - 2011-05-25 13:48:20 --> Total execution time: 0.0285
DEBUG - 2011-05-25 13:48:22 --> Config Class Initialized
DEBUG - 2011-05-25 13:48:22 --> Hooks Class Initialized
DEBUG - 2011-05-25 13:48:22 --> Utf8 Class Initialized
DEBUG - 2011-05-25 13:48:22 --> UTF-8 Support Enabled
DEBUG - 2011-05-25 13:48:22 --> URI Class Initialized
DEBUG - 2011-05-25 13:48:22 --> Router Class Initialized
ERROR - 2011-05-25 13:48:22 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-05-25 13:54:43 --> Config Class Initialized
DEBUG - 2011-05-25 13:54:43 --> Hooks Class Initialized
DEBUG - 2011-05-25 13:54:43 --> Utf8 Class Initialized
DEBUG - 2011-05-25 13:54:43 --> UTF-8 Support Enabled
DEBUG - 2011-05-25 13:54:43 --> URI Class Initialized
DEBUG - 2011-05-25 13:54:43 --> Router Class Initialized
DEBUG - 2011-05-25 13:54:43 --> No URI present. Default controller set.
DEBUG - 2011-05-25 13:54:43 --> Output Class Initialized
DEBUG - 2011-05-25 13:54:43 --> Input Class Initialized
DEBUG - 2011-05-25 13:54:43 --> Global POST and COOKIE data sanitized
DEBUG - 2011-05-25 13:54:43 --> Language Class Initialized
DEBUG - 2011-05-25 13:54:43 --> Loader Class Initialized
DEBUG - 2011-05-25 13:54:43 --> Controller Class Initialized
DEBUG - 2011-05-25 13:54:43 --> File loaded: application/views/splash/main.php
DEBUG - 2011-05-25 13:54:43 --> Helper loaded: url_helper
DEBUG - 2011-05-25 13:54:43 --> File loaded: application/views/common/header.php
DEBUG - 2011-05-25 13:54:43 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-05-25 13:54:43 --> File loaded: application/views/common/footer.php
DEBUG - 2011-05-25 13:54:43 --> File loaded: application/views/layout/main.php
DEBUG - 2011-05-25 13:54:43 --> Final output sent to browser
DEBUG - 2011-05-25 13:54:43 --> Total execution time: 0.0390
DEBUG - 2011-05-25 15:38:05 --> Config Class Initialized
DEBUG - 2011-05-25 15:38:05 --> Hooks Class Initialized
DEBUG - 2011-05-25 15:38:05 --> Utf8 Class Initialized
DEBUG - 2011-05-25 15:38:05 --> UTF-8 Support Enabled
DEBUG - 2011-05-25 15:38:05 --> URI Class Initialized
DEBUG - 2011-05-25 15:38:05 --> Router Class Initialized
ERROR - 2011-05-25 15:38:05 --> 404 Page Not Found --> robots.txt
DEBUG - 2011-05-25 16:20:18 --> Config Class Initialized
DEBUG - 2011-05-25 16:20:18 --> Hooks Class Initialized
DEBUG - 2011-05-25 16:20:19 --> Utf8 Class Initialized
DEBUG - 2011-05-25 16:20:19 --> UTF-8 Support Enabled
DEBUG - 2011-05-25 16:20:19 --> URI Class Initialized
DEBUG - 2011-05-25 16:20:19 --> Router Class Initialized
DEBUG - 2011-05-25 16:20:19 --> Output Class Initialized
DEBUG - 2011-05-25 16:20:19 --> Input Class Initialized
DEBUG - 2011-05-25 16:20:19 --> Global POST and COOKIE data sanitized
DEBUG - 2011-05-25 16:20:20 --> Language Class Initialized
DEBUG - 2011-05-25 16:20:20 --> Loader Class Initialized
DEBUG - 2011-05-25 16:20:21 --> Controller Class Initialized
ERROR - 2011-05-25 16:20:22 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-05-25 16:20:22 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-05-25 16:20:22 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-05-25 16:20:22 --> Model Class Initialized
DEBUG - 2011-05-25 16:20:22 --> Model Class Initialized
DEBUG - 2011-05-25 16:20:23 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-05-25 16:20:23 --> Database Driver Class Initialized
DEBUG - 2011-05-25 16:20:23 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-05-25 16:20:23 --> Helper loaded: url_helper
DEBUG - 2011-05-25 16:20:23 --> File loaded: application/views/common/header.php
DEBUG - 2011-05-25 16:20:23 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-05-25 16:20:23 --> File loaded: application/views/common/footer.php
DEBUG - 2011-05-25 16:20:23 --> File loaded: application/views/layout/main.php
DEBUG - 2011-05-25 16:20:23 --> Final output sent to browser
DEBUG - 2011-05-25 16:20:23 --> Total execution time: 5.1944
DEBUG - 2011-05-25 16:20:25 --> Config Class Initialized
DEBUG - 2011-05-25 16:20:25 --> Hooks Class Initialized
DEBUG - 2011-05-25 16:20:25 --> Utf8 Class Initialized
DEBUG - 2011-05-25 16:20:25 --> UTF-8 Support Enabled
DEBUG - 2011-05-25 16:20:25 --> URI Class Initialized
DEBUG - 2011-05-25 16:20:25 --> Router Class Initialized
DEBUG - 2011-05-25 16:20:25 --> Output Class Initialized
DEBUG - 2011-05-25 16:20:25 --> Input Class Initialized
DEBUG - 2011-05-25 16:20:25 --> Global POST and COOKIE data sanitized
DEBUG - 2011-05-25 16:20:25 --> Language Class Initialized
DEBUG - 2011-05-25 16:20:25 --> Loader Class Initialized
DEBUG - 2011-05-25 16:20:25 --> Controller Class Initialized
DEBUG - 2011-05-25 16:20:25 --> Model Class Initialized
DEBUG - 2011-05-25 16:20:25 --> Model Class Initialized
DEBUG - 2011-05-25 16:20:25 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-05-25 16:20:25 --> Database Driver Class Initialized
DEBUG - 2011-05-25 16:20:28 --> Final output sent to browser
DEBUG - 2011-05-25 16:20:28 --> Total execution time: 2.1161
DEBUG - 2011-05-25 16:20:29 --> Config Class Initialized
DEBUG - 2011-05-25 16:20:29 --> Hooks Class Initialized
DEBUG - 2011-05-25 16:20:29 --> Utf8 Class Initialized
DEBUG - 2011-05-25 16:20:29 --> UTF-8 Support Enabled
DEBUG - 2011-05-25 16:20:29 --> URI Class Initialized
DEBUG - 2011-05-25 16:20:29 --> Router Class Initialized
ERROR - 2011-05-25 16:20:29 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-05-25 16:53:00 --> Config Class Initialized
DEBUG - 2011-05-25 16:53:00 --> Hooks Class Initialized
DEBUG - 2011-05-25 16:53:00 --> Utf8 Class Initialized
DEBUG - 2011-05-25 16:53:00 --> UTF-8 Support Enabled
DEBUG - 2011-05-25 16:53:00 --> URI Class Initialized
DEBUG - 2011-05-25 16:53:00 --> Router Class Initialized
DEBUG - 2011-05-25 16:53:00 --> Output Class Initialized
DEBUG - 2011-05-25 16:53:00 --> Input Class Initialized
DEBUG - 2011-05-25 16:53:00 --> Global POST and COOKIE data sanitized
DEBUG - 2011-05-25 16:53:00 --> Language Class Initialized
DEBUG - 2011-05-25 16:53:00 --> Loader Class Initialized
DEBUG - 2011-05-25 16:53:00 --> Controller Class Initialized
ERROR - 2011-05-25 16:53:00 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-05-25 16:53:00 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-05-25 16:53:00 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-05-25 16:53:00 --> Model Class Initialized
DEBUG - 2011-05-25 16:53:00 --> Model Class Initialized
DEBUG - 2011-05-25 16:53:00 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-05-25 16:53:00 --> Database Driver Class Initialized
DEBUG - 2011-05-25 16:53:00 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-05-25 16:53:00 --> Helper loaded: url_helper
DEBUG - 2011-05-25 16:53:00 --> File loaded: application/views/common/header.php
DEBUG - 2011-05-25 16:53:00 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-05-25 16:53:00 --> File loaded: application/views/common/footer.php
DEBUG - 2011-05-25 16:53:00 --> File loaded: application/views/layout/main.php
DEBUG - 2011-05-25 16:53:00 --> Final output sent to browser
DEBUG - 2011-05-25 16:53:00 --> Total execution time: 0.3071
DEBUG - 2011-05-25 16:53:01 --> Config Class Initialized
DEBUG - 2011-05-25 16:53:01 --> Hooks Class Initialized
DEBUG - 2011-05-25 16:53:01 --> Utf8 Class Initialized
DEBUG - 2011-05-25 16:53:01 --> UTF-8 Support Enabled
DEBUG - 2011-05-25 16:53:01 --> URI Class Initialized
DEBUG - 2011-05-25 16:53:01 --> Router Class Initialized
DEBUG - 2011-05-25 16:53:01 --> Output Class Initialized
DEBUG - 2011-05-25 16:53:01 --> Input Class Initialized
DEBUG - 2011-05-25 16:53:01 --> Global POST and COOKIE data sanitized
DEBUG - 2011-05-25 16:53:01 --> Language Class Initialized
DEBUG - 2011-05-25 16:53:01 --> Loader Class Initialized
DEBUG - 2011-05-25 16:53:01 --> Controller Class Initialized
DEBUG - 2011-05-25 16:53:01 --> Model Class Initialized
DEBUG - 2011-05-25 16:53:01 --> Model Class Initialized
DEBUG - 2011-05-25 16:53:01 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-05-25 16:53:01 --> Database Driver Class Initialized
DEBUG - 2011-05-25 16:53:01 --> Config Class Initialized
DEBUG - 2011-05-25 16:53:01 --> Hooks Class Initialized
DEBUG - 2011-05-25 16:53:01 --> Utf8 Class Initialized
DEBUG - 2011-05-25 16:53:01 --> UTF-8 Support Enabled
DEBUG - 2011-05-25 16:53:01 --> URI Class Initialized
DEBUG - 2011-05-25 16:53:01 --> Router Class Initialized
ERROR - 2011-05-25 16:53:01 --> 404 Page Not Found --> robots.txt
DEBUG - 2011-05-25 16:53:02 --> Config Class Initialized
DEBUG - 2011-05-25 16:53:02 --> Hooks Class Initialized
DEBUG - 2011-05-25 16:53:02 --> Utf8 Class Initialized
DEBUG - 2011-05-25 16:53:02 --> UTF-8 Support Enabled
DEBUG - 2011-05-25 16:53:02 --> URI Class Initialized
DEBUG - 2011-05-25 16:53:02 --> Router Class Initialized
DEBUG - 2011-05-25 16:53:02 --> Output Class Initialized
DEBUG - 2011-05-25 16:53:02 --> Input Class Initialized
DEBUG - 2011-05-25 16:53:02 --> Global POST and COOKIE data sanitized
DEBUG - 2011-05-25 16:53:02 --> Language Class Initialized
DEBUG - 2011-05-25 16:53:02 --> Loader Class Initialized
DEBUG - 2011-05-25 16:53:02 --> Controller Class Initialized
ERROR - 2011-05-25 16:53:02 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-05-25 16:53:02 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-05-25 16:53:02 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-05-25 16:53:02 --> Model Class Initialized
DEBUG - 2011-05-25 16:53:02 --> Model Class Initialized
DEBUG - 2011-05-25 16:53:02 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-05-25 16:53:02 --> Database Driver Class Initialized
DEBUG - 2011-05-25 16:53:02 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-05-25 16:53:02 --> Helper loaded: url_helper
DEBUG - 2011-05-25 16:53:02 --> File loaded: application/views/common/header.php
DEBUG - 2011-05-25 16:53:02 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-05-25 16:53:02 --> File loaded: application/views/common/footer.php
DEBUG - 2011-05-25 16:53:02 --> File loaded: application/views/layout/main.php
DEBUG - 2011-05-25 16:53:02 --> Final output sent to browser
DEBUG - 2011-05-25 16:53:02 --> Total execution time: 0.0307
DEBUG - 2011-05-25 16:53:02 --> Final output sent to browser
DEBUG - 2011-05-25 16:53:02 --> Total execution time: 1.0187
DEBUG - 2011-05-25 16:53:04 --> Config Class Initialized
DEBUG - 2011-05-25 16:53:04 --> Hooks Class Initialized
DEBUG - 2011-05-25 16:53:04 --> Utf8 Class Initialized
DEBUG - 2011-05-25 16:53:04 --> UTF-8 Support Enabled
DEBUG - 2011-05-25 16:53:04 --> URI Class Initialized
DEBUG - 2011-05-25 16:53:04 --> Router Class Initialized
ERROR - 2011-05-25 16:53:04 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-05-25 16:53:19 --> Config Class Initialized
DEBUG - 2011-05-25 16:53:19 --> Hooks Class Initialized
DEBUG - 2011-05-25 16:53:19 --> Utf8 Class Initialized
DEBUG - 2011-05-25 16:53:19 --> UTF-8 Support Enabled
DEBUG - 2011-05-25 16:53:19 --> URI Class Initialized
DEBUG - 2011-05-25 16:53:19 --> Router Class Initialized
DEBUG - 2011-05-25 16:53:19 --> Output Class Initialized
DEBUG - 2011-05-25 16:53:19 --> Input Class Initialized
DEBUG - 2011-05-25 16:53:19 --> Global POST and COOKIE data sanitized
DEBUG - 2011-05-25 16:53:19 --> Language Class Initialized
DEBUG - 2011-05-25 16:53:19 --> Loader Class Initialized
DEBUG - 2011-05-25 16:53:19 --> Controller Class Initialized
ERROR - 2011-05-25 16:53:19 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-05-25 16:53:19 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-05-25 16:53:19 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-05-25 16:53:19 --> Model Class Initialized
DEBUG - 2011-05-25 16:53:19 --> Model Class Initialized
DEBUG - 2011-05-25 16:53:19 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-05-25 16:53:19 --> Database Driver Class Initialized
DEBUG - 2011-05-25 16:53:19 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-05-25 16:53:19 --> Helper loaded: url_helper
DEBUG - 2011-05-25 16:53:19 --> File loaded: application/views/common/header.php
DEBUG - 2011-05-25 16:53:19 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-05-25 16:53:19 --> File loaded: application/views/common/footer.php
DEBUG - 2011-05-25 16:53:19 --> File loaded: application/views/layout/main.php
DEBUG - 2011-05-25 16:53:19 --> Final output sent to browser
DEBUG - 2011-05-25 16:53:19 --> Total execution time: 0.0980
DEBUG - 2011-05-25 16:53:20 --> Config Class Initialized
DEBUG - 2011-05-25 16:53:20 --> Hooks Class Initialized
DEBUG - 2011-05-25 16:53:20 --> Utf8 Class Initialized
DEBUG - 2011-05-25 16:53:20 --> UTF-8 Support Enabled
DEBUG - 2011-05-25 16:53:20 --> URI Class Initialized
DEBUG - 2011-05-25 16:53:20 --> Router Class Initialized
DEBUG - 2011-05-25 16:53:20 --> Output Class Initialized
DEBUG - 2011-05-25 16:53:20 --> Input Class Initialized
DEBUG - 2011-05-25 16:53:20 --> Global POST and COOKIE data sanitized
DEBUG - 2011-05-25 16:53:20 --> Language Class Initialized
DEBUG - 2011-05-25 16:53:20 --> Loader Class Initialized
DEBUG - 2011-05-25 16:53:20 --> Controller Class Initialized
ERROR - 2011-05-25 16:53:20 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-05-25 16:53:20 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-05-25 16:53:20 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-05-25 16:53:20 --> Model Class Initialized
DEBUG - 2011-05-25 16:53:20 --> Model Class Initialized
DEBUG - 2011-05-25 16:53:20 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-05-25 16:53:20 --> Database Driver Class Initialized
DEBUG - 2011-05-25 16:53:20 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-05-25 16:53:20 --> Helper loaded: url_helper
DEBUG - 2011-05-25 16:53:20 --> File loaded: application/views/common/header.php
DEBUG - 2011-05-25 16:53:20 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-05-25 16:53:20 --> File loaded: application/views/common/footer.php
DEBUG - 2011-05-25 16:53:20 --> File loaded: application/views/layout/main.php
DEBUG - 2011-05-25 16:53:20 --> Final output sent to browser
DEBUG - 2011-05-25 16:53:20 --> Total execution time: 0.0322
DEBUG - 2011-05-25 16:53:20 --> Config Class Initialized
DEBUG - 2011-05-25 16:53:20 --> Hooks Class Initialized
DEBUG - 2011-05-25 16:53:20 --> Utf8 Class Initialized
DEBUG - 2011-05-25 16:53:20 --> UTF-8 Support Enabled
DEBUG - 2011-05-25 16:53:20 --> URI Class Initialized
DEBUG - 2011-05-25 16:53:20 --> Router Class Initialized
DEBUG - 2011-05-25 16:53:20 --> Output Class Initialized
DEBUG - 2011-05-25 16:53:20 --> Input Class Initialized
DEBUG - 2011-05-25 16:53:20 --> Global POST and COOKIE data sanitized
DEBUG - 2011-05-25 16:53:20 --> Language Class Initialized
DEBUG - 2011-05-25 16:53:20 --> Loader Class Initialized
DEBUG - 2011-05-25 16:53:20 --> Controller Class Initialized
ERROR - 2011-05-25 16:53:20 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-05-25 16:53:20 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-05-25 16:53:20 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-05-25 16:53:20 --> Model Class Initialized
DEBUG - 2011-05-25 16:53:20 --> Model Class Initialized
DEBUG - 2011-05-25 16:53:20 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-05-25 16:53:20 --> Database Driver Class Initialized
DEBUG - 2011-05-25 16:53:20 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-05-25 16:53:20 --> Helper loaded: url_helper
DEBUG - 2011-05-25 16:53:20 --> File loaded: application/views/common/header.php
DEBUG - 2011-05-25 16:53:20 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-05-25 16:53:20 --> File loaded: application/views/common/footer.php
DEBUG - 2011-05-25 16:53:20 --> File loaded: application/views/layout/main.php
DEBUG - 2011-05-25 16:53:20 --> Final output sent to browser
DEBUG - 2011-05-25 16:53:20 --> Total execution time: 0.0337
DEBUG - 2011-05-25 16:53:20 --> Config Class Initialized
DEBUG - 2011-05-25 16:53:20 --> Hooks Class Initialized
DEBUG - 2011-05-25 16:53:20 --> Utf8 Class Initialized
DEBUG - 2011-05-25 16:53:20 --> UTF-8 Support Enabled
DEBUG - 2011-05-25 16:53:20 --> URI Class Initialized
DEBUG - 2011-05-25 16:53:20 --> Router Class Initialized
DEBUG - 2011-05-25 16:53:20 --> Output Class Initialized
DEBUG - 2011-05-25 16:53:20 --> Input Class Initialized
DEBUG - 2011-05-25 16:53:20 --> Global POST and COOKIE data sanitized
DEBUG - 2011-05-25 16:53:20 --> Language Class Initialized
DEBUG - 2011-05-25 16:53:20 --> Loader Class Initialized
DEBUG - 2011-05-25 16:53:20 --> Controller Class Initialized
DEBUG - 2011-05-25 16:53:20 --> Model Class Initialized
DEBUG - 2011-05-25 16:53:20 --> Model Class Initialized
DEBUG - 2011-05-25 16:53:20 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-05-25 16:53:20 --> Database Driver Class Initialized
DEBUG - 2011-05-25 16:53:21 --> Final output sent to browser
DEBUG - 2011-05-25 16:53:21 --> Total execution time: 0.6672
DEBUG - 2011-05-25 16:53:23 --> Config Class Initialized
DEBUG - 2011-05-25 16:53:23 --> Hooks Class Initialized
DEBUG - 2011-05-25 16:53:23 --> Utf8 Class Initialized
DEBUG - 2011-05-25 16:53:23 --> UTF-8 Support Enabled
DEBUG - 2011-05-25 16:53:23 --> URI Class Initialized
DEBUG - 2011-05-25 16:53:23 --> Router Class Initialized
ERROR - 2011-05-25 16:53:23 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-05-25 16:53:36 --> Config Class Initialized
DEBUG - 2011-05-25 16:53:36 --> Hooks Class Initialized
DEBUG - 2011-05-25 16:53:36 --> Utf8 Class Initialized
DEBUG - 2011-05-25 16:53:36 --> UTF-8 Support Enabled
DEBUG - 2011-05-25 16:53:36 --> URI Class Initialized
DEBUG - 2011-05-25 16:53:36 --> Router Class Initialized
DEBUG - 2011-05-25 16:53:36 --> Output Class Initialized
DEBUG - 2011-05-25 16:53:36 --> Input Class Initialized
DEBUG - 2011-05-25 16:53:36 --> Global POST and COOKIE data sanitized
DEBUG - 2011-05-25 16:53:36 --> Language Class Initialized
DEBUG - 2011-05-25 16:53:36 --> Loader Class Initialized
DEBUG - 2011-05-25 16:53:36 --> Controller Class Initialized
ERROR - 2011-05-25 16:53:36 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-05-25 16:53:36 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-05-25 16:53:36 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-05-25 16:53:36 --> Model Class Initialized
DEBUG - 2011-05-25 16:53:36 --> Model Class Initialized
DEBUG - 2011-05-25 16:53:36 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-05-25 16:53:36 --> Database Driver Class Initialized
DEBUG - 2011-05-25 16:53:36 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-05-25 16:53:36 --> Helper loaded: url_helper
DEBUG - 2011-05-25 16:53:36 --> File loaded: application/views/common/header.php
DEBUG - 2011-05-25 16:53:36 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-05-25 16:53:36 --> File loaded: application/views/common/footer.php
DEBUG - 2011-05-25 16:53:36 --> File loaded: application/views/layout/main.php
DEBUG - 2011-05-25 16:53:36 --> Final output sent to browser
DEBUG - 2011-05-25 16:53:36 --> Total execution time: 0.0285
DEBUG - 2011-05-25 16:53:37 --> Config Class Initialized
DEBUG - 2011-05-25 16:53:37 --> Hooks Class Initialized
DEBUG - 2011-05-25 16:53:37 --> Utf8 Class Initialized
DEBUG - 2011-05-25 16:53:37 --> UTF-8 Support Enabled
DEBUG - 2011-05-25 16:53:37 --> URI Class Initialized
DEBUG - 2011-05-25 16:53:37 --> Router Class Initialized
DEBUG - 2011-05-25 16:53:37 --> Output Class Initialized
DEBUG - 2011-05-25 16:53:37 --> Input Class Initialized
DEBUG - 2011-05-25 16:53:37 --> Global POST and COOKIE data sanitized
DEBUG - 2011-05-25 16:53:37 --> Language Class Initialized
DEBUG - 2011-05-25 16:53:37 --> Loader Class Initialized
DEBUG - 2011-05-25 16:53:37 --> Controller Class Initialized
ERROR - 2011-05-25 16:53:37 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-05-25 16:53:37 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-05-25 16:53:37 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-05-25 16:53:37 --> Model Class Initialized
DEBUG - 2011-05-25 16:53:37 --> Model Class Initialized
DEBUG - 2011-05-25 16:53:37 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-05-25 16:53:37 --> Database Driver Class Initialized
DEBUG - 2011-05-25 16:53:37 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-05-25 16:53:37 --> Helper loaded: url_helper
DEBUG - 2011-05-25 16:53:37 --> File loaded: application/views/common/header.php
DEBUG - 2011-05-25 16:53:37 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-05-25 16:53:37 --> File loaded: application/views/common/footer.php
DEBUG - 2011-05-25 16:53:37 --> File loaded: application/views/layout/main.php
DEBUG - 2011-05-25 16:53:37 --> Final output sent to browser
DEBUG - 2011-05-25 16:53:37 --> Total execution time: 0.0272
DEBUG - 2011-05-25 16:53:38 --> Config Class Initialized
DEBUG - 2011-05-25 16:53:38 --> Hooks Class Initialized
DEBUG - 2011-05-25 16:53:38 --> Utf8 Class Initialized
DEBUG - 2011-05-25 16:53:38 --> UTF-8 Support Enabled
DEBUG - 2011-05-25 16:53:38 --> URI Class Initialized
DEBUG - 2011-05-25 16:53:38 --> Router Class Initialized
DEBUG - 2011-05-25 16:53:38 --> Output Class Initialized
DEBUG - 2011-05-25 16:53:38 --> Input Class Initialized
DEBUG - 2011-05-25 16:53:38 --> Global POST and COOKIE data sanitized
DEBUG - 2011-05-25 16:53:38 --> Language Class Initialized
DEBUG - 2011-05-25 16:53:38 --> Loader Class Initialized
DEBUG - 2011-05-25 16:53:38 --> Controller Class Initialized
DEBUG - 2011-05-25 16:53:38 --> Model Class Initialized
DEBUG - 2011-05-25 16:53:38 --> Model Class Initialized
DEBUG - 2011-05-25 16:53:38 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-05-25 16:53:38 --> Database Driver Class Initialized
DEBUG - 2011-05-25 16:53:38 --> Final output sent to browser
DEBUG - 2011-05-25 16:53:38 --> Total execution time: 0.5466
DEBUG - 2011-05-25 16:53:40 --> Config Class Initialized
DEBUG - 2011-05-25 16:53:40 --> Hooks Class Initialized
DEBUG - 2011-05-25 16:53:40 --> Utf8 Class Initialized
DEBUG - 2011-05-25 16:53:40 --> UTF-8 Support Enabled
DEBUG - 2011-05-25 16:53:40 --> URI Class Initialized
DEBUG - 2011-05-25 16:53:40 --> Router Class Initialized
ERROR - 2011-05-25 16:53:40 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-05-25 16:53:50 --> Config Class Initialized
DEBUG - 2011-05-25 16:53:50 --> Hooks Class Initialized
DEBUG - 2011-05-25 16:53:50 --> Utf8 Class Initialized
DEBUG - 2011-05-25 16:53:50 --> UTF-8 Support Enabled
DEBUG - 2011-05-25 16:53:50 --> URI Class Initialized
DEBUG - 2011-05-25 16:53:50 --> Router Class Initialized
DEBUG - 2011-05-25 16:53:50 --> Output Class Initialized
DEBUG - 2011-05-25 16:53:50 --> Input Class Initialized
DEBUG - 2011-05-25 16:53:50 --> Global POST and COOKIE data sanitized
DEBUG - 2011-05-25 16:53:50 --> Language Class Initialized
DEBUG - 2011-05-25 16:53:50 --> Loader Class Initialized
DEBUG - 2011-05-25 16:53:50 --> Controller Class Initialized
ERROR - 2011-05-25 16:53:50 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-05-25 16:53:50 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-05-25 16:53:50 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-05-25 16:53:50 --> Model Class Initialized
DEBUG - 2011-05-25 16:53:50 --> Model Class Initialized
DEBUG - 2011-05-25 16:53:50 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-05-25 16:53:50 --> Database Driver Class Initialized
DEBUG - 2011-05-25 16:53:50 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-05-25 16:53:50 --> Helper loaded: url_helper
DEBUG - 2011-05-25 16:53:50 --> File loaded: application/views/common/header.php
DEBUG - 2011-05-25 16:53:50 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-05-25 16:53:50 --> File loaded: application/views/common/footer.php
DEBUG - 2011-05-25 16:53:50 --> File loaded: application/views/layout/main.php
DEBUG - 2011-05-25 16:53:50 --> Final output sent to browser
DEBUG - 2011-05-25 16:53:50 --> Total execution time: 0.0294
DEBUG - 2011-05-25 16:53:51 --> Config Class Initialized
DEBUG - 2011-05-25 16:53:51 --> Hooks Class Initialized
DEBUG - 2011-05-25 16:53:51 --> Utf8 Class Initialized
DEBUG - 2011-05-25 16:53:51 --> UTF-8 Support Enabled
DEBUG - 2011-05-25 16:53:51 --> URI Class Initialized
DEBUG - 2011-05-25 16:53:51 --> Router Class Initialized
DEBUG - 2011-05-25 16:53:51 --> Output Class Initialized
DEBUG - 2011-05-25 16:53:51 --> Input Class Initialized
DEBUG - 2011-05-25 16:53:51 --> Global POST and COOKIE data sanitized
DEBUG - 2011-05-25 16:53:51 --> Language Class Initialized
DEBUG - 2011-05-25 16:53:51 --> Loader Class Initialized
DEBUG - 2011-05-25 16:53:51 --> Controller Class Initialized
DEBUG - 2011-05-25 16:53:51 --> Model Class Initialized
DEBUG - 2011-05-25 16:53:51 --> Model Class Initialized
DEBUG - 2011-05-25 16:53:51 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-05-25 16:53:51 --> Database Driver Class Initialized
DEBUG - 2011-05-25 16:53:51 --> Final output sent to browser
DEBUG - 2011-05-25 16:53:51 --> Total execution time: 0.6724
DEBUG - 2011-05-25 16:53:53 --> Config Class Initialized
DEBUG - 2011-05-25 16:53:53 --> Hooks Class Initialized
DEBUG - 2011-05-25 16:53:53 --> Utf8 Class Initialized
DEBUG - 2011-05-25 16:53:53 --> UTF-8 Support Enabled
DEBUG - 2011-05-25 16:53:53 --> URI Class Initialized
DEBUG - 2011-05-25 16:53:53 --> Router Class Initialized
ERROR - 2011-05-25 16:53:53 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-05-25 16:54:07 --> Config Class Initialized
DEBUG - 2011-05-25 16:54:07 --> Hooks Class Initialized
DEBUG - 2011-05-25 16:54:07 --> Utf8 Class Initialized
DEBUG - 2011-05-25 16:54:07 --> UTF-8 Support Enabled
DEBUG - 2011-05-25 16:54:07 --> URI Class Initialized
DEBUG - 2011-05-25 16:54:07 --> Router Class Initialized
DEBUG - 2011-05-25 16:54:07 --> Output Class Initialized
DEBUG - 2011-05-25 16:54:07 --> Input Class Initialized
DEBUG - 2011-05-25 16:54:07 --> Global POST and COOKIE data sanitized
DEBUG - 2011-05-25 16:54:07 --> Language Class Initialized
DEBUG - 2011-05-25 16:54:07 --> Loader Class Initialized
DEBUG - 2011-05-25 16:54:07 --> Controller Class Initialized
ERROR - 2011-05-25 16:54:07 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-05-25 16:54:07 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-05-25 16:54:07 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-05-25 16:54:07 --> Model Class Initialized
DEBUG - 2011-05-25 16:54:07 --> Model Class Initialized
DEBUG - 2011-05-25 16:54:07 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-05-25 16:54:07 --> Database Driver Class Initialized
DEBUG - 2011-05-25 16:54:07 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-05-25 16:54:07 --> Helper loaded: url_helper
DEBUG - 2011-05-25 16:54:07 --> File loaded: application/views/common/header.php
DEBUG - 2011-05-25 16:54:07 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-05-25 16:54:07 --> File loaded: application/views/common/footer.php
DEBUG - 2011-05-25 16:54:07 --> File loaded: application/views/layout/main.php
DEBUG - 2011-05-25 16:54:07 --> Final output sent to browser
DEBUG - 2011-05-25 16:54:07 --> Total execution time: 0.0294
DEBUG - 2011-05-25 16:54:08 --> Config Class Initialized
DEBUG - 2011-05-25 16:54:08 --> Hooks Class Initialized
DEBUG - 2011-05-25 16:54:08 --> Utf8 Class Initialized
DEBUG - 2011-05-25 16:54:08 --> UTF-8 Support Enabled
DEBUG - 2011-05-25 16:54:08 --> URI Class Initialized
DEBUG - 2011-05-25 16:54:08 --> Router Class Initialized
DEBUG - 2011-05-25 16:54:08 --> Output Class Initialized
DEBUG - 2011-05-25 16:54:08 --> Input Class Initialized
DEBUG - 2011-05-25 16:54:08 --> Global POST and COOKIE data sanitized
DEBUG - 2011-05-25 16:54:08 --> Language Class Initialized
DEBUG - 2011-05-25 16:54:08 --> Loader Class Initialized
DEBUG - 2011-05-25 16:54:08 --> Controller Class Initialized
DEBUG - 2011-05-25 16:54:08 --> Model Class Initialized
DEBUG - 2011-05-25 16:54:08 --> Model Class Initialized
DEBUG - 2011-05-25 16:54:08 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-05-25 16:54:08 --> Database Driver Class Initialized
DEBUG - 2011-05-25 16:54:09 --> Final output sent to browser
DEBUG - 2011-05-25 16:54:09 --> Total execution time: 0.7671
DEBUG - 2011-05-25 16:54:11 --> Config Class Initialized
DEBUG - 2011-05-25 16:54:11 --> Hooks Class Initialized
DEBUG - 2011-05-25 16:54:11 --> Utf8 Class Initialized
DEBUG - 2011-05-25 16:54:11 --> UTF-8 Support Enabled
DEBUG - 2011-05-25 16:54:11 --> URI Class Initialized
DEBUG - 2011-05-25 16:54:11 --> Router Class Initialized
ERROR - 2011-05-25 16:54:11 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-05-25 17:00:34 --> Config Class Initialized
DEBUG - 2011-05-25 17:00:34 --> Hooks Class Initialized
DEBUG - 2011-05-25 17:00:34 --> Utf8 Class Initialized
DEBUG - 2011-05-25 17:00:34 --> UTF-8 Support Enabled
DEBUG - 2011-05-25 17:00:34 --> URI Class Initialized
DEBUG - 2011-05-25 17:00:34 --> Router Class Initialized
DEBUG - 2011-05-25 17:00:34 --> Output Class Initialized
DEBUG - 2011-05-25 17:00:34 --> Input Class Initialized
DEBUG - 2011-05-25 17:00:34 --> Global POST and COOKIE data sanitized
DEBUG - 2011-05-25 17:00:34 --> Language Class Initialized
DEBUG - 2011-05-25 17:00:34 --> Loader Class Initialized
DEBUG - 2011-05-25 17:00:34 --> Controller Class Initialized
ERROR - 2011-05-25 17:00:34 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-05-25 17:00:34 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-05-25 17:00:34 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-05-25 17:00:34 --> Model Class Initialized
DEBUG - 2011-05-25 17:00:34 --> Model Class Initialized
DEBUG - 2011-05-25 17:00:34 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-05-25 17:00:34 --> Database Driver Class Initialized
DEBUG - 2011-05-25 17:00:34 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-05-25 17:00:34 --> Helper loaded: url_helper
DEBUG - 2011-05-25 17:00:34 --> File loaded: application/views/common/header.php
DEBUG - 2011-05-25 17:00:34 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-05-25 17:00:34 --> File loaded: application/views/common/footer.php
DEBUG - 2011-05-25 17:00:34 --> File loaded: application/views/layout/main.php
DEBUG - 2011-05-25 17:00:34 --> Final output sent to browser
DEBUG - 2011-05-25 17:00:34 --> Total execution time: 0.0276
DEBUG - 2011-05-25 17:00:35 --> Config Class Initialized
DEBUG - 2011-05-25 17:00:35 --> Hooks Class Initialized
DEBUG - 2011-05-25 17:00:35 --> Utf8 Class Initialized
DEBUG - 2011-05-25 17:00:35 --> UTF-8 Support Enabled
DEBUG - 2011-05-25 17:00:35 --> URI Class Initialized
DEBUG - 2011-05-25 17:00:35 --> Router Class Initialized
DEBUG - 2011-05-25 17:00:35 --> Output Class Initialized
DEBUG - 2011-05-25 17:00:35 --> Input Class Initialized
DEBUG - 2011-05-25 17:00:35 --> Global POST and COOKIE data sanitized
DEBUG - 2011-05-25 17:00:35 --> Language Class Initialized
DEBUG - 2011-05-25 17:00:35 --> Loader Class Initialized
DEBUG - 2011-05-25 17:00:35 --> Controller Class Initialized
DEBUG - 2011-05-25 17:00:35 --> Model Class Initialized
DEBUG - 2011-05-25 17:00:35 --> Model Class Initialized
DEBUG - 2011-05-25 17:00:35 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-05-25 17:00:35 --> Database Driver Class Initialized
DEBUG - 2011-05-25 17:00:36 --> Final output sent to browser
DEBUG - 2011-05-25 17:00:36 --> Total execution time: 0.5488
DEBUG - 2011-05-25 17:00:37 --> Config Class Initialized
DEBUG - 2011-05-25 17:00:37 --> Hooks Class Initialized
DEBUG - 2011-05-25 17:00:37 --> Utf8 Class Initialized
DEBUG - 2011-05-25 17:00:37 --> UTF-8 Support Enabled
DEBUG - 2011-05-25 17:00:37 --> URI Class Initialized
DEBUG - 2011-05-25 17:00:37 --> Router Class Initialized
ERROR - 2011-05-25 17:00:37 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-05-25 17:00:49 --> Config Class Initialized
DEBUG - 2011-05-25 17:00:49 --> Hooks Class Initialized
DEBUG - 2011-05-25 17:00:49 --> Utf8 Class Initialized
DEBUG - 2011-05-25 17:00:49 --> UTF-8 Support Enabled
DEBUG - 2011-05-25 17:00:49 --> URI Class Initialized
DEBUG - 2011-05-25 17:00:49 --> Router Class Initialized
DEBUG - 2011-05-25 17:00:49 --> Output Class Initialized
DEBUG - 2011-05-25 17:00:49 --> Input Class Initialized
DEBUG - 2011-05-25 17:00:49 --> Global POST and COOKIE data sanitized
DEBUG - 2011-05-25 17:00:49 --> Language Class Initialized
DEBUG - 2011-05-25 17:00:49 --> Loader Class Initialized
DEBUG - 2011-05-25 17:00:49 --> Controller Class Initialized
ERROR - 2011-05-25 17:00:49 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-05-25 17:00:49 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-05-25 17:00:49 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-05-25 17:00:49 --> Model Class Initialized
DEBUG - 2011-05-25 17:00:49 --> Model Class Initialized
DEBUG - 2011-05-25 17:00:49 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-05-25 17:00:49 --> Database Driver Class Initialized
DEBUG - 2011-05-25 17:00:49 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-05-25 17:00:49 --> Helper loaded: url_helper
DEBUG - 2011-05-25 17:00:49 --> File loaded: application/views/common/header.php
DEBUG - 2011-05-25 17:00:49 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-05-25 17:00:49 --> File loaded: application/views/common/footer.php
DEBUG - 2011-05-25 17:00:49 --> File loaded: application/views/layout/main.php
DEBUG - 2011-05-25 17:00:49 --> Final output sent to browser
DEBUG - 2011-05-25 17:00:49 --> Total execution time: 0.0291
DEBUG - 2011-05-25 17:00:50 --> Config Class Initialized
DEBUG - 2011-05-25 17:00:50 --> Hooks Class Initialized
DEBUG - 2011-05-25 17:00:50 --> Utf8 Class Initialized
DEBUG - 2011-05-25 17:00:50 --> UTF-8 Support Enabled
DEBUG - 2011-05-25 17:00:50 --> URI Class Initialized
DEBUG - 2011-05-25 17:00:50 --> Router Class Initialized
DEBUG - 2011-05-25 17:00:50 --> Output Class Initialized
DEBUG - 2011-05-25 17:00:50 --> Input Class Initialized
DEBUG - 2011-05-25 17:00:50 --> Global POST and COOKIE data sanitized
DEBUG - 2011-05-25 17:00:50 --> Language Class Initialized
DEBUG - 2011-05-25 17:00:50 --> Loader Class Initialized
DEBUG - 2011-05-25 17:00:50 --> Controller Class Initialized
ERROR - 2011-05-25 17:00:50 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-05-25 17:00:50 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-05-25 17:00:50 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-05-25 17:00:50 --> Model Class Initialized
DEBUG - 2011-05-25 17:00:50 --> Model Class Initialized
DEBUG - 2011-05-25 17:00:50 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-05-25 17:00:50 --> Database Driver Class Initialized
DEBUG - 2011-05-25 17:00:50 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-05-25 17:00:50 --> Helper loaded: url_helper
DEBUG - 2011-05-25 17:00:50 --> File loaded: application/views/common/header.php
DEBUG - 2011-05-25 17:00:50 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-05-25 17:00:50 --> File loaded: application/views/common/footer.php
DEBUG - 2011-05-25 17:00:50 --> File loaded: application/views/layout/main.php
DEBUG - 2011-05-25 17:00:50 --> Final output sent to browser
DEBUG - 2011-05-25 17:00:50 --> Total execution time: 0.0363
DEBUG - 2011-05-25 17:00:50 --> Config Class Initialized
DEBUG - 2011-05-25 17:00:50 --> Hooks Class Initialized
DEBUG - 2011-05-25 17:00:50 --> Utf8 Class Initialized
DEBUG - 2011-05-25 17:00:50 --> UTF-8 Support Enabled
DEBUG - 2011-05-25 17:00:50 --> URI Class Initialized
DEBUG - 2011-05-25 17:00:50 --> Router Class Initialized
DEBUG - 2011-05-25 17:00:50 --> Output Class Initialized
DEBUG - 2011-05-25 17:00:50 --> Input Class Initialized
DEBUG - 2011-05-25 17:00:50 --> Global POST and COOKIE data sanitized
DEBUG - 2011-05-25 17:00:50 --> Language Class Initialized
DEBUG - 2011-05-25 17:00:50 --> Loader Class Initialized
DEBUG - 2011-05-25 17:00:50 --> Controller Class Initialized
DEBUG - 2011-05-25 17:00:50 --> Model Class Initialized
DEBUG - 2011-05-25 17:00:50 --> Model Class Initialized
DEBUG - 2011-05-25 17:00:50 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-05-25 17:00:50 --> Database Driver Class Initialized
DEBUG - 2011-05-25 17:00:50 --> Config Class Initialized
DEBUG - 2011-05-25 17:00:50 --> Hooks Class Initialized
DEBUG - 2011-05-25 17:00:50 --> Utf8 Class Initialized
DEBUG - 2011-05-25 17:00:50 --> UTF-8 Support Enabled
DEBUG - 2011-05-25 17:00:50 --> URI Class Initialized
DEBUG - 2011-05-25 17:00:50 --> Router Class Initialized
DEBUG - 2011-05-25 17:00:50 --> Output Class Initialized
DEBUG - 2011-05-25 17:00:50 --> Input Class Initialized
DEBUG - 2011-05-25 17:00:50 --> Global POST and COOKIE data sanitized
DEBUG - 2011-05-25 17:00:50 --> Language Class Initialized
DEBUG - 2011-05-25 17:00:50 --> Loader Class Initialized
DEBUG - 2011-05-25 17:00:50 --> Controller Class Initialized
ERROR - 2011-05-25 17:00:50 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-05-25 17:00:50 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-05-25 17:00:50 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-05-25 17:00:50 --> Model Class Initialized
DEBUG - 2011-05-25 17:00:50 --> Model Class Initialized
DEBUG - 2011-05-25 17:00:50 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-05-25 17:00:51 --> Database Driver Class Initialized
DEBUG - 2011-05-25 17:00:51 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-05-25 17:00:51 --> Helper loaded: url_helper
DEBUG - 2011-05-25 17:00:51 --> File loaded: application/views/common/header.php
DEBUG - 2011-05-25 17:00:51 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-05-25 17:00:51 --> File loaded: application/views/common/footer.php
DEBUG - 2011-05-25 17:00:51 --> File loaded: application/views/layout/main.php
DEBUG - 2011-05-25 17:00:51 --> Final output sent to browser
DEBUG - 2011-05-25 17:00:51 --> Total execution time: 0.0675
DEBUG - 2011-05-25 17:00:51 --> Final output sent to browser
DEBUG - 2011-05-25 17:00:51 --> Total execution time: 0.6573
DEBUG - 2011-05-25 17:00:53 --> Config Class Initialized
DEBUG - 2011-05-25 17:00:53 --> Hooks Class Initialized
DEBUG - 2011-05-25 17:00:53 --> Utf8 Class Initialized
DEBUG - 2011-05-25 17:00:53 --> UTF-8 Support Enabled
DEBUG - 2011-05-25 17:00:53 --> URI Class Initialized
DEBUG - 2011-05-25 17:00:53 --> Router Class Initialized
ERROR - 2011-05-25 17:00:53 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-05-25 17:31:40 --> Config Class Initialized
DEBUG - 2011-05-25 17:31:40 --> Hooks Class Initialized
DEBUG - 2011-05-25 17:31:40 --> Utf8 Class Initialized
DEBUG - 2011-05-25 17:31:40 --> UTF-8 Support Enabled
DEBUG - 2011-05-25 17:31:40 --> URI Class Initialized
DEBUG - 2011-05-25 17:31:40 --> Router Class Initialized
DEBUG - 2011-05-25 17:31:40 --> Output Class Initialized
DEBUG - 2011-05-25 17:31:40 --> Input Class Initialized
DEBUG - 2011-05-25 17:31:40 --> Global POST and COOKIE data sanitized
DEBUG - 2011-05-25 17:31:40 --> Language Class Initialized
DEBUG - 2011-05-25 17:31:40 --> Loader Class Initialized
DEBUG - 2011-05-25 17:31:40 --> Controller Class Initialized
DEBUG - 2011-05-25 17:31:40 --> Model Class Initialized
DEBUG - 2011-05-25 17:31:40 --> Model Class Initialized
DEBUG - 2011-05-25 17:31:40 --> Model Class Initialized
DEBUG - 2011-05-25 17:31:40 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-05-25 17:31:40 --> Database Driver Class Initialized
DEBUG - 2011-05-25 17:31:41 --> File loaded: application/views/table/main.php
DEBUG - 2011-05-25 17:31:41 --> Helper loaded: url_helper
DEBUG - 2011-05-25 17:31:41 --> File loaded: application/views/common/header.php
DEBUG - 2011-05-25 17:31:41 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-05-25 17:31:41 --> File loaded: application/views/common/footer.php
DEBUG - 2011-05-25 17:31:41 --> File loaded: application/views/layout/main.php
DEBUG - 2011-05-25 17:31:41 --> Final output sent to browser
DEBUG - 2011-05-25 17:31:41 --> Total execution time: 0.4487
DEBUG - 2011-05-25 17:31:42 --> Config Class Initialized
DEBUG - 2011-05-25 17:31:42 --> Hooks Class Initialized
DEBUG - 2011-05-25 17:31:42 --> Utf8 Class Initialized
DEBUG - 2011-05-25 17:31:42 --> UTF-8 Support Enabled
DEBUG - 2011-05-25 17:31:42 --> URI Class Initialized
DEBUG - 2011-05-25 17:31:42 --> Router Class Initialized
ERROR - 2011-05-25 17:31:42 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-05-25 17:31:42 --> Config Class Initialized
DEBUG - 2011-05-25 17:31:42 --> Hooks Class Initialized
DEBUG - 2011-05-25 17:31:42 --> Utf8 Class Initialized
DEBUG - 2011-05-25 17:31:42 --> UTF-8 Support Enabled
DEBUG - 2011-05-25 17:31:42 --> URI Class Initialized
DEBUG - 2011-05-25 17:31:42 --> Router Class Initialized
ERROR - 2011-05-25 17:31:42 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-05-25 17:31:42 --> Config Class Initialized
DEBUG - 2011-05-25 17:31:42 --> Hooks Class Initialized
DEBUG - 2011-05-25 17:31:42 --> Utf8 Class Initialized
DEBUG - 2011-05-25 17:31:42 --> UTF-8 Support Enabled
DEBUG - 2011-05-25 17:31:42 --> URI Class Initialized
DEBUG - 2011-05-25 17:31:42 --> Router Class Initialized
ERROR - 2011-05-25 17:31:42 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-05-25 19:05:13 --> Config Class Initialized
DEBUG - 2011-05-25 19:05:14 --> Hooks Class Initialized
DEBUG - 2011-05-25 19:05:14 --> Utf8 Class Initialized
DEBUG - 2011-05-25 19:05:14 --> UTF-8 Support Enabled
DEBUG - 2011-05-25 19:05:14 --> URI Class Initialized
DEBUG - 2011-05-25 19:05:14 --> Router Class Initialized
DEBUG - 2011-05-25 19:05:14 --> Output Class Initialized
DEBUG - 2011-05-25 19:05:14 --> Input Class Initialized
DEBUG - 2011-05-25 19:05:14 --> Global POST and COOKIE data sanitized
DEBUG - 2011-05-25 19:05:14 --> Language Class Initialized
DEBUG - 2011-05-25 19:05:14 --> Loader Class Initialized
DEBUG - 2011-05-25 19:05:14 --> Controller Class Initialized
DEBUG - 2011-05-25 19:05:15 --> Model Class Initialized
DEBUG - 2011-05-25 19:05:15 --> Model Class Initialized
DEBUG - 2011-05-25 19:05:15 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-05-25 19:05:16 --> Database Driver Class Initialized
DEBUG - 2011-05-25 19:05:16 --> Final output sent to browser
DEBUG - 2011-05-25 19:05:16 --> Total execution time: 3.1851
DEBUG - 2011-05-25 21:22:04 --> Config Class Initialized
DEBUG - 2011-05-25 21:22:04 --> Hooks Class Initialized
DEBUG - 2011-05-25 21:22:04 --> Utf8 Class Initialized
DEBUG - 2011-05-25 21:22:04 --> UTF-8 Support Enabled
DEBUG - 2011-05-25 21:22:04 --> URI Class Initialized
DEBUG - 2011-05-25 21:22:04 --> Router Class Initialized
ERROR - 2011-05-25 21:22:04 --> 404 Page Not Found --> robots.txt
DEBUG - 2011-05-25 21:22:05 --> Config Class Initialized
DEBUG - 2011-05-25 21:22:05 --> Hooks Class Initialized
DEBUG - 2011-05-25 21:22:05 --> Utf8 Class Initialized
DEBUG - 2011-05-25 21:22:05 --> UTF-8 Support Enabled
DEBUG - 2011-05-25 21:22:05 --> URI Class Initialized
DEBUG - 2011-05-25 21:22:05 --> Router Class Initialized
DEBUG - 2011-05-25 21:22:05 --> Output Class Initialized
DEBUG - 2011-05-25 21:22:05 --> Input Class Initialized
DEBUG - 2011-05-25 21:22:05 --> Global POST and COOKIE data sanitized
DEBUG - 2011-05-25 21:22:05 --> Language Class Initialized
DEBUG - 2011-05-25 21:22:05 --> Loader Class Initialized
DEBUG - 2011-05-25 21:22:05 --> Controller Class Initialized
ERROR - 2011-05-25 21:22:05 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-05-25 21:22:05 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-05-25 21:22:05 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-05-25 21:22:05 --> Model Class Initialized
DEBUG - 2011-05-25 21:22:05 --> Model Class Initialized
DEBUG - 2011-05-25 21:22:05 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-05-25 21:22:06 --> Database Driver Class Initialized
DEBUG - 2011-05-25 21:22:06 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-05-25 21:22:06 --> Helper loaded: url_helper
DEBUG - 2011-05-25 21:22:06 --> File loaded: application/views/common/header.php
DEBUG - 2011-05-25 21:22:06 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-05-25 21:22:06 --> File loaded: application/views/common/footer.php
DEBUG - 2011-05-25 21:22:06 --> File loaded: application/views/layout/main.php
DEBUG - 2011-05-25 21:22:06 --> Final output sent to browser
DEBUG - 2011-05-25 21:22:06 --> Total execution time: 0.2793
DEBUG - 2011-05-25 21:22:11 --> Config Class Initialized
DEBUG - 2011-05-25 21:22:11 --> Hooks Class Initialized
DEBUG - 2011-05-25 21:22:11 --> Utf8 Class Initialized
DEBUG - 2011-05-25 21:22:11 --> UTF-8 Support Enabled
DEBUG - 2011-05-25 21:22:11 --> URI Class Initialized
DEBUG - 2011-05-25 21:22:11 --> Router Class Initialized
DEBUG - 2011-05-25 21:22:11 --> Output Class Initialized
DEBUG - 2011-05-25 21:22:11 --> Input Class Initialized
DEBUG - 2011-05-25 21:22:11 --> Global POST and COOKIE data sanitized
DEBUG - 2011-05-25 21:22:11 --> Language Class Initialized
DEBUG - 2011-05-25 21:22:11 --> Loader Class Initialized
DEBUG - 2011-05-25 21:22:11 --> Controller Class Initialized
DEBUG - 2011-05-25 21:22:11 --> Model Class Initialized
DEBUG - 2011-05-25 21:22:11 --> Model Class Initialized
DEBUG - 2011-05-25 21:22:11 --> Model Class Initialized
DEBUG - 2011-05-25 21:22:11 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-05-25 21:22:11 --> Database Driver Class Initialized
DEBUG - 2011-05-25 21:22:11 --> File loaded: application/views/table/main.php
DEBUG - 2011-05-25 21:22:11 --> Helper loaded: url_helper
DEBUG - 2011-05-25 21:22:11 --> File loaded: application/views/common/header.php
DEBUG - 2011-05-25 21:22:11 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-05-25 21:22:11 --> File loaded: application/views/common/footer.php
DEBUG - 2011-05-25 21:22:11 --> File loaded: application/views/layout/main.php
DEBUG - 2011-05-25 21:22:11 --> Final output sent to browser
DEBUG - 2011-05-25 21:22:11 --> Total execution time: 0.5670
DEBUG - 2011-05-25 21:48:14 --> Config Class Initialized
DEBUG - 2011-05-25 21:48:14 --> Hooks Class Initialized
DEBUG - 2011-05-25 21:48:14 --> Utf8 Class Initialized
DEBUG - 2011-05-25 21:48:14 --> UTF-8 Support Enabled
DEBUG - 2011-05-25 21:48:14 --> URI Class Initialized
DEBUG - 2011-05-25 21:48:14 --> Router Class Initialized
ERROR - 2011-05-25 21:48:14 --> 404 Page Not Found --> robots.txt
DEBUG - 2011-05-25 21:48:14 --> Config Class Initialized
DEBUG - 2011-05-25 21:48:14 --> Hooks Class Initialized
DEBUG - 2011-05-25 21:48:14 --> Utf8 Class Initialized
DEBUG - 2011-05-25 21:48:14 --> UTF-8 Support Enabled
DEBUG - 2011-05-25 21:48:14 --> URI Class Initialized
DEBUG - 2011-05-25 21:48:14 --> Router Class Initialized
DEBUG - 2011-05-25 21:48:14 --> Output Class Initialized
DEBUG - 2011-05-25 21:48:14 --> Input Class Initialized
DEBUG - 2011-05-25 21:48:14 --> Global POST and COOKIE data sanitized
DEBUG - 2011-05-25 21:48:14 --> Language Class Initialized
DEBUG - 2011-05-25 21:48:14 --> Loader Class Initialized
DEBUG - 2011-05-25 21:48:14 --> Controller Class Initialized
ERROR - 2011-05-25 21:48:14 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-05-25 21:48:14 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-05-25 21:48:14 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-05-25 21:48:14 --> Model Class Initialized
DEBUG - 2011-05-25 21:48:14 --> Model Class Initialized
DEBUG - 2011-05-25 21:48:14 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-05-25 21:48:14 --> Database Driver Class Initialized
DEBUG - 2011-05-25 21:48:14 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-05-25 21:48:14 --> Helper loaded: url_helper
DEBUG - 2011-05-25 21:48:14 --> File loaded: application/views/common/header.php
DEBUG - 2011-05-25 21:48:14 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-05-25 21:48:14 --> File loaded: application/views/common/footer.php
DEBUG - 2011-05-25 21:48:14 --> File loaded: application/views/layout/main.php
DEBUG - 2011-05-25 21:48:14 --> Final output sent to browser
DEBUG - 2011-05-25 21:48:14 --> Total execution time: 0.3197
DEBUG - 2011-05-25 22:18:17 --> Config Class Initialized
DEBUG - 2011-05-25 22:18:17 --> Hooks Class Initialized
DEBUG - 2011-05-25 22:18:17 --> Utf8 Class Initialized
DEBUG - 2011-05-25 22:18:17 --> UTF-8 Support Enabled
DEBUG - 2011-05-25 22:18:17 --> URI Class Initialized
DEBUG - 2011-05-25 22:18:17 --> Router Class Initialized
DEBUG - 2011-05-25 22:18:17 --> No URI present. Default controller set.
DEBUG - 2011-05-25 22:18:17 --> Output Class Initialized
DEBUG - 2011-05-25 22:18:17 --> Input Class Initialized
DEBUG - 2011-05-25 22:18:17 --> Global POST and COOKIE data sanitized
DEBUG - 2011-05-25 22:18:17 --> Language Class Initialized
DEBUG - 2011-05-25 22:18:17 --> Loader Class Initialized
DEBUG - 2011-05-25 22:18:17 --> Controller Class Initialized
DEBUG - 2011-05-25 22:18:17 --> File loaded: application/views/splash/main.php
DEBUG - 2011-05-25 22:18:17 --> Helper loaded: url_helper
DEBUG - 2011-05-25 22:18:17 --> File loaded: application/views/common/header.php
DEBUG - 2011-05-25 22:18:17 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-05-25 22:18:17 --> File loaded: application/views/common/footer.php
DEBUG - 2011-05-25 22:18:17 --> File loaded: application/views/layout/main.php
DEBUG - 2011-05-25 22:18:17 --> Final output sent to browser
DEBUG - 2011-05-25 22:18:17 --> Total execution time: 0.2448
DEBUG - 2011-05-25 23:17:05 --> Config Class Initialized
DEBUG - 2011-05-25 23:17:05 --> Config Class Initialized
DEBUG - 2011-05-25 23:17:05 --> Hooks Class Initialized
DEBUG - 2011-05-25 23:17:05 --> Hooks Class Initialized
DEBUG - 2011-05-25 23:17:05 --> Utf8 Class Initialized
DEBUG - 2011-05-25 23:17:05 --> UTF-8 Support Enabled
DEBUG - 2011-05-25 23:17:05 --> Utf8 Class Initialized
DEBUG - 2011-05-25 23:17:05 --> UTF-8 Support Enabled
DEBUG - 2011-05-25 23:17:05 --> URI Class Initialized
DEBUG - 2011-05-25 23:17:05 --> URI Class Initialized
DEBUG - 2011-05-25 23:17:05 --> Router Class Initialized
DEBUG - 2011-05-25 23:17:05 --> Router Class Initialized
DEBUG - 2011-05-25 23:17:05 --> Output Class Initialized
DEBUG - 2011-05-25 23:17:05 --> Output Class Initialized
DEBUG - 2011-05-25 23:17:05 --> Input Class Initialized
DEBUG - 2011-05-25 23:17:05 --> Global POST and COOKIE data sanitized
DEBUG - 2011-05-25 23:17:05 --> Language Class Initialized
DEBUG - 2011-05-25 23:17:05 --> Input Class Initialized
DEBUG - 2011-05-25 23:17:05 --> Global POST and COOKIE data sanitized
DEBUG - 2011-05-25 23:17:05 --> Language Class Initialized
DEBUG - 2011-05-25 23:17:05 --> Loader Class Initialized
DEBUG - 2011-05-25 23:17:05 --> Controller Class Initialized
DEBUG - 2011-05-25 23:17:05 --> Loader Class Initialized
DEBUG - 2011-05-25 23:17:05 --> Controller Class Initialized
DEBUG - 2011-05-25 23:17:05 --> Model Class Initialized
DEBUG - 2011-05-25 23:17:05 --> Model Class Initialized
DEBUG - 2011-05-25 23:17:05 --> Model Class Initialized
DEBUG - 2011-05-25 23:17:05 --> Database config for development environment is not found. Trying global config.
ERROR - 2011-05-25 23:17:05 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-05-25 23:17:05 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-05-25 23:17:05 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-05-25 23:17:05 --> Model Class Initialized
DEBUG - 2011-05-25 23:17:05 --> Model Class Initialized
DEBUG - 2011-05-25 23:17:05 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-05-25 23:17:05 --> Database Driver Class Initialized
DEBUG - 2011-05-25 23:17:05 --> Database Driver Class Initialized
DEBUG - 2011-05-25 23:17:05 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-05-25 23:17:05 --> Helper loaded: url_helper
DEBUG - 2011-05-25 23:17:05 --> File loaded: application/views/common/header.php
DEBUG - 2011-05-25 23:17:05 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-05-25 23:17:05 --> File loaded: application/views/common/footer.php
DEBUG - 2011-05-25 23:17:05 --> File loaded: application/views/layout/main.php
DEBUG - 2011-05-25 23:17:05 --> Final output sent to browser
DEBUG - 2011-05-25 23:17:05 --> Total execution time: 0.3241
DEBUG - 2011-05-25 23:17:05 --> File loaded: application/views/table/main.php
DEBUG - 2011-05-25 23:17:05 --> Helper loaded: url_helper
DEBUG - 2011-05-25 23:17:05 --> File loaded: application/views/common/header.php
DEBUG - 2011-05-25 23:17:05 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-05-25 23:17:05 --> File loaded: application/views/common/footer.php
DEBUG - 2011-05-25 23:17:05 --> File loaded: application/views/layout/main.php
DEBUG - 2011-05-25 23:17:05 --> Final output sent to browser
DEBUG - 2011-05-25 23:17:05 --> Total execution time: 0.4914
DEBUG - 2011-05-25 23:46:49 --> Config Class Initialized
DEBUG - 2011-05-25 23:46:49 --> Hooks Class Initialized
DEBUG - 2011-05-25 23:46:49 --> Utf8 Class Initialized
DEBUG - 2011-05-25 23:46:49 --> UTF-8 Support Enabled
DEBUG - 2011-05-25 23:46:49 --> URI Class Initialized
DEBUG - 2011-05-25 23:46:49 --> Router Class Initialized
DEBUG - 2011-05-25 23:46:49 --> Output Class Initialized
DEBUG - 2011-05-25 23:46:49 --> Input Class Initialized
DEBUG - 2011-05-25 23:46:49 --> Global POST and COOKIE data sanitized
DEBUG - 2011-05-25 23:46:49 --> Language Class Initialized
DEBUG - 2011-05-25 23:46:49 --> Loader Class Initialized
DEBUG - 2011-05-25 23:46:49 --> Controller Class Initialized
DEBUG - 2011-05-25 23:46:49 --> Model Class Initialized
DEBUG - 2011-05-25 23:46:49 --> Model Class Initialized
DEBUG - 2011-05-25 23:46:49 --> Model Class Initialized
DEBUG - 2011-05-25 23:46:49 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-05-25 23:46:49 --> Database Driver Class Initialized
DEBUG - 2011-05-25 23:46:49 --> File loaded: application/views/table/main.php
DEBUG - 2011-05-25 23:46:49 --> Helper loaded: url_helper
DEBUG - 2011-05-25 23:46:49 --> File loaded: application/views/common/header.php
DEBUG - 2011-05-25 23:46:49 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-05-25 23:46:49 --> File loaded: application/views/common/footer.php
DEBUG - 2011-05-25 23:46:49 --> File loaded: application/views/layout/main.php
DEBUG - 2011-05-25 23:46:49 --> Final output sent to browser
DEBUG - 2011-05-25 23:46:49 --> Total execution time: 0.3697
DEBUG - 2011-05-25 23:46:53 --> Config Class Initialized
DEBUG - 2011-05-25 23:46:53 --> Hooks Class Initialized
DEBUG - 2011-05-25 23:46:53 --> Utf8 Class Initialized
DEBUG - 2011-05-25 23:46:53 --> UTF-8 Support Enabled
DEBUG - 2011-05-25 23:46:53 --> URI Class Initialized
DEBUG - 2011-05-25 23:46:53 --> Router Class Initialized
DEBUG - 2011-05-25 23:46:53 --> Output Class Initialized
DEBUG - 2011-05-25 23:46:53 --> Input Class Initialized
DEBUG - 2011-05-25 23:46:53 --> Global POST and COOKIE data sanitized
DEBUG - 2011-05-25 23:46:53 --> Language Class Initialized
DEBUG - 2011-05-25 23:46:53 --> Loader Class Initialized
DEBUG - 2011-05-25 23:46:53 --> Controller Class Initialized
DEBUG - 2011-05-25 23:46:53 --> Model Class Initialized
DEBUG - 2011-05-25 23:46:53 --> Model Class Initialized
DEBUG - 2011-05-25 23:46:53 --> Model Class Initialized
DEBUG - 2011-05-25 23:46:53 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-05-25 23:46:53 --> Database Driver Class Initialized
DEBUG - 2011-05-25 23:46:53 --> File loaded: application/views/table/main.php
DEBUG - 2011-05-25 23:46:53 --> Helper loaded: url_helper
DEBUG - 2011-05-25 23:46:53 --> File loaded: application/views/common/header.php
DEBUG - 2011-05-25 23:46:53 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-05-25 23:46:53 --> File loaded: application/views/common/footer.php
DEBUG - 2011-05-25 23:46:53 --> File loaded: application/views/layout/main.php
DEBUG - 2011-05-25 23:46:53 --> Final output sent to browser
DEBUG - 2011-05-25 23:46:53 --> Total execution time: 0.0856
DEBUG - 2011-05-25 23:46:56 --> Config Class Initialized
DEBUG - 2011-05-25 23:46:56 --> Hooks Class Initialized
DEBUG - 2011-05-25 23:46:56 --> Utf8 Class Initialized
DEBUG - 2011-05-25 23:46:56 --> UTF-8 Support Enabled
DEBUG - 2011-05-25 23:46:56 --> URI Class Initialized
DEBUG - 2011-05-25 23:46:56 --> Router Class Initialized
ERROR - 2011-05-25 23:46:56 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-05-25 23:47:00 --> Config Class Initialized
DEBUG - 2011-05-25 23:47:00 --> Hooks Class Initialized
DEBUG - 2011-05-25 23:47:00 --> Utf8 Class Initialized
DEBUG - 2011-05-25 23:47:00 --> UTF-8 Support Enabled
DEBUG - 2011-05-25 23:47:00 --> URI Class Initialized
DEBUG - 2011-05-25 23:47:00 --> Router Class Initialized
ERROR - 2011-05-25 23:47:00 --> 404 Page Not Found --> favicon.ico

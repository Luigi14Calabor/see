<?php  if ( ! defined('BASEPATH')) exit('No direct script access allowed'); ?>

DEBUG - 2011-04-28 00:05:09 --> Config Class Initialized
DEBUG - 2011-04-28 00:05:09 --> Hooks Class Initialized
DEBUG - 2011-04-28 00:05:09 --> Utf8 Class Initialized
DEBUG - 2011-04-28 00:05:09 --> UTF-8 Support Enabled
DEBUG - 2011-04-28 00:05:09 --> URI Class Initialized
DEBUG - 2011-04-28 00:05:09 --> Router Class Initialized
DEBUG - 2011-04-28 00:05:09 --> Output Class Initialized
DEBUG - 2011-04-28 00:05:10 --> Input Class Initialized
DEBUG - 2011-04-28 00:05:10 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-28 00:05:10 --> Language Class Initialized
DEBUG - 2011-04-28 00:05:10 --> Loader Class Initialized
DEBUG - 2011-04-28 00:05:10 --> Controller Class Initialized
DEBUG - 2011-04-28 00:05:10 --> Model Class Initialized
DEBUG - 2011-04-28 00:05:10 --> Model Class Initialized
DEBUG - 2011-04-28 00:05:10 --> Model Class Initialized
DEBUG - 2011-04-28 00:05:10 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-28 00:05:10 --> Database Driver Class Initialized
DEBUG - 2011-04-28 00:05:10 --> File loaded: application/views/table/main.php
DEBUG - 2011-04-28 00:05:10 --> Helper loaded: url_helper
DEBUG - 2011-04-28 00:05:10 --> File loaded: application/views/common/header.php
DEBUG - 2011-04-28 00:05:10 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-04-28 00:05:10 --> File loaded: application/views/common/footer.php
DEBUG - 2011-04-28 00:05:10 --> File loaded: application/views/layout/main.php
DEBUG - 2011-04-28 00:05:10 --> Final output sent to browser
DEBUG - 2011-04-28 00:05:10 --> Total execution time: 0.7097
DEBUG - 2011-04-28 00:05:11 --> Config Class Initialized
DEBUG - 2011-04-28 00:05:11 --> Hooks Class Initialized
DEBUG - 2011-04-28 00:05:11 --> Utf8 Class Initialized
DEBUG - 2011-04-28 00:05:11 --> UTF-8 Support Enabled
DEBUG - 2011-04-28 00:05:11 --> URI Class Initialized
DEBUG - 2011-04-28 00:05:11 --> Router Class Initialized
DEBUG - 2011-04-28 00:05:11 --> Output Class Initialized
DEBUG - 2011-04-28 00:05:11 --> Input Class Initialized
DEBUG - 2011-04-28 00:05:11 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-28 00:05:11 --> Language Class Initialized
DEBUG - 2011-04-28 00:05:11 --> Loader Class Initialized
DEBUG - 2011-04-28 00:05:11 --> Controller Class Initialized
ERROR - 2011-04-28 00:05:13 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-04-28 00:05:13 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-04-28 00:05:13 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-04-28 00:05:13 --> Model Class Initialized
DEBUG - 2011-04-28 00:05:13 --> Model Class Initialized
DEBUG - 2011-04-28 00:05:13 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-28 00:05:13 --> Database Driver Class Initialized
DEBUG - 2011-04-28 00:05:13 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-04-28 00:05:13 --> Helper loaded: url_helper
DEBUG - 2011-04-28 00:05:13 --> File loaded: application/views/common/header.php
DEBUG - 2011-04-28 00:05:13 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-04-28 00:05:13 --> File loaded: application/views/common/footer.php
DEBUG - 2011-04-28 00:05:13 --> File loaded: application/views/layout/main.php
DEBUG - 2011-04-28 00:05:13 --> Final output sent to browser
DEBUG - 2011-04-28 00:05:13 --> Total execution time: 1.3963
DEBUG - 2011-04-28 00:11:32 --> Config Class Initialized
DEBUG - 2011-04-28 00:11:32 --> Hooks Class Initialized
DEBUG - 2011-04-28 00:11:32 --> Utf8 Class Initialized
DEBUG - 2011-04-28 00:11:32 --> UTF-8 Support Enabled
DEBUG - 2011-04-28 00:11:32 --> URI Class Initialized
DEBUG - 2011-04-28 00:11:32 --> Router Class Initialized
DEBUG - 2011-04-28 00:11:32 --> Output Class Initialized
DEBUG - 2011-04-28 00:11:32 --> Input Class Initialized
DEBUG - 2011-04-28 00:11:32 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-28 00:11:32 --> Language Class Initialized
DEBUG - 2011-04-28 00:11:32 --> Loader Class Initialized
DEBUG - 2011-04-28 00:11:32 --> Controller Class Initialized
DEBUG - 2011-04-28 00:11:32 --> Model Class Initialized
DEBUG - 2011-04-28 00:11:32 --> Model Class Initialized
DEBUG - 2011-04-28 00:11:32 --> Model Class Initialized
DEBUG - 2011-04-28 00:11:32 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-28 00:11:32 --> Database Driver Class Initialized
DEBUG - 2011-04-28 00:11:32 --> File loaded: application/views/table/main.php
DEBUG - 2011-04-28 00:11:32 --> Helper loaded: url_helper
DEBUG - 2011-04-28 00:11:32 --> File loaded: application/views/common/header.php
DEBUG - 2011-04-28 00:11:32 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-04-28 00:11:32 --> File loaded: application/views/common/footer.php
DEBUG - 2011-04-28 00:11:32 --> File loaded: application/views/layout/main.php
DEBUG - 2011-04-28 00:11:32 --> Final output sent to browser
DEBUG - 2011-04-28 00:11:32 --> Total execution time: 0.0430
DEBUG - 2011-04-28 00:11:33 --> Config Class Initialized
DEBUG - 2011-04-28 00:11:33 --> Hooks Class Initialized
DEBUG - 2011-04-28 00:11:33 --> Utf8 Class Initialized
DEBUG - 2011-04-28 00:11:33 --> UTF-8 Support Enabled
DEBUG - 2011-04-28 00:11:33 --> URI Class Initialized
DEBUG - 2011-04-28 00:11:33 --> Router Class Initialized
DEBUG - 2011-04-28 00:11:33 --> Output Class Initialized
DEBUG - 2011-04-28 00:11:33 --> Input Class Initialized
DEBUG - 2011-04-28 00:11:33 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-28 00:11:33 --> Language Class Initialized
DEBUG - 2011-04-28 00:11:33 --> Loader Class Initialized
DEBUG - 2011-04-28 00:11:33 --> Controller Class Initialized
ERROR - 2011-04-28 00:11:33 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-04-28 00:11:33 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-04-28 00:11:33 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-04-28 00:11:33 --> Model Class Initialized
DEBUG - 2011-04-28 00:11:33 --> Model Class Initialized
DEBUG - 2011-04-28 00:11:33 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-28 00:11:33 --> Database Driver Class Initialized
DEBUG - 2011-04-28 00:11:33 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-04-28 00:11:33 --> Helper loaded: url_helper
DEBUG - 2011-04-28 00:11:33 --> File loaded: application/views/common/header.php
DEBUG - 2011-04-28 00:11:33 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-04-28 00:11:33 --> File loaded: application/views/common/footer.php
DEBUG - 2011-04-28 00:11:33 --> File loaded: application/views/layout/main.php
DEBUG - 2011-04-28 00:11:33 --> Final output sent to browser
DEBUG - 2011-04-28 00:11:33 --> Total execution time: 0.0300
DEBUG - 2011-04-28 00:38:44 --> Config Class Initialized
DEBUG - 2011-04-28 00:38:44 --> Hooks Class Initialized
DEBUG - 2011-04-28 00:38:44 --> Utf8 Class Initialized
DEBUG - 2011-04-28 00:38:44 --> UTF-8 Support Enabled
DEBUG - 2011-04-28 00:38:44 --> URI Class Initialized
DEBUG - 2011-04-28 00:38:44 --> Router Class Initialized
ERROR - 2011-04-28 00:38:44 --> 404 Page Not Found --> robots.txt
DEBUG - 2011-04-28 00:39:43 --> Config Class Initialized
DEBUG - 2011-04-28 00:39:43 --> Hooks Class Initialized
DEBUG - 2011-04-28 00:39:43 --> Utf8 Class Initialized
DEBUG - 2011-04-28 00:39:43 --> UTF-8 Support Enabled
DEBUG - 2011-04-28 00:39:43 --> URI Class Initialized
DEBUG - 2011-04-28 00:39:43 --> Router Class Initialized
DEBUG - 2011-04-28 00:39:43 --> Output Class Initialized
DEBUG - 2011-04-28 00:39:43 --> Input Class Initialized
DEBUG - 2011-04-28 00:39:43 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-28 00:39:43 --> Language Class Initialized
DEBUG - 2011-04-28 00:39:43 --> Loader Class Initialized
DEBUG - 2011-04-28 00:39:43 --> Controller Class Initialized
DEBUG - 2011-04-28 00:39:43 --> Model Class Initialized
DEBUG - 2011-04-28 00:39:43 --> Model Class Initialized
DEBUG - 2011-04-28 00:39:43 --> Model Class Initialized
DEBUG - 2011-04-28 00:39:43 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-28 00:39:43 --> Database Driver Class Initialized
DEBUG - 2011-04-28 00:39:44 --> File loaded: application/views/table/main.php
DEBUG - 2011-04-28 00:39:44 --> Helper loaded: url_helper
DEBUG - 2011-04-28 00:39:44 --> File loaded: application/views/common/header.php
DEBUG - 2011-04-28 00:39:44 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-04-28 00:39:44 --> File loaded: application/views/common/footer.php
DEBUG - 2011-04-28 00:39:44 --> File loaded: application/views/layout/main.php
DEBUG - 2011-04-28 00:39:44 --> Final output sent to browser
DEBUG - 2011-04-28 00:39:44 --> Total execution time: 0.4612
DEBUG - 2011-04-28 00:43:10 --> Config Class Initialized
DEBUG - 2011-04-28 00:43:10 --> Hooks Class Initialized
DEBUG - 2011-04-28 00:43:10 --> Utf8 Class Initialized
DEBUG - 2011-04-28 00:43:10 --> UTF-8 Support Enabled
DEBUG - 2011-04-28 00:43:10 --> URI Class Initialized
DEBUG - 2011-04-28 00:43:10 --> Router Class Initialized
DEBUG - 2011-04-28 00:43:10 --> Output Class Initialized
DEBUG - 2011-04-28 00:43:10 --> Input Class Initialized
DEBUG - 2011-04-28 00:43:10 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-28 00:43:10 --> Language Class Initialized
DEBUG - 2011-04-28 00:43:10 --> Loader Class Initialized
DEBUG - 2011-04-28 00:43:10 --> Controller Class Initialized
ERROR - 2011-04-28 00:43:10 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-04-28 00:43:10 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-04-28 00:43:10 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-04-28 00:43:10 --> Model Class Initialized
DEBUG - 2011-04-28 00:43:10 --> Model Class Initialized
DEBUG - 2011-04-28 00:43:10 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-28 00:43:10 --> Database Driver Class Initialized
DEBUG - 2011-04-28 00:43:10 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-04-28 00:43:10 --> Helper loaded: url_helper
DEBUG - 2011-04-28 00:43:10 --> File loaded: application/views/common/header.php
DEBUG - 2011-04-28 00:43:10 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-04-28 00:43:10 --> File loaded: application/views/common/footer.php
DEBUG - 2011-04-28 00:43:10 --> File loaded: application/views/layout/main.php
DEBUG - 2011-04-28 00:43:10 --> Final output sent to browser
DEBUG - 2011-04-28 00:43:10 --> Total execution time: 0.0322
DEBUG - 2011-04-28 01:05:12 --> Config Class Initialized
DEBUG - 2011-04-28 01:05:12 --> Hooks Class Initialized
DEBUG - 2011-04-28 01:05:12 --> Utf8 Class Initialized
DEBUG - 2011-04-28 01:05:12 --> UTF-8 Support Enabled
DEBUG - 2011-04-28 01:05:12 --> URI Class Initialized
DEBUG - 2011-04-28 01:05:12 --> Router Class Initialized
DEBUG - 2011-04-28 01:05:12 --> Output Class Initialized
DEBUG - 2011-04-28 01:05:12 --> Input Class Initialized
DEBUG - 2011-04-28 01:05:12 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-28 01:05:12 --> Language Class Initialized
DEBUG - 2011-04-28 01:05:12 --> Loader Class Initialized
DEBUG - 2011-04-28 01:05:12 --> Controller Class Initialized
DEBUG - 2011-04-28 01:05:12 --> Model Class Initialized
DEBUG - 2011-04-28 01:05:12 --> Model Class Initialized
DEBUG - 2011-04-28 01:05:12 --> Model Class Initialized
DEBUG - 2011-04-28 01:05:12 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-28 01:05:12 --> Database Driver Class Initialized
DEBUG - 2011-04-28 01:05:13 --> File loaded: application/views/table/main.php
DEBUG - 2011-04-28 01:05:13 --> Helper loaded: url_helper
DEBUG - 2011-04-28 01:05:13 --> File loaded: application/views/common/header.php
DEBUG - 2011-04-28 01:05:13 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-04-28 01:05:13 --> File loaded: application/views/common/footer.php
DEBUG - 2011-04-28 01:05:13 --> File loaded: application/views/layout/main.php
DEBUG - 2011-04-28 01:05:13 --> Final output sent to browser
DEBUG - 2011-04-28 01:05:13 --> Total execution time: 1.2254
DEBUG - 2011-04-28 01:05:18 --> Config Class Initialized
DEBUG - 2011-04-28 01:05:18 --> Hooks Class Initialized
DEBUG - 2011-04-28 01:05:18 --> Utf8 Class Initialized
DEBUG - 2011-04-28 01:05:18 --> UTF-8 Support Enabled
DEBUG - 2011-04-28 01:05:18 --> URI Class Initialized
DEBUG - 2011-04-28 01:05:18 --> Router Class Initialized
ERROR - 2011-04-28 01:05:18 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-04-28 01:05:18 --> Config Class Initialized
DEBUG - 2011-04-28 01:05:18 --> Hooks Class Initialized
DEBUG - 2011-04-28 01:05:18 --> Utf8 Class Initialized
DEBUG - 2011-04-28 01:05:18 --> UTF-8 Support Enabled
DEBUG - 2011-04-28 01:05:18 --> URI Class Initialized
DEBUG - 2011-04-28 01:05:18 --> Router Class Initialized
ERROR - 2011-04-28 01:05:18 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-04-28 02:12:43 --> Config Class Initialized
DEBUG - 2011-04-28 02:12:43 --> Hooks Class Initialized
DEBUG - 2011-04-28 02:12:43 --> Utf8 Class Initialized
DEBUG - 2011-04-28 02:12:43 --> UTF-8 Support Enabled
DEBUG - 2011-04-28 02:12:43 --> URI Class Initialized
DEBUG - 2011-04-28 02:12:43 --> Router Class Initialized
DEBUG - 2011-04-28 02:12:43 --> Output Class Initialized
DEBUG - 2011-04-28 02:12:43 --> Input Class Initialized
DEBUG - 2011-04-28 02:12:43 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-28 02:12:43 --> Language Class Initialized
DEBUG - 2011-04-28 02:12:43 --> Loader Class Initialized
DEBUG - 2011-04-28 02:12:43 --> Controller Class Initialized
DEBUG - 2011-04-28 02:12:43 --> Model Class Initialized
DEBUG - 2011-04-28 02:12:43 --> Model Class Initialized
DEBUG - 2011-04-28 02:12:43 --> Model Class Initialized
DEBUG - 2011-04-28 02:12:43 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-28 02:12:43 --> Database Driver Class Initialized
DEBUG - 2011-04-28 02:12:50 --> File loaded: application/views/table/main.php
DEBUG - 2011-04-28 02:12:50 --> Helper loaded: url_helper
DEBUG - 2011-04-28 02:12:50 --> File loaded: application/views/common/header.php
DEBUG - 2011-04-28 02:12:50 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-04-28 02:12:50 --> File loaded: application/views/common/footer.php
DEBUG - 2011-04-28 02:12:50 --> File loaded: application/views/layout/main.php
DEBUG - 2011-04-28 02:12:50 --> Final output sent to browser
DEBUG - 2011-04-28 02:12:50 --> Total execution time: 7.5882
DEBUG - 2011-04-28 02:12:51 --> Config Class Initialized
DEBUG - 2011-04-28 02:12:51 --> Hooks Class Initialized
DEBUG - 2011-04-28 02:12:51 --> Utf8 Class Initialized
DEBUG - 2011-04-28 02:12:51 --> UTF-8 Support Enabled
DEBUG - 2011-04-28 02:12:51 --> URI Class Initialized
DEBUG - 2011-04-28 02:12:51 --> Router Class Initialized
DEBUG - 2011-04-28 02:12:51 --> Output Class Initialized
DEBUG - 2011-04-28 02:12:51 --> Input Class Initialized
DEBUG - 2011-04-28 02:12:51 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-28 02:12:51 --> Language Class Initialized
DEBUG - 2011-04-28 02:12:51 --> Loader Class Initialized
DEBUG - 2011-04-28 02:12:51 --> Controller Class Initialized
ERROR - 2011-04-28 02:12:51 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-04-28 02:12:51 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-04-28 02:12:51 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-04-28 02:12:51 --> Model Class Initialized
DEBUG - 2011-04-28 02:12:51 --> Model Class Initialized
DEBUG - 2011-04-28 02:12:51 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-28 02:12:51 --> Database Driver Class Initialized
DEBUG - 2011-04-28 02:12:51 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-04-28 02:12:51 --> Helper loaded: url_helper
DEBUG - 2011-04-28 02:12:51 --> File loaded: application/views/common/header.php
DEBUG - 2011-04-28 02:12:51 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-04-28 02:12:51 --> File loaded: application/views/common/footer.php
DEBUG - 2011-04-28 02:12:51 --> File loaded: application/views/layout/main.php
DEBUG - 2011-04-28 02:12:51 --> Final output sent to browser
DEBUG - 2011-04-28 02:12:51 --> Total execution time: 0.1667
DEBUG - 2011-04-28 02:19:49 --> Config Class Initialized
DEBUG - 2011-04-28 02:19:49 --> Hooks Class Initialized
DEBUG - 2011-04-28 02:19:49 --> Utf8 Class Initialized
DEBUG - 2011-04-28 02:19:49 --> UTF-8 Support Enabled
DEBUG - 2011-04-28 02:19:49 --> URI Class Initialized
DEBUG - 2011-04-28 02:19:49 --> Router Class Initialized
ERROR - 2011-04-28 02:19:49 --> 404 Page Not Found --> robots.txt
DEBUG - 2011-04-28 02:19:49 --> Config Class Initialized
DEBUG - 2011-04-28 02:19:49 --> Hooks Class Initialized
DEBUG - 2011-04-28 02:19:49 --> Utf8 Class Initialized
DEBUG - 2011-04-28 02:19:49 --> UTF-8 Support Enabled
DEBUG - 2011-04-28 02:19:49 --> URI Class Initialized
DEBUG - 2011-04-28 02:19:49 --> Router Class Initialized
DEBUG - 2011-04-28 02:19:49 --> Output Class Initialized
DEBUG - 2011-04-28 02:19:49 --> Input Class Initialized
DEBUG - 2011-04-28 02:19:49 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-28 02:19:49 --> Language Class Initialized
DEBUG - 2011-04-28 02:19:49 --> Loader Class Initialized
DEBUG - 2011-04-28 02:19:49 --> Controller Class Initialized
ERROR - 2011-04-28 02:19:49 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-04-28 02:19:49 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-04-28 02:19:49 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-04-28 02:19:49 --> Model Class Initialized
DEBUG - 2011-04-28 02:19:49 --> Model Class Initialized
DEBUG - 2011-04-28 02:19:49 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-28 02:19:49 --> Database Driver Class Initialized
DEBUG - 2011-04-28 02:19:49 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-04-28 02:19:49 --> Helper loaded: url_helper
DEBUG - 2011-04-28 02:19:49 --> File loaded: application/views/common/header.php
DEBUG - 2011-04-28 02:19:49 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-04-28 02:19:49 --> File loaded: application/views/common/footer.php
DEBUG - 2011-04-28 02:19:49 --> File loaded: application/views/layout/main.php
DEBUG - 2011-04-28 02:19:49 --> Final output sent to browser
DEBUG - 2011-04-28 02:19:49 --> Total execution time: 0.1414
DEBUG - 2011-04-28 02:20:41 --> Config Class Initialized
DEBUG - 2011-04-28 02:20:41 --> Hooks Class Initialized
DEBUG - 2011-04-28 02:20:41 --> Utf8 Class Initialized
DEBUG - 2011-04-28 02:20:41 --> UTF-8 Support Enabled
DEBUG - 2011-04-28 02:20:41 --> URI Class Initialized
DEBUG - 2011-04-28 02:20:41 --> Router Class Initialized
DEBUG - 2011-04-28 02:20:41 --> Output Class Initialized
DEBUG - 2011-04-28 02:20:41 --> Input Class Initialized
DEBUG - 2011-04-28 02:20:41 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-28 02:20:41 --> Language Class Initialized
DEBUG - 2011-04-28 02:20:41 --> Loader Class Initialized
DEBUG - 2011-04-28 02:20:41 --> Controller Class Initialized
DEBUG - 2011-04-28 02:20:41 --> Model Class Initialized
DEBUG - 2011-04-28 02:20:41 --> Model Class Initialized
DEBUG - 2011-04-28 02:20:41 --> Model Class Initialized
DEBUG - 2011-04-28 02:20:41 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-28 02:20:41 --> Database Driver Class Initialized
DEBUG - 2011-04-28 02:20:41 --> File loaded: application/views/table/main.php
DEBUG - 2011-04-28 02:20:41 --> Helper loaded: url_helper
DEBUG - 2011-04-28 02:20:41 --> File loaded: application/views/common/header.php
DEBUG - 2011-04-28 02:20:41 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-04-28 02:20:41 --> File loaded: application/views/common/footer.php
DEBUG - 2011-04-28 02:20:41 --> File loaded: application/views/layout/main.php
DEBUG - 2011-04-28 02:20:41 --> Final output sent to browser
DEBUG - 2011-04-28 02:20:41 --> Total execution time: 0.1396
DEBUG - 2011-04-28 02:33:12 --> Config Class Initialized
DEBUG - 2011-04-28 02:33:12 --> Hooks Class Initialized
DEBUG - 2011-04-28 02:33:12 --> Utf8 Class Initialized
DEBUG - 2011-04-28 02:33:12 --> UTF-8 Support Enabled
DEBUG - 2011-04-28 02:33:12 --> URI Class Initialized
DEBUG - 2011-04-28 02:33:12 --> Router Class Initialized
DEBUG - 2011-04-28 02:33:12 --> Output Class Initialized
DEBUG - 2011-04-28 02:33:12 --> Input Class Initialized
DEBUG - 2011-04-28 02:33:12 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-28 02:33:12 --> Language Class Initialized
DEBUG - 2011-04-28 02:33:12 --> Loader Class Initialized
DEBUG - 2011-04-28 02:33:12 --> Controller Class Initialized
DEBUG - 2011-04-28 02:33:12 --> Model Class Initialized
DEBUG - 2011-04-28 02:33:12 --> Model Class Initialized
DEBUG - 2011-04-28 02:33:12 --> Model Class Initialized
DEBUG - 2011-04-28 02:33:12 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-28 02:33:12 --> Database Driver Class Initialized
DEBUG - 2011-04-28 02:33:12 --> File loaded: application/views/table/main.php
DEBUG - 2011-04-28 02:33:12 --> Helper loaded: url_helper
DEBUG - 2011-04-28 02:33:12 --> File loaded: application/views/common/header.php
DEBUG - 2011-04-28 02:33:12 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-04-28 02:33:12 --> File loaded: application/views/common/footer.php
DEBUG - 2011-04-28 02:33:12 --> File loaded: application/views/layout/main.php
DEBUG - 2011-04-28 02:33:12 --> Final output sent to browser
DEBUG - 2011-04-28 02:33:12 --> Total execution time: 0.2109
DEBUG - 2011-04-28 02:35:07 --> Config Class Initialized
DEBUG - 2011-04-28 02:35:07 --> Hooks Class Initialized
DEBUG - 2011-04-28 02:35:07 --> Utf8 Class Initialized
DEBUG - 2011-04-28 02:35:07 --> UTF-8 Support Enabled
DEBUG - 2011-04-28 02:35:07 --> URI Class Initialized
DEBUG - 2011-04-28 02:35:07 --> Router Class Initialized
DEBUG - 2011-04-28 02:35:07 --> Output Class Initialized
DEBUG - 2011-04-28 02:35:07 --> Input Class Initialized
DEBUG - 2011-04-28 02:35:07 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-28 02:35:07 --> Language Class Initialized
DEBUG - 2011-04-28 02:35:07 --> Loader Class Initialized
DEBUG - 2011-04-28 02:35:07 --> Controller Class Initialized
DEBUG - 2011-04-28 02:35:07 --> Model Class Initialized
DEBUG - 2011-04-28 02:35:07 --> Model Class Initialized
DEBUG - 2011-04-28 02:35:07 --> Model Class Initialized
DEBUG - 2011-04-28 02:35:07 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-28 02:35:07 --> Database Driver Class Initialized
DEBUG - 2011-04-28 02:35:08 --> File loaded: application/views/table/main.php
DEBUG - 2011-04-28 02:35:08 --> Helper loaded: url_helper
DEBUG - 2011-04-28 02:35:08 --> File loaded: application/views/common/header.php
DEBUG - 2011-04-28 02:35:08 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-04-28 02:35:08 --> File loaded: application/views/common/footer.php
DEBUG - 2011-04-28 02:35:08 --> File loaded: application/views/layout/main.php
DEBUG - 2011-04-28 02:35:08 --> Final output sent to browser
DEBUG - 2011-04-28 02:35:08 --> Total execution time: 0.5525
DEBUG - 2011-04-28 02:40:34 --> Config Class Initialized
DEBUG - 2011-04-28 02:40:34 --> Hooks Class Initialized
DEBUG - 2011-04-28 02:40:34 --> Utf8 Class Initialized
DEBUG - 2011-04-28 02:40:34 --> UTF-8 Support Enabled
DEBUG - 2011-04-28 02:40:34 --> URI Class Initialized
DEBUG - 2011-04-28 02:40:34 --> Router Class Initialized
DEBUG - 2011-04-28 02:40:34 --> Output Class Initialized
DEBUG - 2011-04-28 02:40:34 --> Input Class Initialized
DEBUG - 2011-04-28 02:40:34 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-28 02:40:34 --> Language Class Initialized
DEBUG - 2011-04-28 02:40:34 --> Loader Class Initialized
DEBUG - 2011-04-28 02:40:34 --> Controller Class Initialized
DEBUG - 2011-04-28 02:40:34 --> Model Class Initialized
DEBUG - 2011-04-28 02:40:34 --> Model Class Initialized
DEBUG - 2011-04-28 02:40:34 --> Model Class Initialized
DEBUG - 2011-04-28 02:40:34 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-28 02:40:34 --> Database Driver Class Initialized
DEBUG - 2011-04-28 02:40:34 --> File loaded: application/views/table/main.php
DEBUG - 2011-04-28 02:40:34 --> Helper loaded: url_helper
DEBUG - 2011-04-28 02:40:34 --> File loaded: application/views/common/header.php
DEBUG - 2011-04-28 02:40:34 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-04-28 02:40:34 --> File loaded: application/views/common/footer.php
DEBUG - 2011-04-28 02:40:34 --> File loaded: application/views/layout/main.php
DEBUG - 2011-04-28 02:40:34 --> Final output sent to browser
DEBUG - 2011-04-28 02:40:34 --> Total execution time: 0.0651
DEBUG - 2011-04-28 02:40:36 --> Config Class Initialized
DEBUG - 2011-04-28 02:40:36 --> Hooks Class Initialized
DEBUG - 2011-04-28 02:40:36 --> Utf8 Class Initialized
DEBUG - 2011-04-28 02:40:36 --> UTF-8 Support Enabled
DEBUG - 2011-04-28 02:40:36 --> URI Class Initialized
DEBUG - 2011-04-28 02:40:36 --> Router Class Initialized
DEBUG - 2011-04-28 02:40:36 --> Output Class Initialized
DEBUG - 2011-04-28 02:40:36 --> Input Class Initialized
DEBUG - 2011-04-28 02:40:36 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-28 02:40:36 --> Language Class Initialized
DEBUG - 2011-04-28 02:40:36 --> Loader Class Initialized
DEBUG - 2011-04-28 02:40:36 --> Controller Class Initialized
ERROR - 2011-04-28 02:40:36 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-04-28 02:40:36 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-04-28 02:40:36 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-04-28 02:40:36 --> Model Class Initialized
DEBUG - 2011-04-28 02:40:36 --> Model Class Initialized
DEBUG - 2011-04-28 02:40:36 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-28 02:40:36 --> Database Driver Class Initialized
DEBUG - 2011-04-28 02:40:36 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-04-28 02:40:36 --> Helper loaded: url_helper
DEBUG - 2011-04-28 02:40:36 --> File loaded: application/views/common/header.php
DEBUG - 2011-04-28 02:40:36 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-04-28 02:40:36 --> File loaded: application/views/common/footer.php
DEBUG - 2011-04-28 02:40:36 --> File loaded: application/views/layout/main.php
DEBUG - 2011-04-28 02:40:36 --> Final output sent to browser
DEBUG - 2011-04-28 02:40:36 --> Total execution time: 0.1284
DEBUG - 2011-04-28 03:02:57 --> Config Class Initialized
DEBUG - 2011-04-28 03:02:57 --> Hooks Class Initialized
DEBUG - 2011-04-28 03:02:57 --> Utf8 Class Initialized
DEBUG - 2011-04-28 03:02:57 --> UTF-8 Support Enabled
DEBUG - 2011-04-28 03:02:57 --> URI Class Initialized
DEBUG - 2011-04-28 03:02:57 --> Router Class Initialized
DEBUG - 2011-04-28 03:02:57 --> Output Class Initialized
DEBUG - 2011-04-28 03:02:57 --> Input Class Initialized
DEBUG - 2011-04-28 03:02:57 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-28 03:02:57 --> Language Class Initialized
DEBUG - 2011-04-28 03:02:57 --> Loader Class Initialized
DEBUG - 2011-04-28 03:02:57 --> Controller Class Initialized
DEBUG - 2011-04-28 03:02:57 --> Model Class Initialized
DEBUG - 2011-04-28 03:02:57 --> Model Class Initialized
DEBUG - 2011-04-28 03:02:57 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-28 03:02:57 --> Database Driver Class Initialized
DEBUG - 2011-04-28 03:02:59 --> Final output sent to browser
DEBUG - 2011-04-28 03:02:59 --> Total execution time: 1.5340
DEBUG - 2011-04-28 05:11:10 --> Config Class Initialized
DEBUG - 2011-04-28 05:11:10 --> Hooks Class Initialized
DEBUG - 2011-04-28 05:11:10 --> Utf8 Class Initialized
DEBUG - 2011-04-28 05:11:10 --> UTF-8 Support Enabled
DEBUG - 2011-04-28 05:11:10 --> URI Class Initialized
DEBUG - 2011-04-28 05:11:10 --> Router Class Initialized
DEBUG - 2011-04-28 05:11:10 --> Output Class Initialized
DEBUG - 2011-04-28 05:11:10 --> Input Class Initialized
DEBUG - 2011-04-28 05:11:10 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-28 05:11:10 --> Language Class Initialized
DEBUG - 2011-04-28 05:11:10 --> Loader Class Initialized
DEBUG - 2011-04-28 05:11:10 --> Controller Class Initialized
DEBUG - 2011-04-28 05:11:10 --> Model Class Initialized
DEBUG - 2011-04-28 05:11:10 --> Model Class Initialized
DEBUG - 2011-04-28 05:11:10 --> Model Class Initialized
DEBUG - 2011-04-28 05:11:10 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-28 05:11:10 --> Database Driver Class Initialized
DEBUG - 2011-04-28 05:11:38 --> File loaded: application/views/table/main.php
DEBUG - 2011-04-28 05:11:39 --> Helper loaded: url_helper
DEBUG - 2011-04-28 05:11:39 --> File loaded: application/views/common/header.php
DEBUG - 2011-04-28 05:11:39 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-04-28 05:11:39 --> File loaded: application/views/common/footer.php
DEBUG - 2011-04-28 05:11:39 --> File loaded: application/views/layout/main.php
DEBUG - 2011-04-28 05:11:39 --> Final output sent to browser
DEBUG - 2011-04-28 05:11:39 --> Total execution time: 28.8178
DEBUG - 2011-04-28 05:11:40 --> Config Class Initialized
DEBUG - 2011-04-28 05:11:40 --> Hooks Class Initialized
DEBUG - 2011-04-28 05:11:40 --> Utf8 Class Initialized
DEBUG - 2011-04-28 05:11:40 --> UTF-8 Support Enabled
DEBUG - 2011-04-28 05:11:40 --> URI Class Initialized
DEBUG - 2011-04-28 05:11:40 --> Router Class Initialized
DEBUG - 2011-04-28 05:11:40 --> Output Class Initialized
DEBUG - 2011-04-28 05:11:40 --> Input Class Initialized
DEBUG - 2011-04-28 05:11:40 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-28 05:11:40 --> Language Class Initialized
DEBUG - 2011-04-28 05:11:40 --> Loader Class Initialized
DEBUG - 2011-04-28 05:11:40 --> Controller Class Initialized
ERROR - 2011-04-28 05:11:40 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-04-28 05:11:40 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-04-28 05:11:40 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-04-28 05:11:40 --> Model Class Initialized
DEBUG - 2011-04-28 05:11:40 --> Model Class Initialized
DEBUG - 2011-04-28 05:11:40 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-28 05:11:40 --> Database Driver Class Initialized
DEBUG - 2011-04-28 05:11:40 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-04-28 05:11:40 --> Helper loaded: url_helper
DEBUG - 2011-04-28 05:11:40 --> File loaded: application/views/common/header.php
DEBUG - 2011-04-28 05:11:40 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-04-28 05:11:40 --> File loaded: application/views/common/footer.php
DEBUG - 2011-04-28 05:11:40 --> File loaded: application/views/layout/main.php
DEBUG - 2011-04-28 05:11:40 --> Final output sent to browser
DEBUG - 2011-04-28 05:11:40 --> Total execution time: 0.1536
DEBUG - 2011-04-28 06:20:25 --> Config Class Initialized
DEBUG - 2011-04-28 06:20:25 --> Hooks Class Initialized
DEBUG - 2011-04-28 06:20:25 --> Utf8 Class Initialized
DEBUG - 2011-04-28 06:20:25 --> UTF-8 Support Enabled
DEBUG - 2011-04-28 06:20:25 --> URI Class Initialized
DEBUG - 2011-04-28 06:20:25 --> Router Class Initialized
DEBUG - 2011-04-28 06:20:25 --> Output Class Initialized
DEBUG - 2011-04-28 06:20:25 --> Input Class Initialized
DEBUG - 2011-04-28 06:20:25 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-28 06:20:25 --> Language Class Initialized
DEBUG - 2011-04-28 06:20:25 --> Loader Class Initialized
DEBUG - 2011-04-28 06:20:25 --> Controller Class Initialized
DEBUG - 2011-04-28 06:20:25 --> Model Class Initialized
DEBUG - 2011-04-28 06:20:25 --> Model Class Initialized
DEBUG - 2011-04-28 06:20:25 --> Model Class Initialized
DEBUG - 2011-04-28 06:20:25 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-28 06:20:25 --> Database Driver Class Initialized
DEBUG - 2011-04-28 06:20:28 --> File loaded: application/views/table/main.php
DEBUG - 2011-04-28 06:20:28 --> Helper loaded: url_helper
DEBUG - 2011-04-28 06:20:28 --> File loaded: application/views/common/header.php
DEBUG - 2011-04-28 06:20:28 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-04-28 06:20:28 --> File loaded: application/views/common/footer.php
DEBUG - 2011-04-28 06:20:28 --> File loaded: application/views/layout/main.php
DEBUG - 2011-04-28 06:20:28 --> Final output sent to browser
DEBUG - 2011-04-28 06:20:28 --> Total execution time: 3.2182
DEBUG - 2011-04-28 06:20:47 --> Config Class Initialized
DEBUG - 2011-04-28 06:20:47 --> Hooks Class Initialized
DEBUG - 2011-04-28 06:20:47 --> Utf8 Class Initialized
DEBUG - 2011-04-28 06:20:47 --> UTF-8 Support Enabled
DEBUG - 2011-04-28 06:20:47 --> URI Class Initialized
DEBUG - 2011-04-28 06:20:47 --> Router Class Initialized
DEBUG - 2011-04-28 06:20:47 --> Output Class Initialized
DEBUG - 2011-04-28 06:20:47 --> Input Class Initialized
DEBUG - 2011-04-28 06:20:47 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-28 06:20:47 --> Language Class Initialized
DEBUG - 2011-04-28 06:20:47 --> Loader Class Initialized
DEBUG - 2011-04-28 06:20:47 --> Controller Class Initialized
ERROR - 2011-04-28 06:20:47 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-04-28 06:20:47 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-04-28 06:20:47 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-04-28 06:20:47 --> Model Class Initialized
DEBUG - 2011-04-28 06:20:47 --> Model Class Initialized
DEBUG - 2011-04-28 06:20:47 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-28 06:20:47 --> Database Driver Class Initialized
DEBUG - 2011-04-28 06:20:47 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-04-28 06:20:47 --> Helper loaded: url_helper
DEBUG - 2011-04-28 06:20:47 --> File loaded: application/views/common/header.php
DEBUG - 2011-04-28 06:20:47 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-04-28 06:20:47 --> File loaded: application/views/common/footer.php
DEBUG - 2011-04-28 06:20:47 --> File loaded: application/views/layout/main.php
DEBUG - 2011-04-28 06:20:47 --> Final output sent to browser
DEBUG - 2011-04-28 06:20:47 --> Total execution time: 0.1090
DEBUG - 2011-04-28 07:42:14 --> Config Class Initialized
DEBUG - 2011-04-28 07:42:14 --> Hooks Class Initialized
DEBUG - 2011-04-28 07:42:14 --> Utf8 Class Initialized
DEBUG - 2011-04-28 07:42:14 --> UTF-8 Support Enabled
DEBUG - 2011-04-28 07:42:14 --> URI Class Initialized
DEBUG - 2011-04-28 07:42:14 --> Router Class Initialized
DEBUG - 2011-04-28 07:42:14 --> Output Class Initialized
DEBUG - 2011-04-28 07:42:14 --> Input Class Initialized
DEBUG - 2011-04-28 07:42:14 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-28 07:42:14 --> Language Class Initialized
DEBUG - 2011-04-28 07:42:14 --> Loader Class Initialized
DEBUG - 2011-04-28 07:42:14 --> Controller Class Initialized
DEBUG - 2011-04-28 07:42:14 --> Model Class Initialized
DEBUG - 2011-04-28 07:42:14 --> Model Class Initialized
DEBUG - 2011-04-28 07:42:14 --> Model Class Initialized
DEBUG - 2011-04-28 07:42:14 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-28 07:42:14 --> Database Driver Class Initialized
DEBUG - 2011-04-28 07:42:15 --> File loaded: application/views/table/main.php
DEBUG - 2011-04-28 07:42:15 --> Helper loaded: url_helper
DEBUG - 2011-04-28 07:42:15 --> File loaded: application/views/common/header.php
DEBUG - 2011-04-28 07:42:15 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-04-28 07:42:15 --> File loaded: application/views/common/footer.php
DEBUG - 2011-04-28 07:42:15 --> File loaded: application/views/layout/main.php
DEBUG - 2011-04-28 07:42:15 --> Final output sent to browser
DEBUG - 2011-04-28 07:42:15 --> Total execution time: 0.6031
DEBUG - 2011-04-28 07:42:16 --> Config Class Initialized
DEBUG - 2011-04-28 07:42:16 --> Hooks Class Initialized
DEBUG - 2011-04-28 07:42:16 --> Utf8 Class Initialized
DEBUG - 2011-04-28 07:42:16 --> UTF-8 Support Enabled
DEBUG - 2011-04-28 07:42:16 --> URI Class Initialized
DEBUG - 2011-04-28 07:42:16 --> Router Class Initialized
DEBUG - 2011-04-28 07:42:16 --> Output Class Initialized
DEBUG - 2011-04-28 07:42:16 --> Input Class Initialized
DEBUG - 2011-04-28 07:42:16 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-28 07:42:16 --> Language Class Initialized
DEBUG - 2011-04-28 07:42:16 --> Loader Class Initialized
DEBUG - 2011-04-28 07:42:16 --> Controller Class Initialized
DEBUG - 2011-04-28 07:42:16 --> Model Class Initialized
DEBUG - 2011-04-28 07:42:16 --> Model Class Initialized
DEBUG - 2011-04-28 07:42:16 --> Model Class Initialized
DEBUG - 2011-04-28 07:42:16 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-28 07:42:16 --> Database Driver Class Initialized
DEBUG - 2011-04-28 07:42:16 --> File loaded: application/views/table/main.php
DEBUG - 2011-04-28 07:42:16 --> Helper loaded: url_helper
DEBUG - 2011-04-28 07:42:16 --> File loaded: application/views/common/header.php
DEBUG - 2011-04-28 07:42:16 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-04-28 07:42:16 --> File loaded: application/views/common/footer.php
DEBUG - 2011-04-28 07:42:16 --> File loaded: application/views/layout/main.php
DEBUG - 2011-04-28 07:42:16 --> Final output sent to browser
DEBUG - 2011-04-28 07:42:16 --> Total execution time: 0.0467
DEBUG - 2011-04-28 07:42:20 --> Config Class Initialized
DEBUG - 2011-04-28 07:42:20 --> Hooks Class Initialized
DEBUG - 2011-04-28 07:42:20 --> Utf8 Class Initialized
DEBUG - 2011-04-28 07:42:20 --> UTF-8 Support Enabled
DEBUG - 2011-04-28 07:42:20 --> URI Class Initialized
DEBUG - 2011-04-28 07:42:20 --> Router Class Initialized
DEBUG - 2011-04-28 07:42:20 --> Output Class Initialized
DEBUG - 2011-04-28 07:42:20 --> Input Class Initialized
DEBUG - 2011-04-28 07:42:20 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-28 07:42:20 --> Language Class Initialized
DEBUG - 2011-04-28 07:42:20 --> Loader Class Initialized
DEBUG - 2011-04-28 07:42:20 --> Controller Class Initialized
DEBUG - 2011-04-28 07:42:20 --> Model Class Initialized
DEBUG - 2011-04-28 07:42:20 --> Model Class Initialized
DEBUG - 2011-04-28 07:42:20 --> Model Class Initialized
DEBUG - 2011-04-28 07:42:20 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-28 07:42:20 --> Database Driver Class Initialized
DEBUG - 2011-04-28 07:42:20 --> File loaded: application/views/table/main.php
DEBUG - 2011-04-28 07:42:20 --> Helper loaded: url_helper
DEBUG - 2011-04-28 07:42:20 --> File loaded: application/views/common/header.php
DEBUG - 2011-04-28 07:42:20 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-04-28 07:42:20 --> File loaded: application/views/common/footer.php
DEBUG - 2011-04-28 07:42:20 --> File loaded: application/views/layout/main.php
DEBUG - 2011-04-28 07:42:20 --> Final output sent to browser
DEBUG - 2011-04-28 07:42:20 --> Total execution time: 0.0429
DEBUG - 2011-04-28 07:42:20 --> Config Class Initialized
DEBUG - 2011-04-28 07:42:20 --> Hooks Class Initialized
DEBUG - 2011-04-28 07:42:20 --> Utf8 Class Initialized
DEBUG - 2011-04-28 07:42:20 --> UTF-8 Support Enabled
DEBUG - 2011-04-28 07:42:20 --> URI Class Initialized
DEBUG - 2011-04-28 07:42:20 --> Router Class Initialized
ERROR - 2011-04-28 07:42:20 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-04-28 07:43:08 --> Config Class Initialized
DEBUG - 2011-04-28 07:43:08 --> Hooks Class Initialized
DEBUG - 2011-04-28 07:43:08 --> Utf8 Class Initialized
DEBUG - 2011-04-28 07:43:08 --> UTF-8 Support Enabled
DEBUG - 2011-04-28 07:43:08 --> URI Class Initialized
DEBUG - 2011-04-28 07:43:08 --> Router Class Initialized
DEBUG - 2011-04-28 07:43:08 --> Output Class Initialized
DEBUG - 2011-04-28 07:43:08 --> Input Class Initialized
DEBUG - 2011-04-28 07:43:08 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-28 07:43:08 --> Language Class Initialized
DEBUG - 2011-04-28 07:43:08 --> Loader Class Initialized
DEBUG - 2011-04-28 07:43:08 --> Controller Class Initialized
DEBUG - 2011-04-28 07:43:08 --> Model Class Initialized
DEBUG - 2011-04-28 07:43:08 --> Model Class Initialized
DEBUG - 2011-04-28 07:43:08 --> Model Class Initialized
DEBUG - 2011-04-28 07:43:08 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-28 07:43:08 --> Database Driver Class Initialized
DEBUG - 2011-04-28 07:43:09 --> File loaded: application/views/table/main.php
DEBUG - 2011-04-28 07:43:09 --> Helper loaded: url_helper
DEBUG - 2011-04-28 07:43:09 --> File loaded: application/views/common/header.php
DEBUG - 2011-04-28 07:43:09 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-04-28 07:43:09 --> File loaded: application/views/common/footer.php
DEBUG - 2011-04-28 07:43:09 --> File loaded: application/views/layout/main.php
DEBUG - 2011-04-28 07:43:09 --> Final output sent to browser
DEBUG - 2011-04-28 07:43:09 --> Total execution time: 0.2234
DEBUG - 2011-04-28 07:43:13 --> Config Class Initialized
DEBUG - 2011-04-28 07:43:13 --> Hooks Class Initialized
DEBUG - 2011-04-28 07:43:13 --> Utf8 Class Initialized
DEBUG - 2011-04-28 07:43:13 --> UTF-8 Support Enabled
DEBUG - 2011-04-28 07:43:13 --> URI Class Initialized
DEBUG - 2011-04-28 07:43:13 --> Router Class Initialized
DEBUG - 2011-04-28 07:43:13 --> Output Class Initialized
DEBUG - 2011-04-28 07:43:13 --> Input Class Initialized
DEBUG - 2011-04-28 07:43:13 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-28 07:43:13 --> Language Class Initialized
DEBUG - 2011-04-28 07:43:14 --> Loader Class Initialized
DEBUG - 2011-04-28 07:43:14 --> Controller Class Initialized
ERROR - 2011-04-28 07:43:14 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-04-28 07:43:14 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-04-28 07:43:14 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-04-28 07:43:14 --> Model Class Initialized
DEBUG - 2011-04-28 07:43:14 --> Model Class Initialized
DEBUG - 2011-04-28 07:43:14 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-28 07:43:14 --> Database Driver Class Initialized
DEBUG - 2011-04-28 07:43:14 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-04-28 07:43:14 --> Helper loaded: url_helper
DEBUG - 2011-04-28 07:43:14 --> File loaded: application/views/common/header.php
DEBUG - 2011-04-28 07:43:14 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-04-28 07:43:14 --> File loaded: application/views/common/footer.php
DEBUG - 2011-04-28 07:43:14 --> File loaded: application/views/layout/main.php
DEBUG - 2011-04-28 07:43:14 --> Final output sent to browser
DEBUG - 2011-04-28 07:43:14 --> Total execution time: 0.1117
DEBUG - 2011-04-28 09:05:59 --> Config Class Initialized
DEBUG - 2011-04-28 09:05:59 --> Hooks Class Initialized
DEBUG - 2011-04-28 09:05:59 --> Utf8 Class Initialized
DEBUG - 2011-04-28 09:05:59 --> UTF-8 Support Enabled
DEBUG - 2011-04-28 09:05:59 --> URI Class Initialized
DEBUG - 2011-04-28 09:05:59 --> Router Class Initialized
DEBUG - 2011-04-28 09:05:59 --> Output Class Initialized
DEBUG - 2011-04-28 09:05:59 --> Input Class Initialized
DEBUG - 2011-04-28 09:05:59 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-28 09:05:59 --> Language Class Initialized
DEBUG - 2011-04-28 09:05:59 --> Loader Class Initialized
DEBUG - 2011-04-28 09:05:59 --> Controller Class Initialized
ERROR - 2011-04-28 09:05:59 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-04-28 09:05:59 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-04-28 09:05:59 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-04-28 09:05:59 --> Model Class Initialized
DEBUG - 2011-04-28 09:05:59 --> Model Class Initialized
DEBUG - 2011-04-28 09:05:59 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-28 09:05:59 --> Database Driver Class Initialized
DEBUG - 2011-04-28 09:05:59 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-04-28 09:05:59 --> Helper loaded: url_helper
DEBUG - 2011-04-28 09:05:59 --> File loaded: application/views/common/header.php
DEBUG - 2011-04-28 09:05:59 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-04-28 09:05:59 --> File loaded: application/views/common/footer.php
DEBUG - 2011-04-28 09:05:59 --> File loaded: application/views/layout/main.php
DEBUG - 2011-04-28 09:05:59 --> Final output sent to browser
DEBUG - 2011-04-28 09:05:59 --> Total execution time: 0.4573
DEBUG - 2011-04-28 09:06:03 --> Config Class Initialized
DEBUG - 2011-04-28 09:06:03 --> Hooks Class Initialized
DEBUG - 2011-04-28 09:06:03 --> Utf8 Class Initialized
DEBUG - 2011-04-28 09:06:03 --> UTF-8 Support Enabled
DEBUG - 2011-04-28 09:06:03 --> URI Class Initialized
DEBUG - 2011-04-28 09:06:03 --> Router Class Initialized
DEBUG - 2011-04-28 09:06:03 --> Output Class Initialized
DEBUG - 2011-04-28 09:06:03 --> Input Class Initialized
DEBUG - 2011-04-28 09:06:03 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-28 09:06:03 --> Language Class Initialized
DEBUG - 2011-04-28 09:06:03 --> Loader Class Initialized
DEBUG - 2011-04-28 09:06:03 --> Controller Class Initialized
DEBUG - 2011-04-28 09:06:03 --> Model Class Initialized
DEBUG - 2011-04-28 09:06:03 --> Model Class Initialized
DEBUG - 2011-04-28 09:06:03 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-28 09:06:03 --> Database Driver Class Initialized
DEBUG - 2011-04-28 09:06:04 --> Final output sent to browser
DEBUG - 2011-04-28 09:06:04 --> Total execution time: 0.9119
DEBUG - 2011-04-28 09:06:25 --> Config Class Initialized
DEBUG - 2011-04-28 09:06:25 --> Hooks Class Initialized
DEBUG - 2011-04-28 09:06:25 --> Utf8 Class Initialized
DEBUG - 2011-04-28 09:06:25 --> UTF-8 Support Enabled
DEBUG - 2011-04-28 09:06:25 --> URI Class Initialized
DEBUG - 2011-04-28 09:06:25 --> Router Class Initialized
ERROR - 2011-04-28 09:06:25 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-04-28 09:06:28 --> Config Class Initialized
DEBUG - 2011-04-28 09:06:28 --> Hooks Class Initialized
DEBUG - 2011-04-28 09:06:28 --> Utf8 Class Initialized
DEBUG - 2011-04-28 09:06:28 --> UTF-8 Support Enabled
DEBUG - 2011-04-28 09:06:28 --> URI Class Initialized
DEBUG - 2011-04-28 09:06:28 --> Router Class Initialized
ERROR - 2011-04-28 09:06:28 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-04-28 09:06:32 --> Config Class Initialized
DEBUG - 2011-04-28 09:06:32 --> Hooks Class Initialized
DEBUG - 2011-04-28 09:06:32 --> Utf8 Class Initialized
DEBUG - 2011-04-28 09:06:32 --> UTF-8 Support Enabled
DEBUG - 2011-04-28 09:06:32 --> URI Class Initialized
DEBUG - 2011-04-28 09:06:32 --> Router Class Initialized
DEBUG - 2011-04-28 09:06:32 --> Output Class Initialized
DEBUG - 2011-04-28 09:06:32 --> Input Class Initialized
DEBUG - 2011-04-28 09:06:32 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-28 09:06:32 --> Language Class Initialized
DEBUG - 2011-04-28 09:06:32 --> Loader Class Initialized
DEBUG - 2011-04-28 09:06:32 --> Controller Class Initialized
ERROR - 2011-04-28 09:06:32 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-04-28 09:06:32 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-04-28 09:06:32 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-04-28 09:06:32 --> Model Class Initialized
DEBUG - 2011-04-28 09:06:32 --> Model Class Initialized
DEBUG - 2011-04-28 09:06:32 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-28 09:06:32 --> Database Driver Class Initialized
DEBUG - 2011-04-28 09:06:32 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-04-28 09:06:32 --> Helper loaded: url_helper
DEBUG - 2011-04-28 09:06:32 --> File loaded: application/views/common/header.php
DEBUG - 2011-04-28 09:06:32 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-04-28 09:06:32 --> File loaded: application/views/common/footer.php
DEBUG - 2011-04-28 09:06:32 --> File loaded: application/views/layout/main.php
DEBUG - 2011-04-28 09:06:32 --> Final output sent to browser
DEBUG - 2011-04-28 09:06:32 --> Total execution time: 0.0576
DEBUG - 2011-04-28 09:06:35 --> Config Class Initialized
DEBUG - 2011-04-28 09:06:35 --> Hooks Class Initialized
DEBUG - 2011-04-28 09:06:35 --> Utf8 Class Initialized
DEBUG - 2011-04-28 09:06:35 --> UTF-8 Support Enabled
DEBUG - 2011-04-28 09:06:35 --> URI Class Initialized
DEBUG - 2011-04-28 09:06:35 --> Router Class Initialized
DEBUG - 2011-04-28 09:06:35 --> Output Class Initialized
DEBUG - 2011-04-28 09:06:35 --> Input Class Initialized
DEBUG - 2011-04-28 09:06:35 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-28 09:06:35 --> Language Class Initialized
DEBUG - 2011-04-28 09:06:35 --> Loader Class Initialized
DEBUG - 2011-04-28 09:06:35 --> Controller Class Initialized
DEBUG - 2011-04-28 09:06:35 --> Model Class Initialized
DEBUG - 2011-04-28 09:06:35 --> Model Class Initialized
DEBUG - 2011-04-28 09:06:35 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-28 09:06:35 --> Database Driver Class Initialized
DEBUG - 2011-04-28 09:06:36 --> Config Class Initialized
DEBUG - 2011-04-28 09:06:36 --> Hooks Class Initialized
DEBUG - 2011-04-28 09:06:36 --> Utf8 Class Initialized
DEBUG - 2011-04-28 09:06:36 --> UTF-8 Support Enabled
DEBUG - 2011-04-28 09:06:36 --> URI Class Initialized
DEBUG - 2011-04-28 09:06:36 --> Router Class Initialized
DEBUG - 2011-04-28 09:06:36 --> Output Class Initialized
DEBUG - 2011-04-28 09:06:36 --> Input Class Initialized
DEBUG - 2011-04-28 09:06:36 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-28 09:06:36 --> Language Class Initialized
DEBUG - 2011-04-28 09:06:36 --> Loader Class Initialized
DEBUG - 2011-04-28 09:06:36 --> Controller Class Initialized
ERROR - 2011-04-28 09:06:36 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-04-28 09:06:36 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-04-28 09:06:36 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-04-28 09:06:36 --> Model Class Initialized
DEBUG - 2011-04-28 09:06:36 --> Model Class Initialized
DEBUG - 2011-04-28 09:06:36 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-28 09:06:36 --> Database Driver Class Initialized
DEBUG - 2011-04-28 09:06:36 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-04-28 09:06:36 --> Helper loaded: url_helper
DEBUG - 2011-04-28 09:06:36 --> File loaded: application/views/common/header.php
DEBUG - 2011-04-28 09:06:36 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-04-28 09:06:36 --> File loaded: application/views/common/footer.php
DEBUG - 2011-04-28 09:06:36 --> File loaded: application/views/layout/main.php
DEBUG - 2011-04-28 09:06:36 --> Final output sent to browser
DEBUG - 2011-04-28 09:06:36 --> Total execution time: 0.0355
DEBUG - 2011-04-28 09:06:38 --> Final output sent to browser
DEBUG - 2011-04-28 09:06:38 --> Total execution time: 2.7602
DEBUG - 2011-04-28 10:26:02 --> Config Class Initialized
DEBUG - 2011-04-28 10:26:02 --> Hooks Class Initialized
DEBUG - 2011-04-28 10:26:02 --> Utf8 Class Initialized
DEBUG - 2011-04-28 10:26:02 --> UTF-8 Support Enabled
DEBUG - 2011-04-28 10:26:02 --> URI Class Initialized
DEBUG - 2011-04-28 10:26:02 --> Router Class Initialized
DEBUG - 2011-04-28 10:26:02 --> Output Class Initialized
DEBUG - 2011-04-28 10:26:02 --> Input Class Initialized
DEBUG - 2011-04-28 10:26:02 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-28 10:26:02 --> Language Class Initialized
DEBUG - 2011-04-28 10:26:02 --> Loader Class Initialized
DEBUG - 2011-04-28 10:26:02 --> Controller Class Initialized
DEBUG - 2011-04-28 10:26:02 --> Model Class Initialized
DEBUG - 2011-04-28 10:26:02 --> Model Class Initialized
DEBUG - 2011-04-28 10:26:02 --> Model Class Initialized
DEBUG - 2011-04-28 10:26:02 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-28 10:26:02 --> Database Driver Class Initialized
DEBUG - 2011-04-28 10:26:02 --> File loaded: application/views/table/main.php
DEBUG - 2011-04-28 10:26:02 --> Helper loaded: url_helper
DEBUG - 2011-04-28 10:26:02 --> File loaded: application/views/common/header.php
DEBUG - 2011-04-28 10:26:02 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-04-28 10:26:02 --> File loaded: application/views/common/footer.php
DEBUG - 2011-04-28 10:26:02 --> File loaded: application/views/layout/main.php
DEBUG - 2011-04-28 10:26:02 --> Final output sent to browser
DEBUG - 2011-04-28 10:26:02 --> Total execution time: 0.7032
DEBUG - 2011-04-28 10:26:03 --> Config Class Initialized
DEBUG - 2011-04-28 10:26:03 --> Hooks Class Initialized
DEBUG - 2011-04-28 10:26:03 --> Utf8 Class Initialized
DEBUG - 2011-04-28 10:26:03 --> UTF-8 Support Enabled
DEBUG - 2011-04-28 10:26:03 --> URI Class Initialized
DEBUG - 2011-04-28 10:26:03 --> Router Class Initialized
DEBUG - 2011-04-28 10:26:03 --> Output Class Initialized
DEBUG - 2011-04-28 10:26:03 --> Input Class Initialized
DEBUG - 2011-04-28 10:26:03 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-28 10:26:03 --> Language Class Initialized
DEBUG - 2011-04-28 10:26:03 --> Loader Class Initialized
DEBUG - 2011-04-28 10:26:03 --> Controller Class Initialized
ERROR - 2011-04-28 10:26:03 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-04-28 10:26:03 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-04-28 10:26:03 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-04-28 10:26:03 --> Model Class Initialized
DEBUG - 2011-04-28 10:26:03 --> Model Class Initialized
DEBUG - 2011-04-28 10:26:03 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-28 10:26:03 --> Database Driver Class Initialized
DEBUG - 2011-04-28 10:26:03 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-04-28 10:26:03 --> Helper loaded: url_helper
DEBUG - 2011-04-28 10:26:03 --> File loaded: application/views/common/header.php
DEBUG - 2011-04-28 10:26:03 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-04-28 10:26:03 --> File loaded: application/views/common/footer.php
DEBUG - 2011-04-28 10:26:03 --> File loaded: application/views/layout/main.php
DEBUG - 2011-04-28 10:26:03 --> Final output sent to browser
DEBUG - 2011-04-28 10:26:03 --> Total execution time: 0.1606
DEBUG - 2011-04-28 11:45:39 --> Config Class Initialized
DEBUG - 2011-04-28 11:45:39 --> Hooks Class Initialized
DEBUG - 2011-04-28 11:45:39 --> Utf8 Class Initialized
DEBUG - 2011-04-28 11:45:39 --> UTF-8 Support Enabled
DEBUG - 2011-04-28 11:45:39 --> URI Class Initialized
DEBUG - 2011-04-28 11:45:39 --> Router Class Initialized
DEBUG - 2011-04-28 11:45:39 --> No URI present. Default controller set.
DEBUG - 2011-04-28 11:45:39 --> Output Class Initialized
DEBUG - 2011-04-28 11:45:39 --> Input Class Initialized
DEBUG - 2011-04-28 11:45:39 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-28 11:45:39 --> Language Class Initialized
DEBUG - 2011-04-28 11:45:39 --> Loader Class Initialized
DEBUG - 2011-04-28 11:45:39 --> Controller Class Initialized
DEBUG - 2011-04-28 11:45:39 --> File loaded: application/views/splash/main.php
DEBUG - 2011-04-28 11:45:39 --> Helper loaded: url_helper
DEBUG - 2011-04-28 11:45:39 --> File loaded: application/views/common/header.php
DEBUG - 2011-04-28 11:45:40 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-04-28 11:45:40 --> File loaded: application/views/common/footer.php
DEBUG - 2011-04-28 11:45:40 --> File loaded: application/views/layout/main.php
DEBUG - 2011-04-28 11:45:40 --> Final output sent to browser
DEBUG - 2011-04-28 11:45:40 --> Total execution time: 0.6317
DEBUG - 2011-04-28 11:45:40 --> Config Class Initialized
DEBUG - 2011-04-28 11:45:40 --> Hooks Class Initialized
DEBUG - 2011-04-28 11:45:40 --> Utf8 Class Initialized
DEBUG - 2011-04-28 11:45:40 --> UTF-8 Support Enabled
DEBUG - 2011-04-28 11:45:40 --> URI Class Initialized
DEBUG - 2011-04-28 11:45:40 --> Router Class Initialized
DEBUG - 2011-04-28 11:45:40 --> No URI present. Default controller set.
DEBUG - 2011-04-28 11:45:40 --> Output Class Initialized
DEBUG - 2011-04-28 11:45:40 --> Input Class Initialized
DEBUG - 2011-04-28 11:45:40 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-28 11:45:40 --> Language Class Initialized
DEBUG - 2011-04-28 11:45:40 --> Loader Class Initialized
DEBUG - 2011-04-28 11:45:40 --> Controller Class Initialized
DEBUG - 2011-04-28 11:45:40 --> File loaded: application/views/splash/main.php
DEBUG - 2011-04-28 11:45:40 --> Helper loaded: url_helper
DEBUG - 2011-04-28 11:45:40 --> File loaded: application/views/common/header.php
DEBUG - 2011-04-28 11:45:40 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-04-28 11:45:40 --> File loaded: application/views/common/footer.php
DEBUG - 2011-04-28 11:45:40 --> File loaded: application/views/layout/main.php
DEBUG - 2011-04-28 11:45:40 --> Final output sent to browser
DEBUG - 2011-04-28 11:45:40 --> Total execution time: 0.0412
DEBUG - 2011-04-28 13:04:20 --> Config Class Initialized
DEBUG - 2011-04-28 13:04:20 --> Hooks Class Initialized
DEBUG - 2011-04-28 13:04:20 --> Utf8 Class Initialized
DEBUG - 2011-04-28 13:04:20 --> UTF-8 Support Enabled
DEBUG - 2011-04-28 13:04:20 --> URI Class Initialized
DEBUG - 2011-04-28 13:04:20 --> Router Class Initialized
DEBUG - 2011-04-28 13:04:20 --> Output Class Initialized
DEBUG - 2011-04-28 13:04:21 --> Input Class Initialized
DEBUG - 2011-04-28 13:04:21 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-28 13:04:21 --> Language Class Initialized
DEBUG - 2011-04-28 13:04:21 --> Loader Class Initialized
DEBUG - 2011-04-28 13:04:21 --> Controller Class Initialized
DEBUG - 2011-04-28 13:04:21 --> Model Class Initialized
DEBUG - 2011-04-28 13:04:21 --> Model Class Initialized
DEBUG - 2011-04-28 13:04:21 --> Model Class Initialized
DEBUG - 2011-04-28 13:04:22 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-28 13:04:23 --> Database Driver Class Initialized
DEBUG - 2011-04-28 13:04:23 --> File loaded: application/views/table/main.php
DEBUG - 2011-04-28 13:04:24 --> Helper loaded: url_helper
DEBUG - 2011-04-28 13:04:24 --> File loaded: application/views/common/header.php
DEBUG - 2011-04-28 13:04:24 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-04-28 13:04:24 --> File loaded: application/views/common/footer.php
DEBUG - 2011-04-28 13:04:24 --> File loaded: application/views/layout/main.php
DEBUG - 2011-04-28 13:04:24 --> Final output sent to browser
DEBUG - 2011-04-28 13:04:24 --> Total execution time: 4.1126
DEBUG - 2011-04-28 13:04:25 --> Config Class Initialized
DEBUG - 2011-04-28 13:04:25 --> Hooks Class Initialized
DEBUG - 2011-04-28 13:04:25 --> Utf8 Class Initialized
DEBUG - 2011-04-28 13:04:25 --> UTF-8 Support Enabled
DEBUG - 2011-04-28 13:04:25 --> URI Class Initialized
DEBUG - 2011-04-28 13:04:25 --> Router Class Initialized
DEBUG - 2011-04-28 13:04:25 --> Output Class Initialized
DEBUG - 2011-04-28 13:04:25 --> Input Class Initialized
DEBUG - 2011-04-28 13:04:25 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-28 13:04:25 --> Language Class Initialized
DEBUG - 2011-04-28 13:04:25 --> Loader Class Initialized
DEBUG - 2011-04-28 13:04:25 --> Controller Class Initialized
ERROR - 2011-04-28 13:04:25 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-04-28 13:04:25 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-04-28 13:04:25 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-04-28 13:04:25 --> Model Class Initialized
DEBUG - 2011-04-28 13:04:25 --> Model Class Initialized
DEBUG - 2011-04-28 13:04:25 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-28 13:04:25 --> Database Driver Class Initialized
DEBUG - 2011-04-28 13:04:25 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-04-28 13:04:25 --> Helper loaded: url_helper
DEBUG - 2011-04-28 13:04:25 --> File loaded: application/views/common/header.php
DEBUG - 2011-04-28 13:04:25 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-04-28 13:04:25 --> File loaded: application/views/common/footer.php
DEBUG - 2011-04-28 13:04:25 --> File loaded: application/views/layout/main.php
DEBUG - 2011-04-28 13:04:25 --> Final output sent to browser
DEBUG - 2011-04-28 13:04:25 --> Total execution time: 0.3107
DEBUG - 2011-04-28 14:45:32 --> Config Class Initialized
DEBUG - 2011-04-28 14:45:32 --> Hooks Class Initialized
DEBUG - 2011-04-28 14:45:32 --> Utf8 Class Initialized
DEBUG - 2011-04-28 14:45:32 --> UTF-8 Support Enabled
DEBUG - 2011-04-28 14:45:32 --> URI Class Initialized
DEBUG - 2011-04-28 14:45:32 --> Router Class Initialized
ERROR - 2011-04-28 14:45:32 --> 404 Page Not Found --> robots.txt
DEBUG - 2011-04-28 14:45:32 --> Config Class Initialized
DEBUG - 2011-04-28 14:45:32 --> Hooks Class Initialized
DEBUG - 2011-04-28 14:45:32 --> Utf8 Class Initialized
DEBUG - 2011-04-28 14:45:32 --> UTF-8 Support Enabled
DEBUG - 2011-04-28 14:45:32 --> URI Class Initialized
DEBUG - 2011-04-28 14:45:32 --> Router Class Initialized
DEBUG - 2011-04-28 14:45:32 --> Output Class Initialized
DEBUG - 2011-04-28 14:45:32 --> Input Class Initialized
DEBUG - 2011-04-28 14:45:32 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-28 14:45:32 --> Language Class Initialized
DEBUG - 2011-04-28 14:45:32 --> Loader Class Initialized
DEBUG - 2011-04-28 14:45:32 --> Controller Class Initialized
DEBUG - 2011-04-28 14:45:32 --> Model Class Initialized
DEBUG - 2011-04-28 14:45:32 --> Model Class Initialized
DEBUG - 2011-04-28 14:45:32 --> Model Class Initialized
DEBUG - 2011-04-28 14:45:32 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-28 14:45:32 --> Database Driver Class Initialized
DEBUG - 2011-04-28 14:45:32 --> File loaded: application/views/table/main.php
DEBUG - 2011-04-28 14:45:32 --> Helper loaded: url_helper
DEBUG - 2011-04-28 14:45:32 --> File loaded: application/views/common/header.php
DEBUG - 2011-04-28 14:45:32 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-04-28 14:45:32 --> File loaded: application/views/common/footer.php
DEBUG - 2011-04-28 14:45:32 --> File loaded: application/views/layout/main.php
DEBUG - 2011-04-28 14:45:32 --> Final output sent to browser
DEBUG - 2011-04-28 14:45:32 --> Total execution time: 0.5100
DEBUG - 2011-04-28 15:30:21 --> Config Class Initialized
DEBUG - 2011-04-28 15:30:21 --> Hooks Class Initialized
DEBUG - 2011-04-28 15:30:21 --> Utf8 Class Initialized
DEBUG - 2011-04-28 15:30:21 --> UTF-8 Support Enabled
DEBUG - 2011-04-28 15:30:21 --> URI Class Initialized
DEBUG - 2011-04-28 15:30:21 --> Router Class Initialized
DEBUG - 2011-04-28 15:30:22 --> Output Class Initialized
DEBUG - 2011-04-28 15:30:22 --> Input Class Initialized
DEBUG - 2011-04-28 15:30:22 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-28 15:30:23 --> Language Class Initialized
DEBUG - 2011-04-28 15:30:23 --> Loader Class Initialized
DEBUG - 2011-04-28 15:30:23 --> Controller Class Initialized
DEBUG - 2011-04-28 15:30:23 --> Model Class Initialized
DEBUG - 2011-04-28 15:30:23 --> Model Class Initialized
DEBUG - 2011-04-28 15:30:23 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-28 15:30:24 --> Database Driver Class Initialized
DEBUG - 2011-04-28 15:30:24 --> Final output sent to browser
DEBUG - 2011-04-28 15:30:24 --> Total execution time: 2.9063
DEBUG - 2011-04-28 15:41:55 --> Config Class Initialized
DEBUG - 2011-04-28 15:41:55 --> Hooks Class Initialized
DEBUG - 2011-04-28 15:41:55 --> Utf8 Class Initialized
DEBUG - 2011-04-28 15:41:55 --> UTF-8 Support Enabled
DEBUG - 2011-04-28 15:41:55 --> URI Class Initialized
DEBUG - 2011-04-28 15:41:55 --> Router Class Initialized
DEBUG - 2011-04-28 15:41:55 --> Output Class Initialized
DEBUG - 2011-04-28 15:41:55 --> Input Class Initialized
DEBUG - 2011-04-28 15:41:55 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-28 15:41:55 --> Language Class Initialized
DEBUG - 2011-04-28 15:41:55 --> Loader Class Initialized
DEBUG - 2011-04-28 15:41:55 --> Controller Class Initialized
DEBUG - 2011-04-28 15:41:55 --> Model Class Initialized
DEBUG - 2011-04-28 15:41:55 --> Model Class Initialized
DEBUG - 2011-04-28 15:41:55 --> Model Class Initialized
DEBUG - 2011-04-28 15:41:55 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-28 15:41:55 --> Database Driver Class Initialized
DEBUG - 2011-04-28 15:41:56 --> File loaded: application/views/table/main.php
DEBUG - 2011-04-28 15:41:56 --> Helper loaded: url_helper
DEBUG - 2011-04-28 15:41:56 --> File loaded: application/views/common/header.php
DEBUG - 2011-04-28 15:41:56 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-04-28 15:41:56 --> File loaded: application/views/common/footer.php
DEBUG - 2011-04-28 15:41:56 --> File loaded: application/views/layout/main.php
DEBUG - 2011-04-28 15:41:56 --> Final output sent to browser
DEBUG - 2011-04-28 15:41:56 --> Total execution time: 0.7475
DEBUG - 2011-04-28 15:42:01 --> Config Class Initialized
DEBUG - 2011-04-28 15:42:01 --> Hooks Class Initialized
DEBUG - 2011-04-28 15:42:01 --> Utf8 Class Initialized
DEBUG - 2011-04-28 15:42:01 --> UTF-8 Support Enabled
DEBUG - 2011-04-28 15:42:01 --> URI Class Initialized
DEBUG - 2011-04-28 15:42:01 --> Router Class Initialized
DEBUG - 2011-04-28 15:42:01 --> Output Class Initialized
DEBUG - 2011-04-28 15:42:01 --> Input Class Initialized
DEBUG - 2011-04-28 15:42:01 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-28 15:42:01 --> Language Class Initialized
DEBUG - 2011-04-28 15:42:01 --> Loader Class Initialized
DEBUG - 2011-04-28 15:42:01 --> Controller Class Initialized
ERROR - 2011-04-28 15:42:01 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-04-28 15:42:01 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-04-28 15:42:01 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-04-28 15:42:01 --> Model Class Initialized
DEBUG - 2011-04-28 15:42:01 --> Model Class Initialized
DEBUG - 2011-04-28 15:42:01 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-28 15:42:01 --> Database Driver Class Initialized
DEBUG - 2011-04-28 15:42:01 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-04-28 15:42:01 --> Helper loaded: url_helper
DEBUG - 2011-04-28 15:42:01 --> File loaded: application/views/common/header.php
DEBUG - 2011-04-28 15:42:01 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-04-28 15:42:01 --> File loaded: application/views/common/footer.php
DEBUG - 2011-04-28 15:42:01 --> File loaded: application/views/layout/main.php
DEBUG - 2011-04-28 15:42:01 --> Final output sent to browser
DEBUG - 2011-04-28 15:42:01 --> Total execution time: 0.1052
DEBUG - 2011-04-28 16:20:45 --> Config Class Initialized
DEBUG - 2011-04-28 16:20:45 --> Hooks Class Initialized
DEBUG - 2011-04-28 16:20:45 --> Utf8 Class Initialized
DEBUG - 2011-04-28 16:20:45 --> UTF-8 Support Enabled
DEBUG - 2011-04-28 16:20:45 --> URI Class Initialized
DEBUG - 2011-04-28 16:20:45 --> Router Class Initialized
DEBUG - 2011-04-28 16:20:45 --> Output Class Initialized
DEBUG - 2011-04-28 16:20:45 --> Input Class Initialized
DEBUG - 2011-04-28 16:20:45 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-28 16:20:45 --> Language Class Initialized
DEBUG - 2011-04-28 16:20:45 --> Loader Class Initialized
DEBUG - 2011-04-28 16:20:45 --> Controller Class Initialized
DEBUG - 2011-04-28 16:20:45 --> Model Class Initialized
DEBUG - 2011-04-28 16:20:45 --> Model Class Initialized
DEBUG - 2011-04-28 16:20:45 --> Model Class Initialized
DEBUG - 2011-04-28 16:20:45 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-28 16:20:45 --> Database Driver Class Initialized
DEBUG - 2011-04-28 16:20:45 --> File loaded: application/views/table/main.php
DEBUG - 2011-04-28 16:20:46 --> Helper loaded: url_helper
DEBUG - 2011-04-28 16:20:46 --> File loaded: application/views/common/header.php
DEBUG - 2011-04-28 16:20:46 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-04-28 16:20:46 --> File loaded: application/views/common/footer.php
DEBUG - 2011-04-28 16:20:46 --> File loaded: application/views/layout/main.php
DEBUG - 2011-04-28 16:20:46 --> Final output sent to browser
DEBUG - 2011-04-28 16:20:46 --> Total execution time: 0.6628
DEBUG - 2011-04-28 16:20:55 --> Config Class Initialized
DEBUG - 2011-04-28 16:20:55 --> Hooks Class Initialized
DEBUG - 2011-04-28 16:20:55 --> Utf8 Class Initialized
DEBUG - 2011-04-28 16:20:55 --> UTF-8 Support Enabled
DEBUG - 2011-04-28 16:20:55 --> URI Class Initialized
DEBUG - 2011-04-28 16:20:55 --> Router Class Initialized
DEBUG - 2011-04-28 16:20:55 --> Output Class Initialized
DEBUG - 2011-04-28 16:20:55 --> Input Class Initialized
DEBUG - 2011-04-28 16:20:55 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-28 16:20:55 --> Language Class Initialized
DEBUG - 2011-04-28 16:20:55 --> Loader Class Initialized
DEBUG - 2011-04-28 16:20:55 --> Controller Class Initialized
ERROR - 2011-04-28 16:20:55 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-04-28 16:20:55 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-04-28 16:20:55 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-04-28 16:20:55 --> Model Class Initialized
DEBUG - 2011-04-28 16:20:55 --> Model Class Initialized
DEBUG - 2011-04-28 16:20:55 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-28 16:20:56 --> Database Driver Class Initialized
DEBUG - 2011-04-28 16:20:56 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-04-28 16:20:56 --> Helper loaded: url_helper
DEBUG - 2011-04-28 16:20:56 --> File loaded: application/views/common/header.php
DEBUG - 2011-04-28 16:20:56 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-04-28 16:20:56 --> File loaded: application/views/common/footer.php
DEBUG - 2011-04-28 16:20:56 --> File loaded: application/views/layout/main.php
DEBUG - 2011-04-28 16:20:56 --> Final output sent to browser
DEBUG - 2011-04-28 16:20:56 --> Total execution time: 0.1034
DEBUG - 2011-04-28 17:11:39 --> Config Class Initialized
DEBUG - 2011-04-28 17:11:39 --> Hooks Class Initialized
DEBUG - 2011-04-28 17:11:39 --> Utf8 Class Initialized
DEBUG - 2011-04-28 17:11:39 --> UTF-8 Support Enabled
DEBUG - 2011-04-28 17:11:39 --> URI Class Initialized
DEBUG - 2011-04-28 17:11:39 --> Router Class Initialized
ERROR - 2011-04-28 17:11:39 --> 404 Page Not Found --> robots.txt
DEBUG - 2011-04-28 17:14:38 --> Config Class Initialized
DEBUG - 2011-04-28 17:14:38 --> Hooks Class Initialized
DEBUG - 2011-04-28 17:14:38 --> Utf8 Class Initialized
DEBUG - 2011-04-28 17:14:38 --> UTF-8 Support Enabled
DEBUG - 2011-04-28 17:14:38 --> URI Class Initialized
DEBUG - 2011-04-28 17:14:38 --> Router Class Initialized
DEBUG - 2011-04-28 17:14:38 --> Output Class Initialized
DEBUG - 2011-04-28 17:14:38 --> Input Class Initialized
DEBUG - 2011-04-28 17:14:38 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-28 17:14:38 --> Language Class Initialized
DEBUG - 2011-04-28 17:14:39 --> Loader Class Initialized
DEBUG - 2011-04-28 17:14:39 --> Controller Class Initialized
DEBUG - 2011-04-28 17:14:39 --> Model Class Initialized
DEBUG - 2011-04-28 17:14:39 --> Model Class Initialized
DEBUG - 2011-04-28 17:14:39 --> Model Class Initialized
DEBUG - 2011-04-28 17:14:39 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-28 17:14:39 --> Database Driver Class Initialized
DEBUG - 2011-04-28 17:14:39 --> File loaded: application/views/table/main.php
DEBUG - 2011-04-28 17:14:39 --> Helper loaded: url_helper
DEBUG - 2011-04-28 17:14:39 --> File loaded: application/views/common/header.php
DEBUG - 2011-04-28 17:14:39 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-04-28 17:14:39 --> File loaded: application/views/common/footer.php
DEBUG - 2011-04-28 17:14:39 --> File loaded: application/views/layout/main.php
DEBUG - 2011-04-28 17:14:39 --> Final output sent to browser
DEBUG - 2011-04-28 17:14:39 --> Total execution time: 1.7700
DEBUG - 2011-04-28 17:14:40 --> Config Class Initialized
DEBUG - 2011-04-28 17:14:40 --> Hooks Class Initialized
DEBUG - 2011-04-28 17:14:40 --> Utf8 Class Initialized
DEBUG - 2011-04-28 17:14:40 --> UTF-8 Support Enabled
DEBUG - 2011-04-28 17:14:40 --> URI Class Initialized
DEBUG - 2011-04-28 17:14:40 --> Router Class Initialized
DEBUG - 2011-04-28 17:14:40 --> Output Class Initialized
DEBUG - 2011-04-28 17:14:40 --> Input Class Initialized
DEBUG - 2011-04-28 17:14:40 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-28 17:14:40 --> Language Class Initialized
DEBUG - 2011-04-28 17:14:40 --> Loader Class Initialized
DEBUG - 2011-04-28 17:14:40 --> Controller Class Initialized
ERROR - 2011-04-28 17:14:41 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-04-28 17:14:41 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-04-28 17:14:41 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-04-28 17:14:41 --> Model Class Initialized
DEBUG - 2011-04-28 17:14:41 --> Model Class Initialized
DEBUG - 2011-04-28 17:14:41 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-28 17:14:41 --> Database Driver Class Initialized
DEBUG - 2011-04-28 17:14:41 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-04-28 17:14:41 --> Helper loaded: url_helper
DEBUG - 2011-04-28 17:14:41 --> File loaded: application/views/common/header.php
DEBUG - 2011-04-28 17:14:41 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-04-28 17:14:41 --> File loaded: application/views/common/footer.php
DEBUG - 2011-04-28 17:14:41 --> File loaded: application/views/layout/main.php
DEBUG - 2011-04-28 17:14:41 --> Final output sent to browser
DEBUG - 2011-04-28 17:14:41 --> Total execution time: 0.1026
DEBUG - 2011-04-28 17:17:31 --> Config Class Initialized
DEBUG - 2011-04-28 17:17:31 --> Hooks Class Initialized
DEBUG - 2011-04-28 17:17:31 --> Utf8 Class Initialized
DEBUG - 2011-04-28 17:17:31 --> UTF-8 Support Enabled
DEBUG - 2011-04-28 17:17:31 --> URI Class Initialized
DEBUG - 2011-04-28 17:17:31 --> Router Class Initialized
DEBUG - 2011-04-28 17:17:31 --> Output Class Initialized
DEBUG - 2011-04-28 17:17:31 --> Input Class Initialized
DEBUG - 2011-04-28 17:17:31 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-28 17:17:31 --> Language Class Initialized
DEBUG - 2011-04-28 17:17:31 --> Loader Class Initialized
DEBUG - 2011-04-28 17:17:31 --> Controller Class Initialized
DEBUG - 2011-04-28 17:17:31 --> Model Class Initialized
DEBUG - 2011-04-28 17:17:31 --> Model Class Initialized
DEBUG - 2011-04-28 17:17:31 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-28 17:17:31 --> Database Driver Class Initialized
DEBUG - 2011-04-28 17:17:32 --> Final output sent to browser
DEBUG - 2011-04-28 17:17:32 --> Total execution time: 0.8518
DEBUG - 2011-04-28 18:19:15 --> Config Class Initialized
DEBUG - 2011-04-28 18:19:15 --> Hooks Class Initialized
DEBUG - 2011-04-28 18:19:15 --> Utf8 Class Initialized
DEBUG - 2011-04-28 18:19:15 --> UTF-8 Support Enabled
DEBUG - 2011-04-28 18:19:15 --> URI Class Initialized
DEBUG - 2011-04-28 18:19:15 --> Router Class Initialized
DEBUG - 2011-04-28 18:19:15 --> Output Class Initialized
DEBUG - 2011-04-28 18:19:15 --> Input Class Initialized
DEBUG - 2011-04-28 18:19:15 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-28 18:19:15 --> Language Class Initialized
DEBUG - 2011-04-28 18:19:15 --> Loader Class Initialized
DEBUG - 2011-04-28 18:19:15 --> Controller Class Initialized
DEBUG - 2011-04-28 18:19:15 --> Model Class Initialized
DEBUG - 2011-04-28 18:19:15 --> Model Class Initialized
DEBUG - 2011-04-28 18:19:15 --> Model Class Initialized
DEBUG - 2011-04-28 18:19:15 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-28 18:19:15 --> Database Driver Class Initialized
DEBUG - 2011-04-28 18:19:16 --> File loaded: application/views/table/main.php
DEBUG - 2011-04-28 18:19:16 --> Helper loaded: url_helper
DEBUG - 2011-04-28 18:19:16 --> File loaded: application/views/common/header.php
DEBUG - 2011-04-28 18:19:16 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-04-28 18:19:16 --> File loaded: application/views/common/footer.php
DEBUG - 2011-04-28 18:19:16 --> File loaded: application/views/layout/main.php
DEBUG - 2011-04-28 18:19:16 --> Final output sent to browser
DEBUG - 2011-04-28 18:19:16 --> Total execution time: 1.1689
DEBUG - 2011-04-28 18:19:17 --> Config Class Initialized
DEBUG - 2011-04-28 18:19:17 --> Hooks Class Initialized
DEBUG - 2011-04-28 18:19:17 --> Utf8 Class Initialized
DEBUG - 2011-04-28 18:19:17 --> UTF-8 Support Enabled
DEBUG - 2011-04-28 18:19:17 --> URI Class Initialized
DEBUG - 2011-04-28 18:19:17 --> Router Class Initialized
DEBUG - 2011-04-28 18:19:17 --> Output Class Initialized
DEBUG - 2011-04-28 18:19:17 --> Input Class Initialized
DEBUG - 2011-04-28 18:19:17 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-28 18:19:17 --> Language Class Initialized
DEBUG - 2011-04-28 18:19:17 --> Loader Class Initialized
DEBUG - 2011-04-28 18:19:17 --> Controller Class Initialized
ERROR - 2011-04-28 18:19:17 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-04-28 18:19:17 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-04-28 18:19:17 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-04-28 18:19:17 --> Model Class Initialized
DEBUG - 2011-04-28 18:19:17 --> Model Class Initialized
DEBUG - 2011-04-28 18:19:17 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-28 18:19:17 --> Database Driver Class Initialized
DEBUG - 2011-04-28 18:19:17 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-04-28 18:19:17 --> Helper loaded: url_helper
DEBUG - 2011-04-28 18:19:17 --> File loaded: application/views/common/header.php
DEBUG - 2011-04-28 18:19:17 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-04-28 18:19:17 --> File loaded: application/views/common/footer.php
DEBUG - 2011-04-28 18:19:17 --> File loaded: application/views/layout/main.php
DEBUG - 2011-04-28 18:19:17 --> Final output sent to browser
DEBUG - 2011-04-28 18:19:17 --> Total execution time: 0.0941
DEBUG - 2011-04-28 20:58:59 --> Config Class Initialized
DEBUG - 2011-04-28 20:58:59 --> Hooks Class Initialized
DEBUG - 2011-04-28 20:58:59 --> Utf8 Class Initialized
DEBUG - 2011-04-28 20:58:59 --> UTF-8 Support Enabled
DEBUG - 2011-04-28 20:58:59 --> URI Class Initialized
DEBUG - 2011-04-28 20:58:59 --> Router Class Initialized
DEBUG - 2011-04-28 20:58:59 --> Output Class Initialized
DEBUG - 2011-04-28 20:58:59 --> Input Class Initialized
DEBUG - 2011-04-28 20:58:59 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-28 20:58:59 --> Language Class Initialized
DEBUG - 2011-04-28 20:58:59 --> Loader Class Initialized
DEBUG - 2011-04-28 20:58:59 --> Controller Class Initialized
DEBUG - 2011-04-28 20:58:59 --> Model Class Initialized
DEBUG - 2011-04-28 20:58:59 --> Model Class Initialized
DEBUG - 2011-04-28 20:58:59 --> Model Class Initialized
DEBUG - 2011-04-28 20:58:59 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-28 20:58:59 --> Database Driver Class Initialized
DEBUG - 2011-04-28 20:59:00 --> File loaded: application/views/table/main.php
DEBUG - 2011-04-28 20:59:00 --> Helper loaded: url_helper
DEBUG - 2011-04-28 20:59:00 --> File loaded: application/views/common/header.php
DEBUG - 2011-04-28 20:59:00 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-04-28 20:59:00 --> File loaded: application/views/common/footer.php
DEBUG - 2011-04-28 20:59:00 --> File loaded: application/views/layout/main.php
DEBUG - 2011-04-28 20:59:00 --> Final output sent to browser
DEBUG - 2011-04-28 20:59:00 --> Total execution time: 1.1483
DEBUG - 2011-04-28 20:59:01 --> Config Class Initialized
DEBUG - 2011-04-28 20:59:01 --> Hooks Class Initialized
DEBUG - 2011-04-28 20:59:01 --> Utf8 Class Initialized
DEBUG - 2011-04-28 20:59:01 --> UTF-8 Support Enabled
DEBUG - 2011-04-28 20:59:01 --> URI Class Initialized
DEBUG - 2011-04-28 20:59:01 --> Router Class Initialized
DEBUG - 2011-04-28 20:59:01 --> Output Class Initialized
DEBUG - 2011-04-28 20:59:01 --> Input Class Initialized
DEBUG - 2011-04-28 20:59:01 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-28 20:59:01 --> Language Class Initialized
DEBUG - 2011-04-28 20:59:01 --> Loader Class Initialized
DEBUG - 2011-04-28 20:59:01 --> Controller Class Initialized
ERROR - 2011-04-28 20:59:01 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-04-28 20:59:01 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-04-28 20:59:01 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-04-28 20:59:01 --> Model Class Initialized
DEBUG - 2011-04-28 20:59:01 --> Model Class Initialized
DEBUG - 2011-04-28 20:59:01 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-28 20:59:01 --> Database Driver Class Initialized
DEBUG - 2011-04-28 20:59:01 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-04-28 20:59:01 --> Helper loaded: url_helper
DEBUG - 2011-04-28 20:59:01 --> File loaded: application/views/common/header.php
DEBUG - 2011-04-28 20:59:01 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-04-28 20:59:01 --> File loaded: application/views/common/footer.php
DEBUG - 2011-04-28 20:59:01 --> File loaded: application/views/layout/main.php
DEBUG - 2011-04-28 20:59:01 --> Final output sent to browser
DEBUG - 2011-04-28 20:59:01 --> Total execution time: 0.1394
DEBUG - 2011-04-28 22:23:12 --> Config Class Initialized
DEBUG - 2011-04-28 22:23:12 --> Hooks Class Initialized
DEBUG - 2011-04-28 22:23:12 --> Utf8 Class Initialized
DEBUG - 2011-04-28 22:23:12 --> UTF-8 Support Enabled
DEBUG - 2011-04-28 22:23:12 --> URI Class Initialized
DEBUG - 2011-04-28 22:23:12 --> Router Class Initialized
ERROR - 2011-04-28 22:23:12 --> 404 Page Not Found --> robots.txt
DEBUG - 2011-04-28 22:24:11 --> Config Class Initialized
DEBUG - 2011-04-28 22:24:11 --> Hooks Class Initialized
DEBUG - 2011-04-28 22:24:11 --> Utf8 Class Initialized
DEBUG - 2011-04-28 22:24:11 --> UTF-8 Support Enabled
DEBUG - 2011-04-28 22:24:11 --> URI Class Initialized
DEBUG - 2011-04-28 22:24:11 --> Router Class Initialized
DEBUG - 2011-04-28 22:24:11 --> No URI present. Default controller set.
DEBUG - 2011-04-28 22:24:11 --> Output Class Initialized
DEBUG - 2011-04-28 22:24:11 --> Input Class Initialized
DEBUG - 2011-04-28 22:24:11 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-28 22:24:11 --> Language Class Initialized
DEBUG - 2011-04-28 22:24:11 --> Loader Class Initialized
DEBUG - 2011-04-28 22:24:11 --> Controller Class Initialized
DEBUG - 2011-04-28 22:24:11 --> File loaded: application/views/splash/main.php
DEBUG - 2011-04-28 22:24:11 --> Helper loaded: url_helper
DEBUG - 2011-04-28 22:24:11 --> File loaded: application/views/common/header.php
DEBUG - 2011-04-28 22:24:11 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-04-28 22:24:11 --> File loaded: application/views/common/footer.php
DEBUG - 2011-04-28 22:24:11 --> File loaded: application/views/layout/main.php
DEBUG - 2011-04-28 22:24:11 --> Final output sent to browser
DEBUG - 2011-04-28 22:24:11 --> Total execution time: 0.2646
DEBUG - 2011-04-28 22:25:51 --> Config Class Initialized
DEBUG - 2011-04-28 22:25:51 --> Hooks Class Initialized
DEBUG - 2011-04-28 22:25:51 --> Utf8 Class Initialized
DEBUG - 2011-04-28 22:25:51 --> UTF-8 Support Enabled
DEBUG - 2011-04-28 22:25:51 --> URI Class Initialized
DEBUG - 2011-04-28 22:25:51 --> Router Class Initialized
DEBUG - 2011-04-28 22:25:51 --> Output Class Initialized
DEBUG - 2011-04-28 22:25:51 --> Input Class Initialized
DEBUG - 2011-04-28 22:25:51 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-28 22:25:51 --> Language Class Initialized
DEBUG - 2011-04-28 22:25:51 --> Loader Class Initialized
DEBUG - 2011-04-28 22:25:51 --> Controller Class Initialized
ERROR - 2011-04-28 22:25:51 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-04-28 22:25:51 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-04-28 22:25:51 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-04-28 22:25:51 --> Model Class Initialized
DEBUG - 2011-04-28 22:25:51 --> Model Class Initialized
DEBUG - 2011-04-28 22:25:51 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-28 22:25:51 --> Database Driver Class Initialized
DEBUG - 2011-04-28 22:25:51 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-04-28 22:25:51 --> Helper loaded: url_helper
DEBUG - 2011-04-28 22:25:51 --> File loaded: application/views/common/header.php
DEBUG - 2011-04-28 22:25:51 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-04-28 22:25:51 --> File loaded: application/views/common/footer.php
DEBUG - 2011-04-28 22:25:51 --> File loaded: application/views/layout/main.php
DEBUG - 2011-04-28 22:25:51 --> Final output sent to browser
DEBUG - 2011-04-28 22:25:51 --> Total execution time: 0.1837
DEBUG - 2011-04-28 22:25:53 --> Config Class Initialized
DEBUG - 2011-04-28 22:25:53 --> Hooks Class Initialized
DEBUG - 2011-04-28 22:25:53 --> Utf8 Class Initialized
DEBUG - 2011-04-28 22:25:53 --> UTF-8 Support Enabled
DEBUG - 2011-04-28 22:25:53 --> URI Class Initialized
DEBUG - 2011-04-28 22:25:53 --> Router Class Initialized
DEBUG - 2011-04-28 22:25:53 --> Output Class Initialized
DEBUG - 2011-04-28 22:25:53 --> Input Class Initialized
DEBUG - 2011-04-28 22:25:53 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-28 22:25:53 --> Language Class Initialized
DEBUG - 2011-04-28 22:25:53 --> Loader Class Initialized
DEBUG - 2011-04-28 22:25:53 --> Controller Class Initialized
DEBUG - 2011-04-28 22:25:53 --> Model Class Initialized
DEBUG - 2011-04-28 22:25:53 --> Model Class Initialized
DEBUG - 2011-04-28 22:25:53 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-28 22:25:53 --> Database Driver Class Initialized
DEBUG - 2011-04-28 22:25:53 --> Config Class Initialized
DEBUG - 2011-04-28 22:25:53 --> Hooks Class Initialized
DEBUG - 2011-04-28 22:25:53 --> Utf8 Class Initialized
DEBUG - 2011-04-28 22:25:53 --> UTF-8 Support Enabled
DEBUG - 2011-04-28 22:25:54 --> URI Class Initialized
DEBUG - 2011-04-28 22:25:54 --> Router Class Initialized
DEBUG - 2011-04-28 22:25:54 --> Output Class Initialized
DEBUG - 2011-04-28 22:25:54 --> Input Class Initialized
DEBUG - 2011-04-28 22:25:54 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-28 22:25:54 --> Language Class Initialized
DEBUG - 2011-04-28 22:25:54 --> Loader Class Initialized
DEBUG - 2011-04-28 22:25:54 --> Controller Class Initialized
ERROR - 2011-04-28 22:25:54 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-04-28 22:25:54 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-04-28 22:25:54 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-04-28 22:25:54 --> Model Class Initialized
DEBUG - 2011-04-28 22:25:54 --> Model Class Initialized
DEBUG - 2011-04-28 22:25:54 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-28 22:25:54 --> Database Driver Class Initialized
DEBUG - 2011-04-28 22:25:54 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-04-28 22:25:54 --> Helper loaded: url_helper
DEBUG - 2011-04-28 22:25:54 --> File loaded: application/views/common/header.php
DEBUG - 2011-04-28 22:25:54 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-04-28 22:25:54 --> File loaded: application/views/common/footer.php
DEBUG - 2011-04-28 22:25:54 --> File loaded: application/views/layout/main.php
DEBUG - 2011-04-28 22:25:54 --> Final output sent to browser
DEBUG - 2011-04-28 22:25:54 --> Total execution time: 0.0319
DEBUG - 2011-04-28 22:25:54 --> Final output sent to browser
DEBUG - 2011-04-28 22:25:54 --> Total execution time: 0.6735
DEBUG - 2011-04-28 22:25:55 --> Config Class Initialized
DEBUG - 2011-04-28 22:25:55 --> Hooks Class Initialized
DEBUG - 2011-04-28 22:25:55 --> Utf8 Class Initialized
DEBUG - 2011-04-28 22:25:55 --> UTF-8 Support Enabled
DEBUG - 2011-04-28 22:25:55 --> URI Class Initialized
DEBUG - 2011-04-28 22:25:55 --> Router Class Initialized
DEBUG - 2011-04-28 22:25:55 --> Output Class Initialized
DEBUG - 2011-04-28 22:25:55 --> Input Class Initialized
DEBUG - 2011-04-28 22:25:55 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-28 22:25:55 --> Language Class Initialized
DEBUG - 2011-04-28 22:25:55 --> Loader Class Initialized
DEBUG - 2011-04-28 22:25:55 --> Controller Class Initialized
ERROR - 2011-04-28 22:25:55 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-04-28 22:25:55 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-04-28 22:25:55 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-04-28 22:25:55 --> Model Class Initialized
DEBUG - 2011-04-28 22:25:55 --> Model Class Initialized
DEBUG - 2011-04-28 22:25:55 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-28 22:25:55 --> Database Driver Class Initialized
DEBUG - 2011-04-28 22:25:55 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-04-28 22:25:55 --> Helper loaded: url_helper
DEBUG - 2011-04-28 22:25:55 --> File loaded: application/views/common/header.php
DEBUG - 2011-04-28 22:25:55 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-04-28 22:25:55 --> File loaded: application/views/common/footer.php
DEBUG - 2011-04-28 22:25:55 --> File loaded: application/views/layout/main.php
DEBUG - 2011-04-28 22:25:55 --> Final output sent to browser
DEBUG - 2011-04-28 22:25:55 --> Total execution time: 0.0445
DEBUG - 2011-04-28 22:25:56 --> Config Class Initialized
DEBUG - 2011-04-28 22:25:56 --> Hooks Class Initialized
DEBUG - 2011-04-28 22:25:56 --> Utf8 Class Initialized
DEBUG - 2011-04-28 22:25:56 --> UTF-8 Support Enabled
DEBUG - 2011-04-28 22:25:56 --> URI Class Initialized
DEBUG - 2011-04-28 22:25:56 --> Router Class Initialized
ERROR - 2011-04-28 22:25:56 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-04-28 22:25:56 --> Config Class Initialized
DEBUG - 2011-04-28 22:25:56 --> Hooks Class Initialized
DEBUG - 2011-04-28 22:25:56 --> Utf8 Class Initialized
DEBUG - 2011-04-28 22:25:56 --> UTF-8 Support Enabled
DEBUG - 2011-04-28 22:25:56 --> URI Class Initialized
DEBUG - 2011-04-28 22:25:56 --> Router Class Initialized
ERROR - 2011-04-28 22:25:56 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-04-28 22:25:57 --> Config Class Initialized
DEBUG - 2011-04-28 22:25:57 --> Hooks Class Initialized
DEBUG - 2011-04-28 22:25:57 --> Utf8 Class Initialized
DEBUG - 2011-04-28 22:25:57 --> UTF-8 Support Enabled
DEBUG - 2011-04-28 22:25:57 --> URI Class Initialized
DEBUG - 2011-04-28 22:25:57 --> Router Class Initialized
ERROR - 2011-04-28 22:25:57 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-04-28 23:11:42 --> Config Class Initialized
DEBUG - 2011-04-28 23:11:42 --> Hooks Class Initialized
DEBUG - 2011-04-28 23:11:42 --> Utf8 Class Initialized
DEBUG - 2011-04-28 23:11:42 --> UTF-8 Support Enabled
DEBUG - 2011-04-28 23:11:43 --> URI Class Initialized
DEBUG - 2011-04-28 23:11:43 --> Router Class Initialized
DEBUG - 2011-04-28 23:11:43 --> Output Class Initialized
DEBUG - 2011-04-28 23:11:43 --> Input Class Initialized
DEBUG - 2011-04-28 23:11:43 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-28 23:11:43 --> Language Class Initialized
DEBUG - 2011-04-28 23:11:43 --> Loader Class Initialized
DEBUG - 2011-04-28 23:11:43 --> Controller Class Initialized
DEBUG - 2011-04-28 23:11:43 --> Model Class Initialized
DEBUG - 2011-04-28 23:11:43 --> Model Class Initialized
DEBUG - 2011-04-28 23:11:43 --> Model Class Initialized
DEBUG - 2011-04-28 23:11:43 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-28 23:11:43 --> Database Driver Class Initialized
DEBUG - 2011-04-28 23:11:43 --> File loaded: application/views/table/main.php
DEBUG - 2011-04-28 23:11:43 --> Helper loaded: url_helper
DEBUG - 2011-04-28 23:11:43 --> File loaded: application/views/common/header.php
DEBUG - 2011-04-28 23:11:43 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-04-28 23:11:43 --> File loaded: application/views/common/footer.php
DEBUG - 2011-04-28 23:11:43 --> File loaded: application/views/layout/main.php
DEBUG - 2011-04-28 23:11:43 --> Final output sent to browser
DEBUG - 2011-04-28 23:11:43 --> Total execution time: 1.4207
DEBUG - 2011-04-28 23:11:44 --> Config Class Initialized
DEBUG - 2011-04-28 23:11:44 --> Hooks Class Initialized
DEBUG - 2011-04-28 23:11:44 --> Utf8 Class Initialized
DEBUG - 2011-04-28 23:11:44 --> UTF-8 Support Enabled
DEBUG - 2011-04-28 23:11:44 --> URI Class Initialized
DEBUG - 2011-04-28 23:11:44 --> Router Class Initialized
DEBUG - 2011-04-28 23:11:44 --> Output Class Initialized
DEBUG - 2011-04-28 23:11:44 --> Input Class Initialized
DEBUG - 2011-04-28 23:11:44 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-28 23:11:44 --> Language Class Initialized
DEBUG - 2011-04-28 23:11:44 --> Loader Class Initialized
DEBUG - 2011-04-28 23:11:44 --> Controller Class Initialized
ERROR - 2011-04-28 23:11:44 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-04-28 23:11:44 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-04-28 23:11:44 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-04-28 23:11:44 --> Model Class Initialized
DEBUG - 2011-04-28 23:11:44 --> Model Class Initialized
DEBUG - 2011-04-28 23:11:44 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-28 23:11:44 --> Database Driver Class Initialized
DEBUG - 2011-04-28 23:11:45 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-04-28 23:11:45 --> Helper loaded: url_helper
DEBUG - 2011-04-28 23:11:45 --> File loaded: application/views/common/header.php
DEBUG - 2011-04-28 23:11:45 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-04-28 23:11:45 --> File loaded: application/views/common/footer.php
DEBUG - 2011-04-28 23:11:45 --> File loaded: application/views/layout/main.php
DEBUG - 2011-04-28 23:11:45 --> Final output sent to browser
DEBUG - 2011-04-28 23:11:45 --> Total execution time: 0.1942
DEBUG - 2011-04-28 23:23:49 --> Config Class Initialized
DEBUG - 2011-04-28 23:23:49 --> Hooks Class Initialized
DEBUG - 2011-04-28 23:23:49 --> Utf8 Class Initialized
DEBUG - 2011-04-28 23:23:49 --> UTF-8 Support Enabled
DEBUG - 2011-04-28 23:23:49 --> URI Class Initialized
DEBUG - 2011-04-28 23:23:49 --> Router Class Initialized
DEBUG - 2011-04-28 23:23:49 --> Output Class Initialized
DEBUG - 2011-04-28 23:23:49 --> Input Class Initialized
DEBUG - 2011-04-28 23:23:49 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-28 23:23:49 --> Language Class Initialized
DEBUG - 2011-04-28 23:23:50 --> Loader Class Initialized
DEBUG - 2011-04-28 23:23:50 --> Controller Class Initialized
ERROR - 2011-04-28 23:23:50 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-04-28 23:23:50 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-04-28 23:23:50 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-04-28 23:23:50 --> Model Class Initialized
DEBUG - 2011-04-28 23:23:50 --> Model Class Initialized
DEBUG - 2011-04-28 23:23:50 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-28 23:23:50 --> Database Driver Class Initialized
DEBUG - 2011-04-28 23:23:50 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-04-28 23:23:50 --> Helper loaded: url_helper
DEBUG - 2011-04-28 23:23:50 --> File loaded: application/views/common/header.php
DEBUG - 2011-04-28 23:23:50 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-04-28 23:23:50 --> File loaded: application/views/common/footer.php
DEBUG - 2011-04-28 23:23:50 --> File loaded: application/views/layout/main.php
DEBUG - 2011-04-28 23:23:50 --> Final output sent to browser
DEBUG - 2011-04-28 23:23:50 --> Total execution time: 0.5343
DEBUG - 2011-04-28 23:23:51 --> Config Class Initialized
DEBUG - 2011-04-28 23:23:51 --> Hooks Class Initialized
DEBUG - 2011-04-28 23:23:51 --> Utf8 Class Initialized
DEBUG - 2011-04-28 23:23:51 --> UTF-8 Support Enabled
DEBUG - 2011-04-28 23:23:51 --> URI Class Initialized
DEBUG - 2011-04-28 23:23:51 --> Router Class Initialized
DEBUG - 2011-04-28 23:23:51 --> Output Class Initialized
DEBUG - 2011-04-28 23:23:51 --> Input Class Initialized
DEBUG - 2011-04-28 23:23:51 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-28 23:23:51 --> Language Class Initialized
DEBUG - 2011-04-28 23:23:51 --> Loader Class Initialized
DEBUG - 2011-04-28 23:23:51 --> Controller Class Initialized
DEBUG - 2011-04-28 23:23:51 --> Model Class Initialized
DEBUG - 2011-04-28 23:23:51 --> Model Class Initialized
DEBUG - 2011-04-28 23:23:51 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-28 23:23:51 --> Database Driver Class Initialized
DEBUG - 2011-04-28 23:23:52 --> Final output sent to browser
DEBUG - 2011-04-28 23:23:52 --> Total execution time: 0.7710
DEBUG - 2011-04-28 23:23:53 --> Config Class Initialized
DEBUG - 2011-04-28 23:23:53 --> Hooks Class Initialized
DEBUG - 2011-04-28 23:23:53 --> Utf8 Class Initialized
DEBUG - 2011-04-28 23:23:53 --> UTF-8 Support Enabled
DEBUG - 2011-04-28 23:23:53 --> URI Class Initialized
DEBUG - 2011-04-28 23:23:53 --> Router Class Initialized
ERROR - 2011-04-28 23:23:53 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-04-28 23:24:01 --> Config Class Initialized
DEBUG - 2011-04-28 23:24:01 --> Hooks Class Initialized
DEBUG - 2011-04-28 23:24:01 --> Utf8 Class Initialized
DEBUG - 2011-04-28 23:24:01 --> UTF-8 Support Enabled
DEBUG - 2011-04-28 23:24:01 --> URI Class Initialized
DEBUG - 2011-04-28 23:24:01 --> Router Class Initialized
DEBUG - 2011-04-28 23:24:01 --> Output Class Initialized
DEBUG - 2011-04-28 23:24:01 --> Input Class Initialized
DEBUG - 2011-04-28 23:24:01 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-28 23:24:01 --> Language Class Initialized
DEBUG - 2011-04-28 23:24:01 --> Loader Class Initialized
DEBUG - 2011-04-28 23:24:01 --> Controller Class Initialized
ERROR - 2011-04-28 23:24:01 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-04-28 23:24:01 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-04-28 23:24:01 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-04-28 23:24:01 --> Model Class Initialized
DEBUG - 2011-04-28 23:24:01 --> Model Class Initialized
DEBUG - 2011-04-28 23:24:01 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-28 23:24:01 --> Database Driver Class Initialized
DEBUG - 2011-04-28 23:24:01 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-04-28 23:24:01 --> Helper loaded: url_helper
DEBUG - 2011-04-28 23:24:01 --> File loaded: application/views/common/header.php
DEBUG - 2011-04-28 23:24:01 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-04-28 23:24:01 --> File loaded: application/views/common/footer.php
DEBUG - 2011-04-28 23:24:01 --> File loaded: application/views/layout/main.php
DEBUG - 2011-04-28 23:24:01 --> Final output sent to browser
DEBUG - 2011-04-28 23:24:01 --> Total execution time: 0.0307
DEBUG - 2011-04-28 23:24:02 --> Config Class Initialized
DEBUG - 2011-04-28 23:24:02 --> Hooks Class Initialized
DEBUG - 2011-04-28 23:24:02 --> Utf8 Class Initialized
DEBUG - 2011-04-28 23:24:02 --> UTF-8 Support Enabled
DEBUG - 2011-04-28 23:24:02 --> URI Class Initialized
DEBUG - 2011-04-28 23:24:02 --> Router Class Initialized
DEBUG - 2011-04-28 23:24:02 --> Output Class Initialized
DEBUG - 2011-04-28 23:24:02 --> Input Class Initialized
DEBUG - 2011-04-28 23:24:02 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-28 23:24:02 --> Language Class Initialized
DEBUG - 2011-04-28 23:24:02 --> Loader Class Initialized
DEBUG - 2011-04-28 23:24:02 --> Controller Class Initialized
DEBUG - 2011-04-28 23:24:02 --> Model Class Initialized
DEBUG - 2011-04-28 23:24:02 --> Model Class Initialized
DEBUG - 2011-04-28 23:24:02 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-28 23:24:02 --> Database Driver Class Initialized
DEBUG - 2011-04-28 23:24:02 --> Final output sent to browser
DEBUG - 2011-04-28 23:24:02 --> Total execution time: 0.5161
DEBUG - 2011-04-28 23:24:03 --> Config Class Initialized
DEBUG - 2011-04-28 23:24:03 --> Hooks Class Initialized
DEBUG - 2011-04-28 23:24:03 --> Utf8 Class Initialized
DEBUG - 2011-04-28 23:24:03 --> UTF-8 Support Enabled
DEBUG - 2011-04-28 23:24:03 --> URI Class Initialized
DEBUG - 2011-04-28 23:24:03 --> Router Class Initialized
ERROR - 2011-04-28 23:24:03 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-04-28 23:24:09 --> Config Class Initialized
DEBUG - 2011-04-28 23:24:09 --> Hooks Class Initialized
DEBUG - 2011-04-28 23:24:09 --> Utf8 Class Initialized
DEBUG - 2011-04-28 23:24:09 --> UTF-8 Support Enabled
DEBUG - 2011-04-28 23:24:09 --> URI Class Initialized
DEBUG - 2011-04-28 23:24:09 --> Router Class Initialized
DEBUG - 2011-04-28 23:24:09 --> Output Class Initialized
DEBUG - 2011-04-28 23:24:09 --> Input Class Initialized
DEBUG - 2011-04-28 23:24:09 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-28 23:24:09 --> Language Class Initialized
DEBUG - 2011-04-28 23:24:09 --> Loader Class Initialized
DEBUG - 2011-04-28 23:24:09 --> Controller Class Initialized
ERROR - 2011-04-28 23:24:09 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-04-28 23:24:09 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-04-28 23:24:09 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-04-28 23:24:09 --> Model Class Initialized
DEBUG - 2011-04-28 23:24:09 --> Model Class Initialized
DEBUG - 2011-04-28 23:24:09 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-28 23:24:09 --> Database Driver Class Initialized
DEBUG - 2011-04-28 23:24:09 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-04-28 23:24:09 --> Helper loaded: url_helper
DEBUG - 2011-04-28 23:24:09 --> File loaded: application/views/common/header.php
DEBUG - 2011-04-28 23:24:09 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-04-28 23:24:09 --> File loaded: application/views/common/footer.php
DEBUG - 2011-04-28 23:24:09 --> File loaded: application/views/layout/main.php
DEBUG - 2011-04-28 23:24:09 --> Final output sent to browser
DEBUG - 2011-04-28 23:24:09 --> Total execution time: 0.0580
DEBUG - 2011-04-28 23:24:09 --> Config Class Initialized
DEBUG - 2011-04-28 23:24:09 --> Hooks Class Initialized
DEBUG - 2011-04-28 23:24:09 --> Utf8 Class Initialized
DEBUG - 2011-04-28 23:24:09 --> UTF-8 Support Enabled
DEBUG - 2011-04-28 23:24:09 --> URI Class Initialized
DEBUG - 2011-04-28 23:24:09 --> Router Class Initialized
DEBUG - 2011-04-28 23:24:09 --> Output Class Initialized
DEBUG - 2011-04-28 23:24:09 --> Input Class Initialized
DEBUG - 2011-04-28 23:24:09 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-28 23:24:09 --> Language Class Initialized
DEBUG - 2011-04-28 23:24:09 --> Loader Class Initialized
DEBUG - 2011-04-28 23:24:09 --> Controller Class Initialized
DEBUG - 2011-04-28 23:24:09 --> Model Class Initialized
DEBUG - 2011-04-28 23:24:09 --> Model Class Initialized
DEBUG - 2011-04-28 23:24:09 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-28 23:24:09 --> Database Driver Class Initialized
DEBUG - 2011-04-28 23:24:10 --> Final output sent to browser
DEBUG - 2011-04-28 23:24:10 --> Total execution time: 0.6316
DEBUG - 2011-04-28 23:24:11 --> Config Class Initialized
DEBUG - 2011-04-28 23:24:11 --> Hooks Class Initialized
DEBUG - 2011-04-28 23:24:11 --> Utf8 Class Initialized
DEBUG - 2011-04-28 23:24:11 --> UTF-8 Support Enabled
DEBUG - 2011-04-28 23:24:11 --> URI Class Initialized
DEBUG - 2011-04-28 23:24:11 --> Router Class Initialized
ERROR - 2011-04-28 23:24:11 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-04-28 23:24:14 --> Config Class Initialized
DEBUG - 2011-04-28 23:24:14 --> Hooks Class Initialized
DEBUG - 2011-04-28 23:24:14 --> Utf8 Class Initialized
DEBUG - 2011-04-28 23:24:14 --> UTF-8 Support Enabled
DEBUG - 2011-04-28 23:24:14 --> URI Class Initialized
DEBUG - 2011-04-28 23:24:14 --> Router Class Initialized
DEBUG - 2011-04-28 23:24:14 --> Output Class Initialized
DEBUG - 2011-04-28 23:24:14 --> Input Class Initialized
DEBUG - 2011-04-28 23:24:14 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-28 23:24:14 --> Language Class Initialized
DEBUG - 2011-04-28 23:24:14 --> Loader Class Initialized
DEBUG - 2011-04-28 23:24:14 --> Controller Class Initialized
ERROR - 2011-04-28 23:24:14 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-04-28 23:24:14 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-04-28 23:24:14 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-04-28 23:24:14 --> Model Class Initialized
DEBUG - 2011-04-28 23:24:14 --> Model Class Initialized
DEBUG - 2011-04-28 23:24:14 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-28 23:24:14 --> Database Driver Class Initialized
DEBUG - 2011-04-28 23:24:14 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-04-28 23:24:14 --> Helper loaded: url_helper
DEBUG - 2011-04-28 23:24:14 --> File loaded: application/views/common/header.php
DEBUG - 2011-04-28 23:24:14 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-04-28 23:24:14 --> File loaded: application/views/common/footer.php
DEBUG - 2011-04-28 23:24:14 --> File loaded: application/views/layout/main.php
DEBUG - 2011-04-28 23:24:14 --> Final output sent to browser
DEBUG - 2011-04-28 23:24:14 --> Total execution time: 0.0294
DEBUG - 2011-04-28 23:24:15 --> Config Class Initialized
DEBUG - 2011-04-28 23:24:15 --> Hooks Class Initialized
DEBUG - 2011-04-28 23:24:15 --> Utf8 Class Initialized
DEBUG - 2011-04-28 23:24:15 --> UTF-8 Support Enabled
DEBUG - 2011-04-28 23:24:15 --> URI Class Initialized
DEBUG - 2011-04-28 23:24:15 --> Router Class Initialized
DEBUG - 2011-04-28 23:24:15 --> Output Class Initialized
DEBUG - 2011-04-28 23:24:15 --> Input Class Initialized
DEBUG - 2011-04-28 23:24:15 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-28 23:24:15 --> Language Class Initialized
DEBUG - 2011-04-28 23:24:15 --> Loader Class Initialized
DEBUG - 2011-04-28 23:24:15 --> Controller Class Initialized
DEBUG - 2011-04-28 23:24:15 --> Model Class Initialized
DEBUG - 2011-04-28 23:24:15 --> Model Class Initialized
DEBUG - 2011-04-28 23:24:15 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-28 23:24:15 --> Database Driver Class Initialized
DEBUG - 2011-04-28 23:24:16 --> Final output sent to browser
DEBUG - 2011-04-28 23:24:16 --> Total execution time: 0.6678
DEBUG - 2011-04-28 23:24:17 --> Config Class Initialized
DEBUG - 2011-04-28 23:24:17 --> Hooks Class Initialized
DEBUG - 2011-04-28 23:24:17 --> Utf8 Class Initialized
DEBUG - 2011-04-28 23:24:17 --> UTF-8 Support Enabled
DEBUG - 2011-04-28 23:24:17 --> URI Class Initialized
DEBUG - 2011-04-28 23:24:17 --> Router Class Initialized
ERROR - 2011-04-28 23:24:17 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-04-28 23:24:22 --> Config Class Initialized
DEBUG - 2011-04-28 23:24:22 --> Hooks Class Initialized
DEBUG - 2011-04-28 23:24:22 --> Utf8 Class Initialized
DEBUG - 2011-04-28 23:24:22 --> UTF-8 Support Enabled
DEBUG - 2011-04-28 23:24:22 --> URI Class Initialized
DEBUG - 2011-04-28 23:24:22 --> Router Class Initialized
DEBUG - 2011-04-28 23:24:22 --> Output Class Initialized
DEBUG - 2011-04-28 23:24:22 --> Input Class Initialized
DEBUG - 2011-04-28 23:24:22 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-28 23:24:22 --> Language Class Initialized
DEBUG - 2011-04-28 23:24:22 --> Loader Class Initialized
DEBUG - 2011-04-28 23:24:22 --> Controller Class Initialized
ERROR - 2011-04-28 23:24:22 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-04-28 23:24:22 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-04-28 23:24:22 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-04-28 23:24:22 --> Model Class Initialized
DEBUG - 2011-04-28 23:24:22 --> Model Class Initialized
DEBUG - 2011-04-28 23:24:22 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-28 23:24:22 --> Database Driver Class Initialized
DEBUG - 2011-04-28 23:24:22 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-04-28 23:24:22 --> Helper loaded: url_helper
DEBUG - 2011-04-28 23:24:22 --> File loaded: application/views/common/header.php
DEBUG - 2011-04-28 23:24:22 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-04-28 23:24:22 --> File loaded: application/views/common/footer.php
DEBUG - 2011-04-28 23:24:22 --> File loaded: application/views/layout/main.php
DEBUG - 2011-04-28 23:24:22 --> Final output sent to browser
DEBUG - 2011-04-28 23:24:22 --> Total execution time: 0.0295
DEBUG - 2011-04-28 23:24:23 --> Config Class Initialized
DEBUG - 2011-04-28 23:24:23 --> Hooks Class Initialized
DEBUG - 2011-04-28 23:24:23 --> Utf8 Class Initialized
DEBUG - 2011-04-28 23:24:23 --> UTF-8 Support Enabled
DEBUG - 2011-04-28 23:24:23 --> URI Class Initialized
DEBUG - 2011-04-28 23:24:23 --> Router Class Initialized
DEBUG - 2011-04-28 23:24:23 --> Output Class Initialized
DEBUG - 2011-04-28 23:24:23 --> Input Class Initialized
DEBUG - 2011-04-28 23:24:23 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-28 23:24:23 --> Language Class Initialized
DEBUG - 2011-04-28 23:24:23 --> Loader Class Initialized
DEBUG - 2011-04-28 23:24:23 --> Controller Class Initialized
DEBUG - 2011-04-28 23:24:23 --> Model Class Initialized
DEBUG - 2011-04-28 23:24:23 --> Model Class Initialized
DEBUG - 2011-04-28 23:24:23 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-28 23:24:23 --> Database Driver Class Initialized
DEBUG - 2011-04-28 23:24:23 --> Final output sent to browser
DEBUG - 2011-04-28 23:24:23 --> Total execution time: 0.5770
DEBUG - 2011-04-28 23:24:24 --> Config Class Initialized
DEBUG - 2011-04-28 23:24:24 --> Hooks Class Initialized
DEBUG - 2011-04-28 23:24:24 --> Utf8 Class Initialized
DEBUG - 2011-04-28 23:24:24 --> UTF-8 Support Enabled
DEBUG - 2011-04-28 23:24:24 --> URI Class Initialized
DEBUG - 2011-04-28 23:24:24 --> Router Class Initialized
ERROR - 2011-04-28 23:24:24 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-04-28 23:24:29 --> Config Class Initialized
DEBUG - 2011-04-28 23:24:29 --> Hooks Class Initialized
DEBUG - 2011-04-28 23:24:29 --> Utf8 Class Initialized
DEBUG - 2011-04-28 23:24:29 --> UTF-8 Support Enabled
DEBUG - 2011-04-28 23:24:29 --> URI Class Initialized
DEBUG - 2011-04-28 23:24:29 --> Router Class Initialized
DEBUG - 2011-04-28 23:24:29 --> Output Class Initialized
DEBUG - 2011-04-28 23:24:29 --> Input Class Initialized
DEBUG - 2011-04-28 23:24:29 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-28 23:24:29 --> Language Class Initialized
DEBUG - 2011-04-28 23:24:29 --> Loader Class Initialized
DEBUG - 2011-04-28 23:24:29 --> Controller Class Initialized
ERROR - 2011-04-28 23:24:29 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-04-28 23:24:29 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-04-28 23:24:29 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-04-28 23:24:29 --> Model Class Initialized
DEBUG - 2011-04-28 23:24:29 --> Model Class Initialized
DEBUG - 2011-04-28 23:24:29 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-28 23:24:29 --> Database Driver Class Initialized
DEBUG - 2011-04-28 23:24:29 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-04-28 23:24:30 --> Helper loaded: url_helper
DEBUG - 2011-04-28 23:24:30 --> File loaded: application/views/common/header.php
DEBUG - 2011-04-28 23:24:30 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-04-28 23:24:30 --> File loaded: application/views/common/footer.php
DEBUG - 2011-04-28 23:24:30 --> File loaded: application/views/layout/main.php
DEBUG - 2011-04-28 23:24:30 --> Final output sent to browser
DEBUG - 2011-04-28 23:24:30 --> Total execution time: 0.0294
DEBUG - 2011-04-28 23:24:30 --> Config Class Initialized
DEBUG - 2011-04-28 23:24:30 --> Hooks Class Initialized
DEBUG - 2011-04-28 23:24:30 --> Utf8 Class Initialized
DEBUG - 2011-04-28 23:24:30 --> UTF-8 Support Enabled
DEBUG - 2011-04-28 23:24:30 --> URI Class Initialized
DEBUG - 2011-04-28 23:24:30 --> Router Class Initialized
DEBUG - 2011-04-28 23:24:30 --> Output Class Initialized
DEBUG - 2011-04-28 23:24:30 --> Input Class Initialized
DEBUG - 2011-04-28 23:24:30 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-28 23:24:30 --> Language Class Initialized
DEBUG - 2011-04-28 23:24:30 --> Loader Class Initialized
DEBUG - 2011-04-28 23:24:30 --> Controller Class Initialized
DEBUG - 2011-04-28 23:24:30 --> Model Class Initialized
DEBUG - 2011-04-28 23:24:30 --> Model Class Initialized
DEBUG - 2011-04-28 23:24:30 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-28 23:24:30 --> Database Driver Class Initialized
DEBUG - 2011-04-28 23:24:31 --> Final output sent to browser
DEBUG - 2011-04-28 23:24:31 --> Total execution time: 0.5874
DEBUG - 2011-04-28 23:24:32 --> Config Class Initialized
DEBUG - 2011-04-28 23:24:32 --> Hooks Class Initialized
DEBUG - 2011-04-28 23:24:32 --> Utf8 Class Initialized
DEBUG - 2011-04-28 23:24:32 --> UTF-8 Support Enabled
DEBUG - 2011-04-28 23:24:32 --> URI Class Initialized
DEBUG - 2011-04-28 23:24:32 --> Router Class Initialized
ERROR - 2011-04-28 23:24:32 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-04-28 23:24:35 --> Config Class Initialized
DEBUG - 2011-04-28 23:24:35 --> Hooks Class Initialized
DEBUG - 2011-04-28 23:24:35 --> Utf8 Class Initialized
DEBUG - 2011-04-28 23:24:35 --> UTF-8 Support Enabled
DEBUG - 2011-04-28 23:24:35 --> URI Class Initialized
DEBUG - 2011-04-28 23:24:35 --> Router Class Initialized
DEBUG - 2011-04-28 23:24:35 --> Output Class Initialized
DEBUG - 2011-04-28 23:24:35 --> Input Class Initialized
DEBUG - 2011-04-28 23:24:35 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-28 23:24:35 --> Language Class Initialized
DEBUG - 2011-04-28 23:24:35 --> Loader Class Initialized
DEBUG - 2011-04-28 23:24:35 --> Controller Class Initialized
ERROR - 2011-04-28 23:24:35 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-04-28 23:24:35 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-04-28 23:24:35 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-04-28 23:24:35 --> Model Class Initialized
DEBUG - 2011-04-28 23:24:35 --> Model Class Initialized
DEBUG - 2011-04-28 23:24:35 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-28 23:24:35 --> Database Driver Class Initialized
DEBUG - 2011-04-28 23:24:35 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-04-28 23:24:35 --> Helper loaded: url_helper
DEBUG - 2011-04-28 23:24:35 --> File loaded: application/views/common/header.php
DEBUG - 2011-04-28 23:24:35 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-04-28 23:24:35 --> File loaded: application/views/common/footer.php
DEBUG - 2011-04-28 23:24:35 --> File loaded: application/views/layout/main.php
DEBUG - 2011-04-28 23:24:35 --> Final output sent to browser
DEBUG - 2011-04-28 23:24:35 --> Total execution time: 0.0623
DEBUG - 2011-04-28 23:24:35 --> Config Class Initialized
DEBUG - 2011-04-28 23:24:35 --> Hooks Class Initialized
DEBUG - 2011-04-28 23:24:35 --> Utf8 Class Initialized
DEBUG - 2011-04-28 23:24:35 --> UTF-8 Support Enabled
DEBUG - 2011-04-28 23:24:35 --> URI Class Initialized
DEBUG - 2011-04-28 23:24:35 --> Router Class Initialized
DEBUG - 2011-04-28 23:24:35 --> Output Class Initialized
DEBUG - 2011-04-28 23:24:35 --> Input Class Initialized
DEBUG - 2011-04-28 23:24:35 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-28 23:24:35 --> Language Class Initialized
DEBUG - 2011-04-28 23:24:35 --> Loader Class Initialized
DEBUG - 2011-04-28 23:24:35 --> Controller Class Initialized
DEBUG - 2011-04-28 23:24:35 --> Model Class Initialized
DEBUG - 2011-04-28 23:24:35 --> Model Class Initialized
DEBUG - 2011-04-28 23:24:35 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-28 23:24:36 --> Database Driver Class Initialized
DEBUG - 2011-04-28 23:24:36 --> Final output sent to browser
DEBUG - 2011-04-28 23:24:36 --> Total execution time: 0.7120
DEBUG - 2011-04-28 23:24:37 --> Config Class Initialized
DEBUG - 2011-04-28 23:24:37 --> Hooks Class Initialized
DEBUG - 2011-04-28 23:24:37 --> Utf8 Class Initialized
DEBUG - 2011-04-28 23:24:37 --> UTF-8 Support Enabled
DEBUG - 2011-04-28 23:24:37 --> URI Class Initialized
DEBUG - 2011-04-28 23:24:37 --> Router Class Initialized
ERROR - 2011-04-28 23:24:37 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-04-28 23:24:39 --> Config Class Initialized
DEBUG - 2011-04-28 23:24:39 --> Hooks Class Initialized
DEBUG - 2011-04-28 23:24:39 --> Utf8 Class Initialized
DEBUG - 2011-04-28 23:24:39 --> UTF-8 Support Enabled
DEBUG - 2011-04-28 23:24:39 --> URI Class Initialized
DEBUG - 2011-04-28 23:24:39 --> Router Class Initialized
DEBUG - 2011-04-28 23:24:39 --> Output Class Initialized
DEBUG - 2011-04-28 23:24:39 --> Input Class Initialized
DEBUG - 2011-04-28 23:24:39 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-28 23:24:39 --> Language Class Initialized
DEBUG - 2011-04-28 23:24:39 --> Loader Class Initialized
DEBUG - 2011-04-28 23:24:39 --> Controller Class Initialized
ERROR - 2011-04-28 23:24:39 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-04-28 23:24:39 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-04-28 23:24:39 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-04-28 23:24:39 --> Model Class Initialized
DEBUG - 2011-04-28 23:24:39 --> Model Class Initialized
DEBUG - 2011-04-28 23:24:39 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-28 23:24:39 --> Database Driver Class Initialized
DEBUG - 2011-04-28 23:24:39 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-04-28 23:24:39 --> Helper loaded: url_helper
DEBUG - 2011-04-28 23:24:39 --> File loaded: application/views/common/header.php
DEBUG - 2011-04-28 23:24:39 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-04-28 23:24:39 --> File loaded: application/views/common/footer.php
DEBUG - 2011-04-28 23:24:39 --> File loaded: application/views/layout/main.php
DEBUG - 2011-04-28 23:24:39 --> Final output sent to browser
DEBUG - 2011-04-28 23:24:39 --> Total execution time: 0.0605
DEBUG - 2011-04-28 23:24:40 --> Config Class Initialized
DEBUG - 2011-04-28 23:24:40 --> Hooks Class Initialized
DEBUG - 2011-04-28 23:24:40 --> Utf8 Class Initialized
DEBUG - 2011-04-28 23:24:40 --> UTF-8 Support Enabled
DEBUG - 2011-04-28 23:24:40 --> URI Class Initialized
DEBUG - 2011-04-28 23:24:40 --> Router Class Initialized
DEBUG - 2011-04-28 23:24:40 --> Output Class Initialized
DEBUG - 2011-04-28 23:24:40 --> Input Class Initialized
DEBUG - 2011-04-28 23:24:40 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-28 23:24:40 --> Language Class Initialized
DEBUG - 2011-04-28 23:24:40 --> Loader Class Initialized
DEBUG - 2011-04-28 23:24:40 --> Controller Class Initialized
DEBUG - 2011-04-28 23:24:40 --> Model Class Initialized
DEBUG - 2011-04-28 23:24:40 --> Model Class Initialized
DEBUG - 2011-04-28 23:24:40 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-28 23:24:40 --> Database Driver Class Initialized
DEBUG - 2011-04-28 23:24:40 --> Final output sent to browser
DEBUG - 2011-04-28 23:24:40 --> Total execution time: 0.5382
DEBUG - 2011-04-28 23:24:41 --> Config Class Initialized
DEBUG - 2011-04-28 23:24:41 --> Hooks Class Initialized
DEBUG - 2011-04-28 23:24:41 --> Utf8 Class Initialized
DEBUG - 2011-04-28 23:24:41 --> UTF-8 Support Enabled
DEBUG - 2011-04-28 23:24:41 --> URI Class Initialized
DEBUG - 2011-04-28 23:24:41 --> Router Class Initialized
ERROR - 2011-04-28 23:24:41 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-04-28 23:24:43 --> Config Class Initialized
DEBUG - 2011-04-28 23:24:43 --> Hooks Class Initialized
DEBUG - 2011-04-28 23:24:43 --> Utf8 Class Initialized
DEBUG - 2011-04-28 23:24:43 --> UTF-8 Support Enabled
DEBUG - 2011-04-28 23:24:43 --> URI Class Initialized
DEBUG - 2011-04-28 23:24:43 --> Router Class Initialized
DEBUG - 2011-04-28 23:24:43 --> Output Class Initialized
DEBUG - 2011-04-28 23:24:43 --> Input Class Initialized
DEBUG - 2011-04-28 23:24:43 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-28 23:24:43 --> Language Class Initialized
DEBUG - 2011-04-28 23:24:43 --> Loader Class Initialized
DEBUG - 2011-04-28 23:24:43 --> Controller Class Initialized
ERROR - 2011-04-28 23:24:43 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-04-28 23:24:43 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-04-28 23:24:43 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-04-28 23:24:43 --> Model Class Initialized
DEBUG - 2011-04-28 23:24:43 --> Model Class Initialized
DEBUG - 2011-04-28 23:24:43 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-28 23:24:43 --> Database Driver Class Initialized
DEBUG - 2011-04-28 23:24:43 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-04-28 23:24:43 --> Helper loaded: url_helper
DEBUG - 2011-04-28 23:24:43 --> File loaded: application/views/common/header.php
DEBUG - 2011-04-28 23:24:43 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-04-28 23:24:43 --> File loaded: application/views/common/footer.php
DEBUG - 2011-04-28 23:24:43 --> File loaded: application/views/layout/main.php
DEBUG - 2011-04-28 23:24:43 --> Final output sent to browser
DEBUG - 2011-04-28 23:24:43 --> Total execution time: 0.0391
DEBUG - 2011-04-28 23:24:44 --> Config Class Initialized
DEBUG - 2011-04-28 23:24:44 --> Hooks Class Initialized
DEBUG - 2011-04-28 23:24:44 --> Utf8 Class Initialized
DEBUG - 2011-04-28 23:24:44 --> UTF-8 Support Enabled
DEBUG - 2011-04-28 23:24:44 --> URI Class Initialized
DEBUG - 2011-04-28 23:24:44 --> Router Class Initialized
DEBUG - 2011-04-28 23:24:44 --> Output Class Initialized
DEBUG - 2011-04-28 23:24:44 --> Input Class Initialized
DEBUG - 2011-04-28 23:24:44 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-28 23:24:44 --> Language Class Initialized
DEBUG - 2011-04-28 23:24:44 --> Loader Class Initialized
DEBUG - 2011-04-28 23:24:44 --> Controller Class Initialized
DEBUG - 2011-04-28 23:24:44 --> Model Class Initialized
DEBUG - 2011-04-28 23:24:44 --> Model Class Initialized
DEBUG - 2011-04-28 23:24:44 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-28 23:24:44 --> Database Driver Class Initialized
DEBUG - 2011-04-28 23:24:45 --> Final output sent to browser
DEBUG - 2011-04-28 23:24:45 --> Total execution time: 0.5221
DEBUG - 2011-04-28 23:24:46 --> Config Class Initialized
DEBUG - 2011-04-28 23:24:46 --> Hooks Class Initialized
DEBUG - 2011-04-28 23:24:46 --> Utf8 Class Initialized
DEBUG - 2011-04-28 23:24:46 --> UTF-8 Support Enabled
DEBUG - 2011-04-28 23:24:46 --> URI Class Initialized
DEBUG - 2011-04-28 23:24:46 --> Router Class Initialized
ERROR - 2011-04-28 23:24:46 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-04-28 23:24:57 --> Config Class Initialized
DEBUG - 2011-04-28 23:24:57 --> Hooks Class Initialized
DEBUG - 2011-04-28 23:24:57 --> Utf8 Class Initialized
DEBUG - 2011-04-28 23:24:57 --> UTF-8 Support Enabled
DEBUG - 2011-04-28 23:24:57 --> URI Class Initialized
DEBUG - 2011-04-28 23:24:57 --> Router Class Initialized
DEBUG - 2011-04-28 23:24:57 --> Output Class Initialized
DEBUG - 2011-04-28 23:24:57 --> Input Class Initialized
DEBUG - 2011-04-28 23:24:57 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-28 23:24:57 --> Language Class Initialized
DEBUG - 2011-04-28 23:24:57 --> Loader Class Initialized
DEBUG - 2011-04-28 23:24:57 --> Controller Class Initialized
ERROR - 2011-04-28 23:24:57 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-04-28 23:24:57 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-04-28 23:24:57 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-04-28 23:24:57 --> Model Class Initialized
DEBUG - 2011-04-28 23:24:57 --> Model Class Initialized
DEBUG - 2011-04-28 23:24:57 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-28 23:24:57 --> Database Driver Class Initialized
DEBUG - 2011-04-28 23:24:57 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-04-28 23:24:57 --> Helper loaded: url_helper
DEBUG - 2011-04-28 23:24:57 --> File loaded: application/views/common/header.php
DEBUG - 2011-04-28 23:24:57 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-04-28 23:24:57 --> File loaded: application/views/common/footer.php
DEBUG - 2011-04-28 23:24:57 --> File loaded: application/views/layout/main.php
DEBUG - 2011-04-28 23:24:57 --> Final output sent to browser
DEBUG - 2011-04-28 23:24:57 --> Total execution time: 0.0304
DEBUG - 2011-04-28 23:24:58 --> Config Class Initialized
DEBUG - 2011-04-28 23:24:58 --> Hooks Class Initialized
DEBUG - 2011-04-28 23:24:58 --> Utf8 Class Initialized
DEBUG - 2011-04-28 23:24:58 --> UTF-8 Support Enabled
DEBUG - 2011-04-28 23:24:58 --> URI Class Initialized
DEBUG - 2011-04-28 23:24:58 --> Router Class Initialized
DEBUG - 2011-04-28 23:24:58 --> Output Class Initialized
DEBUG - 2011-04-28 23:24:58 --> Input Class Initialized
DEBUG - 2011-04-28 23:24:58 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-28 23:24:58 --> Language Class Initialized
DEBUG - 2011-04-28 23:24:58 --> Loader Class Initialized
DEBUG - 2011-04-28 23:24:58 --> Controller Class Initialized
DEBUG - 2011-04-28 23:24:58 --> Model Class Initialized
DEBUG - 2011-04-28 23:24:58 --> Model Class Initialized
DEBUG - 2011-04-28 23:24:58 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-28 23:24:58 --> Database Driver Class Initialized
DEBUG - 2011-04-28 23:24:58 --> Final output sent to browser
DEBUG - 2011-04-28 23:24:58 --> Total execution time: 0.5666
DEBUG - 2011-04-28 23:24:59 --> Config Class Initialized
DEBUG - 2011-04-28 23:24:59 --> Hooks Class Initialized
DEBUG - 2011-04-28 23:24:59 --> Utf8 Class Initialized
DEBUG - 2011-04-28 23:24:59 --> UTF-8 Support Enabled
DEBUG - 2011-04-28 23:24:59 --> URI Class Initialized
DEBUG - 2011-04-28 23:24:59 --> Router Class Initialized
ERROR - 2011-04-28 23:24:59 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-04-28 23:26:53 --> Config Class Initialized
DEBUG - 2011-04-28 23:26:53 --> Hooks Class Initialized
DEBUG - 2011-04-28 23:26:53 --> Utf8 Class Initialized
DEBUG - 2011-04-28 23:26:53 --> UTF-8 Support Enabled
DEBUG - 2011-04-28 23:26:53 --> URI Class Initialized
DEBUG - 2011-04-28 23:26:53 --> Router Class Initialized
DEBUG - 2011-04-28 23:26:53 --> Output Class Initialized
DEBUG - 2011-04-28 23:26:53 --> Input Class Initialized
DEBUG - 2011-04-28 23:26:53 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-28 23:26:53 --> Language Class Initialized
DEBUG - 2011-04-28 23:26:53 --> Loader Class Initialized
DEBUG - 2011-04-28 23:26:53 --> Controller Class Initialized
ERROR - 2011-04-28 23:26:53 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-04-28 23:26:53 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-04-28 23:26:53 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-04-28 23:26:53 --> Model Class Initialized
DEBUG - 2011-04-28 23:26:53 --> Model Class Initialized
DEBUG - 2011-04-28 23:26:53 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-28 23:26:53 --> Database Driver Class Initialized
DEBUG - 2011-04-28 23:26:53 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-04-28 23:26:53 --> Helper loaded: url_helper
DEBUG - 2011-04-28 23:26:53 --> File loaded: application/views/common/header.php
DEBUG - 2011-04-28 23:26:53 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-04-28 23:26:53 --> File loaded: application/views/common/footer.php
DEBUG - 2011-04-28 23:26:53 --> File loaded: application/views/layout/main.php
DEBUG - 2011-04-28 23:26:53 --> Final output sent to browser
DEBUG - 2011-04-28 23:26:53 --> Total execution time: 0.0284
DEBUG - 2011-04-28 23:26:54 --> Config Class Initialized
DEBUG - 2011-04-28 23:26:54 --> Hooks Class Initialized
DEBUG - 2011-04-28 23:26:54 --> Utf8 Class Initialized
DEBUG - 2011-04-28 23:26:54 --> UTF-8 Support Enabled
DEBUG - 2011-04-28 23:26:54 --> URI Class Initialized
DEBUG - 2011-04-28 23:26:54 --> Router Class Initialized
DEBUG - 2011-04-28 23:26:54 --> Output Class Initialized
DEBUG - 2011-04-28 23:26:54 --> Input Class Initialized
DEBUG - 2011-04-28 23:26:54 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-28 23:26:54 --> Language Class Initialized
DEBUG - 2011-04-28 23:26:54 --> Loader Class Initialized
DEBUG - 2011-04-28 23:26:54 --> Controller Class Initialized
ERROR - 2011-04-28 23:26:54 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-04-28 23:26:54 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-04-28 23:26:54 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-04-28 23:26:54 --> Model Class Initialized
DEBUG - 2011-04-28 23:26:54 --> Model Class Initialized
DEBUG - 2011-04-28 23:26:54 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-28 23:26:54 --> Database Driver Class Initialized
DEBUG - 2011-04-28 23:26:54 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-04-28 23:26:54 --> Helper loaded: url_helper
DEBUG - 2011-04-28 23:26:54 --> File loaded: application/views/common/header.php
DEBUG - 2011-04-28 23:26:54 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-04-28 23:26:54 --> File loaded: application/views/common/footer.php
DEBUG - 2011-04-28 23:26:54 --> File loaded: application/views/layout/main.php
DEBUG - 2011-04-28 23:26:54 --> Final output sent to browser
DEBUG - 2011-04-28 23:26:54 --> Total execution time: 0.0354
DEBUG - 2011-04-28 23:26:55 --> Config Class Initialized
DEBUG - 2011-04-28 23:26:55 --> Hooks Class Initialized
DEBUG - 2011-04-28 23:26:55 --> Utf8 Class Initialized
DEBUG - 2011-04-28 23:26:55 --> UTF-8 Support Enabled
DEBUG - 2011-04-28 23:26:55 --> URI Class Initialized
DEBUG - 2011-04-28 23:26:55 --> Router Class Initialized
DEBUG - 2011-04-28 23:26:55 --> Output Class Initialized
DEBUG - 2011-04-28 23:26:55 --> Input Class Initialized
DEBUG - 2011-04-28 23:26:55 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-28 23:26:55 --> Language Class Initialized
DEBUG - 2011-04-28 23:26:55 --> Loader Class Initialized
DEBUG - 2011-04-28 23:26:55 --> Controller Class Initialized
ERROR - 2011-04-28 23:26:55 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-04-28 23:26:55 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-04-28 23:26:55 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-04-28 23:26:55 --> Model Class Initialized
DEBUG - 2011-04-28 23:26:55 --> Model Class Initialized
DEBUG - 2011-04-28 23:26:55 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-28 23:26:55 --> Database Driver Class Initialized
DEBUG - 2011-04-28 23:26:55 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-04-28 23:26:55 --> Helper loaded: url_helper
DEBUG - 2011-04-28 23:26:55 --> File loaded: application/views/common/header.php
DEBUG - 2011-04-28 23:26:55 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-04-28 23:26:55 --> File loaded: application/views/common/footer.php
DEBUG - 2011-04-28 23:26:55 --> File loaded: application/views/layout/main.php
DEBUG - 2011-04-28 23:26:55 --> Final output sent to browser
DEBUG - 2011-04-28 23:26:55 --> Total execution time: 0.0282
DEBUG - 2011-04-28 23:26:55 --> Config Class Initialized
DEBUG - 2011-04-28 23:26:55 --> Hooks Class Initialized
DEBUG - 2011-04-28 23:26:55 --> Utf8 Class Initialized
DEBUG - 2011-04-28 23:26:55 --> UTF-8 Support Enabled
DEBUG - 2011-04-28 23:26:55 --> URI Class Initialized
DEBUG - 2011-04-28 23:26:55 --> Router Class Initialized
DEBUG - 2011-04-28 23:26:55 --> Output Class Initialized
DEBUG - 2011-04-28 23:26:55 --> Input Class Initialized
DEBUG - 2011-04-28 23:26:55 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-28 23:26:55 --> Language Class Initialized
DEBUG - 2011-04-28 23:26:55 --> Loader Class Initialized
DEBUG - 2011-04-28 23:26:55 --> Controller Class Initialized
ERROR - 2011-04-28 23:26:55 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-04-28 23:26:55 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-04-28 23:26:55 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-04-28 23:26:55 --> Model Class Initialized
DEBUG - 2011-04-28 23:26:55 --> Model Class Initialized
DEBUG - 2011-04-28 23:26:55 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-28 23:26:55 --> Database Driver Class Initialized
DEBUG - 2011-04-28 23:26:55 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-04-28 23:26:55 --> Helper loaded: url_helper
DEBUG - 2011-04-28 23:26:55 --> File loaded: application/views/common/header.php
DEBUG - 2011-04-28 23:26:55 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-04-28 23:26:55 --> File loaded: application/views/common/footer.php
DEBUG - 2011-04-28 23:26:55 --> File loaded: application/views/layout/main.php
DEBUG - 2011-04-28 23:26:55 --> Final output sent to browser
DEBUG - 2011-04-28 23:26:55 --> Total execution time: 0.0281
DEBUG - 2011-04-28 23:26:57 --> Config Class Initialized
DEBUG - 2011-04-28 23:26:57 --> Hooks Class Initialized
DEBUG - 2011-04-28 23:26:57 --> Utf8 Class Initialized
DEBUG - 2011-04-28 23:26:57 --> UTF-8 Support Enabled
DEBUG - 2011-04-28 23:26:57 --> URI Class Initialized
DEBUG - 2011-04-28 23:26:57 --> Router Class Initialized
DEBUG - 2011-04-28 23:26:57 --> Output Class Initialized
DEBUG - 2011-04-28 23:26:57 --> Input Class Initialized
DEBUG - 2011-04-28 23:26:57 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-28 23:26:57 --> Language Class Initialized
DEBUG - 2011-04-28 23:26:57 --> Loader Class Initialized
DEBUG - 2011-04-28 23:26:57 --> Controller Class Initialized
ERROR - 2011-04-28 23:26:57 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-04-28 23:26:57 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-04-28 23:26:57 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-04-28 23:26:57 --> Model Class Initialized
DEBUG - 2011-04-28 23:26:57 --> Model Class Initialized
DEBUG - 2011-04-28 23:26:57 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-28 23:26:57 --> Database Driver Class Initialized
DEBUG - 2011-04-28 23:26:57 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-04-28 23:26:57 --> Helper loaded: url_helper
DEBUG - 2011-04-28 23:26:57 --> File loaded: application/views/common/header.php
DEBUG - 2011-04-28 23:26:57 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-04-28 23:26:57 --> File loaded: application/views/common/footer.php
DEBUG - 2011-04-28 23:26:57 --> File loaded: application/views/layout/main.php
DEBUG - 2011-04-28 23:26:57 --> Final output sent to browser
DEBUG - 2011-04-28 23:26:57 --> Total execution time: 0.0368
DEBUG - 2011-04-28 23:27:02 --> Config Class Initialized
DEBUG - 2011-04-28 23:27:02 --> Hooks Class Initialized
DEBUG - 2011-04-28 23:27:02 --> Utf8 Class Initialized
DEBUG - 2011-04-28 23:27:02 --> UTF-8 Support Enabled
DEBUG - 2011-04-28 23:27:02 --> URI Class Initialized
DEBUG - 2011-04-28 23:27:02 --> Router Class Initialized
DEBUG - 2011-04-28 23:27:02 --> Output Class Initialized
DEBUG - 2011-04-28 23:27:02 --> Input Class Initialized
DEBUG - 2011-04-28 23:27:02 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-28 23:27:02 --> Language Class Initialized
DEBUG - 2011-04-28 23:27:02 --> Loader Class Initialized
DEBUG - 2011-04-28 23:27:02 --> Controller Class Initialized
ERROR - 2011-04-28 23:27:02 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-04-28 23:27:02 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-04-28 23:27:02 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-04-28 23:27:02 --> Model Class Initialized
DEBUG - 2011-04-28 23:27:02 --> Model Class Initialized
DEBUG - 2011-04-28 23:27:02 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-28 23:27:02 --> Database Driver Class Initialized
DEBUG - 2011-04-28 23:27:02 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-04-28 23:27:02 --> Helper loaded: url_helper
DEBUG - 2011-04-28 23:27:02 --> File loaded: application/views/common/header.php
DEBUG - 2011-04-28 23:27:02 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-04-28 23:27:02 --> File loaded: application/views/common/footer.php
DEBUG - 2011-04-28 23:27:02 --> File loaded: application/views/layout/main.php
DEBUG - 2011-04-28 23:27:02 --> Final output sent to browser
DEBUG - 2011-04-28 23:27:02 --> Total execution time: 0.0278
DEBUG - 2011-04-28 23:39:14 --> Config Class Initialized
DEBUG - 2011-04-28 23:39:14 --> Hooks Class Initialized
DEBUG - 2011-04-28 23:39:14 --> Utf8 Class Initialized
DEBUG - 2011-04-28 23:39:14 --> UTF-8 Support Enabled
DEBUG - 2011-04-28 23:39:14 --> URI Class Initialized
DEBUG - 2011-04-28 23:39:14 --> Router Class Initialized
DEBUG - 2011-04-28 23:39:14 --> Output Class Initialized
DEBUG - 2011-04-28 23:39:15 --> Input Class Initialized
DEBUG - 2011-04-28 23:39:15 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-28 23:39:15 --> Language Class Initialized
DEBUG - 2011-04-28 23:39:15 --> Loader Class Initialized
DEBUG - 2011-04-28 23:39:15 --> Controller Class Initialized
DEBUG - 2011-04-28 23:39:15 --> Model Class Initialized
DEBUG - 2011-04-28 23:39:15 --> Model Class Initialized
DEBUG - 2011-04-28 23:39:15 --> Model Class Initialized
DEBUG - 2011-04-28 23:39:15 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-28 23:39:15 --> Database Driver Class Initialized
DEBUG - 2011-04-28 23:39:15 --> File loaded: application/views/table/main.php
DEBUG - 2011-04-28 23:39:15 --> Helper loaded: url_helper
DEBUG - 2011-04-28 23:39:15 --> File loaded: application/views/common/header.php
DEBUG - 2011-04-28 23:39:15 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-04-28 23:39:15 --> File loaded: application/views/common/footer.php
DEBUG - 2011-04-28 23:39:15 --> File loaded: application/views/layout/main.php
DEBUG - 2011-04-28 23:39:15 --> Final output sent to browser
DEBUG - 2011-04-28 23:39:15 --> Total execution time: 0.2978
DEBUG - 2011-04-28 23:39:16 --> Config Class Initialized
DEBUG - 2011-04-28 23:39:16 --> Hooks Class Initialized
DEBUG - 2011-04-28 23:39:16 --> Utf8 Class Initialized
DEBUG - 2011-04-28 23:39:16 --> UTF-8 Support Enabled
DEBUG - 2011-04-28 23:39:16 --> URI Class Initialized
DEBUG - 2011-04-28 23:39:16 --> Router Class Initialized
DEBUG - 2011-04-28 23:39:16 --> Output Class Initialized
DEBUG - 2011-04-28 23:39:16 --> Input Class Initialized
DEBUG - 2011-04-28 23:39:16 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-28 23:39:16 --> Language Class Initialized
DEBUG - 2011-04-28 23:39:16 --> Loader Class Initialized
DEBUG - 2011-04-28 23:39:16 --> Controller Class Initialized
ERROR - 2011-04-28 23:39:16 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-04-28 23:39:16 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-04-28 23:39:16 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-04-28 23:39:16 --> Model Class Initialized
DEBUG - 2011-04-28 23:39:16 --> Model Class Initialized
DEBUG - 2011-04-28 23:39:16 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-28 23:39:16 --> Database Driver Class Initialized
DEBUG - 2011-04-28 23:39:16 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-04-28 23:39:16 --> Helper loaded: url_helper
DEBUG - 2011-04-28 23:39:16 --> File loaded: application/views/common/header.php
DEBUG - 2011-04-28 23:39:16 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-04-28 23:39:16 --> File loaded: application/views/common/footer.php
DEBUG - 2011-04-28 23:39:16 --> File loaded: application/views/layout/main.php
DEBUG - 2011-04-28 23:39:16 --> Final output sent to browser
DEBUG - 2011-04-28 23:39:16 --> Total execution time: 0.0307

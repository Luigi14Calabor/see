<?php  if ( ! defined('BASEPATH')) exit('No direct script access allowed'); ?>

DEBUG - 2011-05-17 00:28:50 --> Config Class Initialized
DEBUG - 2011-05-17 00:28:50 --> Hooks Class Initialized
DEBUG - 2011-05-17 00:28:50 --> Utf8 Class Initialized
DEBUG - 2011-05-17 00:28:50 --> UTF-8 Support Enabled
DEBUG - 2011-05-17 00:28:50 --> URI Class Initialized
DEBUG - 2011-05-17 00:28:50 --> Router Class Initialized
DEBUG - 2011-05-17 00:28:51 --> Output Class Initialized
DEBUG - 2011-05-17 00:28:51 --> Input Class Initialized
DEBUG - 2011-05-17 00:28:51 --> Global POST and COOKIE data sanitized
DEBUG - 2011-05-17 00:28:51 --> Language Class Initialized
DEBUG - 2011-05-17 00:28:51 --> Loader Class Initialized
DEBUG - 2011-05-17 00:28:51 --> Controller Class Initialized
DEBUG - 2011-05-17 00:28:51 --> Model Class Initialized
DEBUG - 2011-05-17 00:28:51 --> Model Class Initialized
DEBUG - 2011-05-17 00:28:51 --> Model Class Initialized
DEBUG - 2011-05-17 00:28:51 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-05-17 00:28:51 --> Database Driver Class Initialized
DEBUG - 2011-05-17 00:28:51 --> File loaded: application/views/table/main.php
DEBUG - 2011-05-17 00:28:51 --> Helper loaded: url_helper
DEBUG - 2011-05-17 00:28:51 --> File loaded: application/views/common/header.php
DEBUG - 2011-05-17 00:28:51 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-05-17 00:28:51 --> File loaded: application/views/common/footer.php
DEBUG - 2011-05-17 00:28:51 --> File loaded: application/views/layout/main.php
DEBUG - 2011-05-17 00:28:51 --> Final output sent to browser
DEBUG - 2011-05-17 00:28:51 --> Total execution time: 0.9170
DEBUG - 2011-05-17 00:28:52 --> Config Class Initialized
DEBUG - 2011-05-17 00:28:52 --> Hooks Class Initialized
DEBUG - 2011-05-17 00:28:52 --> Utf8 Class Initialized
DEBUG - 2011-05-17 00:28:52 --> UTF-8 Support Enabled
DEBUG - 2011-05-17 00:28:52 --> URI Class Initialized
DEBUG - 2011-05-17 00:28:52 --> Router Class Initialized
DEBUG - 2011-05-17 00:28:52 --> Output Class Initialized
DEBUG - 2011-05-17 00:28:52 --> Input Class Initialized
DEBUG - 2011-05-17 00:28:52 --> Global POST and COOKIE data sanitized
DEBUG - 2011-05-17 00:28:52 --> Language Class Initialized
DEBUG - 2011-05-17 00:28:52 --> Loader Class Initialized
DEBUG - 2011-05-17 00:28:52 --> Controller Class Initialized
ERROR - 2011-05-17 00:28:52 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-05-17 00:28:52 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-05-17 00:28:52 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-05-17 00:28:52 --> Model Class Initialized
DEBUG - 2011-05-17 00:28:52 --> Model Class Initialized
DEBUG - 2011-05-17 00:28:52 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-05-17 00:28:52 --> Database Driver Class Initialized
DEBUG - 2011-05-17 00:28:52 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-05-17 00:28:52 --> Helper loaded: url_helper
DEBUG - 2011-05-17 00:28:52 --> File loaded: application/views/common/header.php
DEBUG - 2011-05-17 00:28:52 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-05-17 00:28:52 --> File loaded: application/views/common/footer.php
DEBUG - 2011-05-17 00:28:52 --> File loaded: application/views/layout/main.php
DEBUG - 2011-05-17 00:28:52 --> Final output sent to browser
DEBUG - 2011-05-17 00:28:52 --> Total execution time: 0.1102
DEBUG - 2011-05-17 02:02:27 --> Config Class Initialized
DEBUG - 2011-05-17 02:02:27 --> Hooks Class Initialized
DEBUG - 2011-05-17 02:02:27 --> Utf8 Class Initialized
DEBUG - 2011-05-17 02:02:27 --> UTF-8 Support Enabled
DEBUG - 2011-05-17 02:02:27 --> URI Class Initialized
DEBUG - 2011-05-17 02:02:27 --> Router Class Initialized
ERROR - 2011-05-17 02:02:27 --> 404 Page Not Found --> robots.txt
DEBUG - 2011-05-17 02:29:01 --> Config Class Initialized
DEBUG - 2011-05-17 02:29:02 --> Hooks Class Initialized
DEBUG - 2011-05-17 02:29:02 --> Utf8 Class Initialized
DEBUG - 2011-05-17 02:29:02 --> UTF-8 Support Enabled
DEBUG - 2011-05-17 02:29:02 --> URI Class Initialized
DEBUG - 2011-05-17 02:29:02 --> Router Class Initialized
DEBUG - 2011-05-17 02:29:02 --> Output Class Initialized
DEBUG - 2011-05-17 02:29:02 --> Input Class Initialized
DEBUG - 2011-05-17 02:29:02 --> Global POST and COOKIE data sanitized
DEBUG - 2011-05-17 02:29:02 --> Language Class Initialized
DEBUG - 2011-05-17 02:29:02 --> Loader Class Initialized
DEBUG - 2011-05-17 02:29:02 --> Controller Class Initialized
DEBUG - 2011-05-17 02:29:02 --> Model Class Initialized
DEBUG - 2011-05-17 02:29:02 --> Model Class Initialized
DEBUG - 2011-05-17 02:29:02 --> Model Class Initialized
DEBUG - 2011-05-17 02:29:03 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-05-17 02:29:03 --> Database Driver Class Initialized
DEBUG - 2011-05-17 02:29:37 --> File loaded: application/views/table/main.php
DEBUG - 2011-05-17 02:29:37 --> Helper loaded: url_helper
DEBUG - 2011-05-17 02:29:37 --> File loaded: application/views/common/header.php
DEBUG - 2011-05-17 02:29:37 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-05-17 02:29:37 --> File loaded: application/views/common/footer.php
DEBUG - 2011-05-17 02:29:37 --> File loaded: application/views/layout/main.php
DEBUG - 2011-05-17 02:29:37 --> Final output sent to browser
DEBUG - 2011-05-17 02:29:37 --> Total execution time: 36.6042
DEBUG - 2011-05-17 04:22:24 --> Config Class Initialized
DEBUG - 2011-05-17 04:22:24 --> Hooks Class Initialized
DEBUG - 2011-05-17 04:22:24 --> Utf8 Class Initialized
DEBUG - 2011-05-17 04:22:24 --> UTF-8 Support Enabled
DEBUG - 2011-05-17 04:22:24 --> URI Class Initialized
DEBUG - 2011-05-17 04:22:24 --> Router Class Initialized
DEBUG - 2011-05-17 04:22:24 --> Output Class Initialized
DEBUG - 2011-05-17 04:22:24 --> Input Class Initialized
DEBUG - 2011-05-17 04:22:24 --> Global POST and COOKIE data sanitized
DEBUG - 2011-05-17 04:22:24 --> Language Class Initialized
DEBUG - 2011-05-17 04:22:24 --> Loader Class Initialized
DEBUG - 2011-05-17 04:22:24 --> Controller Class Initialized
DEBUG - 2011-05-17 04:22:24 --> Model Class Initialized
DEBUG - 2011-05-17 04:22:24 --> Model Class Initialized
DEBUG - 2011-05-17 04:22:24 --> Model Class Initialized
DEBUG - 2011-05-17 04:22:24 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-05-17 04:22:24 --> Database Driver Class Initialized
DEBUG - 2011-05-17 04:22:30 --> File loaded: application/views/table/main.php
DEBUG - 2011-05-17 04:22:31 --> Helper loaded: url_helper
DEBUG - 2011-05-17 04:22:31 --> File loaded: application/views/common/header.php
DEBUG - 2011-05-17 04:22:31 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-05-17 04:22:31 --> File loaded: application/views/common/footer.php
DEBUG - 2011-05-17 04:22:31 --> File loaded: application/views/layout/main.php
DEBUG - 2011-05-17 04:22:31 --> Final output sent to browser
DEBUG - 2011-05-17 04:22:31 --> Total execution time: 7.1024
DEBUG - 2011-05-17 04:22:39 --> Config Class Initialized
DEBUG - 2011-05-17 04:22:39 --> Hooks Class Initialized
DEBUG - 2011-05-17 04:22:39 --> Utf8 Class Initialized
DEBUG - 2011-05-17 04:22:39 --> UTF-8 Support Enabled
DEBUG - 2011-05-17 04:22:39 --> URI Class Initialized
DEBUG - 2011-05-17 04:22:39 --> Router Class Initialized
DEBUG - 2011-05-17 04:22:39 --> Output Class Initialized
DEBUG - 2011-05-17 04:22:39 --> Input Class Initialized
DEBUG - 2011-05-17 04:22:39 --> Global POST and COOKIE data sanitized
DEBUG - 2011-05-17 04:22:39 --> Language Class Initialized
DEBUG - 2011-05-17 04:22:39 --> Loader Class Initialized
DEBUG - 2011-05-17 04:22:39 --> Controller Class Initialized
ERROR - 2011-05-17 04:22:40 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-05-17 04:22:40 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-05-17 04:22:40 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-05-17 04:22:40 --> Model Class Initialized
DEBUG - 2011-05-17 04:22:40 --> Model Class Initialized
DEBUG - 2011-05-17 04:22:40 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-05-17 04:22:40 --> Database Driver Class Initialized
DEBUG - 2011-05-17 04:22:40 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-05-17 04:22:40 --> Helper loaded: url_helper
DEBUG - 2011-05-17 04:22:40 --> File loaded: application/views/common/header.php
DEBUG - 2011-05-17 04:22:40 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-05-17 04:22:40 --> File loaded: application/views/common/footer.php
DEBUG - 2011-05-17 04:22:40 --> File loaded: application/views/layout/main.php
DEBUG - 2011-05-17 04:22:40 --> Final output sent to browser
DEBUG - 2011-05-17 04:22:40 --> Total execution time: 1.1035
DEBUG - 2011-05-17 04:42:50 --> Config Class Initialized
DEBUG - 2011-05-17 04:42:50 --> Hooks Class Initialized
DEBUG - 2011-05-17 04:42:50 --> Utf8 Class Initialized
DEBUG - 2011-05-17 04:42:50 --> UTF-8 Support Enabled
DEBUG - 2011-05-17 04:42:50 --> URI Class Initialized
DEBUG - 2011-05-17 04:42:50 --> Router Class Initialized
ERROR - 2011-05-17 04:42:50 --> 404 Page Not Found --> robots.txt
DEBUG - 2011-05-17 04:43:47 --> Config Class Initialized
DEBUG - 2011-05-17 04:43:47 --> Hooks Class Initialized
DEBUG - 2011-05-17 04:43:47 --> Utf8 Class Initialized
DEBUG - 2011-05-17 04:43:47 --> UTF-8 Support Enabled
DEBUG - 2011-05-17 04:43:47 --> URI Class Initialized
DEBUG - 2011-05-17 04:43:47 --> Router Class Initialized
DEBUG - 2011-05-17 04:43:47 --> No URI present. Default controller set.
DEBUG - 2011-05-17 04:43:47 --> Output Class Initialized
DEBUG - 2011-05-17 04:43:48 --> Input Class Initialized
DEBUG - 2011-05-17 04:43:48 --> Global POST and COOKIE data sanitized
DEBUG - 2011-05-17 04:43:48 --> Language Class Initialized
DEBUG - 2011-05-17 04:43:49 --> Loader Class Initialized
DEBUG - 2011-05-17 04:43:49 --> Controller Class Initialized
DEBUG - 2011-05-17 04:43:50 --> File loaded: application/views/splash/main.php
DEBUG - 2011-05-17 04:43:50 --> Helper loaded: url_helper
DEBUG - 2011-05-17 04:43:50 --> File loaded: application/views/common/header.php
DEBUG - 2011-05-17 04:43:50 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-05-17 04:43:50 --> File loaded: application/views/common/footer.php
DEBUG - 2011-05-17 04:43:50 --> File loaded: application/views/layout/main.php
DEBUG - 2011-05-17 04:43:50 --> Final output sent to browser
DEBUG - 2011-05-17 04:43:50 --> Total execution time: 2.6956
DEBUG - 2011-05-17 05:29:25 --> Config Class Initialized
DEBUG - 2011-05-17 05:29:25 --> Hooks Class Initialized
DEBUG - 2011-05-17 05:29:25 --> Utf8 Class Initialized
DEBUG - 2011-05-17 05:29:25 --> UTF-8 Support Enabled
DEBUG - 2011-05-17 05:29:25 --> URI Class Initialized
DEBUG - 2011-05-17 05:29:25 --> Router Class Initialized
DEBUG - 2011-05-17 05:29:25 --> Output Class Initialized
DEBUG - 2011-05-17 05:29:25 --> Input Class Initialized
DEBUG - 2011-05-17 05:29:25 --> Global POST and COOKIE data sanitized
DEBUG - 2011-05-17 05:29:25 --> Language Class Initialized
DEBUG - 2011-05-17 05:29:25 --> Loader Class Initialized
DEBUG - 2011-05-17 05:29:25 --> Controller Class Initialized
DEBUG - 2011-05-17 05:29:25 --> Model Class Initialized
DEBUG - 2011-05-17 05:29:25 --> Model Class Initialized
DEBUG - 2011-05-17 05:29:25 --> Model Class Initialized
DEBUG - 2011-05-17 05:29:25 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-05-17 05:29:26 --> Database Driver Class Initialized
DEBUG - 2011-05-17 05:29:26 --> File loaded: application/views/table/main.php
DEBUG - 2011-05-17 05:29:26 --> Helper loaded: url_helper
DEBUG - 2011-05-17 05:29:26 --> File loaded: application/views/common/header.php
DEBUG - 2011-05-17 05:29:26 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-05-17 05:29:26 --> File loaded: application/views/common/footer.php
DEBUG - 2011-05-17 05:29:26 --> File loaded: application/views/layout/main.php
DEBUG - 2011-05-17 05:29:26 --> Final output sent to browser
DEBUG - 2011-05-17 05:29:26 --> Total execution time: 1.2698
DEBUG - 2011-05-17 05:29:29 --> Config Class Initialized
DEBUG - 2011-05-17 05:29:29 --> Hooks Class Initialized
DEBUG - 2011-05-17 05:29:29 --> Utf8 Class Initialized
DEBUG - 2011-05-17 05:29:29 --> UTF-8 Support Enabled
DEBUG - 2011-05-17 05:29:29 --> URI Class Initialized
DEBUG - 2011-05-17 05:29:29 --> Router Class Initialized
ERROR - 2011-05-17 05:29:29 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-05-17 05:29:33 --> Config Class Initialized
DEBUG - 2011-05-17 05:29:33 --> Hooks Class Initialized
DEBUG - 2011-05-17 05:29:33 --> Utf8 Class Initialized
DEBUG - 2011-05-17 05:29:33 --> UTF-8 Support Enabled
DEBUG - 2011-05-17 05:29:33 --> URI Class Initialized
DEBUG - 2011-05-17 05:29:33 --> Router Class Initialized
DEBUG - 2011-05-17 05:29:34 --> Output Class Initialized
DEBUG - 2011-05-17 05:29:34 --> Input Class Initialized
DEBUG - 2011-05-17 05:29:34 --> Global POST and COOKIE data sanitized
DEBUG - 2011-05-17 05:29:34 --> Language Class Initialized
DEBUG - 2011-05-17 05:29:34 --> Loader Class Initialized
DEBUG - 2011-05-17 05:29:34 --> Controller Class Initialized
ERROR - 2011-05-17 05:29:35 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-05-17 05:29:35 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-05-17 05:29:35 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-05-17 05:29:35 --> Model Class Initialized
DEBUG - 2011-05-17 05:29:35 --> Model Class Initialized
DEBUG - 2011-05-17 05:29:35 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-05-17 05:29:35 --> Database Driver Class Initialized
DEBUG - 2011-05-17 05:29:35 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-05-17 05:29:35 --> Helper loaded: url_helper
DEBUG - 2011-05-17 05:29:35 --> File loaded: application/views/common/header.php
DEBUG - 2011-05-17 05:29:35 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-05-17 05:29:35 --> File loaded: application/views/common/footer.php
DEBUG - 2011-05-17 05:29:35 --> File loaded: application/views/layout/main.php
DEBUG - 2011-05-17 05:29:35 --> Final output sent to browser
DEBUG - 2011-05-17 05:29:35 --> Total execution time: 1.8316
DEBUG - 2011-05-17 05:29:36 --> Config Class Initialized
DEBUG - 2011-05-17 05:29:36 --> Hooks Class Initialized
DEBUG - 2011-05-17 05:29:36 --> Utf8 Class Initialized
DEBUG - 2011-05-17 05:29:36 --> UTF-8 Support Enabled
DEBUG - 2011-05-17 05:29:36 --> URI Class Initialized
DEBUG - 2011-05-17 05:29:36 --> Router Class Initialized
DEBUG - 2011-05-17 05:29:36 --> Output Class Initialized
DEBUG - 2011-05-17 05:29:36 --> Input Class Initialized
DEBUG - 2011-05-17 05:29:36 --> Global POST and COOKIE data sanitized
DEBUG - 2011-05-17 05:29:36 --> Language Class Initialized
DEBUG - 2011-05-17 05:29:36 --> Loader Class Initialized
DEBUG - 2011-05-17 05:29:36 --> Controller Class Initialized
DEBUG - 2011-05-17 05:29:36 --> Model Class Initialized
DEBUG - 2011-05-17 05:29:36 --> Model Class Initialized
DEBUG - 2011-05-17 05:29:36 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-05-17 05:29:36 --> Database Driver Class Initialized
DEBUG - 2011-05-17 05:29:37 --> Final output sent to browser
DEBUG - 2011-05-17 05:29:37 --> Total execution time: 0.8266
DEBUG - 2011-05-17 05:29:39 --> Config Class Initialized
DEBUG - 2011-05-17 05:29:39 --> Hooks Class Initialized
DEBUG - 2011-05-17 05:29:39 --> Utf8 Class Initialized
DEBUG - 2011-05-17 05:29:39 --> UTF-8 Support Enabled
DEBUG - 2011-05-17 05:29:39 --> URI Class Initialized
DEBUG - 2011-05-17 05:29:39 --> Router Class Initialized
ERROR - 2011-05-17 05:29:39 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-05-17 05:29:44 --> Config Class Initialized
DEBUG - 2011-05-17 05:29:44 --> Hooks Class Initialized
DEBUG - 2011-05-17 05:29:44 --> Utf8 Class Initialized
DEBUG - 2011-05-17 05:29:44 --> UTF-8 Support Enabled
DEBUG - 2011-05-17 05:29:44 --> URI Class Initialized
DEBUG - 2011-05-17 05:29:44 --> Router Class Initialized
DEBUG - 2011-05-17 05:29:44 --> Output Class Initialized
DEBUG - 2011-05-17 05:29:44 --> Input Class Initialized
DEBUG - 2011-05-17 05:29:44 --> Global POST and COOKIE data sanitized
DEBUG - 2011-05-17 05:29:44 --> Language Class Initialized
DEBUG - 2011-05-17 05:29:44 --> Loader Class Initialized
DEBUG - 2011-05-17 05:29:44 --> Controller Class Initialized
ERROR - 2011-05-17 05:29:44 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-05-17 05:29:44 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-05-17 05:29:44 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-05-17 05:29:44 --> Model Class Initialized
DEBUG - 2011-05-17 05:29:44 --> Model Class Initialized
DEBUG - 2011-05-17 05:29:44 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-05-17 05:29:44 --> Database Driver Class Initialized
DEBUG - 2011-05-17 05:29:44 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-05-17 05:29:44 --> Helper loaded: url_helper
DEBUG - 2011-05-17 05:29:44 --> File loaded: application/views/common/header.php
DEBUG - 2011-05-17 05:29:44 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-05-17 05:29:44 --> File loaded: application/views/common/footer.php
DEBUG - 2011-05-17 05:29:44 --> File loaded: application/views/layout/main.php
DEBUG - 2011-05-17 05:29:44 --> Final output sent to browser
DEBUG - 2011-05-17 05:29:44 --> Total execution time: 0.0341
DEBUG - 2011-05-17 05:29:45 --> Config Class Initialized
DEBUG - 2011-05-17 05:29:45 --> Hooks Class Initialized
DEBUG - 2011-05-17 05:29:45 --> Utf8 Class Initialized
DEBUG - 2011-05-17 05:29:45 --> UTF-8 Support Enabled
DEBUG - 2011-05-17 05:29:45 --> URI Class Initialized
DEBUG - 2011-05-17 05:29:45 --> Router Class Initialized
DEBUG - 2011-05-17 05:29:45 --> Output Class Initialized
DEBUG - 2011-05-17 05:29:45 --> Input Class Initialized
DEBUG - 2011-05-17 05:29:45 --> Global POST and COOKIE data sanitized
DEBUG - 2011-05-17 05:29:45 --> Language Class Initialized
DEBUG - 2011-05-17 05:29:45 --> Loader Class Initialized
DEBUG - 2011-05-17 05:29:45 --> Controller Class Initialized
DEBUG - 2011-05-17 05:29:45 --> Model Class Initialized
DEBUG - 2011-05-17 05:29:45 --> Model Class Initialized
DEBUG - 2011-05-17 05:29:45 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-05-17 05:29:45 --> Database Driver Class Initialized
DEBUG - 2011-05-17 05:29:45 --> Final output sent to browser
DEBUG - 2011-05-17 05:29:45 --> Total execution time: 0.5128
DEBUG - 2011-05-17 05:29:47 --> Config Class Initialized
DEBUG - 2011-05-17 05:29:47 --> Hooks Class Initialized
DEBUG - 2011-05-17 05:29:47 --> Utf8 Class Initialized
DEBUG - 2011-05-17 05:29:47 --> UTF-8 Support Enabled
DEBUG - 2011-05-17 05:29:47 --> URI Class Initialized
DEBUG - 2011-05-17 05:29:47 --> Router Class Initialized
ERROR - 2011-05-17 05:29:47 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-05-17 05:29:47 --> Config Class Initialized
DEBUG - 2011-05-17 05:29:47 --> Hooks Class Initialized
DEBUG - 2011-05-17 05:29:47 --> Utf8 Class Initialized
DEBUG - 2011-05-17 05:29:47 --> UTF-8 Support Enabled
DEBUG - 2011-05-17 05:29:47 --> URI Class Initialized
DEBUG - 2011-05-17 05:29:47 --> Router Class Initialized
ERROR - 2011-05-17 05:29:47 --> 404 Page Not Found --> robots.txt
DEBUG - 2011-05-17 05:29:47 --> Config Class Initialized
DEBUG - 2011-05-17 05:29:47 --> Hooks Class Initialized
DEBUG - 2011-05-17 05:29:47 --> Utf8 Class Initialized
DEBUG - 2011-05-17 05:29:47 --> UTF-8 Support Enabled
DEBUG - 2011-05-17 05:29:47 --> URI Class Initialized
DEBUG - 2011-05-17 05:29:47 --> Router Class Initialized
DEBUG - 2011-05-17 05:29:47 --> Output Class Initialized
DEBUG - 2011-05-17 05:29:47 --> Input Class Initialized
DEBUG - 2011-05-17 05:29:47 --> Global POST and COOKIE data sanitized
DEBUG - 2011-05-17 05:29:47 --> Language Class Initialized
DEBUG - 2011-05-17 05:29:47 --> Loader Class Initialized
DEBUG - 2011-05-17 05:29:47 --> Controller Class Initialized
ERROR - 2011-05-17 05:29:47 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-05-17 05:29:47 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-05-17 05:29:47 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-05-17 05:29:47 --> Model Class Initialized
DEBUG - 2011-05-17 05:29:47 --> Model Class Initialized
DEBUG - 2011-05-17 05:29:47 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-05-17 05:29:47 --> Database Driver Class Initialized
DEBUG - 2011-05-17 05:29:47 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-05-17 05:29:47 --> Helper loaded: url_helper
DEBUG - 2011-05-17 05:29:47 --> File loaded: application/views/common/header.php
DEBUG - 2011-05-17 05:29:47 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-05-17 05:29:47 --> File loaded: application/views/common/footer.php
DEBUG - 2011-05-17 05:29:47 --> File loaded: application/views/layout/main.php
DEBUG - 2011-05-17 05:29:47 --> Final output sent to browser
DEBUG - 2011-05-17 05:29:47 --> Total execution time: 0.0295
DEBUG - 2011-05-17 05:29:48 --> Config Class Initialized
DEBUG - 2011-05-17 05:29:48 --> Hooks Class Initialized
DEBUG - 2011-05-17 05:29:48 --> Utf8 Class Initialized
DEBUG - 2011-05-17 05:29:48 --> UTF-8 Support Enabled
DEBUG - 2011-05-17 05:29:48 --> URI Class Initialized
DEBUG - 2011-05-17 05:29:48 --> Router Class Initialized
DEBUG - 2011-05-17 05:29:48 --> Output Class Initialized
DEBUG - 2011-05-17 05:29:48 --> Input Class Initialized
DEBUG - 2011-05-17 05:29:48 --> Global POST and COOKIE data sanitized
DEBUG - 2011-05-17 05:29:48 --> Language Class Initialized
DEBUG - 2011-05-17 05:29:48 --> Loader Class Initialized
DEBUG - 2011-05-17 05:29:48 --> Controller Class Initialized
ERROR - 2011-05-17 05:29:48 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-05-17 05:29:48 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-05-17 05:29:48 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-05-17 05:29:48 --> Model Class Initialized
DEBUG - 2011-05-17 05:29:48 --> Model Class Initialized
DEBUG - 2011-05-17 05:29:48 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-05-17 05:29:48 --> Database Driver Class Initialized
DEBUG - 2011-05-17 05:29:48 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-05-17 05:29:48 --> Helper loaded: url_helper
DEBUG - 2011-05-17 05:29:48 --> File loaded: application/views/common/header.php
DEBUG - 2011-05-17 05:29:48 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-05-17 05:29:48 --> File loaded: application/views/common/footer.php
DEBUG - 2011-05-17 05:29:48 --> File loaded: application/views/layout/main.php
DEBUG - 2011-05-17 05:29:48 --> Final output sent to browser
DEBUG - 2011-05-17 05:29:48 --> Total execution time: 0.0310
DEBUG - 2011-05-17 05:29:49 --> Config Class Initialized
DEBUG - 2011-05-17 05:29:49 --> Hooks Class Initialized
DEBUG - 2011-05-17 05:29:49 --> Utf8 Class Initialized
DEBUG - 2011-05-17 05:29:49 --> UTF-8 Support Enabled
DEBUG - 2011-05-17 05:29:49 --> URI Class Initialized
DEBUG - 2011-05-17 05:29:49 --> Router Class Initialized
DEBUG - 2011-05-17 05:29:49 --> Output Class Initialized
DEBUG - 2011-05-17 05:29:49 --> Input Class Initialized
DEBUG - 2011-05-17 05:29:49 --> Global POST and COOKIE data sanitized
DEBUG - 2011-05-17 05:29:49 --> Language Class Initialized
DEBUG - 2011-05-17 05:29:49 --> Loader Class Initialized
DEBUG - 2011-05-17 05:29:49 --> Controller Class Initialized
DEBUG - 2011-05-17 05:29:49 --> Model Class Initialized
DEBUG - 2011-05-17 05:29:49 --> Model Class Initialized
DEBUG - 2011-05-17 05:29:49 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-05-17 05:29:49 --> Database Driver Class Initialized
DEBUG - 2011-05-17 05:29:50 --> Final output sent to browser
DEBUG - 2011-05-17 05:29:50 --> Total execution time: 0.5826
DEBUG - 2011-05-17 05:29:50 --> Config Class Initialized
DEBUG - 2011-05-17 05:29:50 --> Hooks Class Initialized
DEBUG - 2011-05-17 05:29:50 --> Utf8 Class Initialized
DEBUG - 2011-05-17 05:29:50 --> UTF-8 Support Enabled
DEBUG - 2011-05-17 05:29:50 --> URI Class Initialized
DEBUG - 2011-05-17 05:29:50 --> Router Class Initialized
DEBUG - 2011-05-17 05:29:50 --> Output Class Initialized
DEBUG - 2011-05-17 05:29:50 --> Input Class Initialized
DEBUG - 2011-05-17 05:29:50 --> Global POST and COOKIE data sanitized
DEBUG - 2011-05-17 05:29:50 --> Language Class Initialized
DEBUG - 2011-05-17 05:29:50 --> Loader Class Initialized
DEBUG - 2011-05-17 05:29:50 --> Controller Class Initialized
ERROR - 2011-05-17 05:29:50 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-05-17 05:29:50 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-05-17 05:29:50 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-05-17 05:29:50 --> Model Class Initialized
DEBUG - 2011-05-17 05:29:50 --> Model Class Initialized
DEBUG - 2011-05-17 05:29:50 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-05-17 05:29:50 --> Database Driver Class Initialized
DEBUG - 2011-05-17 05:29:50 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-05-17 05:29:50 --> Helper loaded: url_helper
DEBUG - 2011-05-17 05:29:50 --> File loaded: application/views/common/header.php
DEBUG - 2011-05-17 05:29:50 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-05-17 05:29:50 --> File loaded: application/views/common/footer.php
DEBUG - 2011-05-17 05:29:50 --> File loaded: application/views/layout/main.php
DEBUG - 2011-05-17 05:29:50 --> Final output sent to browser
DEBUG - 2011-05-17 05:29:50 --> Total execution time: 0.0320
DEBUG - 2011-05-17 05:29:52 --> Config Class Initialized
DEBUG - 2011-05-17 05:29:52 --> Hooks Class Initialized
DEBUG - 2011-05-17 05:29:52 --> Utf8 Class Initialized
DEBUG - 2011-05-17 05:29:52 --> UTF-8 Support Enabled
DEBUG - 2011-05-17 05:29:52 --> URI Class Initialized
DEBUG - 2011-05-17 05:29:52 --> Router Class Initialized
ERROR - 2011-05-17 05:29:52 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-05-17 05:38:43 --> Config Class Initialized
DEBUG - 2011-05-17 05:38:43 --> Hooks Class Initialized
DEBUG - 2011-05-17 05:38:43 --> Utf8 Class Initialized
DEBUG - 2011-05-17 05:38:43 --> UTF-8 Support Enabled
DEBUG - 2011-05-17 05:38:43 --> URI Class Initialized
DEBUG - 2011-05-17 05:38:43 --> Router Class Initialized
DEBUG - 2011-05-17 05:38:43 --> Output Class Initialized
DEBUG - 2011-05-17 05:38:43 --> Input Class Initialized
DEBUG - 2011-05-17 05:38:43 --> Global POST and COOKIE data sanitized
DEBUG - 2011-05-17 05:38:43 --> Language Class Initialized
DEBUG - 2011-05-17 05:38:43 --> Loader Class Initialized
DEBUG - 2011-05-17 05:38:43 --> Controller Class Initialized
ERROR - 2011-05-17 05:38:43 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-05-17 05:38:43 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-05-17 05:38:43 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-05-17 05:38:43 --> Model Class Initialized
DEBUG - 2011-05-17 05:38:43 --> Model Class Initialized
DEBUG - 2011-05-17 05:38:43 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-05-17 05:38:44 --> Database Driver Class Initialized
DEBUG - 2011-05-17 05:38:44 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-05-17 05:38:44 --> Helper loaded: url_helper
DEBUG - 2011-05-17 05:38:44 --> File loaded: application/views/common/header.php
DEBUG - 2011-05-17 05:38:44 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-05-17 05:38:44 --> File loaded: application/views/common/footer.php
DEBUG - 2011-05-17 05:38:44 --> File loaded: application/views/layout/main.php
DEBUG - 2011-05-17 05:38:44 --> Final output sent to browser
DEBUG - 2011-05-17 05:38:44 --> Total execution time: 0.3704
DEBUG - 2011-05-17 05:38:45 --> Config Class Initialized
DEBUG - 2011-05-17 05:38:45 --> Hooks Class Initialized
DEBUG - 2011-05-17 05:38:45 --> Utf8 Class Initialized
DEBUG - 2011-05-17 05:38:45 --> UTF-8 Support Enabled
DEBUG - 2011-05-17 05:38:45 --> URI Class Initialized
DEBUG - 2011-05-17 05:38:45 --> Router Class Initialized
DEBUG - 2011-05-17 05:38:45 --> Output Class Initialized
DEBUG - 2011-05-17 05:38:45 --> Input Class Initialized
DEBUG - 2011-05-17 05:38:45 --> Global POST and COOKIE data sanitized
DEBUG - 2011-05-17 05:38:45 --> Language Class Initialized
DEBUG - 2011-05-17 05:38:45 --> Loader Class Initialized
DEBUG - 2011-05-17 05:38:45 --> Controller Class Initialized
DEBUG - 2011-05-17 05:38:45 --> Model Class Initialized
DEBUG - 2011-05-17 05:38:45 --> Model Class Initialized
DEBUG - 2011-05-17 05:38:45 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-05-17 05:38:45 --> Database Driver Class Initialized
DEBUG - 2011-05-17 05:38:46 --> Final output sent to browser
DEBUG - 2011-05-17 05:38:46 --> Total execution time: 0.7383
DEBUG - 2011-05-17 05:41:54 --> Config Class Initialized
DEBUG - 2011-05-17 05:41:54 --> Hooks Class Initialized
DEBUG - 2011-05-17 05:41:54 --> Utf8 Class Initialized
DEBUG - 2011-05-17 05:41:54 --> UTF-8 Support Enabled
DEBUG - 2011-05-17 05:41:54 --> URI Class Initialized
DEBUG - 2011-05-17 05:41:54 --> Router Class Initialized
DEBUG - 2011-05-17 05:41:54 --> Output Class Initialized
DEBUG - 2011-05-17 05:41:54 --> Input Class Initialized
DEBUG - 2011-05-17 05:41:54 --> Global POST and COOKIE data sanitized
DEBUG - 2011-05-17 05:41:54 --> Language Class Initialized
DEBUG - 2011-05-17 05:41:55 --> Loader Class Initialized
DEBUG - 2011-05-17 05:41:55 --> Controller Class Initialized
DEBUG - 2011-05-17 05:41:55 --> Model Class Initialized
DEBUG - 2011-05-17 05:41:55 --> Model Class Initialized
DEBUG - 2011-05-17 05:41:55 --> Model Class Initialized
DEBUG - 2011-05-17 05:41:55 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-05-17 05:41:55 --> Database Driver Class Initialized
DEBUG - 2011-05-17 05:41:56 --> File loaded: application/views/table/main.php
DEBUG - 2011-05-17 05:41:56 --> Helper loaded: url_helper
DEBUG - 2011-05-17 05:41:56 --> File loaded: application/views/common/header.php
DEBUG - 2011-05-17 05:41:56 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-05-17 05:41:56 --> File loaded: application/views/common/footer.php
DEBUG - 2011-05-17 05:41:56 --> File loaded: application/views/layout/main.php
DEBUG - 2011-05-17 05:41:56 --> Final output sent to browser
DEBUG - 2011-05-17 05:41:56 --> Total execution time: 2.3697
DEBUG - 2011-05-17 05:41:58 --> Config Class Initialized
DEBUG - 2011-05-17 05:41:58 --> Hooks Class Initialized
DEBUG - 2011-05-17 05:41:58 --> Utf8 Class Initialized
DEBUG - 2011-05-17 05:41:58 --> UTF-8 Support Enabled
DEBUG - 2011-05-17 05:41:58 --> URI Class Initialized
DEBUG - 2011-05-17 05:41:58 --> Router Class Initialized
ERROR - 2011-05-17 05:41:58 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-05-17 05:42:24 --> Config Class Initialized
DEBUG - 2011-05-17 05:42:24 --> Hooks Class Initialized
DEBUG - 2011-05-17 05:42:24 --> Utf8 Class Initialized
DEBUG - 2011-05-17 05:42:24 --> UTF-8 Support Enabled
DEBUG - 2011-05-17 05:42:24 --> URI Class Initialized
DEBUG - 2011-05-17 05:42:24 --> Router Class Initialized
DEBUG - 2011-05-17 05:42:24 --> Output Class Initialized
DEBUG - 2011-05-17 05:42:24 --> Input Class Initialized
DEBUG - 2011-05-17 05:42:24 --> Global POST and COOKIE data sanitized
DEBUG - 2011-05-17 05:42:24 --> Language Class Initialized
DEBUG - 2011-05-17 05:42:24 --> Loader Class Initialized
DEBUG - 2011-05-17 05:42:24 --> Controller Class Initialized
DEBUG - 2011-05-17 05:42:24 --> Model Class Initialized
DEBUG - 2011-05-17 05:42:24 --> Model Class Initialized
DEBUG - 2011-05-17 05:42:24 --> Model Class Initialized
DEBUG - 2011-05-17 05:42:24 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-05-17 05:42:24 --> Database Driver Class Initialized
DEBUG - 2011-05-17 05:42:33 --> File loaded: application/views/table/main.php
DEBUG - 2011-05-17 05:42:33 --> Helper loaded: url_helper
DEBUG - 2011-05-17 05:42:33 --> File loaded: application/views/common/header.php
DEBUG - 2011-05-17 05:42:33 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-05-17 05:42:33 --> File loaded: application/views/common/footer.php
DEBUG - 2011-05-17 05:42:33 --> File loaded: application/views/layout/main.php
DEBUG - 2011-05-17 05:42:33 --> Final output sent to browser
DEBUG - 2011-05-17 05:42:33 --> Total execution time: 9.0340
DEBUG - 2011-05-17 05:42:35 --> Config Class Initialized
DEBUG - 2011-05-17 05:42:35 --> Hooks Class Initialized
DEBUG - 2011-05-17 05:42:35 --> Utf8 Class Initialized
DEBUG - 2011-05-17 05:42:35 --> UTF-8 Support Enabled
DEBUG - 2011-05-17 05:42:35 --> URI Class Initialized
DEBUG - 2011-05-17 05:42:35 --> Router Class Initialized
DEBUG - 2011-05-17 05:42:35 --> Output Class Initialized
DEBUG - 2011-05-17 05:42:35 --> Input Class Initialized
DEBUG - 2011-05-17 05:42:35 --> Global POST and COOKIE data sanitized
DEBUG - 2011-05-17 05:42:35 --> Language Class Initialized
DEBUG - 2011-05-17 05:42:35 --> Loader Class Initialized
DEBUG - 2011-05-17 05:42:35 --> Controller Class Initialized
DEBUG - 2011-05-17 05:42:35 --> Model Class Initialized
DEBUG - 2011-05-17 05:42:35 --> Model Class Initialized
DEBUG - 2011-05-17 05:42:35 --> Model Class Initialized
DEBUG - 2011-05-17 05:42:35 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-05-17 05:42:35 --> Database Driver Class Initialized
DEBUG - 2011-05-17 05:42:35 --> File loaded: application/views/table/main.php
DEBUG - 2011-05-17 05:42:35 --> Helper loaded: url_helper
DEBUG - 2011-05-17 05:42:35 --> File loaded: application/views/common/header.php
DEBUG - 2011-05-17 05:42:35 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-05-17 05:42:35 --> File loaded: application/views/common/footer.php
DEBUG - 2011-05-17 05:42:35 --> File loaded: application/views/layout/main.php
DEBUG - 2011-05-17 05:42:35 --> Final output sent to browser
DEBUG - 2011-05-17 05:42:35 --> Total execution time: 0.1214
DEBUG - 2011-05-17 05:42:59 --> Config Class Initialized
DEBUG - 2011-05-17 05:42:59 --> Hooks Class Initialized
DEBUG - 2011-05-17 05:42:59 --> Utf8 Class Initialized
DEBUG - 2011-05-17 05:42:59 --> UTF-8 Support Enabled
DEBUG - 2011-05-17 05:42:59 --> URI Class Initialized
DEBUG - 2011-05-17 05:42:59 --> Router Class Initialized
DEBUG - 2011-05-17 05:42:59 --> Output Class Initialized
DEBUG - 2011-05-17 05:42:59 --> Input Class Initialized
DEBUG - 2011-05-17 05:42:59 --> Global POST and COOKIE data sanitized
DEBUG - 2011-05-17 05:42:59 --> Language Class Initialized
DEBUG - 2011-05-17 05:42:59 --> Loader Class Initialized
DEBUG - 2011-05-17 05:42:59 --> Controller Class Initialized
DEBUG - 2011-05-17 05:42:59 --> Model Class Initialized
DEBUG - 2011-05-17 05:42:59 --> Model Class Initialized
DEBUG - 2011-05-17 05:42:59 --> Model Class Initialized
DEBUG - 2011-05-17 05:42:59 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-05-17 05:42:59 --> Database Driver Class Initialized
DEBUG - 2011-05-17 05:42:59 --> File loaded: application/views/table/main.php
DEBUG - 2011-05-17 05:42:59 --> Helper loaded: url_helper
DEBUG - 2011-05-17 05:42:59 --> File loaded: application/views/common/header.php
DEBUG - 2011-05-17 05:42:59 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-05-17 05:42:59 --> File loaded: application/views/common/footer.php
DEBUG - 2011-05-17 05:42:59 --> File loaded: application/views/layout/main.php
DEBUG - 2011-05-17 05:42:59 --> Final output sent to browser
DEBUG - 2011-05-17 05:42:59 --> Total execution time: 0.3428
DEBUG - 2011-05-17 05:43:00 --> Config Class Initialized
DEBUG - 2011-05-17 05:43:00 --> Hooks Class Initialized
DEBUG - 2011-05-17 05:43:00 --> Utf8 Class Initialized
DEBUG - 2011-05-17 05:43:00 --> UTF-8 Support Enabled
DEBUG - 2011-05-17 05:43:00 --> URI Class Initialized
DEBUG - 2011-05-17 05:43:00 --> Router Class Initialized
DEBUG - 2011-05-17 05:43:00 --> Output Class Initialized
DEBUG - 2011-05-17 05:43:00 --> Input Class Initialized
DEBUG - 2011-05-17 05:43:00 --> Global POST and COOKIE data sanitized
DEBUG - 2011-05-17 05:43:00 --> Language Class Initialized
DEBUG - 2011-05-17 05:43:00 --> Loader Class Initialized
DEBUG - 2011-05-17 05:43:00 --> Controller Class Initialized
DEBUG - 2011-05-17 05:43:00 --> Model Class Initialized
DEBUG - 2011-05-17 05:43:00 --> Model Class Initialized
DEBUG - 2011-05-17 05:43:00 --> Model Class Initialized
DEBUG - 2011-05-17 05:43:00 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-05-17 05:43:00 --> Database Driver Class Initialized
DEBUG - 2011-05-17 05:43:00 --> File loaded: application/views/table/main.php
DEBUG - 2011-05-17 05:43:00 --> Helper loaded: url_helper
DEBUG - 2011-05-17 05:43:00 --> File loaded: application/views/common/header.php
DEBUG - 2011-05-17 05:43:00 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-05-17 05:43:00 --> File loaded: application/views/common/footer.php
DEBUG - 2011-05-17 05:43:00 --> File loaded: application/views/layout/main.php
DEBUG - 2011-05-17 05:43:00 --> Final output sent to browser
DEBUG - 2011-05-17 05:43:00 --> Total execution time: 0.0539
DEBUG - 2011-05-17 05:43:00 --> Config Class Initialized
DEBUG - 2011-05-17 05:43:00 --> Hooks Class Initialized
DEBUG - 2011-05-17 05:43:00 --> Utf8 Class Initialized
DEBUG - 2011-05-17 05:43:00 --> UTF-8 Support Enabled
DEBUG - 2011-05-17 05:43:00 --> URI Class Initialized
DEBUG - 2011-05-17 05:43:00 --> Router Class Initialized
DEBUG - 2011-05-17 05:43:00 --> Output Class Initialized
DEBUG - 2011-05-17 05:43:00 --> Input Class Initialized
DEBUG - 2011-05-17 05:43:00 --> Global POST and COOKIE data sanitized
DEBUG - 2011-05-17 05:43:00 --> Language Class Initialized
DEBUG - 2011-05-17 05:43:00 --> Loader Class Initialized
DEBUG - 2011-05-17 05:43:00 --> Controller Class Initialized
DEBUG - 2011-05-17 05:43:00 --> Model Class Initialized
DEBUG - 2011-05-17 05:43:00 --> Model Class Initialized
DEBUG - 2011-05-17 05:43:00 --> Model Class Initialized
DEBUG - 2011-05-17 05:43:00 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-05-17 05:43:00 --> Database Driver Class Initialized
DEBUG - 2011-05-17 05:43:00 --> File loaded: application/views/table/main.php
DEBUG - 2011-05-17 05:43:00 --> Helper loaded: url_helper
DEBUG - 2011-05-17 05:43:00 --> File loaded: application/views/common/header.php
DEBUG - 2011-05-17 05:43:00 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-05-17 05:43:00 --> File loaded: application/views/common/footer.php
DEBUG - 2011-05-17 05:43:00 --> File loaded: application/views/layout/main.php
DEBUG - 2011-05-17 05:43:00 --> Final output sent to browser
DEBUG - 2011-05-17 05:43:00 --> Total execution time: 0.0646
DEBUG - 2011-05-17 05:43:16 --> Config Class Initialized
DEBUG - 2011-05-17 05:43:16 --> Hooks Class Initialized
DEBUG - 2011-05-17 05:43:16 --> Utf8 Class Initialized
DEBUG - 2011-05-17 05:43:16 --> UTF-8 Support Enabled
DEBUG - 2011-05-17 05:43:16 --> URI Class Initialized
DEBUG - 2011-05-17 05:43:16 --> Router Class Initialized
DEBUG - 2011-05-17 05:43:16 --> Output Class Initialized
DEBUG - 2011-05-17 05:43:16 --> Input Class Initialized
DEBUG - 2011-05-17 05:43:16 --> Global POST and COOKIE data sanitized
DEBUG - 2011-05-17 05:43:16 --> Language Class Initialized
DEBUG - 2011-05-17 05:43:16 --> Loader Class Initialized
DEBUG - 2011-05-17 05:43:16 --> Controller Class Initialized
DEBUG - 2011-05-17 05:43:16 --> Model Class Initialized
DEBUG - 2011-05-17 05:43:16 --> Model Class Initialized
DEBUG - 2011-05-17 05:43:16 --> Model Class Initialized
DEBUG - 2011-05-17 05:43:16 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-05-17 05:43:16 --> Database Driver Class Initialized
DEBUG - 2011-05-17 05:43:17 --> File loaded: application/views/table/main.php
DEBUG - 2011-05-17 05:43:17 --> Helper loaded: url_helper
DEBUG - 2011-05-17 05:43:17 --> File loaded: application/views/common/header.php
DEBUG - 2011-05-17 05:43:17 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-05-17 05:43:17 --> File loaded: application/views/common/footer.php
DEBUG - 2011-05-17 05:43:17 --> File loaded: application/views/layout/main.php
DEBUG - 2011-05-17 05:43:17 --> Final output sent to browser
DEBUG - 2011-05-17 05:43:17 --> Total execution time: 0.8835
DEBUG - 2011-05-17 05:43:18 --> Config Class Initialized
DEBUG - 2011-05-17 05:43:18 --> Hooks Class Initialized
DEBUG - 2011-05-17 05:43:18 --> Utf8 Class Initialized
DEBUG - 2011-05-17 05:43:18 --> UTF-8 Support Enabled
DEBUG - 2011-05-17 05:43:18 --> URI Class Initialized
DEBUG - 2011-05-17 05:43:18 --> Router Class Initialized
DEBUG - 2011-05-17 05:43:18 --> Output Class Initialized
DEBUG - 2011-05-17 05:43:18 --> Input Class Initialized
DEBUG - 2011-05-17 05:43:18 --> Global POST and COOKIE data sanitized
DEBUG - 2011-05-17 05:43:18 --> Language Class Initialized
DEBUG - 2011-05-17 05:43:18 --> Loader Class Initialized
DEBUG - 2011-05-17 05:43:18 --> Controller Class Initialized
DEBUG - 2011-05-17 05:43:18 --> Model Class Initialized
DEBUG - 2011-05-17 05:43:18 --> Model Class Initialized
DEBUG - 2011-05-17 05:43:18 --> Model Class Initialized
DEBUG - 2011-05-17 05:43:18 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-05-17 05:43:18 --> Database Driver Class Initialized
DEBUG - 2011-05-17 05:43:18 --> File loaded: application/views/table/main.php
DEBUG - 2011-05-17 05:43:18 --> Helper loaded: url_helper
DEBUG - 2011-05-17 05:43:18 --> File loaded: application/views/common/header.php
DEBUG - 2011-05-17 05:43:18 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-05-17 05:43:18 --> File loaded: application/views/common/footer.php
DEBUG - 2011-05-17 05:43:18 --> File loaded: application/views/layout/main.php
DEBUG - 2011-05-17 05:43:18 --> Final output sent to browser
DEBUG - 2011-05-17 05:43:18 --> Total execution time: 0.1202
DEBUG - 2011-05-17 05:43:18 --> Config Class Initialized
DEBUG - 2011-05-17 05:43:18 --> Hooks Class Initialized
DEBUG - 2011-05-17 05:43:18 --> Utf8 Class Initialized
DEBUG - 2011-05-17 05:43:18 --> UTF-8 Support Enabled
DEBUG - 2011-05-17 05:43:18 --> URI Class Initialized
DEBUG - 2011-05-17 05:43:18 --> Router Class Initialized
DEBUG - 2011-05-17 05:43:18 --> Output Class Initialized
DEBUG - 2011-05-17 05:43:18 --> Input Class Initialized
DEBUG - 2011-05-17 05:43:18 --> Global POST and COOKIE data sanitized
DEBUG - 2011-05-17 05:43:18 --> Language Class Initialized
DEBUG - 2011-05-17 05:43:18 --> Loader Class Initialized
DEBUG - 2011-05-17 05:43:18 --> Controller Class Initialized
DEBUG - 2011-05-17 05:43:18 --> Model Class Initialized
DEBUG - 2011-05-17 05:43:18 --> Model Class Initialized
DEBUG - 2011-05-17 05:43:18 --> Model Class Initialized
DEBUG - 2011-05-17 05:43:18 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-05-17 05:43:18 --> Database Driver Class Initialized
DEBUG - 2011-05-17 05:43:18 --> File loaded: application/views/table/main.php
DEBUG - 2011-05-17 05:43:18 --> Helper loaded: url_helper
DEBUG - 2011-05-17 05:43:18 --> File loaded: application/views/common/header.php
DEBUG - 2011-05-17 05:43:18 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-05-17 05:43:18 --> File loaded: application/views/common/footer.php
DEBUG - 2011-05-17 05:43:18 --> File loaded: application/views/layout/main.php
DEBUG - 2011-05-17 05:43:18 --> Final output sent to browser
DEBUG - 2011-05-17 05:43:18 --> Total execution time: 0.1484
DEBUG - 2011-05-17 05:43:38 --> Config Class Initialized
DEBUG - 2011-05-17 05:43:38 --> Hooks Class Initialized
DEBUG - 2011-05-17 05:43:38 --> Utf8 Class Initialized
DEBUG - 2011-05-17 05:43:38 --> UTF-8 Support Enabled
DEBUG - 2011-05-17 05:43:38 --> URI Class Initialized
DEBUG - 2011-05-17 05:43:38 --> Router Class Initialized
DEBUG - 2011-05-17 05:43:38 --> Output Class Initialized
DEBUG - 2011-05-17 05:43:38 --> Input Class Initialized
DEBUG - 2011-05-17 05:43:38 --> Global POST and COOKIE data sanitized
DEBUG - 2011-05-17 05:43:38 --> Language Class Initialized
DEBUG - 2011-05-17 05:43:38 --> Loader Class Initialized
DEBUG - 2011-05-17 05:43:38 --> Controller Class Initialized
DEBUG - 2011-05-17 05:43:38 --> Model Class Initialized
DEBUG - 2011-05-17 05:43:38 --> Model Class Initialized
DEBUG - 2011-05-17 05:43:38 --> Model Class Initialized
DEBUG - 2011-05-17 05:43:38 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-05-17 05:43:38 --> Database Driver Class Initialized
DEBUG - 2011-05-17 05:43:39 --> File loaded: application/views/table/main.php
DEBUG - 2011-05-17 05:43:39 --> Helper loaded: url_helper
DEBUG - 2011-05-17 05:43:39 --> File loaded: application/views/common/header.php
DEBUG - 2011-05-17 05:43:39 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-05-17 05:43:39 --> File loaded: application/views/common/footer.php
DEBUG - 2011-05-17 05:43:39 --> File loaded: application/views/layout/main.php
DEBUG - 2011-05-17 05:43:39 --> Final output sent to browser
DEBUG - 2011-05-17 05:43:39 --> Total execution time: 0.3162
DEBUG - 2011-05-17 05:43:41 --> Config Class Initialized
DEBUG - 2011-05-17 05:43:41 --> Hooks Class Initialized
DEBUG - 2011-05-17 05:43:41 --> Utf8 Class Initialized
DEBUG - 2011-05-17 05:43:41 --> UTF-8 Support Enabled
DEBUG - 2011-05-17 05:43:41 --> URI Class Initialized
DEBUG - 2011-05-17 05:43:41 --> Router Class Initialized
DEBUG - 2011-05-17 05:43:41 --> Output Class Initialized
DEBUG - 2011-05-17 05:43:41 --> Input Class Initialized
DEBUG - 2011-05-17 05:43:41 --> Global POST and COOKIE data sanitized
DEBUG - 2011-05-17 05:43:41 --> Language Class Initialized
DEBUG - 2011-05-17 05:43:41 --> Loader Class Initialized
DEBUG - 2011-05-17 05:43:41 --> Controller Class Initialized
DEBUG - 2011-05-17 05:43:41 --> Model Class Initialized
DEBUG - 2011-05-17 05:43:41 --> Model Class Initialized
DEBUG - 2011-05-17 05:43:41 --> Model Class Initialized
DEBUG - 2011-05-17 05:43:41 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-05-17 05:43:41 --> Database Driver Class Initialized
DEBUG - 2011-05-17 05:43:41 --> File loaded: application/views/table/main.php
DEBUG - 2011-05-17 05:43:41 --> Helper loaded: url_helper
DEBUG - 2011-05-17 05:43:41 --> File loaded: application/views/common/header.php
DEBUG - 2011-05-17 05:43:41 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-05-17 05:43:41 --> File loaded: application/views/common/footer.php
DEBUG - 2011-05-17 05:43:41 --> File loaded: application/views/layout/main.php
DEBUG - 2011-05-17 05:43:41 --> Final output sent to browser
DEBUG - 2011-05-17 05:43:41 --> Total execution time: 0.1094
DEBUG - 2011-05-17 06:03:05 --> Config Class Initialized
DEBUG - 2011-05-17 06:03:05 --> Hooks Class Initialized
DEBUG - 2011-05-17 06:03:05 --> Utf8 Class Initialized
DEBUG - 2011-05-17 06:03:05 --> UTF-8 Support Enabled
DEBUG - 2011-05-17 06:03:05 --> URI Class Initialized
DEBUG - 2011-05-17 06:03:05 --> Router Class Initialized
DEBUG - 2011-05-17 06:03:05 --> Output Class Initialized
DEBUG - 2011-05-17 06:03:05 --> Input Class Initialized
DEBUG - 2011-05-17 06:03:05 --> Global POST and COOKIE data sanitized
DEBUG - 2011-05-17 06:03:05 --> Language Class Initialized
DEBUG - 2011-05-17 06:03:05 --> Loader Class Initialized
DEBUG - 2011-05-17 06:03:05 --> Controller Class Initialized
ERROR - 2011-05-17 06:03:05 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-05-17 06:03:05 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-05-17 06:03:05 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-05-17 06:03:05 --> Model Class Initialized
DEBUG - 2011-05-17 06:03:05 --> Model Class Initialized
DEBUG - 2011-05-17 06:03:05 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-05-17 06:03:05 --> Database Driver Class Initialized
DEBUG - 2011-05-17 06:03:05 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-05-17 06:03:05 --> Helper loaded: url_helper
DEBUG - 2011-05-17 06:03:05 --> File loaded: application/views/common/header.php
DEBUG - 2011-05-17 06:03:05 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-05-17 06:03:05 --> File loaded: application/views/common/footer.php
DEBUG - 2011-05-17 06:03:05 --> File loaded: application/views/layout/main.php
DEBUG - 2011-05-17 06:03:05 --> Final output sent to browser
DEBUG - 2011-05-17 06:03:05 --> Total execution time: 0.4731
DEBUG - 2011-05-17 06:30:25 --> Config Class Initialized
DEBUG - 2011-05-17 06:30:25 --> Hooks Class Initialized
DEBUG - 2011-05-17 06:30:25 --> Utf8 Class Initialized
DEBUG - 2011-05-17 06:30:25 --> UTF-8 Support Enabled
DEBUG - 2011-05-17 06:30:26 --> URI Class Initialized
DEBUG - 2011-05-17 06:30:27 --> Router Class Initialized
ERROR - 2011-05-17 06:30:27 --> 404 Page Not Found --> robots.txt
DEBUG - 2011-05-17 06:31:17 --> Config Class Initialized
DEBUG - 2011-05-17 06:31:17 --> Hooks Class Initialized
DEBUG - 2011-05-17 06:31:17 --> Utf8 Class Initialized
DEBUG - 2011-05-17 06:31:17 --> UTF-8 Support Enabled
DEBUG - 2011-05-17 06:31:17 --> URI Class Initialized
DEBUG - 2011-05-17 06:31:17 --> Router Class Initialized
DEBUG - 2011-05-17 06:31:18 --> No URI present. Default controller set.
DEBUG - 2011-05-17 06:31:18 --> Output Class Initialized
DEBUG - 2011-05-17 06:31:18 --> Input Class Initialized
DEBUG - 2011-05-17 06:31:18 --> Global POST and COOKIE data sanitized
DEBUG - 2011-05-17 06:31:19 --> Language Class Initialized
DEBUG - 2011-05-17 06:31:19 --> Loader Class Initialized
DEBUG - 2011-05-17 06:31:19 --> Controller Class Initialized
DEBUG - 2011-05-17 06:31:19 --> File loaded: application/views/splash/main.php
DEBUG - 2011-05-17 06:31:19 --> Helper loaded: url_helper
DEBUG - 2011-05-17 06:31:19 --> File loaded: application/views/common/header.php
DEBUG - 2011-05-17 06:31:19 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-05-17 06:31:19 --> File loaded: application/views/common/footer.php
DEBUG - 2011-05-17 06:31:19 --> File loaded: application/views/layout/main.php
DEBUG - 2011-05-17 06:31:19 --> Final output sent to browser
DEBUG - 2011-05-17 06:31:19 --> Total execution time: 1.8828
DEBUG - 2011-05-17 07:28:37 --> Config Class Initialized
DEBUG - 2011-05-17 07:28:37 --> Hooks Class Initialized
DEBUG - 2011-05-17 07:28:37 --> Utf8 Class Initialized
DEBUG - 2011-05-17 07:28:37 --> UTF-8 Support Enabled
DEBUG - 2011-05-17 07:28:37 --> URI Class Initialized
DEBUG - 2011-05-17 07:28:37 --> Router Class Initialized
DEBUG - 2011-05-17 07:28:37 --> Output Class Initialized
DEBUG - 2011-05-17 07:28:37 --> Input Class Initialized
DEBUG - 2011-05-17 07:28:37 --> Global POST and COOKIE data sanitized
DEBUG - 2011-05-17 07:28:37 --> Language Class Initialized
DEBUG - 2011-05-17 07:28:37 --> Loader Class Initialized
DEBUG - 2011-05-17 07:28:37 --> Controller Class Initialized
DEBUG - 2011-05-17 07:28:37 --> Model Class Initialized
DEBUG - 2011-05-17 07:28:37 --> Model Class Initialized
DEBUG - 2011-05-17 07:28:37 --> Model Class Initialized
DEBUG - 2011-05-17 07:28:37 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-05-17 07:28:37 --> Database Driver Class Initialized
DEBUG - 2011-05-17 07:28:37 --> File loaded: application/views/table/main.php
DEBUG - 2011-05-17 07:28:37 --> Helper loaded: url_helper
DEBUG - 2011-05-17 07:28:37 --> File loaded: application/views/common/header.php
DEBUG - 2011-05-17 07:28:37 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-05-17 07:28:37 --> File loaded: application/views/common/footer.php
DEBUG - 2011-05-17 07:28:37 --> File loaded: application/views/layout/main.php
DEBUG - 2011-05-17 07:28:37 --> Final output sent to browser
DEBUG - 2011-05-17 07:28:37 --> Total execution time: 0.5770
DEBUG - 2011-05-17 07:28:58 --> Config Class Initialized
DEBUG - 2011-05-17 07:28:58 --> Hooks Class Initialized
DEBUG - 2011-05-17 07:28:58 --> Utf8 Class Initialized
DEBUG - 2011-05-17 07:28:58 --> UTF-8 Support Enabled
DEBUG - 2011-05-17 07:28:58 --> URI Class Initialized
DEBUG - 2011-05-17 07:28:58 --> Router Class Initialized
DEBUG - 2011-05-17 07:28:58 --> Output Class Initialized
DEBUG - 2011-05-17 07:28:58 --> Input Class Initialized
DEBUG - 2011-05-17 07:28:58 --> Global POST and COOKIE data sanitized
DEBUG - 2011-05-17 07:28:58 --> Language Class Initialized
DEBUG - 2011-05-17 07:28:58 --> Loader Class Initialized
DEBUG - 2011-05-17 07:28:58 --> Controller Class Initialized
ERROR - 2011-05-17 07:28:58 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-05-17 07:28:58 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-05-17 07:28:58 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-05-17 07:28:58 --> Model Class Initialized
DEBUG - 2011-05-17 07:28:58 --> Model Class Initialized
DEBUG - 2011-05-17 07:28:58 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-05-17 07:28:58 --> Database Driver Class Initialized
DEBUG - 2011-05-17 07:28:58 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-05-17 07:28:58 --> Helper loaded: url_helper
DEBUG - 2011-05-17 07:28:58 --> File loaded: application/views/common/header.php
DEBUG - 2011-05-17 07:28:58 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-05-17 07:28:58 --> File loaded: application/views/common/footer.php
DEBUG - 2011-05-17 07:28:58 --> File loaded: application/views/layout/main.php
DEBUG - 2011-05-17 07:28:58 --> Final output sent to browser
DEBUG - 2011-05-17 07:28:58 --> Total execution time: 0.1112
DEBUG - 2011-05-17 09:19:53 --> Config Class Initialized
DEBUG - 2011-05-17 09:19:53 --> Hooks Class Initialized
DEBUG - 2011-05-17 09:19:53 --> Utf8 Class Initialized
DEBUG - 2011-05-17 09:19:53 --> UTF-8 Support Enabled
DEBUG - 2011-05-17 09:19:53 --> URI Class Initialized
DEBUG - 2011-05-17 09:19:53 --> Router Class Initialized
ERROR - 2011-05-17 09:19:53 --> 404 Page Not Found --> robots.txt
DEBUG - 2011-05-17 09:19:53 --> Config Class Initialized
DEBUG - 2011-05-17 09:19:53 --> Hooks Class Initialized
DEBUG - 2011-05-17 09:19:53 --> Utf8 Class Initialized
DEBUG - 2011-05-17 09:19:53 --> UTF-8 Support Enabled
DEBUG - 2011-05-17 09:19:53 --> URI Class Initialized
DEBUG - 2011-05-17 09:19:53 --> Router Class Initialized
DEBUG - 2011-05-17 09:19:53 --> Output Class Initialized
DEBUG - 2011-05-17 09:19:54 --> Input Class Initialized
DEBUG - 2011-05-17 09:19:54 --> Global POST and COOKIE data sanitized
DEBUG - 2011-05-17 09:19:54 --> Language Class Initialized
DEBUG - 2011-05-17 09:19:54 --> Loader Class Initialized
DEBUG - 2011-05-17 09:19:54 --> Controller Class Initialized
DEBUG - 2011-05-17 09:19:54 --> Model Class Initialized
DEBUG - 2011-05-17 09:19:54 --> Model Class Initialized
DEBUG - 2011-05-17 09:19:54 --> Model Class Initialized
DEBUG - 2011-05-17 09:19:54 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-05-17 09:19:54 --> Database Driver Class Initialized
DEBUG - 2011-05-17 09:19:54 --> File loaded: application/views/table/main.php
DEBUG - 2011-05-17 09:19:54 --> Helper loaded: url_helper
DEBUG - 2011-05-17 09:19:54 --> File loaded: application/views/common/header.php
DEBUG - 2011-05-17 09:19:54 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-05-17 09:19:54 --> File loaded: application/views/common/footer.php
DEBUG - 2011-05-17 09:19:54 --> File loaded: application/views/layout/main.php
DEBUG - 2011-05-17 09:19:54 --> Final output sent to browser
DEBUG - 2011-05-17 09:19:54 --> Total execution time: 0.6529
DEBUG - 2011-05-17 12:39:27 --> Config Class Initialized
DEBUG - 2011-05-17 12:39:27 --> Hooks Class Initialized
DEBUG - 2011-05-17 12:39:27 --> Utf8 Class Initialized
DEBUG - 2011-05-17 12:39:27 --> UTF-8 Support Enabled
DEBUG - 2011-05-17 12:39:27 --> URI Class Initialized
DEBUG - 2011-05-17 12:39:27 --> Router Class Initialized
DEBUG - 2011-05-17 12:39:27 --> Output Class Initialized
DEBUG - 2011-05-17 12:39:27 --> Input Class Initialized
DEBUG - 2011-05-17 12:39:27 --> Global POST and COOKIE data sanitized
DEBUG - 2011-05-17 12:39:27 --> Language Class Initialized
DEBUG - 2011-05-17 12:39:27 --> Loader Class Initialized
DEBUG - 2011-05-17 12:39:27 --> Controller Class Initialized
ERROR - 2011-05-17 12:39:27 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-05-17 12:39:27 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-05-17 12:39:27 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-05-17 12:39:28 --> Model Class Initialized
DEBUG - 2011-05-17 12:39:28 --> Model Class Initialized
DEBUG - 2011-05-17 12:39:28 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-05-17 12:39:28 --> Database Driver Class Initialized
DEBUG - 2011-05-17 12:39:28 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-05-17 12:39:28 --> Helper loaded: url_helper
DEBUG - 2011-05-17 12:39:28 --> File loaded: application/views/common/header.php
DEBUG - 2011-05-17 12:39:28 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-05-17 12:39:28 --> File loaded: application/views/common/footer.php
DEBUG - 2011-05-17 12:39:28 --> File loaded: application/views/layout/main.php
DEBUG - 2011-05-17 12:39:28 --> Final output sent to browser
DEBUG - 2011-05-17 12:39:28 --> Total execution time: 0.4948
DEBUG - 2011-05-17 12:39:31 --> Config Class Initialized
DEBUG - 2011-05-17 12:39:31 --> Hooks Class Initialized
DEBUG - 2011-05-17 12:39:31 --> Utf8 Class Initialized
DEBUG - 2011-05-17 12:39:31 --> UTF-8 Support Enabled
DEBUG - 2011-05-17 12:39:31 --> URI Class Initialized
DEBUG - 2011-05-17 12:39:31 --> Router Class Initialized
DEBUG - 2011-05-17 12:39:31 --> Output Class Initialized
DEBUG - 2011-05-17 12:39:31 --> Input Class Initialized
DEBUG - 2011-05-17 12:39:31 --> Global POST and COOKIE data sanitized
DEBUG - 2011-05-17 12:39:31 --> Language Class Initialized
DEBUG - 2011-05-17 12:39:31 --> Loader Class Initialized
DEBUG - 2011-05-17 12:39:31 --> Controller Class Initialized
DEBUG - 2011-05-17 12:39:31 --> Model Class Initialized
DEBUG - 2011-05-17 12:39:31 --> Model Class Initialized
DEBUG - 2011-05-17 12:39:31 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-05-17 12:39:31 --> Database Driver Class Initialized
DEBUG - 2011-05-17 12:39:32 --> Final output sent to browser
DEBUG - 2011-05-17 12:39:32 --> Total execution time: 0.9821
DEBUG - 2011-05-17 12:39:34 --> Config Class Initialized
DEBUG - 2011-05-17 12:39:34 --> Hooks Class Initialized
DEBUG - 2011-05-17 12:39:34 --> Utf8 Class Initialized
DEBUG - 2011-05-17 12:39:34 --> UTF-8 Support Enabled
DEBUG - 2011-05-17 12:39:34 --> URI Class Initialized
DEBUG - 2011-05-17 12:39:34 --> Router Class Initialized
ERROR - 2011-05-17 12:39:34 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-05-17 12:56:06 --> Config Class Initialized
DEBUG - 2011-05-17 12:56:06 --> Hooks Class Initialized
DEBUG - 2011-05-17 12:56:06 --> Utf8 Class Initialized
DEBUG - 2011-05-17 12:56:06 --> UTF-8 Support Enabled
DEBUG - 2011-05-17 12:56:06 --> URI Class Initialized
DEBUG - 2011-05-17 12:56:06 --> Router Class Initialized
DEBUG - 2011-05-17 12:56:06 --> No URI present. Default controller set.
DEBUG - 2011-05-17 12:56:06 --> Output Class Initialized
DEBUG - 2011-05-17 12:56:06 --> Input Class Initialized
DEBUG - 2011-05-17 12:56:06 --> Global POST and COOKIE data sanitized
DEBUG - 2011-05-17 12:56:06 --> Language Class Initialized
DEBUG - 2011-05-17 12:56:06 --> Loader Class Initialized
DEBUG - 2011-05-17 12:56:06 --> Controller Class Initialized
DEBUG - 2011-05-17 12:56:06 --> File loaded: application/views/splash/main.php
DEBUG - 2011-05-17 12:56:06 --> Helper loaded: url_helper
DEBUG - 2011-05-17 12:56:06 --> File loaded: application/views/common/header.php
DEBUG - 2011-05-17 12:56:06 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-05-17 12:56:06 --> File loaded: application/views/common/footer.php
DEBUG - 2011-05-17 12:56:06 --> File loaded: application/views/layout/main.php
DEBUG - 2011-05-17 12:56:06 --> Final output sent to browser
DEBUG - 2011-05-17 12:56:06 --> Total execution time: 0.1373
DEBUG - 2011-05-17 13:22:42 --> Config Class Initialized
DEBUG - 2011-05-17 13:22:42 --> Hooks Class Initialized
DEBUG - 2011-05-17 13:22:42 --> Utf8 Class Initialized
DEBUG - 2011-05-17 13:22:42 --> UTF-8 Support Enabled
DEBUG - 2011-05-17 13:22:42 --> URI Class Initialized
DEBUG - 2011-05-17 13:22:42 --> Router Class Initialized
DEBUG - 2011-05-17 13:22:42 --> Output Class Initialized
DEBUG - 2011-05-17 13:22:42 --> Input Class Initialized
DEBUG - 2011-05-17 13:22:42 --> Global POST and COOKIE data sanitized
DEBUG - 2011-05-17 13:22:42 --> Language Class Initialized
DEBUG - 2011-05-17 13:22:42 --> Loader Class Initialized
DEBUG - 2011-05-17 13:22:42 --> Controller Class Initialized
DEBUG - 2011-05-17 13:22:42 --> Model Class Initialized
DEBUG - 2011-05-17 13:22:42 --> Model Class Initialized
DEBUG - 2011-05-17 13:22:42 --> Model Class Initialized
DEBUG - 2011-05-17 13:22:42 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-05-17 13:22:42 --> Database Driver Class Initialized
DEBUG - 2011-05-17 13:22:43 --> File loaded: application/views/table/main.php
DEBUG - 2011-05-17 13:22:43 --> Helper loaded: url_helper
DEBUG - 2011-05-17 13:22:43 --> File loaded: application/views/common/header.php
DEBUG - 2011-05-17 13:22:43 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-05-17 13:22:43 --> File loaded: application/views/common/footer.php
DEBUG - 2011-05-17 13:22:43 --> File loaded: application/views/layout/main.php
DEBUG - 2011-05-17 13:22:43 --> Final output sent to browser
DEBUG - 2011-05-17 13:22:43 --> Total execution time: 0.5909
DEBUG - 2011-05-17 13:52:58 --> Config Class Initialized
DEBUG - 2011-05-17 13:52:58 --> Hooks Class Initialized
DEBUG - 2011-05-17 13:52:58 --> Utf8 Class Initialized
DEBUG - 2011-05-17 13:52:58 --> UTF-8 Support Enabled
DEBUG - 2011-05-17 13:52:58 --> URI Class Initialized
DEBUG - 2011-05-17 13:52:58 --> Router Class Initialized
DEBUG - 2011-05-17 13:52:58 --> No URI present. Default controller set.
DEBUG - 2011-05-17 13:52:58 --> Output Class Initialized
DEBUG - 2011-05-17 13:52:58 --> Input Class Initialized
DEBUG - 2011-05-17 13:52:58 --> Global POST and COOKIE data sanitized
DEBUG - 2011-05-17 13:52:58 --> Language Class Initialized
DEBUG - 2011-05-17 13:52:58 --> Loader Class Initialized
DEBUG - 2011-05-17 13:52:58 --> Controller Class Initialized
DEBUG - 2011-05-17 13:52:58 --> File loaded: application/views/splash/main.php
DEBUG - 2011-05-17 13:52:58 --> Helper loaded: url_helper
DEBUG - 2011-05-17 13:52:58 --> File loaded: application/views/common/header.php
DEBUG - 2011-05-17 13:52:58 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-05-17 13:52:58 --> File loaded: application/views/common/footer.php
DEBUG - 2011-05-17 13:52:58 --> File loaded: application/views/layout/main.php
DEBUG - 2011-05-17 13:52:58 --> Final output sent to browser
DEBUG - 2011-05-17 13:52:58 --> Total execution time: 0.2261
DEBUG - 2011-05-17 13:56:08 --> Config Class Initialized
DEBUG - 2011-05-17 13:56:08 --> Hooks Class Initialized
DEBUG - 2011-05-17 13:56:08 --> Utf8 Class Initialized
DEBUG - 2011-05-17 13:56:08 --> UTF-8 Support Enabled
DEBUG - 2011-05-17 13:56:08 --> URI Class Initialized
DEBUG - 2011-05-17 13:56:08 --> Router Class Initialized
DEBUG - 2011-05-17 13:56:08 --> Output Class Initialized
DEBUG - 2011-05-17 13:56:08 --> Input Class Initialized
DEBUG - 2011-05-17 13:56:08 --> Global POST and COOKIE data sanitized
DEBUG - 2011-05-17 13:56:08 --> Language Class Initialized
DEBUG - 2011-05-17 13:56:08 --> Loader Class Initialized
DEBUG - 2011-05-17 13:56:08 --> Controller Class Initialized
DEBUG - 2011-05-17 13:56:08 --> Model Class Initialized
DEBUG - 2011-05-17 13:56:08 --> Model Class Initialized
DEBUG - 2011-05-17 13:56:08 --> Model Class Initialized
DEBUG - 2011-05-17 13:56:08 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-05-17 13:56:08 --> Database Driver Class Initialized
DEBUG - 2011-05-17 13:56:08 --> File loaded: application/views/table/main.php
DEBUG - 2011-05-17 13:56:08 --> Helper loaded: url_helper
DEBUG - 2011-05-17 13:56:08 --> File loaded: application/views/common/header.php
DEBUG - 2011-05-17 13:56:08 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-05-17 13:56:08 --> File loaded: application/views/common/footer.php
DEBUG - 2011-05-17 13:56:08 --> File loaded: application/views/layout/main.php
DEBUG - 2011-05-17 13:56:08 --> Final output sent to browser
DEBUG - 2011-05-17 13:56:08 --> Total execution time: 0.4604
DEBUG - 2011-05-17 13:56:29 --> Config Class Initialized
DEBUG - 2011-05-17 13:56:29 --> Hooks Class Initialized
DEBUG - 2011-05-17 13:56:29 --> Utf8 Class Initialized
DEBUG - 2011-05-17 13:56:29 --> UTF-8 Support Enabled
DEBUG - 2011-05-17 13:56:29 --> URI Class Initialized
DEBUG - 2011-05-17 13:56:29 --> Router Class Initialized
DEBUG - 2011-05-17 13:56:29 --> Output Class Initialized
DEBUG - 2011-05-17 13:56:29 --> Input Class Initialized
DEBUG - 2011-05-17 13:56:29 --> Global POST and COOKIE data sanitized
DEBUG - 2011-05-17 13:56:29 --> Language Class Initialized
DEBUG - 2011-05-17 13:56:29 --> Loader Class Initialized
DEBUG - 2011-05-17 13:56:29 --> Controller Class Initialized
DEBUG - 2011-05-17 13:56:29 --> Model Class Initialized
DEBUG - 2011-05-17 13:56:29 --> Model Class Initialized
DEBUG - 2011-05-17 13:56:29 --> Model Class Initialized
DEBUG - 2011-05-17 13:56:29 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-05-17 13:56:29 --> Database Driver Class Initialized
DEBUG - 2011-05-17 13:56:29 --> File loaded: application/views/table/main.php
DEBUG - 2011-05-17 13:56:29 --> Helper loaded: url_helper
DEBUG - 2011-05-17 13:56:29 --> File loaded: application/views/common/header.php
DEBUG - 2011-05-17 13:56:29 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-05-17 13:56:29 --> File loaded: application/views/common/footer.php
DEBUG - 2011-05-17 13:56:29 --> File loaded: application/views/layout/main.php
DEBUG - 2011-05-17 13:56:29 --> Final output sent to browser
DEBUG - 2011-05-17 13:56:29 --> Total execution time: 0.2691
DEBUG - 2011-05-17 13:56:31 --> Config Class Initialized
DEBUG - 2011-05-17 13:56:31 --> Hooks Class Initialized
DEBUG - 2011-05-17 13:56:31 --> Utf8 Class Initialized
DEBUG - 2011-05-17 13:56:31 --> UTF-8 Support Enabled
DEBUG - 2011-05-17 13:56:31 --> URI Class Initialized
DEBUG - 2011-05-17 13:56:31 --> Router Class Initialized
DEBUG - 2011-05-17 13:56:31 --> Output Class Initialized
DEBUG - 2011-05-17 13:56:31 --> Input Class Initialized
DEBUG - 2011-05-17 13:56:31 --> Global POST and COOKIE data sanitized
DEBUG - 2011-05-17 13:56:31 --> Language Class Initialized
DEBUG - 2011-05-17 13:56:31 --> Loader Class Initialized
DEBUG - 2011-05-17 13:56:31 --> Controller Class Initialized
DEBUG - 2011-05-17 13:56:31 --> Model Class Initialized
DEBUG - 2011-05-17 13:56:31 --> Model Class Initialized
DEBUG - 2011-05-17 13:56:31 --> Model Class Initialized
DEBUG - 2011-05-17 13:56:31 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-05-17 13:56:31 --> Database Driver Class Initialized
DEBUG - 2011-05-17 13:56:31 --> File loaded: application/views/table/main.php
DEBUG - 2011-05-17 13:56:31 --> Helper loaded: url_helper
DEBUG - 2011-05-17 13:56:31 --> File loaded: application/views/common/header.php
DEBUG - 2011-05-17 13:56:31 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-05-17 13:56:31 --> File loaded: application/views/common/footer.php
DEBUG - 2011-05-17 13:56:31 --> File loaded: application/views/layout/main.php
DEBUG - 2011-05-17 13:56:31 --> Final output sent to browser
DEBUG - 2011-05-17 13:56:31 --> Total execution time: 0.0470
DEBUG - 2011-05-17 15:49:46 --> Config Class Initialized
DEBUG - 2011-05-17 15:49:46 --> Hooks Class Initialized
DEBUG - 2011-05-17 15:49:46 --> Utf8 Class Initialized
DEBUG - 2011-05-17 15:49:46 --> UTF-8 Support Enabled
DEBUG - 2011-05-17 15:49:47 --> URI Class Initialized
DEBUG - 2011-05-17 15:49:47 --> Router Class Initialized
DEBUG - 2011-05-17 15:49:47 --> Output Class Initialized
DEBUG - 2011-05-17 15:49:47 --> Input Class Initialized
DEBUG - 2011-05-17 15:49:47 --> Global POST and COOKIE data sanitized
DEBUG - 2011-05-17 15:49:47 --> Language Class Initialized
DEBUG - 2011-05-17 15:49:47 --> Loader Class Initialized
DEBUG - 2011-05-17 15:49:47 --> Controller Class Initialized
ERROR - 2011-05-17 15:49:47 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-05-17 15:49:47 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-05-17 15:49:47 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-05-17 15:49:47 --> Model Class Initialized
DEBUG - 2011-05-17 15:49:47 --> Model Class Initialized
DEBUG - 2011-05-17 15:49:47 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-05-17 15:49:47 --> Database Driver Class Initialized
DEBUG - 2011-05-17 15:49:47 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-05-17 15:49:47 --> Helper loaded: url_helper
DEBUG - 2011-05-17 15:49:47 --> File loaded: application/views/common/header.php
DEBUG - 2011-05-17 15:49:47 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-05-17 15:49:47 --> File loaded: application/views/common/footer.php
DEBUG - 2011-05-17 15:49:47 --> File loaded: application/views/layout/main.php
DEBUG - 2011-05-17 15:49:47 --> Final output sent to browser
DEBUG - 2011-05-17 15:49:47 --> Total execution time: 0.4483
DEBUG - 2011-05-17 15:49:47 --> Config Class Initialized
DEBUG - 2011-05-17 15:49:47 --> Hooks Class Initialized
DEBUG - 2011-05-17 15:49:47 --> Utf8 Class Initialized
DEBUG - 2011-05-17 15:49:47 --> UTF-8 Support Enabled
DEBUG - 2011-05-17 15:49:47 --> URI Class Initialized
DEBUG - 2011-05-17 15:49:47 --> Router Class Initialized
DEBUG - 2011-05-17 15:49:47 --> Output Class Initialized
DEBUG - 2011-05-17 15:49:47 --> Input Class Initialized
DEBUG - 2011-05-17 15:49:47 --> Global POST and COOKIE data sanitized
DEBUG - 2011-05-17 15:49:47 --> Language Class Initialized
DEBUG - 2011-05-17 15:49:47 --> Loader Class Initialized
DEBUG - 2011-05-17 15:49:47 --> Controller Class Initialized
DEBUG - 2011-05-17 15:49:47 --> Model Class Initialized
DEBUG - 2011-05-17 15:49:47 --> Model Class Initialized
DEBUG - 2011-05-17 15:49:47 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-05-17 15:49:47 --> Database Driver Class Initialized
DEBUG - 2011-05-17 15:49:48 --> Final output sent to browser
DEBUG - 2011-05-17 15:49:48 --> Total execution time: 0.8380
DEBUG - 2011-05-17 15:49:49 --> Config Class Initialized
DEBUG - 2011-05-17 15:49:49 --> Hooks Class Initialized
DEBUG - 2011-05-17 15:49:49 --> Utf8 Class Initialized
DEBUG - 2011-05-17 15:49:49 --> UTF-8 Support Enabled
DEBUG - 2011-05-17 15:49:49 --> URI Class Initialized
DEBUG - 2011-05-17 15:49:49 --> Router Class Initialized
ERROR - 2011-05-17 15:49:49 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-05-17 15:49:49 --> Config Class Initialized
DEBUG - 2011-05-17 15:49:49 --> Hooks Class Initialized
DEBUG - 2011-05-17 15:49:49 --> Utf8 Class Initialized
DEBUG - 2011-05-17 15:49:49 --> UTF-8 Support Enabled
DEBUG - 2011-05-17 15:49:49 --> URI Class Initialized
DEBUG - 2011-05-17 15:49:49 --> Router Class Initialized
ERROR - 2011-05-17 15:49:49 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-05-17 16:43:28 --> Config Class Initialized
DEBUG - 2011-05-17 16:43:28 --> Hooks Class Initialized
DEBUG - 2011-05-17 16:43:28 --> Utf8 Class Initialized
DEBUG - 2011-05-17 16:43:28 --> UTF-8 Support Enabled
DEBUG - 2011-05-17 16:43:28 --> URI Class Initialized
DEBUG - 2011-05-17 16:43:28 --> Router Class Initialized
DEBUG - 2011-05-17 16:43:28 --> Output Class Initialized
DEBUG - 2011-05-17 16:43:28 --> Input Class Initialized
DEBUG - 2011-05-17 16:43:28 --> Global POST and COOKIE data sanitized
DEBUG - 2011-05-17 16:43:28 --> Language Class Initialized
DEBUG - 2011-05-17 16:43:28 --> Loader Class Initialized
DEBUG - 2011-05-17 16:43:28 --> Controller Class Initialized
DEBUG - 2011-05-17 16:43:28 --> Model Class Initialized
DEBUG - 2011-05-17 16:43:28 --> Model Class Initialized
DEBUG - 2011-05-17 16:43:28 --> Model Class Initialized
DEBUG - 2011-05-17 16:43:28 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-05-17 16:43:28 --> Database Driver Class Initialized
DEBUG - 2011-05-17 16:43:29 --> File loaded: application/views/table/main.php
DEBUG - 2011-05-17 16:43:29 --> Helper loaded: url_helper
DEBUG - 2011-05-17 16:43:29 --> File loaded: application/views/common/header.php
DEBUG - 2011-05-17 16:43:29 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-05-17 16:43:29 --> File loaded: application/views/common/footer.php
DEBUG - 2011-05-17 16:43:29 --> File loaded: application/views/layout/main.php
DEBUG - 2011-05-17 16:43:29 --> Final output sent to browser
DEBUG - 2011-05-17 16:43:29 --> Total execution time: 0.7397
DEBUG - 2011-05-17 16:43:31 --> Config Class Initialized
DEBUG - 2011-05-17 16:43:31 --> Hooks Class Initialized
DEBUG - 2011-05-17 16:43:31 --> Utf8 Class Initialized
DEBUG - 2011-05-17 16:43:31 --> UTF-8 Support Enabled
DEBUG - 2011-05-17 16:43:31 --> URI Class Initialized
DEBUG - 2011-05-17 16:43:31 --> Router Class Initialized
ERROR - 2011-05-17 16:43:31 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-05-17 16:43:31 --> Config Class Initialized
DEBUG - 2011-05-17 16:43:31 --> Hooks Class Initialized
DEBUG - 2011-05-17 16:43:31 --> Utf8 Class Initialized
DEBUG - 2011-05-17 16:43:31 --> UTF-8 Support Enabled
DEBUG - 2011-05-17 16:43:31 --> URI Class Initialized
DEBUG - 2011-05-17 16:43:31 --> Router Class Initialized
ERROR - 2011-05-17 16:43:31 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-05-17 16:43:31 --> Config Class Initialized
DEBUG - 2011-05-17 16:43:31 --> Hooks Class Initialized
DEBUG - 2011-05-17 16:43:31 --> Utf8 Class Initialized
DEBUG - 2011-05-17 16:43:31 --> UTF-8 Support Enabled
DEBUG - 2011-05-17 16:43:31 --> URI Class Initialized
DEBUG - 2011-05-17 16:43:31 --> Router Class Initialized
ERROR - 2011-05-17 16:43:31 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-05-17 16:43:37 --> Config Class Initialized
DEBUG - 2011-05-17 16:43:37 --> Hooks Class Initialized
DEBUG - 2011-05-17 16:43:37 --> Utf8 Class Initialized
DEBUG - 2011-05-17 16:43:37 --> UTF-8 Support Enabled
DEBUG - 2011-05-17 16:43:37 --> URI Class Initialized
DEBUG - 2011-05-17 16:43:37 --> Router Class Initialized
DEBUG - 2011-05-17 16:43:37 --> Output Class Initialized
DEBUG - 2011-05-17 16:43:37 --> Input Class Initialized
DEBUG - 2011-05-17 16:43:37 --> Global POST and COOKIE data sanitized
DEBUG - 2011-05-17 16:43:37 --> Language Class Initialized
DEBUG - 2011-05-17 16:43:37 --> Loader Class Initialized
DEBUG - 2011-05-17 16:43:37 --> Controller Class Initialized
DEBUG - 2011-05-17 16:43:37 --> Model Class Initialized
DEBUG - 2011-05-17 16:43:37 --> Model Class Initialized
DEBUG - 2011-05-17 16:43:37 --> Model Class Initialized
DEBUG - 2011-05-17 16:43:37 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-05-17 16:43:37 --> Database Driver Class Initialized
DEBUG - 2011-05-17 16:43:38 --> File loaded: application/views/table/main.php
DEBUG - 2011-05-17 16:43:38 --> Helper loaded: url_helper
DEBUG - 2011-05-17 16:43:38 --> File loaded: application/views/common/header.php
DEBUG - 2011-05-17 16:43:38 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-05-17 16:43:38 --> File loaded: application/views/common/footer.php
DEBUG - 2011-05-17 16:43:38 --> File loaded: application/views/layout/main.php
DEBUG - 2011-05-17 16:43:38 --> Final output sent to browser
DEBUG - 2011-05-17 16:43:38 --> Total execution time: 0.6074
DEBUG - 2011-05-17 16:43:40 --> Config Class Initialized
DEBUG - 2011-05-17 16:43:40 --> Hooks Class Initialized
DEBUG - 2011-05-17 16:43:40 --> Utf8 Class Initialized
DEBUG - 2011-05-17 16:43:40 --> UTF-8 Support Enabled
DEBUG - 2011-05-17 16:43:40 --> URI Class Initialized
DEBUG - 2011-05-17 16:43:40 --> Router Class Initialized
DEBUG - 2011-05-17 16:43:40 --> Output Class Initialized
DEBUG - 2011-05-17 16:43:40 --> Input Class Initialized
DEBUG - 2011-05-17 16:43:40 --> Global POST and COOKIE data sanitized
DEBUG - 2011-05-17 16:43:40 --> Language Class Initialized
DEBUG - 2011-05-17 16:43:40 --> Loader Class Initialized
DEBUG - 2011-05-17 16:43:40 --> Controller Class Initialized
DEBUG - 2011-05-17 16:43:40 --> Model Class Initialized
DEBUG - 2011-05-17 16:43:40 --> Model Class Initialized
DEBUG - 2011-05-17 16:43:40 --> Model Class Initialized
DEBUG - 2011-05-17 16:43:40 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-05-17 16:43:40 --> Database Driver Class Initialized
DEBUG - 2011-05-17 16:43:40 --> File loaded: application/views/table/main.php
DEBUG - 2011-05-17 16:43:40 --> Helper loaded: url_helper
DEBUG - 2011-05-17 16:43:40 --> File loaded: application/views/common/header.php
DEBUG - 2011-05-17 16:43:40 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-05-17 16:43:40 --> File loaded: application/views/common/footer.php
DEBUG - 2011-05-17 16:43:40 --> File loaded: application/views/layout/main.php
DEBUG - 2011-05-17 16:43:40 --> Final output sent to browser
DEBUG - 2011-05-17 16:43:40 --> Total execution time: 0.0496
DEBUG - 2011-05-17 17:26:35 --> Config Class Initialized
DEBUG - 2011-05-17 17:26:35 --> Hooks Class Initialized
DEBUG - 2011-05-17 17:26:35 --> Utf8 Class Initialized
DEBUG - 2011-05-17 17:26:35 --> UTF-8 Support Enabled
DEBUG - 2011-05-17 17:26:35 --> URI Class Initialized
DEBUG - 2011-05-17 17:26:35 --> Router Class Initialized
DEBUG - 2011-05-17 17:26:35 --> Output Class Initialized
DEBUG - 2011-05-17 17:26:35 --> Input Class Initialized
DEBUG - 2011-05-17 17:26:35 --> Global POST and COOKIE data sanitized
DEBUG - 2011-05-17 17:26:35 --> Language Class Initialized
DEBUG - 2011-05-17 17:26:35 --> Loader Class Initialized
DEBUG - 2011-05-17 17:26:35 --> Controller Class Initialized
DEBUG - 2011-05-17 17:26:35 --> Model Class Initialized
DEBUG - 2011-05-17 17:26:35 --> Model Class Initialized
DEBUG - 2011-05-17 17:26:35 --> Model Class Initialized
DEBUG - 2011-05-17 17:26:35 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-05-17 17:26:35 --> Database Driver Class Initialized
DEBUG - 2011-05-17 17:26:35 --> File loaded: application/views/table/main.php
DEBUG - 2011-05-17 17:26:35 --> Helper loaded: url_helper
DEBUG - 2011-05-17 17:26:35 --> File loaded: application/views/common/header.php
DEBUG - 2011-05-17 17:26:35 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-05-17 17:26:35 --> File loaded: application/views/common/footer.php
DEBUG - 2011-05-17 17:26:35 --> File loaded: application/views/layout/main.php
DEBUG - 2011-05-17 17:26:35 --> Final output sent to browser
DEBUG - 2011-05-17 17:26:35 --> Total execution time: 0.5590
DEBUG - 2011-05-17 18:13:36 --> Config Class Initialized
DEBUG - 2011-05-17 18:13:36 --> Hooks Class Initialized
DEBUG - 2011-05-17 18:13:36 --> Utf8 Class Initialized
DEBUG - 2011-05-17 18:13:36 --> UTF-8 Support Enabled
DEBUG - 2011-05-17 18:13:36 --> URI Class Initialized
DEBUG - 2011-05-17 18:13:36 --> Router Class Initialized
DEBUG - 2011-05-17 18:13:36 --> Output Class Initialized
DEBUG - 2011-05-17 18:13:36 --> Input Class Initialized
DEBUG - 2011-05-17 18:13:36 --> Global POST and COOKIE data sanitized
DEBUG - 2011-05-17 18:13:36 --> Language Class Initialized
DEBUG - 2011-05-17 18:13:36 --> Loader Class Initialized
DEBUG - 2011-05-17 18:13:36 --> Controller Class Initialized
DEBUG - 2011-05-17 18:13:36 --> Model Class Initialized
DEBUG - 2011-05-17 18:13:36 --> Model Class Initialized
DEBUG - 2011-05-17 18:13:36 --> Model Class Initialized
DEBUG - 2011-05-17 18:13:36 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-05-17 18:13:36 --> Database Driver Class Initialized
DEBUG - 2011-05-17 18:13:37 --> File loaded: application/views/table/main.php
DEBUG - 2011-05-17 18:13:37 --> Helper loaded: url_helper
DEBUG - 2011-05-17 18:13:37 --> File loaded: application/views/common/header.php
DEBUG - 2011-05-17 18:13:37 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-05-17 18:13:37 --> File loaded: application/views/common/footer.php
DEBUG - 2011-05-17 18:13:37 --> File loaded: application/views/layout/main.php
DEBUG - 2011-05-17 18:13:37 --> Final output sent to browser
DEBUG - 2011-05-17 18:13:37 --> Total execution time: 0.6246
DEBUG - 2011-05-17 18:13:40 --> Config Class Initialized
DEBUG - 2011-05-17 18:13:40 --> Hooks Class Initialized
DEBUG - 2011-05-17 18:13:40 --> Utf8 Class Initialized
DEBUG - 2011-05-17 18:13:40 --> UTF-8 Support Enabled
DEBUG - 2011-05-17 18:13:40 --> URI Class Initialized
DEBUG - 2011-05-17 18:13:40 --> Router Class Initialized
ERROR - 2011-05-17 18:13:40 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-05-17 19:31:48 --> Config Class Initialized
DEBUG - 2011-05-17 19:31:48 --> Hooks Class Initialized
DEBUG - 2011-05-17 19:31:48 --> Utf8 Class Initialized
DEBUG - 2011-05-17 19:31:48 --> UTF-8 Support Enabled
DEBUG - 2011-05-17 19:31:48 --> URI Class Initialized
DEBUG - 2011-05-17 19:31:48 --> Router Class Initialized
ERROR - 2011-05-17 19:31:48 --> 404 Page Not Found --> robots.txt
DEBUG - 2011-05-17 19:31:49 --> Config Class Initialized
DEBUG - 2011-05-17 19:31:49 --> Hooks Class Initialized
DEBUG - 2011-05-17 19:31:49 --> Utf8 Class Initialized
DEBUG - 2011-05-17 19:31:49 --> UTF-8 Support Enabled
DEBUG - 2011-05-17 19:31:49 --> URI Class Initialized
DEBUG - 2011-05-17 19:31:49 --> Router Class Initialized
DEBUG - 2011-05-17 19:31:49 --> Output Class Initialized
DEBUG - 2011-05-17 19:31:49 --> Input Class Initialized
DEBUG - 2011-05-17 19:31:49 --> Global POST and COOKIE data sanitized
DEBUG - 2011-05-17 19:31:49 --> Language Class Initialized
DEBUG - 2011-05-17 19:31:49 --> Loader Class Initialized
DEBUG - 2011-05-17 19:31:49 --> Controller Class Initialized
ERROR - 2011-05-17 19:31:49 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-05-17 19:31:49 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-05-17 19:31:49 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-05-17 19:31:49 --> Model Class Initialized
DEBUG - 2011-05-17 19:31:49 --> Model Class Initialized
DEBUG - 2011-05-17 19:31:49 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-05-17 19:31:49 --> Database Driver Class Initialized
DEBUG - 2011-05-17 19:31:49 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-05-17 19:31:49 --> Helper loaded: url_helper
DEBUG - 2011-05-17 19:31:49 --> File loaded: application/views/common/header.php
DEBUG - 2011-05-17 19:31:49 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-05-17 19:31:49 --> File loaded: application/views/common/footer.php
DEBUG - 2011-05-17 19:31:49 --> File loaded: application/views/layout/main.php
DEBUG - 2011-05-17 19:31:49 --> Final output sent to browser
DEBUG - 2011-05-17 19:31:49 --> Total execution time: 0.3894
DEBUG - 2011-05-17 22:48:50 --> Config Class Initialized
DEBUG - 2011-05-17 22:48:50 --> Hooks Class Initialized
DEBUG - 2011-05-17 22:48:50 --> Utf8 Class Initialized
DEBUG - 2011-05-17 22:48:50 --> UTF-8 Support Enabled
DEBUG - 2011-05-17 22:48:50 --> URI Class Initialized
DEBUG - 2011-05-17 22:48:50 --> Router Class Initialized
DEBUG - 2011-05-17 22:48:50 --> Output Class Initialized
DEBUG - 2011-05-17 22:48:50 --> Input Class Initialized
DEBUG - 2011-05-17 22:48:50 --> Global POST and COOKIE data sanitized
DEBUG - 2011-05-17 22:48:50 --> Language Class Initialized
DEBUG - 2011-05-17 22:48:50 --> Loader Class Initialized
DEBUG - 2011-05-17 22:48:50 --> Controller Class Initialized
ERROR - 2011-05-17 22:48:50 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-05-17 22:48:50 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-05-17 22:48:50 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-05-17 22:48:50 --> Model Class Initialized
DEBUG - 2011-05-17 22:48:50 --> Model Class Initialized
DEBUG - 2011-05-17 22:48:50 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-05-17 22:48:50 --> Database Driver Class Initialized
DEBUG - 2011-05-17 22:48:50 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-05-17 22:48:50 --> Helper loaded: url_helper
DEBUG - 2011-05-17 22:48:50 --> File loaded: application/views/common/header.php
DEBUG - 2011-05-17 22:48:50 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-05-17 22:48:50 --> File loaded: application/views/common/footer.php
DEBUG - 2011-05-17 22:48:50 --> File loaded: application/views/layout/main.php
DEBUG - 2011-05-17 22:48:50 --> Final output sent to browser
DEBUG - 2011-05-17 22:48:50 --> Total execution time: 0.3658
DEBUG - 2011-05-17 22:48:59 --> Config Class Initialized
DEBUG - 2011-05-17 22:48:59 --> Hooks Class Initialized
DEBUG - 2011-05-17 22:48:59 --> Utf8 Class Initialized
DEBUG - 2011-05-17 22:48:59 --> UTF-8 Support Enabled
DEBUG - 2011-05-17 22:48:59 --> URI Class Initialized
DEBUG - 2011-05-17 22:48:59 --> Router Class Initialized
DEBUG - 2011-05-17 22:48:59 --> Output Class Initialized
DEBUG - 2011-05-17 22:48:59 --> Input Class Initialized
DEBUG - 2011-05-17 22:48:59 --> Global POST and COOKIE data sanitized
DEBUG - 2011-05-17 22:48:59 --> Language Class Initialized
DEBUG - 2011-05-17 22:48:59 --> Loader Class Initialized
DEBUG - 2011-05-17 22:48:59 --> Controller Class Initialized
DEBUG - 2011-05-17 22:49:00 --> Model Class Initialized
DEBUG - 2011-05-17 22:49:00 --> Model Class Initialized
DEBUG - 2011-05-17 22:49:00 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-05-17 22:49:00 --> Database Driver Class Initialized
DEBUG - 2011-05-17 22:49:00 --> Final output sent to browser
DEBUG - 2011-05-17 22:49:00 --> Total execution time: 0.7147
DEBUG - 2011-05-17 22:49:12 --> Config Class Initialized
DEBUG - 2011-05-17 22:49:12 --> Hooks Class Initialized
DEBUG - 2011-05-17 22:49:12 --> Utf8 Class Initialized
DEBUG - 2011-05-17 22:49:12 --> UTF-8 Support Enabled
DEBUG - 2011-05-17 22:49:12 --> URI Class Initialized
DEBUG - 2011-05-17 22:49:12 --> Router Class Initialized
ERROR - 2011-05-17 22:49:12 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-05-17 22:49:15 --> Config Class Initialized
DEBUG - 2011-05-17 22:49:15 --> Hooks Class Initialized
DEBUG - 2011-05-17 22:49:15 --> Utf8 Class Initialized
DEBUG - 2011-05-17 22:49:15 --> UTF-8 Support Enabled
DEBUG - 2011-05-17 22:49:15 --> URI Class Initialized
DEBUG - 2011-05-17 22:49:15 --> Router Class Initialized
ERROR - 2011-05-17 22:49:15 --> 404 Page Not Found --> favicon.ico

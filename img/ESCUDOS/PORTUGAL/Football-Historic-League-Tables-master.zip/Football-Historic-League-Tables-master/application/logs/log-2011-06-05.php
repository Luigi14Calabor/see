<?php  if ( ! defined('BASEPATH')) exit('No direct script access allowed'); ?>

DEBUG - 2011-06-05 00:48:32 --> Config Class Initialized
DEBUG - 2011-06-05 00:48:32 --> Hooks Class Initialized
DEBUG - 2011-06-05 00:48:32 --> Utf8 Class Initialized
DEBUG - 2011-06-05 00:48:32 --> UTF-8 Support Enabled
DEBUG - 2011-06-05 00:48:32 --> URI Class Initialized
DEBUG - 2011-06-05 00:48:32 --> Router Class Initialized
DEBUG - 2011-06-05 00:48:32 --> Output Class Initialized
DEBUG - 2011-06-05 00:48:32 --> Input Class Initialized
DEBUG - 2011-06-05 00:48:32 --> Global POST and COOKIE data sanitized
DEBUG - 2011-06-05 00:48:32 --> Language Class Initialized
DEBUG - 2011-06-05 00:48:32 --> Loader Class Initialized
DEBUG - 2011-06-05 00:48:32 --> Controller Class Initialized
DEBUG - 2011-06-05 00:48:32 --> Model Class Initialized
DEBUG - 2011-06-05 00:48:32 --> Model Class Initialized
DEBUG - 2011-06-05 00:48:33 --> Model Class Initialized
DEBUG - 2011-06-05 00:48:33 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-06-05 00:48:33 --> Database Driver Class Initialized
DEBUG - 2011-06-05 00:48:33 --> File loaded: application/views/table/main.php
DEBUG - 2011-06-05 00:48:33 --> Helper loaded: url_helper
DEBUG - 2011-06-05 00:48:33 --> File loaded: application/views/common/header.php
DEBUG - 2011-06-05 00:48:33 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-06-05 00:48:33 --> File loaded: application/views/common/footer.php
DEBUG - 2011-06-05 00:48:33 --> File loaded: application/views/layout/main.php
DEBUG - 2011-06-05 00:48:33 --> Final output sent to browser
DEBUG - 2011-06-05 00:48:33 --> Total execution time: 0.8476
DEBUG - 2011-06-05 00:48:34 --> Config Class Initialized
DEBUG - 2011-06-05 00:48:34 --> Hooks Class Initialized
DEBUG - 2011-06-05 00:48:34 --> Utf8 Class Initialized
DEBUG - 2011-06-05 00:48:34 --> UTF-8 Support Enabled
DEBUG - 2011-06-05 00:48:34 --> URI Class Initialized
DEBUG - 2011-06-05 00:48:34 --> Router Class Initialized
DEBUG - 2011-06-05 00:48:34 --> Output Class Initialized
DEBUG - 2011-06-05 00:48:34 --> Input Class Initialized
DEBUG - 2011-06-05 00:48:34 --> Global POST and COOKIE data sanitized
DEBUG - 2011-06-05 00:48:34 --> Language Class Initialized
DEBUG - 2011-06-05 00:48:34 --> Loader Class Initialized
DEBUG - 2011-06-05 00:48:34 --> Controller Class Initialized
ERROR - 2011-06-05 00:48:34 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-06-05 00:48:34 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-06-05 00:48:34 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-06-05 00:48:34 --> Model Class Initialized
DEBUG - 2011-06-05 00:48:34 --> Model Class Initialized
DEBUG - 2011-06-05 00:48:34 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-06-05 00:48:34 --> Database Driver Class Initialized
DEBUG - 2011-06-05 00:48:34 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-06-05 00:48:34 --> Helper loaded: url_helper
DEBUG - 2011-06-05 00:48:34 --> File loaded: application/views/common/header.php
DEBUG - 2011-06-05 00:48:34 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-06-05 00:48:34 --> File loaded: application/views/common/footer.php
DEBUG - 2011-06-05 00:48:34 --> File loaded: application/views/layout/main.php
DEBUG - 2011-06-05 00:48:34 --> Final output sent to browser
DEBUG - 2011-06-05 00:48:34 --> Total execution time: 0.1048
DEBUG - 2011-06-05 01:18:18 --> Config Class Initialized
DEBUG - 2011-06-05 01:18:18 --> Hooks Class Initialized
DEBUG - 2011-06-05 01:18:18 --> Utf8 Class Initialized
DEBUG - 2011-06-05 01:18:18 --> UTF-8 Support Enabled
DEBUG - 2011-06-05 01:18:18 --> URI Class Initialized
DEBUG - 2011-06-05 01:18:18 --> Router Class Initialized
ERROR - 2011-06-05 01:18:18 --> 404 Page Not Found --> robots.txt
DEBUG - 2011-06-05 01:18:18 --> Config Class Initialized
DEBUG - 2011-06-05 01:18:18 --> Hooks Class Initialized
DEBUG - 2011-06-05 01:18:18 --> Utf8 Class Initialized
DEBUG - 2011-06-05 01:18:18 --> UTF-8 Support Enabled
DEBUG - 2011-06-05 01:18:18 --> URI Class Initialized
DEBUG - 2011-06-05 01:18:18 --> Router Class Initialized
DEBUG - 2011-06-05 01:18:18 --> Output Class Initialized
DEBUG - 2011-06-05 01:18:18 --> Input Class Initialized
DEBUG - 2011-06-05 01:18:18 --> Global POST and COOKIE data sanitized
DEBUG - 2011-06-05 01:18:18 --> Language Class Initialized
DEBUG - 2011-06-05 01:18:18 --> Loader Class Initialized
DEBUG - 2011-06-05 01:18:18 --> Controller Class Initialized
DEBUG - 2011-06-05 01:18:18 --> Model Class Initialized
DEBUG - 2011-06-05 01:18:18 --> Model Class Initialized
DEBUG - 2011-06-05 01:18:18 --> Model Class Initialized
DEBUG - 2011-06-05 01:18:18 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-06-05 01:18:18 --> Database Driver Class Initialized
DEBUG - 2011-06-05 01:18:18 --> File loaded: application/views/table/main.php
DEBUG - 2011-06-05 01:18:18 --> Helper loaded: url_helper
DEBUG - 2011-06-05 01:18:18 --> File loaded: application/views/common/header.php
DEBUG - 2011-06-05 01:18:18 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-06-05 01:18:18 --> File loaded: application/views/common/footer.php
DEBUG - 2011-06-05 01:18:18 --> File loaded: application/views/layout/main.php
DEBUG - 2011-06-05 01:18:18 --> Final output sent to browser
DEBUG - 2011-06-05 01:18:18 --> Total execution time: 0.3082
DEBUG - 2011-06-05 01:18:49 --> Config Class Initialized
DEBUG - 2011-06-05 01:18:49 --> Hooks Class Initialized
DEBUG - 2011-06-05 01:18:49 --> Utf8 Class Initialized
DEBUG - 2011-06-05 01:18:49 --> UTF-8 Support Enabled
DEBUG - 2011-06-05 01:18:49 --> URI Class Initialized
DEBUG - 2011-06-05 01:18:49 --> Router Class Initialized
DEBUG - 2011-06-05 01:18:49 --> Output Class Initialized
DEBUG - 2011-06-05 01:18:49 --> Input Class Initialized
DEBUG - 2011-06-05 01:18:49 --> Global POST and COOKIE data sanitized
DEBUG - 2011-06-05 01:18:49 --> Language Class Initialized
DEBUG - 2011-06-05 01:18:49 --> Loader Class Initialized
DEBUG - 2011-06-05 01:18:49 --> Controller Class Initialized
ERROR - 2011-06-05 01:18:49 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-06-05 01:18:49 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-06-05 01:18:49 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-06-05 01:18:49 --> Model Class Initialized
DEBUG - 2011-06-05 01:18:49 --> Model Class Initialized
DEBUG - 2011-06-05 01:18:49 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-06-05 01:18:49 --> Database Driver Class Initialized
DEBUG - 2011-06-05 01:18:49 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-06-05 01:18:49 --> Helper loaded: url_helper
DEBUG - 2011-06-05 01:18:49 --> File loaded: application/views/common/header.php
DEBUG - 2011-06-05 01:18:49 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-06-05 01:18:49 --> File loaded: application/views/common/footer.php
DEBUG - 2011-06-05 01:18:49 --> File loaded: application/views/layout/main.php
DEBUG - 2011-06-05 01:18:49 --> Final output sent to browser
DEBUG - 2011-06-05 01:18:49 --> Total execution time: 0.0504
DEBUG - 2011-06-05 01:50:09 --> Config Class Initialized
DEBUG - 2011-06-05 01:50:09 --> Hooks Class Initialized
DEBUG - 2011-06-05 01:50:09 --> Utf8 Class Initialized
DEBUG - 2011-06-05 01:50:09 --> UTF-8 Support Enabled
DEBUG - 2011-06-05 01:50:09 --> URI Class Initialized
DEBUG - 2011-06-05 01:50:09 --> Router Class Initialized
DEBUG - 2011-06-05 01:50:09 --> Output Class Initialized
DEBUG - 2011-06-05 01:50:09 --> Input Class Initialized
DEBUG - 2011-06-05 01:50:09 --> Global POST and COOKIE data sanitized
DEBUG - 2011-06-05 01:50:09 --> Language Class Initialized
DEBUG - 2011-06-05 01:50:09 --> Loader Class Initialized
DEBUG - 2011-06-05 01:50:09 --> Controller Class Initialized
ERROR - 2011-06-05 01:50:09 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-06-05 01:50:09 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-06-05 01:50:09 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-06-05 01:50:09 --> Model Class Initialized
DEBUG - 2011-06-05 01:50:09 --> Model Class Initialized
DEBUG - 2011-06-05 01:50:09 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-06-05 01:50:09 --> Database Driver Class Initialized
DEBUG - 2011-06-05 01:50:09 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-06-05 01:50:10 --> Helper loaded: url_helper
DEBUG - 2011-06-05 01:50:10 --> File loaded: application/views/common/header.php
DEBUG - 2011-06-05 01:50:10 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-06-05 01:50:10 --> File loaded: application/views/common/footer.php
DEBUG - 2011-06-05 01:50:10 --> File loaded: application/views/layout/main.php
DEBUG - 2011-06-05 01:50:10 --> Final output sent to browser
DEBUG - 2011-06-05 01:50:10 --> Total execution time: 0.9895
DEBUG - 2011-06-05 01:50:11 --> Config Class Initialized
DEBUG - 2011-06-05 01:50:11 --> Hooks Class Initialized
DEBUG - 2011-06-05 01:50:11 --> Utf8 Class Initialized
DEBUG - 2011-06-05 01:50:11 --> UTF-8 Support Enabled
DEBUG - 2011-06-05 01:50:11 --> URI Class Initialized
DEBUG - 2011-06-05 01:50:11 --> Router Class Initialized
DEBUG - 2011-06-05 01:50:11 --> Output Class Initialized
DEBUG - 2011-06-05 01:50:11 --> Input Class Initialized
DEBUG - 2011-06-05 01:50:11 --> Global POST and COOKIE data sanitized
DEBUG - 2011-06-05 01:50:11 --> Language Class Initialized
DEBUG - 2011-06-05 01:50:11 --> Loader Class Initialized
DEBUG - 2011-06-05 01:50:11 --> Controller Class Initialized
DEBUG - 2011-06-05 01:50:11 --> Model Class Initialized
DEBUG - 2011-06-05 01:50:11 --> Model Class Initialized
DEBUG - 2011-06-05 01:50:11 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-06-05 01:50:11 --> Database Driver Class Initialized
DEBUG - 2011-06-05 01:50:25 --> Final output sent to browser
DEBUG - 2011-06-05 01:50:25 --> Total execution time: 14.4443
DEBUG - 2011-06-05 01:50:26 --> Config Class Initialized
DEBUG - 2011-06-05 01:50:26 --> Hooks Class Initialized
DEBUG - 2011-06-05 01:50:26 --> Utf8 Class Initialized
DEBUG - 2011-06-05 01:50:26 --> UTF-8 Support Enabled
DEBUG - 2011-06-05 01:50:26 --> URI Class Initialized
DEBUG - 2011-06-05 01:50:26 --> Router Class Initialized
ERROR - 2011-06-05 01:50:26 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-06-05 01:50:44 --> Config Class Initialized
DEBUG - 2011-06-05 01:50:44 --> Hooks Class Initialized
DEBUG - 2011-06-05 01:50:44 --> Utf8 Class Initialized
DEBUG - 2011-06-05 01:50:44 --> UTF-8 Support Enabled
DEBUG - 2011-06-05 01:50:44 --> URI Class Initialized
DEBUG - 2011-06-05 01:50:44 --> Router Class Initialized
DEBUG - 2011-06-05 01:50:44 --> Output Class Initialized
DEBUG - 2011-06-05 01:50:44 --> Input Class Initialized
DEBUG - 2011-06-05 01:50:44 --> Global POST and COOKIE data sanitized
DEBUG - 2011-06-05 01:50:44 --> Language Class Initialized
DEBUG - 2011-06-05 01:50:44 --> Loader Class Initialized
DEBUG - 2011-06-05 01:50:44 --> Controller Class Initialized
ERROR - 2011-06-05 01:50:44 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-06-05 01:50:44 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-06-05 01:50:44 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-06-05 01:50:44 --> Model Class Initialized
DEBUG - 2011-06-05 01:50:44 --> Model Class Initialized
DEBUG - 2011-06-05 01:50:44 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-06-05 01:50:44 --> Database Driver Class Initialized
DEBUG - 2011-06-05 01:50:44 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-06-05 01:50:44 --> Helper loaded: url_helper
DEBUG - 2011-06-05 01:50:44 --> File loaded: application/views/common/header.php
DEBUG - 2011-06-05 01:50:44 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-06-05 01:50:44 --> File loaded: application/views/common/footer.php
DEBUG - 2011-06-05 01:50:44 --> File loaded: application/views/layout/main.php
DEBUG - 2011-06-05 01:50:44 --> Final output sent to browser
DEBUG - 2011-06-05 01:50:44 --> Total execution time: 0.0298
DEBUG - 2011-06-05 01:50:45 --> Config Class Initialized
DEBUG - 2011-06-05 01:50:45 --> Hooks Class Initialized
DEBUG - 2011-06-05 01:50:45 --> Utf8 Class Initialized
DEBUG - 2011-06-05 01:50:45 --> UTF-8 Support Enabled
DEBUG - 2011-06-05 01:50:45 --> URI Class Initialized
DEBUG - 2011-06-05 01:50:45 --> Router Class Initialized
DEBUG - 2011-06-05 01:50:45 --> Output Class Initialized
DEBUG - 2011-06-05 01:50:45 --> Input Class Initialized
DEBUG - 2011-06-05 01:50:45 --> Global POST and COOKIE data sanitized
DEBUG - 2011-06-05 01:50:45 --> Language Class Initialized
DEBUG - 2011-06-05 01:50:45 --> Loader Class Initialized
DEBUG - 2011-06-05 01:50:45 --> Controller Class Initialized
DEBUG - 2011-06-05 01:50:45 --> Model Class Initialized
DEBUG - 2011-06-05 01:50:45 --> Model Class Initialized
DEBUG - 2011-06-05 01:50:45 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-06-05 01:50:45 --> Database Driver Class Initialized
DEBUG - 2011-06-05 01:50:45 --> Final output sent to browser
DEBUG - 2011-06-05 01:50:45 --> Total execution time: 0.5644
DEBUG - 2011-06-05 02:08:27 --> Config Class Initialized
DEBUG - 2011-06-05 02:08:27 --> Hooks Class Initialized
DEBUG - 2011-06-05 02:08:27 --> Utf8 Class Initialized
DEBUG - 2011-06-05 02:08:27 --> UTF-8 Support Enabled
DEBUG - 2011-06-05 02:08:27 --> URI Class Initialized
DEBUG - 2011-06-05 02:08:27 --> Router Class Initialized
DEBUG - 2011-06-05 02:08:27 --> Output Class Initialized
DEBUG - 2011-06-05 02:08:27 --> Input Class Initialized
DEBUG - 2011-06-05 02:08:27 --> Global POST and COOKIE data sanitized
DEBUG - 2011-06-05 02:08:27 --> Language Class Initialized
DEBUG - 2011-06-05 02:08:27 --> Loader Class Initialized
DEBUG - 2011-06-05 02:08:27 --> Controller Class Initialized
DEBUG - 2011-06-05 02:08:27 --> Model Class Initialized
DEBUG - 2011-06-05 02:08:27 --> Model Class Initialized
DEBUG - 2011-06-05 02:08:27 --> Model Class Initialized
DEBUG - 2011-06-05 02:08:27 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-06-05 02:08:27 --> Database Driver Class Initialized
DEBUG - 2011-06-05 02:08:56 --> File loaded: application/views/table/main.php
DEBUG - 2011-06-05 02:08:57 --> Helper loaded: url_helper
DEBUG - 2011-06-05 02:08:57 --> File loaded: application/views/common/header.php
DEBUG - 2011-06-05 02:08:57 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-06-05 02:08:57 --> File loaded: application/views/common/footer.php
DEBUG - 2011-06-05 02:08:57 --> File loaded: application/views/layout/main.php
DEBUG - 2011-06-05 02:08:57 --> Final output sent to browser
DEBUG - 2011-06-05 02:08:57 --> Total execution time: 29.4828
DEBUG - 2011-06-05 02:09:00 --> Config Class Initialized
DEBUG - 2011-06-05 02:09:00 --> Hooks Class Initialized
DEBUG - 2011-06-05 02:09:00 --> Utf8 Class Initialized
DEBUG - 2011-06-05 02:09:00 --> UTF-8 Support Enabled
DEBUG - 2011-06-05 02:09:00 --> URI Class Initialized
DEBUG - 2011-06-05 02:09:00 --> Router Class Initialized
ERROR - 2011-06-05 02:09:00 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-06-05 02:09:00 --> Config Class Initialized
DEBUG - 2011-06-05 02:09:00 --> Hooks Class Initialized
DEBUG - 2011-06-05 02:09:00 --> Utf8 Class Initialized
DEBUG - 2011-06-05 02:09:00 --> UTF-8 Support Enabled
DEBUG - 2011-06-05 02:09:00 --> URI Class Initialized
DEBUG - 2011-06-05 02:09:00 --> Router Class Initialized
ERROR - 2011-06-05 02:09:00 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-06-05 02:09:01 --> Config Class Initialized
DEBUG - 2011-06-05 02:09:01 --> Hooks Class Initialized
DEBUG - 2011-06-05 02:09:01 --> Utf8 Class Initialized
DEBUG - 2011-06-05 02:09:01 --> UTF-8 Support Enabled
DEBUG - 2011-06-05 02:09:01 --> URI Class Initialized
DEBUG - 2011-06-05 02:09:01 --> Router Class Initialized
ERROR - 2011-06-05 02:09:01 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-06-05 03:13:48 --> Config Class Initialized
DEBUG - 2011-06-05 03:13:48 --> Hooks Class Initialized
DEBUG - 2011-06-05 03:13:48 --> Utf8 Class Initialized
DEBUG - 2011-06-05 03:13:48 --> UTF-8 Support Enabled
DEBUG - 2011-06-05 03:13:48 --> URI Class Initialized
DEBUG - 2011-06-05 03:13:48 --> Router Class Initialized
DEBUG - 2011-06-05 03:13:48 --> No URI present. Default controller set.
DEBUG - 2011-06-05 03:13:48 --> Output Class Initialized
DEBUG - 2011-06-05 03:13:48 --> Input Class Initialized
DEBUG - 2011-06-05 03:13:48 --> Global POST and COOKIE data sanitized
DEBUG - 2011-06-05 03:13:48 --> Language Class Initialized
DEBUG - 2011-06-05 03:13:48 --> Loader Class Initialized
DEBUG - 2011-06-05 03:13:48 --> Controller Class Initialized
DEBUG - 2011-06-05 03:13:48 --> File loaded: application/views/splash/main.php
DEBUG - 2011-06-05 03:13:48 --> Helper loaded: url_helper
DEBUG - 2011-06-05 03:13:48 --> File loaded: application/views/common/header.php
DEBUG - 2011-06-05 03:13:48 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-06-05 03:13:48 --> File loaded: application/views/common/footer.php
DEBUG - 2011-06-05 03:13:48 --> File loaded: application/views/layout/main.php
DEBUG - 2011-06-05 03:13:48 --> Final output sent to browser
DEBUG - 2011-06-05 03:13:48 --> Total execution time: 0.2866
DEBUG - 2011-06-05 03:18:43 --> Config Class Initialized
DEBUG - 2011-06-05 03:18:43 --> Hooks Class Initialized
DEBUG - 2011-06-05 03:18:43 --> Utf8 Class Initialized
DEBUG - 2011-06-05 03:18:43 --> UTF-8 Support Enabled
DEBUG - 2011-06-05 03:18:43 --> URI Class Initialized
DEBUG - 2011-06-05 03:18:43 --> Router Class Initialized
DEBUG - 2011-06-05 03:18:43 --> Output Class Initialized
DEBUG - 2011-06-05 03:18:43 --> Input Class Initialized
DEBUG - 2011-06-05 03:18:43 --> Global POST and COOKIE data sanitized
DEBUG - 2011-06-05 03:18:43 --> Language Class Initialized
DEBUG - 2011-06-05 03:18:43 --> Loader Class Initialized
DEBUG - 2011-06-05 03:18:43 --> Controller Class Initialized
DEBUG - 2011-06-05 03:18:43 --> Model Class Initialized
DEBUG - 2011-06-05 03:18:43 --> Model Class Initialized
DEBUG - 2011-06-05 03:18:43 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-06-05 03:18:43 --> Database Driver Class Initialized
DEBUG - 2011-06-05 03:18:46 --> Final output sent to browser
DEBUG - 2011-06-05 03:18:46 --> Total execution time: 2.6210
DEBUG - 2011-06-05 04:38:01 --> Config Class Initialized
DEBUG - 2011-06-05 04:38:01 --> Hooks Class Initialized
DEBUG - 2011-06-05 04:38:01 --> Utf8 Class Initialized
DEBUG - 2011-06-05 04:38:01 --> UTF-8 Support Enabled
DEBUG - 2011-06-05 04:38:01 --> URI Class Initialized
DEBUG - 2011-06-05 04:38:01 --> Router Class Initialized
ERROR - 2011-06-05 04:38:01 --> 404 Page Not Found --> robots.txt
DEBUG - 2011-06-05 04:38:02 --> Config Class Initialized
DEBUG - 2011-06-05 04:38:02 --> Hooks Class Initialized
DEBUG - 2011-06-05 04:38:02 --> Utf8 Class Initialized
DEBUG - 2011-06-05 04:38:02 --> UTF-8 Support Enabled
DEBUG - 2011-06-05 04:38:02 --> URI Class Initialized
DEBUG - 2011-06-05 04:38:02 --> Router Class Initialized
DEBUG - 2011-06-05 04:38:02 --> No URI present. Default controller set.
DEBUG - 2011-06-05 04:38:02 --> Output Class Initialized
DEBUG - 2011-06-05 04:38:02 --> Input Class Initialized
DEBUG - 2011-06-05 04:38:02 --> Global POST and COOKIE data sanitized
DEBUG - 2011-06-05 04:38:02 --> Language Class Initialized
DEBUG - 2011-06-05 04:38:02 --> Loader Class Initialized
DEBUG - 2011-06-05 04:38:02 --> Controller Class Initialized
DEBUG - 2011-06-05 04:38:02 --> File loaded: application/views/splash/main.php
DEBUG - 2011-06-05 04:38:02 --> Helper loaded: url_helper
DEBUG - 2011-06-05 04:38:02 --> File loaded: application/views/common/header.php
DEBUG - 2011-06-05 04:38:02 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-06-05 04:38:02 --> File loaded: application/views/common/footer.php
DEBUG - 2011-06-05 04:38:02 --> File loaded: application/views/layout/main.php
DEBUG - 2011-06-05 04:38:02 --> Final output sent to browser
DEBUG - 2011-06-05 04:38:02 --> Total execution time: 0.2253
DEBUG - 2011-06-05 05:51:04 --> Config Class Initialized
DEBUG - 2011-06-05 05:51:04 --> Config Class Initialized
DEBUG - 2011-06-05 05:51:04 --> Hooks Class Initialized
DEBUG - 2011-06-05 05:51:04 --> Hooks Class Initialized
DEBUG - 2011-06-05 05:51:04 --> Utf8 Class Initialized
DEBUG - 2011-06-05 05:51:04 --> UTF-8 Support Enabled
DEBUG - 2011-06-05 05:51:04 --> Utf8 Class Initialized
DEBUG - 2011-06-05 05:51:04 --> UTF-8 Support Enabled
DEBUG - 2011-06-05 05:51:04 --> URI Class Initialized
DEBUG - 2011-06-05 05:51:04 --> URI Class Initialized
DEBUG - 2011-06-05 05:51:04 --> Router Class Initialized
DEBUG - 2011-06-05 05:51:04 --> Router Class Initialized
DEBUG - 2011-06-05 05:51:04 --> Output Class Initialized
DEBUG - 2011-06-05 05:51:04 --> Output Class Initialized
DEBUG - 2011-06-05 05:51:04 --> Input Class Initialized
DEBUG - 2011-06-05 05:51:04 --> Global POST and COOKIE data sanitized
DEBUG - 2011-06-05 05:51:04 --> Input Class Initialized
DEBUG - 2011-06-05 05:51:04 --> Global POST and COOKIE data sanitized
DEBUG - 2011-06-05 05:51:04 --> Language Class Initialized
DEBUG - 2011-06-05 05:51:04 --> Language Class Initialized
DEBUG - 2011-06-05 05:51:04 --> Loader Class Initialized
DEBUG - 2011-06-05 05:51:04 --> Loader Class Initialized
DEBUG - 2011-06-05 05:51:04 --> Controller Class Initialized
DEBUG - 2011-06-05 05:51:04 --> Controller Class Initialized
DEBUG - 2011-06-05 05:51:04 --> Model Class Initialized
DEBUG - 2011-06-05 05:51:04 --> Model Class Initialized
DEBUG - 2011-06-05 05:51:04 --> Model Class Initialized
DEBUG - 2011-06-05 05:51:04 --> Model Class Initialized
DEBUG - 2011-06-05 05:51:04 --> Model Class Initialized
DEBUG - 2011-06-05 05:51:04 --> Model Class Initialized
DEBUG - 2011-06-05 05:51:04 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-06-05 05:51:04 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-06-05 05:51:04 --> Database Driver Class Initialized
DEBUG - 2011-06-05 05:51:04 --> Database Driver Class Initialized
DEBUG - 2011-06-05 05:51:04 --> Config Class Initialized
DEBUG - 2011-06-05 05:51:04 --> Hooks Class Initialized
DEBUG - 2011-06-05 05:51:04 --> Utf8 Class Initialized
DEBUG - 2011-06-05 05:51:04 --> UTF-8 Support Enabled
DEBUG - 2011-06-05 05:51:04 --> URI Class Initialized
DEBUG - 2011-06-05 05:51:04 --> Router Class Initialized
DEBUG - 2011-06-05 05:51:04 --> Output Class Initialized
DEBUG - 2011-06-05 05:51:04 --> Input Class Initialized
DEBUG - 2011-06-05 05:51:04 --> Global POST and COOKIE data sanitized
DEBUG - 2011-06-05 05:51:04 --> Language Class Initialized
DEBUG - 2011-06-05 05:51:04 --> Loader Class Initialized
DEBUG - 2011-06-05 05:51:04 --> Controller Class Initialized
DEBUG - 2011-06-05 05:51:04 --> Model Class Initialized
DEBUG - 2011-06-05 05:51:04 --> Model Class Initialized
DEBUG - 2011-06-05 05:51:04 --> Model Class Initialized
DEBUG - 2011-06-05 05:51:04 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-06-05 05:51:04 --> Database Driver Class Initialized
DEBUG - 2011-06-05 05:51:05 --> File loaded: application/views/table/main.php
DEBUG - 2011-06-05 05:51:05 --> File loaded: application/views/table/main.php
DEBUG - 2011-06-05 05:51:05 --> File loaded: application/views/table/main.php
DEBUG - 2011-06-05 05:51:05 --> Helper loaded: url_helper
DEBUG - 2011-06-05 05:51:05 --> Helper loaded: url_helper
DEBUG - 2011-06-05 05:51:05 --> File loaded: application/views/common/header.php
DEBUG - 2011-06-05 05:51:05 --> Helper loaded: url_helper
DEBUG - 2011-06-05 05:51:05 --> File loaded: application/views/common/header.php
DEBUG - 2011-06-05 05:51:05 --> File loaded: application/views/common/header.php
DEBUG - 2011-06-05 05:51:05 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-06-05 05:51:05 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-06-05 05:51:05 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-06-05 05:51:05 --> File loaded: application/views/common/footer.php
DEBUG - 2011-06-05 05:51:05 --> File loaded: application/views/common/footer.php
DEBUG - 2011-06-05 05:51:05 --> File loaded: application/views/layout/main.php
DEBUG - 2011-06-05 05:51:05 --> File loaded: application/views/common/footer.php
DEBUG - 2011-06-05 05:51:05 --> File loaded: application/views/layout/main.php
DEBUG - 2011-06-05 05:51:05 --> File loaded: application/views/layout/main.php
DEBUG - 2011-06-05 05:51:05 --> Final output sent to browser
DEBUG - 2011-06-05 05:51:05 --> Total execution time: 1.1739
DEBUG - 2011-06-05 05:51:05 --> Final output sent to browser
DEBUG - 2011-06-05 05:51:05 --> Total execution time: 1.1741
DEBUG - 2011-06-05 05:51:05 --> Final output sent to browser
DEBUG - 2011-06-05 05:51:05 --> Total execution time: 0.3730
DEBUG - 2011-06-05 05:51:05 --> Config Class Initialized
DEBUG - 2011-06-05 05:51:05 --> Hooks Class Initialized
DEBUG - 2011-06-05 05:51:05 --> Utf8 Class Initialized
DEBUG - 2011-06-05 05:51:05 --> UTF-8 Support Enabled
DEBUG - 2011-06-05 05:51:05 --> URI Class Initialized
DEBUG - 2011-06-05 05:51:05 --> Router Class Initialized
DEBUG - 2011-06-05 05:51:05 --> Output Class Initialized
DEBUG - 2011-06-05 05:51:05 --> Input Class Initialized
DEBUG - 2011-06-05 05:51:05 --> Global POST and COOKIE data sanitized
DEBUG - 2011-06-05 05:51:05 --> Language Class Initialized
DEBUG - 2011-06-05 05:51:05 --> Loader Class Initialized
DEBUG - 2011-06-05 05:51:05 --> Controller Class Initialized
DEBUG - 2011-06-05 05:51:05 --> Model Class Initialized
DEBUG - 2011-06-05 05:51:05 --> Model Class Initialized
DEBUG - 2011-06-05 05:51:05 --> Model Class Initialized
DEBUG - 2011-06-05 05:51:05 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-06-05 05:51:05 --> Database Driver Class Initialized
DEBUG - 2011-06-05 05:51:05 --> File loaded: application/views/table/main.php
DEBUG - 2011-06-05 05:51:05 --> Helper loaded: url_helper
DEBUG - 2011-06-05 05:51:05 --> File loaded: application/views/common/header.php
DEBUG - 2011-06-05 05:51:05 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-06-05 05:51:05 --> File loaded: application/views/common/footer.php
DEBUG - 2011-06-05 05:51:05 --> File loaded: application/views/layout/main.php
DEBUG - 2011-06-05 05:51:05 --> Final output sent to browser
DEBUG - 2011-06-05 05:51:05 --> Total execution time: 0.0531
DEBUG - 2011-06-05 05:51:05 --> Config Class Initialized
DEBUG - 2011-06-05 05:51:05 --> Hooks Class Initialized
DEBUG - 2011-06-05 05:51:05 --> Utf8 Class Initialized
DEBUG - 2011-06-05 05:51:05 --> UTF-8 Support Enabled
DEBUG - 2011-06-05 05:51:05 --> URI Class Initialized
DEBUG - 2011-06-05 05:51:05 --> Router Class Initialized
DEBUG - 2011-06-05 05:51:05 --> Output Class Initialized
DEBUG - 2011-06-05 05:51:05 --> Input Class Initialized
DEBUG - 2011-06-05 05:51:05 --> Global POST and COOKIE data sanitized
DEBUG - 2011-06-05 05:51:05 --> Language Class Initialized
DEBUG - 2011-06-05 05:51:05 --> Loader Class Initialized
DEBUG - 2011-06-05 05:51:05 --> Controller Class Initialized
ERROR - 2011-06-05 05:51:05 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-06-05 05:51:05 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-06-05 05:51:05 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-06-05 05:51:05 --> Model Class Initialized
DEBUG - 2011-06-05 05:51:05 --> Model Class Initialized
DEBUG - 2011-06-05 05:51:05 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-06-05 05:51:05 --> Database Driver Class Initialized
DEBUG - 2011-06-05 05:51:05 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-06-05 05:51:05 --> Helper loaded: url_helper
DEBUG - 2011-06-05 05:51:05 --> File loaded: application/views/common/header.php
DEBUG - 2011-06-05 05:51:05 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-06-05 05:51:05 --> File loaded: application/views/common/footer.php
DEBUG - 2011-06-05 05:51:05 --> File loaded: application/views/layout/main.php
DEBUG - 2011-06-05 05:51:05 --> Final output sent to browser
DEBUG - 2011-06-05 05:51:05 --> Total execution time: 0.0781
DEBUG - 2011-06-05 05:51:07 --> Config Class Initialized
DEBUG - 2011-06-05 05:51:07 --> Hooks Class Initialized
DEBUG - 2011-06-05 05:51:07 --> Utf8 Class Initialized
DEBUG - 2011-06-05 05:51:07 --> UTF-8 Support Enabled
DEBUG - 2011-06-05 05:51:07 --> URI Class Initialized
DEBUG - 2011-06-05 05:51:07 --> Router Class Initialized
DEBUG - 2011-06-05 05:51:07 --> Output Class Initialized
DEBUG - 2011-06-05 05:51:07 --> Input Class Initialized
DEBUG - 2011-06-05 05:51:07 --> Global POST and COOKIE data sanitized
DEBUG - 2011-06-05 05:51:07 --> Language Class Initialized
DEBUG - 2011-06-05 05:51:07 --> Loader Class Initialized
DEBUG - 2011-06-05 05:51:07 --> Controller Class Initialized
DEBUG - 2011-06-05 05:51:07 --> Model Class Initialized
DEBUG - 2011-06-05 05:51:07 --> Model Class Initialized
DEBUG - 2011-06-05 05:51:07 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-06-05 05:51:07 --> Database Driver Class Initialized
DEBUG - 2011-06-05 05:51:08 --> Final output sent to browser
DEBUG - 2011-06-05 05:51:08 --> Total execution time: 0.6379
DEBUG - 2011-06-05 05:51:09 --> Config Class Initialized
DEBUG - 2011-06-05 05:51:09 --> Hooks Class Initialized
DEBUG - 2011-06-05 05:51:09 --> Utf8 Class Initialized
DEBUG - 2011-06-05 05:51:09 --> UTF-8 Support Enabled
DEBUG - 2011-06-05 05:51:09 --> URI Class Initialized
DEBUG - 2011-06-05 05:51:10 --> Router Class Initialized
ERROR - 2011-06-05 05:51:10 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-06-05 06:28:08 --> Config Class Initialized
DEBUG - 2011-06-05 06:28:08 --> Hooks Class Initialized
DEBUG - 2011-06-05 06:28:08 --> Utf8 Class Initialized
DEBUG - 2011-06-05 06:28:08 --> UTF-8 Support Enabled
DEBUG - 2011-06-05 06:28:08 --> URI Class Initialized
DEBUG - 2011-06-05 06:28:08 --> Router Class Initialized
ERROR - 2011-06-05 06:28:08 --> 404 Page Not Found --> robots.txt
DEBUG - 2011-06-05 06:28:08 --> Config Class Initialized
DEBUG - 2011-06-05 06:28:08 --> Hooks Class Initialized
DEBUG - 2011-06-05 06:28:08 --> Utf8 Class Initialized
DEBUG - 2011-06-05 06:28:08 --> UTF-8 Support Enabled
DEBUG - 2011-06-05 06:28:08 --> URI Class Initialized
DEBUG - 2011-06-05 06:28:08 --> Router Class Initialized
DEBUG - 2011-06-05 06:28:08 --> Output Class Initialized
DEBUG - 2011-06-05 06:28:08 --> Input Class Initialized
DEBUG - 2011-06-05 06:28:08 --> Global POST and COOKIE data sanitized
DEBUG - 2011-06-05 06:28:08 --> Language Class Initialized
DEBUG - 2011-06-05 06:28:08 --> Loader Class Initialized
DEBUG - 2011-06-05 06:28:08 --> Controller Class Initialized
ERROR - 2011-06-05 06:28:08 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-06-05 06:28:08 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-06-05 06:28:08 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-06-05 06:28:08 --> Model Class Initialized
DEBUG - 2011-06-05 06:28:08 --> Model Class Initialized
DEBUG - 2011-06-05 06:28:08 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-06-05 06:28:08 --> Database Driver Class Initialized
DEBUG - 2011-06-05 06:28:08 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-06-05 06:28:08 --> Helper loaded: url_helper
DEBUG - 2011-06-05 06:28:08 --> File loaded: application/views/common/header.php
DEBUG - 2011-06-05 06:28:08 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-06-05 06:28:08 --> File loaded: application/views/common/footer.php
DEBUG - 2011-06-05 06:28:08 --> File loaded: application/views/layout/main.php
DEBUG - 2011-06-05 06:28:08 --> Final output sent to browser
DEBUG - 2011-06-05 06:28:08 --> Total execution time: 0.2902
DEBUG - 2011-06-05 09:49:37 --> Config Class Initialized
DEBUG - 2011-06-05 09:49:37 --> Hooks Class Initialized
DEBUG - 2011-06-05 09:49:37 --> Utf8 Class Initialized
DEBUG - 2011-06-05 09:49:37 --> UTF-8 Support Enabled
DEBUG - 2011-06-05 09:49:37 --> URI Class Initialized
DEBUG - 2011-06-05 09:49:37 --> Router Class Initialized
ERROR - 2011-06-05 09:49:37 --> 404 Page Not Found --> robots.txt
DEBUG - 2011-06-05 09:49:37 --> Config Class Initialized
DEBUG - 2011-06-05 09:49:37 --> Hooks Class Initialized
DEBUG - 2011-06-05 09:49:37 --> Utf8 Class Initialized
DEBUG - 2011-06-05 09:49:37 --> UTF-8 Support Enabled
DEBUG - 2011-06-05 09:49:37 --> URI Class Initialized
DEBUG - 2011-06-05 09:49:37 --> Router Class Initialized
DEBUG - 2011-06-05 09:49:37 --> Output Class Initialized
DEBUG - 2011-06-05 09:49:37 --> Input Class Initialized
DEBUG - 2011-06-05 09:49:37 --> Global POST and COOKIE data sanitized
DEBUG - 2011-06-05 09:49:37 --> Language Class Initialized
DEBUG - 2011-06-05 09:49:37 --> Loader Class Initialized
DEBUG - 2011-06-05 09:49:37 --> Controller Class Initialized
ERROR - 2011-06-05 09:49:37 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-06-05 09:49:37 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-06-05 09:49:37 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-06-05 09:49:37 --> Model Class Initialized
DEBUG - 2011-06-05 09:49:37 --> Model Class Initialized
DEBUG - 2011-06-05 09:49:37 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-06-05 09:49:37 --> Database Driver Class Initialized
DEBUG - 2011-06-05 09:49:37 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-06-05 09:49:37 --> Helper loaded: url_helper
DEBUG - 2011-06-05 09:49:37 --> File loaded: application/views/common/header.php
DEBUG - 2011-06-05 09:49:37 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-06-05 09:49:37 --> File loaded: application/views/common/footer.php
DEBUG - 2011-06-05 09:49:37 --> File loaded: application/views/layout/main.php
DEBUG - 2011-06-05 09:49:37 --> Final output sent to browser
DEBUG - 2011-06-05 09:49:37 --> Total execution time: 0.3590
DEBUG - 2011-06-05 10:25:51 --> Config Class Initialized
DEBUG - 2011-06-05 10:25:51 --> Hooks Class Initialized
DEBUG - 2011-06-05 10:25:51 --> Utf8 Class Initialized
DEBUG - 2011-06-05 10:25:51 --> UTF-8 Support Enabled
DEBUG - 2011-06-05 10:25:51 --> URI Class Initialized
DEBUG - 2011-06-05 10:25:51 --> Router Class Initialized
DEBUG - 2011-06-05 10:25:51 --> Output Class Initialized
DEBUG - 2011-06-05 10:25:51 --> Input Class Initialized
DEBUG - 2011-06-05 10:25:51 --> Global POST and COOKIE data sanitized
DEBUG - 2011-06-05 10:25:51 --> Language Class Initialized
DEBUG - 2011-06-05 10:25:51 --> Loader Class Initialized
DEBUG - 2011-06-05 10:25:51 --> Controller Class Initialized
DEBUG - 2011-06-05 10:25:51 --> Model Class Initialized
DEBUG - 2011-06-05 10:25:51 --> Model Class Initialized
DEBUG - 2011-06-05 10:25:51 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-06-05 10:25:51 --> Database Driver Class Initialized
DEBUG - 2011-06-05 10:25:52 --> Final output sent to browser
DEBUG - 2011-06-05 10:25:52 --> Total execution time: 1.6317
DEBUG - 2011-06-05 10:54:31 --> Config Class Initialized
DEBUG - 2011-06-05 10:54:31 --> Hooks Class Initialized
DEBUG - 2011-06-05 10:54:31 --> Utf8 Class Initialized
DEBUG - 2011-06-05 10:54:31 --> UTF-8 Support Enabled
DEBUG - 2011-06-05 10:54:31 --> URI Class Initialized
DEBUG - 2011-06-05 10:54:31 --> Router Class Initialized
DEBUG - 2011-06-05 10:54:31 --> Output Class Initialized
DEBUG - 2011-06-05 10:54:31 --> Input Class Initialized
DEBUG - 2011-06-05 10:54:31 --> Global POST and COOKIE data sanitized
DEBUG - 2011-06-05 10:54:31 --> Language Class Initialized
DEBUG - 2011-06-05 10:54:31 --> Loader Class Initialized
DEBUG - 2011-06-05 10:54:31 --> Controller Class Initialized
ERROR - 2011-06-05 10:54:31 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-06-05 10:54:31 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-06-05 10:54:31 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-06-05 10:54:31 --> Model Class Initialized
DEBUG - 2011-06-05 10:54:31 --> Model Class Initialized
DEBUG - 2011-06-05 10:54:31 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-06-05 10:54:31 --> Database Driver Class Initialized
DEBUG - 2011-06-05 10:54:31 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-06-05 10:54:31 --> Helper loaded: url_helper
DEBUG - 2011-06-05 10:54:31 --> File loaded: application/views/common/header.php
DEBUG - 2011-06-05 10:54:31 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-06-05 10:54:31 --> File loaded: application/views/common/footer.php
DEBUG - 2011-06-05 10:54:31 --> File loaded: application/views/layout/main.php
DEBUG - 2011-06-05 10:54:31 --> Final output sent to browser
DEBUG - 2011-06-05 10:54:31 --> Total execution time: 0.4310
DEBUG - 2011-06-05 10:54:33 --> Config Class Initialized
DEBUG - 2011-06-05 10:54:33 --> Hooks Class Initialized
DEBUG - 2011-06-05 10:54:33 --> Utf8 Class Initialized
DEBUG - 2011-06-05 10:54:33 --> UTF-8 Support Enabled
DEBUG - 2011-06-05 10:54:33 --> URI Class Initialized
DEBUG - 2011-06-05 10:54:33 --> Router Class Initialized
DEBUG - 2011-06-05 10:54:33 --> Output Class Initialized
DEBUG - 2011-06-05 10:54:33 --> Input Class Initialized
DEBUG - 2011-06-05 10:54:33 --> Global POST and COOKIE data sanitized
DEBUG - 2011-06-05 10:54:33 --> Language Class Initialized
DEBUG - 2011-06-05 10:54:33 --> Loader Class Initialized
DEBUG - 2011-06-05 10:54:33 --> Controller Class Initialized
DEBUG - 2011-06-05 10:54:33 --> Model Class Initialized
DEBUG - 2011-06-05 10:54:33 --> Model Class Initialized
DEBUG - 2011-06-05 10:54:33 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-06-05 10:54:33 --> Database Driver Class Initialized
DEBUG - 2011-06-05 10:54:33 --> Final output sent to browser
DEBUG - 2011-06-05 10:54:33 --> Total execution time: 0.6729
DEBUG - 2011-06-05 10:54:34 --> Config Class Initialized
DEBUG - 2011-06-05 10:54:34 --> Hooks Class Initialized
DEBUG - 2011-06-05 10:54:34 --> Utf8 Class Initialized
DEBUG - 2011-06-05 10:54:34 --> UTF-8 Support Enabled
DEBUG - 2011-06-05 10:54:34 --> URI Class Initialized
DEBUG - 2011-06-05 10:54:34 --> Router Class Initialized
ERROR - 2011-06-05 10:54:34 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-06-05 10:54:35 --> Config Class Initialized
DEBUG - 2011-06-05 10:54:35 --> Hooks Class Initialized
DEBUG - 2011-06-05 10:54:35 --> Utf8 Class Initialized
DEBUG - 2011-06-05 10:54:35 --> UTF-8 Support Enabled
DEBUG - 2011-06-05 10:54:35 --> URI Class Initialized
DEBUG - 2011-06-05 10:54:35 --> Router Class Initialized
ERROR - 2011-06-05 10:54:35 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-06-05 10:58:17 --> Config Class Initialized
DEBUG - 2011-06-05 10:58:17 --> Hooks Class Initialized
DEBUG - 2011-06-05 10:58:17 --> Utf8 Class Initialized
DEBUG - 2011-06-05 10:58:17 --> UTF-8 Support Enabled
DEBUG - 2011-06-05 10:58:17 --> URI Class Initialized
DEBUG - 2011-06-05 10:58:17 --> Router Class Initialized
DEBUG - 2011-06-05 10:58:17 --> No URI present. Default controller set.
DEBUG - 2011-06-05 10:58:17 --> Output Class Initialized
DEBUG - 2011-06-05 10:58:17 --> Input Class Initialized
DEBUG - 2011-06-05 10:58:17 --> Global POST and COOKIE data sanitized
DEBUG - 2011-06-05 10:58:17 --> Language Class Initialized
DEBUG - 2011-06-05 10:58:17 --> Loader Class Initialized
DEBUG - 2011-06-05 10:58:17 --> Controller Class Initialized
DEBUG - 2011-06-05 10:58:17 --> File loaded: application/views/splash/main.php
DEBUG - 2011-06-05 10:58:17 --> Helper loaded: url_helper
DEBUG - 2011-06-05 10:58:17 --> File loaded: application/views/common/header.php
DEBUG - 2011-06-05 10:58:17 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-06-05 10:58:17 --> File loaded: application/views/common/footer.php
DEBUG - 2011-06-05 10:58:17 --> File loaded: application/views/layout/main.php
DEBUG - 2011-06-05 10:58:17 --> Final output sent to browser
DEBUG - 2011-06-05 10:58:17 --> Total execution time: 0.1388
DEBUG - 2011-06-05 12:11:06 --> Config Class Initialized
DEBUG - 2011-06-05 12:11:06 --> Hooks Class Initialized
DEBUG - 2011-06-05 12:11:06 --> Utf8 Class Initialized
DEBUG - 2011-06-05 12:11:06 --> UTF-8 Support Enabled
DEBUG - 2011-06-05 12:11:06 --> URI Class Initialized
DEBUG - 2011-06-05 12:11:06 --> Router Class Initialized
DEBUG - 2011-06-05 12:11:06 --> Output Class Initialized
DEBUG - 2011-06-05 12:11:06 --> Input Class Initialized
DEBUG - 2011-06-05 12:11:06 --> Global POST and COOKIE data sanitized
DEBUG - 2011-06-05 12:11:06 --> Language Class Initialized
DEBUG - 2011-06-05 12:11:06 --> Loader Class Initialized
DEBUG - 2011-06-05 12:11:06 --> Controller Class Initialized
ERROR - 2011-06-05 12:11:06 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-06-05 12:11:06 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-06-05 12:11:06 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-06-05 12:11:06 --> Model Class Initialized
DEBUG - 2011-06-05 12:11:06 --> Model Class Initialized
DEBUG - 2011-06-05 12:11:06 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-06-05 12:11:06 --> Database Driver Class Initialized
DEBUG - 2011-06-05 12:11:06 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-06-05 12:11:07 --> Helper loaded: url_helper
DEBUG - 2011-06-05 12:11:07 --> File loaded: application/views/common/header.php
DEBUG - 2011-06-05 12:11:07 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-06-05 12:11:07 --> File loaded: application/views/common/footer.php
DEBUG - 2011-06-05 12:11:07 --> File loaded: application/views/layout/main.php
DEBUG - 2011-06-05 12:11:07 --> Final output sent to browser
DEBUG - 2011-06-05 12:11:07 --> Total execution time: 0.3248
DEBUG - 2011-06-05 13:00:51 --> Config Class Initialized
DEBUG - 2011-06-05 13:00:51 --> Hooks Class Initialized
DEBUG - 2011-06-05 13:00:51 --> Utf8 Class Initialized
DEBUG - 2011-06-05 13:00:51 --> UTF-8 Support Enabled
DEBUG - 2011-06-05 13:00:51 --> URI Class Initialized
DEBUG - 2011-06-05 13:00:51 --> Router Class Initialized
DEBUG - 2011-06-05 13:00:51 --> Output Class Initialized
DEBUG - 2011-06-05 13:00:51 --> Input Class Initialized
DEBUG - 2011-06-05 13:00:51 --> Global POST and COOKIE data sanitized
DEBUG - 2011-06-05 13:00:51 --> Language Class Initialized
DEBUG - 2011-06-05 13:00:51 --> Loader Class Initialized
DEBUG - 2011-06-05 13:00:51 --> Controller Class Initialized
ERROR - 2011-06-05 13:00:51 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-06-05 13:00:51 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-06-05 13:00:51 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-06-05 13:00:51 --> Model Class Initialized
DEBUG - 2011-06-05 13:00:51 --> Model Class Initialized
DEBUG - 2011-06-05 13:00:51 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-06-05 13:00:51 --> Database Driver Class Initialized
DEBUG - 2011-06-05 13:00:51 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-06-05 13:00:51 --> Helper loaded: url_helper
DEBUG - 2011-06-05 13:00:51 --> File loaded: application/views/common/header.php
DEBUG - 2011-06-05 13:00:51 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-06-05 13:00:51 --> File loaded: application/views/common/footer.php
DEBUG - 2011-06-05 13:00:51 --> File loaded: application/views/layout/main.php
DEBUG - 2011-06-05 13:00:51 --> Final output sent to browser
DEBUG - 2011-06-05 13:00:51 --> Total execution time: 0.4106
DEBUG - 2011-06-05 13:00:54 --> Config Class Initialized
DEBUG - 2011-06-05 13:00:54 --> Hooks Class Initialized
DEBUG - 2011-06-05 13:00:54 --> Utf8 Class Initialized
DEBUG - 2011-06-05 13:00:54 --> UTF-8 Support Enabled
DEBUG - 2011-06-05 13:00:54 --> URI Class Initialized
DEBUG - 2011-06-05 13:00:54 --> Router Class Initialized
DEBUG - 2011-06-05 13:00:54 --> Output Class Initialized
DEBUG - 2011-06-05 13:00:54 --> Input Class Initialized
DEBUG - 2011-06-05 13:00:54 --> Global POST and COOKIE data sanitized
DEBUG - 2011-06-05 13:00:54 --> Language Class Initialized
DEBUG - 2011-06-05 13:00:54 --> Loader Class Initialized
DEBUG - 2011-06-05 13:00:54 --> Controller Class Initialized
DEBUG - 2011-06-05 13:00:54 --> Model Class Initialized
DEBUG - 2011-06-05 13:00:54 --> Model Class Initialized
DEBUG - 2011-06-05 13:00:54 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-06-05 13:00:54 --> Database Driver Class Initialized
DEBUG - 2011-06-05 13:00:55 --> Final output sent to browser
DEBUG - 2011-06-05 13:00:55 --> Total execution time: 1.0295
DEBUG - 2011-06-05 13:01:03 --> Config Class Initialized
DEBUG - 2011-06-05 13:01:03 --> Hooks Class Initialized
DEBUG - 2011-06-05 13:01:03 --> Utf8 Class Initialized
DEBUG - 2011-06-05 13:01:03 --> UTF-8 Support Enabled
DEBUG - 2011-06-05 13:01:03 --> URI Class Initialized
DEBUG - 2011-06-05 13:01:03 --> Router Class Initialized
ERROR - 2011-06-05 13:01:03 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-06-05 13:01:37 --> Config Class Initialized
DEBUG - 2011-06-05 13:01:37 --> Hooks Class Initialized
DEBUG - 2011-06-05 13:01:37 --> Utf8 Class Initialized
DEBUG - 2011-06-05 13:01:37 --> UTF-8 Support Enabled
DEBUG - 2011-06-05 13:01:37 --> URI Class Initialized
DEBUG - 2011-06-05 13:01:37 --> Router Class Initialized
DEBUG - 2011-06-05 13:01:37 --> Output Class Initialized
DEBUG - 2011-06-05 13:01:37 --> Input Class Initialized
DEBUG - 2011-06-05 13:01:37 --> Global POST and COOKIE data sanitized
DEBUG - 2011-06-05 13:01:37 --> Language Class Initialized
DEBUG - 2011-06-05 13:01:37 --> Loader Class Initialized
DEBUG - 2011-06-05 13:01:37 --> Controller Class Initialized
ERROR - 2011-06-05 13:01:37 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-06-05 13:01:37 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-06-05 13:01:37 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-06-05 13:01:37 --> Model Class Initialized
DEBUG - 2011-06-05 13:01:37 --> Model Class Initialized
DEBUG - 2011-06-05 13:01:37 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-06-05 13:01:37 --> Database Driver Class Initialized
DEBUG - 2011-06-05 13:01:37 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-06-05 13:01:37 --> Helper loaded: url_helper
DEBUG - 2011-06-05 13:01:37 --> File loaded: application/views/common/header.php
DEBUG - 2011-06-05 13:01:37 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-06-05 13:01:37 --> File loaded: application/views/common/footer.php
DEBUG - 2011-06-05 13:01:37 --> File loaded: application/views/layout/main.php
DEBUG - 2011-06-05 13:01:37 --> Final output sent to browser
DEBUG - 2011-06-05 13:01:37 --> Total execution time: 0.0304
DEBUG - 2011-06-05 13:01:38 --> Config Class Initialized
DEBUG - 2011-06-05 13:01:38 --> Hooks Class Initialized
DEBUG - 2011-06-05 13:01:38 --> Utf8 Class Initialized
DEBUG - 2011-06-05 13:01:38 --> UTF-8 Support Enabled
DEBUG - 2011-06-05 13:01:38 --> URI Class Initialized
DEBUG - 2011-06-05 13:01:38 --> Router Class Initialized
DEBUG - 2011-06-05 13:01:38 --> Output Class Initialized
DEBUG - 2011-06-05 13:01:38 --> Input Class Initialized
DEBUG - 2011-06-05 13:01:38 --> Global POST and COOKIE data sanitized
DEBUG - 2011-06-05 13:01:38 --> Language Class Initialized
DEBUG - 2011-06-05 13:01:38 --> Loader Class Initialized
DEBUG - 2011-06-05 13:01:38 --> Controller Class Initialized
ERROR - 2011-06-05 13:01:38 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-06-05 13:01:38 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-06-05 13:01:38 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-06-05 13:01:38 --> Model Class Initialized
DEBUG - 2011-06-05 13:01:38 --> Model Class Initialized
DEBUG - 2011-06-05 13:01:38 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-06-05 13:01:38 --> Database Driver Class Initialized
DEBUG - 2011-06-05 13:01:38 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-06-05 13:01:38 --> Helper loaded: url_helper
DEBUG - 2011-06-05 13:01:38 --> File loaded: application/views/common/header.php
DEBUG - 2011-06-05 13:01:38 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-06-05 13:01:38 --> File loaded: application/views/common/footer.php
DEBUG - 2011-06-05 13:01:38 --> File loaded: application/views/layout/main.php
DEBUG - 2011-06-05 13:01:38 --> Final output sent to browser
DEBUG - 2011-06-05 13:01:38 --> Total execution time: 0.0377
DEBUG - 2011-06-05 13:01:39 --> Config Class Initialized
DEBUG - 2011-06-05 13:01:39 --> Hooks Class Initialized
DEBUG - 2011-06-05 13:01:39 --> Utf8 Class Initialized
DEBUG - 2011-06-05 13:01:39 --> UTF-8 Support Enabled
DEBUG - 2011-06-05 13:01:39 --> URI Class Initialized
DEBUG - 2011-06-05 13:01:39 --> Router Class Initialized
DEBUG - 2011-06-05 13:01:39 --> Output Class Initialized
DEBUG - 2011-06-05 13:01:39 --> Input Class Initialized
DEBUG - 2011-06-05 13:01:39 --> Global POST and COOKIE data sanitized
DEBUG - 2011-06-05 13:01:39 --> Language Class Initialized
DEBUG - 2011-06-05 13:01:39 --> Loader Class Initialized
DEBUG - 2011-06-05 13:01:39 --> Controller Class Initialized
DEBUG - 2011-06-05 13:01:39 --> Model Class Initialized
DEBUG - 2011-06-05 13:01:39 --> Model Class Initialized
DEBUG - 2011-06-05 13:01:39 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-06-05 13:01:39 --> Database Driver Class Initialized
DEBUG - 2011-06-05 13:01:39 --> Final output sent to browser
DEBUG - 2011-06-05 13:01:39 --> Total execution time: 0.6605
DEBUG - 2011-06-05 13:01:51 --> Config Class Initialized
DEBUG - 2011-06-05 13:01:51 --> Hooks Class Initialized
DEBUG - 2011-06-05 13:01:51 --> Utf8 Class Initialized
DEBUG - 2011-06-05 13:01:51 --> UTF-8 Support Enabled
DEBUG - 2011-06-05 13:01:51 --> URI Class Initialized
DEBUG - 2011-06-05 13:01:51 --> Router Class Initialized
DEBUG - 2011-06-05 13:01:51 --> Output Class Initialized
DEBUG - 2011-06-05 13:01:51 --> Input Class Initialized
DEBUG - 2011-06-05 13:01:51 --> Global POST and COOKIE data sanitized
DEBUG - 2011-06-05 13:01:51 --> Language Class Initialized
DEBUG - 2011-06-05 13:01:51 --> Loader Class Initialized
DEBUG - 2011-06-05 13:01:51 --> Controller Class Initialized
ERROR - 2011-06-05 13:01:51 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-06-05 13:01:51 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-06-05 13:01:51 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-06-05 13:01:51 --> Model Class Initialized
DEBUG - 2011-06-05 13:01:51 --> Model Class Initialized
DEBUG - 2011-06-05 13:01:51 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-06-05 13:01:51 --> Database Driver Class Initialized
DEBUG - 2011-06-05 13:01:51 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-06-05 13:01:51 --> Helper loaded: url_helper
DEBUG - 2011-06-05 13:01:51 --> File loaded: application/views/common/header.php
DEBUG - 2011-06-05 13:01:51 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-06-05 13:01:51 --> File loaded: application/views/common/footer.php
DEBUG - 2011-06-05 13:01:51 --> File loaded: application/views/layout/main.php
DEBUG - 2011-06-05 13:01:51 --> Final output sent to browser
DEBUG - 2011-06-05 13:01:51 --> Total execution time: 0.0302
DEBUG - 2011-06-05 13:01:52 --> Config Class Initialized
DEBUG - 2011-06-05 13:01:52 --> Hooks Class Initialized
DEBUG - 2011-06-05 13:01:52 --> Utf8 Class Initialized
DEBUG - 2011-06-05 13:01:52 --> UTF-8 Support Enabled
DEBUG - 2011-06-05 13:01:52 --> URI Class Initialized
DEBUG - 2011-06-05 13:01:52 --> Router Class Initialized
ERROR - 2011-06-05 13:01:52 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-06-05 13:01:53 --> Config Class Initialized
DEBUG - 2011-06-05 13:01:53 --> Hooks Class Initialized
DEBUG - 2011-06-05 13:01:53 --> Utf8 Class Initialized
DEBUG - 2011-06-05 13:01:53 --> UTF-8 Support Enabled
DEBUG - 2011-06-05 13:01:53 --> URI Class Initialized
DEBUG - 2011-06-05 13:01:53 --> Router Class Initialized
DEBUG - 2011-06-05 13:01:53 --> Output Class Initialized
DEBUG - 2011-06-05 13:01:53 --> Input Class Initialized
DEBUG - 2011-06-05 13:01:53 --> Global POST and COOKIE data sanitized
DEBUG - 2011-06-05 13:01:53 --> Language Class Initialized
DEBUG - 2011-06-05 13:01:53 --> Loader Class Initialized
DEBUG - 2011-06-05 13:01:53 --> Controller Class Initialized
DEBUG - 2011-06-05 13:01:53 --> Model Class Initialized
DEBUG - 2011-06-05 13:01:53 --> Model Class Initialized
DEBUG - 2011-06-05 13:01:53 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-06-05 13:01:53 --> Database Driver Class Initialized
DEBUG - 2011-06-05 13:01:53 --> Config Class Initialized
DEBUG - 2011-06-05 13:01:53 --> Hooks Class Initialized
DEBUG - 2011-06-05 13:01:53 --> Utf8 Class Initialized
DEBUG - 2011-06-05 13:01:53 --> UTF-8 Support Enabled
DEBUG - 2011-06-05 13:01:53 --> URI Class Initialized
DEBUG - 2011-06-05 13:01:53 --> Router Class Initialized
DEBUG - 2011-06-05 13:01:53 --> Output Class Initialized
DEBUG - 2011-06-05 13:01:53 --> Input Class Initialized
DEBUG - 2011-06-05 13:01:53 --> Global POST and COOKIE data sanitized
DEBUG - 2011-06-05 13:01:53 --> Language Class Initialized
DEBUG - 2011-06-05 13:01:53 --> Loader Class Initialized
DEBUG - 2011-06-05 13:01:53 --> Controller Class Initialized
ERROR - 2011-06-05 13:01:53 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-06-05 13:01:53 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-06-05 13:01:53 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-06-05 13:01:53 --> Model Class Initialized
DEBUG - 2011-06-05 13:01:53 --> Model Class Initialized
DEBUG - 2011-06-05 13:01:53 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-06-05 13:01:53 --> Database Driver Class Initialized
DEBUG - 2011-06-05 13:01:53 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-06-05 13:01:53 --> Helper loaded: url_helper
DEBUG - 2011-06-05 13:01:53 --> File loaded: application/views/common/header.php
DEBUG - 2011-06-05 13:01:53 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-06-05 13:01:53 --> File loaded: application/views/common/footer.php
DEBUG - 2011-06-05 13:01:53 --> File loaded: application/views/layout/main.php
DEBUG - 2011-06-05 13:01:53 --> Final output sent to browser
DEBUG - 2011-06-05 13:01:53 --> Total execution time: 0.0294
DEBUG - 2011-06-05 13:01:53 --> Final output sent to browser
DEBUG - 2011-06-05 13:01:53 --> Total execution time: 0.7037
DEBUG - 2011-06-05 13:02:00 --> Config Class Initialized
DEBUG - 2011-06-05 13:02:00 --> Hooks Class Initialized
DEBUG - 2011-06-05 13:02:00 --> Utf8 Class Initialized
DEBUG - 2011-06-05 13:02:00 --> UTF-8 Support Enabled
DEBUG - 2011-06-05 13:02:00 --> URI Class Initialized
DEBUG - 2011-06-05 13:02:00 --> Router Class Initialized
ERROR - 2011-06-05 13:02:00 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-06-05 13:44:43 --> Config Class Initialized
DEBUG - 2011-06-05 13:44:43 --> Hooks Class Initialized
DEBUG - 2011-06-05 13:44:44 --> Utf8 Class Initialized
DEBUG - 2011-06-05 13:44:44 --> UTF-8 Support Enabled
DEBUG - 2011-06-05 13:44:44 --> URI Class Initialized
DEBUG - 2011-06-05 13:44:44 --> Router Class Initialized
DEBUG - 2011-06-05 13:44:44 --> Output Class Initialized
DEBUG - 2011-06-05 13:44:44 --> Input Class Initialized
DEBUG - 2011-06-05 13:44:44 --> Global POST and COOKIE data sanitized
DEBUG - 2011-06-05 13:44:44 --> Language Class Initialized
DEBUG - 2011-06-05 13:44:44 --> Loader Class Initialized
DEBUG - 2011-06-05 13:44:44 --> Controller Class Initialized
ERROR - 2011-06-05 13:44:44 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-06-05 13:44:44 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-06-05 13:44:44 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-06-05 13:44:44 --> Model Class Initialized
DEBUG - 2011-06-05 13:44:44 --> Model Class Initialized
DEBUG - 2011-06-05 13:44:44 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-06-05 13:44:44 --> Database Driver Class Initialized
DEBUG - 2011-06-05 13:44:44 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-06-05 13:44:44 --> Helper loaded: url_helper
DEBUG - 2011-06-05 13:44:44 --> File loaded: application/views/common/header.php
DEBUG - 2011-06-05 13:44:44 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-06-05 13:44:44 --> File loaded: application/views/common/footer.php
DEBUG - 2011-06-05 13:44:44 --> File loaded: application/views/layout/main.php
DEBUG - 2011-06-05 13:44:44 --> Final output sent to browser
DEBUG - 2011-06-05 13:44:44 --> Total execution time: 0.9610
DEBUG - 2011-06-05 16:09:02 --> Config Class Initialized
DEBUG - 2011-06-05 16:09:02 --> Hooks Class Initialized
DEBUG - 2011-06-05 16:09:02 --> Utf8 Class Initialized
DEBUG - 2011-06-05 16:09:02 --> UTF-8 Support Enabled
DEBUG - 2011-06-05 16:09:02 --> URI Class Initialized
DEBUG - 2011-06-05 16:09:02 --> Router Class Initialized
DEBUG - 2011-06-05 16:09:02 --> Output Class Initialized
DEBUG - 2011-06-05 16:09:02 --> Input Class Initialized
DEBUG - 2011-06-05 16:09:02 --> Global POST and COOKIE data sanitized
DEBUG - 2011-06-05 16:09:02 --> Language Class Initialized
DEBUG - 2011-06-05 16:09:02 --> Loader Class Initialized
DEBUG - 2011-06-05 16:09:02 --> Controller Class Initialized
ERROR - 2011-06-05 16:09:02 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-06-05 16:09:02 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-06-05 16:09:02 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-06-05 16:09:02 --> Model Class Initialized
DEBUG - 2011-06-05 16:09:02 --> Model Class Initialized
DEBUG - 2011-06-05 16:09:02 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-06-05 16:09:02 --> Database Driver Class Initialized
DEBUG - 2011-06-05 16:09:03 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-06-05 16:09:03 --> Helper loaded: url_helper
DEBUG - 2011-06-05 16:09:03 --> File loaded: application/views/common/header.php
DEBUG - 2011-06-05 16:09:03 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-06-05 16:09:03 --> File loaded: application/views/common/footer.php
DEBUG - 2011-06-05 16:09:03 --> File loaded: application/views/layout/main.php
DEBUG - 2011-06-05 16:09:03 --> Final output sent to browser
DEBUG - 2011-06-05 16:09:03 --> Total execution time: 0.8395
DEBUG - 2011-06-05 16:09:04 --> Config Class Initialized
DEBUG - 2011-06-05 16:09:04 --> Hooks Class Initialized
DEBUG - 2011-06-05 16:09:04 --> Utf8 Class Initialized
DEBUG - 2011-06-05 16:09:04 --> UTF-8 Support Enabled
DEBUG - 2011-06-05 16:09:04 --> URI Class Initialized
DEBUG - 2011-06-05 16:09:04 --> Router Class Initialized
DEBUG - 2011-06-05 16:09:04 --> Output Class Initialized
DEBUG - 2011-06-05 16:09:04 --> Input Class Initialized
DEBUG - 2011-06-05 16:09:04 --> Global POST and COOKIE data sanitized
DEBUG - 2011-06-05 16:09:04 --> Language Class Initialized
DEBUG - 2011-06-05 16:09:04 --> Loader Class Initialized
DEBUG - 2011-06-05 16:09:04 --> Controller Class Initialized
ERROR - 2011-06-05 16:09:04 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-06-05 16:09:04 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-06-05 16:09:04 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-06-05 16:09:04 --> Model Class Initialized
DEBUG - 2011-06-05 16:09:04 --> Model Class Initialized
DEBUG - 2011-06-05 16:09:04 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-06-05 16:09:04 --> Database Driver Class Initialized
DEBUG - 2011-06-05 16:09:04 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-06-05 16:09:04 --> Helper loaded: url_helper
DEBUG - 2011-06-05 16:09:04 --> File loaded: application/views/common/header.php
DEBUG - 2011-06-05 16:09:04 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-06-05 16:09:04 --> File loaded: application/views/common/footer.php
DEBUG - 2011-06-05 16:09:04 --> File loaded: application/views/layout/main.php
DEBUG - 2011-06-05 16:09:04 --> Final output sent to browser
DEBUG - 2011-06-05 16:09:04 --> Total execution time: 0.0281
DEBUG - 2011-06-05 16:23:26 --> Config Class Initialized
DEBUG - 2011-06-05 16:23:26 --> Hooks Class Initialized
DEBUG - 2011-06-05 16:23:26 --> Utf8 Class Initialized
DEBUG - 2011-06-05 16:23:26 --> UTF-8 Support Enabled
DEBUG - 2011-06-05 16:23:26 --> URI Class Initialized
DEBUG - 2011-06-05 16:23:26 --> Router Class Initialized
ERROR - 2011-06-05 16:23:26 --> 404 Page Not Found --> robots.txt
DEBUG - 2011-06-05 16:24:13 --> Config Class Initialized
DEBUG - 2011-06-05 16:24:13 --> Hooks Class Initialized
DEBUG - 2011-06-05 16:24:13 --> Utf8 Class Initialized
DEBUG - 2011-06-05 16:24:13 --> UTF-8 Support Enabled
DEBUG - 2011-06-05 16:24:13 --> URI Class Initialized
DEBUG - 2011-06-05 16:24:14 --> Router Class Initialized
DEBUG - 2011-06-05 16:24:14 --> Output Class Initialized
DEBUG - 2011-06-05 16:24:14 --> Input Class Initialized
DEBUG - 2011-06-05 16:24:14 --> Global POST and COOKIE data sanitized
DEBUG - 2011-06-05 16:24:14 --> Language Class Initialized
DEBUG - 2011-06-05 16:24:14 --> Loader Class Initialized
DEBUG - 2011-06-05 16:24:14 --> Controller Class Initialized
DEBUG - 2011-06-05 16:24:14 --> Model Class Initialized
DEBUG - 2011-06-05 16:24:14 --> Model Class Initialized
DEBUG - 2011-06-05 16:24:14 --> Model Class Initialized
DEBUG - 2011-06-05 16:24:14 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-06-05 16:24:14 --> Database Driver Class Initialized
DEBUG - 2011-06-05 16:24:14 --> File loaded: application/views/table/main.php
DEBUG - 2011-06-05 16:24:14 --> Helper loaded: url_helper
DEBUG - 2011-06-05 16:24:14 --> File loaded: application/views/common/header.php
DEBUG - 2011-06-05 16:24:14 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-06-05 16:24:14 --> File loaded: application/views/common/footer.php
DEBUG - 2011-06-05 16:24:14 --> File loaded: application/views/layout/main.php
DEBUG - 2011-06-05 16:24:14 --> Final output sent to browser
DEBUG - 2011-06-05 16:24:14 --> Total execution time: 0.7344
DEBUG - 2011-06-05 16:28:26 --> Config Class Initialized
DEBUG - 2011-06-05 16:28:26 --> Hooks Class Initialized
DEBUG - 2011-06-05 16:28:26 --> Utf8 Class Initialized
DEBUG - 2011-06-05 16:28:26 --> UTF-8 Support Enabled
DEBUG - 2011-06-05 16:28:26 --> URI Class Initialized
DEBUG - 2011-06-05 16:28:26 --> Router Class Initialized
DEBUG - 2011-06-05 16:28:26 --> Output Class Initialized
DEBUG - 2011-06-05 16:28:26 --> Input Class Initialized
DEBUG - 2011-06-05 16:28:26 --> Global POST and COOKIE data sanitized
DEBUG - 2011-06-05 16:28:26 --> Language Class Initialized
DEBUG - 2011-06-05 16:28:26 --> Loader Class Initialized
DEBUG - 2011-06-05 16:28:26 --> Controller Class Initialized
DEBUG - 2011-06-05 16:28:26 --> Model Class Initialized
DEBUG - 2011-06-05 16:28:26 --> Model Class Initialized
DEBUG - 2011-06-05 16:28:26 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-06-05 16:28:26 --> Database Driver Class Initialized
DEBUG - 2011-06-05 16:28:26 --> Final output sent to browser
DEBUG - 2011-06-05 16:28:26 --> Total execution time: 0.7201
DEBUG - 2011-06-05 17:28:33 --> Config Class Initialized
DEBUG - 2011-06-05 17:28:33 --> Hooks Class Initialized
DEBUG - 2011-06-05 17:28:33 --> Utf8 Class Initialized
DEBUG - 2011-06-05 17:28:33 --> UTF-8 Support Enabled
DEBUG - 2011-06-05 17:28:33 --> URI Class Initialized
DEBUG - 2011-06-05 17:28:33 --> Router Class Initialized
DEBUG - 2011-06-05 17:28:34 --> Output Class Initialized
DEBUG - 2011-06-05 17:28:34 --> Input Class Initialized
DEBUG - 2011-06-05 17:28:34 --> Global POST and COOKIE data sanitized
DEBUG - 2011-06-05 17:28:34 --> Language Class Initialized
DEBUG - 2011-06-05 17:28:34 --> Loader Class Initialized
DEBUG - 2011-06-05 17:28:34 --> Controller Class Initialized
DEBUG - 2011-06-05 17:28:34 --> Model Class Initialized
DEBUG - 2011-06-05 17:28:34 --> Model Class Initialized
DEBUG - 2011-06-05 17:28:34 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-06-05 17:28:34 --> Database Driver Class Initialized
DEBUG - 2011-06-05 17:28:34 --> Final output sent to browser
DEBUG - 2011-06-05 17:28:34 --> Total execution time: 0.8118
DEBUG - 2011-06-05 19:11:53 --> Config Class Initialized
DEBUG - 2011-06-05 19:11:53 --> Hooks Class Initialized
DEBUG - 2011-06-05 19:11:53 --> Utf8 Class Initialized
DEBUG - 2011-06-05 19:11:53 --> UTF-8 Support Enabled
DEBUG - 2011-06-05 19:11:53 --> URI Class Initialized
DEBUG - 2011-06-05 19:11:53 --> Router Class Initialized
DEBUG - 2011-06-05 19:11:53 --> Output Class Initialized
DEBUG - 2011-06-05 19:11:53 --> Input Class Initialized
DEBUG - 2011-06-05 19:11:53 --> Global POST and COOKIE data sanitized
DEBUG - 2011-06-05 19:11:53 --> Language Class Initialized
DEBUG - 2011-06-05 19:11:54 --> Loader Class Initialized
DEBUG - 2011-06-05 19:11:54 --> Controller Class Initialized
ERROR - 2011-06-05 19:11:54 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-06-05 19:11:54 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-06-05 19:11:54 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-06-05 19:11:54 --> Model Class Initialized
DEBUG - 2011-06-05 19:11:54 --> Model Class Initialized
DEBUG - 2011-06-05 19:11:54 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-06-05 19:11:55 --> Database Driver Class Initialized
DEBUG - 2011-06-05 19:11:55 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-06-05 19:11:55 --> Helper loaded: url_helper
DEBUG - 2011-06-05 19:11:55 --> File loaded: application/views/common/header.php
DEBUG - 2011-06-05 19:11:55 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-06-05 19:11:55 --> File loaded: application/views/common/footer.php
DEBUG - 2011-06-05 19:11:55 --> File loaded: application/views/layout/main.php
DEBUG - 2011-06-05 19:11:55 --> Final output sent to browser
DEBUG - 2011-06-05 19:11:55 --> Total execution time: 3.5472
DEBUG - 2011-06-05 20:27:14 --> Config Class Initialized
DEBUG - 2011-06-05 20:27:14 --> Hooks Class Initialized
DEBUG - 2011-06-05 20:27:14 --> Utf8 Class Initialized
DEBUG - 2011-06-05 20:27:14 --> UTF-8 Support Enabled
DEBUG - 2011-06-05 20:27:14 --> URI Class Initialized
DEBUG - 2011-06-05 20:27:14 --> Router Class Initialized
DEBUG - 2011-06-05 20:27:14 --> Output Class Initialized
DEBUG - 2011-06-05 20:27:14 --> Input Class Initialized
DEBUG - 2011-06-05 20:27:14 --> Global POST and COOKIE data sanitized
DEBUG - 2011-06-05 20:27:14 --> Language Class Initialized
DEBUG - 2011-06-05 20:27:14 --> Loader Class Initialized
DEBUG - 2011-06-05 20:27:14 --> Controller Class Initialized
ERROR - 2011-06-05 20:27:14 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-06-05 20:27:14 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-06-05 20:27:14 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-06-05 20:27:14 --> Model Class Initialized
DEBUG - 2011-06-05 20:27:14 --> Model Class Initialized
DEBUG - 2011-06-05 20:27:14 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-06-05 20:27:14 --> Database Driver Class Initialized
DEBUG - 2011-06-05 20:27:15 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-06-05 20:27:15 --> Helper loaded: url_helper
DEBUG - 2011-06-05 20:27:15 --> File loaded: application/views/common/header.php
DEBUG - 2011-06-05 20:27:15 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-06-05 20:27:15 --> File loaded: application/views/common/footer.php
DEBUG - 2011-06-05 20:27:15 --> File loaded: application/views/layout/main.php
DEBUG - 2011-06-05 20:27:15 --> Final output sent to browser
DEBUG - 2011-06-05 20:27:15 --> Total execution time: 0.3191
DEBUG - 2011-06-05 20:27:20 --> Config Class Initialized
DEBUG - 2011-06-05 20:27:20 --> Hooks Class Initialized
DEBUG - 2011-06-05 20:27:20 --> Utf8 Class Initialized
DEBUG - 2011-06-05 20:27:20 --> UTF-8 Support Enabled
DEBUG - 2011-06-05 20:27:20 --> URI Class Initialized
DEBUG - 2011-06-05 20:27:20 --> Router Class Initialized
DEBUG - 2011-06-05 20:27:20 --> Output Class Initialized
DEBUG - 2011-06-05 20:27:20 --> Input Class Initialized
DEBUG - 2011-06-05 20:27:20 --> Global POST and COOKIE data sanitized
DEBUG - 2011-06-05 20:27:20 --> Language Class Initialized
DEBUG - 2011-06-05 20:27:20 --> Loader Class Initialized
DEBUG - 2011-06-05 20:27:20 --> Controller Class Initialized
DEBUG - 2011-06-05 20:27:20 --> Model Class Initialized
DEBUG - 2011-06-05 20:27:20 --> Model Class Initialized
DEBUG - 2011-06-05 20:27:20 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-06-05 20:27:20 --> Database Driver Class Initialized
DEBUG - 2011-06-05 20:27:21 --> Final output sent to browser
DEBUG - 2011-06-05 20:27:21 --> Total execution time: 0.7583
DEBUG - 2011-06-05 20:28:10 --> Config Class Initialized
DEBUG - 2011-06-05 20:28:10 --> Hooks Class Initialized
DEBUG - 2011-06-05 20:28:10 --> Utf8 Class Initialized
DEBUG - 2011-06-05 20:28:10 --> UTF-8 Support Enabled
DEBUG - 2011-06-05 20:28:10 --> URI Class Initialized
DEBUG - 2011-06-05 20:28:10 --> Router Class Initialized
DEBUG - 2011-06-05 20:28:10 --> Output Class Initialized
DEBUG - 2011-06-05 20:28:10 --> Input Class Initialized
DEBUG - 2011-06-05 20:28:10 --> Global POST and COOKIE data sanitized
DEBUG - 2011-06-05 20:28:10 --> Language Class Initialized
DEBUG - 2011-06-05 20:28:10 --> Loader Class Initialized
DEBUG - 2011-06-05 20:28:10 --> Controller Class Initialized
ERROR - 2011-06-05 20:28:10 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-06-05 20:28:10 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-06-05 20:28:10 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-06-05 20:28:10 --> Model Class Initialized
DEBUG - 2011-06-05 20:28:10 --> Model Class Initialized
DEBUG - 2011-06-05 20:28:10 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-06-05 20:28:10 --> Database Driver Class Initialized
DEBUG - 2011-06-05 20:28:10 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-06-05 20:28:10 --> Helper loaded: url_helper
DEBUG - 2011-06-05 20:28:10 --> File loaded: application/views/common/header.php
DEBUG - 2011-06-05 20:28:10 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-06-05 20:28:10 --> File loaded: application/views/common/footer.php
DEBUG - 2011-06-05 20:28:10 --> File loaded: application/views/layout/main.php
DEBUG - 2011-06-05 20:28:10 --> Final output sent to browser
DEBUG - 2011-06-05 20:28:10 --> Total execution time: 0.0394
DEBUG - 2011-06-05 20:28:12 --> Config Class Initialized
DEBUG - 2011-06-05 20:28:12 --> Hooks Class Initialized
DEBUG - 2011-06-05 20:28:12 --> Utf8 Class Initialized
DEBUG - 2011-06-05 20:28:12 --> UTF-8 Support Enabled
DEBUG - 2011-06-05 20:28:12 --> URI Class Initialized
DEBUG - 2011-06-05 20:28:12 --> Router Class Initialized
DEBUG - 2011-06-05 20:28:12 --> Output Class Initialized
DEBUG - 2011-06-05 20:28:12 --> Input Class Initialized
DEBUG - 2011-06-05 20:28:12 --> Global POST and COOKIE data sanitized
DEBUG - 2011-06-05 20:28:12 --> Language Class Initialized
DEBUG - 2011-06-05 20:28:12 --> Loader Class Initialized
DEBUG - 2011-06-05 20:28:12 --> Controller Class Initialized
DEBUG - 2011-06-05 20:28:12 --> Model Class Initialized
DEBUG - 2011-06-05 20:28:12 --> Model Class Initialized
DEBUG - 2011-06-05 20:28:12 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-06-05 20:28:12 --> Database Driver Class Initialized
DEBUG - 2011-06-05 20:28:13 --> Final output sent to browser
DEBUG - 2011-06-05 20:28:13 --> Total execution time: 0.6323
DEBUG - 2011-06-05 20:29:02 --> Config Class Initialized
DEBUG - 2011-06-05 20:29:02 --> Hooks Class Initialized
DEBUG - 2011-06-05 20:29:02 --> Utf8 Class Initialized
DEBUG - 2011-06-05 20:29:02 --> UTF-8 Support Enabled
DEBUG - 2011-06-05 20:29:02 --> URI Class Initialized
DEBUG - 2011-06-05 20:29:02 --> Router Class Initialized
DEBUG - 2011-06-05 20:29:02 --> Output Class Initialized
DEBUG - 2011-06-05 20:29:02 --> Input Class Initialized
DEBUG - 2011-06-05 20:29:02 --> Global POST and COOKIE data sanitized
DEBUG - 2011-06-05 20:29:02 --> Language Class Initialized
DEBUG - 2011-06-05 20:29:02 --> Loader Class Initialized
DEBUG - 2011-06-05 20:29:02 --> Controller Class Initialized
ERROR - 2011-06-05 20:29:02 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-06-05 20:29:02 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-06-05 20:29:02 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-06-05 20:29:02 --> Model Class Initialized
DEBUG - 2011-06-05 20:29:02 --> Model Class Initialized
DEBUG - 2011-06-05 20:29:02 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-06-05 20:29:02 --> Database Driver Class Initialized
DEBUG - 2011-06-05 20:29:02 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-06-05 20:29:02 --> Helper loaded: url_helper
DEBUG - 2011-06-05 20:29:02 --> File loaded: application/views/common/header.php
DEBUG - 2011-06-05 20:29:02 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-06-05 20:29:02 --> File loaded: application/views/common/footer.php
DEBUG - 2011-06-05 20:29:02 --> File loaded: application/views/layout/main.php
DEBUG - 2011-06-05 20:29:02 --> Final output sent to browser
DEBUG - 2011-06-05 20:29:02 --> Total execution time: 0.1562
DEBUG - 2011-06-05 20:29:06 --> Config Class Initialized
DEBUG - 2011-06-05 20:29:06 --> Hooks Class Initialized
DEBUG - 2011-06-05 20:29:06 --> Utf8 Class Initialized
DEBUG - 2011-06-05 20:29:06 --> UTF-8 Support Enabled
DEBUG - 2011-06-05 20:29:06 --> URI Class Initialized
DEBUG - 2011-06-05 20:29:06 --> Router Class Initialized
DEBUG - 2011-06-05 20:29:06 --> Output Class Initialized
DEBUG - 2011-06-05 20:29:06 --> Input Class Initialized
DEBUG - 2011-06-05 20:29:06 --> Global POST and COOKIE data sanitized
DEBUG - 2011-06-05 20:29:06 --> Language Class Initialized
DEBUG - 2011-06-05 20:29:06 --> Loader Class Initialized
DEBUG - 2011-06-05 20:29:06 --> Controller Class Initialized
ERROR - 2011-06-05 20:29:06 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-06-05 20:29:06 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-06-05 20:29:06 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-06-05 20:29:06 --> Model Class Initialized
DEBUG - 2011-06-05 20:29:06 --> Model Class Initialized
DEBUG - 2011-06-05 20:29:06 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-06-05 20:29:06 --> Database Driver Class Initialized
DEBUG - 2011-06-05 20:29:06 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-06-05 20:29:06 --> Helper loaded: url_helper
DEBUG - 2011-06-05 20:29:06 --> File loaded: application/views/common/header.php
DEBUG - 2011-06-05 20:29:06 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-06-05 20:29:06 --> File loaded: application/views/common/footer.php
DEBUG - 2011-06-05 20:29:06 --> File loaded: application/views/layout/main.php
DEBUG - 2011-06-05 20:29:06 --> Final output sent to browser
DEBUG - 2011-06-05 20:29:06 --> Total execution time: 0.1018
DEBUG - 2011-06-05 20:29:08 --> Config Class Initialized
DEBUG - 2011-06-05 20:29:08 --> Hooks Class Initialized
DEBUG - 2011-06-05 20:29:08 --> Utf8 Class Initialized
DEBUG - 2011-06-05 20:29:08 --> UTF-8 Support Enabled
DEBUG - 2011-06-05 20:29:08 --> URI Class Initialized
DEBUG - 2011-06-05 20:29:08 --> Router Class Initialized
DEBUG - 2011-06-05 20:29:08 --> Output Class Initialized
DEBUG - 2011-06-05 20:29:08 --> Input Class Initialized
DEBUG - 2011-06-05 20:29:08 --> Global POST and COOKIE data sanitized
DEBUG - 2011-06-05 20:29:08 --> Language Class Initialized
DEBUG - 2011-06-05 20:29:08 --> Loader Class Initialized
DEBUG - 2011-06-05 20:29:08 --> Controller Class Initialized
DEBUG - 2011-06-05 20:29:08 --> Model Class Initialized
DEBUG - 2011-06-05 20:29:08 --> Model Class Initialized
DEBUG - 2011-06-05 20:29:08 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-06-05 20:29:08 --> Database Driver Class Initialized
DEBUG - 2011-06-05 20:29:09 --> Final output sent to browser
DEBUG - 2011-06-05 20:29:09 --> Total execution time: 1.3116
DEBUG - 2011-06-05 20:29:41 --> Config Class Initialized
DEBUG - 2011-06-05 20:29:41 --> Hooks Class Initialized
DEBUG - 2011-06-05 20:29:41 --> Utf8 Class Initialized
DEBUG - 2011-06-05 20:29:41 --> UTF-8 Support Enabled
DEBUG - 2011-06-05 20:29:41 --> URI Class Initialized
DEBUG - 2011-06-05 20:29:41 --> Router Class Initialized
DEBUG - 2011-06-05 20:29:41 --> Output Class Initialized
DEBUG - 2011-06-05 20:29:41 --> Input Class Initialized
DEBUG - 2011-06-05 20:29:41 --> Global POST and COOKIE data sanitized
DEBUG - 2011-06-05 20:29:41 --> Language Class Initialized
DEBUG - 2011-06-05 20:29:41 --> Loader Class Initialized
DEBUG - 2011-06-05 20:29:41 --> Controller Class Initialized
ERROR - 2011-06-05 20:29:41 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-06-05 20:29:41 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-06-05 20:29:41 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-06-05 20:29:41 --> Model Class Initialized
DEBUG - 2011-06-05 20:29:41 --> Model Class Initialized
DEBUG - 2011-06-05 20:29:41 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-06-05 20:29:41 --> Database Driver Class Initialized
DEBUG - 2011-06-05 20:29:41 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-06-05 20:29:41 --> Helper loaded: url_helper
DEBUG - 2011-06-05 20:29:41 --> File loaded: application/views/common/header.php
DEBUG - 2011-06-05 20:29:41 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-06-05 20:29:41 --> File loaded: application/views/common/footer.php
DEBUG - 2011-06-05 20:29:41 --> File loaded: application/views/layout/main.php
DEBUG - 2011-06-05 20:29:41 --> Final output sent to browser
DEBUG - 2011-06-05 20:29:41 --> Total execution time: 0.0965
DEBUG - 2011-06-05 20:30:06 --> Config Class Initialized
DEBUG - 2011-06-05 20:30:06 --> Hooks Class Initialized
DEBUG - 2011-06-05 20:30:06 --> Utf8 Class Initialized
DEBUG - 2011-06-05 20:30:06 --> UTF-8 Support Enabled
DEBUG - 2011-06-05 20:30:06 --> URI Class Initialized
DEBUG - 2011-06-05 20:30:06 --> Router Class Initialized
DEBUG - 2011-06-05 20:30:06 --> Output Class Initialized
DEBUG - 2011-06-05 20:30:06 --> Input Class Initialized
DEBUG - 2011-06-05 20:30:06 --> Global POST and COOKIE data sanitized
DEBUG - 2011-06-05 20:30:06 --> Language Class Initialized
DEBUG - 2011-06-05 20:30:06 --> Loader Class Initialized
DEBUG - 2011-06-05 20:30:06 --> Controller Class Initialized
DEBUG - 2011-06-05 20:30:06 --> Model Class Initialized
DEBUG - 2011-06-05 20:30:06 --> Model Class Initialized
DEBUG - 2011-06-05 20:30:06 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-06-05 20:30:07 --> Database Driver Class Initialized
DEBUG - 2011-06-05 20:30:14 --> Final output sent to browser
DEBUG - 2011-06-05 20:30:14 --> Total execution time: 7.5423
DEBUG - 2011-06-05 20:30:29 --> Config Class Initialized
DEBUG - 2011-06-05 20:30:29 --> Hooks Class Initialized
DEBUG - 2011-06-05 20:30:29 --> Utf8 Class Initialized
DEBUG - 2011-06-05 20:30:29 --> UTF-8 Support Enabled
DEBUG - 2011-06-05 20:30:29 --> URI Class Initialized
DEBUG - 2011-06-05 20:30:29 --> Router Class Initialized
DEBUG - 2011-06-05 20:30:29 --> Output Class Initialized
DEBUG - 2011-06-05 20:30:29 --> Input Class Initialized
DEBUG - 2011-06-05 20:30:29 --> Global POST and COOKIE data sanitized
DEBUG - 2011-06-05 20:30:29 --> Language Class Initialized
DEBUG - 2011-06-05 20:30:29 --> Loader Class Initialized
DEBUG - 2011-06-05 20:30:29 --> Controller Class Initialized
ERROR - 2011-06-05 20:30:29 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-06-05 20:30:29 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-06-05 20:30:29 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-06-05 20:30:29 --> Model Class Initialized
DEBUG - 2011-06-05 20:30:29 --> Model Class Initialized
DEBUG - 2011-06-05 20:30:29 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-06-05 20:30:29 --> Database Driver Class Initialized
DEBUG - 2011-06-05 20:30:29 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-06-05 20:30:29 --> Helper loaded: url_helper
DEBUG - 2011-06-05 20:30:29 --> File loaded: application/views/common/header.php
DEBUG - 2011-06-05 20:30:29 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-06-05 20:30:29 --> File loaded: application/views/common/footer.php
DEBUG - 2011-06-05 20:30:29 --> File loaded: application/views/layout/main.php
DEBUG - 2011-06-05 20:30:29 --> Final output sent to browser
DEBUG - 2011-06-05 20:30:29 --> Total execution time: 0.0304
DEBUG - 2011-06-05 20:31:17 --> Config Class Initialized
DEBUG - 2011-06-05 20:31:17 --> Hooks Class Initialized
DEBUG - 2011-06-05 20:31:17 --> Utf8 Class Initialized
DEBUG - 2011-06-05 20:31:17 --> UTF-8 Support Enabled
DEBUG - 2011-06-05 20:31:17 --> URI Class Initialized
DEBUG - 2011-06-05 20:31:17 --> Router Class Initialized
DEBUG - 2011-06-05 20:31:17 --> Output Class Initialized
DEBUG - 2011-06-05 20:31:17 --> Input Class Initialized
DEBUG - 2011-06-05 20:31:17 --> Global POST and COOKIE data sanitized
DEBUG - 2011-06-05 20:31:17 --> Language Class Initialized
DEBUG - 2011-06-05 20:31:17 --> Loader Class Initialized
DEBUG - 2011-06-05 20:31:17 --> Controller Class Initialized
ERROR - 2011-06-05 20:31:17 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-06-05 20:31:17 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-06-05 20:31:17 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-06-05 20:31:17 --> Model Class Initialized
DEBUG - 2011-06-05 20:31:17 --> Model Class Initialized
DEBUG - 2011-06-05 20:31:17 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-06-05 20:31:17 --> Database Driver Class Initialized
DEBUG - 2011-06-05 20:31:17 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-06-05 20:31:17 --> Helper loaded: url_helper
DEBUG - 2011-06-05 20:31:17 --> File loaded: application/views/common/header.php
DEBUG - 2011-06-05 20:31:17 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-06-05 20:31:17 --> File loaded: application/views/common/footer.php
DEBUG - 2011-06-05 20:31:17 --> File loaded: application/views/layout/main.php
DEBUG - 2011-06-05 20:31:17 --> Final output sent to browser
DEBUG - 2011-06-05 20:31:17 --> Total execution time: 0.1239
DEBUG - 2011-06-05 20:31:23 --> Config Class Initialized
DEBUG - 2011-06-05 20:31:23 --> Hooks Class Initialized
DEBUG - 2011-06-05 20:31:23 --> Utf8 Class Initialized
DEBUG - 2011-06-05 20:31:23 --> UTF-8 Support Enabled
DEBUG - 2011-06-05 20:31:23 --> URI Class Initialized
DEBUG - 2011-06-05 20:31:23 --> Router Class Initialized
DEBUG - 2011-06-05 20:31:23 --> Output Class Initialized
DEBUG - 2011-06-05 20:31:23 --> Input Class Initialized
DEBUG - 2011-06-05 20:31:23 --> Global POST and COOKIE data sanitized
DEBUG - 2011-06-05 20:31:23 --> Language Class Initialized
DEBUG - 2011-06-05 20:31:23 --> Loader Class Initialized
DEBUG - 2011-06-05 20:31:23 --> Controller Class Initialized
DEBUG - 2011-06-05 20:31:23 --> Model Class Initialized
DEBUG - 2011-06-05 20:31:23 --> Model Class Initialized
DEBUG - 2011-06-05 20:31:23 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-06-05 20:31:23 --> Database Driver Class Initialized
DEBUG - 2011-06-05 20:31:23 --> Final output sent to browser
DEBUG - 2011-06-05 20:31:23 --> Total execution time: 0.5436
DEBUG - 2011-06-05 20:31:25 --> Config Class Initialized
DEBUG - 2011-06-05 20:31:25 --> Hooks Class Initialized
DEBUG - 2011-06-05 20:31:25 --> Utf8 Class Initialized
DEBUG - 2011-06-05 20:31:25 --> UTF-8 Support Enabled
DEBUG - 2011-06-05 20:31:25 --> URI Class Initialized
DEBUG - 2011-06-05 20:31:25 --> Router Class Initialized
DEBUG - 2011-06-05 20:31:25 --> Output Class Initialized
DEBUG - 2011-06-05 20:31:25 --> Input Class Initialized
DEBUG - 2011-06-05 20:31:25 --> Global POST and COOKIE data sanitized
DEBUG - 2011-06-05 20:31:25 --> Language Class Initialized
DEBUG - 2011-06-05 20:31:25 --> Loader Class Initialized
DEBUG - 2011-06-05 20:31:25 --> Controller Class Initialized
ERROR - 2011-06-05 20:31:25 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-06-05 20:31:25 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-06-05 20:31:25 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-06-05 20:31:25 --> Model Class Initialized
DEBUG - 2011-06-05 20:31:25 --> Model Class Initialized
DEBUG - 2011-06-05 20:31:25 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-06-05 20:31:25 --> Database Driver Class Initialized
DEBUG - 2011-06-05 20:31:25 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-06-05 20:31:25 --> Helper loaded: url_helper
DEBUG - 2011-06-05 20:31:25 --> File loaded: application/views/common/header.php
DEBUG - 2011-06-05 20:31:25 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-06-05 20:31:25 --> File loaded: application/views/common/footer.php
DEBUG - 2011-06-05 20:31:25 --> File loaded: application/views/layout/main.php
DEBUG - 2011-06-05 20:31:25 --> Final output sent to browser
DEBUG - 2011-06-05 20:31:25 --> Total execution time: 0.1456
DEBUG - 2011-06-05 20:32:07 --> Config Class Initialized
DEBUG - 2011-06-05 20:32:07 --> Hooks Class Initialized
DEBUG - 2011-06-05 20:32:07 --> Utf8 Class Initialized
DEBUG - 2011-06-05 20:32:07 --> UTF-8 Support Enabled
DEBUG - 2011-06-05 20:32:07 --> URI Class Initialized
DEBUG - 2011-06-05 20:32:07 --> Router Class Initialized
DEBUG - 2011-06-05 20:32:07 --> Output Class Initialized
DEBUG - 2011-06-05 20:32:07 --> Input Class Initialized
DEBUG - 2011-06-05 20:32:07 --> Global POST and COOKIE data sanitized
DEBUG - 2011-06-05 20:32:07 --> Language Class Initialized
DEBUG - 2011-06-05 20:32:07 --> Loader Class Initialized
DEBUG - 2011-06-05 20:32:07 --> Controller Class Initialized
ERROR - 2011-06-05 20:32:07 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-06-05 20:32:07 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-06-05 20:32:07 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-06-05 20:32:07 --> Model Class Initialized
DEBUG - 2011-06-05 20:32:07 --> Model Class Initialized
DEBUG - 2011-06-05 20:32:07 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-06-05 20:32:07 --> Database Driver Class Initialized
DEBUG - 2011-06-05 20:32:07 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-06-05 20:32:07 --> Helper loaded: url_helper
DEBUG - 2011-06-05 20:32:07 --> File loaded: application/views/common/header.php
DEBUG - 2011-06-05 20:32:07 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-06-05 20:32:07 --> File loaded: application/views/common/footer.php
DEBUG - 2011-06-05 20:32:07 --> File loaded: application/views/layout/main.php
DEBUG - 2011-06-05 20:32:07 --> Final output sent to browser
DEBUG - 2011-06-05 20:32:07 --> Total execution time: 0.0615
DEBUG - 2011-06-05 20:32:15 --> Config Class Initialized
DEBUG - 2011-06-05 20:32:15 --> Hooks Class Initialized
DEBUG - 2011-06-05 20:32:15 --> Utf8 Class Initialized
DEBUG - 2011-06-05 20:32:15 --> UTF-8 Support Enabled
DEBUG - 2011-06-05 20:32:15 --> URI Class Initialized
DEBUG - 2011-06-05 20:32:15 --> Router Class Initialized
DEBUG - 2011-06-05 20:32:15 --> Output Class Initialized
DEBUG - 2011-06-05 20:32:15 --> Input Class Initialized
DEBUG - 2011-06-05 20:32:15 --> Global POST and COOKIE data sanitized
DEBUG - 2011-06-05 20:32:15 --> Language Class Initialized
DEBUG - 2011-06-05 20:32:15 --> Loader Class Initialized
DEBUG - 2011-06-05 20:32:15 --> Controller Class Initialized
DEBUG - 2011-06-05 20:32:15 --> Model Class Initialized
DEBUG - 2011-06-05 20:32:15 --> Model Class Initialized
DEBUG - 2011-06-05 20:32:15 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-06-05 20:32:15 --> Database Driver Class Initialized
DEBUG - 2011-06-05 20:32:15 --> Final output sent to browser
DEBUG - 2011-06-05 20:32:15 --> Total execution time: 0.6836
DEBUG - 2011-06-05 20:33:42 --> Config Class Initialized
DEBUG - 2011-06-05 20:33:42 --> Hooks Class Initialized
DEBUG - 2011-06-05 20:33:42 --> Utf8 Class Initialized
DEBUG - 2011-06-05 20:33:42 --> UTF-8 Support Enabled
DEBUG - 2011-06-05 20:33:42 --> URI Class Initialized
DEBUG - 2011-06-05 20:33:42 --> Router Class Initialized
DEBUG - 2011-06-05 20:33:42 --> Output Class Initialized
DEBUG - 2011-06-05 20:33:42 --> Input Class Initialized
DEBUG - 2011-06-05 20:33:42 --> Global POST and COOKIE data sanitized
DEBUG - 2011-06-05 20:33:42 --> Language Class Initialized
DEBUG - 2011-06-05 20:33:42 --> Loader Class Initialized
DEBUG - 2011-06-05 20:33:42 --> Controller Class Initialized
ERROR - 2011-06-05 20:33:42 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-06-05 20:33:42 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-06-05 20:33:42 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-06-05 20:33:42 --> Model Class Initialized
DEBUG - 2011-06-05 20:33:42 --> Model Class Initialized
DEBUG - 2011-06-05 20:33:42 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-06-05 20:33:42 --> Database Driver Class Initialized
DEBUG - 2011-06-05 20:33:42 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-06-05 20:33:42 --> Helper loaded: url_helper
DEBUG - 2011-06-05 20:33:42 --> File loaded: application/views/common/header.php
DEBUG - 2011-06-05 20:33:42 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-06-05 20:33:42 --> File loaded: application/views/common/footer.php
DEBUG - 2011-06-05 20:33:42 --> File loaded: application/views/layout/main.php
DEBUG - 2011-06-05 20:33:42 --> Final output sent to browser
DEBUG - 2011-06-05 20:33:42 --> Total execution time: 0.0359
DEBUG - 2011-06-05 20:34:09 --> Config Class Initialized
DEBUG - 2011-06-05 20:34:09 --> Hooks Class Initialized
DEBUG - 2011-06-05 20:34:09 --> Utf8 Class Initialized
DEBUG - 2011-06-05 20:34:09 --> UTF-8 Support Enabled
DEBUG - 2011-06-05 20:34:09 --> URI Class Initialized
DEBUG - 2011-06-05 20:34:09 --> Router Class Initialized
DEBUG - 2011-06-05 20:34:09 --> Output Class Initialized
DEBUG - 2011-06-05 20:34:09 --> Input Class Initialized
DEBUG - 2011-06-05 20:34:09 --> Global POST and COOKIE data sanitized
DEBUG - 2011-06-05 20:34:09 --> Language Class Initialized
DEBUG - 2011-06-05 20:34:09 --> Loader Class Initialized
DEBUG - 2011-06-05 20:34:09 --> Controller Class Initialized
DEBUG - 2011-06-05 20:34:09 --> Model Class Initialized
DEBUG - 2011-06-05 20:34:09 --> Model Class Initialized
DEBUG - 2011-06-05 20:34:09 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-06-05 20:34:09 --> Database Driver Class Initialized
DEBUG - 2011-06-05 20:34:18 --> Final output sent to browser
DEBUG - 2011-06-05 20:34:18 --> Total execution time: 9.1842
DEBUG - 2011-06-05 20:34:36 --> Config Class Initialized
DEBUG - 2011-06-05 20:34:36 --> Hooks Class Initialized
DEBUG - 2011-06-05 20:34:36 --> Utf8 Class Initialized
DEBUG - 2011-06-05 20:34:36 --> UTF-8 Support Enabled
DEBUG - 2011-06-05 20:34:36 --> URI Class Initialized
DEBUG - 2011-06-05 20:34:36 --> Router Class Initialized
DEBUG - 2011-06-05 20:34:36 --> Output Class Initialized
DEBUG - 2011-06-05 20:34:36 --> Input Class Initialized
DEBUG - 2011-06-05 20:34:36 --> Global POST and COOKIE data sanitized
DEBUG - 2011-06-05 20:34:36 --> Language Class Initialized
DEBUG - 2011-06-05 20:34:36 --> Loader Class Initialized
DEBUG - 2011-06-05 20:34:36 --> Controller Class Initialized
ERROR - 2011-06-05 20:34:36 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-06-05 20:34:36 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-06-05 20:34:36 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-06-05 20:34:36 --> Model Class Initialized
DEBUG - 2011-06-05 20:34:36 --> Model Class Initialized
DEBUG - 2011-06-05 20:34:36 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-06-05 20:34:36 --> Database Driver Class Initialized
DEBUG - 2011-06-05 20:34:36 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-06-05 20:34:36 --> Helper loaded: url_helper
DEBUG - 2011-06-05 20:34:36 --> File loaded: application/views/common/header.php
DEBUG - 2011-06-05 20:34:36 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-06-05 20:34:36 --> File loaded: application/views/common/footer.php
DEBUG - 2011-06-05 20:34:36 --> File loaded: application/views/layout/main.php
DEBUG - 2011-06-05 20:34:36 --> Final output sent to browser
DEBUG - 2011-06-05 20:34:36 --> Total execution time: 0.0307
DEBUG - 2011-06-05 20:34:44 --> Config Class Initialized
DEBUG - 2011-06-05 20:34:44 --> Hooks Class Initialized
DEBUG - 2011-06-05 20:34:44 --> Utf8 Class Initialized
DEBUG - 2011-06-05 20:34:44 --> UTF-8 Support Enabled
DEBUG - 2011-06-05 20:34:44 --> URI Class Initialized
DEBUG - 2011-06-05 20:34:44 --> Router Class Initialized
DEBUG - 2011-06-05 20:34:44 --> Output Class Initialized
DEBUG - 2011-06-05 20:34:44 --> Input Class Initialized
DEBUG - 2011-06-05 20:34:44 --> Global POST and COOKIE data sanitized
DEBUG - 2011-06-05 20:34:44 --> Language Class Initialized
DEBUG - 2011-06-05 20:34:44 --> Loader Class Initialized
DEBUG - 2011-06-05 20:34:44 --> Controller Class Initialized
DEBUG - 2011-06-05 20:34:44 --> Model Class Initialized
DEBUG - 2011-06-05 20:34:44 --> Model Class Initialized
DEBUG - 2011-06-05 20:34:44 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-06-05 20:34:44 --> Database Driver Class Initialized
DEBUG - 2011-06-05 20:34:45 --> Final output sent to browser
DEBUG - 2011-06-05 20:34:45 --> Total execution time: 0.6253
DEBUG - 2011-06-05 20:35:06 --> Config Class Initialized
DEBUG - 2011-06-05 20:35:06 --> Hooks Class Initialized
DEBUG - 2011-06-05 20:35:06 --> Utf8 Class Initialized
DEBUG - 2011-06-05 20:35:06 --> UTF-8 Support Enabled
DEBUG - 2011-06-05 20:35:06 --> URI Class Initialized
DEBUG - 2011-06-05 20:35:06 --> Router Class Initialized
ERROR - 2011-06-05 20:35:06 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-06-05 22:02:05 --> Config Class Initialized
DEBUG - 2011-06-05 22:02:05 --> Hooks Class Initialized
DEBUG - 2011-06-05 22:02:05 --> Utf8 Class Initialized
DEBUG - 2011-06-05 22:02:05 --> UTF-8 Support Enabled
DEBUG - 2011-06-05 22:02:05 --> URI Class Initialized
DEBUG - 2011-06-05 22:02:05 --> Router Class Initialized
ERROR - 2011-06-05 22:02:05 --> 404 Page Not Found --> robots.txt
DEBUG - 2011-06-05 22:02:09 --> Config Class Initialized
DEBUG - 2011-06-05 22:02:09 --> Hooks Class Initialized
DEBUG - 2011-06-05 22:02:09 --> Utf8 Class Initialized
DEBUG - 2011-06-05 22:02:09 --> UTF-8 Support Enabled
DEBUG - 2011-06-05 22:02:09 --> URI Class Initialized
DEBUG - 2011-06-05 22:02:09 --> Router Class Initialized
DEBUG - 2011-06-05 22:02:09 --> No URI present. Default controller set.
DEBUG - 2011-06-05 22:02:09 --> Output Class Initialized
DEBUG - 2011-06-05 22:02:09 --> Input Class Initialized
DEBUG - 2011-06-05 22:02:09 --> Global POST and COOKIE data sanitized
DEBUG - 2011-06-05 22:02:09 --> Language Class Initialized
DEBUG - 2011-06-05 22:02:09 --> Loader Class Initialized
DEBUG - 2011-06-05 22:02:09 --> Controller Class Initialized
DEBUG - 2011-06-05 22:02:09 --> File loaded: application/views/splash/main.php
DEBUG - 2011-06-05 22:02:09 --> Helper loaded: url_helper
DEBUG - 2011-06-05 22:02:09 --> File loaded: application/views/common/header.php
DEBUG - 2011-06-05 22:02:09 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-06-05 22:02:09 --> File loaded: application/views/common/footer.php
DEBUG - 2011-06-05 22:02:09 --> File loaded: application/views/layout/main.php
DEBUG - 2011-06-05 22:02:09 --> Final output sent to browser
DEBUG - 2011-06-05 22:02:09 --> Total execution time: 0.2931
DEBUG - 2011-06-05 22:24:47 --> Config Class Initialized
DEBUG - 2011-06-05 22:24:47 --> Hooks Class Initialized
DEBUG - 2011-06-05 22:24:47 --> Utf8 Class Initialized
DEBUG - 2011-06-05 22:24:47 --> UTF-8 Support Enabled
DEBUG - 2011-06-05 22:24:47 --> URI Class Initialized
DEBUG - 2011-06-05 22:24:47 --> Router Class Initialized
DEBUG - 2011-06-05 22:24:48 --> Output Class Initialized
DEBUG - 2011-06-05 22:24:48 --> Input Class Initialized
DEBUG - 2011-06-05 22:24:48 --> Global POST and COOKIE data sanitized
DEBUG - 2011-06-05 22:24:48 --> Language Class Initialized
DEBUG - 2011-06-05 22:24:48 --> Loader Class Initialized
DEBUG - 2011-06-05 22:24:48 --> Controller Class Initialized
ERROR - 2011-06-05 22:24:48 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-06-05 22:24:48 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-06-05 22:24:48 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-06-05 22:24:48 --> Model Class Initialized
DEBUG - 2011-06-05 22:24:48 --> Model Class Initialized
DEBUG - 2011-06-05 22:24:48 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-06-05 22:24:48 --> Database Driver Class Initialized
DEBUG - 2011-06-05 22:24:48 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-06-05 22:24:48 --> Helper loaded: url_helper
DEBUG - 2011-06-05 22:24:48 --> File loaded: application/views/common/header.php
DEBUG - 2011-06-05 22:24:48 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-06-05 22:24:48 --> File loaded: application/views/common/footer.php
DEBUG - 2011-06-05 22:24:48 --> File loaded: application/views/layout/main.php
DEBUG - 2011-06-05 22:24:48 --> Final output sent to browser
DEBUG - 2011-06-05 22:24:48 --> Total execution time: 0.3084
DEBUG - 2011-06-05 22:24:48 --> Config Class Initialized
DEBUG - 2011-06-05 22:24:48 --> Hooks Class Initialized
DEBUG - 2011-06-05 22:24:48 --> Utf8 Class Initialized
DEBUG - 2011-06-05 22:24:48 --> UTF-8 Support Enabled
DEBUG - 2011-06-05 22:24:48 --> URI Class Initialized
DEBUG - 2011-06-05 22:24:48 --> Router Class Initialized
DEBUG - 2011-06-05 22:24:48 --> Output Class Initialized
DEBUG - 2011-06-05 22:24:48 --> Input Class Initialized
DEBUG - 2011-06-05 22:24:48 --> Global POST and COOKIE data sanitized
DEBUG - 2011-06-05 22:24:48 --> Language Class Initialized
DEBUG - 2011-06-05 22:24:48 --> Loader Class Initialized
DEBUG - 2011-06-05 22:24:48 --> Controller Class Initialized
DEBUG - 2011-06-05 22:24:48 --> Model Class Initialized
DEBUG - 2011-06-05 22:24:48 --> Model Class Initialized
DEBUG - 2011-06-05 22:24:48 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-06-05 22:24:48 --> Database Driver Class Initialized
DEBUG - 2011-06-05 22:24:49 --> Final output sent to browser
DEBUG - 2011-06-05 22:24:49 --> Total execution time: 0.7220
DEBUG - 2011-06-05 22:24:50 --> Config Class Initialized
DEBUG - 2011-06-05 22:24:50 --> Hooks Class Initialized
DEBUG - 2011-06-05 22:24:50 --> Utf8 Class Initialized
DEBUG - 2011-06-05 22:24:50 --> UTF-8 Support Enabled
DEBUG - 2011-06-05 22:24:50 --> URI Class Initialized
DEBUG - 2011-06-05 22:24:50 --> Router Class Initialized
ERROR - 2011-06-05 22:24:50 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-06-05 23:51:14 --> Config Class Initialized
DEBUG - 2011-06-05 23:51:14 --> Hooks Class Initialized
DEBUG - 2011-06-05 23:51:14 --> Utf8 Class Initialized
DEBUG - 2011-06-05 23:51:14 --> UTF-8 Support Enabled
DEBUG - 2011-06-05 23:51:14 --> URI Class Initialized
DEBUG - 2011-06-05 23:51:14 --> Router Class Initialized
DEBUG - 2011-06-05 23:51:14 --> Output Class Initialized
DEBUG - 2011-06-05 23:51:14 --> Input Class Initialized
DEBUG - 2011-06-05 23:51:14 --> Global POST and COOKIE data sanitized
DEBUG - 2011-06-05 23:51:14 --> Language Class Initialized
DEBUG - 2011-06-05 23:51:14 --> Loader Class Initialized
DEBUG - 2011-06-05 23:51:14 --> Controller Class Initialized
ERROR - 2011-06-05 23:51:14 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-06-05 23:51:14 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-06-05 23:51:14 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-06-05 23:51:14 --> Model Class Initialized
DEBUG - 2011-06-05 23:51:14 --> Model Class Initialized
DEBUG - 2011-06-05 23:51:14 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-06-05 23:51:14 --> Database Driver Class Initialized
DEBUG - 2011-06-05 23:51:14 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-06-05 23:51:14 --> Helper loaded: url_helper
DEBUG - 2011-06-05 23:51:14 --> File loaded: application/views/common/header.php
DEBUG - 2011-06-05 23:51:14 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-06-05 23:51:15 --> File loaded: application/views/common/footer.php
DEBUG - 2011-06-05 23:51:15 --> File loaded: application/views/layout/main.php
DEBUG - 2011-06-05 23:51:15 --> Final output sent to browser
DEBUG - 2011-06-05 23:51:15 --> Total execution time: 0.5077
DEBUG - 2011-06-05 23:51:15 --> Config Class Initialized
DEBUG - 2011-06-05 23:51:15 --> Hooks Class Initialized
DEBUG - 2011-06-05 23:51:15 --> Utf8 Class Initialized
DEBUG - 2011-06-05 23:51:15 --> UTF-8 Support Enabled
DEBUG - 2011-06-05 23:51:15 --> URI Class Initialized
DEBUG - 2011-06-05 23:51:15 --> Router Class Initialized
DEBUG - 2011-06-05 23:51:15 --> Output Class Initialized
DEBUG - 2011-06-05 23:51:15 --> Input Class Initialized
DEBUG - 2011-06-05 23:51:15 --> Global POST and COOKIE data sanitized
DEBUG - 2011-06-05 23:51:15 --> Language Class Initialized
DEBUG - 2011-06-05 23:51:15 --> Loader Class Initialized
DEBUG - 2011-06-05 23:51:15 --> Controller Class Initialized
DEBUG - 2011-06-05 23:51:15 --> Model Class Initialized
DEBUG - 2011-06-05 23:51:15 --> Model Class Initialized
DEBUG - 2011-06-05 23:51:15 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-06-05 23:51:15 --> Database Driver Class Initialized
DEBUG - 2011-06-05 23:51:16 --> Final output sent to browser
DEBUG - 2011-06-05 23:51:16 --> Total execution time: 0.6627
DEBUG - 2011-06-05 23:51:17 --> Config Class Initialized
DEBUG - 2011-06-05 23:51:17 --> Hooks Class Initialized
DEBUG - 2011-06-05 23:51:17 --> Utf8 Class Initialized
DEBUG - 2011-06-05 23:51:17 --> UTF-8 Support Enabled
DEBUG - 2011-06-05 23:51:17 --> URI Class Initialized
DEBUG - 2011-06-05 23:51:17 --> Router Class Initialized
ERROR - 2011-06-05 23:51:17 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-06-05 23:51:18 --> Config Class Initialized
DEBUG - 2011-06-05 23:51:18 --> Hooks Class Initialized
DEBUG - 2011-06-05 23:51:18 --> Utf8 Class Initialized
DEBUG - 2011-06-05 23:51:18 --> UTF-8 Support Enabled
DEBUG - 2011-06-05 23:51:18 --> URI Class Initialized
DEBUG - 2011-06-05 23:51:18 --> Router Class Initialized
ERROR - 2011-06-05 23:51:18 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-06-05 23:51:18 --> Config Class Initialized
DEBUG - 2011-06-05 23:51:18 --> Hooks Class Initialized
DEBUG - 2011-06-05 23:51:18 --> Utf8 Class Initialized
DEBUG - 2011-06-05 23:51:18 --> UTF-8 Support Enabled
DEBUG - 2011-06-05 23:51:18 --> URI Class Initialized
DEBUG - 2011-06-05 23:51:18 --> Router Class Initialized
ERROR - 2011-06-05 23:51:18 --> 404 Page Not Found --> favicon.ico

<?php  if ( ! defined('BASEPATH')) exit('No direct script access allowed'); ?>

DEBUG - 2011-07-24 01:36:18 --> Config Class Initialized
DEBUG - 2011-07-24 01:36:18 --> Hooks Class Initialized
DEBUG - 2011-07-24 01:36:18 --> Utf8 Class Initialized
DEBUG - 2011-07-24 01:36:18 --> UTF-8 Support Enabled
DEBUG - 2011-07-24 01:36:18 --> URI Class Initialized
DEBUG - 2011-07-24 01:36:18 --> Router Class Initialized
DEBUG - 2011-07-24 01:36:18 --> No URI present. Default controller set.
DEBUG - 2011-07-24 01:36:18 --> Output Class Initialized
DEBUG - 2011-07-24 01:36:18 --> Input Class Initialized
DEBUG - 2011-07-24 01:36:18 --> Global POST and COOKIE data sanitized
DEBUG - 2011-07-24 01:36:18 --> Language Class Initialized
DEBUG - 2011-07-24 01:36:18 --> Loader Class Initialized
DEBUG - 2011-07-24 01:36:18 --> Controller Class Initialized
DEBUG - 2011-07-24 01:36:18 --> File loaded: application/views/splash/main.php
DEBUG - 2011-07-24 01:36:18 --> Helper loaded: url_helper
DEBUG - 2011-07-24 01:36:18 --> File loaded: application/views/common/header.php
DEBUG - 2011-07-24 01:36:18 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-07-24 01:36:18 --> File loaded: application/views/common/footer.php
DEBUG - 2011-07-24 01:36:18 --> File loaded: application/views/layout/main.php
DEBUG - 2011-07-24 01:36:18 --> Final output sent to browser
DEBUG - 2011-07-24 01:36:18 --> Total execution time: 0.1740
DEBUG - 2011-07-24 02:14:52 --> Config Class Initialized
DEBUG - 2011-07-24 02:14:52 --> Hooks Class Initialized
DEBUG - 2011-07-24 02:14:52 --> Utf8 Class Initialized
DEBUG - 2011-07-24 02:14:52 --> UTF-8 Support Enabled
DEBUG - 2011-07-24 02:14:52 --> URI Class Initialized
DEBUG - 2011-07-24 02:14:52 --> Router Class Initialized
DEBUG - 2011-07-24 02:14:52 --> Output Class Initialized
DEBUG - 2011-07-24 02:14:52 --> Input Class Initialized
DEBUG - 2011-07-24 02:14:52 --> Global POST and COOKIE data sanitized
DEBUG - 2011-07-24 02:14:52 --> Language Class Initialized
DEBUG - 2011-07-24 02:14:52 --> Loader Class Initialized
DEBUG - 2011-07-24 02:14:52 --> Controller Class Initialized
DEBUG - 2011-07-24 02:14:52 --> Model Class Initialized
DEBUG - 2011-07-24 02:14:52 --> Model Class Initialized
DEBUG - 2011-07-24 02:14:53 --> Model Class Initialized
DEBUG - 2011-07-24 02:14:53 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-07-24 02:14:53 --> Database Driver Class Initialized
DEBUG - 2011-07-24 02:14:53 --> File loaded: application/views/table/main.php
DEBUG - 2011-07-24 02:14:53 --> Helper loaded: url_helper
DEBUG - 2011-07-24 02:14:53 --> File loaded: application/views/common/header.php
DEBUG - 2011-07-24 02:14:53 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-07-24 02:14:53 --> File loaded: application/views/common/footer.php
DEBUG - 2011-07-24 02:14:53 --> File loaded: application/views/layout/main.php
DEBUG - 2011-07-24 02:14:53 --> Final output sent to browser
DEBUG - 2011-07-24 02:14:53 --> Total execution time: 0.6167
DEBUG - 2011-07-24 02:14:54 --> Config Class Initialized
DEBUG - 2011-07-24 02:14:54 --> Hooks Class Initialized
DEBUG - 2011-07-24 02:14:54 --> Utf8 Class Initialized
DEBUG - 2011-07-24 02:14:54 --> UTF-8 Support Enabled
DEBUG - 2011-07-24 02:14:54 --> URI Class Initialized
DEBUG - 2011-07-24 02:14:54 --> Router Class Initialized
DEBUG - 2011-07-24 02:14:54 --> Output Class Initialized
DEBUG - 2011-07-24 02:14:54 --> Input Class Initialized
DEBUG - 2011-07-24 02:14:54 --> Global POST and COOKIE data sanitized
DEBUG - 2011-07-24 02:14:54 --> Language Class Initialized
DEBUG - 2011-07-24 02:14:54 --> Loader Class Initialized
DEBUG - 2011-07-24 02:14:54 --> Controller Class Initialized
ERROR - 2011-07-24 02:14:54 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-07-24 02:14:54 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-07-24 02:14:54 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-07-24 02:14:54 --> Model Class Initialized
DEBUG - 2011-07-24 02:14:54 --> Model Class Initialized
DEBUG - 2011-07-24 02:14:54 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-07-24 02:14:54 --> Database Driver Class Initialized
DEBUG - 2011-07-24 02:14:54 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-07-24 02:14:54 --> Helper loaded: url_helper
DEBUG - 2011-07-24 02:14:54 --> File loaded: application/views/common/header.php
DEBUG - 2011-07-24 02:14:54 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-07-24 02:14:54 --> File loaded: application/views/common/footer.php
DEBUG - 2011-07-24 02:14:54 --> File loaded: application/views/layout/main.php
DEBUG - 2011-07-24 02:14:54 --> Final output sent to browser
DEBUG - 2011-07-24 02:14:54 --> Total execution time: 0.0869
DEBUG - 2011-07-24 02:24:47 --> Config Class Initialized
DEBUG - 2011-07-24 02:24:47 --> Hooks Class Initialized
DEBUG - 2011-07-24 02:24:47 --> Utf8 Class Initialized
DEBUG - 2011-07-24 02:24:47 --> UTF-8 Support Enabled
DEBUG - 2011-07-24 02:24:47 --> URI Class Initialized
DEBUG - 2011-07-24 02:24:47 --> Router Class Initialized
DEBUG - 2011-07-24 02:24:47 --> Output Class Initialized
DEBUG - 2011-07-24 02:24:47 --> Input Class Initialized
DEBUG - 2011-07-24 02:24:47 --> Global POST and COOKIE data sanitized
DEBUG - 2011-07-24 02:24:47 --> Language Class Initialized
DEBUG - 2011-07-24 02:24:47 --> Loader Class Initialized
DEBUG - 2011-07-24 02:24:47 --> Controller Class Initialized
ERROR - 2011-07-24 02:24:47 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-07-24 02:24:47 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-07-24 02:24:47 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-07-24 02:24:47 --> Model Class Initialized
DEBUG - 2011-07-24 02:24:47 --> Model Class Initialized
DEBUG - 2011-07-24 02:24:47 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-07-24 02:24:47 --> Database Driver Class Initialized
DEBUG - 2011-07-24 02:24:47 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-07-24 02:24:47 --> Helper loaded: url_helper
DEBUG - 2011-07-24 02:24:47 --> File loaded: application/views/common/header.php
DEBUG - 2011-07-24 02:24:47 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-07-24 02:24:47 --> File loaded: application/views/common/footer.php
DEBUG - 2011-07-24 02:24:47 --> File loaded: application/views/layout/main.php
DEBUG - 2011-07-24 02:24:47 --> Final output sent to browser
DEBUG - 2011-07-24 02:24:47 --> Total execution time: 0.0838
DEBUG - 2011-07-24 02:24:48 --> Config Class Initialized
DEBUG - 2011-07-24 02:24:48 --> Hooks Class Initialized
DEBUG - 2011-07-24 02:24:48 --> Utf8 Class Initialized
DEBUG - 2011-07-24 02:24:48 --> UTF-8 Support Enabled
DEBUG - 2011-07-24 02:24:48 --> URI Class Initialized
DEBUG - 2011-07-24 02:24:48 --> Router Class Initialized
DEBUG - 2011-07-24 02:24:48 --> Output Class Initialized
DEBUG - 2011-07-24 02:24:48 --> Input Class Initialized
DEBUG - 2011-07-24 02:24:48 --> Global POST and COOKIE data sanitized
DEBUG - 2011-07-24 02:24:48 --> Language Class Initialized
DEBUG - 2011-07-24 02:24:48 --> Loader Class Initialized
DEBUG - 2011-07-24 02:24:48 --> Controller Class Initialized
DEBUG - 2011-07-24 02:24:48 --> Model Class Initialized
DEBUG - 2011-07-24 02:24:48 --> Model Class Initialized
DEBUG - 2011-07-24 02:24:48 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-07-24 02:24:48 --> Database Driver Class Initialized
DEBUG - 2011-07-24 02:24:49 --> Final output sent to browser
DEBUG - 2011-07-24 02:24:49 --> Total execution time: 0.6768
DEBUG - 2011-07-24 02:24:50 --> Config Class Initialized
DEBUG - 2011-07-24 02:24:50 --> Hooks Class Initialized
DEBUG - 2011-07-24 02:24:50 --> Utf8 Class Initialized
DEBUG - 2011-07-24 02:24:50 --> UTF-8 Support Enabled
DEBUG - 2011-07-24 02:24:50 --> URI Class Initialized
DEBUG - 2011-07-24 02:24:50 --> Router Class Initialized
ERROR - 2011-07-24 02:24:50 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-07-24 02:24:59 --> Config Class Initialized
DEBUG - 2011-07-24 02:24:59 --> Hooks Class Initialized
DEBUG - 2011-07-24 02:24:59 --> Utf8 Class Initialized
DEBUG - 2011-07-24 02:24:59 --> UTF-8 Support Enabled
DEBUG - 2011-07-24 02:24:59 --> URI Class Initialized
DEBUG - 2011-07-24 02:24:59 --> Router Class Initialized
ERROR - 2011-07-24 02:24:59 --> 404 Page Not Found --> robots.txt
DEBUG - 2011-07-24 02:24:59 --> Config Class Initialized
DEBUG - 2011-07-24 02:24:59 --> Hooks Class Initialized
DEBUG - 2011-07-24 02:24:59 --> Utf8 Class Initialized
DEBUG - 2011-07-24 02:24:59 --> UTF-8 Support Enabled
DEBUG - 2011-07-24 02:24:59 --> URI Class Initialized
DEBUG - 2011-07-24 02:24:59 --> Router Class Initialized
DEBUG - 2011-07-24 02:24:59 --> Output Class Initialized
DEBUG - 2011-07-24 02:24:59 --> Input Class Initialized
DEBUG - 2011-07-24 02:24:59 --> Global POST and COOKIE data sanitized
DEBUG - 2011-07-24 02:24:59 --> Language Class Initialized
DEBUG - 2011-07-24 02:24:59 --> Loader Class Initialized
DEBUG - 2011-07-24 02:24:59 --> Controller Class Initialized
ERROR - 2011-07-24 02:24:59 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-07-24 02:24:59 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-07-24 02:24:59 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-07-24 02:24:59 --> Model Class Initialized
DEBUG - 2011-07-24 02:24:59 --> Model Class Initialized
DEBUG - 2011-07-24 02:24:59 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-07-24 02:24:59 --> Database Driver Class Initialized
DEBUG - 2011-07-24 02:24:59 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-07-24 02:24:59 --> Helper loaded: url_helper
DEBUG - 2011-07-24 02:24:59 --> File loaded: application/views/common/header.php
DEBUG - 2011-07-24 02:24:59 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-07-24 02:24:59 --> File loaded: application/views/common/footer.php
DEBUG - 2011-07-24 02:24:59 --> File loaded: application/views/layout/main.php
DEBUG - 2011-07-24 02:24:59 --> Final output sent to browser
DEBUG - 2011-07-24 02:24:59 --> Total execution time: 0.0344
DEBUG - 2011-07-24 02:29:55 --> Config Class Initialized
DEBUG - 2011-07-24 02:29:55 --> Hooks Class Initialized
DEBUG - 2011-07-24 02:29:55 --> Utf8 Class Initialized
DEBUG - 2011-07-24 02:29:55 --> UTF-8 Support Enabled
DEBUG - 2011-07-24 02:29:55 --> URI Class Initialized
DEBUG - 2011-07-24 02:29:55 --> Router Class Initialized
DEBUG - 2011-07-24 02:29:55 --> No URI present. Default controller set.
DEBUG - 2011-07-24 02:29:55 --> Output Class Initialized
DEBUG - 2011-07-24 02:29:55 --> Input Class Initialized
DEBUG - 2011-07-24 02:29:55 --> Global POST and COOKIE data sanitized
DEBUG - 2011-07-24 02:29:55 --> Language Class Initialized
DEBUG - 2011-07-24 02:29:55 --> Loader Class Initialized
DEBUG - 2011-07-24 02:29:55 --> Controller Class Initialized
DEBUG - 2011-07-24 02:29:55 --> File loaded: application/views/splash/main.php
DEBUG - 2011-07-24 02:29:55 --> Helper loaded: url_helper
DEBUG - 2011-07-24 02:29:55 --> File loaded: application/views/common/header.php
DEBUG - 2011-07-24 02:29:55 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-07-24 02:29:55 --> File loaded: application/views/common/footer.php
DEBUG - 2011-07-24 02:29:55 --> File loaded: application/views/layout/main.php
DEBUG - 2011-07-24 02:29:55 --> Final output sent to browser
DEBUG - 2011-07-24 02:29:55 --> Total execution time: 0.0926
DEBUG - 2011-07-24 02:30:02 --> Config Class Initialized
DEBUG - 2011-07-24 02:30:02 --> Hooks Class Initialized
DEBUG - 2011-07-24 02:30:02 --> Utf8 Class Initialized
DEBUG - 2011-07-24 02:30:02 --> UTF-8 Support Enabled
DEBUG - 2011-07-24 02:30:02 --> URI Class Initialized
DEBUG - 2011-07-24 02:30:02 --> Router Class Initialized
ERROR - 2011-07-24 02:30:02 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-07-24 02:37:47 --> Config Class Initialized
DEBUG - 2011-07-24 02:37:47 --> Hooks Class Initialized
DEBUG - 2011-07-24 02:37:47 --> Utf8 Class Initialized
DEBUG - 2011-07-24 02:37:47 --> UTF-8 Support Enabled
DEBUG - 2011-07-24 02:37:47 --> URI Class Initialized
DEBUG - 2011-07-24 02:37:47 --> Router Class Initialized
DEBUG - 2011-07-24 02:37:48 --> Output Class Initialized
DEBUG - 2011-07-24 02:37:48 --> Input Class Initialized
DEBUG - 2011-07-24 02:37:48 --> Global POST and COOKIE data sanitized
DEBUG - 2011-07-24 02:37:48 --> Language Class Initialized
DEBUG - 2011-07-24 02:37:48 --> Loader Class Initialized
DEBUG - 2011-07-24 02:37:48 --> Controller Class Initialized
ERROR - 2011-07-24 02:37:49 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-07-24 02:37:49 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-07-24 02:37:49 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-07-24 02:37:49 --> Model Class Initialized
DEBUG - 2011-07-24 02:37:49 --> Model Class Initialized
DEBUG - 2011-07-24 02:37:49 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-07-24 02:37:49 --> Database Driver Class Initialized
DEBUG - 2011-07-24 02:37:49 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-07-24 02:37:49 --> Config Class Initialized
DEBUG - 2011-07-24 02:37:49 --> Hooks Class Initialized
DEBUG - 2011-07-24 02:37:49 --> Utf8 Class Initialized
DEBUG - 2011-07-24 02:37:49 --> UTF-8 Support Enabled
DEBUG - 2011-07-24 02:37:49 --> URI Class Initialized
DEBUG - 2011-07-24 02:37:49 --> Router Class Initialized
DEBUG - 2011-07-24 02:37:49 --> Output Class Initialized
DEBUG - 2011-07-24 02:37:49 --> Input Class Initialized
DEBUG - 2011-07-24 02:37:49 --> Global POST and COOKIE data sanitized
DEBUG - 2011-07-24 02:37:49 --> Language Class Initialized
DEBUG - 2011-07-24 02:37:49 --> Loader Class Initialized
DEBUG - 2011-07-24 02:37:49 --> Controller Class Initialized
DEBUG - 2011-07-24 02:37:49 --> Helper loaded: url_helper
DEBUG - 2011-07-24 02:37:49 --> File loaded: application/views/common/header.php
DEBUG - 2011-07-24 02:37:49 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-07-24 02:37:49 --> File loaded: application/views/common/footer.php
DEBUG - 2011-07-24 02:37:49 --> File loaded: application/views/layout/main.php
DEBUG - 2011-07-24 02:37:49 --> Final output sent to browser
DEBUG - 2011-07-24 02:37:49 --> Total execution time: 2.1395
DEBUG - 2011-07-24 02:37:49 --> Model Class Initialized
DEBUG - 2011-07-24 02:37:50 --> Model Class Initialized
DEBUG - 2011-07-24 02:37:50 --> Model Class Initialized
DEBUG - 2011-07-24 02:37:50 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-07-24 02:37:50 --> Database Driver Class Initialized
DEBUG - 2011-07-24 02:37:50 --> File loaded: application/views/table/main.php
DEBUG - 2011-07-24 02:37:50 --> Helper loaded: url_helper
DEBUG - 2011-07-24 02:37:50 --> File loaded: application/views/common/header.php
DEBUG - 2011-07-24 02:37:50 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-07-24 02:37:50 --> File loaded: application/views/common/footer.php
DEBUG - 2011-07-24 02:37:50 --> File loaded: application/views/layout/main.php
DEBUG - 2011-07-24 02:37:50 --> Final output sent to browser
DEBUG - 2011-07-24 02:37:50 --> Total execution time: 1.2151
DEBUG - 2011-07-24 02:37:51 --> Config Class Initialized
DEBUG - 2011-07-24 02:37:51 --> Hooks Class Initialized
DEBUG - 2011-07-24 02:37:51 --> Utf8 Class Initialized
DEBUG - 2011-07-24 02:37:52 --> UTF-8 Support Enabled
DEBUG - 2011-07-24 02:37:52 --> URI Class Initialized
DEBUG - 2011-07-24 02:37:52 --> Router Class Initialized
DEBUG - 2011-07-24 02:37:52 --> Output Class Initialized
DEBUG - 2011-07-24 02:37:52 --> Input Class Initialized
DEBUG - 2011-07-24 02:37:52 --> Global POST and COOKIE data sanitized
DEBUG - 2011-07-24 02:37:52 --> Language Class Initialized
DEBUG - 2011-07-24 02:37:52 --> Loader Class Initialized
DEBUG - 2011-07-24 02:37:52 --> Controller Class Initialized
DEBUG - 2011-07-24 02:37:52 --> Model Class Initialized
DEBUG - 2011-07-24 02:37:52 --> Model Class Initialized
DEBUG - 2011-07-24 02:37:52 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-07-24 02:37:52 --> Database Driver Class Initialized
DEBUG - 2011-07-24 02:37:52 --> Final output sent to browser
DEBUG - 2011-07-24 02:37:52 --> Total execution time: 1.1125
DEBUG - 2011-07-24 02:37:57 --> Config Class Initialized
DEBUG - 2011-07-24 02:37:57 --> Hooks Class Initialized
DEBUG - 2011-07-24 02:37:57 --> Utf8 Class Initialized
DEBUG - 2011-07-24 02:37:57 --> UTF-8 Support Enabled
DEBUG - 2011-07-24 02:37:57 --> URI Class Initialized
DEBUG - 2011-07-24 02:37:57 --> Router Class Initialized
ERROR - 2011-07-24 02:37:57 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-07-24 02:38:21 --> Config Class Initialized
DEBUG - 2011-07-24 02:38:21 --> Hooks Class Initialized
DEBUG - 2011-07-24 02:38:21 --> Utf8 Class Initialized
DEBUG - 2011-07-24 02:38:21 --> UTF-8 Support Enabled
DEBUG - 2011-07-24 02:38:21 --> URI Class Initialized
DEBUG - 2011-07-24 02:38:21 --> Router Class Initialized
DEBUG - 2011-07-24 02:38:21 --> Output Class Initialized
DEBUG - 2011-07-24 02:38:21 --> Input Class Initialized
DEBUG - 2011-07-24 02:38:21 --> Global POST and COOKIE data sanitized
DEBUG - 2011-07-24 02:38:21 --> Language Class Initialized
DEBUG - 2011-07-24 02:38:21 --> Loader Class Initialized
DEBUG - 2011-07-24 02:38:21 --> Controller Class Initialized
DEBUG - 2011-07-24 02:38:21 --> Model Class Initialized
DEBUG - 2011-07-24 02:38:21 --> Model Class Initialized
DEBUG - 2011-07-24 02:38:21 --> Model Class Initialized
DEBUG - 2011-07-24 02:38:21 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-07-24 02:38:21 --> Database Driver Class Initialized
DEBUG - 2011-07-24 02:38:21 --> File loaded: application/views/table/main.php
DEBUG - 2011-07-24 02:38:21 --> Helper loaded: url_helper
DEBUG - 2011-07-24 02:38:21 --> File loaded: application/views/common/header.php
DEBUG - 2011-07-24 02:38:21 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-07-24 02:38:21 --> File loaded: application/views/common/footer.php
DEBUG - 2011-07-24 02:38:21 --> File loaded: application/views/layout/main.php
DEBUG - 2011-07-24 02:38:21 --> Final output sent to browser
DEBUG - 2011-07-24 02:38:21 --> Total execution time: 0.2151
DEBUG - 2011-07-24 02:38:30 --> Config Class Initialized
DEBUG - 2011-07-24 02:38:30 --> Hooks Class Initialized
DEBUG - 2011-07-24 02:38:30 --> Utf8 Class Initialized
DEBUG - 2011-07-24 02:38:30 --> UTF-8 Support Enabled
DEBUG - 2011-07-24 02:38:30 --> URI Class Initialized
DEBUG - 2011-07-24 02:38:30 --> Router Class Initialized
DEBUG - 2011-07-24 02:38:30 --> Output Class Initialized
DEBUG - 2011-07-24 02:38:30 --> Input Class Initialized
DEBUG - 2011-07-24 02:38:30 --> Global POST and COOKIE data sanitized
DEBUG - 2011-07-24 02:38:30 --> Language Class Initialized
DEBUG - 2011-07-24 02:38:30 --> Loader Class Initialized
DEBUG - 2011-07-24 02:38:30 --> Controller Class Initialized
DEBUG - 2011-07-24 02:38:30 --> Model Class Initialized
DEBUG - 2011-07-24 02:38:30 --> Model Class Initialized
DEBUG - 2011-07-24 02:38:30 --> Model Class Initialized
DEBUG - 2011-07-24 02:38:30 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-07-24 02:38:30 --> Database Driver Class Initialized
DEBUG - 2011-07-24 02:38:30 --> File loaded: application/views/table/main.php
DEBUG - 2011-07-24 02:38:30 --> Helper loaded: url_helper
DEBUG - 2011-07-24 02:38:30 --> File loaded: application/views/common/header.php
DEBUG - 2011-07-24 02:38:30 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-07-24 02:38:30 --> File loaded: application/views/common/footer.php
DEBUG - 2011-07-24 02:38:30 --> File loaded: application/views/layout/main.php
DEBUG - 2011-07-24 02:38:30 --> Final output sent to browser
DEBUG - 2011-07-24 02:38:30 --> Total execution time: 0.2575
DEBUG - 2011-07-24 02:38:35 --> Config Class Initialized
DEBUG - 2011-07-24 02:38:35 --> Hooks Class Initialized
DEBUG - 2011-07-24 02:38:35 --> Utf8 Class Initialized
DEBUG - 2011-07-24 02:38:35 --> UTF-8 Support Enabled
DEBUG - 2011-07-24 02:38:35 --> URI Class Initialized
DEBUG - 2011-07-24 02:38:35 --> Router Class Initialized
DEBUG - 2011-07-24 02:38:35 --> Output Class Initialized
DEBUG - 2011-07-24 02:38:35 --> Input Class Initialized
DEBUG - 2011-07-24 02:38:35 --> Global POST and COOKIE data sanitized
DEBUG - 2011-07-24 02:38:35 --> Language Class Initialized
DEBUG - 2011-07-24 02:38:35 --> Loader Class Initialized
DEBUG - 2011-07-24 02:38:35 --> Controller Class Initialized
DEBUG - 2011-07-24 02:38:35 --> Model Class Initialized
DEBUG - 2011-07-24 02:38:35 --> Model Class Initialized
DEBUG - 2011-07-24 02:38:35 --> Model Class Initialized
DEBUG - 2011-07-24 02:38:35 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-07-24 02:38:35 --> Database Driver Class Initialized
DEBUG - 2011-07-24 02:38:35 --> File loaded: application/views/table/main.php
DEBUG - 2011-07-24 02:38:35 --> Helper loaded: url_helper
DEBUG - 2011-07-24 02:38:35 --> File loaded: application/views/common/header.php
DEBUG - 2011-07-24 02:38:35 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-07-24 02:38:35 --> File loaded: application/views/common/footer.php
DEBUG - 2011-07-24 02:38:35 --> File loaded: application/views/layout/main.php
DEBUG - 2011-07-24 02:38:35 --> Final output sent to browser
DEBUG - 2011-07-24 02:38:35 --> Total execution time: 0.0478
DEBUG - 2011-07-24 02:38:37 --> Config Class Initialized
DEBUG - 2011-07-24 02:38:37 --> Hooks Class Initialized
DEBUG - 2011-07-24 02:38:37 --> Utf8 Class Initialized
DEBUG - 2011-07-24 02:38:37 --> UTF-8 Support Enabled
DEBUG - 2011-07-24 02:38:37 --> URI Class Initialized
DEBUG - 2011-07-24 02:38:37 --> Router Class Initialized
DEBUG - 2011-07-24 02:38:37 --> Output Class Initialized
DEBUG - 2011-07-24 02:38:37 --> Input Class Initialized
DEBUG - 2011-07-24 02:38:37 --> Global POST and COOKIE data sanitized
DEBUG - 2011-07-24 02:38:37 --> Language Class Initialized
DEBUG - 2011-07-24 02:38:37 --> Loader Class Initialized
DEBUG - 2011-07-24 02:38:37 --> Controller Class Initialized
DEBUG - 2011-07-24 02:38:37 --> Model Class Initialized
DEBUG - 2011-07-24 02:38:37 --> Model Class Initialized
DEBUG - 2011-07-24 02:38:37 --> Model Class Initialized
DEBUG - 2011-07-24 02:38:37 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-07-24 02:38:37 --> Database Driver Class Initialized
DEBUG - 2011-07-24 02:38:37 --> File loaded: application/views/table/main.php
DEBUG - 2011-07-24 02:38:37 --> Helper loaded: url_helper
DEBUG - 2011-07-24 02:38:37 --> File loaded: application/views/common/header.php
DEBUG - 2011-07-24 02:38:37 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-07-24 02:38:37 --> File loaded: application/views/common/footer.php
DEBUG - 2011-07-24 02:38:37 --> File loaded: application/views/layout/main.php
DEBUG - 2011-07-24 02:38:37 --> Final output sent to browser
DEBUG - 2011-07-24 02:38:37 --> Total execution time: 0.0488
DEBUG - 2011-07-24 02:38:42 --> Config Class Initialized
DEBUG - 2011-07-24 02:38:42 --> Hooks Class Initialized
DEBUG - 2011-07-24 02:38:42 --> Utf8 Class Initialized
DEBUG - 2011-07-24 02:38:42 --> UTF-8 Support Enabled
DEBUG - 2011-07-24 02:38:42 --> URI Class Initialized
DEBUG - 2011-07-24 02:38:42 --> Router Class Initialized
DEBUG - 2011-07-24 02:38:42 --> Output Class Initialized
DEBUG - 2011-07-24 02:38:42 --> Input Class Initialized
DEBUG - 2011-07-24 02:38:42 --> Global POST and COOKIE data sanitized
DEBUG - 2011-07-24 02:38:42 --> Language Class Initialized
DEBUG - 2011-07-24 02:38:42 --> Loader Class Initialized
DEBUG - 2011-07-24 02:38:42 --> Controller Class Initialized
DEBUG - 2011-07-24 02:38:42 --> Model Class Initialized
DEBUG - 2011-07-24 02:38:42 --> Model Class Initialized
DEBUG - 2011-07-24 02:38:42 --> Model Class Initialized
DEBUG - 2011-07-24 02:38:42 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-07-24 02:38:42 --> Database Driver Class Initialized
DEBUG - 2011-07-24 02:38:42 --> File loaded: application/views/table/main.php
DEBUG - 2011-07-24 02:38:42 --> Helper loaded: url_helper
DEBUG - 2011-07-24 02:38:42 --> File loaded: application/views/common/header.php
DEBUG - 2011-07-24 02:38:42 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-07-24 02:38:42 --> File loaded: application/views/common/footer.php
DEBUG - 2011-07-24 02:38:42 --> File loaded: application/views/layout/main.php
DEBUG - 2011-07-24 02:38:42 --> Final output sent to browser
DEBUG - 2011-07-24 02:38:42 --> Total execution time: 0.2367
DEBUG - 2011-07-24 02:38:43 --> Config Class Initialized
DEBUG - 2011-07-24 02:38:43 --> Hooks Class Initialized
DEBUG - 2011-07-24 02:38:43 --> Utf8 Class Initialized
DEBUG - 2011-07-24 02:38:43 --> UTF-8 Support Enabled
DEBUG - 2011-07-24 02:38:43 --> URI Class Initialized
DEBUG - 2011-07-24 02:38:43 --> Router Class Initialized
DEBUG - 2011-07-24 02:38:43 --> Output Class Initialized
DEBUG - 2011-07-24 02:38:43 --> Input Class Initialized
DEBUG - 2011-07-24 02:38:43 --> Global POST and COOKIE data sanitized
DEBUG - 2011-07-24 02:38:43 --> Language Class Initialized
DEBUG - 2011-07-24 02:38:43 --> Loader Class Initialized
DEBUG - 2011-07-24 02:38:43 --> Controller Class Initialized
DEBUG - 2011-07-24 02:38:43 --> Model Class Initialized
DEBUG - 2011-07-24 02:38:43 --> Model Class Initialized
DEBUG - 2011-07-24 02:38:43 --> Model Class Initialized
DEBUG - 2011-07-24 02:38:43 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-07-24 02:38:43 --> Database Driver Class Initialized
DEBUG - 2011-07-24 02:38:43 --> File loaded: application/views/table/main.php
DEBUG - 2011-07-24 02:38:43 --> Helper loaded: url_helper
DEBUG - 2011-07-24 02:38:43 --> File loaded: application/views/common/header.php
DEBUG - 2011-07-24 02:38:43 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-07-24 02:38:43 --> File loaded: application/views/common/footer.php
DEBUG - 2011-07-24 02:38:43 --> File loaded: application/views/layout/main.php
DEBUG - 2011-07-24 02:38:43 --> Final output sent to browser
DEBUG - 2011-07-24 02:38:43 --> Total execution time: 0.0474
DEBUG - 2011-07-24 02:38:50 --> Config Class Initialized
DEBUG - 2011-07-24 02:38:50 --> Hooks Class Initialized
DEBUG - 2011-07-24 02:38:50 --> Utf8 Class Initialized
DEBUG - 2011-07-24 02:38:50 --> UTF-8 Support Enabled
DEBUG - 2011-07-24 02:38:50 --> URI Class Initialized
DEBUG - 2011-07-24 02:38:50 --> Router Class Initialized
DEBUG - 2011-07-24 02:38:50 --> Output Class Initialized
DEBUG - 2011-07-24 02:38:50 --> Input Class Initialized
DEBUG - 2011-07-24 02:38:50 --> Global POST and COOKIE data sanitized
DEBUG - 2011-07-24 02:38:50 --> Language Class Initialized
DEBUG - 2011-07-24 02:38:50 --> Loader Class Initialized
DEBUG - 2011-07-24 02:38:50 --> Controller Class Initialized
DEBUG - 2011-07-24 02:38:50 --> Model Class Initialized
DEBUG - 2011-07-24 02:38:50 --> Model Class Initialized
DEBUG - 2011-07-24 02:38:50 --> Model Class Initialized
DEBUG - 2011-07-24 02:38:50 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-07-24 02:38:50 --> Database Driver Class Initialized
DEBUG - 2011-07-24 02:38:50 --> File loaded: application/views/table/main.php
DEBUG - 2011-07-24 02:38:50 --> Helper loaded: url_helper
DEBUG - 2011-07-24 02:38:50 --> File loaded: application/views/common/header.php
DEBUG - 2011-07-24 02:38:50 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-07-24 02:38:50 --> File loaded: application/views/common/footer.php
DEBUG - 2011-07-24 02:38:50 --> File loaded: application/views/layout/main.php
DEBUG - 2011-07-24 02:38:50 --> Final output sent to browser
DEBUG - 2011-07-24 02:38:50 --> Total execution time: 0.1872
DEBUG - 2011-07-24 02:38:59 --> Config Class Initialized
DEBUG - 2011-07-24 02:38:59 --> Hooks Class Initialized
DEBUG - 2011-07-24 02:38:59 --> Utf8 Class Initialized
DEBUG - 2011-07-24 02:38:59 --> UTF-8 Support Enabled
DEBUG - 2011-07-24 02:38:59 --> URI Class Initialized
DEBUG - 2011-07-24 02:38:59 --> Router Class Initialized
DEBUG - 2011-07-24 02:38:59 --> Output Class Initialized
DEBUG - 2011-07-24 02:38:59 --> Input Class Initialized
DEBUG - 2011-07-24 02:38:59 --> Global POST and COOKIE data sanitized
DEBUG - 2011-07-24 02:38:59 --> Language Class Initialized
DEBUG - 2011-07-24 02:38:59 --> Loader Class Initialized
DEBUG - 2011-07-24 02:38:59 --> Controller Class Initialized
DEBUG - 2011-07-24 02:38:59 --> Model Class Initialized
DEBUG - 2011-07-24 02:38:59 --> Model Class Initialized
DEBUG - 2011-07-24 02:38:59 --> Model Class Initialized
DEBUG - 2011-07-24 02:38:59 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-07-24 02:38:59 --> Database Driver Class Initialized
DEBUG - 2011-07-24 02:38:59 --> File loaded: application/views/table/main.php
DEBUG - 2011-07-24 02:38:59 --> Helper loaded: url_helper
DEBUG - 2011-07-24 02:38:59 --> File loaded: application/views/common/header.php
DEBUG - 2011-07-24 02:38:59 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-07-24 02:38:59 --> File loaded: application/views/common/footer.php
DEBUG - 2011-07-24 02:38:59 --> File loaded: application/views/layout/main.php
DEBUG - 2011-07-24 02:38:59 --> Final output sent to browser
DEBUG - 2011-07-24 02:38:59 --> Total execution time: 0.0446
DEBUG - 2011-07-24 05:30:34 --> Config Class Initialized
DEBUG - 2011-07-24 05:30:34 --> Hooks Class Initialized
DEBUG - 2011-07-24 05:30:34 --> Utf8 Class Initialized
DEBUG - 2011-07-24 05:30:34 --> UTF-8 Support Enabled
DEBUG - 2011-07-24 05:30:34 --> URI Class Initialized
DEBUG - 2011-07-24 05:30:34 --> Router Class Initialized
DEBUG - 2011-07-24 05:30:34 --> Output Class Initialized
DEBUG - 2011-07-24 05:30:34 --> Input Class Initialized
DEBUG - 2011-07-24 05:30:34 --> Global POST and COOKIE data sanitized
DEBUG - 2011-07-24 05:30:34 --> Language Class Initialized
DEBUG - 2011-07-24 05:30:34 --> Loader Class Initialized
DEBUG - 2011-07-24 05:30:34 --> Controller Class Initialized
DEBUG - 2011-07-24 05:30:34 --> Model Class Initialized
DEBUG - 2011-07-24 05:30:34 --> Model Class Initialized
DEBUG - 2011-07-24 05:30:34 --> Model Class Initialized
DEBUG - 2011-07-24 05:30:34 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-07-24 05:30:34 --> Database Driver Class Initialized
DEBUG - 2011-07-24 05:30:34 --> File loaded: application/views/table/main.php
DEBUG - 2011-07-24 05:30:34 --> Helper loaded: url_helper
DEBUG - 2011-07-24 05:30:34 --> File loaded: application/views/common/header.php
DEBUG - 2011-07-24 05:30:34 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-07-24 05:30:34 --> File loaded: application/views/common/footer.php
DEBUG - 2011-07-24 05:30:34 --> File loaded: application/views/layout/main.php
DEBUG - 2011-07-24 05:30:34 --> Final output sent to browser
DEBUG - 2011-07-24 05:30:34 --> Total execution time: 0.5700
DEBUG - 2011-07-24 05:30:34 --> Config Class Initialized
DEBUG - 2011-07-24 05:30:34 --> Hooks Class Initialized
DEBUG - 2011-07-24 05:30:34 --> Utf8 Class Initialized
DEBUG - 2011-07-24 05:30:34 --> UTF-8 Support Enabled
DEBUG - 2011-07-24 05:30:34 --> URI Class Initialized
DEBUG - 2011-07-24 05:30:34 --> Router Class Initialized
DEBUG - 2011-07-24 05:30:35 --> Output Class Initialized
DEBUG - 2011-07-24 05:30:35 --> Input Class Initialized
DEBUG - 2011-07-24 05:30:35 --> Global POST and COOKIE data sanitized
DEBUG - 2011-07-24 05:30:35 --> Language Class Initialized
DEBUG - 2011-07-24 05:30:35 --> Loader Class Initialized
DEBUG - 2011-07-24 05:30:35 --> Controller Class Initialized
DEBUG - 2011-07-24 05:30:35 --> Model Class Initialized
DEBUG - 2011-07-24 05:30:35 --> Model Class Initialized
DEBUG - 2011-07-24 05:30:35 --> Model Class Initialized
DEBUG - 2011-07-24 05:30:35 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-07-24 05:30:35 --> Database Driver Class Initialized
DEBUG - 2011-07-24 05:30:35 --> File loaded: application/views/table/main.php
DEBUG - 2011-07-24 05:30:35 --> Helper loaded: url_helper
DEBUG - 2011-07-24 05:30:35 --> File loaded: application/views/common/header.php
DEBUG - 2011-07-24 05:30:35 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-07-24 05:30:35 --> File loaded: application/views/common/footer.php
DEBUG - 2011-07-24 05:30:35 --> File loaded: application/views/layout/main.php
DEBUG - 2011-07-24 05:30:35 --> Final output sent to browser
DEBUG - 2011-07-24 05:30:35 --> Total execution time: 0.0514
DEBUG - 2011-07-24 05:30:37 --> Config Class Initialized
DEBUG - 2011-07-24 05:30:37 --> Hooks Class Initialized
DEBUG - 2011-07-24 05:30:37 --> Utf8 Class Initialized
DEBUG - 2011-07-24 05:30:37 --> UTF-8 Support Enabled
DEBUG - 2011-07-24 05:30:37 --> URI Class Initialized
DEBUG - 2011-07-24 05:30:37 --> Router Class Initialized
ERROR - 2011-07-24 05:30:37 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-07-24 05:31:58 --> Config Class Initialized
DEBUG - 2011-07-24 05:31:58 --> Hooks Class Initialized
DEBUG - 2011-07-24 05:31:58 --> Utf8 Class Initialized
DEBUG - 2011-07-24 05:31:58 --> UTF-8 Support Enabled
DEBUG - 2011-07-24 05:31:58 --> URI Class Initialized
DEBUG - 2011-07-24 05:31:58 --> Router Class Initialized
DEBUG - 2011-07-24 05:31:58 --> Output Class Initialized
DEBUG - 2011-07-24 05:31:58 --> Input Class Initialized
DEBUG - 2011-07-24 05:31:58 --> Global POST and COOKIE data sanitized
DEBUG - 2011-07-24 05:31:58 --> Language Class Initialized
DEBUG - 2011-07-24 05:31:58 --> Loader Class Initialized
DEBUG - 2011-07-24 05:31:58 --> Controller Class Initialized
ERROR - 2011-07-24 05:31:58 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-07-24 05:31:58 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-07-24 05:31:58 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-07-24 05:31:58 --> Model Class Initialized
DEBUG - 2011-07-24 05:31:58 --> Model Class Initialized
DEBUG - 2011-07-24 05:31:58 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-07-24 05:31:58 --> Database Driver Class Initialized
DEBUG - 2011-07-24 05:31:58 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-07-24 05:31:58 --> Helper loaded: url_helper
DEBUG - 2011-07-24 05:31:58 --> File loaded: application/views/common/header.php
DEBUG - 2011-07-24 05:31:58 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-07-24 05:31:58 --> File loaded: application/views/common/footer.php
DEBUG - 2011-07-24 05:31:58 --> File loaded: application/views/layout/main.php
DEBUG - 2011-07-24 05:31:58 --> Final output sent to browser
DEBUG - 2011-07-24 05:31:58 --> Total execution time: 0.0876
DEBUG - 2011-07-24 05:32:00 --> Config Class Initialized
DEBUG - 2011-07-24 05:32:00 --> Hooks Class Initialized
DEBUG - 2011-07-24 05:32:00 --> Utf8 Class Initialized
DEBUG - 2011-07-24 05:32:00 --> UTF-8 Support Enabled
DEBUG - 2011-07-24 05:32:00 --> URI Class Initialized
DEBUG - 2011-07-24 05:32:00 --> Router Class Initialized
DEBUG - 2011-07-24 05:32:00 --> Output Class Initialized
DEBUG - 2011-07-24 05:32:00 --> Input Class Initialized
DEBUG - 2011-07-24 05:32:00 --> Global POST and COOKIE data sanitized
DEBUG - 2011-07-24 05:32:00 --> Language Class Initialized
DEBUG - 2011-07-24 05:32:00 --> Loader Class Initialized
DEBUG - 2011-07-24 05:32:00 --> Controller Class Initialized
DEBUG - 2011-07-24 05:32:00 --> Model Class Initialized
DEBUG - 2011-07-24 05:32:00 --> Model Class Initialized
DEBUG - 2011-07-24 05:32:00 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-07-24 05:32:00 --> Database Driver Class Initialized
DEBUG - 2011-07-24 05:32:00 --> Final output sent to browser
DEBUG - 2011-07-24 05:32:00 --> Total execution time: 0.6057
DEBUG - 2011-07-24 05:32:07 --> Config Class Initialized
DEBUG - 2011-07-24 05:32:07 --> Hooks Class Initialized
DEBUG - 2011-07-24 05:32:07 --> Utf8 Class Initialized
DEBUG - 2011-07-24 05:32:07 --> UTF-8 Support Enabled
DEBUG - 2011-07-24 05:32:07 --> URI Class Initialized
DEBUG - 2011-07-24 05:32:07 --> Router Class Initialized
ERROR - 2011-07-24 05:32:07 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-07-24 05:32:34 --> Config Class Initialized
DEBUG - 2011-07-24 05:32:34 --> Hooks Class Initialized
DEBUG - 2011-07-24 05:32:34 --> Utf8 Class Initialized
DEBUG - 2011-07-24 05:32:34 --> UTF-8 Support Enabled
DEBUG - 2011-07-24 05:32:34 --> URI Class Initialized
DEBUG - 2011-07-24 05:32:34 --> Router Class Initialized
DEBUG - 2011-07-24 05:32:34 --> Output Class Initialized
DEBUG - 2011-07-24 05:32:34 --> Input Class Initialized
DEBUG - 2011-07-24 05:32:34 --> Global POST and COOKIE data sanitized
DEBUG - 2011-07-24 05:32:34 --> Language Class Initialized
DEBUG - 2011-07-24 05:32:34 --> Loader Class Initialized
DEBUG - 2011-07-24 05:32:34 --> Controller Class Initialized
ERROR - 2011-07-24 05:32:34 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-07-24 05:32:34 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-07-24 05:32:34 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-07-24 05:32:34 --> Model Class Initialized
DEBUG - 2011-07-24 05:32:34 --> Model Class Initialized
DEBUG - 2011-07-24 05:32:34 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-07-24 05:32:34 --> Database Driver Class Initialized
DEBUG - 2011-07-24 05:32:34 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-07-24 05:32:34 --> Helper loaded: url_helper
DEBUG - 2011-07-24 05:32:34 --> File loaded: application/views/common/header.php
DEBUG - 2011-07-24 05:32:34 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-07-24 05:32:34 --> File loaded: application/views/common/footer.php
DEBUG - 2011-07-24 05:32:34 --> File loaded: application/views/layout/main.php
DEBUG - 2011-07-24 05:32:34 --> Final output sent to browser
DEBUG - 2011-07-24 05:32:34 --> Total execution time: 0.0353
DEBUG - 2011-07-24 05:32:34 --> Config Class Initialized
DEBUG - 2011-07-24 05:32:34 --> Hooks Class Initialized
DEBUG - 2011-07-24 05:32:34 --> Utf8 Class Initialized
DEBUG - 2011-07-24 05:32:34 --> UTF-8 Support Enabled
DEBUG - 2011-07-24 05:32:34 --> URI Class Initialized
DEBUG - 2011-07-24 05:32:34 --> Router Class Initialized
DEBUG - 2011-07-24 05:32:34 --> Output Class Initialized
DEBUG - 2011-07-24 05:32:34 --> Input Class Initialized
DEBUG - 2011-07-24 05:32:34 --> Global POST and COOKIE data sanitized
DEBUG - 2011-07-24 05:32:34 --> Language Class Initialized
DEBUG - 2011-07-24 05:32:34 --> Loader Class Initialized
DEBUG - 2011-07-24 05:32:34 --> Controller Class Initialized
DEBUG - 2011-07-24 05:32:34 --> Model Class Initialized
DEBUG - 2011-07-24 05:32:34 --> Model Class Initialized
DEBUG - 2011-07-24 05:32:34 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-07-24 05:32:34 --> Database Driver Class Initialized
DEBUG - 2011-07-24 05:32:35 --> Final output sent to browser
DEBUG - 2011-07-24 05:32:35 --> Total execution time: 0.5499
DEBUG - 2011-07-24 05:32:42 --> Config Class Initialized
DEBUG - 2011-07-24 05:32:42 --> Hooks Class Initialized
DEBUG - 2011-07-24 05:32:42 --> Utf8 Class Initialized
DEBUG - 2011-07-24 05:32:42 --> UTF-8 Support Enabled
DEBUG - 2011-07-24 05:32:42 --> URI Class Initialized
DEBUG - 2011-07-24 05:32:42 --> Router Class Initialized
ERROR - 2011-07-24 05:32:42 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-07-24 06:02:42 --> Config Class Initialized
DEBUG - 2011-07-24 06:02:42 --> Hooks Class Initialized
DEBUG - 2011-07-24 06:02:43 --> Utf8 Class Initialized
DEBUG - 2011-07-24 06:02:43 --> UTF-8 Support Enabled
DEBUG - 2011-07-24 06:02:43 --> URI Class Initialized
DEBUG - 2011-07-24 06:02:43 --> Router Class Initialized
DEBUG - 2011-07-24 06:02:43 --> Output Class Initialized
DEBUG - 2011-07-24 06:02:43 --> Input Class Initialized
DEBUG - 2011-07-24 06:02:43 --> Global POST and COOKIE data sanitized
DEBUG - 2011-07-24 06:02:43 --> Language Class Initialized
DEBUG - 2011-07-24 06:02:43 --> Loader Class Initialized
DEBUG - 2011-07-24 06:02:43 --> Controller Class Initialized
DEBUG - 2011-07-24 06:02:43 --> Model Class Initialized
DEBUG - 2011-07-24 06:02:43 --> Model Class Initialized
DEBUG - 2011-07-24 06:02:43 --> Model Class Initialized
DEBUG - 2011-07-24 06:02:43 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-07-24 06:02:43 --> Database Driver Class Initialized
DEBUG - 2011-07-24 06:02:43 --> File loaded: application/views/table/main.php
DEBUG - 2011-07-24 06:02:43 --> Helper loaded: url_helper
DEBUG - 2011-07-24 06:02:43 --> File loaded: application/views/common/header.php
DEBUG - 2011-07-24 06:02:43 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-07-24 06:02:43 --> File loaded: application/views/common/footer.php
DEBUG - 2011-07-24 06:02:43 --> File loaded: application/views/layout/main.php
DEBUG - 2011-07-24 06:02:43 --> Final output sent to browser
DEBUG - 2011-07-24 06:02:43 --> Total execution time: 1.0226
DEBUG - 2011-07-24 06:33:18 --> Config Class Initialized
DEBUG - 2011-07-24 06:33:18 --> Hooks Class Initialized
DEBUG - 2011-07-24 06:33:18 --> Utf8 Class Initialized
DEBUG - 2011-07-24 06:33:18 --> UTF-8 Support Enabled
DEBUG - 2011-07-24 06:33:18 --> URI Class Initialized
DEBUG - 2011-07-24 06:33:18 --> Router Class Initialized
DEBUG - 2011-07-24 06:33:18 --> Output Class Initialized
DEBUG - 2011-07-24 06:33:18 --> Input Class Initialized
DEBUG - 2011-07-24 06:33:18 --> Global POST and COOKIE data sanitized
DEBUG - 2011-07-24 06:33:18 --> Language Class Initialized
DEBUG - 2011-07-24 06:33:18 --> Loader Class Initialized
DEBUG - 2011-07-24 06:33:18 --> Controller Class Initialized
DEBUG - 2011-07-24 06:33:18 --> Model Class Initialized
DEBUG - 2011-07-24 06:33:18 --> Model Class Initialized
DEBUG - 2011-07-24 06:33:18 --> Model Class Initialized
DEBUG - 2011-07-24 06:33:18 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-07-24 06:33:18 --> Database Driver Class Initialized
DEBUG - 2011-07-24 06:33:18 --> File loaded: application/views/table/main.php
DEBUG - 2011-07-24 06:33:18 --> Helper loaded: url_helper
DEBUG - 2011-07-24 06:33:18 --> File loaded: application/views/common/header.php
DEBUG - 2011-07-24 06:33:18 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-07-24 06:33:18 --> File loaded: application/views/common/footer.php
DEBUG - 2011-07-24 06:33:18 --> File loaded: application/views/layout/main.php
DEBUG - 2011-07-24 06:33:18 --> Final output sent to browser
DEBUG - 2011-07-24 06:33:18 --> Total execution time: 0.4059
DEBUG - 2011-07-24 06:33:21 --> Config Class Initialized
DEBUG - 2011-07-24 06:33:21 --> Hooks Class Initialized
DEBUG - 2011-07-24 06:33:21 --> Utf8 Class Initialized
DEBUG - 2011-07-24 06:33:21 --> UTF-8 Support Enabled
DEBUG - 2011-07-24 06:33:21 --> URI Class Initialized
DEBUG - 2011-07-24 06:33:21 --> Router Class Initialized
ERROR - 2011-07-24 06:33:21 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-07-24 06:33:22 --> Config Class Initialized
DEBUG - 2011-07-24 06:33:22 --> Hooks Class Initialized
DEBUG - 2011-07-24 06:33:22 --> Utf8 Class Initialized
DEBUG - 2011-07-24 06:33:22 --> UTF-8 Support Enabled
DEBUG - 2011-07-24 06:33:22 --> URI Class Initialized
DEBUG - 2011-07-24 06:33:22 --> Router Class Initialized
ERROR - 2011-07-24 06:33:22 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-07-24 06:33:22 --> Config Class Initialized
DEBUG - 2011-07-24 06:33:22 --> Hooks Class Initialized
DEBUG - 2011-07-24 06:33:22 --> Utf8 Class Initialized
DEBUG - 2011-07-24 06:33:22 --> UTF-8 Support Enabled
DEBUG - 2011-07-24 06:33:22 --> URI Class Initialized
DEBUG - 2011-07-24 06:33:22 --> Router Class Initialized
ERROR - 2011-07-24 06:33:22 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-07-24 06:33:53 --> Config Class Initialized
DEBUG - 2011-07-24 06:33:53 --> Hooks Class Initialized
DEBUG - 2011-07-24 06:33:53 --> Utf8 Class Initialized
DEBUG - 2011-07-24 06:33:53 --> UTF-8 Support Enabled
DEBUG - 2011-07-24 06:33:53 --> URI Class Initialized
DEBUG - 2011-07-24 06:33:53 --> Router Class Initialized
DEBUG - 2011-07-24 06:33:53 --> Output Class Initialized
DEBUG - 2011-07-24 06:33:53 --> Input Class Initialized
DEBUG - 2011-07-24 06:33:53 --> Global POST and COOKIE data sanitized
DEBUG - 2011-07-24 06:33:53 --> Language Class Initialized
DEBUG - 2011-07-24 06:33:53 --> Loader Class Initialized
DEBUG - 2011-07-24 06:33:53 --> Controller Class Initialized
DEBUG - 2011-07-24 06:33:53 --> Model Class Initialized
DEBUG - 2011-07-24 06:33:53 --> Model Class Initialized
DEBUG - 2011-07-24 06:33:53 --> Model Class Initialized
DEBUG - 2011-07-24 06:33:53 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-07-24 06:33:53 --> Database Driver Class Initialized
DEBUG - 2011-07-24 06:33:53 --> File loaded: application/views/table/main.php
DEBUG - 2011-07-24 06:33:53 --> Helper loaded: url_helper
DEBUG - 2011-07-24 06:33:53 --> File loaded: application/views/common/header.php
DEBUG - 2011-07-24 06:33:53 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-07-24 06:33:53 --> File loaded: application/views/common/footer.php
DEBUG - 2011-07-24 06:33:53 --> File loaded: application/views/layout/main.php
DEBUG - 2011-07-24 06:33:53 --> Final output sent to browser
DEBUG - 2011-07-24 06:33:53 --> Total execution time: 0.1949
DEBUG - 2011-07-24 06:33:54 --> Config Class Initialized
DEBUG - 2011-07-24 06:33:54 --> Hooks Class Initialized
DEBUG - 2011-07-24 06:33:54 --> Utf8 Class Initialized
DEBUG - 2011-07-24 06:33:54 --> UTF-8 Support Enabled
DEBUG - 2011-07-24 06:33:54 --> URI Class Initialized
DEBUG - 2011-07-24 06:33:54 --> Router Class Initialized
DEBUG - 2011-07-24 06:33:54 --> Output Class Initialized
DEBUG - 2011-07-24 06:33:54 --> Input Class Initialized
DEBUG - 2011-07-24 06:33:54 --> Global POST and COOKIE data sanitized
DEBUG - 2011-07-24 06:33:54 --> Language Class Initialized
DEBUG - 2011-07-24 06:33:54 --> Loader Class Initialized
DEBUG - 2011-07-24 06:33:54 --> Controller Class Initialized
DEBUG - 2011-07-24 06:33:54 --> Model Class Initialized
DEBUG - 2011-07-24 06:33:54 --> Model Class Initialized
DEBUG - 2011-07-24 06:33:54 --> Model Class Initialized
DEBUG - 2011-07-24 06:33:54 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-07-24 06:33:54 --> Database Driver Class Initialized
DEBUG - 2011-07-24 06:33:54 --> File loaded: application/views/table/main.php
DEBUG - 2011-07-24 06:33:54 --> Helper loaded: url_helper
DEBUG - 2011-07-24 06:33:54 --> File loaded: application/views/common/header.php
DEBUG - 2011-07-24 06:33:54 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-07-24 06:33:54 --> File loaded: application/views/common/footer.php
DEBUG - 2011-07-24 06:33:54 --> File loaded: application/views/layout/main.php
DEBUG - 2011-07-24 06:33:54 --> Final output sent to browser
DEBUG - 2011-07-24 06:33:54 --> Total execution time: 0.0658
DEBUG - 2011-07-24 06:34:26 --> Config Class Initialized
DEBUG - 2011-07-24 06:34:26 --> Hooks Class Initialized
DEBUG - 2011-07-24 06:34:26 --> Utf8 Class Initialized
DEBUG - 2011-07-24 06:34:26 --> UTF-8 Support Enabled
DEBUG - 2011-07-24 06:34:26 --> URI Class Initialized
DEBUG - 2011-07-24 06:34:26 --> Router Class Initialized
DEBUG - 2011-07-24 06:34:26 --> Output Class Initialized
DEBUG - 2011-07-24 06:34:26 --> Input Class Initialized
DEBUG - 2011-07-24 06:34:26 --> Global POST and COOKIE data sanitized
DEBUG - 2011-07-24 06:34:26 --> Language Class Initialized
DEBUG - 2011-07-24 06:34:26 --> Loader Class Initialized
DEBUG - 2011-07-24 06:34:26 --> Controller Class Initialized
DEBUG - 2011-07-24 06:34:26 --> Model Class Initialized
DEBUG - 2011-07-24 06:34:26 --> Model Class Initialized
DEBUG - 2011-07-24 06:34:26 --> Model Class Initialized
DEBUG - 2011-07-24 06:34:26 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-07-24 06:34:26 --> Database Driver Class Initialized
DEBUG - 2011-07-24 06:34:26 --> File loaded: application/views/table/main.php
DEBUG - 2011-07-24 06:34:26 --> Helper loaded: url_helper
DEBUG - 2011-07-24 06:34:26 --> File loaded: application/views/common/header.php
DEBUG - 2011-07-24 06:34:26 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-07-24 06:34:26 --> File loaded: application/views/common/footer.php
DEBUG - 2011-07-24 06:34:26 --> File loaded: application/views/layout/main.php
DEBUG - 2011-07-24 06:34:26 --> Final output sent to browser
DEBUG - 2011-07-24 06:34:26 --> Total execution time: 0.3390
DEBUG - 2011-07-24 06:34:44 --> Config Class Initialized
DEBUG - 2011-07-24 06:34:44 --> Hooks Class Initialized
DEBUG - 2011-07-24 06:34:44 --> Utf8 Class Initialized
DEBUG - 2011-07-24 06:34:44 --> UTF-8 Support Enabled
DEBUG - 2011-07-24 06:34:44 --> URI Class Initialized
DEBUG - 2011-07-24 06:34:44 --> Router Class Initialized
DEBUG - 2011-07-24 06:34:44 --> Output Class Initialized
DEBUG - 2011-07-24 06:34:44 --> Input Class Initialized
DEBUG - 2011-07-24 06:34:44 --> Global POST and COOKIE data sanitized
DEBUG - 2011-07-24 06:34:44 --> Language Class Initialized
DEBUG - 2011-07-24 06:34:44 --> Loader Class Initialized
DEBUG - 2011-07-24 06:34:44 --> Controller Class Initialized
DEBUG - 2011-07-24 06:34:44 --> Model Class Initialized
DEBUG - 2011-07-24 06:34:44 --> Model Class Initialized
DEBUG - 2011-07-24 06:34:44 --> Model Class Initialized
DEBUG - 2011-07-24 06:34:44 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-07-24 06:34:44 --> Database Driver Class Initialized
DEBUG - 2011-07-24 06:34:44 --> File loaded: application/views/table/main.php
DEBUG - 2011-07-24 06:34:44 --> Helper loaded: url_helper
DEBUG - 2011-07-24 06:34:44 --> File loaded: application/views/common/header.php
DEBUG - 2011-07-24 06:34:44 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-07-24 06:34:44 --> File loaded: application/views/common/footer.php
DEBUG - 2011-07-24 06:34:44 --> File loaded: application/views/layout/main.php
DEBUG - 2011-07-24 06:34:44 --> Final output sent to browser
DEBUG - 2011-07-24 06:34:44 --> Total execution time: 0.0441
DEBUG - 2011-07-24 07:02:16 --> Config Class Initialized
DEBUG - 2011-07-24 07:02:16 --> Hooks Class Initialized
DEBUG - 2011-07-24 07:02:16 --> Utf8 Class Initialized
DEBUG - 2011-07-24 07:02:16 --> UTF-8 Support Enabled
DEBUG - 2011-07-24 07:02:16 --> URI Class Initialized
DEBUG - 2011-07-24 07:02:16 --> Router Class Initialized
ERROR - 2011-07-24 07:02:16 --> 404 Page Not Found --> robots.txt
DEBUG - 2011-07-24 07:02:16 --> Config Class Initialized
DEBUG - 2011-07-24 07:02:16 --> Hooks Class Initialized
DEBUG - 2011-07-24 07:02:16 --> Utf8 Class Initialized
DEBUG - 2011-07-24 07:02:16 --> UTF-8 Support Enabled
DEBUG - 2011-07-24 07:02:16 --> URI Class Initialized
DEBUG - 2011-07-24 07:02:16 --> Router Class Initialized
DEBUG - 2011-07-24 07:02:16 --> Output Class Initialized
DEBUG - 2011-07-24 07:02:16 --> Input Class Initialized
DEBUG - 2011-07-24 07:02:16 --> Global POST and COOKIE data sanitized
DEBUG - 2011-07-24 07:02:16 --> Language Class Initialized
DEBUG - 2011-07-24 07:02:16 --> Loader Class Initialized
DEBUG - 2011-07-24 07:02:16 --> Controller Class Initialized
DEBUG - 2011-07-24 07:02:16 --> Model Class Initialized
DEBUG - 2011-07-24 07:02:16 --> Model Class Initialized
DEBUG - 2011-07-24 07:02:16 --> Model Class Initialized
DEBUG - 2011-07-24 07:02:16 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-07-24 07:02:16 --> Database Driver Class Initialized
DEBUG - 2011-07-24 07:02:16 --> File loaded: application/views/table/main.php
DEBUG - 2011-07-24 07:02:16 --> Helper loaded: url_helper
DEBUG - 2011-07-24 07:02:16 --> File loaded: application/views/common/header.php
DEBUG - 2011-07-24 07:02:16 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-07-24 07:02:16 --> File loaded: application/views/common/footer.php
DEBUG - 2011-07-24 07:02:16 --> File loaded: application/views/layout/main.php
DEBUG - 2011-07-24 07:02:16 --> Final output sent to browser
DEBUG - 2011-07-24 07:02:16 --> Total execution time: 0.4298
DEBUG - 2011-07-24 07:43:50 --> Config Class Initialized
DEBUG - 2011-07-24 07:43:50 --> Hooks Class Initialized
DEBUG - 2011-07-24 07:43:50 --> Utf8 Class Initialized
DEBUG - 2011-07-24 07:43:50 --> UTF-8 Support Enabled
DEBUG - 2011-07-24 07:43:50 --> URI Class Initialized
DEBUG - 2011-07-24 07:43:50 --> Router Class Initialized
DEBUG - 2011-07-24 07:43:50 --> Output Class Initialized
DEBUG - 2011-07-24 07:43:50 --> Input Class Initialized
DEBUG - 2011-07-24 07:43:50 --> Global POST and COOKIE data sanitized
DEBUG - 2011-07-24 07:43:50 --> Language Class Initialized
DEBUG - 2011-07-24 07:43:50 --> Loader Class Initialized
DEBUG - 2011-07-24 07:43:50 --> Controller Class Initialized
DEBUG - 2011-07-24 07:43:50 --> Model Class Initialized
DEBUG - 2011-07-24 07:43:50 --> Model Class Initialized
DEBUG - 2011-07-24 07:43:50 --> Model Class Initialized
DEBUG - 2011-07-24 07:43:50 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-07-24 07:43:50 --> Database Driver Class Initialized
DEBUG - 2011-07-24 07:43:50 --> File loaded: application/views/table/main.php
DEBUG - 2011-07-24 07:43:50 --> Helper loaded: url_helper
DEBUG - 2011-07-24 07:43:50 --> File loaded: application/views/common/header.php
DEBUG - 2011-07-24 07:43:50 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-07-24 07:43:50 --> File loaded: application/views/common/footer.php
DEBUG - 2011-07-24 07:43:50 --> File loaded: application/views/layout/main.php
DEBUG - 2011-07-24 07:43:50 --> Final output sent to browser
DEBUG - 2011-07-24 07:43:50 --> Total execution time: 0.3878
DEBUG - 2011-07-24 07:48:34 --> Config Class Initialized
DEBUG - 2011-07-24 07:48:34 --> Hooks Class Initialized
DEBUG - 2011-07-24 07:48:34 --> Utf8 Class Initialized
DEBUG - 2011-07-24 07:48:34 --> UTF-8 Support Enabled
DEBUG - 2011-07-24 07:48:34 --> URI Class Initialized
DEBUG - 2011-07-24 07:48:34 --> Router Class Initialized
DEBUG - 2011-07-24 07:48:34 --> Output Class Initialized
DEBUG - 2011-07-24 07:48:34 --> Input Class Initialized
DEBUG - 2011-07-24 07:48:34 --> Global POST and COOKIE data sanitized
DEBUG - 2011-07-24 07:48:34 --> Language Class Initialized
DEBUG - 2011-07-24 07:48:35 --> Loader Class Initialized
DEBUG - 2011-07-24 07:48:35 --> Controller Class Initialized
DEBUG - 2011-07-24 07:48:35 --> Model Class Initialized
DEBUG - 2011-07-24 07:48:35 --> Model Class Initialized
DEBUG - 2011-07-24 07:48:35 --> Model Class Initialized
DEBUG - 2011-07-24 07:48:35 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-07-24 07:48:35 --> Database Driver Class Initialized
DEBUG - 2011-07-24 07:48:35 --> File loaded: application/views/table/main.php
DEBUG - 2011-07-24 07:48:36 --> Helper loaded: url_helper
DEBUG - 2011-07-24 07:48:36 --> File loaded: application/views/common/header.php
DEBUG - 2011-07-24 07:48:36 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-07-24 07:48:36 --> File loaded: application/views/common/footer.php
DEBUG - 2011-07-24 07:48:36 --> File loaded: application/views/layout/main.php
DEBUG - 2011-07-24 07:48:36 --> Final output sent to browser
DEBUG - 2011-07-24 07:48:36 --> Total execution time: 2.0906
DEBUG - 2011-07-24 07:48:37 --> Config Class Initialized
DEBUG - 2011-07-24 07:48:37 --> Hooks Class Initialized
DEBUG - 2011-07-24 07:48:37 --> Utf8 Class Initialized
DEBUG - 2011-07-24 07:48:37 --> UTF-8 Support Enabled
DEBUG - 2011-07-24 07:48:37 --> URI Class Initialized
DEBUG - 2011-07-24 07:48:37 --> Router Class Initialized
DEBUG - 2011-07-24 07:48:37 --> Output Class Initialized
DEBUG - 2011-07-24 07:48:37 --> Input Class Initialized
DEBUG - 2011-07-24 07:48:37 --> Global POST and COOKIE data sanitized
DEBUG - 2011-07-24 07:48:37 --> Language Class Initialized
DEBUG - 2011-07-24 07:48:37 --> Loader Class Initialized
DEBUG - 2011-07-24 07:48:37 --> Controller Class Initialized
ERROR - 2011-07-24 07:48:37 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-07-24 07:48:37 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-07-24 07:48:37 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-07-24 07:48:37 --> Model Class Initialized
DEBUG - 2011-07-24 07:48:37 --> Model Class Initialized
DEBUG - 2011-07-24 07:48:37 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-07-24 07:48:37 --> Database Driver Class Initialized
DEBUG - 2011-07-24 07:48:37 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-07-24 07:48:37 --> Helper loaded: url_helper
DEBUG - 2011-07-24 07:48:37 --> File loaded: application/views/common/header.php
DEBUG - 2011-07-24 07:48:37 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-07-24 07:48:37 --> File loaded: application/views/common/footer.php
DEBUG - 2011-07-24 07:48:37 --> File loaded: application/views/layout/main.php
DEBUG - 2011-07-24 07:48:37 --> Final output sent to browser
DEBUG - 2011-07-24 07:48:37 --> Total execution time: 0.1124
DEBUG - 2011-07-24 09:57:09 --> Config Class Initialized
DEBUG - 2011-07-24 09:57:09 --> Hooks Class Initialized
DEBUG - 2011-07-24 09:57:09 --> Utf8 Class Initialized
DEBUG - 2011-07-24 09:57:09 --> UTF-8 Support Enabled
DEBUG - 2011-07-24 09:57:09 --> URI Class Initialized
DEBUG - 2011-07-24 09:57:09 --> Router Class Initialized
DEBUG - 2011-07-24 09:57:09 --> Output Class Initialized
DEBUG - 2011-07-24 09:57:09 --> Input Class Initialized
DEBUG - 2011-07-24 09:57:09 --> Global POST and COOKIE data sanitized
DEBUG - 2011-07-24 09:57:09 --> Language Class Initialized
DEBUG - 2011-07-24 09:57:09 --> Loader Class Initialized
DEBUG - 2011-07-24 09:57:09 --> Controller Class Initialized
DEBUG - 2011-07-24 09:57:09 --> Model Class Initialized
DEBUG - 2011-07-24 09:57:09 --> Model Class Initialized
DEBUG - 2011-07-24 09:57:09 --> Model Class Initialized
DEBUG - 2011-07-24 09:57:09 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-07-24 09:57:09 --> Database Driver Class Initialized
DEBUG - 2011-07-24 09:57:09 --> File loaded: application/views/table/main.php
DEBUG - 2011-07-24 09:57:10 --> Helper loaded: url_helper
DEBUG - 2011-07-24 09:57:10 --> File loaded: application/views/common/header.php
DEBUG - 2011-07-24 09:57:10 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-07-24 09:57:10 --> File loaded: application/views/common/footer.php
DEBUG - 2011-07-24 09:57:10 --> File loaded: application/views/layout/main.php
DEBUG - 2011-07-24 09:57:10 --> Final output sent to browser
DEBUG - 2011-07-24 09:57:10 --> Total execution time: 0.6259
DEBUG - 2011-07-24 09:57:12 --> Config Class Initialized
DEBUG - 2011-07-24 09:57:12 --> Hooks Class Initialized
DEBUG - 2011-07-24 09:57:12 --> Utf8 Class Initialized
DEBUG - 2011-07-24 09:57:12 --> UTF-8 Support Enabled
DEBUG - 2011-07-24 09:57:12 --> URI Class Initialized
DEBUG - 2011-07-24 09:57:12 --> Router Class Initialized
ERROR - 2011-07-24 09:57:12 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-07-24 09:57:48 --> Config Class Initialized
DEBUG - 2011-07-24 09:57:48 --> Hooks Class Initialized
DEBUG - 2011-07-24 09:57:48 --> Utf8 Class Initialized
DEBUG - 2011-07-24 09:57:48 --> UTF-8 Support Enabled
DEBUG - 2011-07-24 09:57:48 --> URI Class Initialized
DEBUG - 2011-07-24 09:57:48 --> Router Class Initialized
DEBUG - 2011-07-24 09:57:48 --> Output Class Initialized
DEBUG - 2011-07-24 09:57:48 --> Input Class Initialized
DEBUG - 2011-07-24 09:57:48 --> Global POST and COOKIE data sanitized
DEBUG - 2011-07-24 09:57:48 --> Language Class Initialized
DEBUG - 2011-07-24 09:57:48 --> Loader Class Initialized
DEBUG - 2011-07-24 09:57:48 --> Controller Class Initialized
DEBUG - 2011-07-24 09:57:48 --> Model Class Initialized
DEBUG - 2011-07-24 09:57:48 --> Model Class Initialized
DEBUG - 2011-07-24 09:57:48 --> Model Class Initialized
DEBUG - 2011-07-24 09:57:48 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-07-24 09:57:48 --> Database Driver Class Initialized
DEBUG - 2011-07-24 09:57:48 --> File loaded: application/views/table/main.php
DEBUG - 2011-07-24 09:57:48 --> Helper loaded: url_helper
DEBUG - 2011-07-24 09:57:48 --> File loaded: application/views/common/header.php
DEBUG - 2011-07-24 09:57:48 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-07-24 09:57:48 --> File loaded: application/views/common/footer.php
DEBUG - 2011-07-24 09:57:48 --> File loaded: application/views/layout/main.php
DEBUG - 2011-07-24 09:57:48 --> Final output sent to browser
DEBUG - 2011-07-24 09:57:48 --> Total execution time: 0.0462
DEBUG - 2011-07-24 09:57:50 --> Config Class Initialized
DEBUG - 2011-07-24 09:57:50 --> Hooks Class Initialized
DEBUG - 2011-07-24 09:57:50 --> Utf8 Class Initialized
DEBUG - 2011-07-24 09:57:50 --> UTF-8 Support Enabled
DEBUG - 2011-07-24 09:57:50 --> URI Class Initialized
DEBUG - 2011-07-24 09:57:50 --> Router Class Initialized
ERROR - 2011-07-24 09:57:50 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-07-24 09:57:59 --> Config Class Initialized
DEBUG - 2011-07-24 09:57:59 --> Hooks Class Initialized
DEBUG - 2011-07-24 09:57:59 --> Utf8 Class Initialized
DEBUG - 2011-07-24 09:57:59 --> UTF-8 Support Enabled
DEBUG - 2011-07-24 09:57:59 --> URI Class Initialized
DEBUG - 2011-07-24 09:57:59 --> Router Class Initialized
DEBUG - 2011-07-24 09:57:59 --> Output Class Initialized
DEBUG - 2011-07-24 09:57:59 --> Input Class Initialized
DEBUG - 2011-07-24 09:57:59 --> Global POST and COOKIE data sanitized
DEBUG - 2011-07-24 09:57:59 --> Language Class Initialized
DEBUG - 2011-07-24 09:57:59 --> Loader Class Initialized
DEBUG - 2011-07-24 09:57:59 --> Controller Class Initialized
DEBUG - 2011-07-24 09:57:59 --> Model Class Initialized
DEBUG - 2011-07-24 09:57:59 --> Model Class Initialized
DEBUG - 2011-07-24 09:57:59 --> Model Class Initialized
DEBUG - 2011-07-24 09:57:59 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-07-24 09:57:59 --> Database Driver Class Initialized
DEBUG - 2011-07-24 09:57:59 --> File loaded: application/views/table/main.php
DEBUG - 2011-07-24 09:57:59 --> Helper loaded: url_helper
DEBUG - 2011-07-24 09:57:59 --> File loaded: application/views/common/header.php
DEBUG - 2011-07-24 09:57:59 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-07-24 09:57:59 --> File loaded: application/views/common/footer.php
DEBUG - 2011-07-24 09:57:59 --> File loaded: application/views/layout/main.php
DEBUG - 2011-07-24 09:57:59 --> Final output sent to browser
DEBUG - 2011-07-24 09:57:59 --> Total execution time: 0.0476
DEBUG - 2011-07-24 11:16:14 --> Config Class Initialized
DEBUG - 2011-07-24 11:16:14 --> Hooks Class Initialized
DEBUG - 2011-07-24 11:16:14 --> Utf8 Class Initialized
DEBUG - 2011-07-24 11:16:14 --> UTF-8 Support Enabled
DEBUG - 2011-07-24 11:16:14 --> URI Class Initialized
DEBUG - 2011-07-24 11:16:14 --> Router Class Initialized
DEBUG - 2011-07-24 11:16:14 --> Output Class Initialized
DEBUG - 2011-07-24 11:16:14 --> Input Class Initialized
DEBUG - 2011-07-24 11:16:14 --> Global POST and COOKIE data sanitized
DEBUG - 2011-07-24 11:16:15 --> Language Class Initialized
DEBUG - 2011-07-24 11:16:15 --> Loader Class Initialized
DEBUG - 2011-07-24 11:16:15 --> Controller Class Initialized
DEBUG - 2011-07-24 11:16:15 --> Model Class Initialized
DEBUG - 2011-07-24 11:16:15 --> Model Class Initialized
DEBUG - 2011-07-24 11:16:15 --> Model Class Initialized
DEBUG - 2011-07-24 11:16:15 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-07-24 11:16:15 --> Database Driver Class Initialized
DEBUG - 2011-07-24 11:16:15 --> File loaded: application/views/table/main.php
DEBUG - 2011-07-24 11:16:15 --> Helper loaded: url_helper
DEBUG - 2011-07-24 11:16:15 --> File loaded: application/views/common/header.php
DEBUG - 2011-07-24 11:16:15 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-07-24 11:16:15 --> File loaded: application/views/common/footer.php
DEBUG - 2011-07-24 11:16:15 --> File loaded: application/views/layout/main.php
DEBUG - 2011-07-24 11:16:15 --> Final output sent to browser
DEBUG - 2011-07-24 11:16:15 --> Total execution time: 1.1183
DEBUG - 2011-07-24 12:10:11 --> Config Class Initialized
DEBUG - 2011-07-24 12:10:11 --> Hooks Class Initialized
DEBUG - 2011-07-24 12:10:11 --> Utf8 Class Initialized
DEBUG - 2011-07-24 12:10:11 --> UTF-8 Support Enabled
DEBUG - 2011-07-24 12:10:11 --> URI Class Initialized
DEBUG - 2011-07-24 12:10:11 --> Router Class Initialized
DEBUG - 2011-07-24 12:10:11 --> Output Class Initialized
DEBUG - 2011-07-24 12:10:11 --> Input Class Initialized
DEBUG - 2011-07-24 12:10:11 --> Global POST and COOKIE data sanitized
DEBUG - 2011-07-24 12:10:11 --> Language Class Initialized
DEBUG - 2011-07-24 12:10:11 --> Loader Class Initialized
DEBUG - 2011-07-24 12:10:11 --> Controller Class Initialized
DEBUG - 2011-07-24 12:10:11 --> Model Class Initialized
DEBUG - 2011-07-24 12:10:11 --> Model Class Initialized
DEBUG - 2011-07-24 12:10:11 --> Model Class Initialized
DEBUG - 2011-07-24 12:10:11 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-07-24 12:10:11 --> Database Driver Class Initialized
DEBUG - 2011-07-24 12:10:12 --> File loaded: application/views/table/main.php
DEBUG - 2011-07-24 12:10:12 --> Helper loaded: url_helper
DEBUG - 2011-07-24 12:10:12 --> File loaded: application/views/common/header.php
DEBUG - 2011-07-24 12:10:12 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-07-24 12:10:12 --> File loaded: application/views/common/footer.php
DEBUG - 2011-07-24 12:10:12 --> File loaded: application/views/layout/main.php
DEBUG - 2011-07-24 12:10:12 --> Final output sent to browser
DEBUG - 2011-07-24 12:10:12 --> Total execution time: 1.1037
DEBUG - 2011-07-24 13:08:00 --> Config Class Initialized
DEBUG - 2011-07-24 13:08:00 --> Hooks Class Initialized
DEBUG - 2011-07-24 13:08:00 --> Utf8 Class Initialized
DEBUG - 2011-07-24 13:08:00 --> UTF-8 Support Enabled
DEBUG - 2011-07-24 13:08:00 --> URI Class Initialized
DEBUG - 2011-07-24 13:08:00 --> Router Class Initialized
DEBUG - 2011-07-24 13:08:00 --> Output Class Initialized
DEBUG - 2011-07-24 13:08:00 --> Input Class Initialized
DEBUG - 2011-07-24 13:08:00 --> Global POST and COOKIE data sanitized
DEBUG - 2011-07-24 13:08:00 --> Language Class Initialized
DEBUG - 2011-07-24 13:08:00 --> Loader Class Initialized
DEBUG - 2011-07-24 13:08:00 --> Controller Class Initialized
ERROR - 2011-07-24 13:08:00 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-07-24 13:08:00 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-07-24 13:08:00 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-07-24 13:08:00 --> Model Class Initialized
DEBUG - 2011-07-24 13:08:00 --> Model Class Initialized
DEBUG - 2011-07-24 13:08:00 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-07-24 13:08:00 --> Database Driver Class Initialized
DEBUG - 2011-07-24 13:08:00 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-07-24 13:08:00 --> Helper loaded: url_helper
DEBUG - 2011-07-24 13:08:00 --> File loaded: application/views/common/header.php
DEBUG - 2011-07-24 13:08:00 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-07-24 13:08:00 --> File loaded: application/views/common/footer.php
DEBUG - 2011-07-24 13:08:00 --> File loaded: application/views/layout/main.php
DEBUG - 2011-07-24 13:08:00 --> Final output sent to browser
DEBUG - 2011-07-24 13:08:00 --> Total execution time: 0.3735
DEBUG - 2011-07-24 13:08:01 --> Config Class Initialized
DEBUG - 2011-07-24 13:08:01 --> Hooks Class Initialized
DEBUG - 2011-07-24 13:08:01 --> Utf8 Class Initialized
DEBUG - 2011-07-24 13:08:01 --> UTF-8 Support Enabled
DEBUG - 2011-07-24 13:08:01 --> URI Class Initialized
DEBUG - 2011-07-24 13:08:01 --> Router Class Initialized
DEBUG - 2011-07-24 13:08:01 --> Output Class Initialized
DEBUG - 2011-07-24 13:08:01 --> Input Class Initialized
DEBUG - 2011-07-24 13:08:01 --> Global POST and COOKIE data sanitized
DEBUG - 2011-07-24 13:08:01 --> Language Class Initialized
DEBUG - 2011-07-24 13:08:01 --> Loader Class Initialized
DEBUG - 2011-07-24 13:08:01 --> Controller Class Initialized
DEBUG - 2011-07-24 13:08:01 --> Model Class Initialized
DEBUG - 2011-07-24 13:08:01 --> Model Class Initialized
DEBUG - 2011-07-24 13:08:01 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-07-24 13:08:01 --> Database Driver Class Initialized
DEBUG - 2011-07-24 13:08:02 --> Final output sent to browser
DEBUG - 2011-07-24 13:08:02 --> Total execution time: 0.8429
DEBUG - 2011-07-24 16:08:08 --> Config Class Initialized
DEBUG - 2011-07-24 16:08:08 --> Hooks Class Initialized
DEBUG - 2011-07-24 16:08:08 --> Utf8 Class Initialized
DEBUG - 2011-07-24 16:08:08 --> UTF-8 Support Enabled
DEBUG - 2011-07-24 16:08:08 --> URI Class Initialized
DEBUG - 2011-07-24 16:08:08 --> Router Class Initialized
DEBUG - 2011-07-24 16:08:08 --> No URI present. Default controller set.
DEBUG - 2011-07-24 16:08:09 --> Output Class Initialized
DEBUG - 2011-07-24 16:08:09 --> Input Class Initialized
DEBUG - 2011-07-24 16:08:09 --> Global POST and COOKIE data sanitized
DEBUG - 2011-07-24 16:08:09 --> Language Class Initialized
DEBUG - 2011-07-24 16:08:09 --> Loader Class Initialized
DEBUG - 2011-07-24 16:08:09 --> Controller Class Initialized
DEBUG - 2011-07-24 16:08:09 --> File loaded: application/views/splash/main.php
DEBUG - 2011-07-24 16:08:09 --> Helper loaded: url_helper
DEBUG - 2011-07-24 16:08:09 --> File loaded: application/views/common/header.php
DEBUG - 2011-07-24 16:08:09 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-07-24 16:08:09 --> File loaded: application/views/common/footer.php
DEBUG - 2011-07-24 16:08:09 --> File loaded: application/views/layout/main.php
DEBUG - 2011-07-24 16:08:09 --> Final output sent to browser
DEBUG - 2011-07-24 16:08:09 --> Total execution time: 0.2646
DEBUG - 2011-07-24 16:16:57 --> Config Class Initialized
DEBUG - 2011-07-24 16:16:57 --> Hooks Class Initialized
DEBUG - 2011-07-24 16:16:57 --> Utf8 Class Initialized
DEBUG - 2011-07-24 16:16:57 --> UTF-8 Support Enabled
DEBUG - 2011-07-24 16:16:57 --> URI Class Initialized
DEBUG - 2011-07-24 16:16:57 --> Router Class Initialized
DEBUG - 2011-07-24 16:16:57 --> Output Class Initialized
DEBUG - 2011-07-24 16:16:57 --> Input Class Initialized
DEBUG - 2011-07-24 16:16:57 --> Global POST and COOKIE data sanitized
DEBUG - 2011-07-24 16:16:57 --> Language Class Initialized
DEBUG - 2011-07-24 16:16:57 --> Loader Class Initialized
DEBUG - 2011-07-24 16:16:57 --> Controller Class Initialized
DEBUG - 2011-07-24 16:16:57 --> Model Class Initialized
DEBUG - 2011-07-24 16:16:57 --> Model Class Initialized
DEBUG - 2011-07-24 16:16:57 --> Model Class Initialized
DEBUG - 2011-07-24 16:16:57 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-07-24 16:16:57 --> Database Driver Class Initialized
DEBUG - 2011-07-24 16:16:58 --> File loaded: application/views/table/main.php
DEBUG - 2011-07-24 16:16:58 --> Helper loaded: url_helper
DEBUG - 2011-07-24 16:16:58 --> File loaded: application/views/common/header.php
DEBUG - 2011-07-24 16:16:58 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-07-24 16:16:58 --> File loaded: application/views/common/footer.php
DEBUG - 2011-07-24 16:16:58 --> File loaded: application/views/layout/main.php
DEBUG - 2011-07-24 16:16:58 --> Final output sent to browser
DEBUG - 2011-07-24 16:16:58 --> Total execution time: 0.5839
DEBUG - 2011-07-24 16:17:46 --> Config Class Initialized
DEBUG - 2011-07-24 16:17:46 --> Hooks Class Initialized
DEBUG - 2011-07-24 16:17:46 --> Utf8 Class Initialized
DEBUG - 2011-07-24 16:17:46 --> UTF-8 Support Enabled
DEBUG - 2011-07-24 16:17:46 --> URI Class Initialized
DEBUG - 2011-07-24 16:17:46 --> Router Class Initialized
DEBUG - 2011-07-24 16:17:46 --> Output Class Initialized
DEBUG - 2011-07-24 16:17:46 --> Input Class Initialized
DEBUG - 2011-07-24 16:17:46 --> Global POST and COOKIE data sanitized
DEBUG - 2011-07-24 16:17:46 --> Language Class Initialized
DEBUG - 2011-07-24 16:17:46 --> Loader Class Initialized
DEBUG - 2011-07-24 16:17:46 --> Controller Class Initialized
ERROR - 2011-07-24 16:17:46 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-07-24 16:17:46 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-07-24 16:17:46 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-07-24 16:17:46 --> Model Class Initialized
DEBUG - 2011-07-24 16:17:46 --> Model Class Initialized
DEBUG - 2011-07-24 16:17:46 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-07-24 16:17:46 --> Database Driver Class Initialized
DEBUG - 2011-07-24 16:17:46 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-07-24 16:17:46 --> Helper loaded: url_helper
DEBUG - 2011-07-24 16:17:46 --> File loaded: application/views/common/header.php
DEBUG - 2011-07-24 16:17:46 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-07-24 16:17:46 --> File loaded: application/views/common/footer.php
DEBUG - 2011-07-24 16:17:46 --> File loaded: application/views/layout/main.php
DEBUG - 2011-07-24 16:17:46 --> Final output sent to browser
DEBUG - 2011-07-24 16:17:46 --> Total execution time: 0.6234
DEBUG - 2011-07-24 16:38:31 --> Config Class Initialized
DEBUG - 2011-07-24 16:38:31 --> Hooks Class Initialized
DEBUG - 2011-07-24 16:38:31 --> Utf8 Class Initialized
DEBUG - 2011-07-24 16:38:31 --> UTF-8 Support Enabled
DEBUG - 2011-07-24 16:38:31 --> URI Class Initialized
DEBUG - 2011-07-24 16:38:31 --> Router Class Initialized
DEBUG - 2011-07-24 16:38:31 --> Output Class Initialized
DEBUG - 2011-07-24 16:38:31 --> Input Class Initialized
DEBUG - 2011-07-24 16:38:31 --> Global POST and COOKIE data sanitized
DEBUG - 2011-07-24 16:38:31 --> Language Class Initialized
DEBUG - 2011-07-24 16:38:31 --> Loader Class Initialized
DEBUG - 2011-07-24 16:38:31 --> Controller Class Initialized
DEBUG - 2011-07-24 16:38:31 --> Model Class Initialized
DEBUG - 2011-07-24 16:38:32 --> Model Class Initialized
DEBUG - 2011-07-24 16:38:32 --> Model Class Initialized
DEBUG - 2011-07-24 16:38:32 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-07-24 16:38:32 --> Database Driver Class Initialized
DEBUG - 2011-07-24 16:38:32 --> File loaded: application/views/table/main.php
DEBUG - 2011-07-24 16:38:33 --> Helper loaded: url_helper
DEBUG - 2011-07-24 16:38:33 --> File loaded: application/views/common/header.php
DEBUG - 2011-07-24 16:38:33 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-07-24 16:38:33 --> File loaded: application/views/common/footer.php
DEBUG - 2011-07-24 16:38:33 --> File loaded: application/views/layout/main.php
DEBUG - 2011-07-24 16:38:33 --> Final output sent to browser
DEBUG - 2011-07-24 16:38:33 --> Total execution time: 1.1651
DEBUG - 2011-07-24 16:38:40 --> Config Class Initialized
DEBUG - 2011-07-24 16:38:40 --> Hooks Class Initialized
DEBUG - 2011-07-24 16:38:40 --> Utf8 Class Initialized
DEBUG - 2011-07-24 16:38:40 --> UTF-8 Support Enabled
DEBUG - 2011-07-24 16:38:40 --> URI Class Initialized
DEBUG - 2011-07-24 16:38:40 --> Router Class Initialized
ERROR - 2011-07-24 16:38:40 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-07-24 16:38:41 --> Config Class Initialized
DEBUG - 2011-07-24 16:38:41 --> Hooks Class Initialized
DEBUG - 2011-07-24 16:38:41 --> Utf8 Class Initialized
DEBUG - 2011-07-24 16:38:41 --> UTF-8 Support Enabled
DEBUG - 2011-07-24 16:38:41 --> URI Class Initialized
DEBUG - 2011-07-24 16:38:41 --> Router Class Initialized
ERROR - 2011-07-24 16:38:41 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-07-24 16:38:43 --> Config Class Initialized
DEBUG - 2011-07-24 16:38:43 --> Hooks Class Initialized
DEBUG - 2011-07-24 16:38:43 --> Utf8 Class Initialized
DEBUG - 2011-07-24 16:38:43 --> UTF-8 Support Enabled
DEBUG - 2011-07-24 16:38:43 --> URI Class Initialized
DEBUG - 2011-07-24 16:38:43 --> Router Class Initialized
ERROR - 2011-07-24 16:38:43 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-07-24 16:39:15 --> Config Class Initialized
DEBUG - 2011-07-24 16:39:15 --> Hooks Class Initialized
DEBUG - 2011-07-24 16:39:15 --> Utf8 Class Initialized
DEBUG - 2011-07-24 16:39:15 --> UTF-8 Support Enabled
DEBUG - 2011-07-24 16:39:15 --> URI Class Initialized
DEBUG - 2011-07-24 16:39:15 --> Router Class Initialized
DEBUG - 2011-07-24 16:39:15 --> Output Class Initialized
DEBUG - 2011-07-24 16:39:15 --> Input Class Initialized
DEBUG - 2011-07-24 16:39:15 --> Global POST and COOKIE data sanitized
DEBUG - 2011-07-24 16:39:15 --> Language Class Initialized
DEBUG - 2011-07-24 16:39:15 --> Loader Class Initialized
DEBUG - 2011-07-24 16:39:15 --> Controller Class Initialized
DEBUG - 2011-07-24 16:39:15 --> Model Class Initialized
DEBUG - 2011-07-24 16:39:15 --> Model Class Initialized
DEBUG - 2011-07-24 16:39:15 --> Model Class Initialized
DEBUG - 2011-07-24 16:39:15 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-07-24 16:39:15 --> Database Driver Class Initialized
DEBUG - 2011-07-24 16:39:15 --> File loaded: application/views/table/main.php
DEBUG - 2011-07-24 16:39:15 --> Helper loaded: url_helper
DEBUG - 2011-07-24 16:39:15 --> File loaded: application/views/common/header.php
DEBUG - 2011-07-24 16:39:15 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-07-24 16:39:15 --> File loaded: application/views/common/footer.php
DEBUG - 2011-07-24 16:39:15 --> File loaded: application/views/layout/main.php
DEBUG - 2011-07-24 16:39:15 --> Final output sent to browser
DEBUG - 2011-07-24 16:39:15 --> Total execution time: 0.2435
DEBUG - 2011-07-24 16:39:18 --> Config Class Initialized
DEBUG - 2011-07-24 16:39:18 --> Hooks Class Initialized
DEBUG - 2011-07-24 16:39:18 --> Utf8 Class Initialized
DEBUG - 2011-07-24 16:39:18 --> UTF-8 Support Enabled
DEBUG - 2011-07-24 16:39:18 --> URI Class Initialized
DEBUG - 2011-07-24 16:39:18 --> Router Class Initialized
ERROR - 2011-07-24 16:39:18 --> 404 Page Not Found --> robots.txt
DEBUG - 2011-07-24 16:39:18 --> Config Class Initialized
DEBUG - 2011-07-24 16:39:18 --> Hooks Class Initialized
DEBUG - 2011-07-24 16:39:18 --> Utf8 Class Initialized
DEBUG - 2011-07-24 16:39:18 --> UTF-8 Support Enabled
DEBUG - 2011-07-24 16:39:18 --> URI Class Initialized
DEBUG - 2011-07-24 16:39:18 --> Router Class Initialized
DEBUG - 2011-07-24 16:39:18 --> Output Class Initialized
DEBUG - 2011-07-24 16:39:18 --> Input Class Initialized
DEBUG - 2011-07-24 16:39:18 --> Global POST and COOKIE data sanitized
DEBUG - 2011-07-24 16:39:18 --> Language Class Initialized
DEBUG - 2011-07-24 16:39:18 --> Loader Class Initialized
DEBUG - 2011-07-24 16:39:18 --> Controller Class Initialized
DEBUG - 2011-07-24 16:39:18 --> Model Class Initialized
DEBUG - 2011-07-24 16:39:18 --> Model Class Initialized
DEBUG - 2011-07-24 16:39:18 --> Model Class Initialized
DEBUG - 2011-07-24 16:39:18 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-07-24 16:39:18 --> Database Driver Class Initialized
DEBUG - 2011-07-24 16:39:18 --> File loaded: application/views/table/main.php
DEBUG - 2011-07-24 16:39:18 --> Helper loaded: url_helper
DEBUG - 2011-07-24 16:39:18 --> File loaded: application/views/common/header.php
DEBUG - 2011-07-24 16:39:18 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-07-24 16:39:18 --> File loaded: application/views/common/footer.php
DEBUG - 2011-07-24 16:39:18 --> File loaded: application/views/layout/main.php
DEBUG - 2011-07-24 16:39:18 --> Final output sent to browser
DEBUG - 2011-07-24 16:39:18 --> Total execution time: 0.0476
DEBUG - 2011-07-24 16:39:25 --> Config Class Initialized
DEBUG - 2011-07-24 16:39:25 --> Hooks Class Initialized
DEBUG - 2011-07-24 16:39:25 --> Utf8 Class Initialized
DEBUG - 2011-07-24 16:39:25 --> UTF-8 Support Enabled
DEBUG - 2011-07-24 16:39:25 --> URI Class Initialized
DEBUG - 2011-07-24 16:39:25 --> Router Class Initialized
DEBUG - 2011-07-24 16:39:25 --> Output Class Initialized
DEBUG - 2011-07-24 16:39:25 --> Input Class Initialized
DEBUG - 2011-07-24 16:39:25 --> Global POST and COOKIE data sanitized
DEBUG - 2011-07-24 16:39:25 --> Language Class Initialized
DEBUG - 2011-07-24 16:39:25 --> Loader Class Initialized
DEBUG - 2011-07-24 16:39:25 --> Controller Class Initialized
DEBUG - 2011-07-24 16:39:25 --> Model Class Initialized
DEBUG - 2011-07-24 16:39:25 --> Model Class Initialized
DEBUG - 2011-07-24 16:39:25 --> Model Class Initialized
DEBUG - 2011-07-24 16:39:25 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-07-24 16:39:25 --> Database Driver Class Initialized
DEBUG - 2011-07-24 16:39:26 --> File loaded: application/views/table/main.php
DEBUG - 2011-07-24 16:39:26 --> Helper loaded: url_helper
DEBUG - 2011-07-24 16:39:26 --> File loaded: application/views/common/header.php
DEBUG - 2011-07-24 16:39:26 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-07-24 16:39:26 --> File loaded: application/views/common/footer.php
DEBUG - 2011-07-24 16:39:26 --> File loaded: application/views/layout/main.php
DEBUG - 2011-07-24 16:39:26 --> Final output sent to browser
DEBUG - 2011-07-24 16:39:26 --> Total execution time: 0.2094
DEBUG - 2011-07-24 16:39:28 --> Config Class Initialized
DEBUG - 2011-07-24 16:39:28 --> Hooks Class Initialized
DEBUG - 2011-07-24 16:39:28 --> Utf8 Class Initialized
DEBUG - 2011-07-24 16:39:28 --> UTF-8 Support Enabled
DEBUG - 2011-07-24 16:39:28 --> URI Class Initialized
DEBUG - 2011-07-24 16:39:28 --> Router Class Initialized
DEBUG - 2011-07-24 16:39:28 --> Output Class Initialized
DEBUG - 2011-07-24 16:39:28 --> Input Class Initialized
DEBUG - 2011-07-24 16:39:28 --> Global POST and COOKIE data sanitized
DEBUG - 2011-07-24 16:39:28 --> Language Class Initialized
DEBUG - 2011-07-24 16:39:28 --> Loader Class Initialized
DEBUG - 2011-07-24 16:39:28 --> Controller Class Initialized
DEBUG - 2011-07-24 16:39:28 --> Model Class Initialized
DEBUG - 2011-07-24 16:39:28 --> Model Class Initialized
DEBUG - 2011-07-24 16:39:28 --> Model Class Initialized
DEBUG - 2011-07-24 16:39:28 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-07-24 16:39:28 --> Database Driver Class Initialized
DEBUG - 2011-07-24 16:39:28 --> File loaded: application/views/table/main.php
DEBUG - 2011-07-24 16:39:28 --> Helper loaded: url_helper
DEBUG - 2011-07-24 16:39:28 --> File loaded: application/views/common/header.php
DEBUG - 2011-07-24 16:39:28 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-07-24 16:39:28 --> File loaded: application/views/common/footer.php
DEBUG - 2011-07-24 16:39:28 --> File loaded: application/views/layout/main.php
DEBUG - 2011-07-24 16:39:28 --> Final output sent to browser
DEBUG - 2011-07-24 16:39:28 --> Total execution time: 0.0453
DEBUG - 2011-07-24 16:39:33 --> Config Class Initialized
DEBUG - 2011-07-24 16:39:33 --> Hooks Class Initialized
DEBUG - 2011-07-24 16:39:33 --> Utf8 Class Initialized
DEBUG - 2011-07-24 16:39:33 --> UTF-8 Support Enabled
DEBUG - 2011-07-24 16:39:33 --> URI Class Initialized
DEBUG - 2011-07-24 16:39:33 --> Router Class Initialized
DEBUG - 2011-07-24 16:39:33 --> Output Class Initialized
DEBUG - 2011-07-24 16:39:33 --> Input Class Initialized
DEBUG - 2011-07-24 16:39:33 --> Global POST and COOKIE data sanitized
DEBUG - 2011-07-24 16:39:33 --> Language Class Initialized
DEBUG - 2011-07-24 16:39:33 --> Loader Class Initialized
DEBUG - 2011-07-24 16:39:33 --> Controller Class Initialized
DEBUG - 2011-07-24 16:39:33 --> Model Class Initialized
DEBUG - 2011-07-24 16:39:33 --> Model Class Initialized
DEBUG - 2011-07-24 16:39:33 --> Model Class Initialized
DEBUG - 2011-07-24 16:39:33 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-07-24 16:39:33 --> Database Driver Class Initialized
DEBUG - 2011-07-24 16:39:33 --> File loaded: application/views/table/main.php
DEBUG - 2011-07-24 16:39:33 --> Helper loaded: url_helper
DEBUG - 2011-07-24 16:39:33 --> File loaded: application/views/common/header.php
DEBUG - 2011-07-24 16:39:33 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-07-24 16:39:33 --> File loaded: application/views/common/footer.php
DEBUG - 2011-07-24 16:39:33 --> File loaded: application/views/layout/main.php
DEBUG - 2011-07-24 16:39:33 --> Final output sent to browser
DEBUG - 2011-07-24 16:39:33 --> Total execution time: 0.3341
DEBUG - 2011-07-24 16:39:36 --> Config Class Initialized
DEBUG - 2011-07-24 16:39:36 --> Hooks Class Initialized
DEBUG - 2011-07-24 16:39:36 --> Utf8 Class Initialized
DEBUG - 2011-07-24 16:39:36 --> UTF-8 Support Enabled
DEBUG - 2011-07-24 16:39:36 --> URI Class Initialized
DEBUG - 2011-07-24 16:39:36 --> Router Class Initialized
DEBUG - 2011-07-24 16:39:36 --> Output Class Initialized
DEBUG - 2011-07-24 16:39:36 --> Input Class Initialized
DEBUG - 2011-07-24 16:39:36 --> Global POST and COOKIE data sanitized
DEBUG - 2011-07-24 16:39:36 --> Language Class Initialized
DEBUG - 2011-07-24 16:39:36 --> Loader Class Initialized
DEBUG - 2011-07-24 16:39:36 --> Controller Class Initialized
DEBUG - 2011-07-24 16:39:36 --> Model Class Initialized
DEBUG - 2011-07-24 16:39:36 --> Model Class Initialized
DEBUG - 2011-07-24 16:39:36 --> Model Class Initialized
DEBUG - 2011-07-24 16:39:36 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-07-24 16:39:36 --> Database Driver Class Initialized
DEBUG - 2011-07-24 16:39:36 --> File loaded: application/views/table/main.php
DEBUG - 2011-07-24 16:39:36 --> Helper loaded: url_helper
DEBUG - 2011-07-24 16:39:36 --> File loaded: application/views/common/header.php
DEBUG - 2011-07-24 16:39:36 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-07-24 16:39:36 --> File loaded: application/views/common/footer.php
DEBUG - 2011-07-24 16:39:36 --> File loaded: application/views/layout/main.php
DEBUG - 2011-07-24 16:39:36 --> Final output sent to browser
DEBUG - 2011-07-24 16:39:36 --> Total execution time: 0.0526
DEBUG - 2011-07-24 16:39:40 --> Config Class Initialized
DEBUG - 2011-07-24 16:39:40 --> Hooks Class Initialized
DEBUG - 2011-07-24 16:39:40 --> Utf8 Class Initialized
DEBUG - 2011-07-24 16:39:40 --> UTF-8 Support Enabled
DEBUG - 2011-07-24 16:39:40 --> URI Class Initialized
DEBUG - 2011-07-24 16:39:40 --> Router Class Initialized
DEBUG - 2011-07-24 16:39:40 --> Output Class Initialized
DEBUG - 2011-07-24 16:39:40 --> Input Class Initialized
DEBUG - 2011-07-24 16:39:40 --> Global POST and COOKIE data sanitized
DEBUG - 2011-07-24 16:39:40 --> Language Class Initialized
DEBUG - 2011-07-24 16:39:40 --> Loader Class Initialized
DEBUG - 2011-07-24 16:39:40 --> Controller Class Initialized
DEBUG - 2011-07-24 16:39:40 --> Model Class Initialized
DEBUG - 2011-07-24 16:39:40 --> Model Class Initialized
DEBUG - 2011-07-24 16:39:40 --> Model Class Initialized
DEBUG - 2011-07-24 16:39:40 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-07-24 16:39:40 --> Database Driver Class Initialized
DEBUG - 2011-07-24 16:39:40 --> File loaded: application/views/table/main.php
DEBUG - 2011-07-24 16:39:40 --> Helper loaded: url_helper
DEBUG - 2011-07-24 16:39:40 --> File loaded: application/views/common/header.php
DEBUG - 2011-07-24 16:39:40 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-07-24 16:39:40 --> File loaded: application/views/common/footer.php
DEBUG - 2011-07-24 16:39:40 --> File loaded: application/views/layout/main.php
DEBUG - 2011-07-24 16:39:40 --> Final output sent to browser
DEBUG - 2011-07-24 16:39:40 --> Total execution time: 0.2217
DEBUG - 2011-07-24 16:39:41 --> Config Class Initialized
DEBUG - 2011-07-24 16:39:41 --> Hooks Class Initialized
DEBUG - 2011-07-24 16:39:41 --> Utf8 Class Initialized
DEBUG - 2011-07-24 16:39:41 --> UTF-8 Support Enabled
DEBUG - 2011-07-24 16:39:41 --> URI Class Initialized
DEBUG - 2011-07-24 16:39:41 --> Router Class Initialized
DEBUG - 2011-07-24 16:39:41 --> Output Class Initialized
DEBUG - 2011-07-24 16:39:41 --> Input Class Initialized
DEBUG - 2011-07-24 16:39:41 --> Global POST and COOKIE data sanitized
DEBUG - 2011-07-24 16:39:41 --> Language Class Initialized
DEBUG - 2011-07-24 16:39:41 --> Loader Class Initialized
DEBUG - 2011-07-24 16:39:41 --> Controller Class Initialized
DEBUG - 2011-07-24 16:39:41 --> Model Class Initialized
DEBUG - 2011-07-24 16:39:41 --> Model Class Initialized
DEBUG - 2011-07-24 16:39:41 --> Model Class Initialized
DEBUG - 2011-07-24 16:39:41 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-07-24 16:39:41 --> Database Driver Class Initialized
DEBUG - 2011-07-24 16:39:41 --> File loaded: application/views/table/main.php
DEBUG - 2011-07-24 16:39:41 --> Helper loaded: url_helper
DEBUG - 2011-07-24 16:39:41 --> File loaded: application/views/common/header.php
DEBUG - 2011-07-24 16:39:41 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-07-24 16:39:41 --> File loaded: application/views/common/footer.php
DEBUG - 2011-07-24 16:39:41 --> File loaded: application/views/layout/main.php
DEBUG - 2011-07-24 16:39:41 --> Final output sent to browser
DEBUG - 2011-07-24 16:39:41 --> Total execution time: 0.0589
DEBUG - 2011-07-24 16:39:46 --> Config Class Initialized
DEBUG - 2011-07-24 16:39:46 --> Hooks Class Initialized
DEBUG - 2011-07-24 16:39:46 --> Utf8 Class Initialized
DEBUG - 2011-07-24 16:39:46 --> UTF-8 Support Enabled
DEBUG - 2011-07-24 16:39:46 --> URI Class Initialized
DEBUG - 2011-07-24 16:39:46 --> Router Class Initialized
DEBUG - 2011-07-24 16:39:46 --> Output Class Initialized
DEBUG - 2011-07-24 16:39:46 --> Input Class Initialized
DEBUG - 2011-07-24 16:39:46 --> Global POST and COOKIE data sanitized
DEBUG - 2011-07-24 16:39:46 --> Language Class Initialized
DEBUG - 2011-07-24 16:39:46 --> Loader Class Initialized
DEBUG - 2011-07-24 16:39:46 --> Controller Class Initialized
DEBUG - 2011-07-24 16:39:46 --> Model Class Initialized
DEBUG - 2011-07-24 16:39:46 --> Model Class Initialized
DEBUG - 2011-07-24 16:39:46 --> Model Class Initialized
DEBUG - 2011-07-24 16:39:46 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-07-24 16:39:46 --> Database Driver Class Initialized
DEBUG - 2011-07-24 16:39:46 --> File loaded: application/views/table/main.php
DEBUG - 2011-07-24 16:39:46 --> Helper loaded: url_helper
DEBUG - 2011-07-24 16:39:46 --> File loaded: application/views/common/header.php
DEBUG - 2011-07-24 16:39:46 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-07-24 16:39:46 --> File loaded: application/views/common/footer.php
DEBUG - 2011-07-24 16:39:46 --> File loaded: application/views/layout/main.php
DEBUG - 2011-07-24 16:39:46 --> Final output sent to browser
DEBUG - 2011-07-24 16:39:46 --> Total execution time: 0.2047
DEBUG - 2011-07-24 16:39:54 --> Config Class Initialized
DEBUG - 2011-07-24 16:39:54 --> Hooks Class Initialized
DEBUG - 2011-07-24 16:39:54 --> Utf8 Class Initialized
DEBUG - 2011-07-24 16:39:54 --> UTF-8 Support Enabled
DEBUG - 2011-07-24 16:39:54 --> URI Class Initialized
DEBUG - 2011-07-24 16:39:54 --> Router Class Initialized
DEBUG - 2011-07-24 16:39:54 --> Output Class Initialized
DEBUG - 2011-07-24 16:39:54 --> Input Class Initialized
DEBUG - 2011-07-24 16:39:54 --> Global POST and COOKIE data sanitized
DEBUG - 2011-07-24 16:39:54 --> Language Class Initialized
DEBUG - 2011-07-24 16:39:54 --> Loader Class Initialized
DEBUG - 2011-07-24 16:39:54 --> Controller Class Initialized
DEBUG - 2011-07-24 16:39:54 --> Model Class Initialized
DEBUG - 2011-07-24 16:39:54 --> Model Class Initialized
DEBUG - 2011-07-24 16:39:54 --> Model Class Initialized
DEBUG - 2011-07-24 16:39:54 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-07-24 16:39:54 --> Database Driver Class Initialized
DEBUG - 2011-07-24 16:39:55 --> File loaded: application/views/table/main.php
DEBUG - 2011-07-24 16:39:55 --> Helper loaded: url_helper
DEBUG - 2011-07-24 16:39:55 --> File loaded: application/views/common/header.php
DEBUG - 2011-07-24 16:39:55 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-07-24 16:39:55 --> File loaded: application/views/common/footer.php
DEBUG - 2011-07-24 16:39:55 --> File loaded: application/views/layout/main.php
DEBUG - 2011-07-24 16:39:55 --> Final output sent to browser
DEBUG - 2011-07-24 16:39:55 --> Total execution time: 0.2619
DEBUG - 2011-07-24 16:40:05 --> Config Class Initialized
DEBUG - 2011-07-24 16:40:05 --> Hooks Class Initialized
DEBUG - 2011-07-24 16:40:05 --> Utf8 Class Initialized
DEBUG - 2011-07-24 16:40:05 --> UTF-8 Support Enabled
DEBUG - 2011-07-24 16:40:05 --> URI Class Initialized
DEBUG - 2011-07-24 16:40:05 --> Router Class Initialized
DEBUG - 2011-07-24 16:40:05 --> Output Class Initialized
DEBUG - 2011-07-24 16:40:05 --> Input Class Initialized
DEBUG - 2011-07-24 16:40:05 --> Global POST and COOKIE data sanitized
DEBUG - 2011-07-24 16:40:05 --> Language Class Initialized
DEBUG - 2011-07-24 16:40:05 --> Loader Class Initialized
DEBUG - 2011-07-24 16:40:05 --> Controller Class Initialized
DEBUG - 2011-07-24 16:40:05 --> Model Class Initialized
DEBUG - 2011-07-24 16:40:05 --> Model Class Initialized
DEBUG - 2011-07-24 16:40:05 --> Model Class Initialized
DEBUG - 2011-07-24 16:40:05 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-07-24 16:40:06 --> Database Driver Class Initialized
DEBUG - 2011-07-24 16:40:06 --> File loaded: application/views/table/main.php
DEBUG - 2011-07-24 16:40:06 --> Helper loaded: url_helper
DEBUG - 2011-07-24 16:40:06 --> File loaded: application/views/common/header.php
DEBUG - 2011-07-24 16:40:06 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-07-24 16:40:06 --> File loaded: application/views/common/footer.php
DEBUG - 2011-07-24 16:40:06 --> File loaded: application/views/layout/main.php
DEBUG - 2011-07-24 16:40:06 --> Final output sent to browser
DEBUG - 2011-07-24 16:40:06 --> Total execution time: 0.3838
DEBUG - 2011-07-24 16:40:19 --> Config Class Initialized
DEBUG - 2011-07-24 16:40:19 --> Hooks Class Initialized
DEBUG - 2011-07-24 16:40:19 --> Utf8 Class Initialized
DEBUG - 2011-07-24 16:40:19 --> UTF-8 Support Enabled
DEBUG - 2011-07-24 16:40:19 --> URI Class Initialized
DEBUG - 2011-07-24 16:40:19 --> Router Class Initialized
DEBUG - 2011-07-24 16:40:19 --> Output Class Initialized
DEBUG - 2011-07-24 16:40:19 --> Input Class Initialized
DEBUG - 2011-07-24 16:40:19 --> Global POST and COOKIE data sanitized
DEBUG - 2011-07-24 16:40:19 --> Language Class Initialized
DEBUG - 2011-07-24 16:40:19 --> Loader Class Initialized
DEBUG - 2011-07-24 16:40:19 --> Controller Class Initialized
DEBUG - 2011-07-24 16:40:19 --> Model Class Initialized
DEBUG - 2011-07-24 16:40:19 --> Model Class Initialized
DEBUG - 2011-07-24 16:40:19 --> Model Class Initialized
DEBUG - 2011-07-24 16:40:19 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-07-24 16:40:19 --> Database Driver Class Initialized
DEBUG - 2011-07-24 16:40:19 --> File loaded: application/views/table/main.php
DEBUG - 2011-07-24 16:40:19 --> Helper loaded: url_helper
DEBUG - 2011-07-24 16:40:19 --> File loaded: application/views/common/header.php
DEBUG - 2011-07-24 16:40:19 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-07-24 16:40:19 --> File loaded: application/views/common/footer.php
DEBUG - 2011-07-24 16:40:19 --> File loaded: application/views/layout/main.php
DEBUG - 2011-07-24 16:40:19 --> Final output sent to browser
DEBUG - 2011-07-24 16:40:19 --> Total execution time: 0.2983
DEBUG - 2011-07-24 16:40:36 --> Config Class Initialized
DEBUG - 2011-07-24 16:40:36 --> Hooks Class Initialized
DEBUG - 2011-07-24 16:40:36 --> Utf8 Class Initialized
DEBUG - 2011-07-24 16:40:36 --> UTF-8 Support Enabled
DEBUG - 2011-07-24 16:40:36 --> URI Class Initialized
DEBUG - 2011-07-24 16:40:36 --> Router Class Initialized
DEBUG - 2011-07-24 16:40:36 --> Output Class Initialized
DEBUG - 2011-07-24 16:40:36 --> Input Class Initialized
DEBUG - 2011-07-24 16:40:36 --> Global POST and COOKIE data sanitized
DEBUG - 2011-07-24 16:40:36 --> Language Class Initialized
DEBUG - 2011-07-24 16:40:36 --> Loader Class Initialized
DEBUG - 2011-07-24 16:40:36 --> Controller Class Initialized
DEBUG - 2011-07-24 16:40:36 --> Model Class Initialized
DEBUG - 2011-07-24 16:40:36 --> Model Class Initialized
DEBUG - 2011-07-24 16:40:36 --> Model Class Initialized
DEBUG - 2011-07-24 16:40:36 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-07-24 16:40:36 --> Database Driver Class Initialized
DEBUG - 2011-07-24 16:40:36 --> File loaded: application/views/table/main.php
DEBUG - 2011-07-24 16:40:36 --> Helper loaded: url_helper
DEBUG - 2011-07-24 16:40:36 --> File loaded: application/views/common/header.php
DEBUG - 2011-07-24 16:40:36 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-07-24 16:40:36 --> File loaded: application/views/common/footer.php
DEBUG - 2011-07-24 16:40:36 --> File loaded: application/views/layout/main.php
DEBUG - 2011-07-24 16:40:36 --> Final output sent to browser
DEBUG - 2011-07-24 16:40:36 --> Total execution time: 0.3276
DEBUG - 2011-07-24 16:40:47 --> Config Class Initialized
DEBUG - 2011-07-24 16:40:47 --> Hooks Class Initialized
DEBUG - 2011-07-24 16:40:47 --> Utf8 Class Initialized
DEBUG - 2011-07-24 16:40:47 --> UTF-8 Support Enabled
DEBUG - 2011-07-24 16:40:47 --> URI Class Initialized
DEBUG - 2011-07-24 16:40:47 --> Router Class Initialized
DEBUG - 2011-07-24 16:40:47 --> Output Class Initialized
DEBUG - 2011-07-24 16:40:47 --> Input Class Initialized
DEBUG - 2011-07-24 16:40:47 --> Global POST and COOKIE data sanitized
DEBUG - 2011-07-24 16:40:47 --> Language Class Initialized
DEBUG - 2011-07-24 16:40:47 --> Loader Class Initialized
DEBUG - 2011-07-24 16:40:47 --> Controller Class Initialized
DEBUG - 2011-07-24 16:40:47 --> Model Class Initialized
DEBUG - 2011-07-24 16:40:47 --> Model Class Initialized
DEBUG - 2011-07-24 16:40:47 --> Model Class Initialized
DEBUG - 2011-07-24 16:40:47 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-07-24 16:40:47 --> Database Driver Class Initialized
DEBUG - 2011-07-24 16:40:47 --> File loaded: application/views/table/main.php
DEBUG - 2011-07-24 16:40:47 --> Helper loaded: url_helper
DEBUG - 2011-07-24 16:40:47 --> File loaded: application/views/common/header.php
DEBUG - 2011-07-24 16:40:47 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-07-24 16:40:47 --> File loaded: application/views/common/footer.php
DEBUG - 2011-07-24 16:40:47 --> File loaded: application/views/layout/main.php
DEBUG - 2011-07-24 16:40:47 --> Final output sent to browser
DEBUG - 2011-07-24 16:40:47 --> Total execution time: 0.1497
DEBUG - 2011-07-24 16:40:50 --> Config Class Initialized
DEBUG - 2011-07-24 16:40:50 --> Hooks Class Initialized
DEBUG - 2011-07-24 16:40:50 --> Utf8 Class Initialized
DEBUG - 2011-07-24 16:40:50 --> UTF-8 Support Enabled
DEBUG - 2011-07-24 16:40:50 --> URI Class Initialized
DEBUG - 2011-07-24 16:40:50 --> Router Class Initialized
DEBUG - 2011-07-24 16:40:50 --> Output Class Initialized
DEBUG - 2011-07-24 16:40:50 --> Input Class Initialized
DEBUG - 2011-07-24 16:40:50 --> Global POST and COOKIE data sanitized
DEBUG - 2011-07-24 16:40:50 --> Language Class Initialized
DEBUG - 2011-07-24 16:40:50 --> Loader Class Initialized
DEBUG - 2011-07-24 16:40:50 --> Controller Class Initialized
DEBUG - 2011-07-24 16:40:50 --> Model Class Initialized
DEBUG - 2011-07-24 16:40:50 --> Model Class Initialized
DEBUG - 2011-07-24 16:40:50 --> Model Class Initialized
DEBUG - 2011-07-24 16:40:50 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-07-24 16:40:50 --> Database Driver Class Initialized
DEBUG - 2011-07-24 16:40:50 --> File loaded: application/views/table/main.php
DEBUG - 2011-07-24 16:40:50 --> Helper loaded: url_helper
DEBUG - 2011-07-24 16:40:50 --> File loaded: application/views/common/header.php
DEBUG - 2011-07-24 16:40:50 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-07-24 16:40:50 --> File loaded: application/views/common/footer.php
DEBUG - 2011-07-24 16:40:50 --> File loaded: application/views/layout/main.php
DEBUG - 2011-07-24 16:40:50 --> Final output sent to browser
DEBUG - 2011-07-24 16:40:50 --> Total execution time: 0.0749
DEBUG - 2011-07-24 16:40:50 --> Config Class Initialized
DEBUG - 2011-07-24 16:40:50 --> Hooks Class Initialized
DEBUG - 2011-07-24 16:40:50 --> Utf8 Class Initialized
DEBUG - 2011-07-24 16:40:50 --> UTF-8 Support Enabled
DEBUG - 2011-07-24 16:40:50 --> URI Class Initialized
DEBUG - 2011-07-24 16:40:50 --> Router Class Initialized
DEBUG - 2011-07-24 16:40:50 --> Output Class Initialized
DEBUG - 2011-07-24 16:40:50 --> Input Class Initialized
DEBUG - 2011-07-24 16:40:50 --> Global POST and COOKIE data sanitized
DEBUG - 2011-07-24 16:40:50 --> Language Class Initialized
DEBUG - 2011-07-24 16:40:50 --> Loader Class Initialized
DEBUG - 2011-07-24 16:40:50 --> Controller Class Initialized
DEBUG - 2011-07-24 16:40:50 --> Model Class Initialized
DEBUG - 2011-07-24 16:40:50 --> Model Class Initialized
DEBUG - 2011-07-24 16:40:50 --> Model Class Initialized
DEBUG - 2011-07-24 16:40:50 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-07-24 16:40:51 --> Database Driver Class Initialized
DEBUG - 2011-07-24 16:40:51 --> File loaded: application/views/table/main.php
DEBUG - 2011-07-24 16:40:51 --> Helper loaded: url_helper
DEBUG - 2011-07-24 16:40:51 --> File loaded: application/views/common/header.php
DEBUG - 2011-07-24 16:40:51 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-07-24 16:40:51 --> File loaded: application/views/common/footer.php
DEBUG - 2011-07-24 16:40:51 --> File loaded: application/views/layout/main.php
DEBUG - 2011-07-24 16:40:51 --> Final output sent to browser
DEBUG - 2011-07-24 16:40:51 --> Total execution time: 0.0544
DEBUG - 2011-07-24 16:40:52 --> Config Class Initialized
DEBUG - 2011-07-24 16:40:52 --> Hooks Class Initialized
DEBUG - 2011-07-24 16:40:52 --> Utf8 Class Initialized
DEBUG - 2011-07-24 16:40:52 --> UTF-8 Support Enabled
DEBUG - 2011-07-24 16:40:52 --> URI Class Initialized
DEBUG - 2011-07-24 16:40:52 --> Router Class Initialized
DEBUG - 2011-07-24 16:40:52 --> Output Class Initialized
DEBUG - 2011-07-24 16:40:52 --> Input Class Initialized
DEBUG - 2011-07-24 16:40:52 --> Global POST and COOKIE data sanitized
DEBUG - 2011-07-24 16:40:52 --> Language Class Initialized
DEBUG - 2011-07-24 16:40:52 --> Loader Class Initialized
DEBUG - 2011-07-24 16:40:52 --> Controller Class Initialized
DEBUG - 2011-07-24 16:40:52 --> Model Class Initialized
DEBUG - 2011-07-24 16:40:52 --> Model Class Initialized
DEBUG - 2011-07-24 16:40:52 --> Model Class Initialized
DEBUG - 2011-07-24 16:40:52 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-07-24 16:40:52 --> Database Driver Class Initialized
DEBUG - 2011-07-24 16:40:52 --> File loaded: application/views/table/main.php
DEBUG - 2011-07-24 16:40:52 --> Helper loaded: url_helper
DEBUG - 2011-07-24 16:40:52 --> File loaded: application/views/common/header.php
DEBUG - 2011-07-24 16:40:52 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-07-24 16:40:52 --> File loaded: application/views/common/footer.php
DEBUG - 2011-07-24 16:40:52 --> File loaded: application/views/layout/main.php
DEBUG - 2011-07-24 16:40:52 --> Final output sent to browser
DEBUG - 2011-07-24 16:40:52 --> Total execution time: 0.0473
DEBUG - 2011-07-24 16:40:59 --> Config Class Initialized
DEBUG - 2011-07-24 16:40:59 --> Hooks Class Initialized
DEBUG - 2011-07-24 16:40:59 --> Utf8 Class Initialized
DEBUG - 2011-07-24 16:40:59 --> UTF-8 Support Enabled
DEBUG - 2011-07-24 16:40:59 --> URI Class Initialized
DEBUG - 2011-07-24 16:40:59 --> Router Class Initialized
DEBUG - 2011-07-24 16:40:59 --> Output Class Initialized
DEBUG - 2011-07-24 16:40:59 --> Input Class Initialized
DEBUG - 2011-07-24 16:40:59 --> Global POST and COOKIE data sanitized
DEBUG - 2011-07-24 16:40:59 --> Language Class Initialized
DEBUG - 2011-07-24 16:40:59 --> Loader Class Initialized
DEBUG - 2011-07-24 16:40:59 --> Controller Class Initialized
DEBUG - 2011-07-24 16:40:59 --> Model Class Initialized
DEBUG - 2011-07-24 16:40:59 --> Model Class Initialized
DEBUG - 2011-07-24 16:40:59 --> Model Class Initialized
DEBUG - 2011-07-24 16:40:59 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-07-24 16:40:59 --> Database Driver Class Initialized
DEBUG - 2011-07-24 16:41:00 --> File loaded: application/views/table/main.php
DEBUG - 2011-07-24 16:41:00 --> Helper loaded: url_helper
DEBUG - 2011-07-24 16:41:00 --> File loaded: application/views/common/header.php
DEBUG - 2011-07-24 16:41:00 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-07-24 16:41:00 --> File loaded: application/views/common/footer.php
DEBUG - 2011-07-24 16:41:00 --> File loaded: application/views/layout/main.php
DEBUG - 2011-07-24 16:41:00 --> Final output sent to browser
DEBUG - 2011-07-24 16:41:00 --> Total execution time: 0.2685
DEBUG - 2011-07-24 16:41:09 --> Config Class Initialized
DEBUG - 2011-07-24 16:41:09 --> Hooks Class Initialized
DEBUG - 2011-07-24 16:41:09 --> Utf8 Class Initialized
DEBUG - 2011-07-24 16:41:09 --> UTF-8 Support Enabled
DEBUG - 2011-07-24 16:41:09 --> URI Class Initialized
DEBUG - 2011-07-24 16:41:09 --> Router Class Initialized
DEBUG - 2011-07-24 16:41:09 --> Output Class Initialized
DEBUG - 2011-07-24 16:41:09 --> Input Class Initialized
DEBUG - 2011-07-24 16:41:09 --> Global POST and COOKIE data sanitized
DEBUG - 2011-07-24 16:41:09 --> Language Class Initialized
DEBUG - 2011-07-24 16:41:09 --> Loader Class Initialized
DEBUG - 2011-07-24 16:41:09 --> Controller Class Initialized
DEBUG - 2011-07-24 16:41:09 --> Model Class Initialized
DEBUG - 2011-07-24 16:41:09 --> Model Class Initialized
DEBUG - 2011-07-24 16:41:09 --> Model Class Initialized
DEBUG - 2011-07-24 16:41:09 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-07-24 16:41:09 --> Database Driver Class Initialized
DEBUG - 2011-07-24 16:41:09 --> File loaded: application/views/table/main.php
DEBUG - 2011-07-24 16:41:09 --> Helper loaded: url_helper
DEBUG - 2011-07-24 16:41:09 --> File loaded: application/views/common/header.php
DEBUG - 2011-07-24 16:41:09 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-07-24 16:41:09 --> File loaded: application/views/common/footer.php
DEBUG - 2011-07-24 16:41:09 --> File loaded: application/views/layout/main.php
DEBUG - 2011-07-24 16:41:09 --> Final output sent to browser
DEBUG - 2011-07-24 16:41:09 --> Total execution time: 0.2159
DEBUG - 2011-07-24 16:41:10 --> Config Class Initialized
DEBUG - 2011-07-24 16:41:10 --> Hooks Class Initialized
DEBUG - 2011-07-24 16:41:10 --> Utf8 Class Initialized
DEBUG - 2011-07-24 16:41:10 --> UTF-8 Support Enabled
DEBUG - 2011-07-24 16:41:10 --> URI Class Initialized
DEBUG - 2011-07-24 16:41:10 --> Router Class Initialized
DEBUG - 2011-07-24 16:41:10 --> Output Class Initialized
DEBUG - 2011-07-24 16:41:10 --> Input Class Initialized
DEBUG - 2011-07-24 16:41:10 --> Global POST and COOKIE data sanitized
DEBUG - 2011-07-24 16:41:10 --> Language Class Initialized
DEBUG - 2011-07-24 16:41:10 --> Loader Class Initialized
DEBUG - 2011-07-24 16:41:10 --> Controller Class Initialized
DEBUG - 2011-07-24 16:41:10 --> Model Class Initialized
DEBUG - 2011-07-24 16:41:10 --> Model Class Initialized
DEBUG - 2011-07-24 16:41:10 --> Model Class Initialized
DEBUG - 2011-07-24 16:41:10 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-07-24 16:41:10 --> Database Driver Class Initialized
DEBUG - 2011-07-24 16:41:10 --> File loaded: application/views/table/main.php
DEBUG - 2011-07-24 16:41:10 --> Helper loaded: url_helper
DEBUG - 2011-07-24 16:41:10 --> File loaded: application/views/common/header.php
DEBUG - 2011-07-24 16:41:10 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-07-24 16:41:10 --> File loaded: application/views/common/footer.php
DEBUG - 2011-07-24 16:41:10 --> File loaded: application/views/layout/main.php
DEBUG - 2011-07-24 16:41:10 --> Final output sent to browser
DEBUG - 2011-07-24 16:41:10 --> Total execution time: 0.0486
DEBUG - 2011-07-24 16:41:23 --> Config Class Initialized
DEBUG - 2011-07-24 16:41:23 --> Hooks Class Initialized
DEBUG - 2011-07-24 16:41:23 --> Utf8 Class Initialized
DEBUG - 2011-07-24 16:41:23 --> UTF-8 Support Enabled
DEBUG - 2011-07-24 16:41:23 --> URI Class Initialized
DEBUG - 2011-07-24 16:41:23 --> Router Class Initialized
DEBUG - 2011-07-24 16:41:23 --> Output Class Initialized
DEBUG - 2011-07-24 16:41:23 --> Input Class Initialized
DEBUG - 2011-07-24 16:41:23 --> Global POST and COOKIE data sanitized
DEBUG - 2011-07-24 16:41:23 --> Language Class Initialized
DEBUG - 2011-07-24 16:41:23 --> Loader Class Initialized
DEBUG - 2011-07-24 16:41:23 --> Controller Class Initialized
DEBUG - 2011-07-24 16:41:23 --> Model Class Initialized
DEBUG - 2011-07-24 16:41:23 --> Model Class Initialized
DEBUG - 2011-07-24 16:41:23 --> Model Class Initialized
DEBUG - 2011-07-24 16:41:23 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-07-24 16:41:23 --> Database Driver Class Initialized
DEBUG - 2011-07-24 16:41:23 --> File loaded: application/views/table/main.php
DEBUG - 2011-07-24 16:41:23 --> Helper loaded: url_helper
DEBUG - 2011-07-24 16:41:23 --> File loaded: application/views/common/header.php
DEBUG - 2011-07-24 16:41:23 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-07-24 16:41:23 --> File loaded: application/views/common/footer.php
DEBUG - 2011-07-24 16:41:23 --> File loaded: application/views/layout/main.php
DEBUG - 2011-07-24 16:41:23 --> Final output sent to browser
DEBUG - 2011-07-24 16:41:23 --> Total execution time: 0.2337
DEBUG - 2011-07-24 16:41:24 --> Config Class Initialized
DEBUG - 2011-07-24 16:41:24 --> Hooks Class Initialized
DEBUG - 2011-07-24 16:41:24 --> Utf8 Class Initialized
DEBUG - 2011-07-24 16:41:24 --> UTF-8 Support Enabled
DEBUG - 2011-07-24 16:41:24 --> URI Class Initialized
DEBUG - 2011-07-24 16:41:24 --> Router Class Initialized
DEBUG - 2011-07-24 16:41:24 --> Output Class Initialized
DEBUG - 2011-07-24 16:41:24 --> Input Class Initialized
DEBUG - 2011-07-24 16:41:24 --> Global POST and COOKIE data sanitized
DEBUG - 2011-07-24 16:41:24 --> Language Class Initialized
DEBUG - 2011-07-24 16:41:24 --> Loader Class Initialized
DEBUG - 2011-07-24 16:41:24 --> Controller Class Initialized
DEBUG - 2011-07-24 16:41:24 --> Model Class Initialized
DEBUG - 2011-07-24 16:41:24 --> Model Class Initialized
DEBUG - 2011-07-24 16:41:24 --> Model Class Initialized
DEBUG - 2011-07-24 16:41:24 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-07-24 16:41:24 --> Database Driver Class Initialized
DEBUG - 2011-07-24 16:41:24 --> File loaded: application/views/table/main.php
DEBUG - 2011-07-24 16:41:24 --> Helper loaded: url_helper
DEBUG - 2011-07-24 16:41:24 --> File loaded: application/views/common/header.php
DEBUG - 2011-07-24 16:41:24 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-07-24 16:41:24 --> File loaded: application/views/common/footer.php
DEBUG - 2011-07-24 16:41:24 --> File loaded: application/views/layout/main.php
DEBUG - 2011-07-24 16:41:24 --> Final output sent to browser
DEBUG - 2011-07-24 16:41:24 --> Total execution time: 0.0967
DEBUG - 2011-07-24 16:41:35 --> Config Class Initialized
DEBUG - 2011-07-24 16:41:35 --> Hooks Class Initialized
DEBUG - 2011-07-24 16:41:35 --> Utf8 Class Initialized
DEBUG - 2011-07-24 16:41:35 --> UTF-8 Support Enabled
DEBUG - 2011-07-24 16:41:35 --> URI Class Initialized
DEBUG - 2011-07-24 16:41:35 --> Router Class Initialized
DEBUG - 2011-07-24 16:41:35 --> Output Class Initialized
DEBUG - 2011-07-24 16:41:35 --> Input Class Initialized
DEBUG - 2011-07-24 16:41:35 --> Global POST and COOKIE data sanitized
DEBUG - 2011-07-24 16:41:35 --> Language Class Initialized
DEBUG - 2011-07-24 16:41:35 --> Loader Class Initialized
DEBUG - 2011-07-24 16:41:35 --> Controller Class Initialized
DEBUG - 2011-07-24 16:41:35 --> Model Class Initialized
DEBUG - 2011-07-24 16:41:35 --> Model Class Initialized
DEBUG - 2011-07-24 16:41:35 --> Model Class Initialized
DEBUG - 2011-07-24 16:41:35 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-07-24 16:41:35 --> Database Driver Class Initialized
DEBUG - 2011-07-24 16:41:35 --> File loaded: application/views/table/main.php
DEBUG - 2011-07-24 16:41:35 --> Helper loaded: url_helper
DEBUG - 2011-07-24 16:41:35 --> File loaded: application/views/common/header.php
DEBUG - 2011-07-24 16:41:35 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-07-24 16:41:35 --> File loaded: application/views/common/footer.php
DEBUG - 2011-07-24 16:41:35 --> File loaded: application/views/layout/main.php
DEBUG - 2011-07-24 16:41:35 --> Final output sent to browser
DEBUG - 2011-07-24 16:41:35 --> Total execution time: 0.2173
DEBUG - 2011-07-24 16:41:37 --> Config Class Initialized
DEBUG - 2011-07-24 16:41:37 --> Hooks Class Initialized
DEBUG - 2011-07-24 16:41:37 --> Utf8 Class Initialized
DEBUG - 2011-07-24 16:41:37 --> UTF-8 Support Enabled
DEBUG - 2011-07-24 16:41:37 --> URI Class Initialized
DEBUG - 2011-07-24 16:41:37 --> Router Class Initialized
DEBUG - 2011-07-24 16:41:37 --> Output Class Initialized
DEBUG - 2011-07-24 16:41:37 --> Input Class Initialized
DEBUG - 2011-07-24 16:41:37 --> Global POST and COOKIE data sanitized
DEBUG - 2011-07-24 16:41:37 --> Language Class Initialized
DEBUG - 2011-07-24 16:41:37 --> Loader Class Initialized
DEBUG - 2011-07-24 16:41:37 --> Controller Class Initialized
DEBUG - 2011-07-24 16:41:37 --> Model Class Initialized
DEBUG - 2011-07-24 16:41:37 --> Model Class Initialized
DEBUG - 2011-07-24 16:41:37 --> Model Class Initialized
DEBUG - 2011-07-24 16:41:37 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-07-24 16:41:37 --> Database Driver Class Initialized
DEBUG - 2011-07-24 16:41:37 --> File loaded: application/views/table/main.php
DEBUG - 2011-07-24 16:41:37 --> Helper loaded: url_helper
DEBUG - 2011-07-24 16:41:37 --> File loaded: application/views/common/header.php
DEBUG - 2011-07-24 16:41:37 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-07-24 16:41:37 --> File loaded: application/views/common/footer.php
DEBUG - 2011-07-24 16:41:37 --> File loaded: application/views/layout/main.php
DEBUG - 2011-07-24 16:41:37 --> Final output sent to browser
DEBUG - 2011-07-24 16:41:37 --> Total execution time: 0.0839
DEBUG - 2011-07-24 16:41:47 --> Config Class Initialized
DEBUG - 2011-07-24 16:41:47 --> Hooks Class Initialized
DEBUG - 2011-07-24 16:41:47 --> Utf8 Class Initialized
DEBUG - 2011-07-24 16:41:47 --> UTF-8 Support Enabled
DEBUG - 2011-07-24 16:41:47 --> URI Class Initialized
DEBUG - 2011-07-24 16:41:47 --> Router Class Initialized
DEBUG - 2011-07-24 16:41:47 --> Output Class Initialized
DEBUG - 2011-07-24 16:41:47 --> Input Class Initialized
DEBUG - 2011-07-24 16:41:47 --> Global POST and COOKIE data sanitized
DEBUG - 2011-07-24 16:41:47 --> Language Class Initialized
DEBUG - 2011-07-24 16:41:47 --> Loader Class Initialized
DEBUG - 2011-07-24 16:41:47 --> Controller Class Initialized
DEBUG - 2011-07-24 16:41:47 --> Model Class Initialized
DEBUG - 2011-07-24 16:41:47 --> Model Class Initialized
DEBUG - 2011-07-24 16:41:47 --> Model Class Initialized
DEBUG - 2011-07-24 16:41:47 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-07-24 16:41:47 --> Database Driver Class Initialized
DEBUG - 2011-07-24 16:41:47 --> File loaded: application/views/table/main.php
DEBUG - 2011-07-24 16:41:47 --> Helper loaded: url_helper
DEBUG - 2011-07-24 16:41:47 --> File loaded: application/views/common/header.php
DEBUG - 2011-07-24 16:41:47 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-07-24 16:41:47 --> File loaded: application/views/common/footer.php
DEBUG - 2011-07-24 16:41:47 --> File loaded: application/views/layout/main.php
DEBUG - 2011-07-24 16:41:47 --> Final output sent to browser
DEBUG - 2011-07-24 16:41:47 --> Total execution time: 0.0497
DEBUG - 2011-07-24 16:41:54 --> Config Class Initialized
DEBUG - 2011-07-24 16:41:54 --> Hooks Class Initialized
DEBUG - 2011-07-24 16:41:54 --> Utf8 Class Initialized
DEBUG - 2011-07-24 16:41:54 --> UTF-8 Support Enabled
DEBUG - 2011-07-24 16:41:54 --> URI Class Initialized
DEBUG - 2011-07-24 16:41:54 --> Router Class Initialized
DEBUG - 2011-07-24 16:41:54 --> Output Class Initialized
DEBUG - 2011-07-24 16:41:54 --> Input Class Initialized
DEBUG - 2011-07-24 16:41:54 --> Global POST and COOKIE data sanitized
DEBUG - 2011-07-24 16:41:54 --> Language Class Initialized
DEBUG - 2011-07-24 16:41:54 --> Loader Class Initialized
DEBUG - 2011-07-24 16:41:54 --> Controller Class Initialized
DEBUG - 2011-07-24 16:41:54 --> Model Class Initialized
DEBUG - 2011-07-24 16:41:54 --> Model Class Initialized
DEBUG - 2011-07-24 16:41:54 --> Model Class Initialized
DEBUG - 2011-07-24 16:41:54 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-07-24 16:41:54 --> Database Driver Class Initialized
DEBUG - 2011-07-24 16:41:54 --> File loaded: application/views/table/main.php
DEBUG - 2011-07-24 16:41:54 --> Helper loaded: url_helper
DEBUG - 2011-07-24 16:41:54 --> File loaded: application/views/common/header.php
DEBUG - 2011-07-24 16:41:54 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-07-24 16:41:54 --> File loaded: application/views/common/footer.php
DEBUG - 2011-07-24 16:41:54 --> File loaded: application/views/layout/main.php
DEBUG - 2011-07-24 16:41:54 --> Final output sent to browser
DEBUG - 2011-07-24 16:41:54 --> Total execution time: 0.0425
DEBUG - 2011-07-24 16:41:56 --> Config Class Initialized
DEBUG - 2011-07-24 16:41:56 --> Hooks Class Initialized
DEBUG - 2011-07-24 16:41:56 --> Utf8 Class Initialized
DEBUG - 2011-07-24 16:41:56 --> UTF-8 Support Enabled
DEBUG - 2011-07-24 16:41:56 --> URI Class Initialized
DEBUG - 2011-07-24 16:41:56 --> Router Class Initialized
DEBUG - 2011-07-24 16:41:56 --> No URI present. Default controller set.
DEBUG - 2011-07-24 16:41:56 --> Output Class Initialized
DEBUG - 2011-07-24 16:41:56 --> Input Class Initialized
DEBUG - 2011-07-24 16:41:56 --> Global POST and COOKIE data sanitized
DEBUG - 2011-07-24 16:41:56 --> Language Class Initialized
DEBUG - 2011-07-24 16:41:56 --> Loader Class Initialized
DEBUG - 2011-07-24 16:41:56 --> Controller Class Initialized
DEBUG - 2011-07-24 16:41:56 --> File loaded: application/views/splash/main.php
DEBUG - 2011-07-24 16:41:56 --> Helper loaded: url_helper
DEBUG - 2011-07-24 16:41:56 --> File loaded: application/views/common/header.php
DEBUG - 2011-07-24 16:41:56 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-07-24 16:41:56 --> File loaded: application/views/common/footer.php
DEBUG - 2011-07-24 16:41:56 --> File loaded: application/views/layout/main.php
DEBUG - 2011-07-24 16:41:56 --> Final output sent to browser
DEBUG - 2011-07-24 16:41:56 --> Total execution time: 0.0528
DEBUG - 2011-07-24 16:41:56 --> Config Class Initialized
DEBUG - 2011-07-24 16:41:56 --> Hooks Class Initialized
DEBUG - 2011-07-24 16:41:56 --> Utf8 Class Initialized
DEBUG - 2011-07-24 16:41:56 --> UTF-8 Support Enabled
DEBUG - 2011-07-24 16:41:56 --> URI Class Initialized
DEBUG - 2011-07-24 16:41:56 --> Router Class Initialized
DEBUG - 2011-07-24 16:41:56 --> No URI present. Default controller set.
DEBUG - 2011-07-24 16:41:56 --> Output Class Initialized
DEBUG - 2011-07-24 16:41:56 --> Input Class Initialized
DEBUG - 2011-07-24 16:41:56 --> Global POST and COOKIE data sanitized
DEBUG - 2011-07-24 16:41:56 --> Language Class Initialized
DEBUG - 2011-07-24 16:41:56 --> Loader Class Initialized
DEBUG - 2011-07-24 16:41:56 --> Controller Class Initialized
DEBUG - 2011-07-24 16:41:56 --> File loaded: application/views/splash/main.php
DEBUG - 2011-07-24 16:41:56 --> Helper loaded: url_helper
DEBUG - 2011-07-24 16:41:56 --> File loaded: application/views/common/header.php
DEBUG - 2011-07-24 16:41:56 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-07-24 16:41:56 --> File loaded: application/views/common/footer.php
DEBUG - 2011-07-24 16:41:56 --> File loaded: application/views/layout/main.php
DEBUG - 2011-07-24 16:41:56 --> Final output sent to browser
DEBUG - 2011-07-24 16:41:56 --> Total execution time: 0.0179
DEBUG - 2011-07-24 16:42:00 --> Config Class Initialized
DEBUG - 2011-07-24 16:42:00 --> Hooks Class Initialized
DEBUG - 2011-07-24 16:42:00 --> Utf8 Class Initialized
DEBUG - 2011-07-24 16:42:00 --> UTF-8 Support Enabled
DEBUG - 2011-07-24 16:42:00 --> URI Class Initialized
DEBUG - 2011-07-24 16:42:00 --> Router Class Initialized
DEBUG - 2011-07-24 16:42:00 --> Output Class Initialized
DEBUG - 2011-07-24 16:42:00 --> Input Class Initialized
DEBUG - 2011-07-24 16:42:00 --> Global POST and COOKIE data sanitized
DEBUG - 2011-07-24 16:42:00 --> Language Class Initialized
DEBUG - 2011-07-24 16:42:00 --> Loader Class Initialized
DEBUG - 2011-07-24 16:42:00 --> Controller Class Initialized
DEBUG - 2011-07-24 16:42:00 --> Model Class Initialized
DEBUG - 2011-07-24 16:42:00 --> Model Class Initialized
DEBUG - 2011-07-24 16:42:00 --> Model Class Initialized
DEBUG - 2011-07-24 16:42:00 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-07-24 16:42:00 --> Database Driver Class Initialized
DEBUG - 2011-07-24 16:42:01 --> File loaded: application/views/table/main.php
DEBUG - 2011-07-24 16:42:01 --> Helper loaded: url_helper
DEBUG - 2011-07-24 16:42:01 --> File loaded: application/views/common/header.php
DEBUG - 2011-07-24 16:42:01 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-07-24 16:42:01 --> File loaded: application/views/common/footer.php
DEBUG - 2011-07-24 16:42:01 --> File loaded: application/views/layout/main.php
DEBUG - 2011-07-24 16:42:01 --> Final output sent to browser
DEBUG - 2011-07-24 16:42:01 --> Total execution time: 0.3740
DEBUG - 2011-07-24 16:42:02 --> Config Class Initialized
DEBUG - 2011-07-24 16:42:02 --> Hooks Class Initialized
DEBUG - 2011-07-24 16:42:02 --> Utf8 Class Initialized
DEBUG - 2011-07-24 16:42:02 --> UTF-8 Support Enabled
DEBUG - 2011-07-24 16:42:02 --> URI Class Initialized
DEBUG - 2011-07-24 16:42:02 --> Router Class Initialized
DEBUG - 2011-07-24 16:42:02 --> Output Class Initialized
DEBUG - 2011-07-24 16:42:02 --> Input Class Initialized
DEBUG - 2011-07-24 16:42:02 --> Global POST and COOKIE data sanitized
DEBUG - 2011-07-24 16:42:02 --> Language Class Initialized
DEBUG - 2011-07-24 16:42:02 --> Loader Class Initialized
DEBUG - 2011-07-24 16:42:02 --> Controller Class Initialized
DEBUG - 2011-07-24 16:42:02 --> Model Class Initialized
DEBUG - 2011-07-24 16:42:02 --> Model Class Initialized
DEBUG - 2011-07-24 16:42:02 --> Model Class Initialized
DEBUG - 2011-07-24 16:42:02 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-07-24 16:42:02 --> Database Driver Class Initialized
DEBUG - 2011-07-24 16:42:02 --> File loaded: application/views/table/main.php
DEBUG - 2011-07-24 16:42:02 --> Helper loaded: url_helper
DEBUG - 2011-07-24 16:42:02 --> File loaded: application/views/common/header.php
DEBUG - 2011-07-24 16:42:02 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-07-24 16:42:02 --> File loaded: application/views/common/footer.php
DEBUG - 2011-07-24 16:42:02 --> File loaded: application/views/layout/main.php
DEBUG - 2011-07-24 16:42:02 --> Final output sent to browser
DEBUG - 2011-07-24 16:42:02 --> Total execution time: 0.0532
DEBUG - 2011-07-24 16:42:11 --> Config Class Initialized
DEBUG - 2011-07-24 16:42:11 --> Hooks Class Initialized
DEBUG - 2011-07-24 16:42:11 --> Utf8 Class Initialized
DEBUG - 2011-07-24 16:42:11 --> UTF-8 Support Enabled
DEBUG - 2011-07-24 16:42:11 --> URI Class Initialized
DEBUG - 2011-07-24 16:42:11 --> Router Class Initialized
DEBUG - 2011-07-24 16:42:11 --> Output Class Initialized
DEBUG - 2011-07-24 16:42:11 --> Input Class Initialized
DEBUG - 2011-07-24 16:42:11 --> Global POST and COOKIE data sanitized
DEBUG - 2011-07-24 16:42:11 --> Language Class Initialized
DEBUG - 2011-07-24 16:42:11 --> Loader Class Initialized
DEBUG - 2011-07-24 16:42:11 --> Controller Class Initialized
DEBUG - 2011-07-24 16:42:11 --> Model Class Initialized
DEBUG - 2011-07-24 16:42:11 --> Model Class Initialized
DEBUG - 2011-07-24 16:42:11 --> Model Class Initialized
DEBUG - 2011-07-24 16:42:11 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-07-24 16:42:11 --> Database Driver Class Initialized
DEBUG - 2011-07-24 16:42:11 --> File loaded: application/views/table/main.php
DEBUG - 2011-07-24 16:42:11 --> Helper loaded: url_helper
DEBUG - 2011-07-24 16:42:11 --> File loaded: application/views/common/header.php
DEBUG - 2011-07-24 16:42:11 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-07-24 16:42:11 --> File loaded: application/views/common/footer.php
DEBUG - 2011-07-24 16:42:11 --> File loaded: application/views/layout/main.php
DEBUG - 2011-07-24 16:42:11 --> Final output sent to browser
DEBUG - 2011-07-24 16:42:11 --> Total execution time: 0.3342
DEBUG - 2011-07-24 16:42:19 --> Config Class Initialized
DEBUG - 2011-07-24 16:42:19 --> Hooks Class Initialized
DEBUG - 2011-07-24 16:42:19 --> Utf8 Class Initialized
DEBUG - 2011-07-24 16:42:19 --> UTF-8 Support Enabled
DEBUG - 2011-07-24 16:42:19 --> URI Class Initialized
DEBUG - 2011-07-24 16:42:19 --> Router Class Initialized
DEBUG - 2011-07-24 16:42:19 --> Output Class Initialized
DEBUG - 2011-07-24 16:42:19 --> Input Class Initialized
DEBUG - 2011-07-24 16:42:19 --> Global POST and COOKIE data sanitized
DEBUG - 2011-07-24 16:42:19 --> Language Class Initialized
DEBUG - 2011-07-24 16:42:19 --> Loader Class Initialized
DEBUG - 2011-07-24 16:42:19 --> Controller Class Initialized
DEBUG - 2011-07-24 16:42:19 --> Model Class Initialized
DEBUG - 2011-07-24 16:42:19 --> Model Class Initialized
DEBUG - 2011-07-24 16:42:19 --> Model Class Initialized
DEBUG - 2011-07-24 16:42:19 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-07-24 16:42:19 --> Database Driver Class Initialized
DEBUG - 2011-07-24 16:42:20 --> File loaded: application/views/table/main.php
DEBUG - 2011-07-24 16:42:20 --> Helper loaded: url_helper
DEBUG - 2011-07-24 16:42:20 --> File loaded: application/views/common/header.php
DEBUG - 2011-07-24 16:42:20 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-07-24 16:42:20 --> File loaded: application/views/common/footer.php
DEBUG - 2011-07-24 16:42:20 --> File loaded: application/views/layout/main.php
DEBUG - 2011-07-24 16:42:20 --> Final output sent to browser
DEBUG - 2011-07-24 16:42:20 --> Total execution time: 0.7567
DEBUG - 2011-07-24 16:42:27 --> Config Class Initialized
DEBUG - 2011-07-24 16:42:27 --> Hooks Class Initialized
DEBUG - 2011-07-24 16:42:27 --> Utf8 Class Initialized
DEBUG - 2011-07-24 16:42:27 --> UTF-8 Support Enabled
DEBUG - 2011-07-24 16:42:27 --> URI Class Initialized
DEBUG - 2011-07-24 16:42:27 --> Router Class Initialized
DEBUG - 2011-07-24 16:42:27 --> Output Class Initialized
DEBUG - 2011-07-24 16:42:27 --> Input Class Initialized
DEBUG - 2011-07-24 16:42:27 --> Global POST and COOKIE data sanitized
DEBUG - 2011-07-24 16:42:27 --> Language Class Initialized
DEBUG - 2011-07-24 16:42:27 --> Loader Class Initialized
DEBUG - 2011-07-24 16:42:27 --> Controller Class Initialized
DEBUG - 2011-07-24 16:42:27 --> Model Class Initialized
DEBUG - 2011-07-24 16:42:27 --> Model Class Initialized
DEBUG - 2011-07-24 16:42:27 --> Model Class Initialized
DEBUG - 2011-07-24 16:42:27 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-07-24 16:42:27 --> Database Driver Class Initialized
DEBUG - 2011-07-24 16:42:27 --> File loaded: application/views/table/main.php
DEBUG - 2011-07-24 16:42:27 --> Helper loaded: url_helper
DEBUG - 2011-07-24 16:42:27 --> File loaded: application/views/common/header.php
DEBUG - 2011-07-24 16:42:27 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-07-24 16:42:27 --> File loaded: application/views/common/footer.php
DEBUG - 2011-07-24 16:42:27 --> File loaded: application/views/layout/main.php
DEBUG - 2011-07-24 16:42:27 --> Final output sent to browser
DEBUG - 2011-07-24 16:42:27 --> Total execution time: 0.3046
DEBUG - 2011-07-24 16:42:34 --> Config Class Initialized
DEBUG - 2011-07-24 16:42:34 --> Hooks Class Initialized
DEBUG - 2011-07-24 16:42:34 --> Utf8 Class Initialized
DEBUG - 2011-07-24 16:42:34 --> UTF-8 Support Enabled
DEBUG - 2011-07-24 16:42:34 --> URI Class Initialized
DEBUG - 2011-07-24 16:42:34 --> Router Class Initialized
DEBUG - 2011-07-24 16:42:34 --> Output Class Initialized
DEBUG - 2011-07-24 16:42:34 --> Input Class Initialized
DEBUG - 2011-07-24 16:42:34 --> Global POST and COOKIE data sanitized
DEBUG - 2011-07-24 16:42:34 --> Language Class Initialized
DEBUG - 2011-07-24 16:42:34 --> Loader Class Initialized
DEBUG - 2011-07-24 16:42:34 --> Controller Class Initialized
DEBUG - 2011-07-24 16:42:34 --> Model Class Initialized
DEBUG - 2011-07-24 16:42:34 --> Model Class Initialized
DEBUG - 2011-07-24 16:42:34 --> Model Class Initialized
DEBUG - 2011-07-24 16:42:34 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-07-24 16:42:34 --> Database Driver Class Initialized
DEBUG - 2011-07-24 16:42:34 --> File loaded: application/views/table/main.php
DEBUG - 2011-07-24 16:42:34 --> Helper loaded: url_helper
DEBUG - 2011-07-24 16:42:34 --> File loaded: application/views/common/header.php
DEBUG - 2011-07-24 16:42:34 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-07-24 16:42:34 --> File loaded: application/views/common/footer.php
DEBUG - 2011-07-24 16:42:34 --> File loaded: application/views/layout/main.php
DEBUG - 2011-07-24 16:42:34 --> Final output sent to browser
DEBUG - 2011-07-24 16:42:34 --> Total execution time: 0.0421
DEBUG - 2011-07-24 16:42:41 --> Config Class Initialized
DEBUG - 2011-07-24 16:42:41 --> Hooks Class Initialized
DEBUG - 2011-07-24 16:42:41 --> Utf8 Class Initialized
DEBUG - 2011-07-24 16:42:41 --> UTF-8 Support Enabled
DEBUG - 2011-07-24 16:42:41 --> URI Class Initialized
DEBUG - 2011-07-24 16:42:41 --> Router Class Initialized
DEBUG - 2011-07-24 16:42:41 --> Output Class Initialized
DEBUG - 2011-07-24 16:42:41 --> Input Class Initialized
DEBUG - 2011-07-24 16:42:41 --> Global POST and COOKIE data sanitized
DEBUG - 2011-07-24 16:42:41 --> Language Class Initialized
DEBUG - 2011-07-24 16:42:41 --> Loader Class Initialized
DEBUG - 2011-07-24 16:42:41 --> Controller Class Initialized
DEBUG - 2011-07-24 16:42:41 --> Model Class Initialized
DEBUG - 2011-07-24 16:42:41 --> Model Class Initialized
DEBUG - 2011-07-24 16:42:41 --> Model Class Initialized
DEBUG - 2011-07-24 16:42:41 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-07-24 16:42:41 --> Database Driver Class Initialized
DEBUG - 2011-07-24 16:42:41 --> File loaded: application/views/table/main.php
DEBUG - 2011-07-24 16:42:41 --> Helper loaded: url_helper
DEBUG - 2011-07-24 16:42:41 --> File loaded: application/views/common/header.php
DEBUG - 2011-07-24 16:42:41 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-07-24 16:42:41 --> File loaded: application/views/common/footer.php
DEBUG - 2011-07-24 16:42:41 --> File loaded: application/views/layout/main.php
DEBUG - 2011-07-24 16:42:41 --> Final output sent to browser
DEBUG - 2011-07-24 16:42:41 --> Total execution time: 0.0471
DEBUG - 2011-07-24 16:42:44 --> Config Class Initialized
DEBUG - 2011-07-24 16:42:44 --> Hooks Class Initialized
DEBUG - 2011-07-24 16:42:44 --> Utf8 Class Initialized
DEBUG - 2011-07-24 16:42:44 --> UTF-8 Support Enabled
DEBUG - 2011-07-24 16:42:44 --> URI Class Initialized
DEBUG - 2011-07-24 16:42:44 --> Router Class Initialized
DEBUG - 2011-07-24 16:42:44 --> Output Class Initialized
DEBUG - 2011-07-24 16:42:44 --> Input Class Initialized
DEBUG - 2011-07-24 16:42:44 --> Global POST and COOKIE data sanitized
DEBUG - 2011-07-24 16:42:44 --> Language Class Initialized
DEBUG - 2011-07-24 16:42:44 --> Loader Class Initialized
DEBUG - 2011-07-24 16:42:44 --> Controller Class Initialized
DEBUG - 2011-07-24 16:42:44 --> Model Class Initialized
DEBUG - 2011-07-24 16:42:44 --> Model Class Initialized
DEBUG - 2011-07-24 16:42:44 --> Model Class Initialized
DEBUG - 2011-07-24 16:42:44 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-07-24 16:42:44 --> Database Driver Class Initialized
DEBUG - 2011-07-24 16:42:44 --> File loaded: application/views/table/main.php
DEBUG - 2011-07-24 16:42:44 --> Helper loaded: url_helper
DEBUG - 2011-07-24 16:42:44 --> File loaded: application/views/common/header.php
DEBUG - 2011-07-24 16:42:44 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-07-24 16:42:44 --> File loaded: application/views/common/footer.php
DEBUG - 2011-07-24 16:42:44 --> File loaded: application/views/layout/main.php
DEBUG - 2011-07-24 16:42:44 --> Final output sent to browser
DEBUG - 2011-07-24 16:42:44 --> Total execution time: 0.0453
DEBUG - 2011-07-24 16:42:48 --> Config Class Initialized
DEBUG - 2011-07-24 16:42:48 --> Hooks Class Initialized
DEBUG - 2011-07-24 16:42:48 --> Utf8 Class Initialized
DEBUG - 2011-07-24 16:42:48 --> UTF-8 Support Enabled
DEBUG - 2011-07-24 16:42:48 --> URI Class Initialized
DEBUG - 2011-07-24 16:42:48 --> Router Class Initialized
DEBUG - 2011-07-24 16:42:48 --> Output Class Initialized
DEBUG - 2011-07-24 16:42:48 --> Input Class Initialized
DEBUG - 2011-07-24 16:42:48 --> Global POST and COOKIE data sanitized
DEBUG - 2011-07-24 16:42:48 --> Language Class Initialized
DEBUG - 2011-07-24 16:42:48 --> Loader Class Initialized
DEBUG - 2011-07-24 16:42:48 --> Controller Class Initialized
DEBUG - 2011-07-24 16:42:48 --> Model Class Initialized
DEBUG - 2011-07-24 16:42:48 --> Model Class Initialized
DEBUG - 2011-07-24 16:42:48 --> Model Class Initialized
DEBUG - 2011-07-24 16:42:48 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-07-24 16:42:48 --> Database Driver Class Initialized
DEBUG - 2011-07-24 16:42:48 --> File loaded: application/views/table/main.php
DEBUG - 2011-07-24 16:42:48 --> Helper loaded: url_helper
DEBUG - 2011-07-24 16:42:48 --> File loaded: application/views/common/header.php
DEBUG - 2011-07-24 16:42:48 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-07-24 16:42:48 --> File loaded: application/views/common/footer.php
DEBUG - 2011-07-24 16:42:48 --> File loaded: application/views/layout/main.php
DEBUG - 2011-07-24 16:42:48 --> Final output sent to browser
DEBUG - 2011-07-24 16:42:48 --> Total execution time: 0.0451
DEBUG - 2011-07-24 17:07:50 --> Config Class Initialized
DEBUG - 2011-07-24 17:07:50 --> Hooks Class Initialized
DEBUG - 2011-07-24 17:07:50 --> Utf8 Class Initialized
DEBUG - 2011-07-24 17:07:50 --> UTF-8 Support Enabled
DEBUG - 2011-07-24 17:07:50 --> URI Class Initialized
DEBUG - 2011-07-24 17:07:50 --> Router Class Initialized
DEBUG - 2011-07-24 17:07:50 --> Output Class Initialized
DEBUG - 2011-07-24 17:07:50 --> Input Class Initialized
DEBUG - 2011-07-24 17:07:50 --> Global POST and COOKIE data sanitized
DEBUG - 2011-07-24 17:07:50 --> Language Class Initialized
DEBUG - 2011-07-24 17:07:50 --> Loader Class Initialized
DEBUG - 2011-07-24 17:07:50 --> Controller Class Initialized
ERROR - 2011-07-24 17:07:51 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-07-24 17:07:51 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-07-24 17:07:51 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-07-24 17:07:51 --> Model Class Initialized
DEBUG - 2011-07-24 17:07:51 --> Model Class Initialized
DEBUG - 2011-07-24 17:07:51 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-07-24 17:07:51 --> Database Driver Class Initialized
DEBUG - 2011-07-24 17:07:51 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-07-24 17:07:51 --> Helper loaded: url_helper
DEBUG - 2011-07-24 17:07:51 --> File loaded: application/views/common/header.php
DEBUG - 2011-07-24 17:07:51 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-07-24 17:07:51 --> File loaded: application/views/common/footer.php
DEBUG - 2011-07-24 17:07:51 --> File loaded: application/views/layout/main.php
DEBUG - 2011-07-24 17:07:51 --> Final output sent to browser
DEBUG - 2011-07-24 17:07:51 --> Total execution time: 0.7494
DEBUG - 2011-07-24 17:07:54 --> Config Class Initialized
DEBUG - 2011-07-24 17:07:54 --> Hooks Class Initialized
DEBUG - 2011-07-24 17:07:54 --> Utf8 Class Initialized
DEBUG - 2011-07-24 17:07:54 --> UTF-8 Support Enabled
DEBUG - 2011-07-24 17:07:54 --> URI Class Initialized
DEBUG - 2011-07-24 17:07:54 --> Router Class Initialized
DEBUG - 2011-07-24 17:07:54 --> Output Class Initialized
DEBUG - 2011-07-24 17:07:54 --> Input Class Initialized
DEBUG - 2011-07-24 17:07:54 --> Global POST and COOKIE data sanitized
DEBUG - 2011-07-24 17:07:54 --> Language Class Initialized
DEBUG - 2011-07-24 17:07:54 --> Loader Class Initialized
DEBUG - 2011-07-24 17:07:54 --> Controller Class Initialized
DEBUG - 2011-07-24 17:07:54 --> Model Class Initialized
DEBUG - 2011-07-24 17:07:54 --> Model Class Initialized
DEBUG - 2011-07-24 17:07:54 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-07-24 17:07:54 --> Database Driver Class Initialized
DEBUG - 2011-07-24 17:07:55 --> Final output sent to browser
DEBUG - 2011-07-24 17:07:55 --> Total execution time: 1.1647
DEBUG - 2011-07-24 17:08:00 --> Config Class Initialized
DEBUG - 2011-07-24 17:08:00 --> Hooks Class Initialized
DEBUG - 2011-07-24 17:08:00 --> Utf8 Class Initialized
DEBUG - 2011-07-24 17:08:00 --> UTF-8 Support Enabled
DEBUG - 2011-07-24 17:08:00 --> URI Class Initialized
DEBUG - 2011-07-24 17:08:00 --> Router Class Initialized
ERROR - 2011-07-24 17:08:00 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-07-24 17:08:02 --> Config Class Initialized
DEBUG - 2011-07-24 17:08:02 --> Hooks Class Initialized
DEBUG - 2011-07-24 17:08:02 --> Utf8 Class Initialized
DEBUG - 2011-07-24 17:08:02 --> UTF-8 Support Enabled
DEBUG - 2011-07-24 17:08:02 --> URI Class Initialized
DEBUG - 2011-07-24 17:08:02 --> Router Class Initialized
ERROR - 2011-07-24 17:08:02 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-07-24 18:10:55 --> Config Class Initialized
DEBUG - 2011-07-24 18:10:55 --> Hooks Class Initialized
DEBUG - 2011-07-24 18:10:55 --> Utf8 Class Initialized
DEBUG - 2011-07-24 18:10:55 --> UTF-8 Support Enabled
DEBUG - 2011-07-24 18:10:55 --> URI Class Initialized
DEBUG - 2011-07-24 18:10:55 --> Router Class Initialized
ERROR - 2011-07-24 18:10:55 --> 404 Page Not Found --> robots.txt
DEBUG - 2011-07-24 18:52:40 --> Config Class Initialized
DEBUG - 2011-07-24 18:52:40 --> Hooks Class Initialized
DEBUG - 2011-07-24 18:52:40 --> Utf8 Class Initialized
DEBUG - 2011-07-24 18:52:40 --> UTF-8 Support Enabled
DEBUG - 2011-07-24 18:52:40 --> URI Class Initialized
DEBUG - 2011-07-24 18:52:40 --> Router Class Initialized
DEBUG - 2011-07-24 18:52:40 --> Output Class Initialized
DEBUG - 2011-07-24 18:52:40 --> Input Class Initialized
DEBUG - 2011-07-24 18:52:40 --> Global POST and COOKIE data sanitized
DEBUG - 2011-07-24 18:52:40 --> Language Class Initialized
DEBUG - 2011-07-24 18:52:40 --> Loader Class Initialized
DEBUG - 2011-07-24 18:52:40 --> Controller Class Initialized
DEBUG - 2011-07-24 18:52:40 --> Model Class Initialized
DEBUG - 2011-07-24 18:52:40 --> Model Class Initialized
DEBUG - 2011-07-24 18:52:40 --> Model Class Initialized
DEBUG - 2011-07-24 18:52:40 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-07-24 18:52:40 --> Database Driver Class Initialized
DEBUG - 2011-07-24 18:52:40 --> File loaded: application/views/table/main.php
DEBUG - 2011-07-24 18:52:40 --> Helper loaded: url_helper
DEBUG - 2011-07-24 18:52:40 --> File loaded: application/views/common/header.php
DEBUG - 2011-07-24 18:52:40 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-07-24 18:52:40 --> File loaded: application/views/common/footer.php
DEBUG - 2011-07-24 18:52:40 --> File loaded: application/views/layout/main.php
DEBUG - 2011-07-24 18:52:40 --> Final output sent to browser
DEBUG - 2011-07-24 18:52:40 --> Total execution time: 0.7002
DEBUG - 2011-07-24 19:49:28 --> Config Class Initialized
DEBUG - 2011-07-24 19:49:28 --> Hooks Class Initialized
DEBUG - 2011-07-24 19:49:28 --> Utf8 Class Initialized
DEBUG - 2011-07-24 19:49:28 --> UTF-8 Support Enabled
DEBUG - 2011-07-24 19:49:28 --> URI Class Initialized
DEBUG - 2011-07-24 19:49:28 --> Router Class Initialized
DEBUG - 2011-07-24 19:49:28 --> Output Class Initialized
DEBUG - 2011-07-24 19:49:28 --> Input Class Initialized
DEBUG - 2011-07-24 19:49:28 --> Global POST and COOKIE data sanitized
DEBUG - 2011-07-24 19:49:28 --> Language Class Initialized
DEBUG - 2011-07-24 19:49:29 --> Loader Class Initialized
DEBUG - 2011-07-24 19:49:29 --> Controller Class Initialized
DEBUG - 2011-07-24 19:49:29 --> Model Class Initialized
DEBUG - 2011-07-24 19:49:30 --> Model Class Initialized
DEBUG - 2011-07-24 19:49:30 --> Model Class Initialized
DEBUG - 2011-07-24 19:49:30 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-07-24 19:49:30 --> Database Driver Class Initialized
DEBUG - 2011-07-24 19:49:30 --> File loaded: application/views/table/main.php
DEBUG - 2011-07-24 19:49:30 --> Helper loaded: url_helper
DEBUG - 2011-07-24 19:49:30 --> File loaded: application/views/common/header.php
DEBUG - 2011-07-24 19:49:30 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-07-24 19:49:30 --> File loaded: application/views/common/footer.php
DEBUG - 2011-07-24 19:49:30 --> File loaded: application/views/layout/main.php
DEBUG - 2011-07-24 19:49:30 --> Final output sent to browser
DEBUG - 2011-07-24 19:49:30 --> Total execution time: 3.7268
DEBUG - 2011-07-24 19:49:33 --> Config Class Initialized
DEBUG - 2011-07-24 19:49:33 --> Hooks Class Initialized
DEBUG - 2011-07-24 19:49:33 --> Utf8 Class Initialized
DEBUG - 2011-07-24 19:49:33 --> UTF-8 Support Enabled
DEBUG - 2011-07-24 19:49:33 --> URI Class Initialized
DEBUG - 2011-07-24 19:49:33 --> Router Class Initialized
ERROR - 2011-07-24 19:49:33 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-07-24 22:17:05 --> Config Class Initialized
DEBUG - 2011-07-24 22:17:05 --> Hooks Class Initialized
DEBUG - 2011-07-24 22:17:05 --> Utf8 Class Initialized
DEBUG - 2011-07-24 22:17:05 --> UTF-8 Support Enabled
DEBUG - 2011-07-24 22:17:05 --> URI Class Initialized
DEBUG - 2011-07-24 22:17:05 --> Router Class Initialized
DEBUG - 2011-07-24 22:17:05 --> Output Class Initialized
DEBUG - 2011-07-24 22:17:05 --> Input Class Initialized
DEBUG - 2011-07-24 22:17:05 --> Global POST and COOKIE data sanitized
DEBUG - 2011-07-24 22:17:06 --> Language Class Initialized
DEBUG - 2011-07-24 22:17:06 --> Loader Class Initialized
DEBUG - 2011-07-24 22:17:06 --> Controller Class Initialized
ERROR - 2011-07-24 22:17:06 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-07-24 22:17:06 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-07-24 22:17:06 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-07-24 22:17:06 --> Model Class Initialized
DEBUG - 2011-07-24 22:17:06 --> Model Class Initialized
DEBUG - 2011-07-24 22:17:06 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-07-24 22:17:06 --> Database Driver Class Initialized
DEBUG - 2011-07-24 22:17:06 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-07-24 22:17:07 --> Helper loaded: url_helper
DEBUG - 2011-07-24 22:17:07 --> File loaded: application/views/common/header.php
DEBUG - 2011-07-24 22:17:07 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-07-24 22:17:07 --> File loaded: application/views/common/footer.php
DEBUG - 2011-07-24 22:17:07 --> File loaded: application/views/layout/main.php
DEBUG - 2011-07-24 22:17:07 --> Final output sent to browser
DEBUG - 2011-07-24 22:17:07 --> Total execution time: 2.3771
DEBUG - 2011-07-24 22:17:08 --> Config Class Initialized
DEBUG - 2011-07-24 22:17:08 --> Hooks Class Initialized
DEBUG - 2011-07-24 22:17:08 --> Utf8 Class Initialized
DEBUG - 2011-07-24 22:17:08 --> UTF-8 Support Enabled
DEBUG - 2011-07-24 22:17:08 --> URI Class Initialized
DEBUG - 2011-07-24 22:17:08 --> Router Class Initialized
DEBUG - 2011-07-24 22:17:08 --> Output Class Initialized
DEBUG - 2011-07-24 22:17:08 --> Input Class Initialized
DEBUG - 2011-07-24 22:17:08 --> Global POST and COOKIE data sanitized
DEBUG - 2011-07-24 22:17:08 --> Language Class Initialized
DEBUG - 2011-07-24 22:17:08 --> Loader Class Initialized
DEBUG - 2011-07-24 22:17:08 --> Controller Class Initialized
DEBUG - 2011-07-24 22:17:08 --> Model Class Initialized
DEBUG - 2011-07-24 22:17:08 --> Model Class Initialized
DEBUG - 2011-07-24 22:17:08 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-07-24 22:17:08 --> Database Driver Class Initialized
DEBUG - 2011-07-24 22:17:09 --> Final output sent to browser
DEBUG - 2011-07-24 22:17:09 --> Total execution time: 1.2879
DEBUG - 2011-07-24 22:18:21 --> Config Class Initialized
DEBUG - 2011-07-24 22:18:21 --> Hooks Class Initialized
DEBUG - 2011-07-24 22:18:21 --> Utf8 Class Initialized
DEBUG - 2011-07-24 22:18:21 --> UTF-8 Support Enabled
DEBUG - 2011-07-24 22:18:21 --> URI Class Initialized
DEBUG - 2011-07-24 22:18:21 --> Router Class Initialized
DEBUG - 2011-07-24 22:18:21 --> Output Class Initialized
DEBUG - 2011-07-24 22:18:21 --> Input Class Initialized
DEBUG - 2011-07-24 22:18:21 --> Global POST and COOKIE data sanitized
DEBUG - 2011-07-24 22:18:21 --> Language Class Initialized
DEBUG - 2011-07-24 22:18:21 --> Loader Class Initialized
DEBUG - 2011-07-24 22:18:21 --> Controller Class Initialized
DEBUG - 2011-07-24 22:18:21 --> Model Class Initialized
DEBUG - 2011-07-24 22:18:21 --> Model Class Initialized
DEBUG - 2011-07-24 22:18:21 --> Model Class Initialized
DEBUG - 2011-07-24 22:18:21 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-07-24 22:18:21 --> Database Driver Class Initialized
DEBUG - 2011-07-24 22:18:21 --> File loaded: application/views/table/main.php
DEBUG - 2011-07-24 22:18:21 --> Helper loaded: url_helper
DEBUG - 2011-07-24 22:18:21 --> File loaded: application/views/common/header.php
DEBUG - 2011-07-24 22:18:21 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-07-24 22:18:21 --> File loaded: application/views/common/footer.php
DEBUG - 2011-07-24 22:18:21 --> File loaded: application/views/layout/main.php
DEBUG - 2011-07-24 22:18:21 --> Final output sent to browser
DEBUG - 2011-07-24 22:18:21 --> Total execution time: 0.2639
DEBUG - 2011-07-24 22:18:22 --> Config Class Initialized
DEBUG - 2011-07-24 22:18:22 --> Hooks Class Initialized
DEBUG - 2011-07-24 22:18:22 --> Utf8 Class Initialized
DEBUG - 2011-07-24 22:18:22 --> UTF-8 Support Enabled
DEBUG - 2011-07-24 22:18:22 --> URI Class Initialized
DEBUG - 2011-07-24 22:18:22 --> Router Class Initialized
ERROR - 2011-07-24 22:18:22 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-07-24 22:18:25 --> Config Class Initialized
DEBUG - 2011-07-24 22:18:25 --> Hooks Class Initialized
DEBUG - 2011-07-24 22:18:25 --> Utf8 Class Initialized
DEBUG - 2011-07-24 22:18:25 --> UTF-8 Support Enabled
DEBUG - 2011-07-24 22:18:25 --> URI Class Initialized
DEBUG - 2011-07-24 22:18:25 --> Router Class Initialized
ERROR - 2011-07-24 22:18:25 --> 404 Page Not Found --> favicon.ico

<?php  if ( ! defined('BASEPATH')) exit('No direct script access allowed'); ?>

DEBUG - 2011-08-05 00:44:56 --> Config Class Initialized
DEBUG - 2011-08-05 00:44:56 --> Hooks Class Initialized
DEBUG - 2011-08-05 00:44:56 --> Utf8 Class Initialized
DEBUG - 2011-08-05 00:44:56 --> UTF-8 Support Enabled
DEBUG - 2011-08-05 00:44:56 --> URI Class Initialized
DEBUG - 2011-08-05 00:44:56 --> Router Class Initialized
DEBUG - 2011-08-05 00:44:56 --> Output Class Initialized
DEBUG - 2011-08-05 00:44:56 --> Input Class Initialized
DEBUG - 2011-08-05 00:44:56 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-05 00:44:56 --> Language Class Initialized
DEBUG - 2011-08-05 00:44:56 --> Loader Class Initialized
DEBUG - 2011-08-05 00:44:56 --> Controller Class Initialized
ERROR - 2011-08-05 00:44:57 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-08-05 00:44:57 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-08-05 00:44:57 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-08-05 00:44:57 --> Model Class Initialized
DEBUG - 2011-08-05 00:44:57 --> Model Class Initialized
DEBUG - 2011-08-05 00:44:57 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-05 00:44:57 --> Database Driver Class Initialized
DEBUG - 2011-08-05 00:44:57 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-08-05 00:44:57 --> Helper loaded: url_helper
DEBUG - 2011-08-05 00:44:57 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-05 00:44:57 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-05 00:44:57 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-05 00:44:57 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-05 00:44:57 --> Final output sent to browser
DEBUG - 2011-08-05 00:44:57 --> Total execution time: 0.2086
DEBUG - 2011-08-05 00:44:58 --> Config Class Initialized
DEBUG - 2011-08-05 00:44:58 --> Hooks Class Initialized
DEBUG - 2011-08-05 00:44:58 --> Utf8 Class Initialized
DEBUG - 2011-08-05 00:44:58 --> UTF-8 Support Enabled
DEBUG - 2011-08-05 00:44:58 --> URI Class Initialized
DEBUG - 2011-08-05 00:44:58 --> Router Class Initialized
DEBUG - 2011-08-05 00:44:58 --> Output Class Initialized
DEBUG - 2011-08-05 00:44:58 --> Input Class Initialized
DEBUG - 2011-08-05 00:44:58 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-05 00:44:58 --> Language Class Initialized
DEBUG - 2011-08-05 00:44:58 --> Loader Class Initialized
DEBUG - 2011-08-05 00:44:58 --> Controller Class Initialized
DEBUG - 2011-08-05 00:44:58 --> Model Class Initialized
DEBUG - 2011-08-05 00:44:58 --> Model Class Initialized
DEBUG - 2011-08-05 00:44:58 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-05 00:44:58 --> Database Driver Class Initialized
DEBUG - 2011-08-05 00:44:58 --> Final output sent to browser
DEBUG - 2011-08-05 00:44:58 --> Total execution time: 0.6886
DEBUG - 2011-08-05 00:44:59 --> Config Class Initialized
DEBUG - 2011-08-05 00:44:59 --> Hooks Class Initialized
DEBUG - 2011-08-05 00:44:59 --> Utf8 Class Initialized
DEBUG - 2011-08-05 00:44:59 --> UTF-8 Support Enabled
DEBUG - 2011-08-05 00:44:59 --> URI Class Initialized
DEBUG - 2011-08-05 00:44:59 --> Router Class Initialized
ERROR - 2011-08-05 00:44:59 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-08-05 00:45:16 --> Config Class Initialized
DEBUG - 2011-08-05 00:45:16 --> Hooks Class Initialized
DEBUG - 2011-08-05 00:45:16 --> Utf8 Class Initialized
DEBUG - 2011-08-05 00:45:16 --> UTF-8 Support Enabled
DEBUG - 2011-08-05 00:45:16 --> URI Class Initialized
DEBUG - 2011-08-05 00:45:16 --> Router Class Initialized
DEBUG - 2011-08-05 00:45:16 --> Output Class Initialized
DEBUG - 2011-08-05 00:45:16 --> Input Class Initialized
DEBUG - 2011-08-05 00:45:16 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-05 00:45:16 --> Language Class Initialized
DEBUG - 2011-08-05 00:45:16 --> Loader Class Initialized
DEBUG - 2011-08-05 00:45:16 --> Controller Class Initialized
ERROR - 2011-08-05 00:45:16 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-08-05 00:45:16 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-08-05 00:45:16 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-08-05 00:45:16 --> Model Class Initialized
DEBUG - 2011-08-05 00:45:16 --> Model Class Initialized
DEBUG - 2011-08-05 00:45:16 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-05 00:45:16 --> Database Driver Class Initialized
DEBUG - 2011-08-05 00:45:16 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-08-05 00:45:16 --> Helper loaded: url_helper
DEBUG - 2011-08-05 00:45:16 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-05 00:45:16 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-05 00:45:16 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-05 00:45:16 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-05 00:45:16 --> Final output sent to browser
DEBUG - 2011-08-05 00:45:16 --> Total execution time: 0.0296
DEBUG - 2011-08-05 00:45:16 --> Config Class Initialized
DEBUG - 2011-08-05 00:45:16 --> Hooks Class Initialized
DEBUG - 2011-08-05 00:45:16 --> Utf8 Class Initialized
DEBUG - 2011-08-05 00:45:16 --> UTF-8 Support Enabled
DEBUG - 2011-08-05 00:45:16 --> URI Class Initialized
DEBUG - 2011-08-05 00:45:16 --> Router Class Initialized
DEBUG - 2011-08-05 00:45:16 --> Output Class Initialized
DEBUG - 2011-08-05 00:45:16 --> Input Class Initialized
DEBUG - 2011-08-05 00:45:16 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-05 00:45:16 --> Language Class Initialized
DEBUG - 2011-08-05 00:45:16 --> Loader Class Initialized
DEBUG - 2011-08-05 00:45:16 --> Controller Class Initialized
DEBUG - 2011-08-05 00:45:16 --> Model Class Initialized
DEBUG - 2011-08-05 00:45:16 --> Model Class Initialized
DEBUG - 2011-08-05 00:45:16 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-05 00:45:16 --> Database Driver Class Initialized
DEBUG - 2011-08-05 00:45:17 --> Final output sent to browser
DEBUG - 2011-08-05 00:45:17 --> Total execution time: 0.5745
DEBUG - 2011-08-05 00:45:18 --> Config Class Initialized
DEBUG - 2011-08-05 00:45:18 --> Hooks Class Initialized
DEBUG - 2011-08-05 00:45:18 --> Utf8 Class Initialized
DEBUG - 2011-08-05 00:45:18 --> UTF-8 Support Enabled
DEBUG - 2011-08-05 00:45:18 --> URI Class Initialized
DEBUG - 2011-08-05 00:45:18 --> Router Class Initialized
ERROR - 2011-08-05 00:45:18 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-08-05 00:45:26 --> Config Class Initialized
DEBUG - 2011-08-05 00:45:26 --> Hooks Class Initialized
DEBUG - 2011-08-05 00:45:26 --> Utf8 Class Initialized
DEBUG - 2011-08-05 00:45:26 --> UTF-8 Support Enabled
DEBUG - 2011-08-05 00:45:26 --> URI Class Initialized
DEBUG - 2011-08-05 00:45:26 --> Router Class Initialized
DEBUG - 2011-08-05 00:45:26 --> Output Class Initialized
DEBUG - 2011-08-05 00:45:26 --> Input Class Initialized
DEBUG - 2011-08-05 00:45:26 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-05 00:45:26 --> Language Class Initialized
DEBUG - 2011-08-05 00:45:26 --> Loader Class Initialized
DEBUG - 2011-08-05 00:45:26 --> Controller Class Initialized
ERROR - 2011-08-05 00:45:26 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-08-05 00:45:26 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-08-05 00:45:26 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-08-05 00:45:26 --> Model Class Initialized
DEBUG - 2011-08-05 00:45:26 --> Model Class Initialized
DEBUG - 2011-08-05 00:45:26 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-05 00:45:26 --> Database Driver Class Initialized
DEBUG - 2011-08-05 00:45:26 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-08-05 00:45:26 --> Helper loaded: url_helper
DEBUG - 2011-08-05 00:45:26 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-05 00:45:26 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-05 00:45:26 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-05 00:45:26 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-05 00:45:26 --> Final output sent to browser
DEBUG - 2011-08-05 00:45:26 --> Total execution time: 0.0881
DEBUG - 2011-08-05 00:45:27 --> Config Class Initialized
DEBUG - 2011-08-05 00:45:27 --> Hooks Class Initialized
DEBUG - 2011-08-05 00:45:27 --> Utf8 Class Initialized
DEBUG - 2011-08-05 00:45:27 --> UTF-8 Support Enabled
DEBUG - 2011-08-05 00:45:27 --> URI Class Initialized
DEBUG - 2011-08-05 00:45:27 --> Router Class Initialized
DEBUG - 2011-08-05 00:45:27 --> Output Class Initialized
DEBUG - 2011-08-05 00:45:27 --> Input Class Initialized
DEBUG - 2011-08-05 00:45:27 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-05 00:45:27 --> Language Class Initialized
DEBUG - 2011-08-05 00:45:27 --> Loader Class Initialized
DEBUG - 2011-08-05 00:45:27 --> Controller Class Initialized
DEBUG - 2011-08-05 00:45:27 --> Model Class Initialized
DEBUG - 2011-08-05 00:45:27 --> Model Class Initialized
DEBUG - 2011-08-05 00:45:27 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-05 00:45:27 --> Database Driver Class Initialized
DEBUG - 2011-08-05 00:45:28 --> Final output sent to browser
DEBUG - 2011-08-05 00:45:28 --> Total execution time: 0.5831
DEBUG - 2011-08-05 00:45:28 --> Config Class Initialized
DEBUG - 2011-08-05 00:45:28 --> Hooks Class Initialized
DEBUG - 2011-08-05 00:45:28 --> Utf8 Class Initialized
DEBUG - 2011-08-05 00:45:28 --> UTF-8 Support Enabled
DEBUG - 2011-08-05 00:45:28 --> URI Class Initialized
DEBUG - 2011-08-05 00:45:28 --> Router Class Initialized
ERROR - 2011-08-05 00:45:28 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-08-05 00:45:35 --> Config Class Initialized
DEBUG - 2011-08-05 00:45:35 --> Hooks Class Initialized
DEBUG - 2011-08-05 00:45:35 --> Utf8 Class Initialized
DEBUG - 2011-08-05 00:45:35 --> UTF-8 Support Enabled
DEBUG - 2011-08-05 00:45:35 --> URI Class Initialized
DEBUG - 2011-08-05 00:45:35 --> Router Class Initialized
DEBUG - 2011-08-05 00:45:35 --> Output Class Initialized
DEBUG - 2011-08-05 00:45:35 --> Input Class Initialized
DEBUG - 2011-08-05 00:45:35 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-05 00:45:35 --> Language Class Initialized
DEBUG - 2011-08-05 00:45:35 --> Loader Class Initialized
DEBUG - 2011-08-05 00:45:35 --> Controller Class Initialized
ERROR - 2011-08-05 00:45:35 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-08-05 00:45:35 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-08-05 00:45:35 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-08-05 00:45:35 --> Model Class Initialized
DEBUG - 2011-08-05 00:45:35 --> Model Class Initialized
DEBUG - 2011-08-05 00:45:35 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-05 00:45:35 --> Database Driver Class Initialized
DEBUG - 2011-08-05 00:45:35 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-08-05 00:45:35 --> Helper loaded: url_helper
DEBUG - 2011-08-05 00:45:35 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-05 00:45:35 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-05 00:45:35 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-05 00:45:35 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-05 00:45:35 --> Final output sent to browser
DEBUG - 2011-08-05 00:45:35 --> Total execution time: 0.1037
DEBUG - 2011-08-05 00:45:35 --> Config Class Initialized
DEBUG - 2011-08-05 00:45:35 --> Hooks Class Initialized
DEBUG - 2011-08-05 00:45:35 --> Utf8 Class Initialized
DEBUG - 2011-08-05 00:45:35 --> UTF-8 Support Enabled
DEBUG - 2011-08-05 00:45:35 --> URI Class Initialized
DEBUG - 2011-08-05 00:45:35 --> Router Class Initialized
DEBUG - 2011-08-05 00:45:35 --> Output Class Initialized
DEBUG - 2011-08-05 00:45:35 --> Input Class Initialized
DEBUG - 2011-08-05 00:45:35 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-05 00:45:35 --> Language Class Initialized
DEBUG - 2011-08-05 00:45:35 --> Loader Class Initialized
DEBUG - 2011-08-05 00:45:35 --> Controller Class Initialized
DEBUG - 2011-08-05 00:45:35 --> Model Class Initialized
DEBUG - 2011-08-05 00:45:35 --> Model Class Initialized
DEBUG - 2011-08-05 00:45:35 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-05 00:45:35 --> Database Driver Class Initialized
DEBUG - 2011-08-05 00:45:36 --> Final output sent to browser
DEBUG - 2011-08-05 00:45:36 --> Total execution time: 0.7348
DEBUG - 2011-08-05 00:45:37 --> Config Class Initialized
DEBUG - 2011-08-05 00:45:37 --> Hooks Class Initialized
DEBUG - 2011-08-05 00:45:37 --> Utf8 Class Initialized
DEBUG - 2011-08-05 00:45:37 --> UTF-8 Support Enabled
DEBUG - 2011-08-05 00:45:37 --> URI Class Initialized
DEBUG - 2011-08-05 00:45:37 --> Router Class Initialized
ERROR - 2011-08-05 00:45:37 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-08-05 00:45:50 --> Config Class Initialized
DEBUG - 2011-08-05 00:45:50 --> Hooks Class Initialized
DEBUG - 2011-08-05 00:45:50 --> Utf8 Class Initialized
DEBUG - 2011-08-05 00:45:50 --> UTF-8 Support Enabled
DEBUG - 2011-08-05 00:45:50 --> URI Class Initialized
DEBUG - 2011-08-05 00:45:50 --> Router Class Initialized
DEBUG - 2011-08-05 00:45:50 --> Output Class Initialized
DEBUG - 2011-08-05 00:45:50 --> Input Class Initialized
DEBUG - 2011-08-05 00:45:50 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-05 00:45:50 --> Language Class Initialized
DEBUG - 2011-08-05 00:45:50 --> Loader Class Initialized
DEBUG - 2011-08-05 00:45:50 --> Controller Class Initialized
ERROR - 2011-08-05 00:45:50 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-08-05 00:45:50 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-08-05 00:45:50 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-08-05 00:45:50 --> Model Class Initialized
DEBUG - 2011-08-05 00:45:50 --> Model Class Initialized
DEBUG - 2011-08-05 00:45:50 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-05 00:45:50 --> Database Driver Class Initialized
DEBUG - 2011-08-05 00:45:50 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-08-05 00:45:50 --> Helper loaded: url_helper
DEBUG - 2011-08-05 00:45:50 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-05 00:45:50 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-05 00:45:50 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-05 00:45:50 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-05 00:45:50 --> Final output sent to browser
DEBUG - 2011-08-05 00:45:50 --> Total execution time: 0.0619
DEBUG - 2011-08-05 00:45:51 --> Config Class Initialized
DEBUG - 2011-08-05 00:45:51 --> Hooks Class Initialized
DEBUG - 2011-08-05 00:45:51 --> Utf8 Class Initialized
DEBUG - 2011-08-05 00:45:51 --> UTF-8 Support Enabled
DEBUG - 2011-08-05 00:45:51 --> URI Class Initialized
DEBUG - 2011-08-05 00:45:51 --> Router Class Initialized
DEBUG - 2011-08-05 00:45:51 --> Output Class Initialized
DEBUG - 2011-08-05 00:45:51 --> Input Class Initialized
DEBUG - 2011-08-05 00:45:51 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-05 00:45:51 --> Language Class Initialized
DEBUG - 2011-08-05 00:45:51 --> Loader Class Initialized
DEBUG - 2011-08-05 00:45:51 --> Controller Class Initialized
DEBUG - 2011-08-05 00:45:51 --> Model Class Initialized
DEBUG - 2011-08-05 00:45:51 --> Model Class Initialized
DEBUG - 2011-08-05 00:45:51 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-05 00:45:51 --> Database Driver Class Initialized
DEBUG - 2011-08-05 00:45:52 --> Final output sent to browser
DEBUG - 2011-08-05 00:45:52 --> Total execution time: 0.6742
DEBUG - 2011-08-05 00:45:52 --> Config Class Initialized
DEBUG - 2011-08-05 00:45:52 --> Hooks Class Initialized
DEBUG - 2011-08-05 00:45:52 --> Utf8 Class Initialized
DEBUG - 2011-08-05 00:45:52 --> UTF-8 Support Enabled
DEBUG - 2011-08-05 00:45:52 --> URI Class Initialized
DEBUG - 2011-08-05 00:45:52 --> Router Class Initialized
ERROR - 2011-08-05 00:45:53 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-08-05 00:45:58 --> Config Class Initialized
DEBUG - 2011-08-05 00:45:58 --> Hooks Class Initialized
DEBUG - 2011-08-05 00:45:58 --> Utf8 Class Initialized
DEBUG - 2011-08-05 00:45:58 --> UTF-8 Support Enabled
DEBUG - 2011-08-05 00:45:58 --> URI Class Initialized
DEBUG - 2011-08-05 00:45:58 --> Router Class Initialized
DEBUG - 2011-08-05 00:45:58 --> Output Class Initialized
DEBUG - 2011-08-05 00:45:58 --> Input Class Initialized
DEBUG - 2011-08-05 00:45:58 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-05 00:45:58 --> Language Class Initialized
DEBUG - 2011-08-05 00:45:58 --> Loader Class Initialized
DEBUG - 2011-08-05 00:45:58 --> Controller Class Initialized
ERROR - 2011-08-05 00:45:58 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-08-05 00:45:58 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-08-05 00:45:58 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-08-05 00:45:58 --> Model Class Initialized
DEBUG - 2011-08-05 00:45:58 --> Model Class Initialized
DEBUG - 2011-08-05 00:45:58 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-05 00:45:58 --> Database Driver Class Initialized
DEBUG - 2011-08-05 00:45:58 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-08-05 00:45:58 --> Helper loaded: url_helper
DEBUG - 2011-08-05 00:45:58 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-05 00:45:58 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-05 00:45:58 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-05 00:45:58 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-05 00:45:58 --> Final output sent to browser
DEBUG - 2011-08-05 00:45:58 --> Total execution time: 0.0539
DEBUG - 2011-08-05 00:45:59 --> Config Class Initialized
DEBUG - 2011-08-05 00:45:59 --> Hooks Class Initialized
DEBUG - 2011-08-05 00:45:59 --> Utf8 Class Initialized
DEBUG - 2011-08-05 00:45:59 --> UTF-8 Support Enabled
DEBUG - 2011-08-05 00:45:59 --> URI Class Initialized
DEBUG - 2011-08-05 00:45:59 --> Router Class Initialized
DEBUG - 2011-08-05 00:45:59 --> Output Class Initialized
DEBUG - 2011-08-05 00:45:59 --> Input Class Initialized
DEBUG - 2011-08-05 00:45:59 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-05 00:45:59 --> Language Class Initialized
DEBUG - 2011-08-05 00:45:59 --> Loader Class Initialized
DEBUG - 2011-08-05 00:45:59 --> Controller Class Initialized
DEBUG - 2011-08-05 00:45:59 --> Model Class Initialized
DEBUG - 2011-08-05 00:45:59 --> Model Class Initialized
DEBUG - 2011-08-05 00:45:59 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-05 00:45:59 --> Database Driver Class Initialized
DEBUG - 2011-08-05 00:46:00 --> Final output sent to browser
DEBUG - 2011-08-05 00:46:00 --> Total execution time: 0.6132
DEBUG - 2011-08-05 00:46:00 --> Config Class Initialized
DEBUG - 2011-08-05 00:46:00 --> Hooks Class Initialized
DEBUG - 2011-08-05 00:46:00 --> Utf8 Class Initialized
DEBUG - 2011-08-05 00:46:00 --> UTF-8 Support Enabled
DEBUG - 2011-08-05 00:46:00 --> URI Class Initialized
DEBUG - 2011-08-05 00:46:00 --> Router Class Initialized
ERROR - 2011-08-05 00:46:00 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-08-05 00:46:13 --> Config Class Initialized
DEBUG - 2011-08-05 00:46:13 --> Hooks Class Initialized
DEBUG - 2011-08-05 00:46:13 --> Utf8 Class Initialized
DEBUG - 2011-08-05 00:46:13 --> UTF-8 Support Enabled
DEBUG - 2011-08-05 00:46:13 --> URI Class Initialized
DEBUG - 2011-08-05 00:46:13 --> Router Class Initialized
DEBUG - 2011-08-05 00:46:13 --> Output Class Initialized
DEBUG - 2011-08-05 00:46:13 --> Input Class Initialized
DEBUG - 2011-08-05 00:46:13 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-05 00:46:13 --> Language Class Initialized
DEBUG - 2011-08-05 00:46:13 --> Loader Class Initialized
DEBUG - 2011-08-05 00:46:13 --> Controller Class Initialized
ERROR - 2011-08-05 00:46:13 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-08-05 00:46:13 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-08-05 00:46:13 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-08-05 00:46:13 --> Model Class Initialized
DEBUG - 2011-08-05 00:46:13 --> Model Class Initialized
DEBUG - 2011-08-05 00:46:13 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-05 00:46:13 --> Database Driver Class Initialized
DEBUG - 2011-08-05 00:46:13 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-08-05 00:46:13 --> Helper loaded: url_helper
DEBUG - 2011-08-05 00:46:13 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-05 00:46:13 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-05 00:46:13 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-05 00:46:13 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-05 00:46:13 --> Final output sent to browser
DEBUG - 2011-08-05 00:46:13 --> Total execution time: 0.0864
DEBUG - 2011-08-05 00:46:13 --> Config Class Initialized
DEBUG - 2011-08-05 00:46:13 --> Hooks Class Initialized
DEBUG - 2011-08-05 00:46:13 --> Utf8 Class Initialized
DEBUG - 2011-08-05 00:46:13 --> UTF-8 Support Enabled
DEBUG - 2011-08-05 00:46:13 --> URI Class Initialized
DEBUG - 2011-08-05 00:46:13 --> Router Class Initialized
DEBUG - 2011-08-05 00:46:13 --> Output Class Initialized
DEBUG - 2011-08-05 00:46:13 --> Input Class Initialized
DEBUG - 2011-08-05 00:46:13 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-05 00:46:13 --> Language Class Initialized
DEBUG - 2011-08-05 00:46:13 --> Loader Class Initialized
DEBUG - 2011-08-05 00:46:13 --> Controller Class Initialized
DEBUG - 2011-08-05 00:46:13 --> Model Class Initialized
DEBUG - 2011-08-05 00:46:13 --> Model Class Initialized
DEBUG - 2011-08-05 00:46:13 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-05 00:46:13 --> Database Driver Class Initialized
DEBUG - 2011-08-05 00:46:14 --> Final output sent to browser
DEBUG - 2011-08-05 00:46:14 --> Total execution time: 0.8353
DEBUG - 2011-08-05 00:46:15 --> Config Class Initialized
DEBUG - 2011-08-05 00:46:15 --> Hooks Class Initialized
DEBUG - 2011-08-05 00:46:15 --> Utf8 Class Initialized
DEBUG - 2011-08-05 00:46:15 --> UTF-8 Support Enabled
DEBUG - 2011-08-05 00:46:15 --> URI Class Initialized
DEBUG - 2011-08-05 00:46:15 --> Router Class Initialized
ERROR - 2011-08-05 00:46:15 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-08-05 00:46:15 --> Config Class Initialized
DEBUG - 2011-08-05 00:46:15 --> Hooks Class Initialized
DEBUG - 2011-08-05 00:46:15 --> Utf8 Class Initialized
DEBUG - 2011-08-05 00:46:15 --> UTF-8 Support Enabled
DEBUG - 2011-08-05 00:46:15 --> URI Class Initialized
DEBUG - 2011-08-05 00:46:15 --> Router Class Initialized
DEBUG - 2011-08-05 00:46:15 --> Output Class Initialized
DEBUG - 2011-08-05 00:46:15 --> Input Class Initialized
DEBUG - 2011-08-05 00:46:15 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-05 00:46:15 --> Language Class Initialized
DEBUG - 2011-08-05 00:46:15 --> Loader Class Initialized
DEBUG - 2011-08-05 00:46:15 --> Controller Class Initialized
ERROR - 2011-08-05 00:46:15 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-08-05 00:46:15 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-08-05 00:46:15 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-08-05 00:46:15 --> Model Class Initialized
DEBUG - 2011-08-05 00:46:15 --> Model Class Initialized
DEBUG - 2011-08-05 00:46:15 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-05 00:46:15 --> Database Driver Class Initialized
DEBUG - 2011-08-05 00:46:15 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-08-05 00:46:15 --> Helper loaded: url_helper
DEBUG - 2011-08-05 00:46:15 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-05 00:46:15 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-05 00:46:15 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-05 00:46:15 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-05 00:46:15 --> Final output sent to browser
DEBUG - 2011-08-05 00:46:15 --> Total execution time: 0.0484
DEBUG - 2011-08-05 00:46:21 --> Config Class Initialized
DEBUG - 2011-08-05 00:46:21 --> Hooks Class Initialized
DEBUG - 2011-08-05 00:46:21 --> Utf8 Class Initialized
DEBUG - 2011-08-05 00:46:21 --> UTF-8 Support Enabled
DEBUG - 2011-08-05 00:46:21 --> URI Class Initialized
DEBUG - 2011-08-05 00:46:21 --> Router Class Initialized
DEBUG - 2011-08-05 00:46:21 --> Output Class Initialized
DEBUG - 2011-08-05 00:46:21 --> Input Class Initialized
DEBUG - 2011-08-05 00:46:21 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-05 00:46:21 --> Language Class Initialized
DEBUG - 2011-08-05 00:46:21 --> Loader Class Initialized
DEBUG - 2011-08-05 00:46:21 --> Controller Class Initialized
ERROR - 2011-08-05 00:46:21 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-08-05 00:46:21 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-08-05 00:46:21 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-08-05 00:46:21 --> Model Class Initialized
DEBUG - 2011-08-05 00:46:21 --> Model Class Initialized
DEBUG - 2011-08-05 00:46:21 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-05 00:46:21 --> Database Driver Class Initialized
DEBUG - 2011-08-05 00:46:21 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-08-05 00:46:21 --> Helper loaded: url_helper
DEBUG - 2011-08-05 00:46:21 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-05 00:46:21 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-05 00:46:21 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-05 00:46:21 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-05 00:46:21 --> Final output sent to browser
DEBUG - 2011-08-05 00:46:21 --> Total execution time: 0.0379
DEBUG - 2011-08-05 00:46:25 --> Config Class Initialized
DEBUG - 2011-08-05 00:46:25 --> Hooks Class Initialized
DEBUG - 2011-08-05 00:46:25 --> Utf8 Class Initialized
DEBUG - 2011-08-05 00:46:25 --> UTF-8 Support Enabled
DEBUG - 2011-08-05 00:46:25 --> URI Class Initialized
DEBUG - 2011-08-05 00:46:25 --> Router Class Initialized
DEBUG - 2011-08-05 00:46:25 --> Output Class Initialized
DEBUG - 2011-08-05 00:46:25 --> Input Class Initialized
DEBUG - 2011-08-05 00:46:25 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-05 00:46:25 --> Language Class Initialized
DEBUG - 2011-08-05 00:46:25 --> Loader Class Initialized
DEBUG - 2011-08-05 00:46:25 --> Controller Class Initialized
ERROR - 2011-08-05 00:46:25 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-08-05 00:46:25 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-08-05 00:46:25 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-08-05 00:46:25 --> Model Class Initialized
DEBUG - 2011-08-05 00:46:25 --> Model Class Initialized
DEBUG - 2011-08-05 00:46:25 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-05 00:46:25 --> Database Driver Class Initialized
DEBUG - 2011-08-05 00:46:25 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-08-05 00:46:25 --> Helper loaded: url_helper
DEBUG - 2011-08-05 00:46:25 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-05 00:46:25 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-05 00:46:25 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-05 00:46:25 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-05 00:46:25 --> Final output sent to browser
DEBUG - 2011-08-05 00:46:25 --> Total execution time: 0.0402
DEBUG - 2011-08-05 00:46:26 --> Config Class Initialized
DEBUG - 2011-08-05 00:46:26 --> Hooks Class Initialized
DEBUG - 2011-08-05 00:46:26 --> Utf8 Class Initialized
DEBUG - 2011-08-05 00:46:26 --> UTF-8 Support Enabled
DEBUG - 2011-08-05 00:46:26 --> URI Class Initialized
DEBUG - 2011-08-05 00:46:26 --> Router Class Initialized
DEBUG - 2011-08-05 00:46:26 --> Output Class Initialized
DEBUG - 2011-08-05 00:46:26 --> Input Class Initialized
DEBUG - 2011-08-05 00:46:26 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-05 00:46:26 --> Language Class Initialized
DEBUG - 2011-08-05 00:46:26 --> Loader Class Initialized
DEBUG - 2011-08-05 00:46:26 --> Controller Class Initialized
DEBUG - 2011-08-05 00:46:26 --> Model Class Initialized
DEBUG - 2011-08-05 00:46:26 --> Model Class Initialized
DEBUG - 2011-08-05 00:46:26 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-05 00:46:26 --> Database Driver Class Initialized
DEBUG - 2011-08-05 00:46:26 --> Config Class Initialized
DEBUG - 2011-08-05 00:46:26 --> Hooks Class Initialized
DEBUG - 2011-08-05 00:46:26 --> Utf8 Class Initialized
DEBUG - 2011-08-05 00:46:26 --> UTF-8 Support Enabled
DEBUG - 2011-08-05 00:46:26 --> URI Class Initialized
DEBUG - 2011-08-05 00:46:26 --> Router Class Initialized
DEBUG - 2011-08-05 00:46:26 --> Output Class Initialized
DEBUG - 2011-08-05 00:46:26 --> Input Class Initialized
DEBUG - 2011-08-05 00:46:26 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-05 00:46:26 --> Language Class Initialized
DEBUG - 2011-08-05 00:46:26 --> Loader Class Initialized
DEBUG - 2011-08-05 00:46:26 --> Controller Class Initialized
ERROR - 2011-08-05 00:46:26 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-08-05 00:46:26 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-08-05 00:46:26 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-08-05 00:46:26 --> Model Class Initialized
DEBUG - 2011-08-05 00:46:26 --> Model Class Initialized
DEBUG - 2011-08-05 00:46:26 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-05 00:46:26 --> Database Driver Class Initialized
DEBUG - 2011-08-05 00:46:26 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-08-05 00:46:26 --> Helper loaded: url_helper
DEBUG - 2011-08-05 00:46:26 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-05 00:46:26 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-05 00:46:26 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-05 00:46:26 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-05 00:46:26 --> Final output sent to browser
DEBUG - 2011-08-05 00:46:26 --> Total execution time: 0.0284
DEBUG - 2011-08-05 00:46:26 --> Final output sent to browser
DEBUG - 2011-08-05 00:46:26 --> Total execution time: 0.5531
DEBUG - 2011-08-05 00:46:27 --> Config Class Initialized
DEBUG - 2011-08-05 00:46:27 --> Hooks Class Initialized
DEBUG - 2011-08-05 00:46:27 --> Utf8 Class Initialized
DEBUG - 2011-08-05 00:46:27 --> UTF-8 Support Enabled
DEBUG - 2011-08-05 00:46:27 --> URI Class Initialized
DEBUG - 2011-08-05 00:46:27 --> Router Class Initialized
ERROR - 2011-08-05 00:46:27 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-08-05 00:46:35 --> Config Class Initialized
DEBUG - 2011-08-05 00:46:35 --> Hooks Class Initialized
DEBUG - 2011-08-05 00:46:35 --> Utf8 Class Initialized
DEBUG - 2011-08-05 00:46:35 --> UTF-8 Support Enabled
DEBUG - 2011-08-05 00:46:35 --> URI Class Initialized
DEBUG - 2011-08-05 00:46:35 --> Router Class Initialized
DEBUG - 2011-08-05 00:46:35 --> Output Class Initialized
DEBUG - 2011-08-05 00:46:35 --> Input Class Initialized
DEBUG - 2011-08-05 00:46:35 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-05 00:46:35 --> Language Class Initialized
DEBUG - 2011-08-05 00:46:35 --> Loader Class Initialized
DEBUG - 2011-08-05 00:46:35 --> Controller Class Initialized
ERROR - 2011-08-05 00:46:35 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-08-05 00:46:35 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-08-05 00:46:35 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-08-05 00:46:35 --> Model Class Initialized
DEBUG - 2011-08-05 00:46:35 --> Model Class Initialized
DEBUG - 2011-08-05 00:46:35 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-05 00:46:35 --> Database Driver Class Initialized
DEBUG - 2011-08-05 00:46:35 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-08-05 00:46:35 --> Helper loaded: url_helper
DEBUG - 2011-08-05 00:46:35 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-05 00:46:35 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-05 00:46:35 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-05 00:46:35 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-05 00:46:35 --> Final output sent to browser
DEBUG - 2011-08-05 00:46:35 --> Total execution time: 0.0346
DEBUG - 2011-08-05 00:46:36 --> Config Class Initialized
DEBUG - 2011-08-05 00:46:36 --> Hooks Class Initialized
DEBUG - 2011-08-05 00:46:36 --> Utf8 Class Initialized
DEBUG - 2011-08-05 00:46:36 --> UTF-8 Support Enabled
DEBUG - 2011-08-05 00:46:36 --> URI Class Initialized
DEBUG - 2011-08-05 00:46:36 --> Router Class Initialized
DEBUG - 2011-08-05 00:46:36 --> Output Class Initialized
DEBUG - 2011-08-05 00:46:36 --> Input Class Initialized
DEBUG - 2011-08-05 00:46:36 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-05 00:46:36 --> Language Class Initialized
DEBUG - 2011-08-05 00:46:36 --> Loader Class Initialized
DEBUG - 2011-08-05 00:46:36 --> Controller Class Initialized
DEBUG - 2011-08-05 00:46:36 --> Model Class Initialized
DEBUG - 2011-08-05 00:46:36 --> Model Class Initialized
DEBUG - 2011-08-05 00:46:36 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-05 00:46:36 --> Database Driver Class Initialized
DEBUG - 2011-08-05 00:46:36 --> Final output sent to browser
DEBUG - 2011-08-05 00:46:36 --> Total execution time: 0.5460
DEBUG - 2011-08-05 00:46:36 --> Config Class Initialized
DEBUG - 2011-08-05 00:46:36 --> Hooks Class Initialized
DEBUG - 2011-08-05 00:46:36 --> Utf8 Class Initialized
DEBUG - 2011-08-05 00:46:36 --> UTF-8 Support Enabled
DEBUG - 2011-08-05 00:46:36 --> URI Class Initialized
DEBUG - 2011-08-05 00:46:36 --> Router Class Initialized
DEBUG - 2011-08-05 00:46:36 --> Output Class Initialized
DEBUG - 2011-08-05 00:46:36 --> Input Class Initialized
DEBUG - 2011-08-05 00:46:36 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-05 00:46:36 --> Language Class Initialized
DEBUG - 2011-08-05 00:46:36 --> Loader Class Initialized
DEBUG - 2011-08-05 00:46:36 --> Controller Class Initialized
ERROR - 2011-08-05 00:46:36 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-08-05 00:46:36 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-08-05 00:46:36 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-08-05 00:46:36 --> Model Class Initialized
DEBUG - 2011-08-05 00:46:36 --> Model Class Initialized
DEBUG - 2011-08-05 00:46:36 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-05 00:46:36 --> Database Driver Class Initialized
DEBUG - 2011-08-05 00:46:36 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-08-05 00:46:36 --> Helper loaded: url_helper
DEBUG - 2011-08-05 00:46:36 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-05 00:46:36 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-05 00:46:36 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-05 00:46:36 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-05 00:46:36 --> Final output sent to browser
DEBUG - 2011-08-05 00:46:36 --> Total execution time: 0.0302
DEBUG - 2011-08-05 00:46:37 --> Config Class Initialized
DEBUG - 2011-08-05 00:46:37 --> Hooks Class Initialized
DEBUG - 2011-08-05 00:46:37 --> Utf8 Class Initialized
DEBUG - 2011-08-05 00:46:37 --> UTF-8 Support Enabled
DEBUG - 2011-08-05 00:46:37 --> URI Class Initialized
DEBUG - 2011-08-05 00:46:37 --> Router Class Initialized
ERROR - 2011-08-05 00:46:37 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-08-05 00:46:52 --> Config Class Initialized
DEBUG - 2011-08-05 00:46:52 --> Hooks Class Initialized
DEBUG - 2011-08-05 00:46:52 --> Utf8 Class Initialized
DEBUG - 2011-08-05 00:46:52 --> UTF-8 Support Enabled
DEBUG - 2011-08-05 00:46:52 --> URI Class Initialized
DEBUG - 2011-08-05 00:46:52 --> Router Class Initialized
DEBUG - 2011-08-05 00:46:52 --> Output Class Initialized
DEBUG - 2011-08-05 00:46:52 --> Input Class Initialized
DEBUG - 2011-08-05 00:46:52 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-05 00:46:52 --> Language Class Initialized
DEBUG - 2011-08-05 00:46:52 --> Loader Class Initialized
DEBUG - 2011-08-05 00:46:52 --> Controller Class Initialized
ERROR - 2011-08-05 00:46:52 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-08-05 00:46:52 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-08-05 00:46:52 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-08-05 00:46:52 --> Model Class Initialized
DEBUG - 2011-08-05 00:46:52 --> Model Class Initialized
DEBUG - 2011-08-05 00:46:52 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-05 00:46:52 --> Database Driver Class Initialized
DEBUG - 2011-08-05 00:46:52 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-08-05 00:46:52 --> Helper loaded: url_helper
DEBUG - 2011-08-05 00:46:52 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-05 00:46:52 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-05 00:46:52 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-05 00:46:52 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-05 00:46:52 --> Final output sent to browser
DEBUG - 2011-08-05 00:46:52 --> Total execution time: 0.0370
DEBUG - 2011-08-05 00:46:52 --> Config Class Initialized
DEBUG - 2011-08-05 00:46:52 --> Hooks Class Initialized
DEBUG - 2011-08-05 00:46:52 --> Utf8 Class Initialized
DEBUG - 2011-08-05 00:46:52 --> UTF-8 Support Enabled
DEBUG - 2011-08-05 00:46:52 --> URI Class Initialized
DEBUG - 2011-08-05 00:46:52 --> Router Class Initialized
DEBUG - 2011-08-05 00:46:52 --> Output Class Initialized
DEBUG - 2011-08-05 00:46:52 --> Input Class Initialized
DEBUG - 2011-08-05 00:46:52 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-05 00:46:52 --> Language Class Initialized
DEBUG - 2011-08-05 00:46:52 --> Loader Class Initialized
DEBUG - 2011-08-05 00:46:52 --> Controller Class Initialized
DEBUG - 2011-08-05 00:46:52 --> Model Class Initialized
DEBUG - 2011-08-05 00:46:52 --> Model Class Initialized
DEBUG - 2011-08-05 00:46:52 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-05 00:46:52 --> Database Driver Class Initialized
DEBUG - 2011-08-05 00:46:58 --> Final output sent to browser
DEBUG - 2011-08-05 00:46:58 --> Total execution time: 5.5257
DEBUG - 2011-08-05 00:46:59 --> Config Class Initialized
DEBUG - 2011-08-05 00:46:59 --> Hooks Class Initialized
DEBUG - 2011-08-05 00:46:59 --> Utf8 Class Initialized
DEBUG - 2011-08-05 00:46:59 --> UTF-8 Support Enabled
DEBUG - 2011-08-05 00:46:59 --> URI Class Initialized
DEBUG - 2011-08-05 00:46:59 --> Router Class Initialized
ERROR - 2011-08-05 00:46:59 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-08-05 00:47:05 --> Config Class Initialized
DEBUG - 2011-08-05 00:47:05 --> Hooks Class Initialized
DEBUG - 2011-08-05 00:47:05 --> Utf8 Class Initialized
DEBUG - 2011-08-05 00:47:05 --> UTF-8 Support Enabled
DEBUG - 2011-08-05 00:47:05 --> URI Class Initialized
DEBUG - 2011-08-05 00:47:05 --> Router Class Initialized
DEBUG - 2011-08-05 00:47:05 --> Output Class Initialized
DEBUG - 2011-08-05 00:47:05 --> Input Class Initialized
DEBUG - 2011-08-05 00:47:05 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-05 00:47:05 --> Language Class Initialized
DEBUG - 2011-08-05 00:47:05 --> Loader Class Initialized
DEBUG - 2011-08-05 00:47:05 --> Controller Class Initialized
ERROR - 2011-08-05 00:47:05 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-08-05 00:47:05 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-08-05 00:47:05 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-08-05 00:47:05 --> Model Class Initialized
DEBUG - 2011-08-05 00:47:05 --> Model Class Initialized
DEBUG - 2011-08-05 00:47:05 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-05 00:47:05 --> Database Driver Class Initialized
DEBUG - 2011-08-05 00:47:05 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-08-05 00:47:05 --> Helper loaded: url_helper
DEBUG - 2011-08-05 00:47:05 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-05 00:47:05 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-05 00:47:05 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-05 00:47:05 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-05 00:47:05 --> Final output sent to browser
DEBUG - 2011-08-05 00:47:05 --> Total execution time: 0.0303
DEBUG - 2011-08-05 00:47:06 --> Config Class Initialized
DEBUG - 2011-08-05 00:47:06 --> Hooks Class Initialized
DEBUG - 2011-08-05 00:47:06 --> Utf8 Class Initialized
DEBUG - 2011-08-05 00:47:06 --> UTF-8 Support Enabled
DEBUG - 2011-08-05 00:47:06 --> URI Class Initialized
DEBUG - 2011-08-05 00:47:06 --> Router Class Initialized
DEBUG - 2011-08-05 00:47:06 --> Output Class Initialized
DEBUG - 2011-08-05 00:47:06 --> Input Class Initialized
DEBUG - 2011-08-05 00:47:06 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-05 00:47:06 --> Language Class Initialized
DEBUG - 2011-08-05 00:47:06 --> Loader Class Initialized
DEBUG - 2011-08-05 00:47:06 --> Controller Class Initialized
DEBUG - 2011-08-05 00:47:06 --> Model Class Initialized
DEBUG - 2011-08-05 00:47:06 --> Model Class Initialized
DEBUG - 2011-08-05 00:47:06 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-05 00:47:06 --> Database Driver Class Initialized
DEBUG - 2011-08-05 00:47:06 --> Final output sent to browser
DEBUG - 2011-08-05 00:47:06 --> Total execution time: 0.5520
DEBUG - 2011-08-05 00:47:07 --> Config Class Initialized
DEBUG - 2011-08-05 00:47:07 --> Hooks Class Initialized
DEBUG - 2011-08-05 00:47:07 --> Utf8 Class Initialized
DEBUG - 2011-08-05 00:47:07 --> UTF-8 Support Enabled
DEBUG - 2011-08-05 00:47:07 --> URI Class Initialized
DEBUG - 2011-08-05 00:47:07 --> Router Class Initialized
ERROR - 2011-08-05 00:47:07 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-08-05 00:47:19 --> Config Class Initialized
DEBUG - 2011-08-05 00:47:19 --> Hooks Class Initialized
DEBUG - 2011-08-05 00:47:19 --> Utf8 Class Initialized
DEBUG - 2011-08-05 00:47:19 --> UTF-8 Support Enabled
DEBUG - 2011-08-05 00:47:19 --> URI Class Initialized
DEBUG - 2011-08-05 00:47:19 --> Router Class Initialized
DEBUG - 2011-08-05 00:47:19 --> Output Class Initialized
DEBUG - 2011-08-05 00:47:19 --> Input Class Initialized
DEBUG - 2011-08-05 00:47:19 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-05 00:47:19 --> Language Class Initialized
DEBUG - 2011-08-05 00:47:19 --> Loader Class Initialized
DEBUG - 2011-08-05 00:47:19 --> Controller Class Initialized
ERROR - 2011-08-05 00:47:19 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-08-05 00:47:19 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-08-05 00:47:19 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-08-05 00:47:19 --> Model Class Initialized
DEBUG - 2011-08-05 00:47:19 --> Model Class Initialized
DEBUG - 2011-08-05 00:47:19 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-05 00:47:19 --> Database Driver Class Initialized
DEBUG - 2011-08-05 00:47:19 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-08-05 00:47:19 --> Helper loaded: url_helper
DEBUG - 2011-08-05 00:47:19 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-05 00:47:19 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-05 00:47:19 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-05 00:47:19 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-05 00:47:19 --> Final output sent to browser
DEBUG - 2011-08-05 00:47:19 --> Total execution time: 0.0723
DEBUG - 2011-08-05 00:47:20 --> Config Class Initialized
DEBUG - 2011-08-05 00:47:20 --> Hooks Class Initialized
DEBUG - 2011-08-05 00:47:20 --> Utf8 Class Initialized
DEBUG - 2011-08-05 00:47:20 --> UTF-8 Support Enabled
DEBUG - 2011-08-05 00:47:20 --> URI Class Initialized
DEBUG - 2011-08-05 00:47:20 --> Router Class Initialized
DEBUG - 2011-08-05 00:47:20 --> Output Class Initialized
DEBUG - 2011-08-05 00:47:20 --> Input Class Initialized
DEBUG - 2011-08-05 00:47:20 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-05 00:47:20 --> Language Class Initialized
DEBUG - 2011-08-05 00:47:20 --> Loader Class Initialized
DEBUG - 2011-08-05 00:47:20 --> Controller Class Initialized
DEBUG - 2011-08-05 00:47:20 --> Model Class Initialized
DEBUG - 2011-08-05 00:47:20 --> Model Class Initialized
DEBUG - 2011-08-05 00:47:20 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-05 00:47:20 --> Database Driver Class Initialized
DEBUG - 2011-08-05 00:47:20 --> Final output sent to browser
DEBUG - 2011-08-05 00:47:20 --> Total execution time: 0.7253
DEBUG - 2011-08-05 00:47:21 --> Config Class Initialized
DEBUG - 2011-08-05 00:47:21 --> Hooks Class Initialized
DEBUG - 2011-08-05 00:47:21 --> Utf8 Class Initialized
DEBUG - 2011-08-05 00:47:21 --> UTF-8 Support Enabled
DEBUG - 2011-08-05 00:47:21 --> URI Class Initialized
DEBUG - 2011-08-05 00:47:21 --> Router Class Initialized
ERROR - 2011-08-05 00:47:21 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-08-05 00:47:23 --> Config Class Initialized
DEBUG - 2011-08-05 00:47:23 --> Hooks Class Initialized
DEBUG - 2011-08-05 00:47:23 --> Utf8 Class Initialized
DEBUG - 2011-08-05 00:47:23 --> UTF-8 Support Enabled
DEBUG - 2011-08-05 00:47:23 --> URI Class Initialized
DEBUG - 2011-08-05 00:47:23 --> Router Class Initialized
DEBUG - 2011-08-05 00:47:23 --> Output Class Initialized
DEBUG - 2011-08-05 00:47:23 --> Input Class Initialized
DEBUG - 2011-08-05 00:47:23 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-05 00:47:23 --> Language Class Initialized
DEBUG - 2011-08-05 00:47:23 --> Loader Class Initialized
DEBUG - 2011-08-05 00:47:23 --> Controller Class Initialized
ERROR - 2011-08-05 00:47:23 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-08-05 00:47:23 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-08-05 00:47:23 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-08-05 00:47:23 --> Model Class Initialized
DEBUG - 2011-08-05 00:47:23 --> Model Class Initialized
DEBUG - 2011-08-05 00:47:23 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-05 00:47:23 --> Database Driver Class Initialized
DEBUG - 2011-08-05 00:47:24 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-08-05 00:47:24 --> Helper loaded: url_helper
DEBUG - 2011-08-05 00:47:24 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-05 00:47:24 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-05 00:47:24 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-05 00:47:24 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-05 00:47:24 --> Final output sent to browser
DEBUG - 2011-08-05 00:47:24 --> Total execution time: 0.0910
DEBUG - 2011-08-05 00:47:31 --> Config Class Initialized
DEBUG - 2011-08-05 00:47:31 --> Hooks Class Initialized
DEBUG - 2011-08-05 00:47:31 --> Utf8 Class Initialized
DEBUG - 2011-08-05 00:47:31 --> UTF-8 Support Enabled
DEBUG - 2011-08-05 00:47:31 --> URI Class Initialized
DEBUG - 2011-08-05 00:47:31 --> Router Class Initialized
DEBUG - 2011-08-05 00:47:31 --> Output Class Initialized
DEBUG - 2011-08-05 00:47:31 --> Input Class Initialized
DEBUG - 2011-08-05 00:47:31 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-05 00:47:31 --> Language Class Initialized
DEBUG - 2011-08-05 00:47:31 --> Loader Class Initialized
DEBUG - 2011-08-05 00:47:31 --> Controller Class Initialized
ERROR - 2011-08-05 00:47:31 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-08-05 00:47:31 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-08-05 00:47:31 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-08-05 00:47:31 --> Model Class Initialized
DEBUG - 2011-08-05 00:47:31 --> Model Class Initialized
DEBUG - 2011-08-05 00:47:31 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-05 00:47:31 --> Database Driver Class Initialized
DEBUG - 2011-08-05 00:47:31 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-08-05 00:47:31 --> Helper loaded: url_helper
DEBUG - 2011-08-05 00:47:31 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-05 00:47:31 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-05 00:47:31 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-05 00:47:31 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-05 00:47:31 --> Final output sent to browser
DEBUG - 2011-08-05 00:47:31 --> Total execution time: 0.0482
DEBUG - 2011-08-05 00:47:33 --> Config Class Initialized
DEBUG - 2011-08-05 00:47:33 --> Hooks Class Initialized
DEBUG - 2011-08-05 00:47:33 --> Utf8 Class Initialized
DEBUG - 2011-08-05 00:47:33 --> UTF-8 Support Enabled
DEBUG - 2011-08-05 00:47:33 --> URI Class Initialized
DEBUG - 2011-08-05 00:47:33 --> Router Class Initialized
DEBUG - 2011-08-05 00:47:33 --> Output Class Initialized
DEBUG - 2011-08-05 00:47:33 --> Input Class Initialized
DEBUG - 2011-08-05 00:47:33 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-05 00:47:34 --> Language Class Initialized
DEBUG - 2011-08-05 00:47:34 --> Loader Class Initialized
DEBUG - 2011-08-05 00:47:34 --> Controller Class Initialized
ERROR - 2011-08-05 00:47:34 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-08-05 00:47:34 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-08-05 00:47:34 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-08-05 00:47:34 --> Model Class Initialized
DEBUG - 2011-08-05 00:47:34 --> Model Class Initialized
DEBUG - 2011-08-05 00:47:34 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-05 00:47:34 --> Database Driver Class Initialized
DEBUG - 2011-08-05 00:47:34 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-08-05 00:47:34 --> Helper loaded: url_helper
DEBUG - 2011-08-05 00:47:34 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-05 00:47:34 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-05 00:47:34 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-05 00:47:34 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-05 00:47:34 --> Final output sent to browser
DEBUG - 2011-08-05 00:47:34 --> Total execution time: 0.1461
DEBUG - 2011-08-05 00:47:34 --> Config Class Initialized
DEBUG - 2011-08-05 00:47:34 --> Hooks Class Initialized
DEBUG - 2011-08-05 00:47:34 --> Utf8 Class Initialized
DEBUG - 2011-08-05 00:47:34 --> UTF-8 Support Enabled
DEBUG - 2011-08-05 00:47:34 --> URI Class Initialized
DEBUG - 2011-08-05 00:47:34 --> Router Class Initialized
DEBUG - 2011-08-05 00:47:34 --> Output Class Initialized
DEBUG - 2011-08-05 00:47:34 --> Input Class Initialized
DEBUG - 2011-08-05 00:47:34 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-05 00:47:34 --> Language Class Initialized
DEBUG - 2011-08-05 00:47:34 --> Loader Class Initialized
DEBUG - 2011-08-05 00:47:34 --> Controller Class Initialized
DEBUG - 2011-08-05 00:47:34 --> Model Class Initialized
DEBUG - 2011-08-05 00:47:34 --> Model Class Initialized
DEBUG - 2011-08-05 00:47:34 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-05 00:47:34 --> Database Driver Class Initialized
DEBUG - 2011-08-05 00:47:35 --> Final output sent to browser
DEBUG - 2011-08-05 00:47:35 --> Total execution time: 0.6036
DEBUG - 2011-08-05 00:47:35 --> Config Class Initialized
DEBUG - 2011-08-05 00:47:35 --> Hooks Class Initialized
DEBUG - 2011-08-05 00:47:35 --> Utf8 Class Initialized
DEBUG - 2011-08-05 00:47:35 --> UTF-8 Support Enabled
DEBUG - 2011-08-05 00:47:35 --> URI Class Initialized
DEBUG - 2011-08-05 00:47:35 --> Router Class Initialized
ERROR - 2011-08-05 00:47:35 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-08-05 00:47:45 --> Config Class Initialized
DEBUG - 2011-08-05 00:47:45 --> Hooks Class Initialized
DEBUG - 2011-08-05 00:47:45 --> Utf8 Class Initialized
DEBUG - 2011-08-05 00:47:45 --> UTF-8 Support Enabled
DEBUG - 2011-08-05 00:47:45 --> URI Class Initialized
DEBUG - 2011-08-05 00:47:45 --> Router Class Initialized
DEBUG - 2011-08-05 00:47:45 --> Output Class Initialized
DEBUG - 2011-08-05 00:47:45 --> Input Class Initialized
DEBUG - 2011-08-05 00:47:45 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-05 00:47:45 --> Language Class Initialized
DEBUG - 2011-08-05 00:47:45 --> Loader Class Initialized
DEBUG - 2011-08-05 00:47:45 --> Controller Class Initialized
ERROR - 2011-08-05 00:47:45 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-08-05 00:47:45 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-08-05 00:47:45 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-08-05 00:47:45 --> Model Class Initialized
DEBUG - 2011-08-05 00:47:45 --> Model Class Initialized
DEBUG - 2011-08-05 00:47:45 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-05 00:47:45 --> Database Driver Class Initialized
DEBUG - 2011-08-05 00:47:45 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-08-05 00:47:45 --> Helper loaded: url_helper
DEBUG - 2011-08-05 00:47:45 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-05 00:47:45 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-05 00:47:45 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-05 00:47:45 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-05 00:47:45 --> Final output sent to browser
DEBUG - 2011-08-05 00:47:45 --> Total execution time: 0.0762
DEBUG - 2011-08-05 00:47:45 --> Config Class Initialized
DEBUG - 2011-08-05 00:47:45 --> Hooks Class Initialized
DEBUG - 2011-08-05 00:47:45 --> Utf8 Class Initialized
DEBUG - 2011-08-05 00:47:45 --> UTF-8 Support Enabled
DEBUG - 2011-08-05 00:47:45 --> URI Class Initialized
DEBUG - 2011-08-05 00:47:45 --> Router Class Initialized
DEBUG - 2011-08-05 00:47:45 --> Output Class Initialized
DEBUG - 2011-08-05 00:47:45 --> Input Class Initialized
DEBUG - 2011-08-05 00:47:45 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-05 00:47:45 --> Language Class Initialized
DEBUG - 2011-08-05 00:47:45 --> Loader Class Initialized
DEBUG - 2011-08-05 00:47:45 --> Controller Class Initialized
DEBUG - 2011-08-05 00:47:45 --> Model Class Initialized
DEBUG - 2011-08-05 00:47:45 --> Model Class Initialized
DEBUG - 2011-08-05 00:47:45 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-05 00:47:45 --> Database Driver Class Initialized
DEBUG - 2011-08-05 00:47:46 --> Final output sent to browser
DEBUG - 2011-08-05 00:47:46 --> Total execution time: 0.9587
DEBUG - 2011-08-05 00:47:47 --> Config Class Initialized
DEBUG - 2011-08-05 00:47:47 --> Hooks Class Initialized
DEBUG - 2011-08-05 00:47:47 --> Utf8 Class Initialized
DEBUG - 2011-08-05 00:47:47 --> UTF-8 Support Enabled
DEBUG - 2011-08-05 00:47:47 --> URI Class Initialized
DEBUG - 2011-08-05 00:47:47 --> Router Class Initialized
ERROR - 2011-08-05 00:47:47 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-08-05 00:47:58 --> Config Class Initialized
DEBUG - 2011-08-05 00:47:58 --> Hooks Class Initialized
DEBUG - 2011-08-05 00:47:58 --> Utf8 Class Initialized
DEBUG - 2011-08-05 00:47:58 --> UTF-8 Support Enabled
DEBUG - 2011-08-05 00:47:58 --> URI Class Initialized
DEBUG - 2011-08-05 00:47:58 --> Router Class Initialized
DEBUG - 2011-08-05 00:47:58 --> Output Class Initialized
DEBUG - 2011-08-05 00:47:58 --> Input Class Initialized
DEBUG - 2011-08-05 00:47:58 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-05 00:47:58 --> Language Class Initialized
DEBUG - 2011-08-05 00:47:58 --> Loader Class Initialized
DEBUG - 2011-08-05 00:47:58 --> Controller Class Initialized
ERROR - 2011-08-05 00:47:58 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-08-05 00:47:58 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-08-05 00:47:58 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-08-05 00:47:58 --> Model Class Initialized
DEBUG - 2011-08-05 00:47:58 --> Model Class Initialized
DEBUG - 2011-08-05 00:47:58 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-05 00:47:58 --> Database Driver Class Initialized
DEBUG - 2011-08-05 00:47:58 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-08-05 00:47:58 --> Helper loaded: url_helper
DEBUG - 2011-08-05 00:47:58 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-05 00:47:58 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-05 00:47:58 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-05 00:47:58 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-05 00:47:58 --> Final output sent to browser
DEBUG - 2011-08-05 00:47:58 --> Total execution time: 0.0360
DEBUG - 2011-08-05 00:47:59 --> Config Class Initialized
DEBUG - 2011-08-05 00:47:59 --> Hooks Class Initialized
DEBUG - 2011-08-05 00:47:59 --> Utf8 Class Initialized
DEBUG - 2011-08-05 00:47:59 --> UTF-8 Support Enabled
DEBUG - 2011-08-05 00:47:59 --> URI Class Initialized
DEBUG - 2011-08-05 00:47:59 --> Router Class Initialized
DEBUG - 2011-08-05 00:47:59 --> Output Class Initialized
DEBUG - 2011-08-05 00:47:59 --> Input Class Initialized
DEBUG - 2011-08-05 00:47:59 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-05 00:47:59 --> Language Class Initialized
DEBUG - 2011-08-05 00:47:59 --> Loader Class Initialized
DEBUG - 2011-08-05 00:47:59 --> Controller Class Initialized
DEBUG - 2011-08-05 00:47:59 --> Model Class Initialized
DEBUG - 2011-08-05 00:47:59 --> Model Class Initialized
DEBUG - 2011-08-05 00:47:59 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-05 00:47:59 --> Database Driver Class Initialized
DEBUG - 2011-08-05 00:47:59 --> Final output sent to browser
DEBUG - 2011-08-05 00:47:59 --> Total execution time: 0.5604
DEBUG - 2011-08-05 00:48:00 --> Config Class Initialized
DEBUG - 2011-08-05 00:48:00 --> Hooks Class Initialized
DEBUG - 2011-08-05 00:48:00 --> Utf8 Class Initialized
DEBUG - 2011-08-05 00:48:00 --> UTF-8 Support Enabled
DEBUG - 2011-08-05 00:48:00 --> URI Class Initialized
DEBUG - 2011-08-05 00:48:00 --> Router Class Initialized
ERROR - 2011-08-05 00:48:00 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-08-05 00:48:07 --> Config Class Initialized
DEBUG - 2011-08-05 00:48:07 --> Hooks Class Initialized
DEBUG - 2011-08-05 00:48:07 --> Utf8 Class Initialized
DEBUG - 2011-08-05 00:48:07 --> UTF-8 Support Enabled
DEBUG - 2011-08-05 00:48:07 --> URI Class Initialized
DEBUG - 2011-08-05 00:48:07 --> Router Class Initialized
DEBUG - 2011-08-05 00:48:07 --> Output Class Initialized
DEBUG - 2011-08-05 00:48:07 --> Input Class Initialized
DEBUG - 2011-08-05 00:48:07 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-05 00:48:07 --> Language Class Initialized
DEBUG - 2011-08-05 00:48:07 --> Loader Class Initialized
DEBUG - 2011-08-05 00:48:07 --> Controller Class Initialized
ERROR - 2011-08-05 00:48:07 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-08-05 00:48:07 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-08-05 00:48:07 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-08-05 00:48:07 --> Model Class Initialized
DEBUG - 2011-08-05 00:48:07 --> Model Class Initialized
DEBUG - 2011-08-05 00:48:07 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-05 00:48:07 --> Database Driver Class Initialized
DEBUG - 2011-08-05 00:48:07 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-08-05 00:48:07 --> Helper loaded: url_helper
DEBUG - 2011-08-05 00:48:07 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-05 00:48:07 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-05 00:48:07 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-05 00:48:07 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-05 00:48:07 --> Final output sent to browser
DEBUG - 2011-08-05 00:48:07 --> Total execution time: 0.0397
DEBUG - 2011-08-05 00:48:14 --> Config Class Initialized
DEBUG - 2011-08-05 00:48:14 --> Hooks Class Initialized
DEBUG - 2011-08-05 00:48:14 --> Utf8 Class Initialized
DEBUG - 2011-08-05 00:48:14 --> UTF-8 Support Enabled
DEBUG - 2011-08-05 00:48:14 --> URI Class Initialized
DEBUG - 2011-08-05 00:48:14 --> Router Class Initialized
DEBUG - 2011-08-05 00:48:14 --> Output Class Initialized
DEBUG - 2011-08-05 00:48:14 --> Input Class Initialized
DEBUG - 2011-08-05 00:48:14 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-05 00:48:14 --> Language Class Initialized
DEBUG - 2011-08-05 00:48:14 --> Loader Class Initialized
DEBUG - 2011-08-05 00:48:14 --> Controller Class Initialized
ERROR - 2011-08-05 00:48:14 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-08-05 00:48:14 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-08-05 00:48:14 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-08-05 00:48:14 --> Model Class Initialized
DEBUG - 2011-08-05 00:48:14 --> Model Class Initialized
DEBUG - 2011-08-05 00:48:14 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-05 00:48:14 --> Database Driver Class Initialized
DEBUG - 2011-08-05 00:48:14 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-08-05 00:48:14 --> Helper loaded: url_helper
DEBUG - 2011-08-05 00:48:14 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-05 00:48:14 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-05 00:48:14 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-05 00:48:14 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-05 00:48:14 --> Final output sent to browser
DEBUG - 2011-08-05 00:48:14 --> Total execution time: 0.0364
DEBUG - 2011-08-05 00:48:15 --> Config Class Initialized
DEBUG - 2011-08-05 00:48:15 --> Hooks Class Initialized
DEBUG - 2011-08-05 00:48:15 --> Utf8 Class Initialized
DEBUG - 2011-08-05 00:48:15 --> UTF-8 Support Enabled
DEBUG - 2011-08-05 00:48:15 --> URI Class Initialized
DEBUG - 2011-08-05 00:48:15 --> Router Class Initialized
DEBUG - 2011-08-05 00:48:15 --> Output Class Initialized
DEBUG - 2011-08-05 00:48:15 --> Input Class Initialized
DEBUG - 2011-08-05 00:48:15 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-05 00:48:15 --> Language Class Initialized
DEBUG - 2011-08-05 00:48:15 --> Loader Class Initialized
DEBUG - 2011-08-05 00:48:15 --> Controller Class Initialized
DEBUG - 2011-08-05 00:48:15 --> Model Class Initialized
DEBUG - 2011-08-05 00:48:15 --> Model Class Initialized
DEBUG - 2011-08-05 00:48:15 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-05 00:48:15 --> Database Driver Class Initialized
DEBUG - 2011-08-05 00:48:15 --> Final output sent to browser
DEBUG - 2011-08-05 00:48:15 --> Total execution time: 0.6055
DEBUG - 2011-08-05 00:48:16 --> Config Class Initialized
DEBUG - 2011-08-05 00:48:16 --> Hooks Class Initialized
DEBUG - 2011-08-05 00:48:16 --> Utf8 Class Initialized
DEBUG - 2011-08-05 00:48:16 --> UTF-8 Support Enabled
DEBUG - 2011-08-05 00:48:16 --> URI Class Initialized
DEBUG - 2011-08-05 00:48:16 --> Router Class Initialized
ERROR - 2011-08-05 00:48:16 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-08-05 00:48:40 --> Config Class Initialized
DEBUG - 2011-08-05 00:48:40 --> Hooks Class Initialized
DEBUG - 2011-08-05 00:48:40 --> Utf8 Class Initialized
DEBUG - 2011-08-05 00:48:40 --> UTF-8 Support Enabled
DEBUG - 2011-08-05 00:48:40 --> URI Class Initialized
DEBUG - 2011-08-05 00:48:40 --> Router Class Initialized
DEBUG - 2011-08-05 00:48:40 --> Output Class Initialized
DEBUG - 2011-08-05 00:48:40 --> Input Class Initialized
DEBUG - 2011-08-05 00:48:40 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-05 00:48:40 --> Language Class Initialized
DEBUG - 2011-08-05 00:48:40 --> Loader Class Initialized
DEBUG - 2011-08-05 00:48:40 --> Controller Class Initialized
ERROR - 2011-08-05 00:48:40 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-08-05 00:48:40 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-08-05 00:48:40 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-08-05 00:48:40 --> Model Class Initialized
DEBUG - 2011-08-05 00:48:40 --> Model Class Initialized
DEBUG - 2011-08-05 00:48:40 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-05 00:48:40 --> Database Driver Class Initialized
DEBUG - 2011-08-05 00:48:40 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-08-05 00:48:40 --> Helper loaded: url_helper
DEBUG - 2011-08-05 00:48:40 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-05 00:48:40 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-05 00:48:40 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-05 00:48:40 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-05 00:48:40 --> Final output sent to browser
DEBUG - 2011-08-05 00:48:40 --> Total execution time: 0.0280
DEBUG - 2011-08-05 00:48:41 --> Config Class Initialized
DEBUG - 2011-08-05 00:48:41 --> Hooks Class Initialized
DEBUG - 2011-08-05 00:48:41 --> Utf8 Class Initialized
DEBUG - 2011-08-05 00:48:41 --> UTF-8 Support Enabled
DEBUG - 2011-08-05 00:48:41 --> URI Class Initialized
DEBUG - 2011-08-05 00:48:41 --> Router Class Initialized
DEBUG - 2011-08-05 00:48:41 --> Output Class Initialized
DEBUG - 2011-08-05 00:48:41 --> Input Class Initialized
DEBUG - 2011-08-05 00:48:41 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-05 00:48:41 --> Language Class Initialized
DEBUG - 2011-08-05 00:48:41 --> Loader Class Initialized
DEBUG - 2011-08-05 00:48:41 --> Controller Class Initialized
DEBUG - 2011-08-05 00:48:41 --> Model Class Initialized
DEBUG - 2011-08-05 00:48:41 --> Model Class Initialized
DEBUG - 2011-08-05 00:48:41 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-05 00:48:41 --> Database Driver Class Initialized
DEBUG - 2011-08-05 00:48:41 --> Final output sent to browser
DEBUG - 2011-08-05 00:48:41 --> Total execution time: 0.4596
DEBUG - 2011-08-05 00:48:42 --> Config Class Initialized
DEBUG - 2011-08-05 00:48:42 --> Hooks Class Initialized
DEBUG - 2011-08-05 00:48:42 --> Utf8 Class Initialized
DEBUG - 2011-08-05 00:48:42 --> UTF-8 Support Enabled
DEBUG - 2011-08-05 00:48:42 --> URI Class Initialized
DEBUG - 2011-08-05 00:48:42 --> Router Class Initialized
ERROR - 2011-08-05 00:48:42 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-08-05 00:58:42 --> Config Class Initialized
DEBUG - 2011-08-05 00:58:42 --> Hooks Class Initialized
DEBUG - 2011-08-05 00:58:42 --> Utf8 Class Initialized
DEBUG - 2011-08-05 00:58:42 --> UTF-8 Support Enabled
DEBUG - 2011-08-05 00:58:42 --> URI Class Initialized
DEBUG - 2011-08-05 00:58:42 --> Router Class Initialized
ERROR - 2011-08-05 00:58:42 --> 404 Page Not Found --> robots.txt
DEBUG - 2011-08-05 00:58:42 --> Config Class Initialized
DEBUG - 2011-08-05 00:58:42 --> Hooks Class Initialized
DEBUG - 2011-08-05 00:58:42 --> Utf8 Class Initialized
DEBUG - 2011-08-05 00:58:42 --> UTF-8 Support Enabled
DEBUG - 2011-08-05 00:58:42 --> URI Class Initialized
DEBUG - 2011-08-05 00:58:42 --> Router Class Initialized
DEBUG - 2011-08-05 00:58:42 --> Output Class Initialized
DEBUG - 2011-08-05 00:58:42 --> Input Class Initialized
DEBUG - 2011-08-05 00:58:42 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-05 00:58:42 --> Language Class Initialized
DEBUG - 2011-08-05 00:58:42 --> Loader Class Initialized
DEBUG - 2011-08-05 00:58:42 --> Controller Class Initialized
DEBUG - 2011-08-05 00:58:42 --> Model Class Initialized
DEBUG - 2011-08-05 00:58:42 --> Model Class Initialized
DEBUG - 2011-08-05 00:58:42 --> Model Class Initialized
DEBUG - 2011-08-05 00:58:42 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-05 00:58:42 --> Database Driver Class Initialized
DEBUG - 2011-08-05 00:58:44 --> File loaded: application/views/table/main.php
DEBUG - 2011-08-05 00:58:44 --> Helper loaded: url_helper
DEBUG - 2011-08-05 00:58:44 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-05 00:58:44 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-05 00:58:44 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-05 00:58:44 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-05 00:58:44 --> Final output sent to browser
DEBUG - 2011-08-05 00:58:44 --> Total execution time: 1.5367
DEBUG - 2011-08-05 01:30:45 --> Config Class Initialized
DEBUG - 2011-08-05 01:30:45 --> Hooks Class Initialized
DEBUG - 2011-08-05 01:30:45 --> Utf8 Class Initialized
DEBUG - 2011-08-05 01:30:45 --> UTF-8 Support Enabled
DEBUG - 2011-08-05 01:30:45 --> URI Class Initialized
DEBUG - 2011-08-05 01:30:45 --> Router Class Initialized
DEBUG - 2011-08-05 01:30:45 --> No URI present. Default controller set.
DEBUG - 2011-08-05 01:30:45 --> Output Class Initialized
DEBUG - 2011-08-05 01:30:45 --> Input Class Initialized
DEBUG - 2011-08-05 01:30:45 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-05 01:30:45 --> Language Class Initialized
DEBUG - 2011-08-05 01:30:46 --> Loader Class Initialized
DEBUG - 2011-08-05 01:30:46 --> Controller Class Initialized
DEBUG - 2011-08-05 01:30:46 --> File loaded: application/views/splash/main.php
DEBUG - 2011-08-05 01:30:46 --> Helper loaded: url_helper
DEBUG - 2011-08-05 01:30:46 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-05 01:30:46 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-05 01:30:46 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-05 01:30:46 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-05 01:30:46 --> Final output sent to browser
DEBUG - 2011-08-05 01:30:46 --> Total execution time: 0.2067
DEBUG - 2011-08-05 03:38:15 --> Config Class Initialized
DEBUG - 2011-08-05 03:38:15 --> Hooks Class Initialized
DEBUG - 2011-08-05 03:38:15 --> Utf8 Class Initialized
DEBUG - 2011-08-05 03:38:15 --> UTF-8 Support Enabled
DEBUG - 2011-08-05 03:38:15 --> URI Class Initialized
DEBUG - 2011-08-05 03:38:15 --> Router Class Initialized
DEBUG - 2011-08-05 03:38:15 --> Output Class Initialized
DEBUG - 2011-08-05 03:38:15 --> Input Class Initialized
DEBUG - 2011-08-05 03:38:15 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-05 03:38:15 --> Language Class Initialized
DEBUG - 2011-08-05 03:38:15 --> Loader Class Initialized
DEBUG - 2011-08-05 03:38:15 --> Controller Class Initialized
DEBUG - 2011-08-05 03:38:15 --> Model Class Initialized
DEBUG - 2011-08-05 03:38:15 --> Model Class Initialized
DEBUG - 2011-08-05 03:38:15 --> Model Class Initialized
DEBUG - 2011-08-05 03:38:15 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-05 03:38:15 --> Database Driver Class Initialized
DEBUG - 2011-08-05 03:38:19 --> File loaded: application/views/table/main.php
DEBUG - 2011-08-05 03:38:19 --> Helper loaded: url_helper
DEBUG - 2011-08-05 03:38:19 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-05 03:38:19 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-05 03:38:19 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-05 03:38:19 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-05 03:38:19 --> Final output sent to browser
DEBUG - 2011-08-05 03:38:19 --> Total execution time: 4.3799
DEBUG - 2011-08-05 03:38:22 --> Config Class Initialized
DEBUG - 2011-08-05 03:38:23 --> Hooks Class Initialized
DEBUG - 2011-08-05 03:38:23 --> Utf8 Class Initialized
DEBUG - 2011-08-05 03:38:23 --> UTF-8 Support Enabled
DEBUG - 2011-08-05 03:38:23 --> URI Class Initialized
DEBUG - 2011-08-05 03:38:23 --> Router Class Initialized
ERROR - 2011-08-05 03:38:23 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-08-05 03:38:32 --> Config Class Initialized
DEBUG - 2011-08-05 03:38:32 --> Hooks Class Initialized
DEBUG - 2011-08-05 03:38:32 --> Utf8 Class Initialized
DEBUG - 2011-08-05 03:38:32 --> UTF-8 Support Enabled
DEBUG - 2011-08-05 03:38:32 --> URI Class Initialized
DEBUG - 2011-08-05 03:38:32 --> Router Class Initialized
DEBUG - 2011-08-05 03:38:32 --> Output Class Initialized
DEBUG - 2011-08-05 03:38:32 --> Input Class Initialized
DEBUG - 2011-08-05 03:38:32 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-05 03:38:32 --> Language Class Initialized
DEBUG - 2011-08-05 03:38:32 --> Loader Class Initialized
DEBUG - 2011-08-05 03:38:32 --> Controller Class Initialized
ERROR - 2011-08-05 03:38:32 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-08-05 03:38:32 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-08-05 03:38:32 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-08-05 03:38:32 --> Model Class Initialized
DEBUG - 2011-08-05 03:38:32 --> Model Class Initialized
DEBUG - 2011-08-05 03:38:32 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-05 03:38:32 --> Database Driver Class Initialized
DEBUG - 2011-08-05 03:38:32 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-08-05 03:38:32 --> Helper loaded: url_helper
DEBUG - 2011-08-05 03:38:32 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-05 03:38:32 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-05 03:38:32 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-05 03:38:32 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-05 03:38:32 --> Final output sent to browser
DEBUG - 2011-08-05 03:38:32 --> Total execution time: 0.1353
DEBUG - 2011-08-05 03:38:33 --> Config Class Initialized
DEBUG - 2011-08-05 03:38:33 --> Hooks Class Initialized
DEBUG - 2011-08-05 03:38:33 --> Utf8 Class Initialized
DEBUG - 2011-08-05 03:38:33 --> UTF-8 Support Enabled
DEBUG - 2011-08-05 03:38:33 --> URI Class Initialized
DEBUG - 2011-08-05 03:38:33 --> Router Class Initialized
DEBUG - 2011-08-05 03:38:33 --> Output Class Initialized
DEBUG - 2011-08-05 03:38:33 --> Input Class Initialized
DEBUG - 2011-08-05 03:38:33 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-05 03:38:33 --> Language Class Initialized
DEBUG - 2011-08-05 03:38:33 --> Loader Class Initialized
DEBUG - 2011-08-05 03:38:33 --> Controller Class Initialized
DEBUG - 2011-08-05 03:38:33 --> Model Class Initialized
DEBUG - 2011-08-05 03:38:33 --> Model Class Initialized
DEBUG - 2011-08-05 03:38:33 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-05 03:38:33 --> Database Driver Class Initialized
DEBUG - 2011-08-05 03:38:34 --> Final output sent to browser
DEBUG - 2011-08-05 03:38:34 --> Total execution time: 0.8515
DEBUG - 2011-08-05 06:09:07 --> Config Class Initialized
DEBUG - 2011-08-05 06:09:07 --> Hooks Class Initialized
DEBUG - 2011-08-05 06:09:07 --> Utf8 Class Initialized
DEBUG - 2011-08-05 06:09:07 --> UTF-8 Support Enabled
DEBUG - 2011-08-05 06:09:07 --> URI Class Initialized
DEBUG - 2011-08-05 06:09:07 --> Router Class Initialized
DEBUG - 2011-08-05 06:09:07 --> Output Class Initialized
DEBUG - 2011-08-05 06:09:07 --> Input Class Initialized
DEBUG - 2011-08-05 06:09:07 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-05 06:09:07 --> Language Class Initialized
DEBUG - 2011-08-05 06:09:07 --> Loader Class Initialized
DEBUG - 2011-08-05 06:09:07 --> Controller Class Initialized
DEBUG - 2011-08-05 06:09:07 --> Model Class Initialized
DEBUG - 2011-08-05 06:09:07 --> Model Class Initialized
DEBUG - 2011-08-05 06:09:07 --> Model Class Initialized
DEBUG - 2011-08-05 06:09:07 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-05 06:09:07 --> Database Driver Class Initialized
DEBUG - 2011-08-05 06:09:08 --> File loaded: application/views/table/main.php
DEBUG - 2011-08-05 06:09:08 --> Helper loaded: url_helper
DEBUG - 2011-08-05 06:09:08 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-05 06:09:08 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-05 06:09:08 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-05 06:09:08 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-05 06:09:08 --> Final output sent to browser
DEBUG - 2011-08-05 06:09:08 --> Total execution time: 1.5157
DEBUG - 2011-08-05 06:09:10 --> Config Class Initialized
DEBUG - 2011-08-05 06:09:10 --> Hooks Class Initialized
DEBUG - 2011-08-05 06:09:10 --> Utf8 Class Initialized
DEBUG - 2011-08-05 06:09:10 --> UTF-8 Support Enabled
DEBUG - 2011-08-05 06:09:10 --> URI Class Initialized
DEBUG - 2011-08-05 06:09:10 --> Router Class Initialized
ERROR - 2011-08-05 06:09:10 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-08-05 06:09:42 --> Config Class Initialized
DEBUG - 2011-08-05 06:09:42 --> Hooks Class Initialized
DEBUG - 2011-08-05 06:09:42 --> Utf8 Class Initialized
DEBUG - 2011-08-05 06:09:42 --> UTF-8 Support Enabled
DEBUG - 2011-08-05 06:09:42 --> URI Class Initialized
DEBUG - 2011-08-05 06:09:42 --> Router Class Initialized
DEBUG - 2011-08-05 06:09:42 --> Output Class Initialized
DEBUG - 2011-08-05 06:09:42 --> Input Class Initialized
DEBUG - 2011-08-05 06:09:42 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-05 06:09:42 --> Language Class Initialized
DEBUG - 2011-08-05 06:09:42 --> Loader Class Initialized
DEBUG - 2011-08-05 06:09:42 --> Controller Class Initialized
DEBUG - 2011-08-05 06:09:42 --> Model Class Initialized
DEBUG - 2011-08-05 06:09:42 --> Model Class Initialized
DEBUG - 2011-08-05 06:09:42 --> Model Class Initialized
DEBUG - 2011-08-05 06:09:42 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-05 06:09:42 --> Database Driver Class Initialized
DEBUG - 2011-08-05 06:09:42 --> File loaded: application/views/table/main.php
DEBUG - 2011-08-05 06:09:42 --> Helper loaded: url_helper
DEBUG - 2011-08-05 06:09:42 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-05 06:09:42 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-05 06:09:42 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-05 06:09:42 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-05 06:09:42 --> Final output sent to browser
DEBUG - 2011-08-05 06:09:42 --> Total execution time: 0.5145
DEBUG - 2011-08-05 06:09:44 --> Config Class Initialized
DEBUG - 2011-08-05 06:09:44 --> Hooks Class Initialized
DEBUG - 2011-08-05 06:09:44 --> Utf8 Class Initialized
DEBUG - 2011-08-05 06:09:44 --> UTF-8 Support Enabled
DEBUG - 2011-08-05 06:09:44 --> URI Class Initialized
DEBUG - 2011-08-05 06:09:44 --> Router Class Initialized
ERROR - 2011-08-05 06:09:44 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-08-05 06:09:44 --> Config Class Initialized
DEBUG - 2011-08-05 06:09:44 --> Hooks Class Initialized
DEBUG - 2011-08-05 06:09:44 --> Utf8 Class Initialized
DEBUG - 2011-08-05 06:09:44 --> UTF-8 Support Enabled
DEBUG - 2011-08-05 06:09:44 --> URI Class Initialized
DEBUG - 2011-08-05 06:09:44 --> Router Class Initialized
DEBUG - 2011-08-05 06:09:44 --> Output Class Initialized
DEBUG - 2011-08-05 06:09:44 --> Input Class Initialized
DEBUG - 2011-08-05 06:09:44 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-05 06:09:44 --> Language Class Initialized
DEBUG - 2011-08-05 06:09:44 --> Loader Class Initialized
DEBUG - 2011-08-05 06:09:44 --> Controller Class Initialized
DEBUG - 2011-08-05 06:09:44 --> Model Class Initialized
DEBUG - 2011-08-05 06:09:44 --> Model Class Initialized
DEBUG - 2011-08-05 06:09:44 --> Model Class Initialized
DEBUG - 2011-08-05 06:09:44 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-05 06:09:44 --> Database Driver Class Initialized
DEBUG - 2011-08-05 06:09:44 --> File loaded: application/views/table/main.php
DEBUG - 2011-08-05 06:09:44 --> Helper loaded: url_helper
DEBUG - 2011-08-05 06:09:44 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-05 06:09:44 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-05 06:09:44 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-05 06:09:44 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-05 06:09:44 --> Final output sent to browser
DEBUG - 2011-08-05 06:09:44 --> Total execution time: 0.0576
DEBUG - 2011-08-05 06:09:50 --> Config Class Initialized
DEBUG - 2011-08-05 06:09:50 --> Hooks Class Initialized
DEBUG - 2011-08-05 06:09:50 --> Utf8 Class Initialized
DEBUG - 2011-08-05 06:09:50 --> UTF-8 Support Enabled
DEBUG - 2011-08-05 06:09:50 --> URI Class Initialized
DEBUG - 2011-08-05 06:09:50 --> Router Class Initialized
DEBUG - 2011-08-05 06:09:50 --> Output Class Initialized
DEBUG - 2011-08-05 06:09:50 --> Input Class Initialized
DEBUG - 2011-08-05 06:09:50 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-05 06:09:50 --> Language Class Initialized
DEBUG - 2011-08-05 06:09:50 --> Loader Class Initialized
DEBUG - 2011-08-05 06:09:50 --> Controller Class Initialized
DEBUG - 2011-08-05 06:09:50 --> Model Class Initialized
DEBUG - 2011-08-05 06:09:50 --> Model Class Initialized
DEBUG - 2011-08-05 06:09:50 --> Model Class Initialized
DEBUG - 2011-08-05 06:09:50 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-05 06:09:50 --> Database Driver Class Initialized
DEBUG - 2011-08-05 06:09:50 --> File loaded: application/views/table/main.php
DEBUG - 2011-08-05 06:09:50 --> Helper loaded: url_helper
DEBUG - 2011-08-05 06:09:50 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-05 06:09:50 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-05 06:09:50 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-05 06:09:50 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-05 06:09:50 --> Final output sent to browser
DEBUG - 2011-08-05 06:09:50 --> Total execution time: 0.0806
DEBUG - 2011-08-05 06:09:52 --> Config Class Initialized
DEBUG - 2011-08-05 06:09:52 --> Hooks Class Initialized
DEBUG - 2011-08-05 06:09:52 --> Utf8 Class Initialized
DEBUG - 2011-08-05 06:09:52 --> UTF-8 Support Enabled
DEBUG - 2011-08-05 06:09:52 --> URI Class Initialized
DEBUG - 2011-08-05 06:09:52 --> Router Class Initialized
ERROR - 2011-08-05 06:09:52 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-08-05 06:09:58 --> Config Class Initialized
DEBUG - 2011-08-05 06:09:58 --> Hooks Class Initialized
DEBUG - 2011-08-05 06:09:58 --> Utf8 Class Initialized
DEBUG - 2011-08-05 06:09:58 --> UTF-8 Support Enabled
DEBUG - 2011-08-05 06:09:58 --> URI Class Initialized
DEBUG - 2011-08-05 06:09:58 --> Router Class Initialized
DEBUG - 2011-08-05 06:09:58 --> Output Class Initialized
DEBUG - 2011-08-05 06:09:58 --> Input Class Initialized
DEBUG - 2011-08-05 06:09:58 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-05 06:09:58 --> Language Class Initialized
DEBUG - 2011-08-05 06:09:58 --> Loader Class Initialized
DEBUG - 2011-08-05 06:09:58 --> Controller Class Initialized
DEBUG - 2011-08-05 06:09:58 --> Model Class Initialized
DEBUG - 2011-08-05 06:09:58 --> Model Class Initialized
DEBUG - 2011-08-05 06:09:58 --> Model Class Initialized
DEBUG - 2011-08-05 06:09:58 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-05 06:09:58 --> Database Driver Class Initialized
DEBUG - 2011-08-05 06:10:00 --> File loaded: application/views/table/main.php
DEBUG - 2011-08-05 06:10:00 --> Helper loaded: url_helper
DEBUG - 2011-08-05 06:10:00 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-05 06:10:00 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-05 06:10:00 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-05 06:10:00 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-05 06:10:00 --> Final output sent to browser
DEBUG - 2011-08-05 06:10:00 --> Total execution time: 1.9154
DEBUG - 2011-08-05 06:10:01 --> Config Class Initialized
DEBUG - 2011-08-05 06:10:01 --> Hooks Class Initialized
DEBUG - 2011-08-05 06:10:01 --> Utf8 Class Initialized
DEBUG - 2011-08-05 06:10:01 --> UTF-8 Support Enabled
DEBUG - 2011-08-05 06:10:01 --> URI Class Initialized
DEBUG - 2011-08-05 06:10:01 --> Router Class Initialized
ERROR - 2011-08-05 06:10:01 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-08-05 06:10:03 --> Config Class Initialized
DEBUG - 2011-08-05 06:10:03 --> Hooks Class Initialized
DEBUG - 2011-08-05 06:10:03 --> Utf8 Class Initialized
DEBUG - 2011-08-05 06:10:03 --> UTF-8 Support Enabled
DEBUG - 2011-08-05 06:10:03 --> URI Class Initialized
DEBUG - 2011-08-05 06:10:03 --> Router Class Initialized
DEBUG - 2011-08-05 06:10:03 --> Output Class Initialized
DEBUG - 2011-08-05 06:10:03 --> Input Class Initialized
DEBUG - 2011-08-05 06:10:03 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-05 06:10:03 --> Language Class Initialized
DEBUG - 2011-08-05 06:10:03 --> Loader Class Initialized
DEBUG - 2011-08-05 06:10:03 --> Controller Class Initialized
DEBUG - 2011-08-05 06:10:03 --> Model Class Initialized
DEBUG - 2011-08-05 06:10:03 --> Model Class Initialized
DEBUG - 2011-08-05 06:10:03 --> Model Class Initialized
DEBUG - 2011-08-05 06:10:03 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-05 06:10:03 --> Database Driver Class Initialized
DEBUG - 2011-08-05 06:10:03 --> File loaded: application/views/table/main.php
DEBUG - 2011-08-05 06:10:03 --> Helper loaded: url_helper
DEBUG - 2011-08-05 06:10:03 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-05 06:10:03 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-05 06:10:03 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-05 06:10:03 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-05 06:10:03 --> Final output sent to browser
DEBUG - 2011-08-05 06:10:03 --> Total execution time: 0.5224
DEBUG - 2011-08-05 06:47:35 --> Config Class Initialized
DEBUG - 2011-08-05 06:47:35 --> Hooks Class Initialized
DEBUG - 2011-08-05 06:47:35 --> Utf8 Class Initialized
DEBUG - 2011-08-05 06:47:35 --> UTF-8 Support Enabled
DEBUG - 2011-08-05 06:47:35 --> URI Class Initialized
DEBUG - 2011-08-05 06:47:35 --> Router Class Initialized
DEBUG - 2011-08-05 06:47:35 --> Output Class Initialized
DEBUG - 2011-08-05 06:47:35 --> Input Class Initialized
DEBUG - 2011-08-05 06:47:35 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-05 06:47:35 --> Language Class Initialized
DEBUG - 2011-08-05 06:47:35 --> Loader Class Initialized
DEBUG - 2011-08-05 06:47:35 --> Controller Class Initialized
ERROR - 2011-08-05 06:47:35 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-08-05 06:47:35 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-08-05 06:47:35 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-08-05 06:47:35 --> Model Class Initialized
DEBUG - 2011-08-05 06:47:35 --> Model Class Initialized
DEBUG - 2011-08-05 06:47:35 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-05 06:47:35 --> Database Driver Class Initialized
DEBUG - 2011-08-05 06:47:35 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-08-05 06:47:35 --> Helper loaded: url_helper
DEBUG - 2011-08-05 06:47:35 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-05 06:47:35 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-05 06:47:35 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-05 06:47:35 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-05 06:47:35 --> Final output sent to browser
DEBUG - 2011-08-05 06:47:35 --> Total execution time: 0.5156
DEBUG - 2011-08-05 08:05:00 --> Config Class Initialized
DEBUG - 2011-08-05 08:05:00 --> Hooks Class Initialized
DEBUG - 2011-08-05 08:05:00 --> Utf8 Class Initialized
DEBUG - 2011-08-05 08:05:00 --> UTF-8 Support Enabled
DEBUG - 2011-08-05 08:05:00 --> URI Class Initialized
DEBUG - 2011-08-05 08:05:00 --> Router Class Initialized
ERROR - 2011-08-05 08:05:00 --> 404 Page Not Found --> robots.txt
DEBUG - 2011-08-05 08:05:00 --> Config Class Initialized
DEBUG - 2011-08-05 08:05:00 --> Hooks Class Initialized
DEBUG - 2011-08-05 08:05:00 --> Utf8 Class Initialized
DEBUG - 2011-08-05 08:05:00 --> UTF-8 Support Enabled
DEBUG - 2011-08-05 08:05:00 --> URI Class Initialized
DEBUG - 2011-08-05 08:05:00 --> Router Class Initialized
DEBUG - 2011-08-05 08:05:00 --> No URI present. Default controller set.
DEBUG - 2011-08-05 08:05:00 --> Output Class Initialized
DEBUG - 2011-08-05 08:05:00 --> Input Class Initialized
DEBUG - 2011-08-05 08:05:00 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-05 08:05:00 --> Language Class Initialized
DEBUG - 2011-08-05 08:05:00 --> Loader Class Initialized
DEBUG - 2011-08-05 08:05:00 --> Controller Class Initialized
DEBUG - 2011-08-05 08:05:00 --> File loaded: application/views/splash/main.php
DEBUG - 2011-08-05 08:05:01 --> Helper loaded: url_helper
DEBUG - 2011-08-05 08:05:01 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-05 08:05:01 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-05 08:05:01 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-05 08:05:01 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-05 08:05:01 --> Final output sent to browser
DEBUG - 2011-08-05 08:05:01 --> Total execution time: 0.1870
DEBUG - 2011-08-05 08:06:31 --> Config Class Initialized
DEBUG - 2011-08-05 08:06:31 --> Hooks Class Initialized
DEBUG - 2011-08-05 08:06:31 --> Utf8 Class Initialized
DEBUG - 2011-08-05 08:06:31 --> UTF-8 Support Enabled
DEBUG - 2011-08-05 08:06:31 --> URI Class Initialized
DEBUG - 2011-08-05 08:06:31 --> Router Class Initialized
DEBUG - 2011-08-05 08:06:31 --> Output Class Initialized
DEBUG - 2011-08-05 08:06:31 --> Input Class Initialized
DEBUG - 2011-08-05 08:06:31 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-05 08:06:31 --> Language Class Initialized
DEBUG - 2011-08-05 08:06:31 --> Loader Class Initialized
DEBUG - 2011-08-05 08:06:31 --> Controller Class Initialized
ERROR - 2011-08-05 08:06:31 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-08-05 08:06:31 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-08-05 08:06:31 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-08-05 08:06:31 --> Model Class Initialized
DEBUG - 2011-08-05 08:06:31 --> Model Class Initialized
DEBUG - 2011-08-05 08:06:31 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-05 08:06:31 --> Database Driver Class Initialized
DEBUG - 2011-08-05 08:06:31 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-08-05 08:06:31 --> Helper loaded: url_helper
DEBUG - 2011-08-05 08:06:31 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-05 08:06:31 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-05 08:06:31 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-05 08:06:31 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-05 08:06:31 --> Final output sent to browser
DEBUG - 2011-08-05 08:06:31 --> Total execution time: 0.2440
DEBUG - 2011-08-05 08:06:33 --> Config Class Initialized
DEBUG - 2011-08-05 08:06:33 --> Hooks Class Initialized
DEBUG - 2011-08-05 08:06:33 --> Utf8 Class Initialized
DEBUG - 2011-08-05 08:06:33 --> UTF-8 Support Enabled
DEBUG - 2011-08-05 08:06:33 --> URI Class Initialized
DEBUG - 2011-08-05 08:06:33 --> Router Class Initialized
DEBUG - 2011-08-05 08:06:33 --> Output Class Initialized
DEBUG - 2011-08-05 08:06:33 --> Input Class Initialized
DEBUG - 2011-08-05 08:06:33 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-05 08:06:33 --> Language Class Initialized
DEBUG - 2011-08-05 08:06:33 --> Loader Class Initialized
DEBUG - 2011-08-05 08:06:33 --> Controller Class Initialized
DEBUG - 2011-08-05 08:06:33 --> Model Class Initialized
DEBUG - 2011-08-05 08:06:33 --> Model Class Initialized
DEBUG - 2011-08-05 08:06:33 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-05 08:06:33 --> Database Driver Class Initialized
DEBUG - 2011-08-05 08:06:34 --> Final output sent to browser
DEBUG - 2011-08-05 08:06:34 --> Total execution time: 1.0251
DEBUG - 2011-08-05 08:06:35 --> Config Class Initialized
DEBUG - 2011-08-05 08:06:35 --> Hooks Class Initialized
DEBUG - 2011-08-05 08:06:35 --> Utf8 Class Initialized
DEBUG - 2011-08-05 08:06:35 --> UTF-8 Support Enabled
DEBUG - 2011-08-05 08:06:35 --> URI Class Initialized
DEBUG - 2011-08-05 08:06:35 --> Router Class Initialized
ERROR - 2011-08-05 08:06:35 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-08-05 08:06:38 --> Config Class Initialized
DEBUG - 2011-08-05 08:06:38 --> Hooks Class Initialized
DEBUG - 2011-08-05 08:06:38 --> Utf8 Class Initialized
DEBUG - 2011-08-05 08:06:38 --> UTF-8 Support Enabled
DEBUG - 2011-08-05 08:06:38 --> URI Class Initialized
DEBUG - 2011-08-05 08:06:38 --> Router Class Initialized
DEBUG - 2011-08-05 08:06:38 --> Output Class Initialized
DEBUG - 2011-08-05 08:06:38 --> Input Class Initialized
DEBUG - 2011-08-05 08:06:38 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-05 08:06:38 --> Language Class Initialized
DEBUG - 2011-08-05 08:06:38 --> Loader Class Initialized
DEBUG - 2011-08-05 08:06:38 --> Controller Class Initialized
DEBUG - 2011-08-05 08:06:38 --> Model Class Initialized
DEBUG - 2011-08-05 08:06:38 --> Model Class Initialized
DEBUG - 2011-08-05 08:06:38 --> Model Class Initialized
DEBUG - 2011-08-05 08:06:38 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-05 08:06:38 --> Database Driver Class Initialized
DEBUG - 2011-08-05 08:06:38 --> Config Class Initialized
DEBUG - 2011-08-05 08:06:38 --> Hooks Class Initialized
DEBUG - 2011-08-05 08:06:38 --> Utf8 Class Initialized
DEBUG - 2011-08-05 08:06:38 --> UTF-8 Support Enabled
DEBUG - 2011-08-05 08:06:38 --> URI Class Initialized
DEBUG - 2011-08-05 08:06:38 --> Router Class Initialized
DEBUG - 2011-08-05 08:06:38 --> Output Class Initialized
DEBUG - 2011-08-05 08:06:38 --> Input Class Initialized
DEBUG - 2011-08-05 08:06:38 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-05 08:06:38 --> Language Class Initialized
DEBUG - 2011-08-05 08:06:38 --> Loader Class Initialized
DEBUG - 2011-08-05 08:06:38 --> Controller Class Initialized
DEBUG - 2011-08-05 08:06:38 --> Model Class Initialized
DEBUG - 2011-08-05 08:06:38 --> Model Class Initialized
DEBUG - 2011-08-05 08:06:38 --> Model Class Initialized
DEBUG - 2011-08-05 08:06:38 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-05 08:06:38 --> Database Driver Class Initialized
DEBUG - 2011-08-05 08:06:38 --> File loaded: application/views/table/main.php
DEBUG - 2011-08-05 08:06:38 --> Helper loaded: url_helper
DEBUG - 2011-08-05 08:06:38 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-05 08:06:38 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-05 08:06:38 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-05 08:06:38 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-05 08:06:38 --> Final output sent to browser
DEBUG - 2011-08-05 08:06:38 --> Total execution time: 0.1359
DEBUG - 2011-08-05 08:06:38 --> File loaded: application/views/table/main.php
DEBUG - 2011-08-05 08:06:38 --> Helper loaded: url_helper
DEBUG - 2011-08-05 08:06:38 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-05 08:06:38 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-05 08:06:38 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-05 08:06:38 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-05 08:06:38 --> Final output sent to browser
DEBUG - 2011-08-05 08:06:38 --> Total execution time: 0.4790
DEBUG - 2011-08-05 08:06:38 --> Config Class Initialized
DEBUG - 2011-08-05 08:06:38 --> Hooks Class Initialized
DEBUG - 2011-08-05 08:06:38 --> Utf8 Class Initialized
DEBUG - 2011-08-05 08:06:38 --> UTF-8 Support Enabled
DEBUG - 2011-08-05 08:06:38 --> URI Class Initialized
DEBUG - 2011-08-05 08:06:38 --> Router Class Initialized
DEBUG - 2011-08-05 08:06:38 --> Output Class Initialized
DEBUG - 2011-08-05 08:06:38 --> Input Class Initialized
DEBUG - 2011-08-05 08:06:38 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-05 08:06:38 --> Language Class Initialized
DEBUG - 2011-08-05 08:06:38 --> Loader Class Initialized
DEBUG - 2011-08-05 08:06:38 --> Controller Class Initialized
DEBUG - 2011-08-05 08:06:38 --> Model Class Initialized
DEBUG - 2011-08-05 08:06:38 --> Model Class Initialized
DEBUG - 2011-08-05 08:06:38 --> Model Class Initialized
DEBUG - 2011-08-05 08:06:38 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-05 08:06:38 --> Database Driver Class Initialized
DEBUG - 2011-08-05 08:06:38 --> File loaded: application/views/table/main.php
DEBUG - 2011-08-05 08:06:38 --> Helper loaded: url_helper
DEBUG - 2011-08-05 08:06:38 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-05 08:06:38 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-05 08:06:38 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-05 08:06:38 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-05 08:06:38 --> Final output sent to browser
DEBUG - 2011-08-05 08:06:38 --> Total execution time: 0.0591
DEBUG - 2011-08-05 08:06:41 --> Config Class Initialized
DEBUG - 2011-08-05 08:06:41 --> Hooks Class Initialized
DEBUG - 2011-08-05 08:06:41 --> Utf8 Class Initialized
DEBUG - 2011-08-05 08:06:41 --> UTF-8 Support Enabled
DEBUG - 2011-08-05 08:06:41 --> URI Class Initialized
DEBUG - 2011-08-05 08:06:41 --> Router Class Initialized
ERROR - 2011-08-05 08:06:41 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-08-05 08:06:52 --> Config Class Initialized
DEBUG - 2011-08-05 08:06:52 --> Hooks Class Initialized
DEBUG - 2011-08-05 08:06:52 --> Utf8 Class Initialized
DEBUG - 2011-08-05 08:06:52 --> UTF-8 Support Enabled
DEBUG - 2011-08-05 08:06:52 --> URI Class Initialized
DEBUG - 2011-08-05 08:06:52 --> Router Class Initialized
DEBUG - 2011-08-05 08:06:52 --> Output Class Initialized
DEBUG - 2011-08-05 08:06:52 --> Input Class Initialized
DEBUG - 2011-08-05 08:06:52 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-05 08:06:52 --> Language Class Initialized
DEBUG - 2011-08-05 08:06:52 --> Loader Class Initialized
DEBUG - 2011-08-05 08:06:52 --> Controller Class Initialized
DEBUG - 2011-08-05 08:06:52 --> Model Class Initialized
DEBUG - 2011-08-05 08:06:52 --> Model Class Initialized
DEBUG - 2011-08-05 08:06:52 --> Model Class Initialized
DEBUG - 2011-08-05 08:06:52 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-05 08:06:52 --> Database Driver Class Initialized
DEBUG - 2011-08-05 08:06:52 --> File loaded: application/views/table/main.php
DEBUG - 2011-08-05 08:06:52 --> Helper loaded: url_helper
DEBUG - 2011-08-05 08:06:52 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-05 08:06:52 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-05 08:06:52 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-05 08:06:52 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-05 08:06:52 --> Final output sent to browser
DEBUG - 2011-08-05 08:06:52 --> Total execution time: 0.3853
DEBUG - 2011-08-05 08:06:55 --> Config Class Initialized
DEBUG - 2011-08-05 08:06:55 --> Hooks Class Initialized
DEBUG - 2011-08-05 08:06:55 --> Utf8 Class Initialized
DEBUG - 2011-08-05 08:06:55 --> UTF-8 Support Enabled
DEBUG - 2011-08-05 08:06:55 --> URI Class Initialized
DEBUG - 2011-08-05 08:06:55 --> Router Class Initialized
ERROR - 2011-08-05 08:06:55 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-08-05 08:07:09 --> Config Class Initialized
DEBUG - 2011-08-05 08:07:09 --> Hooks Class Initialized
DEBUG - 2011-08-05 08:07:09 --> Utf8 Class Initialized
DEBUG - 2011-08-05 08:07:09 --> UTF-8 Support Enabled
DEBUG - 2011-08-05 08:07:09 --> URI Class Initialized
DEBUG - 2011-08-05 08:07:09 --> Router Class Initialized
DEBUG - 2011-08-05 08:07:09 --> Output Class Initialized
DEBUG - 2011-08-05 08:07:09 --> Input Class Initialized
DEBUG - 2011-08-05 08:07:09 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-05 08:07:09 --> Language Class Initialized
DEBUG - 2011-08-05 08:07:09 --> Loader Class Initialized
DEBUG - 2011-08-05 08:07:09 --> Controller Class Initialized
DEBUG - 2011-08-05 08:07:09 --> Model Class Initialized
DEBUG - 2011-08-05 08:07:09 --> Model Class Initialized
DEBUG - 2011-08-05 08:07:09 --> Model Class Initialized
DEBUG - 2011-08-05 08:07:09 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-05 08:07:09 --> Database Driver Class Initialized
DEBUG - 2011-08-05 08:07:10 --> File loaded: application/views/table/main.php
DEBUG - 2011-08-05 08:07:10 --> Helper loaded: url_helper
DEBUG - 2011-08-05 08:07:10 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-05 08:07:10 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-05 08:07:10 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-05 08:07:10 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-05 08:07:10 --> Final output sent to browser
DEBUG - 2011-08-05 08:07:10 --> Total execution time: 1.2334
DEBUG - 2011-08-05 08:07:12 --> Config Class Initialized
DEBUG - 2011-08-05 08:07:12 --> Hooks Class Initialized
DEBUG - 2011-08-05 08:07:12 --> Utf8 Class Initialized
DEBUG - 2011-08-05 08:07:12 --> UTF-8 Support Enabled
DEBUG - 2011-08-05 08:07:12 --> URI Class Initialized
DEBUG - 2011-08-05 08:07:12 --> Router Class Initialized
ERROR - 2011-08-05 08:07:12 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-08-05 08:07:19 --> Config Class Initialized
DEBUG - 2011-08-05 08:07:19 --> Hooks Class Initialized
DEBUG - 2011-08-05 08:07:19 --> Utf8 Class Initialized
DEBUG - 2011-08-05 08:07:19 --> UTF-8 Support Enabled
DEBUG - 2011-08-05 08:07:19 --> URI Class Initialized
DEBUG - 2011-08-05 08:07:19 --> Router Class Initialized
DEBUG - 2011-08-05 08:07:19 --> Output Class Initialized
DEBUG - 2011-08-05 08:07:19 --> Input Class Initialized
DEBUG - 2011-08-05 08:07:19 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-05 08:07:19 --> Language Class Initialized
DEBUG - 2011-08-05 08:07:19 --> Loader Class Initialized
DEBUG - 2011-08-05 08:07:19 --> Controller Class Initialized
DEBUG - 2011-08-05 08:07:19 --> Model Class Initialized
DEBUG - 2011-08-05 08:07:19 --> Model Class Initialized
DEBUG - 2011-08-05 08:07:19 --> Model Class Initialized
DEBUG - 2011-08-05 08:07:19 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-05 08:07:19 --> Database Driver Class Initialized
DEBUG - 2011-08-05 08:07:19 --> File loaded: application/views/table/main.php
DEBUG - 2011-08-05 08:07:19 --> Helper loaded: url_helper
DEBUG - 2011-08-05 08:07:19 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-05 08:07:19 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-05 08:07:19 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-05 08:07:19 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-05 08:07:19 --> Final output sent to browser
DEBUG - 2011-08-05 08:07:19 --> Total execution time: 0.0647
DEBUG - 2011-08-05 08:07:21 --> Config Class Initialized
DEBUG - 2011-08-05 08:07:21 --> Hooks Class Initialized
DEBUG - 2011-08-05 08:07:21 --> Utf8 Class Initialized
DEBUG - 2011-08-05 08:07:21 --> UTF-8 Support Enabled
DEBUG - 2011-08-05 08:07:21 --> URI Class Initialized
DEBUG - 2011-08-05 08:07:21 --> Router Class Initialized
DEBUG - 2011-08-05 08:07:21 --> Output Class Initialized
DEBUG - 2011-08-05 08:07:21 --> Input Class Initialized
DEBUG - 2011-08-05 08:07:21 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-05 08:07:21 --> Language Class Initialized
DEBUG - 2011-08-05 08:07:21 --> Loader Class Initialized
DEBUG - 2011-08-05 08:07:21 --> Controller Class Initialized
DEBUG - 2011-08-05 08:07:21 --> Model Class Initialized
DEBUG - 2011-08-05 08:07:21 --> Model Class Initialized
DEBUG - 2011-08-05 08:07:21 --> Model Class Initialized
DEBUG - 2011-08-05 08:07:21 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-05 08:07:21 --> Database Driver Class Initialized
DEBUG - 2011-08-05 08:07:21 --> File loaded: application/views/table/main.php
DEBUG - 2011-08-05 08:07:21 --> Helper loaded: url_helper
DEBUG - 2011-08-05 08:07:21 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-05 08:07:21 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-05 08:07:21 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-05 08:07:21 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-05 08:07:21 --> Final output sent to browser
DEBUG - 2011-08-05 08:07:21 --> Total execution time: 0.0803
DEBUG - 2011-08-05 08:07:36 --> Config Class Initialized
DEBUG - 2011-08-05 08:07:36 --> Hooks Class Initialized
DEBUG - 2011-08-05 08:07:36 --> Utf8 Class Initialized
DEBUG - 2011-08-05 08:07:36 --> UTF-8 Support Enabled
DEBUG - 2011-08-05 08:07:36 --> URI Class Initialized
DEBUG - 2011-08-05 08:07:36 --> Router Class Initialized
DEBUG - 2011-08-05 08:07:36 --> Output Class Initialized
DEBUG - 2011-08-05 08:07:36 --> Input Class Initialized
DEBUG - 2011-08-05 08:07:36 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-05 08:07:36 --> Language Class Initialized
DEBUG - 2011-08-05 08:07:36 --> Loader Class Initialized
DEBUG - 2011-08-05 08:07:36 --> Controller Class Initialized
DEBUG - 2011-08-05 08:07:36 --> Model Class Initialized
DEBUG - 2011-08-05 08:07:36 --> Model Class Initialized
DEBUG - 2011-08-05 08:07:36 --> Model Class Initialized
DEBUG - 2011-08-05 08:07:36 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-05 08:07:36 --> Database Driver Class Initialized
DEBUG - 2011-08-05 08:07:37 --> File loaded: application/views/table/main.php
DEBUG - 2011-08-05 08:07:37 --> Helper loaded: url_helper
DEBUG - 2011-08-05 08:07:37 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-05 08:07:37 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-05 08:07:37 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-05 08:07:37 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-05 08:07:37 --> Final output sent to browser
DEBUG - 2011-08-05 08:07:37 --> Total execution time: 0.5002
DEBUG - 2011-08-05 08:07:39 --> Config Class Initialized
DEBUG - 2011-08-05 08:07:39 --> Hooks Class Initialized
DEBUG - 2011-08-05 08:07:39 --> Utf8 Class Initialized
DEBUG - 2011-08-05 08:07:39 --> UTF-8 Support Enabled
DEBUG - 2011-08-05 08:07:39 --> URI Class Initialized
DEBUG - 2011-08-05 08:07:39 --> Router Class Initialized
ERROR - 2011-08-05 08:07:39 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-08-05 08:07:42 --> Config Class Initialized
DEBUG - 2011-08-05 08:07:42 --> Hooks Class Initialized
DEBUG - 2011-08-05 08:07:42 --> Utf8 Class Initialized
DEBUG - 2011-08-05 08:07:42 --> UTF-8 Support Enabled
DEBUG - 2011-08-05 08:07:42 --> URI Class Initialized
DEBUG - 2011-08-05 08:07:42 --> Router Class Initialized
DEBUG - 2011-08-05 08:07:42 --> Output Class Initialized
DEBUG - 2011-08-05 08:07:42 --> Input Class Initialized
DEBUG - 2011-08-05 08:07:42 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-05 08:07:42 --> Language Class Initialized
DEBUG - 2011-08-05 08:07:42 --> Loader Class Initialized
DEBUG - 2011-08-05 08:07:42 --> Controller Class Initialized
DEBUG - 2011-08-05 08:07:42 --> Model Class Initialized
DEBUG - 2011-08-05 08:07:42 --> Model Class Initialized
DEBUG - 2011-08-05 08:07:42 --> Model Class Initialized
DEBUG - 2011-08-05 08:07:42 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-05 08:07:42 --> Database Driver Class Initialized
DEBUG - 2011-08-05 08:07:42 --> File loaded: application/views/table/main.php
DEBUG - 2011-08-05 08:07:42 --> Helper loaded: url_helper
DEBUG - 2011-08-05 08:07:42 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-05 08:07:42 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-05 08:07:42 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-05 08:07:42 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-05 08:07:42 --> Final output sent to browser
DEBUG - 2011-08-05 08:07:42 --> Total execution time: 0.0453
DEBUG - 2011-08-05 08:07:47 --> Config Class Initialized
DEBUG - 2011-08-05 08:07:47 --> Hooks Class Initialized
DEBUG - 2011-08-05 08:07:47 --> Utf8 Class Initialized
DEBUG - 2011-08-05 08:07:47 --> UTF-8 Support Enabled
DEBUG - 2011-08-05 08:07:47 --> URI Class Initialized
DEBUG - 2011-08-05 08:07:47 --> Router Class Initialized
DEBUG - 2011-08-05 08:07:47 --> Output Class Initialized
DEBUG - 2011-08-05 08:07:47 --> Input Class Initialized
DEBUG - 2011-08-05 08:07:47 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-05 08:07:47 --> Language Class Initialized
DEBUG - 2011-08-05 08:07:47 --> Loader Class Initialized
DEBUG - 2011-08-05 08:07:47 --> Controller Class Initialized
DEBUG - 2011-08-05 08:07:47 --> Model Class Initialized
DEBUG - 2011-08-05 08:07:47 --> Model Class Initialized
DEBUG - 2011-08-05 08:07:47 --> Model Class Initialized
DEBUG - 2011-08-05 08:07:47 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-05 08:07:47 --> Database Driver Class Initialized
DEBUG - 2011-08-05 08:07:47 --> File loaded: application/views/table/main.php
DEBUG - 2011-08-05 08:07:47 --> Helper loaded: url_helper
DEBUG - 2011-08-05 08:07:47 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-05 08:07:47 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-05 08:07:47 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-05 08:07:47 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-05 08:07:47 --> Final output sent to browser
DEBUG - 2011-08-05 08:07:47 --> Total execution time: 0.2545
DEBUG - 2011-08-05 08:07:49 --> Config Class Initialized
DEBUG - 2011-08-05 08:07:49 --> Hooks Class Initialized
DEBUG - 2011-08-05 08:07:49 --> Utf8 Class Initialized
DEBUG - 2011-08-05 08:07:49 --> UTF-8 Support Enabled
DEBUG - 2011-08-05 08:07:49 --> URI Class Initialized
DEBUG - 2011-08-05 08:07:49 --> Router Class Initialized
DEBUG - 2011-08-05 08:07:49 --> Output Class Initialized
DEBUG - 2011-08-05 08:07:49 --> Input Class Initialized
DEBUG - 2011-08-05 08:07:49 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-05 08:07:49 --> Language Class Initialized
DEBUG - 2011-08-05 08:07:49 --> Loader Class Initialized
DEBUG - 2011-08-05 08:07:49 --> Controller Class Initialized
DEBUG - 2011-08-05 08:07:49 --> Model Class Initialized
DEBUG - 2011-08-05 08:07:49 --> Model Class Initialized
DEBUG - 2011-08-05 08:07:49 --> Model Class Initialized
DEBUG - 2011-08-05 08:07:49 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-05 08:07:49 --> Database Driver Class Initialized
DEBUG - 2011-08-05 08:07:49 --> File loaded: application/views/table/main.php
DEBUG - 2011-08-05 08:07:49 --> Helper loaded: url_helper
DEBUG - 2011-08-05 08:07:49 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-05 08:07:49 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-05 08:07:49 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-05 08:07:49 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-05 08:07:49 --> Final output sent to browser
DEBUG - 2011-08-05 08:07:49 --> Total execution time: 0.0452
DEBUG - 2011-08-05 08:07:50 --> Config Class Initialized
DEBUG - 2011-08-05 08:07:50 --> Hooks Class Initialized
DEBUG - 2011-08-05 08:07:50 --> Utf8 Class Initialized
DEBUG - 2011-08-05 08:07:50 --> UTF-8 Support Enabled
DEBUG - 2011-08-05 08:07:50 --> URI Class Initialized
DEBUG - 2011-08-05 08:07:50 --> Router Class Initialized
ERROR - 2011-08-05 08:07:50 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-08-05 08:07:52 --> Config Class Initialized
DEBUG - 2011-08-05 08:07:52 --> Hooks Class Initialized
DEBUG - 2011-08-05 08:07:52 --> Utf8 Class Initialized
DEBUG - 2011-08-05 08:07:52 --> UTF-8 Support Enabled
DEBUG - 2011-08-05 08:07:52 --> URI Class Initialized
DEBUG - 2011-08-05 08:07:52 --> Router Class Initialized
DEBUG - 2011-08-05 08:07:52 --> Output Class Initialized
DEBUG - 2011-08-05 08:07:52 --> Input Class Initialized
DEBUG - 2011-08-05 08:07:52 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-05 08:07:52 --> Language Class Initialized
DEBUG - 2011-08-05 08:07:52 --> Loader Class Initialized
DEBUG - 2011-08-05 08:07:52 --> Controller Class Initialized
DEBUG - 2011-08-05 08:07:52 --> Model Class Initialized
DEBUG - 2011-08-05 08:07:52 --> Model Class Initialized
DEBUG - 2011-08-05 08:07:52 --> Model Class Initialized
DEBUG - 2011-08-05 08:07:52 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-05 08:07:52 --> Database Driver Class Initialized
DEBUG - 2011-08-05 08:07:52 --> File loaded: application/views/table/main.php
DEBUG - 2011-08-05 08:07:52 --> Helper loaded: url_helper
DEBUG - 2011-08-05 08:07:52 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-05 08:07:52 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-05 08:07:52 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-05 08:07:52 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-05 08:07:52 --> Final output sent to browser
DEBUG - 2011-08-05 08:07:52 --> Total execution time: 0.0752
DEBUG - 2011-08-05 08:08:06 --> Config Class Initialized
DEBUG - 2011-08-05 08:08:06 --> Hooks Class Initialized
DEBUG - 2011-08-05 08:08:06 --> Utf8 Class Initialized
DEBUG - 2011-08-05 08:08:06 --> UTF-8 Support Enabled
DEBUG - 2011-08-05 08:08:06 --> URI Class Initialized
DEBUG - 2011-08-05 08:08:06 --> Router Class Initialized
DEBUG - 2011-08-05 08:08:06 --> Output Class Initialized
DEBUG - 2011-08-05 08:08:06 --> Input Class Initialized
DEBUG - 2011-08-05 08:08:06 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-05 08:08:06 --> Language Class Initialized
DEBUG - 2011-08-05 08:08:06 --> Loader Class Initialized
DEBUG - 2011-08-05 08:08:06 --> Controller Class Initialized
DEBUG - 2011-08-05 08:08:06 --> Model Class Initialized
DEBUG - 2011-08-05 08:08:06 --> Model Class Initialized
DEBUG - 2011-08-05 08:08:06 --> Model Class Initialized
DEBUG - 2011-08-05 08:08:06 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-05 08:08:06 --> Database Driver Class Initialized
DEBUG - 2011-08-05 08:08:06 --> File loaded: application/views/table/main.php
DEBUG - 2011-08-05 08:08:06 --> Helper loaded: url_helper
DEBUG - 2011-08-05 08:08:06 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-05 08:08:06 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-05 08:08:06 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-05 08:08:06 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-05 08:08:06 --> Final output sent to browser
DEBUG - 2011-08-05 08:08:06 --> Total execution time: 0.2209
DEBUG - 2011-08-05 08:08:08 --> Config Class Initialized
DEBUG - 2011-08-05 08:08:08 --> Hooks Class Initialized
DEBUG - 2011-08-05 08:08:08 --> Utf8 Class Initialized
DEBUG - 2011-08-05 08:08:08 --> UTF-8 Support Enabled
DEBUG - 2011-08-05 08:08:08 --> URI Class Initialized
DEBUG - 2011-08-05 08:08:08 --> Router Class Initialized
DEBUG - 2011-08-05 08:08:08 --> Output Class Initialized
DEBUG - 2011-08-05 08:08:08 --> Input Class Initialized
DEBUG - 2011-08-05 08:08:08 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-05 08:08:08 --> Language Class Initialized
DEBUG - 2011-08-05 08:08:08 --> Loader Class Initialized
DEBUG - 2011-08-05 08:08:08 --> Controller Class Initialized
DEBUG - 2011-08-05 08:08:08 --> Model Class Initialized
DEBUG - 2011-08-05 08:08:08 --> Model Class Initialized
DEBUG - 2011-08-05 08:08:08 --> Model Class Initialized
DEBUG - 2011-08-05 08:08:08 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-05 08:08:08 --> Database Driver Class Initialized
DEBUG - 2011-08-05 08:08:08 --> Config Class Initialized
DEBUG - 2011-08-05 08:08:08 --> Hooks Class Initialized
DEBUG - 2011-08-05 08:08:08 --> Utf8 Class Initialized
DEBUG - 2011-08-05 08:08:08 --> UTF-8 Support Enabled
DEBUG - 2011-08-05 08:08:08 --> URI Class Initialized
DEBUG - 2011-08-05 08:08:08 --> Router Class Initialized
ERROR - 2011-08-05 08:08:08 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-08-05 08:08:09 --> File loaded: application/views/table/main.php
DEBUG - 2011-08-05 08:08:09 --> Helper loaded: url_helper
DEBUG - 2011-08-05 08:08:09 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-05 08:08:09 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-05 08:08:09 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-05 08:08:09 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-05 08:08:09 --> Final output sent to browser
DEBUG - 2011-08-05 08:08:09 --> Total execution time: 0.2289
DEBUG - 2011-08-05 08:08:27 --> Config Class Initialized
DEBUG - 2011-08-05 08:08:27 --> Hooks Class Initialized
DEBUG - 2011-08-05 08:08:27 --> Utf8 Class Initialized
DEBUG - 2011-08-05 08:08:27 --> UTF-8 Support Enabled
DEBUG - 2011-08-05 08:08:27 --> URI Class Initialized
DEBUG - 2011-08-05 08:08:27 --> Router Class Initialized
DEBUG - 2011-08-05 08:08:27 --> Output Class Initialized
DEBUG - 2011-08-05 08:08:27 --> Input Class Initialized
DEBUG - 2011-08-05 08:08:27 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-05 08:08:27 --> Language Class Initialized
DEBUG - 2011-08-05 08:08:27 --> Loader Class Initialized
DEBUG - 2011-08-05 08:08:27 --> Controller Class Initialized
DEBUG - 2011-08-05 08:08:27 --> Model Class Initialized
DEBUG - 2011-08-05 08:08:27 --> Model Class Initialized
DEBUG - 2011-08-05 08:08:27 --> Model Class Initialized
DEBUG - 2011-08-05 08:08:27 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-05 08:08:27 --> Database Driver Class Initialized
DEBUG - 2011-08-05 08:08:28 --> File loaded: application/views/table/main.php
DEBUG - 2011-08-05 08:08:28 --> Helper loaded: url_helper
DEBUG - 2011-08-05 08:08:28 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-05 08:08:28 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-05 08:08:28 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-05 08:08:28 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-05 08:08:28 --> Final output sent to browser
DEBUG - 2011-08-05 08:08:28 --> Total execution time: 0.6686
DEBUG - 2011-08-05 08:08:30 --> Config Class Initialized
DEBUG - 2011-08-05 08:08:30 --> Hooks Class Initialized
DEBUG - 2011-08-05 08:08:30 --> Utf8 Class Initialized
DEBUG - 2011-08-05 08:08:30 --> UTF-8 Support Enabled
DEBUG - 2011-08-05 08:08:30 --> URI Class Initialized
DEBUG - 2011-08-05 08:08:30 --> Router Class Initialized
DEBUG - 2011-08-05 08:08:30 --> Output Class Initialized
DEBUG - 2011-08-05 08:08:30 --> Input Class Initialized
DEBUG - 2011-08-05 08:08:30 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-05 08:08:30 --> Language Class Initialized
DEBUG - 2011-08-05 08:08:30 --> Loader Class Initialized
DEBUG - 2011-08-05 08:08:30 --> Controller Class Initialized
DEBUG - 2011-08-05 08:08:30 --> Model Class Initialized
DEBUG - 2011-08-05 08:08:30 --> Model Class Initialized
DEBUG - 2011-08-05 08:08:30 --> Model Class Initialized
DEBUG - 2011-08-05 08:08:30 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-05 08:08:30 --> Database Driver Class Initialized
DEBUG - 2011-08-05 08:08:30 --> File loaded: application/views/table/main.php
DEBUG - 2011-08-05 08:08:30 --> Helper loaded: url_helper
DEBUG - 2011-08-05 08:08:30 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-05 08:08:30 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-05 08:08:30 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-05 08:08:30 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-05 08:08:30 --> Final output sent to browser
DEBUG - 2011-08-05 08:08:30 --> Total execution time: 0.0583
DEBUG - 2011-08-05 08:08:30 --> Config Class Initialized
DEBUG - 2011-08-05 08:08:30 --> Hooks Class Initialized
DEBUG - 2011-08-05 08:08:30 --> Utf8 Class Initialized
DEBUG - 2011-08-05 08:08:30 --> UTF-8 Support Enabled
DEBUG - 2011-08-05 08:08:30 --> URI Class Initialized
DEBUG - 2011-08-05 08:08:30 --> Router Class Initialized
ERROR - 2011-08-05 08:08:30 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-08-05 08:08:53 --> Config Class Initialized
DEBUG - 2011-08-05 08:08:53 --> Hooks Class Initialized
DEBUG - 2011-08-05 08:08:53 --> Utf8 Class Initialized
DEBUG - 2011-08-05 08:08:53 --> UTF-8 Support Enabled
DEBUG - 2011-08-05 08:08:53 --> URI Class Initialized
DEBUG - 2011-08-05 08:08:53 --> Router Class Initialized
DEBUG - 2011-08-05 08:08:53 --> Output Class Initialized
DEBUG - 2011-08-05 08:08:53 --> Input Class Initialized
DEBUG - 2011-08-05 08:08:53 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-05 08:08:53 --> Language Class Initialized
DEBUG - 2011-08-05 08:08:53 --> Loader Class Initialized
DEBUG - 2011-08-05 08:08:53 --> Controller Class Initialized
DEBUG - 2011-08-05 08:08:53 --> Model Class Initialized
DEBUG - 2011-08-05 08:08:53 --> Model Class Initialized
DEBUG - 2011-08-05 08:08:53 --> Model Class Initialized
DEBUG - 2011-08-05 08:08:53 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-05 08:08:53 --> Database Driver Class Initialized
DEBUG - 2011-08-05 08:08:53 --> File loaded: application/views/table/main.php
DEBUG - 2011-08-05 08:08:53 --> Helper loaded: url_helper
DEBUG - 2011-08-05 08:08:53 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-05 08:08:53 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-05 08:08:53 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-05 08:08:53 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-05 08:08:53 --> Final output sent to browser
DEBUG - 2011-08-05 08:08:53 --> Total execution time: 0.1801
DEBUG - 2011-08-05 08:08:54 --> Config Class Initialized
DEBUG - 2011-08-05 08:08:54 --> Hooks Class Initialized
DEBUG - 2011-08-05 08:08:54 --> Utf8 Class Initialized
DEBUG - 2011-08-05 08:08:54 --> UTF-8 Support Enabled
DEBUG - 2011-08-05 08:08:54 --> URI Class Initialized
DEBUG - 2011-08-05 08:08:54 --> Router Class Initialized
ERROR - 2011-08-05 08:08:54 --> 404 Page Not Found --> robots.txt
DEBUG - 2011-08-05 08:08:55 --> Config Class Initialized
DEBUG - 2011-08-05 08:08:55 --> Hooks Class Initialized
DEBUG - 2011-08-05 08:08:55 --> Utf8 Class Initialized
DEBUG - 2011-08-05 08:08:55 --> UTF-8 Support Enabled
DEBUG - 2011-08-05 08:08:55 --> URI Class Initialized
DEBUG - 2011-08-05 08:08:55 --> Router Class Initialized
ERROR - 2011-08-05 08:08:55 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-08-05 08:09:00 --> Config Class Initialized
DEBUG - 2011-08-05 08:09:00 --> Hooks Class Initialized
DEBUG - 2011-08-05 08:09:00 --> Utf8 Class Initialized
DEBUG - 2011-08-05 08:09:00 --> UTF-8 Support Enabled
DEBUG - 2011-08-05 08:09:00 --> URI Class Initialized
DEBUG - 2011-08-05 08:09:00 --> Router Class Initialized
DEBUG - 2011-08-05 08:09:00 --> Output Class Initialized
DEBUG - 2011-08-05 08:09:00 --> Input Class Initialized
DEBUG - 2011-08-05 08:09:00 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-05 08:09:00 --> Language Class Initialized
DEBUG - 2011-08-05 08:09:00 --> Loader Class Initialized
DEBUG - 2011-08-05 08:09:00 --> Controller Class Initialized
DEBUG - 2011-08-05 08:09:00 --> Model Class Initialized
DEBUG - 2011-08-05 08:09:00 --> Model Class Initialized
DEBUG - 2011-08-05 08:09:00 --> Model Class Initialized
DEBUG - 2011-08-05 08:09:00 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-05 08:09:00 --> Database Driver Class Initialized
DEBUG - 2011-08-05 08:09:00 --> File loaded: application/views/table/main.php
DEBUG - 2011-08-05 08:09:00 --> Helper loaded: url_helper
DEBUG - 2011-08-05 08:09:00 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-05 08:09:00 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-05 08:09:00 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-05 08:09:00 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-05 08:09:00 --> Final output sent to browser
DEBUG - 2011-08-05 08:09:00 --> Total execution time: 0.0447
DEBUG - 2011-08-05 08:09:02 --> Config Class Initialized
DEBUG - 2011-08-05 08:09:02 --> Hooks Class Initialized
DEBUG - 2011-08-05 08:09:02 --> Utf8 Class Initialized
DEBUG - 2011-08-05 08:09:02 --> UTF-8 Support Enabled
DEBUG - 2011-08-05 08:09:02 --> URI Class Initialized
DEBUG - 2011-08-05 08:09:02 --> Router Class Initialized
ERROR - 2011-08-05 08:09:02 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-08-05 08:09:07 --> Config Class Initialized
DEBUG - 2011-08-05 08:09:07 --> Hooks Class Initialized
DEBUG - 2011-08-05 08:09:07 --> Utf8 Class Initialized
DEBUG - 2011-08-05 08:09:07 --> UTF-8 Support Enabled
DEBUG - 2011-08-05 08:09:07 --> URI Class Initialized
DEBUG - 2011-08-05 08:09:07 --> Router Class Initialized
DEBUG - 2011-08-05 08:09:07 --> Output Class Initialized
DEBUG - 2011-08-05 08:09:07 --> Input Class Initialized
DEBUG - 2011-08-05 08:09:07 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-05 08:09:07 --> Language Class Initialized
DEBUG - 2011-08-05 08:09:07 --> Loader Class Initialized
DEBUG - 2011-08-05 08:09:07 --> Controller Class Initialized
DEBUG - 2011-08-05 08:09:07 --> Model Class Initialized
DEBUG - 2011-08-05 08:09:07 --> Model Class Initialized
DEBUG - 2011-08-05 08:09:07 --> Model Class Initialized
DEBUG - 2011-08-05 08:09:07 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-05 08:09:07 --> Database Driver Class Initialized
DEBUG - 2011-08-05 08:09:07 --> File loaded: application/views/table/main.php
DEBUG - 2011-08-05 08:09:07 --> Helper loaded: url_helper
DEBUG - 2011-08-05 08:09:07 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-05 08:09:07 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-05 08:09:07 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-05 08:09:07 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-05 08:09:07 --> Final output sent to browser
DEBUG - 2011-08-05 08:09:07 --> Total execution time: 0.0625
DEBUG - 2011-08-05 08:09:10 --> Config Class Initialized
DEBUG - 2011-08-05 08:09:10 --> Hooks Class Initialized
DEBUG - 2011-08-05 08:09:10 --> Utf8 Class Initialized
DEBUG - 2011-08-05 08:09:10 --> UTF-8 Support Enabled
DEBUG - 2011-08-05 08:09:10 --> URI Class Initialized
DEBUG - 2011-08-05 08:09:10 --> Router Class Initialized
ERROR - 2011-08-05 08:09:10 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-08-05 08:10:02 --> Config Class Initialized
DEBUG - 2011-08-05 08:10:02 --> Hooks Class Initialized
DEBUG - 2011-08-05 08:10:02 --> Utf8 Class Initialized
DEBUG - 2011-08-05 08:10:02 --> UTF-8 Support Enabled
DEBUG - 2011-08-05 08:10:02 --> URI Class Initialized
DEBUG - 2011-08-05 08:10:02 --> Router Class Initialized
DEBUG - 2011-08-05 08:10:02 --> Output Class Initialized
DEBUG - 2011-08-05 08:10:02 --> Input Class Initialized
DEBUG - 2011-08-05 08:10:02 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-05 08:10:02 --> Language Class Initialized
DEBUG - 2011-08-05 08:10:02 --> Loader Class Initialized
DEBUG - 2011-08-05 08:10:02 --> Controller Class Initialized
ERROR - 2011-08-05 08:10:02 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-08-05 08:10:02 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-08-05 08:10:02 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-08-05 08:10:02 --> Model Class Initialized
DEBUG - 2011-08-05 08:10:02 --> Model Class Initialized
DEBUG - 2011-08-05 08:10:02 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-05 08:10:02 --> Database Driver Class Initialized
DEBUG - 2011-08-05 08:10:02 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-08-05 08:10:02 --> Helper loaded: url_helper
DEBUG - 2011-08-05 08:10:02 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-05 08:10:02 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-05 08:10:02 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-05 08:10:02 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-05 08:10:02 --> Final output sent to browser
DEBUG - 2011-08-05 08:10:02 --> Total execution time: 0.1602
DEBUG - 2011-08-05 08:11:21 --> Config Class Initialized
DEBUG - 2011-08-05 08:11:21 --> Hooks Class Initialized
DEBUG - 2011-08-05 08:11:21 --> Utf8 Class Initialized
DEBUG - 2011-08-05 08:11:21 --> UTF-8 Support Enabled
DEBUG - 2011-08-05 08:11:21 --> URI Class Initialized
DEBUG - 2011-08-05 08:11:21 --> Router Class Initialized
DEBUG - 2011-08-05 08:11:21 --> Output Class Initialized
DEBUG - 2011-08-05 08:11:21 --> Input Class Initialized
DEBUG - 2011-08-05 08:11:21 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-05 08:11:21 --> Language Class Initialized
DEBUG - 2011-08-05 08:11:21 --> Loader Class Initialized
DEBUG - 2011-08-05 08:11:21 --> Controller Class Initialized
DEBUG - 2011-08-05 08:11:21 --> Model Class Initialized
DEBUG - 2011-08-05 08:11:21 --> Model Class Initialized
DEBUG - 2011-08-05 08:11:21 --> Model Class Initialized
DEBUG - 2011-08-05 08:11:21 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-05 08:11:21 --> Database Driver Class Initialized
DEBUG - 2011-08-05 08:11:21 --> File loaded: application/views/table/main.php
DEBUG - 2011-08-05 08:11:21 --> Helper loaded: url_helper
DEBUG - 2011-08-05 08:11:21 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-05 08:11:21 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-05 08:11:21 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-05 08:11:21 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-05 08:11:21 --> Final output sent to browser
DEBUG - 2011-08-05 08:11:21 --> Total execution time: 0.0450
DEBUG - 2011-08-05 10:27:08 --> Config Class Initialized
DEBUG - 2011-08-05 10:27:08 --> Hooks Class Initialized
DEBUG - 2011-08-05 10:27:08 --> Utf8 Class Initialized
DEBUG - 2011-08-05 10:27:08 --> UTF-8 Support Enabled
DEBUG - 2011-08-05 10:27:08 --> URI Class Initialized
DEBUG - 2011-08-05 10:27:08 --> Router Class Initialized
ERROR - 2011-08-05 10:27:08 --> 404 Page Not Found --> robots.txt
DEBUG - 2011-08-05 10:27:59 --> Config Class Initialized
DEBUG - 2011-08-05 10:27:59 --> Hooks Class Initialized
DEBUG - 2011-08-05 10:27:59 --> Utf8 Class Initialized
DEBUG - 2011-08-05 10:27:59 --> UTF-8 Support Enabled
DEBUG - 2011-08-05 10:27:59 --> URI Class Initialized
DEBUG - 2011-08-05 10:27:59 --> Router Class Initialized
DEBUG - 2011-08-05 10:27:59 --> Output Class Initialized
DEBUG - 2011-08-05 10:27:59 --> Input Class Initialized
DEBUG - 2011-08-05 10:27:59 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-05 10:27:59 --> Language Class Initialized
DEBUG - 2011-08-05 10:27:59 --> Loader Class Initialized
DEBUG - 2011-08-05 10:27:59 --> Controller Class Initialized
DEBUG - 2011-08-05 10:27:59 --> Model Class Initialized
DEBUG - 2011-08-05 10:27:59 --> Model Class Initialized
DEBUG - 2011-08-05 10:27:59 --> Model Class Initialized
DEBUG - 2011-08-05 10:27:59 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-05 10:27:59 --> Database Driver Class Initialized
DEBUG - 2011-08-05 10:28:00 --> File loaded: application/views/table/main.php
DEBUG - 2011-08-05 10:28:00 --> Helper loaded: url_helper
DEBUG - 2011-08-05 10:28:00 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-05 10:28:00 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-05 10:28:00 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-05 10:28:00 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-05 10:28:00 --> Final output sent to browser
DEBUG - 2011-08-05 10:28:00 --> Total execution time: 0.8258
DEBUG - 2011-08-05 12:59:46 --> Config Class Initialized
DEBUG - 2011-08-05 12:59:46 --> Hooks Class Initialized
DEBUG - 2011-08-05 12:59:46 --> Utf8 Class Initialized
DEBUG - 2011-08-05 12:59:46 --> UTF-8 Support Enabled
DEBUG - 2011-08-05 12:59:46 --> URI Class Initialized
DEBUG - 2011-08-05 12:59:46 --> Router Class Initialized
DEBUG - 2011-08-05 12:59:46 --> Output Class Initialized
DEBUG - 2011-08-05 12:59:46 --> Input Class Initialized
DEBUG - 2011-08-05 12:59:46 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-05 12:59:46 --> Language Class Initialized
DEBUG - 2011-08-05 12:59:46 --> Loader Class Initialized
DEBUG - 2011-08-05 12:59:46 --> Controller Class Initialized
ERROR - 2011-08-05 12:59:46 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-08-05 12:59:46 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-08-05 12:59:46 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-08-05 12:59:46 --> Model Class Initialized
DEBUG - 2011-08-05 12:59:46 --> Model Class Initialized
DEBUG - 2011-08-05 12:59:46 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-05 12:59:46 --> Database Driver Class Initialized
DEBUG - 2011-08-05 12:59:46 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-08-05 12:59:46 --> Helper loaded: url_helper
DEBUG - 2011-08-05 12:59:46 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-05 12:59:46 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-05 12:59:46 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-05 12:59:46 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-05 12:59:46 --> Final output sent to browser
DEBUG - 2011-08-05 12:59:46 --> Total execution time: 0.2621
DEBUG - 2011-08-05 12:59:47 --> Config Class Initialized
DEBUG - 2011-08-05 12:59:47 --> Hooks Class Initialized
DEBUG - 2011-08-05 12:59:47 --> Utf8 Class Initialized
DEBUG - 2011-08-05 12:59:47 --> UTF-8 Support Enabled
DEBUG - 2011-08-05 12:59:47 --> URI Class Initialized
DEBUG - 2011-08-05 12:59:47 --> Router Class Initialized
DEBUG - 2011-08-05 12:59:47 --> Output Class Initialized
DEBUG - 2011-08-05 12:59:47 --> Input Class Initialized
DEBUG - 2011-08-05 12:59:47 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-05 12:59:47 --> Language Class Initialized
DEBUG - 2011-08-05 12:59:47 --> Loader Class Initialized
DEBUG - 2011-08-05 12:59:47 --> Controller Class Initialized
DEBUG - 2011-08-05 12:59:47 --> Model Class Initialized
DEBUG - 2011-08-05 12:59:47 --> Model Class Initialized
DEBUG - 2011-08-05 12:59:47 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-05 12:59:47 --> Database Driver Class Initialized
DEBUG - 2011-08-05 12:59:48 --> Final output sent to browser
DEBUG - 2011-08-05 12:59:48 --> Total execution time: 0.6930
DEBUG - 2011-08-05 12:59:49 --> Config Class Initialized
DEBUG - 2011-08-05 12:59:49 --> Hooks Class Initialized
DEBUG - 2011-08-05 12:59:49 --> Utf8 Class Initialized
DEBUG - 2011-08-05 12:59:49 --> UTF-8 Support Enabled
DEBUG - 2011-08-05 12:59:49 --> URI Class Initialized
DEBUG - 2011-08-05 12:59:49 --> Router Class Initialized
ERROR - 2011-08-05 12:59:49 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-08-05 12:59:49 --> Config Class Initialized
DEBUG - 2011-08-05 12:59:49 --> Hooks Class Initialized
DEBUG - 2011-08-05 12:59:49 --> Utf8 Class Initialized
DEBUG - 2011-08-05 12:59:49 --> UTF-8 Support Enabled
DEBUG - 2011-08-05 12:59:49 --> URI Class Initialized
DEBUG - 2011-08-05 12:59:49 --> Router Class Initialized
ERROR - 2011-08-05 12:59:49 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-08-05 12:59:49 --> Config Class Initialized
DEBUG - 2011-08-05 12:59:49 --> Hooks Class Initialized
DEBUG - 2011-08-05 12:59:49 --> Utf8 Class Initialized
DEBUG - 2011-08-05 12:59:49 --> UTF-8 Support Enabled
DEBUG - 2011-08-05 12:59:49 --> URI Class Initialized
DEBUG - 2011-08-05 12:59:49 --> Router Class Initialized
ERROR - 2011-08-05 12:59:49 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-08-05 14:28:43 --> Config Class Initialized
DEBUG - 2011-08-05 14:28:43 --> Hooks Class Initialized
DEBUG - 2011-08-05 14:28:43 --> Utf8 Class Initialized
DEBUG - 2011-08-05 14:28:43 --> UTF-8 Support Enabled
DEBUG - 2011-08-05 14:28:43 --> URI Class Initialized
DEBUG - 2011-08-05 14:28:43 --> Router Class Initialized
ERROR - 2011-08-05 14:28:43 --> 404 Page Not Found --> robots.txt
DEBUG - 2011-08-05 14:37:20 --> Config Class Initialized
DEBUG - 2011-08-05 14:37:20 --> Hooks Class Initialized
DEBUG - 2011-08-05 14:37:20 --> Utf8 Class Initialized
DEBUG - 2011-08-05 14:37:20 --> UTF-8 Support Enabled
DEBUG - 2011-08-05 14:37:20 --> URI Class Initialized
DEBUG - 2011-08-05 14:37:20 --> Router Class Initialized
ERROR - 2011-08-05 14:37:20 --> 404 Page Not Found --> robots.txt
DEBUG - 2011-08-05 14:37:21 --> Config Class Initialized
DEBUG - 2011-08-05 14:37:21 --> Hooks Class Initialized
DEBUG - 2011-08-05 14:37:21 --> Utf8 Class Initialized
DEBUG - 2011-08-05 14:37:21 --> UTF-8 Support Enabled
DEBUG - 2011-08-05 14:37:21 --> URI Class Initialized
DEBUG - 2011-08-05 14:37:21 --> Router Class Initialized
DEBUG - 2011-08-05 14:37:21 --> Output Class Initialized
DEBUG - 2011-08-05 14:37:21 --> Input Class Initialized
DEBUG - 2011-08-05 14:37:21 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-05 14:37:21 --> Language Class Initialized
DEBUG - 2011-08-05 14:37:21 --> Loader Class Initialized
DEBUG - 2011-08-05 14:37:21 --> Controller Class Initialized
DEBUG - 2011-08-05 14:37:21 --> Model Class Initialized
DEBUG - 2011-08-05 14:37:21 --> Model Class Initialized
DEBUG - 2011-08-05 14:37:21 --> Model Class Initialized
DEBUG - 2011-08-05 14:37:21 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-05 14:37:21 --> Database Driver Class Initialized
DEBUG - 2011-08-05 14:37:21 --> File loaded: application/views/table/main.php
DEBUG - 2011-08-05 14:37:21 --> Helper loaded: url_helper
DEBUG - 2011-08-05 14:37:21 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-05 14:37:21 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-05 14:37:21 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-05 14:37:21 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-05 14:37:21 --> Final output sent to browser
DEBUG - 2011-08-05 14:37:21 --> Total execution time: 0.4321
DEBUG - 2011-08-05 14:55:16 --> Config Class Initialized
DEBUG - 2011-08-05 14:55:16 --> Hooks Class Initialized
DEBUG - 2011-08-05 14:55:16 --> Utf8 Class Initialized
DEBUG - 2011-08-05 14:55:16 --> UTF-8 Support Enabled
DEBUG - 2011-08-05 14:55:16 --> URI Class Initialized
DEBUG - 2011-08-05 14:55:16 --> Router Class Initialized
DEBUG - 2011-08-05 14:55:16 --> Output Class Initialized
DEBUG - 2011-08-05 14:55:16 --> Input Class Initialized
DEBUG - 2011-08-05 14:55:16 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-05 14:55:16 --> Language Class Initialized
DEBUG - 2011-08-05 14:55:16 --> Loader Class Initialized
DEBUG - 2011-08-05 14:55:16 --> Controller Class Initialized
ERROR - 2011-08-05 14:55:16 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-08-05 14:55:16 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-08-05 14:55:16 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-08-05 14:55:16 --> Model Class Initialized
DEBUG - 2011-08-05 14:55:16 --> Model Class Initialized
DEBUG - 2011-08-05 14:55:16 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-05 14:55:16 --> Database Driver Class Initialized
DEBUG - 2011-08-05 14:55:16 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-08-05 14:55:16 --> Helper loaded: url_helper
DEBUG - 2011-08-05 14:55:16 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-05 14:55:16 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-05 14:55:16 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-05 14:55:16 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-05 14:55:16 --> Final output sent to browser
DEBUG - 2011-08-05 14:55:16 --> Total execution time: 0.0966
DEBUG - 2011-08-05 14:55:23 --> Config Class Initialized
DEBUG - 2011-08-05 14:55:23 --> Hooks Class Initialized
DEBUG - 2011-08-05 14:55:23 --> Utf8 Class Initialized
DEBUG - 2011-08-05 14:55:23 --> UTF-8 Support Enabled
DEBUG - 2011-08-05 14:55:23 --> URI Class Initialized
DEBUG - 2011-08-05 14:55:23 --> Router Class Initialized
DEBUG - 2011-08-05 14:55:23 --> Output Class Initialized
DEBUG - 2011-08-05 14:55:23 --> Input Class Initialized
DEBUG - 2011-08-05 14:55:23 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-05 14:55:23 --> Language Class Initialized
DEBUG - 2011-08-05 14:55:23 --> Loader Class Initialized
DEBUG - 2011-08-05 14:55:23 --> Controller Class Initialized
DEBUG - 2011-08-05 14:55:23 --> Model Class Initialized
DEBUG - 2011-08-05 14:55:23 --> Model Class Initialized
DEBUG - 2011-08-05 14:55:23 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-05 14:55:23 --> Database Driver Class Initialized
DEBUG - 2011-08-05 14:55:24 --> Final output sent to browser
DEBUG - 2011-08-05 14:55:24 --> Total execution time: 0.6753
DEBUG - 2011-08-05 14:55:28 --> Config Class Initialized
DEBUG - 2011-08-05 14:55:28 --> Hooks Class Initialized
DEBUG - 2011-08-05 14:55:28 --> Utf8 Class Initialized
DEBUG - 2011-08-05 14:55:28 --> UTF-8 Support Enabled
DEBUG - 2011-08-05 14:55:28 --> URI Class Initialized
DEBUG - 2011-08-05 14:55:28 --> Router Class Initialized
ERROR - 2011-08-05 14:55:28 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-08-05 14:56:04 --> Config Class Initialized
DEBUG - 2011-08-05 14:56:04 --> Hooks Class Initialized
DEBUG - 2011-08-05 14:56:04 --> Utf8 Class Initialized
DEBUG - 2011-08-05 14:56:04 --> UTF-8 Support Enabled
DEBUG - 2011-08-05 14:56:04 --> URI Class Initialized
DEBUG - 2011-08-05 14:56:04 --> Router Class Initialized
DEBUG - 2011-08-05 14:56:04 --> Output Class Initialized
DEBUG - 2011-08-05 14:56:04 --> Input Class Initialized
DEBUG - 2011-08-05 14:56:04 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-05 14:56:04 --> Language Class Initialized
DEBUG - 2011-08-05 14:56:04 --> Loader Class Initialized
DEBUG - 2011-08-05 14:56:04 --> Controller Class Initialized
ERROR - 2011-08-05 14:56:04 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-08-05 14:56:04 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-08-05 14:56:04 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-08-05 14:56:04 --> Model Class Initialized
DEBUG - 2011-08-05 14:56:04 --> Model Class Initialized
DEBUG - 2011-08-05 14:56:04 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-05 14:56:04 --> Database Driver Class Initialized
DEBUG - 2011-08-05 14:56:04 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-08-05 14:56:04 --> Helper loaded: url_helper
DEBUG - 2011-08-05 14:56:04 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-05 14:56:04 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-05 14:56:04 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-05 14:56:04 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-05 14:56:04 --> Final output sent to browser
DEBUG - 2011-08-05 14:56:04 --> Total execution time: 0.0264
DEBUG - 2011-08-05 14:56:06 --> Config Class Initialized
DEBUG - 2011-08-05 14:56:06 --> Hooks Class Initialized
DEBUG - 2011-08-05 14:56:06 --> Utf8 Class Initialized
DEBUG - 2011-08-05 14:56:06 --> UTF-8 Support Enabled
DEBUG - 2011-08-05 14:56:06 --> URI Class Initialized
DEBUG - 2011-08-05 14:56:06 --> Router Class Initialized
DEBUG - 2011-08-05 14:56:06 --> Output Class Initialized
DEBUG - 2011-08-05 14:56:06 --> Input Class Initialized
DEBUG - 2011-08-05 14:56:06 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-05 14:56:06 --> Language Class Initialized
DEBUG - 2011-08-05 14:56:06 --> Loader Class Initialized
DEBUG - 2011-08-05 14:56:06 --> Controller Class Initialized
DEBUG - 2011-08-05 14:56:06 --> Model Class Initialized
DEBUG - 2011-08-05 14:56:06 --> Model Class Initialized
DEBUG - 2011-08-05 14:56:06 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-05 14:56:06 --> Database Driver Class Initialized
DEBUG - 2011-08-05 14:56:06 --> Final output sent to browser
DEBUG - 2011-08-05 14:56:06 --> Total execution time: 0.6764
DEBUG - 2011-08-05 14:56:06 --> Config Class Initialized
DEBUG - 2011-08-05 14:56:06 --> Hooks Class Initialized
DEBUG - 2011-08-05 14:56:06 --> Utf8 Class Initialized
DEBUG - 2011-08-05 14:56:06 --> UTF-8 Support Enabled
DEBUG - 2011-08-05 14:56:06 --> URI Class Initialized
DEBUG - 2011-08-05 14:56:06 --> Router Class Initialized
ERROR - 2011-08-05 14:56:06 --> 404 Page Not Found --> robots.txt
DEBUG - 2011-08-05 14:56:06 --> Config Class Initialized
DEBUG - 2011-08-05 14:56:06 --> Hooks Class Initialized
DEBUG - 2011-08-05 14:56:06 --> Utf8 Class Initialized
DEBUG - 2011-08-05 14:56:06 --> UTF-8 Support Enabled
DEBUG - 2011-08-05 14:56:06 --> URI Class Initialized
DEBUG - 2011-08-05 14:56:06 --> Router Class Initialized
DEBUG - 2011-08-05 14:56:06 --> Output Class Initialized
DEBUG - 2011-08-05 14:56:07 --> Input Class Initialized
DEBUG - 2011-08-05 14:56:07 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-05 14:56:07 --> Language Class Initialized
DEBUG - 2011-08-05 14:56:07 --> Loader Class Initialized
DEBUG - 2011-08-05 14:56:07 --> Controller Class Initialized
ERROR - 2011-08-05 14:56:07 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-08-05 14:56:07 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-08-05 14:56:07 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-08-05 14:56:07 --> Model Class Initialized
DEBUG - 2011-08-05 14:56:07 --> Model Class Initialized
DEBUG - 2011-08-05 14:56:07 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-05 14:56:07 --> Database Driver Class Initialized
DEBUG - 2011-08-05 14:56:07 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-08-05 14:56:07 --> Helper loaded: url_helper
DEBUG - 2011-08-05 14:56:07 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-05 14:56:07 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-05 14:56:07 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-05 14:56:07 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-05 14:56:07 --> Final output sent to browser
DEBUG - 2011-08-05 14:56:07 --> Total execution time: 0.0904
DEBUG - 2011-08-05 14:56:08 --> Config Class Initialized
DEBUG - 2011-08-05 14:56:08 --> Hooks Class Initialized
DEBUG - 2011-08-05 14:56:08 --> Utf8 Class Initialized
DEBUG - 2011-08-05 14:56:08 --> UTF-8 Support Enabled
DEBUG - 2011-08-05 14:56:08 --> URI Class Initialized
DEBUG - 2011-08-05 14:56:08 --> Router Class Initialized
ERROR - 2011-08-05 14:56:08 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-08-05 14:56:38 --> Config Class Initialized
DEBUG - 2011-08-05 14:56:38 --> Hooks Class Initialized
DEBUG - 2011-08-05 14:56:38 --> Utf8 Class Initialized
DEBUG - 2011-08-05 14:56:38 --> UTF-8 Support Enabled
DEBUG - 2011-08-05 14:56:38 --> URI Class Initialized
DEBUG - 2011-08-05 14:56:38 --> Router Class Initialized
DEBUG - 2011-08-05 14:56:38 --> Output Class Initialized
DEBUG - 2011-08-05 14:56:38 --> Input Class Initialized
DEBUG - 2011-08-05 14:56:38 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-05 14:56:38 --> Language Class Initialized
DEBUG - 2011-08-05 14:56:38 --> Loader Class Initialized
DEBUG - 2011-08-05 14:56:38 --> Controller Class Initialized
ERROR - 2011-08-05 14:56:38 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-08-05 14:56:38 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-08-05 14:56:38 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-08-05 14:56:38 --> Model Class Initialized
DEBUG - 2011-08-05 14:56:38 --> Model Class Initialized
DEBUG - 2011-08-05 14:56:38 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-05 14:56:38 --> Database Driver Class Initialized
DEBUG - 2011-08-05 14:56:38 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-08-05 14:56:38 --> Helper loaded: url_helper
DEBUG - 2011-08-05 14:56:38 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-05 14:56:38 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-05 14:56:38 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-05 14:56:38 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-05 14:56:38 --> Final output sent to browser
DEBUG - 2011-08-05 14:56:38 --> Total execution time: 0.0306
DEBUG - 2011-08-05 14:56:40 --> Config Class Initialized
DEBUG - 2011-08-05 14:56:40 --> Hooks Class Initialized
DEBUG - 2011-08-05 14:56:40 --> Utf8 Class Initialized
DEBUG - 2011-08-05 14:56:40 --> UTF-8 Support Enabled
DEBUG - 2011-08-05 14:56:40 --> URI Class Initialized
DEBUG - 2011-08-05 14:56:40 --> Router Class Initialized
DEBUG - 2011-08-05 14:56:40 --> Output Class Initialized
DEBUG - 2011-08-05 14:56:40 --> Input Class Initialized
DEBUG - 2011-08-05 14:56:40 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-05 14:56:40 --> Language Class Initialized
DEBUG - 2011-08-05 14:56:40 --> Loader Class Initialized
DEBUG - 2011-08-05 14:56:40 --> Controller Class Initialized
DEBUG - 2011-08-05 14:56:40 --> Model Class Initialized
DEBUG - 2011-08-05 14:56:40 --> Model Class Initialized
DEBUG - 2011-08-05 14:56:40 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-05 14:56:40 --> Database Driver Class Initialized
DEBUG - 2011-08-05 14:56:40 --> Final output sent to browser
DEBUG - 2011-08-05 14:56:40 --> Total execution time: 0.5504
DEBUG - 2011-08-05 14:56:42 --> Config Class Initialized
DEBUG - 2011-08-05 14:56:42 --> Hooks Class Initialized
DEBUG - 2011-08-05 14:56:42 --> Utf8 Class Initialized
DEBUG - 2011-08-05 14:56:42 --> UTF-8 Support Enabled
DEBUG - 2011-08-05 14:56:42 --> URI Class Initialized
DEBUG - 2011-08-05 14:56:42 --> Router Class Initialized
ERROR - 2011-08-05 14:56:42 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-08-05 14:56:52 --> Config Class Initialized
DEBUG - 2011-08-05 14:56:52 --> Hooks Class Initialized
DEBUG - 2011-08-05 14:56:52 --> Utf8 Class Initialized
DEBUG - 2011-08-05 14:56:52 --> UTF-8 Support Enabled
DEBUG - 2011-08-05 14:56:52 --> URI Class Initialized
DEBUG - 2011-08-05 14:56:52 --> Router Class Initialized
DEBUG - 2011-08-05 14:56:52 --> Output Class Initialized
DEBUG - 2011-08-05 14:56:52 --> Input Class Initialized
DEBUG - 2011-08-05 14:56:52 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-05 14:56:52 --> Language Class Initialized
DEBUG - 2011-08-05 14:56:52 --> Loader Class Initialized
DEBUG - 2011-08-05 14:56:52 --> Controller Class Initialized
ERROR - 2011-08-05 14:56:52 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-08-05 14:56:52 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-08-05 14:56:52 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-08-05 14:56:52 --> Model Class Initialized
DEBUG - 2011-08-05 14:56:52 --> Model Class Initialized
DEBUG - 2011-08-05 14:56:52 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-05 14:56:52 --> Database Driver Class Initialized
DEBUG - 2011-08-05 14:56:52 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-08-05 14:56:52 --> Helper loaded: url_helper
DEBUG - 2011-08-05 14:56:52 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-05 14:56:52 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-05 14:56:52 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-05 14:56:52 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-05 14:56:52 --> Final output sent to browser
DEBUG - 2011-08-05 14:56:52 --> Total execution time: 0.0393
DEBUG - 2011-08-05 14:56:53 --> Config Class Initialized
DEBUG - 2011-08-05 14:56:53 --> Hooks Class Initialized
DEBUG - 2011-08-05 14:56:53 --> Utf8 Class Initialized
DEBUG - 2011-08-05 14:56:53 --> UTF-8 Support Enabled
DEBUG - 2011-08-05 14:56:53 --> URI Class Initialized
DEBUG - 2011-08-05 14:56:53 --> Router Class Initialized
DEBUG - 2011-08-05 14:56:53 --> Output Class Initialized
DEBUG - 2011-08-05 14:56:53 --> Input Class Initialized
DEBUG - 2011-08-05 14:56:53 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-05 14:56:53 --> Language Class Initialized
DEBUG - 2011-08-05 14:56:53 --> Loader Class Initialized
DEBUG - 2011-08-05 14:56:53 --> Controller Class Initialized
DEBUG - 2011-08-05 14:56:53 --> Model Class Initialized
DEBUG - 2011-08-05 14:56:53 --> Model Class Initialized
DEBUG - 2011-08-05 14:56:53 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-05 14:56:53 --> Database Driver Class Initialized
DEBUG - 2011-08-05 14:56:54 --> Final output sent to browser
DEBUG - 2011-08-05 14:56:54 --> Total execution time: 0.5638
DEBUG - 2011-08-05 14:56:55 --> Config Class Initialized
DEBUG - 2011-08-05 14:56:55 --> Hooks Class Initialized
DEBUG - 2011-08-05 14:56:55 --> Utf8 Class Initialized
DEBUG - 2011-08-05 14:56:55 --> UTF-8 Support Enabled
DEBUG - 2011-08-05 14:56:55 --> URI Class Initialized
DEBUG - 2011-08-05 14:56:55 --> Router Class Initialized
ERROR - 2011-08-05 14:56:55 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-08-05 16:16:27 --> Config Class Initialized
DEBUG - 2011-08-05 16:16:27 --> Hooks Class Initialized
DEBUG - 2011-08-05 16:16:27 --> Utf8 Class Initialized
DEBUG - 2011-08-05 16:16:27 --> UTF-8 Support Enabled
DEBUG - 2011-08-05 16:16:27 --> URI Class Initialized
DEBUG - 2011-08-05 16:16:27 --> Router Class Initialized
ERROR - 2011-08-05 16:16:27 --> 404 Page Not Found --> robots.txt
DEBUG - 2011-08-05 17:12:45 --> Config Class Initialized
DEBUG - 2011-08-05 17:12:45 --> Hooks Class Initialized
DEBUG - 2011-08-05 17:12:45 --> Utf8 Class Initialized
DEBUG - 2011-08-05 17:12:45 --> UTF-8 Support Enabled
DEBUG - 2011-08-05 17:12:45 --> URI Class Initialized
DEBUG - 2011-08-05 17:12:45 --> Router Class Initialized
DEBUG - 2011-08-05 17:12:45 --> Output Class Initialized
DEBUG - 2011-08-05 17:12:45 --> Input Class Initialized
DEBUG - 2011-08-05 17:12:45 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-05 17:12:45 --> Language Class Initialized
DEBUG - 2011-08-05 17:12:45 --> Loader Class Initialized
DEBUG - 2011-08-05 17:12:45 --> Controller Class Initialized
DEBUG - 2011-08-05 17:12:45 --> Model Class Initialized
DEBUG - 2011-08-05 17:12:45 --> Model Class Initialized
DEBUG - 2011-08-05 17:12:45 --> Model Class Initialized
DEBUG - 2011-08-05 17:12:45 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-05 17:12:45 --> Database Driver Class Initialized
DEBUG - 2011-08-05 17:12:45 --> File loaded: application/views/table/main.php
DEBUG - 2011-08-05 17:12:45 --> Helper loaded: url_helper
DEBUG - 2011-08-05 17:12:45 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-05 17:12:45 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-05 17:12:45 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-05 17:12:45 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-05 17:12:45 --> Final output sent to browser
DEBUG - 2011-08-05 17:12:45 --> Total execution time: 0.5356
DEBUG - 2011-08-05 17:12:48 --> Config Class Initialized
DEBUG - 2011-08-05 17:12:48 --> Hooks Class Initialized
DEBUG - 2011-08-05 17:12:48 --> Utf8 Class Initialized
DEBUG - 2011-08-05 17:12:48 --> UTF-8 Support Enabled
DEBUG - 2011-08-05 17:12:48 --> URI Class Initialized
DEBUG - 2011-08-05 17:12:48 --> Router Class Initialized
ERROR - 2011-08-05 17:12:48 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-08-05 17:36:24 --> Config Class Initialized
DEBUG - 2011-08-05 17:36:24 --> Hooks Class Initialized
DEBUG - 2011-08-05 17:36:24 --> Utf8 Class Initialized
DEBUG - 2011-08-05 17:36:24 --> UTF-8 Support Enabled
DEBUG - 2011-08-05 17:36:24 --> URI Class Initialized
DEBUG - 2011-08-05 17:36:24 --> Router Class Initialized
DEBUG - 2011-08-05 17:36:24 --> Output Class Initialized
DEBUG - 2011-08-05 17:36:24 --> Input Class Initialized
DEBUG - 2011-08-05 17:36:24 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-05 17:36:24 --> Language Class Initialized
DEBUG - 2011-08-05 17:36:24 --> Loader Class Initialized
DEBUG - 2011-08-05 17:36:24 --> Controller Class Initialized
DEBUG - 2011-08-05 17:36:24 --> Model Class Initialized
DEBUG - 2011-08-05 17:36:24 --> Model Class Initialized
DEBUG - 2011-08-05 17:36:24 --> Model Class Initialized
DEBUG - 2011-08-05 17:36:24 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-05 17:36:24 --> Database Driver Class Initialized
DEBUG - 2011-08-05 17:36:25 --> File loaded: application/views/table/main.php
DEBUG - 2011-08-05 17:36:25 --> Helper loaded: url_helper
DEBUG - 2011-08-05 17:36:25 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-05 17:36:25 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-05 17:36:25 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-05 17:36:25 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-05 17:36:25 --> Final output sent to browser
DEBUG - 2011-08-05 17:36:25 --> Total execution time: 0.2263
DEBUG - 2011-08-05 17:36:26 --> Config Class Initialized
DEBUG - 2011-08-05 17:36:26 --> Hooks Class Initialized
DEBUG - 2011-08-05 17:36:26 --> Utf8 Class Initialized
DEBUG - 2011-08-05 17:36:26 --> UTF-8 Support Enabled
DEBUG - 2011-08-05 17:36:26 --> URI Class Initialized
DEBUG - 2011-08-05 17:36:26 --> Router Class Initialized
ERROR - 2011-08-05 17:36:26 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-08-05 17:36:26 --> Config Class Initialized
DEBUG - 2011-08-05 17:36:26 --> Hooks Class Initialized
DEBUG - 2011-08-05 17:36:26 --> Utf8 Class Initialized
DEBUG - 2011-08-05 17:36:26 --> UTF-8 Support Enabled
DEBUG - 2011-08-05 17:36:26 --> URI Class Initialized
DEBUG - 2011-08-05 17:36:26 --> Router Class Initialized
ERROR - 2011-08-05 17:36:26 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-08-05 17:49:51 --> Config Class Initialized
DEBUG - 2011-08-05 17:49:51 --> Hooks Class Initialized
DEBUG - 2011-08-05 17:49:51 --> Utf8 Class Initialized
DEBUG - 2011-08-05 17:49:51 --> UTF-8 Support Enabled
DEBUG - 2011-08-05 17:49:51 --> URI Class Initialized
DEBUG - 2011-08-05 17:49:51 --> Router Class Initialized
DEBUG - 2011-08-05 17:49:51 --> Output Class Initialized
DEBUG - 2011-08-05 17:49:51 --> Input Class Initialized
DEBUG - 2011-08-05 17:49:51 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-05 17:49:51 --> Language Class Initialized
DEBUG - 2011-08-05 17:49:51 --> Loader Class Initialized
DEBUG - 2011-08-05 17:49:51 --> Controller Class Initialized
DEBUG - 2011-08-05 17:49:51 --> Model Class Initialized
DEBUG - 2011-08-05 17:49:51 --> Model Class Initialized
DEBUG - 2011-08-05 17:49:51 --> Model Class Initialized
DEBUG - 2011-08-05 17:49:51 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-05 17:49:51 --> Database Driver Class Initialized
DEBUG - 2011-08-05 17:49:51 --> File loaded: application/views/table/main.php
DEBUG - 2011-08-05 17:49:51 --> Helper loaded: url_helper
DEBUG - 2011-08-05 17:49:51 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-05 17:49:51 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-05 17:49:51 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-05 17:49:51 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-05 17:49:51 --> Final output sent to browser
DEBUG - 2011-08-05 17:49:51 --> Total execution time: 0.0519
DEBUG - 2011-08-05 17:50:33 --> Config Class Initialized
DEBUG - 2011-08-05 17:50:33 --> Hooks Class Initialized
DEBUG - 2011-08-05 17:50:33 --> Utf8 Class Initialized
DEBUG - 2011-08-05 17:50:33 --> UTF-8 Support Enabled
DEBUG - 2011-08-05 17:50:33 --> URI Class Initialized
DEBUG - 2011-08-05 17:50:33 --> Router Class Initialized
DEBUG - 2011-08-05 17:50:33 --> Output Class Initialized
DEBUG - 2011-08-05 17:50:33 --> Input Class Initialized
DEBUG - 2011-08-05 17:50:33 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-05 17:50:33 --> Language Class Initialized
DEBUG - 2011-08-05 17:50:33 --> Loader Class Initialized
DEBUG - 2011-08-05 17:50:33 --> Controller Class Initialized
DEBUG - 2011-08-05 17:50:33 --> Model Class Initialized
DEBUG - 2011-08-05 17:50:33 --> Model Class Initialized
DEBUG - 2011-08-05 17:50:33 --> Model Class Initialized
DEBUG - 2011-08-05 17:50:33 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-05 17:50:33 --> Database Driver Class Initialized
DEBUG - 2011-08-05 17:50:33 --> File loaded: application/views/table/main.php
DEBUG - 2011-08-05 17:50:33 --> Helper loaded: url_helper
DEBUG - 2011-08-05 17:50:33 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-05 17:50:33 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-05 17:50:33 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-05 17:50:33 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-05 17:50:33 --> Final output sent to browser
DEBUG - 2011-08-05 17:50:33 --> Total execution time: 0.0532
DEBUG - 2011-08-05 17:50:48 --> Config Class Initialized
DEBUG - 2011-08-05 17:50:48 --> Hooks Class Initialized
DEBUG - 2011-08-05 17:50:48 --> Utf8 Class Initialized
DEBUG - 2011-08-05 17:50:48 --> UTF-8 Support Enabled
DEBUG - 2011-08-05 17:50:48 --> URI Class Initialized
DEBUG - 2011-08-05 17:50:48 --> Router Class Initialized
DEBUG - 2011-08-05 17:50:48 --> Output Class Initialized
DEBUG - 2011-08-05 17:50:48 --> Input Class Initialized
DEBUG - 2011-08-05 17:50:48 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-05 17:50:48 --> Language Class Initialized
DEBUG - 2011-08-05 17:50:48 --> Loader Class Initialized
DEBUG - 2011-08-05 17:50:48 --> Controller Class Initialized
DEBUG - 2011-08-05 17:50:48 --> Model Class Initialized
DEBUG - 2011-08-05 17:50:48 --> Model Class Initialized
DEBUG - 2011-08-05 17:50:48 --> Model Class Initialized
DEBUG - 2011-08-05 17:50:48 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-05 17:50:48 --> Database Driver Class Initialized
DEBUG - 2011-08-05 17:50:48 --> File loaded: application/views/table/main.php
DEBUG - 2011-08-05 17:50:48 --> Helper loaded: url_helper
DEBUG - 2011-08-05 17:50:48 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-05 17:50:48 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-05 17:50:48 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-05 17:50:48 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-05 17:50:48 --> Final output sent to browser
DEBUG - 2011-08-05 17:50:48 --> Total execution time: 0.0575
DEBUG - 2011-08-05 18:58:37 --> Config Class Initialized
DEBUG - 2011-08-05 18:58:37 --> Hooks Class Initialized
DEBUG - 2011-08-05 18:58:37 --> Utf8 Class Initialized
DEBUG - 2011-08-05 18:58:37 --> UTF-8 Support Enabled
DEBUG - 2011-08-05 18:58:37 --> URI Class Initialized
DEBUG - 2011-08-05 18:58:37 --> Router Class Initialized
ERROR - 2011-08-05 18:58:37 --> 404 Page Not Found --> robots.txt
DEBUG - 2011-08-05 21:28:37 --> Config Class Initialized
DEBUG - 2011-08-05 21:28:37 --> Hooks Class Initialized
DEBUG - 2011-08-05 21:28:37 --> Utf8 Class Initialized
DEBUG - 2011-08-05 21:28:37 --> UTF-8 Support Enabled
DEBUG - 2011-08-05 21:28:37 --> URI Class Initialized
DEBUG - 2011-08-05 21:28:37 --> Router Class Initialized
DEBUG - 2011-08-05 21:28:37 --> No URI present. Default controller set.
DEBUG - 2011-08-05 21:28:37 --> Output Class Initialized
DEBUG - 2011-08-05 21:28:37 --> Input Class Initialized
DEBUG - 2011-08-05 21:28:37 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-05 21:28:37 --> Language Class Initialized
DEBUG - 2011-08-05 21:28:37 --> Loader Class Initialized
DEBUG - 2011-08-05 21:28:37 --> Controller Class Initialized
DEBUG - 2011-08-05 21:28:37 --> File loaded: application/views/splash/main.php
DEBUG - 2011-08-05 21:28:37 --> Helper loaded: url_helper
DEBUG - 2011-08-05 21:28:37 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-05 21:28:37 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-05 21:28:37 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-05 21:28:37 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-05 21:28:37 --> Final output sent to browser
DEBUG - 2011-08-05 21:28:37 --> Total execution time: 0.0713
DEBUG - 2011-08-05 21:59:40 --> Config Class Initialized
DEBUG - 2011-08-05 21:59:40 --> Hooks Class Initialized
DEBUG - 2011-08-05 21:59:40 --> Utf8 Class Initialized
DEBUG - 2011-08-05 21:59:40 --> UTF-8 Support Enabled
DEBUG - 2011-08-05 21:59:40 --> URI Class Initialized
DEBUG - 2011-08-05 21:59:40 --> Router Class Initialized
DEBUG - 2011-08-05 21:59:40 --> Output Class Initialized
DEBUG - 2011-08-05 21:59:40 --> Input Class Initialized
DEBUG - 2011-08-05 21:59:40 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-05 21:59:40 --> Language Class Initialized
DEBUG - 2011-08-05 21:59:40 --> Loader Class Initialized
DEBUG - 2011-08-05 21:59:40 --> Controller Class Initialized
ERROR - 2011-08-05 21:59:40 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-08-05 21:59:40 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-08-05 21:59:40 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-08-05 21:59:40 --> Model Class Initialized
DEBUG - 2011-08-05 21:59:40 --> Model Class Initialized
DEBUG - 2011-08-05 21:59:40 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-05 21:59:40 --> Database Driver Class Initialized
DEBUG - 2011-08-05 21:59:40 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-08-05 21:59:40 --> Helper loaded: url_helper
DEBUG - 2011-08-05 21:59:40 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-05 21:59:40 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-05 21:59:40 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-05 21:59:40 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-05 21:59:40 --> Final output sent to browser
DEBUG - 2011-08-05 21:59:40 --> Total execution time: 0.1182
DEBUG - 2011-08-05 21:59:41 --> Config Class Initialized
DEBUG - 2011-08-05 21:59:41 --> Hooks Class Initialized
DEBUG - 2011-08-05 21:59:41 --> Utf8 Class Initialized
DEBUG - 2011-08-05 21:59:41 --> UTF-8 Support Enabled
DEBUG - 2011-08-05 21:59:41 --> URI Class Initialized
DEBUG - 2011-08-05 21:59:41 --> Router Class Initialized
DEBUG - 2011-08-05 21:59:41 --> Output Class Initialized
DEBUG - 2011-08-05 21:59:41 --> Input Class Initialized
DEBUG - 2011-08-05 21:59:41 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-05 21:59:41 --> Language Class Initialized
DEBUG - 2011-08-05 21:59:41 --> Loader Class Initialized
DEBUG - 2011-08-05 21:59:41 --> Controller Class Initialized
DEBUG - 2011-08-05 21:59:41 --> Model Class Initialized
DEBUG - 2011-08-05 21:59:41 --> Model Class Initialized
DEBUG - 2011-08-05 21:59:41 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-05 21:59:41 --> Database Driver Class Initialized
DEBUG - 2011-08-05 21:59:42 --> Final output sent to browser
DEBUG - 2011-08-05 21:59:42 --> Total execution time: 0.6568
DEBUG - 2011-08-05 21:59:43 --> Config Class Initialized
DEBUG - 2011-08-05 21:59:43 --> Hooks Class Initialized
DEBUG - 2011-08-05 21:59:43 --> Utf8 Class Initialized
DEBUG - 2011-08-05 21:59:43 --> UTF-8 Support Enabled
DEBUG - 2011-08-05 21:59:43 --> URI Class Initialized
DEBUG - 2011-08-05 21:59:43 --> Router Class Initialized
ERROR - 2011-08-05 21:59:43 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-08-05 21:59:48 --> Config Class Initialized
DEBUG - 2011-08-05 21:59:48 --> Hooks Class Initialized
DEBUG - 2011-08-05 21:59:48 --> Utf8 Class Initialized
DEBUG - 2011-08-05 21:59:48 --> UTF-8 Support Enabled
DEBUG - 2011-08-05 21:59:48 --> URI Class Initialized
DEBUG - 2011-08-05 21:59:48 --> Router Class Initialized
DEBUG - 2011-08-05 21:59:48 --> Output Class Initialized
DEBUG - 2011-08-05 21:59:48 --> Input Class Initialized
DEBUG - 2011-08-05 21:59:48 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-05 21:59:48 --> Language Class Initialized
DEBUG - 2011-08-05 21:59:48 --> Loader Class Initialized
DEBUG - 2011-08-05 21:59:48 --> Controller Class Initialized
DEBUG - 2011-08-05 21:59:48 --> Model Class Initialized
DEBUG - 2011-08-05 21:59:48 --> Model Class Initialized
DEBUG - 2011-08-05 21:59:48 --> Model Class Initialized
DEBUG - 2011-08-05 21:59:48 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-05 21:59:48 --> Database Driver Class Initialized
DEBUG - 2011-08-05 21:59:48 --> File loaded: application/views/table/main.php
DEBUG - 2011-08-05 21:59:48 --> Helper loaded: url_helper
DEBUG - 2011-08-05 21:59:48 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-05 21:59:48 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-05 21:59:48 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-05 21:59:48 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-05 21:59:48 --> Final output sent to browser
DEBUG - 2011-08-05 21:59:48 --> Total execution time: 0.4757
DEBUG - 2011-08-05 21:59:50 --> Config Class Initialized
DEBUG - 2011-08-05 21:59:50 --> Hooks Class Initialized
DEBUG - 2011-08-05 21:59:50 --> Utf8 Class Initialized
DEBUG - 2011-08-05 21:59:50 --> UTF-8 Support Enabled
DEBUG - 2011-08-05 21:59:50 --> URI Class Initialized
DEBUG - 2011-08-05 21:59:50 --> Router Class Initialized
ERROR - 2011-08-05 21:59:50 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-08-05 22:21:17 --> Config Class Initialized
DEBUG - 2011-08-05 22:21:17 --> Hooks Class Initialized
DEBUG - 2011-08-05 22:21:17 --> Utf8 Class Initialized
DEBUG - 2011-08-05 22:21:17 --> UTF-8 Support Enabled
DEBUG - 2011-08-05 22:21:17 --> URI Class Initialized
DEBUG - 2011-08-05 22:21:17 --> Router Class Initialized
ERROR - 2011-08-05 22:21:17 --> 404 Page Not Found --> robots.txt
DEBUG - 2011-08-05 22:21:18 --> Config Class Initialized
DEBUG - 2011-08-05 22:21:18 --> Hooks Class Initialized
DEBUG - 2011-08-05 22:21:18 --> Utf8 Class Initialized
DEBUG - 2011-08-05 22:21:18 --> UTF-8 Support Enabled
DEBUG - 2011-08-05 22:21:18 --> URI Class Initialized
DEBUG - 2011-08-05 22:21:18 --> Router Class Initialized
DEBUG - 2011-08-05 22:21:18 --> No URI present. Default controller set.
DEBUG - 2011-08-05 22:21:18 --> Output Class Initialized
DEBUG - 2011-08-05 22:21:18 --> Input Class Initialized
DEBUG - 2011-08-05 22:21:18 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-05 22:21:18 --> Language Class Initialized
DEBUG - 2011-08-05 22:21:18 --> Loader Class Initialized
DEBUG - 2011-08-05 22:21:18 --> Controller Class Initialized
DEBUG - 2011-08-05 22:21:18 --> File loaded: application/views/splash/main.php
DEBUG - 2011-08-05 22:21:18 --> Helper loaded: url_helper
DEBUG - 2011-08-05 22:21:18 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-05 22:21:18 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-05 22:21:18 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-05 22:21:18 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-05 22:21:18 --> Final output sent to browser
DEBUG - 2011-08-05 22:21:18 --> Total execution time: 0.0375
DEBUG - 2011-08-05 23:40:42 --> Config Class Initialized
DEBUG - 2011-08-05 23:40:42 --> Hooks Class Initialized
DEBUG - 2011-08-05 23:40:42 --> Utf8 Class Initialized
DEBUG - 2011-08-05 23:40:42 --> UTF-8 Support Enabled
DEBUG - 2011-08-05 23:40:42 --> URI Class Initialized
DEBUG - 2011-08-05 23:40:42 --> Router Class Initialized
ERROR - 2011-08-05 23:40:42 --> 404 Page Not Found --> robots.txt

<?php  if ( ! defined('BASEPATH')) exit('No direct script access allowed'); ?>

DEBUG - 2011-06-26 00:41:13 --> Config Class Initialized
DEBUG - 2011-06-26 00:41:13 --> Hooks Class Initialized
DEBUG - 2011-06-26 00:41:13 --> Utf8 Class Initialized
DEBUG - 2011-06-26 00:41:13 --> UTF-8 Support Enabled
DEBUG - 2011-06-26 00:41:13 --> URI Class Initialized
DEBUG - 2011-06-26 00:41:13 --> Router Class Initialized
DEBUG - 2011-06-26 00:41:13 --> Output Class Initialized
DEBUG - 2011-06-26 00:41:13 --> Input Class Initialized
DEBUG - 2011-06-26 00:41:13 --> Global POST and COOKIE data sanitized
DEBUG - 2011-06-26 00:41:13 --> Language Class Initialized
DEBUG - 2011-06-26 00:41:13 --> Loader Class Initialized
DEBUG - 2011-06-26 00:41:13 --> Controller Class Initialized
ERROR - 2011-06-26 00:41:13 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-06-26 00:41:13 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-06-26 00:41:13 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-06-26 00:41:13 --> Model Class Initialized
DEBUG - 2011-06-26 00:41:13 --> Model Class Initialized
DEBUG - 2011-06-26 00:41:13 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-06-26 00:41:13 --> Database Driver Class Initialized
DEBUG - 2011-06-26 00:41:13 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-06-26 00:41:13 --> Helper loaded: url_helper
DEBUG - 2011-06-26 00:41:13 --> File loaded: application/views/common/header.php
DEBUG - 2011-06-26 00:41:13 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-06-26 00:41:13 --> File loaded: application/views/common/footer.php
DEBUG - 2011-06-26 00:41:13 --> File loaded: application/views/layout/main.php
DEBUG - 2011-06-26 00:41:13 --> Final output sent to browser
DEBUG - 2011-06-26 00:41:13 --> Total execution time: 0.2889
DEBUG - 2011-06-26 00:41:15 --> Config Class Initialized
DEBUG - 2011-06-26 00:41:15 --> Hooks Class Initialized
DEBUG - 2011-06-26 00:41:15 --> Utf8 Class Initialized
DEBUG - 2011-06-26 00:41:15 --> UTF-8 Support Enabled
DEBUG - 2011-06-26 00:41:15 --> URI Class Initialized
DEBUG - 2011-06-26 00:41:15 --> Router Class Initialized
DEBUG - 2011-06-26 00:41:15 --> Output Class Initialized
DEBUG - 2011-06-26 00:41:15 --> Input Class Initialized
DEBUG - 2011-06-26 00:41:15 --> Global POST and COOKIE data sanitized
DEBUG - 2011-06-26 00:41:15 --> Language Class Initialized
DEBUG - 2011-06-26 00:41:15 --> Loader Class Initialized
DEBUG - 2011-06-26 00:41:15 --> Controller Class Initialized
DEBUG - 2011-06-26 00:41:15 --> Model Class Initialized
DEBUG - 2011-06-26 00:41:15 --> Model Class Initialized
DEBUG - 2011-06-26 00:41:15 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-06-26 00:41:15 --> Database Driver Class Initialized
DEBUG - 2011-06-26 00:41:16 --> Final output sent to browser
DEBUG - 2011-06-26 00:41:16 --> Total execution time: 0.7271
DEBUG - 2011-06-26 00:41:18 --> Config Class Initialized
DEBUG - 2011-06-26 00:41:18 --> Hooks Class Initialized
DEBUG - 2011-06-26 00:41:18 --> Utf8 Class Initialized
DEBUG - 2011-06-26 00:41:18 --> UTF-8 Support Enabled
DEBUG - 2011-06-26 00:41:18 --> URI Class Initialized
DEBUG - 2011-06-26 00:41:18 --> Router Class Initialized
ERROR - 2011-06-26 00:41:18 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-06-26 00:41:39 --> Config Class Initialized
DEBUG - 2011-06-26 00:41:39 --> Hooks Class Initialized
DEBUG - 2011-06-26 00:41:39 --> Utf8 Class Initialized
DEBUG - 2011-06-26 00:41:39 --> UTF-8 Support Enabled
DEBUG - 2011-06-26 00:41:39 --> URI Class Initialized
DEBUG - 2011-06-26 00:41:39 --> Router Class Initialized
DEBUG - 2011-06-26 00:41:39 --> Output Class Initialized
DEBUG - 2011-06-26 00:41:39 --> Input Class Initialized
DEBUG - 2011-06-26 00:41:39 --> Global POST and COOKIE data sanitized
DEBUG - 2011-06-26 00:41:39 --> Language Class Initialized
DEBUG - 2011-06-26 00:41:39 --> Loader Class Initialized
DEBUG - 2011-06-26 00:41:39 --> Controller Class Initialized
ERROR - 2011-06-26 00:41:39 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-06-26 00:41:39 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-06-26 00:41:39 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-06-26 00:41:39 --> Model Class Initialized
DEBUG - 2011-06-26 00:41:39 --> Model Class Initialized
DEBUG - 2011-06-26 00:41:39 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-06-26 00:41:39 --> Database Driver Class Initialized
DEBUG - 2011-06-26 00:41:39 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-06-26 00:41:39 --> Helper loaded: url_helper
DEBUG - 2011-06-26 00:41:39 --> File loaded: application/views/common/header.php
DEBUG - 2011-06-26 00:41:39 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-06-26 00:41:39 --> File loaded: application/views/common/footer.php
DEBUG - 2011-06-26 00:41:39 --> File loaded: application/views/layout/main.php
DEBUG - 2011-06-26 00:41:39 --> Final output sent to browser
DEBUG - 2011-06-26 00:41:39 --> Total execution time: 0.0269
DEBUG - 2011-06-26 00:41:40 --> Config Class Initialized
DEBUG - 2011-06-26 00:41:40 --> Hooks Class Initialized
DEBUG - 2011-06-26 00:41:40 --> Utf8 Class Initialized
DEBUG - 2011-06-26 00:41:40 --> UTF-8 Support Enabled
DEBUG - 2011-06-26 00:41:40 --> URI Class Initialized
DEBUG - 2011-06-26 00:41:40 --> Router Class Initialized
DEBUG - 2011-06-26 00:41:40 --> Output Class Initialized
DEBUG - 2011-06-26 00:41:40 --> Input Class Initialized
DEBUG - 2011-06-26 00:41:40 --> Global POST and COOKIE data sanitized
DEBUG - 2011-06-26 00:41:40 --> Language Class Initialized
DEBUG - 2011-06-26 00:41:40 --> Loader Class Initialized
DEBUG - 2011-06-26 00:41:40 --> Controller Class Initialized
DEBUG - 2011-06-26 00:41:40 --> Model Class Initialized
DEBUG - 2011-06-26 00:41:40 --> Model Class Initialized
DEBUG - 2011-06-26 00:41:40 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-06-26 00:41:40 --> Database Driver Class Initialized
DEBUG - 2011-06-26 00:41:41 --> Final output sent to browser
DEBUG - 2011-06-26 00:41:41 --> Total execution time: 0.8253
DEBUG - 2011-06-26 00:41:42 --> Config Class Initialized
DEBUG - 2011-06-26 00:41:42 --> Hooks Class Initialized
DEBUG - 2011-06-26 00:41:42 --> Utf8 Class Initialized
DEBUG - 2011-06-26 00:41:42 --> UTF-8 Support Enabled
DEBUG - 2011-06-26 00:41:42 --> URI Class Initialized
DEBUG - 2011-06-26 00:41:42 --> Router Class Initialized
DEBUG - 2011-06-26 00:41:42 --> Output Class Initialized
DEBUG - 2011-06-26 00:41:42 --> Input Class Initialized
DEBUG - 2011-06-26 00:41:42 --> Global POST and COOKIE data sanitized
DEBUG - 2011-06-26 00:41:42 --> Language Class Initialized
DEBUG - 2011-06-26 00:41:42 --> Loader Class Initialized
DEBUG - 2011-06-26 00:41:42 --> Controller Class Initialized
ERROR - 2011-06-26 00:41:42 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-06-26 00:41:42 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-06-26 00:41:42 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-06-26 00:41:42 --> Model Class Initialized
DEBUG - 2011-06-26 00:41:42 --> Model Class Initialized
DEBUG - 2011-06-26 00:41:42 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-06-26 00:41:42 --> Database Driver Class Initialized
DEBUG - 2011-06-26 00:41:42 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-06-26 00:41:42 --> Helper loaded: url_helper
DEBUG - 2011-06-26 00:41:42 --> File loaded: application/views/common/header.php
DEBUG - 2011-06-26 00:41:42 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-06-26 00:41:42 --> File loaded: application/views/common/footer.php
DEBUG - 2011-06-26 00:41:42 --> File loaded: application/views/layout/main.php
DEBUG - 2011-06-26 00:41:42 --> Final output sent to browser
DEBUG - 2011-06-26 00:41:42 --> Total execution time: 0.0278
DEBUG - 2011-06-26 00:41:42 --> Config Class Initialized
DEBUG - 2011-06-26 00:41:42 --> Hooks Class Initialized
DEBUG - 2011-06-26 00:41:42 --> Utf8 Class Initialized
DEBUG - 2011-06-26 00:41:42 --> UTF-8 Support Enabled
DEBUG - 2011-06-26 00:41:42 --> URI Class Initialized
DEBUG - 2011-06-26 00:41:42 --> Router Class Initialized
DEBUG - 2011-06-26 00:41:42 --> Output Class Initialized
DEBUG - 2011-06-26 00:41:42 --> Input Class Initialized
DEBUG - 2011-06-26 00:41:42 --> Global POST and COOKIE data sanitized
DEBUG - 2011-06-26 00:41:42 --> Language Class Initialized
DEBUG - 2011-06-26 00:41:42 --> Loader Class Initialized
DEBUG - 2011-06-26 00:41:42 --> Controller Class Initialized
ERROR - 2011-06-26 00:41:42 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-06-26 00:41:42 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-06-26 00:41:42 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-06-26 00:41:42 --> Model Class Initialized
DEBUG - 2011-06-26 00:41:42 --> Model Class Initialized
DEBUG - 2011-06-26 00:41:42 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-06-26 00:41:42 --> Database Driver Class Initialized
DEBUG - 2011-06-26 00:41:42 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-06-26 00:41:42 --> Helper loaded: url_helper
DEBUG - 2011-06-26 00:41:42 --> File loaded: application/views/common/header.php
DEBUG - 2011-06-26 00:41:42 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-06-26 00:41:42 --> File loaded: application/views/common/footer.php
DEBUG - 2011-06-26 00:41:42 --> File loaded: application/views/layout/main.php
DEBUG - 2011-06-26 00:41:42 --> Final output sent to browser
DEBUG - 2011-06-26 00:41:42 --> Total execution time: 0.0298
DEBUG - 2011-06-26 00:41:43 --> Config Class Initialized
DEBUG - 2011-06-26 00:41:43 --> Hooks Class Initialized
DEBUG - 2011-06-26 00:41:43 --> Utf8 Class Initialized
DEBUG - 2011-06-26 00:41:43 --> UTF-8 Support Enabled
DEBUG - 2011-06-26 00:41:43 --> URI Class Initialized
DEBUG - 2011-06-26 00:41:43 --> Router Class Initialized
ERROR - 2011-06-26 00:41:43 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-06-26 00:41:48 --> Config Class Initialized
DEBUG - 2011-06-26 00:41:48 --> Hooks Class Initialized
DEBUG - 2011-06-26 00:41:48 --> Utf8 Class Initialized
DEBUG - 2011-06-26 00:41:48 --> UTF-8 Support Enabled
DEBUG - 2011-06-26 00:41:48 --> URI Class Initialized
DEBUG - 2011-06-26 00:41:48 --> Router Class Initialized
DEBUG - 2011-06-26 00:41:48 --> Output Class Initialized
DEBUG - 2011-06-26 00:41:48 --> Input Class Initialized
DEBUG - 2011-06-26 00:41:48 --> Global POST and COOKIE data sanitized
DEBUG - 2011-06-26 00:41:48 --> Language Class Initialized
DEBUG - 2011-06-26 00:41:48 --> Loader Class Initialized
DEBUG - 2011-06-26 00:41:48 --> Controller Class Initialized
ERROR - 2011-06-26 00:41:48 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-06-26 00:41:48 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-06-26 00:41:48 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-06-26 00:41:48 --> Model Class Initialized
DEBUG - 2011-06-26 00:41:48 --> Model Class Initialized
DEBUG - 2011-06-26 00:41:48 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-06-26 00:41:48 --> Database Driver Class Initialized
DEBUG - 2011-06-26 00:41:48 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-06-26 00:41:48 --> Helper loaded: url_helper
DEBUG - 2011-06-26 00:41:48 --> File loaded: application/views/common/header.php
DEBUG - 2011-06-26 00:41:48 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-06-26 00:41:48 --> File loaded: application/views/common/footer.php
DEBUG - 2011-06-26 00:41:48 --> File loaded: application/views/layout/main.php
DEBUG - 2011-06-26 00:41:48 --> Final output sent to browser
DEBUG - 2011-06-26 00:41:48 --> Total execution time: 0.0266
DEBUG - 2011-06-26 00:41:49 --> Config Class Initialized
DEBUG - 2011-06-26 00:41:49 --> Hooks Class Initialized
DEBUG - 2011-06-26 00:41:49 --> Utf8 Class Initialized
DEBUG - 2011-06-26 00:41:49 --> UTF-8 Support Enabled
DEBUG - 2011-06-26 00:41:49 --> URI Class Initialized
DEBUG - 2011-06-26 00:41:49 --> Router Class Initialized
DEBUG - 2011-06-26 00:41:49 --> Output Class Initialized
DEBUG - 2011-06-26 00:41:49 --> Input Class Initialized
DEBUG - 2011-06-26 00:41:49 --> Global POST and COOKIE data sanitized
DEBUG - 2011-06-26 00:41:49 --> Language Class Initialized
DEBUG - 2011-06-26 00:41:49 --> Loader Class Initialized
DEBUG - 2011-06-26 00:41:49 --> Controller Class Initialized
DEBUG - 2011-06-26 00:41:49 --> Model Class Initialized
DEBUG - 2011-06-26 00:41:49 --> Model Class Initialized
DEBUG - 2011-06-26 00:41:49 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-06-26 00:41:49 --> Database Driver Class Initialized
DEBUG - 2011-06-26 00:41:49 --> Config Class Initialized
DEBUG - 2011-06-26 00:41:49 --> Hooks Class Initialized
DEBUG - 2011-06-26 00:41:49 --> Utf8 Class Initialized
DEBUG - 2011-06-26 00:41:49 --> UTF-8 Support Enabled
DEBUG - 2011-06-26 00:41:49 --> URI Class Initialized
DEBUG - 2011-06-26 00:41:49 --> Router Class Initialized
DEBUG - 2011-06-26 00:41:49 --> Output Class Initialized
DEBUG - 2011-06-26 00:41:49 --> Input Class Initialized
DEBUG - 2011-06-26 00:41:49 --> Global POST and COOKIE data sanitized
DEBUG - 2011-06-26 00:41:49 --> Language Class Initialized
DEBUG - 2011-06-26 00:41:49 --> Loader Class Initialized
DEBUG - 2011-06-26 00:41:49 --> Controller Class Initialized
ERROR - 2011-06-26 00:41:49 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-06-26 00:41:49 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-06-26 00:41:49 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-06-26 00:41:49 --> Model Class Initialized
DEBUG - 2011-06-26 00:41:49 --> Model Class Initialized
DEBUG - 2011-06-26 00:41:49 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-06-26 00:41:49 --> Database Driver Class Initialized
DEBUG - 2011-06-26 00:41:49 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-06-26 00:41:49 --> Helper loaded: url_helper
DEBUG - 2011-06-26 00:41:49 --> File loaded: application/views/common/header.php
DEBUG - 2011-06-26 00:41:49 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-06-26 00:41:49 --> File loaded: application/views/common/footer.php
DEBUG - 2011-06-26 00:41:49 --> File loaded: application/views/layout/main.php
DEBUG - 2011-06-26 00:41:49 --> Final output sent to browser
DEBUG - 2011-06-26 00:41:49 --> Total execution time: 0.0298
DEBUG - 2011-06-26 00:41:49 --> Final output sent to browser
DEBUG - 2011-06-26 00:41:49 --> Total execution time: 0.5370
DEBUG - 2011-06-26 00:41:53 --> Config Class Initialized
DEBUG - 2011-06-26 00:41:53 --> Hooks Class Initialized
DEBUG - 2011-06-26 00:41:53 --> Utf8 Class Initialized
DEBUG - 2011-06-26 00:41:53 --> UTF-8 Support Enabled
DEBUG - 2011-06-26 00:41:53 --> URI Class Initialized
DEBUG - 2011-06-26 00:41:53 --> Router Class Initialized
ERROR - 2011-06-26 00:41:53 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-06-26 00:42:11 --> Config Class Initialized
DEBUG - 2011-06-26 00:42:11 --> Hooks Class Initialized
DEBUG - 2011-06-26 00:42:11 --> Utf8 Class Initialized
DEBUG - 2011-06-26 00:42:11 --> UTF-8 Support Enabled
DEBUG - 2011-06-26 00:42:11 --> URI Class Initialized
DEBUG - 2011-06-26 00:42:11 --> Router Class Initialized
DEBUG - 2011-06-26 00:42:11 --> Output Class Initialized
DEBUG - 2011-06-26 00:42:11 --> Input Class Initialized
DEBUG - 2011-06-26 00:42:11 --> Global POST and COOKIE data sanitized
DEBUG - 2011-06-26 00:42:11 --> Language Class Initialized
DEBUG - 2011-06-26 00:42:11 --> Loader Class Initialized
DEBUG - 2011-06-26 00:42:11 --> Controller Class Initialized
ERROR - 2011-06-26 00:42:11 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-06-26 00:42:11 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-06-26 00:42:11 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-06-26 00:42:11 --> Model Class Initialized
DEBUG - 2011-06-26 00:42:11 --> Model Class Initialized
DEBUG - 2011-06-26 00:42:11 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-06-26 00:42:11 --> Database Driver Class Initialized
DEBUG - 2011-06-26 00:42:11 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-06-26 00:42:11 --> Helper loaded: url_helper
DEBUG - 2011-06-26 00:42:11 --> File loaded: application/views/common/header.php
DEBUG - 2011-06-26 00:42:11 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-06-26 00:42:11 --> File loaded: application/views/common/footer.php
DEBUG - 2011-06-26 00:42:11 --> File loaded: application/views/layout/main.php
DEBUG - 2011-06-26 00:42:11 --> Final output sent to browser
DEBUG - 2011-06-26 00:42:11 --> Total execution time: 0.0345
DEBUG - 2011-06-26 00:42:12 --> Config Class Initialized
DEBUG - 2011-06-26 00:42:12 --> Hooks Class Initialized
DEBUG - 2011-06-26 00:42:12 --> Utf8 Class Initialized
DEBUG - 2011-06-26 00:42:12 --> UTF-8 Support Enabled
DEBUG - 2011-06-26 00:42:12 --> URI Class Initialized
DEBUG - 2011-06-26 00:42:12 --> Router Class Initialized
DEBUG - 2011-06-26 00:42:12 --> Output Class Initialized
DEBUG - 2011-06-26 00:42:12 --> Input Class Initialized
DEBUG - 2011-06-26 00:42:12 --> Global POST and COOKIE data sanitized
DEBUG - 2011-06-26 00:42:12 --> Language Class Initialized
DEBUG - 2011-06-26 00:42:12 --> Loader Class Initialized
DEBUG - 2011-06-26 00:42:12 --> Controller Class Initialized
DEBUG - 2011-06-26 00:42:12 --> Model Class Initialized
DEBUG - 2011-06-26 00:42:12 --> Model Class Initialized
DEBUG - 2011-06-26 00:42:12 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-06-26 00:42:12 --> Database Driver Class Initialized
DEBUG - 2011-06-26 00:42:12 --> Final output sent to browser
DEBUG - 2011-06-26 00:42:12 --> Total execution time: 0.7899
DEBUG - 2011-06-26 00:42:13 --> Config Class Initialized
DEBUG - 2011-06-26 00:42:13 --> Hooks Class Initialized
DEBUG - 2011-06-26 00:42:13 --> Utf8 Class Initialized
DEBUG - 2011-06-26 00:42:13 --> UTF-8 Support Enabled
DEBUG - 2011-06-26 00:42:13 --> URI Class Initialized
DEBUG - 2011-06-26 00:42:13 --> Router Class Initialized
ERROR - 2011-06-26 00:42:13 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-06-26 00:42:17 --> Config Class Initialized
DEBUG - 2011-06-26 00:42:17 --> Hooks Class Initialized
DEBUG - 2011-06-26 00:42:17 --> Utf8 Class Initialized
DEBUG - 2011-06-26 00:42:17 --> UTF-8 Support Enabled
DEBUG - 2011-06-26 00:42:17 --> URI Class Initialized
DEBUG - 2011-06-26 00:42:17 --> Router Class Initialized
DEBUG - 2011-06-26 00:42:17 --> Output Class Initialized
DEBUG - 2011-06-26 00:42:17 --> Input Class Initialized
DEBUG - 2011-06-26 00:42:17 --> Global POST and COOKIE data sanitized
DEBUG - 2011-06-26 00:42:17 --> Language Class Initialized
DEBUG - 2011-06-26 00:42:17 --> Loader Class Initialized
DEBUG - 2011-06-26 00:42:17 --> Controller Class Initialized
ERROR - 2011-06-26 00:42:17 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-06-26 00:42:17 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-06-26 00:42:17 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-06-26 00:42:17 --> Model Class Initialized
DEBUG - 2011-06-26 00:42:17 --> Model Class Initialized
DEBUG - 2011-06-26 00:42:17 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-06-26 00:42:17 --> Database Driver Class Initialized
DEBUG - 2011-06-26 00:42:17 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-06-26 00:42:17 --> Helper loaded: url_helper
DEBUG - 2011-06-26 00:42:17 --> File loaded: application/views/common/header.php
DEBUG - 2011-06-26 00:42:17 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-06-26 00:42:17 --> File loaded: application/views/common/footer.php
DEBUG - 2011-06-26 00:42:17 --> File loaded: application/views/layout/main.php
DEBUG - 2011-06-26 00:42:17 --> Final output sent to browser
DEBUG - 2011-06-26 00:42:17 --> Total execution time: 0.0278
DEBUG - 2011-06-26 00:42:18 --> Config Class Initialized
DEBUG - 2011-06-26 00:42:18 --> Hooks Class Initialized
DEBUG - 2011-06-26 00:42:18 --> Utf8 Class Initialized
DEBUG - 2011-06-26 00:42:18 --> UTF-8 Support Enabled
DEBUG - 2011-06-26 00:42:18 --> URI Class Initialized
DEBUG - 2011-06-26 00:42:18 --> Router Class Initialized
DEBUG - 2011-06-26 00:42:18 --> Output Class Initialized
DEBUG - 2011-06-26 00:42:18 --> Input Class Initialized
DEBUG - 2011-06-26 00:42:18 --> Global POST and COOKIE data sanitized
DEBUG - 2011-06-26 00:42:18 --> Language Class Initialized
DEBUG - 2011-06-26 00:42:18 --> Loader Class Initialized
DEBUG - 2011-06-26 00:42:18 --> Controller Class Initialized
DEBUG - 2011-06-26 00:42:18 --> Model Class Initialized
DEBUG - 2011-06-26 00:42:18 --> Model Class Initialized
DEBUG - 2011-06-26 00:42:18 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-06-26 00:42:18 --> Database Driver Class Initialized
DEBUG - 2011-06-26 00:42:18 --> Final output sent to browser
DEBUG - 2011-06-26 00:42:18 --> Total execution time: 0.6553
DEBUG - 2011-06-26 00:42:20 --> Config Class Initialized
DEBUG - 2011-06-26 00:42:20 --> Hooks Class Initialized
DEBUG - 2011-06-26 00:42:20 --> Utf8 Class Initialized
DEBUG - 2011-06-26 00:42:20 --> UTF-8 Support Enabled
DEBUG - 2011-06-26 00:42:20 --> URI Class Initialized
DEBUG - 2011-06-26 00:42:20 --> Router Class Initialized
ERROR - 2011-06-26 00:42:20 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-06-26 01:30:19 --> Config Class Initialized
DEBUG - 2011-06-26 01:30:19 --> Hooks Class Initialized
DEBUG - 2011-06-26 01:30:19 --> Utf8 Class Initialized
DEBUG - 2011-06-26 01:30:19 --> UTF-8 Support Enabled
DEBUG - 2011-06-26 01:30:19 --> URI Class Initialized
DEBUG - 2011-06-26 01:30:19 --> Router Class Initialized
DEBUG - 2011-06-26 01:30:19 --> Output Class Initialized
DEBUG - 2011-06-26 01:30:19 --> Input Class Initialized
DEBUG - 2011-06-26 01:30:19 --> Global POST and COOKIE data sanitized
DEBUG - 2011-06-26 01:30:19 --> Language Class Initialized
DEBUG - 2011-06-26 01:30:19 --> Loader Class Initialized
DEBUG - 2011-06-26 01:30:19 --> Controller Class Initialized
DEBUG - 2011-06-26 01:30:19 --> Model Class Initialized
DEBUG - 2011-06-26 01:30:19 --> Model Class Initialized
DEBUG - 2011-06-26 01:30:19 --> Model Class Initialized
DEBUG - 2011-06-26 01:30:19 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-06-26 01:30:19 --> Database Driver Class Initialized
DEBUG - 2011-06-26 01:30:19 --> File loaded: application/views/table/main.php
DEBUG - 2011-06-26 01:30:20 --> Helper loaded: url_helper
DEBUG - 2011-06-26 01:30:20 --> File loaded: application/views/common/header.php
DEBUG - 2011-06-26 01:30:20 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-06-26 01:30:20 --> File loaded: application/views/common/footer.php
DEBUG - 2011-06-26 01:30:20 --> File loaded: application/views/layout/main.php
DEBUG - 2011-06-26 01:30:20 --> Final output sent to browser
DEBUG - 2011-06-26 01:30:20 --> Total execution time: 0.4602
DEBUG - 2011-06-26 01:30:22 --> Config Class Initialized
DEBUG - 2011-06-26 01:30:22 --> Hooks Class Initialized
DEBUG - 2011-06-26 01:30:22 --> Utf8 Class Initialized
DEBUG - 2011-06-26 01:30:22 --> UTF-8 Support Enabled
DEBUG - 2011-06-26 01:30:22 --> URI Class Initialized
DEBUG - 2011-06-26 01:30:22 --> Router Class Initialized
ERROR - 2011-06-26 01:30:22 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-06-26 01:30:39 --> Config Class Initialized
DEBUG - 2011-06-26 01:30:39 --> Hooks Class Initialized
DEBUG - 2011-06-26 01:30:39 --> Utf8 Class Initialized
DEBUG - 2011-06-26 01:30:39 --> UTF-8 Support Enabled
DEBUG - 2011-06-26 01:30:39 --> URI Class Initialized
DEBUG - 2011-06-26 01:30:39 --> Router Class Initialized
DEBUG - 2011-06-26 01:30:39 --> Output Class Initialized
DEBUG - 2011-06-26 01:30:39 --> Input Class Initialized
DEBUG - 2011-06-26 01:30:39 --> Global POST and COOKIE data sanitized
DEBUG - 2011-06-26 01:30:39 --> Language Class Initialized
DEBUG - 2011-06-26 01:30:39 --> Loader Class Initialized
DEBUG - 2011-06-26 01:30:39 --> Controller Class Initialized
DEBUG - 2011-06-26 01:30:39 --> Model Class Initialized
DEBUG - 2011-06-26 01:30:39 --> Model Class Initialized
DEBUG - 2011-06-26 01:30:39 --> Model Class Initialized
DEBUG - 2011-06-26 01:30:39 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-06-26 01:30:39 --> Database Driver Class Initialized
DEBUG - 2011-06-26 01:30:39 --> File loaded: application/views/table/main.php
DEBUG - 2011-06-26 01:30:39 --> Helper loaded: url_helper
DEBUG - 2011-06-26 01:30:39 --> File loaded: application/views/common/header.php
DEBUG - 2011-06-26 01:30:39 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-06-26 01:30:39 --> File loaded: application/views/common/footer.php
DEBUG - 2011-06-26 01:30:39 --> File loaded: application/views/layout/main.php
DEBUG - 2011-06-26 01:30:39 --> Final output sent to browser
DEBUG - 2011-06-26 01:30:39 --> Total execution time: 0.0437
DEBUG - 2011-06-26 02:16:23 --> Config Class Initialized
DEBUG - 2011-06-26 02:16:23 --> Hooks Class Initialized
DEBUG - 2011-06-26 02:16:23 --> Utf8 Class Initialized
DEBUG - 2011-06-26 02:16:23 --> UTF-8 Support Enabled
DEBUG - 2011-06-26 02:16:23 --> URI Class Initialized
DEBUG - 2011-06-26 02:16:23 --> Router Class Initialized
DEBUG - 2011-06-26 02:16:24 --> Output Class Initialized
DEBUG - 2011-06-26 02:16:24 --> Input Class Initialized
DEBUG - 2011-06-26 02:16:24 --> Global POST and COOKIE data sanitized
DEBUG - 2011-06-26 02:16:24 --> Language Class Initialized
DEBUG - 2011-06-26 02:16:24 --> Loader Class Initialized
DEBUG - 2011-06-26 02:16:24 --> Controller Class Initialized
DEBUG - 2011-06-26 02:16:24 --> Model Class Initialized
DEBUG - 2011-06-26 02:16:24 --> Model Class Initialized
DEBUG - 2011-06-26 02:16:24 --> Model Class Initialized
DEBUG - 2011-06-26 02:16:25 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-06-26 02:16:26 --> Database Driver Class Initialized
DEBUG - 2011-06-26 02:16:30 --> File loaded: application/views/table/main.php
DEBUG - 2011-06-26 02:16:30 --> Helper loaded: url_helper
DEBUG - 2011-06-26 02:16:30 --> File loaded: application/views/common/header.php
DEBUG - 2011-06-26 02:16:30 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-06-26 02:16:30 --> File loaded: application/views/common/footer.php
DEBUG - 2011-06-26 02:16:30 --> File loaded: application/views/layout/main.php
DEBUG - 2011-06-26 02:16:30 --> Final output sent to browser
DEBUG - 2011-06-26 02:16:30 --> Total execution time: 7.1622
DEBUG - 2011-06-26 02:16:33 --> Config Class Initialized
DEBUG - 2011-06-26 02:16:33 --> Hooks Class Initialized
DEBUG - 2011-06-26 02:16:33 --> Utf8 Class Initialized
DEBUG - 2011-06-26 02:16:33 --> UTF-8 Support Enabled
DEBUG - 2011-06-26 02:16:33 --> URI Class Initialized
DEBUG - 2011-06-26 02:16:33 --> Router Class Initialized
ERROR - 2011-06-26 02:16:33 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-06-26 02:16:34 --> Config Class Initialized
DEBUG - 2011-06-26 02:16:34 --> Hooks Class Initialized
DEBUG - 2011-06-26 02:16:34 --> Utf8 Class Initialized
DEBUG - 2011-06-26 02:16:34 --> UTF-8 Support Enabled
DEBUG - 2011-06-26 02:16:34 --> URI Class Initialized
DEBUG - 2011-06-26 02:16:34 --> Router Class Initialized
ERROR - 2011-06-26 02:16:34 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-06-26 02:16:34 --> Config Class Initialized
DEBUG - 2011-06-26 02:16:34 --> Hooks Class Initialized
DEBUG - 2011-06-26 02:16:34 --> Utf8 Class Initialized
DEBUG - 2011-06-26 02:16:34 --> UTF-8 Support Enabled
DEBUG - 2011-06-26 02:16:34 --> URI Class Initialized
DEBUG - 2011-06-26 02:16:34 --> Router Class Initialized
ERROR - 2011-06-26 02:16:34 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-06-26 02:16:41 --> Config Class Initialized
DEBUG - 2011-06-26 02:16:41 --> Hooks Class Initialized
DEBUG - 2011-06-26 02:16:41 --> Utf8 Class Initialized
DEBUG - 2011-06-26 02:16:41 --> UTF-8 Support Enabled
DEBUG - 2011-06-26 02:16:41 --> URI Class Initialized
DEBUG - 2011-06-26 02:16:41 --> Router Class Initialized
DEBUG - 2011-06-26 02:16:41 --> Output Class Initialized
DEBUG - 2011-06-26 02:16:41 --> Input Class Initialized
DEBUG - 2011-06-26 02:16:41 --> Global POST and COOKIE data sanitized
DEBUG - 2011-06-26 02:16:41 --> Language Class Initialized
DEBUG - 2011-06-26 02:16:41 --> Loader Class Initialized
DEBUG - 2011-06-26 02:16:41 --> Controller Class Initialized
DEBUG - 2011-06-26 02:16:41 --> Model Class Initialized
DEBUG - 2011-06-26 02:16:41 --> Model Class Initialized
DEBUG - 2011-06-26 02:16:41 --> Model Class Initialized
DEBUG - 2011-06-26 02:16:41 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-06-26 02:16:41 --> Database Driver Class Initialized
DEBUG - 2011-06-26 02:16:45 --> File loaded: application/views/table/main.php
DEBUG - 2011-06-26 02:16:45 --> Helper loaded: url_helper
DEBUG - 2011-06-26 02:16:45 --> File loaded: application/views/common/header.php
DEBUG - 2011-06-26 02:16:45 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-06-26 02:16:45 --> File loaded: application/views/common/footer.php
DEBUG - 2011-06-26 02:16:45 --> File loaded: application/views/layout/main.php
DEBUG - 2011-06-26 02:16:45 --> Final output sent to browser
DEBUG - 2011-06-26 02:16:45 --> Total execution time: 4.2492
DEBUG - 2011-06-26 02:17:01 --> Config Class Initialized
DEBUG - 2011-06-26 02:17:01 --> Hooks Class Initialized
DEBUG - 2011-06-26 02:17:01 --> Utf8 Class Initialized
DEBUG - 2011-06-26 02:17:01 --> UTF-8 Support Enabled
DEBUG - 2011-06-26 02:17:01 --> URI Class Initialized
DEBUG - 2011-06-26 02:17:01 --> Router Class Initialized
DEBUG - 2011-06-26 02:17:01 --> Output Class Initialized
DEBUG - 2011-06-26 02:17:01 --> Input Class Initialized
DEBUG - 2011-06-26 02:17:01 --> Global POST and COOKIE data sanitized
DEBUG - 2011-06-26 02:17:01 --> Language Class Initialized
DEBUG - 2011-06-26 02:17:01 --> Loader Class Initialized
DEBUG - 2011-06-26 02:17:01 --> Controller Class Initialized
DEBUG - 2011-06-26 02:17:01 --> Model Class Initialized
DEBUG - 2011-06-26 02:17:01 --> Model Class Initialized
DEBUG - 2011-06-26 02:17:01 --> Model Class Initialized
DEBUG - 2011-06-26 02:17:01 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-06-26 02:17:01 --> Database Driver Class Initialized
DEBUG - 2011-06-26 02:17:01 --> File loaded: application/views/table/main.php
DEBUG - 2011-06-26 02:17:01 --> Helper loaded: url_helper
DEBUG - 2011-06-26 02:17:01 --> File loaded: application/views/common/header.php
DEBUG - 2011-06-26 02:17:01 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-06-26 02:17:01 --> File loaded: application/views/common/footer.php
DEBUG - 2011-06-26 02:17:01 --> File loaded: application/views/layout/main.php
DEBUG - 2011-06-26 02:17:01 --> Final output sent to browser
DEBUG - 2011-06-26 02:17:01 --> Total execution time: 0.5090
DEBUG - 2011-06-26 02:17:25 --> Config Class Initialized
DEBUG - 2011-06-26 02:17:25 --> Hooks Class Initialized
DEBUG - 2011-06-26 02:17:25 --> Utf8 Class Initialized
DEBUG - 2011-06-26 02:17:25 --> UTF-8 Support Enabled
DEBUG - 2011-06-26 02:17:25 --> URI Class Initialized
DEBUG - 2011-06-26 02:17:25 --> Router Class Initialized
DEBUG - 2011-06-26 02:17:25 --> Output Class Initialized
DEBUG - 2011-06-26 02:17:25 --> Input Class Initialized
DEBUG - 2011-06-26 02:17:25 --> Global POST and COOKIE data sanitized
DEBUG - 2011-06-26 02:17:25 --> Language Class Initialized
DEBUG - 2011-06-26 02:17:25 --> Loader Class Initialized
DEBUG - 2011-06-26 02:17:25 --> Controller Class Initialized
DEBUG - 2011-06-26 02:17:25 --> Model Class Initialized
DEBUG - 2011-06-26 02:17:25 --> Model Class Initialized
DEBUG - 2011-06-26 02:17:25 --> Model Class Initialized
DEBUG - 2011-06-26 02:17:25 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-06-26 02:17:25 --> Database Driver Class Initialized
DEBUG - 2011-06-26 02:17:28 --> File loaded: application/views/table/main.php
DEBUG - 2011-06-26 02:17:28 --> Helper loaded: url_helper
DEBUG - 2011-06-26 02:17:28 --> File loaded: application/views/common/header.php
DEBUG - 2011-06-26 02:17:28 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-06-26 02:17:28 --> File loaded: application/views/common/footer.php
DEBUG - 2011-06-26 02:17:28 --> File loaded: application/views/layout/main.php
DEBUG - 2011-06-26 02:17:28 --> Final output sent to browser
DEBUG - 2011-06-26 02:17:28 --> Total execution time: 2.7092
DEBUG - 2011-06-26 02:17:43 --> Config Class Initialized
DEBUG - 2011-06-26 02:17:43 --> Hooks Class Initialized
DEBUG - 2011-06-26 02:17:43 --> Utf8 Class Initialized
DEBUG - 2011-06-26 02:17:43 --> UTF-8 Support Enabled
DEBUG - 2011-06-26 02:17:43 --> URI Class Initialized
DEBUG - 2011-06-26 02:17:43 --> Router Class Initialized
DEBUG - 2011-06-26 02:17:43 --> Output Class Initialized
DEBUG - 2011-06-26 02:17:43 --> Input Class Initialized
DEBUG - 2011-06-26 02:17:43 --> Global POST and COOKIE data sanitized
DEBUG - 2011-06-26 02:17:43 --> Language Class Initialized
DEBUG - 2011-06-26 02:17:43 --> Loader Class Initialized
DEBUG - 2011-06-26 02:17:43 --> Controller Class Initialized
DEBUG - 2011-06-26 02:17:43 --> Model Class Initialized
DEBUG - 2011-06-26 02:17:43 --> Model Class Initialized
DEBUG - 2011-06-26 02:17:43 --> Model Class Initialized
DEBUG - 2011-06-26 02:17:43 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-06-26 02:17:43 --> Database Driver Class Initialized
DEBUG - 2011-06-26 02:17:43 --> File loaded: application/views/table/main.php
DEBUG - 2011-06-26 02:17:43 --> Helper loaded: url_helper
DEBUG - 2011-06-26 02:17:43 --> File loaded: application/views/common/header.php
DEBUG - 2011-06-26 02:17:43 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-06-26 02:17:43 --> File loaded: application/views/common/footer.php
DEBUG - 2011-06-26 02:17:43 --> File loaded: application/views/layout/main.php
DEBUG - 2011-06-26 02:17:43 --> Final output sent to browser
DEBUG - 2011-06-26 02:17:43 --> Total execution time: 0.6729
DEBUG - 2011-06-26 02:17:52 --> Config Class Initialized
DEBUG - 2011-06-26 02:17:52 --> Hooks Class Initialized
DEBUG - 2011-06-26 02:17:52 --> Utf8 Class Initialized
DEBUG - 2011-06-26 02:17:52 --> UTF-8 Support Enabled
DEBUG - 2011-06-26 02:17:52 --> URI Class Initialized
DEBUG - 2011-06-26 02:17:52 --> Router Class Initialized
DEBUG - 2011-06-26 02:17:52 --> Output Class Initialized
DEBUG - 2011-06-26 02:17:52 --> Input Class Initialized
DEBUG - 2011-06-26 02:17:52 --> Global POST and COOKIE data sanitized
DEBUG - 2011-06-26 02:17:52 --> Language Class Initialized
DEBUG - 2011-06-26 02:17:52 --> Loader Class Initialized
DEBUG - 2011-06-26 02:17:52 --> Controller Class Initialized
DEBUG - 2011-06-26 02:17:52 --> Model Class Initialized
DEBUG - 2011-06-26 02:17:52 --> Model Class Initialized
DEBUG - 2011-06-26 02:17:52 --> Model Class Initialized
DEBUG - 2011-06-26 02:17:52 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-06-26 02:17:52 --> Database Driver Class Initialized
DEBUG - 2011-06-26 02:17:56 --> File loaded: application/views/table/main.php
DEBUG - 2011-06-26 02:17:56 --> Helper loaded: url_helper
DEBUG - 2011-06-26 02:17:56 --> File loaded: application/views/common/header.php
DEBUG - 2011-06-26 02:17:56 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-06-26 02:17:56 --> File loaded: application/views/common/footer.php
DEBUG - 2011-06-26 02:17:56 --> File loaded: application/views/layout/main.php
DEBUG - 2011-06-26 02:17:56 --> Final output sent to browser
DEBUG - 2011-06-26 02:17:56 --> Total execution time: 3.5820
DEBUG - 2011-06-26 02:18:08 --> Config Class Initialized
DEBUG - 2011-06-26 02:18:08 --> Hooks Class Initialized
DEBUG - 2011-06-26 02:18:08 --> Utf8 Class Initialized
DEBUG - 2011-06-26 02:18:08 --> UTF-8 Support Enabled
DEBUG - 2011-06-26 02:18:08 --> URI Class Initialized
DEBUG - 2011-06-26 02:18:08 --> Router Class Initialized
DEBUG - 2011-06-26 02:18:08 --> Output Class Initialized
DEBUG - 2011-06-26 02:18:08 --> Input Class Initialized
DEBUG - 2011-06-26 02:18:08 --> Global POST and COOKIE data sanitized
DEBUG - 2011-06-26 02:18:08 --> Language Class Initialized
DEBUG - 2011-06-26 02:18:08 --> Loader Class Initialized
DEBUG - 2011-06-26 02:18:08 --> Controller Class Initialized
DEBUG - 2011-06-26 02:18:08 --> Model Class Initialized
DEBUG - 2011-06-26 02:18:08 --> Model Class Initialized
DEBUG - 2011-06-26 02:18:08 --> Model Class Initialized
DEBUG - 2011-06-26 02:18:08 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-06-26 02:18:08 --> Database Driver Class Initialized
DEBUG - 2011-06-26 02:18:09 --> File loaded: application/views/table/main.php
DEBUG - 2011-06-26 02:18:09 --> Helper loaded: url_helper
DEBUG - 2011-06-26 02:18:09 --> File loaded: application/views/common/header.php
DEBUG - 2011-06-26 02:18:09 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-06-26 02:18:09 --> File loaded: application/views/common/footer.php
DEBUG - 2011-06-26 02:18:09 --> File loaded: application/views/layout/main.php
DEBUG - 2011-06-26 02:18:09 --> Final output sent to browser
DEBUG - 2011-06-26 02:18:09 --> Total execution time: 0.7761
DEBUG - 2011-06-26 02:18:26 --> Config Class Initialized
DEBUG - 2011-06-26 02:18:26 --> Hooks Class Initialized
DEBUG - 2011-06-26 02:18:26 --> Utf8 Class Initialized
DEBUG - 2011-06-26 02:18:26 --> UTF-8 Support Enabled
DEBUG - 2011-06-26 02:18:26 --> URI Class Initialized
DEBUG - 2011-06-26 02:18:26 --> Router Class Initialized
DEBUG - 2011-06-26 02:18:26 --> Output Class Initialized
DEBUG - 2011-06-26 02:18:26 --> Input Class Initialized
DEBUG - 2011-06-26 02:18:26 --> Global POST and COOKIE data sanitized
DEBUG - 2011-06-26 02:18:26 --> Language Class Initialized
DEBUG - 2011-06-26 02:18:26 --> Loader Class Initialized
DEBUG - 2011-06-26 02:18:26 --> Controller Class Initialized
DEBUG - 2011-06-26 02:18:26 --> Model Class Initialized
DEBUG - 2011-06-26 02:18:26 --> Model Class Initialized
DEBUG - 2011-06-26 02:18:26 --> Model Class Initialized
DEBUG - 2011-06-26 02:18:26 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-06-26 02:18:26 --> Database Driver Class Initialized
DEBUG - 2011-06-26 02:18:26 --> File loaded: application/views/table/main.php
DEBUG - 2011-06-26 02:18:26 --> Helper loaded: url_helper
DEBUG - 2011-06-26 02:18:26 --> File loaded: application/views/common/header.php
DEBUG - 2011-06-26 02:18:26 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-06-26 02:18:26 --> File loaded: application/views/common/footer.php
DEBUG - 2011-06-26 02:18:26 --> File loaded: application/views/layout/main.php
DEBUG - 2011-06-26 02:18:26 --> Final output sent to browser
DEBUG - 2011-06-26 02:18:26 --> Total execution time: 0.2454
DEBUG - 2011-06-26 02:18:38 --> Config Class Initialized
DEBUG - 2011-06-26 02:18:38 --> Hooks Class Initialized
DEBUG - 2011-06-26 02:18:38 --> Utf8 Class Initialized
DEBUG - 2011-06-26 02:18:38 --> UTF-8 Support Enabled
DEBUG - 2011-06-26 02:18:38 --> URI Class Initialized
DEBUG - 2011-06-26 02:18:38 --> Router Class Initialized
DEBUG - 2011-06-26 02:18:38 --> Output Class Initialized
DEBUG - 2011-06-26 02:18:38 --> Input Class Initialized
DEBUG - 2011-06-26 02:18:38 --> Global POST and COOKIE data sanitized
DEBUG - 2011-06-26 02:18:38 --> Language Class Initialized
DEBUG - 2011-06-26 02:18:38 --> Loader Class Initialized
DEBUG - 2011-06-26 02:18:38 --> Controller Class Initialized
DEBUG - 2011-06-26 02:18:38 --> Model Class Initialized
DEBUG - 2011-06-26 02:18:38 --> Model Class Initialized
DEBUG - 2011-06-26 02:18:38 --> Model Class Initialized
DEBUG - 2011-06-26 02:18:38 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-06-26 02:18:38 --> Database Driver Class Initialized
DEBUG - 2011-06-26 02:18:46 --> File loaded: application/views/table/main.php
DEBUG - 2011-06-26 02:18:46 --> Helper loaded: url_helper
DEBUG - 2011-06-26 02:18:46 --> File loaded: application/views/common/header.php
DEBUG - 2011-06-26 02:18:46 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-06-26 02:18:46 --> File loaded: application/views/common/footer.php
DEBUG - 2011-06-26 02:18:46 --> File loaded: application/views/layout/main.php
DEBUG - 2011-06-26 02:18:46 --> Final output sent to browser
DEBUG - 2011-06-26 02:18:46 --> Total execution time: 7.7141
DEBUG - 2011-06-26 02:19:23 --> Config Class Initialized
DEBUG - 2011-06-26 02:19:23 --> Hooks Class Initialized
DEBUG - 2011-06-26 02:19:23 --> Utf8 Class Initialized
DEBUG - 2011-06-26 02:19:23 --> UTF-8 Support Enabled
DEBUG - 2011-06-26 02:19:23 --> URI Class Initialized
DEBUG - 2011-06-26 02:19:23 --> Router Class Initialized
DEBUG - 2011-06-26 02:19:23 --> Output Class Initialized
DEBUG - 2011-06-26 02:19:23 --> Input Class Initialized
DEBUG - 2011-06-26 02:19:23 --> Global POST and COOKIE data sanitized
DEBUG - 2011-06-26 02:19:23 --> Language Class Initialized
DEBUG - 2011-06-26 02:19:23 --> Loader Class Initialized
DEBUG - 2011-06-26 02:19:23 --> Controller Class Initialized
DEBUG - 2011-06-26 02:19:23 --> Model Class Initialized
DEBUG - 2011-06-26 02:19:23 --> Model Class Initialized
DEBUG - 2011-06-26 02:19:23 --> Model Class Initialized
DEBUG - 2011-06-26 02:19:23 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-06-26 02:19:23 --> Database Driver Class Initialized
DEBUG - 2011-06-26 02:19:23 --> File loaded: application/views/table/main.php
DEBUG - 2011-06-26 02:19:23 --> Helper loaded: url_helper
DEBUG - 2011-06-26 02:19:23 --> File loaded: application/views/common/header.php
DEBUG - 2011-06-26 02:19:23 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-06-26 02:19:23 --> File loaded: application/views/common/footer.php
DEBUG - 2011-06-26 02:19:23 --> File loaded: application/views/layout/main.php
DEBUG - 2011-06-26 02:19:23 --> Final output sent to browser
DEBUG - 2011-06-26 02:19:23 --> Total execution time: 0.0606
DEBUG - 2011-06-26 02:19:30 --> Config Class Initialized
DEBUG - 2011-06-26 02:19:30 --> Hooks Class Initialized
DEBUG - 2011-06-26 02:19:30 --> Utf8 Class Initialized
DEBUG - 2011-06-26 02:19:30 --> UTF-8 Support Enabled
DEBUG - 2011-06-26 02:19:30 --> URI Class Initialized
DEBUG - 2011-06-26 02:19:30 --> Router Class Initialized
DEBUG - 2011-06-26 02:19:30 --> Output Class Initialized
DEBUG - 2011-06-26 02:19:30 --> Input Class Initialized
DEBUG - 2011-06-26 02:19:30 --> Global POST and COOKIE data sanitized
DEBUG - 2011-06-26 02:19:30 --> Language Class Initialized
DEBUG - 2011-06-26 02:19:30 --> Loader Class Initialized
DEBUG - 2011-06-26 02:19:30 --> Controller Class Initialized
DEBUG - 2011-06-26 02:19:30 --> Model Class Initialized
DEBUG - 2011-06-26 02:19:30 --> Model Class Initialized
DEBUG - 2011-06-26 02:19:30 --> Model Class Initialized
DEBUG - 2011-06-26 02:19:30 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-06-26 02:19:30 --> Database Driver Class Initialized
DEBUG - 2011-06-26 02:19:30 --> File loaded: application/views/table/main.php
DEBUG - 2011-06-26 02:19:30 --> Helper loaded: url_helper
DEBUG - 2011-06-26 02:19:30 --> File loaded: application/views/common/header.php
DEBUG - 2011-06-26 02:19:30 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-06-26 02:19:30 --> File loaded: application/views/common/footer.php
DEBUG - 2011-06-26 02:19:30 --> File loaded: application/views/layout/main.php
DEBUG - 2011-06-26 02:19:30 --> Final output sent to browser
DEBUG - 2011-06-26 02:19:30 --> Total execution time: 0.0513
DEBUG - 2011-06-26 02:19:37 --> Config Class Initialized
DEBUG - 2011-06-26 02:19:37 --> Hooks Class Initialized
DEBUG - 2011-06-26 02:19:37 --> Utf8 Class Initialized
DEBUG - 2011-06-26 02:19:37 --> UTF-8 Support Enabled
DEBUG - 2011-06-26 02:19:37 --> URI Class Initialized
DEBUG - 2011-06-26 02:19:37 --> Router Class Initialized
DEBUG - 2011-06-26 02:19:37 --> Output Class Initialized
DEBUG - 2011-06-26 02:19:37 --> Input Class Initialized
DEBUG - 2011-06-26 02:19:37 --> Global POST and COOKIE data sanitized
DEBUG - 2011-06-26 02:19:37 --> Language Class Initialized
DEBUG - 2011-06-26 02:19:37 --> Loader Class Initialized
DEBUG - 2011-06-26 02:19:37 --> Controller Class Initialized
DEBUG - 2011-06-26 02:19:37 --> Model Class Initialized
DEBUG - 2011-06-26 02:19:37 --> Model Class Initialized
DEBUG - 2011-06-26 02:19:37 --> Model Class Initialized
DEBUG - 2011-06-26 02:19:37 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-06-26 02:19:37 --> Database Driver Class Initialized
DEBUG - 2011-06-26 02:19:37 --> File loaded: application/views/table/main.php
DEBUG - 2011-06-26 02:19:37 --> Helper loaded: url_helper
DEBUG - 2011-06-26 02:19:37 --> File loaded: application/views/common/header.php
DEBUG - 2011-06-26 02:19:37 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-06-26 02:19:37 --> File loaded: application/views/common/footer.php
DEBUG - 2011-06-26 02:19:37 --> File loaded: application/views/layout/main.php
DEBUG - 2011-06-26 02:19:37 --> Final output sent to browser
DEBUG - 2011-06-26 02:19:37 --> Total execution time: 0.0599
DEBUG - 2011-06-26 03:57:56 --> Config Class Initialized
DEBUG - 2011-06-26 03:57:56 --> Hooks Class Initialized
DEBUG - 2011-06-26 03:57:56 --> Utf8 Class Initialized
DEBUG - 2011-06-26 03:57:56 --> UTF-8 Support Enabled
DEBUG - 2011-06-26 03:57:56 --> URI Class Initialized
DEBUG - 2011-06-26 03:57:56 --> Router Class Initialized
ERROR - 2011-06-26 03:57:56 --> 404 Page Not Found --> robots.txt
DEBUG - 2011-06-26 03:57:56 --> Config Class Initialized
DEBUG - 2011-06-26 03:57:56 --> Hooks Class Initialized
DEBUG - 2011-06-26 03:57:56 --> Utf8 Class Initialized
DEBUG - 2011-06-26 03:57:56 --> UTF-8 Support Enabled
DEBUG - 2011-06-26 03:57:56 --> URI Class Initialized
DEBUG - 2011-06-26 03:57:56 --> Router Class Initialized
DEBUG - 2011-06-26 03:57:56 --> Output Class Initialized
DEBUG - 2011-06-26 03:57:56 --> Input Class Initialized
DEBUG - 2011-06-26 03:57:56 --> Global POST and COOKIE data sanitized
DEBUG - 2011-06-26 03:57:56 --> Language Class Initialized
DEBUG - 2011-06-26 03:57:56 --> Loader Class Initialized
DEBUG - 2011-06-26 03:57:56 --> Controller Class Initialized
ERROR - 2011-06-26 03:57:56 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-06-26 03:57:56 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-06-26 03:57:56 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-06-26 03:57:56 --> Model Class Initialized
DEBUG - 2011-06-26 03:57:56 --> Model Class Initialized
DEBUG - 2011-06-26 03:57:56 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-06-26 03:57:56 --> Database Driver Class Initialized
DEBUG - 2011-06-26 03:57:57 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-06-26 03:57:57 --> Helper loaded: url_helper
DEBUG - 2011-06-26 03:57:57 --> File loaded: application/views/common/header.php
DEBUG - 2011-06-26 03:57:57 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-06-26 03:57:57 --> File loaded: application/views/common/footer.php
DEBUG - 2011-06-26 03:57:57 --> File loaded: application/views/layout/main.php
DEBUG - 2011-06-26 03:57:57 --> Final output sent to browser
DEBUG - 2011-06-26 03:57:57 --> Total execution time: 0.9323
DEBUG - 2011-06-26 05:11:06 --> Config Class Initialized
DEBUG - 2011-06-26 05:11:06 --> Hooks Class Initialized
DEBUG - 2011-06-26 05:11:06 --> Utf8 Class Initialized
DEBUG - 2011-06-26 05:11:06 --> UTF-8 Support Enabled
DEBUG - 2011-06-26 05:11:06 --> URI Class Initialized
DEBUG - 2011-06-26 05:11:06 --> Router Class Initialized
ERROR - 2011-06-26 05:11:06 --> 404 Page Not Found --> robots.txt
DEBUG - 2011-06-26 05:11:07 --> Config Class Initialized
DEBUG - 2011-06-26 05:11:07 --> Hooks Class Initialized
DEBUG - 2011-06-26 05:11:07 --> Utf8 Class Initialized
DEBUG - 2011-06-26 05:11:07 --> UTF-8 Support Enabled
DEBUG - 2011-06-26 05:11:07 --> URI Class Initialized
DEBUG - 2011-06-26 05:11:07 --> Router Class Initialized
DEBUG - 2011-06-26 05:11:07 --> Output Class Initialized
DEBUG - 2011-06-26 05:11:07 --> Input Class Initialized
DEBUG - 2011-06-26 05:11:07 --> Global POST and COOKIE data sanitized
DEBUG - 2011-06-26 05:11:07 --> Language Class Initialized
DEBUG - 2011-06-26 05:11:07 --> Loader Class Initialized
DEBUG - 2011-06-26 05:11:07 --> Controller Class Initialized
ERROR - 2011-06-26 05:11:07 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-06-26 05:11:07 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-06-26 05:11:07 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-06-26 05:11:07 --> Model Class Initialized
DEBUG - 2011-06-26 05:11:07 --> Model Class Initialized
DEBUG - 2011-06-26 05:11:07 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-06-26 05:11:07 --> Database Driver Class Initialized
DEBUG - 2011-06-26 05:11:07 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-06-26 05:11:07 --> Helper loaded: url_helper
DEBUG - 2011-06-26 05:11:07 --> File loaded: application/views/common/header.php
DEBUG - 2011-06-26 05:11:07 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-06-26 05:11:07 --> File loaded: application/views/common/footer.php
DEBUG - 2011-06-26 05:11:07 --> File loaded: application/views/layout/main.php
DEBUG - 2011-06-26 05:11:07 --> Final output sent to browser
DEBUG - 2011-06-26 05:11:07 --> Total execution time: 0.5097
DEBUG - 2011-06-26 05:11:08 --> Config Class Initialized
DEBUG - 2011-06-26 05:11:08 --> Hooks Class Initialized
DEBUG - 2011-06-26 05:11:08 --> Utf8 Class Initialized
DEBUG - 2011-06-26 05:11:08 --> UTF-8 Support Enabled
DEBUG - 2011-06-26 05:11:08 --> URI Class Initialized
DEBUG - 2011-06-26 05:11:08 --> Router Class Initialized
DEBUG - 2011-06-26 05:11:08 --> Output Class Initialized
DEBUG - 2011-06-26 05:11:08 --> Input Class Initialized
DEBUG - 2011-06-26 05:11:08 --> Global POST and COOKIE data sanitized
DEBUG - 2011-06-26 05:11:08 --> Language Class Initialized
DEBUG - 2011-06-26 05:11:08 --> Loader Class Initialized
DEBUG - 2011-06-26 05:11:08 --> Controller Class Initialized
DEBUG - 2011-06-26 05:11:08 --> Model Class Initialized
DEBUG - 2011-06-26 05:11:08 --> Model Class Initialized
DEBUG - 2011-06-26 05:11:08 --> Model Class Initialized
DEBUG - 2011-06-26 05:11:08 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-06-26 05:11:08 --> Database Driver Class Initialized
DEBUG - 2011-06-26 05:11:10 --> File loaded: application/views/table/main.php
DEBUG - 2011-06-26 05:11:10 --> Helper loaded: url_helper
DEBUG - 2011-06-26 05:11:10 --> File loaded: application/views/common/header.php
DEBUG - 2011-06-26 05:11:10 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-06-26 05:11:10 --> File loaded: application/views/common/footer.php
DEBUG - 2011-06-26 05:11:10 --> File loaded: application/views/layout/main.php
DEBUG - 2011-06-26 05:11:10 --> Final output sent to browser
DEBUG - 2011-06-26 05:11:10 --> Total execution time: 2.1392
DEBUG - 2011-06-26 06:01:34 --> Config Class Initialized
DEBUG - 2011-06-26 06:01:34 --> Hooks Class Initialized
DEBUG - 2011-06-26 06:01:34 --> Utf8 Class Initialized
DEBUG - 2011-06-26 06:01:34 --> UTF-8 Support Enabled
DEBUG - 2011-06-26 06:01:34 --> URI Class Initialized
DEBUG - 2011-06-26 06:01:34 --> Router Class Initialized
DEBUG - 2011-06-26 06:01:34 --> Output Class Initialized
DEBUG - 2011-06-26 06:01:34 --> Input Class Initialized
DEBUG - 2011-06-26 06:01:34 --> Global POST and COOKIE data sanitized
DEBUG - 2011-06-26 06:01:34 --> Language Class Initialized
DEBUG - 2011-06-26 06:01:34 --> Loader Class Initialized
DEBUG - 2011-06-26 06:01:34 --> Controller Class Initialized
DEBUG - 2011-06-26 06:01:34 --> Model Class Initialized
DEBUG - 2011-06-26 06:01:34 --> Model Class Initialized
DEBUG - 2011-06-26 06:01:34 --> Model Class Initialized
DEBUG - 2011-06-26 06:01:34 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-06-26 06:01:34 --> Database Driver Class Initialized
DEBUG - 2011-06-26 06:01:34 --> File loaded: application/views/table/main.php
DEBUG - 2011-06-26 06:01:34 --> Helper loaded: url_helper
DEBUG - 2011-06-26 06:01:34 --> File loaded: application/views/common/header.php
DEBUG - 2011-06-26 06:01:34 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-06-26 06:01:34 --> File loaded: application/views/common/footer.php
DEBUG - 2011-06-26 06:01:34 --> File loaded: application/views/layout/main.php
DEBUG - 2011-06-26 06:01:34 --> Final output sent to browser
DEBUG - 2011-06-26 06:01:34 --> Total execution time: 0.5944
DEBUG - 2011-06-26 06:01:35 --> Config Class Initialized
DEBUG - 2011-06-26 06:01:35 --> Hooks Class Initialized
DEBUG - 2011-06-26 06:01:35 --> Utf8 Class Initialized
DEBUG - 2011-06-26 06:01:35 --> UTF-8 Support Enabled
DEBUG - 2011-06-26 06:01:35 --> URI Class Initialized
DEBUG - 2011-06-26 06:01:35 --> Router Class Initialized
DEBUG - 2011-06-26 06:01:35 --> Output Class Initialized
DEBUG - 2011-06-26 06:01:35 --> Input Class Initialized
DEBUG - 2011-06-26 06:01:35 --> Global POST and COOKIE data sanitized
DEBUG - 2011-06-26 06:01:35 --> Language Class Initialized
DEBUG - 2011-06-26 06:01:35 --> Loader Class Initialized
DEBUG - 2011-06-26 06:01:35 --> Controller Class Initialized
ERROR - 2011-06-26 06:01:35 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-06-26 06:01:35 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-06-26 06:01:35 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-06-26 06:01:35 --> Model Class Initialized
DEBUG - 2011-06-26 06:01:35 --> Model Class Initialized
DEBUG - 2011-06-26 06:01:35 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-06-26 06:01:35 --> Database Driver Class Initialized
DEBUG - 2011-06-26 06:01:35 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-06-26 06:01:35 --> Helper loaded: url_helper
DEBUG - 2011-06-26 06:01:35 --> File loaded: application/views/common/header.php
DEBUG - 2011-06-26 06:01:35 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-06-26 06:01:35 --> File loaded: application/views/common/footer.php
DEBUG - 2011-06-26 06:01:35 --> File loaded: application/views/layout/main.php
DEBUG - 2011-06-26 06:01:35 --> Final output sent to browser
DEBUG - 2011-06-26 06:01:35 --> Total execution time: 0.0909
DEBUG - 2011-06-26 07:13:11 --> Config Class Initialized
DEBUG - 2011-06-26 07:13:11 --> Hooks Class Initialized
DEBUG - 2011-06-26 07:13:11 --> Utf8 Class Initialized
DEBUG - 2011-06-26 07:13:11 --> UTF-8 Support Enabled
DEBUG - 2011-06-26 07:13:11 --> URI Class Initialized
DEBUG - 2011-06-26 07:13:11 --> Router Class Initialized
DEBUG - 2011-06-26 07:13:11 --> Output Class Initialized
DEBUG - 2011-06-26 07:13:11 --> Input Class Initialized
DEBUG - 2011-06-26 07:13:11 --> Global POST and COOKIE data sanitized
DEBUG - 2011-06-26 07:13:11 --> Language Class Initialized
DEBUG - 2011-06-26 07:13:11 --> Loader Class Initialized
DEBUG - 2011-06-26 07:13:11 --> Controller Class Initialized
DEBUG - 2011-06-26 07:13:11 --> Model Class Initialized
DEBUG - 2011-06-26 07:13:11 --> Model Class Initialized
DEBUG - 2011-06-26 07:13:11 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-06-26 07:13:12 --> Database Driver Class Initialized
DEBUG - 2011-06-26 07:13:12 --> Final output sent to browser
DEBUG - 2011-06-26 07:13:12 --> Total execution time: 1.7420
DEBUG - 2011-06-26 11:25:57 --> Config Class Initialized
DEBUG - 2011-06-26 11:25:58 --> Hooks Class Initialized
DEBUG - 2011-06-26 11:25:58 --> Utf8 Class Initialized
DEBUG - 2011-06-26 11:25:58 --> UTF-8 Support Enabled
DEBUG - 2011-06-26 11:25:58 --> URI Class Initialized
DEBUG - 2011-06-26 11:25:59 --> Router Class Initialized
DEBUG - 2011-06-26 11:25:59 --> Output Class Initialized
DEBUG - 2011-06-26 11:25:59 --> Input Class Initialized
DEBUG - 2011-06-26 11:25:59 --> Global POST and COOKIE data sanitized
DEBUG - 2011-06-26 11:26:00 --> Language Class Initialized
DEBUG - 2011-06-26 11:26:01 --> Loader Class Initialized
DEBUG - 2011-06-26 11:26:01 --> Controller Class Initialized
ERROR - 2011-06-26 11:26:02 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-06-26 11:26:02 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-06-26 11:26:02 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-06-26 11:26:02 --> Model Class Initialized
DEBUG - 2011-06-26 11:26:02 --> Model Class Initialized
DEBUG - 2011-06-26 11:26:02 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-06-26 11:26:02 --> Database Driver Class Initialized
DEBUG - 2011-06-26 11:26:02 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-06-26 11:26:03 --> Helper loaded: url_helper
DEBUG - 2011-06-26 11:26:03 --> File loaded: application/views/common/header.php
DEBUG - 2011-06-26 11:26:03 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-06-26 11:26:03 --> File loaded: application/views/common/footer.php
DEBUG - 2011-06-26 11:26:03 --> File loaded: application/views/layout/main.php
DEBUG - 2011-06-26 11:26:03 --> Final output sent to browser
DEBUG - 2011-06-26 11:26:03 --> Total execution time: 6.1573
DEBUG - 2011-06-26 11:26:04 --> Config Class Initialized
DEBUG - 2011-06-26 11:26:04 --> Hooks Class Initialized
DEBUG - 2011-06-26 11:26:04 --> Utf8 Class Initialized
DEBUG - 2011-06-26 11:26:04 --> UTF-8 Support Enabled
DEBUG - 2011-06-26 11:26:04 --> URI Class Initialized
DEBUG - 2011-06-26 11:26:04 --> Router Class Initialized
DEBUG - 2011-06-26 11:26:04 --> Output Class Initialized
DEBUG - 2011-06-26 11:26:04 --> Input Class Initialized
DEBUG - 2011-06-26 11:26:04 --> Global POST and COOKIE data sanitized
DEBUG - 2011-06-26 11:26:04 --> Language Class Initialized
DEBUG - 2011-06-26 11:26:04 --> Loader Class Initialized
DEBUG - 2011-06-26 11:26:04 --> Controller Class Initialized
DEBUG - 2011-06-26 11:26:04 --> Model Class Initialized
DEBUG - 2011-06-26 11:26:04 --> Model Class Initialized
DEBUG - 2011-06-26 11:26:04 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-06-26 11:26:04 --> Database Driver Class Initialized
DEBUG - 2011-06-26 11:26:06 --> Final output sent to browser
DEBUG - 2011-06-26 11:26:06 --> Total execution time: 2.0445
DEBUG - 2011-06-26 11:26:06 --> Config Class Initialized
DEBUG - 2011-06-26 11:26:06 --> Hooks Class Initialized
DEBUG - 2011-06-26 11:26:06 --> Utf8 Class Initialized
DEBUG - 2011-06-26 11:26:06 --> UTF-8 Support Enabled
DEBUG - 2011-06-26 11:26:06 --> URI Class Initialized
DEBUG - 2011-06-26 11:26:06 --> Router Class Initialized
ERROR - 2011-06-26 11:26:06 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-06-26 11:26:08 --> Config Class Initialized
DEBUG - 2011-06-26 11:26:08 --> Hooks Class Initialized
DEBUG - 2011-06-26 11:26:08 --> Utf8 Class Initialized
DEBUG - 2011-06-26 11:26:08 --> UTF-8 Support Enabled
DEBUG - 2011-06-26 11:26:08 --> URI Class Initialized
DEBUG - 2011-06-26 11:26:08 --> Router Class Initialized
ERROR - 2011-06-26 11:26:08 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-06-26 11:45:39 --> Config Class Initialized
DEBUG - 2011-06-26 11:45:39 --> Hooks Class Initialized
DEBUG - 2011-06-26 11:45:39 --> Utf8 Class Initialized
DEBUG - 2011-06-26 11:45:39 --> UTF-8 Support Enabled
DEBUG - 2011-06-26 11:45:39 --> URI Class Initialized
DEBUG - 2011-06-26 11:45:39 --> Router Class Initialized
DEBUG - 2011-06-26 11:45:39 --> Output Class Initialized
DEBUG - 2011-06-26 11:45:39 --> Input Class Initialized
DEBUG - 2011-06-26 11:45:39 --> Global POST and COOKIE data sanitized
DEBUG - 2011-06-26 11:45:39 --> Language Class Initialized
DEBUG - 2011-06-26 11:45:39 --> Loader Class Initialized
DEBUG - 2011-06-26 11:45:39 --> Controller Class Initialized
DEBUG - 2011-06-26 11:45:39 --> Model Class Initialized
DEBUG - 2011-06-26 11:45:39 --> Model Class Initialized
DEBUG - 2011-06-26 11:45:39 --> Model Class Initialized
DEBUG - 2011-06-26 11:45:39 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-06-26 11:45:39 --> Database Driver Class Initialized
DEBUG - 2011-06-26 11:45:39 --> File loaded: application/views/table/main.php
DEBUG - 2011-06-26 11:45:39 --> Helper loaded: url_helper
DEBUG - 2011-06-26 11:45:39 --> File loaded: application/views/common/header.php
DEBUG - 2011-06-26 11:45:39 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-06-26 11:45:39 --> File loaded: application/views/common/footer.php
DEBUG - 2011-06-26 11:45:39 --> File loaded: application/views/layout/main.php
DEBUG - 2011-06-26 11:45:39 --> Final output sent to browser
DEBUG - 2011-06-26 11:45:39 --> Total execution time: 0.4333
DEBUG - 2011-06-26 11:45:41 --> Config Class Initialized
DEBUG - 2011-06-26 11:45:41 --> Hooks Class Initialized
DEBUG - 2011-06-26 11:45:41 --> Utf8 Class Initialized
DEBUG - 2011-06-26 11:45:41 --> UTF-8 Support Enabled
DEBUG - 2011-06-26 11:45:41 --> URI Class Initialized
DEBUG - 2011-06-26 11:45:41 --> Router Class Initialized
ERROR - 2011-06-26 11:45:41 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-06-26 11:46:19 --> Config Class Initialized
DEBUG - 2011-06-26 11:46:19 --> Hooks Class Initialized
DEBUG - 2011-06-26 11:46:19 --> Utf8 Class Initialized
DEBUG - 2011-06-26 11:46:19 --> UTF-8 Support Enabled
DEBUG - 2011-06-26 11:46:19 --> URI Class Initialized
DEBUG - 2011-06-26 11:46:19 --> Router Class Initialized
DEBUG - 2011-06-26 11:46:19 --> Output Class Initialized
DEBUG - 2011-06-26 11:46:19 --> Input Class Initialized
DEBUG - 2011-06-26 11:46:19 --> Global POST and COOKIE data sanitized
DEBUG - 2011-06-26 11:46:19 --> Language Class Initialized
DEBUG - 2011-06-26 11:46:19 --> Loader Class Initialized
DEBUG - 2011-06-26 11:46:19 --> Controller Class Initialized
DEBUG - 2011-06-26 11:46:19 --> Model Class Initialized
DEBUG - 2011-06-26 11:46:19 --> Model Class Initialized
DEBUG - 2011-06-26 11:46:19 --> Model Class Initialized
DEBUG - 2011-06-26 11:46:19 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-06-26 11:46:19 --> Database Driver Class Initialized
DEBUG - 2011-06-26 11:46:19 --> File loaded: application/views/table/main.php
DEBUG - 2011-06-26 11:46:19 --> Helper loaded: url_helper
DEBUG - 2011-06-26 11:46:19 --> File loaded: application/views/common/header.php
DEBUG - 2011-06-26 11:46:19 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-06-26 11:46:19 --> File loaded: application/views/common/footer.php
DEBUG - 2011-06-26 11:46:19 --> File loaded: application/views/layout/main.php
DEBUG - 2011-06-26 11:46:19 --> Final output sent to browser
DEBUG - 2011-06-26 11:46:19 --> Total execution time: 0.7916
DEBUG - 2011-06-26 11:46:20 --> Config Class Initialized
DEBUG - 2011-06-26 11:46:20 --> Hooks Class Initialized
DEBUG - 2011-06-26 11:46:20 --> Utf8 Class Initialized
DEBUG - 2011-06-26 11:46:20 --> UTF-8 Support Enabled
DEBUG - 2011-06-26 11:46:20 --> URI Class Initialized
DEBUG - 2011-06-26 11:46:20 --> Router Class Initialized
ERROR - 2011-06-26 11:46:20 --> 404 Page Not Found --> robots.txt
DEBUG - 2011-06-26 11:46:21 --> Config Class Initialized
DEBUG - 2011-06-26 11:46:21 --> Hooks Class Initialized
DEBUG - 2011-06-26 11:46:21 --> Utf8 Class Initialized
DEBUG - 2011-06-26 11:46:21 --> UTF-8 Support Enabled
DEBUG - 2011-06-26 11:46:21 --> URI Class Initialized
DEBUG - 2011-06-26 11:46:21 --> Router Class Initialized
DEBUG - 2011-06-26 11:46:21 --> Output Class Initialized
DEBUG - 2011-06-26 11:46:21 --> Input Class Initialized
DEBUG - 2011-06-26 11:46:21 --> Global POST and COOKIE data sanitized
DEBUG - 2011-06-26 11:46:21 --> Language Class Initialized
DEBUG - 2011-06-26 11:46:21 --> Loader Class Initialized
DEBUG - 2011-06-26 11:46:21 --> Controller Class Initialized
DEBUG - 2011-06-26 11:46:21 --> Model Class Initialized
DEBUG - 2011-06-26 11:46:21 --> Model Class Initialized
DEBUG - 2011-06-26 11:46:21 --> Model Class Initialized
DEBUG - 2011-06-26 11:46:21 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-06-26 11:46:21 --> Database Driver Class Initialized
DEBUG - 2011-06-26 11:46:21 --> File loaded: application/views/table/main.php
DEBUG - 2011-06-26 11:46:21 --> Helper loaded: url_helper
DEBUG - 2011-06-26 11:46:21 --> File loaded: application/views/common/header.php
DEBUG - 2011-06-26 11:46:21 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-06-26 11:46:21 --> File loaded: application/views/common/footer.php
DEBUG - 2011-06-26 11:46:21 --> File loaded: application/views/layout/main.php
DEBUG - 2011-06-26 11:46:21 --> Final output sent to browser
DEBUG - 2011-06-26 11:46:21 --> Total execution time: 0.0806
DEBUG - 2011-06-26 11:46:21 --> Config Class Initialized
DEBUG - 2011-06-26 11:46:21 --> Hooks Class Initialized
DEBUG - 2011-06-26 11:46:21 --> Utf8 Class Initialized
DEBUG - 2011-06-26 11:46:21 --> UTF-8 Support Enabled
DEBUG - 2011-06-26 11:46:21 --> URI Class Initialized
DEBUG - 2011-06-26 11:46:21 --> Router Class Initialized
ERROR - 2011-06-26 11:46:21 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-06-26 12:21:01 --> Config Class Initialized
DEBUG - 2011-06-26 12:21:02 --> Hooks Class Initialized
DEBUG - 2011-06-26 12:21:02 --> Utf8 Class Initialized
DEBUG - 2011-06-26 12:21:02 --> UTF-8 Support Enabled
DEBUG - 2011-06-26 12:21:02 --> URI Class Initialized
DEBUG - 2011-06-26 12:21:02 --> Router Class Initialized
DEBUG - 2011-06-26 12:21:03 --> Output Class Initialized
DEBUG - 2011-06-26 12:21:03 --> Input Class Initialized
DEBUG - 2011-06-26 12:21:03 --> Global POST and COOKIE data sanitized
DEBUG - 2011-06-26 12:21:03 --> Language Class Initialized
DEBUG - 2011-06-26 12:21:03 --> Loader Class Initialized
DEBUG - 2011-06-26 12:21:03 --> Controller Class Initialized
ERROR - 2011-06-26 12:21:04 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-06-26 12:21:04 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-06-26 12:21:04 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-06-26 12:21:05 --> Model Class Initialized
DEBUG - 2011-06-26 12:21:05 --> Model Class Initialized
DEBUG - 2011-06-26 12:21:05 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-06-26 12:21:05 --> Database Driver Class Initialized
DEBUG - 2011-06-26 12:21:05 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-06-26 12:21:05 --> Helper loaded: url_helper
DEBUG - 2011-06-26 12:21:05 --> File loaded: application/views/common/header.php
DEBUG - 2011-06-26 12:21:05 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-06-26 12:21:05 --> File loaded: application/views/common/footer.php
DEBUG - 2011-06-26 12:21:05 --> File loaded: application/views/layout/main.php
DEBUG - 2011-06-26 12:21:05 --> Final output sent to browser
DEBUG - 2011-06-26 12:21:05 --> Total execution time: 3.6437
DEBUG - 2011-06-26 12:21:06 --> Config Class Initialized
DEBUG - 2011-06-26 12:21:06 --> Hooks Class Initialized
DEBUG - 2011-06-26 12:21:06 --> Utf8 Class Initialized
DEBUG - 2011-06-26 12:21:06 --> UTF-8 Support Enabled
DEBUG - 2011-06-26 12:21:06 --> URI Class Initialized
DEBUG - 2011-06-26 12:21:06 --> Router Class Initialized
DEBUG - 2011-06-26 12:21:06 --> Output Class Initialized
DEBUG - 2011-06-26 12:21:06 --> Input Class Initialized
DEBUG - 2011-06-26 12:21:06 --> Global POST and COOKIE data sanitized
DEBUG - 2011-06-26 12:21:06 --> Language Class Initialized
DEBUG - 2011-06-26 12:21:06 --> Loader Class Initialized
DEBUG - 2011-06-26 12:21:06 --> Controller Class Initialized
DEBUG - 2011-06-26 12:21:06 --> Model Class Initialized
DEBUG - 2011-06-26 12:21:06 --> Model Class Initialized
DEBUG - 2011-06-26 12:21:06 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-06-26 12:21:06 --> Database Driver Class Initialized
DEBUG - 2011-06-26 12:21:07 --> Final output sent to browser
DEBUG - 2011-06-26 12:21:07 --> Total execution time: 0.6930
DEBUG - 2011-06-26 12:21:11 --> Config Class Initialized
DEBUG - 2011-06-26 12:21:11 --> Hooks Class Initialized
DEBUG - 2011-06-26 12:21:11 --> Utf8 Class Initialized
DEBUG - 2011-06-26 12:21:11 --> UTF-8 Support Enabled
DEBUG - 2011-06-26 12:21:11 --> URI Class Initialized
DEBUG - 2011-06-26 12:21:11 --> Router Class Initialized
DEBUG - 2011-06-26 12:21:11 --> Output Class Initialized
DEBUG - 2011-06-26 12:21:11 --> Input Class Initialized
DEBUG - 2011-06-26 12:21:11 --> Global POST and COOKIE data sanitized
DEBUG - 2011-06-26 12:21:11 --> Language Class Initialized
DEBUG - 2011-06-26 12:21:11 --> Loader Class Initialized
DEBUG - 2011-06-26 12:21:11 --> Controller Class Initialized
ERROR - 2011-06-26 12:21:11 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-06-26 12:21:11 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-06-26 12:21:11 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-06-26 12:21:11 --> Model Class Initialized
DEBUG - 2011-06-26 12:21:11 --> Model Class Initialized
DEBUG - 2011-06-26 12:21:11 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-06-26 12:21:11 --> Database Driver Class Initialized
DEBUG - 2011-06-26 12:21:11 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-06-26 12:21:11 --> Helper loaded: url_helper
DEBUG - 2011-06-26 12:21:11 --> File loaded: application/views/common/header.php
DEBUG - 2011-06-26 12:21:11 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-06-26 12:21:11 --> File loaded: application/views/common/footer.php
DEBUG - 2011-06-26 12:21:11 --> File loaded: application/views/layout/main.php
DEBUG - 2011-06-26 12:21:11 --> Final output sent to browser
DEBUG - 2011-06-26 12:21:11 --> Total execution time: 0.0268
DEBUG - 2011-06-26 12:21:13 --> Config Class Initialized
DEBUG - 2011-06-26 12:21:13 --> Hooks Class Initialized
DEBUG - 2011-06-26 12:21:13 --> Utf8 Class Initialized
DEBUG - 2011-06-26 12:21:13 --> UTF-8 Support Enabled
DEBUG - 2011-06-26 12:21:13 --> URI Class Initialized
DEBUG - 2011-06-26 12:21:13 --> Router Class Initialized
ERROR - 2011-06-26 12:21:13 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-06-26 12:21:14 --> Config Class Initialized
DEBUG - 2011-06-26 12:21:14 --> Hooks Class Initialized
DEBUG - 2011-06-26 12:21:14 --> Utf8 Class Initialized
DEBUG - 2011-06-26 12:21:14 --> UTF-8 Support Enabled
DEBUG - 2011-06-26 12:21:14 --> URI Class Initialized
DEBUG - 2011-06-26 12:21:14 --> Router Class Initialized
ERROR - 2011-06-26 12:21:14 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-06-26 14:43:07 --> Config Class Initialized
DEBUG - 2011-06-26 14:43:07 --> Hooks Class Initialized
DEBUG - 2011-06-26 14:43:07 --> Utf8 Class Initialized
DEBUG - 2011-06-26 14:43:07 --> UTF-8 Support Enabled
DEBUG - 2011-06-26 14:43:07 --> URI Class Initialized
DEBUG - 2011-06-26 14:43:07 --> Router Class Initialized
DEBUG - 2011-06-26 14:43:07 --> Output Class Initialized
DEBUG - 2011-06-26 14:43:07 --> Input Class Initialized
DEBUG - 2011-06-26 14:43:07 --> Global POST and COOKIE data sanitized
DEBUG - 2011-06-26 14:43:07 --> Language Class Initialized
DEBUG - 2011-06-26 14:43:07 --> Loader Class Initialized
DEBUG - 2011-06-26 14:43:07 --> Controller Class Initialized
DEBUG - 2011-06-26 14:43:07 --> Model Class Initialized
DEBUG - 2011-06-26 14:43:07 --> Model Class Initialized
DEBUG - 2011-06-26 14:43:07 --> Model Class Initialized
DEBUG - 2011-06-26 14:43:07 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-06-26 14:43:07 --> Database Driver Class Initialized
DEBUG - 2011-06-26 14:43:07 --> File loaded: application/views/table/main.php
DEBUG - 2011-06-26 14:43:07 --> Helper loaded: url_helper
DEBUG - 2011-06-26 14:43:07 --> File loaded: application/views/common/header.php
DEBUG - 2011-06-26 14:43:07 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-06-26 14:43:07 --> File loaded: application/views/common/footer.php
DEBUG - 2011-06-26 14:43:07 --> File loaded: application/views/layout/main.php
DEBUG - 2011-06-26 14:43:07 --> Final output sent to browser
DEBUG - 2011-06-26 14:43:07 --> Total execution time: 0.5563
DEBUG - 2011-06-26 14:43:18 --> Config Class Initialized
DEBUG - 2011-06-26 14:43:18 --> Hooks Class Initialized
DEBUG - 2011-06-26 14:43:18 --> Utf8 Class Initialized
DEBUG - 2011-06-26 14:43:18 --> UTF-8 Support Enabled
DEBUG - 2011-06-26 14:43:18 --> URI Class Initialized
DEBUG - 2011-06-26 14:43:18 --> Router Class Initialized
ERROR - 2011-06-26 14:43:18 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-06-26 14:43:19 --> Config Class Initialized
DEBUG - 2011-06-26 14:43:19 --> Hooks Class Initialized
DEBUG - 2011-06-26 14:43:19 --> Utf8 Class Initialized
DEBUG - 2011-06-26 14:43:19 --> UTF-8 Support Enabled
DEBUG - 2011-06-26 14:43:19 --> URI Class Initialized
DEBUG - 2011-06-26 14:43:19 --> Router Class Initialized
ERROR - 2011-06-26 14:43:19 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-06-26 16:45:52 --> Config Class Initialized
DEBUG - 2011-06-26 16:45:52 --> Hooks Class Initialized
DEBUG - 2011-06-26 16:45:52 --> Utf8 Class Initialized
DEBUG - 2011-06-26 16:45:52 --> UTF-8 Support Enabled
DEBUG - 2011-06-26 16:45:52 --> URI Class Initialized
DEBUG - 2011-06-26 16:45:52 --> Router Class Initialized
DEBUG - 2011-06-26 16:45:52 --> Output Class Initialized
DEBUG - 2011-06-26 16:45:52 --> Input Class Initialized
DEBUG - 2011-06-26 16:45:52 --> Global POST and COOKIE data sanitized
DEBUG - 2011-06-26 16:45:53 --> Language Class Initialized
DEBUG - 2011-06-26 16:45:53 --> Loader Class Initialized
DEBUG - 2011-06-26 16:45:53 --> Controller Class Initialized
DEBUG - 2011-06-26 16:45:53 --> Model Class Initialized
DEBUG - 2011-06-26 16:45:53 --> Model Class Initialized
DEBUG - 2011-06-26 16:45:53 --> Model Class Initialized
DEBUG - 2011-06-26 16:45:53 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-06-26 16:45:53 --> Database Driver Class Initialized
DEBUG - 2011-06-26 16:45:54 --> File loaded: application/views/table/main.php
DEBUG - 2011-06-26 16:45:54 --> Helper loaded: url_helper
DEBUG - 2011-06-26 16:45:54 --> File loaded: application/views/common/header.php
DEBUG - 2011-06-26 16:45:54 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-06-26 16:45:54 --> File loaded: application/views/common/footer.php
DEBUG - 2011-06-26 16:45:54 --> File loaded: application/views/layout/main.php
DEBUG - 2011-06-26 16:45:54 --> Final output sent to browser
DEBUG - 2011-06-26 16:45:54 --> Total execution time: 1.8237
DEBUG - 2011-06-26 16:45:55 --> Config Class Initialized
DEBUG - 2011-06-26 16:45:55 --> Hooks Class Initialized
DEBUG - 2011-06-26 16:45:55 --> Utf8 Class Initialized
DEBUG - 2011-06-26 16:45:55 --> UTF-8 Support Enabled
DEBUG - 2011-06-26 16:45:55 --> URI Class Initialized
DEBUG - 2011-06-26 16:45:55 --> Router Class Initialized
DEBUG - 2011-06-26 16:45:55 --> Output Class Initialized
DEBUG - 2011-06-26 16:45:55 --> Input Class Initialized
DEBUG - 2011-06-26 16:45:55 --> Global POST and COOKIE data sanitized
DEBUG - 2011-06-26 16:45:55 --> Language Class Initialized
DEBUG - 2011-06-26 16:45:55 --> Loader Class Initialized
DEBUG - 2011-06-26 16:45:55 --> Controller Class Initialized
ERROR - 2011-06-26 16:45:55 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-06-26 16:45:55 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-06-26 16:45:55 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-06-26 16:45:55 --> Model Class Initialized
DEBUG - 2011-06-26 16:45:55 --> Model Class Initialized
DEBUG - 2011-06-26 16:45:55 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-06-26 16:45:55 --> Database Driver Class Initialized
DEBUG - 2011-06-26 16:45:55 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-06-26 16:45:55 --> Helper loaded: url_helper
DEBUG - 2011-06-26 16:45:55 --> File loaded: application/views/common/header.php
DEBUG - 2011-06-26 16:45:55 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-06-26 16:45:55 --> File loaded: application/views/common/footer.php
DEBUG - 2011-06-26 16:45:55 --> File loaded: application/views/layout/main.php
DEBUG - 2011-06-26 16:45:55 --> Final output sent to browser
DEBUG - 2011-06-26 16:45:55 --> Total execution time: 0.2390
DEBUG - 2011-06-26 20:09:13 --> Config Class Initialized
DEBUG - 2011-06-26 20:09:13 --> Hooks Class Initialized
DEBUG - 2011-06-26 20:09:13 --> Utf8 Class Initialized
DEBUG - 2011-06-26 20:09:13 --> UTF-8 Support Enabled
DEBUG - 2011-06-26 20:09:13 --> URI Class Initialized
DEBUG - 2011-06-26 20:09:13 --> Router Class Initialized
DEBUG - 2011-06-26 20:09:13 --> Output Class Initialized
DEBUG - 2011-06-26 20:09:13 --> Input Class Initialized
DEBUG - 2011-06-26 20:09:13 --> Global POST and COOKIE data sanitized
DEBUG - 2011-06-26 20:09:13 --> Language Class Initialized
DEBUG - 2011-06-26 20:09:13 --> Loader Class Initialized
DEBUG - 2011-06-26 20:09:13 --> Controller Class Initialized
DEBUG - 2011-06-26 20:09:13 --> Model Class Initialized
DEBUG - 2011-06-26 20:09:13 --> Model Class Initialized
DEBUG - 2011-06-26 20:09:13 --> Model Class Initialized
DEBUG - 2011-06-26 20:09:13 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-06-26 20:09:13 --> Database Driver Class Initialized
DEBUG - 2011-06-26 20:09:14 --> File loaded: application/views/table/main.php
DEBUG - 2011-06-26 20:09:14 --> Helper loaded: url_helper
DEBUG - 2011-06-26 20:09:14 --> File loaded: application/views/common/header.php
DEBUG - 2011-06-26 20:09:14 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-06-26 20:09:14 --> File loaded: application/views/common/footer.php
DEBUG - 2011-06-26 20:09:14 --> File loaded: application/views/layout/main.php
DEBUG - 2011-06-26 20:09:14 --> Final output sent to browser
DEBUG - 2011-06-26 20:09:14 --> Total execution time: 0.7139
DEBUG - 2011-06-26 21:48:02 --> Config Class Initialized
DEBUG - 2011-06-26 21:48:02 --> Hooks Class Initialized
DEBUG - 2011-06-26 21:48:02 --> Utf8 Class Initialized
DEBUG - 2011-06-26 21:48:02 --> UTF-8 Support Enabled
DEBUG - 2011-06-26 21:48:02 --> URI Class Initialized
DEBUG - 2011-06-26 21:48:02 --> Router Class Initialized
ERROR - 2011-06-26 21:48:02 --> 404 Page Not Found --> robots.txt
DEBUG - 2011-06-26 21:49:44 --> Config Class Initialized
DEBUG - 2011-06-26 21:49:44 --> Hooks Class Initialized
DEBUG - 2011-06-26 21:49:44 --> Utf8 Class Initialized
DEBUG - 2011-06-26 21:49:44 --> UTF-8 Support Enabled
DEBUG - 2011-06-26 21:49:44 --> URI Class Initialized
DEBUG - 2011-06-26 21:49:44 --> Router Class Initialized
DEBUG - 2011-06-26 21:49:44 --> Output Class Initialized
DEBUG - 2011-06-26 21:49:44 --> Input Class Initialized
DEBUG - 2011-06-26 21:49:44 --> Global POST and COOKIE data sanitized
DEBUG - 2011-06-26 21:49:44 --> Language Class Initialized
DEBUG - 2011-06-26 21:49:45 --> Loader Class Initialized
DEBUG - 2011-06-26 21:49:45 --> Controller Class Initialized
ERROR - 2011-06-26 21:49:45 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-06-26 21:49:45 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-06-26 21:49:45 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-06-26 21:49:45 --> Model Class Initialized
DEBUG - 2011-06-26 21:49:45 --> Model Class Initialized
DEBUG - 2011-06-26 21:49:45 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-06-26 21:49:45 --> Database Driver Class Initialized
DEBUG - 2011-06-26 21:49:45 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-06-26 21:49:45 --> Helper loaded: url_helper
DEBUG - 2011-06-26 21:49:45 --> File loaded: application/views/common/header.php
DEBUG - 2011-06-26 21:49:45 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-06-26 21:49:45 --> File loaded: application/views/common/footer.php
DEBUG - 2011-06-26 21:49:45 --> File loaded: application/views/layout/main.php
DEBUG - 2011-06-26 21:49:45 --> Final output sent to browser
DEBUG - 2011-06-26 21:49:45 --> Total execution time: 0.3431
DEBUG - 2011-06-26 22:38:52 --> Config Class Initialized
DEBUG - 2011-06-26 22:38:52 --> Hooks Class Initialized
DEBUG - 2011-06-26 22:38:52 --> Utf8 Class Initialized
DEBUG - 2011-06-26 22:38:52 --> UTF-8 Support Enabled
DEBUG - 2011-06-26 22:38:52 --> URI Class Initialized
DEBUG - 2011-06-26 22:38:52 --> Router Class Initialized
DEBUG - 2011-06-26 22:38:52 --> No URI present. Default controller set.
DEBUG - 2011-06-26 22:38:52 --> Output Class Initialized
DEBUG - 2011-06-26 22:38:52 --> Input Class Initialized
DEBUG - 2011-06-26 22:38:52 --> Global POST and COOKIE data sanitized
DEBUG - 2011-06-26 22:38:52 --> Language Class Initialized
DEBUG - 2011-06-26 22:38:52 --> Loader Class Initialized
DEBUG - 2011-06-26 22:38:52 --> Controller Class Initialized
DEBUG - 2011-06-26 22:38:52 --> File loaded: application/views/splash/main.php
DEBUG - 2011-06-26 22:38:53 --> Helper loaded: url_helper
DEBUG - 2011-06-26 22:38:53 --> File loaded: application/views/common/header.php
DEBUG - 2011-06-26 22:38:53 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-06-26 22:38:53 --> File loaded: application/views/common/footer.php
DEBUG - 2011-06-26 22:38:53 --> File loaded: application/views/layout/main.php
DEBUG - 2011-06-26 22:38:53 --> Final output sent to browser
DEBUG - 2011-06-26 22:38:53 --> Total execution time: 0.5407
DEBUG - 2011-06-26 22:55:51 --> Config Class Initialized
DEBUG - 2011-06-26 22:55:51 --> Hooks Class Initialized
DEBUG - 2011-06-26 22:55:51 --> Utf8 Class Initialized
DEBUG - 2011-06-26 22:55:51 --> UTF-8 Support Enabled
DEBUG - 2011-06-26 22:55:51 --> URI Class Initialized
DEBUG - 2011-06-26 22:55:51 --> Router Class Initialized
ERROR - 2011-06-26 22:55:51 --> 404 Page Not Found --> robots.txt
DEBUG - 2011-06-26 23:18:31 --> Config Class Initialized
DEBUG - 2011-06-26 23:18:31 --> Hooks Class Initialized
DEBUG - 2011-06-26 23:18:31 --> Utf8 Class Initialized
DEBUG - 2011-06-26 23:18:31 --> UTF-8 Support Enabled
DEBUG - 2011-06-26 23:18:31 --> URI Class Initialized
DEBUG - 2011-06-26 23:18:31 --> Router Class Initialized
DEBUG - 2011-06-26 23:18:31 --> Output Class Initialized
DEBUG - 2011-06-26 23:18:31 --> Input Class Initialized
DEBUG - 2011-06-26 23:18:31 --> Global POST and COOKIE data sanitized
DEBUG - 2011-06-26 23:18:31 --> Language Class Initialized
DEBUG - 2011-06-26 23:18:31 --> Loader Class Initialized
DEBUG - 2011-06-26 23:18:31 --> Controller Class Initialized
DEBUG - 2011-06-26 23:18:31 --> Model Class Initialized
DEBUG - 2011-06-26 23:18:31 --> Model Class Initialized
DEBUG - 2011-06-26 23:18:31 --> Model Class Initialized
DEBUG - 2011-06-26 23:18:31 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-06-26 23:18:31 --> Database Driver Class Initialized
DEBUG - 2011-06-26 23:18:32 --> File loaded: application/views/table/main.php
DEBUG - 2011-06-26 23:18:32 --> Helper loaded: url_helper
DEBUG - 2011-06-26 23:18:32 --> File loaded: application/views/common/header.php
DEBUG - 2011-06-26 23:18:32 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-06-26 23:18:32 --> File loaded: application/views/common/footer.php
DEBUG - 2011-06-26 23:18:32 --> File loaded: application/views/layout/main.php
DEBUG - 2011-06-26 23:18:32 --> Final output sent to browser
DEBUG - 2011-06-26 23:18:32 --> Total execution time: 0.9567
DEBUG - 2011-06-26 23:18:33 --> Config Class Initialized
DEBUG - 2011-06-26 23:18:33 --> Hooks Class Initialized
DEBUG - 2011-06-26 23:18:33 --> Utf8 Class Initialized
DEBUG - 2011-06-26 23:18:33 --> UTF-8 Support Enabled
DEBUG - 2011-06-26 23:18:33 --> URI Class Initialized
DEBUG - 2011-06-26 23:18:33 --> Router Class Initialized
DEBUG - 2011-06-26 23:18:33 --> Output Class Initialized
DEBUG - 2011-06-26 23:18:33 --> Input Class Initialized
DEBUG - 2011-06-26 23:18:33 --> Global POST and COOKIE data sanitized
DEBUG - 2011-06-26 23:18:33 --> Language Class Initialized
DEBUG - 2011-06-26 23:18:34 --> Loader Class Initialized
DEBUG - 2011-06-26 23:18:34 --> Controller Class Initialized
ERROR - 2011-06-26 23:18:34 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-06-26 23:18:34 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-06-26 23:18:34 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-06-26 23:18:34 --> Model Class Initialized
DEBUG - 2011-06-26 23:18:34 --> Model Class Initialized
DEBUG - 2011-06-26 23:18:34 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-06-26 23:18:34 --> Database Driver Class Initialized
DEBUG - 2011-06-26 23:18:34 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-06-26 23:18:34 --> Helper loaded: url_helper
DEBUG - 2011-06-26 23:18:34 --> File loaded: application/views/common/header.php
DEBUG - 2011-06-26 23:18:34 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-06-26 23:18:34 --> File loaded: application/views/common/footer.php
DEBUG - 2011-06-26 23:18:34 --> File loaded: application/views/layout/main.php
DEBUG - 2011-06-26 23:18:34 --> Final output sent to browser
DEBUG - 2011-06-26 23:18:34 --> Total execution time: 0.1934
DEBUG - 2011-06-26 23:36:20 --> Config Class Initialized
DEBUG - 2011-06-26 23:36:20 --> Hooks Class Initialized
DEBUG - 2011-06-26 23:36:20 --> Utf8 Class Initialized
DEBUG - 2011-06-26 23:36:20 --> UTF-8 Support Enabled
DEBUG - 2011-06-26 23:36:20 --> URI Class Initialized
DEBUG - 2011-06-26 23:36:20 --> Router Class Initialized
DEBUG - 2011-06-26 23:36:20 --> Output Class Initialized
DEBUG - 2011-06-26 23:36:20 --> Input Class Initialized
DEBUG - 2011-06-26 23:36:20 --> Global POST and COOKIE data sanitized
DEBUG - 2011-06-26 23:36:20 --> Language Class Initialized
DEBUG - 2011-06-26 23:36:20 --> Loader Class Initialized
DEBUG - 2011-06-26 23:36:20 --> Controller Class Initialized
DEBUG - 2011-06-26 23:36:20 --> Model Class Initialized
DEBUG - 2011-06-26 23:36:20 --> Model Class Initialized
DEBUG - 2011-06-26 23:36:20 --> Model Class Initialized
DEBUG - 2011-06-26 23:36:20 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-06-26 23:36:20 --> Database Driver Class Initialized
DEBUG - 2011-06-26 23:36:20 --> File loaded: application/views/table/main.php
DEBUG - 2011-06-26 23:36:20 --> Helper loaded: url_helper
DEBUG - 2011-06-26 23:36:20 --> File loaded: application/views/common/header.php
DEBUG - 2011-06-26 23:36:20 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-06-26 23:36:20 --> File loaded: application/views/common/footer.php
DEBUG - 2011-06-26 23:36:20 --> File loaded: application/views/layout/main.php
DEBUG - 2011-06-26 23:36:20 --> Final output sent to browser
DEBUG - 2011-06-26 23:36:20 --> Total execution time: 0.1234
DEBUG - 2011-06-26 23:36:21 --> Config Class Initialized
DEBUG - 2011-06-26 23:36:21 --> Hooks Class Initialized
DEBUG - 2011-06-26 23:36:21 --> Utf8 Class Initialized
DEBUG - 2011-06-26 23:36:21 --> UTF-8 Support Enabled
DEBUG - 2011-06-26 23:36:21 --> URI Class Initialized
DEBUG - 2011-06-26 23:36:21 --> Router Class Initialized
DEBUG - 2011-06-26 23:36:21 --> Output Class Initialized
DEBUG - 2011-06-26 23:36:21 --> Input Class Initialized
DEBUG - 2011-06-26 23:36:21 --> Global POST and COOKIE data sanitized
DEBUG - 2011-06-26 23:36:21 --> Language Class Initialized
DEBUG - 2011-06-26 23:36:21 --> Loader Class Initialized
DEBUG - 2011-06-26 23:36:21 --> Controller Class Initialized
ERROR - 2011-06-26 23:36:21 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-06-26 23:36:21 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-06-26 23:36:21 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-06-26 23:36:21 --> Model Class Initialized
DEBUG - 2011-06-26 23:36:21 --> Model Class Initialized
DEBUG - 2011-06-26 23:36:21 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-06-26 23:36:21 --> Database Driver Class Initialized
DEBUG - 2011-06-26 23:36:21 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-06-26 23:36:21 --> Helper loaded: url_helper
DEBUG - 2011-06-26 23:36:21 --> File loaded: application/views/common/header.php
DEBUG - 2011-06-26 23:36:21 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-06-26 23:36:21 --> File loaded: application/views/common/footer.php
DEBUG - 2011-06-26 23:36:21 --> File loaded: application/views/layout/main.php
DEBUG - 2011-06-26 23:36:21 --> Final output sent to browser
DEBUG - 2011-06-26 23:36:21 --> Total execution time: 0.0543

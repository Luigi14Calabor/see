<?php  if ( ! defined('BASEPATH')) exit('No direct script access allowed'); ?>

DEBUG - 2011-04-27 00:32:54 --> Config Class Initialized
DEBUG - 2011-04-27 00:32:54 --> Hooks Class Initialized
DEBUG - 2011-04-27 00:32:54 --> Utf8 Class Initialized
DEBUG - 2011-04-27 00:32:54 --> UTF-8 Support Enabled
DEBUG - 2011-04-27 00:32:54 --> URI Class Initialized
DEBUG - 2011-04-27 00:32:54 --> Router Class Initialized
ERROR - 2011-04-27 00:32:54 --> 404 Page Not Found --> robots.txt
DEBUG - 2011-04-27 01:25:27 --> Config Class Initialized
DEBUG - 2011-04-27 01:25:27 --> Hooks Class Initialized
DEBUG - 2011-04-27 01:25:28 --> Utf8 Class Initialized
DEBUG - 2011-04-27 01:25:28 --> UTF-8 Support Enabled
DEBUG - 2011-04-27 01:25:28 --> URI Class Initialized
DEBUG - 2011-04-27 01:25:28 --> Router Class Initialized
DEBUG - 2011-04-27 01:25:28 --> Output Class Initialized
DEBUG - 2011-04-27 01:25:28 --> Input Class Initialized
DEBUG - 2011-04-27 01:25:28 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-27 01:25:28 --> Language Class Initialized
DEBUG - 2011-04-27 01:25:28 --> Loader Class Initialized
DEBUG - 2011-04-27 01:25:28 --> Controller Class Initialized
DEBUG - 2011-04-27 01:25:29 --> Model Class Initialized
DEBUG - 2011-04-27 01:25:29 --> Model Class Initialized
DEBUG - 2011-04-27 01:25:30 --> Model Class Initialized
DEBUG - 2011-04-27 01:25:30 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-27 01:25:31 --> Database Driver Class Initialized
DEBUG - 2011-04-27 01:25:33 --> File loaded: application/views/table/main.php
DEBUG - 2011-04-27 01:25:35 --> Helper loaded: url_helper
DEBUG - 2011-04-27 01:25:35 --> File loaded: application/views/common/header.php
DEBUG - 2011-04-27 01:25:36 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-04-27 01:25:36 --> File loaded: application/views/common/footer.php
DEBUG - 2011-04-27 01:25:36 --> File loaded: application/views/layout/main.php
DEBUG - 2011-04-27 01:25:36 --> Final output sent to browser
DEBUG - 2011-04-27 01:25:36 --> Total execution time: 8.9751
DEBUG - 2011-04-27 01:25:37 --> Config Class Initialized
DEBUG - 2011-04-27 01:25:37 --> Hooks Class Initialized
DEBUG - 2011-04-27 01:25:37 --> Utf8 Class Initialized
DEBUG - 2011-04-27 01:25:37 --> UTF-8 Support Enabled
DEBUG - 2011-04-27 01:25:37 --> URI Class Initialized
DEBUG - 2011-04-27 01:25:37 --> Router Class Initialized
DEBUG - 2011-04-27 01:25:38 --> Output Class Initialized
DEBUG - 2011-04-27 01:25:38 --> Input Class Initialized
DEBUG - 2011-04-27 01:25:38 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-27 01:25:38 --> Language Class Initialized
DEBUG - 2011-04-27 01:25:38 --> Loader Class Initialized
DEBUG - 2011-04-27 01:25:38 --> Controller Class Initialized
ERROR - 2011-04-27 01:25:39 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-04-27 01:25:39 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-04-27 01:25:39 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-04-27 01:25:39 --> Model Class Initialized
DEBUG - 2011-04-27 01:25:39 --> Model Class Initialized
DEBUG - 2011-04-27 01:25:39 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-27 01:25:39 --> Database Driver Class Initialized
DEBUG - 2011-04-27 01:25:39 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-04-27 01:25:39 --> Helper loaded: url_helper
DEBUG - 2011-04-27 01:25:39 --> File loaded: application/views/common/header.php
DEBUG - 2011-04-27 01:25:39 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-04-27 01:25:39 --> File loaded: application/views/common/footer.php
DEBUG - 2011-04-27 01:25:39 --> File loaded: application/views/layout/main.php
DEBUG - 2011-04-27 01:25:39 --> Final output sent to browser
DEBUG - 2011-04-27 01:25:39 --> Total execution time: 1.6811
DEBUG - 2011-04-27 03:22:58 --> Config Class Initialized
DEBUG - 2011-04-27 03:22:58 --> Hooks Class Initialized
DEBUG - 2011-04-27 03:22:58 --> Utf8 Class Initialized
DEBUG - 2011-04-27 03:22:58 --> UTF-8 Support Enabled
DEBUG - 2011-04-27 03:22:58 --> URI Class Initialized
DEBUG - 2011-04-27 03:22:58 --> Router Class Initialized
DEBUG - 2011-04-27 03:22:58 --> Output Class Initialized
DEBUG - 2011-04-27 03:22:58 --> Input Class Initialized
DEBUG - 2011-04-27 03:22:58 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-27 03:22:58 --> Language Class Initialized
DEBUG - 2011-04-27 03:22:58 --> Loader Class Initialized
DEBUG - 2011-04-27 03:22:58 --> Controller Class Initialized
ERROR - 2011-04-27 03:22:58 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-04-27 03:22:58 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-04-27 03:22:58 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-04-27 03:22:58 --> Model Class Initialized
DEBUG - 2011-04-27 03:22:58 --> Model Class Initialized
DEBUG - 2011-04-27 03:22:58 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-27 03:22:58 --> Database Driver Class Initialized
DEBUG - 2011-04-27 03:22:59 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-04-27 03:22:59 --> Helper loaded: url_helper
DEBUG - 2011-04-27 03:22:59 --> File loaded: application/views/common/header.php
DEBUG - 2011-04-27 03:22:59 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-04-27 03:22:59 --> File loaded: application/views/common/footer.php
DEBUG - 2011-04-27 03:22:59 --> File loaded: application/views/layout/main.php
DEBUG - 2011-04-27 03:22:59 --> Final output sent to browser
DEBUG - 2011-04-27 03:22:59 --> Total execution time: 1.2740
DEBUG - 2011-04-27 03:23:00 --> Config Class Initialized
DEBUG - 2011-04-27 03:23:00 --> Hooks Class Initialized
DEBUG - 2011-04-27 03:23:00 --> Utf8 Class Initialized
DEBUG - 2011-04-27 03:23:00 --> UTF-8 Support Enabled
DEBUG - 2011-04-27 03:23:00 --> URI Class Initialized
DEBUG - 2011-04-27 03:23:00 --> Router Class Initialized
DEBUG - 2011-04-27 03:23:00 --> Output Class Initialized
DEBUG - 2011-04-27 03:23:00 --> Input Class Initialized
DEBUG - 2011-04-27 03:23:00 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-27 03:23:00 --> Language Class Initialized
DEBUG - 2011-04-27 03:23:00 --> Loader Class Initialized
DEBUG - 2011-04-27 03:23:00 --> Controller Class Initialized
DEBUG - 2011-04-27 03:23:00 --> Model Class Initialized
DEBUG - 2011-04-27 03:23:00 --> Model Class Initialized
DEBUG - 2011-04-27 03:23:00 --> Model Class Initialized
DEBUG - 2011-04-27 03:23:00 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-27 03:23:00 --> Database Driver Class Initialized
DEBUG - 2011-04-27 03:23:10 --> File loaded: application/views/table/main.php
DEBUG - 2011-04-27 03:23:10 --> Helper loaded: url_helper
DEBUG - 2011-04-27 03:23:10 --> File loaded: application/views/common/header.php
DEBUG - 2011-04-27 03:23:10 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-04-27 03:23:10 --> File loaded: application/views/common/footer.php
DEBUG - 2011-04-27 03:23:10 --> File loaded: application/views/layout/main.php
DEBUG - 2011-04-27 03:23:10 --> Final output sent to browser
DEBUG - 2011-04-27 03:23:10 --> Total execution time: 9.8892
DEBUG - 2011-04-27 03:23:42 --> Config Class Initialized
DEBUG - 2011-04-27 03:23:42 --> Hooks Class Initialized
DEBUG - 2011-04-27 03:23:42 --> Utf8 Class Initialized
DEBUG - 2011-04-27 03:23:42 --> UTF-8 Support Enabled
DEBUG - 2011-04-27 03:23:42 --> URI Class Initialized
DEBUG - 2011-04-27 03:23:42 --> Router Class Initialized
DEBUG - 2011-04-27 03:23:42 --> No URI present. Default controller set.
DEBUG - 2011-04-27 03:23:42 --> Output Class Initialized
DEBUG - 2011-04-27 03:23:42 --> Input Class Initialized
DEBUG - 2011-04-27 03:23:42 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-27 03:23:42 --> Language Class Initialized
DEBUG - 2011-04-27 03:23:42 --> Loader Class Initialized
DEBUG - 2011-04-27 03:23:42 --> Controller Class Initialized
DEBUG - 2011-04-27 03:23:42 --> File loaded: application/views/splash/main.php
DEBUG - 2011-04-27 03:23:42 --> Helper loaded: url_helper
DEBUG - 2011-04-27 03:23:42 --> File loaded: application/views/common/header.php
DEBUG - 2011-04-27 03:23:42 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-04-27 03:23:42 --> File loaded: application/views/common/footer.php
DEBUG - 2011-04-27 03:23:42 --> File loaded: application/views/layout/main.php
DEBUG - 2011-04-27 03:23:42 --> Final output sent to browser
DEBUG - 2011-04-27 03:23:42 --> Total execution time: 0.0742
DEBUG - 2011-04-27 03:58:51 --> Config Class Initialized
DEBUG - 2011-04-27 03:58:51 --> Hooks Class Initialized
DEBUG - 2011-04-27 03:58:51 --> Utf8 Class Initialized
DEBUG - 2011-04-27 03:58:51 --> UTF-8 Support Enabled
DEBUG - 2011-04-27 03:58:51 --> URI Class Initialized
DEBUG - 2011-04-27 03:58:51 --> Router Class Initialized
DEBUG - 2011-04-27 03:58:51 --> Output Class Initialized
DEBUG - 2011-04-27 03:58:51 --> Input Class Initialized
DEBUG - 2011-04-27 03:58:51 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-27 03:58:51 --> Language Class Initialized
DEBUG - 2011-04-27 03:58:51 --> Loader Class Initialized
DEBUG - 2011-04-27 03:58:51 --> Controller Class Initialized
DEBUG - 2011-04-27 03:58:51 --> Model Class Initialized
DEBUG - 2011-04-27 03:58:51 --> Model Class Initialized
DEBUG - 2011-04-27 03:58:51 --> Model Class Initialized
DEBUG - 2011-04-27 03:58:51 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-27 03:58:51 --> Database Driver Class Initialized
DEBUG - 2011-04-27 03:58:51 --> File loaded: application/views/table/main.php
DEBUG - 2011-04-27 03:58:51 --> Helper loaded: url_helper
DEBUG - 2011-04-27 03:58:51 --> File loaded: application/views/common/header.php
DEBUG - 2011-04-27 03:58:51 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-04-27 03:58:51 --> File loaded: application/views/common/footer.php
DEBUG - 2011-04-27 03:58:51 --> File loaded: application/views/layout/main.php
DEBUG - 2011-04-27 03:58:51 --> Final output sent to browser
DEBUG - 2011-04-27 03:58:51 --> Total execution time: 0.7313
DEBUG - 2011-04-27 03:58:53 --> Config Class Initialized
DEBUG - 2011-04-27 03:58:53 --> Hooks Class Initialized
DEBUG - 2011-04-27 03:58:53 --> Utf8 Class Initialized
DEBUG - 2011-04-27 03:58:53 --> UTF-8 Support Enabled
DEBUG - 2011-04-27 03:58:53 --> URI Class Initialized
DEBUG - 2011-04-27 03:58:53 --> Router Class Initialized
DEBUG - 2011-04-27 03:58:53 --> Output Class Initialized
DEBUG - 2011-04-27 03:58:53 --> Input Class Initialized
DEBUG - 2011-04-27 03:58:53 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-27 03:58:53 --> Language Class Initialized
DEBUG - 2011-04-27 03:58:53 --> Loader Class Initialized
DEBUG - 2011-04-27 03:58:53 --> Controller Class Initialized
ERROR - 2011-04-27 03:58:53 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-04-27 03:58:53 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-04-27 03:58:53 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-04-27 03:58:53 --> Model Class Initialized
DEBUG - 2011-04-27 03:58:53 --> Model Class Initialized
DEBUG - 2011-04-27 03:58:53 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-27 03:58:53 --> Database Driver Class Initialized
DEBUG - 2011-04-27 03:58:53 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-04-27 03:58:53 --> Helper loaded: url_helper
DEBUG - 2011-04-27 03:58:53 --> File loaded: application/views/common/header.php
DEBUG - 2011-04-27 03:58:53 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-04-27 03:58:53 --> File loaded: application/views/common/footer.php
DEBUG - 2011-04-27 03:58:53 --> File loaded: application/views/layout/main.php
DEBUG - 2011-04-27 03:58:53 --> Final output sent to browser
DEBUG - 2011-04-27 03:58:53 --> Total execution time: 0.0764
DEBUG - 2011-04-27 06:34:14 --> Config Class Initialized
DEBUG - 2011-04-27 06:34:14 --> Hooks Class Initialized
DEBUG - 2011-04-27 06:34:14 --> Utf8 Class Initialized
DEBUG - 2011-04-27 06:34:14 --> UTF-8 Support Enabled
DEBUG - 2011-04-27 06:34:14 --> URI Class Initialized
DEBUG - 2011-04-27 06:34:14 --> Router Class Initialized
DEBUG - 2011-04-27 06:34:14 --> Output Class Initialized
DEBUG - 2011-04-27 06:34:14 --> Input Class Initialized
DEBUG - 2011-04-27 06:34:14 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-27 06:34:14 --> Language Class Initialized
DEBUG - 2011-04-27 06:34:14 --> Loader Class Initialized
DEBUG - 2011-04-27 06:34:14 --> Controller Class Initialized
ERROR - 2011-04-27 06:34:14 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-04-27 06:34:14 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-04-27 06:34:14 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-04-27 06:34:14 --> Model Class Initialized
DEBUG - 2011-04-27 06:34:14 --> Model Class Initialized
DEBUG - 2011-04-27 06:34:14 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-27 06:34:14 --> Database Driver Class Initialized
DEBUG - 2011-04-27 06:34:15 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-04-27 06:34:15 --> Helper loaded: url_helper
DEBUG - 2011-04-27 06:34:15 --> File loaded: application/views/common/header.php
DEBUG - 2011-04-27 06:34:15 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-04-27 06:34:15 --> File loaded: application/views/common/footer.php
DEBUG - 2011-04-27 06:34:15 --> File loaded: application/views/layout/main.php
DEBUG - 2011-04-27 06:34:15 --> Final output sent to browser
DEBUG - 2011-04-27 06:34:15 --> Total execution time: 0.8242
DEBUG - 2011-04-27 06:34:16 --> Config Class Initialized
DEBUG - 2011-04-27 06:34:16 --> Hooks Class Initialized
DEBUG - 2011-04-27 06:34:16 --> Utf8 Class Initialized
DEBUG - 2011-04-27 06:34:16 --> UTF-8 Support Enabled
DEBUG - 2011-04-27 06:34:16 --> URI Class Initialized
DEBUG - 2011-04-27 06:34:16 --> Router Class Initialized
DEBUG - 2011-04-27 06:34:16 --> Output Class Initialized
DEBUG - 2011-04-27 06:34:16 --> Input Class Initialized
DEBUG - 2011-04-27 06:34:16 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-27 06:34:16 --> Language Class Initialized
DEBUG - 2011-04-27 06:34:16 --> Loader Class Initialized
DEBUG - 2011-04-27 06:34:16 --> Controller Class Initialized
DEBUG - 2011-04-27 06:34:16 --> Model Class Initialized
DEBUG - 2011-04-27 06:34:16 --> Model Class Initialized
DEBUG - 2011-04-27 06:34:16 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-27 06:34:16 --> Database Driver Class Initialized
DEBUG - 2011-04-27 06:34:17 --> Final output sent to browser
DEBUG - 2011-04-27 06:34:17 --> Total execution time: 1.0423
DEBUG - 2011-04-27 06:34:18 --> Config Class Initialized
DEBUG - 2011-04-27 06:34:18 --> Hooks Class Initialized
DEBUG - 2011-04-27 06:34:18 --> Utf8 Class Initialized
DEBUG - 2011-04-27 06:34:18 --> UTF-8 Support Enabled
DEBUG - 2011-04-27 06:34:18 --> URI Class Initialized
DEBUG - 2011-04-27 06:34:18 --> Router Class Initialized
ERROR - 2011-04-27 06:34:18 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-04-27 06:34:25 --> Config Class Initialized
DEBUG - 2011-04-27 06:34:25 --> Hooks Class Initialized
DEBUG - 2011-04-27 06:34:25 --> Utf8 Class Initialized
DEBUG - 2011-04-27 06:34:25 --> UTF-8 Support Enabled
DEBUG - 2011-04-27 06:34:25 --> URI Class Initialized
DEBUG - 2011-04-27 06:34:25 --> Router Class Initialized
DEBUG - 2011-04-27 06:34:25 --> Output Class Initialized
DEBUG - 2011-04-27 06:34:25 --> Input Class Initialized
DEBUG - 2011-04-27 06:34:25 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-27 06:34:25 --> Language Class Initialized
DEBUG - 2011-04-27 06:34:25 --> Loader Class Initialized
DEBUG - 2011-04-27 06:34:25 --> Controller Class Initialized
ERROR - 2011-04-27 06:34:25 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-04-27 06:34:25 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-04-27 06:34:25 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-04-27 06:34:25 --> Model Class Initialized
DEBUG - 2011-04-27 06:34:25 --> Model Class Initialized
DEBUG - 2011-04-27 06:34:25 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-27 06:34:25 --> Database Driver Class Initialized
DEBUG - 2011-04-27 06:34:25 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-04-27 06:34:25 --> Helper loaded: url_helper
DEBUG - 2011-04-27 06:34:25 --> File loaded: application/views/common/header.php
DEBUG - 2011-04-27 06:34:25 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-04-27 06:34:25 --> File loaded: application/views/common/footer.php
DEBUG - 2011-04-27 06:34:25 --> File loaded: application/views/layout/main.php
DEBUG - 2011-04-27 06:34:25 --> Final output sent to browser
DEBUG - 2011-04-27 06:34:25 --> Total execution time: 0.0275
DEBUG - 2011-04-27 06:34:27 --> Config Class Initialized
DEBUG - 2011-04-27 06:34:27 --> Hooks Class Initialized
DEBUG - 2011-04-27 06:34:27 --> Utf8 Class Initialized
DEBUG - 2011-04-27 06:34:27 --> UTF-8 Support Enabled
DEBUG - 2011-04-27 06:34:27 --> URI Class Initialized
DEBUG - 2011-04-27 06:34:27 --> Router Class Initialized
DEBUG - 2011-04-27 06:34:27 --> Output Class Initialized
DEBUG - 2011-04-27 06:34:27 --> Input Class Initialized
DEBUG - 2011-04-27 06:34:27 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-27 06:34:27 --> Language Class Initialized
DEBUG - 2011-04-27 06:34:27 --> Loader Class Initialized
DEBUG - 2011-04-27 06:34:27 --> Controller Class Initialized
DEBUG - 2011-04-27 06:34:27 --> Model Class Initialized
DEBUG - 2011-04-27 06:34:27 --> Model Class Initialized
DEBUG - 2011-04-27 06:34:27 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-27 06:34:27 --> Database Driver Class Initialized
DEBUG - 2011-04-27 06:34:28 --> Final output sent to browser
DEBUG - 2011-04-27 06:34:28 --> Total execution time: 1.1126
DEBUG - 2011-04-27 06:34:29 --> Config Class Initialized
DEBUG - 2011-04-27 06:34:29 --> Hooks Class Initialized
DEBUG - 2011-04-27 06:34:29 --> Utf8 Class Initialized
DEBUG - 2011-04-27 06:34:29 --> UTF-8 Support Enabled
DEBUG - 2011-04-27 06:34:29 --> URI Class Initialized
DEBUG - 2011-04-27 06:34:29 --> Router Class Initialized
ERROR - 2011-04-27 06:34:29 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-04-27 06:34:29 --> Config Class Initialized
DEBUG - 2011-04-27 06:34:29 --> Hooks Class Initialized
DEBUG - 2011-04-27 06:34:29 --> Utf8 Class Initialized
DEBUG - 2011-04-27 06:34:29 --> UTF-8 Support Enabled
DEBUG - 2011-04-27 06:34:29 --> URI Class Initialized
DEBUG - 2011-04-27 06:34:29 --> Router Class Initialized
DEBUG - 2011-04-27 06:34:29 --> Output Class Initialized
DEBUG - 2011-04-27 06:34:29 --> Input Class Initialized
DEBUG - 2011-04-27 06:34:29 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-27 06:34:29 --> Language Class Initialized
DEBUG - 2011-04-27 06:34:29 --> Loader Class Initialized
DEBUG - 2011-04-27 06:34:29 --> Controller Class Initialized
ERROR - 2011-04-27 06:34:29 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-04-27 06:34:29 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-04-27 06:34:29 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-04-27 06:34:29 --> Model Class Initialized
DEBUG - 2011-04-27 06:34:29 --> Model Class Initialized
DEBUG - 2011-04-27 06:34:29 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-27 06:34:29 --> Database Driver Class Initialized
DEBUG - 2011-04-27 06:34:29 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-04-27 06:34:29 --> Helper loaded: url_helper
DEBUG - 2011-04-27 06:34:29 --> File loaded: application/views/common/header.php
DEBUG - 2011-04-27 06:34:29 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-04-27 06:34:29 --> File loaded: application/views/common/footer.php
DEBUG - 2011-04-27 06:34:29 --> File loaded: application/views/layout/main.php
DEBUG - 2011-04-27 06:34:29 --> Final output sent to browser
DEBUG - 2011-04-27 06:34:29 --> Total execution time: 0.0313
DEBUG - 2011-04-27 06:50:54 --> Config Class Initialized
DEBUG - 2011-04-27 06:50:54 --> Hooks Class Initialized
DEBUG - 2011-04-27 06:50:54 --> Utf8 Class Initialized
DEBUG - 2011-04-27 06:50:54 --> UTF-8 Support Enabled
DEBUG - 2011-04-27 06:50:54 --> URI Class Initialized
DEBUG - 2011-04-27 06:50:54 --> Router Class Initialized
DEBUG - 2011-04-27 06:50:54 --> Output Class Initialized
DEBUG - 2011-04-27 06:50:54 --> Input Class Initialized
DEBUG - 2011-04-27 06:50:54 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-27 06:50:54 --> Language Class Initialized
DEBUG - 2011-04-27 06:50:54 --> Loader Class Initialized
DEBUG - 2011-04-27 06:50:54 --> Controller Class Initialized
DEBUG - 2011-04-27 06:50:55 --> Model Class Initialized
DEBUG - 2011-04-27 06:50:56 --> Model Class Initialized
DEBUG - 2011-04-27 06:50:56 --> Model Class Initialized
DEBUG - 2011-04-27 06:50:56 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-27 06:50:57 --> Database Driver Class Initialized
DEBUG - 2011-04-27 06:51:11 --> File loaded: application/views/table/main.php
DEBUG - 2011-04-27 06:51:12 --> Helper loaded: url_helper
DEBUG - 2011-04-27 06:51:12 --> File loaded: application/views/common/header.php
DEBUG - 2011-04-27 06:51:12 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-04-27 06:51:12 --> File loaded: application/views/common/footer.php
DEBUG - 2011-04-27 06:51:12 --> File loaded: application/views/layout/main.php
DEBUG - 2011-04-27 06:51:12 --> Final output sent to browser
DEBUG - 2011-04-27 06:51:12 --> Total execution time: 19.1018
DEBUG - 2011-04-27 06:52:05 --> Config Class Initialized
DEBUG - 2011-04-27 06:52:05 --> Hooks Class Initialized
DEBUG - 2011-04-27 06:52:05 --> Utf8 Class Initialized
DEBUG - 2011-04-27 06:52:05 --> UTF-8 Support Enabled
DEBUG - 2011-04-27 06:52:05 --> URI Class Initialized
DEBUG - 2011-04-27 06:52:05 --> Router Class Initialized
DEBUG - 2011-04-27 06:52:05 --> Output Class Initialized
DEBUG - 2011-04-27 06:52:05 --> Input Class Initialized
DEBUG - 2011-04-27 06:52:05 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-27 06:52:05 --> Language Class Initialized
DEBUG - 2011-04-27 06:52:05 --> Loader Class Initialized
DEBUG - 2011-04-27 06:52:05 --> Controller Class Initialized
DEBUG - 2011-04-27 06:52:05 --> Model Class Initialized
DEBUG - 2011-04-27 06:52:05 --> Model Class Initialized
DEBUG - 2011-04-27 06:52:05 --> Model Class Initialized
DEBUG - 2011-04-27 06:52:05 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-27 06:52:05 --> Database Driver Class Initialized
DEBUG - 2011-04-27 06:52:05 --> File loaded: application/views/table/main.php
DEBUG - 2011-04-27 06:52:05 --> Helper loaded: url_helper
DEBUG - 2011-04-27 06:52:05 --> File loaded: application/views/common/header.php
DEBUG - 2011-04-27 06:52:05 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-04-27 06:52:05 --> File loaded: application/views/common/footer.php
DEBUG - 2011-04-27 06:52:05 --> File loaded: application/views/layout/main.php
DEBUG - 2011-04-27 06:52:05 --> Final output sent to browser
DEBUG - 2011-04-27 06:52:05 --> Total execution time: 0.4804
DEBUG - 2011-04-27 06:52:47 --> Config Class Initialized
DEBUG - 2011-04-27 06:52:47 --> Hooks Class Initialized
DEBUG - 2011-04-27 06:52:47 --> Utf8 Class Initialized
DEBUG - 2011-04-27 06:52:47 --> UTF-8 Support Enabled
DEBUG - 2011-04-27 06:52:47 --> URI Class Initialized
DEBUG - 2011-04-27 06:52:47 --> Router Class Initialized
DEBUG - 2011-04-27 06:52:47 --> Output Class Initialized
DEBUG - 2011-04-27 06:52:47 --> Input Class Initialized
DEBUG - 2011-04-27 06:52:47 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-27 06:52:47 --> Language Class Initialized
DEBUG - 2011-04-27 06:52:47 --> Loader Class Initialized
DEBUG - 2011-04-27 06:52:47 --> Controller Class Initialized
DEBUG - 2011-04-27 06:52:47 --> Model Class Initialized
DEBUG - 2011-04-27 06:52:47 --> Model Class Initialized
DEBUG - 2011-04-27 06:52:47 --> Model Class Initialized
DEBUG - 2011-04-27 06:52:47 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-27 06:52:47 --> Database Driver Class Initialized
DEBUG - 2011-04-27 06:52:48 --> File loaded: application/views/table/main.php
DEBUG - 2011-04-27 06:52:48 --> Helper loaded: url_helper
DEBUG - 2011-04-27 06:52:48 --> File loaded: application/views/common/header.php
DEBUG - 2011-04-27 06:52:48 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-04-27 06:52:48 --> File loaded: application/views/common/footer.php
DEBUG - 2011-04-27 06:52:48 --> File loaded: application/views/layout/main.php
DEBUG - 2011-04-27 06:52:48 --> Final output sent to browser
DEBUG - 2011-04-27 06:52:48 --> Total execution time: 0.2712
DEBUG - 2011-04-27 06:53:18 --> Config Class Initialized
DEBUG - 2011-04-27 06:53:18 --> Hooks Class Initialized
DEBUG - 2011-04-27 06:53:18 --> Utf8 Class Initialized
DEBUG - 2011-04-27 06:53:18 --> UTF-8 Support Enabled
DEBUG - 2011-04-27 06:53:18 --> URI Class Initialized
DEBUG - 2011-04-27 06:53:18 --> Router Class Initialized
DEBUG - 2011-04-27 06:53:18 --> Output Class Initialized
DEBUG - 2011-04-27 06:53:18 --> Input Class Initialized
DEBUG - 2011-04-27 06:53:18 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-27 06:53:18 --> Language Class Initialized
DEBUG - 2011-04-27 06:53:18 --> Loader Class Initialized
DEBUG - 2011-04-27 06:53:18 --> Controller Class Initialized
ERROR - 2011-04-27 06:53:18 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-04-27 06:53:18 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-04-27 06:53:18 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-04-27 06:53:18 --> Model Class Initialized
DEBUG - 2011-04-27 06:53:18 --> Model Class Initialized
DEBUG - 2011-04-27 06:53:18 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-27 06:53:18 --> Database Driver Class Initialized
DEBUG - 2011-04-27 06:53:18 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-04-27 06:53:18 --> Helper loaded: url_helper
DEBUG - 2011-04-27 06:53:18 --> File loaded: application/views/common/header.php
DEBUG - 2011-04-27 06:53:18 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-04-27 06:53:18 --> File loaded: application/views/common/footer.php
DEBUG - 2011-04-27 06:53:18 --> File loaded: application/views/layout/main.php
DEBUG - 2011-04-27 06:53:18 --> Final output sent to browser
DEBUG - 2011-04-27 06:53:18 --> Total execution time: 0.1077
DEBUG - 2011-04-27 06:53:21 --> Config Class Initialized
DEBUG - 2011-04-27 06:53:21 --> Hooks Class Initialized
DEBUG - 2011-04-27 06:53:21 --> Utf8 Class Initialized
DEBUG - 2011-04-27 06:53:21 --> UTF-8 Support Enabled
DEBUG - 2011-04-27 06:53:21 --> URI Class Initialized
DEBUG - 2011-04-27 06:53:21 --> Router Class Initialized
DEBUG - 2011-04-27 06:53:21 --> Output Class Initialized
DEBUG - 2011-04-27 06:53:21 --> Input Class Initialized
DEBUG - 2011-04-27 06:53:21 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-27 06:53:21 --> Language Class Initialized
DEBUG - 2011-04-27 06:53:21 --> Loader Class Initialized
DEBUG - 2011-04-27 06:53:21 --> Controller Class Initialized
DEBUG - 2011-04-27 06:53:21 --> Model Class Initialized
DEBUG - 2011-04-27 06:53:21 --> Model Class Initialized
DEBUG - 2011-04-27 06:53:21 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-27 06:53:21 --> Database Driver Class Initialized
DEBUG - 2011-04-27 06:53:21 --> Final output sent to browser
DEBUG - 2011-04-27 06:53:21 --> Total execution time: 0.6913
DEBUG - 2011-04-27 06:53:42 --> Config Class Initialized
DEBUG - 2011-04-27 06:53:42 --> Hooks Class Initialized
DEBUG - 2011-04-27 06:53:42 --> Utf8 Class Initialized
DEBUG - 2011-04-27 06:53:42 --> UTF-8 Support Enabled
DEBUG - 2011-04-27 06:53:42 --> URI Class Initialized
DEBUG - 2011-04-27 06:53:42 --> Router Class Initialized
DEBUG - 2011-04-27 06:53:42 --> Output Class Initialized
DEBUG - 2011-04-27 06:53:42 --> Input Class Initialized
DEBUG - 2011-04-27 06:53:42 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-27 06:53:42 --> Language Class Initialized
DEBUG - 2011-04-27 06:53:42 --> Loader Class Initialized
DEBUG - 2011-04-27 06:53:42 --> Controller Class Initialized
DEBUG - 2011-04-27 06:53:42 --> Model Class Initialized
DEBUG - 2011-04-27 06:53:42 --> Model Class Initialized
DEBUG - 2011-04-27 06:53:42 --> Model Class Initialized
DEBUG - 2011-04-27 06:53:42 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-27 06:53:42 --> Database Driver Class Initialized
DEBUG - 2011-04-27 06:53:42 --> File loaded: application/views/table/main.php
DEBUG - 2011-04-27 06:53:42 --> Helper loaded: url_helper
DEBUG - 2011-04-27 06:53:42 --> File loaded: application/views/common/header.php
DEBUG - 2011-04-27 06:53:42 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-04-27 06:53:42 --> File loaded: application/views/common/footer.php
DEBUG - 2011-04-27 06:53:42 --> File loaded: application/views/layout/main.php
DEBUG - 2011-04-27 06:53:42 --> Final output sent to browser
DEBUG - 2011-04-27 06:53:42 --> Total execution time: 0.0852
DEBUG - 2011-04-27 06:53:45 --> Config Class Initialized
DEBUG - 2011-04-27 06:53:45 --> Hooks Class Initialized
DEBUG - 2011-04-27 06:53:45 --> Utf8 Class Initialized
DEBUG - 2011-04-27 06:53:45 --> UTF-8 Support Enabled
DEBUG - 2011-04-27 06:53:45 --> URI Class Initialized
DEBUG - 2011-04-27 06:53:45 --> Router Class Initialized
DEBUG - 2011-04-27 06:53:45 --> Output Class Initialized
DEBUG - 2011-04-27 06:53:45 --> Input Class Initialized
DEBUG - 2011-04-27 06:53:45 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-27 06:53:45 --> Language Class Initialized
DEBUG - 2011-04-27 06:53:45 --> Loader Class Initialized
DEBUG - 2011-04-27 06:53:45 --> Controller Class Initialized
DEBUG - 2011-04-27 06:53:45 --> Model Class Initialized
DEBUG - 2011-04-27 06:53:45 --> Model Class Initialized
DEBUG - 2011-04-27 06:53:45 --> Model Class Initialized
DEBUG - 2011-04-27 06:53:45 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-27 06:53:45 --> Database Driver Class Initialized
DEBUG - 2011-04-27 06:53:45 --> File loaded: application/views/table/main.php
DEBUG - 2011-04-27 06:53:45 --> Helper loaded: url_helper
DEBUG - 2011-04-27 06:53:45 --> File loaded: application/views/common/header.php
DEBUG - 2011-04-27 06:53:45 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-04-27 06:53:45 --> File loaded: application/views/common/footer.php
DEBUG - 2011-04-27 06:53:45 --> File loaded: application/views/layout/main.php
DEBUG - 2011-04-27 06:53:45 --> Final output sent to browser
DEBUG - 2011-04-27 06:53:45 --> Total execution time: 0.0495
DEBUG - 2011-04-27 06:53:55 --> Config Class Initialized
DEBUG - 2011-04-27 06:53:55 --> Hooks Class Initialized
DEBUG - 2011-04-27 06:53:55 --> Utf8 Class Initialized
DEBUG - 2011-04-27 06:53:55 --> UTF-8 Support Enabled
DEBUG - 2011-04-27 06:53:55 --> URI Class Initialized
DEBUG - 2011-04-27 06:53:55 --> Router Class Initialized
DEBUG - 2011-04-27 06:53:55 --> Output Class Initialized
DEBUG - 2011-04-27 06:53:55 --> Input Class Initialized
DEBUG - 2011-04-27 06:53:55 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-27 06:53:55 --> Language Class Initialized
DEBUG - 2011-04-27 06:53:55 --> Loader Class Initialized
DEBUG - 2011-04-27 06:53:55 --> Controller Class Initialized
ERROR - 2011-04-27 06:53:55 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-04-27 06:53:55 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-04-27 06:53:55 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-04-27 06:53:55 --> Model Class Initialized
DEBUG - 2011-04-27 06:53:55 --> Model Class Initialized
DEBUG - 2011-04-27 06:53:55 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-27 06:53:55 --> Database Driver Class Initialized
DEBUG - 2011-04-27 06:53:55 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-04-27 06:53:55 --> Helper loaded: url_helper
DEBUG - 2011-04-27 06:53:55 --> File loaded: application/views/common/header.php
DEBUG - 2011-04-27 06:53:55 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-04-27 06:53:55 --> File loaded: application/views/common/footer.php
DEBUG - 2011-04-27 06:53:55 --> File loaded: application/views/layout/main.php
DEBUG - 2011-04-27 06:53:55 --> Final output sent to browser
DEBUG - 2011-04-27 06:53:55 --> Total execution time: 0.0294
DEBUG - 2011-04-27 06:53:57 --> Config Class Initialized
DEBUG - 2011-04-27 06:53:57 --> Hooks Class Initialized
DEBUG - 2011-04-27 06:53:57 --> Utf8 Class Initialized
DEBUG - 2011-04-27 06:53:57 --> UTF-8 Support Enabled
DEBUG - 2011-04-27 06:53:57 --> URI Class Initialized
DEBUG - 2011-04-27 06:53:57 --> Router Class Initialized
DEBUG - 2011-04-27 06:53:57 --> Output Class Initialized
DEBUG - 2011-04-27 06:53:57 --> Input Class Initialized
DEBUG - 2011-04-27 06:53:57 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-27 06:53:57 --> Language Class Initialized
DEBUG - 2011-04-27 06:53:57 --> Loader Class Initialized
DEBUG - 2011-04-27 06:53:57 --> Controller Class Initialized
DEBUG - 2011-04-27 06:53:57 --> Model Class Initialized
DEBUG - 2011-04-27 06:53:57 --> Model Class Initialized
DEBUG - 2011-04-27 06:53:57 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-27 06:53:57 --> Database Driver Class Initialized
DEBUG - 2011-04-27 06:53:58 --> Final output sent to browser
DEBUG - 2011-04-27 06:53:58 --> Total execution time: 0.6203
DEBUG - 2011-04-27 06:53:58 --> Config Class Initialized
DEBUG - 2011-04-27 06:53:58 --> Hooks Class Initialized
DEBUG - 2011-04-27 06:53:58 --> Utf8 Class Initialized
DEBUG - 2011-04-27 06:53:58 --> UTF-8 Support Enabled
DEBUG - 2011-04-27 06:53:58 --> URI Class Initialized
DEBUG - 2011-04-27 06:53:58 --> Router Class Initialized
DEBUG - 2011-04-27 06:53:58 --> Output Class Initialized
DEBUG - 2011-04-27 06:53:58 --> Input Class Initialized
DEBUG - 2011-04-27 06:53:58 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-27 06:53:58 --> Language Class Initialized
DEBUG - 2011-04-27 06:53:58 --> Loader Class Initialized
DEBUG - 2011-04-27 06:53:58 --> Controller Class Initialized
ERROR - 2011-04-27 06:53:58 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-04-27 06:53:58 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-04-27 06:53:58 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-04-27 06:53:58 --> Model Class Initialized
DEBUG - 2011-04-27 06:53:58 --> Model Class Initialized
DEBUG - 2011-04-27 06:53:58 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-27 06:53:58 --> Database Driver Class Initialized
DEBUG - 2011-04-27 06:53:58 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-04-27 06:53:58 --> Helper loaded: url_helper
DEBUG - 2011-04-27 06:53:58 --> File loaded: application/views/common/header.php
DEBUG - 2011-04-27 06:53:58 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-04-27 06:53:58 --> File loaded: application/views/common/footer.php
DEBUG - 2011-04-27 06:53:58 --> File loaded: application/views/layout/main.php
DEBUG - 2011-04-27 06:53:58 --> Final output sent to browser
DEBUG - 2011-04-27 06:53:58 --> Total execution time: 0.0342
DEBUG - 2011-04-27 08:48:47 --> Config Class Initialized
DEBUG - 2011-04-27 08:48:47 --> Hooks Class Initialized
DEBUG - 2011-04-27 08:48:47 --> Utf8 Class Initialized
DEBUG - 2011-04-27 08:48:47 --> UTF-8 Support Enabled
DEBUG - 2011-04-27 08:48:47 --> URI Class Initialized
DEBUG - 2011-04-27 08:48:47 --> Router Class Initialized
DEBUG - 2011-04-27 08:48:47 --> Output Class Initialized
DEBUG - 2011-04-27 08:48:47 --> Input Class Initialized
DEBUG - 2011-04-27 08:48:47 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-27 08:48:47 --> Language Class Initialized
DEBUG - 2011-04-27 08:48:47 --> Loader Class Initialized
DEBUG - 2011-04-27 08:48:47 --> Controller Class Initialized
DEBUG - 2011-04-27 08:48:47 --> Model Class Initialized
DEBUG - 2011-04-27 08:48:47 --> Model Class Initialized
DEBUG - 2011-04-27 08:48:47 --> Model Class Initialized
DEBUG - 2011-04-27 08:48:47 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-27 08:48:47 --> Database Driver Class Initialized
DEBUG - 2011-04-27 08:48:47 --> File loaded: application/views/table/main.php
DEBUG - 2011-04-27 08:48:47 --> Helper loaded: url_helper
DEBUG - 2011-04-27 08:48:47 --> File loaded: application/views/common/header.php
DEBUG - 2011-04-27 08:48:47 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-04-27 08:48:47 --> File loaded: application/views/common/footer.php
DEBUG - 2011-04-27 08:48:47 --> File loaded: application/views/layout/main.php
DEBUG - 2011-04-27 08:48:47 --> Final output sent to browser
DEBUG - 2011-04-27 08:48:47 --> Total execution time: 0.8256
DEBUG - 2011-04-27 08:48:51 --> Config Class Initialized
DEBUG - 2011-04-27 08:48:51 --> Hooks Class Initialized
DEBUG - 2011-04-27 08:48:51 --> Utf8 Class Initialized
DEBUG - 2011-04-27 08:48:51 --> UTF-8 Support Enabled
DEBUG - 2011-04-27 08:48:51 --> URI Class Initialized
DEBUG - 2011-04-27 08:48:51 --> Router Class Initialized
ERROR - 2011-04-27 08:48:52 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-04-27 08:49:09 --> Config Class Initialized
DEBUG - 2011-04-27 08:49:09 --> Hooks Class Initialized
DEBUG - 2011-04-27 08:49:09 --> Utf8 Class Initialized
DEBUG - 2011-04-27 08:49:09 --> UTF-8 Support Enabled
DEBUG - 2011-04-27 08:49:09 --> URI Class Initialized
DEBUG - 2011-04-27 08:49:09 --> Router Class Initialized
DEBUG - 2011-04-27 08:49:09 --> Output Class Initialized
DEBUG - 2011-04-27 08:49:09 --> Input Class Initialized
DEBUG - 2011-04-27 08:49:09 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-27 08:49:09 --> Language Class Initialized
DEBUG - 2011-04-27 08:49:09 --> Loader Class Initialized
DEBUG - 2011-04-27 08:49:09 --> Controller Class Initialized
DEBUG - 2011-04-27 08:49:09 --> Model Class Initialized
DEBUG - 2011-04-27 08:49:09 --> Model Class Initialized
DEBUG - 2011-04-27 08:49:09 --> Model Class Initialized
DEBUG - 2011-04-27 08:49:09 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-27 08:49:09 --> Database Driver Class Initialized
DEBUG - 2011-04-27 08:49:11 --> File loaded: application/views/table/main.php
DEBUG - 2011-04-27 08:49:11 --> Helper loaded: url_helper
DEBUG - 2011-04-27 08:49:11 --> File loaded: application/views/common/header.php
DEBUG - 2011-04-27 08:49:11 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-04-27 08:49:11 --> File loaded: application/views/common/footer.php
DEBUG - 2011-04-27 08:49:11 --> File loaded: application/views/layout/main.php
DEBUG - 2011-04-27 08:49:11 --> Final output sent to browser
DEBUG - 2011-04-27 08:49:11 --> Total execution time: 2.2301
DEBUG - 2011-04-27 08:49:14 --> Config Class Initialized
DEBUG - 2011-04-27 08:49:14 --> Hooks Class Initialized
DEBUG - 2011-04-27 08:49:14 --> Utf8 Class Initialized
DEBUG - 2011-04-27 08:49:14 --> UTF-8 Support Enabled
DEBUG - 2011-04-27 08:49:14 --> URI Class Initialized
DEBUG - 2011-04-27 08:49:14 --> Router Class Initialized
ERROR - 2011-04-27 08:49:14 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-04-27 08:49:52 --> Config Class Initialized
DEBUG - 2011-04-27 08:49:52 --> Hooks Class Initialized
DEBUG - 2011-04-27 08:49:52 --> Utf8 Class Initialized
DEBUG - 2011-04-27 08:49:52 --> UTF-8 Support Enabled
DEBUG - 2011-04-27 08:49:52 --> URI Class Initialized
DEBUG - 2011-04-27 08:49:52 --> Router Class Initialized
DEBUG - 2011-04-27 08:49:52 --> Output Class Initialized
DEBUG - 2011-04-27 08:49:52 --> Input Class Initialized
DEBUG - 2011-04-27 08:49:52 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-27 08:49:52 --> Language Class Initialized
DEBUG - 2011-04-27 08:49:52 --> Loader Class Initialized
DEBUG - 2011-04-27 08:49:52 --> Controller Class Initialized
DEBUG - 2011-04-27 08:49:52 --> Model Class Initialized
DEBUG - 2011-04-27 08:49:52 --> Model Class Initialized
DEBUG - 2011-04-27 08:49:52 --> Model Class Initialized
DEBUG - 2011-04-27 08:49:52 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-27 08:49:52 --> Database Driver Class Initialized
DEBUG - 2011-04-27 08:49:53 --> File loaded: application/views/table/main.php
DEBUG - 2011-04-27 08:49:53 --> Helper loaded: url_helper
DEBUG - 2011-04-27 08:49:53 --> File loaded: application/views/common/header.php
DEBUG - 2011-04-27 08:49:53 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-04-27 08:49:53 --> File loaded: application/views/common/footer.php
DEBUG - 2011-04-27 08:49:53 --> File loaded: application/views/layout/main.php
DEBUG - 2011-04-27 08:49:53 --> Final output sent to browser
DEBUG - 2011-04-27 08:49:53 --> Total execution time: 0.6097
DEBUG - 2011-04-27 08:49:55 --> Config Class Initialized
DEBUG - 2011-04-27 08:49:55 --> Hooks Class Initialized
DEBUG - 2011-04-27 08:49:55 --> Utf8 Class Initialized
DEBUG - 2011-04-27 08:49:55 --> UTF-8 Support Enabled
DEBUG - 2011-04-27 08:49:55 --> URI Class Initialized
DEBUG - 2011-04-27 08:49:55 --> Router Class Initialized
DEBUG - 2011-04-27 08:49:55 --> Output Class Initialized
DEBUG - 2011-04-27 08:49:55 --> Input Class Initialized
DEBUG - 2011-04-27 08:49:55 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-27 08:49:55 --> Language Class Initialized
DEBUG - 2011-04-27 08:49:55 --> Loader Class Initialized
DEBUG - 2011-04-27 08:49:55 --> Controller Class Initialized
DEBUG - 2011-04-27 08:49:55 --> Model Class Initialized
DEBUG - 2011-04-27 08:49:55 --> Model Class Initialized
DEBUG - 2011-04-27 08:49:55 --> Model Class Initialized
DEBUG - 2011-04-27 08:49:55 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-27 08:49:55 --> Database Driver Class Initialized
DEBUG - 2011-04-27 08:49:55 --> File loaded: application/views/table/main.php
DEBUG - 2011-04-27 08:49:55 --> Helper loaded: url_helper
DEBUG - 2011-04-27 08:49:55 --> File loaded: application/views/common/header.php
DEBUG - 2011-04-27 08:49:55 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-04-27 08:49:55 --> File loaded: application/views/common/footer.php
DEBUG - 2011-04-27 08:49:55 --> File loaded: application/views/layout/main.php
DEBUG - 2011-04-27 08:49:55 --> Final output sent to browser
DEBUG - 2011-04-27 08:49:55 --> Total execution time: 0.0979
DEBUG - 2011-04-27 08:49:55 --> Config Class Initialized
DEBUG - 2011-04-27 08:49:55 --> Hooks Class Initialized
DEBUG - 2011-04-27 08:49:55 --> Utf8 Class Initialized
DEBUG - 2011-04-27 08:49:55 --> UTF-8 Support Enabled
DEBUG - 2011-04-27 08:49:55 --> URI Class Initialized
DEBUG - 2011-04-27 08:49:55 --> Router Class Initialized
ERROR - 2011-04-27 08:49:55 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-04-27 13:35:31 --> Config Class Initialized
DEBUG - 2011-04-27 13:35:31 --> Hooks Class Initialized
DEBUG - 2011-04-27 13:35:31 --> Utf8 Class Initialized
DEBUG - 2011-04-27 13:35:31 --> UTF-8 Support Enabled
DEBUG - 2011-04-27 13:35:31 --> URI Class Initialized
DEBUG - 2011-04-27 13:35:31 --> Router Class Initialized
ERROR - 2011-04-27 13:35:31 --> 404 Page Not Found --> robots.txt
DEBUG - 2011-04-27 13:35:32 --> Config Class Initialized
DEBUG - 2011-04-27 13:35:32 --> Hooks Class Initialized
DEBUG - 2011-04-27 13:35:32 --> Utf8 Class Initialized
DEBUG - 2011-04-27 13:35:32 --> UTF-8 Support Enabled
DEBUG - 2011-04-27 13:35:32 --> URI Class Initialized
DEBUG - 2011-04-27 13:35:32 --> Router Class Initialized
DEBUG - 2011-04-27 13:35:32 --> Output Class Initialized
DEBUG - 2011-04-27 13:35:32 --> Input Class Initialized
DEBUG - 2011-04-27 13:35:32 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-27 13:35:32 --> Language Class Initialized
DEBUG - 2011-04-27 13:35:32 --> Loader Class Initialized
DEBUG - 2011-04-27 13:35:32 --> Controller Class Initialized
DEBUG - 2011-04-27 13:35:32 --> Model Class Initialized
DEBUG - 2011-04-27 13:35:32 --> Model Class Initialized
DEBUG - 2011-04-27 13:35:32 --> Model Class Initialized
DEBUG - 2011-04-27 13:35:32 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-27 13:35:32 --> Database Driver Class Initialized
DEBUG - 2011-04-27 13:35:32 --> File loaded: application/views/table/main.php
DEBUG - 2011-04-27 13:35:32 --> Helper loaded: url_helper
DEBUG - 2011-04-27 13:35:32 --> File loaded: application/views/common/header.php
DEBUG - 2011-04-27 13:35:32 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-04-27 13:35:32 --> File loaded: application/views/common/footer.php
DEBUG - 2011-04-27 13:35:32 --> File loaded: application/views/layout/main.php
DEBUG - 2011-04-27 13:35:32 --> Final output sent to browser
DEBUG - 2011-04-27 13:35:32 --> Total execution time: 0.4739
DEBUG - 2011-04-27 14:20:04 --> Config Class Initialized
DEBUG - 2011-04-27 14:20:04 --> Hooks Class Initialized
DEBUG - 2011-04-27 14:20:04 --> Utf8 Class Initialized
DEBUG - 2011-04-27 14:20:04 --> UTF-8 Support Enabled
DEBUG - 2011-04-27 14:20:04 --> URI Class Initialized
DEBUG - 2011-04-27 14:20:04 --> Router Class Initialized
DEBUG - 2011-04-27 14:20:04 --> Output Class Initialized
DEBUG - 2011-04-27 14:20:04 --> Input Class Initialized
DEBUG - 2011-04-27 14:20:04 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-27 14:20:04 --> Language Class Initialized
DEBUG - 2011-04-27 14:20:04 --> Loader Class Initialized
DEBUG - 2011-04-27 14:20:04 --> Controller Class Initialized
DEBUG - 2011-04-27 14:20:04 --> Model Class Initialized
DEBUG - 2011-04-27 14:20:04 --> Model Class Initialized
DEBUG - 2011-04-27 14:20:04 --> Model Class Initialized
DEBUG - 2011-04-27 14:20:04 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-27 14:20:04 --> Database Driver Class Initialized
DEBUG - 2011-04-27 14:20:05 --> File loaded: application/views/table/main.php
DEBUG - 2011-04-27 14:20:06 --> Helper loaded: url_helper
DEBUG - 2011-04-27 14:20:06 --> File loaded: application/views/common/header.php
DEBUG - 2011-04-27 14:20:06 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-04-27 14:20:06 --> File loaded: application/views/common/footer.php
DEBUG - 2011-04-27 14:20:06 --> File loaded: application/views/layout/main.php
DEBUG - 2011-04-27 14:20:06 --> Final output sent to browser
DEBUG - 2011-04-27 14:20:06 --> Total execution time: 2.3236
DEBUG - 2011-04-27 14:20:07 --> Config Class Initialized
DEBUG - 2011-04-27 14:20:07 --> Hooks Class Initialized
DEBUG - 2011-04-27 14:20:07 --> Utf8 Class Initialized
DEBUG - 2011-04-27 14:20:07 --> UTF-8 Support Enabled
DEBUG - 2011-04-27 14:20:07 --> URI Class Initialized
DEBUG - 2011-04-27 14:20:07 --> Router Class Initialized
DEBUG - 2011-04-27 14:20:07 --> Output Class Initialized
DEBUG - 2011-04-27 14:20:07 --> Input Class Initialized
DEBUG - 2011-04-27 14:20:07 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-27 14:20:07 --> Language Class Initialized
DEBUG - 2011-04-27 14:20:07 --> Loader Class Initialized
DEBUG - 2011-04-27 14:20:07 --> Controller Class Initialized
ERROR - 2011-04-27 14:20:07 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-04-27 14:20:07 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-04-27 14:20:07 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-04-27 14:20:07 --> Model Class Initialized
DEBUG - 2011-04-27 14:20:07 --> Model Class Initialized
DEBUG - 2011-04-27 14:20:07 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-27 14:20:07 --> Database Driver Class Initialized
DEBUG - 2011-04-27 14:20:07 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-04-27 14:20:07 --> Helper loaded: url_helper
DEBUG - 2011-04-27 14:20:07 --> File loaded: application/views/common/header.php
DEBUG - 2011-04-27 14:20:07 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-04-27 14:20:07 --> File loaded: application/views/common/footer.php
DEBUG - 2011-04-27 14:20:07 --> File loaded: application/views/layout/main.php
DEBUG - 2011-04-27 14:20:07 --> Final output sent to browser
DEBUG - 2011-04-27 14:20:07 --> Total execution time: 0.1886
DEBUG - 2011-04-27 14:21:40 --> Config Class Initialized
DEBUG - 2011-04-27 14:21:40 --> Hooks Class Initialized
DEBUG - 2011-04-27 14:21:40 --> Utf8 Class Initialized
DEBUG - 2011-04-27 14:21:40 --> UTF-8 Support Enabled
DEBUG - 2011-04-27 14:21:40 --> URI Class Initialized
DEBUG - 2011-04-27 14:21:40 --> Router Class Initialized
ERROR - 2011-04-27 14:21:40 --> 404 Page Not Found --> robots.txt
DEBUG - 2011-04-27 14:21:41 --> Config Class Initialized
DEBUG - 2011-04-27 14:21:41 --> Hooks Class Initialized
DEBUG - 2011-04-27 14:21:41 --> Utf8 Class Initialized
DEBUG - 2011-04-27 14:21:41 --> UTF-8 Support Enabled
DEBUG - 2011-04-27 14:21:41 --> URI Class Initialized
DEBUG - 2011-04-27 14:21:41 --> Router Class Initialized
DEBUG - 2011-04-27 14:21:41 --> Output Class Initialized
DEBUG - 2011-04-27 14:21:41 --> Input Class Initialized
DEBUG - 2011-04-27 14:21:41 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-27 14:21:41 --> Language Class Initialized
DEBUG - 2011-04-27 14:21:41 --> Loader Class Initialized
DEBUG - 2011-04-27 14:21:41 --> Controller Class Initialized
DEBUG - 2011-04-27 14:21:41 --> Model Class Initialized
DEBUG - 2011-04-27 14:21:41 --> Model Class Initialized
DEBUG - 2011-04-27 14:21:41 --> Model Class Initialized
DEBUG - 2011-04-27 14:21:41 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-27 14:21:41 --> Database Driver Class Initialized
DEBUG - 2011-04-27 14:21:41 --> File loaded: application/views/table/main.php
DEBUG - 2011-04-27 14:21:41 --> Helper loaded: url_helper
DEBUG - 2011-04-27 14:21:41 --> File loaded: application/views/common/header.php
DEBUG - 2011-04-27 14:21:41 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-04-27 14:21:41 --> File loaded: application/views/common/footer.php
DEBUG - 2011-04-27 14:21:41 --> File loaded: application/views/layout/main.php
DEBUG - 2011-04-27 14:21:41 --> Final output sent to browser
DEBUG - 2011-04-27 14:21:41 --> Total execution time: 0.0454
DEBUG - 2011-04-27 15:15:49 --> Config Class Initialized
DEBUG - 2011-04-27 15:15:49 --> Hooks Class Initialized
DEBUG - 2011-04-27 15:15:49 --> Utf8 Class Initialized
DEBUG - 2011-04-27 15:15:49 --> UTF-8 Support Enabled
DEBUG - 2011-04-27 15:15:49 --> URI Class Initialized
DEBUG - 2011-04-27 15:15:49 --> Router Class Initialized
DEBUG - 2011-04-27 15:15:49 --> Output Class Initialized
DEBUG - 2011-04-27 15:15:49 --> Input Class Initialized
DEBUG - 2011-04-27 15:15:49 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-27 15:15:49 --> Language Class Initialized
DEBUG - 2011-04-27 15:15:49 --> Loader Class Initialized
DEBUG - 2011-04-27 15:15:49 --> Controller Class Initialized
ERROR - 2011-04-27 15:15:49 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-04-27 15:15:49 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-04-27 15:15:49 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-04-27 15:15:49 --> Model Class Initialized
DEBUG - 2011-04-27 15:15:49 --> Model Class Initialized
DEBUG - 2011-04-27 15:15:49 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-27 15:15:49 --> Database Driver Class Initialized
DEBUG - 2011-04-27 15:15:49 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-04-27 15:15:49 --> Helper loaded: url_helper
DEBUG - 2011-04-27 15:15:49 --> File loaded: application/views/common/header.php
DEBUG - 2011-04-27 15:15:49 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-04-27 15:15:49 --> File loaded: application/views/common/footer.php
DEBUG - 2011-04-27 15:15:49 --> File loaded: application/views/layout/main.php
DEBUG - 2011-04-27 15:15:49 --> Final output sent to browser
DEBUG - 2011-04-27 15:15:49 --> Total execution time: 0.2810
DEBUG - 2011-04-27 15:15:50 --> Config Class Initialized
DEBUG - 2011-04-27 15:15:50 --> Hooks Class Initialized
DEBUG - 2011-04-27 15:15:50 --> Utf8 Class Initialized
DEBUG - 2011-04-27 15:15:50 --> UTF-8 Support Enabled
DEBUG - 2011-04-27 15:15:50 --> URI Class Initialized
DEBUG - 2011-04-27 15:15:50 --> Router Class Initialized
DEBUG - 2011-04-27 15:15:50 --> Output Class Initialized
DEBUG - 2011-04-27 15:15:50 --> Input Class Initialized
DEBUG - 2011-04-27 15:15:50 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-27 15:15:50 --> Language Class Initialized
DEBUG - 2011-04-27 15:15:50 --> Loader Class Initialized
DEBUG - 2011-04-27 15:15:50 --> Controller Class Initialized
DEBUG - 2011-04-27 15:15:50 --> Model Class Initialized
DEBUG - 2011-04-27 15:15:50 --> Model Class Initialized
DEBUG - 2011-04-27 15:15:50 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-27 15:15:50 --> Database Driver Class Initialized
DEBUG - 2011-04-27 15:15:51 --> Final output sent to browser
DEBUG - 2011-04-27 15:15:51 --> Total execution time: 0.6882
DEBUG - 2011-04-27 15:15:52 --> Config Class Initialized
DEBUG - 2011-04-27 15:15:52 --> Hooks Class Initialized
DEBUG - 2011-04-27 15:15:52 --> Utf8 Class Initialized
DEBUG - 2011-04-27 15:15:52 --> UTF-8 Support Enabled
DEBUG - 2011-04-27 15:15:52 --> URI Class Initialized
DEBUG - 2011-04-27 15:15:52 --> Router Class Initialized
ERROR - 2011-04-27 15:15:52 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-04-27 15:15:53 --> Config Class Initialized
DEBUG - 2011-04-27 15:15:53 --> Hooks Class Initialized
DEBUG - 2011-04-27 15:15:53 --> Utf8 Class Initialized
DEBUG - 2011-04-27 15:15:53 --> UTF-8 Support Enabled
DEBUG - 2011-04-27 15:15:53 --> URI Class Initialized
DEBUG - 2011-04-27 15:15:53 --> Router Class Initialized
ERROR - 2011-04-27 15:15:53 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-04-27 15:15:53 --> Config Class Initialized
DEBUG - 2011-04-27 15:15:53 --> Hooks Class Initialized
DEBUG - 2011-04-27 15:15:53 --> Utf8 Class Initialized
DEBUG - 2011-04-27 15:15:53 --> UTF-8 Support Enabled
DEBUG - 2011-04-27 15:15:53 --> URI Class Initialized
DEBUG - 2011-04-27 15:15:53 --> Router Class Initialized
ERROR - 2011-04-27 15:15:53 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-04-27 15:16:12 --> Config Class Initialized
DEBUG - 2011-04-27 15:16:12 --> Hooks Class Initialized
DEBUG - 2011-04-27 15:16:12 --> Utf8 Class Initialized
DEBUG - 2011-04-27 15:16:12 --> UTF-8 Support Enabled
DEBUG - 2011-04-27 15:16:12 --> URI Class Initialized
DEBUG - 2011-04-27 15:16:12 --> Router Class Initialized
DEBUG - 2011-04-27 15:16:12 --> Output Class Initialized
DEBUG - 2011-04-27 15:16:12 --> Input Class Initialized
DEBUG - 2011-04-27 15:16:12 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-27 15:16:12 --> Language Class Initialized
DEBUG - 2011-04-27 15:16:12 --> Loader Class Initialized
DEBUG - 2011-04-27 15:16:12 --> Controller Class Initialized
ERROR - 2011-04-27 15:16:12 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-04-27 15:16:12 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-04-27 15:16:12 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-04-27 15:16:12 --> Model Class Initialized
DEBUG - 2011-04-27 15:16:12 --> Model Class Initialized
DEBUG - 2011-04-27 15:16:12 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-27 15:16:12 --> Database Driver Class Initialized
DEBUG - 2011-04-27 15:16:12 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-04-27 15:16:12 --> Helper loaded: url_helper
DEBUG - 2011-04-27 15:16:12 --> File loaded: application/views/common/header.php
DEBUG - 2011-04-27 15:16:12 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-04-27 15:16:12 --> File loaded: application/views/common/footer.php
DEBUG - 2011-04-27 15:16:12 --> File loaded: application/views/layout/main.php
DEBUG - 2011-04-27 15:16:12 --> Final output sent to browser
DEBUG - 2011-04-27 15:16:12 --> Total execution time: 0.0363
DEBUG - 2011-04-27 15:16:13 --> Config Class Initialized
DEBUG - 2011-04-27 15:16:13 --> Hooks Class Initialized
DEBUG - 2011-04-27 15:16:13 --> Utf8 Class Initialized
DEBUG - 2011-04-27 15:16:13 --> UTF-8 Support Enabled
DEBUG - 2011-04-27 15:16:13 --> URI Class Initialized
DEBUG - 2011-04-27 15:16:13 --> Router Class Initialized
DEBUG - 2011-04-27 15:16:13 --> Output Class Initialized
DEBUG - 2011-04-27 15:16:13 --> Input Class Initialized
DEBUG - 2011-04-27 15:16:13 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-27 15:16:13 --> Language Class Initialized
DEBUG - 2011-04-27 15:16:13 --> Loader Class Initialized
DEBUG - 2011-04-27 15:16:13 --> Controller Class Initialized
DEBUG - 2011-04-27 15:16:13 --> Model Class Initialized
DEBUG - 2011-04-27 15:16:13 --> Model Class Initialized
DEBUG - 2011-04-27 15:16:13 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-27 15:16:13 --> Database Driver Class Initialized
DEBUG - 2011-04-27 15:16:14 --> Final output sent to browser
DEBUG - 2011-04-27 15:16:14 --> Total execution time: 0.6947
DEBUG - 2011-04-27 15:16:37 --> Config Class Initialized
DEBUG - 2011-04-27 15:16:37 --> Hooks Class Initialized
DEBUG - 2011-04-27 15:16:37 --> Utf8 Class Initialized
DEBUG - 2011-04-27 15:16:37 --> UTF-8 Support Enabled
DEBUG - 2011-04-27 15:16:37 --> URI Class Initialized
DEBUG - 2011-04-27 15:16:37 --> Router Class Initialized
DEBUG - 2011-04-27 15:16:37 --> Output Class Initialized
DEBUG - 2011-04-27 15:16:37 --> Input Class Initialized
DEBUG - 2011-04-27 15:16:37 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-27 15:16:37 --> Language Class Initialized
DEBUG - 2011-04-27 15:16:37 --> Loader Class Initialized
DEBUG - 2011-04-27 15:16:37 --> Controller Class Initialized
ERROR - 2011-04-27 15:16:37 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-04-27 15:16:37 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-04-27 15:16:37 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-04-27 15:16:37 --> Model Class Initialized
DEBUG - 2011-04-27 15:16:37 --> Model Class Initialized
DEBUG - 2011-04-27 15:16:37 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-27 15:16:37 --> Database Driver Class Initialized
DEBUG - 2011-04-27 15:16:37 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-04-27 15:16:37 --> Helper loaded: url_helper
DEBUG - 2011-04-27 15:16:37 --> File loaded: application/views/common/header.php
DEBUG - 2011-04-27 15:16:37 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-04-27 15:16:37 --> File loaded: application/views/common/footer.php
DEBUG - 2011-04-27 15:16:37 --> File loaded: application/views/layout/main.php
DEBUG - 2011-04-27 15:16:37 --> Final output sent to browser
DEBUG - 2011-04-27 15:16:37 --> Total execution time: 0.0337
DEBUG - 2011-04-27 15:16:38 --> Config Class Initialized
DEBUG - 2011-04-27 15:16:38 --> Hooks Class Initialized
DEBUG - 2011-04-27 15:16:38 --> Utf8 Class Initialized
DEBUG - 2011-04-27 15:16:38 --> UTF-8 Support Enabled
DEBUG - 2011-04-27 15:16:38 --> URI Class Initialized
DEBUG - 2011-04-27 15:16:38 --> Router Class Initialized
DEBUG - 2011-04-27 15:16:38 --> Output Class Initialized
DEBUG - 2011-04-27 15:16:38 --> Input Class Initialized
DEBUG - 2011-04-27 15:16:38 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-27 15:16:38 --> Language Class Initialized
DEBUG - 2011-04-27 15:16:38 --> Loader Class Initialized
DEBUG - 2011-04-27 15:16:38 --> Controller Class Initialized
DEBUG - 2011-04-27 15:16:38 --> Model Class Initialized
DEBUG - 2011-04-27 15:16:38 --> Model Class Initialized
DEBUG - 2011-04-27 15:16:38 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-27 15:16:38 --> Database Driver Class Initialized
DEBUG - 2011-04-27 15:16:38 --> Final output sent to browser
DEBUG - 2011-04-27 15:16:38 --> Total execution time: 0.5210
DEBUG - 2011-04-27 16:13:33 --> Config Class Initialized
DEBUG - 2011-04-27 16:13:33 --> Hooks Class Initialized
DEBUG - 2011-04-27 16:13:33 --> Utf8 Class Initialized
DEBUG - 2011-04-27 16:13:33 --> UTF-8 Support Enabled
DEBUG - 2011-04-27 16:13:33 --> URI Class Initialized
DEBUG - 2011-04-27 16:13:33 --> Router Class Initialized
DEBUG - 2011-04-27 16:13:33 --> Output Class Initialized
DEBUG - 2011-04-27 16:13:33 --> Input Class Initialized
DEBUG - 2011-04-27 16:13:33 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-27 16:13:33 --> Language Class Initialized
DEBUG - 2011-04-27 16:13:33 --> Loader Class Initialized
DEBUG - 2011-04-27 16:13:33 --> Controller Class Initialized
ERROR - 2011-04-27 16:13:33 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-04-27 16:13:33 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-04-27 16:13:33 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-04-27 16:13:33 --> Model Class Initialized
DEBUG - 2011-04-27 16:13:33 --> Model Class Initialized
DEBUG - 2011-04-27 16:13:33 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-27 16:13:33 --> Database Driver Class Initialized
DEBUG - 2011-04-27 16:13:33 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-04-27 16:13:33 --> Helper loaded: url_helper
DEBUG - 2011-04-27 16:13:33 --> File loaded: application/views/common/header.php
DEBUG - 2011-04-27 16:13:33 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-04-27 16:13:33 --> File loaded: application/views/common/footer.php
DEBUG - 2011-04-27 16:13:33 --> File loaded: application/views/layout/main.php
DEBUG - 2011-04-27 16:13:33 --> Final output sent to browser
DEBUG - 2011-04-27 16:13:33 --> Total execution time: 0.2798
DEBUG - 2011-04-27 16:13:34 --> Config Class Initialized
DEBUG - 2011-04-27 16:13:34 --> Hooks Class Initialized
DEBUG - 2011-04-27 16:13:34 --> Utf8 Class Initialized
DEBUG - 2011-04-27 16:13:34 --> UTF-8 Support Enabled
DEBUG - 2011-04-27 16:13:34 --> URI Class Initialized
DEBUG - 2011-04-27 16:13:34 --> Router Class Initialized
DEBUG - 2011-04-27 16:13:34 --> Output Class Initialized
DEBUG - 2011-04-27 16:13:34 --> Input Class Initialized
DEBUG - 2011-04-27 16:13:34 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-27 16:13:34 --> Language Class Initialized
DEBUG - 2011-04-27 16:13:34 --> Loader Class Initialized
DEBUG - 2011-04-27 16:13:34 --> Controller Class Initialized
DEBUG - 2011-04-27 16:13:34 --> Model Class Initialized
DEBUG - 2011-04-27 16:13:34 --> Model Class Initialized
DEBUG - 2011-04-27 16:13:34 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-27 16:13:34 --> Database Driver Class Initialized
DEBUG - 2011-04-27 16:13:34 --> Final output sent to browser
DEBUG - 2011-04-27 16:13:34 --> Total execution time: 0.7380
DEBUG - 2011-04-27 16:13:35 --> Config Class Initialized
DEBUG - 2011-04-27 16:13:35 --> Hooks Class Initialized
DEBUG - 2011-04-27 16:13:35 --> Utf8 Class Initialized
DEBUG - 2011-04-27 16:13:35 --> UTF-8 Support Enabled
DEBUG - 2011-04-27 16:13:35 --> URI Class Initialized
DEBUG - 2011-04-27 16:13:35 --> Router Class Initialized
ERROR - 2011-04-27 16:13:35 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-04-27 16:13:36 --> Config Class Initialized
DEBUG - 2011-04-27 16:13:36 --> Hooks Class Initialized
DEBUG - 2011-04-27 16:13:36 --> Utf8 Class Initialized
DEBUG - 2011-04-27 16:13:36 --> UTF-8 Support Enabled
DEBUG - 2011-04-27 16:13:36 --> URI Class Initialized
DEBUG - 2011-04-27 16:13:36 --> Router Class Initialized
ERROR - 2011-04-27 16:13:36 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-04-27 16:13:53 --> Config Class Initialized
DEBUG - 2011-04-27 16:13:53 --> Hooks Class Initialized
DEBUG - 2011-04-27 16:13:53 --> Utf8 Class Initialized
DEBUG - 2011-04-27 16:13:53 --> UTF-8 Support Enabled
DEBUG - 2011-04-27 16:13:53 --> URI Class Initialized
DEBUG - 2011-04-27 16:13:53 --> Router Class Initialized
DEBUG - 2011-04-27 16:13:53 --> Output Class Initialized
DEBUG - 2011-04-27 16:13:53 --> Input Class Initialized
DEBUG - 2011-04-27 16:13:53 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-27 16:13:53 --> Language Class Initialized
DEBUG - 2011-04-27 16:13:53 --> Loader Class Initialized
DEBUG - 2011-04-27 16:13:53 --> Controller Class Initialized
ERROR - 2011-04-27 16:13:53 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-04-27 16:13:53 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-04-27 16:13:53 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-04-27 16:13:53 --> Model Class Initialized
DEBUG - 2011-04-27 16:13:53 --> Model Class Initialized
DEBUG - 2011-04-27 16:13:53 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-27 16:13:53 --> Database Driver Class Initialized
DEBUG - 2011-04-27 16:13:53 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-04-27 16:13:53 --> Helper loaded: url_helper
DEBUG - 2011-04-27 16:13:53 --> File loaded: application/views/common/header.php
DEBUG - 2011-04-27 16:13:53 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-04-27 16:13:53 --> File loaded: application/views/common/footer.php
DEBUG - 2011-04-27 16:13:53 --> File loaded: application/views/layout/main.php
DEBUG - 2011-04-27 16:13:53 --> Final output sent to browser
DEBUG - 2011-04-27 16:13:53 --> Total execution time: 0.0294
DEBUG - 2011-04-27 16:13:53 --> Config Class Initialized
DEBUG - 2011-04-27 16:13:53 --> Hooks Class Initialized
DEBUG - 2011-04-27 16:13:53 --> Utf8 Class Initialized
DEBUG - 2011-04-27 16:13:53 --> UTF-8 Support Enabled
DEBUG - 2011-04-27 16:13:53 --> URI Class Initialized
DEBUG - 2011-04-27 16:13:53 --> Router Class Initialized
DEBUG - 2011-04-27 16:13:53 --> Output Class Initialized
DEBUG - 2011-04-27 16:13:53 --> Input Class Initialized
DEBUG - 2011-04-27 16:13:53 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-27 16:13:53 --> Language Class Initialized
DEBUG - 2011-04-27 16:13:53 --> Loader Class Initialized
DEBUG - 2011-04-27 16:13:53 --> Controller Class Initialized
DEBUG - 2011-04-27 16:13:53 --> Model Class Initialized
DEBUG - 2011-04-27 16:13:53 --> Model Class Initialized
DEBUG - 2011-04-27 16:13:53 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-27 16:13:53 --> Database Driver Class Initialized
DEBUG - 2011-04-27 16:13:53 --> Final output sent to browser
DEBUG - 2011-04-27 16:13:53 --> Total execution time: 0.6530
DEBUG - 2011-04-27 17:01:17 --> Config Class Initialized
DEBUG - 2011-04-27 17:01:17 --> Hooks Class Initialized
DEBUG - 2011-04-27 17:01:17 --> Utf8 Class Initialized
DEBUG - 2011-04-27 17:01:17 --> UTF-8 Support Enabled
DEBUG - 2011-04-27 17:01:17 --> URI Class Initialized
DEBUG - 2011-04-27 17:01:17 --> Router Class Initialized
DEBUG - 2011-04-27 17:01:17 --> Output Class Initialized
DEBUG - 2011-04-27 17:01:17 --> Input Class Initialized
DEBUG - 2011-04-27 17:01:17 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-27 17:01:17 --> Language Class Initialized
DEBUG - 2011-04-27 17:01:17 --> Loader Class Initialized
DEBUG - 2011-04-27 17:01:17 --> Controller Class Initialized
ERROR - 2011-04-27 17:01:17 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-04-27 17:01:17 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-04-27 17:01:17 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-04-27 17:01:17 --> Model Class Initialized
DEBUG - 2011-04-27 17:01:17 --> Model Class Initialized
DEBUG - 2011-04-27 17:01:17 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-27 17:01:17 --> Database Driver Class Initialized
DEBUG - 2011-04-27 17:01:17 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-04-27 17:01:17 --> Helper loaded: url_helper
DEBUG - 2011-04-27 17:01:17 --> File loaded: application/views/common/header.php
DEBUG - 2011-04-27 17:01:17 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-04-27 17:01:17 --> File loaded: application/views/common/footer.php
DEBUG - 2011-04-27 17:01:17 --> File loaded: application/views/layout/main.php
DEBUG - 2011-04-27 17:01:17 --> Final output sent to browser
DEBUG - 2011-04-27 17:01:17 --> Total execution time: 0.2737
DEBUG - 2011-04-27 17:01:18 --> Config Class Initialized
DEBUG - 2011-04-27 17:01:18 --> Hooks Class Initialized
DEBUG - 2011-04-27 17:01:18 --> Utf8 Class Initialized
DEBUG - 2011-04-27 17:01:18 --> UTF-8 Support Enabled
DEBUG - 2011-04-27 17:01:18 --> URI Class Initialized
DEBUG - 2011-04-27 17:01:18 --> Router Class Initialized
DEBUG - 2011-04-27 17:01:18 --> Output Class Initialized
DEBUG - 2011-04-27 17:01:18 --> Input Class Initialized
DEBUG - 2011-04-27 17:01:18 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-27 17:01:18 --> Language Class Initialized
DEBUG - 2011-04-27 17:01:18 --> Loader Class Initialized
DEBUG - 2011-04-27 17:01:18 --> Controller Class Initialized
DEBUG - 2011-04-27 17:01:18 --> Model Class Initialized
DEBUG - 2011-04-27 17:01:18 --> Model Class Initialized
DEBUG - 2011-04-27 17:01:18 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-27 17:01:18 --> Database Driver Class Initialized
DEBUG - 2011-04-27 17:01:19 --> Final output sent to browser
DEBUG - 2011-04-27 17:01:19 --> Total execution time: 1.0694
DEBUG - 2011-04-27 17:01:20 --> Config Class Initialized
DEBUG - 2011-04-27 17:01:20 --> Hooks Class Initialized
DEBUG - 2011-04-27 17:01:20 --> Utf8 Class Initialized
DEBUG - 2011-04-27 17:01:20 --> UTF-8 Support Enabled
DEBUG - 2011-04-27 17:01:20 --> URI Class Initialized
DEBUG - 2011-04-27 17:01:20 --> Router Class Initialized
ERROR - 2011-04-27 17:01:20 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-04-27 17:01:21 --> Config Class Initialized
DEBUG - 2011-04-27 17:01:21 --> Hooks Class Initialized
DEBUG - 2011-04-27 17:01:21 --> Utf8 Class Initialized
DEBUG - 2011-04-27 17:01:21 --> UTF-8 Support Enabled
DEBUG - 2011-04-27 17:01:21 --> URI Class Initialized
DEBUG - 2011-04-27 17:01:21 --> Router Class Initialized
ERROR - 2011-04-27 17:01:21 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-04-27 17:01:49 --> Config Class Initialized
DEBUG - 2011-04-27 17:01:49 --> Hooks Class Initialized
DEBUG - 2011-04-27 17:01:49 --> Utf8 Class Initialized
DEBUG - 2011-04-27 17:01:49 --> UTF-8 Support Enabled
DEBUG - 2011-04-27 17:01:49 --> URI Class Initialized
DEBUG - 2011-04-27 17:01:49 --> Router Class Initialized
ERROR - 2011-04-27 17:01:49 --> 404 Page Not Found --> robots.txt
DEBUG - 2011-04-27 18:55:40 --> Config Class Initialized
DEBUG - 2011-04-27 18:55:40 --> Hooks Class Initialized
DEBUG - 2011-04-27 18:55:40 --> Utf8 Class Initialized
DEBUG - 2011-04-27 18:55:40 --> UTF-8 Support Enabled
DEBUG - 2011-04-27 18:55:40 --> URI Class Initialized
DEBUG - 2011-04-27 18:55:40 --> Router Class Initialized
DEBUG - 2011-04-27 18:55:40 --> Output Class Initialized
DEBUG - 2011-04-27 18:55:40 --> Input Class Initialized
DEBUG - 2011-04-27 18:55:40 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-27 18:55:40 --> Language Class Initialized
DEBUG - 2011-04-27 18:55:40 --> Loader Class Initialized
DEBUG - 2011-04-27 18:55:40 --> Controller Class Initialized
DEBUG - 2011-04-27 18:55:40 --> Model Class Initialized
DEBUG - 2011-04-27 18:55:40 --> Model Class Initialized
DEBUG - 2011-04-27 18:55:40 --> Model Class Initialized
DEBUG - 2011-04-27 18:55:40 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-27 18:55:40 --> Database Driver Class Initialized
DEBUG - 2011-04-27 18:55:41 --> File loaded: application/views/table/main.php
DEBUG - 2011-04-27 18:55:41 --> Helper loaded: url_helper
DEBUG - 2011-04-27 18:55:41 --> File loaded: application/views/common/header.php
DEBUG - 2011-04-27 18:55:41 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-04-27 18:55:41 --> File loaded: application/views/common/footer.php
DEBUG - 2011-04-27 18:55:41 --> File loaded: application/views/layout/main.php
DEBUG - 2011-04-27 18:55:41 --> Final output sent to browser
DEBUG - 2011-04-27 18:55:41 --> Total execution time: 0.8202
DEBUG - 2011-04-27 18:55:44 --> Config Class Initialized
DEBUG - 2011-04-27 18:55:44 --> Hooks Class Initialized
DEBUG - 2011-04-27 18:55:44 --> Utf8 Class Initialized
DEBUG - 2011-04-27 18:55:44 --> UTF-8 Support Enabled
DEBUG - 2011-04-27 18:55:44 --> URI Class Initialized
DEBUG - 2011-04-27 18:55:44 --> Router Class Initialized
DEBUG - 2011-04-27 18:55:44 --> Output Class Initialized
DEBUG - 2011-04-27 18:55:44 --> Input Class Initialized
DEBUG - 2011-04-27 18:55:44 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-27 18:55:44 --> Language Class Initialized
DEBUG - 2011-04-27 18:55:44 --> Loader Class Initialized
DEBUG - 2011-04-27 18:55:44 --> Controller Class Initialized
ERROR - 2011-04-27 18:55:45 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-04-27 18:55:45 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-04-27 18:55:45 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-04-27 18:55:45 --> Model Class Initialized
DEBUG - 2011-04-27 18:55:45 --> Model Class Initialized
DEBUG - 2011-04-27 18:55:45 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-27 18:55:45 --> Database Driver Class Initialized
DEBUG - 2011-04-27 18:55:45 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-04-27 18:55:45 --> Helper loaded: url_helper
DEBUG - 2011-04-27 18:55:45 --> File loaded: application/views/common/header.php
DEBUG - 2011-04-27 18:55:45 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-04-27 18:55:45 --> File loaded: application/views/common/footer.php
DEBUG - 2011-04-27 18:55:45 --> File loaded: application/views/layout/main.php
DEBUG - 2011-04-27 18:55:45 --> Final output sent to browser
DEBUG - 2011-04-27 18:55:45 --> Total execution time: 0.8011
DEBUG - 2011-04-27 19:04:41 --> Config Class Initialized
DEBUG - 2011-04-27 19:04:41 --> Hooks Class Initialized
DEBUG - 2011-04-27 19:04:41 --> Utf8 Class Initialized
DEBUG - 2011-04-27 19:04:41 --> UTF-8 Support Enabled
DEBUG - 2011-04-27 19:04:41 --> URI Class Initialized
DEBUG - 2011-04-27 19:04:41 --> Router Class Initialized
DEBUG - 2011-04-27 19:04:41 --> Output Class Initialized
DEBUG - 2011-04-27 19:04:41 --> Input Class Initialized
DEBUG - 2011-04-27 19:04:41 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-27 19:04:41 --> Language Class Initialized
DEBUG - 2011-04-27 19:04:41 --> Loader Class Initialized
DEBUG - 2011-04-27 19:04:41 --> Controller Class Initialized
ERROR - 2011-04-27 19:04:41 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-04-27 19:04:41 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-04-27 19:04:41 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-04-27 19:04:41 --> Model Class Initialized
DEBUG - 2011-04-27 19:04:41 --> Model Class Initialized
DEBUG - 2011-04-27 19:04:41 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-27 19:04:41 --> Database Driver Class Initialized
DEBUG - 2011-04-27 19:04:41 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-04-27 19:04:41 --> Helper loaded: url_helper
DEBUG - 2011-04-27 19:04:41 --> File loaded: application/views/common/header.php
DEBUG - 2011-04-27 19:04:41 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-04-27 19:04:41 --> File loaded: application/views/common/footer.php
DEBUG - 2011-04-27 19:04:41 --> File loaded: application/views/layout/main.php
DEBUG - 2011-04-27 19:04:41 --> Final output sent to browser
DEBUG - 2011-04-27 19:04:41 --> Total execution time: 0.0485
DEBUG - 2011-04-27 19:04:42 --> Config Class Initialized
DEBUG - 2011-04-27 19:04:42 --> Hooks Class Initialized
DEBUG - 2011-04-27 19:04:42 --> Utf8 Class Initialized
DEBUG - 2011-04-27 19:04:42 --> UTF-8 Support Enabled
DEBUG - 2011-04-27 19:04:42 --> URI Class Initialized
DEBUG - 2011-04-27 19:04:42 --> Router Class Initialized
DEBUG - 2011-04-27 19:04:42 --> Output Class Initialized
DEBUG - 2011-04-27 19:04:42 --> Input Class Initialized
DEBUG - 2011-04-27 19:04:42 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-27 19:04:42 --> Language Class Initialized
DEBUG - 2011-04-27 19:04:42 --> Loader Class Initialized
DEBUG - 2011-04-27 19:04:42 --> Controller Class Initialized
DEBUG - 2011-04-27 19:04:42 --> Model Class Initialized
DEBUG - 2011-04-27 19:04:42 --> Model Class Initialized
DEBUG - 2011-04-27 19:04:42 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-27 19:04:42 --> Database Driver Class Initialized
DEBUG - 2011-04-27 19:04:43 --> Final output sent to browser
DEBUG - 2011-04-27 19:04:43 --> Total execution time: 0.7974
DEBUG - 2011-04-27 19:04:44 --> Config Class Initialized
DEBUG - 2011-04-27 19:04:44 --> Hooks Class Initialized
DEBUG - 2011-04-27 19:04:44 --> Utf8 Class Initialized
DEBUG - 2011-04-27 19:04:44 --> UTF-8 Support Enabled
DEBUG - 2011-04-27 19:04:44 --> URI Class Initialized
DEBUG - 2011-04-27 19:04:44 --> Router Class Initialized
ERROR - 2011-04-27 19:04:44 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-04-27 19:04:44 --> Config Class Initialized
DEBUG - 2011-04-27 19:04:44 --> Hooks Class Initialized
DEBUG - 2011-04-27 19:04:44 --> Utf8 Class Initialized
DEBUG - 2011-04-27 19:04:44 --> UTF-8 Support Enabled
DEBUG - 2011-04-27 19:04:44 --> URI Class Initialized
DEBUG - 2011-04-27 19:04:44 --> Router Class Initialized
ERROR - 2011-04-27 19:04:44 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-04-27 19:35:56 --> Config Class Initialized
DEBUG - 2011-04-27 19:35:56 --> Hooks Class Initialized
DEBUG - 2011-04-27 19:35:56 --> Utf8 Class Initialized
DEBUG - 2011-04-27 19:35:56 --> UTF-8 Support Enabled
DEBUG - 2011-04-27 19:35:56 --> URI Class Initialized
DEBUG - 2011-04-27 19:35:56 --> Router Class Initialized
ERROR - 2011-04-27 19:35:56 --> 404 Page Not Found --> robots.txt
DEBUG - 2011-04-27 19:36:38 --> Config Class Initialized
DEBUG - 2011-04-27 19:36:38 --> Hooks Class Initialized
DEBUG - 2011-04-27 19:36:38 --> Utf8 Class Initialized
DEBUG - 2011-04-27 19:36:38 --> UTF-8 Support Enabled
DEBUG - 2011-04-27 19:36:38 --> URI Class Initialized
DEBUG - 2011-04-27 19:36:38 --> Router Class Initialized
DEBUG - 2011-04-27 19:36:38 --> No URI present. Default controller set.
DEBUG - 2011-04-27 19:36:38 --> Output Class Initialized
DEBUG - 2011-04-27 19:36:38 --> Input Class Initialized
DEBUG - 2011-04-27 19:36:38 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-27 19:36:38 --> Language Class Initialized
DEBUG - 2011-04-27 19:36:38 --> Loader Class Initialized
DEBUG - 2011-04-27 19:36:38 --> Controller Class Initialized
DEBUG - 2011-04-27 19:36:38 --> File loaded: application/views/splash/main.php
DEBUG - 2011-04-27 19:36:38 --> Helper loaded: url_helper
DEBUG - 2011-04-27 19:36:38 --> File loaded: application/views/common/header.php
DEBUG - 2011-04-27 19:36:38 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-04-27 19:36:38 --> File loaded: application/views/common/footer.php
DEBUG - 2011-04-27 19:36:38 --> File loaded: application/views/layout/main.php
DEBUG - 2011-04-27 19:36:38 --> Final output sent to browser
DEBUG - 2011-04-27 19:36:38 --> Total execution time: 0.1291
DEBUG - 2011-04-27 20:33:05 --> Config Class Initialized
DEBUG - 2011-04-27 20:33:05 --> Hooks Class Initialized
DEBUG - 2011-04-27 20:33:05 --> Utf8 Class Initialized
DEBUG - 2011-04-27 20:33:05 --> UTF-8 Support Enabled
DEBUG - 2011-04-27 20:33:05 --> URI Class Initialized
DEBUG - 2011-04-27 20:33:05 --> Router Class Initialized
ERROR - 2011-04-27 20:33:05 --> 404 Page Not Found --> robots.txt
DEBUG - 2011-04-27 20:33:06 --> Config Class Initialized
DEBUG - 2011-04-27 20:33:06 --> Hooks Class Initialized
DEBUG - 2011-04-27 20:33:06 --> Utf8 Class Initialized
DEBUG - 2011-04-27 20:33:06 --> UTF-8 Support Enabled
DEBUG - 2011-04-27 20:33:06 --> URI Class Initialized
DEBUG - 2011-04-27 20:33:06 --> Router Class Initialized
DEBUG - 2011-04-27 20:33:06 --> No URI present. Default controller set.
DEBUG - 2011-04-27 20:33:06 --> Output Class Initialized
DEBUG - 2011-04-27 20:33:06 --> Input Class Initialized
DEBUG - 2011-04-27 20:33:06 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-27 20:33:06 --> Language Class Initialized
DEBUG - 2011-04-27 20:33:06 --> Loader Class Initialized
DEBUG - 2011-04-27 20:33:06 --> Controller Class Initialized
DEBUG - 2011-04-27 20:33:06 --> File loaded: application/views/splash/main.php
DEBUG - 2011-04-27 20:33:07 --> Helper loaded: url_helper
DEBUG - 2011-04-27 20:33:07 --> File loaded: application/views/common/header.php
DEBUG - 2011-04-27 20:33:07 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-04-27 20:33:07 --> File loaded: application/views/common/footer.php
DEBUG - 2011-04-27 20:33:07 --> File loaded: application/views/layout/main.php
DEBUG - 2011-04-27 20:33:07 --> Final output sent to browser
DEBUG - 2011-04-27 20:33:07 --> Total execution time: 1.4647
DEBUG - 2011-04-27 21:33:36 --> Config Class Initialized
DEBUG - 2011-04-27 21:33:36 --> Hooks Class Initialized
DEBUG - 2011-04-27 21:33:36 --> Utf8 Class Initialized
DEBUG - 2011-04-27 21:33:36 --> UTF-8 Support Enabled
DEBUG - 2011-04-27 21:33:36 --> URI Class Initialized
DEBUG - 2011-04-27 21:33:36 --> Router Class Initialized
DEBUG - 2011-04-27 21:33:36 --> Output Class Initialized
DEBUG - 2011-04-27 21:33:36 --> Input Class Initialized
DEBUG - 2011-04-27 21:33:36 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-27 21:33:36 --> Language Class Initialized
DEBUG - 2011-04-27 21:33:36 --> Loader Class Initialized
DEBUG - 2011-04-27 21:33:36 --> Controller Class Initialized
DEBUG - 2011-04-27 21:33:36 --> Model Class Initialized
DEBUG - 2011-04-27 21:33:36 --> Model Class Initialized
DEBUG - 2011-04-27 21:33:36 --> Model Class Initialized
DEBUG - 2011-04-27 21:33:36 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-27 21:33:37 --> Database Driver Class Initialized
DEBUG - 2011-04-27 21:33:37 --> File loaded: application/views/table/main.php
DEBUG - 2011-04-27 21:33:37 --> Helper loaded: url_helper
DEBUG - 2011-04-27 21:33:37 --> File loaded: application/views/common/header.php
DEBUG - 2011-04-27 21:33:37 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-04-27 21:33:37 --> File loaded: application/views/common/footer.php
DEBUG - 2011-04-27 21:33:37 --> File loaded: application/views/layout/main.php
DEBUG - 2011-04-27 21:33:37 --> Final output sent to browser
DEBUG - 2011-04-27 21:33:37 --> Total execution time: 0.7330
DEBUG - 2011-04-27 21:33:38 --> Config Class Initialized
DEBUG - 2011-04-27 21:33:38 --> Hooks Class Initialized
DEBUG - 2011-04-27 21:33:38 --> Utf8 Class Initialized
DEBUG - 2011-04-27 21:33:38 --> UTF-8 Support Enabled
DEBUG - 2011-04-27 21:33:38 --> URI Class Initialized
DEBUG - 2011-04-27 21:33:38 --> Router Class Initialized
DEBUG - 2011-04-27 21:33:38 --> Output Class Initialized
DEBUG - 2011-04-27 21:33:38 --> Input Class Initialized
DEBUG - 2011-04-27 21:33:38 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-27 21:33:38 --> Language Class Initialized
DEBUG - 2011-04-27 21:33:38 --> Loader Class Initialized
DEBUG - 2011-04-27 21:33:38 --> Controller Class Initialized
ERROR - 2011-04-27 21:33:38 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-04-27 21:33:38 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-04-27 21:33:38 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-04-27 21:33:38 --> Model Class Initialized
DEBUG - 2011-04-27 21:33:38 --> Model Class Initialized
DEBUG - 2011-04-27 21:33:38 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-27 21:33:38 --> Database Driver Class Initialized
DEBUG - 2011-04-27 21:33:38 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-04-27 21:33:38 --> Helper loaded: url_helper
DEBUG - 2011-04-27 21:33:38 --> File loaded: application/views/common/header.php
DEBUG - 2011-04-27 21:33:38 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-04-27 21:33:38 --> File loaded: application/views/common/footer.php
DEBUG - 2011-04-27 21:33:38 --> File loaded: application/views/layout/main.php
DEBUG - 2011-04-27 21:33:38 --> Final output sent to browser
DEBUG - 2011-04-27 21:33:38 --> Total execution time: 0.1133
DEBUG - 2011-04-27 22:13:13 --> Config Class Initialized
DEBUG - 2011-04-27 22:13:13 --> Hooks Class Initialized
DEBUG - 2011-04-27 22:13:13 --> Utf8 Class Initialized
DEBUG - 2011-04-27 22:13:13 --> UTF-8 Support Enabled
DEBUG - 2011-04-27 22:13:13 --> URI Class Initialized
DEBUG - 2011-04-27 22:13:13 --> Router Class Initialized
ERROR - 2011-04-27 22:13:13 --> 404 Page Not Found --> robots.txt
DEBUG - 2011-04-27 22:13:24 --> Config Class Initialized
DEBUG - 2011-04-27 22:13:24 --> Hooks Class Initialized
DEBUG - 2011-04-27 22:13:24 --> Utf8 Class Initialized
DEBUG - 2011-04-27 22:13:24 --> UTF-8 Support Enabled
DEBUG - 2011-04-27 22:13:24 --> URI Class Initialized
DEBUG - 2011-04-27 22:13:24 --> Router Class Initialized
DEBUG - 2011-04-27 22:13:24 --> Output Class Initialized
DEBUG - 2011-04-27 22:13:24 --> Input Class Initialized
DEBUG - 2011-04-27 22:13:24 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-27 22:13:24 --> Language Class Initialized
DEBUG - 2011-04-27 22:13:24 --> Loader Class Initialized
DEBUG - 2011-04-27 22:13:24 --> Controller Class Initialized
ERROR - 2011-04-27 22:13:24 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-04-27 22:13:24 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-04-27 22:13:24 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-04-27 22:13:24 --> Model Class Initialized
DEBUG - 2011-04-27 22:13:24 --> Model Class Initialized
DEBUG - 2011-04-27 22:13:24 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-27 22:13:24 --> Database Driver Class Initialized
DEBUG - 2011-04-27 22:13:24 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-04-27 22:13:24 --> Helper loaded: url_helper
DEBUG - 2011-04-27 22:13:24 --> File loaded: application/views/common/header.php
DEBUG - 2011-04-27 22:13:24 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-04-27 22:13:24 --> File loaded: application/views/common/footer.php
DEBUG - 2011-04-27 22:13:24 --> File loaded: application/views/layout/main.php
DEBUG - 2011-04-27 22:13:24 --> Final output sent to browser
DEBUG - 2011-04-27 22:13:24 --> Total execution time: 0.0806
DEBUG - 2011-04-27 22:13:26 --> Config Class Initialized
DEBUG - 2011-04-27 22:13:26 --> Hooks Class Initialized
DEBUG - 2011-04-27 22:13:26 --> Utf8 Class Initialized
DEBUG - 2011-04-27 22:13:26 --> UTF-8 Support Enabled
DEBUG - 2011-04-27 22:13:26 --> URI Class Initialized
DEBUG - 2011-04-27 22:13:26 --> Router Class Initialized
DEBUG - 2011-04-27 22:13:26 --> Output Class Initialized
DEBUG - 2011-04-27 22:13:26 --> Input Class Initialized
DEBUG - 2011-04-27 22:13:26 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-27 22:13:26 --> Language Class Initialized
DEBUG - 2011-04-27 22:13:26 --> Loader Class Initialized
DEBUG - 2011-04-27 22:13:26 --> Controller Class Initialized
DEBUG - 2011-04-27 22:13:26 --> Model Class Initialized
DEBUG - 2011-04-27 22:13:26 --> Model Class Initialized
DEBUG - 2011-04-27 22:13:26 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-27 22:13:26 --> Database Driver Class Initialized
DEBUG - 2011-04-27 22:13:27 --> Final output sent to browser
DEBUG - 2011-04-27 22:13:27 --> Total execution time: 0.6566
DEBUG - 2011-04-27 22:14:13 --> Config Class Initialized
DEBUG - 2011-04-27 22:14:13 --> Hooks Class Initialized
DEBUG - 2011-04-27 22:14:13 --> Utf8 Class Initialized
DEBUG - 2011-04-27 22:14:13 --> UTF-8 Support Enabled
DEBUG - 2011-04-27 22:14:13 --> URI Class Initialized
DEBUG - 2011-04-27 22:14:13 --> Router Class Initialized
DEBUG - 2011-04-27 22:14:13 --> No URI present. Default controller set.
DEBUG - 2011-04-27 22:14:13 --> Output Class Initialized
DEBUG - 2011-04-27 22:14:13 --> Input Class Initialized
DEBUG - 2011-04-27 22:14:13 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-27 22:14:13 --> Language Class Initialized
DEBUG - 2011-04-27 22:14:13 --> Loader Class Initialized
DEBUG - 2011-04-27 22:14:13 --> Controller Class Initialized
DEBUG - 2011-04-27 22:14:13 --> File loaded: application/views/splash/main.php
DEBUG - 2011-04-27 22:14:13 --> Helper loaded: url_helper
DEBUG - 2011-04-27 22:14:13 --> File loaded: application/views/common/header.php
DEBUG - 2011-04-27 22:14:13 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-04-27 22:14:13 --> File loaded: application/views/common/footer.php
DEBUG - 2011-04-27 22:14:13 --> File loaded: application/views/layout/main.php
DEBUG - 2011-04-27 22:14:13 --> Final output sent to browser
DEBUG - 2011-04-27 22:14:13 --> Total execution time: 0.2521
DEBUG - 2011-04-27 22:36:39 --> Config Class Initialized
DEBUG - 2011-04-27 22:36:39 --> Hooks Class Initialized
DEBUG - 2011-04-27 22:36:39 --> Utf8 Class Initialized
DEBUG - 2011-04-27 22:36:39 --> UTF-8 Support Enabled
DEBUG - 2011-04-27 22:36:39 --> URI Class Initialized
DEBUG - 2011-04-27 22:36:39 --> Router Class Initialized
DEBUG - 2011-04-27 22:36:39 --> Output Class Initialized
DEBUG - 2011-04-27 22:36:39 --> Input Class Initialized
DEBUG - 2011-04-27 22:36:39 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-27 22:36:39 --> Language Class Initialized
DEBUG - 2011-04-27 22:36:39 --> Loader Class Initialized
DEBUG - 2011-04-27 22:36:39 --> Controller Class Initialized
DEBUG - 2011-04-27 22:36:39 --> Model Class Initialized
DEBUG - 2011-04-27 22:36:39 --> Model Class Initialized
DEBUG - 2011-04-27 22:36:39 --> Model Class Initialized
DEBUG - 2011-04-27 22:36:39 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-27 22:36:39 --> Database Driver Class Initialized
DEBUG - 2011-04-27 22:36:40 --> File loaded: application/views/table/main.php
DEBUG - 2011-04-27 22:36:40 --> Helper loaded: url_helper
DEBUG - 2011-04-27 22:36:40 --> File loaded: application/views/common/header.php
DEBUG - 2011-04-27 22:36:40 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-04-27 22:36:40 --> File loaded: application/views/common/footer.php
DEBUG - 2011-04-27 22:36:40 --> File loaded: application/views/layout/main.php
DEBUG - 2011-04-27 22:36:40 --> Final output sent to browser
DEBUG - 2011-04-27 22:36:40 --> Total execution time: 0.4498
DEBUG - 2011-04-27 22:36:45 --> Config Class Initialized
DEBUG - 2011-04-27 22:36:45 --> Hooks Class Initialized
DEBUG - 2011-04-27 22:36:45 --> Utf8 Class Initialized
DEBUG - 2011-04-27 22:36:45 --> UTF-8 Support Enabled
DEBUG - 2011-04-27 22:36:45 --> URI Class Initialized
DEBUG - 2011-04-27 22:36:45 --> Router Class Initialized
DEBUG - 2011-04-27 22:36:45 --> Output Class Initialized
DEBUG - 2011-04-27 22:36:45 --> Input Class Initialized
DEBUG - 2011-04-27 22:36:45 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-27 22:36:45 --> Language Class Initialized
DEBUG - 2011-04-27 22:36:45 --> Loader Class Initialized
DEBUG - 2011-04-27 22:36:45 --> Controller Class Initialized
ERROR - 2011-04-27 22:36:45 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-04-27 22:36:45 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-04-27 22:36:45 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-04-27 22:36:45 --> Model Class Initialized
DEBUG - 2011-04-27 22:36:45 --> Model Class Initialized
DEBUG - 2011-04-27 22:36:45 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-27 22:36:45 --> Database Driver Class Initialized
DEBUG - 2011-04-27 22:36:45 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-04-27 22:36:45 --> Helper loaded: url_helper
DEBUG - 2011-04-27 22:36:45 --> File loaded: application/views/common/header.php
DEBUG - 2011-04-27 22:36:45 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-04-27 22:36:45 --> File loaded: application/views/common/footer.php
DEBUG - 2011-04-27 22:36:45 --> File loaded: application/views/layout/main.php
DEBUG - 2011-04-27 22:36:45 --> Final output sent to browser
DEBUG - 2011-04-27 22:36:45 --> Total execution time: 0.0350
DEBUG - 2011-04-27 23:03:14 --> Config Class Initialized
DEBUG - 2011-04-27 23:03:14 --> Hooks Class Initialized
DEBUG - 2011-04-27 23:03:14 --> Utf8 Class Initialized
DEBUG - 2011-04-27 23:03:14 --> UTF-8 Support Enabled
DEBUG - 2011-04-27 23:03:14 --> URI Class Initialized
DEBUG - 2011-04-27 23:03:14 --> Router Class Initialized
ERROR - 2011-04-27 23:03:14 --> 404 Page Not Found --> robots.txt
DEBUG - 2011-04-27 23:03:14 --> Config Class Initialized
DEBUG - 2011-04-27 23:03:14 --> Hooks Class Initialized
DEBUG - 2011-04-27 23:03:14 --> Utf8 Class Initialized
DEBUG - 2011-04-27 23:03:14 --> UTF-8 Support Enabled
DEBUG - 2011-04-27 23:03:14 --> URI Class Initialized
DEBUG - 2011-04-27 23:03:14 --> Router Class Initialized
DEBUG - 2011-04-27 23:03:14 --> Output Class Initialized
DEBUG - 2011-04-27 23:03:14 --> Input Class Initialized
DEBUG - 2011-04-27 23:03:14 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-27 23:03:14 --> Language Class Initialized
DEBUG - 2011-04-27 23:03:14 --> Loader Class Initialized
DEBUG - 2011-04-27 23:03:14 --> Controller Class Initialized
ERROR - 2011-04-27 23:03:14 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-04-27 23:03:14 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-04-27 23:03:14 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-04-27 23:03:14 --> Model Class Initialized
DEBUG - 2011-04-27 23:03:14 --> Model Class Initialized
DEBUG - 2011-04-27 23:03:14 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-27 23:03:14 --> Database Driver Class Initialized
DEBUG - 2011-04-27 23:03:14 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-04-27 23:03:14 --> Helper loaded: url_helper
DEBUG - 2011-04-27 23:03:14 --> File loaded: application/views/common/header.php
DEBUG - 2011-04-27 23:03:14 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-04-27 23:03:14 --> File loaded: application/views/common/footer.php
DEBUG - 2011-04-27 23:03:14 --> File loaded: application/views/layout/main.php
DEBUG - 2011-04-27 23:03:14 --> Final output sent to browser
DEBUG - 2011-04-27 23:03:14 --> Total execution time: 0.1396
DEBUG - 2011-04-27 23:29:06 --> Config Class Initialized
DEBUG - 2011-04-27 23:29:06 --> Hooks Class Initialized
DEBUG - 2011-04-27 23:29:06 --> Utf8 Class Initialized
DEBUG - 2011-04-27 23:29:06 --> UTF-8 Support Enabled
DEBUG - 2011-04-27 23:29:06 --> URI Class Initialized
DEBUG - 2011-04-27 23:29:06 --> Router Class Initialized
DEBUG - 2011-04-27 23:29:06 --> Output Class Initialized
DEBUG - 2011-04-27 23:29:06 --> Input Class Initialized
DEBUG - 2011-04-27 23:29:06 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-27 23:29:06 --> Language Class Initialized
DEBUG - 2011-04-27 23:29:06 --> Loader Class Initialized
DEBUG - 2011-04-27 23:29:06 --> Controller Class Initialized
DEBUG - 2011-04-27 23:29:06 --> Model Class Initialized
DEBUG - 2011-04-27 23:29:06 --> Model Class Initialized
DEBUG - 2011-04-27 23:29:06 --> Model Class Initialized
DEBUG - 2011-04-27 23:29:06 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-27 23:29:06 --> Database Driver Class Initialized
DEBUG - 2011-04-27 23:29:07 --> File loaded: application/views/table/main.php
DEBUG - 2011-04-27 23:29:07 --> Helper loaded: url_helper
DEBUG - 2011-04-27 23:29:07 --> File loaded: application/views/common/header.php
DEBUG - 2011-04-27 23:29:07 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-04-27 23:29:07 --> File loaded: application/views/common/footer.php
DEBUG - 2011-04-27 23:29:07 --> File loaded: application/views/layout/main.php
DEBUG - 2011-04-27 23:29:07 --> Final output sent to browser
DEBUG - 2011-04-27 23:29:07 --> Total execution time: 0.3947
DEBUG - 2011-04-27 23:29:08 --> Config Class Initialized
DEBUG - 2011-04-27 23:29:08 --> Hooks Class Initialized
DEBUG - 2011-04-27 23:29:08 --> Utf8 Class Initialized
DEBUG - 2011-04-27 23:29:08 --> UTF-8 Support Enabled
DEBUG - 2011-04-27 23:29:08 --> URI Class Initialized
DEBUG - 2011-04-27 23:29:08 --> Router Class Initialized
DEBUG - 2011-04-27 23:29:08 --> Output Class Initialized
DEBUG - 2011-04-27 23:29:08 --> Input Class Initialized
DEBUG - 2011-04-27 23:29:08 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-27 23:29:08 --> Language Class Initialized
DEBUG - 2011-04-27 23:29:08 --> Loader Class Initialized
DEBUG - 2011-04-27 23:29:08 --> Controller Class Initialized
ERROR - 2011-04-27 23:29:08 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-04-27 23:29:08 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-04-27 23:29:08 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-04-27 23:29:08 --> Model Class Initialized
DEBUG - 2011-04-27 23:29:08 --> Model Class Initialized
DEBUG - 2011-04-27 23:29:08 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-27 23:29:08 --> Database Driver Class Initialized
DEBUG - 2011-04-27 23:29:08 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-04-27 23:29:08 --> Helper loaded: url_helper
DEBUG - 2011-04-27 23:29:08 --> File loaded: application/views/common/header.php
DEBUG - 2011-04-27 23:29:08 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-04-27 23:29:08 --> File loaded: application/views/common/footer.php
DEBUG - 2011-04-27 23:29:08 --> File loaded: application/views/layout/main.php
DEBUG - 2011-04-27 23:29:08 --> Final output sent to browser
DEBUG - 2011-04-27 23:29:08 --> Total execution time: 0.0570
DEBUG - 2011-04-27 23:44:49 --> Config Class Initialized
DEBUG - 2011-04-27 23:44:49 --> Hooks Class Initialized
DEBUG - 2011-04-27 23:44:49 --> Utf8 Class Initialized
DEBUG - 2011-04-27 23:44:49 --> UTF-8 Support Enabled
DEBUG - 2011-04-27 23:44:49 --> URI Class Initialized
DEBUG - 2011-04-27 23:44:49 --> Router Class Initialized
DEBUG - 2011-04-27 23:44:49 --> Output Class Initialized
DEBUG - 2011-04-27 23:44:49 --> Input Class Initialized
DEBUG - 2011-04-27 23:44:49 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-27 23:44:49 --> Language Class Initialized
DEBUG - 2011-04-27 23:44:49 --> Loader Class Initialized
DEBUG - 2011-04-27 23:44:49 --> Controller Class Initialized
DEBUG - 2011-04-27 23:44:49 --> Model Class Initialized
DEBUG - 2011-04-27 23:44:49 --> Model Class Initialized
DEBUG - 2011-04-27 23:44:49 --> Model Class Initialized
DEBUG - 2011-04-27 23:44:49 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-27 23:44:49 --> Database Driver Class Initialized
DEBUG - 2011-04-27 23:44:49 --> File loaded: application/views/table/main.php
DEBUG - 2011-04-27 23:44:49 --> Helper loaded: url_helper
DEBUG - 2011-04-27 23:44:49 --> File loaded: application/views/common/header.php
DEBUG - 2011-04-27 23:44:49 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-04-27 23:44:49 --> File loaded: application/views/common/footer.php
DEBUG - 2011-04-27 23:44:49 --> File loaded: application/views/layout/main.php
DEBUG - 2011-04-27 23:44:49 --> Final output sent to browser
DEBUG - 2011-04-27 23:44:49 --> Total execution time: 0.1822
DEBUG - 2011-04-27 23:44:51 --> Config Class Initialized
DEBUG - 2011-04-27 23:44:51 --> Hooks Class Initialized
DEBUG - 2011-04-27 23:44:51 --> Utf8 Class Initialized
DEBUG - 2011-04-27 23:44:51 --> UTF-8 Support Enabled
DEBUG - 2011-04-27 23:44:51 --> URI Class Initialized
DEBUG - 2011-04-27 23:44:51 --> Router Class Initialized
ERROR - 2011-04-27 23:44:51 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-04-27 23:50:53 --> Config Class Initialized
DEBUG - 2011-04-27 23:50:53 --> Hooks Class Initialized
DEBUG - 2011-04-27 23:50:53 --> Utf8 Class Initialized
DEBUG - 2011-04-27 23:50:53 --> UTF-8 Support Enabled
DEBUG - 2011-04-27 23:50:53 --> URI Class Initialized
DEBUG - 2011-04-27 23:50:53 --> Router Class Initialized
DEBUG - 2011-04-27 23:50:53 --> Output Class Initialized
DEBUG - 2011-04-27 23:50:53 --> Input Class Initialized
DEBUG - 2011-04-27 23:50:53 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-27 23:50:53 --> Language Class Initialized
DEBUG - 2011-04-27 23:50:53 --> Loader Class Initialized
DEBUG - 2011-04-27 23:50:53 --> Controller Class Initialized
DEBUG - 2011-04-27 23:50:53 --> Model Class Initialized
DEBUG - 2011-04-27 23:50:53 --> Model Class Initialized
DEBUG - 2011-04-27 23:50:53 --> Model Class Initialized
DEBUG - 2011-04-27 23:50:53 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-27 23:50:53 --> Database Driver Class Initialized
DEBUG - 2011-04-27 23:50:53 --> File loaded: application/views/table/main.php
DEBUG - 2011-04-27 23:50:53 --> Helper loaded: url_helper
DEBUG - 2011-04-27 23:50:53 --> File loaded: application/views/common/header.php
DEBUG - 2011-04-27 23:50:53 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-04-27 23:50:53 --> File loaded: application/views/common/footer.php
DEBUG - 2011-04-27 23:50:54 --> File loaded: application/views/layout/main.php
DEBUG - 2011-04-27 23:50:54 --> Final output sent to browser
DEBUG - 2011-04-27 23:50:54 --> Total execution time: 0.0736
DEBUG - 2011-04-27 23:54:19 --> Config Class Initialized
DEBUG - 2011-04-27 23:54:19 --> Hooks Class Initialized
DEBUG - 2011-04-27 23:54:19 --> Utf8 Class Initialized
DEBUG - 2011-04-27 23:54:19 --> UTF-8 Support Enabled
DEBUG - 2011-04-27 23:54:19 --> URI Class Initialized
DEBUG - 2011-04-27 23:54:19 --> Router Class Initialized
ERROR - 2011-04-27 23:54:19 --> 404 Page Not Found --> robots.txt

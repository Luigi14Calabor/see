<?php  if ( ! defined('BASEPATH')) exit('No direct script access allowed'); ?>

DEBUG - 2011-05-21 00:44:09 --> Config Class Initialized
DEBUG - 2011-05-21 00:44:09 --> Hooks Class Initialized
DEBUG - 2011-05-21 00:44:09 --> Utf8 Class Initialized
DEBUG - 2011-05-21 00:44:09 --> UTF-8 Support Enabled
DEBUG - 2011-05-21 00:44:09 --> URI Class Initialized
DEBUG - 2011-05-21 00:44:09 --> Router Class Initialized
DEBUG - 2011-05-21 00:44:09 --> Output Class Initialized
DEBUG - 2011-05-21 00:44:09 --> Input Class Initialized
DEBUG - 2011-05-21 00:44:09 --> Global POST and COOKIE data sanitized
DEBUG - 2011-05-21 00:44:09 --> Language Class Initialized
DEBUG - 2011-05-21 00:44:09 --> Loader Class Initialized
DEBUG - 2011-05-21 00:44:09 --> Controller Class Initialized
ERROR - 2011-05-21 00:44:09 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-05-21 00:44:09 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-05-21 00:44:09 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-05-21 00:44:09 --> Model Class Initialized
DEBUG - 2011-05-21 00:44:09 --> Model Class Initialized
DEBUG - 2011-05-21 00:44:09 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-05-21 00:44:09 --> Database Driver Class Initialized
DEBUG - 2011-05-21 00:44:09 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-05-21 00:44:09 --> Helper loaded: url_helper
DEBUG - 2011-05-21 00:44:09 --> File loaded: application/views/common/header.php
DEBUG - 2011-05-21 00:44:09 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-05-21 00:44:09 --> File loaded: application/views/common/footer.php
DEBUG - 2011-05-21 00:44:09 --> File loaded: application/views/layout/main.php
DEBUG - 2011-05-21 00:44:09 --> Final output sent to browser
DEBUG - 2011-05-21 00:44:09 --> Total execution time: 0.8594
DEBUG - 2011-05-21 01:03:50 --> Config Class Initialized
DEBUG - 2011-05-21 01:03:50 --> Hooks Class Initialized
DEBUG - 2011-05-21 01:03:50 --> Utf8 Class Initialized
DEBUG - 2011-05-21 01:03:50 --> UTF-8 Support Enabled
DEBUG - 2011-05-21 01:03:50 --> URI Class Initialized
DEBUG - 2011-05-21 01:03:50 --> Router Class Initialized
ERROR - 2011-05-21 01:03:50 --> 404 Page Not Found --> robots.txt
DEBUG - 2011-05-21 01:36:39 --> Config Class Initialized
DEBUG - 2011-05-21 01:36:39 --> Hooks Class Initialized
DEBUG - 2011-05-21 01:36:39 --> Utf8 Class Initialized
DEBUG - 2011-05-21 01:36:39 --> UTF-8 Support Enabled
DEBUG - 2011-05-21 01:36:39 --> URI Class Initialized
DEBUG - 2011-05-21 01:36:39 --> Router Class Initialized
DEBUG - 2011-05-21 01:36:39 --> No URI present. Default controller set.
DEBUG - 2011-05-21 01:36:39 --> Output Class Initialized
DEBUG - 2011-05-21 01:36:39 --> Input Class Initialized
DEBUG - 2011-05-21 01:36:39 --> Global POST and COOKIE data sanitized
DEBUG - 2011-05-21 01:36:40 --> Language Class Initialized
DEBUG - 2011-05-21 01:36:40 --> Loader Class Initialized
DEBUG - 2011-05-21 01:36:40 --> Controller Class Initialized
DEBUG - 2011-05-21 01:36:41 --> File loaded: application/views/splash/main.php
DEBUG - 2011-05-21 01:36:43 --> Helper loaded: url_helper
DEBUG - 2011-05-21 01:36:43 --> File loaded: application/views/common/header.php
DEBUG - 2011-05-21 01:36:43 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-05-21 01:36:43 --> File loaded: application/views/common/footer.php
DEBUG - 2011-05-21 01:36:43 --> File loaded: application/views/layout/main.php
DEBUG - 2011-05-21 01:36:43 --> Final output sent to browser
DEBUG - 2011-05-21 01:36:43 --> Total execution time: 6.1338
DEBUG - 2011-05-21 05:30:37 --> Config Class Initialized
DEBUG - 2011-05-21 05:30:37 --> Hooks Class Initialized
DEBUG - 2011-05-21 05:30:37 --> Utf8 Class Initialized
DEBUG - 2011-05-21 05:30:37 --> UTF-8 Support Enabled
DEBUG - 2011-05-21 05:30:37 --> URI Class Initialized
DEBUG - 2011-05-21 05:30:37 --> Router Class Initialized
DEBUG - 2011-05-21 05:30:38 --> Output Class Initialized
DEBUG - 2011-05-21 05:30:38 --> Input Class Initialized
DEBUG - 2011-05-21 05:30:38 --> Global POST and COOKIE data sanitized
DEBUG - 2011-05-21 05:30:38 --> Language Class Initialized
DEBUG - 2011-05-21 05:30:38 --> Loader Class Initialized
DEBUG - 2011-05-21 05:30:38 --> Controller Class Initialized
DEBUG - 2011-05-21 05:30:38 --> Model Class Initialized
DEBUG - 2011-05-21 05:30:38 --> Model Class Initialized
DEBUG - 2011-05-21 05:30:38 --> Model Class Initialized
DEBUG - 2011-05-21 05:30:38 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-05-21 05:30:38 --> Database Driver Class Initialized
DEBUG - 2011-05-21 05:30:42 --> File loaded: application/views/table/main.php
DEBUG - 2011-05-21 05:30:42 --> Helper loaded: url_helper
DEBUG - 2011-05-21 05:30:42 --> File loaded: application/views/common/header.php
DEBUG - 2011-05-21 05:30:42 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-05-21 05:30:42 --> File loaded: application/views/common/footer.php
DEBUG - 2011-05-21 05:30:42 --> File loaded: application/views/layout/main.php
DEBUG - 2011-05-21 05:30:42 --> Final output sent to browser
DEBUG - 2011-05-21 05:30:42 --> Total execution time: 5.1366
DEBUG - 2011-05-21 05:30:44 --> Config Class Initialized
DEBUG - 2011-05-21 05:30:44 --> Hooks Class Initialized
DEBUG - 2011-05-21 05:30:44 --> Utf8 Class Initialized
DEBUG - 2011-05-21 05:30:44 --> UTF-8 Support Enabled
DEBUG - 2011-05-21 05:30:44 --> URI Class Initialized
DEBUG - 2011-05-21 05:30:44 --> Router Class Initialized
DEBUG - 2011-05-21 05:30:44 --> Output Class Initialized
DEBUG - 2011-05-21 05:30:44 --> Input Class Initialized
DEBUG - 2011-05-21 05:30:44 --> Global POST and COOKIE data sanitized
DEBUG - 2011-05-21 05:30:44 --> Language Class Initialized
DEBUG - 2011-05-21 05:30:44 --> Loader Class Initialized
DEBUG - 2011-05-21 05:30:44 --> Controller Class Initialized
ERROR - 2011-05-21 05:30:44 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-05-21 05:30:44 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-05-21 05:30:44 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-05-21 05:30:44 --> Model Class Initialized
DEBUG - 2011-05-21 05:30:44 --> Model Class Initialized
DEBUG - 2011-05-21 05:30:44 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-05-21 05:30:44 --> Database Driver Class Initialized
DEBUG - 2011-05-21 05:30:44 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-05-21 05:30:44 --> Helper loaded: url_helper
DEBUG - 2011-05-21 05:30:44 --> File loaded: application/views/common/header.php
DEBUG - 2011-05-21 05:30:44 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-05-21 05:30:44 --> File loaded: application/views/common/footer.php
DEBUG - 2011-05-21 05:30:44 --> File loaded: application/views/layout/main.php
DEBUG - 2011-05-21 05:30:44 --> Final output sent to browser
DEBUG - 2011-05-21 05:30:44 --> Total execution time: 0.1070
DEBUG - 2011-05-21 05:33:08 --> Config Class Initialized
DEBUG - 2011-05-21 05:33:08 --> Hooks Class Initialized
DEBUG - 2011-05-21 05:33:08 --> Utf8 Class Initialized
DEBUG - 2011-05-21 05:33:08 --> UTF-8 Support Enabled
DEBUG - 2011-05-21 05:33:08 --> URI Class Initialized
DEBUG - 2011-05-21 05:33:08 --> Router Class Initialized
DEBUG - 2011-05-21 05:33:08 --> Output Class Initialized
DEBUG - 2011-05-21 05:33:08 --> Input Class Initialized
DEBUG - 2011-05-21 05:33:08 --> Global POST and COOKIE data sanitized
DEBUG - 2011-05-21 05:33:08 --> Language Class Initialized
DEBUG - 2011-05-21 05:33:08 --> Loader Class Initialized
DEBUG - 2011-05-21 05:33:08 --> Controller Class Initialized
DEBUG - 2011-05-21 05:33:08 --> Model Class Initialized
DEBUG - 2011-05-21 05:33:08 --> Model Class Initialized
DEBUG - 2011-05-21 05:33:08 --> Model Class Initialized
DEBUG - 2011-05-21 05:33:08 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-05-21 05:33:08 --> Database Driver Class Initialized
DEBUG - 2011-05-21 05:33:08 --> File loaded: application/views/table/main.php
DEBUG - 2011-05-21 05:33:08 --> Helper loaded: url_helper
DEBUG - 2011-05-21 05:33:08 --> File loaded: application/views/common/header.php
DEBUG - 2011-05-21 05:33:08 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-05-21 05:33:08 --> File loaded: application/views/common/footer.php
DEBUG - 2011-05-21 05:33:08 --> File loaded: application/views/layout/main.php
DEBUG - 2011-05-21 05:33:08 --> Final output sent to browser
DEBUG - 2011-05-21 05:33:08 --> Total execution time: 0.0715
DEBUG - 2011-05-21 05:33:13 --> Config Class Initialized
DEBUG - 2011-05-21 05:33:13 --> Hooks Class Initialized
DEBUG - 2011-05-21 05:33:13 --> Utf8 Class Initialized
DEBUG - 2011-05-21 05:33:13 --> UTF-8 Support Enabled
DEBUG - 2011-05-21 05:33:13 --> URI Class Initialized
DEBUG - 2011-05-21 05:33:13 --> Router Class Initialized
ERROR - 2011-05-21 05:33:13 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-05-21 05:33:27 --> Config Class Initialized
DEBUG - 2011-05-21 05:33:27 --> Hooks Class Initialized
DEBUG - 2011-05-21 05:33:27 --> Utf8 Class Initialized
DEBUG - 2011-05-21 05:33:27 --> UTF-8 Support Enabled
DEBUG - 2011-05-21 05:33:27 --> URI Class Initialized
DEBUG - 2011-05-21 05:33:27 --> Router Class Initialized
DEBUG - 2011-05-21 05:33:27 --> Output Class Initialized
DEBUG - 2011-05-21 05:33:27 --> Input Class Initialized
DEBUG - 2011-05-21 05:33:27 --> Global POST and COOKIE data sanitized
DEBUG - 2011-05-21 05:33:27 --> Language Class Initialized
DEBUG - 2011-05-21 05:33:27 --> Loader Class Initialized
DEBUG - 2011-05-21 05:33:27 --> Controller Class Initialized
DEBUG - 2011-05-21 05:33:27 --> Model Class Initialized
DEBUG - 2011-05-21 05:33:27 --> Model Class Initialized
DEBUG - 2011-05-21 05:33:27 --> Model Class Initialized
DEBUG - 2011-05-21 05:33:27 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-05-21 05:33:27 --> Database Driver Class Initialized
DEBUG - 2011-05-21 05:33:29 --> File loaded: application/views/table/main.php
DEBUG - 2011-05-21 05:33:29 --> Helper loaded: url_helper
DEBUG - 2011-05-21 05:33:29 --> File loaded: application/views/common/header.php
DEBUG - 2011-05-21 05:33:29 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-05-21 05:33:29 --> File loaded: application/views/common/footer.php
DEBUG - 2011-05-21 05:33:29 --> File loaded: application/views/layout/main.php
DEBUG - 2011-05-21 05:33:29 --> Final output sent to browser
DEBUG - 2011-05-21 05:33:29 --> Total execution time: 1.9657
DEBUG - 2011-05-21 05:33:30 --> Config Class Initialized
DEBUG - 2011-05-21 05:33:30 --> Hooks Class Initialized
DEBUG - 2011-05-21 05:33:30 --> Utf8 Class Initialized
DEBUG - 2011-05-21 05:33:30 --> UTF-8 Support Enabled
DEBUG - 2011-05-21 05:33:30 --> URI Class Initialized
DEBUG - 2011-05-21 05:33:30 --> Router Class Initialized
ERROR - 2011-05-21 05:33:30 --> 404 Page Not Found --> robots.txt
DEBUG - 2011-05-21 05:33:31 --> Config Class Initialized
DEBUG - 2011-05-21 05:33:31 --> Hooks Class Initialized
DEBUG - 2011-05-21 05:33:31 --> Utf8 Class Initialized
DEBUG - 2011-05-21 05:33:31 --> UTF-8 Support Enabled
DEBUG - 2011-05-21 05:33:31 --> URI Class Initialized
DEBUG - 2011-05-21 05:33:31 --> Router Class Initialized
DEBUG - 2011-05-21 05:33:31 --> Output Class Initialized
DEBUG - 2011-05-21 05:33:31 --> Input Class Initialized
DEBUG - 2011-05-21 05:33:31 --> Global POST and COOKIE data sanitized
DEBUG - 2011-05-21 05:33:31 --> Language Class Initialized
DEBUG - 2011-05-21 05:33:31 --> Loader Class Initialized
DEBUG - 2011-05-21 05:33:31 --> Controller Class Initialized
DEBUG - 2011-05-21 05:33:31 --> Model Class Initialized
DEBUG - 2011-05-21 05:33:31 --> Model Class Initialized
DEBUG - 2011-05-21 05:33:31 --> Model Class Initialized
DEBUG - 2011-05-21 05:33:31 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-05-21 05:33:31 --> Database Driver Class Initialized
DEBUG - 2011-05-21 05:33:31 --> File loaded: application/views/table/main.php
DEBUG - 2011-05-21 05:33:31 --> Helper loaded: url_helper
DEBUG - 2011-05-21 05:33:31 --> File loaded: application/views/common/header.php
DEBUG - 2011-05-21 05:33:31 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-05-21 05:33:31 --> File loaded: application/views/common/footer.php
DEBUG - 2011-05-21 05:33:31 --> File loaded: application/views/layout/main.php
DEBUG - 2011-05-21 05:33:31 --> Final output sent to browser
DEBUG - 2011-05-21 05:33:31 --> Total execution time: 0.0679
DEBUG - 2011-05-21 05:33:31 --> Config Class Initialized
DEBUG - 2011-05-21 05:33:31 --> Hooks Class Initialized
DEBUG - 2011-05-21 05:33:31 --> Utf8 Class Initialized
DEBUG - 2011-05-21 05:33:31 --> UTF-8 Support Enabled
DEBUG - 2011-05-21 05:33:31 --> URI Class Initialized
DEBUG - 2011-05-21 05:33:31 --> Router Class Initialized
ERROR - 2011-05-21 05:33:31 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-05-21 05:33:43 --> Config Class Initialized
DEBUG - 2011-05-21 05:33:43 --> Hooks Class Initialized
DEBUG - 2011-05-21 05:33:43 --> Utf8 Class Initialized
DEBUG - 2011-05-21 05:33:43 --> UTF-8 Support Enabled
DEBUG - 2011-05-21 05:33:43 --> URI Class Initialized
DEBUG - 2011-05-21 05:33:43 --> Router Class Initialized
DEBUG - 2011-05-21 05:33:43 --> Output Class Initialized
DEBUG - 2011-05-21 05:33:43 --> Input Class Initialized
DEBUG - 2011-05-21 05:33:43 --> Global POST and COOKIE data sanitized
DEBUG - 2011-05-21 05:33:43 --> Language Class Initialized
DEBUG - 2011-05-21 05:33:43 --> Loader Class Initialized
DEBUG - 2011-05-21 05:33:43 --> Controller Class Initialized
DEBUG - 2011-05-21 05:33:43 --> Model Class Initialized
DEBUG - 2011-05-21 05:33:43 --> Model Class Initialized
DEBUG - 2011-05-21 05:33:43 --> Model Class Initialized
DEBUG - 2011-05-21 05:33:43 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-05-21 05:33:43 --> Database Driver Class Initialized
DEBUG - 2011-05-21 05:33:47 --> File loaded: application/views/table/main.php
DEBUG - 2011-05-21 05:33:47 --> Helper loaded: url_helper
DEBUG - 2011-05-21 05:33:47 --> File loaded: application/views/common/header.php
DEBUG - 2011-05-21 05:33:47 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-05-21 05:33:47 --> File loaded: application/views/common/footer.php
DEBUG - 2011-05-21 05:33:47 --> File loaded: application/views/layout/main.php
DEBUG - 2011-05-21 05:33:47 --> Final output sent to browser
DEBUG - 2011-05-21 05:33:47 --> Total execution time: 3.6606
DEBUG - 2011-05-21 05:33:48 --> Config Class Initialized
DEBUG - 2011-05-21 05:33:48 --> Hooks Class Initialized
DEBUG - 2011-05-21 05:33:48 --> Utf8 Class Initialized
DEBUG - 2011-05-21 05:33:48 --> UTF-8 Support Enabled
DEBUG - 2011-05-21 05:33:48 --> URI Class Initialized
DEBUG - 2011-05-21 05:33:48 --> Router Class Initialized
DEBUG - 2011-05-21 05:33:48 --> Output Class Initialized
DEBUG - 2011-05-21 05:33:48 --> Input Class Initialized
DEBUG - 2011-05-21 05:33:48 --> Global POST and COOKIE data sanitized
DEBUG - 2011-05-21 05:33:48 --> Language Class Initialized
DEBUG - 2011-05-21 05:33:48 --> Loader Class Initialized
DEBUG - 2011-05-21 05:33:48 --> Controller Class Initialized
DEBUG - 2011-05-21 05:33:48 --> Model Class Initialized
DEBUG - 2011-05-21 05:33:48 --> Model Class Initialized
DEBUG - 2011-05-21 05:33:48 --> Model Class Initialized
DEBUG - 2011-05-21 05:33:48 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-05-21 05:33:48 --> Database Driver Class Initialized
DEBUG - 2011-05-21 05:33:48 --> File loaded: application/views/table/main.php
DEBUG - 2011-05-21 05:33:48 --> Helper loaded: url_helper
DEBUG - 2011-05-21 05:33:48 --> File loaded: application/views/common/header.php
DEBUG - 2011-05-21 05:33:48 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-05-21 05:33:48 --> File loaded: application/views/common/footer.php
DEBUG - 2011-05-21 05:33:48 --> File loaded: application/views/layout/main.php
DEBUG - 2011-05-21 05:33:48 --> Final output sent to browser
DEBUG - 2011-05-21 05:33:48 --> Total execution time: 0.0677
DEBUG - 2011-05-21 05:33:49 --> Config Class Initialized
DEBUG - 2011-05-21 05:33:49 --> Hooks Class Initialized
DEBUG - 2011-05-21 05:33:49 --> Utf8 Class Initialized
DEBUG - 2011-05-21 05:33:49 --> UTF-8 Support Enabled
DEBUG - 2011-05-21 05:33:49 --> URI Class Initialized
DEBUG - 2011-05-21 05:33:49 --> Router Class Initialized
ERROR - 2011-05-21 05:33:49 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-05-21 05:33:58 --> Config Class Initialized
DEBUG - 2011-05-21 05:33:58 --> Hooks Class Initialized
DEBUG - 2011-05-21 05:33:58 --> Utf8 Class Initialized
DEBUG - 2011-05-21 05:33:58 --> UTF-8 Support Enabled
DEBUG - 2011-05-21 05:33:58 --> URI Class Initialized
DEBUG - 2011-05-21 05:33:58 --> Router Class Initialized
DEBUG - 2011-05-21 05:33:58 --> Output Class Initialized
DEBUG - 2011-05-21 05:33:58 --> Input Class Initialized
DEBUG - 2011-05-21 05:33:58 --> Global POST and COOKIE data sanitized
DEBUG - 2011-05-21 05:33:58 --> Language Class Initialized
DEBUG - 2011-05-21 05:33:58 --> Loader Class Initialized
DEBUG - 2011-05-21 05:33:58 --> Controller Class Initialized
DEBUG - 2011-05-21 05:33:58 --> Model Class Initialized
DEBUG - 2011-05-21 05:33:58 --> Model Class Initialized
DEBUG - 2011-05-21 05:33:58 --> Model Class Initialized
DEBUG - 2011-05-21 05:33:58 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-05-21 05:33:58 --> Database Driver Class Initialized
DEBUG - 2011-05-21 05:33:59 --> File loaded: application/views/table/main.php
DEBUG - 2011-05-21 05:33:59 --> Helper loaded: url_helper
DEBUG - 2011-05-21 05:33:59 --> File loaded: application/views/common/header.php
DEBUG - 2011-05-21 05:33:59 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-05-21 05:33:59 --> File loaded: application/views/common/footer.php
DEBUG - 2011-05-21 05:33:59 --> File loaded: application/views/layout/main.php
DEBUG - 2011-05-21 05:33:59 --> Final output sent to browser
DEBUG - 2011-05-21 05:33:59 --> Total execution time: 0.9239
DEBUG - 2011-05-21 05:34:00 --> Config Class Initialized
DEBUG - 2011-05-21 05:34:00 --> Hooks Class Initialized
DEBUG - 2011-05-21 05:34:00 --> Utf8 Class Initialized
DEBUG - 2011-05-21 05:34:00 --> UTF-8 Support Enabled
DEBUG - 2011-05-21 05:34:00 --> URI Class Initialized
DEBUG - 2011-05-21 05:34:00 --> Router Class Initialized
DEBUG - 2011-05-21 05:34:00 --> Output Class Initialized
DEBUG - 2011-05-21 05:34:00 --> Input Class Initialized
DEBUG - 2011-05-21 05:34:00 --> Global POST and COOKIE data sanitized
DEBUG - 2011-05-21 05:34:00 --> Language Class Initialized
DEBUG - 2011-05-21 05:34:00 --> Loader Class Initialized
DEBUG - 2011-05-21 05:34:00 --> Controller Class Initialized
DEBUG - 2011-05-21 05:34:00 --> Model Class Initialized
DEBUG - 2011-05-21 05:34:00 --> Model Class Initialized
DEBUG - 2011-05-21 05:34:00 --> Model Class Initialized
DEBUG - 2011-05-21 05:34:00 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-05-21 05:34:00 --> Database Driver Class Initialized
DEBUG - 2011-05-21 05:34:00 --> File loaded: application/views/table/main.php
DEBUG - 2011-05-21 05:34:00 --> Helper loaded: url_helper
DEBUG - 2011-05-21 05:34:00 --> File loaded: application/views/common/header.php
DEBUG - 2011-05-21 05:34:00 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-05-21 05:34:00 --> File loaded: application/views/common/footer.php
DEBUG - 2011-05-21 05:34:00 --> File loaded: application/views/layout/main.php
DEBUG - 2011-05-21 05:34:00 --> Final output sent to browser
DEBUG - 2011-05-21 05:34:00 --> Total execution time: 0.1002
DEBUG - 2011-05-21 05:34:00 --> Config Class Initialized
DEBUG - 2011-05-21 05:34:00 --> Hooks Class Initialized
DEBUG - 2011-05-21 05:34:00 --> Utf8 Class Initialized
DEBUG - 2011-05-21 05:34:00 --> UTF-8 Support Enabled
DEBUG - 2011-05-21 05:34:00 --> URI Class Initialized
DEBUG - 2011-05-21 05:34:00 --> Router Class Initialized
DEBUG - 2011-05-21 05:34:00 --> Output Class Initialized
DEBUG - 2011-05-21 05:34:00 --> Input Class Initialized
DEBUG - 2011-05-21 05:34:00 --> Global POST and COOKIE data sanitized
DEBUG - 2011-05-21 05:34:00 --> Language Class Initialized
DEBUG - 2011-05-21 05:34:00 --> Loader Class Initialized
DEBUG - 2011-05-21 05:34:00 --> Controller Class Initialized
DEBUG - 2011-05-21 05:34:00 --> Model Class Initialized
DEBUG - 2011-05-21 05:34:00 --> Model Class Initialized
DEBUG - 2011-05-21 05:34:00 --> Model Class Initialized
DEBUG - 2011-05-21 05:34:00 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-05-21 05:34:00 --> Database Driver Class Initialized
DEBUG - 2011-05-21 05:34:00 --> File loaded: application/views/table/main.php
DEBUG - 2011-05-21 05:34:00 --> Helper loaded: url_helper
DEBUG - 2011-05-21 05:34:00 --> File loaded: application/views/common/header.php
DEBUG - 2011-05-21 05:34:00 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-05-21 05:34:00 --> File loaded: application/views/common/footer.php
DEBUG - 2011-05-21 05:34:00 --> File loaded: application/views/layout/main.php
DEBUG - 2011-05-21 05:34:00 --> Final output sent to browser
DEBUG - 2011-05-21 05:34:00 --> Total execution time: 0.0863
DEBUG - 2011-05-21 05:34:01 --> Config Class Initialized
DEBUG - 2011-05-21 05:34:01 --> Hooks Class Initialized
DEBUG - 2011-05-21 05:34:01 --> Utf8 Class Initialized
DEBUG - 2011-05-21 05:34:01 --> UTF-8 Support Enabled
DEBUG - 2011-05-21 05:34:01 --> URI Class Initialized
DEBUG - 2011-05-21 05:34:01 --> Router Class Initialized
ERROR - 2011-05-21 05:34:01 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-05-21 05:34:20 --> Config Class Initialized
DEBUG - 2011-05-21 05:34:20 --> Hooks Class Initialized
DEBUG - 2011-05-21 05:34:20 --> Utf8 Class Initialized
DEBUG - 2011-05-21 05:34:20 --> UTF-8 Support Enabled
DEBUG - 2011-05-21 05:34:20 --> URI Class Initialized
DEBUG - 2011-05-21 05:34:20 --> Router Class Initialized
DEBUG - 2011-05-21 05:34:20 --> Output Class Initialized
DEBUG - 2011-05-21 05:34:20 --> Input Class Initialized
DEBUG - 2011-05-21 05:34:20 --> Global POST and COOKIE data sanitized
DEBUG - 2011-05-21 05:34:20 --> Language Class Initialized
DEBUG - 2011-05-21 05:34:20 --> Loader Class Initialized
DEBUG - 2011-05-21 05:34:20 --> Controller Class Initialized
DEBUG - 2011-05-21 05:34:20 --> Model Class Initialized
DEBUG - 2011-05-21 05:34:20 --> Model Class Initialized
DEBUG - 2011-05-21 05:34:20 --> Model Class Initialized
DEBUG - 2011-05-21 05:34:20 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-05-21 05:34:20 --> Database Driver Class Initialized
DEBUG - 2011-05-21 05:34:25 --> Config Class Initialized
DEBUG - 2011-05-21 05:34:25 --> Hooks Class Initialized
DEBUG - 2011-05-21 05:34:25 --> Utf8 Class Initialized
DEBUG - 2011-05-21 05:34:25 --> UTF-8 Support Enabled
DEBUG - 2011-05-21 05:34:25 --> URI Class Initialized
DEBUG - 2011-05-21 05:34:25 --> Router Class Initialized
DEBUG - 2011-05-21 05:34:25 --> Output Class Initialized
DEBUG - 2011-05-21 05:34:25 --> Input Class Initialized
DEBUG - 2011-05-21 05:34:25 --> Global POST and COOKIE data sanitized
DEBUG - 2011-05-21 05:34:25 --> Language Class Initialized
DEBUG - 2011-05-21 05:34:25 --> Loader Class Initialized
DEBUG - 2011-05-21 05:34:25 --> Controller Class Initialized
DEBUG - 2011-05-21 05:34:25 --> Model Class Initialized
DEBUG - 2011-05-21 05:34:25 --> Model Class Initialized
DEBUG - 2011-05-21 05:34:25 --> Model Class Initialized
DEBUG - 2011-05-21 05:34:25 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-05-21 05:34:25 --> Database Driver Class Initialized
DEBUG - 2011-05-21 05:34:26 --> File loaded: application/views/table/main.php
DEBUG - 2011-05-21 05:34:26 --> File loaded: application/views/table/main.php
DEBUG - 2011-05-21 05:34:26 --> Helper loaded: url_helper
DEBUG - 2011-05-21 05:34:26 --> File loaded: application/views/common/header.php
DEBUG - 2011-05-21 05:34:26 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-05-21 05:34:26 --> File loaded: application/views/common/footer.php
DEBUG - 2011-05-21 05:34:26 --> Helper loaded: url_helper
DEBUG - 2011-05-21 05:34:26 --> File loaded: application/views/layout/main.php
DEBUG - 2011-05-21 05:34:26 --> Final output sent to browser
DEBUG - 2011-05-21 05:34:26 --> File loaded: application/views/common/header.php
DEBUG - 2011-05-21 05:34:26 --> Total execution time: 6.6837
DEBUG - 2011-05-21 05:34:26 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-05-21 05:34:26 --> File loaded: application/views/common/footer.php
DEBUG - 2011-05-21 05:34:26 --> File loaded: application/views/layout/main.php
DEBUG - 2011-05-21 05:34:26 --> Final output sent to browser
DEBUG - 2011-05-21 05:34:26 --> Total execution time: 1.6820
DEBUG - 2011-05-21 05:34:28 --> Config Class Initialized
DEBUG - 2011-05-21 05:34:28 --> Hooks Class Initialized
DEBUG - 2011-05-21 05:34:28 --> Utf8 Class Initialized
DEBUG - 2011-05-21 05:34:28 --> UTF-8 Support Enabled
DEBUG - 2011-05-21 05:34:28 --> URI Class Initialized
DEBUG - 2011-05-21 05:34:28 --> Router Class Initialized
DEBUG - 2011-05-21 05:34:28 --> Output Class Initialized
DEBUG - 2011-05-21 05:34:28 --> Input Class Initialized
DEBUG - 2011-05-21 05:34:28 --> Global POST and COOKIE data sanitized
DEBUG - 2011-05-21 05:34:28 --> Language Class Initialized
DEBUG - 2011-05-21 05:34:28 --> Loader Class Initialized
DEBUG - 2011-05-21 05:34:28 --> Controller Class Initialized
DEBUG - 2011-05-21 05:34:28 --> Model Class Initialized
DEBUG - 2011-05-21 05:34:28 --> Model Class Initialized
DEBUG - 2011-05-21 05:34:28 --> Model Class Initialized
DEBUG - 2011-05-21 05:34:28 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-05-21 05:34:28 --> Database Driver Class Initialized
DEBUG - 2011-05-21 05:34:28 --> Config Class Initialized
DEBUG - 2011-05-21 05:34:28 --> Hooks Class Initialized
DEBUG - 2011-05-21 05:34:28 --> Utf8 Class Initialized
DEBUG - 2011-05-21 05:34:28 --> UTF-8 Support Enabled
DEBUG - 2011-05-21 05:34:28 --> File loaded: application/views/table/main.php
DEBUG - 2011-05-21 05:34:28 --> URI Class Initialized
DEBUG - 2011-05-21 05:34:28 --> Helper loaded: url_helper
DEBUG - 2011-05-21 05:34:28 --> Router Class Initialized
DEBUG - 2011-05-21 05:34:28 --> File loaded: application/views/common/header.php
DEBUG - 2011-05-21 05:34:28 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-05-21 05:34:28 --> File loaded: application/views/common/footer.php
DEBUG - 2011-05-21 05:34:28 --> File loaded: application/views/layout/main.php
DEBUG - 2011-05-21 05:34:28 --> Final output sent to browser
DEBUG - 2011-05-21 05:34:28 --> Total execution time: 0.0823
ERROR - 2011-05-21 05:34:28 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-05-21 06:15:27 --> Config Class Initialized
DEBUG - 2011-05-21 06:15:27 --> Hooks Class Initialized
DEBUG - 2011-05-21 06:15:27 --> Utf8 Class Initialized
DEBUG - 2011-05-21 06:15:27 --> UTF-8 Support Enabled
DEBUG - 2011-05-21 06:15:27 --> URI Class Initialized
DEBUG - 2011-05-21 06:15:27 --> Router Class Initialized
DEBUG - 2011-05-21 06:15:27 --> Output Class Initialized
DEBUG - 2011-05-21 06:15:27 --> Input Class Initialized
DEBUG - 2011-05-21 06:15:27 --> Global POST and COOKIE data sanitized
DEBUG - 2011-05-21 06:15:27 --> Language Class Initialized
DEBUG - 2011-05-21 06:15:27 --> Loader Class Initialized
DEBUG - 2011-05-21 06:15:27 --> Controller Class Initialized
ERROR - 2011-05-21 06:15:27 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-05-21 06:15:27 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-05-21 06:15:27 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-05-21 06:15:27 --> Model Class Initialized
DEBUG - 2011-05-21 06:15:27 --> Model Class Initialized
DEBUG - 2011-05-21 06:15:27 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-05-21 06:15:27 --> Database Driver Class Initialized
DEBUG - 2011-05-21 06:15:27 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-05-21 06:15:27 --> Helper loaded: url_helper
DEBUG - 2011-05-21 06:15:27 --> File loaded: application/views/common/header.php
DEBUG - 2011-05-21 06:15:27 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-05-21 06:15:27 --> File loaded: application/views/common/footer.php
DEBUG - 2011-05-21 06:15:27 --> File loaded: application/views/layout/main.php
DEBUG - 2011-05-21 06:15:27 --> Final output sent to browser
DEBUG - 2011-05-21 06:15:27 --> Total execution time: 0.4242
DEBUG - 2011-05-21 06:15:29 --> Config Class Initialized
DEBUG - 2011-05-21 06:15:29 --> Hooks Class Initialized
DEBUG - 2011-05-21 06:15:29 --> Utf8 Class Initialized
DEBUG - 2011-05-21 06:15:29 --> UTF-8 Support Enabled
DEBUG - 2011-05-21 06:15:29 --> URI Class Initialized
DEBUG - 2011-05-21 06:15:29 --> Router Class Initialized
DEBUG - 2011-05-21 06:15:29 --> Output Class Initialized
DEBUG - 2011-05-21 06:15:29 --> Input Class Initialized
DEBUG - 2011-05-21 06:15:29 --> Global POST and COOKIE data sanitized
DEBUG - 2011-05-21 06:15:29 --> Language Class Initialized
DEBUG - 2011-05-21 06:15:29 --> Loader Class Initialized
DEBUG - 2011-05-21 06:15:29 --> Controller Class Initialized
DEBUG - 2011-05-21 06:15:29 --> Model Class Initialized
DEBUG - 2011-05-21 06:15:29 --> Model Class Initialized
DEBUG - 2011-05-21 06:15:29 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-05-21 06:15:29 --> Database Driver Class Initialized
DEBUG - 2011-05-21 06:15:30 --> Final output sent to browser
DEBUG - 2011-05-21 06:15:30 --> Total execution time: 1.2006
DEBUG - 2011-05-21 06:15:31 --> Config Class Initialized
DEBUG - 2011-05-21 06:15:31 --> Hooks Class Initialized
DEBUG - 2011-05-21 06:15:31 --> Utf8 Class Initialized
DEBUG - 2011-05-21 06:15:31 --> UTF-8 Support Enabled
DEBUG - 2011-05-21 06:15:31 --> URI Class Initialized
DEBUG - 2011-05-21 06:15:31 --> Router Class Initialized
ERROR - 2011-05-21 06:15:31 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-05-21 06:18:51 --> Config Class Initialized
DEBUG - 2011-05-21 06:18:51 --> Hooks Class Initialized
DEBUG - 2011-05-21 06:18:51 --> Utf8 Class Initialized
DEBUG - 2011-05-21 06:18:51 --> UTF-8 Support Enabled
DEBUG - 2011-05-21 06:18:51 --> URI Class Initialized
DEBUG - 2011-05-21 06:18:51 --> Router Class Initialized
DEBUG - 2011-05-21 06:18:51 --> Output Class Initialized
DEBUG - 2011-05-21 06:18:51 --> Input Class Initialized
DEBUG - 2011-05-21 06:18:51 --> Global POST and COOKIE data sanitized
DEBUG - 2011-05-21 06:18:51 --> Language Class Initialized
DEBUG - 2011-05-21 06:18:51 --> Loader Class Initialized
DEBUG - 2011-05-21 06:18:51 --> Controller Class Initialized
ERROR - 2011-05-21 06:18:51 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-05-21 06:18:51 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-05-21 06:18:51 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-05-21 06:18:51 --> Model Class Initialized
DEBUG - 2011-05-21 06:18:51 --> Model Class Initialized
DEBUG - 2011-05-21 06:18:51 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-05-21 06:18:51 --> Database Driver Class Initialized
DEBUG - 2011-05-21 06:18:51 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-05-21 06:18:51 --> Helper loaded: url_helper
DEBUG - 2011-05-21 06:18:51 --> File loaded: application/views/common/header.php
DEBUG - 2011-05-21 06:18:51 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-05-21 06:18:51 --> File loaded: application/views/common/footer.php
DEBUG - 2011-05-21 06:18:51 --> File loaded: application/views/layout/main.php
DEBUG - 2011-05-21 06:18:51 --> Final output sent to browser
DEBUG - 2011-05-21 06:18:51 --> Total execution time: 0.0773
DEBUG - 2011-05-21 06:18:59 --> Config Class Initialized
DEBUG - 2011-05-21 06:18:59 --> Hooks Class Initialized
DEBUG - 2011-05-21 06:18:59 --> Utf8 Class Initialized
DEBUG - 2011-05-21 06:18:59 --> UTF-8 Support Enabled
DEBUG - 2011-05-21 06:18:59 --> URI Class Initialized
DEBUG - 2011-05-21 06:18:59 --> Router Class Initialized
DEBUG - 2011-05-21 06:18:59 --> Output Class Initialized
DEBUG - 2011-05-21 06:18:59 --> Input Class Initialized
DEBUG - 2011-05-21 06:18:59 --> Global POST and COOKIE data sanitized
DEBUG - 2011-05-21 06:18:59 --> Language Class Initialized
DEBUG - 2011-05-21 06:18:59 --> Loader Class Initialized
DEBUG - 2011-05-21 06:18:59 --> Controller Class Initialized
DEBUG - 2011-05-21 06:18:59 --> Model Class Initialized
DEBUG - 2011-05-21 06:18:59 --> Model Class Initialized
DEBUG - 2011-05-21 06:18:59 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-05-21 06:18:59 --> Database Driver Class Initialized
DEBUG - 2011-05-21 06:19:00 --> Final output sent to browser
DEBUG - 2011-05-21 06:19:00 --> Total execution time: 0.5695
DEBUG - 2011-05-21 06:21:50 --> Config Class Initialized
DEBUG - 2011-05-21 06:21:50 --> Hooks Class Initialized
DEBUG - 2011-05-21 06:21:50 --> Utf8 Class Initialized
DEBUG - 2011-05-21 06:21:50 --> UTF-8 Support Enabled
DEBUG - 2011-05-21 06:21:50 --> URI Class Initialized
DEBUG - 2011-05-21 06:21:50 --> Router Class Initialized
ERROR - 2011-05-21 06:21:50 --> 404 Page Not Found --> robots.txt
DEBUG - 2011-05-21 06:22:47 --> Config Class Initialized
DEBUG - 2011-05-21 06:22:47 --> Hooks Class Initialized
DEBUG - 2011-05-21 06:22:47 --> Utf8 Class Initialized
DEBUG - 2011-05-21 06:22:47 --> UTF-8 Support Enabled
DEBUG - 2011-05-21 06:22:47 --> URI Class Initialized
DEBUG - 2011-05-21 06:22:47 --> Router Class Initialized
DEBUG - 2011-05-21 06:22:47 --> Output Class Initialized
DEBUG - 2011-05-21 06:22:47 --> Input Class Initialized
DEBUG - 2011-05-21 06:22:47 --> Global POST and COOKIE data sanitized
DEBUG - 2011-05-21 06:22:47 --> Language Class Initialized
DEBUG - 2011-05-21 06:22:47 --> Loader Class Initialized
DEBUG - 2011-05-21 06:22:47 --> Controller Class Initialized
DEBUG - 2011-05-21 06:22:47 --> Model Class Initialized
DEBUG - 2011-05-21 06:22:47 --> Model Class Initialized
DEBUG - 2011-05-21 06:22:47 --> Model Class Initialized
DEBUG - 2011-05-21 06:22:47 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-05-21 06:22:47 --> Database Driver Class Initialized
DEBUG - 2011-05-21 06:22:48 --> File loaded: application/views/table/main.php
DEBUG - 2011-05-21 06:22:48 --> Helper loaded: url_helper
DEBUG - 2011-05-21 06:22:48 --> File loaded: application/views/common/header.php
DEBUG - 2011-05-21 06:22:48 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-05-21 06:22:48 --> File loaded: application/views/common/footer.php
DEBUG - 2011-05-21 06:22:48 --> File loaded: application/views/layout/main.php
DEBUG - 2011-05-21 06:22:48 --> Final output sent to browser
DEBUG - 2011-05-21 06:22:48 --> Total execution time: 0.4981
DEBUG - 2011-05-21 07:56:49 --> Config Class Initialized
DEBUG - 2011-05-21 07:56:49 --> Hooks Class Initialized
DEBUG - 2011-05-21 07:56:49 --> Utf8 Class Initialized
DEBUG - 2011-05-21 07:56:49 --> UTF-8 Support Enabled
DEBUG - 2011-05-21 07:56:49 --> URI Class Initialized
DEBUG - 2011-05-21 07:56:49 --> Router Class Initialized
DEBUG - 2011-05-21 07:56:49 --> Output Class Initialized
DEBUG - 2011-05-21 07:56:49 --> Input Class Initialized
DEBUG - 2011-05-21 07:56:49 --> Global POST and COOKIE data sanitized
DEBUG - 2011-05-21 07:56:49 --> Language Class Initialized
DEBUG - 2011-05-21 07:56:49 --> Loader Class Initialized
DEBUG - 2011-05-21 07:56:49 --> Controller Class Initialized
ERROR - 2011-05-21 07:56:49 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-05-21 07:56:49 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-05-21 07:56:49 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-05-21 07:56:49 --> Model Class Initialized
DEBUG - 2011-05-21 07:56:49 --> Model Class Initialized
DEBUG - 2011-05-21 07:56:49 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-05-21 07:56:49 --> Database Driver Class Initialized
DEBUG - 2011-05-21 07:56:49 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-05-21 07:56:49 --> Helper loaded: url_helper
DEBUG - 2011-05-21 07:56:49 --> File loaded: application/views/common/header.php
DEBUG - 2011-05-21 07:56:49 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-05-21 07:56:49 --> File loaded: application/views/common/footer.php
DEBUG - 2011-05-21 07:56:49 --> File loaded: application/views/layout/main.php
DEBUG - 2011-05-21 07:56:49 --> Final output sent to browser
DEBUG - 2011-05-21 07:56:49 --> Total execution time: 0.3787
DEBUG - 2011-05-21 07:56:50 --> Config Class Initialized
DEBUG - 2011-05-21 07:56:50 --> Hooks Class Initialized
DEBUG - 2011-05-21 07:56:50 --> Utf8 Class Initialized
DEBUG - 2011-05-21 07:56:50 --> UTF-8 Support Enabled
DEBUG - 2011-05-21 07:56:50 --> URI Class Initialized
DEBUG - 2011-05-21 07:56:50 --> Router Class Initialized
DEBUG - 2011-05-21 07:56:50 --> Output Class Initialized
DEBUG - 2011-05-21 07:56:50 --> Input Class Initialized
DEBUG - 2011-05-21 07:56:50 --> Global POST and COOKIE data sanitized
DEBUG - 2011-05-21 07:56:50 --> Language Class Initialized
DEBUG - 2011-05-21 07:56:50 --> Loader Class Initialized
DEBUG - 2011-05-21 07:56:50 --> Controller Class Initialized
DEBUG - 2011-05-21 07:56:50 --> Model Class Initialized
DEBUG - 2011-05-21 07:56:50 --> Model Class Initialized
DEBUG - 2011-05-21 07:56:50 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-05-21 07:56:50 --> Database Driver Class Initialized
DEBUG - 2011-05-21 07:56:50 --> Final output sent to browser
DEBUG - 2011-05-21 07:56:50 --> Total execution time: 0.7166
DEBUG - 2011-05-21 07:56:57 --> Config Class Initialized
DEBUG - 2011-05-21 07:56:57 --> Hooks Class Initialized
DEBUG - 2011-05-21 07:56:57 --> Utf8 Class Initialized
DEBUG - 2011-05-21 07:56:57 --> UTF-8 Support Enabled
DEBUG - 2011-05-21 07:56:57 --> URI Class Initialized
DEBUG - 2011-05-21 07:56:57 --> Router Class Initialized
ERROR - 2011-05-21 07:56:57 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-05-21 07:56:57 --> Config Class Initialized
DEBUG - 2011-05-21 07:56:57 --> Hooks Class Initialized
DEBUG - 2011-05-21 07:56:57 --> Utf8 Class Initialized
DEBUG - 2011-05-21 07:56:57 --> UTF-8 Support Enabled
DEBUG - 2011-05-21 07:56:57 --> URI Class Initialized
DEBUG - 2011-05-21 07:56:57 --> Config Class Initialized
DEBUG - 2011-05-21 07:56:57 --> Hooks Class Initialized
DEBUG - 2011-05-21 07:56:57 --> Utf8 Class Initialized
DEBUG - 2011-05-21 07:56:57 --> UTF-8 Support Enabled
DEBUG - 2011-05-21 07:56:57 --> Router Class Initialized
DEBUG - 2011-05-21 07:56:57 --> URI Class Initialized
ERROR - 2011-05-21 07:56:57 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-05-21 07:56:57 --> Router Class Initialized
ERROR - 2011-05-21 07:56:57 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-05-21 07:57:53 --> Config Class Initialized
DEBUG - 2011-05-21 07:57:53 --> Hooks Class Initialized
DEBUG - 2011-05-21 07:57:53 --> Utf8 Class Initialized
DEBUG - 2011-05-21 07:57:53 --> UTF-8 Support Enabled
DEBUG - 2011-05-21 07:57:53 --> URI Class Initialized
DEBUG - 2011-05-21 07:57:53 --> Router Class Initialized
DEBUG - 2011-05-21 07:57:53 --> Output Class Initialized
DEBUG - 2011-05-21 07:57:53 --> Input Class Initialized
DEBUG - 2011-05-21 07:57:53 --> Global POST and COOKIE data sanitized
DEBUG - 2011-05-21 07:57:53 --> Language Class Initialized
DEBUG - 2011-05-21 07:57:53 --> Loader Class Initialized
DEBUG - 2011-05-21 07:57:53 --> Controller Class Initialized
ERROR - 2011-05-21 07:57:53 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-05-21 07:57:53 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-05-21 07:57:53 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-05-21 07:57:53 --> Model Class Initialized
DEBUG - 2011-05-21 07:57:53 --> Model Class Initialized
DEBUG - 2011-05-21 07:57:53 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-05-21 07:57:53 --> Database Driver Class Initialized
DEBUG - 2011-05-21 07:57:53 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-05-21 07:57:53 --> Helper loaded: url_helper
DEBUG - 2011-05-21 07:57:53 --> File loaded: application/views/common/header.php
DEBUG - 2011-05-21 07:57:53 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-05-21 07:57:53 --> File loaded: application/views/common/footer.php
DEBUG - 2011-05-21 07:57:53 --> File loaded: application/views/layout/main.php
DEBUG - 2011-05-21 07:57:53 --> Final output sent to browser
DEBUG - 2011-05-21 07:57:53 --> Total execution time: 0.0320
DEBUG - 2011-05-21 07:57:53 --> Config Class Initialized
DEBUG - 2011-05-21 07:57:53 --> Hooks Class Initialized
DEBUG - 2011-05-21 07:57:53 --> Utf8 Class Initialized
DEBUG - 2011-05-21 07:57:53 --> UTF-8 Support Enabled
DEBUG - 2011-05-21 07:57:53 --> URI Class Initialized
DEBUG - 2011-05-21 07:57:53 --> Router Class Initialized
DEBUG - 2011-05-21 07:57:53 --> Output Class Initialized
DEBUG - 2011-05-21 07:57:53 --> Input Class Initialized
DEBUG - 2011-05-21 07:57:53 --> Global POST and COOKIE data sanitized
DEBUG - 2011-05-21 07:57:53 --> Language Class Initialized
DEBUG - 2011-05-21 07:57:53 --> Loader Class Initialized
DEBUG - 2011-05-21 07:57:53 --> Controller Class Initialized
DEBUG - 2011-05-21 07:57:53 --> Model Class Initialized
DEBUG - 2011-05-21 07:57:53 --> Model Class Initialized
DEBUG - 2011-05-21 07:57:53 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-05-21 07:57:53 --> Database Driver Class Initialized
DEBUG - 2011-05-21 07:57:54 --> Final output sent to browser
DEBUG - 2011-05-21 07:57:54 --> Total execution time: 0.6613
DEBUG - 2011-05-21 07:57:55 --> Config Class Initialized
DEBUG - 2011-05-21 07:57:55 --> Hooks Class Initialized
DEBUG - 2011-05-21 07:57:55 --> Utf8 Class Initialized
DEBUG - 2011-05-21 07:57:55 --> UTF-8 Support Enabled
DEBUG - 2011-05-21 07:57:55 --> URI Class Initialized
DEBUG - 2011-05-21 07:57:55 --> Router Class Initialized
DEBUG - 2011-05-21 07:57:55 --> Output Class Initialized
DEBUG - 2011-05-21 07:57:55 --> Input Class Initialized
DEBUG - 2011-05-21 07:57:55 --> Global POST and COOKIE data sanitized
DEBUG - 2011-05-21 07:57:55 --> Language Class Initialized
DEBUG - 2011-05-21 07:57:55 --> Loader Class Initialized
DEBUG - 2011-05-21 07:57:55 --> Controller Class Initialized
ERROR - 2011-05-21 07:57:55 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-05-21 07:57:55 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-05-21 07:57:55 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-05-21 07:57:55 --> Model Class Initialized
DEBUG - 2011-05-21 07:57:55 --> Model Class Initialized
DEBUG - 2011-05-21 07:57:55 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-05-21 07:57:55 --> Database Driver Class Initialized
DEBUG - 2011-05-21 07:57:55 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-05-21 07:57:55 --> Helper loaded: url_helper
DEBUG - 2011-05-21 07:57:55 --> File loaded: application/views/common/header.php
DEBUG - 2011-05-21 07:57:55 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-05-21 07:57:55 --> File loaded: application/views/common/footer.php
DEBUG - 2011-05-21 07:57:55 --> File loaded: application/views/layout/main.php
DEBUG - 2011-05-21 07:57:55 --> Final output sent to browser
DEBUG - 2011-05-21 07:57:55 --> Total execution time: 0.0308
DEBUG - 2011-05-21 07:58:16 --> Config Class Initialized
DEBUG - 2011-05-21 07:58:16 --> Hooks Class Initialized
DEBUG - 2011-05-21 07:58:16 --> Utf8 Class Initialized
DEBUG - 2011-05-21 07:58:16 --> UTF-8 Support Enabled
DEBUG - 2011-05-21 07:58:16 --> URI Class Initialized
DEBUG - 2011-05-21 07:58:16 --> Router Class Initialized
DEBUG - 2011-05-21 07:58:16 --> Output Class Initialized
DEBUG - 2011-05-21 07:58:16 --> Input Class Initialized
DEBUG - 2011-05-21 07:58:16 --> Global POST and COOKIE data sanitized
DEBUG - 2011-05-21 07:58:16 --> Language Class Initialized
DEBUG - 2011-05-21 07:58:16 --> Loader Class Initialized
DEBUG - 2011-05-21 07:58:16 --> Controller Class Initialized
ERROR - 2011-05-21 07:58:16 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-05-21 07:58:16 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-05-21 07:58:16 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-05-21 07:58:16 --> Model Class Initialized
DEBUG - 2011-05-21 07:58:16 --> Model Class Initialized
DEBUG - 2011-05-21 07:58:16 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-05-21 07:58:16 --> Database Driver Class Initialized
DEBUG - 2011-05-21 07:58:16 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-05-21 07:58:16 --> Helper loaded: url_helper
DEBUG - 2011-05-21 07:58:16 --> File loaded: application/views/common/header.php
DEBUG - 2011-05-21 07:58:16 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-05-21 07:58:16 --> File loaded: application/views/common/footer.php
DEBUG - 2011-05-21 07:58:16 --> File loaded: application/views/layout/main.php
DEBUG - 2011-05-21 07:58:16 --> Final output sent to browser
DEBUG - 2011-05-21 07:58:16 --> Total execution time: 0.0319
DEBUG - 2011-05-21 07:58:17 --> Config Class Initialized
DEBUG - 2011-05-21 07:58:17 --> Hooks Class Initialized
DEBUG - 2011-05-21 07:58:17 --> Utf8 Class Initialized
DEBUG - 2011-05-21 07:58:17 --> UTF-8 Support Enabled
DEBUG - 2011-05-21 07:58:17 --> URI Class Initialized
DEBUG - 2011-05-21 07:58:17 --> Router Class Initialized
DEBUG - 2011-05-21 07:58:17 --> Output Class Initialized
DEBUG - 2011-05-21 07:58:17 --> Input Class Initialized
DEBUG - 2011-05-21 07:58:17 --> Global POST and COOKIE data sanitized
DEBUG - 2011-05-21 07:58:17 --> Language Class Initialized
DEBUG - 2011-05-21 07:58:17 --> Loader Class Initialized
DEBUG - 2011-05-21 07:58:17 --> Controller Class Initialized
DEBUG - 2011-05-21 07:58:17 --> Model Class Initialized
DEBUG - 2011-05-21 07:58:17 --> Model Class Initialized
DEBUG - 2011-05-21 07:58:17 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-05-21 07:58:17 --> Database Driver Class Initialized
DEBUG - 2011-05-21 07:58:18 --> Final output sent to browser
DEBUG - 2011-05-21 07:58:18 --> Total execution time: 0.7545
DEBUG - 2011-05-21 07:58:18 --> Config Class Initialized
DEBUG - 2011-05-21 07:58:18 --> Hooks Class Initialized
DEBUG - 2011-05-21 07:58:18 --> Utf8 Class Initialized
DEBUG - 2011-05-21 07:58:18 --> UTF-8 Support Enabled
DEBUG - 2011-05-21 07:58:18 --> URI Class Initialized
DEBUG - 2011-05-21 07:58:18 --> Router Class Initialized
DEBUG - 2011-05-21 07:58:18 --> Output Class Initialized
DEBUG - 2011-05-21 07:58:18 --> Input Class Initialized
DEBUG - 2011-05-21 07:58:18 --> Global POST and COOKIE data sanitized
DEBUG - 2011-05-21 07:58:18 --> Language Class Initialized
DEBUG - 2011-05-21 07:58:18 --> Loader Class Initialized
DEBUG - 2011-05-21 07:58:18 --> Controller Class Initialized
ERROR - 2011-05-21 07:58:18 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-05-21 07:58:18 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-05-21 07:58:18 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-05-21 07:58:18 --> Model Class Initialized
DEBUG - 2011-05-21 07:58:18 --> Model Class Initialized
DEBUG - 2011-05-21 07:58:18 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-05-21 07:58:18 --> Database Driver Class Initialized
DEBUG - 2011-05-21 07:58:18 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-05-21 07:58:18 --> Helper loaded: url_helper
DEBUG - 2011-05-21 07:58:18 --> File loaded: application/views/common/header.php
DEBUG - 2011-05-21 07:58:18 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-05-21 07:58:18 --> File loaded: application/views/common/footer.php
DEBUG - 2011-05-21 07:58:18 --> File loaded: application/views/layout/main.php
DEBUG - 2011-05-21 07:58:18 --> Final output sent to browser
DEBUG - 2011-05-21 07:58:18 --> Total execution time: 0.0312
DEBUG - 2011-05-21 07:58:27 --> Config Class Initialized
DEBUG - 2011-05-21 07:58:27 --> Hooks Class Initialized
DEBUG - 2011-05-21 07:58:27 --> Utf8 Class Initialized
DEBUG - 2011-05-21 07:58:27 --> UTF-8 Support Enabled
DEBUG - 2011-05-21 07:58:27 --> URI Class Initialized
DEBUG - 2011-05-21 07:58:27 --> Router Class Initialized
DEBUG - 2011-05-21 07:58:27 --> Output Class Initialized
DEBUG - 2011-05-21 07:58:27 --> Input Class Initialized
DEBUG - 2011-05-21 07:58:27 --> Global POST and COOKIE data sanitized
DEBUG - 2011-05-21 07:58:27 --> Language Class Initialized
DEBUG - 2011-05-21 07:58:27 --> Loader Class Initialized
DEBUG - 2011-05-21 07:58:27 --> Controller Class Initialized
ERROR - 2011-05-21 07:58:27 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-05-21 07:58:27 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-05-21 07:58:27 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-05-21 07:58:27 --> Model Class Initialized
DEBUG - 2011-05-21 07:58:27 --> Model Class Initialized
DEBUG - 2011-05-21 07:58:27 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-05-21 07:58:27 --> Database Driver Class Initialized
DEBUG - 2011-05-21 07:58:27 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-05-21 07:58:27 --> Helper loaded: url_helper
DEBUG - 2011-05-21 07:58:27 --> File loaded: application/views/common/header.php
DEBUG - 2011-05-21 07:58:27 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-05-21 07:58:27 --> File loaded: application/views/common/footer.php
DEBUG - 2011-05-21 07:58:27 --> File loaded: application/views/layout/main.php
DEBUG - 2011-05-21 07:58:27 --> Final output sent to browser
DEBUG - 2011-05-21 07:58:27 --> Total execution time: 0.0297
DEBUG - 2011-05-21 07:58:28 --> Config Class Initialized
DEBUG - 2011-05-21 07:58:28 --> Hooks Class Initialized
DEBUG - 2011-05-21 07:58:28 --> Utf8 Class Initialized
DEBUG - 2011-05-21 07:58:28 --> UTF-8 Support Enabled
DEBUG - 2011-05-21 07:58:28 --> URI Class Initialized
DEBUG - 2011-05-21 07:58:28 --> Router Class Initialized
DEBUG - 2011-05-21 07:58:28 --> Output Class Initialized
DEBUG - 2011-05-21 07:58:28 --> Input Class Initialized
DEBUG - 2011-05-21 07:58:28 --> Global POST and COOKIE data sanitized
DEBUG - 2011-05-21 07:58:28 --> Language Class Initialized
DEBUG - 2011-05-21 07:58:28 --> Loader Class Initialized
DEBUG - 2011-05-21 07:58:28 --> Controller Class Initialized
DEBUG - 2011-05-21 07:58:28 --> Model Class Initialized
DEBUG - 2011-05-21 07:58:28 --> Model Class Initialized
DEBUG - 2011-05-21 07:58:28 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-05-21 07:58:28 --> Database Driver Class Initialized
DEBUG - 2011-05-21 07:58:29 --> Final output sent to browser
DEBUG - 2011-05-21 07:58:29 --> Total execution time: 0.9773
DEBUG - 2011-05-21 07:58:46 --> Config Class Initialized
DEBUG - 2011-05-21 07:58:46 --> Hooks Class Initialized
DEBUG - 2011-05-21 07:58:46 --> Utf8 Class Initialized
DEBUG - 2011-05-21 07:58:46 --> UTF-8 Support Enabled
DEBUG - 2011-05-21 07:58:46 --> URI Class Initialized
DEBUG - 2011-05-21 07:58:46 --> Router Class Initialized
DEBUG - 2011-05-21 07:58:46 --> Output Class Initialized
DEBUG - 2011-05-21 07:58:46 --> Input Class Initialized
DEBUG - 2011-05-21 07:58:46 --> Global POST and COOKIE data sanitized
DEBUG - 2011-05-21 07:58:46 --> Language Class Initialized
DEBUG - 2011-05-21 07:58:46 --> Loader Class Initialized
DEBUG - 2011-05-21 07:58:46 --> Controller Class Initialized
ERROR - 2011-05-21 07:58:46 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-05-21 07:58:46 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-05-21 07:58:46 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-05-21 07:58:46 --> Model Class Initialized
DEBUG - 2011-05-21 07:58:46 --> Model Class Initialized
DEBUG - 2011-05-21 07:58:46 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-05-21 07:58:46 --> Database Driver Class Initialized
DEBUG - 2011-05-21 07:58:46 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-05-21 07:58:46 --> Helper loaded: url_helper
DEBUG - 2011-05-21 07:58:46 --> File loaded: application/views/common/header.php
DEBUG - 2011-05-21 07:58:46 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-05-21 07:58:46 --> File loaded: application/views/common/footer.php
DEBUG - 2011-05-21 07:58:46 --> File loaded: application/views/layout/main.php
DEBUG - 2011-05-21 07:58:46 --> Final output sent to browser
DEBUG - 2011-05-21 07:58:46 --> Total execution time: 0.0296
DEBUG - 2011-05-21 07:58:47 --> Config Class Initialized
DEBUG - 2011-05-21 07:58:47 --> Hooks Class Initialized
DEBUG - 2011-05-21 07:58:47 --> Utf8 Class Initialized
DEBUG - 2011-05-21 07:58:47 --> UTF-8 Support Enabled
DEBUG - 2011-05-21 07:58:47 --> URI Class Initialized
DEBUG - 2011-05-21 07:58:47 --> Router Class Initialized
DEBUG - 2011-05-21 07:58:47 --> Output Class Initialized
DEBUG - 2011-05-21 07:58:47 --> Input Class Initialized
DEBUG - 2011-05-21 07:58:47 --> Global POST and COOKIE data sanitized
DEBUG - 2011-05-21 07:58:47 --> Language Class Initialized
DEBUG - 2011-05-21 07:58:47 --> Loader Class Initialized
DEBUG - 2011-05-21 07:58:47 --> Controller Class Initialized
DEBUG - 2011-05-21 07:58:47 --> Model Class Initialized
DEBUG - 2011-05-21 07:58:47 --> Model Class Initialized
DEBUG - 2011-05-21 07:58:47 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-05-21 07:58:47 --> Database Driver Class Initialized
DEBUG - 2011-05-21 07:58:48 --> Final output sent to browser
DEBUG - 2011-05-21 07:58:48 --> Total execution time: 1.2010
DEBUG - 2011-05-21 07:59:12 --> Config Class Initialized
DEBUG - 2011-05-21 07:59:12 --> Hooks Class Initialized
DEBUG - 2011-05-21 07:59:12 --> Utf8 Class Initialized
DEBUG - 2011-05-21 07:59:12 --> UTF-8 Support Enabled
DEBUG - 2011-05-21 07:59:12 --> URI Class Initialized
DEBUG - 2011-05-21 07:59:12 --> Router Class Initialized
DEBUG - 2011-05-21 07:59:12 --> Output Class Initialized
DEBUG - 2011-05-21 07:59:12 --> Input Class Initialized
DEBUG - 2011-05-21 07:59:12 --> Global POST and COOKIE data sanitized
DEBUG - 2011-05-21 07:59:12 --> Language Class Initialized
DEBUG - 2011-05-21 07:59:12 --> Loader Class Initialized
DEBUG - 2011-05-21 07:59:12 --> Controller Class Initialized
ERROR - 2011-05-21 07:59:12 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-05-21 07:59:12 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-05-21 07:59:12 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-05-21 07:59:12 --> Model Class Initialized
DEBUG - 2011-05-21 07:59:12 --> Model Class Initialized
DEBUG - 2011-05-21 07:59:12 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-05-21 07:59:12 --> Database Driver Class Initialized
DEBUG - 2011-05-21 07:59:12 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-05-21 07:59:12 --> Helper loaded: url_helper
DEBUG - 2011-05-21 07:59:12 --> File loaded: application/views/common/header.php
DEBUG - 2011-05-21 07:59:12 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-05-21 07:59:12 --> File loaded: application/views/common/footer.php
DEBUG - 2011-05-21 07:59:12 --> File loaded: application/views/layout/main.php
DEBUG - 2011-05-21 07:59:12 --> Final output sent to browser
DEBUG - 2011-05-21 07:59:12 --> Total execution time: 0.0606
DEBUG - 2011-05-21 07:59:13 --> Config Class Initialized
DEBUG - 2011-05-21 07:59:13 --> Hooks Class Initialized
DEBUG - 2011-05-21 07:59:13 --> Utf8 Class Initialized
DEBUG - 2011-05-21 07:59:13 --> UTF-8 Support Enabled
DEBUG - 2011-05-21 07:59:13 --> URI Class Initialized
DEBUG - 2011-05-21 07:59:13 --> Router Class Initialized
DEBUG - 2011-05-21 07:59:13 --> Output Class Initialized
DEBUG - 2011-05-21 07:59:13 --> Input Class Initialized
DEBUG - 2011-05-21 07:59:13 --> Global POST and COOKIE data sanitized
DEBUG - 2011-05-21 07:59:13 --> Language Class Initialized
DEBUG - 2011-05-21 07:59:13 --> Loader Class Initialized
DEBUG - 2011-05-21 07:59:13 --> Controller Class Initialized
DEBUG - 2011-05-21 07:59:13 --> Model Class Initialized
DEBUG - 2011-05-21 07:59:13 --> Model Class Initialized
DEBUG - 2011-05-21 07:59:13 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-05-21 07:59:13 --> Database Driver Class Initialized
DEBUG - 2011-05-21 07:59:14 --> Final output sent to browser
DEBUG - 2011-05-21 07:59:14 --> Total execution time: 1.0860
DEBUG - 2011-05-21 07:59:50 --> Config Class Initialized
DEBUG - 2011-05-21 07:59:50 --> Hooks Class Initialized
DEBUG - 2011-05-21 07:59:50 --> Utf8 Class Initialized
DEBUG - 2011-05-21 07:59:50 --> UTF-8 Support Enabled
DEBUG - 2011-05-21 07:59:50 --> URI Class Initialized
DEBUG - 2011-05-21 07:59:50 --> Router Class Initialized
DEBUG - 2011-05-21 07:59:50 --> Output Class Initialized
DEBUG - 2011-05-21 07:59:50 --> Input Class Initialized
DEBUG - 2011-05-21 07:59:50 --> Global POST and COOKIE data sanitized
DEBUG - 2011-05-21 07:59:50 --> Language Class Initialized
DEBUG - 2011-05-21 07:59:50 --> Loader Class Initialized
DEBUG - 2011-05-21 07:59:50 --> Controller Class Initialized
ERROR - 2011-05-21 07:59:50 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-05-21 07:59:50 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-05-21 07:59:50 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-05-21 07:59:50 --> Model Class Initialized
DEBUG - 2011-05-21 07:59:50 --> Model Class Initialized
DEBUG - 2011-05-21 07:59:50 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-05-21 07:59:50 --> Database Driver Class Initialized
DEBUG - 2011-05-21 07:59:50 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-05-21 07:59:50 --> Helper loaded: url_helper
DEBUG - 2011-05-21 07:59:50 --> File loaded: application/views/common/header.php
DEBUG - 2011-05-21 07:59:50 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-05-21 07:59:50 --> File loaded: application/views/common/footer.php
DEBUG - 2011-05-21 07:59:50 --> File loaded: application/views/layout/main.php
DEBUG - 2011-05-21 07:59:50 --> Final output sent to browser
DEBUG - 2011-05-21 07:59:50 --> Total execution time: 0.0300
DEBUG - 2011-05-21 07:59:51 --> Config Class Initialized
DEBUG - 2011-05-21 07:59:51 --> Hooks Class Initialized
DEBUG - 2011-05-21 07:59:51 --> Utf8 Class Initialized
DEBUG - 2011-05-21 07:59:51 --> UTF-8 Support Enabled
DEBUG - 2011-05-21 07:59:51 --> URI Class Initialized
DEBUG - 2011-05-21 07:59:51 --> Router Class Initialized
DEBUG - 2011-05-21 07:59:51 --> Output Class Initialized
DEBUG - 2011-05-21 07:59:51 --> Input Class Initialized
DEBUG - 2011-05-21 07:59:51 --> Global POST and COOKIE data sanitized
DEBUG - 2011-05-21 07:59:51 --> Language Class Initialized
DEBUG - 2011-05-21 07:59:51 --> Loader Class Initialized
DEBUG - 2011-05-21 07:59:51 --> Controller Class Initialized
DEBUG - 2011-05-21 07:59:51 --> Model Class Initialized
DEBUG - 2011-05-21 07:59:51 --> Model Class Initialized
DEBUG - 2011-05-21 07:59:51 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-05-21 07:59:51 --> Database Driver Class Initialized
DEBUG - 2011-05-21 07:59:52 --> Final output sent to browser
DEBUG - 2011-05-21 07:59:52 --> Total execution time: 0.5007
DEBUG - 2011-05-21 08:00:18 --> Config Class Initialized
DEBUG - 2011-05-21 08:00:18 --> Hooks Class Initialized
DEBUG - 2011-05-21 08:00:18 --> Utf8 Class Initialized
DEBUG - 2011-05-21 08:00:18 --> UTF-8 Support Enabled
DEBUG - 2011-05-21 08:00:18 --> URI Class Initialized
DEBUG - 2011-05-21 08:00:18 --> Router Class Initialized
DEBUG - 2011-05-21 08:00:18 --> Output Class Initialized
DEBUG - 2011-05-21 08:00:18 --> Input Class Initialized
DEBUG - 2011-05-21 08:00:18 --> Global POST and COOKIE data sanitized
DEBUG - 2011-05-21 08:00:18 --> Language Class Initialized
DEBUG - 2011-05-21 08:00:18 --> Loader Class Initialized
DEBUG - 2011-05-21 08:00:18 --> Controller Class Initialized
ERROR - 2011-05-21 08:00:18 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-05-21 08:00:18 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-05-21 08:00:18 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-05-21 08:00:18 --> Model Class Initialized
DEBUG - 2011-05-21 08:00:18 --> Model Class Initialized
DEBUG - 2011-05-21 08:00:18 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-05-21 08:00:18 --> Database Driver Class Initialized
DEBUG - 2011-05-21 08:00:18 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-05-21 08:00:18 --> Helper loaded: url_helper
DEBUG - 2011-05-21 08:00:18 --> File loaded: application/views/common/header.php
DEBUG - 2011-05-21 08:00:18 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-05-21 08:00:18 --> File loaded: application/views/common/footer.php
DEBUG - 2011-05-21 08:00:18 --> File loaded: application/views/layout/main.php
DEBUG - 2011-05-21 08:00:18 --> Final output sent to browser
DEBUG - 2011-05-21 08:00:18 --> Total execution time: 0.0305
DEBUG - 2011-05-21 08:00:20 --> Config Class Initialized
DEBUG - 2011-05-21 08:00:20 --> Hooks Class Initialized
DEBUG - 2011-05-21 08:00:20 --> Utf8 Class Initialized
DEBUG - 2011-05-21 08:00:20 --> UTF-8 Support Enabled
DEBUG - 2011-05-21 08:00:20 --> URI Class Initialized
DEBUG - 2011-05-21 08:00:20 --> Router Class Initialized
DEBUG - 2011-05-21 08:00:20 --> Output Class Initialized
DEBUG - 2011-05-21 08:00:20 --> Input Class Initialized
DEBUG - 2011-05-21 08:00:20 --> Global POST and COOKIE data sanitized
DEBUG - 2011-05-21 08:00:20 --> Language Class Initialized
DEBUG - 2011-05-21 08:00:20 --> Loader Class Initialized
DEBUG - 2011-05-21 08:00:20 --> Controller Class Initialized
DEBUG - 2011-05-21 08:00:20 --> Model Class Initialized
DEBUG - 2011-05-21 08:00:20 --> Model Class Initialized
DEBUG - 2011-05-21 08:00:20 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-05-21 08:00:20 --> Database Driver Class Initialized
DEBUG - 2011-05-21 08:00:20 --> Final output sent to browser
DEBUG - 2011-05-21 08:00:20 --> Total execution time: 0.6875
DEBUG - 2011-05-21 08:00:52 --> Config Class Initialized
DEBUG - 2011-05-21 08:00:52 --> Hooks Class Initialized
DEBUG - 2011-05-21 08:00:52 --> Utf8 Class Initialized
DEBUG - 2011-05-21 08:00:52 --> UTF-8 Support Enabled
DEBUG - 2011-05-21 08:00:52 --> URI Class Initialized
DEBUG - 2011-05-21 08:00:52 --> Router Class Initialized
DEBUG - 2011-05-21 08:00:52 --> Output Class Initialized
DEBUG - 2011-05-21 08:00:52 --> Input Class Initialized
DEBUG - 2011-05-21 08:00:52 --> Global POST and COOKIE data sanitized
DEBUG - 2011-05-21 08:00:52 --> Language Class Initialized
DEBUG - 2011-05-21 08:00:52 --> Loader Class Initialized
DEBUG - 2011-05-21 08:00:52 --> Controller Class Initialized
ERROR - 2011-05-21 08:00:52 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-05-21 08:00:52 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-05-21 08:00:52 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-05-21 08:00:52 --> Model Class Initialized
DEBUG - 2011-05-21 08:00:52 --> Model Class Initialized
DEBUG - 2011-05-21 08:00:52 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-05-21 08:00:52 --> Database Driver Class Initialized
DEBUG - 2011-05-21 08:00:52 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-05-21 08:00:52 --> Helper loaded: url_helper
DEBUG - 2011-05-21 08:00:52 --> File loaded: application/views/common/header.php
DEBUG - 2011-05-21 08:00:52 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-05-21 08:00:52 --> File loaded: application/views/common/footer.php
DEBUG - 2011-05-21 08:00:52 --> File loaded: application/views/layout/main.php
DEBUG - 2011-05-21 08:00:52 --> Final output sent to browser
DEBUG - 2011-05-21 08:00:52 --> Total execution time: 0.0300
DEBUG - 2011-05-21 08:00:52 --> Config Class Initialized
DEBUG - 2011-05-21 08:00:52 --> Hooks Class Initialized
DEBUG - 2011-05-21 08:00:52 --> Utf8 Class Initialized
DEBUG - 2011-05-21 08:00:52 --> UTF-8 Support Enabled
DEBUG - 2011-05-21 08:00:52 --> URI Class Initialized
DEBUG - 2011-05-21 08:00:52 --> Router Class Initialized
DEBUG - 2011-05-21 08:00:52 --> Output Class Initialized
DEBUG - 2011-05-21 08:00:52 --> Input Class Initialized
DEBUG - 2011-05-21 08:00:52 --> Global POST and COOKIE data sanitized
DEBUG - 2011-05-21 08:00:52 --> Language Class Initialized
DEBUG - 2011-05-21 08:00:52 --> Loader Class Initialized
DEBUG - 2011-05-21 08:00:52 --> Controller Class Initialized
DEBUG - 2011-05-21 08:00:52 --> Model Class Initialized
DEBUG - 2011-05-21 08:00:52 --> Model Class Initialized
DEBUG - 2011-05-21 08:00:52 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-05-21 08:00:52 --> Database Driver Class Initialized
DEBUG - 2011-05-21 08:00:53 --> Final output sent to browser
DEBUG - 2011-05-21 08:00:53 --> Total execution time: 0.8999
DEBUG - 2011-05-21 08:00:55 --> Config Class Initialized
DEBUG - 2011-05-21 08:00:55 --> Hooks Class Initialized
DEBUG - 2011-05-21 08:00:55 --> Utf8 Class Initialized
DEBUG - 2011-05-21 08:00:55 --> UTF-8 Support Enabled
DEBUG - 2011-05-21 08:00:55 --> URI Class Initialized
DEBUG - 2011-05-21 08:00:55 --> Router Class Initialized
DEBUG - 2011-05-21 08:00:55 --> Output Class Initialized
DEBUG - 2011-05-21 08:00:55 --> Input Class Initialized
DEBUG - 2011-05-21 08:00:55 --> Global POST and COOKIE data sanitized
DEBUG - 2011-05-21 08:00:55 --> Language Class Initialized
DEBUG - 2011-05-21 08:00:55 --> Loader Class Initialized
DEBUG - 2011-05-21 08:00:55 --> Controller Class Initialized
ERROR - 2011-05-21 08:00:55 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-05-21 08:00:55 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-05-21 08:00:55 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-05-21 08:00:55 --> Model Class Initialized
DEBUG - 2011-05-21 08:00:55 --> Model Class Initialized
DEBUG - 2011-05-21 08:00:55 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-05-21 08:00:55 --> Database Driver Class Initialized
DEBUG - 2011-05-21 08:00:55 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-05-21 08:00:55 --> Helper loaded: url_helper
DEBUG - 2011-05-21 08:00:55 --> File loaded: application/views/common/header.php
DEBUG - 2011-05-21 08:00:55 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-05-21 08:00:55 --> File loaded: application/views/common/footer.php
DEBUG - 2011-05-21 08:00:55 --> File loaded: application/views/layout/main.php
DEBUG - 2011-05-21 08:00:55 --> Final output sent to browser
DEBUG - 2011-05-21 08:00:55 --> Total execution time: 0.0302
DEBUG - 2011-05-21 08:00:56 --> Config Class Initialized
DEBUG - 2011-05-21 08:00:56 --> Hooks Class Initialized
DEBUG - 2011-05-21 08:00:56 --> Utf8 Class Initialized
DEBUG - 2011-05-21 08:00:56 --> UTF-8 Support Enabled
DEBUG - 2011-05-21 08:00:56 --> URI Class Initialized
DEBUG - 2011-05-21 08:00:56 --> Router Class Initialized
DEBUG - 2011-05-21 08:00:56 --> Output Class Initialized
DEBUG - 2011-05-21 08:00:56 --> Input Class Initialized
DEBUG - 2011-05-21 08:00:56 --> Global POST and COOKIE data sanitized
DEBUG - 2011-05-21 08:00:56 --> Language Class Initialized
DEBUG - 2011-05-21 08:00:56 --> Loader Class Initialized
DEBUG - 2011-05-21 08:00:56 --> Controller Class Initialized
DEBUG - 2011-05-21 08:00:56 --> Model Class Initialized
DEBUG - 2011-05-21 08:00:56 --> Model Class Initialized
DEBUG - 2011-05-21 08:00:56 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-05-21 08:00:56 --> Database Driver Class Initialized
DEBUG - 2011-05-21 08:00:56 --> Final output sent to browser
DEBUG - 2011-05-21 08:00:56 --> Total execution time: 0.5641
DEBUG - 2011-05-21 08:01:08 --> Config Class Initialized
DEBUG - 2011-05-21 08:01:08 --> Hooks Class Initialized
DEBUG - 2011-05-21 08:01:08 --> Utf8 Class Initialized
DEBUG - 2011-05-21 08:01:08 --> UTF-8 Support Enabled
DEBUG - 2011-05-21 08:01:08 --> URI Class Initialized
DEBUG - 2011-05-21 08:01:08 --> Router Class Initialized
DEBUG - 2011-05-21 08:01:08 --> Output Class Initialized
DEBUG - 2011-05-21 08:01:08 --> Input Class Initialized
DEBUG - 2011-05-21 08:01:08 --> Global POST and COOKIE data sanitized
DEBUG - 2011-05-21 08:01:08 --> Language Class Initialized
DEBUG - 2011-05-21 08:01:08 --> Loader Class Initialized
DEBUG - 2011-05-21 08:01:08 --> Controller Class Initialized
ERROR - 2011-05-21 08:01:08 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-05-21 08:01:08 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-05-21 08:01:08 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-05-21 08:01:08 --> Model Class Initialized
DEBUG - 2011-05-21 08:01:08 --> Model Class Initialized
DEBUG - 2011-05-21 08:01:08 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-05-21 08:01:08 --> Database Driver Class Initialized
DEBUG - 2011-05-21 08:01:08 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-05-21 08:01:08 --> Helper loaded: url_helper
DEBUG - 2011-05-21 08:01:08 --> File loaded: application/views/common/header.php
DEBUG - 2011-05-21 08:01:08 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-05-21 08:01:08 --> File loaded: application/views/common/footer.php
DEBUG - 2011-05-21 08:01:08 --> File loaded: application/views/layout/main.php
DEBUG - 2011-05-21 08:01:08 --> Final output sent to browser
DEBUG - 2011-05-21 08:01:08 --> Total execution time: 0.0303
DEBUG - 2011-05-21 08:01:09 --> Config Class Initialized
DEBUG - 2011-05-21 08:01:09 --> Hooks Class Initialized
DEBUG - 2011-05-21 08:01:09 --> Utf8 Class Initialized
DEBUG - 2011-05-21 08:01:09 --> UTF-8 Support Enabled
DEBUG - 2011-05-21 08:01:09 --> URI Class Initialized
DEBUG - 2011-05-21 08:01:09 --> Router Class Initialized
DEBUG - 2011-05-21 08:01:09 --> Output Class Initialized
DEBUG - 2011-05-21 08:01:09 --> Input Class Initialized
DEBUG - 2011-05-21 08:01:09 --> Global POST and COOKIE data sanitized
DEBUG - 2011-05-21 08:01:09 --> Language Class Initialized
DEBUG - 2011-05-21 08:01:09 --> Loader Class Initialized
DEBUG - 2011-05-21 08:01:09 --> Controller Class Initialized
DEBUG - 2011-05-21 08:01:09 --> Model Class Initialized
DEBUG - 2011-05-21 08:01:09 --> Model Class Initialized
DEBUG - 2011-05-21 08:01:09 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-05-21 08:01:09 --> Database Driver Class Initialized
DEBUG - 2011-05-21 08:01:09 --> Final output sent to browser
DEBUG - 2011-05-21 08:01:09 --> Total execution time: 0.8460
DEBUG - 2011-05-21 08:01:31 --> Config Class Initialized
DEBUG - 2011-05-21 08:01:31 --> Hooks Class Initialized
DEBUG - 2011-05-21 08:01:31 --> Utf8 Class Initialized
DEBUG - 2011-05-21 08:01:31 --> UTF-8 Support Enabled
DEBUG - 2011-05-21 08:01:31 --> URI Class Initialized
DEBUG - 2011-05-21 08:01:31 --> Router Class Initialized
DEBUG - 2011-05-21 08:01:31 --> Output Class Initialized
DEBUG - 2011-05-21 08:01:31 --> Input Class Initialized
DEBUG - 2011-05-21 08:01:31 --> Global POST and COOKIE data sanitized
DEBUG - 2011-05-21 08:01:31 --> Language Class Initialized
DEBUG - 2011-05-21 08:01:31 --> Loader Class Initialized
DEBUG - 2011-05-21 08:01:31 --> Controller Class Initialized
DEBUG - 2011-05-21 08:01:31 --> Model Class Initialized
DEBUG - 2011-05-21 08:01:31 --> Model Class Initialized
DEBUG - 2011-05-21 08:01:31 --> Model Class Initialized
DEBUG - 2011-05-21 08:01:31 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-05-21 08:01:31 --> Database Driver Class Initialized
DEBUG - 2011-05-21 08:01:31 --> File loaded: application/views/table/main.php
DEBUG - 2011-05-21 08:01:31 --> Helper loaded: url_helper
DEBUG - 2011-05-21 08:01:31 --> File loaded: application/views/common/header.php
DEBUG - 2011-05-21 08:01:31 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-05-21 08:01:31 --> File loaded: application/views/common/footer.php
DEBUG - 2011-05-21 08:01:31 --> File loaded: application/views/layout/main.php
DEBUG - 2011-05-21 08:01:31 --> Final output sent to browser
DEBUG - 2011-05-21 08:01:31 --> Total execution time: 0.2748
DEBUG - 2011-05-21 09:44:35 --> Config Class Initialized
DEBUG - 2011-05-21 09:44:35 --> Hooks Class Initialized
DEBUG - 2011-05-21 09:44:35 --> Utf8 Class Initialized
DEBUG - 2011-05-21 09:44:35 --> UTF-8 Support Enabled
DEBUG - 2011-05-21 09:44:35 --> URI Class Initialized
DEBUG - 2011-05-21 09:44:35 --> Router Class Initialized
ERROR - 2011-05-21 09:44:35 --> 404 Page Not Found --> robots.txt
DEBUG - 2011-05-21 10:35:41 --> Config Class Initialized
DEBUG - 2011-05-21 10:35:41 --> Hooks Class Initialized
DEBUG - 2011-05-21 10:35:41 --> Utf8 Class Initialized
DEBUG - 2011-05-21 10:35:41 --> UTF-8 Support Enabled
DEBUG - 2011-05-21 10:35:41 --> URI Class Initialized
DEBUG - 2011-05-21 10:35:41 --> Router Class Initialized
DEBUG - 2011-05-21 10:35:41 --> Output Class Initialized
DEBUG - 2011-05-21 10:35:41 --> Input Class Initialized
DEBUG - 2011-05-21 10:35:41 --> Global POST and COOKIE data sanitized
DEBUG - 2011-05-21 10:35:41 --> Language Class Initialized
DEBUG - 2011-05-21 10:35:41 --> Loader Class Initialized
DEBUG - 2011-05-21 10:35:41 --> Controller Class Initialized
DEBUG - 2011-05-21 10:35:41 --> Model Class Initialized
DEBUG - 2011-05-21 10:35:41 --> Model Class Initialized
DEBUG - 2011-05-21 10:35:41 --> Model Class Initialized
DEBUG - 2011-05-21 10:35:41 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-05-21 10:35:41 --> Database Driver Class Initialized
DEBUG - 2011-05-21 10:35:41 --> File loaded: application/views/table/main.php
DEBUG - 2011-05-21 10:35:42 --> Helper loaded: url_helper
DEBUG - 2011-05-21 10:35:42 --> File loaded: application/views/common/header.php
DEBUG - 2011-05-21 10:35:42 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-05-21 10:35:42 --> File loaded: application/views/common/footer.php
DEBUG - 2011-05-21 10:35:42 --> File loaded: application/views/layout/main.php
DEBUG - 2011-05-21 10:35:42 --> Final output sent to browser
DEBUG - 2011-05-21 10:35:42 --> Total execution time: 0.6738
DEBUG - 2011-05-21 12:06:13 --> Config Class Initialized
DEBUG - 2011-05-21 12:06:13 --> Hooks Class Initialized
DEBUG - 2011-05-21 12:06:13 --> Utf8 Class Initialized
DEBUG - 2011-05-21 12:06:13 --> UTF-8 Support Enabled
DEBUG - 2011-05-21 12:06:13 --> URI Class Initialized
DEBUG - 2011-05-21 12:06:13 --> Router Class Initialized
ERROR - 2011-05-21 12:06:13 --> 404 Page Not Found --> robots.txt
DEBUG - 2011-05-21 12:10:29 --> Config Class Initialized
DEBUG - 2011-05-21 12:10:29 --> Hooks Class Initialized
DEBUG - 2011-05-21 12:10:29 --> Utf8 Class Initialized
DEBUG - 2011-05-21 12:10:29 --> UTF-8 Support Enabled
DEBUG - 2011-05-21 12:10:29 --> URI Class Initialized
DEBUG - 2011-05-21 12:10:29 --> Router Class Initialized
DEBUG - 2011-05-21 12:10:29 --> Output Class Initialized
DEBUG - 2011-05-21 12:10:29 --> Input Class Initialized
DEBUG - 2011-05-21 12:10:29 --> Global POST and COOKIE data sanitized
DEBUG - 2011-05-21 12:10:29 --> Language Class Initialized
DEBUG - 2011-05-21 12:10:29 --> Loader Class Initialized
DEBUG - 2011-05-21 12:10:29 --> Controller Class Initialized
DEBUG - 2011-05-21 12:10:29 --> Model Class Initialized
DEBUG - 2011-05-21 12:10:29 --> Model Class Initialized
DEBUG - 2011-05-21 12:10:29 --> Model Class Initialized
DEBUG - 2011-05-21 12:10:29 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-05-21 12:10:30 --> Database Driver Class Initialized
DEBUG - 2011-05-21 12:10:30 --> File loaded: application/views/table/main.php
DEBUG - 2011-05-21 12:10:30 --> Helper loaded: url_helper
DEBUG - 2011-05-21 12:10:30 --> File loaded: application/views/common/header.php
DEBUG - 2011-05-21 12:10:30 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-05-21 12:10:30 --> File loaded: application/views/common/footer.php
DEBUG - 2011-05-21 12:10:30 --> File loaded: application/views/layout/main.php
DEBUG - 2011-05-21 12:10:30 --> Final output sent to browser
DEBUG - 2011-05-21 12:10:30 --> Total execution time: 1.1226
DEBUG - 2011-05-21 12:10:32 --> Config Class Initialized
DEBUG - 2011-05-21 12:10:32 --> Hooks Class Initialized
DEBUG - 2011-05-21 12:10:32 --> Utf8 Class Initialized
DEBUG - 2011-05-21 12:10:32 --> UTF-8 Support Enabled
DEBUG - 2011-05-21 12:10:32 --> URI Class Initialized
DEBUG - 2011-05-21 12:10:32 --> Router Class Initialized
DEBUG - 2011-05-21 12:10:32 --> Output Class Initialized
DEBUG - 2011-05-21 12:10:32 --> Input Class Initialized
DEBUG - 2011-05-21 12:10:32 --> Global POST and COOKIE data sanitized
DEBUG - 2011-05-21 12:10:32 --> Language Class Initialized
DEBUG - 2011-05-21 12:10:32 --> Loader Class Initialized
DEBUG - 2011-05-21 12:10:32 --> Controller Class Initialized
ERROR - 2011-05-21 12:10:32 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-05-21 12:10:32 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-05-21 12:10:32 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-05-21 12:10:32 --> Model Class Initialized
DEBUG - 2011-05-21 12:10:32 --> Model Class Initialized
DEBUG - 2011-05-21 12:10:32 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-05-21 12:10:32 --> Database Driver Class Initialized
DEBUG - 2011-05-21 12:10:32 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-05-21 12:10:32 --> Helper loaded: url_helper
DEBUG - 2011-05-21 12:10:32 --> File loaded: application/views/common/header.php
DEBUG - 2011-05-21 12:10:32 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-05-21 12:10:32 --> File loaded: application/views/common/footer.php
DEBUG - 2011-05-21 12:10:32 --> File loaded: application/views/layout/main.php
DEBUG - 2011-05-21 12:10:32 --> Final output sent to browser
DEBUG - 2011-05-21 12:10:32 --> Total execution time: 0.2333
DEBUG - 2011-05-21 12:57:38 --> Config Class Initialized
DEBUG - 2011-05-21 12:57:39 --> Hooks Class Initialized
DEBUG - 2011-05-21 12:57:39 --> Utf8 Class Initialized
DEBUG - 2011-05-21 12:57:39 --> UTF-8 Support Enabled
DEBUG - 2011-05-21 12:57:39 --> URI Class Initialized
DEBUG - 2011-05-21 12:57:39 --> Router Class Initialized
DEBUG - 2011-05-21 12:57:39 --> Output Class Initialized
DEBUG - 2011-05-21 12:57:39 --> Input Class Initialized
DEBUG - 2011-05-21 12:57:39 --> Global POST and COOKIE data sanitized
DEBUG - 2011-05-21 12:57:39 --> Language Class Initialized
DEBUG - 2011-05-21 12:57:39 --> Loader Class Initialized
DEBUG - 2011-05-21 12:57:39 --> Controller Class Initialized
DEBUG - 2011-05-21 12:57:39 --> Model Class Initialized
DEBUG - 2011-05-21 12:57:39 --> Model Class Initialized
DEBUG - 2011-05-21 12:57:39 --> Model Class Initialized
DEBUG - 2011-05-21 12:57:39 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-05-21 12:57:39 --> Database Driver Class Initialized
DEBUG - 2011-05-21 12:57:39 --> File loaded: application/views/table/main.php
DEBUG - 2011-05-21 12:57:39 --> Helper loaded: url_helper
DEBUG - 2011-05-21 12:57:39 --> File loaded: application/views/common/header.php
DEBUG - 2011-05-21 12:57:39 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-05-21 12:57:39 --> File loaded: application/views/common/footer.php
DEBUG - 2011-05-21 12:57:39 --> File loaded: application/views/layout/main.php
DEBUG - 2011-05-21 12:57:39 --> Final output sent to browser
DEBUG - 2011-05-21 12:57:39 --> Total execution time: 0.5150
DEBUG - 2011-05-21 12:57:42 --> Config Class Initialized
DEBUG - 2011-05-21 12:57:42 --> Hooks Class Initialized
DEBUG - 2011-05-21 12:57:42 --> Utf8 Class Initialized
DEBUG - 2011-05-21 12:57:42 --> UTF-8 Support Enabled
DEBUG - 2011-05-21 12:57:42 --> URI Class Initialized
DEBUG - 2011-05-21 12:57:42 --> Router Class Initialized
DEBUG - 2011-05-21 12:57:42 --> Output Class Initialized
DEBUG - 2011-05-21 12:57:42 --> Input Class Initialized
DEBUG - 2011-05-21 12:57:42 --> Global POST and COOKIE data sanitized
DEBUG - 2011-05-21 12:57:42 --> Language Class Initialized
DEBUG - 2011-05-21 12:57:42 --> Loader Class Initialized
DEBUG - 2011-05-21 12:57:42 --> Controller Class Initialized
DEBUG - 2011-05-21 12:57:42 --> Model Class Initialized
DEBUG - 2011-05-21 12:57:42 --> Model Class Initialized
DEBUG - 2011-05-21 12:57:42 --> Model Class Initialized
DEBUG - 2011-05-21 12:57:42 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-05-21 12:57:42 --> Database Driver Class Initialized
DEBUG - 2011-05-21 12:57:42 --> File loaded: application/views/table/main.php
DEBUG - 2011-05-21 12:57:42 --> Helper loaded: url_helper
DEBUG - 2011-05-21 12:57:42 --> File loaded: application/views/common/header.php
DEBUG - 2011-05-21 12:57:42 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-05-21 12:57:42 --> File loaded: application/views/common/footer.php
DEBUG - 2011-05-21 12:57:42 --> File loaded: application/views/layout/main.php
DEBUG - 2011-05-21 12:57:42 --> Final output sent to browser
DEBUG - 2011-05-21 12:57:42 --> Total execution time: 0.0429
DEBUG - 2011-05-21 13:38:05 --> Config Class Initialized
DEBUG - 2011-05-21 13:38:05 --> Hooks Class Initialized
DEBUG - 2011-05-21 13:38:05 --> Utf8 Class Initialized
DEBUG - 2011-05-21 13:38:05 --> UTF-8 Support Enabled
DEBUG - 2011-05-21 13:38:05 --> URI Class Initialized
DEBUG - 2011-05-21 13:38:05 --> Router Class Initialized
DEBUG - 2011-05-21 13:38:05 --> Output Class Initialized
DEBUG - 2011-05-21 13:38:05 --> Input Class Initialized
DEBUG - 2011-05-21 13:38:05 --> Global POST and COOKIE data sanitized
DEBUG - 2011-05-21 13:38:05 --> Language Class Initialized
DEBUG - 2011-05-21 13:38:05 --> Loader Class Initialized
DEBUG - 2011-05-21 13:38:05 --> Controller Class Initialized
DEBUG - 2011-05-21 13:38:05 --> Model Class Initialized
DEBUG - 2011-05-21 13:38:05 --> Model Class Initialized
DEBUG - 2011-05-21 13:38:05 --> Model Class Initialized
DEBUG - 2011-05-21 13:38:05 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-05-21 13:38:05 --> Database Driver Class Initialized
DEBUG - 2011-05-21 13:38:06 --> File loaded: application/views/table/main.php
DEBUG - 2011-05-21 13:38:06 --> Helper loaded: url_helper
DEBUG - 2011-05-21 13:38:06 --> File loaded: application/views/common/header.php
DEBUG - 2011-05-21 13:38:06 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-05-21 13:38:06 --> File loaded: application/views/common/footer.php
DEBUG - 2011-05-21 13:38:06 --> File loaded: application/views/layout/main.php
DEBUG - 2011-05-21 13:38:06 --> Final output sent to browser
DEBUG - 2011-05-21 13:38:06 --> Total execution time: 1.0193
DEBUG - 2011-05-21 13:38:08 --> Config Class Initialized
DEBUG - 2011-05-21 13:38:08 --> Hooks Class Initialized
DEBUG - 2011-05-21 13:38:08 --> Utf8 Class Initialized
DEBUG - 2011-05-21 13:38:08 --> UTF-8 Support Enabled
DEBUG - 2011-05-21 13:38:08 --> URI Class Initialized
DEBUG - 2011-05-21 13:38:08 --> Router Class Initialized
ERROR - 2011-05-21 13:38:08 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-05-21 13:38:09 --> Config Class Initialized
DEBUG - 2011-05-21 13:38:09 --> Hooks Class Initialized
DEBUG - 2011-05-21 13:38:09 --> Utf8 Class Initialized
DEBUG - 2011-05-21 13:38:09 --> UTF-8 Support Enabled
DEBUG - 2011-05-21 13:38:09 --> URI Class Initialized
DEBUG - 2011-05-21 13:38:09 --> Router Class Initialized
ERROR - 2011-05-21 13:38:09 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-05-21 13:38:09 --> Config Class Initialized
DEBUG - 2011-05-21 13:38:09 --> Hooks Class Initialized
DEBUG - 2011-05-21 13:38:09 --> Utf8 Class Initialized
DEBUG - 2011-05-21 13:38:09 --> UTF-8 Support Enabled
DEBUG - 2011-05-21 13:38:09 --> URI Class Initialized
DEBUG - 2011-05-21 13:38:09 --> Router Class Initialized
DEBUG - 2011-05-21 13:38:09 --> Output Class Initialized
DEBUG - 2011-05-21 13:38:09 --> Input Class Initialized
DEBUG - 2011-05-21 13:38:09 --> Global POST and COOKIE data sanitized
DEBUG - 2011-05-21 13:38:09 --> Language Class Initialized
DEBUG - 2011-05-21 13:38:09 --> Loader Class Initialized
DEBUG - 2011-05-21 13:38:09 --> Controller Class Initialized
DEBUG - 2011-05-21 13:38:09 --> Model Class Initialized
DEBUG - 2011-05-21 13:38:09 --> Model Class Initialized
DEBUG - 2011-05-21 13:38:09 --> Model Class Initialized
DEBUG - 2011-05-21 13:38:09 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-05-21 13:38:09 --> Database Driver Class Initialized
DEBUG - 2011-05-21 13:38:09 --> File loaded: application/views/table/main.php
DEBUG - 2011-05-21 13:38:09 --> Helper loaded: url_helper
DEBUG - 2011-05-21 13:38:09 --> File loaded: application/views/common/header.php
DEBUG - 2011-05-21 13:38:09 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-05-21 13:38:09 --> File loaded: application/views/common/footer.php
DEBUG - 2011-05-21 13:38:09 --> File loaded: application/views/layout/main.php
DEBUG - 2011-05-21 13:38:09 --> Final output sent to browser
DEBUG - 2011-05-21 13:38:09 --> Total execution time: 0.0780
DEBUG - 2011-05-21 15:05:23 --> Config Class Initialized
DEBUG - 2011-05-21 15:05:23 --> Hooks Class Initialized
DEBUG - 2011-05-21 15:05:23 --> Utf8 Class Initialized
DEBUG - 2011-05-21 15:05:23 --> UTF-8 Support Enabled
DEBUG - 2011-05-21 15:05:23 --> URI Class Initialized
DEBUG - 2011-05-21 15:05:23 --> Router Class Initialized
DEBUG - 2011-05-21 15:05:23 --> No URI present. Default controller set.
DEBUG - 2011-05-21 15:05:23 --> Output Class Initialized
DEBUG - 2011-05-21 15:05:23 --> Input Class Initialized
DEBUG - 2011-05-21 15:05:23 --> Global POST and COOKIE data sanitized
DEBUG - 2011-05-21 15:05:23 --> Language Class Initialized
DEBUG - 2011-05-21 15:05:24 --> Loader Class Initialized
DEBUG - 2011-05-21 15:05:24 --> Controller Class Initialized
DEBUG - 2011-05-21 15:05:24 --> File loaded: application/views/splash/main.php
DEBUG - 2011-05-21 15:05:24 --> Helper loaded: url_helper
DEBUG - 2011-05-21 15:05:24 --> File loaded: application/views/common/header.php
DEBUG - 2011-05-21 15:05:24 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-05-21 15:05:24 --> File loaded: application/views/common/footer.php
DEBUG - 2011-05-21 15:05:24 --> File loaded: application/views/layout/main.php
DEBUG - 2011-05-21 15:05:24 --> Final output sent to browser
DEBUG - 2011-05-21 15:05:24 --> Total execution time: 2.0361
DEBUG - 2011-05-21 15:05:25 --> Config Class Initialized
DEBUG - 2011-05-21 15:05:25 --> Hooks Class Initialized
DEBUG - 2011-05-21 15:05:25 --> Utf8 Class Initialized
DEBUG - 2011-05-21 15:05:25 --> UTF-8 Support Enabled
DEBUG - 2011-05-21 15:05:25 --> URI Class Initialized
DEBUG - 2011-05-21 15:05:25 --> Router Class Initialized
ERROR - 2011-05-21 15:05:25 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-05-21 15:05:26 --> Config Class Initialized
DEBUG - 2011-05-21 15:05:26 --> Hooks Class Initialized
DEBUG - 2011-05-21 15:05:26 --> Utf8 Class Initialized
DEBUG - 2011-05-21 15:05:26 --> UTF-8 Support Enabled
DEBUG - 2011-05-21 15:05:26 --> URI Class Initialized
DEBUG - 2011-05-21 15:05:26 --> Router Class Initialized
ERROR - 2011-05-21 15:05:26 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-05-21 15:05:26 --> Config Class Initialized
DEBUG - 2011-05-21 15:05:26 --> Hooks Class Initialized
DEBUG - 2011-05-21 15:05:26 --> Utf8 Class Initialized
DEBUG - 2011-05-21 15:05:26 --> UTF-8 Support Enabled
DEBUG - 2011-05-21 15:05:26 --> URI Class Initialized
DEBUG - 2011-05-21 15:05:26 --> Router Class Initialized
ERROR - 2011-05-21 15:05:26 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-05-21 15:05:26 --> Config Class Initialized
DEBUG - 2011-05-21 15:05:26 --> Hooks Class Initialized
DEBUG - 2011-05-21 15:05:26 --> Utf8 Class Initialized
DEBUG - 2011-05-21 15:05:26 --> UTF-8 Support Enabled
DEBUG - 2011-05-21 15:05:26 --> URI Class Initialized
DEBUG - 2011-05-21 15:05:26 --> Router Class Initialized
DEBUG - 2011-05-21 15:05:26 --> Output Class Initialized
DEBUG - 2011-05-21 15:05:26 --> Input Class Initialized
DEBUG - 2011-05-21 15:05:26 --> Global POST and COOKIE data sanitized
DEBUG - 2011-05-21 15:05:26 --> Language Class Initialized
DEBUG - 2011-05-21 15:05:26 --> Loader Class Initialized
DEBUG - 2011-05-21 15:05:26 --> Controller Class Initialized
DEBUG - 2011-05-21 15:05:26 --> Model Class Initialized
DEBUG - 2011-05-21 15:05:26 --> Model Class Initialized
DEBUG - 2011-05-21 15:05:26 --> Model Class Initialized
DEBUG - 2011-05-21 15:05:26 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-05-21 15:05:26 --> Database Driver Class Initialized
DEBUG - 2011-05-21 15:05:27 --> File loaded: application/views/table/main.php
DEBUG - 2011-05-21 15:05:27 --> Helper loaded: url_helper
DEBUG - 2011-05-21 15:05:27 --> File loaded: application/views/common/header.php
DEBUG - 2011-05-21 15:05:27 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-05-21 15:05:27 --> File loaded: application/views/common/footer.php
DEBUG - 2011-05-21 15:05:27 --> File loaded: application/views/layout/main.php
DEBUG - 2011-05-21 15:05:27 --> Final output sent to browser
DEBUG - 2011-05-21 15:05:27 --> Total execution time: 0.5613
DEBUG - 2011-05-21 15:05:37 --> Config Class Initialized
DEBUG - 2011-05-21 15:05:37 --> Hooks Class Initialized
DEBUG - 2011-05-21 15:05:37 --> Utf8 Class Initialized
DEBUG - 2011-05-21 15:05:37 --> UTF-8 Support Enabled
DEBUG - 2011-05-21 15:05:37 --> URI Class Initialized
DEBUG - 2011-05-21 15:05:37 --> Router Class Initialized
DEBUG - 2011-05-21 15:05:37 --> Output Class Initialized
DEBUG - 2011-05-21 15:05:37 --> Input Class Initialized
DEBUG - 2011-05-21 15:05:37 --> Global POST and COOKIE data sanitized
DEBUG - 2011-05-21 15:05:37 --> Language Class Initialized
DEBUG - 2011-05-21 15:05:37 --> Loader Class Initialized
DEBUG - 2011-05-21 15:05:37 --> Controller Class Initialized
DEBUG - 2011-05-21 15:05:37 --> Model Class Initialized
DEBUG - 2011-05-21 15:05:37 --> Model Class Initialized
DEBUG - 2011-05-21 15:05:37 --> Model Class Initialized
DEBUG - 2011-05-21 15:05:37 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-05-21 15:05:37 --> Database Driver Class Initialized
DEBUG - 2011-05-21 15:05:37 --> File loaded: application/views/table/main.php
DEBUG - 2011-05-21 15:05:37 --> Helper loaded: url_helper
DEBUG - 2011-05-21 15:05:37 --> File loaded: application/views/common/header.php
DEBUG - 2011-05-21 15:05:37 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-05-21 15:05:37 --> File loaded: application/views/common/footer.php
DEBUG - 2011-05-21 15:05:37 --> File loaded: application/views/layout/main.php
DEBUG - 2011-05-21 15:05:37 --> Final output sent to browser
DEBUG - 2011-05-21 15:05:37 --> Total execution time: 0.0446
DEBUG - 2011-05-21 15:05:38 --> Config Class Initialized
DEBUG - 2011-05-21 15:05:38 --> Hooks Class Initialized
DEBUG - 2011-05-21 15:05:38 --> Utf8 Class Initialized
DEBUG - 2011-05-21 15:05:38 --> UTF-8 Support Enabled
DEBUG - 2011-05-21 15:05:38 --> URI Class Initialized
DEBUG - 2011-05-21 15:05:38 --> Router Class Initialized
DEBUG - 2011-05-21 15:05:38 --> Output Class Initialized
DEBUG - 2011-05-21 15:05:38 --> Input Class Initialized
DEBUG - 2011-05-21 15:05:38 --> Global POST and COOKIE data sanitized
DEBUG - 2011-05-21 15:05:38 --> Language Class Initialized
DEBUG - 2011-05-21 15:05:38 --> Loader Class Initialized
DEBUG - 2011-05-21 15:05:38 --> Controller Class Initialized
DEBUG - 2011-05-21 15:05:38 --> Model Class Initialized
DEBUG - 2011-05-21 15:05:38 --> Model Class Initialized
DEBUG - 2011-05-21 15:05:38 --> Model Class Initialized
DEBUG - 2011-05-21 15:05:38 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-05-21 15:05:38 --> Database Driver Class Initialized
DEBUG - 2011-05-21 15:05:38 --> File loaded: application/views/table/main.php
DEBUG - 2011-05-21 15:05:38 --> Helper loaded: url_helper
DEBUG - 2011-05-21 15:05:38 --> File loaded: application/views/common/header.php
DEBUG - 2011-05-21 15:05:38 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-05-21 15:05:38 --> File loaded: application/views/common/footer.php
DEBUG - 2011-05-21 15:05:38 --> File loaded: application/views/layout/main.php
DEBUG - 2011-05-21 15:05:38 --> Final output sent to browser
DEBUG - 2011-05-21 15:05:38 --> Total execution time: 0.0429
DEBUG - 2011-05-21 15:05:53 --> Config Class Initialized
DEBUG - 2011-05-21 15:05:53 --> Hooks Class Initialized
DEBUG - 2011-05-21 15:05:53 --> Utf8 Class Initialized
DEBUG - 2011-05-21 15:05:53 --> UTF-8 Support Enabled
DEBUG - 2011-05-21 15:05:53 --> URI Class Initialized
DEBUG - 2011-05-21 15:05:53 --> Router Class Initialized
DEBUG - 2011-05-21 15:05:53 --> Output Class Initialized
DEBUG - 2011-05-21 15:05:53 --> Input Class Initialized
DEBUG - 2011-05-21 15:05:53 --> Global POST and COOKIE data sanitized
DEBUG - 2011-05-21 15:05:53 --> Language Class Initialized
DEBUG - 2011-05-21 15:05:53 --> Loader Class Initialized
DEBUG - 2011-05-21 15:05:53 --> Controller Class Initialized
DEBUG - 2011-05-21 15:05:53 --> Model Class Initialized
DEBUG - 2011-05-21 15:05:53 --> Model Class Initialized
DEBUG - 2011-05-21 15:05:53 --> Model Class Initialized
DEBUG - 2011-05-21 15:05:53 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-05-21 15:05:53 --> Database Driver Class Initialized
DEBUG - 2011-05-21 15:05:53 --> File loaded: application/views/table/main.php
DEBUG - 2011-05-21 15:05:53 --> Helper loaded: url_helper
DEBUG - 2011-05-21 15:05:53 --> File loaded: application/views/common/header.php
DEBUG - 2011-05-21 15:05:53 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-05-21 15:05:53 --> File loaded: application/views/common/footer.php
DEBUG - 2011-05-21 15:05:53 --> File loaded: application/views/layout/main.php
DEBUG - 2011-05-21 15:05:53 --> Final output sent to browser
DEBUG - 2011-05-21 15:05:53 --> Total execution time: 0.4027
DEBUG - 2011-05-21 15:05:56 --> Config Class Initialized
DEBUG - 2011-05-21 15:05:56 --> Hooks Class Initialized
DEBUG - 2011-05-21 15:05:56 --> Utf8 Class Initialized
DEBUG - 2011-05-21 15:05:56 --> UTF-8 Support Enabled
DEBUG - 2011-05-21 15:05:56 --> URI Class Initialized
DEBUG - 2011-05-21 15:05:56 --> Router Class Initialized
DEBUG - 2011-05-21 15:05:56 --> Output Class Initialized
DEBUG - 2011-05-21 15:05:56 --> Input Class Initialized
DEBUG - 2011-05-21 15:05:56 --> Global POST and COOKIE data sanitized
DEBUG - 2011-05-21 15:05:56 --> Language Class Initialized
DEBUG - 2011-05-21 15:05:56 --> Loader Class Initialized
DEBUG - 2011-05-21 15:05:56 --> Controller Class Initialized
DEBUG - 2011-05-21 15:05:56 --> Model Class Initialized
DEBUG - 2011-05-21 15:05:56 --> Model Class Initialized
DEBUG - 2011-05-21 15:05:56 --> Model Class Initialized
DEBUG - 2011-05-21 15:05:56 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-05-21 15:05:56 --> Database Driver Class Initialized
DEBUG - 2011-05-21 15:05:56 --> File loaded: application/views/table/main.php
DEBUG - 2011-05-21 15:05:56 --> Helper loaded: url_helper
DEBUG - 2011-05-21 15:05:56 --> File loaded: application/views/common/header.php
DEBUG - 2011-05-21 15:05:56 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-05-21 15:05:56 --> File loaded: application/views/common/footer.php
DEBUG - 2011-05-21 15:05:56 --> File loaded: application/views/layout/main.php
DEBUG - 2011-05-21 15:05:56 --> Final output sent to browser
DEBUG - 2011-05-21 15:05:56 --> Total execution time: 0.0469
DEBUG - 2011-05-21 15:06:08 --> Config Class Initialized
DEBUG - 2011-05-21 15:06:08 --> Hooks Class Initialized
DEBUG - 2011-05-21 15:06:08 --> Utf8 Class Initialized
DEBUG - 2011-05-21 15:06:08 --> UTF-8 Support Enabled
DEBUG - 2011-05-21 15:06:08 --> URI Class Initialized
DEBUG - 2011-05-21 15:06:08 --> Router Class Initialized
DEBUG - 2011-05-21 15:06:08 --> Output Class Initialized
DEBUG - 2011-05-21 15:06:08 --> Input Class Initialized
DEBUG - 2011-05-21 15:06:08 --> Global POST and COOKIE data sanitized
DEBUG - 2011-05-21 15:06:08 --> Language Class Initialized
DEBUG - 2011-05-21 15:06:08 --> Loader Class Initialized
DEBUG - 2011-05-21 15:06:08 --> Controller Class Initialized
DEBUG - 2011-05-21 15:06:08 --> Model Class Initialized
DEBUG - 2011-05-21 15:06:08 --> Model Class Initialized
DEBUG - 2011-05-21 15:06:08 --> Model Class Initialized
DEBUG - 2011-05-21 15:06:08 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-05-21 15:06:08 --> Database Driver Class Initialized
DEBUG - 2011-05-21 15:06:08 --> File loaded: application/views/table/main.php
DEBUG - 2011-05-21 15:06:08 --> Helper loaded: url_helper
DEBUG - 2011-05-21 15:06:08 --> File loaded: application/views/common/header.php
DEBUG - 2011-05-21 15:06:08 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-05-21 15:06:08 --> File loaded: application/views/common/footer.php
DEBUG - 2011-05-21 15:06:08 --> File loaded: application/views/layout/main.php
DEBUG - 2011-05-21 15:06:08 --> Final output sent to browser
DEBUG - 2011-05-21 15:06:08 --> Total execution time: 0.0768
DEBUG - 2011-05-21 15:06:20 --> Config Class Initialized
DEBUG - 2011-05-21 15:06:20 --> Hooks Class Initialized
DEBUG - 2011-05-21 15:06:20 --> Utf8 Class Initialized
DEBUG - 2011-05-21 15:06:20 --> UTF-8 Support Enabled
DEBUG - 2011-05-21 15:06:20 --> URI Class Initialized
DEBUG - 2011-05-21 15:06:20 --> Router Class Initialized
DEBUG - 2011-05-21 15:06:20 --> Output Class Initialized
DEBUG - 2011-05-21 15:06:20 --> Input Class Initialized
DEBUG - 2011-05-21 15:06:20 --> Global POST and COOKIE data sanitized
DEBUG - 2011-05-21 15:06:20 --> Language Class Initialized
DEBUG - 2011-05-21 15:06:20 --> Loader Class Initialized
DEBUG - 2011-05-21 15:06:20 --> Controller Class Initialized
DEBUG - 2011-05-21 15:06:20 --> Model Class Initialized
DEBUG - 2011-05-21 15:06:20 --> Model Class Initialized
DEBUG - 2011-05-21 15:06:20 --> Model Class Initialized
DEBUG - 2011-05-21 15:06:20 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-05-21 15:06:20 --> Database Driver Class Initialized
DEBUG - 2011-05-21 15:06:22 --> File loaded: application/views/table/main.php
DEBUG - 2011-05-21 15:06:22 --> Helper loaded: url_helper
DEBUG - 2011-05-21 15:06:22 --> File loaded: application/views/common/header.php
DEBUG - 2011-05-21 15:06:22 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-05-21 15:06:22 --> File loaded: application/views/common/footer.php
DEBUG - 2011-05-21 15:06:22 --> File loaded: application/views/layout/main.php
DEBUG - 2011-05-21 15:06:22 --> Final output sent to browser
DEBUG - 2011-05-21 15:06:22 --> Total execution time: 1.9334
DEBUG - 2011-05-21 15:06:23 --> Config Class Initialized
DEBUG - 2011-05-21 15:06:23 --> Hooks Class Initialized
DEBUG - 2011-05-21 15:06:23 --> Utf8 Class Initialized
DEBUG - 2011-05-21 15:06:23 --> UTF-8 Support Enabled
DEBUG - 2011-05-21 15:06:23 --> URI Class Initialized
DEBUG - 2011-05-21 15:06:23 --> Router Class Initialized
DEBUG - 2011-05-21 15:06:23 --> Output Class Initialized
DEBUG - 2011-05-21 15:06:23 --> Input Class Initialized
DEBUG - 2011-05-21 15:06:23 --> Global POST and COOKIE data sanitized
DEBUG - 2011-05-21 15:06:23 --> Language Class Initialized
DEBUG - 2011-05-21 15:06:23 --> Loader Class Initialized
DEBUG - 2011-05-21 15:06:23 --> Controller Class Initialized
DEBUG - 2011-05-21 15:06:23 --> Model Class Initialized
DEBUG - 2011-05-21 15:06:23 --> Model Class Initialized
DEBUG - 2011-05-21 15:06:23 --> Model Class Initialized
DEBUG - 2011-05-21 15:06:23 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-05-21 15:06:23 --> Database Driver Class Initialized
DEBUG - 2011-05-21 15:06:23 --> File loaded: application/views/table/main.php
DEBUG - 2011-05-21 15:06:23 --> Helper loaded: url_helper
DEBUG - 2011-05-21 15:06:23 --> File loaded: application/views/common/header.php
DEBUG - 2011-05-21 15:06:23 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-05-21 15:06:23 --> File loaded: application/views/common/footer.php
DEBUG - 2011-05-21 15:06:23 --> File loaded: application/views/layout/main.php
DEBUG - 2011-05-21 15:06:23 --> Final output sent to browser
DEBUG - 2011-05-21 15:06:23 --> Total execution time: 0.0453
DEBUG - 2011-05-21 15:06:23 --> Config Class Initialized
DEBUG - 2011-05-21 15:06:23 --> Hooks Class Initialized
DEBUG - 2011-05-21 15:06:23 --> Utf8 Class Initialized
DEBUG - 2011-05-21 15:06:23 --> UTF-8 Support Enabled
DEBUG - 2011-05-21 15:06:23 --> URI Class Initialized
DEBUG - 2011-05-21 15:06:23 --> Router Class Initialized
DEBUG - 2011-05-21 15:06:23 --> Output Class Initialized
DEBUG - 2011-05-21 15:06:23 --> Input Class Initialized
DEBUG - 2011-05-21 15:06:23 --> Global POST and COOKIE data sanitized
DEBUG - 2011-05-21 15:06:23 --> Language Class Initialized
DEBUG - 2011-05-21 15:06:23 --> Loader Class Initialized
DEBUG - 2011-05-21 15:06:23 --> Controller Class Initialized
DEBUG - 2011-05-21 15:06:23 --> Model Class Initialized
DEBUG - 2011-05-21 15:06:23 --> Model Class Initialized
DEBUG - 2011-05-21 15:06:23 --> Model Class Initialized
DEBUG - 2011-05-21 15:06:23 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-05-21 15:06:23 --> Database Driver Class Initialized
DEBUG - 2011-05-21 15:06:23 --> File loaded: application/views/table/main.php
DEBUG - 2011-05-21 15:06:23 --> Helper loaded: url_helper
DEBUG - 2011-05-21 15:06:23 --> File loaded: application/views/common/header.php
DEBUG - 2011-05-21 15:06:23 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-05-21 15:06:23 --> File loaded: application/views/common/footer.php
DEBUG - 2011-05-21 15:06:23 --> File loaded: application/views/layout/main.php
DEBUG - 2011-05-21 15:06:23 --> Final output sent to browser
DEBUG - 2011-05-21 15:06:23 --> Total execution time: 0.0500
DEBUG - 2011-05-21 15:06:31 --> Config Class Initialized
DEBUG - 2011-05-21 15:06:31 --> Hooks Class Initialized
DEBUG - 2011-05-21 15:06:31 --> Utf8 Class Initialized
DEBUG - 2011-05-21 15:06:31 --> UTF-8 Support Enabled
DEBUG - 2011-05-21 15:06:31 --> URI Class Initialized
DEBUG - 2011-05-21 15:06:31 --> Router Class Initialized
DEBUG - 2011-05-21 15:06:31 --> Output Class Initialized
DEBUG - 2011-05-21 15:06:31 --> Input Class Initialized
DEBUG - 2011-05-21 15:06:31 --> Global POST and COOKIE data sanitized
DEBUG - 2011-05-21 15:06:31 --> Language Class Initialized
DEBUG - 2011-05-21 15:06:31 --> Loader Class Initialized
DEBUG - 2011-05-21 15:06:31 --> Controller Class Initialized
DEBUG - 2011-05-21 15:06:31 --> Model Class Initialized
DEBUG - 2011-05-21 15:06:31 --> Model Class Initialized
DEBUG - 2011-05-21 15:06:31 --> Model Class Initialized
DEBUG - 2011-05-21 15:06:31 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-05-21 15:06:31 --> Database Driver Class Initialized
DEBUG - 2011-05-21 15:06:33 --> File loaded: application/views/table/main.php
DEBUG - 2011-05-21 15:06:33 --> Helper loaded: url_helper
DEBUG - 2011-05-21 15:06:33 --> File loaded: application/views/common/header.php
DEBUG - 2011-05-21 15:06:33 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-05-21 15:06:33 --> File loaded: application/views/common/footer.php
DEBUG - 2011-05-21 15:06:33 --> File loaded: application/views/layout/main.php
DEBUG - 2011-05-21 15:06:33 --> Final output sent to browser
DEBUG - 2011-05-21 15:06:33 --> Total execution time: 1.4323
DEBUG - 2011-05-21 15:06:39 --> Config Class Initialized
DEBUG - 2011-05-21 15:06:39 --> Hooks Class Initialized
DEBUG - 2011-05-21 15:06:39 --> Utf8 Class Initialized
DEBUG - 2011-05-21 15:06:39 --> UTF-8 Support Enabled
DEBUG - 2011-05-21 15:06:39 --> URI Class Initialized
DEBUG - 2011-05-21 15:06:39 --> Router Class Initialized
DEBUG - 2011-05-21 15:06:39 --> Output Class Initialized
DEBUG - 2011-05-21 15:06:39 --> Input Class Initialized
DEBUG - 2011-05-21 15:06:39 --> Global POST and COOKIE data sanitized
DEBUG - 2011-05-21 15:06:39 --> Language Class Initialized
DEBUG - 2011-05-21 15:06:39 --> Loader Class Initialized
DEBUG - 2011-05-21 15:06:39 --> Controller Class Initialized
DEBUG - 2011-05-21 15:06:39 --> Model Class Initialized
DEBUG - 2011-05-21 15:06:39 --> Model Class Initialized
DEBUG - 2011-05-21 15:06:39 --> Model Class Initialized
DEBUG - 2011-05-21 15:06:39 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-05-21 15:06:39 --> Database Driver Class Initialized
DEBUG - 2011-05-21 15:06:39 --> File loaded: application/views/table/main.php
DEBUG - 2011-05-21 15:06:39 --> Helper loaded: url_helper
DEBUG - 2011-05-21 15:06:39 --> File loaded: application/views/common/header.php
DEBUG - 2011-05-21 15:06:39 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-05-21 15:06:39 --> File loaded: application/views/common/footer.php
DEBUG - 2011-05-21 15:06:39 --> File loaded: application/views/layout/main.php
DEBUG - 2011-05-21 15:06:39 --> Final output sent to browser
DEBUG - 2011-05-21 15:06:39 --> Total execution time: 0.0517
DEBUG - 2011-05-21 16:44:03 --> Config Class Initialized
DEBUG - 2011-05-21 16:44:03 --> Hooks Class Initialized
DEBUG - 2011-05-21 16:44:03 --> Utf8 Class Initialized
DEBUG - 2011-05-21 16:44:03 --> UTF-8 Support Enabled
DEBUG - 2011-05-21 16:44:03 --> URI Class Initialized
DEBUG - 2011-05-21 16:44:03 --> Router Class Initialized
DEBUG - 2011-05-21 16:44:03 --> Output Class Initialized
DEBUG - 2011-05-21 16:44:03 --> Input Class Initialized
DEBUG - 2011-05-21 16:44:03 --> Global POST and COOKIE data sanitized
DEBUG - 2011-05-21 16:44:03 --> Language Class Initialized
DEBUG - 2011-05-21 16:44:03 --> Loader Class Initialized
DEBUG - 2011-05-21 16:44:03 --> Controller Class Initialized
DEBUG - 2011-05-21 16:44:03 --> Model Class Initialized
DEBUG - 2011-05-21 16:44:03 --> Model Class Initialized
DEBUG - 2011-05-21 16:44:03 --> Model Class Initialized
DEBUG - 2011-05-21 16:44:03 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-05-21 16:44:03 --> Database Driver Class Initialized
DEBUG - 2011-05-21 16:44:04 --> File loaded: application/views/table/main.php
DEBUG - 2011-05-21 16:44:04 --> Helper loaded: url_helper
DEBUG - 2011-05-21 16:44:04 --> File loaded: application/views/common/header.php
DEBUG - 2011-05-21 16:44:04 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-05-21 16:44:04 --> File loaded: application/views/common/footer.php
DEBUG - 2011-05-21 16:44:04 --> File loaded: application/views/layout/main.php
DEBUG - 2011-05-21 16:44:04 --> Final output sent to browser
DEBUG - 2011-05-21 16:44:04 --> Total execution time: 0.5925
DEBUG - 2011-05-21 16:44:05 --> Config Class Initialized
DEBUG - 2011-05-21 16:44:05 --> Hooks Class Initialized
DEBUG - 2011-05-21 16:44:05 --> Utf8 Class Initialized
DEBUG - 2011-05-21 16:44:05 --> UTF-8 Support Enabled
DEBUG - 2011-05-21 16:44:05 --> URI Class Initialized
DEBUG - 2011-05-21 16:44:05 --> Router Class Initialized
DEBUG - 2011-05-21 16:44:05 --> Output Class Initialized
DEBUG - 2011-05-21 16:44:05 --> Input Class Initialized
DEBUG - 2011-05-21 16:44:05 --> Global POST and COOKIE data sanitized
DEBUG - 2011-05-21 16:44:05 --> Language Class Initialized
DEBUG - 2011-05-21 16:44:05 --> Loader Class Initialized
DEBUG - 2011-05-21 16:44:05 --> Controller Class Initialized
ERROR - 2011-05-21 16:44:05 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-05-21 16:44:05 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-05-21 16:44:05 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-05-21 16:44:05 --> Model Class Initialized
DEBUG - 2011-05-21 16:44:05 --> Model Class Initialized
DEBUG - 2011-05-21 16:44:05 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-05-21 16:44:05 --> Database Driver Class Initialized
DEBUG - 2011-05-21 16:44:05 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-05-21 16:44:05 --> Helper loaded: url_helper
DEBUG - 2011-05-21 16:44:05 --> File loaded: application/views/common/header.php
DEBUG - 2011-05-21 16:44:05 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-05-21 16:44:05 --> File loaded: application/views/common/footer.php
DEBUG - 2011-05-21 16:44:05 --> File loaded: application/views/layout/main.php
DEBUG - 2011-05-21 16:44:05 --> Final output sent to browser
DEBUG - 2011-05-21 16:44:05 --> Total execution time: 0.0985
DEBUG - 2011-05-21 17:04:24 --> Config Class Initialized
DEBUG - 2011-05-21 17:04:24 --> Hooks Class Initialized
DEBUG - 2011-05-21 17:04:24 --> Utf8 Class Initialized
DEBUG - 2011-05-21 17:04:24 --> UTF-8 Support Enabled
DEBUG - 2011-05-21 17:04:24 --> URI Class Initialized
DEBUG - 2011-05-21 17:04:24 --> Router Class Initialized
DEBUG - 2011-05-21 17:04:24 --> Output Class Initialized
DEBUG - 2011-05-21 17:04:24 --> Input Class Initialized
DEBUG - 2011-05-21 17:04:24 --> Global POST and COOKIE data sanitized
DEBUG - 2011-05-21 17:04:24 --> Language Class Initialized
DEBUG - 2011-05-21 17:04:24 --> Loader Class Initialized
DEBUG - 2011-05-21 17:04:24 --> Controller Class Initialized
DEBUG - 2011-05-21 17:04:24 --> Model Class Initialized
DEBUG - 2011-05-21 17:04:24 --> Model Class Initialized
DEBUG - 2011-05-21 17:04:24 --> Model Class Initialized
DEBUG - 2011-05-21 17:04:24 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-05-21 17:04:24 --> Database Driver Class Initialized
DEBUG - 2011-05-21 17:04:24 --> File loaded: application/views/table/main.php
DEBUG - 2011-05-21 17:04:24 --> Helper loaded: url_helper
DEBUG - 2011-05-21 17:04:24 --> File loaded: application/views/common/header.php
DEBUG - 2011-05-21 17:04:24 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-05-21 17:04:24 --> File loaded: application/views/common/footer.php
DEBUG - 2011-05-21 17:04:24 --> File loaded: application/views/layout/main.php
DEBUG - 2011-05-21 17:04:24 --> Final output sent to browser
DEBUG - 2011-05-21 17:04:24 --> Total execution time: 0.2684
DEBUG - 2011-05-21 17:04:53 --> Config Class Initialized
DEBUG - 2011-05-21 17:04:53 --> Hooks Class Initialized
DEBUG - 2011-05-21 17:04:53 --> Utf8 Class Initialized
DEBUG - 2011-05-21 17:04:53 --> UTF-8 Support Enabled
DEBUG - 2011-05-21 17:04:53 --> URI Class Initialized
DEBUG - 2011-05-21 17:04:53 --> Router Class Initialized
DEBUG - 2011-05-21 17:04:53 --> Output Class Initialized
DEBUG - 2011-05-21 17:04:53 --> Input Class Initialized
DEBUG - 2011-05-21 17:04:53 --> Global POST and COOKIE data sanitized
DEBUG - 2011-05-21 17:04:53 --> Language Class Initialized
DEBUG - 2011-05-21 17:04:53 --> Loader Class Initialized
DEBUG - 2011-05-21 17:04:53 --> Controller Class Initialized
ERROR - 2011-05-21 17:04:53 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-05-21 17:04:53 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-05-21 17:04:53 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-05-21 17:04:53 --> Model Class Initialized
DEBUG - 2011-05-21 17:04:53 --> Model Class Initialized
DEBUG - 2011-05-21 17:04:53 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-05-21 17:04:53 --> Database Driver Class Initialized
DEBUG - 2011-05-21 17:04:53 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-05-21 17:04:54 --> Helper loaded: url_helper
DEBUG - 2011-05-21 17:04:54 --> File loaded: application/views/common/header.php
DEBUG - 2011-05-21 17:04:54 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-05-21 17:04:54 --> File loaded: application/views/common/footer.php
DEBUG - 2011-05-21 17:04:54 --> File loaded: application/views/layout/main.php
DEBUG - 2011-05-21 17:04:54 --> Final output sent to browser
DEBUG - 2011-05-21 17:04:54 --> Total execution time: 0.0567
DEBUG - 2011-05-21 17:36:51 --> Config Class Initialized
DEBUG - 2011-05-21 17:36:51 --> Hooks Class Initialized
DEBUG - 2011-05-21 17:36:51 --> Utf8 Class Initialized
DEBUG - 2011-05-21 17:36:51 --> UTF-8 Support Enabled
DEBUG - 2011-05-21 17:36:51 --> URI Class Initialized
DEBUG - 2011-05-21 17:36:51 --> Router Class Initialized
ERROR - 2011-05-21 17:36:51 --> 404 Page Not Found --> robots.txt
DEBUG - 2011-05-21 17:36:52 --> Config Class Initialized
DEBUG - 2011-05-21 17:36:52 --> Hooks Class Initialized
DEBUG - 2011-05-21 17:36:52 --> Utf8 Class Initialized
DEBUG - 2011-05-21 17:36:52 --> UTF-8 Support Enabled
DEBUG - 2011-05-21 17:36:52 --> URI Class Initialized
DEBUG - 2011-05-21 17:36:52 --> Router Class Initialized
DEBUG - 2011-05-21 17:36:52 --> Output Class Initialized
DEBUG - 2011-05-21 17:36:52 --> Input Class Initialized
DEBUG - 2011-05-21 17:36:52 --> Global POST and COOKIE data sanitized
DEBUG - 2011-05-21 17:36:52 --> Language Class Initialized
DEBUG - 2011-05-21 17:36:52 --> Loader Class Initialized
DEBUG - 2011-05-21 17:36:52 --> Controller Class Initialized
ERROR - 2011-05-21 17:36:52 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-05-21 17:36:52 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-05-21 17:36:52 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-05-21 17:36:52 --> Model Class Initialized
DEBUG - 2011-05-21 17:36:52 --> Model Class Initialized
DEBUG - 2011-05-21 17:36:52 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-05-21 17:36:52 --> Database Driver Class Initialized
DEBUG - 2011-05-21 17:36:52 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-05-21 17:36:52 --> Helper loaded: url_helper
DEBUG - 2011-05-21 17:36:52 --> File loaded: application/views/common/header.php
DEBUG - 2011-05-21 17:36:52 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-05-21 17:36:52 --> File loaded: application/views/common/footer.php
DEBUG - 2011-05-21 17:36:52 --> File loaded: application/views/layout/main.php
DEBUG - 2011-05-21 17:36:52 --> Final output sent to browser
DEBUG - 2011-05-21 17:36:52 --> Total execution time: 0.3094
DEBUG - 2011-05-21 17:36:55 --> Config Class Initialized
DEBUG - 2011-05-21 17:36:55 --> Hooks Class Initialized
DEBUG - 2011-05-21 17:36:55 --> Utf8 Class Initialized
DEBUG - 2011-05-21 17:36:55 --> UTF-8 Support Enabled
DEBUG - 2011-05-21 17:36:55 --> URI Class Initialized
DEBUG - 2011-05-21 17:36:55 --> Router Class Initialized
DEBUG - 2011-05-21 17:36:55 --> Output Class Initialized
DEBUG - 2011-05-21 17:36:55 --> Input Class Initialized
DEBUG - 2011-05-21 17:36:55 --> Global POST and COOKIE data sanitized
DEBUG - 2011-05-21 17:36:55 --> Language Class Initialized
DEBUG - 2011-05-21 17:36:55 --> Loader Class Initialized
DEBUG - 2011-05-21 17:36:55 --> Controller Class Initialized
DEBUG - 2011-05-21 17:36:55 --> Model Class Initialized
DEBUG - 2011-05-21 17:36:55 --> Model Class Initialized
DEBUG - 2011-05-21 17:36:55 --> Model Class Initialized
DEBUG - 2011-05-21 17:36:55 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-05-21 17:36:55 --> Database Driver Class Initialized
DEBUG - 2011-05-21 17:36:55 --> File loaded: application/views/table/main.php
DEBUG - 2011-05-21 17:36:55 --> Helper loaded: url_helper
DEBUG - 2011-05-21 17:36:55 --> File loaded: application/views/common/header.php
DEBUG - 2011-05-21 17:36:55 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-05-21 17:36:55 --> File loaded: application/views/common/footer.php
DEBUG - 2011-05-21 17:36:55 --> File loaded: application/views/layout/main.php
DEBUG - 2011-05-21 17:36:55 --> Final output sent to browser
DEBUG - 2011-05-21 17:36:55 --> Total execution time: 0.4065
DEBUG - 2011-05-21 19:14:03 --> Config Class Initialized
DEBUG - 2011-05-21 19:14:03 --> Hooks Class Initialized
DEBUG - 2011-05-21 19:14:03 --> Utf8 Class Initialized
DEBUG - 2011-05-21 19:14:03 --> UTF-8 Support Enabled
DEBUG - 2011-05-21 19:14:03 --> URI Class Initialized
DEBUG - 2011-05-21 19:14:03 --> Router Class Initialized
DEBUG - 2011-05-21 19:14:03 --> No URI present. Default controller set.
DEBUG - 2011-05-21 19:14:03 --> Output Class Initialized
DEBUG - 2011-05-21 19:14:03 --> Input Class Initialized
DEBUG - 2011-05-21 19:14:03 --> Global POST and COOKIE data sanitized
DEBUG - 2011-05-21 19:14:03 --> Language Class Initialized
DEBUG - 2011-05-21 19:14:03 --> Loader Class Initialized
DEBUG - 2011-05-21 19:14:03 --> Controller Class Initialized
DEBUG - 2011-05-21 19:14:03 --> File loaded: application/views/splash/main.php
DEBUG - 2011-05-21 19:14:03 --> Helper loaded: url_helper
DEBUG - 2011-05-21 19:14:03 --> File loaded: application/views/common/header.php
DEBUG - 2011-05-21 19:14:03 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-05-21 19:14:03 --> File loaded: application/views/common/footer.php
DEBUG - 2011-05-21 19:14:03 --> File loaded: application/views/layout/main.php
DEBUG - 2011-05-21 19:14:03 --> Final output sent to browser
DEBUG - 2011-05-21 19:14:03 --> Total execution time: 0.3564
DEBUG - 2011-05-21 19:59:16 --> Config Class Initialized
DEBUG - 2011-05-21 19:59:16 --> Hooks Class Initialized
DEBUG - 2011-05-21 19:59:16 --> Utf8 Class Initialized
DEBUG - 2011-05-21 19:59:16 --> UTF-8 Support Enabled
DEBUG - 2011-05-21 19:59:16 --> URI Class Initialized
DEBUG - 2011-05-21 19:59:16 --> Router Class Initialized
ERROR - 2011-05-21 19:59:16 --> 404 Page Not Found --> robots.txt
DEBUG - 2011-05-21 19:59:16 --> Config Class Initialized
DEBUG - 2011-05-21 19:59:16 --> Hooks Class Initialized
DEBUG - 2011-05-21 19:59:16 --> Utf8 Class Initialized
DEBUG - 2011-05-21 19:59:16 --> UTF-8 Support Enabled
DEBUG - 2011-05-21 19:59:16 --> URI Class Initialized
DEBUG - 2011-05-21 19:59:16 --> Router Class Initialized
DEBUG - 2011-05-21 19:59:16 --> No URI present. Default controller set.
DEBUG - 2011-05-21 19:59:16 --> Output Class Initialized
DEBUG - 2011-05-21 19:59:16 --> Input Class Initialized
DEBUG - 2011-05-21 19:59:16 --> Global POST and COOKIE data sanitized
DEBUG - 2011-05-21 19:59:16 --> Language Class Initialized
DEBUG - 2011-05-21 19:59:17 --> Loader Class Initialized
DEBUG - 2011-05-21 19:59:17 --> Controller Class Initialized
DEBUG - 2011-05-21 19:59:17 --> File loaded: application/views/splash/main.php
DEBUG - 2011-05-21 19:59:17 --> Helper loaded: url_helper
DEBUG - 2011-05-21 19:59:17 --> File loaded: application/views/common/header.php
DEBUG - 2011-05-21 19:59:17 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-05-21 19:59:17 --> File loaded: application/views/common/footer.php
DEBUG - 2011-05-21 19:59:17 --> File loaded: application/views/layout/main.php
DEBUG - 2011-05-21 19:59:17 --> Final output sent to browser
DEBUG - 2011-05-21 19:59:17 --> Total execution time: 0.1463
DEBUG - 2011-05-21 20:13:08 --> Config Class Initialized
DEBUG - 2011-05-21 20:13:08 --> Hooks Class Initialized
DEBUG - 2011-05-21 20:13:08 --> Utf8 Class Initialized
DEBUG - 2011-05-21 20:13:08 --> UTF-8 Support Enabled
DEBUG - 2011-05-21 20:13:08 --> URI Class Initialized
DEBUG - 2011-05-21 20:13:08 --> Router Class Initialized
DEBUG - 2011-05-21 20:13:08 --> Output Class Initialized
DEBUG - 2011-05-21 20:13:08 --> Input Class Initialized
DEBUG - 2011-05-21 20:13:08 --> Global POST and COOKIE data sanitized
DEBUG - 2011-05-21 20:13:08 --> Language Class Initialized
DEBUG - 2011-05-21 20:13:08 --> Loader Class Initialized
DEBUG - 2011-05-21 20:13:08 --> Controller Class Initialized
DEBUG - 2011-05-21 20:13:08 --> Model Class Initialized
DEBUG - 2011-05-21 20:13:08 --> Model Class Initialized
DEBUG - 2011-05-21 20:13:08 --> Model Class Initialized
DEBUG - 2011-05-21 20:13:08 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-05-21 20:13:08 --> Database Driver Class Initialized
DEBUG - 2011-05-21 20:13:08 --> File loaded: application/views/table/main.php
DEBUG - 2011-05-21 20:13:09 --> Helper loaded: url_helper
DEBUG - 2011-05-21 20:13:09 --> File loaded: application/views/common/header.php
DEBUG - 2011-05-21 20:13:09 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-05-21 20:13:09 --> File loaded: application/views/common/footer.php
DEBUG - 2011-05-21 20:13:09 --> File loaded: application/views/layout/main.php
DEBUG - 2011-05-21 20:13:09 --> Final output sent to browser
DEBUG - 2011-05-21 20:13:09 --> Total execution time: 0.4991
DEBUG - 2011-05-21 20:13:09 --> Config Class Initialized
DEBUG - 2011-05-21 20:13:09 --> Hooks Class Initialized
DEBUG - 2011-05-21 20:13:09 --> Utf8 Class Initialized
DEBUG - 2011-05-21 20:13:09 --> UTF-8 Support Enabled
DEBUG - 2011-05-21 20:13:09 --> URI Class Initialized
DEBUG - 2011-05-21 20:13:09 --> Router Class Initialized
DEBUG - 2011-05-21 20:13:09 --> Output Class Initialized
DEBUG - 2011-05-21 20:13:09 --> Input Class Initialized
DEBUG - 2011-05-21 20:13:09 --> Global POST and COOKIE data sanitized
DEBUG - 2011-05-21 20:13:09 --> Language Class Initialized
DEBUG - 2011-05-21 20:13:09 --> Loader Class Initialized
DEBUG - 2011-05-21 20:13:09 --> Controller Class Initialized
ERROR - 2011-05-21 20:13:09 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-05-21 20:13:09 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-05-21 20:13:09 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-05-21 20:13:09 --> Model Class Initialized
DEBUG - 2011-05-21 20:13:09 --> Model Class Initialized
DEBUG - 2011-05-21 20:13:09 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-05-21 20:13:09 --> Database Driver Class Initialized
DEBUG - 2011-05-21 20:13:09 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-05-21 20:13:09 --> Helper loaded: url_helper
DEBUG - 2011-05-21 20:13:09 --> File loaded: application/views/common/header.php
DEBUG - 2011-05-21 20:13:09 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-05-21 20:13:09 --> File loaded: application/views/common/footer.php
DEBUG - 2011-05-21 20:13:09 --> File loaded: application/views/layout/main.php
DEBUG - 2011-05-21 20:13:09 --> Final output sent to browser
DEBUG - 2011-05-21 20:13:09 --> Total execution time: 0.1224
DEBUG - 2011-05-21 20:13:22 --> Config Class Initialized
DEBUG - 2011-05-21 20:13:22 --> Hooks Class Initialized
DEBUG - 2011-05-21 20:13:22 --> Utf8 Class Initialized
DEBUG - 2011-05-21 20:13:22 --> UTF-8 Support Enabled
DEBUG - 2011-05-21 20:13:22 --> URI Class Initialized
DEBUG - 2011-05-21 20:13:22 --> Router Class Initialized
DEBUG - 2011-05-21 20:13:22 --> Output Class Initialized
DEBUG - 2011-05-21 20:13:22 --> Input Class Initialized
DEBUG - 2011-05-21 20:13:22 --> Global POST and COOKIE data sanitized
DEBUG - 2011-05-21 20:13:22 --> Language Class Initialized
DEBUG - 2011-05-21 20:13:22 --> Loader Class Initialized
DEBUG - 2011-05-21 20:13:22 --> Controller Class Initialized
DEBUG - 2011-05-21 20:13:22 --> Model Class Initialized
DEBUG - 2011-05-21 20:13:22 --> Model Class Initialized
DEBUG - 2011-05-21 20:13:22 --> Model Class Initialized
DEBUG - 2011-05-21 20:13:22 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-05-21 20:13:22 --> Database Driver Class Initialized
DEBUG - 2011-05-21 20:13:22 --> File loaded: application/views/table/main.php
DEBUG - 2011-05-21 20:13:22 --> Helper loaded: url_helper
DEBUG - 2011-05-21 20:13:22 --> File loaded: application/views/common/header.php
DEBUG - 2011-05-21 20:13:22 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-05-21 20:13:22 --> File loaded: application/views/common/footer.php
DEBUG - 2011-05-21 20:13:22 --> File loaded: application/views/layout/main.php
DEBUG - 2011-05-21 20:13:22 --> Final output sent to browser
DEBUG - 2011-05-21 20:13:22 --> Total execution time: 0.0455
DEBUG - 2011-05-21 20:13:23 --> Config Class Initialized
DEBUG - 2011-05-21 20:13:23 --> Hooks Class Initialized
DEBUG - 2011-05-21 20:13:23 --> Utf8 Class Initialized
DEBUG - 2011-05-21 20:13:23 --> UTF-8 Support Enabled
DEBUG - 2011-05-21 20:13:23 --> URI Class Initialized
DEBUG - 2011-05-21 20:13:23 --> Router Class Initialized
DEBUG - 2011-05-21 20:13:23 --> Output Class Initialized
DEBUG - 2011-05-21 20:13:23 --> Input Class Initialized
DEBUG - 2011-05-21 20:13:23 --> Global POST and COOKIE data sanitized
DEBUG - 2011-05-21 20:13:23 --> Language Class Initialized
DEBUG - 2011-05-21 20:13:23 --> Loader Class Initialized
DEBUG - 2011-05-21 20:13:23 --> Controller Class Initialized
ERROR - 2011-05-21 20:13:23 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-05-21 20:13:23 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-05-21 20:13:23 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-05-21 20:13:23 --> Model Class Initialized
DEBUG - 2011-05-21 20:13:23 --> Model Class Initialized
DEBUG - 2011-05-21 20:13:23 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-05-21 20:13:23 --> Database Driver Class Initialized
DEBUG - 2011-05-21 20:13:23 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-05-21 20:13:23 --> Helper loaded: url_helper
DEBUG - 2011-05-21 20:13:23 --> File loaded: application/views/common/header.php
DEBUG - 2011-05-21 20:13:23 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-05-21 20:13:23 --> File loaded: application/views/common/footer.php
DEBUG - 2011-05-21 20:13:23 --> File loaded: application/views/layout/main.php
DEBUG - 2011-05-21 20:13:23 --> Final output sent to browser
DEBUG - 2011-05-21 20:13:23 --> Total execution time: 0.0277
DEBUG - 2011-05-21 22:20:23 --> Config Class Initialized
DEBUG - 2011-05-21 22:20:23 --> Hooks Class Initialized
DEBUG - 2011-05-21 22:20:23 --> Utf8 Class Initialized
DEBUG - 2011-05-21 22:20:23 --> UTF-8 Support Enabled
DEBUG - 2011-05-21 22:20:23 --> URI Class Initialized
DEBUG - 2011-05-21 22:20:23 --> Router Class Initialized
DEBUG - 2011-05-21 22:20:23 --> No URI present. Default controller set.
DEBUG - 2011-05-21 22:20:23 --> Output Class Initialized
DEBUG - 2011-05-21 22:20:23 --> Input Class Initialized
DEBUG - 2011-05-21 22:20:23 --> Global POST and COOKIE data sanitized
DEBUG - 2011-05-21 22:20:23 --> Language Class Initialized
DEBUG - 2011-05-21 22:20:23 --> Loader Class Initialized
DEBUG - 2011-05-21 22:20:23 --> Controller Class Initialized
DEBUG - 2011-05-21 22:20:23 --> File loaded: application/views/splash/main.php
DEBUG - 2011-05-21 22:20:23 --> Helper loaded: url_helper
DEBUG - 2011-05-21 22:20:23 --> File loaded: application/views/common/header.php
DEBUG - 2011-05-21 22:20:23 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-05-21 22:20:23 --> File loaded: application/views/common/footer.php
DEBUG - 2011-05-21 22:20:23 --> File loaded: application/views/layout/main.php
DEBUG - 2011-05-21 22:20:23 --> Final output sent to browser
DEBUG - 2011-05-21 22:20:23 --> Total execution time: 0.4422

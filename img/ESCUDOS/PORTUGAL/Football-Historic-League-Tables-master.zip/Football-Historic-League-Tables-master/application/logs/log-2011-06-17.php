<?php  if ( ! defined('BASEPATH')) exit('No direct script access allowed'); ?>

DEBUG - 2011-06-17 00:52:22 --> Config Class Initialized
DEBUG - 2011-06-17 00:52:22 --> Hooks Class Initialized
DEBUG - 2011-06-17 00:52:22 --> Utf8 Class Initialized
DEBUG - 2011-06-17 00:52:22 --> UTF-8 Support Enabled
DEBUG - 2011-06-17 00:52:22 --> URI Class Initialized
DEBUG - 2011-06-17 00:52:22 --> Router Class Initialized
DEBUG - 2011-06-17 00:52:22 --> Output Class Initialized
DEBUG - 2011-06-17 00:52:22 --> Input Class Initialized
DEBUG - 2011-06-17 00:52:22 --> Global POST and COOKIE data sanitized
DEBUG - 2011-06-17 00:52:22 --> Language Class Initialized
DEBUG - 2011-06-17 00:52:22 --> Loader Class Initialized
DEBUG - 2011-06-17 00:52:22 --> Controller Class Initialized
DEBUG - 2011-06-17 00:52:22 --> Model Class Initialized
DEBUG - 2011-06-17 00:52:22 --> Model Class Initialized
DEBUG - 2011-06-17 00:52:22 --> Model Class Initialized
DEBUG - 2011-06-17 00:52:22 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-06-17 00:52:22 --> Database Driver Class Initialized
DEBUG - 2011-06-17 00:52:23 --> File loaded: application/views/table/main.php
DEBUG - 2011-06-17 00:52:23 --> Helper loaded: url_helper
DEBUG - 2011-06-17 00:52:23 --> File loaded: application/views/common/header.php
DEBUG - 2011-06-17 00:52:23 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-06-17 00:52:23 --> File loaded: application/views/common/footer.php
DEBUG - 2011-06-17 00:52:23 --> File loaded: application/views/layout/main.php
DEBUG - 2011-06-17 00:52:23 --> Final output sent to browser
DEBUG - 2011-06-17 00:52:23 --> Total execution time: 0.8652
DEBUG - 2011-06-17 00:52:24 --> Config Class Initialized
DEBUG - 2011-06-17 00:52:24 --> Hooks Class Initialized
DEBUG - 2011-06-17 00:52:24 --> Utf8 Class Initialized
DEBUG - 2011-06-17 00:52:24 --> UTF-8 Support Enabled
DEBUG - 2011-06-17 00:52:24 --> URI Class Initialized
DEBUG - 2011-06-17 00:52:24 --> Router Class Initialized
DEBUG - 2011-06-17 00:52:24 --> Output Class Initialized
DEBUG - 2011-06-17 00:52:24 --> Input Class Initialized
DEBUG - 2011-06-17 00:52:24 --> Global POST and COOKIE data sanitized
DEBUG - 2011-06-17 00:52:24 --> Language Class Initialized
DEBUG - 2011-06-17 00:52:24 --> Loader Class Initialized
DEBUG - 2011-06-17 00:52:24 --> Controller Class Initialized
ERROR - 2011-06-17 00:52:24 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-06-17 00:52:24 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-06-17 00:52:24 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-06-17 00:52:24 --> Model Class Initialized
DEBUG - 2011-06-17 00:52:24 --> Model Class Initialized
DEBUG - 2011-06-17 00:52:24 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-06-17 00:52:24 --> Database Driver Class Initialized
DEBUG - 2011-06-17 00:52:24 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-06-17 00:52:24 --> Helper loaded: url_helper
DEBUG - 2011-06-17 00:52:24 --> File loaded: application/views/common/header.php
DEBUG - 2011-06-17 00:52:24 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-06-17 00:52:24 --> File loaded: application/views/common/footer.php
DEBUG - 2011-06-17 00:52:24 --> File loaded: application/views/layout/main.php
DEBUG - 2011-06-17 00:52:24 --> Final output sent to browser
DEBUG - 2011-06-17 00:52:24 --> Total execution time: 0.1359
DEBUG - 2011-06-17 02:18:08 --> Config Class Initialized
DEBUG - 2011-06-17 02:18:08 --> Hooks Class Initialized
DEBUG - 2011-06-17 02:18:08 --> Utf8 Class Initialized
DEBUG - 2011-06-17 02:18:08 --> UTF-8 Support Enabled
DEBUG - 2011-06-17 02:18:08 --> URI Class Initialized
DEBUG - 2011-06-17 02:18:08 --> Router Class Initialized
DEBUG - 2011-06-17 02:18:08 --> Output Class Initialized
DEBUG - 2011-06-17 02:18:08 --> Input Class Initialized
DEBUG - 2011-06-17 02:18:08 --> Global POST and COOKIE data sanitized
DEBUG - 2011-06-17 02:18:08 --> Language Class Initialized
DEBUG - 2011-06-17 02:18:08 --> Loader Class Initialized
DEBUG - 2011-06-17 02:18:08 --> Controller Class Initialized
DEBUG - 2011-06-17 02:18:09 --> Model Class Initialized
DEBUG - 2011-06-17 02:18:09 --> Model Class Initialized
DEBUG - 2011-06-17 02:18:09 --> Model Class Initialized
DEBUG - 2011-06-17 02:18:09 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-06-17 02:18:09 --> Database Driver Class Initialized
DEBUG - 2011-06-17 02:18:15 --> File loaded: application/views/table/main.php
DEBUG - 2011-06-17 02:18:15 --> Helper loaded: url_helper
DEBUG - 2011-06-17 02:18:15 --> File loaded: application/views/common/header.php
DEBUG - 2011-06-17 02:18:15 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-06-17 02:18:15 --> File loaded: application/views/common/footer.php
DEBUG - 2011-06-17 02:18:15 --> File loaded: application/views/layout/main.php
DEBUG - 2011-06-17 02:18:15 --> Final output sent to browser
DEBUG - 2011-06-17 02:18:15 --> Total execution time: 7.2988
DEBUG - 2011-06-17 02:18:16 --> Config Class Initialized
DEBUG - 2011-06-17 02:18:16 --> Hooks Class Initialized
DEBUG - 2011-06-17 02:18:16 --> Utf8 Class Initialized
DEBUG - 2011-06-17 02:18:16 --> UTF-8 Support Enabled
DEBUG - 2011-06-17 02:18:16 --> URI Class Initialized
DEBUG - 2011-06-17 02:18:16 --> Router Class Initialized
DEBUG - 2011-06-17 02:18:17 --> Output Class Initialized
DEBUG - 2011-06-17 02:18:17 --> Input Class Initialized
DEBUG - 2011-06-17 02:18:17 --> Global POST and COOKIE data sanitized
DEBUG - 2011-06-17 02:18:17 --> Language Class Initialized
DEBUG - 2011-06-17 02:18:17 --> Loader Class Initialized
DEBUG - 2011-06-17 02:18:17 --> Controller Class Initialized
ERROR - 2011-06-17 02:18:17 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-06-17 02:18:17 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-06-17 02:18:17 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-06-17 02:18:17 --> Model Class Initialized
DEBUG - 2011-06-17 02:18:17 --> Model Class Initialized
DEBUG - 2011-06-17 02:18:17 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-06-17 02:18:17 --> Database Driver Class Initialized
DEBUG - 2011-06-17 02:18:17 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-06-17 02:18:17 --> Helper loaded: url_helper
DEBUG - 2011-06-17 02:18:17 --> File loaded: application/views/common/header.php
DEBUG - 2011-06-17 02:18:17 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-06-17 02:18:17 --> File loaded: application/views/common/footer.php
DEBUG - 2011-06-17 02:18:17 --> File loaded: application/views/layout/main.php
DEBUG - 2011-06-17 02:18:17 --> Final output sent to browser
DEBUG - 2011-06-17 02:18:17 --> Total execution time: 0.3229
DEBUG - 2011-06-17 02:46:01 --> Config Class Initialized
DEBUG - 2011-06-17 02:46:01 --> Hooks Class Initialized
DEBUG - 2011-06-17 02:46:01 --> Utf8 Class Initialized
DEBUG - 2011-06-17 02:46:01 --> UTF-8 Support Enabled
DEBUG - 2011-06-17 02:46:01 --> URI Class Initialized
DEBUG - 2011-06-17 02:46:01 --> Router Class Initialized
DEBUG - 2011-06-17 02:46:01 --> Output Class Initialized
DEBUG - 2011-06-17 02:46:01 --> Input Class Initialized
DEBUG - 2011-06-17 02:46:01 --> Global POST and COOKIE data sanitized
DEBUG - 2011-06-17 02:46:01 --> Language Class Initialized
DEBUG - 2011-06-17 02:46:02 --> Loader Class Initialized
DEBUG - 2011-06-17 02:46:02 --> Controller Class Initialized
DEBUG - 2011-06-17 02:46:02 --> Model Class Initialized
DEBUG - 2011-06-17 02:46:02 --> Model Class Initialized
DEBUG - 2011-06-17 02:46:02 --> Model Class Initialized
DEBUG - 2011-06-17 02:46:02 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-06-17 02:46:02 --> Database Driver Class Initialized
DEBUG - 2011-06-17 02:46:07 --> File loaded: application/views/table/main.php
DEBUG - 2011-06-17 02:46:07 --> Helper loaded: url_helper
DEBUG - 2011-06-17 02:46:07 --> File loaded: application/views/common/header.php
DEBUG - 2011-06-17 02:46:07 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-06-17 02:46:07 --> File loaded: application/views/common/footer.php
DEBUG - 2011-06-17 02:46:07 --> File loaded: application/views/layout/main.php
DEBUG - 2011-06-17 02:46:07 --> Final output sent to browser
DEBUG - 2011-06-17 02:46:07 --> Total execution time: 6.0962
DEBUG - 2011-06-17 02:46:10 --> Config Class Initialized
DEBUG - 2011-06-17 02:46:10 --> Hooks Class Initialized
DEBUG - 2011-06-17 02:46:10 --> Utf8 Class Initialized
DEBUG - 2011-06-17 02:46:10 --> UTF-8 Support Enabled
DEBUG - 2011-06-17 02:46:10 --> URI Class Initialized
DEBUG - 2011-06-17 02:46:10 --> Router Class Initialized
ERROR - 2011-06-17 02:46:10 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-06-17 02:46:10 --> Config Class Initialized
DEBUG - 2011-06-17 02:46:10 --> Hooks Class Initialized
DEBUG - 2011-06-17 02:46:10 --> Utf8 Class Initialized
DEBUG - 2011-06-17 02:46:10 --> UTF-8 Support Enabled
DEBUG - 2011-06-17 02:46:10 --> URI Class Initialized
DEBUG - 2011-06-17 02:46:10 --> Router Class Initialized
ERROR - 2011-06-17 02:46:10 --> 404 Page Not Found --> robots.txt
DEBUG - 2011-06-17 02:46:10 --> Config Class Initialized
DEBUG - 2011-06-17 02:46:10 --> Hooks Class Initialized
DEBUG - 2011-06-17 02:46:10 --> Utf8 Class Initialized
DEBUG - 2011-06-17 02:46:10 --> UTF-8 Support Enabled
DEBUG - 2011-06-17 02:46:10 --> URI Class Initialized
DEBUG - 2011-06-17 02:46:10 --> Router Class Initialized
DEBUG - 2011-06-17 02:46:10 --> Output Class Initialized
DEBUG - 2011-06-17 02:46:10 --> Input Class Initialized
DEBUG - 2011-06-17 02:46:10 --> Global POST and COOKIE data sanitized
DEBUG - 2011-06-17 02:46:10 --> Language Class Initialized
DEBUG - 2011-06-17 02:46:10 --> Loader Class Initialized
DEBUG - 2011-06-17 02:46:10 --> Controller Class Initialized
DEBUG - 2011-06-17 02:46:10 --> Model Class Initialized
DEBUG - 2011-06-17 02:46:10 --> Model Class Initialized
DEBUG - 2011-06-17 02:46:10 --> Model Class Initialized
DEBUG - 2011-06-17 02:46:10 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-06-17 02:46:10 --> Database Driver Class Initialized
DEBUG - 2011-06-17 02:46:10 --> File loaded: application/views/table/main.php
DEBUG - 2011-06-17 02:46:10 --> Helper loaded: url_helper
DEBUG - 2011-06-17 02:46:10 --> File loaded: application/views/common/header.php
DEBUG - 2011-06-17 02:46:10 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-06-17 02:46:10 --> File loaded: application/views/common/footer.php
DEBUG - 2011-06-17 02:46:10 --> File loaded: application/views/layout/main.php
DEBUG - 2011-06-17 02:46:10 --> Final output sent to browser
DEBUG - 2011-06-17 02:46:10 --> Total execution time: 0.1088
DEBUG - 2011-06-17 04:50:42 --> Config Class Initialized
DEBUG - 2011-06-17 04:50:42 --> Hooks Class Initialized
DEBUG - 2011-06-17 04:50:42 --> Utf8 Class Initialized
DEBUG - 2011-06-17 04:50:42 --> UTF-8 Support Enabled
DEBUG - 2011-06-17 04:50:42 --> URI Class Initialized
DEBUG - 2011-06-17 04:50:42 --> Router Class Initialized
DEBUG - 2011-06-17 04:50:42 --> Output Class Initialized
DEBUG - 2011-06-17 04:50:42 --> Input Class Initialized
DEBUG - 2011-06-17 04:50:42 --> Global POST and COOKIE data sanitized
DEBUG - 2011-06-17 04:50:42 --> Language Class Initialized
DEBUG - 2011-06-17 04:50:42 --> Loader Class Initialized
DEBUG - 2011-06-17 04:50:42 --> Controller Class Initialized
DEBUG - 2011-06-17 04:50:42 --> Model Class Initialized
DEBUG - 2011-06-17 04:50:42 --> Model Class Initialized
DEBUG - 2011-06-17 04:50:42 --> Model Class Initialized
DEBUG - 2011-06-17 04:50:42 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-06-17 04:50:42 --> Database Driver Class Initialized
DEBUG - 2011-06-17 04:50:44 --> File loaded: application/views/table/main.php
DEBUG - 2011-06-17 04:50:44 --> Helper loaded: url_helper
DEBUG - 2011-06-17 04:50:44 --> File loaded: application/views/common/header.php
DEBUG - 2011-06-17 04:50:44 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-06-17 04:50:44 --> File loaded: application/views/common/footer.php
DEBUG - 2011-06-17 04:50:44 --> File loaded: application/views/layout/main.php
DEBUG - 2011-06-17 04:50:44 --> Final output sent to browser
DEBUG - 2011-06-17 04:50:44 --> Total execution time: 2.1376
DEBUG - 2011-06-17 04:50:45 --> Config Class Initialized
DEBUG - 2011-06-17 04:50:45 --> Hooks Class Initialized
DEBUG - 2011-06-17 04:50:45 --> Utf8 Class Initialized
DEBUG - 2011-06-17 04:50:45 --> UTF-8 Support Enabled
DEBUG - 2011-06-17 04:50:45 --> URI Class Initialized
DEBUG - 2011-06-17 04:50:45 --> Router Class Initialized
DEBUG - 2011-06-17 04:50:45 --> Output Class Initialized
DEBUG - 2011-06-17 04:50:45 --> Input Class Initialized
DEBUG - 2011-06-17 04:50:45 --> Global POST and COOKIE data sanitized
DEBUG - 2011-06-17 04:50:45 --> Language Class Initialized
DEBUG - 2011-06-17 04:50:45 --> Loader Class Initialized
DEBUG - 2011-06-17 04:50:45 --> Controller Class Initialized
ERROR - 2011-06-17 04:50:45 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-06-17 04:50:45 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-06-17 04:50:45 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-06-17 04:50:45 --> Model Class Initialized
DEBUG - 2011-06-17 04:50:45 --> Model Class Initialized
DEBUG - 2011-06-17 04:50:45 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-06-17 04:50:45 --> Database Driver Class Initialized
DEBUG - 2011-06-17 04:50:45 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-06-17 04:50:45 --> Helper loaded: url_helper
DEBUG - 2011-06-17 04:50:45 --> File loaded: application/views/common/header.php
DEBUG - 2011-06-17 04:50:45 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-06-17 04:50:45 --> File loaded: application/views/common/footer.php
DEBUG - 2011-06-17 04:50:45 --> File loaded: application/views/layout/main.php
DEBUG - 2011-06-17 04:50:45 --> Final output sent to browser
DEBUG - 2011-06-17 04:50:45 --> Total execution time: 0.1311
DEBUG - 2011-06-17 07:11:19 --> Config Class Initialized
DEBUG - 2011-06-17 07:11:19 --> Hooks Class Initialized
DEBUG - 2011-06-17 07:11:19 --> Utf8 Class Initialized
DEBUG - 2011-06-17 07:11:19 --> UTF-8 Support Enabled
DEBUG - 2011-06-17 07:11:19 --> URI Class Initialized
DEBUG - 2011-06-17 07:11:19 --> Router Class Initialized
ERROR - 2011-06-17 07:11:19 --> 404 Page Not Found --> robots.txt
DEBUG - 2011-06-17 07:24:37 --> Config Class Initialized
DEBUG - 2011-06-17 07:24:37 --> Hooks Class Initialized
DEBUG - 2011-06-17 07:24:37 --> Utf8 Class Initialized
DEBUG - 2011-06-17 07:24:37 --> UTF-8 Support Enabled
DEBUG - 2011-06-17 07:24:37 --> URI Class Initialized
DEBUG - 2011-06-17 07:24:37 --> Router Class Initialized
DEBUG - 2011-06-17 07:24:37 --> Output Class Initialized
DEBUG - 2011-06-17 07:24:37 --> Input Class Initialized
DEBUG - 2011-06-17 07:24:37 --> Global POST and COOKIE data sanitized
DEBUG - 2011-06-17 07:24:37 --> Language Class Initialized
DEBUG - 2011-06-17 07:24:38 --> Loader Class Initialized
DEBUG - 2011-06-17 07:24:38 --> Controller Class Initialized
DEBUG - 2011-06-17 07:24:38 --> Model Class Initialized
DEBUG - 2011-06-17 07:24:38 --> Model Class Initialized
DEBUG - 2011-06-17 07:24:38 --> Model Class Initialized
DEBUG - 2011-06-17 07:24:38 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-06-17 07:24:38 --> Database Driver Class Initialized
DEBUG - 2011-06-17 07:24:39 --> File loaded: application/views/table/main.php
DEBUG - 2011-06-17 07:24:39 --> Helper loaded: url_helper
DEBUG - 2011-06-17 07:24:39 --> File loaded: application/views/common/header.php
DEBUG - 2011-06-17 07:24:39 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-06-17 07:24:39 --> File loaded: application/views/common/footer.php
DEBUG - 2011-06-17 07:24:39 --> File loaded: application/views/layout/main.php
DEBUG - 2011-06-17 07:24:39 --> Final output sent to browser
DEBUG - 2011-06-17 07:24:39 --> Total execution time: 1.7147
DEBUG - 2011-06-17 07:24:40 --> Config Class Initialized
DEBUG - 2011-06-17 07:24:40 --> Hooks Class Initialized
DEBUG - 2011-06-17 07:24:40 --> Utf8 Class Initialized
DEBUG - 2011-06-17 07:24:40 --> UTF-8 Support Enabled
DEBUG - 2011-06-17 07:24:40 --> URI Class Initialized
DEBUG - 2011-06-17 07:24:40 --> Router Class Initialized
DEBUG - 2011-06-17 07:24:40 --> Output Class Initialized
DEBUG - 2011-06-17 07:24:40 --> Input Class Initialized
DEBUG - 2011-06-17 07:24:40 --> Global POST and COOKIE data sanitized
DEBUG - 2011-06-17 07:24:40 --> Language Class Initialized
DEBUG - 2011-06-17 07:24:40 --> Loader Class Initialized
DEBUG - 2011-06-17 07:24:40 --> Controller Class Initialized
ERROR - 2011-06-17 07:24:40 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-06-17 07:24:40 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-06-17 07:24:40 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-06-17 07:24:40 --> Model Class Initialized
DEBUG - 2011-06-17 07:24:40 --> Model Class Initialized
DEBUG - 2011-06-17 07:24:40 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-06-17 07:24:40 --> Database Driver Class Initialized
DEBUG - 2011-06-17 07:24:40 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-06-17 07:24:40 --> Helper loaded: url_helper
DEBUG - 2011-06-17 07:24:40 --> File loaded: application/views/common/header.php
DEBUG - 2011-06-17 07:24:40 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-06-17 07:24:40 --> File loaded: application/views/common/footer.php
DEBUG - 2011-06-17 07:24:40 --> File loaded: application/views/layout/main.php
DEBUG - 2011-06-17 07:24:40 --> Final output sent to browser
DEBUG - 2011-06-17 07:24:40 --> Total execution time: 0.1060
DEBUG - 2011-06-17 07:27:11 --> Config Class Initialized
DEBUG - 2011-06-17 07:27:11 --> Hooks Class Initialized
DEBUG - 2011-06-17 07:27:11 --> Utf8 Class Initialized
DEBUG - 2011-06-17 07:27:11 --> UTF-8 Support Enabled
DEBUG - 2011-06-17 07:27:11 --> URI Class Initialized
DEBUG - 2011-06-17 07:27:11 --> Router Class Initialized
DEBUG - 2011-06-17 07:27:11 --> No URI present. Default controller set.
DEBUG - 2011-06-17 07:27:11 --> Output Class Initialized
DEBUG - 2011-06-17 07:27:11 --> Input Class Initialized
DEBUG - 2011-06-17 07:27:11 --> Global POST and COOKIE data sanitized
DEBUG - 2011-06-17 07:27:11 --> Language Class Initialized
DEBUG - 2011-06-17 07:27:11 --> Loader Class Initialized
DEBUG - 2011-06-17 07:27:11 --> Controller Class Initialized
DEBUG - 2011-06-17 07:27:11 --> File loaded: application/views/splash/main.php
DEBUG - 2011-06-17 07:27:11 --> Helper loaded: url_helper
DEBUG - 2011-06-17 07:27:11 --> File loaded: application/views/common/header.php
DEBUG - 2011-06-17 07:27:11 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-06-17 07:27:11 --> File loaded: application/views/common/footer.php
DEBUG - 2011-06-17 07:27:11 --> File loaded: application/views/layout/main.php
DEBUG - 2011-06-17 07:27:11 --> Final output sent to browser
DEBUG - 2011-06-17 07:27:11 --> Total execution time: 0.0557
DEBUG - 2011-06-17 10:01:00 --> Config Class Initialized
DEBUG - 2011-06-17 10:01:00 --> Hooks Class Initialized
DEBUG - 2011-06-17 10:01:00 --> Utf8 Class Initialized
DEBUG - 2011-06-17 10:01:00 --> UTF-8 Support Enabled
DEBUG - 2011-06-17 10:01:00 --> URI Class Initialized
DEBUG - 2011-06-17 10:01:00 --> Router Class Initialized
DEBUG - 2011-06-17 10:01:00 --> Output Class Initialized
DEBUG - 2011-06-17 10:01:00 --> Input Class Initialized
DEBUG - 2011-06-17 10:01:00 --> Global POST and COOKIE data sanitized
DEBUG - 2011-06-17 10:01:00 --> Language Class Initialized
DEBUG - 2011-06-17 10:01:00 --> Loader Class Initialized
DEBUG - 2011-06-17 10:01:00 --> Controller Class Initialized
DEBUG - 2011-06-17 10:01:00 --> Model Class Initialized
DEBUG - 2011-06-17 10:01:01 --> Model Class Initialized
DEBUG - 2011-06-17 10:01:01 --> Model Class Initialized
DEBUG - 2011-06-17 10:01:01 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-06-17 10:01:01 --> Database Driver Class Initialized
DEBUG - 2011-06-17 10:01:01 --> File loaded: application/views/table/main.php
DEBUG - 2011-06-17 10:01:01 --> Helper loaded: url_helper
DEBUG - 2011-06-17 10:01:01 --> File loaded: application/views/common/header.php
DEBUG - 2011-06-17 10:01:01 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-06-17 10:01:01 --> File loaded: application/views/common/footer.php
DEBUG - 2011-06-17 10:01:01 --> File loaded: application/views/layout/main.php
DEBUG - 2011-06-17 10:01:01 --> Final output sent to browser
DEBUG - 2011-06-17 10:01:01 --> Total execution time: 0.6029
DEBUG - 2011-06-17 10:01:02 --> Config Class Initialized
DEBUG - 2011-06-17 10:01:02 --> Hooks Class Initialized
DEBUG - 2011-06-17 10:01:02 --> Utf8 Class Initialized
DEBUG - 2011-06-17 10:01:02 --> UTF-8 Support Enabled
DEBUG - 2011-06-17 10:01:02 --> URI Class Initialized
DEBUG - 2011-06-17 10:01:02 --> Router Class Initialized
DEBUG - 2011-06-17 10:01:02 --> Output Class Initialized
DEBUG - 2011-06-17 10:01:02 --> Input Class Initialized
DEBUG - 2011-06-17 10:01:02 --> Global POST and COOKIE data sanitized
DEBUG - 2011-06-17 10:01:02 --> Language Class Initialized
DEBUG - 2011-06-17 10:01:02 --> Loader Class Initialized
DEBUG - 2011-06-17 10:01:02 --> Controller Class Initialized
ERROR - 2011-06-17 10:01:02 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-06-17 10:01:02 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-06-17 10:01:02 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-06-17 10:01:02 --> Model Class Initialized
DEBUG - 2011-06-17 10:01:02 --> Model Class Initialized
DEBUG - 2011-06-17 10:01:02 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-06-17 10:01:02 --> Database Driver Class Initialized
DEBUG - 2011-06-17 10:01:02 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-06-17 10:01:02 --> Helper loaded: url_helper
DEBUG - 2011-06-17 10:01:02 --> File loaded: application/views/common/header.php
DEBUG - 2011-06-17 10:01:02 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-06-17 10:01:02 --> File loaded: application/views/common/footer.php
DEBUG - 2011-06-17 10:01:02 --> File loaded: application/views/layout/main.php
DEBUG - 2011-06-17 10:01:02 --> Final output sent to browser
DEBUG - 2011-06-17 10:01:02 --> Total execution time: 0.1276
DEBUG - 2011-06-17 10:13:35 --> Config Class Initialized
DEBUG - 2011-06-17 10:13:35 --> Hooks Class Initialized
DEBUG - 2011-06-17 10:13:35 --> Utf8 Class Initialized
DEBUG - 2011-06-17 10:13:35 --> UTF-8 Support Enabled
DEBUG - 2011-06-17 10:13:35 --> URI Class Initialized
DEBUG - 2011-06-17 10:13:35 --> Router Class Initialized
DEBUG - 2011-06-17 10:13:35 --> Output Class Initialized
DEBUG - 2011-06-17 10:13:35 --> Input Class Initialized
DEBUG - 2011-06-17 10:13:35 --> Global POST and COOKIE data sanitized
DEBUG - 2011-06-17 10:13:35 --> Language Class Initialized
DEBUG - 2011-06-17 10:13:35 --> Loader Class Initialized
DEBUG - 2011-06-17 10:13:35 --> Controller Class Initialized
DEBUG - 2011-06-17 10:13:35 --> Model Class Initialized
DEBUG - 2011-06-17 10:13:35 --> Model Class Initialized
DEBUG - 2011-06-17 10:13:35 --> Model Class Initialized
DEBUG - 2011-06-17 10:13:35 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-06-17 10:13:35 --> Database Driver Class Initialized
DEBUG - 2011-06-17 10:13:35 --> File loaded: application/views/table/main.php
DEBUG - 2011-06-17 10:13:35 --> Helper loaded: url_helper
DEBUG - 2011-06-17 10:13:35 --> File loaded: application/views/common/header.php
DEBUG - 2011-06-17 10:13:35 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-06-17 10:13:35 --> File loaded: application/views/common/footer.php
DEBUG - 2011-06-17 10:13:35 --> File loaded: application/views/layout/main.php
DEBUG - 2011-06-17 10:13:35 --> Final output sent to browser
DEBUG - 2011-06-17 10:13:35 --> Total execution time: 0.2686
DEBUG - 2011-06-17 10:13:39 --> Config Class Initialized
DEBUG - 2011-06-17 10:13:39 --> Hooks Class Initialized
DEBUG - 2011-06-17 10:13:39 --> Utf8 Class Initialized
DEBUG - 2011-06-17 10:13:39 --> UTF-8 Support Enabled
DEBUG - 2011-06-17 10:13:39 --> URI Class Initialized
DEBUG - 2011-06-17 10:13:39 --> Router Class Initialized
ERROR - 2011-06-17 10:13:39 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-06-17 10:25:45 --> Config Class Initialized
DEBUG - 2011-06-17 10:25:45 --> Hooks Class Initialized
DEBUG - 2011-06-17 10:25:45 --> Utf8 Class Initialized
DEBUG - 2011-06-17 10:25:45 --> UTF-8 Support Enabled
DEBUG - 2011-06-17 10:25:45 --> URI Class Initialized
DEBUG - 2011-06-17 10:25:45 --> Router Class Initialized
ERROR - 2011-06-17 10:25:45 --> 404 Page Not Found --> robots.txt
DEBUG - 2011-06-17 10:25:45 --> Config Class Initialized
DEBUG - 2011-06-17 10:25:45 --> Hooks Class Initialized
DEBUG - 2011-06-17 10:25:45 --> Utf8 Class Initialized
DEBUG - 2011-06-17 10:25:45 --> UTF-8 Support Enabled
DEBUG - 2011-06-17 10:25:45 --> URI Class Initialized
DEBUG - 2011-06-17 10:25:45 --> Router Class Initialized
DEBUG - 2011-06-17 10:25:45 --> Output Class Initialized
DEBUG - 2011-06-17 10:25:45 --> Input Class Initialized
DEBUG - 2011-06-17 10:25:45 --> Global POST and COOKIE data sanitized
DEBUG - 2011-06-17 10:25:45 --> Language Class Initialized
DEBUG - 2011-06-17 10:25:45 --> Loader Class Initialized
DEBUG - 2011-06-17 10:25:45 --> Controller Class Initialized
DEBUG - 2011-06-17 10:25:45 --> Model Class Initialized
DEBUG - 2011-06-17 10:25:45 --> Model Class Initialized
DEBUG - 2011-06-17 10:25:45 --> Model Class Initialized
DEBUG - 2011-06-17 10:25:45 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-06-17 10:25:45 --> Database Driver Class Initialized
DEBUG - 2011-06-17 10:25:45 --> File loaded: application/views/table/main.php
DEBUG - 2011-06-17 10:25:45 --> Helper loaded: url_helper
DEBUG - 2011-06-17 10:25:45 --> File loaded: application/views/common/header.php
DEBUG - 2011-06-17 10:25:45 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-06-17 10:25:45 --> File loaded: application/views/common/footer.php
DEBUG - 2011-06-17 10:25:45 --> File loaded: application/views/layout/main.php
DEBUG - 2011-06-17 10:25:45 --> Final output sent to browser
DEBUG - 2011-06-17 10:25:45 --> Total execution time: 0.2407
DEBUG - 2011-06-17 10:26:45 --> Config Class Initialized
DEBUG - 2011-06-17 10:26:45 --> Hooks Class Initialized
DEBUG - 2011-06-17 10:26:45 --> Utf8 Class Initialized
DEBUG - 2011-06-17 10:26:45 --> UTF-8 Support Enabled
DEBUG - 2011-06-17 10:26:45 --> URI Class Initialized
DEBUG - 2011-06-17 10:26:45 --> Router Class Initialized
DEBUG - 2011-06-17 10:26:45 --> Output Class Initialized
DEBUG - 2011-06-17 10:26:45 --> Input Class Initialized
DEBUG - 2011-06-17 10:26:45 --> Global POST and COOKIE data sanitized
DEBUG - 2011-06-17 10:26:45 --> Language Class Initialized
DEBUG - 2011-06-17 10:26:45 --> Loader Class Initialized
DEBUG - 2011-06-17 10:26:45 --> Controller Class Initialized
ERROR - 2011-06-17 10:26:46 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-06-17 10:26:46 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-06-17 10:26:46 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-06-17 10:26:46 --> Model Class Initialized
DEBUG - 2011-06-17 10:26:46 --> Model Class Initialized
DEBUG - 2011-06-17 10:26:46 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-06-17 10:26:46 --> Database Driver Class Initialized
DEBUG - 2011-06-17 10:26:46 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-06-17 10:26:46 --> Helper loaded: url_helper
DEBUG - 2011-06-17 10:26:46 --> File loaded: application/views/common/header.php
DEBUG - 2011-06-17 10:26:46 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-06-17 10:26:46 --> File loaded: application/views/common/footer.php
DEBUG - 2011-06-17 10:26:46 --> File loaded: application/views/layout/main.php
DEBUG - 2011-06-17 10:26:46 --> Final output sent to browser
DEBUG - 2011-06-17 10:26:46 --> Total execution time: 1.8060
DEBUG - 2011-06-17 10:33:27 --> Config Class Initialized
DEBUG - 2011-06-17 10:33:27 --> Hooks Class Initialized
DEBUG - 2011-06-17 10:33:27 --> Utf8 Class Initialized
DEBUG - 2011-06-17 10:33:27 --> UTF-8 Support Enabled
DEBUG - 2011-06-17 10:33:27 --> URI Class Initialized
DEBUG - 2011-06-17 10:33:27 --> Router Class Initialized
DEBUG - 2011-06-17 10:33:27 --> Output Class Initialized
DEBUG - 2011-06-17 10:33:27 --> Input Class Initialized
DEBUG - 2011-06-17 10:33:27 --> Global POST and COOKIE data sanitized
DEBUG - 2011-06-17 10:33:27 --> Language Class Initialized
DEBUG - 2011-06-17 10:33:27 --> Loader Class Initialized
DEBUG - 2011-06-17 10:33:27 --> Controller Class Initialized
ERROR - 2011-06-17 10:33:27 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-06-17 10:33:27 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-06-17 10:33:27 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-06-17 10:33:27 --> Model Class Initialized
DEBUG - 2011-06-17 10:33:27 --> Model Class Initialized
DEBUG - 2011-06-17 10:33:27 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-06-17 10:33:27 --> Database Driver Class Initialized
DEBUG - 2011-06-17 10:33:27 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-06-17 10:33:27 --> Helper loaded: url_helper
DEBUG - 2011-06-17 10:33:27 --> File loaded: application/views/common/header.php
DEBUG - 2011-06-17 10:33:27 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-06-17 10:33:27 --> File loaded: application/views/common/footer.php
DEBUG - 2011-06-17 10:33:27 --> File loaded: application/views/layout/main.php
DEBUG - 2011-06-17 10:33:27 --> Final output sent to browser
DEBUG - 2011-06-17 10:33:27 --> Total execution time: 0.1028
DEBUG - 2011-06-17 10:56:31 --> Config Class Initialized
DEBUG - 2011-06-17 10:56:31 --> Hooks Class Initialized
DEBUG - 2011-06-17 10:56:31 --> Utf8 Class Initialized
DEBUG - 2011-06-17 10:56:31 --> UTF-8 Support Enabled
DEBUG - 2011-06-17 10:56:31 --> URI Class Initialized
DEBUG - 2011-06-17 10:56:31 --> Router Class Initialized
DEBUG - 2011-06-17 10:56:31 --> Output Class Initialized
DEBUG - 2011-06-17 10:56:31 --> Input Class Initialized
DEBUG - 2011-06-17 10:56:31 --> Global POST and COOKIE data sanitized
DEBUG - 2011-06-17 10:56:31 --> Language Class Initialized
DEBUG - 2011-06-17 10:56:31 --> Loader Class Initialized
DEBUG - 2011-06-17 10:56:31 --> Controller Class Initialized
DEBUG - 2011-06-17 10:56:31 --> Model Class Initialized
DEBUG - 2011-06-17 10:56:32 --> Model Class Initialized
DEBUG - 2011-06-17 10:56:32 --> Model Class Initialized
DEBUG - 2011-06-17 10:56:32 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-06-17 10:56:32 --> Database Driver Class Initialized
DEBUG - 2011-06-17 10:56:32 --> File loaded: application/views/table/main.php
DEBUG - 2011-06-17 10:56:32 --> Helper loaded: url_helper
DEBUG - 2011-06-17 10:56:32 --> File loaded: application/views/common/header.php
DEBUG - 2011-06-17 10:56:32 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-06-17 10:56:32 --> File loaded: application/views/common/footer.php
DEBUG - 2011-06-17 10:56:32 --> File loaded: application/views/layout/main.php
DEBUG - 2011-06-17 10:56:32 --> Final output sent to browser
DEBUG - 2011-06-17 10:56:32 --> Total execution time: 1.2601
DEBUG - 2011-06-17 10:56:37 --> Config Class Initialized
DEBUG - 2011-06-17 10:56:37 --> Hooks Class Initialized
DEBUG - 2011-06-17 10:56:37 --> Utf8 Class Initialized
DEBUG - 2011-06-17 10:56:37 --> UTF-8 Support Enabled
DEBUG - 2011-06-17 10:56:37 --> URI Class Initialized
DEBUG - 2011-06-17 10:56:37 --> Router Class Initialized
ERROR - 2011-06-17 10:56:37 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-06-17 10:56:57 --> Config Class Initialized
DEBUG - 2011-06-17 10:56:57 --> Hooks Class Initialized
DEBUG - 2011-06-17 10:56:57 --> Utf8 Class Initialized
DEBUG - 2011-06-17 10:56:57 --> UTF-8 Support Enabled
DEBUG - 2011-06-17 10:56:57 --> URI Class Initialized
DEBUG - 2011-06-17 10:56:57 --> Router Class Initialized
DEBUG - 2011-06-17 10:56:57 --> Output Class Initialized
DEBUG - 2011-06-17 10:56:57 --> Input Class Initialized
DEBUG - 2011-06-17 10:56:57 --> Global POST and COOKIE data sanitized
DEBUG - 2011-06-17 10:56:57 --> Language Class Initialized
DEBUG - 2011-06-17 10:56:57 --> Loader Class Initialized
DEBUG - 2011-06-17 10:56:57 --> Controller Class Initialized
DEBUG - 2011-06-17 10:56:57 --> Model Class Initialized
DEBUG - 2011-06-17 10:56:57 --> Model Class Initialized
DEBUG - 2011-06-17 10:56:57 --> Model Class Initialized
DEBUG - 2011-06-17 10:56:57 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-06-17 10:56:57 --> Database Driver Class Initialized
DEBUG - 2011-06-17 10:56:59 --> File loaded: application/views/table/main.php
DEBUG - 2011-06-17 10:56:59 --> Helper loaded: url_helper
DEBUG - 2011-06-17 10:56:59 --> File loaded: application/views/common/header.php
DEBUG - 2011-06-17 10:56:59 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-06-17 10:56:59 --> File loaded: application/views/common/footer.php
DEBUG - 2011-06-17 10:56:59 --> File loaded: application/views/layout/main.php
DEBUG - 2011-06-17 10:56:59 --> Final output sent to browser
DEBUG - 2011-06-17 10:56:59 --> Total execution time: 1.4090
DEBUG - 2011-06-17 10:57:01 --> Config Class Initialized
DEBUG - 2011-06-17 10:57:01 --> Hooks Class Initialized
DEBUG - 2011-06-17 10:57:01 --> Utf8 Class Initialized
DEBUG - 2011-06-17 10:57:01 --> UTF-8 Support Enabled
DEBUG - 2011-06-17 10:57:01 --> URI Class Initialized
DEBUG - 2011-06-17 10:57:01 --> Router Class Initialized
ERROR - 2011-06-17 10:57:01 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-06-17 10:57:01 --> Config Class Initialized
DEBUG - 2011-06-17 10:57:01 --> Hooks Class Initialized
DEBUG - 2011-06-17 10:57:01 --> Utf8 Class Initialized
DEBUG - 2011-06-17 10:57:01 --> UTF-8 Support Enabled
DEBUG - 2011-06-17 10:57:01 --> URI Class Initialized
DEBUG - 2011-06-17 10:57:01 --> Router Class Initialized
DEBUG - 2011-06-17 10:57:01 --> Output Class Initialized
DEBUG - 2011-06-17 10:57:01 --> Input Class Initialized
DEBUG - 2011-06-17 10:57:01 --> Global POST and COOKIE data sanitized
DEBUG - 2011-06-17 10:57:01 --> Language Class Initialized
DEBUG - 2011-06-17 10:57:01 --> Loader Class Initialized
DEBUG - 2011-06-17 10:57:01 --> Controller Class Initialized
DEBUG - 2011-06-17 10:57:01 --> Model Class Initialized
DEBUG - 2011-06-17 10:57:01 --> Model Class Initialized
DEBUG - 2011-06-17 10:57:01 --> Model Class Initialized
DEBUG - 2011-06-17 10:57:01 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-06-17 10:57:01 --> Database Driver Class Initialized
DEBUG - 2011-06-17 10:57:01 --> File loaded: application/views/table/main.php
DEBUG - 2011-06-17 10:57:01 --> Helper loaded: url_helper
DEBUG - 2011-06-17 10:57:01 --> File loaded: application/views/common/header.php
DEBUG - 2011-06-17 10:57:01 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-06-17 10:57:01 --> File loaded: application/views/common/footer.php
DEBUG - 2011-06-17 10:57:01 --> File loaded: application/views/layout/main.php
DEBUG - 2011-06-17 10:57:01 --> Final output sent to browser
DEBUG - 2011-06-17 10:57:01 --> Total execution time: 0.0639
DEBUG - 2011-06-17 10:57:16 --> Config Class Initialized
DEBUG - 2011-06-17 10:57:16 --> Hooks Class Initialized
DEBUG - 2011-06-17 10:57:16 --> Utf8 Class Initialized
DEBUG - 2011-06-17 10:57:16 --> UTF-8 Support Enabled
DEBUG - 2011-06-17 10:57:16 --> URI Class Initialized
DEBUG - 2011-06-17 10:57:16 --> Router Class Initialized
DEBUG - 2011-06-17 10:57:16 --> Output Class Initialized
DEBUG - 2011-06-17 10:57:16 --> Input Class Initialized
DEBUG - 2011-06-17 10:57:16 --> Global POST and COOKIE data sanitized
DEBUG - 2011-06-17 10:57:16 --> Language Class Initialized
DEBUG - 2011-06-17 10:57:16 --> Loader Class Initialized
DEBUG - 2011-06-17 10:57:16 --> Controller Class Initialized
DEBUG - 2011-06-17 10:57:16 --> Model Class Initialized
DEBUG - 2011-06-17 10:57:16 --> Model Class Initialized
DEBUG - 2011-06-17 10:57:16 --> Model Class Initialized
DEBUG - 2011-06-17 10:57:16 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-06-17 10:57:16 --> Database Driver Class Initialized
DEBUG - 2011-06-17 10:57:17 --> File loaded: application/views/table/main.php
DEBUG - 2011-06-17 10:57:17 --> Helper loaded: url_helper
DEBUG - 2011-06-17 10:57:17 --> File loaded: application/views/common/header.php
DEBUG - 2011-06-17 10:57:17 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-06-17 10:57:17 --> File loaded: application/views/common/footer.php
DEBUG - 2011-06-17 10:57:17 --> File loaded: application/views/layout/main.php
DEBUG - 2011-06-17 10:57:17 --> Final output sent to browser
DEBUG - 2011-06-17 10:57:17 --> Total execution time: 0.3421
DEBUG - 2011-06-17 10:57:19 --> Config Class Initialized
DEBUG - 2011-06-17 10:57:19 --> Hooks Class Initialized
DEBUG - 2011-06-17 10:57:19 --> Utf8 Class Initialized
DEBUG - 2011-06-17 10:57:19 --> UTF-8 Support Enabled
DEBUG - 2011-06-17 10:57:19 --> URI Class Initialized
DEBUG - 2011-06-17 10:57:19 --> Router Class Initialized
ERROR - 2011-06-17 10:57:19 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-06-17 10:57:20 --> Config Class Initialized
DEBUG - 2011-06-17 10:57:20 --> Hooks Class Initialized
DEBUG - 2011-06-17 10:57:20 --> Utf8 Class Initialized
DEBUG - 2011-06-17 10:57:20 --> UTF-8 Support Enabled
DEBUG - 2011-06-17 10:57:20 --> URI Class Initialized
DEBUG - 2011-06-17 10:57:20 --> Router Class Initialized
DEBUG - 2011-06-17 10:57:20 --> Output Class Initialized
DEBUG - 2011-06-17 10:57:20 --> Input Class Initialized
DEBUG - 2011-06-17 10:57:20 --> Global POST and COOKIE data sanitized
DEBUG - 2011-06-17 10:57:20 --> Language Class Initialized
DEBUG - 2011-06-17 10:57:20 --> Loader Class Initialized
DEBUG - 2011-06-17 10:57:20 --> Controller Class Initialized
DEBUG - 2011-06-17 10:57:20 --> Model Class Initialized
DEBUG - 2011-06-17 10:57:20 --> Model Class Initialized
DEBUG - 2011-06-17 10:57:20 --> Model Class Initialized
DEBUG - 2011-06-17 10:57:20 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-06-17 10:57:20 --> Database Driver Class Initialized
DEBUG - 2011-06-17 10:57:20 --> File loaded: application/views/table/main.php
DEBUG - 2011-06-17 10:57:20 --> Helper loaded: url_helper
DEBUG - 2011-06-17 10:57:20 --> File loaded: application/views/common/header.php
DEBUG - 2011-06-17 10:57:20 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-06-17 10:57:20 --> File loaded: application/views/common/footer.php
DEBUG - 2011-06-17 10:57:20 --> File loaded: application/views/layout/main.php
DEBUG - 2011-06-17 10:57:20 --> Final output sent to browser
DEBUG - 2011-06-17 10:57:20 --> Total execution time: 0.0750
DEBUG - 2011-06-17 10:57:24 --> Config Class Initialized
DEBUG - 2011-06-17 10:57:24 --> Hooks Class Initialized
DEBUG - 2011-06-17 10:57:24 --> Utf8 Class Initialized
DEBUG - 2011-06-17 10:57:24 --> UTF-8 Support Enabled
DEBUG - 2011-06-17 10:57:24 --> URI Class Initialized
DEBUG - 2011-06-17 10:57:24 --> Router Class Initialized
DEBUG - 2011-06-17 10:57:24 --> Output Class Initialized
DEBUG - 2011-06-17 10:57:24 --> Input Class Initialized
DEBUG - 2011-06-17 10:57:24 --> Global POST and COOKIE data sanitized
DEBUG - 2011-06-17 10:57:24 --> Language Class Initialized
DEBUG - 2011-06-17 10:57:24 --> Loader Class Initialized
DEBUG - 2011-06-17 10:57:24 --> Controller Class Initialized
DEBUG - 2011-06-17 10:57:24 --> Model Class Initialized
DEBUG - 2011-06-17 10:57:24 --> Model Class Initialized
DEBUG - 2011-06-17 10:57:24 --> Model Class Initialized
DEBUG - 2011-06-17 10:57:24 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-06-17 10:57:24 --> Database Driver Class Initialized
DEBUG - 2011-06-17 10:57:25 --> File loaded: application/views/table/main.php
DEBUG - 2011-06-17 10:57:25 --> Helper loaded: url_helper
DEBUG - 2011-06-17 10:57:25 --> File loaded: application/views/common/header.php
DEBUG - 2011-06-17 10:57:25 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-06-17 10:57:25 --> File loaded: application/views/common/footer.php
DEBUG - 2011-06-17 10:57:25 --> File loaded: application/views/layout/main.php
DEBUG - 2011-06-17 10:57:25 --> Final output sent to browser
DEBUG - 2011-06-17 10:57:25 --> Total execution time: 0.5490
DEBUG - 2011-06-17 10:57:27 --> Config Class Initialized
DEBUG - 2011-06-17 10:57:27 --> Hooks Class Initialized
DEBUG - 2011-06-17 10:57:27 --> Utf8 Class Initialized
DEBUG - 2011-06-17 10:57:27 --> UTF-8 Support Enabled
DEBUG - 2011-06-17 10:57:27 --> URI Class Initialized
DEBUG - 2011-06-17 10:57:27 --> Router Class Initialized
ERROR - 2011-06-17 10:57:27 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-06-17 10:57:39 --> Config Class Initialized
DEBUG - 2011-06-17 10:57:39 --> Hooks Class Initialized
DEBUG - 2011-06-17 10:57:39 --> Utf8 Class Initialized
DEBUG - 2011-06-17 10:57:39 --> UTF-8 Support Enabled
DEBUG - 2011-06-17 10:57:39 --> URI Class Initialized
DEBUG - 2011-06-17 10:57:39 --> Router Class Initialized
DEBUG - 2011-06-17 10:57:39 --> Output Class Initialized
DEBUG - 2011-06-17 10:57:39 --> Input Class Initialized
DEBUG - 2011-06-17 10:57:39 --> Global POST and COOKIE data sanitized
DEBUG - 2011-06-17 10:57:39 --> Language Class Initialized
DEBUG - 2011-06-17 10:57:39 --> Loader Class Initialized
DEBUG - 2011-06-17 10:57:39 --> Controller Class Initialized
DEBUG - 2011-06-17 10:57:39 --> Model Class Initialized
DEBUG - 2011-06-17 10:57:39 --> Model Class Initialized
DEBUG - 2011-06-17 10:57:39 --> Model Class Initialized
DEBUG - 2011-06-17 10:57:39 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-06-17 10:57:39 --> Database Driver Class Initialized
DEBUG - 2011-06-17 10:57:40 --> File loaded: application/views/table/main.php
DEBUG - 2011-06-17 10:57:40 --> Helper loaded: url_helper
DEBUG - 2011-06-17 10:57:40 --> File loaded: application/views/common/header.php
DEBUG - 2011-06-17 10:57:40 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-06-17 10:57:40 --> File loaded: application/views/common/footer.php
DEBUG - 2011-06-17 10:57:40 --> File loaded: application/views/layout/main.php
DEBUG - 2011-06-17 10:57:40 --> Final output sent to browser
DEBUG - 2011-06-17 10:57:40 --> Total execution time: 0.3358
DEBUG - 2011-06-17 10:57:42 --> Config Class Initialized
DEBUG - 2011-06-17 10:57:42 --> Hooks Class Initialized
DEBUG - 2011-06-17 10:57:42 --> Utf8 Class Initialized
DEBUG - 2011-06-17 10:57:42 --> UTF-8 Support Enabled
DEBUG - 2011-06-17 10:57:42 --> URI Class Initialized
DEBUG - 2011-06-17 10:57:42 --> Router Class Initialized
ERROR - 2011-06-17 10:57:42 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-06-17 10:57:47 --> Config Class Initialized
DEBUG - 2011-06-17 10:57:47 --> Hooks Class Initialized
DEBUG - 2011-06-17 10:57:47 --> Utf8 Class Initialized
DEBUG - 2011-06-17 10:57:47 --> UTF-8 Support Enabled
DEBUG - 2011-06-17 10:57:47 --> URI Class Initialized
DEBUG - 2011-06-17 10:57:47 --> Router Class Initialized
DEBUG - 2011-06-17 10:57:47 --> Output Class Initialized
DEBUG - 2011-06-17 10:57:47 --> Input Class Initialized
DEBUG - 2011-06-17 10:57:47 --> Global POST and COOKIE data sanitized
DEBUG - 2011-06-17 10:57:47 --> Language Class Initialized
DEBUG - 2011-06-17 10:57:47 --> Loader Class Initialized
DEBUG - 2011-06-17 10:57:47 --> Controller Class Initialized
DEBUG - 2011-06-17 10:57:47 --> Model Class Initialized
DEBUG - 2011-06-17 10:57:47 --> Model Class Initialized
DEBUG - 2011-06-17 10:57:47 --> Model Class Initialized
DEBUG - 2011-06-17 10:57:47 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-06-17 10:57:47 --> Database Driver Class Initialized
DEBUG - 2011-06-17 10:57:47 --> File loaded: application/views/table/main.php
DEBUG - 2011-06-17 10:57:47 --> Helper loaded: url_helper
DEBUG - 2011-06-17 10:57:47 --> File loaded: application/views/common/header.php
DEBUG - 2011-06-17 10:57:47 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-06-17 10:57:47 --> File loaded: application/views/common/footer.php
DEBUG - 2011-06-17 10:57:47 --> File loaded: application/views/layout/main.php
DEBUG - 2011-06-17 10:57:47 --> Final output sent to browser
DEBUG - 2011-06-17 10:57:47 --> Total execution time: 0.3310
DEBUG - 2011-06-17 10:57:49 --> Config Class Initialized
DEBUG - 2011-06-17 10:57:49 --> Hooks Class Initialized
DEBUG - 2011-06-17 10:57:49 --> Utf8 Class Initialized
DEBUG - 2011-06-17 10:57:49 --> UTF-8 Support Enabled
DEBUG - 2011-06-17 10:57:49 --> URI Class Initialized
DEBUG - 2011-06-17 10:57:49 --> Router Class Initialized
ERROR - 2011-06-17 10:57:49 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-06-17 10:57:57 --> Config Class Initialized
DEBUG - 2011-06-17 10:57:57 --> Hooks Class Initialized
DEBUG - 2011-06-17 10:57:57 --> Utf8 Class Initialized
DEBUG - 2011-06-17 10:57:57 --> UTF-8 Support Enabled
DEBUG - 2011-06-17 10:57:57 --> URI Class Initialized
DEBUG - 2011-06-17 10:57:57 --> Router Class Initialized
DEBUG - 2011-06-17 10:57:57 --> Output Class Initialized
DEBUG - 2011-06-17 10:57:57 --> Input Class Initialized
DEBUG - 2011-06-17 10:57:57 --> Global POST and COOKIE data sanitized
DEBUG - 2011-06-17 10:57:57 --> Language Class Initialized
DEBUG - 2011-06-17 10:57:57 --> Loader Class Initialized
DEBUG - 2011-06-17 10:57:57 --> Controller Class Initialized
DEBUG - 2011-06-17 10:57:57 --> Model Class Initialized
DEBUG - 2011-06-17 10:57:57 --> Model Class Initialized
DEBUG - 2011-06-17 10:57:57 --> Model Class Initialized
DEBUG - 2011-06-17 10:57:57 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-06-17 10:57:57 --> Database Driver Class Initialized
DEBUG - 2011-06-17 10:57:57 --> File loaded: application/views/table/main.php
DEBUG - 2011-06-17 10:57:57 --> Helper loaded: url_helper
DEBUG - 2011-06-17 10:57:57 --> File loaded: application/views/common/header.php
DEBUG - 2011-06-17 10:57:57 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-06-17 10:57:57 --> File loaded: application/views/common/footer.php
DEBUG - 2011-06-17 10:57:57 --> File loaded: application/views/layout/main.php
DEBUG - 2011-06-17 10:57:57 --> Final output sent to browser
DEBUG - 2011-06-17 10:57:57 --> Total execution time: 0.2725
DEBUG - 2011-06-17 10:57:59 --> Config Class Initialized
DEBUG - 2011-06-17 10:57:59 --> Hooks Class Initialized
DEBUG - 2011-06-17 10:57:59 --> Utf8 Class Initialized
DEBUG - 2011-06-17 10:57:59 --> UTF-8 Support Enabled
DEBUG - 2011-06-17 10:57:59 --> URI Class Initialized
DEBUG - 2011-06-17 10:57:59 --> Router Class Initialized
ERROR - 2011-06-17 10:57:59 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-06-17 10:58:08 --> Config Class Initialized
DEBUG - 2011-06-17 10:58:08 --> Hooks Class Initialized
DEBUG - 2011-06-17 10:58:08 --> Utf8 Class Initialized
DEBUG - 2011-06-17 10:58:08 --> UTF-8 Support Enabled
DEBUG - 2011-06-17 10:58:08 --> URI Class Initialized
DEBUG - 2011-06-17 10:58:08 --> Router Class Initialized
DEBUG - 2011-06-17 10:58:08 --> Output Class Initialized
DEBUG - 2011-06-17 10:58:08 --> Input Class Initialized
DEBUG - 2011-06-17 10:58:08 --> Global POST and COOKIE data sanitized
DEBUG - 2011-06-17 10:58:08 --> Language Class Initialized
DEBUG - 2011-06-17 10:58:08 --> Loader Class Initialized
DEBUG - 2011-06-17 10:58:08 --> Controller Class Initialized
DEBUG - 2011-06-17 10:58:08 --> Model Class Initialized
DEBUG - 2011-06-17 10:58:08 --> Model Class Initialized
DEBUG - 2011-06-17 10:58:08 --> Model Class Initialized
DEBUG - 2011-06-17 10:58:08 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-06-17 10:58:08 --> Database Driver Class Initialized
DEBUG - 2011-06-17 10:58:09 --> File loaded: application/views/table/main.php
DEBUG - 2011-06-17 10:58:09 --> Helper loaded: url_helper
DEBUG - 2011-06-17 10:58:09 --> File loaded: application/views/common/header.php
DEBUG - 2011-06-17 10:58:09 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-06-17 10:58:09 --> File loaded: application/views/common/footer.php
DEBUG - 2011-06-17 10:58:09 --> File loaded: application/views/layout/main.php
DEBUG - 2011-06-17 10:58:09 --> Final output sent to browser
DEBUG - 2011-06-17 10:58:09 --> Total execution time: 0.3216
DEBUG - 2011-06-17 10:58:11 --> Config Class Initialized
DEBUG - 2011-06-17 10:58:11 --> Hooks Class Initialized
DEBUG - 2011-06-17 10:58:11 --> Utf8 Class Initialized
DEBUG - 2011-06-17 10:58:11 --> UTF-8 Support Enabled
DEBUG - 2011-06-17 10:58:11 --> URI Class Initialized
DEBUG - 2011-06-17 10:58:11 --> Router Class Initialized
ERROR - 2011-06-17 10:58:11 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-06-17 10:58:15 --> Config Class Initialized
DEBUG - 2011-06-17 10:58:15 --> Hooks Class Initialized
DEBUG - 2011-06-17 10:58:15 --> Utf8 Class Initialized
DEBUG - 2011-06-17 10:58:15 --> UTF-8 Support Enabled
DEBUG - 2011-06-17 10:58:15 --> URI Class Initialized
DEBUG - 2011-06-17 10:58:15 --> Router Class Initialized
DEBUG - 2011-06-17 10:58:15 --> Output Class Initialized
DEBUG - 2011-06-17 10:58:15 --> Input Class Initialized
DEBUG - 2011-06-17 10:58:15 --> Global POST and COOKIE data sanitized
DEBUG - 2011-06-17 10:58:15 --> Language Class Initialized
DEBUG - 2011-06-17 10:58:15 --> Loader Class Initialized
DEBUG - 2011-06-17 10:58:15 --> Controller Class Initialized
DEBUG - 2011-06-17 10:58:15 --> Model Class Initialized
DEBUG - 2011-06-17 10:58:15 --> Model Class Initialized
DEBUG - 2011-06-17 10:58:15 --> Model Class Initialized
DEBUG - 2011-06-17 10:58:15 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-06-17 10:58:15 --> Database Driver Class Initialized
DEBUG - 2011-06-17 10:58:15 --> File loaded: application/views/table/main.php
DEBUG - 2011-06-17 10:58:15 --> Helper loaded: url_helper
DEBUG - 2011-06-17 10:58:15 --> File loaded: application/views/common/header.php
DEBUG - 2011-06-17 10:58:15 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-06-17 10:58:15 --> File loaded: application/views/common/footer.php
DEBUG - 2011-06-17 10:58:15 --> File loaded: application/views/layout/main.php
DEBUG - 2011-06-17 10:58:15 --> Final output sent to browser
DEBUG - 2011-06-17 10:58:15 --> Total execution time: 0.0685
DEBUG - 2011-06-17 10:58:18 --> Config Class Initialized
DEBUG - 2011-06-17 10:58:18 --> Hooks Class Initialized
DEBUG - 2011-06-17 10:58:18 --> Utf8 Class Initialized
DEBUG - 2011-06-17 10:58:18 --> UTF-8 Support Enabled
DEBUG - 2011-06-17 10:58:18 --> URI Class Initialized
DEBUG - 2011-06-17 10:58:18 --> Router Class Initialized
DEBUG - 2011-06-17 10:58:18 --> Output Class Initialized
DEBUG - 2011-06-17 10:58:18 --> Input Class Initialized
DEBUG - 2011-06-17 10:58:18 --> Global POST and COOKIE data sanitized
DEBUG - 2011-06-17 10:58:18 --> Language Class Initialized
DEBUG - 2011-06-17 10:58:18 --> Loader Class Initialized
DEBUG - 2011-06-17 10:58:18 --> Controller Class Initialized
DEBUG - 2011-06-17 10:58:18 --> Model Class Initialized
DEBUG - 2011-06-17 10:58:18 --> Model Class Initialized
DEBUG - 2011-06-17 10:58:18 --> Model Class Initialized
DEBUG - 2011-06-17 10:58:18 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-06-17 10:58:18 --> Database Driver Class Initialized
DEBUG - 2011-06-17 10:58:19 --> File loaded: application/views/table/main.php
DEBUG - 2011-06-17 10:58:19 --> Helper loaded: url_helper
DEBUG - 2011-06-17 10:58:19 --> File loaded: application/views/common/header.php
DEBUG - 2011-06-17 10:58:19 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-06-17 10:58:19 --> File loaded: application/views/common/footer.php
DEBUG - 2011-06-17 10:58:19 --> File loaded: application/views/layout/main.php
DEBUG - 2011-06-17 10:58:19 --> Final output sent to browser
DEBUG - 2011-06-17 10:58:19 --> Total execution time: 0.2741
DEBUG - 2011-06-17 10:58:20 --> Config Class Initialized
DEBUG - 2011-06-17 10:58:20 --> Hooks Class Initialized
DEBUG - 2011-06-17 10:58:20 --> Utf8 Class Initialized
DEBUG - 2011-06-17 10:58:20 --> UTF-8 Support Enabled
DEBUG - 2011-06-17 10:58:20 --> URI Class Initialized
DEBUG - 2011-06-17 10:58:20 --> Router Class Initialized
DEBUG - 2011-06-17 10:58:20 --> Output Class Initialized
DEBUG - 2011-06-17 10:58:20 --> Input Class Initialized
DEBUG - 2011-06-17 10:58:20 --> Global POST and COOKIE data sanitized
DEBUG - 2011-06-17 10:58:20 --> Language Class Initialized
DEBUG - 2011-06-17 10:58:20 --> Loader Class Initialized
DEBUG - 2011-06-17 10:58:20 --> Controller Class Initialized
DEBUG - 2011-06-17 10:58:20 --> Model Class Initialized
DEBUG - 2011-06-17 10:58:20 --> Model Class Initialized
DEBUG - 2011-06-17 10:58:20 --> Model Class Initialized
DEBUG - 2011-06-17 10:58:20 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-06-17 10:58:20 --> Database Driver Class Initialized
DEBUG - 2011-06-17 10:58:20 --> File loaded: application/views/table/main.php
DEBUG - 2011-06-17 10:58:20 --> Helper loaded: url_helper
DEBUG - 2011-06-17 10:58:20 --> File loaded: application/views/common/header.php
DEBUG - 2011-06-17 10:58:20 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-06-17 10:58:20 --> File loaded: application/views/common/footer.php
DEBUG - 2011-06-17 10:58:20 --> File loaded: application/views/layout/main.php
DEBUG - 2011-06-17 10:58:20 --> Final output sent to browser
DEBUG - 2011-06-17 10:58:20 --> Total execution time: 0.0446
DEBUG - 2011-06-17 10:58:21 --> Config Class Initialized
DEBUG - 2011-06-17 10:58:21 --> Hooks Class Initialized
DEBUG - 2011-06-17 10:58:21 --> Utf8 Class Initialized
DEBUG - 2011-06-17 10:58:21 --> UTF-8 Support Enabled
DEBUG - 2011-06-17 10:58:21 --> URI Class Initialized
DEBUG - 2011-06-17 10:58:21 --> Router Class Initialized
ERROR - 2011-06-17 10:58:21 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-06-17 10:58:22 --> Config Class Initialized
DEBUG - 2011-06-17 10:58:22 --> Hooks Class Initialized
DEBUG - 2011-06-17 10:58:22 --> Utf8 Class Initialized
DEBUG - 2011-06-17 10:58:22 --> UTF-8 Support Enabled
DEBUG - 2011-06-17 10:58:22 --> URI Class Initialized
DEBUG - 2011-06-17 10:58:22 --> Router Class Initialized
DEBUG - 2011-06-17 10:58:22 --> Output Class Initialized
DEBUG - 2011-06-17 10:58:22 --> Input Class Initialized
DEBUG - 2011-06-17 10:58:22 --> Global POST and COOKIE data sanitized
DEBUG - 2011-06-17 10:58:22 --> Language Class Initialized
DEBUG - 2011-06-17 10:58:22 --> Loader Class Initialized
DEBUG - 2011-06-17 10:58:22 --> Controller Class Initialized
DEBUG - 2011-06-17 10:58:22 --> Model Class Initialized
DEBUG - 2011-06-17 10:58:22 --> Model Class Initialized
DEBUG - 2011-06-17 10:58:22 --> Model Class Initialized
DEBUG - 2011-06-17 10:58:22 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-06-17 10:58:22 --> Database Driver Class Initialized
DEBUG - 2011-06-17 10:58:23 --> File loaded: application/views/table/main.php
DEBUG - 2011-06-17 10:58:23 --> Helper loaded: url_helper
DEBUG - 2011-06-17 10:58:23 --> File loaded: application/views/common/header.php
DEBUG - 2011-06-17 10:58:23 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-06-17 10:58:23 --> File loaded: application/views/common/footer.php
DEBUG - 2011-06-17 10:58:23 --> File loaded: application/views/layout/main.php
DEBUG - 2011-06-17 10:58:23 --> Final output sent to browser
DEBUG - 2011-06-17 10:58:23 --> Total execution time: 0.0932
DEBUG - 2011-06-17 10:58:23 --> Config Class Initialized
DEBUG - 2011-06-17 10:58:23 --> Hooks Class Initialized
DEBUG - 2011-06-17 10:58:23 --> Utf8 Class Initialized
DEBUG - 2011-06-17 10:58:23 --> UTF-8 Support Enabled
DEBUG - 2011-06-17 10:58:23 --> URI Class Initialized
DEBUG - 2011-06-17 10:58:23 --> Router Class Initialized
DEBUG - 2011-06-17 10:58:23 --> Output Class Initialized
DEBUG - 2011-06-17 10:58:23 --> Input Class Initialized
DEBUG - 2011-06-17 10:58:23 --> Global POST and COOKIE data sanitized
DEBUG - 2011-06-17 10:58:23 --> Language Class Initialized
DEBUG - 2011-06-17 10:58:23 --> Loader Class Initialized
DEBUG - 2011-06-17 10:58:23 --> Controller Class Initialized
DEBUG - 2011-06-17 10:58:23 --> Model Class Initialized
DEBUG - 2011-06-17 10:58:23 --> Model Class Initialized
DEBUG - 2011-06-17 10:58:24 --> Model Class Initialized
DEBUG - 2011-06-17 10:58:24 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-06-17 10:58:24 --> Database Driver Class Initialized
DEBUG - 2011-06-17 10:58:24 --> File loaded: application/views/table/main.php
DEBUG - 2011-06-17 10:58:24 --> Helper loaded: url_helper
DEBUG - 2011-06-17 10:58:24 --> File loaded: application/views/common/header.php
DEBUG - 2011-06-17 10:58:24 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-06-17 10:58:24 --> File loaded: application/views/common/footer.php
DEBUG - 2011-06-17 10:58:24 --> File loaded: application/views/layout/main.php
DEBUG - 2011-06-17 10:58:24 --> Final output sent to browser
DEBUG - 2011-06-17 10:58:24 --> Total execution time: 0.0443
DEBUG - 2011-06-17 10:58:24 --> Config Class Initialized
DEBUG - 2011-06-17 10:58:24 --> Hooks Class Initialized
DEBUG - 2011-06-17 10:58:24 --> Utf8 Class Initialized
DEBUG - 2011-06-17 10:58:24 --> UTF-8 Support Enabled
DEBUG - 2011-06-17 10:58:24 --> URI Class Initialized
DEBUG - 2011-06-17 10:58:24 --> Router Class Initialized
DEBUG - 2011-06-17 10:58:24 --> Output Class Initialized
DEBUG - 2011-06-17 10:58:24 --> Input Class Initialized
DEBUG - 2011-06-17 10:58:24 --> Global POST and COOKIE data sanitized
DEBUG - 2011-06-17 10:58:24 --> Language Class Initialized
DEBUG - 2011-06-17 10:58:24 --> Loader Class Initialized
DEBUG - 2011-06-17 10:58:24 --> Controller Class Initialized
DEBUG - 2011-06-17 10:58:24 --> Model Class Initialized
DEBUG - 2011-06-17 10:58:24 --> Model Class Initialized
DEBUG - 2011-06-17 10:58:24 --> Model Class Initialized
DEBUG - 2011-06-17 10:58:24 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-06-17 10:58:24 --> Database Driver Class Initialized
DEBUG - 2011-06-17 10:58:24 --> File loaded: application/views/table/main.php
DEBUG - 2011-06-17 10:58:24 --> Helper loaded: url_helper
DEBUG - 2011-06-17 10:58:24 --> File loaded: application/views/common/header.php
DEBUG - 2011-06-17 10:58:24 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-06-17 10:58:24 --> File loaded: application/views/common/footer.php
DEBUG - 2011-06-17 10:58:24 --> File loaded: application/views/layout/main.php
DEBUG - 2011-06-17 10:58:24 --> Final output sent to browser
DEBUG - 2011-06-17 10:58:24 --> Total execution time: 0.0538
DEBUG - 2011-06-17 10:58:26 --> Config Class Initialized
DEBUG - 2011-06-17 10:58:26 --> Hooks Class Initialized
DEBUG - 2011-06-17 10:58:26 --> Utf8 Class Initialized
DEBUG - 2011-06-17 10:58:26 --> UTF-8 Support Enabled
DEBUG - 2011-06-17 10:58:26 --> URI Class Initialized
DEBUG - 2011-06-17 10:58:26 --> Router Class Initialized
DEBUG - 2011-06-17 10:58:26 --> Output Class Initialized
DEBUG - 2011-06-17 10:58:26 --> Input Class Initialized
DEBUG - 2011-06-17 10:58:26 --> Global POST and COOKIE data sanitized
DEBUG - 2011-06-17 10:58:26 --> Language Class Initialized
DEBUG - 2011-06-17 10:58:26 --> Loader Class Initialized
DEBUG - 2011-06-17 10:58:26 --> Controller Class Initialized
DEBUG - 2011-06-17 10:58:26 --> Model Class Initialized
DEBUG - 2011-06-17 10:58:26 --> Model Class Initialized
DEBUG - 2011-06-17 10:58:26 --> Model Class Initialized
DEBUG - 2011-06-17 10:58:26 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-06-17 10:58:26 --> Database Driver Class Initialized
DEBUG - 2011-06-17 10:58:26 --> File loaded: application/views/table/main.php
DEBUG - 2011-06-17 10:58:26 --> Helper loaded: url_helper
DEBUG - 2011-06-17 10:58:26 --> File loaded: application/views/common/header.php
DEBUG - 2011-06-17 10:58:26 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-06-17 10:58:26 --> File loaded: application/views/common/footer.php
DEBUG - 2011-06-17 10:58:26 --> File loaded: application/views/layout/main.php
DEBUG - 2011-06-17 10:58:26 --> Final output sent to browser
DEBUG - 2011-06-17 10:58:26 --> Total execution time: 0.2804
DEBUG - 2011-06-17 10:58:26 --> Config Class Initialized
DEBUG - 2011-06-17 10:58:26 --> Hooks Class Initialized
DEBUG - 2011-06-17 10:58:26 --> Utf8 Class Initialized
DEBUG - 2011-06-17 10:58:26 --> UTF-8 Support Enabled
DEBUG - 2011-06-17 10:58:26 --> URI Class Initialized
DEBUG - 2011-06-17 10:58:26 --> Router Class Initialized
DEBUG - 2011-06-17 10:58:26 --> Output Class Initialized
DEBUG - 2011-06-17 10:58:26 --> Input Class Initialized
DEBUG - 2011-06-17 10:58:26 --> Global POST and COOKIE data sanitized
DEBUG - 2011-06-17 10:58:26 --> Language Class Initialized
DEBUG - 2011-06-17 10:58:26 --> Loader Class Initialized
DEBUG - 2011-06-17 10:58:26 --> Controller Class Initialized
DEBUG - 2011-06-17 10:58:26 --> Model Class Initialized
DEBUG - 2011-06-17 10:58:26 --> Model Class Initialized
DEBUG - 2011-06-17 10:58:26 --> Model Class Initialized
DEBUG - 2011-06-17 10:58:26 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-06-17 10:58:26 --> Database Driver Class Initialized
DEBUG - 2011-06-17 10:58:26 --> File loaded: application/views/table/main.php
DEBUG - 2011-06-17 10:58:26 --> Helper loaded: url_helper
DEBUG - 2011-06-17 10:58:26 --> File loaded: application/views/common/header.php
DEBUG - 2011-06-17 10:58:26 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-06-17 10:58:26 --> File loaded: application/views/common/footer.php
DEBUG - 2011-06-17 10:58:26 --> File loaded: application/views/layout/main.php
DEBUG - 2011-06-17 10:58:26 --> Final output sent to browser
DEBUG - 2011-06-17 10:58:26 --> Total execution time: 0.0507
DEBUG - 2011-06-17 10:58:27 --> Config Class Initialized
DEBUG - 2011-06-17 10:58:27 --> Hooks Class Initialized
DEBUG - 2011-06-17 10:58:27 --> Utf8 Class Initialized
DEBUG - 2011-06-17 10:58:27 --> UTF-8 Support Enabled
DEBUG - 2011-06-17 10:58:27 --> URI Class Initialized
DEBUG - 2011-06-17 10:58:27 --> Router Class Initialized
DEBUG - 2011-06-17 10:58:27 --> Output Class Initialized
DEBUG - 2011-06-17 10:58:27 --> Input Class Initialized
DEBUG - 2011-06-17 10:58:27 --> Global POST and COOKIE data sanitized
DEBUG - 2011-06-17 10:58:27 --> Language Class Initialized
DEBUG - 2011-06-17 10:58:27 --> Loader Class Initialized
DEBUG - 2011-06-17 10:58:27 --> Controller Class Initialized
DEBUG - 2011-06-17 10:58:27 --> Model Class Initialized
DEBUG - 2011-06-17 10:58:27 --> Model Class Initialized
DEBUG - 2011-06-17 10:58:27 --> Model Class Initialized
DEBUG - 2011-06-17 10:58:27 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-06-17 10:58:27 --> Database Driver Class Initialized
DEBUG - 2011-06-17 10:58:28 --> File loaded: application/views/table/main.php
DEBUG - 2011-06-17 10:58:28 --> Helper loaded: url_helper
DEBUG - 2011-06-17 10:58:28 --> File loaded: application/views/common/header.php
DEBUG - 2011-06-17 10:58:28 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-06-17 10:58:28 --> File loaded: application/views/common/footer.php
DEBUG - 2011-06-17 10:58:28 --> File loaded: application/views/layout/main.php
DEBUG - 2011-06-17 10:58:28 --> Final output sent to browser
DEBUG - 2011-06-17 10:58:28 --> Total execution time: 0.0525
DEBUG - 2011-06-17 10:58:28 --> Config Class Initialized
DEBUG - 2011-06-17 10:58:28 --> Hooks Class Initialized
DEBUG - 2011-06-17 10:58:28 --> Utf8 Class Initialized
DEBUG - 2011-06-17 10:58:28 --> UTF-8 Support Enabled
DEBUG - 2011-06-17 10:58:28 --> URI Class Initialized
DEBUG - 2011-06-17 10:58:28 --> Router Class Initialized
ERROR - 2011-06-17 10:58:28 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-06-17 10:58:42 --> Config Class Initialized
DEBUG - 2011-06-17 10:58:42 --> Hooks Class Initialized
DEBUG - 2011-06-17 10:58:42 --> Utf8 Class Initialized
DEBUG - 2011-06-17 10:58:42 --> UTF-8 Support Enabled
DEBUG - 2011-06-17 10:58:42 --> URI Class Initialized
DEBUG - 2011-06-17 10:58:42 --> Router Class Initialized
DEBUG - 2011-06-17 10:58:42 --> Output Class Initialized
DEBUG - 2011-06-17 10:58:42 --> Input Class Initialized
DEBUG - 2011-06-17 10:58:42 --> Global POST and COOKIE data sanitized
DEBUG - 2011-06-17 10:58:42 --> Language Class Initialized
DEBUG - 2011-06-17 10:58:42 --> Loader Class Initialized
DEBUG - 2011-06-17 10:58:42 --> Controller Class Initialized
DEBUG - 2011-06-17 10:58:42 --> Model Class Initialized
DEBUG - 2011-06-17 10:58:42 --> Model Class Initialized
DEBUG - 2011-06-17 10:58:42 --> Model Class Initialized
DEBUG - 2011-06-17 10:58:42 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-06-17 10:58:42 --> Database Driver Class Initialized
DEBUG - 2011-06-17 10:58:43 --> File loaded: application/views/table/main.php
DEBUG - 2011-06-17 10:58:43 --> Helper loaded: url_helper
DEBUG - 2011-06-17 10:58:43 --> File loaded: application/views/common/header.php
DEBUG - 2011-06-17 10:58:43 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-06-17 10:58:43 --> File loaded: application/views/common/footer.php
DEBUG - 2011-06-17 10:58:43 --> File loaded: application/views/layout/main.php
DEBUG - 2011-06-17 10:58:43 --> Final output sent to browser
DEBUG - 2011-06-17 10:58:43 --> Total execution time: 0.5284
DEBUG - 2011-06-17 10:58:44 --> Config Class Initialized
DEBUG - 2011-06-17 10:58:44 --> Hooks Class Initialized
DEBUG - 2011-06-17 10:58:44 --> Utf8 Class Initialized
DEBUG - 2011-06-17 10:58:44 --> UTF-8 Support Enabled
DEBUG - 2011-06-17 10:58:44 --> URI Class Initialized
DEBUG - 2011-06-17 10:58:44 --> Router Class Initialized
DEBUG - 2011-06-17 10:58:44 --> Output Class Initialized
DEBUG - 2011-06-17 10:58:44 --> Input Class Initialized
DEBUG - 2011-06-17 10:58:44 --> Global POST and COOKIE data sanitized
DEBUG - 2011-06-17 10:58:44 --> Language Class Initialized
DEBUG - 2011-06-17 10:58:44 --> Loader Class Initialized
DEBUG - 2011-06-17 10:58:44 --> Controller Class Initialized
DEBUG - 2011-06-17 10:58:44 --> Model Class Initialized
DEBUG - 2011-06-17 10:58:44 --> Model Class Initialized
DEBUG - 2011-06-17 10:58:44 --> Model Class Initialized
DEBUG - 2011-06-17 10:58:44 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-06-17 10:58:44 --> Database Driver Class Initialized
DEBUG - 2011-06-17 10:58:44 --> File loaded: application/views/table/main.php
DEBUG - 2011-06-17 10:58:44 --> Helper loaded: url_helper
DEBUG - 2011-06-17 10:58:44 --> File loaded: application/views/common/header.php
DEBUG - 2011-06-17 10:58:44 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-06-17 10:58:44 --> File loaded: application/views/common/footer.php
DEBUG - 2011-06-17 10:58:44 --> File loaded: application/views/layout/main.php
DEBUG - 2011-06-17 10:58:44 --> Final output sent to browser
DEBUG - 2011-06-17 10:58:44 --> Total execution time: 0.0447
DEBUG - 2011-06-17 10:58:45 --> Config Class Initialized
DEBUG - 2011-06-17 10:58:45 --> Hooks Class Initialized
DEBUG - 2011-06-17 10:58:45 --> Utf8 Class Initialized
DEBUG - 2011-06-17 10:58:45 --> UTF-8 Support Enabled
DEBUG - 2011-06-17 10:58:45 --> URI Class Initialized
DEBUG - 2011-06-17 10:58:45 --> Router Class Initialized
ERROR - 2011-06-17 10:58:45 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-06-17 11:00:22 --> Config Class Initialized
DEBUG - 2011-06-17 11:00:22 --> Hooks Class Initialized
DEBUG - 2011-06-17 11:00:22 --> Utf8 Class Initialized
DEBUG - 2011-06-17 11:00:22 --> UTF-8 Support Enabled
DEBUG - 2011-06-17 11:00:22 --> URI Class Initialized
DEBUG - 2011-06-17 11:00:22 --> Router Class Initialized
DEBUG - 2011-06-17 11:00:22 --> Output Class Initialized
DEBUG - 2011-06-17 11:00:22 --> Input Class Initialized
DEBUG - 2011-06-17 11:00:22 --> Global POST and COOKIE data sanitized
DEBUG - 2011-06-17 11:00:22 --> Language Class Initialized
DEBUG - 2011-06-17 11:00:22 --> Loader Class Initialized
DEBUG - 2011-06-17 11:00:22 --> Controller Class Initialized
DEBUG - 2011-06-17 11:00:22 --> Model Class Initialized
DEBUG - 2011-06-17 11:00:22 --> Model Class Initialized
DEBUG - 2011-06-17 11:00:22 --> Model Class Initialized
DEBUG - 2011-06-17 11:00:22 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-06-17 11:00:22 --> Database Driver Class Initialized
DEBUG - 2011-06-17 11:00:23 --> File loaded: application/views/table/main.php
DEBUG - 2011-06-17 11:00:23 --> Helper loaded: url_helper
DEBUG - 2011-06-17 11:00:23 --> File loaded: application/views/common/header.php
DEBUG - 2011-06-17 11:00:23 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-06-17 11:00:23 --> File loaded: application/views/common/footer.php
DEBUG - 2011-06-17 11:00:23 --> File loaded: application/views/layout/main.php
DEBUG - 2011-06-17 11:00:23 --> Final output sent to browser
DEBUG - 2011-06-17 11:00:23 --> Total execution time: 0.4375
DEBUG - 2011-06-17 11:00:24 --> Config Class Initialized
DEBUG - 2011-06-17 11:00:24 --> Hooks Class Initialized
DEBUG - 2011-06-17 11:00:24 --> Utf8 Class Initialized
DEBUG - 2011-06-17 11:00:24 --> UTF-8 Support Enabled
DEBUG - 2011-06-17 11:00:24 --> URI Class Initialized
DEBUG - 2011-06-17 11:00:24 --> Router Class Initialized
DEBUG - 2011-06-17 11:00:24 --> Output Class Initialized
DEBUG - 2011-06-17 11:00:24 --> Input Class Initialized
DEBUG - 2011-06-17 11:00:24 --> Global POST and COOKIE data sanitized
DEBUG - 2011-06-17 11:00:24 --> Language Class Initialized
DEBUG - 2011-06-17 11:00:24 --> Loader Class Initialized
DEBUG - 2011-06-17 11:00:24 --> Controller Class Initialized
DEBUG - 2011-06-17 11:00:24 --> Model Class Initialized
DEBUG - 2011-06-17 11:00:24 --> Model Class Initialized
DEBUG - 2011-06-17 11:00:24 --> Model Class Initialized
DEBUG - 2011-06-17 11:00:24 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-06-17 11:00:24 --> Database Driver Class Initialized
DEBUG - 2011-06-17 11:00:24 --> File loaded: application/views/table/main.php
DEBUG - 2011-06-17 11:00:24 --> Helper loaded: url_helper
DEBUG - 2011-06-17 11:00:24 --> File loaded: application/views/common/header.php
DEBUG - 2011-06-17 11:00:24 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-06-17 11:00:24 --> File loaded: application/views/common/footer.php
DEBUG - 2011-06-17 11:00:24 --> File loaded: application/views/layout/main.php
DEBUG - 2011-06-17 11:00:24 --> Final output sent to browser
DEBUG - 2011-06-17 11:00:24 --> Total execution time: 0.0830
DEBUG - 2011-06-17 11:00:24 --> Config Class Initialized
DEBUG - 2011-06-17 11:00:24 --> Hooks Class Initialized
DEBUG - 2011-06-17 11:00:24 --> Utf8 Class Initialized
DEBUG - 2011-06-17 11:00:24 --> UTF-8 Support Enabled
DEBUG - 2011-06-17 11:00:24 --> URI Class Initialized
DEBUG - 2011-06-17 11:00:24 --> Router Class Initialized
DEBUG - 2011-06-17 11:00:24 --> Output Class Initialized
DEBUG - 2011-06-17 11:00:24 --> Input Class Initialized
DEBUG - 2011-06-17 11:00:24 --> Global POST and COOKIE data sanitized
DEBUG - 2011-06-17 11:00:24 --> Language Class Initialized
DEBUG - 2011-06-17 11:00:24 --> Loader Class Initialized
DEBUG - 2011-06-17 11:00:24 --> Controller Class Initialized
DEBUG - 2011-06-17 11:00:24 --> Model Class Initialized
DEBUG - 2011-06-17 11:00:24 --> Model Class Initialized
DEBUG - 2011-06-17 11:00:24 --> Model Class Initialized
DEBUG - 2011-06-17 11:00:24 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-06-17 11:00:24 --> Database Driver Class Initialized
DEBUG - 2011-06-17 11:00:24 --> File loaded: application/views/table/main.php
DEBUG - 2011-06-17 11:00:24 --> Helper loaded: url_helper
DEBUG - 2011-06-17 11:00:24 --> File loaded: application/views/common/header.php
DEBUG - 2011-06-17 11:00:24 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-06-17 11:00:24 --> File loaded: application/views/common/footer.php
DEBUG - 2011-06-17 11:00:24 --> File loaded: application/views/layout/main.php
DEBUG - 2011-06-17 11:00:24 --> Final output sent to browser
DEBUG - 2011-06-17 11:00:24 --> Total execution time: 0.0619
DEBUG - 2011-06-17 11:00:26 --> Config Class Initialized
DEBUG - 2011-06-17 11:00:26 --> Hooks Class Initialized
DEBUG - 2011-06-17 11:00:26 --> Utf8 Class Initialized
DEBUG - 2011-06-17 11:00:26 --> UTF-8 Support Enabled
DEBUG - 2011-06-17 11:00:26 --> URI Class Initialized
DEBUG - 2011-06-17 11:00:26 --> Router Class Initialized
ERROR - 2011-06-17 11:00:26 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-06-17 11:00:46 --> Config Class Initialized
DEBUG - 2011-06-17 11:00:46 --> Hooks Class Initialized
DEBUG - 2011-06-17 11:00:46 --> Utf8 Class Initialized
DEBUG - 2011-06-17 11:00:46 --> UTF-8 Support Enabled
DEBUG - 2011-06-17 11:00:46 --> URI Class Initialized
DEBUG - 2011-06-17 11:00:46 --> Router Class Initialized
DEBUG - 2011-06-17 11:00:46 --> Output Class Initialized
DEBUG - 2011-06-17 11:00:46 --> Input Class Initialized
DEBUG - 2011-06-17 11:00:46 --> Global POST and COOKIE data sanitized
DEBUG - 2011-06-17 11:00:46 --> Language Class Initialized
DEBUG - 2011-06-17 11:00:46 --> Loader Class Initialized
DEBUG - 2011-06-17 11:00:46 --> Controller Class Initialized
DEBUG - 2011-06-17 11:00:46 --> Model Class Initialized
DEBUG - 2011-06-17 11:00:46 --> Model Class Initialized
DEBUG - 2011-06-17 11:00:46 --> Model Class Initialized
DEBUG - 2011-06-17 11:00:46 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-06-17 11:00:46 --> Database Driver Class Initialized
DEBUG - 2011-06-17 11:00:46 --> File loaded: application/views/table/main.php
DEBUG - 2011-06-17 11:00:46 --> Helper loaded: url_helper
DEBUG - 2011-06-17 11:00:46 --> File loaded: application/views/common/header.php
DEBUG - 2011-06-17 11:00:46 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-06-17 11:00:46 --> File loaded: application/views/common/footer.php
DEBUG - 2011-06-17 11:00:46 --> File loaded: application/views/layout/main.php
DEBUG - 2011-06-17 11:00:46 --> Final output sent to browser
DEBUG - 2011-06-17 11:00:46 --> Total execution time: 0.5133
DEBUG - 2011-06-17 11:00:53 --> Config Class Initialized
DEBUG - 2011-06-17 11:00:53 --> Hooks Class Initialized
DEBUG - 2011-06-17 11:00:53 --> Utf8 Class Initialized
DEBUG - 2011-06-17 11:00:53 --> UTF-8 Support Enabled
DEBUG - 2011-06-17 11:00:53 --> URI Class Initialized
DEBUG - 2011-06-17 11:00:53 --> Router Class Initialized
ERROR - 2011-06-17 11:00:53 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-06-17 11:00:53 --> Config Class Initialized
DEBUG - 2011-06-17 11:00:53 --> Hooks Class Initialized
DEBUG - 2011-06-17 11:00:53 --> Utf8 Class Initialized
DEBUG - 2011-06-17 11:00:53 --> UTF-8 Support Enabled
DEBUG - 2011-06-17 11:00:53 --> URI Class Initialized
DEBUG - 2011-06-17 11:00:53 --> Router Class Initialized
DEBUG - 2011-06-17 11:00:53 --> Output Class Initialized
DEBUG - 2011-06-17 11:00:53 --> Input Class Initialized
DEBUG - 2011-06-17 11:00:53 --> Global POST and COOKIE data sanitized
DEBUG - 2011-06-17 11:00:53 --> Language Class Initialized
DEBUG - 2011-06-17 11:00:53 --> Loader Class Initialized
DEBUG - 2011-06-17 11:00:53 --> Controller Class Initialized
DEBUG - 2011-06-17 11:00:53 --> Model Class Initialized
DEBUG - 2011-06-17 11:00:53 --> Model Class Initialized
DEBUG - 2011-06-17 11:00:53 --> Model Class Initialized
DEBUG - 2011-06-17 11:00:53 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-06-17 11:00:53 --> Database Driver Class Initialized
DEBUG - 2011-06-17 11:00:53 --> File loaded: application/views/table/main.php
DEBUG - 2011-06-17 11:00:53 --> Helper loaded: url_helper
DEBUG - 2011-06-17 11:00:53 --> File loaded: application/views/common/header.php
DEBUG - 2011-06-17 11:00:53 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-06-17 11:00:53 --> File loaded: application/views/common/footer.php
DEBUG - 2011-06-17 11:00:53 --> File loaded: application/views/layout/main.php
DEBUG - 2011-06-17 11:00:53 --> Final output sent to browser
DEBUG - 2011-06-17 11:00:53 --> Total execution time: 0.0459
DEBUG - 2011-06-17 11:01:17 --> Config Class Initialized
DEBUG - 2011-06-17 11:01:17 --> Hooks Class Initialized
DEBUG - 2011-06-17 11:01:17 --> Utf8 Class Initialized
DEBUG - 2011-06-17 11:01:17 --> UTF-8 Support Enabled
DEBUG - 2011-06-17 11:01:17 --> URI Class Initialized
DEBUG - 2011-06-17 11:01:17 --> Router Class Initialized
DEBUG - 2011-06-17 11:01:17 --> Output Class Initialized
DEBUG - 2011-06-17 11:01:17 --> Input Class Initialized
DEBUG - 2011-06-17 11:01:17 --> Global POST and COOKIE data sanitized
DEBUG - 2011-06-17 11:01:17 --> Language Class Initialized
DEBUG - 2011-06-17 11:01:17 --> Loader Class Initialized
DEBUG - 2011-06-17 11:01:17 --> Controller Class Initialized
DEBUG - 2011-06-17 11:01:17 --> Model Class Initialized
DEBUG - 2011-06-17 11:01:17 --> Model Class Initialized
DEBUG - 2011-06-17 11:01:17 --> Model Class Initialized
DEBUG - 2011-06-17 11:01:17 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-06-17 11:01:17 --> Database Driver Class Initialized
DEBUG - 2011-06-17 11:01:17 --> File loaded: application/views/table/main.php
DEBUG - 2011-06-17 11:01:17 --> Helper loaded: url_helper
DEBUG - 2011-06-17 11:01:17 --> File loaded: application/views/common/header.php
DEBUG - 2011-06-17 11:01:17 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-06-17 11:01:17 --> File loaded: application/views/common/footer.php
DEBUG - 2011-06-17 11:01:17 --> File loaded: application/views/layout/main.php
DEBUG - 2011-06-17 11:01:17 --> Final output sent to browser
DEBUG - 2011-06-17 11:01:17 --> Total execution time: 0.2707
DEBUG - 2011-06-17 11:01:20 --> Config Class Initialized
DEBUG - 2011-06-17 11:01:20 --> Hooks Class Initialized
DEBUG - 2011-06-17 11:01:20 --> Utf8 Class Initialized
DEBUG - 2011-06-17 11:01:20 --> UTF-8 Support Enabled
DEBUG - 2011-06-17 11:01:20 --> URI Class Initialized
DEBUG - 2011-06-17 11:01:20 --> Router Class Initialized
ERROR - 2011-06-17 11:01:20 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-06-17 11:01:24 --> Config Class Initialized
DEBUG - 2011-06-17 11:01:24 --> Hooks Class Initialized
DEBUG - 2011-06-17 11:01:24 --> Utf8 Class Initialized
DEBUG - 2011-06-17 11:01:24 --> UTF-8 Support Enabled
DEBUG - 2011-06-17 11:01:24 --> URI Class Initialized
DEBUG - 2011-06-17 11:01:24 --> Router Class Initialized
DEBUG - 2011-06-17 11:01:24 --> Output Class Initialized
DEBUG - 2011-06-17 11:01:24 --> Input Class Initialized
DEBUG - 2011-06-17 11:01:24 --> Global POST and COOKIE data sanitized
DEBUG - 2011-06-17 11:01:24 --> Language Class Initialized
DEBUG - 2011-06-17 11:01:24 --> Loader Class Initialized
DEBUG - 2011-06-17 11:01:24 --> Controller Class Initialized
DEBUG - 2011-06-17 11:01:24 --> Model Class Initialized
DEBUG - 2011-06-17 11:01:24 --> Model Class Initialized
DEBUG - 2011-06-17 11:01:24 --> Model Class Initialized
DEBUG - 2011-06-17 11:01:24 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-06-17 11:01:24 --> Database Driver Class Initialized
DEBUG - 2011-06-17 11:01:24 --> File loaded: application/views/table/main.php
DEBUG - 2011-06-17 11:01:24 --> Helper loaded: url_helper
DEBUG - 2011-06-17 11:01:24 --> File loaded: application/views/common/header.php
DEBUG - 2011-06-17 11:01:24 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-06-17 11:01:24 --> File loaded: application/views/common/footer.php
DEBUG - 2011-06-17 11:01:24 --> File loaded: application/views/layout/main.php
DEBUG - 2011-06-17 11:01:24 --> Final output sent to browser
DEBUG - 2011-06-17 11:01:24 --> Total execution time: 0.0456
DEBUG - 2011-06-17 11:01:26 --> Config Class Initialized
DEBUG - 2011-06-17 11:01:26 --> Hooks Class Initialized
DEBUG - 2011-06-17 11:01:26 --> Utf8 Class Initialized
DEBUG - 2011-06-17 11:01:26 --> UTF-8 Support Enabled
DEBUG - 2011-06-17 11:01:26 --> URI Class Initialized
DEBUG - 2011-06-17 11:01:26 --> Router Class Initialized
DEBUG - 2011-06-17 11:01:26 --> Output Class Initialized
DEBUG - 2011-06-17 11:01:26 --> Input Class Initialized
DEBUG - 2011-06-17 11:01:26 --> Global POST and COOKIE data sanitized
DEBUG - 2011-06-17 11:01:26 --> Language Class Initialized
DEBUG - 2011-06-17 11:01:26 --> Loader Class Initialized
DEBUG - 2011-06-17 11:01:26 --> Controller Class Initialized
DEBUG - 2011-06-17 11:01:26 --> Model Class Initialized
DEBUG - 2011-06-17 11:01:26 --> Model Class Initialized
DEBUG - 2011-06-17 11:01:26 --> Model Class Initialized
DEBUG - 2011-06-17 11:01:26 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-06-17 11:01:26 --> Database Driver Class Initialized
DEBUG - 2011-06-17 11:01:26 --> File loaded: application/views/table/main.php
DEBUG - 2011-06-17 11:01:26 --> Helper loaded: url_helper
DEBUG - 2011-06-17 11:01:26 --> File loaded: application/views/common/header.php
DEBUG - 2011-06-17 11:01:26 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-06-17 11:01:26 --> File loaded: application/views/common/footer.php
DEBUG - 2011-06-17 11:01:26 --> File loaded: application/views/layout/main.php
DEBUG - 2011-06-17 11:01:26 --> Final output sent to browser
DEBUG - 2011-06-17 11:01:26 --> Total execution time: 0.5895
DEBUG - 2011-06-17 11:01:29 --> Config Class Initialized
DEBUG - 2011-06-17 11:01:29 --> Hooks Class Initialized
DEBUG - 2011-06-17 11:01:29 --> Utf8 Class Initialized
DEBUG - 2011-06-17 11:01:29 --> UTF-8 Support Enabled
DEBUG - 2011-06-17 11:01:29 --> URI Class Initialized
DEBUG - 2011-06-17 11:01:29 --> Router Class Initialized
ERROR - 2011-06-17 11:01:29 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-06-17 11:01:34 --> Config Class Initialized
DEBUG - 2011-06-17 11:01:34 --> Hooks Class Initialized
DEBUG - 2011-06-17 11:01:34 --> Utf8 Class Initialized
DEBUG - 2011-06-17 11:01:34 --> UTF-8 Support Enabled
DEBUG - 2011-06-17 11:01:34 --> URI Class Initialized
DEBUG - 2011-06-17 11:01:34 --> Router Class Initialized
DEBUG - 2011-06-17 11:01:34 --> Output Class Initialized
DEBUG - 2011-06-17 11:01:34 --> Input Class Initialized
DEBUG - 2011-06-17 11:01:34 --> Global POST and COOKIE data sanitized
DEBUG - 2011-06-17 11:01:34 --> Language Class Initialized
DEBUG - 2011-06-17 11:01:34 --> Loader Class Initialized
DEBUG - 2011-06-17 11:01:34 --> Controller Class Initialized
DEBUG - 2011-06-17 11:01:34 --> Model Class Initialized
DEBUG - 2011-06-17 11:01:34 --> Model Class Initialized
DEBUG - 2011-06-17 11:01:34 --> Model Class Initialized
DEBUG - 2011-06-17 11:01:34 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-06-17 11:01:34 --> Database Driver Class Initialized
DEBUG - 2011-06-17 11:01:34 --> File loaded: application/views/table/main.php
DEBUG - 2011-06-17 11:01:34 --> Helper loaded: url_helper
DEBUG - 2011-06-17 11:01:34 --> File loaded: application/views/common/header.php
DEBUG - 2011-06-17 11:01:34 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-06-17 11:01:34 --> File loaded: application/views/common/footer.php
DEBUG - 2011-06-17 11:01:34 --> File loaded: application/views/layout/main.php
DEBUG - 2011-06-17 11:01:34 --> Final output sent to browser
DEBUG - 2011-06-17 11:01:34 --> Total execution time: 0.0565
DEBUG - 2011-06-17 11:01:42 --> Config Class Initialized
DEBUG - 2011-06-17 11:01:42 --> Hooks Class Initialized
DEBUG - 2011-06-17 11:01:42 --> Utf8 Class Initialized
DEBUG - 2011-06-17 11:01:42 --> UTF-8 Support Enabled
DEBUG - 2011-06-17 11:01:42 --> URI Class Initialized
DEBUG - 2011-06-17 11:01:42 --> Router Class Initialized
DEBUG - 2011-06-17 11:01:42 --> Output Class Initialized
DEBUG - 2011-06-17 11:01:42 --> Input Class Initialized
DEBUG - 2011-06-17 11:01:42 --> Global POST and COOKIE data sanitized
DEBUG - 2011-06-17 11:01:42 --> Language Class Initialized
DEBUG - 2011-06-17 11:01:42 --> Loader Class Initialized
DEBUG - 2011-06-17 11:01:42 --> Controller Class Initialized
DEBUG - 2011-06-17 11:01:42 --> Model Class Initialized
DEBUG - 2011-06-17 11:01:42 --> Model Class Initialized
DEBUG - 2011-06-17 11:01:42 --> Model Class Initialized
DEBUG - 2011-06-17 11:01:42 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-06-17 11:01:42 --> Database Driver Class Initialized
DEBUG - 2011-06-17 11:01:45 --> File loaded: application/views/table/main.php
DEBUG - 2011-06-17 11:01:45 --> Helper loaded: url_helper
DEBUG - 2011-06-17 11:01:45 --> File loaded: application/views/common/header.php
DEBUG - 2011-06-17 11:01:45 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-06-17 11:01:45 --> File loaded: application/views/common/footer.php
DEBUG - 2011-06-17 11:01:45 --> File loaded: application/views/layout/main.php
DEBUG - 2011-06-17 11:01:45 --> Final output sent to browser
DEBUG - 2011-06-17 11:01:45 --> Total execution time: 3.1522
DEBUG - 2011-06-17 11:01:47 --> Config Class Initialized
DEBUG - 2011-06-17 11:01:47 --> Hooks Class Initialized
DEBUG - 2011-06-17 11:01:47 --> Utf8 Class Initialized
DEBUG - 2011-06-17 11:01:47 --> UTF-8 Support Enabled
DEBUG - 2011-06-17 11:01:47 --> URI Class Initialized
DEBUG - 2011-06-17 11:01:47 --> Router Class Initialized
DEBUG - 2011-06-17 11:01:47 --> Output Class Initialized
DEBUG - 2011-06-17 11:01:47 --> Input Class Initialized
DEBUG - 2011-06-17 11:01:47 --> Global POST and COOKIE data sanitized
DEBUG - 2011-06-17 11:01:47 --> Language Class Initialized
DEBUG - 2011-06-17 11:01:47 --> Loader Class Initialized
DEBUG - 2011-06-17 11:01:47 --> Controller Class Initialized
DEBUG - 2011-06-17 11:01:47 --> Model Class Initialized
DEBUG - 2011-06-17 11:01:47 --> Model Class Initialized
DEBUG - 2011-06-17 11:01:47 --> Model Class Initialized
DEBUG - 2011-06-17 11:01:47 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-06-17 11:01:47 --> Database Driver Class Initialized
DEBUG - 2011-06-17 11:01:47 --> File loaded: application/views/table/main.php
DEBUG - 2011-06-17 11:01:47 --> Helper loaded: url_helper
DEBUG - 2011-06-17 11:01:47 --> File loaded: application/views/common/header.php
DEBUG - 2011-06-17 11:01:47 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-06-17 11:01:47 --> File loaded: application/views/common/footer.php
DEBUG - 2011-06-17 11:01:47 --> File loaded: application/views/layout/main.php
DEBUG - 2011-06-17 11:01:47 --> Final output sent to browser
DEBUG - 2011-06-17 11:01:47 --> Total execution time: 0.0626
DEBUG - 2011-06-17 11:01:49 --> Config Class Initialized
DEBUG - 2011-06-17 11:01:49 --> Hooks Class Initialized
DEBUG - 2011-06-17 11:01:49 --> Utf8 Class Initialized
DEBUG - 2011-06-17 11:01:49 --> UTF-8 Support Enabled
DEBUG - 2011-06-17 11:01:49 --> URI Class Initialized
DEBUG - 2011-06-17 11:01:49 --> Router Class Initialized
ERROR - 2011-06-17 11:01:49 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-06-17 11:01:58 --> Config Class Initialized
DEBUG - 2011-06-17 11:01:58 --> Hooks Class Initialized
DEBUG - 2011-06-17 11:01:58 --> Utf8 Class Initialized
DEBUG - 2011-06-17 11:01:58 --> UTF-8 Support Enabled
DEBUG - 2011-06-17 11:01:58 --> URI Class Initialized
DEBUG - 2011-06-17 11:01:58 --> Router Class Initialized
DEBUG - 2011-06-17 11:01:58 --> Output Class Initialized
DEBUG - 2011-06-17 11:01:58 --> Input Class Initialized
DEBUG - 2011-06-17 11:01:58 --> Global POST and COOKIE data sanitized
DEBUG - 2011-06-17 11:01:58 --> Language Class Initialized
DEBUG - 2011-06-17 11:01:58 --> Loader Class Initialized
DEBUG - 2011-06-17 11:01:58 --> Controller Class Initialized
DEBUG - 2011-06-17 11:01:58 --> Model Class Initialized
DEBUG - 2011-06-17 11:01:58 --> Model Class Initialized
DEBUG - 2011-06-17 11:01:58 --> Model Class Initialized
DEBUG - 2011-06-17 11:01:58 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-06-17 11:01:58 --> Database Driver Class Initialized
DEBUG - 2011-06-17 11:01:58 --> File loaded: application/views/table/main.php
DEBUG - 2011-06-17 11:01:58 --> Helper loaded: url_helper
DEBUG - 2011-06-17 11:01:58 --> File loaded: application/views/common/header.php
DEBUG - 2011-06-17 11:01:58 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-06-17 11:01:58 --> File loaded: application/views/common/footer.php
DEBUG - 2011-06-17 11:01:58 --> File loaded: application/views/layout/main.php
DEBUG - 2011-06-17 11:01:58 --> Final output sent to browser
DEBUG - 2011-06-17 11:01:58 --> Total execution time: 0.5309
DEBUG - 2011-06-17 11:02:00 --> Config Class Initialized
DEBUG - 2011-06-17 11:02:00 --> Hooks Class Initialized
DEBUG - 2011-06-17 11:02:00 --> Utf8 Class Initialized
DEBUG - 2011-06-17 11:02:00 --> UTF-8 Support Enabled
DEBUG - 2011-06-17 11:02:00 --> URI Class Initialized
DEBUG - 2011-06-17 11:02:00 --> Router Class Initialized
DEBUG - 2011-06-17 11:02:00 --> Output Class Initialized
DEBUG - 2011-06-17 11:02:00 --> Input Class Initialized
DEBUG - 2011-06-17 11:02:00 --> Global POST and COOKIE data sanitized
DEBUG - 2011-06-17 11:02:00 --> Language Class Initialized
DEBUG - 2011-06-17 11:02:00 --> Loader Class Initialized
DEBUG - 2011-06-17 11:02:00 --> Controller Class Initialized
DEBUG - 2011-06-17 11:02:00 --> Model Class Initialized
DEBUG - 2011-06-17 11:02:00 --> Model Class Initialized
DEBUG - 2011-06-17 11:02:00 --> Model Class Initialized
DEBUG - 2011-06-17 11:02:00 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-06-17 11:02:01 --> Database Driver Class Initialized
DEBUG - 2011-06-17 11:02:01 --> File loaded: application/views/table/main.php
DEBUG - 2011-06-17 11:02:01 --> Helper loaded: url_helper
DEBUG - 2011-06-17 11:02:01 --> File loaded: application/views/common/header.php
DEBUG - 2011-06-17 11:02:01 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-06-17 11:02:01 --> File loaded: application/views/common/footer.php
DEBUG - 2011-06-17 11:02:01 --> File loaded: application/views/layout/main.php
DEBUG - 2011-06-17 11:02:01 --> Final output sent to browser
DEBUG - 2011-06-17 11:02:01 --> Total execution time: 0.0670
DEBUG - 2011-06-17 11:02:01 --> Config Class Initialized
DEBUG - 2011-06-17 11:02:01 --> Hooks Class Initialized
DEBUG - 2011-06-17 11:02:01 --> Utf8 Class Initialized
DEBUG - 2011-06-17 11:02:01 --> UTF-8 Support Enabled
DEBUG - 2011-06-17 11:02:01 --> URI Class Initialized
DEBUG - 2011-06-17 11:02:01 --> Router Class Initialized
ERROR - 2011-06-17 11:02:01 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-06-17 11:02:08 --> Config Class Initialized
DEBUG - 2011-06-17 11:02:08 --> Hooks Class Initialized
DEBUG - 2011-06-17 11:02:08 --> Utf8 Class Initialized
DEBUG - 2011-06-17 11:02:08 --> UTF-8 Support Enabled
DEBUG - 2011-06-17 11:02:08 --> URI Class Initialized
DEBUG - 2011-06-17 11:02:08 --> Router Class Initialized
DEBUG - 2011-06-17 11:02:08 --> Output Class Initialized
DEBUG - 2011-06-17 11:02:08 --> Input Class Initialized
DEBUG - 2011-06-17 11:02:08 --> Global POST and COOKIE data sanitized
DEBUG - 2011-06-17 11:02:08 --> Language Class Initialized
DEBUG - 2011-06-17 11:02:08 --> Loader Class Initialized
DEBUG - 2011-06-17 11:02:08 --> Controller Class Initialized
DEBUG - 2011-06-17 11:02:08 --> Model Class Initialized
DEBUG - 2011-06-17 11:02:08 --> Model Class Initialized
DEBUG - 2011-06-17 11:02:08 --> Model Class Initialized
DEBUG - 2011-06-17 11:02:08 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-06-17 11:02:08 --> Database Driver Class Initialized
DEBUG - 2011-06-17 11:02:08 --> File loaded: application/views/table/main.php
DEBUG - 2011-06-17 11:02:08 --> Helper loaded: url_helper
DEBUG - 2011-06-17 11:02:08 --> File loaded: application/views/common/header.php
DEBUG - 2011-06-17 11:02:08 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-06-17 11:02:08 --> File loaded: application/views/common/footer.php
DEBUG - 2011-06-17 11:02:08 --> File loaded: application/views/layout/main.php
DEBUG - 2011-06-17 11:02:08 --> Final output sent to browser
DEBUG - 2011-06-17 11:02:08 --> Total execution time: 0.2596
DEBUG - 2011-06-17 11:02:09 --> Config Class Initialized
DEBUG - 2011-06-17 11:02:09 --> Hooks Class Initialized
DEBUG - 2011-06-17 11:02:09 --> Utf8 Class Initialized
DEBUG - 2011-06-17 11:02:09 --> UTF-8 Support Enabled
DEBUG - 2011-06-17 11:02:09 --> URI Class Initialized
DEBUG - 2011-06-17 11:02:09 --> Router Class Initialized
DEBUG - 2011-06-17 11:02:09 --> Output Class Initialized
DEBUG - 2011-06-17 11:02:09 --> Input Class Initialized
DEBUG - 2011-06-17 11:02:09 --> Global POST and COOKIE data sanitized
DEBUG - 2011-06-17 11:02:09 --> Language Class Initialized
DEBUG - 2011-06-17 11:02:09 --> Loader Class Initialized
DEBUG - 2011-06-17 11:02:09 --> Controller Class Initialized
DEBUG - 2011-06-17 11:02:09 --> Model Class Initialized
DEBUG - 2011-06-17 11:02:09 --> Model Class Initialized
DEBUG - 2011-06-17 11:02:09 --> Model Class Initialized
DEBUG - 2011-06-17 11:02:09 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-06-17 11:02:09 --> Database Driver Class Initialized
DEBUG - 2011-06-17 11:02:09 --> File loaded: application/views/table/main.php
DEBUG - 2011-06-17 11:02:09 --> Helper loaded: url_helper
DEBUG - 2011-06-17 11:02:09 --> File loaded: application/views/common/header.php
DEBUG - 2011-06-17 11:02:09 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-06-17 11:02:09 --> File loaded: application/views/common/footer.php
DEBUG - 2011-06-17 11:02:09 --> File loaded: application/views/layout/main.php
DEBUG - 2011-06-17 11:02:09 --> Final output sent to browser
DEBUG - 2011-06-17 11:02:09 --> Total execution time: 0.0544
DEBUG - 2011-06-17 11:02:11 --> Config Class Initialized
DEBUG - 2011-06-17 11:02:11 --> Hooks Class Initialized
DEBUG - 2011-06-17 11:02:11 --> Utf8 Class Initialized
DEBUG - 2011-06-17 11:02:11 --> UTF-8 Support Enabled
DEBUG - 2011-06-17 11:02:11 --> URI Class Initialized
DEBUG - 2011-06-17 11:02:11 --> Router Class Initialized
ERROR - 2011-06-17 11:02:11 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-06-17 11:02:25 --> Config Class Initialized
DEBUG - 2011-06-17 11:02:25 --> Hooks Class Initialized
DEBUG - 2011-06-17 11:02:25 --> Utf8 Class Initialized
DEBUG - 2011-06-17 11:02:25 --> UTF-8 Support Enabled
DEBUG - 2011-06-17 11:02:25 --> URI Class Initialized
DEBUG - 2011-06-17 11:02:25 --> Router Class Initialized
DEBUG - 2011-06-17 11:02:25 --> Output Class Initialized
DEBUG - 2011-06-17 11:02:25 --> Input Class Initialized
DEBUG - 2011-06-17 11:02:25 --> Global POST and COOKIE data sanitized
DEBUG - 2011-06-17 11:02:25 --> Language Class Initialized
DEBUG - 2011-06-17 11:02:25 --> Loader Class Initialized
DEBUG - 2011-06-17 11:02:25 --> Controller Class Initialized
DEBUG - 2011-06-17 11:02:25 --> Model Class Initialized
DEBUG - 2011-06-17 11:02:25 --> Model Class Initialized
DEBUG - 2011-06-17 11:02:25 --> Model Class Initialized
DEBUG - 2011-06-17 11:02:25 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-06-17 11:02:25 --> Database Driver Class Initialized
DEBUG - 2011-06-17 11:02:25 --> File loaded: application/views/table/main.php
DEBUG - 2011-06-17 11:02:25 --> Helper loaded: url_helper
DEBUG - 2011-06-17 11:02:25 --> File loaded: application/views/common/header.php
DEBUG - 2011-06-17 11:02:25 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-06-17 11:02:25 --> File loaded: application/views/common/footer.php
DEBUG - 2011-06-17 11:02:25 --> File loaded: application/views/layout/main.php
DEBUG - 2011-06-17 11:02:25 --> Final output sent to browser
DEBUG - 2011-06-17 11:02:25 --> Total execution time: 0.0448
DEBUG - 2011-06-17 11:02:27 --> Config Class Initialized
DEBUG - 2011-06-17 11:02:27 --> Hooks Class Initialized
DEBUG - 2011-06-17 11:02:27 --> Utf8 Class Initialized
DEBUG - 2011-06-17 11:02:27 --> UTF-8 Support Enabled
DEBUG - 2011-06-17 11:02:27 --> URI Class Initialized
DEBUG - 2011-06-17 11:02:27 --> Router Class Initialized
ERROR - 2011-06-17 11:02:27 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-06-17 11:02:31 --> Config Class Initialized
DEBUG - 2011-06-17 11:02:31 --> Hooks Class Initialized
DEBUG - 2011-06-17 11:02:31 --> Utf8 Class Initialized
DEBUG - 2011-06-17 11:02:31 --> UTF-8 Support Enabled
DEBUG - 2011-06-17 11:02:31 --> URI Class Initialized
DEBUG - 2011-06-17 11:02:31 --> Router Class Initialized
DEBUG - 2011-06-17 11:02:31 --> Output Class Initialized
DEBUG - 2011-06-17 11:02:31 --> Input Class Initialized
DEBUG - 2011-06-17 11:02:31 --> Global POST and COOKIE data sanitized
DEBUG - 2011-06-17 11:02:31 --> Language Class Initialized
DEBUG - 2011-06-17 11:02:31 --> Loader Class Initialized
DEBUG - 2011-06-17 11:02:31 --> Controller Class Initialized
DEBUG - 2011-06-17 11:02:31 --> Model Class Initialized
DEBUG - 2011-06-17 11:02:31 --> Model Class Initialized
DEBUG - 2011-06-17 11:02:31 --> Model Class Initialized
DEBUG - 2011-06-17 11:02:31 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-06-17 11:02:31 --> Database Driver Class Initialized
DEBUG - 2011-06-17 11:02:33 --> File loaded: application/views/table/main.php
DEBUG - 2011-06-17 11:02:33 --> Helper loaded: url_helper
DEBUG - 2011-06-17 11:02:33 --> File loaded: application/views/common/header.php
DEBUG - 2011-06-17 11:02:33 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-06-17 11:02:33 --> File loaded: application/views/common/footer.php
DEBUG - 2011-06-17 11:02:33 --> File loaded: application/views/layout/main.php
DEBUG - 2011-06-17 11:02:33 --> Final output sent to browser
DEBUG - 2011-06-17 11:02:33 --> Total execution time: 1.2910
DEBUG - 2011-06-17 11:02:34 --> Config Class Initialized
DEBUG - 2011-06-17 11:02:34 --> Hooks Class Initialized
DEBUG - 2011-06-17 11:02:34 --> Utf8 Class Initialized
DEBUG - 2011-06-17 11:02:34 --> UTF-8 Support Enabled
DEBUG - 2011-06-17 11:02:34 --> URI Class Initialized
DEBUG - 2011-06-17 11:02:34 --> Router Class Initialized
DEBUG - 2011-06-17 11:02:34 --> Output Class Initialized
DEBUG - 2011-06-17 11:02:34 --> Input Class Initialized
DEBUG - 2011-06-17 11:02:34 --> Global POST and COOKIE data sanitized
DEBUG - 2011-06-17 11:02:34 --> Language Class Initialized
DEBUG - 2011-06-17 11:02:34 --> Loader Class Initialized
DEBUG - 2011-06-17 11:02:34 --> Controller Class Initialized
DEBUG - 2011-06-17 11:02:34 --> Model Class Initialized
DEBUG - 2011-06-17 11:02:34 --> Model Class Initialized
DEBUG - 2011-06-17 11:02:34 --> Model Class Initialized
DEBUG - 2011-06-17 11:02:34 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-06-17 11:02:34 --> Database Driver Class Initialized
DEBUG - 2011-06-17 11:02:34 --> File loaded: application/views/table/main.php
DEBUG - 2011-06-17 11:02:34 --> Helper loaded: url_helper
DEBUG - 2011-06-17 11:02:34 --> File loaded: application/views/common/header.php
DEBUG - 2011-06-17 11:02:34 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-06-17 11:02:34 --> File loaded: application/views/common/footer.php
DEBUG - 2011-06-17 11:02:34 --> File loaded: application/views/layout/main.php
DEBUG - 2011-06-17 11:02:34 --> Final output sent to browser
DEBUG - 2011-06-17 11:02:34 --> Total execution time: 0.0498
DEBUG - 2011-06-17 11:02:36 --> Config Class Initialized
DEBUG - 2011-06-17 11:02:36 --> Hooks Class Initialized
DEBUG - 2011-06-17 11:02:36 --> Utf8 Class Initialized
DEBUG - 2011-06-17 11:02:36 --> UTF-8 Support Enabled
DEBUG - 2011-06-17 11:02:36 --> URI Class Initialized
DEBUG - 2011-06-17 11:02:36 --> Router Class Initialized
ERROR - 2011-06-17 11:02:36 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-06-17 11:02:45 --> Config Class Initialized
DEBUG - 2011-06-17 11:02:45 --> Hooks Class Initialized
DEBUG - 2011-06-17 11:02:45 --> Utf8 Class Initialized
DEBUG - 2011-06-17 11:02:45 --> UTF-8 Support Enabled
DEBUG - 2011-06-17 11:02:45 --> URI Class Initialized
DEBUG - 2011-06-17 11:02:45 --> Router Class Initialized
DEBUG - 2011-06-17 11:02:45 --> Output Class Initialized
DEBUG - 2011-06-17 11:02:45 --> Input Class Initialized
DEBUG - 2011-06-17 11:02:45 --> Global POST and COOKIE data sanitized
DEBUG - 2011-06-17 11:02:45 --> Language Class Initialized
DEBUG - 2011-06-17 11:02:45 --> Loader Class Initialized
DEBUG - 2011-06-17 11:02:45 --> Controller Class Initialized
DEBUG - 2011-06-17 11:02:45 --> Model Class Initialized
DEBUG - 2011-06-17 11:02:45 --> Model Class Initialized
DEBUG - 2011-06-17 11:02:45 --> Model Class Initialized
DEBUG - 2011-06-17 11:02:45 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-06-17 11:02:45 --> Database Driver Class Initialized
DEBUG - 2011-06-17 11:02:46 --> File loaded: application/views/table/main.php
DEBUG - 2011-06-17 11:02:46 --> Helper loaded: url_helper
DEBUG - 2011-06-17 11:02:46 --> File loaded: application/views/common/header.php
DEBUG - 2011-06-17 11:02:46 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-06-17 11:02:46 --> File loaded: application/views/common/footer.php
DEBUG - 2011-06-17 11:02:46 --> File loaded: application/views/layout/main.php
DEBUG - 2011-06-17 11:02:46 --> Final output sent to browser
DEBUG - 2011-06-17 11:02:46 --> Total execution time: 0.6430
DEBUG - 2011-06-17 11:02:54 --> Config Class Initialized
DEBUG - 2011-06-17 11:02:54 --> Hooks Class Initialized
DEBUG - 2011-06-17 11:02:54 --> Utf8 Class Initialized
DEBUG - 2011-06-17 11:02:54 --> UTF-8 Support Enabled
DEBUG - 2011-06-17 11:02:54 --> URI Class Initialized
DEBUG - 2011-06-17 11:02:54 --> Router Class Initialized
ERROR - 2011-06-17 11:02:54 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-06-17 11:02:55 --> Config Class Initialized
DEBUG - 2011-06-17 11:02:55 --> Hooks Class Initialized
DEBUG - 2011-06-17 11:02:55 --> Utf8 Class Initialized
DEBUG - 2011-06-17 11:02:55 --> UTF-8 Support Enabled
DEBUG - 2011-06-17 11:02:55 --> URI Class Initialized
DEBUG - 2011-06-17 11:02:55 --> Router Class Initialized
DEBUG - 2011-06-17 11:02:55 --> Output Class Initialized
DEBUG - 2011-06-17 11:02:55 --> Input Class Initialized
DEBUG - 2011-06-17 11:02:55 --> Global POST and COOKIE data sanitized
DEBUG - 2011-06-17 11:02:55 --> Language Class Initialized
DEBUG - 2011-06-17 11:02:55 --> Loader Class Initialized
DEBUG - 2011-06-17 11:02:55 --> Controller Class Initialized
DEBUG - 2011-06-17 11:02:55 --> Model Class Initialized
DEBUG - 2011-06-17 11:02:55 --> Model Class Initialized
DEBUG - 2011-06-17 11:02:55 --> Model Class Initialized
DEBUG - 2011-06-17 11:02:55 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-06-17 11:02:55 --> Database Driver Class Initialized
DEBUG - 2011-06-17 11:02:55 --> File loaded: application/views/table/main.php
DEBUG - 2011-06-17 11:02:55 --> Helper loaded: url_helper
DEBUG - 2011-06-17 11:02:55 --> File loaded: application/views/common/header.php
DEBUG - 2011-06-17 11:02:55 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-06-17 11:02:55 --> File loaded: application/views/common/footer.php
DEBUG - 2011-06-17 11:02:55 --> File loaded: application/views/layout/main.php
DEBUG - 2011-06-17 11:02:55 --> Final output sent to browser
DEBUG - 2011-06-17 11:02:55 --> Total execution time: 0.0539
DEBUG - 2011-06-17 11:03:01 --> Config Class Initialized
DEBUG - 2011-06-17 11:03:01 --> Hooks Class Initialized
DEBUG - 2011-06-17 11:03:01 --> Utf8 Class Initialized
DEBUG - 2011-06-17 11:03:01 --> UTF-8 Support Enabled
DEBUG - 2011-06-17 11:03:01 --> URI Class Initialized
DEBUG - 2011-06-17 11:03:01 --> Router Class Initialized
DEBUG - 2011-06-17 11:03:01 --> Output Class Initialized
DEBUG - 2011-06-17 11:03:01 --> Input Class Initialized
DEBUG - 2011-06-17 11:03:01 --> Global POST and COOKIE data sanitized
DEBUG - 2011-06-17 11:03:01 --> Language Class Initialized
DEBUG - 2011-06-17 11:03:01 --> Loader Class Initialized
DEBUG - 2011-06-17 11:03:01 --> Controller Class Initialized
DEBUG - 2011-06-17 11:03:01 --> Model Class Initialized
DEBUG - 2011-06-17 11:03:01 --> Model Class Initialized
DEBUG - 2011-06-17 11:03:01 --> Model Class Initialized
DEBUG - 2011-06-17 11:03:01 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-06-17 11:03:01 --> Database Driver Class Initialized
DEBUG - 2011-06-17 11:03:01 --> File loaded: application/views/table/main.php
DEBUG - 2011-06-17 11:03:01 --> Helper loaded: url_helper
DEBUG - 2011-06-17 11:03:01 --> File loaded: application/views/common/header.php
DEBUG - 2011-06-17 11:03:01 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-06-17 11:03:01 --> File loaded: application/views/common/footer.php
DEBUG - 2011-06-17 11:03:01 --> File loaded: application/views/layout/main.php
DEBUG - 2011-06-17 11:03:01 --> Final output sent to browser
DEBUG - 2011-06-17 11:03:01 --> Total execution time: 0.2879
DEBUG - 2011-06-17 11:03:03 --> Config Class Initialized
DEBUG - 2011-06-17 11:03:03 --> Hooks Class Initialized
DEBUG - 2011-06-17 11:03:03 --> Utf8 Class Initialized
DEBUG - 2011-06-17 11:03:03 --> UTF-8 Support Enabled
DEBUG - 2011-06-17 11:03:03 --> URI Class Initialized
DEBUG - 2011-06-17 11:03:03 --> Router Class Initialized
DEBUG - 2011-06-17 11:03:03 --> Output Class Initialized
DEBUG - 2011-06-17 11:03:03 --> Input Class Initialized
DEBUG - 2011-06-17 11:03:03 --> Global POST and COOKIE data sanitized
DEBUG - 2011-06-17 11:03:03 --> Language Class Initialized
DEBUG - 2011-06-17 11:03:03 --> Loader Class Initialized
DEBUG - 2011-06-17 11:03:03 --> Controller Class Initialized
DEBUG - 2011-06-17 11:03:03 --> Model Class Initialized
DEBUG - 2011-06-17 11:03:03 --> Model Class Initialized
DEBUG - 2011-06-17 11:03:03 --> Model Class Initialized
DEBUG - 2011-06-17 11:03:03 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-06-17 11:03:03 --> Database Driver Class Initialized
DEBUG - 2011-06-17 11:03:03 --> File loaded: application/views/table/main.php
DEBUG - 2011-06-17 11:03:03 --> Helper loaded: url_helper
DEBUG - 2011-06-17 11:03:03 --> File loaded: application/views/common/header.php
DEBUG - 2011-06-17 11:03:03 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-06-17 11:03:03 --> File loaded: application/views/common/footer.php
DEBUG - 2011-06-17 11:03:03 --> File loaded: application/views/layout/main.php
DEBUG - 2011-06-17 11:03:03 --> Final output sent to browser
DEBUG - 2011-06-17 11:03:03 --> Total execution time: 0.0520
DEBUG - 2011-06-17 11:03:04 --> Config Class Initialized
DEBUG - 2011-06-17 11:03:04 --> Hooks Class Initialized
DEBUG - 2011-06-17 11:03:04 --> Utf8 Class Initialized
DEBUG - 2011-06-17 11:03:04 --> UTF-8 Support Enabled
DEBUG - 2011-06-17 11:03:04 --> URI Class Initialized
DEBUG - 2011-06-17 11:03:04 --> Router Class Initialized
ERROR - 2011-06-17 11:03:04 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-06-17 11:03:10 --> Config Class Initialized
DEBUG - 2011-06-17 11:03:10 --> Hooks Class Initialized
DEBUG - 2011-06-17 11:03:10 --> Utf8 Class Initialized
DEBUG - 2011-06-17 11:03:10 --> UTF-8 Support Enabled
DEBUG - 2011-06-17 11:03:10 --> URI Class Initialized
DEBUG - 2011-06-17 11:03:10 --> Router Class Initialized
DEBUG - 2011-06-17 11:03:10 --> Output Class Initialized
DEBUG - 2011-06-17 11:03:10 --> Input Class Initialized
DEBUG - 2011-06-17 11:03:10 --> Global POST and COOKIE data sanitized
DEBUG - 2011-06-17 11:03:10 --> Language Class Initialized
DEBUG - 2011-06-17 11:03:10 --> Loader Class Initialized
DEBUG - 2011-06-17 11:03:10 --> Controller Class Initialized
DEBUG - 2011-06-17 11:03:10 --> Model Class Initialized
DEBUG - 2011-06-17 11:03:10 --> Model Class Initialized
DEBUG - 2011-06-17 11:03:10 --> Model Class Initialized
DEBUG - 2011-06-17 11:03:10 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-06-17 11:03:10 --> Database Driver Class Initialized
DEBUG - 2011-06-17 11:03:11 --> File loaded: application/views/table/main.php
DEBUG - 2011-06-17 11:03:11 --> Helper loaded: url_helper
DEBUG - 2011-06-17 11:03:11 --> File loaded: application/views/common/header.php
DEBUG - 2011-06-17 11:03:11 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-06-17 11:03:11 --> File loaded: application/views/common/footer.php
DEBUG - 2011-06-17 11:03:11 --> File loaded: application/views/layout/main.php
DEBUG - 2011-06-17 11:03:11 --> Final output sent to browser
DEBUG - 2011-06-17 11:03:11 --> Total execution time: 0.6366
DEBUG - 2011-06-17 11:03:12 --> Config Class Initialized
DEBUG - 2011-06-17 11:03:12 --> Hooks Class Initialized
DEBUG - 2011-06-17 11:03:12 --> Utf8 Class Initialized
DEBUG - 2011-06-17 11:03:12 --> UTF-8 Support Enabled
DEBUG - 2011-06-17 11:03:12 --> URI Class Initialized
DEBUG - 2011-06-17 11:03:12 --> Router Class Initialized
DEBUG - 2011-06-17 11:03:12 --> Output Class Initialized
DEBUG - 2011-06-17 11:03:12 --> Input Class Initialized
DEBUG - 2011-06-17 11:03:12 --> Global POST and COOKIE data sanitized
DEBUG - 2011-06-17 11:03:12 --> Language Class Initialized
DEBUG - 2011-06-17 11:03:12 --> Loader Class Initialized
DEBUG - 2011-06-17 11:03:12 --> Controller Class Initialized
DEBUG - 2011-06-17 11:03:12 --> Model Class Initialized
DEBUG - 2011-06-17 11:03:12 --> Model Class Initialized
DEBUG - 2011-06-17 11:03:12 --> Model Class Initialized
DEBUG - 2011-06-17 11:03:12 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-06-17 11:03:12 --> Database Driver Class Initialized
DEBUG - 2011-06-17 11:03:12 --> File loaded: application/views/table/main.php
DEBUG - 2011-06-17 11:03:12 --> Helper loaded: url_helper
DEBUG - 2011-06-17 11:03:12 --> File loaded: application/views/common/header.php
DEBUG - 2011-06-17 11:03:12 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-06-17 11:03:12 --> File loaded: application/views/common/footer.php
DEBUG - 2011-06-17 11:03:12 --> File loaded: application/views/layout/main.php
DEBUG - 2011-06-17 11:03:12 --> Final output sent to browser
DEBUG - 2011-06-17 11:03:12 --> Total execution time: 0.0523
DEBUG - 2011-06-17 11:03:12 --> Config Class Initialized
DEBUG - 2011-06-17 11:03:12 --> Hooks Class Initialized
DEBUG - 2011-06-17 11:03:12 --> Utf8 Class Initialized
DEBUG - 2011-06-17 11:03:12 --> UTF-8 Support Enabled
DEBUG - 2011-06-17 11:03:12 --> URI Class Initialized
DEBUG - 2011-06-17 11:03:12 --> Router Class Initialized
DEBUG - 2011-06-17 11:03:12 --> Output Class Initialized
DEBUG - 2011-06-17 11:03:12 --> Input Class Initialized
DEBUG - 2011-06-17 11:03:12 --> Global POST and COOKIE data sanitized
DEBUG - 2011-06-17 11:03:12 --> Language Class Initialized
DEBUG - 2011-06-17 11:03:12 --> Loader Class Initialized
DEBUG - 2011-06-17 11:03:12 --> Controller Class Initialized
DEBUG - 2011-06-17 11:03:12 --> Model Class Initialized
DEBUG - 2011-06-17 11:03:12 --> Model Class Initialized
DEBUG - 2011-06-17 11:03:12 --> Model Class Initialized
DEBUG - 2011-06-17 11:03:12 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-06-17 11:03:12 --> Database Driver Class Initialized
DEBUG - 2011-06-17 11:03:12 --> File loaded: application/views/table/main.php
DEBUG - 2011-06-17 11:03:12 --> Helper loaded: url_helper
DEBUG - 2011-06-17 11:03:12 --> File loaded: application/views/common/header.php
DEBUG - 2011-06-17 11:03:12 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-06-17 11:03:12 --> File loaded: application/views/common/footer.php
DEBUG - 2011-06-17 11:03:12 --> File loaded: application/views/layout/main.php
DEBUG - 2011-06-17 11:03:12 --> Final output sent to browser
DEBUG - 2011-06-17 11:03:12 --> Total execution time: 0.0459
DEBUG - 2011-06-17 11:03:13 --> Config Class Initialized
DEBUG - 2011-06-17 11:03:13 --> Hooks Class Initialized
DEBUG - 2011-06-17 11:03:13 --> Utf8 Class Initialized
DEBUG - 2011-06-17 11:03:13 --> UTF-8 Support Enabled
DEBUG - 2011-06-17 11:03:13 --> URI Class Initialized
DEBUG - 2011-06-17 11:03:13 --> Router Class Initialized
ERROR - 2011-06-17 11:03:13 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-06-17 11:03:23 --> Config Class Initialized
DEBUG - 2011-06-17 11:03:23 --> Hooks Class Initialized
DEBUG - 2011-06-17 11:03:23 --> Utf8 Class Initialized
DEBUG - 2011-06-17 11:03:23 --> UTF-8 Support Enabled
DEBUG - 2011-06-17 11:03:23 --> URI Class Initialized
DEBUG - 2011-06-17 11:03:23 --> Router Class Initialized
DEBUG - 2011-06-17 11:03:23 --> Output Class Initialized
DEBUG - 2011-06-17 11:03:23 --> Input Class Initialized
DEBUG - 2011-06-17 11:03:23 --> Global POST and COOKIE data sanitized
DEBUG - 2011-06-17 11:03:23 --> Language Class Initialized
DEBUG - 2011-06-17 11:03:23 --> Loader Class Initialized
DEBUG - 2011-06-17 11:03:23 --> Controller Class Initialized
DEBUG - 2011-06-17 11:03:23 --> Model Class Initialized
DEBUG - 2011-06-17 11:03:23 --> Model Class Initialized
DEBUG - 2011-06-17 11:03:23 --> Model Class Initialized
DEBUG - 2011-06-17 11:03:23 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-06-17 11:03:23 --> Database Driver Class Initialized
DEBUG - 2011-06-17 11:03:24 --> File loaded: application/views/table/main.php
DEBUG - 2011-06-17 11:03:24 --> Helper loaded: url_helper
DEBUG - 2011-06-17 11:03:24 --> File loaded: application/views/common/header.php
DEBUG - 2011-06-17 11:03:24 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-06-17 11:03:24 --> File loaded: application/views/common/footer.php
DEBUG - 2011-06-17 11:03:24 --> File loaded: application/views/layout/main.php
DEBUG - 2011-06-17 11:03:24 --> Final output sent to browser
DEBUG - 2011-06-17 11:03:24 --> Total execution time: 0.2312
DEBUG - 2011-06-17 11:03:25 --> Config Class Initialized
DEBUG - 2011-06-17 11:03:25 --> Hooks Class Initialized
DEBUG - 2011-06-17 11:03:25 --> Utf8 Class Initialized
DEBUG - 2011-06-17 11:03:25 --> UTF-8 Support Enabled
DEBUG - 2011-06-17 11:03:25 --> URI Class Initialized
DEBUG - 2011-06-17 11:03:25 --> Router Class Initialized
DEBUG - 2011-06-17 11:03:25 --> Output Class Initialized
DEBUG - 2011-06-17 11:03:25 --> Input Class Initialized
DEBUG - 2011-06-17 11:03:25 --> Global POST and COOKIE data sanitized
DEBUG - 2011-06-17 11:03:25 --> Language Class Initialized
DEBUG - 2011-06-17 11:03:25 --> Loader Class Initialized
DEBUG - 2011-06-17 11:03:25 --> Controller Class Initialized
DEBUG - 2011-06-17 11:03:25 --> Model Class Initialized
DEBUG - 2011-06-17 11:03:25 --> Model Class Initialized
DEBUG - 2011-06-17 11:03:25 --> Model Class Initialized
DEBUG - 2011-06-17 11:03:25 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-06-17 11:03:25 --> Database Driver Class Initialized
DEBUG - 2011-06-17 11:03:25 --> File loaded: application/views/table/main.php
DEBUG - 2011-06-17 11:03:25 --> Helper loaded: url_helper
DEBUG - 2011-06-17 11:03:25 --> File loaded: application/views/common/header.php
DEBUG - 2011-06-17 11:03:25 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-06-17 11:03:25 --> File loaded: application/views/common/footer.php
DEBUG - 2011-06-17 11:03:25 --> File loaded: application/views/layout/main.php
DEBUG - 2011-06-17 11:03:25 --> Final output sent to browser
DEBUG - 2011-06-17 11:03:25 --> Total execution time: 0.0451
DEBUG - 2011-06-17 11:03:26 --> Config Class Initialized
DEBUG - 2011-06-17 11:03:26 --> Hooks Class Initialized
DEBUG - 2011-06-17 11:03:26 --> Utf8 Class Initialized
DEBUG - 2011-06-17 11:03:26 --> UTF-8 Support Enabled
DEBUG - 2011-06-17 11:03:26 --> URI Class Initialized
DEBUG - 2011-06-17 11:03:26 --> Router Class Initialized
ERROR - 2011-06-17 11:03:26 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-06-17 11:03:45 --> Config Class Initialized
DEBUG - 2011-06-17 11:03:45 --> Hooks Class Initialized
DEBUG - 2011-06-17 11:03:45 --> Utf8 Class Initialized
DEBUG - 2011-06-17 11:03:45 --> UTF-8 Support Enabled
DEBUG - 2011-06-17 11:03:45 --> URI Class Initialized
DEBUG - 2011-06-17 11:03:45 --> Router Class Initialized
DEBUG - 2011-06-17 11:03:45 --> Output Class Initialized
DEBUG - 2011-06-17 11:03:45 --> Input Class Initialized
DEBUG - 2011-06-17 11:03:45 --> Global POST and COOKIE data sanitized
DEBUG - 2011-06-17 11:03:45 --> Language Class Initialized
DEBUG - 2011-06-17 11:03:45 --> Loader Class Initialized
DEBUG - 2011-06-17 11:03:45 --> Controller Class Initialized
DEBUG - 2011-06-17 11:03:45 --> Model Class Initialized
DEBUG - 2011-06-17 11:03:45 --> Model Class Initialized
DEBUG - 2011-06-17 11:03:45 --> Model Class Initialized
DEBUG - 2011-06-17 11:03:45 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-06-17 11:03:45 --> Database Driver Class Initialized
DEBUG - 2011-06-17 11:03:45 --> File loaded: application/views/table/main.php
DEBUG - 2011-06-17 11:03:45 --> Helper loaded: url_helper
DEBUG - 2011-06-17 11:03:45 --> File loaded: application/views/common/header.php
DEBUG - 2011-06-17 11:03:45 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-06-17 11:03:45 --> File loaded: application/views/common/footer.php
DEBUG - 2011-06-17 11:03:45 --> File loaded: application/views/layout/main.php
DEBUG - 2011-06-17 11:03:45 --> Final output sent to browser
DEBUG - 2011-06-17 11:03:45 --> Total execution time: 0.3388
DEBUG - 2011-06-17 11:03:46 --> Config Class Initialized
DEBUG - 2011-06-17 11:03:46 --> Hooks Class Initialized
DEBUG - 2011-06-17 11:03:46 --> Utf8 Class Initialized
DEBUG - 2011-06-17 11:03:46 --> UTF-8 Support Enabled
DEBUG - 2011-06-17 11:03:46 --> URI Class Initialized
DEBUG - 2011-06-17 11:03:46 --> Router Class Initialized
DEBUG - 2011-06-17 11:03:46 --> Output Class Initialized
DEBUG - 2011-06-17 11:03:46 --> Input Class Initialized
DEBUG - 2011-06-17 11:03:46 --> Global POST and COOKIE data sanitized
DEBUG - 2011-06-17 11:03:46 --> Language Class Initialized
DEBUG - 2011-06-17 11:03:46 --> Loader Class Initialized
DEBUG - 2011-06-17 11:03:46 --> Controller Class Initialized
DEBUG - 2011-06-17 11:03:46 --> Model Class Initialized
DEBUG - 2011-06-17 11:03:46 --> Model Class Initialized
DEBUG - 2011-06-17 11:03:46 --> Model Class Initialized
DEBUG - 2011-06-17 11:03:46 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-06-17 11:03:46 --> Database Driver Class Initialized
DEBUG - 2011-06-17 11:03:46 --> File loaded: application/views/table/main.php
DEBUG - 2011-06-17 11:03:46 --> Helper loaded: url_helper
DEBUG - 2011-06-17 11:03:46 --> File loaded: application/views/common/header.php
DEBUG - 2011-06-17 11:03:46 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-06-17 11:03:46 --> File loaded: application/views/common/footer.php
DEBUG - 2011-06-17 11:03:46 --> File loaded: application/views/layout/main.php
DEBUG - 2011-06-17 11:03:46 --> Final output sent to browser
DEBUG - 2011-06-17 11:03:46 --> Total execution time: 0.0559
DEBUG - 2011-06-17 11:03:50 --> Config Class Initialized
DEBUG - 2011-06-17 11:03:50 --> Hooks Class Initialized
DEBUG - 2011-06-17 11:03:50 --> Utf8 Class Initialized
DEBUG - 2011-06-17 11:03:50 --> UTF-8 Support Enabled
DEBUG - 2011-06-17 11:03:50 --> URI Class Initialized
DEBUG - 2011-06-17 11:03:50 --> Router Class Initialized
ERROR - 2011-06-17 11:03:50 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-06-17 11:03:56 --> Config Class Initialized
DEBUG - 2011-06-17 11:03:56 --> Hooks Class Initialized
DEBUG - 2011-06-17 11:03:56 --> Utf8 Class Initialized
DEBUG - 2011-06-17 11:03:56 --> UTF-8 Support Enabled
DEBUG - 2011-06-17 11:03:56 --> URI Class Initialized
DEBUG - 2011-06-17 11:03:56 --> Router Class Initialized
DEBUG - 2011-06-17 11:03:56 --> Output Class Initialized
DEBUG - 2011-06-17 11:03:56 --> Input Class Initialized
DEBUG - 2011-06-17 11:03:56 --> Global POST and COOKIE data sanitized
DEBUG - 2011-06-17 11:03:56 --> Language Class Initialized
DEBUG - 2011-06-17 11:03:56 --> Loader Class Initialized
DEBUG - 2011-06-17 11:03:56 --> Controller Class Initialized
DEBUG - 2011-06-17 11:03:56 --> Model Class Initialized
DEBUG - 2011-06-17 11:03:56 --> Model Class Initialized
DEBUG - 2011-06-17 11:03:56 --> Model Class Initialized
DEBUG - 2011-06-17 11:03:56 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-06-17 11:03:56 --> Database Driver Class Initialized
DEBUG - 2011-06-17 11:03:57 --> File loaded: application/views/table/main.php
DEBUG - 2011-06-17 11:03:57 --> Helper loaded: url_helper
DEBUG - 2011-06-17 11:03:57 --> File loaded: application/views/common/header.php
DEBUG - 2011-06-17 11:03:57 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-06-17 11:03:57 --> File loaded: application/views/common/footer.php
DEBUG - 2011-06-17 11:03:57 --> File loaded: application/views/layout/main.php
DEBUG - 2011-06-17 11:03:57 --> Final output sent to browser
DEBUG - 2011-06-17 11:03:57 --> Total execution time: 0.2308
DEBUG - 2011-06-17 11:03:59 --> Config Class Initialized
DEBUG - 2011-06-17 11:03:59 --> Hooks Class Initialized
DEBUG - 2011-06-17 11:03:59 --> Utf8 Class Initialized
DEBUG - 2011-06-17 11:03:59 --> UTF-8 Support Enabled
DEBUG - 2011-06-17 11:03:59 --> URI Class Initialized
DEBUG - 2011-06-17 11:03:59 --> Router Class Initialized
DEBUG - 2011-06-17 11:03:59 --> Output Class Initialized
DEBUG - 2011-06-17 11:03:59 --> Input Class Initialized
DEBUG - 2011-06-17 11:03:59 --> Global POST and COOKIE data sanitized
DEBUG - 2011-06-17 11:03:59 --> Language Class Initialized
DEBUG - 2011-06-17 11:03:59 --> Loader Class Initialized
DEBUG - 2011-06-17 11:03:59 --> Controller Class Initialized
DEBUG - 2011-06-17 11:03:59 --> Model Class Initialized
DEBUG - 2011-06-17 11:03:59 --> Model Class Initialized
DEBUG - 2011-06-17 11:03:59 --> Model Class Initialized
DEBUG - 2011-06-17 11:03:59 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-06-17 11:03:59 --> Database Driver Class Initialized
DEBUG - 2011-06-17 11:03:59 --> File loaded: application/views/table/main.php
DEBUG - 2011-06-17 11:03:59 --> Helper loaded: url_helper
DEBUG - 2011-06-17 11:03:59 --> File loaded: application/views/common/header.php
DEBUG - 2011-06-17 11:03:59 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-06-17 11:03:59 --> File loaded: application/views/common/footer.php
DEBUG - 2011-06-17 11:03:59 --> File loaded: application/views/layout/main.php
DEBUG - 2011-06-17 11:03:59 --> Final output sent to browser
DEBUG - 2011-06-17 11:03:59 --> Total execution time: 0.0465
DEBUG - 2011-06-17 11:03:59 --> Config Class Initialized
DEBUG - 2011-06-17 11:03:59 --> Hooks Class Initialized
DEBUG - 2011-06-17 11:03:59 --> Utf8 Class Initialized
DEBUG - 2011-06-17 11:03:59 --> UTF-8 Support Enabled
DEBUG - 2011-06-17 11:03:59 --> URI Class Initialized
DEBUG - 2011-06-17 11:03:59 --> Router Class Initialized
ERROR - 2011-06-17 11:03:59 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-06-17 11:04:12 --> Config Class Initialized
DEBUG - 2011-06-17 11:04:12 --> Hooks Class Initialized
DEBUG - 2011-06-17 11:04:12 --> Utf8 Class Initialized
DEBUG - 2011-06-17 11:04:12 --> UTF-8 Support Enabled
DEBUG - 2011-06-17 11:04:12 --> URI Class Initialized
DEBUG - 2011-06-17 11:04:12 --> Router Class Initialized
DEBUG - 2011-06-17 11:04:12 --> Output Class Initialized
DEBUG - 2011-06-17 11:04:12 --> Input Class Initialized
DEBUG - 2011-06-17 11:04:12 --> Global POST and COOKIE data sanitized
DEBUG - 2011-06-17 11:04:12 --> Language Class Initialized
DEBUG - 2011-06-17 11:04:12 --> Loader Class Initialized
DEBUG - 2011-06-17 11:04:12 --> Controller Class Initialized
DEBUG - 2011-06-17 11:04:12 --> Model Class Initialized
DEBUG - 2011-06-17 11:04:12 --> Model Class Initialized
DEBUG - 2011-06-17 11:04:12 --> Model Class Initialized
DEBUG - 2011-06-17 11:04:12 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-06-17 11:04:12 --> Database Driver Class Initialized
DEBUG - 2011-06-17 11:04:12 --> File loaded: application/views/table/main.php
DEBUG - 2011-06-17 11:04:12 --> Helper loaded: url_helper
DEBUG - 2011-06-17 11:04:12 --> File loaded: application/views/common/header.php
DEBUG - 2011-06-17 11:04:12 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-06-17 11:04:12 --> File loaded: application/views/common/footer.php
DEBUG - 2011-06-17 11:04:12 --> File loaded: application/views/layout/main.php
DEBUG - 2011-06-17 11:04:12 --> Final output sent to browser
DEBUG - 2011-06-17 11:04:12 --> Total execution time: 0.2328
DEBUG - 2011-06-17 11:04:15 --> Config Class Initialized
DEBUG - 2011-06-17 11:04:15 --> Hooks Class Initialized
DEBUG - 2011-06-17 11:04:15 --> Utf8 Class Initialized
DEBUG - 2011-06-17 11:04:15 --> UTF-8 Support Enabled
DEBUG - 2011-06-17 11:04:15 --> URI Class Initialized
DEBUG - 2011-06-17 11:04:15 --> Router Class Initialized
DEBUG - 2011-06-17 11:04:15 --> Output Class Initialized
DEBUG - 2011-06-17 11:04:15 --> Input Class Initialized
DEBUG - 2011-06-17 11:04:15 --> Global POST and COOKIE data sanitized
DEBUG - 2011-06-17 11:04:15 --> Language Class Initialized
DEBUG - 2011-06-17 11:04:15 --> Loader Class Initialized
DEBUG - 2011-06-17 11:04:15 --> Controller Class Initialized
DEBUG - 2011-06-17 11:04:15 --> Model Class Initialized
DEBUG - 2011-06-17 11:04:15 --> Model Class Initialized
DEBUG - 2011-06-17 11:04:15 --> Model Class Initialized
DEBUG - 2011-06-17 11:04:15 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-06-17 11:04:15 --> Database Driver Class Initialized
DEBUG - 2011-06-17 11:04:15 --> File loaded: application/views/table/main.php
DEBUG - 2011-06-17 11:04:15 --> Helper loaded: url_helper
DEBUG - 2011-06-17 11:04:15 --> File loaded: application/views/common/header.php
DEBUG - 2011-06-17 11:04:15 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-06-17 11:04:15 --> File loaded: application/views/common/footer.php
DEBUG - 2011-06-17 11:04:15 --> File loaded: application/views/layout/main.php
DEBUG - 2011-06-17 11:04:15 --> Final output sent to browser
DEBUG - 2011-06-17 11:04:15 --> Total execution time: 0.0439
DEBUG - 2011-06-17 11:04:15 --> Config Class Initialized
DEBUG - 2011-06-17 11:04:15 --> Hooks Class Initialized
DEBUG - 2011-06-17 11:04:15 --> Utf8 Class Initialized
DEBUG - 2011-06-17 11:04:15 --> UTF-8 Support Enabled
DEBUG - 2011-06-17 11:04:15 --> URI Class Initialized
DEBUG - 2011-06-17 11:04:15 --> Router Class Initialized
ERROR - 2011-06-17 11:04:15 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-06-17 11:04:23 --> Config Class Initialized
DEBUG - 2011-06-17 11:04:23 --> Hooks Class Initialized
DEBUG - 2011-06-17 11:04:23 --> Utf8 Class Initialized
DEBUG - 2011-06-17 11:04:23 --> UTF-8 Support Enabled
DEBUG - 2011-06-17 11:04:23 --> URI Class Initialized
DEBUG - 2011-06-17 11:04:23 --> Router Class Initialized
DEBUG - 2011-06-17 11:04:23 --> Output Class Initialized
DEBUG - 2011-06-17 11:04:23 --> Input Class Initialized
DEBUG - 2011-06-17 11:04:23 --> Global POST and COOKIE data sanitized
DEBUG - 2011-06-17 11:04:23 --> Language Class Initialized
DEBUG - 2011-06-17 11:04:23 --> Loader Class Initialized
DEBUG - 2011-06-17 11:04:23 --> Controller Class Initialized
DEBUG - 2011-06-17 11:04:23 --> Model Class Initialized
DEBUG - 2011-06-17 11:04:23 --> Model Class Initialized
DEBUG - 2011-06-17 11:04:23 --> Model Class Initialized
DEBUG - 2011-06-17 11:04:23 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-06-17 11:04:23 --> Database Driver Class Initialized
DEBUG - 2011-06-17 11:04:23 --> File loaded: application/views/table/main.php
DEBUG - 2011-06-17 11:04:23 --> Helper loaded: url_helper
DEBUG - 2011-06-17 11:04:23 --> File loaded: application/views/common/header.php
DEBUG - 2011-06-17 11:04:23 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-06-17 11:04:23 --> File loaded: application/views/common/footer.php
DEBUG - 2011-06-17 11:04:23 --> File loaded: application/views/layout/main.php
DEBUG - 2011-06-17 11:04:23 --> Final output sent to browser
DEBUG - 2011-06-17 11:04:23 --> Total execution time: 0.2554
DEBUG - 2011-06-17 11:04:24 --> Config Class Initialized
DEBUG - 2011-06-17 11:04:24 --> Hooks Class Initialized
DEBUG - 2011-06-17 11:04:24 --> Utf8 Class Initialized
DEBUG - 2011-06-17 11:04:24 --> UTF-8 Support Enabled
DEBUG - 2011-06-17 11:04:24 --> URI Class Initialized
DEBUG - 2011-06-17 11:04:24 --> Router Class Initialized
DEBUG - 2011-06-17 11:04:24 --> Output Class Initialized
DEBUG - 2011-06-17 11:04:24 --> Input Class Initialized
DEBUG - 2011-06-17 11:04:24 --> Global POST and COOKIE data sanitized
DEBUG - 2011-06-17 11:04:24 --> Language Class Initialized
DEBUG - 2011-06-17 11:04:24 --> Loader Class Initialized
DEBUG - 2011-06-17 11:04:24 --> Controller Class Initialized
DEBUG - 2011-06-17 11:04:24 --> Model Class Initialized
DEBUG - 2011-06-17 11:04:24 --> Model Class Initialized
DEBUG - 2011-06-17 11:04:24 --> Model Class Initialized
DEBUG - 2011-06-17 11:04:24 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-06-17 11:04:24 --> Database Driver Class Initialized
DEBUG - 2011-06-17 11:04:24 --> File loaded: application/views/table/main.php
DEBUG - 2011-06-17 11:04:24 --> Helper loaded: url_helper
DEBUG - 2011-06-17 11:04:24 --> File loaded: application/views/common/header.php
DEBUG - 2011-06-17 11:04:24 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-06-17 11:04:24 --> File loaded: application/views/common/footer.php
DEBUG - 2011-06-17 11:04:24 --> File loaded: application/views/layout/main.php
DEBUG - 2011-06-17 11:04:24 --> Final output sent to browser
DEBUG - 2011-06-17 11:04:24 --> Total execution time: 0.0532
DEBUG - 2011-06-17 11:04:25 --> Config Class Initialized
DEBUG - 2011-06-17 11:04:25 --> Hooks Class Initialized
DEBUG - 2011-06-17 11:04:25 --> Utf8 Class Initialized
DEBUG - 2011-06-17 11:04:25 --> UTF-8 Support Enabled
DEBUG - 2011-06-17 11:04:25 --> URI Class Initialized
DEBUG - 2011-06-17 11:04:25 --> Router Class Initialized
ERROR - 2011-06-17 11:04:25 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-06-17 11:04:40 --> Config Class Initialized
DEBUG - 2011-06-17 11:04:40 --> Hooks Class Initialized
DEBUG - 2011-06-17 11:04:40 --> Utf8 Class Initialized
DEBUG - 2011-06-17 11:04:40 --> UTF-8 Support Enabled
DEBUG - 2011-06-17 11:04:40 --> URI Class Initialized
DEBUG - 2011-06-17 11:04:40 --> Router Class Initialized
DEBUG - 2011-06-17 11:04:40 --> Output Class Initialized
DEBUG - 2011-06-17 11:04:40 --> Input Class Initialized
DEBUG - 2011-06-17 11:04:40 --> Global POST and COOKIE data sanitized
DEBUG - 2011-06-17 11:04:40 --> Language Class Initialized
DEBUG - 2011-06-17 11:04:40 --> Loader Class Initialized
DEBUG - 2011-06-17 11:04:40 --> Controller Class Initialized
DEBUG - 2011-06-17 11:04:40 --> Model Class Initialized
DEBUG - 2011-06-17 11:04:40 --> Model Class Initialized
DEBUG - 2011-06-17 11:04:40 --> Model Class Initialized
DEBUG - 2011-06-17 11:04:40 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-06-17 11:04:40 --> Database Driver Class Initialized
DEBUG - 2011-06-17 11:04:40 --> File loaded: application/views/table/main.php
DEBUG - 2011-06-17 11:04:40 --> Helper loaded: url_helper
DEBUG - 2011-06-17 11:04:40 --> File loaded: application/views/common/header.php
DEBUG - 2011-06-17 11:04:40 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-06-17 11:04:40 --> File loaded: application/views/common/footer.php
DEBUG - 2011-06-17 11:04:40 --> File loaded: application/views/layout/main.php
DEBUG - 2011-06-17 11:04:40 --> Final output sent to browser
DEBUG - 2011-06-17 11:04:40 --> Total execution time: 0.3382
DEBUG - 2011-06-17 11:04:42 --> Config Class Initialized
DEBUG - 2011-06-17 11:04:42 --> Hooks Class Initialized
DEBUG - 2011-06-17 11:04:42 --> Utf8 Class Initialized
DEBUG - 2011-06-17 11:04:42 --> UTF-8 Support Enabled
DEBUG - 2011-06-17 11:04:42 --> URI Class Initialized
DEBUG - 2011-06-17 11:04:42 --> Router Class Initialized
ERROR - 2011-06-17 11:04:42 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-06-17 11:04:43 --> Config Class Initialized
DEBUG - 2011-06-17 11:04:43 --> Hooks Class Initialized
DEBUG - 2011-06-17 11:04:43 --> Utf8 Class Initialized
DEBUG - 2011-06-17 11:04:43 --> UTF-8 Support Enabled
DEBUG - 2011-06-17 11:04:43 --> URI Class Initialized
DEBUG - 2011-06-17 11:04:43 --> Router Class Initialized
DEBUG - 2011-06-17 11:04:43 --> Output Class Initialized
DEBUG - 2011-06-17 11:04:43 --> Input Class Initialized
DEBUG - 2011-06-17 11:04:43 --> Global POST and COOKIE data sanitized
DEBUG - 2011-06-17 11:04:43 --> Language Class Initialized
DEBUG - 2011-06-17 11:04:43 --> Loader Class Initialized
DEBUG - 2011-06-17 11:04:43 --> Controller Class Initialized
DEBUG - 2011-06-17 11:04:43 --> Model Class Initialized
DEBUG - 2011-06-17 11:04:43 --> Model Class Initialized
DEBUG - 2011-06-17 11:04:43 --> Model Class Initialized
DEBUG - 2011-06-17 11:04:43 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-06-17 11:04:43 --> Database Driver Class Initialized
DEBUG - 2011-06-17 11:04:43 --> File loaded: application/views/table/main.php
DEBUG - 2011-06-17 11:04:43 --> Helper loaded: url_helper
DEBUG - 2011-06-17 11:04:43 --> File loaded: application/views/common/header.php
DEBUG - 2011-06-17 11:04:43 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-06-17 11:04:43 --> File loaded: application/views/common/footer.php
DEBUG - 2011-06-17 11:04:43 --> File loaded: application/views/layout/main.php
DEBUG - 2011-06-17 11:04:43 --> Final output sent to browser
DEBUG - 2011-06-17 11:04:43 --> Total execution time: 0.0575
DEBUG - 2011-06-17 11:04:53 --> Config Class Initialized
DEBUG - 2011-06-17 11:04:53 --> Hooks Class Initialized
DEBUG - 2011-06-17 11:04:53 --> Utf8 Class Initialized
DEBUG - 2011-06-17 11:04:53 --> UTF-8 Support Enabled
DEBUG - 2011-06-17 11:04:53 --> URI Class Initialized
DEBUG - 2011-06-17 11:04:53 --> Router Class Initialized
DEBUG - 2011-06-17 11:04:53 --> Output Class Initialized
DEBUG - 2011-06-17 11:04:53 --> Input Class Initialized
DEBUG - 2011-06-17 11:04:53 --> Global POST and COOKIE data sanitized
DEBUG - 2011-06-17 11:04:53 --> Language Class Initialized
DEBUG - 2011-06-17 11:04:53 --> Loader Class Initialized
DEBUG - 2011-06-17 11:04:53 --> Controller Class Initialized
DEBUG - 2011-06-17 11:04:53 --> Model Class Initialized
DEBUG - 2011-06-17 11:04:53 --> Model Class Initialized
DEBUG - 2011-06-17 11:04:53 --> Model Class Initialized
DEBUG - 2011-06-17 11:04:53 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-06-17 11:04:53 --> Database Driver Class Initialized
DEBUG - 2011-06-17 11:04:54 --> File loaded: application/views/table/main.php
DEBUG - 2011-06-17 11:04:54 --> Helper loaded: url_helper
DEBUG - 2011-06-17 11:04:54 --> File loaded: application/views/common/header.php
DEBUG - 2011-06-17 11:04:54 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-06-17 11:04:54 --> File loaded: application/views/common/footer.php
DEBUG - 2011-06-17 11:04:54 --> File loaded: application/views/layout/main.php
DEBUG - 2011-06-17 11:04:54 --> Final output sent to browser
DEBUG - 2011-06-17 11:04:54 --> Total execution time: 0.7383
DEBUG - 2011-06-17 11:04:56 --> Config Class Initialized
DEBUG - 2011-06-17 11:04:56 --> Hooks Class Initialized
DEBUG - 2011-06-17 11:04:56 --> Utf8 Class Initialized
DEBUG - 2011-06-17 11:04:56 --> UTF-8 Support Enabled
DEBUG - 2011-06-17 11:04:56 --> URI Class Initialized
DEBUG - 2011-06-17 11:04:56 --> Router Class Initialized
ERROR - 2011-06-17 11:04:56 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-06-17 11:04:57 --> Config Class Initialized
DEBUG - 2011-06-17 11:04:57 --> Hooks Class Initialized
DEBUG - 2011-06-17 11:04:57 --> Utf8 Class Initialized
DEBUG - 2011-06-17 11:04:57 --> UTF-8 Support Enabled
DEBUG - 2011-06-17 11:04:57 --> URI Class Initialized
DEBUG - 2011-06-17 11:04:57 --> Router Class Initialized
DEBUG - 2011-06-17 11:04:57 --> Output Class Initialized
DEBUG - 2011-06-17 11:04:57 --> Input Class Initialized
DEBUG - 2011-06-17 11:04:57 --> Global POST and COOKIE data sanitized
DEBUG - 2011-06-17 11:04:57 --> Language Class Initialized
DEBUG - 2011-06-17 11:04:57 --> Loader Class Initialized
DEBUG - 2011-06-17 11:04:57 --> Controller Class Initialized
DEBUG - 2011-06-17 11:04:57 --> Model Class Initialized
DEBUG - 2011-06-17 11:04:57 --> Model Class Initialized
DEBUG - 2011-06-17 11:04:57 --> Model Class Initialized
DEBUG - 2011-06-17 11:04:57 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-06-17 11:04:57 --> Database Driver Class Initialized
DEBUG - 2011-06-17 11:04:57 --> File loaded: application/views/table/main.php
DEBUG - 2011-06-17 11:04:57 --> Helper loaded: url_helper
DEBUG - 2011-06-17 11:04:57 --> File loaded: application/views/common/header.php
DEBUG - 2011-06-17 11:04:57 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-06-17 11:04:57 --> File loaded: application/views/common/footer.php
DEBUG - 2011-06-17 11:04:57 --> File loaded: application/views/layout/main.php
DEBUG - 2011-06-17 11:04:57 --> Final output sent to browser
DEBUG - 2011-06-17 11:04:57 --> Total execution time: 0.0952
DEBUG - 2011-06-17 11:05:03 --> Config Class Initialized
DEBUG - 2011-06-17 11:05:03 --> Hooks Class Initialized
DEBUG - 2011-06-17 11:05:03 --> Utf8 Class Initialized
DEBUG - 2011-06-17 11:05:03 --> UTF-8 Support Enabled
DEBUG - 2011-06-17 11:05:03 --> URI Class Initialized
DEBUG - 2011-06-17 11:05:03 --> Router Class Initialized
DEBUG - 2011-06-17 11:05:03 --> Output Class Initialized
DEBUG - 2011-06-17 11:05:03 --> Input Class Initialized
DEBUG - 2011-06-17 11:05:03 --> Global POST and COOKIE data sanitized
DEBUG - 2011-06-17 11:05:03 --> Language Class Initialized
DEBUG - 2011-06-17 11:05:03 --> Loader Class Initialized
DEBUG - 2011-06-17 11:05:03 --> Controller Class Initialized
DEBUG - 2011-06-17 11:05:03 --> Model Class Initialized
DEBUG - 2011-06-17 11:05:03 --> Model Class Initialized
DEBUG - 2011-06-17 11:05:03 --> Model Class Initialized
DEBUG - 2011-06-17 11:05:03 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-06-17 11:05:03 --> Database Driver Class Initialized
DEBUG - 2011-06-17 11:05:03 --> File loaded: application/views/table/main.php
DEBUG - 2011-06-17 11:05:03 --> Helper loaded: url_helper
DEBUG - 2011-06-17 11:05:03 --> File loaded: application/views/common/header.php
DEBUG - 2011-06-17 11:05:03 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-06-17 11:05:03 --> File loaded: application/views/common/footer.php
DEBUG - 2011-06-17 11:05:03 --> File loaded: application/views/layout/main.php
DEBUG - 2011-06-17 11:05:03 --> Final output sent to browser
DEBUG - 2011-06-17 11:05:03 --> Total execution time: 0.4574
DEBUG - 2011-06-17 11:05:06 --> Config Class Initialized
DEBUG - 2011-06-17 11:05:06 --> Hooks Class Initialized
DEBUG - 2011-06-17 11:05:06 --> Utf8 Class Initialized
DEBUG - 2011-06-17 11:05:06 --> UTF-8 Support Enabled
DEBUG - 2011-06-17 11:05:06 --> URI Class Initialized
DEBUG - 2011-06-17 11:05:06 --> Router Class Initialized
DEBUG - 2011-06-17 11:05:06 --> Output Class Initialized
DEBUG - 2011-06-17 11:05:06 --> Input Class Initialized
DEBUG - 2011-06-17 11:05:06 --> Global POST and COOKIE data sanitized
DEBUG - 2011-06-17 11:05:06 --> Language Class Initialized
DEBUG - 2011-06-17 11:05:06 --> Loader Class Initialized
DEBUG - 2011-06-17 11:05:06 --> Controller Class Initialized
DEBUG - 2011-06-17 11:05:06 --> Model Class Initialized
DEBUG - 2011-06-17 11:05:06 --> Model Class Initialized
DEBUG - 2011-06-17 11:05:06 --> Model Class Initialized
DEBUG - 2011-06-17 11:05:06 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-06-17 11:05:06 --> Database Driver Class Initialized
DEBUG - 2011-06-17 11:05:06 --> File loaded: application/views/table/main.php
DEBUG - 2011-06-17 11:05:06 --> Helper loaded: url_helper
DEBUG - 2011-06-17 11:05:06 --> File loaded: application/views/common/header.php
DEBUG - 2011-06-17 11:05:06 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-06-17 11:05:06 --> File loaded: application/views/common/footer.php
DEBUG - 2011-06-17 11:05:06 --> File loaded: application/views/layout/main.php
DEBUG - 2011-06-17 11:05:06 --> Final output sent to browser
DEBUG - 2011-06-17 11:05:06 --> Total execution time: 0.0471
DEBUG - 2011-06-17 11:05:07 --> Config Class Initialized
DEBUG - 2011-06-17 11:05:07 --> Hooks Class Initialized
DEBUG - 2011-06-17 11:05:07 --> Utf8 Class Initialized
DEBUG - 2011-06-17 11:05:07 --> UTF-8 Support Enabled
DEBUG - 2011-06-17 11:05:07 --> URI Class Initialized
DEBUG - 2011-06-17 11:05:07 --> Router Class Initialized
ERROR - 2011-06-17 11:05:07 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-06-17 11:05:28 --> Config Class Initialized
DEBUG - 2011-06-17 11:05:28 --> Hooks Class Initialized
DEBUG - 2011-06-17 11:05:28 --> Utf8 Class Initialized
DEBUG - 2011-06-17 11:05:28 --> UTF-8 Support Enabled
DEBUG - 2011-06-17 11:05:28 --> URI Class Initialized
DEBUG - 2011-06-17 11:05:28 --> Router Class Initialized
DEBUG - 2011-06-17 11:05:28 --> Output Class Initialized
DEBUG - 2011-06-17 11:05:28 --> Input Class Initialized
DEBUG - 2011-06-17 11:05:28 --> Global POST and COOKIE data sanitized
DEBUG - 2011-06-17 11:05:28 --> Language Class Initialized
DEBUG - 2011-06-17 11:05:28 --> Loader Class Initialized
DEBUG - 2011-06-17 11:05:28 --> Controller Class Initialized
DEBUG - 2011-06-17 11:05:28 --> Model Class Initialized
DEBUG - 2011-06-17 11:05:28 --> Model Class Initialized
DEBUG - 2011-06-17 11:05:28 --> Model Class Initialized
DEBUG - 2011-06-17 11:05:28 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-06-17 11:05:28 --> Database Driver Class Initialized
DEBUG - 2011-06-17 11:05:28 --> File loaded: application/views/table/main.php
DEBUG - 2011-06-17 11:05:28 --> Helper loaded: url_helper
DEBUG - 2011-06-17 11:05:28 --> File loaded: application/views/common/header.php
DEBUG - 2011-06-17 11:05:28 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-06-17 11:05:28 --> File loaded: application/views/common/footer.php
DEBUG - 2011-06-17 11:05:28 --> File loaded: application/views/layout/main.php
DEBUG - 2011-06-17 11:05:28 --> Final output sent to browser
DEBUG - 2011-06-17 11:05:28 --> Total execution time: 0.2598
DEBUG - 2011-06-17 11:05:30 --> Config Class Initialized
DEBUG - 2011-06-17 11:05:30 --> Hooks Class Initialized
DEBUG - 2011-06-17 11:05:30 --> Utf8 Class Initialized
DEBUG - 2011-06-17 11:05:30 --> UTF-8 Support Enabled
DEBUG - 2011-06-17 11:05:30 --> URI Class Initialized
DEBUG - 2011-06-17 11:05:30 --> Router Class Initialized
DEBUG - 2011-06-17 11:05:30 --> Output Class Initialized
DEBUG - 2011-06-17 11:05:30 --> Input Class Initialized
DEBUG - 2011-06-17 11:05:30 --> Global POST and COOKIE data sanitized
DEBUG - 2011-06-17 11:05:30 --> Language Class Initialized
DEBUG - 2011-06-17 11:05:30 --> Loader Class Initialized
DEBUG - 2011-06-17 11:05:30 --> Controller Class Initialized
DEBUG - 2011-06-17 11:05:30 --> Model Class Initialized
DEBUG - 2011-06-17 11:05:30 --> Model Class Initialized
DEBUG - 2011-06-17 11:05:30 --> Model Class Initialized
DEBUG - 2011-06-17 11:05:30 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-06-17 11:05:30 --> Database Driver Class Initialized
DEBUG - 2011-06-17 11:05:30 --> File loaded: application/views/table/main.php
DEBUG - 2011-06-17 11:05:30 --> Helper loaded: url_helper
DEBUG - 2011-06-17 11:05:30 --> File loaded: application/views/common/header.php
DEBUG - 2011-06-17 11:05:30 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-06-17 11:05:30 --> File loaded: application/views/common/footer.php
DEBUG - 2011-06-17 11:05:30 --> File loaded: application/views/layout/main.php
DEBUG - 2011-06-17 11:05:30 --> Final output sent to browser
DEBUG - 2011-06-17 11:05:30 --> Total execution time: 0.1320
DEBUG - 2011-06-17 11:05:30 --> Config Class Initialized
DEBUG - 2011-06-17 11:05:30 --> Hooks Class Initialized
DEBUG - 2011-06-17 11:05:30 --> Utf8 Class Initialized
DEBUG - 2011-06-17 11:05:30 --> UTF-8 Support Enabled
DEBUG - 2011-06-17 11:05:30 --> URI Class Initialized
DEBUG - 2011-06-17 11:05:30 --> Router Class Initialized
ERROR - 2011-06-17 11:05:30 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-06-17 11:05:40 --> Config Class Initialized
DEBUG - 2011-06-17 11:05:40 --> Hooks Class Initialized
DEBUG - 2011-06-17 11:05:40 --> Utf8 Class Initialized
DEBUG - 2011-06-17 11:05:40 --> UTF-8 Support Enabled
DEBUG - 2011-06-17 11:05:40 --> URI Class Initialized
DEBUG - 2011-06-17 11:05:40 --> Router Class Initialized
DEBUG - 2011-06-17 11:05:40 --> Output Class Initialized
DEBUG - 2011-06-17 11:05:40 --> Input Class Initialized
DEBUG - 2011-06-17 11:05:40 --> Global POST and COOKIE data sanitized
DEBUG - 2011-06-17 11:05:40 --> Language Class Initialized
DEBUG - 2011-06-17 11:05:40 --> Loader Class Initialized
DEBUG - 2011-06-17 11:05:40 --> Controller Class Initialized
DEBUG - 2011-06-17 11:05:40 --> Model Class Initialized
DEBUG - 2011-06-17 11:05:40 --> Model Class Initialized
DEBUG - 2011-06-17 11:05:40 --> Model Class Initialized
DEBUG - 2011-06-17 11:05:40 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-06-17 11:05:40 --> Database Driver Class Initialized
DEBUG - 2011-06-17 11:05:41 --> File loaded: application/views/table/main.php
DEBUG - 2011-06-17 11:05:41 --> Helper loaded: url_helper
DEBUG - 2011-06-17 11:05:41 --> File loaded: application/views/common/header.php
DEBUG - 2011-06-17 11:05:41 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-06-17 11:05:41 --> File loaded: application/views/common/footer.php
DEBUG - 2011-06-17 11:05:41 --> File loaded: application/views/layout/main.php
DEBUG - 2011-06-17 11:05:41 --> Final output sent to browser
DEBUG - 2011-06-17 11:05:41 --> Total execution time: 0.4045
DEBUG - 2011-06-17 11:05:42 --> Config Class Initialized
DEBUG - 2011-06-17 11:05:42 --> Hooks Class Initialized
DEBUG - 2011-06-17 11:05:42 --> Utf8 Class Initialized
DEBUG - 2011-06-17 11:05:42 --> UTF-8 Support Enabled
DEBUG - 2011-06-17 11:05:42 --> URI Class Initialized
DEBUG - 2011-06-17 11:05:42 --> Router Class Initialized
ERROR - 2011-06-17 11:05:42 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-06-17 11:05:44 --> Config Class Initialized
DEBUG - 2011-06-17 11:05:44 --> Hooks Class Initialized
DEBUG - 2011-06-17 11:05:44 --> Utf8 Class Initialized
DEBUG - 2011-06-17 11:05:44 --> UTF-8 Support Enabled
DEBUG - 2011-06-17 11:05:44 --> URI Class Initialized
DEBUG - 2011-06-17 11:05:44 --> Router Class Initialized
DEBUG - 2011-06-17 11:05:44 --> Output Class Initialized
DEBUG - 2011-06-17 11:05:44 --> Input Class Initialized
DEBUG - 2011-06-17 11:05:44 --> Global POST and COOKIE data sanitized
DEBUG - 2011-06-17 11:05:44 --> Language Class Initialized
DEBUG - 2011-06-17 11:05:44 --> Loader Class Initialized
DEBUG - 2011-06-17 11:05:44 --> Controller Class Initialized
DEBUG - 2011-06-17 11:05:44 --> Model Class Initialized
DEBUG - 2011-06-17 11:05:44 --> Model Class Initialized
DEBUG - 2011-06-17 11:05:44 --> Model Class Initialized
DEBUG - 2011-06-17 11:05:44 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-06-17 11:05:44 --> Database Driver Class Initialized
DEBUG - 2011-06-17 11:05:44 --> File loaded: application/views/table/main.php
DEBUG - 2011-06-17 11:05:44 --> Helper loaded: url_helper
DEBUG - 2011-06-17 11:05:44 --> File loaded: application/views/common/header.php
DEBUG - 2011-06-17 11:05:44 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-06-17 11:05:44 --> File loaded: application/views/common/footer.php
DEBUG - 2011-06-17 11:05:44 --> File loaded: application/views/layout/main.php
DEBUG - 2011-06-17 11:05:44 --> Final output sent to browser
DEBUG - 2011-06-17 11:05:44 --> Total execution time: 0.1101
DEBUG - 2011-06-17 11:05:50 --> Config Class Initialized
DEBUG - 2011-06-17 11:05:50 --> Hooks Class Initialized
DEBUG - 2011-06-17 11:05:50 --> Utf8 Class Initialized
DEBUG - 2011-06-17 11:05:50 --> UTF-8 Support Enabled
DEBUG - 2011-06-17 11:05:50 --> URI Class Initialized
DEBUG - 2011-06-17 11:05:50 --> Router Class Initialized
DEBUG - 2011-06-17 11:05:50 --> Output Class Initialized
DEBUG - 2011-06-17 11:05:50 --> Input Class Initialized
DEBUG - 2011-06-17 11:05:50 --> Global POST and COOKIE data sanitized
DEBUG - 2011-06-17 11:05:50 --> Language Class Initialized
DEBUG - 2011-06-17 11:05:50 --> Loader Class Initialized
DEBUG - 2011-06-17 11:05:50 --> Controller Class Initialized
DEBUG - 2011-06-17 11:05:50 --> Model Class Initialized
DEBUG - 2011-06-17 11:05:50 --> Model Class Initialized
DEBUG - 2011-06-17 11:05:50 --> Model Class Initialized
DEBUG - 2011-06-17 11:05:50 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-06-17 11:05:50 --> Database Driver Class Initialized
DEBUG - 2011-06-17 11:05:50 --> File loaded: application/views/table/main.php
DEBUG - 2011-06-17 11:05:50 --> Helper loaded: url_helper
DEBUG - 2011-06-17 11:05:50 --> File loaded: application/views/common/header.php
DEBUG - 2011-06-17 11:05:50 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-06-17 11:05:50 --> File loaded: application/views/common/footer.php
DEBUG - 2011-06-17 11:05:50 --> File loaded: application/views/layout/main.php
DEBUG - 2011-06-17 11:05:50 --> Final output sent to browser
DEBUG - 2011-06-17 11:05:50 --> Total execution time: 0.2972
DEBUG - 2011-06-17 11:05:52 --> Config Class Initialized
DEBUG - 2011-06-17 11:05:52 --> Hooks Class Initialized
DEBUG - 2011-06-17 11:05:52 --> Utf8 Class Initialized
DEBUG - 2011-06-17 11:05:52 --> UTF-8 Support Enabled
DEBUG - 2011-06-17 11:05:52 --> URI Class Initialized
DEBUG - 2011-06-17 11:05:52 --> Router Class Initialized
DEBUG - 2011-06-17 11:05:52 --> Output Class Initialized
DEBUG - 2011-06-17 11:05:52 --> Input Class Initialized
DEBUG - 2011-06-17 11:05:52 --> Global POST and COOKIE data sanitized
DEBUG - 2011-06-17 11:05:52 --> Language Class Initialized
DEBUG - 2011-06-17 11:05:52 --> Loader Class Initialized
DEBUG - 2011-06-17 11:05:52 --> Controller Class Initialized
DEBUG - 2011-06-17 11:05:52 --> Model Class Initialized
DEBUG - 2011-06-17 11:05:52 --> Model Class Initialized
DEBUG - 2011-06-17 11:05:52 --> Model Class Initialized
DEBUG - 2011-06-17 11:05:52 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-06-17 11:05:52 --> Database Driver Class Initialized
DEBUG - 2011-06-17 11:05:52 --> File loaded: application/views/table/main.php
DEBUG - 2011-06-17 11:05:52 --> Helper loaded: url_helper
DEBUG - 2011-06-17 11:05:52 --> File loaded: application/views/common/header.php
DEBUG - 2011-06-17 11:05:52 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-06-17 11:05:52 --> File loaded: application/views/common/footer.php
DEBUG - 2011-06-17 11:05:52 --> File loaded: application/views/layout/main.php
DEBUG - 2011-06-17 11:05:52 --> Final output sent to browser
DEBUG - 2011-06-17 11:05:52 --> Total execution time: 0.1237
DEBUG - 2011-06-17 11:05:52 --> Config Class Initialized
DEBUG - 2011-06-17 11:05:52 --> Hooks Class Initialized
DEBUG - 2011-06-17 11:05:52 --> Utf8 Class Initialized
DEBUG - 2011-06-17 11:05:52 --> UTF-8 Support Enabled
DEBUG - 2011-06-17 11:05:52 --> URI Class Initialized
DEBUG - 2011-06-17 11:05:52 --> Router Class Initialized
ERROR - 2011-06-17 11:05:52 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-06-17 11:06:01 --> Config Class Initialized
DEBUG - 2011-06-17 11:06:01 --> Hooks Class Initialized
DEBUG - 2011-06-17 11:06:01 --> Utf8 Class Initialized
DEBUG - 2011-06-17 11:06:01 --> UTF-8 Support Enabled
DEBUG - 2011-06-17 11:06:01 --> URI Class Initialized
DEBUG - 2011-06-17 11:06:01 --> Router Class Initialized
DEBUG - 2011-06-17 11:06:01 --> Output Class Initialized
DEBUG - 2011-06-17 11:06:01 --> Input Class Initialized
DEBUG - 2011-06-17 11:06:01 --> Global POST and COOKIE data sanitized
DEBUG - 2011-06-17 11:06:01 --> Language Class Initialized
DEBUG - 2011-06-17 11:06:01 --> Loader Class Initialized
DEBUG - 2011-06-17 11:06:01 --> Controller Class Initialized
DEBUG - 2011-06-17 11:06:01 --> Model Class Initialized
DEBUG - 2011-06-17 11:06:01 --> Model Class Initialized
DEBUG - 2011-06-17 11:06:01 --> Model Class Initialized
DEBUG - 2011-06-17 11:06:01 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-06-17 11:06:01 --> Database Driver Class Initialized
DEBUG - 2011-06-17 11:06:01 --> File loaded: application/views/table/main.php
DEBUG - 2011-06-17 11:06:01 --> Helper loaded: url_helper
DEBUG - 2011-06-17 11:06:01 --> File loaded: application/views/common/header.php
DEBUG - 2011-06-17 11:06:01 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-06-17 11:06:01 --> File loaded: application/views/common/footer.php
DEBUG - 2011-06-17 11:06:01 --> File loaded: application/views/layout/main.php
DEBUG - 2011-06-17 11:06:01 --> Final output sent to browser
DEBUG - 2011-06-17 11:06:01 --> Total execution time: 0.2757
DEBUG - 2011-06-17 11:06:02 --> Config Class Initialized
DEBUG - 2011-06-17 11:06:02 --> Hooks Class Initialized
DEBUG - 2011-06-17 11:06:02 --> Utf8 Class Initialized
DEBUG - 2011-06-17 11:06:02 --> UTF-8 Support Enabled
DEBUG - 2011-06-17 11:06:02 --> URI Class Initialized
DEBUG - 2011-06-17 11:06:02 --> Router Class Initialized
DEBUG - 2011-06-17 11:06:02 --> Output Class Initialized
DEBUG - 2011-06-17 11:06:02 --> Input Class Initialized
DEBUG - 2011-06-17 11:06:02 --> Global POST and COOKIE data sanitized
DEBUG - 2011-06-17 11:06:02 --> Language Class Initialized
DEBUG - 2011-06-17 11:06:02 --> Loader Class Initialized
DEBUG - 2011-06-17 11:06:02 --> Controller Class Initialized
DEBUG - 2011-06-17 11:06:02 --> Model Class Initialized
DEBUG - 2011-06-17 11:06:02 --> Model Class Initialized
DEBUG - 2011-06-17 11:06:02 --> Model Class Initialized
DEBUG - 2011-06-17 11:06:02 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-06-17 11:06:02 --> Database Driver Class Initialized
DEBUG - 2011-06-17 11:06:02 --> File loaded: application/views/table/main.php
DEBUG - 2011-06-17 11:06:02 --> Helper loaded: url_helper
DEBUG - 2011-06-17 11:06:02 --> File loaded: application/views/common/header.php
DEBUG - 2011-06-17 11:06:02 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-06-17 11:06:02 --> File loaded: application/views/common/footer.php
DEBUG - 2011-06-17 11:06:02 --> File loaded: application/views/layout/main.php
DEBUG - 2011-06-17 11:06:02 --> Final output sent to browser
DEBUG - 2011-06-17 11:06:02 --> Total execution time: 0.0609
DEBUG - 2011-06-17 11:06:03 --> Config Class Initialized
DEBUG - 2011-06-17 11:06:03 --> Hooks Class Initialized
DEBUG - 2011-06-17 11:06:03 --> Utf8 Class Initialized
DEBUG - 2011-06-17 11:06:03 --> UTF-8 Support Enabled
DEBUG - 2011-06-17 11:06:03 --> URI Class Initialized
DEBUG - 2011-06-17 11:06:03 --> Router Class Initialized
ERROR - 2011-06-17 11:06:03 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-06-17 11:06:10 --> Config Class Initialized
DEBUG - 2011-06-17 11:06:10 --> Hooks Class Initialized
DEBUG - 2011-06-17 11:06:10 --> Utf8 Class Initialized
DEBUG - 2011-06-17 11:06:10 --> UTF-8 Support Enabled
DEBUG - 2011-06-17 11:06:10 --> URI Class Initialized
DEBUG - 2011-06-17 11:06:10 --> Router Class Initialized
DEBUG - 2011-06-17 11:06:10 --> Output Class Initialized
DEBUG - 2011-06-17 11:06:10 --> Input Class Initialized
DEBUG - 2011-06-17 11:06:10 --> Global POST and COOKIE data sanitized
DEBUG - 2011-06-17 11:06:10 --> Language Class Initialized
DEBUG - 2011-06-17 11:06:10 --> Loader Class Initialized
DEBUG - 2011-06-17 11:06:10 --> Controller Class Initialized
DEBUG - 2011-06-17 11:06:10 --> Model Class Initialized
DEBUG - 2011-06-17 11:06:10 --> Model Class Initialized
DEBUG - 2011-06-17 11:06:10 --> Model Class Initialized
DEBUG - 2011-06-17 11:06:10 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-06-17 11:06:10 --> Database Driver Class Initialized
DEBUG - 2011-06-17 11:06:10 --> File loaded: application/views/table/main.php
DEBUG - 2011-06-17 11:06:10 --> Helper loaded: url_helper
DEBUG - 2011-06-17 11:06:10 --> File loaded: application/views/common/header.php
DEBUG - 2011-06-17 11:06:10 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-06-17 11:06:10 --> File loaded: application/views/common/footer.php
DEBUG - 2011-06-17 11:06:10 --> File loaded: application/views/layout/main.php
DEBUG - 2011-06-17 11:06:10 --> Final output sent to browser
DEBUG - 2011-06-17 11:06:10 --> Total execution time: 0.1991
DEBUG - 2011-06-17 11:06:11 --> Config Class Initialized
DEBUG - 2011-06-17 11:06:11 --> Hooks Class Initialized
DEBUG - 2011-06-17 11:06:11 --> Utf8 Class Initialized
DEBUG - 2011-06-17 11:06:11 --> UTF-8 Support Enabled
DEBUG - 2011-06-17 11:06:11 --> URI Class Initialized
DEBUG - 2011-06-17 11:06:11 --> Router Class Initialized
DEBUG - 2011-06-17 11:06:11 --> Output Class Initialized
DEBUG - 2011-06-17 11:06:11 --> Input Class Initialized
DEBUG - 2011-06-17 11:06:11 --> Global POST and COOKIE data sanitized
DEBUG - 2011-06-17 11:06:11 --> Language Class Initialized
DEBUG - 2011-06-17 11:06:11 --> Loader Class Initialized
DEBUG - 2011-06-17 11:06:11 --> Controller Class Initialized
DEBUG - 2011-06-17 11:06:11 --> Model Class Initialized
DEBUG - 2011-06-17 11:06:11 --> Model Class Initialized
DEBUG - 2011-06-17 11:06:11 --> Model Class Initialized
DEBUG - 2011-06-17 11:06:11 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-06-17 11:06:11 --> Database Driver Class Initialized
DEBUG - 2011-06-17 11:06:11 --> File loaded: application/views/table/main.php
DEBUG - 2011-06-17 11:06:11 --> Helper loaded: url_helper
DEBUG - 2011-06-17 11:06:11 --> File loaded: application/views/common/header.php
DEBUG - 2011-06-17 11:06:11 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-06-17 11:06:11 --> File loaded: application/views/common/footer.php
DEBUG - 2011-06-17 11:06:11 --> File loaded: application/views/layout/main.php
DEBUG - 2011-06-17 11:06:11 --> Final output sent to browser
DEBUG - 2011-06-17 11:06:11 --> Total execution time: 0.0763
DEBUG - 2011-06-17 11:06:11 --> Config Class Initialized
DEBUG - 2011-06-17 11:06:11 --> Hooks Class Initialized
DEBUG - 2011-06-17 11:06:11 --> Utf8 Class Initialized
DEBUG - 2011-06-17 11:06:11 --> UTF-8 Support Enabled
DEBUG - 2011-06-17 11:06:11 --> URI Class Initialized
DEBUG - 2011-06-17 11:06:11 --> Router Class Initialized
DEBUG - 2011-06-17 11:06:11 --> Output Class Initialized
DEBUG - 2011-06-17 11:06:11 --> Input Class Initialized
DEBUG - 2011-06-17 11:06:11 --> Global POST and COOKIE data sanitized
DEBUG - 2011-06-17 11:06:11 --> Language Class Initialized
DEBUG - 2011-06-17 11:06:11 --> Loader Class Initialized
DEBUG - 2011-06-17 11:06:11 --> Controller Class Initialized
DEBUG - 2011-06-17 11:06:11 --> Model Class Initialized
DEBUG - 2011-06-17 11:06:11 --> Model Class Initialized
DEBUG - 2011-06-17 11:06:11 --> Model Class Initialized
DEBUG - 2011-06-17 11:06:11 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-06-17 11:06:11 --> Database Driver Class Initialized
DEBUG - 2011-06-17 11:06:11 --> File loaded: application/views/table/main.php
DEBUG - 2011-06-17 11:06:11 --> Helper loaded: url_helper
DEBUG - 2011-06-17 11:06:11 --> File loaded: application/views/common/header.php
DEBUG - 2011-06-17 11:06:11 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-06-17 11:06:11 --> File loaded: application/views/common/footer.php
DEBUG - 2011-06-17 11:06:11 --> File loaded: application/views/layout/main.php
DEBUG - 2011-06-17 11:06:11 --> Final output sent to browser
DEBUG - 2011-06-17 11:06:11 --> Total execution time: 0.0493
DEBUG - 2011-06-17 11:06:12 --> Config Class Initialized
DEBUG - 2011-06-17 11:06:12 --> Hooks Class Initialized
DEBUG - 2011-06-17 11:06:12 --> Utf8 Class Initialized
DEBUG - 2011-06-17 11:06:12 --> UTF-8 Support Enabled
DEBUG - 2011-06-17 11:06:12 --> URI Class Initialized
DEBUG - 2011-06-17 11:06:12 --> Router Class Initialized
ERROR - 2011-06-17 11:06:12 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-06-17 11:06:17 --> Config Class Initialized
DEBUG - 2011-06-17 11:06:17 --> Hooks Class Initialized
DEBUG - 2011-06-17 11:06:17 --> Utf8 Class Initialized
DEBUG - 2011-06-17 11:06:17 --> UTF-8 Support Enabled
DEBUG - 2011-06-17 11:06:17 --> URI Class Initialized
DEBUG - 2011-06-17 11:06:17 --> Router Class Initialized
DEBUG - 2011-06-17 11:06:17 --> Output Class Initialized
DEBUG - 2011-06-17 11:06:17 --> Input Class Initialized
DEBUG - 2011-06-17 11:06:17 --> Global POST and COOKIE data sanitized
DEBUG - 2011-06-17 11:06:17 --> Language Class Initialized
DEBUG - 2011-06-17 11:06:17 --> Loader Class Initialized
DEBUG - 2011-06-17 11:06:17 --> Controller Class Initialized
DEBUG - 2011-06-17 11:06:17 --> Model Class Initialized
DEBUG - 2011-06-17 11:06:17 --> Model Class Initialized
DEBUG - 2011-06-17 11:06:17 --> Model Class Initialized
DEBUG - 2011-06-17 11:06:17 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-06-17 11:06:17 --> Database Driver Class Initialized
DEBUG - 2011-06-17 11:06:17 --> File loaded: application/views/table/main.php
DEBUG - 2011-06-17 11:06:17 --> Helper loaded: url_helper
DEBUG - 2011-06-17 11:06:17 --> File loaded: application/views/common/header.php
DEBUG - 2011-06-17 11:06:17 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-06-17 11:06:17 --> File loaded: application/views/common/footer.php
DEBUG - 2011-06-17 11:06:17 --> File loaded: application/views/layout/main.php
DEBUG - 2011-06-17 11:06:17 --> Final output sent to browser
DEBUG - 2011-06-17 11:06:17 --> Total execution time: 0.3841
DEBUG - 2011-06-17 11:06:18 --> Config Class Initialized
DEBUG - 2011-06-17 11:06:18 --> Hooks Class Initialized
DEBUG - 2011-06-17 11:06:18 --> Utf8 Class Initialized
DEBUG - 2011-06-17 11:06:18 --> UTF-8 Support Enabled
DEBUG - 2011-06-17 11:06:18 --> URI Class Initialized
DEBUG - 2011-06-17 11:06:18 --> Router Class Initialized
DEBUG - 2011-06-17 11:06:18 --> Output Class Initialized
DEBUG - 2011-06-17 11:06:18 --> Input Class Initialized
DEBUG - 2011-06-17 11:06:18 --> Global POST and COOKIE data sanitized
DEBUG - 2011-06-17 11:06:18 --> Language Class Initialized
DEBUG - 2011-06-17 11:06:18 --> Loader Class Initialized
DEBUG - 2011-06-17 11:06:18 --> Controller Class Initialized
DEBUG - 2011-06-17 11:06:18 --> Model Class Initialized
DEBUG - 2011-06-17 11:06:18 --> Model Class Initialized
DEBUG - 2011-06-17 11:06:18 --> Model Class Initialized
DEBUG - 2011-06-17 11:06:18 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-06-17 11:06:18 --> Database Driver Class Initialized
DEBUG - 2011-06-17 11:06:18 --> File loaded: application/views/table/main.php
DEBUG - 2011-06-17 11:06:18 --> Helper loaded: url_helper
DEBUG - 2011-06-17 11:06:18 --> File loaded: application/views/common/header.php
DEBUG - 2011-06-17 11:06:18 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-06-17 11:06:18 --> File loaded: application/views/common/footer.php
DEBUG - 2011-06-17 11:06:18 --> File loaded: application/views/layout/main.php
DEBUG - 2011-06-17 11:06:18 --> Final output sent to browser
DEBUG - 2011-06-17 11:06:18 --> Total execution time: 0.0496
DEBUG - 2011-06-17 11:06:19 --> Config Class Initialized
DEBUG - 2011-06-17 11:06:19 --> Hooks Class Initialized
DEBUG - 2011-06-17 11:06:19 --> Utf8 Class Initialized
DEBUG - 2011-06-17 11:06:19 --> UTF-8 Support Enabled
DEBUG - 2011-06-17 11:06:19 --> URI Class Initialized
DEBUG - 2011-06-17 11:06:19 --> Router Class Initialized
DEBUG - 2011-06-17 11:06:19 --> Output Class Initialized
DEBUG - 2011-06-17 11:06:19 --> Input Class Initialized
DEBUG - 2011-06-17 11:06:19 --> Global POST and COOKIE data sanitized
DEBUG - 2011-06-17 11:06:19 --> Language Class Initialized
DEBUG - 2011-06-17 11:06:19 --> Loader Class Initialized
DEBUG - 2011-06-17 11:06:19 --> Controller Class Initialized
ERROR - 2011-06-17 11:06:19 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-06-17 11:06:19 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-06-17 11:06:19 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-06-17 11:06:19 --> Model Class Initialized
DEBUG - 2011-06-17 11:06:19 --> Model Class Initialized
DEBUG - 2011-06-17 11:06:19 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-06-17 11:06:19 --> Database Driver Class Initialized
DEBUG - 2011-06-17 11:06:19 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-06-17 11:06:19 --> Helper loaded: url_helper
DEBUG - 2011-06-17 11:06:19 --> File loaded: application/views/common/header.php
DEBUG - 2011-06-17 11:06:19 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-06-17 11:06:19 --> File loaded: application/views/common/footer.php
DEBUG - 2011-06-17 11:06:19 --> File loaded: application/views/layout/main.php
DEBUG - 2011-06-17 11:06:19 --> Final output sent to browser
DEBUG - 2011-06-17 11:06:19 --> Total execution time: 0.1130
DEBUG - 2011-06-17 11:06:19 --> Config Class Initialized
DEBUG - 2011-06-17 11:06:19 --> Hooks Class Initialized
DEBUG - 2011-06-17 11:06:19 --> Utf8 Class Initialized
DEBUG - 2011-06-17 11:06:19 --> UTF-8 Support Enabled
DEBUG - 2011-06-17 11:06:19 --> URI Class Initialized
DEBUG - 2011-06-17 11:06:19 --> Router Class Initialized
ERROR - 2011-06-17 11:06:19 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-06-17 11:06:29 --> Config Class Initialized
DEBUG - 2011-06-17 11:06:29 --> Hooks Class Initialized
DEBUG - 2011-06-17 11:06:29 --> Utf8 Class Initialized
DEBUG - 2011-06-17 11:06:29 --> UTF-8 Support Enabled
DEBUG - 2011-06-17 11:06:29 --> URI Class Initialized
DEBUG - 2011-06-17 11:06:29 --> Router Class Initialized
DEBUG - 2011-06-17 11:06:29 --> Output Class Initialized
DEBUG - 2011-06-17 11:06:29 --> Input Class Initialized
DEBUG - 2011-06-17 11:06:29 --> Global POST and COOKIE data sanitized
DEBUG - 2011-06-17 11:06:29 --> Language Class Initialized
DEBUG - 2011-06-17 11:06:29 --> Loader Class Initialized
DEBUG - 2011-06-17 11:06:29 --> Controller Class Initialized
DEBUG - 2011-06-17 11:06:29 --> Model Class Initialized
DEBUG - 2011-06-17 11:06:29 --> Model Class Initialized
DEBUG - 2011-06-17 11:06:29 --> Model Class Initialized
DEBUG - 2011-06-17 11:06:29 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-06-17 11:06:29 --> Database Driver Class Initialized
DEBUG - 2011-06-17 11:06:30 --> File loaded: application/views/table/main.php
DEBUG - 2011-06-17 11:06:30 --> Helper loaded: url_helper
DEBUG - 2011-06-17 11:06:30 --> File loaded: application/views/common/header.php
DEBUG - 2011-06-17 11:06:30 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-06-17 11:06:30 --> File loaded: application/views/common/footer.php
DEBUG - 2011-06-17 11:06:30 --> File loaded: application/views/layout/main.php
DEBUG - 2011-06-17 11:06:30 --> Final output sent to browser
DEBUG - 2011-06-17 11:06:30 --> Total execution time: 0.2603
DEBUG - 2011-06-17 11:06:32 --> Config Class Initialized
DEBUG - 2011-06-17 11:06:32 --> Hooks Class Initialized
DEBUG - 2011-06-17 11:06:32 --> Utf8 Class Initialized
DEBUG - 2011-06-17 11:06:32 --> UTF-8 Support Enabled
DEBUG - 2011-06-17 11:06:32 --> URI Class Initialized
DEBUG - 2011-06-17 11:06:32 --> Router Class Initialized
ERROR - 2011-06-17 11:06:32 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-06-17 11:06:34 --> Config Class Initialized
DEBUG - 2011-06-17 11:06:34 --> Hooks Class Initialized
DEBUG - 2011-06-17 11:06:34 --> Utf8 Class Initialized
DEBUG - 2011-06-17 11:06:34 --> UTF-8 Support Enabled
DEBUG - 2011-06-17 11:06:34 --> URI Class Initialized
DEBUG - 2011-06-17 11:06:34 --> Router Class Initialized
DEBUG - 2011-06-17 11:06:34 --> Output Class Initialized
DEBUG - 2011-06-17 11:06:34 --> Input Class Initialized
DEBUG - 2011-06-17 11:06:34 --> Global POST and COOKIE data sanitized
DEBUG - 2011-06-17 11:06:34 --> Language Class Initialized
DEBUG - 2011-06-17 11:06:34 --> Loader Class Initialized
DEBUG - 2011-06-17 11:06:34 --> Controller Class Initialized
DEBUG - 2011-06-17 11:06:34 --> Model Class Initialized
DEBUG - 2011-06-17 11:06:34 --> Model Class Initialized
DEBUG - 2011-06-17 11:06:34 --> Model Class Initialized
DEBUG - 2011-06-17 11:06:34 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-06-17 11:06:34 --> Database Driver Class Initialized
DEBUG - 2011-06-17 11:06:34 --> File loaded: application/views/table/main.php
DEBUG - 2011-06-17 11:06:34 --> Helper loaded: url_helper
DEBUG - 2011-06-17 11:06:34 --> File loaded: application/views/common/header.php
DEBUG - 2011-06-17 11:06:34 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-06-17 11:06:34 --> File loaded: application/views/common/footer.php
DEBUG - 2011-06-17 11:06:34 --> File loaded: application/views/layout/main.php
DEBUG - 2011-06-17 11:06:34 --> Final output sent to browser
DEBUG - 2011-06-17 11:06:34 --> Total execution time: 0.0470
DEBUG - 2011-06-17 11:06:37 --> Config Class Initialized
DEBUG - 2011-06-17 11:06:37 --> Hooks Class Initialized
DEBUG - 2011-06-17 11:06:37 --> Utf8 Class Initialized
DEBUG - 2011-06-17 11:06:37 --> UTF-8 Support Enabled
DEBUG - 2011-06-17 11:06:37 --> URI Class Initialized
DEBUG - 2011-06-17 11:06:37 --> Router Class Initialized
DEBUG - 2011-06-17 11:06:37 --> Output Class Initialized
DEBUG - 2011-06-17 11:06:37 --> Input Class Initialized
DEBUG - 2011-06-17 11:06:37 --> Global POST and COOKIE data sanitized
DEBUG - 2011-06-17 11:06:37 --> Language Class Initialized
DEBUG - 2011-06-17 11:06:37 --> Loader Class Initialized
DEBUG - 2011-06-17 11:06:37 --> Controller Class Initialized
DEBUG - 2011-06-17 11:06:37 --> Model Class Initialized
DEBUG - 2011-06-17 11:06:37 --> Model Class Initialized
DEBUG - 2011-06-17 11:06:37 --> Model Class Initialized
DEBUG - 2011-06-17 11:06:37 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-06-17 11:06:37 --> Database Driver Class Initialized
DEBUG - 2011-06-17 11:06:37 --> File loaded: application/views/table/main.php
DEBUG - 2011-06-17 11:06:37 --> Helper loaded: url_helper
DEBUG - 2011-06-17 11:06:37 --> File loaded: application/views/common/header.php
DEBUG - 2011-06-17 11:06:37 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-06-17 11:06:37 --> File loaded: application/views/common/footer.php
DEBUG - 2011-06-17 11:06:37 --> File loaded: application/views/layout/main.php
DEBUG - 2011-06-17 11:06:37 --> Final output sent to browser
DEBUG - 2011-06-17 11:06:37 --> Total execution time: 0.1658
DEBUG - 2011-06-17 11:06:39 --> Config Class Initialized
DEBUG - 2011-06-17 11:06:39 --> Hooks Class Initialized
DEBUG - 2011-06-17 11:06:39 --> Utf8 Class Initialized
DEBUG - 2011-06-17 11:06:39 --> UTF-8 Support Enabled
DEBUG - 2011-06-17 11:06:39 --> URI Class Initialized
DEBUG - 2011-06-17 11:06:39 --> Router Class Initialized
ERROR - 2011-06-17 11:06:39 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-06-17 11:06:40 --> Config Class Initialized
DEBUG - 2011-06-17 11:06:40 --> Hooks Class Initialized
DEBUG - 2011-06-17 11:06:40 --> Utf8 Class Initialized
DEBUG - 2011-06-17 11:06:40 --> UTF-8 Support Enabled
DEBUG - 2011-06-17 11:06:40 --> URI Class Initialized
DEBUG - 2011-06-17 11:06:40 --> Router Class Initialized
DEBUG - 2011-06-17 11:06:40 --> Output Class Initialized
DEBUG - 2011-06-17 11:06:40 --> Input Class Initialized
DEBUG - 2011-06-17 11:06:40 --> Global POST and COOKIE data sanitized
DEBUG - 2011-06-17 11:06:40 --> Language Class Initialized
DEBUG - 2011-06-17 11:06:40 --> Loader Class Initialized
DEBUG - 2011-06-17 11:06:40 --> Controller Class Initialized
DEBUG - 2011-06-17 11:06:40 --> Model Class Initialized
DEBUG - 2011-06-17 11:06:40 --> Model Class Initialized
DEBUG - 2011-06-17 11:06:40 --> Model Class Initialized
DEBUG - 2011-06-17 11:06:40 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-06-17 11:06:40 --> Database Driver Class Initialized
DEBUG - 2011-06-17 11:06:40 --> File loaded: application/views/table/main.php
DEBUG - 2011-06-17 11:06:40 --> Helper loaded: url_helper
DEBUG - 2011-06-17 11:06:40 --> File loaded: application/views/common/header.php
DEBUG - 2011-06-17 11:06:40 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-06-17 11:06:40 --> File loaded: application/views/common/footer.php
DEBUG - 2011-06-17 11:06:40 --> File loaded: application/views/layout/main.php
DEBUG - 2011-06-17 11:06:40 --> Final output sent to browser
DEBUG - 2011-06-17 11:06:40 --> Total execution time: 0.0981
DEBUG - 2011-06-17 11:06:46 --> Config Class Initialized
DEBUG - 2011-06-17 11:06:46 --> Hooks Class Initialized
DEBUG - 2011-06-17 11:06:46 --> Utf8 Class Initialized
DEBUG - 2011-06-17 11:06:46 --> UTF-8 Support Enabled
DEBUG - 2011-06-17 11:06:46 --> URI Class Initialized
DEBUG - 2011-06-17 11:06:46 --> Router Class Initialized
DEBUG - 2011-06-17 11:06:46 --> Output Class Initialized
DEBUG - 2011-06-17 11:06:46 --> Input Class Initialized
DEBUG - 2011-06-17 11:06:46 --> Global POST and COOKIE data sanitized
DEBUG - 2011-06-17 11:06:46 --> Language Class Initialized
DEBUG - 2011-06-17 11:06:46 --> Loader Class Initialized
DEBUG - 2011-06-17 11:06:46 --> Controller Class Initialized
DEBUG - 2011-06-17 11:06:46 --> Model Class Initialized
DEBUG - 2011-06-17 11:06:46 --> Model Class Initialized
DEBUG - 2011-06-17 11:06:46 --> Model Class Initialized
DEBUG - 2011-06-17 11:06:46 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-06-17 11:06:46 --> Database Driver Class Initialized
DEBUG - 2011-06-17 11:06:46 --> File loaded: application/views/table/main.php
DEBUG - 2011-06-17 11:06:46 --> Helper loaded: url_helper
DEBUG - 2011-06-17 11:06:46 --> File loaded: application/views/common/header.php
DEBUG - 2011-06-17 11:06:46 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-06-17 11:06:46 --> File loaded: application/views/common/footer.php
DEBUG - 2011-06-17 11:06:46 --> File loaded: application/views/layout/main.php
DEBUG - 2011-06-17 11:06:46 --> Final output sent to browser
DEBUG - 2011-06-17 11:06:46 --> Total execution time: 0.1556
DEBUG - 2011-06-17 11:06:58 --> Config Class Initialized
DEBUG - 2011-06-17 11:06:58 --> Hooks Class Initialized
DEBUG - 2011-06-17 11:06:58 --> Utf8 Class Initialized
DEBUG - 2011-06-17 11:06:58 --> UTF-8 Support Enabled
DEBUG - 2011-06-17 11:06:58 --> URI Class Initialized
DEBUG - 2011-06-17 11:06:58 --> Router Class Initialized
DEBUG - 2011-06-17 11:06:58 --> Output Class Initialized
DEBUG - 2011-06-17 11:06:58 --> Input Class Initialized
DEBUG - 2011-06-17 11:06:58 --> Global POST and COOKIE data sanitized
DEBUG - 2011-06-17 11:06:58 --> Language Class Initialized
DEBUG - 2011-06-17 11:06:58 --> Loader Class Initialized
DEBUG - 2011-06-17 11:06:58 --> Controller Class Initialized
DEBUG - 2011-06-17 11:06:58 --> Model Class Initialized
DEBUG - 2011-06-17 11:06:58 --> Model Class Initialized
DEBUG - 2011-06-17 11:06:58 --> Model Class Initialized
DEBUG - 2011-06-17 11:06:58 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-06-17 11:06:58 --> Database Driver Class Initialized
DEBUG - 2011-06-17 11:06:58 --> File loaded: application/views/table/main.php
DEBUG - 2011-06-17 11:06:58 --> Helper loaded: url_helper
DEBUG - 2011-06-17 11:06:58 --> File loaded: application/views/common/header.php
DEBUG - 2011-06-17 11:06:58 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-06-17 11:06:58 --> File loaded: application/views/common/footer.php
DEBUG - 2011-06-17 11:06:58 --> File loaded: application/views/layout/main.php
DEBUG - 2011-06-17 11:06:58 --> Final output sent to browser
DEBUG - 2011-06-17 11:06:58 --> Total execution time: 0.1775
DEBUG - 2011-06-17 11:07:01 --> Config Class Initialized
DEBUG - 2011-06-17 11:07:01 --> Hooks Class Initialized
DEBUG - 2011-06-17 11:07:01 --> Utf8 Class Initialized
DEBUG - 2011-06-17 11:07:01 --> UTF-8 Support Enabled
DEBUG - 2011-06-17 11:07:01 --> URI Class Initialized
DEBUG - 2011-06-17 11:07:01 --> Router Class Initialized
ERROR - 2011-06-17 11:07:01 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-06-17 11:07:01 --> Config Class Initialized
DEBUG - 2011-06-17 11:07:01 --> Hooks Class Initialized
DEBUG - 2011-06-17 11:07:01 --> Utf8 Class Initialized
DEBUG - 2011-06-17 11:07:01 --> UTF-8 Support Enabled
DEBUG - 2011-06-17 11:07:01 --> URI Class Initialized
DEBUG - 2011-06-17 11:07:01 --> Router Class Initialized
DEBUG - 2011-06-17 11:07:01 --> Output Class Initialized
DEBUG - 2011-06-17 11:07:01 --> Input Class Initialized
DEBUG - 2011-06-17 11:07:01 --> Global POST and COOKIE data sanitized
DEBUG - 2011-06-17 11:07:01 --> Language Class Initialized
DEBUG - 2011-06-17 11:07:01 --> Loader Class Initialized
DEBUG - 2011-06-17 11:07:01 --> Controller Class Initialized
DEBUG - 2011-06-17 11:07:01 --> Model Class Initialized
DEBUG - 2011-06-17 11:07:01 --> Model Class Initialized
DEBUG - 2011-06-17 11:07:01 --> Model Class Initialized
DEBUG - 2011-06-17 11:07:01 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-06-17 11:07:01 --> Database Driver Class Initialized
DEBUG - 2011-06-17 11:07:01 --> File loaded: application/views/table/main.php
DEBUG - 2011-06-17 11:07:01 --> Helper loaded: url_helper
DEBUG - 2011-06-17 11:07:01 --> File loaded: application/views/common/header.php
DEBUG - 2011-06-17 11:07:01 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-06-17 11:07:01 --> File loaded: application/views/common/footer.php
DEBUG - 2011-06-17 11:07:01 --> File loaded: application/views/layout/main.php
DEBUG - 2011-06-17 11:07:01 --> Final output sent to browser
DEBUG - 2011-06-17 11:07:01 --> Total execution time: 0.1046
DEBUG - 2011-06-17 11:07:06 --> Config Class Initialized
DEBUG - 2011-06-17 11:07:06 --> Hooks Class Initialized
DEBUG - 2011-06-17 11:07:06 --> Utf8 Class Initialized
DEBUG - 2011-06-17 11:07:06 --> UTF-8 Support Enabled
DEBUG - 2011-06-17 11:07:06 --> URI Class Initialized
DEBUG - 2011-06-17 11:07:06 --> Router Class Initialized
DEBUG - 2011-06-17 11:07:06 --> Output Class Initialized
DEBUG - 2011-06-17 11:07:06 --> Input Class Initialized
DEBUG - 2011-06-17 11:07:06 --> Global POST and COOKIE data sanitized
DEBUG - 2011-06-17 11:07:06 --> Language Class Initialized
DEBUG - 2011-06-17 11:07:06 --> Loader Class Initialized
DEBUG - 2011-06-17 11:07:06 --> Controller Class Initialized
DEBUG - 2011-06-17 11:07:06 --> Model Class Initialized
DEBUG - 2011-06-17 11:07:06 --> Model Class Initialized
DEBUG - 2011-06-17 11:07:06 --> Model Class Initialized
DEBUG - 2011-06-17 11:07:06 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-06-17 11:07:06 --> Database Driver Class Initialized
DEBUG - 2011-06-17 11:07:06 --> File loaded: application/views/table/main.php
DEBUG - 2011-06-17 11:07:06 --> Helper loaded: url_helper
DEBUG - 2011-06-17 11:07:06 --> File loaded: application/views/common/header.php
DEBUG - 2011-06-17 11:07:06 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-06-17 11:07:06 --> File loaded: application/views/common/footer.php
DEBUG - 2011-06-17 11:07:06 --> File loaded: application/views/layout/main.php
DEBUG - 2011-06-17 11:07:06 --> Final output sent to browser
DEBUG - 2011-06-17 11:07:06 --> Total execution time: 0.0490
DEBUG - 2011-06-17 11:07:08 --> Config Class Initialized
DEBUG - 2011-06-17 11:07:08 --> Hooks Class Initialized
DEBUG - 2011-06-17 11:07:08 --> Utf8 Class Initialized
DEBUG - 2011-06-17 11:07:08 --> UTF-8 Support Enabled
DEBUG - 2011-06-17 11:07:08 --> URI Class Initialized
DEBUG - 2011-06-17 11:07:08 --> Router Class Initialized
ERROR - 2011-06-17 11:07:08 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-06-17 11:07:17 --> Config Class Initialized
DEBUG - 2011-06-17 11:07:17 --> Hooks Class Initialized
DEBUG - 2011-06-17 11:07:17 --> Utf8 Class Initialized
DEBUG - 2011-06-17 11:07:17 --> UTF-8 Support Enabled
DEBUG - 2011-06-17 11:07:17 --> URI Class Initialized
DEBUG - 2011-06-17 11:07:17 --> Router Class Initialized
DEBUG - 2011-06-17 11:07:17 --> Output Class Initialized
DEBUG - 2011-06-17 11:07:17 --> Input Class Initialized
DEBUG - 2011-06-17 11:07:17 --> Global POST and COOKIE data sanitized
DEBUG - 2011-06-17 11:07:17 --> Language Class Initialized
DEBUG - 2011-06-17 11:07:17 --> Loader Class Initialized
DEBUG - 2011-06-17 11:07:17 --> Controller Class Initialized
DEBUG - 2011-06-17 11:07:17 --> Model Class Initialized
DEBUG - 2011-06-17 11:07:17 --> Model Class Initialized
DEBUG - 2011-06-17 11:07:17 --> Model Class Initialized
DEBUG - 2011-06-17 11:07:17 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-06-17 11:07:17 --> Database Driver Class Initialized
DEBUG - 2011-06-17 11:07:17 --> File loaded: application/views/table/main.php
DEBUG - 2011-06-17 11:07:17 --> Helper loaded: url_helper
DEBUG - 2011-06-17 11:07:17 --> File loaded: application/views/common/header.php
DEBUG - 2011-06-17 11:07:17 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-06-17 11:07:17 --> File loaded: application/views/common/footer.php
DEBUG - 2011-06-17 11:07:17 --> File loaded: application/views/layout/main.php
DEBUG - 2011-06-17 11:07:17 --> Final output sent to browser
DEBUG - 2011-06-17 11:07:17 --> Total execution time: 0.6920
DEBUG - 2011-06-17 11:07:19 --> Config Class Initialized
DEBUG - 2011-06-17 11:07:19 --> Hooks Class Initialized
DEBUG - 2011-06-17 11:07:19 --> Utf8 Class Initialized
DEBUG - 2011-06-17 11:07:19 --> UTF-8 Support Enabled
DEBUG - 2011-06-17 11:07:19 --> URI Class Initialized
DEBUG - 2011-06-17 11:07:19 --> Router Class Initialized
ERROR - 2011-06-17 11:07:19 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-06-17 11:07:19 --> Config Class Initialized
DEBUG - 2011-06-17 11:07:19 --> Hooks Class Initialized
DEBUG - 2011-06-17 11:07:19 --> Utf8 Class Initialized
DEBUG - 2011-06-17 11:07:19 --> UTF-8 Support Enabled
DEBUG - 2011-06-17 11:07:19 --> URI Class Initialized
DEBUG - 2011-06-17 11:07:19 --> Router Class Initialized
DEBUG - 2011-06-17 11:07:19 --> Output Class Initialized
DEBUG - 2011-06-17 11:07:19 --> Input Class Initialized
DEBUG - 2011-06-17 11:07:19 --> Global POST and COOKIE data sanitized
DEBUG - 2011-06-17 11:07:19 --> Language Class Initialized
DEBUG - 2011-06-17 11:07:19 --> Loader Class Initialized
DEBUG - 2011-06-17 11:07:19 --> Controller Class Initialized
DEBUG - 2011-06-17 11:07:19 --> Model Class Initialized
DEBUG - 2011-06-17 11:07:19 --> Model Class Initialized
DEBUG - 2011-06-17 11:07:19 --> Model Class Initialized
DEBUG - 2011-06-17 11:07:19 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-06-17 11:07:19 --> Database Driver Class Initialized
DEBUG - 2011-06-17 11:07:19 --> File loaded: application/views/table/main.php
DEBUG - 2011-06-17 11:07:19 --> Helper loaded: url_helper
DEBUG - 2011-06-17 11:07:19 --> File loaded: application/views/common/header.php
DEBUG - 2011-06-17 11:07:19 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-06-17 11:07:19 --> File loaded: application/views/common/footer.php
DEBUG - 2011-06-17 11:07:19 --> File loaded: application/views/layout/main.php
DEBUG - 2011-06-17 11:07:19 --> Final output sent to browser
DEBUG - 2011-06-17 11:07:19 --> Total execution time: 0.0506
DEBUG - 2011-06-17 11:07:26 --> Config Class Initialized
DEBUG - 2011-06-17 11:07:26 --> Hooks Class Initialized
DEBUG - 2011-06-17 11:07:26 --> Utf8 Class Initialized
DEBUG - 2011-06-17 11:07:26 --> UTF-8 Support Enabled
DEBUG - 2011-06-17 11:07:26 --> URI Class Initialized
DEBUG - 2011-06-17 11:07:26 --> Router Class Initialized
DEBUG - 2011-06-17 11:07:26 --> Output Class Initialized
DEBUG - 2011-06-17 11:07:26 --> Input Class Initialized
DEBUG - 2011-06-17 11:07:26 --> Global POST and COOKIE data sanitized
DEBUG - 2011-06-17 11:07:26 --> Language Class Initialized
DEBUG - 2011-06-17 11:07:26 --> Loader Class Initialized
DEBUG - 2011-06-17 11:07:26 --> Controller Class Initialized
DEBUG - 2011-06-17 11:07:26 --> Model Class Initialized
DEBUG - 2011-06-17 11:07:26 --> Model Class Initialized
DEBUG - 2011-06-17 11:07:26 --> Model Class Initialized
DEBUG - 2011-06-17 11:07:26 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-06-17 11:07:26 --> Database Driver Class Initialized
DEBUG - 2011-06-17 11:07:26 --> File loaded: application/views/table/main.php
DEBUG - 2011-06-17 11:07:26 --> Helper loaded: url_helper
DEBUG - 2011-06-17 11:07:26 --> File loaded: application/views/common/header.php
DEBUG - 2011-06-17 11:07:26 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-06-17 11:07:26 --> File loaded: application/views/common/footer.php
DEBUG - 2011-06-17 11:07:26 --> File loaded: application/views/layout/main.php
DEBUG - 2011-06-17 11:07:26 --> Final output sent to browser
DEBUG - 2011-06-17 11:07:26 --> Total execution time: 0.2088
DEBUG - 2011-06-17 11:07:27 --> Config Class Initialized
DEBUG - 2011-06-17 11:07:27 --> Hooks Class Initialized
DEBUG - 2011-06-17 11:07:27 --> Utf8 Class Initialized
DEBUG - 2011-06-17 11:07:27 --> UTF-8 Support Enabled
DEBUG - 2011-06-17 11:07:27 --> URI Class Initialized
DEBUG - 2011-06-17 11:07:27 --> Router Class Initialized
DEBUG - 2011-06-17 11:07:27 --> Output Class Initialized
DEBUG - 2011-06-17 11:07:27 --> Input Class Initialized
DEBUG - 2011-06-17 11:07:27 --> Global POST and COOKIE data sanitized
DEBUG - 2011-06-17 11:07:27 --> Language Class Initialized
DEBUG - 2011-06-17 11:07:27 --> Loader Class Initialized
DEBUG - 2011-06-17 11:07:27 --> Controller Class Initialized
DEBUG - 2011-06-17 11:07:27 --> Model Class Initialized
DEBUG - 2011-06-17 11:07:27 --> Model Class Initialized
DEBUG - 2011-06-17 11:07:27 --> Model Class Initialized
DEBUG - 2011-06-17 11:07:27 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-06-17 11:07:27 --> Database Driver Class Initialized
DEBUG - 2011-06-17 11:07:27 --> File loaded: application/views/table/main.php
DEBUG - 2011-06-17 11:07:27 --> Helper loaded: url_helper
DEBUG - 2011-06-17 11:07:27 --> File loaded: application/views/common/header.php
DEBUG - 2011-06-17 11:07:27 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-06-17 11:07:27 --> File loaded: application/views/common/footer.php
DEBUG - 2011-06-17 11:07:27 --> File loaded: application/views/layout/main.php
DEBUG - 2011-06-17 11:07:27 --> Final output sent to browser
DEBUG - 2011-06-17 11:07:27 --> Total execution time: 0.0456
DEBUG - 2011-06-17 11:07:28 --> Config Class Initialized
DEBUG - 2011-06-17 11:07:28 --> Hooks Class Initialized
DEBUG - 2011-06-17 11:07:28 --> Utf8 Class Initialized
DEBUG - 2011-06-17 11:07:28 --> UTF-8 Support Enabled
DEBUG - 2011-06-17 11:07:28 --> URI Class Initialized
DEBUG - 2011-06-17 11:07:28 --> Router Class Initialized
ERROR - 2011-06-17 11:07:28 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-06-17 11:07:35 --> Config Class Initialized
DEBUG - 2011-06-17 11:07:35 --> Hooks Class Initialized
DEBUG - 2011-06-17 11:07:35 --> Utf8 Class Initialized
DEBUG - 2011-06-17 11:07:35 --> UTF-8 Support Enabled
DEBUG - 2011-06-17 11:07:35 --> URI Class Initialized
DEBUG - 2011-06-17 11:07:35 --> Router Class Initialized
DEBUG - 2011-06-17 11:07:35 --> Output Class Initialized
DEBUG - 2011-06-17 11:07:35 --> Input Class Initialized
DEBUG - 2011-06-17 11:07:35 --> Global POST and COOKIE data sanitized
DEBUG - 2011-06-17 11:07:35 --> Language Class Initialized
DEBUG - 2011-06-17 11:07:35 --> Loader Class Initialized
DEBUG - 2011-06-17 11:07:35 --> Controller Class Initialized
DEBUG - 2011-06-17 11:07:35 --> Model Class Initialized
DEBUG - 2011-06-17 11:07:35 --> Model Class Initialized
DEBUG - 2011-06-17 11:07:35 --> Model Class Initialized
DEBUG - 2011-06-17 11:07:35 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-06-17 11:07:35 --> Database Driver Class Initialized
DEBUG - 2011-06-17 11:07:36 --> File loaded: application/views/table/main.php
DEBUG - 2011-06-17 11:07:36 --> Helper loaded: url_helper
DEBUG - 2011-06-17 11:07:36 --> File loaded: application/views/common/header.php
DEBUG - 2011-06-17 11:07:36 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-06-17 11:07:36 --> File loaded: application/views/common/footer.php
DEBUG - 2011-06-17 11:07:36 --> File loaded: application/views/layout/main.php
DEBUG - 2011-06-17 11:07:36 --> Final output sent to browser
DEBUG - 2011-06-17 11:07:36 --> Total execution time: 0.2583
DEBUG - 2011-06-17 11:07:38 --> Config Class Initialized
DEBUG - 2011-06-17 11:07:38 --> Hooks Class Initialized
DEBUG - 2011-06-17 11:07:38 --> Utf8 Class Initialized
DEBUG - 2011-06-17 11:07:38 --> UTF-8 Support Enabled
DEBUG - 2011-06-17 11:07:38 --> URI Class Initialized
DEBUG - 2011-06-17 11:07:38 --> Router Class Initialized
DEBUG - 2011-06-17 11:07:38 --> Output Class Initialized
DEBUG - 2011-06-17 11:07:38 --> Input Class Initialized
DEBUG - 2011-06-17 11:07:38 --> Global POST and COOKIE data sanitized
DEBUG - 2011-06-17 11:07:38 --> Language Class Initialized
DEBUG - 2011-06-17 11:07:38 --> Loader Class Initialized
DEBUG - 2011-06-17 11:07:38 --> Controller Class Initialized
DEBUG - 2011-06-17 11:07:38 --> Model Class Initialized
DEBUG - 2011-06-17 11:07:38 --> Model Class Initialized
DEBUG - 2011-06-17 11:07:38 --> Model Class Initialized
DEBUG - 2011-06-17 11:07:38 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-06-17 11:07:38 --> Database Driver Class Initialized
DEBUG - 2011-06-17 11:07:38 --> File loaded: application/views/table/main.php
DEBUG - 2011-06-17 11:07:38 --> Helper loaded: url_helper
DEBUG - 2011-06-17 11:07:38 --> File loaded: application/views/common/header.php
DEBUG - 2011-06-17 11:07:38 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-06-17 11:07:38 --> File loaded: application/views/common/footer.php
DEBUG - 2011-06-17 11:07:38 --> File loaded: application/views/layout/main.php
DEBUG - 2011-06-17 11:07:38 --> Final output sent to browser
DEBUG - 2011-06-17 11:07:38 --> Total execution time: 0.0441
DEBUG - 2011-06-17 11:07:39 --> Config Class Initialized
DEBUG - 2011-06-17 11:07:39 --> Hooks Class Initialized
DEBUG - 2011-06-17 11:07:39 --> Utf8 Class Initialized
DEBUG - 2011-06-17 11:07:39 --> UTF-8 Support Enabled
DEBUG - 2011-06-17 11:07:39 --> URI Class Initialized
DEBUG - 2011-06-17 11:07:39 --> Router Class Initialized
ERROR - 2011-06-17 11:07:39 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-06-17 11:07:47 --> Config Class Initialized
DEBUG - 2011-06-17 11:07:47 --> Hooks Class Initialized
DEBUG - 2011-06-17 11:07:47 --> Utf8 Class Initialized
DEBUG - 2011-06-17 11:07:47 --> UTF-8 Support Enabled
DEBUG - 2011-06-17 11:07:47 --> URI Class Initialized
DEBUG - 2011-06-17 11:07:47 --> Router Class Initialized
DEBUG - 2011-06-17 11:07:47 --> Output Class Initialized
DEBUG - 2011-06-17 11:07:47 --> Input Class Initialized
DEBUG - 2011-06-17 11:07:47 --> Global POST and COOKIE data sanitized
DEBUG - 2011-06-17 11:07:47 --> Language Class Initialized
DEBUG - 2011-06-17 11:07:47 --> Loader Class Initialized
DEBUG - 2011-06-17 11:07:47 --> Controller Class Initialized
DEBUG - 2011-06-17 11:07:47 --> Model Class Initialized
DEBUG - 2011-06-17 11:07:47 --> Model Class Initialized
DEBUG - 2011-06-17 11:07:47 --> Model Class Initialized
DEBUG - 2011-06-17 11:07:47 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-06-17 11:07:47 --> Database Driver Class Initialized
DEBUG - 2011-06-17 11:07:47 --> File loaded: application/views/table/main.php
DEBUG - 2011-06-17 11:07:47 --> Helper loaded: url_helper
DEBUG - 2011-06-17 11:07:47 --> File loaded: application/views/common/header.php
DEBUG - 2011-06-17 11:07:47 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-06-17 11:07:47 --> File loaded: application/views/common/footer.php
DEBUG - 2011-06-17 11:07:47 --> File loaded: application/views/layout/main.php
DEBUG - 2011-06-17 11:07:47 --> Final output sent to browser
DEBUG - 2011-06-17 11:07:47 --> Total execution time: 0.2404
DEBUG - 2011-06-17 11:07:50 --> Config Class Initialized
DEBUG - 2011-06-17 11:07:50 --> Hooks Class Initialized
DEBUG - 2011-06-17 11:07:50 --> Utf8 Class Initialized
DEBUG - 2011-06-17 11:07:50 --> UTF-8 Support Enabled
DEBUG - 2011-06-17 11:07:50 --> URI Class Initialized
DEBUG - 2011-06-17 11:07:50 --> Router Class Initialized
ERROR - 2011-06-17 11:07:50 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-06-17 11:08:11 --> Config Class Initialized
DEBUG - 2011-06-17 11:08:11 --> Hooks Class Initialized
DEBUG - 2011-06-17 11:08:11 --> Utf8 Class Initialized
DEBUG - 2011-06-17 11:08:11 --> UTF-8 Support Enabled
DEBUG - 2011-06-17 11:08:11 --> URI Class Initialized
DEBUG - 2011-06-17 11:08:11 --> Router Class Initialized
DEBUG - 2011-06-17 11:08:11 --> Output Class Initialized
DEBUG - 2011-06-17 11:08:11 --> Input Class Initialized
DEBUG - 2011-06-17 11:08:11 --> Global POST and COOKIE data sanitized
DEBUG - 2011-06-17 11:08:11 --> Language Class Initialized
DEBUG - 2011-06-17 11:08:11 --> Loader Class Initialized
DEBUG - 2011-06-17 11:08:11 --> Controller Class Initialized
DEBUG - 2011-06-17 11:08:11 --> Model Class Initialized
DEBUG - 2011-06-17 11:08:11 --> Model Class Initialized
DEBUG - 2011-06-17 11:08:11 --> Model Class Initialized
DEBUG - 2011-06-17 11:08:11 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-06-17 11:08:11 --> Database Driver Class Initialized
DEBUG - 2011-06-17 11:08:11 --> File loaded: application/views/table/main.php
DEBUG - 2011-06-17 11:08:11 --> Helper loaded: url_helper
DEBUG - 2011-06-17 11:08:11 --> File loaded: application/views/common/header.php
DEBUG - 2011-06-17 11:08:11 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-06-17 11:08:11 --> File loaded: application/views/common/footer.php
DEBUG - 2011-06-17 11:08:11 --> File loaded: application/views/layout/main.php
DEBUG - 2011-06-17 11:08:11 --> Final output sent to browser
DEBUG - 2011-06-17 11:08:11 --> Total execution time: 0.2212
DEBUG - 2011-06-17 11:08:14 --> Config Class Initialized
DEBUG - 2011-06-17 11:08:14 --> Hooks Class Initialized
DEBUG - 2011-06-17 11:08:14 --> Utf8 Class Initialized
DEBUG - 2011-06-17 11:08:14 --> UTF-8 Support Enabled
DEBUG - 2011-06-17 11:08:14 --> URI Class Initialized
DEBUG - 2011-06-17 11:08:14 --> Router Class Initialized
ERROR - 2011-06-17 11:08:14 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-06-17 11:08:48 --> Config Class Initialized
DEBUG - 2011-06-17 11:08:48 --> Hooks Class Initialized
DEBUG - 2011-06-17 11:08:48 --> Utf8 Class Initialized
DEBUG - 2011-06-17 11:08:48 --> UTF-8 Support Enabled
DEBUG - 2011-06-17 11:08:48 --> URI Class Initialized
DEBUG - 2011-06-17 11:08:48 --> Router Class Initialized
DEBUG - 2011-06-17 11:08:48 --> Output Class Initialized
DEBUG - 2011-06-17 11:08:48 --> Input Class Initialized
DEBUG - 2011-06-17 11:08:48 --> Global POST and COOKIE data sanitized
DEBUG - 2011-06-17 11:08:48 --> Language Class Initialized
DEBUG - 2011-06-17 11:08:48 --> Loader Class Initialized
DEBUG - 2011-06-17 11:08:48 --> Controller Class Initialized
DEBUG - 2011-06-17 11:08:48 --> Model Class Initialized
DEBUG - 2011-06-17 11:08:48 --> Model Class Initialized
DEBUG - 2011-06-17 11:08:48 --> Model Class Initialized
DEBUG - 2011-06-17 11:08:48 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-06-17 11:08:48 --> Database Driver Class Initialized
DEBUG - 2011-06-17 11:08:48 --> File loaded: application/views/table/main.php
DEBUG - 2011-06-17 11:08:48 --> Helper loaded: url_helper
DEBUG - 2011-06-17 11:08:48 --> File loaded: application/views/common/header.php
DEBUG - 2011-06-17 11:08:48 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-06-17 11:08:48 --> File loaded: application/views/common/footer.php
DEBUG - 2011-06-17 11:08:48 --> File loaded: application/views/layout/main.php
DEBUG - 2011-06-17 11:08:48 --> Final output sent to browser
DEBUG - 2011-06-17 11:08:48 --> Total execution time: 0.0760
DEBUG - 2011-06-17 11:08:54 --> Config Class Initialized
DEBUG - 2011-06-17 11:08:54 --> Hooks Class Initialized
DEBUG - 2011-06-17 11:08:54 --> Utf8 Class Initialized
DEBUG - 2011-06-17 11:08:54 --> UTF-8 Support Enabled
DEBUG - 2011-06-17 11:08:54 --> URI Class Initialized
DEBUG - 2011-06-17 11:08:54 --> Router Class Initialized
DEBUG - 2011-06-17 11:08:54 --> Output Class Initialized
DEBUG - 2011-06-17 11:08:54 --> Input Class Initialized
DEBUG - 2011-06-17 11:08:54 --> Global POST and COOKIE data sanitized
DEBUG - 2011-06-17 11:08:54 --> Language Class Initialized
DEBUG - 2011-06-17 11:08:54 --> Loader Class Initialized
DEBUG - 2011-06-17 11:08:54 --> Controller Class Initialized
DEBUG - 2011-06-17 11:08:54 --> Model Class Initialized
DEBUG - 2011-06-17 11:08:54 --> Model Class Initialized
DEBUG - 2011-06-17 11:08:54 --> Model Class Initialized
DEBUG - 2011-06-17 11:08:54 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-06-17 11:08:54 --> Database Driver Class Initialized
DEBUG - 2011-06-17 11:08:54 --> File loaded: application/views/table/main.php
DEBUG - 2011-06-17 11:08:54 --> Helper loaded: url_helper
DEBUG - 2011-06-17 11:08:54 --> File loaded: application/views/common/header.php
DEBUG - 2011-06-17 11:08:54 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-06-17 11:08:54 --> File loaded: application/views/common/footer.php
DEBUG - 2011-06-17 11:08:54 --> File loaded: application/views/layout/main.php
DEBUG - 2011-06-17 11:08:54 --> Final output sent to browser
DEBUG - 2011-06-17 11:08:54 --> Total execution time: 0.0696
DEBUG - 2011-06-17 11:09:03 --> Config Class Initialized
DEBUG - 2011-06-17 11:09:03 --> Hooks Class Initialized
DEBUG - 2011-06-17 11:09:03 --> Utf8 Class Initialized
DEBUG - 2011-06-17 11:09:03 --> UTF-8 Support Enabled
DEBUG - 2011-06-17 11:09:03 --> URI Class Initialized
DEBUG - 2011-06-17 11:09:03 --> Router Class Initialized
DEBUG - 2011-06-17 11:09:03 --> Output Class Initialized
DEBUG - 2011-06-17 11:09:03 --> Input Class Initialized
DEBUG - 2011-06-17 11:09:03 --> Global POST and COOKIE data sanitized
DEBUG - 2011-06-17 11:09:03 --> Language Class Initialized
DEBUG - 2011-06-17 11:09:03 --> Loader Class Initialized
DEBUG - 2011-06-17 11:09:03 --> Controller Class Initialized
DEBUG - 2011-06-17 11:09:03 --> Model Class Initialized
DEBUG - 2011-06-17 11:09:03 --> Model Class Initialized
DEBUG - 2011-06-17 11:09:03 --> Model Class Initialized
DEBUG - 2011-06-17 11:09:03 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-06-17 11:09:03 --> Database Driver Class Initialized
DEBUG - 2011-06-17 11:09:03 --> File loaded: application/views/table/main.php
DEBUG - 2011-06-17 11:09:03 --> Helper loaded: url_helper
DEBUG - 2011-06-17 11:09:03 --> File loaded: application/views/common/header.php
DEBUG - 2011-06-17 11:09:03 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-06-17 11:09:03 --> File loaded: application/views/common/footer.php
DEBUG - 2011-06-17 11:09:03 --> File loaded: application/views/layout/main.php
DEBUG - 2011-06-17 11:09:03 --> Final output sent to browser
DEBUG - 2011-06-17 11:09:03 --> Total execution time: 0.2727
DEBUG - 2011-06-17 11:09:05 --> Config Class Initialized
DEBUG - 2011-06-17 11:09:05 --> Hooks Class Initialized
DEBUG - 2011-06-17 11:09:05 --> Utf8 Class Initialized
DEBUG - 2011-06-17 11:09:05 --> UTF-8 Support Enabled
DEBUG - 2011-06-17 11:09:05 --> URI Class Initialized
DEBUG - 2011-06-17 11:09:05 --> Router Class Initialized
ERROR - 2011-06-17 11:09:05 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-06-17 11:09:07 --> Config Class Initialized
DEBUG - 2011-06-17 11:09:07 --> Hooks Class Initialized
DEBUG - 2011-06-17 11:09:07 --> Utf8 Class Initialized
DEBUG - 2011-06-17 11:09:07 --> UTF-8 Support Enabled
DEBUG - 2011-06-17 11:09:07 --> URI Class Initialized
DEBUG - 2011-06-17 11:09:07 --> Router Class Initialized
DEBUG - 2011-06-17 11:09:07 --> Output Class Initialized
DEBUG - 2011-06-17 11:09:07 --> Input Class Initialized
DEBUG - 2011-06-17 11:09:07 --> Global POST and COOKIE data sanitized
DEBUG - 2011-06-17 11:09:07 --> Language Class Initialized
DEBUG - 2011-06-17 11:09:07 --> Loader Class Initialized
DEBUG - 2011-06-17 11:09:07 --> Controller Class Initialized
DEBUG - 2011-06-17 11:09:07 --> Model Class Initialized
DEBUG - 2011-06-17 11:09:07 --> Model Class Initialized
DEBUG - 2011-06-17 11:09:07 --> Model Class Initialized
DEBUG - 2011-06-17 11:09:07 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-06-17 11:09:07 --> Database Driver Class Initialized
DEBUG - 2011-06-17 11:09:07 --> File loaded: application/views/table/main.php
DEBUG - 2011-06-17 11:09:07 --> Helper loaded: url_helper
DEBUG - 2011-06-17 11:09:07 --> File loaded: application/views/common/header.php
DEBUG - 2011-06-17 11:09:07 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-06-17 11:09:07 --> File loaded: application/views/common/footer.php
DEBUG - 2011-06-17 11:09:07 --> File loaded: application/views/layout/main.php
DEBUG - 2011-06-17 11:09:07 --> Final output sent to browser
DEBUG - 2011-06-17 11:09:07 --> Total execution time: 0.0452
DEBUG - 2011-06-17 11:09:10 --> Config Class Initialized
DEBUG - 2011-06-17 11:09:10 --> Hooks Class Initialized
DEBUG - 2011-06-17 11:09:10 --> Utf8 Class Initialized
DEBUG - 2011-06-17 11:09:10 --> UTF-8 Support Enabled
DEBUG - 2011-06-17 11:09:10 --> URI Class Initialized
DEBUG - 2011-06-17 11:09:10 --> Router Class Initialized
DEBUG - 2011-06-17 11:09:10 --> Output Class Initialized
DEBUG - 2011-06-17 11:09:10 --> Input Class Initialized
DEBUG - 2011-06-17 11:09:10 --> Global POST and COOKIE data sanitized
DEBUG - 2011-06-17 11:09:10 --> Language Class Initialized
DEBUG - 2011-06-17 11:09:10 --> Loader Class Initialized
DEBUG - 2011-06-17 11:09:10 --> Controller Class Initialized
DEBUG - 2011-06-17 11:09:10 --> Model Class Initialized
DEBUG - 2011-06-17 11:09:10 --> Model Class Initialized
DEBUG - 2011-06-17 11:09:10 --> Model Class Initialized
DEBUG - 2011-06-17 11:09:10 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-06-17 11:09:10 --> Database Driver Class Initialized
DEBUG - 2011-06-17 11:09:10 --> File loaded: application/views/table/main.php
DEBUG - 2011-06-17 11:09:10 --> Helper loaded: url_helper
DEBUG - 2011-06-17 11:09:10 --> File loaded: application/views/common/header.php
DEBUG - 2011-06-17 11:09:10 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-06-17 11:09:10 --> File loaded: application/views/common/footer.php
DEBUG - 2011-06-17 11:09:10 --> File loaded: application/views/layout/main.php
DEBUG - 2011-06-17 11:09:10 --> Final output sent to browser
DEBUG - 2011-06-17 11:09:10 --> Total execution time: 0.2998
DEBUG - 2011-06-17 11:09:12 --> Config Class Initialized
DEBUG - 2011-06-17 11:09:12 --> Hooks Class Initialized
DEBUG - 2011-06-17 11:09:12 --> Utf8 Class Initialized
DEBUG - 2011-06-17 11:09:12 --> UTF-8 Support Enabled
DEBUG - 2011-06-17 11:09:12 --> URI Class Initialized
DEBUG - 2011-06-17 11:09:12 --> Router Class Initialized
DEBUG - 2011-06-17 11:09:12 --> Output Class Initialized
DEBUG - 2011-06-17 11:09:12 --> Input Class Initialized
DEBUG - 2011-06-17 11:09:12 --> Global POST and COOKIE data sanitized
DEBUG - 2011-06-17 11:09:12 --> Language Class Initialized
DEBUG - 2011-06-17 11:09:12 --> Loader Class Initialized
DEBUG - 2011-06-17 11:09:12 --> Controller Class Initialized
DEBUG - 2011-06-17 11:09:12 --> Model Class Initialized
DEBUG - 2011-06-17 11:09:12 --> Model Class Initialized
DEBUG - 2011-06-17 11:09:12 --> Model Class Initialized
DEBUG - 2011-06-17 11:09:12 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-06-17 11:09:12 --> Database Driver Class Initialized
DEBUG - 2011-06-17 11:09:12 --> File loaded: application/views/table/main.php
DEBUG - 2011-06-17 11:09:12 --> Helper loaded: url_helper
DEBUG - 2011-06-17 11:09:12 --> File loaded: application/views/common/header.php
DEBUG - 2011-06-17 11:09:12 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-06-17 11:09:12 --> File loaded: application/views/common/footer.php
DEBUG - 2011-06-17 11:09:12 --> File loaded: application/views/layout/main.php
DEBUG - 2011-06-17 11:09:12 --> Final output sent to browser
DEBUG - 2011-06-17 11:09:12 --> Total execution time: 0.0552
DEBUG - 2011-06-17 11:09:12 --> Config Class Initialized
DEBUG - 2011-06-17 11:09:12 --> Hooks Class Initialized
DEBUG - 2011-06-17 11:09:12 --> Utf8 Class Initialized
DEBUG - 2011-06-17 11:09:12 --> UTF-8 Support Enabled
DEBUG - 2011-06-17 11:09:12 --> URI Class Initialized
DEBUG - 2011-06-17 11:09:12 --> Router Class Initialized
ERROR - 2011-06-17 11:09:12 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-06-17 11:09:18 --> Config Class Initialized
DEBUG - 2011-06-17 11:09:18 --> Hooks Class Initialized
DEBUG - 2011-06-17 11:09:18 --> Utf8 Class Initialized
DEBUG - 2011-06-17 11:09:18 --> UTF-8 Support Enabled
DEBUG - 2011-06-17 11:09:18 --> URI Class Initialized
DEBUG - 2011-06-17 11:09:18 --> Router Class Initialized
DEBUG - 2011-06-17 11:09:18 --> Output Class Initialized
DEBUG - 2011-06-17 11:09:18 --> Input Class Initialized
DEBUG - 2011-06-17 11:09:18 --> Global POST and COOKIE data sanitized
DEBUG - 2011-06-17 11:09:18 --> Language Class Initialized
DEBUG - 2011-06-17 11:09:18 --> Loader Class Initialized
DEBUG - 2011-06-17 11:09:18 --> Controller Class Initialized
DEBUG - 2011-06-17 11:09:18 --> Model Class Initialized
DEBUG - 2011-06-17 11:09:18 --> Model Class Initialized
DEBUG - 2011-06-17 11:09:18 --> Model Class Initialized
DEBUG - 2011-06-17 11:09:18 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-06-17 11:09:18 --> Database Driver Class Initialized
DEBUG - 2011-06-17 11:09:18 --> File loaded: application/views/table/main.php
DEBUG - 2011-06-17 11:09:18 --> Helper loaded: url_helper
DEBUG - 2011-06-17 11:09:18 --> File loaded: application/views/common/header.php
DEBUG - 2011-06-17 11:09:18 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-06-17 11:09:18 --> File loaded: application/views/common/footer.php
DEBUG - 2011-06-17 11:09:18 --> File loaded: application/views/layout/main.php
DEBUG - 2011-06-17 11:09:18 --> Final output sent to browser
DEBUG - 2011-06-17 11:09:18 --> Total execution time: 0.2204
DEBUG - 2011-06-17 11:09:19 --> Config Class Initialized
DEBUG - 2011-06-17 11:09:19 --> Hooks Class Initialized
DEBUG - 2011-06-17 11:09:19 --> Utf8 Class Initialized
DEBUG - 2011-06-17 11:09:19 --> UTF-8 Support Enabled
DEBUG - 2011-06-17 11:09:19 --> URI Class Initialized
DEBUG - 2011-06-17 11:09:19 --> Router Class Initialized
DEBUG - 2011-06-17 11:09:19 --> Output Class Initialized
DEBUG - 2011-06-17 11:09:19 --> Input Class Initialized
DEBUG - 2011-06-17 11:09:19 --> Global POST and COOKIE data sanitized
DEBUG - 2011-06-17 11:09:19 --> Language Class Initialized
DEBUG - 2011-06-17 11:09:19 --> Loader Class Initialized
DEBUG - 2011-06-17 11:09:19 --> Controller Class Initialized
DEBUG - 2011-06-17 11:09:19 --> Model Class Initialized
DEBUG - 2011-06-17 11:09:19 --> Model Class Initialized
DEBUG - 2011-06-17 11:09:19 --> Model Class Initialized
DEBUG - 2011-06-17 11:09:19 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-06-17 11:09:19 --> Database Driver Class Initialized
DEBUG - 2011-06-17 11:09:19 --> File loaded: application/views/table/main.php
DEBUG - 2011-06-17 11:09:19 --> Helper loaded: url_helper
DEBUG - 2011-06-17 11:09:19 --> File loaded: application/views/common/header.php
DEBUG - 2011-06-17 11:09:19 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-06-17 11:09:19 --> File loaded: application/views/common/footer.php
DEBUG - 2011-06-17 11:09:19 --> File loaded: application/views/layout/main.php
DEBUG - 2011-06-17 11:09:19 --> Final output sent to browser
DEBUG - 2011-06-17 11:09:19 --> Total execution time: 0.0510
DEBUG - 2011-06-17 11:09:20 --> Config Class Initialized
DEBUG - 2011-06-17 11:09:20 --> Hooks Class Initialized
DEBUG - 2011-06-17 11:09:20 --> Utf8 Class Initialized
DEBUG - 2011-06-17 11:09:20 --> UTF-8 Support Enabled
DEBUG - 2011-06-17 11:09:20 --> URI Class Initialized
DEBUG - 2011-06-17 11:09:20 --> Router Class Initialized
ERROR - 2011-06-17 11:09:20 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-06-17 11:09:25 --> Config Class Initialized
DEBUG - 2011-06-17 11:09:25 --> Hooks Class Initialized
DEBUG - 2011-06-17 11:09:25 --> Utf8 Class Initialized
DEBUG - 2011-06-17 11:09:25 --> UTF-8 Support Enabled
DEBUG - 2011-06-17 11:09:25 --> URI Class Initialized
DEBUG - 2011-06-17 11:09:25 --> Router Class Initialized
DEBUG - 2011-06-17 11:09:25 --> Output Class Initialized
DEBUG - 2011-06-17 11:09:25 --> Input Class Initialized
DEBUG - 2011-06-17 11:09:25 --> Global POST and COOKIE data sanitized
DEBUG - 2011-06-17 11:09:25 --> Language Class Initialized
DEBUG - 2011-06-17 11:09:25 --> Loader Class Initialized
DEBUG - 2011-06-17 11:09:25 --> Controller Class Initialized
DEBUG - 2011-06-17 11:09:25 --> Model Class Initialized
DEBUG - 2011-06-17 11:09:25 --> Model Class Initialized
DEBUG - 2011-06-17 11:09:25 --> Model Class Initialized
DEBUG - 2011-06-17 11:09:25 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-06-17 11:09:25 --> Database Driver Class Initialized
DEBUG - 2011-06-17 11:09:25 --> File loaded: application/views/table/main.php
DEBUG - 2011-06-17 11:09:25 --> Helper loaded: url_helper
DEBUG - 2011-06-17 11:09:25 --> File loaded: application/views/common/header.php
DEBUG - 2011-06-17 11:09:25 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-06-17 11:09:25 --> File loaded: application/views/common/footer.php
DEBUG - 2011-06-17 11:09:25 --> File loaded: application/views/layout/main.php
DEBUG - 2011-06-17 11:09:25 --> Final output sent to browser
DEBUG - 2011-06-17 11:09:25 --> Total execution time: 0.2814
DEBUG - 2011-06-17 11:09:27 --> Config Class Initialized
DEBUG - 2011-06-17 11:09:27 --> Hooks Class Initialized
DEBUG - 2011-06-17 11:09:27 --> Utf8 Class Initialized
DEBUG - 2011-06-17 11:09:27 --> UTF-8 Support Enabled
DEBUG - 2011-06-17 11:09:27 --> URI Class Initialized
DEBUG - 2011-06-17 11:09:27 --> Router Class Initialized
ERROR - 2011-06-17 11:09:27 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-06-17 11:09:27 --> Config Class Initialized
DEBUG - 2011-06-17 11:09:27 --> Hooks Class Initialized
DEBUG - 2011-06-17 11:09:27 --> Utf8 Class Initialized
DEBUG - 2011-06-17 11:09:27 --> UTF-8 Support Enabled
DEBUG - 2011-06-17 11:09:27 --> URI Class Initialized
DEBUG - 2011-06-17 11:09:27 --> Router Class Initialized
DEBUG - 2011-06-17 11:09:27 --> Output Class Initialized
DEBUG - 2011-06-17 11:09:27 --> Input Class Initialized
DEBUG - 2011-06-17 11:09:27 --> Global POST and COOKIE data sanitized
DEBUG - 2011-06-17 11:09:27 --> Language Class Initialized
DEBUG - 2011-06-17 11:09:27 --> Loader Class Initialized
DEBUG - 2011-06-17 11:09:27 --> Controller Class Initialized
DEBUG - 2011-06-17 11:09:27 --> Model Class Initialized
DEBUG - 2011-06-17 11:09:27 --> Model Class Initialized
DEBUG - 2011-06-17 11:09:27 --> Model Class Initialized
DEBUG - 2011-06-17 11:09:27 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-06-17 11:09:27 --> Database Driver Class Initialized
DEBUG - 2011-06-17 11:09:28 --> File loaded: application/views/table/main.php
DEBUG - 2011-06-17 11:09:28 --> Helper loaded: url_helper
DEBUG - 2011-06-17 11:09:28 --> File loaded: application/views/common/header.php
DEBUG - 2011-06-17 11:09:28 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-06-17 11:09:28 --> File loaded: application/views/common/footer.php
DEBUG - 2011-06-17 11:09:28 --> File loaded: application/views/layout/main.php
DEBUG - 2011-06-17 11:09:28 --> Final output sent to browser
DEBUG - 2011-06-17 11:09:28 --> Total execution time: 0.0560
DEBUG - 2011-06-17 12:38:44 --> Config Class Initialized
DEBUG - 2011-06-17 12:38:44 --> Hooks Class Initialized
DEBUG - 2011-06-17 12:38:44 --> Utf8 Class Initialized
DEBUG - 2011-06-17 12:38:44 --> UTF-8 Support Enabled
DEBUG - 2011-06-17 12:38:44 --> URI Class Initialized
DEBUG - 2011-06-17 12:38:44 --> Router Class Initialized
DEBUG - 2011-06-17 12:38:44 --> Output Class Initialized
DEBUG - 2011-06-17 12:38:44 --> Input Class Initialized
DEBUG - 2011-06-17 12:38:44 --> Global POST and COOKIE data sanitized
DEBUG - 2011-06-17 12:38:44 --> Language Class Initialized
DEBUG - 2011-06-17 12:38:44 --> Loader Class Initialized
DEBUG - 2011-06-17 12:38:44 --> Controller Class Initialized
DEBUG - 2011-06-17 12:38:44 --> Model Class Initialized
DEBUG - 2011-06-17 12:38:44 --> Model Class Initialized
DEBUG - 2011-06-17 12:38:44 --> Model Class Initialized
DEBUG - 2011-06-17 12:38:44 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-06-17 12:38:44 --> Database Driver Class Initialized
DEBUG - 2011-06-17 12:38:48 --> File loaded: application/views/table/main.php
DEBUG - 2011-06-17 12:38:48 --> Helper loaded: url_helper
DEBUG - 2011-06-17 12:38:48 --> File loaded: application/views/common/header.php
DEBUG - 2011-06-17 12:38:48 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-06-17 12:38:48 --> File loaded: application/views/common/footer.php
DEBUG - 2011-06-17 12:38:48 --> File loaded: application/views/layout/main.php
DEBUG - 2011-06-17 12:38:48 --> Final output sent to browser
DEBUG - 2011-06-17 12:38:48 --> Total execution time: 4.0808
DEBUG - 2011-06-17 12:38:49 --> Config Class Initialized
DEBUG - 2011-06-17 12:38:49 --> Hooks Class Initialized
DEBUG - 2011-06-17 12:38:49 --> Utf8 Class Initialized
DEBUG - 2011-06-17 12:38:49 --> UTF-8 Support Enabled
DEBUG - 2011-06-17 12:38:49 --> URI Class Initialized
DEBUG - 2011-06-17 12:38:49 --> Router Class Initialized
DEBUG - 2011-06-17 12:38:49 --> Output Class Initialized
DEBUG - 2011-06-17 12:38:49 --> Input Class Initialized
DEBUG - 2011-06-17 12:38:49 --> Global POST and COOKIE data sanitized
DEBUG - 2011-06-17 12:38:49 --> Language Class Initialized
DEBUG - 2011-06-17 12:38:49 --> Loader Class Initialized
DEBUG - 2011-06-17 12:38:49 --> Controller Class Initialized
ERROR - 2011-06-17 12:38:49 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-06-17 12:38:49 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-06-17 12:38:49 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-06-17 12:38:49 --> Model Class Initialized
DEBUG - 2011-06-17 12:38:49 --> Model Class Initialized
DEBUG - 2011-06-17 12:38:49 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-06-17 12:38:49 --> Database Driver Class Initialized
DEBUG - 2011-06-17 12:38:49 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-06-17 12:38:49 --> Helper loaded: url_helper
DEBUG - 2011-06-17 12:38:49 --> File loaded: application/views/common/header.php
DEBUG - 2011-06-17 12:38:49 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-06-17 12:38:49 --> File loaded: application/views/common/footer.php
DEBUG - 2011-06-17 12:38:49 --> File loaded: application/views/layout/main.php
DEBUG - 2011-06-17 12:38:49 --> Final output sent to browser
DEBUG - 2011-06-17 12:38:49 --> Total execution time: 0.0986
DEBUG - 2011-06-17 13:11:40 --> Config Class Initialized
DEBUG - 2011-06-17 13:11:40 --> Hooks Class Initialized
DEBUG - 2011-06-17 13:11:40 --> Utf8 Class Initialized
DEBUG - 2011-06-17 13:11:40 --> UTF-8 Support Enabled
DEBUG - 2011-06-17 13:11:40 --> URI Class Initialized
DEBUG - 2011-06-17 13:11:40 --> Router Class Initialized
ERROR - 2011-06-17 13:11:40 --> 404 Page Not Found --> robots.txt
DEBUG - 2011-06-17 13:13:22 --> Config Class Initialized
DEBUG - 2011-06-17 13:13:22 --> Hooks Class Initialized
DEBUG - 2011-06-17 13:13:22 --> Utf8 Class Initialized
DEBUG - 2011-06-17 13:13:22 --> UTF-8 Support Enabled
DEBUG - 2011-06-17 13:13:22 --> URI Class Initialized
DEBUG - 2011-06-17 13:13:22 --> Router Class Initialized
DEBUG - 2011-06-17 13:13:22 --> Output Class Initialized
DEBUG - 2011-06-17 13:13:22 --> Input Class Initialized
DEBUG - 2011-06-17 13:13:22 --> Global POST and COOKIE data sanitized
DEBUG - 2011-06-17 13:13:22 --> Language Class Initialized
DEBUG - 2011-06-17 13:13:22 --> Loader Class Initialized
DEBUG - 2011-06-17 13:13:22 --> Controller Class Initialized
DEBUG - 2011-06-17 13:13:22 --> Model Class Initialized
DEBUG - 2011-06-17 13:13:22 --> Model Class Initialized
DEBUG - 2011-06-17 13:13:22 --> Model Class Initialized
DEBUG - 2011-06-17 13:13:22 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-06-17 13:13:22 --> Database Driver Class Initialized
DEBUG - 2011-06-17 13:13:22 --> File loaded: application/views/table/main.php
DEBUG - 2011-06-17 13:13:23 --> Helper loaded: url_helper
DEBUG - 2011-06-17 13:13:23 --> File loaded: application/views/common/header.php
DEBUG - 2011-06-17 13:13:23 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-06-17 13:13:23 --> File loaded: application/views/common/footer.php
DEBUG - 2011-06-17 13:13:23 --> File loaded: application/views/layout/main.php
DEBUG - 2011-06-17 13:13:23 --> Final output sent to browser
DEBUG - 2011-06-17 13:13:23 --> Total execution time: 0.5908
DEBUG - 2011-06-17 13:15:09 --> Config Class Initialized
DEBUG - 2011-06-17 13:15:09 --> Hooks Class Initialized
DEBUG - 2011-06-17 13:15:09 --> Utf8 Class Initialized
DEBUG - 2011-06-17 13:15:09 --> UTF-8 Support Enabled
DEBUG - 2011-06-17 13:15:09 --> URI Class Initialized
DEBUG - 2011-06-17 13:15:09 --> Router Class Initialized
DEBUG - 2011-06-17 13:15:09 --> Output Class Initialized
DEBUG - 2011-06-17 13:15:09 --> Input Class Initialized
DEBUG - 2011-06-17 13:15:09 --> Global POST and COOKIE data sanitized
DEBUG - 2011-06-17 13:15:09 --> Language Class Initialized
DEBUG - 2011-06-17 13:15:09 --> Loader Class Initialized
DEBUG - 2011-06-17 13:15:09 --> Controller Class Initialized
ERROR - 2011-06-17 13:15:09 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-06-17 13:15:09 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-06-17 13:15:09 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-06-17 13:15:09 --> Model Class Initialized
DEBUG - 2011-06-17 13:15:09 --> Model Class Initialized
DEBUG - 2011-06-17 13:15:09 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-06-17 13:15:09 --> Database Driver Class Initialized
DEBUG - 2011-06-17 13:15:09 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-06-17 13:15:09 --> Helper loaded: url_helper
DEBUG - 2011-06-17 13:15:09 --> File loaded: application/views/common/header.php
DEBUG - 2011-06-17 13:15:09 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-06-17 13:15:09 --> File loaded: application/views/common/footer.php
DEBUG - 2011-06-17 13:15:09 --> File loaded: application/views/layout/main.php
DEBUG - 2011-06-17 13:15:09 --> Final output sent to browser
DEBUG - 2011-06-17 13:15:09 --> Total execution time: 0.1916
DEBUG - 2011-06-17 14:24:21 --> Config Class Initialized
DEBUG - 2011-06-17 14:24:21 --> Hooks Class Initialized
DEBUG - 2011-06-17 14:24:21 --> Utf8 Class Initialized
DEBUG - 2011-06-17 14:24:21 --> UTF-8 Support Enabled
DEBUG - 2011-06-17 14:24:21 --> URI Class Initialized
DEBUG - 2011-06-17 14:24:21 --> Router Class Initialized
DEBUG - 2011-06-17 14:24:21 --> Output Class Initialized
DEBUG - 2011-06-17 14:24:21 --> Input Class Initialized
DEBUG - 2011-06-17 14:24:21 --> Global POST and COOKIE data sanitized
DEBUG - 2011-06-17 14:24:21 --> Language Class Initialized
DEBUG - 2011-06-17 14:24:21 --> Loader Class Initialized
DEBUG - 2011-06-17 14:24:21 --> Controller Class Initialized
DEBUG - 2011-06-17 14:24:21 --> Model Class Initialized
DEBUG - 2011-06-17 14:24:21 --> Model Class Initialized
DEBUG - 2011-06-17 14:24:21 --> Model Class Initialized
DEBUG - 2011-06-17 14:24:21 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-06-17 14:24:21 --> Database Driver Class Initialized
DEBUG - 2011-06-17 14:24:21 --> File loaded: application/views/table/main.php
DEBUG - 2011-06-17 14:24:21 --> Helper loaded: url_helper
DEBUG - 2011-06-17 14:24:21 --> File loaded: application/views/common/header.php
DEBUG - 2011-06-17 14:24:21 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-06-17 14:24:21 --> File loaded: application/views/common/footer.php
DEBUG - 2011-06-17 14:24:21 --> File loaded: application/views/layout/main.php
DEBUG - 2011-06-17 14:24:21 --> Final output sent to browser
DEBUG - 2011-06-17 14:24:21 --> Total execution time: 0.6119
DEBUG - 2011-06-17 14:24:24 --> Config Class Initialized
DEBUG - 2011-06-17 14:24:24 --> Hooks Class Initialized
DEBUG - 2011-06-17 14:24:24 --> Utf8 Class Initialized
DEBUG - 2011-06-17 14:24:24 --> UTF-8 Support Enabled
DEBUG - 2011-06-17 14:24:24 --> URI Class Initialized
DEBUG - 2011-06-17 14:24:24 --> Router Class Initialized
ERROR - 2011-06-17 14:24:24 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-06-17 15:12:45 --> Config Class Initialized
DEBUG - 2011-06-17 15:12:45 --> Hooks Class Initialized
DEBUG - 2011-06-17 15:12:45 --> Utf8 Class Initialized
DEBUG - 2011-06-17 15:12:45 --> UTF-8 Support Enabled
DEBUG - 2011-06-17 15:12:46 --> URI Class Initialized
DEBUG - 2011-06-17 15:12:46 --> Router Class Initialized
DEBUG - 2011-06-17 15:12:46 --> Output Class Initialized
DEBUG - 2011-06-17 15:12:46 --> Input Class Initialized
DEBUG - 2011-06-17 15:12:46 --> Global POST and COOKIE data sanitized
DEBUG - 2011-06-17 15:12:46 --> Language Class Initialized
DEBUG - 2011-06-17 15:12:46 --> Loader Class Initialized
DEBUG - 2011-06-17 15:12:46 --> Controller Class Initialized
DEBUG - 2011-06-17 15:12:46 --> Model Class Initialized
DEBUG - 2011-06-17 15:12:46 --> Model Class Initialized
DEBUG - 2011-06-17 15:12:46 --> Model Class Initialized
DEBUG - 2011-06-17 15:12:46 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-06-17 15:12:47 --> Database Driver Class Initialized
DEBUG - 2011-06-17 15:12:48 --> File loaded: application/views/table/main.php
DEBUG - 2011-06-17 15:12:48 --> Helper loaded: url_helper
DEBUG - 2011-06-17 15:12:48 --> File loaded: application/views/common/header.php
DEBUG - 2011-06-17 15:12:48 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-06-17 15:12:49 --> File loaded: application/views/common/footer.php
DEBUG - 2011-06-17 15:12:49 --> File loaded: application/views/layout/main.php
DEBUG - 2011-06-17 15:12:49 --> Final output sent to browser
DEBUG - 2011-06-17 15:12:49 --> Total execution time: 3.3852
DEBUG - 2011-06-17 15:12:49 --> Config Class Initialized
DEBUG - 2011-06-17 15:12:49 --> Hooks Class Initialized
DEBUG - 2011-06-17 15:12:49 --> Utf8 Class Initialized
DEBUG - 2011-06-17 15:12:49 --> UTF-8 Support Enabled
DEBUG - 2011-06-17 15:12:49 --> URI Class Initialized
DEBUG - 2011-06-17 15:12:49 --> Router Class Initialized
DEBUG - 2011-06-17 15:12:49 --> Output Class Initialized
DEBUG - 2011-06-17 15:12:49 --> Input Class Initialized
DEBUG - 2011-06-17 15:12:49 --> Global POST and COOKIE data sanitized
DEBUG - 2011-06-17 15:12:49 --> Language Class Initialized
DEBUG - 2011-06-17 15:12:49 --> Loader Class Initialized
DEBUG - 2011-06-17 15:12:49 --> Controller Class Initialized
ERROR - 2011-06-17 15:12:50 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-06-17 15:12:50 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-06-17 15:12:50 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-06-17 15:12:50 --> Model Class Initialized
DEBUG - 2011-06-17 15:12:50 --> Model Class Initialized
DEBUG - 2011-06-17 15:12:50 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-06-17 15:12:50 --> Database Driver Class Initialized
DEBUG - 2011-06-17 15:12:50 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-06-17 15:12:50 --> Helper loaded: url_helper
DEBUG - 2011-06-17 15:12:50 --> File loaded: application/views/common/header.php
DEBUG - 2011-06-17 15:12:50 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-06-17 15:12:50 --> File loaded: application/views/common/footer.php
DEBUG - 2011-06-17 15:12:50 --> File loaded: application/views/layout/main.php
DEBUG - 2011-06-17 15:12:50 --> Final output sent to browser
DEBUG - 2011-06-17 15:12:50 --> Total execution time: 0.5885
DEBUG - 2011-06-17 17:48:29 --> Config Class Initialized
DEBUG - 2011-06-17 17:48:29 --> Hooks Class Initialized
DEBUG - 2011-06-17 17:48:29 --> Utf8 Class Initialized
DEBUG - 2011-06-17 17:48:29 --> UTF-8 Support Enabled
DEBUG - 2011-06-17 17:48:29 --> URI Class Initialized
DEBUG - 2011-06-17 17:48:29 --> Router Class Initialized
DEBUG - 2011-06-17 17:48:29 --> Output Class Initialized
DEBUG - 2011-06-17 17:48:29 --> Input Class Initialized
DEBUG - 2011-06-17 17:48:29 --> Global POST and COOKIE data sanitized
DEBUG - 2011-06-17 17:48:29 --> Language Class Initialized
DEBUG - 2011-06-17 17:48:29 --> Loader Class Initialized
DEBUG - 2011-06-17 17:48:29 --> Controller Class Initialized
DEBUG - 2011-06-17 17:48:29 --> Model Class Initialized
DEBUG - 2011-06-17 17:48:29 --> Model Class Initialized
DEBUG - 2011-06-17 17:48:29 --> Model Class Initialized
DEBUG - 2011-06-17 17:48:29 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-06-17 17:48:29 --> Database Driver Class Initialized
DEBUG - 2011-06-17 17:48:30 --> File loaded: application/views/table/main.php
DEBUG - 2011-06-17 17:48:30 --> Helper loaded: url_helper
DEBUG - 2011-06-17 17:48:30 --> File loaded: application/views/common/header.php
DEBUG - 2011-06-17 17:48:30 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-06-17 17:48:30 --> File loaded: application/views/common/footer.php
DEBUG - 2011-06-17 17:48:30 --> File loaded: application/views/layout/main.php
DEBUG - 2011-06-17 17:48:30 --> Final output sent to browser
DEBUG - 2011-06-17 17:48:30 --> Total execution time: 0.8203
DEBUG - 2011-06-17 17:48:33 --> Config Class Initialized
DEBUG - 2011-06-17 17:48:33 --> Hooks Class Initialized
DEBUG - 2011-06-17 17:48:33 --> Utf8 Class Initialized
DEBUG - 2011-06-17 17:48:33 --> UTF-8 Support Enabled
DEBUG - 2011-06-17 17:48:33 --> URI Class Initialized
DEBUG - 2011-06-17 17:48:33 --> Router Class Initialized
DEBUG - 2011-06-17 17:48:33 --> Output Class Initialized
DEBUG - 2011-06-17 17:48:33 --> Input Class Initialized
DEBUG - 2011-06-17 17:48:33 --> Global POST and COOKIE data sanitized
DEBUG - 2011-06-17 17:48:33 --> Language Class Initialized
DEBUG - 2011-06-17 17:48:33 --> Loader Class Initialized
DEBUG - 2011-06-17 17:48:33 --> Controller Class Initialized
ERROR - 2011-06-17 17:48:33 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-06-17 17:48:33 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-06-17 17:48:33 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-06-17 17:48:33 --> Model Class Initialized
DEBUG - 2011-06-17 17:48:33 --> Model Class Initialized
DEBUG - 2011-06-17 17:48:33 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-06-17 17:48:33 --> Database Driver Class Initialized
DEBUG - 2011-06-17 17:48:33 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-06-17 17:48:33 --> Helper loaded: url_helper
DEBUG - 2011-06-17 17:48:33 --> File loaded: application/views/common/header.php
DEBUG - 2011-06-17 17:48:33 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-06-17 17:48:33 --> File loaded: application/views/common/footer.php
DEBUG - 2011-06-17 17:48:33 --> File loaded: application/views/layout/main.php
DEBUG - 2011-06-17 17:48:33 --> Final output sent to browser
DEBUG - 2011-06-17 17:48:33 --> Total execution time: 0.1393
DEBUG - 2011-06-17 18:17:51 --> Config Class Initialized
DEBUG - 2011-06-17 18:17:51 --> Hooks Class Initialized
DEBUG - 2011-06-17 18:17:51 --> Utf8 Class Initialized
DEBUG - 2011-06-17 18:17:51 --> UTF-8 Support Enabled
DEBUG - 2011-06-17 18:17:51 --> URI Class Initialized
DEBUG - 2011-06-17 18:17:51 --> Router Class Initialized
ERROR - 2011-06-17 18:17:51 --> 404 Page Not Found --> robots.txt
DEBUG - 2011-06-17 18:18:42 --> Config Class Initialized
DEBUG - 2011-06-17 18:18:42 --> Hooks Class Initialized
DEBUG - 2011-06-17 18:18:42 --> Utf8 Class Initialized
DEBUG - 2011-06-17 18:18:42 --> UTF-8 Support Enabled
DEBUG - 2011-06-17 18:18:42 --> URI Class Initialized
DEBUG - 2011-06-17 18:18:42 --> Router Class Initialized
DEBUG - 2011-06-17 18:18:42 --> No URI present. Default controller set.
DEBUG - 2011-06-17 18:18:42 --> Output Class Initialized
DEBUG - 2011-06-17 18:18:42 --> Input Class Initialized
DEBUG - 2011-06-17 18:18:42 --> Global POST and COOKIE data sanitized
DEBUG - 2011-06-17 18:18:42 --> Language Class Initialized
DEBUG - 2011-06-17 18:18:42 --> Loader Class Initialized
DEBUG - 2011-06-17 18:18:42 --> Controller Class Initialized
DEBUG - 2011-06-17 18:18:42 --> File loaded: application/views/splash/main.php
DEBUG - 2011-06-17 18:18:42 --> Helper loaded: url_helper
DEBUG - 2011-06-17 18:18:42 --> File loaded: application/views/common/header.php
DEBUG - 2011-06-17 18:18:42 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-06-17 18:18:42 --> File loaded: application/views/common/footer.php
DEBUG - 2011-06-17 18:18:42 --> File loaded: application/views/layout/main.php
DEBUG - 2011-06-17 18:18:42 --> Final output sent to browser
DEBUG - 2011-06-17 18:18:42 --> Total execution time: 0.2268
DEBUG - 2011-06-17 20:24:26 --> Config Class Initialized
DEBUG - 2011-06-17 20:24:26 --> Hooks Class Initialized
DEBUG - 2011-06-17 20:24:26 --> Utf8 Class Initialized
DEBUG - 2011-06-17 20:24:26 --> UTF-8 Support Enabled
DEBUG - 2011-06-17 20:24:26 --> URI Class Initialized
DEBUG - 2011-06-17 20:24:26 --> Router Class Initialized
DEBUG - 2011-06-17 20:24:26 --> Output Class Initialized
DEBUG - 2011-06-17 20:24:26 --> Input Class Initialized
DEBUG - 2011-06-17 20:24:26 --> Global POST and COOKIE data sanitized
DEBUG - 2011-06-17 20:24:26 --> Language Class Initialized
DEBUG - 2011-06-17 20:24:26 --> Loader Class Initialized
DEBUG - 2011-06-17 20:24:26 --> Controller Class Initialized
DEBUG - 2011-06-17 20:24:26 --> Model Class Initialized
DEBUG - 2011-06-17 20:24:26 --> Model Class Initialized
DEBUG - 2011-06-17 20:24:26 --> Model Class Initialized
DEBUG - 2011-06-17 20:24:26 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-06-17 20:24:26 --> Database Driver Class Initialized
DEBUG - 2011-06-17 20:24:26 --> File loaded: application/views/table/main.php
DEBUG - 2011-06-17 20:24:26 --> Helper loaded: url_helper
DEBUG - 2011-06-17 20:24:26 --> File loaded: application/views/common/header.php
DEBUG - 2011-06-17 20:24:26 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-06-17 20:24:26 --> File loaded: application/views/common/footer.php
DEBUG - 2011-06-17 20:24:26 --> File loaded: application/views/layout/main.php
DEBUG - 2011-06-17 20:24:26 --> Final output sent to browser
DEBUG - 2011-06-17 20:24:26 --> Total execution time: 0.5671
DEBUG - 2011-06-17 20:24:27 --> Config Class Initialized
DEBUG - 2011-06-17 20:24:27 --> Hooks Class Initialized
DEBUG - 2011-06-17 20:24:27 --> Utf8 Class Initialized
DEBUG - 2011-06-17 20:24:27 --> UTF-8 Support Enabled
DEBUG - 2011-06-17 20:24:27 --> URI Class Initialized
DEBUG - 2011-06-17 20:24:27 --> Router Class Initialized
DEBUG - 2011-06-17 20:24:27 --> Output Class Initialized
DEBUG - 2011-06-17 20:24:27 --> Input Class Initialized
DEBUG - 2011-06-17 20:24:27 --> Global POST and COOKIE data sanitized
DEBUG - 2011-06-17 20:24:27 --> Language Class Initialized
DEBUG - 2011-06-17 20:24:27 --> Loader Class Initialized
DEBUG - 2011-06-17 20:24:27 --> Controller Class Initialized
ERROR - 2011-06-17 20:24:27 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-06-17 20:24:27 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-06-17 20:24:27 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-06-17 20:24:27 --> Model Class Initialized
DEBUG - 2011-06-17 20:24:27 --> Model Class Initialized
DEBUG - 2011-06-17 20:24:27 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-06-17 20:24:27 --> Database Driver Class Initialized
DEBUG - 2011-06-17 20:24:27 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-06-17 20:24:27 --> Helper loaded: url_helper
DEBUG - 2011-06-17 20:24:27 --> File loaded: application/views/common/header.php
DEBUG - 2011-06-17 20:24:27 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-06-17 20:24:27 --> File loaded: application/views/common/footer.php
DEBUG - 2011-06-17 20:24:27 --> File loaded: application/views/layout/main.php
DEBUG - 2011-06-17 20:24:27 --> Final output sent to browser
DEBUG - 2011-06-17 20:24:27 --> Total execution time: 0.0774
DEBUG - 2011-06-17 21:27:46 --> Config Class Initialized
DEBUG - 2011-06-17 21:27:46 --> Hooks Class Initialized
DEBUG - 2011-06-17 21:27:46 --> Utf8 Class Initialized
DEBUG - 2011-06-17 21:27:46 --> UTF-8 Support Enabled
DEBUG - 2011-06-17 21:27:46 --> URI Class Initialized
DEBUG - 2011-06-17 21:27:46 --> Router Class Initialized
ERROR - 2011-06-17 21:27:46 --> 404 Page Not Found --> robots.txt
DEBUG - 2011-06-17 21:28:42 --> Config Class Initialized
DEBUG - 2011-06-17 21:28:42 --> Hooks Class Initialized
DEBUG - 2011-06-17 21:28:42 --> Utf8 Class Initialized
DEBUG - 2011-06-17 21:28:42 --> UTF-8 Support Enabled
DEBUG - 2011-06-17 21:28:42 --> URI Class Initialized
DEBUG - 2011-06-17 21:28:42 --> Router Class Initialized
DEBUG - 2011-06-17 21:28:42 --> Output Class Initialized
DEBUG - 2011-06-17 21:28:42 --> Input Class Initialized
DEBUG - 2011-06-17 21:28:42 --> Global POST and COOKIE data sanitized
DEBUG - 2011-06-17 21:28:42 --> Language Class Initialized
DEBUG - 2011-06-17 21:28:42 --> Loader Class Initialized
DEBUG - 2011-06-17 21:28:43 --> Controller Class Initialized
ERROR - 2011-06-17 21:28:43 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-06-17 21:28:43 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-06-17 21:28:43 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-06-17 21:28:43 --> Model Class Initialized
DEBUG - 2011-06-17 21:28:43 --> Model Class Initialized
DEBUG - 2011-06-17 21:28:43 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-06-17 21:28:43 --> Database Driver Class Initialized
DEBUG - 2011-06-17 21:28:43 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-06-17 21:28:43 --> Helper loaded: url_helper
DEBUG - 2011-06-17 21:28:43 --> File loaded: application/views/common/header.php
DEBUG - 2011-06-17 21:28:43 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-06-17 21:28:43 --> File loaded: application/views/common/footer.php
DEBUG - 2011-06-17 21:28:43 --> File loaded: application/views/layout/main.php
DEBUG - 2011-06-17 21:28:43 --> Final output sent to browser
DEBUG - 2011-06-17 21:28:43 --> Total execution time: 0.3098
DEBUG - 2011-06-17 22:58:03 --> Config Class Initialized
DEBUG - 2011-06-17 22:58:03 --> Hooks Class Initialized
DEBUG - 2011-06-17 22:58:03 --> Utf8 Class Initialized
DEBUG - 2011-06-17 22:58:03 --> UTF-8 Support Enabled
DEBUG - 2011-06-17 22:58:03 --> URI Class Initialized
DEBUG - 2011-06-17 22:58:03 --> Router Class Initialized
DEBUG - 2011-06-17 22:58:03 --> Output Class Initialized
DEBUG - 2011-06-17 22:58:03 --> Input Class Initialized
DEBUG - 2011-06-17 22:58:03 --> Global POST and COOKIE data sanitized
DEBUG - 2011-06-17 22:58:03 --> Language Class Initialized
DEBUG - 2011-06-17 22:58:03 --> Loader Class Initialized
DEBUG - 2011-06-17 22:58:03 --> Controller Class Initialized
DEBUG - 2011-06-17 22:58:03 --> Model Class Initialized
DEBUG - 2011-06-17 22:58:03 --> Model Class Initialized
DEBUG - 2011-06-17 22:58:03 --> Model Class Initialized
DEBUG - 2011-06-17 22:58:03 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-06-17 22:58:03 --> Database Driver Class Initialized
DEBUG - 2011-06-17 22:58:04 --> File loaded: application/views/table/main.php
DEBUG - 2011-06-17 22:58:04 --> Helper loaded: url_helper
DEBUG - 2011-06-17 22:58:04 --> File loaded: application/views/common/header.php
DEBUG - 2011-06-17 22:58:04 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-06-17 22:58:04 --> File loaded: application/views/common/footer.php
DEBUG - 2011-06-17 22:58:04 --> File loaded: application/views/layout/main.php
DEBUG - 2011-06-17 22:58:04 --> Final output sent to browser
DEBUG - 2011-06-17 22:58:04 --> Total execution time: 0.6035
DEBUG - 2011-06-17 22:58:05 --> Config Class Initialized
DEBUG - 2011-06-17 22:58:05 --> Hooks Class Initialized
DEBUG - 2011-06-17 22:58:05 --> Utf8 Class Initialized
DEBUG - 2011-06-17 22:58:05 --> UTF-8 Support Enabled
DEBUG - 2011-06-17 22:58:05 --> URI Class Initialized
DEBUG - 2011-06-17 22:58:05 --> Router Class Initialized
DEBUG - 2011-06-17 22:58:05 --> Output Class Initialized
DEBUG - 2011-06-17 22:58:05 --> Input Class Initialized
DEBUG - 2011-06-17 22:58:05 --> Global POST and COOKIE data sanitized
DEBUG - 2011-06-17 22:58:05 --> Language Class Initialized
DEBUG - 2011-06-17 22:58:05 --> Loader Class Initialized
DEBUG - 2011-06-17 22:58:05 --> Controller Class Initialized
ERROR - 2011-06-17 22:58:05 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-06-17 22:58:05 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-06-17 22:58:05 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-06-17 22:58:05 --> Model Class Initialized
DEBUG - 2011-06-17 22:58:05 --> Model Class Initialized
DEBUG - 2011-06-17 22:58:05 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-06-17 22:58:05 --> Database Driver Class Initialized
DEBUG - 2011-06-17 22:58:05 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-06-17 22:58:05 --> Helper loaded: url_helper
DEBUG - 2011-06-17 22:58:05 --> File loaded: application/views/common/header.php
DEBUG - 2011-06-17 22:58:05 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-06-17 22:58:05 --> File loaded: application/views/common/footer.php
DEBUG - 2011-06-17 22:58:05 --> File loaded: application/views/layout/main.php
DEBUG - 2011-06-17 22:58:05 --> Final output sent to browser
DEBUG - 2011-06-17 22:58:05 --> Total execution time: 0.0809
DEBUG - 2011-06-17 23:25:35 --> Config Class Initialized
DEBUG - 2011-06-17 23:25:35 --> Hooks Class Initialized
DEBUG - 2011-06-17 23:25:35 --> Utf8 Class Initialized
DEBUG - 2011-06-17 23:25:35 --> UTF-8 Support Enabled
DEBUG - 2011-06-17 23:25:35 --> URI Class Initialized
DEBUG - 2011-06-17 23:25:35 --> Router Class Initialized
ERROR - 2011-06-17 23:25:35 --> 404 Page Not Found --> robots.txt
DEBUG - 2011-06-17 23:25:36 --> Config Class Initialized
DEBUG - 2011-06-17 23:25:36 --> Hooks Class Initialized
DEBUG - 2011-06-17 23:25:36 --> Utf8 Class Initialized
DEBUG - 2011-06-17 23:25:36 --> UTF-8 Support Enabled
DEBUG - 2011-06-17 23:25:36 --> URI Class Initialized
DEBUG - 2011-06-17 23:25:36 --> Router Class Initialized
DEBUG - 2011-06-17 23:25:36 --> Output Class Initialized
DEBUG - 2011-06-17 23:25:36 --> Input Class Initialized
DEBUG - 2011-06-17 23:25:36 --> Global POST and COOKIE data sanitized
DEBUG - 2011-06-17 23:25:36 --> Language Class Initialized
DEBUG - 2011-06-17 23:25:36 --> Loader Class Initialized
DEBUG - 2011-06-17 23:25:36 --> Controller Class Initialized
DEBUG - 2011-06-17 23:25:36 --> Model Class Initialized
DEBUG - 2011-06-17 23:25:36 --> Model Class Initialized
DEBUG - 2011-06-17 23:25:36 --> Model Class Initialized
DEBUG - 2011-06-17 23:25:36 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-06-17 23:25:37 --> Database Driver Class Initialized
DEBUG - 2011-06-17 23:25:37 --> File loaded: application/views/table/main.php
DEBUG - 2011-06-17 23:25:37 --> Helper loaded: url_helper
DEBUG - 2011-06-17 23:25:37 --> File loaded: application/views/common/header.php
DEBUG - 2011-06-17 23:25:37 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-06-17 23:25:37 --> File loaded: application/views/common/footer.php
DEBUG - 2011-06-17 23:25:37 --> File loaded: application/views/layout/main.php
DEBUG - 2011-06-17 23:25:37 --> Final output sent to browser
DEBUG - 2011-06-17 23:25:37 --> Total execution time: 1.1912

<?php  if ( ! defined('BASEPATH')) exit('No direct script access allowed'); ?>

DEBUG - 2011-04-14 01:42:26 --> Config Class Initialized
DEBUG - 2011-04-14 01:42:26 --> Hooks Class Initialized
DEBUG - 2011-04-14 01:42:26 --> Utf8 Class Initialized
DEBUG - 2011-04-14 01:42:26 --> UTF-8 Support Enabled
DEBUG - 2011-04-14 01:42:26 --> URI Class Initialized
DEBUG - 2011-04-14 01:42:26 --> Router Class Initialized
DEBUG - 2011-04-14 01:42:26 --> Output Class Initialized
DEBUG - 2011-04-14 01:42:26 --> Input Class Initialized
DEBUG - 2011-04-14 01:42:26 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-14 01:42:26 --> Language Class Initialized
DEBUG - 2011-04-14 01:42:26 --> Loader Class Initialized
DEBUG - 2011-04-14 01:42:26 --> Controller Class Initialized
ERROR - 2011-04-14 01:42:26 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-04-14 01:42:26 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-04-14 01:42:26 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-04-14 01:42:26 --> Model Class Initialized
DEBUG - 2011-04-14 01:42:26 --> Model Class Initialized
DEBUG - 2011-04-14 01:42:26 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-14 01:42:27 --> Database Driver Class Initialized
DEBUG - 2011-04-14 01:42:27 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-04-14 01:42:27 --> Helper loaded: url_helper
DEBUG - 2011-04-14 01:42:27 --> File loaded: application/views/common/header.php
DEBUG - 2011-04-14 01:42:27 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-04-14 01:42:27 --> File loaded: application/views/common/footer.php
DEBUG - 2011-04-14 01:42:27 --> File loaded: application/views/layout/main.php
DEBUG - 2011-04-14 01:42:27 --> Final output sent to browser
DEBUG - 2011-04-14 01:42:27 --> Total execution time: 0.6895
DEBUG - 2011-04-14 01:42:30 --> Config Class Initialized
DEBUG - 2011-04-14 01:42:30 --> Hooks Class Initialized
DEBUG - 2011-04-14 01:42:30 --> Utf8 Class Initialized
DEBUG - 2011-04-14 01:42:30 --> UTF-8 Support Enabled
DEBUG - 2011-04-14 01:42:30 --> URI Class Initialized
DEBUG - 2011-04-14 01:42:30 --> Router Class Initialized
DEBUG - 2011-04-14 01:42:30 --> Output Class Initialized
DEBUG - 2011-04-14 01:42:30 --> Input Class Initialized
DEBUG - 2011-04-14 01:42:30 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-14 01:42:30 --> Language Class Initialized
DEBUG - 2011-04-14 01:42:30 --> Loader Class Initialized
DEBUG - 2011-04-14 01:42:30 --> Controller Class Initialized
DEBUG - 2011-04-14 01:42:30 --> Model Class Initialized
DEBUG - 2011-04-14 01:42:31 --> Model Class Initialized
DEBUG - 2011-04-14 01:42:31 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-14 01:42:31 --> Database Driver Class Initialized
DEBUG - 2011-04-14 01:42:31 --> Final output sent to browser
DEBUG - 2011-04-14 01:42:31 --> Total execution time: 0.7923
DEBUG - 2011-04-14 02:06:32 --> Config Class Initialized
DEBUG - 2011-04-14 02:06:32 --> Hooks Class Initialized
DEBUG - 2011-04-14 02:06:32 --> Utf8 Class Initialized
DEBUG - 2011-04-14 02:06:32 --> UTF-8 Support Enabled
DEBUG - 2011-04-14 02:06:32 --> URI Class Initialized
DEBUG - 2011-04-14 02:06:32 --> Router Class Initialized
DEBUG - 2011-04-14 02:06:33 --> Output Class Initialized
DEBUG - 2011-04-14 02:06:33 --> Input Class Initialized
DEBUG - 2011-04-14 02:06:33 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-14 02:06:33 --> Language Class Initialized
DEBUG - 2011-04-14 02:06:33 --> Loader Class Initialized
DEBUG - 2011-04-14 02:06:33 --> Controller Class Initialized
DEBUG - 2011-04-14 02:06:33 --> Model Class Initialized
DEBUG - 2011-04-14 02:06:33 --> Model Class Initialized
DEBUG - 2011-04-14 02:06:33 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-14 02:06:33 --> Database Driver Class Initialized
DEBUG - 2011-04-14 02:06:35 --> Final output sent to browser
DEBUG - 2011-04-14 02:06:35 --> Total execution time: 3.0606
DEBUG - 2011-04-14 02:09:50 --> Config Class Initialized
DEBUG - 2011-04-14 02:09:50 --> Hooks Class Initialized
DEBUG - 2011-04-14 02:09:50 --> Utf8 Class Initialized
DEBUG - 2011-04-14 02:09:50 --> UTF-8 Support Enabled
DEBUG - 2011-04-14 02:09:50 --> URI Class Initialized
DEBUG - 2011-04-14 02:09:50 --> Router Class Initialized
DEBUG - 2011-04-14 02:09:50 --> No URI present. Default controller set.
DEBUG - 2011-04-14 02:09:50 --> Output Class Initialized
DEBUG - 2011-04-14 02:09:50 --> Input Class Initialized
DEBUG - 2011-04-14 02:09:50 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-14 02:09:50 --> Language Class Initialized
DEBUG - 2011-04-14 02:09:50 --> Loader Class Initialized
DEBUG - 2011-04-14 02:09:50 --> Controller Class Initialized
DEBUG - 2011-04-14 02:09:51 --> File loaded: application/views/splash/main.php
DEBUG - 2011-04-14 02:09:53 --> Helper loaded: url_helper
DEBUG - 2011-04-14 02:09:53 --> File loaded: application/views/common/header.php
DEBUG - 2011-04-14 02:09:53 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-04-14 02:09:53 --> File loaded: application/views/common/footer.php
DEBUG - 2011-04-14 02:09:53 --> File loaded: application/views/layout/main.php
DEBUG - 2011-04-14 02:09:53 --> Final output sent to browser
DEBUG - 2011-04-14 02:09:53 --> Total execution time: 3.3750
DEBUG - 2011-04-14 02:09:56 --> Config Class Initialized
DEBUG - 2011-04-14 02:09:56 --> Hooks Class Initialized
DEBUG - 2011-04-14 02:09:56 --> Utf8 Class Initialized
DEBUG - 2011-04-14 02:09:56 --> UTF-8 Support Enabled
DEBUG - 2011-04-14 02:09:56 --> URI Class Initialized
DEBUG - 2011-04-14 02:09:56 --> Router Class Initialized
ERROR - 2011-04-14 02:09:56 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-04-14 02:09:57 --> Config Class Initialized
DEBUG - 2011-04-14 02:09:57 --> Hooks Class Initialized
DEBUG - 2011-04-14 02:09:57 --> Utf8 Class Initialized
DEBUG - 2011-04-14 02:09:57 --> UTF-8 Support Enabled
DEBUG - 2011-04-14 02:09:57 --> URI Class Initialized
DEBUG - 2011-04-14 02:09:57 --> Router Class Initialized
ERROR - 2011-04-14 02:09:57 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-04-14 02:09:59 --> Config Class Initialized
DEBUG - 2011-04-14 02:09:59 --> Hooks Class Initialized
DEBUG - 2011-04-14 02:09:59 --> Utf8 Class Initialized
DEBUG - 2011-04-14 02:09:59 --> UTF-8 Support Enabled
DEBUG - 2011-04-14 02:09:59 --> URI Class Initialized
DEBUG - 2011-04-14 02:09:59 --> Router Class Initialized
DEBUG - 2011-04-14 02:09:59 --> Output Class Initialized
DEBUG - 2011-04-14 02:09:59 --> Input Class Initialized
DEBUG - 2011-04-14 02:09:59 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-14 02:09:59 --> Language Class Initialized
DEBUG - 2011-04-14 02:10:00 --> Loader Class Initialized
DEBUG - 2011-04-14 02:10:00 --> Controller Class Initialized
DEBUG - 2011-04-14 02:10:00 --> Model Class Initialized
DEBUG - 2011-04-14 02:10:00 --> Model Class Initialized
DEBUG - 2011-04-14 02:10:00 --> Model Class Initialized
DEBUG - 2011-04-14 02:10:00 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-14 02:10:00 --> Database Driver Class Initialized
DEBUG - 2011-04-14 02:10:08 --> File loaded: application/views/table/main.php
DEBUG - 2011-04-14 02:10:08 --> Helper loaded: url_helper
DEBUG - 2011-04-14 02:10:08 --> File loaded: application/views/common/header.php
DEBUG - 2011-04-14 02:10:08 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-04-14 02:10:08 --> File loaded: application/views/common/footer.php
DEBUG - 2011-04-14 02:10:08 --> File loaded: application/views/layout/main.php
DEBUG - 2011-04-14 02:10:08 --> Final output sent to browser
DEBUG - 2011-04-14 02:10:08 --> Total execution time: 8.8261
DEBUG - 2011-04-14 02:10:10 --> Config Class Initialized
DEBUG - 2011-04-14 02:10:10 --> Hooks Class Initialized
DEBUG - 2011-04-14 02:10:10 --> Utf8 Class Initialized
DEBUG - 2011-04-14 02:10:10 --> UTF-8 Support Enabled
DEBUG - 2011-04-14 02:10:10 --> URI Class Initialized
DEBUG - 2011-04-14 02:10:10 --> Router Class Initialized
ERROR - 2011-04-14 02:10:10 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-04-14 02:10:29 --> Config Class Initialized
DEBUG - 2011-04-14 02:10:29 --> Hooks Class Initialized
DEBUG - 2011-04-14 02:10:29 --> Utf8 Class Initialized
DEBUG - 2011-04-14 02:10:29 --> UTF-8 Support Enabled
DEBUG - 2011-04-14 02:10:29 --> URI Class Initialized
DEBUG - 2011-04-14 02:10:29 --> Router Class Initialized
DEBUG - 2011-04-14 02:10:29 --> Output Class Initialized
DEBUG - 2011-04-14 02:10:29 --> Input Class Initialized
DEBUG - 2011-04-14 02:10:29 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-14 02:10:29 --> Language Class Initialized
DEBUG - 2011-04-14 02:10:29 --> Loader Class Initialized
DEBUG - 2011-04-14 02:10:29 --> Controller Class Initialized
DEBUG - 2011-04-14 02:10:29 --> Model Class Initialized
DEBUG - 2011-04-14 02:10:29 --> Model Class Initialized
DEBUG - 2011-04-14 02:10:29 --> Model Class Initialized
DEBUG - 2011-04-14 02:10:29 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-14 02:10:29 --> Database Driver Class Initialized
DEBUG - 2011-04-14 02:10:30 --> File loaded: application/views/table/main.php
DEBUG - 2011-04-14 02:10:30 --> Helper loaded: url_helper
DEBUG - 2011-04-14 02:10:30 --> File loaded: application/views/common/header.php
DEBUG - 2011-04-14 02:10:30 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-04-14 02:10:30 --> File loaded: application/views/common/footer.php
DEBUG - 2011-04-14 02:10:30 --> File loaded: application/views/layout/main.php
DEBUG - 2011-04-14 02:10:30 --> Final output sent to browser
DEBUG - 2011-04-14 02:10:30 --> Total execution time: 0.9245
DEBUG - 2011-04-14 02:10:32 --> Config Class Initialized
DEBUG - 2011-04-14 02:10:32 --> Hooks Class Initialized
DEBUG - 2011-04-14 02:10:32 --> Utf8 Class Initialized
DEBUG - 2011-04-14 02:10:32 --> UTF-8 Support Enabled
DEBUG - 2011-04-14 02:10:32 --> URI Class Initialized
DEBUG - 2011-04-14 02:10:32 --> Router Class Initialized
ERROR - 2011-04-14 02:10:32 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-04-14 02:10:33 --> Config Class Initialized
DEBUG - 2011-04-14 02:10:33 --> Hooks Class Initialized
DEBUG - 2011-04-14 02:10:33 --> Utf8 Class Initialized
DEBUG - 2011-04-14 02:10:33 --> UTF-8 Support Enabled
DEBUG - 2011-04-14 02:10:33 --> URI Class Initialized
DEBUG - 2011-04-14 02:10:33 --> Router Class Initialized
DEBUG - 2011-04-14 02:10:33 --> Output Class Initialized
DEBUG - 2011-04-14 02:10:33 --> Input Class Initialized
DEBUG - 2011-04-14 02:10:33 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-14 02:10:33 --> Language Class Initialized
DEBUG - 2011-04-14 02:10:33 --> Loader Class Initialized
DEBUG - 2011-04-14 02:10:33 --> Controller Class Initialized
DEBUG - 2011-04-14 02:10:33 --> Model Class Initialized
DEBUG - 2011-04-14 02:10:33 --> Model Class Initialized
DEBUG - 2011-04-14 02:10:33 --> Model Class Initialized
DEBUG - 2011-04-14 02:10:33 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-14 02:10:33 --> Database Driver Class Initialized
DEBUG - 2011-04-14 02:10:33 --> File loaded: application/views/table/main.php
DEBUG - 2011-04-14 02:10:33 --> Helper loaded: url_helper
DEBUG - 2011-04-14 02:10:33 --> File loaded: application/views/common/header.php
DEBUG - 2011-04-14 02:10:33 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-04-14 02:10:33 --> File loaded: application/views/common/footer.php
DEBUG - 2011-04-14 02:10:33 --> File loaded: application/views/layout/main.php
DEBUG - 2011-04-14 02:10:33 --> Final output sent to browser
DEBUG - 2011-04-14 02:10:33 --> Total execution time: 0.0702
DEBUG - 2011-04-14 02:10:45 --> Config Class Initialized
DEBUG - 2011-04-14 02:10:45 --> Hooks Class Initialized
DEBUG - 2011-04-14 02:10:45 --> Utf8 Class Initialized
DEBUG - 2011-04-14 02:10:45 --> UTF-8 Support Enabled
DEBUG - 2011-04-14 02:10:45 --> URI Class Initialized
DEBUG - 2011-04-14 02:10:45 --> Router Class Initialized
DEBUG - 2011-04-14 02:10:45 --> Output Class Initialized
DEBUG - 2011-04-14 02:10:45 --> Input Class Initialized
DEBUG - 2011-04-14 02:10:45 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-14 02:10:45 --> Language Class Initialized
DEBUG - 2011-04-14 02:10:45 --> Loader Class Initialized
DEBUG - 2011-04-14 02:10:45 --> Controller Class Initialized
DEBUG - 2011-04-14 02:10:45 --> Model Class Initialized
DEBUG - 2011-04-14 02:10:45 --> Model Class Initialized
DEBUG - 2011-04-14 02:10:45 --> Model Class Initialized
DEBUG - 2011-04-14 02:10:45 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-14 02:10:45 --> Database Driver Class Initialized
DEBUG - 2011-04-14 02:10:47 --> File loaded: application/views/table/main.php
DEBUG - 2011-04-14 02:10:47 --> Helper loaded: url_helper
DEBUG - 2011-04-14 02:10:47 --> File loaded: application/views/common/header.php
DEBUG - 2011-04-14 02:10:47 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-04-14 02:10:47 --> File loaded: application/views/common/footer.php
DEBUG - 2011-04-14 02:10:47 --> File loaded: application/views/layout/main.php
DEBUG - 2011-04-14 02:10:47 --> Final output sent to browser
DEBUG - 2011-04-14 02:10:47 --> Total execution time: 2.3989
DEBUG - 2011-04-14 02:10:49 --> Config Class Initialized
DEBUG - 2011-04-14 02:10:49 --> Hooks Class Initialized
DEBUG - 2011-04-14 02:10:49 --> Utf8 Class Initialized
DEBUG - 2011-04-14 02:10:49 --> UTF-8 Support Enabled
DEBUG - 2011-04-14 02:10:49 --> URI Class Initialized
DEBUG - 2011-04-14 02:10:49 --> Router Class Initialized
DEBUG - 2011-04-14 02:10:49 --> Output Class Initialized
DEBUG - 2011-04-14 02:10:49 --> Input Class Initialized
DEBUG - 2011-04-14 02:10:49 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-14 02:10:49 --> Language Class Initialized
DEBUG - 2011-04-14 02:10:49 --> Loader Class Initialized
DEBUG - 2011-04-14 02:10:49 --> Controller Class Initialized
DEBUG - 2011-04-14 02:10:49 --> Model Class Initialized
DEBUG - 2011-04-14 02:10:49 --> Model Class Initialized
DEBUG - 2011-04-14 02:10:49 --> Model Class Initialized
DEBUG - 2011-04-14 02:10:49 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-14 02:10:49 --> Database Driver Class Initialized
DEBUG - 2011-04-14 02:10:49 --> File loaded: application/views/table/main.php
DEBUG - 2011-04-14 02:10:49 --> Helper loaded: url_helper
DEBUG - 2011-04-14 02:10:49 --> File loaded: application/views/common/header.php
DEBUG - 2011-04-14 02:10:49 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-04-14 02:10:49 --> File loaded: application/views/common/footer.php
DEBUG - 2011-04-14 02:10:49 --> File loaded: application/views/layout/main.php
DEBUG - 2011-04-14 02:10:49 --> Final output sent to browser
DEBUG - 2011-04-14 02:10:49 --> Total execution time: 0.0489
DEBUG - 2011-04-14 02:10:49 --> Config Class Initialized
DEBUG - 2011-04-14 02:10:49 --> Hooks Class Initialized
DEBUG - 2011-04-14 02:10:49 --> Utf8 Class Initialized
DEBUG - 2011-04-14 02:10:49 --> UTF-8 Support Enabled
DEBUG - 2011-04-14 02:10:49 --> URI Class Initialized
DEBUG - 2011-04-14 02:10:49 --> Router Class Initialized
DEBUG - 2011-04-14 02:10:49 --> Output Class Initialized
DEBUG - 2011-04-14 02:10:49 --> Input Class Initialized
DEBUG - 2011-04-14 02:10:49 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-14 02:10:49 --> Language Class Initialized
DEBUG - 2011-04-14 02:10:49 --> Loader Class Initialized
DEBUG - 2011-04-14 02:10:49 --> Controller Class Initialized
DEBUG - 2011-04-14 02:10:49 --> Model Class Initialized
DEBUG - 2011-04-14 02:10:49 --> Model Class Initialized
DEBUG - 2011-04-14 02:10:49 --> Model Class Initialized
DEBUG - 2011-04-14 02:10:49 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-14 02:10:49 --> Database Driver Class Initialized
DEBUG - 2011-04-14 02:10:49 --> File loaded: application/views/table/main.php
DEBUG - 2011-04-14 02:10:49 --> Helper loaded: url_helper
DEBUG - 2011-04-14 02:10:49 --> File loaded: application/views/common/header.php
DEBUG - 2011-04-14 02:10:49 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-04-14 02:10:49 --> File loaded: application/views/common/footer.php
DEBUG - 2011-04-14 02:10:49 --> File loaded: application/views/layout/main.php
DEBUG - 2011-04-14 02:10:49 --> Final output sent to browser
DEBUG - 2011-04-14 02:10:49 --> Total execution time: 0.0507
DEBUG - 2011-04-14 02:10:50 --> Config Class Initialized
DEBUG - 2011-04-14 02:10:50 --> Hooks Class Initialized
DEBUG - 2011-04-14 02:10:50 --> Utf8 Class Initialized
DEBUG - 2011-04-14 02:10:50 --> UTF-8 Support Enabled
DEBUG - 2011-04-14 02:10:50 --> URI Class Initialized
DEBUG - 2011-04-14 02:10:50 --> Router Class Initialized
ERROR - 2011-04-14 02:10:50 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-04-14 02:11:20 --> Config Class Initialized
DEBUG - 2011-04-14 02:11:20 --> Hooks Class Initialized
DEBUG - 2011-04-14 02:11:20 --> Utf8 Class Initialized
DEBUG - 2011-04-14 02:11:20 --> UTF-8 Support Enabled
DEBUG - 2011-04-14 02:11:20 --> URI Class Initialized
DEBUG - 2011-04-14 02:11:20 --> Router Class Initialized
DEBUG - 2011-04-14 02:11:20 --> Output Class Initialized
DEBUG - 2011-04-14 02:11:20 --> Input Class Initialized
DEBUG - 2011-04-14 02:11:20 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-14 02:11:20 --> Language Class Initialized
DEBUG - 2011-04-14 02:11:20 --> Loader Class Initialized
DEBUG - 2011-04-14 02:11:20 --> Controller Class Initialized
DEBUG - 2011-04-14 02:11:20 --> Model Class Initialized
DEBUG - 2011-04-14 02:11:20 --> Model Class Initialized
DEBUG - 2011-04-14 02:11:20 --> Model Class Initialized
DEBUG - 2011-04-14 02:11:20 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-14 02:11:20 --> Database Driver Class Initialized
DEBUG - 2011-04-14 02:11:21 --> File loaded: application/views/table/main.php
DEBUG - 2011-04-14 02:11:21 --> Helper loaded: url_helper
DEBUG - 2011-04-14 02:11:21 --> File loaded: application/views/common/header.php
DEBUG - 2011-04-14 02:11:21 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-04-14 02:11:21 --> File loaded: application/views/common/footer.php
DEBUG - 2011-04-14 02:11:21 --> File loaded: application/views/layout/main.php
DEBUG - 2011-04-14 02:11:21 --> Final output sent to browser
DEBUG - 2011-04-14 02:11:21 --> Total execution time: 1.1975
DEBUG - 2011-04-14 02:11:24 --> Config Class Initialized
DEBUG - 2011-04-14 02:11:24 --> Hooks Class Initialized
DEBUG - 2011-04-14 02:11:24 --> Utf8 Class Initialized
DEBUG - 2011-04-14 02:11:24 --> UTF-8 Support Enabled
DEBUG - 2011-04-14 02:11:24 --> URI Class Initialized
DEBUG - 2011-04-14 02:11:24 --> Router Class Initialized
ERROR - 2011-04-14 02:11:24 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-04-14 02:11:25 --> Config Class Initialized
DEBUG - 2011-04-14 02:11:25 --> Hooks Class Initialized
DEBUG - 2011-04-14 02:11:25 --> Utf8 Class Initialized
DEBUG - 2011-04-14 02:11:25 --> UTF-8 Support Enabled
DEBUG - 2011-04-14 02:11:25 --> URI Class Initialized
DEBUG - 2011-04-14 02:11:25 --> Router Class Initialized
DEBUG - 2011-04-14 02:11:25 --> Output Class Initialized
DEBUG - 2011-04-14 02:11:25 --> Input Class Initialized
DEBUG - 2011-04-14 02:11:25 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-14 02:11:25 --> Language Class Initialized
DEBUG - 2011-04-14 02:11:25 --> Loader Class Initialized
DEBUG - 2011-04-14 02:11:25 --> Controller Class Initialized
DEBUG - 2011-04-14 02:11:25 --> Model Class Initialized
DEBUG - 2011-04-14 02:11:25 --> Model Class Initialized
DEBUG - 2011-04-14 02:11:25 --> Model Class Initialized
DEBUG - 2011-04-14 02:11:25 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-14 02:11:25 --> Database Driver Class Initialized
DEBUG - 2011-04-14 02:11:25 --> File loaded: application/views/table/main.php
DEBUG - 2011-04-14 02:11:25 --> Helper loaded: url_helper
DEBUG - 2011-04-14 02:11:25 --> File loaded: application/views/common/header.php
DEBUG - 2011-04-14 02:11:25 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-04-14 02:11:25 --> File loaded: application/views/common/footer.php
DEBUG - 2011-04-14 02:11:25 --> File loaded: application/views/layout/main.php
DEBUG - 2011-04-14 02:11:25 --> Final output sent to browser
DEBUG - 2011-04-14 02:11:25 --> Total execution time: 0.0546
DEBUG - 2011-04-14 02:11:41 --> Config Class Initialized
DEBUG - 2011-04-14 02:11:41 --> Hooks Class Initialized
DEBUG - 2011-04-14 02:11:41 --> Utf8 Class Initialized
DEBUG - 2011-04-14 02:11:41 --> UTF-8 Support Enabled
DEBUG - 2011-04-14 02:11:41 --> URI Class Initialized
DEBUG - 2011-04-14 02:11:41 --> Router Class Initialized
DEBUG - 2011-04-14 02:11:41 --> Output Class Initialized
DEBUG - 2011-04-14 02:11:41 --> Input Class Initialized
DEBUG - 2011-04-14 02:11:41 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-14 02:11:41 --> Language Class Initialized
DEBUG - 2011-04-14 02:11:41 --> Loader Class Initialized
DEBUG - 2011-04-14 02:11:41 --> Controller Class Initialized
DEBUG - 2011-04-14 02:11:41 --> Model Class Initialized
DEBUG - 2011-04-14 02:11:41 --> Model Class Initialized
DEBUG - 2011-04-14 02:11:41 --> Model Class Initialized
DEBUG - 2011-04-14 02:11:41 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-14 02:11:41 --> Database Driver Class Initialized
DEBUG - 2011-04-14 02:11:41 --> File loaded: application/views/table/main.php
DEBUG - 2011-04-14 02:11:41 --> Helper loaded: url_helper
DEBUG - 2011-04-14 02:11:41 --> File loaded: application/views/common/header.php
DEBUG - 2011-04-14 02:11:41 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-04-14 02:11:41 --> File loaded: application/views/common/footer.php
DEBUG - 2011-04-14 02:11:41 --> File loaded: application/views/layout/main.php
DEBUG - 2011-04-14 02:11:42 --> Final output sent to browser
DEBUG - 2011-04-14 02:11:42 --> Total execution time: 0.0811
DEBUG - 2011-04-14 02:11:44 --> Config Class Initialized
DEBUG - 2011-04-14 02:11:44 --> Hooks Class Initialized
DEBUG - 2011-04-14 02:11:44 --> Utf8 Class Initialized
DEBUG - 2011-04-14 02:11:44 --> UTF-8 Support Enabled
DEBUG - 2011-04-14 02:11:44 --> URI Class Initialized
DEBUG - 2011-04-14 02:11:44 --> Router Class Initialized
ERROR - 2011-04-14 02:11:44 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-04-14 02:11:56 --> Config Class Initialized
DEBUG - 2011-04-14 02:11:56 --> Hooks Class Initialized
DEBUG - 2011-04-14 02:11:56 --> Utf8 Class Initialized
DEBUG - 2011-04-14 02:11:56 --> UTF-8 Support Enabled
DEBUG - 2011-04-14 02:11:56 --> URI Class Initialized
DEBUG - 2011-04-14 02:11:56 --> Router Class Initialized
DEBUG - 2011-04-14 02:11:56 --> Output Class Initialized
DEBUG - 2011-04-14 02:11:56 --> Input Class Initialized
DEBUG - 2011-04-14 02:11:56 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-14 02:11:56 --> Language Class Initialized
DEBUG - 2011-04-14 02:11:56 --> Loader Class Initialized
DEBUG - 2011-04-14 02:11:56 --> Controller Class Initialized
DEBUG - 2011-04-14 02:11:56 --> Model Class Initialized
DEBUG - 2011-04-14 02:11:56 --> Model Class Initialized
DEBUG - 2011-04-14 02:11:56 --> Model Class Initialized
DEBUG - 2011-04-14 02:11:56 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-14 02:11:56 --> Database Driver Class Initialized
DEBUG - 2011-04-14 02:12:00 --> File loaded: application/views/table/main.php
DEBUG - 2011-04-14 02:12:00 --> Helper loaded: url_helper
DEBUG - 2011-04-14 02:12:00 --> File loaded: application/views/common/header.php
DEBUG - 2011-04-14 02:12:00 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-04-14 02:12:00 --> File loaded: application/views/common/footer.php
DEBUG - 2011-04-14 02:12:00 --> File loaded: application/views/layout/main.php
DEBUG - 2011-04-14 02:12:00 --> Final output sent to browser
DEBUG - 2011-04-14 02:12:00 --> Total execution time: 4.1355
DEBUG - 2011-04-14 02:12:03 --> Config Class Initialized
DEBUG - 2011-04-14 02:12:03 --> Hooks Class Initialized
DEBUG - 2011-04-14 02:12:03 --> Utf8 Class Initialized
DEBUG - 2011-04-14 02:12:03 --> UTF-8 Support Enabled
DEBUG - 2011-04-14 02:12:03 --> URI Class Initialized
DEBUG - 2011-04-14 02:12:03 --> Router Class Initialized
DEBUG - 2011-04-14 02:12:03 --> Output Class Initialized
DEBUG - 2011-04-14 02:12:03 --> Input Class Initialized
DEBUG - 2011-04-14 02:12:03 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-14 02:12:03 --> Language Class Initialized
DEBUG - 2011-04-14 02:12:03 --> Loader Class Initialized
DEBUG - 2011-04-14 02:12:03 --> Controller Class Initialized
DEBUG - 2011-04-14 02:12:03 --> Model Class Initialized
DEBUG - 2011-04-14 02:12:03 --> Model Class Initialized
DEBUG - 2011-04-14 02:12:03 --> Model Class Initialized
DEBUG - 2011-04-14 02:12:03 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-14 02:12:03 --> Database Driver Class Initialized
DEBUG - 2011-04-14 02:12:03 --> File loaded: application/views/table/main.php
DEBUG - 2011-04-14 02:12:03 --> Helper loaded: url_helper
DEBUG - 2011-04-14 02:12:03 --> File loaded: application/views/common/header.php
DEBUG - 2011-04-14 02:12:03 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-04-14 02:12:03 --> File loaded: application/views/common/footer.php
DEBUG - 2011-04-14 02:12:03 --> File loaded: application/views/layout/main.php
DEBUG - 2011-04-14 02:12:03 --> Final output sent to browser
DEBUG - 2011-04-14 02:12:03 --> Total execution time: 0.0844
DEBUG - 2011-04-14 02:12:03 --> Config Class Initialized
DEBUG - 2011-04-14 02:12:03 --> Hooks Class Initialized
DEBUG - 2011-04-14 02:12:03 --> Utf8 Class Initialized
DEBUG - 2011-04-14 02:12:03 --> UTF-8 Support Enabled
DEBUG - 2011-04-14 02:12:03 --> URI Class Initialized
DEBUG - 2011-04-14 02:12:03 --> Router Class Initialized
DEBUG - 2011-04-14 02:12:03 --> Output Class Initialized
DEBUG - 2011-04-14 02:12:03 --> Input Class Initialized
DEBUG - 2011-04-14 02:12:03 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-14 02:12:03 --> Language Class Initialized
DEBUG - 2011-04-14 02:12:03 --> Loader Class Initialized
DEBUG - 2011-04-14 02:12:03 --> Controller Class Initialized
DEBUG - 2011-04-14 02:12:03 --> Model Class Initialized
DEBUG - 2011-04-14 02:12:03 --> Model Class Initialized
DEBUG - 2011-04-14 02:12:03 --> Model Class Initialized
DEBUG - 2011-04-14 02:12:03 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-14 02:12:03 --> Database Driver Class Initialized
DEBUG - 2011-04-14 02:12:03 --> File loaded: application/views/table/main.php
DEBUG - 2011-04-14 02:12:03 --> Helper loaded: url_helper
DEBUG - 2011-04-14 02:12:03 --> File loaded: application/views/common/header.php
DEBUG - 2011-04-14 02:12:03 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-04-14 02:12:03 --> File loaded: application/views/common/footer.php
DEBUG - 2011-04-14 02:12:03 --> File loaded: application/views/layout/main.php
DEBUG - 2011-04-14 02:12:03 --> Final output sent to browser
DEBUG - 2011-04-14 02:12:03 --> Total execution time: 0.0558
DEBUG - 2011-04-14 02:12:03 --> Config Class Initialized
DEBUG - 2011-04-14 02:12:03 --> Hooks Class Initialized
DEBUG - 2011-04-14 02:12:03 --> Utf8 Class Initialized
DEBUG - 2011-04-14 02:12:03 --> UTF-8 Support Enabled
DEBUG - 2011-04-14 02:12:03 --> URI Class Initialized
DEBUG - 2011-04-14 02:12:03 --> Router Class Initialized
ERROR - 2011-04-14 02:12:03 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-04-14 02:12:21 --> Config Class Initialized
DEBUG - 2011-04-14 02:12:21 --> Hooks Class Initialized
DEBUG - 2011-04-14 02:12:21 --> Utf8 Class Initialized
DEBUG - 2011-04-14 02:12:21 --> UTF-8 Support Enabled
DEBUG - 2011-04-14 02:12:21 --> URI Class Initialized
DEBUG - 2011-04-14 02:12:21 --> Router Class Initialized
DEBUG - 2011-04-14 02:12:21 --> Output Class Initialized
DEBUG - 2011-04-14 02:12:22 --> Input Class Initialized
DEBUG - 2011-04-14 02:12:22 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-14 02:12:22 --> Language Class Initialized
DEBUG - 2011-04-14 02:12:22 --> Loader Class Initialized
DEBUG - 2011-04-14 02:12:22 --> Controller Class Initialized
DEBUG - 2011-04-14 02:12:22 --> Model Class Initialized
DEBUG - 2011-04-14 02:12:22 --> Model Class Initialized
DEBUG - 2011-04-14 02:12:22 --> Model Class Initialized
DEBUG - 2011-04-14 02:12:22 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-14 02:12:22 --> Database Driver Class Initialized
DEBUG - 2011-04-14 02:12:22 --> File loaded: application/views/table/main.php
DEBUG - 2011-04-14 02:12:22 --> Helper loaded: url_helper
DEBUG - 2011-04-14 02:12:22 --> File loaded: application/views/common/header.php
DEBUG - 2011-04-14 02:12:22 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-04-14 02:12:22 --> File loaded: application/views/common/footer.php
DEBUG - 2011-04-14 02:12:22 --> File loaded: application/views/layout/main.php
DEBUG - 2011-04-14 02:12:22 --> Final output sent to browser
DEBUG - 2011-04-14 02:12:22 --> Total execution time: 0.4942
DEBUG - 2011-04-14 02:12:23 --> Config Class Initialized
DEBUG - 2011-04-14 02:12:23 --> Hooks Class Initialized
DEBUG - 2011-04-14 02:12:23 --> Utf8 Class Initialized
DEBUG - 2011-04-14 02:12:23 --> UTF-8 Support Enabled
DEBUG - 2011-04-14 02:12:23 --> URI Class Initialized
DEBUG - 2011-04-14 02:12:23 --> Router Class Initialized
DEBUG - 2011-04-14 02:12:23 --> Output Class Initialized
DEBUG - 2011-04-14 02:12:23 --> Input Class Initialized
DEBUG - 2011-04-14 02:12:23 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-14 02:12:23 --> Language Class Initialized
DEBUG - 2011-04-14 02:12:23 --> Loader Class Initialized
DEBUG - 2011-04-14 02:12:23 --> Controller Class Initialized
DEBUG - 2011-04-14 02:12:23 --> Model Class Initialized
DEBUG - 2011-04-14 02:12:23 --> Model Class Initialized
DEBUG - 2011-04-14 02:12:23 --> Model Class Initialized
DEBUG - 2011-04-14 02:12:23 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-14 02:12:23 --> Database Driver Class Initialized
DEBUG - 2011-04-14 02:12:23 --> File loaded: application/views/table/main.php
DEBUG - 2011-04-14 02:12:23 --> Helper loaded: url_helper
DEBUG - 2011-04-14 02:12:23 --> File loaded: application/views/common/header.php
DEBUG - 2011-04-14 02:12:23 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-04-14 02:12:23 --> File loaded: application/views/common/footer.php
DEBUG - 2011-04-14 02:12:23 --> File loaded: application/views/layout/main.php
DEBUG - 2011-04-14 02:12:23 --> Final output sent to browser
DEBUG - 2011-04-14 02:12:23 --> Total execution time: 0.0863
DEBUG - 2011-04-14 02:12:29 --> Config Class Initialized
DEBUG - 2011-04-14 02:12:29 --> Hooks Class Initialized
DEBUG - 2011-04-14 02:12:29 --> Utf8 Class Initialized
DEBUG - 2011-04-14 02:12:29 --> UTF-8 Support Enabled
DEBUG - 2011-04-14 02:12:29 --> URI Class Initialized
DEBUG - 2011-04-14 02:12:29 --> Router Class Initialized
ERROR - 2011-04-14 02:12:29 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-04-14 02:12:46 --> Config Class Initialized
DEBUG - 2011-04-14 02:12:46 --> Hooks Class Initialized
DEBUG - 2011-04-14 02:12:46 --> Utf8 Class Initialized
DEBUG - 2011-04-14 02:12:46 --> UTF-8 Support Enabled
DEBUG - 2011-04-14 02:12:46 --> URI Class Initialized
DEBUG - 2011-04-14 02:12:46 --> Router Class Initialized
DEBUG - 2011-04-14 02:12:46 --> Output Class Initialized
DEBUG - 2011-04-14 02:12:46 --> Input Class Initialized
DEBUG - 2011-04-14 02:12:46 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-14 02:12:46 --> Language Class Initialized
DEBUG - 2011-04-14 02:12:46 --> Loader Class Initialized
DEBUG - 2011-04-14 02:12:46 --> Controller Class Initialized
DEBUG - 2011-04-14 02:12:46 --> Model Class Initialized
DEBUG - 2011-04-14 02:12:46 --> Model Class Initialized
DEBUG - 2011-04-14 02:12:46 --> Model Class Initialized
DEBUG - 2011-04-14 02:12:46 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-14 02:12:46 --> Database Driver Class Initialized
DEBUG - 2011-04-14 02:12:46 --> File loaded: application/views/table/main.php
DEBUG - 2011-04-14 02:12:46 --> Helper loaded: url_helper
DEBUG - 2011-04-14 02:12:46 --> File loaded: application/views/common/header.php
DEBUG - 2011-04-14 02:12:46 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-04-14 02:12:46 --> File loaded: application/views/common/footer.php
DEBUG - 2011-04-14 02:12:46 --> File loaded: application/views/layout/main.php
DEBUG - 2011-04-14 02:12:46 --> Final output sent to browser
DEBUG - 2011-04-14 02:12:46 --> Total execution time: 0.3041
DEBUG - 2011-04-14 02:12:49 --> Config Class Initialized
DEBUG - 2011-04-14 02:12:49 --> Hooks Class Initialized
DEBUG - 2011-04-14 02:12:49 --> Utf8 Class Initialized
DEBUG - 2011-04-14 02:12:49 --> UTF-8 Support Enabled
DEBUG - 2011-04-14 02:12:49 --> URI Class Initialized
DEBUG - 2011-04-14 02:12:49 --> Router Class Initialized
ERROR - 2011-04-14 02:12:49 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-04-14 02:12:49 --> Config Class Initialized
DEBUG - 2011-04-14 02:12:49 --> Hooks Class Initialized
DEBUG - 2011-04-14 02:12:49 --> Utf8 Class Initialized
DEBUG - 2011-04-14 02:12:49 --> UTF-8 Support Enabled
DEBUG - 2011-04-14 02:12:49 --> URI Class Initialized
DEBUG - 2011-04-14 02:12:49 --> Router Class Initialized
DEBUG - 2011-04-14 02:12:49 --> Output Class Initialized
DEBUG - 2011-04-14 02:12:49 --> Input Class Initialized
DEBUG - 2011-04-14 02:12:49 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-14 02:12:49 --> Language Class Initialized
DEBUG - 2011-04-14 02:12:49 --> Loader Class Initialized
DEBUG - 2011-04-14 02:12:49 --> Controller Class Initialized
DEBUG - 2011-04-14 02:12:49 --> Model Class Initialized
DEBUG - 2011-04-14 02:12:49 --> Model Class Initialized
DEBUG - 2011-04-14 02:12:49 --> Model Class Initialized
DEBUG - 2011-04-14 02:12:49 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-14 02:12:49 --> Database Driver Class Initialized
DEBUG - 2011-04-14 02:12:49 --> File loaded: application/views/table/main.php
DEBUG - 2011-04-14 02:12:49 --> Helper loaded: url_helper
DEBUG - 2011-04-14 02:12:49 --> File loaded: application/views/common/header.php
DEBUG - 2011-04-14 02:12:49 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-04-14 02:12:49 --> File loaded: application/views/common/footer.php
DEBUG - 2011-04-14 02:12:49 --> File loaded: application/views/layout/main.php
DEBUG - 2011-04-14 02:12:49 --> Final output sent to browser
DEBUG - 2011-04-14 02:12:49 --> Total execution time: 0.2010
DEBUG - 2011-04-14 02:13:09 --> Config Class Initialized
DEBUG - 2011-04-14 02:13:09 --> Hooks Class Initialized
DEBUG - 2011-04-14 02:13:09 --> Utf8 Class Initialized
DEBUG - 2011-04-14 02:13:09 --> UTF-8 Support Enabled
DEBUG - 2011-04-14 02:13:09 --> URI Class Initialized
DEBUG - 2011-04-14 02:13:09 --> Router Class Initialized
DEBUG - 2011-04-14 02:13:09 --> Output Class Initialized
DEBUG - 2011-04-14 02:13:09 --> Input Class Initialized
DEBUG - 2011-04-14 02:13:09 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-14 02:13:09 --> Language Class Initialized
DEBUG - 2011-04-14 02:13:09 --> Loader Class Initialized
DEBUG - 2011-04-14 02:13:09 --> Controller Class Initialized
DEBUG - 2011-04-14 02:13:09 --> Model Class Initialized
DEBUG - 2011-04-14 02:13:09 --> Model Class Initialized
DEBUG - 2011-04-14 02:13:09 --> Model Class Initialized
DEBUG - 2011-04-14 02:13:09 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-14 02:13:09 --> Database Driver Class Initialized
DEBUG - 2011-04-14 02:13:09 --> File loaded: application/views/table/main.php
DEBUG - 2011-04-14 02:13:09 --> Helper loaded: url_helper
DEBUG - 2011-04-14 02:13:09 --> File loaded: application/views/common/header.php
DEBUG - 2011-04-14 02:13:09 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-04-14 02:13:09 --> File loaded: application/views/common/footer.php
DEBUG - 2011-04-14 02:13:09 --> File loaded: application/views/layout/main.php
DEBUG - 2011-04-14 02:13:09 --> Final output sent to browser
DEBUG - 2011-04-14 02:13:09 --> Total execution time: 0.5202
DEBUG - 2011-04-14 02:13:11 --> Config Class Initialized
DEBUG - 2011-04-14 02:13:11 --> Hooks Class Initialized
DEBUG - 2011-04-14 02:13:11 --> Utf8 Class Initialized
DEBUG - 2011-04-14 02:13:11 --> UTF-8 Support Enabled
DEBUG - 2011-04-14 02:13:11 --> URI Class Initialized
DEBUG - 2011-04-14 02:13:11 --> Router Class Initialized
DEBUG - 2011-04-14 02:13:11 --> Output Class Initialized
DEBUG - 2011-04-14 02:13:11 --> Input Class Initialized
DEBUG - 2011-04-14 02:13:11 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-14 02:13:11 --> Language Class Initialized
DEBUG - 2011-04-14 02:13:11 --> Loader Class Initialized
DEBUG - 2011-04-14 02:13:11 --> Controller Class Initialized
DEBUG - 2011-04-14 02:13:12 --> Model Class Initialized
DEBUG - 2011-04-14 02:13:12 --> Model Class Initialized
DEBUG - 2011-04-14 02:13:12 --> Model Class Initialized
DEBUG - 2011-04-14 02:13:12 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-14 02:13:12 --> Database Driver Class Initialized
DEBUG - 2011-04-14 02:13:12 --> File loaded: application/views/table/main.php
DEBUG - 2011-04-14 02:13:12 --> Helper loaded: url_helper
DEBUG - 2011-04-14 02:13:12 --> File loaded: application/views/common/header.php
DEBUG - 2011-04-14 02:13:12 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-04-14 02:13:12 --> File loaded: application/views/common/footer.php
DEBUG - 2011-04-14 02:13:12 --> File loaded: application/views/layout/main.php
DEBUG - 2011-04-14 02:13:12 --> Final output sent to browser
DEBUG - 2011-04-14 02:13:12 --> Total execution time: 0.0579
DEBUG - 2011-04-14 02:13:12 --> Config Class Initialized
DEBUG - 2011-04-14 02:13:12 --> Hooks Class Initialized
DEBUG - 2011-04-14 02:13:12 --> Utf8 Class Initialized
DEBUG - 2011-04-14 02:13:12 --> UTF-8 Support Enabled
DEBUG - 2011-04-14 02:13:12 --> URI Class Initialized
DEBUG - 2011-04-14 02:13:12 --> Router Class Initialized
ERROR - 2011-04-14 02:13:12 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-04-14 02:13:41 --> Config Class Initialized
DEBUG - 2011-04-14 02:13:41 --> Hooks Class Initialized
DEBUG - 2011-04-14 02:13:41 --> Utf8 Class Initialized
DEBUG - 2011-04-14 02:13:41 --> UTF-8 Support Enabled
DEBUG - 2011-04-14 02:13:41 --> URI Class Initialized
DEBUG - 2011-04-14 02:13:41 --> Router Class Initialized
DEBUG - 2011-04-14 02:13:41 --> Output Class Initialized
DEBUG - 2011-04-14 02:13:41 --> Input Class Initialized
DEBUG - 2011-04-14 02:13:41 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-14 02:13:41 --> Language Class Initialized
DEBUG - 2011-04-14 02:13:41 --> Loader Class Initialized
DEBUG - 2011-04-14 02:13:41 --> Controller Class Initialized
DEBUG - 2011-04-14 02:13:41 --> Model Class Initialized
DEBUG - 2011-04-14 02:13:41 --> Model Class Initialized
DEBUG - 2011-04-14 02:13:41 --> Model Class Initialized
DEBUG - 2011-04-14 02:13:41 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-14 02:13:42 --> Database Driver Class Initialized
DEBUG - 2011-04-14 02:13:47 --> File loaded: application/views/table/main.php
DEBUG - 2011-04-14 02:13:47 --> Helper loaded: url_helper
DEBUG - 2011-04-14 02:13:47 --> File loaded: application/views/common/header.php
DEBUG - 2011-04-14 02:13:47 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-04-14 02:13:47 --> File loaded: application/views/common/footer.php
DEBUG - 2011-04-14 02:13:47 --> File loaded: application/views/layout/main.php
DEBUG - 2011-04-14 02:13:47 --> Final output sent to browser
DEBUG - 2011-04-14 02:13:47 --> Total execution time: 7.3728
DEBUG - 2011-04-14 02:13:48 --> Config Class Initialized
DEBUG - 2011-04-14 02:13:48 --> Hooks Class Initialized
DEBUG - 2011-04-14 02:13:48 --> Utf8 Class Initialized
DEBUG - 2011-04-14 02:13:48 --> UTF-8 Support Enabled
DEBUG - 2011-04-14 02:13:48 --> URI Class Initialized
DEBUG - 2011-04-14 02:13:48 --> Router Class Initialized
DEBUG - 2011-04-14 02:13:48 --> Output Class Initialized
DEBUG - 2011-04-14 02:13:48 --> Input Class Initialized
DEBUG - 2011-04-14 02:13:48 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-14 02:13:48 --> Language Class Initialized
DEBUG - 2011-04-14 02:13:48 --> Loader Class Initialized
DEBUG - 2011-04-14 02:13:48 --> Controller Class Initialized
DEBUG - 2011-04-14 02:13:48 --> Model Class Initialized
DEBUG - 2011-04-14 02:13:48 --> Model Class Initialized
DEBUG - 2011-04-14 02:13:48 --> Model Class Initialized
DEBUG - 2011-04-14 02:13:48 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-14 02:13:48 --> Database Driver Class Initialized
DEBUG - 2011-04-14 02:13:48 --> File loaded: application/views/table/main.php
DEBUG - 2011-04-14 02:13:48 --> Helper loaded: url_helper
DEBUG - 2011-04-14 02:13:48 --> File loaded: application/views/common/header.php
DEBUG - 2011-04-14 02:13:48 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-04-14 02:13:48 --> File loaded: application/views/common/footer.php
DEBUG - 2011-04-14 02:13:48 --> File loaded: application/views/layout/main.php
DEBUG - 2011-04-14 02:13:48 --> Final output sent to browser
DEBUG - 2011-04-14 02:13:48 --> Total execution time: 0.0597
DEBUG - 2011-04-14 02:13:48 --> Config Class Initialized
DEBUG - 2011-04-14 02:13:48 --> Hooks Class Initialized
DEBUG - 2011-04-14 02:13:48 --> Utf8 Class Initialized
DEBUG - 2011-04-14 02:13:48 --> UTF-8 Support Enabled
DEBUG - 2011-04-14 02:13:48 --> URI Class Initialized
DEBUG - 2011-04-14 02:13:48 --> Router Class Initialized
DEBUG - 2011-04-14 02:13:48 --> Output Class Initialized
DEBUG - 2011-04-14 02:13:48 --> Input Class Initialized
DEBUG - 2011-04-14 02:13:48 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-14 02:13:48 --> Language Class Initialized
DEBUG - 2011-04-14 02:13:48 --> Loader Class Initialized
DEBUG - 2011-04-14 02:13:48 --> Controller Class Initialized
DEBUG - 2011-04-14 02:13:48 --> Model Class Initialized
DEBUG - 2011-04-14 02:13:48 --> Model Class Initialized
DEBUG - 2011-04-14 02:13:48 --> Model Class Initialized
DEBUG - 2011-04-14 02:13:48 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-14 02:13:48 --> Database Driver Class Initialized
DEBUG - 2011-04-14 02:13:49 --> File loaded: application/views/table/main.php
DEBUG - 2011-04-14 02:13:49 --> Helper loaded: url_helper
DEBUG - 2011-04-14 02:13:49 --> File loaded: application/views/common/header.php
DEBUG - 2011-04-14 02:13:49 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-04-14 02:13:49 --> File loaded: application/views/common/footer.php
DEBUG - 2011-04-14 02:13:49 --> File loaded: application/views/layout/main.php
DEBUG - 2011-04-14 02:13:49 --> Final output sent to browser
DEBUG - 2011-04-14 02:13:49 --> Total execution time: 0.0958
DEBUG - 2011-04-14 02:13:50 --> Config Class Initialized
DEBUG - 2011-04-14 02:13:50 --> Hooks Class Initialized
DEBUG - 2011-04-14 02:13:50 --> Utf8 Class Initialized
DEBUG - 2011-04-14 02:13:50 --> UTF-8 Support Enabled
DEBUG - 2011-04-14 02:13:50 --> URI Class Initialized
DEBUG - 2011-04-14 02:13:50 --> Router Class Initialized
ERROR - 2011-04-14 02:13:50 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-04-14 02:14:05 --> Config Class Initialized
DEBUG - 2011-04-14 02:14:05 --> Hooks Class Initialized
DEBUG - 2011-04-14 02:14:05 --> Utf8 Class Initialized
DEBUG - 2011-04-14 02:14:05 --> UTF-8 Support Enabled
DEBUG - 2011-04-14 02:14:05 --> URI Class Initialized
DEBUG - 2011-04-14 02:14:05 --> Router Class Initialized
DEBUG - 2011-04-14 02:14:05 --> Output Class Initialized
DEBUG - 2011-04-14 02:14:05 --> Input Class Initialized
DEBUG - 2011-04-14 02:14:05 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-14 02:14:05 --> Language Class Initialized
DEBUG - 2011-04-14 02:14:05 --> Loader Class Initialized
DEBUG - 2011-04-14 02:14:05 --> Controller Class Initialized
DEBUG - 2011-04-14 02:14:05 --> Model Class Initialized
DEBUG - 2011-04-14 02:14:05 --> Model Class Initialized
DEBUG - 2011-04-14 02:14:05 --> Model Class Initialized
DEBUG - 2011-04-14 02:14:05 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-14 02:14:05 --> Database Driver Class Initialized
DEBUG - 2011-04-14 02:14:06 --> File loaded: application/views/table/main.php
DEBUG - 2011-04-14 02:14:06 --> Helper loaded: url_helper
DEBUG - 2011-04-14 02:14:06 --> File loaded: application/views/common/header.php
DEBUG - 2011-04-14 02:14:06 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-04-14 02:14:06 --> File loaded: application/views/common/footer.php
DEBUG - 2011-04-14 02:14:06 --> File loaded: application/views/layout/main.php
DEBUG - 2011-04-14 02:14:06 --> Final output sent to browser
DEBUG - 2011-04-14 02:14:06 --> Total execution time: 0.5470
DEBUG - 2011-04-14 02:14:10 --> Config Class Initialized
DEBUG - 2011-04-14 02:14:10 --> Hooks Class Initialized
DEBUG - 2011-04-14 02:14:10 --> Utf8 Class Initialized
DEBUG - 2011-04-14 02:14:10 --> UTF-8 Support Enabled
DEBUG - 2011-04-14 02:14:10 --> URI Class Initialized
DEBUG - 2011-04-14 02:14:10 --> Router Class Initialized
DEBUG - 2011-04-14 02:14:10 --> Output Class Initialized
DEBUG - 2011-04-14 02:14:10 --> Input Class Initialized
DEBUG - 2011-04-14 02:14:10 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-14 02:14:10 --> Language Class Initialized
DEBUG - 2011-04-14 02:14:10 --> Loader Class Initialized
DEBUG - 2011-04-14 02:14:10 --> Controller Class Initialized
DEBUG - 2011-04-14 02:14:10 --> Model Class Initialized
DEBUG - 2011-04-14 02:14:10 --> Model Class Initialized
DEBUG - 2011-04-14 02:14:10 --> Model Class Initialized
DEBUG - 2011-04-14 02:14:10 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-14 02:14:10 --> Database Driver Class Initialized
DEBUG - 2011-04-14 02:14:10 --> File loaded: application/views/table/main.php
DEBUG - 2011-04-14 02:14:10 --> Helper loaded: url_helper
DEBUG - 2011-04-14 02:14:10 --> File loaded: application/views/common/header.php
DEBUG - 2011-04-14 02:14:10 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-04-14 02:14:10 --> File loaded: application/views/common/footer.php
DEBUG - 2011-04-14 02:14:10 --> File loaded: application/views/layout/main.php
DEBUG - 2011-04-14 02:14:10 --> Final output sent to browser
DEBUG - 2011-04-14 02:14:10 --> Total execution time: 0.0538
DEBUG - 2011-04-14 02:14:12 --> Config Class Initialized
DEBUG - 2011-04-14 02:14:12 --> Hooks Class Initialized
DEBUG - 2011-04-14 02:14:12 --> Utf8 Class Initialized
DEBUG - 2011-04-14 02:14:12 --> UTF-8 Support Enabled
DEBUG - 2011-04-14 02:14:12 --> URI Class Initialized
DEBUG - 2011-04-14 02:14:12 --> Router Class Initialized
ERROR - 2011-04-14 02:14:12 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-04-14 02:14:20 --> Config Class Initialized
DEBUG - 2011-04-14 02:14:20 --> Hooks Class Initialized
DEBUG - 2011-04-14 02:14:20 --> Utf8 Class Initialized
DEBUG - 2011-04-14 02:14:20 --> UTF-8 Support Enabled
DEBUG - 2011-04-14 02:14:20 --> URI Class Initialized
DEBUG - 2011-04-14 02:14:20 --> Router Class Initialized
DEBUG - 2011-04-14 02:14:20 --> Output Class Initialized
DEBUG - 2011-04-14 02:14:20 --> Input Class Initialized
DEBUG - 2011-04-14 02:14:20 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-14 02:14:20 --> Language Class Initialized
DEBUG - 2011-04-14 02:14:20 --> Loader Class Initialized
DEBUG - 2011-04-14 02:14:20 --> Controller Class Initialized
DEBUG - 2011-04-14 02:14:20 --> Model Class Initialized
DEBUG - 2011-04-14 02:14:20 --> Model Class Initialized
DEBUG - 2011-04-14 02:14:20 --> Model Class Initialized
DEBUG - 2011-04-14 02:14:20 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-14 02:14:20 --> Database Driver Class Initialized
DEBUG - 2011-04-14 02:14:28 --> File loaded: application/views/table/main.php
DEBUG - 2011-04-14 02:14:28 --> Helper loaded: url_helper
DEBUG - 2011-04-14 02:14:28 --> File loaded: application/views/common/header.php
DEBUG - 2011-04-14 02:14:28 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-04-14 02:14:28 --> File loaded: application/views/common/footer.php
DEBUG - 2011-04-14 02:14:28 --> File loaded: application/views/layout/main.php
DEBUG - 2011-04-14 02:14:28 --> Final output sent to browser
DEBUG - 2011-04-14 02:14:28 --> Total execution time: 7.9246
DEBUG - 2011-04-14 02:14:31 --> Config Class Initialized
DEBUG - 2011-04-14 02:14:31 --> Hooks Class Initialized
DEBUG - 2011-04-14 02:14:31 --> Utf8 Class Initialized
DEBUG - 2011-04-14 02:14:31 --> UTF-8 Support Enabled
DEBUG - 2011-04-14 02:14:31 --> URI Class Initialized
DEBUG - 2011-04-14 02:14:31 --> Router Class Initialized
ERROR - 2011-04-14 02:14:31 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-04-14 02:14:32 --> Config Class Initialized
DEBUG - 2011-04-14 02:14:32 --> Hooks Class Initialized
DEBUG - 2011-04-14 02:14:32 --> Utf8 Class Initialized
DEBUG - 2011-04-14 02:14:32 --> UTF-8 Support Enabled
DEBUG - 2011-04-14 02:14:32 --> URI Class Initialized
DEBUG - 2011-04-14 02:14:32 --> Router Class Initialized
DEBUG - 2011-04-14 02:14:32 --> Output Class Initialized
DEBUG - 2011-04-14 02:14:32 --> Input Class Initialized
DEBUG - 2011-04-14 02:14:32 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-14 02:14:32 --> Language Class Initialized
DEBUG - 2011-04-14 02:14:32 --> Loader Class Initialized
DEBUG - 2011-04-14 02:14:32 --> Controller Class Initialized
DEBUG - 2011-04-14 02:14:32 --> Model Class Initialized
DEBUG - 2011-04-14 02:14:32 --> Model Class Initialized
DEBUG - 2011-04-14 02:14:32 --> Model Class Initialized
DEBUG - 2011-04-14 02:14:32 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-14 02:14:32 --> Database Driver Class Initialized
DEBUG - 2011-04-14 02:14:32 --> File loaded: application/views/table/main.php
DEBUG - 2011-04-14 02:14:32 --> Helper loaded: url_helper
DEBUG - 2011-04-14 02:14:32 --> File loaded: application/views/common/header.php
DEBUG - 2011-04-14 02:14:32 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-04-14 02:14:32 --> File loaded: application/views/common/footer.php
DEBUG - 2011-04-14 02:14:32 --> File loaded: application/views/layout/main.php
DEBUG - 2011-04-14 02:14:32 --> Final output sent to browser
DEBUG - 2011-04-14 02:14:32 --> Total execution time: 0.0522
DEBUG - 2011-04-14 02:14:45 --> Config Class Initialized
DEBUG - 2011-04-14 02:14:45 --> Hooks Class Initialized
DEBUG - 2011-04-14 02:14:45 --> Utf8 Class Initialized
DEBUG - 2011-04-14 02:14:45 --> UTF-8 Support Enabled
DEBUG - 2011-04-14 02:14:45 --> URI Class Initialized
DEBUG - 2011-04-14 02:14:45 --> Router Class Initialized
DEBUG - 2011-04-14 02:14:45 --> Output Class Initialized
DEBUG - 2011-04-14 02:14:45 --> Input Class Initialized
DEBUG - 2011-04-14 02:14:45 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-14 02:14:45 --> Language Class Initialized
DEBUG - 2011-04-14 02:14:45 --> Loader Class Initialized
DEBUG - 2011-04-14 02:14:45 --> Controller Class Initialized
DEBUG - 2011-04-14 02:14:45 --> Model Class Initialized
DEBUG - 2011-04-14 02:14:45 --> Model Class Initialized
DEBUG - 2011-04-14 02:14:45 --> Model Class Initialized
DEBUG - 2011-04-14 02:14:45 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-14 02:14:45 --> Database Driver Class Initialized
DEBUG - 2011-04-14 02:14:47 --> File loaded: application/views/table/main.php
DEBUG - 2011-04-14 02:14:47 --> Helper loaded: url_helper
DEBUG - 2011-04-14 02:14:47 --> File loaded: application/views/common/header.php
DEBUG - 2011-04-14 02:14:47 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-04-14 02:14:47 --> File loaded: application/views/common/footer.php
DEBUG - 2011-04-14 02:14:47 --> File loaded: application/views/layout/main.php
DEBUG - 2011-04-14 02:14:47 --> Final output sent to browser
DEBUG - 2011-04-14 02:14:47 --> Total execution time: 1.5350
DEBUG - 2011-04-14 02:14:48 --> Config Class Initialized
DEBUG - 2011-04-14 02:14:48 --> Hooks Class Initialized
DEBUG - 2011-04-14 02:14:48 --> Utf8 Class Initialized
DEBUG - 2011-04-14 02:14:48 --> UTF-8 Support Enabled
DEBUG - 2011-04-14 02:14:48 --> URI Class Initialized
DEBUG - 2011-04-14 02:14:48 --> Router Class Initialized
DEBUG - 2011-04-14 02:14:48 --> Output Class Initialized
DEBUG - 2011-04-14 02:14:48 --> Input Class Initialized
DEBUG - 2011-04-14 02:14:48 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-14 02:14:48 --> Language Class Initialized
DEBUG - 2011-04-14 02:14:48 --> Loader Class Initialized
DEBUG - 2011-04-14 02:14:48 --> Controller Class Initialized
DEBUG - 2011-04-14 02:14:48 --> Model Class Initialized
DEBUG - 2011-04-14 02:14:48 --> Model Class Initialized
DEBUG - 2011-04-14 02:14:48 --> Model Class Initialized
DEBUG - 2011-04-14 02:14:48 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-14 02:14:48 --> Database Driver Class Initialized
DEBUG - 2011-04-14 02:14:48 --> File loaded: application/views/table/main.php
DEBUG - 2011-04-14 02:14:48 --> Helper loaded: url_helper
DEBUG - 2011-04-14 02:14:48 --> File loaded: application/views/common/header.php
DEBUG - 2011-04-14 02:14:48 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-04-14 02:14:48 --> File loaded: application/views/common/footer.php
DEBUG - 2011-04-14 02:14:48 --> File loaded: application/views/layout/main.php
DEBUG - 2011-04-14 02:14:48 --> Final output sent to browser
DEBUG - 2011-04-14 02:14:48 --> Total execution time: 0.0776
DEBUG - 2011-04-14 02:14:49 --> Config Class Initialized
DEBUG - 2011-04-14 02:14:49 --> Hooks Class Initialized
DEBUG - 2011-04-14 02:14:49 --> Utf8 Class Initialized
DEBUG - 2011-04-14 02:14:49 --> UTF-8 Support Enabled
DEBUG - 2011-04-14 02:14:49 --> URI Class Initialized
DEBUG - 2011-04-14 02:14:49 --> Router Class Initialized
ERROR - 2011-04-14 02:14:49 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-04-14 02:15:05 --> Config Class Initialized
DEBUG - 2011-04-14 02:15:05 --> Hooks Class Initialized
DEBUG - 2011-04-14 02:15:05 --> Utf8 Class Initialized
DEBUG - 2011-04-14 02:15:05 --> UTF-8 Support Enabled
DEBUG - 2011-04-14 02:15:05 --> URI Class Initialized
DEBUG - 2011-04-14 02:15:05 --> Router Class Initialized
DEBUG - 2011-04-14 02:15:05 --> Output Class Initialized
DEBUG - 2011-04-14 02:15:05 --> Input Class Initialized
DEBUG - 2011-04-14 02:15:05 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-14 02:15:05 --> Language Class Initialized
DEBUG - 2011-04-14 02:15:05 --> Loader Class Initialized
DEBUG - 2011-04-14 02:15:05 --> Controller Class Initialized
DEBUG - 2011-04-14 02:15:05 --> Model Class Initialized
DEBUG - 2011-04-14 02:15:05 --> Model Class Initialized
DEBUG - 2011-04-14 02:15:05 --> Model Class Initialized
DEBUG - 2011-04-14 02:15:05 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-14 02:15:05 --> Database Driver Class Initialized
DEBUG - 2011-04-14 02:15:09 --> File loaded: application/views/table/main.php
DEBUG - 2011-04-14 02:15:09 --> Helper loaded: url_helper
DEBUG - 2011-04-14 02:15:09 --> File loaded: application/views/common/header.php
DEBUG - 2011-04-14 02:15:09 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-04-14 02:15:09 --> File loaded: application/views/common/footer.php
DEBUG - 2011-04-14 02:15:09 --> File loaded: application/views/layout/main.php
DEBUG - 2011-04-14 02:15:09 --> Final output sent to browser
DEBUG - 2011-04-14 02:15:09 --> Total execution time: 4.7609
DEBUG - 2011-04-14 02:15:11 --> Config Class Initialized
DEBUG - 2011-04-14 02:15:11 --> Hooks Class Initialized
DEBUG - 2011-04-14 02:15:11 --> Utf8 Class Initialized
DEBUG - 2011-04-14 02:15:11 --> UTF-8 Support Enabled
DEBUG - 2011-04-14 02:15:11 --> URI Class Initialized
DEBUG - 2011-04-14 02:15:11 --> Router Class Initialized
DEBUG - 2011-04-14 02:15:11 --> Output Class Initialized
DEBUG - 2011-04-14 02:15:11 --> Input Class Initialized
DEBUG - 2011-04-14 02:15:11 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-14 02:15:11 --> Language Class Initialized
DEBUG - 2011-04-14 02:15:11 --> Loader Class Initialized
DEBUG - 2011-04-14 02:15:11 --> Controller Class Initialized
DEBUG - 2011-04-14 02:15:11 --> Model Class Initialized
DEBUG - 2011-04-14 02:15:11 --> Model Class Initialized
DEBUG - 2011-04-14 02:15:11 --> Model Class Initialized
DEBUG - 2011-04-14 02:15:11 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-14 02:15:11 --> Database Driver Class Initialized
DEBUG - 2011-04-14 02:15:11 --> File loaded: application/views/table/main.php
DEBUG - 2011-04-14 02:15:11 --> Helper loaded: url_helper
DEBUG - 2011-04-14 02:15:11 --> File loaded: application/views/common/header.php
DEBUG - 2011-04-14 02:15:11 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-04-14 02:15:11 --> File loaded: application/views/common/footer.php
DEBUG - 2011-04-14 02:15:11 --> File loaded: application/views/layout/main.php
DEBUG - 2011-04-14 02:15:11 --> Final output sent to browser
DEBUG - 2011-04-14 02:15:11 --> Total execution time: 0.0448
DEBUG - 2011-04-14 02:15:12 --> Config Class Initialized
DEBUG - 2011-04-14 02:15:12 --> Hooks Class Initialized
DEBUG - 2011-04-14 02:15:12 --> Utf8 Class Initialized
DEBUG - 2011-04-14 02:15:12 --> UTF-8 Support Enabled
DEBUG - 2011-04-14 02:15:12 --> URI Class Initialized
DEBUG - 2011-04-14 02:15:12 --> Router Class Initialized
ERROR - 2011-04-14 02:15:12 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-04-14 02:15:13 --> Config Class Initialized
DEBUG - 2011-04-14 02:15:13 --> Hooks Class Initialized
DEBUG - 2011-04-14 02:15:13 --> Utf8 Class Initialized
DEBUG - 2011-04-14 02:15:13 --> UTF-8 Support Enabled
DEBUG - 2011-04-14 02:15:13 --> URI Class Initialized
DEBUG - 2011-04-14 02:15:13 --> Router Class Initialized
ERROR - 2011-04-14 02:15:13 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-04-14 02:15:26 --> Config Class Initialized
DEBUG - 2011-04-14 02:15:26 --> Hooks Class Initialized
DEBUG - 2011-04-14 02:15:26 --> Utf8 Class Initialized
DEBUG - 2011-04-14 02:15:26 --> UTF-8 Support Enabled
DEBUG - 2011-04-14 02:15:26 --> URI Class Initialized
DEBUG - 2011-04-14 02:15:26 --> Router Class Initialized
DEBUG - 2011-04-14 02:15:26 --> Output Class Initialized
DEBUG - 2011-04-14 02:15:26 --> Input Class Initialized
DEBUG - 2011-04-14 02:15:26 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-14 02:15:26 --> Language Class Initialized
DEBUG - 2011-04-14 02:15:26 --> Loader Class Initialized
DEBUG - 2011-04-14 02:15:26 --> Controller Class Initialized
DEBUG - 2011-04-14 02:15:26 --> Model Class Initialized
DEBUG - 2011-04-14 02:15:26 --> Model Class Initialized
DEBUG - 2011-04-14 02:15:26 --> Model Class Initialized
DEBUG - 2011-04-14 02:15:26 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-14 02:15:26 --> Database Driver Class Initialized
DEBUG - 2011-04-14 02:15:26 --> File loaded: application/views/table/main.php
DEBUG - 2011-04-14 02:15:26 --> Helper loaded: url_helper
DEBUG - 2011-04-14 02:15:26 --> File loaded: application/views/common/header.php
DEBUG - 2011-04-14 02:15:26 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-04-14 02:15:26 --> File loaded: application/views/common/footer.php
DEBUG - 2011-04-14 02:15:26 --> File loaded: application/views/layout/main.php
DEBUG - 2011-04-14 02:15:26 --> Final output sent to browser
DEBUG - 2011-04-14 02:15:26 --> Total execution time: 0.2517
DEBUG - 2011-04-14 02:15:29 --> Config Class Initialized
DEBUG - 2011-04-14 02:15:29 --> Hooks Class Initialized
DEBUG - 2011-04-14 02:15:29 --> Utf8 Class Initialized
DEBUG - 2011-04-14 02:15:29 --> UTF-8 Support Enabled
DEBUG - 2011-04-14 02:15:29 --> URI Class Initialized
DEBUG - 2011-04-14 02:15:29 --> Router Class Initialized
DEBUG - 2011-04-14 02:15:29 --> Output Class Initialized
DEBUG - 2011-04-14 02:15:29 --> Input Class Initialized
DEBUG - 2011-04-14 02:15:29 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-14 02:15:29 --> Language Class Initialized
DEBUG - 2011-04-14 02:15:29 --> Loader Class Initialized
DEBUG - 2011-04-14 02:15:29 --> Controller Class Initialized
DEBUG - 2011-04-14 02:15:29 --> Model Class Initialized
DEBUG - 2011-04-14 02:15:29 --> Model Class Initialized
DEBUG - 2011-04-14 02:15:29 --> Model Class Initialized
DEBUG - 2011-04-14 02:15:29 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-14 02:15:29 --> Database Driver Class Initialized
DEBUG - 2011-04-14 02:15:29 --> Config Class Initialized
DEBUG - 2011-04-14 02:15:29 --> Hooks Class Initialized
DEBUG - 2011-04-14 02:15:29 --> Utf8 Class Initialized
DEBUG - 2011-04-14 02:15:29 --> UTF-8 Support Enabled
DEBUG - 2011-04-14 02:15:29 --> URI Class Initialized
DEBUG - 2011-04-14 02:15:29 --> Router Class Initialized
ERROR - 2011-04-14 02:15:29 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-04-14 02:15:29 --> File loaded: application/views/table/main.php
DEBUG - 2011-04-14 02:15:29 --> Helper loaded: url_helper
DEBUG - 2011-04-14 02:15:29 --> File loaded: application/views/common/header.php
DEBUG - 2011-04-14 02:15:29 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-04-14 02:15:29 --> File loaded: application/views/common/footer.php
DEBUG - 2011-04-14 02:15:29 --> File loaded: application/views/layout/main.php
DEBUG - 2011-04-14 02:15:29 --> Final output sent to browser
DEBUG - 2011-04-14 02:15:29 --> Total execution time: 0.0476
DEBUG - 2011-04-14 02:15:41 --> Config Class Initialized
DEBUG - 2011-04-14 02:15:41 --> Hooks Class Initialized
DEBUG - 2011-04-14 02:15:41 --> Utf8 Class Initialized
DEBUG - 2011-04-14 02:15:41 --> UTF-8 Support Enabled
DEBUG - 2011-04-14 02:15:41 --> URI Class Initialized
DEBUG - 2011-04-14 02:15:41 --> Router Class Initialized
DEBUG - 2011-04-14 02:15:41 --> Output Class Initialized
DEBUG - 2011-04-14 02:15:41 --> Input Class Initialized
DEBUG - 2011-04-14 02:15:41 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-14 02:15:41 --> Language Class Initialized
DEBUG - 2011-04-14 02:15:41 --> Loader Class Initialized
DEBUG - 2011-04-14 02:15:41 --> Controller Class Initialized
DEBUG - 2011-04-14 02:15:41 --> Model Class Initialized
DEBUG - 2011-04-14 02:15:41 --> Model Class Initialized
DEBUG - 2011-04-14 02:15:41 --> Model Class Initialized
DEBUG - 2011-04-14 02:15:41 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-14 02:15:41 --> Database Driver Class Initialized
DEBUG - 2011-04-14 02:15:47 --> File loaded: application/views/table/main.php
DEBUG - 2011-04-14 02:15:47 --> Helper loaded: url_helper
DEBUG - 2011-04-14 02:15:47 --> File loaded: application/views/common/header.php
DEBUG - 2011-04-14 02:15:47 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-04-14 02:15:47 --> File loaded: application/views/common/footer.php
DEBUG - 2011-04-14 02:15:47 --> File loaded: application/views/layout/main.php
DEBUG - 2011-04-14 02:15:47 --> Final output sent to browser
DEBUG - 2011-04-14 02:15:47 --> Total execution time: 6.6374
DEBUG - 2011-04-14 02:15:49 --> Config Class Initialized
DEBUG - 2011-04-14 02:15:49 --> Hooks Class Initialized
DEBUG - 2011-04-14 02:15:49 --> Utf8 Class Initialized
DEBUG - 2011-04-14 02:15:49 --> UTF-8 Support Enabled
DEBUG - 2011-04-14 02:15:49 --> URI Class Initialized
DEBUG - 2011-04-14 02:15:49 --> Router Class Initialized
DEBUG - 2011-04-14 02:15:49 --> Output Class Initialized
DEBUG - 2011-04-14 02:15:49 --> Input Class Initialized
DEBUG - 2011-04-14 02:15:49 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-14 02:15:49 --> Language Class Initialized
DEBUG - 2011-04-14 02:15:49 --> Loader Class Initialized
DEBUG - 2011-04-14 02:15:49 --> Controller Class Initialized
DEBUG - 2011-04-14 02:15:49 --> Model Class Initialized
DEBUG - 2011-04-14 02:15:49 --> Model Class Initialized
DEBUG - 2011-04-14 02:15:49 --> Model Class Initialized
DEBUG - 2011-04-14 02:15:49 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-14 02:15:49 --> Database Driver Class Initialized
DEBUG - 2011-04-14 02:15:49 --> File loaded: application/views/table/main.php
DEBUG - 2011-04-14 02:15:49 --> Helper loaded: url_helper
DEBUG - 2011-04-14 02:15:49 --> File loaded: application/views/common/header.php
DEBUG - 2011-04-14 02:15:49 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-04-14 02:15:49 --> File loaded: application/views/common/footer.php
DEBUG - 2011-04-14 02:15:49 --> File loaded: application/views/layout/main.php
DEBUG - 2011-04-14 02:15:49 --> Final output sent to browser
DEBUG - 2011-04-14 02:15:49 --> Total execution time: 0.0817
DEBUG - 2011-04-14 02:15:49 --> Config Class Initialized
DEBUG - 2011-04-14 02:15:49 --> Hooks Class Initialized
DEBUG - 2011-04-14 02:15:49 --> Utf8 Class Initialized
DEBUG - 2011-04-14 02:15:49 --> UTF-8 Support Enabled
DEBUG - 2011-04-14 02:15:49 --> URI Class Initialized
DEBUG - 2011-04-14 02:15:49 --> Router Class Initialized
ERROR - 2011-04-14 02:15:49 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-04-14 02:16:03 --> Config Class Initialized
DEBUG - 2011-04-14 02:16:03 --> Hooks Class Initialized
DEBUG - 2011-04-14 02:16:03 --> Utf8 Class Initialized
DEBUG - 2011-04-14 02:16:03 --> UTF-8 Support Enabled
DEBUG - 2011-04-14 02:16:03 --> URI Class Initialized
DEBUG - 2011-04-14 02:16:03 --> Router Class Initialized
DEBUG - 2011-04-14 02:16:03 --> Output Class Initialized
DEBUG - 2011-04-14 02:16:03 --> Input Class Initialized
DEBUG - 2011-04-14 02:16:03 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-14 02:16:03 --> Language Class Initialized
DEBUG - 2011-04-14 02:16:03 --> Loader Class Initialized
DEBUG - 2011-04-14 02:16:03 --> Controller Class Initialized
DEBUG - 2011-04-14 02:16:03 --> Model Class Initialized
DEBUG - 2011-04-14 02:16:03 --> Model Class Initialized
DEBUG - 2011-04-14 02:16:03 --> Model Class Initialized
DEBUG - 2011-04-14 02:16:03 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-14 02:16:03 --> Database Driver Class Initialized
DEBUG - 2011-04-14 02:16:06 --> File loaded: application/views/table/main.php
DEBUG - 2011-04-14 02:16:06 --> Helper loaded: url_helper
DEBUG - 2011-04-14 02:16:06 --> File loaded: application/views/common/header.php
DEBUG - 2011-04-14 02:16:06 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-04-14 02:16:06 --> File loaded: application/views/common/footer.php
DEBUG - 2011-04-14 02:16:06 --> File loaded: application/views/layout/main.php
DEBUG - 2011-04-14 02:16:06 --> Final output sent to browser
DEBUG - 2011-04-14 02:16:06 --> Total execution time: 3.6576
DEBUG - 2011-04-14 02:16:08 --> Config Class Initialized
DEBUG - 2011-04-14 02:16:08 --> Hooks Class Initialized
DEBUG - 2011-04-14 02:16:08 --> Utf8 Class Initialized
DEBUG - 2011-04-14 02:16:08 --> UTF-8 Support Enabled
DEBUG - 2011-04-14 02:16:08 --> URI Class Initialized
DEBUG - 2011-04-14 02:16:08 --> Router Class Initialized
ERROR - 2011-04-14 02:16:08 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-04-14 02:16:13 --> Config Class Initialized
DEBUG - 2011-04-14 02:16:13 --> Hooks Class Initialized
DEBUG - 2011-04-14 02:16:13 --> Utf8 Class Initialized
DEBUG - 2011-04-14 02:16:13 --> UTF-8 Support Enabled
DEBUG - 2011-04-14 02:16:13 --> URI Class Initialized
DEBUG - 2011-04-14 02:16:13 --> Router Class Initialized
DEBUG - 2011-04-14 02:16:13 --> Output Class Initialized
DEBUG - 2011-04-14 02:16:13 --> Input Class Initialized
DEBUG - 2011-04-14 02:16:13 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-14 02:16:13 --> Language Class Initialized
DEBUG - 2011-04-14 02:16:13 --> Loader Class Initialized
DEBUG - 2011-04-14 02:16:13 --> Controller Class Initialized
DEBUG - 2011-04-14 02:16:13 --> Model Class Initialized
DEBUG - 2011-04-14 02:16:13 --> Model Class Initialized
DEBUG - 2011-04-14 02:16:13 --> Model Class Initialized
DEBUG - 2011-04-14 02:16:13 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-14 02:16:13 --> Database Driver Class Initialized
DEBUG - 2011-04-14 02:16:13 --> File loaded: application/views/table/main.php
DEBUG - 2011-04-14 02:16:13 --> Helper loaded: url_helper
DEBUG - 2011-04-14 02:16:13 --> File loaded: application/views/common/header.php
DEBUG - 2011-04-14 02:16:13 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-04-14 02:16:13 --> File loaded: application/views/common/footer.php
DEBUG - 2011-04-14 02:16:13 --> File loaded: application/views/layout/main.php
DEBUG - 2011-04-14 02:16:13 --> Final output sent to browser
DEBUG - 2011-04-14 02:16:13 --> Total execution time: 0.0530
DEBUG - 2011-04-14 03:04:39 --> Config Class Initialized
DEBUG - 2011-04-14 03:04:39 --> Hooks Class Initialized
DEBUG - 2011-04-14 03:04:39 --> Utf8 Class Initialized
DEBUG - 2011-04-14 03:04:39 --> UTF-8 Support Enabled
DEBUG - 2011-04-14 03:04:39 --> URI Class Initialized
DEBUG - 2011-04-14 03:04:39 --> Router Class Initialized
ERROR - 2011-04-14 03:04:40 --> 404 Page Not Found --> robots.txt
DEBUG - 2011-04-14 03:05:38 --> Config Class Initialized
DEBUG - 2011-04-14 03:05:38 --> Hooks Class Initialized
DEBUG - 2011-04-14 03:05:38 --> Utf8 Class Initialized
DEBUG - 2011-04-14 03:05:38 --> UTF-8 Support Enabled
DEBUG - 2011-04-14 03:05:38 --> URI Class Initialized
DEBUG - 2011-04-14 03:05:38 --> Router Class Initialized
DEBUG - 2011-04-14 03:05:38 --> Output Class Initialized
DEBUG - 2011-04-14 03:05:38 --> Input Class Initialized
DEBUG - 2011-04-14 03:05:38 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-14 03:05:38 --> Language Class Initialized
DEBUG - 2011-04-14 03:05:38 --> Loader Class Initialized
DEBUG - 2011-04-14 03:05:38 --> Controller Class Initialized
DEBUG - 2011-04-14 03:05:38 --> Model Class Initialized
DEBUG - 2011-04-14 03:05:38 --> Model Class Initialized
DEBUG - 2011-04-14 03:05:38 --> Model Class Initialized
DEBUG - 2011-04-14 03:05:38 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-14 03:05:38 --> Database Driver Class Initialized
DEBUG - 2011-04-14 03:05:58 --> File loaded: application/views/table/main.php
DEBUG - 2011-04-14 03:05:58 --> Helper loaded: url_helper
DEBUG - 2011-04-14 03:05:58 --> File loaded: application/views/common/header.php
DEBUG - 2011-04-14 03:05:58 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-04-14 03:05:59 --> File loaded: application/views/common/footer.php
DEBUG - 2011-04-14 03:05:59 --> File loaded: application/views/layout/main.php
DEBUG - 2011-04-14 03:05:59 --> Final output sent to browser
DEBUG - 2011-04-14 03:05:59 --> Total execution time: 20.8260
DEBUG - 2011-04-14 03:06:55 --> Config Class Initialized
DEBUG - 2011-04-14 03:06:55 --> Hooks Class Initialized
DEBUG - 2011-04-14 03:06:55 --> Utf8 Class Initialized
DEBUG - 2011-04-14 03:06:55 --> UTF-8 Support Enabled
DEBUG - 2011-04-14 03:06:55 --> URI Class Initialized
DEBUG - 2011-04-14 03:06:55 --> Router Class Initialized
DEBUG - 2011-04-14 03:06:55 --> Output Class Initialized
DEBUG - 2011-04-14 03:06:56 --> Input Class Initialized
DEBUG - 2011-04-14 03:06:56 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-14 03:06:56 --> Language Class Initialized
DEBUG - 2011-04-14 03:06:56 --> Loader Class Initialized
DEBUG - 2011-04-14 03:06:56 --> Controller Class Initialized
ERROR - 2011-04-14 03:06:56 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-04-14 03:06:56 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-04-14 03:06:56 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-04-14 03:06:56 --> Model Class Initialized
DEBUG - 2011-04-14 03:06:56 --> Model Class Initialized
DEBUG - 2011-04-14 03:06:56 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-14 03:06:56 --> Database Driver Class Initialized
DEBUG - 2011-04-14 03:06:56 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-04-14 03:06:56 --> Helper loaded: url_helper
DEBUG - 2011-04-14 03:06:56 --> File loaded: application/views/common/header.php
DEBUG - 2011-04-14 03:06:56 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-04-14 03:06:56 --> File loaded: application/views/common/footer.php
DEBUG - 2011-04-14 03:06:56 --> File loaded: application/views/layout/main.php
DEBUG - 2011-04-14 03:06:56 --> Final output sent to browser
DEBUG - 2011-04-14 03:06:56 --> Total execution time: 0.1445
DEBUG - 2011-04-14 03:06:57 --> Config Class Initialized
DEBUG - 2011-04-14 03:06:57 --> Hooks Class Initialized
DEBUG - 2011-04-14 03:06:57 --> Utf8 Class Initialized
DEBUG - 2011-04-14 03:06:57 --> UTF-8 Support Enabled
DEBUG - 2011-04-14 03:06:57 --> URI Class Initialized
DEBUG - 2011-04-14 03:06:57 --> Router Class Initialized
DEBUG - 2011-04-14 03:06:57 --> Output Class Initialized
DEBUG - 2011-04-14 03:06:57 --> Input Class Initialized
DEBUG - 2011-04-14 03:06:57 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-14 03:06:57 --> Language Class Initialized
DEBUG - 2011-04-14 03:06:57 --> Loader Class Initialized
DEBUG - 2011-04-14 03:06:57 --> Controller Class Initialized
DEBUG - 2011-04-14 03:06:57 --> Model Class Initialized
DEBUG - 2011-04-14 03:06:57 --> Model Class Initialized
DEBUG - 2011-04-14 03:06:57 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-14 03:06:57 --> Database Driver Class Initialized
DEBUG - 2011-04-14 03:06:58 --> Config Class Initialized
DEBUG - 2011-04-14 03:06:58 --> Hooks Class Initialized
DEBUG - 2011-04-14 03:06:58 --> Utf8 Class Initialized
DEBUG - 2011-04-14 03:06:58 --> UTF-8 Support Enabled
DEBUG - 2011-04-14 03:06:58 --> URI Class Initialized
DEBUG - 2011-04-14 03:06:58 --> Router Class Initialized
DEBUG - 2011-04-14 03:06:58 --> Output Class Initialized
DEBUG - 2011-04-14 03:06:58 --> Input Class Initialized
DEBUG - 2011-04-14 03:06:58 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-14 03:06:58 --> Language Class Initialized
DEBUG - 2011-04-14 03:06:58 --> Loader Class Initialized
DEBUG - 2011-04-14 03:06:58 --> Controller Class Initialized
ERROR - 2011-04-14 03:06:58 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-04-14 03:06:58 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-04-14 03:06:58 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-04-14 03:06:58 --> Model Class Initialized
DEBUG - 2011-04-14 03:06:58 --> Model Class Initialized
DEBUG - 2011-04-14 03:06:58 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-14 03:06:58 --> Database Driver Class Initialized
DEBUG - 2011-04-14 03:06:58 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-04-14 03:06:58 --> Helper loaded: url_helper
DEBUG - 2011-04-14 03:06:58 --> File loaded: application/views/common/header.php
DEBUG - 2011-04-14 03:06:58 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-04-14 03:06:58 --> File loaded: application/views/common/footer.php
DEBUG - 2011-04-14 03:06:58 --> File loaded: application/views/layout/main.php
DEBUG - 2011-04-14 03:06:58 --> Final output sent to browser
DEBUG - 2011-04-14 03:06:58 --> Total execution time: 0.0303
DEBUG - 2011-04-14 03:06:58 --> Final output sent to browser
DEBUG - 2011-04-14 03:06:58 --> Total execution time: 1.5567
DEBUG - 2011-04-14 03:07:00 --> Config Class Initialized
DEBUG - 2011-04-14 03:07:00 --> Hooks Class Initialized
DEBUG - 2011-04-14 03:07:00 --> Utf8 Class Initialized
DEBUG - 2011-04-14 03:07:00 --> UTF-8 Support Enabled
DEBUG - 2011-04-14 03:07:00 --> URI Class Initialized
DEBUG - 2011-04-14 03:07:00 --> Router Class Initialized
ERROR - 2011-04-14 03:07:00 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-04-14 03:07:27 --> Config Class Initialized
DEBUG - 2011-04-14 03:07:27 --> Hooks Class Initialized
DEBUG - 2011-04-14 03:07:27 --> Utf8 Class Initialized
DEBUG - 2011-04-14 03:07:27 --> UTF-8 Support Enabled
DEBUG - 2011-04-14 03:07:27 --> URI Class Initialized
DEBUG - 2011-04-14 03:07:27 --> Router Class Initialized
DEBUG - 2011-04-14 03:07:27 --> Output Class Initialized
DEBUG - 2011-04-14 03:07:27 --> Input Class Initialized
DEBUG - 2011-04-14 03:07:27 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-14 03:07:27 --> Language Class Initialized
DEBUG - 2011-04-14 03:07:27 --> Loader Class Initialized
DEBUG - 2011-04-14 03:07:27 --> Controller Class Initialized
ERROR - 2011-04-14 03:07:27 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-04-14 03:07:27 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-04-14 03:07:27 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-04-14 03:07:27 --> Model Class Initialized
DEBUG - 2011-04-14 03:07:27 --> Model Class Initialized
DEBUG - 2011-04-14 03:07:27 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-14 03:07:27 --> Database Driver Class Initialized
DEBUG - 2011-04-14 03:07:27 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-04-14 03:07:27 --> Helper loaded: url_helper
DEBUG - 2011-04-14 03:07:27 --> File loaded: application/views/common/header.php
DEBUG - 2011-04-14 03:07:27 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-04-14 03:07:27 --> File loaded: application/views/common/footer.php
DEBUG - 2011-04-14 03:07:27 --> File loaded: application/views/layout/main.php
DEBUG - 2011-04-14 03:07:27 --> Final output sent to browser
DEBUG - 2011-04-14 03:07:27 --> Total execution time: 0.0289
DEBUG - 2011-04-14 03:07:27 --> Config Class Initialized
DEBUG - 2011-04-14 03:07:27 --> Hooks Class Initialized
DEBUG - 2011-04-14 03:07:27 --> Utf8 Class Initialized
DEBUG - 2011-04-14 03:07:27 --> UTF-8 Support Enabled
DEBUG - 2011-04-14 03:07:27 --> URI Class Initialized
DEBUG - 2011-04-14 03:07:27 --> Router Class Initialized
DEBUG - 2011-04-14 03:07:27 --> Output Class Initialized
DEBUG - 2011-04-14 03:07:27 --> Input Class Initialized
DEBUG - 2011-04-14 03:07:27 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-14 03:07:27 --> Language Class Initialized
DEBUG - 2011-04-14 03:07:27 --> Loader Class Initialized
DEBUG - 2011-04-14 03:07:27 --> Controller Class Initialized
DEBUG - 2011-04-14 03:07:27 --> Model Class Initialized
DEBUG - 2011-04-14 03:07:27 --> Model Class Initialized
DEBUG - 2011-04-14 03:07:27 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-14 03:07:27 --> Database Driver Class Initialized
DEBUG - 2011-04-14 03:07:30 --> Final output sent to browser
DEBUG - 2011-04-14 03:07:30 --> Total execution time: 2.1336
DEBUG - 2011-04-14 03:07:42 --> Config Class Initialized
DEBUG - 2011-04-14 03:07:42 --> Hooks Class Initialized
DEBUG - 2011-04-14 03:07:42 --> Utf8 Class Initialized
DEBUG - 2011-04-14 03:07:42 --> UTF-8 Support Enabled
DEBUG - 2011-04-14 03:07:42 --> URI Class Initialized
DEBUG - 2011-04-14 03:07:42 --> Router Class Initialized
DEBUG - 2011-04-14 03:07:42 --> Output Class Initialized
DEBUG - 2011-04-14 03:07:42 --> Input Class Initialized
DEBUG - 2011-04-14 03:07:42 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-14 03:07:42 --> Language Class Initialized
DEBUG - 2011-04-14 03:07:42 --> Loader Class Initialized
DEBUG - 2011-04-14 03:07:42 --> Controller Class Initialized
ERROR - 2011-04-14 03:07:42 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-04-14 03:07:42 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-04-14 03:07:42 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-04-14 03:07:42 --> Model Class Initialized
DEBUG - 2011-04-14 03:07:42 --> Model Class Initialized
DEBUG - 2011-04-14 03:07:42 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-14 03:07:42 --> Database Driver Class Initialized
DEBUG - 2011-04-14 03:07:42 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-04-14 03:07:42 --> Helper loaded: url_helper
DEBUG - 2011-04-14 03:07:42 --> File loaded: application/views/common/header.php
DEBUG - 2011-04-14 03:07:42 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-04-14 03:07:42 --> File loaded: application/views/common/footer.php
DEBUG - 2011-04-14 03:07:42 --> File loaded: application/views/layout/main.php
DEBUG - 2011-04-14 03:07:42 --> Final output sent to browser
DEBUG - 2011-04-14 03:07:42 --> Total execution time: 0.0648
DEBUG - 2011-04-14 03:17:37 --> Config Class Initialized
DEBUG - 2011-04-14 03:17:37 --> Hooks Class Initialized
DEBUG - 2011-04-14 03:17:37 --> Utf8 Class Initialized
DEBUG - 2011-04-14 03:17:37 --> UTF-8 Support Enabled
DEBUG - 2011-04-14 03:17:37 --> URI Class Initialized
DEBUG - 2011-04-14 03:17:37 --> Router Class Initialized
ERROR - 2011-04-14 03:17:37 --> 404 Page Not Found --> robots.txt
DEBUG - 2011-04-14 03:17:37 --> Config Class Initialized
DEBUG - 2011-04-14 03:17:37 --> Hooks Class Initialized
DEBUG - 2011-04-14 03:17:37 --> Utf8 Class Initialized
DEBUG - 2011-04-14 03:17:37 --> UTF-8 Support Enabled
DEBUG - 2011-04-14 03:17:37 --> URI Class Initialized
DEBUG - 2011-04-14 03:17:37 --> Router Class Initialized
DEBUG - 2011-04-14 03:17:37 --> No URI present. Default controller set.
DEBUG - 2011-04-14 03:17:37 --> Output Class Initialized
DEBUG - 2011-04-14 03:17:37 --> Input Class Initialized
DEBUG - 2011-04-14 03:17:37 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-14 03:17:37 --> Language Class Initialized
DEBUG - 2011-04-14 03:17:37 --> Loader Class Initialized
DEBUG - 2011-04-14 03:17:37 --> Controller Class Initialized
DEBUG - 2011-04-14 03:17:37 --> File loaded: application/views/splash/main.php
DEBUG - 2011-04-14 03:17:37 --> Helper loaded: url_helper
DEBUG - 2011-04-14 03:17:37 --> File loaded: application/views/common/header.php
DEBUG - 2011-04-14 03:17:37 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-04-14 03:17:37 --> File loaded: application/views/common/footer.php
DEBUG - 2011-04-14 03:17:37 --> File loaded: application/views/layout/main.php
DEBUG - 2011-04-14 03:17:37 --> Final output sent to browser
DEBUG - 2011-04-14 03:17:37 --> Total execution time: 0.1325
DEBUG - 2011-04-14 03:19:59 --> Config Class Initialized
DEBUG - 2011-04-14 03:19:59 --> Hooks Class Initialized
DEBUG - 2011-04-14 03:19:59 --> Utf8 Class Initialized
DEBUG - 2011-04-14 03:19:59 --> UTF-8 Support Enabled
DEBUG - 2011-04-14 03:19:59 --> URI Class Initialized
DEBUG - 2011-04-14 03:19:59 --> Router Class Initialized
DEBUG - 2011-04-14 03:19:59 --> Output Class Initialized
DEBUG - 2011-04-14 03:19:59 --> Input Class Initialized
DEBUG - 2011-04-14 03:19:59 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-14 03:19:59 --> Language Class Initialized
DEBUG - 2011-04-14 03:19:59 --> Loader Class Initialized
DEBUG - 2011-04-14 03:19:59 --> Controller Class Initialized
DEBUG - 2011-04-14 03:19:59 --> Model Class Initialized
DEBUG - 2011-04-14 03:19:59 --> Model Class Initialized
DEBUG - 2011-04-14 03:19:59 --> Model Class Initialized
DEBUG - 2011-04-14 03:19:59 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-14 03:19:59 --> Database Driver Class Initialized
DEBUG - 2011-04-14 03:19:59 --> File loaded: application/views/table/main.php
DEBUG - 2011-04-14 03:20:00 --> Helper loaded: url_helper
DEBUG - 2011-04-14 03:20:00 --> File loaded: application/views/common/header.php
DEBUG - 2011-04-14 03:20:00 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-04-14 03:20:00 --> File loaded: application/views/common/footer.php
DEBUG - 2011-04-14 03:20:00 --> File loaded: application/views/layout/main.php
DEBUG - 2011-04-14 03:20:00 --> Final output sent to browser
DEBUG - 2011-04-14 03:20:00 --> Total execution time: 0.7130
DEBUG - 2011-04-14 03:20:03 --> Config Class Initialized
DEBUG - 2011-04-14 03:20:03 --> Hooks Class Initialized
DEBUG - 2011-04-14 03:20:03 --> Utf8 Class Initialized
DEBUG - 2011-04-14 03:20:03 --> UTF-8 Support Enabled
DEBUG - 2011-04-14 03:20:03 --> URI Class Initialized
DEBUG - 2011-04-14 03:20:03 --> Router Class Initialized
DEBUG - 2011-04-14 03:20:03 --> Output Class Initialized
DEBUG - 2011-04-14 03:20:03 --> Input Class Initialized
DEBUG - 2011-04-14 03:20:03 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-14 03:20:03 --> Language Class Initialized
DEBUG - 2011-04-14 03:20:03 --> Loader Class Initialized
DEBUG - 2011-04-14 03:20:03 --> Controller Class Initialized
DEBUG - 2011-04-14 03:20:03 --> Model Class Initialized
DEBUG - 2011-04-14 03:20:03 --> Model Class Initialized
DEBUG - 2011-04-14 03:20:03 --> Model Class Initialized
DEBUG - 2011-04-14 03:20:03 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-14 03:20:03 --> Database Driver Class Initialized
DEBUG - 2011-04-14 03:20:03 --> File loaded: application/views/table/main.php
DEBUG - 2011-04-14 03:20:03 --> Helper loaded: url_helper
DEBUG - 2011-04-14 03:20:03 --> File loaded: application/views/common/header.php
DEBUG - 2011-04-14 03:20:03 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-04-14 03:20:03 --> File loaded: application/views/common/footer.php
DEBUG - 2011-04-14 03:20:03 --> File loaded: application/views/layout/main.php
DEBUG - 2011-04-14 03:20:03 --> Final output sent to browser
DEBUG - 2011-04-14 03:20:03 --> Total execution time: 0.2245
DEBUG - 2011-04-14 03:20:05 --> Config Class Initialized
DEBUG - 2011-04-14 03:20:05 --> Hooks Class Initialized
DEBUG - 2011-04-14 03:20:05 --> Utf8 Class Initialized
DEBUG - 2011-04-14 03:20:05 --> UTF-8 Support Enabled
DEBUG - 2011-04-14 03:20:05 --> URI Class Initialized
DEBUG - 2011-04-14 03:20:05 --> Router Class Initialized
ERROR - 2011-04-14 03:20:05 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-04-14 03:32:51 --> Config Class Initialized
DEBUG - 2011-04-14 03:32:51 --> Hooks Class Initialized
DEBUG - 2011-04-14 03:32:51 --> Utf8 Class Initialized
DEBUG - 2011-04-14 03:32:51 --> UTF-8 Support Enabled
DEBUG - 2011-04-14 03:32:51 --> URI Class Initialized
DEBUG - 2011-04-14 03:32:51 --> Router Class Initialized
DEBUG - 2011-04-14 03:32:51 --> Output Class Initialized
DEBUG - 2011-04-14 03:32:51 --> Input Class Initialized
DEBUG - 2011-04-14 03:32:51 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-14 03:32:51 --> Language Class Initialized
DEBUG - 2011-04-14 03:32:51 --> Loader Class Initialized
DEBUG - 2011-04-14 03:32:51 --> Controller Class Initialized
DEBUG - 2011-04-14 03:32:51 --> Model Class Initialized
DEBUG - 2011-04-14 03:32:51 --> Model Class Initialized
DEBUG - 2011-04-14 03:32:51 --> Model Class Initialized
DEBUG - 2011-04-14 03:32:52 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-14 03:32:52 --> Database Driver Class Initialized
DEBUG - 2011-04-14 03:32:55 --> File loaded: application/views/table/main.php
DEBUG - 2011-04-14 03:32:56 --> Helper loaded: url_helper
DEBUG - 2011-04-14 03:32:56 --> File loaded: application/views/common/header.php
DEBUG - 2011-04-14 03:32:56 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-04-14 03:32:56 --> File loaded: application/views/common/footer.php
DEBUG - 2011-04-14 03:32:56 --> File loaded: application/views/layout/main.php
DEBUG - 2011-04-14 03:32:56 --> Final output sent to browser
DEBUG - 2011-04-14 03:32:56 --> Total execution time: 6.0655
DEBUG - 2011-04-14 03:32:58 --> Config Class Initialized
DEBUG - 2011-04-14 03:32:58 --> Hooks Class Initialized
DEBUG - 2011-04-14 03:32:58 --> Utf8 Class Initialized
DEBUG - 2011-04-14 03:32:58 --> UTF-8 Support Enabled
DEBUG - 2011-04-14 03:32:58 --> URI Class Initialized
DEBUG - 2011-04-14 03:32:58 --> Router Class Initialized
DEBUG - 2011-04-14 03:32:58 --> Output Class Initialized
DEBUG - 2011-04-14 03:32:58 --> Input Class Initialized
DEBUG - 2011-04-14 03:32:58 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-14 03:32:58 --> Language Class Initialized
DEBUG - 2011-04-14 03:32:59 --> Loader Class Initialized
DEBUG - 2011-04-14 03:32:59 --> Controller Class Initialized
ERROR - 2011-04-14 03:32:59 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-04-14 03:32:59 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-04-14 03:32:59 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-04-14 03:32:59 --> Model Class Initialized
DEBUG - 2011-04-14 03:32:59 --> Model Class Initialized
DEBUG - 2011-04-14 03:32:59 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-14 03:32:59 --> Database Driver Class Initialized
DEBUG - 2011-04-14 03:32:59 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-04-14 03:32:59 --> Helper loaded: url_helper
DEBUG - 2011-04-14 03:32:59 --> File loaded: application/views/common/header.php
DEBUG - 2011-04-14 03:32:59 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-04-14 03:32:59 --> File loaded: application/views/common/footer.php
DEBUG - 2011-04-14 03:32:59 --> File loaded: application/views/layout/main.php
DEBUG - 2011-04-14 03:32:59 --> Final output sent to browser
DEBUG - 2011-04-14 03:32:59 --> Total execution time: 0.5655
DEBUG - 2011-04-14 03:32:59 --> Config Class Initialized
DEBUG - 2011-04-14 03:32:59 --> Hooks Class Initialized
DEBUG - 2011-04-14 03:32:59 --> Utf8 Class Initialized
DEBUG - 2011-04-14 03:32:59 --> UTF-8 Support Enabled
DEBUG - 2011-04-14 03:32:59 --> URI Class Initialized
DEBUG - 2011-04-14 03:32:59 --> Router Class Initialized
DEBUG - 2011-04-14 03:32:59 --> Output Class Initialized
DEBUG - 2011-04-14 03:32:59 --> Input Class Initialized
DEBUG - 2011-04-14 03:32:59 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-14 03:32:59 --> Language Class Initialized
DEBUG - 2011-04-14 03:32:59 --> Loader Class Initialized
DEBUG - 2011-04-14 03:32:59 --> Controller Class Initialized
DEBUG - 2011-04-14 03:32:59 --> Model Class Initialized
DEBUG - 2011-04-14 03:32:59 --> Model Class Initialized
DEBUG - 2011-04-14 03:32:59 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-14 03:32:59 --> Database Driver Class Initialized
DEBUG - 2011-04-14 03:33:00 --> Final output sent to browser
DEBUG - 2011-04-14 03:33:00 --> Total execution time: 0.9319
DEBUG - 2011-04-14 03:53:44 --> Config Class Initialized
DEBUG - 2011-04-14 03:53:44 --> Hooks Class Initialized
DEBUG - 2011-04-14 03:53:44 --> Utf8 Class Initialized
DEBUG - 2011-04-14 03:53:44 --> UTF-8 Support Enabled
DEBUG - 2011-04-14 03:53:44 --> URI Class Initialized
DEBUG - 2011-04-14 03:53:44 --> Router Class Initialized
DEBUG - 2011-04-14 03:53:44 --> No URI present. Default controller set.
DEBUG - 2011-04-14 03:53:44 --> Output Class Initialized
DEBUG - 2011-04-14 03:53:44 --> Input Class Initialized
DEBUG - 2011-04-14 03:53:44 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-14 03:53:44 --> Language Class Initialized
DEBUG - 2011-04-14 03:53:44 --> Loader Class Initialized
DEBUG - 2011-04-14 03:53:44 --> Controller Class Initialized
DEBUG - 2011-04-14 03:53:44 --> File loaded: application/views/splash/main.php
DEBUG - 2011-04-14 03:53:44 --> Helper loaded: url_helper
DEBUG - 2011-04-14 03:53:44 --> File loaded: application/views/common/header.php
DEBUG - 2011-04-14 03:53:44 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-04-14 03:53:44 --> File loaded: application/views/common/footer.php
DEBUG - 2011-04-14 03:53:44 --> File loaded: application/views/layout/main.php
DEBUG - 2011-04-14 03:53:44 --> Final output sent to browser
DEBUG - 2011-04-14 03:53:44 --> Total execution time: 0.6268
DEBUG - 2011-04-14 03:53:46 --> Config Class Initialized
DEBUG - 2011-04-14 03:53:46 --> Hooks Class Initialized
DEBUG - 2011-04-14 03:53:46 --> Utf8 Class Initialized
DEBUG - 2011-04-14 03:53:46 --> UTF-8 Support Enabled
DEBUG - 2011-04-14 03:53:46 --> URI Class Initialized
DEBUG - 2011-04-14 03:53:46 --> Router Class Initialized
ERROR - 2011-04-14 03:53:46 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-04-14 03:54:43 --> Config Class Initialized
DEBUG - 2011-04-14 03:54:43 --> Hooks Class Initialized
DEBUG - 2011-04-14 03:54:43 --> Utf8 Class Initialized
DEBUG - 2011-04-14 03:54:43 --> UTF-8 Support Enabled
DEBUG - 2011-04-14 03:54:43 --> URI Class Initialized
DEBUG - 2011-04-14 03:54:43 --> Router Class Initialized
DEBUG - 2011-04-14 03:54:43 --> Output Class Initialized
DEBUG - 2011-04-14 03:54:43 --> Input Class Initialized
DEBUG - 2011-04-14 03:54:43 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-14 03:54:43 --> Language Class Initialized
DEBUG - 2011-04-14 03:54:43 --> Loader Class Initialized
DEBUG - 2011-04-14 03:54:43 --> Controller Class Initialized
DEBUG - 2011-04-14 03:54:43 --> Model Class Initialized
DEBUG - 2011-04-14 03:54:43 --> Model Class Initialized
DEBUG - 2011-04-14 03:54:43 --> Model Class Initialized
DEBUG - 2011-04-14 03:54:43 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-14 03:54:43 --> Database Driver Class Initialized
DEBUG - 2011-04-14 03:54:59 --> File loaded: application/views/table/main.php
DEBUG - 2011-04-14 03:54:59 --> Helper loaded: url_helper
DEBUG - 2011-04-14 03:54:59 --> File loaded: application/views/common/header.php
DEBUG - 2011-04-14 03:54:59 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-04-14 03:54:59 --> File loaded: application/views/common/footer.php
DEBUG - 2011-04-14 03:54:59 --> File loaded: application/views/layout/main.php
DEBUG - 2011-04-14 03:54:59 --> Final output sent to browser
DEBUG - 2011-04-14 03:54:59 --> Total execution time: 15.9359
DEBUG - 2011-04-14 03:55:02 --> Config Class Initialized
DEBUG - 2011-04-14 03:55:02 --> Hooks Class Initialized
DEBUG - 2011-04-14 03:55:02 --> Utf8 Class Initialized
DEBUG - 2011-04-14 03:55:02 --> UTF-8 Support Enabled
DEBUG - 2011-04-14 03:55:02 --> URI Class Initialized
DEBUG - 2011-04-14 03:55:02 --> Router Class Initialized
ERROR - 2011-04-14 03:55:02 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-04-14 03:56:05 --> Config Class Initialized
DEBUG - 2011-04-14 03:56:05 --> Hooks Class Initialized
DEBUG - 2011-04-14 03:56:05 --> Utf8 Class Initialized
DEBUG - 2011-04-14 03:56:05 --> UTF-8 Support Enabled
DEBUG - 2011-04-14 03:56:05 --> URI Class Initialized
DEBUG - 2011-04-14 03:56:05 --> Router Class Initialized
DEBUG - 2011-04-14 03:56:05 --> Output Class Initialized
DEBUG - 2011-04-14 03:56:05 --> Input Class Initialized
DEBUG - 2011-04-14 03:56:05 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-14 03:56:05 --> Language Class Initialized
DEBUG - 2011-04-14 03:56:05 --> Loader Class Initialized
DEBUG - 2011-04-14 03:56:05 --> Controller Class Initialized
DEBUG - 2011-04-14 03:56:05 --> Model Class Initialized
DEBUG - 2011-04-14 03:56:05 --> Model Class Initialized
DEBUG - 2011-04-14 03:56:05 --> Model Class Initialized
DEBUG - 2011-04-14 03:56:05 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-14 03:56:05 --> Database Driver Class Initialized
DEBUG - 2011-04-14 03:56:06 --> File loaded: application/views/table/main.php
DEBUG - 2011-04-14 03:56:06 --> Helper loaded: url_helper
DEBUG - 2011-04-14 03:56:06 --> File loaded: application/views/common/header.php
DEBUG - 2011-04-14 03:56:06 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-04-14 03:56:06 --> File loaded: application/views/common/footer.php
DEBUG - 2011-04-14 03:56:06 --> File loaded: application/views/layout/main.php
DEBUG - 2011-04-14 03:56:06 --> Final output sent to browser
DEBUG - 2011-04-14 03:56:06 --> Total execution time: 0.7135
DEBUG - 2011-04-14 03:56:08 --> Config Class Initialized
DEBUG - 2011-04-14 03:56:08 --> Hooks Class Initialized
DEBUG - 2011-04-14 03:56:08 --> Utf8 Class Initialized
DEBUG - 2011-04-14 03:56:08 --> UTF-8 Support Enabled
DEBUG - 2011-04-14 03:56:08 --> URI Class Initialized
DEBUG - 2011-04-14 03:56:08 --> Router Class Initialized
DEBUG - 2011-04-14 03:56:08 --> Output Class Initialized
DEBUG - 2011-04-14 03:56:08 --> Input Class Initialized
DEBUG - 2011-04-14 03:56:08 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-14 03:56:08 --> Language Class Initialized
DEBUG - 2011-04-14 03:56:08 --> Loader Class Initialized
DEBUG - 2011-04-14 03:56:08 --> Controller Class Initialized
DEBUG - 2011-04-14 03:56:08 --> Model Class Initialized
DEBUG - 2011-04-14 03:56:08 --> Model Class Initialized
DEBUG - 2011-04-14 03:56:08 --> Model Class Initialized
DEBUG - 2011-04-14 03:56:08 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-14 03:56:08 --> Database Driver Class Initialized
DEBUG - 2011-04-14 03:56:08 --> Config Class Initialized
DEBUG - 2011-04-14 03:56:08 --> Hooks Class Initialized
DEBUG - 2011-04-14 03:56:08 --> Utf8 Class Initialized
DEBUG - 2011-04-14 03:56:08 --> UTF-8 Support Enabled
DEBUG - 2011-04-14 03:56:08 --> URI Class Initialized
DEBUG - 2011-04-14 03:56:08 --> Router Class Initialized
ERROR - 2011-04-14 03:56:08 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-04-14 03:56:08 --> File loaded: application/views/table/main.php
DEBUG - 2011-04-14 03:56:08 --> Helper loaded: url_helper
DEBUG - 2011-04-14 03:56:08 --> File loaded: application/views/common/header.php
DEBUG - 2011-04-14 03:56:08 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-04-14 03:56:08 --> File loaded: application/views/common/footer.php
DEBUG - 2011-04-14 03:56:08 --> File loaded: application/views/layout/main.php
DEBUG - 2011-04-14 03:56:08 --> Final output sent to browser
DEBUG - 2011-04-14 03:56:08 --> Total execution time: 0.0550
DEBUG - 2011-04-14 03:56:18 --> Config Class Initialized
DEBUG - 2011-04-14 03:56:18 --> Hooks Class Initialized
DEBUG - 2011-04-14 03:56:18 --> Utf8 Class Initialized
DEBUG - 2011-04-14 03:56:18 --> UTF-8 Support Enabled
DEBUG - 2011-04-14 03:56:18 --> URI Class Initialized
DEBUG - 2011-04-14 03:56:18 --> Router Class Initialized
DEBUG - 2011-04-14 03:56:18 --> Output Class Initialized
DEBUG - 2011-04-14 03:56:18 --> Input Class Initialized
DEBUG - 2011-04-14 03:56:18 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-14 03:56:18 --> Language Class Initialized
DEBUG - 2011-04-14 03:56:18 --> Loader Class Initialized
DEBUG - 2011-04-14 03:56:18 --> Controller Class Initialized
DEBUG - 2011-04-14 03:56:18 --> Model Class Initialized
DEBUG - 2011-04-14 03:56:18 --> Model Class Initialized
DEBUG - 2011-04-14 03:56:18 --> Model Class Initialized
DEBUG - 2011-04-14 03:56:18 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-14 03:56:18 --> Database Driver Class Initialized
DEBUG - 2011-04-14 03:56:18 --> File loaded: application/views/table/main.php
DEBUG - 2011-04-14 03:56:18 --> Helper loaded: url_helper
DEBUG - 2011-04-14 03:56:18 --> File loaded: application/views/common/header.php
DEBUG - 2011-04-14 03:56:18 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-04-14 03:56:18 --> File loaded: application/views/common/footer.php
DEBUG - 2011-04-14 03:56:18 --> File loaded: application/views/layout/main.php
DEBUG - 2011-04-14 03:56:18 --> Final output sent to browser
DEBUG - 2011-04-14 03:56:18 --> Total execution time: 0.2081
DEBUG - 2011-04-14 03:56:20 --> Config Class Initialized
DEBUG - 2011-04-14 03:56:20 --> Hooks Class Initialized
DEBUG - 2011-04-14 03:56:20 --> Utf8 Class Initialized
DEBUG - 2011-04-14 03:56:20 --> UTF-8 Support Enabled
DEBUG - 2011-04-14 03:56:20 --> URI Class Initialized
DEBUG - 2011-04-14 03:56:20 --> Router Class Initialized
ERROR - 2011-04-14 03:56:20 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-04-14 03:56:37 --> Config Class Initialized
DEBUG - 2011-04-14 03:56:37 --> Hooks Class Initialized
DEBUG - 2011-04-14 03:56:37 --> Utf8 Class Initialized
DEBUG - 2011-04-14 03:56:37 --> UTF-8 Support Enabled
DEBUG - 2011-04-14 03:56:37 --> URI Class Initialized
DEBUG - 2011-04-14 03:56:37 --> Router Class Initialized
DEBUG - 2011-04-14 03:56:37 --> Output Class Initialized
DEBUG - 2011-04-14 03:56:37 --> Input Class Initialized
DEBUG - 2011-04-14 03:56:37 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-14 03:56:37 --> Language Class Initialized
DEBUG - 2011-04-14 03:56:37 --> Loader Class Initialized
DEBUG - 2011-04-14 03:56:37 --> Controller Class Initialized
DEBUG - 2011-04-14 03:56:37 --> Model Class Initialized
DEBUG - 2011-04-14 03:56:37 --> Model Class Initialized
DEBUG - 2011-04-14 03:56:37 --> Model Class Initialized
DEBUG - 2011-04-14 03:56:37 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-14 03:56:37 --> Database Driver Class Initialized
DEBUG - 2011-04-14 03:56:37 --> File loaded: application/views/table/main.php
DEBUG - 2011-04-14 03:56:37 --> Helper loaded: url_helper
DEBUG - 2011-04-14 03:56:37 --> File loaded: application/views/common/header.php
DEBUG - 2011-04-14 03:56:37 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-04-14 03:56:37 --> File loaded: application/views/common/footer.php
DEBUG - 2011-04-14 03:56:37 --> File loaded: application/views/layout/main.php
DEBUG - 2011-04-14 03:56:37 --> Final output sent to browser
DEBUG - 2011-04-14 03:56:37 --> Total execution time: 0.0492
DEBUG - 2011-04-14 03:56:39 --> Config Class Initialized
DEBUG - 2011-04-14 03:56:39 --> Hooks Class Initialized
DEBUG - 2011-04-14 03:56:39 --> Utf8 Class Initialized
DEBUG - 2011-04-14 03:56:39 --> UTF-8 Support Enabled
DEBUG - 2011-04-14 03:56:39 --> URI Class Initialized
DEBUG - 2011-04-14 03:56:39 --> Router Class Initialized
ERROR - 2011-04-14 03:56:39 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-04-14 03:56:59 --> Config Class Initialized
DEBUG - 2011-04-14 03:56:59 --> Hooks Class Initialized
DEBUG - 2011-04-14 03:56:59 --> Utf8 Class Initialized
DEBUG - 2011-04-14 03:56:59 --> UTF-8 Support Enabled
DEBUG - 2011-04-14 03:56:59 --> URI Class Initialized
DEBUG - 2011-04-14 03:56:59 --> Router Class Initialized
DEBUG - 2011-04-14 03:56:59 --> Output Class Initialized
DEBUG - 2011-04-14 03:56:59 --> Input Class Initialized
DEBUG - 2011-04-14 03:56:59 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-14 03:56:59 --> Language Class Initialized
DEBUG - 2011-04-14 03:56:59 --> Loader Class Initialized
DEBUG - 2011-04-14 03:56:59 --> Controller Class Initialized
DEBUG - 2011-04-14 03:56:59 --> Model Class Initialized
DEBUG - 2011-04-14 03:56:59 --> Model Class Initialized
DEBUG - 2011-04-14 03:56:59 --> Model Class Initialized
DEBUG - 2011-04-14 03:56:59 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-14 03:56:59 --> Database Driver Class Initialized
DEBUG - 2011-04-14 03:56:59 --> File loaded: application/views/table/main.php
DEBUG - 2011-04-14 03:56:59 --> Helper loaded: url_helper
DEBUG - 2011-04-14 03:56:59 --> File loaded: application/views/common/header.php
DEBUG - 2011-04-14 03:56:59 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-04-14 03:56:59 --> File loaded: application/views/common/footer.php
DEBUG - 2011-04-14 03:56:59 --> File loaded: application/views/layout/main.php
DEBUG - 2011-04-14 03:56:59 --> Final output sent to browser
DEBUG - 2011-04-14 03:56:59 --> Total execution time: 0.6650
DEBUG - 2011-04-14 03:57:01 --> Config Class Initialized
DEBUG - 2011-04-14 03:57:01 --> Hooks Class Initialized
DEBUG - 2011-04-14 03:57:01 --> Utf8 Class Initialized
DEBUG - 2011-04-14 03:57:01 --> UTF-8 Support Enabled
DEBUG - 2011-04-14 03:57:01 --> URI Class Initialized
DEBUG - 2011-04-14 03:57:01 --> Router Class Initialized
DEBUG - 2011-04-14 03:57:01 --> Output Class Initialized
DEBUG - 2011-04-14 03:57:01 --> Input Class Initialized
DEBUG - 2011-04-14 03:57:01 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-14 03:57:01 --> Language Class Initialized
DEBUG - 2011-04-14 03:57:01 --> Loader Class Initialized
DEBUG - 2011-04-14 03:57:01 --> Controller Class Initialized
DEBUG - 2011-04-14 03:57:01 --> Model Class Initialized
DEBUG - 2011-04-14 03:57:01 --> Model Class Initialized
DEBUG - 2011-04-14 03:57:01 --> Model Class Initialized
DEBUG - 2011-04-14 03:57:01 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-14 03:57:01 --> Database Driver Class Initialized
DEBUG - 2011-04-14 03:57:01 --> File loaded: application/views/table/main.php
DEBUG - 2011-04-14 03:57:01 --> Helper loaded: url_helper
DEBUG - 2011-04-14 03:57:01 --> File loaded: application/views/common/header.php
DEBUG - 2011-04-14 03:57:01 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-04-14 03:57:01 --> File loaded: application/views/common/footer.php
DEBUG - 2011-04-14 03:57:01 --> File loaded: application/views/layout/main.php
DEBUG - 2011-04-14 03:57:01 --> Final output sent to browser
DEBUG - 2011-04-14 03:57:01 --> Total execution time: 0.0601
DEBUG - 2011-04-14 03:57:01 --> Config Class Initialized
DEBUG - 2011-04-14 03:57:01 --> Hooks Class Initialized
DEBUG - 2011-04-14 03:57:01 --> Utf8 Class Initialized
DEBUG - 2011-04-14 03:57:01 --> UTF-8 Support Enabled
DEBUG - 2011-04-14 03:57:01 --> URI Class Initialized
DEBUG - 2011-04-14 03:57:01 --> Router Class Initialized
ERROR - 2011-04-14 03:57:01 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-04-14 03:57:13 --> Config Class Initialized
DEBUG - 2011-04-14 03:57:13 --> Hooks Class Initialized
DEBUG - 2011-04-14 03:57:13 --> Utf8 Class Initialized
DEBUG - 2011-04-14 03:57:13 --> UTF-8 Support Enabled
DEBUG - 2011-04-14 03:57:13 --> URI Class Initialized
DEBUG - 2011-04-14 03:57:13 --> Router Class Initialized
DEBUG - 2011-04-14 03:57:13 --> Output Class Initialized
DEBUG - 2011-04-14 03:57:13 --> Input Class Initialized
DEBUG - 2011-04-14 03:57:13 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-14 03:57:13 --> Language Class Initialized
DEBUG - 2011-04-14 03:57:13 --> Loader Class Initialized
DEBUG - 2011-04-14 03:57:13 --> Controller Class Initialized
DEBUG - 2011-04-14 03:57:13 --> Model Class Initialized
DEBUG - 2011-04-14 03:57:13 --> Model Class Initialized
DEBUG - 2011-04-14 03:57:13 --> Model Class Initialized
DEBUG - 2011-04-14 03:57:13 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-14 03:57:14 --> Database Driver Class Initialized
DEBUG - 2011-04-14 03:57:14 --> File loaded: application/views/table/main.php
DEBUG - 2011-04-14 03:57:14 --> Helper loaded: url_helper
DEBUG - 2011-04-14 03:57:14 --> File loaded: application/views/common/header.php
DEBUG - 2011-04-14 03:57:14 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-04-14 03:57:14 --> File loaded: application/views/common/footer.php
DEBUG - 2011-04-14 03:57:14 --> File loaded: application/views/layout/main.php
DEBUG - 2011-04-14 03:57:14 --> Final output sent to browser
DEBUG - 2011-04-14 03:57:14 --> Total execution time: 0.6922
DEBUG - 2011-04-14 03:57:15 --> Config Class Initialized
DEBUG - 2011-04-14 03:57:15 --> Hooks Class Initialized
DEBUG - 2011-04-14 03:57:15 --> Utf8 Class Initialized
DEBUG - 2011-04-14 03:57:15 --> UTF-8 Support Enabled
DEBUG - 2011-04-14 03:57:15 --> URI Class Initialized
DEBUG - 2011-04-14 03:57:15 --> Router Class Initialized
DEBUG - 2011-04-14 03:57:15 --> Output Class Initialized
DEBUG - 2011-04-14 03:57:15 --> Input Class Initialized
DEBUG - 2011-04-14 03:57:15 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-14 03:57:15 --> Language Class Initialized
DEBUG - 2011-04-14 03:57:15 --> Loader Class Initialized
DEBUG - 2011-04-14 03:57:15 --> Controller Class Initialized
DEBUG - 2011-04-14 03:57:15 --> Model Class Initialized
DEBUG - 2011-04-14 03:57:15 --> Model Class Initialized
DEBUG - 2011-04-14 03:57:15 --> Model Class Initialized
DEBUG - 2011-04-14 03:57:15 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-14 03:57:15 --> Database Driver Class Initialized
DEBUG - 2011-04-14 03:57:15 --> File loaded: application/views/table/main.php
DEBUG - 2011-04-14 03:57:15 --> Helper loaded: url_helper
DEBUG - 2011-04-14 03:57:15 --> File loaded: application/views/common/header.php
DEBUG - 2011-04-14 03:57:15 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-04-14 03:57:15 --> File loaded: application/views/common/footer.php
DEBUG - 2011-04-14 03:57:15 --> File loaded: application/views/layout/main.php
DEBUG - 2011-04-14 03:57:15 --> Final output sent to browser
DEBUG - 2011-04-14 03:57:15 --> Total execution time: 0.0476
DEBUG - 2011-04-14 03:57:16 --> Config Class Initialized
DEBUG - 2011-04-14 03:57:16 --> Hooks Class Initialized
DEBUG - 2011-04-14 03:57:16 --> Utf8 Class Initialized
DEBUG - 2011-04-14 03:57:16 --> UTF-8 Support Enabled
DEBUG - 2011-04-14 03:57:16 --> URI Class Initialized
DEBUG - 2011-04-14 03:57:16 --> Router Class Initialized
ERROR - 2011-04-14 03:57:16 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-04-14 03:57:32 --> Config Class Initialized
DEBUG - 2011-04-14 03:57:32 --> Hooks Class Initialized
DEBUG - 2011-04-14 03:57:32 --> Utf8 Class Initialized
DEBUG - 2011-04-14 03:57:32 --> UTF-8 Support Enabled
DEBUG - 2011-04-14 03:57:32 --> URI Class Initialized
DEBUG - 2011-04-14 03:57:32 --> Router Class Initialized
DEBUG - 2011-04-14 03:57:32 --> Output Class Initialized
DEBUG - 2011-04-14 03:57:32 --> Input Class Initialized
DEBUG - 2011-04-14 03:57:32 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-14 03:57:32 --> Language Class Initialized
DEBUG - 2011-04-14 03:57:32 --> Loader Class Initialized
DEBUG - 2011-04-14 03:57:32 --> Controller Class Initialized
DEBUG - 2011-04-14 03:57:32 --> Model Class Initialized
DEBUG - 2011-04-14 03:57:32 --> Model Class Initialized
DEBUG - 2011-04-14 03:57:32 --> Model Class Initialized
DEBUG - 2011-04-14 03:57:32 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-14 03:57:32 --> Database Driver Class Initialized
DEBUG - 2011-04-14 03:57:32 --> File loaded: application/views/table/main.php
DEBUG - 2011-04-14 03:57:32 --> Helper loaded: url_helper
DEBUG - 2011-04-14 03:57:32 --> File loaded: application/views/common/header.php
DEBUG - 2011-04-14 03:57:32 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-04-14 03:57:32 --> File loaded: application/views/common/footer.php
DEBUG - 2011-04-14 03:57:32 --> File loaded: application/views/layout/main.php
DEBUG - 2011-04-14 03:57:32 --> Final output sent to browser
DEBUG - 2011-04-14 03:57:32 --> Total execution time: 0.3232
DEBUG - 2011-04-14 03:57:34 --> Config Class Initialized
DEBUG - 2011-04-14 03:57:34 --> Hooks Class Initialized
DEBUG - 2011-04-14 03:57:34 --> Utf8 Class Initialized
DEBUG - 2011-04-14 03:57:34 --> UTF-8 Support Enabled
DEBUG - 2011-04-14 03:57:34 --> URI Class Initialized
DEBUG - 2011-04-14 03:57:34 --> Router Class Initialized
ERROR - 2011-04-14 03:57:34 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-04-14 03:57:35 --> Config Class Initialized
DEBUG - 2011-04-14 03:57:35 --> Hooks Class Initialized
DEBUG - 2011-04-14 03:57:35 --> Utf8 Class Initialized
DEBUG - 2011-04-14 03:57:35 --> UTF-8 Support Enabled
DEBUG - 2011-04-14 03:57:35 --> URI Class Initialized
DEBUG - 2011-04-14 03:57:35 --> Router Class Initialized
DEBUG - 2011-04-14 03:57:35 --> Output Class Initialized
DEBUG - 2011-04-14 03:57:35 --> Input Class Initialized
DEBUG - 2011-04-14 03:57:35 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-14 03:57:35 --> Language Class Initialized
DEBUG - 2011-04-14 03:57:35 --> Loader Class Initialized
DEBUG - 2011-04-14 03:57:35 --> Controller Class Initialized
DEBUG - 2011-04-14 03:57:35 --> Model Class Initialized
DEBUG - 2011-04-14 03:57:35 --> Model Class Initialized
DEBUG - 2011-04-14 03:57:35 --> Model Class Initialized
DEBUG - 2011-04-14 03:57:35 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-14 03:57:35 --> Database Driver Class Initialized
DEBUG - 2011-04-14 03:57:35 --> File loaded: application/views/table/main.php
DEBUG - 2011-04-14 03:57:35 --> Helper loaded: url_helper
DEBUG - 2011-04-14 03:57:35 --> File loaded: application/views/common/header.php
DEBUG - 2011-04-14 03:57:35 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-04-14 03:57:35 --> File loaded: application/views/common/footer.php
DEBUG - 2011-04-14 03:57:35 --> File loaded: application/views/layout/main.php
DEBUG - 2011-04-14 03:57:35 --> Final output sent to browser
DEBUG - 2011-04-14 03:57:35 --> Total execution time: 0.0480
DEBUG - 2011-04-14 03:57:48 --> Config Class Initialized
DEBUG - 2011-04-14 03:57:48 --> Hooks Class Initialized
DEBUG - 2011-04-14 03:57:48 --> Utf8 Class Initialized
DEBUG - 2011-04-14 03:57:48 --> UTF-8 Support Enabled
DEBUG - 2011-04-14 03:57:48 --> URI Class Initialized
DEBUG - 2011-04-14 03:57:48 --> Router Class Initialized
DEBUG - 2011-04-14 03:57:48 --> Output Class Initialized
DEBUG - 2011-04-14 03:57:48 --> Input Class Initialized
DEBUG - 2011-04-14 03:57:48 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-14 03:57:48 --> Language Class Initialized
DEBUG - 2011-04-14 03:57:48 --> Loader Class Initialized
DEBUG - 2011-04-14 03:57:48 --> Controller Class Initialized
DEBUG - 2011-04-14 03:57:48 --> Model Class Initialized
DEBUG - 2011-04-14 03:57:48 --> Model Class Initialized
DEBUG - 2011-04-14 03:57:48 --> Model Class Initialized
DEBUG - 2011-04-14 03:57:48 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-14 03:57:48 --> Database Driver Class Initialized
DEBUG - 2011-04-14 03:57:48 --> File loaded: application/views/table/main.php
DEBUG - 2011-04-14 03:57:48 --> Helper loaded: url_helper
DEBUG - 2011-04-14 03:57:48 --> File loaded: application/views/common/header.php
DEBUG - 2011-04-14 03:57:48 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-04-14 03:57:48 --> File loaded: application/views/common/footer.php
DEBUG - 2011-04-14 03:57:48 --> File loaded: application/views/layout/main.php
DEBUG - 2011-04-14 03:57:48 --> Final output sent to browser
DEBUG - 2011-04-14 03:57:48 --> Total execution time: 0.2184
DEBUG - 2011-04-14 03:57:49 --> Config Class Initialized
DEBUG - 2011-04-14 03:57:49 --> Hooks Class Initialized
DEBUG - 2011-04-14 03:57:49 --> Utf8 Class Initialized
DEBUG - 2011-04-14 03:57:49 --> UTF-8 Support Enabled
DEBUG - 2011-04-14 03:57:49 --> URI Class Initialized
DEBUG - 2011-04-14 03:57:49 --> Router Class Initialized
DEBUG - 2011-04-14 03:57:49 --> Output Class Initialized
DEBUG - 2011-04-14 03:57:49 --> Input Class Initialized
DEBUG - 2011-04-14 03:57:49 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-14 03:57:49 --> Language Class Initialized
DEBUG - 2011-04-14 03:57:49 --> Loader Class Initialized
DEBUG - 2011-04-14 03:57:49 --> Controller Class Initialized
DEBUG - 2011-04-14 03:57:49 --> Model Class Initialized
DEBUG - 2011-04-14 03:57:49 --> Model Class Initialized
DEBUG - 2011-04-14 03:57:49 --> Model Class Initialized
DEBUG - 2011-04-14 03:57:49 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-14 03:57:49 --> Database Driver Class Initialized
DEBUG - 2011-04-14 03:57:49 --> File loaded: application/views/table/main.php
DEBUG - 2011-04-14 03:57:49 --> Helper loaded: url_helper
DEBUG - 2011-04-14 03:57:49 --> File loaded: application/views/common/header.php
DEBUG - 2011-04-14 03:57:49 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-04-14 03:57:49 --> File loaded: application/views/common/footer.php
DEBUG - 2011-04-14 03:57:49 --> File loaded: application/views/layout/main.php
DEBUG - 2011-04-14 03:57:49 --> Final output sent to browser
DEBUG - 2011-04-14 03:57:49 --> Total execution time: 0.0547
DEBUG - 2011-04-14 03:57:50 --> Config Class Initialized
DEBUG - 2011-04-14 03:57:50 --> Hooks Class Initialized
DEBUG - 2011-04-14 03:57:50 --> Utf8 Class Initialized
DEBUG - 2011-04-14 03:57:50 --> UTF-8 Support Enabled
DEBUG - 2011-04-14 03:57:50 --> URI Class Initialized
DEBUG - 2011-04-14 03:57:50 --> Router Class Initialized
ERROR - 2011-04-14 03:57:50 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-04-14 03:57:57 --> Config Class Initialized
DEBUG - 2011-04-14 03:57:57 --> Hooks Class Initialized
DEBUG - 2011-04-14 03:57:57 --> Utf8 Class Initialized
DEBUG - 2011-04-14 03:57:57 --> UTF-8 Support Enabled
DEBUG - 2011-04-14 03:57:57 --> URI Class Initialized
DEBUG - 2011-04-14 03:57:57 --> Router Class Initialized
DEBUG - 2011-04-14 03:57:57 --> Output Class Initialized
DEBUG - 2011-04-14 03:57:57 --> Input Class Initialized
DEBUG - 2011-04-14 03:57:57 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-14 03:57:57 --> Language Class Initialized
DEBUG - 2011-04-14 03:57:57 --> Loader Class Initialized
DEBUG - 2011-04-14 03:57:57 --> Controller Class Initialized
DEBUG - 2011-04-14 03:57:57 --> Model Class Initialized
DEBUG - 2011-04-14 03:57:57 --> Model Class Initialized
DEBUG - 2011-04-14 03:57:57 --> Model Class Initialized
DEBUG - 2011-04-14 03:57:57 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-14 03:57:57 --> Database Driver Class Initialized
DEBUG - 2011-04-14 03:57:57 --> File loaded: application/views/table/main.php
DEBUG - 2011-04-14 03:57:57 --> Helper loaded: url_helper
DEBUG - 2011-04-14 03:57:57 --> File loaded: application/views/common/header.php
DEBUG - 2011-04-14 03:57:57 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-04-14 03:57:57 --> File loaded: application/views/common/footer.php
DEBUG - 2011-04-14 03:57:57 --> File loaded: application/views/layout/main.php
DEBUG - 2011-04-14 03:57:57 --> Final output sent to browser
DEBUG - 2011-04-14 03:57:57 --> Total execution time: 0.2303
DEBUG - 2011-04-14 03:57:59 --> Config Class Initialized
DEBUG - 2011-04-14 03:57:59 --> Hooks Class Initialized
DEBUG - 2011-04-14 03:57:59 --> Utf8 Class Initialized
DEBUG - 2011-04-14 03:57:59 --> UTF-8 Support Enabled
DEBUG - 2011-04-14 03:57:59 --> URI Class Initialized
DEBUG - 2011-04-14 03:57:59 --> Router Class Initialized
DEBUG - 2011-04-14 03:57:59 --> Output Class Initialized
DEBUG - 2011-04-14 03:57:59 --> Input Class Initialized
DEBUG - 2011-04-14 03:57:59 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-14 03:57:59 --> Language Class Initialized
DEBUG - 2011-04-14 03:57:59 --> Loader Class Initialized
DEBUG - 2011-04-14 03:57:59 --> Controller Class Initialized
DEBUG - 2011-04-14 03:57:59 --> Model Class Initialized
DEBUG - 2011-04-14 03:57:59 --> Model Class Initialized
DEBUG - 2011-04-14 03:57:59 --> Model Class Initialized
DEBUG - 2011-04-14 03:57:59 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-14 03:57:59 --> Database Driver Class Initialized
DEBUG - 2011-04-14 03:57:59 --> File loaded: application/views/table/main.php
DEBUG - 2011-04-14 03:57:59 --> Helper loaded: url_helper
DEBUG - 2011-04-14 03:57:59 --> File loaded: application/views/common/header.php
DEBUG - 2011-04-14 03:57:59 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-04-14 03:57:59 --> File loaded: application/views/common/footer.php
DEBUG - 2011-04-14 03:57:59 --> File loaded: application/views/layout/main.php
DEBUG - 2011-04-14 03:57:59 --> Final output sent to browser
DEBUG - 2011-04-14 03:57:59 --> Total execution time: 0.0438
DEBUG - 2011-04-14 03:57:59 --> Config Class Initialized
DEBUG - 2011-04-14 03:57:59 --> Hooks Class Initialized
DEBUG - 2011-04-14 03:57:59 --> Utf8 Class Initialized
DEBUG - 2011-04-14 03:57:59 --> UTF-8 Support Enabled
DEBUG - 2011-04-14 03:57:59 --> URI Class Initialized
DEBUG - 2011-04-14 03:57:59 --> Router Class Initialized
ERROR - 2011-04-14 03:57:59 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-04-14 03:58:08 --> Config Class Initialized
DEBUG - 2011-04-14 03:58:08 --> Hooks Class Initialized
DEBUG - 2011-04-14 03:58:08 --> Utf8 Class Initialized
DEBUG - 2011-04-14 03:58:08 --> UTF-8 Support Enabled
DEBUG - 2011-04-14 03:58:08 --> URI Class Initialized
DEBUG - 2011-04-14 03:58:08 --> Router Class Initialized
DEBUG - 2011-04-14 03:58:08 --> Output Class Initialized
DEBUG - 2011-04-14 03:58:08 --> Input Class Initialized
DEBUG - 2011-04-14 03:58:08 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-14 03:58:08 --> Language Class Initialized
DEBUG - 2011-04-14 03:58:08 --> Loader Class Initialized
DEBUG - 2011-04-14 03:58:08 --> Controller Class Initialized
DEBUG - 2011-04-14 03:58:08 --> Model Class Initialized
DEBUG - 2011-04-14 03:58:08 --> Model Class Initialized
DEBUG - 2011-04-14 03:58:08 --> Model Class Initialized
DEBUG - 2011-04-14 03:58:08 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-14 03:58:08 --> Database Driver Class Initialized
DEBUG - 2011-04-14 03:58:09 --> File loaded: application/views/table/main.php
DEBUG - 2011-04-14 03:58:09 --> Helper loaded: url_helper
DEBUG - 2011-04-14 03:58:09 --> File loaded: application/views/common/header.php
DEBUG - 2011-04-14 03:58:09 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-04-14 03:58:09 --> File loaded: application/views/common/footer.php
DEBUG - 2011-04-14 03:58:09 --> File loaded: application/views/layout/main.php
DEBUG - 2011-04-14 03:58:09 --> Final output sent to browser
DEBUG - 2011-04-14 03:58:09 --> Total execution time: 0.2829
DEBUG - 2011-04-14 03:58:10 --> Config Class Initialized
DEBUG - 2011-04-14 03:58:10 --> Hooks Class Initialized
DEBUG - 2011-04-14 03:58:10 --> Utf8 Class Initialized
DEBUG - 2011-04-14 03:58:10 --> UTF-8 Support Enabled
DEBUG - 2011-04-14 03:58:10 --> URI Class Initialized
DEBUG - 2011-04-14 03:58:10 --> Router Class Initialized
ERROR - 2011-04-14 03:58:10 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-04-14 03:58:11 --> Config Class Initialized
DEBUG - 2011-04-14 03:58:11 --> Hooks Class Initialized
DEBUG - 2011-04-14 03:58:11 --> Utf8 Class Initialized
DEBUG - 2011-04-14 03:58:11 --> UTF-8 Support Enabled
DEBUG - 2011-04-14 03:58:11 --> URI Class Initialized
DEBUG - 2011-04-14 03:58:11 --> Router Class Initialized
DEBUG - 2011-04-14 03:58:11 --> Output Class Initialized
DEBUG - 2011-04-14 03:58:11 --> Input Class Initialized
DEBUG - 2011-04-14 03:58:11 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-14 03:58:11 --> Language Class Initialized
DEBUG - 2011-04-14 03:58:11 --> Loader Class Initialized
DEBUG - 2011-04-14 03:58:11 --> Controller Class Initialized
DEBUG - 2011-04-14 03:58:11 --> Model Class Initialized
DEBUG - 2011-04-14 03:58:11 --> Model Class Initialized
DEBUG - 2011-04-14 03:58:11 --> Model Class Initialized
DEBUG - 2011-04-14 03:58:11 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-14 03:58:11 --> Database Driver Class Initialized
DEBUG - 2011-04-14 03:58:11 --> File loaded: application/views/table/main.php
DEBUG - 2011-04-14 03:58:11 --> Helper loaded: url_helper
DEBUG - 2011-04-14 03:58:11 --> File loaded: application/views/common/header.php
DEBUG - 2011-04-14 03:58:11 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-04-14 03:58:11 --> File loaded: application/views/common/footer.php
DEBUG - 2011-04-14 03:58:11 --> File loaded: application/views/layout/main.php
DEBUG - 2011-04-14 03:58:11 --> Final output sent to browser
DEBUG - 2011-04-14 03:58:11 --> Total execution time: 0.0885
DEBUG - 2011-04-14 03:58:19 --> Config Class Initialized
DEBUG - 2011-04-14 03:58:19 --> Hooks Class Initialized
DEBUG - 2011-04-14 03:58:19 --> Utf8 Class Initialized
DEBUG - 2011-04-14 03:58:19 --> UTF-8 Support Enabled
DEBUG - 2011-04-14 03:58:19 --> URI Class Initialized
DEBUG - 2011-04-14 03:58:19 --> Router Class Initialized
DEBUG - 2011-04-14 03:58:19 --> Output Class Initialized
DEBUG - 2011-04-14 03:58:19 --> Input Class Initialized
DEBUG - 2011-04-14 03:58:19 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-14 03:58:19 --> Language Class Initialized
DEBUG - 2011-04-14 03:58:19 --> Loader Class Initialized
DEBUG - 2011-04-14 03:58:19 --> Controller Class Initialized
DEBUG - 2011-04-14 03:58:19 --> Model Class Initialized
DEBUG - 2011-04-14 03:58:19 --> Model Class Initialized
DEBUG - 2011-04-14 03:58:19 --> Model Class Initialized
DEBUG - 2011-04-14 03:58:19 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-14 03:58:19 --> Database Driver Class Initialized
DEBUG - 2011-04-14 03:58:19 --> File loaded: application/views/table/main.php
DEBUG - 2011-04-14 03:58:19 --> Helper loaded: url_helper
DEBUG - 2011-04-14 03:58:19 --> File loaded: application/views/common/header.php
DEBUG - 2011-04-14 03:58:19 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-04-14 03:58:19 --> File loaded: application/views/common/footer.php
DEBUG - 2011-04-14 03:58:19 --> File loaded: application/views/layout/main.php
DEBUG - 2011-04-14 03:58:19 --> Final output sent to browser
DEBUG - 2011-04-14 03:58:19 --> Total execution time: 0.1866
DEBUG - 2011-04-14 03:58:22 --> Config Class Initialized
DEBUG - 2011-04-14 03:58:22 --> Hooks Class Initialized
DEBUG - 2011-04-14 03:58:22 --> Utf8 Class Initialized
DEBUG - 2011-04-14 03:58:22 --> UTF-8 Support Enabled
DEBUG - 2011-04-14 03:58:22 --> URI Class Initialized
DEBUG - 2011-04-14 03:58:22 --> Router Class Initialized
ERROR - 2011-04-14 03:58:22 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-04-14 04:04:44 --> Config Class Initialized
DEBUG - 2011-04-14 04:04:44 --> Hooks Class Initialized
DEBUG - 2011-04-14 04:04:44 --> Utf8 Class Initialized
DEBUG - 2011-04-14 04:04:44 --> UTF-8 Support Enabled
DEBUG - 2011-04-14 04:04:44 --> URI Class Initialized
DEBUG - 2011-04-14 04:04:44 --> Router Class Initialized
DEBUG - 2011-04-14 04:04:44 --> Output Class Initialized
DEBUG - 2011-04-14 04:04:44 --> Input Class Initialized
DEBUG - 2011-04-14 04:04:44 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-14 04:04:44 --> Language Class Initialized
DEBUG - 2011-04-14 04:04:44 --> Loader Class Initialized
DEBUG - 2011-04-14 04:04:44 --> Controller Class Initialized
ERROR - 2011-04-14 04:04:44 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-04-14 04:04:44 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-04-14 04:04:44 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-04-14 04:04:44 --> Model Class Initialized
DEBUG - 2011-04-14 04:04:44 --> Model Class Initialized
DEBUG - 2011-04-14 04:04:44 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-14 04:04:45 --> Database Driver Class Initialized
DEBUG - 2011-04-14 04:04:45 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-04-14 04:04:45 --> Helper loaded: url_helper
DEBUG - 2011-04-14 04:04:45 --> File loaded: application/views/common/header.php
DEBUG - 2011-04-14 04:04:45 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-04-14 04:04:45 --> File loaded: application/views/common/footer.php
DEBUG - 2011-04-14 04:04:45 --> File loaded: application/views/layout/main.php
DEBUG - 2011-04-14 04:04:45 --> Final output sent to browser
DEBUG - 2011-04-14 04:04:45 --> Total execution time: 0.1395
DEBUG - 2011-04-14 04:04:46 --> Config Class Initialized
DEBUG - 2011-04-14 04:04:46 --> Hooks Class Initialized
DEBUG - 2011-04-14 04:04:46 --> Utf8 Class Initialized
DEBUG - 2011-04-14 04:04:46 --> UTF-8 Support Enabled
DEBUG - 2011-04-14 04:04:46 --> URI Class Initialized
DEBUG - 2011-04-14 04:04:46 --> Router Class Initialized
DEBUG - 2011-04-14 04:04:46 --> Output Class Initialized
DEBUG - 2011-04-14 04:04:46 --> Input Class Initialized
DEBUG - 2011-04-14 04:04:46 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-14 04:04:46 --> Language Class Initialized
DEBUG - 2011-04-14 04:04:46 --> Loader Class Initialized
DEBUG - 2011-04-14 04:04:46 --> Controller Class Initialized
DEBUG - 2011-04-14 04:04:46 --> Model Class Initialized
DEBUG - 2011-04-14 04:04:46 --> Model Class Initialized
DEBUG - 2011-04-14 04:04:46 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-14 04:04:46 --> Database Driver Class Initialized
DEBUG - 2011-04-14 04:04:48 --> Final output sent to browser
DEBUG - 2011-04-14 04:04:48 --> Total execution time: 1.9969
DEBUG - 2011-04-14 04:04:50 --> Config Class Initialized
DEBUG - 2011-04-14 04:04:50 --> Hooks Class Initialized
DEBUG - 2011-04-14 04:04:50 --> Utf8 Class Initialized
DEBUG - 2011-04-14 04:04:50 --> UTF-8 Support Enabled
DEBUG - 2011-04-14 04:04:50 --> URI Class Initialized
DEBUG - 2011-04-14 04:04:50 --> Router Class Initialized
ERROR - 2011-04-14 04:04:50 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-04-14 04:46:23 --> Config Class Initialized
DEBUG - 2011-04-14 04:46:23 --> Hooks Class Initialized
DEBUG - 2011-04-14 04:46:23 --> Utf8 Class Initialized
DEBUG - 2011-04-14 04:46:23 --> UTF-8 Support Enabled
DEBUG - 2011-04-14 04:46:23 --> URI Class Initialized
DEBUG - 2011-04-14 04:46:23 --> Router Class Initialized
DEBUG - 2011-04-14 04:46:23 --> Output Class Initialized
DEBUG - 2011-04-14 04:46:23 --> Input Class Initialized
DEBUG - 2011-04-14 04:46:23 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-14 04:46:23 --> Language Class Initialized
DEBUG - 2011-04-14 04:46:23 --> Loader Class Initialized
DEBUG - 2011-04-14 04:46:24 --> Controller Class Initialized
DEBUG - 2011-04-14 04:46:24 --> Model Class Initialized
DEBUG - 2011-04-14 04:46:24 --> Model Class Initialized
DEBUG - 2011-04-14 04:46:24 --> Model Class Initialized
DEBUG - 2011-04-14 04:46:24 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-14 04:46:24 --> Database Driver Class Initialized
DEBUG - 2011-04-14 04:46:27 --> File loaded: application/views/table/main.php
DEBUG - 2011-04-14 04:46:27 --> Helper loaded: url_helper
DEBUG - 2011-04-14 04:46:27 --> File loaded: application/views/common/header.php
DEBUG - 2011-04-14 04:46:27 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-04-14 04:46:27 --> File loaded: application/views/common/footer.php
DEBUG - 2011-04-14 04:46:27 --> File loaded: application/views/layout/main.php
DEBUG - 2011-04-14 04:46:27 --> Final output sent to browser
DEBUG - 2011-04-14 04:46:27 --> Total execution time: 3.8179
DEBUG - 2011-04-14 04:46:28 --> Config Class Initialized
DEBUG - 2011-04-14 04:46:28 --> Hooks Class Initialized
DEBUG - 2011-04-14 04:46:28 --> Utf8 Class Initialized
DEBUG - 2011-04-14 04:46:28 --> UTF-8 Support Enabled
DEBUG - 2011-04-14 04:46:28 --> URI Class Initialized
DEBUG - 2011-04-14 04:46:28 --> Router Class Initialized
DEBUG - 2011-04-14 04:46:28 --> Output Class Initialized
DEBUG - 2011-04-14 04:46:28 --> Input Class Initialized
DEBUG - 2011-04-14 04:46:28 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-14 04:46:28 --> Language Class Initialized
DEBUG - 2011-04-14 04:46:28 --> Loader Class Initialized
DEBUG - 2011-04-14 04:46:28 --> Controller Class Initialized
ERROR - 2011-04-14 04:46:28 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-04-14 04:46:28 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-04-14 04:46:28 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-04-14 04:46:28 --> Model Class Initialized
DEBUG - 2011-04-14 04:46:28 --> Model Class Initialized
DEBUG - 2011-04-14 04:46:28 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-14 04:46:28 --> Database Driver Class Initialized
DEBUG - 2011-04-14 04:46:28 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-04-14 04:46:28 --> Helper loaded: url_helper
DEBUG - 2011-04-14 04:46:28 --> File loaded: application/views/common/header.php
DEBUG - 2011-04-14 04:46:28 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-04-14 04:46:28 --> File loaded: application/views/common/footer.php
DEBUG - 2011-04-14 04:46:28 --> File loaded: application/views/layout/main.php
DEBUG - 2011-04-14 04:46:28 --> Final output sent to browser
DEBUG - 2011-04-14 04:46:28 --> Total execution time: 0.2817
DEBUG - 2011-04-14 04:47:33 --> Config Class Initialized
DEBUG - 2011-04-14 04:47:33 --> Hooks Class Initialized
DEBUG - 2011-04-14 04:47:33 --> Utf8 Class Initialized
DEBUG - 2011-04-14 04:47:33 --> UTF-8 Support Enabled
DEBUG - 2011-04-14 04:47:33 --> URI Class Initialized
DEBUG - 2011-04-14 04:47:33 --> Router Class Initialized
DEBUG - 2011-04-14 04:47:33 --> Output Class Initialized
DEBUG - 2011-04-14 04:47:33 --> Input Class Initialized
DEBUG - 2011-04-14 04:47:33 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-14 04:47:33 --> Language Class Initialized
DEBUG - 2011-04-14 04:47:33 --> Loader Class Initialized
DEBUG - 2011-04-14 04:47:33 --> Controller Class Initialized
DEBUG - 2011-04-14 04:47:33 --> Model Class Initialized
DEBUG - 2011-04-14 04:47:33 --> Model Class Initialized
DEBUG - 2011-04-14 04:47:33 --> Model Class Initialized
DEBUG - 2011-04-14 04:47:33 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-14 04:47:33 --> Database Driver Class Initialized
DEBUG - 2011-04-14 04:47:33 --> File loaded: application/views/table/main.php
DEBUG - 2011-04-14 04:47:33 --> Helper loaded: url_helper
DEBUG - 2011-04-14 04:47:33 --> File loaded: application/views/common/header.php
DEBUG - 2011-04-14 04:47:33 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-04-14 04:47:33 --> File loaded: application/views/common/footer.php
DEBUG - 2011-04-14 04:47:33 --> File loaded: application/views/layout/main.php
DEBUG - 2011-04-14 04:47:33 --> Final output sent to browser
DEBUG - 2011-04-14 04:47:33 --> Total execution time: 0.0526
DEBUG - 2011-04-14 06:15:51 --> Config Class Initialized
DEBUG - 2011-04-14 06:15:51 --> Hooks Class Initialized
DEBUG - 2011-04-14 06:15:51 --> Utf8 Class Initialized
DEBUG - 2011-04-14 06:15:51 --> UTF-8 Support Enabled
DEBUG - 2011-04-14 06:15:51 --> URI Class Initialized
DEBUG - 2011-04-14 06:15:51 --> Router Class Initialized
DEBUG - 2011-04-14 06:15:51 --> Output Class Initialized
DEBUG - 2011-04-14 06:15:51 --> Input Class Initialized
DEBUG - 2011-04-14 06:15:51 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-14 06:15:51 --> Language Class Initialized
DEBUG - 2011-04-14 06:15:51 --> Loader Class Initialized
DEBUG - 2011-04-14 06:15:51 --> Controller Class Initialized
ERROR - 2011-04-14 06:15:51 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-04-14 06:15:51 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-04-14 06:15:51 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-04-14 06:15:51 --> Model Class Initialized
DEBUG - 2011-04-14 06:15:51 --> Model Class Initialized
DEBUG - 2011-04-14 06:15:51 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-14 06:15:51 --> Database Driver Class Initialized
DEBUG - 2011-04-14 06:15:51 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-04-14 06:15:51 --> Helper loaded: url_helper
DEBUG - 2011-04-14 06:15:51 --> File loaded: application/views/common/header.php
DEBUG - 2011-04-14 06:15:51 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-04-14 06:15:51 --> File loaded: application/views/common/footer.php
DEBUG - 2011-04-14 06:15:51 --> File loaded: application/views/layout/main.php
DEBUG - 2011-04-14 06:15:51 --> Final output sent to browser
DEBUG - 2011-04-14 06:15:51 --> Total execution time: 0.6841
DEBUG - 2011-04-14 06:15:53 --> Config Class Initialized
DEBUG - 2011-04-14 06:15:53 --> Hooks Class Initialized
DEBUG - 2011-04-14 06:15:53 --> Utf8 Class Initialized
DEBUG - 2011-04-14 06:15:53 --> UTF-8 Support Enabled
DEBUG - 2011-04-14 06:15:53 --> URI Class Initialized
DEBUG - 2011-04-14 06:15:53 --> Router Class Initialized
DEBUG - 2011-04-14 06:15:53 --> Output Class Initialized
DEBUG - 2011-04-14 06:15:53 --> Input Class Initialized
DEBUG - 2011-04-14 06:15:53 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-14 06:15:53 --> Language Class Initialized
DEBUG - 2011-04-14 06:15:53 --> Loader Class Initialized
DEBUG - 2011-04-14 06:15:53 --> Controller Class Initialized
DEBUG - 2011-04-14 06:15:53 --> Model Class Initialized
DEBUG - 2011-04-14 06:15:53 --> Model Class Initialized
DEBUG - 2011-04-14 06:15:53 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-14 06:15:53 --> Database Driver Class Initialized
DEBUG - 2011-04-14 06:15:54 --> Final output sent to browser
DEBUG - 2011-04-14 06:15:54 --> Total execution time: 0.7102
DEBUG - 2011-04-14 06:15:57 --> Config Class Initialized
DEBUG - 2011-04-14 06:15:57 --> Hooks Class Initialized
DEBUG - 2011-04-14 06:15:57 --> Utf8 Class Initialized
DEBUG - 2011-04-14 06:15:57 --> UTF-8 Support Enabled
DEBUG - 2011-04-14 06:15:57 --> URI Class Initialized
DEBUG - 2011-04-14 06:15:57 --> Router Class Initialized
ERROR - 2011-04-14 06:15:57 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-04-14 06:16:24 --> Config Class Initialized
DEBUG - 2011-04-14 06:16:24 --> Hooks Class Initialized
DEBUG - 2011-04-14 06:16:24 --> Utf8 Class Initialized
DEBUG - 2011-04-14 06:16:24 --> UTF-8 Support Enabled
DEBUG - 2011-04-14 06:16:24 --> URI Class Initialized
DEBUG - 2011-04-14 06:16:24 --> Router Class Initialized
DEBUG - 2011-04-14 06:16:24 --> Output Class Initialized
DEBUG - 2011-04-14 06:16:24 --> Input Class Initialized
DEBUG - 2011-04-14 06:16:24 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-14 06:16:24 --> Language Class Initialized
DEBUG - 2011-04-14 06:16:24 --> Loader Class Initialized
DEBUG - 2011-04-14 06:16:24 --> Controller Class Initialized
ERROR - 2011-04-14 06:16:24 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-04-14 06:16:24 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-04-14 06:16:24 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-04-14 06:16:24 --> Model Class Initialized
DEBUG - 2011-04-14 06:16:24 --> Model Class Initialized
DEBUG - 2011-04-14 06:16:24 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-14 06:16:24 --> Database Driver Class Initialized
DEBUG - 2011-04-14 06:16:24 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-04-14 06:16:24 --> Helper loaded: url_helper
DEBUG - 2011-04-14 06:16:24 --> File loaded: application/views/common/header.php
DEBUG - 2011-04-14 06:16:24 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-04-14 06:16:24 --> File loaded: application/views/common/footer.php
DEBUG - 2011-04-14 06:16:24 --> File loaded: application/views/layout/main.php
DEBUG - 2011-04-14 06:16:24 --> Final output sent to browser
DEBUG - 2011-04-14 06:16:24 --> Total execution time: 0.0309
DEBUG - 2011-04-14 06:16:25 --> Config Class Initialized
DEBUG - 2011-04-14 06:16:25 --> Hooks Class Initialized
DEBUG - 2011-04-14 06:16:25 --> Utf8 Class Initialized
DEBUG - 2011-04-14 06:16:25 --> UTF-8 Support Enabled
DEBUG - 2011-04-14 06:16:25 --> URI Class Initialized
DEBUG - 2011-04-14 06:16:25 --> Router Class Initialized
DEBUG - 2011-04-14 06:16:25 --> Output Class Initialized
DEBUG - 2011-04-14 06:16:25 --> Input Class Initialized
DEBUG - 2011-04-14 06:16:25 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-14 06:16:25 --> Language Class Initialized
DEBUG - 2011-04-14 06:16:25 --> Loader Class Initialized
DEBUG - 2011-04-14 06:16:25 --> Controller Class Initialized
DEBUG - 2011-04-14 06:16:25 --> Model Class Initialized
DEBUG - 2011-04-14 06:16:25 --> Model Class Initialized
DEBUG - 2011-04-14 06:16:25 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-14 06:16:25 --> Database Driver Class Initialized
DEBUG - 2011-04-14 06:16:25 --> Final output sent to browser
DEBUG - 2011-04-14 06:16:25 --> Total execution time: 0.6638
DEBUG - 2011-04-14 07:29:06 --> Config Class Initialized
DEBUG - 2011-04-14 07:29:07 --> Hooks Class Initialized
DEBUG - 2011-04-14 07:29:07 --> Utf8 Class Initialized
DEBUG - 2011-04-14 07:29:07 --> UTF-8 Support Enabled
DEBUG - 2011-04-14 07:29:07 --> URI Class Initialized
DEBUG - 2011-04-14 07:29:07 --> Router Class Initialized
DEBUG - 2011-04-14 07:29:07 --> No URI present. Default controller set.
DEBUG - 2011-04-14 07:29:07 --> Output Class Initialized
DEBUG - 2011-04-14 07:29:07 --> Input Class Initialized
DEBUG - 2011-04-14 07:29:07 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-14 07:29:07 --> Language Class Initialized
DEBUG - 2011-04-14 07:29:08 --> Loader Class Initialized
DEBUG - 2011-04-14 07:29:08 --> Controller Class Initialized
DEBUG - 2011-04-14 07:29:08 --> File loaded: application/views/splash/main.php
DEBUG - 2011-04-14 07:29:08 --> Helper loaded: url_helper
DEBUG - 2011-04-14 07:29:08 --> File loaded: application/views/common/header.php
DEBUG - 2011-04-14 07:29:08 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-04-14 07:29:08 --> File loaded: application/views/common/footer.php
DEBUG - 2011-04-14 07:29:08 --> File loaded: application/views/layout/main.php
DEBUG - 2011-04-14 07:29:08 --> Final output sent to browser
DEBUG - 2011-04-14 07:29:08 --> Total execution time: 2.4003
DEBUG - 2011-04-14 07:43:55 --> Config Class Initialized
DEBUG - 2011-04-14 07:43:55 --> Hooks Class Initialized
DEBUG - 2011-04-14 07:43:55 --> Utf8 Class Initialized
DEBUG - 2011-04-14 07:43:55 --> UTF-8 Support Enabled
DEBUG - 2011-04-14 07:43:55 --> URI Class Initialized
DEBUG - 2011-04-14 07:43:55 --> Router Class Initialized
DEBUG - 2011-04-14 07:43:55 --> Output Class Initialized
DEBUG - 2011-04-14 07:43:55 --> Input Class Initialized
DEBUG - 2011-04-14 07:43:55 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-14 07:43:55 --> Language Class Initialized
DEBUG - 2011-04-14 07:43:55 --> Loader Class Initialized
DEBUG - 2011-04-14 07:43:55 --> Controller Class Initialized
DEBUG - 2011-04-14 07:43:55 --> Model Class Initialized
DEBUG - 2011-04-14 07:43:55 --> Model Class Initialized
DEBUG - 2011-04-14 07:43:55 --> Model Class Initialized
DEBUG - 2011-04-14 07:43:55 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-14 07:43:59 --> Database Driver Class Initialized
DEBUG - 2011-04-14 07:44:02 --> File loaded: application/views/table/main.php
DEBUG - 2011-04-14 07:44:04 --> Helper loaded: url_helper
DEBUG - 2011-04-14 07:44:04 --> File loaded: application/views/common/header.php
DEBUG - 2011-04-14 07:44:04 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-04-14 07:44:04 --> File loaded: application/views/common/footer.php
DEBUG - 2011-04-14 07:44:04 --> File loaded: application/views/layout/main.php
DEBUG - 2011-04-14 07:44:04 --> Final output sent to browser
DEBUG - 2011-04-14 07:44:04 --> Total execution time: 10.8270
DEBUG - 2011-04-14 07:44:09 --> Config Class Initialized
DEBUG - 2011-04-14 07:44:09 --> Hooks Class Initialized
DEBUG - 2011-04-14 07:44:09 --> Utf8 Class Initialized
DEBUG - 2011-04-14 07:44:09 --> UTF-8 Support Enabled
DEBUG - 2011-04-14 07:44:09 --> URI Class Initialized
DEBUG - 2011-04-14 07:44:09 --> Router Class Initialized
ERROR - 2011-04-14 07:44:09 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-04-14 07:44:19 --> Config Class Initialized
DEBUG - 2011-04-14 07:44:19 --> Hooks Class Initialized
DEBUG - 2011-04-14 07:44:19 --> Utf8 Class Initialized
DEBUG - 2011-04-14 07:44:19 --> UTF-8 Support Enabled
DEBUG - 2011-04-14 07:44:19 --> URI Class Initialized
DEBUG - 2011-04-14 07:44:19 --> Router Class Initialized
DEBUG - 2011-04-14 07:44:19 --> Output Class Initialized
DEBUG - 2011-04-14 07:44:19 --> Input Class Initialized
DEBUG - 2011-04-14 07:44:19 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-14 07:44:19 --> Language Class Initialized
DEBUG - 2011-04-14 07:44:19 --> Loader Class Initialized
DEBUG - 2011-04-14 07:44:19 --> Controller Class Initialized
DEBUG - 2011-04-14 07:44:19 --> Model Class Initialized
DEBUG - 2011-04-14 07:44:19 --> Model Class Initialized
DEBUG - 2011-04-14 07:44:19 --> Model Class Initialized
DEBUG - 2011-04-14 07:44:19 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-14 07:44:19 --> Database Driver Class Initialized
DEBUG - 2011-04-14 07:44:22 --> File loaded: application/views/table/main.php
DEBUG - 2011-04-14 07:44:22 --> Helper loaded: url_helper
DEBUG - 2011-04-14 07:44:22 --> File loaded: application/views/common/header.php
DEBUG - 2011-04-14 07:44:22 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-04-14 07:44:22 --> File loaded: application/views/common/footer.php
DEBUG - 2011-04-14 07:44:22 --> File loaded: application/views/layout/main.php
DEBUG - 2011-04-14 07:44:22 --> Final output sent to browser
DEBUG - 2011-04-14 07:44:22 --> Total execution time: 3.3365
DEBUG - 2011-04-14 07:44:32 --> Config Class Initialized
DEBUG - 2011-04-14 07:44:32 --> Hooks Class Initialized
DEBUG - 2011-04-14 07:44:32 --> Utf8 Class Initialized
DEBUG - 2011-04-14 07:44:32 --> UTF-8 Support Enabled
DEBUG - 2011-04-14 07:44:32 --> URI Class Initialized
DEBUG - 2011-04-14 07:44:32 --> Router Class Initialized
DEBUG - 2011-04-14 07:44:32 --> Output Class Initialized
DEBUG - 2011-04-14 07:44:32 --> Input Class Initialized
DEBUG - 2011-04-14 07:44:32 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-14 07:44:32 --> Language Class Initialized
DEBUG - 2011-04-14 07:44:32 --> Loader Class Initialized
DEBUG - 2011-04-14 07:44:32 --> Controller Class Initialized
DEBUG - 2011-04-14 07:44:32 --> Model Class Initialized
DEBUG - 2011-04-14 07:44:32 --> Model Class Initialized
DEBUG - 2011-04-14 07:44:32 --> Model Class Initialized
DEBUG - 2011-04-14 07:44:32 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-14 07:44:32 --> Database Driver Class Initialized
DEBUG - 2011-04-14 07:44:32 --> File loaded: application/views/table/main.php
DEBUG - 2011-04-14 07:44:32 --> Helper loaded: url_helper
DEBUG - 2011-04-14 07:44:32 --> File loaded: application/views/common/header.php
DEBUG - 2011-04-14 07:44:32 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-04-14 07:44:32 --> File loaded: application/views/common/footer.php
DEBUG - 2011-04-14 07:44:32 --> File loaded: application/views/layout/main.php
DEBUG - 2011-04-14 07:44:32 --> Final output sent to browser
DEBUG - 2011-04-14 07:44:32 --> Total execution time: 0.0961
DEBUG - 2011-04-14 07:44:35 --> Config Class Initialized
DEBUG - 2011-04-14 07:44:35 --> Hooks Class Initialized
DEBUG - 2011-04-14 07:44:35 --> Utf8 Class Initialized
DEBUG - 2011-04-14 07:44:35 --> UTF-8 Support Enabled
DEBUG - 2011-04-14 07:44:35 --> URI Class Initialized
DEBUG - 2011-04-14 07:44:35 --> Router Class Initialized
DEBUG - 2011-04-14 07:44:35 --> Output Class Initialized
DEBUG - 2011-04-14 07:44:35 --> Input Class Initialized
DEBUG - 2011-04-14 07:44:35 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-14 07:44:35 --> Language Class Initialized
DEBUG - 2011-04-14 07:44:35 --> Loader Class Initialized
DEBUG - 2011-04-14 07:44:35 --> Controller Class Initialized
DEBUG - 2011-04-14 07:44:35 --> Model Class Initialized
DEBUG - 2011-04-14 07:44:35 --> Model Class Initialized
DEBUG - 2011-04-14 07:44:35 --> Model Class Initialized
DEBUG - 2011-04-14 07:44:35 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-14 07:44:35 --> Database Driver Class Initialized
DEBUG - 2011-04-14 07:44:35 --> File loaded: application/views/table/main.php
DEBUG - 2011-04-14 07:44:35 --> Helper loaded: url_helper
DEBUG - 2011-04-14 07:44:35 --> File loaded: application/views/common/header.php
DEBUG - 2011-04-14 07:44:35 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-04-14 07:44:35 --> File loaded: application/views/common/footer.php
DEBUG - 2011-04-14 07:44:35 --> File loaded: application/views/layout/main.php
DEBUG - 2011-04-14 07:44:35 --> Final output sent to browser
DEBUG - 2011-04-14 07:44:35 --> Total execution time: 0.1217
DEBUG - 2011-04-14 07:50:58 --> Config Class Initialized
DEBUG - 2011-04-14 07:50:58 --> Hooks Class Initialized
DEBUG - 2011-04-14 07:50:58 --> Utf8 Class Initialized
DEBUG - 2011-04-14 07:50:58 --> UTF-8 Support Enabled
DEBUG - 2011-04-14 07:50:58 --> URI Class Initialized
DEBUG - 2011-04-14 07:50:58 --> Router Class Initialized
DEBUG - 2011-04-14 07:50:58 --> Output Class Initialized
DEBUG - 2011-04-14 07:50:58 --> Input Class Initialized
DEBUG - 2011-04-14 07:50:58 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-14 07:50:58 --> Language Class Initialized
DEBUG - 2011-04-14 07:50:58 --> Loader Class Initialized
DEBUG - 2011-04-14 07:50:58 --> Controller Class Initialized
DEBUG - 2011-04-14 07:50:58 --> Model Class Initialized
DEBUG - 2011-04-14 07:50:58 --> Model Class Initialized
DEBUG - 2011-04-14 07:50:58 --> Model Class Initialized
DEBUG - 2011-04-14 07:50:58 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-14 07:50:58 --> Database Driver Class Initialized
DEBUG - 2011-04-14 07:50:58 --> File loaded: application/views/table/main.php
DEBUG - 2011-04-14 07:50:58 --> Helper loaded: url_helper
DEBUG - 2011-04-14 07:50:58 --> File loaded: application/views/common/header.php
DEBUG - 2011-04-14 07:50:58 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-04-14 07:50:58 --> File loaded: application/views/common/footer.php
DEBUG - 2011-04-14 07:50:58 --> File loaded: application/views/layout/main.php
DEBUG - 2011-04-14 07:50:58 --> Final output sent to browser
DEBUG - 2011-04-14 07:50:58 --> Total execution time: 0.1556
DEBUG - 2011-04-14 07:51:06 --> Config Class Initialized
DEBUG - 2011-04-14 07:51:06 --> Hooks Class Initialized
DEBUG - 2011-04-14 07:51:06 --> Utf8 Class Initialized
DEBUG - 2011-04-14 07:51:06 --> UTF-8 Support Enabled
DEBUG - 2011-04-14 07:51:06 --> URI Class Initialized
DEBUG - 2011-04-14 07:51:06 --> Router Class Initialized
ERROR - 2011-04-14 07:51:06 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-04-14 07:51:08 --> Config Class Initialized
DEBUG - 2011-04-14 07:51:08 --> Hooks Class Initialized
DEBUG - 2011-04-14 07:51:08 --> Utf8 Class Initialized
DEBUG - 2011-04-14 07:51:08 --> UTF-8 Support Enabled
DEBUG - 2011-04-14 07:51:08 --> URI Class Initialized
DEBUG - 2011-04-14 07:51:08 --> Router Class Initialized
ERROR - 2011-04-14 07:51:08 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-04-14 08:45:54 --> Config Class Initialized
DEBUG - 2011-04-14 08:45:54 --> Hooks Class Initialized
DEBUG - 2011-04-14 08:45:54 --> Utf8 Class Initialized
DEBUG - 2011-04-14 08:45:54 --> UTF-8 Support Enabled
DEBUG - 2011-04-14 08:45:54 --> URI Class Initialized
DEBUG - 2011-04-14 08:45:54 --> Router Class Initialized
DEBUG - 2011-04-14 08:45:54 --> No URI present. Default controller set.
DEBUG - 2011-04-14 08:45:54 --> Output Class Initialized
DEBUG - 2011-04-14 08:45:54 --> Input Class Initialized
DEBUG - 2011-04-14 08:45:54 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-14 08:45:54 --> Language Class Initialized
DEBUG - 2011-04-14 08:45:54 --> Loader Class Initialized
DEBUG - 2011-04-14 08:45:54 --> Controller Class Initialized
DEBUG - 2011-04-14 08:45:54 --> File loaded: application/views/splash/main.php
DEBUG - 2011-04-14 08:45:54 --> Helper loaded: url_helper
DEBUG - 2011-04-14 08:45:54 --> File loaded: application/views/common/header.php
DEBUG - 2011-04-14 08:45:54 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-04-14 08:45:54 --> File loaded: application/views/common/footer.php
DEBUG - 2011-04-14 08:45:54 --> File loaded: application/views/layout/main.php
DEBUG - 2011-04-14 08:45:54 --> Final output sent to browser
DEBUG - 2011-04-14 08:45:54 --> Total execution time: 0.5700
DEBUG - 2011-04-14 08:45:57 --> Config Class Initialized
DEBUG - 2011-04-14 08:45:57 --> Hooks Class Initialized
DEBUG - 2011-04-14 08:45:57 --> Utf8 Class Initialized
DEBUG - 2011-04-14 08:45:57 --> UTF-8 Support Enabled
DEBUG - 2011-04-14 08:45:57 --> URI Class Initialized
DEBUG - 2011-04-14 08:45:57 --> Router Class Initialized
DEBUG - 2011-04-14 08:45:57 --> Output Class Initialized
DEBUG - 2011-04-14 08:45:57 --> Input Class Initialized
DEBUG - 2011-04-14 08:45:57 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-14 08:45:57 --> Language Class Initialized
DEBUG - 2011-04-14 08:45:57 --> Loader Class Initialized
DEBUG - 2011-04-14 08:45:57 --> Controller Class Initialized
DEBUG - 2011-04-14 08:45:57 --> Config Class Initialized
DEBUG - 2011-04-14 08:45:57 --> Hooks Class Initialized
DEBUG - 2011-04-14 08:45:57 --> Utf8 Class Initialized
DEBUG - 2011-04-14 08:45:57 --> UTF-8 Support Enabled
DEBUG - 2011-04-14 08:45:57 --> URI Class Initialized
DEBUG - 2011-04-14 08:45:57 --> Router Class Initialized
DEBUG - 2011-04-14 08:45:57 --> Output Class Initialized
DEBUG - 2011-04-14 08:45:57 --> Input Class Initialized
DEBUG - 2011-04-14 08:45:57 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-14 08:45:57 --> Language Class Initialized
DEBUG - 2011-04-14 08:45:57 --> Loader Class Initialized
DEBUG - 2011-04-14 08:45:57 --> Controller Class Initialized
DEBUG - 2011-04-14 08:45:57 --> Model Class Initialized
DEBUG - 2011-04-14 08:45:57 --> Model Class Initialized
DEBUG - 2011-04-14 08:45:57 --> Model Class Initialized
ERROR - 2011-04-14 08:45:57 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-04-14 08:45:57 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-04-14 08:45:57 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-04-14 08:45:57 --> Model Class Initialized
DEBUG - 2011-04-14 08:45:57 --> Model Class Initialized
DEBUG - 2011-04-14 08:45:57 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-14 08:45:57 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-14 08:45:58 --> Database Driver Class Initialized
DEBUG - 2011-04-14 08:45:58 --> Database Driver Class Initialized
DEBUG - 2011-04-14 08:45:58 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-04-14 08:45:58 --> Helper loaded: url_helper
DEBUG - 2011-04-14 08:45:58 --> File loaded: application/views/common/header.php
DEBUG - 2011-04-14 08:45:58 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-04-14 08:45:58 --> File loaded: application/views/common/footer.php
DEBUG - 2011-04-14 08:45:58 --> File loaded: application/views/layout/main.php
DEBUG - 2011-04-14 08:45:58 --> Final output sent to browser
DEBUG - 2011-04-14 08:45:58 --> Total execution time: 0.3620
DEBUG - 2011-04-14 08:45:58 --> File loaded: application/views/table/main.php
DEBUG - 2011-04-14 08:45:58 --> Helper loaded: url_helper
DEBUG - 2011-04-14 08:45:58 --> File loaded: application/views/common/header.php
DEBUG - 2011-04-14 08:45:58 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-04-14 08:45:58 --> File loaded: application/views/common/footer.php
DEBUG - 2011-04-14 08:45:58 --> File loaded: application/views/layout/main.php
DEBUG - 2011-04-14 08:45:58 --> Final output sent to browser
DEBUG - 2011-04-14 08:45:58 --> Total execution time: 0.6475
DEBUG - 2011-04-14 08:55:13 --> Config Class Initialized
DEBUG - 2011-04-14 08:55:13 --> Hooks Class Initialized
DEBUG - 2011-04-14 08:55:13 --> Utf8 Class Initialized
DEBUG - 2011-04-14 08:55:13 --> UTF-8 Support Enabled
DEBUG - 2011-04-14 08:55:13 --> URI Class Initialized
DEBUG - 2011-04-14 08:55:13 --> Router Class Initialized
DEBUG - 2011-04-14 08:55:13 --> No URI present. Default controller set.
DEBUG - 2011-04-14 08:55:13 --> Output Class Initialized
DEBUG - 2011-04-14 08:55:13 --> Input Class Initialized
DEBUG - 2011-04-14 08:55:13 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-14 08:55:13 --> Language Class Initialized
DEBUG - 2011-04-14 08:55:13 --> Loader Class Initialized
DEBUG - 2011-04-14 08:55:13 --> Controller Class Initialized
DEBUG - 2011-04-14 08:55:13 --> File loaded: application/views/splash/main.php
DEBUG - 2011-04-14 08:55:13 --> Helper loaded: url_helper
DEBUG - 2011-04-14 08:55:13 --> File loaded: application/views/common/header.php
DEBUG - 2011-04-14 08:55:13 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-04-14 08:55:13 --> File loaded: application/views/common/footer.php
DEBUG - 2011-04-14 08:55:13 --> File loaded: application/views/layout/main.php
DEBUG - 2011-04-14 08:55:13 --> Final output sent to browser
DEBUG - 2011-04-14 08:55:13 --> Total execution time: 0.6263
DEBUG - 2011-04-14 08:55:17 --> Config Class Initialized
DEBUG - 2011-04-14 08:55:17 --> Hooks Class Initialized
DEBUG - 2011-04-14 08:55:17 --> Utf8 Class Initialized
DEBUG - 2011-04-14 08:55:17 --> UTF-8 Support Enabled
DEBUG - 2011-04-14 08:55:17 --> URI Class Initialized
DEBUG - 2011-04-14 08:55:17 --> Router Class Initialized
ERROR - 2011-04-14 08:55:17 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-04-14 09:45:19 --> Config Class Initialized
DEBUG - 2011-04-14 09:45:19 --> Hooks Class Initialized
DEBUG - 2011-04-14 09:45:19 --> Utf8 Class Initialized
DEBUG - 2011-04-14 09:45:19 --> UTF-8 Support Enabled
DEBUG - 2011-04-14 09:45:19 --> URI Class Initialized
DEBUG - 2011-04-14 09:45:19 --> Router Class Initialized
DEBUG - 2011-04-14 09:45:19 --> Output Class Initialized
DEBUG - 2011-04-14 09:45:19 --> Input Class Initialized
DEBUG - 2011-04-14 09:45:19 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-14 09:45:19 --> Language Class Initialized
DEBUG - 2011-04-14 09:45:19 --> Loader Class Initialized
DEBUG - 2011-04-14 09:45:19 --> Controller Class Initialized
DEBUG - 2011-04-14 09:45:19 --> Model Class Initialized
DEBUG - 2011-04-14 09:45:19 --> Model Class Initialized
DEBUG - 2011-04-14 09:45:19 --> Model Class Initialized
DEBUG - 2011-04-14 09:45:19 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-14 09:45:19 --> Database Driver Class Initialized
DEBUG - 2011-04-14 09:45:20 --> File loaded: application/views/table/main.php
DEBUG - 2011-04-14 09:45:20 --> Helper loaded: url_helper
DEBUG - 2011-04-14 09:45:20 --> File loaded: application/views/common/header.php
DEBUG - 2011-04-14 09:45:20 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-04-14 09:45:20 --> File loaded: application/views/common/footer.php
DEBUG - 2011-04-14 09:45:20 --> File loaded: application/views/layout/main.php
DEBUG - 2011-04-14 09:45:20 --> Final output sent to browser
DEBUG - 2011-04-14 09:45:20 --> Total execution time: 0.7515
DEBUG - 2011-04-14 09:45:22 --> Config Class Initialized
DEBUG - 2011-04-14 09:45:22 --> Hooks Class Initialized
DEBUG - 2011-04-14 09:45:22 --> Utf8 Class Initialized
DEBUG - 2011-04-14 09:45:22 --> UTF-8 Support Enabled
DEBUG - 2011-04-14 09:45:22 --> URI Class Initialized
DEBUG - 2011-04-14 09:45:22 --> Router Class Initialized
DEBUG - 2011-04-14 09:45:22 --> Output Class Initialized
DEBUG - 2011-04-14 09:45:22 --> Input Class Initialized
DEBUG - 2011-04-14 09:45:22 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-14 09:45:22 --> Language Class Initialized
DEBUG - 2011-04-14 09:45:22 --> Loader Class Initialized
DEBUG - 2011-04-14 09:45:22 --> Controller Class Initialized
ERROR - 2011-04-14 09:45:22 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-04-14 09:45:22 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-04-14 09:45:22 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-04-14 09:45:22 --> Model Class Initialized
DEBUG - 2011-04-14 09:45:22 --> Model Class Initialized
DEBUG - 2011-04-14 09:45:22 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-14 09:45:22 --> Database Driver Class Initialized
DEBUG - 2011-04-14 09:45:22 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-04-14 09:45:22 --> Helper loaded: url_helper
DEBUG - 2011-04-14 09:45:22 --> File loaded: application/views/common/header.php
DEBUG - 2011-04-14 09:45:22 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-04-14 09:45:22 --> File loaded: application/views/common/footer.php
DEBUG - 2011-04-14 09:45:22 --> File loaded: application/views/layout/main.php
DEBUG - 2011-04-14 09:45:22 --> Final output sent to browser
DEBUG - 2011-04-14 09:45:22 --> Total execution time: 0.2091
DEBUG - 2011-04-14 10:30:44 --> Config Class Initialized
DEBUG - 2011-04-14 10:30:44 --> Hooks Class Initialized
DEBUG - 2011-04-14 10:30:44 --> Utf8 Class Initialized
DEBUG - 2011-04-14 10:30:44 --> UTF-8 Support Enabled
DEBUG - 2011-04-14 10:30:44 --> URI Class Initialized
DEBUG - 2011-04-14 10:30:44 --> Router Class Initialized
ERROR - 2011-04-14 10:30:44 --> 404 Page Not Found --> robots.txt
DEBUG - 2011-04-14 10:30:44 --> Config Class Initialized
DEBUG - 2011-04-14 10:30:44 --> Hooks Class Initialized
DEBUG - 2011-04-14 10:30:44 --> Utf8 Class Initialized
DEBUG - 2011-04-14 10:30:44 --> UTF-8 Support Enabled
DEBUG - 2011-04-14 10:30:44 --> URI Class Initialized
DEBUG - 2011-04-14 10:30:44 --> Router Class Initialized
DEBUG - 2011-04-14 10:30:44 --> Output Class Initialized
DEBUG - 2011-04-14 10:30:44 --> Input Class Initialized
DEBUG - 2011-04-14 10:30:44 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-14 10:30:44 --> Language Class Initialized
DEBUG - 2011-04-14 10:30:44 --> Loader Class Initialized
DEBUG - 2011-04-14 10:30:44 --> Controller Class Initialized
DEBUG - 2011-04-14 10:30:44 --> Model Class Initialized
DEBUG - 2011-04-14 10:30:44 --> Model Class Initialized
DEBUG - 2011-04-14 10:30:44 --> Model Class Initialized
DEBUG - 2011-04-14 10:30:44 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-14 10:30:44 --> Database Driver Class Initialized
DEBUG - 2011-04-14 10:30:45 --> File loaded: application/views/table/main.php
DEBUG - 2011-04-14 10:30:45 --> Helper loaded: url_helper
DEBUG - 2011-04-14 10:30:45 --> File loaded: application/views/common/header.php
DEBUG - 2011-04-14 10:30:45 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-04-14 10:30:45 --> File loaded: application/views/common/footer.php
DEBUG - 2011-04-14 10:30:45 --> File loaded: application/views/layout/main.php
DEBUG - 2011-04-14 10:30:45 --> Final output sent to browser
DEBUG - 2011-04-14 10:30:45 --> Total execution time: 0.9182
DEBUG - 2011-04-14 10:31:15 --> Config Class Initialized
DEBUG - 2011-04-14 10:31:15 --> Hooks Class Initialized
DEBUG - 2011-04-14 10:31:15 --> Utf8 Class Initialized
DEBUG - 2011-04-14 10:31:15 --> UTF-8 Support Enabled
DEBUG - 2011-04-14 10:31:15 --> URI Class Initialized
DEBUG - 2011-04-14 10:31:15 --> Router Class Initialized
DEBUG - 2011-04-14 10:31:15 --> Output Class Initialized
DEBUG - 2011-04-14 10:31:15 --> Input Class Initialized
DEBUG - 2011-04-14 10:31:15 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-14 10:31:15 --> Language Class Initialized
DEBUG - 2011-04-14 10:31:15 --> Loader Class Initialized
DEBUG - 2011-04-14 10:31:15 --> Controller Class Initialized
ERROR - 2011-04-14 10:31:15 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-04-14 10:31:15 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-04-14 10:31:15 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-04-14 10:31:15 --> Model Class Initialized
DEBUG - 2011-04-14 10:31:15 --> Model Class Initialized
DEBUG - 2011-04-14 10:31:15 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-14 10:31:15 --> Database Driver Class Initialized
DEBUG - 2011-04-14 10:31:16 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-04-14 10:31:16 --> Helper loaded: url_helper
DEBUG - 2011-04-14 10:31:16 --> File loaded: application/views/common/header.php
DEBUG - 2011-04-14 10:31:16 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-04-14 10:31:16 --> File loaded: application/views/common/footer.php
DEBUG - 2011-04-14 10:31:16 --> File loaded: application/views/layout/main.php
DEBUG - 2011-04-14 10:31:16 --> Final output sent to browser
DEBUG - 2011-04-14 10:31:16 --> Total execution time: 0.1343
DEBUG - 2011-04-14 10:35:23 --> Config Class Initialized
DEBUG - 2011-04-14 10:35:23 --> Hooks Class Initialized
DEBUG - 2011-04-14 10:35:23 --> Utf8 Class Initialized
DEBUG - 2011-04-14 10:35:23 --> UTF-8 Support Enabled
DEBUG - 2011-04-14 10:35:23 --> URI Class Initialized
DEBUG - 2011-04-14 10:35:23 --> Router Class Initialized
DEBUG - 2011-04-14 10:35:23 --> No URI present. Default controller set.
DEBUG - 2011-04-14 10:35:23 --> Output Class Initialized
DEBUG - 2011-04-14 10:35:23 --> Input Class Initialized
DEBUG - 2011-04-14 10:35:23 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-14 10:35:23 --> Language Class Initialized
DEBUG - 2011-04-14 10:35:23 --> Loader Class Initialized
DEBUG - 2011-04-14 10:35:23 --> Controller Class Initialized
DEBUG - 2011-04-14 10:35:23 --> File loaded: application/views/splash/main.php
DEBUG - 2011-04-14 10:35:23 --> Helper loaded: url_helper
DEBUG - 2011-04-14 10:35:23 --> File loaded: application/views/common/header.php
DEBUG - 2011-04-14 10:35:23 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-04-14 10:35:23 --> File loaded: application/views/common/footer.php
DEBUG - 2011-04-14 10:35:23 --> File loaded: application/views/layout/main.php
DEBUG - 2011-04-14 10:35:23 --> Final output sent to browser
DEBUG - 2011-04-14 10:35:23 --> Total execution time: 0.4573
DEBUG - 2011-04-14 10:51:57 --> Config Class Initialized
DEBUG - 2011-04-14 10:51:57 --> Hooks Class Initialized
DEBUG - 2011-04-14 10:51:57 --> Utf8 Class Initialized
DEBUG - 2011-04-14 10:51:57 --> UTF-8 Support Enabled
DEBUG - 2011-04-14 10:51:57 --> URI Class Initialized
DEBUG - 2011-04-14 10:51:57 --> Router Class Initialized
DEBUG - 2011-04-14 10:51:57 --> No URI present. Default controller set.
DEBUG - 2011-04-14 10:51:57 --> Output Class Initialized
DEBUG - 2011-04-14 10:51:57 --> Input Class Initialized
DEBUG - 2011-04-14 10:51:57 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-14 10:51:57 --> Language Class Initialized
DEBUG - 2011-04-14 10:51:58 --> Loader Class Initialized
DEBUG - 2011-04-14 10:51:58 --> Controller Class Initialized
DEBUG - 2011-04-14 10:51:58 --> File loaded: application/views/splash/main.php
DEBUG - 2011-04-14 10:51:58 --> Helper loaded: url_helper
DEBUG - 2011-04-14 10:51:58 --> File loaded: application/views/common/header.php
DEBUG - 2011-04-14 10:51:58 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-04-14 10:51:58 --> File loaded: application/views/common/footer.php
DEBUG - 2011-04-14 10:51:58 --> File loaded: application/views/layout/main.php
DEBUG - 2011-04-14 10:51:58 --> Final output sent to browser
DEBUG - 2011-04-14 10:51:58 --> Total execution time: 0.3841
DEBUG - 2011-04-14 11:12:51 --> Config Class Initialized
DEBUG - 2011-04-14 11:12:51 --> Hooks Class Initialized
DEBUG - 2011-04-14 11:12:51 --> Utf8 Class Initialized
DEBUG - 2011-04-14 11:12:51 --> UTF-8 Support Enabled
DEBUG - 2011-04-14 11:12:51 --> URI Class Initialized
DEBUG - 2011-04-14 11:12:51 --> Router Class Initialized
DEBUG - 2011-04-14 11:12:51 --> No URI present. Default controller set.
DEBUG - 2011-04-14 11:12:51 --> Output Class Initialized
DEBUG - 2011-04-14 11:12:51 --> Input Class Initialized
DEBUG - 2011-04-14 11:12:51 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-14 11:12:51 --> Language Class Initialized
DEBUG - 2011-04-14 11:12:51 --> Loader Class Initialized
DEBUG - 2011-04-14 11:12:51 --> Controller Class Initialized
DEBUG - 2011-04-14 11:12:52 --> File loaded: application/views/splash/main.php
DEBUG - 2011-04-14 11:12:52 --> Helper loaded: url_helper
DEBUG - 2011-04-14 11:12:52 --> File loaded: application/views/common/header.php
DEBUG - 2011-04-14 11:12:52 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-04-14 11:12:52 --> File loaded: application/views/common/footer.php
DEBUG - 2011-04-14 11:12:52 --> File loaded: application/views/layout/main.php
DEBUG - 2011-04-14 11:12:52 --> Final output sent to browser
DEBUG - 2011-04-14 11:12:52 --> Total execution time: 0.6613
DEBUG - 2011-04-14 11:12:55 --> Config Class Initialized
DEBUG - 2011-04-14 11:12:55 --> Hooks Class Initialized
DEBUG - 2011-04-14 11:12:55 --> Utf8 Class Initialized
DEBUG - 2011-04-14 11:12:55 --> UTF-8 Support Enabled
DEBUG - 2011-04-14 11:12:55 --> URI Class Initialized
DEBUG - 2011-04-14 11:12:55 --> Router Class Initialized
ERROR - 2011-04-14 11:12:55 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-04-14 11:19:44 --> Config Class Initialized
DEBUG - 2011-04-14 11:19:44 --> Hooks Class Initialized
DEBUG - 2011-04-14 11:19:44 --> Utf8 Class Initialized
DEBUG - 2011-04-14 11:19:44 --> UTF-8 Support Enabled
DEBUG - 2011-04-14 11:19:44 --> URI Class Initialized
DEBUG - 2011-04-14 11:19:44 --> Router Class Initialized
DEBUG - 2011-04-14 11:19:44 --> Output Class Initialized
DEBUG - 2011-04-14 11:19:45 --> Input Class Initialized
DEBUG - 2011-04-14 11:19:45 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-14 11:19:45 --> Language Class Initialized
DEBUG - 2011-04-14 11:19:45 --> Loader Class Initialized
DEBUG - 2011-04-14 11:19:45 --> Controller Class Initialized
ERROR - 2011-04-14 11:19:45 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-04-14 11:19:45 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-04-14 11:19:45 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-04-14 11:19:45 --> Model Class Initialized
DEBUG - 2011-04-14 11:19:45 --> Model Class Initialized
DEBUG - 2011-04-14 11:19:45 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-14 11:19:45 --> Database Driver Class Initialized
DEBUG - 2011-04-14 11:19:45 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-04-14 11:19:45 --> Helper loaded: url_helper
DEBUG - 2011-04-14 11:19:45 --> File loaded: application/views/common/header.php
DEBUG - 2011-04-14 11:19:45 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-04-14 11:19:45 --> File loaded: application/views/common/footer.php
DEBUG - 2011-04-14 11:19:45 --> File loaded: application/views/layout/main.php
DEBUG - 2011-04-14 11:19:45 --> Final output sent to browser
DEBUG - 2011-04-14 11:19:45 --> Total execution time: 0.2979
DEBUG - 2011-04-14 11:19:47 --> Config Class Initialized
DEBUG - 2011-04-14 11:19:47 --> Hooks Class Initialized
DEBUG - 2011-04-14 11:19:47 --> Utf8 Class Initialized
DEBUG - 2011-04-14 11:19:47 --> UTF-8 Support Enabled
DEBUG - 2011-04-14 11:19:47 --> URI Class Initialized
DEBUG - 2011-04-14 11:19:47 --> Router Class Initialized
DEBUG - 2011-04-14 11:19:47 --> Output Class Initialized
DEBUG - 2011-04-14 11:19:47 --> Input Class Initialized
DEBUG - 2011-04-14 11:19:47 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-14 11:19:47 --> Language Class Initialized
DEBUG - 2011-04-14 11:19:47 --> Loader Class Initialized
DEBUG - 2011-04-14 11:19:47 --> Controller Class Initialized
DEBUG - 2011-04-14 11:19:47 --> Model Class Initialized
DEBUG - 2011-04-14 11:19:47 --> Model Class Initialized
DEBUG - 2011-04-14 11:19:47 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-14 11:19:47 --> Database Driver Class Initialized
DEBUG - 2011-04-14 11:19:48 --> Config Class Initialized
DEBUG - 2011-04-14 11:19:48 --> Hooks Class Initialized
DEBUG - 2011-04-14 11:19:48 --> Utf8 Class Initialized
DEBUG - 2011-04-14 11:19:48 --> UTF-8 Support Enabled
DEBUG - 2011-04-14 11:19:48 --> Final output sent to browser
DEBUG - 2011-04-14 11:19:48 --> Total execution time: 1.3133
DEBUG - 2011-04-14 11:19:48 --> URI Class Initialized
DEBUG - 2011-04-14 11:19:48 --> Router Class Initialized
DEBUG - 2011-04-14 11:19:48 --> Output Class Initialized
DEBUG - 2011-04-14 11:19:48 --> Input Class Initialized
DEBUG - 2011-04-14 11:19:48 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-14 11:19:48 --> Language Class Initialized
DEBUG - 2011-04-14 11:19:48 --> Loader Class Initialized
DEBUG - 2011-04-14 11:19:48 --> Controller Class Initialized
ERROR - 2011-04-14 11:19:48 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-04-14 11:19:48 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-04-14 11:19:48 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-04-14 11:19:48 --> Model Class Initialized
DEBUG - 2011-04-14 11:19:48 --> Model Class Initialized
DEBUG - 2011-04-14 11:19:48 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-14 11:19:48 --> Database Driver Class Initialized
DEBUG - 2011-04-14 11:19:48 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-04-14 11:19:48 --> Helper loaded: url_helper
DEBUG - 2011-04-14 11:19:48 --> File loaded: application/views/common/header.php
DEBUG - 2011-04-14 11:19:48 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-04-14 11:19:48 --> File loaded: application/views/common/footer.php
DEBUG - 2011-04-14 11:19:48 --> File loaded: application/views/layout/main.php
DEBUG - 2011-04-14 11:19:48 --> Final output sent to browser
DEBUG - 2011-04-14 11:19:48 --> Total execution time: 0.1860
DEBUG - 2011-04-14 11:19:50 --> Config Class Initialized
DEBUG - 2011-04-14 11:19:53 --> Hooks Class Initialized
DEBUG - 2011-04-14 11:19:53 --> Utf8 Class Initialized
DEBUG - 2011-04-14 11:19:53 --> UTF-8 Support Enabled
DEBUG - 2011-04-14 11:19:53 --> URI Class Initialized
DEBUG - 2011-04-14 11:19:53 --> Router Class Initialized
ERROR - 2011-04-14 11:19:53 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-04-14 11:19:54 --> Config Class Initialized
DEBUG - 2011-04-14 11:19:54 --> Hooks Class Initialized
DEBUG - 2011-04-14 11:19:54 --> Utf8 Class Initialized
DEBUG - 2011-04-14 11:19:54 --> UTF-8 Support Enabled
DEBUG - 2011-04-14 11:19:54 --> URI Class Initialized
DEBUG - 2011-04-14 11:19:54 --> Router Class Initialized
ERROR - 2011-04-14 11:19:54 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-04-14 11:19:55 --> Config Class Initialized
DEBUG - 2011-04-14 11:19:55 --> Hooks Class Initialized
DEBUG - 2011-04-14 11:19:55 --> Utf8 Class Initialized
DEBUG - 2011-04-14 11:19:55 --> UTF-8 Support Enabled
DEBUG - 2011-04-14 11:19:55 --> URI Class Initialized
DEBUG - 2011-04-14 11:19:55 --> Router Class Initialized
ERROR - 2011-04-14 11:19:55 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-04-14 11:19:57 --> Config Class Initialized
DEBUG - 2011-04-14 11:19:57 --> Hooks Class Initialized
DEBUG - 2011-04-14 11:19:57 --> Utf8 Class Initialized
DEBUG - 2011-04-14 11:19:57 --> UTF-8 Support Enabled
DEBUG - 2011-04-14 11:19:57 --> URI Class Initialized
DEBUG - 2011-04-14 11:19:57 --> Router Class Initialized
DEBUG - 2011-04-14 11:19:57 --> Output Class Initialized
DEBUG - 2011-04-14 11:19:57 --> Input Class Initialized
DEBUG - 2011-04-14 11:19:57 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-14 11:19:57 --> Language Class Initialized
DEBUG - 2011-04-14 11:19:57 --> Loader Class Initialized
DEBUG - 2011-04-14 11:19:57 --> Controller Class Initialized
ERROR - 2011-04-14 11:19:57 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-04-14 11:19:57 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-04-14 11:19:57 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-04-14 11:19:57 --> Model Class Initialized
DEBUG - 2011-04-14 11:19:57 --> Model Class Initialized
DEBUG - 2011-04-14 11:19:57 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-14 11:19:57 --> Database Driver Class Initialized
DEBUG - 2011-04-14 11:19:57 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-04-14 11:19:57 --> Helper loaded: url_helper
DEBUG - 2011-04-14 11:19:57 --> File loaded: application/views/common/header.php
DEBUG - 2011-04-14 11:19:57 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-04-14 11:19:57 --> File loaded: application/views/common/footer.php
DEBUG - 2011-04-14 11:19:57 --> File loaded: application/views/layout/main.php
DEBUG - 2011-04-14 11:19:57 --> Final output sent to browser
DEBUG - 2011-04-14 11:19:57 --> Total execution time: 0.0353
DEBUG - 2011-04-14 11:19:58 --> Config Class Initialized
DEBUG - 2011-04-14 11:19:58 --> Hooks Class Initialized
DEBUG - 2011-04-14 11:19:58 --> Utf8 Class Initialized
DEBUG - 2011-04-14 11:19:58 --> UTF-8 Support Enabled
DEBUG - 2011-04-14 11:19:58 --> URI Class Initialized
DEBUG - 2011-04-14 11:19:58 --> Router Class Initialized
DEBUG - 2011-04-14 11:19:58 --> Output Class Initialized
DEBUG - 2011-04-14 11:19:58 --> Input Class Initialized
DEBUG - 2011-04-14 11:19:58 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-14 11:19:58 --> Language Class Initialized
DEBUG - 2011-04-14 11:19:58 --> Loader Class Initialized
DEBUG - 2011-04-14 11:19:58 --> Controller Class Initialized
DEBUG - 2011-04-14 11:19:58 --> Model Class Initialized
DEBUG - 2011-04-14 11:19:58 --> Model Class Initialized
DEBUG - 2011-04-14 11:19:58 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-14 11:19:58 --> Database Driver Class Initialized
DEBUG - 2011-04-14 11:19:58 --> Final output sent to browser
DEBUG - 2011-04-14 11:19:58 --> Total execution time: 0.7471
DEBUG - 2011-04-14 11:41:51 --> Config Class Initialized
DEBUG - 2011-04-14 11:41:51 --> Hooks Class Initialized
DEBUG - 2011-04-14 11:41:51 --> Utf8 Class Initialized
DEBUG - 2011-04-14 11:41:51 --> UTF-8 Support Enabled
DEBUG - 2011-04-14 11:41:51 --> URI Class Initialized
DEBUG - 2011-04-14 11:41:51 --> Router Class Initialized
DEBUG - 2011-04-14 11:41:51 --> Output Class Initialized
DEBUG - 2011-04-14 11:41:51 --> Input Class Initialized
DEBUG - 2011-04-14 11:41:51 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-14 11:41:51 --> Language Class Initialized
DEBUG - 2011-04-14 11:41:51 --> Loader Class Initialized
DEBUG - 2011-04-14 11:41:51 --> Controller Class Initialized
ERROR - 2011-04-14 11:41:51 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-04-14 11:41:51 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-04-14 11:41:51 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-04-14 11:41:51 --> Model Class Initialized
DEBUG - 2011-04-14 11:41:51 --> Model Class Initialized
DEBUG - 2011-04-14 11:41:51 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-14 11:41:51 --> Database Driver Class Initialized
DEBUG - 2011-04-14 11:41:51 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-04-14 11:41:51 --> Helper loaded: url_helper
DEBUG - 2011-04-14 11:41:51 --> File loaded: application/views/common/header.php
DEBUG - 2011-04-14 11:41:51 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-04-14 11:41:51 --> File loaded: application/views/common/footer.php
DEBUG - 2011-04-14 11:41:51 --> File loaded: application/views/layout/main.php
DEBUG - 2011-04-14 11:41:51 --> Final output sent to browser
DEBUG - 2011-04-14 11:41:51 --> Total execution time: 0.4512
DEBUG - 2011-04-14 11:42:02 --> Config Class Initialized
DEBUG - 2011-04-14 11:42:02 --> Hooks Class Initialized
DEBUG - 2011-04-14 11:42:02 --> Utf8 Class Initialized
DEBUG - 2011-04-14 11:42:02 --> UTF-8 Support Enabled
DEBUG - 2011-04-14 11:42:02 --> URI Class Initialized
DEBUG - 2011-04-14 11:42:02 --> Router Class Initialized
DEBUG - 2011-04-14 11:42:02 --> Output Class Initialized
DEBUG - 2011-04-14 11:42:02 --> Input Class Initialized
DEBUG - 2011-04-14 11:42:02 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-14 11:42:02 --> Language Class Initialized
DEBUG - 2011-04-14 11:42:02 --> Loader Class Initialized
DEBUG - 2011-04-14 11:42:02 --> Controller Class Initialized
DEBUG - 2011-04-14 11:42:02 --> Model Class Initialized
DEBUG - 2011-04-14 11:42:02 --> Model Class Initialized
DEBUG - 2011-04-14 11:42:02 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-14 11:42:02 --> Database Driver Class Initialized
DEBUG - 2011-04-14 11:42:04 --> Final output sent to browser
DEBUG - 2011-04-14 11:42:04 --> Total execution time: 1.8715
DEBUG - 2011-04-14 11:42:07 --> Config Class Initialized
DEBUG - 2011-04-14 11:42:07 --> Hooks Class Initialized
DEBUG - 2011-04-14 11:42:07 --> Utf8 Class Initialized
DEBUG - 2011-04-14 11:42:07 --> UTF-8 Support Enabled
DEBUG - 2011-04-14 11:42:07 --> URI Class Initialized
DEBUG - 2011-04-14 11:42:07 --> Router Class Initialized
ERROR - 2011-04-14 11:42:07 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-04-14 11:43:08 --> Config Class Initialized
DEBUG - 2011-04-14 11:43:08 --> Hooks Class Initialized
DEBUG - 2011-04-14 11:43:08 --> Utf8 Class Initialized
DEBUG - 2011-04-14 11:43:08 --> UTF-8 Support Enabled
DEBUG - 2011-04-14 11:43:08 --> URI Class Initialized
DEBUG - 2011-04-14 11:43:08 --> Router Class Initialized
DEBUG - 2011-04-14 11:43:08 --> Output Class Initialized
DEBUG - 2011-04-14 11:43:08 --> Input Class Initialized
DEBUG - 2011-04-14 11:43:08 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-14 11:43:08 --> Language Class Initialized
DEBUG - 2011-04-14 11:43:08 --> Loader Class Initialized
DEBUG - 2011-04-14 11:43:08 --> Controller Class Initialized
ERROR - 2011-04-14 11:43:08 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-04-14 11:43:08 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-04-14 11:43:08 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-04-14 11:43:08 --> Model Class Initialized
DEBUG - 2011-04-14 11:43:08 --> Model Class Initialized
DEBUG - 2011-04-14 11:43:08 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-14 11:43:08 --> Database Driver Class Initialized
DEBUG - 2011-04-14 11:43:08 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-04-14 11:43:08 --> Helper loaded: url_helper
DEBUG - 2011-04-14 11:43:08 --> File loaded: application/views/common/header.php
DEBUG - 2011-04-14 11:43:08 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-04-14 11:43:08 --> File loaded: application/views/common/footer.php
DEBUG - 2011-04-14 11:43:08 --> File loaded: application/views/layout/main.php
DEBUG - 2011-04-14 11:43:08 --> Final output sent to browser
DEBUG - 2011-04-14 11:43:08 --> Total execution time: 0.0636
DEBUG - 2011-04-14 11:43:10 --> Config Class Initialized
DEBUG - 2011-04-14 11:43:10 --> Hooks Class Initialized
DEBUG - 2011-04-14 11:43:10 --> Utf8 Class Initialized
DEBUG - 2011-04-14 11:43:10 --> UTF-8 Support Enabled
DEBUG - 2011-04-14 11:43:10 --> URI Class Initialized
DEBUG - 2011-04-14 11:43:10 --> Router Class Initialized
DEBUG - 2011-04-14 11:43:10 --> Output Class Initialized
DEBUG - 2011-04-14 11:43:10 --> Input Class Initialized
DEBUG - 2011-04-14 11:43:10 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-14 11:43:10 --> Language Class Initialized
DEBUG - 2011-04-14 11:43:10 --> Loader Class Initialized
DEBUG - 2011-04-14 11:43:10 --> Controller Class Initialized
DEBUG - 2011-04-14 11:43:10 --> Model Class Initialized
DEBUG - 2011-04-14 11:43:10 --> Model Class Initialized
DEBUG - 2011-04-14 11:43:10 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-14 11:43:10 --> Database Driver Class Initialized
DEBUG - 2011-04-14 11:43:11 --> Final output sent to browser
DEBUG - 2011-04-14 11:43:11 --> Total execution time: 0.6416
DEBUG - 2011-04-14 11:43:11 --> Config Class Initialized
DEBUG - 2011-04-14 11:43:11 --> Hooks Class Initialized
DEBUG - 2011-04-14 11:43:11 --> Utf8 Class Initialized
DEBUG - 2011-04-14 11:43:11 --> UTF-8 Support Enabled
DEBUG - 2011-04-14 11:43:11 --> URI Class Initialized
DEBUG - 2011-04-14 11:43:11 --> Router Class Initialized
ERROR - 2011-04-14 11:43:11 --> 404 Page Not Found --> robots.txt
DEBUG - 2011-04-14 11:43:11 --> Config Class Initialized
DEBUG - 2011-04-14 11:43:11 --> Hooks Class Initialized
DEBUG - 2011-04-14 11:43:11 --> Utf8 Class Initialized
DEBUG - 2011-04-14 11:43:11 --> UTF-8 Support Enabled
DEBUG - 2011-04-14 11:43:11 --> URI Class Initialized
DEBUG - 2011-04-14 11:43:11 --> Router Class Initialized
DEBUG - 2011-04-14 11:43:11 --> Output Class Initialized
DEBUG - 2011-04-14 11:43:11 --> Input Class Initialized
DEBUG - 2011-04-14 11:43:11 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-14 11:43:11 --> Language Class Initialized
DEBUG - 2011-04-14 11:43:11 --> Loader Class Initialized
DEBUG - 2011-04-14 11:43:11 --> Controller Class Initialized
ERROR - 2011-04-14 11:43:11 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-04-14 11:43:11 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-04-14 11:43:11 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-04-14 11:43:11 --> Model Class Initialized
DEBUG - 2011-04-14 11:43:11 --> Model Class Initialized
DEBUG - 2011-04-14 11:43:11 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-14 11:43:11 --> Database Driver Class Initialized
DEBUG - 2011-04-14 11:43:11 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-04-14 11:43:11 --> Helper loaded: url_helper
DEBUG - 2011-04-14 11:43:11 --> File loaded: application/views/common/header.php
DEBUG - 2011-04-14 11:43:11 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-04-14 11:43:11 --> File loaded: application/views/common/footer.php
DEBUG - 2011-04-14 11:43:11 --> File loaded: application/views/layout/main.php
DEBUG - 2011-04-14 11:43:11 --> Final output sent to browser
DEBUG - 2011-04-14 11:43:11 --> Total execution time: 0.0345
DEBUG - 2011-04-14 11:43:13 --> Config Class Initialized
DEBUG - 2011-04-14 11:43:13 --> Hooks Class Initialized
DEBUG - 2011-04-14 11:43:13 --> Utf8 Class Initialized
DEBUG - 2011-04-14 11:43:13 --> UTF-8 Support Enabled
DEBUG - 2011-04-14 11:43:13 --> URI Class Initialized
DEBUG - 2011-04-14 11:43:13 --> Router Class Initialized
ERROR - 2011-04-14 11:43:13 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-04-14 11:43:49 --> Config Class Initialized
DEBUG - 2011-04-14 11:43:49 --> Hooks Class Initialized
DEBUG - 2011-04-14 11:43:49 --> Utf8 Class Initialized
DEBUG - 2011-04-14 11:43:49 --> UTF-8 Support Enabled
DEBUG - 2011-04-14 11:43:49 --> URI Class Initialized
DEBUG - 2011-04-14 11:43:49 --> Router Class Initialized
DEBUG - 2011-04-14 11:43:49 --> Output Class Initialized
DEBUG - 2011-04-14 11:43:49 --> Input Class Initialized
DEBUG - 2011-04-14 11:43:49 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-14 11:43:49 --> Language Class Initialized
DEBUG - 2011-04-14 11:43:49 --> Loader Class Initialized
DEBUG - 2011-04-14 11:43:49 --> Controller Class Initialized
ERROR - 2011-04-14 11:43:49 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-04-14 11:43:49 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-04-14 11:43:49 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-04-14 11:43:49 --> Model Class Initialized
DEBUG - 2011-04-14 11:43:49 --> Model Class Initialized
DEBUG - 2011-04-14 11:43:49 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-14 11:43:49 --> Database Driver Class Initialized
DEBUG - 2011-04-14 11:43:49 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-04-14 11:43:49 --> Helper loaded: url_helper
DEBUG - 2011-04-14 11:43:49 --> File loaded: application/views/common/header.php
DEBUG - 2011-04-14 11:43:49 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-04-14 11:43:49 --> File loaded: application/views/common/footer.php
DEBUG - 2011-04-14 11:43:49 --> File loaded: application/views/layout/main.php
DEBUG - 2011-04-14 11:43:49 --> Final output sent to browser
DEBUG - 2011-04-14 11:43:49 --> Total execution time: 0.0618
DEBUG - 2011-04-14 11:43:51 --> Config Class Initialized
DEBUG - 2011-04-14 11:43:51 --> Hooks Class Initialized
DEBUG - 2011-04-14 11:43:51 --> Utf8 Class Initialized
DEBUG - 2011-04-14 11:43:51 --> UTF-8 Support Enabled
DEBUG - 2011-04-14 11:43:51 --> URI Class Initialized
DEBUG - 2011-04-14 11:43:51 --> Router Class Initialized
DEBUG - 2011-04-14 11:43:51 --> Output Class Initialized
DEBUG - 2011-04-14 11:43:51 --> Input Class Initialized
DEBUG - 2011-04-14 11:43:51 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-14 11:43:51 --> Language Class Initialized
DEBUG - 2011-04-14 11:43:51 --> Loader Class Initialized
DEBUG - 2011-04-14 11:43:51 --> Controller Class Initialized
ERROR - 2011-04-14 11:43:51 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-04-14 11:43:51 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-04-14 11:43:51 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-04-14 11:43:51 --> Model Class Initialized
DEBUG - 2011-04-14 11:43:51 --> Model Class Initialized
DEBUG - 2011-04-14 11:43:51 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-14 11:43:51 --> Database Driver Class Initialized
DEBUG - 2011-04-14 11:43:51 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-04-14 11:43:51 --> Helper loaded: url_helper
DEBUG - 2011-04-14 11:43:51 --> File loaded: application/views/common/header.php
DEBUG - 2011-04-14 11:43:51 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-04-14 11:43:51 --> File loaded: application/views/common/footer.php
DEBUG - 2011-04-14 11:43:51 --> File loaded: application/views/layout/main.php
DEBUG - 2011-04-14 11:43:51 --> Final output sent to browser
DEBUG - 2011-04-14 11:43:51 --> Total execution time: 0.0384
DEBUG - 2011-04-14 11:43:51 --> Config Class Initialized
DEBUG - 2011-04-14 11:43:51 --> Hooks Class Initialized
DEBUG - 2011-04-14 11:43:51 --> Utf8 Class Initialized
DEBUG - 2011-04-14 11:43:51 --> UTF-8 Support Enabled
DEBUG - 2011-04-14 11:43:51 --> URI Class Initialized
DEBUG - 2011-04-14 11:43:51 --> Router Class Initialized
DEBUG - 2011-04-14 11:43:51 --> Output Class Initialized
DEBUG - 2011-04-14 11:43:51 --> Input Class Initialized
DEBUG - 2011-04-14 11:43:51 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-14 11:43:51 --> Language Class Initialized
DEBUG - 2011-04-14 11:43:51 --> Loader Class Initialized
DEBUG - 2011-04-14 11:43:51 --> Controller Class Initialized
DEBUG - 2011-04-14 11:43:51 --> Model Class Initialized
DEBUG - 2011-04-14 11:43:51 --> Model Class Initialized
DEBUG - 2011-04-14 11:43:51 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-14 11:43:51 --> Database Driver Class Initialized
DEBUG - 2011-04-14 11:43:52 --> Final output sent to browser
DEBUG - 2011-04-14 11:43:52 --> Total execution time: 0.5057
DEBUG - 2011-04-14 11:43:54 --> Config Class Initialized
DEBUG - 2011-04-14 11:43:54 --> Hooks Class Initialized
DEBUG - 2011-04-14 11:43:54 --> Utf8 Class Initialized
DEBUG - 2011-04-14 11:43:54 --> UTF-8 Support Enabled
DEBUG - 2011-04-14 11:43:54 --> URI Class Initialized
DEBUG - 2011-04-14 11:43:54 --> Router Class Initialized
ERROR - 2011-04-14 11:43:54 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-04-14 11:45:21 --> Config Class Initialized
DEBUG - 2011-04-14 11:45:21 --> Hooks Class Initialized
DEBUG - 2011-04-14 11:45:21 --> Utf8 Class Initialized
DEBUG - 2011-04-14 11:45:21 --> UTF-8 Support Enabled
DEBUG - 2011-04-14 11:45:21 --> URI Class Initialized
DEBUG - 2011-04-14 11:45:21 --> Router Class Initialized
DEBUG - 2011-04-14 11:45:21 --> Output Class Initialized
DEBUG - 2011-04-14 11:45:21 --> Input Class Initialized
DEBUG - 2011-04-14 11:45:21 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-14 11:45:21 --> Language Class Initialized
DEBUG - 2011-04-14 11:45:21 --> Loader Class Initialized
DEBUG - 2011-04-14 11:45:21 --> Controller Class Initialized
ERROR - 2011-04-14 11:45:21 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-04-14 11:45:21 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-04-14 11:45:21 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-04-14 11:45:21 --> Model Class Initialized
DEBUG - 2011-04-14 11:45:21 --> Model Class Initialized
DEBUG - 2011-04-14 11:45:21 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-14 11:45:21 --> Database Driver Class Initialized
DEBUG - 2011-04-14 11:45:21 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-04-14 11:45:21 --> Helper loaded: url_helper
DEBUG - 2011-04-14 11:45:21 --> File loaded: application/views/common/header.php
DEBUG - 2011-04-14 11:45:21 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-04-14 11:45:21 --> File loaded: application/views/common/footer.php
DEBUG - 2011-04-14 11:45:21 --> File loaded: application/views/layout/main.php
DEBUG - 2011-04-14 11:45:21 --> Final output sent to browser
DEBUG - 2011-04-14 11:45:21 --> Total execution time: 0.2450
DEBUG - 2011-04-14 11:45:24 --> Config Class Initialized
DEBUG - 2011-04-14 11:45:24 --> Hooks Class Initialized
DEBUG - 2011-04-14 11:45:24 --> Utf8 Class Initialized
DEBUG - 2011-04-14 11:45:24 --> UTF-8 Support Enabled
DEBUG - 2011-04-14 11:45:24 --> URI Class Initialized
DEBUG - 2011-04-14 11:45:24 --> Router Class Initialized
DEBUG - 2011-04-14 11:45:24 --> Output Class Initialized
DEBUG - 2011-04-14 11:45:24 --> Input Class Initialized
DEBUG - 2011-04-14 11:45:24 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-14 11:45:24 --> Language Class Initialized
DEBUG - 2011-04-14 11:45:24 --> Loader Class Initialized
DEBUG - 2011-04-14 11:45:24 --> Controller Class Initialized
DEBUG - 2011-04-14 11:45:24 --> Model Class Initialized
DEBUG - 2011-04-14 11:45:24 --> Model Class Initialized
DEBUG - 2011-04-14 11:45:24 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-14 11:45:24 --> Database Driver Class Initialized
DEBUG - 2011-04-14 11:45:25 --> Final output sent to browser
DEBUG - 2011-04-14 11:45:25 --> Total execution time: 0.9405
DEBUG - 2011-04-14 11:45:25 --> Config Class Initialized
DEBUG - 2011-04-14 11:45:25 --> Hooks Class Initialized
DEBUG - 2011-04-14 11:45:25 --> Utf8 Class Initialized
DEBUG - 2011-04-14 11:45:25 --> UTF-8 Support Enabled
DEBUG - 2011-04-14 11:45:25 --> URI Class Initialized
DEBUG - 2011-04-14 11:45:25 --> Router Class Initialized
DEBUG - 2011-04-14 11:45:26 --> No URI present. Default controller set.
DEBUG - 2011-04-14 11:45:26 --> Output Class Initialized
DEBUG - 2011-04-14 11:45:26 --> Input Class Initialized
DEBUG - 2011-04-14 11:45:26 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-14 11:45:26 --> Language Class Initialized
DEBUG - 2011-04-14 11:45:27 --> Loader Class Initialized
DEBUG - 2011-04-14 11:45:27 --> Controller Class Initialized
DEBUG - 2011-04-14 11:45:27 --> File loaded: application/views/splash/main.php
DEBUG - 2011-04-14 11:45:27 --> Helper loaded: url_helper
DEBUG - 2011-04-14 11:45:27 --> File loaded: application/views/common/header.php
DEBUG - 2011-04-14 11:45:27 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-04-14 11:45:27 --> File loaded: application/views/common/footer.php
DEBUG - 2011-04-14 11:45:27 --> File loaded: application/views/layout/main.php
DEBUG - 2011-04-14 11:45:27 --> Final output sent to browser
DEBUG - 2011-04-14 11:45:27 --> Total execution time: 1.9677
DEBUG - 2011-04-14 11:45:28 --> Config Class Initialized
DEBUG - 2011-04-14 11:45:28 --> Hooks Class Initialized
DEBUG - 2011-04-14 11:45:28 --> Utf8 Class Initialized
DEBUG - 2011-04-14 11:45:28 --> UTF-8 Support Enabled
DEBUG - 2011-04-14 11:45:28 --> URI Class Initialized
DEBUG - 2011-04-14 11:45:28 --> Router Class Initialized
ERROR - 2011-04-14 11:45:28 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-04-14 11:45:54 --> Config Class Initialized
DEBUG - 2011-04-14 11:45:54 --> Hooks Class Initialized
DEBUG - 2011-04-14 11:45:54 --> Utf8 Class Initialized
DEBUG - 2011-04-14 11:45:54 --> UTF-8 Support Enabled
DEBUG - 2011-04-14 11:45:54 --> URI Class Initialized
DEBUG - 2011-04-14 11:45:54 --> Router Class Initialized
ERROR - 2011-04-14 11:45:54 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-04-14 11:45:56 --> Config Class Initialized
DEBUG - 2011-04-14 11:45:56 --> Hooks Class Initialized
DEBUG - 2011-04-14 11:45:56 --> Utf8 Class Initialized
DEBUG - 2011-04-14 11:45:56 --> UTF-8 Support Enabled
DEBUG - 2011-04-14 11:45:56 --> URI Class Initialized
DEBUG - 2011-04-14 11:45:56 --> Router Class Initialized
ERROR - 2011-04-14 11:45:56 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-04-14 11:46:06 --> Config Class Initialized
DEBUG - 2011-04-14 11:46:06 --> Hooks Class Initialized
DEBUG - 2011-04-14 11:46:06 --> Utf8 Class Initialized
DEBUG - 2011-04-14 11:46:06 --> UTF-8 Support Enabled
DEBUG - 2011-04-14 11:46:06 --> URI Class Initialized
DEBUG - 2011-04-14 11:46:06 --> Router Class Initialized
DEBUG - 2011-04-14 11:46:06 --> Output Class Initialized
DEBUG - 2011-04-14 11:46:06 --> Input Class Initialized
DEBUG - 2011-04-14 11:46:06 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-14 11:46:06 --> Language Class Initialized
DEBUG - 2011-04-14 11:46:06 --> Loader Class Initialized
DEBUG - 2011-04-14 11:46:06 --> Controller Class Initialized
ERROR - 2011-04-14 11:46:06 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-04-14 11:46:06 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-04-14 11:46:06 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-04-14 11:46:06 --> Model Class Initialized
DEBUG - 2011-04-14 11:46:06 --> Model Class Initialized
DEBUG - 2011-04-14 11:46:06 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-14 11:46:06 --> Database Driver Class Initialized
DEBUG - 2011-04-14 11:46:06 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-04-14 11:46:06 --> Helper loaded: url_helper
DEBUG - 2011-04-14 11:46:06 --> File loaded: application/views/common/header.php
DEBUG - 2011-04-14 11:46:06 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-04-14 11:46:06 --> File loaded: application/views/common/footer.php
DEBUG - 2011-04-14 11:46:06 --> File loaded: application/views/layout/main.php
DEBUG - 2011-04-14 11:46:06 --> Final output sent to browser
DEBUG - 2011-04-14 11:46:06 --> Total execution time: 0.1625
DEBUG - 2011-04-14 11:46:08 --> Config Class Initialized
DEBUG - 2011-04-14 11:46:08 --> Hooks Class Initialized
DEBUG - 2011-04-14 11:46:08 --> Utf8 Class Initialized
DEBUG - 2011-04-14 11:46:08 --> UTF-8 Support Enabled
DEBUG - 2011-04-14 11:46:08 --> URI Class Initialized
DEBUG - 2011-04-14 11:46:08 --> Router Class Initialized
DEBUG - 2011-04-14 11:46:08 --> Output Class Initialized
DEBUG - 2011-04-14 11:46:08 --> Input Class Initialized
DEBUG - 2011-04-14 11:46:08 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-14 11:46:08 --> Language Class Initialized
DEBUG - 2011-04-14 11:46:08 --> Loader Class Initialized
DEBUG - 2011-04-14 11:46:08 --> Controller Class Initialized
DEBUG - 2011-04-14 11:46:08 --> Model Class Initialized
DEBUG - 2011-04-14 11:46:08 --> Model Class Initialized
DEBUG - 2011-04-14 11:46:08 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-14 11:46:08 --> Database Driver Class Initialized
DEBUG - 2011-04-14 11:46:09 --> Final output sent to browser
DEBUG - 2011-04-14 11:46:09 --> Total execution time: 0.8322
DEBUG - 2011-04-14 11:46:12 --> Config Class Initialized
DEBUG - 2011-04-14 11:46:12 --> Hooks Class Initialized
DEBUG - 2011-04-14 11:46:12 --> Utf8 Class Initialized
DEBUG - 2011-04-14 11:46:12 --> UTF-8 Support Enabled
DEBUG - 2011-04-14 11:46:12 --> URI Class Initialized
DEBUG - 2011-04-14 11:46:12 --> Router Class Initialized
ERROR - 2011-04-14 11:46:13 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-04-14 11:46:50 --> Config Class Initialized
DEBUG - 2011-04-14 11:46:50 --> Hooks Class Initialized
DEBUG - 2011-04-14 11:46:50 --> Utf8 Class Initialized
DEBUG - 2011-04-14 11:46:50 --> UTF-8 Support Enabled
DEBUG - 2011-04-14 11:46:50 --> URI Class Initialized
DEBUG - 2011-04-14 11:46:50 --> Router Class Initialized
DEBUG - 2011-04-14 11:46:50 --> Output Class Initialized
DEBUG - 2011-04-14 11:46:50 --> Input Class Initialized
DEBUG - 2011-04-14 11:46:50 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-14 11:46:50 --> Language Class Initialized
DEBUG - 2011-04-14 11:46:50 --> Loader Class Initialized
DEBUG - 2011-04-14 11:46:50 --> Controller Class Initialized
ERROR - 2011-04-14 11:46:50 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-04-14 11:46:50 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-04-14 11:46:50 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-04-14 11:46:50 --> Model Class Initialized
DEBUG - 2011-04-14 11:46:50 --> Model Class Initialized
DEBUG - 2011-04-14 11:46:50 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-14 11:46:50 --> Database Driver Class Initialized
DEBUG - 2011-04-14 11:46:50 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-04-14 11:46:50 --> Helper loaded: url_helper
DEBUG - 2011-04-14 11:46:50 --> File loaded: application/views/common/header.php
DEBUG - 2011-04-14 11:46:50 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-04-14 11:46:50 --> File loaded: application/views/common/footer.php
DEBUG - 2011-04-14 11:46:50 --> File loaded: application/views/layout/main.php
DEBUG - 2011-04-14 11:46:50 --> Final output sent to browser
DEBUG - 2011-04-14 11:46:50 --> Total execution time: 0.1240
DEBUG - 2011-04-14 11:46:53 --> Config Class Initialized
DEBUG - 2011-04-14 11:46:53 --> Hooks Class Initialized
DEBUG - 2011-04-14 11:46:53 --> Utf8 Class Initialized
DEBUG - 2011-04-14 11:46:53 --> UTF-8 Support Enabled
DEBUG - 2011-04-14 11:46:53 --> URI Class Initialized
DEBUG - 2011-04-14 11:46:53 --> Router Class Initialized
DEBUG - 2011-04-14 11:46:53 --> Output Class Initialized
DEBUG - 2011-04-14 11:46:53 --> Input Class Initialized
DEBUG - 2011-04-14 11:46:53 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-14 11:46:53 --> Language Class Initialized
DEBUG - 2011-04-14 11:46:53 --> Loader Class Initialized
DEBUG - 2011-04-14 11:46:53 --> Controller Class Initialized
DEBUG - 2011-04-14 11:46:53 --> Model Class Initialized
DEBUG - 2011-04-14 11:46:53 --> Model Class Initialized
DEBUG - 2011-04-14 11:46:53 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-14 11:46:53 --> Database Driver Class Initialized
DEBUG - 2011-04-14 11:46:54 --> Final output sent to browser
DEBUG - 2011-04-14 11:46:54 --> Total execution time: 1.4713
DEBUG - 2011-04-14 11:46:56 --> Config Class Initialized
DEBUG - 2011-04-14 11:46:56 --> Hooks Class Initialized
DEBUG - 2011-04-14 11:46:56 --> Utf8 Class Initialized
DEBUG - 2011-04-14 11:46:56 --> UTF-8 Support Enabled
DEBUG - 2011-04-14 11:46:56 --> URI Class Initialized
DEBUG - 2011-04-14 11:46:56 --> Router Class Initialized
ERROR - 2011-04-14 11:46:56 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-04-14 11:47:30 --> Config Class Initialized
DEBUG - 2011-04-14 11:47:30 --> Hooks Class Initialized
DEBUG - 2011-04-14 11:47:30 --> Utf8 Class Initialized
DEBUG - 2011-04-14 11:47:30 --> UTF-8 Support Enabled
DEBUG - 2011-04-14 11:47:30 --> URI Class Initialized
DEBUG - 2011-04-14 11:47:30 --> Router Class Initialized
DEBUG - 2011-04-14 11:47:30 --> Output Class Initialized
DEBUG - 2011-04-14 11:47:30 --> Input Class Initialized
DEBUG - 2011-04-14 11:47:30 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-14 11:47:30 --> Language Class Initialized
DEBUG - 2011-04-14 11:47:30 --> Loader Class Initialized
DEBUG - 2011-04-14 11:47:30 --> Controller Class Initialized
ERROR - 2011-04-14 11:47:30 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-04-14 11:47:30 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-04-14 11:47:30 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-04-14 11:47:30 --> Model Class Initialized
DEBUG - 2011-04-14 11:47:30 --> Model Class Initialized
DEBUG - 2011-04-14 11:47:30 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-14 11:47:30 --> Database Driver Class Initialized
DEBUG - 2011-04-14 11:47:30 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-04-14 11:47:30 --> Helper loaded: url_helper
DEBUG - 2011-04-14 11:47:30 --> File loaded: application/views/common/header.php
DEBUG - 2011-04-14 11:47:30 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-04-14 11:47:30 --> File loaded: application/views/common/footer.php
DEBUG - 2011-04-14 11:47:30 --> File loaded: application/views/layout/main.php
DEBUG - 2011-04-14 11:47:30 --> Final output sent to browser
DEBUG - 2011-04-14 11:47:30 --> Total execution time: 0.0364
DEBUG - 2011-04-14 11:47:33 --> Config Class Initialized
DEBUG - 2011-04-14 11:47:33 --> Hooks Class Initialized
DEBUG - 2011-04-14 11:47:33 --> Utf8 Class Initialized
DEBUG - 2011-04-14 11:47:33 --> UTF-8 Support Enabled
DEBUG - 2011-04-14 11:47:33 --> URI Class Initialized
DEBUG - 2011-04-14 11:47:33 --> Router Class Initialized
DEBUG - 2011-04-14 11:47:33 --> Output Class Initialized
DEBUG - 2011-04-14 11:47:33 --> Input Class Initialized
DEBUG - 2011-04-14 11:47:33 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-14 11:47:33 --> Language Class Initialized
DEBUG - 2011-04-14 11:47:33 --> Loader Class Initialized
DEBUG - 2011-04-14 11:47:33 --> Controller Class Initialized
DEBUG - 2011-04-14 11:47:33 --> Model Class Initialized
DEBUG - 2011-04-14 11:47:33 --> Model Class Initialized
DEBUG - 2011-04-14 11:47:33 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-14 11:47:33 --> Database Driver Class Initialized
DEBUG - 2011-04-14 11:47:34 --> Final output sent to browser
DEBUG - 2011-04-14 11:47:34 --> Total execution time: 1.4279
DEBUG - 2011-04-14 11:47:36 --> Config Class Initialized
DEBUG - 2011-04-14 11:47:36 --> Hooks Class Initialized
DEBUG - 2011-04-14 11:47:36 --> Utf8 Class Initialized
DEBUG - 2011-04-14 11:47:36 --> UTF-8 Support Enabled
DEBUG - 2011-04-14 11:47:36 --> URI Class Initialized
DEBUG - 2011-04-14 11:47:36 --> Router Class Initialized
ERROR - 2011-04-14 11:47:36 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-04-14 11:48:07 --> Config Class Initialized
DEBUG - 2011-04-14 11:48:07 --> Hooks Class Initialized
DEBUG - 2011-04-14 11:48:07 --> Utf8 Class Initialized
DEBUG - 2011-04-14 11:48:07 --> UTF-8 Support Enabled
DEBUG - 2011-04-14 11:48:07 --> URI Class Initialized
DEBUG - 2011-04-14 11:48:07 --> Router Class Initialized
DEBUG - 2011-04-14 11:48:07 --> Output Class Initialized
DEBUG - 2011-04-14 11:48:07 --> Input Class Initialized
DEBUG - 2011-04-14 11:48:07 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-14 11:48:07 --> Language Class Initialized
DEBUG - 2011-04-14 11:48:07 --> Loader Class Initialized
DEBUG - 2011-04-14 11:48:07 --> Controller Class Initialized
ERROR - 2011-04-14 11:48:07 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-04-14 11:48:07 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-04-14 11:48:07 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-04-14 11:48:07 --> Model Class Initialized
DEBUG - 2011-04-14 11:48:07 --> Model Class Initialized
DEBUG - 2011-04-14 11:48:07 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-14 11:48:07 --> Database Driver Class Initialized
DEBUG - 2011-04-14 11:48:07 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-04-14 11:48:07 --> Helper loaded: url_helper
DEBUG - 2011-04-14 11:48:07 --> File loaded: application/views/common/header.php
DEBUG - 2011-04-14 11:48:07 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-04-14 11:48:07 --> File loaded: application/views/common/footer.php
DEBUG - 2011-04-14 11:48:07 --> File loaded: application/views/layout/main.php
DEBUG - 2011-04-14 11:48:07 --> Final output sent to browser
DEBUG - 2011-04-14 11:48:07 --> Total execution time: 0.0313
DEBUG - 2011-04-14 11:48:10 --> Config Class Initialized
DEBUG - 2011-04-14 11:48:10 --> Hooks Class Initialized
DEBUG - 2011-04-14 11:48:10 --> Utf8 Class Initialized
DEBUG - 2011-04-14 11:48:10 --> UTF-8 Support Enabled
DEBUG - 2011-04-14 11:48:10 --> URI Class Initialized
DEBUG - 2011-04-14 11:48:10 --> Router Class Initialized
DEBUG - 2011-04-14 11:48:10 --> Output Class Initialized
DEBUG - 2011-04-14 11:48:10 --> Input Class Initialized
DEBUG - 2011-04-14 11:48:10 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-14 11:48:10 --> Language Class Initialized
DEBUG - 2011-04-14 11:48:10 --> Loader Class Initialized
DEBUG - 2011-04-14 11:48:10 --> Controller Class Initialized
DEBUG - 2011-04-14 11:48:10 --> Model Class Initialized
DEBUG - 2011-04-14 11:48:10 --> Model Class Initialized
DEBUG - 2011-04-14 11:48:10 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-14 11:48:10 --> Database Driver Class Initialized
DEBUG - 2011-04-14 11:48:11 --> Final output sent to browser
DEBUG - 2011-04-14 11:48:11 --> Total execution time: 1.3453
DEBUG - 2011-04-14 11:48:13 --> Config Class Initialized
DEBUG - 2011-04-14 11:48:13 --> Hooks Class Initialized
DEBUG - 2011-04-14 11:48:13 --> Utf8 Class Initialized
DEBUG - 2011-04-14 11:48:13 --> UTF-8 Support Enabled
DEBUG - 2011-04-14 11:48:13 --> URI Class Initialized
DEBUG - 2011-04-14 11:48:13 --> Router Class Initialized
ERROR - 2011-04-14 11:48:13 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-04-14 11:48:39 --> Config Class Initialized
DEBUG - 2011-04-14 11:48:39 --> Hooks Class Initialized
DEBUG - 2011-04-14 11:48:39 --> Utf8 Class Initialized
DEBUG - 2011-04-14 11:48:39 --> UTF-8 Support Enabled
DEBUG - 2011-04-14 11:48:39 --> URI Class Initialized
DEBUG - 2011-04-14 11:48:39 --> Router Class Initialized
DEBUG - 2011-04-14 11:48:39 --> Output Class Initialized
DEBUG - 2011-04-14 11:48:39 --> Input Class Initialized
DEBUG - 2011-04-14 11:48:39 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-14 11:48:39 --> Language Class Initialized
DEBUG - 2011-04-14 11:48:39 --> Loader Class Initialized
DEBUG - 2011-04-14 11:48:39 --> Controller Class Initialized
ERROR - 2011-04-14 11:48:39 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-04-14 11:48:39 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-04-14 11:48:39 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-04-14 11:48:39 --> Model Class Initialized
DEBUG - 2011-04-14 11:48:39 --> Model Class Initialized
DEBUG - 2011-04-14 11:48:39 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-14 11:48:39 --> Database Driver Class Initialized
DEBUG - 2011-04-14 11:48:39 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-04-14 11:48:39 --> Helper loaded: url_helper
DEBUG - 2011-04-14 11:48:39 --> File loaded: application/views/common/header.php
DEBUG - 2011-04-14 11:48:39 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-04-14 11:48:39 --> File loaded: application/views/common/footer.php
DEBUG - 2011-04-14 11:48:39 --> File loaded: application/views/layout/main.php
DEBUG - 2011-04-14 11:48:39 --> Final output sent to browser
DEBUG - 2011-04-14 11:48:39 --> Total execution time: 0.3011
DEBUG - 2011-04-14 11:48:41 --> Config Class Initialized
DEBUG - 2011-04-14 11:48:41 --> Hooks Class Initialized
DEBUG - 2011-04-14 11:48:41 --> Utf8 Class Initialized
DEBUG - 2011-04-14 11:48:41 --> UTF-8 Support Enabled
DEBUG - 2011-04-14 11:48:41 --> URI Class Initialized
DEBUG - 2011-04-14 11:48:41 --> Router Class Initialized
DEBUG - 2011-04-14 11:48:41 --> Output Class Initialized
DEBUG - 2011-04-14 11:48:41 --> Input Class Initialized
DEBUG - 2011-04-14 11:48:41 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-14 11:48:41 --> Language Class Initialized
DEBUG - 2011-04-14 11:48:41 --> Loader Class Initialized
DEBUG - 2011-04-14 11:48:41 --> Controller Class Initialized
DEBUG - 2011-04-14 11:48:41 --> Model Class Initialized
DEBUG - 2011-04-14 11:48:41 --> Model Class Initialized
DEBUG - 2011-04-14 11:48:41 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-14 11:48:41 --> Database Driver Class Initialized
DEBUG - 2011-04-14 11:48:43 --> Final output sent to browser
DEBUG - 2011-04-14 11:48:43 --> Total execution time: 2.1370
DEBUG - 2011-04-14 11:48:45 --> Config Class Initialized
DEBUG - 2011-04-14 11:48:45 --> Hooks Class Initialized
DEBUG - 2011-04-14 11:48:45 --> Utf8 Class Initialized
DEBUG - 2011-04-14 11:48:45 --> UTF-8 Support Enabled
DEBUG - 2011-04-14 11:48:45 --> URI Class Initialized
DEBUG - 2011-04-14 11:48:45 --> Router Class Initialized
ERROR - 2011-04-14 11:48:45 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-04-14 11:49:29 --> Config Class Initialized
DEBUG - 2011-04-14 11:49:29 --> Hooks Class Initialized
DEBUG - 2011-04-14 11:49:29 --> Utf8 Class Initialized
DEBUG - 2011-04-14 11:49:29 --> UTF-8 Support Enabled
DEBUG - 2011-04-14 11:49:29 --> URI Class Initialized
DEBUG - 2011-04-14 11:49:29 --> Router Class Initialized
DEBUG - 2011-04-14 11:49:29 --> Output Class Initialized
DEBUG - 2011-04-14 11:49:29 --> Input Class Initialized
DEBUG - 2011-04-14 11:49:29 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-14 11:49:29 --> Language Class Initialized
DEBUG - 2011-04-14 11:49:29 --> Loader Class Initialized
DEBUG - 2011-04-14 11:49:29 --> Controller Class Initialized
ERROR - 2011-04-14 11:49:29 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-04-14 11:49:29 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-04-14 11:49:29 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-04-14 11:49:29 --> Model Class Initialized
DEBUG - 2011-04-14 11:49:29 --> Model Class Initialized
DEBUG - 2011-04-14 11:49:29 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-14 11:49:29 --> Database Driver Class Initialized
DEBUG - 2011-04-14 11:49:29 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-04-14 11:49:29 --> Helper loaded: url_helper
DEBUG - 2011-04-14 11:49:29 --> File loaded: application/views/common/header.php
DEBUG - 2011-04-14 11:49:29 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-04-14 11:49:29 --> File loaded: application/views/common/footer.php
DEBUG - 2011-04-14 11:49:29 --> File loaded: application/views/layout/main.php
DEBUG - 2011-04-14 11:49:29 --> Final output sent to browser
DEBUG - 2011-04-14 11:49:29 --> Total execution time: 0.3679
DEBUG - 2011-04-14 11:49:32 --> Config Class Initialized
DEBUG - 2011-04-14 11:49:32 --> Hooks Class Initialized
DEBUG - 2011-04-14 11:49:32 --> Utf8 Class Initialized
DEBUG - 2011-04-14 11:49:32 --> UTF-8 Support Enabled
DEBUG - 2011-04-14 11:49:32 --> URI Class Initialized
DEBUG - 2011-04-14 11:49:32 --> Router Class Initialized
DEBUG - 2011-04-14 11:49:32 --> Output Class Initialized
DEBUG - 2011-04-14 11:49:32 --> Input Class Initialized
DEBUG - 2011-04-14 11:49:32 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-14 11:49:32 --> Language Class Initialized
DEBUG - 2011-04-14 11:49:32 --> Loader Class Initialized
DEBUG - 2011-04-14 11:49:32 --> Controller Class Initialized
DEBUG - 2011-04-14 11:49:32 --> Model Class Initialized
DEBUG - 2011-04-14 11:49:32 --> Model Class Initialized
DEBUG - 2011-04-14 11:49:32 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-14 11:49:32 --> Database Driver Class Initialized
DEBUG - 2011-04-14 11:49:34 --> Final output sent to browser
DEBUG - 2011-04-14 11:49:34 --> Total execution time: 2.1617
DEBUG - 2011-04-14 11:49:36 --> Config Class Initialized
DEBUG - 2011-04-14 11:49:36 --> Hooks Class Initialized
DEBUG - 2011-04-14 11:49:36 --> Utf8 Class Initialized
DEBUG - 2011-04-14 11:49:36 --> UTF-8 Support Enabled
DEBUG - 2011-04-14 11:49:36 --> URI Class Initialized
DEBUG - 2011-04-14 11:49:36 --> Router Class Initialized
ERROR - 2011-04-14 11:49:36 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-04-14 11:50:03 --> Config Class Initialized
DEBUG - 2011-04-14 11:50:03 --> Hooks Class Initialized
DEBUG - 2011-04-14 11:50:03 --> Utf8 Class Initialized
DEBUG - 2011-04-14 11:50:03 --> UTF-8 Support Enabled
DEBUG - 2011-04-14 11:50:03 --> URI Class Initialized
DEBUG - 2011-04-14 11:50:03 --> Router Class Initialized
DEBUG - 2011-04-14 11:50:03 --> Output Class Initialized
DEBUG - 2011-04-14 11:50:03 --> Input Class Initialized
DEBUG - 2011-04-14 11:50:03 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-14 11:50:03 --> Language Class Initialized
DEBUG - 2011-04-14 11:50:03 --> Loader Class Initialized
DEBUG - 2011-04-14 11:50:03 --> Controller Class Initialized
ERROR - 2011-04-14 11:50:04 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-04-14 11:50:04 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-04-14 11:50:04 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-04-14 11:50:04 --> Model Class Initialized
DEBUG - 2011-04-14 11:50:04 --> Model Class Initialized
DEBUG - 2011-04-14 11:50:04 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-14 11:50:04 --> Database Driver Class Initialized
DEBUG - 2011-04-14 11:50:04 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-04-14 11:50:07 --> Helper loaded: url_helper
DEBUG - 2011-04-14 11:50:07 --> File loaded: application/views/common/header.php
DEBUG - 2011-04-14 11:50:07 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-04-14 11:50:07 --> File loaded: application/views/common/footer.php
DEBUG - 2011-04-14 11:50:07 --> File loaded: application/views/layout/main.php
DEBUG - 2011-04-14 11:50:07 --> Final output sent to browser
DEBUG - 2011-04-14 11:50:07 --> Total execution time: 3.5674
DEBUG - 2011-04-14 11:50:09 --> Config Class Initialized
DEBUG - 2011-04-14 11:50:09 --> Hooks Class Initialized
DEBUG - 2011-04-14 11:50:09 --> Utf8 Class Initialized
DEBUG - 2011-04-14 11:50:09 --> UTF-8 Support Enabled
DEBUG - 2011-04-14 11:50:09 --> URI Class Initialized
DEBUG - 2011-04-14 11:50:09 --> Router Class Initialized
DEBUG - 2011-04-14 11:50:09 --> Output Class Initialized
DEBUG - 2011-04-14 11:50:09 --> Input Class Initialized
DEBUG - 2011-04-14 11:50:09 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-14 11:50:09 --> Language Class Initialized
DEBUG - 2011-04-14 11:50:09 --> Loader Class Initialized
DEBUG - 2011-04-14 11:50:09 --> Controller Class Initialized
DEBUG - 2011-04-14 11:50:09 --> Model Class Initialized
DEBUG - 2011-04-14 11:50:09 --> Model Class Initialized
DEBUG - 2011-04-14 11:50:09 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-14 11:50:09 --> Database Driver Class Initialized
DEBUG - 2011-04-14 11:50:10 --> Final output sent to browser
DEBUG - 2011-04-14 11:50:10 --> Total execution time: 0.5848
DEBUG - 2011-04-14 11:50:13 --> Config Class Initialized
DEBUG - 2011-04-14 11:50:13 --> Hooks Class Initialized
DEBUG - 2011-04-14 11:50:13 --> Utf8 Class Initialized
DEBUG - 2011-04-14 11:50:13 --> UTF-8 Support Enabled
DEBUG - 2011-04-14 11:50:13 --> URI Class Initialized
DEBUG - 2011-04-14 11:50:13 --> Router Class Initialized
ERROR - 2011-04-14 11:50:13 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-04-14 11:52:51 --> Config Class Initialized
DEBUG - 2011-04-14 11:52:51 --> Hooks Class Initialized
DEBUG - 2011-04-14 11:52:51 --> Utf8 Class Initialized
DEBUG - 2011-04-14 11:52:51 --> UTF-8 Support Enabled
DEBUG - 2011-04-14 11:52:51 --> URI Class Initialized
DEBUG - 2011-04-14 11:52:51 --> Router Class Initialized
DEBUG - 2011-04-14 11:52:51 --> Output Class Initialized
DEBUG - 2011-04-14 11:52:51 --> Input Class Initialized
DEBUG - 2011-04-14 11:52:51 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-14 11:52:51 --> Language Class Initialized
DEBUG - 2011-04-14 11:52:51 --> Loader Class Initialized
DEBUG - 2011-04-14 11:52:51 --> Controller Class Initialized
ERROR - 2011-04-14 11:52:51 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-04-14 11:52:51 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-04-14 11:52:51 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-04-14 11:52:51 --> Model Class Initialized
DEBUG - 2011-04-14 11:52:51 --> Model Class Initialized
DEBUG - 2011-04-14 11:52:51 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-14 11:52:51 --> Database Driver Class Initialized
DEBUG - 2011-04-14 11:52:51 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-04-14 11:52:51 --> Helper loaded: url_helper
DEBUG - 2011-04-14 11:52:51 --> File loaded: application/views/common/header.php
DEBUG - 2011-04-14 11:52:51 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-04-14 11:52:51 --> File loaded: application/views/common/footer.php
DEBUG - 2011-04-14 11:52:51 --> File loaded: application/views/layout/main.php
DEBUG - 2011-04-14 11:52:51 --> Final output sent to browser
DEBUG - 2011-04-14 11:52:51 --> Total execution time: 0.0370
DEBUG - 2011-04-14 11:52:54 --> Config Class Initialized
DEBUG - 2011-04-14 11:52:54 --> Hooks Class Initialized
DEBUG - 2011-04-14 11:52:54 --> Utf8 Class Initialized
DEBUG - 2011-04-14 11:52:54 --> UTF-8 Support Enabled
DEBUG - 2011-04-14 11:52:54 --> URI Class Initialized
DEBUG - 2011-04-14 11:52:54 --> Router Class Initialized
DEBUG - 2011-04-14 11:52:54 --> Output Class Initialized
DEBUG - 2011-04-14 11:52:54 --> Input Class Initialized
DEBUG - 2011-04-14 11:52:54 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-14 11:52:54 --> Language Class Initialized
DEBUG - 2011-04-14 11:52:54 --> Loader Class Initialized
DEBUG - 2011-04-14 11:52:54 --> Controller Class Initialized
DEBUG - 2011-04-14 11:52:54 --> Model Class Initialized
DEBUG - 2011-04-14 11:52:54 --> Model Class Initialized
DEBUG - 2011-04-14 11:52:54 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-14 11:52:54 --> Database Driver Class Initialized
DEBUG - 2011-04-14 11:52:54 --> Final output sent to browser
DEBUG - 2011-04-14 11:52:54 --> Total execution time: 0.8438
DEBUG - 2011-04-14 11:52:57 --> Config Class Initialized
DEBUG - 2011-04-14 11:52:57 --> Hooks Class Initialized
DEBUG - 2011-04-14 11:52:57 --> Utf8 Class Initialized
DEBUG - 2011-04-14 11:52:57 --> UTF-8 Support Enabled
DEBUG - 2011-04-14 11:52:57 --> URI Class Initialized
DEBUG - 2011-04-14 11:52:57 --> Router Class Initialized
ERROR - 2011-04-14 11:52:57 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-04-14 11:53:24 --> Config Class Initialized
DEBUG - 2011-04-14 11:53:24 --> Hooks Class Initialized
DEBUG - 2011-04-14 11:53:24 --> Utf8 Class Initialized
DEBUG - 2011-04-14 11:53:24 --> UTF-8 Support Enabled
DEBUG - 2011-04-14 11:53:24 --> URI Class Initialized
DEBUG - 2011-04-14 11:53:24 --> Router Class Initialized
DEBUG - 2011-04-14 11:53:24 --> Output Class Initialized
DEBUG - 2011-04-14 11:53:24 --> Input Class Initialized
DEBUG - 2011-04-14 11:53:24 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-14 11:53:24 --> Language Class Initialized
DEBUG - 2011-04-14 11:53:24 --> Loader Class Initialized
DEBUG - 2011-04-14 11:53:24 --> Controller Class Initialized
ERROR - 2011-04-14 11:53:24 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-04-14 11:53:24 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-04-14 11:53:24 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-04-14 11:53:24 --> Model Class Initialized
DEBUG - 2011-04-14 11:53:24 --> Model Class Initialized
DEBUG - 2011-04-14 11:53:24 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-14 11:53:24 --> Database Driver Class Initialized
DEBUG - 2011-04-14 11:53:24 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-04-14 11:53:24 --> Helper loaded: url_helper
DEBUG - 2011-04-14 11:53:24 --> File loaded: application/views/common/header.php
DEBUG - 2011-04-14 11:53:24 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-04-14 11:53:24 --> File loaded: application/views/common/footer.php
DEBUG - 2011-04-14 11:53:24 --> File loaded: application/views/layout/main.php
DEBUG - 2011-04-14 11:53:24 --> Final output sent to browser
DEBUG - 2011-04-14 11:53:24 --> Total execution time: 0.0316
DEBUG - 2011-04-14 11:53:26 --> Config Class Initialized
DEBUG - 2011-04-14 11:53:26 --> Hooks Class Initialized
DEBUG - 2011-04-14 11:53:26 --> Utf8 Class Initialized
DEBUG - 2011-04-14 11:53:26 --> UTF-8 Support Enabled
DEBUG - 2011-04-14 11:53:26 --> URI Class Initialized
DEBUG - 2011-04-14 11:53:26 --> Router Class Initialized
DEBUG - 2011-04-14 11:53:26 --> Output Class Initialized
DEBUG - 2011-04-14 11:53:26 --> Input Class Initialized
DEBUG - 2011-04-14 11:53:26 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-14 11:53:26 --> Language Class Initialized
DEBUG - 2011-04-14 11:53:26 --> Loader Class Initialized
DEBUG - 2011-04-14 11:53:26 --> Controller Class Initialized
DEBUG - 2011-04-14 11:53:26 --> Model Class Initialized
DEBUG - 2011-04-14 11:53:26 --> Model Class Initialized
DEBUG - 2011-04-14 11:53:26 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-14 11:53:26 --> Database Driver Class Initialized
DEBUG - 2011-04-14 11:53:28 --> Final output sent to browser
DEBUG - 2011-04-14 11:53:28 --> Total execution time: 1.2329
DEBUG - 2011-04-14 11:53:30 --> Config Class Initialized
DEBUG - 2011-04-14 11:53:30 --> Hooks Class Initialized
DEBUG - 2011-04-14 11:53:30 --> Utf8 Class Initialized
DEBUG - 2011-04-14 11:53:30 --> UTF-8 Support Enabled
DEBUG - 2011-04-14 11:53:30 --> URI Class Initialized
DEBUG - 2011-04-14 11:53:30 --> Router Class Initialized
ERROR - 2011-04-14 11:53:30 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-04-14 11:53:46 --> Config Class Initialized
DEBUG - 2011-04-14 11:53:46 --> Hooks Class Initialized
DEBUG - 2011-04-14 11:53:46 --> Utf8 Class Initialized
DEBUG - 2011-04-14 11:53:46 --> UTF-8 Support Enabled
DEBUG - 2011-04-14 11:53:46 --> URI Class Initialized
DEBUG - 2011-04-14 11:53:46 --> Router Class Initialized
DEBUG - 2011-04-14 11:53:46 --> Output Class Initialized
DEBUG - 2011-04-14 11:53:46 --> Input Class Initialized
DEBUG - 2011-04-14 11:53:46 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-14 11:53:46 --> Language Class Initialized
DEBUG - 2011-04-14 11:53:46 --> Loader Class Initialized
DEBUG - 2011-04-14 11:53:46 --> Controller Class Initialized
ERROR - 2011-04-14 11:53:46 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-04-14 11:53:46 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-04-14 11:53:46 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-04-14 11:53:46 --> Model Class Initialized
DEBUG - 2011-04-14 11:53:46 --> Model Class Initialized
DEBUG - 2011-04-14 11:53:46 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-14 11:53:46 --> Database Driver Class Initialized
DEBUG - 2011-04-14 11:53:46 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-04-14 11:53:46 --> Helper loaded: url_helper
DEBUG - 2011-04-14 11:53:46 --> File loaded: application/views/common/header.php
DEBUG - 2011-04-14 11:53:46 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-04-14 11:53:46 --> File loaded: application/views/common/footer.php
DEBUG - 2011-04-14 11:53:46 --> File loaded: application/views/layout/main.php
DEBUG - 2011-04-14 11:53:46 --> Final output sent to browser
DEBUG - 2011-04-14 11:53:46 --> Total execution time: 0.1095
DEBUG - 2011-04-14 11:53:48 --> Config Class Initialized
DEBUG - 2011-04-14 11:53:48 --> Hooks Class Initialized
DEBUG - 2011-04-14 11:53:48 --> Utf8 Class Initialized
DEBUG - 2011-04-14 11:53:48 --> UTF-8 Support Enabled
DEBUG - 2011-04-14 11:53:48 --> URI Class Initialized
DEBUG - 2011-04-14 11:53:48 --> Router Class Initialized
DEBUG - 2011-04-14 11:53:48 --> Output Class Initialized
DEBUG - 2011-04-14 11:53:48 --> Input Class Initialized
DEBUG - 2011-04-14 11:53:48 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-14 11:53:48 --> Language Class Initialized
DEBUG - 2011-04-14 11:53:48 --> Loader Class Initialized
DEBUG - 2011-04-14 11:53:48 --> Controller Class Initialized
DEBUG - 2011-04-14 11:53:48 --> Model Class Initialized
DEBUG - 2011-04-14 11:53:48 --> Model Class Initialized
DEBUG - 2011-04-14 11:53:48 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-14 11:53:48 --> Database Driver Class Initialized
DEBUG - 2011-04-14 11:53:49 --> Final output sent to browser
DEBUG - 2011-04-14 11:53:49 --> Total execution time: 0.6577
DEBUG - 2011-04-14 11:53:51 --> Config Class Initialized
DEBUG - 2011-04-14 11:53:51 --> Hooks Class Initialized
DEBUG - 2011-04-14 11:53:51 --> Utf8 Class Initialized
DEBUG - 2011-04-14 11:53:51 --> UTF-8 Support Enabled
DEBUG - 2011-04-14 11:53:51 --> URI Class Initialized
DEBUG - 2011-04-14 11:53:51 --> Router Class Initialized
ERROR - 2011-04-14 11:53:51 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-04-14 11:54:27 --> Config Class Initialized
DEBUG - 2011-04-14 11:54:27 --> Hooks Class Initialized
DEBUG - 2011-04-14 11:54:27 --> Utf8 Class Initialized
DEBUG - 2011-04-14 11:54:27 --> UTF-8 Support Enabled
DEBUG - 2011-04-14 11:54:27 --> URI Class Initialized
DEBUG - 2011-04-14 11:54:27 --> Router Class Initialized
DEBUG - 2011-04-14 11:54:27 --> Output Class Initialized
DEBUG - 2011-04-14 11:54:27 --> Input Class Initialized
DEBUG - 2011-04-14 11:54:27 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-14 11:54:27 --> Language Class Initialized
DEBUG - 2011-04-14 11:54:27 --> Loader Class Initialized
DEBUG - 2011-04-14 11:54:27 --> Controller Class Initialized
ERROR - 2011-04-14 11:54:27 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-04-14 11:54:27 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-04-14 11:54:27 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-04-14 11:54:27 --> Model Class Initialized
DEBUG - 2011-04-14 11:54:27 --> Model Class Initialized
DEBUG - 2011-04-14 11:54:27 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-14 11:54:27 --> Database Driver Class Initialized
DEBUG - 2011-04-14 11:54:27 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-04-14 11:54:27 --> Helper loaded: url_helper
DEBUG - 2011-04-14 11:54:27 --> File loaded: application/views/common/header.php
DEBUG - 2011-04-14 11:54:27 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-04-14 11:54:27 --> File loaded: application/views/common/footer.php
DEBUG - 2011-04-14 11:54:27 --> File loaded: application/views/layout/main.php
DEBUG - 2011-04-14 11:54:27 --> Final output sent to browser
DEBUG - 2011-04-14 11:54:27 --> Total execution time: 0.0429
DEBUG - 2011-04-14 11:54:29 --> Config Class Initialized
DEBUG - 2011-04-14 11:54:29 --> Hooks Class Initialized
DEBUG - 2011-04-14 11:54:29 --> Utf8 Class Initialized
DEBUG - 2011-04-14 11:54:29 --> UTF-8 Support Enabled
DEBUG - 2011-04-14 11:54:29 --> URI Class Initialized
DEBUG - 2011-04-14 11:54:29 --> Router Class Initialized
DEBUG - 2011-04-14 11:54:29 --> Output Class Initialized
DEBUG - 2011-04-14 11:54:29 --> Input Class Initialized
DEBUG - 2011-04-14 11:54:29 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-14 11:54:29 --> Language Class Initialized
DEBUG - 2011-04-14 11:54:29 --> Loader Class Initialized
DEBUG - 2011-04-14 11:54:29 --> Controller Class Initialized
DEBUG - 2011-04-14 11:54:29 --> Model Class Initialized
DEBUG - 2011-04-14 11:54:29 --> Model Class Initialized
DEBUG - 2011-04-14 11:54:29 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-14 11:54:29 --> Database Driver Class Initialized
DEBUG - 2011-04-14 11:54:30 --> Final output sent to browser
DEBUG - 2011-04-14 11:54:30 --> Total execution time: 0.5914
DEBUG - 2011-04-14 11:54:32 --> Config Class Initialized
DEBUG - 2011-04-14 11:54:32 --> Hooks Class Initialized
DEBUG - 2011-04-14 11:54:32 --> Utf8 Class Initialized
DEBUG - 2011-04-14 11:54:32 --> UTF-8 Support Enabled
DEBUG - 2011-04-14 11:54:32 --> URI Class Initialized
DEBUG - 2011-04-14 11:54:32 --> Router Class Initialized
ERROR - 2011-04-14 11:54:32 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-04-14 11:54:49 --> Config Class Initialized
DEBUG - 2011-04-14 11:54:49 --> Hooks Class Initialized
DEBUG - 2011-04-14 11:54:49 --> Utf8 Class Initialized
DEBUG - 2011-04-14 11:54:49 --> UTF-8 Support Enabled
DEBUG - 2011-04-14 11:54:49 --> URI Class Initialized
DEBUG - 2011-04-14 11:54:49 --> Router Class Initialized
DEBUG - 2011-04-14 11:54:49 --> Output Class Initialized
DEBUG - 2011-04-14 11:54:49 --> Input Class Initialized
DEBUG - 2011-04-14 11:54:49 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-14 11:54:49 --> Language Class Initialized
DEBUG - 2011-04-14 11:54:49 --> Loader Class Initialized
DEBUG - 2011-04-14 11:54:49 --> Controller Class Initialized
ERROR - 2011-04-14 11:54:49 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-04-14 11:54:49 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-04-14 11:54:49 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-04-14 11:54:49 --> Model Class Initialized
DEBUG - 2011-04-14 11:54:49 --> Model Class Initialized
DEBUG - 2011-04-14 11:54:49 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-14 11:54:49 --> Database Driver Class Initialized
DEBUG - 2011-04-14 11:54:49 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-04-14 11:54:49 --> Helper loaded: url_helper
DEBUG - 2011-04-14 11:54:49 --> File loaded: application/views/common/header.php
DEBUG - 2011-04-14 11:54:49 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-04-14 11:54:49 --> File loaded: application/views/common/footer.php
DEBUG - 2011-04-14 11:54:49 --> File loaded: application/views/layout/main.php
DEBUG - 2011-04-14 11:54:49 --> Final output sent to browser
DEBUG - 2011-04-14 11:54:49 --> Total execution time: 0.0399
DEBUG - 2011-04-14 11:54:51 --> Config Class Initialized
DEBUG - 2011-04-14 11:54:51 --> Hooks Class Initialized
DEBUG - 2011-04-14 11:54:51 --> Utf8 Class Initialized
DEBUG - 2011-04-14 11:54:51 --> UTF-8 Support Enabled
DEBUG - 2011-04-14 11:54:51 --> URI Class Initialized
DEBUG - 2011-04-14 11:54:51 --> Router Class Initialized
DEBUG - 2011-04-14 11:54:51 --> Output Class Initialized
DEBUG - 2011-04-14 11:54:51 --> Input Class Initialized
DEBUG - 2011-04-14 11:54:51 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-14 11:54:51 --> Language Class Initialized
DEBUG - 2011-04-14 11:54:51 --> Loader Class Initialized
DEBUG - 2011-04-14 11:54:51 --> Controller Class Initialized
DEBUG - 2011-04-14 11:54:51 --> Model Class Initialized
DEBUG - 2011-04-14 11:54:51 --> Model Class Initialized
DEBUG - 2011-04-14 11:54:51 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-14 11:54:52 --> Database Driver Class Initialized
DEBUG - 2011-04-14 11:54:52 --> Final output sent to browser
DEBUG - 2011-04-14 11:54:52 --> Total execution time: 0.5879
DEBUG - 2011-04-14 11:54:55 --> Config Class Initialized
DEBUG - 2011-04-14 11:54:55 --> Hooks Class Initialized
DEBUG - 2011-04-14 11:54:55 --> Utf8 Class Initialized
DEBUG - 2011-04-14 11:54:55 --> UTF-8 Support Enabled
DEBUG - 2011-04-14 11:54:55 --> URI Class Initialized
DEBUG - 2011-04-14 11:54:55 --> Router Class Initialized
ERROR - 2011-04-14 11:54:55 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-04-14 11:55:08 --> Config Class Initialized
DEBUG - 2011-04-14 11:55:08 --> Hooks Class Initialized
DEBUG - 2011-04-14 11:55:08 --> Utf8 Class Initialized
DEBUG - 2011-04-14 11:55:08 --> UTF-8 Support Enabled
DEBUG - 2011-04-14 11:55:08 --> URI Class Initialized
DEBUG - 2011-04-14 11:55:08 --> Router Class Initialized
DEBUG - 2011-04-14 11:55:08 --> Output Class Initialized
DEBUG - 2011-04-14 11:55:08 --> Input Class Initialized
DEBUG - 2011-04-14 11:55:08 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-14 11:55:08 --> Language Class Initialized
DEBUG - 2011-04-14 11:55:08 --> Loader Class Initialized
DEBUG - 2011-04-14 11:55:08 --> Controller Class Initialized
ERROR - 2011-04-14 11:55:08 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-04-14 11:55:08 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-04-14 11:55:08 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-04-14 11:55:08 --> Model Class Initialized
DEBUG - 2011-04-14 11:55:08 --> Model Class Initialized
DEBUG - 2011-04-14 11:55:08 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-14 11:55:08 --> Database Driver Class Initialized
DEBUG - 2011-04-14 11:55:08 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-04-14 11:55:08 --> Helper loaded: url_helper
DEBUG - 2011-04-14 11:55:08 --> File loaded: application/views/common/header.php
DEBUG - 2011-04-14 11:55:08 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-04-14 11:55:08 --> File loaded: application/views/common/footer.php
DEBUG - 2011-04-14 11:55:08 --> File loaded: application/views/layout/main.php
DEBUG - 2011-04-14 11:55:08 --> Final output sent to browser
DEBUG - 2011-04-14 11:55:08 --> Total execution time: 0.0282
DEBUG - 2011-04-14 11:55:10 --> Config Class Initialized
DEBUG - 2011-04-14 11:55:10 --> Hooks Class Initialized
DEBUG - 2011-04-14 11:55:10 --> Utf8 Class Initialized
DEBUG - 2011-04-14 11:55:10 --> UTF-8 Support Enabled
DEBUG - 2011-04-14 11:55:10 --> URI Class Initialized
DEBUG - 2011-04-14 11:55:10 --> Router Class Initialized
DEBUG - 2011-04-14 11:55:10 --> Output Class Initialized
DEBUG - 2011-04-14 11:55:10 --> Input Class Initialized
DEBUG - 2011-04-14 11:55:10 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-14 11:55:10 --> Language Class Initialized
DEBUG - 2011-04-14 11:55:10 --> Loader Class Initialized
DEBUG - 2011-04-14 11:55:10 --> Controller Class Initialized
DEBUG - 2011-04-14 11:55:10 --> Model Class Initialized
DEBUG - 2011-04-14 11:55:10 --> Model Class Initialized
DEBUG - 2011-04-14 11:55:10 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-14 11:55:10 --> Database Driver Class Initialized
DEBUG - 2011-04-14 11:55:11 --> Final output sent to browser
DEBUG - 2011-04-14 11:55:11 --> Total execution time: 0.5113
DEBUG - 2011-04-14 11:55:14 --> Config Class Initialized
DEBUG - 2011-04-14 11:55:14 --> Hooks Class Initialized
DEBUG - 2011-04-14 11:55:14 --> Utf8 Class Initialized
DEBUG - 2011-04-14 11:55:14 --> UTF-8 Support Enabled
DEBUG - 2011-04-14 11:55:14 --> URI Class Initialized
DEBUG - 2011-04-14 11:55:14 --> Router Class Initialized
ERROR - 2011-04-14 11:55:14 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-04-14 11:55:27 --> Config Class Initialized
DEBUG - 2011-04-14 11:55:27 --> Hooks Class Initialized
DEBUG - 2011-04-14 11:55:27 --> Utf8 Class Initialized
DEBUG - 2011-04-14 11:55:27 --> UTF-8 Support Enabled
DEBUG - 2011-04-14 11:55:27 --> URI Class Initialized
DEBUG - 2011-04-14 11:55:27 --> Router Class Initialized
DEBUG - 2011-04-14 11:55:27 --> Output Class Initialized
DEBUG - 2011-04-14 11:55:27 --> Input Class Initialized
DEBUG - 2011-04-14 11:55:27 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-14 11:55:27 --> Language Class Initialized
DEBUG - 2011-04-14 11:55:27 --> Loader Class Initialized
DEBUG - 2011-04-14 11:55:27 --> Controller Class Initialized
ERROR - 2011-04-14 11:55:27 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-04-14 11:55:27 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-04-14 11:55:27 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-04-14 11:55:27 --> Model Class Initialized
DEBUG - 2011-04-14 11:55:27 --> Model Class Initialized
DEBUG - 2011-04-14 11:55:27 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-14 11:55:27 --> Database Driver Class Initialized
DEBUG - 2011-04-14 11:55:27 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-04-14 11:55:27 --> Helper loaded: url_helper
DEBUG - 2011-04-14 11:55:27 --> File loaded: application/views/common/header.php
DEBUG - 2011-04-14 11:55:27 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-04-14 11:55:27 --> File loaded: application/views/common/footer.php
DEBUG - 2011-04-14 11:55:27 --> File loaded: application/views/layout/main.php
DEBUG - 2011-04-14 11:55:27 --> Final output sent to browser
DEBUG - 2011-04-14 11:55:27 --> Total execution time: 0.0338
DEBUG - 2011-04-14 11:55:30 --> Config Class Initialized
DEBUG - 2011-04-14 11:55:30 --> Hooks Class Initialized
DEBUG - 2011-04-14 11:55:30 --> Utf8 Class Initialized
DEBUG - 2011-04-14 11:55:30 --> UTF-8 Support Enabled
DEBUG - 2011-04-14 11:55:30 --> URI Class Initialized
DEBUG - 2011-04-14 11:55:30 --> Router Class Initialized
DEBUG - 2011-04-14 11:55:30 --> Output Class Initialized
DEBUG - 2011-04-14 11:55:30 --> Input Class Initialized
DEBUG - 2011-04-14 11:55:30 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-14 11:55:30 --> Language Class Initialized
DEBUG - 2011-04-14 11:55:30 --> Loader Class Initialized
DEBUG - 2011-04-14 11:55:30 --> Controller Class Initialized
DEBUG - 2011-04-14 11:55:30 --> Model Class Initialized
DEBUG - 2011-04-14 11:55:30 --> Model Class Initialized
DEBUG - 2011-04-14 11:55:30 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-14 11:55:30 --> Database Driver Class Initialized
DEBUG - 2011-04-14 11:55:31 --> Final output sent to browser
DEBUG - 2011-04-14 11:55:31 --> Total execution time: 1.4478
DEBUG - 2011-04-14 11:55:34 --> Config Class Initialized
DEBUG - 2011-04-14 11:55:34 --> Hooks Class Initialized
DEBUG - 2011-04-14 11:55:34 --> Utf8 Class Initialized
DEBUG - 2011-04-14 11:55:34 --> UTF-8 Support Enabled
DEBUG - 2011-04-14 11:55:34 --> URI Class Initialized
DEBUG - 2011-04-14 11:55:34 --> Router Class Initialized
ERROR - 2011-04-14 11:55:34 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-04-14 11:55:50 --> Config Class Initialized
DEBUG - 2011-04-14 11:55:50 --> Hooks Class Initialized
DEBUG - 2011-04-14 11:55:50 --> Utf8 Class Initialized
DEBUG - 2011-04-14 11:55:50 --> UTF-8 Support Enabled
DEBUG - 2011-04-14 11:55:50 --> URI Class Initialized
DEBUG - 2011-04-14 11:55:50 --> Router Class Initialized
DEBUG - 2011-04-14 11:55:50 --> Output Class Initialized
DEBUG - 2011-04-14 11:55:50 --> Input Class Initialized
DEBUG - 2011-04-14 11:55:50 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-14 11:55:50 --> Language Class Initialized
DEBUG - 2011-04-14 11:55:50 --> Loader Class Initialized
DEBUG - 2011-04-14 11:55:50 --> Controller Class Initialized
ERROR - 2011-04-14 11:55:50 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-04-14 11:55:50 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-04-14 11:55:50 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-04-14 11:55:50 --> Model Class Initialized
DEBUG - 2011-04-14 11:55:50 --> Model Class Initialized
DEBUG - 2011-04-14 11:55:50 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-14 11:55:50 --> Database Driver Class Initialized
DEBUG - 2011-04-14 11:55:50 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-04-14 11:55:50 --> Helper loaded: url_helper
DEBUG - 2011-04-14 11:55:50 --> File loaded: application/views/common/header.php
DEBUG - 2011-04-14 11:55:50 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-04-14 11:55:50 --> File loaded: application/views/common/footer.php
DEBUG - 2011-04-14 11:55:50 --> File loaded: application/views/layout/main.php
DEBUG - 2011-04-14 11:55:50 --> Final output sent to browser
DEBUG - 2011-04-14 11:55:50 --> Total execution time: 0.0270
DEBUG - 2011-04-14 11:55:53 --> Config Class Initialized
DEBUG - 2011-04-14 11:55:53 --> Hooks Class Initialized
DEBUG - 2011-04-14 11:55:53 --> Utf8 Class Initialized
DEBUG - 2011-04-14 11:55:53 --> UTF-8 Support Enabled
DEBUG - 2011-04-14 11:55:53 --> URI Class Initialized
DEBUG - 2011-04-14 11:55:53 --> Router Class Initialized
DEBUG - 2011-04-14 11:55:53 --> Output Class Initialized
DEBUG - 2011-04-14 11:55:53 --> Input Class Initialized
DEBUG - 2011-04-14 11:55:53 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-14 11:55:53 --> Language Class Initialized
DEBUG - 2011-04-14 11:55:53 --> Loader Class Initialized
DEBUG - 2011-04-14 11:55:53 --> Controller Class Initialized
DEBUG - 2011-04-14 11:55:53 --> Model Class Initialized
DEBUG - 2011-04-14 11:55:53 --> Model Class Initialized
DEBUG - 2011-04-14 11:55:53 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-14 11:55:53 --> Database Driver Class Initialized
DEBUG - 2011-04-14 11:55:53 --> Final output sent to browser
DEBUG - 2011-04-14 11:55:53 --> Total execution time: 0.6905
DEBUG - 2011-04-14 11:55:56 --> Config Class Initialized
DEBUG - 2011-04-14 11:55:56 --> Hooks Class Initialized
DEBUG - 2011-04-14 11:55:56 --> Utf8 Class Initialized
DEBUG - 2011-04-14 11:55:56 --> UTF-8 Support Enabled
DEBUG - 2011-04-14 11:55:56 --> URI Class Initialized
DEBUG - 2011-04-14 11:55:56 --> Router Class Initialized
ERROR - 2011-04-14 11:55:56 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-04-14 11:56:03 --> Config Class Initialized
DEBUG - 2011-04-14 11:56:03 --> Hooks Class Initialized
DEBUG - 2011-04-14 11:56:03 --> Utf8 Class Initialized
DEBUG - 2011-04-14 11:56:03 --> UTF-8 Support Enabled
DEBUG - 2011-04-14 11:56:03 --> URI Class Initialized
DEBUG - 2011-04-14 11:56:03 --> Router Class Initialized
DEBUG - 2011-04-14 11:56:03 --> Output Class Initialized
DEBUG - 2011-04-14 11:56:03 --> Input Class Initialized
DEBUG - 2011-04-14 11:56:03 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-14 11:56:03 --> Language Class Initialized
DEBUG - 2011-04-14 11:56:03 --> Loader Class Initialized
DEBUG - 2011-04-14 11:56:03 --> Controller Class Initialized
ERROR - 2011-04-14 11:56:03 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-04-14 11:56:03 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-04-14 11:56:03 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-04-14 11:56:03 --> Model Class Initialized
DEBUG - 2011-04-14 11:56:03 --> Model Class Initialized
DEBUG - 2011-04-14 11:56:03 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-14 11:56:03 --> Database Driver Class Initialized
DEBUG - 2011-04-14 11:56:03 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-04-14 11:56:03 --> Helper loaded: url_helper
DEBUG - 2011-04-14 11:56:03 --> File loaded: application/views/common/header.php
DEBUG - 2011-04-14 11:56:03 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-04-14 11:56:03 --> File loaded: application/views/common/footer.php
DEBUG - 2011-04-14 11:56:03 --> File loaded: application/views/layout/main.php
DEBUG - 2011-04-14 11:56:03 --> Final output sent to browser
DEBUG - 2011-04-14 11:56:03 --> Total execution time: 0.0481
DEBUG - 2011-04-14 11:56:05 --> Config Class Initialized
DEBUG - 2011-04-14 11:56:05 --> Hooks Class Initialized
DEBUG - 2011-04-14 11:56:05 --> Utf8 Class Initialized
DEBUG - 2011-04-14 11:56:05 --> UTF-8 Support Enabled
DEBUG - 2011-04-14 11:56:05 --> URI Class Initialized
DEBUG - 2011-04-14 11:56:05 --> Router Class Initialized
DEBUG - 2011-04-14 11:56:05 --> Output Class Initialized
DEBUG - 2011-04-14 11:56:05 --> Input Class Initialized
DEBUG - 2011-04-14 11:56:05 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-14 11:56:05 --> Language Class Initialized
DEBUG - 2011-04-14 11:56:05 --> Loader Class Initialized
DEBUG - 2011-04-14 11:56:05 --> Controller Class Initialized
DEBUG - 2011-04-14 11:56:05 --> Model Class Initialized
DEBUG - 2011-04-14 11:56:05 --> Model Class Initialized
DEBUG - 2011-04-14 11:56:05 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-14 11:56:05 --> Database Driver Class Initialized
DEBUG - 2011-04-14 11:56:06 --> Final output sent to browser
DEBUG - 2011-04-14 11:56:06 --> Total execution time: 0.6727
DEBUG - 2011-04-14 11:56:09 --> Config Class Initialized
DEBUG - 2011-04-14 11:56:09 --> Hooks Class Initialized
DEBUG - 2011-04-14 11:56:09 --> Utf8 Class Initialized
DEBUG - 2011-04-14 11:56:09 --> UTF-8 Support Enabled
DEBUG - 2011-04-14 11:56:09 --> URI Class Initialized
DEBUG - 2011-04-14 11:56:09 --> Router Class Initialized
ERROR - 2011-04-14 11:56:09 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-04-14 11:56:21 --> Config Class Initialized
DEBUG - 2011-04-14 11:56:21 --> Hooks Class Initialized
DEBUG - 2011-04-14 11:56:21 --> Utf8 Class Initialized
DEBUG - 2011-04-14 11:56:21 --> UTF-8 Support Enabled
DEBUG - 2011-04-14 11:56:21 --> URI Class Initialized
DEBUG - 2011-04-14 11:56:21 --> Router Class Initialized
DEBUG - 2011-04-14 11:56:21 --> Output Class Initialized
DEBUG - 2011-04-14 11:56:21 --> Input Class Initialized
DEBUG - 2011-04-14 11:56:21 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-14 11:56:21 --> Language Class Initialized
DEBUG - 2011-04-14 11:56:21 --> Loader Class Initialized
DEBUG - 2011-04-14 11:56:21 --> Controller Class Initialized
ERROR - 2011-04-14 11:56:21 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-04-14 11:56:21 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-04-14 11:56:21 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-04-14 11:56:21 --> Model Class Initialized
DEBUG - 2011-04-14 11:56:21 --> Model Class Initialized
DEBUG - 2011-04-14 11:56:21 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-14 11:56:22 --> Database Driver Class Initialized
DEBUG - 2011-04-14 11:56:22 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-04-14 11:56:22 --> Helper loaded: url_helper
DEBUG - 2011-04-14 11:56:22 --> File loaded: application/views/common/header.php
DEBUG - 2011-04-14 11:56:22 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-04-14 11:56:22 --> File loaded: application/views/common/footer.php
DEBUG - 2011-04-14 11:56:22 --> File loaded: application/views/layout/main.php
DEBUG - 2011-04-14 11:56:22 --> Final output sent to browser
DEBUG - 2011-04-14 11:56:22 --> Total execution time: 0.0314
DEBUG - 2011-04-14 11:56:24 --> Config Class Initialized
DEBUG - 2011-04-14 11:56:24 --> Hooks Class Initialized
DEBUG - 2011-04-14 11:56:24 --> Utf8 Class Initialized
DEBUG - 2011-04-14 11:56:24 --> UTF-8 Support Enabled
DEBUG - 2011-04-14 11:56:24 --> URI Class Initialized
DEBUG - 2011-04-14 11:56:24 --> Router Class Initialized
DEBUG - 2011-04-14 11:56:24 --> Output Class Initialized
DEBUG - 2011-04-14 11:56:24 --> Input Class Initialized
DEBUG - 2011-04-14 11:56:24 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-14 11:56:24 --> Language Class Initialized
DEBUG - 2011-04-14 11:56:24 --> Loader Class Initialized
DEBUG - 2011-04-14 11:56:24 --> Controller Class Initialized
DEBUG - 2011-04-14 11:56:24 --> Model Class Initialized
DEBUG - 2011-04-14 11:56:24 --> Model Class Initialized
DEBUG - 2011-04-14 11:56:24 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-14 11:56:24 --> Database Driver Class Initialized
DEBUG - 2011-04-14 11:56:24 --> Final output sent to browser
DEBUG - 2011-04-14 11:56:24 --> Total execution time: 0.5034
DEBUG - 2011-04-14 11:56:27 --> Config Class Initialized
DEBUG - 2011-04-14 11:56:27 --> Hooks Class Initialized
DEBUG - 2011-04-14 11:56:27 --> Utf8 Class Initialized
DEBUG - 2011-04-14 11:56:27 --> UTF-8 Support Enabled
DEBUG - 2011-04-14 11:56:27 --> URI Class Initialized
DEBUG - 2011-04-14 11:56:27 --> Router Class Initialized
ERROR - 2011-04-14 11:56:27 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-04-14 11:56:38 --> Config Class Initialized
DEBUG - 2011-04-14 11:56:38 --> Hooks Class Initialized
DEBUG - 2011-04-14 11:56:38 --> Utf8 Class Initialized
DEBUG - 2011-04-14 11:56:38 --> UTF-8 Support Enabled
DEBUG - 2011-04-14 11:56:38 --> URI Class Initialized
DEBUG - 2011-04-14 11:56:38 --> Router Class Initialized
DEBUG - 2011-04-14 11:56:38 --> Output Class Initialized
DEBUG - 2011-04-14 11:56:38 --> Input Class Initialized
DEBUG - 2011-04-14 11:56:38 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-14 11:56:38 --> Language Class Initialized
DEBUG - 2011-04-14 11:56:38 --> Loader Class Initialized
DEBUG - 2011-04-14 11:56:38 --> Controller Class Initialized
ERROR - 2011-04-14 11:56:38 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-04-14 11:56:38 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-04-14 11:56:38 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-04-14 11:56:38 --> Model Class Initialized
DEBUG - 2011-04-14 11:56:38 --> Model Class Initialized
DEBUG - 2011-04-14 11:56:38 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-14 11:56:38 --> Database Driver Class Initialized
DEBUG - 2011-04-14 11:56:38 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-04-14 11:56:38 --> Helper loaded: url_helper
DEBUG - 2011-04-14 11:56:38 --> File loaded: application/views/common/header.php
DEBUG - 2011-04-14 11:56:38 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-04-14 11:56:38 --> File loaded: application/views/common/footer.php
DEBUG - 2011-04-14 11:56:38 --> File loaded: application/views/layout/main.php
DEBUG - 2011-04-14 11:56:38 --> Final output sent to browser
DEBUG - 2011-04-14 11:56:38 --> Total execution time: 0.0302
DEBUG - 2011-04-14 11:56:40 --> Config Class Initialized
DEBUG - 2011-04-14 11:56:40 --> Hooks Class Initialized
DEBUG - 2011-04-14 11:56:40 --> Utf8 Class Initialized
DEBUG - 2011-04-14 11:56:40 --> UTF-8 Support Enabled
DEBUG - 2011-04-14 11:56:40 --> URI Class Initialized
DEBUG - 2011-04-14 11:56:40 --> Router Class Initialized
DEBUG - 2011-04-14 11:56:40 --> Output Class Initialized
DEBUG - 2011-04-14 11:56:40 --> Input Class Initialized
DEBUG - 2011-04-14 11:56:40 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-14 11:56:40 --> Language Class Initialized
DEBUG - 2011-04-14 11:56:40 --> Loader Class Initialized
DEBUG - 2011-04-14 11:56:40 --> Controller Class Initialized
DEBUG - 2011-04-14 11:56:40 --> Model Class Initialized
DEBUG - 2011-04-14 11:56:40 --> Model Class Initialized
DEBUG - 2011-04-14 11:56:40 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-14 11:56:40 --> Database Driver Class Initialized
DEBUG - 2011-04-14 11:56:41 --> Final output sent to browser
DEBUG - 2011-04-14 11:56:41 --> Total execution time: 0.9024
DEBUG - 2011-04-14 11:56:44 --> Config Class Initialized
DEBUG - 2011-04-14 11:56:44 --> Hooks Class Initialized
DEBUG - 2011-04-14 11:56:44 --> Utf8 Class Initialized
DEBUG - 2011-04-14 11:56:44 --> UTF-8 Support Enabled
DEBUG - 2011-04-14 11:56:44 --> URI Class Initialized
DEBUG - 2011-04-14 11:56:44 --> Router Class Initialized
ERROR - 2011-04-14 11:56:44 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-04-14 11:56:53 --> Config Class Initialized
DEBUG - 2011-04-14 11:56:53 --> Hooks Class Initialized
DEBUG - 2011-04-14 11:56:53 --> Utf8 Class Initialized
DEBUG - 2011-04-14 11:56:53 --> UTF-8 Support Enabled
DEBUG - 2011-04-14 11:56:53 --> URI Class Initialized
DEBUG - 2011-04-14 11:56:53 --> Router Class Initialized
DEBUG - 2011-04-14 11:56:53 --> Output Class Initialized
DEBUG - 2011-04-14 11:56:53 --> Input Class Initialized
DEBUG - 2011-04-14 11:56:53 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-14 11:56:53 --> Language Class Initialized
DEBUG - 2011-04-14 11:56:53 --> Loader Class Initialized
DEBUG - 2011-04-14 11:56:53 --> Controller Class Initialized
ERROR - 2011-04-14 11:56:53 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-04-14 11:56:53 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-04-14 11:56:53 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-04-14 11:56:53 --> Model Class Initialized
DEBUG - 2011-04-14 11:56:53 --> Model Class Initialized
DEBUG - 2011-04-14 11:56:53 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-14 11:56:53 --> Database Driver Class Initialized
DEBUG - 2011-04-14 11:56:53 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-04-14 11:56:53 --> Helper loaded: url_helper
DEBUG - 2011-04-14 11:56:53 --> File loaded: application/views/common/header.php
DEBUG - 2011-04-14 11:56:53 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-04-14 11:56:53 --> File loaded: application/views/common/footer.php
DEBUG - 2011-04-14 11:56:53 --> File loaded: application/views/layout/main.php
DEBUG - 2011-04-14 11:56:53 --> Final output sent to browser
DEBUG - 2011-04-14 11:56:53 --> Total execution time: 0.0290
DEBUG - 2011-04-14 11:56:55 --> Config Class Initialized
DEBUG - 2011-04-14 11:56:55 --> Hooks Class Initialized
DEBUG - 2011-04-14 11:56:55 --> Utf8 Class Initialized
DEBUG - 2011-04-14 11:56:55 --> UTF-8 Support Enabled
DEBUG - 2011-04-14 11:56:55 --> URI Class Initialized
DEBUG - 2011-04-14 11:56:55 --> Router Class Initialized
DEBUG - 2011-04-14 11:56:55 --> Output Class Initialized
DEBUG - 2011-04-14 11:56:55 --> Input Class Initialized
DEBUG - 2011-04-14 11:56:55 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-14 11:56:55 --> Language Class Initialized
DEBUG - 2011-04-14 11:56:55 --> Loader Class Initialized
DEBUG - 2011-04-14 11:56:55 --> Controller Class Initialized
DEBUG - 2011-04-14 11:56:55 --> Model Class Initialized
DEBUG - 2011-04-14 11:56:55 --> Model Class Initialized
DEBUG - 2011-04-14 11:56:55 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-14 11:56:55 --> Database Driver Class Initialized
DEBUG - 2011-04-14 11:56:55 --> Final output sent to browser
DEBUG - 2011-04-14 11:56:55 --> Total execution time: 0.4582
DEBUG - 2011-04-14 11:56:58 --> Config Class Initialized
DEBUG - 2011-04-14 11:56:58 --> Hooks Class Initialized
DEBUG - 2011-04-14 11:56:58 --> Utf8 Class Initialized
DEBUG - 2011-04-14 11:56:58 --> UTF-8 Support Enabled
DEBUG - 2011-04-14 11:56:58 --> URI Class Initialized
DEBUG - 2011-04-14 11:56:58 --> Router Class Initialized
ERROR - 2011-04-14 11:56:58 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-04-14 11:57:10 --> Config Class Initialized
DEBUG - 2011-04-14 11:57:10 --> Hooks Class Initialized
DEBUG - 2011-04-14 11:57:10 --> Utf8 Class Initialized
DEBUG - 2011-04-14 11:57:10 --> UTF-8 Support Enabled
DEBUG - 2011-04-14 11:57:10 --> URI Class Initialized
DEBUG - 2011-04-14 11:57:10 --> Router Class Initialized
DEBUG - 2011-04-14 11:57:10 --> Output Class Initialized
DEBUG - 2011-04-14 11:57:10 --> Input Class Initialized
DEBUG - 2011-04-14 11:57:10 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-14 11:57:10 --> Language Class Initialized
DEBUG - 2011-04-14 11:57:10 --> Loader Class Initialized
DEBUG - 2011-04-14 11:57:10 --> Controller Class Initialized
ERROR - 2011-04-14 11:57:10 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-04-14 11:57:10 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-04-14 11:57:10 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-04-14 11:57:10 --> Model Class Initialized
DEBUG - 2011-04-14 11:57:10 --> Model Class Initialized
DEBUG - 2011-04-14 11:57:10 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-14 11:57:10 --> Database Driver Class Initialized
DEBUG - 2011-04-14 11:57:10 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-04-14 11:57:10 --> Helper loaded: url_helper
DEBUG - 2011-04-14 11:57:10 --> File loaded: application/views/common/header.php
DEBUG - 2011-04-14 11:57:10 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-04-14 11:57:10 --> File loaded: application/views/common/footer.php
DEBUG - 2011-04-14 11:57:10 --> File loaded: application/views/layout/main.php
DEBUG - 2011-04-14 11:57:10 --> Final output sent to browser
DEBUG - 2011-04-14 11:57:10 --> Total execution time: 0.1604
DEBUG - 2011-04-14 11:57:12 --> Config Class Initialized
DEBUG - 2011-04-14 11:57:12 --> Hooks Class Initialized
DEBUG - 2011-04-14 11:57:12 --> Utf8 Class Initialized
DEBUG - 2011-04-14 11:57:12 --> UTF-8 Support Enabled
DEBUG - 2011-04-14 11:57:12 --> URI Class Initialized
DEBUG - 2011-04-14 11:57:12 --> Router Class Initialized
DEBUG - 2011-04-14 11:57:12 --> Output Class Initialized
DEBUG - 2011-04-14 11:57:12 --> Input Class Initialized
DEBUG - 2011-04-14 11:57:12 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-14 11:57:12 --> Language Class Initialized
DEBUG - 2011-04-14 11:57:12 --> Loader Class Initialized
DEBUG - 2011-04-14 11:57:12 --> Controller Class Initialized
DEBUG - 2011-04-14 11:57:12 --> Model Class Initialized
DEBUG - 2011-04-14 11:57:12 --> Model Class Initialized
DEBUG - 2011-04-14 11:57:12 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-14 11:57:12 --> Database Driver Class Initialized
DEBUG - 2011-04-14 11:57:13 --> Final output sent to browser
DEBUG - 2011-04-14 11:57:13 --> Total execution time: 0.7262
DEBUG - 2011-04-14 11:57:16 --> Config Class Initialized
DEBUG - 2011-04-14 11:57:16 --> Hooks Class Initialized
DEBUG - 2011-04-14 11:57:16 --> Utf8 Class Initialized
DEBUG - 2011-04-14 11:57:16 --> UTF-8 Support Enabled
DEBUG - 2011-04-14 11:57:16 --> URI Class Initialized
DEBUG - 2011-04-14 11:57:16 --> Router Class Initialized
ERROR - 2011-04-14 11:57:16 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-04-14 11:57:27 --> Config Class Initialized
DEBUG - 2011-04-14 11:57:27 --> Hooks Class Initialized
DEBUG - 2011-04-14 11:57:27 --> Utf8 Class Initialized
DEBUG - 2011-04-14 11:57:27 --> UTF-8 Support Enabled
DEBUG - 2011-04-14 11:57:27 --> URI Class Initialized
DEBUG - 2011-04-14 11:57:27 --> Router Class Initialized
DEBUG - 2011-04-14 11:57:27 --> Output Class Initialized
DEBUG - 2011-04-14 11:57:27 --> Input Class Initialized
DEBUG - 2011-04-14 11:57:27 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-14 11:57:27 --> Language Class Initialized
DEBUG - 2011-04-14 11:57:27 --> Loader Class Initialized
DEBUG - 2011-04-14 11:57:27 --> Controller Class Initialized
ERROR - 2011-04-14 11:57:27 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-04-14 11:57:27 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-04-14 11:57:27 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-04-14 11:57:27 --> Model Class Initialized
DEBUG - 2011-04-14 11:57:27 --> Model Class Initialized
DEBUG - 2011-04-14 11:57:27 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-14 11:57:27 --> Database Driver Class Initialized
DEBUG - 2011-04-14 11:57:27 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-04-14 11:57:27 --> Helper loaded: url_helper
DEBUG - 2011-04-14 11:57:27 --> File loaded: application/views/common/header.php
DEBUG - 2011-04-14 11:57:27 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-04-14 11:57:27 --> File loaded: application/views/common/footer.php
DEBUG - 2011-04-14 11:57:27 --> File loaded: application/views/layout/main.php
DEBUG - 2011-04-14 11:57:27 --> Final output sent to browser
DEBUG - 2011-04-14 11:57:27 --> Total execution time: 0.0380
DEBUG - 2011-04-14 11:57:29 --> Config Class Initialized
DEBUG - 2011-04-14 11:57:29 --> Hooks Class Initialized
DEBUG - 2011-04-14 11:57:29 --> Utf8 Class Initialized
DEBUG - 2011-04-14 11:57:29 --> UTF-8 Support Enabled
DEBUG - 2011-04-14 11:57:29 --> URI Class Initialized
DEBUG - 2011-04-14 11:57:29 --> Router Class Initialized
DEBUG - 2011-04-14 11:57:29 --> Output Class Initialized
DEBUG - 2011-04-14 11:57:29 --> Input Class Initialized
DEBUG - 2011-04-14 11:57:29 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-14 11:57:29 --> Language Class Initialized
DEBUG - 2011-04-14 11:57:29 --> Loader Class Initialized
DEBUG - 2011-04-14 11:57:29 --> Controller Class Initialized
DEBUG - 2011-04-14 11:57:29 --> Model Class Initialized
DEBUG - 2011-04-14 11:57:29 --> Model Class Initialized
DEBUG - 2011-04-14 11:57:29 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-14 11:57:29 --> Database Driver Class Initialized
DEBUG - 2011-04-14 11:57:30 --> Final output sent to browser
DEBUG - 2011-04-14 11:57:30 --> Total execution time: 0.5115
DEBUG - 2011-04-14 11:57:33 --> Config Class Initialized
DEBUG - 2011-04-14 11:57:33 --> Hooks Class Initialized
DEBUG - 2011-04-14 11:57:33 --> Utf8 Class Initialized
DEBUG - 2011-04-14 11:57:33 --> UTF-8 Support Enabled
DEBUG - 2011-04-14 11:57:33 --> URI Class Initialized
DEBUG - 2011-04-14 11:57:33 --> Router Class Initialized
ERROR - 2011-04-14 11:57:33 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-04-14 11:57:42 --> Config Class Initialized
DEBUG - 2011-04-14 11:57:42 --> Hooks Class Initialized
DEBUG - 2011-04-14 11:57:42 --> Utf8 Class Initialized
DEBUG - 2011-04-14 11:57:42 --> UTF-8 Support Enabled
DEBUG - 2011-04-14 11:57:42 --> URI Class Initialized
DEBUG - 2011-04-14 11:57:42 --> Router Class Initialized
DEBUG - 2011-04-14 11:57:42 --> Output Class Initialized
DEBUG - 2011-04-14 11:57:42 --> Input Class Initialized
DEBUG - 2011-04-14 11:57:42 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-14 11:57:42 --> Language Class Initialized
DEBUG - 2011-04-14 11:57:42 --> Loader Class Initialized
DEBUG - 2011-04-14 11:57:42 --> Controller Class Initialized
ERROR - 2011-04-14 11:57:42 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-04-14 11:57:42 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-04-14 11:57:42 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-04-14 11:57:42 --> Model Class Initialized
DEBUG - 2011-04-14 11:57:42 --> Model Class Initialized
DEBUG - 2011-04-14 11:57:42 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-14 11:57:42 --> Database Driver Class Initialized
DEBUG - 2011-04-14 11:57:42 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-04-14 11:57:42 --> Helper loaded: url_helper
DEBUG - 2011-04-14 11:57:42 --> File loaded: application/views/common/header.php
DEBUG - 2011-04-14 11:57:42 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-04-14 11:57:42 --> File loaded: application/views/common/footer.php
DEBUG - 2011-04-14 11:57:42 --> File loaded: application/views/layout/main.php
DEBUG - 2011-04-14 11:57:42 --> Final output sent to browser
DEBUG - 2011-04-14 11:57:42 --> Total execution time: 0.0309
DEBUG - 2011-04-14 11:57:44 --> Config Class Initialized
DEBUG - 2011-04-14 11:57:44 --> Hooks Class Initialized
DEBUG - 2011-04-14 11:57:44 --> Utf8 Class Initialized
DEBUG - 2011-04-14 11:57:44 --> UTF-8 Support Enabled
DEBUG - 2011-04-14 11:57:44 --> URI Class Initialized
DEBUG - 2011-04-14 11:57:44 --> Router Class Initialized
DEBUG - 2011-04-14 11:57:44 --> Output Class Initialized
DEBUG - 2011-04-14 11:57:44 --> Input Class Initialized
DEBUG - 2011-04-14 11:57:44 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-14 11:57:44 --> Language Class Initialized
DEBUG - 2011-04-14 11:57:44 --> Loader Class Initialized
DEBUG - 2011-04-14 11:57:44 --> Controller Class Initialized
DEBUG - 2011-04-14 11:57:44 --> Model Class Initialized
DEBUG - 2011-04-14 11:57:44 --> Model Class Initialized
DEBUG - 2011-04-14 11:57:44 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-14 11:57:44 --> Database Driver Class Initialized
DEBUG - 2011-04-14 11:57:44 --> Final output sent to browser
DEBUG - 2011-04-14 11:57:44 --> Total execution time: 0.5114
DEBUG - 2011-04-14 11:57:47 --> Config Class Initialized
DEBUG - 2011-04-14 11:57:47 --> Hooks Class Initialized
DEBUG - 2011-04-14 11:57:47 --> Utf8 Class Initialized
DEBUG - 2011-04-14 11:57:47 --> UTF-8 Support Enabled
DEBUG - 2011-04-14 11:57:47 --> URI Class Initialized
DEBUG - 2011-04-14 11:57:47 --> Router Class Initialized
ERROR - 2011-04-14 11:57:47 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-04-14 11:58:04 --> Config Class Initialized
DEBUG - 2011-04-14 11:58:04 --> Hooks Class Initialized
DEBUG - 2011-04-14 11:58:04 --> Utf8 Class Initialized
DEBUG - 2011-04-14 11:58:04 --> UTF-8 Support Enabled
DEBUG - 2011-04-14 11:58:04 --> URI Class Initialized
DEBUG - 2011-04-14 11:58:04 --> Router Class Initialized
DEBUG - 2011-04-14 11:58:04 --> Output Class Initialized
DEBUG - 2011-04-14 11:58:04 --> Input Class Initialized
DEBUG - 2011-04-14 11:58:04 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-14 11:58:04 --> Language Class Initialized
DEBUG - 2011-04-14 11:58:04 --> Loader Class Initialized
DEBUG - 2011-04-14 11:58:04 --> Controller Class Initialized
ERROR - 2011-04-14 11:58:04 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-04-14 11:58:04 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-04-14 11:58:04 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-04-14 11:58:04 --> Model Class Initialized
DEBUG - 2011-04-14 11:58:04 --> Model Class Initialized
DEBUG - 2011-04-14 11:58:04 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-14 11:58:04 --> Database Driver Class Initialized
DEBUG - 2011-04-14 11:58:04 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-04-14 11:58:04 --> Helper loaded: url_helper
DEBUG - 2011-04-14 11:58:04 --> File loaded: application/views/common/header.php
DEBUG - 2011-04-14 11:58:04 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-04-14 11:58:04 --> File loaded: application/views/common/footer.php
DEBUG - 2011-04-14 11:58:04 --> File loaded: application/views/layout/main.php
DEBUG - 2011-04-14 11:58:04 --> Final output sent to browser
DEBUG - 2011-04-14 11:58:04 --> Total execution time: 0.0319
DEBUG - 2011-04-14 11:58:07 --> Config Class Initialized
DEBUG - 2011-04-14 11:58:07 --> Hooks Class Initialized
DEBUG - 2011-04-14 11:58:07 --> Utf8 Class Initialized
DEBUG - 2011-04-14 11:58:07 --> UTF-8 Support Enabled
DEBUG - 2011-04-14 11:58:07 --> URI Class Initialized
DEBUG - 2011-04-14 11:58:07 --> Router Class Initialized
DEBUG - 2011-04-14 11:58:07 --> Output Class Initialized
DEBUG - 2011-04-14 11:58:07 --> Input Class Initialized
DEBUG - 2011-04-14 11:58:07 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-14 11:58:07 --> Language Class Initialized
DEBUG - 2011-04-14 11:58:07 --> Loader Class Initialized
DEBUG - 2011-04-14 11:58:07 --> Controller Class Initialized
DEBUG - 2011-04-14 11:58:07 --> Model Class Initialized
DEBUG - 2011-04-14 11:58:07 --> Model Class Initialized
DEBUG - 2011-04-14 11:58:07 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-14 11:58:07 --> Database Driver Class Initialized
DEBUG - 2011-04-14 11:58:07 --> Final output sent to browser
DEBUG - 2011-04-14 11:58:07 --> Total execution time: 0.4862
DEBUG - 2011-04-14 11:58:10 --> Config Class Initialized
DEBUG - 2011-04-14 11:58:10 --> Hooks Class Initialized
DEBUG - 2011-04-14 11:58:10 --> Utf8 Class Initialized
DEBUG - 2011-04-14 11:58:10 --> UTF-8 Support Enabled
DEBUG - 2011-04-14 11:58:10 --> URI Class Initialized
DEBUG - 2011-04-14 11:58:10 --> Router Class Initialized
ERROR - 2011-04-14 11:58:10 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-04-14 12:01:26 --> Config Class Initialized
DEBUG - 2011-04-14 12:01:26 --> Hooks Class Initialized
DEBUG - 2011-04-14 12:01:26 --> Utf8 Class Initialized
DEBUG - 2011-04-14 12:01:26 --> UTF-8 Support Enabled
DEBUG - 2011-04-14 12:01:26 --> URI Class Initialized
DEBUG - 2011-04-14 12:01:26 --> Router Class Initialized
DEBUG - 2011-04-14 12:01:26 --> Output Class Initialized
DEBUG - 2011-04-14 12:01:26 --> Config Class Initialized
DEBUG - 2011-04-14 12:01:26 --> Hooks Class Initialized
DEBUG - 2011-04-14 12:01:26 --> Input Class Initialized
DEBUG - 2011-04-14 12:01:26 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-14 12:01:26 --> Language Class Initialized
DEBUG - 2011-04-14 12:01:26 --> Loader Class Initialized
DEBUG - 2011-04-14 12:01:26 --> Controller Class Initialized
DEBUG - 2011-04-14 12:01:26 --> Utf8 Class Initialized
DEBUG - 2011-04-14 12:01:26 --> UTF-8 Support Enabled
DEBUG - 2011-04-14 12:01:26 --> URI Class Initialized
DEBUG - 2011-04-14 12:01:26 --> Router Class Initialized
DEBUG - 2011-04-14 12:01:26 --> Output Class Initialized
DEBUG - 2011-04-14 12:01:26 --> Input Class Initialized
DEBUG - 2011-04-14 12:01:26 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-14 12:01:26 --> Language Class Initialized
DEBUG - 2011-04-14 12:01:26 --> Loader Class Initialized
DEBUG - 2011-04-14 12:01:26 --> Controller Class Initialized
ERROR - 2011-04-14 12:01:26 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-04-14 12:01:26 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-04-14 12:01:26 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-04-14 12:01:26 --> Model Class Initialized
DEBUG - 2011-04-14 12:01:26 --> Model Class Initialized
DEBUG - 2011-04-14 12:01:26 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-14 12:01:26 --> Model Class Initialized
DEBUG - 2011-04-14 12:01:26 --> Database Driver Class Initialized
DEBUG - 2011-04-14 12:01:26 --> Model Class Initialized
DEBUG - 2011-04-14 12:01:26 --> Model Class Initialized
DEBUG - 2011-04-14 12:01:26 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-14 12:01:26 --> Database Driver Class Initialized
DEBUG - 2011-04-14 12:01:26 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-04-14 12:01:26 --> Helper loaded: url_helper
DEBUG - 2011-04-14 12:01:26 --> File loaded: application/views/common/header.php
DEBUG - 2011-04-14 12:01:26 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-04-14 12:01:26 --> File loaded: application/views/common/footer.php
DEBUG - 2011-04-14 12:01:26 --> File loaded: application/views/layout/main.php
DEBUG - 2011-04-14 12:01:26 --> Final output sent to browser
DEBUG - 2011-04-14 12:01:26 --> Total execution time: 0.0911
DEBUG - 2011-04-14 12:01:26 --> File loaded: application/views/table/main.php
DEBUG - 2011-04-14 12:01:26 --> Helper loaded: url_helper
DEBUG - 2011-04-14 12:01:26 --> File loaded: application/views/common/header.php
DEBUG - 2011-04-14 12:01:26 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-04-14 12:01:26 --> File loaded: application/views/common/footer.php
DEBUG - 2011-04-14 12:01:26 --> File loaded: application/views/layout/main.php
DEBUG - 2011-04-14 12:01:26 --> Final output sent to browser
DEBUG - 2011-04-14 12:01:26 --> Total execution time: 0.3712
DEBUG - 2011-04-14 12:39:22 --> Config Class Initialized
DEBUG - 2011-04-14 12:39:22 --> Hooks Class Initialized
DEBUG - 2011-04-14 12:39:23 --> Utf8 Class Initialized
DEBUG - 2011-04-14 12:39:23 --> UTF-8 Support Enabled
DEBUG - 2011-04-14 12:39:23 --> URI Class Initialized
DEBUG - 2011-04-14 12:39:23 --> Router Class Initialized
DEBUG - 2011-04-14 12:39:23 --> Output Class Initialized
DEBUG - 2011-04-14 12:39:23 --> Input Class Initialized
DEBUG - 2011-04-14 12:39:23 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-14 12:39:23 --> Language Class Initialized
DEBUG - 2011-04-14 12:39:23 --> Loader Class Initialized
DEBUG - 2011-04-14 12:39:23 --> Controller Class Initialized
ERROR - 2011-04-14 12:39:23 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-04-14 12:39:23 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-04-14 12:39:23 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-04-14 12:39:23 --> Model Class Initialized
DEBUG - 2011-04-14 12:39:23 --> Model Class Initialized
DEBUG - 2011-04-14 12:39:23 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-14 12:39:23 --> Database Driver Class Initialized
DEBUG - 2011-04-14 12:39:24 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-04-14 12:39:24 --> Helper loaded: url_helper
DEBUG - 2011-04-14 12:39:24 --> File loaded: application/views/common/header.php
DEBUG - 2011-04-14 12:39:24 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-04-14 12:39:24 --> File loaded: application/views/common/footer.php
DEBUG - 2011-04-14 12:39:24 --> File loaded: application/views/layout/main.php
DEBUG - 2011-04-14 12:39:24 --> Final output sent to browser
DEBUG - 2011-04-14 12:39:24 --> Total execution time: 2.2971
DEBUG - 2011-04-14 12:39:26 --> Config Class Initialized
DEBUG - 2011-04-14 12:39:26 --> Hooks Class Initialized
DEBUG - 2011-04-14 12:39:26 --> Utf8 Class Initialized
DEBUG - 2011-04-14 12:39:26 --> UTF-8 Support Enabled
DEBUG - 2011-04-14 12:39:26 --> URI Class Initialized
DEBUG - 2011-04-14 12:39:26 --> Router Class Initialized
DEBUG - 2011-04-14 12:39:26 --> Output Class Initialized
DEBUG - 2011-04-14 12:39:26 --> Input Class Initialized
DEBUG - 2011-04-14 12:39:26 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-14 12:39:26 --> Language Class Initialized
DEBUG - 2011-04-14 12:39:26 --> Loader Class Initialized
DEBUG - 2011-04-14 12:39:26 --> Controller Class Initialized
DEBUG - 2011-04-14 12:39:26 --> Model Class Initialized
DEBUG - 2011-04-14 12:39:26 --> Model Class Initialized
DEBUG - 2011-04-14 12:39:26 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-14 12:39:26 --> Database Driver Class Initialized
DEBUG - 2011-04-14 12:39:27 --> Final output sent to browser
DEBUG - 2011-04-14 12:39:27 --> Total execution time: 0.7448
DEBUG - 2011-04-14 12:39:30 --> Config Class Initialized
DEBUG - 2011-04-14 12:39:30 --> Hooks Class Initialized
DEBUG - 2011-04-14 12:39:30 --> Utf8 Class Initialized
DEBUG - 2011-04-14 12:39:30 --> UTF-8 Support Enabled
DEBUG - 2011-04-14 12:39:30 --> URI Class Initialized
DEBUG - 2011-04-14 12:39:30 --> Router Class Initialized
ERROR - 2011-04-14 12:39:30 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-04-14 12:39:31 --> Config Class Initialized
DEBUG - 2011-04-14 12:39:31 --> Hooks Class Initialized
DEBUG - 2011-04-14 12:39:31 --> Utf8 Class Initialized
DEBUG - 2011-04-14 12:39:31 --> UTF-8 Support Enabled
DEBUG - 2011-04-14 12:39:31 --> URI Class Initialized
DEBUG - 2011-04-14 12:39:31 --> Router Class Initialized
ERROR - 2011-04-14 12:39:31 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-04-14 12:40:05 --> Config Class Initialized
DEBUG - 2011-04-14 12:40:05 --> Hooks Class Initialized
DEBUG - 2011-04-14 12:40:05 --> Utf8 Class Initialized
DEBUG - 2011-04-14 12:40:05 --> UTF-8 Support Enabled
DEBUG - 2011-04-14 12:40:05 --> URI Class Initialized
DEBUG - 2011-04-14 12:40:05 --> Router Class Initialized
DEBUG - 2011-04-14 12:40:05 --> Output Class Initialized
DEBUG - 2011-04-14 12:40:05 --> Input Class Initialized
DEBUG - 2011-04-14 12:40:05 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-14 12:40:05 --> Language Class Initialized
DEBUG - 2011-04-14 12:40:05 --> Loader Class Initialized
DEBUG - 2011-04-14 12:40:05 --> Controller Class Initialized
ERROR - 2011-04-14 12:40:05 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-04-14 12:40:05 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-04-14 12:40:05 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-04-14 12:40:05 --> Model Class Initialized
DEBUG - 2011-04-14 12:40:05 --> Model Class Initialized
DEBUG - 2011-04-14 12:40:05 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-14 12:40:05 --> Database Driver Class Initialized
DEBUG - 2011-04-14 12:40:05 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-04-14 12:40:05 --> Helper loaded: url_helper
DEBUG - 2011-04-14 12:40:05 --> File loaded: application/views/common/header.php
DEBUG - 2011-04-14 12:40:05 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-04-14 12:40:05 --> File loaded: application/views/common/footer.php
DEBUG - 2011-04-14 12:40:05 --> File loaded: application/views/layout/main.php
DEBUG - 2011-04-14 12:40:05 --> Final output sent to browser
DEBUG - 2011-04-14 12:40:05 --> Total execution time: 0.0298
DEBUG - 2011-04-14 12:40:07 --> Config Class Initialized
DEBUG - 2011-04-14 12:40:07 --> Hooks Class Initialized
DEBUG - 2011-04-14 12:40:07 --> Utf8 Class Initialized
DEBUG - 2011-04-14 12:40:07 --> UTF-8 Support Enabled
DEBUG - 2011-04-14 12:40:07 --> URI Class Initialized
DEBUG - 2011-04-14 12:40:07 --> Router Class Initialized
DEBUG - 2011-04-14 12:40:07 --> Output Class Initialized
DEBUG - 2011-04-14 12:40:07 --> Input Class Initialized
DEBUG - 2011-04-14 12:40:07 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-14 12:40:08 --> Language Class Initialized
DEBUG - 2011-04-14 12:40:08 --> Loader Class Initialized
DEBUG - 2011-04-14 12:40:08 --> Controller Class Initialized
DEBUG - 2011-04-14 12:40:08 --> Model Class Initialized
DEBUG - 2011-04-14 12:40:08 --> Model Class Initialized
DEBUG - 2011-04-14 12:40:08 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-14 12:40:08 --> Database Driver Class Initialized
DEBUG - 2011-04-14 12:40:08 --> Final output sent to browser
DEBUG - 2011-04-14 12:40:08 --> Total execution time: 0.6487
DEBUG - 2011-04-14 12:51:09 --> Config Class Initialized
DEBUG - 2011-04-14 12:51:09 --> Hooks Class Initialized
DEBUG - 2011-04-14 12:51:09 --> Utf8 Class Initialized
DEBUG - 2011-04-14 12:51:09 --> UTF-8 Support Enabled
DEBUG - 2011-04-14 12:51:09 --> URI Class Initialized
DEBUG - 2011-04-14 12:51:09 --> Router Class Initialized
DEBUG - 2011-04-14 12:51:09 --> Output Class Initialized
DEBUG - 2011-04-14 12:51:09 --> Input Class Initialized
DEBUG - 2011-04-14 12:51:09 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-14 12:51:09 --> Language Class Initialized
DEBUG - 2011-04-14 12:51:09 --> Loader Class Initialized
DEBUG - 2011-04-14 12:51:09 --> Controller Class Initialized
DEBUG - 2011-04-14 12:51:09 --> Model Class Initialized
DEBUG - 2011-04-14 12:51:09 --> Model Class Initialized
DEBUG - 2011-04-14 12:51:09 --> Model Class Initialized
DEBUG - 2011-04-14 12:51:09 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-14 12:51:09 --> Database Driver Class Initialized
DEBUG - 2011-04-14 12:51:10 --> File loaded: application/views/table/main.php
DEBUG - 2011-04-14 12:51:10 --> Helper loaded: url_helper
DEBUG - 2011-04-14 12:51:10 --> File loaded: application/views/common/header.php
DEBUG - 2011-04-14 12:51:10 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-04-14 12:51:10 --> File loaded: application/views/common/footer.php
DEBUG - 2011-04-14 12:51:10 --> File loaded: application/views/layout/main.php
DEBUG - 2011-04-14 12:51:10 --> Final output sent to browser
DEBUG - 2011-04-14 12:51:10 --> Total execution time: 0.3533
DEBUG - 2011-04-14 12:51:11 --> Config Class Initialized
DEBUG - 2011-04-14 12:51:11 --> Hooks Class Initialized
DEBUG - 2011-04-14 12:51:11 --> Utf8 Class Initialized
DEBUG - 2011-04-14 12:51:11 --> UTF-8 Support Enabled
DEBUG - 2011-04-14 12:51:11 --> URI Class Initialized
DEBUG - 2011-04-14 12:51:11 --> Router Class Initialized
DEBUG - 2011-04-14 12:51:11 --> Output Class Initialized
DEBUG - 2011-04-14 12:51:11 --> Input Class Initialized
DEBUG - 2011-04-14 12:51:11 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-14 12:51:11 --> Language Class Initialized
DEBUG - 2011-04-14 12:51:11 --> Loader Class Initialized
DEBUG - 2011-04-14 12:51:11 --> Controller Class Initialized
DEBUG - 2011-04-14 12:51:11 --> Model Class Initialized
DEBUG - 2011-04-14 12:51:11 --> Model Class Initialized
DEBUG - 2011-04-14 12:51:11 --> Model Class Initialized
DEBUG - 2011-04-14 12:51:11 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-14 12:51:11 --> Database Driver Class Initialized
DEBUG - 2011-04-14 12:51:11 --> File loaded: application/views/table/main.php
DEBUG - 2011-04-14 12:51:11 --> Helper loaded: url_helper
DEBUG - 2011-04-14 12:51:11 --> File loaded: application/views/common/header.php
DEBUG - 2011-04-14 12:51:11 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-04-14 12:51:11 --> File loaded: application/views/common/footer.php
DEBUG - 2011-04-14 12:51:11 --> File loaded: application/views/layout/main.php
DEBUG - 2011-04-14 12:51:11 --> Final output sent to browser
DEBUG - 2011-04-14 12:51:11 --> Total execution time: 0.0742
DEBUG - 2011-04-14 12:51:11 --> Config Class Initialized
DEBUG - 2011-04-14 12:51:11 --> Hooks Class Initialized
DEBUG - 2011-04-14 12:51:11 --> Utf8 Class Initialized
DEBUG - 2011-04-14 12:51:11 --> UTF-8 Support Enabled
DEBUG - 2011-04-14 12:51:11 --> URI Class Initialized
DEBUG - 2011-04-14 12:51:11 --> Router Class Initialized
ERROR - 2011-04-14 12:51:11 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-04-14 12:51:13 --> Config Class Initialized
DEBUG - 2011-04-14 12:51:13 --> Hooks Class Initialized
DEBUG - 2011-04-14 12:51:13 --> Utf8 Class Initialized
DEBUG - 2011-04-14 12:51:13 --> UTF-8 Support Enabled
DEBUG - 2011-04-14 12:51:13 --> URI Class Initialized
DEBUG - 2011-04-14 12:51:13 --> Router Class Initialized
ERROR - 2011-04-14 12:51:13 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-04-14 12:51:16 --> Config Class Initialized
DEBUG - 2011-04-14 12:51:16 --> Hooks Class Initialized
DEBUG - 2011-04-14 12:51:16 --> Utf8 Class Initialized
DEBUG - 2011-04-14 12:51:16 --> UTF-8 Support Enabled
DEBUG - 2011-04-14 12:51:16 --> URI Class Initialized
DEBUG - 2011-04-14 12:51:16 --> Router Class Initialized
DEBUG - 2011-04-14 12:51:16 --> Output Class Initialized
DEBUG - 2011-04-14 12:51:16 --> Input Class Initialized
DEBUG - 2011-04-14 12:51:16 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-14 12:51:16 --> Language Class Initialized
DEBUG - 2011-04-14 12:51:16 --> Loader Class Initialized
DEBUG - 2011-04-14 12:51:16 --> Controller Class Initialized
DEBUG - 2011-04-14 12:51:16 --> Model Class Initialized
DEBUG - 2011-04-14 12:51:16 --> Model Class Initialized
DEBUG - 2011-04-14 12:51:16 --> Model Class Initialized
DEBUG - 2011-04-14 12:51:16 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-14 12:51:16 --> Database Driver Class Initialized
DEBUG - 2011-04-14 12:51:17 --> File loaded: application/views/table/main.php
DEBUG - 2011-04-14 12:51:17 --> Helper loaded: url_helper
DEBUG - 2011-04-14 12:51:17 --> File loaded: application/views/common/header.php
DEBUG - 2011-04-14 12:51:17 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-04-14 12:51:17 --> File loaded: application/views/common/footer.php
DEBUG - 2011-04-14 12:51:17 --> File loaded: application/views/layout/main.php
DEBUG - 2011-04-14 12:51:17 --> Final output sent to browser
DEBUG - 2011-04-14 12:51:17 --> Total execution time: 0.3144
DEBUG - 2011-04-14 12:51:18 --> Config Class Initialized
DEBUG - 2011-04-14 12:51:18 --> Hooks Class Initialized
DEBUG - 2011-04-14 12:51:18 --> Utf8 Class Initialized
DEBUG - 2011-04-14 12:51:18 --> UTF-8 Support Enabled
DEBUG - 2011-04-14 12:51:18 --> URI Class Initialized
DEBUG - 2011-04-14 12:51:18 --> Router Class Initialized
DEBUG - 2011-04-14 12:51:18 --> Output Class Initialized
DEBUG - 2011-04-14 12:51:18 --> Input Class Initialized
DEBUG - 2011-04-14 12:51:18 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-14 12:51:18 --> Language Class Initialized
DEBUG - 2011-04-14 12:51:18 --> Loader Class Initialized
DEBUG - 2011-04-14 12:51:18 --> Controller Class Initialized
DEBUG - 2011-04-14 12:51:18 --> Model Class Initialized
DEBUG - 2011-04-14 12:51:18 --> Model Class Initialized
DEBUG - 2011-04-14 12:51:18 --> Model Class Initialized
DEBUG - 2011-04-14 12:51:18 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-14 12:51:18 --> Database Driver Class Initialized
DEBUG - 2011-04-14 12:51:18 --> File loaded: application/views/table/main.php
DEBUG - 2011-04-14 12:51:18 --> Helper loaded: url_helper
DEBUG - 2011-04-14 12:51:18 --> File loaded: application/views/common/header.php
DEBUG - 2011-04-14 12:51:18 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-04-14 12:51:18 --> File loaded: application/views/common/footer.php
DEBUG - 2011-04-14 12:51:18 --> File loaded: application/views/layout/main.php
DEBUG - 2011-04-14 12:51:18 --> Final output sent to browser
DEBUG - 2011-04-14 12:51:18 --> Total execution time: 0.0442
DEBUG - 2011-04-14 12:51:40 --> Config Class Initialized
DEBUG - 2011-04-14 12:51:40 --> Hooks Class Initialized
DEBUG - 2011-04-14 12:51:40 --> Utf8 Class Initialized
DEBUG - 2011-04-14 12:51:40 --> UTF-8 Support Enabled
DEBUG - 2011-04-14 12:51:40 --> URI Class Initialized
DEBUG - 2011-04-14 12:51:40 --> Router Class Initialized
DEBUG - 2011-04-14 12:51:40 --> Output Class Initialized
DEBUG - 2011-04-14 12:51:40 --> Input Class Initialized
DEBUG - 2011-04-14 12:51:40 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-14 12:51:40 --> Language Class Initialized
DEBUG - 2011-04-14 12:51:40 --> Loader Class Initialized
DEBUG - 2011-04-14 12:51:40 --> Controller Class Initialized
DEBUG - 2011-04-14 12:51:40 --> Model Class Initialized
DEBUG - 2011-04-14 12:51:40 --> Model Class Initialized
DEBUG - 2011-04-14 12:51:40 --> Model Class Initialized
DEBUG - 2011-04-14 12:51:40 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-14 12:51:40 --> Database Driver Class Initialized
DEBUG - 2011-04-14 12:51:40 --> File loaded: application/views/table/main.php
DEBUG - 2011-04-14 12:51:40 --> Helper loaded: url_helper
DEBUG - 2011-04-14 12:51:40 --> File loaded: application/views/common/header.php
DEBUG - 2011-04-14 12:51:40 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-04-14 12:51:40 --> File loaded: application/views/common/footer.php
DEBUG - 2011-04-14 12:51:40 --> File loaded: application/views/layout/main.php
DEBUG - 2011-04-14 12:51:40 --> Final output sent to browser
DEBUG - 2011-04-14 12:51:40 --> Total execution time: 0.2282
DEBUG - 2011-04-14 12:51:42 --> Config Class Initialized
DEBUG - 2011-04-14 12:51:42 --> Hooks Class Initialized
DEBUG - 2011-04-14 12:51:42 --> Utf8 Class Initialized
DEBUG - 2011-04-14 12:51:42 --> UTF-8 Support Enabled
DEBUG - 2011-04-14 12:51:42 --> URI Class Initialized
DEBUG - 2011-04-14 12:51:42 --> Router Class Initialized
DEBUG - 2011-04-14 12:51:42 --> Output Class Initialized
DEBUG - 2011-04-14 12:51:42 --> Input Class Initialized
DEBUG - 2011-04-14 12:51:42 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-14 12:51:42 --> Language Class Initialized
DEBUG - 2011-04-14 12:51:42 --> Loader Class Initialized
DEBUG - 2011-04-14 12:51:42 --> Controller Class Initialized
DEBUG - 2011-04-14 12:51:42 --> Model Class Initialized
DEBUG - 2011-04-14 12:51:42 --> Model Class Initialized
DEBUG - 2011-04-14 12:51:42 --> Model Class Initialized
DEBUG - 2011-04-14 12:51:42 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-14 12:51:42 --> Database Driver Class Initialized
DEBUG - 2011-04-14 12:51:42 --> File loaded: application/views/table/main.php
DEBUG - 2011-04-14 12:51:42 --> Helper loaded: url_helper
DEBUG - 2011-04-14 12:51:42 --> File loaded: application/views/common/header.php
DEBUG - 2011-04-14 12:51:42 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-04-14 12:51:42 --> File loaded: application/views/common/footer.php
DEBUG - 2011-04-14 12:51:42 --> File loaded: application/views/layout/main.php
DEBUG - 2011-04-14 12:51:42 --> Final output sent to browser
DEBUG - 2011-04-14 12:51:42 --> Total execution time: 0.1594
DEBUG - 2011-04-14 12:51:53 --> Config Class Initialized
DEBUG - 2011-04-14 12:51:53 --> Hooks Class Initialized
DEBUG - 2011-04-14 12:51:53 --> Utf8 Class Initialized
DEBUG - 2011-04-14 12:51:53 --> UTF-8 Support Enabled
DEBUG - 2011-04-14 12:51:53 --> URI Class Initialized
DEBUG - 2011-04-14 12:51:53 --> Router Class Initialized
DEBUG - 2011-04-14 12:51:53 --> Output Class Initialized
DEBUG - 2011-04-14 12:51:53 --> Input Class Initialized
DEBUG - 2011-04-14 12:51:53 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-14 12:51:53 --> Language Class Initialized
DEBUG - 2011-04-14 12:51:53 --> Loader Class Initialized
DEBUG - 2011-04-14 12:51:53 --> Controller Class Initialized
DEBUG - 2011-04-14 12:51:53 --> Model Class Initialized
DEBUG - 2011-04-14 12:51:53 --> Model Class Initialized
DEBUG - 2011-04-14 12:51:53 --> Model Class Initialized
DEBUG - 2011-04-14 12:51:53 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-14 12:51:53 --> Database Driver Class Initialized
DEBUG - 2011-04-14 12:51:54 --> File loaded: application/views/table/main.php
DEBUG - 2011-04-14 12:51:54 --> Helper loaded: url_helper
DEBUG - 2011-04-14 12:51:54 --> File loaded: application/views/common/header.php
DEBUG - 2011-04-14 12:51:54 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-04-14 12:51:54 --> File loaded: application/views/common/footer.php
DEBUG - 2011-04-14 12:51:54 --> File loaded: application/views/layout/main.php
DEBUG - 2011-04-14 12:51:54 --> Final output sent to browser
DEBUG - 2011-04-14 12:51:54 --> Total execution time: 0.8836
DEBUG - 2011-04-14 12:52:10 --> Config Class Initialized
DEBUG - 2011-04-14 12:52:10 --> Hooks Class Initialized
DEBUG - 2011-04-14 12:52:10 --> Utf8 Class Initialized
DEBUG - 2011-04-14 12:52:10 --> UTF-8 Support Enabled
DEBUG - 2011-04-14 12:52:10 --> URI Class Initialized
DEBUG - 2011-04-14 12:52:10 --> Router Class Initialized
DEBUG - 2011-04-14 12:52:10 --> Output Class Initialized
DEBUG - 2011-04-14 12:52:10 --> Input Class Initialized
DEBUG - 2011-04-14 12:52:10 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-14 12:52:10 --> Language Class Initialized
DEBUG - 2011-04-14 12:52:10 --> Loader Class Initialized
DEBUG - 2011-04-14 12:52:10 --> Controller Class Initialized
ERROR - 2011-04-14 12:52:10 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-04-14 12:52:10 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-04-14 12:52:10 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-04-14 12:52:10 --> Model Class Initialized
DEBUG - 2011-04-14 12:52:10 --> Model Class Initialized
DEBUG - 2011-04-14 12:52:10 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-14 12:52:10 --> Database Driver Class Initialized
DEBUG - 2011-04-14 12:52:10 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-04-14 12:52:10 --> Helper loaded: url_helper
DEBUG - 2011-04-14 12:52:10 --> File loaded: application/views/common/header.php
DEBUG - 2011-04-14 12:52:10 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-04-14 12:52:10 --> File loaded: application/views/common/footer.php
DEBUG - 2011-04-14 12:52:10 --> File loaded: application/views/layout/main.php
DEBUG - 2011-04-14 12:52:10 --> Final output sent to browser
DEBUG - 2011-04-14 12:52:10 --> Total execution time: 0.0283
DEBUG - 2011-04-14 12:52:11 --> Config Class Initialized
DEBUG - 2011-04-14 12:52:11 --> Hooks Class Initialized
DEBUG - 2011-04-14 12:52:11 --> Utf8 Class Initialized
DEBUG - 2011-04-14 12:52:11 --> UTF-8 Support Enabled
DEBUG - 2011-04-14 12:52:11 --> URI Class Initialized
DEBUG - 2011-04-14 12:52:11 --> Router Class Initialized
DEBUG - 2011-04-14 12:52:11 --> Output Class Initialized
DEBUG - 2011-04-14 12:52:11 --> Input Class Initialized
DEBUG - 2011-04-14 12:52:11 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-14 12:52:11 --> Language Class Initialized
DEBUG - 2011-04-14 12:52:11 --> Loader Class Initialized
DEBUG - 2011-04-14 12:52:11 --> Controller Class Initialized
DEBUG - 2011-04-14 12:52:11 --> Model Class Initialized
DEBUG - 2011-04-14 12:52:11 --> Model Class Initialized
DEBUG - 2011-04-14 12:52:11 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-14 12:52:11 --> Database Driver Class Initialized
DEBUG - 2011-04-14 12:52:11 --> Final output sent to browser
DEBUG - 2011-04-14 12:52:11 --> Total execution time: 0.5014
DEBUG - 2011-04-14 13:00:38 --> Config Class Initialized
DEBUG - 2011-04-14 13:00:38 --> Hooks Class Initialized
DEBUG - 2011-04-14 13:00:38 --> Utf8 Class Initialized
DEBUG - 2011-04-14 13:00:38 --> UTF-8 Support Enabled
DEBUG - 2011-04-14 13:00:38 --> URI Class Initialized
DEBUG - 2011-04-14 13:00:38 --> Router Class Initialized
DEBUG - 2011-04-14 13:00:38 --> Output Class Initialized
DEBUG - 2011-04-14 13:00:38 --> Input Class Initialized
DEBUG - 2011-04-14 13:00:38 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-14 13:00:38 --> Language Class Initialized
DEBUG - 2011-04-14 13:00:38 --> Loader Class Initialized
DEBUG - 2011-04-14 13:00:38 --> Controller Class Initialized
ERROR - 2011-04-14 13:00:39 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-04-14 13:00:39 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-04-14 13:00:39 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-04-14 13:00:39 --> Model Class Initialized
DEBUG - 2011-04-14 13:00:39 --> Model Class Initialized
DEBUG - 2011-04-14 13:00:39 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-14 13:00:39 --> Database Driver Class Initialized
DEBUG - 2011-04-14 13:00:39 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-04-14 13:00:41 --> Helper loaded: url_helper
DEBUG - 2011-04-14 13:00:41 --> File loaded: application/views/common/header.php
DEBUG - 2011-04-14 13:00:41 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-04-14 13:00:41 --> File loaded: application/views/common/footer.php
DEBUG - 2011-04-14 13:00:41 --> File loaded: application/views/layout/main.php
DEBUG - 2011-04-14 13:00:41 --> Final output sent to browser
DEBUG - 2011-04-14 13:00:41 --> Total execution time: 5.6700
DEBUG - 2011-04-14 13:09:44 --> Config Class Initialized
DEBUG - 2011-04-14 13:09:44 --> Hooks Class Initialized
DEBUG - 2011-04-14 13:09:44 --> Utf8 Class Initialized
DEBUG - 2011-04-14 13:09:44 --> UTF-8 Support Enabled
DEBUG - 2011-04-14 13:09:44 --> URI Class Initialized
DEBUG - 2011-04-14 13:09:44 --> Router Class Initialized
ERROR - 2011-04-14 13:09:44 --> 404 Page Not Found --> robots.txt
DEBUG - 2011-04-14 13:09:50 --> Config Class Initialized
DEBUG - 2011-04-14 13:09:50 --> Hooks Class Initialized
DEBUG - 2011-04-14 13:09:50 --> Utf8 Class Initialized
DEBUG - 2011-04-14 13:09:50 --> UTF-8 Support Enabled
DEBUG - 2011-04-14 13:09:50 --> URI Class Initialized
DEBUG - 2011-04-14 13:09:50 --> Router Class Initialized
DEBUG - 2011-04-14 13:09:50 --> Output Class Initialized
DEBUG - 2011-04-14 13:09:50 --> Input Class Initialized
DEBUG - 2011-04-14 13:09:50 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-14 13:09:50 --> Language Class Initialized
DEBUG - 2011-04-14 13:09:50 --> Loader Class Initialized
DEBUG - 2011-04-14 13:09:50 --> Controller Class Initialized
DEBUG - 2011-04-14 13:09:50 --> Model Class Initialized
DEBUG - 2011-04-14 13:09:51 --> Model Class Initialized
DEBUG - 2011-04-14 13:09:51 --> Model Class Initialized
DEBUG - 2011-04-14 13:09:51 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-14 13:09:51 --> Database Driver Class Initialized
DEBUG - 2011-04-14 13:09:51 --> File loaded: application/views/table/main.php
DEBUG - 2011-04-14 13:09:51 --> Helper loaded: url_helper
DEBUG - 2011-04-14 13:09:51 --> File loaded: application/views/common/header.php
DEBUG - 2011-04-14 13:09:51 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-04-14 13:09:51 --> File loaded: application/views/common/footer.php
DEBUG - 2011-04-14 13:09:51 --> File loaded: application/views/layout/main.php
DEBUG - 2011-04-14 13:09:51 --> Final output sent to browser
DEBUG - 2011-04-14 13:09:51 --> Total execution time: 0.4855
DEBUG - 2011-04-14 13:52:41 --> Config Class Initialized
DEBUG - 2011-04-14 13:52:41 --> Hooks Class Initialized
DEBUG - 2011-04-14 13:52:41 --> Utf8 Class Initialized
DEBUG - 2011-04-14 13:52:41 --> UTF-8 Support Enabled
DEBUG - 2011-04-14 13:52:41 --> URI Class Initialized
DEBUG - 2011-04-14 13:52:41 --> Router Class Initialized
DEBUG - 2011-04-14 13:52:41 --> No URI present. Default controller set.
DEBUG - 2011-04-14 13:52:41 --> Output Class Initialized
DEBUG - 2011-04-14 13:52:41 --> Input Class Initialized
DEBUG - 2011-04-14 13:52:41 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-14 13:52:41 --> Language Class Initialized
DEBUG - 2011-04-14 13:52:41 --> Loader Class Initialized
DEBUG - 2011-04-14 13:52:41 --> Controller Class Initialized
DEBUG - 2011-04-14 13:52:41 --> File loaded: application/views/splash/main.php
DEBUG - 2011-04-14 13:52:41 --> Helper loaded: url_helper
DEBUG - 2011-04-14 13:52:41 --> File loaded: application/views/common/header.php
DEBUG - 2011-04-14 13:52:41 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-04-14 13:52:41 --> File loaded: application/views/common/footer.php
DEBUG - 2011-04-14 13:52:41 --> File loaded: application/views/layout/main.php
DEBUG - 2011-04-14 13:52:41 --> Final output sent to browser
DEBUG - 2011-04-14 13:52:41 --> Total execution time: 0.3013
DEBUG - 2011-04-14 14:19:28 --> Config Class Initialized
DEBUG - 2011-04-14 14:19:28 --> Hooks Class Initialized
DEBUG - 2011-04-14 14:19:28 --> Utf8 Class Initialized
DEBUG - 2011-04-14 14:19:28 --> UTF-8 Support Enabled
DEBUG - 2011-04-14 14:19:28 --> URI Class Initialized
DEBUG - 2011-04-14 14:19:28 --> Router Class Initialized
DEBUG - 2011-04-14 14:19:28 --> Output Class Initialized
DEBUG - 2011-04-14 14:19:28 --> Input Class Initialized
DEBUG - 2011-04-14 14:19:28 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-14 14:19:28 --> Language Class Initialized
DEBUG - 2011-04-14 14:19:29 --> Loader Class Initialized
DEBUG - 2011-04-14 14:19:29 --> Controller Class Initialized
DEBUG - 2011-04-14 14:19:29 --> Model Class Initialized
DEBUG - 2011-04-14 14:19:29 --> Model Class Initialized
DEBUG - 2011-04-14 14:19:29 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-14 14:19:29 --> Database Driver Class Initialized
DEBUG - 2011-04-14 14:19:29 --> Final output sent to browser
DEBUG - 2011-04-14 14:19:29 --> Total execution time: 0.9000
DEBUG - 2011-04-14 15:48:37 --> Config Class Initialized
DEBUG - 2011-04-14 15:48:37 --> Hooks Class Initialized
DEBUG - 2011-04-14 15:48:37 --> Utf8 Class Initialized
DEBUG - 2011-04-14 15:48:37 --> UTF-8 Support Enabled
DEBUG - 2011-04-14 15:48:37 --> URI Class Initialized
DEBUG - 2011-04-14 15:48:37 --> Router Class Initialized
DEBUG - 2011-04-14 15:48:37 --> Output Class Initialized
DEBUG - 2011-04-14 15:48:37 --> Input Class Initialized
DEBUG - 2011-04-14 15:48:37 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-14 15:48:37 --> Language Class Initialized
DEBUG - 2011-04-14 15:48:37 --> Loader Class Initialized
DEBUG - 2011-04-14 15:48:37 --> Controller Class Initialized
DEBUG - 2011-04-14 15:48:37 --> Model Class Initialized
DEBUG - 2011-04-14 15:48:37 --> Model Class Initialized
DEBUG - 2011-04-14 15:48:37 --> Model Class Initialized
DEBUG - 2011-04-14 15:48:37 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-14 15:48:37 --> Database Driver Class Initialized
DEBUG - 2011-04-14 15:48:37 --> File loaded: application/views/table/main.php
DEBUG - 2011-04-14 15:48:37 --> Helper loaded: url_helper
DEBUG - 2011-04-14 15:48:37 --> File loaded: application/views/common/header.php
DEBUG - 2011-04-14 15:48:37 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-04-14 15:48:37 --> File loaded: application/views/common/footer.php
DEBUG - 2011-04-14 15:48:37 --> File loaded: application/views/layout/main.php
DEBUG - 2011-04-14 15:48:37 --> Final output sent to browser
DEBUG - 2011-04-14 15:48:37 --> Total execution time: 0.5152
DEBUG - 2011-04-14 15:48:39 --> Config Class Initialized
DEBUG - 2011-04-14 15:48:39 --> Hooks Class Initialized
DEBUG - 2011-04-14 15:48:39 --> Utf8 Class Initialized
DEBUG - 2011-04-14 15:48:39 --> UTF-8 Support Enabled
DEBUG - 2011-04-14 15:48:39 --> URI Class Initialized
DEBUG - 2011-04-14 15:48:39 --> Router Class Initialized
DEBUG - 2011-04-14 15:48:39 --> Output Class Initialized
DEBUG - 2011-04-14 15:48:39 --> Input Class Initialized
DEBUG - 2011-04-14 15:48:39 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-14 15:48:39 --> Language Class Initialized
DEBUG - 2011-04-14 15:48:39 --> Loader Class Initialized
DEBUG - 2011-04-14 15:48:39 --> Controller Class Initialized
ERROR - 2011-04-14 15:48:40 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-04-14 15:48:40 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-04-14 15:48:40 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-04-14 15:48:40 --> Model Class Initialized
DEBUG - 2011-04-14 15:48:40 --> Model Class Initialized
DEBUG - 2011-04-14 15:48:40 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-14 15:48:40 --> Database Driver Class Initialized
DEBUG - 2011-04-14 15:48:40 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-04-14 15:48:40 --> Helper loaded: url_helper
DEBUG - 2011-04-14 15:48:40 --> File loaded: application/views/common/header.php
DEBUG - 2011-04-14 15:48:40 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-04-14 15:48:40 --> File loaded: application/views/common/footer.php
DEBUG - 2011-04-14 15:48:40 --> File loaded: application/views/layout/main.php
DEBUG - 2011-04-14 15:48:40 --> Final output sent to browser
DEBUG - 2011-04-14 15:48:40 --> Total execution time: 0.0977
DEBUG - 2011-04-14 16:35:36 --> Config Class Initialized
DEBUG - 2011-04-14 16:35:36 --> Hooks Class Initialized
DEBUG - 2011-04-14 16:35:36 --> Utf8 Class Initialized
DEBUG - 2011-04-14 16:35:36 --> UTF-8 Support Enabled
DEBUG - 2011-04-14 16:35:36 --> URI Class Initialized
DEBUG - 2011-04-14 16:35:36 --> Router Class Initialized
DEBUG - 2011-04-14 16:35:36 --> Output Class Initialized
DEBUG - 2011-04-14 16:35:36 --> Input Class Initialized
DEBUG - 2011-04-14 16:35:36 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-14 16:35:36 --> Language Class Initialized
DEBUG - 2011-04-14 16:35:37 --> Loader Class Initialized
DEBUG - 2011-04-14 16:35:37 --> Controller Class Initialized
ERROR - 2011-04-14 16:35:37 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-04-14 16:35:37 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-04-14 16:35:37 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-04-14 16:35:37 --> Model Class Initialized
DEBUG - 2011-04-14 16:35:37 --> Model Class Initialized
DEBUG - 2011-04-14 16:35:37 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-14 16:35:37 --> Database Driver Class Initialized
DEBUG - 2011-04-14 16:35:37 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-04-14 16:35:37 --> Helper loaded: url_helper
DEBUG - 2011-04-14 16:35:37 --> File loaded: application/views/common/header.php
DEBUG - 2011-04-14 16:35:37 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-04-14 16:35:37 --> File loaded: application/views/common/footer.php
DEBUG - 2011-04-14 16:35:37 --> File loaded: application/views/layout/main.php
DEBUG - 2011-04-14 16:35:37 --> Final output sent to browser
DEBUG - 2011-04-14 16:35:37 --> Total execution time: 0.9977
DEBUG - 2011-04-14 16:36:07 --> Config Class Initialized
DEBUG - 2011-04-14 16:36:07 --> Hooks Class Initialized
DEBUG - 2011-04-14 16:36:07 --> Utf8 Class Initialized
DEBUG - 2011-04-14 16:36:07 --> UTF-8 Support Enabled
DEBUG - 2011-04-14 16:36:07 --> URI Class Initialized
DEBUG - 2011-04-14 16:36:07 --> Router Class Initialized
DEBUG - 2011-04-14 16:36:07 --> Output Class Initialized
DEBUG - 2011-04-14 16:36:07 --> Input Class Initialized
DEBUG - 2011-04-14 16:36:07 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-14 16:36:07 --> Language Class Initialized
DEBUG - 2011-04-14 16:36:07 --> Loader Class Initialized
DEBUG - 2011-04-14 16:36:07 --> Controller Class Initialized
DEBUG - 2011-04-14 16:36:07 --> Model Class Initialized
DEBUG - 2011-04-14 16:36:07 --> Model Class Initialized
DEBUG - 2011-04-14 16:36:07 --> Model Class Initialized
DEBUG - 2011-04-14 16:36:07 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-14 16:36:07 --> Database Driver Class Initialized
DEBUG - 2011-04-14 16:36:08 --> File loaded: application/views/table/main.php
DEBUG - 2011-04-14 16:36:08 --> Helper loaded: url_helper
DEBUG - 2011-04-14 16:36:08 --> File loaded: application/views/common/header.php
DEBUG - 2011-04-14 16:36:08 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-04-14 16:36:08 --> File loaded: application/views/common/footer.php
DEBUG - 2011-04-14 16:36:08 --> File loaded: application/views/layout/main.php
DEBUG - 2011-04-14 16:36:08 --> Final output sent to browser
DEBUG - 2011-04-14 16:36:08 --> Total execution time: 0.8209
DEBUG - 2011-04-14 16:48:43 --> Config Class Initialized
DEBUG - 2011-04-14 16:48:43 --> Hooks Class Initialized
DEBUG - 2011-04-14 16:48:43 --> Utf8 Class Initialized
DEBUG - 2011-04-14 16:48:43 --> UTF-8 Support Enabled
DEBUG - 2011-04-14 16:48:43 --> URI Class Initialized
DEBUG - 2011-04-14 16:48:43 --> Router Class Initialized
DEBUG - 2011-04-14 16:48:43 --> Output Class Initialized
DEBUG - 2011-04-14 16:48:43 --> Input Class Initialized
DEBUG - 2011-04-14 16:48:43 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-14 16:48:43 --> Language Class Initialized
DEBUG - 2011-04-14 16:48:43 --> Loader Class Initialized
DEBUG - 2011-04-14 16:48:43 --> Controller Class Initialized
DEBUG - 2011-04-14 16:48:43 --> Model Class Initialized
DEBUG - 2011-04-14 16:48:43 --> Model Class Initialized
DEBUG - 2011-04-14 16:48:43 --> Model Class Initialized
DEBUG - 2011-04-14 16:48:43 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-14 16:48:43 --> Database Driver Class Initialized
DEBUG - 2011-04-14 16:48:43 --> File loaded: application/views/table/main.php
DEBUG - 2011-04-14 16:48:43 --> Helper loaded: url_helper
DEBUG - 2011-04-14 16:48:43 --> File loaded: application/views/common/header.php
DEBUG - 2011-04-14 16:48:43 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-04-14 16:48:43 --> File loaded: application/views/common/footer.php
DEBUG - 2011-04-14 16:48:43 --> File loaded: application/views/layout/main.php
DEBUG - 2011-04-14 16:48:43 --> Final output sent to browser
DEBUG - 2011-04-14 16:48:43 --> Total execution time: 0.2618
DEBUG - 2011-04-14 16:56:26 --> Config Class Initialized
DEBUG - 2011-04-14 16:56:26 --> Hooks Class Initialized
DEBUG - 2011-04-14 16:56:26 --> Utf8 Class Initialized
DEBUG - 2011-04-14 16:56:26 --> UTF-8 Support Enabled
DEBUG - 2011-04-14 16:56:26 --> URI Class Initialized
DEBUG - 2011-04-14 16:56:26 --> Router Class Initialized
DEBUG - 2011-04-14 16:56:26 --> Output Class Initialized
DEBUG - 2011-04-14 16:56:26 --> Input Class Initialized
DEBUG - 2011-04-14 16:56:26 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-14 16:56:26 --> Language Class Initialized
DEBUG - 2011-04-14 16:56:26 --> Loader Class Initialized
DEBUG - 2011-04-14 16:56:26 --> Controller Class Initialized
DEBUG - 2011-04-14 16:56:26 --> Model Class Initialized
DEBUG - 2011-04-14 16:56:26 --> Model Class Initialized
DEBUG - 2011-04-14 16:56:26 --> Model Class Initialized
DEBUG - 2011-04-14 16:56:26 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-14 16:56:26 --> Database Driver Class Initialized
DEBUG - 2011-04-14 16:56:26 --> File loaded: application/views/table/main.php
DEBUG - 2011-04-14 16:56:26 --> Helper loaded: url_helper
DEBUG - 2011-04-14 16:56:26 --> File loaded: application/views/common/header.php
DEBUG - 2011-04-14 16:56:26 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-04-14 16:56:26 --> File loaded: application/views/common/footer.php
DEBUG - 2011-04-14 16:56:26 --> File loaded: application/views/layout/main.php
DEBUG - 2011-04-14 16:56:26 --> Final output sent to browser
DEBUG - 2011-04-14 16:56:26 --> Total execution time: 0.1079
DEBUG - 2011-04-14 16:56:30 --> Config Class Initialized
DEBUG - 2011-04-14 16:56:30 --> Hooks Class Initialized
DEBUG - 2011-04-14 16:56:30 --> Utf8 Class Initialized
DEBUG - 2011-04-14 16:56:30 --> UTF-8 Support Enabled
DEBUG - 2011-04-14 16:56:30 --> URI Class Initialized
DEBUG - 2011-04-14 16:56:30 --> Router Class Initialized
DEBUG - 2011-04-14 16:56:30 --> Output Class Initialized
DEBUG - 2011-04-14 16:56:30 --> Input Class Initialized
DEBUG - 2011-04-14 16:56:30 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-14 16:56:30 --> Language Class Initialized
DEBUG - 2011-04-14 16:56:30 --> Loader Class Initialized
DEBUG - 2011-04-14 16:56:30 --> Controller Class Initialized
ERROR - 2011-04-14 16:56:30 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-04-14 16:56:30 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-04-14 16:56:30 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-04-14 16:56:30 --> Model Class Initialized
DEBUG - 2011-04-14 16:56:30 --> Model Class Initialized
DEBUG - 2011-04-14 16:56:30 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-14 16:56:30 --> Database Driver Class Initialized
DEBUG - 2011-04-14 16:56:30 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-04-14 16:56:30 --> Helper loaded: url_helper
DEBUG - 2011-04-14 16:56:30 --> File loaded: application/views/common/header.php
DEBUG - 2011-04-14 16:56:30 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-04-14 16:56:30 --> File loaded: application/views/common/footer.php
DEBUG - 2011-04-14 16:56:30 --> File loaded: application/views/layout/main.php
DEBUG - 2011-04-14 16:56:30 --> Final output sent to browser
DEBUG - 2011-04-14 16:56:30 --> Total execution time: 0.0544
DEBUG - 2011-04-14 17:16:28 --> Config Class Initialized
DEBUG - 2011-04-14 17:16:28 --> Hooks Class Initialized
DEBUG - 2011-04-14 17:16:28 --> Utf8 Class Initialized
DEBUG - 2011-04-14 17:16:28 --> UTF-8 Support Enabled
DEBUG - 2011-04-14 17:16:28 --> URI Class Initialized
DEBUG - 2011-04-14 17:16:28 --> Router Class Initialized
DEBUG - 2011-04-14 17:16:28 --> Output Class Initialized
DEBUG - 2011-04-14 17:16:28 --> Input Class Initialized
DEBUG - 2011-04-14 17:16:28 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-14 17:16:28 --> Language Class Initialized
DEBUG - 2011-04-14 17:16:28 --> Loader Class Initialized
DEBUG - 2011-04-14 17:16:28 --> Controller Class Initialized
ERROR - 2011-04-14 17:16:28 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-04-14 17:16:28 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-04-14 17:16:28 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-04-14 17:16:28 --> Model Class Initialized
DEBUG - 2011-04-14 17:16:28 --> Model Class Initialized
DEBUG - 2011-04-14 17:16:28 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-14 17:16:28 --> Database Driver Class Initialized
DEBUG - 2011-04-14 17:16:28 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-04-14 17:16:28 --> Helper loaded: url_helper
DEBUG - 2011-04-14 17:16:28 --> File loaded: application/views/common/header.php
DEBUG - 2011-04-14 17:16:28 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-04-14 17:16:28 --> File loaded: application/views/common/footer.php
DEBUG - 2011-04-14 17:16:28 --> File loaded: application/views/layout/main.php
DEBUG - 2011-04-14 17:16:28 --> Final output sent to browser
DEBUG - 2011-04-14 17:16:28 --> Total execution time: 0.0840
DEBUG - 2011-04-14 17:16:29 --> Config Class Initialized
DEBUG - 2011-04-14 17:16:29 --> Hooks Class Initialized
DEBUG - 2011-04-14 17:16:29 --> Utf8 Class Initialized
DEBUG - 2011-04-14 17:16:29 --> UTF-8 Support Enabled
DEBUG - 2011-04-14 17:16:29 --> URI Class Initialized
DEBUG - 2011-04-14 17:16:29 --> Router Class Initialized
DEBUG - 2011-04-14 17:16:29 --> Output Class Initialized
DEBUG - 2011-04-14 17:16:29 --> Input Class Initialized
DEBUG - 2011-04-14 17:16:29 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-14 17:16:29 --> Language Class Initialized
DEBUG - 2011-04-14 17:16:29 --> Loader Class Initialized
DEBUG - 2011-04-14 17:16:29 --> Controller Class Initialized
DEBUG - 2011-04-14 17:16:29 --> Model Class Initialized
DEBUG - 2011-04-14 17:16:29 --> Model Class Initialized
DEBUG - 2011-04-14 17:16:29 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-14 17:16:29 --> Database Driver Class Initialized
DEBUG - 2011-04-14 17:16:30 --> Final output sent to browser
DEBUG - 2011-04-14 17:16:30 --> Total execution time: 0.8403
DEBUG - 2011-04-14 17:16:31 --> Config Class Initialized
DEBUG - 2011-04-14 17:16:31 --> Hooks Class Initialized
DEBUG - 2011-04-14 17:16:31 --> Utf8 Class Initialized
DEBUG - 2011-04-14 17:16:31 --> UTF-8 Support Enabled
DEBUG - 2011-04-14 17:16:31 --> URI Class Initialized
DEBUG - 2011-04-14 17:16:31 --> Router Class Initialized
ERROR - 2011-04-14 17:16:31 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-04-14 17:16:33 --> Config Class Initialized
DEBUG - 2011-04-14 17:16:33 --> Hooks Class Initialized
DEBUG - 2011-04-14 17:16:33 --> Utf8 Class Initialized
DEBUG - 2011-04-14 17:16:33 --> UTF-8 Support Enabled
DEBUG - 2011-04-14 17:16:33 --> URI Class Initialized
DEBUG - 2011-04-14 17:16:33 --> Router Class Initialized
ERROR - 2011-04-14 17:16:33 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-04-14 17:16:55 --> Config Class Initialized
DEBUG - 2011-04-14 17:16:55 --> Hooks Class Initialized
DEBUG - 2011-04-14 17:16:55 --> Utf8 Class Initialized
DEBUG - 2011-04-14 17:16:55 --> UTF-8 Support Enabled
DEBUG - 2011-04-14 17:16:55 --> URI Class Initialized
DEBUG - 2011-04-14 17:16:55 --> Router Class Initialized
DEBUG - 2011-04-14 17:16:55 --> Output Class Initialized
DEBUG - 2011-04-14 17:16:55 --> Input Class Initialized
DEBUG - 2011-04-14 17:16:55 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-14 17:16:55 --> Language Class Initialized
DEBUG - 2011-04-14 17:16:55 --> Loader Class Initialized
DEBUG - 2011-04-14 17:16:55 --> Controller Class Initialized
ERROR - 2011-04-14 17:16:55 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-04-14 17:16:55 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-04-14 17:16:55 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-04-14 17:16:55 --> Model Class Initialized
DEBUG - 2011-04-14 17:16:55 --> Model Class Initialized
DEBUG - 2011-04-14 17:16:55 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-14 17:16:55 --> Database Driver Class Initialized
DEBUG - 2011-04-14 17:16:55 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-04-14 17:16:55 --> Helper loaded: url_helper
DEBUG - 2011-04-14 17:16:55 --> File loaded: application/views/common/header.php
DEBUG - 2011-04-14 17:16:55 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-04-14 17:16:55 --> File loaded: application/views/common/footer.php
DEBUG - 2011-04-14 17:16:55 --> File loaded: application/views/layout/main.php
DEBUG - 2011-04-14 17:16:55 --> Final output sent to browser
DEBUG - 2011-04-14 17:16:55 --> Total execution time: 0.0334
DEBUG - 2011-04-14 17:16:55 --> Config Class Initialized
DEBUG - 2011-04-14 17:16:55 --> Hooks Class Initialized
DEBUG - 2011-04-14 17:16:55 --> Utf8 Class Initialized
DEBUG - 2011-04-14 17:16:55 --> UTF-8 Support Enabled
DEBUG - 2011-04-14 17:16:55 --> URI Class Initialized
DEBUG - 2011-04-14 17:16:55 --> Router Class Initialized
DEBUG - 2011-04-14 17:16:55 --> Output Class Initialized
DEBUG - 2011-04-14 17:16:55 --> Input Class Initialized
DEBUG - 2011-04-14 17:16:55 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-14 17:16:55 --> Language Class Initialized
DEBUG - 2011-04-14 17:16:55 --> Loader Class Initialized
DEBUG - 2011-04-14 17:16:55 --> Controller Class Initialized
DEBUG - 2011-04-14 17:16:55 --> Model Class Initialized
DEBUG - 2011-04-14 17:16:55 --> Model Class Initialized
DEBUG - 2011-04-14 17:16:55 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-14 17:16:55 --> Database Driver Class Initialized
DEBUG - 2011-04-14 17:16:56 --> Final output sent to browser
DEBUG - 2011-04-14 17:16:56 --> Total execution time: 0.5431
DEBUG - 2011-04-14 17:17:17 --> Config Class Initialized
DEBUG - 2011-04-14 17:17:17 --> Hooks Class Initialized
DEBUG - 2011-04-14 17:17:17 --> Utf8 Class Initialized
DEBUG - 2011-04-14 17:17:17 --> UTF-8 Support Enabled
DEBUG - 2011-04-14 17:17:17 --> URI Class Initialized
DEBUG - 2011-04-14 17:17:17 --> Router Class Initialized
DEBUG - 2011-04-14 17:17:17 --> Output Class Initialized
DEBUG - 2011-04-14 17:17:17 --> Input Class Initialized
DEBUG - 2011-04-14 17:17:17 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-14 17:17:17 --> Language Class Initialized
DEBUG - 2011-04-14 17:17:17 --> Loader Class Initialized
DEBUG - 2011-04-14 17:17:17 --> Controller Class Initialized
ERROR - 2011-04-14 17:17:17 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-04-14 17:17:17 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-04-14 17:17:17 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-04-14 17:17:17 --> Model Class Initialized
DEBUG - 2011-04-14 17:17:17 --> Model Class Initialized
DEBUG - 2011-04-14 17:17:17 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-14 17:17:17 --> Database Driver Class Initialized
DEBUG - 2011-04-14 17:17:17 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-04-14 17:17:17 --> Helper loaded: url_helper
DEBUG - 2011-04-14 17:17:17 --> File loaded: application/views/common/header.php
DEBUG - 2011-04-14 17:17:17 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-04-14 17:17:17 --> File loaded: application/views/common/footer.php
DEBUG - 2011-04-14 17:17:17 --> File loaded: application/views/layout/main.php
DEBUG - 2011-04-14 17:17:17 --> Final output sent to browser
DEBUG - 2011-04-14 17:17:17 --> Total execution time: 0.0289
DEBUG - 2011-04-14 17:17:18 --> Config Class Initialized
DEBUG - 2011-04-14 17:17:18 --> Hooks Class Initialized
DEBUG - 2011-04-14 17:17:18 --> Utf8 Class Initialized
DEBUG - 2011-04-14 17:17:18 --> UTF-8 Support Enabled
DEBUG - 2011-04-14 17:17:18 --> URI Class Initialized
DEBUG - 2011-04-14 17:17:18 --> Router Class Initialized
DEBUG - 2011-04-14 17:17:18 --> Output Class Initialized
DEBUG - 2011-04-14 17:17:18 --> Input Class Initialized
DEBUG - 2011-04-14 17:17:18 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-14 17:17:18 --> Language Class Initialized
DEBUG - 2011-04-14 17:17:18 --> Loader Class Initialized
DEBUG - 2011-04-14 17:17:18 --> Controller Class Initialized
ERROR - 2011-04-14 17:17:18 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-04-14 17:17:18 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-04-14 17:17:18 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-04-14 17:17:18 --> Model Class Initialized
DEBUG - 2011-04-14 17:17:18 --> Model Class Initialized
DEBUG - 2011-04-14 17:17:18 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-14 17:17:18 --> Database Driver Class Initialized
DEBUG - 2011-04-14 17:17:18 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-04-14 17:17:18 --> Helper loaded: url_helper
DEBUG - 2011-04-14 17:17:18 --> File loaded: application/views/common/header.php
DEBUG - 2011-04-14 17:17:18 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-04-14 17:17:18 --> File loaded: application/views/common/footer.php
DEBUG - 2011-04-14 17:17:18 --> File loaded: application/views/layout/main.php
DEBUG - 2011-04-14 17:17:18 --> Final output sent to browser
DEBUG - 2011-04-14 17:17:18 --> Total execution time: 0.0295
DEBUG - 2011-04-14 17:17:18 --> Config Class Initialized
DEBUG - 2011-04-14 17:17:18 --> Hooks Class Initialized
DEBUG - 2011-04-14 17:17:18 --> Utf8 Class Initialized
DEBUG - 2011-04-14 17:17:18 --> UTF-8 Support Enabled
DEBUG - 2011-04-14 17:17:18 --> URI Class Initialized
DEBUG - 2011-04-14 17:17:18 --> Router Class Initialized
DEBUG - 2011-04-14 17:17:18 --> Output Class Initialized
DEBUG - 2011-04-14 17:17:18 --> Input Class Initialized
DEBUG - 2011-04-14 17:17:18 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-14 17:17:18 --> Language Class Initialized
DEBUG - 2011-04-14 17:17:18 --> Loader Class Initialized
DEBUG - 2011-04-14 17:17:18 --> Controller Class Initialized
DEBUG - 2011-04-14 17:17:18 --> Model Class Initialized
DEBUG - 2011-04-14 17:17:18 --> Model Class Initialized
DEBUG - 2011-04-14 17:17:18 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-14 17:17:18 --> Database Driver Class Initialized
DEBUG - 2011-04-14 17:17:19 --> Final output sent to browser
DEBUG - 2011-04-14 17:17:19 --> Total execution time: 0.5760
DEBUG - 2011-04-14 17:17:40 --> Config Class Initialized
DEBUG - 2011-04-14 17:17:40 --> Hooks Class Initialized
DEBUG - 2011-04-14 17:17:40 --> Utf8 Class Initialized
DEBUG - 2011-04-14 17:17:40 --> UTF-8 Support Enabled
DEBUG - 2011-04-14 17:17:40 --> URI Class Initialized
DEBUG - 2011-04-14 17:17:40 --> Router Class Initialized
DEBUG - 2011-04-14 17:17:40 --> Output Class Initialized
DEBUG - 2011-04-14 17:17:40 --> Input Class Initialized
DEBUG - 2011-04-14 17:17:40 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-14 17:17:40 --> Language Class Initialized
DEBUG - 2011-04-14 17:17:40 --> Loader Class Initialized
DEBUG - 2011-04-14 17:17:40 --> Controller Class Initialized
ERROR - 2011-04-14 17:17:40 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-04-14 17:17:40 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-04-14 17:17:40 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-04-14 17:17:40 --> Model Class Initialized
DEBUG - 2011-04-14 17:17:40 --> Model Class Initialized
DEBUG - 2011-04-14 17:17:40 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-14 17:17:40 --> Database Driver Class Initialized
DEBUG - 2011-04-14 17:17:40 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-04-14 17:17:40 --> Helper loaded: url_helper
DEBUG - 2011-04-14 17:17:40 --> File loaded: application/views/common/header.php
DEBUG - 2011-04-14 17:17:40 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-04-14 17:17:40 --> File loaded: application/views/common/footer.php
DEBUG - 2011-04-14 17:17:40 --> File loaded: application/views/layout/main.php
DEBUG - 2011-04-14 17:17:40 --> Final output sent to browser
DEBUG - 2011-04-14 17:17:40 --> Total execution time: 0.0300
DEBUG - 2011-04-14 17:17:41 --> Config Class Initialized
DEBUG - 2011-04-14 17:17:41 --> Hooks Class Initialized
DEBUG - 2011-04-14 17:17:41 --> Utf8 Class Initialized
DEBUG - 2011-04-14 17:17:41 --> UTF-8 Support Enabled
DEBUG - 2011-04-14 17:17:41 --> URI Class Initialized
DEBUG - 2011-04-14 17:17:41 --> Router Class Initialized
DEBUG - 2011-04-14 17:17:41 --> Output Class Initialized
DEBUG - 2011-04-14 17:17:41 --> Input Class Initialized
DEBUG - 2011-04-14 17:17:41 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-14 17:17:41 --> Language Class Initialized
DEBUG - 2011-04-14 17:17:41 --> Loader Class Initialized
DEBUG - 2011-04-14 17:17:41 --> Controller Class Initialized
DEBUG - 2011-04-14 17:17:41 --> Model Class Initialized
DEBUG - 2011-04-14 17:17:41 --> Model Class Initialized
DEBUG - 2011-04-14 17:17:41 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-14 17:17:41 --> Database Driver Class Initialized
DEBUG - 2011-04-14 17:17:41 --> Final output sent to browser
DEBUG - 2011-04-14 17:17:41 --> Total execution time: 0.6759
DEBUG - 2011-04-14 17:17:41 --> Config Class Initialized
DEBUG - 2011-04-14 17:17:41 --> Hooks Class Initialized
DEBUG - 2011-04-14 17:17:41 --> Utf8 Class Initialized
DEBUG - 2011-04-14 17:17:42 --> UTF-8 Support Enabled
DEBUG - 2011-04-14 17:17:42 --> URI Class Initialized
DEBUG - 2011-04-14 17:17:42 --> Router Class Initialized
DEBUG - 2011-04-14 17:17:42 --> Output Class Initialized
DEBUG - 2011-04-14 17:17:42 --> Input Class Initialized
DEBUG - 2011-04-14 17:17:42 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-14 17:17:42 --> Language Class Initialized
DEBUG - 2011-04-14 17:17:42 --> Loader Class Initialized
DEBUG - 2011-04-14 17:17:42 --> Controller Class Initialized
ERROR - 2011-04-14 17:17:42 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-04-14 17:17:42 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-04-14 17:17:42 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-04-14 17:17:42 --> Model Class Initialized
DEBUG - 2011-04-14 17:17:42 --> Model Class Initialized
DEBUG - 2011-04-14 17:17:42 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-14 17:17:42 --> Database Driver Class Initialized
DEBUG - 2011-04-14 17:17:42 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-04-14 17:17:42 --> Helper loaded: url_helper
DEBUG - 2011-04-14 17:17:42 --> File loaded: application/views/common/header.php
DEBUG - 2011-04-14 17:17:42 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-04-14 17:17:42 --> File loaded: application/views/common/footer.php
DEBUG - 2011-04-14 17:17:42 --> File loaded: application/views/layout/main.php
DEBUG - 2011-04-14 17:17:42 --> Final output sent to browser
DEBUG - 2011-04-14 17:17:42 --> Total execution time: 0.0366
DEBUG - 2011-04-14 17:17:51 --> Config Class Initialized
DEBUG - 2011-04-14 17:17:51 --> Hooks Class Initialized
DEBUG - 2011-04-14 17:17:51 --> Utf8 Class Initialized
DEBUG - 2011-04-14 17:17:51 --> UTF-8 Support Enabled
DEBUG - 2011-04-14 17:17:51 --> URI Class Initialized
DEBUG - 2011-04-14 17:17:51 --> Router Class Initialized
DEBUG - 2011-04-14 17:17:51 --> Output Class Initialized
DEBUG - 2011-04-14 17:17:51 --> Input Class Initialized
DEBUG - 2011-04-14 17:17:51 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-14 17:17:51 --> Language Class Initialized
DEBUG - 2011-04-14 17:17:51 --> Loader Class Initialized
DEBUG - 2011-04-14 17:17:51 --> Controller Class Initialized
ERROR - 2011-04-14 17:17:51 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-04-14 17:17:51 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-04-14 17:17:51 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-04-14 17:17:51 --> Model Class Initialized
DEBUG - 2011-04-14 17:17:51 --> Model Class Initialized
DEBUG - 2011-04-14 17:17:51 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-14 17:17:51 --> Database Driver Class Initialized
DEBUG - 2011-04-14 17:17:51 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-04-14 17:17:51 --> Helper loaded: url_helper
DEBUG - 2011-04-14 17:17:51 --> File loaded: application/views/common/header.php
DEBUG - 2011-04-14 17:17:51 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-04-14 17:17:51 --> File loaded: application/views/common/footer.php
DEBUG - 2011-04-14 17:17:51 --> File loaded: application/views/layout/main.php
DEBUG - 2011-04-14 17:17:51 --> Final output sent to browser
DEBUG - 2011-04-14 17:17:51 --> Total execution time: 0.0343
DEBUG - 2011-04-14 17:17:52 --> Config Class Initialized
DEBUG - 2011-04-14 17:17:52 --> Hooks Class Initialized
DEBUG - 2011-04-14 17:17:52 --> Utf8 Class Initialized
DEBUG - 2011-04-14 17:17:52 --> UTF-8 Support Enabled
DEBUG - 2011-04-14 17:17:52 --> URI Class Initialized
DEBUG - 2011-04-14 17:17:52 --> Router Class Initialized
DEBUG - 2011-04-14 17:17:52 --> Output Class Initialized
DEBUG - 2011-04-14 17:17:52 --> Input Class Initialized
DEBUG - 2011-04-14 17:17:52 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-14 17:17:52 --> Language Class Initialized
DEBUG - 2011-04-14 17:17:52 --> Loader Class Initialized
DEBUG - 2011-04-14 17:17:52 --> Controller Class Initialized
DEBUG - 2011-04-14 17:17:52 --> Model Class Initialized
DEBUG - 2011-04-14 17:17:52 --> Model Class Initialized
DEBUG - 2011-04-14 17:17:52 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-14 17:17:52 --> Database Driver Class Initialized
DEBUG - 2011-04-14 17:17:53 --> Final output sent to browser
DEBUG - 2011-04-14 17:17:53 --> Total execution time: 0.6579
DEBUG - 2011-04-14 17:18:11 --> Config Class Initialized
DEBUG - 2011-04-14 17:18:11 --> Hooks Class Initialized
DEBUG - 2011-04-14 17:18:11 --> Utf8 Class Initialized
DEBUG - 2011-04-14 17:18:11 --> UTF-8 Support Enabled
DEBUG - 2011-04-14 17:18:11 --> URI Class Initialized
DEBUG - 2011-04-14 17:18:11 --> Router Class Initialized
DEBUG - 2011-04-14 17:18:11 --> Output Class Initialized
DEBUG - 2011-04-14 17:18:11 --> Input Class Initialized
DEBUG - 2011-04-14 17:18:11 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-14 17:18:11 --> Language Class Initialized
DEBUG - 2011-04-14 17:18:11 --> Loader Class Initialized
DEBUG - 2011-04-14 17:18:11 --> Controller Class Initialized
ERROR - 2011-04-14 17:18:11 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-04-14 17:18:11 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-04-14 17:18:11 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-04-14 17:18:11 --> Model Class Initialized
DEBUG - 2011-04-14 17:18:11 --> Model Class Initialized
DEBUG - 2011-04-14 17:18:11 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-14 17:18:11 --> Database Driver Class Initialized
DEBUG - 2011-04-14 17:18:11 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-04-14 17:18:11 --> Helper loaded: url_helper
DEBUG - 2011-04-14 17:18:11 --> File loaded: application/views/common/header.php
DEBUG - 2011-04-14 17:18:11 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-04-14 17:18:11 --> File loaded: application/views/common/footer.php
DEBUG - 2011-04-14 17:18:11 --> File loaded: application/views/layout/main.php
DEBUG - 2011-04-14 17:18:11 --> Final output sent to browser
DEBUG - 2011-04-14 17:18:11 --> Total execution time: 0.0317
DEBUG - 2011-04-14 17:18:12 --> Config Class Initialized
DEBUG - 2011-04-14 17:18:12 --> Hooks Class Initialized
DEBUG - 2011-04-14 17:18:12 --> Utf8 Class Initialized
DEBUG - 2011-04-14 17:18:12 --> UTF-8 Support Enabled
DEBUG - 2011-04-14 17:18:12 --> URI Class Initialized
DEBUG - 2011-04-14 17:18:12 --> Router Class Initialized
DEBUG - 2011-04-14 17:18:12 --> Output Class Initialized
DEBUG - 2011-04-14 17:18:12 --> Input Class Initialized
DEBUG - 2011-04-14 17:18:12 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-14 17:18:12 --> Language Class Initialized
DEBUG - 2011-04-14 17:18:12 --> Loader Class Initialized
DEBUG - 2011-04-14 17:18:12 --> Controller Class Initialized
DEBUG - 2011-04-14 17:18:12 --> Model Class Initialized
DEBUG - 2011-04-14 17:18:12 --> Model Class Initialized
DEBUG - 2011-04-14 17:18:12 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-14 17:18:12 --> Database Driver Class Initialized
DEBUG - 2011-04-14 17:18:13 --> Final output sent to browser
DEBUG - 2011-04-14 17:18:13 --> Total execution time: 0.6338
DEBUG - 2011-04-14 17:18:41 --> Config Class Initialized
DEBUG - 2011-04-14 17:18:41 --> Hooks Class Initialized
DEBUG - 2011-04-14 17:18:41 --> Utf8 Class Initialized
DEBUG - 2011-04-14 17:18:41 --> UTF-8 Support Enabled
DEBUG - 2011-04-14 17:18:41 --> URI Class Initialized
DEBUG - 2011-04-14 17:18:41 --> Router Class Initialized
DEBUG - 2011-04-14 17:18:41 --> Output Class Initialized
DEBUG - 2011-04-14 17:18:41 --> Input Class Initialized
DEBUG - 2011-04-14 17:18:41 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-14 17:18:41 --> Language Class Initialized
DEBUG - 2011-04-14 17:18:41 --> Loader Class Initialized
DEBUG - 2011-04-14 17:18:41 --> Controller Class Initialized
ERROR - 2011-04-14 17:18:41 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-04-14 17:18:41 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-04-14 17:18:41 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-04-14 17:18:41 --> Model Class Initialized
DEBUG - 2011-04-14 17:18:41 --> Model Class Initialized
DEBUG - 2011-04-14 17:18:41 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-14 17:18:41 --> Database Driver Class Initialized
DEBUG - 2011-04-14 17:18:41 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-04-14 17:18:41 --> Helper loaded: url_helper
DEBUG - 2011-04-14 17:18:41 --> File loaded: application/views/common/header.php
DEBUG - 2011-04-14 17:18:41 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-04-14 17:18:41 --> File loaded: application/views/common/footer.php
DEBUG - 2011-04-14 17:18:41 --> File loaded: application/views/layout/main.php
DEBUG - 2011-04-14 17:18:41 --> Final output sent to browser
DEBUG - 2011-04-14 17:18:41 --> Total execution time: 0.0299
DEBUG - 2011-04-14 17:18:43 --> Config Class Initialized
DEBUG - 2011-04-14 17:18:43 --> Hooks Class Initialized
DEBUG - 2011-04-14 17:18:43 --> Utf8 Class Initialized
DEBUG - 2011-04-14 17:18:43 --> UTF-8 Support Enabled
DEBUG - 2011-04-14 17:18:43 --> URI Class Initialized
DEBUG - 2011-04-14 17:18:43 --> Router Class Initialized
DEBUG - 2011-04-14 17:18:43 --> Output Class Initialized
DEBUG - 2011-04-14 17:18:43 --> Input Class Initialized
DEBUG - 2011-04-14 17:18:43 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-14 17:18:43 --> Language Class Initialized
DEBUG - 2011-04-14 17:18:43 --> Loader Class Initialized
DEBUG - 2011-04-14 17:18:43 --> Controller Class Initialized
DEBUG - 2011-04-14 17:18:43 --> Model Class Initialized
DEBUG - 2011-04-14 17:18:43 --> Model Class Initialized
DEBUG - 2011-04-14 17:18:43 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-14 17:18:43 --> Database Driver Class Initialized
DEBUG - 2011-04-14 17:18:43 --> Final output sent to browser
DEBUG - 2011-04-14 17:18:43 --> Total execution time: 0.5821
DEBUG - 2011-04-14 17:18:57 --> Config Class Initialized
DEBUG - 2011-04-14 17:18:57 --> Hooks Class Initialized
DEBUG - 2011-04-14 17:18:57 --> Utf8 Class Initialized
DEBUG - 2011-04-14 17:18:57 --> UTF-8 Support Enabled
DEBUG - 2011-04-14 17:18:57 --> URI Class Initialized
DEBUG - 2011-04-14 17:18:57 --> Router Class Initialized
DEBUG - 2011-04-14 17:18:57 --> Output Class Initialized
DEBUG - 2011-04-14 17:18:57 --> Input Class Initialized
DEBUG - 2011-04-14 17:18:57 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-14 17:18:57 --> Language Class Initialized
DEBUG - 2011-04-14 17:18:57 --> Loader Class Initialized
DEBUG - 2011-04-14 17:18:57 --> Controller Class Initialized
ERROR - 2011-04-14 17:18:57 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-04-14 17:18:57 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-04-14 17:18:57 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-04-14 17:18:57 --> Model Class Initialized
DEBUG - 2011-04-14 17:18:57 --> Model Class Initialized
DEBUG - 2011-04-14 17:18:57 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-14 17:18:57 --> Database Driver Class Initialized
DEBUG - 2011-04-14 17:18:57 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-04-14 17:18:57 --> Helper loaded: url_helper
DEBUG - 2011-04-14 17:18:57 --> File loaded: application/views/common/header.php
DEBUG - 2011-04-14 17:18:57 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-04-14 17:18:57 --> File loaded: application/views/common/footer.php
DEBUG - 2011-04-14 17:18:57 --> File loaded: application/views/layout/main.php
DEBUG - 2011-04-14 17:18:57 --> Final output sent to browser
DEBUG - 2011-04-14 17:18:57 --> Total execution time: 0.0465
DEBUG - 2011-04-14 17:18:58 --> Config Class Initialized
DEBUG - 2011-04-14 17:18:58 --> Hooks Class Initialized
DEBUG - 2011-04-14 17:18:58 --> Utf8 Class Initialized
DEBUG - 2011-04-14 17:18:58 --> UTF-8 Support Enabled
DEBUG - 2011-04-14 17:18:58 --> URI Class Initialized
DEBUG - 2011-04-14 17:18:58 --> Router Class Initialized
DEBUG - 2011-04-14 17:18:58 --> Output Class Initialized
DEBUG - 2011-04-14 17:18:58 --> Input Class Initialized
DEBUG - 2011-04-14 17:18:58 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-14 17:18:58 --> Language Class Initialized
DEBUG - 2011-04-14 17:18:58 --> Loader Class Initialized
DEBUG - 2011-04-14 17:18:58 --> Controller Class Initialized
DEBUG - 2011-04-14 17:18:58 --> Model Class Initialized
DEBUG - 2011-04-14 17:18:58 --> Model Class Initialized
DEBUG - 2011-04-14 17:18:58 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-14 17:18:58 --> Database Driver Class Initialized
DEBUG - 2011-04-14 17:18:59 --> Final output sent to browser
DEBUG - 2011-04-14 17:18:59 --> Total execution time: 0.5255
DEBUG - 2011-04-14 17:19:26 --> Config Class Initialized
DEBUG - 2011-04-14 17:19:26 --> Hooks Class Initialized
DEBUG - 2011-04-14 17:19:26 --> Utf8 Class Initialized
DEBUG - 2011-04-14 17:19:26 --> UTF-8 Support Enabled
DEBUG - 2011-04-14 17:19:26 --> URI Class Initialized
DEBUG - 2011-04-14 17:19:26 --> Router Class Initialized
DEBUG - 2011-04-14 17:19:26 --> Output Class Initialized
DEBUG - 2011-04-14 17:19:26 --> Input Class Initialized
DEBUG - 2011-04-14 17:19:26 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-14 17:19:26 --> Language Class Initialized
DEBUG - 2011-04-14 17:19:26 --> Loader Class Initialized
DEBUG - 2011-04-14 17:19:26 --> Controller Class Initialized
ERROR - 2011-04-14 17:19:26 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-04-14 17:19:26 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-04-14 17:19:26 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-04-14 17:19:26 --> Model Class Initialized
DEBUG - 2011-04-14 17:19:26 --> Model Class Initialized
DEBUG - 2011-04-14 17:19:26 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-14 17:19:26 --> Database Driver Class Initialized
DEBUG - 2011-04-14 17:19:26 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-04-14 17:19:26 --> Helper loaded: url_helper
DEBUG - 2011-04-14 17:19:26 --> File loaded: application/views/common/header.php
DEBUG - 2011-04-14 17:19:26 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-04-14 17:19:26 --> File loaded: application/views/common/footer.php
DEBUG - 2011-04-14 17:19:26 --> File loaded: application/views/layout/main.php
DEBUG - 2011-04-14 17:19:26 --> Final output sent to browser
DEBUG - 2011-04-14 17:19:26 --> Total execution time: 0.0277
DEBUG - 2011-04-14 17:19:27 --> Config Class Initialized
DEBUG - 2011-04-14 17:19:27 --> Hooks Class Initialized
DEBUG - 2011-04-14 17:19:27 --> Utf8 Class Initialized
DEBUG - 2011-04-14 17:19:27 --> UTF-8 Support Enabled
DEBUG - 2011-04-14 17:19:27 --> URI Class Initialized
DEBUG - 2011-04-14 17:19:27 --> Router Class Initialized
DEBUG - 2011-04-14 17:19:27 --> Output Class Initialized
DEBUG - 2011-04-14 17:19:27 --> Input Class Initialized
DEBUG - 2011-04-14 17:19:27 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-14 17:19:27 --> Language Class Initialized
DEBUG - 2011-04-14 17:19:27 --> Loader Class Initialized
DEBUG - 2011-04-14 17:19:27 --> Controller Class Initialized
ERROR - 2011-04-14 17:19:27 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-04-14 17:19:27 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-04-14 17:19:27 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-04-14 17:19:27 --> Model Class Initialized
DEBUG - 2011-04-14 17:19:27 --> Model Class Initialized
DEBUG - 2011-04-14 17:19:27 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-14 17:19:27 --> Database Driver Class Initialized
DEBUG - 2011-04-14 17:19:27 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-04-14 17:19:27 --> Helper loaded: url_helper
DEBUG - 2011-04-14 17:19:27 --> File loaded: application/views/common/header.php
DEBUG - 2011-04-14 17:19:27 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-04-14 17:19:27 --> File loaded: application/views/common/footer.php
DEBUG - 2011-04-14 17:19:27 --> File loaded: application/views/layout/main.php
DEBUG - 2011-04-14 17:19:27 --> Final output sent to browser
DEBUG - 2011-04-14 17:19:27 --> Total execution time: 0.0296
DEBUG - 2011-04-14 17:19:27 --> Config Class Initialized
DEBUG - 2011-04-14 17:19:27 --> Hooks Class Initialized
DEBUG - 2011-04-14 17:19:27 --> Utf8 Class Initialized
DEBUG - 2011-04-14 17:19:27 --> UTF-8 Support Enabled
DEBUG - 2011-04-14 17:19:27 --> URI Class Initialized
DEBUG - 2011-04-14 17:19:27 --> Router Class Initialized
DEBUG - 2011-04-14 17:19:27 --> Output Class Initialized
DEBUG - 2011-04-14 17:19:27 --> Input Class Initialized
DEBUG - 2011-04-14 17:19:27 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-14 17:19:27 --> Language Class Initialized
DEBUG - 2011-04-14 17:19:27 --> Loader Class Initialized
DEBUG - 2011-04-14 17:19:27 --> Controller Class Initialized
DEBUG - 2011-04-14 17:19:27 --> Model Class Initialized
DEBUG - 2011-04-14 17:19:27 --> Model Class Initialized
DEBUG - 2011-04-14 17:19:27 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-14 17:19:27 --> Database Driver Class Initialized
DEBUG - 2011-04-14 17:19:27 --> Final output sent to browser
DEBUG - 2011-04-14 17:19:27 --> Total execution time: 0.6168
DEBUG - 2011-04-14 17:19:38 --> Config Class Initialized
DEBUG - 2011-04-14 17:19:38 --> Hooks Class Initialized
DEBUG - 2011-04-14 17:19:38 --> Utf8 Class Initialized
DEBUG - 2011-04-14 17:19:38 --> UTF-8 Support Enabled
DEBUG - 2011-04-14 17:19:38 --> URI Class Initialized
DEBUG - 2011-04-14 17:19:38 --> Router Class Initialized
DEBUG - 2011-04-14 17:19:38 --> Output Class Initialized
DEBUG - 2011-04-14 17:19:38 --> Input Class Initialized
DEBUG - 2011-04-14 17:19:38 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-14 17:19:38 --> Language Class Initialized
DEBUG - 2011-04-14 17:19:38 --> Loader Class Initialized
DEBUG - 2011-04-14 17:19:38 --> Controller Class Initialized
ERROR - 2011-04-14 17:19:38 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-04-14 17:19:38 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-04-14 17:19:38 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-04-14 17:19:38 --> Model Class Initialized
DEBUG - 2011-04-14 17:19:38 --> Model Class Initialized
DEBUG - 2011-04-14 17:19:38 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-14 17:19:38 --> Database Driver Class Initialized
DEBUG - 2011-04-14 17:19:38 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-04-14 17:19:38 --> Helper loaded: url_helper
DEBUG - 2011-04-14 17:19:38 --> File loaded: application/views/common/header.php
DEBUG - 2011-04-14 17:19:38 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-04-14 17:19:38 --> File loaded: application/views/common/footer.php
DEBUG - 2011-04-14 17:19:38 --> File loaded: application/views/layout/main.php
DEBUG - 2011-04-14 17:19:38 --> Final output sent to browser
DEBUG - 2011-04-14 17:19:38 --> Total execution time: 0.0314
DEBUG - 2011-04-14 17:19:39 --> Config Class Initialized
DEBUG - 2011-04-14 17:19:39 --> Hooks Class Initialized
DEBUG - 2011-04-14 17:19:39 --> Utf8 Class Initialized
DEBUG - 2011-04-14 17:19:39 --> UTF-8 Support Enabled
DEBUG - 2011-04-14 17:19:39 --> URI Class Initialized
DEBUG - 2011-04-14 17:19:39 --> Router Class Initialized
DEBUG - 2011-04-14 17:19:39 --> Output Class Initialized
DEBUG - 2011-04-14 17:19:39 --> Input Class Initialized
DEBUG - 2011-04-14 17:19:39 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-14 17:19:39 --> Language Class Initialized
DEBUG - 2011-04-14 17:19:39 --> Loader Class Initialized
DEBUG - 2011-04-14 17:19:39 --> Controller Class Initialized
DEBUG - 2011-04-14 17:19:39 --> Model Class Initialized
DEBUG - 2011-04-14 17:19:39 --> Model Class Initialized
DEBUG - 2011-04-14 17:19:39 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-14 17:19:39 --> Database Driver Class Initialized
DEBUG - 2011-04-14 17:19:39 --> Final output sent to browser
DEBUG - 2011-04-14 17:19:39 --> Total execution time: 0.4617
DEBUG - 2011-04-14 18:46:26 --> Config Class Initialized
DEBUG - 2011-04-14 18:46:26 --> Hooks Class Initialized
DEBUG - 2011-04-14 18:46:26 --> Utf8 Class Initialized
DEBUG - 2011-04-14 18:46:26 --> UTF-8 Support Enabled
DEBUG - 2011-04-14 18:46:26 --> URI Class Initialized
DEBUG - 2011-04-14 18:46:26 --> Router Class Initialized
DEBUG - 2011-04-14 18:46:27 --> Output Class Initialized
DEBUG - 2011-04-14 18:46:27 --> Input Class Initialized
DEBUG - 2011-04-14 18:46:27 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-14 18:46:27 --> Language Class Initialized
DEBUG - 2011-04-14 18:46:27 --> Loader Class Initialized
DEBUG - 2011-04-14 18:46:27 --> Controller Class Initialized
ERROR - 2011-04-14 18:46:27 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-04-14 18:46:27 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-04-14 18:46:27 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-04-14 18:46:27 --> Model Class Initialized
DEBUG - 2011-04-14 18:46:27 --> Model Class Initialized
DEBUG - 2011-04-14 18:46:27 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-14 18:46:27 --> Database Driver Class Initialized
DEBUG - 2011-04-14 18:46:27 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-04-14 18:46:27 --> Helper loaded: url_helper
DEBUG - 2011-04-14 18:46:27 --> File loaded: application/views/common/header.php
DEBUG - 2011-04-14 18:46:27 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-04-14 18:46:27 --> File loaded: application/views/common/footer.php
DEBUG - 2011-04-14 18:46:27 --> File loaded: application/views/layout/main.php
DEBUG - 2011-04-14 18:46:27 --> Final output sent to browser
DEBUG - 2011-04-14 18:46:27 --> Total execution time: 1.5931
DEBUG - 2011-04-14 18:46:30 --> Config Class Initialized
DEBUG - 2011-04-14 18:46:30 --> Hooks Class Initialized
DEBUG - 2011-04-14 18:46:30 --> Utf8 Class Initialized
DEBUG - 2011-04-14 18:46:30 --> UTF-8 Support Enabled
DEBUG - 2011-04-14 18:46:30 --> URI Class Initialized
DEBUG - 2011-04-14 18:46:30 --> Router Class Initialized
DEBUG - 2011-04-14 18:46:30 --> Output Class Initialized
DEBUG - 2011-04-14 18:46:30 --> Input Class Initialized
DEBUG - 2011-04-14 18:46:30 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-14 18:46:30 --> Language Class Initialized
DEBUG - 2011-04-14 18:46:30 --> Loader Class Initialized
DEBUG - 2011-04-14 18:46:30 --> Controller Class Initialized
DEBUG - 2011-04-14 18:46:30 --> Model Class Initialized
DEBUG - 2011-04-14 18:46:30 --> Model Class Initialized
DEBUG - 2011-04-14 18:46:30 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-14 18:46:30 --> Database Driver Class Initialized
DEBUG - 2011-04-14 18:46:31 --> Final output sent to browser
DEBUG - 2011-04-14 18:46:31 --> Total execution time: 0.7544
DEBUG - 2011-04-14 18:46:46 --> Config Class Initialized
DEBUG - 2011-04-14 18:46:46 --> Hooks Class Initialized
DEBUG - 2011-04-14 18:46:46 --> Utf8 Class Initialized
DEBUG - 2011-04-14 18:46:46 --> UTF-8 Support Enabled
DEBUG - 2011-04-14 18:46:46 --> URI Class Initialized
DEBUG - 2011-04-14 18:46:46 --> Router Class Initialized
ERROR - 2011-04-14 18:46:46 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-04-14 19:09:28 --> Config Class Initialized
DEBUG - 2011-04-14 19:09:28 --> Hooks Class Initialized
DEBUG - 2011-04-14 19:09:28 --> Utf8 Class Initialized
DEBUG - 2011-04-14 19:09:28 --> UTF-8 Support Enabled
DEBUG - 2011-04-14 19:09:28 --> URI Class Initialized
DEBUG - 2011-04-14 19:09:28 --> Router Class Initialized
DEBUG - 2011-04-14 19:09:28 --> Output Class Initialized
DEBUG - 2011-04-14 19:09:28 --> Input Class Initialized
DEBUG - 2011-04-14 19:09:28 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-14 19:09:28 --> Language Class Initialized
DEBUG - 2011-04-14 19:09:28 --> Loader Class Initialized
DEBUG - 2011-04-14 19:09:28 --> Controller Class Initialized
ERROR - 2011-04-14 19:09:28 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-04-14 19:09:28 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-04-14 19:09:28 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-04-14 19:09:28 --> Model Class Initialized
DEBUG - 2011-04-14 19:09:28 --> Model Class Initialized
DEBUG - 2011-04-14 19:09:28 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-14 19:09:28 --> Database Driver Class Initialized
DEBUG - 2011-04-14 19:09:28 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-04-14 19:09:28 --> Helper loaded: url_helper
DEBUG - 2011-04-14 19:09:28 --> File loaded: application/views/common/header.php
DEBUG - 2011-04-14 19:09:28 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-04-14 19:09:28 --> File loaded: application/views/common/footer.php
DEBUG - 2011-04-14 19:09:28 --> File loaded: application/views/layout/main.php
DEBUG - 2011-04-14 19:09:28 --> Final output sent to browser
DEBUG - 2011-04-14 19:09:28 --> Total execution time: 0.1037
DEBUG - 2011-04-14 19:17:02 --> Config Class Initialized
DEBUG - 2011-04-14 19:17:02 --> Hooks Class Initialized
DEBUG - 2011-04-14 19:17:02 --> Utf8 Class Initialized
DEBUG - 2011-04-14 19:17:02 --> UTF-8 Support Enabled
DEBUG - 2011-04-14 19:17:02 --> URI Class Initialized
DEBUG - 2011-04-14 19:17:02 --> Router Class Initialized
DEBUG - 2011-04-14 19:17:02 --> Output Class Initialized
DEBUG - 2011-04-14 19:17:02 --> Input Class Initialized
DEBUG - 2011-04-14 19:17:02 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-14 19:17:02 --> Language Class Initialized
DEBUG - 2011-04-14 19:17:02 --> Loader Class Initialized
DEBUG - 2011-04-14 19:17:02 --> Controller Class Initialized
ERROR - 2011-04-14 19:17:02 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-04-14 19:17:02 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-04-14 19:17:02 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-04-14 19:17:02 --> Model Class Initialized
DEBUG - 2011-04-14 19:17:02 --> Model Class Initialized
DEBUG - 2011-04-14 19:17:02 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-14 19:17:02 --> Database Driver Class Initialized
DEBUG - 2011-04-14 19:17:02 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-04-14 19:17:02 --> Helper loaded: url_helper
DEBUG - 2011-04-14 19:17:02 --> File loaded: application/views/common/header.php
DEBUG - 2011-04-14 19:17:02 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-04-14 19:17:02 --> File loaded: application/views/common/footer.php
DEBUG - 2011-04-14 19:17:02 --> File loaded: application/views/layout/main.php
DEBUG - 2011-04-14 19:17:02 --> Final output sent to browser
DEBUG - 2011-04-14 19:17:02 --> Total execution time: 0.0896
DEBUG - 2011-04-14 20:41:43 --> Config Class Initialized
DEBUG - 2011-04-14 20:41:43 --> Hooks Class Initialized
DEBUG - 2011-04-14 20:41:43 --> Utf8 Class Initialized
DEBUG - 2011-04-14 20:41:43 --> UTF-8 Support Enabled
DEBUG - 2011-04-14 20:41:43 --> URI Class Initialized
DEBUG - 2011-04-14 20:41:43 --> Router Class Initialized
DEBUG - 2011-04-14 20:41:43 --> Output Class Initialized
DEBUG - 2011-04-14 20:41:43 --> Input Class Initialized
DEBUG - 2011-04-14 20:41:43 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-14 20:41:43 --> Language Class Initialized
DEBUG - 2011-04-14 20:41:43 --> Loader Class Initialized
DEBUG - 2011-04-14 20:41:43 --> Controller Class Initialized
DEBUG - 2011-04-14 20:41:43 --> Model Class Initialized
DEBUG - 2011-04-14 20:41:43 --> Model Class Initialized
DEBUG - 2011-04-14 20:41:43 --> Model Class Initialized
DEBUG - 2011-04-14 20:41:43 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-14 20:41:44 --> Database Driver Class Initialized
DEBUG - 2011-04-14 20:41:44 --> File loaded: application/views/table/main.php
DEBUG - 2011-04-14 20:41:44 --> Helper loaded: url_helper
DEBUG - 2011-04-14 20:41:44 --> File loaded: application/views/common/header.php
DEBUG - 2011-04-14 20:41:44 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-04-14 20:41:44 --> File loaded: application/views/common/footer.php
DEBUG - 2011-04-14 20:41:44 --> File loaded: application/views/layout/main.php
DEBUG - 2011-04-14 20:41:44 --> Final output sent to browser
DEBUG - 2011-04-14 20:41:44 --> Total execution time: 0.4808
DEBUG - 2011-04-14 20:41:45 --> Config Class Initialized
DEBUG - 2011-04-14 20:41:45 --> Hooks Class Initialized
DEBUG - 2011-04-14 20:41:45 --> Utf8 Class Initialized
DEBUG - 2011-04-14 20:41:45 --> UTF-8 Support Enabled
DEBUG - 2011-04-14 20:41:45 --> URI Class Initialized
DEBUG - 2011-04-14 20:41:45 --> Router Class Initialized
DEBUG - 2011-04-14 20:41:45 --> Output Class Initialized
DEBUG - 2011-04-14 20:41:45 --> Input Class Initialized
DEBUG - 2011-04-14 20:41:45 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-14 20:41:45 --> Language Class Initialized
DEBUG - 2011-04-14 20:41:45 --> Loader Class Initialized
DEBUG - 2011-04-14 20:41:45 --> Controller Class Initialized
ERROR - 2011-04-14 20:41:45 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-04-14 20:41:45 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-04-14 20:41:45 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-04-14 20:41:45 --> Model Class Initialized
DEBUG - 2011-04-14 20:41:45 --> Model Class Initialized
DEBUG - 2011-04-14 20:41:45 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-14 20:41:45 --> Database Driver Class Initialized
DEBUG - 2011-04-14 20:41:45 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-04-14 20:41:45 --> Helper loaded: url_helper
DEBUG - 2011-04-14 20:41:45 --> File loaded: application/views/common/header.php
DEBUG - 2011-04-14 20:41:45 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-04-14 20:41:45 --> File loaded: application/views/common/footer.php
DEBUG - 2011-04-14 20:41:45 --> File loaded: application/views/layout/main.php
DEBUG - 2011-04-14 20:41:45 --> Final output sent to browser
DEBUG - 2011-04-14 20:41:45 --> Total execution time: 0.0668
DEBUG - 2011-04-14 21:26:19 --> Config Class Initialized
DEBUG - 2011-04-14 21:26:19 --> Hooks Class Initialized
DEBUG - 2011-04-14 21:26:19 --> Utf8 Class Initialized
DEBUG - 2011-04-14 21:26:19 --> UTF-8 Support Enabled
DEBUG - 2011-04-14 21:26:19 --> URI Class Initialized
DEBUG - 2011-04-14 21:26:19 --> Router Class Initialized
ERROR - 2011-04-14 21:26:19 --> 404 Page Not Found --> robots.txt
DEBUG - 2011-04-14 21:38:58 --> Config Class Initialized
DEBUG - 2011-04-14 21:38:58 --> Hooks Class Initialized
DEBUG - 2011-04-14 21:38:58 --> Utf8 Class Initialized
DEBUG - 2011-04-14 21:38:58 --> UTF-8 Support Enabled
DEBUG - 2011-04-14 21:38:58 --> URI Class Initialized
DEBUG - 2011-04-14 21:38:58 --> Router Class Initialized
DEBUG - 2011-04-14 21:38:58 --> Output Class Initialized
DEBUG - 2011-04-14 21:38:58 --> Input Class Initialized
DEBUG - 2011-04-14 21:38:58 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-14 21:38:58 --> Language Class Initialized
DEBUG - 2011-04-14 21:38:58 --> Loader Class Initialized
DEBUG - 2011-04-14 21:38:58 --> Controller Class Initialized
DEBUG - 2011-04-14 21:38:58 --> Model Class Initialized
DEBUG - 2011-04-14 21:38:58 --> Model Class Initialized
DEBUG - 2011-04-14 21:38:58 --> Model Class Initialized
DEBUG - 2011-04-14 21:38:58 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-14 21:38:58 --> Database Driver Class Initialized
DEBUG - 2011-04-14 21:38:59 --> File loaded: application/views/table/main.php
DEBUG - 2011-04-14 21:38:59 --> Helper loaded: url_helper
DEBUG - 2011-04-14 21:38:59 --> File loaded: application/views/common/header.php
DEBUG - 2011-04-14 21:38:59 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-04-14 21:38:59 --> File loaded: application/views/common/footer.php
DEBUG - 2011-04-14 21:38:59 --> File loaded: application/views/layout/main.php
DEBUG - 2011-04-14 21:38:59 --> Final output sent to browser
DEBUG - 2011-04-14 21:38:59 --> Total execution time: 0.6618
DEBUG - 2011-04-14 21:39:01 --> Config Class Initialized
DEBUG - 2011-04-14 21:39:01 --> Hooks Class Initialized
DEBUG - 2011-04-14 21:39:01 --> Utf8 Class Initialized
DEBUG - 2011-04-14 21:39:01 --> UTF-8 Support Enabled
DEBUG - 2011-04-14 21:39:01 --> URI Class Initialized
DEBUG - 2011-04-14 21:39:01 --> Router Class Initialized
ERROR - 2011-04-14 21:39:01 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-04-14 21:39:02 --> Config Class Initialized
DEBUG - 2011-04-14 21:39:02 --> Hooks Class Initialized
DEBUG - 2011-04-14 21:39:02 --> Utf8 Class Initialized
DEBUG - 2011-04-14 21:39:02 --> UTF-8 Support Enabled
DEBUG - 2011-04-14 21:39:02 --> URI Class Initialized
DEBUG - 2011-04-14 21:39:02 --> Router Class Initialized
ERROR - 2011-04-14 21:39:02 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-04-14 21:49:47 --> Config Class Initialized
DEBUG - 2011-04-14 21:49:47 --> Hooks Class Initialized
DEBUG - 2011-04-14 21:49:47 --> Utf8 Class Initialized
DEBUG - 2011-04-14 21:49:47 --> UTF-8 Support Enabled
DEBUG - 2011-04-14 21:49:47 --> URI Class Initialized
DEBUG - 2011-04-14 21:49:47 --> Router Class Initialized
DEBUG - 2011-04-14 21:49:47 --> Output Class Initialized
DEBUG - 2011-04-14 21:49:47 --> Input Class Initialized
DEBUG - 2011-04-14 21:49:47 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-14 21:49:47 --> Language Class Initialized
DEBUG - 2011-04-14 21:49:47 --> Loader Class Initialized
DEBUG - 2011-04-14 21:49:47 --> Controller Class Initialized
DEBUG - 2011-04-14 21:49:47 --> Model Class Initialized
DEBUG - 2011-04-14 21:49:47 --> Model Class Initialized
DEBUG - 2011-04-14 21:49:47 --> Model Class Initialized
DEBUG - 2011-04-14 21:49:47 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-14 21:49:47 --> Database Driver Class Initialized
DEBUG - 2011-04-14 21:49:47 --> File loaded: application/views/table/main.php
DEBUG - 2011-04-14 21:49:47 --> Helper loaded: url_helper
DEBUG - 2011-04-14 21:49:47 --> File loaded: application/views/common/header.php
DEBUG - 2011-04-14 21:49:47 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-04-14 21:49:47 --> File loaded: application/views/common/footer.php
DEBUG - 2011-04-14 21:49:47 --> File loaded: application/views/layout/main.php
DEBUG - 2011-04-14 21:49:47 --> Final output sent to browser
DEBUG - 2011-04-14 21:49:47 --> Total execution time: 0.1755
DEBUG - 2011-04-14 22:06:55 --> Config Class Initialized
DEBUG - 2011-04-14 22:06:55 --> Hooks Class Initialized
DEBUG - 2011-04-14 22:06:55 --> Utf8 Class Initialized
DEBUG - 2011-04-14 22:06:55 --> UTF-8 Support Enabled
DEBUG - 2011-04-14 22:06:55 --> URI Class Initialized
DEBUG - 2011-04-14 22:06:55 --> Router Class Initialized
DEBUG - 2011-04-14 22:06:55 --> Output Class Initialized
DEBUG - 2011-04-14 22:06:55 --> Input Class Initialized
DEBUG - 2011-04-14 22:06:55 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-14 22:06:55 --> Language Class Initialized
DEBUG - 2011-04-14 22:06:55 --> Loader Class Initialized
DEBUG - 2011-04-14 22:06:55 --> Controller Class Initialized
ERROR - 2011-04-14 22:06:55 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-04-14 22:06:55 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-04-14 22:06:55 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-04-14 22:06:55 --> Model Class Initialized
DEBUG - 2011-04-14 22:06:55 --> Model Class Initialized
DEBUG - 2011-04-14 22:06:55 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-14 22:06:55 --> Database Driver Class Initialized
DEBUG - 2011-04-14 22:06:55 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-04-14 22:06:55 --> Helper loaded: url_helper
DEBUG - 2011-04-14 22:06:55 --> File loaded: application/views/common/header.php
DEBUG - 2011-04-14 22:06:55 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-04-14 22:06:55 --> File loaded: application/views/common/footer.php
DEBUG - 2011-04-14 22:06:55 --> File loaded: application/views/layout/main.php
DEBUG - 2011-04-14 22:06:55 --> Final output sent to browser
DEBUG - 2011-04-14 22:06:55 --> Total execution time: 0.1352
DEBUG - 2011-04-14 23:04:08 --> Config Class Initialized
DEBUG - 2011-04-14 23:04:08 --> Hooks Class Initialized
DEBUG - 2011-04-14 23:04:08 --> Utf8 Class Initialized
DEBUG - 2011-04-14 23:04:08 --> UTF-8 Support Enabled
DEBUG - 2011-04-14 23:04:08 --> URI Class Initialized
DEBUG - 2011-04-14 23:04:08 --> Router Class Initialized
DEBUG - 2011-04-14 23:04:08 --> Output Class Initialized
DEBUG - 2011-04-14 23:04:08 --> Input Class Initialized
DEBUG - 2011-04-14 23:04:08 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-14 23:04:08 --> Language Class Initialized
DEBUG - 2011-04-14 23:04:08 --> Loader Class Initialized
DEBUG - 2011-04-14 23:04:08 --> Controller Class Initialized
ERROR - 2011-04-14 23:04:09 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-04-14 23:04:09 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-04-14 23:04:09 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-04-14 23:04:09 --> Model Class Initialized
DEBUG - 2011-04-14 23:04:09 --> Model Class Initialized
DEBUG - 2011-04-14 23:04:09 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-14 23:04:09 --> Database Driver Class Initialized
DEBUG - 2011-04-14 23:04:09 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-04-14 23:04:09 --> Helper loaded: url_helper
DEBUG - 2011-04-14 23:04:09 --> File loaded: application/views/common/header.php
DEBUG - 2011-04-14 23:04:09 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-04-14 23:04:09 --> File loaded: application/views/common/footer.php
DEBUG - 2011-04-14 23:04:09 --> File loaded: application/views/layout/main.php
DEBUG - 2011-04-14 23:04:09 --> Final output sent to browser
DEBUG - 2011-04-14 23:04:09 --> Total execution time: 0.5745
DEBUG - 2011-04-14 23:24:56 --> Config Class Initialized
DEBUG - 2011-04-14 23:24:56 --> Hooks Class Initialized
DEBUG - 2011-04-14 23:24:56 --> Utf8 Class Initialized
DEBUG - 2011-04-14 23:24:56 --> UTF-8 Support Enabled
DEBUG - 2011-04-14 23:24:56 --> URI Class Initialized
DEBUG - 2011-04-14 23:24:56 --> Router Class Initialized
DEBUG - 2011-04-14 23:24:56 --> Output Class Initialized
DEBUG - 2011-04-14 23:24:56 --> Input Class Initialized
DEBUG - 2011-04-14 23:24:56 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-14 23:24:56 --> Language Class Initialized
DEBUG - 2011-04-14 23:24:56 --> Loader Class Initialized
DEBUG - 2011-04-14 23:24:56 --> Controller Class Initialized
DEBUG - 2011-04-14 23:24:57 --> Model Class Initialized
DEBUG - 2011-04-14 23:24:57 --> Model Class Initialized
DEBUG - 2011-04-14 23:24:57 --> Model Class Initialized
DEBUG - 2011-04-14 23:24:57 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-14 23:24:57 --> Database Driver Class Initialized
DEBUG - 2011-04-14 23:24:57 --> File loaded: application/views/table/main.php
DEBUG - 2011-04-14 23:24:57 --> Helper loaded: url_helper
DEBUG - 2011-04-14 23:24:57 --> File loaded: application/views/common/header.php
DEBUG - 2011-04-14 23:24:57 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-04-14 23:24:57 --> File loaded: application/views/common/footer.php
DEBUG - 2011-04-14 23:24:57 --> File loaded: application/views/layout/main.php
DEBUG - 2011-04-14 23:24:57 --> Final output sent to browser
DEBUG - 2011-04-14 23:24:57 --> Total execution time: 0.4504
DEBUG - 2011-04-14 23:24:58 --> Config Class Initialized
DEBUG - 2011-04-14 23:24:58 --> Hooks Class Initialized
DEBUG - 2011-04-14 23:24:58 --> Utf8 Class Initialized
DEBUG - 2011-04-14 23:24:58 --> UTF-8 Support Enabled
DEBUG - 2011-04-14 23:24:58 --> URI Class Initialized
DEBUG - 2011-04-14 23:24:58 --> Router Class Initialized
DEBUG - 2011-04-14 23:24:58 --> Output Class Initialized
DEBUG - 2011-04-14 23:24:58 --> Input Class Initialized
DEBUG - 2011-04-14 23:24:58 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-14 23:24:58 --> Language Class Initialized
DEBUG - 2011-04-14 23:24:59 --> Loader Class Initialized
DEBUG - 2011-04-14 23:24:59 --> Controller Class Initialized
ERROR - 2011-04-14 23:24:59 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-04-14 23:24:59 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-04-14 23:24:59 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-04-14 23:24:59 --> Model Class Initialized
DEBUG - 2011-04-14 23:24:59 --> Model Class Initialized
DEBUG - 2011-04-14 23:24:59 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-14 23:24:59 --> Database Driver Class Initialized
DEBUG - 2011-04-14 23:24:59 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-04-14 23:24:59 --> Helper loaded: url_helper
DEBUG - 2011-04-14 23:24:59 --> File loaded: application/views/common/header.php
DEBUG - 2011-04-14 23:24:59 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-04-14 23:24:59 --> File loaded: application/views/common/footer.php
DEBUG - 2011-04-14 23:24:59 --> File loaded: application/views/layout/main.php
DEBUG - 2011-04-14 23:24:59 --> Final output sent to browser
DEBUG - 2011-04-14 23:24:59 --> Total execution time: 0.0510
DEBUG - 2011-04-14 23:49:20 --> Config Class Initialized
DEBUG - 2011-04-14 23:49:20 --> Hooks Class Initialized
DEBUG - 2011-04-14 23:49:20 --> Utf8 Class Initialized
DEBUG - 2011-04-14 23:49:20 --> UTF-8 Support Enabled
DEBUG - 2011-04-14 23:49:20 --> URI Class Initialized
DEBUG - 2011-04-14 23:49:20 --> Router Class Initialized
ERROR - 2011-04-14 23:49:21 --> 404 Page Not Found --> robots.txt
DEBUG - 2011-04-14 23:49:21 --> Config Class Initialized
DEBUG - 2011-04-14 23:49:21 --> Hooks Class Initialized
DEBUG - 2011-04-14 23:49:21 --> Utf8 Class Initialized
DEBUG - 2011-04-14 23:49:21 --> UTF-8 Support Enabled
DEBUG - 2011-04-14 23:49:21 --> URI Class Initialized
DEBUG - 2011-04-14 23:49:21 --> Router Class Initialized
DEBUG - 2011-04-14 23:49:21 --> Output Class Initialized
DEBUG - 2011-04-14 23:49:21 --> Input Class Initialized
DEBUG - 2011-04-14 23:49:21 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-14 23:49:21 --> Language Class Initialized
DEBUG - 2011-04-14 23:49:22 --> Loader Class Initialized
DEBUG - 2011-04-14 23:49:22 --> Controller Class Initialized
ERROR - 2011-04-14 23:49:22 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-04-14 23:49:22 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-04-14 23:49:22 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-04-14 23:49:22 --> Model Class Initialized
DEBUG - 2011-04-14 23:49:22 --> Model Class Initialized
DEBUG - 2011-04-14 23:49:22 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-14 23:49:22 --> Database Driver Class Initialized
DEBUG - 2011-04-14 23:49:22 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-04-14 23:49:22 --> Helper loaded: url_helper
DEBUG - 2011-04-14 23:49:22 --> File loaded: application/views/common/header.php
DEBUG - 2011-04-14 23:49:22 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-04-14 23:49:22 --> File loaded: application/views/common/footer.php
DEBUG - 2011-04-14 23:49:22 --> File loaded: application/views/layout/main.php
DEBUG - 2011-04-14 23:49:22 --> Final output sent to browser
DEBUG - 2011-04-14 23:49:22 --> Total execution time: 0.8649

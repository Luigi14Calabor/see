<?php  if ( ! defined('BASEPATH')) exit('No direct script access allowed'); ?>

DEBUG - 2011-05-05 00:19:31 --> Config Class Initialized
DEBUG - 2011-05-05 00:19:31 --> Hooks Class Initialized
DEBUG - 2011-05-05 00:19:31 --> Utf8 Class Initialized
DEBUG - 2011-05-05 00:19:31 --> UTF-8 Support Enabled
DEBUG - 2011-05-05 00:19:31 --> URI Class Initialized
DEBUG - 2011-05-05 00:19:31 --> Router Class Initialized
DEBUG - 2011-05-05 00:19:32 --> No URI present. Default controller set.
DEBUG - 2011-05-05 00:19:32 --> Output Class Initialized
DEBUG - 2011-05-05 00:19:32 --> Input Class Initialized
DEBUG - 2011-05-05 00:19:32 --> Global POST and COOKIE data sanitized
DEBUG - 2011-05-05 00:19:32 --> Language Class Initialized
DEBUG - 2011-05-05 00:19:32 --> Loader Class Initialized
DEBUG - 2011-05-05 00:19:32 --> Controller Class Initialized
DEBUG - 2011-05-05 00:19:32 --> File loaded: application/views/splash/main.php
DEBUG - 2011-05-05 00:19:32 --> Helper loaded: url_helper
DEBUG - 2011-05-05 00:19:32 --> File loaded: application/views/common/header.php
DEBUG - 2011-05-05 00:19:32 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-05-05 00:19:32 --> File loaded: application/views/common/footer.php
DEBUG - 2011-05-05 00:19:32 --> File loaded: application/views/layout/main.php
DEBUG - 2011-05-05 00:19:32 --> Final output sent to browser
DEBUG - 2011-05-05 00:19:32 --> Total execution time: 0.4176
DEBUG - 2011-05-05 00:38:05 --> Config Class Initialized
DEBUG - 2011-05-05 00:38:05 --> Hooks Class Initialized
DEBUG - 2011-05-05 00:38:05 --> Utf8 Class Initialized
DEBUG - 2011-05-05 00:38:05 --> UTF-8 Support Enabled
DEBUG - 2011-05-05 00:38:05 --> URI Class Initialized
DEBUG - 2011-05-05 00:38:05 --> Router Class Initialized
ERROR - 2011-05-05 00:38:05 --> 404 Page Not Found --> robots.txt
DEBUG - 2011-05-05 00:40:10 --> Config Class Initialized
DEBUG - 2011-05-05 00:40:10 --> Hooks Class Initialized
DEBUG - 2011-05-05 00:40:10 --> Utf8 Class Initialized
DEBUG - 2011-05-05 00:40:10 --> UTF-8 Support Enabled
DEBUG - 2011-05-05 00:40:10 --> URI Class Initialized
DEBUG - 2011-05-05 00:40:10 --> Router Class Initialized
DEBUG - 2011-05-05 00:40:10 --> Output Class Initialized
DEBUG - 2011-05-05 00:40:10 --> Input Class Initialized
DEBUG - 2011-05-05 00:40:10 --> Global POST and COOKIE data sanitized
DEBUG - 2011-05-05 00:40:10 --> Language Class Initialized
DEBUG - 2011-05-05 00:40:10 --> Loader Class Initialized
DEBUG - 2011-05-05 00:40:10 --> Controller Class Initialized
ERROR - 2011-05-05 00:40:11 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-05-05 00:40:11 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-05-05 00:40:11 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-05-05 00:40:11 --> Model Class Initialized
DEBUG - 2011-05-05 00:40:11 --> Model Class Initialized
DEBUG - 2011-05-05 00:40:11 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-05-05 00:40:12 --> Database Driver Class Initialized
DEBUG - 2011-05-05 00:40:12 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-05-05 00:40:12 --> Helper loaded: url_helper
DEBUG - 2011-05-05 00:40:12 --> File loaded: application/views/common/header.php
DEBUG - 2011-05-05 00:40:12 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-05-05 00:40:13 --> File loaded: application/views/common/footer.php
DEBUG - 2011-05-05 00:40:13 --> File loaded: application/views/layout/main.php
DEBUG - 2011-05-05 00:40:13 --> Final output sent to browser
DEBUG - 2011-05-05 00:40:13 --> Total execution time: 3.0870
DEBUG - 2011-05-05 01:16:56 --> Config Class Initialized
DEBUG - 2011-05-05 01:16:56 --> Hooks Class Initialized
DEBUG - 2011-05-05 01:16:56 --> Utf8 Class Initialized
DEBUG - 2011-05-05 01:16:56 --> UTF-8 Support Enabled
DEBUG - 2011-05-05 01:16:56 --> URI Class Initialized
DEBUG - 2011-05-05 01:16:56 --> Router Class Initialized
DEBUG - 2011-05-05 01:16:56 --> Output Class Initialized
DEBUG - 2011-05-05 01:16:56 --> Input Class Initialized
DEBUG - 2011-05-05 01:16:56 --> Global POST and COOKIE data sanitized
DEBUG - 2011-05-05 01:16:56 --> Language Class Initialized
DEBUG - 2011-05-05 01:16:56 --> Loader Class Initialized
DEBUG - 2011-05-05 01:16:56 --> Controller Class Initialized
ERROR - 2011-05-05 01:16:56 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-05-05 01:16:56 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-05-05 01:16:56 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-05-05 01:16:56 --> Model Class Initialized
DEBUG - 2011-05-05 01:16:56 --> Model Class Initialized
DEBUG - 2011-05-05 01:16:56 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-05-05 01:16:56 --> Database Driver Class Initialized
DEBUG - 2011-05-05 01:16:56 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-05-05 01:16:56 --> Helper loaded: url_helper
DEBUG - 2011-05-05 01:16:56 --> File loaded: application/views/common/header.php
DEBUG - 2011-05-05 01:16:56 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-05-05 01:16:56 --> File loaded: application/views/common/footer.php
DEBUG - 2011-05-05 01:16:56 --> File loaded: application/views/layout/main.php
DEBUG - 2011-05-05 01:16:56 --> Final output sent to browser
DEBUG - 2011-05-05 01:16:56 --> Total execution time: 0.2902
DEBUG - 2011-05-05 01:16:57 --> Config Class Initialized
DEBUG - 2011-05-05 01:16:57 --> Hooks Class Initialized
DEBUG - 2011-05-05 01:16:57 --> Utf8 Class Initialized
DEBUG - 2011-05-05 01:16:57 --> UTF-8 Support Enabled
DEBUG - 2011-05-05 01:16:57 --> URI Class Initialized
DEBUG - 2011-05-05 01:16:57 --> Router Class Initialized
DEBUG - 2011-05-05 01:16:57 --> Output Class Initialized
DEBUG - 2011-05-05 01:16:57 --> Input Class Initialized
DEBUG - 2011-05-05 01:16:57 --> Global POST and COOKIE data sanitized
DEBUG - 2011-05-05 01:16:57 --> Language Class Initialized
DEBUG - 2011-05-05 01:16:57 --> Loader Class Initialized
DEBUG - 2011-05-05 01:16:57 --> Controller Class Initialized
DEBUG - 2011-05-05 01:16:57 --> Model Class Initialized
DEBUG - 2011-05-05 01:16:57 --> Model Class Initialized
DEBUG - 2011-05-05 01:16:57 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-05-05 01:16:57 --> Database Driver Class Initialized
DEBUG - 2011-05-05 01:16:58 --> Final output sent to browser
DEBUG - 2011-05-05 01:16:58 --> Total execution time: 0.6192
DEBUG - 2011-05-05 01:16:59 --> Config Class Initialized
DEBUG - 2011-05-05 01:16:59 --> Hooks Class Initialized
DEBUG - 2011-05-05 01:16:59 --> Utf8 Class Initialized
DEBUG - 2011-05-05 01:16:59 --> UTF-8 Support Enabled
DEBUG - 2011-05-05 01:16:59 --> URI Class Initialized
DEBUG - 2011-05-05 01:16:59 --> Router Class Initialized
ERROR - 2011-05-05 01:16:59 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-05-05 01:16:59 --> Config Class Initialized
DEBUG - 2011-05-05 01:16:59 --> Hooks Class Initialized
DEBUG - 2011-05-05 01:16:59 --> Utf8 Class Initialized
DEBUG - 2011-05-05 01:16:59 --> UTF-8 Support Enabled
DEBUG - 2011-05-05 01:16:59 --> URI Class Initialized
DEBUG - 2011-05-05 01:16:59 --> Router Class Initialized
ERROR - 2011-05-05 01:16:59 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-05-05 01:17:30 --> Config Class Initialized
DEBUG - 2011-05-05 01:17:30 --> Hooks Class Initialized
DEBUG - 2011-05-05 01:17:30 --> Utf8 Class Initialized
DEBUG - 2011-05-05 01:17:30 --> UTF-8 Support Enabled
DEBUG - 2011-05-05 01:17:30 --> URI Class Initialized
DEBUG - 2011-05-05 01:17:30 --> Router Class Initialized
ERROR - 2011-05-05 01:17:30 --> 404 Page Not Found --> robots.txt
DEBUG - 2011-05-05 01:49:22 --> Config Class Initialized
DEBUG - 2011-05-05 01:49:22 --> Hooks Class Initialized
DEBUG - 2011-05-05 01:49:22 --> Utf8 Class Initialized
DEBUG - 2011-05-05 01:49:22 --> UTF-8 Support Enabled
DEBUG - 2011-05-05 01:49:22 --> URI Class Initialized
DEBUG - 2011-05-05 01:49:22 --> Router Class Initialized
ERROR - 2011-05-05 01:49:22 --> 404 Page Not Found --> robots.txt
DEBUG - 2011-05-05 01:50:10 --> Config Class Initialized
DEBUG - 2011-05-05 01:50:10 --> Hooks Class Initialized
DEBUG - 2011-05-05 01:50:10 --> Utf8 Class Initialized
DEBUG - 2011-05-05 01:50:10 --> UTF-8 Support Enabled
DEBUG - 2011-05-05 01:50:10 --> URI Class Initialized
DEBUG - 2011-05-05 01:50:10 --> Router Class Initialized
DEBUG - 2011-05-05 01:50:10 --> No URI present. Default controller set.
DEBUG - 2011-05-05 01:50:10 --> Output Class Initialized
DEBUG - 2011-05-05 01:50:10 --> Input Class Initialized
DEBUG - 2011-05-05 01:50:10 --> Global POST and COOKIE data sanitized
DEBUG - 2011-05-05 01:50:10 --> Language Class Initialized
DEBUG - 2011-05-05 01:50:10 --> Loader Class Initialized
DEBUG - 2011-05-05 01:50:10 --> Controller Class Initialized
DEBUG - 2011-05-05 01:50:11 --> File loaded: application/views/splash/main.php
DEBUG - 2011-05-05 01:50:11 --> Helper loaded: url_helper
DEBUG - 2011-05-05 01:50:11 --> File loaded: application/views/common/header.php
DEBUG - 2011-05-05 01:50:11 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-05-05 01:50:11 --> File loaded: application/views/common/footer.php
DEBUG - 2011-05-05 01:50:11 --> File loaded: application/views/layout/main.php
DEBUG - 2011-05-05 01:50:11 --> Final output sent to browser
DEBUG - 2011-05-05 01:50:11 --> Total execution time: 0.9767
DEBUG - 2011-05-05 02:25:55 --> Config Class Initialized
DEBUG - 2011-05-05 02:25:55 --> Hooks Class Initialized
DEBUG - 2011-05-05 02:25:55 --> Utf8 Class Initialized
DEBUG - 2011-05-05 02:25:55 --> UTF-8 Support Enabled
DEBUG - 2011-05-05 02:25:55 --> URI Class Initialized
DEBUG - 2011-05-05 02:25:55 --> Router Class Initialized
DEBUG - 2011-05-05 02:25:55 --> No URI present. Default controller set.
DEBUG - 2011-05-05 02:25:55 --> Output Class Initialized
DEBUG - 2011-05-05 02:25:55 --> Input Class Initialized
DEBUG - 2011-05-05 02:25:55 --> Global POST and COOKIE data sanitized
DEBUG - 2011-05-05 02:25:55 --> Language Class Initialized
DEBUG - 2011-05-05 02:25:55 --> Loader Class Initialized
DEBUG - 2011-05-05 02:25:55 --> Controller Class Initialized
DEBUG - 2011-05-05 02:25:55 --> File loaded: application/views/splash/main.php
DEBUG - 2011-05-05 02:25:55 --> Helper loaded: url_helper
DEBUG - 2011-05-05 02:25:55 --> File loaded: application/views/common/header.php
DEBUG - 2011-05-05 02:25:55 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-05-05 02:25:55 --> File loaded: application/views/common/footer.php
DEBUG - 2011-05-05 02:25:55 --> File loaded: application/views/layout/main.php
DEBUG - 2011-05-05 02:25:55 --> Final output sent to browser
DEBUG - 2011-05-05 02:25:55 --> Total execution time: 0.2610
DEBUG - 2011-05-05 02:25:57 --> Config Class Initialized
DEBUG - 2011-05-05 02:25:57 --> Hooks Class Initialized
DEBUG - 2011-05-05 02:25:57 --> Utf8 Class Initialized
DEBUG - 2011-05-05 02:25:57 --> UTF-8 Support Enabled
DEBUG - 2011-05-05 02:25:57 --> URI Class Initialized
DEBUG - 2011-05-05 02:25:57 --> Router Class Initialized
ERROR - 2011-05-05 02:25:57 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-05-05 02:25:57 --> Config Class Initialized
DEBUG - 2011-05-05 02:25:57 --> Hooks Class Initialized
DEBUG - 2011-05-05 02:25:57 --> Utf8 Class Initialized
DEBUG - 2011-05-05 02:25:57 --> UTF-8 Support Enabled
DEBUG - 2011-05-05 02:25:57 --> URI Class Initialized
DEBUG - 2011-05-05 02:25:57 --> Router Class Initialized
ERROR - 2011-05-05 02:25:57 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-05-05 02:25:58 --> Config Class Initialized
DEBUG - 2011-05-05 02:25:58 --> Hooks Class Initialized
DEBUG - 2011-05-05 02:25:58 --> Utf8 Class Initialized
DEBUG - 2011-05-05 02:25:58 --> UTF-8 Support Enabled
DEBUG - 2011-05-05 02:25:58 --> URI Class Initialized
DEBUG - 2011-05-05 02:25:58 --> Router Class Initialized
ERROR - 2011-05-05 02:25:58 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-05-05 02:26:02 --> Config Class Initialized
DEBUG - 2011-05-05 02:26:02 --> Hooks Class Initialized
DEBUG - 2011-05-05 02:26:02 --> Utf8 Class Initialized
DEBUG - 2011-05-05 02:26:02 --> UTF-8 Support Enabled
DEBUG - 2011-05-05 02:26:02 --> URI Class Initialized
DEBUG - 2011-05-05 02:26:02 --> Router Class Initialized
DEBUG - 2011-05-05 02:26:02 --> Output Class Initialized
DEBUG - 2011-05-05 02:26:02 --> Input Class Initialized
DEBUG - 2011-05-05 02:26:02 --> Global POST and COOKIE data sanitized
DEBUG - 2011-05-05 02:26:02 --> Language Class Initialized
DEBUG - 2011-05-05 02:26:02 --> Loader Class Initialized
DEBUG - 2011-05-05 02:26:02 --> Controller Class Initialized
DEBUG - 2011-05-05 02:26:02 --> Model Class Initialized
DEBUG - 2011-05-05 02:26:02 --> Model Class Initialized
DEBUG - 2011-05-05 02:26:03 --> Model Class Initialized
DEBUG - 2011-05-05 02:26:03 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-05-05 02:26:03 --> Database Driver Class Initialized
DEBUG - 2011-05-05 02:26:04 --> File loaded: application/views/table/main.php
DEBUG - 2011-05-05 02:26:04 --> Helper loaded: url_helper
DEBUG - 2011-05-05 02:26:04 --> File loaded: application/views/common/header.php
DEBUG - 2011-05-05 02:26:04 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-05-05 02:26:04 --> File loaded: application/views/common/footer.php
DEBUG - 2011-05-05 02:26:04 --> File loaded: application/views/layout/main.php
DEBUG - 2011-05-05 02:26:04 --> Final output sent to browser
DEBUG - 2011-05-05 02:26:04 --> Total execution time: 1.5920
DEBUG - 2011-05-05 02:26:26 --> Config Class Initialized
DEBUG - 2011-05-05 02:26:26 --> Hooks Class Initialized
DEBUG - 2011-05-05 02:26:26 --> Utf8 Class Initialized
DEBUG - 2011-05-05 02:26:26 --> UTF-8 Support Enabled
DEBUG - 2011-05-05 02:26:26 --> URI Class Initialized
DEBUG - 2011-05-05 02:26:26 --> Router Class Initialized
DEBUG - 2011-05-05 02:26:26 --> Output Class Initialized
DEBUG - 2011-05-05 02:26:26 --> Input Class Initialized
DEBUG - 2011-05-05 02:26:26 --> Global POST and COOKIE data sanitized
DEBUG - 2011-05-05 02:26:26 --> Language Class Initialized
DEBUG - 2011-05-05 02:26:26 --> Loader Class Initialized
DEBUG - 2011-05-05 02:26:26 --> Controller Class Initialized
DEBUG - 2011-05-05 02:26:26 --> Model Class Initialized
DEBUG - 2011-05-05 02:26:26 --> Model Class Initialized
DEBUG - 2011-05-05 02:26:26 --> Model Class Initialized
DEBUG - 2011-05-05 02:26:26 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-05-05 02:26:26 --> Database Driver Class Initialized
DEBUG - 2011-05-05 02:26:27 --> File loaded: application/views/table/main.php
DEBUG - 2011-05-05 02:26:27 --> Helper loaded: url_helper
DEBUG - 2011-05-05 02:26:27 --> File loaded: application/views/common/header.php
DEBUG - 2011-05-05 02:26:27 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-05-05 02:26:27 --> File loaded: application/views/common/footer.php
DEBUG - 2011-05-05 02:26:27 --> File loaded: application/views/layout/main.php
DEBUG - 2011-05-05 02:26:27 --> Final output sent to browser
DEBUG - 2011-05-05 02:26:27 --> Total execution time: 0.5642
DEBUG - 2011-05-05 02:26:30 --> Config Class Initialized
DEBUG - 2011-05-05 02:26:30 --> Hooks Class Initialized
DEBUG - 2011-05-05 02:26:30 --> Utf8 Class Initialized
DEBUG - 2011-05-05 02:26:30 --> UTF-8 Support Enabled
DEBUG - 2011-05-05 02:26:30 --> URI Class Initialized
DEBUG - 2011-05-05 02:26:30 --> Router Class Initialized
ERROR - 2011-05-05 02:26:30 --> 404 Page Not Found --> robots.txt
DEBUG - 2011-05-05 02:26:30 --> Config Class Initialized
DEBUG - 2011-05-05 02:26:30 --> Hooks Class Initialized
DEBUG - 2011-05-05 02:26:30 --> Utf8 Class Initialized
DEBUG - 2011-05-05 02:26:30 --> UTF-8 Support Enabled
DEBUG - 2011-05-05 02:26:30 --> URI Class Initialized
DEBUG - 2011-05-05 02:26:30 --> Router Class Initialized
DEBUG - 2011-05-05 02:26:30 --> Output Class Initialized
DEBUG - 2011-05-05 02:26:30 --> Input Class Initialized
DEBUG - 2011-05-05 02:26:30 --> Global POST and COOKIE data sanitized
DEBUG - 2011-05-05 02:26:30 --> Language Class Initialized
DEBUG - 2011-05-05 02:26:30 --> Loader Class Initialized
DEBUG - 2011-05-05 02:26:30 --> Controller Class Initialized
DEBUG - 2011-05-05 02:26:30 --> Model Class Initialized
DEBUG - 2011-05-05 02:26:30 --> Model Class Initialized
DEBUG - 2011-05-05 02:26:30 --> Model Class Initialized
DEBUG - 2011-05-05 02:26:30 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-05-05 02:26:30 --> Database Driver Class Initialized
DEBUG - 2011-05-05 02:26:30 --> File loaded: application/views/table/main.php
DEBUG - 2011-05-05 02:26:30 --> Helper loaded: url_helper
DEBUG - 2011-05-05 02:26:30 --> File loaded: application/views/common/header.php
DEBUG - 2011-05-05 02:26:30 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-05-05 02:26:30 --> File loaded: application/views/common/footer.php
DEBUG - 2011-05-05 02:26:30 --> File loaded: application/views/layout/main.php
DEBUG - 2011-05-05 02:26:30 --> Final output sent to browser
DEBUG - 2011-05-05 02:26:30 --> Total execution time: 0.0641
DEBUG - 2011-05-05 02:27:21 --> Config Class Initialized
DEBUG - 2011-05-05 02:27:21 --> Hooks Class Initialized
DEBUG - 2011-05-05 02:27:21 --> Utf8 Class Initialized
DEBUG - 2011-05-05 02:27:21 --> UTF-8 Support Enabled
DEBUG - 2011-05-05 02:27:21 --> URI Class Initialized
DEBUG - 2011-05-05 02:27:21 --> Router Class Initialized
DEBUG - 2011-05-05 02:27:21 --> Output Class Initialized
DEBUG - 2011-05-05 02:27:21 --> Input Class Initialized
DEBUG - 2011-05-05 02:27:21 --> Global POST and COOKIE data sanitized
DEBUG - 2011-05-05 02:27:21 --> Language Class Initialized
DEBUG - 2011-05-05 02:27:21 --> Loader Class Initialized
DEBUG - 2011-05-05 02:27:21 --> Controller Class Initialized
DEBUG - 2011-05-05 02:27:21 --> Model Class Initialized
DEBUG - 2011-05-05 02:27:21 --> Model Class Initialized
DEBUG - 2011-05-05 02:27:21 --> Model Class Initialized
DEBUG - 2011-05-05 02:27:21 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-05-05 02:27:21 --> Database Driver Class Initialized
DEBUG - 2011-05-05 02:27:21 --> File loaded: application/views/table/main.php
DEBUG - 2011-05-05 02:27:21 --> Helper loaded: url_helper
DEBUG - 2011-05-05 02:27:21 --> File loaded: application/views/common/header.php
DEBUG - 2011-05-05 02:27:21 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-05-05 02:27:21 --> File loaded: application/views/common/footer.php
DEBUG - 2011-05-05 02:27:21 --> File loaded: application/views/layout/main.php
DEBUG - 2011-05-05 02:27:21 --> Final output sent to browser
DEBUG - 2011-05-05 02:27:21 --> Total execution time: 0.5344
DEBUG - 2011-05-05 02:27:22 --> Config Class Initialized
DEBUG - 2011-05-05 02:27:22 --> Hooks Class Initialized
DEBUG - 2011-05-05 02:27:22 --> Utf8 Class Initialized
DEBUG - 2011-05-05 02:27:22 --> UTF-8 Support Enabled
DEBUG - 2011-05-05 02:27:22 --> URI Class Initialized
DEBUG - 2011-05-05 02:27:22 --> Router Class Initialized
DEBUG - 2011-05-05 02:27:22 --> Output Class Initialized
DEBUG - 2011-05-05 02:27:22 --> Input Class Initialized
DEBUG - 2011-05-05 02:27:22 --> Global POST and COOKIE data sanitized
DEBUG - 2011-05-05 02:27:22 --> Language Class Initialized
DEBUG - 2011-05-05 02:27:22 --> Loader Class Initialized
DEBUG - 2011-05-05 02:27:22 --> Controller Class Initialized
DEBUG - 2011-05-05 02:27:22 --> Model Class Initialized
DEBUG - 2011-05-05 02:27:22 --> Model Class Initialized
DEBUG - 2011-05-05 02:27:22 --> Model Class Initialized
DEBUG - 2011-05-05 02:27:22 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-05-05 02:27:22 --> Database Driver Class Initialized
DEBUG - 2011-05-05 02:27:22 --> File loaded: application/views/table/main.php
DEBUG - 2011-05-05 02:27:22 --> Helper loaded: url_helper
DEBUG - 2011-05-05 02:27:22 --> File loaded: application/views/common/header.php
DEBUG - 2011-05-05 02:27:22 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-05-05 02:27:22 --> File loaded: application/views/common/footer.php
DEBUG - 2011-05-05 02:27:22 --> File loaded: application/views/layout/main.php
DEBUG - 2011-05-05 02:27:22 --> Final output sent to browser
DEBUG - 2011-05-05 02:27:22 --> Total execution time: 0.0718
DEBUG - 2011-05-05 02:27:23 --> Config Class Initialized
DEBUG - 2011-05-05 02:27:23 --> Hooks Class Initialized
DEBUG - 2011-05-05 02:27:23 --> Utf8 Class Initialized
DEBUG - 2011-05-05 02:27:23 --> UTF-8 Support Enabled
DEBUG - 2011-05-05 02:27:23 --> URI Class Initialized
DEBUG - 2011-05-05 02:27:23 --> Router Class Initialized
DEBUG - 2011-05-05 02:27:23 --> Output Class Initialized
DEBUG - 2011-05-05 02:27:23 --> Input Class Initialized
DEBUG - 2011-05-05 02:27:23 --> Global POST and COOKIE data sanitized
DEBUG - 2011-05-05 02:27:23 --> Language Class Initialized
DEBUG - 2011-05-05 02:27:23 --> Loader Class Initialized
DEBUG - 2011-05-05 02:27:23 --> Controller Class Initialized
DEBUG - 2011-05-05 02:27:23 --> Model Class Initialized
DEBUG - 2011-05-05 02:27:23 --> Model Class Initialized
DEBUG - 2011-05-05 02:27:23 --> Model Class Initialized
DEBUG - 2011-05-05 02:27:23 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-05-05 02:27:23 --> Database Driver Class Initialized
DEBUG - 2011-05-05 02:27:23 --> File loaded: application/views/table/main.php
DEBUG - 2011-05-05 02:27:23 --> Helper loaded: url_helper
DEBUG - 2011-05-05 02:27:23 --> File loaded: application/views/common/header.php
DEBUG - 2011-05-05 02:27:23 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-05-05 02:27:23 --> File loaded: application/views/common/footer.php
DEBUG - 2011-05-05 02:27:23 --> File loaded: application/views/layout/main.php
DEBUG - 2011-05-05 02:27:23 --> Final output sent to browser
DEBUG - 2011-05-05 02:27:23 --> Total execution time: 0.0589
DEBUG - 2011-05-05 02:27:58 --> Config Class Initialized
DEBUG - 2011-05-05 02:27:58 --> Hooks Class Initialized
DEBUG - 2011-05-05 02:27:58 --> Utf8 Class Initialized
DEBUG - 2011-05-05 02:27:58 --> UTF-8 Support Enabled
DEBUG - 2011-05-05 02:27:58 --> URI Class Initialized
DEBUG - 2011-05-05 02:27:58 --> Router Class Initialized
DEBUG - 2011-05-05 02:27:58 --> Output Class Initialized
DEBUG - 2011-05-05 02:27:58 --> Input Class Initialized
DEBUG - 2011-05-05 02:27:58 --> Global POST and COOKIE data sanitized
DEBUG - 2011-05-05 02:27:58 --> Language Class Initialized
DEBUG - 2011-05-05 02:27:58 --> Loader Class Initialized
DEBUG - 2011-05-05 02:27:58 --> Controller Class Initialized
DEBUG - 2011-05-05 02:27:58 --> Model Class Initialized
DEBUG - 2011-05-05 02:27:58 --> Model Class Initialized
DEBUG - 2011-05-05 02:27:58 --> Model Class Initialized
DEBUG - 2011-05-05 02:27:58 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-05-05 02:27:58 --> Database Driver Class Initialized
DEBUG - 2011-05-05 02:27:58 --> File loaded: application/views/table/main.php
DEBUG - 2011-05-05 02:27:58 --> Helper loaded: url_helper
DEBUG - 2011-05-05 02:27:58 --> File loaded: application/views/common/header.php
DEBUG - 2011-05-05 02:27:58 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-05-05 02:27:58 --> File loaded: application/views/common/footer.php
DEBUG - 2011-05-05 02:27:58 --> File loaded: application/views/layout/main.php
DEBUG - 2011-05-05 02:27:58 --> Final output sent to browser
DEBUG - 2011-05-05 02:27:58 --> Total execution time: 0.0706
DEBUG - 2011-05-05 02:28:00 --> Config Class Initialized
DEBUG - 2011-05-05 02:28:00 --> Hooks Class Initialized
DEBUG - 2011-05-05 02:28:00 --> Utf8 Class Initialized
DEBUG - 2011-05-05 02:28:00 --> UTF-8 Support Enabled
DEBUG - 2011-05-05 02:28:00 --> URI Class Initialized
DEBUG - 2011-05-05 02:28:00 --> Router Class Initialized
DEBUG - 2011-05-05 02:28:00 --> Output Class Initialized
DEBUG - 2011-05-05 02:28:00 --> Input Class Initialized
DEBUG - 2011-05-05 02:28:00 --> Global POST and COOKIE data sanitized
DEBUG - 2011-05-05 02:28:00 --> Language Class Initialized
DEBUG - 2011-05-05 02:28:00 --> Loader Class Initialized
DEBUG - 2011-05-05 02:28:00 --> Controller Class Initialized
DEBUG - 2011-05-05 02:28:00 --> Model Class Initialized
DEBUG - 2011-05-05 02:28:00 --> Model Class Initialized
DEBUG - 2011-05-05 02:28:00 --> Model Class Initialized
DEBUG - 2011-05-05 02:28:00 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-05-05 02:28:00 --> Database Driver Class Initialized
DEBUG - 2011-05-05 02:28:00 --> File loaded: application/views/table/main.php
DEBUG - 2011-05-05 02:28:00 --> Helper loaded: url_helper
DEBUG - 2011-05-05 02:28:00 --> File loaded: application/views/common/header.php
DEBUG - 2011-05-05 02:28:00 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-05-05 02:28:00 --> File loaded: application/views/common/footer.php
DEBUG - 2011-05-05 02:28:00 --> File loaded: application/views/layout/main.php
DEBUG - 2011-05-05 02:28:00 --> Final output sent to browser
DEBUG - 2011-05-05 02:28:00 --> Total execution time: 0.0544
DEBUG - 2011-05-05 02:31:01 --> Config Class Initialized
DEBUG - 2011-05-05 02:31:01 --> Hooks Class Initialized
DEBUG - 2011-05-05 02:31:01 --> Utf8 Class Initialized
DEBUG - 2011-05-05 02:31:01 --> UTF-8 Support Enabled
DEBUG - 2011-05-05 02:31:01 --> URI Class Initialized
DEBUG - 2011-05-05 02:31:01 --> Router Class Initialized
DEBUG - 2011-05-05 02:31:02 --> Output Class Initialized
DEBUG - 2011-05-05 02:31:02 --> Input Class Initialized
DEBUG - 2011-05-05 02:31:02 --> Global POST and COOKIE data sanitized
DEBUG - 2011-05-05 02:31:02 --> Language Class Initialized
DEBUG - 2011-05-05 02:31:02 --> Loader Class Initialized
DEBUG - 2011-05-05 02:31:02 --> Controller Class Initialized
ERROR - 2011-05-05 02:31:02 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-05-05 02:31:02 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-05-05 02:31:02 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-05-05 02:31:02 --> Model Class Initialized
DEBUG - 2011-05-05 02:31:02 --> Model Class Initialized
DEBUG - 2011-05-05 02:31:02 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-05-05 02:31:02 --> Database Driver Class Initialized
DEBUG - 2011-05-05 02:31:02 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-05-05 02:31:02 --> Helper loaded: url_helper
DEBUG - 2011-05-05 02:31:02 --> File loaded: application/views/common/header.php
DEBUG - 2011-05-05 02:31:02 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-05-05 02:31:02 --> File loaded: application/views/common/footer.php
DEBUG - 2011-05-05 02:31:02 --> File loaded: application/views/layout/main.php
DEBUG - 2011-05-05 02:31:02 --> Final output sent to browser
DEBUG - 2011-05-05 02:31:02 --> Total execution time: 0.5260
DEBUG - 2011-05-05 02:31:05 --> Config Class Initialized
DEBUG - 2011-05-05 02:31:05 --> Hooks Class Initialized
DEBUG - 2011-05-05 02:31:05 --> Utf8 Class Initialized
DEBUG - 2011-05-05 02:31:05 --> UTF-8 Support Enabled
DEBUG - 2011-05-05 02:31:05 --> URI Class Initialized
DEBUG - 2011-05-05 02:31:05 --> Router Class Initialized
DEBUG - 2011-05-05 02:31:05 --> Output Class Initialized
DEBUG - 2011-05-05 02:31:05 --> Input Class Initialized
DEBUG - 2011-05-05 02:31:05 --> Global POST and COOKIE data sanitized
DEBUG - 2011-05-05 02:31:05 --> Language Class Initialized
DEBUG - 2011-05-05 02:31:05 --> Loader Class Initialized
DEBUG - 2011-05-05 02:31:05 --> Controller Class Initialized
DEBUG - 2011-05-05 02:31:05 --> Model Class Initialized
DEBUG - 2011-05-05 02:31:05 --> Model Class Initialized
DEBUG - 2011-05-05 02:31:05 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-05-05 02:31:05 --> Database Driver Class Initialized
DEBUG - 2011-05-05 02:31:23 --> Final output sent to browser
DEBUG - 2011-05-05 02:31:23 --> Total execution time: 17.7863
DEBUG - 2011-05-05 02:31:27 --> Config Class Initialized
DEBUG - 2011-05-05 02:31:27 --> Hooks Class Initialized
DEBUG - 2011-05-05 02:31:27 --> Utf8 Class Initialized
DEBUG - 2011-05-05 02:31:27 --> UTF-8 Support Enabled
DEBUG - 2011-05-05 02:31:27 --> URI Class Initialized
DEBUG - 2011-05-05 02:31:27 --> Router Class Initialized
ERROR - 2011-05-05 02:31:27 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-05-05 02:48:03 --> Config Class Initialized
DEBUG - 2011-05-05 02:48:03 --> Hooks Class Initialized
DEBUG - 2011-05-05 02:48:03 --> Utf8 Class Initialized
DEBUG - 2011-05-05 02:48:03 --> UTF-8 Support Enabled
DEBUG - 2011-05-05 02:48:03 --> URI Class Initialized
DEBUG - 2011-05-05 02:48:03 --> Router Class Initialized
DEBUG - 2011-05-05 02:48:03 --> Output Class Initialized
DEBUG - 2011-05-05 02:48:03 --> Input Class Initialized
DEBUG - 2011-05-05 02:48:03 --> Global POST and COOKIE data sanitized
DEBUG - 2011-05-05 02:48:03 --> Language Class Initialized
DEBUG - 2011-05-05 02:48:03 --> Loader Class Initialized
DEBUG - 2011-05-05 02:48:03 --> Controller Class Initialized
DEBUG - 2011-05-05 02:48:03 --> Model Class Initialized
DEBUG - 2011-05-05 02:48:03 --> Model Class Initialized
DEBUG - 2011-05-05 02:48:03 --> Model Class Initialized
DEBUG - 2011-05-05 02:48:03 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-05-05 02:48:03 --> Database Driver Class Initialized
DEBUG - 2011-05-05 02:48:04 --> File loaded: application/views/table/main.php
DEBUG - 2011-05-05 02:48:04 --> Helper loaded: url_helper
DEBUG - 2011-05-05 02:48:04 --> File loaded: application/views/common/header.php
DEBUG - 2011-05-05 02:48:04 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-05-05 02:48:04 --> File loaded: application/views/common/footer.php
DEBUG - 2011-05-05 02:48:04 --> File loaded: application/views/layout/main.php
DEBUG - 2011-05-05 02:48:04 --> Final output sent to browser
DEBUG - 2011-05-05 02:48:04 --> Total execution time: 0.9854
DEBUG - 2011-05-05 03:08:09 --> Config Class Initialized
DEBUG - 2011-05-05 03:08:09 --> Hooks Class Initialized
DEBUG - 2011-05-05 03:08:09 --> Utf8 Class Initialized
DEBUG - 2011-05-05 03:08:09 --> UTF-8 Support Enabled
DEBUG - 2011-05-05 03:08:09 --> URI Class Initialized
DEBUG - 2011-05-05 03:08:09 --> Router Class Initialized
DEBUG - 2011-05-05 03:08:09 --> No URI present. Default controller set.
DEBUG - 2011-05-05 03:08:09 --> Output Class Initialized
DEBUG - 2011-05-05 03:08:09 --> Input Class Initialized
DEBUG - 2011-05-05 03:08:09 --> Global POST and COOKIE data sanitized
DEBUG - 2011-05-05 03:08:09 --> Language Class Initialized
DEBUG - 2011-05-05 03:08:09 --> Loader Class Initialized
DEBUG - 2011-05-05 03:08:09 --> Controller Class Initialized
DEBUG - 2011-05-05 03:08:09 --> File loaded: application/views/splash/main.php
DEBUG - 2011-05-05 03:08:09 --> Helper loaded: url_helper
DEBUG - 2011-05-05 03:08:09 --> File loaded: application/views/common/header.php
DEBUG - 2011-05-05 03:08:09 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-05-05 03:08:09 --> File loaded: application/views/common/footer.php
DEBUG - 2011-05-05 03:08:09 --> File loaded: application/views/layout/main.php
DEBUG - 2011-05-05 03:08:09 --> Final output sent to browser
DEBUG - 2011-05-05 03:08:09 --> Total execution time: 0.1821
DEBUG - 2011-05-05 03:08:23 --> Config Class Initialized
DEBUG - 2011-05-05 03:08:23 --> Hooks Class Initialized
DEBUG - 2011-05-05 03:08:23 --> Utf8 Class Initialized
DEBUG - 2011-05-05 03:08:23 --> UTF-8 Support Enabled
DEBUG - 2011-05-05 03:08:23 --> URI Class Initialized
DEBUG - 2011-05-05 03:08:23 --> Router Class Initialized
ERROR - 2011-05-05 03:08:23 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-05-05 03:08:47 --> Config Class Initialized
DEBUG - 2011-05-05 03:08:47 --> Hooks Class Initialized
DEBUG - 2011-05-05 03:08:47 --> Utf8 Class Initialized
DEBUG - 2011-05-05 03:08:47 --> UTF-8 Support Enabled
DEBUG - 2011-05-05 03:08:47 --> URI Class Initialized
DEBUG - 2011-05-05 03:08:47 --> Router Class Initialized
DEBUG - 2011-05-05 03:08:47 --> Output Class Initialized
DEBUG - 2011-05-05 03:08:47 --> Input Class Initialized
DEBUG - 2011-05-05 03:08:47 --> Global POST and COOKIE data sanitized
DEBUG - 2011-05-05 03:08:47 --> Language Class Initialized
DEBUG - 2011-05-05 03:08:47 --> Loader Class Initialized
DEBUG - 2011-05-05 03:08:47 --> Controller Class Initialized
DEBUG - 2011-05-05 03:08:47 --> Model Class Initialized
DEBUG - 2011-05-05 03:08:47 --> Model Class Initialized
DEBUG - 2011-05-05 03:08:47 --> Model Class Initialized
DEBUG - 2011-05-05 03:08:47 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-05-05 03:08:47 --> Database Driver Class Initialized
DEBUG - 2011-05-05 03:08:47 --> File loaded: application/views/table/main.php
DEBUG - 2011-05-05 03:08:47 --> Helper loaded: url_helper
DEBUG - 2011-05-05 03:08:47 --> File loaded: application/views/common/header.php
DEBUG - 2011-05-05 03:08:47 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-05-05 03:08:47 --> File loaded: application/views/common/footer.php
DEBUG - 2011-05-05 03:08:47 --> File loaded: application/views/layout/main.php
DEBUG - 2011-05-05 03:08:47 --> Final output sent to browser
DEBUG - 2011-05-05 03:08:47 --> Total execution time: 0.2321
DEBUG - 2011-05-05 03:09:01 --> Config Class Initialized
DEBUG - 2011-05-05 03:09:01 --> Hooks Class Initialized
DEBUG - 2011-05-05 03:09:01 --> Utf8 Class Initialized
DEBUG - 2011-05-05 03:09:01 --> UTF-8 Support Enabled
DEBUG - 2011-05-05 03:09:01 --> URI Class Initialized
DEBUG - 2011-05-05 03:09:01 --> Router Class Initialized
DEBUG - 2011-05-05 03:09:01 --> Output Class Initialized
DEBUG - 2011-05-05 03:09:01 --> Input Class Initialized
DEBUG - 2011-05-05 03:09:01 --> Global POST and COOKIE data sanitized
DEBUG - 2011-05-05 03:09:01 --> Language Class Initialized
DEBUG - 2011-05-05 03:09:01 --> Loader Class Initialized
DEBUG - 2011-05-05 03:09:01 --> Controller Class Initialized
DEBUG - 2011-05-05 03:09:01 --> Model Class Initialized
DEBUG - 2011-05-05 03:09:01 --> Model Class Initialized
DEBUG - 2011-05-05 03:09:01 --> Model Class Initialized
DEBUG - 2011-05-05 03:09:01 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-05-05 03:09:01 --> Database Driver Class Initialized
DEBUG - 2011-05-05 03:09:03 --> File loaded: application/views/table/main.php
DEBUG - 2011-05-05 03:09:03 --> Helper loaded: url_helper
DEBUG - 2011-05-05 03:09:03 --> File loaded: application/views/common/header.php
DEBUG - 2011-05-05 03:09:03 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-05-05 03:09:03 --> File loaded: application/views/common/footer.php
DEBUG - 2011-05-05 03:09:03 --> File loaded: application/views/layout/main.php
DEBUG - 2011-05-05 03:09:03 --> Final output sent to browser
DEBUG - 2011-05-05 03:09:03 --> Total execution time: 2.7315
DEBUG - 2011-05-05 03:09:16 --> Config Class Initialized
DEBUG - 2011-05-05 03:09:16 --> Hooks Class Initialized
DEBUG - 2011-05-05 03:09:16 --> Utf8 Class Initialized
DEBUG - 2011-05-05 03:09:16 --> UTF-8 Support Enabled
DEBUG - 2011-05-05 03:09:16 --> URI Class Initialized
DEBUG - 2011-05-05 03:09:16 --> Router Class Initialized
DEBUG - 2011-05-05 03:09:16 --> Output Class Initialized
DEBUG - 2011-05-05 03:09:16 --> Input Class Initialized
DEBUG - 2011-05-05 03:09:16 --> Global POST and COOKIE data sanitized
DEBUG - 2011-05-05 03:09:16 --> Language Class Initialized
DEBUG - 2011-05-05 03:09:16 --> Loader Class Initialized
DEBUG - 2011-05-05 03:09:16 --> Controller Class Initialized
DEBUG - 2011-05-05 03:09:16 --> Model Class Initialized
DEBUG - 2011-05-05 03:09:16 --> Model Class Initialized
DEBUG - 2011-05-05 03:09:16 --> Model Class Initialized
DEBUG - 2011-05-05 03:09:16 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-05-05 03:09:16 --> Database Driver Class Initialized
DEBUG - 2011-05-05 03:09:16 --> File loaded: application/views/table/main.php
DEBUG - 2011-05-05 03:09:16 --> Helper loaded: url_helper
DEBUG - 2011-05-05 03:09:16 --> File loaded: application/views/common/header.php
DEBUG - 2011-05-05 03:09:16 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-05-05 03:09:16 --> File loaded: application/views/common/footer.php
DEBUG - 2011-05-05 03:09:16 --> File loaded: application/views/layout/main.php
DEBUG - 2011-05-05 03:09:16 --> Final output sent to browser
DEBUG - 2011-05-05 03:09:16 --> Total execution time: 0.0705
DEBUG - 2011-05-05 03:09:22 --> Config Class Initialized
DEBUG - 2011-05-05 03:09:22 --> Hooks Class Initialized
DEBUG - 2011-05-05 03:09:22 --> Utf8 Class Initialized
DEBUG - 2011-05-05 03:09:22 --> UTF-8 Support Enabled
DEBUG - 2011-05-05 03:09:22 --> URI Class Initialized
DEBUG - 2011-05-05 03:09:22 --> Router Class Initialized
DEBUG - 2011-05-05 03:09:22 --> Output Class Initialized
DEBUG - 2011-05-05 03:09:22 --> Input Class Initialized
DEBUG - 2011-05-05 03:09:22 --> Global POST and COOKIE data sanitized
DEBUG - 2011-05-05 03:09:22 --> Language Class Initialized
DEBUG - 2011-05-05 03:09:22 --> Loader Class Initialized
DEBUG - 2011-05-05 03:09:22 --> Controller Class Initialized
DEBUG - 2011-05-05 03:09:22 --> Model Class Initialized
DEBUG - 2011-05-05 03:09:22 --> Model Class Initialized
DEBUG - 2011-05-05 03:09:22 --> Model Class Initialized
DEBUG - 2011-05-05 03:09:22 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-05-05 03:09:22 --> Database Driver Class Initialized
DEBUG - 2011-05-05 03:09:24 --> File loaded: application/views/table/main.php
DEBUG - 2011-05-05 03:09:24 --> Helper loaded: url_helper
DEBUG - 2011-05-05 03:09:24 --> File loaded: application/views/common/header.php
DEBUG - 2011-05-05 03:09:24 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-05-05 03:09:24 --> File loaded: application/views/common/footer.php
DEBUG - 2011-05-05 03:09:24 --> File loaded: application/views/layout/main.php
DEBUG - 2011-05-05 03:09:24 --> Final output sent to browser
DEBUG - 2011-05-05 03:09:24 --> Total execution time: 2.1644
DEBUG - 2011-05-05 03:09:26 --> Config Class Initialized
DEBUG - 2011-05-05 03:09:26 --> Hooks Class Initialized
DEBUG - 2011-05-05 03:09:26 --> Utf8 Class Initialized
DEBUG - 2011-05-05 03:09:26 --> UTF-8 Support Enabled
DEBUG - 2011-05-05 03:09:26 --> URI Class Initialized
DEBUG - 2011-05-05 03:09:26 --> Router Class Initialized
DEBUG - 2011-05-05 03:09:26 --> Output Class Initialized
DEBUG - 2011-05-05 03:09:26 --> Input Class Initialized
DEBUG - 2011-05-05 03:09:26 --> Global POST and COOKIE data sanitized
DEBUG - 2011-05-05 03:09:26 --> Language Class Initialized
DEBUG - 2011-05-05 03:09:26 --> Loader Class Initialized
DEBUG - 2011-05-05 03:09:26 --> Controller Class Initialized
DEBUG - 2011-05-05 03:09:26 --> Model Class Initialized
DEBUG - 2011-05-05 03:09:26 --> Model Class Initialized
DEBUG - 2011-05-05 03:09:26 --> Model Class Initialized
DEBUG - 2011-05-05 03:09:26 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-05-05 03:09:26 --> Database Driver Class Initialized
DEBUG - 2011-05-05 03:09:26 --> File loaded: application/views/table/main.php
DEBUG - 2011-05-05 03:09:26 --> Helper loaded: url_helper
DEBUG - 2011-05-05 03:09:26 --> File loaded: application/views/common/header.php
DEBUG - 2011-05-05 03:09:26 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-05-05 03:09:26 --> File loaded: application/views/common/footer.php
DEBUG - 2011-05-05 03:09:26 --> File loaded: application/views/layout/main.php
DEBUG - 2011-05-05 03:09:26 --> Final output sent to browser
DEBUG - 2011-05-05 03:09:26 --> Total execution time: 0.0464
DEBUG - 2011-05-05 03:09:45 --> Config Class Initialized
DEBUG - 2011-05-05 03:09:45 --> Hooks Class Initialized
DEBUG - 2011-05-05 03:09:45 --> Utf8 Class Initialized
DEBUG - 2011-05-05 03:09:45 --> UTF-8 Support Enabled
DEBUG - 2011-05-05 03:09:45 --> URI Class Initialized
DEBUG - 2011-05-05 03:09:45 --> Router Class Initialized
DEBUG - 2011-05-05 03:09:45 --> Output Class Initialized
DEBUG - 2011-05-05 03:09:45 --> Input Class Initialized
DEBUG - 2011-05-05 03:09:45 --> Global POST and COOKIE data sanitized
DEBUG - 2011-05-05 03:09:45 --> Language Class Initialized
DEBUG - 2011-05-05 03:09:45 --> Loader Class Initialized
DEBUG - 2011-05-05 03:09:45 --> Controller Class Initialized
DEBUG - 2011-05-05 03:09:45 --> Model Class Initialized
DEBUG - 2011-05-05 03:09:45 --> Model Class Initialized
DEBUG - 2011-05-05 03:09:45 --> Model Class Initialized
DEBUG - 2011-05-05 03:09:45 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-05-05 03:09:45 --> Database Driver Class Initialized
DEBUG - 2011-05-05 03:09:46 --> File loaded: application/views/table/main.php
DEBUG - 2011-05-05 03:09:46 --> Helper loaded: url_helper
DEBUG - 2011-05-05 03:09:46 --> File loaded: application/views/common/header.php
DEBUG - 2011-05-05 03:09:46 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-05-05 03:09:46 --> File loaded: application/views/common/footer.php
DEBUG - 2011-05-05 03:09:46 --> File loaded: application/views/layout/main.php
DEBUG - 2011-05-05 03:09:46 --> Final output sent to browser
DEBUG - 2011-05-05 03:09:46 --> Total execution time: 1.0745
DEBUG - 2011-05-05 03:09:50 --> Config Class Initialized
DEBUG - 2011-05-05 03:09:50 --> Hooks Class Initialized
DEBUG - 2011-05-05 03:09:50 --> Utf8 Class Initialized
DEBUG - 2011-05-05 03:09:50 --> UTF-8 Support Enabled
DEBUG - 2011-05-05 03:09:50 --> URI Class Initialized
DEBUG - 2011-05-05 03:09:50 --> Router Class Initialized
DEBUG - 2011-05-05 03:09:50 --> Output Class Initialized
DEBUG - 2011-05-05 03:09:50 --> Input Class Initialized
DEBUG - 2011-05-05 03:09:50 --> Global POST and COOKIE data sanitized
DEBUG - 2011-05-05 03:09:50 --> Language Class Initialized
DEBUG - 2011-05-05 03:09:50 --> Loader Class Initialized
DEBUG - 2011-05-05 03:09:50 --> Controller Class Initialized
DEBUG - 2011-05-05 03:09:50 --> Model Class Initialized
DEBUG - 2011-05-05 03:09:50 --> Model Class Initialized
DEBUG - 2011-05-05 03:09:50 --> Model Class Initialized
DEBUG - 2011-05-05 03:09:50 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-05-05 03:09:50 --> Database Driver Class Initialized
DEBUG - 2011-05-05 03:09:50 --> File loaded: application/views/table/main.php
DEBUG - 2011-05-05 03:09:50 --> Helper loaded: url_helper
DEBUG - 2011-05-05 03:09:50 --> File loaded: application/views/common/header.php
DEBUG - 2011-05-05 03:09:50 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-05-05 03:09:50 --> File loaded: application/views/common/footer.php
DEBUG - 2011-05-05 03:09:50 --> File loaded: application/views/layout/main.php
DEBUG - 2011-05-05 03:09:50 --> Final output sent to browser
DEBUG - 2011-05-05 03:09:50 --> Total execution time: 0.0490
DEBUG - 2011-05-05 03:09:59 --> Config Class Initialized
DEBUG - 2011-05-05 03:09:59 --> Hooks Class Initialized
DEBUG - 2011-05-05 03:09:59 --> Utf8 Class Initialized
DEBUG - 2011-05-05 03:09:59 --> UTF-8 Support Enabled
DEBUG - 2011-05-05 03:09:59 --> URI Class Initialized
DEBUG - 2011-05-05 03:09:59 --> Router Class Initialized
DEBUG - 2011-05-05 03:09:59 --> Output Class Initialized
DEBUG - 2011-05-05 03:09:59 --> Input Class Initialized
DEBUG - 2011-05-05 03:09:59 --> Global POST and COOKIE data sanitized
DEBUG - 2011-05-05 03:09:59 --> Language Class Initialized
DEBUG - 2011-05-05 03:09:59 --> Loader Class Initialized
DEBUG - 2011-05-05 03:09:59 --> Controller Class Initialized
DEBUG - 2011-05-05 03:09:59 --> Model Class Initialized
DEBUG - 2011-05-05 03:09:59 --> Model Class Initialized
DEBUG - 2011-05-05 03:09:59 --> Model Class Initialized
DEBUG - 2011-05-05 03:09:59 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-05-05 03:09:59 --> Database Driver Class Initialized
DEBUG - 2011-05-05 03:09:59 --> File loaded: application/views/table/main.php
DEBUG - 2011-05-05 03:09:59 --> Helper loaded: url_helper
DEBUG - 2011-05-05 03:09:59 --> File loaded: application/views/common/header.php
DEBUG - 2011-05-05 03:09:59 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-05-05 03:09:59 --> File loaded: application/views/common/footer.php
DEBUG - 2011-05-05 03:09:59 --> File loaded: application/views/layout/main.php
DEBUG - 2011-05-05 03:09:59 --> Final output sent to browser
DEBUG - 2011-05-05 03:09:59 --> Total execution time: 0.0545
DEBUG - 2011-05-05 03:10:16 --> Config Class Initialized
DEBUG - 2011-05-05 03:10:16 --> Hooks Class Initialized
DEBUG - 2011-05-05 03:10:16 --> Utf8 Class Initialized
DEBUG - 2011-05-05 03:10:16 --> UTF-8 Support Enabled
DEBUG - 2011-05-05 03:10:16 --> URI Class Initialized
DEBUG - 2011-05-05 03:10:16 --> Router Class Initialized
DEBUG - 2011-05-05 03:10:16 --> Output Class Initialized
DEBUG - 2011-05-05 03:10:16 --> Input Class Initialized
DEBUG - 2011-05-05 03:10:16 --> Global POST and COOKIE data sanitized
DEBUG - 2011-05-05 03:10:16 --> Language Class Initialized
DEBUG - 2011-05-05 03:10:16 --> Loader Class Initialized
DEBUG - 2011-05-05 03:10:16 --> Controller Class Initialized
DEBUG - 2011-05-05 03:10:16 --> Model Class Initialized
DEBUG - 2011-05-05 03:10:16 --> Model Class Initialized
DEBUG - 2011-05-05 03:10:16 --> Model Class Initialized
DEBUG - 2011-05-05 03:10:16 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-05-05 03:10:16 --> Database Driver Class Initialized
DEBUG - 2011-05-05 03:10:33 --> File loaded: application/views/table/main.php
DEBUG - 2011-05-05 03:10:33 --> Helper loaded: url_helper
DEBUG - 2011-05-05 03:10:33 --> File loaded: application/views/common/header.php
DEBUG - 2011-05-05 03:10:33 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-05-05 03:10:33 --> File loaded: application/views/common/footer.php
DEBUG - 2011-05-05 03:10:33 --> File loaded: application/views/layout/main.php
DEBUG - 2011-05-05 03:10:33 --> Final output sent to browser
DEBUG - 2011-05-05 03:10:33 --> Total execution time: 16.6541
DEBUG - 2011-05-05 03:10:34 --> Config Class Initialized
DEBUG - 2011-05-05 03:10:34 --> Hooks Class Initialized
DEBUG - 2011-05-05 03:10:34 --> Utf8 Class Initialized
DEBUG - 2011-05-05 03:10:34 --> UTF-8 Support Enabled
DEBUG - 2011-05-05 03:10:34 --> URI Class Initialized
DEBUG - 2011-05-05 03:10:34 --> Router Class Initialized
DEBUG - 2011-05-05 03:10:34 --> Output Class Initialized
DEBUG - 2011-05-05 03:10:34 --> Input Class Initialized
DEBUG - 2011-05-05 03:10:34 --> Global POST and COOKIE data sanitized
DEBUG - 2011-05-05 03:10:34 --> Language Class Initialized
DEBUG - 2011-05-05 03:10:34 --> Loader Class Initialized
DEBUG - 2011-05-05 03:10:34 --> Controller Class Initialized
DEBUG - 2011-05-05 03:10:34 --> Model Class Initialized
DEBUG - 2011-05-05 03:10:34 --> Model Class Initialized
DEBUG - 2011-05-05 03:10:34 --> Model Class Initialized
DEBUG - 2011-05-05 03:10:34 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-05-05 03:10:34 --> Database Driver Class Initialized
DEBUG - 2011-05-05 03:10:35 --> File loaded: application/views/table/main.php
DEBUG - 2011-05-05 03:10:35 --> Helper loaded: url_helper
DEBUG - 2011-05-05 03:10:35 --> File loaded: application/views/common/header.php
DEBUG - 2011-05-05 03:10:35 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-05-05 03:10:35 --> File loaded: application/views/common/footer.php
DEBUG - 2011-05-05 03:10:35 --> File loaded: application/views/layout/main.php
DEBUG - 2011-05-05 03:10:35 --> Final output sent to browser
DEBUG - 2011-05-05 03:10:35 --> Total execution time: 0.0766
DEBUG - 2011-05-05 03:10:44 --> Config Class Initialized
DEBUG - 2011-05-05 03:10:44 --> Hooks Class Initialized
DEBUG - 2011-05-05 03:10:44 --> Utf8 Class Initialized
DEBUG - 2011-05-05 03:10:44 --> UTF-8 Support Enabled
DEBUG - 2011-05-05 03:10:44 --> URI Class Initialized
DEBUG - 2011-05-05 03:10:44 --> Router Class Initialized
DEBUG - 2011-05-05 03:10:44 --> Output Class Initialized
DEBUG - 2011-05-05 03:10:44 --> Input Class Initialized
DEBUG - 2011-05-05 03:10:44 --> Global POST and COOKIE data sanitized
DEBUG - 2011-05-05 03:10:44 --> Language Class Initialized
DEBUG - 2011-05-05 03:10:44 --> Loader Class Initialized
DEBUG - 2011-05-05 03:10:44 --> Controller Class Initialized
DEBUG - 2011-05-05 03:10:44 --> Model Class Initialized
DEBUG - 2011-05-05 03:10:44 --> Model Class Initialized
DEBUG - 2011-05-05 03:10:44 --> Model Class Initialized
DEBUG - 2011-05-05 03:10:44 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-05-05 03:10:44 --> Database Driver Class Initialized
DEBUG - 2011-05-05 03:10:45 --> File loaded: application/views/table/main.php
DEBUG - 2011-05-05 03:10:45 --> Helper loaded: url_helper
DEBUG - 2011-05-05 03:10:45 --> File loaded: application/views/common/header.php
DEBUG - 2011-05-05 03:10:45 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-05-05 03:10:45 --> File loaded: application/views/common/footer.php
DEBUG - 2011-05-05 03:10:45 --> File loaded: application/views/layout/main.php
DEBUG - 2011-05-05 03:10:45 --> Final output sent to browser
DEBUG - 2011-05-05 03:10:45 --> Total execution time: 1.4454
DEBUG - 2011-05-05 03:10:47 --> Config Class Initialized
DEBUG - 2011-05-05 03:10:47 --> Hooks Class Initialized
DEBUG - 2011-05-05 03:10:47 --> Utf8 Class Initialized
DEBUG - 2011-05-05 03:10:47 --> UTF-8 Support Enabled
DEBUG - 2011-05-05 03:10:47 --> URI Class Initialized
DEBUG - 2011-05-05 03:10:47 --> Router Class Initialized
DEBUG - 2011-05-05 03:10:47 --> Output Class Initialized
DEBUG - 2011-05-05 03:10:47 --> Input Class Initialized
DEBUG - 2011-05-05 03:10:47 --> Global POST and COOKIE data sanitized
DEBUG - 2011-05-05 03:10:47 --> Language Class Initialized
DEBUG - 2011-05-05 03:10:47 --> Loader Class Initialized
DEBUG - 2011-05-05 03:10:47 --> Controller Class Initialized
DEBUG - 2011-05-05 03:10:47 --> Model Class Initialized
DEBUG - 2011-05-05 03:10:47 --> Model Class Initialized
DEBUG - 2011-05-05 03:10:47 --> Model Class Initialized
DEBUG - 2011-05-05 03:10:47 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-05-05 03:10:47 --> Database Driver Class Initialized
DEBUG - 2011-05-05 03:10:47 --> File loaded: application/views/table/main.php
DEBUG - 2011-05-05 03:10:47 --> Helper loaded: url_helper
DEBUG - 2011-05-05 03:10:47 --> File loaded: application/views/common/header.php
DEBUG - 2011-05-05 03:10:47 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-05-05 03:10:47 --> File loaded: application/views/common/footer.php
DEBUG - 2011-05-05 03:10:47 --> File loaded: application/views/layout/main.php
DEBUG - 2011-05-05 03:10:47 --> Final output sent to browser
DEBUG - 2011-05-05 03:10:47 --> Total execution time: 0.2534
DEBUG - 2011-05-05 03:10:49 --> Config Class Initialized
DEBUG - 2011-05-05 03:10:49 --> Hooks Class Initialized
DEBUG - 2011-05-05 03:10:49 --> Utf8 Class Initialized
DEBUG - 2011-05-05 03:10:49 --> UTF-8 Support Enabled
DEBUG - 2011-05-05 03:10:49 --> URI Class Initialized
DEBUG - 2011-05-05 03:10:49 --> Router Class Initialized
DEBUG - 2011-05-05 03:10:49 --> Output Class Initialized
DEBUG - 2011-05-05 03:10:49 --> Input Class Initialized
DEBUG - 2011-05-05 03:10:49 --> Global POST and COOKIE data sanitized
DEBUG - 2011-05-05 03:10:49 --> Language Class Initialized
DEBUG - 2011-05-05 03:10:49 --> Loader Class Initialized
DEBUG - 2011-05-05 03:10:49 --> Controller Class Initialized
DEBUG - 2011-05-05 03:10:49 --> Model Class Initialized
DEBUG - 2011-05-05 03:10:49 --> Model Class Initialized
DEBUG - 2011-05-05 03:10:49 --> Model Class Initialized
DEBUG - 2011-05-05 03:10:49 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-05-05 03:10:49 --> Database Driver Class Initialized
DEBUG - 2011-05-05 03:10:49 --> File loaded: application/views/table/main.php
DEBUG - 2011-05-05 03:10:49 --> Helper loaded: url_helper
DEBUG - 2011-05-05 03:10:49 --> File loaded: application/views/common/header.php
DEBUG - 2011-05-05 03:10:49 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-05-05 03:10:49 --> File loaded: application/views/common/footer.php
DEBUG - 2011-05-05 03:10:49 --> File loaded: application/views/layout/main.php
DEBUG - 2011-05-05 03:10:49 --> Final output sent to browser
DEBUG - 2011-05-05 03:10:49 --> Total execution time: 0.3755
DEBUG - 2011-05-05 04:19:42 --> Config Class Initialized
DEBUG - 2011-05-05 04:19:42 --> Hooks Class Initialized
DEBUG - 2011-05-05 04:19:42 --> Utf8 Class Initialized
DEBUG - 2011-05-05 04:19:42 --> UTF-8 Support Enabled
DEBUG - 2011-05-05 04:19:42 --> URI Class Initialized
DEBUG - 2011-05-05 04:19:42 --> Router Class Initialized
DEBUG - 2011-05-05 04:19:42 --> Output Class Initialized
DEBUG - 2011-05-05 04:19:42 --> Input Class Initialized
DEBUG - 2011-05-05 04:19:42 --> Global POST and COOKIE data sanitized
DEBUG - 2011-05-05 04:19:42 --> Language Class Initialized
DEBUG - 2011-05-05 04:19:42 --> Loader Class Initialized
DEBUG - 2011-05-05 04:19:42 --> Controller Class Initialized
ERROR - 2011-05-05 04:19:42 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-05-05 04:19:42 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-05-05 04:19:42 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-05-05 04:19:42 --> Model Class Initialized
DEBUG - 2011-05-05 04:19:42 --> Model Class Initialized
DEBUG - 2011-05-05 04:19:42 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-05-05 04:19:42 --> Database Driver Class Initialized
DEBUG - 2011-05-05 04:19:43 --> Config Class Initialized
DEBUG - 2011-05-05 04:19:43 --> Hooks Class Initialized
DEBUG - 2011-05-05 04:19:43 --> Utf8 Class Initialized
DEBUG - 2011-05-05 04:19:43 --> UTF-8 Support Enabled
DEBUG - 2011-05-05 04:19:43 --> URI Class Initialized
DEBUG - 2011-05-05 04:19:43 --> Router Class Initialized
DEBUG - 2011-05-05 04:19:43 --> Output Class Initialized
DEBUG - 2011-05-05 04:19:43 --> Input Class Initialized
DEBUG - 2011-05-05 04:19:43 --> Global POST and COOKIE data sanitized
DEBUG - 2011-05-05 04:19:43 --> Language Class Initialized
DEBUG - 2011-05-05 04:19:43 --> Loader Class Initialized
DEBUG - 2011-05-05 04:19:43 --> Controller Class Initialized
DEBUG - 2011-05-05 04:19:43 --> Model Class Initialized
DEBUG - 2011-05-05 04:19:43 --> Model Class Initialized
DEBUG - 2011-05-05 04:19:43 --> Model Class Initialized
DEBUG - 2011-05-05 04:19:43 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-05-05 04:19:43 --> Database Driver Class Initialized
DEBUG - 2011-05-05 04:19:46 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-05-05 04:19:46 --> Helper loaded: url_helper
DEBUG - 2011-05-05 04:19:46 --> File loaded: application/views/common/header.php
DEBUG - 2011-05-05 04:19:46 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-05-05 04:19:46 --> File loaded: application/views/common/footer.php
DEBUG - 2011-05-05 04:19:46 --> File loaded: application/views/layout/main.php
DEBUG - 2011-05-05 04:19:46 --> Final output sent to browser
DEBUG - 2011-05-05 04:19:46 --> Total execution time: 4.1208
DEBUG - 2011-05-05 04:19:48 --> File loaded: application/views/table/main.php
DEBUG - 2011-05-05 04:19:48 --> Helper loaded: url_helper
DEBUG - 2011-05-05 04:19:48 --> File loaded: application/views/common/header.php
DEBUG - 2011-05-05 04:19:48 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-05-05 04:19:48 --> File loaded: application/views/common/footer.php
DEBUG - 2011-05-05 04:19:48 --> File loaded: application/views/layout/main.php
DEBUG - 2011-05-05 04:19:48 --> Final output sent to browser
DEBUG - 2011-05-05 04:19:48 --> Total execution time: 4.8890
DEBUG - 2011-05-05 04:19:56 --> Config Class Initialized
DEBUG - 2011-05-05 04:19:56 --> Hooks Class Initialized
DEBUG - 2011-05-05 04:19:56 --> Utf8 Class Initialized
DEBUG - 2011-05-05 04:19:56 --> UTF-8 Support Enabled
DEBUG - 2011-05-05 04:19:56 --> URI Class Initialized
DEBUG - 2011-05-05 04:19:56 --> Router Class Initialized
DEBUG - 2011-05-05 04:19:56 --> Output Class Initialized
DEBUG - 2011-05-05 04:19:56 --> Input Class Initialized
DEBUG - 2011-05-05 04:19:56 --> Global POST and COOKIE data sanitized
DEBUG - 2011-05-05 04:19:56 --> Language Class Initialized
DEBUG - 2011-05-05 04:19:56 --> Loader Class Initialized
DEBUG - 2011-05-05 04:19:56 --> Controller Class Initialized
DEBUG - 2011-05-05 04:19:56 --> Model Class Initialized
DEBUG - 2011-05-05 04:19:56 --> Model Class Initialized
DEBUG - 2011-05-05 04:19:56 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-05-05 04:19:56 --> Database Driver Class Initialized
DEBUG - 2011-05-05 04:20:02 --> Final output sent to browser
DEBUG - 2011-05-05 04:20:02 --> Total execution time: 6.5999
DEBUG - 2011-05-05 04:20:32 --> Config Class Initialized
DEBUG - 2011-05-05 04:20:32 --> Hooks Class Initialized
DEBUG - 2011-05-05 04:20:32 --> Utf8 Class Initialized
DEBUG - 2011-05-05 04:20:32 --> UTF-8 Support Enabled
DEBUG - 2011-05-05 04:20:32 --> URI Class Initialized
DEBUG - 2011-05-05 04:20:32 --> Router Class Initialized
DEBUG - 2011-05-05 04:20:32 --> Output Class Initialized
DEBUG - 2011-05-05 04:20:32 --> Input Class Initialized
DEBUG - 2011-05-05 04:20:32 --> Global POST and COOKIE data sanitized
DEBUG - 2011-05-05 04:20:32 --> Language Class Initialized
DEBUG - 2011-05-05 04:20:32 --> Loader Class Initialized
DEBUG - 2011-05-05 04:20:32 --> Controller Class Initialized
DEBUG - 2011-05-05 04:20:32 --> Model Class Initialized
DEBUG - 2011-05-05 04:20:32 --> Model Class Initialized
DEBUG - 2011-05-05 04:20:32 --> Model Class Initialized
DEBUG - 2011-05-05 04:20:32 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-05-05 04:20:32 --> Database Driver Class Initialized
DEBUG - 2011-05-05 04:20:32 --> File loaded: application/views/table/main.php
DEBUG - 2011-05-05 04:20:32 --> Helper loaded: url_helper
DEBUG - 2011-05-05 04:20:32 --> File loaded: application/views/common/header.php
DEBUG - 2011-05-05 04:20:32 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-05-05 04:20:32 --> File loaded: application/views/common/footer.php
DEBUG - 2011-05-05 04:20:32 --> File loaded: application/views/layout/main.php
DEBUG - 2011-05-05 04:20:32 --> Final output sent to browser
DEBUG - 2011-05-05 04:20:32 --> Total execution time: 0.0582
DEBUG - 2011-05-05 04:20:34 --> Config Class Initialized
DEBUG - 2011-05-05 04:20:34 --> Hooks Class Initialized
DEBUG - 2011-05-05 04:20:34 --> Utf8 Class Initialized
DEBUG - 2011-05-05 04:20:34 --> UTF-8 Support Enabled
DEBUG - 2011-05-05 04:20:34 --> URI Class Initialized
DEBUG - 2011-05-05 04:20:34 --> Router Class Initialized
DEBUG - 2011-05-05 04:20:34 --> Output Class Initialized
DEBUG - 2011-05-05 04:20:34 --> Input Class Initialized
DEBUG - 2011-05-05 04:20:34 --> Global POST and COOKIE data sanitized
DEBUG - 2011-05-05 04:20:34 --> Language Class Initialized
DEBUG - 2011-05-05 04:20:34 --> Loader Class Initialized
DEBUG - 2011-05-05 04:20:34 --> Controller Class Initialized
ERROR - 2011-05-05 04:20:34 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-05-05 04:20:34 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-05-05 04:20:34 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-05-05 04:20:34 --> Model Class Initialized
DEBUG - 2011-05-05 04:20:34 --> Model Class Initialized
DEBUG - 2011-05-05 04:20:34 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-05-05 04:20:34 --> Database Driver Class Initialized
DEBUG - 2011-05-05 04:20:34 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-05-05 04:20:34 --> Helper loaded: url_helper
DEBUG - 2011-05-05 04:20:34 --> File loaded: application/views/common/header.php
DEBUG - 2011-05-05 04:20:34 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-05-05 04:20:34 --> File loaded: application/views/common/footer.php
DEBUG - 2011-05-05 04:20:34 --> File loaded: application/views/layout/main.php
DEBUG - 2011-05-05 04:20:34 --> Final output sent to browser
DEBUG - 2011-05-05 04:20:34 --> Total execution time: 0.0295
DEBUG - 2011-05-05 04:20:37 --> Config Class Initialized
DEBUG - 2011-05-05 04:20:37 --> Hooks Class Initialized
DEBUG - 2011-05-05 04:20:37 --> Utf8 Class Initialized
DEBUG - 2011-05-05 04:20:37 --> UTF-8 Support Enabled
DEBUG - 2011-05-05 04:20:37 --> URI Class Initialized
DEBUG - 2011-05-05 04:20:37 --> Router Class Initialized
DEBUG - 2011-05-05 04:20:37 --> Output Class Initialized
DEBUG - 2011-05-05 04:20:37 --> Input Class Initialized
DEBUG - 2011-05-05 04:20:37 --> Global POST and COOKIE data sanitized
DEBUG - 2011-05-05 04:20:37 --> Language Class Initialized
DEBUG - 2011-05-05 04:20:37 --> Loader Class Initialized
DEBUG - 2011-05-05 04:20:37 --> Controller Class Initialized
DEBUG - 2011-05-05 04:20:37 --> Model Class Initialized
DEBUG - 2011-05-05 04:20:37 --> Model Class Initialized
DEBUG - 2011-05-05 04:20:37 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-05-05 04:20:37 --> Database Driver Class Initialized
DEBUG - 2011-05-05 04:20:40 --> Config Class Initialized
DEBUG - 2011-05-05 04:20:40 --> Hooks Class Initialized
DEBUG - 2011-05-05 04:20:40 --> Utf8 Class Initialized
DEBUG - 2011-05-05 04:20:40 --> UTF-8 Support Enabled
DEBUG - 2011-05-05 04:20:40 --> URI Class Initialized
DEBUG - 2011-05-05 04:20:40 --> Router Class Initialized
ERROR - 2011-05-05 04:20:40 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-05-05 04:20:41 --> Final output sent to browser
DEBUG - 2011-05-05 04:20:41 --> Total execution time: 4.6613
DEBUG - 2011-05-05 04:20:41 --> Config Class Initialized
DEBUG - 2011-05-05 04:20:41 --> Hooks Class Initialized
DEBUG - 2011-05-05 04:20:41 --> Utf8 Class Initialized
DEBUG - 2011-05-05 04:20:41 --> UTF-8 Support Enabled
DEBUG - 2011-05-05 04:20:41 --> URI Class Initialized
DEBUG - 2011-05-05 04:20:41 --> Router Class Initialized
ERROR - 2011-05-05 04:20:41 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-05-05 04:22:02 --> Config Class Initialized
DEBUG - 2011-05-05 04:22:02 --> Hooks Class Initialized
DEBUG - 2011-05-05 04:22:02 --> Utf8 Class Initialized
DEBUG - 2011-05-05 04:22:02 --> UTF-8 Support Enabled
DEBUG - 2011-05-05 04:22:02 --> URI Class Initialized
DEBUG - 2011-05-05 04:22:02 --> Router Class Initialized
DEBUG - 2011-05-05 04:22:02 --> Output Class Initialized
DEBUG - 2011-05-05 04:22:02 --> Input Class Initialized
DEBUG - 2011-05-05 04:22:02 --> Global POST and COOKIE data sanitized
DEBUG - 2011-05-05 04:22:02 --> Language Class Initialized
DEBUG - 2011-05-05 04:22:02 --> Loader Class Initialized
DEBUG - 2011-05-05 04:22:02 --> Controller Class Initialized
ERROR - 2011-05-05 04:22:02 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-05-05 04:22:02 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-05-05 04:22:02 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-05-05 04:22:02 --> Model Class Initialized
DEBUG - 2011-05-05 04:22:02 --> Model Class Initialized
DEBUG - 2011-05-05 04:22:02 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-05-05 04:22:02 --> Database Driver Class Initialized
DEBUG - 2011-05-05 04:22:02 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-05-05 04:22:02 --> Helper loaded: url_helper
DEBUG - 2011-05-05 04:22:02 --> File loaded: application/views/common/header.php
DEBUG - 2011-05-05 04:22:02 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-05-05 04:22:02 --> File loaded: application/views/common/footer.php
DEBUG - 2011-05-05 04:22:02 --> File loaded: application/views/layout/main.php
DEBUG - 2011-05-05 04:22:02 --> Final output sent to browser
DEBUG - 2011-05-05 04:22:02 --> Total execution time: 0.0976
DEBUG - 2011-05-05 04:22:07 --> Config Class Initialized
DEBUG - 2011-05-05 04:22:07 --> Hooks Class Initialized
DEBUG - 2011-05-05 04:22:07 --> Utf8 Class Initialized
DEBUG - 2011-05-05 04:22:07 --> UTF-8 Support Enabled
DEBUG - 2011-05-05 04:22:07 --> URI Class Initialized
DEBUG - 2011-05-05 04:22:07 --> Router Class Initialized
DEBUG - 2011-05-05 04:22:07 --> Output Class Initialized
DEBUG - 2011-05-05 04:22:07 --> Input Class Initialized
DEBUG - 2011-05-05 04:22:07 --> Global POST and COOKIE data sanitized
DEBUG - 2011-05-05 04:22:07 --> Language Class Initialized
DEBUG - 2011-05-05 04:22:07 --> Loader Class Initialized
DEBUG - 2011-05-05 04:22:07 --> Controller Class Initialized
DEBUG - 2011-05-05 04:22:07 --> Model Class Initialized
DEBUG - 2011-05-05 04:22:07 --> Model Class Initialized
DEBUG - 2011-05-05 04:22:07 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-05-05 04:22:07 --> Database Driver Class Initialized
DEBUG - 2011-05-05 04:22:14 --> Final output sent to browser
DEBUG - 2011-05-05 04:22:14 --> Total execution time: 6.8498
DEBUG - 2011-05-05 06:19:30 --> Config Class Initialized
DEBUG - 2011-05-05 06:19:30 --> Hooks Class Initialized
DEBUG - 2011-05-05 06:19:30 --> Utf8 Class Initialized
DEBUG - 2011-05-05 06:19:30 --> UTF-8 Support Enabled
DEBUG - 2011-05-05 06:19:30 --> URI Class Initialized
DEBUG - 2011-05-05 06:19:30 --> Router Class Initialized
DEBUG - 2011-05-05 06:19:30 --> Output Class Initialized
DEBUG - 2011-05-05 06:19:30 --> Input Class Initialized
DEBUG - 2011-05-05 06:19:30 --> Global POST and COOKIE data sanitized
DEBUG - 2011-05-05 06:19:30 --> Language Class Initialized
DEBUG - 2011-05-05 06:19:30 --> Loader Class Initialized
DEBUG - 2011-05-05 06:19:30 --> Controller Class Initialized
DEBUG - 2011-05-05 06:19:30 --> Model Class Initialized
DEBUG - 2011-05-05 06:19:30 --> Model Class Initialized
DEBUG - 2011-05-05 06:19:30 --> Model Class Initialized
DEBUG - 2011-05-05 06:19:30 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-05-05 06:19:31 --> Database Driver Class Initialized
DEBUG - 2011-05-05 06:19:31 --> File loaded: application/views/table/main.php
DEBUG - 2011-05-05 06:19:31 --> Helper loaded: url_helper
DEBUG - 2011-05-05 06:19:31 --> File loaded: application/views/common/header.php
DEBUG - 2011-05-05 06:19:31 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-05-05 06:19:31 --> File loaded: application/views/common/footer.php
DEBUG - 2011-05-05 06:19:31 --> File loaded: application/views/layout/main.php
DEBUG - 2011-05-05 06:19:31 --> Final output sent to browser
DEBUG - 2011-05-05 06:19:31 --> Total execution time: 0.7250
DEBUG - 2011-05-05 06:19:32 --> Config Class Initialized
DEBUG - 2011-05-05 06:19:32 --> Hooks Class Initialized
DEBUG - 2011-05-05 06:19:32 --> Utf8 Class Initialized
DEBUG - 2011-05-05 06:19:32 --> UTF-8 Support Enabled
DEBUG - 2011-05-05 06:19:32 --> URI Class Initialized
DEBUG - 2011-05-05 06:19:32 --> Router Class Initialized
DEBUG - 2011-05-05 06:19:32 --> Output Class Initialized
DEBUG - 2011-05-05 06:19:32 --> Input Class Initialized
DEBUG - 2011-05-05 06:19:32 --> Global POST and COOKIE data sanitized
DEBUG - 2011-05-05 06:19:32 --> Language Class Initialized
DEBUG - 2011-05-05 06:19:32 --> Loader Class Initialized
DEBUG - 2011-05-05 06:19:32 --> Controller Class Initialized
ERROR - 2011-05-05 06:19:32 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-05-05 06:19:32 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-05-05 06:19:32 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-05-05 06:19:32 --> Model Class Initialized
DEBUG - 2011-05-05 06:19:32 --> Model Class Initialized
DEBUG - 2011-05-05 06:19:32 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-05-05 06:19:32 --> Database Driver Class Initialized
DEBUG - 2011-05-05 06:19:32 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-05-05 06:19:32 --> Helper loaded: url_helper
DEBUG - 2011-05-05 06:19:32 --> File loaded: application/views/common/header.php
DEBUG - 2011-05-05 06:19:32 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-05-05 06:19:32 --> File loaded: application/views/common/footer.php
DEBUG - 2011-05-05 06:19:32 --> File loaded: application/views/layout/main.php
DEBUG - 2011-05-05 06:19:32 --> Final output sent to browser
DEBUG - 2011-05-05 06:19:32 --> Total execution time: 0.1028
DEBUG - 2011-05-05 08:52:58 --> Config Class Initialized
DEBUG - 2011-05-05 08:52:58 --> Hooks Class Initialized
DEBUG - 2011-05-05 08:52:58 --> Utf8 Class Initialized
DEBUG - 2011-05-05 08:52:58 --> UTF-8 Support Enabled
DEBUG - 2011-05-05 08:52:58 --> URI Class Initialized
DEBUG - 2011-05-05 08:52:58 --> Router Class Initialized
DEBUG - 2011-05-05 08:52:58 --> Output Class Initialized
DEBUG - 2011-05-05 08:52:58 --> Input Class Initialized
DEBUG - 2011-05-05 08:52:58 --> Global POST and COOKIE data sanitized
DEBUG - 2011-05-05 08:52:58 --> Language Class Initialized
DEBUG - 2011-05-05 08:52:58 --> Loader Class Initialized
DEBUG - 2011-05-05 08:52:58 --> Controller Class Initialized
ERROR - 2011-05-05 08:52:58 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-05-05 08:52:58 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-05-05 08:52:58 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-05-05 08:52:58 --> Model Class Initialized
DEBUG - 2011-05-05 08:52:58 --> Model Class Initialized
DEBUG - 2011-05-05 08:52:58 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-05-05 08:52:58 --> Database Driver Class Initialized
DEBUG - 2011-05-05 08:52:58 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-05-05 08:52:58 --> Helper loaded: url_helper
DEBUG - 2011-05-05 08:52:58 --> File loaded: application/views/common/header.php
DEBUG - 2011-05-05 08:52:58 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-05-05 08:52:58 --> File loaded: application/views/common/footer.php
DEBUG - 2011-05-05 08:52:58 --> File loaded: application/views/layout/main.php
DEBUG - 2011-05-05 08:52:58 --> Final output sent to browser
DEBUG - 2011-05-05 08:52:58 --> Total execution time: 0.4495
DEBUG - 2011-05-05 08:52:59 --> Config Class Initialized
DEBUG - 2011-05-05 08:52:59 --> Hooks Class Initialized
DEBUG - 2011-05-05 08:52:59 --> Utf8 Class Initialized
DEBUG - 2011-05-05 08:52:59 --> UTF-8 Support Enabled
DEBUG - 2011-05-05 08:52:59 --> URI Class Initialized
DEBUG - 2011-05-05 08:52:59 --> Router Class Initialized
DEBUG - 2011-05-05 08:52:59 --> Output Class Initialized
DEBUG - 2011-05-05 08:52:59 --> Input Class Initialized
DEBUG - 2011-05-05 08:52:59 --> Global POST and COOKIE data sanitized
DEBUG - 2011-05-05 08:52:59 --> Language Class Initialized
DEBUG - 2011-05-05 08:52:59 --> Loader Class Initialized
DEBUG - 2011-05-05 08:52:59 --> Controller Class Initialized
DEBUG - 2011-05-05 08:52:59 --> Model Class Initialized
DEBUG - 2011-05-05 08:52:59 --> Model Class Initialized
DEBUG - 2011-05-05 08:52:59 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-05-05 08:52:59 --> Database Driver Class Initialized
DEBUG - 2011-05-05 08:53:00 --> Final output sent to browser
DEBUG - 2011-05-05 08:53:00 --> Total execution time: 0.7819
DEBUG - 2011-05-05 08:53:01 --> Config Class Initialized
DEBUG - 2011-05-05 08:53:01 --> Hooks Class Initialized
DEBUG - 2011-05-05 08:53:01 --> Utf8 Class Initialized
DEBUG - 2011-05-05 08:53:01 --> UTF-8 Support Enabled
DEBUG - 2011-05-05 08:53:01 --> URI Class Initialized
DEBUG - 2011-05-05 08:53:01 --> Router Class Initialized
ERROR - 2011-05-05 08:53:01 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-05-05 08:53:03 --> Config Class Initialized
DEBUG - 2011-05-05 08:53:03 --> Hooks Class Initialized
DEBUG - 2011-05-05 08:53:03 --> Utf8 Class Initialized
DEBUG - 2011-05-05 08:53:03 --> UTF-8 Support Enabled
DEBUG - 2011-05-05 08:53:03 --> URI Class Initialized
DEBUG - 2011-05-05 08:53:03 --> Router Class Initialized
ERROR - 2011-05-05 08:53:03 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-05-05 08:58:00 --> Config Class Initialized
DEBUG - 2011-05-05 08:58:00 --> Hooks Class Initialized
DEBUG - 2011-05-05 08:58:00 --> Utf8 Class Initialized
DEBUG - 2011-05-05 08:58:00 --> UTF-8 Support Enabled
DEBUG - 2011-05-05 08:58:00 --> URI Class Initialized
DEBUG - 2011-05-05 08:58:00 --> Router Class Initialized
DEBUG - 2011-05-05 08:58:00 --> Output Class Initialized
DEBUG - 2011-05-05 08:58:00 --> Input Class Initialized
DEBUG - 2011-05-05 08:58:00 --> Global POST and COOKIE data sanitized
DEBUG - 2011-05-05 08:58:00 --> Language Class Initialized
DEBUG - 2011-05-05 08:58:00 --> Loader Class Initialized
DEBUG - 2011-05-05 08:58:00 --> Controller Class Initialized
ERROR - 2011-05-05 08:58:00 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-05-05 08:58:00 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-05-05 08:58:00 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-05-05 08:58:00 --> Model Class Initialized
DEBUG - 2011-05-05 08:58:00 --> Model Class Initialized
DEBUG - 2011-05-05 08:58:00 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-05-05 08:58:00 --> Database Driver Class Initialized
DEBUG - 2011-05-05 08:58:00 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-05-05 08:58:00 --> Helper loaded: url_helper
DEBUG - 2011-05-05 08:58:00 --> File loaded: application/views/common/header.php
DEBUG - 2011-05-05 08:58:00 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-05-05 08:58:00 --> File loaded: application/views/common/footer.php
DEBUG - 2011-05-05 08:58:00 --> File loaded: application/views/layout/main.php
DEBUG - 2011-05-05 08:58:00 --> Final output sent to browser
DEBUG - 2011-05-05 08:58:00 --> Total execution time: 0.1138
DEBUG - 2011-05-05 08:58:01 --> Config Class Initialized
DEBUG - 2011-05-05 08:58:01 --> Hooks Class Initialized
DEBUG - 2011-05-05 08:58:01 --> Utf8 Class Initialized
DEBUG - 2011-05-05 08:58:01 --> UTF-8 Support Enabled
DEBUG - 2011-05-05 08:58:01 --> URI Class Initialized
DEBUG - 2011-05-05 08:58:01 --> Router Class Initialized
DEBUG - 2011-05-05 08:58:01 --> Output Class Initialized
DEBUG - 2011-05-05 08:58:01 --> Input Class Initialized
DEBUG - 2011-05-05 08:58:01 --> Global POST and COOKIE data sanitized
DEBUG - 2011-05-05 08:58:01 --> Language Class Initialized
DEBUG - 2011-05-05 08:58:01 --> Loader Class Initialized
DEBUG - 2011-05-05 08:58:01 --> Controller Class Initialized
DEBUG - 2011-05-05 08:58:01 --> Model Class Initialized
DEBUG - 2011-05-05 08:58:01 --> Model Class Initialized
DEBUG - 2011-05-05 08:58:01 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-05-05 08:58:01 --> Database Driver Class Initialized
DEBUG - 2011-05-05 08:58:02 --> Final output sent to browser
DEBUG - 2011-05-05 08:58:02 --> Total execution time: 0.6192
DEBUG - 2011-05-05 08:59:37 --> Config Class Initialized
DEBUG - 2011-05-05 08:59:37 --> Hooks Class Initialized
DEBUG - 2011-05-05 08:59:37 --> Utf8 Class Initialized
DEBUG - 2011-05-05 08:59:37 --> UTF-8 Support Enabled
DEBUG - 2011-05-05 08:59:37 --> URI Class Initialized
DEBUG - 2011-05-05 08:59:37 --> Router Class Initialized
DEBUG - 2011-05-05 08:59:37 --> Output Class Initialized
DEBUG - 2011-05-05 08:59:37 --> Input Class Initialized
DEBUG - 2011-05-05 08:59:37 --> Global POST and COOKIE data sanitized
DEBUG - 2011-05-05 08:59:37 --> Language Class Initialized
DEBUG - 2011-05-05 08:59:37 --> Loader Class Initialized
DEBUG - 2011-05-05 08:59:37 --> Controller Class Initialized
ERROR - 2011-05-05 08:59:37 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-05-05 08:59:37 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-05-05 08:59:37 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-05-05 08:59:37 --> Model Class Initialized
DEBUG - 2011-05-05 08:59:37 --> Model Class Initialized
DEBUG - 2011-05-05 08:59:37 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-05-05 08:59:37 --> Database Driver Class Initialized
DEBUG - 2011-05-05 08:59:37 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-05-05 08:59:37 --> Helper loaded: url_helper
DEBUG - 2011-05-05 08:59:37 --> File loaded: application/views/common/header.php
DEBUG - 2011-05-05 08:59:37 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-05-05 08:59:37 --> File loaded: application/views/common/footer.php
DEBUG - 2011-05-05 08:59:37 --> File loaded: application/views/layout/main.php
DEBUG - 2011-05-05 08:59:37 --> Final output sent to browser
DEBUG - 2011-05-05 08:59:37 --> Total execution time: 0.0437
DEBUG - 2011-05-05 08:59:38 --> Config Class Initialized
DEBUG - 2011-05-05 08:59:38 --> Hooks Class Initialized
DEBUG - 2011-05-05 08:59:38 --> Utf8 Class Initialized
DEBUG - 2011-05-05 08:59:38 --> UTF-8 Support Enabled
DEBUG - 2011-05-05 08:59:38 --> URI Class Initialized
DEBUG - 2011-05-05 08:59:38 --> Router Class Initialized
DEBUG - 2011-05-05 08:59:38 --> Output Class Initialized
DEBUG - 2011-05-05 08:59:38 --> Input Class Initialized
DEBUG - 2011-05-05 08:59:38 --> Global POST and COOKIE data sanitized
DEBUG - 2011-05-05 08:59:38 --> Language Class Initialized
DEBUG - 2011-05-05 08:59:38 --> Loader Class Initialized
DEBUG - 2011-05-05 08:59:38 --> Controller Class Initialized
DEBUG - 2011-05-05 08:59:38 --> Model Class Initialized
DEBUG - 2011-05-05 08:59:38 --> Model Class Initialized
DEBUG - 2011-05-05 08:59:38 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-05-05 08:59:38 --> Database Driver Class Initialized
DEBUG - 2011-05-05 08:59:39 --> Final output sent to browser
DEBUG - 2011-05-05 08:59:39 --> Total execution time: 0.7831
DEBUG - 2011-05-05 09:00:40 --> Config Class Initialized
DEBUG - 2011-05-05 09:00:40 --> Hooks Class Initialized
DEBUG - 2011-05-05 09:00:40 --> Utf8 Class Initialized
DEBUG - 2011-05-05 09:00:40 --> UTF-8 Support Enabled
DEBUG - 2011-05-05 09:00:40 --> URI Class Initialized
DEBUG - 2011-05-05 09:00:40 --> Router Class Initialized
DEBUG - 2011-05-05 09:00:40 --> Output Class Initialized
DEBUG - 2011-05-05 09:00:40 --> Input Class Initialized
DEBUG - 2011-05-05 09:00:40 --> Global POST and COOKIE data sanitized
DEBUG - 2011-05-05 09:00:40 --> Language Class Initialized
DEBUG - 2011-05-05 09:00:40 --> Loader Class Initialized
DEBUG - 2011-05-05 09:00:40 --> Controller Class Initialized
ERROR - 2011-05-05 09:00:40 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-05-05 09:00:40 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-05-05 09:00:40 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-05-05 09:00:40 --> Model Class Initialized
DEBUG - 2011-05-05 09:00:40 --> Model Class Initialized
DEBUG - 2011-05-05 09:00:40 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-05-05 09:00:40 --> Database Driver Class Initialized
DEBUG - 2011-05-05 09:00:40 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-05-05 09:00:40 --> Helper loaded: url_helper
DEBUG - 2011-05-05 09:00:40 --> File loaded: application/views/common/header.php
DEBUG - 2011-05-05 09:00:40 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-05-05 09:00:40 --> File loaded: application/views/common/footer.php
DEBUG - 2011-05-05 09:00:40 --> File loaded: application/views/layout/main.php
DEBUG - 2011-05-05 09:00:40 --> Final output sent to browser
DEBUG - 2011-05-05 09:00:40 --> Total execution time: 0.0452
DEBUG - 2011-05-05 09:00:40 --> Config Class Initialized
DEBUG - 2011-05-05 09:00:40 --> Hooks Class Initialized
DEBUG - 2011-05-05 09:00:40 --> Utf8 Class Initialized
DEBUG - 2011-05-05 09:00:40 --> UTF-8 Support Enabled
DEBUG - 2011-05-05 09:00:40 --> URI Class Initialized
DEBUG - 2011-05-05 09:00:40 --> Router Class Initialized
DEBUG - 2011-05-05 09:00:40 --> Output Class Initialized
DEBUG - 2011-05-05 09:00:40 --> Input Class Initialized
DEBUG - 2011-05-05 09:00:40 --> Global POST and COOKIE data sanitized
DEBUG - 2011-05-05 09:00:40 --> Language Class Initialized
DEBUG - 2011-05-05 09:00:40 --> Loader Class Initialized
DEBUG - 2011-05-05 09:00:40 --> Controller Class Initialized
DEBUG - 2011-05-05 09:00:40 --> Model Class Initialized
DEBUG - 2011-05-05 09:00:40 --> Model Class Initialized
DEBUG - 2011-05-05 09:00:40 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-05-05 09:00:40 --> Database Driver Class Initialized
DEBUG - 2011-05-05 09:00:41 --> Final output sent to browser
DEBUG - 2011-05-05 09:00:41 --> Total execution time: 0.7917
DEBUG - 2011-05-05 09:01:09 --> Config Class Initialized
DEBUG - 2011-05-05 09:01:09 --> Hooks Class Initialized
DEBUG - 2011-05-05 09:01:09 --> Utf8 Class Initialized
DEBUG - 2011-05-05 09:01:09 --> UTF-8 Support Enabled
DEBUG - 2011-05-05 09:01:09 --> URI Class Initialized
DEBUG - 2011-05-05 09:01:09 --> Router Class Initialized
DEBUG - 2011-05-05 09:01:09 --> Output Class Initialized
DEBUG - 2011-05-05 09:01:09 --> Input Class Initialized
DEBUG - 2011-05-05 09:01:09 --> Global POST and COOKIE data sanitized
DEBUG - 2011-05-05 09:01:09 --> Language Class Initialized
DEBUG - 2011-05-05 09:01:09 --> Loader Class Initialized
DEBUG - 2011-05-05 09:01:09 --> Controller Class Initialized
ERROR - 2011-05-05 09:01:09 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-05-05 09:01:09 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-05-05 09:01:09 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-05-05 09:01:09 --> Model Class Initialized
DEBUG - 2011-05-05 09:01:09 --> Model Class Initialized
DEBUG - 2011-05-05 09:01:09 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-05-05 09:01:09 --> Database Driver Class Initialized
DEBUG - 2011-05-05 09:01:09 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-05-05 09:01:10 --> Helper loaded: url_helper
DEBUG - 2011-05-05 09:01:10 --> File loaded: application/views/common/header.php
DEBUG - 2011-05-05 09:01:10 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-05-05 09:01:10 --> File loaded: application/views/common/footer.php
DEBUG - 2011-05-05 09:01:10 --> File loaded: application/views/layout/main.php
DEBUG - 2011-05-05 09:01:10 --> Final output sent to browser
DEBUG - 2011-05-05 09:01:10 --> Total execution time: 0.1041
DEBUG - 2011-05-05 09:01:11 --> Config Class Initialized
DEBUG - 2011-05-05 09:01:11 --> Hooks Class Initialized
DEBUG - 2011-05-05 09:01:11 --> Utf8 Class Initialized
DEBUG - 2011-05-05 09:01:11 --> UTF-8 Support Enabled
DEBUG - 2011-05-05 09:01:11 --> URI Class Initialized
DEBUG - 2011-05-05 09:01:11 --> Router Class Initialized
DEBUG - 2011-05-05 09:01:11 --> Output Class Initialized
DEBUG - 2011-05-05 09:01:11 --> Input Class Initialized
DEBUG - 2011-05-05 09:01:11 --> Global POST and COOKIE data sanitized
DEBUG - 2011-05-05 09:01:11 --> Language Class Initialized
DEBUG - 2011-05-05 09:01:11 --> Loader Class Initialized
DEBUG - 2011-05-05 09:01:11 --> Controller Class Initialized
DEBUG - 2011-05-05 09:01:11 --> Model Class Initialized
DEBUG - 2011-05-05 09:01:11 --> Model Class Initialized
DEBUG - 2011-05-05 09:01:11 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-05-05 09:01:11 --> Database Driver Class Initialized
DEBUG - 2011-05-05 09:01:11 --> Final output sent to browser
DEBUG - 2011-05-05 09:01:11 --> Total execution time: 0.9229
DEBUG - 2011-05-05 09:01:12 --> Config Class Initialized
DEBUG - 2011-05-05 09:01:12 --> Hooks Class Initialized
DEBUG - 2011-05-05 09:01:12 --> Utf8 Class Initialized
DEBUG - 2011-05-05 09:01:12 --> UTF-8 Support Enabled
DEBUG - 2011-05-05 09:01:12 --> URI Class Initialized
DEBUG - 2011-05-05 09:01:12 --> Router Class Initialized
DEBUG - 2011-05-05 09:01:12 --> Output Class Initialized
DEBUG - 2011-05-05 09:01:12 --> Input Class Initialized
DEBUG - 2011-05-05 09:01:12 --> Global POST and COOKIE data sanitized
DEBUG - 2011-05-05 09:01:12 --> Language Class Initialized
DEBUG - 2011-05-05 09:01:12 --> Loader Class Initialized
DEBUG - 2011-05-05 09:01:12 --> Controller Class Initialized
ERROR - 2011-05-05 09:01:12 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-05-05 09:01:12 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-05-05 09:01:12 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-05-05 09:01:12 --> Model Class Initialized
DEBUG - 2011-05-05 09:01:12 --> Model Class Initialized
DEBUG - 2011-05-05 09:01:12 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-05-05 09:01:12 --> Database Driver Class Initialized
DEBUG - 2011-05-05 09:01:12 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-05-05 09:01:12 --> Helper loaded: url_helper
DEBUG - 2011-05-05 09:01:12 --> File loaded: application/views/common/header.php
DEBUG - 2011-05-05 09:01:12 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-05-05 09:01:12 --> File loaded: application/views/common/footer.php
DEBUG - 2011-05-05 09:01:12 --> File loaded: application/views/layout/main.php
DEBUG - 2011-05-05 09:01:12 --> Final output sent to browser
DEBUG - 2011-05-05 09:01:12 --> Total execution time: 0.1502
DEBUG - 2011-05-05 09:01:17 --> Config Class Initialized
DEBUG - 2011-05-05 09:01:17 --> Hooks Class Initialized
DEBUG - 2011-05-05 09:01:17 --> Utf8 Class Initialized
DEBUG - 2011-05-05 09:01:17 --> UTF-8 Support Enabled
DEBUG - 2011-05-05 09:01:17 --> URI Class Initialized
DEBUG - 2011-05-05 09:01:17 --> Router Class Initialized
DEBUG - 2011-05-05 09:01:17 --> Output Class Initialized
DEBUG - 2011-05-05 09:01:17 --> Input Class Initialized
DEBUG - 2011-05-05 09:01:17 --> Global POST and COOKIE data sanitized
DEBUG - 2011-05-05 09:01:17 --> Language Class Initialized
DEBUG - 2011-05-05 09:01:17 --> Loader Class Initialized
DEBUG - 2011-05-05 09:01:17 --> Controller Class Initialized
ERROR - 2011-05-05 09:01:17 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-05-05 09:01:17 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-05-05 09:01:17 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-05-05 09:01:17 --> Model Class Initialized
DEBUG - 2011-05-05 09:01:17 --> Model Class Initialized
DEBUG - 2011-05-05 09:01:17 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-05-05 09:01:17 --> Database Driver Class Initialized
DEBUG - 2011-05-05 09:01:17 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-05-05 09:01:17 --> Helper loaded: url_helper
DEBUG - 2011-05-05 09:01:17 --> File loaded: application/views/common/header.php
DEBUG - 2011-05-05 09:01:17 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-05-05 09:01:17 --> File loaded: application/views/common/footer.php
DEBUG - 2011-05-05 09:01:17 --> File loaded: application/views/layout/main.php
DEBUG - 2011-05-05 09:01:17 --> Final output sent to browser
DEBUG - 2011-05-05 09:01:17 --> Total execution time: 0.0564
DEBUG - 2011-05-05 09:01:36 --> Config Class Initialized
DEBUG - 2011-05-05 09:01:36 --> Hooks Class Initialized
DEBUG - 2011-05-05 09:01:36 --> Utf8 Class Initialized
DEBUG - 2011-05-05 09:01:36 --> UTF-8 Support Enabled
DEBUG - 2011-05-05 09:01:36 --> URI Class Initialized
DEBUG - 2011-05-05 09:01:36 --> Router Class Initialized
DEBUG - 2011-05-05 09:01:36 --> Output Class Initialized
DEBUG - 2011-05-05 09:01:36 --> Input Class Initialized
DEBUG - 2011-05-05 09:01:36 --> Global POST and COOKIE data sanitized
DEBUG - 2011-05-05 09:01:36 --> Language Class Initialized
DEBUG - 2011-05-05 09:01:36 --> Loader Class Initialized
DEBUG - 2011-05-05 09:01:36 --> Controller Class Initialized
ERROR - 2011-05-05 09:01:36 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-05-05 09:01:36 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-05-05 09:01:36 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-05-05 09:01:36 --> Model Class Initialized
DEBUG - 2011-05-05 09:01:36 --> Model Class Initialized
DEBUG - 2011-05-05 09:01:36 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-05-05 09:01:36 --> Database Driver Class Initialized
DEBUG - 2011-05-05 09:01:36 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-05-05 09:01:36 --> Helper loaded: url_helper
DEBUG - 2011-05-05 09:01:36 --> File loaded: application/views/common/header.php
DEBUG - 2011-05-05 09:01:36 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-05-05 09:01:36 --> File loaded: application/views/common/footer.php
DEBUG - 2011-05-05 09:01:36 --> File loaded: application/views/layout/main.php
DEBUG - 2011-05-05 09:01:36 --> Final output sent to browser
DEBUG - 2011-05-05 09:01:36 --> Total execution time: 0.0418
DEBUG - 2011-05-05 09:01:37 --> Config Class Initialized
DEBUG - 2011-05-05 09:01:37 --> Hooks Class Initialized
DEBUG - 2011-05-05 09:01:37 --> Utf8 Class Initialized
DEBUG - 2011-05-05 09:01:37 --> UTF-8 Support Enabled
DEBUG - 2011-05-05 09:01:37 --> URI Class Initialized
DEBUG - 2011-05-05 09:01:37 --> Router Class Initialized
DEBUG - 2011-05-05 09:01:37 --> Output Class Initialized
DEBUG - 2011-05-05 09:01:37 --> Input Class Initialized
DEBUG - 2011-05-05 09:01:37 --> Global POST and COOKIE data sanitized
DEBUG - 2011-05-05 09:01:37 --> Language Class Initialized
DEBUG - 2011-05-05 09:01:37 --> Loader Class Initialized
DEBUG - 2011-05-05 09:01:37 --> Controller Class Initialized
DEBUG - 2011-05-05 09:01:37 --> Model Class Initialized
DEBUG - 2011-05-05 09:01:37 --> Model Class Initialized
DEBUG - 2011-05-05 09:01:37 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-05-05 09:01:37 --> Database Driver Class Initialized
DEBUG - 2011-05-05 09:01:38 --> Final output sent to browser
DEBUG - 2011-05-05 09:01:38 --> Total execution time: 1.0609
DEBUG - 2011-05-05 09:02:16 --> Config Class Initialized
DEBUG - 2011-05-05 09:02:16 --> Hooks Class Initialized
DEBUG - 2011-05-05 09:02:16 --> Utf8 Class Initialized
DEBUG - 2011-05-05 09:02:16 --> UTF-8 Support Enabled
DEBUG - 2011-05-05 09:02:16 --> URI Class Initialized
DEBUG - 2011-05-05 09:02:16 --> Router Class Initialized
DEBUG - 2011-05-05 09:02:16 --> Output Class Initialized
DEBUG - 2011-05-05 09:02:16 --> Input Class Initialized
DEBUG - 2011-05-05 09:02:16 --> Global POST and COOKIE data sanitized
DEBUG - 2011-05-05 09:02:16 --> Language Class Initialized
DEBUG - 2011-05-05 09:02:16 --> Loader Class Initialized
DEBUG - 2011-05-05 09:02:16 --> Controller Class Initialized
ERROR - 2011-05-05 09:02:16 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-05-05 09:02:16 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-05-05 09:02:16 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-05-05 09:02:16 --> Model Class Initialized
DEBUG - 2011-05-05 09:02:16 --> Model Class Initialized
DEBUG - 2011-05-05 09:02:16 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-05-05 09:02:16 --> Database Driver Class Initialized
DEBUG - 2011-05-05 09:02:16 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-05-05 09:02:16 --> Helper loaded: url_helper
DEBUG - 2011-05-05 09:02:16 --> File loaded: application/views/common/header.php
DEBUG - 2011-05-05 09:02:16 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-05-05 09:02:16 --> File loaded: application/views/common/footer.php
DEBUG - 2011-05-05 09:02:16 --> File loaded: application/views/layout/main.php
DEBUG - 2011-05-05 09:02:16 --> Final output sent to browser
DEBUG - 2011-05-05 09:02:16 --> Total execution time: 0.1883
DEBUG - 2011-05-05 09:02:18 --> Config Class Initialized
DEBUG - 2011-05-05 09:02:18 --> Hooks Class Initialized
DEBUG - 2011-05-05 09:02:18 --> Utf8 Class Initialized
DEBUG - 2011-05-05 09:02:18 --> UTF-8 Support Enabled
DEBUG - 2011-05-05 09:02:18 --> URI Class Initialized
DEBUG - 2011-05-05 09:02:18 --> Router Class Initialized
DEBUG - 2011-05-05 09:02:18 --> Output Class Initialized
DEBUG - 2011-05-05 09:02:18 --> Input Class Initialized
DEBUG - 2011-05-05 09:02:18 --> Global POST and COOKIE data sanitized
DEBUG - 2011-05-05 09:02:18 --> Language Class Initialized
DEBUG - 2011-05-05 09:02:18 --> Loader Class Initialized
DEBUG - 2011-05-05 09:02:18 --> Controller Class Initialized
DEBUG - 2011-05-05 09:02:18 --> Model Class Initialized
DEBUG - 2011-05-05 09:02:18 --> Model Class Initialized
DEBUG - 2011-05-05 09:02:18 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-05-05 09:02:18 --> Database Driver Class Initialized
DEBUG - 2011-05-05 09:02:19 --> Final output sent to browser
DEBUG - 2011-05-05 09:02:19 --> Total execution time: 0.8921
DEBUG - 2011-05-05 09:03:10 --> Config Class Initialized
DEBUG - 2011-05-05 09:03:10 --> Hooks Class Initialized
DEBUG - 2011-05-05 09:03:10 --> Utf8 Class Initialized
DEBUG - 2011-05-05 09:03:10 --> UTF-8 Support Enabled
DEBUG - 2011-05-05 09:03:10 --> URI Class Initialized
DEBUG - 2011-05-05 09:03:10 --> Router Class Initialized
DEBUG - 2011-05-05 09:03:10 --> Output Class Initialized
DEBUG - 2011-05-05 09:03:11 --> Input Class Initialized
DEBUG - 2011-05-05 09:03:11 --> Global POST and COOKIE data sanitized
DEBUG - 2011-05-05 09:03:11 --> Language Class Initialized
DEBUG - 2011-05-05 09:03:11 --> Loader Class Initialized
DEBUG - 2011-05-05 09:03:11 --> Controller Class Initialized
ERROR - 2011-05-05 09:03:11 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-05-05 09:03:11 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-05-05 09:03:11 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-05-05 09:03:11 --> Model Class Initialized
DEBUG - 2011-05-05 09:03:11 --> Model Class Initialized
DEBUG - 2011-05-05 09:03:11 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-05-05 09:03:11 --> Database Driver Class Initialized
DEBUG - 2011-05-05 09:03:11 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-05-05 09:03:11 --> Helper loaded: url_helper
DEBUG - 2011-05-05 09:03:11 --> File loaded: application/views/common/header.php
DEBUG - 2011-05-05 09:03:11 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-05-05 09:03:11 --> File loaded: application/views/common/footer.php
DEBUG - 2011-05-05 09:03:11 --> File loaded: application/views/layout/main.php
DEBUG - 2011-05-05 09:03:11 --> Final output sent to browser
DEBUG - 2011-05-05 09:03:11 --> Total execution time: 0.1249
DEBUG - 2011-05-05 09:03:11 --> Config Class Initialized
DEBUG - 2011-05-05 09:03:11 --> Hooks Class Initialized
DEBUG - 2011-05-05 09:03:11 --> Utf8 Class Initialized
DEBUG - 2011-05-05 09:03:11 --> UTF-8 Support Enabled
DEBUG - 2011-05-05 09:03:11 --> URI Class Initialized
DEBUG - 2011-05-05 09:03:11 --> Router Class Initialized
DEBUG - 2011-05-05 09:03:11 --> Output Class Initialized
DEBUG - 2011-05-05 09:03:11 --> Input Class Initialized
DEBUG - 2011-05-05 09:03:11 --> Global POST and COOKIE data sanitized
DEBUG - 2011-05-05 09:03:11 --> Language Class Initialized
DEBUG - 2011-05-05 09:03:11 --> Loader Class Initialized
DEBUG - 2011-05-05 09:03:11 --> Controller Class Initialized
DEBUG - 2011-05-05 09:03:11 --> Model Class Initialized
DEBUG - 2011-05-05 09:03:11 --> Model Class Initialized
DEBUG - 2011-05-05 09:03:11 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-05-05 09:03:11 --> Database Driver Class Initialized
DEBUG - 2011-05-05 09:03:12 --> Final output sent to browser
DEBUG - 2011-05-05 09:03:12 --> Total execution time: 0.7509
DEBUG - 2011-05-05 09:03:37 --> Config Class Initialized
DEBUG - 2011-05-05 09:03:37 --> Hooks Class Initialized
DEBUG - 2011-05-05 09:03:37 --> Utf8 Class Initialized
DEBUG - 2011-05-05 09:03:37 --> UTF-8 Support Enabled
DEBUG - 2011-05-05 09:03:37 --> URI Class Initialized
DEBUG - 2011-05-05 09:03:37 --> Router Class Initialized
DEBUG - 2011-05-05 09:03:37 --> Output Class Initialized
DEBUG - 2011-05-05 09:03:37 --> Input Class Initialized
DEBUG - 2011-05-05 09:03:37 --> Global POST and COOKIE data sanitized
DEBUG - 2011-05-05 09:03:37 --> Language Class Initialized
DEBUG - 2011-05-05 09:03:37 --> Loader Class Initialized
DEBUG - 2011-05-05 09:03:37 --> Controller Class Initialized
ERROR - 2011-05-05 09:03:37 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-05-05 09:03:37 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-05-05 09:03:37 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-05-05 09:03:37 --> Model Class Initialized
DEBUG - 2011-05-05 09:03:37 --> Model Class Initialized
DEBUG - 2011-05-05 09:03:37 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-05-05 09:03:37 --> Database Driver Class Initialized
DEBUG - 2011-05-05 09:03:37 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-05-05 09:03:37 --> Helper loaded: url_helper
DEBUG - 2011-05-05 09:03:37 --> File loaded: application/views/common/header.php
DEBUG - 2011-05-05 09:03:37 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-05-05 09:03:37 --> File loaded: application/views/common/footer.php
DEBUG - 2011-05-05 09:03:37 --> File loaded: application/views/layout/main.php
DEBUG - 2011-05-05 09:03:37 --> Final output sent to browser
DEBUG - 2011-05-05 09:03:37 --> Total execution time: 0.0276
DEBUG - 2011-05-05 09:03:38 --> Config Class Initialized
DEBUG - 2011-05-05 09:03:38 --> Hooks Class Initialized
DEBUG - 2011-05-05 09:03:38 --> Utf8 Class Initialized
DEBUG - 2011-05-05 09:03:38 --> UTF-8 Support Enabled
DEBUG - 2011-05-05 09:03:38 --> URI Class Initialized
DEBUG - 2011-05-05 09:03:38 --> Router Class Initialized
DEBUG - 2011-05-05 09:03:38 --> Output Class Initialized
DEBUG - 2011-05-05 09:03:38 --> Input Class Initialized
DEBUG - 2011-05-05 09:03:38 --> Global POST and COOKIE data sanitized
DEBUG - 2011-05-05 09:03:38 --> Language Class Initialized
DEBUG - 2011-05-05 09:03:38 --> Loader Class Initialized
DEBUG - 2011-05-05 09:03:38 --> Controller Class Initialized
DEBUG - 2011-05-05 09:03:38 --> Model Class Initialized
DEBUG - 2011-05-05 09:03:38 --> Model Class Initialized
DEBUG - 2011-05-05 09:03:38 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-05-05 09:03:38 --> Database Driver Class Initialized
DEBUG - 2011-05-05 09:03:39 --> Final output sent to browser
DEBUG - 2011-05-05 09:03:39 --> Total execution time: 0.6118
DEBUG - 2011-05-05 09:03:58 --> Config Class Initialized
DEBUG - 2011-05-05 09:03:58 --> Hooks Class Initialized
DEBUG - 2011-05-05 09:03:58 --> Utf8 Class Initialized
DEBUG - 2011-05-05 09:03:58 --> UTF-8 Support Enabled
DEBUG - 2011-05-05 09:03:58 --> URI Class Initialized
DEBUG - 2011-05-05 09:03:58 --> Router Class Initialized
DEBUG - 2011-05-05 09:03:58 --> Output Class Initialized
DEBUG - 2011-05-05 09:03:58 --> Input Class Initialized
DEBUG - 2011-05-05 09:03:58 --> Global POST and COOKIE data sanitized
DEBUG - 2011-05-05 09:03:58 --> Language Class Initialized
DEBUG - 2011-05-05 09:03:58 --> Loader Class Initialized
DEBUG - 2011-05-05 09:03:58 --> Controller Class Initialized
ERROR - 2011-05-05 09:03:58 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-05-05 09:03:58 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-05-05 09:03:58 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-05-05 09:03:58 --> Model Class Initialized
DEBUG - 2011-05-05 09:03:58 --> Model Class Initialized
DEBUG - 2011-05-05 09:03:58 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-05-05 09:03:58 --> Database Driver Class Initialized
DEBUG - 2011-05-05 09:03:58 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-05-05 09:03:58 --> Helper loaded: url_helper
DEBUG - 2011-05-05 09:03:58 --> File loaded: application/views/common/header.php
DEBUG - 2011-05-05 09:03:58 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-05-05 09:03:58 --> File loaded: application/views/common/footer.php
DEBUG - 2011-05-05 09:03:58 --> File loaded: application/views/layout/main.php
DEBUG - 2011-05-05 09:03:58 --> Final output sent to browser
DEBUG - 2011-05-05 09:03:58 --> Total execution time: 0.0475
DEBUG - 2011-05-05 09:03:58 --> Config Class Initialized
DEBUG - 2011-05-05 09:03:58 --> Hooks Class Initialized
DEBUG - 2011-05-05 09:03:58 --> Utf8 Class Initialized
DEBUG - 2011-05-05 09:03:58 --> UTF-8 Support Enabled
DEBUG - 2011-05-05 09:03:58 --> URI Class Initialized
DEBUG - 2011-05-05 09:03:58 --> Router Class Initialized
DEBUG - 2011-05-05 09:03:58 --> Output Class Initialized
DEBUG - 2011-05-05 09:03:58 --> Input Class Initialized
DEBUG - 2011-05-05 09:03:58 --> Global POST and COOKIE data sanitized
DEBUG - 2011-05-05 09:03:58 --> Language Class Initialized
DEBUG - 2011-05-05 09:03:58 --> Loader Class Initialized
DEBUG - 2011-05-05 09:03:58 --> Controller Class Initialized
DEBUG - 2011-05-05 09:03:58 --> Model Class Initialized
DEBUG - 2011-05-05 09:03:58 --> Model Class Initialized
DEBUG - 2011-05-05 09:03:58 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-05-05 09:03:58 --> Database Driver Class Initialized
DEBUG - 2011-05-05 09:03:59 --> Final output sent to browser
DEBUG - 2011-05-05 09:03:59 --> Total execution time: 0.8965
DEBUG - 2011-05-05 09:04:12 --> Config Class Initialized
DEBUG - 2011-05-05 09:04:12 --> Hooks Class Initialized
DEBUG - 2011-05-05 09:04:12 --> Utf8 Class Initialized
DEBUG - 2011-05-05 09:04:12 --> UTF-8 Support Enabled
DEBUG - 2011-05-05 09:04:12 --> URI Class Initialized
DEBUG - 2011-05-05 09:04:12 --> Router Class Initialized
DEBUG - 2011-05-05 09:04:12 --> Output Class Initialized
DEBUG - 2011-05-05 09:04:12 --> Input Class Initialized
DEBUG - 2011-05-05 09:04:12 --> Global POST and COOKIE data sanitized
DEBUG - 2011-05-05 09:04:12 --> Language Class Initialized
DEBUG - 2011-05-05 09:04:12 --> Loader Class Initialized
DEBUG - 2011-05-05 09:04:12 --> Controller Class Initialized
ERROR - 2011-05-05 09:04:12 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-05-05 09:04:12 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-05-05 09:04:12 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-05-05 09:04:12 --> Model Class Initialized
DEBUG - 2011-05-05 09:04:12 --> Model Class Initialized
DEBUG - 2011-05-05 09:04:12 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-05-05 09:04:12 --> Database Driver Class Initialized
DEBUG - 2011-05-05 09:04:12 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-05-05 09:04:12 --> Helper loaded: url_helper
DEBUG - 2011-05-05 09:04:12 --> File loaded: application/views/common/header.php
DEBUG - 2011-05-05 09:04:12 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-05-05 09:04:12 --> File loaded: application/views/common/footer.php
DEBUG - 2011-05-05 09:04:12 --> File loaded: application/views/layout/main.php
DEBUG - 2011-05-05 09:04:12 --> Final output sent to browser
DEBUG - 2011-05-05 09:04:12 --> Total execution time: 0.1316
DEBUG - 2011-05-05 09:04:13 --> Config Class Initialized
DEBUG - 2011-05-05 09:04:13 --> Hooks Class Initialized
DEBUG - 2011-05-05 09:04:13 --> Utf8 Class Initialized
DEBUG - 2011-05-05 09:04:13 --> UTF-8 Support Enabled
DEBUG - 2011-05-05 09:04:13 --> URI Class Initialized
DEBUG - 2011-05-05 09:04:13 --> Router Class Initialized
DEBUG - 2011-05-05 09:04:13 --> Output Class Initialized
DEBUG - 2011-05-05 09:04:13 --> Input Class Initialized
DEBUG - 2011-05-05 09:04:13 --> Global POST and COOKIE data sanitized
DEBUG - 2011-05-05 09:04:13 --> Language Class Initialized
DEBUG - 2011-05-05 09:04:13 --> Loader Class Initialized
DEBUG - 2011-05-05 09:04:13 --> Controller Class Initialized
DEBUG - 2011-05-05 09:04:13 --> Model Class Initialized
DEBUG - 2011-05-05 09:04:13 --> Model Class Initialized
DEBUG - 2011-05-05 09:04:13 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-05-05 09:04:14 --> Database Driver Class Initialized
DEBUG - 2011-05-05 09:04:14 --> Final output sent to browser
DEBUG - 2011-05-05 09:04:14 --> Total execution time: 1.0045
DEBUG - 2011-05-05 09:07:15 --> Config Class Initialized
DEBUG - 2011-05-05 09:07:15 --> Hooks Class Initialized
DEBUG - 2011-05-05 09:07:15 --> Utf8 Class Initialized
DEBUG - 2011-05-05 09:07:15 --> UTF-8 Support Enabled
DEBUG - 2011-05-05 09:07:15 --> URI Class Initialized
DEBUG - 2011-05-05 09:07:15 --> Router Class Initialized
DEBUG - 2011-05-05 09:07:15 --> Output Class Initialized
DEBUG - 2011-05-05 09:07:15 --> Input Class Initialized
DEBUG - 2011-05-05 09:07:15 --> Global POST and COOKIE data sanitized
DEBUG - 2011-05-05 09:07:15 --> Language Class Initialized
DEBUG - 2011-05-05 09:07:15 --> Loader Class Initialized
DEBUG - 2011-05-05 09:07:15 --> Controller Class Initialized
ERROR - 2011-05-05 09:07:15 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-05-05 09:07:15 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-05-05 09:07:15 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-05-05 09:07:15 --> Model Class Initialized
DEBUG - 2011-05-05 09:07:15 --> Model Class Initialized
DEBUG - 2011-05-05 09:07:15 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-05-05 09:07:15 --> Database Driver Class Initialized
DEBUG - 2011-05-05 09:07:15 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-05-05 09:07:15 --> Helper loaded: url_helper
DEBUG - 2011-05-05 09:07:15 --> File loaded: application/views/common/header.php
DEBUG - 2011-05-05 09:07:15 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-05-05 09:07:15 --> File loaded: application/views/common/footer.php
DEBUG - 2011-05-05 09:07:15 --> File loaded: application/views/layout/main.php
DEBUG - 2011-05-05 09:07:15 --> Final output sent to browser
DEBUG - 2011-05-05 09:07:15 --> Total execution time: 0.0518
DEBUG - 2011-05-05 09:07:16 --> Config Class Initialized
DEBUG - 2011-05-05 09:07:16 --> Hooks Class Initialized
DEBUG - 2011-05-05 09:07:16 --> Utf8 Class Initialized
DEBUG - 2011-05-05 09:07:16 --> UTF-8 Support Enabled
DEBUG - 2011-05-05 09:07:16 --> URI Class Initialized
DEBUG - 2011-05-05 09:07:16 --> Router Class Initialized
DEBUG - 2011-05-05 09:07:16 --> Output Class Initialized
DEBUG - 2011-05-05 09:07:16 --> Input Class Initialized
DEBUG - 2011-05-05 09:07:16 --> Global POST and COOKIE data sanitized
DEBUG - 2011-05-05 09:07:16 --> Language Class Initialized
DEBUG - 2011-05-05 09:07:16 --> Loader Class Initialized
DEBUG - 2011-05-05 09:07:16 --> Controller Class Initialized
DEBUG - 2011-05-05 09:07:16 --> Model Class Initialized
DEBUG - 2011-05-05 09:07:16 --> Model Class Initialized
DEBUG - 2011-05-05 09:07:16 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-05-05 09:07:16 --> Database Driver Class Initialized
DEBUG - 2011-05-05 09:07:17 --> Final output sent to browser
DEBUG - 2011-05-05 09:07:17 --> Total execution time: 0.6066
DEBUG - 2011-05-05 09:07:17 --> Config Class Initialized
DEBUG - 2011-05-05 09:07:17 --> Hooks Class Initialized
DEBUG - 2011-05-05 09:07:17 --> Utf8 Class Initialized
DEBUG - 2011-05-05 09:07:17 --> UTF-8 Support Enabled
DEBUG - 2011-05-05 09:07:17 --> URI Class Initialized
DEBUG - 2011-05-05 09:07:17 --> Router Class Initialized
DEBUG - 2011-05-05 09:07:17 --> Output Class Initialized
DEBUG - 2011-05-05 09:07:17 --> Input Class Initialized
DEBUG - 2011-05-05 09:07:17 --> Global POST and COOKIE data sanitized
DEBUG - 2011-05-05 09:07:17 --> Language Class Initialized
DEBUG - 2011-05-05 09:07:17 --> Loader Class Initialized
DEBUG - 2011-05-05 09:07:17 --> Controller Class Initialized
ERROR - 2011-05-05 09:07:17 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-05-05 09:07:17 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-05-05 09:07:17 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-05-05 09:07:17 --> Model Class Initialized
DEBUG - 2011-05-05 09:07:17 --> Model Class Initialized
DEBUG - 2011-05-05 09:07:17 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-05-05 09:07:17 --> Database Driver Class Initialized
DEBUG - 2011-05-05 09:07:17 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-05-05 09:07:17 --> Helper loaded: url_helper
DEBUG - 2011-05-05 09:07:17 --> File loaded: application/views/common/header.php
DEBUG - 2011-05-05 09:07:17 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-05-05 09:07:17 --> File loaded: application/views/common/footer.php
DEBUG - 2011-05-05 09:07:17 --> File loaded: application/views/layout/main.php
DEBUG - 2011-05-05 09:07:17 --> Final output sent to browser
DEBUG - 2011-05-05 09:07:17 --> Total execution time: 0.0415
DEBUG - 2011-05-05 09:13:28 --> Config Class Initialized
DEBUG - 2011-05-05 09:13:28 --> Hooks Class Initialized
DEBUG - 2011-05-05 09:13:28 --> Utf8 Class Initialized
DEBUG - 2011-05-05 09:13:28 --> UTF-8 Support Enabled
DEBUG - 2011-05-05 09:13:28 --> URI Class Initialized
DEBUG - 2011-05-05 09:13:28 --> Router Class Initialized
DEBUG - 2011-05-05 09:13:28 --> Output Class Initialized
DEBUG - 2011-05-05 09:13:28 --> Input Class Initialized
DEBUG - 2011-05-05 09:13:28 --> Global POST and COOKIE data sanitized
DEBUG - 2011-05-05 09:13:28 --> Language Class Initialized
DEBUG - 2011-05-05 09:13:28 --> Loader Class Initialized
DEBUG - 2011-05-05 09:13:28 --> Controller Class Initialized
ERROR - 2011-05-05 09:13:28 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-05-05 09:13:28 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-05-05 09:13:28 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-05-05 09:13:28 --> Model Class Initialized
DEBUG - 2011-05-05 09:13:28 --> Model Class Initialized
DEBUG - 2011-05-05 09:13:28 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-05-05 09:13:28 --> Database Driver Class Initialized
DEBUG - 2011-05-05 09:13:28 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-05-05 09:13:28 --> Helper loaded: url_helper
DEBUG - 2011-05-05 09:13:28 --> File loaded: application/views/common/header.php
DEBUG - 2011-05-05 09:13:28 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-05-05 09:13:28 --> File loaded: application/views/common/footer.php
DEBUG - 2011-05-05 09:13:28 --> File loaded: application/views/layout/main.php
DEBUG - 2011-05-05 09:13:28 --> Final output sent to browser
DEBUG - 2011-05-05 09:13:28 --> Total execution time: 0.1616
DEBUG - 2011-05-05 09:13:29 --> Config Class Initialized
DEBUG - 2011-05-05 09:13:29 --> Hooks Class Initialized
DEBUG - 2011-05-05 09:13:29 --> Utf8 Class Initialized
DEBUG - 2011-05-05 09:13:29 --> UTF-8 Support Enabled
DEBUG - 2011-05-05 09:13:29 --> URI Class Initialized
DEBUG - 2011-05-05 09:13:29 --> Router Class Initialized
DEBUG - 2011-05-05 09:13:29 --> Output Class Initialized
DEBUG - 2011-05-05 09:13:29 --> Input Class Initialized
DEBUG - 2011-05-05 09:13:29 --> Global POST and COOKIE data sanitized
DEBUG - 2011-05-05 09:13:29 --> Language Class Initialized
DEBUG - 2011-05-05 09:13:29 --> Loader Class Initialized
DEBUG - 2011-05-05 09:13:29 --> Controller Class Initialized
DEBUG - 2011-05-05 09:13:29 --> Model Class Initialized
DEBUG - 2011-05-05 09:13:29 --> Model Class Initialized
DEBUG - 2011-05-05 09:13:29 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-05-05 09:13:29 --> Database Driver Class Initialized
DEBUG - 2011-05-05 09:13:30 --> Final output sent to browser
DEBUG - 2011-05-05 09:13:30 --> Total execution time: 0.4897
DEBUG - 2011-05-05 09:13:31 --> Config Class Initialized
DEBUG - 2011-05-05 09:13:31 --> Hooks Class Initialized
DEBUG - 2011-05-05 09:13:31 --> Utf8 Class Initialized
DEBUG - 2011-05-05 09:13:31 --> UTF-8 Support Enabled
DEBUG - 2011-05-05 09:13:31 --> URI Class Initialized
DEBUG - 2011-05-05 09:13:31 --> Router Class Initialized
ERROR - 2011-05-05 09:13:31 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-05-05 09:13:33 --> Config Class Initialized
DEBUG - 2011-05-05 09:13:33 --> Hooks Class Initialized
DEBUG - 2011-05-05 09:13:33 --> Utf8 Class Initialized
DEBUG - 2011-05-05 09:13:33 --> UTF-8 Support Enabled
DEBUG - 2011-05-05 09:13:33 --> URI Class Initialized
DEBUG - 2011-05-05 09:13:33 --> Router Class Initialized
ERROR - 2011-05-05 09:13:33 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-05-05 09:47:35 --> Config Class Initialized
DEBUG - 2011-05-05 09:47:35 --> Hooks Class Initialized
DEBUG - 2011-05-05 09:47:35 --> Utf8 Class Initialized
DEBUG - 2011-05-05 09:47:35 --> UTF-8 Support Enabled
DEBUG - 2011-05-05 09:47:35 --> URI Class Initialized
DEBUG - 2011-05-05 09:47:35 --> Router Class Initialized
DEBUG - 2011-05-05 09:47:35 --> No URI present. Default controller set.
DEBUG - 2011-05-05 09:47:35 --> Output Class Initialized
DEBUG - 2011-05-05 09:47:35 --> Input Class Initialized
DEBUG - 2011-05-05 09:47:35 --> Global POST and COOKIE data sanitized
DEBUG - 2011-05-05 09:47:35 --> Language Class Initialized
DEBUG - 2011-05-05 09:47:35 --> Loader Class Initialized
DEBUG - 2011-05-05 09:47:35 --> Controller Class Initialized
DEBUG - 2011-05-05 09:47:35 --> File loaded: application/views/splash/main.php
DEBUG - 2011-05-05 09:47:35 --> Helper loaded: url_helper
DEBUG - 2011-05-05 09:47:35 --> File loaded: application/views/common/header.php
DEBUG - 2011-05-05 09:47:35 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-05-05 09:47:35 --> File loaded: application/views/common/footer.php
DEBUG - 2011-05-05 09:47:35 --> File loaded: application/views/layout/main.php
DEBUG - 2011-05-05 09:47:35 --> Final output sent to browser
DEBUG - 2011-05-05 09:47:35 --> Total execution time: 0.3239
DEBUG - 2011-05-05 09:47:40 --> Config Class Initialized
DEBUG - 2011-05-05 09:47:40 --> Hooks Class Initialized
DEBUG - 2011-05-05 09:47:40 --> Utf8 Class Initialized
DEBUG - 2011-05-05 09:47:40 --> UTF-8 Support Enabled
DEBUG - 2011-05-05 09:47:40 --> URI Class Initialized
DEBUG - 2011-05-05 09:47:40 --> Router Class Initialized
DEBUG - 2011-05-05 09:47:40 --> Output Class Initialized
DEBUG - 2011-05-05 09:47:40 --> Input Class Initialized
DEBUG - 2011-05-05 09:47:40 --> Global POST and COOKIE data sanitized
DEBUG - 2011-05-05 09:47:40 --> Language Class Initialized
DEBUG - 2011-05-05 09:47:40 --> Loader Class Initialized
DEBUG - 2011-05-05 09:47:40 --> Controller Class Initialized
DEBUG - 2011-05-05 09:47:40 --> Model Class Initialized
DEBUG - 2011-05-05 09:47:40 --> Model Class Initialized
DEBUG - 2011-05-05 09:47:40 --> Model Class Initialized
DEBUG - 2011-05-05 09:47:40 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-05-05 09:47:40 --> Database Driver Class Initialized
DEBUG - 2011-05-05 09:47:40 --> File loaded: application/views/table/main.php
DEBUG - 2011-05-05 09:47:40 --> Helper loaded: url_helper
DEBUG - 2011-05-05 09:47:40 --> File loaded: application/views/common/header.php
DEBUG - 2011-05-05 09:47:40 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-05-05 09:47:40 --> File loaded: application/views/common/footer.php
DEBUG - 2011-05-05 09:47:40 --> File loaded: application/views/layout/main.php
DEBUG - 2011-05-05 09:47:40 --> Final output sent to browser
DEBUG - 2011-05-05 09:47:40 --> Total execution time: 0.4189
DEBUG - 2011-05-05 09:48:06 --> Config Class Initialized
DEBUG - 2011-05-05 09:48:06 --> Hooks Class Initialized
DEBUG - 2011-05-05 09:48:06 --> Utf8 Class Initialized
DEBUG - 2011-05-05 09:48:06 --> UTF-8 Support Enabled
DEBUG - 2011-05-05 09:48:06 --> URI Class Initialized
DEBUG - 2011-05-05 09:48:06 --> Router Class Initialized
DEBUG - 2011-05-05 09:48:06 --> Output Class Initialized
DEBUG - 2011-05-05 09:48:06 --> Input Class Initialized
DEBUG - 2011-05-05 09:48:06 --> Global POST and COOKIE data sanitized
DEBUG - 2011-05-05 09:48:06 --> Language Class Initialized
DEBUG - 2011-05-05 09:48:06 --> Loader Class Initialized
DEBUG - 2011-05-05 09:48:06 --> Controller Class Initialized
DEBUG - 2011-05-05 09:48:06 --> Model Class Initialized
DEBUG - 2011-05-05 09:48:06 --> Model Class Initialized
DEBUG - 2011-05-05 09:48:06 --> Model Class Initialized
DEBUG - 2011-05-05 09:48:06 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-05-05 09:48:06 --> Database Driver Class Initialized
DEBUG - 2011-05-05 09:48:07 --> File loaded: application/views/table/main.php
DEBUG - 2011-05-05 09:48:07 --> Helper loaded: url_helper
DEBUG - 2011-05-05 09:48:07 --> File loaded: application/views/common/header.php
DEBUG - 2011-05-05 09:48:07 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-05-05 09:48:07 --> File loaded: application/views/common/footer.php
DEBUG - 2011-05-05 09:48:07 --> File loaded: application/views/layout/main.php
DEBUG - 2011-05-05 09:48:07 --> Final output sent to browser
DEBUG - 2011-05-05 09:48:07 --> Total execution time: 0.4000
DEBUG - 2011-05-05 09:48:08 --> Config Class Initialized
DEBUG - 2011-05-05 09:48:08 --> Hooks Class Initialized
DEBUG - 2011-05-05 09:48:08 --> Utf8 Class Initialized
DEBUG - 2011-05-05 09:48:08 --> UTF-8 Support Enabled
DEBUG - 2011-05-05 09:48:08 --> URI Class Initialized
DEBUG - 2011-05-05 09:48:08 --> Router Class Initialized
DEBUG - 2011-05-05 09:48:08 --> Output Class Initialized
DEBUG - 2011-05-05 09:48:08 --> Input Class Initialized
DEBUG - 2011-05-05 09:48:08 --> Global POST and COOKIE data sanitized
DEBUG - 2011-05-05 09:48:08 --> Language Class Initialized
DEBUG - 2011-05-05 09:48:08 --> Loader Class Initialized
DEBUG - 2011-05-05 09:48:08 --> Controller Class Initialized
DEBUG - 2011-05-05 09:48:08 --> Model Class Initialized
DEBUG - 2011-05-05 09:48:08 --> Model Class Initialized
DEBUG - 2011-05-05 09:48:08 --> Model Class Initialized
DEBUG - 2011-05-05 09:48:08 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-05-05 09:48:08 --> Database Driver Class Initialized
DEBUG - 2011-05-05 09:48:09 --> File loaded: application/views/table/main.php
DEBUG - 2011-05-05 09:48:09 --> Helper loaded: url_helper
DEBUG - 2011-05-05 09:48:09 --> File loaded: application/views/common/header.php
DEBUG - 2011-05-05 09:48:09 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-05-05 09:48:09 --> File loaded: application/views/common/footer.php
DEBUG - 2011-05-05 09:48:09 --> File loaded: application/views/layout/main.php
DEBUG - 2011-05-05 09:48:09 --> Final output sent to browser
DEBUG - 2011-05-05 09:48:09 --> Total execution time: 0.0505
DEBUG - 2011-05-05 09:48:23 --> Config Class Initialized
DEBUG - 2011-05-05 09:48:23 --> Hooks Class Initialized
DEBUG - 2011-05-05 09:48:23 --> Utf8 Class Initialized
DEBUG - 2011-05-05 09:48:23 --> UTF-8 Support Enabled
DEBUG - 2011-05-05 09:48:23 --> URI Class Initialized
DEBUG - 2011-05-05 09:48:23 --> Router Class Initialized
DEBUG - 2011-05-05 09:48:23 --> Output Class Initialized
DEBUG - 2011-05-05 09:48:23 --> Input Class Initialized
DEBUG - 2011-05-05 09:48:23 --> Global POST and COOKIE data sanitized
DEBUG - 2011-05-05 09:48:23 --> Language Class Initialized
DEBUG - 2011-05-05 09:48:23 --> Loader Class Initialized
DEBUG - 2011-05-05 09:48:23 --> Controller Class Initialized
DEBUG - 2011-05-05 09:48:23 --> Model Class Initialized
DEBUG - 2011-05-05 09:48:23 --> Model Class Initialized
DEBUG - 2011-05-05 09:48:23 --> Model Class Initialized
DEBUG - 2011-05-05 09:48:23 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-05-05 09:48:23 --> Database Driver Class Initialized
DEBUG - 2011-05-05 09:48:23 --> File loaded: application/views/table/main.php
DEBUG - 2011-05-05 09:48:23 --> Helper loaded: url_helper
DEBUG - 2011-05-05 09:48:23 --> File loaded: application/views/common/header.php
DEBUG - 2011-05-05 09:48:23 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-05-05 09:48:23 --> File loaded: application/views/common/footer.php
DEBUG - 2011-05-05 09:48:23 --> File loaded: application/views/layout/main.php
DEBUG - 2011-05-05 09:48:23 --> Final output sent to browser
DEBUG - 2011-05-05 09:48:23 --> Total execution time: 0.4458
DEBUG - 2011-05-05 09:48:26 --> Config Class Initialized
DEBUG - 2011-05-05 09:48:26 --> Hooks Class Initialized
DEBUG - 2011-05-05 09:48:26 --> Utf8 Class Initialized
DEBUG - 2011-05-05 09:48:26 --> UTF-8 Support Enabled
DEBUG - 2011-05-05 09:48:26 --> URI Class Initialized
DEBUG - 2011-05-05 09:48:26 --> Router Class Initialized
DEBUG - 2011-05-05 09:48:26 --> Output Class Initialized
DEBUG - 2011-05-05 09:48:26 --> Input Class Initialized
DEBUG - 2011-05-05 09:48:26 --> Global POST and COOKIE data sanitized
DEBUG - 2011-05-05 09:48:26 --> Language Class Initialized
DEBUG - 2011-05-05 09:48:26 --> Loader Class Initialized
DEBUG - 2011-05-05 09:48:26 --> Controller Class Initialized
DEBUG - 2011-05-05 09:48:26 --> Model Class Initialized
DEBUG - 2011-05-05 09:48:26 --> Model Class Initialized
DEBUG - 2011-05-05 09:48:26 --> Model Class Initialized
DEBUG - 2011-05-05 09:48:26 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-05-05 09:48:26 --> Database Driver Class Initialized
DEBUG - 2011-05-05 09:48:26 --> File loaded: application/views/table/main.php
DEBUG - 2011-05-05 09:48:26 --> Helper loaded: url_helper
DEBUG - 2011-05-05 09:48:26 --> File loaded: application/views/common/header.php
DEBUG - 2011-05-05 09:48:26 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-05-05 09:48:26 --> File loaded: application/views/common/footer.php
DEBUG - 2011-05-05 09:48:26 --> File loaded: application/views/layout/main.php
DEBUG - 2011-05-05 09:48:26 --> Final output sent to browser
DEBUG - 2011-05-05 09:48:26 --> Total execution time: 0.0503
DEBUG - 2011-05-05 10:17:51 --> Config Class Initialized
DEBUG - 2011-05-05 10:17:51 --> Hooks Class Initialized
DEBUG - 2011-05-05 10:17:51 --> Utf8 Class Initialized
DEBUG - 2011-05-05 10:17:51 --> UTF-8 Support Enabled
DEBUG - 2011-05-05 10:17:51 --> URI Class Initialized
DEBUG - 2011-05-05 10:17:51 --> Router Class Initialized
DEBUG - 2011-05-05 10:17:51 --> Output Class Initialized
DEBUG - 2011-05-05 10:17:51 --> Input Class Initialized
DEBUG - 2011-05-05 10:17:51 --> Global POST and COOKIE data sanitized
DEBUG - 2011-05-05 10:17:51 --> Language Class Initialized
DEBUG - 2011-05-05 10:17:51 --> Loader Class Initialized
DEBUG - 2011-05-05 10:17:51 --> Controller Class Initialized
DEBUG - 2011-05-05 10:17:51 --> Model Class Initialized
DEBUG - 2011-05-05 10:17:52 --> Model Class Initialized
DEBUG - 2011-05-05 10:17:52 --> Model Class Initialized
DEBUG - 2011-05-05 10:17:52 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-05-05 10:17:52 --> Database Driver Class Initialized
DEBUG - 2011-05-05 10:17:52 --> Config Class Initialized
DEBUG - 2011-05-05 10:17:52 --> Hooks Class Initialized
DEBUG - 2011-05-05 10:17:52 --> Utf8 Class Initialized
DEBUG - 2011-05-05 10:17:52 --> UTF-8 Support Enabled
DEBUG - 2011-05-05 10:17:52 --> URI Class Initialized
DEBUG - 2011-05-05 10:17:52 --> Router Class Initialized
DEBUG - 2011-05-05 10:17:52 --> Output Class Initialized
DEBUG - 2011-05-05 10:17:52 --> Input Class Initialized
DEBUG - 2011-05-05 10:17:52 --> Global POST and COOKIE data sanitized
DEBUG - 2011-05-05 10:17:52 --> Language Class Initialized
DEBUG - 2011-05-05 10:17:52 --> Loader Class Initialized
DEBUG - 2011-05-05 10:17:52 --> Controller Class Initialized
DEBUG - 2011-05-05 10:17:52 --> File loaded: application/views/table/main.php
ERROR - 2011-05-05 10:17:52 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-05-05 10:17:52 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-05-05 10:17:52 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-05-05 10:17:52 --> Model Class Initialized
DEBUG - 2011-05-05 10:17:52 --> Model Class Initialized
DEBUG - 2011-05-05 10:17:52 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-05-05 10:17:52 --> Database Driver Class Initialized
DEBUG - 2011-05-05 10:17:52 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-05-05 10:17:52 --> Helper loaded: url_helper
DEBUG - 2011-05-05 10:17:52 --> File loaded: application/views/common/header.php
DEBUG - 2011-05-05 10:17:52 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-05-05 10:17:52 --> Helper loaded: url_helper
DEBUG - 2011-05-05 10:17:52 --> File loaded: application/views/common/header.php
DEBUG - 2011-05-05 10:17:52 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-05-05 10:17:52 --> File loaded: application/views/common/footer.php
DEBUG - 2011-05-05 10:17:52 --> File loaded: application/views/common/footer.php
DEBUG - 2011-05-05 10:17:52 --> File loaded: application/views/layout/main.php
DEBUG - 2011-05-05 10:17:52 --> File loaded: application/views/layout/main.php
DEBUG - 2011-05-05 10:17:52 --> Final output sent to browser
DEBUG - 2011-05-05 10:17:52 --> Final output sent to browser
DEBUG - 2011-05-05 10:17:52 --> Total execution time: 1.4348
DEBUG - 2011-05-05 10:17:52 --> Total execution time: 0.3197
DEBUG - 2011-05-05 10:17:53 --> Config Class Initialized
DEBUG - 2011-05-05 10:17:53 --> Hooks Class Initialized
DEBUG - 2011-05-05 10:17:53 --> Utf8 Class Initialized
DEBUG - 2011-05-05 10:17:53 --> UTF-8 Support Enabled
DEBUG - 2011-05-05 10:17:53 --> URI Class Initialized
DEBUG - 2011-05-05 10:17:53 --> Router Class Initialized
DEBUG - 2011-05-05 10:17:53 --> Output Class Initialized
DEBUG - 2011-05-05 10:17:53 --> Input Class Initialized
DEBUG - 2011-05-05 10:17:53 --> Global POST and COOKIE data sanitized
DEBUG - 2011-05-05 10:17:53 --> Language Class Initialized
DEBUG - 2011-05-05 10:17:53 --> Loader Class Initialized
DEBUG - 2011-05-05 10:17:53 --> Controller Class Initialized
DEBUG - 2011-05-05 10:17:53 --> Model Class Initialized
DEBUG - 2011-05-05 10:17:53 --> Model Class Initialized
DEBUG - 2011-05-05 10:17:53 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-05-05 10:17:53 --> Database Driver Class Initialized
DEBUG - 2011-05-05 10:17:54 --> Final output sent to browser
DEBUG - 2011-05-05 10:17:54 --> Total execution time: 0.6993
DEBUG - 2011-05-05 10:17:54 --> Config Class Initialized
DEBUG - 2011-05-05 10:17:54 --> Hooks Class Initialized
DEBUG - 2011-05-05 10:17:54 --> Utf8 Class Initialized
DEBUG - 2011-05-05 10:17:54 --> UTF-8 Support Enabled
DEBUG - 2011-05-05 10:17:54 --> URI Class Initialized
DEBUG - 2011-05-05 10:17:54 --> Router Class Initialized
ERROR - 2011-05-05 10:17:54 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-05-05 10:17:56 --> Config Class Initialized
DEBUG - 2011-05-05 10:17:56 --> Hooks Class Initialized
DEBUG - 2011-05-05 10:17:56 --> Utf8 Class Initialized
DEBUG - 2011-05-05 10:17:56 --> UTF-8 Support Enabled
DEBUG - 2011-05-05 10:17:56 --> URI Class Initialized
DEBUG - 2011-05-05 10:17:56 --> Router Class Initialized
ERROR - 2011-05-05 10:17:56 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-05-05 10:18:02 --> Config Class Initialized
DEBUG - 2011-05-05 10:18:02 --> Hooks Class Initialized
DEBUG - 2011-05-05 10:18:02 --> Utf8 Class Initialized
DEBUG - 2011-05-05 10:18:02 --> UTF-8 Support Enabled
DEBUG - 2011-05-05 10:18:02 --> URI Class Initialized
DEBUG - 2011-05-05 10:18:02 --> Router Class Initialized
DEBUG - 2011-05-05 10:18:02 --> Output Class Initialized
DEBUG - 2011-05-05 10:18:02 --> Input Class Initialized
DEBUG - 2011-05-05 10:18:02 --> Global POST and COOKIE data sanitized
DEBUG - 2011-05-05 10:18:02 --> Language Class Initialized
DEBUG - 2011-05-05 10:18:02 --> Loader Class Initialized
DEBUG - 2011-05-05 10:18:02 --> Controller Class Initialized
ERROR - 2011-05-05 10:18:02 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-05-05 10:18:02 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-05-05 10:18:02 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-05-05 10:18:02 --> Model Class Initialized
DEBUG - 2011-05-05 10:18:02 --> Model Class Initialized
DEBUG - 2011-05-05 10:18:02 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-05-05 10:18:02 --> Database Driver Class Initialized
DEBUG - 2011-05-05 10:18:02 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-05-05 10:18:02 --> Helper loaded: url_helper
DEBUG - 2011-05-05 10:18:02 --> File loaded: application/views/common/header.php
DEBUG - 2011-05-05 10:18:02 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-05-05 10:18:02 --> File loaded: application/views/common/footer.php
DEBUG - 2011-05-05 10:18:02 --> File loaded: application/views/layout/main.php
DEBUG - 2011-05-05 10:18:02 --> Final output sent to browser
DEBUG - 2011-05-05 10:18:02 --> Total execution time: 0.0294
DEBUG - 2011-05-05 10:18:02 --> Config Class Initialized
DEBUG - 2011-05-05 10:18:02 --> Hooks Class Initialized
DEBUG - 2011-05-05 10:18:02 --> Utf8 Class Initialized
DEBUG - 2011-05-05 10:18:02 --> UTF-8 Support Enabled
DEBUG - 2011-05-05 10:18:02 --> URI Class Initialized
DEBUG - 2011-05-05 10:18:02 --> Router Class Initialized
DEBUG - 2011-05-05 10:18:02 --> Output Class Initialized
DEBUG - 2011-05-05 10:18:02 --> Input Class Initialized
DEBUG - 2011-05-05 10:18:02 --> Global POST and COOKIE data sanitized
DEBUG - 2011-05-05 10:18:02 --> Language Class Initialized
DEBUG - 2011-05-05 10:18:02 --> Loader Class Initialized
DEBUG - 2011-05-05 10:18:02 --> Controller Class Initialized
DEBUG - 2011-05-05 10:18:02 --> Model Class Initialized
DEBUG - 2011-05-05 10:18:02 --> Model Class Initialized
DEBUG - 2011-05-05 10:18:02 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-05-05 10:18:02 --> Database Driver Class Initialized
DEBUG - 2011-05-05 10:18:03 --> Final output sent to browser
DEBUG - 2011-05-05 10:18:03 --> Total execution time: 0.8215
DEBUG - 2011-05-05 10:18:17 --> Config Class Initialized
DEBUG - 2011-05-05 10:18:17 --> Hooks Class Initialized
DEBUG - 2011-05-05 10:18:17 --> Utf8 Class Initialized
DEBUG - 2011-05-05 10:18:17 --> UTF-8 Support Enabled
DEBUG - 2011-05-05 10:18:17 --> URI Class Initialized
DEBUG - 2011-05-05 10:18:17 --> Router Class Initialized
DEBUG - 2011-05-05 10:18:17 --> Output Class Initialized
DEBUG - 2011-05-05 10:18:17 --> Input Class Initialized
DEBUG - 2011-05-05 10:18:17 --> Global POST and COOKIE data sanitized
DEBUG - 2011-05-05 10:18:17 --> Language Class Initialized
DEBUG - 2011-05-05 10:18:17 --> Loader Class Initialized
DEBUG - 2011-05-05 10:18:17 --> Controller Class Initialized
ERROR - 2011-05-05 10:18:17 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-05-05 10:18:17 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-05-05 10:18:17 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-05-05 10:18:17 --> Model Class Initialized
DEBUG - 2011-05-05 10:18:17 --> Model Class Initialized
DEBUG - 2011-05-05 10:18:17 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-05-05 10:18:17 --> Database Driver Class Initialized
DEBUG - 2011-05-05 10:18:17 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-05-05 10:18:17 --> Helper loaded: url_helper
DEBUG - 2011-05-05 10:18:17 --> File loaded: application/views/common/header.php
DEBUG - 2011-05-05 10:18:17 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-05-05 10:18:17 --> File loaded: application/views/common/footer.php
DEBUG - 2011-05-05 10:18:17 --> File loaded: application/views/layout/main.php
DEBUG - 2011-05-05 10:18:17 --> Final output sent to browser
DEBUG - 2011-05-05 10:18:17 --> Total execution time: 0.0378
DEBUG - 2011-05-05 10:18:17 --> Config Class Initialized
DEBUG - 2011-05-05 10:18:17 --> Hooks Class Initialized
DEBUG - 2011-05-05 10:18:17 --> Utf8 Class Initialized
DEBUG - 2011-05-05 10:18:17 --> UTF-8 Support Enabled
DEBUG - 2011-05-05 10:18:17 --> URI Class Initialized
DEBUG - 2011-05-05 10:18:17 --> Router Class Initialized
DEBUG - 2011-05-05 10:18:17 --> Output Class Initialized
DEBUG - 2011-05-05 10:18:17 --> Input Class Initialized
DEBUG - 2011-05-05 10:18:17 --> Global POST and COOKIE data sanitized
DEBUG - 2011-05-05 10:18:17 --> Language Class Initialized
DEBUG - 2011-05-05 10:18:17 --> Loader Class Initialized
DEBUG - 2011-05-05 10:18:17 --> Controller Class Initialized
DEBUG - 2011-05-05 10:18:17 --> Model Class Initialized
DEBUG - 2011-05-05 10:18:17 --> Model Class Initialized
DEBUG - 2011-05-05 10:18:17 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-05-05 10:18:17 --> Database Driver Class Initialized
DEBUG - 2011-05-05 10:18:18 --> Final output sent to browser
DEBUG - 2011-05-05 10:18:18 --> Total execution time: 0.5113
DEBUG - 2011-05-05 10:18:34 --> Config Class Initialized
DEBUG - 2011-05-05 10:18:34 --> Hooks Class Initialized
DEBUG - 2011-05-05 10:18:34 --> Utf8 Class Initialized
DEBUG - 2011-05-05 10:18:34 --> UTF-8 Support Enabled
DEBUG - 2011-05-05 10:18:34 --> URI Class Initialized
DEBUG - 2011-05-05 10:18:34 --> Router Class Initialized
DEBUG - 2011-05-05 10:18:34 --> Output Class Initialized
DEBUG - 2011-05-05 10:18:34 --> Input Class Initialized
DEBUG - 2011-05-05 10:18:34 --> Global POST and COOKIE data sanitized
DEBUG - 2011-05-05 10:18:34 --> Language Class Initialized
DEBUG - 2011-05-05 10:18:34 --> Loader Class Initialized
DEBUG - 2011-05-05 10:18:34 --> Controller Class Initialized
ERROR - 2011-05-05 10:18:34 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-05-05 10:18:34 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-05-05 10:18:34 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-05-05 10:18:34 --> Model Class Initialized
DEBUG - 2011-05-05 10:18:34 --> Model Class Initialized
DEBUG - 2011-05-05 10:18:34 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-05-05 10:18:34 --> Database Driver Class Initialized
DEBUG - 2011-05-05 10:18:34 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-05-05 10:18:34 --> Helper loaded: url_helper
DEBUG - 2011-05-05 10:18:34 --> File loaded: application/views/common/header.php
DEBUG - 2011-05-05 10:18:34 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-05-05 10:18:34 --> File loaded: application/views/common/footer.php
DEBUG - 2011-05-05 10:18:34 --> File loaded: application/views/layout/main.php
DEBUG - 2011-05-05 10:18:34 --> Final output sent to browser
DEBUG - 2011-05-05 10:18:34 --> Total execution time: 0.0351
DEBUG - 2011-05-05 10:18:35 --> Config Class Initialized
DEBUG - 2011-05-05 10:18:35 --> Hooks Class Initialized
DEBUG - 2011-05-05 10:18:35 --> Utf8 Class Initialized
DEBUG - 2011-05-05 10:18:35 --> UTF-8 Support Enabled
DEBUG - 2011-05-05 10:18:35 --> URI Class Initialized
DEBUG - 2011-05-05 10:18:35 --> Router Class Initialized
DEBUG - 2011-05-05 10:18:35 --> Output Class Initialized
DEBUG - 2011-05-05 10:18:35 --> Input Class Initialized
DEBUG - 2011-05-05 10:18:35 --> Global POST and COOKIE data sanitized
DEBUG - 2011-05-05 10:18:35 --> Language Class Initialized
DEBUG - 2011-05-05 10:18:35 --> Loader Class Initialized
DEBUG - 2011-05-05 10:18:35 --> Controller Class Initialized
DEBUG - 2011-05-05 10:18:35 --> Model Class Initialized
DEBUG - 2011-05-05 10:18:35 --> Model Class Initialized
DEBUG - 2011-05-05 10:18:35 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-05-05 10:18:35 --> Database Driver Class Initialized
DEBUG - 2011-05-05 10:18:35 --> Final output sent to browser
DEBUG - 2011-05-05 10:18:35 --> Total execution time: 0.6105
DEBUG - 2011-05-05 10:42:16 --> Config Class Initialized
DEBUG - 2011-05-05 10:42:16 --> Hooks Class Initialized
DEBUG - 2011-05-05 10:42:16 --> Utf8 Class Initialized
DEBUG - 2011-05-05 10:42:16 --> UTF-8 Support Enabled
DEBUG - 2011-05-05 10:42:16 --> URI Class Initialized
DEBUG - 2011-05-05 10:42:16 --> Router Class Initialized
DEBUG - 2011-05-05 10:42:16 --> Output Class Initialized
DEBUG - 2011-05-05 10:42:16 --> Input Class Initialized
DEBUG - 2011-05-05 10:42:16 --> Global POST and COOKIE data sanitized
DEBUG - 2011-05-05 10:42:16 --> Language Class Initialized
DEBUG - 2011-05-05 10:42:16 --> Loader Class Initialized
DEBUG - 2011-05-05 10:42:16 --> Controller Class Initialized
DEBUG - 2011-05-05 10:42:16 --> Model Class Initialized
DEBUG - 2011-05-05 10:42:16 --> Model Class Initialized
DEBUG - 2011-05-05 10:42:16 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-05-05 10:42:16 --> Database Driver Class Initialized
DEBUG - 2011-05-05 10:42:17 --> Final output sent to browser
DEBUG - 2011-05-05 10:42:17 --> Total execution time: 1.0363
DEBUG - 2011-05-05 10:49:55 --> Config Class Initialized
DEBUG - 2011-05-05 10:49:56 --> Hooks Class Initialized
DEBUG - 2011-05-05 10:49:56 --> Utf8 Class Initialized
DEBUG - 2011-05-05 10:49:56 --> UTF-8 Support Enabled
DEBUG - 2011-05-05 10:49:56 --> URI Class Initialized
DEBUG - 2011-05-05 10:49:56 --> Router Class Initialized
DEBUG - 2011-05-05 10:49:56 --> Output Class Initialized
DEBUG - 2011-05-05 10:49:56 --> Input Class Initialized
DEBUG - 2011-05-05 10:49:56 --> Global POST and COOKIE data sanitized
DEBUG - 2011-05-05 10:49:56 --> Language Class Initialized
DEBUG - 2011-05-05 10:49:56 --> Loader Class Initialized
DEBUG - 2011-05-05 10:49:56 --> Controller Class Initialized
DEBUG - 2011-05-05 10:49:56 --> Model Class Initialized
DEBUG - 2011-05-05 10:49:56 --> Model Class Initialized
DEBUG - 2011-05-05 10:49:56 --> Model Class Initialized
DEBUG - 2011-05-05 10:49:56 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-05-05 10:49:56 --> Database Driver Class Initialized
DEBUG - 2011-05-05 10:49:57 --> File loaded: application/views/table/main.php
DEBUG - 2011-05-05 10:49:57 --> Helper loaded: url_helper
DEBUG - 2011-05-05 10:49:57 --> File loaded: application/views/common/header.php
DEBUG - 2011-05-05 10:49:57 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-05-05 10:49:57 --> File loaded: application/views/common/footer.php
DEBUG - 2011-05-05 10:49:57 --> File loaded: application/views/layout/main.php
DEBUG - 2011-05-05 10:49:57 --> Final output sent to browser
DEBUG - 2011-05-05 10:49:57 --> Total execution time: 2.2372
DEBUG - 2011-05-05 10:49:59 --> Config Class Initialized
DEBUG - 2011-05-05 10:49:59 --> Hooks Class Initialized
DEBUG - 2011-05-05 10:49:59 --> Utf8 Class Initialized
DEBUG - 2011-05-05 10:49:59 --> UTF-8 Support Enabled
DEBUG - 2011-05-05 10:49:59 --> URI Class Initialized
DEBUG - 2011-05-05 10:49:59 --> Router Class Initialized
ERROR - 2011-05-05 10:50:00 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-05-05 10:50:00 --> Config Class Initialized
DEBUG - 2011-05-05 10:50:00 --> Hooks Class Initialized
DEBUG - 2011-05-05 10:50:00 --> Utf8 Class Initialized
DEBUG - 2011-05-05 10:50:00 --> UTF-8 Support Enabled
DEBUG - 2011-05-05 10:50:00 --> URI Class Initialized
DEBUG - 2011-05-05 10:50:00 --> Router Class Initialized
ERROR - 2011-05-05 10:50:00 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-05-05 11:06:12 --> Config Class Initialized
DEBUG - 2011-05-05 11:06:12 --> Hooks Class Initialized
DEBUG - 2011-05-05 11:06:12 --> Utf8 Class Initialized
DEBUG - 2011-05-05 11:06:12 --> UTF-8 Support Enabled
DEBUG - 2011-05-05 11:06:12 --> URI Class Initialized
DEBUG - 2011-05-05 11:06:12 --> Router Class Initialized
DEBUG - 2011-05-05 11:06:12 --> No URI present. Default controller set.
DEBUG - 2011-05-05 11:06:12 --> Output Class Initialized
DEBUG - 2011-05-05 11:06:12 --> Input Class Initialized
DEBUG - 2011-05-05 11:06:12 --> Global POST and COOKIE data sanitized
DEBUG - 2011-05-05 11:06:12 --> Language Class Initialized
DEBUG - 2011-05-05 11:06:12 --> Loader Class Initialized
DEBUG - 2011-05-05 11:06:12 --> Controller Class Initialized
DEBUG - 2011-05-05 11:06:12 --> File loaded: application/views/splash/main.php
DEBUG - 2011-05-05 11:06:12 --> Helper loaded: url_helper
DEBUG - 2011-05-05 11:06:12 --> File loaded: application/views/common/header.php
DEBUG - 2011-05-05 11:06:12 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-05-05 11:06:12 --> File loaded: application/views/common/footer.php
DEBUG - 2011-05-05 11:06:12 --> File loaded: application/views/layout/main.php
DEBUG - 2011-05-05 11:06:12 --> Final output sent to browser
DEBUG - 2011-05-05 11:06:12 --> Total execution time: 0.3861
DEBUG - 2011-05-05 11:06:14 --> Config Class Initialized
DEBUG - 2011-05-05 11:06:14 --> Hooks Class Initialized
DEBUG - 2011-05-05 11:06:14 --> Utf8 Class Initialized
DEBUG - 2011-05-05 11:06:14 --> UTF-8 Support Enabled
DEBUG - 2011-05-05 11:06:14 --> URI Class Initialized
DEBUG - 2011-05-05 11:06:14 --> Router Class Initialized
ERROR - 2011-05-05 11:06:14 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-05-05 11:06:15 --> Config Class Initialized
DEBUG - 2011-05-05 11:06:15 --> Hooks Class Initialized
DEBUG - 2011-05-05 11:06:15 --> Utf8 Class Initialized
DEBUG - 2011-05-05 11:06:15 --> UTF-8 Support Enabled
DEBUG - 2011-05-05 11:06:15 --> URI Class Initialized
DEBUG - 2011-05-05 11:06:15 --> Router Class Initialized
DEBUG - 2011-05-05 11:06:15 --> Output Class Initialized
DEBUG - 2011-05-05 11:06:15 --> Input Class Initialized
DEBUG - 2011-05-05 11:06:15 --> Global POST and COOKIE data sanitized
DEBUG - 2011-05-05 11:06:15 --> Language Class Initialized
DEBUG - 2011-05-05 11:06:15 --> Loader Class Initialized
DEBUG - 2011-05-05 11:06:15 --> Controller Class Initialized
DEBUG - 2011-05-05 11:06:16 --> Model Class Initialized
DEBUG - 2011-05-05 11:06:16 --> Model Class Initialized
DEBUG - 2011-05-05 11:06:16 --> Model Class Initialized
DEBUG - 2011-05-05 11:06:16 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-05-05 11:06:16 --> Database Driver Class Initialized
DEBUG - 2011-05-05 11:06:16 --> File loaded: application/views/table/main.php
DEBUG - 2011-05-05 11:06:16 --> Helper loaded: url_helper
DEBUG - 2011-05-05 11:06:16 --> File loaded: application/views/common/header.php
DEBUG - 2011-05-05 11:06:16 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-05-05 11:06:16 --> File loaded: application/views/common/footer.php
DEBUG - 2011-05-05 11:06:16 --> File loaded: application/views/layout/main.php
DEBUG - 2011-05-05 11:06:16 --> Final output sent to browser
DEBUG - 2011-05-05 11:06:16 --> Total execution time: 0.7857
DEBUG - 2011-05-05 11:06:17 --> Config Class Initialized
DEBUG - 2011-05-05 11:06:17 --> Hooks Class Initialized
DEBUG - 2011-05-05 11:06:17 --> Utf8 Class Initialized
DEBUG - 2011-05-05 11:06:17 --> UTF-8 Support Enabled
DEBUG - 2011-05-05 11:06:17 --> URI Class Initialized
DEBUG - 2011-05-05 11:06:17 --> Router Class Initialized
ERROR - 2011-05-05 11:06:17 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-05-05 11:06:34 --> Config Class Initialized
DEBUG - 2011-05-05 11:06:34 --> Hooks Class Initialized
DEBUG - 2011-05-05 11:06:34 --> Utf8 Class Initialized
DEBUG - 2011-05-05 11:06:34 --> UTF-8 Support Enabled
DEBUG - 2011-05-05 11:06:34 --> URI Class Initialized
DEBUG - 2011-05-05 11:06:34 --> Router Class Initialized
DEBUG - 2011-05-05 11:06:34 --> Output Class Initialized
DEBUG - 2011-05-05 11:06:34 --> Input Class Initialized
DEBUG - 2011-05-05 11:06:34 --> Global POST and COOKIE data sanitized
DEBUG - 2011-05-05 11:06:34 --> Language Class Initialized
DEBUG - 2011-05-05 11:06:34 --> Loader Class Initialized
DEBUG - 2011-05-05 11:06:34 --> Controller Class Initialized
DEBUG - 2011-05-05 11:06:34 --> Model Class Initialized
DEBUG - 2011-05-05 11:06:34 --> Model Class Initialized
DEBUG - 2011-05-05 11:06:34 --> Model Class Initialized
DEBUG - 2011-05-05 11:06:34 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-05-05 11:06:34 --> Database Driver Class Initialized
DEBUG - 2011-05-05 11:06:35 --> File loaded: application/views/table/main.php
DEBUG - 2011-05-05 11:06:35 --> Helper loaded: url_helper
DEBUG - 2011-05-05 11:06:35 --> File loaded: application/views/common/header.php
DEBUG - 2011-05-05 11:06:35 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-05-05 11:06:35 --> File loaded: application/views/common/footer.php
DEBUG - 2011-05-05 11:06:35 --> File loaded: application/views/layout/main.php
DEBUG - 2011-05-05 11:06:35 --> Final output sent to browser
DEBUG - 2011-05-05 11:06:35 --> Total execution time: 0.9208
DEBUG - 2011-05-05 11:06:36 --> Config Class Initialized
DEBUG - 2011-05-05 11:06:36 --> Hooks Class Initialized
DEBUG - 2011-05-05 11:06:36 --> Utf8 Class Initialized
DEBUG - 2011-05-05 11:06:36 --> UTF-8 Support Enabled
DEBUG - 2011-05-05 11:06:36 --> URI Class Initialized
DEBUG - 2011-05-05 11:06:36 --> Router Class Initialized
ERROR - 2011-05-05 11:06:36 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-05-05 11:06:38 --> Config Class Initialized
DEBUG - 2011-05-05 11:06:38 --> Hooks Class Initialized
DEBUG - 2011-05-05 11:06:38 --> Utf8 Class Initialized
DEBUG - 2011-05-05 11:06:38 --> UTF-8 Support Enabled
DEBUG - 2011-05-05 11:06:38 --> URI Class Initialized
DEBUG - 2011-05-05 11:06:38 --> Router Class Initialized
DEBUG - 2011-05-05 11:06:38 --> Output Class Initialized
DEBUG - 2011-05-05 11:06:38 --> Input Class Initialized
DEBUG - 2011-05-05 11:06:38 --> Global POST and COOKIE data sanitized
DEBUG - 2011-05-05 11:06:38 --> Language Class Initialized
DEBUG - 2011-05-05 11:06:38 --> Loader Class Initialized
DEBUG - 2011-05-05 11:06:38 --> Controller Class Initialized
DEBUG - 2011-05-05 11:06:38 --> Model Class Initialized
DEBUG - 2011-05-05 11:06:38 --> Model Class Initialized
DEBUG - 2011-05-05 11:06:38 --> Model Class Initialized
DEBUG - 2011-05-05 11:06:38 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-05-05 11:06:38 --> Database Driver Class Initialized
DEBUG - 2011-05-05 11:06:38 --> File loaded: application/views/table/main.php
DEBUG - 2011-05-05 11:06:38 --> Helper loaded: url_helper
DEBUG - 2011-05-05 11:06:38 --> File loaded: application/views/common/header.php
DEBUG - 2011-05-05 11:06:38 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-05-05 11:06:38 --> File loaded: application/views/common/footer.php
DEBUG - 2011-05-05 11:06:38 --> File loaded: application/views/layout/main.php
DEBUG - 2011-05-05 11:06:38 --> Final output sent to browser
DEBUG - 2011-05-05 11:06:38 --> Total execution time: 0.0795
DEBUG - 2011-05-05 11:06:43 --> Config Class Initialized
DEBUG - 2011-05-05 11:06:43 --> Hooks Class Initialized
DEBUG - 2011-05-05 11:06:43 --> Utf8 Class Initialized
DEBUG - 2011-05-05 11:06:43 --> UTF-8 Support Enabled
DEBUG - 2011-05-05 11:06:43 --> URI Class Initialized
DEBUG - 2011-05-05 11:06:43 --> Router Class Initialized
DEBUG - 2011-05-05 11:06:43 --> Output Class Initialized
DEBUG - 2011-05-05 11:06:43 --> Input Class Initialized
DEBUG - 2011-05-05 11:06:43 --> Global POST and COOKIE data sanitized
DEBUG - 2011-05-05 11:06:43 --> Language Class Initialized
DEBUG - 2011-05-05 11:06:43 --> Loader Class Initialized
DEBUG - 2011-05-05 11:06:43 --> Controller Class Initialized
DEBUG - 2011-05-05 11:06:43 --> Model Class Initialized
DEBUG - 2011-05-05 11:06:43 --> Model Class Initialized
DEBUG - 2011-05-05 11:06:43 --> Model Class Initialized
DEBUG - 2011-05-05 11:06:43 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-05-05 11:06:43 --> Database Driver Class Initialized
DEBUG - 2011-05-05 11:06:43 --> File loaded: application/views/table/main.php
DEBUG - 2011-05-05 11:06:43 --> Helper loaded: url_helper
DEBUG - 2011-05-05 11:06:43 --> File loaded: application/views/common/header.php
DEBUG - 2011-05-05 11:06:43 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-05-05 11:06:43 --> File loaded: application/views/common/footer.php
DEBUG - 2011-05-05 11:06:43 --> File loaded: application/views/layout/main.php
DEBUG - 2011-05-05 11:06:43 --> Final output sent to browser
DEBUG - 2011-05-05 11:06:43 --> Total execution time: 0.0446
DEBUG - 2011-05-05 11:06:44 --> Config Class Initialized
DEBUG - 2011-05-05 11:06:44 --> Hooks Class Initialized
DEBUG - 2011-05-05 11:06:44 --> Utf8 Class Initialized
DEBUG - 2011-05-05 11:06:44 --> UTF-8 Support Enabled
DEBUG - 2011-05-05 11:06:44 --> URI Class Initialized
DEBUG - 2011-05-05 11:06:44 --> Router Class Initialized
ERROR - 2011-05-05 11:06:44 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-05-05 11:06:50 --> Config Class Initialized
DEBUG - 2011-05-05 11:06:50 --> Hooks Class Initialized
DEBUG - 2011-05-05 11:06:50 --> Utf8 Class Initialized
DEBUG - 2011-05-05 11:06:50 --> UTF-8 Support Enabled
DEBUG - 2011-05-05 11:06:50 --> URI Class Initialized
DEBUG - 2011-05-05 11:06:50 --> Router Class Initialized
DEBUG - 2011-05-05 11:06:50 --> Output Class Initialized
DEBUG - 2011-05-05 11:06:50 --> Input Class Initialized
DEBUG - 2011-05-05 11:06:50 --> Global POST and COOKIE data sanitized
DEBUG - 2011-05-05 11:06:50 --> Language Class Initialized
DEBUG - 2011-05-05 11:06:50 --> Loader Class Initialized
DEBUG - 2011-05-05 11:06:50 --> Controller Class Initialized
DEBUG - 2011-05-05 11:06:50 --> Model Class Initialized
DEBUG - 2011-05-05 11:06:50 --> Model Class Initialized
DEBUG - 2011-05-05 11:06:50 --> Model Class Initialized
DEBUG - 2011-05-05 11:06:50 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-05-05 11:06:50 --> Database Driver Class Initialized
DEBUG - 2011-05-05 11:06:50 --> File loaded: application/views/table/main.php
DEBUG - 2011-05-05 11:06:50 --> Helper loaded: url_helper
DEBUG - 2011-05-05 11:06:50 --> File loaded: application/views/common/header.php
DEBUG - 2011-05-05 11:06:50 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-05-05 11:06:50 --> File loaded: application/views/common/footer.php
DEBUG - 2011-05-05 11:06:50 --> File loaded: application/views/layout/main.php
DEBUG - 2011-05-05 11:06:50 --> Final output sent to browser
DEBUG - 2011-05-05 11:06:50 --> Total execution time: 0.0548
DEBUG - 2011-05-05 11:06:51 --> Config Class Initialized
DEBUG - 2011-05-05 11:06:51 --> Hooks Class Initialized
DEBUG - 2011-05-05 11:06:51 --> Utf8 Class Initialized
DEBUG - 2011-05-05 11:06:51 --> UTF-8 Support Enabled
DEBUG - 2011-05-05 11:06:51 --> URI Class Initialized
DEBUG - 2011-05-05 11:06:51 --> Router Class Initialized
ERROR - 2011-05-05 11:06:51 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-05-05 11:07:00 --> Config Class Initialized
DEBUG - 2011-05-05 11:07:00 --> Hooks Class Initialized
DEBUG - 2011-05-05 11:07:00 --> Utf8 Class Initialized
DEBUG - 2011-05-05 11:07:00 --> UTF-8 Support Enabled
DEBUG - 2011-05-05 11:07:00 --> URI Class Initialized
DEBUG - 2011-05-05 11:07:00 --> Router Class Initialized
DEBUG - 2011-05-05 11:07:00 --> Output Class Initialized
DEBUG - 2011-05-05 11:07:00 --> Input Class Initialized
DEBUG - 2011-05-05 11:07:00 --> Global POST and COOKIE data sanitized
DEBUG - 2011-05-05 11:07:00 --> Language Class Initialized
DEBUG - 2011-05-05 11:07:00 --> Loader Class Initialized
DEBUG - 2011-05-05 11:07:00 --> Controller Class Initialized
DEBUG - 2011-05-05 11:07:00 --> Model Class Initialized
DEBUG - 2011-05-05 11:07:00 --> Model Class Initialized
DEBUG - 2011-05-05 11:07:00 --> Model Class Initialized
DEBUG - 2011-05-05 11:07:00 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-05-05 11:07:00 --> Database Driver Class Initialized
DEBUG - 2011-05-05 11:07:01 --> File loaded: application/views/table/main.php
DEBUG - 2011-05-05 11:07:01 --> Helper loaded: url_helper
DEBUG - 2011-05-05 11:07:01 --> File loaded: application/views/common/header.php
DEBUG - 2011-05-05 11:07:01 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-05-05 11:07:01 --> File loaded: application/views/common/footer.php
DEBUG - 2011-05-05 11:07:01 --> File loaded: application/views/layout/main.php
DEBUG - 2011-05-05 11:07:01 --> Final output sent to browser
DEBUG - 2011-05-05 11:07:01 --> Total execution time: 0.2763
DEBUG - 2011-05-05 11:07:02 --> Config Class Initialized
DEBUG - 2011-05-05 11:07:02 --> Hooks Class Initialized
DEBUG - 2011-05-05 11:07:02 --> Utf8 Class Initialized
DEBUG - 2011-05-05 11:07:02 --> UTF-8 Support Enabled
DEBUG - 2011-05-05 11:07:02 --> URI Class Initialized
DEBUG - 2011-05-05 11:07:02 --> Router Class Initialized
ERROR - 2011-05-05 11:07:02 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-05-05 11:07:02 --> Config Class Initialized
DEBUG - 2011-05-05 11:07:02 --> Hooks Class Initialized
DEBUG - 2011-05-05 11:07:02 --> Utf8 Class Initialized
DEBUG - 2011-05-05 11:07:02 --> UTF-8 Support Enabled
DEBUG - 2011-05-05 11:07:02 --> URI Class Initialized
DEBUG - 2011-05-05 11:07:02 --> Router Class Initialized
DEBUG - 2011-05-05 11:07:02 --> Output Class Initialized
DEBUG - 2011-05-05 11:07:02 --> Input Class Initialized
DEBUG - 2011-05-05 11:07:02 --> Global POST and COOKIE data sanitized
DEBUG - 2011-05-05 11:07:02 --> Language Class Initialized
DEBUG - 2011-05-05 11:07:02 --> Loader Class Initialized
DEBUG - 2011-05-05 11:07:02 --> Controller Class Initialized
DEBUG - 2011-05-05 11:07:02 --> Model Class Initialized
DEBUG - 2011-05-05 11:07:02 --> Model Class Initialized
DEBUG - 2011-05-05 11:07:02 --> Model Class Initialized
DEBUG - 2011-05-05 11:07:02 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-05-05 11:07:02 --> Database Driver Class Initialized
DEBUG - 2011-05-05 11:07:02 --> File loaded: application/views/table/main.php
DEBUG - 2011-05-05 11:07:02 --> Helper loaded: url_helper
DEBUG - 2011-05-05 11:07:02 --> File loaded: application/views/common/header.php
DEBUG - 2011-05-05 11:07:02 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-05-05 11:07:02 --> File loaded: application/views/common/footer.php
DEBUG - 2011-05-05 11:07:02 --> File loaded: application/views/layout/main.php
DEBUG - 2011-05-05 11:07:02 --> Final output sent to browser
DEBUG - 2011-05-05 11:07:02 --> Total execution time: 0.0538
DEBUG - 2011-05-05 11:07:08 --> Config Class Initialized
DEBUG - 2011-05-05 11:07:08 --> Hooks Class Initialized
DEBUG - 2011-05-05 11:07:08 --> Utf8 Class Initialized
DEBUG - 2011-05-05 11:07:08 --> UTF-8 Support Enabled
DEBUG - 2011-05-05 11:07:08 --> URI Class Initialized
DEBUG - 2011-05-05 11:07:08 --> Router Class Initialized
DEBUG - 2011-05-05 11:07:08 --> Output Class Initialized
DEBUG - 2011-05-05 11:07:08 --> Input Class Initialized
DEBUG - 2011-05-05 11:07:08 --> Global POST and COOKIE data sanitized
DEBUG - 2011-05-05 11:07:08 --> Language Class Initialized
DEBUG - 2011-05-05 11:07:08 --> Loader Class Initialized
DEBUG - 2011-05-05 11:07:08 --> Controller Class Initialized
DEBUG - 2011-05-05 11:07:08 --> Model Class Initialized
DEBUG - 2011-05-05 11:07:08 --> Model Class Initialized
DEBUG - 2011-05-05 11:07:08 --> Model Class Initialized
DEBUG - 2011-05-05 11:07:08 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-05-05 11:07:08 --> Database Driver Class Initialized
DEBUG - 2011-05-05 11:07:08 --> File loaded: application/views/table/main.php
DEBUG - 2011-05-05 11:07:08 --> Helper loaded: url_helper
DEBUG - 2011-05-05 11:07:08 --> File loaded: application/views/common/header.php
DEBUG - 2011-05-05 11:07:08 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-05-05 11:07:08 --> File loaded: application/views/common/footer.php
DEBUG - 2011-05-05 11:07:08 --> File loaded: application/views/layout/main.php
DEBUG - 2011-05-05 11:07:08 --> Final output sent to browser
DEBUG - 2011-05-05 11:07:08 --> Total execution time: 0.3098
DEBUG - 2011-05-05 11:07:09 --> Config Class Initialized
DEBUG - 2011-05-05 11:07:09 --> Hooks Class Initialized
DEBUG - 2011-05-05 11:07:09 --> Utf8 Class Initialized
DEBUG - 2011-05-05 11:07:09 --> UTF-8 Support Enabled
DEBUG - 2011-05-05 11:07:09 --> URI Class Initialized
DEBUG - 2011-05-05 11:07:09 --> Router Class Initialized
DEBUG - 2011-05-05 11:07:09 --> Output Class Initialized
DEBUG - 2011-05-05 11:07:09 --> Input Class Initialized
DEBUG - 2011-05-05 11:07:09 --> Global POST and COOKIE data sanitized
DEBUG - 2011-05-05 11:07:09 --> Language Class Initialized
DEBUG - 2011-05-05 11:07:09 --> Loader Class Initialized
DEBUG - 2011-05-05 11:07:09 --> Controller Class Initialized
DEBUG - 2011-05-05 11:07:09 --> Model Class Initialized
DEBUG - 2011-05-05 11:07:09 --> Model Class Initialized
DEBUG - 2011-05-05 11:07:09 --> Model Class Initialized
DEBUG - 2011-05-05 11:07:09 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-05-05 11:07:09 --> Database Driver Class Initialized
DEBUG - 2011-05-05 11:07:09 --> File loaded: application/views/table/main.php
DEBUG - 2011-05-05 11:07:09 --> Helper loaded: url_helper
DEBUG - 2011-05-05 11:07:09 --> File loaded: application/views/common/header.php
DEBUG - 2011-05-05 11:07:09 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-05-05 11:07:09 --> File loaded: application/views/common/footer.php
DEBUG - 2011-05-05 11:07:09 --> File loaded: application/views/layout/main.php
DEBUG - 2011-05-05 11:07:09 --> Final output sent to browser
DEBUG - 2011-05-05 11:07:09 --> Total execution time: 0.0940
DEBUG - 2011-05-05 11:07:10 --> Config Class Initialized
DEBUG - 2011-05-05 11:07:10 --> Hooks Class Initialized
DEBUG - 2011-05-05 11:07:10 --> Utf8 Class Initialized
DEBUG - 2011-05-05 11:07:10 --> UTF-8 Support Enabled
DEBUG - 2011-05-05 11:07:10 --> URI Class Initialized
DEBUG - 2011-05-05 11:07:10 --> Router Class Initialized
ERROR - 2011-05-05 11:07:10 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-05-05 11:07:18 --> Config Class Initialized
DEBUG - 2011-05-05 11:07:18 --> Hooks Class Initialized
DEBUG - 2011-05-05 11:07:18 --> Utf8 Class Initialized
DEBUG - 2011-05-05 11:07:18 --> UTF-8 Support Enabled
DEBUG - 2011-05-05 11:07:18 --> URI Class Initialized
DEBUG - 2011-05-05 11:07:18 --> Router Class Initialized
DEBUG - 2011-05-05 11:07:18 --> Output Class Initialized
DEBUG - 2011-05-05 11:07:18 --> Input Class Initialized
DEBUG - 2011-05-05 11:07:18 --> Global POST and COOKIE data sanitized
DEBUG - 2011-05-05 11:07:18 --> Language Class Initialized
DEBUG - 2011-05-05 11:07:18 --> Loader Class Initialized
DEBUG - 2011-05-05 11:07:18 --> Controller Class Initialized
DEBUG - 2011-05-05 11:07:18 --> Model Class Initialized
DEBUG - 2011-05-05 11:07:18 --> Model Class Initialized
DEBUG - 2011-05-05 11:07:18 --> Model Class Initialized
DEBUG - 2011-05-05 11:07:18 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-05-05 11:07:18 --> Database Driver Class Initialized
DEBUG - 2011-05-05 11:07:19 --> File loaded: application/views/table/main.php
DEBUG - 2011-05-05 11:07:19 --> Helper loaded: url_helper
DEBUG - 2011-05-05 11:07:19 --> File loaded: application/views/common/header.php
DEBUG - 2011-05-05 11:07:19 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-05-05 11:07:19 --> File loaded: application/views/common/footer.php
DEBUG - 2011-05-05 11:07:19 --> File loaded: application/views/layout/main.php
DEBUG - 2011-05-05 11:07:19 --> Final output sent to browser
DEBUG - 2011-05-05 11:07:19 --> Total execution time: 0.5161
DEBUG - 2011-05-05 11:07:19 --> Config Class Initialized
DEBUG - 2011-05-05 11:07:19 --> Hooks Class Initialized
DEBUG - 2011-05-05 11:07:19 --> Utf8 Class Initialized
DEBUG - 2011-05-05 11:07:19 --> UTF-8 Support Enabled
DEBUG - 2011-05-05 11:07:19 --> URI Class Initialized
DEBUG - 2011-05-05 11:07:19 --> Router Class Initialized
DEBUG - 2011-05-05 11:07:19 --> Output Class Initialized
DEBUG - 2011-05-05 11:07:19 --> Input Class Initialized
DEBUG - 2011-05-05 11:07:19 --> Global POST and COOKIE data sanitized
DEBUG - 2011-05-05 11:07:19 --> Language Class Initialized
DEBUG - 2011-05-05 11:07:19 --> Loader Class Initialized
DEBUG - 2011-05-05 11:07:19 --> Controller Class Initialized
DEBUG - 2011-05-05 11:07:19 --> Model Class Initialized
DEBUG - 2011-05-05 11:07:19 --> Model Class Initialized
DEBUG - 2011-05-05 11:07:19 --> Model Class Initialized
DEBUG - 2011-05-05 11:07:19 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-05-05 11:07:19 --> Database Driver Class Initialized
DEBUG - 2011-05-05 11:07:19 --> File loaded: application/views/table/main.php
DEBUG - 2011-05-05 11:07:19 --> Helper loaded: url_helper
DEBUG - 2011-05-05 11:07:19 --> File loaded: application/views/common/header.php
DEBUG - 2011-05-05 11:07:19 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-05-05 11:07:19 --> File loaded: application/views/common/footer.php
DEBUG - 2011-05-05 11:07:19 --> File loaded: application/views/layout/main.php
DEBUG - 2011-05-05 11:07:19 --> Final output sent to browser
DEBUG - 2011-05-05 11:07:19 --> Total execution time: 0.0884
DEBUG - 2011-05-05 11:07:20 --> Config Class Initialized
DEBUG - 2011-05-05 11:07:20 --> Hooks Class Initialized
DEBUG - 2011-05-05 11:07:20 --> Utf8 Class Initialized
DEBUG - 2011-05-05 11:07:20 --> UTF-8 Support Enabled
DEBUG - 2011-05-05 11:07:20 --> URI Class Initialized
DEBUG - 2011-05-05 11:07:20 --> Router Class Initialized
ERROR - 2011-05-05 11:07:20 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-05-05 11:07:31 --> Config Class Initialized
DEBUG - 2011-05-05 11:07:31 --> Hooks Class Initialized
DEBUG - 2011-05-05 11:07:31 --> Utf8 Class Initialized
DEBUG - 2011-05-05 11:07:31 --> UTF-8 Support Enabled
DEBUG - 2011-05-05 11:07:31 --> URI Class Initialized
DEBUG - 2011-05-05 11:07:31 --> Router Class Initialized
DEBUG - 2011-05-05 11:07:31 --> Output Class Initialized
DEBUG - 2011-05-05 11:07:31 --> Input Class Initialized
DEBUG - 2011-05-05 11:07:31 --> Global POST and COOKIE data sanitized
DEBUG - 2011-05-05 11:07:31 --> Language Class Initialized
DEBUG - 2011-05-05 11:07:31 --> Loader Class Initialized
DEBUG - 2011-05-05 11:07:31 --> Controller Class Initialized
DEBUG - 2011-05-05 11:07:31 --> Model Class Initialized
DEBUG - 2011-05-05 11:07:31 --> Model Class Initialized
DEBUG - 2011-05-05 11:07:31 --> Model Class Initialized
DEBUG - 2011-05-05 11:07:31 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-05-05 11:07:31 --> Database Driver Class Initialized
DEBUG - 2011-05-05 11:07:33 --> File loaded: application/views/table/main.php
DEBUG - 2011-05-05 11:07:33 --> Helper loaded: url_helper
DEBUG - 2011-05-05 11:07:33 --> File loaded: application/views/common/header.php
DEBUG - 2011-05-05 11:07:33 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-05-05 11:07:33 --> File loaded: application/views/common/footer.php
DEBUG - 2011-05-05 11:07:33 --> File loaded: application/views/layout/main.php
DEBUG - 2011-05-05 11:07:33 --> Final output sent to browser
DEBUG - 2011-05-05 11:07:33 --> Total execution time: 1.7098
DEBUG - 2011-05-05 11:07:34 --> Config Class Initialized
DEBUG - 2011-05-05 11:07:34 --> Hooks Class Initialized
DEBUG - 2011-05-05 11:07:34 --> Utf8 Class Initialized
DEBUG - 2011-05-05 11:07:34 --> UTF-8 Support Enabled
DEBUG - 2011-05-05 11:07:34 --> URI Class Initialized
DEBUG - 2011-05-05 11:07:34 --> Router Class Initialized
ERROR - 2011-05-05 11:07:34 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-05-05 11:07:36 --> Config Class Initialized
DEBUG - 2011-05-05 11:07:36 --> Hooks Class Initialized
DEBUG - 2011-05-05 11:07:36 --> Utf8 Class Initialized
DEBUG - 2011-05-05 11:07:36 --> UTF-8 Support Enabled
DEBUG - 2011-05-05 11:07:36 --> URI Class Initialized
DEBUG - 2011-05-05 11:07:36 --> Router Class Initialized
DEBUG - 2011-05-05 11:07:36 --> Output Class Initialized
DEBUG - 2011-05-05 11:07:36 --> Input Class Initialized
DEBUG - 2011-05-05 11:07:36 --> Global POST and COOKIE data sanitized
DEBUG - 2011-05-05 11:07:36 --> Language Class Initialized
DEBUG - 2011-05-05 11:07:36 --> Loader Class Initialized
DEBUG - 2011-05-05 11:07:36 --> Controller Class Initialized
DEBUG - 2011-05-05 11:07:36 --> Model Class Initialized
DEBUG - 2011-05-05 11:07:36 --> Model Class Initialized
DEBUG - 2011-05-05 11:07:36 --> Model Class Initialized
DEBUG - 2011-05-05 11:07:36 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-05-05 11:07:36 --> Database Driver Class Initialized
DEBUG - 2011-05-05 11:07:36 --> File loaded: application/views/table/main.php
DEBUG - 2011-05-05 11:07:36 --> Helper loaded: url_helper
DEBUG - 2011-05-05 11:07:36 --> File loaded: application/views/common/header.php
DEBUG - 2011-05-05 11:07:36 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-05-05 11:07:36 --> File loaded: application/views/common/footer.php
DEBUG - 2011-05-05 11:07:36 --> File loaded: application/views/layout/main.php
DEBUG - 2011-05-05 11:07:36 --> Final output sent to browser
DEBUG - 2011-05-05 11:07:36 --> Total execution time: 0.0758
DEBUG - 2011-05-05 11:07:54 --> Config Class Initialized
DEBUG - 2011-05-05 11:07:54 --> Hooks Class Initialized
DEBUG - 2011-05-05 11:07:54 --> Utf8 Class Initialized
DEBUG - 2011-05-05 11:07:54 --> UTF-8 Support Enabled
DEBUG - 2011-05-05 11:07:54 --> URI Class Initialized
DEBUG - 2011-05-05 11:07:54 --> Router Class Initialized
DEBUG - 2011-05-05 11:07:54 --> Output Class Initialized
DEBUG - 2011-05-05 11:07:54 --> Input Class Initialized
DEBUG - 2011-05-05 11:07:54 --> Global POST and COOKIE data sanitized
DEBUG - 2011-05-05 11:07:54 --> Language Class Initialized
DEBUG - 2011-05-05 11:07:54 --> Loader Class Initialized
DEBUG - 2011-05-05 11:07:54 --> Controller Class Initialized
DEBUG - 2011-05-05 11:07:54 --> Model Class Initialized
DEBUG - 2011-05-05 11:07:54 --> Model Class Initialized
DEBUG - 2011-05-05 11:07:54 --> Model Class Initialized
DEBUG - 2011-05-05 11:07:54 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-05-05 11:07:54 --> Database Driver Class Initialized
DEBUG - 2011-05-05 11:07:54 --> File loaded: application/views/table/main.php
DEBUG - 2011-05-05 11:07:54 --> Helper loaded: url_helper
DEBUG - 2011-05-05 11:07:54 --> File loaded: application/views/common/header.php
DEBUG - 2011-05-05 11:07:54 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-05-05 11:07:54 --> File loaded: application/views/common/footer.php
DEBUG - 2011-05-05 11:07:54 --> File loaded: application/views/layout/main.php
DEBUG - 2011-05-05 11:07:54 --> Final output sent to browser
DEBUG - 2011-05-05 11:07:54 --> Total execution time: 0.2262
DEBUG - 2011-05-05 11:07:55 --> Config Class Initialized
DEBUG - 2011-05-05 11:07:55 --> Hooks Class Initialized
DEBUG - 2011-05-05 11:07:55 --> Utf8 Class Initialized
DEBUG - 2011-05-05 11:07:55 --> UTF-8 Support Enabled
DEBUG - 2011-05-05 11:07:55 --> URI Class Initialized
DEBUG - 2011-05-05 11:07:55 --> Router Class Initialized
ERROR - 2011-05-05 11:07:55 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-05-05 11:08:02 --> Config Class Initialized
DEBUG - 2011-05-05 11:08:02 --> Hooks Class Initialized
DEBUG - 2011-05-05 11:08:02 --> Utf8 Class Initialized
DEBUG - 2011-05-05 11:08:02 --> UTF-8 Support Enabled
DEBUG - 2011-05-05 11:08:02 --> URI Class Initialized
DEBUG - 2011-05-05 11:08:02 --> Router Class Initialized
DEBUG - 2011-05-05 11:08:02 --> Output Class Initialized
DEBUG - 2011-05-05 11:08:02 --> Input Class Initialized
DEBUG - 2011-05-05 11:08:02 --> Global POST and COOKIE data sanitized
DEBUG - 2011-05-05 11:08:02 --> Language Class Initialized
DEBUG - 2011-05-05 11:08:02 --> Loader Class Initialized
DEBUG - 2011-05-05 11:08:02 --> Controller Class Initialized
DEBUG - 2011-05-05 11:08:02 --> Model Class Initialized
DEBUG - 2011-05-05 11:08:02 --> Model Class Initialized
DEBUG - 2011-05-05 11:08:02 --> Model Class Initialized
DEBUG - 2011-05-05 11:08:02 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-05-05 11:08:02 --> Database Driver Class Initialized
DEBUG - 2011-05-05 11:08:02 --> File loaded: application/views/table/main.php
DEBUG - 2011-05-05 11:08:02 --> Helper loaded: url_helper
DEBUG - 2011-05-05 11:08:02 --> File loaded: application/views/common/header.php
DEBUG - 2011-05-05 11:08:02 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-05-05 11:08:02 --> File loaded: application/views/common/footer.php
DEBUG - 2011-05-05 11:08:02 --> File loaded: application/views/layout/main.php
DEBUG - 2011-05-05 11:08:02 --> Final output sent to browser
DEBUG - 2011-05-05 11:08:02 --> Total execution time: 0.6841
DEBUG - 2011-05-05 11:08:03 --> Config Class Initialized
DEBUG - 2011-05-05 11:08:03 --> Hooks Class Initialized
DEBUG - 2011-05-05 11:08:03 --> Utf8 Class Initialized
DEBUG - 2011-05-05 11:08:03 --> UTF-8 Support Enabled
DEBUG - 2011-05-05 11:08:03 --> URI Class Initialized
DEBUG - 2011-05-05 11:08:03 --> Router Class Initialized
ERROR - 2011-05-05 11:08:03 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-05-05 11:08:07 --> Config Class Initialized
DEBUG - 2011-05-05 11:08:07 --> Hooks Class Initialized
DEBUG - 2011-05-05 11:08:07 --> Utf8 Class Initialized
DEBUG - 2011-05-05 11:08:07 --> UTF-8 Support Enabled
DEBUG - 2011-05-05 11:08:07 --> URI Class Initialized
DEBUG - 2011-05-05 11:08:07 --> Router Class Initialized
DEBUG - 2011-05-05 11:08:07 --> Output Class Initialized
DEBUG - 2011-05-05 11:08:07 --> Input Class Initialized
DEBUG - 2011-05-05 11:08:07 --> Global POST and COOKIE data sanitized
DEBUG - 2011-05-05 11:08:07 --> Language Class Initialized
DEBUG - 2011-05-05 11:08:07 --> Loader Class Initialized
DEBUG - 2011-05-05 11:08:07 --> Controller Class Initialized
DEBUG - 2011-05-05 11:08:07 --> Model Class Initialized
DEBUG - 2011-05-05 11:08:07 --> Model Class Initialized
DEBUG - 2011-05-05 11:08:07 --> Model Class Initialized
DEBUG - 2011-05-05 11:08:07 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-05-05 11:08:07 --> Database Driver Class Initialized
DEBUG - 2011-05-05 11:08:07 --> File loaded: application/views/table/main.php
DEBUG - 2011-05-05 11:08:07 --> Helper loaded: url_helper
DEBUG - 2011-05-05 11:08:07 --> File loaded: application/views/common/header.php
DEBUG - 2011-05-05 11:08:07 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-05-05 11:08:07 --> File loaded: application/views/common/footer.php
DEBUG - 2011-05-05 11:08:07 --> File loaded: application/views/layout/main.php
DEBUG - 2011-05-05 11:08:07 --> Final output sent to browser
DEBUG - 2011-05-05 11:08:07 --> Total execution time: 0.4579
DEBUG - 2011-05-05 11:08:08 --> Config Class Initialized
DEBUG - 2011-05-05 11:08:08 --> Hooks Class Initialized
DEBUG - 2011-05-05 11:08:08 --> Utf8 Class Initialized
DEBUG - 2011-05-05 11:08:08 --> UTF-8 Support Enabled
DEBUG - 2011-05-05 11:08:08 --> URI Class Initialized
DEBUG - 2011-05-05 11:08:08 --> Router Class Initialized
ERROR - 2011-05-05 11:08:08 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-05-05 11:08:12 --> Config Class Initialized
DEBUG - 2011-05-05 11:08:12 --> Hooks Class Initialized
DEBUG - 2011-05-05 11:08:12 --> Utf8 Class Initialized
DEBUG - 2011-05-05 11:08:12 --> UTF-8 Support Enabled
DEBUG - 2011-05-05 11:08:12 --> URI Class Initialized
DEBUG - 2011-05-05 11:08:12 --> Router Class Initialized
DEBUG - 2011-05-05 11:08:12 --> Output Class Initialized
DEBUG - 2011-05-05 11:08:12 --> Input Class Initialized
DEBUG - 2011-05-05 11:08:12 --> Global POST and COOKIE data sanitized
DEBUG - 2011-05-05 11:08:12 --> Language Class Initialized
DEBUG - 2011-05-05 11:08:12 --> Loader Class Initialized
DEBUG - 2011-05-05 11:08:12 --> Controller Class Initialized
DEBUG - 2011-05-05 11:08:12 --> Model Class Initialized
DEBUG - 2011-05-05 11:08:12 --> Model Class Initialized
DEBUG - 2011-05-05 11:08:12 --> Model Class Initialized
DEBUG - 2011-05-05 11:08:12 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-05-05 11:08:12 --> Database Driver Class Initialized
DEBUG - 2011-05-05 11:08:13 --> File loaded: application/views/table/main.php
DEBUG - 2011-05-05 11:08:13 --> Helper loaded: url_helper
DEBUG - 2011-05-05 11:08:13 --> File loaded: application/views/common/header.php
DEBUG - 2011-05-05 11:08:13 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-05-05 11:08:13 --> File loaded: application/views/common/footer.php
DEBUG - 2011-05-05 11:08:13 --> File loaded: application/views/layout/main.php
DEBUG - 2011-05-05 11:08:13 --> Final output sent to browser
DEBUG - 2011-05-05 11:08:13 --> Total execution time: 0.8384
DEBUG - 2011-05-05 11:08:14 --> Config Class Initialized
DEBUG - 2011-05-05 11:08:14 --> Hooks Class Initialized
DEBUG - 2011-05-05 11:08:14 --> Utf8 Class Initialized
DEBUG - 2011-05-05 11:08:14 --> UTF-8 Support Enabled
DEBUG - 2011-05-05 11:08:14 --> URI Class Initialized
DEBUG - 2011-05-05 11:08:14 --> Router Class Initialized
ERROR - 2011-05-05 11:08:14 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-05-05 11:08:18 --> Config Class Initialized
DEBUG - 2011-05-05 11:08:18 --> Hooks Class Initialized
DEBUG - 2011-05-05 11:08:18 --> Utf8 Class Initialized
DEBUG - 2011-05-05 11:08:18 --> UTF-8 Support Enabled
DEBUG - 2011-05-05 11:08:18 --> URI Class Initialized
DEBUG - 2011-05-05 11:08:18 --> Router Class Initialized
DEBUG - 2011-05-05 11:08:18 --> Output Class Initialized
DEBUG - 2011-05-05 11:08:18 --> Input Class Initialized
DEBUG - 2011-05-05 11:08:18 --> Global POST and COOKIE data sanitized
DEBUG - 2011-05-05 11:08:18 --> Language Class Initialized
DEBUG - 2011-05-05 11:08:18 --> Loader Class Initialized
DEBUG - 2011-05-05 11:08:18 --> Controller Class Initialized
DEBUG - 2011-05-05 11:08:18 --> Model Class Initialized
DEBUG - 2011-05-05 11:08:18 --> Model Class Initialized
DEBUG - 2011-05-05 11:08:18 --> Model Class Initialized
DEBUG - 2011-05-05 11:08:18 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-05-05 11:08:18 --> Database Driver Class Initialized
DEBUG - 2011-05-05 11:08:19 --> File loaded: application/views/table/main.php
DEBUG - 2011-05-05 11:08:19 --> Helper loaded: url_helper
DEBUG - 2011-05-05 11:08:19 --> File loaded: application/views/common/header.php
DEBUG - 2011-05-05 11:08:19 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-05-05 11:08:19 --> File loaded: application/views/common/footer.php
DEBUG - 2011-05-05 11:08:19 --> File loaded: application/views/layout/main.php
DEBUG - 2011-05-05 11:08:19 --> Final output sent to browser
DEBUG - 2011-05-05 11:08:19 --> Total execution time: 0.2524
DEBUG - 2011-05-05 11:08:20 --> Config Class Initialized
DEBUG - 2011-05-05 11:08:20 --> Hooks Class Initialized
DEBUG - 2011-05-05 11:08:20 --> Utf8 Class Initialized
DEBUG - 2011-05-05 11:08:20 --> UTF-8 Support Enabled
DEBUG - 2011-05-05 11:08:20 --> URI Class Initialized
DEBUG - 2011-05-05 11:08:20 --> Router Class Initialized
ERROR - 2011-05-05 11:08:20 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-05-05 11:08:23 --> Config Class Initialized
DEBUG - 2011-05-05 11:08:23 --> Hooks Class Initialized
DEBUG - 2011-05-05 11:08:23 --> Utf8 Class Initialized
DEBUG - 2011-05-05 11:08:23 --> UTF-8 Support Enabled
DEBUG - 2011-05-05 11:08:23 --> URI Class Initialized
DEBUG - 2011-05-05 11:08:23 --> Router Class Initialized
DEBUG - 2011-05-05 11:08:23 --> Output Class Initialized
DEBUG - 2011-05-05 11:08:23 --> Input Class Initialized
DEBUG - 2011-05-05 11:08:23 --> Global POST and COOKIE data sanitized
DEBUG - 2011-05-05 11:08:23 --> Language Class Initialized
DEBUG - 2011-05-05 11:08:23 --> Loader Class Initialized
DEBUG - 2011-05-05 11:08:23 --> Controller Class Initialized
DEBUG - 2011-05-05 11:08:23 --> Model Class Initialized
DEBUG - 2011-05-05 11:08:23 --> Model Class Initialized
DEBUG - 2011-05-05 11:08:23 --> Model Class Initialized
DEBUG - 2011-05-05 11:08:23 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-05-05 11:08:23 --> Database Driver Class Initialized
DEBUG - 2011-05-05 11:08:23 --> File loaded: application/views/table/main.php
DEBUG - 2011-05-05 11:08:23 --> Helper loaded: url_helper
DEBUG - 2011-05-05 11:08:23 --> File loaded: application/views/common/header.php
DEBUG - 2011-05-05 11:08:23 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-05-05 11:08:23 --> File loaded: application/views/common/footer.php
DEBUG - 2011-05-05 11:08:23 --> File loaded: application/views/layout/main.php
DEBUG - 2011-05-05 11:08:23 --> Final output sent to browser
DEBUG - 2011-05-05 11:08:23 --> Total execution time: 0.6165
DEBUG - 2011-05-05 11:08:25 --> Config Class Initialized
DEBUG - 2011-05-05 11:08:25 --> Hooks Class Initialized
DEBUG - 2011-05-05 11:08:25 --> Utf8 Class Initialized
DEBUG - 2011-05-05 11:08:25 --> UTF-8 Support Enabled
DEBUG - 2011-05-05 11:08:25 --> URI Class Initialized
DEBUG - 2011-05-05 11:08:25 --> Router Class Initialized
ERROR - 2011-05-05 11:08:25 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-05-05 11:08:27 --> Config Class Initialized
DEBUG - 2011-05-05 11:08:27 --> Hooks Class Initialized
DEBUG - 2011-05-05 11:08:27 --> Utf8 Class Initialized
DEBUG - 2011-05-05 11:08:27 --> UTF-8 Support Enabled
DEBUG - 2011-05-05 11:08:27 --> URI Class Initialized
DEBUG - 2011-05-05 11:08:27 --> Router Class Initialized
DEBUG - 2011-05-05 11:08:27 --> Output Class Initialized
DEBUG - 2011-05-05 11:08:27 --> Input Class Initialized
DEBUG - 2011-05-05 11:08:27 --> Global POST and COOKIE data sanitized
DEBUG - 2011-05-05 11:08:27 --> Language Class Initialized
DEBUG - 2011-05-05 11:08:27 --> Loader Class Initialized
DEBUG - 2011-05-05 11:08:27 --> Controller Class Initialized
DEBUG - 2011-05-05 11:08:27 --> Model Class Initialized
DEBUG - 2011-05-05 11:08:27 --> Model Class Initialized
DEBUG - 2011-05-05 11:08:27 --> Model Class Initialized
DEBUG - 2011-05-05 11:08:27 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-05-05 11:08:27 --> Database Driver Class Initialized
DEBUG - 2011-05-05 11:08:27 --> File loaded: application/views/table/main.php
DEBUG - 2011-05-05 11:08:27 --> Helper loaded: url_helper
DEBUG - 2011-05-05 11:08:27 --> File loaded: application/views/common/header.php
DEBUG - 2011-05-05 11:08:27 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-05-05 11:08:27 --> File loaded: application/views/common/footer.php
DEBUG - 2011-05-05 11:08:27 --> File loaded: application/views/layout/main.php
DEBUG - 2011-05-05 11:08:27 --> Final output sent to browser
DEBUG - 2011-05-05 11:08:27 --> Total execution time: 0.5092
DEBUG - 2011-05-05 11:08:28 --> Config Class Initialized
DEBUG - 2011-05-05 11:08:28 --> Hooks Class Initialized
DEBUG - 2011-05-05 11:08:28 --> Utf8 Class Initialized
DEBUG - 2011-05-05 11:08:28 --> UTF-8 Support Enabled
DEBUG - 2011-05-05 11:08:28 --> URI Class Initialized
DEBUG - 2011-05-05 11:08:28 --> Router Class Initialized
ERROR - 2011-05-05 11:08:28 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-05-05 11:08:30 --> Config Class Initialized
DEBUG - 2011-05-05 11:08:30 --> Hooks Class Initialized
DEBUG - 2011-05-05 11:08:30 --> Utf8 Class Initialized
DEBUG - 2011-05-05 11:08:30 --> UTF-8 Support Enabled
DEBUG - 2011-05-05 11:08:30 --> URI Class Initialized
DEBUG - 2011-05-05 11:08:30 --> Router Class Initialized
DEBUG - 2011-05-05 11:08:30 --> Output Class Initialized
DEBUG - 2011-05-05 11:08:30 --> Input Class Initialized
DEBUG - 2011-05-05 11:08:30 --> Global POST and COOKIE data sanitized
DEBUG - 2011-05-05 11:08:30 --> Language Class Initialized
DEBUG - 2011-05-05 11:08:30 --> Loader Class Initialized
DEBUG - 2011-05-05 11:08:30 --> Controller Class Initialized
DEBUG - 2011-05-05 11:08:30 --> Model Class Initialized
DEBUG - 2011-05-05 11:08:30 --> Model Class Initialized
DEBUG - 2011-05-05 11:08:30 --> Model Class Initialized
DEBUG - 2011-05-05 11:08:30 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-05-05 11:08:30 --> Database Driver Class Initialized
DEBUG - 2011-05-05 11:08:31 --> File loaded: application/views/table/main.php
DEBUG - 2011-05-05 11:08:31 --> Helper loaded: url_helper
DEBUG - 2011-05-05 11:08:31 --> File loaded: application/views/common/header.php
DEBUG - 2011-05-05 11:08:31 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-05-05 11:08:31 --> File loaded: application/views/common/footer.php
DEBUG - 2011-05-05 11:08:31 --> File loaded: application/views/layout/main.php
DEBUG - 2011-05-05 11:08:31 --> Final output sent to browser
DEBUG - 2011-05-05 11:08:31 --> Total execution time: 0.0539
DEBUG - 2011-05-05 11:08:31 --> Config Class Initialized
DEBUG - 2011-05-05 11:08:31 --> Hooks Class Initialized
DEBUG - 2011-05-05 11:08:31 --> Utf8 Class Initialized
DEBUG - 2011-05-05 11:08:31 --> UTF-8 Support Enabled
DEBUG - 2011-05-05 11:08:31 --> URI Class Initialized
DEBUG - 2011-05-05 11:08:31 --> Router Class Initialized
ERROR - 2011-05-05 11:08:31 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-05-05 11:08:34 --> Config Class Initialized
DEBUG - 2011-05-05 11:08:34 --> Hooks Class Initialized
DEBUG - 2011-05-05 11:08:34 --> Utf8 Class Initialized
DEBUG - 2011-05-05 11:08:34 --> UTF-8 Support Enabled
DEBUG - 2011-05-05 11:08:34 --> URI Class Initialized
DEBUG - 2011-05-05 11:08:34 --> Router Class Initialized
DEBUG - 2011-05-05 11:08:34 --> Output Class Initialized
DEBUG - 2011-05-05 11:08:34 --> Input Class Initialized
DEBUG - 2011-05-05 11:08:34 --> Global POST and COOKIE data sanitized
DEBUG - 2011-05-05 11:08:34 --> Language Class Initialized
DEBUG - 2011-05-05 11:08:34 --> Loader Class Initialized
DEBUG - 2011-05-05 11:08:34 --> Controller Class Initialized
DEBUG - 2011-05-05 11:08:34 --> Model Class Initialized
DEBUG - 2011-05-05 11:08:34 --> Model Class Initialized
DEBUG - 2011-05-05 11:08:34 --> Model Class Initialized
DEBUG - 2011-05-05 11:08:34 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-05-05 11:08:34 --> Database Driver Class Initialized
DEBUG - 2011-05-05 11:08:34 --> File loaded: application/views/table/main.php
DEBUG - 2011-05-05 11:08:34 --> Helper loaded: url_helper
DEBUG - 2011-05-05 11:08:34 --> File loaded: application/views/common/header.php
DEBUG - 2011-05-05 11:08:34 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-05-05 11:08:34 --> File loaded: application/views/common/footer.php
DEBUG - 2011-05-05 11:08:34 --> File loaded: application/views/layout/main.php
DEBUG - 2011-05-05 11:08:34 --> Final output sent to browser
DEBUG - 2011-05-05 11:08:34 --> Total execution time: 0.2175
DEBUG - 2011-05-05 11:08:35 --> Config Class Initialized
DEBUG - 2011-05-05 11:08:35 --> Hooks Class Initialized
DEBUG - 2011-05-05 11:08:35 --> Utf8 Class Initialized
DEBUG - 2011-05-05 11:08:35 --> UTF-8 Support Enabled
DEBUG - 2011-05-05 11:08:35 --> URI Class Initialized
DEBUG - 2011-05-05 11:08:35 --> Config Class Initialized
DEBUG - 2011-05-05 11:08:35 --> Hooks Class Initialized
DEBUG - 2011-05-05 11:08:35 --> Router Class Initialized
DEBUG - 2011-05-05 11:08:35 --> Utf8 Class Initialized
DEBUG - 2011-05-05 11:08:35 --> UTF-8 Support Enabled
ERROR - 2011-05-05 11:08:35 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-05-05 11:08:35 --> URI Class Initialized
DEBUG - 2011-05-05 11:08:35 --> Router Class Initialized
DEBUG - 2011-05-05 11:08:35 --> Output Class Initialized
DEBUG - 2011-05-05 11:08:35 --> Input Class Initialized
DEBUG - 2011-05-05 11:08:35 --> Global POST and COOKIE data sanitized
DEBUG - 2011-05-05 11:08:35 --> Language Class Initialized
DEBUG - 2011-05-05 11:08:35 --> Loader Class Initialized
DEBUG - 2011-05-05 11:08:35 --> Controller Class Initialized
DEBUG - 2011-05-05 11:08:35 --> Model Class Initialized
DEBUG - 2011-05-05 11:08:35 --> Model Class Initialized
DEBUG - 2011-05-05 11:08:35 --> Model Class Initialized
DEBUG - 2011-05-05 11:08:35 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-05-05 11:08:35 --> Database Driver Class Initialized
DEBUG - 2011-05-05 11:08:35 --> File loaded: application/views/table/main.php
DEBUG - 2011-05-05 11:08:35 --> Helper loaded: url_helper
DEBUG - 2011-05-05 11:08:35 --> File loaded: application/views/common/header.php
DEBUG - 2011-05-05 11:08:35 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-05-05 11:08:35 --> File loaded: application/views/common/footer.php
DEBUG - 2011-05-05 11:08:35 --> File loaded: application/views/layout/main.php
DEBUG - 2011-05-05 11:08:35 --> Final output sent to browser
DEBUG - 2011-05-05 11:08:35 --> Total execution time: 0.0442
DEBUG - 2011-05-05 11:08:47 --> Config Class Initialized
DEBUG - 2011-05-05 11:08:47 --> Hooks Class Initialized
DEBUG - 2011-05-05 11:08:47 --> Utf8 Class Initialized
DEBUG - 2011-05-05 11:08:47 --> UTF-8 Support Enabled
DEBUG - 2011-05-05 11:08:47 --> URI Class Initialized
DEBUG - 2011-05-05 11:08:47 --> Router Class Initialized
DEBUG - 2011-05-05 11:08:47 --> Output Class Initialized
DEBUG - 2011-05-05 11:08:47 --> Input Class Initialized
DEBUG - 2011-05-05 11:08:47 --> Global POST and COOKIE data sanitized
DEBUG - 2011-05-05 11:08:47 --> Language Class Initialized
DEBUG - 2011-05-05 11:08:47 --> Loader Class Initialized
DEBUG - 2011-05-05 11:08:47 --> Controller Class Initialized
DEBUG - 2011-05-05 11:08:47 --> Model Class Initialized
DEBUG - 2011-05-05 11:08:47 --> Model Class Initialized
DEBUG - 2011-05-05 11:08:47 --> Model Class Initialized
DEBUG - 2011-05-05 11:08:47 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-05-05 11:08:47 --> Database Driver Class Initialized
DEBUG - 2011-05-05 11:08:47 --> File loaded: application/views/table/main.php
DEBUG - 2011-05-05 11:08:47 --> Helper loaded: url_helper
DEBUG - 2011-05-05 11:08:47 --> File loaded: application/views/common/header.php
DEBUG - 2011-05-05 11:08:47 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-05-05 11:08:47 --> File loaded: application/views/common/footer.php
DEBUG - 2011-05-05 11:08:47 --> File loaded: application/views/layout/main.php
DEBUG - 2011-05-05 11:08:47 --> Final output sent to browser
DEBUG - 2011-05-05 11:08:47 --> Total execution time: 0.0496
DEBUG - 2011-05-05 11:08:48 --> Config Class Initialized
DEBUG - 2011-05-05 11:08:48 --> Hooks Class Initialized
DEBUG - 2011-05-05 11:08:48 --> Utf8 Class Initialized
DEBUG - 2011-05-05 11:08:48 --> UTF-8 Support Enabled
DEBUG - 2011-05-05 11:08:48 --> URI Class Initialized
DEBUG - 2011-05-05 11:08:48 --> Router Class Initialized
DEBUG - 2011-05-05 11:08:48 --> Output Class Initialized
DEBUG - 2011-05-05 11:08:48 --> Input Class Initialized
DEBUG - 2011-05-05 11:08:48 --> Global POST and COOKIE data sanitized
DEBUG - 2011-05-05 11:08:48 --> Language Class Initialized
DEBUG - 2011-05-05 11:08:48 --> Loader Class Initialized
DEBUG - 2011-05-05 11:08:48 --> Controller Class Initialized
DEBUG - 2011-05-05 11:08:48 --> Model Class Initialized
DEBUG - 2011-05-05 11:08:48 --> Model Class Initialized
DEBUG - 2011-05-05 11:08:48 --> Model Class Initialized
DEBUG - 2011-05-05 11:08:48 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-05-05 11:08:48 --> Database Driver Class Initialized
DEBUG - 2011-05-05 11:08:48 --> File loaded: application/views/table/main.php
DEBUG - 2011-05-05 11:08:48 --> Helper loaded: url_helper
DEBUG - 2011-05-05 11:08:48 --> File loaded: application/views/common/header.php
DEBUG - 2011-05-05 11:08:48 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-05-05 11:08:48 --> File loaded: application/views/common/footer.php
DEBUG - 2011-05-05 11:08:48 --> File loaded: application/views/layout/main.php
DEBUG - 2011-05-05 11:08:48 --> Final output sent to browser
DEBUG - 2011-05-05 11:08:48 --> Total execution time: 0.0466
DEBUG - 2011-05-05 11:08:50 --> Config Class Initialized
DEBUG - 2011-05-05 11:08:50 --> Hooks Class Initialized
DEBUG - 2011-05-05 11:08:50 --> Utf8 Class Initialized
DEBUG - 2011-05-05 11:08:50 --> UTF-8 Support Enabled
DEBUG - 2011-05-05 11:08:50 --> URI Class Initialized
DEBUG - 2011-05-05 11:08:50 --> Router Class Initialized
DEBUG - 2011-05-05 11:08:50 --> Output Class Initialized
DEBUG - 2011-05-05 11:08:50 --> Input Class Initialized
DEBUG - 2011-05-05 11:08:50 --> Global POST and COOKIE data sanitized
DEBUG - 2011-05-05 11:08:50 --> Language Class Initialized
DEBUG - 2011-05-05 11:08:50 --> Loader Class Initialized
DEBUG - 2011-05-05 11:08:50 --> Controller Class Initialized
DEBUG - 2011-05-05 11:08:50 --> Model Class Initialized
DEBUG - 2011-05-05 11:08:50 --> Model Class Initialized
DEBUG - 2011-05-05 11:08:50 --> Model Class Initialized
DEBUG - 2011-05-05 11:08:50 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-05-05 11:08:50 --> Database Driver Class Initialized
DEBUG - 2011-05-05 11:08:50 --> File loaded: application/views/table/main.php
DEBUG - 2011-05-05 11:08:50 --> Helper loaded: url_helper
DEBUG - 2011-05-05 11:08:50 --> File loaded: application/views/common/header.php
DEBUG - 2011-05-05 11:08:50 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-05-05 11:08:50 --> File loaded: application/views/common/footer.php
DEBUG - 2011-05-05 11:08:50 --> File loaded: application/views/layout/main.php
DEBUG - 2011-05-05 11:08:50 --> Final output sent to browser
DEBUG - 2011-05-05 11:08:50 --> Total execution time: 0.0471
DEBUG - 2011-05-05 11:08:52 --> Config Class Initialized
DEBUG - 2011-05-05 11:08:52 --> Hooks Class Initialized
DEBUG - 2011-05-05 11:08:52 --> Utf8 Class Initialized
DEBUG - 2011-05-05 11:08:52 --> UTF-8 Support Enabled
DEBUG - 2011-05-05 11:08:52 --> URI Class Initialized
DEBUG - 2011-05-05 11:08:52 --> Router Class Initialized
DEBUG - 2011-05-05 11:08:52 --> Output Class Initialized
DEBUG - 2011-05-05 11:08:52 --> Input Class Initialized
DEBUG - 2011-05-05 11:08:52 --> Global POST and COOKIE data sanitized
DEBUG - 2011-05-05 11:08:52 --> Language Class Initialized
DEBUG - 2011-05-05 11:08:52 --> Loader Class Initialized
DEBUG - 2011-05-05 11:08:52 --> Controller Class Initialized
DEBUG - 2011-05-05 11:08:52 --> Model Class Initialized
DEBUG - 2011-05-05 11:08:52 --> Model Class Initialized
DEBUG - 2011-05-05 11:08:52 --> Model Class Initialized
DEBUG - 2011-05-05 11:08:52 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-05-05 11:08:52 --> Database Driver Class Initialized
DEBUG - 2011-05-05 11:08:52 --> File loaded: application/views/table/main.php
DEBUG - 2011-05-05 11:08:52 --> Helper loaded: url_helper
DEBUG - 2011-05-05 11:08:52 --> File loaded: application/views/common/header.php
DEBUG - 2011-05-05 11:08:52 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-05-05 11:08:52 --> File loaded: application/views/common/footer.php
DEBUG - 2011-05-05 11:08:52 --> File loaded: application/views/layout/main.php
DEBUG - 2011-05-05 11:08:52 --> Final output sent to browser
DEBUG - 2011-05-05 11:08:52 --> Total execution time: 0.0586
DEBUG - 2011-05-05 11:08:53 --> Config Class Initialized
DEBUG - 2011-05-05 11:08:53 --> Hooks Class Initialized
DEBUG - 2011-05-05 11:08:53 --> Utf8 Class Initialized
DEBUG - 2011-05-05 11:08:53 --> UTF-8 Support Enabled
DEBUG - 2011-05-05 11:08:53 --> URI Class Initialized
DEBUG - 2011-05-05 11:08:53 --> Router Class Initialized
DEBUG - 2011-05-05 11:08:53 --> Output Class Initialized
DEBUG - 2011-05-05 11:08:53 --> Input Class Initialized
DEBUG - 2011-05-05 11:08:53 --> Global POST and COOKIE data sanitized
DEBUG - 2011-05-05 11:08:53 --> Language Class Initialized
DEBUG - 2011-05-05 11:08:53 --> Loader Class Initialized
DEBUG - 2011-05-05 11:08:53 --> Controller Class Initialized
DEBUG - 2011-05-05 11:08:53 --> Model Class Initialized
DEBUG - 2011-05-05 11:08:53 --> Model Class Initialized
DEBUG - 2011-05-05 11:08:53 --> Model Class Initialized
DEBUG - 2011-05-05 11:08:53 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-05-05 11:08:53 --> Database Driver Class Initialized
DEBUG - 2011-05-05 11:08:53 --> File loaded: application/views/table/main.php
DEBUG - 2011-05-05 11:08:53 --> Helper loaded: url_helper
DEBUG - 2011-05-05 11:08:53 --> File loaded: application/views/common/header.php
DEBUG - 2011-05-05 11:08:53 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-05-05 11:08:53 --> File loaded: application/views/common/footer.php
DEBUG - 2011-05-05 11:08:53 --> File loaded: application/views/layout/main.php
DEBUG - 2011-05-05 11:08:53 --> Final output sent to browser
DEBUG - 2011-05-05 11:08:53 --> Total execution time: 0.0548
DEBUG - 2011-05-05 11:08:54 --> Config Class Initialized
DEBUG - 2011-05-05 11:08:54 --> Hooks Class Initialized
DEBUG - 2011-05-05 11:08:54 --> Utf8 Class Initialized
DEBUG - 2011-05-05 11:08:54 --> UTF-8 Support Enabled
DEBUG - 2011-05-05 11:08:54 --> URI Class Initialized
DEBUG - 2011-05-05 11:08:54 --> Router Class Initialized
DEBUG - 2011-05-05 11:08:54 --> Output Class Initialized
DEBUG - 2011-05-05 11:08:54 --> Input Class Initialized
DEBUG - 2011-05-05 11:08:54 --> Global POST and COOKIE data sanitized
DEBUG - 2011-05-05 11:08:54 --> Language Class Initialized
DEBUG - 2011-05-05 11:08:54 --> Loader Class Initialized
DEBUG - 2011-05-05 11:08:54 --> Controller Class Initialized
DEBUG - 2011-05-05 11:08:54 --> Model Class Initialized
DEBUG - 2011-05-05 11:08:54 --> Model Class Initialized
DEBUG - 2011-05-05 11:08:54 --> Model Class Initialized
DEBUG - 2011-05-05 11:08:54 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-05-05 11:08:54 --> Database Driver Class Initialized
DEBUG - 2011-05-05 11:08:54 --> File loaded: application/views/table/main.php
DEBUG - 2011-05-05 11:08:54 --> Helper loaded: url_helper
DEBUG - 2011-05-05 11:08:54 --> File loaded: application/views/common/header.php
DEBUG - 2011-05-05 11:08:54 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-05-05 11:08:54 --> File loaded: application/views/common/footer.php
DEBUG - 2011-05-05 11:08:54 --> File loaded: application/views/layout/main.php
DEBUG - 2011-05-05 11:08:54 --> Final output sent to browser
DEBUG - 2011-05-05 11:08:54 --> Total execution time: 0.0504
DEBUG - 2011-05-05 11:08:55 --> Config Class Initialized
DEBUG - 2011-05-05 11:08:55 --> Hooks Class Initialized
DEBUG - 2011-05-05 11:08:55 --> Utf8 Class Initialized
DEBUG - 2011-05-05 11:08:55 --> UTF-8 Support Enabled
DEBUG - 2011-05-05 11:08:55 --> URI Class Initialized
DEBUG - 2011-05-05 11:08:55 --> Router Class Initialized
ERROR - 2011-05-05 11:08:55 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-05-05 11:08:57 --> Config Class Initialized
DEBUG - 2011-05-05 11:08:57 --> Hooks Class Initialized
DEBUG - 2011-05-05 11:08:57 --> Utf8 Class Initialized
DEBUG - 2011-05-05 11:08:57 --> UTF-8 Support Enabled
DEBUG - 2011-05-05 11:08:57 --> URI Class Initialized
DEBUG - 2011-05-05 11:08:57 --> Router Class Initialized
DEBUG - 2011-05-05 11:08:57 --> Output Class Initialized
DEBUG - 2011-05-05 11:08:57 --> Input Class Initialized
DEBUG - 2011-05-05 11:08:57 --> Global POST and COOKIE data sanitized
DEBUG - 2011-05-05 11:08:57 --> Language Class Initialized
DEBUG - 2011-05-05 11:08:57 --> Loader Class Initialized
DEBUG - 2011-05-05 11:08:57 --> Controller Class Initialized
DEBUG - 2011-05-05 11:08:57 --> Model Class Initialized
DEBUG - 2011-05-05 11:08:57 --> Model Class Initialized
DEBUG - 2011-05-05 11:08:57 --> Model Class Initialized
DEBUG - 2011-05-05 11:08:57 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-05-05 11:08:57 --> Database Driver Class Initialized
DEBUG - 2011-05-05 11:08:57 --> File loaded: application/views/table/main.php
DEBUG - 2011-05-05 11:08:57 --> Helper loaded: url_helper
DEBUG - 2011-05-05 11:08:57 --> File loaded: application/views/common/header.php
DEBUG - 2011-05-05 11:08:57 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-05-05 11:08:57 --> File loaded: application/views/common/footer.php
DEBUG - 2011-05-05 11:08:57 --> File loaded: application/views/layout/main.php
DEBUG - 2011-05-05 11:08:57 --> Final output sent to browser
DEBUG - 2011-05-05 11:08:57 --> Total execution time: 0.0567
DEBUG - 2011-05-05 11:09:01 --> Config Class Initialized
DEBUG - 2011-05-05 11:09:01 --> Hooks Class Initialized
DEBUG - 2011-05-05 11:09:01 --> Utf8 Class Initialized
DEBUG - 2011-05-05 11:09:01 --> UTF-8 Support Enabled
DEBUG - 2011-05-05 11:09:01 --> URI Class Initialized
DEBUG - 2011-05-05 11:09:01 --> Router Class Initialized
DEBUG - 2011-05-05 11:09:01 --> Output Class Initialized
DEBUG - 2011-05-05 11:09:01 --> Input Class Initialized
DEBUG - 2011-05-05 11:09:01 --> Global POST and COOKIE data sanitized
DEBUG - 2011-05-05 11:09:01 --> Language Class Initialized
DEBUG - 2011-05-05 11:09:01 --> Loader Class Initialized
DEBUG - 2011-05-05 11:09:01 --> Controller Class Initialized
DEBUG - 2011-05-05 11:09:01 --> Model Class Initialized
DEBUG - 2011-05-05 11:09:01 --> Model Class Initialized
DEBUG - 2011-05-05 11:09:01 --> Model Class Initialized
DEBUG - 2011-05-05 11:09:01 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-05-05 11:09:01 --> Database Driver Class Initialized
DEBUG - 2011-05-05 11:09:01 --> File loaded: application/views/table/main.php
DEBUG - 2011-05-05 11:09:01 --> Helper loaded: url_helper
DEBUG - 2011-05-05 11:09:01 --> File loaded: application/views/common/header.php
DEBUG - 2011-05-05 11:09:01 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-05-05 11:09:01 --> File loaded: application/views/common/footer.php
DEBUG - 2011-05-05 11:09:01 --> File loaded: application/views/layout/main.php
DEBUG - 2011-05-05 11:09:01 --> Final output sent to browser
DEBUG - 2011-05-05 11:09:01 --> Total execution time: 0.0549
DEBUG - 2011-05-05 11:11:14 --> Config Class Initialized
DEBUG - 2011-05-05 11:11:14 --> Hooks Class Initialized
DEBUG - 2011-05-05 11:11:14 --> Utf8 Class Initialized
DEBUG - 2011-05-05 11:11:14 --> UTF-8 Support Enabled
DEBUG - 2011-05-05 11:11:14 --> URI Class Initialized
DEBUG - 2011-05-05 11:11:14 --> Router Class Initialized
DEBUG - 2011-05-05 11:11:14 --> Output Class Initialized
DEBUG - 2011-05-05 11:11:14 --> Input Class Initialized
DEBUG - 2011-05-05 11:11:14 --> Global POST and COOKIE data sanitized
DEBUG - 2011-05-05 11:11:14 --> Language Class Initialized
DEBUG - 2011-05-05 11:11:14 --> Loader Class Initialized
DEBUG - 2011-05-05 11:11:14 --> Controller Class Initialized
DEBUG - 2011-05-05 11:11:14 --> Model Class Initialized
DEBUG - 2011-05-05 11:11:14 --> Model Class Initialized
DEBUG - 2011-05-05 11:11:14 --> Model Class Initialized
DEBUG - 2011-05-05 11:11:14 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-05-05 11:11:14 --> Database Driver Class Initialized
DEBUG - 2011-05-05 11:11:14 --> File loaded: application/views/table/main.php
DEBUG - 2011-05-05 11:11:14 --> Helper loaded: url_helper
DEBUG - 2011-05-05 11:11:14 --> File loaded: application/views/common/header.php
DEBUG - 2011-05-05 11:11:14 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-05-05 11:11:14 --> File loaded: application/views/common/footer.php
DEBUG - 2011-05-05 11:11:14 --> File loaded: application/views/layout/main.php
DEBUG - 2011-05-05 11:11:14 --> Final output sent to browser
DEBUG - 2011-05-05 11:11:14 --> Total execution time: 0.1378
DEBUG - 2011-05-05 11:11:16 --> Config Class Initialized
DEBUG - 2011-05-05 11:11:16 --> Hooks Class Initialized
DEBUG - 2011-05-05 11:11:16 --> Utf8 Class Initialized
DEBUG - 2011-05-05 11:11:16 --> UTF-8 Support Enabled
DEBUG - 2011-05-05 11:11:16 --> URI Class Initialized
DEBUG - 2011-05-05 11:11:16 --> Router Class Initialized
DEBUG - 2011-05-05 11:11:16 --> Output Class Initialized
DEBUG - 2011-05-05 11:11:16 --> Input Class Initialized
DEBUG - 2011-05-05 11:11:16 --> Global POST and COOKIE data sanitized
DEBUG - 2011-05-05 11:11:16 --> Language Class Initialized
DEBUG - 2011-05-05 11:11:16 --> Loader Class Initialized
DEBUG - 2011-05-05 11:11:16 --> Controller Class Initialized
ERROR - 2011-05-05 11:11:16 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-05-05 11:11:16 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-05-05 11:11:16 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-05-05 11:11:16 --> Model Class Initialized
DEBUG - 2011-05-05 11:11:16 --> Model Class Initialized
DEBUG - 2011-05-05 11:11:16 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-05-05 11:11:16 --> Database Driver Class Initialized
DEBUG - 2011-05-05 11:11:16 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-05-05 11:11:16 --> Helper loaded: url_helper
DEBUG - 2011-05-05 11:11:16 --> File loaded: application/views/common/header.php
DEBUG - 2011-05-05 11:11:16 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-05-05 11:11:16 --> File loaded: application/views/common/footer.php
DEBUG - 2011-05-05 11:11:16 --> File loaded: application/views/layout/main.php
DEBUG - 2011-05-05 11:11:16 --> Final output sent to browser
DEBUG - 2011-05-05 11:11:16 --> Total execution time: 0.1621
DEBUG - 2011-05-05 11:15:48 --> Config Class Initialized
DEBUG - 2011-05-05 11:15:48 --> Hooks Class Initialized
DEBUG - 2011-05-05 11:15:48 --> Utf8 Class Initialized
DEBUG - 2011-05-05 11:15:48 --> UTF-8 Support Enabled
DEBUG - 2011-05-05 11:15:48 --> URI Class Initialized
DEBUG - 2011-05-05 11:15:48 --> Router Class Initialized
DEBUG - 2011-05-05 11:15:48 --> No URI present. Default controller set.
DEBUG - 2011-05-05 11:15:48 --> Output Class Initialized
DEBUG - 2011-05-05 11:15:48 --> Input Class Initialized
DEBUG - 2011-05-05 11:15:48 --> Global POST and COOKIE data sanitized
DEBUG - 2011-05-05 11:15:48 --> Language Class Initialized
DEBUG - 2011-05-05 11:15:48 --> Loader Class Initialized
DEBUG - 2011-05-05 11:15:48 --> Controller Class Initialized
DEBUG - 2011-05-05 11:15:48 --> File loaded: application/views/splash/main.php
DEBUG - 2011-05-05 11:15:48 --> Helper loaded: url_helper
DEBUG - 2011-05-05 11:15:48 --> File loaded: application/views/common/header.php
DEBUG - 2011-05-05 11:15:48 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-05-05 11:15:48 --> File loaded: application/views/common/footer.php
DEBUG - 2011-05-05 11:15:48 --> File loaded: application/views/layout/main.php
DEBUG - 2011-05-05 11:15:48 --> Final output sent to browser
DEBUG - 2011-05-05 11:15:48 --> Total execution time: 0.0731
DEBUG - 2011-05-05 11:57:50 --> Config Class Initialized
DEBUG - 2011-05-05 11:57:50 --> Hooks Class Initialized
DEBUG - 2011-05-05 11:57:50 --> Utf8 Class Initialized
DEBUG - 2011-05-05 11:57:50 --> UTF-8 Support Enabled
DEBUG - 2011-05-05 11:57:50 --> URI Class Initialized
DEBUG - 2011-05-05 11:57:50 --> Router Class Initialized
DEBUG - 2011-05-05 11:57:50 --> No URI present. Default controller set.
DEBUG - 2011-05-05 11:57:50 --> Output Class Initialized
DEBUG - 2011-05-05 11:57:50 --> Input Class Initialized
DEBUG - 2011-05-05 11:57:50 --> Global POST and COOKIE data sanitized
DEBUG - 2011-05-05 11:57:50 --> Language Class Initialized
DEBUG - 2011-05-05 11:57:50 --> Loader Class Initialized
DEBUG - 2011-05-05 11:57:50 --> Controller Class Initialized
DEBUG - 2011-05-05 11:57:50 --> File loaded: application/views/splash/main.php
DEBUG - 2011-05-05 11:57:50 --> Helper loaded: url_helper
DEBUG - 2011-05-05 11:57:50 --> File loaded: application/views/common/header.php
DEBUG - 2011-05-05 11:57:50 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-05-05 11:57:50 --> File loaded: application/views/common/footer.php
DEBUG - 2011-05-05 11:57:50 --> File loaded: application/views/layout/main.php
DEBUG - 2011-05-05 11:57:50 --> Final output sent to browser
DEBUG - 2011-05-05 11:57:50 --> Total execution time: 0.2735
DEBUG - 2011-05-05 11:57:54 --> Config Class Initialized
DEBUG - 2011-05-05 11:57:54 --> Hooks Class Initialized
DEBUG - 2011-05-05 11:57:54 --> Utf8 Class Initialized
DEBUG - 2011-05-05 11:57:54 --> UTF-8 Support Enabled
DEBUG - 2011-05-05 11:57:54 --> URI Class Initialized
DEBUG - 2011-05-05 11:57:54 --> Router Class Initialized
ERROR - 2011-05-05 11:57:54 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-05-05 11:57:56 --> Config Class Initialized
DEBUG - 2011-05-05 11:57:56 --> Hooks Class Initialized
DEBUG - 2011-05-05 11:57:56 --> Utf8 Class Initialized
DEBUG - 2011-05-05 11:57:56 --> UTF-8 Support Enabled
DEBUG - 2011-05-05 11:57:56 --> URI Class Initialized
DEBUG - 2011-05-05 11:57:56 --> Router Class Initialized
ERROR - 2011-05-05 11:57:56 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-05-05 11:58:01 --> Config Class Initialized
DEBUG - 2011-05-05 11:58:01 --> Hooks Class Initialized
DEBUG - 2011-05-05 11:58:01 --> Utf8 Class Initialized
DEBUG - 2011-05-05 11:58:01 --> UTF-8 Support Enabled
DEBUG - 2011-05-05 11:58:01 --> URI Class Initialized
DEBUG - 2011-05-05 11:58:01 --> Router Class Initialized
ERROR - 2011-05-05 11:58:01 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-05-05 12:10:56 --> Config Class Initialized
DEBUG - 2011-05-05 12:10:56 --> Hooks Class Initialized
DEBUG - 2011-05-05 12:10:56 --> Utf8 Class Initialized
DEBUG - 2011-05-05 12:10:56 --> UTF-8 Support Enabled
DEBUG - 2011-05-05 12:10:56 --> URI Class Initialized
DEBUG - 2011-05-05 12:10:56 --> Router Class Initialized
ERROR - 2011-05-05 12:10:56 --> 404 Page Not Found --> robots.txt
DEBUG - 2011-05-05 12:15:19 --> Config Class Initialized
DEBUG - 2011-05-05 12:15:20 --> Hooks Class Initialized
DEBUG - 2011-05-05 12:15:20 --> Utf8 Class Initialized
DEBUG - 2011-05-05 12:15:20 --> UTF-8 Support Enabled
DEBUG - 2011-05-05 12:15:20 --> URI Class Initialized
DEBUG - 2011-05-05 12:15:20 --> Router Class Initialized
ERROR - 2011-05-05 12:15:20 --> 404 Page Not Found --> robots.txt
DEBUG - 2011-05-05 12:16:09 --> Config Class Initialized
DEBUG - 2011-05-05 12:16:09 --> Hooks Class Initialized
DEBUG - 2011-05-05 12:16:09 --> Utf8 Class Initialized
DEBUG - 2011-05-05 12:16:09 --> UTF-8 Support Enabled
DEBUG - 2011-05-05 12:16:09 --> URI Class Initialized
DEBUG - 2011-05-05 12:16:09 --> Router Class Initialized
DEBUG - 2011-05-05 12:16:09 --> Output Class Initialized
DEBUG - 2011-05-05 12:16:09 --> Input Class Initialized
DEBUG - 2011-05-05 12:16:09 --> Global POST and COOKIE data sanitized
DEBUG - 2011-05-05 12:16:09 --> Language Class Initialized
DEBUG - 2011-05-05 12:16:09 --> Loader Class Initialized
DEBUG - 2011-05-05 12:16:09 --> Controller Class Initialized
DEBUG - 2011-05-05 12:16:09 --> Model Class Initialized
DEBUG - 2011-05-05 12:16:09 --> Model Class Initialized
DEBUG - 2011-05-05 12:16:09 --> Model Class Initialized
DEBUG - 2011-05-05 12:16:09 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-05-05 12:16:09 --> Database Driver Class Initialized
DEBUG - 2011-05-05 12:16:10 --> File loaded: application/views/table/main.php
DEBUG - 2011-05-05 12:16:10 --> Helper loaded: url_helper
DEBUG - 2011-05-05 12:16:10 --> File loaded: application/views/common/header.php
DEBUG - 2011-05-05 12:16:10 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-05-05 12:16:10 --> File loaded: application/views/common/footer.php
DEBUG - 2011-05-05 12:16:10 --> File loaded: application/views/layout/main.php
DEBUG - 2011-05-05 12:16:10 --> Final output sent to browser
DEBUG - 2011-05-05 12:16:10 --> Total execution time: 0.7896
DEBUG - 2011-05-05 12:42:52 --> Config Class Initialized
DEBUG - 2011-05-05 12:42:52 --> Hooks Class Initialized
DEBUG - 2011-05-05 12:42:52 --> Utf8 Class Initialized
DEBUG - 2011-05-05 12:42:52 --> UTF-8 Support Enabled
DEBUG - 2011-05-05 12:42:52 --> URI Class Initialized
DEBUG - 2011-05-05 12:42:52 --> Router Class Initialized
DEBUG - 2011-05-05 12:42:52 --> Output Class Initialized
DEBUG - 2011-05-05 12:42:52 --> Input Class Initialized
DEBUG - 2011-05-05 12:42:52 --> Global POST and COOKIE data sanitized
DEBUG - 2011-05-05 12:42:52 --> Language Class Initialized
DEBUG - 2011-05-05 12:42:52 --> Loader Class Initialized
DEBUG - 2011-05-05 12:42:52 --> Controller Class Initialized
DEBUG - 2011-05-05 12:42:52 --> Model Class Initialized
DEBUG - 2011-05-05 12:42:52 --> Model Class Initialized
DEBUG - 2011-05-05 12:42:52 --> Model Class Initialized
DEBUG - 2011-05-05 12:42:52 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-05-05 12:42:52 --> Database Driver Class Initialized
DEBUG - 2011-05-05 12:42:52 --> File loaded: application/views/table/main.php
DEBUG - 2011-05-05 12:42:52 --> Helper loaded: url_helper
DEBUG - 2011-05-05 12:42:52 --> File loaded: application/views/common/header.php
DEBUG - 2011-05-05 12:42:52 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-05-05 12:42:52 --> File loaded: application/views/common/footer.php
DEBUG - 2011-05-05 12:42:52 --> File loaded: application/views/layout/main.php
DEBUG - 2011-05-05 12:42:52 --> Final output sent to browser
DEBUG - 2011-05-05 12:42:52 --> Total execution time: 0.5666
DEBUG - 2011-05-05 12:42:56 --> Config Class Initialized
DEBUG - 2011-05-05 12:42:56 --> Hooks Class Initialized
DEBUG - 2011-05-05 12:42:56 --> Utf8 Class Initialized
DEBUG - 2011-05-05 12:42:56 --> UTF-8 Support Enabled
DEBUG - 2011-05-05 12:42:56 --> URI Class Initialized
DEBUG - 2011-05-05 12:42:56 --> Router Class Initialized
ERROR - 2011-05-05 12:42:56 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-05-05 12:42:56 --> Config Class Initialized
DEBUG - 2011-05-05 12:42:56 --> Hooks Class Initialized
DEBUG - 2011-05-05 12:42:56 --> Utf8 Class Initialized
DEBUG - 2011-05-05 12:42:56 --> UTF-8 Support Enabled
DEBUG - 2011-05-05 12:42:56 --> URI Class Initialized
DEBUG - 2011-05-05 12:42:56 --> Router Class Initialized
ERROR - 2011-05-05 12:42:56 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-05-05 12:42:57 --> Config Class Initialized
DEBUG - 2011-05-05 12:42:57 --> Hooks Class Initialized
DEBUG - 2011-05-05 12:42:57 --> Utf8 Class Initialized
DEBUG - 2011-05-05 12:42:57 --> UTF-8 Support Enabled
DEBUG - 2011-05-05 12:42:57 --> URI Class Initialized
DEBUG - 2011-05-05 12:42:57 --> Router Class Initialized
ERROR - 2011-05-05 12:42:57 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-05-05 12:55:38 --> Config Class Initialized
DEBUG - 2011-05-05 12:55:38 --> Hooks Class Initialized
DEBUG - 2011-05-05 12:55:38 --> Utf8 Class Initialized
DEBUG - 2011-05-05 12:55:38 --> UTF-8 Support Enabled
DEBUG - 2011-05-05 12:55:38 --> URI Class Initialized
DEBUG - 2011-05-05 12:55:38 --> Router Class Initialized
DEBUG - 2011-05-05 12:55:38 --> Output Class Initialized
DEBUG - 2011-05-05 12:55:38 --> Input Class Initialized
DEBUG - 2011-05-05 12:55:38 --> Global POST and COOKIE data sanitized
DEBUG - 2011-05-05 12:55:38 --> Language Class Initialized
DEBUG - 2011-05-05 12:55:38 --> Loader Class Initialized
DEBUG - 2011-05-05 12:55:38 --> Controller Class Initialized
DEBUG - 2011-05-05 12:55:38 --> Model Class Initialized
DEBUG - 2011-05-05 12:55:38 --> Model Class Initialized
DEBUG - 2011-05-05 12:55:38 --> Model Class Initialized
DEBUG - 2011-05-05 12:55:38 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-05-05 12:55:38 --> Database Driver Class Initialized
DEBUG - 2011-05-05 12:55:39 --> File loaded: application/views/table/main.php
DEBUG - 2011-05-05 12:55:39 --> Helper loaded: url_helper
DEBUG - 2011-05-05 12:55:39 --> File loaded: application/views/common/header.php
DEBUG - 2011-05-05 12:55:39 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-05-05 12:55:39 --> File loaded: application/views/common/footer.php
DEBUG - 2011-05-05 12:55:39 --> File loaded: application/views/layout/main.php
DEBUG - 2011-05-05 12:55:39 --> Final output sent to browser
DEBUG - 2011-05-05 12:55:39 --> Total execution time: 0.5525
DEBUG - 2011-05-05 12:55:45 --> Config Class Initialized
DEBUG - 2011-05-05 12:55:45 --> Hooks Class Initialized
DEBUG - 2011-05-05 12:55:45 --> Utf8 Class Initialized
DEBUG - 2011-05-05 12:55:45 --> UTF-8 Support Enabled
DEBUG - 2011-05-05 12:55:45 --> URI Class Initialized
DEBUG - 2011-05-05 12:55:45 --> Router Class Initialized
DEBUG - 2011-05-05 12:55:45 --> Output Class Initialized
DEBUG - 2011-05-05 12:55:45 --> Input Class Initialized
DEBUG - 2011-05-05 12:55:45 --> Global POST and COOKIE data sanitized
DEBUG - 2011-05-05 12:55:45 --> Language Class Initialized
DEBUG - 2011-05-05 12:55:45 --> Loader Class Initialized
DEBUG - 2011-05-05 12:55:45 --> Controller Class Initialized
ERROR - 2011-05-05 12:55:45 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-05-05 12:55:45 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-05-05 12:55:45 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-05-05 12:55:45 --> Model Class Initialized
DEBUG - 2011-05-05 12:55:45 --> Model Class Initialized
DEBUG - 2011-05-05 12:55:45 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-05-05 12:55:45 --> Database Driver Class Initialized
DEBUG - 2011-05-05 12:55:45 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-05-05 12:55:45 --> Helper loaded: url_helper
DEBUG - 2011-05-05 12:55:45 --> File loaded: application/views/common/header.php
DEBUG - 2011-05-05 12:55:45 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-05-05 12:55:45 --> File loaded: application/views/common/footer.php
DEBUG - 2011-05-05 12:55:45 --> File loaded: application/views/layout/main.php
DEBUG - 2011-05-05 12:55:45 --> Final output sent to browser
DEBUG - 2011-05-05 12:55:45 --> Total execution time: 0.3188
DEBUG - 2011-05-05 12:56:33 --> Config Class Initialized
DEBUG - 2011-05-05 12:56:33 --> Hooks Class Initialized
DEBUG - 2011-05-05 12:56:33 --> Utf8 Class Initialized
DEBUG - 2011-05-05 12:56:33 --> UTF-8 Support Enabled
DEBUG - 2011-05-05 12:56:33 --> URI Class Initialized
DEBUG - 2011-05-05 12:56:33 --> Router Class Initialized
DEBUG - 2011-05-05 12:56:33 --> Output Class Initialized
DEBUG - 2011-05-05 12:56:33 --> Input Class Initialized
DEBUG - 2011-05-05 12:56:33 --> Global POST and COOKIE data sanitized
DEBUG - 2011-05-05 12:56:33 --> Language Class Initialized
DEBUG - 2011-05-05 12:56:33 --> Loader Class Initialized
DEBUG - 2011-05-05 12:56:33 --> Controller Class Initialized
DEBUG - 2011-05-05 12:56:33 --> Model Class Initialized
DEBUG - 2011-05-05 12:56:33 --> Model Class Initialized
DEBUG - 2011-05-05 12:56:33 --> Model Class Initialized
DEBUG - 2011-05-05 12:56:33 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-05-05 12:56:33 --> Database Driver Class Initialized
DEBUG - 2011-05-05 12:56:33 --> File loaded: application/views/table/main.php
DEBUG - 2011-05-05 12:56:33 --> Helper loaded: url_helper
DEBUG - 2011-05-05 12:56:33 --> File loaded: application/views/common/header.php
DEBUG - 2011-05-05 12:56:33 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-05-05 12:56:33 --> File loaded: application/views/common/footer.php
DEBUG - 2011-05-05 12:56:33 --> File loaded: application/views/layout/main.php
DEBUG - 2011-05-05 12:56:33 --> Final output sent to browser
DEBUG - 2011-05-05 12:56:33 --> Total execution time: 0.0514
DEBUG - 2011-05-05 12:56:35 --> Config Class Initialized
DEBUG - 2011-05-05 12:56:35 --> Hooks Class Initialized
DEBUG - 2011-05-05 12:56:35 --> Utf8 Class Initialized
DEBUG - 2011-05-05 12:56:35 --> UTF-8 Support Enabled
DEBUG - 2011-05-05 12:56:35 --> URI Class Initialized
DEBUG - 2011-05-05 12:56:35 --> Router Class Initialized
DEBUG - 2011-05-05 12:56:35 --> Output Class Initialized
DEBUG - 2011-05-05 12:56:35 --> Input Class Initialized
DEBUG - 2011-05-05 12:56:35 --> Global POST and COOKIE data sanitized
DEBUG - 2011-05-05 12:56:35 --> Language Class Initialized
DEBUG - 2011-05-05 12:56:35 --> Loader Class Initialized
DEBUG - 2011-05-05 12:56:35 --> Controller Class Initialized
ERROR - 2011-05-05 12:56:35 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-05-05 12:56:35 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-05-05 12:56:35 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-05-05 12:56:35 --> Model Class Initialized
DEBUG - 2011-05-05 12:56:35 --> Model Class Initialized
DEBUG - 2011-05-05 12:56:35 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-05-05 12:56:35 --> Database Driver Class Initialized
DEBUG - 2011-05-05 12:56:35 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-05-05 12:56:35 --> Helper loaded: url_helper
DEBUG - 2011-05-05 12:56:35 --> File loaded: application/views/common/header.php
DEBUG - 2011-05-05 12:56:35 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-05-05 12:56:35 --> File loaded: application/views/common/footer.php
DEBUG - 2011-05-05 12:56:35 --> File loaded: application/views/layout/main.php
DEBUG - 2011-05-05 12:56:35 --> Final output sent to browser
DEBUG - 2011-05-05 12:56:35 --> Total execution time: 0.0487
DEBUG - 2011-05-05 13:16:34 --> Config Class Initialized
DEBUG - 2011-05-05 13:16:34 --> Hooks Class Initialized
DEBUG - 2011-05-05 13:16:34 --> Utf8 Class Initialized
DEBUG - 2011-05-05 13:16:34 --> UTF-8 Support Enabled
DEBUG - 2011-05-05 13:16:34 --> URI Class Initialized
DEBUG - 2011-05-05 13:16:34 --> Router Class Initialized
DEBUG - 2011-05-05 13:16:34 --> Output Class Initialized
DEBUG - 2011-05-05 13:16:34 --> Input Class Initialized
DEBUG - 2011-05-05 13:16:34 --> Global POST and COOKIE data sanitized
DEBUG - 2011-05-05 13:16:34 --> Language Class Initialized
DEBUG - 2011-05-05 13:16:34 --> Loader Class Initialized
DEBUG - 2011-05-05 13:16:34 --> Controller Class Initialized
ERROR - 2011-05-05 13:16:34 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-05-05 13:16:34 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-05-05 13:16:34 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-05-05 13:16:34 --> Model Class Initialized
DEBUG - 2011-05-05 13:16:34 --> Model Class Initialized
DEBUG - 2011-05-05 13:16:34 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-05-05 13:16:34 --> Database Driver Class Initialized
DEBUG - 2011-05-05 13:16:34 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-05-05 13:16:34 --> Helper loaded: url_helper
DEBUG - 2011-05-05 13:16:34 --> File loaded: application/views/common/header.php
DEBUG - 2011-05-05 13:16:34 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-05-05 13:16:34 --> File loaded: application/views/common/footer.php
DEBUG - 2011-05-05 13:16:34 --> File loaded: application/views/layout/main.php
DEBUG - 2011-05-05 13:16:34 --> Final output sent to browser
DEBUG - 2011-05-05 13:16:34 --> Total execution time: 0.3290
DEBUG - 2011-05-05 13:23:24 --> Config Class Initialized
DEBUG - 2011-05-05 13:23:24 --> Hooks Class Initialized
DEBUG - 2011-05-05 13:23:24 --> Utf8 Class Initialized
DEBUG - 2011-05-05 13:23:24 --> UTF-8 Support Enabled
DEBUG - 2011-05-05 13:23:24 --> URI Class Initialized
DEBUG - 2011-05-05 13:23:24 --> Router Class Initialized
DEBUG - 2011-05-05 13:23:24 --> Output Class Initialized
DEBUG - 2011-05-05 13:23:24 --> Input Class Initialized
DEBUG - 2011-05-05 13:23:24 --> Global POST and COOKIE data sanitized
DEBUG - 2011-05-05 13:23:24 --> Language Class Initialized
DEBUG - 2011-05-05 13:23:25 --> Loader Class Initialized
DEBUG - 2011-05-05 13:23:25 --> Controller Class Initialized
ERROR - 2011-05-05 13:23:25 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-05-05 13:23:25 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-05-05 13:23:25 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-05-05 13:23:25 --> Model Class Initialized
DEBUG - 2011-05-05 13:23:25 --> Model Class Initialized
DEBUG - 2011-05-05 13:23:25 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-05-05 13:23:25 --> Database Driver Class Initialized
DEBUG - 2011-05-05 13:23:25 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-05-05 13:23:25 --> Helper loaded: url_helper
DEBUG - 2011-05-05 13:23:25 --> File loaded: application/views/common/header.php
DEBUG - 2011-05-05 13:23:25 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-05-05 13:23:25 --> File loaded: application/views/common/footer.php
DEBUG - 2011-05-05 13:23:25 --> File loaded: application/views/layout/main.php
DEBUG - 2011-05-05 13:23:25 --> Final output sent to browser
DEBUG - 2011-05-05 13:23:25 --> Total execution time: 0.9334
DEBUG - 2011-05-05 13:24:09 --> Config Class Initialized
DEBUG - 2011-05-05 13:24:09 --> Hooks Class Initialized
DEBUG - 2011-05-05 13:24:09 --> Utf8 Class Initialized
DEBUG - 2011-05-05 13:24:09 --> UTF-8 Support Enabled
DEBUG - 2011-05-05 13:24:09 --> URI Class Initialized
DEBUG - 2011-05-05 13:24:09 --> Router Class Initialized
DEBUG - 2011-05-05 13:24:09 --> Output Class Initialized
DEBUG - 2011-05-05 13:24:09 --> Input Class Initialized
DEBUG - 2011-05-05 13:24:09 --> Global POST and COOKIE data sanitized
DEBUG - 2011-05-05 13:24:09 --> Language Class Initialized
DEBUG - 2011-05-05 13:24:09 --> Loader Class Initialized
DEBUG - 2011-05-05 13:24:09 --> Controller Class Initialized
DEBUG - 2011-05-05 13:24:09 --> Model Class Initialized
DEBUG - 2011-05-05 13:24:09 --> Model Class Initialized
DEBUG - 2011-05-05 13:24:09 --> Model Class Initialized
DEBUG - 2011-05-05 13:24:09 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-05-05 13:24:09 --> Database Driver Class Initialized
DEBUG - 2011-05-05 13:24:10 --> File loaded: application/views/table/main.php
DEBUG - 2011-05-05 13:24:10 --> Helper loaded: url_helper
DEBUG - 2011-05-05 13:24:10 --> File loaded: application/views/common/header.php
DEBUG - 2011-05-05 13:24:10 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-05-05 13:24:10 --> File loaded: application/views/common/footer.php
DEBUG - 2011-05-05 13:24:10 --> File loaded: application/views/layout/main.php
DEBUG - 2011-05-05 13:24:10 --> Final output sent to browser
DEBUG - 2011-05-05 13:24:10 --> Total execution time: 0.3490
DEBUG - 2011-05-05 13:24:24 --> Config Class Initialized
DEBUG - 2011-05-05 13:24:24 --> Hooks Class Initialized
DEBUG - 2011-05-05 13:24:24 --> Utf8 Class Initialized
DEBUG - 2011-05-05 13:24:24 --> UTF-8 Support Enabled
DEBUG - 2011-05-05 13:24:24 --> URI Class Initialized
DEBUG - 2011-05-05 13:24:24 --> Router Class Initialized
DEBUG - 2011-05-05 13:24:24 --> Output Class Initialized
DEBUG - 2011-05-05 13:24:24 --> Input Class Initialized
DEBUG - 2011-05-05 13:24:24 --> Global POST and COOKIE data sanitized
DEBUG - 2011-05-05 13:24:24 --> Language Class Initialized
DEBUG - 2011-05-05 13:24:24 --> Loader Class Initialized
DEBUG - 2011-05-05 13:24:24 --> Controller Class Initialized
ERROR - 2011-05-05 13:24:24 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-05-05 13:24:24 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-05-05 13:24:24 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-05-05 13:24:24 --> Model Class Initialized
DEBUG - 2011-05-05 13:24:24 --> Model Class Initialized
DEBUG - 2011-05-05 13:24:24 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-05-05 13:24:24 --> Database Driver Class Initialized
DEBUG - 2011-05-05 13:24:24 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-05-05 13:24:24 --> Helper loaded: url_helper
DEBUG - 2011-05-05 13:24:24 --> File loaded: application/views/common/header.php
DEBUG - 2011-05-05 13:24:24 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-05-05 13:24:24 --> File loaded: application/views/common/footer.php
DEBUG - 2011-05-05 13:24:24 --> File loaded: application/views/layout/main.php
DEBUG - 2011-05-05 13:24:24 --> Final output sent to browser
DEBUG - 2011-05-05 13:24:24 --> Total execution time: 0.1022
DEBUG - 2011-05-05 13:51:31 --> Config Class Initialized
DEBUG - 2011-05-05 13:51:31 --> Hooks Class Initialized
DEBUG - 2011-05-05 13:51:31 --> Utf8 Class Initialized
DEBUG - 2011-05-05 13:51:31 --> UTF-8 Support Enabled
DEBUG - 2011-05-05 13:51:31 --> URI Class Initialized
DEBUG - 2011-05-05 13:51:31 --> Router Class Initialized
DEBUG - 2011-05-05 13:51:31 --> Output Class Initialized
DEBUG - 2011-05-05 13:51:31 --> Input Class Initialized
DEBUG - 2011-05-05 13:51:31 --> Global POST and COOKIE data sanitized
DEBUG - 2011-05-05 13:51:31 --> Language Class Initialized
DEBUG - 2011-05-05 13:51:31 --> Loader Class Initialized
DEBUG - 2011-05-05 13:51:31 --> Controller Class Initialized
DEBUG - 2011-05-05 13:51:31 --> Model Class Initialized
DEBUG - 2011-05-05 13:51:31 --> Model Class Initialized
DEBUG - 2011-05-05 13:51:31 --> Model Class Initialized
DEBUG - 2011-05-05 13:51:31 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-05-05 13:51:31 --> Database Driver Class Initialized
DEBUG - 2011-05-05 13:51:32 --> File loaded: application/views/table/main.php
DEBUG - 2011-05-05 13:51:32 --> Helper loaded: url_helper
DEBUG - 2011-05-05 13:51:32 --> File loaded: application/views/common/header.php
DEBUG - 2011-05-05 13:51:32 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-05-05 13:51:32 --> File loaded: application/views/common/footer.php
DEBUG - 2011-05-05 13:51:32 --> File loaded: application/views/layout/main.php
DEBUG - 2011-05-05 13:51:32 --> Final output sent to browser
DEBUG - 2011-05-05 13:51:32 --> Total execution time: 1.2638
DEBUG - 2011-05-05 13:51:34 --> Config Class Initialized
DEBUG - 2011-05-05 13:51:34 --> Hooks Class Initialized
DEBUG - 2011-05-05 13:51:34 --> Utf8 Class Initialized
DEBUG - 2011-05-05 13:51:34 --> UTF-8 Support Enabled
DEBUG - 2011-05-05 13:51:34 --> URI Class Initialized
DEBUG - 2011-05-05 13:51:34 --> Router Class Initialized
DEBUG - 2011-05-05 13:51:34 --> Output Class Initialized
DEBUG - 2011-05-05 13:51:34 --> Input Class Initialized
DEBUG - 2011-05-05 13:51:34 --> Global POST and COOKIE data sanitized
DEBUG - 2011-05-05 13:51:34 --> Language Class Initialized
DEBUG - 2011-05-05 13:51:34 --> Loader Class Initialized
DEBUG - 2011-05-05 13:51:34 --> Controller Class Initialized
ERROR - 2011-05-05 13:51:34 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-05-05 13:51:34 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-05-05 13:51:34 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-05-05 13:51:34 --> Model Class Initialized
DEBUG - 2011-05-05 13:51:34 --> Model Class Initialized
DEBUG - 2011-05-05 13:51:34 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-05-05 13:51:34 --> Database Driver Class Initialized
DEBUG - 2011-05-05 13:51:34 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-05-05 13:51:34 --> Helper loaded: url_helper
DEBUG - 2011-05-05 13:51:34 --> File loaded: application/views/common/header.php
DEBUG - 2011-05-05 13:51:34 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-05-05 13:51:34 --> File loaded: application/views/common/footer.php
DEBUG - 2011-05-05 13:51:34 --> File loaded: application/views/layout/main.php
DEBUG - 2011-05-05 13:51:34 --> Final output sent to browser
DEBUG - 2011-05-05 13:51:34 --> Total execution time: 0.1162
DEBUG - 2011-05-05 14:45:43 --> Config Class Initialized
DEBUG - 2011-05-05 14:45:43 --> Hooks Class Initialized
DEBUG - 2011-05-05 14:45:43 --> Utf8 Class Initialized
DEBUG - 2011-05-05 14:45:43 --> UTF-8 Support Enabled
DEBUG - 2011-05-05 14:45:43 --> URI Class Initialized
DEBUG - 2011-05-05 14:45:43 --> Router Class Initialized
DEBUG - 2011-05-05 14:45:43 --> Output Class Initialized
DEBUG - 2011-05-05 14:45:43 --> Input Class Initialized
DEBUG - 2011-05-05 14:45:43 --> Global POST and COOKIE data sanitized
DEBUG - 2011-05-05 14:45:43 --> Language Class Initialized
DEBUG - 2011-05-05 14:45:43 --> Loader Class Initialized
DEBUG - 2011-05-05 14:45:43 --> Controller Class Initialized
DEBUG - 2011-05-05 14:45:43 --> Model Class Initialized
DEBUG - 2011-05-05 14:45:43 --> Model Class Initialized
DEBUG - 2011-05-05 14:45:43 --> Model Class Initialized
DEBUG - 2011-05-05 14:45:43 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-05-05 14:45:43 --> Database Driver Class Initialized
DEBUG - 2011-05-05 14:45:43 --> File loaded: application/views/table/main.php
DEBUG - 2011-05-05 14:45:43 --> Helper loaded: url_helper
DEBUG - 2011-05-05 14:45:43 --> File loaded: application/views/common/header.php
DEBUG - 2011-05-05 14:45:43 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-05-05 14:45:43 --> File loaded: application/views/common/footer.php
DEBUG - 2011-05-05 14:45:43 --> File loaded: application/views/layout/main.php
DEBUG - 2011-05-05 14:45:43 --> Final output sent to browser
DEBUG - 2011-05-05 14:45:43 --> Total execution time: 0.6153
DEBUG - 2011-05-05 14:45:45 --> Config Class Initialized
DEBUG - 2011-05-05 14:45:45 --> Hooks Class Initialized
DEBUG - 2011-05-05 14:45:45 --> Utf8 Class Initialized
DEBUG - 2011-05-05 14:45:45 --> UTF-8 Support Enabled
DEBUG - 2011-05-05 14:45:45 --> URI Class Initialized
DEBUG - 2011-05-05 14:45:45 --> Router Class Initialized
ERROR - 2011-05-05 14:45:45 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-05-05 15:56:52 --> Config Class Initialized
DEBUG - 2011-05-05 15:56:52 --> Hooks Class Initialized
DEBUG - 2011-05-05 15:56:52 --> Utf8 Class Initialized
DEBUG - 2011-05-05 15:56:52 --> UTF-8 Support Enabled
DEBUG - 2011-05-05 15:56:52 --> URI Class Initialized
DEBUG - 2011-05-05 15:56:52 --> Router Class Initialized
DEBUG - 2011-05-05 15:56:52 --> Output Class Initialized
DEBUG - 2011-05-05 15:56:52 --> Input Class Initialized
DEBUG - 2011-05-05 15:56:52 --> Global POST and COOKIE data sanitized
DEBUG - 2011-05-05 15:56:52 --> Language Class Initialized
DEBUG - 2011-05-05 15:56:52 --> Loader Class Initialized
DEBUG - 2011-05-05 15:56:52 --> Controller Class Initialized
DEBUG - 2011-05-05 15:56:52 --> Model Class Initialized
DEBUG - 2011-05-05 15:56:52 --> Model Class Initialized
DEBUG - 2011-05-05 15:56:52 --> Model Class Initialized
DEBUG - 2011-05-05 15:56:52 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-05-05 15:56:52 --> Database Driver Class Initialized
DEBUG - 2011-05-05 15:56:53 --> File loaded: application/views/table/main.php
DEBUG - 2011-05-05 15:56:53 --> Helper loaded: url_helper
DEBUG - 2011-05-05 15:56:53 --> File loaded: application/views/common/header.php
DEBUG - 2011-05-05 15:56:53 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-05-05 15:56:53 --> File loaded: application/views/common/footer.php
DEBUG - 2011-05-05 15:56:53 --> File loaded: application/views/layout/main.php
DEBUG - 2011-05-05 15:56:53 --> Final output sent to browser
DEBUG - 2011-05-05 15:56:53 --> Total execution time: 0.4911
DEBUG - 2011-05-05 15:56:53 --> Config Class Initialized
DEBUG - 2011-05-05 15:56:53 --> Hooks Class Initialized
DEBUG - 2011-05-05 15:56:53 --> Utf8 Class Initialized
DEBUG - 2011-05-05 15:56:53 --> UTF-8 Support Enabled
DEBUG - 2011-05-05 15:56:53 --> URI Class Initialized
DEBUG - 2011-05-05 15:56:53 --> Router Class Initialized
DEBUG - 2011-05-05 15:56:53 --> Output Class Initialized
DEBUG - 2011-05-05 15:56:53 --> Input Class Initialized
DEBUG - 2011-05-05 15:56:53 --> Global POST and COOKIE data sanitized
DEBUG - 2011-05-05 15:56:53 --> Language Class Initialized
DEBUG - 2011-05-05 15:56:53 --> Loader Class Initialized
DEBUG - 2011-05-05 15:56:53 --> Controller Class Initialized
ERROR - 2011-05-05 15:56:53 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-05-05 15:56:53 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-05-05 15:56:53 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-05-05 15:56:53 --> Model Class Initialized
DEBUG - 2011-05-05 15:56:53 --> Model Class Initialized
DEBUG - 2011-05-05 15:56:53 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-05-05 15:56:53 --> Database Driver Class Initialized
DEBUG - 2011-05-05 15:56:53 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-05-05 15:56:53 --> Helper loaded: url_helper
DEBUG - 2011-05-05 15:56:53 --> File loaded: application/views/common/header.php
DEBUG - 2011-05-05 15:56:53 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-05-05 15:56:53 --> File loaded: application/views/common/footer.php
DEBUG - 2011-05-05 15:56:54 --> File loaded: application/views/layout/main.php
DEBUG - 2011-05-05 15:56:54 --> Final output sent to browser
DEBUG - 2011-05-05 15:56:54 --> Total execution time: 0.0849
DEBUG - 2011-05-05 16:25:30 --> Config Class Initialized
DEBUG - 2011-05-05 16:25:30 --> Hooks Class Initialized
DEBUG - 2011-05-05 16:25:30 --> Utf8 Class Initialized
DEBUG - 2011-05-05 16:25:30 --> UTF-8 Support Enabled
DEBUG - 2011-05-05 16:25:30 --> URI Class Initialized
DEBUG - 2011-05-05 16:25:30 --> Router Class Initialized
DEBUG - 2011-05-05 16:25:30 --> Output Class Initialized
DEBUG - 2011-05-05 16:25:30 --> Input Class Initialized
DEBUG - 2011-05-05 16:25:30 --> Global POST and COOKIE data sanitized
DEBUG - 2011-05-05 16:25:30 --> Language Class Initialized
DEBUG - 2011-05-05 16:25:30 --> Loader Class Initialized
DEBUG - 2011-05-05 16:25:30 --> Controller Class Initialized
DEBUG - 2011-05-05 16:25:30 --> Model Class Initialized
DEBUG - 2011-05-05 16:25:30 --> Model Class Initialized
DEBUG - 2011-05-05 16:25:30 --> Model Class Initialized
DEBUG - 2011-05-05 16:25:30 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-05-05 16:25:30 --> Database Driver Class Initialized
DEBUG - 2011-05-05 16:25:30 --> File loaded: application/views/table/main.php
DEBUG - 2011-05-05 16:25:30 --> Helper loaded: url_helper
DEBUG - 2011-05-05 16:25:30 --> File loaded: application/views/common/header.php
DEBUG - 2011-05-05 16:25:30 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-05-05 16:25:30 --> File loaded: application/views/common/footer.php
DEBUG - 2011-05-05 16:25:30 --> File loaded: application/views/layout/main.php
DEBUG - 2011-05-05 16:25:30 --> Final output sent to browser
DEBUG - 2011-05-05 16:25:30 --> Total execution time: 0.5668
DEBUG - 2011-05-05 16:25:42 --> Config Class Initialized
DEBUG - 2011-05-05 16:25:42 --> Hooks Class Initialized
DEBUG - 2011-05-05 16:25:42 --> Utf8 Class Initialized
DEBUG - 2011-05-05 16:25:42 --> UTF-8 Support Enabled
DEBUG - 2011-05-05 16:25:42 --> URI Class Initialized
DEBUG - 2011-05-05 16:25:42 --> Router Class Initialized
DEBUG - 2011-05-05 16:25:42 --> Output Class Initialized
DEBUG - 2011-05-05 16:25:42 --> Input Class Initialized
DEBUG - 2011-05-05 16:25:42 --> Global POST and COOKIE data sanitized
DEBUG - 2011-05-05 16:25:42 --> Language Class Initialized
DEBUG - 2011-05-05 16:25:42 --> Loader Class Initialized
DEBUG - 2011-05-05 16:25:42 --> Controller Class Initialized
ERROR - 2011-05-05 16:25:42 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-05-05 16:25:42 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-05-05 16:25:42 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-05-05 16:25:42 --> Model Class Initialized
DEBUG - 2011-05-05 16:25:42 --> Model Class Initialized
DEBUG - 2011-05-05 16:25:42 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-05-05 16:25:42 --> Database Driver Class Initialized
DEBUG - 2011-05-05 16:25:42 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-05-05 16:25:42 --> Helper loaded: url_helper
DEBUG - 2011-05-05 16:25:42 --> File loaded: application/views/common/header.php
DEBUG - 2011-05-05 16:25:42 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-05-05 16:25:42 --> File loaded: application/views/common/footer.php
DEBUG - 2011-05-05 16:25:42 --> File loaded: application/views/layout/main.php
DEBUG - 2011-05-05 16:25:42 --> Final output sent to browser
DEBUG - 2011-05-05 16:25:42 --> Total execution time: 0.0800
DEBUG - 2011-05-05 17:55:05 --> Config Class Initialized
DEBUG - 2011-05-05 17:55:05 --> Hooks Class Initialized
DEBUG - 2011-05-05 17:55:05 --> Utf8 Class Initialized
DEBUG - 2011-05-05 17:55:05 --> UTF-8 Support Enabled
DEBUG - 2011-05-05 17:55:05 --> URI Class Initialized
DEBUG - 2011-05-05 17:55:05 --> Router Class Initialized
DEBUG - 2011-05-05 17:55:05 --> No URI present. Default controller set.
DEBUG - 2011-05-05 17:55:05 --> Output Class Initialized
DEBUG - 2011-05-05 17:55:05 --> Input Class Initialized
DEBUG - 2011-05-05 17:55:05 --> Global POST and COOKIE data sanitized
DEBUG - 2011-05-05 17:55:05 --> Language Class Initialized
DEBUG - 2011-05-05 17:55:05 --> Loader Class Initialized
DEBUG - 2011-05-05 17:55:05 --> Controller Class Initialized
DEBUG - 2011-05-05 17:55:05 --> File loaded: application/views/splash/main.php
DEBUG - 2011-05-05 17:55:06 --> Helper loaded: url_helper
DEBUG - 2011-05-05 17:55:06 --> File loaded: application/views/common/header.php
DEBUG - 2011-05-05 17:55:06 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-05-05 17:55:06 --> File loaded: application/views/common/footer.php
DEBUG - 2011-05-05 17:55:06 --> File loaded: application/views/layout/main.php
DEBUG - 2011-05-05 17:55:06 --> Final output sent to browser
DEBUG - 2011-05-05 17:55:06 --> Total execution time: 1.3557
DEBUG - 2011-05-05 17:55:07 --> Config Class Initialized
DEBUG - 2011-05-05 17:55:07 --> Hooks Class Initialized
DEBUG - 2011-05-05 17:55:07 --> Utf8 Class Initialized
DEBUG - 2011-05-05 17:55:07 --> UTF-8 Support Enabled
DEBUG - 2011-05-05 17:55:07 --> URI Class Initialized
DEBUG - 2011-05-05 17:55:07 --> Router Class Initialized
ERROR - 2011-05-05 17:55:07 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-05-05 18:19:53 --> Config Class Initialized
DEBUG - 2011-05-05 18:19:53 --> Hooks Class Initialized
DEBUG - 2011-05-05 18:19:53 --> Utf8 Class Initialized
DEBUG - 2011-05-05 18:19:53 --> UTF-8 Support Enabled
DEBUG - 2011-05-05 18:19:53 --> URI Class Initialized
DEBUG - 2011-05-05 18:19:53 --> Router Class Initialized
ERROR - 2011-05-05 18:19:53 --> 404 Page Not Found --> robots.txt
DEBUG - 2011-05-05 18:19:53 --> Config Class Initialized
DEBUG - 2011-05-05 18:19:53 --> Hooks Class Initialized
DEBUG - 2011-05-05 18:19:53 --> Utf8 Class Initialized
DEBUG - 2011-05-05 18:19:53 --> UTF-8 Support Enabled
DEBUG - 2011-05-05 18:19:53 --> URI Class Initialized
DEBUG - 2011-05-05 18:19:53 --> Router Class Initialized
DEBUG - 2011-05-05 18:19:53 --> Output Class Initialized
DEBUG - 2011-05-05 18:19:53 --> Input Class Initialized
DEBUG - 2011-05-05 18:19:53 --> Global POST and COOKIE data sanitized
DEBUG - 2011-05-05 18:19:53 --> Language Class Initialized
DEBUG - 2011-05-05 18:19:53 --> Loader Class Initialized
DEBUG - 2011-05-05 18:19:53 --> Controller Class Initialized
DEBUG - 2011-05-05 18:19:53 --> Model Class Initialized
DEBUG - 2011-05-05 18:19:53 --> Model Class Initialized
DEBUG - 2011-05-05 18:19:53 --> Model Class Initialized
DEBUG - 2011-05-05 18:19:53 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-05-05 18:19:53 --> Database Driver Class Initialized
DEBUG - 2011-05-05 18:19:53 --> File loaded: application/views/table/main.php
DEBUG - 2011-05-05 18:19:54 --> Helper loaded: url_helper
DEBUG - 2011-05-05 18:19:54 --> File loaded: application/views/common/header.php
DEBUG - 2011-05-05 18:19:54 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-05-05 18:19:54 --> File loaded: application/views/common/footer.php
DEBUG - 2011-05-05 18:19:54 --> File loaded: application/views/layout/main.php
DEBUG - 2011-05-05 18:19:54 --> Final output sent to browser
DEBUG - 2011-05-05 18:19:54 --> Total execution time: 0.4861
DEBUG - 2011-05-05 18:41:01 --> Config Class Initialized
DEBUG - 2011-05-05 18:41:01 --> Hooks Class Initialized
DEBUG - 2011-05-05 18:41:01 --> Utf8 Class Initialized
DEBUG - 2011-05-05 18:41:01 --> UTF-8 Support Enabled
DEBUG - 2011-05-05 18:41:01 --> URI Class Initialized
DEBUG - 2011-05-05 18:41:01 --> Router Class Initialized
DEBUG - 2011-05-05 18:41:01 --> Output Class Initialized
DEBUG - 2011-05-05 18:41:01 --> Input Class Initialized
DEBUG - 2011-05-05 18:41:01 --> Global POST and COOKIE data sanitized
DEBUG - 2011-05-05 18:41:01 --> Language Class Initialized
DEBUG - 2011-05-05 18:41:01 --> Loader Class Initialized
DEBUG - 2011-05-05 18:41:01 --> Controller Class Initialized
ERROR - 2011-05-05 18:41:01 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-05-05 18:41:01 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-05-05 18:41:01 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-05-05 18:41:01 --> Model Class Initialized
DEBUG - 2011-05-05 18:41:01 --> Model Class Initialized
DEBUG - 2011-05-05 18:41:01 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-05-05 18:41:01 --> Database Driver Class Initialized
DEBUG - 2011-05-05 18:41:01 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-05-05 18:41:01 --> Helper loaded: url_helper
DEBUG - 2011-05-05 18:41:01 --> File loaded: application/views/common/header.php
DEBUG - 2011-05-05 18:41:01 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-05-05 18:41:01 --> File loaded: application/views/common/footer.php
DEBUG - 2011-05-05 18:41:01 --> File loaded: application/views/layout/main.php
DEBUG - 2011-05-05 18:41:01 --> Final output sent to browser
DEBUG - 2011-05-05 18:41:01 --> Total execution time: 0.2734
DEBUG - 2011-05-05 18:41:03 --> Config Class Initialized
DEBUG - 2011-05-05 18:41:03 --> Hooks Class Initialized
DEBUG - 2011-05-05 18:41:03 --> Utf8 Class Initialized
DEBUG - 2011-05-05 18:41:03 --> UTF-8 Support Enabled
DEBUG - 2011-05-05 18:41:03 --> URI Class Initialized
DEBUG - 2011-05-05 18:41:03 --> Router Class Initialized
DEBUG - 2011-05-05 18:41:03 --> Output Class Initialized
DEBUG - 2011-05-05 18:41:03 --> Input Class Initialized
DEBUG - 2011-05-05 18:41:03 --> Global POST and COOKIE data sanitized
DEBUG - 2011-05-05 18:41:03 --> Language Class Initialized
DEBUG - 2011-05-05 18:41:03 --> Loader Class Initialized
DEBUG - 2011-05-05 18:41:03 --> Controller Class Initialized
DEBUG - 2011-05-05 18:41:03 --> Model Class Initialized
DEBUG - 2011-05-05 18:41:03 --> Model Class Initialized
DEBUG - 2011-05-05 18:41:03 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-05-05 18:41:03 --> Database Driver Class Initialized
DEBUG - 2011-05-05 18:41:03 --> Final output sent to browser
DEBUG - 2011-05-05 18:41:03 --> Total execution time: 0.7910
DEBUG - 2011-05-05 18:41:06 --> Config Class Initialized
DEBUG - 2011-05-05 18:41:06 --> Hooks Class Initialized
DEBUG - 2011-05-05 18:41:06 --> Utf8 Class Initialized
DEBUG - 2011-05-05 18:41:06 --> UTF-8 Support Enabled
DEBUG - 2011-05-05 18:41:06 --> URI Class Initialized
DEBUG - 2011-05-05 18:41:06 --> Router Class Initialized
ERROR - 2011-05-05 18:41:06 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-05-05 19:33:29 --> Config Class Initialized
DEBUG - 2011-05-05 19:33:29 --> Hooks Class Initialized
DEBUG - 2011-05-05 19:33:29 --> Utf8 Class Initialized
DEBUG - 2011-05-05 19:33:29 --> UTF-8 Support Enabled
DEBUG - 2011-05-05 19:33:29 --> URI Class Initialized
DEBUG - 2011-05-05 19:33:29 --> Router Class Initialized
DEBUG - 2011-05-05 19:33:29 --> No URI present. Default controller set.
DEBUG - 2011-05-05 19:33:29 --> Output Class Initialized
DEBUG - 2011-05-05 19:33:29 --> Input Class Initialized
DEBUG - 2011-05-05 19:33:29 --> Global POST and COOKIE data sanitized
DEBUG - 2011-05-05 19:33:29 --> Language Class Initialized
DEBUG - 2011-05-05 19:33:29 --> Loader Class Initialized
DEBUG - 2011-05-05 19:33:29 --> Controller Class Initialized
DEBUG - 2011-05-05 19:33:29 --> File loaded: application/views/splash/main.php
DEBUG - 2011-05-05 19:33:29 --> Helper loaded: url_helper
DEBUG - 2011-05-05 19:33:29 --> File loaded: application/views/common/header.php
DEBUG - 2011-05-05 19:33:29 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-05-05 19:33:29 --> File loaded: application/views/common/footer.php
DEBUG - 2011-05-05 19:33:29 --> File loaded: application/views/layout/main.php
DEBUG - 2011-05-05 19:33:29 --> Final output sent to browser
DEBUG - 2011-05-05 19:33:29 --> Total execution time: 0.1827
DEBUG - 2011-05-05 19:33:30 --> Config Class Initialized
DEBUG - 2011-05-05 19:33:30 --> Hooks Class Initialized
DEBUG - 2011-05-05 19:33:30 --> Utf8 Class Initialized
DEBUG - 2011-05-05 19:33:30 --> UTF-8 Support Enabled
DEBUG - 2011-05-05 19:33:30 --> URI Class Initialized
DEBUG - 2011-05-05 19:33:30 --> Router Class Initialized
ERROR - 2011-05-05 19:33:30 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-05-05 19:33:31 --> Config Class Initialized
DEBUG - 2011-05-05 19:33:31 --> Hooks Class Initialized
DEBUG - 2011-05-05 19:33:31 --> Utf8 Class Initialized
DEBUG - 2011-05-05 19:33:31 --> UTF-8 Support Enabled
DEBUG - 2011-05-05 19:33:31 --> URI Class Initialized
DEBUG - 2011-05-05 19:33:31 --> Router Class Initialized
ERROR - 2011-05-05 19:33:31 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-05-05 19:33:37 --> Config Class Initialized
DEBUG - 2011-05-05 19:33:37 --> Hooks Class Initialized
DEBUG - 2011-05-05 19:33:37 --> Utf8 Class Initialized
DEBUG - 2011-05-05 19:33:37 --> UTF-8 Support Enabled
DEBUG - 2011-05-05 19:33:37 --> URI Class Initialized
DEBUG - 2011-05-05 19:33:37 --> Router Class Initialized
DEBUG - 2011-05-05 19:33:37 --> Output Class Initialized
DEBUG - 2011-05-05 19:33:37 --> Input Class Initialized
DEBUG - 2011-05-05 19:33:37 --> Global POST and COOKIE data sanitized
DEBUG - 2011-05-05 19:33:37 --> Language Class Initialized
DEBUG - 2011-05-05 19:33:37 --> Loader Class Initialized
DEBUG - 2011-05-05 19:33:37 --> Controller Class Initialized
ERROR - 2011-05-05 19:33:37 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-05-05 19:33:37 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-05-05 19:33:37 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-05-05 19:33:37 --> Model Class Initialized
DEBUG - 2011-05-05 19:33:37 --> Model Class Initialized
DEBUG - 2011-05-05 19:33:37 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-05-05 19:33:37 --> Database Driver Class Initialized
DEBUG - 2011-05-05 19:33:37 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-05-05 19:33:37 --> Helper loaded: url_helper
DEBUG - 2011-05-05 19:33:37 --> File loaded: application/views/common/header.php
DEBUG - 2011-05-05 19:33:37 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-05-05 19:33:37 --> File loaded: application/views/common/footer.php
DEBUG - 2011-05-05 19:33:37 --> File loaded: application/views/layout/main.php
DEBUG - 2011-05-05 19:33:37 --> Final output sent to browser
DEBUG - 2011-05-05 19:33:37 --> Total execution time: 0.1751
DEBUG - 2011-05-05 19:33:37 --> Config Class Initialized
DEBUG - 2011-05-05 19:33:37 --> Hooks Class Initialized
DEBUG - 2011-05-05 19:33:37 --> Utf8 Class Initialized
DEBUG - 2011-05-05 19:33:37 --> UTF-8 Support Enabled
DEBUG - 2011-05-05 19:33:37 --> URI Class Initialized
DEBUG - 2011-05-05 19:33:37 --> Router Class Initialized
DEBUG - 2011-05-05 19:33:37 --> Output Class Initialized
DEBUG - 2011-05-05 19:33:37 --> Input Class Initialized
DEBUG - 2011-05-05 19:33:37 --> Global POST and COOKIE data sanitized
DEBUG - 2011-05-05 19:33:37 --> Language Class Initialized
DEBUG - 2011-05-05 19:33:37 --> Loader Class Initialized
DEBUG - 2011-05-05 19:33:37 --> Controller Class Initialized
DEBUG - 2011-05-05 19:33:37 --> Model Class Initialized
DEBUG - 2011-05-05 19:33:37 --> Config Class Initialized
DEBUG - 2011-05-05 19:33:37 --> Hooks Class Initialized
DEBUG - 2011-05-05 19:33:37 --> Utf8 Class Initialized
DEBUG - 2011-05-05 19:33:37 --> UTF-8 Support Enabled
DEBUG - 2011-05-05 19:33:37 --> URI Class Initialized
DEBUG - 2011-05-05 19:33:37 --> Router Class Initialized
DEBUG - 2011-05-05 19:33:37 --> Output Class Initialized
DEBUG - 2011-05-05 19:33:37 --> Input Class Initialized
DEBUG - 2011-05-05 19:33:37 --> Global POST and COOKIE data sanitized
DEBUG - 2011-05-05 19:33:37 --> Language Class Initialized
DEBUG - 2011-05-05 19:33:37 --> Loader Class Initialized
DEBUG - 2011-05-05 19:33:37 --> Controller Class Initialized
DEBUG - 2011-05-05 19:33:37 --> Model Class Initialized
DEBUG - 2011-05-05 19:33:37 --> Model Class Initialized
DEBUG - 2011-05-05 19:33:37 --> Model Class Initialized
DEBUG - 2011-05-05 19:33:37 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-05-05 19:33:37 --> Model Class Initialized
DEBUG - 2011-05-05 19:33:37 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-05-05 19:33:37 --> Database Driver Class Initialized
DEBUG - 2011-05-05 19:33:37 --> Database Driver Class Initialized
DEBUG - 2011-05-05 19:33:37 --> File loaded: application/views/table/main.php
DEBUG - 2011-05-05 19:33:37 --> Helper loaded: url_helper
DEBUG - 2011-05-05 19:33:37 --> File loaded: application/views/common/header.php
DEBUG - 2011-05-05 19:33:37 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-05-05 19:33:37 --> File loaded: application/views/common/footer.php
DEBUG - 2011-05-05 19:33:37 --> File loaded: application/views/layout/main.php
DEBUG - 2011-05-05 19:33:37 --> Final output sent to browser
DEBUG - 2011-05-05 19:33:37 --> Total execution time: 0.3016
DEBUG - 2011-05-05 19:33:38 --> Final output sent to browser
DEBUG - 2011-05-05 19:33:38 --> Total execution time: 0.6643
DEBUG - 2011-05-05 19:33:38 --> Config Class Initialized
DEBUG - 2011-05-05 19:33:38 --> Hooks Class Initialized
DEBUG - 2011-05-05 19:33:38 --> Utf8 Class Initialized
DEBUG - 2011-05-05 19:33:38 --> UTF-8 Support Enabled
DEBUG - 2011-05-05 19:33:38 --> URI Class Initialized
DEBUG - 2011-05-05 19:33:38 --> Router Class Initialized
ERROR - 2011-05-05 19:33:38 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-05-05 19:33:39 --> Config Class Initialized
DEBUG - 2011-05-05 19:33:39 --> Hooks Class Initialized
DEBUG - 2011-05-05 19:33:39 --> Utf8 Class Initialized
DEBUG - 2011-05-05 19:33:39 --> UTF-8 Support Enabled
DEBUG - 2011-05-05 19:33:39 --> URI Class Initialized
DEBUG - 2011-05-05 19:33:39 --> Router Class Initialized
ERROR - 2011-05-05 19:33:39 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-05-05 19:33:53 --> Config Class Initialized
DEBUG - 2011-05-05 19:33:53 --> Hooks Class Initialized
DEBUG - 2011-05-05 19:33:53 --> Utf8 Class Initialized
DEBUG - 2011-05-05 19:33:53 --> UTF-8 Support Enabled
DEBUG - 2011-05-05 19:33:53 --> URI Class Initialized
DEBUG - 2011-05-05 19:33:53 --> Router Class Initialized
DEBUG - 2011-05-05 19:33:53 --> Output Class Initialized
DEBUG - 2011-05-05 19:33:53 --> Input Class Initialized
DEBUG - 2011-05-05 19:33:53 --> Global POST and COOKIE data sanitized
DEBUG - 2011-05-05 19:33:53 --> Language Class Initialized
DEBUG - 2011-05-05 19:33:53 --> Loader Class Initialized
DEBUG - 2011-05-05 19:33:53 --> Controller Class Initialized
DEBUG - 2011-05-05 19:33:53 --> Model Class Initialized
DEBUG - 2011-05-05 19:33:53 --> Model Class Initialized
DEBUG - 2011-05-05 19:33:53 --> Model Class Initialized
DEBUG - 2011-05-05 19:33:53 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-05-05 19:33:53 --> Database Driver Class Initialized
DEBUG - 2011-05-05 19:33:53 --> File loaded: application/views/table/main.php
DEBUG - 2011-05-05 19:33:53 --> Helper loaded: url_helper
DEBUG - 2011-05-05 19:33:53 --> File loaded: application/views/common/header.php
DEBUG - 2011-05-05 19:33:53 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-05-05 19:33:53 --> File loaded: application/views/common/footer.php
DEBUG - 2011-05-05 19:33:53 --> File loaded: application/views/layout/main.php
DEBUG - 2011-05-05 19:33:53 --> Final output sent to browser
DEBUG - 2011-05-05 19:33:53 --> Total execution time: 0.0441
DEBUG - 2011-05-05 19:33:54 --> Config Class Initialized
DEBUG - 2011-05-05 19:33:54 --> Hooks Class Initialized
DEBUG - 2011-05-05 19:33:54 --> Utf8 Class Initialized
DEBUG - 2011-05-05 19:33:54 --> UTF-8 Support Enabled
DEBUG - 2011-05-05 19:33:54 --> URI Class Initialized
DEBUG - 2011-05-05 19:33:54 --> Router Class Initialized
ERROR - 2011-05-05 19:33:54 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-05-05 22:57:28 --> Config Class Initialized
DEBUG - 2011-05-05 22:57:28 --> Hooks Class Initialized
DEBUG - 2011-05-05 22:57:28 --> Utf8 Class Initialized
DEBUG - 2011-05-05 22:57:28 --> UTF-8 Support Enabled
DEBUG - 2011-05-05 22:57:28 --> URI Class Initialized
DEBUG - 2011-05-05 22:57:28 --> Router Class Initialized
ERROR - 2011-05-05 22:57:28 --> 404 Page Not Found --> robots.txt
DEBUG - 2011-05-05 22:57:31 --> Config Class Initialized
DEBUG - 2011-05-05 22:57:31 --> Hooks Class Initialized
DEBUG - 2011-05-05 22:57:31 --> Utf8 Class Initialized
DEBUG - 2011-05-05 22:57:31 --> UTF-8 Support Enabled
DEBUG - 2011-05-05 22:57:31 --> URI Class Initialized
DEBUG - 2011-05-05 22:57:31 --> Router Class Initialized
DEBUG - 2011-05-05 22:57:31 --> No URI present. Default controller set.
DEBUG - 2011-05-05 22:57:31 --> Output Class Initialized
DEBUG - 2011-05-05 22:57:31 --> Input Class Initialized
DEBUG - 2011-05-05 22:57:31 --> Global POST and COOKIE data sanitized
DEBUG - 2011-05-05 22:57:31 --> Language Class Initialized
DEBUG - 2011-05-05 22:57:31 --> Loader Class Initialized
DEBUG - 2011-05-05 22:57:31 --> Controller Class Initialized
DEBUG - 2011-05-05 22:57:31 --> File loaded: application/views/splash/main.php
DEBUG - 2011-05-05 22:57:31 --> Helper loaded: url_helper
DEBUG - 2011-05-05 22:57:31 --> File loaded: application/views/common/header.php
DEBUG - 2011-05-05 22:57:31 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-05-05 22:57:31 --> File loaded: application/views/common/footer.php
DEBUG - 2011-05-05 22:57:31 --> File loaded: application/views/layout/main.php
DEBUG - 2011-05-05 22:57:31 --> Final output sent to browser
DEBUG - 2011-05-05 22:57:31 --> Total execution time: 0.1514
DEBUG - 2011-05-05 23:38:19 --> Config Class Initialized
DEBUG - 2011-05-05 23:38:19 --> Hooks Class Initialized
DEBUG - 2011-05-05 23:38:19 --> Utf8 Class Initialized
DEBUG - 2011-05-05 23:38:19 --> UTF-8 Support Enabled
DEBUG - 2011-05-05 23:38:19 --> URI Class Initialized
DEBUG - 2011-05-05 23:38:19 --> Router Class Initialized
ERROR - 2011-05-05 23:38:19 --> 404 Page Not Found --> robots.txt
DEBUG - 2011-05-05 23:39:18 --> Config Class Initialized
DEBUG - 2011-05-05 23:39:18 --> Hooks Class Initialized
DEBUG - 2011-05-05 23:39:18 --> Utf8 Class Initialized
DEBUG - 2011-05-05 23:39:18 --> UTF-8 Support Enabled
DEBUG - 2011-05-05 23:39:18 --> URI Class Initialized
DEBUG - 2011-05-05 23:39:18 --> Router Class Initialized
DEBUG - 2011-05-05 23:39:18 --> Output Class Initialized
DEBUG - 2011-05-05 23:39:18 --> Input Class Initialized
DEBUG - 2011-05-05 23:39:18 --> Global POST and COOKIE data sanitized
DEBUG - 2011-05-05 23:39:18 --> Language Class Initialized
DEBUG - 2011-05-05 23:39:18 --> Loader Class Initialized
DEBUG - 2011-05-05 23:39:18 --> Controller Class Initialized
DEBUG - 2011-05-05 23:39:18 --> Model Class Initialized
DEBUG - 2011-05-05 23:39:18 --> Model Class Initialized
DEBUG - 2011-05-05 23:39:18 --> Model Class Initialized
DEBUG - 2011-05-05 23:39:18 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-05-05 23:39:18 --> Database Driver Class Initialized
DEBUG - 2011-05-05 23:39:19 --> File loaded: application/views/table/main.php
DEBUG - 2011-05-05 23:39:19 --> Helper loaded: url_helper
DEBUG - 2011-05-05 23:39:19 --> File loaded: application/views/common/header.php
DEBUG - 2011-05-05 23:39:19 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-05-05 23:39:19 --> File loaded: application/views/common/footer.php
DEBUG - 2011-05-05 23:39:19 --> File loaded: application/views/layout/main.php
DEBUG - 2011-05-05 23:39:19 --> Final output sent to browser
DEBUG - 2011-05-05 23:39:19 --> Total execution time: 0.7249
DEBUG - 2011-05-05 23:54:12 --> Config Class Initialized
DEBUG - 2011-05-05 23:54:12 --> Hooks Class Initialized
DEBUG - 2011-05-05 23:54:12 --> Utf8 Class Initialized
DEBUG - 2011-05-05 23:54:12 --> UTF-8 Support Enabled
DEBUG - 2011-05-05 23:54:12 --> URI Class Initialized
DEBUG - 2011-05-05 23:54:12 --> Router Class Initialized
DEBUG - 2011-05-05 23:54:12 --> Output Class Initialized
DEBUG - 2011-05-05 23:54:12 --> Input Class Initialized
DEBUG - 2011-05-05 23:54:12 --> Global POST and COOKIE data sanitized
DEBUG - 2011-05-05 23:54:12 --> Language Class Initialized
DEBUG - 2011-05-05 23:54:12 --> Loader Class Initialized
DEBUG - 2011-05-05 23:54:12 --> Controller Class Initialized
DEBUG - 2011-05-05 23:54:12 --> Model Class Initialized
DEBUG - 2011-05-05 23:54:12 --> Model Class Initialized
DEBUG - 2011-05-05 23:54:12 --> Model Class Initialized
DEBUG - 2011-05-05 23:54:12 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-05-05 23:54:12 --> Database Driver Class Initialized
DEBUG - 2011-05-05 23:54:12 --> File loaded: application/views/table/main.php
DEBUG - 2011-05-05 23:54:12 --> Helper loaded: url_helper
DEBUG - 2011-05-05 23:54:12 --> File loaded: application/views/common/header.php
DEBUG - 2011-05-05 23:54:12 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-05-05 23:54:12 --> File loaded: application/views/common/footer.php
DEBUG - 2011-05-05 23:54:12 --> File loaded: application/views/layout/main.php
DEBUG - 2011-05-05 23:54:12 --> Final output sent to browser
DEBUG - 2011-05-05 23:54:12 --> Total execution time: 0.1905
DEBUG - 2011-05-05 23:54:13 --> Config Class Initialized
DEBUG - 2011-05-05 23:54:13 --> Hooks Class Initialized
DEBUG - 2011-05-05 23:54:13 --> Utf8 Class Initialized
DEBUG - 2011-05-05 23:54:13 --> UTF-8 Support Enabled
DEBUG - 2011-05-05 23:54:13 --> URI Class Initialized
DEBUG - 2011-05-05 23:54:13 --> Router Class Initialized
DEBUG - 2011-05-05 23:54:13 --> Output Class Initialized
DEBUG - 2011-05-05 23:54:13 --> Input Class Initialized
DEBUG - 2011-05-05 23:54:13 --> Global POST and COOKIE data sanitized
DEBUG - 2011-05-05 23:54:13 --> Language Class Initialized
DEBUG - 2011-05-05 23:54:13 --> Loader Class Initialized
DEBUG - 2011-05-05 23:54:13 --> Controller Class Initialized
ERROR - 2011-05-05 23:54:13 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-05-05 23:54:13 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-05-05 23:54:13 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-05-05 23:54:13 --> Model Class Initialized
DEBUG - 2011-05-05 23:54:13 --> Model Class Initialized
DEBUG - 2011-05-05 23:54:13 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-05-05 23:54:13 --> Database Driver Class Initialized
DEBUG - 2011-05-05 23:54:13 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-05-05 23:54:13 --> Helper loaded: url_helper
DEBUG - 2011-05-05 23:54:13 --> File loaded: application/views/common/header.php
DEBUG - 2011-05-05 23:54:13 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-05-05 23:54:13 --> File loaded: application/views/common/footer.php
DEBUG - 2011-05-05 23:54:13 --> File loaded: application/views/layout/main.php
DEBUG - 2011-05-05 23:54:13 --> Final output sent to browser
DEBUG - 2011-05-05 23:54:13 --> Total execution time: 0.1184

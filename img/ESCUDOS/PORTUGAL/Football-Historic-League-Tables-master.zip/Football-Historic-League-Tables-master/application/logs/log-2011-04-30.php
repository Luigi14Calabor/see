<?php  if ( ! defined('BASEPATH')) exit('No direct script access allowed'); ?>

DEBUG - 2011-04-30 01:57:55 --> Config Class Initialized
DEBUG - 2011-04-30 01:57:55 --> Hooks Class Initialized
DEBUG - 2011-04-30 01:57:55 --> Utf8 Class Initialized
DEBUG - 2011-04-30 01:57:55 --> UTF-8 Support Enabled
DEBUG - 2011-04-30 01:57:55 --> URI Class Initialized
DEBUG - 2011-04-30 01:57:55 --> Router Class Initialized
DEBUG - 2011-04-30 01:57:55 --> Output Class Initialized
DEBUG - 2011-04-30 01:57:55 --> Input Class Initialized
DEBUG - 2011-04-30 01:57:55 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-30 01:57:55 --> Language Class Initialized
DEBUG - 2011-04-30 01:57:55 --> Loader Class Initialized
DEBUG - 2011-04-30 01:57:55 --> Controller Class Initialized
DEBUG - 2011-04-30 01:57:55 --> Model Class Initialized
DEBUG - 2011-04-30 01:57:55 --> Model Class Initialized
DEBUG - 2011-04-30 01:57:55 --> Model Class Initialized
DEBUG - 2011-04-30 01:57:55 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-30 01:57:55 --> Database Driver Class Initialized
DEBUG - 2011-04-30 01:58:29 --> Config Class Initialized
DEBUG - 2011-04-30 01:58:29 --> Hooks Class Initialized
DEBUG - 2011-04-30 01:58:29 --> Utf8 Class Initialized
DEBUG - 2011-04-30 01:58:29 --> UTF-8 Support Enabled
DEBUG - 2011-04-30 01:58:29 --> URI Class Initialized
DEBUG - 2011-04-30 01:58:29 --> Router Class Initialized
DEBUG - 2011-04-30 01:58:29 --> Output Class Initialized
DEBUG - 2011-04-30 01:58:29 --> Input Class Initialized
DEBUG - 2011-04-30 01:58:29 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-30 01:58:29 --> Language Class Initialized
DEBUG - 2011-04-30 01:58:29 --> Loader Class Initialized
DEBUG - 2011-04-30 01:58:29 --> Controller Class Initialized
ERROR - 2011-04-30 01:58:29 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-04-30 01:58:29 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-04-30 01:58:29 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-04-30 01:58:29 --> Model Class Initialized
DEBUG - 2011-04-30 01:58:29 --> Model Class Initialized
DEBUG - 2011-04-30 01:58:29 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-30 01:58:29 --> Database Driver Class Initialized
DEBUG - 2011-04-30 01:58:31 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-04-30 01:58:31 --> Helper loaded: url_helper
DEBUG - 2011-04-30 01:58:31 --> File loaded: application/views/common/header.php
DEBUG - 2011-04-30 01:58:31 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-04-30 01:58:31 --> File loaded: application/views/common/footer.php
DEBUG - 2011-04-30 01:58:31 --> File loaded: application/views/layout/main.php
DEBUG - 2011-04-30 01:58:31 --> Final output sent to browser
DEBUG - 2011-04-30 01:58:31 --> Total execution time: 2.5911
DEBUG - 2011-04-30 01:58:48 --> File loaded: application/views/table/main.php
DEBUG - 2011-04-30 01:58:48 --> Helper loaded: url_helper
DEBUG - 2011-04-30 01:58:48 --> File loaded: application/views/common/header.php
DEBUG - 2011-04-30 01:58:48 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-04-30 01:58:48 --> File loaded: application/views/common/footer.php
DEBUG - 2011-04-30 01:58:48 --> File loaded: application/views/layout/main.php
DEBUG - 2011-04-30 01:58:48 --> Final output sent to browser
DEBUG - 2011-04-30 01:58:48 --> Total execution time: 52.7073
DEBUG - 2011-04-30 02:17:36 --> Config Class Initialized
DEBUG - 2011-04-30 02:17:36 --> Hooks Class Initialized
DEBUG - 2011-04-30 02:17:36 --> Utf8 Class Initialized
DEBUG - 2011-04-30 02:17:36 --> UTF-8 Support Enabled
DEBUG - 2011-04-30 02:17:36 --> URI Class Initialized
DEBUG - 2011-04-30 02:17:36 --> Router Class Initialized
DEBUG - 2011-04-30 02:17:36 --> Output Class Initialized
DEBUG - 2011-04-30 02:17:36 --> Input Class Initialized
DEBUG - 2011-04-30 02:17:36 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-30 02:17:36 --> Language Class Initialized
DEBUG - 2011-04-30 02:17:36 --> Loader Class Initialized
DEBUG - 2011-04-30 02:17:37 --> Controller Class Initialized
ERROR - 2011-04-30 02:17:37 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-04-30 02:17:37 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-04-30 02:17:37 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-04-30 02:17:37 --> Model Class Initialized
DEBUG - 2011-04-30 02:17:37 --> Model Class Initialized
DEBUG - 2011-04-30 02:17:37 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-30 02:17:37 --> Database Driver Class Initialized
DEBUG - 2011-04-30 02:17:37 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-04-30 02:17:38 --> Helper loaded: url_helper
DEBUG - 2011-04-30 02:17:38 --> File loaded: application/views/common/header.php
DEBUG - 2011-04-30 02:17:38 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-04-30 02:17:38 --> File loaded: application/views/common/footer.php
DEBUG - 2011-04-30 02:17:38 --> File loaded: application/views/layout/main.php
DEBUG - 2011-04-30 02:17:38 --> Final output sent to browser
DEBUG - 2011-04-30 02:17:38 --> Total execution time: 1.9980
DEBUG - 2011-04-30 02:17:40 --> Config Class Initialized
DEBUG - 2011-04-30 02:17:40 --> Hooks Class Initialized
DEBUG - 2011-04-30 02:17:40 --> Utf8 Class Initialized
DEBUG - 2011-04-30 02:17:40 --> UTF-8 Support Enabled
DEBUG - 2011-04-30 02:17:40 --> URI Class Initialized
DEBUG - 2011-04-30 02:17:40 --> Router Class Initialized
DEBUG - 2011-04-30 02:17:40 --> Output Class Initialized
DEBUG - 2011-04-30 02:17:40 --> Input Class Initialized
DEBUG - 2011-04-30 02:17:40 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-30 02:17:40 --> Language Class Initialized
DEBUG - 2011-04-30 02:17:40 --> Loader Class Initialized
DEBUG - 2011-04-30 02:17:40 --> Controller Class Initialized
DEBUG - 2011-04-30 02:17:40 --> Model Class Initialized
DEBUG - 2011-04-30 02:17:40 --> Model Class Initialized
DEBUG - 2011-04-30 02:17:40 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-30 02:17:40 --> Database Driver Class Initialized
DEBUG - 2011-04-30 02:17:43 --> Final output sent to browser
DEBUG - 2011-04-30 02:17:43 --> Total execution time: 2.4066
DEBUG - 2011-04-30 02:17:44 --> Config Class Initialized
DEBUG - 2011-04-30 02:17:44 --> Hooks Class Initialized
DEBUG - 2011-04-30 02:17:44 --> Utf8 Class Initialized
DEBUG - 2011-04-30 02:17:44 --> UTF-8 Support Enabled
DEBUG - 2011-04-30 02:17:44 --> URI Class Initialized
DEBUG - 2011-04-30 02:17:44 --> Router Class Initialized
ERROR - 2011-04-30 02:17:44 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-04-30 02:17:46 --> Config Class Initialized
DEBUG - 2011-04-30 02:17:46 --> Hooks Class Initialized
DEBUG - 2011-04-30 02:17:46 --> Utf8 Class Initialized
DEBUG - 2011-04-30 02:17:46 --> UTF-8 Support Enabled
DEBUG - 2011-04-30 02:17:46 --> URI Class Initialized
DEBUG - 2011-04-30 02:17:46 --> Router Class Initialized
ERROR - 2011-04-30 02:17:46 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-04-30 02:21:30 --> Config Class Initialized
DEBUG - 2011-04-30 02:21:30 --> Hooks Class Initialized
DEBUG - 2011-04-30 02:21:30 --> Utf8 Class Initialized
DEBUG - 2011-04-30 02:21:30 --> UTF-8 Support Enabled
DEBUG - 2011-04-30 02:21:30 --> URI Class Initialized
DEBUG - 2011-04-30 02:21:30 --> Router Class Initialized
DEBUG - 2011-04-30 02:21:30 --> Output Class Initialized
DEBUG - 2011-04-30 02:21:30 --> Input Class Initialized
DEBUG - 2011-04-30 02:21:30 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-30 02:21:30 --> Language Class Initialized
DEBUG - 2011-04-30 02:21:30 --> Loader Class Initialized
DEBUG - 2011-04-30 02:21:30 --> Controller Class Initialized
DEBUG - 2011-04-30 02:21:30 --> Model Class Initialized
DEBUG - 2011-04-30 02:21:30 --> Model Class Initialized
DEBUG - 2011-04-30 02:21:30 --> Model Class Initialized
DEBUG - 2011-04-30 02:21:30 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-30 02:21:30 --> Database Driver Class Initialized
DEBUG - 2011-04-30 02:21:31 --> File loaded: application/views/table/main.php
DEBUG - 2011-04-30 02:21:31 --> Helper loaded: url_helper
DEBUG - 2011-04-30 02:21:31 --> File loaded: application/views/common/header.php
DEBUG - 2011-04-30 02:21:31 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-04-30 02:21:31 --> File loaded: application/views/common/footer.php
DEBUG - 2011-04-30 02:21:31 --> File loaded: application/views/layout/main.php
DEBUG - 2011-04-30 02:21:31 --> Final output sent to browser
DEBUG - 2011-04-30 02:21:31 --> Total execution time: 1.1820
DEBUG - 2011-04-30 02:21:35 --> Config Class Initialized
DEBUG - 2011-04-30 02:21:35 --> Hooks Class Initialized
DEBUG - 2011-04-30 02:21:35 --> Utf8 Class Initialized
DEBUG - 2011-04-30 02:21:35 --> UTF-8 Support Enabled
DEBUG - 2011-04-30 02:21:35 --> URI Class Initialized
DEBUG - 2011-04-30 02:21:35 --> Router Class Initialized
DEBUG - 2011-04-30 02:21:35 --> Output Class Initialized
DEBUG - 2011-04-30 02:21:35 --> Input Class Initialized
DEBUG - 2011-04-30 02:21:35 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-30 02:21:35 --> Language Class Initialized
DEBUG - 2011-04-30 02:21:35 --> Loader Class Initialized
DEBUG - 2011-04-30 02:21:35 --> Controller Class Initialized
DEBUG - 2011-04-30 02:21:35 --> Model Class Initialized
DEBUG - 2011-04-30 02:21:35 --> Model Class Initialized
DEBUG - 2011-04-30 02:21:35 --> Model Class Initialized
DEBUG - 2011-04-30 02:21:35 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-30 02:21:35 --> Database Driver Class Initialized
DEBUG - 2011-04-30 02:21:35 --> File loaded: application/views/table/main.php
DEBUG - 2011-04-30 02:21:35 --> Helper loaded: url_helper
DEBUG - 2011-04-30 02:21:35 --> File loaded: application/views/common/header.php
DEBUG - 2011-04-30 02:21:35 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-04-30 02:21:35 --> File loaded: application/views/common/footer.php
DEBUG - 2011-04-30 02:21:35 --> File loaded: application/views/layout/main.php
DEBUG - 2011-04-30 02:21:35 --> Final output sent to browser
DEBUG - 2011-04-30 02:21:35 --> Total execution time: 0.0523
DEBUG - 2011-04-30 02:22:06 --> Config Class Initialized
DEBUG - 2011-04-30 02:22:06 --> Hooks Class Initialized
DEBUG - 2011-04-30 02:22:06 --> Utf8 Class Initialized
DEBUG - 2011-04-30 02:22:06 --> UTF-8 Support Enabled
DEBUG - 2011-04-30 02:22:06 --> URI Class Initialized
DEBUG - 2011-04-30 02:22:06 --> Router Class Initialized
DEBUG - 2011-04-30 02:22:06 --> Output Class Initialized
DEBUG - 2011-04-30 02:22:06 --> Input Class Initialized
DEBUG - 2011-04-30 02:22:06 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-30 02:22:06 --> Language Class Initialized
DEBUG - 2011-04-30 02:22:06 --> Loader Class Initialized
DEBUG - 2011-04-30 02:22:06 --> Controller Class Initialized
DEBUG - 2011-04-30 02:22:06 --> Model Class Initialized
DEBUG - 2011-04-30 02:22:06 --> Model Class Initialized
DEBUG - 2011-04-30 02:22:06 --> Model Class Initialized
DEBUG - 2011-04-30 02:22:06 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-30 02:22:06 --> Database Driver Class Initialized
DEBUG - 2011-04-30 02:22:11 --> File loaded: application/views/table/main.php
DEBUG - 2011-04-30 02:22:11 --> Helper loaded: url_helper
DEBUG - 2011-04-30 02:22:11 --> File loaded: application/views/common/header.php
DEBUG - 2011-04-30 02:22:11 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-04-30 02:22:11 --> File loaded: application/views/common/footer.php
DEBUG - 2011-04-30 02:22:11 --> File loaded: application/views/layout/main.php
DEBUG - 2011-04-30 02:22:11 --> Final output sent to browser
DEBUG - 2011-04-30 02:22:11 --> Total execution time: 5.0655
DEBUG - 2011-04-30 02:22:13 --> Config Class Initialized
DEBUG - 2011-04-30 02:22:13 --> Hooks Class Initialized
DEBUG - 2011-04-30 02:22:13 --> Utf8 Class Initialized
DEBUG - 2011-04-30 02:22:13 --> UTF-8 Support Enabled
DEBUG - 2011-04-30 02:22:13 --> URI Class Initialized
DEBUG - 2011-04-30 02:22:13 --> Router Class Initialized
DEBUG - 2011-04-30 02:22:13 --> Output Class Initialized
DEBUG - 2011-04-30 02:22:13 --> Input Class Initialized
DEBUG - 2011-04-30 02:22:13 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-30 02:22:13 --> Language Class Initialized
DEBUG - 2011-04-30 02:22:13 --> Loader Class Initialized
DEBUG - 2011-04-30 02:22:13 --> Controller Class Initialized
DEBUG - 2011-04-30 02:22:13 --> Model Class Initialized
DEBUG - 2011-04-30 02:22:13 --> Model Class Initialized
DEBUG - 2011-04-30 02:22:13 --> Model Class Initialized
DEBUG - 2011-04-30 02:22:13 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-30 02:22:13 --> Database Driver Class Initialized
DEBUG - 2011-04-30 02:22:13 --> File loaded: application/views/table/main.php
DEBUG - 2011-04-30 02:22:13 --> Helper loaded: url_helper
DEBUG - 2011-04-30 02:22:13 --> File loaded: application/views/common/header.php
DEBUG - 2011-04-30 02:22:13 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-04-30 02:22:13 --> File loaded: application/views/common/footer.php
DEBUG - 2011-04-30 02:22:13 --> File loaded: application/views/layout/main.php
DEBUG - 2011-04-30 02:22:13 --> Final output sent to browser
DEBUG - 2011-04-30 02:22:13 --> Total execution time: 0.0478
DEBUG - 2011-04-30 02:22:13 --> Config Class Initialized
DEBUG - 2011-04-30 02:22:13 --> Hooks Class Initialized
DEBUG - 2011-04-30 02:22:13 --> Utf8 Class Initialized
DEBUG - 2011-04-30 02:22:13 --> UTF-8 Support Enabled
DEBUG - 2011-04-30 02:22:13 --> URI Class Initialized
DEBUG - 2011-04-30 02:22:13 --> Router Class Initialized
DEBUG - 2011-04-30 02:22:13 --> Output Class Initialized
DEBUG - 2011-04-30 02:22:13 --> Input Class Initialized
DEBUG - 2011-04-30 02:22:13 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-30 02:22:13 --> Language Class Initialized
DEBUG - 2011-04-30 02:22:13 --> Loader Class Initialized
DEBUG - 2011-04-30 02:22:13 --> Controller Class Initialized
DEBUG - 2011-04-30 02:22:13 --> Model Class Initialized
DEBUG - 2011-04-30 02:22:13 --> Model Class Initialized
DEBUG - 2011-04-30 02:22:13 --> Model Class Initialized
DEBUG - 2011-04-30 02:22:13 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-30 02:22:13 --> Database Driver Class Initialized
DEBUG - 2011-04-30 02:22:13 --> File loaded: application/views/table/main.php
DEBUG - 2011-04-30 02:22:13 --> Helper loaded: url_helper
DEBUG - 2011-04-30 02:22:13 --> File loaded: application/views/common/header.php
DEBUG - 2011-04-30 02:22:13 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-04-30 02:22:13 --> File loaded: application/views/common/footer.php
DEBUG - 2011-04-30 02:22:13 --> File loaded: application/views/layout/main.php
DEBUG - 2011-04-30 02:22:13 --> Final output sent to browser
DEBUG - 2011-04-30 02:22:13 --> Total execution time: 0.0604
DEBUG - 2011-04-30 02:22:23 --> Config Class Initialized
DEBUG - 2011-04-30 02:22:23 --> Hooks Class Initialized
DEBUG - 2011-04-30 02:22:23 --> Utf8 Class Initialized
DEBUG - 2011-04-30 02:22:23 --> UTF-8 Support Enabled
DEBUG - 2011-04-30 02:22:23 --> URI Class Initialized
DEBUG - 2011-04-30 02:22:23 --> Router Class Initialized
DEBUG - 2011-04-30 02:22:23 --> Output Class Initialized
DEBUG - 2011-04-30 02:22:23 --> Input Class Initialized
DEBUG - 2011-04-30 02:22:23 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-30 02:22:23 --> Language Class Initialized
DEBUG - 2011-04-30 02:22:23 --> Loader Class Initialized
DEBUG - 2011-04-30 02:22:23 --> Controller Class Initialized
DEBUG - 2011-04-30 02:22:23 --> Model Class Initialized
DEBUG - 2011-04-30 02:22:23 --> Model Class Initialized
DEBUG - 2011-04-30 02:22:23 --> Model Class Initialized
DEBUG - 2011-04-30 02:22:23 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-30 02:22:23 --> Database Driver Class Initialized
DEBUG - 2011-04-30 02:22:23 --> File loaded: application/views/table/main.php
DEBUG - 2011-04-30 02:22:23 --> Helper loaded: url_helper
DEBUG - 2011-04-30 02:22:23 --> File loaded: application/views/common/header.php
DEBUG - 2011-04-30 02:22:23 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-04-30 02:22:23 --> File loaded: application/views/common/footer.php
DEBUG - 2011-04-30 02:22:23 --> File loaded: application/views/layout/main.php
DEBUG - 2011-04-30 02:22:23 --> Final output sent to browser
DEBUG - 2011-04-30 02:22:23 --> Total execution time: 0.0523
DEBUG - 2011-04-30 02:43:40 --> Config Class Initialized
DEBUG - 2011-04-30 02:43:40 --> Hooks Class Initialized
DEBUG - 2011-04-30 02:43:40 --> Utf8 Class Initialized
DEBUG - 2011-04-30 02:43:40 --> UTF-8 Support Enabled
DEBUG - 2011-04-30 02:43:40 --> URI Class Initialized
DEBUG - 2011-04-30 02:43:40 --> Router Class Initialized
ERROR - 2011-04-30 02:43:40 --> 404 Page Not Found --> robots.txt
DEBUG - 2011-04-30 02:43:53 --> Config Class Initialized
DEBUG - 2011-04-30 02:43:53 --> Hooks Class Initialized
DEBUG - 2011-04-30 02:43:53 --> Utf8 Class Initialized
DEBUG - 2011-04-30 02:43:53 --> UTF-8 Support Enabled
DEBUG - 2011-04-30 02:43:53 --> URI Class Initialized
DEBUG - 2011-04-30 02:43:53 --> Router Class Initialized
DEBUG - 2011-04-30 02:43:53 --> Output Class Initialized
DEBUG - 2011-04-30 02:43:53 --> Input Class Initialized
DEBUG - 2011-04-30 02:43:53 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-30 02:43:53 --> Language Class Initialized
DEBUG - 2011-04-30 02:43:53 --> Loader Class Initialized
DEBUG - 2011-04-30 02:43:53 --> Controller Class Initialized
DEBUG - 2011-04-30 02:43:53 --> Model Class Initialized
DEBUG - 2011-04-30 02:43:53 --> Model Class Initialized
DEBUG - 2011-04-30 02:43:53 --> Model Class Initialized
DEBUG - 2011-04-30 02:43:53 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-30 02:43:53 --> Database Driver Class Initialized
DEBUG - 2011-04-30 02:43:54 --> File loaded: application/views/table/main.php
DEBUG - 2011-04-30 02:43:54 --> Helper loaded: url_helper
DEBUG - 2011-04-30 02:43:54 --> File loaded: application/views/common/header.php
DEBUG - 2011-04-30 02:43:54 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-04-30 02:43:54 --> File loaded: application/views/common/footer.php
DEBUG - 2011-04-30 02:43:54 --> File loaded: application/views/layout/main.php
DEBUG - 2011-04-30 02:43:54 --> Final output sent to browser
DEBUG - 2011-04-30 02:43:54 --> Total execution time: 1.3214
DEBUG - 2011-04-30 02:44:07 --> Config Class Initialized
DEBUG - 2011-04-30 02:44:07 --> Hooks Class Initialized
DEBUG - 2011-04-30 02:44:07 --> Utf8 Class Initialized
DEBUG - 2011-04-30 02:44:07 --> UTF-8 Support Enabled
DEBUG - 2011-04-30 02:44:07 --> URI Class Initialized
DEBUG - 2011-04-30 02:44:07 --> Router Class Initialized
DEBUG - 2011-04-30 02:44:07 --> Output Class Initialized
DEBUG - 2011-04-30 02:44:07 --> Input Class Initialized
DEBUG - 2011-04-30 02:44:07 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-30 02:44:07 --> Language Class Initialized
DEBUG - 2011-04-30 02:44:07 --> Loader Class Initialized
DEBUG - 2011-04-30 02:44:07 --> Controller Class Initialized
ERROR - 2011-04-30 02:44:07 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-04-30 02:44:07 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-04-30 02:44:07 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-04-30 02:44:07 --> Model Class Initialized
DEBUG - 2011-04-30 02:44:07 --> Model Class Initialized
DEBUG - 2011-04-30 02:44:07 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-30 02:44:07 --> Database Driver Class Initialized
DEBUG - 2011-04-30 02:44:07 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-04-30 02:44:07 --> Helper loaded: url_helper
DEBUG - 2011-04-30 02:44:07 --> File loaded: application/views/common/header.php
DEBUG - 2011-04-30 02:44:07 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-04-30 02:44:07 --> File loaded: application/views/common/footer.php
DEBUG - 2011-04-30 02:44:07 --> File loaded: application/views/layout/main.php
DEBUG - 2011-04-30 02:44:07 --> Final output sent to browser
DEBUG - 2011-04-30 02:44:07 --> Total execution time: 0.1897
DEBUG - 2011-04-30 03:06:34 --> Config Class Initialized
DEBUG - 2011-04-30 03:06:34 --> Hooks Class Initialized
DEBUG - 2011-04-30 03:06:34 --> Utf8 Class Initialized
DEBUG - 2011-04-30 03:06:34 --> UTF-8 Support Enabled
DEBUG - 2011-04-30 03:06:34 --> URI Class Initialized
DEBUG - 2011-04-30 03:06:34 --> Router Class Initialized
DEBUG - 2011-04-30 03:06:34 --> Output Class Initialized
DEBUG - 2011-04-30 03:06:34 --> Input Class Initialized
DEBUG - 2011-04-30 03:06:34 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-30 03:06:34 --> Language Class Initialized
DEBUG - 2011-04-30 03:06:34 --> Loader Class Initialized
DEBUG - 2011-04-30 03:06:34 --> Controller Class Initialized
DEBUG - 2011-04-30 03:06:34 --> Model Class Initialized
DEBUG - 2011-04-30 03:06:34 --> Model Class Initialized
DEBUG - 2011-04-30 03:06:34 --> Model Class Initialized
DEBUG - 2011-04-30 03:06:34 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-30 03:06:34 --> Database Driver Class Initialized
DEBUG - 2011-04-30 03:06:57 --> File loaded: application/views/table/main.php
DEBUG - 2011-04-30 03:06:57 --> Helper loaded: url_helper
DEBUG - 2011-04-30 03:06:57 --> File loaded: application/views/common/header.php
DEBUG - 2011-04-30 03:06:57 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-04-30 03:06:57 --> File loaded: application/views/common/footer.php
DEBUG - 2011-04-30 03:06:57 --> File loaded: application/views/layout/main.php
DEBUG - 2011-04-30 03:06:57 --> Final output sent to browser
DEBUG - 2011-04-30 03:06:57 --> Total execution time: 23.7055
DEBUG - 2011-04-30 03:08:40 --> Config Class Initialized
DEBUG - 2011-04-30 03:08:40 --> Hooks Class Initialized
DEBUG - 2011-04-30 03:08:40 --> Utf8 Class Initialized
DEBUG - 2011-04-30 03:08:40 --> UTF-8 Support Enabled
DEBUG - 2011-04-30 03:08:40 --> URI Class Initialized
DEBUG - 2011-04-30 03:08:40 --> Router Class Initialized
ERROR - 2011-04-30 03:08:40 --> 404 Page Not Found --> robots.txt
DEBUG - 2011-04-30 03:08:42 --> Config Class Initialized
DEBUG - 2011-04-30 03:08:42 --> Hooks Class Initialized
DEBUG - 2011-04-30 03:08:42 --> Utf8 Class Initialized
DEBUG - 2011-04-30 03:08:42 --> UTF-8 Support Enabled
DEBUG - 2011-04-30 03:08:42 --> URI Class Initialized
DEBUG - 2011-04-30 03:08:42 --> Router Class Initialized
DEBUG - 2011-04-30 03:08:42 --> Output Class Initialized
DEBUG - 2011-04-30 03:08:42 --> Input Class Initialized
DEBUG - 2011-04-30 03:08:42 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-30 03:08:42 --> Language Class Initialized
DEBUG - 2011-04-30 03:08:42 --> Loader Class Initialized
DEBUG - 2011-04-30 03:08:42 --> Controller Class Initialized
ERROR - 2011-04-30 03:08:42 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-04-30 03:08:42 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-04-30 03:08:42 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-04-30 03:08:42 --> Model Class Initialized
DEBUG - 2011-04-30 03:08:42 --> Model Class Initialized
DEBUG - 2011-04-30 03:08:42 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-30 03:08:42 --> Database Driver Class Initialized
DEBUG - 2011-04-30 03:08:42 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-04-30 03:08:42 --> Helper loaded: url_helper
DEBUG - 2011-04-30 03:08:42 --> File loaded: application/views/common/header.php
DEBUG - 2011-04-30 03:08:42 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-04-30 03:08:42 --> File loaded: application/views/common/footer.php
DEBUG - 2011-04-30 03:08:42 --> File loaded: application/views/layout/main.php
DEBUG - 2011-04-30 03:08:42 --> Final output sent to browser
DEBUG - 2011-04-30 03:08:42 --> Total execution time: 0.1568
DEBUG - 2011-04-30 03:08:44 --> Config Class Initialized
DEBUG - 2011-04-30 03:08:44 --> Hooks Class Initialized
DEBUG - 2011-04-30 03:08:44 --> Utf8 Class Initialized
DEBUG - 2011-04-30 03:08:44 --> UTF-8 Support Enabled
DEBUG - 2011-04-30 03:08:44 --> URI Class Initialized
DEBUG - 2011-04-30 03:08:44 --> Router Class Initialized
DEBUG - 2011-04-30 03:08:44 --> Output Class Initialized
DEBUG - 2011-04-30 03:08:44 --> Input Class Initialized
DEBUG - 2011-04-30 03:08:44 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-30 03:08:44 --> Language Class Initialized
DEBUG - 2011-04-30 03:08:44 --> Loader Class Initialized
DEBUG - 2011-04-30 03:08:44 --> Controller Class Initialized
DEBUG - 2011-04-30 03:08:44 --> Model Class Initialized
DEBUG - 2011-04-30 03:08:44 --> Model Class Initialized
DEBUG - 2011-04-30 03:08:44 --> Model Class Initialized
DEBUG - 2011-04-30 03:08:44 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-30 03:08:44 --> Database Driver Class Initialized
DEBUG - 2011-04-30 03:08:45 --> File loaded: application/views/table/main.php
DEBUG - 2011-04-30 03:08:45 --> Helper loaded: url_helper
DEBUG - 2011-04-30 03:08:45 --> File loaded: application/views/common/header.php
DEBUG - 2011-04-30 03:08:45 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-04-30 03:08:45 --> File loaded: application/views/common/footer.php
DEBUG - 2011-04-30 03:08:45 --> File loaded: application/views/layout/main.php
DEBUG - 2011-04-30 03:08:45 --> Final output sent to browser
DEBUG - 2011-04-30 03:08:45 --> Total execution time: 0.1072
DEBUG - 2011-04-30 03:16:24 --> Config Class Initialized
DEBUG - 2011-04-30 03:16:24 --> Hooks Class Initialized
DEBUG - 2011-04-30 03:16:24 --> Utf8 Class Initialized
DEBUG - 2011-04-30 03:16:24 --> UTF-8 Support Enabled
DEBUG - 2011-04-30 03:16:24 --> URI Class Initialized
DEBUG - 2011-04-30 03:16:24 --> Router Class Initialized
DEBUG - 2011-04-30 03:16:24 --> Output Class Initialized
DEBUG - 2011-04-30 03:16:24 --> Input Class Initialized
DEBUG - 2011-04-30 03:16:24 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-30 03:16:24 --> Language Class Initialized
DEBUG - 2011-04-30 03:16:24 --> Loader Class Initialized
DEBUG - 2011-04-30 03:16:24 --> Controller Class Initialized
DEBUG - 2011-04-30 03:16:24 --> Model Class Initialized
DEBUG - 2011-04-30 03:16:24 --> Model Class Initialized
DEBUG - 2011-04-30 03:16:24 --> Model Class Initialized
DEBUG - 2011-04-30 03:16:24 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-30 03:16:24 --> Database Driver Class Initialized
DEBUG - 2011-04-30 03:16:29 --> File loaded: application/views/table/main.php
DEBUG - 2011-04-30 03:16:29 --> Helper loaded: url_helper
DEBUG - 2011-04-30 03:16:29 --> File loaded: application/views/common/header.php
DEBUG - 2011-04-30 03:16:29 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-04-30 03:16:29 --> File loaded: application/views/common/footer.php
DEBUG - 2011-04-30 03:16:29 --> File loaded: application/views/layout/main.php
DEBUG - 2011-04-30 03:16:29 --> Final output sent to browser
DEBUG - 2011-04-30 03:16:29 --> Total execution time: 4.7210
DEBUG - 2011-04-30 03:20:31 --> Config Class Initialized
DEBUG - 2011-04-30 03:20:31 --> Hooks Class Initialized
DEBUG - 2011-04-30 03:20:31 --> Utf8 Class Initialized
DEBUG - 2011-04-30 03:20:31 --> UTF-8 Support Enabled
DEBUG - 2011-04-30 03:20:31 --> URI Class Initialized
DEBUG - 2011-04-30 03:20:31 --> Router Class Initialized
DEBUG - 2011-04-30 03:20:32 --> Output Class Initialized
DEBUG - 2011-04-30 03:20:32 --> Input Class Initialized
DEBUG - 2011-04-30 03:20:32 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-30 03:20:32 --> Language Class Initialized
DEBUG - 2011-04-30 03:20:32 --> Loader Class Initialized
DEBUG - 2011-04-30 03:20:32 --> Controller Class Initialized
DEBUG - 2011-04-30 03:20:32 --> Model Class Initialized
DEBUG - 2011-04-30 03:20:32 --> Model Class Initialized
DEBUG - 2011-04-30 03:20:32 --> Model Class Initialized
DEBUG - 2011-04-30 03:20:32 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-30 03:20:32 --> Database Driver Class Initialized
DEBUG - 2011-04-30 03:20:32 --> File loaded: application/views/table/main.php
DEBUG - 2011-04-30 03:20:32 --> Helper loaded: url_helper
DEBUG - 2011-04-30 03:20:32 --> File loaded: application/views/common/header.php
DEBUG - 2011-04-30 03:20:32 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-04-30 03:20:32 --> File loaded: application/views/common/footer.php
DEBUG - 2011-04-30 03:20:32 --> File loaded: application/views/layout/main.php
DEBUG - 2011-04-30 03:20:32 --> Final output sent to browser
DEBUG - 2011-04-30 03:20:32 --> Total execution time: 0.4891
DEBUG - 2011-04-30 03:20:37 --> Config Class Initialized
DEBUG - 2011-04-30 03:20:37 --> Hooks Class Initialized
DEBUG - 2011-04-30 03:20:37 --> Utf8 Class Initialized
DEBUG - 2011-04-30 03:20:37 --> UTF-8 Support Enabled
DEBUG - 2011-04-30 03:20:37 --> URI Class Initialized
DEBUG - 2011-04-30 03:20:37 --> Router Class Initialized
DEBUG - 2011-04-30 03:20:37 --> Output Class Initialized
DEBUG - 2011-04-30 03:20:37 --> Input Class Initialized
DEBUG - 2011-04-30 03:20:37 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-30 03:20:37 --> Language Class Initialized
DEBUG - 2011-04-30 03:20:37 --> Loader Class Initialized
DEBUG - 2011-04-30 03:20:37 --> Controller Class Initialized
ERROR - 2011-04-30 03:20:37 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-04-30 03:20:37 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-04-30 03:20:37 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-04-30 03:20:37 --> Model Class Initialized
DEBUG - 2011-04-30 03:20:37 --> Model Class Initialized
DEBUG - 2011-04-30 03:20:37 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-30 03:20:37 --> Database Driver Class Initialized
DEBUG - 2011-04-30 03:20:38 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-04-30 03:20:38 --> Helper loaded: url_helper
DEBUG - 2011-04-30 03:20:38 --> File loaded: application/views/common/header.php
DEBUG - 2011-04-30 03:20:38 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-04-30 03:20:38 --> File loaded: application/views/common/footer.php
DEBUG - 2011-04-30 03:20:38 --> File loaded: application/views/layout/main.php
DEBUG - 2011-04-30 03:20:38 --> Final output sent to browser
DEBUG - 2011-04-30 03:20:38 --> Total execution time: 0.6443
DEBUG - 2011-04-30 04:37:43 --> Config Class Initialized
DEBUG - 2011-04-30 04:37:43 --> Hooks Class Initialized
DEBUG - 2011-04-30 04:37:43 --> Utf8 Class Initialized
DEBUG - 2011-04-30 04:37:43 --> UTF-8 Support Enabled
DEBUG - 2011-04-30 04:37:43 --> URI Class Initialized
DEBUG - 2011-04-30 04:37:43 --> Router Class Initialized
DEBUG - 2011-04-30 04:37:43 --> Output Class Initialized
DEBUG - 2011-04-30 04:37:43 --> Input Class Initialized
DEBUG - 2011-04-30 04:37:43 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-30 04:37:43 --> Language Class Initialized
DEBUG - 2011-04-30 04:37:43 --> Loader Class Initialized
DEBUG - 2011-04-30 04:37:43 --> Controller Class Initialized
DEBUG - 2011-04-30 04:37:43 --> Model Class Initialized
DEBUG - 2011-04-30 04:37:43 --> Model Class Initialized
DEBUG - 2011-04-30 04:37:43 --> Model Class Initialized
DEBUG - 2011-04-30 04:37:43 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-30 04:37:43 --> Database Driver Class Initialized
DEBUG - 2011-04-30 04:37:48 --> File loaded: application/views/table/main.php
DEBUG - 2011-04-30 04:37:48 --> Helper loaded: url_helper
DEBUG - 2011-04-30 04:37:48 --> File loaded: application/views/common/header.php
DEBUG - 2011-04-30 04:37:48 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-04-30 04:37:48 --> File loaded: application/views/common/footer.php
DEBUG - 2011-04-30 04:37:48 --> File loaded: application/views/layout/main.php
DEBUG - 2011-04-30 04:37:48 --> Final output sent to browser
DEBUG - 2011-04-30 04:37:48 --> Total execution time: 6.0670
DEBUG - 2011-04-30 04:37:49 --> Config Class Initialized
DEBUG - 2011-04-30 04:37:49 --> Hooks Class Initialized
DEBUG - 2011-04-30 04:37:49 --> Utf8 Class Initialized
DEBUG - 2011-04-30 04:37:49 --> UTF-8 Support Enabled
DEBUG - 2011-04-30 04:37:49 --> URI Class Initialized
DEBUG - 2011-04-30 04:37:50 --> Router Class Initialized
DEBUG - 2011-04-30 04:37:50 --> Output Class Initialized
DEBUG - 2011-04-30 04:37:50 --> Input Class Initialized
DEBUG - 2011-04-30 04:37:50 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-30 04:37:50 --> Language Class Initialized
DEBUG - 2011-04-30 04:37:50 --> Loader Class Initialized
DEBUG - 2011-04-30 04:37:50 --> Controller Class Initialized
ERROR - 2011-04-30 04:37:50 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-04-30 04:37:50 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-04-30 04:37:50 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-04-30 04:37:50 --> Model Class Initialized
DEBUG - 2011-04-30 04:37:50 --> Model Class Initialized
DEBUG - 2011-04-30 04:37:50 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-30 04:37:50 --> Database Driver Class Initialized
DEBUG - 2011-04-30 04:37:50 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-04-30 04:37:50 --> Helper loaded: url_helper
DEBUG - 2011-04-30 04:37:50 --> File loaded: application/views/common/header.php
DEBUG - 2011-04-30 04:37:50 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-04-30 04:37:50 --> File loaded: application/views/common/footer.php
DEBUG - 2011-04-30 04:37:50 --> File loaded: application/views/layout/main.php
DEBUG - 2011-04-30 04:37:50 --> Final output sent to browser
DEBUG - 2011-04-30 04:37:50 --> Total execution time: 0.2572
DEBUG - 2011-04-30 05:21:31 --> Config Class Initialized
DEBUG - 2011-04-30 05:21:31 --> Hooks Class Initialized
DEBUG - 2011-04-30 05:21:31 --> Utf8 Class Initialized
DEBUG - 2011-04-30 05:21:31 --> UTF-8 Support Enabled
DEBUG - 2011-04-30 05:21:31 --> URI Class Initialized
DEBUG - 2011-04-30 05:21:31 --> Router Class Initialized
DEBUG - 2011-04-30 05:21:31 --> Output Class Initialized
DEBUG - 2011-04-30 05:21:31 --> Input Class Initialized
DEBUG - 2011-04-30 05:21:31 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-30 05:21:31 --> Language Class Initialized
DEBUG - 2011-04-30 05:21:31 --> Loader Class Initialized
DEBUG - 2011-04-30 05:21:31 --> Controller Class Initialized
ERROR - 2011-04-30 05:21:31 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-04-30 05:21:31 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-04-30 05:21:31 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-04-30 05:21:31 --> Model Class Initialized
DEBUG - 2011-04-30 05:21:31 --> Model Class Initialized
DEBUG - 2011-04-30 05:21:31 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-30 05:21:31 --> Database Driver Class Initialized
DEBUG - 2011-04-30 05:21:31 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-04-30 05:21:31 --> Helper loaded: url_helper
DEBUG - 2011-04-30 05:21:31 --> File loaded: application/views/common/header.php
DEBUG - 2011-04-30 05:21:31 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-04-30 05:21:31 --> File loaded: application/views/common/footer.php
DEBUG - 2011-04-30 05:21:31 --> File loaded: application/views/layout/main.php
DEBUG - 2011-04-30 05:21:31 --> Final output sent to browser
DEBUG - 2011-04-30 05:21:31 --> Total execution time: 0.3736
DEBUG - 2011-04-30 05:21:32 --> Config Class Initialized
DEBUG - 2011-04-30 05:21:32 --> Hooks Class Initialized
DEBUG - 2011-04-30 05:21:32 --> Utf8 Class Initialized
DEBUG - 2011-04-30 05:21:32 --> UTF-8 Support Enabled
DEBUG - 2011-04-30 05:21:32 --> URI Class Initialized
DEBUG - 2011-04-30 05:21:32 --> Router Class Initialized
DEBUG - 2011-04-30 05:21:32 --> Output Class Initialized
DEBUG - 2011-04-30 05:21:32 --> Input Class Initialized
DEBUG - 2011-04-30 05:21:32 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-30 05:21:32 --> Language Class Initialized
DEBUG - 2011-04-30 05:21:32 --> Loader Class Initialized
DEBUG - 2011-04-30 05:21:32 --> Controller Class Initialized
DEBUG - 2011-04-30 05:21:32 --> Model Class Initialized
DEBUG - 2011-04-30 05:21:32 --> Model Class Initialized
DEBUG - 2011-04-30 05:21:32 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-30 05:21:32 --> Database Driver Class Initialized
DEBUG - 2011-04-30 05:21:34 --> Final output sent to browser
DEBUG - 2011-04-30 05:21:34 --> Total execution time: 2.0559
DEBUG - 2011-04-30 05:21:36 --> Config Class Initialized
DEBUG - 2011-04-30 05:21:36 --> Hooks Class Initialized
DEBUG - 2011-04-30 05:21:36 --> Utf8 Class Initialized
DEBUG - 2011-04-30 05:21:36 --> UTF-8 Support Enabled
DEBUG - 2011-04-30 05:21:36 --> URI Class Initialized
DEBUG - 2011-04-30 05:21:36 --> Router Class Initialized
ERROR - 2011-04-30 05:21:36 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-04-30 05:21:39 --> Config Class Initialized
DEBUG - 2011-04-30 05:21:39 --> Hooks Class Initialized
DEBUG - 2011-04-30 05:21:39 --> Utf8 Class Initialized
DEBUG - 2011-04-30 05:21:39 --> UTF-8 Support Enabled
DEBUG - 2011-04-30 05:21:39 --> URI Class Initialized
DEBUG - 2011-04-30 05:21:39 --> Router Class Initialized
ERROR - 2011-04-30 05:21:39 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-04-30 05:54:50 --> Config Class Initialized
DEBUG - 2011-04-30 05:54:50 --> Hooks Class Initialized
DEBUG - 2011-04-30 05:54:50 --> Utf8 Class Initialized
DEBUG - 2011-04-30 05:54:50 --> UTF-8 Support Enabled
DEBUG - 2011-04-30 05:54:50 --> URI Class Initialized
DEBUG - 2011-04-30 05:54:50 --> Router Class Initialized
ERROR - 2011-04-30 05:54:50 --> 404 Page Not Found --> robots.txt
DEBUG - 2011-04-30 05:54:51 --> Config Class Initialized
DEBUG - 2011-04-30 05:54:51 --> Hooks Class Initialized
DEBUG - 2011-04-30 05:54:51 --> Utf8 Class Initialized
DEBUG - 2011-04-30 05:54:51 --> UTF-8 Support Enabled
DEBUG - 2011-04-30 05:54:51 --> URI Class Initialized
DEBUG - 2011-04-30 05:54:51 --> Router Class Initialized
DEBUG - 2011-04-30 05:54:51 --> No URI present. Default controller set.
DEBUG - 2011-04-30 05:54:51 --> Output Class Initialized
DEBUG - 2011-04-30 05:54:51 --> Input Class Initialized
DEBUG - 2011-04-30 05:54:51 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-30 05:54:51 --> Language Class Initialized
DEBUG - 2011-04-30 05:54:51 --> Loader Class Initialized
DEBUG - 2011-04-30 05:54:51 --> Controller Class Initialized
DEBUG - 2011-04-30 05:54:51 --> File loaded: application/views/splash/main.php
DEBUG - 2011-04-30 05:54:51 --> Helper loaded: url_helper
DEBUG - 2011-04-30 05:54:51 --> File loaded: application/views/common/header.php
DEBUG - 2011-04-30 05:54:51 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-04-30 05:54:51 --> File loaded: application/views/common/footer.php
DEBUG - 2011-04-30 05:54:51 --> File loaded: application/views/layout/main.php
DEBUG - 2011-04-30 05:54:51 --> Final output sent to browser
DEBUG - 2011-04-30 05:54:51 --> Total execution time: 0.2039
DEBUG - 2011-04-30 07:18:58 --> Config Class Initialized
DEBUG - 2011-04-30 07:18:58 --> Hooks Class Initialized
DEBUG - 2011-04-30 07:18:58 --> Utf8 Class Initialized
DEBUG - 2011-04-30 07:18:58 --> UTF-8 Support Enabled
DEBUG - 2011-04-30 07:18:58 --> URI Class Initialized
DEBUG - 2011-04-30 07:18:58 --> Router Class Initialized
DEBUG - 2011-04-30 07:18:58 --> Output Class Initialized
DEBUG - 2011-04-30 07:18:58 --> Input Class Initialized
DEBUG - 2011-04-30 07:18:58 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-30 07:18:58 --> Language Class Initialized
DEBUG - 2011-04-30 07:18:58 --> Loader Class Initialized
DEBUG - 2011-04-30 07:18:58 --> Controller Class Initialized
DEBUG - 2011-04-30 07:18:58 --> Model Class Initialized
DEBUG - 2011-04-30 07:18:58 --> Model Class Initialized
DEBUG - 2011-04-30 07:18:58 --> Model Class Initialized
DEBUG - 2011-04-30 07:18:58 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-30 07:18:58 --> Database Driver Class Initialized
DEBUG - 2011-04-30 07:18:58 --> File loaded: application/views/table/main.php
DEBUG - 2011-04-30 07:18:59 --> Helper loaded: url_helper
DEBUG - 2011-04-30 07:18:59 --> File loaded: application/views/common/header.php
DEBUG - 2011-04-30 07:18:59 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-04-30 07:18:59 --> File loaded: application/views/common/footer.php
DEBUG - 2011-04-30 07:18:59 --> File loaded: application/views/layout/main.php
DEBUG - 2011-04-30 07:18:59 --> Final output sent to browser
DEBUG - 2011-04-30 07:18:59 --> Total execution time: 0.6271
DEBUG - 2011-04-30 07:19:00 --> Config Class Initialized
DEBUG - 2011-04-30 07:19:00 --> Hooks Class Initialized
DEBUG - 2011-04-30 07:19:00 --> Utf8 Class Initialized
DEBUG - 2011-04-30 07:19:00 --> UTF-8 Support Enabled
DEBUG - 2011-04-30 07:19:00 --> URI Class Initialized
DEBUG - 2011-04-30 07:19:00 --> Router Class Initialized
DEBUG - 2011-04-30 07:19:00 --> Output Class Initialized
DEBUG - 2011-04-30 07:19:00 --> Input Class Initialized
DEBUG - 2011-04-30 07:19:00 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-30 07:19:00 --> Language Class Initialized
DEBUG - 2011-04-30 07:19:00 --> Loader Class Initialized
DEBUG - 2011-04-30 07:19:00 --> Controller Class Initialized
ERROR - 2011-04-30 07:19:00 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-04-30 07:19:00 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-04-30 07:19:00 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-04-30 07:19:00 --> Model Class Initialized
DEBUG - 2011-04-30 07:19:00 --> Model Class Initialized
DEBUG - 2011-04-30 07:19:00 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-30 07:19:00 --> Database Driver Class Initialized
DEBUG - 2011-04-30 07:19:00 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-04-30 07:19:00 --> Helper loaded: url_helper
DEBUG - 2011-04-30 07:19:00 --> File loaded: application/views/common/header.php
DEBUG - 2011-04-30 07:19:00 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-04-30 07:19:00 --> File loaded: application/views/common/footer.php
DEBUG - 2011-04-30 07:19:00 --> File loaded: application/views/layout/main.php
DEBUG - 2011-04-30 07:19:00 --> Final output sent to browser
DEBUG - 2011-04-30 07:19:00 --> Total execution time: 0.1179
DEBUG - 2011-04-30 07:26:02 --> Config Class Initialized
DEBUG - 2011-04-30 07:26:02 --> Hooks Class Initialized
DEBUG - 2011-04-30 07:26:02 --> Utf8 Class Initialized
DEBUG - 2011-04-30 07:26:02 --> UTF-8 Support Enabled
DEBUG - 2011-04-30 07:26:02 --> URI Class Initialized
DEBUG - 2011-04-30 07:26:02 --> Router Class Initialized
DEBUG - 2011-04-30 07:26:02 --> Output Class Initialized
DEBUG - 2011-04-30 07:26:02 --> Input Class Initialized
DEBUG - 2011-04-30 07:26:02 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-30 07:26:02 --> Language Class Initialized
DEBUG - 2011-04-30 07:26:02 --> Loader Class Initialized
DEBUG - 2011-04-30 07:26:02 --> Controller Class Initialized
DEBUG - 2011-04-30 07:26:02 --> Model Class Initialized
DEBUG - 2011-04-30 07:26:02 --> Model Class Initialized
DEBUG - 2011-04-30 07:26:02 --> Model Class Initialized
DEBUG - 2011-04-30 07:26:02 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-30 07:26:02 --> Database Driver Class Initialized
DEBUG - 2011-04-30 07:26:02 --> File loaded: application/views/table/main.php
DEBUG - 2011-04-30 07:26:02 --> Helper loaded: url_helper
DEBUG - 2011-04-30 07:26:02 --> File loaded: application/views/common/header.php
DEBUG - 2011-04-30 07:26:02 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-04-30 07:26:02 --> File loaded: application/views/common/footer.php
DEBUG - 2011-04-30 07:26:02 --> File loaded: application/views/layout/main.php
DEBUG - 2011-04-30 07:26:02 --> Final output sent to browser
DEBUG - 2011-04-30 07:26:02 --> Total execution time: 0.1058
DEBUG - 2011-04-30 07:26:04 --> Config Class Initialized
DEBUG - 2011-04-30 07:26:04 --> Hooks Class Initialized
DEBUG - 2011-04-30 07:26:04 --> Utf8 Class Initialized
DEBUG - 2011-04-30 07:26:04 --> UTF-8 Support Enabled
DEBUG - 2011-04-30 07:26:04 --> URI Class Initialized
DEBUG - 2011-04-30 07:26:04 --> Router Class Initialized
ERROR - 2011-04-30 07:26:04 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-04-30 07:26:05 --> Config Class Initialized
DEBUG - 2011-04-30 07:26:05 --> Hooks Class Initialized
DEBUG - 2011-04-30 07:26:05 --> Utf8 Class Initialized
DEBUG - 2011-04-30 07:26:05 --> UTF-8 Support Enabled
DEBUG - 2011-04-30 07:26:05 --> URI Class Initialized
DEBUG - 2011-04-30 07:26:05 --> Router Class Initialized
ERROR - 2011-04-30 07:26:05 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-04-30 07:26:35 --> Config Class Initialized
DEBUG - 2011-04-30 07:26:35 --> Hooks Class Initialized
DEBUG - 2011-04-30 07:26:35 --> Utf8 Class Initialized
DEBUG - 2011-04-30 07:26:35 --> UTF-8 Support Enabled
DEBUG - 2011-04-30 07:26:35 --> URI Class Initialized
DEBUG - 2011-04-30 07:26:35 --> Router Class Initialized
DEBUG - 2011-04-30 07:26:35 --> Output Class Initialized
DEBUG - 2011-04-30 07:26:35 --> Input Class Initialized
DEBUG - 2011-04-30 07:26:35 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-30 07:26:35 --> Language Class Initialized
DEBUG - 2011-04-30 07:26:35 --> Loader Class Initialized
DEBUG - 2011-04-30 07:26:35 --> Controller Class Initialized
DEBUG - 2011-04-30 07:26:35 --> Model Class Initialized
DEBUG - 2011-04-30 07:26:35 --> Model Class Initialized
DEBUG - 2011-04-30 07:26:35 --> Model Class Initialized
DEBUG - 2011-04-30 07:26:35 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-30 07:26:35 --> Database Driver Class Initialized
DEBUG - 2011-04-30 07:26:35 --> File loaded: application/views/table/main.php
DEBUG - 2011-04-30 07:26:35 --> Helper loaded: url_helper
DEBUG - 2011-04-30 07:26:35 --> File loaded: application/views/common/header.php
DEBUG - 2011-04-30 07:26:35 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-04-30 07:26:35 --> File loaded: application/views/common/footer.php
DEBUG - 2011-04-30 07:26:35 --> File loaded: application/views/layout/main.php
DEBUG - 2011-04-30 07:26:35 --> Final output sent to browser
DEBUG - 2011-04-30 07:26:35 --> Total execution time: 0.1181
DEBUG - 2011-04-30 07:45:34 --> Config Class Initialized
DEBUG - 2011-04-30 07:45:34 --> Hooks Class Initialized
DEBUG - 2011-04-30 07:45:34 --> Utf8 Class Initialized
DEBUG - 2011-04-30 07:45:34 --> UTF-8 Support Enabled
DEBUG - 2011-04-30 07:45:34 --> URI Class Initialized
DEBUG - 2011-04-30 07:45:34 --> Router Class Initialized
DEBUG - 2011-04-30 07:45:34 --> Output Class Initialized
DEBUG - 2011-04-30 07:45:34 --> Input Class Initialized
DEBUG - 2011-04-30 07:45:34 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-30 07:45:34 --> Language Class Initialized
DEBUG - 2011-04-30 07:45:34 --> Loader Class Initialized
DEBUG - 2011-04-30 07:45:34 --> Controller Class Initialized
ERROR - 2011-04-30 07:45:35 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-04-30 07:45:35 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-04-30 07:45:35 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-04-30 07:45:35 --> Model Class Initialized
DEBUG - 2011-04-30 07:45:35 --> Model Class Initialized
DEBUG - 2011-04-30 07:45:35 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-30 07:45:35 --> Database Driver Class Initialized
DEBUG - 2011-04-30 07:45:35 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-04-30 07:45:35 --> Helper loaded: url_helper
DEBUG - 2011-04-30 07:45:35 --> File loaded: application/views/common/header.php
DEBUG - 2011-04-30 07:45:35 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-04-30 07:45:35 --> File loaded: application/views/common/footer.php
DEBUG - 2011-04-30 07:45:35 --> File loaded: application/views/layout/main.php
DEBUG - 2011-04-30 07:45:35 --> Final output sent to browser
DEBUG - 2011-04-30 07:45:35 --> Total execution time: 0.3642
DEBUG - 2011-04-30 07:45:36 --> Config Class Initialized
DEBUG - 2011-04-30 07:45:36 --> Hooks Class Initialized
DEBUG - 2011-04-30 07:45:36 --> Utf8 Class Initialized
DEBUG - 2011-04-30 07:45:36 --> UTF-8 Support Enabled
DEBUG - 2011-04-30 07:45:36 --> URI Class Initialized
DEBUG - 2011-04-30 07:45:36 --> Router Class Initialized
DEBUG - 2011-04-30 07:45:36 --> Output Class Initialized
DEBUG - 2011-04-30 07:45:36 --> Input Class Initialized
DEBUG - 2011-04-30 07:45:36 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-30 07:45:36 --> Language Class Initialized
DEBUG - 2011-04-30 07:45:36 --> Loader Class Initialized
DEBUG - 2011-04-30 07:45:36 --> Controller Class Initialized
DEBUG - 2011-04-30 07:45:36 --> Model Class Initialized
DEBUG - 2011-04-30 07:45:36 --> Model Class Initialized
DEBUG - 2011-04-30 07:45:36 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-30 07:45:36 --> Database Driver Class Initialized
DEBUG - 2011-04-30 07:45:37 --> Final output sent to browser
DEBUG - 2011-04-30 07:45:37 --> Total execution time: 0.7391
DEBUG - 2011-04-30 07:45:38 --> Config Class Initialized
DEBUG - 2011-04-30 07:45:38 --> Hooks Class Initialized
DEBUG - 2011-04-30 07:45:38 --> Utf8 Class Initialized
DEBUG - 2011-04-30 07:45:38 --> UTF-8 Support Enabled
DEBUG - 2011-04-30 07:45:38 --> URI Class Initialized
DEBUG - 2011-04-30 07:45:38 --> Router Class Initialized
DEBUG - 2011-04-30 07:45:38 --> Output Class Initialized
DEBUG - 2011-04-30 07:45:38 --> Input Class Initialized
DEBUG - 2011-04-30 07:45:38 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-30 07:45:38 --> Language Class Initialized
DEBUG - 2011-04-30 07:45:38 --> Loader Class Initialized
DEBUG - 2011-04-30 07:45:38 --> Controller Class Initialized
ERROR - 2011-04-30 07:45:38 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-04-30 07:45:38 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-04-30 07:45:38 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-04-30 07:45:38 --> Model Class Initialized
DEBUG - 2011-04-30 07:45:38 --> Model Class Initialized
DEBUG - 2011-04-30 07:45:38 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-30 07:45:38 --> Database Driver Class Initialized
DEBUG - 2011-04-30 07:45:38 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-04-30 07:45:38 --> Helper loaded: url_helper
DEBUG - 2011-04-30 07:45:38 --> File loaded: application/views/common/header.php
DEBUG - 2011-04-30 07:45:38 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-04-30 07:45:38 --> File loaded: application/views/common/footer.php
DEBUG - 2011-04-30 07:45:38 --> File loaded: application/views/layout/main.php
DEBUG - 2011-04-30 07:45:38 --> Final output sent to browser
DEBUG - 2011-04-30 07:45:38 --> Total execution time: 0.0304
DEBUG - 2011-04-30 08:34:12 --> Config Class Initialized
DEBUG - 2011-04-30 08:34:12 --> Hooks Class Initialized
DEBUG - 2011-04-30 08:34:12 --> Utf8 Class Initialized
DEBUG - 2011-04-30 08:34:12 --> UTF-8 Support Enabled
DEBUG - 2011-04-30 08:34:12 --> URI Class Initialized
DEBUG - 2011-04-30 08:34:12 --> Router Class Initialized
DEBUG - 2011-04-30 08:34:12 --> No URI present. Default controller set.
DEBUG - 2011-04-30 08:34:12 --> Output Class Initialized
DEBUG - 2011-04-30 08:34:12 --> Input Class Initialized
DEBUG - 2011-04-30 08:34:12 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-30 08:34:12 --> Language Class Initialized
DEBUG - 2011-04-30 08:34:12 --> Loader Class Initialized
DEBUG - 2011-04-30 08:34:12 --> Controller Class Initialized
DEBUG - 2011-04-30 08:34:12 --> File loaded: application/views/splash/main.php
DEBUG - 2011-04-30 08:34:12 --> Helper loaded: url_helper
DEBUG - 2011-04-30 08:34:12 --> File loaded: application/views/common/header.php
DEBUG - 2011-04-30 08:34:12 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-04-30 08:34:12 --> File loaded: application/views/common/footer.php
DEBUG - 2011-04-30 08:34:12 --> File loaded: application/views/layout/main.php
DEBUG - 2011-04-30 08:34:12 --> Final output sent to browser
DEBUG - 2011-04-30 08:34:12 --> Total execution time: 0.3009
DEBUG - 2011-04-30 08:34:13 --> Config Class Initialized
DEBUG - 2011-04-30 08:34:13 --> Hooks Class Initialized
DEBUG - 2011-04-30 08:34:13 --> Utf8 Class Initialized
DEBUG - 2011-04-30 08:34:13 --> UTF-8 Support Enabled
DEBUG - 2011-04-30 08:34:13 --> URI Class Initialized
DEBUG - 2011-04-30 08:34:13 --> Router Class Initialized
ERROR - 2011-04-30 08:34:13 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-04-30 08:34:13 --> Config Class Initialized
DEBUG - 2011-04-30 08:34:13 --> Hooks Class Initialized
DEBUG - 2011-04-30 08:34:13 --> Utf8 Class Initialized
DEBUG - 2011-04-30 08:34:13 --> UTF-8 Support Enabled
DEBUG - 2011-04-30 08:34:13 --> URI Class Initialized
DEBUG - 2011-04-30 08:34:13 --> Router Class Initialized
ERROR - 2011-04-30 08:34:13 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-04-30 08:34:19 --> Config Class Initialized
DEBUG - 2011-04-30 08:34:19 --> Hooks Class Initialized
DEBUG - 2011-04-30 08:34:19 --> Utf8 Class Initialized
DEBUG - 2011-04-30 08:34:19 --> UTF-8 Support Enabled
DEBUG - 2011-04-30 08:34:19 --> URI Class Initialized
DEBUG - 2011-04-30 08:34:19 --> Router Class Initialized
DEBUG - 2011-04-30 08:34:19 --> Output Class Initialized
DEBUG - 2011-04-30 08:34:19 --> Input Class Initialized
DEBUG - 2011-04-30 08:34:19 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-30 08:34:19 --> Language Class Initialized
DEBUG - 2011-04-30 08:34:19 --> Loader Class Initialized
DEBUG - 2011-04-30 08:34:19 --> Controller Class Initialized
DEBUG - 2011-04-30 08:34:19 --> Model Class Initialized
DEBUG - 2011-04-30 08:34:19 --> Model Class Initialized
DEBUG - 2011-04-30 08:34:19 --> Model Class Initialized
DEBUG - 2011-04-30 08:34:19 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-30 08:34:19 --> Database Driver Class Initialized
DEBUG - 2011-04-30 08:34:19 --> File loaded: application/views/table/main.php
DEBUG - 2011-04-30 08:34:19 --> Helper loaded: url_helper
DEBUG - 2011-04-30 08:34:19 --> File loaded: application/views/common/header.php
DEBUG - 2011-04-30 08:34:19 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-04-30 08:34:19 --> File loaded: application/views/common/footer.php
DEBUG - 2011-04-30 08:34:19 --> File loaded: application/views/layout/main.php
DEBUG - 2011-04-30 08:34:19 --> Final output sent to browser
DEBUG - 2011-04-30 08:34:19 --> Total execution time: 0.4426
DEBUG - 2011-04-30 08:34:20 --> Config Class Initialized
DEBUG - 2011-04-30 08:34:20 --> Hooks Class Initialized
DEBUG - 2011-04-30 08:34:20 --> Utf8 Class Initialized
DEBUG - 2011-04-30 08:34:20 --> UTF-8 Support Enabled
DEBUG - 2011-04-30 08:34:20 --> URI Class Initialized
DEBUG - 2011-04-30 08:34:20 --> Router Class Initialized
ERROR - 2011-04-30 08:34:20 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-04-30 08:34:29 --> Config Class Initialized
DEBUG - 2011-04-30 08:34:29 --> Hooks Class Initialized
DEBUG - 2011-04-30 08:34:29 --> Utf8 Class Initialized
DEBUG - 2011-04-30 08:34:29 --> UTF-8 Support Enabled
DEBUG - 2011-04-30 08:34:29 --> URI Class Initialized
DEBUG - 2011-04-30 08:34:29 --> Router Class Initialized
DEBUG - 2011-04-30 08:34:29 --> Output Class Initialized
DEBUG - 2011-04-30 08:34:29 --> Input Class Initialized
DEBUG - 2011-04-30 08:34:29 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-30 08:34:29 --> Language Class Initialized
DEBUG - 2011-04-30 08:34:29 --> Loader Class Initialized
DEBUG - 2011-04-30 08:34:29 --> Controller Class Initialized
DEBUG - 2011-04-30 08:34:29 --> Model Class Initialized
DEBUG - 2011-04-30 08:34:29 --> Model Class Initialized
DEBUG - 2011-04-30 08:34:29 --> Model Class Initialized
DEBUG - 2011-04-30 08:34:29 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-30 08:34:29 --> Database Driver Class Initialized
DEBUG - 2011-04-30 08:34:30 --> File loaded: application/views/table/main.php
DEBUG - 2011-04-30 08:34:30 --> Helper loaded: url_helper
DEBUG - 2011-04-30 08:34:30 --> File loaded: application/views/common/header.php
DEBUG - 2011-04-30 08:34:30 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-04-30 08:34:30 --> File loaded: application/views/common/footer.php
DEBUG - 2011-04-30 08:34:30 --> File loaded: application/views/layout/main.php
DEBUG - 2011-04-30 08:34:30 --> Final output sent to browser
DEBUG - 2011-04-30 08:34:30 --> Total execution time: 0.3427
DEBUG - 2011-04-30 08:34:31 --> Config Class Initialized
DEBUG - 2011-04-30 08:34:31 --> Hooks Class Initialized
DEBUG - 2011-04-30 08:34:31 --> Utf8 Class Initialized
DEBUG - 2011-04-30 08:34:31 --> UTF-8 Support Enabled
DEBUG - 2011-04-30 08:34:31 --> URI Class Initialized
DEBUG - 2011-04-30 08:34:31 --> Router Class Initialized
DEBUG - 2011-04-30 08:34:31 --> Output Class Initialized
DEBUG - 2011-04-30 08:34:31 --> Input Class Initialized
DEBUG - 2011-04-30 08:34:31 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-30 08:34:31 --> Language Class Initialized
DEBUG - 2011-04-30 08:34:31 --> Loader Class Initialized
DEBUG - 2011-04-30 08:34:31 --> Controller Class Initialized
DEBUG - 2011-04-30 08:34:31 --> Model Class Initialized
DEBUG - 2011-04-30 08:34:31 --> Model Class Initialized
DEBUG - 2011-04-30 08:34:31 --> Model Class Initialized
DEBUG - 2011-04-30 08:34:31 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-30 08:34:31 --> Config Class Initialized
DEBUG - 2011-04-30 08:34:31 --> Hooks Class Initialized
DEBUG - 2011-04-30 08:34:31 --> Utf8 Class Initialized
DEBUG - 2011-04-30 08:34:31 --> UTF-8 Support Enabled
DEBUG - 2011-04-30 08:34:31 --> URI Class Initialized
DEBUG - 2011-04-30 08:34:31 --> Database Driver Class Initialized
DEBUG - 2011-04-30 08:34:31 --> Router Class Initialized
ERROR - 2011-04-30 08:34:31 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-04-30 08:34:31 --> File loaded: application/views/table/main.php
DEBUG - 2011-04-30 08:34:31 --> Helper loaded: url_helper
DEBUG - 2011-04-30 08:34:31 --> File loaded: application/views/common/header.php
DEBUG - 2011-04-30 08:34:31 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-04-30 08:34:31 --> File loaded: application/views/common/footer.php
DEBUG - 2011-04-30 08:34:31 --> File loaded: application/views/layout/main.php
DEBUG - 2011-04-30 08:34:31 --> Final output sent to browser
DEBUG - 2011-04-30 08:34:31 --> Total execution time: 0.0523
DEBUG - 2011-04-30 08:34:49 --> Config Class Initialized
DEBUG - 2011-04-30 08:34:49 --> Hooks Class Initialized
DEBUG - 2011-04-30 08:34:49 --> Utf8 Class Initialized
DEBUG - 2011-04-30 08:34:49 --> UTF-8 Support Enabled
DEBUG - 2011-04-30 08:34:49 --> URI Class Initialized
DEBUG - 2011-04-30 08:34:49 --> Router Class Initialized
DEBUG - 2011-04-30 08:34:49 --> Output Class Initialized
DEBUG - 2011-04-30 08:34:49 --> Input Class Initialized
DEBUG - 2011-04-30 08:34:49 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-30 08:34:49 --> Language Class Initialized
DEBUG - 2011-04-30 08:34:49 --> Loader Class Initialized
DEBUG - 2011-04-30 08:34:49 --> Controller Class Initialized
DEBUG - 2011-04-30 08:34:49 --> Model Class Initialized
DEBUG - 2011-04-30 08:34:49 --> Model Class Initialized
DEBUG - 2011-04-30 08:34:49 --> Model Class Initialized
DEBUG - 2011-04-30 08:34:49 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-30 08:34:49 --> Database Driver Class Initialized
DEBUG - 2011-04-30 08:34:49 --> File loaded: application/views/table/main.php
DEBUG - 2011-04-30 08:34:49 --> Helper loaded: url_helper
DEBUG - 2011-04-30 08:34:49 --> File loaded: application/views/common/header.php
DEBUG - 2011-04-30 08:34:49 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-04-30 08:34:49 --> File loaded: application/views/common/footer.php
DEBUG - 2011-04-30 08:34:49 --> File loaded: application/views/layout/main.php
DEBUG - 2011-04-30 08:34:49 --> Final output sent to browser
DEBUG - 2011-04-30 08:34:49 --> Total execution time: 0.6200
DEBUG - 2011-04-30 08:34:51 --> Config Class Initialized
DEBUG - 2011-04-30 08:34:51 --> Hooks Class Initialized
DEBUG - 2011-04-30 08:34:51 --> Utf8 Class Initialized
DEBUG - 2011-04-30 08:34:51 --> UTF-8 Support Enabled
DEBUG - 2011-04-30 08:34:51 --> URI Class Initialized
DEBUG - 2011-04-30 08:34:51 --> Router Class Initialized
DEBUG - 2011-04-30 08:34:51 --> Output Class Initialized
DEBUG - 2011-04-30 08:34:51 --> Input Class Initialized
DEBUG - 2011-04-30 08:34:51 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-30 08:34:51 --> Language Class Initialized
DEBUG - 2011-04-30 08:34:51 --> Loader Class Initialized
DEBUG - 2011-04-30 08:34:51 --> Controller Class Initialized
DEBUG - 2011-04-30 08:34:51 --> Model Class Initialized
DEBUG - 2011-04-30 08:34:51 --> Model Class Initialized
DEBUG - 2011-04-30 08:34:51 --> Model Class Initialized
DEBUG - 2011-04-30 08:34:51 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-30 08:34:51 --> Database Driver Class Initialized
DEBUG - 2011-04-30 08:34:51 --> File loaded: application/views/table/main.php
DEBUG - 2011-04-30 08:34:51 --> Helper loaded: url_helper
DEBUG - 2011-04-30 08:34:51 --> File loaded: application/views/common/header.php
DEBUG - 2011-04-30 08:34:51 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-04-30 08:34:51 --> File loaded: application/views/common/footer.php
DEBUG - 2011-04-30 08:34:51 --> File loaded: application/views/layout/main.php
DEBUG - 2011-04-30 08:34:51 --> Final output sent to browser
DEBUG - 2011-04-30 08:34:51 --> Total execution time: 0.0754
DEBUG - 2011-04-30 08:34:51 --> Config Class Initialized
DEBUG - 2011-04-30 08:34:51 --> Hooks Class Initialized
DEBUG - 2011-04-30 08:34:51 --> Utf8 Class Initialized
DEBUG - 2011-04-30 08:34:51 --> UTF-8 Support Enabled
DEBUG - 2011-04-30 08:34:51 --> URI Class Initialized
DEBUG - 2011-04-30 08:34:51 --> Router Class Initialized
ERROR - 2011-04-30 08:34:51 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-04-30 08:34:59 --> Config Class Initialized
DEBUG - 2011-04-30 08:34:59 --> Hooks Class Initialized
DEBUG - 2011-04-30 08:34:59 --> Utf8 Class Initialized
DEBUG - 2011-04-30 08:34:59 --> UTF-8 Support Enabled
DEBUG - 2011-04-30 08:34:59 --> URI Class Initialized
DEBUG - 2011-04-30 08:34:59 --> Router Class Initialized
DEBUG - 2011-04-30 08:34:59 --> Output Class Initialized
DEBUG - 2011-04-30 08:34:59 --> Input Class Initialized
DEBUG - 2011-04-30 08:34:59 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-30 08:34:59 --> Language Class Initialized
DEBUG - 2011-04-30 08:34:59 --> Loader Class Initialized
DEBUG - 2011-04-30 08:34:59 --> Controller Class Initialized
DEBUG - 2011-04-30 08:34:59 --> Model Class Initialized
DEBUG - 2011-04-30 08:34:59 --> Model Class Initialized
DEBUG - 2011-04-30 08:34:59 --> Model Class Initialized
DEBUG - 2011-04-30 08:34:59 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-30 08:34:59 --> Database Driver Class Initialized
DEBUG - 2011-04-30 08:34:59 --> File loaded: application/views/table/main.php
DEBUG - 2011-04-30 08:34:59 --> Helper loaded: url_helper
DEBUG - 2011-04-30 08:34:59 --> File loaded: application/views/common/header.php
DEBUG - 2011-04-30 08:34:59 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-04-30 08:34:59 --> File loaded: application/views/common/footer.php
DEBUG - 2011-04-30 08:34:59 --> File loaded: application/views/layout/main.php
DEBUG - 2011-04-30 08:34:59 --> Final output sent to browser
DEBUG - 2011-04-30 08:34:59 --> Total execution time: 0.2242
DEBUG - 2011-04-30 08:35:01 --> Config Class Initialized
DEBUG - 2011-04-30 08:35:01 --> Hooks Class Initialized
DEBUG - 2011-04-30 08:35:01 --> Utf8 Class Initialized
DEBUG - 2011-04-30 08:35:01 --> UTF-8 Support Enabled
DEBUG - 2011-04-30 08:35:01 --> URI Class Initialized
DEBUG - 2011-04-30 08:35:01 --> Router Class Initialized
DEBUG - 2011-04-30 08:35:01 --> Output Class Initialized
DEBUG - 2011-04-30 08:35:01 --> Input Class Initialized
DEBUG - 2011-04-30 08:35:01 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-30 08:35:01 --> Language Class Initialized
DEBUG - 2011-04-30 08:35:01 --> Loader Class Initialized
DEBUG - 2011-04-30 08:35:01 --> Controller Class Initialized
DEBUG - 2011-04-30 08:35:01 --> Model Class Initialized
DEBUG - 2011-04-30 08:35:01 --> Model Class Initialized
DEBUG - 2011-04-30 08:35:01 --> Model Class Initialized
DEBUG - 2011-04-30 08:35:01 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-30 08:35:01 --> Database Driver Class Initialized
DEBUG - 2011-04-30 08:35:01 --> File loaded: application/views/table/main.php
DEBUG - 2011-04-30 08:35:01 --> Helper loaded: url_helper
DEBUG - 2011-04-30 08:35:01 --> File loaded: application/views/common/header.php
DEBUG - 2011-04-30 08:35:01 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-04-30 08:35:01 --> File loaded: application/views/common/footer.php
DEBUG - 2011-04-30 08:35:01 --> File loaded: application/views/layout/main.php
DEBUG - 2011-04-30 08:35:01 --> Final output sent to browser
DEBUG - 2011-04-30 08:35:01 --> Total execution time: 0.0514
DEBUG - 2011-04-30 08:35:01 --> Config Class Initialized
DEBUG - 2011-04-30 08:35:01 --> Hooks Class Initialized
DEBUG - 2011-04-30 08:35:01 --> Utf8 Class Initialized
DEBUG - 2011-04-30 08:35:01 --> UTF-8 Support Enabled
DEBUG - 2011-04-30 08:35:01 --> URI Class Initialized
DEBUG - 2011-04-30 08:35:01 --> Router Class Initialized
ERROR - 2011-04-30 08:35:01 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-04-30 08:35:05 --> Config Class Initialized
DEBUG - 2011-04-30 08:35:05 --> Hooks Class Initialized
DEBUG - 2011-04-30 08:35:05 --> Utf8 Class Initialized
DEBUG - 2011-04-30 08:35:05 --> UTF-8 Support Enabled
DEBUG - 2011-04-30 08:35:05 --> URI Class Initialized
DEBUG - 2011-04-30 08:35:05 --> Router Class Initialized
DEBUG - 2011-04-30 08:35:05 --> Output Class Initialized
DEBUG - 2011-04-30 08:35:05 --> Input Class Initialized
DEBUG - 2011-04-30 08:35:05 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-30 08:35:05 --> Language Class Initialized
DEBUG - 2011-04-30 08:35:05 --> Loader Class Initialized
DEBUG - 2011-04-30 08:35:05 --> Controller Class Initialized
DEBUG - 2011-04-30 08:35:05 --> Model Class Initialized
DEBUG - 2011-04-30 08:35:05 --> Model Class Initialized
DEBUG - 2011-04-30 08:35:05 --> Model Class Initialized
DEBUG - 2011-04-30 08:35:05 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-30 08:35:05 --> Database Driver Class Initialized
DEBUG - 2011-04-30 08:35:05 --> File loaded: application/views/table/main.php
DEBUG - 2011-04-30 08:35:05 --> Helper loaded: url_helper
DEBUG - 2011-04-30 08:35:05 --> File loaded: application/views/common/header.php
DEBUG - 2011-04-30 08:35:05 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-04-30 08:35:05 --> File loaded: application/views/common/footer.php
DEBUG - 2011-04-30 08:35:05 --> File loaded: application/views/layout/main.php
DEBUG - 2011-04-30 08:35:05 --> Final output sent to browser
DEBUG - 2011-04-30 08:35:05 --> Total execution time: 0.4065
DEBUG - 2011-04-30 08:35:06 --> Config Class Initialized
DEBUG - 2011-04-30 08:35:06 --> Hooks Class Initialized
DEBUG - 2011-04-30 08:35:06 --> Utf8 Class Initialized
DEBUG - 2011-04-30 08:35:06 --> UTF-8 Support Enabled
DEBUG - 2011-04-30 08:35:06 --> URI Class Initialized
DEBUG - 2011-04-30 08:35:06 --> Router Class Initialized
ERROR - 2011-04-30 08:35:06 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-04-30 08:35:06 --> Config Class Initialized
DEBUG - 2011-04-30 08:35:06 --> Hooks Class Initialized
DEBUG - 2011-04-30 08:35:06 --> Utf8 Class Initialized
DEBUG - 2011-04-30 08:35:06 --> UTF-8 Support Enabled
DEBUG - 2011-04-30 08:35:06 --> URI Class Initialized
DEBUG - 2011-04-30 08:35:06 --> Router Class Initialized
DEBUG - 2011-04-30 08:35:06 --> Output Class Initialized
DEBUG - 2011-04-30 08:35:06 --> Input Class Initialized
DEBUG - 2011-04-30 08:35:06 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-30 08:35:06 --> Language Class Initialized
DEBUG - 2011-04-30 08:35:06 --> Loader Class Initialized
DEBUG - 2011-04-30 08:35:06 --> Controller Class Initialized
DEBUG - 2011-04-30 08:35:06 --> Model Class Initialized
DEBUG - 2011-04-30 08:35:06 --> Model Class Initialized
DEBUG - 2011-04-30 08:35:06 --> Model Class Initialized
DEBUG - 2011-04-30 08:35:06 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-30 08:35:06 --> Database Driver Class Initialized
DEBUG - 2011-04-30 08:35:07 --> File loaded: application/views/table/main.php
DEBUG - 2011-04-30 08:35:07 --> Helper loaded: url_helper
DEBUG - 2011-04-30 08:35:07 --> File loaded: application/views/common/header.php
DEBUG - 2011-04-30 08:35:07 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-04-30 08:35:07 --> File loaded: application/views/common/footer.php
DEBUG - 2011-04-30 08:35:07 --> File loaded: application/views/layout/main.php
DEBUG - 2011-04-30 08:35:07 --> Final output sent to browser
DEBUG - 2011-04-30 08:35:07 --> Total execution time: 0.1042
DEBUG - 2011-04-30 08:35:17 --> Config Class Initialized
DEBUG - 2011-04-30 08:35:17 --> Hooks Class Initialized
DEBUG - 2011-04-30 08:35:17 --> Utf8 Class Initialized
DEBUG - 2011-04-30 08:35:17 --> UTF-8 Support Enabled
DEBUG - 2011-04-30 08:35:17 --> URI Class Initialized
DEBUG - 2011-04-30 08:35:17 --> Router Class Initialized
DEBUG - 2011-04-30 08:35:17 --> Output Class Initialized
DEBUG - 2011-04-30 08:35:17 --> Input Class Initialized
DEBUG - 2011-04-30 08:35:17 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-30 08:35:17 --> Language Class Initialized
DEBUG - 2011-04-30 08:35:17 --> Loader Class Initialized
DEBUG - 2011-04-30 08:35:17 --> Controller Class Initialized
DEBUG - 2011-04-30 08:35:17 --> Model Class Initialized
DEBUG - 2011-04-30 08:35:17 --> Model Class Initialized
DEBUG - 2011-04-30 08:35:17 --> Model Class Initialized
DEBUG - 2011-04-30 08:35:17 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-30 08:35:17 --> Database Driver Class Initialized
DEBUG - 2011-04-30 08:35:17 --> File loaded: application/views/table/main.php
DEBUG - 2011-04-30 08:35:17 --> Helper loaded: url_helper
DEBUG - 2011-04-30 08:35:17 --> File loaded: application/views/common/header.php
DEBUG - 2011-04-30 08:35:17 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-04-30 08:35:17 --> File loaded: application/views/common/footer.php
DEBUG - 2011-04-30 08:35:17 --> File loaded: application/views/layout/main.php
DEBUG - 2011-04-30 08:35:17 --> Final output sent to browser
DEBUG - 2011-04-30 08:35:17 --> Total execution time: 0.1817
DEBUG - 2011-04-30 08:35:18 --> Config Class Initialized
DEBUG - 2011-04-30 08:35:18 --> Hooks Class Initialized
DEBUG - 2011-04-30 08:35:18 --> Utf8 Class Initialized
DEBUG - 2011-04-30 08:35:18 --> UTF-8 Support Enabled
DEBUG - 2011-04-30 08:35:18 --> URI Class Initialized
DEBUG - 2011-04-30 08:35:18 --> Router Class Initialized
DEBUG - 2011-04-30 08:35:18 --> Output Class Initialized
DEBUG - 2011-04-30 08:35:18 --> Input Class Initialized
DEBUG - 2011-04-30 08:35:18 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-30 08:35:18 --> Language Class Initialized
DEBUG - 2011-04-30 08:35:18 --> Loader Class Initialized
DEBUG - 2011-04-30 08:35:18 --> Controller Class Initialized
DEBUG - 2011-04-30 08:35:18 --> Model Class Initialized
DEBUG - 2011-04-30 08:35:18 --> Model Class Initialized
DEBUG - 2011-04-30 08:35:18 --> Model Class Initialized
DEBUG - 2011-04-30 08:35:18 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-30 08:35:18 --> Database Driver Class Initialized
DEBUG - 2011-04-30 08:35:18 --> File loaded: application/views/table/main.php
DEBUG - 2011-04-30 08:35:18 --> Helper loaded: url_helper
DEBUG - 2011-04-30 08:35:18 --> File loaded: application/views/common/header.php
DEBUG - 2011-04-30 08:35:18 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-04-30 08:35:18 --> File loaded: application/views/common/footer.php
DEBUG - 2011-04-30 08:35:18 --> File loaded: application/views/layout/main.php
DEBUG - 2011-04-30 08:35:18 --> Final output sent to browser
DEBUG - 2011-04-30 08:35:18 --> Total execution time: 0.0501
DEBUG - 2011-04-30 08:35:23 --> Config Class Initialized
DEBUG - 2011-04-30 08:35:23 --> Hooks Class Initialized
DEBUG - 2011-04-30 08:35:23 --> Utf8 Class Initialized
DEBUG - 2011-04-30 08:35:23 --> UTF-8 Support Enabled
DEBUG - 2011-04-30 08:35:23 --> URI Class Initialized
DEBUG - 2011-04-30 08:35:23 --> Router Class Initialized
ERROR - 2011-04-30 08:35:23 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-04-30 08:35:42 --> Config Class Initialized
DEBUG - 2011-04-30 08:35:42 --> Hooks Class Initialized
DEBUG - 2011-04-30 08:35:42 --> Utf8 Class Initialized
DEBUG - 2011-04-30 08:35:42 --> UTF-8 Support Enabled
DEBUG - 2011-04-30 08:35:42 --> URI Class Initialized
DEBUG - 2011-04-30 08:35:42 --> Router Class Initialized
DEBUG - 2011-04-30 08:35:42 --> Output Class Initialized
DEBUG - 2011-04-30 08:35:42 --> Input Class Initialized
DEBUG - 2011-04-30 08:35:42 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-30 08:35:42 --> Language Class Initialized
DEBUG - 2011-04-30 08:35:42 --> Loader Class Initialized
DEBUG - 2011-04-30 08:35:42 --> Controller Class Initialized
DEBUG - 2011-04-30 08:35:42 --> Model Class Initialized
DEBUG - 2011-04-30 08:35:42 --> Model Class Initialized
DEBUG - 2011-04-30 08:35:42 --> Model Class Initialized
DEBUG - 2011-04-30 08:35:42 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-30 08:35:43 --> Database Driver Class Initialized
DEBUG - 2011-04-30 08:35:44 --> File loaded: application/views/table/main.php
DEBUG - 2011-04-30 08:35:44 --> Helper loaded: url_helper
DEBUG - 2011-04-30 08:35:44 --> File loaded: application/views/common/header.php
DEBUG - 2011-04-30 08:35:44 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-04-30 08:35:44 --> File loaded: application/views/common/footer.php
DEBUG - 2011-04-30 08:35:44 --> File loaded: application/views/layout/main.php
DEBUG - 2011-04-30 08:35:44 --> Final output sent to browser
DEBUG - 2011-04-30 08:35:44 --> Total execution time: 1.3558
DEBUG - 2011-04-30 08:35:45 --> Config Class Initialized
DEBUG - 2011-04-30 08:35:45 --> Hooks Class Initialized
DEBUG - 2011-04-30 08:35:45 --> Utf8 Class Initialized
DEBUG - 2011-04-30 08:35:45 --> UTF-8 Support Enabled
DEBUG - 2011-04-30 08:35:45 --> URI Class Initialized
DEBUG - 2011-04-30 08:35:45 --> Router Class Initialized
DEBUG - 2011-04-30 08:35:45 --> Output Class Initialized
DEBUG - 2011-04-30 08:35:45 --> Input Class Initialized
DEBUG - 2011-04-30 08:35:45 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-30 08:35:45 --> Language Class Initialized
DEBUG - 2011-04-30 08:35:45 --> Loader Class Initialized
DEBUG - 2011-04-30 08:35:45 --> Controller Class Initialized
DEBUG - 2011-04-30 08:35:45 --> Model Class Initialized
DEBUG - 2011-04-30 08:35:45 --> Model Class Initialized
DEBUG - 2011-04-30 08:35:45 --> Model Class Initialized
DEBUG - 2011-04-30 08:35:45 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-30 08:35:45 --> Database Driver Class Initialized
DEBUG - 2011-04-30 08:35:45 --> File loaded: application/views/table/main.php
DEBUG - 2011-04-30 08:35:45 --> Helper loaded: url_helper
DEBUG - 2011-04-30 08:35:45 --> File loaded: application/views/common/header.php
DEBUG - 2011-04-30 08:35:45 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-04-30 08:35:45 --> File loaded: application/views/common/footer.php
DEBUG - 2011-04-30 08:35:45 --> File loaded: application/views/layout/main.php
DEBUG - 2011-04-30 08:35:45 --> Final output sent to browser
DEBUG - 2011-04-30 08:35:45 --> Total execution time: 0.1213
DEBUG - 2011-04-30 08:35:45 --> Config Class Initialized
DEBUG - 2011-04-30 08:35:45 --> Hooks Class Initialized
DEBUG - 2011-04-30 08:35:45 --> Utf8 Class Initialized
DEBUG - 2011-04-30 08:35:45 --> UTF-8 Support Enabled
DEBUG - 2011-04-30 08:35:45 --> URI Class Initialized
DEBUG - 2011-04-30 08:35:45 --> Router Class Initialized
ERROR - 2011-04-30 08:35:45 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-04-30 08:36:03 --> Config Class Initialized
DEBUG - 2011-04-30 08:36:03 --> Hooks Class Initialized
DEBUG - 2011-04-30 08:36:03 --> Utf8 Class Initialized
DEBUG - 2011-04-30 08:36:03 --> UTF-8 Support Enabled
DEBUG - 2011-04-30 08:36:03 --> URI Class Initialized
DEBUG - 2011-04-30 08:36:03 --> Router Class Initialized
DEBUG - 2011-04-30 08:36:03 --> Output Class Initialized
DEBUG - 2011-04-30 08:36:03 --> Input Class Initialized
DEBUG - 2011-04-30 08:36:03 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-30 08:36:03 --> Language Class Initialized
DEBUG - 2011-04-30 08:36:03 --> Loader Class Initialized
DEBUG - 2011-04-30 08:36:03 --> Controller Class Initialized
DEBUG - 2011-04-30 08:36:03 --> Model Class Initialized
DEBUG - 2011-04-30 08:36:03 --> Model Class Initialized
DEBUG - 2011-04-30 08:36:03 --> Model Class Initialized
DEBUG - 2011-04-30 08:36:03 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-30 08:36:03 --> Database Driver Class Initialized
DEBUG - 2011-04-30 08:36:03 --> File loaded: application/views/table/main.php
DEBUG - 2011-04-30 08:36:03 --> Helper loaded: url_helper
DEBUG - 2011-04-30 08:36:03 --> File loaded: application/views/common/header.php
DEBUG - 2011-04-30 08:36:03 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-04-30 08:36:03 --> File loaded: application/views/common/footer.php
DEBUG - 2011-04-30 08:36:03 --> File loaded: application/views/layout/main.php
DEBUG - 2011-04-30 08:36:03 --> Final output sent to browser
DEBUG - 2011-04-30 08:36:03 --> Total execution time: 0.2321
DEBUG - 2011-04-30 08:36:04 --> Config Class Initialized
DEBUG - 2011-04-30 08:36:04 --> Hooks Class Initialized
DEBUG - 2011-04-30 08:36:04 --> Utf8 Class Initialized
DEBUG - 2011-04-30 08:36:04 --> UTF-8 Support Enabled
DEBUG - 2011-04-30 08:36:04 --> URI Class Initialized
DEBUG - 2011-04-30 08:36:04 --> Router Class Initialized
DEBUG - 2011-04-30 08:36:04 --> Output Class Initialized
DEBUG - 2011-04-30 08:36:04 --> Input Class Initialized
DEBUG - 2011-04-30 08:36:04 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-30 08:36:04 --> Language Class Initialized
DEBUG - 2011-04-30 08:36:04 --> Loader Class Initialized
DEBUG - 2011-04-30 08:36:04 --> Controller Class Initialized
DEBUG - 2011-04-30 08:36:04 --> Model Class Initialized
DEBUG - 2011-04-30 08:36:04 --> Model Class Initialized
DEBUG - 2011-04-30 08:36:04 --> Model Class Initialized
DEBUG - 2011-04-30 08:36:04 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-30 08:36:04 --> Database Driver Class Initialized
DEBUG - 2011-04-30 08:36:04 --> File loaded: application/views/table/main.php
DEBUG - 2011-04-30 08:36:04 --> Helper loaded: url_helper
DEBUG - 2011-04-30 08:36:04 --> File loaded: application/views/common/header.php
DEBUG - 2011-04-30 08:36:04 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-04-30 08:36:04 --> File loaded: application/views/common/footer.php
DEBUG - 2011-04-30 08:36:04 --> File loaded: application/views/layout/main.php
DEBUG - 2011-04-30 08:36:04 --> Final output sent to browser
DEBUG - 2011-04-30 08:36:04 --> Total execution time: 0.0547
DEBUG - 2011-04-30 08:36:04 --> Config Class Initialized
DEBUG - 2011-04-30 08:36:04 --> Hooks Class Initialized
DEBUG - 2011-04-30 08:36:04 --> Utf8 Class Initialized
DEBUG - 2011-04-30 08:36:04 --> UTF-8 Support Enabled
DEBUG - 2011-04-30 08:36:04 --> URI Class Initialized
DEBUG - 2011-04-30 08:36:04 --> Router Class Initialized
ERROR - 2011-04-30 08:36:04 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-04-30 08:36:12 --> Config Class Initialized
DEBUG - 2011-04-30 08:36:12 --> Hooks Class Initialized
DEBUG - 2011-04-30 08:36:12 --> Utf8 Class Initialized
DEBUG - 2011-04-30 08:36:12 --> UTF-8 Support Enabled
DEBUG - 2011-04-30 08:36:12 --> URI Class Initialized
DEBUG - 2011-04-30 08:36:12 --> Router Class Initialized
DEBUG - 2011-04-30 08:36:12 --> Output Class Initialized
DEBUG - 2011-04-30 08:36:12 --> Input Class Initialized
DEBUG - 2011-04-30 08:36:12 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-30 08:36:12 --> Language Class Initialized
DEBUG - 2011-04-30 08:36:12 --> Loader Class Initialized
DEBUG - 2011-04-30 08:36:12 --> Controller Class Initialized
DEBUG - 2011-04-30 08:36:12 --> Model Class Initialized
DEBUG - 2011-04-30 08:36:12 --> Model Class Initialized
DEBUG - 2011-04-30 08:36:12 --> Model Class Initialized
DEBUG - 2011-04-30 08:36:12 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-30 08:36:12 --> Database Driver Class Initialized
DEBUG - 2011-04-30 08:36:12 --> File loaded: application/views/table/main.php
DEBUG - 2011-04-30 08:36:12 --> Helper loaded: url_helper
DEBUG - 2011-04-30 08:36:12 --> File loaded: application/views/common/header.php
DEBUG - 2011-04-30 08:36:12 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-04-30 08:36:12 --> File loaded: application/views/common/footer.php
DEBUG - 2011-04-30 08:36:12 --> File loaded: application/views/layout/main.php
DEBUG - 2011-04-30 08:36:12 --> Final output sent to browser
DEBUG - 2011-04-30 08:36:12 --> Total execution time: 0.4374
DEBUG - 2011-04-30 08:36:13 --> Config Class Initialized
DEBUG - 2011-04-30 08:36:13 --> Hooks Class Initialized
DEBUG - 2011-04-30 08:36:13 --> Utf8 Class Initialized
DEBUG - 2011-04-30 08:36:13 --> UTF-8 Support Enabled
DEBUG - 2011-04-30 08:36:13 --> URI Class Initialized
DEBUG - 2011-04-30 08:36:13 --> Router Class Initialized
ERROR - 2011-04-30 08:36:13 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-04-30 08:36:15 --> Config Class Initialized
DEBUG - 2011-04-30 08:36:15 --> Hooks Class Initialized
DEBUG - 2011-04-30 08:36:15 --> Utf8 Class Initialized
DEBUG - 2011-04-30 08:36:15 --> UTF-8 Support Enabled
DEBUG - 2011-04-30 08:36:15 --> URI Class Initialized
DEBUG - 2011-04-30 08:36:15 --> Router Class Initialized
DEBUG - 2011-04-30 08:36:15 --> Output Class Initialized
DEBUG - 2011-04-30 08:36:15 --> Input Class Initialized
DEBUG - 2011-04-30 08:36:15 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-30 08:36:15 --> Language Class Initialized
DEBUG - 2011-04-30 08:36:15 --> Loader Class Initialized
DEBUG - 2011-04-30 08:36:15 --> Controller Class Initialized
DEBUG - 2011-04-30 08:36:15 --> Model Class Initialized
DEBUG - 2011-04-30 08:36:15 --> Model Class Initialized
DEBUG - 2011-04-30 08:36:15 --> Model Class Initialized
DEBUG - 2011-04-30 08:36:15 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-30 08:36:15 --> Database Driver Class Initialized
DEBUG - 2011-04-30 08:36:15 --> File loaded: application/views/table/main.php
DEBUG - 2011-04-30 08:36:16 --> Helper loaded: url_helper
DEBUG - 2011-04-30 08:36:16 --> File loaded: application/views/common/header.php
DEBUG - 2011-04-30 08:36:16 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-04-30 08:36:16 --> File loaded: application/views/common/footer.php
DEBUG - 2011-04-30 08:36:16 --> File loaded: application/views/layout/main.php
DEBUG - 2011-04-30 08:36:16 --> Final output sent to browser
DEBUG - 2011-04-30 08:36:16 --> Total execution time: 0.1191
DEBUG - 2011-04-30 08:36:22 --> Config Class Initialized
DEBUG - 2011-04-30 08:36:22 --> Hooks Class Initialized
DEBUG - 2011-04-30 08:36:22 --> Utf8 Class Initialized
DEBUG - 2011-04-30 08:36:22 --> UTF-8 Support Enabled
DEBUG - 2011-04-30 08:36:22 --> URI Class Initialized
DEBUG - 2011-04-30 08:36:22 --> Router Class Initialized
DEBUG - 2011-04-30 08:36:22 --> Output Class Initialized
DEBUG - 2011-04-30 08:36:22 --> Input Class Initialized
DEBUG - 2011-04-30 08:36:22 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-30 08:36:22 --> Language Class Initialized
DEBUG - 2011-04-30 08:36:22 --> Loader Class Initialized
DEBUG - 2011-04-30 08:36:22 --> Controller Class Initialized
DEBUG - 2011-04-30 08:36:22 --> Model Class Initialized
DEBUG - 2011-04-30 08:36:22 --> Model Class Initialized
DEBUG - 2011-04-30 08:36:22 --> Model Class Initialized
DEBUG - 2011-04-30 08:36:22 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-30 08:36:22 --> Database Driver Class Initialized
DEBUG - 2011-04-30 08:36:22 --> File loaded: application/views/table/main.php
DEBUG - 2011-04-30 08:36:22 --> Helper loaded: url_helper
DEBUG - 2011-04-30 08:36:22 --> File loaded: application/views/common/header.php
DEBUG - 2011-04-30 08:36:22 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-04-30 08:36:22 --> File loaded: application/views/common/footer.php
DEBUG - 2011-04-30 08:36:22 --> File loaded: application/views/layout/main.php
DEBUG - 2011-04-30 08:36:22 --> Final output sent to browser
DEBUG - 2011-04-30 08:36:22 --> Total execution time: 0.2203
DEBUG - 2011-04-30 08:36:23 --> Config Class Initialized
DEBUG - 2011-04-30 08:36:23 --> Hooks Class Initialized
DEBUG - 2011-04-30 08:36:23 --> Utf8 Class Initialized
DEBUG - 2011-04-30 08:36:23 --> UTF-8 Support Enabled
DEBUG - 2011-04-30 08:36:23 --> URI Class Initialized
DEBUG - 2011-04-30 08:36:23 --> Router Class Initialized
DEBUG - 2011-04-30 08:36:23 --> Output Class Initialized
DEBUG - 2011-04-30 08:36:23 --> Input Class Initialized
DEBUG - 2011-04-30 08:36:23 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-30 08:36:23 --> Language Class Initialized
DEBUG - 2011-04-30 08:36:23 --> Loader Class Initialized
DEBUG - 2011-04-30 08:36:23 --> Controller Class Initialized
DEBUG - 2011-04-30 08:36:23 --> Model Class Initialized
DEBUG - 2011-04-30 08:36:23 --> Model Class Initialized
DEBUG - 2011-04-30 08:36:23 --> Model Class Initialized
DEBUG - 2011-04-30 08:36:23 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-30 08:36:23 --> Database Driver Class Initialized
DEBUG - 2011-04-30 08:36:23 --> File loaded: application/views/table/main.php
DEBUG - 2011-04-30 08:36:23 --> Helper loaded: url_helper
DEBUG - 2011-04-30 08:36:23 --> File loaded: application/views/common/header.php
DEBUG - 2011-04-30 08:36:23 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-04-30 08:36:23 --> File loaded: application/views/common/footer.php
DEBUG - 2011-04-30 08:36:23 --> File loaded: application/views/layout/main.php
DEBUG - 2011-04-30 08:36:23 --> Final output sent to browser
DEBUG - 2011-04-30 08:36:23 --> Total execution time: 0.0648
DEBUG - 2011-04-30 08:36:23 --> Config Class Initialized
DEBUG - 2011-04-30 08:36:23 --> Hooks Class Initialized
DEBUG - 2011-04-30 08:36:23 --> Utf8 Class Initialized
DEBUG - 2011-04-30 08:36:23 --> UTF-8 Support Enabled
DEBUG - 2011-04-30 08:36:23 --> URI Class Initialized
DEBUG - 2011-04-30 08:36:23 --> Router Class Initialized
ERROR - 2011-04-30 08:36:23 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-04-30 08:36:29 --> Config Class Initialized
DEBUG - 2011-04-30 08:36:29 --> Hooks Class Initialized
DEBUG - 2011-04-30 08:36:29 --> Utf8 Class Initialized
DEBUG - 2011-04-30 08:36:29 --> UTF-8 Support Enabled
DEBUG - 2011-04-30 08:36:29 --> URI Class Initialized
DEBUG - 2011-04-30 08:36:29 --> Router Class Initialized
DEBUG - 2011-04-30 08:36:29 --> Output Class Initialized
DEBUG - 2011-04-30 08:36:29 --> Input Class Initialized
DEBUG - 2011-04-30 08:36:29 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-30 08:36:29 --> Language Class Initialized
DEBUG - 2011-04-30 08:36:29 --> Loader Class Initialized
DEBUG - 2011-04-30 08:36:29 --> Controller Class Initialized
DEBUG - 2011-04-30 08:36:29 --> Model Class Initialized
DEBUG - 2011-04-30 08:36:29 --> Model Class Initialized
DEBUG - 2011-04-30 08:36:29 --> Model Class Initialized
DEBUG - 2011-04-30 08:36:29 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-30 08:36:29 --> Database Driver Class Initialized
DEBUG - 2011-04-30 08:36:30 --> File loaded: application/views/table/main.php
DEBUG - 2011-04-30 08:36:30 --> Helper loaded: url_helper
DEBUG - 2011-04-30 08:36:30 --> File loaded: application/views/common/header.php
DEBUG - 2011-04-30 08:36:30 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-04-30 08:36:30 --> File loaded: application/views/common/footer.php
DEBUG - 2011-04-30 08:36:30 --> File loaded: application/views/layout/main.php
DEBUG - 2011-04-30 08:36:30 --> Final output sent to browser
DEBUG - 2011-04-30 08:36:30 --> Total execution time: 0.8279
DEBUG - 2011-04-30 08:36:31 --> Config Class Initialized
DEBUG - 2011-04-30 08:36:31 --> Hooks Class Initialized
DEBUG - 2011-04-30 08:36:31 --> Utf8 Class Initialized
DEBUG - 2011-04-30 08:36:31 --> UTF-8 Support Enabled
DEBUG - 2011-04-30 08:36:31 --> URI Class Initialized
DEBUG - 2011-04-30 08:36:31 --> Router Class Initialized
DEBUG - 2011-04-30 08:36:31 --> Output Class Initialized
DEBUG - 2011-04-30 08:36:31 --> Input Class Initialized
DEBUG - 2011-04-30 08:36:31 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-30 08:36:31 --> Language Class Initialized
DEBUG - 2011-04-30 08:36:31 --> Loader Class Initialized
DEBUG - 2011-04-30 08:36:31 --> Controller Class Initialized
DEBUG - 2011-04-30 08:36:31 --> Model Class Initialized
DEBUG - 2011-04-30 08:36:31 --> Model Class Initialized
DEBUG - 2011-04-30 08:36:31 --> Model Class Initialized
DEBUG - 2011-04-30 08:36:31 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-30 08:36:31 --> Database Driver Class Initialized
DEBUG - 2011-04-30 08:36:31 --> File loaded: application/views/table/main.php
DEBUG - 2011-04-30 08:36:31 --> Helper loaded: url_helper
DEBUG - 2011-04-30 08:36:31 --> File loaded: application/views/common/header.php
DEBUG - 2011-04-30 08:36:31 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-04-30 08:36:31 --> File loaded: application/views/common/footer.php
DEBUG - 2011-04-30 08:36:31 --> File loaded: application/views/layout/main.php
DEBUG - 2011-04-30 08:36:31 --> Final output sent to browser
DEBUG - 2011-04-30 08:36:31 --> Total execution time: 0.1767
DEBUG - 2011-04-30 08:36:31 --> Config Class Initialized
DEBUG - 2011-04-30 08:36:31 --> Hooks Class Initialized
DEBUG - 2011-04-30 08:36:31 --> Utf8 Class Initialized
DEBUG - 2011-04-30 08:36:31 --> UTF-8 Support Enabled
DEBUG - 2011-04-30 08:36:31 --> URI Class Initialized
DEBUG - 2011-04-30 08:36:31 --> Router Class Initialized
ERROR - 2011-04-30 08:36:31 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-04-30 08:36:34 --> Config Class Initialized
DEBUG - 2011-04-30 08:36:34 --> Hooks Class Initialized
DEBUG - 2011-04-30 08:36:34 --> Utf8 Class Initialized
DEBUG - 2011-04-30 08:36:34 --> UTF-8 Support Enabled
DEBUG - 2011-04-30 08:36:34 --> URI Class Initialized
DEBUG - 2011-04-30 08:36:34 --> Router Class Initialized
DEBUG - 2011-04-30 08:36:34 --> Output Class Initialized
DEBUG - 2011-04-30 08:36:34 --> Input Class Initialized
DEBUG - 2011-04-30 08:36:34 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-30 08:36:34 --> Language Class Initialized
DEBUG - 2011-04-30 08:36:34 --> Loader Class Initialized
DEBUG - 2011-04-30 08:36:34 --> Controller Class Initialized
DEBUG - 2011-04-30 08:36:34 --> Model Class Initialized
DEBUG - 2011-04-30 08:36:34 --> Model Class Initialized
DEBUG - 2011-04-30 08:36:34 --> Model Class Initialized
DEBUG - 2011-04-30 08:36:34 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-30 08:36:34 --> Database Driver Class Initialized
DEBUG - 2011-04-30 08:36:35 --> File loaded: application/views/table/main.php
DEBUG - 2011-04-30 08:36:35 --> Helper loaded: url_helper
DEBUG - 2011-04-30 08:36:35 --> File loaded: application/views/common/header.php
DEBUG - 2011-04-30 08:36:35 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-04-30 08:36:35 --> File loaded: application/views/common/footer.php
DEBUG - 2011-04-30 08:36:35 --> File loaded: application/views/layout/main.php
DEBUG - 2011-04-30 08:36:35 --> Final output sent to browser
DEBUG - 2011-04-30 08:36:35 --> Total execution time: 0.2657
DEBUG - 2011-04-30 08:36:36 --> Config Class Initialized
DEBUG - 2011-04-30 08:36:36 --> Hooks Class Initialized
DEBUG - 2011-04-30 08:36:36 --> Utf8 Class Initialized
DEBUG - 2011-04-30 08:36:36 --> UTF-8 Support Enabled
DEBUG - 2011-04-30 08:36:36 --> URI Class Initialized
DEBUG - 2011-04-30 08:36:36 --> Router Class Initialized
DEBUG - 2011-04-30 08:36:36 --> Output Class Initialized
DEBUG - 2011-04-30 08:36:36 --> Input Class Initialized
DEBUG - 2011-04-30 08:36:36 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-30 08:36:36 --> Language Class Initialized
DEBUG - 2011-04-30 08:36:36 --> Loader Class Initialized
DEBUG - 2011-04-30 08:36:36 --> Controller Class Initialized
DEBUG - 2011-04-30 08:36:36 --> Model Class Initialized
DEBUG - 2011-04-30 08:36:36 --> Model Class Initialized
DEBUG - 2011-04-30 08:36:36 --> Model Class Initialized
DEBUG - 2011-04-30 08:36:36 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-30 08:36:36 --> Database Driver Class Initialized
DEBUG - 2011-04-30 08:36:36 --> File loaded: application/views/table/main.php
DEBUG - 2011-04-30 08:36:36 --> Helper loaded: url_helper
DEBUG - 2011-04-30 08:36:36 --> File loaded: application/views/common/header.php
DEBUG - 2011-04-30 08:36:36 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-04-30 08:36:36 --> File loaded: application/views/common/footer.php
DEBUG - 2011-04-30 08:36:36 --> File loaded: application/views/layout/main.php
DEBUG - 2011-04-30 08:36:36 --> Final output sent to browser
DEBUG - 2011-04-30 08:36:36 --> Total execution time: 0.0497
DEBUG - 2011-04-30 08:36:36 --> Config Class Initialized
DEBUG - 2011-04-30 08:36:36 --> Hooks Class Initialized
DEBUG - 2011-04-30 08:36:36 --> Utf8 Class Initialized
DEBUG - 2011-04-30 08:36:36 --> UTF-8 Support Enabled
DEBUG - 2011-04-30 08:36:36 --> URI Class Initialized
DEBUG - 2011-04-30 08:36:36 --> Router Class Initialized
ERROR - 2011-04-30 08:36:36 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-04-30 08:36:41 --> Config Class Initialized
DEBUG - 2011-04-30 08:36:41 --> Hooks Class Initialized
DEBUG - 2011-04-30 08:36:41 --> Utf8 Class Initialized
DEBUG - 2011-04-30 08:36:41 --> UTF-8 Support Enabled
DEBUG - 2011-04-30 08:36:41 --> URI Class Initialized
DEBUG - 2011-04-30 08:36:41 --> Router Class Initialized
DEBUG - 2011-04-30 08:36:41 --> Output Class Initialized
DEBUG - 2011-04-30 08:36:41 --> Input Class Initialized
DEBUG - 2011-04-30 08:36:41 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-30 08:36:41 --> Language Class Initialized
DEBUG - 2011-04-30 08:36:41 --> Loader Class Initialized
DEBUG - 2011-04-30 08:36:41 --> Controller Class Initialized
DEBUG - 2011-04-30 08:36:41 --> Model Class Initialized
DEBUG - 2011-04-30 08:36:41 --> Model Class Initialized
DEBUG - 2011-04-30 08:36:41 --> Model Class Initialized
DEBUG - 2011-04-30 08:36:41 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-30 08:36:41 --> Database Driver Class Initialized
DEBUG - 2011-04-30 08:36:41 --> File loaded: application/views/table/main.php
DEBUG - 2011-04-30 08:36:41 --> Helper loaded: url_helper
DEBUG - 2011-04-30 08:36:41 --> File loaded: application/views/common/header.php
DEBUG - 2011-04-30 08:36:41 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-04-30 08:36:41 --> File loaded: application/views/common/footer.php
DEBUG - 2011-04-30 08:36:41 --> File loaded: application/views/layout/main.php
DEBUG - 2011-04-30 08:36:41 --> Final output sent to browser
DEBUG - 2011-04-30 08:36:41 --> Total execution time: 0.6671
DEBUG - 2011-04-30 08:36:42 --> Config Class Initialized
DEBUG - 2011-04-30 08:36:42 --> Hooks Class Initialized
DEBUG - 2011-04-30 08:36:42 --> Utf8 Class Initialized
DEBUG - 2011-04-30 08:36:42 --> UTF-8 Support Enabled
DEBUG - 2011-04-30 08:36:42 --> URI Class Initialized
DEBUG - 2011-04-30 08:36:42 --> Router Class Initialized
ERROR - 2011-04-30 08:36:42 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-04-30 08:36:43 --> Config Class Initialized
DEBUG - 2011-04-30 08:36:43 --> Hooks Class Initialized
DEBUG - 2011-04-30 08:36:43 --> Utf8 Class Initialized
DEBUG - 2011-04-30 08:36:43 --> UTF-8 Support Enabled
DEBUG - 2011-04-30 08:36:43 --> URI Class Initialized
DEBUG - 2011-04-30 08:36:43 --> Router Class Initialized
DEBUG - 2011-04-30 08:36:43 --> Output Class Initialized
DEBUG - 2011-04-30 08:36:43 --> Input Class Initialized
DEBUG - 2011-04-30 08:36:43 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-30 08:36:43 --> Language Class Initialized
DEBUG - 2011-04-30 08:36:43 --> Loader Class Initialized
DEBUG - 2011-04-30 08:36:43 --> Controller Class Initialized
DEBUG - 2011-04-30 08:36:43 --> Model Class Initialized
DEBUG - 2011-04-30 08:36:43 --> Model Class Initialized
DEBUG - 2011-04-30 08:36:43 --> Model Class Initialized
DEBUG - 2011-04-30 08:36:43 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-30 08:36:43 --> Database Driver Class Initialized
DEBUG - 2011-04-30 08:36:43 --> File loaded: application/views/table/main.php
DEBUG - 2011-04-30 08:36:43 --> Helper loaded: url_helper
DEBUG - 2011-04-30 08:36:43 --> File loaded: application/views/common/header.php
DEBUG - 2011-04-30 08:36:43 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-04-30 08:36:43 --> File loaded: application/views/common/footer.php
DEBUG - 2011-04-30 08:36:43 --> File loaded: application/views/layout/main.php
DEBUG - 2011-04-30 08:36:43 --> Final output sent to browser
DEBUG - 2011-04-30 08:36:43 --> Total execution time: 0.0732
DEBUG - 2011-04-30 08:36:48 --> Config Class Initialized
DEBUG - 2011-04-30 08:36:48 --> Hooks Class Initialized
DEBUG - 2011-04-30 08:36:48 --> Utf8 Class Initialized
DEBUG - 2011-04-30 08:36:48 --> UTF-8 Support Enabled
DEBUG - 2011-04-30 08:36:48 --> URI Class Initialized
DEBUG - 2011-04-30 08:36:48 --> Router Class Initialized
DEBUG - 2011-04-30 08:36:48 --> Output Class Initialized
DEBUG - 2011-04-30 08:36:48 --> Input Class Initialized
DEBUG - 2011-04-30 08:36:48 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-30 08:36:48 --> Language Class Initialized
DEBUG - 2011-04-30 08:36:48 --> Loader Class Initialized
DEBUG - 2011-04-30 08:36:48 --> Controller Class Initialized
DEBUG - 2011-04-30 08:36:48 --> Model Class Initialized
DEBUG - 2011-04-30 08:36:48 --> Model Class Initialized
DEBUG - 2011-04-30 08:36:48 --> Model Class Initialized
DEBUG - 2011-04-30 08:36:48 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-30 08:36:48 --> Database Driver Class Initialized
DEBUG - 2011-04-30 08:36:48 --> File loaded: application/views/table/main.php
DEBUG - 2011-04-30 08:36:48 --> Helper loaded: url_helper
DEBUG - 2011-04-30 08:36:48 --> File loaded: application/views/common/header.php
DEBUG - 2011-04-30 08:36:48 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-04-30 08:36:48 --> File loaded: application/views/common/footer.php
DEBUG - 2011-04-30 08:36:48 --> File loaded: application/views/layout/main.php
DEBUG - 2011-04-30 08:36:48 --> Final output sent to browser
DEBUG - 2011-04-30 08:36:48 --> Total execution time: 0.6255
DEBUG - 2011-04-30 08:36:49 --> Config Class Initialized
DEBUG - 2011-04-30 08:36:49 --> Hooks Class Initialized
DEBUG - 2011-04-30 08:36:49 --> Utf8 Class Initialized
DEBUG - 2011-04-30 08:36:49 --> UTF-8 Support Enabled
DEBUG - 2011-04-30 08:36:49 --> URI Class Initialized
DEBUG - 2011-04-30 08:36:49 --> Router Class Initialized
ERROR - 2011-04-30 08:36:49 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-04-30 08:36:50 --> Config Class Initialized
DEBUG - 2011-04-30 08:36:50 --> Hooks Class Initialized
DEBUG - 2011-04-30 08:36:50 --> Utf8 Class Initialized
DEBUG - 2011-04-30 08:36:50 --> UTF-8 Support Enabled
DEBUG - 2011-04-30 08:36:50 --> URI Class Initialized
DEBUG - 2011-04-30 08:36:50 --> Router Class Initialized
DEBUG - 2011-04-30 08:36:50 --> Output Class Initialized
DEBUG - 2011-04-30 08:36:50 --> Input Class Initialized
DEBUG - 2011-04-30 08:36:50 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-30 08:36:50 --> Language Class Initialized
DEBUG - 2011-04-30 08:36:50 --> Loader Class Initialized
DEBUG - 2011-04-30 08:36:50 --> Controller Class Initialized
DEBUG - 2011-04-30 08:36:50 --> Model Class Initialized
DEBUG - 2011-04-30 08:36:50 --> Model Class Initialized
DEBUG - 2011-04-30 08:36:50 --> Model Class Initialized
DEBUG - 2011-04-30 08:36:50 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-30 08:36:50 --> Database Driver Class Initialized
DEBUG - 2011-04-30 08:36:50 --> File loaded: application/views/table/main.php
DEBUG - 2011-04-30 08:36:50 --> Helper loaded: url_helper
DEBUG - 2011-04-30 08:36:50 --> File loaded: application/views/common/header.php
DEBUG - 2011-04-30 08:36:50 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-04-30 08:36:50 --> File loaded: application/views/common/footer.php
DEBUG - 2011-04-30 08:36:50 --> File loaded: application/views/layout/main.php
DEBUG - 2011-04-30 08:36:50 --> Final output sent to browser
DEBUG - 2011-04-30 08:36:50 --> Total execution time: 0.2293
DEBUG - 2011-04-30 08:36:55 --> Config Class Initialized
DEBUG - 2011-04-30 08:36:55 --> Hooks Class Initialized
DEBUG - 2011-04-30 08:36:55 --> Utf8 Class Initialized
DEBUG - 2011-04-30 08:36:55 --> UTF-8 Support Enabled
DEBUG - 2011-04-30 08:36:55 --> URI Class Initialized
DEBUG - 2011-04-30 08:36:55 --> Router Class Initialized
DEBUG - 2011-04-30 08:36:55 --> Output Class Initialized
DEBUG - 2011-04-30 08:36:55 --> Input Class Initialized
DEBUG - 2011-04-30 08:36:55 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-30 08:36:55 --> Language Class Initialized
DEBUG - 2011-04-30 08:36:55 --> Loader Class Initialized
DEBUG - 2011-04-30 08:36:55 --> Controller Class Initialized
DEBUG - 2011-04-30 08:36:55 --> Model Class Initialized
DEBUG - 2011-04-30 08:36:55 --> Model Class Initialized
DEBUG - 2011-04-30 08:36:55 --> Model Class Initialized
DEBUG - 2011-04-30 08:36:55 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-30 08:36:55 --> Database Driver Class Initialized
DEBUG - 2011-04-30 08:36:55 --> File loaded: application/views/table/main.php
DEBUG - 2011-04-30 08:36:55 --> Helper loaded: url_helper
DEBUG - 2011-04-30 08:36:55 --> File loaded: application/views/common/header.php
DEBUG - 2011-04-30 08:36:55 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-04-30 08:36:55 --> File loaded: application/views/common/footer.php
DEBUG - 2011-04-30 08:36:55 --> File loaded: application/views/layout/main.php
DEBUG - 2011-04-30 08:36:55 --> Final output sent to browser
DEBUG - 2011-04-30 08:36:55 --> Total execution time: 0.1954
DEBUG - 2011-04-30 08:36:56 --> Config Class Initialized
DEBUG - 2011-04-30 08:36:56 --> Hooks Class Initialized
DEBUG - 2011-04-30 08:36:56 --> Utf8 Class Initialized
DEBUG - 2011-04-30 08:36:56 --> UTF-8 Support Enabled
DEBUG - 2011-04-30 08:36:56 --> URI Class Initialized
DEBUG - 2011-04-30 08:36:56 --> Router Class Initialized
ERROR - 2011-04-30 08:36:56 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-04-30 08:36:56 --> Config Class Initialized
DEBUG - 2011-04-30 08:36:56 --> Hooks Class Initialized
DEBUG - 2011-04-30 08:36:56 --> Utf8 Class Initialized
DEBUG - 2011-04-30 08:36:56 --> UTF-8 Support Enabled
DEBUG - 2011-04-30 08:36:56 --> URI Class Initialized
DEBUG - 2011-04-30 08:36:56 --> Router Class Initialized
DEBUG - 2011-04-30 08:36:56 --> Output Class Initialized
DEBUG - 2011-04-30 08:36:56 --> Input Class Initialized
DEBUG - 2011-04-30 08:36:56 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-30 08:36:56 --> Language Class Initialized
DEBUG - 2011-04-30 08:36:56 --> Loader Class Initialized
DEBUG - 2011-04-30 08:36:56 --> Controller Class Initialized
DEBUG - 2011-04-30 08:36:56 --> Model Class Initialized
DEBUG - 2011-04-30 08:36:56 --> Model Class Initialized
DEBUG - 2011-04-30 08:36:56 --> Model Class Initialized
DEBUG - 2011-04-30 08:36:56 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-30 08:36:56 --> Database Driver Class Initialized
DEBUG - 2011-04-30 08:36:56 --> File loaded: application/views/table/main.php
DEBUG - 2011-04-30 08:36:56 --> Helper loaded: url_helper
DEBUG - 2011-04-30 08:36:56 --> File loaded: application/views/common/header.php
DEBUG - 2011-04-30 08:36:56 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-04-30 08:36:56 --> File loaded: application/views/common/footer.php
DEBUG - 2011-04-30 08:36:56 --> File loaded: application/views/layout/main.php
DEBUG - 2011-04-30 08:36:56 --> Final output sent to browser
DEBUG - 2011-04-30 08:36:56 --> Total execution time: 0.0493
DEBUG - 2011-04-30 08:37:00 --> Config Class Initialized
DEBUG - 2011-04-30 08:37:00 --> Hooks Class Initialized
DEBUG - 2011-04-30 08:37:00 --> Utf8 Class Initialized
DEBUG - 2011-04-30 08:37:00 --> UTF-8 Support Enabled
DEBUG - 2011-04-30 08:37:00 --> URI Class Initialized
DEBUG - 2011-04-30 08:37:00 --> Router Class Initialized
DEBUG - 2011-04-30 08:37:00 --> Output Class Initialized
DEBUG - 2011-04-30 08:37:00 --> Input Class Initialized
DEBUG - 2011-04-30 08:37:00 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-30 08:37:00 --> Language Class Initialized
DEBUG - 2011-04-30 08:37:00 --> Loader Class Initialized
DEBUG - 2011-04-30 08:37:00 --> Controller Class Initialized
DEBUG - 2011-04-30 08:37:00 --> Model Class Initialized
DEBUG - 2011-04-30 08:37:00 --> Model Class Initialized
DEBUG - 2011-04-30 08:37:00 --> Model Class Initialized
DEBUG - 2011-04-30 08:37:00 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-30 08:37:00 --> Database Driver Class Initialized
DEBUG - 2011-04-30 08:37:00 --> File loaded: application/views/table/main.php
DEBUG - 2011-04-30 08:37:00 --> Helper loaded: url_helper
DEBUG - 2011-04-30 08:37:00 --> File loaded: application/views/common/header.php
DEBUG - 2011-04-30 08:37:00 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-04-30 08:37:00 --> File loaded: application/views/common/footer.php
DEBUG - 2011-04-30 08:37:00 --> File loaded: application/views/layout/main.php
DEBUG - 2011-04-30 08:37:00 --> Final output sent to browser
DEBUG - 2011-04-30 08:37:00 --> Total execution time: 0.3602
DEBUG - 2011-04-30 08:37:01 --> Config Class Initialized
DEBUG - 2011-04-30 08:37:01 --> Hooks Class Initialized
DEBUG - 2011-04-30 08:37:01 --> Utf8 Class Initialized
DEBUG - 2011-04-30 08:37:01 --> UTF-8 Support Enabled
DEBUG - 2011-04-30 08:37:01 --> URI Class Initialized
DEBUG - 2011-04-30 08:37:01 --> Router Class Initialized
DEBUG - 2011-04-30 08:37:01 --> Output Class Initialized
DEBUG - 2011-04-30 08:37:01 --> Input Class Initialized
DEBUG - 2011-04-30 08:37:01 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-30 08:37:01 --> Language Class Initialized
DEBUG - 2011-04-30 08:37:01 --> Loader Class Initialized
DEBUG - 2011-04-30 08:37:01 --> Controller Class Initialized
DEBUG - 2011-04-30 08:37:01 --> Model Class Initialized
DEBUG - 2011-04-30 08:37:01 --> Model Class Initialized
DEBUG - 2011-04-30 08:37:01 --> Model Class Initialized
DEBUG - 2011-04-30 08:37:01 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-30 08:37:01 --> Database Driver Class Initialized
DEBUG - 2011-04-30 08:37:01 --> File loaded: application/views/table/main.php
DEBUG - 2011-04-30 08:37:01 --> Helper loaded: url_helper
DEBUG - 2011-04-30 08:37:01 --> File loaded: application/views/common/header.php
DEBUG - 2011-04-30 08:37:01 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-04-30 08:37:01 --> File loaded: application/views/common/footer.php
DEBUG - 2011-04-30 08:37:01 --> File loaded: application/views/layout/main.php
DEBUG - 2011-04-30 08:37:01 --> Final output sent to browser
DEBUG - 2011-04-30 08:37:01 --> Total execution time: 0.1032
DEBUG - 2011-04-30 08:37:01 --> Config Class Initialized
DEBUG - 2011-04-30 08:37:01 --> Hooks Class Initialized
DEBUG - 2011-04-30 08:37:01 --> Utf8 Class Initialized
DEBUG - 2011-04-30 08:37:01 --> UTF-8 Support Enabled
DEBUG - 2011-04-30 08:37:01 --> URI Class Initialized
DEBUG - 2011-04-30 08:37:01 --> Router Class Initialized
ERROR - 2011-04-30 08:37:01 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-04-30 08:37:05 --> Config Class Initialized
DEBUG - 2011-04-30 08:37:05 --> Hooks Class Initialized
DEBUG - 2011-04-30 08:37:05 --> Utf8 Class Initialized
DEBUG - 2011-04-30 08:37:05 --> UTF-8 Support Enabled
DEBUG - 2011-04-30 08:37:05 --> URI Class Initialized
DEBUG - 2011-04-30 08:37:05 --> Router Class Initialized
DEBUG - 2011-04-30 08:37:05 --> Output Class Initialized
DEBUG - 2011-04-30 08:37:05 --> Input Class Initialized
DEBUG - 2011-04-30 08:37:05 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-30 08:37:05 --> Language Class Initialized
DEBUG - 2011-04-30 08:37:05 --> Loader Class Initialized
DEBUG - 2011-04-30 08:37:05 --> Controller Class Initialized
DEBUG - 2011-04-30 08:37:05 --> Model Class Initialized
DEBUG - 2011-04-30 08:37:05 --> Model Class Initialized
DEBUG - 2011-04-30 08:37:05 --> Model Class Initialized
DEBUG - 2011-04-30 08:37:05 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-30 08:37:05 --> Database Driver Class Initialized
DEBUG - 2011-04-30 08:37:05 --> File loaded: application/views/table/main.php
DEBUG - 2011-04-30 08:37:05 --> Helper loaded: url_helper
DEBUG - 2011-04-30 08:37:05 --> File loaded: application/views/common/header.php
DEBUG - 2011-04-30 08:37:05 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-04-30 08:37:05 --> File loaded: application/views/common/footer.php
DEBUG - 2011-04-30 08:37:05 --> File loaded: application/views/layout/main.php
DEBUG - 2011-04-30 08:37:05 --> Final output sent to browser
DEBUG - 2011-04-30 08:37:05 --> Total execution time: 0.1922
DEBUG - 2011-04-30 08:37:06 --> Config Class Initialized
DEBUG - 2011-04-30 08:37:06 --> Hooks Class Initialized
DEBUG - 2011-04-30 08:37:06 --> Utf8 Class Initialized
DEBUG - 2011-04-30 08:37:06 --> UTF-8 Support Enabled
DEBUG - 2011-04-30 08:37:06 --> URI Class Initialized
DEBUG - 2011-04-30 08:37:06 --> Router Class Initialized
DEBUG - 2011-04-30 08:37:06 --> Output Class Initialized
DEBUG - 2011-04-30 08:37:06 --> Input Class Initialized
DEBUG - 2011-04-30 08:37:06 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-30 08:37:06 --> Language Class Initialized
DEBUG - 2011-04-30 08:37:06 --> Loader Class Initialized
DEBUG - 2011-04-30 08:37:06 --> Controller Class Initialized
DEBUG - 2011-04-30 08:37:06 --> Model Class Initialized
DEBUG - 2011-04-30 08:37:06 --> Model Class Initialized
DEBUG - 2011-04-30 08:37:06 --> Model Class Initialized
DEBUG - 2011-04-30 08:37:06 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-30 08:37:06 --> Database Driver Class Initialized
DEBUG - 2011-04-30 08:37:06 --> File loaded: application/views/table/main.php
DEBUG - 2011-04-30 08:37:06 --> Helper loaded: url_helper
DEBUG - 2011-04-30 08:37:06 --> File loaded: application/views/common/header.php
DEBUG - 2011-04-30 08:37:06 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-04-30 08:37:06 --> File loaded: application/views/common/footer.php
DEBUG - 2011-04-30 08:37:06 --> File loaded: application/views/layout/main.php
DEBUG - 2011-04-30 08:37:06 --> Final output sent to browser
DEBUG - 2011-04-30 08:37:06 --> Total execution time: 0.0537
DEBUG - 2011-04-30 08:37:06 --> Config Class Initialized
DEBUG - 2011-04-30 08:37:06 --> Hooks Class Initialized
DEBUG - 2011-04-30 08:37:06 --> Utf8 Class Initialized
DEBUG - 2011-04-30 08:37:06 --> UTF-8 Support Enabled
DEBUG - 2011-04-30 08:37:06 --> URI Class Initialized
DEBUG - 2011-04-30 08:37:06 --> Router Class Initialized
ERROR - 2011-04-30 08:37:06 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-04-30 08:37:19 --> Config Class Initialized
DEBUG - 2011-04-30 08:37:19 --> Hooks Class Initialized
DEBUG - 2011-04-30 08:37:19 --> Utf8 Class Initialized
DEBUG - 2011-04-30 08:37:19 --> UTF-8 Support Enabled
DEBUG - 2011-04-30 08:37:19 --> URI Class Initialized
DEBUG - 2011-04-30 08:37:19 --> Router Class Initialized
DEBUG - 2011-04-30 08:37:19 --> Output Class Initialized
DEBUG - 2011-04-30 08:37:19 --> Input Class Initialized
DEBUG - 2011-04-30 08:37:19 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-30 08:37:19 --> Language Class Initialized
DEBUG - 2011-04-30 08:37:19 --> Loader Class Initialized
DEBUG - 2011-04-30 08:37:19 --> Controller Class Initialized
DEBUG - 2011-04-30 08:37:19 --> Model Class Initialized
DEBUG - 2011-04-30 08:37:19 --> Model Class Initialized
DEBUG - 2011-04-30 08:37:19 --> Model Class Initialized
DEBUG - 2011-04-30 08:37:19 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-30 08:37:19 --> Database Driver Class Initialized
DEBUG - 2011-04-30 08:37:20 --> File loaded: application/views/table/main.php
DEBUG - 2011-04-30 08:37:20 --> Helper loaded: url_helper
DEBUG - 2011-04-30 08:37:20 --> File loaded: application/views/common/header.php
DEBUG - 2011-04-30 08:37:20 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-04-30 08:37:20 --> File loaded: application/views/common/footer.php
DEBUG - 2011-04-30 08:37:20 --> File loaded: application/views/layout/main.php
DEBUG - 2011-04-30 08:37:20 --> Final output sent to browser
DEBUG - 2011-04-30 08:37:20 --> Total execution time: 0.7434
DEBUG - 2011-04-30 08:37:21 --> Config Class Initialized
DEBUG - 2011-04-30 08:37:21 --> Hooks Class Initialized
DEBUG - 2011-04-30 08:37:21 --> Utf8 Class Initialized
DEBUG - 2011-04-30 08:37:21 --> UTF-8 Support Enabled
DEBUG - 2011-04-30 08:37:21 --> URI Class Initialized
DEBUG - 2011-04-30 08:37:21 --> Router Class Initialized
DEBUG - 2011-04-30 08:37:21 --> Output Class Initialized
DEBUG - 2011-04-30 08:37:21 --> Input Class Initialized
DEBUG - 2011-04-30 08:37:21 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-30 08:37:21 --> Language Class Initialized
DEBUG - 2011-04-30 08:37:21 --> Loader Class Initialized
DEBUG - 2011-04-30 08:37:21 --> Controller Class Initialized
DEBUG - 2011-04-30 08:37:21 --> Model Class Initialized
DEBUG - 2011-04-30 08:37:21 --> Model Class Initialized
DEBUG - 2011-04-30 08:37:21 --> Model Class Initialized
DEBUG - 2011-04-30 08:37:21 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-30 08:37:21 --> Database Driver Class Initialized
DEBUG - 2011-04-30 08:37:21 --> File loaded: application/views/table/main.php
DEBUG - 2011-04-30 08:37:21 --> Helper loaded: url_helper
DEBUG - 2011-04-30 08:37:21 --> File loaded: application/views/common/header.php
DEBUG - 2011-04-30 08:37:21 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-04-30 08:37:21 --> File loaded: application/views/common/footer.php
DEBUG - 2011-04-30 08:37:21 --> File loaded: application/views/layout/main.php
DEBUG - 2011-04-30 08:37:21 --> Final output sent to browser
DEBUG - 2011-04-30 08:37:21 --> Total execution time: 0.0509
DEBUG - 2011-04-30 08:37:21 --> Config Class Initialized
DEBUG - 2011-04-30 08:37:21 --> Hooks Class Initialized
DEBUG - 2011-04-30 08:37:21 --> Utf8 Class Initialized
DEBUG - 2011-04-30 08:37:21 --> UTF-8 Support Enabled
DEBUG - 2011-04-30 08:37:21 --> URI Class Initialized
DEBUG - 2011-04-30 08:37:21 --> Router Class Initialized
ERROR - 2011-04-30 08:37:21 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-04-30 08:37:52 --> Config Class Initialized
DEBUG - 2011-04-30 08:37:52 --> Hooks Class Initialized
DEBUG - 2011-04-30 08:37:52 --> Utf8 Class Initialized
DEBUG - 2011-04-30 08:37:52 --> UTF-8 Support Enabled
DEBUG - 2011-04-30 08:37:52 --> URI Class Initialized
DEBUG - 2011-04-30 08:37:52 --> Router Class Initialized
DEBUG - 2011-04-30 08:37:52 --> Output Class Initialized
DEBUG - 2011-04-30 08:37:52 --> Input Class Initialized
DEBUG - 2011-04-30 08:37:52 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-30 08:37:52 --> Language Class Initialized
DEBUG - 2011-04-30 08:37:52 --> Loader Class Initialized
DEBUG - 2011-04-30 08:37:52 --> Controller Class Initialized
DEBUG - 2011-04-30 08:37:52 --> Model Class Initialized
DEBUG - 2011-04-30 08:37:52 --> Model Class Initialized
DEBUG - 2011-04-30 08:37:52 --> Model Class Initialized
DEBUG - 2011-04-30 08:37:52 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-30 08:37:52 --> Database Driver Class Initialized
DEBUG - 2011-04-30 08:37:53 --> File loaded: application/views/table/main.php
DEBUG - 2011-04-30 08:37:53 --> Helper loaded: url_helper
DEBUG - 2011-04-30 08:37:53 --> File loaded: application/views/common/header.php
DEBUG - 2011-04-30 08:37:53 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-04-30 08:37:53 --> File loaded: application/views/common/footer.php
DEBUG - 2011-04-30 08:37:53 --> File loaded: application/views/layout/main.php
DEBUG - 2011-04-30 08:37:53 --> Final output sent to browser
DEBUG - 2011-04-30 08:37:53 --> Total execution time: 0.7677
DEBUG - 2011-04-30 08:37:54 --> Config Class Initialized
DEBUG - 2011-04-30 08:37:54 --> Hooks Class Initialized
DEBUG - 2011-04-30 08:37:54 --> Utf8 Class Initialized
DEBUG - 2011-04-30 08:37:54 --> UTF-8 Support Enabled
DEBUG - 2011-04-30 08:37:54 --> URI Class Initialized
DEBUG - 2011-04-30 08:37:54 --> Router Class Initialized
ERROR - 2011-04-30 08:37:54 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-04-30 08:37:55 --> Config Class Initialized
DEBUG - 2011-04-30 08:37:55 --> Hooks Class Initialized
DEBUG - 2011-04-30 08:37:55 --> Utf8 Class Initialized
DEBUG - 2011-04-30 08:37:55 --> UTF-8 Support Enabled
DEBUG - 2011-04-30 08:37:55 --> URI Class Initialized
DEBUG - 2011-04-30 08:37:55 --> Router Class Initialized
DEBUG - 2011-04-30 08:37:55 --> Output Class Initialized
DEBUG - 2011-04-30 08:37:55 --> Input Class Initialized
DEBUG - 2011-04-30 08:37:55 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-30 08:37:55 --> Language Class Initialized
DEBUG - 2011-04-30 08:37:55 --> Loader Class Initialized
DEBUG - 2011-04-30 08:37:55 --> Controller Class Initialized
DEBUG - 2011-04-30 08:37:55 --> Model Class Initialized
DEBUG - 2011-04-30 08:37:55 --> Model Class Initialized
DEBUG - 2011-04-30 08:37:55 --> Model Class Initialized
DEBUG - 2011-04-30 08:37:55 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-30 08:37:55 --> Database Driver Class Initialized
DEBUG - 2011-04-30 08:37:55 --> File loaded: application/views/table/main.php
DEBUG - 2011-04-30 08:37:55 --> Helper loaded: url_helper
DEBUG - 2011-04-30 08:37:55 --> File loaded: application/views/common/header.php
DEBUG - 2011-04-30 08:37:55 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-04-30 08:37:55 --> File loaded: application/views/common/footer.php
DEBUG - 2011-04-30 08:37:55 --> File loaded: application/views/layout/main.php
DEBUG - 2011-04-30 08:37:55 --> Final output sent to browser
DEBUG - 2011-04-30 08:37:55 --> Total execution time: 0.0527
DEBUG - 2011-04-30 08:38:03 --> Config Class Initialized
DEBUG - 2011-04-30 08:38:03 --> Hooks Class Initialized
DEBUG - 2011-04-30 08:38:03 --> Utf8 Class Initialized
DEBUG - 2011-04-30 08:38:03 --> UTF-8 Support Enabled
DEBUG - 2011-04-30 08:38:03 --> URI Class Initialized
DEBUG - 2011-04-30 08:38:03 --> Router Class Initialized
DEBUG - 2011-04-30 08:38:03 --> Output Class Initialized
DEBUG - 2011-04-30 08:38:03 --> Input Class Initialized
DEBUG - 2011-04-30 08:38:03 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-30 08:38:03 --> Language Class Initialized
DEBUG - 2011-04-30 08:38:03 --> Loader Class Initialized
DEBUG - 2011-04-30 08:38:03 --> Controller Class Initialized
DEBUG - 2011-04-30 08:38:03 --> Model Class Initialized
DEBUG - 2011-04-30 08:38:03 --> Model Class Initialized
DEBUG - 2011-04-30 08:38:03 --> Model Class Initialized
DEBUG - 2011-04-30 08:38:03 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-30 08:38:03 --> Database Driver Class Initialized
DEBUG - 2011-04-30 08:38:03 --> File loaded: application/views/table/main.php
DEBUG - 2011-04-30 08:38:03 --> Helper loaded: url_helper
DEBUG - 2011-04-30 08:38:03 --> File loaded: application/views/common/header.php
DEBUG - 2011-04-30 08:38:03 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-04-30 08:38:03 --> File loaded: application/views/common/footer.php
DEBUG - 2011-04-30 08:38:03 --> File loaded: application/views/layout/main.php
DEBUG - 2011-04-30 08:38:03 --> Final output sent to browser
DEBUG - 2011-04-30 08:38:03 --> Total execution time: 0.0521
DEBUG - 2011-04-30 08:38:04 --> Config Class Initialized
DEBUG - 2011-04-30 08:38:04 --> Hooks Class Initialized
DEBUG - 2011-04-30 08:38:04 --> Utf8 Class Initialized
DEBUG - 2011-04-30 08:38:04 --> UTF-8 Support Enabled
DEBUG - 2011-04-30 08:38:04 --> URI Class Initialized
DEBUG - 2011-04-30 08:38:04 --> Router Class Initialized
ERROR - 2011-04-30 08:38:04 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-04-30 08:38:09 --> Config Class Initialized
DEBUG - 2011-04-30 08:38:09 --> Hooks Class Initialized
DEBUG - 2011-04-30 08:38:09 --> Utf8 Class Initialized
DEBUG - 2011-04-30 08:38:09 --> UTF-8 Support Enabled
DEBUG - 2011-04-30 08:38:09 --> URI Class Initialized
DEBUG - 2011-04-30 08:38:09 --> Router Class Initialized
DEBUG - 2011-04-30 08:38:09 --> Output Class Initialized
DEBUG - 2011-04-30 08:38:09 --> Input Class Initialized
DEBUG - 2011-04-30 08:38:09 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-30 08:38:09 --> Language Class Initialized
DEBUG - 2011-04-30 08:38:09 --> Loader Class Initialized
DEBUG - 2011-04-30 08:38:09 --> Controller Class Initialized
DEBUG - 2011-04-30 08:38:09 --> Model Class Initialized
DEBUG - 2011-04-30 08:38:09 --> Model Class Initialized
DEBUG - 2011-04-30 08:38:09 --> Model Class Initialized
DEBUG - 2011-04-30 08:38:09 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-30 08:38:09 --> Database Driver Class Initialized
DEBUG - 2011-04-30 08:38:09 --> File loaded: application/views/table/main.php
DEBUG - 2011-04-30 08:38:09 --> Helper loaded: url_helper
DEBUG - 2011-04-30 08:38:09 --> File loaded: application/views/common/header.php
DEBUG - 2011-04-30 08:38:09 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-04-30 08:38:09 --> File loaded: application/views/common/footer.php
DEBUG - 2011-04-30 08:38:09 --> File loaded: application/views/layout/main.php
DEBUG - 2011-04-30 08:38:09 --> Final output sent to browser
DEBUG - 2011-04-30 08:38:09 --> Total execution time: 0.2085
DEBUG - 2011-04-30 08:38:10 --> Config Class Initialized
DEBUG - 2011-04-30 08:38:10 --> Hooks Class Initialized
DEBUG - 2011-04-30 08:38:10 --> Utf8 Class Initialized
DEBUG - 2011-04-30 08:38:10 --> UTF-8 Support Enabled
DEBUG - 2011-04-30 08:38:10 --> URI Class Initialized
DEBUG - 2011-04-30 08:38:10 --> Router Class Initialized
ERROR - 2011-04-30 08:38:10 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-04-30 08:38:10 --> Config Class Initialized
DEBUG - 2011-04-30 08:38:10 --> Hooks Class Initialized
DEBUG - 2011-04-30 08:38:10 --> Utf8 Class Initialized
DEBUG - 2011-04-30 08:38:10 --> UTF-8 Support Enabled
DEBUG - 2011-04-30 08:38:10 --> URI Class Initialized
DEBUG - 2011-04-30 08:38:10 --> Router Class Initialized
DEBUG - 2011-04-30 08:38:10 --> Output Class Initialized
DEBUG - 2011-04-30 08:38:10 --> Input Class Initialized
DEBUG - 2011-04-30 08:38:10 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-30 08:38:10 --> Language Class Initialized
DEBUG - 2011-04-30 08:38:10 --> Loader Class Initialized
DEBUG - 2011-04-30 08:38:10 --> Controller Class Initialized
DEBUG - 2011-04-30 08:38:10 --> Model Class Initialized
DEBUG - 2011-04-30 08:38:10 --> Model Class Initialized
DEBUG - 2011-04-30 08:38:10 --> Model Class Initialized
DEBUG - 2011-04-30 08:38:10 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-30 08:38:10 --> Database Driver Class Initialized
DEBUG - 2011-04-30 08:38:10 --> File loaded: application/views/table/main.php
DEBUG - 2011-04-30 08:38:10 --> Helper loaded: url_helper
DEBUG - 2011-04-30 08:38:10 --> File loaded: application/views/common/header.php
DEBUG - 2011-04-30 08:38:10 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-04-30 08:38:10 --> File loaded: application/views/common/footer.php
DEBUG - 2011-04-30 08:38:10 --> File loaded: application/views/layout/main.php
DEBUG - 2011-04-30 08:38:10 --> Final output sent to browser
DEBUG - 2011-04-30 08:38:10 --> Total execution time: 0.0575
DEBUG - 2011-04-30 08:38:17 --> Config Class Initialized
DEBUG - 2011-04-30 08:38:17 --> Hooks Class Initialized
DEBUG - 2011-04-30 08:38:17 --> Utf8 Class Initialized
DEBUG - 2011-04-30 08:38:17 --> UTF-8 Support Enabled
DEBUG - 2011-04-30 08:38:17 --> URI Class Initialized
DEBUG - 2011-04-30 08:38:17 --> Router Class Initialized
DEBUG - 2011-04-30 08:38:17 --> Output Class Initialized
DEBUG - 2011-04-30 08:38:17 --> Input Class Initialized
DEBUG - 2011-04-30 08:38:17 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-30 08:38:17 --> Language Class Initialized
DEBUG - 2011-04-30 08:38:17 --> Loader Class Initialized
DEBUG - 2011-04-30 08:38:17 --> Controller Class Initialized
DEBUG - 2011-04-30 08:38:17 --> Model Class Initialized
DEBUG - 2011-04-30 08:38:17 --> Model Class Initialized
DEBUG - 2011-04-30 08:38:17 --> Model Class Initialized
DEBUG - 2011-04-30 08:38:17 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-30 08:38:17 --> Database Driver Class Initialized
DEBUG - 2011-04-30 08:38:18 --> File loaded: application/views/table/main.php
DEBUG - 2011-04-30 08:38:18 --> Helper loaded: url_helper
DEBUG - 2011-04-30 08:38:18 --> File loaded: application/views/common/header.php
DEBUG - 2011-04-30 08:38:18 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-04-30 08:38:18 --> File loaded: application/views/common/footer.php
DEBUG - 2011-04-30 08:38:18 --> File loaded: application/views/layout/main.php
DEBUG - 2011-04-30 08:38:18 --> Final output sent to browser
DEBUG - 2011-04-30 08:38:18 --> Total execution time: 0.5659
DEBUG - 2011-04-30 08:38:19 --> Config Class Initialized
DEBUG - 2011-04-30 08:38:19 --> Hooks Class Initialized
DEBUG - 2011-04-30 08:38:19 --> Utf8 Class Initialized
DEBUG - 2011-04-30 08:38:19 --> UTF-8 Support Enabled
DEBUG - 2011-04-30 08:38:19 --> URI Class Initialized
DEBUG - 2011-04-30 08:38:19 --> Router Class Initialized
DEBUG - 2011-04-30 08:38:19 --> Output Class Initialized
DEBUG - 2011-04-30 08:38:19 --> Input Class Initialized
DEBUG - 2011-04-30 08:38:19 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-30 08:38:19 --> Language Class Initialized
DEBUG - 2011-04-30 08:38:19 --> Loader Class Initialized
DEBUG - 2011-04-30 08:38:19 --> Controller Class Initialized
DEBUG - 2011-04-30 08:38:19 --> Model Class Initialized
DEBUG - 2011-04-30 08:38:19 --> Model Class Initialized
DEBUG - 2011-04-30 08:38:19 --> Model Class Initialized
DEBUG - 2011-04-30 08:38:19 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-30 08:38:19 --> Database Driver Class Initialized
DEBUG - 2011-04-30 08:38:19 --> File loaded: application/views/table/main.php
DEBUG - 2011-04-30 08:38:19 --> Helper loaded: url_helper
DEBUG - 2011-04-30 08:38:19 --> File loaded: application/views/common/header.php
DEBUG - 2011-04-30 08:38:19 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-04-30 08:38:19 --> File loaded: application/views/common/footer.php
DEBUG - 2011-04-30 08:38:19 --> File loaded: application/views/layout/main.php
DEBUG - 2011-04-30 08:38:19 --> Final output sent to browser
DEBUG - 2011-04-30 08:38:19 --> Total execution time: 0.0957
DEBUG - 2011-04-30 08:38:19 --> Config Class Initialized
DEBUG - 2011-04-30 08:38:19 --> Hooks Class Initialized
DEBUG - 2011-04-30 08:38:19 --> Utf8 Class Initialized
DEBUG - 2011-04-30 08:38:19 --> UTF-8 Support Enabled
DEBUG - 2011-04-30 08:38:19 --> URI Class Initialized
DEBUG - 2011-04-30 08:38:19 --> Router Class Initialized
ERROR - 2011-04-30 08:38:19 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-04-30 09:20:58 --> Config Class Initialized
DEBUG - 2011-04-30 09:20:58 --> Hooks Class Initialized
DEBUG - 2011-04-30 09:20:58 --> Utf8 Class Initialized
DEBUG - 2011-04-30 09:20:58 --> UTF-8 Support Enabled
DEBUG - 2011-04-30 09:20:58 --> URI Class Initialized
DEBUG - 2011-04-30 09:20:58 --> Router Class Initialized
DEBUG - 2011-04-30 09:20:58 --> Output Class Initialized
DEBUG - 2011-04-30 09:20:58 --> Input Class Initialized
DEBUG - 2011-04-30 09:20:58 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-30 09:20:58 --> Language Class Initialized
DEBUG - 2011-04-30 09:20:58 --> Loader Class Initialized
DEBUG - 2011-04-30 09:20:58 --> Controller Class Initialized
ERROR - 2011-04-30 09:20:58 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-04-30 09:20:58 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-04-30 09:20:58 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-04-30 09:20:58 --> Model Class Initialized
DEBUG - 2011-04-30 09:20:58 --> Model Class Initialized
DEBUG - 2011-04-30 09:20:58 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-30 09:20:59 --> Database Driver Class Initialized
DEBUG - 2011-04-30 09:20:59 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-04-30 09:20:59 --> Helper loaded: url_helper
DEBUG - 2011-04-30 09:20:59 --> File loaded: application/views/common/header.php
DEBUG - 2011-04-30 09:20:59 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-04-30 09:20:59 --> File loaded: application/views/common/footer.php
DEBUG - 2011-04-30 09:20:59 --> File loaded: application/views/layout/main.php
DEBUG - 2011-04-30 09:20:59 --> Final output sent to browser
DEBUG - 2011-04-30 09:20:59 --> Total execution time: 0.4892
DEBUG - 2011-04-30 09:21:00 --> Config Class Initialized
DEBUG - 2011-04-30 09:21:00 --> Hooks Class Initialized
DEBUG - 2011-04-30 09:21:00 --> Utf8 Class Initialized
DEBUG - 2011-04-30 09:21:00 --> UTF-8 Support Enabled
DEBUG - 2011-04-30 09:21:00 --> URI Class Initialized
DEBUG - 2011-04-30 09:21:00 --> Router Class Initialized
DEBUG - 2011-04-30 09:21:00 --> Output Class Initialized
DEBUG - 2011-04-30 09:21:00 --> Input Class Initialized
DEBUG - 2011-04-30 09:21:00 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-30 09:21:00 --> Language Class Initialized
DEBUG - 2011-04-30 09:21:00 --> Loader Class Initialized
DEBUG - 2011-04-30 09:21:00 --> Controller Class Initialized
DEBUG - 2011-04-30 09:21:00 --> Model Class Initialized
DEBUG - 2011-04-30 09:21:00 --> Model Class Initialized
DEBUG - 2011-04-30 09:21:00 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-30 09:21:00 --> Database Driver Class Initialized
DEBUG - 2011-04-30 09:21:00 --> Final output sent to browser
DEBUG - 2011-04-30 09:21:00 --> Total execution time: 0.7517
DEBUG - 2011-04-30 09:21:02 --> Config Class Initialized
DEBUG - 2011-04-30 09:21:02 --> Hooks Class Initialized
DEBUG - 2011-04-30 09:21:02 --> Utf8 Class Initialized
DEBUG - 2011-04-30 09:21:02 --> UTF-8 Support Enabled
DEBUG - 2011-04-30 09:21:02 --> URI Class Initialized
DEBUG - 2011-04-30 09:21:02 --> Router Class Initialized
ERROR - 2011-04-30 09:21:02 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-04-30 09:21:02 --> Config Class Initialized
DEBUG - 2011-04-30 09:21:02 --> Hooks Class Initialized
DEBUG - 2011-04-30 09:21:02 --> Utf8 Class Initialized
DEBUG - 2011-04-30 09:21:02 --> UTF-8 Support Enabled
DEBUG - 2011-04-30 09:21:02 --> URI Class Initialized
DEBUG - 2011-04-30 09:21:02 --> Router Class Initialized
ERROR - 2011-04-30 09:21:02 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-04-30 09:21:03 --> Config Class Initialized
DEBUG - 2011-04-30 09:21:03 --> Hooks Class Initialized
DEBUG - 2011-04-30 09:21:03 --> Utf8 Class Initialized
DEBUG - 2011-04-30 09:21:03 --> UTF-8 Support Enabled
DEBUG - 2011-04-30 09:21:03 --> URI Class Initialized
DEBUG - 2011-04-30 09:21:03 --> Router Class Initialized
ERROR - 2011-04-30 09:21:03 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-04-30 09:23:03 --> Config Class Initialized
DEBUG - 2011-04-30 09:23:03 --> Hooks Class Initialized
DEBUG - 2011-04-30 09:23:03 --> Utf8 Class Initialized
DEBUG - 2011-04-30 09:23:03 --> UTF-8 Support Enabled
DEBUG - 2011-04-30 09:23:03 --> URI Class Initialized
DEBUG - 2011-04-30 09:23:03 --> Router Class Initialized
DEBUG - 2011-04-30 09:23:03 --> Output Class Initialized
DEBUG - 2011-04-30 09:23:03 --> Input Class Initialized
DEBUG - 2011-04-30 09:23:03 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-30 09:23:03 --> Language Class Initialized
DEBUG - 2011-04-30 09:23:03 --> Loader Class Initialized
DEBUG - 2011-04-30 09:23:03 --> Controller Class Initialized
ERROR - 2011-04-30 09:23:03 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-04-30 09:23:03 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-04-30 09:23:03 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-04-30 09:23:03 --> Model Class Initialized
DEBUG - 2011-04-30 09:23:03 --> Model Class Initialized
DEBUG - 2011-04-30 09:23:03 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-30 09:23:03 --> Database Driver Class Initialized
DEBUG - 2011-04-30 09:23:03 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-04-30 09:23:03 --> Helper loaded: url_helper
DEBUG - 2011-04-30 09:23:03 --> File loaded: application/views/common/header.php
DEBUG - 2011-04-30 09:23:03 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-04-30 09:23:03 --> File loaded: application/views/common/footer.php
DEBUG - 2011-04-30 09:23:03 --> File loaded: application/views/layout/main.php
DEBUG - 2011-04-30 09:23:03 --> Final output sent to browser
DEBUG - 2011-04-30 09:23:03 --> Total execution time: 0.0569
DEBUG - 2011-04-30 09:23:03 --> Config Class Initialized
DEBUG - 2011-04-30 09:23:03 --> Hooks Class Initialized
DEBUG - 2011-04-30 09:23:03 --> Utf8 Class Initialized
DEBUG - 2011-04-30 09:23:03 --> UTF-8 Support Enabled
DEBUG - 2011-04-30 09:23:03 --> URI Class Initialized
DEBUG - 2011-04-30 09:23:03 --> Router Class Initialized
DEBUG - 2011-04-30 09:23:03 --> Output Class Initialized
DEBUG - 2011-04-30 09:23:03 --> Input Class Initialized
DEBUG - 2011-04-30 09:23:03 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-30 09:23:03 --> Language Class Initialized
DEBUG - 2011-04-30 09:23:03 --> Loader Class Initialized
DEBUG - 2011-04-30 09:23:03 --> Controller Class Initialized
DEBUG - 2011-04-30 09:23:03 --> Model Class Initialized
DEBUG - 2011-04-30 09:23:03 --> Model Class Initialized
DEBUG - 2011-04-30 09:23:03 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-30 09:23:03 --> Database Driver Class Initialized
DEBUG - 2011-04-30 09:23:04 --> Final output sent to browser
DEBUG - 2011-04-30 09:23:04 --> Total execution time: 0.7689
DEBUG - 2011-04-30 09:24:34 --> Config Class Initialized
DEBUG - 2011-04-30 09:24:34 --> Hooks Class Initialized
DEBUG - 2011-04-30 09:24:34 --> Utf8 Class Initialized
DEBUG - 2011-04-30 09:24:34 --> UTF-8 Support Enabled
DEBUG - 2011-04-30 09:24:34 --> URI Class Initialized
DEBUG - 2011-04-30 09:24:34 --> Router Class Initialized
DEBUG - 2011-04-30 09:24:34 --> Output Class Initialized
DEBUG - 2011-04-30 09:24:34 --> Input Class Initialized
DEBUG - 2011-04-30 09:24:34 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-30 09:24:34 --> Language Class Initialized
DEBUG - 2011-04-30 09:24:34 --> Loader Class Initialized
DEBUG - 2011-04-30 09:24:34 --> Controller Class Initialized
ERROR - 2011-04-30 09:24:34 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-04-30 09:24:34 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-04-30 09:24:34 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-04-30 09:24:34 --> Model Class Initialized
DEBUG - 2011-04-30 09:24:34 --> Model Class Initialized
DEBUG - 2011-04-30 09:24:34 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-30 09:24:34 --> Database Driver Class Initialized
DEBUG - 2011-04-30 09:24:34 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-04-30 09:24:34 --> Helper loaded: url_helper
DEBUG - 2011-04-30 09:24:34 --> File loaded: application/views/common/header.php
DEBUG - 2011-04-30 09:24:34 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-04-30 09:24:34 --> File loaded: application/views/common/footer.php
DEBUG - 2011-04-30 09:24:34 --> File loaded: application/views/layout/main.php
DEBUG - 2011-04-30 09:24:34 --> Final output sent to browser
DEBUG - 2011-04-30 09:24:34 --> Total execution time: 0.0331
DEBUG - 2011-04-30 09:24:35 --> Config Class Initialized
DEBUG - 2011-04-30 09:24:35 --> Hooks Class Initialized
DEBUG - 2011-04-30 09:24:35 --> Utf8 Class Initialized
DEBUG - 2011-04-30 09:24:35 --> UTF-8 Support Enabled
DEBUG - 2011-04-30 09:24:35 --> URI Class Initialized
DEBUG - 2011-04-30 09:24:35 --> Router Class Initialized
DEBUG - 2011-04-30 09:24:35 --> Output Class Initialized
DEBUG - 2011-04-30 09:24:35 --> Input Class Initialized
DEBUG - 2011-04-30 09:24:35 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-30 09:24:35 --> Language Class Initialized
DEBUG - 2011-04-30 09:24:35 --> Loader Class Initialized
DEBUG - 2011-04-30 09:24:35 --> Controller Class Initialized
DEBUG - 2011-04-30 09:24:35 --> Model Class Initialized
DEBUG - 2011-04-30 09:24:35 --> Model Class Initialized
DEBUG - 2011-04-30 09:24:35 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-30 09:24:35 --> Database Driver Class Initialized
DEBUG - 2011-04-30 09:24:35 --> Final output sent to browser
DEBUG - 2011-04-30 09:24:35 --> Total execution time: 0.5933
DEBUG - 2011-04-30 09:24:36 --> Config Class Initialized
DEBUG - 2011-04-30 09:24:36 --> Hooks Class Initialized
DEBUG - 2011-04-30 09:24:36 --> Utf8 Class Initialized
DEBUG - 2011-04-30 09:24:36 --> UTF-8 Support Enabled
DEBUG - 2011-04-30 09:24:36 --> URI Class Initialized
DEBUG - 2011-04-30 09:24:36 --> Router Class Initialized
DEBUG - 2011-04-30 09:24:36 --> Output Class Initialized
DEBUG - 2011-04-30 09:24:36 --> Input Class Initialized
DEBUG - 2011-04-30 09:24:36 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-30 09:24:36 --> Language Class Initialized
DEBUG - 2011-04-30 09:24:36 --> Loader Class Initialized
DEBUG - 2011-04-30 09:24:36 --> Controller Class Initialized
ERROR - 2011-04-30 09:24:36 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-04-30 09:24:36 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-04-30 09:24:36 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-04-30 09:24:36 --> Model Class Initialized
DEBUG - 2011-04-30 09:24:36 --> Model Class Initialized
DEBUG - 2011-04-30 09:24:36 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-30 09:24:36 --> Database Driver Class Initialized
DEBUG - 2011-04-30 09:24:36 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-04-30 09:24:36 --> Helper loaded: url_helper
DEBUG - 2011-04-30 09:24:36 --> File loaded: application/views/common/header.php
DEBUG - 2011-04-30 09:24:36 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-04-30 09:24:36 --> File loaded: application/views/common/footer.php
DEBUG - 2011-04-30 09:24:36 --> File loaded: application/views/layout/main.php
DEBUG - 2011-04-30 09:24:36 --> Final output sent to browser
DEBUG - 2011-04-30 09:24:36 --> Total execution time: 0.0345
DEBUG - 2011-04-30 09:25:21 --> Config Class Initialized
DEBUG - 2011-04-30 09:25:21 --> Hooks Class Initialized
DEBUG - 2011-04-30 09:25:21 --> Utf8 Class Initialized
DEBUG - 2011-04-30 09:25:21 --> UTF-8 Support Enabled
DEBUG - 2011-04-30 09:25:21 --> URI Class Initialized
DEBUG - 2011-04-30 09:25:21 --> Router Class Initialized
DEBUG - 2011-04-30 09:25:21 --> Output Class Initialized
DEBUG - 2011-04-30 09:25:21 --> Input Class Initialized
DEBUG - 2011-04-30 09:25:21 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-30 09:25:21 --> Language Class Initialized
DEBUG - 2011-04-30 09:25:21 --> Loader Class Initialized
DEBUG - 2011-04-30 09:25:21 --> Controller Class Initialized
ERROR - 2011-04-30 09:25:21 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-04-30 09:25:21 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-04-30 09:25:21 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-04-30 09:25:21 --> Model Class Initialized
DEBUG - 2011-04-30 09:25:21 --> Model Class Initialized
DEBUG - 2011-04-30 09:25:21 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-30 09:25:21 --> Database Driver Class Initialized
DEBUG - 2011-04-30 09:25:21 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-04-30 09:25:21 --> Helper loaded: url_helper
DEBUG - 2011-04-30 09:25:21 --> File loaded: application/views/common/header.php
DEBUG - 2011-04-30 09:25:21 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-04-30 09:25:21 --> File loaded: application/views/common/footer.php
DEBUG - 2011-04-30 09:25:21 --> File loaded: application/views/layout/main.php
DEBUG - 2011-04-30 09:25:21 --> Final output sent to browser
DEBUG - 2011-04-30 09:25:21 --> Total execution time: 0.1593
DEBUG - 2011-04-30 09:25:22 --> Config Class Initialized
DEBUG - 2011-04-30 09:25:22 --> Hooks Class Initialized
DEBUG - 2011-04-30 09:25:22 --> Utf8 Class Initialized
DEBUG - 2011-04-30 09:25:22 --> UTF-8 Support Enabled
DEBUG - 2011-04-30 09:25:22 --> URI Class Initialized
DEBUG - 2011-04-30 09:25:22 --> Router Class Initialized
DEBUG - 2011-04-30 09:25:22 --> Output Class Initialized
DEBUG - 2011-04-30 09:25:22 --> Input Class Initialized
DEBUG - 2011-04-30 09:25:22 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-30 09:25:22 --> Language Class Initialized
DEBUG - 2011-04-30 09:25:22 --> Loader Class Initialized
DEBUG - 2011-04-30 09:25:22 --> Controller Class Initialized
DEBUG - 2011-04-30 09:25:22 --> Model Class Initialized
DEBUG - 2011-04-30 09:25:22 --> Model Class Initialized
DEBUG - 2011-04-30 09:25:22 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-30 09:25:22 --> Database Driver Class Initialized
DEBUG - 2011-04-30 09:25:23 --> Final output sent to browser
DEBUG - 2011-04-30 09:25:23 --> Total execution time: 0.7969
DEBUG - 2011-04-30 09:26:20 --> Config Class Initialized
DEBUG - 2011-04-30 09:26:20 --> Hooks Class Initialized
DEBUG - 2011-04-30 09:26:20 --> Utf8 Class Initialized
DEBUG - 2011-04-30 09:26:20 --> UTF-8 Support Enabled
DEBUG - 2011-04-30 09:26:20 --> URI Class Initialized
DEBUG - 2011-04-30 09:26:20 --> Router Class Initialized
DEBUG - 2011-04-30 09:26:20 --> Output Class Initialized
DEBUG - 2011-04-30 09:26:20 --> Input Class Initialized
DEBUG - 2011-04-30 09:26:20 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-30 09:26:20 --> Language Class Initialized
DEBUG - 2011-04-30 09:26:20 --> Loader Class Initialized
DEBUG - 2011-04-30 09:26:20 --> Controller Class Initialized
ERROR - 2011-04-30 09:26:20 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-04-30 09:26:20 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-04-30 09:26:20 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-04-30 09:26:20 --> Model Class Initialized
DEBUG - 2011-04-30 09:26:20 --> Model Class Initialized
DEBUG - 2011-04-30 09:26:20 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-30 09:26:20 --> Database Driver Class Initialized
DEBUG - 2011-04-30 09:26:20 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-04-30 09:26:20 --> Helper loaded: url_helper
DEBUG - 2011-04-30 09:26:20 --> File loaded: application/views/common/header.php
DEBUG - 2011-04-30 09:26:20 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-04-30 09:26:20 --> File loaded: application/views/common/footer.php
DEBUG - 2011-04-30 09:26:20 --> File loaded: application/views/layout/main.php
DEBUG - 2011-04-30 09:26:20 --> Final output sent to browser
DEBUG - 2011-04-30 09:26:20 --> Total execution time: 0.0298
DEBUG - 2011-04-30 09:26:25 --> Config Class Initialized
DEBUG - 2011-04-30 09:26:25 --> Hooks Class Initialized
DEBUG - 2011-04-30 09:26:25 --> Utf8 Class Initialized
DEBUG - 2011-04-30 09:26:25 --> UTF-8 Support Enabled
DEBUG - 2011-04-30 09:26:25 --> URI Class Initialized
DEBUG - 2011-04-30 09:26:25 --> Router Class Initialized
DEBUG - 2011-04-30 09:26:25 --> Output Class Initialized
DEBUG - 2011-04-30 09:26:25 --> Input Class Initialized
DEBUG - 2011-04-30 09:26:25 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-30 09:26:25 --> Language Class Initialized
DEBUG - 2011-04-30 09:26:25 --> Loader Class Initialized
DEBUG - 2011-04-30 09:26:25 --> Controller Class Initialized
DEBUG - 2011-04-30 09:26:25 --> Model Class Initialized
DEBUG - 2011-04-30 09:26:25 --> Model Class Initialized
DEBUG - 2011-04-30 09:26:25 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-30 09:26:25 --> Database Driver Class Initialized
DEBUG - 2011-04-30 09:26:26 --> Final output sent to browser
DEBUG - 2011-04-30 09:26:26 --> Total execution time: 0.8612
DEBUG - 2011-04-30 09:27:08 --> Config Class Initialized
DEBUG - 2011-04-30 09:27:08 --> Hooks Class Initialized
DEBUG - 2011-04-30 09:27:08 --> Utf8 Class Initialized
DEBUG - 2011-04-30 09:27:08 --> UTF-8 Support Enabled
DEBUG - 2011-04-30 09:27:08 --> URI Class Initialized
DEBUG - 2011-04-30 09:27:08 --> Router Class Initialized
DEBUG - 2011-04-30 09:27:08 --> Output Class Initialized
DEBUG - 2011-04-30 09:27:08 --> Input Class Initialized
DEBUG - 2011-04-30 09:27:08 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-30 09:27:08 --> Language Class Initialized
DEBUG - 2011-04-30 09:27:08 --> Loader Class Initialized
DEBUG - 2011-04-30 09:27:08 --> Controller Class Initialized
ERROR - 2011-04-30 09:27:08 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-04-30 09:27:08 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-04-30 09:27:08 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-04-30 09:27:08 --> Model Class Initialized
DEBUG - 2011-04-30 09:27:08 --> Model Class Initialized
DEBUG - 2011-04-30 09:27:08 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-30 09:27:08 --> Database Driver Class Initialized
DEBUG - 2011-04-30 09:27:08 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-04-30 09:27:08 --> Helper loaded: url_helper
DEBUG - 2011-04-30 09:27:08 --> File loaded: application/views/common/header.php
DEBUG - 2011-04-30 09:27:08 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-04-30 09:27:08 --> File loaded: application/views/common/footer.php
DEBUG - 2011-04-30 09:27:08 --> File loaded: application/views/layout/main.php
DEBUG - 2011-04-30 09:27:08 --> Final output sent to browser
DEBUG - 2011-04-30 09:27:08 --> Total execution time: 0.0299
DEBUG - 2011-04-30 09:27:09 --> Config Class Initialized
DEBUG - 2011-04-30 09:27:09 --> Hooks Class Initialized
DEBUG - 2011-04-30 09:27:09 --> Utf8 Class Initialized
DEBUG - 2011-04-30 09:27:09 --> UTF-8 Support Enabled
DEBUG - 2011-04-30 09:27:09 --> URI Class Initialized
DEBUG - 2011-04-30 09:27:09 --> Router Class Initialized
DEBUG - 2011-04-30 09:27:09 --> Output Class Initialized
DEBUG - 2011-04-30 09:27:09 --> Input Class Initialized
DEBUG - 2011-04-30 09:27:09 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-30 09:27:09 --> Language Class Initialized
DEBUG - 2011-04-30 09:27:09 --> Loader Class Initialized
DEBUG - 2011-04-30 09:27:09 --> Controller Class Initialized
DEBUG - 2011-04-30 09:27:09 --> Model Class Initialized
DEBUG - 2011-04-30 09:27:09 --> Model Class Initialized
DEBUG - 2011-04-30 09:27:09 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-30 09:27:09 --> Database Driver Class Initialized
DEBUG - 2011-04-30 09:27:10 --> Final output sent to browser
DEBUG - 2011-04-30 09:27:10 --> Total execution time: 1.0397
DEBUG - 2011-04-30 09:27:26 --> Config Class Initialized
DEBUG - 2011-04-30 09:27:26 --> Hooks Class Initialized
DEBUG - 2011-04-30 09:27:26 --> Utf8 Class Initialized
DEBUG - 2011-04-30 09:27:26 --> UTF-8 Support Enabled
DEBUG - 2011-04-30 09:27:26 --> URI Class Initialized
DEBUG - 2011-04-30 09:27:26 --> Router Class Initialized
DEBUG - 2011-04-30 09:27:26 --> Output Class Initialized
DEBUG - 2011-04-30 09:27:26 --> Input Class Initialized
DEBUG - 2011-04-30 09:27:26 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-30 09:27:26 --> Language Class Initialized
DEBUG - 2011-04-30 09:27:26 --> Loader Class Initialized
DEBUG - 2011-04-30 09:27:26 --> Controller Class Initialized
ERROR - 2011-04-30 09:27:26 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-04-30 09:27:26 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-04-30 09:27:26 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-04-30 09:27:26 --> Model Class Initialized
DEBUG - 2011-04-30 09:27:26 --> Model Class Initialized
DEBUG - 2011-04-30 09:27:26 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-30 09:27:26 --> Database Driver Class Initialized
DEBUG - 2011-04-30 09:27:26 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-04-30 09:27:26 --> Helper loaded: url_helper
DEBUG - 2011-04-30 09:27:26 --> File loaded: application/views/common/header.php
DEBUG - 2011-04-30 09:27:26 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-04-30 09:27:26 --> File loaded: application/views/common/footer.php
DEBUG - 2011-04-30 09:27:26 --> File loaded: application/views/layout/main.php
DEBUG - 2011-04-30 09:27:26 --> Final output sent to browser
DEBUG - 2011-04-30 09:27:26 --> Total execution time: 0.1350
DEBUG - 2011-04-30 09:27:27 --> Config Class Initialized
DEBUG - 2011-04-30 09:27:27 --> Hooks Class Initialized
DEBUG - 2011-04-30 09:27:27 --> Utf8 Class Initialized
DEBUG - 2011-04-30 09:27:27 --> UTF-8 Support Enabled
DEBUG - 2011-04-30 09:27:27 --> URI Class Initialized
DEBUG - 2011-04-30 09:27:27 --> Router Class Initialized
DEBUG - 2011-04-30 09:27:27 --> Output Class Initialized
DEBUG - 2011-04-30 09:27:27 --> Input Class Initialized
DEBUG - 2011-04-30 09:27:27 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-30 09:27:27 --> Language Class Initialized
DEBUG - 2011-04-30 09:27:27 --> Loader Class Initialized
DEBUG - 2011-04-30 09:27:27 --> Controller Class Initialized
DEBUG - 2011-04-30 09:27:27 --> Model Class Initialized
DEBUG - 2011-04-30 09:27:27 --> Model Class Initialized
DEBUG - 2011-04-30 09:27:27 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-30 09:27:27 --> Database Driver Class Initialized
DEBUG - 2011-04-30 09:27:28 --> Final output sent to browser
DEBUG - 2011-04-30 09:27:28 --> Total execution time: 0.7549
DEBUG - 2011-04-30 09:27:57 --> Config Class Initialized
DEBUG - 2011-04-30 09:27:57 --> Hooks Class Initialized
DEBUG - 2011-04-30 09:27:57 --> Utf8 Class Initialized
DEBUG - 2011-04-30 09:27:57 --> UTF-8 Support Enabled
DEBUG - 2011-04-30 09:27:57 --> URI Class Initialized
DEBUG - 2011-04-30 09:27:57 --> Router Class Initialized
DEBUG - 2011-04-30 09:27:57 --> Output Class Initialized
DEBUG - 2011-04-30 09:27:57 --> Input Class Initialized
DEBUG - 2011-04-30 09:27:57 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-30 09:27:57 --> Language Class Initialized
DEBUG - 2011-04-30 09:27:57 --> Loader Class Initialized
DEBUG - 2011-04-30 09:27:57 --> Controller Class Initialized
ERROR - 2011-04-30 09:27:57 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-04-30 09:27:57 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-04-30 09:27:57 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-04-30 09:27:57 --> Model Class Initialized
DEBUG - 2011-04-30 09:27:57 --> Model Class Initialized
DEBUG - 2011-04-30 09:27:57 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-30 09:27:57 --> Database Driver Class Initialized
DEBUG - 2011-04-30 09:27:57 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-04-30 09:27:57 --> Helper loaded: url_helper
DEBUG - 2011-04-30 09:27:57 --> File loaded: application/views/common/header.php
DEBUG - 2011-04-30 09:27:57 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-04-30 09:27:57 --> File loaded: application/views/common/footer.php
DEBUG - 2011-04-30 09:27:57 --> File loaded: application/views/layout/main.php
DEBUG - 2011-04-30 09:27:57 --> Final output sent to browser
DEBUG - 2011-04-30 09:27:57 --> Total execution time: 0.0332
DEBUG - 2011-04-30 09:27:58 --> Config Class Initialized
DEBUG - 2011-04-30 09:27:58 --> Hooks Class Initialized
DEBUG - 2011-04-30 09:27:58 --> Utf8 Class Initialized
DEBUG - 2011-04-30 09:27:58 --> UTF-8 Support Enabled
DEBUG - 2011-04-30 09:27:58 --> URI Class Initialized
DEBUG - 2011-04-30 09:27:58 --> Router Class Initialized
DEBUG - 2011-04-30 09:27:58 --> Output Class Initialized
DEBUG - 2011-04-30 09:27:58 --> Input Class Initialized
DEBUG - 2011-04-30 09:27:58 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-30 09:27:58 --> Language Class Initialized
DEBUG - 2011-04-30 09:27:58 --> Loader Class Initialized
DEBUG - 2011-04-30 09:27:58 --> Controller Class Initialized
DEBUG - 2011-04-30 09:27:58 --> Model Class Initialized
DEBUG - 2011-04-30 09:27:58 --> Model Class Initialized
DEBUG - 2011-04-30 09:27:58 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-30 09:27:58 --> Database Driver Class Initialized
DEBUG - 2011-04-30 09:27:58 --> Final output sent to browser
DEBUG - 2011-04-30 09:27:58 --> Total execution time: 0.5910
DEBUG - 2011-04-30 09:28:40 --> Config Class Initialized
DEBUG - 2011-04-30 09:28:40 --> Hooks Class Initialized
DEBUG - 2011-04-30 09:28:40 --> Utf8 Class Initialized
DEBUG - 2011-04-30 09:28:40 --> UTF-8 Support Enabled
DEBUG - 2011-04-30 09:28:40 --> URI Class Initialized
DEBUG - 2011-04-30 09:28:40 --> Router Class Initialized
DEBUG - 2011-04-30 09:28:40 --> Output Class Initialized
DEBUG - 2011-04-30 09:28:40 --> Input Class Initialized
DEBUG - 2011-04-30 09:28:40 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-30 09:28:40 --> Language Class Initialized
DEBUG - 2011-04-30 09:28:40 --> Loader Class Initialized
DEBUG - 2011-04-30 09:28:40 --> Controller Class Initialized
ERROR - 2011-04-30 09:28:40 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-04-30 09:28:40 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-04-30 09:28:40 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-04-30 09:28:40 --> Model Class Initialized
DEBUG - 2011-04-30 09:28:40 --> Model Class Initialized
DEBUG - 2011-04-30 09:28:40 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-30 09:28:40 --> Database Driver Class Initialized
DEBUG - 2011-04-30 09:28:40 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-04-30 09:28:40 --> Helper loaded: url_helper
DEBUG - 2011-04-30 09:28:40 --> File loaded: application/views/common/header.php
DEBUG - 2011-04-30 09:28:40 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-04-30 09:28:40 --> File loaded: application/views/common/footer.php
DEBUG - 2011-04-30 09:28:40 --> File loaded: application/views/layout/main.php
DEBUG - 2011-04-30 09:28:40 --> Final output sent to browser
DEBUG - 2011-04-30 09:28:40 --> Total execution time: 0.0813
DEBUG - 2011-04-30 09:28:40 --> Config Class Initialized
DEBUG - 2011-04-30 09:28:40 --> Hooks Class Initialized
DEBUG - 2011-04-30 09:28:40 --> Utf8 Class Initialized
DEBUG - 2011-04-30 09:28:40 --> UTF-8 Support Enabled
DEBUG - 2011-04-30 09:28:40 --> URI Class Initialized
DEBUG - 2011-04-30 09:28:40 --> Router Class Initialized
DEBUG - 2011-04-30 09:28:40 --> Output Class Initialized
DEBUG - 2011-04-30 09:28:40 --> Input Class Initialized
DEBUG - 2011-04-30 09:28:40 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-30 09:28:40 --> Language Class Initialized
DEBUG - 2011-04-30 09:28:40 --> Loader Class Initialized
DEBUG - 2011-04-30 09:28:40 --> Controller Class Initialized
DEBUG - 2011-04-30 09:28:40 --> Model Class Initialized
DEBUG - 2011-04-30 09:28:40 --> Model Class Initialized
DEBUG - 2011-04-30 09:28:40 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-30 09:28:40 --> Database Driver Class Initialized
DEBUG - 2011-04-30 09:28:41 --> Final output sent to browser
DEBUG - 2011-04-30 09:28:41 --> Total execution time: 0.5062
DEBUG - 2011-04-30 09:29:19 --> Config Class Initialized
DEBUG - 2011-04-30 09:29:19 --> Hooks Class Initialized
DEBUG - 2011-04-30 09:29:19 --> Utf8 Class Initialized
DEBUG - 2011-04-30 09:29:19 --> UTF-8 Support Enabled
DEBUG - 2011-04-30 09:29:19 --> URI Class Initialized
DEBUG - 2011-04-30 09:29:19 --> Router Class Initialized
DEBUG - 2011-04-30 09:29:19 --> Output Class Initialized
DEBUG - 2011-04-30 09:29:19 --> Input Class Initialized
DEBUG - 2011-04-30 09:29:19 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-30 09:29:19 --> Language Class Initialized
DEBUG - 2011-04-30 09:29:19 --> Loader Class Initialized
DEBUG - 2011-04-30 09:29:19 --> Controller Class Initialized
ERROR - 2011-04-30 09:29:19 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-04-30 09:29:19 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-04-30 09:29:19 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-04-30 09:29:19 --> Model Class Initialized
DEBUG - 2011-04-30 09:29:19 --> Model Class Initialized
DEBUG - 2011-04-30 09:29:19 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-30 09:29:19 --> Database Driver Class Initialized
DEBUG - 2011-04-30 09:29:19 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-04-30 09:29:19 --> Helper loaded: url_helper
DEBUG - 2011-04-30 09:29:19 --> File loaded: application/views/common/header.php
DEBUG - 2011-04-30 09:29:19 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-04-30 09:29:19 --> File loaded: application/views/common/footer.php
DEBUG - 2011-04-30 09:29:19 --> File loaded: application/views/layout/main.php
DEBUG - 2011-04-30 09:29:19 --> Final output sent to browser
DEBUG - 2011-04-30 09:29:19 --> Total execution time: 0.0726
DEBUG - 2011-04-30 09:29:20 --> Config Class Initialized
DEBUG - 2011-04-30 09:29:20 --> Hooks Class Initialized
DEBUG - 2011-04-30 09:29:20 --> Utf8 Class Initialized
DEBUG - 2011-04-30 09:29:20 --> UTF-8 Support Enabled
DEBUG - 2011-04-30 09:29:20 --> URI Class Initialized
DEBUG - 2011-04-30 09:29:20 --> Router Class Initialized
DEBUG - 2011-04-30 09:29:20 --> Output Class Initialized
DEBUG - 2011-04-30 09:29:20 --> Input Class Initialized
DEBUG - 2011-04-30 09:29:20 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-30 09:29:20 --> Language Class Initialized
DEBUG - 2011-04-30 09:29:20 --> Loader Class Initialized
DEBUG - 2011-04-30 09:29:20 --> Controller Class Initialized
DEBUG - 2011-04-30 09:29:20 --> Model Class Initialized
DEBUG - 2011-04-30 09:29:20 --> Model Class Initialized
DEBUG - 2011-04-30 09:29:20 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-30 09:29:20 --> Database Driver Class Initialized
DEBUG - 2011-04-30 09:29:20 --> Final output sent to browser
DEBUG - 2011-04-30 09:29:20 --> Total execution time: 0.5835
DEBUG - 2011-04-30 09:29:43 --> Config Class Initialized
DEBUG - 2011-04-30 09:29:43 --> Hooks Class Initialized
DEBUG - 2011-04-30 09:29:43 --> Utf8 Class Initialized
DEBUG - 2011-04-30 09:29:43 --> UTF-8 Support Enabled
DEBUG - 2011-04-30 09:29:43 --> URI Class Initialized
DEBUG - 2011-04-30 09:29:43 --> Router Class Initialized
DEBUG - 2011-04-30 09:29:43 --> Output Class Initialized
DEBUG - 2011-04-30 09:29:43 --> Input Class Initialized
DEBUG - 2011-04-30 09:29:43 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-30 09:29:43 --> Language Class Initialized
DEBUG - 2011-04-30 09:29:43 --> Loader Class Initialized
DEBUG - 2011-04-30 09:29:43 --> Controller Class Initialized
ERROR - 2011-04-30 09:29:43 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-04-30 09:29:43 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-04-30 09:29:43 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-04-30 09:29:43 --> Model Class Initialized
DEBUG - 2011-04-30 09:29:43 --> Model Class Initialized
DEBUG - 2011-04-30 09:29:43 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-30 09:29:43 --> Database Driver Class Initialized
DEBUG - 2011-04-30 09:29:43 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-04-30 09:29:43 --> Helper loaded: url_helper
DEBUG - 2011-04-30 09:29:43 --> File loaded: application/views/common/header.php
DEBUG - 2011-04-30 09:29:43 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-04-30 09:29:43 --> File loaded: application/views/common/footer.php
DEBUG - 2011-04-30 09:29:43 --> File loaded: application/views/layout/main.php
DEBUG - 2011-04-30 09:29:43 --> Final output sent to browser
DEBUG - 2011-04-30 09:29:43 --> Total execution time: 0.0290
DEBUG - 2011-04-30 09:29:44 --> Config Class Initialized
DEBUG - 2011-04-30 09:29:44 --> Hooks Class Initialized
DEBUG - 2011-04-30 09:29:44 --> Utf8 Class Initialized
DEBUG - 2011-04-30 09:29:44 --> UTF-8 Support Enabled
DEBUG - 2011-04-30 09:29:44 --> URI Class Initialized
DEBUG - 2011-04-30 09:29:44 --> Router Class Initialized
DEBUG - 2011-04-30 09:29:44 --> Output Class Initialized
DEBUG - 2011-04-30 09:29:44 --> Input Class Initialized
DEBUG - 2011-04-30 09:29:44 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-30 09:29:44 --> Language Class Initialized
DEBUG - 2011-04-30 09:29:44 --> Loader Class Initialized
DEBUG - 2011-04-30 09:29:44 --> Controller Class Initialized
DEBUG - 2011-04-30 09:29:44 --> Model Class Initialized
DEBUG - 2011-04-30 09:29:44 --> Model Class Initialized
DEBUG - 2011-04-30 09:29:44 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-30 09:29:44 --> Database Driver Class Initialized
DEBUG - 2011-04-30 09:29:44 --> Config Class Initialized
DEBUG - 2011-04-30 09:29:44 --> Hooks Class Initialized
DEBUG - 2011-04-30 09:29:44 --> Utf8 Class Initialized
DEBUG - 2011-04-30 09:29:44 --> UTF-8 Support Enabled
DEBUG - 2011-04-30 09:29:44 --> URI Class Initialized
DEBUG - 2011-04-30 09:29:44 --> Router Class Initialized
DEBUG - 2011-04-30 09:29:44 --> Output Class Initialized
DEBUG - 2011-04-30 09:29:44 --> Input Class Initialized
DEBUG - 2011-04-30 09:29:44 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-30 09:29:44 --> Language Class Initialized
DEBUG - 2011-04-30 09:29:44 --> Loader Class Initialized
DEBUG - 2011-04-30 09:29:44 --> Controller Class Initialized
ERROR - 2011-04-30 09:29:44 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-04-30 09:29:44 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-04-30 09:29:44 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-04-30 09:29:44 --> Model Class Initialized
DEBUG - 2011-04-30 09:29:44 --> Model Class Initialized
DEBUG - 2011-04-30 09:29:44 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-30 09:29:44 --> Database Driver Class Initialized
DEBUG - 2011-04-30 09:29:44 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-04-30 09:29:44 --> Helper loaded: url_helper
DEBUG - 2011-04-30 09:29:44 --> File loaded: application/views/common/header.php
DEBUG - 2011-04-30 09:29:44 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-04-30 09:29:44 --> File loaded: application/views/common/footer.php
DEBUG - 2011-04-30 09:29:44 --> File loaded: application/views/layout/main.php
DEBUG - 2011-04-30 09:29:44 --> Final output sent to browser
DEBUG - 2011-04-30 09:29:44 --> Total execution time: 0.0336
DEBUG - 2011-04-30 09:29:44 --> Final output sent to browser
DEBUG - 2011-04-30 09:29:44 --> Total execution time: 0.5411
DEBUG - 2011-04-30 09:30:02 --> Config Class Initialized
DEBUG - 2011-04-30 09:30:02 --> Hooks Class Initialized
DEBUG - 2011-04-30 09:30:02 --> Utf8 Class Initialized
DEBUG - 2011-04-30 09:30:02 --> UTF-8 Support Enabled
DEBUG - 2011-04-30 09:30:02 --> URI Class Initialized
DEBUG - 2011-04-30 09:30:02 --> Router Class Initialized
DEBUG - 2011-04-30 09:30:02 --> Output Class Initialized
DEBUG - 2011-04-30 09:30:02 --> Input Class Initialized
DEBUG - 2011-04-30 09:30:02 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-30 09:30:02 --> Language Class Initialized
DEBUG - 2011-04-30 09:30:02 --> Loader Class Initialized
DEBUG - 2011-04-30 09:30:02 --> Controller Class Initialized
ERROR - 2011-04-30 09:30:02 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-04-30 09:30:02 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-04-30 09:30:02 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-04-30 09:30:02 --> Model Class Initialized
DEBUG - 2011-04-30 09:30:02 --> Model Class Initialized
DEBUG - 2011-04-30 09:30:02 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-30 09:30:02 --> Database Driver Class Initialized
DEBUG - 2011-04-30 09:30:02 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-04-30 09:30:02 --> Helper loaded: url_helper
DEBUG - 2011-04-30 09:30:02 --> File loaded: application/views/common/header.php
DEBUG - 2011-04-30 09:30:02 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-04-30 09:30:02 --> File loaded: application/views/common/footer.php
DEBUG - 2011-04-30 09:30:02 --> File loaded: application/views/layout/main.php
DEBUG - 2011-04-30 09:30:02 --> Final output sent to browser
DEBUG - 2011-04-30 09:30:02 --> Total execution time: 0.1811
DEBUG - 2011-04-30 09:30:03 --> Config Class Initialized
DEBUG - 2011-04-30 09:30:03 --> Hooks Class Initialized
DEBUG - 2011-04-30 09:30:03 --> Utf8 Class Initialized
DEBUG - 2011-04-30 09:30:03 --> UTF-8 Support Enabled
DEBUG - 2011-04-30 09:30:04 --> URI Class Initialized
DEBUG - 2011-04-30 09:30:04 --> Router Class Initialized
DEBUG - 2011-04-30 09:30:04 --> Output Class Initialized
DEBUG - 2011-04-30 09:30:04 --> Input Class Initialized
DEBUG - 2011-04-30 09:30:04 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-30 09:30:04 --> Language Class Initialized
DEBUG - 2011-04-30 09:30:04 --> Loader Class Initialized
DEBUG - 2011-04-30 09:30:04 --> Controller Class Initialized
DEBUG - 2011-04-30 09:30:04 --> Model Class Initialized
DEBUG - 2011-04-30 09:30:04 --> Model Class Initialized
DEBUG - 2011-04-30 09:30:04 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-30 09:30:04 --> Database Driver Class Initialized
DEBUG - 2011-04-30 09:30:04 --> Config Class Initialized
DEBUG - 2011-04-30 09:30:04 --> Hooks Class Initialized
DEBUG - 2011-04-30 09:30:04 --> Utf8 Class Initialized
DEBUG - 2011-04-30 09:30:04 --> UTF-8 Support Enabled
DEBUG - 2011-04-30 09:30:04 --> URI Class Initialized
DEBUG - 2011-04-30 09:30:04 --> Router Class Initialized
DEBUG - 2011-04-30 09:30:04 --> Output Class Initialized
DEBUG - 2011-04-30 09:30:04 --> Input Class Initialized
DEBUG - 2011-04-30 09:30:04 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-30 09:30:04 --> Language Class Initialized
DEBUG - 2011-04-30 09:30:04 --> Loader Class Initialized
DEBUG - 2011-04-30 09:30:04 --> Controller Class Initialized
ERROR - 2011-04-30 09:30:04 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-04-30 09:30:04 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-04-30 09:30:04 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-04-30 09:30:04 --> Model Class Initialized
DEBUG - 2011-04-30 09:30:04 --> Model Class Initialized
DEBUG - 2011-04-30 09:30:04 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-30 09:30:04 --> Database Driver Class Initialized
DEBUG - 2011-04-30 09:30:04 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-04-30 09:30:04 --> Helper loaded: url_helper
DEBUG - 2011-04-30 09:30:04 --> File loaded: application/views/common/header.php
DEBUG - 2011-04-30 09:30:04 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-04-30 09:30:04 --> File loaded: application/views/common/footer.php
DEBUG - 2011-04-30 09:30:04 --> File loaded: application/views/layout/main.php
DEBUG - 2011-04-30 09:30:04 --> Final output sent to browser
DEBUG - 2011-04-30 09:30:04 --> Total execution time: 0.0807
DEBUG - 2011-04-30 09:30:04 --> Final output sent to browser
DEBUG - 2011-04-30 09:30:04 --> Total execution time: 0.9078
DEBUG - 2011-04-30 09:30:33 --> Config Class Initialized
DEBUG - 2011-04-30 09:30:33 --> Hooks Class Initialized
DEBUG - 2011-04-30 09:30:33 --> Utf8 Class Initialized
DEBUG - 2011-04-30 09:30:33 --> UTF-8 Support Enabled
DEBUG - 2011-04-30 09:30:33 --> URI Class Initialized
DEBUG - 2011-04-30 09:30:33 --> Router Class Initialized
DEBUG - 2011-04-30 09:30:33 --> Output Class Initialized
DEBUG - 2011-04-30 09:30:33 --> Input Class Initialized
DEBUG - 2011-04-30 09:30:33 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-30 09:30:33 --> Language Class Initialized
DEBUG - 2011-04-30 09:30:33 --> Loader Class Initialized
DEBUG - 2011-04-30 09:30:33 --> Controller Class Initialized
ERROR - 2011-04-30 09:30:33 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-04-30 09:30:33 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-04-30 09:30:33 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-04-30 09:30:33 --> Model Class Initialized
DEBUG - 2011-04-30 09:30:33 --> Model Class Initialized
DEBUG - 2011-04-30 09:30:33 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-30 09:30:33 --> Database Driver Class Initialized
DEBUG - 2011-04-30 09:30:33 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-04-30 09:30:33 --> Helper loaded: url_helper
DEBUG - 2011-04-30 09:30:33 --> File loaded: application/views/common/header.php
DEBUG - 2011-04-30 09:30:33 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-04-30 09:30:33 --> File loaded: application/views/common/footer.php
DEBUG - 2011-04-30 09:30:33 --> File loaded: application/views/layout/main.php
DEBUG - 2011-04-30 09:30:33 --> Final output sent to browser
DEBUG - 2011-04-30 09:30:33 --> Total execution time: 0.0290
DEBUG - 2011-04-30 09:30:34 --> Config Class Initialized
DEBUG - 2011-04-30 09:30:34 --> Hooks Class Initialized
DEBUG - 2011-04-30 09:30:34 --> Utf8 Class Initialized
DEBUG - 2011-04-30 09:30:34 --> UTF-8 Support Enabled
DEBUG - 2011-04-30 09:30:34 --> URI Class Initialized
DEBUG - 2011-04-30 09:30:34 --> Router Class Initialized
DEBUG - 2011-04-30 09:30:34 --> Output Class Initialized
DEBUG - 2011-04-30 09:30:34 --> Input Class Initialized
DEBUG - 2011-04-30 09:30:34 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-30 09:30:34 --> Language Class Initialized
DEBUG - 2011-04-30 09:30:34 --> Loader Class Initialized
DEBUG - 2011-04-30 09:30:34 --> Controller Class Initialized
DEBUG - 2011-04-30 09:30:34 --> Model Class Initialized
DEBUG - 2011-04-30 09:30:34 --> Model Class Initialized
DEBUG - 2011-04-30 09:30:34 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-30 09:30:34 --> Database Driver Class Initialized
DEBUG - 2011-04-30 09:30:34 --> Config Class Initialized
DEBUG - 2011-04-30 09:30:34 --> Hooks Class Initialized
DEBUG - 2011-04-30 09:30:34 --> Utf8 Class Initialized
DEBUG - 2011-04-30 09:30:34 --> UTF-8 Support Enabled
DEBUG - 2011-04-30 09:30:34 --> URI Class Initialized
DEBUG - 2011-04-30 09:30:34 --> Router Class Initialized
DEBUG - 2011-04-30 09:30:34 --> Output Class Initialized
DEBUG - 2011-04-30 09:30:34 --> Input Class Initialized
DEBUG - 2011-04-30 09:30:34 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-30 09:30:34 --> Language Class Initialized
DEBUG - 2011-04-30 09:30:34 --> Loader Class Initialized
DEBUG - 2011-04-30 09:30:34 --> Controller Class Initialized
ERROR - 2011-04-30 09:30:34 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-04-30 09:30:34 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-04-30 09:30:34 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-04-30 09:30:34 --> Model Class Initialized
DEBUG - 2011-04-30 09:30:34 --> Model Class Initialized
DEBUG - 2011-04-30 09:30:34 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-30 09:30:34 --> Database Driver Class Initialized
DEBUG - 2011-04-30 09:30:34 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-04-30 09:30:34 --> Helper loaded: url_helper
DEBUG - 2011-04-30 09:30:34 --> File loaded: application/views/common/header.php
DEBUG - 2011-04-30 09:30:34 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-04-30 09:30:34 --> File loaded: application/views/common/footer.php
DEBUG - 2011-04-30 09:30:34 --> File loaded: application/views/layout/main.php
DEBUG - 2011-04-30 09:30:34 --> Final output sent to browser
DEBUG - 2011-04-30 09:30:34 --> Total execution time: 0.0296
DEBUG - 2011-04-30 09:30:34 --> Final output sent to browser
DEBUG - 2011-04-30 09:30:34 --> Total execution time: 0.5964
DEBUG - 2011-04-30 09:31:17 --> Config Class Initialized
DEBUG - 2011-04-30 09:31:17 --> Hooks Class Initialized
DEBUG - 2011-04-30 09:31:17 --> Utf8 Class Initialized
DEBUG - 2011-04-30 09:31:17 --> UTF-8 Support Enabled
DEBUG - 2011-04-30 09:31:17 --> URI Class Initialized
DEBUG - 2011-04-30 09:31:17 --> Router Class Initialized
DEBUG - 2011-04-30 09:31:17 --> Output Class Initialized
DEBUG - 2011-04-30 09:31:17 --> Input Class Initialized
DEBUG - 2011-04-30 09:31:17 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-30 09:31:17 --> Language Class Initialized
DEBUG - 2011-04-30 09:31:17 --> Loader Class Initialized
DEBUG - 2011-04-30 09:31:17 --> Controller Class Initialized
ERROR - 2011-04-30 09:31:17 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-04-30 09:31:17 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-04-30 09:31:17 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-04-30 09:31:17 --> Model Class Initialized
DEBUG - 2011-04-30 09:31:17 --> Model Class Initialized
DEBUG - 2011-04-30 09:31:17 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-30 09:31:17 --> Database Driver Class Initialized
DEBUG - 2011-04-30 09:31:17 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-04-30 09:31:17 --> Helper loaded: url_helper
DEBUG - 2011-04-30 09:31:17 --> File loaded: application/views/common/header.php
DEBUG - 2011-04-30 09:31:17 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-04-30 09:31:17 --> File loaded: application/views/common/footer.php
DEBUG - 2011-04-30 09:31:17 --> File loaded: application/views/layout/main.php
DEBUG - 2011-04-30 09:31:17 --> Final output sent to browser
DEBUG - 2011-04-30 09:31:17 --> Total execution time: 0.0322
DEBUG - 2011-04-30 09:31:17 --> Config Class Initialized
DEBUG - 2011-04-30 09:31:17 --> Hooks Class Initialized
DEBUG - 2011-04-30 09:31:17 --> Utf8 Class Initialized
DEBUG - 2011-04-30 09:31:17 --> UTF-8 Support Enabled
DEBUG - 2011-04-30 09:31:17 --> URI Class Initialized
DEBUG - 2011-04-30 09:31:17 --> Router Class Initialized
DEBUG - 2011-04-30 09:31:17 --> Output Class Initialized
DEBUG - 2011-04-30 09:31:17 --> Input Class Initialized
DEBUG - 2011-04-30 09:31:17 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-30 09:31:17 --> Language Class Initialized
DEBUG - 2011-04-30 09:31:17 --> Loader Class Initialized
DEBUG - 2011-04-30 09:31:17 --> Controller Class Initialized
DEBUG - 2011-04-30 09:31:17 --> Model Class Initialized
DEBUG - 2011-04-30 09:31:17 --> Model Class Initialized
DEBUG - 2011-04-30 09:31:17 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-30 09:31:17 --> Database Driver Class Initialized
DEBUG - 2011-04-30 09:31:18 --> Config Class Initialized
DEBUG - 2011-04-30 09:31:18 --> Hooks Class Initialized
DEBUG - 2011-04-30 09:31:18 --> Utf8 Class Initialized
DEBUG - 2011-04-30 09:31:18 --> UTF-8 Support Enabled
DEBUG - 2011-04-30 09:31:18 --> URI Class Initialized
DEBUG - 2011-04-30 09:31:18 --> Router Class Initialized
DEBUG - 2011-04-30 09:31:18 --> Output Class Initialized
DEBUG - 2011-04-30 09:31:18 --> Input Class Initialized
DEBUG - 2011-04-30 09:31:18 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-30 09:31:18 --> Language Class Initialized
DEBUG - 2011-04-30 09:31:18 --> Loader Class Initialized
DEBUG - 2011-04-30 09:31:18 --> Controller Class Initialized
ERROR - 2011-04-30 09:31:18 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-04-30 09:31:18 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-04-30 09:31:18 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-04-30 09:31:18 --> Model Class Initialized
DEBUG - 2011-04-30 09:31:18 --> Model Class Initialized
DEBUG - 2011-04-30 09:31:18 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-30 09:31:18 --> Database Driver Class Initialized
DEBUG - 2011-04-30 09:31:18 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-04-30 09:31:18 --> Helper loaded: url_helper
DEBUG - 2011-04-30 09:31:18 --> File loaded: application/views/common/header.php
DEBUG - 2011-04-30 09:31:18 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-04-30 09:31:18 --> File loaded: application/views/common/footer.php
DEBUG - 2011-04-30 09:31:18 --> File loaded: application/views/layout/main.php
DEBUG - 2011-04-30 09:31:18 --> Final output sent to browser
DEBUG - 2011-04-30 09:31:18 --> Total execution time: 0.0405
DEBUG - 2011-04-30 09:31:18 --> Final output sent to browser
DEBUG - 2011-04-30 09:31:18 --> Total execution time: 0.7237
DEBUG - 2011-04-30 09:32:46 --> Config Class Initialized
DEBUG - 2011-04-30 09:32:46 --> Hooks Class Initialized
DEBUG - 2011-04-30 09:32:46 --> Utf8 Class Initialized
DEBUG - 2011-04-30 09:32:46 --> UTF-8 Support Enabled
DEBUG - 2011-04-30 09:32:46 --> URI Class Initialized
DEBUG - 2011-04-30 09:32:46 --> Router Class Initialized
DEBUG - 2011-04-30 09:32:46 --> Output Class Initialized
DEBUG - 2011-04-30 09:32:46 --> Input Class Initialized
DEBUG - 2011-04-30 09:32:46 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-30 09:32:46 --> Language Class Initialized
DEBUG - 2011-04-30 09:32:46 --> Loader Class Initialized
DEBUG - 2011-04-30 09:32:46 --> Controller Class Initialized
ERROR - 2011-04-30 09:32:47 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-04-30 09:32:47 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-04-30 09:32:47 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-04-30 09:32:47 --> Model Class Initialized
DEBUG - 2011-04-30 09:32:47 --> Model Class Initialized
DEBUG - 2011-04-30 09:32:47 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-30 09:32:47 --> Database Driver Class Initialized
DEBUG - 2011-04-30 09:32:47 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-04-30 09:32:47 --> Helper loaded: url_helper
DEBUG - 2011-04-30 09:32:47 --> File loaded: application/views/common/header.php
DEBUG - 2011-04-30 09:32:47 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-04-30 09:32:47 --> File loaded: application/views/common/footer.php
DEBUG - 2011-04-30 09:32:47 --> File loaded: application/views/layout/main.php
DEBUG - 2011-04-30 09:32:47 --> Final output sent to browser
DEBUG - 2011-04-30 09:32:47 --> Total execution time: 0.0884
DEBUG - 2011-04-30 09:32:47 --> Config Class Initialized
DEBUG - 2011-04-30 09:32:47 --> Hooks Class Initialized
DEBUG - 2011-04-30 09:32:47 --> Utf8 Class Initialized
DEBUG - 2011-04-30 09:32:47 --> UTF-8 Support Enabled
DEBUG - 2011-04-30 09:32:47 --> URI Class Initialized
DEBUG - 2011-04-30 09:32:47 --> Router Class Initialized
DEBUG - 2011-04-30 09:32:47 --> Output Class Initialized
DEBUG - 2011-04-30 09:32:47 --> Input Class Initialized
DEBUG - 2011-04-30 09:32:47 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-30 09:32:47 --> Language Class Initialized
DEBUG - 2011-04-30 09:32:47 --> Loader Class Initialized
DEBUG - 2011-04-30 09:32:47 --> Controller Class Initialized
DEBUG - 2011-04-30 09:32:47 --> Model Class Initialized
DEBUG - 2011-04-30 09:32:47 --> Model Class Initialized
DEBUG - 2011-04-30 09:32:47 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-30 09:32:47 --> Database Driver Class Initialized
DEBUG - 2011-04-30 09:32:48 --> Final output sent to browser
DEBUG - 2011-04-30 09:32:48 --> Total execution time: 0.7409
DEBUG - 2011-04-30 09:32:49 --> Config Class Initialized
DEBUG - 2011-04-30 09:32:49 --> Hooks Class Initialized
DEBUG - 2011-04-30 09:32:49 --> Utf8 Class Initialized
DEBUG - 2011-04-30 09:32:49 --> UTF-8 Support Enabled
DEBUG - 2011-04-30 09:32:49 --> URI Class Initialized
DEBUG - 2011-04-30 09:32:49 --> Router Class Initialized
DEBUG - 2011-04-30 09:32:49 --> Output Class Initialized
DEBUG - 2011-04-30 09:32:49 --> Input Class Initialized
DEBUG - 2011-04-30 09:32:49 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-30 09:32:49 --> Language Class Initialized
DEBUG - 2011-04-30 09:32:49 --> Loader Class Initialized
DEBUG - 2011-04-30 09:32:49 --> Controller Class Initialized
ERROR - 2011-04-30 09:32:49 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-04-30 09:32:49 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-04-30 09:32:49 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-04-30 09:32:49 --> Model Class Initialized
DEBUG - 2011-04-30 09:32:49 --> Model Class Initialized
DEBUG - 2011-04-30 09:32:49 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-30 09:32:49 --> Database Driver Class Initialized
DEBUG - 2011-04-30 09:32:49 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-04-30 09:32:49 --> Helper loaded: url_helper
DEBUG - 2011-04-30 09:32:49 --> File loaded: application/views/common/header.php
DEBUG - 2011-04-30 09:32:49 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-04-30 09:32:49 --> File loaded: application/views/common/footer.php
DEBUG - 2011-04-30 09:32:49 --> File loaded: application/views/layout/main.php
DEBUG - 2011-04-30 09:32:49 --> Final output sent to browser
DEBUG - 2011-04-30 09:32:49 --> Total execution time: 0.0298
DEBUG - 2011-04-30 09:32:59 --> Config Class Initialized
DEBUG - 2011-04-30 09:32:59 --> Hooks Class Initialized
DEBUG - 2011-04-30 09:32:59 --> Utf8 Class Initialized
DEBUG - 2011-04-30 09:32:59 --> UTF-8 Support Enabled
DEBUG - 2011-04-30 09:32:59 --> URI Class Initialized
DEBUG - 2011-04-30 09:32:59 --> Router Class Initialized
DEBUG - 2011-04-30 09:32:59 --> Output Class Initialized
DEBUG - 2011-04-30 09:32:59 --> Input Class Initialized
DEBUG - 2011-04-30 09:32:59 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-30 09:32:59 --> Language Class Initialized
DEBUG - 2011-04-30 09:32:59 --> Loader Class Initialized
DEBUG - 2011-04-30 09:32:59 --> Controller Class Initialized
ERROR - 2011-04-30 09:32:59 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-04-30 09:32:59 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-04-30 09:32:59 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-04-30 09:32:59 --> Model Class Initialized
DEBUG - 2011-04-30 09:32:59 --> Model Class Initialized
DEBUG - 2011-04-30 09:32:59 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-30 09:32:59 --> Database Driver Class Initialized
DEBUG - 2011-04-30 09:32:59 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-04-30 09:32:59 --> Helper loaded: url_helper
DEBUG - 2011-04-30 09:32:59 --> File loaded: application/views/common/header.php
DEBUG - 2011-04-30 09:32:59 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-04-30 09:32:59 --> File loaded: application/views/common/footer.php
DEBUG - 2011-04-30 09:32:59 --> File loaded: application/views/layout/main.php
DEBUG - 2011-04-30 09:32:59 --> Final output sent to browser
DEBUG - 2011-04-30 09:32:59 --> Total execution time: 0.0337
DEBUG - 2011-04-30 09:33:00 --> Config Class Initialized
DEBUG - 2011-04-30 09:33:00 --> Hooks Class Initialized
DEBUG - 2011-04-30 09:33:00 --> Utf8 Class Initialized
DEBUG - 2011-04-30 09:33:00 --> UTF-8 Support Enabled
DEBUG - 2011-04-30 09:33:00 --> URI Class Initialized
DEBUG - 2011-04-30 09:33:00 --> Router Class Initialized
DEBUG - 2011-04-30 09:33:00 --> Output Class Initialized
DEBUG - 2011-04-30 09:33:00 --> Input Class Initialized
DEBUG - 2011-04-30 09:33:00 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-30 09:33:00 --> Language Class Initialized
DEBUG - 2011-04-30 09:33:00 --> Loader Class Initialized
DEBUG - 2011-04-30 09:33:00 --> Controller Class Initialized
DEBUG - 2011-04-30 09:33:00 --> Model Class Initialized
DEBUG - 2011-04-30 09:33:00 --> Model Class Initialized
DEBUG - 2011-04-30 09:33:00 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-30 09:33:00 --> Database Driver Class Initialized
DEBUG - 2011-04-30 09:33:00 --> Config Class Initialized
DEBUG - 2011-04-30 09:33:00 --> Hooks Class Initialized
DEBUG - 2011-04-30 09:33:00 --> Utf8 Class Initialized
DEBUG - 2011-04-30 09:33:00 --> UTF-8 Support Enabled
DEBUG - 2011-04-30 09:33:00 --> URI Class Initialized
DEBUG - 2011-04-30 09:33:00 --> Router Class Initialized
DEBUG - 2011-04-30 09:33:00 --> Output Class Initialized
DEBUG - 2011-04-30 09:33:00 --> Input Class Initialized
DEBUG - 2011-04-30 09:33:00 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-30 09:33:00 --> Language Class Initialized
DEBUG - 2011-04-30 09:33:00 --> Loader Class Initialized
DEBUG - 2011-04-30 09:33:00 --> Controller Class Initialized
ERROR - 2011-04-30 09:33:00 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-04-30 09:33:00 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-04-30 09:33:00 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-04-30 09:33:00 --> Model Class Initialized
DEBUG - 2011-04-30 09:33:00 --> Model Class Initialized
DEBUG - 2011-04-30 09:33:00 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-30 09:33:01 --> Database Driver Class Initialized
DEBUG - 2011-04-30 09:33:01 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-04-30 09:33:01 --> Helper loaded: url_helper
DEBUG - 2011-04-30 09:33:01 --> File loaded: application/views/common/header.php
DEBUG - 2011-04-30 09:33:01 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-04-30 09:33:01 --> File loaded: application/views/common/footer.php
DEBUG - 2011-04-30 09:33:01 --> File loaded: application/views/layout/main.php
DEBUG - 2011-04-30 09:33:01 --> Final output sent to browser
DEBUG - 2011-04-30 09:33:01 --> Total execution time: 0.0647
DEBUG - 2011-04-30 09:33:01 --> Final output sent to browser
DEBUG - 2011-04-30 09:33:01 --> Total execution time: 0.6087
DEBUG - 2011-04-30 09:34:00 --> Config Class Initialized
DEBUG - 2011-04-30 09:34:00 --> Hooks Class Initialized
DEBUG - 2011-04-30 09:34:00 --> Utf8 Class Initialized
DEBUG - 2011-04-30 09:34:00 --> UTF-8 Support Enabled
DEBUG - 2011-04-30 09:34:00 --> URI Class Initialized
DEBUG - 2011-04-30 09:34:00 --> Router Class Initialized
DEBUG - 2011-04-30 09:34:00 --> Output Class Initialized
DEBUG - 2011-04-30 09:34:00 --> Input Class Initialized
DEBUG - 2011-04-30 09:34:00 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-30 09:34:00 --> Language Class Initialized
DEBUG - 2011-04-30 09:34:00 --> Loader Class Initialized
DEBUG - 2011-04-30 09:34:00 --> Controller Class Initialized
ERROR - 2011-04-30 09:34:00 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-04-30 09:34:00 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-04-30 09:34:00 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-04-30 09:34:00 --> Model Class Initialized
DEBUG - 2011-04-30 09:34:00 --> Model Class Initialized
DEBUG - 2011-04-30 09:34:00 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-30 09:34:00 --> Database Driver Class Initialized
DEBUG - 2011-04-30 09:34:00 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-04-30 09:34:00 --> Helper loaded: url_helper
DEBUG - 2011-04-30 09:34:00 --> File loaded: application/views/common/header.php
DEBUG - 2011-04-30 09:34:00 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-04-30 09:34:00 --> File loaded: application/views/common/footer.php
DEBUG - 2011-04-30 09:34:00 --> File loaded: application/views/layout/main.php
DEBUG - 2011-04-30 09:34:00 --> Final output sent to browser
DEBUG - 2011-04-30 09:34:00 --> Total execution time: 0.0451
DEBUG - 2011-04-30 09:34:00 --> Config Class Initialized
DEBUG - 2011-04-30 09:34:00 --> Hooks Class Initialized
DEBUG - 2011-04-30 09:34:00 --> Utf8 Class Initialized
DEBUG - 2011-04-30 09:34:00 --> UTF-8 Support Enabled
DEBUG - 2011-04-30 09:34:00 --> URI Class Initialized
DEBUG - 2011-04-30 09:34:00 --> Router Class Initialized
DEBUG - 2011-04-30 09:34:00 --> Output Class Initialized
DEBUG - 2011-04-30 09:34:00 --> Input Class Initialized
DEBUG - 2011-04-30 09:34:00 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-30 09:34:00 --> Language Class Initialized
DEBUG - 2011-04-30 09:34:01 --> Loader Class Initialized
DEBUG - 2011-04-30 09:34:01 --> Controller Class Initialized
DEBUG - 2011-04-30 09:34:01 --> Model Class Initialized
DEBUG - 2011-04-30 09:34:01 --> Model Class Initialized
DEBUG - 2011-04-30 09:34:01 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-30 09:34:01 --> Database Driver Class Initialized
DEBUG - 2011-04-30 09:34:01 --> Final output sent to browser
DEBUG - 2011-04-30 09:34:01 --> Total execution time: 0.8360
DEBUG - 2011-04-30 09:34:55 --> Config Class Initialized
DEBUG - 2011-04-30 09:34:55 --> Hooks Class Initialized
DEBUG - 2011-04-30 09:34:55 --> Utf8 Class Initialized
DEBUG - 2011-04-30 09:34:55 --> UTF-8 Support Enabled
DEBUG - 2011-04-30 09:34:55 --> URI Class Initialized
DEBUG - 2011-04-30 09:34:55 --> Router Class Initialized
DEBUG - 2011-04-30 09:34:55 --> Output Class Initialized
DEBUG - 2011-04-30 09:34:55 --> Input Class Initialized
DEBUG - 2011-04-30 09:34:55 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-30 09:34:55 --> Language Class Initialized
DEBUG - 2011-04-30 09:34:55 --> Loader Class Initialized
DEBUG - 2011-04-30 09:34:55 --> Controller Class Initialized
ERROR - 2011-04-30 09:34:55 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-04-30 09:34:55 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-04-30 09:34:55 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-04-30 09:34:55 --> Model Class Initialized
DEBUG - 2011-04-30 09:34:55 --> Model Class Initialized
DEBUG - 2011-04-30 09:34:55 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-30 09:34:55 --> Database Driver Class Initialized
DEBUG - 2011-04-30 09:34:55 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-04-30 09:34:55 --> Helper loaded: url_helper
DEBUG - 2011-04-30 09:34:55 --> File loaded: application/views/common/header.php
DEBUG - 2011-04-30 09:34:55 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-04-30 09:34:55 --> File loaded: application/views/common/footer.php
DEBUG - 2011-04-30 09:34:55 --> File loaded: application/views/layout/main.php
DEBUG - 2011-04-30 09:34:55 --> Final output sent to browser
DEBUG - 2011-04-30 09:34:55 --> Total execution time: 0.0328
DEBUG - 2011-04-30 09:34:55 --> Config Class Initialized
DEBUG - 2011-04-30 09:34:55 --> Hooks Class Initialized
DEBUG - 2011-04-30 09:34:55 --> Utf8 Class Initialized
DEBUG - 2011-04-30 09:34:55 --> UTF-8 Support Enabled
DEBUG - 2011-04-30 09:34:55 --> URI Class Initialized
DEBUG - 2011-04-30 09:34:55 --> Router Class Initialized
DEBUG - 2011-04-30 09:34:55 --> Output Class Initialized
DEBUG - 2011-04-30 09:34:55 --> Input Class Initialized
DEBUG - 2011-04-30 09:34:55 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-30 09:34:55 --> Language Class Initialized
DEBUG - 2011-04-30 09:34:55 --> Loader Class Initialized
DEBUG - 2011-04-30 09:34:55 --> Controller Class Initialized
DEBUG - 2011-04-30 09:34:55 --> Model Class Initialized
DEBUG - 2011-04-30 09:34:55 --> Model Class Initialized
DEBUG - 2011-04-30 09:34:55 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-30 09:34:55 --> Database Driver Class Initialized
DEBUG - 2011-04-30 09:34:56 --> Config Class Initialized
DEBUG - 2011-04-30 09:34:56 --> Hooks Class Initialized
DEBUG - 2011-04-30 09:34:56 --> Utf8 Class Initialized
DEBUG - 2011-04-30 09:34:56 --> UTF-8 Support Enabled
DEBUG - 2011-04-30 09:34:56 --> URI Class Initialized
DEBUG - 2011-04-30 09:34:56 --> Router Class Initialized
DEBUG - 2011-04-30 09:34:56 --> Final output sent to browser
DEBUG - 2011-04-30 09:34:56 --> Total execution time: 0.6459
DEBUG - 2011-04-30 09:34:56 --> Output Class Initialized
DEBUG - 2011-04-30 09:34:56 --> Input Class Initialized
DEBUG - 2011-04-30 09:34:56 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-30 09:34:56 --> Language Class Initialized
DEBUG - 2011-04-30 09:34:56 --> Loader Class Initialized
DEBUG - 2011-04-30 09:34:56 --> Controller Class Initialized
ERROR - 2011-04-30 09:34:56 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-04-30 09:34:56 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-04-30 09:34:56 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-04-30 09:34:56 --> Model Class Initialized
DEBUG - 2011-04-30 09:34:56 --> Model Class Initialized
DEBUG - 2011-04-30 09:34:56 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-30 09:34:56 --> Database Driver Class Initialized
DEBUG - 2011-04-30 09:34:56 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-04-30 09:34:56 --> Helper loaded: url_helper
DEBUG - 2011-04-30 09:34:56 --> File loaded: application/views/common/header.php
DEBUG - 2011-04-30 09:34:56 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-04-30 09:34:56 --> File loaded: application/views/common/footer.php
DEBUG - 2011-04-30 09:34:56 --> File loaded: application/views/layout/main.php
DEBUG - 2011-04-30 09:34:56 --> Final output sent to browser
DEBUG - 2011-04-30 09:34:56 --> Total execution time: 0.0339
DEBUG - 2011-04-30 09:35:41 --> Config Class Initialized
DEBUG - 2011-04-30 09:35:41 --> Hooks Class Initialized
DEBUG - 2011-04-30 09:35:41 --> Utf8 Class Initialized
DEBUG - 2011-04-30 09:35:41 --> UTF-8 Support Enabled
DEBUG - 2011-04-30 09:35:41 --> URI Class Initialized
DEBUG - 2011-04-30 09:35:41 --> Router Class Initialized
DEBUG - 2011-04-30 09:35:41 --> Output Class Initialized
DEBUG - 2011-04-30 09:35:41 --> Input Class Initialized
DEBUG - 2011-04-30 09:35:41 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-30 09:35:41 --> Language Class Initialized
DEBUG - 2011-04-30 09:35:41 --> Loader Class Initialized
DEBUG - 2011-04-30 09:35:41 --> Controller Class Initialized
ERROR - 2011-04-30 09:35:41 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-04-30 09:35:41 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-04-30 09:35:41 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-04-30 09:35:41 --> Model Class Initialized
DEBUG - 2011-04-30 09:35:41 --> Model Class Initialized
DEBUG - 2011-04-30 09:35:41 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-30 09:35:41 --> Database Driver Class Initialized
DEBUG - 2011-04-30 09:35:41 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-04-30 09:35:41 --> Helper loaded: url_helper
DEBUG - 2011-04-30 09:35:41 --> File loaded: application/views/common/header.php
DEBUG - 2011-04-30 09:35:41 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-04-30 09:35:41 --> File loaded: application/views/common/footer.php
DEBUG - 2011-04-30 09:35:41 --> File loaded: application/views/layout/main.php
DEBUG - 2011-04-30 09:35:41 --> Final output sent to browser
DEBUG - 2011-04-30 09:35:41 --> Total execution time: 0.0359
DEBUG - 2011-04-30 09:35:42 --> Config Class Initialized
DEBUG - 2011-04-30 09:35:42 --> Hooks Class Initialized
DEBUG - 2011-04-30 09:35:42 --> Utf8 Class Initialized
DEBUG - 2011-04-30 09:35:42 --> UTF-8 Support Enabled
DEBUG - 2011-04-30 09:35:42 --> URI Class Initialized
DEBUG - 2011-04-30 09:35:42 --> Router Class Initialized
DEBUG - 2011-04-30 09:35:42 --> Output Class Initialized
DEBUG - 2011-04-30 09:35:42 --> Input Class Initialized
DEBUG - 2011-04-30 09:35:42 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-30 09:35:42 --> Language Class Initialized
DEBUG - 2011-04-30 09:35:42 --> Loader Class Initialized
DEBUG - 2011-04-30 09:35:42 --> Controller Class Initialized
DEBUG - 2011-04-30 09:35:42 --> Model Class Initialized
DEBUG - 2011-04-30 09:35:42 --> Model Class Initialized
DEBUG - 2011-04-30 09:35:42 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-30 09:35:42 --> Database Driver Class Initialized
DEBUG - 2011-04-30 09:35:42 --> Final output sent to browser
DEBUG - 2011-04-30 09:35:42 --> Total execution time: 0.4844
DEBUG - 2011-04-30 09:35:42 --> Config Class Initialized
DEBUG - 2011-04-30 09:35:42 --> Hooks Class Initialized
DEBUG - 2011-04-30 09:35:42 --> Utf8 Class Initialized
DEBUG - 2011-04-30 09:35:42 --> UTF-8 Support Enabled
DEBUG - 2011-04-30 09:35:42 --> URI Class Initialized
DEBUG - 2011-04-30 09:35:42 --> Router Class Initialized
DEBUG - 2011-04-30 09:35:42 --> Output Class Initialized
DEBUG - 2011-04-30 09:35:42 --> Input Class Initialized
DEBUG - 2011-04-30 09:35:42 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-30 09:35:42 --> Language Class Initialized
DEBUG - 2011-04-30 09:35:42 --> Loader Class Initialized
DEBUG - 2011-04-30 09:35:42 --> Controller Class Initialized
ERROR - 2011-04-30 09:35:42 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-04-30 09:35:42 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-04-30 09:35:42 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-04-30 09:35:42 --> Model Class Initialized
DEBUG - 2011-04-30 09:35:42 --> Model Class Initialized
DEBUG - 2011-04-30 09:35:42 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-30 09:35:42 --> Database Driver Class Initialized
DEBUG - 2011-04-30 09:35:42 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-04-30 09:35:42 --> Helper loaded: url_helper
DEBUG - 2011-04-30 09:35:42 --> File loaded: application/views/common/header.php
DEBUG - 2011-04-30 09:35:42 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-04-30 09:35:42 --> File loaded: application/views/common/footer.php
DEBUG - 2011-04-30 09:35:42 --> File loaded: application/views/layout/main.php
DEBUG - 2011-04-30 09:35:42 --> Final output sent to browser
DEBUG - 2011-04-30 09:35:42 --> Total execution time: 0.0427
DEBUG - 2011-04-30 09:35:59 --> Config Class Initialized
DEBUG - 2011-04-30 09:35:59 --> Hooks Class Initialized
DEBUG - 2011-04-30 09:35:59 --> Utf8 Class Initialized
DEBUG - 2011-04-30 09:35:59 --> UTF-8 Support Enabled
DEBUG - 2011-04-30 09:35:59 --> URI Class Initialized
DEBUG - 2011-04-30 09:35:59 --> Router Class Initialized
DEBUG - 2011-04-30 09:35:59 --> Output Class Initialized
DEBUG - 2011-04-30 09:35:59 --> Input Class Initialized
DEBUG - 2011-04-30 09:35:59 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-30 09:35:59 --> Language Class Initialized
DEBUG - 2011-04-30 09:35:59 --> Loader Class Initialized
DEBUG - 2011-04-30 09:35:59 --> Controller Class Initialized
ERROR - 2011-04-30 09:35:59 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-04-30 09:35:59 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-04-30 09:35:59 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-04-30 09:35:59 --> Model Class Initialized
DEBUG - 2011-04-30 09:35:59 --> Model Class Initialized
DEBUG - 2011-04-30 09:35:59 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-30 09:35:59 --> Database Driver Class Initialized
DEBUG - 2011-04-30 09:35:59 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-04-30 09:35:59 --> Helper loaded: url_helper
DEBUG - 2011-04-30 09:35:59 --> File loaded: application/views/common/header.php
DEBUG - 2011-04-30 09:35:59 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-04-30 09:35:59 --> File loaded: application/views/common/footer.php
DEBUG - 2011-04-30 09:35:59 --> File loaded: application/views/layout/main.php
DEBUG - 2011-04-30 09:35:59 --> Final output sent to browser
DEBUG - 2011-04-30 09:35:59 --> Total execution time: 0.1444
DEBUG - 2011-04-30 09:36:00 --> Config Class Initialized
DEBUG - 2011-04-30 09:36:00 --> Hooks Class Initialized
DEBUG - 2011-04-30 09:36:00 --> Utf8 Class Initialized
DEBUG - 2011-04-30 09:36:00 --> UTF-8 Support Enabled
DEBUG - 2011-04-30 09:36:00 --> URI Class Initialized
DEBUG - 2011-04-30 09:36:00 --> Router Class Initialized
DEBUG - 2011-04-30 09:36:00 --> Output Class Initialized
DEBUG - 2011-04-30 09:36:00 --> Input Class Initialized
DEBUG - 2011-04-30 09:36:00 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-30 09:36:00 --> Language Class Initialized
DEBUG - 2011-04-30 09:36:00 --> Loader Class Initialized
DEBUG - 2011-04-30 09:36:00 --> Controller Class Initialized
DEBUG - 2011-04-30 09:36:00 --> Model Class Initialized
DEBUG - 2011-04-30 09:36:00 --> Model Class Initialized
DEBUG - 2011-04-30 09:36:00 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-30 09:36:00 --> Database Driver Class Initialized
DEBUG - 2011-04-30 09:36:01 --> Config Class Initialized
DEBUG - 2011-04-30 09:36:01 --> Hooks Class Initialized
DEBUG - 2011-04-30 09:36:01 --> Utf8 Class Initialized
DEBUG - 2011-04-30 09:36:01 --> UTF-8 Support Enabled
DEBUG - 2011-04-30 09:36:01 --> URI Class Initialized
DEBUG - 2011-04-30 09:36:01 --> Router Class Initialized
DEBUG - 2011-04-30 09:36:01 --> Output Class Initialized
DEBUG - 2011-04-30 09:36:01 --> Input Class Initialized
DEBUG - 2011-04-30 09:36:01 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-30 09:36:01 --> Language Class Initialized
DEBUG - 2011-04-30 09:36:01 --> Loader Class Initialized
DEBUG - 2011-04-30 09:36:01 --> Controller Class Initialized
ERROR - 2011-04-30 09:36:01 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-04-30 09:36:01 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-04-30 09:36:01 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-04-30 09:36:01 --> Model Class Initialized
DEBUG - 2011-04-30 09:36:01 --> Model Class Initialized
DEBUG - 2011-04-30 09:36:01 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-30 09:36:01 --> Database Driver Class Initialized
DEBUG - 2011-04-30 09:36:01 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-04-30 09:36:01 --> Helper loaded: url_helper
DEBUG - 2011-04-30 09:36:01 --> File loaded: application/views/common/header.php
DEBUG - 2011-04-30 09:36:01 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-04-30 09:36:01 --> File loaded: application/views/common/footer.php
DEBUG - 2011-04-30 09:36:01 --> File loaded: application/views/layout/main.php
DEBUG - 2011-04-30 09:36:01 --> Final output sent to browser
DEBUG - 2011-04-30 09:36:01 --> Total execution time: 0.0764
DEBUG - 2011-04-30 09:36:01 --> Final output sent to browser
DEBUG - 2011-04-30 09:36:01 --> Total execution time: 0.7244
DEBUG - 2011-04-30 09:36:22 --> Config Class Initialized
DEBUG - 2011-04-30 09:36:22 --> Hooks Class Initialized
DEBUG - 2011-04-30 09:36:22 --> Utf8 Class Initialized
DEBUG - 2011-04-30 09:36:22 --> UTF-8 Support Enabled
DEBUG - 2011-04-30 09:36:22 --> URI Class Initialized
DEBUG - 2011-04-30 09:36:22 --> Router Class Initialized
DEBUG - 2011-04-30 09:36:22 --> Output Class Initialized
DEBUG - 2011-04-30 09:36:22 --> Input Class Initialized
DEBUG - 2011-04-30 09:36:22 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-30 09:36:22 --> Language Class Initialized
DEBUG - 2011-04-30 09:36:22 --> Loader Class Initialized
DEBUG - 2011-04-30 09:36:22 --> Controller Class Initialized
ERROR - 2011-04-30 09:36:22 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-04-30 09:36:22 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-04-30 09:36:22 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-04-30 09:36:22 --> Model Class Initialized
DEBUG - 2011-04-30 09:36:22 --> Model Class Initialized
DEBUG - 2011-04-30 09:36:22 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-30 09:36:22 --> Database Driver Class Initialized
DEBUG - 2011-04-30 09:36:22 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-04-30 09:36:22 --> Helper loaded: url_helper
DEBUG - 2011-04-30 09:36:22 --> File loaded: application/views/common/header.php
DEBUG - 2011-04-30 09:36:22 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-04-30 09:36:22 --> File loaded: application/views/common/footer.php
DEBUG - 2011-04-30 09:36:22 --> File loaded: application/views/layout/main.php
DEBUG - 2011-04-30 09:36:22 --> Final output sent to browser
DEBUG - 2011-04-30 09:36:22 --> Total execution time: 0.1222
DEBUG - 2011-04-30 09:36:23 --> Config Class Initialized
DEBUG - 2011-04-30 09:36:23 --> Hooks Class Initialized
DEBUG - 2011-04-30 09:36:23 --> Utf8 Class Initialized
DEBUG - 2011-04-30 09:36:23 --> UTF-8 Support Enabled
DEBUG - 2011-04-30 09:36:23 --> URI Class Initialized
DEBUG - 2011-04-30 09:36:23 --> Router Class Initialized
DEBUG - 2011-04-30 09:36:23 --> Output Class Initialized
DEBUG - 2011-04-30 09:36:23 --> Input Class Initialized
DEBUG - 2011-04-30 09:36:23 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-30 09:36:23 --> Language Class Initialized
DEBUG - 2011-04-30 09:36:23 --> Loader Class Initialized
DEBUG - 2011-04-30 09:36:23 --> Controller Class Initialized
DEBUG - 2011-04-30 09:36:23 --> Model Class Initialized
DEBUG - 2011-04-30 09:36:23 --> Model Class Initialized
DEBUG - 2011-04-30 09:36:23 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-30 09:36:23 --> Database Driver Class Initialized
DEBUG - 2011-04-30 09:36:23 --> Config Class Initialized
DEBUG - 2011-04-30 09:36:23 --> Hooks Class Initialized
DEBUG - 2011-04-30 09:36:23 --> Utf8 Class Initialized
DEBUG - 2011-04-30 09:36:23 --> UTF-8 Support Enabled
DEBUG - 2011-04-30 09:36:23 --> URI Class Initialized
DEBUG - 2011-04-30 09:36:23 --> Router Class Initialized
DEBUG - 2011-04-30 09:36:23 --> Output Class Initialized
DEBUG - 2011-04-30 09:36:23 --> Input Class Initialized
DEBUG - 2011-04-30 09:36:23 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-30 09:36:23 --> Language Class Initialized
DEBUG - 2011-04-30 09:36:23 --> Loader Class Initialized
DEBUG - 2011-04-30 09:36:23 --> Controller Class Initialized
ERROR - 2011-04-30 09:36:23 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-04-30 09:36:23 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-04-30 09:36:23 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-04-30 09:36:23 --> Model Class Initialized
DEBUG - 2011-04-30 09:36:23 --> Model Class Initialized
DEBUG - 2011-04-30 09:36:23 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-30 09:36:23 --> Database Driver Class Initialized
DEBUG - 2011-04-30 09:36:23 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-04-30 09:36:23 --> Helper loaded: url_helper
DEBUG - 2011-04-30 09:36:23 --> File loaded: application/views/common/header.php
DEBUG - 2011-04-30 09:36:23 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-04-30 09:36:23 --> File loaded: application/views/common/footer.php
DEBUG - 2011-04-30 09:36:23 --> File loaded: application/views/layout/main.php
DEBUG - 2011-04-30 09:36:23 --> Final output sent to browser
DEBUG - 2011-04-30 09:36:23 --> Total execution time: 0.0293
DEBUG - 2011-04-30 09:36:23 --> Final output sent to browser
DEBUG - 2011-04-30 09:36:23 --> Total execution time: 0.4223
DEBUG - 2011-04-30 09:36:30 --> Config Class Initialized
DEBUG - 2011-04-30 09:36:30 --> Hooks Class Initialized
DEBUG - 2011-04-30 09:36:30 --> Utf8 Class Initialized
DEBUG - 2011-04-30 09:36:30 --> UTF-8 Support Enabled
DEBUG - 2011-04-30 09:36:30 --> URI Class Initialized
DEBUG - 2011-04-30 09:36:30 --> Router Class Initialized
DEBUG - 2011-04-30 09:36:30 --> Output Class Initialized
DEBUG - 2011-04-30 09:36:30 --> Input Class Initialized
DEBUG - 2011-04-30 09:36:30 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-30 09:36:30 --> Language Class Initialized
DEBUG - 2011-04-30 09:36:30 --> Loader Class Initialized
DEBUG - 2011-04-30 09:36:30 --> Controller Class Initialized
ERROR - 2011-04-30 09:36:30 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-04-30 09:36:30 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-04-30 09:36:30 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-04-30 09:36:30 --> Model Class Initialized
DEBUG - 2011-04-30 09:36:30 --> Model Class Initialized
DEBUG - 2011-04-30 09:36:30 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-30 09:36:30 --> Database Driver Class Initialized
DEBUG - 2011-04-30 09:36:30 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-04-30 09:36:30 --> Helper loaded: url_helper
DEBUG - 2011-04-30 09:36:30 --> File loaded: application/views/common/header.php
DEBUG - 2011-04-30 09:36:30 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-04-30 09:36:30 --> File loaded: application/views/common/footer.php
DEBUG - 2011-04-30 09:36:30 --> File loaded: application/views/layout/main.php
DEBUG - 2011-04-30 09:36:30 --> Final output sent to browser
DEBUG - 2011-04-30 09:36:30 --> Total execution time: 0.0336
DEBUG - 2011-04-30 09:36:31 --> Config Class Initialized
DEBUG - 2011-04-30 09:36:31 --> Hooks Class Initialized
DEBUG - 2011-04-30 09:36:31 --> Utf8 Class Initialized
DEBUG - 2011-04-30 09:36:31 --> UTF-8 Support Enabled
DEBUG - 2011-04-30 09:36:31 --> URI Class Initialized
DEBUG - 2011-04-30 09:36:31 --> Router Class Initialized
DEBUG - 2011-04-30 09:36:31 --> Output Class Initialized
DEBUG - 2011-04-30 09:36:31 --> Input Class Initialized
DEBUG - 2011-04-30 09:36:31 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-30 09:36:31 --> Language Class Initialized
DEBUG - 2011-04-30 09:36:31 --> Loader Class Initialized
DEBUG - 2011-04-30 09:36:31 --> Controller Class Initialized
DEBUG - 2011-04-30 09:36:31 --> Model Class Initialized
DEBUG - 2011-04-30 09:36:31 --> Model Class Initialized
DEBUG - 2011-04-30 09:36:31 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-30 09:36:31 --> Database Driver Class Initialized
DEBUG - 2011-04-30 09:36:31 --> Final output sent to browser
DEBUG - 2011-04-30 09:36:31 --> Total execution time: 0.5544
DEBUG - 2011-04-30 09:36:37 --> Config Class Initialized
DEBUG - 2011-04-30 09:36:37 --> Hooks Class Initialized
DEBUG - 2011-04-30 09:36:37 --> Utf8 Class Initialized
DEBUG - 2011-04-30 09:36:37 --> UTF-8 Support Enabled
DEBUG - 2011-04-30 09:36:37 --> URI Class Initialized
DEBUG - 2011-04-30 09:36:37 --> Router Class Initialized
DEBUG - 2011-04-30 09:36:37 --> Output Class Initialized
DEBUG - 2011-04-30 09:36:37 --> Input Class Initialized
DEBUG - 2011-04-30 09:36:37 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-30 09:36:37 --> Language Class Initialized
DEBUG - 2011-04-30 09:36:37 --> Loader Class Initialized
DEBUG - 2011-04-30 09:36:37 --> Controller Class Initialized
ERROR - 2011-04-30 09:36:37 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-04-30 09:36:37 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-04-30 09:36:37 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-04-30 09:36:37 --> Model Class Initialized
DEBUG - 2011-04-30 09:36:37 --> Model Class Initialized
DEBUG - 2011-04-30 09:36:37 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-30 09:36:37 --> Database Driver Class Initialized
DEBUG - 2011-04-30 09:36:37 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-04-30 09:36:37 --> Helper loaded: url_helper
DEBUG - 2011-04-30 09:36:37 --> File loaded: application/views/common/header.php
DEBUG - 2011-04-30 09:36:37 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-04-30 09:36:37 --> File loaded: application/views/common/footer.php
DEBUG - 2011-04-30 09:36:37 --> File loaded: application/views/layout/main.php
DEBUG - 2011-04-30 09:36:37 --> Final output sent to browser
DEBUG - 2011-04-30 09:36:37 --> Total execution time: 0.0327
DEBUG - 2011-04-30 09:36:37 --> Config Class Initialized
DEBUG - 2011-04-30 09:36:37 --> Hooks Class Initialized
DEBUG - 2011-04-30 09:36:37 --> Utf8 Class Initialized
DEBUG - 2011-04-30 09:36:37 --> UTF-8 Support Enabled
DEBUG - 2011-04-30 09:36:37 --> URI Class Initialized
DEBUG - 2011-04-30 09:36:37 --> Router Class Initialized
DEBUG - 2011-04-30 09:36:37 --> Output Class Initialized
DEBUG - 2011-04-30 09:36:37 --> Input Class Initialized
DEBUG - 2011-04-30 09:36:37 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-30 09:36:37 --> Language Class Initialized
DEBUG - 2011-04-30 09:36:37 --> Loader Class Initialized
DEBUG - 2011-04-30 09:36:37 --> Controller Class Initialized
DEBUG - 2011-04-30 09:36:37 --> Model Class Initialized
DEBUG - 2011-04-30 09:36:37 --> Model Class Initialized
DEBUG - 2011-04-30 09:36:37 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-30 09:36:37 --> Database Driver Class Initialized
DEBUG - 2011-04-30 09:36:38 --> Final output sent to browser
DEBUG - 2011-04-30 09:36:38 --> Total execution time: 0.4723
DEBUG - 2011-04-30 09:36:44 --> Config Class Initialized
DEBUG - 2011-04-30 09:36:44 --> Hooks Class Initialized
DEBUG - 2011-04-30 09:36:44 --> Utf8 Class Initialized
DEBUG - 2011-04-30 09:36:44 --> UTF-8 Support Enabled
DEBUG - 2011-04-30 09:36:44 --> URI Class Initialized
DEBUG - 2011-04-30 09:36:44 --> Router Class Initialized
DEBUG - 2011-04-30 09:36:44 --> Output Class Initialized
DEBUG - 2011-04-30 09:36:44 --> Input Class Initialized
DEBUG - 2011-04-30 09:36:44 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-30 09:36:44 --> Language Class Initialized
DEBUG - 2011-04-30 09:36:44 --> Loader Class Initialized
DEBUG - 2011-04-30 09:36:44 --> Controller Class Initialized
ERROR - 2011-04-30 09:36:44 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-04-30 09:36:44 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-04-30 09:36:44 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-04-30 09:36:44 --> Model Class Initialized
DEBUG - 2011-04-30 09:36:44 --> Model Class Initialized
DEBUG - 2011-04-30 09:36:44 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-30 09:36:44 --> Database Driver Class Initialized
DEBUG - 2011-04-30 09:36:44 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-04-30 09:36:44 --> Helper loaded: url_helper
DEBUG - 2011-04-30 09:36:44 --> File loaded: application/views/common/header.php
DEBUG - 2011-04-30 09:36:44 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-04-30 09:36:44 --> File loaded: application/views/common/footer.php
DEBUG - 2011-04-30 09:36:44 --> File loaded: application/views/layout/main.php
DEBUG - 2011-04-30 09:36:44 --> Final output sent to browser
DEBUG - 2011-04-30 09:36:44 --> Total execution time: 0.0450
DEBUG - 2011-04-30 09:36:44 --> Config Class Initialized
DEBUG - 2011-04-30 09:36:44 --> Hooks Class Initialized
DEBUG - 2011-04-30 09:36:44 --> Utf8 Class Initialized
DEBUG - 2011-04-30 09:36:44 --> UTF-8 Support Enabled
DEBUG - 2011-04-30 09:36:44 --> URI Class Initialized
DEBUG - 2011-04-30 09:36:44 --> Router Class Initialized
DEBUG - 2011-04-30 09:36:44 --> Output Class Initialized
DEBUG - 2011-04-30 09:36:44 --> Input Class Initialized
DEBUG - 2011-04-30 09:36:44 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-30 09:36:44 --> Language Class Initialized
DEBUG - 2011-04-30 09:36:44 --> Loader Class Initialized
DEBUG - 2011-04-30 09:36:44 --> Controller Class Initialized
DEBUG - 2011-04-30 09:36:44 --> Model Class Initialized
DEBUG - 2011-04-30 09:36:44 --> Model Class Initialized
DEBUG - 2011-04-30 09:36:44 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-30 09:36:44 --> Database Driver Class Initialized
DEBUG - 2011-04-30 09:36:45 --> Final output sent to browser
DEBUG - 2011-04-30 09:36:45 --> Total execution time: 0.5072
DEBUG - 2011-04-30 09:36:52 --> Config Class Initialized
DEBUG - 2011-04-30 09:36:52 --> Hooks Class Initialized
DEBUG - 2011-04-30 09:36:52 --> Utf8 Class Initialized
DEBUG - 2011-04-30 09:36:52 --> UTF-8 Support Enabled
DEBUG - 2011-04-30 09:36:52 --> URI Class Initialized
DEBUG - 2011-04-30 09:36:52 --> Router Class Initialized
DEBUG - 2011-04-30 09:36:52 --> Output Class Initialized
DEBUG - 2011-04-30 09:36:52 --> Input Class Initialized
DEBUG - 2011-04-30 09:36:52 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-30 09:36:52 --> Language Class Initialized
DEBUG - 2011-04-30 09:36:52 --> Loader Class Initialized
DEBUG - 2011-04-30 09:36:52 --> Controller Class Initialized
ERROR - 2011-04-30 09:36:52 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-04-30 09:36:52 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-04-30 09:36:52 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-04-30 09:36:52 --> Model Class Initialized
DEBUG - 2011-04-30 09:36:52 --> Model Class Initialized
DEBUG - 2011-04-30 09:36:52 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-30 09:36:52 --> Database Driver Class Initialized
DEBUG - 2011-04-30 09:36:52 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-04-30 09:36:52 --> Helper loaded: url_helper
DEBUG - 2011-04-30 09:36:52 --> File loaded: application/views/common/header.php
DEBUG - 2011-04-30 09:36:52 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-04-30 09:36:52 --> File loaded: application/views/common/footer.php
DEBUG - 2011-04-30 09:36:52 --> File loaded: application/views/layout/main.php
DEBUG - 2011-04-30 09:36:52 --> Final output sent to browser
DEBUG - 2011-04-30 09:36:52 --> Total execution time: 0.0400
DEBUG - 2011-04-30 09:36:53 --> Config Class Initialized
DEBUG - 2011-04-30 09:36:53 --> Hooks Class Initialized
DEBUG - 2011-04-30 09:36:53 --> Utf8 Class Initialized
DEBUG - 2011-04-30 09:36:53 --> UTF-8 Support Enabled
DEBUG - 2011-04-30 09:36:53 --> URI Class Initialized
DEBUG - 2011-04-30 09:36:53 --> Router Class Initialized
DEBUG - 2011-04-30 09:36:53 --> Output Class Initialized
DEBUG - 2011-04-30 09:36:53 --> Input Class Initialized
DEBUG - 2011-04-30 09:36:53 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-30 09:36:53 --> Language Class Initialized
DEBUG - 2011-04-30 09:36:53 --> Loader Class Initialized
DEBUG - 2011-04-30 09:36:53 --> Controller Class Initialized
DEBUG - 2011-04-30 09:36:53 --> Model Class Initialized
DEBUG - 2011-04-30 09:36:53 --> Model Class Initialized
DEBUG - 2011-04-30 09:36:53 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-30 09:36:53 --> Database Driver Class Initialized
DEBUG - 2011-04-30 09:36:53 --> Final output sent to browser
DEBUG - 2011-04-30 09:36:53 --> Total execution time: 0.4088
DEBUG - 2011-04-30 09:36:58 --> Config Class Initialized
DEBUG - 2011-04-30 09:36:58 --> Hooks Class Initialized
DEBUG - 2011-04-30 09:36:58 --> Utf8 Class Initialized
DEBUG - 2011-04-30 09:36:58 --> UTF-8 Support Enabled
DEBUG - 2011-04-30 09:36:58 --> URI Class Initialized
DEBUG - 2011-04-30 09:36:58 --> Router Class Initialized
DEBUG - 2011-04-30 09:36:58 --> Output Class Initialized
DEBUG - 2011-04-30 09:36:58 --> Input Class Initialized
DEBUG - 2011-04-30 09:36:58 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-30 09:36:58 --> Language Class Initialized
DEBUG - 2011-04-30 09:36:58 --> Loader Class Initialized
DEBUG - 2011-04-30 09:36:58 --> Controller Class Initialized
ERROR - 2011-04-30 09:36:58 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-04-30 09:36:58 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-04-30 09:36:58 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-04-30 09:36:58 --> Model Class Initialized
DEBUG - 2011-04-30 09:36:58 --> Model Class Initialized
DEBUG - 2011-04-30 09:36:58 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-30 09:36:58 --> Database Driver Class Initialized
DEBUG - 2011-04-30 09:36:58 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-04-30 09:36:58 --> Helper loaded: url_helper
DEBUG - 2011-04-30 09:36:58 --> File loaded: application/views/common/header.php
DEBUG - 2011-04-30 09:36:58 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-04-30 09:36:58 --> File loaded: application/views/common/footer.php
DEBUG - 2011-04-30 09:36:58 --> File loaded: application/views/layout/main.php
DEBUG - 2011-04-30 09:36:58 --> Final output sent to browser
DEBUG - 2011-04-30 09:36:58 --> Total execution time: 0.0325
DEBUG - 2011-04-30 09:36:59 --> Config Class Initialized
DEBUG - 2011-04-30 09:36:59 --> Hooks Class Initialized
DEBUG - 2011-04-30 09:36:59 --> Utf8 Class Initialized
DEBUG - 2011-04-30 09:36:59 --> UTF-8 Support Enabled
DEBUG - 2011-04-30 09:36:59 --> URI Class Initialized
DEBUG - 2011-04-30 09:36:59 --> Router Class Initialized
DEBUG - 2011-04-30 09:36:59 --> Output Class Initialized
DEBUG - 2011-04-30 09:36:59 --> Input Class Initialized
DEBUG - 2011-04-30 09:36:59 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-30 09:36:59 --> Language Class Initialized
DEBUG - 2011-04-30 09:36:59 --> Loader Class Initialized
DEBUG - 2011-04-30 09:36:59 --> Controller Class Initialized
DEBUG - 2011-04-30 09:36:59 --> Model Class Initialized
DEBUG - 2011-04-30 09:36:59 --> Model Class Initialized
DEBUG - 2011-04-30 09:36:59 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-30 09:36:59 --> Database Driver Class Initialized
DEBUG - 2011-04-30 09:36:59 --> Final output sent to browser
DEBUG - 2011-04-30 09:36:59 --> Total execution time: 0.5179
DEBUG - 2011-04-30 09:37:12 --> Config Class Initialized
DEBUG - 2011-04-30 09:37:12 --> Hooks Class Initialized
DEBUG - 2011-04-30 09:37:12 --> Utf8 Class Initialized
DEBUG - 2011-04-30 09:37:12 --> UTF-8 Support Enabled
DEBUG - 2011-04-30 09:37:12 --> URI Class Initialized
DEBUG - 2011-04-30 09:37:12 --> Router Class Initialized
DEBUG - 2011-04-30 09:37:12 --> Output Class Initialized
DEBUG - 2011-04-30 09:37:12 --> Input Class Initialized
DEBUG - 2011-04-30 09:37:12 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-30 09:37:12 --> Language Class Initialized
DEBUG - 2011-04-30 09:37:12 --> Loader Class Initialized
DEBUG - 2011-04-30 09:37:12 --> Controller Class Initialized
ERROR - 2011-04-30 09:37:12 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-04-30 09:37:12 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-04-30 09:37:12 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-04-30 09:37:12 --> Model Class Initialized
DEBUG - 2011-04-30 09:37:12 --> Model Class Initialized
DEBUG - 2011-04-30 09:37:12 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-30 09:37:12 --> Database Driver Class Initialized
DEBUG - 2011-04-30 09:37:12 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-04-30 09:37:12 --> Helper loaded: url_helper
DEBUG - 2011-04-30 09:37:12 --> File loaded: application/views/common/header.php
DEBUG - 2011-04-30 09:37:12 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-04-30 09:37:12 --> File loaded: application/views/common/footer.php
DEBUG - 2011-04-30 09:37:12 --> File loaded: application/views/layout/main.php
DEBUG - 2011-04-30 09:37:12 --> Final output sent to browser
DEBUG - 2011-04-30 09:37:12 --> Total execution time: 0.0325
DEBUG - 2011-04-30 09:37:13 --> Config Class Initialized
DEBUG - 2011-04-30 09:37:13 --> Hooks Class Initialized
DEBUG - 2011-04-30 09:37:13 --> Utf8 Class Initialized
DEBUG - 2011-04-30 09:37:13 --> UTF-8 Support Enabled
DEBUG - 2011-04-30 09:37:13 --> URI Class Initialized
DEBUG - 2011-04-30 09:37:13 --> Router Class Initialized
DEBUG - 2011-04-30 09:37:13 --> Output Class Initialized
DEBUG - 2011-04-30 09:37:13 --> Input Class Initialized
DEBUG - 2011-04-30 09:37:13 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-30 09:37:13 --> Language Class Initialized
DEBUG - 2011-04-30 09:37:13 --> Loader Class Initialized
DEBUG - 2011-04-30 09:37:13 --> Controller Class Initialized
DEBUG - 2011-04-30 09:37:13 --> Model Class Initialized
DEBUG - 2011-04-30 09:37:13 --> Model Class Initialized
DEBUG - 2011-04-30 09:37:13 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-30 09:37:13 --> Database Driver Class Initialized
DEBUG - 2011-04-30 09:37:13 --> Final output sent to browser
DEBUG - 2011-04-30 09:37:13 --> Total execution time: 0.4575
DEBUG - 2011-04-30 09:37:19 --> Config Class Initialized
DEBUG - 2011-04-30 09:37:19 --> Hooks Class Initialized
DEBUG - 2011-04-30 09:37:19 --> Utf8 Class Initialized
DEBUG - 2011-04-30 09:37:19 --> UTF-8 Support Enabled
DEBUG - 2011-04-30 09:37:19 --> URI Class Initialized
DEBUG - 2011-04-30 09:37:19 --> Router Class Initialized
DEBUG - 2011-04-30 09:37:19 --> Output Class Initialized
DEBUG - 2011-04-30 09:37:19 --> Input Class Initialized
DEBUG - 2011-04-30 09:37:19 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-30 09:37:19 --> Language Class Initialized
DEBUG - 2011-04-30 09:37:19 --> Loader Class Initialized
DEBUG - 2011-04-30 09:37:19 --> Controller Class Initialized
ERROR - 2011-04-30 09:37:19 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-04-30 09:37:19 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-04-30 09:37:19 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-04-30 09:37:19 --> Model Class Initialized
DEBUG - 2011-04-30 09:37:19 --> Model Class Initialized
DEBUG - 2011-04-30 09:37:19 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-30 09:37:19 --> Database Driver Class Initialized
DEBUG - 2011-04-30 09:37:19 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-04-30 09:37:19 --> Helper loaded: url_helper
DEBUG - 2011-04-30 09:37:19 --> File loaded: application/views/common/header.php
DEBUG - 2011-04-30 09:37:19 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-04-30 09:37:19 --> File loaded: application/views/common/footer.php
DEBUG - 2011-04-30 09:37:19 --> File loaded: application/views/layout/main.php
DEBUG - 2011-04-30 09:37:19 --> Final output sent to browser
DEBUG - 2011-04-30 09:37:19 --> Total execution time: 0.0984
DEBUG - 2011-04-30 09:37:27 --> Config Class Initialized
DEBUG - 2011-04-30 09:37:27 --> Hooks Class Initialized
DEBUG - 2011-04-30 09:37:27 --> Utf8 Class Initialized
DEBUG - 2011-04-30 09:37:27 --> UTF-8 Support Enabled
DEBUG - 2011-04-30 09:37:27 --> URI Class Initialized
DEBUG - 2011-04-30 09:37:27 --> Router Class Initialized
DEBUG - 2011-04-30 09:37:27 --> Output Class Initialized
DEBUG - 2011-04-30 09:37:27 --> Input Class Initialized
DEBUG - 2011-04-30 09:37:27 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-30 09:37:27 --> Language Class Initialized
DEBUG - 2011-04-30 09:37:27 --> Loader Class Initialized
DEBUG - 2011-04-30 09:37:27 --> Controller Class Initialized
DEBUG - 2011-04-30 09:37:27 --> Model Class Initialized
DEBUG - 2011-04-30 09:37:27 --> Model Class Initialized
DEBUG - 2011-04-30 09:37:27 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-30 09:37:27 --> Database Driver Class Initialized
DEBUG - 2011-04-30 09:37:28 --> Final output sent to browser
DEBUG - 2011-04-30 09:37:28 --> Total execution time: 0.8291
DEBUG - 2011-04-30 09:37:47 --> Config Class Initialized
DEBUG - 2011-04-30 09:37:47 --> Hooks Class Initialized
DEBUG - 2011-04-30 09:37:47 --> Utf8 Class Initialized
DEBUG - 2011-04-30 09:37:47 --> UTF-8 Support Enabled
DEBUG - 2011-04-30 09:37:47 --> URI Class Initialized
DEBUG - 2011-04-30 09:37:47 --> Router Class Initialized
DEBUG - 2011-04-30 09:37:47 --> Output Class Initialized
DEBUG - 2011-04-30 09:37:47 --> Input Class Initialized
DEBUG - 2011-04-30 09:37:47 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-30 09:37:47 --> Language Class Initialized
DEBUG - 2011-04-30 09:37:47 --> Loader Class Initialized
DEBUG - 2011-04-30 09:37:47 --> Controller Class Initialized
ERROR - 2011-04-30 09:37:47 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-04-30 09:37:47 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-04-30 09:37:47 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-04-30 09:37:47 --> Model Class Initialized
DEBUG - 2011-04-30 09:37:47 --> Model Class Initialized
DEBUG - 2011-04-30 09:37:47 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-30 09:37:48 --> Database Driver Class Initialized
DEBUG - 2011-04-30 09:37:48 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-04-30 09:37:48 --> Helper loaded: url_helper
DEBUG - 2011-04-30 09:37:48 --> File loaded: application/views/common/header.php
DEBUG - 2011-04-30 09:37:48 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-04-30 09:37:48 --> File loaded: application/views/common/footer.php
DEBUG - 2011-04-30 09:37:48 --> File loaded: application/views/layout/main.php
DEBUG - 2011-04-30 09:37:48 --> Final output sent to browser
DEBUG - 2011-04-30 09:37:48 --> Total execution time: 0.1388
DEBUG - 2011-04-30 09:37:48 --> Config Class Initialized
DEBUG - 2011-04-30 09:37:48 --> Hooks Class Initialized
DEBUG - 2011-04-30 09:37:48 --> Utf8 Class Initialized
DEBUG - 2011-04-30 09:37:48 --> UTF-8 Support Enabled
DEBUG - 2011-04-30 09:37:48 --> URI Class Initialized
DEBUG - 2011-04-30 09:37:48 --> Router Class Initialized
DEBUG - 2011-04-30 09:37:48 --> Output Class Initialized
DEBUG - 2011-04-30 09:37:48 --> Input Class Initialized
DEBUG - 2011-04-30 09:37:48 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-30 09:37:48 --> Language Class Initialized
DEBUG - 2011-04-30 09:37:48 --> Loader Class Initialized
DEBUG - 2011-04-30 09:37:48 --> Controller Class Initialized
DEBUG - 2011-04-30 09:37:48 --> Model Class Initialized
DEBUG - 2011-04-30 09:37:48 --> Model Class Initialized
DEBUG - 2011-04-30 09:37:48 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-30 09:37:48 --> Database Driver Class Initialized
DEBUG - 2011-04-30 09:37:49 --> Final output sent to browser
DEBUG - 2011-04-30 09:37:49 --> Total execution time: 0.6130
DEBUG - 2011-04-30 09:37:55 --> Config Class Initialized
DEBUG - 2011-04-30 09:37:55 --> Hooks Class Initialized
DEBUG - 2011-04-30 09:37:55 --> Utf8 Class Initialized
DEBUG - 2011-04-30 09:37:55 --> UTF-8 Support Enabled
DEBUG - 2011-04-30 09:37:55 --> URI Class Initialized
DEBUG - 2011-04-30 09:37:55 --> Router Class Initialized
DEBUG - 2011-04-30 09:37:55 --> Output Class Initialized
DEBUG - 2011-04-30 09:37:55 --> Input Class Initialized
DEBUG - 2011-04-30 09:37:55 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-30 09:37:55 --> Language Class Initialized
DEBUG - 2011-04-30 09:37:55 --> Loader Class Initialized
DEBUG - 2011-04-30 09:37:55 --> Controller Class Initialized
ERROR - 2011-04-30 09:37:55 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-04-30 09:37:55 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-04-30 09:37:55 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-04-30 09:37:55 --> Model Class Initialized
DEBUG - 2011-04-30 09:37:55 --> Model Class Initialized
DEBUG - 2011-04-30 09:37:55 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-30 09:37:55 --> Database Driver Class Initialized
DEBUG - 2011-04-30 09:37:55 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-04-30 09:37:55 --> Helper loaded: url_helper
DEBUG - 2011-04-30 09:37:55 --> File loaded: application/views/common/header.php
DEBUG - 2011-04-30 09:37:55 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-04-30 09:37:55 --> File loaded: application/views/common/footer.php
DEBUG - 2011-04-30 09:37:55 --> File loaded: application/views/layout/main.php
DEBUG - 2011-04-30 09:37:55 --> Final output sent to browser
DEBUG - 2011-04-30 09:37:55 --> Total execution time: 0.0309
DEBUG - 2011-04-30 09:37:56 --> Config Class Initialized
DEBUG - 2011-04-30 09:37:56 --> Hooks Class Initialized
DEBUG - 2011-04-30 09:37:56 --> Utf8 Class Initialized
DEBUG - 2011-04-30 09:37:56 --> UTF-8 Support Enabled
DEBUG - 2011-04-30 09:37:56 --> URI Class Initialized
DEBUG - 2011-04-30 09:37:56 --> Router Class Initialized
DEBUG - 2011-04-30 09:37:56 --> Output Class Initialized
DEBUG - 2011-04-30 09:37:56 --> Input Class Initialized
DEBUG - 2011-04-30 09:37:56 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-30 09:37:56 --> Language Class Initialized
DEBUG - 2011-04-30 09:37:56 --> Loader Class Initialized
DEBUG - 2011-04-30 09:37:56 --> Controller Class Initialized
DEBUG - 2011-04-30 09:37:56 --> Model Class Initialized
DEBUG - 2011-04-30 09:37:56 --> Model Class Initialized
DEBUG - 2011-04-30 09:37:56 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-30 09:37:56 --> Database Driver Class Initialized
DEBUG - 2011-04-30 09:37:56 --> Final output sent to browser
DEBUG - 2011-04-30 09:37:56 --> Total execution time: 0.6057
DEBUG - 2011-04-30 09:38:02 --> Config Class Initialized
DEBUG - 2011-04-30 09:38:02 --> Hooks Class Initialized
DEBUG - 2011-04-30 09:38:02 --> Utf8 Class Initialized
DEBUG - 2011-04-30 09:38:02 --> UTF-8 Support Enabled
DEBUG - 2011-04-30 09:38:02 --> URI Class Initialized
DEBUG - 2011-04-30 09:38:02 --> Router Class Initialized
DEBUG - 2011-04-30 09:38:02 --> Output Class Initialized
DEBUG - 2011-04-30 09:38:02 --> Input Class Initialized
DEBUG - 2011-04-30 09:38:02 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-30 09:38:02 --> Language Class Initialized
DEBUG - 2011-04-30 09:38:02 --> Loader Class Initialized
DEBUG - 2011-04-30 09:38:02 --> Controller Class Initialized
ERROR - 2011-04-30 09:38:02 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-04-30 09:38:02 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-04-30 09:38:02 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-04-30 09:38:02 --> Model Class Initialized
DEBUG - 2011-04-30 09:38:02 --> Model Class Initialized
DEBUG - 2011-04-30 09:38:02 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-30 09:38:02 --> Database Driver Class Initialized
DEBUG - 2011-04-30 09:38:02 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-04-30 09:38:02 --> Helper loaded: url_helper
DEBUG - 2011-04-30 09:38:02 --> File loaded: application/views/common/header.php
DEBUG - 2011-04-30 09:38:02 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-04-30 09:38:02 --> File loaded: application/views/common/footer.php
DEBUG - 2011-04-30 09:38:02 --> File loaded: application/views/layout/main.php
DEBUG - 2011-04-30 09:38:02 --> Final output sent to browser
DEBUG - 2011-04-30 09:38:02 --> Total execution time: 0.0636
DEBUG - 2011-04-30 09:38:03 --> Config Class Initialized
DEBUG - 2011-04-30 09:38:03 --> Hooks Class Initialized
DEBUG - 2011-04-30 09:38:03 --> Utf8 Class Initialized
DEBUG - 2011-04-30 09:38:03 --> UTF-8 Support Enabled
DEBUG - 2011-04-30 09:38:03 --> URI Class Initialized
DEBUG - 2011-04-30 09:38:03 --> Router Class Initialized
DEBUG - 2011-04-30 09:38:03 --> Output Class Initialized
DEBUG - 2011-04-30 09:38:03 --> Input Class Initialized
DEBUG - 2011-04-30 09:38:03 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-30 09:38:03 --> Language Class Initialized
DEBUG - 2011-04-30 09:38:03 --> Loader Class Initialized
DEBUG - 2011-04-30 09:38:03 --> Controller Class Initialized
DEBUG - 2011-04-30 09:38:03 --> Model Class Initialized
DEBUG - 2011-04-30 09:38:03 --> Model Class Initialized
DEBUG - 2011-04-30 09:38:03 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-30 09:38:03 --> Database Driver Class Initialized
DEBUG - 2011-04-30 09:38:04 --> Final output sent to browser
DEBUG - 2011-04-30 09:38:04 --> Total execution time: 0.6848
DEBUG - 2011-04-30 09:38:13 --> Config Class Initialized
DEBUG - 2011-04-30 09:38:13 --> Hooks Class Initialized
DEBUG - 2011-04-30 09:38:13 --> Utf8 Class Initialized
DEBUG - 2011-04-30 09:38:13 --> UTF-8 Support Enabled
DEBUG - 2011-04-30 09:38:13 --> URI Class Initialized
DEBUG - 2011-04-30 09:38:13 --> Router Class Initialized
DEBUG - 2011-04-30 09:38:13 --> Output Class Initialized
DEBUG - 2011-04-30 09:38:13 --> Input Class Initialized
DEBUG - 2011-04-30 09:38:13 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-30 09:38:13 --> Language Class Initialized
DEBUG - 2011-04-30 09:38:13 --> Loader Class Initialized
DEBUG - 2011-04-30 09:38:13 --> Controller Class Initialized
ERROR - 2011-04-30 09:38:13 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-04-30 09:38:13 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-04-30 09:38:13 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-04-30 09:38:13 --> Model Class Initialized
DEBUG - 2011-04-30 09:38:13 --> Model Class Initialized
DEBUG - 2011-04-30 09:38:13 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-30 09:38:14 --> Database Driver Class Initialized
DEBUG - 2011-04-30 09:38:14 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-04-30 09:38:14 --> Helper loaded: url_helper
DEBUG - 2011-04-30 09:38:14 --> File loaded: application/views/common/header.php
DEBUG - 2011-04-30 09:38:14 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-04-30 09:38:14 --> File loaded: application/views/common/footer.php
DEBUG - 2011-04-30 09:38:14 --> File loaded: application/views/layout/main.php
DEBUG - 2011-04-30 09:38:14 --> Final output sent to browser
DEBUG - 2011-04-30 09:38:14 --> Total execution time: 0.0288
DEBUG - 2011-04-30 09:38:14 --> Config Class Initialized
DEBUG - 2011-04-30 09:38:14 --> Hooks Class Initialized
DEBUG - 2011-04-30 09:38:14 --> Utf8 Class Initialized
DEBUG - 2011-04-30 09:38:14 --> UTF-8 Support Enabled
DEBUG - 2011-04-30 09:38:14 --> URI Class Initialized
DEBUG - 2011-04-30 09:38:14 --> Router Class Initialized
DEBUG - 2011-04-30 09:38:14 --> Output Class Initialized
DEBUG - 2011-04-30 09:38:14 --> Input Class Initialized
DEBUG - 2011-04-30 09:38:14 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-30 09:38:14 --> Language Class Initialized
DEBUG - 2011-04-30 09:38:14 --> Loader Class Initialized
DEBUG - 2011-04-30 09:38:14 --> Controller Class Initialized
DEBUG - 2011-04-30 09:38:14 --> Model Class Initialized
DEBUG - 2011-04-30 09:38:14 --> Model Class Initialized
DEBUG - 2011-04-30 09:38:14 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-30 09:38:14 --> Database Driver Class Initialized
DEBUG - 2011-04-30 09:38:15 --> Final output sent to browser
DEBUG - 2011-04-30 09:38:15 --> Total execution time: 0.5023
DEBUG - 2011-04-30 09:38:26 --> Config Class Initialized
DEBUG - 2011-04-30 09:38:26 --> Hooks Class Initialized
DEBUG - 2011-04-30 09:38:26 --> Utf8 Class Initialized
DEBUG - 2011-04-30 09:38:26 --> UTF-8 Support Enabled
DEBUG - 2011-04-30 09:38:26 --> URI Class Initialized
DEBUG - 2011-04-30 09:38:26 --> Router Class Initialized
DEBUG - 2011-04-30 09:38:26 --> Output Class Initialized
DEBUG - 2011-04-30 09:38:26 --> Input Class Initialized
DEBUG - 2011-04-30 09:38:26 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-30 09:38:26 --> Language Class Initialized
DEBUG - 2011-04-30 09:38:26 --> Loader Class Initialized
DEBUG - 2011-04-30 09:38:26 --> Controller Class Initialized
ERROR - 2011-04-30 09:38:26 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-04-30 09:38:26 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-04-30 09:38:26 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-04-30 09:38:26 --> Model Class Initialized
DEBUG - 2011-04-30 09:38:26 --> Model Class Initialized
DEBUG - 2011-04-30 09:38:26 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-30 09:38:26 --> Database Driver Class Initialized
DEBUG - 2011-04-30 09:38:26 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-04-30 09:38:26 --> Helper loaded: url_helper
DEBUG - 2011-04-30 09:38:26 --> File loaded: application/views/common/header.php
DEBUG - 2011-04-30 09:38:26 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-04-30 09:38:26 --> File loaded: application/views/common/footer.php
DEBUG - 2011-04-30 09:38:26 --> File loaded: application/views/layout/main.php
DEBUG - 2011-04-30 09:38:26 --> Final output sent to browser
DEBUG - 2011-04-30 09:38:26 --> Total execution time: 0.0289
DEBUG - 2011-04-30 09:38:37 --> Config Class Initialized
DEBUG - 2011-04-30 09:38:37 --> Hooks Class Initialized
DEBUG - 2011-04-30 09:38:37 --> Utf8 Class Initialized
DEBUG - 2011-04-30 09:38:37 --> UTF-8 Support Enabled
DEBUG - 2011-04-30 09:38:37 --> URI Class Initialized
DEBUG - 2011-04-30 09:38:37 --> Router Class Initialized
DEBUG - 2011-04-30 09:38:37 --> Output Class Initialized
DEBUG - 2011-04-30 09:38:37 --> Input Class Initialized
DEBUG - 2011-04-30 09:38:37 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-30 09:38:37 --> Language Class Initialized
DEBUG - 2011-04-30 09:38:37 --> Loader Class Initialized
DEBUG - 2011-04-30 09:38:37 --> Controller Class Initialized
ERROR - 2011-04-30 09:38:37 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-04-30 09:38:37 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-04-30 09:38:37 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-04-30 09:38:37 --> Model Class Initialized
DEBUG - 2011-04-30 09:38:37 --> Model Class Initialized
DEBUG - 2011-04-30 09:38:37 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-30 09:38:37 --> Database Driver Class Initialized
DEBUG - 2011-04-30 09:38:37 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-04-30 09:38:37 --> Helper loaded: url_helper
DEBUG - 2011-04-30 09:38:37 --> File loaded: application/views/common/header.php
DEBUG - 2011-04-30 09:38:37 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-04-30 09:38:37 --> File loaded: application/views/common/footer.php
DEBUG - 2011-04-30 09:38:37 --> File loaded: application/views/layout/main.php
DEBUG - 2011-04-30 09:38:37 --> Final output sent to browser
DEBUG - 2011-04-30 09:38:37 --> Total execution time: 0.0349
DEBUG - 2011-04-30 09:38:44 --> Config Class Initialized
DEBUG - 2011-04-30 09:38:44 --> Hooks Class Initialized
DEBUG - 2011-04-30 09:38:44 --> Utf8 Class Initialized
DEBUG - 2011-04-30 09:38:44 --> UTF-8 Support Enabled
DEBUG - 2011-04-30 09:38:44 --> URI Class Initialized
DEBUG - 2011-04-30 09:38:44 --> Router Class Initialized
DEBUG - 2011-04-30 09:38:44 --> Output Class Initialized
DEBUG - 2011-04-30 09:38:44 --> Input Class Initialized
DEBUG - 2011-04-30 09:38:44 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-30 09:38:44 --> Language Class Initialized
DEBUG - 2011-04-30 09:38:44 --> Loader Class Initialized
DEBUG - 2011-04-30 09:38:44 --> Controller Class Initialized
ERROR - 2011-04-30 09:38:44 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-04-30 09:38:44 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-04-30 09:38:44 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-04-30 09:38:44 --> Model Class Initialized
DEBUG - 2011-04-30 09:38:44 --> Model Class Initialized
DEBUG - 2011-04-30 09:38:44 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-30 09:38:44 --> Database Driver Class Initialized
DEBUG - 2011-04-30 09:38:44 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-04-30 09:38:44 --> Helper loaded: url_helper
DEBUG - 2011-04-30 09:38:44 --> File loaded: application/views/common/header.php
DEBUG - 2011-04-30 09:38:44 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-04-30 09:38:44 --> File loaded: application/views/common/footer.php
DEBUG - 2011-04-30 09:38:44 --> File loaded: application/views/layout/main.php
DEBUG - 2011-04-30 09:38:44 --> Final output sent to browser
DEBUG - 2011-04-30 09:38:44 --> Total execution time: 0.0275
DEBUG - 2011-04-30 09:38:45 --> Config Class Initialized
DEBUG - 2011-04-30 09:38:45 --> Hooks Class Initialized
DEBUG - 2011-04-30 09:38:45 --> Utf8 Class Initialized
DEBUG - 2011-04-30 09:38:45 --> UTF-8 Support Enabled
DEBUG - 2011-04-30 09:38:45 --> URI Class Initialized
DEBUG - 2011-04-30 09:38:45 --> Router Class Initialized
DEBUG - 2011-04-30 09:38:45 --> Output Class Initialized
DEBUG - 2011-04-30 09:38:45 --> Input Class Initialized
DEBUG - 2011-04-30 09:38:45 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-30 09:38:45 --> Language Class Initialized
DEBUG - 2011-04-30 09:38:45 --> Loader Class Initialized
DEBUG - 2011-04-30 09:38:45 --> Controller Class Initialized
DEBUG - 2011-04-30 09:38:45 --> Model Class Initialized
DEBUG - 2011-04-30 09:38:45 --> Model Class Initialized
DEBUG - 2011-04-30 09:38:45 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-30 09:38:45 --> Database Driver Class Initialized
DEBUG - 2011-04-30 09:38:45 --> Final output sent to browser
DEBUG - 2011-04-30 09:38:45 --> Total execution time: 0.4397
DEBUG - 2011-04-30 09:39:04 --> Config Class Initialized
DEBUG - 2011-04-30 09:39:04 --> Hooks Class Initialized
DEBUG - 2011-04-30 09:39:04 --> Utf8 Class Initialized
DEBUG - 2011-04-30 09:39:04 --> UTF-8 Support Enabled
DEBUG - 2011-04-30 09:39:04 --> URI Class Initialized
DEBUG - 2011-04-30 09:39:04 --> Router Class Initialized
DEBUG - 2011-04-30 09:39:04 --> Output Class Initialized
DEBUG - 2011-04-30 09:39:04 --> Input Class Initialized
DEBUG - 2011-04-30 09:39:04 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-30 09:39:04 --> Language Class Initialized
DEBUG - 2011-04-30 09:39:04 --> Loader Class Initialized
DEBUG - 2011-04-30 09:39:04 --> Controller Class Initialized
ERROR - 2011-04-30 09:39:04 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-04-30 09:39:04 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-04-30 09:39:04 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-04-30 09:39:04 --> Model Class Initialized
DEBUG - 2011-04-30 09:39:04 --> Model Class Initialized
DEBUG - 2011-04-30 09:39:04 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-30 09:39:04 --> Database Driver Class Initialized
DEBUG - 2011-04-30 09:39:04 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-04-30 09:39:04 --> Helper loaded: url_helper
DEBUG - 2011-04-30 09:39:04 --> File loaded: application/views/common/header.php
DEBUG - 2011-04-30 09:39:04 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-04-30 09:39:04 --> File loaded: application/views/common/footer.php
DEBUG - 2011-04-30 09:39:04 --> File loaded: application/views/layout/main.php
DEBUG - 2011-04-30 09:39:04 --> Final output sent to browser
DEBUG - 2011-04-30 09:39:04 --> Total execution time: 0.0713
DEBUG - 2011-04-30 09:39:04 --> Config Class Initialized
DEBUG - 2011-04-30 09:39:04 --> Hooks Class Initialized
DEBUG - 2011-04-30 09:39:04 --> Utf8 Class Initialized
DEBUG - 2011-04-30 09:39:04 --> UTF-8 Support Enabled
DEBUG - 2011-04-30 09:39:04 --> URI Class Initialized
DEBUG - 2011-04-30 09:39:04 --> Router Class Initialized
DEBUG - 2011-04-30 09:39:04 --> Output Class Initialized
DEBUG - 2011-04-30 09:39:04 --> Input Class Initialized
DEBUG - 2011-04-30 09:39:04 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-30 09:39:04 --> Language Class Initialized
DEBUG - 2011-04-30 09:39:04 --> Loader Class Initialized
DEBUG - 2011-04-30 09:39:04 --> Controller Class Initialized
DEBUG - 2011-04-30 09:39:04 --> Model Class Initialized
DEBUG - 2011-04-30 09:39:04 --> Model Class Initialized
DEBUG - 2011-04-30 09:39:04 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-30 09:39:04 --> Database Driver Class Initialized
DEBUG - 2011-04-30 09:39:05 --> Final output sent to browser
DEBUG - 2011-04-30 09:39:05 --> Total execution time: 0.6051
DEBUG - 2011-04-30 09:39:10 --> Config Class Initialized
DEBUG - 2011-04-30 09:39:10 --> Hooks Class Initialized
DEBUG - 2011-04-30 09:39:10 --> Utf8 Class Initialized
DEBUG - 2011-04-30 09:39:10 --> UTF-8 Support Enabled
DEBUG - 2011-04-30 09:39:10 --> URI Class Initialized
DEBUG - 2011-04-30 09:39:10 --> Router Class Initialized
DEBUG - 2011-04-30 09:39:10 --> Output Class Initialized
DEBUG - 2011-04-30 09:39:10 --> Input Class Initialized
DEBUG - 2011-04-30 09:39:10 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-30 09:39:10 --> Language Class Initialized
DEBUG - 2011-04-30 09:39:10 --> Loader Class Initialized
DEBUG - 2011-04-30 09:39:10 --> Controller Class Initialized
ERROR - 2011-04-30 09:39:10 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-04-30 09:39:10 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-04-30 09:39:10 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-04-30 09:39:10 --> Model Class Initialized
DEBUG - 2011-04-30 09:39:10 --> Model Class Initialized
DEBUG - 2011-04-30 09:39:10 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-30 09:39:10 --> Database Driver Class Initialized
DEBUG - 2011-04-30 09:39:10 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-04-30 09:39:10 --> Helper loaded: url_helper
DEBUG - 2011-04-30 09:39:10 --> File loaded: application/views/common/header.php
DEBUG - 2011-04-30 09:39:10 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-04-30 09:39:10 --> File loaded: application/views/common/footer.php
DEBUG - 2011-04-30 09:39:10 --> File loaded: application/views/layout/main.php
DEBUG - 2011-04-30 09:39:10 --> Final output sent to browser
DEBUG - 2011-04-30 09:39:10 --> Total execution time: 0.0323
DEBUG - 2011-04-30 09:39:15 --> Config Class Initialized
DEBUG - 2011-04-30 09:39:15 --> Hooks Class Initialized
DEBUG - 2011-04-30 09:39:15 --> Utf8 Class Initialized
DEBUG - 2011-04-30 09:39:15 --> UTF-8 Support Enabled
DEBUG - 2011-04-30 09:39:15 --> URI Class Initialized
DEBUG - 2011-04-30 09:39:15 --> Router Class Initialized
DEBUG - 2011-04-30 09:39:15 --> Output Class Initialized
DEBUG - 2011-04-30 09:39:15 --> Input Class Initialized
DEBUG - 2011-04-30 09:39:15 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-30 09:39:15 --> Language Class Initialized
DEBUG - 2011-04-30 09:39:15 --> Loader Class Initialized
DEBUG - 2011-04-30 09:39:15 --> Controller Class Initialized
ERROR - 2011-04-30 09:39:15 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-04-30 09:39:15 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-04-30 09:39:15 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-04-30 09:39:15 --> Model Class Initialized
DEBUG - 2011-04-30 09:39:15 --> Model Class Initialized
DEBUG - 2011-04-30 09:39:15 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-30 09:39:15 --> Database Driver Class Initialized
DEBUG - 2011-04-30 09:39:15 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-04-30 09:39:15 --> Helper loaded: url_helper
DEBUG - 2011-04-30 09:39:15 --> File loaded: application/views/common/header.php
DEBUG - 2011-04-30 09:39:15 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-04-30 09:39:15 --> File loaded: application/views/common/footer.php
DEBUG - 2011-04-30 09:39:15 --> File loaded: application/views/layout/main.php
DEBUG - 2011-04-30 09:39:15 --> Final output sent to browser
DEBUG - 2011-04-30 09:39:15 --> Total execution time: 0.0289
DEBUG - 2011-04-30 09:39:16 --> Config Class Initialized
DEBUG - 2011-04-30 09:39:16 --> Hooks Class Initialized
DEBUG - 2011-04-30 09:39:16 --> Utf8 Class Initialized
DEBUG - 2011-04-30 09:39:16 --> UTF-8 Support Enabled
DEBUG - 2011-04-30 09:39:16 --> URI Class Initialized
DEBUG - 2011-04-30 09:39:16 --> Router Class Initialized
DEBUG - 2011-04-30 09:39:16 --> Output Class Initialized
DEBUG - 2011-04-30 09:39:16 --> Input Class Initialized
DEBUG - 2011-04-30 09:39:16 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-30 09:39:16 --> Language Class Initialized
DEBUG - 2011-04-30 09:39:16 --> Loader Class Initialized
DEBUG - 2011-04-30 09:39:16 --> Controller Class Initialized
ERROR - 2011-04-30 09:39:16 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-04-30 09:39:16 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-04-30 09:39:16 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-04-30 09:39:16 --> Model Class Initialized
DEBUG - 2011-04-30 09:39:16 --> Model Class Initialized
DEBUG - 2011-04-30 09:39:16 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-30 09:39:16 --> Database Driver Class Initialized
DEBUG - 2011-04-30 09:39:16 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-04-30 09:39:16 --> Helper loaded: url_helper
DEBUG - 2011-04-30 09:39:16 --> File loaded: application/views/common/header.php
DEBUG - 2011-04-30 09:39:16 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-04-30 09:39:16 --> File loaded: application/views/common/footer.php
DEBUG - 2011-04-30 09:39:16 --> File loaded: application/views/layout/main.php
DEBUG - 2011-04-30 09:39:16 --> Final output sent to browser
DEBUG - 2011-04-30 09:39:16 --> Total execution time: 0.0352
DEBUG - 2011-04-30 09:39:17 --> Config Class Initialized
DEBUG - 2011-04-30 09:39:17 --> Hooks Class Initialized
DEBUG - 2011-04-30 09:39:17 --> Utf8 Class Initialized
DEBUG - 2011-04-30 09:39:17 --> UTF-8 Support Enabled
DEBUG - 2011-04-30 09:39:17 --> URI Class Initialized
DEBUG - 2011-04-30 09:39:17 --> Router Class Initialized
DEBUG - 2011-04-30 09:39:17 --> Output Class Initialized
DEBUG - 2011-04-30 09:39:17 --> Input Class Initialized
DEBUG - 2011-04-30 09:39:17 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-30 09:39:17 --> Language Class Initialized
DEBUG - 2011-04-30 09:39:17 --> Loader Class Initialized
DEBUG - 2011-04-30 09:39:17 --> Controller Class Initialized
ERROR - 2011-04-30 09:39:17 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-04-30 09:39:17 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-04-30 09:39:17 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-04-30 09:39:17 --> Model Class Initialized
DEBUG - 2011-04-30 09:39:17 --> Model Class Initialized
DEBUG - 2011-04-30 09:39:17 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-30 09:39:17 --> Database Driver Class Initialized
DEBUG - 2011-04-30 09:39:18 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-04-30 09:39:18 --> Helper loaded: url_helper
DEBUG - 2011-04-30 09:39:18 --> File loaded: application/views/common/header.php
DEBUG - 2011-04-30 09:39:18 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-04-30 09:39:18 --> File loaded: application/views/common/footer.php
DEBUG - 2011-04-30 09:39:18 --> File loaded: application/views/layout/main.php
DEBUG - 2011-04-30 09:39:18 --> Final output sent to browser
DEBUG - 2011-04-30 09:39:18 --> Total execution time: 0.0534
DEBUG - 2011-04-30 09:39:18 --> Config Class Initialized
DEBUG - 2011-04-30 09:39:18 --> Hooks Class Initialized
DEBUG - 2011-04-30 09:39:18 --> Utf8 Class Initialized
DEBUG - 2011-04-30 09:39:18 --> UTF-8 Support Enabled
DEBUG - 2011-04-30 09:39:18 --> URI Class Initialized
DEBUG - 2011-04-30 09:39:18 --> Router Class Initialized
DEBUG - 2011-04-30 09:39:18 --> Output Class Initialized
DEBUG - 2011-04-30 09:39:18 --> Input Class Initialized
DEBUG - 2011-04-30 09:39:18 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-30 09:39:18 --> Language Class Initialized
DEBUG - 2011-04-30 09:39:18 --> Loader Class Initialized
DEBUG - 2011-04-30 09:39:18 --> Controller Class Initialized
ERROR - 2011-04-30 09:39:18 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-04-30 09:39:18 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-04-30 09:39:18 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-04-30 09:39:18 --> Model Class Initialized
DEBUG - 2011-04-30 09:39:18 --> Model Class Initialized
DEBUG - 2011-04-30 09:39:18 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-30 09:39:18 --> Database Driver Class Initialized
DEBUG - 2011-04-30 09:39:18 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-04-30 09:39:18 --> Helper loaded: url_helper
DEBUG - 2011-04-30 09:39:18 --> File loaded: application/views/common/header.php
DEBUG - 2011-04-30 09:39:18 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-04-30 09:39:18 --> File loaded: application/views/common/footer.php
DEBUG - 2011-04-30 09:39:18 --> File loaded: application/views/layout/main.php
DEBUG - 2011-04-30 09:39:18 --> Final output sent to browser
DEBUG - 2011-04-30 09:39:18 --> Total execution time: 0.0292
DEBUG - 2011-04-30 09:39:19 --> Config Class Initialized
DEBUG - 2011-04-30 09:39:19 --> Hooks Class Initialized
DEBUG - 2011-04-30 09:39:19 --> Utf8 Class Initialized
DEBUG - 2011-04-30 09:39:19 --> UTF-8 Support Enabled
DEBUG - 2011-04-30 09:39:19 --> URI Class Initialized
DEBUG - 2011-04-30 09:39:19 --> Router Class Initialized
DEBUG - 2011-04-30 09:39:19 --> Output Class Initialized
DEBUG - 2011-04-30 09:39:19 --> Input Class Initialized
DEBUG - 2011-04-30 09:39:19 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-30 09:39:19 --> Language Class Initialized
DEBUG - 2011-04-30 09:39:19 --> Loader Class Initialized
DEBUG - 2011-04-30 09:39:19 --> Controller Class Initialized
ERROR - 2011-04-30 09:39:19 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-04-30 09:39:19 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-04-30 09:39:19 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-04-30 09:39:19 --> Model Class Initialized
DEBUG - 2011-04-30 09:39:19 --> Model Class Initialized
DEBUG - 2011-04-30 09:39:19 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-30 09:39:19 --> Database Driver Class Initialized
DEBUG - 2011-04-30 09:39:19 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-04-30 09:39:19 --> Helper loaded: url_helper
DEBUG - 2011-04-30 09:39:19 --> File loaded: application/views/common/header.php
DEBUG - 2011-04-30 09:39:19 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-04-30 09:39:19 --> File loaded: application/views/common/footer.php
DEBUG - 2011-04-30 09:39:19 --> File loaded: application/views/layout/main.php
DEBUG - 2011-04-30 09:39:19 --> Final output sent to browser
DEBUG - 2011-04-30 09:39:19 --> Total execution time: 0.0324
DEBUG - 2011-04-30 09:39:19 --> Config Class Initialized
DEBUG - 2011-04-30 09:39:19 --> Hooks Class Initialized
DEBUG - 2011-04-30 09:39:19 --> Utf8 Class Initialized
DEBUG - 2011-04-30 09:39:19 --> UTF-8 Support Enabled
DEBUG - 2011-04-30 09:39:19 --> URI Class Initialized
DEBUG - 2011-04-30 09:39:19 --> Router Class Initialized
DEBUG - 2011-04-30 09:39:19 --> Output Class Initialized
DEBUG - 2011-04-30 09:39:19 --> Input Class Initialized
DEBUG - 2011-04-30 09:39:19 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-30 09:39:19 --> Language Class Initialized
DEBUG - 2011-04-30 09:39:19 --> Loader Class Initialized
DEBUG - 2011-04-30 09:39:19 --> Controller Class Initialized
ERROR - 2011-04-30 09:39:19 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-04-30 09:39:19 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-04-30 09:39:19 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-04-30 09:39:19 --> Model Class Initialized
DEBUG - 2011-04-30 09:39:19 --> Model Class Initialized
DEBUG - 2011-04-30 09:39:19 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-30 09:39:19 --> Database Driver Class Initialized
DEBUG - 2011-04-30 09:39:19 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-04-30 09:39:19 --> Helper loaded: url_helper
DEBUG - 2011-04-30 09:39:19 --> File loaded: application/views/common/header.php
DEBUG - 2011-04-30 09:39:19 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-04-30 09:39:19 --> File loaded: application/views/common/footer.php
DEBUG - 2011-04-30 09:39:19 --> File loaded: application/views/layout/main.php
DEBUG - 2011-04-30 09:39:19 --> Final output sent to browser
DEBUG - 2011-04-30 09:39:19 --> Total execution time: 0.0357
DEBUG - 2011-04-30 09:39:20 --> Config Class Initialized
DEBUG - 2011-04-30 09:39:20 --> Hooks Class Initialized
DEBUG - 2011-04-30 09:39:20 --> Utf8 Class Initialized
DEBUG - 2011-04-30 09:39:20 --> UTF-8 Support Enabled
DEBUG - 2011-04-30 09:39:20 --> URI Class Initialized
DEBUG - 2011-04-30 09:39:20 --> Router Class Initialized
DEBUG - 2011-04-30 09:39:20 --> Output Class Initialized
DEBUG - 2011-04-30 09:39:20 --> Input Class Initialized
DEBUG - 2011-04-30 09:39:20 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-30 09:39:20 --> Language Class Initialized
DEBUG - 2011-04-30 09:39:20 --> Loader Class Initialized
DEBUG - 2011-04-30 09:39:20 --> Controller Class Initialized
ERROR - 2011-04-30 09:39:20 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-04-30 09:39:20 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-04-30 09:39:20 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-04-30 09:39:20 --> Model Class Initialized
DEBUG - 2011-04-30 09:39:20 --> Model Class Initialized
DEBUG - 2011-04-30 09:39:20 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-30 09:39:20 --> Database Driver Class Initialized
DEBUG - 2011-04-30 09:39:20 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-04-30 09:39:20 --> Helper loaded: url_helper
DEBUG - 2011-04-30 09:39:20 --> File loaded: application/views/common/header.php
DEBUG - 2011-04-30 09:39:20 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-04-30 09:39:20 --> File loaded: application/views/common/footer.php
DEBUG - 2011-04-30 09:39:20 --> File loaded: application/views/layout/main.php
DEBUG - 2011-04-30 09:39:20 --> Final output sent to browser
DEBUG - 2011-04-30 09:39:20 --> Total execution time: 0.0289
DEBUG - 2011-04-30 09:39:22 --> Config Class Initialized
DEBUG - 2011-04-30 09:39:22 --> Hooks Class Initialized
DEBUG - 2011-04-30 09:39:22 --> Utf8 Class Initialized
DEBUG - 2011-04-30 09:39:22 --> UTF-8 Support Enabled
DEBUG - 2011-04-30 09:39:22 --> URI Class Initialized
DEBUG - 2011-04-30 09:39:22 --> Router Class Initialized
DEBUG - 2011-04-30 09:39:22 --> Output Class Initialized
DEBUG - 2011-04-30 09:39:22 --> Input Class Initialized
DEBUG - 2011-04-30 09:39:22 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-30 09:39:22 --> Language Class Initialized
DEBUG - 2011-04-30 09:39:22 --> Loader Class Initialized
DEBUG - 2011-04-30 09:39:22 --> Controller Class Initialized
ERROR - 2011-04-30 09:39:22 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-04-30 09:39:22 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-04-30 09:39:22 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-04-30 09:39:22 --> Model Class Initialized
DEBUG - 2011-04-30 09:39:22 --> Model Class Initialized
DEBUG - 2011-04-30 09:39:22 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-30 09:39:22 --> Database Driver Class Initialized
DEBUG - 2011-04-30 09:39:22 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-04-30 09:39:22 --> Helper loaded: url_helper
DEBUG - 2011-04-30 09:39:22 --> File loaded: application/views/common/header.php
DEBUG - 2011-04-30 09:39:22 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-04-30 09:39:22 --> File loaded: application/views/common/footer.php
DEBUG - 2011-04-30 09:39:22 --> File loaded: application/views/layout/main.php
DEBUG - 2011-04-30 09:39:22 --> Final output sent to browser
DEBUG - 2011-04-30 09:39:22 --> Total execution time: 0.0806
DEBUG - 2011-04-30 09:39:25 --> Config Class Initialized
DEBUG - 2011-04-30 09:39:25 --> Hooks Class Initialized
DEBUG - 2011-04-30 09:39:25 --> Utf8 Class Initialized
DEBUG - 2011-04-30 09:39:25 --> UTF-8 Support Enabled
DEBUG - 2011-04-30 09:39:25 --> URI Class Initialized
DEBUG - 2011-04-30 09:39:25 --> Router Class Initialized
DEBUG - 2011-04-30 09:39:25 --> Output Class Initialized
DEBUG - 2011-04-30 09:39:25 --> Input Class Initialized
DEBUG - 2011-04-30 09:39:25 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-30 09:39:25 --> Language Class Initialized
DEBUG - 2011-04-30 09:39:25 --> Loader Class Initialized
DEBUG - 2011-04-30 09:39:25 --> Controller Class Initialized
ERROR - 2011-04-30 09:39:25 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-04-30 09:39:25 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-04-30 09:39:25 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-04-30 09:39:25 --> Model Class Initialized
DEBUG - 2011-04-30 09:39:25 --> Model Class Initialized
DEBUG - 2011-04-30 09:39:25 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-30 09:39:25 --> Database Driver Class Initialized
DEBUG - 2011-04-30 09:39:25 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-04-30 09:39:25 --> Helper loaded: url_helper
DEBUG - 2011-04-30 09:39:25 --> File loaded: application/views/common/header.php
DEBUG - 2011-04-30 09:39:25 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-04-30 09:39:25 --> File loaded: application/views/common/footer.php
DEBUG - 2011-04-30 09:39:25 --> File loaded: application/views/layout/main.php
DEBUG - 2011-04-30 09:39:25 --> Final output sent to browser
DEBUG - 2011-04-30 09:39:25 --> Total execution time: 0.0296
DEBUG - 2011-04-30 09:51:31 --> Config Class Initialized
DEBUG - 2011-04-30 09:51:31 --> Hooks Class Initialized
DEBUG - 2011-04-30 09:51:31 --> Utf8 Class Initialized
DEBUG - 2011-04-30 09:51:31 --> UTF-8 Support Enabled
DEBUG - 2011-04-30 09:51:31 --> URI Class Initialized
DEBUG - 2011-04-30 09:51:31 --> Router Class Initialized
DEBUG - 2011-04-30 09:51:31 --> Output Class Initialized
DEBUG - 2011-04-30 09:51:31 --> Input Class Initialized
DEBUG - 2011-04-30 09:51:31 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-30 09:51:31 --> Language Class Initialized
DEBUG - 2011-04-30 09:51:31 --> Loader Class Initialized
DEBUG - 2011-04-30 09:51:31 --> Controller Class Initialized
DEBUG - 2011-04-30 09:51:32 --> Model Class Initialized
DEBUG - 2011-04-30 09:51:32 --> Model Class Initialized
DEBUG - 2011-04-30 09:51:32 --> Model Class Initialized
DEBUG - 2011-04-30 09:51:32 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-30 09:51:32 --> Database Driver Class Initialized
DEBUG - 2011-04-30 09:51:33 --> File loaded: application/views/table/main.php
DEBUG - 2011-04-30 09:51:33 --> Helper loaded: url_helper
DEBUG - 2011-04-30 09:51:33 --> File loaded: application/views/common/header.php
DEBUG - 2011-04-30 09:51:33 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-04-30 09:51:33 --> File loaded: application/views/common/footer.php
DEBUG - 2011-04-30 09:51:33 --> File loaded: application/views/layout/main.php
DEBUG - 2011-04-30 09:51:33 --> Final output sent to browser
DEBUG - 2011-04-30 09:51:33 --> Total execution time: 1.7098
DEBUG - 2011-04-30 09:51:41 --> Config Class Initialized
DEBUG - 2011-04-30 09:51:41 --> Hooks Class Initialized
DEBUG - 2011-04-30 09:51:41 --> Utf8 Class Initialized
DEBUG - 2011-04-30 09:51:41 --> UTF-8 Support Enabled
DEBUG - 2011-04-30 09:51:41 --> URI Class Initialized
DEBUG - 2011-04-30 09:51:41 --> Router Class Initialized
ERROR - 2011-04-30 09:51:41 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-04-30 09:51:51 --> Config Class Initialized
DEBUG - 2011-04-30 09:51:51 --> Hooks Class Initialized
DEBUG - 2011-04-30 09:51:51 --> Utf8 Class Initialized
DEBUG - 2011-04-30 09:51:51 --> UTF-8 Support Enabled
DEBUG - 2011-04-30 09:51:51 --> URI Class Initialized
DEBUG - 2011-04-30 09:51:51 --> Router Class Initialized
DEBUG - 2011-04-30 09:51:51 --> Output Class Initialized
DEBUG - 2011-04-30 09:51:51 --> Input Class Initialized
DEBUG - 2011-04-30 09:51:51 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-30 09:51:51 --> Language Class Initialized
DEBUG - 2011-04-30 09:51:51 --> Loader Class Initialized
DEBUG - 2011-04-30 09:51:51 --> Controller Class Initialized
DEBUG - 2011-04-30 09:51:51 --> Model Class Initialized
DEBUG - 2011-04-30 09:51:51 --> Model Class Initialized
DEBUG - 2011-04-30 09:51:51 --> Model Class Initialized
DEBUG - 2011-04-30 09:51:51 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-30 09:51:51 --> Database Driver Class Initialized
DEBUG - 2011-04-30 09:51:51 --> File loaded: application/views/table/main.php
DEBUG - 2011-04-30 09:51:51 --> Helper loaded: url_helper
DEBUG - 2011-04-30 09:51:51 --> File loaded: application/views/common/header.php
DEBUG - 2011-04-30 09:51:51 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-04-30 09:51:51 --> File loaded: application/views/common/footer.php
DEBUG - 2011-04-30 09:51:51 --> File loaded: application/views/layout/main.php
DEBUG - 2011-04-30 09:51:51 --> Final output sent to browser
DEBUG - 2011-04-30 09:51:51 --> Total execution time: 0.8206
DEBUG - 2011-04-30 09:51:57 --> Config Class Initialized
DEBUG - 2011-04-30 09:51:57 --> Hooks Class Initialized
DEBUG - 2011-04-30 09:51:57 --> Utf8 Class Initialized
DEBUG - 2011-04-30 09:51:57 --> UTF-8 Support Enabled
DEBUG - 2011-04-30 09:51:57 --> URI Class Initialized
DEBUG - 2011-04-30 09:51:57 --> Router Class Initialized
DEBUG - 2011-04-30 09:51:57 --> Output Class Initialized
DEBUG - 2011-04-30 09:51:57 --> Input Class Initialized
DEBUG - 2011-04-30 09:51:57 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-30 09:51:57 --> Language Class Initialized
DEBUG - 2011-04-30 09:51:57 --> Loader Class Initialized
DEBUG - 2011-04-30 09:51:57 --> Controller Class Initialized
DEBUG - 2011-04-30 09:51:57 --> Model Class Initialized
DEBUG - 2011-04-30 09:51:57 --> Model Class Initialized
DEBUG - 2011-04-30 09:51:57 --> Model Class Initialized
DEBUG - 2011-04-30 09:51:57 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-30 09:51:57 --> Database Driver Class Initialized
DEBUG - 2011-04-30 09:51:57 --> File loaded: application/views/table/main.php
DEBUG - 2011-04-30 09:51:57 --> Helper loaded: url_helper
DEBUG - 2011-04-30 09:51:57 --> File loaded: application/views/common/header.php
DEBUG - 2011-04-30 09:51:57 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-04-30 09:51:57 --> File loaded: application/views/common/footer.php
DEBUG - 2011-04-30 09:51:57 --> File loaded: application/views/layout/main.php
DEBUG - 2011-04-30 09:51:57 --> Final output sent to browser
DEBUG - 2011-04-30 09:51:57 --> Total execution time: 0.0840
DEBUG - 2011-04-30 09:52:00 --> Config Class Initialized
DEBUG - 2011-04-30 09:52:00 --> Hooks Class Initialized
DEBUG - 2011-04-30 09:52:00 --> Utf8 Class Initialized
DEBUG - 2011-04-30 09:52:00 --> UTF-8 Support Enabled
DEBUG - 2011-04-30 09:52:00 --> URI Class Initialized
DEBUG - 2011-04-30 09:52:00 --> Router Class Initialized
ERROR - 2011-04-30 09:52:00 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-04-30 10:19:15 --> Config Class Initialized
DEBUG - 2011-04-30 10:19:15 --> Hooks Class Initialized
DEBUG - 2011-04-30 10:19:15 --> Utf8 Class Initialized
DEBUG - 2011-04-30 10:19:15 --> UTF-8 Support Enabled
DEBUG - 2011-04-30 10:19:15 --> URI Class Initialized
DEBUG - 2011-04-30 10:19:15 --> Router Class Initialized
ERROR - 2011-04-30 10:19:15 --> 404 Page Not Found --> robots.txt
DEBUG - 2011-04-30 10:19:50 --> Config Class Initialized
DEBUG - 2011-04-30 10:19:50 --> Hooks Class Initialized
DEBUG - 2011-04-30 10:19:50 --> Utf8 Class Initialized
DEBUG - 2011-04-30 10:19:50 --> UTF-8 Support Enabled
DEBUG - 2011-04-30 10:19:50 --> URI Class Initialized
DEBUG - 2011-04-30 10:19:50 --> Router Class Initialized
DEBUG - 2011-04-30 10:19:50 --> Output Class Initialized
DEBUG - 2011-04-30 10:19:50 --> Input Class Initialized
DEBUG - 2011-04-30 10:19:50 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-30 10:19:50 --> Language Class Initialized
DEBUG - 2011-04-30 10:19:50 --> Loader Class Initialized
DEBUG - 2011-04-30 10:19:50 --> Controller Class Initialized
DEBUG - 2011-04-30 10:19:50 --> Model Class Initialized
DEBUG - 2011-04-30 10:19:50 --> Model Class Initialized
DEBUG - 2011-04-30 10:19:50 --> Model Class Initialized
DEBUG - 2011-04-30 10:19:50 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-30 10:19:50 --> Database Driver Class Initialized
DEBUG - 2011-04-30 10:19:51 --> File loaded: application/views/table/main.php
DEBUG - 2011-04-30 10:19:51 --> Helper loaded: url_helper
DEBUG - 2011-04-30 10:19:51 --> File loaded: application/views/common/header.php
DEBUG - 2011-04-30 10:19:51 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-04-30 10:19:51 --> File loaded: application/views/common/footer.php
DEBUG - 2011-04-30 10:19:51 --> File loaded: application/views/layout/main.php
DEBUG - 2011-04-30 10:19:51 --> Final output sent to browser
DEBUG - 2011-04-30 10:19:51 --> Total execution time: 0.5952
DEBUG - 2011-04-30 10:35:09 --> Config Class Initialized
DEBUG - 2011-04-30 10:35:09 --> Hooks Class Initialized
DEBUG - 2011-04-30 10:35:09 --> Utf8 Class Initialized
DEBUG - 2011-04-30 10:35:09 --> UTF-8 Support Enabled
DEBUG - 2011-04-30 10:35:09 --> URI Class Initialized
DEBUG - 2011-04-30 10:35:09 --> Router Class Initialized
DEBUG - 2011-04-30 10:35:09 --> Output Class Initialized
DEBUG - 2011-04-30 10:35:09 --> Input Class Initialized
DEBUG - 2011-04-30 10:35:09 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-30 10:35:09 --> Language Class Initialized
DEBUG - 2011-04-30 10:35:09 --> Loader Class Initialized
DEBUG - 2011-04-30 10:35:09 --> Controller Class Initialized
DEBUG - 2011-04-30 10:35:09 --> Model Class Initialized
DEBUG - 2011-04-30 10:35:09 --> Model Class Initialized
DEBUG - 2011-04-30 10:35:09 --> Model Class Initialized
DEBUG - 2011-04-30 10:35:09 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-30 10:35:09 --> Database Driver Class Initialized
DEBUG - 2011-04-30 10:35:10 --> File loaded: application/views/table/main.php
DEBUG - 2011-04-30 10:35:10 --> Helper loaded: url_helper
DEBUG - 2011-04-30 10:35:10 --> File loaded: application/views/common/header.php
DEBUG - 2011-04-30 10:35:10 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-04-30 10:35:10 --> File loaded: application/views/common/footer.php
DEBUG - 2011-04-30 10:35:10 --> File loaded: application/views/layout/main.php
DEBUG - 2011-04-30 10:35:10 --> Final output sent to browser
DEBUG - 2011-04-30 10:35:10 --> Total execution time: 1.6303
DEBUG - 2011-04-30 10:58:47 --> Config Class Initialized
DEBUG - 2011-04-30 10:58:47 --> Hooks Class Initialized
DEBUG - 2011-04-30 10:58:47 --> Utf8 Class Initialized
DEBUG - 2011-04-30 10:58:47 --> UTF-8 Support Enabled
DEBUG - 2011-04-30 10:58:47 --> URI Class Initialized
DEBUG - 2011-04-30 10:58:47 --> Router Class Initialized
DEBUG - 2011-04-30 10:58:47 --> Output Class Initialized
DEBUG - 2011-04-30 10:58:47 --> Input Class Initialized
DEBUG - 2011-04-30 10:58:47 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-30 10:58:47 --> Language Class Initialized
DEBUG - 2011-04-30 10:58:47 --> Loader Class Initialized
DEBUG - 2011-04-30 10:58:47 --> Controller Class Initialized
ERROR - 2011-04-30 10:58:47 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-04-30 10:58:47 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-04-30 10:58:47 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-04-30 10:58:47 --> Model Class Initialized
DEBUG - 2011-04-30 10:58:47 --> Model Class Initialized
DEBUG - 2011-04-30 10:58:47 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-30 10:58:47 --> Database Driver Class Initialized
DEBUG - 2011-04-30 10:58:47 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-04-30 10:58:47 --> Helper loaded: url_helper
DEBUG - 2011-04-30 10:58:47 --> File loaded: application/views/common/header.php
DEBUG - 2011-04-30 10:58:47 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-04-30 10:58:47 --> File loaded: application/views/common/footer.php
DEBUG - 2011-04-30 10:58:47 --> File loaded: application/views/layout/main.php
DEBUG - 2011-04-30 10:58:47 --> Final output sent to browser
DEBUG - 2011-04-30 10:58:47 --> Total execution time: 0.2536
DEBUG - 2011-04-30 10:58:49 --> Config Class Initialized
DEBUG - 2011-04-30 10:58:49 --> Hooks Class Initialized
DEBUG - 2011-04-30 10:58:49 --> Utf8 Class Initialized
DEBUG - 2011-04-30 10:58:49 --> UTF-8 Support Enabled
DEBUG - 2011-04-30 10:58:49 --> URI Class Initialized
DEBUG - 2011-04-30 10:58:49 --> Router Class Initialized
DEBUG - 2011-04-30 10:58:49 --> Output Class Initialized
DEBUG - 2011-04-30 10:58:49 --> Input Class Initialized
DEBUG - 2011-04-30 10:58:49 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-30 10:58:49 --> Language Class Initialized
DEBUG - 2011-04-30 10:58:49 --> Loader Class Initialized
DEBUG - 2011-04-30 10:58:49 --> Controller Class Initialized
DEBUG - 2011-04-30 10:58:49 --> Model Class Initialized
DEBUG - 2011-04-30 10:58:49 --> Model Class Initialized
DEBUG - 2011-04-30 10:58:49 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-30 10:58:49 --> Database Driver Class Initialized
DEBUG - 2011-04-30 10:58:50 --> Final output sent to browser
DEBUG - 2011-04-30 10:58:50 --> Total execution time: 0.7731
DEBUG - 2011-04-30 11:08:51 --> Config Class Initialized
DEBUG - 2011-04-30 11:08:51 --> Hooks Class Initialized
DEBUG - 2011-04-30 11:08:51 --> Utf8 Class Initialized
DEBUG - 2011-04-30 11:08:51 --> UTF-8 Support Enabled
DEBUG - 2011-04-30 11:08:51 --> URI Class Initialized
DEBUG - 2011-04-30 11:08:51 --> Router Class Initialized
DEBUG - 2011-04-30 11:08:51 --> Output Class Initialized
DEBUG - 2011-04-30 11:08:51 --> Input Class Initialized
DEBUG - 2011-04-30 11:08:51 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-30 11:08:51 --> Language Class Initialized
DEBUG - 2011-04-30 11:08:51 --> Loader Class Initialized
DEBUG - 2011-04-30 11:08:51 --> Controller Class Initialized
ERROR - 2011-04-30 11:08:51 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-04-30 11:08:51 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-04-30 11:08:51 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-04-30 11:08:51 --> Model Class Initialized
DEBUG - 2011-04-30 11:08:51 --> Model Class Initialized
DEBUG - 2011-04-30 11:08:51 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-30 11:08:51 --> Database Driver Class Initialized
DEBUG - 2011-04-30 11:08:51 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-04-30 11:08:51 --> Helper loaded: url_helper
DEBUG - 2011-04-30 11:08:51 --> File loaded: application/views/common/header.php
DEBUG - 2011-04-30 11:08:51 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-04-30 11:08:51 --> File loaded: application/views/common/footer.php
DEBUG - 2011-04-30 11:08:51 --> File loaded: application/views/layout/main.php
DEBUG - 2011-04-30 11:08:51 --> Final output sent to browser
DEBUG - 2011-04-30 11:08:51 --> Total execution time: 0.0875
DEBUG - 2011-04-30 11:08:52 --> Config Class Initialized
DEBUG - 2011-04-30 11:08:52 --> Hooks Class Initialized
DEBUG - 2011-04-30 11:08:52 --> Utf8 Class Initialized
DEBUG - 2011-04-30 11:08:52 --> UTF-8 Support Enabled
DEBUG - 2011-04-30 11:08:52 --> URI Class Initialized
DEBUG - 2011-04-30 11:08:52 --> Router Class Initialized
DEBUG - 2011-04-30 11:08:52 --> Output Class Initialized
DEBUG - 2011-04-30 11:08:52 --> Input Class Initialized
DEBUG - 2011-04-30 11:08:52 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-30 11:08:52 --> Language Class Initialized
DEBUG - 2011-04-30 11:08:52 --> Loader Class Initialized
DEBUG - 2011-04-30 11:08:52 --> Controller Class Initialized
DEBUG - 2011-04-30 11:08:52 --> Model Class Initialized
DEBUG - 2011-04-30 11:08:52 --> Model Class Initialized
DEBUG - 2011-04-30 11:08:52 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-30 11:08:52 --> Database Driver Class Initialized
DEBUG - 2011-04-30 11:08:53 --> Final output sent to browser
DEBUG - 2011-04-30 11:08:53 --> Total execution time: 0.6566
DEBUG - 2011-04-30 11:09:37 --> Config Class Initialized
DEBUG - 2011-04-30 11:09:37 --> Hooks Class Initialized
DEBUG - 2011-04-30 11:09:37 --> Utf8 Class Initialized
DEBUG - 2011-04-30 11:09:37 --> UTF-8 Support Enabled
DEBUG - 2011-04-30 11:09:37 --> URI Class Initialized
DEBUG - 2011-04-30 11:09:37 --> Router Class Initialized
DEBUG - 2011-04-30 11:09:37 --> Output Class Initialized
DEBUG - 2011-04-30 11:09:37 --> Input Class Initialized
DEBUG - 2011-04-30 11:09:37 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-30 11:09:37 --> Language Class Initialized
DEBUG - 2011-04-30 11:09:37 --> Loader Class Initialized
DEBUG - 2011-04-30 11:09:37 --> Controller Class Initialized
ERROR - 2011-04-30 11:09:37 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-04-30 11:09:37 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-04-30 11:09:37 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-04-30 11:09:37 --> Model Class Initialized
DEBUG - 2011-04-30 11:09:37 --> Model Class Initialized
DEBUG - 2011-04-30 11:09:37 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-30 11:09:37 --> Database Driver Class Initialized
DEBUG - 2011-04-30 11:09:37 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-04-30 11:09:37 --> Helper loaded: url_helper
DEBUG - 2011-04-30 11:09:37 --> File loaded: application/views/common/header.php
DEBUG - 2011-04-30 11:09:37 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-04-30 11:09:37 --> File loaded: application/views/common/footer.php
DEBUG - 2011-04-30 11:09:37 --> File loaded: application/views/layout/main.php
DEBUG - 2011-04-30 11:09:37 --> Final output sent to browser
DEBUG - 2011-04-30 11:09:37 --> Total execution time: 0.0370
DEBUG - 2011-04-30 11:09:38 --> Config Class Initialized
DEBUG - 2011-04-30 11:09:38 --> Hooks Class Initialized
DEBUG - 2011-04-30 11:09:38 --> Utf8 Class Initialized
DEBUG - 2011-04-30 11:09:38 --> UTF-8 Support Enabled
DEBUG - 2011-04-30 11:09:38 --> URI Class Initialized
DEBUG - 2011-04-30 11:09:38 --> Router Class Initialized
DEBUG - 2011-04-30 11:09:38 --> Output Class Initialized
DEBUG - 2011-04-30 11:09:38 --> Input Class Initialized
DEBUG - 2011-04-30 11:09:38 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-30 11:09:38 --> Language Class Initialized
DEBUG - 2011-04-30 11:09:38 --> Loader Class Initialized
DEBUG - 2011-04-30 11:09:38 --> Controller Class Initialized
DEBUG - 2011-04-30 11:09:38 --> Model Class Initialized
DEBUG - 2011-04-30 11:09:38 --> Model Class Initialized
DEBUG - 2011-04-30 11:09:38 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-30 11:09:38 --> Database Driver Class Initialized
DEBUG - 2011-04-30 11:09:39 --> Final output sent to browser
DEBUG - 2011-04-30 11:09:39 --> Total execution time: 0.7136
DEBUG - 2011-04-30 11:09:39 --> Config Class Initialized
DEBUG - 2011-04-30 11:09:39 --> Hooks Class Initialized
DEBUG - 2011-04-30 11:09:39 --> Utf8 Class Initialized
DEBUG - 2011-04-30 11:09:39 --> UTF-8 Support Enabled
DEBUG - 2011-04-30 11:09:39 --> URI Class Initialized
DEBUG - 2011-04-30 11:09:39 --> Router Class Initialized
DEBUG - 2011-04-30 11:09:39 --> Output Class Initialized
DEBUG - 2011-04-30 11:09:39 --> Input Class Initialized
DEBUG - 2011-04-30 11:09:39 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-30 11:09:39 --> Language Class Initialized
DEBUG - 2011-04-30 11:09:39 --> Loader Class Initialized
DEBUG - 2011-04-30 11:09:39 --> Controller Class Initialized
ERROR - 2011-04-30 11:09:39 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-04-30 11:09:39 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-04-30 11:09:39 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-04-30 11:09:39 --> Model Class Initialized
DEBUG - 2011-04-30 11:09:39 --> Model Class Initialized
DEBUG - 2011-04-30 11:09:39 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-30 11:09:39 --> Database Driver Class Initialized
DEBUG - 2011-04-30 11:09:39 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-04-30 11:09:39 --> Helper loaded: url_helper
DEBUG - 2011-04-30 11:09:39 --> File loaded: application/views/common/header.php
DEBUG - 2011-04-30 11:09:39 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-04-30 11:09:39 --> File loaded: application/views/common/footer.php
DEBUG - 2011-04-30 11:09:39 --> File loaded: application/views/layout/main.php
DEBUG - 2011-04-30 11:09:39 --> Final output sent to browser
DEBUG - 2011-04-30 11:09:39 --> Total execution time: 0.0579
DEBUG - 2011-04-30 12:36:36 --> Config Class Initialized
DEBUG - 2011-04-30 12:36:36 --> Hooks Class Initialized
DEBUG - 2011-04-30 12:36:36 --> Utf8 Class Initialized
DEBUG - 2011-04-30 12:36:36 --> UTF-8 Support Enabled
DEBUG - 2011-04-30 12:36:36 --> URI Class Initialized
DEBUG - 2011-04-30 12:36:36 --> Router Class Initialized
DEBUG - 2011-04-30 12:36:36 --> Output Class Initialized
DEBUG - 2011-04-30 12:36:36 --> Input Class Initialized
DEBUG - 2011-04-30 12:36:36 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-30 12:36:36 --> Language Class Initialized
DEBUG - 2011-04-30 12:36:36 --> Loader Class Initialized
DEBUG - 2011-04-30 12:36:36 --> Controller Class Initialized
DEBUG - 2011-04-30 12:36:36 --> Model Class Initialized
DEBUG - 2011-04-30 12:36:36 --> Model Class Initialized
DEBUG - 2011-04-30 12:36:36 --> Model Class Initialized
DEBUG - 2011-04-30 12:36:36 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-30 12:36:36 --> Database Driver Class Initialized
DEBUG - 2011-04-30 12:36:36 --> File loaded: application/views/table/main.php
DEBUG - 2011-04-30 12:36:36 --> Helper loaded: url_helper
DEBUG - 2011-04-30 12:36:36 --> File loaded: application/views/common/header.php
DEBUG - 2011-04-30 12:36:36 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-04-30 12:36:36 --> File loaded: application/views/common/footer.php
DEBUG - 2011-04-30 12:36:36 --> File loaded: application/views/layout/main.php
DEBUG - 2011-04-30 12:36:36 --> Final output sent to browser
DEBUG - 2011-04-30 12:36:36 --> Total execution time: 0.5826
DEBUG - 2011-04-30 12:36:37 --> Config Class Initialized
DEBUG - 2011-04-30 12:36:37 --> Hooks Class Initialized
DEBUG - 2011-04-30 12:36:37 --> Utf8 Class Initialized
DEBUG - 2011-04-30 12:36:37 --> UTF-8 Support Enabled
DEBUG - 2011-04-30 12:36:37 --> URI Class Initialized
DEBUG - 2011-04-30 12:36:37 --> Router Class Initialized
DEBUG - 2011-04-30 12:36:37 --> Output Class Initialized
DEBUG - 2011-04-30 12:36:37 --> Input Class Initialized
DEBUG - 2011-04-30 12:36:37 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-30 12:36:37 --> Language Class Initialized
DEBUG - 2011-04-30 12:36:37 --> Loader Class Initialized
DEBUG - 2011-04-30 12:36:37 --> Controller Class Initialized
ERROR - 2011-04-30 12:36:37 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-04-30 12:36:37 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-04-30 12:36:37 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-04-30 12:36:37 --> Model Class Initialized
DEBUG - 2011-04-30 12:36:37 --> Model Class Initialized
DEBUG - 2011-04-30 12:36:37 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-30 12:36:37 --> Database Driver Class Initialized
DEBUG - 2011-04-30 12:36:37 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-04-30 12:36:37 --> Helper loaded: url_helper
DEBUG - 2011-04-30 12:36:37 --> File loaded: application/views/common/header.php
DEBUG - 2011-04-30 12:36:37 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-04-30 12:36:37 --> File loaded: application/views/common/footer.php
DEBUG - 2011-04-30 12:36:37 --> File loaded: application/views/layout/main.php
DEBUG - 2011-04-30 12:36:37 --> Final output sent to browser
DEBUG - 2011-04-30 12:36:37 --> Total execution time: 0.0959
DEBUG - 2011-04-30 13:04:57 --> Config Class Initialized
DEBUG - 2011-04-30 13:04:57 --> Hooks Class Initialized
DEBUG - 2011-04-30 13:04:57 --> Utf8 Class Initialized
DEBUG - 2011-04-30 13:04:57 --> UTF-8 Support Enabled
DEBUG - 2011-04-30 13:04:57 --> URI Class Initialized
DEBUG - 2011-04-30 13:04:57 --> Router Class Initialized
DEBUG - 2011-04-30 13:04:57 --> Output Class Initialized
DEBUG - 2011-04-30 13:04:57 --> Input Class Initialized
DEBUG - 2011-04-30 13:04:57 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-30 13:04:57 --> Language Class Initialized
DEBUG - 2011-04-30 13:04:57 --> Loader Class Initialized
DEBUG - 2011-04-30 13:04:57 --> Controller Class Initialized
ERROR - 2011-04-30 13:04:57 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-04-30 13:04:57 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-04-30 13:04:57 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-04-30 13:04:57 --> Model Class Initialized
DEBUG - 2011-04-30 13:04:57 --> Model Class Initialized
DEBUG - 2011-04-30 13:04:57 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-30 13:04:57 --> Database Driver Class Initialized
DEBUG - 2011-04-30 13:04:57 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-04-30 13:04:57 --> Helper loaded: url_helper
DEBUG - 2011-04-30 13:04:57 --> File loaded: application/views/common/header.php
DEBUG - 2011-04-30 13:04:57 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-04-30 13:04:57 --> File loaded: application/views/common/footer.php
DEBUG - 2011-04-30 13:04:57 --> File loaded: application/views/layout/main.php
DEBUG - 2011-04-30 13:04:57 --> Final output sent to browser
DEBUG - 2011-04-30 13:04:57 --> Total execution time: 0.0540
DEBUG - 2011-04-30 13:04:58 --> Config Class Initialized
DEBUG - 2011-04-30 13:04:58 --> Hooks Class Initialized
DEBUG - 2011-04-30 13:04:58 --> Utf8 Class Initialized
DEBUG - 2011-04-30 13:04:58 --> UTF-8 Support Enabled
DEBUG - 2011-04-30 13:04:58 --> URI Class Initialized
DEBUG - 2011-04-30 13:04:58 --> Router Class Initialized
DEBUG - 2011-04-30 13:04:58 --> Output Class Initialized
DEBUG - 2011-04-30 13:04:58 --> Input Class Initialized
DEBUG - 2011-04-30 13:04:58 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-30 13:04:58 --> Language Class Initialized
DEBUG - 2011-04-30 13:04:58 --> Loader Class Initialized
DEBUG - 2011-04-30 13:04:58 --> Controller Class Initialized
DEBUG - 2011-04-30 13:04:58 --> Model Class Initialized
DEBUG - 2011-04-30 13:04:58 --> Model Class Initialized
DEBUG - 2011-04-30 13:04:58 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-30 13:04:58 --> Database Driver Class Initialized
DEBUG - 2011-04-30 13:04:58 --> Final output sent to browser
DEBUG - 2011-04-30 13:04:58 --> Total execution time: 0.6637
DEBUG - 2011-04-30 13:20:25 --> Config Class Initialized
DEBUG - 2011-04-30 13:20:25 --> Hooks Class Initialized
DEBUG - 2011-04-30 13:20:25 --> Utf8 Class Initialized
DEBUG - 2011-04-30 13:20:25 --> UTF-8 Support Enabled
DEBUG - 2011-04-30 13:20:25 --> URI Class Initialized
DEBUG - 2011-04-30 13:20:25 --> Router Class Initialized
DEBUG - 2011-04-30 13:20:25 --> No URI present. Default controller set.
DEBUG - 2011-04-30 13:20:25 --> Output Class Initialized
DEBUG - 2011-04-30 13:20:25 --> Input Class Initialized
DEBUG - 2011-04-30 13:20:25 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-30 13:20:25 --> Language Class Initialized
DEBUG - 2011-04-30 13:20:25 --> Loader Class Initialized
DEBUG - 2011-04-30 13:20:25 --> Controller Class Initialized
DEBUG - 2011-04-30 13:20:25 --> File loaded: application/views/splash/main.php
DEBUG - 2011-04-30 13:20:25 --> Helper loaded: url_helper
DEBUG - 2011-04-30 13:20:25 --> File loaded: application/views/common/header.php
DEBUG - 2011-04-30 13:20:25 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-04-30 13:20:25 --> File loaded: application/views/common/footer.php
DEBUG - 2011-04-30 13:20:25 --> File loaded: application/views/layout/main.php
DEBUG - 2011-04-30 13:20:25 --> Final output sent to browser
DEBUG - 2011-04-30 13:20:25 --> Total execution time: 0.1540
DEBUG - 2011-04-30 13:20:28 --> Config Class Initialized
DEBUG - 2011-04-30 13:20:28 --> Hooks Class Initialized
DEBUG - 2011-04-30 13:20:28 --> Utf8 Class Initialized
DEBUG - 2011-04-30 13:20:28 --> UTF-8 Support Enabled
DEBUG - 2011-04-30 13:20:28 --> URI Class Initialized
DEBUG - 2011-04-30 13:20:28 --> Router Class Initialized
ERROR - 2011-04-30 13:20:28 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-04-30 13:20:29 --> Config Class Initialized
DEBUG - 2011-04-30 13:20:29 --> Hooks Class Initialized
DEBUG - 2011-04-30 13:20:29 --> Utf8 Class Initialized
DEBUG - 2011-04-30 13:20:29 --> UTF-8 Support Enabled
DEBUG - 2011-04-30 13:20:29 --> URI Class Initialized
DEBUG - 2011-04-30 13:20:29 --> Router Class Initialized
ERROR - 2011-04-30 13:20:29 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-04-30 13:20:30 --> Config Class Initialized
DEBUG - 2011-04-30 13:20:30 --> Hooks Class Initialized
DEBUG - 2011-04-30 13:20:30 --> Utf8 Class Initialized
DEBUG - 2011-04-30 13:20:30 --> UTF-8 Support Enabled
DEBUG - 2011-04-30 13:20:30 --> URI Class Initialized
DEBUG - 2011-04-30 13:20:30 --> Router Class Initialized
DEBUG - 2011-04-30 13:20:30 --> Output Class Initialized
DEBUG - 2011-04-30 13:20:30 --> Input Class Initialized
DEBUG - 2011-04-30 13:20:30 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-30 13:20:30 --> Language Class Initialized
DEBUG - 2011-04-30 13:20:30 --> Loader Class Initialized
DEBUG - 2011-04-30 13:20:30 --> Controller Class Initialized
DEBUG - 2011-04-30 13:20:30 --> Model Class Initialized
DEBUG - 2011-04-30 13:20:30 --> Model Class Initialized
DEBUG - 2011-04-30 13:20:30 --> Model Class Initialized
DEBUG - 2011-04-30 13:20:30 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-30 13:20:30 --> Database Driver Class Initialized
DEBUG - 2011-04-30 13:20:31 --> File loaded: application/views/table/main.php
DEBUG - 2011-04-30 13:20:31 --> Helper loaded: url_helper
DEBUG - 2011-04-30 13:20:31 --> File loaded: application/views/common/header.php
DEBUG - 2011-04-30 13:20:31 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-04-30 13:20:31 --> File loaded: application/views/common/footer.php
DEBUG - 2011-04-30 13:20:31 --> File loaded: application/views/layout/main.php
DEBUG - 2011-04-30 13:20:31 --> Final output sent to browser
DEBUG - 2011-04-30 13:20:31 --> Total execution time: 0.2845
DEBUG - 2011-04-30 13:20:33 --> Config Class Initialized
DEBUG - 2011-04-30 13:20:33 --> Hooks Class Initialized
DEBUG - 2011-04-30 13:20:33 --> Utf8 Class Initialized
DEBUG - 2011-04-30 13:20:33 --> UTF-8 Support Enabled
DEBUG - 2011-04-30 13:20:33 --> URI Class Initialized
DEBUG - 2011-04-30 13:20:33 --> Router Class Initialized
ERROR - 2011-04-30 13:20:33 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-04-30 13:21:01 --> Config Class Initialized
DEBUG - 2011-04-30 13:21:01 --> Hooks Class Initialized
DEBUG - 2011-04-30 13:21:01 --> Utf8 Class Initialized
DEBUG - 2011-04-30 13:21:01 --> UTF-8 Support Enabled
DEBUG - 2011-04-30 13:21:01 --> URI Class Initialized
DEBUG - 2011-04-30 13:21:01 --> Router Class Initialized
DEBUG - 2011-04-30 13:21:01 --> Output Class Initialized
DEBUG - 2011-04-30 13:21:01 --> Input Class Initialized
DEBUG - 2011-04-30 13:21:01 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-30 13:21:01 --> Language Class Initialized
DEBUG - 2011-04-30 13:21:01 --> Loader Class Initialized
DEBUG - 2011-04-30 13:21:01 --> Controller Class Initialized
DEBUG - 2011-04-30 13:21:01 --> Model Class Initialized
DEBUG - 2011-04-30 13:21:01 --> Model Class Initialized
DEBUG - 2011-04-30 13:21:01 --> Model Class Initialized
DEBUG - 2011-04-30 13:21:01 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-30 13:21:01 --> Database Driver Class Initialized
DEBUG - 2011-04-30 13:21:01 --> File loaded: application/views/table/main.php
DEBUG - 2011-04-30 13:21:01 --> Helper loaded: url_helper
DEBUG - 2011-04-30 13:21:01 --> File loaded: application/views/common/header.php
DEBUG - 2011-04-30 13:21:01 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-04-30 13:21:01 --> File loaded: application/views/common/footer.php
DEBUG - 2011-04-30 13:21:01 --> File loaded: application/views/layout/main.php
DEBUG - 2011-04-30 13:21:01 --> Final output sent to browser
DEBUG - 2011-04-30 13:21:01 --> Total execution time: 0.0614
DEBUG - 2011-04-30 13:21:03 --> Config Class Initialized
DEBUG - 2011-04-30 13:21:03 --> Hooks Class Initialized
DEBUG - 2011-04-30 13:21:03 --> Utf8 Class Initialized
DEBUG - 2011-04-30 13:21:03 --> UTF-8 Support Enabled
DEBUG - 2011-04-30 13:21:03 --> URI Class Initialized
DEBUG - 2011-04-30 13:21:03 --> Router Class Initialized
ERROR - 2011-04-30 13:21:03 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-04-30 13:21:05 --> Config Class Initialized
DEBUG - 2011-04-30 13:21:05 --> Hooks Class Initialized
DEBUG - 2011-04-30 13:21:05 --> Utf8 Class Initialized
DEBUG - 2011-04-30 13:21:05 --> UTF-8 Support Enabled
DEBUG - 2011-04-30 13:21:05 --> URI Class Initialized
DEBUG - 2011-04-30 13:21:05 --> Router Class Initialized
ERROR - 2011-04-30 13:21:05 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-04-30 13:21:18 --> Config Class Initialized
DEBUG - 2011-04-30 13:21:18 --> Hooks Class Initialized
DEBUG - 2011-04-30 13:21:18 --> Utf8 Class Initialized
DEBUG - 2011-04-30 13:21:18 --> UTF-8 Support Enabled
DEBUG - 2011-04-30 13:21:18 --> URI Class Initialized
DEBUG - 2011-04-30 13:21:18 --> Router Class Initialized
DEBUG - 2011-04-30 13:21:18 --> Output Class Initialized
DEBUG - 2011-04-30 13:21:18 --> Input Class Initialized
DEBUG - 2011-04-30 13:21:18 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-30 13:21:18 --> Language Class Initialized
DEBUG - 2011-04-30 13:21:18 --> Loader Class Initialized
DEBUG - 2011-04-30 13:21:18 --> Controller Class Initialized
DEBUG - 2011-04-30 13:21:18 --> Model Class Initialized
DEBUG - 2011-04-30 13:21:18 --> Model Class Initialized
DEBUG - 2011-04-30 13:21:18 --> Model Class Initialized
DEBUG - 2011-04-30 13:21:18 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-30 13:21:18 --> Database Driver Class Initialized
DEBUG - 2011-04-30 13:21:18 --> File loaded: application/views/table/main.php
DEBUG - 2011-04-30 13:21:18 --> Helper loaded: url_helper
DEBUG - 2011-04-30 13:21:18 --> File loaded: application/views/common/header.php
DEBUG - 2011-04-30 13:21:18 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-04-30 13:21:18 --> File loaded: application/views/common/footer.php
DEBUG - 2011-04-30 13:21:18 --> File loaded: application/views/layout/main.php
DEBUG - 2011-04-30 13:21:18 --> Final output sent to browser
DEBUG - 2011-04-30 13:21:18 --> Total execution time: 0.1790
DEBUG - 2011-04-30 13:21:21 --> Config Class Initialized
DEBUG - 2011-04-30 13:21:21 --> Hooks Class Initialized
DEBUG - 2011-04-30 13:21:21 --> Utf8 Class Initialized
DEBUG - 2011-04-30 13:21:21 --> UTF-8 Support Enabled
DEBUG - 2011-04-30 13:21:21 --> URI Class Initialized
DEBUG - 2011-04-30 13:21:21 --> Router Class Initialized
ERROR - 2011-04-30 13:21:21 --> 404 Page Not Found --> robots.txt
DEBUG - 2011-04-30 13:21:22 --> Config Class Initialized
DEBUG - 2011-04-30 13:21:22 --> Hooks Class Initialized
DEBUG - 2011-04-30 13:21:22 --> Utf8 Class Initialized
DEBUG - 2011-04-30 13:21:22 --> UTF-8 Support Enabled
DEBUG - 2011-04-30 13:21:22 --> URI Class Initialized
DEBUG - 2011-04-30 13:21:22 --> Router Class Initialized
DEBUG - 2011-04-30 13:21:22 --> Output Class Initialized
DEBUG - 2011-04-30 13:21:22 --> Input Class Initialized
DEBUG - 2011-04-30 13:21:22 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-30 13:21:22 --> Language Class Initialized
DEBUG - 2011-04-30 13:21:22 --> Loader Class Initialized
DEBUG - 2011-04-30 13:21:22 --> Controller Class Initialized
DEBUG - 2011-04-30 13:21:22 --> Model Class Initialized
DEBUG - 2011-04-30 13:21:22 --> Model Class Initialized
DEBUG - 2011-04-30 13:21:22 --> Model Class Initialized
DEBUG - 2011-04-30 13:21:22 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-30 13:21:22 --> Database Driver Class Initialized
DEBUG - 2011-04-30 13:21:22 --> File loaded: application/views/table/main.php
DEBUG - 2011-04-30 13:21:22 --> Helper loaded: url_helper
DEBUG - 2011-04-30 13:21:22 --> File loaded: application/views/common/header.php
DEBUG - 2011-04-30 13:21:22 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-04-30 13:21:22 --> File loaded: application/views/common/footer.php
DEBUG - 2011-04-30 13:21:22 --> File loaded: application/views/layout/main.php
DEBUG - 2011-04-30 13:21:22 --> Final output sent to browser
DEBUG - 2011-04-30 13:21:22 --> Total execution time: 0.0465
DEBUG - 2011-04-30 13:21:28 --> Config Class Initialized
DEBUG - 2011-04-30 13:21:28 --> Hooks Class Initialized
DEBUG - 2011-04-30 13:21:28 --> Utf8 Class Initialized
DEBUG - 2011-04-30 13:21:28 --> UTF-8 Support Enabled
DEBUG - 2011-04-30 13:21:28 --> URI Class Initialized
DEBUG - 2011-04-30 13:21:28 --> Router Class Initialized
DEBUG - 2011-04-30 13:21:28 --> Output Class Initialized
DEBUG - 2011-04-30 13:21:28 --> Input Class Initialized
DEBUG - 2011-04-30 13:21:28 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-30 13:21:28 --> Language Class Initialized
DEBUG - 2011-04-30 13:21:28 --> Loader Class Initialized
DEBUG - 2011-04-30 13:21:28 --> Controller Class Initialized
DEBUG - 2011-04-30 13:21:28 --> Model Class Initialized
DEBUG - 2011-04-30 13:21:28 --> Model Class Initialized
DEBUG - 2011-04-30 13:21:28 --> Model Class Initialized
DEBUG - 2011-04-30 13:21:28 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-30 13:21:28 --> Database Driver Class Initialized
DEBUG - 2011-04-30 13:21:28 --> File loaded: application/views/table/main.php
DEBUG - 2011-04-30 13:21:28 --> Helper loaded: url_helper
DEBUG - 2011-04-30 13:21:28 --> File loaded: application/views/common/header.php
DEBUG - 2011-04-30 13:21:28 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-04-30 13:21:28 --> File loaded: application/views/common/footer.php
DEBUG - 2011-04-30 13:21:28 --> File loaded: application/views/layout/main.php
DEBUG - 2011-04-30 13:21:28 --> Final output sent to browser
DEBUG - 2011-04-30 13:21:28 --> Total execution time: 0.2387
DEBUG - 2011-04-30 13:21:29 --> Config Class Initialized
DEBUG - 2011-04-30 13:21:29 --> Hooks Class Initialized
DEBUG - 2011-04-30 13:21:29 --> Utf8 Class Initialized
DEBUG - 2011-04-30 13:21:29 --> UTF-8 Support Enabled
DEBUG - 2011-04-30 13:21:29 --> URI Class Initialized
DEBUG - 2011-04-30 13:21:29 --> Router Class Initialized
DEBUG - 2011-04-30 13:21:29 --> Output Class Initialized
DEBUG - 2011-04-30 13:21:29 --> Input Class Initialized
DEBUG - 2011-04-30 13:21:29 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-30 13:21:29 --> Language Class Initialized
DEBUG - 2011-04-30 13:21:29 --> Loader Class Initialized
DEBUG - 2011-04-30 13:21:29 --> Controller Class Initialized
DEBUG - 2011-04-30 13:21:29 --> Model Class Initialized
DEBUG - 2011-04-30 13:21:29 --> Model Class Initialized
DEBUG - 2011-04-30 13:21:29 --> Model Class Initialized
DEBUG - 2011-04-30 13:21:29 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-30 13:21:29 --> Database Driver Class Initialized
DEBUG - 2011-04-30 13:21:29 --> File loaded: application/views/table/main.php
DEBUG - 2011-04-30 13:21:29 --> Helper loaded: url_helper
DEBUG - 2011-04-30 13:21:29 --> File loaded: application/views/common/header.php
DEBUG - 2011-04-30 13:21:29 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-04-30 13:21:29 --> File loaded: application/views/common/footer.php
DEBUG - 2011-04-30 13:21:29 --> File loaded: application/views/layout/main.php
DEBUG - 2011-04-30 13:21:29 --> Final output sent to browser
DEBUG - 2011-04-30 13:21:29 --> Total execution time: 0.0519
DEBUG - 2011-04-30 13:21:30 --> Config Class Initialized
DEBUG - 2011-04-30 13:21:30 --> Hooks Class Initialized
DEBUG - 2011-04-30 13:21:30 --> Utf8 Class Initialized
DEBUG - 2011-04-30 13:21:30 --> UTF-8 Support Enabled
DEBUG - 2011-04-30 13:21:30 --> URI Class Initialized
DEBUG - 2011-04-30 13:21:30 --> Router Class Initialized
ERROR - 2011-04-30 13:21:30 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-04-30 13:21:31 --> Config Class Initialized
DEBUG - 2011-04-30 13:21:31 --> Hooks Class Initialized
DEBUG - 2011-04-30 13:21:31 --> Utf8 Class Initialized
DEBUG - 2011-04-30 13:21:31 --> UTF-8 Support Enabled
DEBUG - 2011-04-30 13:21:31 --> URI Class Initialized
DEBUG - 2011-04-30 13:21:31 --> Router Class Initialized
DEBUG - 2011-04-30 13:21:31 --> Output Class Initialized
DEBUG - 2011-04-30 13:21:31 --> Input Class Initialized
DEBUG - 2011-04-30 13:21:31 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-30 13:21:31 --> Language Class Initialized
DEBUG - 2011-04-30 13:21:31 --> Loader Class Initialized
DEBUG - 2011-04-30 13:21:31 --> Controller Class Initialized
DEBUG - 2011-04-30 13:21:31 --> Model Class Initialized
DEBUG - 2011-04-30 13:21:31 --> Model Class Initialized
DEBUG - 2011-04-30 13:21:31 --> Model Class Initialized
DEBUG - 2011-04-30 13:21:31 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-30 13:21:31 --> Database Driver Class Initialized
DEBUG - 2011-04-30 13:21:31 --> File loaded: application/views/table/main.php
DEBUG - 2011-04-30 13:21:31 --> Helper loaded: url_helper
DEBUG - 2011-04-30 13:21:31 --> File loaded: application/views/common/header.php
DEBUG - 2011-04-30 13:21:31 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-04-30 13:21:31 --> File loaded: application/views/common/footer.php
DEBUG - 2011-04-30 13:21:31 --> File loaded: application/views/layout/main.php
DEBUG - 2011-04-30 13:21:31 --> Final output sent to browser
DEBUG - 2011-04-30 13:21:31 --> Total execution time: 0.1144
DEBUG - 2011-04-30 13:21:37 --> Config Class Initialized
DEBUG - 2011-04-30 13:21:37 --> Hooks Class Initialized
DEBUG - 2011-04-30 13:21:37 --> Utf8 Class Initialized
DEBUG - 2011-04-30 13:21:37 --> UTF-8 Support Enabled
DEBUG - 2011-04-30 13:21:37 --> URI Class Initialized
DEBUG - 2011-04-30 13:21:37 --> Router Class Initialized
DEBUG - 2011-04-30 13:21:37 --> Output Class Initialized
DEBUG - 2011-04-30 13:21:37 --> Input Class Initialized
DEBUG - 2011-04-30 13:21:37 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-30 13:21:37 --> Language Class Initialized
DEBUG - 2011-04-30 13:21:37 --> Loader Class Initialized
DEBUG - 2011-04-30 13:21:37 --> Controller Class Initialized
DEBUG - 2011-04-30 13:21:37 --> Model Class Initialized
DEBUG - 2011-04-30 13:21:37 --> Model Class Initialized
DEBUG - 2011-04-30 13:21:37 --> Model Class Initialized
DEBUG - 2011-04-30 13:21:37 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-30 13:21:37 --> Database Driver Class Initialized
DEBUG - 2011-04-30 13:21:39 --> File loaded: application/views/table/main.php
DEBUG - 2011-04-30 13:21:39 --> Helper loaded: url_helper
DEBUG - 2011-04-30 13:21:39 --> File loaded: application/views/common/header.php
DEBUG - 2011-04-30 13:21:39 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-04-30 13:21:39 --> File loaded: application/views/common/footer.php
DEBUG - 2011-04-30 13:21:39 --> File loaded: application/views/layout/main.php
DEBUG - 2011-04-30 13:21:39 --> Final output sent to browser
DEBUG - 2011-04-30 13:21:39 --> Total execution time: 1.7003
DEBUG - 2011-04-30 13:21:41 --> Config Class Initialized
DEBUG - 2011-04-30 13:21:41 --> Hooks Class Initialized
DEBUG - 2011-04-30 13:21:41 --> Utf8 Class Initialized
DEBUG - 2011-04-30 13:21:41 --> UTF-8 Support Enabled
DEBUG - 2011-04-30 13:21:41 --> URI Class Initialized
DEBUG - 2011-04-30 13:21:41 --> Router Class Initialized
DEBUG - 2011-04-30 13:21:41 --> Output Class Initialized
DEBUG - 2011-04-30 13:21:41 --> Input Class Initialized
DEBUG - 2011-04-30 13:21:41 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-30 13:21:41 --> Language Class Initialized
DEBUG - 2011-04-30 13:21:41 --> Loader Class Initialized
DEBUG - 2011-04-30 13:21:41 --> Controller Class Initialized
DEBUG - 2011-04-30 13:21:41 --> Model Class Initialized
DEBUG - 2011-04-30 13:21:41 --> Model Class Initialized
DEBUG - 2011-04-30 13:21:41 --> Model Class Initialized
DEBUG - 2011-04-30 13:21:41 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-30 13:21:41 --> Database Driver Class Initialized
DEBUG - 2011-04-30 13:21:41 --> File loaded: application/views/table/main.php
DEBUG - 2011-04-30 13:21:41 --> Helper loaded: url_helper
DEBUG - 2011-04-30 13:21:41 --> File loaded: application/views/common/header.php
DEBUG - 2011-04-30 13:21:41 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-04-30 13:21:41 --> File loaded: application/views/common/footer.php
DEBUG - 2011-04-30 13:21:41 --> File loaded: application/views/layout/main.php
DEBUG - 2011-04-30 13:21:41 --> Final output sent to browser
DEBUG - 2011-04-30 13:21:41 --> Total execution time: 0.0521
DEBUG - 2011-04-30 13:21:52 --> Config Class Initialized
DEBUG - 2011-04-30 13:21:52 --> Hooks Class Initialized
DEBUG - 2011-04-30 13:21:52 --> Utf8 Class Initialized
DEBUG - 2011-04-30 13:21:52 --> UTF-8 Support Enabled
DEBUG - 2011-04-30 13:21:52 --> URI Class Initialized
DEBUG - 2011-04-30 13:21:52 --> Router Class Initialized
DEBUG - 2011-04-30 13:21:52 --> Output Class Initialized
DEBUG - 2011-04-30 13:21:52 --> Input Class Initialized
DEBUG - 2011-04-30 13:21:52 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-30 13:21:52 --> Language Class Initialized
DEBUG - 2011-04-30 13:21:52 --> Loader Class Initialized
DEBUG - 2011-04-30 13:21:52 --> Controller Class Initialized
DEBUG - 2011-04-30 13:21:52 --> Model Class Initialized
DEBUG - 2011-04-30 13:21:52 --> Model Class Initialized
DEBUG - 2011-04-30 13:21:52 --> Model Class Initialized
DEBUG - 2011-04-30 13:21:52 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-30 13:21:52 --> Database Driver Class Initialized
DEBUG - 2011-04-30 13:21:52 --> File loaded: application/views/table/main.php
DEBUG - 2011-04-30 13:21:52 --> Helper loaded: url_helper
DEBUG - 2011-04-30 13:21:52 --> File loaded: application/views/common/header.php
DEBUG - 2011-04-30 13:21:52 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-04-30 13:21:52 --> File loaded: application/views/common/footer.php
DEBUG - 2011-04-30 13:21:52 --> File loaded: application/views/layout/main.php
DEBUG - 2011-04-30 13:21:52 --> Final output sent to browser
DEBUG - 2011-04-30 13:21:52 --> Total execution time: 0.2139
DEBUG - 2011-04-30 13:21:53 --> Config Class Initialized
DEBUG - 2011-04-30 13:21:53 --> Hooks Class Initialized
DEBUG - 2011-04-30 13:21:53 --> Utf8 Class Initialized
DEBUG - 2011-04-30 13:21:53 --> UTF-8 Support Enabled
DEBUG - 2011-04-30 13:21:53 --> URI Class Initialized
DEBUG - 2011-04-30 13:21:53 --> Router Class Initialized
DEBUG - 2011-04-30 13:21:53 --> Output Class Initialized
DEBUG - 2011-04-30 13:21:53 --> Input Class Initialized
DEBUG - 2011-04-30 13:21:53 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-30 13:21:53 --> Language Class Initialized
DEBUG - 2011-04-30 13:21:53 --> Loader Class Initialized
DEBUG - 2011-04-30 13:21:53 --> Controller Class Initialized
DEBUG - 2011-04-30 13:21:53 --> Model Class Initialized
DEBUG - 2011-04-30 13:21:53 --> Model Class Initialized
DEBUG - 2011-04-30 13:21:53 --> Model Class Initialized
DEBUG - 2011-04-30 13:21:53 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-30 13:21:53 --> Database Driver Class Initialized
DEBUG - 2011-04-30 13:21:53 --> File loaded: application/views/table/main.php
DEBUG - 2011-04-30 13:21:53 --> Helper loaded: url_helper
DEBUG - 2011-04-30 13:21:53 --> File loaded: application/views/common/header.php
DEBUG - 2011-04-30 13:21:53 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-04-30 13:21:53 --> File loaded: application/views/common/footer.php
DEBUG - 2011-04-30 13:21:53 --> File loaded: application/views/layout/main.php
DEBUG - 2011-04-30 13:21:53 --> Final output sent to browser
DEBUG - 2011-04-30 13:21:53 --> Total execution time: 0.1935
DEBUG - 2011-04-30 13:21:53 --> Config Class Initialized
DEBUG - 2011-04-30 13:21:53 --> Hooks Class Initialized
DEBUG - 2011-04-30 13:21:53 --> Utf8 Class Initialized
DEBUG - 2011-04-30 13:21:53 --> UTF-8 Support Enabled
DEBUG - 2011-04-30 13:21:53 --> URI Class Initialized
DEBUG - 2011-04-30 13:21:53 --> Router Class Initialized
DEBUG - 2011-04-30 13:21:53 --> Output Class Initialized
DEBUG - 2011-04-30 13:21:53 --> Input Class Initialized
DEBUG - 2011-04-30 13:21:53 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-30 13:21:53 --> Language Class Initialized
DEBUG - 2011-04-30 13:21:53 --> Loader Class Initialized
DEBUG - 2011-04-30 13:21:53 --> Controller Class Initialized
DEBUG - 2011-04-30 13:21:53 --> Model Class Initialized
DEBUG - 2011-04-30 13:21:53 --> Model Class Initialized
DEBUG - 2011-04-30 13:21:53 --> Model Class Initialized
DEBUG - 2011-04-30 13:21:53 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-30 13:21:53 --> Database Driver Class Initialized
DEBUG - 2011-04-30 13:21:53 --> File loaded: application/views/table/main.php
DEBUG - 2011-04-30 13:21:53 --> Helper loaded: url_helper
DEBUG - 2011-04-30 13:21:53 --> File loaded: application/views/common/header.php
DEBUG - 2011-04-30 13:21:53 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-04-30 13:21:53 --> File loaded: application/views/common/footer.php
DEBUG - 2011-04-30 13:21:53 --> File loaded: application/views/layout/main.php
DEBUG - 2011-04-30 13:21:53 --> Final output sent to browser
DEBUG - 2011-04-30 13:21:53 --> Total execution time: 0.2195
DEBUG - 2011-04-30 13:21:59 --> Config Class Initialized
DEBUG - 2011-04-30 13:21:59 --> Hooks Class Initialized
DEBUG - 2011-04-30 13:21:59 --> Utf8 Class Initialized
DEBUG - 2011-04-30 13:21:59 --> UTF-8 Support Enabled
DEBUG - 2011-04-30 13:21:59 --> URI Class Initialized
DEBUG - 2011-04-30 13:21:59 --> Router Class Initialized
DEBUG - 2011-04-30 13:21:59 --> Output Class Initialized
DEBUG - 2011-04-30 13:21:59 --> Input Class Initialized
DEBUG - 2011-04-30 13:21:59 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-30 13:21:59 --> Language Class Initialized
DEBUG - 2011-04-30 13:21:59 --> Loader Class Initialized
DEBUG - 2011-04-30 13:21:59 --> Controller Class Initialized
DEBUG - 2011-04-30 13:21:59 --> Model Class Initialized
DEBUG - 2011-04-30 13:21:59 --> Model Class Initialized
DEBUG - 2011-04-30 13:21:59 --> Model Class Initialized
DEBUG - 2011-04-30 13:21:59 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-30 13:21:59 --> Database Driver Class Initialized
DEBUG - 2011-04-30 13:21:59 --> File loaded: application/views/table/main.php
DEBUG - 2011-04-30 13:21:59 --> Helper loaded: url_helper
DEBUG - 2011-04-30 13:21:59 --> File loaded: application/views/common/header.php
DEBUG - 2011-04-30 13:21:59 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-04-30 13:21:59 --> File loaded: application/views/common/footer.php
DEBUG - 2011-04-30 13:21:59 --> File loaded: application/views/layout/main.php
DEBUG - 2011-04-30 13:21:59 --> Final output sent to browser
DEBUG - 2011-04-30 13:21:59 --> Total execution time: 0.2516
DEBUG - 2011-04-30 13:22:05 --> Config Class Initialized
DEBUG - 2011-04-30 13:22:05 --> Hooks Class Initialized
DEBUG - 2011-04-30 13:22:05 --> Utf8 Class Initialized
DEBUG - 2011-04-30 13:22:05 --> UTF-8 Support Enabled
DEBUG - 2011-04-30 13:22:05 --> URI Class Initialized
DEBUG - 2011-04-30 13:22:05 --> Router Class Initialized
DEBUG - 2011-04-30 13:22:05 --> Output Class Initialized
DEBUG - 2011-04-30 13:22:05 --> Input Class Initialized
DEBUG - 2011-04-30 13:22:05 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-30 13:22:05 --> Language Class Initialized
DEBUG - 2011-04-30 13:22:05 --> Loader Class Initialized
DEBUG - 2011-04-30 13:22:05 --> Controller Class Initialized
DEBUG - 2011-04-30 13:22:05 --> Model Class Initialized
DEBUG - 2011-04-30 13:22:05 --> Model Class Initialized
DEBUG - 2011-04-30 13:22:05 --> Model Class Initialized
DEBUG - 2011-04-30 13:22:05 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-30 13:22:05 --> Database Driver Class Initialized
DEBUG - 2011-04-30 13:22:05 --> File loaded: application/views/table/main.php
DEBUG - 2011-04-30 13:22:05 --> Helper loaded: url_helper
DEBUG - 2011-04-30 13:22:05 --> File loaded: application/views/common/header.php
DEBUG - 2011-04-30 13:22:05 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-04-30 13:22:05 --> File loaded: application/views/common/footer.php
DEBUG - 2011-04-30 13:22:05 --> File loaded: application/views/layout/main.php
DEBUG - 2011-04-30 13:22:05 --> Final output sent to browser
DEBUG - 2011-04-30 13:22:05 --> Total execution time: 0.2370
DEBUG - 2011-04-30 13:22:13 --> Config Class Initialized
DEBUG - 2011-04-30 13:22:13 --> Hooks Class Initialized
DEBUG - 2011-04-30 13:22:13 --> Utf8 Class Initialized
DEBUG - 2011-04-30 13:22:13 --> UTF-8 Support Enabled
DEBUG - 2011-04-30 13:22:13 --> URI Class Initialized
DEBUG - 2011-04-30 13:22:13 --> Router Class Initialized
DEBUG - 2011-04-30 13:22:13 --> Output Class Initialized
DEBUG - 2011-04-30 13:22:13 --> Input Class Initialized
DEBUG - 2011-04-30 13:22:13 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-30 13:22:13 --> Language Class Initialized
DEBUG - 2011-04-30 13:22:13 --> Loader Class Initialized
DEBUG - 2011-04-30 13:22:13 --> Controller Class Initialized
DEBUG - 2011-04-30 13:22:13 --> Model Class Initialized
DEBUG - 2011-04-30 13:22:13 --> Model Class Initialized
DEBUG - 2011-04-30 13:22:13 --> Model Class Initialized
DEBUG - 2011-04-30 13:22:13 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-30 13:22:13 --> Database Driver Class Initialized
DEBUG - 2011-04-30 13:22:13 --> File loaded: application/views/table/main.php
DEBUG - 2011-04-30 13:22:13 --> Helper loaded: url_helper
DEBUG - 2011-04-30 13:22:13 --> File loaded: application/views/common/header.php
DEBUG - 2011-04-30 13:22:13 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-04-30 13:22:13 --> File loaded: application/views/common/footer.php
DEBUG - 2011-04-30 13:22:13 --> File loaded: application/views/layout/main.php
DEBUG - 2011-04-30 13:22:13 --> Final output sent to browser
DEBUG - 2011-04-30 13:22:13 --> Total execution time: 0.1896
DEBUG - 2011-04-30 13:22:16 --> Config Class Initialized
DEBUG - 2011-04-30 13:22:16 --> Hooks Class Initialized
DEBUG - 2011-04-30 13:22:16 --> Utf8 Class Initialized
DEBUG - 2011-04-30 13:22:16 --> UTF-8 Support Enabled
DEBUG - 2011-04-30 13:22:16 --> URI Class Initialized
DEBUG - 2011-04-30 13:22:16 --> Router Class Initialized
DEBUG - 2011-04-30 13:22:16 --> Output Class Initialized
DEBUG - 2011-04-30 13:22:16 --> Input Class Initialized
DEBUG - 2011-04-30 13:22:16 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-30 13:22:16 --> Language Class Initialized
DEBUG - 2011-04-30 13:22:16 --> Loader Class Initialized
DEBUG - 2011-04-30 13:22:16 --> Controller Class Initialized
DEBUG - 2011-04-30 13:22:16 --> Model Class Initialized
DEBUG - 2011-04-30 13:22:16 --> Model Class Initialized
DEBUG - 2011-04-30 13:22:16 --> Model Class Initialized
DEBUG - 2011-04-30 13:22:16 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-30 13:22:16 --> Database Driver Class Initialized
DEBUG - 2011-04-30 13:22:16 --> File loaded: application/views/table/main.php
DEBUG - 2011-04-30 13:22:16 --> Helper loaded: url_helper
DEBUG - 2011-04-30 13:22:16 --> File loaded: application/views/common/header.php
DEBUG - 2011-04-30 13:22:16 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-04-30 13:22:16 --> File loaded: application/views/common/footer.php
DEBUG - 2011-04-30 13:22:16 --> File loaded: application/views/layout/main.php
DEBUG - 2011-04-30 13:22:16 --> Final output sent to browser
DEBUG - 2011-04-30 13:22:16 --> Total execution time: 0.0462
DEBUG - 2011-04-30 13:22:35 --> Config Class Initialized
DEBUG - 2011-04-30 13:22:35 --> Hooks Class Initialized
DEBUG - 2011-04-30 13:22:35 --> Utf8 Class Initialized
DEBUG - 2011-04-30 13:22:35 --> UTF-8 Support Enabled
DEBUG - 2011-04-30 13:22:35 --> URI Class Initialized
DEBUG - 2011-04-30 13:22:35 --> Router Class Initialized
DEBUG - 2011-04-30 13:22:35 --> Output Class Initialized
DEBUG - 2011-04-30 13:22:35 --> Input Class Initialized
DEBUG - 2011-04-30 13:22:35 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-30 13:22:35 --> Language Class Initialized
DEBUG - 2011-04-30 13:22:35 --> Loader Class Initialized
DEBUG - 2011-04-30 13:22:35 --> Controller Class Initialized
DEBUG - 2011-04-30 13:22:35 --> Model Class Initialized
DEBUG - 2011-04-30 13:22:35 --> Model Class Initialized
DEBUG - 2011-04-30 13:22:35 --> Model Class Initialized
DEBUG - 2011-04-30 13:22:35 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-30 13:22:35 --> Database Driver Class Initialized
DEBUG - 2011-04-30 13:22:36 --> File loaded: application/views/table/main.php
DEBUG - 2011-04-30 13:22:36 --> Helper loaded: url_helper
DEBUG - 2011-04-30 13:22:36 --> File loaded: application/views/common/header.php
DEBUG - 2011-04-30 13:22:36 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-04-30 13:22:36 --> File loaded: application/views/common/footer.php
DEBUG - 2011-04-30 13:22:36 --> File loaded: application/views/layout/main.php
DEBUG - 2011-04-30 13:22:36 --> Final output sent to browser
DEBUG - 2011-04-30 13:22:36 --> Total execution time: 0.7384
DEBUG - 2011-04-30 13:22:41 --> Config Class Initialized
DEBUG - 2011-04-30 13:22:41 --> Hooks Class Initialized
DEBUG - 2011-04-30 13:22:41 --> Utf8 Class Initialized
DEBUG - 2011-04-30 13:22:41 --> UTF-8 Support Enabled
DEBUG - 2011-04-30 13:22:41 --> URI Class Initialized
DEBUG - 2011-04-30 13:22:41 --> Router Class Initialized
DEBUG - 2011-04-30 13:22:41 --> Output Class Initialized
DEBUG - 2011-04-30 13:22:41 --> Input Class Initialized
DEBUG - 2011-04-30 13:22:41 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-30 13:22:41 --> Language Class Initialized
DEBUG - 2011-04-30 13:22:41 --> Loader Class Initialized
DEBUG - 2011-04-30 13:22:41 --> Controller Class Initialized
DEBUG - 2011-04-30 13:22:41 --> Model Class Initialized
DEBUG - 2011-04-30 13:22:41 --> Model Class Initialized
DEBUG - 2011-04-30 13:22:41 --> Model Class Initialized
DEBUG - 2011-04-30 13:22:41 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-30 13:22:41 --> Database Driver Class Initialized
DEBUG - 2011-04-30 13:22:42 --> File loaded: application/views/table/main.php
DEBUG - 2011-04-30 13:22:42 --> Helper loaded: url_helper
DEBUG - 2011-04-30 13:22:42 --> File loaded: application/views/common/header.php
DEBUG - 2011-04-30 13:22:42 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-04-30 13:22:42 --> File loaded: application/views/common/footer.php
DEBUG - 2011-04-30 13:22:42 --> File loaded: application/views/layout/main.php
DEBUG - 2011-04-30 13:22:42 --> Final output sent to browser
DEBUG - 2011-04-30 13:22:42 --> Total execution time: 0.2362
DEBUG - 2011-04-30 13:22:49 --> Config Class Initialized
DEBUG - 2011-04-30 13:22:49 --> Hooks Class Initialized
DEBUG - 2011-04-30 13:22:49 --> Utf8 Class Initialized
DEBUG - 2011-04-30 13:22:49 --> UTF-8 Support Enabled
DEBUG - 2011-04-30 13:22:49 --> URI Class Initialized
DEBUG - 2011-04-30 13:22:49 --> Router Class Initialized
DEBUG - 2011-04-30 13:22:49 --> Output Class Initialized
DEBUG - 2011-04-30 13:22:49 --> Input Class Initialized
DEBUG - 2011-04-30 13:22:49 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-30 13:22:49 --> Language Class Initialized
DEBUG - 2011-04-30 13:22:49 --> Loader Class Initialized
DEBUG - 2011-04-30 13:22:49 --> Controller Class Initialized
DEBUG - 2011-04-30 13:22:49 --> Model Class Initialized
DEBUG - 2011-04-30 13:22:49 --> Model Class Initialized
DEBUG - 2011-04-30 13:22:49 --> Model Class Initialized
DEBUG - 2011-04-30 13:22:49 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-30 13:22:49 --> Database Driver Class Initialized
DEBUG - 2011-04-30 13:22:49 --> File loaded: application/views/table/main.php
DEBUG - 2011-04-30 13:22:49 --> Helper loaded: url_helper
DEBUG - 2011-04-30 13:22:49 --> File loaded: application/views/common/header.php
DEBUG - 2011-04-30 13:22:49 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-04-30 13:22:49 --> File loaded: application/views/common/footer.php
DEBUG - 2011-04-30 13:22:49 --> File loaded: application/views/layout/main.php
DEBUG - 2011-04-30 13:22:49 --> Final output sent to browser
DEBUG - 2011-04-30 13:22:49 --> Total execution time: 0.0449
DEBUG - 2011-04-30 13:22:52 --> Config Class Initialized
DEBUG - 2011-04-30 13:22:52 --> Hooks Class Initialized
DEBUG - 2011-04-30 13:22:52 --> Utf8 Class Initialized
DEBUG - 2011-04-30 13:22:52 --> UTF-8 Support Enabled
DEBUG - 2011-04-30 13:22:52 --> URI Class Initialized
DEBUG - 2011-04-30 13:22:52 --> Router Class Initialized
ERROR - 2011-04-30 13:22:52 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-04-30 13:22:53 --> Config Class Initialized
DEBUG - 2011-04-30 13:22:53 --> Hooks Class Initialized
DEBUG - 2011-04-30 13:22:53 --> Utf8 Class Initialized
DEBUG - 2011-04-30 13:22:53 --> UTF-8 Support Enabled
DEBUG - 2011-04-30 13:22:53 --> URI Class Initialized
DEBUG - 2011-04-30 13:22:53 --> Router Class Initialized
DEBUG - 2011-04-30 13:22:53 --> Output Class Initialized
DEBUG - 2011-04-30 13:22:53 --> Input Class Initialized
DEBUG - 2011-04-30 13:22:53 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-30 13:22:53 --> Language Class Initialized
DEBUG - 2011-04-30 13:22:53 --> Loader Class Initialized
DEBUG - 2011-04-30 13:22:53 --> Controller Class Initialized
DEBUG - 2011-04-30 13:22:53 --> Model Class Initialized
DEBUG - 2011-04-30 13:22:53 --> Model Class Initialized
DEBUG - 2011-04-30 13:22:53 --> Model Class Initialized
DEBUG - 2011-04-30 13:22:53 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-30 13:22:53 --> Database Driver Class Initialized
DEBUG - 2011-04-30 13:22:53 --> File loaded: application/views/table/main.php
DEBUG - 2011-04-30 13:22:53 --> Helper loaded: url_helper
DEBUG - 2011-04-30 13:22:53 --> File loaded: application/views/common/header.php
DEBUG - 2011-04-30 13:22:53 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-04-30 13:22:53 --> File loaded: application/views/common/footer.php
DEBUG - 2011-04-30 13:22:53 --> File loaded: application/views/layout/main.php
DEBUG - 2011-04-30 13:22:53 --> Final output sent to browser
DEBUG - 2011-04-30 13:22:53 --> Total execution time: 0.0416
DEBUG - 2011-04-30 13:23:03 --> Config Class Initialized
DEBUG - 2011-04-30 13:23:03 --> Hooks Class Initialized
DEBUG - 2011-04-30 13:23:03 --> Utf8 Class Initialized
DEBUG - 2011-04-30 13:23:03 --> UTF-8 Support Enabled
DEBUG - 2011-04-30 13:23:03 --> URI Class Initialized
DEBUG - 2011-04-30 13:23:03 --> Router Class Initialized
DEBUG - 2011-04-30 13:23:03 --> Output Class Initialized
DEBUG - 2011-04-30 13:23:03 --> Input Class Initialized
DEBUG - 2011-04-30 13:23:03 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-30 13:23:03 --> Language Class Initialized
DEBUG - 2011-04-30 13:23:03 --> Loader Class Initialized
DEBUG - 2011-04-30 13:23:03 --> Controller Class Initialized
DEBUG - 2011-04-30 13:23:03 --> Model Class Initialized
DEBUG - 2011-04-30 13:23:03 --> Model Class Initialized
DEBUG - 2011-04-30 13:23:03 --> Model Class Initialized
DEBUG - 2011-04-30 13:23:03 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-30 13:23:03 --> Database Driver Class Initialized
DEBUG - 2011-04-30 13:23:04 --> File loaded: application/views/table/main.php
DEBUG - 2011-04-30 13:23:04 --> Helper loaded: url_helper
DEBUG - 2011-04-30 13:23:04 --> File loaded: application/views/common/header.php
DEBUG - 2011-04-30 13:23:04 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-04-30 13:23:04 --> File loaded: application/views/common/footer.php
DEBUG - 2011-04-30 13:23:04 --> File loaded: application/views/layout/main.php
DEBUG - 2011-04-30 13:23:04 --> Final output sent to browser
DEBUG - 2011-04-30 13:23:04 --> Total execution time: 0.3781
DEBUG - 2011-04-30 13:23:05 --> Config Class Initialized
DEBUG - 2011-04-30 13:23:05 --> Hooks Class Initialized
DEBUG - 2011-04-30 13:23:05 --> Utf8 Class Initialized
DEBUG - 2011-04-30 13:23:05 --> UTF-8 Support Enabled
DEBUG - 2011-04-30 13:23:05 --> URI Class Initialized
DEBUG - 2011-04-30 13:23:05 --> Router Class Initialized
DEBUG - 2011-04-30 13:23:05 --> Output Class Initialized
DEBUG - 2011-04-30 13:23:05 --> Input Class Initialized
DEBUG - 2011-04-30 13:23:05 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-30 13:23:05 --> Language Class Initialized
DEBUG - 2011-04-30 13:23:05 --> Loader Class Initialized
DEBUG - 2011-04-30 13:23:05 --> Controller Class Initialized
DEBUG - 2011-04-30 13:23:05 --> Model Class Initialized
DEBUG - 2011-04-30 13:23:05 --> Model Class Initialized
DEBUG - 2011-04-30 13:23:05 --> Model Class Initialized
DEBUG - 2011-04-30 13:23:05 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-30 13:23:05 --> Database Driver Class Initialized
DEBUG - 2011-04-30 13:23:05 --> File loaded: application/views/table/main.php
DEBUG - 2011-04-30 13:23:05 --> Helper loaded: url_helper
DEBUG - 2011-04-30 13:23:05 --> File loaded: application/views/common/header.php
DEBUG - 2011-04-30 13:23:05 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-04-30 13:23:05 --> File loaded: application/views/common/footer.php
DEBUG - 2011-04-30 13:23:05 --> File loaded: application/views/layout/main.php
DEBUG - 2011-04-30 13:23:05 --> Final output sent to browser
DEBUG - 2011-04-30 13:23:05 --> Total execution time: 0.0475
DEBUG - 2011-04-30 13:23:05 --> Config Class Initialized
DEBUG - 2011-04-30 13:23:05 --> Hooks Class Initialized
DEBUG - 2011-04-30 13:23:05 --> Utf8 Class Initialized
DEBUG - 2011-04-30 13:23:05 --> UTF-8 Support Enabled
DEBUG - 2011-04-30 13:23:05 --> URI Class Initialized
DEBUG - 2011-04-30 13:23:05 --> Router Class Initialized
ERROR - 2011-04-30 13:23:05 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-04-30 13:23:10 --> Config Class Initialized
DEBUG - 2011-04-30 13:23:10 --> Hooks Class Initialized
DEBUG - 2011-04-30 13:23:10 --> Utf8 Class Initialized
DEBUG - 2011-04-30 13:23:10 --> UTF-8 Support Enabled
DEBUG - 2011-04-30 13:23:10 --> URI Class Initialized
DEBUG - 2011-04-30 13:23:10 --> Router Class Initialized
DEBUG - 2011-04-30 13:23:10 --> Output Class Initialized
DEBUG - 2011-04-30 13:23:10 --> Input Class Initialized
DEBUG - 2011-04-30 13:23:10 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-30 13:23:10 --> Language Class Initialized
DEBUG - 2011-04-30 13:23:10 --> Loader Class Initialized
DEBUG - 2011-04-30 13:23:10 --> Controller Class Initialized
DEBUG - 2011-04-30 13:23:10 --> Model Class Initialized
DEBUG - 2011-04-30 13:23:10 --> Model Class Initialized
DEBUG - 2011-04-30 13:23:10 --> Model Class Initialized
DEBUG - 2011-04-30 13:23:10 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-30 13:23:10 --> Database Driver Class Initialized
DEBUG - 2011-04-30 13:23:10 --> File loaded: application/views/table/main.php
DEBUG - 2011-04-30 13:23:10 --> Helper loaded: url_helper
DEBUG - 2011-04-30 13:23:10 --> File loaded: application/views/common/header.php
DEBUG - 2011-04-30 13:23:10 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-04-30 13:23:10 --> File loaded: application/views/common/footer.php
DEBUG - 2011-04-30 13:23:10 --> File loaded: application/views/layout/main.php
DEBUG - 2011-04-30 13:23:10 --> Final output sent to browser
DEBUG - 2011-04-30 13:23:10 --> Total execution time: 0.0578
DEBUG - 2011-04-30 13:23:11 --> Config Class Initialized
DEBUG - 2011-04-30 13:23:11 --> Hooks Class Initialized
DEBUG - 2011-04-30 13:23:11 --> Utf8 Class Initialized
DEBUG - 2011-04-30 13:23:11 --> UTF-8 Support Enabled
DEBUG - 2011-04-30 13:23:11 --> URI Class Initialized
DEBUG - 2011-04-30 13:23:11 --> Router Class Initialized
DEBUG - 2011-04-30 13:23:11 --> Output Class Initialized
DEBUG - 2011-04-30 13:23:11 --> Input Class Initialized
DEBUG - 2011-04-30 13:23:11 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-30 13:23:11 --> Language Class Initialized
DEBUG - 2011-04-30 13:23:11 --> Loader Class Initialized
DEBUG - 2011-04-30 13:23:11 --> Controller Class Initialized
DEBUG - 2011-04-30 13:23:11 --> Model Class Initialized
DEBUG - 2011-04-30 13:23:11 --> Model Class Initialized
DEBUG - 2011-04-30 13:23:11 --> Model Class Initialized
DEBUG - 2011-04-30 13:23:11 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-30 13:23:11 --> Database Driver Class Initialized
DEBUG - 2011-04-30 13:23:11 --> File loaded: application/views/table/main.php
DEBUG - 2011-04-30 13:23:11 --> Helper loaded: url_helper
DEBUG - 2011-04-30 13:23:11 --> File loaded: application/views/common/header.php
DEBUG - 2011-04-30 13:23:11 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-04-30 13:23:11 --> File loaded: application/views/common/footer.php
DEBUG - 2011-04-30 13:23:11 --> File loaded: application/views/layout/main.php
DEBUG - 2011-04-30 13:23:11 --> Final output sent to browser
DEBUG - 2011-04-30 13:23:11 --> Total execution time: 0.0466
DEBUG - 2011-04-30 13:23:11 --> Config Class Initialized
DEBUG - 2011-04-30 13:23:11 --> Hooks Class Initialized
DEBUG - 2011-04-30 13:23:11 --> Utf8 Class Initialized
DEBUG - 2011-04-30 13:23:11 --> UTF-8 Support Enabled
DEBUG - 2011-04-30 13:23:11 --> URI Class Initialized
DEBUG - 2011-04-30 13:23:11 --> Router Class Initialized
ERROR - 2011-04-30 13:23:11 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-04-30 13:23:16 --> Config Class Initialized
DEBUG - 2011-04-30 13:23:16 --> Hooks Class Initialized
DEBUG - 2011-04-30 13:23:16 --> Utf8 Class Initialized
DEBUG - 2011-04-30 13:23:16 --> UTF-8 Support Enabled
DEBUG - 2011-04-30 13:23:16 --> URI Class Initialized
DEBUG - 2011-04-30 13:23:16 --> Router Class Initialized
DEBUG - 2011-04-30 13:23:16 --> Output Class Initialized
DEBUG - 2011-04-30 13:23:16 --> Input Class Initialized
DEBUG - 2011-04-30 13:23:16 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-30 13:23:16 --> Language Class Initialized
DEBUG - 2011-04-30 13:23:16 --> Loader Class Initialized
DEBUG - 2011-04-30 13:23:16 --> Controller Class Initialized
DEBUG - 2011-04-30 13:23:16 --> Model Class Initialized
DEBUG - 2011-04-30 13:23:16 --> Model Class Initialized
DEBUG - 2011-04-30 13:23:16 --> Model Class Initialized
DEBUG - 2011-04-30 13:23:16 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-30 13:23:16 --> Database Driver Class Initialized
DEBUG - 2011-04-30 13:23:17 --> File loaded: application/views/table/main.php
DEBUG - 2011-04-30 13:23:17 --> Helper loaded: url_helper
DEBUG - 2011-04-30 13:23:17 --> File loaded: application/views/common/header.php
DEBUG - 2011-04-30 13:23:17 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-04-30 13:23:17 --> File loaded: application/views/common/footer.php
DEBUG - 2011-04-30 13:23:17 --> File loaded: application/views/layout/main.php
DEBUG - 2011-04-30 13:23:17 --> Final output sent to browser
DEBUG - 2011-04-30 13:23:17 --> Total execution time: 0.2365
DEBUG - 2011-04-30 13:23:17 --> Config Class Initialized
DEBUG - 2011-04-30 13:23:17 --> Hooks Class Initialized
DEBUG - 2011-04-30 13:23:17 --> Utf8 Class Initialized
DEBUG - 2011-04-30 13:23:17 --> UTF-8 Support Enabled
DEBUG - 2011-04-30 13:23:17 --> URI Class Initialized
DEBUG - 2011-04-30 13:23:17 --> Router Class Initialized
DEBUG - 2011-04-30 13:23:17 --> Output Class Initialized
DEBUG - 2011-04-30 13:23:17 --> Input Class Initialized
DEBUG - 2011-04-30 13:23:17 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-30 13:23:17 --> Language Class Initialized
DEBUG - 2011-04-30 13:23:17 --> Loader Class Initialized
DEBUG - 2011-04-30 13:23:17 --> Controller Class Initialized
DEBUG - 2011-04-30 13:23:17 --> Model Class Initialized
DEBUG - 2011-04-30 13:23:17 --> Model Class Initialized
DEBUG - 2011-04-30 13:23:17 --> Model Class Initialized
DEBUG - 2011-04-30 13:23:17 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-30 13:23:17 --> Database Driver Class Initialized
DEBUG - 2011-04-30 13:23:17 --> File loaded: application/views/table/main.php
DEBUG - 2011-04-30 13:23:17 --> Helper loaded: url_helper
DEBUG - 2011-04-30 13:23:17 --> File loaded: application/views/common/header.php
DEBUG - 2011-04-30 13:23:17 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-04-30 13:23:17 --> File loaded: application/views/common/footer.php
DEBUG - 2011-04-30 13:23:17 --> File loaded: application/views/layout/main.php
DEBUG - 2011-04-30 13:23:17 --> Final output sent to browser
DEBUG - 2011-04-30 13:23:17 --> Total execution time: 0.0476
DEBUG - 2011-04-30 13:23:17 --> Config Class Initialized
DEBUG - 2011-04-30 13:23:17 --> Hooks Class Initialized
DEBUG - 2011-04-30 13:23:17 --> Utf8 Class Initialized
DEBUG - 2011-04-30 13:23:17 --> UTF-8 Support Enabled
DEBUG - 2011-04-30 13:23:17 --> URI Class Initialized
DEBUG - 2011-04-30 13:23:17 --> Router Class Initialized
ERROR - 2011-04-30 13:23:17 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-04-30 13:23:24 --> Config Class Initialized
DEBUG - 2011-04-30 13:23:24 --> Hooks Class Initialized
DEBUG - 2011-04-30 13:23:24 --> Utf8 Class Initialized
DEBUG - 2011-04-30 13:23:24 --> UTF-8 Support Enabled
DEBUG - 2011-04-30 13:23:24 --> URI Class Initialized
DEBUG - 2011-04-30 13:23:24 --> Router Class Initialized
ERROR - 2011-04-30 13:23:24 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-04-30 13:23:25 --> Config Class Initialized
DEBUG - 2011-04-30 13:23:25 --> Hooks Class Initialized
DEBUG - 2011-04-30 13:23:25 --> Utf8 Class Initialized
DEBUG - 2011-04-30 13:23:25 --> UTF-8 Support Enabled
DEBUG - 2011-04-30 13:23:25 --> URI Class Initialized
DEBUG - 2011-04-30 13:23:25 --> Router Class Initialized
ERROR - 2011-04-30 13:23:25 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-04-30 13:23:58 --> Config Class Initialized
DEBUG - 2011-04-30 13:23:58 --> Hooks Class Initialized
DEBUG - 2011-04-30 13:23:58 --> Utf8 Class Initialized
DEBUG - 2011-04-30 13:23:58 --> UTF-8 Support Enabled
DEBUG - 2011-04-30 13:23:58 --> URI Class Initialized
DEBUG - 2011-04-30 13:23:58 --> Router Class Initialized
DEBUG - 2011-04-30 13:23:58 --> Output Class Initialized
DEBUG - 2011-04-30 13:23:58 --> Input Class Initialized
DEBUG - 2011-04-30 13:23:58 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-30 13:23:58 --> Language Class Initialized
DEBUG - 2011-04-30 13:23:58 --> Loader Class Initialized
DEBUG - 2011-04-30 13:23:58 --> Controller Class Initialized
DEBUG - 2011-04-30 13:23:58 --> Model Class Initialized
DEBUG - 2011-04-30 13:23:58 --> Model Class Initialized
DEBUG - 2011-04-30 13:23:58 --> Model Class Initialized
DEBUG - 2011-04-30 13:23:58 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-30 13:23:58 --> Database Driver Class Initialized
DEBUG - 2011-04-30 13:23:58 --> File loaded: application/views/table/main.php
DEBUG - 2011-04-30 13:23:58 --> Helper loaded: url_helper
DEBUG - 2011-04-30 13:23:58 --> File loaded: application/views/common/header.php
DEBUG - 2011-04-30 13:23:58 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-04-30 13:23:58 --> File loaded: application/views/common/footer.php
DEBUG - 2011-04-30 13:23:58 --> File loaded: application/views/layout/main.php
DEBUG - 2011-04-30 13:23:58 --> Final output sent to browser
DEBUG - 2011-04-30 13:23:58 --> Total execution time: 0.0444
DEBUG - 2011-04-30 13:24:05 --> Config Class Initialized
DEBUG - 2011-04-30 13:24:05 --> Hooks Class Initialized
DEBUG - 2011-04-30 13:24:05 --> Utf8 Class Initialized
DEBUG - 2011-04-30 13:24:05 --> UTF-8 Support Enabled
DEBUG - 2011-04-30 13:24:05 --> URI Class Initialized
DEBUG - 2011-04-30 13:24:05 --> Router Class Initialized
DEBUG - 2011-04-30 13:24:05 --> Output Class Initialized
DEBUG - 2011-04-30 13:24:05 --> Input Class Initialized
DEBUG - 2011-04-30 13:24:05 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-30 13:24:05 --> Language Class Initialized
DEBUG - 2011-04-30 13:24:05 --> Loader Class Initialized
DEBUG - 2011-04-30 13:24:05 --> Controller Class Initialized
DEBUG - 2011-04-30 13:24:05 --> Model Class Initialized
DEBUG - 2011-04-30 13:24:05 --> Model Class Initialized
DEBUG - 2011-04-30 13:24:05 --> Model Class Initialized
DEBUG - 2011-04-30 13:24:05 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-30 13:24:05 --> Database Driver Class Initialized
DEBUG - 2011-04-30 13:24:05 --> File loaded: application/views/table/main.php
DEBUG - 2011-04-30 13:24:05 --> Helper loaded: url_helper
DEBUG - 2011-04-30 13:24:05 --> File loaded: application/views/common/header.php
DEBUG - 2011-04-30 13:24:05 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-04-30 13:24:05 --> File loaded: application/views/common/footer.php
DEBUG - 2011-04-30 13:24:05 --> File loaded: application/views/layout/main.php
DEBUG - 2011-04-30 13:24:05 --> Final output sent to browser
DEBUG - 2011-04-30 13:24:05 --> Total execution time: 0.0441
DEBUG - 2011-04-30 13:24:06 --> Config Class Initialized
DEBUG - 2011-04-30 13:24:06 --> Hooks Class Initialized
DEBUG - 2011-04-30 13:24:06 --> Utf8 Class Initialized
DEBUG - 2011-04-30 13:24:06 --> UTF-8 Support Enabled
DEBUG - 2011-04-30 13:24:06 --> URI Class Initialized
DEBUG - 2011-04-30 13:24:06 --> Router Class Initialized
ERROR - 2011-04-30 13:24:06 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-04-30 13:24:06 --> Config Class Initialized
DEBUG - 2011-04-30 13:24:06 --> Hooks Class Initialized
DEBUG - 2011-04-30 13:24:06 --> Utf8 Class Initialized
DEBUG - 2011-04-30 13:24:06 --> UTF-8 Support Enabled
DEBUG - 2011-04-30 13:24:06 --> URI Class Initialized
DEBUG - 2011-04-30 13:24:06 --> Router Class Initialized
ERROR - 2011-04-30 13:24:06 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-04-30 13:24:07 --> Config Class Initialized
DEBUG - 2011-04-30 13:24:07 --> Hooks Class Initialized
DEBUG - 2011-04-30 13:24:07 --> Utf8 Class Initialized
DEBUG - 2011-04-30 13:24:07 --> UTF-8 Support Enabled
DEBUG - 2011-04-30 13:24:07 --> URI Class Initialized
DEBUG - 2011-04-30 13:24:07 --> Router Class Initialized
ERROR - 2011-04-30 13:24:07 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-04-30 13:24:09 --> Config Class Initialized
DEBUG - 2011-04-30 13:24:09 --> Hooks Class Initialized
DEBUG - 2011-04-30 13:24:09 --> Utf8 Class Initialized
DEBUG - 2011-04-30 13:24:09 --> UTF-8 Support Enabled
DEBUG - 2011-04-30 13:24:09 --> URI Class Initialized
DEBUG - 2011-04-30 13:24:09 --> Router Class Initialized
ERROR - 2011-04-30 13:24:09 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-04-30 13:24:21 --> Config Class Initialized
DEBUG - 2011-04-30 13:24:21 --> Hooks Class Initialized
DEBUG - 2011-04-30 13:24:21 --> Utf8 Class Initialized
DEBUG - 2011-04-30 13:24:21 --> UTF-8 Support Enabled
DEBUG - 2011-04-30 13:24:21 --> URI Class Initialized
DEBUG - 2011-04-30 13:24:21 --> Router Class Initialized
DEBUG - 2011-04-30 13:24:21 --> Output Class Initialized
DEBUG - 2011-04-30 13:24:21 --> Input Class Initialized
DEBUG - 2011-04-30 13:24:21 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-30 13:24:21 --> Language Class Initialized
DEBUG - 2011-04-30 13:24:21 --> Loader Class Initialized
DEBUG - 2011-04-30 13:24:21 --> Controller Class Initialized
DEBUG - 2011-04-30 13:24:21 --> Model Class Initialized
DEBUG - 2011-04-30 13:24:21 --> Model Class Initialized
DEBUG - 2011-04-30 13:24:21 --> Model Class Initialized
DEBUG - 2011-04-30 13:24:21 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-30 13:24:21 --> Database Driver Class Initialized
DEBUG - 2011-04-30 13:24:21 --> File loaded: application/views/table/main.php
DEBUG - 2011-04-30 13:24:21 --> Helper loaded: url_helper
DEBUG - 2011-04-30 13:24:21 --> File loaded: application/views/common/header.php
DEBUG - 2011-04-30 13:24:21 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-04-30 13:24:21 --> File loaded: application/views/common/footer.php
DEBUG - 2011-04-30 13:24:21 --> File loaded: application/views/layout/main.php
DEBUG - 2011-04-30 13:24:21 --> Final output sent to browser
DEBUG - 2011-04-30 13:24:21 --> Total execution time: 0.0972
DEBUG - 2011-04-30 13:25:29 --> Config Class Initialized
DEBUG - 2011-04-30 13:25:29 --> Hooks Class Initialized
DEBUG - 2011-04-30 13:25:29 --> Utf8 Class Initialized
DEBUG - 2011-04-30 13:25:29 --> UTF-8 Support Enabled
DEBUG - 2011-04-30 13:25:29 --> URI Class Initialized
DEBUG - 2011-04-30 13:25:29 --> Router Class Initialized
DEBUG - 2011-04-30 13:25:29 --> Output Class Initialized
DEBUG - 2011-04-30 13:25:29 --> Input Class Initialized
DEBUG - 2011-04-30 13:25:29 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-30 13:25:29 --> Language Class Initialized
DEBUG - 2011-04-30 13:25:29 --> Loader Class Initialized
DEBUG - 2011-04-30 13:25:29 --> Controller Class Initialized
DEBUG - 2011-04-30 13:25:29 --> Model Class Initialized
DEBUG - 2011-04-30 13:25:29 --> Model Class Initialized
DEBUG - 2011-04-30 13:25:29 --> Model Class Initialized
DEBUG - 2011-04-30 13:25:29 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-30 13:25:29 --> Database Driver Class Initialized
DEBUG - 2011-04-30 13:25:29 --> File loaded: application/views/table/main.php
DEBUG - 2011-04-30 13:25:29 --> Helper loaded: url_helper
DEBUG - 2011-04-30 13:25:29 --> File loaded: application/views/common/header.php
DEBUG - 2011-04-30 13:25:29 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-04-30 13:25:29 --> File loaded: application/views/common/footer.php
DEBUG - 2011-04-30 13:25:29 --> File loaded: application/views/layout/main.php
DEBUG - 2011-04-30 13:25:29 --> Final output sent to browser
DEBUG - 2011-04-30 13:25:29 --> Total execution time: 0.0460
DEBUG - 2011-04-30 13:25:36 --> Config Class Initialized
DEBUG - 2011-04-30 13:25:36 --> Hooks Class Initialized
DEBUG - 2011-04-30 13:25:36 --> Utf8 Class Initialized
DEBUG - 2011-04-30 13:25:36 --> UTF-8 Support Enabled
DEBUG - 2011-04-30 13:25:36 --> URI Class Initialized
DEBUG - 2011-04-30 13:25:36 --> Router Class Initialized
DEBUG - 2011-04-30 13:25:36 --> Output Class Initialized
DEBUG - 2011-04-30 13:25:36 --> Input Class Initialized
DEBUG - 2011-04-30 13:25:36 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-30 13:25:36 --> Language Class Initialized
DEBUG - 2011-04-30 13:25:36 --> Loader Class Initialized
DEBUG - 2011-04-30 13:25:36 --> Controller Class Initialized
DEBUG - 2011-04-30 13:25:36 --> Model Class Initialized
DEBUG - 2011-04-30 13:25:36 --> Model Class Initialized
DEBUG - 2011-04-30 13:25:36 --> Model Class Initialized
DEBUG - 2011-04-30 13:25:36 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-30 13:25:36 --> Database Driver Class Initialized
DEBUG - 2011-04-30 13:25:36 --> File loaded: application/views/table/main.php
DEBUG - 2011-04-30 13:25:36 --> Helper loaded: url_helper
DEBUG - 2011-04-30 13:25:36 --> File loaded: application/views/common/header.php
DEBUG - 2011-04-30 13:25:36 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-04-30 13:25:36 --> File loaded: application/views/common/footer.php
DEBUG - 2011-04-30 13:25:36 --> File loaded: application/views/layout/main.php
DEBUG - 2011-04-30 13:25:36 --> Final output sent to browser
DEBUG - 2011-04-30 13:25:36 --> Total execution time: 0.2818
DEBUG - 2011-04-30 13:25:37 --> Config Class Initialized
DEBUG - 2011-04-30 13:25:37 --> Hooks Class Initialized
DEBUG - 2011-04-30 13:25:37 --> Utf8 Class Initialized
DEBUG - 2011-04-30 13:25:37 --> UTF-8 Support Enabled
DEBUG - 2011-04-30 13:25:37 --> URI Class Initialized
DEBUG - 2011-04-30 13:25:37 --> Router Class Initialized
DEBUG - 2011-04-30 13:25:37 --> Output Class Initialized
DEBUG - 2011-04-30 13:25:37 --> Input Class Initialized
DEBUG - 2011-04-30 13:25:37 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-30 13:25:37 --> Language Class Initialized
DEBUG - 2011-04-30 13:25:37 --> Loader Class Initialized
DEBUG - 2011-04-30 13:25:37 --> Controller Class Initialized
DEBUG - 2011-04-30 13:25:37 --> Model Class Initialized
DEBUG - 2011-04-30 13:25:37 --> Model Class Initialized
DEBUG - 2011-04-30 13:25:37 --> Model Class Initialized
DEBUG - 2011-04-30 13:25:37 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-30 13:25:37 --> Database Driver Class Initialized
DEBUG - 2011-04-30 13:25:37 --> File loaded: application/views/table/main.php
DEBUG - 2011-04-30 13:25:37 --> Helper loaded: url_helper
DEBUG - 2011-04-30 13:25:37 --> File loaded: application/views/common/header.php
DEBUG - 2011-04-30 13:25:37 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-04-30 13:25:37 --> File loaded: application/views/common/footer.php
DEBUG - 2011-04-30 13:25:37 --> File loaded: application/views/layout/main.php
DEBUG - 2011-04-30 13:25:37 --> Final output sent to browser
DEBUG - 2011-04-30 13:25:37 --> Total execution time: 0.0523
DEBUG - 2011-04-30 13:25:42 --> Config Class Initialized
DEBUG - 2011-04-30 13:25:42 --> Hooks Class Initialized
DEBUG - 2011-04-30 13:25:42 --> Utf8 Class Initialized
DEBUG - 2011-04-30 13:25:42 --> UTF-8 Support Enabled
DEBUG - 2011-04-30 13:25:42 --> URI Class Initialized
DEBUG - 2011-04-30 13:25:42 --> Router Class Initialized
DEBUG - 2011-04-30 13:25:42 --> Output Class Initialized
DEBUG - 2011-04-30 13:25:42 --> Input Class Initialized
DEBUG - 2011-04-30 13:25:42 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-30 13:25:42 --> Language Class Initialized
DEBUG - 2011-04-30 13:25:42 --> Loader Class Initialized
DEBUG - 2011-04-30 13:25:42 --> Controller Class Initialized
DEBUG - 2011-04-30 13:25:42 --> Model Class Initialized
DEBUG - 2011-04-30 13:25:42 --> Model Class Initialized
DEBUG - 2011-04-30 13:25:42 --> Model Class Initialized
DEBUG - 2011-04-30 13:25:42 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-30 13:25:42 --> Database Driver Class Initialized
DEBUG - 2011-04-30 13:25:42 --> File loaded: application/views/table/main.php
DEBUG - 2011-04-30 13:25:42 --> Helper loaded: url_helper
DEBUG - 2011-04-30 13:25:42 --> File loaded: application/views/common/header.php
DEBUG - 2011-04-30 13:25:42 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-04-30 13:25:42 --> File loaded: application/views/common/footer.php
DEBUG - 2011-04-30 13:25:42 --> File loaded: application/views/layout/main.php
DEBUG - 2011-04-30 13:25:42 --> Final output sent to browser
DEBUG - 2011-04-30 13:25:42 --> Total execution time: 0.0527
DEBUG - 2011-04-30 13:25:56 --> Config Class Initialized
DEBUG - 2011-04-30 13:25:56 --> Hooks Class Initialized
DEBUG - 2011-04-30 13:25:56 --> Utf8 Class Initialized
DEBUG - 2011-04-30 13:25:56 --> UTF-8 Support Enabled
DEBUG - 2011-04-30 13:25:56 --> URI Class Initialized
DEBUG - 2011-04-30 13:25:56 --> Router Class Initialized
DEBUG - 2011-04-30 13:25:56 --> Output Class Initialized
DEBUG - 2011-04-30 13:25:56 --> Input Class Initialized
DEBUG - 2011-04-30 13:25:56 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-30 13:25:56 --> Language Class Initialized
DEBUG - 2011-04-30 13:25:56 --> Loader Class Initialized
DEBUG - 2011-04-30 13:25:56 --> Controller Class Initialized
DEBUG - 2011-04-30 13:25:56 --> Model Class Initialized
DEBUG - 2011-04-30 13:25:56 --> Model Class Initialized
DEBUG - 2011-04-30 13:25:56 --> Model Class Initialized
DEBUG - 2011-04-30 13:25:56 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-30 13:25:56 --> Database Driver Class Initialized
DEBUG - 2011-04-30 13:25:56 --> File loaded: application/views/table/main.php
DEBUG - 2011-04-30 13:25:56 --> Helper loaded: url_helper
DEBUG - 2011-04-30 13:25:56 --> File loaded: application/views/common/header.php
DEBUG - 2011-04-30 13:25:56 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-04-30 13:25:56 --> File loaded: application/views/common/footer.php
DEBUG - 2011-04-30 13:25:56 --> File loaded: application/views/layout/main.php
DEBUG - 2011-04-30 13:25:56 --> Final output sent to browser
DEBUG - 2011-04-30 13:25:56 --> Total execution time: 0.0519
DEBUG - 2011-04-30 13:26:21 --> Config Class Initialized
DEBUG - 2011-04-30 13:26:21 --> Hooks Class Initialized
DEBUG - 2011-04-30 13:26:21 --> Utf8 Class Initialized
DEBUG - 2011-04-30 13:26:21 --> UTF-8 Support Enabled
DEBUG - 2011-04-30 13:26:21 --> URI Class Initialized
DEBUG - 2011-04-30 13:26:21 --> Router Class Initialized
DEBUG - 2011-04-30 13:26:21 --> Output Class Initialized
DEBUG - 2011-04-30 13:26:21 --> Input Class Initialized
DEBUG - 2011-04-30 13:26:21 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-30 13:26:21 --> Language Class Initialized
DEBUG - 2011-04-30 13:26:21 --> Loader Class Initialized
DEBUG - 2011-04-30 13:26:21 --> Controller Class Initialized
DEBUG - 2011-04-30 13:26:21 --> Model Class Initialized
DEBUG - 2011-04-30 13:26:21 --> Model Class Initialized
DEBUG - 2011-04-30 13:26:21 --> Model Class Initialized
DEBUG - 2011-04-30 13:26:21 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-30 13:26:21 --> Database Driver Class Initialized
DEBUG - 2011-04-30 13:26:22 --> File loaded: application/views/table/main.php
DEBUG - 2011-04-30 13:26:22 --> Helper loaded: url_helper
DEBUG - 2011-04-30 13:26:22 --> File loaded: application/views/common/header.php
DEBUG - 2011-04-30 13:26:22 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-04-30 13:26:22 --> File loaded: application/views/common/footer.php
DEBUG - 2011-04-30 13:26:22 --> File loaded: application/views/layout/main.php
DEBUG - 2011-04-30 13:26:22 --> Final output sent to browser
DEBUG - 2011-04-30 13:26:22 --> Total execution time: 0.2767
DEBUG - 2011-04-30 13:26:23 --> Config Class Initialized
DEBUG - 2011-04-30 13:26:23 --> Hooks Class Initialized
DEBUG - 2011-04-30 13:26:23 --> Utf8 Class Initialized
DEBUG - 2011-04-30 13:26:23 --> UTF-8 Support Enabled
DEBUG - 2011-04-30 13:26:23 --> URI Class Initialized
DEBUG - 2011-04-30 13:26:23 --> Router Class Initialized
DEBUG - 2011-04-30 13:26:23 --> Output Class Initialized
DEBUG - 2011-04-30 13:26:23 --> Input Class Initialized
DEBUG - 2011-04-30 13:26:23 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-30 13:26:23 --> Language Class Initialized
DEBUG - 2011-04-30 13:26:23 --> Loader Class Initialized
DEBUG - 2011-04-30 13:26:23 --> Controller Class Initialized
DEBUG - 2011-04-30 13:26:23 --> Model Class Initialized
DEBUG - 2011-04-30 13:26:23 --> Model Class Initialized
DEBUG - 2011-04-30 13:26:23 --> Model Class Initialized
DEBUG - 2011-04-30 13:26:23 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-30 13:26:23 --> Database Driver Class Initialized
DEBUG - 2011-04-30 13:26:23 --> File loaded: application/views/table/main.php
DEBUG - 2011-04-30 13:26:23 --> Helper loaded: url_helper
DEBUG - 2011-04-30 13:26:23 --> File loaded: application/views/common/header.php
DEBUG - 2011-04-30 13:26:23 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-04-30 13:26:23 --> File loaded: application/views/common/footer.php
DEBUG - 2011-04-30 13:26:23 --> File loaded: application/views/layout/main.php
DEBUG - 2011-04-30 13:26:23 --> Final output sent to browser
DEBUG - 2011-04-30 13:26:23 --> Total execution time: 0.0447
DEBUG - 2011-04-30 13:26:23 --> Config Class Initialized
DEBUG - 2011-04-30 13:26:23 --> Hooks Class Initialized
DEBUG - 2011-04-30 13:26:23 --> Utf8 Class Initialized
DEBUG - 2011-04-30 13:26:23 --> UTF-8 Support Enabled
DEBUG - 2011-04-30 13:26:23 --> URI Class Initialized
DEBUG - 2011-04-30 13:26:23 --> Router Class Initialized
DEBUG - 2011-04-30 13:26:23 --> Output Class Initialized
DEBUG - 2011-04-30 13:26:23 --> Input Class Initialized
DEBUG - 2011-04-30 13:26:23 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-30 13:26:23 --> Language Class Initialized
DEBUG - 2011-04-30 13:26:23 --> Loader Class Initialized
DEBUG - 2011-04-30 13:26:23 --> Controller Class Initialized
DEBUG - 2011-04-30 13:26:23 --> Model Class Initialized
DEBUG - 2011-04-30 13:26:23 --> Model Class Initialized
DEBUG - 2011-04-30 13:26:23 --> Model Class Initialized
DEBUG - 2011-04-30 13:26:23 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-30 13:26:23 --> Database Driver Class Initialized
DEBUG - 2011-04-30 13:26:23 --> File loaded: application/views/table/main.php
DEBUG - 2011-04-30 13:26:23 --> Helper loaded: url_helper
DEBUG - 2011-04-30 13:26:23 --> File loaded: application/views/common/header.php
DEBUG - 2011-04-30 13:26:23 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-04-30 13:26:23 --> File loaded: application/views/common/footer.php
DEBUG - 2011-04-30 13:26:23 --> File loaded: application/views/layout/main.php
DEBUG - 2011-04-30 13:26:23 --> Final output sent to browser
DEBUG - 2011-04-30 13:26:23 --> Total execution time: 0.0441
DEBUG - 2011-04-30 13:26:37 --> Config Class Initialized
DEBUG - 2011-04-30 13:26:37 --> Hooks Class Initialized
DEBUG - 2011-04-30 13:26:37 --> Utf8 Class Initialized
DEBUG - 2011-04-30 13:26:37 --> UTF-8 Support Enabled
DEBUG - 2011-04-30 13:26:37 --> URI Class Initialized
DEBUG - 2011-04-30 13:26:37 --> Router Class Initialized
DEBUG - 2011-04-30 13:26:37 --> Output Class Initialized
DEBUG - 2011-04-30 13:26:37 --> Input Class Initialized
DEBUG - 2011-04-30 13:26:37 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-30 13:26:37 --> Language Class Initialized
DEBUG - 2011-04-30 13:26:37 --> Loader Class Initialized
DEBUG - 2011-04-30 13:26:37 --> Controller Class Initialized
DEBUG - 2011-04-30 13:26:37 --> Model Class Initialized
DEBUG - 2011-04-30 13:26:37 --> Model Class Initialized
DEBUG - 2011-04-30 13:26:37 --> Model Class Initialized
DEBUG - 2011-04-30 13:26:37 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-30 13:26:37 --> Database Driver Class Initialized
DEBUG - 2011-04-30 13:26:37 --> File loaded: application/views/table/main.php
DEBUG - 2011-04-30 13:26:37 --> Helper loaded: url_helper
DEBUG - 2011-04-30 13:26:37 --> File loaded: application/views/common/header.php
DEBUG - 2011-04-30 13:26:37 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-04-30 13:26:37 --> File loaded: application/views/common/footer.php
DEBUG - 2011-04-30 13:26:37 --> File loaded: application/views/layout/main.php
DEBUG - 2011-04-30 13:26:37 --> Final output sent to browser
DEBUG - 2011-04-30 13:26:37 --> Total execution time: 0.0526
DEBUG - 2011-04-30 13:26:38 --> Config Class Initialized
DEBUG - 2011-04-30 13:26:38 --> Hooks Class Initialized
DEBUG - 2011-04-30 13:26:38 --> Utf8 Class Initialized
DEBUG - 2011-04-30 13:26:38 --> UTF-8 Support Enabled
DEBUG - 2011-04-30 13:26:38 --> URI Class Initialized
DEBUG - 2011-04-30 13:26:38 --> Router Class Initialized
DEBUG - 2011-04-30 13:26:38 --> Output Class Initialized
DEBUG - 2011-04-30 13:26:38 --> Input Class Initialized
DEBUG - 2011-04-30 13:26:38 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-30 13:26:38 --> Language Class Initialized
DEBUG - 2011-04-30 13:26:38 --> Loader Class Initialized
DEBUG - 2011-04-30 13:26:38 --> Controller Class Initialized
DEBUG - 2011-04-30 13:26:38 --> Model Class Initialized
DEBUG - 2011-04-30 13:26:38 --> Model Class Initialized
DEBUG - 2011-04-30 13:26:38 --> Model Class Initialized
DEBUG - 2011-04-30 13:26:38 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-30 13:26:38 --> Database Driver Class Initialized
DEBUG - 2011-04-30 13:26:38 --> File loaded: application/views/table/main.php
DEBUG - 2011-04-30 13:26:38 --> Helper loaded: url_helper
DEBUG - 2011-04-30 13:26:38 --> File loaded: application/views/common/header.php
DEBUG - 2011-04-30 13:26:38 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-04-30 13:26:38 --> File loaded: application/views/common/footer.php
DEBUG - 2011-04-30 13:26:38 --> File loaded: application/views/layout/main.php
DEBUG - 2011-04-30 13:26:38 --> Final output sent to browser
DEBUG - 2011-04-30 13:26:38 --> Total execution time: 0.0495
DEBUG - 2011-04-30 13:26:50 --> Config Class Initialized
DEBUG - 2011-04-30 13:26:50 --> Hooks Class Initialized
DEBUG - 2011-04-30 13:26:50 --> Utf8 Class Initialized
DEBUG - 2011-04-30 13:26:50 --> UTF-8 Support Enabled
DEBUG - 2011-04-30 13:26:50 --> URI Class Initialized
DEBUG - 2011-04-30 13:26:50 --> Router Class Initialized
DEBUG - 2011-04-30 13:26:50 --> Output Class Initialized
DEBUG - 2011-04-30 13:26:50 --> Input Class Initialized
DEBUG - 2011-04-30 13:26:50 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-30 13:26:50 --> Language Class Initialized
DEBUG - 2011-04-30 13:26:50 --> Loader Class Initialized
DEBUG - 2011-04-30 13:26:50 --> Controller Class Initialized
DEBUG - 2011-04-30 13:26:50 --> Model Class Initialized
DEBUG - 2011-04-30 13:26:50 --> Model Class Initialized
DEBUG - 2011-04-30 13:26:50 --> Model Class Initialized
DEBUG - 2011-04-30 13:26:50 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-30 13:26:50 --> Database Driver Class Initialized
DEBUG - 2011-04-30 13:26:50 --> File loaded: application/views/table/main.php
DEBUG - 2011-04-30 13:26:50 --> Helper loaded: url_helper
DEBUG - 2011-04-30 13:26:50 --> File loaded: application/views/common/header.php
DEBUG - 2011-04-30 13:26:50 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-04-30 13:26:50 --> File loaded: application/views/common/footer.php
DEBUG - 2011-04-30 13:26:50 --> File loaded: application/views/layout/main.php
DEBUG - 2011-04-30 13:26:50 --> Final output sent to browser
DEBUG - 2011-04-30 13:26:50 --> Total execution time: 0.3105
DEBUG - 2011-04-30 13:26:52 --> Config Class Initialized
DEBUG - 2011-04-30 13:26:52 --> Hooks Class Initialized
DEBUG - 2011-04-30 13:26:52 --> Utf8 Class Initialized
DEBUG - 2011-04-30 13:26:52 --> UTF-8 Support Enabled
DEBUG - 2011-04-30 13:26:52 --> URI Class Initialized
DEBUG - 2011-04-30 13:26:52 --> Router Class Initialized
DEBUG - 2011-04-30 13:26:52 --> Output Class Initialized
DEBUG - 2011-04-30 13:26:52 --> Input Class Initialized
DEBUG - 2011-04-30 13:26:52 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-30 13:26:52 --> Language Class Initialized
DEBUG - 2011-04-30 13:26:52 --> Loader Class Initialized
DEBUG - 2011-04-30 13:26:52 --> Controller Class Initialized
DEBUG - 2011-04-30 13:26:52 --> Model Class Initialized
DEBUG - 2011-04-30 13:26:52 --> Model Class Initialized
DEBUG - 2011-04-30 13:26:52 --> Model Class Initialized
DEBUG - 2011-04-30 13:26:52 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-30 13:26:52 --> Database Driver Class Initialized
DEBUG - 2011-04-30 13:26:52 --> File loaded: application/views/table/main.php
DEBUG - 2011-04-30 13:26:52 --> Helper loaded: url_helper
DEBUG - 2011-04-30 13:26:52 --> File loaded: application/views/common/header.php
DEBUG - 2011-04-30 13:26:52 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-04-30 13:26:52 --> File loaded: application/views/common/footer.php
DEBUG - 2011-04-30 13:26:52 --> File loaded: application/views/layout/main.php
DEBUG - 2011-04-30 13:26:52 --> Final output sent to browser
DEBUG - 2011-04-30 13:26:52 --> Total execution time: 0.0506
DEBUG - 2011-04-30 13:32:49 --> Config Class Initialized
DEBUG - 2011-04-30 13:32:49 --> Hooks Class Initialized
DEBUG - 2011-04-30 13:32:49 --> Utf8 Class Initialized
DEBUG - 2011-04-30 13:32:49 --> UTF-8 Support Enabled
DEBUG - 2011-04-30 13:32:49 --> URI Class Initialized
DEBUG - 2011-04-30 13:32:49 --> Router Class Initialized
DEBUG - 2011-04-30 13:32:49 --> Output Class Initialized
DEBUG - 2011-04-30 13:32:49 --> Input Class Initialized
DEBUG - 2011-04-30 13:32:49 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-30 13:32:49 --> Language Class Initialized
DEBUG - 2011-04-30 13:32:49 --> Loader Class Initialized
DEBUG - 2011-04-30 13:32:49 --> Controller Class Initialized
DEBUG - 2011-04-30 13:32:49 --> Model Class Initialized
DEBUG - 2011-04-30 13:32:49 --> Model Class Initialized
DEBUG - 2011-04-30 13:32:49 --> Model Class Initialized
DEBUG - 2011-04-30 13:32:49 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-30 13:32:49 --> Database Driver Class Initialized
DEBUG - 2011-04-30 13:32:49 --> File loaded: application/views/table/main.php
DEBUG - 2011-04-30 13:32:49 --> Helper loaded: url_helper
DEBUG - 2011-04-30 13:32:49 --> File loaded: application/views/common/header.php
DEBUG - 2011-04-30 13:32:49 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-04-30 13:32:49 --> File loaded: application/views/common/footer.php
DEBUG - 2011-04-30 13:32:49 --> File loaded: application/views/layout/main.php
DEBUG - 2011-04-30 13:32:49 --> Final output sent to browser
DEBUG - 2011-04-30 13:32:49 --> Total execution time: 0.1169
DEBUG - 2011-04-30 13:36:16 --> Config Class Initialized
DEBUG - 2011-04-30 13:36:16 --> Hooks Class Initialized
DEBUG - 2011-04-30 13:36:16 --> Utf8 Class Initialized
DEBUG - 2011-04-30 13:36:16 --> UTF-8 Support Enabled
DEBUG - 2011-04-30 13:36:16 --> URI Class Initialized
DEBUG - 2011-04-30 13:36:16 --> Router Class Initialized
ERROR - 2011-04-30 13:36:16 --> 404 Page Not Found --> robots.txt
DEBUG - 2011-04-30 13:36:18 --> Config Class Initialized
DEBUG - 2011-04-30 13:36:18 --> Hooks Class Initialized
DEBUG - 2011-04-30 13:36:18 --> Utf8 Class Initialized
DEBUG - 2011-04-30 13:36:18 --> UTF-8 Support Enabled
DEBUG - 2011-04-30 13:36:18 --> URI Class Initialized
DEBUG - 2011-04-30 13:36:18 --> Router Class Initialized
DEBUG - 2011-04-30 13:36:18 --> Output Class Initialized
DEBUG - 2011-04-30 13:36:18 --> Input Class Initialized
DEBUG - 2011-04-30 13:36:18 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-30 13:36:18 --> Language Class Initialized
DEBUG - 2011-04-30 13:36:18 --> Loader Class Initialized
DEBUG - 2011-04-30 13:36:18 --> Controller Class Initialized
ERROR - 2011-04-30 13:36:18 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-04-30 13:36:18 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-04-30 13:36:18 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-04-30 13:36:18 --> Model Class Initialized
DEBUG - 2011-04-30 13:36:18 --> Model Class Initialized
DEBUG - 2011-04-30 13:36:18 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-30 13:36:18 --> Database Driver Class Initialized
DEBUG - 2011-04-30 13:36:18 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-04-30 13:36:18 --> Helper loaded: url_helper
DEBUG - 2011-04-30 13:36:18 --> File loaded: application/views/common/header.php
DEBUG - 2011-04-30 13:36:18 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-04-30 13:36:18 --> File loaded: application/views/common/footer.php
DEBUG - 2011-04-30 13:36:18 --> File loaded: application/views/layout/main.php
DEBUG - 2011-04-30 13:36:18 --> Final output sent to browser
DEBUG - 2011-04-30 13:36:18 --> Total execution time: 0.1065
DEBUG - 2011-04-30 13:44:41 --> Config Class Initialized
DEBUG - 2011-04-30 13:44:41 --> Hooks Class Initialized
DEBUG - 2011-04-30 13:44:41 --> Utf8 Class Initialized
DEBUG - 2011-04-30 13:44:41 --> UTF-8 Support Enabled
DEBUG - 2011-04-30 13:44:41 --> URI Class Initialized
DEBUG - 2011-04-30 13:44:41 --> Router Class Initialized
DEBUG - 2011-04-30 13:44:41 --> Output Class Initialized
DEBUG - 2011-04-30 13:44:41 --> Input Class Initialized
DEBUG - 2011-04-30 13:44:41 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-30 13:44:41 --> Language Class Initialized
DEBUG - 2011-04-30 13:44:41 --> Loader Class Initialized
DEBUG - 2011-04-30 13:44:41 --> Controller Class Initialized
DEBUG - 2011-04-30 13:44:41 --> Model Class Initialized
DEBUG - 2011-04-30 13:44:41 --> Model Class Initialized
DEBUG - 2011-04-30 13:44:41 --> Model Class Initialized
DEBUG - 2011-04-30 13:44:41 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-30 13:44:41 --> Database Driver Class Initialized
DEBUG - 2011-04-30 13:44:41 --> File loaded: application/views/table/main.php
DEBUG - 2011-04-30 13:44:41 --> Helper loaded: url_helper
DEBUG - 2011-04-30 13:44:41 --> File loaded: application/views/common/header.php
DEBUG - 2011-04-30 13:44:41 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-04-30 13:44:41 --> File loaded: application/views/common/footer.php
DEBUG - 2011-04-30 13:44:41 --> File loaded: application/views/layout/main.php
DEBUG - 2011-04-30 13:44:41 --> Final output sent to browser
DEBUG - 2011-04-30 13:44:41 --> Total execution time: 0.0633
DEBUG - 2011-04-30 13:51:42 --> Config Class Initialized
DEBUG - 2011-04-30 13:51:42 --> Hooks Class Initialized
DEBUG - 2011-04-30 13:51:42 --> Utf8 Class Initialized
DEBUG - 2011-04-30 13:51:42 --> UTF-8 Support Enabled
DEBUG - 2011-04-30 13:51:42 --> URI Class Initialized
DEBUG - 2011-04-30 13:51:42 --> Router Class Initialized
DEBUG - 2011-04-30 13:51:42 --> Output Class Initialized
DEBUG - 2011-04-30 13:51:42 --> Input Class Initialized
DEBUG - 2011-04-30 13:51:42 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-30 13:51:42 --> Language Class Initialized
DEBUG - 2011-04-30 13:51:42 --> Loader Class Initialized
DEBUG - 2011-04-30 13:51:42 --> Controller Class Initialized
DEBUG - 2011-04-30 13:51:42 --> Model Class Initialized
DEBUG - 2011-04-30 13:51:42 --> Model Class Initialized
DEBUG - 2011-04-30 13:51:42 --> Model Class Initialized
DEBUG - 2011-04-30 13:51:42 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-30 13:51:42 --> Database Driver Class Initialized
DEBUG - 2011-04-30 13:51:42 --> File loaded: application/views/table/main.php
DEBUG - 2011-04-30 13:51:42 --> Helper loaded: url_helper
DEBUG - 2011-04-30 13:51:42 --> File loaded: application/views/common/header.php
DEBUG - 2011-04-30 13:51:42 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-04-30 13:51:42 --> File loaded: application/views/common/footer.php
DEBUG - 2011-04-30 13:51:42 --> File loaded: application/views/layout/main.php
DEBUG - 2011-04-30 13:51:42 --> Final output sent to browser
DEBUG - 2011-04-30 13:51:42 --> Total execution time: 0.0736
DEBUG - 2011-04-30 13:51:45 --> Config Class Initialized
DEBUG - 2011-04-30 13:51:45 --> Hooks Class Initialized
DEBUG - 2011-04-30 13:51:45 --> Utf8 Class Initialized
DEBUG - 2011-04-30 13:51:45 --> UTF-8 Support Enabled
DEBUG - 2011-04-30 13:51:45 --> URI Class Initialized
DEBUG - 2011-04-30 13:51:45 --> Router Class Initialized
ERROR - 2011-04-30 13:51:45 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-04-30 13:51:48 --> Config Class Initialized
DEBUG - 2011-04-30 13:51:48 --> Hooks Class Initialized
DEBUG - 2011-04-30 13:51:48 --> Utf8 Class Initialized
DEBUG - 2011-04-30 13:51:48 --> UTF-8 Support Enabled
DEBUG - 2011-04-30 13:51:48 --> URI Class Initialized
DEBUG - 2011-04-30 13:51:48 --> Router Class Initialized
ERROR - 2011-04-30 13:51:48 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-04-30 13:51:51 --> Config Class Initialized
DEBUG - 2011-04-30 13:51:51 --> Hooks Class Initialized
DEBUG - 2011-04-30 13:51:51 --> Utf8 Class Initialized
DEBUG - 2011-04-30 13:51:51 --> UTF-8 Support Enabled
DEBUG - 2011-04-30 13:51:51 --> URI Class Initialized
DEBUG - 2011-04-30 13:51:51 --> Router Class Initialized
DEBUG - 2011-04-30 13:51:51 --> Output Class Initialized
DEBUG - 2011-04-30 13:51:51 --> Input Class Initialized
DEBUG - 2011-04-30 13:51:51 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-30 13:51:51 --> Language Class Initialized
DEBUG - 2011-04-30 13:51:51 --> Loader Class Initialized
DEBUG - 2011-04-30 13:51:51 --> Controller Class Initialized
DEBUG - 2011-04-30 13:51:51 --> Model Class Initialized
DEBUG - 2011-04-30 13:51:51 --> Model Class Initialized
DEBUG - 2011-04-30 13:51:51 --> Model Class Initialized
DEBUG - 2011-04-30 13:51:51 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-30 13:51:51 --> Database Driver Class Initialized
DEBUG - 2011-04-30 13:51:51 --> File loaded: application/views/table/main.php
DEBUG - 2011-04-30 13:51:51 --> Helper loaded: url_helper
DEBUG - 2011-04-30 13:51:51 --> File loaded: application/views/common/header.php
DEBUG - 2011-04-30 13:51:51 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-04-30 13:51:51 --> File loaded: application/views/common/footer.php
DEBUG - 2011-04-30 13:51:51 --> File loaded: application/views/layout/main.php
DEBUG - 2011-04-30 13:51:51 --> Final output sent to browser
DEBUG - 2011-04-30 13:51:51 --> Total execution time: 0.0568
DEBUG - 2011-04-30 13:53:32 --> Config Class Initialized
DEBUG - 2011-04-30 13:53:32 --> Hooks Class Initialized
DEBUG - 2011-04-30 13:53:32 --> Utf8 Class Initialized
DEBUG - 2011-04-30 13:53:32 --> UTF-8 Support Enabled
DEBUG - 2011-04-30 13:53:32 --> URI Class Initialized
DEBUG - 2011-04-30 13:53:32 --> Router Class Initialized
DEBUG - 2011-04-30 13:53:32 --> Output Class Initialized
DEBUG - 2011-04-30 13:53:32 --> Input Class Initialized
DEBUG - 2011-04-30 13:53:32 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-30 13:53:32 --> Language Class Initialized
DEBUG - 2011-04-30 13:53:32 --> Loader Class Initialized
DEBUG - 2011-04-30 13:53:32 --> Controller Class Initialized
DEBUG - 2011-04-30 13:53:32 --> Model Class Initialized
DEBUG - 2011-04-30 13:53:32 --> Model Class Initialized
DEBUG - 2011-04-30 13:53:32 --> Model Class Initialized
DEBUG - 2011-04-30 13:53:32 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-30 13:53:32 --> Database Driver Class Initialized
DEBUG - 2011-04-30 13:53:32 --> File loaded: application/views/table/main.php
DEBUG - 2011-04-30 13:53:32 --> Helper loaded: url_helper
DEBUG - 2011-04-30 13:53:32 --> File loaded: application/views/common/header.php
DEBUG - 2011-04-30 13:53:32 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-04-30 13:53:32 --> File loaded: application/views/common/footer.php
DEBUG - 2011-04-30 13:53:32 --> File loaded: application/views/layout/main.php
DEBUG - 2011-04-30 13:53:32 --> Final output sent to browser
DEBUG - 2011-04-30 13:53:32 --> Total execution time: 0.0464
DEBUG - 2011-04-30 13:53:50 --> Config Class Initialized
DEBUG - 2011-04-30 13:53:50 --> Hooks Class Initialized
DEBUG - 2011-04-30 13:53:50 --> Utf8 Class Initialized
DEBUG - 2011-04-30 13:53:50 --> UTF-8 Support Enabled
DEBUG - 2011-04-30 13:53:50 --> URI Class Initialized
DEBUG - 2011-04-30 13:53:50 --> Router Class Initialized
DEBUG - 2011-04-30 13:53:50 --> Output Class Initialized
DEBUG - 2011-04-30 13:53:50 --> Input Class Initialized
DEBUG - 2011-04-30 13:53:50 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-30 13:53:50 --> Language Class Initialized
DEBUG - 2011-04-30 13:53:50 --> Loader Class Initialized
DEBUG - 2011-04-30 13:53:50 --> Controller Class Initialized
DEBUG - 2011-04-30 13:53:50 --> Model Class Initialized
DEBUG - 2011-04-30 13:53:50 --> Model Class Initialized
DEBUG - 2011-04-30 13:53:50 --> Model Class Initialized
DEBUG - 2011-04-30 13:53:50 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-30 13:53:50 --> Database Driver Class Initialized
DEBUG - 2011-04-30 13:53:51 --> File loaded: application/views/table/main.php
DEBUG - 2011-04-30 13:53:51 --> Helper loaded: url_helper
DEBUG - 2011-04-30 13:53:51 --> File loaded: application/views/common/header.php
DEBUG - 2011-04-30 13:53:51 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-04-30 13:53:51 --> File loaded: application/views/common/footer.php
DEBUG - 2011-04-30 13:53:51 --> File loaded: application/views/layout/main.php
DEBUG - 2011-04-30 13:53:51 --> Final output sent to browser
DEBUG - 2011-04-30 13:53:51 --> Total execution time: 0.0502
DEBUG - 2011-04-30 13:53:55 --> Config Class Initialized
DEBUG - 2011-04-30 13:53:55 --> Hooks Class Initialized
DEBUG - 2011-04-30 13:53:55 --> Utf8 Class Initialized
DEBUG - 2011-04-30 13:53:55 --> UTF-8 Support Enabled
DEBUG - 2011-04-30 13:53:55 --> URI Class Initialized
DEBUG - 2011-04-30 13:53:55 --> Router Class Initialized
ERROR - 2011-04-30 13:53:55 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-04-30 13:53:55 --> Config Class Initialized
DEBUG - 2011-04-30 13:53:55 --> Hooks Class Initialized
DEBUG - 2011-04-30 13:53:55 --> Utf8 Class Initialized
DEBUG - 2011-04-30 13:53:55 --> UTF-8 Support Enabled
DEBUG - 2011-04-30 13:53:55 --> URI Class Initialized
DEBUG - 2011-04-30 13:53:55 --> Router Class Initialized
ERROR - 2011-04-30 13:53:55 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-04-30 13:53:56 --> Config Class Initialized
DEBUG - 2011-04-30 13:53:56 --> Hooks Class Initialized
DEBUG - 2011-04-30 13:53:56 --> Utf8 Class Initialized
DEBUG - 2011-04-30 13:53:56 --> UTF-8 Support Enabled
DEBUG - 2011-04-30 13:53:56 --> URI Class Initialized
DEBUG - 2011-04-30 13:53:56 --> Router Class Initialized
ERROR - 2011-04-30 13:53:56 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-04-30 13:55:08 --> Config Class Initialized
DEBUG - 2011-04-30 13:55:08 --> Hooks Class Initialized
DEBUG - 2011-04-30 13:55:08 --> Utf8 Class Initialized
DEBUG - 2011-04-30 13:55:08 --> UTF-8 Support Enabled
DEBUG - 2011-04-30 13:55:08 --> URI Class Initialized
DEBUG - 2011-04-30 13:55:08 --> Router Class Initialized
DEBUG - 2011-04-30 13:55:08 --> Output Class Initialized
DEBUG - 2011-04-30 13:55:08 --> Input Class Initialized
DEBUG - 2011-04-30 13:55:08 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-30 13:55:08 --> Language Class Initialized
DEBUG - 2011-04-30 13:55:08 --> Loader Class Initialized
DEBUG - 2011-04-30 13:55:08 --> Controller Class Initialized
DEBUG - 2011-04-30 13:55:08 --> Model Class Initialized
DEBUG - 2011-04-30 13:55:08 --> Model Class Initialized
DEBUG - 2011-04-30 13:55:08 --> Model Class Initialized
DEBUG - 2011-04-30 13:55:08 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-30 13:55:08 --> Database Driver Class Initialized
DEBUG - 2011-04-30 13:55:08 --> File loaded: application/views/table/main.php
DEBUG - 2011-04-30 13:55:08 --> Helper loaded: url_helper
DEBUG - 2011-04-30 13:55:08 --> File loaded: application/views/common/header.php
DEBUG - 2011-04-30 13:55:08 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-04-30 13:55:08 --> File loaded: application/views/common/footer.php
DEBUG - 2011-04-30 13:55:08 --> File loaded: application/views/layout/main.php
DEBUG - 2011-04-30 13:55:08 --> Final output sent to browser
DEBUG - 2011-04-30 13:55:08 --> Total execution time: 0.0476
DEBUG - 2011-04-30 13:55:10 --> Config Class Initialized
DEBUG - 2011-04-30 13:55:10 --> Hooks Class Initialized
DEBUG - 2011-04-30 13:55:10 --> Utf8 Class Initialized
DEBUG - 2011-04-30 13:55:10 --> UTF-8 Support Enabled
DEBUG - 2011-04-30 13:55:10 --> URI Class Initialized
DEBUG - 2011-04-30 13:55:10 --> Router Class Initialized
ERROR - 2011-04-30 13:55:10 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-04-30 13:55:11 --> Config Class Initialized
DEBUG - 2011-04-30 13:55:11 --> Hooks Class Initialized
DEBUG - 2011-04-30 13:55:11 --> Utf8 Class Initialized
DEBUG - 2011-04-30 13:55:11 --> UTF-8 Support Enabled
DEBUG - 2011-04-30 13:55:11 --> URI Class Initialized
DEBUG - 2011-04-30 13:55:11 --> Router Class Initialized
DEBUG - 2011-04-30 13:55:11 --> Output Class Initialized
DEBUG - 2011-04-30 13:55:11 --> Input Class Initialized
DEBUG - 2011-04-30 13:55:11 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-30 13:55:11 --> Language Class Initialized
DEBUG - 2011-04-30 13:55:11 --> Loader Class Initialized
DEBUG - 2011-04-30 13:55:11 --> Controller Class Initialized
DEBUG - 2011-04-30 13:55:11 --> Model Class Initialized
DEBUG - 2011-04-30 13:55:11 --> Model Class Initialized
DEBUG - 2011-04-30 13:55:11 --> Model Class Initialized
DEBUG - 2011-04-30 13:55:11 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-30 13:55:11 --> Database Driver Class Initialized
DEBUG - 2011-04-30 13:55:11 --> File loaded: application/views/table/main.php
DEBUG - 2011-04-30 13:55:11 --> Helper loaded: url_helper
DEBUG - 2011-04-30 13:55:11 --> File loaded: application/views/common/header.php
DEBUG - 2011-04-30 13:55:11 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-04-30 13:55:11 --> File loaded: application/views/common/footer.php
DEBUG - 2011-04-30 13:55:11 --> File loaded: application/views/layout/main.php
DEBUG - 2011-04-30 13:55:11 --> Final output sent to browser
DEBUG - 2011-04-30 13:55:11 --> Total execution time: 0.0461
DEBUG - 2011-04-30 13:55:13 --> Config Class Initialized
DEBUG - 2011-04-30 13:55:13 --> Hooks Class Initialized
DEBUG - 2011-04-30 13:55:13 --> Utf8 Class Initialized
DEBUG - 2011-04-30 13:55:13 --> UTF-8 Support Enabled
DEBUG - 2011-04-30 13:55:13 --> URI Class Initialized
DEBUG - 2011-04-30 13:55:13 --> Router Class Initialized
ERROR - 2011-04-30 13:55:13 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-04-30 13:55:23 --> Config Class Initialized
DEBUG - 2011-04-30 13:55:23 --> Hooks Class Initialized
DEBUG - 2011-04-30 13:55:23 --> Utf8 Class Initialized
DEBUG - 2011-04-30 13:55:23 --> UTF-8 Support Enabled
DEBUG - 2011-04-30 13:55:23 --> URI Class Initialized
DEBUG - 2011-04-30 13:55:23 --> Router Class Initialized
DEBUG - 2011-04-30 13:55:23 --> Output Class Initialized
DEBUG - 2011-04-30 13:55:23 --> Input Class Initialized
DEBUG - 2011-04-30 13:55:23 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-30 13:55:23 --> Language Class Initialized
DEBUG - 2011-04-30 13:55:23 --> Loader Class Initialized
DEBUG - 2011-04-30 13:55:23 --> Controller Class Initialized
DEBUG - 2011-04-30 13:55:23 --> Model Class Initialized
DEBUG - 2011-04-30 13:55:23 --> Model Class Initialized
DEBUG - 2011-04-30 13:55:23 --> Model Class Initialized
DEBUG - 2011-04-30 13:55:23 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-30 13:55:23 --> Database Driver Class Initialized
DEBUG - 2011-04-30 13:55:23 --> File loaded: application/views/table/main.php
DEBUG - 2011-04-30 13:55:23 --> Helper loaded: url_helper
DEBUG - 2011-04-30 13:55:23 --> File loaded: application/views/common/header.php
DEBUG - 2011-04-30 13:55:23 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-04-30 13:55:23 --> File loaded: application/views/common/footer.php
DEBUG - 2011-04-30 13:55:23 --> File loaded: application/views/layout/main.php
DEBUG - 2011-04-30 13:55:23 --> Final output sent to browser
DEBUG - 2011-04-30 13:55:23 --> Total execution time: 0.1826
DEBUG - 2011-04-30 13:55:44 --> Config Class Initialized
DEBUG - 2011-04-30 13:55:44 --> Hooks Class Initialized
DEBUG - 2011-04-30 13:55:44 --> Utf8 Class Initialized
DEBUG - 2011-04-30 13:55:44 --> UTF-8 Support Enabled
DEBUG - 2011-04-30 13:55:44 --> URI Class Initialized
DEBUG - 2011-04-30 13:55:44 --> Router Class Initialized
DEBUG - 2011-04-30 13:55:44 --> Output Class Initialized
DEBUG - 2011-04-30 13:55:44 --> Input Class Initialized
DEBUG - 2011-04-30 13:55:44 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-30 13:55:44 --> Language Class Initialized
DEBUG - 2011-04-30 13:55:44 --> Loader Class Initialized
DEBUG - 2011-04-30 13:55:44 --> Controller Class Initialized
DEBUG - 2011-04-30 13:55:44 --> Model Class Initialized
DEBUG - 2011-04-30 13:55:44 --> Model Class Initialized
DEBUG - 2011-04-30 13:55:44 --> Model Class Initialized
DEBUG - 2011-04-30 13:55:44 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-30 13:55:44 --> Database Driver Class Initialized
DEBUG - 2011-04-30 13:55:44 --> File loaded: application/views/table/main.php
DEBUG - 2011-04-30 13:55:44 --> Helper loaded: url_helper
DEBUG - 2011-04-30 13:55:44 --> File loaded: application/views/common/header.php
DEBUG - 2011-04-30 13:55:44 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-04-30 13:55:44 --> File loaded: application/views/common/footer.php
DEBUG - 2011-04-30 13:55:44 --> File loaded: application/views/layout/main.php
DEBUG - 2011-04-30 13:55:44 --> Final output sent to browser
DEBUG - 2011-04-30 13:55:44 --> Total execution time: 0.3228
DEBUG - 2011-04-30 13:56:03 --> Config Class Initialized
DEBUG - 2011-04-30 13:56:03 --> Hooks Class Initialized
DEBUG - 2011-04-30 13:56:03 --> Utf8 Class Initialized
DEBUG - 2011-04-30 13:56:03 --> UTF-8 Support Enabled
DEBUG - 2011-04-30 13:56:03 --> URI Class Initialized
DEBUG - 2011-04-30 13:56:03 --> Router Class Initialized
DEBUG - 2011-04-30 13:56:03 --> Output Class Initialized
DEBUG - 2011-04-30 13:56:03 --> Input Class Initialized
DEBUG - 2011-04-30 13:56:03 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-30 13:56:03 --> Language Class Initialized
DEBUG - 2011-04-30 13:56:03 --> Loader Class Initialized
DEBUG - 2011-04-30 13:56:03 --> Controller Class Initialized
DEBUG - 2011-04-30 13:56:03 --> Model Class Initialized
DEBUG - 2011-04-30 13:56:03 --> Model Class Initialized
DEBUG - 2011-04-30 13:56:03 --> Model Class Initialized
DEBUG - 2011-04-30 13:56:03 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-30 13:56:03 --> Database Driver Class Initialized
DEBUG - 2011-04-30 13:56:04 --> File loaded: application/views/table/main.php
DEBUG - 2011-04-30 13:56:04 --> Helper loaded: url_helper
DEBUG - 2011-04-30 13:56:04 --> File loaded: application/views/common/header.php
DEBUG - 2011-04-30 13:56:04 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-04-30 13:56:04 --> File loaded: application/views/common/footer.php
DEBUG - 2011-04-30 13:56:04 --> File loaded: application/views/layout/main.php
DEBUG - 2011-04-30 13:56:04 --> Final output sent to browser
DEBUG - 2011-04-30 13:56:04 --> Total execution time: 0.2881
DEBUG - 2011-04-30 13:56:36 --> Config Class Initialized
DEBUG - 2011-04-30 13:56:36 --> Hooks Class Initialized
DEBUG - 2011-04-30 13:56:36 --> Utf8 Class Initialized
DEBUG - 2011-04-30 13:56:36 --> UTF-8 Support Enabled
DEBUG - 2011-04-30 13:56:36 --> URI Class Initialized
DEBUG - 2011-04-30 13:56:36 --> Router Class Initialized
DEBUG - 2011-04-30 13:56:36 --> Output Class Initialized
DEBUG - 2011-04-30 13:56:36 --> Input Class Initialized
DEBUG - 2011-04-30 13:56:36 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-30 13:56:36 --> Language Class Initialized
DEBUG - 2011-04-30 13:56:36 --> Loader Class Initialized
DEBUG - 2011-04-30 13:56:36 --> Controller Class Initialized
DEBUG - 2011-04-30 13:56:36 --> Model Class Initialized
DEBUG - 2011-04-30 13:56:36 --> Model Class Initialized
DEBUG - 2011-04-30 13:56:36 --> Model Class Initialized
DEBUG - 2011-04-30 13:56:36 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-30 13:56:36 --> Database Driver Class Initialized
DEBUG - 2011-04-30 13:56:36 --> File loaded: application/views/table/main.php
DEBUG - 2011-04-30 13:56:36 --> Helper loaded: url_helper
DEBUG - 2011-04-30 13:56:36 --> File loaded: application/views/common/header.php
DEBUG - 2011-04-30 13:56:36 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-04-30 13:56:36 --> File loaded: application/views/common/footer.php
DEBUG - 2011-04-30 13:56:36 --> File loaded: application/views/layout/main.php
DEBUG - 2011-04-30 13:56:36 --> Final output sent to browser
DEBUG - 2011-04-30 13:56:36 --> Total execution time: 0.2015
DEBUG - 2011-04-30 13:56:44 --> Config Class Initialized
DEBUG - 2011-04-30 13:56:44 --> Hooks Class Initialized
DEBUG - 2011-04-30 13:56:44 --> Utf8 Class Initialized
DEBUG - 2011-04-30 13:56:44 --> UTF-8 Support Enabled
DEBUG - 2011-04-30 13:56:44 --> URI Class Initialized
DEBUG - 2011-04-30 13:56:44 --> Router Class Initialized
DEBUG - 2011-04-30 13:56:44 --> Output Class Initialized
DEBUG - 2011-04-30 13:56:44 --> Input Class Initialized
DEBUG - 2011-04-30 13:56:44 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-30 13:56:44 --> Language Class Initialized
DEBUG - 2011-04-30 13:56:44 --> Loader Class Initialized
DEBUG - 2011-04-30 13:56:44 --> Controller Class Initialized
DEBUG - 2011-04-30 13:56:44 --> Model Class Initialized
DEBUG - 2011-04-30 13:56:44 --> Model Class Initialized
DEBUG - 2011-04-30 13:56:44 --> Model Class Initialized
DEBUG - 2011-04-30 13:56:44 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-30 13:56:44 --> Database Driver Class Initialized
DEBUG - 2011-04-30 13:56:44 --> File loaded: application/views/table/main.php
DEBUG - 2011-04-30 13:56:44 --> Helper loaded: url_helper
DEBUG - 2011-04-30 13:56:44 --> File loaded: application/views/common/header.php
DEBUG - 2011-04-30 13:56:44 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-04-30 13:56:44 --> File loaded: application/views/common/footer.php
DEBUG - 2011-04-30 13:56:44 --> File loaded: application/views/layout/main.php
DEBUG - 2011-04-30 13:56:44 --> Final output sent to browser
DEBUG - 2011-04-30 13:56:44 --> Total execution time: 0.2347
DEBUG - 2011-04-30 13:58:15 --> Config Class Initialized
DEBUG - 2011-04-30 13:58:15 --> Hooks Class Initialized
DEBUG - 2011-04-30 13:58:15 --> Utf8 Class Initialized
DEBUG - 2011-04-30 13:58:15 --> UTF-8 Support Enabled
DEBUG - 2011-04-30 13:58:15 --> URI Class Initialized
DEBUG - 2011-04-30 13:58:15 --> Router Class Initialized
DEBUG - 2011-04-30 13:58:15 --> Output Class Initialized
DEBUG - 2011-04-30 13:58:15 --> Input Class Initialized
DEBUG - 2011-04-30 13:58:15 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-30 13:58:15 --> Language Class Initialized
DEBUG - 2011-04-30 13:58:15 --> Loader Class Initialized
DEBUG - 2011-04-30 13:58:15 --> Controller Class Initialized
DEBUG - 2011-04-30 13:58:15 --> Model Class Initialized
DEBUG - 2011-04-30 13:58:15 --> Model Class Initialized
DEBUG - 2011-04-30 13:58:15 --> Model Class Initialized
DEBUG - 2011-04-30 13:58:15 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-30 13:58:15 --> Database Driver Class Initialized
DEBUG - 2011-04-30 13:58:15 --> File loaded: application/views/table/main.php
DEBUG - 2011-04-30 13:58:15 --> Helper loaded: url_helper
DEBUG - 2011-04-30 13:58:15 --> File loaded: application/views/common/header.php
DEBUG - 2011-04-30 13:58:15 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-04-30 13:58:15 --> File loaded: application/views/common/footer.php
DEBUG - 2011-04-30 13:58:15 --> File loaded: application/views/layout/main.php
DEBUG - 2011-04-30 13:58:15 --> Final output sent to browser
DEBUG - 2011-04-30 13:58:15 --> Total execution time: 0.1956
DEBUG - 2011-04-30 13:58:30 --> Config Class Initialized
DEBUG - 2011-04-30 13:58:30 --> Hooks Class Initialized
DEBUG - 2011-04-30 13:58:30 --> Utf8 Class Initialized
DEBUG - 2011-04-30 13:58:30 --> UTF-8 Support Enabled
DEBUG - 2011-04-30 13:58:30 --> URI Class Initialized
DEBUG - 2011-04-30 13:58:30 --> Router Class Initialized
DEBUG - 2011-04-30 13:58:30 --> Output Class Initialized
DEBUG - 2011-04-30 13:58:30 --> Input Class Initialized
DEBUG - 2011-04-30 13:58:30 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-30 13:58:30 --> Language Class Initialized
DEBUG - 2011-04-30 13:58:30 --> Loader Class Initialized
DEBUG - 2011-04-30 13:58:30 --> Controller Class Initialized
DEBUG - 2011-04-30 13:58:30 --> Model Class Initialized
DEBUG - 2011-04-30 13:58:30 --> Model Class Initialized
DEBUG - 2011-04-30 13:58:30 --> Model Class Initialized
DEBUG - 2011-04-30 13:58:30 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-30 13:58:30 --> Database Driver Class Initialized
DEBUG - 2011-04-30 13:58:30 --> File loaded: application/views/table/main.php
DEBUG - 2011-04-30 13:58:30 --> Helper loaded: url_helper
DEBUG - 2011-04-30 13:58:30 --> File loaded: application/views/common/header.php
DEBUG - 2011-04-30 13:58:30 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-04-30 13:58:30 --> File loaded: application/views/common/footer.php
DEBUG - 2011-04-30 13:58:30 --> File loaded: application/views/layout/main.php
DEBUG - 2011-04-30 13:58:30 --> Final output sent to browser
DEBUG - 2011-04-30 13:58:30 --> Total execution time: 0.0500
DEBUG - 2011-04-30 13:58:37 --> Config Class Initialized
DEBUG - 2011-04-30 13:58:37 --> Hooks Class Initialized
DEBUG - 2011-04-30 13:58:37 --> Utf8 Class Initialized
DEBUG - 2011-04-30 13:58:37 --> UTF-8 Support Enabled
DEBUG - 2011-04-30 13:58:37 --> URI Class Initialized
DEBUG - 2011-04-30 13:58:37 --> Router Class Initialized
DEBUG - 2011-04-30 13:58:37 --> Output Class Initialized
DEBUG - 2011-04-30 13:58:37 --> Input Class Initialized
DEBUG - 2011-04-30 13:58:37 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-30 13:58:37 --> Language Class Initialized
DEBUG - 2011-04-30 13:58:37 --> Loader Class Initialized
DEBUG - 2011-04-30 13:58:37 --> Controller Class Initialized
DEBUG - 2011-04-30 13:58:37 --> Model Class Initialized
DEBUG - 2011-04-30 13:58:37 --> Model Class Initialized
DEBUG - 2011-04-30 13:58:37 --> Model Class Initialized
DEBUG - 2011-04-30 13:58:37 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-30 13:58:37 --> Database Driver Class Initialized
DEBUG - 2011-04-30 13:58:38 --> File loaded: application/views/table/main.php
DEBUG - 2011-04-30 13:58:38 --> Helper loaded: url_helper
DEBUG - 2011-04-30 13:58:38 --> File loaded: application/views/common/header.php
DEBUG - 2011-04-30 13:58:38 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-04-30 13:58:38 --> File loaded: application/views/common/footer.php
DEBUG - 2011-04-30 13:58:38 --> File loaded: application/views/layout/main.php
DEBUG - 2011-04-30 13:58:38 --> Final output sent to browser
DEBUG - 2011-04-30 13:58:38 --> Total execution time: 0.1929
DEBUG - 2011-04-30 13:59:03 --> Config Class Initialized
DEBUG - 2011-04-30 13:59:03 --> Hooks Class Initialized
DEBUG - 2011-04-30 13:59:03 --> Utf8 Class Initialized
DEBUG - 2011-04-30 13:59:03 --> UTF-8 Support Enabled
DEBUG - 2011-04-30 13:59:03 --> URI Class Initialized
DEBUG - 2011-04-30 13:59:03 --> Router Class Initialized
DEBUG - 2011-04-30 13:59:03 --> Output Class Initialized
DEBUG - 2011-04-30 13:59:03 --> Input Class Initialized
DEBUG - 2011-04-30 13:59:03 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-30 13:59:03 --> Language Class Initialized
DEBUG - 2011-04-30 13:59:03 --> Loader Class Initialized
DEBUG - 2011-04-30 13:59:03 --> Controller Class Initialized
DEBUG - 2011-04-30 13:59:03 --> Model Class Initialized
DEBUG - 2011-04-30 13:59:03 --> Model Class Initialized
DEBUG - 2011-04-30 13:59:03 --> Model Class Initialized
DEBUG - 2011-04-30 13:59:03 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-30 13:59:03 --> Database Driver Class Initialized
DEBUG - 2011-04-30 13:59:03 --> File loaded: application/views/table/main.php
DEBUG - 2011-04-30 13:59:03 --> Helper loaded: url_helper
DEBUG - 2011-04-30 13:59:03 --> File loaded: application/views/common/header.php
DEBUG - 2011-04-30 13:59:03 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-04-30 13:59:03 --> File loaded: application/views/common/footer.php
DEBUG - 2011-04-30 13:59:03 --> File loaded: application/views/layout/main.php
DEBUG - 2011-04-30 13:59:03 --> Final output sent to browser
DEBUG - 2011-04-30 13:59:03 --> Total execution time: 0.2006
DEBUG - 2011-04-30 13:59:23 --> Config Class Initialized
DEBUG - 2011-04-30 13:59:23 --> Hooks Class Initialized
DEBUG - 2011-04-30 13:59:23 --> Utf8 Class Initialized
DEBUG - 2011-04-30 13:59:23 --> UTF-8 Support Enabled
DEBUG - 2011-04-30 13:59:23 --> URI Class Initialized
DEBUG - 2011-04-30 13:59:23 --> Router Class Initialized
DEBUG - 2011-04-30 13:59:23 --> Output Class Initialized
DEBUG - 2011-04-30 13:59:23 --> Input Class Initialized
DEBUG - 2011-04-30 13:59:23 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-30 13:59:23 --> Language Class Initialized
DEBUG - 2011-04-30 13:59:23 --> Loader Class Initialized
DEBUG - 2011-04-30 13:59:23 --> Controller Class Initialized
DEBUG - 2011-04-30 13:59:23 --> Model Class Initialized
DEBUG - 2011-04-30 13:59:23 --> Model Class Initialized
DEBUG - 2011-04-30 13:59:23 --> Model Class Initialized
DEBUG - 2011-04-30 13:59:23 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-30 13:59:23 --> Database Driver Class Initialized
DEBUG - 2011-04-30 13:59:23 --> File loaded: application/views/table/main.php
DEBUG - 2011-04-30 13:59:23 --> Helper loaded: url_helper
DEBUG - 2011-04-30 13:59:23 --> File loaded: application/views/common/header.php
DEBUG - 2011-04-30 13:59:23 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-04-30 13:59:23 --> File loaded: application/views/common/footer.php
DEBUG - 2011-04-30 13:59:23 --> File loaded: application/views/layout/main.php
DEBUG - 2011-04-30 13:59:23 --> Final output sent to browser
DEBUG - 2011-04-30 13:59:23 --> Total execution time: 0.2285
DEBUG - 2011-04-30 14:00:06 --> Config Class Initialized
DEBUG - 2011-04-30 14:00:06 --> Hooks Class Initialized
DEBUG - 2011-04-30 14:00:06 --> Utf8 Class Initialized
DEBUG - 2011-04-30 14:00:06 --> UTF-8 Support Enabled
DEBUG - 2011-04-30 14:00:06 --> URI Class Initialized
DEBUG - 2011-04-30 14:00:06 --> Router Class Initialized
DEBUG - 2011-04-30 14:00:06 --> Output Class Initialized
DEBUG - 2011-04-30 14:00:06 --> Input Class Initialized
DEBUG - 2011-04-30 14:00:06 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-30 14:00:06 --> Language Class Initialized
DEBUG - 2011-04-30 14:00:06 --> Loader Class Initialized
DEBUG - 2011-04-30 14:00:06 --> Controller Class Initialized
DEBUG - 2011-04-30 14:00:06 --> Model Class Initialized
DEBUG - 2011-04-30 14:00:06 --> Model Class Initialized
DEBUG - 2011-04-30 14:00:06 --> Model Class Initialized
DEBUG - 2011-04-30 14:00:06 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-30 14:00:06 --> Database Driver Class Initialized
DEBUG - 2011-04-30 14:00:06 --> File loaded: application/views/table/main.php
DEBUG - 2011-04-30 14:00:06 --> Helper loaded: url_helper
DEBUG - 2011-04-30 14:00:06 --> File loaded: application/views/common/header.php
DEBUG - 2011-04-30 14:00:06 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-04-30 14:00:06 --> File loaded: application/views/common/footer.php
DEBUG - 2011-04-30 14:00:06 --> File loaded: application/views/layout/main.php
DEBUG - 2011-04-30 14:00:06 --> Final output sent to browser
DEBUG - 2011-04-30 14:00:06 --> Total execution time: 0.2634
DEBUG - 2011-04-30 14:35:00 --> Config Class Initialized
DEBUG - 2011-04-30 14:35:00 --> Hooks Class Initialized
DEBUG - 2011-04-30 14:35:00 --> Utf8 Class Initialized
DEBUG - 2011-04-30 14:35:00 --> UTF-8 Support Enabled
DEBUG - 2011-04-30 14:35:00 --> URI Class Initialized
DEBUG - 2011-04-30 14:35:00 --> Router Class Initialized
DEBUG - 2011-04-30 14:35:00 --> Output Class Initialized
DEBUG - 2011-04-30 14:35:00 --> Input Class Initialized
DEBUG - 2011-04-30 14:35:00 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-30 14:35:00 --> Language Class Initialized
DEBUG - 2011-04-30 14:35:00 --> Loader Class Initialized
DEBUG - 2011-04-30 14:35:00 --> Controller Class Initialized
DEBUG - 2011-04-30 14:35:00 --> Model Class Initialized
DEBUG - 2011-04-30 14:35:00 --> Model Class Initialized
DEBUG - 2011-04-30 14:35:00 --> Model Class Initialized
DEBUG - 2011-04-30 14:35:00 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-30 14:35:00 --> Database Driver Class Initialized
DEBUG - 2011-04-30 14:35:00 --> File loaded: application/views/table/main.php
DEBUG - 2011-04-30 14:35:00 --> Helper loaded: url_helper
DEBUG - 2011-04-30 14:35:00 --> File loaded: application/views/common/header.php
DEBUG - 2011-04-30 14:35:00 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-04-30 14:35:00 --> File loaded: application/views/common/footer.php
DEBUG - 2011-04-30 14:35:00 --> File loaded: application/views/layout/main.php
DEBUG - 2011-04-30 14:35:00 --> Final output sent to browser
DEBUG - 2011-04-30 14:35:00 --> Total execution time: 0.4403
DEBUG - 2011-04-30 14:35:37 --> Config Class Initialized
DEBUG - 2011-04-30 14:35:37 --> Hooks Class Initialized
DEBUG - 2011-04-30 14:35:37 --> Utf8 Class Initialized
DEBUG - 2011-04-30 14:35:37 --> UTF-8 Support Enabled
DEBUG - 2011-04-30 14:35:37 --> URI Class Initialized
DEBUG - 2011-04-30 14:35:37 --> Router Class Initialized
DEBUG - 2011-04-30 14:35:37 --> Output Class Initialized
DEBUG - 2011-04-30 14:35:37 --> Input Class Initialized
DEBUG - 2011-04-30 14:35:37 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-30 14:35:37 --> Language Class Initialized
DEBUG - 2011-04-30 14:35:37 --> Loader Class Initialized
DEBUG - 2011-04-30 14:35:37 --> Controller Class Initialized
DEBUG - 2011-04-30 14:35:37 --> Model Class Initialized
DEBUG - 2011-04-30 14:35:37 --> Model Class Initialized
DEBUG - 2011-04-30 14:35:37 --> Model Class Initialized
DEBUG - 2011-04-30 14:35:37 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-30 14:35:37 --> Database Driver Class Initialized
DEBUG - 2011-04-30 14:35:38 --> File loaded: application/views/table/main.php
DEBUG - 2011-04-30 14:35:38 --> Helper loaded: url_helper
DEBUG - 2011-04-30 14:35:38 --> File loaded: application/views/common/header.php
DEBUG - 2011-04-30 14:35:38 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-04-30 14:35:38 --> File loaded: application/views/common/footer.php
DEBUG - 2011-04-30 14:35:38 --> File loaded: application/views/layout/main.php
DEBUG - 2011-04-30 14:35:38 --> Final output sent to browser
DEBUG - 2011-04-30 14:35:38 --> Total execution time: 0.0514
DEBUG - 2011-04-30 14:35:39 --> Config Class Initialized
DEBUG - 2011-04-30 14:35:39 --> Hooks Class Initialized
DEBUG - 2011-04-30 14:35:39 --> Utf8 Class Initialized
DEBUG - 2011-04-30 14:35:39 --> UTF-8 Support Enabled
DEBUG - 2011-04-30 14:35:39 --> URI Class Initialized
DEBUG - 2011-04-30 14:35:39 --> Router Class Initialized
DEBUG - 2011-04-30 14:35:39 --> Output Class Initialized
DEBUG - 2011-04-30 14:35:39 --> Input Class Initialized
DEBUG - 2011-04-30 14:35:39 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-30 14:35:39 --> Language Class Initialized
DEBUG - 2011-04-30 14:35:39 --> Loader Class Initialized
DEBUG - 2011-04-30 14:35:39 --> Controller Class Initialized
DEBUG - 2011-04-30 14:35:39 --> Model Class Initialized
DEBUG - 2011-04-30 14:35:39 --> Model Class Initialized
DEBUG - 2011-04-30 14:35:39 --> Model Class Initialized
DEBUG - 2011-04-30 14:35:39 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-30 14:35:39 --> Database Driver Class Initialized
DEBUG - 2011-04-30 14:35:39 --> File loaded: application/views/table/main.php
DEBUG - 2011-04-30 14:35:39 --> Helper loaded: url_helper
DEBUG - 2011-04-30 14:35:39 --> File loaded: application/views/common/header.php
DEBUG - 2011-04-30 14:35:39 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-04-30 14:35:39 --> File loaded: application/views/common/footer.php
DEBUG - 2011-04-30 14:35:39 --> File loaded: application/views/layout/main.php
DEBUG - 2011-04-30 14:35:39 --> Final output sent to browser
DEBUG - 2011-04-30 14:35:39 --> Total execution time: 0.0544
DEBUG - 2011-04-30 14:36:00 --> Config Class Initialized
DEBUG - 2011-04-30 14:36:00 --> Hooks Class Initialized
DEBUG - 2011-04-30 14:36:00 --> Utf8 Class Initialized
DEBUG - 2011-04-30 14:36:00 --> UTF-8 Support Enabled
DEBUG - 2011-04-30 14:36:00 --> URI Class Initialized
DEBUG - 2011-04-30 14:36:00 --> Router Class Initialized
DEBUG - 2011-04-30 14:36:00 --> Output Class Initialized
DEBUG - 2011-04-30 14:36:00 --> Input Class Initialized
DEBUG - 2011-04-30 14:36:00 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-30 14:36:00 --> Language Class Initialized
DEBUG - 2011-04-30 14:36:00 --> Loader Class Initialized
DEBUG - 2011-04-30 14:36:00 --> Controller Class Initialized
DEBUG - 2011-04-30 14:36:00 --> Model Class Initialized
DEBUG - 2011-04-30 14:36:00 --> Model Class Initialized
DEBUG - 2011-04-30 14:36:00 --> Model Class Initialized
DEBUG - 2011-04-30 14:36:00 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-30 14:36:00 --> Database Driver Class Initialized
DEBUG - 2011-04-30 14:36:01 --> File loaded: application/views/table/main.php
DEBUG - 2011-04-30 14:36:01 --> Helper loaded: url_helper
DEBUG - 2011-04-30 14:36:01 --> File loaded: application/views/common/header.php
DEBUG - 2011-04-30 14:36:01 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-04-30 14:36:01 --> File loaded: application/views/common/footer.php
DEBUG - 2011-04-30 14:36:01 --> File loaded: application/views/layout/main.php
DEBUG - 2011-04-30 14:36:01 --> Final output sent to browser
DEBUG - 2011-04-30 14:36:01 --> Total execution time: 1.2043
DEBUG - 2011-04-30 14:36:05 --> Config Class Initialized
DEBUG - 2011-04-30 14:36:05 --> Hooks Class Initialized
DEBUG - 2011-04-30 14:36:05 --> Utf8 Class Initialized
DEBUG - 2011-04-30 14:36:05 --> UTF-8 Support Enabled
DEBUG - 2011-04-30 14:36:05 --> URI Class Initialized
DEBUG - 2011-04-30 14:36:05 --> Router Class Initialized
DEBUG - 2011-04-30 14:36:05 --> Output Class Initialized
DEBUG - 2011-04-30 14:36:05 --> Input Class Initialized
DEBUG - 2011-04-30 14:36:05 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-30 14:36:05 --> Language Class Initialized
DEBUG - 2011-04-30 14:36:05 --> Loader Class Initialized
DEBUG - 2011-04-30 14:36:05 --> Controller Class Initialized
DEBUG - 2011-04-30 14:36:05 --> Model Class Initialized
DEBUG - 2011-04-30 14:36:05 --> Model Class Initialized
DEBUG - 2011-04-30 14:36:05 --> Model Class Initialized
DEBUG - 2011-04-30 14:36:05 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-30 14:36:05 --> Database Driver Class Initialized
DEBUG - 2011-04-30 14:36:05 --> File loaded: application/views/table/main.php
DEBUG - 2011-04-30 14:36:05 --> Helper loaded: url_helper
DEBUG - 2011-04-30 14:36:05 --> File loaded: application/views/common/header.php
DEBUG - 2011-04-30 14:36:05 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-04-30 14:36:05 --> File loaded: application/views/common/footer.php
DEBUG - 2011-04-30 14:36:05 --> File loaded: application/views/layout/main.php
DEBUG - 2011-04-30 14:36:05 --> Final output sent to browser
DEBUG - 2011-04-30 14:36:05 --> Total execution time: 0.0490
DEBUG - 2011-04-30 14:36:09 --> Config Class Initialized
DEBUG - 2011-04-30 14:36:09 --> Hooks Class Initialized
DEBUG - 2011-04-30 14:36:09 --> Utf8 Class Initialized
DEBUG - 2011-04-30 14:36:09 --> UTF-8 Support Enabled
DEBUG - 2011-04-30 14:36:09 --> URI Class Initialized
DEBUG - 2011-04-30 14:36:09 --> Router Class Initialized
DEBUG - 2011-04-30 14:36:09 --> Output Class Initialized
DEBUG - 2011-04-30 14:36:09 --> Input Class Initialized
DEBUG - 2011-04-30 14:36:09 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-30 14:36:09 --> Language Class Initialized
DEBUG - 2011-04-30 14:36:09 --> Loader Class Initialized
DEBUG - 2011-04-30 14:36:09 --> Controller Class Initialized
DEBUG - 2011-04-30 14:36:09 --> Model Class Initialized
DEBUG - 2011-04-30 14:36:09 --> Model Class Initialized
DEBUG - 2011-04-30 14:36:09 --> Model Class Initialized
DEBUG - 2011-04-30 14:36:09 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-30 14:36:09 --> Database Driver Class Initialized
DEBUG - 2011-04-30 14:36:09 --> File loaded: application/views/table/main.php
DEBUG - 2011-04-30 14:36:09 --> Helper loaded: url_helper
DEBUG - 2011-04-30 14:36:09 --> File loaded: application/views/common/header.php
DEBUG - 2011-04-30 14:36:09 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-04-30 14:36:09 --> File loaded: application/views/common/footer.php
DEBUG - 2011-04-30 14:36:09 --> File loaded: application/views/layout/main.php
DEBUG - 2011-04-30 14:36:09 --> Final output sent to browser
DEBUG - 2011-04-30 14:36:09 --> Total execution time: 0.0491
DEBUG - 2011-04-30 14:36:25 --> Config Class Initialized
DEBUG - 2011-04-30 14:36:25 --> Hooks Class Initialized
DEBUG - 2011-04-30 14:36:25 --> Utf8 Class Initialized
DEBUG - 2011-04-30 14:36:25 --> UTF-8 Support Enabled
DEBUG - 2011-04-30 14:36:25 --> URI Class Initialized
DEBUG - 2011-04-30 14:36:25 --> Router Class Initialized
DEBUG - 2011-04-30 14:36:25 --> Output Class Initialized
DEBUG - 2011-04-30 14:36:25 --> Input Class Initialized
DEBUG - 2011-04-30 14:36:25 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-30 14:36:25 --> Language Class Initialized
DEBUG - 2011-04-30 14:36:25 --> Loader Class Initialized
DEBUG - 2011-04-30 14:36:25 --> Controller Class Initialized
DEBUG - 2011-04-30 14:36:25 --> Model Class Initialized
DEBUG - 2011-04-30 14:36:25 --> Model Class Initialized
DEBUG - 2011-04-30 14:36:25 --> Model Class Initialized
DEBUG - 2011-04-30 14:36:25 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-30 14:36:25 --> Database Driver Class Initialized
DEBUG - 2011-04-30 14:36:26 --> File loaded: application/views/table/main.php
DEBUG - 2011-04-30 14:36:26 --> Helper loaded: url_helper
DEBUG - 2011-04-30 14:36:26 --> File loaded: application/views/common/header.php
DEBUG - 2011-04-30 14:36:26 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-04-30 14:36:26 --> File loaded: application/views/common/footer.php
DEBUG - 2011-04-30 14:36:26 --> File loaded: application/views/layout/main.php
DEBUG - 2011-04-30 14:36:26 --> Final output sent to browser
DEBUG - 2011-04-30 14:36:26 --> Total execution time: 0.4899
DEBUG - 2011-04-30 14:36:47 --> Config Class Initialized
DEBUG - 2011-04-30 14:36:47 --> Hooks Class Initialized
DEBUG - 2011-04-30 14:36:47 --> Utf8 Class Initialized
DEBUG - 2011-04-30 14:36:47 --> UTF-8 Support Enabled
DEBUG - 2011-04-30 14:36:47 --> URI Class Initialized
DEBUG - 2011-04-30 14:36:47 --> Router Class Initialized
DEBUG - 2011-04-30 14:36:47 --> Output Class Initialized
DEBUG - 2011-04-30 14:36:47 --> Input Class Initialized
DEBUG - 2011-04-30 14:36:47 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-30 14:36:47 --> Language Class Initialized
DEBUG - 2011-04-30 14:36:47 --> Loader Class Initialized
DEBUG - 2011-04-30 14:36:47 --> Controller Class Initialized
DEBUG - 2011-04-30 14:36:47 --> Model Class Initialized
DEBUG - 2011-04-30 14:36:47 --> Model Class Initialized
DEBUG - 2011-04-30 14:36:47 --> Model Class Initialized
DEBUG - 2011-04-30 14:36:47 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-30 14:36:47 --> Database Driver Class Initialized
DEBUG - 2011-04-30 14:36:47 --> File loaded: application/views/table/main.php
DEBUG - 2011-04-30 14:36:47 --> Helper loaded: url_helper
DEBUG - 2011-04-30 14:36:47 --> File loaded: application/views/common/header.php
DEBUG - 2011-04-30 14:36:47 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-04-30 14:36:47 --> File loaded: application/views/common/footer.php
DEBUG - 2011-04-30 14:36:47 --> File loaded: application/views/layout/main.php
DEBUG - 2011-04-30 14:36:47 --> Final output sent to browser
DEBUG - 2011-04-30 14:36:47 --> Total execution time: 0.2219
DEBUG - 2011-04-30 14:37:02 --> Config Class Initialized
DEBUG - 2011-04-30 14:37:02 --> Hooks Class Initialized
DEBUG - 2011-04-30 14:37:02 --> Utf8 Class Initialized
DEBUG - 2011-04-30 14:37:02 --> UTF-8 Support Enabled
DEBUG - 2011-04-30 14:37:02 --> URI Class Initialized
DEBUG - 2011-04-30 14:37:02 --> Router Class Initialized
DEBUG - 2011-04-30 14:37:02 --> Output Class Initialized
DEBUG - 2011-04-30 14:37:02 --> Input Class Initialized
DEBUG - 2011-04-30 14:37:02 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-30 14:37:02 --> Language Class Initialized
DEBUG - 2011-04-30 14:37:02 --> Loader Class Initialized
DEBUG - 2011-04-30 14:37:02 --> Controller Class Initialized
DEBUG - 2011-04-30 14:37:02 --> Model Class Initialized
DEBUG - 2011-04-30 14:37:02 --> Model Class Initialized
DEBUG - 2011-04-30 14:37:02 --> Model Class Initialized
DEBUG - 2011-04-30 14:37:02 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-30 14:37:02 --> Database Driver Class Initialized
DEBUG - 2011-04-30 14:37:02 --> File loaded: application/views/table/main.php
DEBUG - 2011-04-30 14:37:02 --> Helper loaded: url_helper
DEBUG - 2011-04-30 14:37:02 --> File loaded: application/views/common/header.php
DEBUG - 2011-04-30 14:37:02 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-04-30 14:37:02 --> File loaded: application/views/common/footer.php
DEBUG - 2011-04-30 14:37:02 --> File loaded: application/views/layout/main.php
DEBUG - 2011-04-30 14:37:02 --> Final output sent to browser
DEBUG - 2011-04-30 14:37:02 --> Total execution time: 0.0584
DEBUG - 2011-04-30 14:37:17 --> Config Class Initialized
DEBUG - 2011-04-30 14:37:17 --> Hooks Class Initialized
DEBUG - 2011-04-30 14:37:17 --> Utf8 Class Initialized
DEBUG - 2011-04-30 14:37:17 --> UTF-8 Support Enabled
DEBUG - 2011-04-30 14:37:17 --> URI Class Initialized
DEBUG - 2011-04-30 14:37:17 --> Router Class Initialized
DEBUG - 2011-04-30 14:37:17 --> Output Class Initialized
DEBUG - 2011-04-30 14:37:17 --> Input Class Initialized
DEBUG - 2011-04-30 14:37:17 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-30 14:37:17 --> Language Class Initialized
DEBUG - 2011-04-30 14:37:17 --> Loader Class Initialized
DEBUG - 2011-04-30 14:37:17 --> Controller Class Initialized
DEBUG - 2011-04-30 14:37:17 --> Model Class Initialized
DEBUG - 2011-04-30 14:37:17 --> Model Class Initialized
DEBUG - 2011-04-30 14:37:17 --> Model Class Initialized
DEBUG - 2011-04-30 14:37:17 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-30 14:37:17 --> Database Driver Class Initialized
DEBUG - 2011-04-30 14:37:17 --> File loaded: application/views/table/main.php
DEBUG - 2011-04-30 14:37:17 --> Helper loaded: url_helper
DEBUG - 2011-04-30 14:37:17 --> File loaded: application/views/common/header.php
DEBUG - 2011-04-30 14:37:17 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-04-30 14:37:17 --> File loaded: application/views/common/footer.php
DEBUG - 2011-04-30 14:37:17 --> File loaded: application/views/layout/main.php
DEBUG - 2011-04-30 14:37:17 --> Final output sent to browser
DEBUG - 2011-04-30 14:37:17 --> Total execution time: 0.2156
DEBUG - 2011-04-30 14:37:18 --> Config Class Initialized
DEBUG - 2011-04-30 14:37:18 --> Hooks Class Initialized
DEBUG - 2011-04-30 14:37:18 --> Utf8 Class Initialized
DEBUG - 2011-04-30 14:37:18 --> UTF-8 Support Enabled
DEBUG - 2011-04-30 14:37:18 --> URI Class Initialized
DEBUG - 2011-04-30 14:37:18 --> Router Class Initialized
DEBUG - 2011-04-30 14:37:18 --> Output Class Initialized
DEBUG - 2011-04-30 14:37:18 --> Input Class Initialized
DEBUG - 2011-04-30 14:37:18 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-30 14:37:18 --> Language Class Initialized
DEBUG - 2011-04-30 14:37:18 --> Loader Class Initialized
DEBUG - 2011-04-30 14:37:18 --> Controller Class Initialized
DEBUG - 2011-04-30 14:37:18 --> Model Class Initialized
DEBUG - 2011-04-30 14:37:18 --> Model Class Initialized
DEBUG - 2011-04-30 14:37:18 --> Model Class Initialized
DEBUG - 2011-04-30 14:37:18 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-30 14:37:18 --> Database Driver Class Initialized
DEBUG - 2011-04-30 14:37:18 --> File loaded: application/views/table/main.php
DEBUG - 2011-04-30 14:37:18 --> Helper loaded: url_helper
DEBUG - 2011-04-30 14:37:18 --> File loaded: application/views/common/header.php
DEBUG - 2011-04-30 14:37:18 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-04-30 14:37:18 --> File loaded: application/views/common/footer.php
DEBUG - 2011-04-30 14:37:18 --> File loaded: application/views/layout/main.php
DEBUG - 2011-04-30 14:37:18 --> Final output sent to browser
DEBUG - 2011-04-30 14:37:18 --> Total execution time: 0.0585
DEBUG - 2011-04-30 14:37:19 --> Config Class Initialized
DEBUG - 2011-04-30 14:37:19 --> Hooks Class Initialized
DEBUG - 2011-04-30 14:37:19 --> Utf8 Class Initialized
DEBUG - 2011-04-30 14:37:19 --> UTF-8 Support Enabled
DEBUG - 2011-04-30 14:37:19 --> URI Class Initialized
DEBUG - 2011-04-30 14:37:19 --> Router Class Initialized
DEBUG - 2011-04-30 14:37:19 --> Output Class Initialized
DEBUG - 2011-04-30 14:37:19 --> Input Class Initialized
DEBUG - 2011-04-30 14:37:19 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-30 14:37:19 --> Language Class Initialized
DEBUG - 2011-04-30 14:37:19 --> Loader Class Initialized
DEBUG - 2011-04-30 14:37:19 --> Controller Class Initialized
DEBUG - 2011-04-30 14:37:19 --> Model Class Initialized
DEBUG - 2011-04-30 14:37:19 --> Model Class Initialized
DEBUG - 2011-04-30 14:37:19 --> Model Class Initialized
DEBUG - 2011-04-30 14:37:19 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-30 14:37:19 --> Database Driver Class Initialized
DEBUG - 2011-04-30 14:37:19 --> File loaded: application/views/table/main.php
DEBUG - 2011-04-30 14:37:19 --> Helper loaded: url_helper
DEBUG - 2011-04-30 14:37:19 --> File loaded: application/views/common/header.php
DEBUG - 2011-04-30 14:37:19 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-04-30 14:37:19 --> File loaded: application/views/common/footer.php
DEBUG - 2011-04-30 14:37:19 --> File loaded: application/views/layout/main.php
DEBUG - 2011-04-30 14:37:19 --> Final output sent to browser
DEBUG - 2011-04-30 14:37:19 --> Total execution time: 0.0449
DEBUG - 2011-04-30 14:37:53 --> Config Class Initialized
DEBUG - 2011-04-30 14:37:53 --> Hooks Class Initialized
DEBUG - 2011-04-30 14:37:53 --> Utf8 Class Initialized
DEBUG - 2011-04-30 14:37:53 --> UTF-8 Support Enabled
DEBUG - 2011-04-30 14:37:53 --> URI Class Initialized
DEBUG - 2011-04-30 14:37:53 --> Router Class Initialized
DEBUG - 2011-04-30 14:37:53 --> Output Class Initialized
DEBUG - 2011-04-30 14:37:53 --> Input Class Initialized
DEBUG - 2011-04-30 14:37:53 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-30 14:37:53 --> Language Class Initialized
DEBUG - 2011-04-30 14:37:53 --> Loader Class Initialized
DEBUG - 2011-04-30 14:37:53 --> Controller Class Initialized
DEBUG - 2011-04-30 14:37:53 --> Model Class Initialized
DEBUG - 2011-04-30 14:37:53 --> Model Class Initialized
DEBUG - 2011-04-30 14:37:53 --> Model Class Initialized
DEBUG - 2011-04-30 14:37:53 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-30 14:37:53 --> Database Driver Class Initialized
DEBUG - 2011-04-30 14:37:53 --> File loaded: application/views/table/main.php
DEBUG - 2011-04-30 14:37:53 --> Helper loaded: url_helper
DEBUG - 2011-04-30 14:37:53 --> File loaded: application/views/common/header.php
DEBUG - 2011-04-30 14:37:53 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-04-30 14:37:53 --> File loaded: application/views/common/footer.php
DEBUG - 2011-04-30 14:37:53 --> File loaded: application/views/layout/main.php
DEBUG - 2011-04-30 14:37:53 --> Final output sent to browser
DEBUG - 2011-04-30 14:37:53 --> Total execution time: 0.0467
DEBUG - 2011-04-30 14:38:04 --> Config Class Initialized
DEBUG - 2011-04-30 14:38:04 --> Hooks Class Initialized
DEBUG - 2011-04-30 14:38:04 --> Utf8 Class Initialized
DEBUG - 2011-04-30 14:38:04 --> UTF-8 Support Enabled
DEBUG - 2011-04-30 14:38:04 --> URI Class Initialized
DEBUG - 2011-04-30 14:38:04 --> Router Class Initialized
DEBUG - 2011-04-30 14:38:04 --> Output Class Initialized
DEBUG - 2011-04-30 14:38:04 --> Input Class Initialized
DEBUG - 2011-04-30 14:38:04 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-30 14:38:04 --> Language Class Initialized
DEBUG - 2011-04-30 14:38:04 --> Loader Class Initialized
DEBUG - 2011-04-30 14:38:04 --> Controller Class Initialized
DEBUG - 2011-04-30 14:38:04 --> Model Class Initialized
DEBUG - 2011-04-30 14:38:04 --> Model Class Initialized
DEBUG - 2011-04-30 14:38:04 --> Model Class Initialized
DEBUG - 2011-04-30 14:38:04 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-30 14:38:04 --> Database Driver Class Initialized
DEBUG - 2011-04-30 14:38:04 --> File loaded: application/views/table/main.php
DEBUG - 2011-04-30 14:38:04 --> Helper loaded: url_helper
DEBUG - 2011-04-30 14:38:04 --> File loaded: application/views/common/header.php
DEBUG - 2011-04-30 14:38:04 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-04-30 14:38:04 --> File loaded: application/views/common/footer.php
DEBUG - 2011-04-30 14:38:04 --> File loaded: application/views/layout/main.php
DEBUG - 2011-04-30 14:38:04 --> Final output sent to browser
DEBUG - 2011-04-30 14:38:04 --> Total execution time: 0.2805
DEBUG - 2011-04-30 14:38:07 --> Config Class Initialized
DEBUG - 2011-04-30 14:38:07 --> Hooks Class Initialized
DEBUG - 2011-04-30 14:38:07 --> Utf8 Class Initialized
DEBUG - 2011-04-30 14:38:07 --> UTF-8 Support Enabled
DEBUG - 2011-04-30 14:38:07 --> URI Class Initialized
DEBUG - 2011-04-30 14:38:07 --> Router Class Initialized
DEBUG - 2011-04-30 14:38:07 --> Output Class Initialized
DEBUG - 2011-04-30 14:38:07 --> Input Class Initialized
DEBUG - 2011-04-30 14:38:07 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-30 14:38:07 --> Language Class Initialized
DEBUG - 2011-04-30 14:38:07 --> Loader Class Initialized
DEBUG - 2011-04-30 14:38:07 --> Controller Class Initialized
DEBUG - 2011-04-30 14:38:07 --> Model Class Initialized
DEBUG - 2011-04-30 14:38:07 --> Model Class Initialized
DEBUG - 2011-04-30 14:38:07 --> Model Class Initialized
DEBUG - 2011-04-30 14:38:07 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-30 14:38:07 --> Database Driver Class Initialized
DEBUG - 2011-04-30 14:38:08 --> File loaded: application/views/table/main.php
DEBUG - 2011-04-30 14:38:08 --> Helper loaded: url_helper
DEBUG - 2011-04-30 14:38:08 --> File loaded: application/views/common/header.php
DEBUG - 2011-04-30 14:38:08 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-04-30 14:38:08 --> File loaded: application/views/common/footer.php
DEBUG - 2011-04-30 14:38:08 --> File loaded: application/views/layout/main.php
DEBUG - 2011-04-30 14:38:08 --> Final output sent to browser
DEBUG - 2011-04-30 14:38:08 --> Total execution time: 0.0472
DEBUG - 2011-04-30 14:38:13 --> Config Class Initialized
DEBUG - 2011-04-30 14:38:13 --> Hooks Class Initialized
DEBUG - 2011-04-30 14:38:13 --> Utf8 Class Initialized
DEBUG - 2011-04-30 14:38:13 --> UTF-8 Support Enabled
DEBUG - 2011-04-30 14:38:13 --> URI Class Initialized
DEBUG - 2011-04-30 14:38:13 --> Router Class Initialized
DEBUG - 2011-04-30 14:38:13 --> Output Class Initialized
DEBUG - 2011-04-30 14:38:13 --> Input Class Initialized
DEBUG - 2011-04-30 14:38:13 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-30 14:38:13 --> Language Class Initialized
DEBUG - 2011-04-30 14:38:13 --> Loader Class Initialized
DEBUG - 2011-04-30 14:38:13 --> Controller Class Initialized
DEBUG - 2011-04-30 14:38:13 --> Model Class Initialized
DEBUG - 2011-04-30 14:38:13 --> Model Class Initialized
DEBUG - 2011-04-30 14:38:13 --> Model Class Initialized
DEBUG - 2011-04-30 14:38:13 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-30 14:38:13 --> Database Driver Class Initialized
DEBUG - 2011-04-30 14:38:13 --> File loaded: application/views/table/main.php
DEBUG - 2011-04-30 14:38:13 --> Helper loaded: url_helper
DEBUG - 2011-04-30 14:38:13 --> File loaded: application/views/common/header.php
DEBUG - 2011-04-30 14:38:13 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-04-30 14:38:13 --> File loaded: application/views/common/footer.php
DEBUG - 2011-04-30 14:38:13 --> File loaded: application/views/layout/main.php
DEBUG - 2011-04-30 14:38:13 --> Final output sent to browser
DEBUG - 2011-04-30 14:38:13 --> Total execution time: 0.0424
DEBUG - 2011-04-30 14:38:27 --> Config Class Initialized
DEBUG - 2011-04-30 14:38:27 --> Hooks Class Initialized
DEBUG - 2011-04-30 14:38:27 --> Utf8 Class Initialized
DEBUG - 2011-04-30 14:38:27 --> UTF-8 Support Enabled
DEBUG - 2011-04-30 14:38:27 --> URI Class Initialized
DEBUG - 2011-04-30 14:38:27 --> Router Class Initialized
DEBUG - 2011-04-30 14:38:27 --> Output Class Initialized
DEBUG - 2011-04-30 14:38:27 --> Input Class Initialized
DEBUG - 2011-04-30 14:38:27 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-30 14:38:27 --> Language Class Initialized
DEBUG - 2011-04-30 14:38:27 --> Loader Class Initialized
DEBUG - 2011-04-30 14:38:27 --> Controller Class Initialized
DEBUG - 2011-04-30 14:38:27 --> Model Class Initialized
DEBUG - 2011-04-30 14:38:27 --> Model Class Initialized
DEBUG - 2011-04-30 14:38:27 --> Model Class Initialized
DEBUG - 2011-04-30 14:38:27 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-30 14:38:27 --> Database Driver Class Initialized
DEBUG - 2011-04-30 14:38:27 --> File loaded: application/views/table/main.php
DEBUG - 2011-04-30 14:38:27 --> Helper loaded: url_helper
DEBUG - 2011-04-30 14:38:27 --> File loaded: application/views/common/header.php
DEBUG - 2011-04-30 14:38:27 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-04-30 14:38:27 --> File loaded: application/views/common/footer.php
DEBUG - 2011-04-30 14:38:27 --> File loaded: application/views/layout/main.php
DEBUG - 2011-04-30 14:38:27 --> Final output sent to browser
DEBUG - 2011-04-30 14:38:27 --> Total execution time: 0.2347
DEBUG - 2011-04-30 14:38:54 --> Config Class Initialized
DEBUG - 2011-04-30 14:38:54 --> Hooks Class Initialized
DEBUG - 2011-04-30 14:38:54 --> Utf8 Class Initialized
DEBUG - 2011-04-30 14:38:54 --> UTF-8 Support Enabled
DEBUG - 2011-04-30 14:38:54 --> URI Class Initialized
DEBUG - 2011-04-30 14:38:54 --> Router Class Initialized
DEBUG - 2011-04-30 14:38:54 --> Output Class Initialized
DEBUG - 2011-04-30 14:38:54 --> Input Class Initialized
DEBUG - 2011-04-30 14:38:54 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-30 14:38:54 --> Language Class Initialized
DEBUG - 2011-04-30 14:38:54 --> Loader Class Initialized
DEBUG - 2011-04-30 14:38:54 --> Controller Class Initialized
DEBUG - 2011-04-30 14:38:54 --> Model Class Initialized
DEBUG - 2011-04-30 14:38:54 --> Model Class Initialized
DEBUG - 2011-04-30 14:38:54 --> Model Class Initialized
DEBUG - 2011-04-30 14:38:54 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-30 14:38:54 --> Database Driver Class Initialized
DEBUG - 2011-04-30 14:38:55 --> File loaded: application/views/table/main.php
DEBUG - 2011-04-30 14:38:55 --> Helper loaded: url_helper
DEBUG - 2011-04-30 14:38:55 --> File loaded: application/views/common/header.php
DEBUG - 2011-04-30 14:38:55 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-04-30 14:38:55 --> File loaded: application/views/common/footer.php
DEBUG - 2011-04-30 14:38:55 --> File loaded: application/views/layout/main.php
DEBUG - 2011-04-30 14:38:55 --> Final output sent to browser
DEBUG - 2011-04-30 14:38:55 --> Total execution time: 0.2285
DEBUG - 2011-04-30 14:38:56 --> Config Class Initialized
DEBUG - 2011-04-30 14:38:56 --> Hooks Class Initialized
DEBUG - 2011-04-30 14:38:56 --> Utf8 Class Initialized
DEBUG - 2011-04-30 14:38:56 --> UTF-8 Support Enabled
DEBUG - 2011-04-30 14:38:56 --> URI Class Initialized
DEBUG - 2011-04-30 14:38:56 --> Router Class Initialized
DEBUG - 2011-04-30 14:38:56 --> Output Class Initialized
DEBUG - 2011-04-30 14:38:56 --> Input Class Initialized
DEBUG - 2011-04-30 14:38:56 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-30 14:38:56 --> Language Class Initialized
DEBUG - 2011-04-30 14:38:56 --> Loader Class Initialized
DEBUG - 2011-04-30 14:38:56 --> Controller Class Initialized
DEBUG - 2011-04-30 14:38:56 --> Model Class Initialized
DEBUG - 2011-04-30 14:38:56 --> Model Class Initialized
DEBUG - 2011-04-30 14:38:56 --> Model Class Initialized
DEBUG - 2011-04-30 14:38:56 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-30 14:38:56 --> Database Driver Class Initialized
DEBUG - 2011-04-30 14:38:56 --> File loaded: application/views/table/main.php
DEBUG - 2011-04-30 14:38:56 --> Helper loaded: url_helper
DEBUG - 2011-04-30 14:38:56 --> File loaded: application/views/common/header.php
DEBUG - 2011-04-30 14:38:56 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-04-30 14:38:56 --> File loaded: application/views/common/footer.php
DEBUG - 2011-04-30 14:38:56 --> File loaded: application/views/layout/main.php
DEBUG - 2011-04-30 14:38:56 --> Final output sent to browser
DEBUG - 2011-04-30 14:38:56 --> Total execution time: 0.0466
DEBUG - 2011-04-30 14:39:44 --> Config Class Initialized
DEBUG - 2011-04-30 14:39:44 --> Hooks Class Initialized
DEBUG - 2011-04-30 14:39:44 --> Utf8 Class Initialized
DEBUG - 2011-04-30 14:39:44 --> UTF-8 Support Enabled
DEBUG - 2011-04-30 14:39:44 --> URI Class Initialized
DEBUG - 2011-04-30 14:39:44 --> Router Class Initialized
DEBUG - 2011-04-30 14:39:44 --> Output Class Initialized
DEBUG - 2011-04-30 14:39:44 --> Input Class Initialized
DEBUG - 2011-04-30 14:39:44 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-30 14:39:44 --> Language Class Initialized
DEBUG - 2011-04-30 14:39:44 --> Loader Class Initialized
DEBUG - 2011-04-30 14:39:44 --> Controller Class Initialized
DEBUG - 2011-04-30 14:39:44 --> Model Class Initialized
DEBUG - 2011-04-30 14:39:44 --> Model Class Initialized
DEBUG - 2011-04-30 14:39:44 --> Model Class Initialized
DEBUG - 2011-04-30 14:39:44 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-30 14:39:44 --> Database Driver Class Initialized
DEBUG - 2011-04-30 14:39:44 --> File loaded: application/views/table/main.php
DEBUG - 2011-04-30 14:39:44 --> Helper loaded: url_helper
DEBUG - 2011-04-30 14:39:44 --> File loaded: application/views/common/header.php
DEBUG - 2011-04-30 14:39:44 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-04-30 14:39:44 --> File loaded: application/views/common/footer.php
DEBUG - 2011-04-30 14:39:44 --> File loaded: application/views/layout/main.php
DEBUG - 2011-04-30 14:39:44 --> Final output sent to browser
DEBUG - 2011-04-30 14:39:44 --> Total execution time: 0.3077
DEBUG - 2011-04-30 14:39:48 --> Config Class Initialized
DEBUG - 2011-04-30 14:39:48 --> Hooks Class Initialized
DEBUG - 2011-04-30 14:39:48 --> Utf8 Class Initialized
DEBUG - 2011-04-30 14:39:48 --> UTF-8 Support Enabled
DEBUG - 2011-04-30 14:39:48 --> URI Class Initialized
DEBUG - 2011-04-30 14:39:48 --> Router Class Initialized
DEBUG - 2011-04-30 14:39:48 --> Output Class Initialized
DEBUG - 2011-04-30 14:39:48 --> Input Class Initialized
DEBUG - 2011-04-30 14:39:48 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-30 14:39:48 --> Language Class Initialized
DEBUG - 2011-04-30 14:39:48 --> Loader Class Initialized
DEBUG - 2011-04-30 14:39:48 --> Controller Class Initialized
DEBUG - 2011-04-30 14:39:48 --> Model Class Initialized
DEBUG - 2011-04-30 14:39:48 --> Model Class Initialized
DEBUG - 2011-04-30 14:39:48 --> Model Class Initialized
DEBUG - 2011-04-30 14:39:48 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-30 14:39:48 --> Database Driver Class Initialized
DEBUG - 2011-04-30 14:39:48 --> File loaded: application/views/table/main.php
DEBUG - 2011-04-30 14:39:48 --> Helper loaded: url_helper
DEBUG - 2011-04-30 14:39:48 --> File loaded: application/views/common/header.php
DEBUG - 2011-04-30 14:39:48 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-04-30 14:39:48 --> File loaded: application/views/common/footer.php
DEBUG - 2011-04-30 14:39:48 --> File loaded: application/views/layout/main.php
DEBUG - 2011-04-30 14:39:48 --> Final output sent to browser
DEBUG - 2011-04-30 14:39:48 --> Total execution time: 0.0458
DEBUG - 2011-04-30 15:16:11 --> Config Class Initialized
DEBUG - 2011-04-30 15:16:11 --> Hooks Class Initialized
DEBUG - 2011-04-30 15:16:11 --> Utf8 Class Initialized
DEBUG - 2011-04-30 15:16:11 --> UTF-8 Support Enabled
DEBUG - 2011-04-30 15:16:11 --> URI Class Initialized
DEBUG - 2011-04-30 15:16:11 --> Router Class Initialized
DEBUG - 2011-04-30 15:16:11 --> Output Class Initialized
DEBUG - 2011-04-30 15:16:11 --> Input Class Initialized
DEBUG - 2011-04-30 15:16:11 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-30 15:16:11 --> Language Class Initialized
DEBUG - 2011-04-30 15:16:11 --> Loader Class Initialized
DEBUG - 2011-04-30 15:16:11 --> Controller Class Initialized
DEBUG - 2011-04-30 15:16:11 --> Model Class Initialized
DEBUG - 2011-04-30 15:16:11 --> Model Class Initialized
DEBUG - 2011-04-30 15:16:11 --> Model Class Initialized
DEBUG - 2011-04-30 15:16:11 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-30 15:16:11 --> Database Driver Class Initialized
DEBUG - 2011-04-30 15:16:12 --> File loaded: application/views/table/main.php
DEBUG - 2011-04-30 15:16:12 --> Helper loaded: url_helper
DEBUG - 2011-04-30 15:16:12 --> File loaded: application/views/common/header.php
DEBUG - 2011-04-30 15:16:12 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-04-30 15:16:12 --> File loaded: application/views/common/footer.php
DEBUG - 2011-04-30 15:16:12 --> File loaded: application/views/layout/main.php
DEBUG - 2011-04-30 15:16:12 --> Final output sent to browser
DEBUG - 2011-04-30 15:16:12 --> Total execution time: 0.6256
DEBUG - 2011-04-30 15:16:16 --> Config Class Initialized
DEBUG - 2011-04-30 15:16:16 --> Hooks Class Initialized
DEBUG - 2011-04-30 15:16:16 --> Utf8 Class Initialized
DEBUG - 2011-04-30 15:16:16 --> UTF-8 Support Enabled
DEBUG - 2011-04-30 15:16:16 --> URI Class Initialized
DEBUG - 2011-04-30 15:16:16 --> Router Class Initialized
DEBUG - 2011-04-30 15:16:16 --> Output Class Initialized
DEBUG - 2011-04-30 15:16:16 --> Input Class Initialized
DEBUG - 2011-04-30 15:16:16 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-30 15:16:16 --> Language Class Initialized
DEBUG - 2011-04-30 15:16:16 --> Loader Class Initialized
DEBUG - 2011-04-30 15:16:16 --> Controller Class Initialized
ERROR - 2011-04-30 15:16:16 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-04-30 15:16:16 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-04-30 15:16:16 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-04-30 15:16:16 --> Model Class Initialized
DEBUG - 2011-04-30 15:16:16 --> Model Class Initialized
DEBUG - 2011-04-30 15:16:16 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-30 15:16:16 --> Database Driver Class Initialized
DEBUG - 2011-04-30 15:16:16 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-04-30 15:16:16 --> Helper loaded: url_helper
DEBUG - 2011-04-30 15:16:16 --> File loaded: application/views/common/header.php
DEBUG - 2011-04-30 15:16:16 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-04-30 15:16:16 --> File loaded: application/views/common/footer.php
DEBUG - 2011-04-30 15:16:16 --> File loaded: application/views/layout/main.php
DEBUG - 2011-04-30 15:16:16 --> Final output sent to browser
DEBUG - 2011-04-30 15:16:16 --> Total execution time: 0.1475
DEBUG - 2011-04-30 16:48:01 --> Config Class Initialized
DEBUG - 2011-04-30 16:48:01 --> Hooks Class Initialized
DEBUG - 2011-04-30 16:48:01 --> Utf8 Class Initialized
DEBUG - 2011-04-30 16:48:01 --> UTF-8 Support Enabled
DEBUG - 2011-04-30 16:48:01 --> URI Class Initialized
DEBUG - 2011-04-30 16:48:01 --> Router Class Initialized
DEBUG - 2011-04-30 16:48:01 --> Output Class Initialized
DEBUG - 2011-04-30 16:48:01 --> Input Class Initialized
DEBUG - 2011-04-30 16:48:01 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-30 16:48:01 --> Language Class Initialized
DEBUG - 2011-04-30 16:48:01 --> Loader Class Initialized
DEBUG - 2011-04-30 16:48:01 --> Controller Class Initialized
DEBUG - 2011-04-30 16:48:01 --> Model Class Initialized
DEBUG - 2011-04-30 16:48:01 --> Model Class Initialized
DEBUG - 2011-04-30 16:48:01 --> Model Class Initialized
DEBUG - 2011-04-30 16:48:01 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-30 16:48:02 --> Database Driver Class Initialized
DEBUG - 2011-04-30 16:48:02 --> File loaded: application/views/table/main.php
DEBUG - 2011-04-30 16:48:02 --> Helper loaded: url_helper
DEBUG - 2011-04-30 16:48:02 --> File loaded: application/views/common/header.php
DEBUG - 2011-04-30 16:48:02 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-04-30 16:48:02 --> File loaded: application/views/common/footer.php
DEBUG - 2011-04-30 16:48:02 --> File loaded: application/views/layout/main.php
DEBUG - 2011-04-30 16:48:02 --> Final output sent to browser
DEBUG - 2011-04-30 16:48:02 --> Total execution time: 0.8912
DEBUG - 2011-04-30 16:48:07 --> Config Class Initialized
DEBUG - 2011-04-30 16:48:07 --> Hooks Class Initialized
DEBUG - 2011-04-30 16:48:07 --> Utf8 Class Initialized
DEBUG - 2011-04-30 16:48:07 --> UTF-8 Support Enabled
DEBUG - 2011-04-30 16:48:07 --> URI Class Initialized
DEBUG - 2011-04-30 16:48:07 --> Router Class Initialized
DEBUG - 2011-04-30 16:48:07 --> Output Class Initialized
DEBUG - 2011-04-30 16:48:07 --> Input Class Initialized
DEBUG - 2011-04-30 16:48:07 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-30 16:48:07 --> Language Class Initialized
DEBUG - 2011-04-30 16:48:07 --> Loader Class Initialized
DEBUG - 2011-04-30 16:48:07 --> Controller Class Initialized
DEBUG - 2011-04-30 16:48:07 --> Model Class Initialized
DEBUG - 2011-04-30 16:48:07 --> Model Class Initialized
DEBUG - 2011-04-30 16:48:07 --> Model Class Initialized
DEBUG - 2011-04-30 16:48:07 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-30 16:48:07 --> Database Driver Class Initialized
DEBUG - 2011-04-30 16:48:07 --> File loaded: application/views/table/main.php
DEBUG - 2011-04-30 16:48:07 --> Helper loaded: url_helper
DEBUG - 2011-04-30 16:48:07 --> File loaded: application/views/common/header.php
DEBUG - 2011-04-30 16:48:07 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-04-30 16:48:07 --> File loaded: application/views/common/footer.php
DEBUG - 2011-04-30 16:48:07 --> File loaded: application/views/layout/main.php
DEBUG - 2011-04-30 16:48:07 --> Final output sent to browser
DEBUG - 2011-04-30 16:48:07 --> Total execution time: 0.0462
DEBUG - 2011-04-30 17:44:33 --> Config Class Initialized
DEBUG - 2011-04-30 17:44:33 --> Hooks Class Initialized
DEBUG - 2011-04-30 17:44:33 --> Utf8 Class Initialized
DEBUG - 2011-04-30 17:44:33 --> UTF-8 Support Enabled
DEBUG - 2011-04-30 17:44:33 --> URI Class Initialized
DEBUG - 2011-04-30 17:44:33 --> Router Class Initialized
DEBUG - 2011-04-30 17:44:33 --> Output Class Initialized
DEBUG - 2011-04-30 17:44:33 --> Input Class Initialized
DEBUG - 2011-04-30 17:44:33 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-30 17:44:33 --> Language Class Initialized
DEBUG - 2011-04-30 17:44:33 --> Loader Class Initialized
DEBUG - 2011-04-30 17:44:33 --> Controller Class Initialized
DEBUG - 2011-04-30 17:44:33 --> Model Class Initialized
DEBUG - 2011-04-30 17:44:33 --> Model Class Initialized
DEBUG - 2011-04-30 17:44:33 --> Model Class Initialized
DEBUG - 2011-04-30 17:44:33 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-30 17:44:33 --> Database Driver Class Initialized
DEBUG - 2011-04-30 17:44:34 --> File loaded: application/views/table/main.php
DEBUG - 2011-04-30 17:44:34 --> Helper loaded: url_helper
DEBUG - 2011-04-30 17:44:34 --> File loaded: application/views/common/header.php
DEBUG - 2011-04-30 17:44:34 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-04-30 17:44:34 --> File loaded: application/views/common/footer.php
DEBUG - 2011-04-30 17:44:34 --> File loaded: application/views/layout/main.php
DEBUG - 2011-04-30 17:44:34 --> Final output sent to browser
DEBUG - 2011-04-30 17:44:34 --> Total execution time: 0.7850
DEBUG - 2011-04-30 17:44:36 --> Config Class Initialized
DEBUG - 2011-04-30 17:44:36 --> Hooks Class Initialized
DEBUG - 2011-04-30 17:44:36 --> Utf8 Class Initialized
DEBUG - 2011-04-30 17:44:36 --> UTF-8 Support Enabled
DEBUG - 2011-04-30 17:44:36 --> URI Class Initialized
DEBUG - 2011-04-30 17:44:36 --> Router Class Initialized
ERROR - 2011-04-30 17:44:36 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-04-30 17:44:57 --> Config Class Initialized
DEBUG - 2011-04-30 17:44:57 --> Hooks Class Initialized
DEBUG - 2011-04-30 17:44:57 --> Utf8 Class Initialized
DEBUG - 2011-04-30 17:44:57 --> UTF-8 Support Enabled
DEBUG - 2011-04-30 17:44:57 --> URI Class Initialized
DEBUG - 2011-04-30 17:44:57 --> Router Class Initialized
DEBUG - 2011-04-30 17:44:57 --> Output Class Initialized
DEBUG - 2011-04-30 17:44:57 --> Input Class Initialized
DEBUG - 2011-04-30 17:44:57 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-30 17:44:57 --> Language Class Initialized
DEBUG - 2011-04-30 17:44:57 --> Loader Class Initialized
DEBUG - 2011-04-30 17:44:57 --> Controller Class Initialized
DEBUG - 2011-04-30 17:44:57 --> Model Class Initialized
DEBUG - 2011-04-30 17:44:57 --> Model Class Initialized
DEBUG - 2011-04-30 17:44:57 --> Model Class Initialized
DEBUG - 2011-04-30 17:44:57 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-30 17:44:57 --> Database Driver Class Initialized
DEBUG - 2011-04-30 17:44:57 --> File loaded: application/views/table/main.php
DEBUG - 2011-04-30 17:44:57 --> Helper loaded: url_helper
DEBUG - 2011-04-30 17:44:57 --> File loaded: application/views/common/header.php
DEBUG - 2011-04-30 17:44:57 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-04-30 17:44:57 --> File loaded: application/views/common/footer.php
DEBUG - 2011-04-30 17:44:57 --> File loaded: application/views/layout/main.php
DEBUG - 2011-04-30 17:44:57 --> Final output sent to browser
DEBUG - 2011-04-30 17:44:57 --> Total execution time: 0.2026
DEBUG - 2011-04-30 17:44:59 --> Config Class Initialized
DEBUG - 2011-04-30 17:44:59 --> Hooks Class Initialized
DEBUG - 2011-04-30 17:44:59 --> Utf8 Class Initialized
DEBUG - 2011-04-30 17:44:59 --> UTF-8 Support Enabled
DEBUG - 2011-04-30 17:44:59 --> URI Class Initialized
DEBUG - 2011-04-30 17:44:59 --> Router Class Initialized
DEBUG - 2011-04-30 17:44:59 --> Output Class Initialized
DEBUG - 2011-04-30 17:44:59 --> Input Class Initialized
DEBUG - 2011-04-30 17:44:59 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-30 17:44:59 --> Language Class Initialized
DEBUG - 2011-04-30 17:44:59 --> Loader Class Initialized
DEBUG - 2011-04-30 17:44:59 --> Controller Class Initialized
DEBUG - 2011-04-30 17:44:59 --> Model Class Initialized
DEBUG - 2011-04-30 17:44:59 --> Model Class Initialized
DEBUG - 2011-04-30 17:44:59 --> Model Class Initialized
DEBUG - 2011-04-30 17:44:59 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-30 17:44:59 --> Database Driver Class Initialized
DEBUG - 2011-04-30 17:44:59 --> File loaded: application/views/table/main.php
DEBUG - 2011-04-30 17:44:59 --> Helper loaded: url_helper
DEBUG - 2011-04-30 17:44:59 --> File loaded: application/views/common/header.php
DEBUG - 2011-04-30 17:44:59 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-04-30 17:44:59 --> File loaded: application/views/common/footer.php
DEBUG - 2011-04-30 17:44:59 --> File loaded: application/views/layout/main.php
DEBUG - 2011-04-30 17:44:59 --> Final output sent to browser
DEBUG - 2011-04-30 17:44:59 --> Total execution time: 0.0463
DEBUG - 2011-04-30 17:44:59 --> Config Class Initialized
DEBUG - 2011-04-30 17:44:59 --> Hooks Class Initialized
DEBUG - 2011-04-30 17:44:59 --> Utf8 Class Initialized
DEBUG - 2011-04-30 17:44:59 --> UTF-8 Support Enabled
DEBUG - 2011-04-30 17:44:59 --> URI Class Initialized
DEBUG - 2011-04-30 17:44:59 --> Router Class Initialized
ERROR - 2011-04-30 17:44:59 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-04-30 17:45:39 --> Config Class Initialized
DEBUG - 2011-04-30 17:45:39 --> Hooks Class Initialized
DEBUG - 2011-04-30 17:45:39 --> Utf8 Class Initialized
DEBUG - 2011-04-30 17:45:39 --> UTF-8 Support Enabled
DEBUG - 2011-04-30 17:45:39 --> URI Class Initialized
DEBUG - 2011-04-30 17:45:39 --> Router Class Initialized
DEBUG - 2011-04-30 17:45:39 --> Output Class Initialized
DEBUG - 2011-04-30 17:45:39 --> Input Class Initialized
DEBUG - 2011-04-30 17:45:39 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-30 17:45:39 --> Language Class Initialized
DEBUG - 2011-04-30 17:45:39 --> Loader Class Initialized
DEBUG - 2011-04-30 17:45:39 --> Controller Class Initialized
DEBUG - 2011-04-30 17:45:39 --> Model Class Initialized
DEBUG - 2011-04-30 17:45:39 --> Model Class Initialized
DEBUG - 2011-04-30 17:45:39 --> Model Class Initialized
DEBUG - 2011-04-30 17:45:39 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-30 17:45:39 --> Database Driver Class Initialized
DEBUG - 2011-04-30 17:45:39 --> File loaded: application/views/table/main.php
DEBUG - 2011-04-30 17:45:39 --> Helper loaded: url_helper
DEBUG - 2011-04-30 17:45:39 --> File loaded: application/views/common/header.php
DEBUG - 2011-04-30 17:45:39 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-04-30 17:45:39 --> File loaded: application/views/common/footer.php
DEBUG - 2011-04-30 17:45:39 --> File loaded: application/views/layout/main.php
DEBUG - 2011-04-30 17:45:39 --> Final output sent to browser
DEBUG - 2011-04-30 17:45:39 --> Total execution time: 0.1939
DEBUG - 2011-04-30 17:45:41 --> Config Class Initialized
DEBUG - 2011-04-30 17:45:41 --> Hooks Class Initialized
DEBUG - 2011-04-30 17:45:41 --> Utf8 Class Initialized
DEBUG - 2011-04-30 17:45:41 --> UTF-8 Support Enabled
DEBUG - 2011-04-30 17:45:41 --> URI Class Initialized
DEBUG - 2011-04-30 17:45:41 --> Router Class Initialized
ERROR - 2011-04-30 17:45:41 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-04-30 17:46:07 --> Config Class Initialized
DEBUG - 2011-04-30 17:46:07 --> Hooks Class Initialized
DEBUG - 2011-04-30 17:46:07 --> Utf8 Class Initialized
DEBUG - 2011-04-30 17:46:07 --> UTF-8 Support Enabled
DEBUG - 2011-04-30 17:46:07 --> URI Class Initialized
DEBUG - 2011-04-30 17:46:07 --> Router Class Initialized
DEBUG - 2011-04-30 17:46:07 --> Output Class Initialized
DEBUG - 2011-04-30 17:46:07 --> Input Class Initialized
DEBUG - 2011-04-30 17:46:07 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-30 17:46:07 --> Language Class Initialized
DEBUG - 2011-04-30 17:46:07 --> Loader Class Initialized
DEBUG - 2011-04-30 17:46:07 --> Controller Class Initialized
DEBUG - 2011-04-30 17:46:07 --> Model Class Initialized
DEBUG - 2011-04-30 17:46:07 --> Model Class Initialized
DEBUG - 2011-04-30 17:46:07 --> Model Class Initialized
DEBUG - 2011-04-30 17:46:07 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-30 17:46:07 --> Database Driver Class Initialized
DEBUG - 2011-04-30 17:46:07 --> File loaded: application/views/table/main.php
DEBUG - 2011-04-30 17:46:07 --> Helper loaded: url_helper
DEBUG - 2011-04-30 17:46:07 --> File loaded: application/views/common/header.php
DEBUG - 2011-04-30 17:46:07 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-04-30 17:46:07 --> File loaded: application/views/common/footer.php
DEBUG - 2011-04-30 17:46:07 --> File loaded: application/views/layout/main.php
DEBUG - 2011-04-30 17:46:07 --> Final output sent to browser
DEBUG - 2011-04-30 17:46:07 --> Total execution time: 0.1830
DEBUG - 2011-04-30 17:46:08 --> Config Class Initialized
DEBUG - 2011-04-30 17:46:08 --> Hooks Class Initialized
DEBUG - 2011-04-30 17:46:08 --> Utf8 Class Initialized
DEBUG - 2011-04-30 17:46:08 --> UTF-8 Support Enabled
DEBUG - 2011-04-30 17:46:08 --> URI Class Initialized
DEBUG - 2011-04-30 17:46:08 --> Router Class Initialized
DEBUG - 2011-04-30 17:46:08 --> Output Class Initialized
DEBUG - 2011-04-30 17:46:08 --> Input Class Initialized
DEBUG - 2011-04-30 17:46:08 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-30 17:46:08 --> Language Class Initialized
DEBUG - 2011-04-30 17:46:08 --> Loader Class Initialized
DEBUG - 2011-04-30 17:46:08 --> Controller Class Initialized
DEBUG - 2011-04-30 17:46:08 --> Model Class Initialized
DEBUG - 2011-04-30 17:46:08 --> Model Class Initialized
DEBUG - 2011-04-30 17:46:08 --> Model Class Initialized
DEBUG - 2011-04-30 17:46:08 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-30 17:46:08 --> Database Driver Class Initialized
DEBUG - 2011-04-30 17:46:08 --> File loaded: application/views/table/main.php
DEBUG - 2011-04-30 17:46:08 --> Helper loaded: url_helper
DEBUG - 2011-04-30 17:46:08 --> File loaded: application/views/common/header.php
DEBUG - 2011-04-30 17:46:08 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-04-30 17:46:08 --> File loaded: application/views/common/footer.php
DEBUG - 2011-04-30 17:46:08 --> File loaded: application/views/layout/main.php
DEBUG - 2011-04-30 17:46:08 --> Final output sent to browser
DEBUG - 2011-04-30 17:46:08 --> Total execution time: 0.0485
DEBUG - 2011-04-30 17:46:08 --> Config Class Initialized
DEBUG - 2011-04-30 17:46:08 --> Hooks Class Initialized
DEBUG - 2011-04-30 17:46:08 --> Utf8 Class Initialized
DEBUG - 2011-04-30 17:46:08 --> UTF-8 Support Enabled
DEBUG - 2011-04-30 17:46:08 --> URI Class Initialized
DEBUG - 2011-04-30 17:46:08 --> Router Class Initialized
DEBUG - 2011-04-30 17:46:08 --> Output Class Initialized
DEBUG - 2011-04-30 17:46:08 --> Input Class Initialized
DEBUG - 2011-04-30 17:46:08 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-30 17:46:08 --> Language Class Initialized
DEBUG - 2011-04-30 17:46:08 --> Loader Class Initialized
DEBUG - 2011-04-30 17:46:08 --> Controller Class Initialized
DEBUG - 2011-04-30 17:46:08 --> Model Class Initialized
DEBUG - 2011-04-30 17:46:08 --> Model Class Initialized
DEBUG - 2011-04-30 17:46:08 --> Model Class Initialized
DEBUG - 2011-04-30 17:46:08 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-30 17:46:08 --> Database Driver Class Initialized
DEBUG - 2011-04-30 17:46:08 --> File loaded: application/views/table/main.php
DEBUG - 2011-04-30 17:46:08 --> Helper loaded: url_helper
DEBUG - 2011-04-30 17:46:08 --> File loaded: application/views/common/header.php
DEBUG - 2011-04-30 17:46:08 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-04-30 17:46:08 --> File loaded: application/views/common/footer.php
DEBUG - 2011-04-30 17:46:08 --> File loaded: application/views/layout/main.php
DEBUG - 2011-04-30 17:46:08 --> Final output sent to browser
DEBUG - 2011-04-30 17:46:08 --> Total execution time: 0.0443
DEBUG - 2011-04-30 17:46:09 --> Config Class Initialized
DEBUG - 2011-04-30 17:46:09 --> Hooks Class Initialized
DEBUG - 2011-04-30 17:46:09 --> Utf8 Class Initialized
DEBUG - 2011-04-30 17:46:09 --> UTF-8 Support Enabled
DEBUG - 2011-04-30 17:46:09 --> URI Class Initialized
DEBUG - 2011-04-30 17:46:09 --> Router Class Initialized
ERROR - 2011-04-30 17:46:09 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-04-30 17:46:19 --> Config Class Initialized
DEBUG - 2011-04-30 17:46:19 --> Hooks Class Initialized
DEBUG - 2011-04-30 17:46:19 --> Utf8 Class Initialized
DEBUG - 2011-04-30 17:46:19 --> UTF-8 Support Enabled
DEBUG - 2011-04-30 17:46:19 --> URI Class Initialized
DEBUG - 2011-04-30 17:46:19 --> Router Class Initialized
DEBUG - 2011-04-30 17:46:19 --> Output Class Initialized
DEBUG - 2011-04-30 17:46:19 --> Input Class Initialized
DEBUG - 2011-04-30 17:46:19 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-30 17:46:19 --> Language Class Initialized
DEBUG - 2011-04-30 17:46:19 --> Loader Class Initialized
DEBUG - 2011-04-30 17:46:19 --> Controller Class Initialized
DEBUG - 2011-04-30 17:46:19 --> Model Class Initialized
DEBUG - 2011-04-30 17:46:19 --> Model Class Initialized
DEBUG - 2011-04-30 17:46:19 --> Model Class Initialized
DEBUG - 2011-04-30 17:46:19 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-30 17:46:19 --> Database Driver Class Initialized
DEBUG - 2011-04-30 17:46:20 --> File loaded: application/views/table/main.php
DEBUG - 2011-04-30 17:46:20 --> Helper loaded: url_helper
DEBUG - 2011-04-30 17:46:20 --> File loaded: application/views/common/header.php
DEBUG - 2011-04-30 17:46:20 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-04-30 17:46:20 --> File loaded: application/views/common/footer.php
DEBUG - 2011-04-30 17:46:20 --> File loaded: application/views/layout/main.php
DEBUG - 2011-04-30 17:46:20 --> Final output sent to browser
DEBUG - 2011-04-30 17:46:20 --> Total execution time: 0.4069
DEBUG - 2011-04-30 17:46:21 --> Config Class Initialized
DEBUG - 2011-04-30 17:46:21 --> Hooks Class Initialized
DEBUG - 2011-04-30 17:46:21 --> Utf8 Class Initialized
DEBUG - 2011-04-30 17:46:21 --> UTF-8 Support Enabled
DEBUG - 2011-04-30 17:46:21 --> URI Class Initialized
DEBUG - 2011-04-30 17:46:21 --> Router Class Initialized
DEBUG - 2011-04-30 17:46:21 --> Output Class Initialized
DEBUG - 2011-04-30 17:46:21 --> Input Class Initialized
DEBUG - 2011-04-30 17:46:21 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-30 17:46:21 --> Language Class Initialized
DEBUG - 2011-04-30 17:46:21 --> Loader Class Initialized
DEBUG - 2011-04-30 17:46:21 --> Controller Class Initialized
DEBUG - 2011-04-30 17:46:21 --> Model Class Initialized
DEBUG - 2011-04-30 17:46:21 --> Model Class Initialized
DEBUG - 2011-04-30 17:46:21 --> Model Class Initialized
DEBUG - 2011-04-30 17:46:21 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-30 17:46:21 --> Database Driver Class Initialized
DEBUG - 2011-04-30 17:46:21 --> File loaded: application/views/table/main.php
DEBUG - 2011-04-30 17:46:21 --> Helper loaded: url_helper
DEBUG - 2011-04-30 17:46:21 --> File loaded: application/views/common/header.php
DEBUG - 2011-04-30 17:46:21 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-04-30 17:46:21 --> File loaded: application/views/common/footer.php
DEBUG - 2011-04-30 17:46:21 --> File loaded: application/views/layout/main.php
DEBUG - 2011-04-30 17:46:21 --> Final output sent to browser
DEBUG - 2011-04-30 17:46:21 --> Total execution time: 0.0437
DEBUG - 2011-04-30 17:46:22 --> Config Class Initialized
DEBUG - 2011-04-30 17:46:22 --> Hooks Class Initialized
DEBUG - 2011-04-30 17:46:22 --> Utf8 Class Initialized
DEBUG - 2011-04-30 17:46:22 --> UTF-8 Support Enabled
DEBUG - 2011-04-30 17:46:22 --> URI Class Initialized
DEBUG - 2011-04-30 17:46:22 --> Router Class Initialized
ERROR - 2011-04-30 17:46:22 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-04-30 17:46:23 --> Config Class Initialized
DEBUG - 2011-04-30 17:46:23 --> Hooks Class Initialized
DEBUG - 2011-04-30 17:46:23 --> Utf8 Class Initialized
DEBUG - 2011-04-30 17:46:23 --> UTF-8 Support Enabled
DEBUG - 2011-04-30 17:46:23 --> URI Class Initialized
DEBUG - 2011-04-30 17:46:23 --> Router Class Initialized
DEBUG - 2011-04-30 17:46:23 --> Output Class Initialized
DEBUG - 2011-04-30 17:46:23 --> Input Class Initialized
DEBUG - 2011-04-30 17:46:23 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-30 17:46:23 --> Language Class Initialized
DEBUG - 2011-04-30 17:46:23 --> Loader Class Initialized
DEBUG - 2011-04-30 17:46:23 --> Controller Class Initialized
DEBUG - 2011-04-30 17:46:23 --> Model Class Initialized
DEBUG - 2011-04-30 17:46:23 --> Model Class Initialized
DEBUG - 2011-04-30 17:46:23 --> Model Class Initialized
DEBUG - 2011-04-30 17:46:23 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-30 17:46:23 --> Database Driver Class Initialized
DEBUG - 2011-04-30 17:46:23 --> File loaded: application/views/table/main.php
DEBUG - 2011-04-30 17:46:23 --> Helper loaded: url_helper
DEBUG - 2011-04-30 17:46:23 --> File loaded: application/views/common/header.php
DEBUG - 2011-04-30 17:46:23 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-04-30 17:46:23 --> File loaded: application/views/common/footer.php
DEBUG - 2011-04-30 17:46:23 --> File loaded: application/views/layout/main.php
DEBUG - 2011-04-30 17:46:23 --> Final output sent to browser
DEBUG - 2011-04-30 17:46:23 --> Total execution time: 0.0481
DEBUG - 2011-04-30 17:53:52 --> Config Class Initialized
DEBUG - 2011-04-30 17:53:52 --> Hooks Class Initialized
DEBUG - 2011-04-30 17:53:52 --> Utf8 Class Initialized
DEBUG - 2011-04-30 17:53:52 --> UTF-8 Support Enabled
DEBUG - 2011-04-30 17:53:52 --> URI Class Initialized
DEBUG - 2011-04-30 17:53:52 --> Router Class Initialized
DEBUG - 2011-04-30 17:53:52 --> Output Class Initialized
DEBUG - 2011-04-30 17:53:52 --> Input Class Initialized
DEBUG - 2011-04-30 17:53:52 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-30 17:53:52 --> Language Class Initialized
DEBUG - 2011-04-30 17:53:52 --> Loader Class Initialized
DEBUG - 2011-04-30 17:53:52 --> Controller Class Initialized
DEBUG - 2011-04-30 17:53:52 --> Model Class Initialized
DEBUG - 2011-04-30 17:53:52 --> Model Class Initialized
DEBUG - 2011-04-30 17:53:52 --> Model Class Initialized
DEBUG - 2011-04-30 17:53:52 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-30 17:53:52 --> Database Driver Class Initialized
DEBUG - 2011-04-30 17:53:52 --> File loaded: application/views/table/main.php
DEBUG - 2011-04-30 17:53:52 --> Helper loaded: url_helper
DEBUG - 2011-04-30 17:53:52 --> File loaded: application/views/common/header.php
DEBUG - 2011-04-30 17:53:52 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-04-30 17:53:52 --> File loaded: application/views/common/footer.php
DEBUG - 2011-04-30 17:53:52 --> File loaded: application/views/layout/main.php
DEBUG - 2011-04-30 17:53:52 --> Final output sent to browser
DEBUG - 2011-04-30 17:53:52 --> Total execution time: 0.0452
DEBUG - 2011-04-30 17:53:53 --> Config Class Initialized
DEBUG - 2011-04-30 17:53:53 --> Hooks Class Initialized
DEBUG - 2011-04-30 17:53:53 --> Utf8 Class Initialized
DEBUG - 2011-04-30 17:53:53 --> UTF-8 Support Enabled
DEBUG - 2011-04-30 17:53:53 --> URI Class Initialized
DEBUG - 2011-04-30 17:53:53 --> Router Class Initialized
DEBUG - 2011-04-30 17:53:53 --> Output Class Initialized
DEBUG - 2011-04-30 17:53:53 --> Input Class Initialized
DEBUG - 2011-04-30 17:53:53 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-30 17:53:53 --> Language Class Initialized
DEBUG - 2011-04-30 17:53:53 --> Loader Class Initialized
DEBUG - 2011-04-30 17:53:53 --> Controller Class Initialized
ERROR - 2011-04-30 17:53:53 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-04-30 17:53:53 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-04-30 17:53:53 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-04-30 17:53:53 --> Model Class Initialized
DEBUG - 2011-04-30 17:53:53 --> Model Class Initialized
DEBUG - 2011-04-30 17:53:53 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-30 17:53:53 --> Database Driver Class Initialized
DEBUG - 2011-04-30 17:53:53 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-04-30 17:53:53 --> Helper loaded: url_helper
DEBUG - 2011-04-30 17:53:53 --> File loaded: application/views/common/header.php
DEBUG - 2011-04-30 17:53:53 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-04-30 17:53:53 --> File loaded: application/views/common/footer.php
DEBUG - 2011-04-30 17:53:53 --> File loaded: application/views/layout/main.php
DEBUG - 2011-04-30 17:53:53 --> Final output sent to browser
DEBUG - 2011-04-30 17:53:53 --> Total execution time: 0.1018
DEBUG - 2011-04-30 20:33:10 --> Config Class Initialized
DEBUG - 2011-04-30 20:33:10 --> Hooks Class Initialized
DEBUG - 2011-04-30 20:33:10 --> Utf8 Class Initialized
DEBUG - 2011-04-30 20:33:10 --> UTF-8 Support Enabled
DEBUG - 2011-04-30 20:33:10 --> URI Class Initialized
DEBUG - 2011-04-30 20:33:10 --> Router Class Initialized
DEBUG - 2011-04-30 20:33:10 --> Output Class Initialized
DEBUG - 2011-04-30 20:33:11 --> Input Class Initialized
DEBUG - 2011-04-30 20:33:11 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-30 20:33:11 --> Language Class Initialized
DEBUG - 2011-04-30 20:33:11 --> Loader Class Initialized
DEBUG - 2011-04-30 20:33:11 --> Controller Class Initialized
DEBUG - 2011-04-30 20:33:11 --> Model Class Initialized
DEBUG - 2011-04-30 20:33:11 --> Model Class Initialized
DEBUG - 2011-04-30 20:33:11 --> Model Class Initialized
DEBUG - 2011-04-30 20:33:11 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-30 20:33:11 --> Database Driver Class Initialized
DEBUG - 2011-04-30 20:33:11 --> File loaded: application/views/table/main.php
DEBUG - 2011-04-30 20:33:11 --> Helper loaded: url_helper
DEBUG - 2011-04-30 20:33:11 --> File loaded: application/views/common/header.php
DEBUG - 2011-04-30 20:33:11 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-04-30 20:33:11 --> File loaded: application/views/common/footer.php
DEBUG - 2011-04-30 20:33:11 --> File loaded: application/views/layout/main.php
DEBUG - 2011-04-30 20:33:11 --> Final output sent to browser
DEBUG - 2011-04-30 20:33:11 --> Total execution time: 0.6859
DEBUG - 2011-04-30 20:33:15 --> Config Class Initialized
DEBUG - 2011-04-30 20:33:15 --> Hooks Class Initialized
DEBUG - 2011-04-30 20:33:15 --> Utf8 Class Initialized
DEBUG - 2011-04-30 20:33:15 --> UTF-8 Support Enabled
DEBUG - 2011-04-30 20:33:15 --> URI Class Initialized
DEBUG - 2011-04-30 20:33:15 --> Router Class Initialized
DEBUG - 2011-04-30 20:33:15 --> Output Class Initialized
DEBUG - 2011-04-30 20:33:15 --> Input Class Initialized
DEBUG - 2011-04-30 20:33:15 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-30 20:33:15 --> Language Class Initialized
DEBUG - 2011-04-30 20:33:15 --> Loader Class Initialized
DEBUG - 2011-04-30 20:33:15 --> Controller Class Initialized
ERROR - 2011-04-30 20:33:15 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-04-30 20:33:15 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-04-30 20:33:15 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-04-30 20:33:15 --> Model Class Initialized
DEBUG - 2011-04-30 20:33:15 --> Model Class Initialized
DEBUG - 2011-04-30 20:33:15 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-30 20:33:15 --> Database Driver Class Initialized
DEBUG - 2011-04-30 20:33:15 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-04-30 20:33:15 --> Helper loaded: url_helper
DEBUG - 2011-04-30 20:33:15 --> File loaded: application/views/common/header.php
DEBUG - 2011-04-30 20:33:15 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-04-30 20:33:15 --> File loaded: application/views/common/footer.php
DEBUG - 2011-04-30 20:33:15 --> File loaded: application/views/layout/main.php
DEBUG - 2011-04-30 20:33:15 --> Final output sent to browser
DEBUG - 2011-04-30 20:33:15 --> Total execution time: 0.0814
DEBUG - 2011-04-30 22:10:46 --> Config Class Initialized
DEBUG - 2011-04-30 22:10:46 --> Hooks Class Initialized
DEBUG - 2011-04-30 22:10:46 --> Utf8 Class Initialized
DEBUG - 2011-04-30 22:10:46 --> UTF-8 Support Enabled
DEBUG - 2011-04-30 22:10:46 --> URI Class Initialized
DEBUG - 2011-04-30 22:10:46 --> Router Class Initialized
DEBUG - 2011-04-30 22:10:46 --> No URI present. Default controller set.
DEBUG - 2011-04-30 22:10:46 --> Output Class Initialized
DEBUG - 2011-04-30 22:10:46 --> Input Class Initialized
DEBUG - 2011-04-30 22:10:46 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-30 22:10:46 --> Language Class Initialized
DEBUG - 2011-04-30 22:10:46 --> Loader Class Initialized
DEBUG - 2011-04-30 22:10:46 --> Controller Class Initialized
DEBUG - 2011-04-30 22:10:46 --> File loaded: application/views/splash/main.php
DEBUG - 2011-04-30 22:10:46 --> Helper loaded: url_helper
DEBUG - 2011-04-30 22:10:46 --> File loaded: application/views/common/header.php
DEBUG - 2011-04-30 22:10:46 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-04-30 22:10:46 --> File loaded: application/views/common/footer.php
DEBUG - 2011-04-30 22:10:46 --> File loaded: application/views/layout/main.php
DEBUG - 2011-04-30 22:10:46 --> Final output sent to browser
DEBUG - 2011-04-30 22:10:46 --> Total execution time: 0.5487
DEBUG - 2011-04-30 22:26:49 --> Config Class Initialized
DEBUG - 2011-04-30 22:26:49 --> Hooks Class Initialized
DEBUG - 2011-04-30 22:26:49 --> Utf8 Class Initialized
DEBUG - 2011-04-30 22:26:49 --> UTF-8 Support Enabled
DEBUG - 2011-04-30 22:26:49 --> URI Class Initialized
DEBUG - 2011-04-30 22:26:49 --> Router Class Initialized
DEBUG - 2011-04-30 22:26:49 --> Output Class Initialized
DEBUG - 2011-04-30 22:26:49 --> Input Class Initialized
DEBUG - 2011-04-30 22:26:49 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-30 22:26:49 --> Language Class Initialized
DEBUG - 2011-04-30 22:26:49 --> Loader Class Initialized
DEBUG - 2011-04-30 22:26:49 --> Controller Class Initialized
ERROR - 2011-04-30 22:26:49 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-04-30 22:26:49 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-04-30 22:26:49 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-04-30 22:26:49 --> Model Class Initialized
DEBUG - 2011-04-30 22:26:49 --> Model Class Initialized
DEBUG - 2011-04-30 22:26:49 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-30 22:26:50 --> Database Driver Class Initialized
DEBUG - 2011-04-30 22:26:50 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-04-30 22:26:50 --> Helper loaded: url_helper
DEBUG - 2011-04-30 22:26:50 --> File loaded: application/views/common/header.php
DEBUG - 2011-04-30 22:26:50 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-04-30 22:26:50 --> File loaded: application/views/common/footer.php
DEBUG - 2011-04-30 22:26:50 --> File loaded: application/views/layout/main.php
DEBUG - 2011-04-30 22:26:50 --> Final output sent to browser
DEBUG - 2011-04-30 22:26:50 --> Total execution time: 0.1855
DEBUG - 2011-04-30 22:26:50 --> Config Class Initialized
DEBUG - 2011-04-30 22:26:50 --> Hooks Class Initialized
DEBUG - 2011-04-30 22:26:50 --> Utf8 Class Initialized
DEBUG - 2011-04-30 22:26:50 --> UTF-8 Support Enabled
DEBUG - 2011-04-30 22:26:50 --> URI Class Initialized
DEBUG - 2011-04-30 22:26:50 --> Router Class Initialized
DEBUG - 2011-04-30 22:26:50 --> Output Class Initialized
DEBUG - 2011-04-30 22:26:50 --> Input Class Initialized
DEBUG - 2011-04-30 22:26:50 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-30 22:26:50 --> Language Class Initialized
DEBUG - 2011-04-30 22:26:50 --> Loader Class Initialized
DEBUG - 2011-04-30 22:26:50 --> Controller Class Initialized
DEBUG - 2011-04-30 22:26:50 --> Model Class Initialized
DEBUG - 2011-04-30 22:26:50 --> Model Class Initialized
DEBUG - 2011-04-30 22:26:50 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-30 22:26:50 --> Database Driver Class Initialized
DEBUG - 2011-04-30 22:26:51 --> Final output sent to browser
DEBUG - 2011-04-30 22:26:51 --> Total execution time: 0.6794
DEBUG - 2011-04-30 22:28:14 --> Config Class Initialized
DEBUG - 2011-04-30 22:28:14 --> Hooks Class Initialized
DEBUG - 2011-04-30 22:28:14 --> Utf8 Class Initialized
DEBUG - 2011-04-30 22:28:14 --> UTF-8 Support Enabled
DEBUG - 2011-04-30 22:28:14 --> URI Class Initialized
DEBUG - 2011-04-30 22:28:14 --> Router Class Initialized
DEBUG - 2011-04-30 22:28:14 --> Output Class Initialized
DEBUG - 2011-04-30 22:28:14 --> Input Class Initialized
DEBUG - 2011-04-30 22:28:14 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-30 22:28:14 --> Language Class Initialized
DEBUG - 2011-04-30 22:28:14 --> Loader Class Initialized
DEBUG - 2011-04-30 22:28:14 --> Controller Class Initialized
ERROR - 2011-04-30 22:28:14 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-04-30 22:28:14 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-04-30 22:28:14 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-04-30 22:28:14 --> Model Class Initialized
DEBUG - 2011-04-30 22:28:14 --> Model Class Initialized
DEBUG - 2011-04-30 22:28:14 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-30 22:28:14 --> Database Driver Class Initialized
DEBUG - 2011-04-30 22:28:14 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-04-30 22:28:14 --> Helper loaded: url_helper
DEBUG - 2011-04-30 22:28:14 --> File loaded: application/views/common/header.php
DEBUG - 2011-04-30 22:28:14 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-04-30 22:28:14 --> File loaded: application/views/common/footer.php
DEBUG - 2011-04-30 22:28:14 --> File loaded: application/views/layout/main.php
DEBUG - 2011-04-30 22:28:14 --> Final output sent to browser
DEBUG - 2011-04-30 22:28:14 --> Total execution time: 0.0301
DEBUG - 2011-04-30 22:28:15 --> Config Class Initialized
DEBUG - 2011-04-30 22:28:15 --> Hooks Class Initialized
DEBUG - 2011-04-30 22:28:15 --> Utf8 Class Initialized
DEBUG - 2011-04-30 22:28:15 --> UTF-8 Support Enabled
DEBUG - 2011-04-30 22:28:15 --> URI Class Initialized
DEBUG - 2011-04-30 22:28:15 --> Router Class Initialized
DEBUG - 2011-04-30 22:28:15 --> Output Class Initialized
DEBUG - 2011-04-30 22:28:15 --> Input Class Initialized
DEBUG - 2011-04-30 22:28:15 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-30 22:28:15 --> Language Class Initialized
DEBUG - 2011-04-30 22:28:15 --> Loader Class Initialized
DEBUG - 2011-04-30 22:28:15 --> Controller Class Initialized
DEBUG - 2011-04-30 22:28:15 --> Model Class Initialized
DEBUG - 2011-04-30 22:28:15 --> Model Class Initialized
DEBUG - 2011-04-30 22:28:15 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-30 22:28:15 --> Database Driver Class Initialized
DEBUG - 2011-04-30 22:28:16 --> Final output sent to browser
DEBUG - 2011-04-30 22:28:16 --> Total execution time: 0.7672
DEBUG - 2011-04-30 22:28:16 --> Config Class Initialized
DEBUG - 2011-04-30 22:28:16 --> Hooks Class Initialized
DEBUG - 2011-04-30 22:28:16 --> Utf8 Class Initialized
DEBUG - 2011-04-30 22:28:16 --> UTF-8 Support Enabled
DEBUG - 2011-04-30 22:28:16 --> URI Class Initialized
DEBUG - 2011-04-30 22:28:16 --> Router Class Initialized
DEBUG - 2011-04-30 22:28:16 --> Output Class Initialized
DEBUG - 2011-04-30 22:28:16 --> Input Class Initialized
DEBUG - 2011-04-30 22:28:16 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-30 22:28:16 --> Language Class Initialized
DEBUG - 2011-04-30 22:28:16 --> Loader Class Initialized
DEBUG - 2011-04-30 22:28:16 --> Controller Class Initialized
ERROR - 2011-04-30 22:28:16 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-04-30 22:28:16 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-04-30 22:28:16 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-04-30 22:28:16 --> Model Class Initialized
DEBUG - 2011-04-30 22:28:16 --> Model Class Initialized
DEBUG - 2011-04-30 22:28:16 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-30 22:28:16 --> Database Driver Class Initialized
DEBUG - 2011-04-30 22:28:16 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-04-30 22:28:16 --> Helper loaded: url_helper
DEBUG - 2011-04-30 22:28:16 --> File loaded: application/views/common/header.php
DEBUG - 2011-04-30 22:28:16 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-04-30 22:28:16 --> File loaded: application/views/common/footer.php
DEBUG - 2011-04-30 22:28:16 --> File loaded: application/views/layout/main.php
DEBUG - 2011-04-30 22:28:16 --> Final output sent to browser
DEBUG - 2011-04-30 22:28:16 --> Total execution time: 0.0326
DEBUG - 2011-04-30 22:28:42 --> Config Class Initialized
DEBUG - 2011-04-30 22:28:42 --> Hooks Class Initialized
DEBUG - 2011-04-30 22:28:42 --> Utf8 Class Initialized
DEBUG - 2011-04-30 22:28:42 --> UTF-8 Support Enabled
DEBUG - 2011-04-30 22:28:42 --> URI Class Initialized
DEBUG - 2011-04-30 22:28:42 --> Router Class Initialized
DEBUG - 2011-04-30 22:28:42 --> Output Class Initialized
DEBUG - 2011-04-30 22:28:42 --> Input Class Initialized
DEBUG - 2011-04-30 22:28:42 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-30 22:28:42 --> Language Class Initialized
DEBUG - 2011-04-30 22:28:42 --> Loader Class Initialized
DEBUG - 2011-04-30 22:28:42 --> Controller Class Initialized
ERROR - 2011-04-30 22:28:42 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-04-30 22:28:42 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-04-30 22:28:42 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-04-30 22:28:42 --> Model Class Initialized
DEBUG - 2011-04-30 22:28:42 --> Model Class Initialized
DEBUG - 2011-04-30 22:28:42 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-30 22:28:42 --> Database Driver Class Initialized
DEBUG - 2011-04-30 22:28:42 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-04-30 22:28:42 --> Helper loaded: url_helper
DEBUG - 2011-04-30 22:28:42 --> File loaded: application/views/common/header.php
DEBUG - 2011-04-30 22:28:42 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-04-30 22:28:42 --> File loaded: application/views/common/footer.php
DEBUG - 2011-04-30 22:28:42 --> File loaded: application/views/layout/main.php
DEBUG - 2011-04-30 22:28:42 --> Final output sent to browser
DEBUG - 2011-04-30 22:28:42 --> Total execution time: 0.0317
DEBUG - 2011-04-30 22:28:43 --> Config Class Initialized
DEBUG - 2011-04-30 22:28:43 --> Hooks Class Initialized
DEBUG - 2011-04-30 22:28:43 --> Utf8 Class Initialized
DEBUG - 2011-04-30 22:28:43 --> UTF-8 Support Enabled
DEBUG - 2011-04-30 22:28:43 --> URI Class Initialized
DEBUG - 2011-04-30 22:28:43 --> Router Class Initialized
DEBUG - 2011-04-30 22:28:43 --> Output Class Initialized
DEBUG - 2011-04-30 22:28:43 --> Input Class Initialized
DEBUG - 2011-04-30 22:28:43 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-30 22:28:43 --> Language Class Initialized
DEBUG - 2011-04-30 22:28:43 --> Loader Class Initialized
DEBUG - 2011-04-30 22:28:43 --> Controller Class Initialized
DEBUG - 2011-04-30 22:28:43 --> Model Class Initialized
DEBUG - 2011-04-30 22:28:43 --> Model Class Initialized
DEBUG - 2011-04-30 22:28:43 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-30 22:28:43 --> Database Driver Class Initialized
DEBUG - 2011-04-30 22:28:44 --> Final output sent to browser
DEBUG - 2011-04-30 22:28:44 --> Total execution time: 0.5912
DEBUG - 2011-04-30 22:28:45 --> Config Class Initialized
DEBUG - 2011-04-30 22:28:45 --> Hooks Class Initialized
DEBUG - 2011-04-30 22:28:45 --> Utf8 Class Initialized
DEBUG - 2011-04-30 22:28:45 --> UTF-8 Support Enabled
DEBUG - 2011-04-30 22:28:45 --> URI Class Initialized
DEBUG - 2011-04-30 22:28:45 --> Router Class Initialized
ERROR - 2011-04-30 22:28:45 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-04-30 22:29:06 --> Config Class Initialized
DEBUG - 2011-04-30 22:29:06 --> Hooks Class Initialized
DEBUG - 2011-04-30 22:29:06 --> Utf8 Class Initialized
DEBUG - 2011-04-30 22:29:06 --> UTF-8 Support Enabled
DEBUG - 2011-04-30 22:29:06 --> URI Class Initialized
DEBUG - 2011-04-30 22:29:06 --> Router Class Initialized
DEBUG - 2011-04-30 22:29:06 --> Output Class Initialized
DEBUG - 2011-04-30 22:29:06 --> Input Class Initialized
DEBUG - 2011-04-30 22:29:06 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-30 22:29:06 --> Language Class Initialized
DEBUG - 2011-04-30 22:29:06 --> Loader Class Initialized
DEBUG - 2011-04-30 22:29:06 --> Controller Class Initialized
ERROR - 2011-04-30 22:29:06 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-04-30 22:29:06 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-04-30 22:29:06 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-04-30 22:29:06 --> Model Class Initialized
DEBUG - 2011-04-30 22:29:06 --> Model Class Initialized
DEBUG - 2011-04-30 22:29:06 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-30 22:29:06 --> Database Driver Class Initialized
DEBUG - 2011-04-30 22:29:06 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-04-30 22:29:06 --> Helper loaded: url_helper
DEBUG - 2011-04-30 22:29:06 --> File loaded: application/views/common/header.php
DEBUG - 2011-04-30 22:29:06 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-04-30 22:29:06 --> File loaded: application/views/common/footer.php
DEBUG - 2011-04-30 22:29:06 --> File loaded: application/views/layout/main.php
DEBUG - 2011-04-30 22:29:06 --> Final output sent to browser
DEBUG - 2011-04-30 22:29:06 --> Total execution time: 0.0298
DEBUG - 2011-04-30 22:29:07 --> Config Class Initialized
DEBUG - 2011-04-30 22:29:07 --> Hooks Class Initialized
DEBUG - 2011-04-30 22:29:07 --> Utf8 Class Initialized
DEBUG - 2011-04-30 22:29:07 --> UTF-8 Support Enabled
DEBUG - 2011-04-30 22:29:07 --> URI Class Initialized
DEBUG - 2011-04-30 22:29:07 --> Router Class Initialized
DEBUG - 2011-04-30 22:29:07 --> Output Class Initialized
DEBUG - 2011-04-30 22:29:07 --> Input Class Initialized
DEBUG - 2011-04-30 22:29:07 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-30 22:29:07 --> Language Class Initialized
DEBUG - 2011-04-30 22:29:07 --> Loader Class Initialized
DEBUG - 2011-04-30 22:29:07 --> Controller Class Initialized
DEBUG - 2011-04-30 22:29:07 --> Model Class Initialized
DEBUG - 2011-04-30 22:29:07 --> Model Class Initialized
DEBUG - 2011-04-30 22:29:07 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-30 22:29:07 --> Database Driver Class Initialized
DEBUG - 2011-04-30 22:29:08 --> Final output sent to browser
DEBUG - 2011-04-30 22:29:08 --> Total execution time: 0.6646
DEBUG - 2011-04-30 22:30:07 --> Config Class Initialized
DEBUG - 2011-04-30 22:30:07 --> Hooks Class Initialized
DEBUG - 2011-04-30 22:30:07 --> Utf8 Class Initialized
DEBUG - 2011-04-30 22:30:07 --> UTF-8 Support Enabled
DEBUG - 2011-04-30 22:30:07 --> URI Class Initialized
DEBUG - 2011-04-30 22:30:07 --> Router Class Initialized
ERROR - 2011-04-30 22:30:07 --> 404 Page Not Found --> robots.txt
DEBUG - 2011-04-30 22:30:48 --> Config Class Initialized
DEBUG - 2011-04-30 22:30:48 --> Hooks Class Initialized
DEBUG - 2011-04-30 22:30:48 --> Utf8 Class Initialized
DEBUG - 2011-04-30 22:30:48 --> UTF-8 Support Enabled
DEBUG - 2011-04-30 22:30:48 --> URI Class Initialized
DEBUG - 2011-04-30 22:30:48 --> Router Class Initialized
DEBUG - 2011-04-30 22:30:48 --> No URI present. Default controller set.
DEBUG - 2011-04-30 22:30:48 --> Output Class Initialized
DEBUG - 2011-04-30 22:30:48 --> Input Class Initialized
DEBUG - 2011-04-30 22:30:48 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-30 22:30:48 --> Language Class Initialized
DEBUG - 2011-04-30 22:30:48 --> Loader Class Initialized
DEBUG - 2011-04-30 22:30:48 --> Controller Class Initialized
DEBUG - 2011-04-30 22:30:48 --> File loaded: application/views/splash/main.php
DEBUG - 2011-04-30 22:30:48 --> Helper loaded: url_helper
DEBUG - 2011-04-30 22:30:48 --> File loaded: application/views/common/header.php
DEBUG - 2011-04-30 22:30:48 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-04-30 22:30:48 --> File loaded: application/views/common/footer.php
DEBUG - 2011-04-30 22:30:48 --> File loaded: application/views/layout/main.php
DEBUG - 2011-04-30 22:30:48 --> Final output sent to browser
DEBUG - 2011-04-30 22:30:48 --> Total execution time: 0.0364
DEBUG - 2011-04-30 23:12:50 --> Config Class Initialized
DEBUG - 2011-04-30 23:12:50 --> Hooks Class Initialized
DEBUG - 2011-04-30 23:12:50 --> Utf8 Class Initialized
DEBUG - 2011-04-30 23:12:50 --> UTF-8 Support Enabled
DEBUG - 2011-04-30 23:12:50 --> URI Class Initialized
DEBUG - 2011-04-30 23:12:50 --> Router Class Initialized
DEBUG - 2011-04-30 23:12:50 --> Output Class Initialized
DEBUG - 2011-04-30 23:12:50 --> Input Class Initialized
DEBUG - 2011-04-30 23:12:50 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-30 23:12:50 --> Language Class Initialized
DEBUG - 2011-04-30 23:12:50 --> Loader Class Initialized
DEBUG - 2011-04-30 23:12:50 --> Controller Class Initialized
DEBUG - 2011-04-30 23:12:50 --> Model Class Initialized
DEBUG - 2011-04-30 23:12:50 --> Model Class Initialized
DEBUG - 2011-04-30 23:12:50 --> Model Class Initialized
DEBUG - 2011-04-30 23:12:50 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-30 23:12:50 --> Database Driver Class Initialized
DEBUG - 2011-04-30 23:12:50 --> File loaded: application/views/table/main.php
DEBUG - 2011-04-30 23:12:50 --> Helper loaded: url_helper
DEBUG - 2011-04-30 23:12:50 --> File loaded: application/views/common/header.php
DEBUG - 2011-04-30 23:12:50 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-04-30 23:12:50 --> File loaded: application/views/common/footer.php
DEBUG - 2011-04-30 23:12:50 --> File loaded: application/views/layout/main.php
DEBUG - 2011-04-30 23:12:50 --> Final output sent to browser
DEBUG - 2011-04-30 23:12:50 --> Total execution time: 0.2857
DEBUG - 2011-04-30 23:12:51 --> Config Class Initialized
DEBUG - 2011-04-30 23:12:51 --> Hooks Class Initialized
DEBUG - 2011-04-30 23:12:51 --> Utf8 Class Initialized
DEBUG - 2011-04-30 23:12:51 --> UTF-8 Support Enabled
DEBUG - 2011-04-30 23:12:51 --> URI Class Initialized
DEBUG - 2011-04-30 23:12:51 --> Router Class Initialized
DEBUG - 2011-04-30 23:12:51 --> Output Class Initialized
DEBUG - 2011-04-30 23:12:51 --> Input Class Initialized
DEBUG - 2011-04-30 23:12:51 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-30 23:12:51 --> Language Class Initialized
DEBUG - 2011-04-30 23:12:51 --> Loader Class Initialized
DEBUG - 2011-04-30 23:12:51 --> Controller Class Initialized
ERROR - 2011-04-30 23:12:51 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-04-30 23:12:51 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-04-30 23:12:51 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-04-30 23:12:51 --> Model Class Initialized
DEBUG - 2011-04-30 23:12:51 --> Model Class Initialized
DEBUG - 2011-04-30 23:12:51 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-30 23:12:51 --> Database Driver Class Initialized
DEBUG - 2011-04-30 23:12:51 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-04-30 23:12:51 --> Helper loaded: url_helper
DEBUG - 2011-04-30 23:12:51 --> File loaded: application/views/common/header.php
DEBUG - 2011-04-30 23:12:51 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-04-30 23:12:51 --> File loaded: application/views/common/footer.php
DEBUG - 2011-04-30 23:12:51 --> File loaded: application/views/layout/main.php
DEBUG - 2011-04-30 23:12:51 --> Final output sent to browser
DEBUG - 2011-04-30 23:12:51 --> Total execution time: 0.0369

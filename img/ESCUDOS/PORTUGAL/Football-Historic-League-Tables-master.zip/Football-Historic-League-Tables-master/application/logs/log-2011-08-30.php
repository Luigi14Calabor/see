<?php  if ( ! defined('BASEPATH')) exit('No direct script access allowed'); ?>

DEBUG - 2011-08-30 00:31:21 --> Config Class Initialized
DEBUG - 2011-08-30 00:31:21 --> Hooks Class Initialized
DEBUG - 2011-08-30 00:31:21 --> Utf8 Class Initialized
DEBUG - 2011-08-30 00:31:21 --> UTF-8 Support Enabled
DEBUG - 2011-08-30 00:31:22 --> URI Class Initialized
DEBUG - 2011-08-30 00:31:22 --> Router Class Initialized
ERROR - 2011-08-30 00:31:22 --> 404 Page Not Found --> robots.txt
DEBUG - 2011-08-30 00:31:22 --> Config Class Initialized
DEBUG - 2011-08-30 00:31:22 --> Hooks Class Initialized
DEBUG - 2011-08-30 00:31:22 --> Utf8 Class Initialized
DEBUG - 2011-08-30 00:31:22 --> UTF-8 Support Enabled
DEBUG - 2011-08-30 00:31:22 --> URI Class Initialized
DEBUG - 2011-08-30 00:31:22 --> Router Class Initialized
DEBUG - 2011-08-30 00:31:22 --> Output Class Initialized
DEBUG - 2011-08-30 00:31:22 --> Input Class Initialized
DEBUG - 2011-08-30 00:31:22 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-30 00:31:22 --> Language Class Initialized
DEBUG - 2011-08-30 00:31:22 --> Loader Class Initialized
DEBUG - 2011-08-30 00:31:22 --> Controller Class Initialized
ERROR - 2011-08-30 00:31:22 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-08-30 00:31:22 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-08-30 00:31:22 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-08-30 00:31:22 --> Model Class Initialized
DEBUG - 2011-08-30 00:31:22 --> Model Class Initialized
DEBUG - 2011-08-30 00:31:22 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-30 00:31:22 --> Database Driver Class Initialized
DEBUG - 2011-08-30 00:31:22 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-08-30 00:31:22 --> Helper loaded: url_helper
DEBUG - 2011-08-30 00:31:22 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-30 00:31:22 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-30 00:31:22 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-30 00:31:22 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-30 00:31:22 --> Final output sent to browser
DEBUG - 2011-08-30 00:31:22 --> Total execution time: 0.0301
DEBUG - 2011-08-30 00:49:12 --> Config Class Initialized
DEBUG - 2011-08-30 00:49:12 --> Hooks Class Initialized
DEBUG - 2011-08-30 00:49:12 --> Utf8 Class Initialized
DEBUG - 2011-08-30 00:49:12 --> UTF-8 Support Enabled
DEBUG - 2011-08-30 00:49:12 --> URI Class Initialized
DEBUG - 2011-08-30 00:49:12 --> Router Class Initialized
DEBUG - 2011-08-30 00:49:12 --> Output Class Initialized
DEBUG - 2011-08-30 00:49:12 --> Input Class Initialized
DEBUG - 2011-08-30 00:49:12 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-30 00:49:12 --> Language Class Initialized
DEBUG - 2011-08-30 00:49:12 --> Loader Class Initialized
DEBUG - 2011-08-30 00:49:12 --> Controller Class Initialized
ERROR - 2011-08-30 00:49:12 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-08-30 00:49:12 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-08-30 00:49:12 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-08-30 00:49:12 --> Model Class Initialized
DEBUG - 2011-08-30 00:49:12 --> Model Class Initialized
DEBUG - 2011-08-30 00:49:12 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-30 00:49:12 --> Database Driver Class Initialized
DEBUG - 2011-08-30 00:49:12 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-08-30 00:49:12 --> Helper loaded: url_helper
DEBUG - 2011-08-30 00:49:12 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-30 00:49:12 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-30 00:49:12 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-30 00:49:12 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-30 00:49:12 --> Final output sent to browser
DEBUG - 2011-08-30 00:49:12 --> Total execution time: 0.0327
DEBUG - 2011-08-30 00:49:13 --> Config Class Initialized
DEBUG - 2011-08-30 00:49:13 --> Hooks Class Initialized
DEBUG - 2011-08-30 00:49:13 --> Utf8 Class Initialized
DEBUG - 2011-08-30 00:49:13 --> UTF-8 Support Enabled
DEBUG - 2011-08-30 00:49:13 --> URI Class Initialized
DEBUG - 2011-08-30 00:49:13 --> Router Class Initialized
DEBUG - 2011-08-30 00:49:13 --> Output Class Initialized
DEBUG - 2011-08-30 00:49:13 --> Input Class Initialized
DEBUG - 2011-08-30 00:49:13 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-30 00:49:13 --> Language Class Initialized
DEBUG - 2011-08-30 00:49:13 --> Loader Class Initialized
DEBUG - 2011-08-30 00:49:13 --> Controller Class Initialized
DEBUG - 2011-08-30 00:49:13 --> Model Class Initialized
DEBUG - 2011-08-30 00:49:13 --> Model Class Initialized
DEBUG - 2011-08-30 00:49:13 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-30 00:49:13 --> Database Driver Class Initialized
DEBUG - 2011-08-30 00:49:14 --> Final output sent to browser
DEBUG - 2011-08-30 00:49:14 --> Total execution time: 0.6695
DEBUG - 2011-08-30 00:49:15 --> Config Class Initialized
DEBUG - 2011-08-30 00:49:15 --> Hooks Class Initialized
DEBUG - 2011-08-30 00:49:15 --> Utf8 Class Initialized
DEBUG - 2011-08-30 00:49:15 --> UTF-8 Support Enabled
DEBUG - 2011-08-30 00:49:15 --> URI Class Initialized
DEBUG - 2011-08-30 00:49:15 --> Router Class Initialized
ERROR - 2011-08-30 00:49:15 --> 404 Page Not Found --> eyewonder
DEBUG - 2011-08-30 00:49:16 --> Config Class Initialized
DEBUG - 2011-08-30 00:49:16 --> Hooks Class Initialized
DEBUG - 2011-08-30 00:49:16 --> Utf8 Class Initialized
DEBUG - 2011-08-30 00:49:16 --> UTF-8 Support Enabled
DEBUG - 2011-08-30 00:49:16 --> URI Class Initialized
DEBUG - 2011-08-30 00:49:16 --> Router Class Initialized
ERROR - 2011-08-30 00:49:16 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-08-30 00:49:17 --> Config Class Initialized
DEBUG - 2011-08-30 00:49:17 --> Hooks Class Initialized
DEBUG - 2011-08-30 00:49:17 --> Utf8 Class Initialized
DEBUG - 2011-08-30 00:49:17 --> UTF-8 Support Enabled
DEBUG - 2011-08-30 00:49:17 --> URI Class Initialized
DEBUG - 2011-08-30 00:49:17 --> Router Class Initialized
ERROR - 2011-08-30 00:49:17 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-08-30 00:49:45 --> Config Class Initialized
DEBUG - 2011-08-30 00:49:45 --> Hooks Class Initialized
DEBUG - 2011-08-30 00:49:45 --> Utf8 Class Initialized
DEBUG - 2011-08-30 00:49:45 --> UTF-8 Support Enabled
DEBUG - 2011-08-30 00:49:45 --> URI Class Initialized
DEBUG - 2011-08-30 00:49:45 --> Router Class Initialized
DEBUG - 2011-08-30 00:49:45 --> Output Class Initialized
DEBUG - 2011-08-30 00:49:45 --> Input Class Initialized
DEBUG - 2011-08-30 00:49:45 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-30 00:49:45 --> Language Class Initialized
DEBUG - 2011-08-30 00:49:45 --> Loader Class Initialized
DEBUG - 2011-08-30 00:49:45 --> Controller Class Initialized
ERROR - 2011-08-30 00:49:45 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-08-30 00:49:45 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-08-30 00:49:45 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-08-30 00:49:45 --> Model Class Initialized
DEBUG - 2011-08-30 00:49:45 --> Model Class Initialized
DEBUG - 2011-08-30 00:49:45 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-30 00:49:45 --> Database Driver Class Initialized
DEBUG - 2011-08-30 00:49:45 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-08-30 00:49:45 --> Helper loaded: url_helper
DEBUG - 2011-08-30 00:49:45 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-30 00:49:45 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-30 00:49:45 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-30 00:49:45 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-30 00:49:45 --> Final output sent to browser
DEBUG - 2011-08-30 00:49:45 --> Total execution time: 0.0267
DEBUG - 2011-08-30 00:49:45 --> Config Class Initialized
DEBUG - 2011-08-30 00:49:45 --> Hooks Class Initialized
DEBUG - 2011-08-30 00:49:45 --> Utf8 Class Initialized
DEBUG - 2011-08-30 00:49:45 --> UTF-8 Support Enabled
DEBUG - 2011-08-30 00:49:45 --> URI Class Initialized
DEBUG - 2011-08-30 00:49:45 --> Router Class Initialized
DEBUG - 2011-08-30 00:49:45 --> Output Class Initialized
DEBUG - 2011-08-30 00:49:45 --> Input Class Initialized
DEBUG - 2011-08-30 00:49:45 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-30 00:49:45 --> Language Class Initialized
DEBUG - 2011-08-30 00:49:45 --> Loader Class Initialized
DEBUG - 2011-08-30 00:49:45 --> Controller Class Initialized
DEBUG - 2011-08-30 00:49:45 --> Model Class Initialized
DEBUG - 2011-08-30 00:49:45 --> Model Class Initialized
DEBUG - 2011-08-30 00:49:45 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-30 00:49:45 --> Database Driver Class Initialized
DEBUG - 2011-08-30 00:49:46 --> Final output sent to browser
DEBUG - 2011-08-30 00:49:46 --> Total execution time: 0.4917
DEBUG - 2011-08-30 00:49:47 --> Config Class Initialized
DEBUG - 2011-08-30 00:49:47 --> Hooks Class Initialized
DEBUG - 2011-08-30 00:49:47 --> Utf8 Class Initialized
DEBUG - 2011-08-30 00:49:47 --> UTF-8 Support Enabled
DEBUG - 2011-08-30 00:49:47 --> URI Class Initialized
DEBUG - 2011-08-30 00:49:47 --> Router Class Initialized
ERROR - 2011-08-30 00:49:47 --> 404 Page Not Found --> eyewonder
DEBUG - 2011-08-30 00:50:07 --> Config Class Initialized
DEBUG - 2011-08-30 00:50:07 --> Hooks Class Initialized
DEBUG - 2011-08-30 00:50:07 --> Utf8 Class Initialized
DEBUG - 2011-08-30 00:50:07 --> UTF-8 Support Enabled
DEBUG - 2011-08-30 00:50:07 --> URI Class Initialized
DEBUG - 2011-08-30 00:50:07 --> Router Class Initialized
DEBUG - 2011-08-30 00:50:07 --> Output Class Initialized
DEBUG - 2011-08-30 00:50:07 --> Input Class Initialized
DEBUG - 2011-08-30 00:50:07 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-30 00:50:07 --> Language Class Initialized
DEBUG - 2011-08-30 00:50:07 --> Loader Class Initialized
DEBUG - 2011-08-30 00:50:07 --> Controller Class Initialized
ERROR - 2011-08-30 00:50:07 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-08-30 00:50:07 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-08-30 00:50:07 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-08-30 00:50:07 --> Model Class Initialized
DEBUG - 2011-08-30 00:50:07 --> Model Class Initialized
DEBUG - 2011-08-30 00:50:07 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-30 00:50:07 --> Database Driver Class Initialized
DEBUG - 2011-08-30 00:50:07 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-08-30 00:50:07 --> Helper loaded: url_helper
DEBUG - 2011-08-30 00:50:07 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-30 00:50:07 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-30 00:50:07 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-30 00:50:07 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-30 00:50:07 --> Final output sent to browser
DEBUG - 2011-08-30 00:50:07 --> Total execution time: 0.0295
DEBUG - 2011-08-30 00:50:07 --> Config Class Initialized
DEBUG - 2011-08-30 00:50:07 --> Hooks Class Initialized
DEBUG - 2011-08-30 00:50:07 --> Utf8 Class Initialized
DEBUG - 2011-08-30 00:50:07 --> UTF-8 Support Enabled
DEBUG - 2011-08-30 00:50:07 --> URI Class Initialized
DEBUG - 2011-08-30 00:50:07 --> Router Class Initialized
DEBUG - 2011-08-30 00:50:07 --> Output Class Initialized
DEBUG - 2011-08-30 00:50:07 --> Input Class Initialized
DEBUG - 2011-08-30 00:50:07 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-30 00:50:07 --> Language Class Initialized
DEBUG - 2011-08-30 00:50:07 --> Loader Class Initialized
DEBUG - 2011-08-30 00:50:07 --> Controller Class Initialized
DEBUG - 2011-08-30 00:50:07 --> Model Class Initialized
DEBUG - 2011-08-30 00:50:07 --> Model Class Initialized
DEBUG - 2011-08-30 00:50:07 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-30 00:50:07 --> Database Driver Class Initialized
DEBUG - 2011-08-30 00:50:08 --> Final output sent to browser
DEBUG - 2011-08-30 00:50:08 --> Total execution time: 0.5630
DEBUG - 2011-08-30 00:50:15 --> Config Class Initialized
DEBUG - 2011-08-30 00:50:15 --> Hooks Class Initialized
DEBUG - 2011-08-30 00:50:15 --> Utf8 Class Initialized
DEBUG - 2011-08-30 00:50:15 --> UTF-8 Support Enabled
DEBUG - 2011-08-30 00:50:15 --> URI Class Initialized
DEBUG - 2011-08-30 00:50:15 --> Router Class Initialized
DEBUG - 2011-08-30 00:50:15 --> Output Class Initialized
DEBUG - 2011-08-30 00:50:15 --> Input Class Initialized
DEBUG - 2011-08-30 00:50:15 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-30 00:50:15 --> Language Class Initialized
DEBUG - 2011-08-30 00:50:15 --> Loader Class Initialized
DEBUG - 2011-08-30 00:50:15 --> Controller Class Initialized
ERROR - 2011-08-30 00:50:15 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-08-30 00:50:15 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-08-30 00:50:15 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-08-30 00:50:15 --> Model Class Initialized
DEBUG - 2011-08-30 00:50:15 --> Model Class Initialized
DEBUG - 2011-08-30 00:50:15 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-30 00:50:15 --> Database Driver Class Initialized
DEBUG - 2011-08-30 00:50:15 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-08-30 00:50:15 --> Helper loaded: url_helper
DEBUG - 2011-08-30 00:50:15 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-30 00:50:15 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-30 00:50:15 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-30 00:50:15 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-30 00:50:15 --> Final output sent to browser
DEBUG - 2011-08-30 00:50:15 --> Total execution time: 0.0491
DEBUG - 2011-08-30 00:50:15 --> Config Class Initialized
DEBUG - 2011-08-30 00:50:15 --> Hooks Class Initialized
DEBUG - 2011-08-30 00:50:15 --> Utf8 Class Initialized
DEBUG - 2011-08-30 00:50:15 --> UTF-8 Support Enabled
DEBUG - 2011-08-30 00:50:15 --> URI Class Initialized
DEBUG - 2011-08-30 00:50:15 --> Router Class Initialized
DEBUG - 2011-08-30 00:50:15 --> Output Class Initialized
DEBUG - 2011-08-30 00:50:15 --> Input Class Initialized
DEBUG - 2011-08-30 00:50:15 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-30 00:50:15 --> Language Class Initialized
DEBUG - 2011-08-30 00:50:15 --> Loader Class Initialized
DEBUG - 2011-08-30 00:50:15 --> Controller Class Initialized
DEBUG - 2011-08-30 00:50:15 --> Model Class Initialized
DEBUG - 2011-08-30 00:50:15 --> Model Class Initialized
DEBUG - 2011-08-30 00:50:15 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-30 00:50:15 --> Database Driver Class Initialized
DEBUG - 2011-08-30 00:50:16 --> Final output sent to browser
DEBUG - 2011-08-30 00:50:16 --> Total execution time: 0.6197
DEBUG - 2011-08-30 00:50:22 --> Config Class Initialized
DEBUG - 2011-08-30 00:50:22 --> Hooks Class Initialized
DEBUG - 2011-08-30 00:50:22 --> Utf8 Class Initialized
DEBUG - 2011-08-30 00:50:22 --> UTF-8 Support Enabled
DEBUG - 2011-08-30 00:50:22 --> URI Class Initialized
DEBUG - 2011-08-30 00:50:22 --> Router Class Initialized
DEBUG - 2011-08-30 00:50:22 --> Output Class Initialized
DEBUG - 2011-08-30 00:50:22 --> Input Class Initialized
DEBUG - 2011-08-30 00:50:22 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-30 00:50:22 --> Language Class Initialized
DEBUG - 2011-08-30 00:50:22 --> Loader Class Initialized
DEBUG - 2011-08-30 00:50:22 --> Controller Class Initialized
ERROR - 2011-08-30 00:50:22 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-08-30 00:50:22 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-08-30 00:50:22 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-08-30 00:50:22 --> Model Class Initialized
DEBUG - 2011-08-30 00:50:22 --> Model Class Initialized
DEBUG - 2011-08-30 00:50:22 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-30 00:50:22 --> Database Driver Class Initialized
DEBUG - 2011-08-30 00:50:22 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-08-30 00:50:22 --> Helper loaded: url_helper
DEBUG - 2011-08-30 00:50:22 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-30 00:50:22 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-30 00:50:22 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-30 00:50:22 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-30 00:50:22 --> Final output sent to browser
DEBUG - 2011-08-30 00:50:22 --> Total execution time: 0.0277
DEBUG - 2011-08-30 00:50:22 --> Config Class Initialized
DEBUG - 2011-08-30 00:50:22 --> Hooks Class Initialized
DEBUG - 2011-08-30 00:50:22 --> Utf8 Class Initialized
DEBUG - 2011-08-30 00:50:22 --> UTF-8 Support Enabled
DEBUG - 2011-08-30 00:50:22 --> URI Class Initialized
DEBUG - 2011-08-30 00:50:22 --> Router Class Initialized
DEBUG - 2011-08-30 00:50:22 --> Output Class Initialized
DEBUG - 2011-08-30 00:50:22 --> Input Class Initialized
DEBUG - 2011-08-30 00:50:22 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-30 00:50:22 --> Language Class Initialized
DEBUG - 2011-08-30 00:50:22 --> Loader Class Initialized
DEBUG - 2011-08-30 00:50:22 --> Controller Class Initialized
DEBUG - 2011-08-30 00:50:22 --> Model Class Initialized
DEBUG - 2011-08-30 00:50:22 --> Model Class Initialized
DEBUG - 2011-08-30 00:50:22 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-30 00:50:22 --> Database Driver Class Initialized
DEBUG - 2011-08-30 00:50:23 --> Final output sent to browser
DEBUG - 2011-08-30 00:50:23 --> Total execution time: 0.5106
DEBUG - 2011-08-30 00:50:24 --> Config Class Initialized
DEBUG - 2011-08-30 00:50:24 --> Hooks Class Initialized
DEBUG - 2011-08-30 00:50:24 --> Utf8 Class Initialized
DEBUG - 2011-08-30 00:50:24 --> UTF-8 Support Enabled
DEBUG - 2011-08-30 00:50:24 --> URI Class Initialized
DEBUG - 2011-08-30 00:50:24 --> Router Class Initialized
ERROR - 2011-08-30 00:50:24 --> 404 Page Not Found --> eyewonder
DEBUG - 2011-08-30 00:50:29 --> Config Class Initialized
DEBUG - 2011-08-30 00:50:29 --> Hooks Class Initialized
DEBUG - 2011-08-30 00:50:29 --> Utf8 Class Initialized
DEBUG - 2011-08-30 00:50:29 --> UTF-8 Support Enabled
DEBUG - 2011-08-30 00:50:29 --> URI Class Initialized
DEBUG - 2011-08-30 00:50:29 --> Router Class Initialized
DEBUG - 2011-08-30 00:50:29 --> Output Class Initialized
DEBUG - 2011-08-30 00:50:29 --> Input Class Initialized
DEBUG - 2011-08-30 00:50:29 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-30 00:50:29 --> Language Class Initialized
DEBUG - 2011-08-30 00:50:29 --> Loader Class Initialized
DEBUG - 2011-08-30 00:50:29 --> Controller Class Initialized
ERROR - 2011-08-30 00:50:29 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-08-30 00:50:29 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-08-30 00:50:29 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-08-30 00:50:29 --> Model Class Initialized
DEBUG - 2011-08-30 00:50:29 --> Model Class Initialized
DEBUG - 2011-08-30 00:50:29 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-30 00:50:29 --> Database Driver Class Initialized
DEBUG - 2011-08-30 00:50:29 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-08-30 00:50:29 --> Helper loaded: url_helper
DEBUG - 2011-08-30 00:50:29 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-30 00:50:29 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-30 00:50:29 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-30 00:50:29 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-30 00:50:29 --> Final output sent to browser
DEBUG - 2011-08-30 00:50:29 --> Total execution time: 0.0298
DEBUG - 2011-08-30 00:50:29 --> Config Class Initialized
DEBUG - 2011-08-30 00:50:29 --> Hooks Class Initialized
DEBUG - 2011-08-30 00:50:29 --> Utf8 Class Initialized
DEBUG - 2011-08-30 00:50:29 --> UTF-8 Support Enabled
DEBUG - 2011-08-30 00:50:29 --> URI Class Initialized
DEBUG - 2011-08-30 00:50:29 --> Router Class Initialized
DEBUG - 2011-08-30 00:50:29 --> Output Class Initialized
DEBUG - 2011-08-30 00:50:29 --> Input Class Initialized
DEBUG - 2011-08-30 00:50:29 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-30 00:50:29 --> Language Class Initialized
DEBUG - 2011-08-30 00:50:29 --> Loader Class Initialized
DEBUG - 2011-08-30 00:50:29 --> Controller Class Initialized
DEBUG - 2011-08-30 00:50:29 --> Model Class Initialized
DEBUG - 2011-08-30 00:50:29 --> Model Class Initialized
DEBUG - 2011-08-30 00:50:29 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-30 00:50:29 --> Database Driver Class Initialized
DEBUG - 2011-08-30 00:50:30 --> Final output sent to browser
DEBUG - 2011-08-30 00:50:30 --> Total execution time: 0.7308
DEBUG - 2011-08-30 00:50:45 --> Config Class Initialized
DEBUG - 2011-08-30 00:50:45 --> Hooks Class Initialized
DEBUG - 2011-08-30 00:50:45 --> Utf8 Class Initialized
DEBUG - 2011-08-30 00:50:45 --> UTF-8 Support Enabled
DEBUG - 2011-08-30 00:50:45 --> URI Class Initialized
DEBUG - 2011-08-30 00:50:45 --> Router Class Initialized
DEBUG - 2011-08-30 00:50:45 --> Output Class Initialized
DEBUG - 2011-08-30 00:50:45 --> Input Class Initialized
DEBUG - 2011-08-30 00:50:45 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-30 00:50:45 --> Language Class Initialized
DEBUG - 2011-08-30 00:50:45 --> Loader Class Initialized
DEBUG - 2011-08-30 00:50:45 --> Controller Class Initialized
ERROR - 2011-08-30 00:50:45 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-08-30 00:50:45 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-08-30 00:50:45 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-08-30 00:50:45 --> Model Class Initialized
DEBUG - 2011-08-30 00:50:45 --> Model Class Initialized
DEBUG - 2011-08-30 00:50:45 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-30 00:50:45 --> Database Driver Class Initialized
DEBUG - 2011-08-30 00:50:45 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-08-30 00:50:45 --> Helper loaded: url_helper
DEBUG - 2011-08-30 00:50:45 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-30 00:50:45 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-30 00:50:45 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-30 00:50:45 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-30 00:50:45 --> Final output sent to browser
DEBUG - 2011-08-30 00:50:45 --> Total execution time: 0.0286
DEBUG - 2011-08-30 00:50:45 --> Config Class Initialized
DEBUG - 2011-08-30 00:50:45 --> Hooks Class Initialized
DEBUG - 2011-08-30 00:50:45 --> Utf8 Class Initialized
DEBUG - 2011-08-30 00:50:45 --> UTF-8 Support Enabled
DEBUG - 2011-08-30 00:50:45 --> URI Class Initialized
DEBUG - 2011-08-30 00:50:45 --> Router Class Initialized
DEBUG - 2011-08-30 00:50:45 --> Output Class Initialized
DEBUG - 2011-08-30 00:50:45 --> Input Class Initialized
DEBUG - 2011-08-30 00:50:45 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-30 00:50:45 --> Language Class Initialized
DEBUG - 2011-08-30 00:50:45 --> Loader Class Initialized
DEBUG - 2011-08-30 00:50:45 --> Controller Class Initialized
DEBUG - 2011-08-30 00:50:45 --> Model Class Initialized
DEBUG - 2011-08-30 00:50:45 --> Model Class Initialized
DEBUG - 2011-08-30 00:50:45 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-30 00:50:45 --> Database Driver Class Initialized
DEBUG - 2011-08-30 00:50:45 --> Final output sent to browser
DEBUG - 2011-08-30 00:50:45 --> Total execution time: 0.5041
DEBUG - 2011-08-30 00:50:54 --> Config Class Initialized
DEBUG - 2011-08-30 00:50:54 --> Hooks Class Initialized
DEBUG - 2011-08-30 00:50:54 --> Utf8 Class Initialized
DEBUG - 2011-08-30 00:50:54 --> UTF-8 Support Enabled
DEBUG - 2011-08-30 00:50:54 --> URI Class Initialized
DEBUG - 2011-08-30 00:50:54 --> Router Class Initialized
DEBUG - 2011-08-30 00:50:54 --> Output Class Initialized
DEBUG - 2011-08-30 00:50:54 --> Input Class Initialized
DEBUG - 2011-08-30 00:50:54 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-30 00:50:54 --> Language Class Initialized
DEBUG - 2011-08-30 00:50:54 --> Loader Class Initialized
DEBUG - 2011-08-30 00:50:54 --> Controller Class Initialized
ERROR - 2011-08-30 00:50:54 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-08-30 00:50:54 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-08-30 00:50:54 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-08-30 00:50:54 --> Model Class Initialized
DEBUG - 2011-08-30 00:50:54 --> Model Class Initialized
DEBUG - 2011-08-30 00:50:54 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-30 00:50:54 --> Database Driver Class Initialized
DEBUG - 2011-08-30 00:50:54 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-08-30 00:50:54 --> Helper loaded: url_helper
DEBUG - 2011-08-30 00:50:54 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-30 00:50:54 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-30 00:50:54 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-30 00:50:54 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-30 00:50:54 --> Final output sent to browser
DEBUG - 2011-08-30 00:50:54 --> Total execution time: 0.0333
DEBUG - 2011-08-30 00:50:55 --> Config Class Initialized
DEBUG - 2011-08-30 00:50:55 --> Hooks Class Initialized
DEBUG - 2011-08-30 00:50:55 --> Utf8 Class Initialized
DEBUG - 2011-08-30 00:50:55 --> UTF-8 Support Enabled
DEBUG - 2011-08-30 00:50:55 --> URI Class Initialized
DEBUG - 2011-08-30 00:50:55 --> Router Class Initialized
DEBUG - 2011-08-30 00:50:55 --> Output Class Initialized
DEBUG - 2011-08-30 00:50:55 --> Input Class Initialized
DEBUG - 2011-08-30 00:50:55 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-30 00:50:55 --> Language Class Initialized
DEBUG - 2011-08-30 00:50:55 --> Loader Class Initialized
DEBUG - 2011-08-30 00:50:55 --> Controller Class Initialized
DEBUG - 2011-08-30 00:50:55 --> Model Class Initialized
DEBUG - 2011-08-30 00:50:55 --> Model Class Initialized
DEBUG - 2011-08-30 00:50:55 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-30 00:50:55 --> Database Driver Class Initialized
DEBUG - 2011-08-30 00:50:55 --> Final output sent to browser
DEBUG - 2011-08-30 00:50:55 --> Total execution time: 0.5393
DEBUG - 2011-08-30 00:50:56 --> Config Class Initialized
DEBUG - 2011-08-30 00:50:56 --> Hooks Class Initialized
DEBUG - 2011-08-30 00:50:56 --> Utf8 Class Initialized
DEBUG - 2011-08-30 00:50:56 --> UTF-8 Support Enabled
DEBUG - 2011-08-30 00:50:56 --> URI Class Initialized
DEBUG - 2011-08-30 00:50:56 --> Router Class Initialized
ERROR - 2011-08-30 00:50:56 --> 404 Page Not Found --> eyewonder
DEBUG - 2011-08-30 00:51:06 --> Config Class Initialized
DEBUG - 2011-08-30 00:51:06 --> Hooks Class Initialized
DEBUG - 2011-08-30 00:51:06 --> Utf8 Class Initialized
DEBUG - 2011-08-30 00:51:06 --> UTF-8 Support Enabled
DEBUG - 2011-08-30 00:51:06 --> URI Class Initialized
DEBUG - 2011-08-30 00:51:06 --> Router Class Initialized
DEBUG - 2011-08-30 00:51:06 --> Output Class Initialized
DEBUG - 2011-08-30 00:51:06 --> Input Class Initialized
DEBUG - 2011-08-30 00:51:06 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-30 00:51:06 --> Language Class Initialized
DEBUG - 2011-08-30 00:51:06 --> Loader Class Initialized
DEBUG - 2011-08-30 00:51:06 --> Controller Class Initialized
ERROR - 2011-08-30 00:51:06 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-08-30 00:51:06 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-08-30 00:51:06 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-08-30 00:51:06 --> Model Class Initialized
DEBUG - 2011-08-30 00:51:06 --> Model Class Initialized
DEBUG - 2011-08-30 00:51:06 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-30 00:51:06 --> Database Driver Class Initialized
DEBUG - 2011-08-30 00:51:06 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-08-30 00:51:06 --> Helper loaded: url_helper
DEBUG - 2011-08-30 00:51:06 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-30 00:51:06 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-30 00:51:06 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-30 00:51:06 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-30 00:51:06 --> Final output sent to browser
DEBUG - 2011-08-30 00:51:06 --> Total execution time: 0.0285
DEBUG - 2011-08-30 00:51:07 --> Config Class Initialized
DEBUG - 2011-08-30 00:51:07 --> Hooks Class Initialized
DEBUG - 2011-08-30 00:51:07 --> Utf8 Class Initialized
DEBUG - 2011-08-30 00:51:07 --> UTF-8 Support Enabled
DEBUG - 2011-08-30 00:51:07 --> URI Class Initialized
DEBUG - 2011-08-30 00:51:07 --> Router Class Initialized
DEBUG - 2011-08-30 00:51:07 --> Output Class Initialized
DEBUG - 2011-08-30 00:51:07 --> Input Class Initialized
DEBUG - 2011-08-30 00:51:07 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-30 00:51:07 --> Language Class Initialized
DEBUG - 2011-08-30 00:51:07 --> Loader Class Initialized
DEBUG - 2011-08-30 00:51:07 --> Controller Class Initialized
DEBUG - 2011-08-30 00:51:07 --> Model Class Initialized
DEBUG - 2011-08-30 00:51:07 --> Model Class Initialized
DEBUG - 2011-08-30 00:51:07 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-30 00:51:07 --> Database Driver Class Initialized
DEBUG - 2011-08-30 00:51:07 --> Final output sent to browser
DEBUG - 2011-08-30 00:51:07 --> Total execution time: 0.4810
DEBUG - 2011-08-30 01:11:16 --> Config Class Initialized
DEBUG - 2011-08-30 01:11:16 --> Hooks Class Initialized
DEBUG - 2011-08-30 01:11:16 --> Utf8 Class Initialized
DEBUG - 2011-08-30 01:11:16 --> UTF-8 Support Enabled
DEBUG - 2011-08-30 01:11:16 --> URI Class Initialized
DEBUG - 2011-08-30 01:11:16 --> Router Class Initialized
ERROR - 2011-08-30 01:11:16 --> 404 Page Not Found --> robots.txt
DEBUG - 2011-08-30 01:32:43 --> Config Class Initialized
DEBUG - 2011-08-30 01:32:43 --> Hooks Class Initialized
DEBUG - 2011-08-30 01:32:43 --> Utf8 Class Initialized
DEBUG - 2011-08-30 01:32:43 --> UTF-8 Support Enabled
DEBUG - 2011-08-30 01:32:43 --> URI Class Initialized
DEBUG - 2011-08-30 01:32:43 --> Router Class Initialized
DEBUG - 2011-08-30 01:32:43 --> Output Class Initialized
DEBUG - 2011-08-30 01:32:43 --> Input Class Initialized
DEBUG - 2011-08-30 01:32:43 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-30 01:32:43 --> Language Class Initialized
DEBUG - 2011-08-30 01:32:43 --> Loader Class Initialized
DEBUG - 2011-08-30 01:32:43 --> Controller Class Initialized
ERROR - 2011-08-30 01:32:43 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-08-30 01:32:43 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-08-30 01:32:43 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-08-30 01:32:43 --> Model Class Initialized
DEBUG - 2011-08-30 01:32:43 --> Model Class Initialized
DEBUG - 2011-08-30 01:32:43 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-30 01:32:43 --> Database Driver Class Initialized
DEBUG - 2011-08-30 01:32:43 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-08-30 01:32:43 --> Helper loaded: url_helper
DEBUG - 2011-08-30 01:32:43 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-30 01:32:43 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-30 01:32:43 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-30 01:32:43 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-30 01:32:43 --> Final output sent to browser
DEBUG - 2011-08-30 01:32:43 --> Total execution time: 0.1886
DEBUG - 2011-08-30 01:32:47 --> Config Class Initialized
DEBUG - 2011-08-30 01:32:47 --> Hooks Class Initialized
DEBUG - 2011-08-30 01:32:47 --> Utf8 Class Initialized
DEBUG - 2011-08-30 01:32:47 --> UTF-8 Support Enabled
DEBUG - 2011-08-30 01:32:47 --> URI Class Initialized
DEBUG - 2011-08-30 01:32:47 --> Router Class Initialized
DEBUG - 2011-08-30 01:32:47 --> Output Class Initialized
DEBUG - 2011-08-30 01:32:47 --> Input Class Initialized
DEBUG - 2011-08-30 01:32:47 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-30 01:32:47 --> Language Class Initialized
DEBUG - 2011-08-30 01:32:47 --> Loader Class Initialized
DEBUG - 2011-08-30 01:32:47 --> Controller Class Initialized
DEBUG - 2011-08-30 01:32:47 --> Model Class Initialized
DEBUG - 2011-08-30 01:32:47 --> Model Class Initialized
DEBUG - 2011-08-30 01:32:47 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-30 01:32:47 --> Database Driver Class Initialized
DEBUG - 2011-08-30 01:32:48 --> Final output sent to browser
DEBUG - 2011-08-30 01:32:48 --> Total execution time: 0.6125
DEBUG - 2011-08-30 01:44:11 --> Config Class Initialized
DEBUG - 2011-08-30 01:44:11 --> Hooks Class Initialized
DEBUG - 2011-08-30 01:44:11 --> Utf8 Class Initialized
DEBUG - 2011-08-30 01:44:11 --> UTF-8 Support Enabled
DEBUG - 2011-08-30 01:44:11 --> URI Class Initialized
DEBUG - 2011-08-30 01:44:11 --> Router Class Initialized
DEBUG - 2011-08-30 01:44:11 --> Output Class Initialized
DEBUG - 2011-08-30 01:44:11 --> Input Class Initialized
DEBUG - 2011-08-30 01:44:11 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-30 01:44:11 --> Language Class Initialized
DEBUG - 2011-08-30 01:44:11 --> Loader Class Initialized
DEBUG - 2011-08-30 01:44:11 --> Controller Class Initialized
ERROR - 2011-08-30 01:44:11 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-08-30 01:44:11 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-08-30 01:44:11 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-08-30 01:44:11 --> Model Class Initialized
DEBUG - 2011-08-30 01:44:11 --> Model Class Initialized
DEBUG - 2011-08-30 01:44:11 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-30 01:44:11 --> Database Driver Class Initialized
DEBUG - 2011-08-30 01:44:11 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-08-30 01:44:11 --> Helper loaded: url_helper
DEBUG - 2011-08-30 01:44:11 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-30 01:44:11 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-30 01:44:11 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-30 01:44:11 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-30 01:44:11 --> Final output sent to browser
DEBUG - 2011-08-30 01:44:11 --> Total execution time: 0.0662
DEBUG - 2011-08-30 01:44:12 --> Config Class Initialized
DEBUG - 2011-08-30 01:44:12 --> Hooks Class Initialized
DEBUG - 2011-08-30 01:44:12 --> Utf8 Class Initialized
DEBUG - 2011-08-30 01:44:12 --> UTF-8 Support Enabled
DEBUG - 2011-08-30 01:44:12 --> URI Class Initialized
DEBUG - 2011-08-30 01:44:12 --> Router Class Initialized
DEBUG - 2011-08-30 01:44:12 --> Output Class Initialized
DEBUG - 2011-08-30 01:44:12 --> Input Class Initialized
DEBUG - 2011-08-30 01:44:12 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-30 01:44:12 --> Language Class Initialized
DEBUG - 2011-08-30 01:44:12 --> Loader Class Initialized
DEBUG - 2011-08-30 01:44:12 --> Controller Class Initialized
DEBUG - 2011-08-30 01:44:12 --> Model Class Initialized
DEBUG - 2011-08-30 01:44:12 --> Model Class Initialized
DEBUG - 2011-08-30 01:44:12 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-30 01:44:12 --> Database Driver Class Initialized
DEBUG - 2011-08-30 01:44:13 --> Final output sent to browser
DEBUG - 2011-08-30 01:44:13 --> Total execution time: 0.4675
DEBUG - 2011-08-30 01:44:14 --> Config Class Initialized
DEBUG - 2011-08-30 01:44:14 --> Hooks Class Initialized
DEBUG - 2011-08-30 01:44:14 --> Utf8 Class Initialized
DEBUG - 2011-08-30 01:44:14 --> UTF-8 Support Enabled
DEBUG - 2011-08-30 01:44:14 --> URI Class Initialized
DEBUG - 2011-08-30 01:44:14 --> Router Class Initialized
ERROR - 2011-08-30 01:44:14 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-08-30 01:44:32 --> Config Class Initialized
DEBUG - 2011-08-30 01:44:32 --> Hooks Class Initialized
DEBUG - 2011-08-30 01:44:32 --> Utf8 Class Initialized
DEBUG - 2011-08-30 01:44:32 --> UTF-8 Support Enabled
DEBUG - 2011-08-30 01:44:32 --> URI Class Initialized
DEBUG - 2011-08-30 01:44:32 --> Router Class Initialized
DEBUG - 2011-08-30 01:44:32 --> Output Class Initialized
DEBUG - 2011-08-30 01:44:32 --> Input Class Initialized
DEBUG - 2011-08-30 01:44:32 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-30 01:44:32 --> Language Class Initialized
DEBUG - 2011-08-30 01:44:32 --> Loader Class Initialized
DEBUG - 2011-08-30 01:44:32 --> Controller Class Initialized
ERROR - 2011-08-30 01:44:32 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-08-30 01:44:32 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-08-30 01:44:32 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-08-30 01:44:32 --> Model Class Initialized
DEBUG - 2011-08-30 01:44:32 --> Model Class Initialized
DEBUG - 2011-08-30 01:44:32 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-30 01:44:32 --> Database Driver Class Initialized
DEBUG - 2011-08-30 01:44:32 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-08-30 01:44:32 --> Helper loaded: url_helper
DEBUG - 2011-08-30 01:44:32 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-30 01:44:32 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-30 01:44:32 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-30 01:44:32 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-30 01:44:32 --> Final output sent to browser
DEBUG - 2011-08-30 01:44:32 --> Total execution time: 0.0360
DEBUG - 2011-08-30 01:44:33 --> Config Class Initialized
DEBUG - 2011-08-30 01:44:33 --> Hooks Class Initialized
DEBUG - 2011-08-30 01:44:33 --> Utf8 Class Initialized
DEBUG - 2011-08-30 01:44:33 --> UTF-8 Support Enabled
DEBUG - 2011-08-30 01:44:33 --> URI Class Initialized
DEBUG - 2011-08-30 01:44:33 --> Router Class Initialized
DEBUG - 2011-08-30 01:44:33 --> Output Class Initialized
DEBUG - 2011-08-30 01:44:33 --> Input Class Initialized
DEBUG - 2011-08-30 01:44:33 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-30 01:44:33 --> Language Class Initialized
DEBUG - 2011-08-30 01:44:33 --> Loader Class Initialized
DEBUG - 2011-08-30 01:44:33 --> Controller Class Initialized
DEBUG - 2011-08-30 01:44:33 --> Model Class Initialized
DEBUG - 2011-08-30 01:44:33 --> Model Class Initialized
DEBUG - 2011-08-30 01:44:33 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-30 01:44:33 --> Database Driver Class Initialized
DEBUG - 2011-08-30 01:44:34 --> Final output sent to browser
DEBUG - 2011-08-30 01:44:34 --> Total execution time: 0.6693
DEBUG - 2011-08-30 01:44:34 --> Config Class Initialized
DEBUG - 2011-08-30 01:44:34 --> Hooks Class Initialized
DEBUG - 2011-08-30 01:44:34 --> Utf8 Class Initialized
DEBUG - 2011-08-30 01:44:34 --> UTF-8 Support Enabled
DEBUG - 2011-08-30 01:44:34 --> URI Class Initialized
DEBUG - 2011-08-30 01:44:34 --> Router Class Initialized
ERROR - 2011-08-30 01:44:34 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-08-30 01:44:35 --> Config Class Initialized
DEBUG - 2011-08-30 01:44:35 --> Hooks Class Initialized
DEBUG - 2011-08-30 01:44:35 --> Utf8 Class Initialized
DEBUG - 2011-08-30 01:44:35 --> UTF-8 Support Enabled
DEBUG - 2011-08-30 01:44:35 --> URI Class Initialized
DEBUG - 2011-08-30 01:44:35 --> Router Class Initialized
DEBUG - 2011-08-30 01:44:35 --> Output Class Initialized
DEBUG - 2011-08-30 01:44:35 --> Input Class Initialized
DEBUG - 2011-08-30 01:44:35 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-30 01:44:35 --> Language Class Initialized
DEBUG - 2011-08-30 01:44:35 --> Loader Class Initialized
DEBUG - 2011-08-30 01:44:35 --> Controller Class Initialized
ERROR - 2011-08-30 01:44:35 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-08-30 01:44:35 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-08-30 01:44:35 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-08-30 01:44:35 --> Model Class Initialized
DEBUG - 2011-08-30 01:44:35 --> Model Class Initialized
DEBUG - 2011-08-30 01:44:35 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-30 01:44:35 --> Database Driver Class Initialized
DEBUG - 2011-08-30 01:44:35 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-08-30 01:44:35 --> Helper loaded: url_helper
DEBUG - 2011-08-30 01:44:35 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-30 01:44:35 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-30 01:44:35 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-30 01:44:35 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-30 01:44:35 --> Final output sent to browser
DEBUG - 2011-08-30 01:44:35 --> Total execution time: 0.0287
DEBUG - 2011-08-30 01:44:51 --> Config Class Initialized
DEBUG - 2011-08-30 01:44:51 --> Hooks Class Initialized
DEBUG - 2011-08-30 01:44:51 --> Utf8 Class Initialized
DEBUG - 2011-08-30 01:44:51 --> UTF-8 Support Enabled
DEBUG - 2011-08-30 01:44:51 --> URI Class Initialized
DEBUG - 2011-08-30 01:44:51 --> Router Class Initialized
DEBUG - 2011-08-30 01:44:51 --> Output Class Initialized
DEBUG - 2011-08-30 01:44:51 --> Input Class Initialized
DEBUG - 2011-08-30 01:44:51 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-30 01:44:51 --> Language Class Initialized
DEBUG - 2011-08-30 01:44:51 --> Loader Class Initialized
DEBUG - 2011-08-30 01:44:51 --> Controller Class Initialized
ERROR - 2011-08-30 01:44:51 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-08-30 01:44:51 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-08-30 01:44:51 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-08-30 01:44:51 --> Model Class Initialized
DEBUG - 2011-08-30 01:44:51 --> Model Class Initialized
DEBUG - 2011-08-30 01:44:51 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-30 01:44:51 --> Database Driver Class Initialized
DEBUG - 2011-08-30 01:44:51 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-08-30 01:44:51 --> Helper loaded: url_helper
DEBUG - 2011-08-30 01:44:51 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-30 01:44:51 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-30 01:44:51 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-30 01:44:51 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-30 01:44:51 --> Final output sent to browser
DEBUG - 2011-08-30 01:44:51 --> Total execution time: 0.1188
DEBUG - 2011-08-30 01:44:52 --> Config Class Initialized
DEBUG - 2011-08-30 01:44:52 --> Hooks Class Initialized
DEBUG - 2011-08-30 01:44:52 --> Utf8 Class Initialized
DEBUG - 2011-08-30 01:44:52 --> UTF-8 Support Enabled
DEBUG - 2011-08-30 01:44:52 --> URI Class Initialized
DEBUG - 2011-08-30 01:44:52 --> Router Class Initialized
DEBUG - 2011-08-30 01:44:52 --> Output Class Initialized
DEBUG - 2011-08-30 01:44:52 --> Input Class Initialized
DEBUG - 2011-08-30 01:44:52 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-30 01:44:52 --> Language Class Initialized
DEBUG - 2011-08-30 01:44:52 --> Loader Class Initialized
DEBUG - 2011-08-30 01:44:52 --> Controller Class Initialized
DEBUG - 2011-08-30 01:44:52 --> Model Class Initialized
DEBUG - 2011-08-30 01:44:52 --> Model Class Initialized
DEBUG - 2011-08-30 01:44:52 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-30 01:44:52 --> Database Driver Class Initialized
DEBUG - 2011-08-30 01:44:52 --> Final output sent to browser
DEBUG - 2011-08-30 01:44:52 --> Total execution time: 0.6266
DEBUG - 2011-08-30 01:44:53 --> Config Class Initialized
DEBUG - 2011-08-30 01:44:53 --> Hooks Class Initialized
DEBUG - 2011-08-30 01:44:53 --> Utf8 Class Initialized
DEBUG - 2011-08-30 01:44:53 --> UTF-8 Support Enabled
DEBUG - 2011-08-30 01:44:53 --> URI Class Initialized
DEBUG - 2011-08-30 01:44:53 --> Router Class Initialized
DEBUG - 2011-08-30 01:44:53 --> Output Class Initialized
DEBUG - 2011-08-30 01:44:53 --> Input Class Initialized
DEBUG - 2011-08-30 01:44:53 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-30 01:44:53 --> Language Class Initialized
DEBUG - 2011-08-30 01:44:53 --> Loader Class Initialized
DEBUG - 2011-08-30 01:44:53 --> Controller Class Initialized
ERROR - 2011-08-30 01:44:53 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-08-30 01:44:53 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-08-30 01:44:53 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-08-30 01:44:53 --> Model Class Initialized
DEBUG - 2011-08-30 01:44:53 --> Model Class Initialized
DEBUG - 2011-08-30 01:44:53 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-30 01:44:53 --> Database Driver Class Initialized
DEBUG - 2011-08-30 01:44:53 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-08-30 01:44:53 --> Helper loaded: url_helper
DEBUG - 2011-08-30 01:44:53 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-30 01:44:53 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-30 01:44:53 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-30 01:44:53 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-30 01:44:53 --> Final output sent to browser
DEBUG - 2011-08-30 01:44:53 --> Total execution time: 0.1563
DEBUG - 2011-08-30 01:44:54 --> Config Class Initialized
DEBUG - 2011-08-30 01:44:54 --> Hooks Class Initialized
DEBUG - 2011-08-30 01:44:54 --> Utf8 Class Initialized
DEBUG - 2011-08-30 01:44:54 --> UTF-8 Support Enabled
DEBUG - 2011-08-30 01:44:54 --> URI Class Initialized
DEBUG - 2011-08-30 01:44:54 --> Router Class Initialized
ERROR - 2011-08-30 01:44:54 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-08-30 02:01:38 --> Config Class Initialized
DEBUG - 2011-08-30 02:01:38 --> Hooks Class Initialized
DEBUG - 2011-08-30 02:01:38 --> Utf8 Class Initialized
DEBUG - 2011-08-30 02:01:38 --> UTF-8 Support Enabled
DEBUG - 2011-08-30 02:01:38 --> URI Class Initialized
DEBUG - 2011-08-30 02:01:38 --> Router Class Initialized
DEBUG - 2011-08-30 02:01:38 --> Output Class Initialized
DEBUG - 2011-08-30 02:01:38 --> Input Class Initialized
DEBUG - 2011-08-30 02:01:38 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-30 02:01:38 --> Language Class Initialized
DEBUG - 2011-08-30 02:01:38 --> Loader Class Initialized
DEBUG - 2011-08-30 02:01:38 --> Controller Class Initialized
ERROR - 2011-08-30 02:01:38 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-08-30 02:01:38 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-08-30 02:01:38 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-08-30 02:01:38 --> Model Class Initialized
DEBUG - 2011-08-30 02:01:38 --> Model Class Initialized
DEBUG - 2011-08-30 02:01:38 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-30 02:01:38 --> Database Driver Class Initialized
DEBUG - 2011-08-30 02:01:38 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-08-30 02:01:38 --> Helper loaded: url_helper
DEBUG - 2011-08-30 02:01:38 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-30 02:01:38 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-30 02:01:38 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-30 02:01:38 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-30 02:01:38 --> Final output sent to browser
DEBUG - 2011-08-30 02:01:38 --> Total execution time: 0.0478
DEBUG - 2011-08-30 02:01:39 --> Config Class Initialized
DEBUG - 2011-08-30 02:01:39 --> Hooks Class Initialized
DEBUG - 2011-08-30 02:01:39 --> Utf8 Class Initialized
DEBUG - 2011-08-30 02:01:39 --> UTF-8 Support Enabled
DEBUG - 2011-08-30 02:01:39 --> URI Class Initialized
DEBUG - 2011-08-30 02:01:39 --> Router Class Initialized
DEBUG - 2011-08-30 02:01:39 --> Output Class Initialized
DEBUG - 2011-08-30 02:01:39 --> Input Class Initialized
DEBUG - 2011-08-30 02:01:39 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-30 02:01:39 --> Language Class Initialized
DEBUG - 2011-08-30 02:01:39 --> Loader Class Initialized
DEBUG - 2011-08-30 02:01:39 --> Controller Class Initialized
DEBUG - 2011-08-30 02:01:39 --> Model Class Initialized
DEBUG - 2011-08-30 02:01:39 --> Model Class Initialized
DEBUG - 2011-08-30 02:01:39 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-30 02:01:39 --> Database Driver Class Initialized
DEBUG - 2011-08-30 02:01:40 --> Final output sent to browser
DEBUG - 2011-08-30 02:01:40 --> Total execution time: 0.7688
DEBUG - 2011-08-30 02:01:41 --> Config Class Initialized
DEBUG - 2011-08-30 02:01:41 --> Hooks Class Initialized
DEBUG - 2011-08-30 02:01:41 --> Utf8 Class Initialized
DEBUG - 2011-08-30 02:01:41 --> UTF-8 Support Enabled
DEBUG - 2011-08-30 02:01:41 --> URI Class Initialized
DEBUG - 2011-08-30 02:01:41 --> Router Class Initialized
ERROR - 2011-08-30 02:01:41 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-08-30 02:01:41 --> Config Class Initialized
DEBUG - 2011-08-30 02:01:41 --> Hooks Class Initialized
DEBUG - 2011-08-30 02:01:41 --> Utf8 Class Initialized
DEBUG - 2011-08-30 02:01:41 --> UTF-8 Support Enabled
DEBUG - 2011-08-30 02:01:41 --> URI Class Initialized
DEBUG - 2011-08-30 02:01:41 --> Router Class Initialized
ERROR - 2011-08-30 02:01:41 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-08-30 02:01:59 --> Config Class Initialized
DEBUG - 2011-08-30 02:01:59 --> Hooks Class Initialized
DEBUG - 2011-08-30 02:01:59 --> Utf8 Class Initialized
DEBUG - 2011-08-30 02:01:59 --> UTF-8 Support Enabled
DEBUG - 2011-08-30 02:01:59 --> URI Class Initialized
DEBUG - 2011-08-30 02:01:59 --> Router Class Initialized
DEBUG - 2011-08-30 02:01:59 --> Output Class Initialized
DEBUG - 2011-08-30 02:01:59 --> Input Class Initialized
DEBUG - 2011-08-30 02:01:59 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-30 02:01:59 --> Language Class Initialized
DEBUG - 2011-08-30 02:01:59 --> Loader Class Initialized
DEBUG - 2011-08-30 02:01:59 --> Controller Class Initialized
ERROR - 2011-08-30 02:01:59 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-08-30 02:01:59 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-08-30 02:01:59 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-08-30 02:01:59 --> Model Class Initialized
DEBUG - 2011-08-30 02:01:59 --> Model Class Initialized
DEBUG - 2011-08-30 02:01:59 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-30 02:01:59 --> Database Driver Class Initialized
DEBUG - 2011-08-30 02:01:59 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-08-30 02:01:59 --> Helper loaded: url_helper
DEBUG - 2011-08-30 02:01:59 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-30 02:01:59 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-30 02:01:59 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-30 02:01:59 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-30 02:01:59 --> Final output sent to browser
DEBUG - 2011-08-30 02:01:59 --> Total execution time: 0.0446
DEBUG - 2011-08-30 02:02:00 --> Config Class Initialized
DEBUG - 2011-08-30 02:02:00 --> Hooks Class Initialized
DEBUG - 2011-08-30 02:02:00 --> Utf8 Class Initialized
DEBUG - 2011-08-30 02:02:00 --> UTF-8 Support Enabled
DEBUG - 2011-08-30 02:02:00 --> URI Class Initialized
DEBUG - 2011-08-30 02:02:00 --> Router Class Initialized
DEBUG - 2011-08-30 02:02:00 --> Output Class Initialized
DEBUG - 2011-08-30 02:02:00 --> Input Class Initialized
DEBUG - 2011-08-30 02:02:00 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-30 02:02:00 --> Language Class Initialized
DEBUG - 2011-08-30 02:02:00 --> Loader Class Initialized
DEBUG - 2011-08-30 02:02:00 --> Controller Class Initialized
DEBUG - 2011-08-30 02:02:00 --> Model Class Initialized
DEBUG - 2011-08-30 02:02:00 --> Model Class Initialized
DEBUG - 2011-08-30 02:02:00 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-30 02:02:00 --> Database Driver Class Initialized
DEBUG - 2011-08-30 02:02:01 --> Final output sent to browser
DEBUG - 2011-08-30 02:02:01 --> Total execution time: 0.6897
DEBUG - 2011-08-30 02:02:34 --> Config Class Initialized
DEBUG - 2011-08-30 02:02:34 --> Hooks Class Initialized
DEBUG - 2011-08-30 02:02:34 --> Utf8 Class Initialized
DEBUG - 2011-08-30 02:02:34 --> UTF-8 Support Enabled
DEBUG - 2011-08-30 02:02:34 --> URI Class Initialized
DEBUG - 2011-08-30 02:02:34 --> Router Class Initialized
DEBUG - 2011-08-30 02:02:34 --> Output Class Initialized
DEBUG - 2011-08-30 02:02:34 --> Input Class Initialized
DEBUG - 2011-08-30 02:02:34 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-30 02:02:34 --> Language Class Initialized
DEBUG - 2011-08-30 02:02:34 --> Loader Class Initialized
DEBUG - 2011-08-30 02:02:34 --> Controller Class Initialized
ERROR - 2011-08-30 02:02:34 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-08-30 02:02:34 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-08-30 02:02:34 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-08-30 02:02:34 --> Model Class Initialized
DEBUG - 2011-08-30 02:02:34 --> Model Class Initialized
DEBUG - 2011-08-30 02:02:34 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-30 02:02:34 --> Database Driver Class Initialized
DEBUG - 2011-08-30 02:02:34 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-08-30 02:02:34 --> Helper loaded: url_helper
DEBUG - 2011-08-30 02:02:34 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-30 02:02:34 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-30 02:02:34 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-30 02:02:34 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-30 02:02:34 --> Final output sent to browser
DEBUG - 2011-08-30 02:02:34 --> Total execution time: 0.1074
DEBUG - 2011-08-30 02:02:36 --> Config Class Initialized
DEBUG - 2011-08-30 02:02:36 --> Hooks Class Initialized
DEBUG - 2011-08-30 02:02:36 --> Utf8 Class Initialized
DEBUG - 2011-08-30 02:02:36 --> UTF-8 Support Enabled
DEBUG - 2011-08-30 02:02:36 --> URI Class Initialized
DEBUG - 2011-08-30 02:02:36 --> Router Class Initialized
DEBUG - 2011-08-30 02:02:36 --> Output Class Initialized
DEBUG - 2011-08-30 02:02:36 --> Input Class Initialized
DEBUG - 2011-08-30 02:02:36 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-30 02:02:36 --> Language Class Initialized
DEBUG - 2011-08-30 02:02:36 --> Loader Class Initialized
DEBUG - 2011-08-30 02:02:36 --> Controller Class Initialized
DEBUG - 2011-08-30 02:02:36 --> Model Class Initialized
DEBUG - 2011-08-30 02:02:36 --> Model Class Initialized
DEBUG - 2011-08-30 02:02:36 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-30 02:02:36 --> Database Driver Class Initialized
DEBUG - 2011-08-30 02:02:37 --> Final output sent to browser
DEBUG - 2011-08-30 02:02:37 --> Total execution time: 1.4743
DEBUG - 2011-08-30 02:02:46 --> Config Class Initialized
DEBUG - 2011-08-30 02:02:46 --> Hooks Class Initialized
DEBUG - 2011-08-30 02:02:46 --> Utf8 Class Initialized
DEBUG - 2011-08-30 02:02:46 --> UTF-8 Support Enabled
DEBUG - 2011-08-30 02:02:46 --> URI Class Initialized
DEBUG - 2011-08-30 02:02:46 --> Router Class Initialized
DEBUG - 2011-08-30 02:02:46 --> Output Class Initialized
DEBUG - 2011-08-30 02:02:46 --> Input Class Initialized
DEBUG - 2011-08-30 02:02:46 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-30 02:02:46 --> Language Class Initialized
DEBUG - 2011-08-30 02:02:46 --> Loader Class Initialized
DEBUG - 2011-08-30 02:02:46 --> Controller Class Initialized
ERROR - 2011-08-30 02:02:46 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-08-30 02:02:46 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-08-30 02:02:46 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-08-30 02:02:46 --> Model Class Initialized
DEBUG - 2011-08-30 02:02:46 --> Model Class Initialized
DEBUG - 2011-08-30 02:02:46 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-30 02:02:46 --> Database Driver Class Initialized
DEBUG - 2011-08-30 02:02:46 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-08-30 02:02:46 --> Helper loaded: url_helper
DEBUG - 2011-08-30 02:02:46 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-30 02:02:46 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-30 02:02:46 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-30 02:02:46 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-30 02:02:46 --> Final output sent to browser
DEBUG - 2011-08-30 02:02:46 --> Total execution time: 0.0585
DEBUG - 2011-08-30 02:02:46 --> Config Class Initialized
DEBUG - 2011-08-30 02:02:46 --> Hooks Class Initialized
DEBUG - 2011-08-30 02:02:46 --> Utf8 Class Initialized
DEBUG - 2011-08-30 02:02:46 --> UTF-8 Support Enabled
DEBUG - 2011-08-30 02:02:46 --> URI Class Initialized
DEBUG - 2011-08-30 02:02:46 --> Router Class Initialized
DEBUG - 2011-08-30 02:02:46 --> Output Class Initialized
DEBUG - 2011-08-30 02:02:46 --> Input Class Initialized
DEBUG - 2011-08-30 02:02:46 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-30 02:02:46 --> Language Class Initialized
DEBUG - 2011-08-30 02:02:46 --> Loader Class Initialized
DEBUG - 2011-08-30 02:02:46 --> Controller Class Initialized
DEBUG - 2011-08-30 02:02:46 --> Model Class Initialized
DEBUG - 2011-08-30 02:02:46 --> Model Class Initialized
DEBUG - 2011-08-30 02:02:46 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-30 02:02:46 --> Database Driver Class Initialized
DEBUG - 2011-08-30 02:02:47 --> Final output sent to browser
DEBUG - 2011-08-30 02:02:47 --> Total execution time: 1.2673
DEBUG - 2011-08-30 02:02:48 --> Config Class Initialized
DEBUG - 2011-08-30 02:02:48 --> Hooks Class Initialized
DEBUG - 2011-08-30 02:02:48 --> Utf8 Class Initialized
DEBUG - 2011-08-30 02:02:48 --> UTF-8 Support Enabled
DEBUG - 2011-08-30 02:02:48 --> URI Class Initialized
DEBUG - 2011-08-30 02:02:48 --> Router Class Initialized
DEBUG - 2011-08-30 02:02:48 --> Output Class Initialized
DEBUG - 2011-08-30 02:02:48 --> Input Class Initialized
DEBUG - 2011-08-30 02:02:48 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-30 02:02:48 --> Language Class Initialized
DEBUG - 2011-08-30 02:02:48 --> Loader Class Initialized
DEBUG - 2011-08-30 02:02:48 --> Controller Class Initialized
ERROR - 2011-08-30 02:02:48 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-08-30 02:02:48 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-08-30 02:02:48 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-08-30 02:02:48 --> Model Class Initialized
DEBUG - 2011-08-30 02:02:48 --> Model Class Initialized
DEBUG - 2011-08-30 02:02:48 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-30 02:02:48 --> Database Driver Class Initialized
DEBUG - 2011-08-30 02:02:48 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-08-30 02:02:48 --> Helper loaded: url_helper
DEBUG - 2011-08-30 02:02:48 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-30 02:02:48 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-30 02:02:48 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-30 02:02:48 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-30 02:02:48 --> Final output sent to browser
DEBUG - 2011-08-30 02:02:48 --> Total execution time: 0.0286
DEBUG - 2011-08-30 02:06:31 --> Config Class Initialized
DEBUG - 2011-08-30 02:06:31 --> Hooks Class Initialized
DEBUG - 2011-08-30 02:06:31 --> Utf8 Class Initialized
DEBUG - 2011-08-30 02:06:31 --> UTF-8 Support Enabled
DEBUG - 2011-08-30 02:06:31 --> URI Class Initialized
DEBUG - 2011-08-30 02:06:31 --> Router Class Initialized
DEBUG - 2011-08-30 02:06:31 --> Output Class Initialized
DEBUG - 2011-08-30 02:06:31 --> Input Class Initialized
DEBUG - 2011-08-30 02:06:31 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-30 02:06:31 --> Language Class Initialized
DEBUG - 2011-08-30 02:06:31 --> Loader Class Initialized
DEBUG - 2011-08-30 02:06:31 --> Controller Class Initialized
DEBUG - 2011-08-30 02:06:31 --> Model Class Initialized
DEBUG - 2011-08-30 02:06:31 --> Model Class Initialized
DEBUG - 2011-08-30 02:06:31 --> Model Class Initialized
DEBUG - 2011-08-30 02:06:31 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-30 02:06:31 --> Database Driver Class Initialized
DEBUG - 2011-08-30 02:06:33 --> File loaded: application/views/table/main.php
DEBUG - 2011-08-30 02:06:33 --> Helper loaded: url_helper
DEBUG - 2011-08-30 02:06:33 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-30 02:06:33 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-30 02:06:33 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-30 02:06:33 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-30 02:06:33 --> Final output sent to browser
DEBUG - 2011-08-30 02:06:33 --> Total execution time: 1.6081
DEBUG - 2011-08-30 02:09:49 --> Config Class Initialized
DEBUG - 2011-08-30 02:09:49 --> Hooks Class Initialized
DEBUG - 2011-08-30 02:09:49 --> Utf8 Class Initialized
DEBUG - 2011-08-30 02:09:49 --> UTF-8 Support Enabled
DEBUG - 2011-08-30 02:09:49 --> URI Class Initialized
DEBUG - 2011-08-30 02:09:49 --> Router Class Initialized
DEBUG - 2011-08-30 02:09:49 --> Output Class Initialized
DEBUG - 2011-08-30 02:09:49 --> Input Class Initialized
DEBUG - 2011-08-30 02:09:49 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-30 02:09:49 --> Language Class Initialized
DEBUG - 2011-08-30 02:09:49 --> Loader Class Initialized
DEBUG - 2011-08-30 02:09:49 --> Controller Class Initialized
ERROR - 2011-08-30 02:09:49 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-08-30 02:09:49 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-08-30 02:09:49 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-08-30 02:09:49 --> Model Class Initialized
DEBUG - 2011-08-30 02:09:49 --> Model Class Initialized
DEBUG - 2011-08-30 02:09:49 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-30 02:09:49 --> Database Driver Class Initialized
DEBUG - 2011-08-30 02:09:49 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-08-30 02:09:49 --> Helper loaded: url_helper
DEBUG - 2011-08-30 02:09:49 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-30 02:09:49 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-30 02:09:49 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-30 02:09:49 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-30 02:09:49 --> Final output sent to browser
DEBUG - 2011-08-30 02:09:49 --> Total execution time: 0.0308
DEBUG - 2011-08-30 02:09:50 --> Config Class Initialized
DEBUG - 2011-08-30 02:09:50 --> Hooks Class Initialized
DEBUG - 2011-08-30 02:09:50 --> Utf8 Class Initialized
DEBUG - 2011-08-30 02:09:50 --> UTF-8 Support Enabled
DEBUG - 2011-08-30 02:09:50 --> URI Class Initialized
DEBUG - 2011-08-30 02:09:50 --> Router Class Initialized
DEBUG - 2011-08-30 02:09:50 --> Output Class Initialized
DEBUG - 2011-08-30 02:09:50 --> Input Class Initialized
DEBUG - 2011-08-30 02:09:50 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-30 02:09:50 --> Language Class Initialized
DEBUG - 2011-08-30 02:09:50 --> Loader Class Initialized
DEBUG - 2011-08-30 02:09:50 --> Controller Class Initialized
DEBUG - 2011-08-30 02:09:50 --> Model Class Initialized
DEBUG - 2011-08-30 02:09:50 --> Model Class Initialized
DEBUG - 2011-08-30 02:09:50 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-30 02:09:50 --> Database Driver Class Initialized
DEBUG - 2011-08-30 02:09:51 --> Final output sent to browser
DEBUG - 2011-08-30 02:09:51 --> Total execution time: 0.5317
DEBUG - 2011-08-30 02:09:51 --> Config Class Initialized
DEBUG - 2011-08-30 02:09:51 --> Hooks Class Initialized
DEBUG - 2011-08-30 02:09:51 --> Utf8 Class Initialized
DEBUG - 2011-08-30 02:09:51 --> UTF-8 Support Enabled
DEBUG - 2011-08-30 02:09:51 --> URI Class Initialized
DEBUG - 2011-08-30 02:09:51 --> Router Class Initialized
ERROR - 2011-08-30 02:09:51 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-08-30 02:10:35 --> Config Class Initialized
DEBUG - 2011-08-30 02:10:35 --> Hooks Class Initialized
DEBUG - 2011-08-30 02:10:35 --> Utf8 Class Initialized
DEBUG - 2011-08-30 02:10:35 --> UTF-8 Support Enabled
DEBUG - 2011-08-30 02:10:35 --> URI Class Initialized
DEBUG - 2011-08-30 02:10:35 --> Router Class Initialized
DEBUG - 2011-08-30 02:10:35 --> Output Class Initialized
DEBUG - 2011-08-30 02:10:35 --> Input Class Initialized
DEBUG - 2011-08-30 02:10:35 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-30 02:10:35 --> Language Class Initialized
DEBUG - 2011-08-30 02:10:35 --> Loader Class Initialized
DEBUG - 2011-08-30 02:10:35 --> Controller Class Initialized
ERROR - 2011-08-30 02:10:35 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-08-30 02:10:35 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-08-30 02:10:35 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-08-30 02:10:35 --> Model Class Initialized
DEBUG - 2011-08-30 02:10:35 --> Model Class Initialized
DEBUG - 2011-08-30 02:10:35 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-30 02:10:35 --> Database Driver Class Initialized
DEBUG - 2011-08-30 02:10:35 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-08-30 02:10:35 --> Helper loaded: url_helper
DEBUG - 2011-08-30 02:10:35 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-30 02:10:35 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-30 02:10:35 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-30 02:10:35 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-30 02:10:35 --> Final output sent to browser
DEBUG - 2011-08-30 02:10:35 --> Total execution time: 0.0316
DEBUG - 2011-08-30 02:10:36 --> Config Class Initialized
DEBUG - 2011-08-30 02:10:36 --> Hooks Class Initialized
DEBUG - 2011-08-30 02:10:36 --> Utf8 Class Initialized
DEBUG - 2011-08-30 02:10:36 --> UTF-8 Support Enabled
DEBUG - 2011-08-30 02:10:36 --> URI Class Initialized
DEBUG - 2011-08-30 02:10:36 --> Router Class Initialized
DEBUG - 2011-08-30 02:10:36 --> Output Class Initialized
DEBUG - 2011-08-30 02:10:36 --> Input Class Initialized
DEBUG - 2011-08-30 02:10:36 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-30 02:10:36 --> Language Class Initialized
DEBUG - 2011-08-30 02:10:36 --> Loader Class Initialized
DEBUG - 2011-08-30 02:10:36 --> Controller Class Initialized
DEBUG - 2011-08-30 02:10:36 --> Model Class Initialized
DEBUG - 2011-08-30 02:10:36 --> Model Class Initialized
DEBUG - 2011-08-30 02:10:36 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-30 02:10:36 --> Database Driver Class Initialized
DEBUG - 2011-08-30 02:10:36 --> Final output sent to browser
DEBUG - 2011-08-30 02:10:36 --> Total execution time: 0.6959
DEBUG - 2011-08-30 02:10:37 --> Config Class Initialized
DEBUG - 2011-08-30 02:10:37 --> Hooks Class Initialized
DEBUG - 2011-08-30 02:10:37 --> Utf8 Class Initialized
DEBUG - 2011-08-30 02:10:37 --> UTF-8 Support Enabled
DEBUG - 2011-08-30 02:10:37 --> URI Class Initialized
DEBUG - 2011-08-30 02:10:37 --> Router Class Initialized
ERROR - 2011-08-30 02:10:37 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-08-30 02:10:46 --> Config Class Initialized
DEBUG - 2011-08-30 02:10:46 --> Hooks Class Initialized
DEBUG - 2011-08-30 02:10:46 --> Utf8 Class Initialized
DEBUG - 2011-08-30 02:10:46 --> UTF-8 Support Enabled
DEBUG - 2011-08-30 02:10:46 --> URI Class Initialized
DEBUG - 2011-08-30 02:10:46 --> Router Class Initialized
ERROR - 2011-08-30 02:10:46 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-08-30 02:17:11 --> Config Class Initialized
DEBUG - 2011-08-30 02:17:11 --> Hooks Class Initialized
DEBUG - 2011-08-30 02:17:11 --> Utf8 Class Initialized
DEBUG - 2011-08-30 02:17:11 --> UTF-8 Support Enabled
DEBUG - 2011-08-30 02:17:11 --> URI Class Initialized
DEBUG - 2011-08-30 02:17:11 --> Router Class Initialized
DEBUG - 2011-08-30 02:17:11 --> Output Class Initialized
DEBUG - 2011-08-30 02:17:11 --> Input Class Initialized
DEBUG - 2011-08-30 02:17:11 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-30 02:17:11 --> Language Class Initialized
DEBUG - 2011-08-30 02:17:11 --> Loader Class Initialized
DEBUG - 2011-08-30 02:17:11 --> Controller Class Initialized
DEBUG - 2011-08-30 02:17:11 --> Model Class Initialized
DEBUG - 2011-08-30 02:17:11 --> Model Class Initialized
DEBUG - 2011-08-30 02:17:11 --> Model Class Initialized
DEBUG - 2011-08-30 02:17:11 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-30 02:17:11 --> Database Driver Class Initialized
DEBUG - 2011-08-30 02:17:11 --> File loaded: application/views/table/main.php
DEBUG - 2011-08-30 02:17:11 --> Helper loaded: url_helper
DEBUG - 2011-08-30 02:17:11 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-30 02:17:11 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-30 02:17:11 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-30 02:17:11 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-30 02:17:11 --> Final output sent to browser
DEBUG - 2011-08-30 02:17:11 --> Total execution time: 0.0653
DEBUG - 2011-08-30 02:17:24 --> Config Class Initialized
DEBUG - 2011-08-30 02:17:24 --> Hooks Class Initialized
DEBUG - 2011-08-30 02:17:24 --> Utf8 Class Initialized
DEBUG - 2011-08-30 02:17:24 --> UTF-8 Support Enabled
DEBUG - 2011-08-30 02:17:24 --> URI Class Initialized
DEBUG - 2011-08-30 02:17:24 --> Router Class Initialized
ERROR - 2011-08-30 02:17:24 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-08-30 02:17:33 --> Config Class Initialized
DEBUG - 2011-08-30 02:17:33 --> Hooks Class Initialized
DEBUG - 2011-08-30 02:17:33 --> Utf8 Class Initialized
DEBUG - 2011-08-30 02:17:33 --> UTF-8 Support Enabled
DEBUG - 2011-08-30 02:17:33 --> URI Class Initialized
DEBUG - 2011-08-30 02:17:33 --> Router Class Initialized
DEBUG - 2011-08-30 02:17:33 --> Output Class Initialized
DEBUG - 2011-08-30 02:17:33 --> Input Class Initialized
DEBUG - 2011-08-30 02:17:33 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-30 02:17:33 --> Language Class Initialized
DEBUG - 2011-08-30 02:17:33 --> Loader Class Initialized
DEBUG - 2011-08-30 02:17:33 --> Controller Class Initialized
DEBUG - 2011-08-30 02:17:33 --> Model Class Initialized
DEBUG - 2011-08-30 02:17:33 --> Model Class Initialized
DEBUG - 2011-08-30 02:17:33 --> Model Class Initialized
DEBUG - 2011-08-30 02:17:33 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-30 02:17:33 --> Database Driver Class Initialized
DEBUG - 2011-08-30 02:17:34 --> File loaded: application/views/table/main.php
DEBUG - 2011-08-30 02:17:34 --> Helper loaded: url_helper
DEBUG - 2011-08-30 02:17:34 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-30 02:17:34 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-30 02:17:34 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-30 02:17:34 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-30 02:17:34 --> Final output sent to browser
DEBUG - 2011-08-30 02:17:34 --> Total execution time: 1.1698
DEBUG - 2011-08-30 02:17:36 --> Config Class Initialized
DEBUG - 2011-08-30 02:17:36 --> Hooks Class Initialized
DEBUG - 2011-08-30 02:17:36 --> Utf8 Class Initialized
DEBUG - 2011-08-30 02:17:36 --> UTF-8 Support Enabled
DEBUG - 2011-08-30 02:17:36 --> URI Class Initialized
DEBUG - 2011-08-30 02:17:36 --> Router Class Initialized
DEBUG - 2011-08-30 02:17:36 --> Output Class Initialized
DEBUG - 2011-08-30 02:17:36 --> Input Class Initialized
DEBUG - 2011-08-30 02:17:36 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-30 02:17:36 --> Language Class Initialized
DEBUG - 2011-08-30 02:17:36 --> Loader Class Initialized
DEBUG - 2011-08-30 02:17:36 --> Controller Class Initialized
DEBUG - 2011-08-30 02:17:36 --> Model Class Initialized
DEBUG - 2011-08-30 02:17:36 --> Model Class Initialized
DEBUG - 2011-08-30 02:17:36 --> Model Class Initialized
DEBUG - 2011-08-30 02:17:36 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-30 02:17:36 --> Database Driver Class Initialized
DEBUG - 2011-08-30 02:17:36 --> File loaded: application/views/table/main.php
DEBUG - 2011-08-30 02:17:36 --> Helper loaded: url_helper
DEBUG - 2011-08-30 02:17:36 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-30 02:17:36 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-30 02:17:36 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-30 02:17:36 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-30 02:17:36 --> Final output sent to browser
DEBUG - 2011-08-30 02:17:36 --> Total execution time: 0.0797
DEBUG - 2011-08-30 02:17:37 --> Config Class Initialized
DEBUG - 2011-08-30 02:17:37 --> Hooks Class Initialized
DEBUG - 2011-08-30 02:17:37 --> Utf8 Class Initialized
DEBUG - 2011-08-30 02:17:37 --> UTF-8 Support Enabled
DEBUG - 2011-08-30 02:17:37 --> URI Class Initialized
DEBUG - 2011-08-30 02:17:37 --> Router Class Initialized
ERROR - 2011-08-30 02:17:37 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-08-30 02:17:57 --> Config Class Initialized
DEBUG - 2011-08-30 02:17:57 --> Hooks Class Initialized
DEBUG - 2011-08-30 02:17:57 --> Utf8 Class Initialized
DEBUG - 2011-08-30 02:17:57 --> UTF-8 Support Enabled
DEBUG - 2011-08-30 02:17:57 --> URI Class Initialized
DEBUG - 2011-08-30 02:17:57 --> Router Class Initialized
DEBUG - 2011-08-30 02:17:57 --> Output Class Initialized
DEBUG - 2011-08-30 02:17:57 --> Input Class Initialized
DEBUG - 2011-08-30 02:17:57 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-30 02:17:57 --> Language Class Initialized
DEBUG - 2011-08-30 02:17:57 --> Loader Class Initialized
DEBUG - 2011-08-30 02:17:57 --> Controller Class Initialized
DEBUG - 2011-08-30 02:17:57 --> Model Class Initialized
DEBUG - 2011-08-30 02:17:57 --> Model Class Initialized
DEBUG - 2011-08-30 02:17:57 --> Model Class Initialized
DEBUG - 2011-08-30 02:17:57 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-30 02:17:57 --> Database Driver Class Initialized
DEBUG - 2011-08-30 02:17:58 --> File loaded: application/views/table/main.php
DEBUG - 2011-08-30 02:17:58 --> Helper loaded: url_helper
DEBUG - 2011-08-30 02:17:58 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-30 02:17:58 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-30 02:17:58 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-30 02:17:58 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-30 02:17:58 --> Final output sent to browser
DEBUG - 2011-08-30 02:17:58 --> Total execution time: 0.4456
DEBUG - 2011-08-30 02:18:00 --> Config Class Initialized
DEBUG - 2011-08-30 02:18:00 --> Hooks Class Initialized
DEBUG - 2011-08-30 02:18:00 --> Utf8 Class Initialized
DEBUG - 2011-08-30 02:18:00 --> UTF-8 Support Enabled
DEBUG - 2011-08-30 02:18:00 --> URI Class Initialized
DEBUG - 2011-08-30 02:18:00 --> Router Class Initialized
DEBUG - 2011-08-30 02:18:00 --> Output Class Initialized
DEBUG - 2011-08-30 02:18:00 --> Input Class Initialized
DEBUG - 2011-08-30 02:18:00 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-30 02:18:00 --> Language Class Initialized
DEBUG - 2011-08-30 02:18:00 --> Loader Class Initialized
DEBUG - 2011-08-30 02:18:00 --> Controller Class Initialized
DEBUG - 2011-08-30 02:18:00 --> Model Class Initialized
DEBUG - 2011-08-30 02:18:00 --> Model Class Initialized
DEBUG - 2011-08-30 02:18:00 --> Model Class Initialized
DEBUG - 2011-08-30 02:18:00 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-30 02:18:00 --> Database Driver Class Initialized
DEBUG - 2011-08-30 02:18:00 --> File loaded: application/views/table/main.php
DEBUG - 2011-08-30 02:18:00 --> Helper loaded: url_helper
DEBUG - 2011-08-30 02:18:00 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-30 02:18:00 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-30 02:18:00 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-30 02:18:00 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-30 02:18:00 --> Final output sent to browser
DEBUG - 2011-08-30 02:18:00 --> Total execution time: 0.0450
DEBUG - 2011-08-30 02:18:01 --> Config Class Initialized
DEBUG - 2011-08-30 02:18:01 --> Hooks Class Initialized
DEBUG - 2011-08-30 02:18:01 --> Utf8 Class Initialized
DEBUG - 2011-08-30 02:18:01 --> UTF-8 Support Enabled
DEBUG - 2011-08-30 02:18:01 --> URI Class Initialized
DEBUG - 2011-08-30 02:18:01 --> Router Class Initialized
ERROR - 2011-08-30 02:18:01 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-08-30 02:18:15 --> Config Class Initialized
DEBUG - 2011-08-30 02:18:15 --> Hooks Class Initialized
DEBUG - 2011-08-30 02:18:15 --> Utf8 Class Initialized
DEBUG - 2011-08-30 02:18:15 --> UTF-8 Support Enabled
DEBUG - 2011-08-30 02:18:15 --> URI Class Initialized
DEBUG - 2011-08-30 02:18:15 --> Router Class Initialized
DEBUG - 2011-08-30 02:18:15 --> Output Class Initialized
DEBUG - 2011-08-30 02:18:15 --> Input Class Initialized
DEBUG - 2011-08-30 02:18:15 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-30 02:18:15 --> Language Class Initialized
DEBUG - 2011-08-30 02:18:15 --> Loader Class Initialized
DEBUG - 2011-08-30 02:18:15 --> Controller Class Initialized
DEBUG - 2011-08-30 02:18:15 --> Model Class Initialized
DEBUG - 2011-08-30 02:18:15 --> Model Class Initialized
DEBUG - 2011-08-30 02:18:15 --> Model Class Initialized
DEBUG - 2011-08-30 02:18:15 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-30 02:18:15 --> Database Driver Class Initialized
DEBUG - 2011-08-30 02:18:16 --> File loaded: application/views/table/main.php
DEBUG - 2011-08-30 02:18:16 --> Helper loaded: url_helper
DEBUG - 2011-08-30 02:18:16 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-30 02:18:16 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-30 02:18:16 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-30 02:18:16 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-30 02:18:16 --> Final output sent to browser
DEBUG - 2011-08-30 02:18:16 --> Total execution time: 0.7481
DEBUG - 2011-08-30 02:18:19 --> Config Class Initialized
DEBUG - 2011-08-30 02:18:19 --> Hooks Class Initialized
DEBUG - 2011-08-30 02:18:19 --> Utf8 Class Initialized
DEBUG - 2011-08-30 02:18:19 --> UTF-8 Support Enabled
DEBUG - 2011-08-30 02:18:19 --> URI Class Initialized
DEBUG - 2011-08-30 02:18:19 --> Router Class Initialized
ERROR - 2011-08-30 02:18:19 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-08-30 02:18:25 --> Config Class Initialized
DEBUG - 2011-08-30 02:18:25 --> Hooks Class Initialized
DEBUG - 2011-08-30 02:18:25 --> Utf8 Class Initialized
DEBUG - 2011-08-30 02:18:25 --> UTF-8 Support Enabled
DEBUG - 2011-08-30 02:18:25 --> URI Class Initialized
DEBUG - 2011-08-30 02:18:25 --> Router Class Initialized
DEBUG - 2011-08-30 02:18:25 --> Output Class Initialized
DEBUG - 2011-08-30 02:18:25 --> Input Class Initialized
DEBUG - 2011-08-30 02:18:25 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-30 02:18:25 --> Language Class Initialized
DEBUG - 2011-08-30 02:18:25 --> Loader Class Initialized
DEBUG - 2011-08-30 02:18:25 --> Controller Class Initialized
DEBUG - 2011-08-30 02:18:25 --> Model Class Initialized
DEBUG - 2011-08-30 02:18:25 --> Model Class Initialized
DEBUG - 2011-08-30 02:18:25 --> Model Class Initialized
DEBUG - 2011-08-30 02:18:25 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-30 02:18:25 --> Database Driver Class Initialized
DEBUG - 2011-08-30 02:18:25 --> File loaded: application/views/table/main.php
DEBUG - 2011-08-30 02:18:25 --> Helper loaded: url_helper
DEBUG - 2011-08-30 02:18:25 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-30 02:18:25 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-30 02:18:25 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-30 02:18:25 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-30 02:18:25 --> Final output sent to browser
DEBUG - 2011-08-30 02:18:25 --> Total execution time: 0.0807
DEBUG - 2011-08-30 02:18:32 --> Config Class Initialized
DEBUG - 2011-08-30 02:18:32 --> Hooks Class Initialized
DEBUG - 2011-08-30 02:18:32 --> Utf8 Class Initialized
DEBUG - 2011-08-30 02:18:32 --> UTF-8 Support Enabled
DEBUG - 2011-08-30 02:18:32 --> URI Class Initialized
DEBUG - 2011-08-30 02:18:32 --> Router Class Initialized
DEBUG - 2011-08-30 02:18:32 --> Output Class Initialized
DEBUG - 2011-08-30 02:18:32 --> Input Class Initialized
DEBUG - 2011-08-30 02:18:32 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-30 02:18:32 --> Language Class Initialized
DEBUG - 2011-08-30 02:18:32 --> Loader Class Initialized
DEBUG - 2011-08-30 02:18:32 --> Controller Class Initialized
DEBUG - 2011-08-30 02:18:32 --> Model Class Initialized
DEBUG - 2011-08-30 02:18:32 --> Model Class Initialized
DEBUG - 2011-08-30 02:18:32 --> Model Class Initialized
DEBUG - 2011-08-30 02:18:32 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-30 02:18:32 --> Database Driver Class Initialized
DEBUG - 2011-08-30 02:18:33 --> File loaded: application/views/table/main.php
DEBUG - 2011-08-30 02:18:33 --> Helper loaded: url_helper
DEBUG - 2011-08-30 02:18:33 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-30 02:18:33 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-30 02:18:33 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-30 02:18:33 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-30 02:18:33 --> Final output sent to browser
DEBUG - 2011-08-30 02:18:33 --> Total execution time: 0.6735
DEBUG - 2011-08-30 02:18:34 --> Config Class Initialized
DEBUG - 2011-08-30 02:18:34 --> Hooks Class Initialized
DEBUG - 2011-08-30 02:18:34 --> Utf8 Class Initialized
DEBUG - 2011-08-30 02:18:34 --> UTF-8 Support Enabled
DEBUG - 2011-08-30 02:18:34 --> URI Class Initialized
DEBUG - 2011-08-30 02:18:34 --> Router Class Initialized
DEBUG - 2011-08-30 02:18:34 --> Output Class Initialized
DEBUG - 2011-08-30 02:18:34 --> Input Class Initialized
DEBUG - 2011-08-30 02:18:34 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-30 02:18:34 --> Language Class Initialized
DEBUG - 2011-08-30 02:18:34 --> Loader Class Initialized
DEBUG - 2011-08-30 02:18:34 --> Controller Class Initialized
DEBUG - 2011-08-30 02:18:34 --> Model Class Initialized
DEBUG - 2011-08-30 02:18:34 --> Model Class Initialized
DEBUG - 2011-08-30 02:18:34 --> Model Class Initialized
DEBUG - 2011-08-30 02:18:34 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-30 02:18:34 --> Database Driver Class Initialized
DEBUG - 2011-08-30 02:18:34 --> File loaded: application/views/table/main.php
DEBUG - 2011-08-30 02:18:34 --> Helper loaded: url_helper
DEBUG - 2011-08-30 02:18:34 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-30 02:18:34 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-30 02:18:34 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-30 02:18:34 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-30 02:18:34 --> Final output sent to browser
DEBUG - 2011-08-30 02:18:34 --> Total execution time: 0.1938
DEBUG - 2011-08-30 02:18:36 --> Config Class Initialized
DEBUG - 2011-08-30 02:18:36 --> Hooks Class Initialized
DEBUG - 2011-08-30 02:18:36 --> Utf8 Class Initialized
DEBUG - 2011-08-30 02:18:36 --> UTF-8 Support Enabled
DEBUG - 2011-08-30 02:18:36 --> URI Class Initialized
DEBUG - 2011-08-30 02:18:36 --> Router Class Initialized
DEBUG - 2011-08-30 02:18:36 --> Output Class Initialized
DEBUG - 2011-08-30 02:18:36 --> Input Class Initialized
DEBUG - 2011-08-30 02:18:36 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-30 02:18:36 --> Language Class Initialized
DEBUG - 2011-08-30 02:18:36 --> Loader Class Initialized
DEBUG - 2011-08-30 02:18:36 --> Controller Class Initialized
DEBUG - 2011-08-30 02:18:36 --> Model Class Initialized
DEBUG - 2011-08-30 02:18:36 --> Model Class Initialized
DEBUG - 2011-08-30 02:18:36 --> Model Class Initialized
DEBUG - 2011-08-30 02:18:36 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-30 02:18:36 --> Database Driver Class Initialized
DEBUG - 2011-08-30 02:18:36 --> File loaded: application/views/table/main.php
DEBUG - 2011-08-30 02:18:36 --> Helper loaded: url_helper
DEBUG - 2011-08-30 02:18:36 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-30 02:18:36 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-30 02:18:36 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-30 02:18:36 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-30 02:18:36 --> Final output sent to browser
DEBUG - 2011-08-30 02:18:36 --> Total execution time: 0.0835
DEBUG - 2011-08-30 02:18:40 --> Config Class Initialized
DEBUG - 2011-08-30 02:18:40 --> Hooks Class Initialized
DEBUG - 2011-08-30 02:18:40 --> Utf8 Class Initialized
DEBUG - 2011-08-30 02:18:40 --> UTF-8 Support Enabled
DEBUG - 2011-08-30 02:18:40 --> URI Class Initialized
DEBUG - 2011-08-30 02:18:40 --> Router Class Initialized
ERROR - 2011-08-30 02:18:40 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-08-30 02:18:44 --> Config Class Initialized
DEBUG - 2011-08-30 02:18:44 --> Hooks Class Initialized
DEBUG - 2011-08-30 02:18:44 --> Utf8 Class Initialized
DEBUG - 2011-08-30 02:18:44 --> UTF-8 Support Enabled
DEBUG - 2011-08-30 02:18:44 --> URI Class Initialized
DEBUG - 2011-08-30 02:18:44 --> Router Class Initialized
DEBUG - 2011-08-30 02:18:44 --> Output Class Initialized
DEBUG - 2011-08-30 02:18:44 --> Input Class Initialized
DEBUG - 2011-08-30 02:18:44 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-30 02:18:44 --> Language Class Initialized
DEBUG - 2011-08-30 02:18:44 --> Loader Class Initialized
DEBUG - 2011-08-30 02:18:44 --> Controller Class Initialized
DEBUG - 2011-08-30 02:18:44 --> Model Class Initialized
DEBUG - 2011-08-30 02:18:44 --> Model Class Initialized
DEBUG - 2011-08-30 02:18:44 --> Model Class Initialized
DEBUG - 2011-08-30 02:18:44 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-30 02:18:44 --> Database Driver Class Initialized
DEBUG - 2011-08-30 02:18:45 --> File loaded: application/views/table/main.php
DEBUG - 2011-08-30 02:18:45 --> Helper loaded: url_helper
DEBUG - 2011-08-30 02:18:45 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-30 02:18:45 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-30 02:18:45 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-30 02:18:45 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-30 02:18:45 --> Final output sent to browser
DEBUG - 2011-08-30 02:18:45 --> Total execution time: 0.8251
DEBUG - 2011-08-30 02:18:49 --> Config Class Initialized
DEBUG - 2011-08-30 02:18:49 --> Hooks Class Initialized
DEBUG - 2011-08-30 02:18:49 --> Utf8 Class Initialized
DEBUG - 2011-08-30 02:18:49 --> UTF-8 Support Enabled
DEBUG - 2011-08-30 02:18:49 --> URI Class Initialized
DEBUG - 2011-08-30 02:18:49 --> Router Class Initialized
ERROR - 2011-08-30 02:18:49 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-08-30 02:18:49 --> Config Class Initialized
DEBUG - 2011-08-30 02:18:49 --> Hooks Class Initialized
DEBUG - 2011-08-30 02:18:49 --> Utf8 Class Initialized
DEBUG - 2011-08-30 02:18:49 --> UTF-8 Support Enabled
DEBUG - 2011-08-30 02:18:49 --> URI Class Initialized
DEBUG - 2011-08-30 02:18:49 --> Router Class Initialized
DEBUG - 2011-08-30 02:18:49 --> Output Class Initialized
DEBUG - 2011-08-30 02:18:49 --> Input Class Initialized
DEBUG - 2011-08-30 02:18:49 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-30 02:18:49 --> Language Class Initialized
DEBUG - 2011-08-30 02:18:49 --> Loader Class Initialized
DEBUG - 2011-08-30 02:18:49 --> Controller Class Initialized
ERROR - 2011-08-30 02:18:49 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-08-30 02:18:49 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-08-30 02:18:49 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-08-30 02:18:49 --> Model Class Initialized
DEBUG - 2011-08-30 02:18:49 --> Model Class Initialized
DEBUG - 2011-08-30 02:18:49 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-30 02:18:49 --> Database Driver Class Initialized
DEBUG - 2011-08-30 02:18:49 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-08-30 02:18:49 --> Helper loaded: url_helper
DEBUG - 2011-08-30 02:18:49 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-30 02:18:49 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-30 02:18:49 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-30 02:18:49 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-30 02:18:49 --> Final output sent to browser
DEBUG - 2011-08-30 02:18:49 --> Total execution time: 0.0336
DEBUG - 2011-08-30 02:18:49 --> Config Class Initialized
DEBUG - 2011-08-30 02:18:49 --> Hooks Class Initialized
DEBUG - 2011-08-30 02:18:49 --> Utf8 Class Initialized
DEBUG - 2011-08-30 02:18:49 --> UTF-8 Support Enabled
DEBUG - 2011-08-30 02:18:49 --> URI Class Initialized
DEBUG - 2011-08-30 02:18:49 --> Router Class Initialized
DEBUG - 2011-08-30 02:18:49 --> Output Class Initialized
DEBUG - 2011-08-30 02:18:49 --> Input Class Initialized
DEBUG - 2011-08-30 02:18:49 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-30 02:18:49 --> Language Class Initialized
DEBUG - 2011-08-30 02:18:49 --> Loader Class Initialized
DEBUG - 2011-08-30 02:18:49 --> Controller Class Initialized
DEBUG - 2011-08-30 02:18:49 --> Model Class Initialized
DEBUG - 2011-08-30 02:18:49 --> Model Class Initialized
DEBUG - 2011-08-30 02:18:49 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-30 02:18:49 --> Config Class Initialized
DEBUG - 2011-08-30 02:18:49 --> Hooks Class Initialized
DEBUG - 2011-08-30 02:18:49 --> Utf8 Class Initialized
DEBUG - 2011-08-30 02:18:49 --> UTF-8 Support Enabled
DEBUG - 2011-08-30 02:18:49 --> URI Class Initialized
DEBUG - 2011-08-30 02:18:49 --> Router Class Initialized
DEBUG - 2011-08-30 02:18:49 --> Output Class Initialized
DEBUG - 2011-08-30 02:18:49 --> Database Driver Class Initialized
DEBUG - 2011-08-30 02:18:49 --> Input Class Initialized
DEBUG - 2011-08-30 02:18:49 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-30 02:18:49 --> Language Class Initialized
DEBUG - 2011-08-30 02:18:49 --> Loader Class Initialized
DEBUG - 2011-08-30 02:18:49 --> Controller Class Initialized
DEBUG - 2011-08-30 02:18:49 --> Model Class Initialized
DEBUG - 2011-08-30 02:18:49 --> Model Class Initialized
DEBUG - 2011-08-30 02:18:49 --> Model Class Initialized
DEBUG - 2011-08-30 02:18:49 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-30 02:18:49 --> Database Driver Class Initialized
DEBUG - 2011-08-30 02:18:49 --> File loaded: application/views/table/main.php
DEBUG - 2011-08-30 02:18:49 --> Helper loaded: url_helper
DEBUG - 2011-08-30 02:18:49 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-30 02:18:49 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-30 02:18:49 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-30 02:18:49 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-30 02:18:49 --> Final output sent to browser
DEBUG - 2011-08-30 02:18:49 --> Total execution time: 0.0560
DEBUG - 2011-08-30 02:18:50 --> Final output sent to browser
DEBUG - 2011-08-30 02:18:50 --> Total execution time: 0.5711
DEBUG - 2011-08-30 02:18:59 --> Config Class Initialized
DEBUG - 2011-08-30 02:18:59 --> Hooks Class Initialized
DEBUG - 2011-08-30 02:18:59 --> Utf8 Class Initialized
DEBUG - 2011-08-30 02:18:59 --> UTF-8 Support Enabled
DEBUG - 2011-08-30 02:18:59 --> URI Class Initialized
DEBUG - 2011-08-30 02:18:59 --> Router Class Initialized
DEBUG - 2011-08-30 02:18:59 --> Output Class Initialized
DEBUG - 2011-08-30 02:18:59 --> Input Class Initialized
DEBUG - 2011-08-30 02:18:59 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-30 02:18:59 --> Language Class Initialized
DEBUG - 2011-08-30 02:18:59 --> Loader Class Initialized
DEBUG - 2011-08-30 02:18:59 --> Controller Class Initialized
DEBUG - 2011-08-30 02:18:59 --> Model Class Initialized
DEBUG - 2011-08-30 02:18:59 --> Model Class Initialized
DEBUG - 2011-08-30 02:18:59 --> Model Class Initialized
DEBUG - 2011-08-30 02:18:59 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-30 02:18:59 --> Database Driver Class Initialized
DEBUG - 2011-08-30 02:18:59 --> File loaded: application/views/table/main.php
DEBUG - 2011-08-30 02:18:59 --> Helper loaded: url_helper
DEBUG - 2011-08-30 02:18:59 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-30 02:18:59 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-30 02:18:59 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-30 02:18:59 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-30 02:18:59 --> Final output sent to browser
DEBUG - 2011-08-30 02:18:59 --> Total execution time: 0.2604
DEBUG - 2011-08-30 02:19:01 --> Config Class Initialized
DEBUG - 2011-08-30 02:19:01 --> Hooks Class Initialized
DEBUG - 2011-08-30 02:19:01 --> Utf8 Class Initialized
DEBUG - 2011-08-30 02:19:01 --> UTF-8 Support Enabled
DEBUG - 2011-08-30 02:19:01 --> URI Class Initialized
DEBUG - 2011-08-30 02:19:01 --> Router Class Initialized
DEBUG - 2011-08-30 02:19:01 --> Output Class Initialized
DEBUG - 2011-08-30 02:19:01 --> Input Class Initialized
DEBUG - 2011-08-30 02:19:01 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-30 02:19:01 --> Language Class Initialized
DEBUG - 2011-08-30 02:19:01 --> Loader Class Initialized
DEBUG - 2011-08-30 02:19:01 --> Controller Class Initialized
DEBUG - 2011-08-30 02:19:01 --> Model Class Initialized
DEBUG - 2011-08-30 02:19:01 --> Model Class Initialized
DEBUG - 2011-08-30 02:19:01 --> Model Class Initialized
DEBUG - 2011-08-30 02:19:01 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-30 02:19:01 --> Database Driver Class Initialized
DEBUG - 2011-08-30 02:19:01 --> File loaded: application/views/table/main.php
DEBUG - 2011-08-30 02:19:01 --> Helper loaded: url_helper
DEBUG - 2011-08-30 02:19:01 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-30 02:19:01 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-30 02:19:01 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-30 02:19:01 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-30 02:19:01 --> Final output sent to browser
DEBUG - 2011-08-30 02:19:01 --> Total execution time: 0.0518
DEBUG - 2011-08-30 02:19:02 --> Config Class Initialized
DEBUG - 2011-08-30 02:19:02 --> Hooks Class Initialized
DEBUG - 2011-08-30 02:19:02 --> Utf8 Class Initialized
DEBUG - 2011-08-30 02:19:02 --> UTF-8 Support Enabled
DEBUG - 2011-08-30 02:19:02 --> URI Class Initialized
DEBUG - 2011-08-30 02:19:02 --> Router Class Initialized
ERROR - 2011-08-30 02:19:02 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-08-30 02:19:12 --> Config Class Initialized
DEBUG - 2011-08-30 02:19:12 --> Hooks Class Initialized
DEBUG - 2011-08-30 02:19:12 --> Utf8 Class Initialized
DEBUG - 2011-08-30 02:19:12 --> UTF-8 Support Enabled
DEBUG - 2011-08-30 02:19:12 --> URI Class Initialized
DEBUG - 2011-08-30 02:19:12 --> Router Class Initialized
DEBUG - 2011-08-30 02:19:12 --> Output Class Initialized
DEBUG - 2011-08-30 02:19:12 --> Input Class Initialized
DEBUG - 2011-08-30 02:19:12 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-30 02:19:12 --> Language Class Initialized
DEBUG - 2011-08-30 02:19:12 --> Loader Class Initialized
DEBUG - 2011-08-30 02:19:12 --> Controller Class Initialized
DEBUG - 2011-08-30 02:19:12 --> Model Class Initialized
DEBUG - 2011-08-30 02:19:12 --> Model Class Initialized
DEBUG - 2011-08-30 02:19:12 --> Model Class Initialized
DEBUG - 2011-08-30 02:19:12 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-30 02:19:12 --> Database Driver Class Initialized
DEBUG - 2011-08-30 02:19:13 --> File loaded: application/views/table/main.php
DEBUG - 2011-08-30 02:19:13 --> Helper loaded: url_helper
DEBUG - 2011-08-30 02:19:13 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-30 02:19:13 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-30 02:19:13 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-30 02:19:13 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-30 02:19:13 --> Final output sent to browser
DEBUG - 2011-08-30 02:19:13 --> Total execution time: 0.9102
DEBUG - 2011-08-30 02:19:14 --> Config Class Initialized
DEBUG - 2011-08-30 02:19:14 --> Hooks Class Initialized
DEBUG - 2011-08-30 02:19:14 --> Utf8 Class Initialized
DEBUG - 2011-08-30 02:19:14 --> UTF-8 Support Enabled
DEBUG - 2011-08-30 02:19:14 --> URI Class Initialized
DEBUG - 2011-08-30 02:19:14 --> Router Class Initialized
DEBUG - 2011-08-30 02:19:14 --> Output Class Initialized
DEBUG - 2011-08-30 02:19:14 --> Input Class Initialized
DEBUG - 2011-08-30 02:19:14 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-30 02:19:14 --> Language Class Initialized
DEBUG - 2011-08-30 02:19:14 --> Loader Class Initialized
DEBUG - 2011-08-30 02:19:14 --> Controller Class Initialized
DEBUG - 2011-08-30 02:19:14 --> Model Class Initialized
DEBUG - 2011-08-30 02:19:14 --> Model Class Initialized
DEBUG - 2011-08-30 02:19:14 --> Model Class Initialized
DEBUG - 2011-08-30 02:19:14 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-30 02:19:14 --> Database Driver Class Initialized
DEBUG - 2011-08-30 02:19:14 --> File loaded: application/views/table/main.php
DEBUG - 2011-08-30 02:19:14 --> Helper loaded: url_helper
DEBUG - 2011-08-30 02:19:14 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-30 02:19:14 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-30 02:19:14 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-30 02:19:14 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-30 02:19:14 --> Final output sent to browser
DEBUG - 2011-08-30 02:19:14 --> Total execution time: 0.0530
DEBUG - 2011-08-30 02:19:23 --> Config Class Initialized
DEBUG - 2011-08-30 02:19:23 --> Hooks Class Initialized
DEBUG - 2011-08-30 02:19:23 --> Utf8 Class Initialized
DEBUG - 2011-08-30 02:19:23 --> UTF-8 Support Enabled
DEBUG - 2011-08-30 02:19:23 --> URI Class Initialized
DEBUG - 2011-08-30 02:19:23 --> Router Class Initialized
ERROR - 2011-08-30 02:19:23 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-08-30 02:19:25 --> Config Class Initialized
DEBUG - 2011-08-30 02:19:25 --> Hooks Class Initialized
DEBUG - 2011-08-30 02:19:25 --> Utf8 Class Initialized
DEBUG - 2011-08-30 02:19:25 --> UTF-8 Support Enabled
DEBUG - 2011-08-30 02:19:25 --> URI Class Initialized
DEBUG - 2011-08-30 02:19:25 --> Router Class Initialized
DEBUG - 2011-08-30 02:19:25 --> Output Class Initialized
DEBUG - 2011-08-30 02:19:25 --> Input Class Initialized
DEBUG - 2011-08-30 02:19:25 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-30 02:19:25 --> Language Class Initialized
DEBUG - 2011-08-30 02:19:25 --> Loader Class Initialized
DEBUG - 2011-08-30 02:19:25 --> Controller Class Initialized
ERROR - 2011-08-30 02:19:25 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-08-30 02:19:25 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-08-30 02:19:25 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-08-30 02:19:25 --> Model Class Initialized
DEBUG - 2011-08-30 02:19:25 --> Model Class Initialized
DEBUG - 2011-08-30 02:19:25 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-30 02:19:25 --> Database Driver Class Initialized
DEBUG - 2011-08-30 02:19:25 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-08-30 02:19:25 --> Helper loaded: url_helper
DEBUG - 2011-08-30 02:19:25 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-30 02:19:25 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-30 02:19:25 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-30 02:19:25 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-30 02:19:25 --> Final output sent to browser
DEBUG - 2011-08-30 02:19:25 --> Total execution time: 0.0334
DEBUG - 2011-08-30 02:19:26 --> Config Class Initialized
DEBUG - 2011-08-30 02:19:26 --> Hooks Class Initialized
DEBUG - 2011-08-30 02:19:26 --> Utf8 Class Initialized
DEBUG - 2011-08-30 02:19:26 --> UTF-8 Support Enabled
DEBUG - 2011-08-30 02:19:26 --> URI Class Initialized
DEBUG - 2011-08-30 02:19:26 --> Router Class Initialized
DEBUG - 2011-08-30 02:19:26 --> Output Class Initialized
DEBUG - 2011-08-30 02:19:26 --> Input Class Initialized
DEBUG - 2011-08-30 02:19:26 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-30 02:19:26 --> Language Class Initialized
DEBUG - 2011-08-30 02:19:26 --> Loader Class Initialized
DEBUG - 2011-08-30 02:19:26 --> Controller Class Initialized
DEBUG - 2011-08-30 02:19:26 --> Model Class Initialized
DEBUG - 2011-08-30 02:19:26 --> Model Class Initialized
DEBUG - 2011-08-30 02:19:26 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-30 02:19:26 --> Database Driver Class Initialized
DEBUG - 2011-08-30 02:19:26 --> Final output sent to browser
DEBUG - 2011-08-30 02:19:26 --> Total execution time: 0.5596
DEBUG - 2011-08-30 02:19:27 --> Config Class Initialized
DEBUG - 2011-08-30 02:19:27 --> Hooks Class Initialized
DEBUG - 2011-08-30 02:19:27 --> Utf8 Class Initialized
DEBUG - 2011-08-30 02:19:27 --> UTF-8 Support Enabled
DEBUG - 2011-08-30 02:19:27 --> URI Class Initialized
DEBUG - 2011-08-30 02:19:27 --> Router Class Initialized
DEBUG - 2011-08-30 02:19:27 --> Output Class Initialized
DEBUG - 2011-08-30 02:19:27 --> Input Class Initialized
DEBUG - 2011-08-30 02:19:27 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-30 02:19:27 --> Language Class Initialized
DEBUG - 2011-08-30 02:19:27 --> Loader Class Initialized
DEBUG - 2011-08-30 02:19:27 --> Controller Class Initialized
DEBUG - 2011-08-30 02:19:27 --> Model Class Initialized
DEBUG - 2011-08-30 02:19:27 --> Model Class Initialized
DEBUG - 2011-08-30 02:19:27 --> Model Class Initialized
DEBUG - 2011-08-30 02:19:27 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-30 02:19:27 --> Database Driver Class Initialized
DEBUG - 2011-08-30 02:19:28 --> File loaded: application/views/table/main.php
DEBUG - 2011-08-30 02:19:28 --> Helper loaded: url_helper
DEBUG - 2011-08-30 02:19:28 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-30 02:19:28 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-30 02:19:28 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-30 02:19:28 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-30 02:19:28 --> Final output sent to browser
DEBUG - 2011-08-30 02:19:28 --> Total execution time: 0.6820
DEBUG - 2011-08-30 02:19:29 --> Config Class Initialized
DEBUG - 2011-08-30 02:19:29 --> Hooks Class Initialized
DEBUG - 2011-08-30 02:19:29 --> Utf8 Class Initialized
DEBUG - 2011-08-30 02:19:29 --> UTF-8 Support Enabled
DEBUG - 2011-08-30 02:19:29 --> URI Class Initialized
DEBUG - 2011-08-30 02:19:29 --> Router Class Initialized
DEBUG - 2011-08-30 02:19:29 --> Output Class Initialized
DEBUG - 2011-08-30 02:19:29 --> Input Class Initialized
DEBUG - 2011-08-30 02:19:29 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-30 02:19:29 --> Language Class Initialized
DEBUG - 2011-08-30 02:19:29 --> Loader Class Initialized
DEBUG - 2011-08-30 02:19:29 --> Controller Class Initialized
DEBUG - 2011-08-30 02:19:29 --> Model Class Initialized
DEBUG - 2011-08-30 02:19:29 --> Model Class Initialized
DEBUG - 2011-08-30 02:19:29 --> Model Class Initialized
DEBUG - 2011-08-30 02:19:29 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-30 02:19:29 --> Database Driver Class Initialized
DEBUG - 2011-08-30 02:19:29 --> File loaded: application/views/table/main.php
DEBUG - 2011-08-30 02:19:29 --> Helper loaded: url_helper
DEBUG - 2011-08-30 02:19:29 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-30 02:19:29 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-30 02:19:29 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-30 02:19:29 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-30 02:19:29 --> Final output sent to browser
DEBUG - 2011-08-30 02:19:29 --> Total execution time: 0.0684
DEBUG - 2011-08-30 02:19:31 --> Config Class Initialized
DEBUG - 2011-08-30 02:19:31 --> Hooks Class Initialized
DEBUG - 2011-08-30 02:19:31 --> Utf8 Class Initialized
DEBUG - 2011-08-30 02:19:31 --> UTF-8 Support Enabled
DEBUG - 2011-08-30 02:19:31 --> URI Class Initialized
DEBUG - 2011-08-30 02:19:31 --> Router Class Initialized
ERROR - 2011-08-30 02:19:31 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-08-30 02:19:35 --> Config Class Initialized
DEBUG - 2011-08-30 02:19:35 --> Hooks Class Initialized
DEBUG - 2011-08-30 02:19:35 --> Utf8 Class Initialized
DEBUG - 2011-08-30 02:19:35 --> UTF-8 Support Enabled
DEBUG - 2011-08-30 02:19:35 --> URI Class Initialized
DEBUG - 2011-08-30 02:19:35 --> Router Class Initialized
DEBUG - 2011-08-30 02:19:35 --> Output Class Initialized
DEBUG - 2011-08-30 02:19:35 --> Input Class Initialized
DEBUG - 2011-08-30 02:19:35 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-30 02:19:35 --> Language Class Initialized
DEBUG - 2011-08-30 02:19:35 --> Loader Class Initialized
DEBUG - 2011-08-30 02:19:35 --> Controller Class Initialized
ERROR - 2011-08-30 02:19:35 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-08-30 02:19:35 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-08-30 02:19:35 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-08-30 02:19:35 --> Model Class Initialized
DEBUG - 2011-08-30 02:19:35 --> Model Class Initialized
DEBUG - 2011-08-30 02:19:35 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-30 02:19:35 --> Database Driver Class Initialized
DEBUG - 2011-08-30 02:19:35 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-08-30 02:19:35 --> Helper loaded: url_helper
DEBUG - 2011-08-30 02:19:35 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-30 02:19:35 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-30 02:19:35 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-30 02:19:35 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-30 02:19:35 --> Final output sent to browser
DEBUG - 2011-08-30 02:19:35 --> Total execution time: 0.0794
DEBUG - 2011-08-30 02:19:36 --> Config Class Initialized
DEBUG - 2011-08-30 02:19:36 --> Hooks Class Initialized
DEBUG - 2011-08-30 02:19:36 --> Utf8 Class Initialized
DEBUG - 2011-08-30 02:19:36 --> UTF-8 Support Enabled
DEBUG - 2011-08-30 02:19:36 --> URI Class Initialized
DEBUG - 2011-08-30 02:19:36 --> Router Class Initialized
DEBUG - 2011-08-30 02:19:36 --> Output Class Initialized
DEBUG - 2011-08-30 02:19:36 --> Input Class Initialized
DEBUG - 2011-08-30 02:19:36 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-30 02:19:36 --> Language Class Initialized
DEBUG - 2011-08-30 02:19:36 --> Loader Class Initialized
DEBUG - 2011-08-30 02:19:36 --> Controller Class Initialized
DEBUG - 2011-08-30 02:19:36 --> Model Class Initialized
DEBUG - 2011-08-30 02:19:36 --> Model Class Initialized
DEBUG - 2011-08-30 02:19:36 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-30 02:19:36 --> Database Driver Class Initialized
DEBUG - 2011-08-30 02:19:36 --> Final output sent to browser
DEBUG - 2011-08-30 02:19:36 --> Total execution time: 0.5251
DEBUG - 2011-08-30 02:19:40 --> Config Class Initialized
DEBUG - 2011-08-30 02:19:40 --> Hooks Class Initialized
DEBUG - 2011-08-30 02:19:40 --> Utf8 Class Initialized
DEBUG - 2011-08-30 02:19:40 --> UTF-8 Support Enabled
DEBUG - 2011-08-30 02:19:40 --> URI Class Initialized
DEBUG - 2011-08-30 02:19:40 --> Router Class Initialized
DEBUG - 2011-08-30 02:19:40 --> Output Class Initialized
DEBUG - 2011-08-30 02:19:40 --> Input Class Initialized
DEBUG - 2011-08-30 02:19:40 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-30 02:19:40 --> Language Class Initialized
DEBUG - 2011-08-30 02:19:41 --> Loader Class Initialized
DEBUG - 2011-08-30 02:19:41 --> Controller Class Initialized
DEBUG - 2011-08-30 02:19:41 --> Model Class Initialized
DEBUG - 2011-08-30 02:19:41 --> Model Class Initialized
DEBUG - 2011-08-30 02:19:41 --> Model Class Initialized
DEBUG - 2011-08-30 02:19:41 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-30 02:19:41 --> Database Driver Class Initialized
DEBUG - 2011-08-30 02:19:41 --> File loaded: application/views/table/main.php
DEBUG - 2011-08-30 02:19:41 --> Helper loaded: url_helper
DEBUG - 2011-08-30 02:19:41 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-30 02:19:41 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-30 02:19:41 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-30 02:19:41 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-30 02:19:41 --> Final output sent to browser
DEBUG - 2011-08-30 02:19:41 --> Total execution time: 0.6781
DEBUG - 2011-08-30 02:19:42 --> Config Class Initialized
DEBUG - 2011-08-30 02:19:42 --> Hooks Class Initialized
DEBUG - 2011-08-30 02:19:42 --> Utf8 Class Initialized
DEBUG - 2011-08-30 02:19:42 --> UTF-8 Support Enabled
DEBUG - 2011-08-30 02:19:42 --> URI Class Initialized
DEBUG - 2011-08-30 02:19:42 --> Router Class Initialized
DEBUG - 2011-08-30 02:19:42 --> Output Class Initialized
DEBUG - 2011-08-30 02:19:42 --> Input Class Initialized
DEBUG - 2011-08-30 02:19:42 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-30 02:19:42 --> Language Class Initialized
DEBUG - 2011-08-30 02:19:42 --> Loader Class Initialized
DEBUG - 2011-08-30 02:19:42 --> Controller Class Initialized
DEBUG - 2011-08-30 02:19:42 --> Model Class Initialized
DEBUG - 2011-08-30 02:19:42 --> Model Class Initialized
DEBUG - 2011-08-30 02:19:42 --> Model Class Initialized
DEBUG - 2011-08-30 02:19:42 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-30 02:19:42 --> Database Driver Class Initialized
DEBUG - 2011-08-30 02:19:42 --> File loaded: application/views/table/main.php
DEBUG - 2011-08-30 02:19:42 --> Helper loaded: url_helper
DEBUG - 2011-08-30 02:19:42 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-30 02:19:42 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-30 02:19:42 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-30 02:19:42 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-30 02:19:42 --> Final output sent to browser
DEBUG - 2011-08-30 02:19:42 --> Total execution time: 0.0834
DEBUG - 2011-08-30 02:19:44 --> Config Class Initialized
DEBUG - 2011-08-30 02:19:44 --> Hooks Class Initialized
DEBUG - 2011-08-30 02:19:44 --> Utf8 Class Initialized
DEBUG - 2011-08-30 02:19:44 --> UTF-8 Support Enabled
DEBUG - 2011-08-30 02:19:44 --> URI Class Initialized
DEBUG - 2011-08-30 02:19:44 --> Router Class Initialized
ERROR - 2011-08-30 02:19:44 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-08-30 02:19:54 --> Config Class Initialized
DEBUG - 2011-08-30 02:19:54 --> Hooks Class Initialized
DEBUG - 2011-08-30 02:19:54 --> Utf8 Class Initialized
DEBUG - 2011-08-30 02:19:54 --> UTF-8 Support Enabled
DEBUG - 2011-08-30 02:19:54 --> URI Class Initialized
DEBUG - 2011-08-30 02:19:54 --> Router Class Initialized
DEBUG - 2011-08-30 02:19:54 --> Output Class Initialized
DEBUG - 2011-08-30 02:19:54 --> Input Class Initialized
DEBUG - 2011-08-30 02:19:54 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-30 02:19:54 --> Language Class Initialized
DEBUG - 2011-08-30 02:19:54 --> Loader Class Initialized
DEBUG - 2011-08-30 02:19:54 --> Controller Class Initialized
DEBUG - 2011-08-30 02:19:54 --> Model Class Initialized
DEBUG - 2011-08-30 02:19:54 --> Model Class Initialized
DEBUG - 2011-08-30 02:19:54 --> Model Class Initialized
DEBUG - 2011-08-30 02:19:54 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-30 02:19:54 --> Database Driver Class Initialized
DEBUG - 2011-08-30 02:19:55 --> File loaded: application/views/table/main.php
DEBUG - 2011-08-30 02:19:55 --> Helper loaded: url_helper
DEBUG - 2011-08-30 02:19:55 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-30 02:19:55 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-30 02:19:55 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-30 02:19:55 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-30 02:19:55 --> Final output sent to browser
DEBUG - 2011-08-30 02:19:55 --> Total execution time: 0.5534
DEBUG - 2011-08-30 02:19:56 --> Config Class Initialized
DEBUG - 2011-08-30 02:19:56 --> Hooks Class Initialized
DEBUG - 2011-08-30 02:19:56 --> Utf8 Class Initialized
DEBUG - 2011-08-30 02:19:56 --> UTF-8 Support Enabled
DEBUG - 2011-08-30 02:19:56 --> URI Class Initialized
DEBUG - 2011-08-30 02:19:56 --> Router Class Initialized
DEBUG - 2011-08-30 02:19:56 --> Output Class Initialized
DEBUG - 2011-08-30 02:19:56 --> Input Class Initialized
DEBUG - 2011-08-30 02:19:56 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-30 02:19:56 --> Language Class Initialized
DEBUG - 2011-08-30 02:19:56 --> Loader Class Initialized
DEBUG - 2011-08-30 02:19:56 --> Controller Class Initialized
DEBUG - 2011-08-30 02:19:56 --> Model Class Initialized
DEBUG - 2011-08-30 02:19:56 --> Model Class Initialized
DEBUG - 2011-08-30 02:19:56 --> Model Class Initialized
DEBUG - 2011-08-30 02:19:56 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-30 02:19:56 --> Database Driver Class Initialized
DEBUG - 2011-08-30 02:19:56 --> File loaded: application/views/table/main.php
DEBUG - 2011-08-30 02:19:56 --> Helper loaded: url_helper
DEBUG - 2011-08-30 02:19:56 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-30 02:19:56 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-30 02:19:56 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-30 02:19:56 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-30 02:19:56 --> Final output sent to browser
DEBUG - 2011-08-30 02:19:56 --> Total execution time: 0.0473
DEBUG - 2011-08-30 02:19:59 --> Config Class Initialized
DEBUG - 2011-08-30 02:19:59 --> Hooks Class Initialized
DEBUG - 2011-08-30 02:19:59 --> Utf8 Class Initialized
DEBUG - 2011-08-30 02:19:59 --> UTF-8 Support Enabled
DEBUG - 2011-08-30 02:19:59 --> URI Class Initialized
DEBUG - 2011-08-30 02:19:59 --> Router Class Initialized
ERROR - 2011-08-30 02:19:59 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-08-30 02:20:04 --> Config Class Initialized
DEBUG - 2011-08-30 02:20:04 --> Hooks Class Initialized
DEBUG - 2011-08-30 02:20:04 --> Utf8 Class Initialized
DEBUG - 2011-08-30 02:20:04 --> UTF-8 Support Enabled
DEBUG - 2011-08-30 02:20:04 --> URI Class Initialized
DEBUG - 2011-08-30 02:20:04 --> Router Class Initialized
DEBUG - 2011-08-30 02:20:04 --> Output Class Initialized
DEBUG - 2011-08-30 02:20:04 --> Input Class Initialized
DEBUG - 2011-08-30 02:20:04 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-30 02:20:04 --> Language Class Initialized
DEBUG - 2011-08-30 02:20:04 --> Loader Class Initialized
DEBUG - 2011-08-30 02:20:04 --> Controller Class Initialized
DEBUG - 2011-08-30 02:20:04 --> Model Class Initialized
DEBUG - 2011-08-30 02:20:04 --> Model Class Initialized
DEBUG - 2011-08-30 02:20:04 --> Model Class Initialized
DEBUG - 2011-08-30 02:20:04 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-30 02:20:04 --> Database Driver Class Initialized
DEBUG - 2011-08-30 02:20:06 --> File loaded: application/views/table/main.php
DEBUG - 2011-08-30 02:20:06 --> Helper loaded: url_helper
DEBUG - 2011-08-30 02:20:06 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-30 02:20:06 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-30 02:20:06 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-30 02:20:06 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-30 02:20:06 --> Final output sent to browser
DEBUG - 2011-08-30 02:20:06 --> Total execution time: 2.5145
DEBUG - 2011-08-30 02:20:07 --> Config Class Initialized
DEBUG - 2011-08-30 02:20:07 --> Hooks Class Initialized
DEBUG - 2011-08-30 02:20:07 --> Utf8 Class Initialized
DEBUG - 2011-08-30 02:20:07 --> UTF-8 Support Enabled
DEBUG - 2011-08-30 02:20:07 --> URI Class Initialized
DEBUG - 2011-08-30 02:20:07 --> Router Class Initialized
DEBUG - 2011-08-30 02:20:07 --> Output Class Initialized
DEBUG - 2011-08-30 02:20:07 --> Input Class Initialized
DEBUG - 2011-08-30 02:20:07 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-30 02:20:07 --> Language Class Initialized
DEBUG - 2011-08-30 02:20:07 --> Loader Class Initialized
DEBUG - 2011-08-30 02:20:07 --> Controller Class Initialized
ERROR - 2011-08-30 02:20:07 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-08-30 02:20:07 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-08-30 02:20:07 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-08-30 02:20:07 --> Model Class Initialized
DEBUG - 2011-08-30 02:20:07 --> Model Class Initialized
DEBUG - 2011-08-30 02:20:07 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-30 02:20:08 --> Database Driver Class Initialized
DEBUG - 2011-08-30 02:20:08 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-08-30 02:20:08 --> Helper loaded: url_helper
DEBUG - 2011-08-30 02:20:08 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-30 02:20:08 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-30 02:20:08 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-30 02:20:08 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-30 02:20:08 --> Final output sent to browser
DEBUG - 2011-08-30 02:20:08 --> Total execution time: 0.0646
DEBUG - 2011-08-30 02:20:08 --> Config Class Initialized
DEBUG - 2011-08-30 02:20:08 --> Hooks Class Initialized
DEBUG - 2011-08-30 02:20:08 --> Utf8 Class Initialized
DEBUG - 2011-08-30 02:20:08 --> UTF-8 Support Enabled
DEBUG - 2011-08-30 02:20:08 --> URI Class Initialized
DEBUG - 2011-08-30 02:20:08 --> Router Class Initialized
DEBUG - 2011-08-30 02:20:08 --> Output Class Initialized
DEBUG - 2011-08-30 02:20:08 --> Input Class Initialized
DEBUG - 2011-08-30 02:20:08 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-30 02:20:08 --> Language Class Initialized
DEBUG - 2011-08-30 02:20:08 --> Loader Class Initialized
DEBUG - 2011-08-30 02:20:08 --> Controller Class Initialized
DEBUG - 2011-08-30 02:20:08 --> Model Class Initialized
DEBUG - 2011-08-30 02:20:08 --> Model Class Initialized
DEBUG - 2011-08-30 02:20:08 --> Model Class Initialized
DEBUG - 2011-08-30 02:20:08 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-30 02:20:08 --> Database Driver Class Initialized
DEBUG - 2011-08-30 02:20:08 --> File loaded: application/views/table/main.php
DEBUG - 2011-08-30 02:20:08 --> Helper loaded: url_helper
DEBUG - 2011-08-30 02:20:08 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-30 02:20:08 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-30 02:20:08 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-30 02:20:08 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-30 02:20:08 --> Final output sent to browser
DEBUG - 2011-08-30 02:20:08 --> Total execution time: 0.1216
DEBUG - 2011-08-30 02:20:08 --> Config Class Initialized
DEBUG - 2011-08-30 02:20:08 --> Hooks Class Initialized
DEBUG - 2011-08-30 02:20:08 --> Utf8 Class Initialized
DEBUG - 2011-08-30 02:20:08 --> UTF-8 Support Enabled
DEBUG - 2011-08-30 02:20:08 --> URI Class Initialized
DEBUG - 2011-08-30 02:20:08 --> Router Class Initialized
DEBUG - 2011-08-30 02:20:08 --> Output Class Initialized
DEBUG - 2011-08-30 02:20:08 --> Input Class Initialized
DEBUG - 2011-08-30 02:20:08 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-30 02:20:08 --> Language Class Initialized
DEBUG - 2011-08-30 02:20:08 --> Loader Class Initialized
DEBUG - 2011-08-30 02:20:08 --> Controller Class Initialized
DEBUG - 2011-08-30 02:20:08 --> Model Class Initialized
DEBUG - 2011-08-30 02:20:08 --> Model Class Initialized
DEBUG - 2011-08-30 02:20:08 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-30 02:20:08 --> Database Driver Class Initialized
DEBUG - 2011-08-30 02:20:09 --> Config Class Initialized
DEBUG - 2011-08-30 02:20:09 --> Hooks Class Initialized
DEBUG - 2011-08-30 02:20:09 --> Utf8 Class Initialized
DEBUG - 2011-08-30 02:20:09 --> UTF-8 Support Enabled
DEBUG - 2011-08-30 02:20:09 --> URI Class Initialized
DEBUG - 2011-08-30 02:20:09 --> Router Class Initialized
ERROR - 2011-08-30 02:20:09 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-08-30 02:20:12 --> Final output sent to browser
DEBUG - 2011-08-30 02:20:12 --> Total execution time: 3.5879
DEBUG - 2011-08-30 02:20:17 --> Config Class Initialized
DEBUG - 2011-08-30 02:20:17 --> Hooks Class Initialized
DEBUG - 2011-08-30 02:20:17 --> Utf8 Class Initialized
DEBUG - 2011-08-30 02:20:17 --> UTF-8 Support Enabled
DEBUG - 2011-08-30 02:20:17 --> URI Class Initialized
DEBUG - 2011-08-30 02:20:17 --> Router Class Initialized
DEBUG - 2011-08-30 02:20:17 --> Output Class Initialized
DEBUG - 2011-08-30 02:20:17 --> Input Class Initialized
DEBUG - 2011-08-30 02:20:17 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-30 02:20:17 --> Language Class Initialized
DEBUG - 2011-08-30 02:20:17 --> Loader Class Initialized
DEBUG - 2011-08-30 02:20:17 --> Controller Class Initialized
ERROR - 2011-08-30 02:20:17 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-08-30 02:20:17 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-08-30 02:20:17 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-08-30 02:20:17 --> Model Class Initialized
DEBUG - 2011-08-30 02:20:17 --> Model Class Initialized
DEBUG - 2011-08-30 02:20:17 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-30 02:20:17 --> Database Driver Class Initialized
DEBUG - 2011-08-30 02:20:17 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-08-30 02:20:17 --> Helper loaded: url_helper
DEBUG - 2011-08-30 02:20:17 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-30 02:20:17 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-30 02:20:17 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-30 02:20:17 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-30 02:20:17 --> Final output sent to browser
DEBUG - 2011-08-30 02:20:17 --> Total execution time: 0.0806
DEBUG - 2011-08-30 02:20:18 --> Config Class Initialized
DEBUG - 2011-08-30 02:20:18 --> Hooks Class Initialized
DEBUG - 2011-08-30 02:20:18 --> Utf8 Class Initialized
DEBUG - 2011-08-30 02:20:18 --> UTF-8 Support Enabled
DEBUG - 2011-08-30 02:20:18 --> URI Class Initialized
DEBUG - 2011-08-30 02:20:18 --> Router Class Initialized
DEBUG - 2011-08-30 02:20:18 --> Output Class Initialized
DEBUG - 2011-08-30 02:20:18 --> Input Class Initialized
DEBUG - 2011-08-30 02:20:18 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-30 02:20:18 --> Language Class Initialized
DEBUG - 2011-08-30 02:20:18 --> Loader Class Initialized
DEBUG - 2011-08-30 02:20:18 --> Controller Class Initialized
DEBUG - 2011-08-30 02:20:18 --> Model Class Initialized
DEBUG - 2011-08-30 02:20:18 --> Model Class Initialized
DEBUG - 2011-08-30 02:20:18 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-30 02:20:18 --> Database Driver Class Initialized
DEBUG - 2011-08-30 02:20:18 --> Config Class Initialized
DEBUG - 2011-08-30 02:20:18 --> Hooks Class Initialized
DEBUG - 2011-08-30 02:20:18 --> Utf8 Class Initialized
DEBUG - 2011-08-30 02:20:18 --> UTF-8 Support Enabled
DEBUG - 2011-08-30 02:20:18 --> URI Class Initialized
DEBUG - 2011-08-30 02:20:18 --> Router Class Initialized
DEBUG - 2011-08-30 02:20:18 --> Output Class Initialized
DEBUG - 2011-08-30 02:20:18 --> Input Class Initialized
DEBUG - 2011-08-30 02:20:18 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-30 02:20:18 --> Language Class Initialized
DEBUG - 2011-08-30 02:20:18 --> Loader Class Initialized
DEBUG - 2011-08-30 02:20:18 --> Controller Class Initialized
DEBUG - 2011-08-30 02:20:18 --> Model Class Initialized
DEBUG - 2011-08-30 02:20:18 --> Model Class Initialized
DEBUG - 2011-08-30 02:20:18 --> Model Class Initialized
DEBUG - 2011-08-30 02:20:18 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-30 02:20:18 --> Database Driver Class Initialized
DEBUG - 2011-08-30 02:20:18 --> Final output sent to browser
DEBUG - 2011-08-30 02:20:18 --> Total execution time: 0.5761
DEBUG - 2011-08-30 02:20:19 --> File loaded: application/views/table/main.php
DEBUG - 2011-08-30 02:20:19 --> Helper loaded: url_helper
DEBUG - 2011-08-30 02:20:19 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-30 02:20:19 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-30 02:20:19 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-30 02:20:19 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-30 02:20:19 --> Final output sent to browser
DEBUG - 2011-08-30 02:20:19 --> Total execution time: 0.3629
DEBUG - 2011-08-30 02:20:21 --> Config Class Initialized
DEBUG - 2011-08-30 02:20:21 --> Hooks Class Initialized
DEBUG - 2011-08-30 02:20:21 --> Utf8 Class Initialized
DEBUG - 2011-08-30 02:20:21 --> UTF-8 Support Enabled
DEBUG - 2011-08-30 02:20:21 --> URI Class Initialized
DEBUG - 2011-08-30 02:20:21 --> Router Class Initialized
DEBUG - 2011-08-30 02:20:21 --> Output Class Initialized
DEBUG - 2011-08-30 02:20:21 --> Input Class Initialized
DEBUG - 2011-08-30 02:20:21 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-30 02:20:21 --> Language Class Initialized
DEBUG - 2011-08-30 02:20:21 --> Loader Class Initialized
DEBUG - 2011-08-30 02:20:21 --> Controller Class Initialized
DEBUG - 2011-08-30 02:20:21 --> Model Class Initialized
DEBUG - 2011-08-30 02:20:21 --> Model Class Initialized
DEBUG - 2011-08-30 02:20:21 --> Model Class Initialized
DEBUG - 2011-08-30 02:20:21 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-30 02:20:21 --> Database Driver Class Initialized
DEBUG - 2011-08-30 02:20:21 --> File loaded: application/views/table/main.php
DEBUG - 2011-08-30 02:20:21 --> Helper loaded: url_helper
DEBUG - 2011-08-30 02:20:21 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-30 02:20:21 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-30 02:20:21 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-30 02:20:21 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-30 02:20:21 --> Final output sent to browser
DEBUG - 2011-08-30 02:20:21 --> Total execution time: 0.1195
DEBUG - 2011-08-30 02:20:22 --> Config Class Initialized
DEBUG - 2011-08-30 02:20:22 --> Hooks Class Initialized
DEBUG - 2011-08-30 02:20:22 --> Utf8 Class Initialized
DEBUG - 2011-08-30 02:20:22 --> UTF-8 Support Enabled
DEBUG - 2011-08-30 02:20:22 --> URI Class Initialized
DEBUG - 2011-08-30 02:20:22 --> Router Class Initialized
ERROR - 2011-08-30 02:20:22 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-08-30 02:20:31 --> Config Class Initialized
DEBUG - 2011-08-30 02:20:31 --> Hooks Class Initialized
DEBUG - 2011-08-30 02:20:31 --> Utf8 Class Initialized
DEBUG - 2011-08-30 02:20:31 --> UTF-8 Support Enabled
DEBUG - 2011-08-30 02:20:31 --> URI Class Initialized
DEBUG - 2011-08-30 02:20:31 --> Router Class Initialized
DEBUG - 2011-08-30 02:20:31 --> Output Class Initialized
DEBUG - 2011-08-30 02:20:31 --> Input Class Initialized
DEBUG - 2011-08-30 02:20:31 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-30 02:20:31 --> Language Class Initialized
DEBUG - 2011-08-30 02:20:31 --> Loader Class Initialized
DEBUG - 2011-08-30 02:20:31 --> Controller Class Initialized
DEBUG - 2011-08-30 02:20:31 --> Model Class Initialized
DEBUG - 2011-08-30 02:20:31 --> Model Class Initialized
DEBUG - 2011-08-30 02:20:31 --> Model Class Initialized
DEBUG - 2011-08-30 02:20:31 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-30 02:20:31 --> Database Driver Class Initialized
DEBUG - 2011-08-30 02:20:33 --> File loaded: application/views/table/main.php
DEBUG - 2011-08-30 02:20:33 --> Helper loaded: url_helper
DEBUG - 2011-08-30 02:20:33 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-30 02:20:33 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-30 02:20:33 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-30 02:20:33 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-30 02:20:33 --> Final output sent to browser
DEBUG - 2011-08-30 02:20:33 --> Total execution time: 1.8633
DEBUG - 2011-08-30 02:20:34 --> Config Class Initialized
DEBUG - 2011-08-30 02:20:34 --> Hooks Class Initialized
DEBUG - 2011-08-30 02:20:34 --> Utf8 Class Initialized
DEBUG - 2011-08-30 02:20:34 --> UTF-8 Support Enabled
DEBUG - 2011-08-30 02:20:34 --> URI Class Initialized
DEBUG - 2011-08-30 02:20:34 --> Router Class Initialized
DEBUG - 2011-08-30 02:20:34 --> Output Class Initialized
DEBUG - 2011-08-30 02:20:34 --> Input Class Initialized
DEBUG - 2011-08-30 02:20:34 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-30 02:20:34 --> Language Class Initialized
DEBUG - 2011-08-30 02:20:34 --> Loader Class Initialized
DEBUG - 2011-08-30 02:20:34 --> Controller Class Initialized
DEBUG - 2011-08-30 02:20:34 --> Model Class Initialized
DEBUG - 2011-08-30 02:20:34 --> Model Class Initialized
DEBUG - 2011-08-30 02:20:34 --> Model Class Initialized
DEBUG - 2011-08-30 02:20:34 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-30 02:20:34 --> Database Driver Class Initialized
DEBUG - 2011-08-30 02:20:34 --> File loaded: application/views/table/main.php
DEBUG - 2011-08-30 02:20:34 --> Helper loaded: url_helper
DEBUG - 2011-08-30 02:20:34 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-30 02:20:34 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-30 02:20:34 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-30 02:20:34 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-30 02:20:34 --> Final output sent to browser
DEBUG - 2011-08-30 02:20:34 --> Total execution time: 0.0416
DEBUG - 2011-08-30 02:20:36 --> Config Class Initialized
DEBUG - 2011-08-30 02:20:36 --> Hooks Class Initialized
DEBUG - 2011-08-30 02:20:36 --> Utf8 Class Initialized
DEBUG - 2011-08-30 02:20:36 --> UTF-8 Support Enabled
DEBUG - 2011-08-30 02:20:36 --> URI Class Initialized
DEBUG - 2011-08-30 02:20:36 --> Router Class Initialized
ERROR - 2011-08-30 02:20:36 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-08-30 02:52:03 --> Config Class Initialized
DEBUG - 2011-08-30 02:52:03 --> Hooks Class Initialized
DEBUG - 2011-08-30 02:52:03 --> Utf8 Class Initialized
DEBUG - 2011-08-30 02:52:03 --> UTF-8 Support Enabled
DEBUG - 2011-08-30 02:52:03 --> URI Class Initialized
DEBUG - 2011-08-30 02:52:03 --> Router Class Initialized
DEBUG - 2011-08-30 02:52:03 --> Output Class Initialized
DEBUG - 2011-08-30 02:52:03 --> Input Class Initialized
DEBUG - 2011-08-30 02:52:03 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-30 02:52:03 --> Language Class Initialized
DEBUG - 2011-08-30 02:52:03 --> Loader Class Initialized
DEBUG - 2011-08-30 02:52:03 --> Controller Class Initialized
ERROR - 2011-08-30 02:52:03 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-08-30 02:52:03 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-08-30 02:52:03 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-08-30 02:52:03 --> Model Class Initialized
DEBUG - 2011-08-30 02:52:03 --> Model Class Initialized
DEBUG - 2011-08-30 02:52:03 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-30 02:52:03 --> Database Driver Class Initialized
DEBUG - 2011-08-30 02:52:03 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-08-30 02:52:03 --> Helper loaded: url_helper
DEBUG - 2011-08-30 02:52:03 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-30 02:52:03 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-30 02:52:03 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-30 02:52:03 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-30 02:52:03 --> Final output sent to browser
DEBUG - 2011-08-30 02:52:03 --> Total execution time: 0.4601
DEBUG - 2011-08-30 02:52:05 --> Config Class Initialized
DEBUG - 2011-08-30 02:52:05 --> Hooks Class Initialized
DEBUG - 2011-08-30 02:52:05 --> Utf8 Class Initialized
DEBUG - 2011-08-30 02:52:05 --> UTF-8 Support Enabled
DEBUG - 2011-08-30 02:52:05 --> URI Class Initialized
DEBUG - 2011-08-30 02:52:05 --> Router Class Initialized
DEBUG - 2011-08-30 02:52:05 --> Output Class Initialized
DEBUG - 2011-08-30 02:52:05 --> Input Class Initialized
DEBUG - 2011-08-30 02:52:05 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-30 02:52:05 --> Language Class Initialized
DEBUG - 2011-08-30 02:52:05 --> Loader Class Initialized
DEBUG - 2011-08-30 02:52:05 --> Controller Class Initialized
DEBUG - 2011-08-30 02:52:05 --> Model Class Initialized
DEBUG - 2011-08-30 02:52:05 --> Model Class Initialized
DEBUG - 2011-08-30 02:52:05 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-30 02:52:05 --> Database Driver Class Initialized
DEBUG - 2011-08-30 02:52:06 --> Final output sent to browser
DEBUG - 2011-08-30 02:52:06 --> Total execution time: 0.8419
DEBUG - 2011-08-30 02:53:20 --> Config Class Initialized
DEBUG - 2011-08-30 02:53:20 --> Hooks Class Initialized
DEBUG - 2011-08-30 02:53:20 --> Utf8 Class Initialized
DEBUG - 2011-08-30 02:53:20 --> UTF-8 Support Enabled
DEBUG - 2011-08-30 02:53:20 --> URI Class Initialized
DEBUG - 2011-08-30 02:53:20 --> Router Class Initialized
ERROR - 2011-08-30 02:53:20 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-08-30 02:53:23 --> Config Class Initialized
DEBUG - 2011-08-30 02:53:23 --> Hooks Class Initialized
DEBUG - 2011-08-30 02:53:23 --> Utf8 Class Initialized
DEBUG - 2011-08-30 02:53:23 --> UTF-8 Support Enabled
DEBUG - 2011-08-30 02:53:23 --> URI Class Initialized
DEBUG - 2011-08-30 02:53:23 --> Router Class Initialized
ERROR - 2011-08-30 02:53:23 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-08-30 03:09:30 --> Config Class Initialized
DEBUG - 2011-08-30 03:09:30 --> Hooks Class Initialized
DEBUG - 2011-08-30 03:09:30 --> Utf8 Class Initialized
DEBUG - 2011-08-30 03:09:30 --> UTF-8 Support Enabled
DEBUG - 2011-08-30 03:09:30 --> URI Class Initialized
DEBUG - 2011-08-30 03:09:30 --> Router Class Initialized
DEBUG - 2011-08-30 03:09:30 --> Output Class Initialized
DEBUG - 2011-08-30 03:09:30 --> Input Class Initialized
DEBUG - 2011-08-30 03:09:30 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-30 03:09:30 --> Language Class Initialized
DEBUG - 2011-08-30 03:09:30 --> Loader Class Initialized
DEBUG - 2011-08-30 03:09:30 --> Controller Class Initialized
ERROR - 2011-08-30 03:09:30 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-08-30 03:09:30 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-08-30 03:09:30 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-08-30 03:09:30 --> Model Class Initialized
DEBUG - 2011-08-30 03:09:30 --> Model Class Initialized
DEBUG - 2011-08-30 03:09:30 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-30 03:09:30 --> Database Driver Class Initialized
DEBUG - 2011-08-30 03:09:30 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-08-30 03:09:30 --> Helper loaded: url_helper
DEBUG - 2011-08-30 03:09:30 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-30 03:09:30 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-30 03:09:30 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-30 03:09:30 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-30 03:09:30 --> Final output sent to browser
DEBUG - 2011-08-30 03:09:30 --> Total execution time: 0.3354
DEBUG - 2011-08-30 03:09:31 --> Config Class Initialized
DEBUG - 2011-08-30 03:09:31 --> Hooks Class Initialized
DEBUG - 2011-08-30 03:09:31 --> Utf8 Class Initialized
DEBUG - 2011-08-30 03:09:31 --> UTF-8 Support Enabled
DEBUG - 2011-08-30 03:09:31 --> URI Class Initialized
DEBUG - 2011-08-30 03:09:31 --> Router Class Initialized
DEBUG - 2011-08-30 03:09:31 --> Output Class Initialized
DEBUG - 2011-08-30 03:09:31 --> Input Class Initialized
DEBUG - 2011-08-30 03:09:31 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-30 03:09:31 --> Language Class Initialized
DEBUG - 2011-08-30 03:09:31 --> Loader Class Initialized
DEBUG - 2011-08-30 03:09:31 --> Controller Class Initialized
DEBUG - 2011-08-30 03:09:31 --> Model Class Initialized
DEBUG - 2011-08-30 03:09:31 --> Model Class Initialized
DEBUG - 2011-08-30 03:09:31 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-30 03:09:31 --> Database Driver Class Initialized
DEBUG - 2011-08-30 03:09:32 --> Final output sent to browser
DEBUG - 2011-08-30 03:09:32 --> Total execution time: 1.1604
DEBUG - 2011-08-30 03:09:33 --> Config Class Initialized
DEBUG - 2011-08-30 03:09:33 --> Hooks Class Initialized
DEBUG - 2011-08-30 03:09:33 --> Utf8 Class Initialized
DEBUG - 2011-08-30 03:09:33 --> UTF-8 Support Enabled
DEBUG - 2011-08-30 03:09:33 --> URI Class Initialized
DEBUG - 2011-08-30 03:09:33 --> Router Class Initialized
ERROR - 2011-08-30 03:09:33 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-08-30 03:09:34 --> Config Class Initialized
DEBUG - 2011-08-30 03:09:34 --> Hooks Class Initialized
DEBUG - 2011-08-30 03:09:34 --> Utf8 Class Initialized
DEBUG - 2011-08-30 03:09:34 --> UTF-8 Support Enabled
DEBUG - 2011-08-30 03:09:34 --> URI Class Initialized
DEBUG - 2011-08-30 03:09:34 --> Router Class Initialized
ERROR - 2011-08-30 03:09:34 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-08-30 03:09:34 --> Config Class Initialized
DEBUG - 2011-08-30 03:09:34 --> Hooks Class Initialized
DEBUG - 2011-08-30 03:09:34 --> Utf8 Class Initialized
DEBUG - 2011-08-30 03:09:34 --> UTF-8 Support Enabled
DEBUG - 2011-08-30 03:09:34 --> URI Class Initialized
DEBUG - 2011-08-30 03:09:34 --> Router Class Initialized
ERROR - 2011-08-30 03:09:34 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-08-30 03:10:14 --> Config Class Initialized
DEBUG - 2011-08-30 03:10:14 --> Hooks Class Initialized
DEBUG - 2011-08-30 03:10:14 --> Utf8 Class Initialized
DEBUG - 2011-08-30 03:10:14 --> UTF-8 Support Enabled
DEBUG - 2011-08-30 03:10:14 --> URI Class Initialized
DEBUG - 2011-08-30 03:10:14 --> Router Class Initialized
DEBUG - 2011-08-30 03:10:14 --> Output Class Initialized
DEBUG - 2011-08-30 03:10:14 --> Input Class Initialized
DEBUG - 2011-08-30 03:10:14 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-30 03:10:14 --> Language Class Initialized
DEBUG - 2011-08-30 03:10:14 --> Loader Class Initialized
DEBUG - 2011-08-30 03:10:14 --> Controller Class Initialized
ERROR - 2011-08-30 03:10:14 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-08-30 03:10:14 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-08-30 03:10:14 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-08-30 03:10:14 --> Model Class Initialized
DEBUG - 2011-08-30 03:10:14 --> Model Class Initialized
DEBUG - 2011-08-30 03:10:14 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-30 03:10:14 --> Database Driver Class Initialized
DEBUG - 2011-08-30 03:10:14 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-08-30 03:10:14 --> Helper loaded: url_helper
DEBUG - 2011-08-30 03:10:14 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-30 03:10:14 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-30 03:10:14 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-30 03:10:14 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-30 03:10:14 --> Final output sent to browser
DEBUG - 2011-08-30 03:10:14 --> Total execution time: 0.0390
DEBUG - 2011-08-30 03:10:15 --> Config Class Initialized
DEBUG - 2011-08-30 03:10:15 --> Hooks Class Initialized
DEBUG - 2011-08-30 03:10:15 --> Utf8 Class Initialized
DEBUG - 2011-08-30 03:10:15 --> UTF-8 Support Enabled
DEBUG - 2011-08-30 03:10:15 --> URI Class Initialized
DEBUG - 2011-08-30 03:10:15 --> Router Class Initialized
DEBUG - 2011-08-30 03:10:15 --> Output Class Initialized
DEBUG - 2011-08-30 03:10:15 --> Input Class Initialized
DEBUG - 2011-08-30 03:10:15 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-30 03:10:15 --> Language Class Initialized
DEBUG - 2011-08-30 03:10:15 --> Loader Class Initialized
DEBUG - 2011-08-30 03:10:15 --> Controller Class Initialized
DEBUG - 2011-08-30 03:10:15 --> Model Class Initialized
DEBUG - 2011-08-30 03:10:15 --> Model Class Initialized
DEBUG - 2011-08-30 03:10:15 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-30 03:10:15 --> Database Driver Class Initialized
DEBUG - 2011-08-30 03:10:16 --> Final output sent to browser
DEBUG - 2011-08-30 03:10:16 --> Total execution time: 0.5056
DEBUG - 2011-08-30 03:10:23 --> Config Class Initialized
DEBUG - 2011-08-30 03:10:23 --> Hooks Class Initialized
DEBUG - 2011-08-30 03:10:23 --> Utf8 Class Initialized
DEBUG - 2011-08-30 03:10:23 --> UTF-8 Support Enabled
DEBUG - 2011-08-30 03:10:23 --> URI Class Initialized
DEBUG - 2011-08-30 03:10:23 --> Router Class Initialized
DEBUG - 2011-08-30 03:10:23 --> Output Class Initialized
DEBUG - 2011-08-30 03:10:23 --> Input Class Initialized
DEBUG - 2011-08-30 03:10:23 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-30 03:10:23 --> Language Class Initialized
DEBUG - 2011-08-30 03:10:23 --> Loader Class Initialized
DEBUG - 2011-08-30 03:10:23 --> Controller Class Initialized
ERROR - 2011-08-30 03:10:23 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-08-30 03:10:23 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-08-30 03:10:23 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-08-30 03:10:23 --> Model Class Initialized
DEBUG - 2011-08-30 03:10:23 --> Model Class Initialized
DEBUG - 2011-08-30 03:10:23 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-30 03:10:23 --> Database Driver Class Initialized
DEBUG - 2011-08-30 03:10:23 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-08-30 03:10:23 --> Helper loaded: url_helper
DEBUG - 2011-08-30 03:10:23 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-30 03:10:23 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-30 03:10:23 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-30 03:10:23 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-30 03:10:23 --> Final output sent to browser
DEBUG - 2011-08-30 03:10:23 --> Total execution time: 0.0327
DEBUG - 2011-08-30 03:10:23 --> Config Class Initialized
DEBUG - 2011-08-30 03:10:23 --> Hooks Class Initialized
DEBUG - 2011-08-30 03:10:23 --> Utf8 Class Initialized
DEBUG - 2011-08-30 03:10:23 --> UTF-8 Support Enabled
DEBUG - 2011-08-30 03:10:23 --> URI Class Initialized
DEBUG - 2011-08-30 03:10:23 --> Router Class Initialized
DEBUG - 2011-08-30 03:10:23 --> Output Class Initialized
DEBUG - 2011-08-30 03:10:23 --> Input Class Initialized
DEBUG - 2011-08-30 03:10:23 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-30 03:10:23 --> Language Class Initialized
DEBUG - 2011-08-30 03:10:23 --> Loader Class Initialized
DEBUG - 2011-08-30 03:10:23 --> Controller Class Initialized
DEBUG - 2011-08-30 03:10:23 --> Model Class Initialized
DEBUG - 2011-08-30 03:10:23 --> Model Class Initialized
DEBUG - 2011-08-30 03:10:23 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-30 03:10:23 --> Database Driver Class Initialized
DEBUG - 2011-08-30 03:10:25 --> Final output sent to browser
DEBUG - 2011-08-30 03:10:25 --> Total execution time: 1.0546
DEBUG - 2011-08-30 03:10:57 --> Config Class Initialized
DEBUG - 2011-08-30 03:10:57 --> Hooks Class Initialized
DEBUG - 2011-08-30 03:10:57 --> Utf8 Class Initialized
DEBUG - 2011-08-30 03:10:57 --> UTF-8 Support Enabled
DEBUG - 2011-08-30 03:10:57 --> URI Class Initialized
DEBUG - 2011-08-30 03:10:57 --> Router Class Initialized
DEBUG - 2011-08-30 03:10:57 --> Output Class Initialized
DEBUG - 2011-08-30 03:10:57 --> Input Class Initialized
DEBUG - 2011-08-30 03:10:57 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-30 03:10:57 --> Language Class Initialized
DEBUG - 2011-08-30 03:10:57 --> Loader Class Initialized
DEBUG - 2011-08-30 03:10:57 --> Controller Class Initialized
ERROR - 2011-08-30 03:10:57 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-08-30 03:10:57 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-08-30 03:10:57 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-08-30 03:10:57 --> Model Class Initialized
DEBUG - 2011-08-30 03:10:57 --> Model Class Initialized
DEBUG - 2011-08-30 03:10:57 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-30 03:10:57 --> Database Driver Class Initialized
DEBUG - 2011-08-30 03:10:57 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-08-30 03:10:57 --> Helper loaded: url_helper
DEBUG - 2011-08-30 03:10:57 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-30 03:10:57 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-30 03:10:57 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-30 03:10:57 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-30 03:10:57 --> Final output sent to browser
DEBUG - 2011-08-30 03:10:57 --> Total execution time: 0.0294
DEBUG - 2011-08-30 03:10:58 --> Config Class Initialized
DEBUG - 2011-08-30 03:10:58 --> Hooks Class Initialized
DEBUG - 2011-08-30 03:10:58 --> Utf8 Class Initialized
DEBUG - 2011-08-30 03:10:58 --> UTF-8 Support Enabled
DEBUG - 2011-08-30 03:10:58 --> URI Class Initialized
DEBUG - 2011-08-30 03:10:58 --> Router Class Initialized
DEBUG - 2011-08-30 03:10:58 --> Output Class Initialized
DEBUG - 2011-08-30 03:10:58 --> Input Class Initialized
DEBUG - 2011-08-30 03:10:58 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-30 03:10:58 --> Language Class Initialized
DEBUG - 2011-08-30 03:10:58 --> Loader Class Initialized
DEBUG - 2011-08-30 03:10:58 --> Controller Class Initialized
DEBUG - 2011-08-30 03:10:58 --> Model Class Initialized
DEBUG - 2011-08-30 03:10:58 --> Model Class Initialized
DEBUG - 2011-08-30 03:10:58 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-30 03:10:58 --> Database Driver Class Initialized
DEBUG - 2011-08-30 03:10:59 --> Final output sent to browser
DEBUG - 2011-08-30 03:10:59 --> Total execution time: 0.5543
DEBUG - 2011-08-30 03:11:07 --> Config Class Initialized
DEBUG - 2011-08-30 03:11:07 --> Hooks Class Initialized
DEBUG - 2011-08-30 03:11:07 --> Utf8 Class Initialized
DEBUG - 2011-08-30 03:11:07 --> UTF-8 Support Enabled
DEBUG - 2011-08-30 03:11:07 --> URI Class Initialized
DEBUG - 2011-08-30 03:11:07 --> Router Class Initialized
DEBUG - 2011-08-30 03:11:07 --> Output Class Initialized
DEBUG - 2011-08-30 03:11:07 --> Input Class Initialized
DEBUG - 2011-08-30 03:11:07 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-30 03:11:07 --> Language Class Initialized
DEBUG - 2011-08-30 03:11:07 --> Loader Class Initialized
DEBUG - 2011-08-30 03:11:07 --> Controller Class Initialized
ERROR - 2011-08-30 03:11:07 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-08-30 03:11:07 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-08-30 03:11:07 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-08-30 03:11:07 --> Model Class Initialized
DEBUG - 2011-08-30 03:11:07 --> Model Class Initialized
DEBUG - 2011-08-30 03:11:07 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-30 03:11:07 --> Database Driver Class Initialized
DEBUG - 2011-08-30 03:11:07 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-08-30 03:11:07 --> Helper loaded: url_helper
DEBUG - 2011-08-30 03:11:07 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-30 03:11:07 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-30 03:11:07 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-30 03:11:07 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-30 03:11:07 --> Final output sent to browser
DEBUG - 2011-08-30 03:11:07 --> Total execution time: 0.0349
DEBUG - 2011-08-30 03:11:08 --> Config Class Initialized
DEBUG - 2011-08-30 03:11:08 --> Hooks Class Initialized
DEBUG - 2011-08-30 03:11:08 --> Utf8 Class Initialized
DEBUG - 2011-08-30 03:11:08 --> UTF-8 Support Enabled
DEBUG - 2011-08-30 03:11:08 --> URI Class Initialized
DEBUG - 2011-08-30 03:11:08 --> Router Class Initialized
DEBUG - 2011-08-30 03:11:08 --> Output Class Initialized
DEBUG - 2011-08-30 03:11:08 --> Input Class Initialized
DEBUG - 2011-08-30 03:11:08 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-30 03:11:08 --> Language Class Initialized
DEBUG - 2011-08-30 03:11:08 --> Loader Class Initialized
DEBUG - 2011-08-30 03:11:08 --> Controller Class Initialized
DEBUG - 2011-08-30 03:11:08 --> Model Class Initialized
DEBUG - 2011-08-30 03:11:08 --> Model Class Initialized
DEBUG - 2011-08-30 03:11:08 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-30 03:11:08 --> Database Driver Class Initialized
DEBUG - 2011-08-30 03:11:12 --> Final output sent to browser
DEBUG - 2011-08-30 03:11:12 --> Total execution time: 3.9482
DEBUG - 2011-08-30 03:34:15 --> Config Class Initialized
DEBUG - 2011-08-30 03:34:15 --> Hooks Class Initialized
DEBUG - 2011-08-30 03:34:15 --> Utf8 Class Initialized
DEBUG - 2011-08-30 03:34:15 --> UTF-8 Support Enabled
DEBUG - 2011-08-30 03:34:15 --> URI Class Initialized
DEBUG - 2011-08-30 03:34:15 --> Router Class Initialized
ERROR - 2011-08-30 03:34:15 --> 404 Page Not Found --> robots.txt
DEBUG - 2011-08-30 03:54:16 --> Config Class Initialized
DEBUG - 2011-08-30 03:54:16 --> Hooks Class Initialized
DEBUG - 2011-08-30 03:54:16 --> Utf8 Class Initialized
DEBUG - 2011-08-30 03:54:16 --> UTF-8 Support Enabled
DEBUG - 2011-08-30 03:54:16 --> URI Class Initialized
DEBUG - 2011-08-30 03:54:16 --> Router Class Initialized
DEBUG - 2011-08-30 03:54:16 --> No URI present. Default controller set.
DEBUG - 2011-08-30 03:54:16 --> Output Class Initialized
DEBUG - 2011-08-30 03:54:16 --> Input Class Initialized
DEBUG - 2011-08-30 03:54:16 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-30 03:54:16 --> Language Class Initialized
DEBUG - 2011-08-30 03:54:16 --> Loader Class Initialized
DEBUG - 2011-08-30 03:54:16 --> Controller Class Initialized
DEBUG - 2011-08-30 03:54:16 --> File loaded: application/views/splash/main.php
DEBUG - 2011-08-30 03:54:16 --> Helper loaded: url_helper
DEBUG - 2011-08-30 03:54:16 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-30 03:54:16 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-30 03:54:16 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-30 03:54:16 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-30 03:54:16 --> Final output sent to browser
DEBUG - 2011-08-30 03:54:16 --> Total execution time: 0.1604
DEBUG - 2011-08-30 04:56:09 --> Config Class Initialized
DEBUG - 2011-08-30 04:56:10 --> Hooks Class Initialized
DEBUG - 2011-08-30 04:56:10 --> Utf8 Class Initialized
DEBUG - 2011-08-30 04:56:10 --> UTF-8 Support Enabled
DEBUG - 2011-08-30 04:56:10 --> URI Class Initialized
DEBUG - 2011-08-30 04:56:10 --> Router Class Initialized
DEBUG - 2011-08-30 04:56:10 --> Output Class Initialized
DEBUG - 2011-08-30 04:56:10 --> Input Class Initialized
DEBUG - 2011-08-30 04:56:10 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-30 04:56:10 --> Language Class Initialized
DEBUG - 2011-08-30 04:56:10 --> Loader Class Initialized
DEBUG - 2011-08-30 04:56:10 --> Controller Class Initialized
DEBUG - 2011-08-30 04:56:10 --> Model Class Initialized
DEBUG - 2011-08-30 04:56:10 --> Model Class Initialized
DEBUG - 2011-08-30 04:56:10 --> Model Class Initialized
DEBUG - 2011-08-30 04:56:10 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-30 04:56:10 --> Database Driver Class Initialized
DEBUG - 2011-08-30 04:56:11 --> File loaded: application/views/table/main.php
DEBUG - 2011-08-30 04:56:11 --> Helper loaded: url_helper
DEBUG - 2011-08-30 04:56:11 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-30 04:56:11 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-30 04:56:11 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-30 04:56:11 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-30 04:56:11 --> Final output sent to browser
DEBUG - 2011-08-30 04:56:11 --> Total execution time: 2.5565
DEBUG - 2011-08-30 05:11:50 --> Config Class Initialized
DEBUG - 2011-08-30 05:11:50 --> Hooks Class Initialized
DEBUG - 2011-08-30 05:11:50 --> Utf8 Class Initialized
DEBUG - 2011-08-30 05:11:50 --> UTF-8 Support Enabled
DEBUG - 2011-08-30 05:11:50 --> URI Class Initialized
DEBUG - 2011-08-30 05:11:50 --> Router Class Initialized
DEBUG - 2011-08-30 05:11:50 --> Output Class Initialized
DEBUG - 2011-08-30 05:11:50 --> Input Class Initialized
DEBUG - 2011-08-30 05:11:50 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-30 05:11:50 --> Language Class Initialized
DEBUG - 2011-08-30 05:11:50 --> Loader Class Initialized
DEBUG - 2011-08-30 05:11:50 --> Controller Class Initialized
DEBUG - 2011-08-30 05:11:50 --> Model Class Initialized
DEBUG - 2011-08-30 05:11:50 --> Model Class Initialized
DEBUG - 2011-08-30 05:11:50 --> Model Class Initialized
DEBUG - 2011-08-30 05:11:50 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-30 05:11:50 --> Database Driver Class Initialized
DEBUG - 2011-08-30 05:11:50 --> File loaded: application/views/table/main.php
DEBUG - 2011-08-30 05:11:50 --> Helper loaded: url_helper
DEBUG - 2011-08-30 05:11:50 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-30 05:11:50 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-30 05:11:50 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-30 05:11:50 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-30 05:11:50 --> Final output sent to browser
DEBUG - 2011-08-30 05:11:50 --> Total execution time: 0.0994
DEBUG - 2011-08-30 05:11:59 --> Config Class Initialized
DEBUG - 2011-08-30 05:11:59 --> Hooks Class Initialized
DEBUG - 2011-08-30 05:11:59 --> Utf8 Class Initialized
DEBUG - 2011-08-30 05:11:59 --> UTF-8 Support Enabled
DEBUG - 2011-08-30 05:11:59 --> URI Class Initialized
DEBUG - 2011-08-30 05:11:59 --> Router Class Initialized
ERROR - 2011-08-30 05:11:59 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-08-30 05:11:59 --> Config Class Initialized
DEBUG - 2011-08-30 05:11:59 --> Hooks Class Initialized
DEBUG - 2011-08-30 05:11:59 --> Utf8 Class Initialized
DEBUG - 2011-08-30 05:11:59 --> UTF-8 Support Enabled
DEBUG - 2011-08-30 05:11:59 --> URI Class Initialized
DEBUG - 2011-08-30 05:11:59 --> Router Class Initialized
ERROR - 2011-08-30 05:11:59 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-08-30 05:12:00 --> Config Class Initialized
DEBUG - 2011-08-30 05:12:00 --> Hooks Class Initialized
DEBUG - 2011-08-30 05:12:00 --> Utf8 Class Initialized
DEBUG - 2011-08-30 05:12:00 --> UTF-8 Support Enabled
DEBUG - 2011-08-30 05:12:00 --> URI Class Initialized
DEBUG - 2011-08-30 05:12:00 --> Router Class Initialized
ERROR - 2011-08-30 05:12:00 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-08-30 05:47:07 --> Config Class Initialized
DEBUG - 2011-08-30 05:47:07 --> Hooks Class Initialized
DEBUG - 2011-08-30 05:47:07 --> Utf8 Class Initialized
DEBUG - 2011-08-30 05:47:07 --> UTF-8 Support Enabled
DEBUG - 2011-08-30 05:47:07 --> URI Class Initialized
DEBUG - 2011-08-30 05:47:07 --> Router Class Initialized
ERROR - 2011-08-30 05:47:07 --> 404 Page Not Found --> robots.txt
DEBUG - 2011-08-30 05:47:10 --> Config Class Initialized
DEBUG - 2011-08-30 05:47:10 --> Hooks Class Initialized
DEBUG - 2011-08-30 05:47:10 --> Utf8 Class Initialized
DEBUG - 2011-08-30 05:47:10 --> UTF-8 Support Enabled
DEBUG - 2011-08-30 05:47:10 --> URI Class Initialized
DEBUG - 2011-08-30 05:47:10 --> Router Class Initialized
DEBUG - 2011-08-30 05:47:10 --> No URI present. Default controller set.
DEBUG - 2011-08-30 05:47:10 --> Output Class Initialized
DEBUG - 2011-08-30 05:47:10 --> Input Class Initialized
DEBUG - 2011-08-30 05:47:10 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-30 05:47:10 --> Language Class Initialized
DEBUG - 2011-08-30 05:47:10 --> Loader Class Initialized
DEBUG - 2011-08-30 05:47:10 --> Controller Class Initialized
DEBUG - 2011-08-30 05:47:10 --> File loaded: application/views/splash/main.php
DEBUG - 2011-08-30 05:47:10 --> Helper loaded: url_helper
DEBUG - 2011-08-30 05:47:10 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-30 05:47:10 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-30 05:47:10 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-30 05:47:10 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-30 05:47:10 --> Final output sent to browser
DEBUG - 2011-08-30 05:47:10 --> Total execution time: 0.1331
DEBUG - 2011-08-30 07:22:21 --> Config Class Initialized
DEBUG - 2011-08-30 07:22:21 --> Hooks Class Initialized
DEBUG - 2011-08-30 07:22:21 --> Utf8 Class Initialized
DEBUG - 2011-08-30 07:22:21 --> UTF-8 Support Enabled
DEBUG - 2011-08-30 07:22:21 --> URI Class Initialized
DEBUG - 2011-08-30 07:22:21 --> Router Class Initialized
DEBUG - 2011-08-30 07:22:21 --> Output Class Initialized
DEBUG - 2011-08-30 07:22:21 --> Input Class Initialized
DEBUG - 2011-08-30 07:22:21 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-30 07:22:21 --> Language Class Initialized
DEBUG - 2011-08-30 07:22:21 --> Loader Class Initialized
DEBUG - 2011-08-30 07:22:21 --> Controller Class Initialized
DEBUG - 2011-08-30 07:22:21 --> Model Class Initialized
DEBUG - 2011-08-30 07:22:21 --> Model Class Initialized
DEBUG - 2011-08-30 07:22:21 --> Model Class Initialized
DEBUG - 2011-08-30 07:22:21 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-30 07:22:21 --> Database Driver Class Initialized
DEBUG - 2011-08-30 07:22:22 --> File loaded: application/views/table/main.php
DEBUG - 2011-08-30 07:22:22 --> Helper loaded: url_helper
DEBUG - 2011-08-30 07:22:22 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-30 07:22:22 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-30 07:22:22 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-30 07:22:22 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-30 07:22:22 --> Final output sent to browser
DEBUG - 2011-08-30 07:22:22 --> Total execution time: 1.4143
DEBUG - 2011-08-30 07:22:24 --> Config Class Initialized
DEBUG - 2011-08-30 07:22:24 --> Hooks Class Initialized
DEBUG - 2011-08-30 07:22:24 --> Utf8 Class Initialized
DEBUG - 2011-08-30 07:22:24 --> UTF-8 Support Enabled
DEBUG - 2011-08-30 07:22:24 --> URI Class Initialized
DEBUG - 2011-08-30 07:22:24 --> Router Class Initialized
DEBUG - 2011-08-30 07:22:24 --> Output Class Initialized
DEBUG - 2011-08-30 07:22:24 --> Input Class Initialized
DEBUG - 2011-08-30 07:22:24 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-30 07:22:24 --> Language Class Initialized
DEBUG - 2011-08-30 07:22:24 --> Loader Class Initialized
DEBUG - 2011-08-30 07:22:24 --> Controller Class Initialized
DEBUG - 2011-08-30 07:22:24 --> Model Class Initialized
DEBUG - 2011-08-30 07:22:24 --> Model Class Initialized
DEBUG - 2011-08-30 07:22:24 --> Model Class Initialized
DEBUG - 2011-08-30 07:22:24 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-30 07:22:24 --> Database Driver Class Initialized
DEBUG - 2011-08-30 07:22:24 --> File loaded: application/views/table/main.php
DEBUG - 2011-08-30 07:22:24 --> Helper loaded: url_helper
DEBUG - 2011-08-30 07:22:24 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-30 07:22:24 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-30 07:22:24 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-30 07:22:24 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-30 07:22:24 --> Final output sent to browser
DEBUG - 2011-08-30 07:22:24 --> Total execution time: 0.5429
DEBUG - 2011-08-30 08:09:20 --> Config Class Initialized
DEBUG - 2011-08-30 08:09:20 --> Hooks Class Initialized
DEBUG - 2011-08-30 08:09:20 --> Utf8 Class Initialized
DEBUG - 2011-08-30 08:09:20 --> UTF-8 Support Enabled
DEBUG - 2011-08-30 08:09:20 --> URI Class Initialized
DEBUG - 2011-08-30 08:09:20 --> Router Class Initialized
ERROR - 2011-08-30 08:09:20 --> 404 Page Not Found --> robots.txt
DEBUG - 2011-08-30 08:25:27 --> Config Class Initialized
DEBUG - 2011-08-30 08:25:27 --> Hooks Class Initialized
DEBUG - 2011-08-30 08:25:27 --> Utf8 Class Initialized
DEBUG - 2011-08-30 08:25:27 --> UTF-8 Support Enabled
DEBUG - 2011-08-30 08:25:27 --> URI Class Initialized
DEBUG - 2011-08-30 08:25:27 --> Router Class Initialized
DEBUG - 2011-08-30 08:25:27 --> Output Class Initialized
DEBUG - 2011-08-30 08:25:27 --> Input Class Initialized
DEBUG - 2011-08-30 08:25:27 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-30 08:25:27 --> Language Class Initialized
DEBUG - 2011-08-30 08:25:27 --> Loader Class Initialized
DEBUG - 2011-08-30 08:25:28 --> Controller Class Initialized
DEBUG - 2011-08-30 08:25:28 --> Model Class Initialized
DEBUG - 2011-08-30 08:25:28 --> Model Class Initialized
DEBUG - 2011-08-30 08:25:28 --> Model Class Initialized
DEBUG - 2011-08-30 08:25:28 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-30 08:25:28 --> Database Driver Class Initialized
DEBUG - 2011-08-30 08:25:28 --> File loaded: application/views/table/main.php
DEBUG - 2011-08-30 08:25:28 --> Helper loaded: url_helper
DEBUG - 2011-08-30 08:25:28 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-30 08:25:28 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-30 08:25:28 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-30 08:25:28 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-30 08:25:28 --> Final output sent to browser
DEBUG - 2011-08-30 08:25:28 --> Total execution time: 0.8656
DEBUG - 2011-08-30 08:25:33 --> Config Class Initialized
DEBUG - 2011-08-30 08:25:33 --> Hooks Class Initialized
DEBUG - 2011-08-30 08:25:33 --> Utf8 Class Initialized
DEBUG - 2011-08-30 08:25:33 --> UTF-8 Support Enabled
DEBUG - 2011-08-30 08:25:33 --> URI Class Initialized
DEBUG - 2011-08-30 08:25:33 --> Router Class Initialized
ERROR - 2011-08-30 08:25:33 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-08-30 08:25:34 --> Config Class Initialized
DEBUG - 2011-08-30 08:25:34 --> Hooks Class Initialized
DEBUG - 2011-08-30 08:25:34 --> Utf8 Class Initialized
DEBUG - 2011-08-30 08:25:34 --> UTF-8 Support Enabled
DEBUG - 2011-08-30 08:25:34 --> URI Class Initialized
DEBUG - 2011-08-30 08:25:34 --> Router Class Initialized
ERROR - 2011-08-30 08:25:34 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-08-30 08:47:15 --> Config Class Initialized
DEBUG - 2011-08-30 08:47:15 --> Hooks Class Initialized
DEBUG - 2011-08-30 08:47:15 --> Utf8 Class Initialized
DEBUG - 2011-08-30 08:47:15 --> UTF-8 Support Enabled
DEBUG - 2011-08-30 08:47:15 --> URI Class Initialized
DEBUG - 2011-08-30 08:47:15 --> Router Class Initialized
DEBUG - 2011-08-30 08:47:15 --> Output Class Initialized
DEBUG - 2011-08-30 08:47:15 --> Input Class Initialized
DEBUG - 2011-08-30 08:47:15 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-30 08:47:15 --> Language Class Initialized
DEBUG - 2011-08-30 08:47:15 --> Loader Class Initialized
DEBUG - 2011-08-30 08:47:15 --> Controller Class Initialized
DEBUG - 2011-08-30 08:47:15 --> Model Class Initialized
DEBUG - 2011-08-30 08:47:15 --> Model Class Initialized
DEBUG - 2011-08-30 08:47:15 --> Model Class Initialized
DEBUG - 2011-08-30 08:47:15 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-30 08:47:15 --> Database Driver Class Initialized
DEBUG - 2011-08-30 08:47:16 --> File loaded: application/views/table/main.php
DEBUG - 2011-08-30 08:47:16 --> Helper loaded: url_helper
DEBUG - 2011-08-30 08:47:16 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-30 08:47:16 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-30 08:47:16 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-30 08:47:16 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-30 08:47:16 --> Final output sent to browser
DEBUG - 2011-08-30 08:47:16 --> Total execution time: 0.6316
DEBUG - 2011-08-30 08:47:20 --> Config Class Initialized
DEBUG - 2011-08-30 08:47:20 --> Hooks Class Initialized
DEBUG - 2011-08-30 08:47:20 --> Utf8 Class Initialized
DEBUG - 2011-08-30 08:47:20 --> UTF-8 Support Enabled
DEBUG - 2011-08-30 08:47:20 --> URI Class Initialized
DEBUG - 2011-08-30 08:47:20 --> Router Class Initialized
ERROR - 2011-08-30 08:47:20 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-08-30 08:47:20 --> Config Class Initialized
DEBUG - 2011-08-30 08:47:20 --> Hooks Class Initialized
DEBUG - 2011-08-30 08:47:20 --> Utf8 Class Initialized
DEBUG - 2011-08-30 08:47:20 --> UTF-8 Support Enabled
DEBUG - 2011-08-30 08:47:20 --> URI Class Initialized
DEBUG - 2011-08-30 08:47:20 --> Router Class Initialized
ERROR - 2011-08-30 08:47:20 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-08-30 08:47:46 --> Config Class Initialized
DEBUG - 2011-08-30 08:47:46 --> Hooks Class Initialized
DEBUG - 2011-08-30 08:47:46 --> Utf8 Class Initialized
DEBUG - 2011-08-30 08:47:46 --> UTF-8 Support Enabled
DEBUG - 2011-08-30 08:47:46 --> URI Class Initialized
DEBUG - 2011-08-30 08:47:46 --> Router Class Initialized
DEBUG - 2011-08-30 08:47:46 --> Output Class Initialized
DEBUG - 2011-08-30 08:47:46 --> Input Class Initialized
DEBUG - 2011-08-30 08:47:46 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-30 08:47:46 --> Language Class Initialized
DEBUG - 2011-08-30 08:47:46 --> Loader Class Initialized
DEBUG - 2011-08-30 08:47:46 --> Controller Class Initialized
DEBUG - 2011-08-30 08:47:46 --> Model Class Initialized
DEBUG - 2011-08-30 08:47:46 --> Model Class Initialized
DEBUG - 2011-08-30 08:47:46 --> Model Class Initialized
DEBUG - 2011-08-30 08:47:46 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-30 08:47:46 --> Database Driver Class Initialized
DEBUG - 2011-08-30 08:47:46 --> File loaded: application/views/table/main.php
DEBUG - 2011-08-30 08:47:46 --> Helper loaded: url_helper
DEBUG - 2011-08-30 08:47:46 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-30 08:47:46 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-30 08:47:46 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-30 08:47:46 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-30 08:47:46 --> Final output sent to browser
DEBUG - 2011-08-30 08:47:46 --> Total execution time: 0.5292
DEBUG - 2011-08-30 08:47:47 --> Config Class Initialized
DEBUG - 2011-08-30 08:47:47 --> Hooks Class Initialized
DEBUG - 2011-08-30 08:47:47 --> Utf8 Class Initialized
DEBUG - 2011-08-30 08:47:47 --> UTF-8 Support Enabled
DEBUG - 2011-08-30 08:47:48 --> URI Class Initialized
DEBUG - 2011-08-30 08:47:48 --> Router Class Initialized
ERROR - 2011-08-30 08:47:48 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-08-30 08:47:48 --> Config Class Initialized
DEBUG - 2011-08-30 08:47:48 --> Hooks Class Initialized
DEBUG - 2011-08-30 08:47:48 --> Utf8 Class Initialized
DEBUG - 2011-08-30 08:47:48 --> UTF-8 Support Enabled
DEBUG - 2011-08-30 08:47:48 --> URI Class Initialized
DEBUG - 2011-08-30 08:47:48 --> Router Class Initialized
ERROR - 2011-08-30 08:47:48 --> 404 Page Not Found --> robots.txt
DEBUG - 2011-08-30 08:47:48 --> Config Class Initialized
DEBUG - 2011-08-30 08:47:48 --> Hooks Class Initialized
DEBUG - 2011-08-30 08:47:48 --> Utf8 Class Initialized
DEBUG - 2011-08-30 08:47:48 --> UTF-8 Support Enabled
DEBUG - 2011-08-30 08:47:48 --> URI Class Initialized
DEBUG - 2011-08-30 08:47:48 --> Router Class Initialized
DEBUG - 2011-08-30 08:47:48 --> Output Class Initialized
DEBUG - 2011-08-30 08:47:48 --> Input Class Initialized
DEBUG - 2011-08-30 08:47:48 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-30 08:47:48 --> Language Class Initialized
DEBUG - 2011-08-30 08:47:48 --> Loader Class Initialized
DEBUG - 2011-08-30 08:47:48 --> Controller Class Initialized
DEBUG - 2011-08-30 08:47:48 --> Model Class Initialized
DEBUG - 2011-08-30 08:47:48 --> Model Class Initialized
DEBUG - 2011-08-30 08:47:48 --> Model Class Initialized
DEBUG - 2011-08-30 08:47:48 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-30 08:47:48 --> Database Driver Class Initialized
DEBUG - 2011-08-30 08:47:48 --> File loaded: application/views/table/main.php
DEBUG - 2011-08-30 08:47:48 --> Helper loaded: url_helper
DEBUG - 2011-08-30 08:47:48 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-30 08:47:48 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-30 08:47:48 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-30 08:47:48 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-30 08:47:48 --> Final output sent to browser
DEBUG - 2011-08-30 08:47:48 --> Total execution time: 0.0602
DEBUG - 2011-08-30 08:48:20 --> Config Class Initialized
DEBUG - 2011-08-30 08:48:20 --> Hooks Class Initialized
DEBUG - 2011-08-30 08:48:20 --> Utf8 Class Initialized
DEBUG - 2011-08-30 08:48:20 --> UTF-8 Support Enabled
DEBUG - 2011-08-30 08:48:20 --> URI Class Initialized
DEBUG - 2011-08-30 08:48:20 --> Router Class Initialized
DEBUG - 2011-08-30 08:48:20 --> Output Class Initialized
DEBUG - 2011-08-30 08:48:20 --> Input Class Initialized
DEBUG - 2011-08-30 08:48:20 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-30 08:48:20 --> Language Class Initialized
DEBUG - 2011-08-30 08:48:20 --> Loader Class Initialized
DEBUG - 2011-08-30 08:48:20 --> Controller Class Initialized
DEBUG - 2011-08-30 08:48:20 --> Model Class Initialized
DEBUG - 2011-08-30 08:48:20 --> Model Class Initialized
DEBUG - 2011-08-30 08:48:20 --> Model Class Initialized
DEBUG - 2011-08-30 08:48:20 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-30 08:48:20 --> Database Driver Class Initialized
DEBUG - 2011-08-30 08:48:20 --> File loaded: application/views/table/main.php
DEBUG - 2011-08-30 08:48:20 --> Helper loaded: url_helper
DEBUG - 2011-08-30 08:48:20 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-30 08:48:20 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-30 08:48:20 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-30 08:48:20 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-30 08:48:20 --> Final output sent to browser
DEBUG - 2011-08-30 08:48:20 --> Total execution time: 0.3675
DEBUG - 2011-08-30 08:48:21 --> Config Class Initialized
DEBUG - 2011-08-30 08:48:21 --> Hooks Class Initialized
DEBUG - 2011-08-30 08:48:21 --> Utf8 Class Initialized
DEBUG - 2011-08-30 08:48:21 --> UTF-8 Support Enabled
DEBUG - 2011-08-30 08:48:21 --> URI Class Initialized
DEBUG - 2011-08-30 08:48:21 --> Router Class Initialized
DEBUG - 2011-08-30 08:48:21 --> Output Class Initialized
DEBUG - 2011-08-30 08:48:21 --> Input Class Initialized
DEBUG - 2011-08-30 08:48:21 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-30 08:48:21 --> Language Class Initialized
DEBUG - 2011-08-30 08:48:21 --> Loader Class Initialized
DEBUG - 2011-08-30 08:48:21 --> Controller Class Initialized
DEBUG - 2011-08-30 08:48:21 --> Model Class Initialized
DEBUG - 2011-08-30 08:48:21 --> Model Class Initialized
DEBUG - 2011-08-30 08:48:21 --> Model Class Initialized
DEBUG - 2011-08-30 08:48:21 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-30 08:48:21 --> Database Driver Class Initialized
DEBUG - 2011-08-30 08:48:21 --> File loaded: application/views/table/main.php
DEBUG - 2011-08-30 08:48:21 --> Helper loaded: url_helper
DEBUG - 2011-08-30 08:48:21 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-30 08:48:21 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-30 08:48:21 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-30 08:48:21 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-30 08:48:21 --> Final output sent to browser
DEBUG - 2011-08-30 08:48:21 --> Total execution time: 0.0472
DEBUG - 2011-08-30 08:48:21 --> Config Class Initialized
DEBUG - 2011-08-30 08:48:21 --> Hooks Class Initialized
DEBUG - 2011-08-30 08:48:21 --> Utf8 Class Initialized
DEBUG - 2011-08-30 08:48:21 --> UTF-8 Support Enabled
DEBUG - 2011-08-30 08:48:21 --> URI Class Initialized
DEBUG - 2011-08-30 08:48:21 --> Router Class Initialized
ERROR - 2011-08-30 08:48:21 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-08-30 09:04:23 --> Config Class Initialized
DEBUG - 2011-08-30 09:04:23 --> Hooks Class Initialized
DEBUG - 2011-08-30 09:04:23 --> Utf8 Class Initialized
DEBUG - 2011-08-30 09:04:23 --> UTF-8 Support Enabled
DEBUG - 2011-08-30 09:04:23 --> URI Class Initialized
DEBUG - 2011-08-30 09:04:23 --> Router Class Initialized
DEBUG - 2011-08-30 09:04:23 --> Output Class Initialized
DEBUG - 2011-08-30 09:04:23 --> Input Class Initialized
DEBUG - 2011-08-30 09:04:23 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-30 09:04:23 --> Language Class Initialized
DEBUG - 2011-08-30 09:04:23 --> Loader Class Initialized
DEBUG - 2011-08-30 09:04:23 --> Controller Class Initialized
ERROR - 2011-08-30 09:04:23 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-08-30 09:04:23 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-08-30 09:04:23 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-08-30 09:04:23 --> Model Class Initialized
DEBUG - 2011-08-30 09:04:23 --> Model Class Initialized
DEBUG - 2011-08-30 09:04:23 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-30 09:04:23 --> Database Driver Class Initialized
DEBUG - 2011-08-30 09:04:23 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-08-30 09:04:23 --> Helper loaded: url_helper
DEBUG - 2011-08-30 09:04:23 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-30 09:04:23 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-30 09:04:23 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-30 09:04:23 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-30 09:04:23 --> Final output sent to browser
DEBUG - 2011-08-30 09:04:23 --> Total execution time: 0.0916
DEBUG - 2011-08-30 09:04:25 --> Config Class Initialized
DEBUG - 2011-08-30 09:04:25 --> Hooks Class Initialized
DEBUG - 2011-08-30 09:04:25 --> Utf8 Class Initialized
DEBUG - 2011-08-30 09:04:25 --> UTF-8 Support Enabled
DEBUG - 2011-08-30 09:04:25 --> URI Class Initialized
DEBUG - 2011-08-30 09:04:25 --> Router Class Initialized
DEBUG - 2011-08-30 09:04:25 --> Output Class Initialized
DEBUG - 2011-08-30 09:04:25 --> Input Class Initialized
DEBUG - 2011-08-30 09:04:25 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-30 09:04:25 --> Language Class Initialized
DEBUG - 2011-08-30 09:04:25 --> Loader Class Initialized
DEBUG - 2011-08-30 09:04:25 --> Controller Class Initialized
DEBUG - 2011-08-30 09:04:25 --> Model Class Initialized
DEBUG - 2011-08-30 09:04:25 --> Model Class Initialized
DEBUG - 2011-08-30 09:04:25 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-30 09:04:25 --> Database Driver Class Initialized
DEBUG - 2011-08-30 09:04:25 --> Final output sent to browser
DEBUG - 2011-08-30 09:04:25 --> Total execution time: 0.6831
DEBUG - 2011-08-30 09:04:27 --> Config Class Initialized
DEBUG - 2011-08-30 09:04:27 --> Hooks Class Initialized
DEBUG - 2011-08-30 09:04:27 --> Utf8 Class Initialized
DEBUG - 2011-08-30 09:04:27 --> UTF-8 Support Enabled
DEBUG - 2011-08-30 09:04:27 --> URI Class Initialized
DEBUG - 2011-08-30 09:04:27 --> Router Class Initialized
ERROR - 2011-08-30 09:04:27 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-08-30 09:04:27 --> Config Class Initialized
DEBUG - 2011-08-30 09:04:27 --> Hooks Class Initialized
DEBUG - 2011-08-30 09:04:27 --> Utf8 Class Initialized
DEBUG - 2011-08-30 09:04:27 --> UTF-8 Support Enabled
DEBUG - 2011-08-30 09:04:27 --> URI Class Initialized
DEBUG - 2011-08-30 09:04:27 --> Router Class Initialized
ERROR - 2011-08-30 09:04:27 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-08-30 09:04:28 --> Config Class Initialized
DEBUG - 2011-08-30 09:04:28 --> Hooks Class Initialized
DEBUG - 2011-08-30 09:04:28 --> Utf8 Class Initialized
DEBUG - 2011-08-30 09:04:28 --> UTF-8 Support Enabled
DEBUG - 2011-08-30 09:04:28 --> URI Class Initialized
DEBUG - 2011-08-30 09:04:28 --> Router Class Initialized
ERROR - 2011-08-30 09:04:28 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-08-30 10:51:16 --> Config Class Initialized
DEBUG - 2011-08-30 10:51:16 --> Hooks Class Initialized
DEBUG - 2011-08-30 10:51:16 --> Utf8 Class Initialized
DEBUG - 2011-08-30 10:51:16 --> UTF-8 Support Enabled
DEBUG - 2011-08-30 10:51:16 --> URI Class Initialized
DEBUG - 2011-08-30 10:51:16 --> Router Class Initialized
DEBUG - 2011-08-30 10:51:16 --> Output Class Initialized
DEBUG - 2011-08-30 10:51:16 --> Input Class Initialized
DEBUG - 2011-08-30 10:51:16 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-30 10:51:16 --> Language Class Initialized
DEBUG - 2011-08-30 10:51:16 --> Loader Class Initialized
DEBUG - 2011-08-30 10:51:16 --> Controller Class Initialized
DEBUG - 2011-08-30 10:51:16 --> Model Class Initialized
DEBUG - 2011-08-30 10:51:16 --> Model Class Initialized
DEBUG - 2011-08-30 10:51:16 --> Model Class Initialized
DEBUG - 2011-08-30 10:51:16 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-30 10:51:16 --> Database Driver Class Initialized
DEBUG - 2011-08-30 10:51:16 --> File loaded: application/views/table/main.php
DEBUG - 2011-08-30 10:51:16 --> Helper loaded: url_helper
DEBUG - 2011-08-30 10:51:16 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-30 10:51:16 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-30 10:51:16 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-30 10:51:16 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-30 10:51:16 --> Final output sent to browser
DEBUG - 2011-08-30 10:51:16 --> Total execution time: 0.4011
DEBUG - 2011-08-30 10:51:19 --> Config Class Initialized
DEBUG - 2011-08-30 10:51:19 --> Hooks Class Initialized
DEBUG - 2011-08-30 10:51:19 --> Utf8 Class Initialized
DEBUG - 2011-08-30 10:51:19 --> UTF-8 Support Enabled
DEBUG - 2011-08-30 10:51:19 --> URI Class Initialized
DEBUG - 2011-08-30 10:51:19 --> Router Class Initialized
ERROR - 2011-08-30 10:51:19 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-08-30 10:51:21 --> Config Class Initialized
DEBUG - 2011-08-30 10:51:21 --> Hooks Class Initialized
DEBUG - 2011-08-30 10:51:21 --> Utf8 Class Initialized
DEBUG - 2011-08-30 10:51:21 --> UTF-8 Support Enabled
DEBUG - 2011-08-30 10:51:21 --> URI Class Initialized
DEBUG - 2011-08-30 10:51:21 --> Router Class Initialized
ERROR - 2011-08-30 10:51:21 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-08-30 10:51:44 --> Config Class Initialized
DEBUG - 2011-08-30 10:51:44 --> Hooks Class Initialized
DEBUG - 2011-08-30 10:51:44 --> Utf8 Class Initialized
DEBUG - 2011-08-30 10:51:44 --> UTF-8 Support Enabled
DEBUG - 2011-08-30 10:51:44 --> URI Class Initialized
DEBUG - 2011-08-30 10:51:44 --> Router Class Initialized
DEBUG - 2011-08-30 10:51:44 --> Output Class Initialized
DEBUG - 2011-08-30 10:51:44 --> Input Class Initialized
DEBUG - 2011-08-30 10:51:44 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-30 10:51:44 --> Language Class Initialized
DEBUG - 2011-08-30 10:51:44 --> Loader Class Initialized
DEBUG - 2011-08-30 10:51:44 --> Controller Class Initialized
DEBUG - 2011-08-30 10:51:44 --> Model Class Initialized
DEBUG - 2011-08-30 10:51:44 --> Model Class Initialized
DEBUG - 2011-08-30 10:51:44 --> Model Class Initialized
DEBUG - 2011-08-30 10:51:44 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-30 10:51:44 --> Database Driver Class Initialized
DEBUG - 2011-08-30 10:51:44 --> File loaded: application/views/table/main.php
DEBUG - 2011-08-30 10:51:44 --> Helper loaded: url_helper
DEBUG - 2011-08-30 10:51:44 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-30 10:51:44 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-30 10:51:44 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-30 10:51:44 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-30 10:51:44 --> Final output sent to browser
DEBUG - 2011-08-30 10:51:44 --> Total execution time: 0.2110
DEBUG - 2011-08-30 10:51:47 --> Config Class Initialized
DEBUG - 2011-08-30 10:51:47 --> Hooks Class Initialized
DEBUG - 2011-08-30 10:51:47 --> Utf8 Class Initialized
DEBUG - 2011-08-30 10:51:47 --> UTF-8 Support Enabled
DEBUG - 2011-08-30 10:51:47 --> URI Class Initialized
DEBUG - 2011-08-30 10:51:47 --> Router Class Initialized
DEBUG - 2011-08-30 10:51:47 --> Output Class Initialized
DEBUG - 2011-08-30 10:51:47 --> Input Class Initialized
DEBUG - 2011-08-30 10:51:47 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-30 10:51:47 --> Language Class Initialized
DEBUG - 2011-08-30 10:51:47 --> Loader Class Initialized
DEBUG - 2011-08-30 10:51:47 --> Controller Class Initialized
DEBUG - 2011-08-30 10:51:47 --> Model Class Initialized
DEBUG - 2011-08-30 10:51:47 --> Model Class Initialized
DEBUG - 2011-08-30 10:51:47 --> Model Class Initialized
DEBUG - 2011-08-30 10:51:47 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-30 10:51:47 --> Database Driver Class Initialized
DEBUG - 2011-08-30 10:51:47 --> File loaded: application/views/table/main.php
DEBUG - 2011-08-30 10:51:47 --> Helper loaded: url_helper
DEBUG - 2011-08-30 10:51:47 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-30 10:51:47 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-30 10:51:47 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-30 10:51:47 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-30 10:51:47 --> Final output sent to browser
DEBUG - 2011-08-30 10:51:47 --> Total execution time: 0.1188
DEBUG - 2011-08-30 10:52:06 --> Config Class Initialized
DEBUG - 2011-08-30 10:52:06 --> Hooks Class Initialized
DEBUG - 2011-08-30 10:52:06 --> Utf8 Class Initialized
DEBUG - 2011-08-30 10:52:06 --> UTF-8 Support Enabled
DEBUG - 2011-08-30 10:52:06 --> URI Class Initialized
DEBUG - 2011-08-30 10:52:06 --> Router Class Initialized
DEBUG - 2011-08-30 10:52:06 --> Output Class Initialized
DEBUG - 2011-08-30 10:52:06 --> Input Class Initialized
DEBUG - 2011-08-30 10:52:06 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-30 10:52:06 --> Language Class Initialized
DEBUG - 2011-08-30 10:52:06 --> Loader Class Initialized
DEBUG - 2011-08-30 10:52:06 --> Controller Class Initialized
DEBUG - 2011-08-30 10:52:06 --> Model Class Initialized
DEBUG - 2011-08-30 10:52:06 --> Model Class Initialized
DEBUG - 2011-08-30 10:52:06 --> Model Class Initialized
DEBUG - 2011-08-30 10:52:06 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-30 10:52:06 --> Database Driver Class Initialized
DEBUG - 2011-08-30 10:52:07 --> File loaded: application/views/table/main.php
DEBUG - 2011-08-30 10:52:07 --> Helper loaded: url_helper
DEBUG - 2011-08-30 10:52:07 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-30 10:52:07 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-30 10:52:07 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-30 10:52:07 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-30 10:52:07 --> Final output sent to browser
DEBUG - 2011-08-30 10:52:07 --> Total execution time: 0.9483
DEBUG - 2011-08-30 10:52:12 --> Config Class Initialized
DEBUG - 2011-08-30 10:52:12 --> Hooks Class Initialized
DEBUG - 2011-08-30 10:52:12 --> Utf8 Class Initialized
DEBUG - 2011-08-30 10:52:12 --> UTF-8 Support Enabled
DEBUG - 2011-08-30 10:52:12 --> URI Class Initialized
DEBUG - 2011-08-30 10:52:12 --> Router Class Initialized
DEBUG - 2011-08-30 10:52:12 --> Output Class Initialized
DEBUG - 2011-08-30 10:52:12 --> Input Class Initialized
DEBUG - 2011-08-30 10:52:12 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-30 10:52:12 --> Language Class Initialized
DEBUG - 2011-08-30 10:52:12 --> Loader Class Initialized
DEBUG - 2011-08-30 10:52:12 --> Controller Class Initialized
DEBUG - 2011-08-30 10:52:12 --> Model Class Initialized
DEBUG - 2011-08-30 10:52:12 --> Model Class Initialized
DEBUG - 2011-08-30 10:52:12 --> Model Class Initialized
DEBUG - 2011-08-30 10:52:12 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-30 10:52:12 --> Database Driver Class Initialized
DEBUG - 2011-08-30 10:52:12 --> File loaded: application/views/table/main.php
DEBUG - 2011-08-30 10:52:12 --> Helper loaded: url_helper
DEBUG - 2011-08-30 10:52:12 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-30 10:52:12 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-30 10:52:12 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-30 10:52:12 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-30 10:52:12 --> Final output sent to browser
DEBUG - 2011-08-30 10:52:12 --> Total execution time: 0.0503
DEBUG - 2011-08-30 10:52:18 --> Config Class Initialized
DEBUG - 2011-08-30 10:52:18 --> Hooks Class Initialized
DEBUG - 2011-08-30 10:52:18 --> Utf8 Class Initialized
DEBUG - 2011-08-30 10:52:18 --> UTF-8 Support Enabled
DEBUG - 2011-08-30 10:52:18 --> URI Class Initialized
DEBUG - 2011-08-30 10:52:18 --> Router Class Initialized
DEBUG - 2011-08-30 10:52:18 --> Output Class Initialized
DEBUG - 2011-08-30 10:52:18 --> Input Class Initialized
DEBUG - 2011-08-30 10:52:18 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-30 10:52:18 --> Language Class Initialized
DEBUG - 2011-08-30 10:52:18 --> Loader Class Initialized
DEBUG - 2011-08-30 10:52:18 --> Controller Class Initialized
DEBUG - 2011-08-30 10:52:18 --> Model Class Initialized
DEBUG - 2011-08-30 10:52:18 --> Model Class Initialized
DEBUG - 2011-08-30 10:52:18 --> Model Class Initialized
DEBUG - 2011-08-30 10:52:18 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-30 10:52:18 --> Database Driver Class Initialized
DEBUG - 2011-08-30 10:52:19 --> File loaded: application/views/table/main.php
DEBUG - 2011-08-30 10:52:19 --> Helper loaded: url_helper
DEBUG - 2011-08-30 10:52:19 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-30 10:52:19 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-30 10:52:19 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-30 10:52:19 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-30 10:52:19 --> Final output sent to browser
DEBUG - 2011-08-30 10:52:19 --> Total execution time: 0.3400
DEBUG - 2011-08-30 10:52:21 --> Config Class Initialized
DEBUG - 2011-08-30 10:52:21 --> Hooks Class Initialized
DEBUG - 2011-08-30 10:52:21 --> Utf8 Class Initialized
DEBUG - 2011-08-30 10:52:21 --> UTF-8 Support Enabled
DEBUG - 2011-08-30 10:52:21 --> URI Class Initialized
DEBUG - 2011-08-30 10:52:21 --> Router Class Initialized
DEBUG - 2011-08-30 10:52:21 --> Output Class Initialized
DEBUG - 2011-08-30 10:52:21 --> Input Class Initialized
DEBUG - 2011-08-30 10:52:21 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-30 10:52:21 --> Language Class Initialized
DEBUG - 2011-08-30 10:52:21 --> Loader Class Initialized
DEBUG - 2011-08-30 10:52:21 --> Controller Class Initialized
DEBUG - 2011-08-30 10:52:21 --> Model Class Initialized
DEBUG - 2011-08-30 10:52:21 --> Model Class Initialized
DEBUG - 2011-08-30 10:52:21 --> Model Class Initialized
DEBUG - 2011-08-30 10:52:21 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-30 10:52:21 --> Database Driver Class Initialized
DEBUG - 2011-08-30 10:52:21 --> File loaded: application/views/table/main.php
DEBUG - 2011-08-30 10:52:21 --> Helper loaded: url_helper
DEBUG - 2011-08-30 10:52:21 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-30 10:52:21 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-30 10:52:21 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-30 10:52:21 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-30 10:52:21 --> Final output sent to browser
DEBUG - 2011-08-30 10:52:21 --> Total execution time: 0.0574
DEBUG - 2011-08-30 10:52:41 --> Config Class Initialized
DEBUG - 2011-08-30 10:52:41 --> Hooks Class Initialized
DEBUG - 2011-08-30 10:52:41 --> Utf8 Class Initialized
DEBUG - 2011-08-30 10:52:41 --> UTF-8 Support Enabled
DEBUG - 2011-08-30 10:52:41 --> URI Class Initialized
DEBUG - 2011-08-30 10:52:41 --> Router Class Initialized
DEBUG - 2011-08-30 10:52:41 --> Output Class Initialized
DEBUG - 2011-08-30 10:52:41 --> Input Class Initialized
DEBUG - 2011-08-30 10:52:41 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-30 10:52:41 --> Language Class Initialized
DEBUG - 2011-08-30 10:52:41 --> Loader Class Initialized
DEBUG - 2011-08-30 10:52:41 --> Controller Class Initialized
DEBUG - 2011-08-30 10:52:41 --> Model Class Initialized
DEBUG - 2011-08-30 10:52:41 --> Model Class Initialized
DEBUG - 2011-08-30 10:52:41 --> Model Class Initialized
DEBUG - 2011-08-30 10:52:41 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-30 10:52:41 --> Database Driver Class Initialized
DEBUG - 2011-08-30 10:52:41 --> File loaded: application/views/table/main.php
DEBUG - 2011-08-30 10:52:41 --> Helper loaded: url_helper
DEBUG - 2011-08-30 10:52:41 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-30 10:52:41 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-30 10:52:41 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-30 10:52:41 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-30 10:52:41 --> Final output sent to browser
DEBUG - 2011-08-30 10:52:41 --> Total execution time: 0.3388
DEBUG - 2011-08-30 10:52:43 --> Config Class Initialized
DEBUG - 2011-08-30 10:52:43 --> Hooks Class Initialized
DEBUG - 2011-08-30 10:52:43 --> Utf8 Class Initialized
DEBUG - 2011-08-30 10:52:43 --> UTF-8 Support Enabled
DEBUG - 2011-08-30 10:52:43 --> URI Class Initialized
DEBUG - 2011-08-30 10:52:43 --> Router Class Initialized
DEBUG - 2011-08-30 10:52:43 --> Output Class Initialized
DEBUG - 2011-08-30 10:52:43 --> Input Class Initialized
DEBUG - 2011-08-30 10:52:43 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-30 10:52:43 --> Language Class Initialized
DEBUG - 2011-08-30 10:52:43 --> Loader Class Initialized
DEBUG - 2011-08-30 10:52:43 --> Controller Class Initialized
DEBUG - 2011-08-30 10:52:43 --> Model Class Initialized
DEBUG - 2011-08-30 10:52:43 --> Model Class Initialized
DEBUG - 2011-08-30 10:52:43 --> Model Class Initialized
DEBUG - 2011-08-30 10:52:43 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-30 10:52:43 --> Database Driver Class Initialized
DEBUG - 2011-08-30 10:52:43 --> File loaded: application/views/table/main.php
DEBUG - 2011-08-30 10:52:43 --> Helper loaded: url_helper
DEBUG - 2011-08-30 10:52:43 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-30 10:52:43 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-30 10:52:43 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-30 10:52:43 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-30 10:52:43 --> Final output sent to browser
DEBUG - 2011-08-30 10:52:43 --> Total execution time: 0.0495
DEBUG - 2011-08-30 10:52:59 --> Config Class Initialized
DEBUG - 2011-08-30 10:52:59 --> Hooks Class Initialized
DEBUG - 2011-08-30 10:52:59 --> Utf8 Class Initialized
DEBUG - 2011-08-30 10:52:59 --> UTF-8 Support Enabled
DEBUG - 2011-08-30 10:52:59 --> URI Class Initialized
DEBUG - 2011-08-30 10:52:59 --> Router Class Initialized
DEBUG - 2011-08-30 10:52:59 --> Output Class Initialized
DEBUG - 2011-08-30 10:52:59 --> Input Class Initialized
DEBUG - 2011-08-30 10:52:59 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-30 10:52:59 --> Language Class Initialized
DEBUG - 2011-08-30 10:52:59 --> Loader Class Initialized
DEBUG - 2011-08-30 10:52:59 --> Controller Class Initialized
ERROR - 2011-08-30 10:52:59 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-08-30 10:52:59 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-08-30 10:52:59 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-08-30 10:52:59 --> Model Class Initialized
DEBUG - 2011-08-30 10:52:59 --> Model Class Initialized
DEBUG - 2011-08-30 10:52:59 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-30 10:52:59 --> Database Driver Class Initialized
DEBUG - 2011-08-30 10:52:59 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-08-30 10:52:59 --> Helper loaded: url_helper
DEBUG - 2011-08-30 10:52:59 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-30 10:52:59 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-30 10:52:59 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-30 10:52:59 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-30 10:52:59 --> Final output sent to browser
DEBUG - 2011-08-30 10:52:59 --> Total execution time: 0.0789
DEBUG - 2011-08-30 10:53:00 --> Config Class Initialized
DEBUG - 2011-08-30 10:53:00 --> Hooks Class Initialized
DEBUG - 2011-08-30 10:53:00 --> Utf8 Class Initialized
DEBUG - 2011-08-30 10:53:00 --> UTF-8 Support Enabled
DEBUG - 2011-08-30 10:53:00 --> URI Class Initialized
DEBUG - 2011-08-30 10:53:00 --> Router Class Initialized
DEBUG - 2011-08-30 10:53:00 --> Output Class Initialized
DEBUG - 2011-08-30 10:53:00 --> Input Class Initialized
DEBUG - 2011-08-30 10:53:00 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-30 10:53:00 --> Language Class Initialized
DEBUG - 2011-08-30 10:53:00 --> Loader Class Initialized
DEBUG - 2011-08-30 10:53:00 --> Controller Class Initialized
DEBUG - 2011-08-30 10:53:00 --> Model Class Initialized
DEBUG - 2011-08-30 10:53:00 --> Model Class Initialized
DEBUG - 2011-08-30 10:53:00 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-30 10:53:00 --> Database Driver Class Initialized
DEBUG - 2011-08-30 10:53:01 --> Final output sent to browser
DEBUG - 2011-08-30 10:53:01 --> Total execution time: 0.5701
DEBUG - 2011-08-30 10:53:05 --> Config Class Initialized
DEBUG - 2011-08-30 10:53:05 --> Hooks Class Initialized
DEBUG - 2011-08-30 10:53:05 --> Utf8 Class Initialized
DEBUG - 2011-08-30 10:53:05 --> UTF-8 Support Enabled
DEBUG - 2011-08-30 10:53:05 --> URI Class Initialized
DEBUG - 2011-08-30 10:53:05 --> Router Class Initialized
DEBUG - 2011-08-30 10:53:05 --> Output Class Initialized
DEBUG - 2011-08-30 10:53:05 --> Input Class Initialized
DEBUG - 2011-08-30 10:53:05 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-30 10:53:05 --> Language Class Initialized
DEBUG - 2011-08-30 10:53:05 --> Loader Class Initialized
DEBUG - 2011-08-30 10:53:05 --> Controller Class Initialized
ERROR - 2011-08-30 10:53:05 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-08-30 10:53:05 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-08-30 10:53:05 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-08-30 10:53:05 --> Model Class Initialized
DEBUG - 2011-08-30 10:53:05 --> Model Class Initialized
DEBUG - 2011-08-30 10:53:05 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-30 10:53:05 --> Database Driver Class Initialized
DEBUG - 2011-08-30 10:53:05 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-08-30 10:53:05 --> Helper loaded: url_helper
DEBUG - 2011-08-30 10:53:05 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-30 10:53:05 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-30 10:53:05 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-30 10:53:05 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-30 10:53:05 --> Final output sent to browser
DEBUG - 2011-08-30 10:53:05 --> Total execution time: 0.0290
DEBUG - 2011-08-30 10:53:06 --> Config Class Initialized
DEBUG - 2011-08-30 10:53:06 --> Hooks Class Initialized
DEBUG - 2011-08-30 10:53:06 --> Utf8 Class Initialized
DEBUG - 2011-08-30 10:53:06 --> UTF-8 Support Enabled
DEBUG - 2011-08-30 10:53:06 --> URI Class Initialized
DEBUG - 2011-08-30 10:53:06 --> Router Class Initialized
DEBUG - 2011-08-30 10:53:06 --> Output Class Initialized
DEBUG - 2011-08-30 10:53:06 --> Input Class Initialized
DEBUG - 2011-08-30 10:53:06 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-30 10:53:06 --> Language Class Initialized
DEBUG - 2011-08-30 10:53:06 --> Loader Class Initialized
DEBUG - 2011-08-30 10:53:06 --> Controller Class Initialized
DEBUG - 2011-08-30 10:53:06 --> Model Class Initialized
DEBUG - 2011-08-30 10:53:06 --> Model Class Initialized
DEBUG - 2011-08-30 10:53:06 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-30 10:53:06 --> Database Driver Class Initialized
DEBUG - 2011-08-30 10:53:07 --> Final output sent to browser
DEBUG - 2011-08-30 10:53:07 --> Total execution time: 0.8620
DEBUG - 2011-08-30 10:53:07 --> Config Class Initialized
DEBUG - 2011-08-30 10:53:07 --> Hooks Class Initialized
DEBUG - 2011-08-30 10:53:07 --> Utf8 Class Initialized
DEBUG - 2011-08-30 10:53:07 --> UTF-8 Support Enabled
DEBUG - 2011-08-30 10:53:07 --> URI Class Initialized
DEBUG - 2011-08-30 10:53:07 --> Router Class Initialized
DEBUG - 2011-08-30 10:53:07 --> Output Class Initialized
DEBUG - 2011-08-30 10:53:07 --> Input Class Initialized
DEBUG - 2011-08-30 10:53:07 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-30 10:53:07 --> Language Class Initialized
DEBUG - 2011-08-30 10:53:07 --> Loader Class Initialized
DEBUG - 2011-08-30 10:53:07 --> Controller Class Initialized
ERROR - 2011-08-30 10:53:07 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-08-30 10:53:07 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-08-30 10:53:07 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-08-30 10:53:07 --> Model Class Initialized
DEBUG - 2011-08-30 10:53:07 --> Model Class Initialized
DEBUG - 2011-08-30 10:53:07 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-30 10:53:07 --> Database Driver Class Initialized
DEBUG - 2011-08-30 10:53:07 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-08-30 10:53:07 --> Helper loaded: url_helper
DEBUG - 2011-08-30 10:53:07 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-30 10:53:07 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-30 10:53:07 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-30 10:53:07 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-30 10:53:07 --> Final output sent to browser
DEBUG - 2011-08-30 10:53:07 --> Total execution time: 0.0815
DEBUG - 2011-08-30 10:55:45 --> Config Class Initialized
DEBUG - 2011-08-30 10:55:45 --> Hooks Class Initialized
DEBUG - 2011-08-30 10:55:45 --> Utf8 Class Initialized
DEBUG - 2011-08-30 10:55:45 --> UTF-8 Support Enabled
DEBUG - 2011-08-30 10:55:45 --> URI Class Initialized
DEBUG - 2011-08-30 10:55:45 --> Router Class Initialized
DEBUG - 2011-08-30 10:55:45 --> No URI present. Default controller set.
DEBUG - 2011-08-30 10:55:45 --> Output Class Initialized
DEBUG - 2011-08-30 10:55:45 --> Input Class Initialized
DEBUG - 2011-08-30 10:55:45 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-30 10:55:45 --> Language Class Initialized
DEBUG - 2011-08-30 10:55:45 --> Loader Class Initialized
DEBUG - 2011-08-30 10:55:45 --> Controller Class Initialized
DEBUG - 2011-08-30 10:55:45 --> File loaded: application/views/splash/main.php
DEBUG - 2011-08-30 10:55:45 --> Helper loaded: url_helper
DEBUG - 2011-08-30 10:55:45 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-30 10:55:45 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-30 10:55:45 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-30 10:55:45 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-30 10:55:45 --> Final output sent to browser
DEBUG - 2011-08-30 10:55:45 --> Total execution time: 0.0680
DEBUG - 2011-08-30 11:22:10 --> Config Class Initialized
DEBUG - 2011-08-30 11:22:10 --> Hooks Class Initialized
DEBUG - 2011-08-30 11:22:10 --> Utf8 Class Initialized
DEBUG - 2011-08-30 11:22:10 --> UTF-8 Support Enabled
DEBUG - 2011-08-30 11:22:10 --> URI Class Initialized
DEBUG - 2011-08-30 11:22:10 --> Router Class Initialized
DEBUG - 2011-08-30 11:22:10 --> Output Class Initialized
DEBUG - 2011-08-30 11:22:10 --> Input Class Initialized
DEBUG - 2011-08-30 11:22:10 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-30 11:22:10 --> Language Class Initialized
DEBUG - 2011-08-30 11:22:10 --> Loader Class Initialized
DEBUG - 2011-08-30 11:22:10 --> Controller Class Initialized
ERROR - 2011-08-30 11:22:10 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-08-30 11:22:10 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-08-30 11:22:10 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-08-30 11:22:10 --> Model Class Initialized
DEBUG - 2011-08-30 11:22:10 --> Model Class Initialized
DEBUG - 2011-08-30 11:22:10 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-30 11:22:10 --> Database Driver Class Initialized
DEBUG - 2011-08-30 11:22:10 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-08-30 11:22:10 --> Helper loaded: url_helper
DEBUG - 2011-08-30 11:22:10 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-30 11:22:10 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-30 11:22:10 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-30 11:22:10 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-30 11:22:10 --> Final output sent to browser
DEBUG - 2011-08-30 11:22:10 --> Total execution time: 0.0363
DEBUG - 2011-08-30 11:22:11 --> Config Class Initialized
DEBUG - 2011-08-30 11:22:11 --> Hooks Class Initialized
DEBUG - 2011-08-30 11:22:11 --> Utf8 Class Initialized
DEBUG - 2011-08-30 11:22:11 --> UTF-8 Support Enabled
DEBUG - 2011-08-30 11:22:11 --> URI Class Initialized
DEBUG - 2011-08-30 11:22:11 --> Router Class Initialized
DEBUG - 2011-08-30 11:22:11 --> Output Class Initialized
DEBUG - 2011-08-30 11:22:11 --> Input Class Initialized
DEBUG - 2011-08-30 11:22:11 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-30 11:22:11 --> Language Class Initialized
DEBUG - 2011-08-30 11:22:11 --> Loader Class Initialized
DEBUG - 2011-08-30 11:22:11 --> Controller Class Initialized
DEBUG - 2011-08-30 11:22:11 --> Model Class Initialized
DEBUG - 2011-08-30 11:22:11 --> Model Class Initialized
DEBUG - 2011-08-30 11:22:11 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-30 11:22:11 --> Database Driver Class Initialized
DEBUG - 2011-08-30 11:22:12 --> Final output sent to browser
DEBUG - 2011-08-30 11:22:12 --> Total execution time: 0.5861
DEBUG - 2011-08-30 11:22:13 --> Config Class Initialized
DEBUG - 2011-08-30 11:22:13 --> Hooks Class Initialized
DEBUG - 2011-08-30 11:22:13 --> Utf8 Class Initialized
DEBUG - 2011-08-30 11:22:13 --> UTF-8 Support Enabled
DEBUG - 2011-08-30 11:22:13 --> URI Class Initialized
DEBUG - 2011-08-30 11:22:13 --> Router Class Initialized
ERROR - 2011-08-30 11:22:13 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-08-30 11:22:14 --> Config Class Initialized
DEBUG - 2011-08-30 11:22:14 --> Hooks Class Initialized
DEBUG - 2011-08-30 11:22:14 --> Utf8 Class Initialized
DEBUG - 2011-08-30 11:22:14 --> UTF-8 Support Enabled
DEBUG - 2011-08-30 11:22:14 --> URI Class Initialized
DEBUG - 2011-08-30 11:22:14 --> Router Class Initialized
ERROR - 2011-08-30 11:22:14 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-08-30 11:22:35 --> Config Class Initialized
DEBUG - 2011-08-30 11:22:35 --> Hooks Class Initialized
DEBUG - 2011-08-30 11:22:35 --> Utf8 Class Initialized
DEBUG - 2011-08-30 11:22:35 --> UTF-8 Support Enabled
DEBUG - 2011-08-30 11:22:35 --> URI Class Initialized
DEBUG - 2011-08-30 11:22:35 --> Router Class Initialized
DEBUG - 2011-08-30 11:22:35 --> Output Class Initialized
DEBUG - 2011-08-30 11:22:35 --> Input Class Initialized
DEBUG - 2011-08-30 11:22:35 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-30 11:22:35 --> Language Class Initialized
DEBUG - 2011-08-30 11:22:35 --> Loader Class Initialized
DEBUG - 2011-08-30 11:22:35 --> Controller Class Initialized
ERROR - 2011-08-30 11:22:35 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-08-30 11:22:35 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-08-30 11:22:35 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-08-30 11:22:35 --> Model Class Initialized
DEBUG - 2011-08-30 11:22:35 --> Model Class Initialized
DEBUG - 2011-08-30 11:22:35 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-30 11:22:35 --> Database Driver Class Initialized
DEBUG - 2011-08-30 11:22:35 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-08-30 11:22:35 --> Helper loaded: url_helper
DEBUG - 2011-08-30 11:22:35 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-30 11:22:35 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-30 11:22:35 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-30 11:22:35 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-30 11:22:35 --> Final output sent to browser
DEBUG - 2011-08-30 11:22:35 --> Total execution time: 0.0288
DEBUG - 2011-08-30 11:22:36 --> Config Class Initialized
DEBUG - 2011-08-30 11:22:36 --> Hooks Class Initialized
DEBUG - 2011-08-30 11:22:36 --> Utf8 Class Initialized
DEBUG - 2011-08-30 11:22:36 --> UTF-8 Support Enabled
DEBUG - 2011-08-30 11:22:36 --> URI Class Initialized
DEBUG - 2011-08-30 11:22:36 --> Router Class Initialized
DEBUG - 2011-08-30 11:22:36 --> Output Class Initialized
DEBUG - 2011-08-30 11:22:36 --> Input Class Initialized
DEBUG - 2011-08-30 11:22:36 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-30 11:22:36 --> Language Class Initialized
DEBUG - 2011-08-30 11:22:36 --> Loader Class Initialized
DEBUG - 2011-08-30 11:22:36 --> Controller Class Initialized
DEBUG - 2011-08-30 11:22:36 --> Model Class Initialized
DEBUG - 2011-08-30 11:22:36 --> Model Class Initialized
DEBUG - 2011-08-30 11:22:36 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-30 11:22:36 --> Database Driver Class Initialized
DEBUG - 2011-08-30 11:22:36 --> Final output sent to browser
DEBUG - 2011-08-30 11:22:36 --> Total execution time: 0.5030
DEBUG - 2011-08-30 11:22:37 --> Config Class Initialized
DEBUG - 2011-08-30 11:22:37 --> Hooks Class Initialized
DEBUG - 2011-08-30 11:22:37 --> Utf8 Class Initialized
DEBUG - 2011-08-30 11:22:37 --> UTF-8 Support Enabled
DEBUG - 2011-08-30 11:22:37 --> URI Class Initialized
DEBUG - 2011-08-30 11:22:37 --> Router Class Initialized
ERROR - 2011-08-30 11:22:37 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-08-30 11:22:49 --> Config Class Initialized
DEBUG - 2011-08-30 11:22:49 --> Hooks Class Initialized
DEBUG - 2011-08-30 11:22:49 --> Utf8 Class Initialized
DEBUG - 2011-08-30 11:22:49 --> UTF-8 Support Enabled
DEBUG - 2011-08-30 11:22:49 --> URI Class Initialized
DEBUG - 2011-08-30 11:22:49 --> Router Class Initialized
DEBUG - 2011-08-30 11:22:49 --> Output Class Initialized
DEBUG - 2011-08-30 11:22:49 --> Input Class Initialized
DEBUG - 2011-08-30 11:22:49 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-30 11:22:49 --> Language Class Initialized
DEBUG - 2011-08-30 11:22:49 --> Loader Class Initialized
DEBUG - 2011-08-30 11:22:49 --> Controller Class Initialized
ERROR - 2011-08-30 11:22:49 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-08-30 11:22:49 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-08-30 11:22:49 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-08-30 11:22:49 --> Model Class Initialized
DEBUG - 2011-08-30 11:22:49 --> Model Class Initialized
DEBUG - 2011-08-30 11:22:49 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-30 11:22:49 --> Database Driver Class Initialized
DEBUG - 2011-08-30 11:22:49 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-08-30 11:22:49 --> Helper loaded: url_helper
DEBUG - 2011-08-30 11:22:49 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-30 11:22:49 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-30 11:22:49 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-30 11:22:49 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-30 11:22:49 --> Final output sent to browser
DEBUG - 2011-08-30 11:22:49 --> Total execution time: 0.0276
DEBUG - 2011-08-30 11:22:50 --> Config Class Initialized
DEBUG - 2011-08-30 11:22:50 --> Hooks Class Initialized
DEBUG - 2011-08-30 11:22:50 --> Utf8 Class Initialized
DEBUG - 2011-08-30 11:22:50 --> UTF-8 Support Enabled
DEBUG - 2011-08-30 11:22:50 --> URI Class Initialized
DEBUG - 2011-08-30 11:22:50 --> Router Class Initialized
DEBUG - 2011-08-30 11:22:50 --> Output Class Initialized
DEBUG - 2011-08-30 11:22:50 --> Input Class Initialized
DEBUG - 2011-08-30 11:22:50 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-30 11:22:50 --> Language Class Initialized
DEBUG - 2011-08-30 11:22:50 --> Loader Class Initialized
DEBUG - 2011-08-30 11:22:50 --> Controller Class Initialized
DEBUG - 2011-08-30 11:22:50 --> Model Class Initialized
DEBUG - 2011-08-30 11:22:50 --> Model Class Initialized
DEBUG - 2011-08-30 11:22:50 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-30 11:22:50 --> Database Driver Class Initialized
DEBUG - 2011-08-30 11:22:50 --> Final output sent to browser
DEBUG - 2011-08-30 11:22:50 --> Total execution time: 0.6025
DEBUG - 2011-08-30 11:22:51 --> Config Class Initialized
DEBUG - 2011-08-30 11:22:51 --> Hooks Class Initialized
DEBUG - 2011-08-30 11:22:51 --> Utf8 Class Initialized
DEBUG - 2011-08-30 11:22:51 --> UTF-8 Support Enabled
DEBUG - 2011-08-30 11:22:51 --> URI Class Initialized
DEBUG - 2011-08-30 11:22:51 --> Router Class Initialized
ERROR - 2011-08-30 11:22:51 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-08-30 11:23:19 --> Config Class Initialized
DEBUG - 2011-08-30 11:23:19 --> Hooks Class Initialized
DEBUG - 2011-08-30 11:23:19 --> Utf8 Class Initialized
DEBUG - 2011-08-30 11:23:19 --> UTF-8 Support Enabled
DEBUG - 2011-08-30 11:23:19 --> URI Class Initialized
DEBUG - 2011-08-30 11:23:19 --> Router Class Initialized
DEBUG - 2011-08-30 11:23:19 --> Output Class Initialized
DEBUG - 2011-08-30 11:23:19 --> Input Class Initialized
DEBUG - 2011-08-30 11:23:19 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-30 11:23:19 --> Language Class Initialized
DEBUG - 2011-08-30 11:23:19 --> Loader Class Initialized
DEBUG - 2011-08-30 11:23:19 --> Controller Class Initialized
ERROR - 2011-08-30 11:23:19 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-08-30 11:23:19 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-08-30 11:23:19 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-08-30 11:23:19 --> Model Class Initialized
DEBUG - 2011-08-30 11:23:19 --> Model Class Initialized
DEBUG - 2011-08-30 11:23:19 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-30 11:23:20 --> Database Driver Class Initialized
DEBUG - 2011-08-30 11:23:20 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-08-30 11:23:20 --> Helper loaded: url_helper
DEBUG - 2011-08-30 11:23:20 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-30 11:23:20 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-30 11:23:20 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-30 11:23:20 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-30 11:23:20 --> Final output sent to browser
DEBUG - 2011-08-30 11:23:20 --> Total execution time: 0.0293
DEBUG - 2011-08-30 11:23:20 --> Config Class Initialized
DEBUG - 2011-08-30 11:23:20 --> Hooks Class Initialized
DEBUG - 2011-08-30 11:23:20 --> Utf8 Class Initialized
DEBUG - 2011-08-30 11:23:20 --> UTF-8 Support Enabled
DEBUG - 2011-08-30 11:23:20 --> URI Class Initialized
DEBUG - 2011-08-30 11:23:20 --> Router Class Initialized
DEBUG - 2011-08-30 11:23:20 --> Output Class Initialized
DEBUG - 2011-08-30 11:23:20 --> Input Class Initialized
DEBUG - 2011-08-30 11:23:20 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-30 11:23:20 --> Language Class Initialized
DEBUG - 2011-08-30 11:23:20 --> Loader Class Initialized
DEBUG - 2011-08-30 11:23:20 --> Controller Class Initialized
DEBUG - 2011-08-30 11:23:20 --> Model Class Initialized
DEBUG - 2011-08-30 11:23:20 --> Model Class Initialized
DEBUG - 2011-08-30 11:23:20 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-30 11:23:20 --> Database Driver Class Initialized
DEBUG - 2011-08-30 11:23:21 --> Final output sent to browser
DEBUG - 2011-08-30 11:23:21 --> Total execution time: 0.6365
DEBUG - 2011-08-30 11:23:22 --> Config Class Initialized
DEBUG - 2011-08-30 11:23:22 --> Hooks Class Initialized
DEBUG - 2011-08-30 11:23:22 --> Utf8 Class Initialized
DEBUG - 2011-08-30 11:23:22 --> UTF-8 Support Enabled
DEBUG - 2011-08-30 11:23:22 --> URI Class Initialized
DEBUG - 2011-08-30 11:23:22 --> Router Class Initialized
ERROR - 2011-08-30 11:23:22 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-08-30 11:23:33 --> Config Class Initialized
DEBUG - 2011-08-30 11:23:33 --> Hooks Class Initialized
DEBUG - 2011-08-30 11:23:33 --> Utf8 Class Initialized
DEBUG - 2011-08-30 11:23:33 --> UTF-8 Support Enabled
DEBUG - 2011-08-30 11:23:33 --> URI Class Initialized
DEBUG - 2011-08-30 11:23:33 --> Router Class Initialized
DEBUG - 2011-08-30 11:23:33 --> Output Class Initialized
DEBUG - 2011-08-30 11:23:33 --> Input Class Initialized
DEBUG - 2011-08-30 11:23:33 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-30 11:23:33 --> Language Class Initialized
DEBUG - 2011-08-30 11:23:33 --> Loader Class Initialized
DEBUG - 2011-08-30 11:23:33 --> Controller Class Initialized
ERROR - 2011-08-30 11:23:33 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-08-30 11:23:33 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-08-30 11:23:33 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-08-30 11:23:33 --> Model Class Initialized
DEBUG - 2011-08-30 11:23:33 --> Model Class Initialized
DEBUG - 2011-08-30 11:23:33 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-30 11:23:33 --> Database Driver Class Initialized
DEBUG - 2011-08-30 11:23:33 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-08-30 11:23:33 --> Helper loaded: url_helper
DEBUG - 2011-08-30 11:23:33 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-30 11:23:33 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-30 11:23:33 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-30 11:23:33 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-30 11:23:33 --> Final output sent to browser
DEBUG - 2011-08-30 11:23:33 --> Total execution time: 0.0298
DEBUG - 2011-08-30 11:23:34 --> Config Class Initialized
DEBUG - 2011-08-30 11:23:34 --> Hooks Class Initialized
DEBUG - 2011-08-30 11:23:34 --> Utf8 Class Initialized
DEBUG - 2011-08-30 11:23:34 --> UTF-8 Support Enabled
DEBUG - 2011-08-30 11:23:34 --> URI Class Initialized
DEBUG - 2011-08-30 11:23:34 --> Router Class Initialized
DEBUG - 2011-08-30 11:23:34 --> Output Class Initialized
DEBUG - 2011-08-30 11:23:34 --> Input Class Initialized
DEBUG - 2011-08-30 11:23:34 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-30 11:23:34 --> Language Class Initialized
DEBUG - 2011-08-30 11:23:34 --> Loader Class Initialized
DEBUG - 2011-08-30 11:23:34 --> Controller Class Initialized
DEBUG - 2011-08-30 11:23:34 --> Model Class Initialized
DEBUG - 2011-08-30 11:23:34 --> Model Class Initialized
DEBUG - 2011-08-30 11:23:34 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-30 11:23:34 --> Database Driver Class Initialized
DEBUG - 2011-08-30 11:23:34 --> Final output sent to browser
DEBUG - 2011-08-30 11:23:34 --> Total execution time: 0.6150
DEBUG - 2011-08-30 11:23:36 --> Config Class Initialized
DEBUG - 2011-08-30 11:23:36 --> Hooks Class Initialized
DEBUG - 2011-08-30 11:23:36 --> Utf8 Class Initialized
DEBUG - 2011-08-30 11:23:36 --> UTF-8 Support Enabled
DEBUG - 2011-08-30 11:23:36 --> URI Class Initialized
DEBUG - 2011-08-30 11:23:36 --> Router Class Initialized
ERROR - 2011-08-30 11:23:36 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-08-30 11:23:44 --> Config Class Initialized
DEBUG - 2011-08-30 11:23:44 --> Hooks Class Initialized
DEBUG - 2011-08-30 11:23:44 --> Utf8 Class Initialized
DEBUG - 2011-08-30 11:23:44 --> UTF-8 Support Enabled
DEBUG - 2011-08-30 11:23:44 --> URI Class Initialized
DEBUG - 2011-08-30 11:23:44 --> Router Class Initialized
DEBUG - 2011-08-30 11:23:44 --> Output Class Initialized
DEBUG - 2011-08-30 11:23:44 --> Input Class Initialized
DEBUG - 2011-08-30 11:23:44 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-30 11:23:44 --> Language Class Initialized
DEBUG - 2011-08-30 11:23:44 --> Loader Class Initialized
DEBUG - 2011-08-30 11:23:44 --> Controller Class Initialized
ERROR - 2011-08-30 11:23:44 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-08-30 11:23:44 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-08-30 11:23:44 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-08-30 11:23:44 --> Model Class Initialized
DEBUG - 2011-08-30 11:23:44 --> Model Class Initialized
DEBUG - 2011-08-30 11:23:44 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-30 11:23:44 --> Database Driver Class Initialized
DEBUG - 2011-08-30 11:23:44 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-08-30 11:23:44 --> Helper loaded: url_helper
DEBUG - 2011-08-30 11:23:44 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-30 11:23:44 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-30 11:23:44 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-30 11:23:44 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-30 11:23:44 --> Final output sent to browser
DEBUG - 2011-08-30 11:23:44 --> Total execution time: 0.0462
DEBUG - 2011-08-30 11:23:45 --> Config Class Initialized
DEBUG - 2011-08-30 11:23:45 --> Hooks Class Initialized
DEBUG - 2011-08-30 11:23:45 --> Utf8 Class Initialized
DEBUG - 2011-08-30 11:23:45 --> UTF-8 Support Enabled
DEBUG - 2011-08-30 11:23:45 --> URI Class Initialized
DEBUG - 2011-08-30 11:23:45 --> Router Class Initialized
DEBUG - 2011-08-30 11:23:45 --> Output Class Initialized
DEBUG - 2011-08-30 11:23:45 --> Input Class Initialized
DEBUG - 2011-08-30 11:23:45 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-30 11:23:45 --> Language Class Initialized
DEBUG - 2011-08-30 11:23:45 --> Loader Class Initialized
DEBUG - 2011-08-30 11:23:45 --> Controller Class Initialized
DEBUG - 2011-08-30 11:23:45 --> Model Class Initialized
DEBUG - 2011-08-30 11:23:45 --> Model Class Initialized
DEBUG - 2011-08-30 11:23:45 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-30 11:23:45 --> Database Driver Class Initialized
DEBUG - 2011-08-30 11:23:46 --> Final output sent to browser
DEBUG - 2011-08-30 11:23:46 --> Total execution time: 0.5351
DEBUG - 2011-08-30 11:23:47 --> Config Class Initialized
DEBUG - 2011-08-30 11:23:47 --> Hooks Class Initialized
DEBUG - 2011-08-30 11:23:47 --> Utf8 Class Initialized
DEBUG - 2011-08-30 11:23:47 --> UTF-8 Support Enabled
DEBUG - 2011-08-30 11:23:47 --> URI Class Initialized
DEBUG - 2011-08-30 11:23:47 --> Router Class Initialized
ERROR - 2011-08-30 11:23:47 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-08-30 11:24:27 --> Config Class Initialized
DEBUG - 2011-08-30 11:24:27 --> Hooks Class Initialized
DEBUG - 2011-08-30 11:24:27 --> Utf8 Class Initialized
DEBUG - 2011-08-30 11:24:27 --> UTF-8 Support Enabled
DEBUG - 2011-08-30 11:24:27 --> URI Class Initialized
DEBUG - 2011-08-30 11:24:27 --> Router Class Initialized
ERROR - 2011-08-30 11:24:27 --> 404 Page Not Found --> robots.txt
DEBUG - 2011-08-30 11:36:35 --> Config Class Initialized
DEBUG - 2011-08-30 11:36:35 --> Hooks Class Initialized
DEBUG - 2011-08-30 11:36:35 --> Utf8 Class Initialized
DEBUG - 2011-08-30 11:36:35 --> UTF-8 Support Enabled
DEBUG - 2011-08-30 11:36:35 --> URI Class Initialized
DEBUG - 2011-08-30 11:36:35 --> Router Class Initialized
DEBUG - 2011-08-30 11:36:35 --> Output Class Initialized
DEBUG - 2011-08-30 11:36:35 --> Input Class Initialized
DEBUG - 2011-08-30 11:36:35 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-30 11:36:35 --> Language Class Initialized
DEBUG - 2011-08-30 11:36:35 --> Loader Class Initialized
DEBUG - 2011-08-30 11:36:35 --> Controller Class Initialized
DEBUG - 2011-08-30 11:36:35 --> Model Class Initialized
DEBUG - 2011-08-30 11:36:35 --> Model Class Initialized
DEBUG - 2011-08-30 11:36:35 --> Model Class Initialized
DEBUG - 2011-08-30 11:36:35 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-30 11:36:35 --> Database Driver Class Initialized
DEBUG - 2011-08-30 11:36:35 --> File loaded: application/views/table/main.php
DEBUG - 2011-08-30 11:36:35 --> Helper loaded: url_helper
DEBUG - 2011-08-30 11:36:35 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-30 11:36:35 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-30 11:36:35 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-30 11:36:35 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-30 11:36:35 --> Final output sent to browser
DEBUG - 2011-08-30 11:36:35 --> Total execution time: 0.2790
DEBUG - 2011-08-30 11:36:37 --> Config Class Initialized
DEBUG - 2011-08-30 11:36:37 --> Hooks Class Initialized
DEBUG - 2011-08-30 11:36:37 --> Utf8 Class Initialized
DEBUG - 2011-08-30 11:36:37 --> UTF-8 Support Enabled
DEBUG - 2011-08-30 11:36:37 --> URI Class Initialized
DEBUG - 2011-08-30 11:36:37 --> Router Class Initialized
ERROR - 2011-08-30 11:36:37 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-08-30 11:44:34 --> Config Class Initialized
DEBUG - 2011-08-30 11:44:34 --> Hooks Class Initialized
DEBUG - 2011-08-30 11:44:34 --> Utf8 Class Initialized
DEBUG - 2011-08-30 11:44:34 --> UTF-8 Support Enabled
DEBUG - 2011-08-30 11:44:34 --> URI Class Initialized
DEBUG - 2011-08-30 11:44:34 --> Router Class Initialized
DEBUG - 2011-08-30 11:44:34 --> Output Class Initialized
DEBUG - 2011-08-30 11:44:34 --> Input Class Initialized
DEBUG - 2011-08-30 11:44:34 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-30 11:44:34 --> Language Class Initialized
DEBUG - 2011-08-30 11:44:34 --> Loader Class Initialized
DEBUG - 2011-08-30 11:44:34 --> Controller Class Initialized
ERROR - 2011-08-30 11:44:34 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-08-30 11:44:34 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-08-30 11:44:34 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-08-30 11:44:34 --> Model Class Initialized
DEBUG - 2011-08-30 11:44:34 --> Model Class Initialized
DEBUG - 2011-08-30 11:44:34 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-30 11:44:34 --> Database Driver Class Initialized
DEBUG - 2011-08-30 11:44:34 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-08-30 11:44:34 --> Helper loaded: url_helper
DEBUG - 2011-08-30 11:44:34 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-30 11:44:34 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-30 11:44:34 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-30 11:44:34 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-30 11:44:34 --> Final output sent to browser
DEBUG - 2011-08-30 11:44:34 --> Total execution time: 0.0509
DEBUG - 2011-08-30 11:44:35 --> Config Class Initialized
DEBUG - 2011-08-30 11:44:35 --> Hooks Class Initialized
DEBUG - 2011-08-30 11:44:35 --> Utf8 Class Initialized
DEBUG - 2011-08-30 11:44:35 --> UTF-8 Support Enabled
DEBUG - 2011-08-30 11:44:35 --> URI Class Initialized
DEBUG - 2011-08-30 11:44:35 --> Router Class Initialized
DEBUG - 2011-08-30 11:44:35 --> Output Class Initialized
DEBUG - 2011-08-30 11:44:35 --> Input Class Initialized
DEBUG - 2011-08-30 11:44:35 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-30 11:44:35 --> Language Class Initialized
DEBUG - 2011-08-30 11:44:35 --> Loader Class Initialized
DEBUG - 2011-08-30 11:44:35 --> Controller Class Initialized
DEBUG - 2011-08-30 11:44:35 --> Model Class Initialized
DEBUG - 2011-08-30 11:44:35 --> Model Class Initialized
DEBUG - 2011-08-30 11:44:35 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-30 11:44:35 --> Database Driver Class Initialized
DEBUG - 2011-08-30 11:44:36 --> Final output sent to browser
DEBUG - 2011-08-30 11:44:36 --> Total execution time: 0.6622
DEBUG - 2011-08-30 11:44:37 --> Config Class Initialized
DEBUG - 2011-08-30 11:44:37 --> Hooks Class Initialized
DEBUG - 2011-08-30 11:44:37 --> Utf8 Class Initialized
DEBUG - 2011-08-30 11:44:37 --> UTF-8 Support Enabled
DEBUG - 2011-08-30 11:44:37 --> URI Class Initialized
DEBUG - 2011-08-30 11:44:37 --> Router Class Initialized
ERROR - 2011-08-30 11:44:37 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-08-30 11:44:51 --> Config Class Initialized
DEBUG - 2011-08-30 11:44:51 --> Hooks Class Initialized
DEBUG - 2011-08-30 11:44:51 --> Utf8 Class Initialized
DEBUG - 2011-08-30 11:44:51 --> UTF-8 Support Enabled
DEBUG - 2011-08-30 11:44:51 --> URI Class Initialized
DEBUG - 2011-08-30 11:44:51 --> Router Class Initialized
DEBUG - 2011-08-30 11:44:51 --> Output Class Initialized
DEBUG - 2011-08-30 11:44:51 --> Input Class Initialized
DEBUG - 2011-08-30 11:44:51 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-30 11:44:51 --> Language Class Initialized
DEBUG - 2011-08-30 11:44:51 --> Loader Class Initialized
DEBUG - 2011-08-30 11:44:51 --> Controller Class Initialized
ERROR - 2011-08-30 11:44:51 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-08-30 11:44:51 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-08-30 11:44:51 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-08-30 11:44:51 --> Model Class Initialized
DEBUG - 2011-08-30 11:44:51 --> Model Class Initialized
DEBUG - 2011-08-30 11:44:51 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-30 11:44:51 --> Database Driver Class Initialized
DEBUG - 2011-08-30 11:44:51 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-08-30 11:44:51 --> Helper loaded: url_helper
DEBUG - 2011-08-30 11:44:51 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-30 11:44:51 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-30 11:44:51 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-30 11:44:51 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-30 11:44:51 --> Final output sent to browser
DEBUG - 2011-08-30 11:44:51 --> Total execution time: 0.0274
DEBUG - 2011-08-30 11:44:52 --> Config Class Initialized
DEBUG - 2011-08-30 11:44:52 --> Hooks Class Initialized
DEBUG - 2011-08-30 11:44:52 --> Utf8 Class Initialized
DEBUG - 2011-08-30 11:44:52 --> UTF-8 Support Enabled
DEBUG - 2011-08-30 11:44:52 --> URI Class Initialized
DEBUG - 2011-08-30 11:44:52 --> Router Class Initialized
DEBUG - 2011-08-30 11:44:52 --> Output Class Initialized
DEBUG - 2011-08-30 11:44:52 --> Input Class Initialized
DEBUG - 2011-08-30 11:44:52 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-30 11:44:52 --> Language Class Initialized
DEBUG - 2011-08-30 11:44:52 --> Loader Class Initialized
DEBUG - 2011-08-30 11:44:52 --> Controller Class Initialized
DEBUG - 2011-08-30 11:44:52 --> Model Class Initialized
DEBUG - 2011-08-30 11:44:52 --> Model Class Initialized
DEBUG - 2011-08-30 11:44:52 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-30 11:44:52 --> Database Driver Class Initialized
DEBUG - 2011-08-30 11:44:52 --> Final output sent to browser
DEBUG - 2011-08-30 11:44:52 --> Total execution time: 0.5959
DEBUG - 2011-08-30 11:44:54 --> Config Class Initialized
DEBUG - 2011-08-30 11:44:54 --> Hooks Class Initialized
DEBUG - 2011-08-30 11:44:54 --> Utf8 Class Initialized
DEBUG - 2011-08-30 11:44:54 --> UTF-8 Support Enabled
DEBUG - 2011-08-30 11:44:54 --> URI Class Initialized
DEBUG - 2011-08-30 11:44:54 --> Router Class Initialized
ERROR - 2011-08-30 11:44:54 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-08-30 12:01:41 --> Config Class Initialized
DEBUG - 2011-08-30 12:01:41 --> Hooks Class Initialized
DEBUG - 2011-08-30 12:01:41 --> Utf8 Class Initialized
DEBUG - 2011-08-30 12:01:41 --> UTF-8 Support Enabled
DEBUG - 2011-08-30 12:01:41 --> URI Class Initialized
DEBUG - 2011-08-30 12:01:41 --> Router Class Initialized
DEBUG - 2011-08-30 12:01:41 --> Output Class Initialized
DEBUG - 2011-08-30 12:01:41 --> Input Class Initialized
DEBUG - 2011-08-30 12:01:41 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-30 12:01:41 --> Language Class Initialized
DEBUG - 2011-08-30 12:01:41 --> Loader Class Initialized
DEBUG - 2011-08-30 12:01:41 --> Controller Class Initialized
DEBUG - 2011-08-30 12:01:41 --> Model Class Initialized
DEBUG - 2011-08-30 12:01:41 --> Model Class Initialized
DEBUG - 2011-08-30 12:01:41 --> Model Class Initialized
DEBUG - 2011-08-30 12:01:41 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-30 12:01:41 --> Database Driver Class Initialized
DEBUG - 2011-08-30 12:01:42 --> File loaded: application/views/table/main.php
DEBUG - 2011-08-30 12:01:42 --> Helper loaded: url_helper
DEBUG - 2011-08-30 12:01:42 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-30 12:01:42 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-30 12:01:42 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-30 12:01:42 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-30 12:01:42 --> Final output sent to browser
DEBUG - 2011-08-30 12:01:42 --> Total execution time: 0.3963
DEBUG - 2011-08-30 12:01:43 --> Config Class Initialized
DEBUG - 2011-08-30 12:01:43 --> Hooks Class Initialized
DEBUG - 2011-08-30 12:01:43 --> Utf8 Class Initialized
DEBUG - 2011-08-30 12:01:43 --> UTF-8 Support Enabled
DEBUG - 2011-08-30 12:01:43 --> URI Class Initialized
DEBUG - 2011-08-30 12:01:43 --> Router Class Initialized
ERROR - 2011-08-30 12:01:43 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-08-30 12:01:43 --> Config Class Initialized
DEBUG - 2011-08-30 12:01:43 --> Hooks Class Initialized
DEBUG - 2011-08-30 12:01:43 --> Utf8 Class Initialized
DEBUG - 2011-08-30 12:01:43 --> UTF-8 Support Enabled
DEBUG - 2011-08-30 12:01:43 --> URI Class Initialized
DEBUG - 2011-08-30 12:01:43 --> Router Class Initialized
ERROR - 2011-08-30 12:01:43 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-08-30 12:01:50 --> Config Class Initialized
DEBUG - 2011-08-30 12:01:50 --> Hooks Class Initialized
DEBUG - 2011-08-30 12:01:50 --> Utf8 Class Initialized
DEBUG - 2011-08-30 12:01:50 --> UTF-8 Support Enabled
DEBUG - 2011-08-30 12:01:50 --> URI Class Initialized
DEBUG - 2011-08-30 12:01:50 --> Router Class Initialized
DEBUG - 2011-08-30 12:01:50 --> Output Class Initialized
DEBUG - 2011-08-30 12:01:50 --> Input Class Initialized
DEBUG - 2011-08-30 12:01:50 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-30 12:01:50 --> Language Class Initialized
DEBUG - 2011-08-30 12:01:50 --> Loader Class Initialized
DEBUG - 2011-08-30 12:01:50 --> Controller Class Initialized
DEBUG - 2011-08-30 12:01:50 --> Model Class Initialized
DEBUG - 2011-08-30 12:01:50 --> Model Class Initialized
DEBUG - 2011-08-30 12:01:50 --> Model Class Initialized
DEBUG - 2011-08-30 12:01:50 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-30 12:01:50 --> Database Driver Class Initialized
DEBUG - 2011-08-30 12:01:50 --> File loaded: application/views/table/main.php
DEBUG - 2011-08-30 12:01:50 --> Helper loaded: url_helper
DEBUG - 2011-08-30 12:01:50 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-30 12:01:50 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-30 12:01:50 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-30 12:01:50 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-30 12:01:50 --> Final output sent to browser
DEBUG - 2011-08-30 12:01:50 --> Total execution time: 0.2910
DEBUG - 2011-08-30 12:02:29 --> Config Class Initialized
DEBUG - 2011-08-30 12:02:29 --> Hooks Class Initialized
DEBUG - 2011-08-30 12:02:29 --> Utf8 Class Initialized
DEBUG - 2011-08-30 12:02:29 --> UTF-8 Support Enabled
DEBUG - 2011-08-30 12:02:29 --> URI Class Initialized
DEBUG - 2011-08-30 12:02:29 --> Router Class Initialized
DEBUG - 2011-08-30 12:02:29 --> Output Class Initialized
DEBUG - 2011-08-30 12:02:29 --> Input Class Initialized
DEBUG - 2011-08-30 12:02:29 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-30 12:02:29 --> Language Class Initialized
DEBUG - 2011-08-30 12:02:29 --> Loader Class Initialized
DEBUG - 2011-08-30 12:02:29 --> Controller Class Initialized
DEBUG - 2011-08-30 12:02:29 --> Model Class Initialized
DEBUG - 2011-08-30 12:02:29 --> Model Class Initialized
DEBUG - 2011-08-30 12:02:29 --> Model Class Initialized
DEBUG - 2011-08-30 12:02:29 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-30 12:02:29 --> Database Driver Class Initialized
DEBUG - 2011-08-30 12:02:29 --> File loaded: application/views/table/main.php
DEBUG - 2011-08-30 12:02:29 --> Helper loaded: url_helper
DEBUG - 2011-08-30 12:02:29 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-30 12:02:29 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-30 12:02:29 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-30 12:02:29 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-30 12:02:29 --> Final output sent to browser
DEBUG - 2011-08-30 12:02:29 --> Total execution time: 0.5371
DEBUG - 2011-08-30 12:02:44 --> Config Class Initialized
DEBUG - 2011-08-30 12:02:44 --> Hooks Class Initialized
DEBUG - 2011-08-30 12:02:44 --> Utf8 Class Initialized
DEBUG - 2011-08-30 12:02:44 --> UTF-8 Support Enabled
DEBUG - 2011-08-30 12:02:44 --> URI Class Initialized
DEBUG - 2011-08-30 12:02:44 --> Router Class Initialized
DEBUG - 2011-08-30 12:02:44 --> Output Class Initialized
DEBUG - 2011-08-30 12:02:44 --> Input Class Initialized
DEBUG - 2011-08-30 12:02:44 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-30 12:02:44 --> Language Class Initialized
DEBUG - 2011-08-30 12:02:44 --> Loader Class Initialized
DEBUG - 2011-08-30 12:02:44 --> Controller Class Initialized
DEBUG - 2011-08-30 12:02:44 --> Model Class Initialized
DEBUG - 2011-08-30 12:02:44 --> Model Class Initialized
DEBUG - 2011-08-30 12:02:44 --> Model Class Initialized
DEBUG - 2011-08-30 12:02:44 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-30 12:02:44 --> Database Driver Class Initialized
DEBUG - 2011-08-30 12:02:44 --> File loaded: application/views/table/main.php
DEBUG - 2011-08-30 12:02:44 --> Helper loaded: url_helper
DEBUG - 2011-08-30 12:02:44 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-30 12:02:44 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-30 12:02:44 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-30 12:02:44 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-30 12:02:44 --> Final output sent to browser
DEBUG - 2011-08-30 12:02:44 --> Total execution time: 0.1779
DEBUG - 2011-08-30 12:02:51 --> Config Class Initialized
DEBUG - 2011-08-30 12:02:51 --> Hooks Class Initialized
DEBUG - 2011-08-30 12:02:51 --> Utf8 Class Initialized
DEBUG - 2011-08-30 12:02:51 --> UTF-8 Support Enabled
DEBUG - 2011-08-30 12:02:51 --> URI Class Initialized
DEBUG - 2011-08-30 12:02:51 --> Router Class Initialized
DEBUG - 2011-08-30 12:02:51 --> Output Class Initialized
DEBUG - 2011-08-30 12:02:51 --> Input Class Initialized
DEBUG - 2011-08-30 12:02:51 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-30 12:02:51 --> Language Class Initialized
DEBUG - 2011-08-30 12:02:51 --> Loader Class Initialized
DEBUG - 2011-08-30 12:02:51 --> Controller Class Initialized
DEBUG - 2011-08-30 12:02:51 --> Model Class Initialized
DEBUG - 2011-08-30 12:02:51 --> Model Class Initialized
DEBUG - 2011-08-30 12:02:51 --> Model Class Initialized
DEBUG - 2011-08-30 12:02:51 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-30 12:02:51 --> Database Driver Class Initialized
DEBUG - 2011-08-30 12:02:51 --> File loaded: application/views/table/main.php
DEBUG - 2011-08-30 12:02:51 --> Helper loaded: url_helper
DEBUG - 2011-08-30 12:02:51 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-30 12:02:51 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-30 12:02:51 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-30 12:02:51 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-30 12:02:51 --> Final output sent to browser
DEBUG - 2011-08-30 12:02:51 --> Total execution time: 0.2070
DEBUG - 2011-08-30 12:03:06 --> Config Class Initialized
DEBUG - 2011-08-30 12:03:06 --> Hooks Class Initialized
DEBUG - 2011-08-30 12:03:06 --> Utf8 Class Initialized
DEBUG - 2011-08-30 12:03:06 --> UTF-8 Support Enabled
DEBUG - 2011-08-30 12:03:06 --> URI Class Initialized
DEBUG - 2011-08-30 12:03:06 --> Router Class Initialized
DEBUG - 2011-08-30 12:03:06 --> Output Class Initialized
DEBUG - 2011-08-30 12:03:06 --> Input Class Initialized
DEBUG - 2011-08-30 12:03:06 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-30 12:03:06 --> Language Class Initialized
DEBUG - 2011-08-30 12:03:06 --> Loader Class Initialized
DEBUG - 2011-08-30 12:03:06 --> Controller Class Initialized
DEBUG - 2011-08-30 12:03:06 --> Model Class Initialized
DEBUG - 2011-08-30 12:03:06 --> Model Class Initialized
DEBUG - 2011-08-30 12:03:06 --> Model Class Initialized
DEBUG - 2011-08-30 12:03:06 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-30 12:03:06 --> Database Driver Class Initialized
DEBUG - 2011-08-30 12:03:07 --> File loaded: application/views/table/main.php
DEBUG - 2011-08-30 12:03:07 --> Helper loaded: url_helper
DEBUG - 2011-08-30 12:03:07 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-30 12:03:07 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-30 12:03:07 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-30 12:03:07 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-30 12:03:07 --> Final output sent to browser
DEBUG - 2011-08-30 12:03:07 --> Total execution time: 0.7226
DEBUG - 2011-08-30 12:03:22 --> Config Class Initialized
DEBUG - 2011-08-30 12:03:22 --> Hooks Class Initialized
DEBUG - 2011-08-30 12:03:22 --> Utf8 Class Initialized
DEBUG - 2011-08-30 12:03:22 --> UTF-8 Support Enabled
DEBUG - 2011-08-30 12:03:22 --> URI Class Initialized
DEBUG - 2011-08-30 12:03:22 --> Router Class Initialized
DEBUG - 2011-08-30 12:03:22 --> Output Class Initialized
DEBUG - 2011-08-30 12:03:22 --> Input Class Initialized
DEBUG - 2011-08-30 12:03:22 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-30 12:03:22 --> Language Class Initialized
DEBUG - 2011-08-30 12:03:22 --> Loader Class Initialized
DEBUG - 2011-08-30 12:03:22 --> Controller Class Initialized
DEBUG - 2011-08-30 12:03:22 --> Model Class Initialized
DEBUG - 2011-08-30 12:03:22 --> Model Class Initialized
DEBUG - 2011-08-30 12:03:22 --> Model Class Initialized
DEBUG - 2011-08-30 12:03:22 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-30 12:03:22 --> Database Driver Class Initialized
DEBUG - 2011-08-30 12:03:22 --> File loaded: application/views/table/main.php
DEBUG - 2011-08-30 12:03:22 --> Helper loaded: url_helper
DEBUG - 2011-08-30 12:03:22 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-30 12:03:22 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-30 12:03:22 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-30 12:03:22 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-30 12:03:22 --> Final output sent to browser
DEBUG - 2011-08-30 12:03:22 --> Total execution time: 0.2857
DEBUG - 2011-08-30 12:03:38 --> Config Class Initialized
DEBUG - 2011-08-30 12:03:38 --> Hooks Class Initialized
DEBUG - 2011-08-30 12:03:38 --> Utf8 Class Initialized
DEBUG - 2011-08-30 12:03:38 --> UTF-8 Support Enabled
DEBUG - 2011-08-30 12:03:38 --> URI Class Initialized
DEBUG - 2011-08-30 12:03:38 --> Router Class Initialized
DEBUG - 2011-08-30 12:03:38 --> Output Class Initialized
DEBUG - 2011-08-30 12:03:38 --> Input Class Initialized
DEBUG - 2011-08-30 12:03:38 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-30 12:03:38 --> Language Class Initialized
DEBUG - 2011-08-30 12:03:38 --> Loader Class Initialized
DEBUG - 2011-08-30 12:03:38 --> Controller Class Initialized
DEBUG - 2011-08-30 12:03:38 --> Model Class Initialized
DEBUG - 2011-08-30 12:03:38 --> Model Class Initialized
DEBUG - 2011-08-30 12:03:38 --> Model Class Initialized
DEBUG - 2011-08-30 12:03:38 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-30 12:03:38 --> Database Driver Class Initialized
DEBUG - 2011-08-30 12:03:38 --> File loaded: application/views/table/main.php
DEBUG - 2011-08-30 12:03:38 --> Helper loaded: url_helper
DEBUG - 2011-08-30 12:03:38 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-30 12:03:38 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-30 12:03:38 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-30 12:03:38 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-30 12:03:38 --> Final output sent to browser
DEBUG - 2011-08-30 12:03:38 --> Total execution time: 0.3170
DEBUG - 2011-08-30 12:03:57 --> Config Class Initialized
DEBUG - 2011-08-30 12:03:57 --> Hooks Class Initialized
DEBUG - 2011-08-30 12:03:57 --> Utf8 Class Initialized
DEBUG - 2011-08-30 12:03:57 --> UTF-8 Support Enabled
DEBUG - 2011-08-30 12:03:57 --> URI Class Initialized
DEBUG - 2011-08-30 12:03:57 --> Router Class Initialized
DEBUG - 2011-08-30 12:03:57 --> Output Class Initialized
DEBUG - 2011-08-30 12:03:57 --> Input Class Initialized
DEBUG - 2011-08-30 12:03:57 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-30 12:03:57 --> Language Class Initialized
DEBUG - 2011-08-30 12:03:57 --> Loader Class Initialized
DEBUG - 2011-08-30 12:03:57 --> Controller Class Initialized
DEBUG - 2011-08-30 12:03:57 --> Model Class Initialized
DEBUG - 2011-08-30 12:03:57 --> Model Class Initialized
DEBUG - 2011-08-30 12:03:57 --> Model Class Initialized
DEBUG - 2011-08-30 12:03:57 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-30 12:03:57 --> Database Driver Class Initialized
DEBUG - 2011-08-30 12:03:58 --> File loaded: application/views/table/main.php
DEBUG - 2011-08-30 12:03:58 --> Helper loaded: url_helper
DEBUG - 2011-08-30 12:03:58 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-30 12:03:58 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-30 12:03:58 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-30 12:03:58 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-30 12:03:58 --> Final output sent to browser
DEBUG - 2011-08-30 12:03:58 --> Total execution time: 0.3652
DEBUG - 2011-08-30 12:04:15 --> Config Class Initialized
DEBUG - 2011-08-30 12:04:15 --> Hooks Class Initialized
DEBUG - 2011-08-30 12:04:15 --> Utf8 Class Initialized
DEBUG - 2011-08-30 12:04:15 --> UTF-8 Support Enabled
DEBUG - 2011-08-30 12:04:15 --> URI Class Initialized
DEBUG - 2011-08-30 12:04:15 --> Router Class Initialized
DEBUG - 2011-08-30 12:04:15 --> Output Class Initialized
DEBUG - 2011-08-30 12:04:15 --> Input Class Initialized
DEBUG - 2011-08-30 12:04:15 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-30 12:04:15 --> Language Class Initialized
DEBUG - 2011-08-30 12:04:15 --> Loader Class Initialized
DEBUG - 2011-08-30 12:04:15 --> Controller Class Initialized
DEBUG - 2011-08-30 12:04:15 --> Model Class Initialized
DEBUG - 2011-08-30 12:04:15 --> Model Class Initialized
DEBUG - 2011-08-30 12:04:15 --> Model Class Initialized
DEBUG - 2011-08-30 12:04:15 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-30 12:04:15 --> Database Driver Class Initialized
DEBUG - 2011-08-30 12:04:15 --> File loaded: application/views/table/main.php
DEBUG - 2011-08-30 12:04:15 --> Helper loaded: url_helper
DEBUG - 2011-08-30 12:04:15 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-30 12:04:15 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-30 12:04:15 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-30 12:04:15 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-30 12:04:15 --> Final output sent to browser
DEBUG - 2011-08-30 12:04:15 --> Total execution time: 0.3089
DEBUG - 2011-08-30 12:04:25 --> Config Class Initialized
DEBUG - 2011-08-30 12:04:25 --> Hooks Class Initialized
DEBUG - 2011-08-30 12:04:25 --> Utf8 Class Initialized
DEBUG - 2011-08-30 12:04:25 --> UTF-8 Support Enabled
DEBUG - 2011-08-30 12:04:25 --> URI Class Initialized
DEBUG - 2011-08-30 12:04:25 --> Router Class Initialized
DEBUG - 2011-08-30 12:04:25 --> Output Class Initialized
DEBUG - 2011-08-30 12:04:25 --> Input Class Initialized
DEBUG - 2011-08-30 12:04:25 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-30 12:04:25 --> Language Class Initialized
DEBUG - 2011-08-30 12:04:25 --> Loader Class Initialized
DEBUG - 2011-08-30 12:04:25 --> Controller Class Initialized
DEBUG - 2011-08-30 12:04:25 --> Model Class Initialized
DEBUG - 2011-08-30 12:04:25 --> Model Class Initialized
DEBUG - 2011-08-30 12:04:25 --> Model Class Initialized
DEBUG - 2011-08-30 12:04:25 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-30 12:04:25 --> Database Driver Class Initialized
DEBUG - 2011-08-30 12:04:25 --> File loaded: application/views/table/main.php
DEBUG - 2011-08-30 12:04:25 --> Helper loaded: url_helper
DEBUG - 2011-08-30 12:04:25 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-30 12:04:25 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-30 12:04:25 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-30 12:04:25 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-30 12:04:25 --> Final output sent to browser
DEBUG - 2011-08-30 12:04:25 --> Total execution time: 0.3058
DEBUG - 2011-08-30 12:04:35 --> Config Class Initialized
DEBUG - 2011-08-30 12:04:35 --> Hooks Class Initialized
DEBUG - 2011-08-30 12:04:35 --> Utf8 Class Initialized
DEBUG - 2011-08-30 12:04:35 --> UTF-8 Support Enabled
DEBUG - 2011-08-30 12:04:35 --> URI Class Initialized
DEBUG - 2011-08-30 12:04:35 --> Router Class Initialized
DEBUG - 2011-08-30 12:04:35 --> Output Class Initialized
DEBUG - 2011-08-30 12:04:35 --> Input Class Initialized
DEBUG - 2011-08-30 12:04:35 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-30 12:04:35 --> Language Class Initialized
DEBUG - 2011-08-30 12:04:35 --> Loader Class Initialized
DEBUG - 2011-08-30 12:04:35 --> Controller Class Initialized
DEBUG - 2011-08-30 12:04:35 --> Model Class Initialized
DEBUG - 2011-08-30 12:04:35 --> Model Class Initialized
DEBUG - 2011-08-30 12:04:35 --> Model Class Initialized
DEBUG - 2011-08-30 12:04:35 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-30 12:04:35 --> Database Driver Class Initialized
DEBUG - 2011-08-30 12:04:35 --> File loaded: application/views/table/main.php
DEBUG - 2011-08-30 12:04:35 --> Helper loaded: url_helper
DEBUG - 2011-08-30 12:04:35 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-30 12:04:35 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-30 12:04:35 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-30 12:04:35 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-30 12:04:35 --> Final output sent to browser
DEBUG - 2011-08-30 12:04:35 --> Total execution time: 0.2471
DEBUG - 2011-08-30 12:05:35 --> Config Class Initialized
DEBUG - 2011-08-30 12:05:35 --> Hooks Class Initialized
DEBUG - 2011-08-30 12:05:35 --> Utf8 Class Initialized
DEBUG - 2011-08-30 12:05:35 --> UTF-8 Support Enabled
DEBUG - 2011-08-30 12:05:35 --> URI Class Initialized
DEBUG - 2011-08-30 12:05:35 --> Router Class Initialized
DEBUG - 2011-08-30 12:05:35 --> Output Class Initialized
DEBUG - 2011-08-30 12:05:35 --> Input Class Initialized
DEBUG - 2011-08-30 12:05:35 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-30 12:05:35 --> Language Class Initialized
DEBUG - 2011-08-30 12:05:35 --> Loader Class Initialized
DEBUG - 2011-08-30 12:05:35 --> Controller Class Initialized
DEBUG - 2011-08-30 12:05:35 --> Model Class Initialized
DEBUG - 2011-08-30 12:05:35 --> Model Class Initialized
DEBUG - 2011-08-30 12:05:35 --> Model Class Initialized
DEBUG - 2011-08-30 12:05:35 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-30 12:05:35 --> Database Driver Class Initialized
DEBUG - 2011-08-30 12:05:35 --> File loaded: application/views/table/main.php
DEBUG - 2011-08-30 12:05:35 --> Helper loaded: url_helper
DEBUG - 2011-08-30 12:05:35 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-30 12:05:35 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-30 12:05:35 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-30 12:05:35 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-30 12:05:35 --> Final output sent to browser
DEBUG - 2011-08-30 12:05:35 --> Total execution time: 0.1831
DEBUG - 2011-08-30 12:06:04 --> Config Class Initialized
DEBUG - 2011-08-30 12:06:04 --> Hooks Class Initialized
DEBUG - 2011-08-30 12:06:04 --> Utf8 Class Initialized
DEBUG - 2011-08-30 12:06:04 --> UTF-8 Support Enabled
DEBUG - 2011-08-30 12:06:04 --> URI Class Initialized
DEBUG - 2011-08-30 12:06:04 --> Router Class Initialized
DEBUG - 2011-08-30 12:06:04 --> Output Class Initialized
DEBUG - 2011-08-30 12:06:04 --> Input Class Initialized
DEBUG - 2011-08-30 12:06:04 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-30 12:06:04 --> Language Class Initialized
DEBUG - 2011-08-30 12:06:04 --> Loader Class Initialized
DEBUG - 2011-08-30 12:06:04 --> Controller Class Initialized
DEBUG - 2011-08-30 12:06:04 --> Model Class Initialized
DEBUG - 2011-08-30 12:06:04 --> Model Class Initialized
DEBUG - 2011-08-30 12:06:04 --> Model Class Initialized
DEBUG - 2011-08-30 12:06:04 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-30 12:06:04 --> Database Driver Class Initialized
DEBUG - 2011-08-30 12:06:04 --> File loaded: application/views/table/main.php
DEBUG - 2011-08-30 12:06:04 --> Helper loaded: url_helper
DEBUG - 2011-08-30 12:06:04 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-30 12:06:04 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-30 12:06:04 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-30 12:06:04 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-30 12:06:04 --> Final output sent to browser
DEBUG - 2011-08-30 12:06:04 --> Total execution time: 0.5731
DEBUG - 2011-08-30 12:06:13 --> Config Class Initialized
DEBUG - 2011-08-30 12:06:13 --> Hooks Class Initialized
DEBUG - 2011-08-30 12:06:13 --> Utf8 Class Initialized
DEBUG - 2011-08-30 12:06:13 --> UTF-8 Support Enabled
DEBUG - 2011-08-30 12:06:13 --> URI Class Initialized
DEBUG - 2011-08-30 12:06:13 --> Router Class Initialized
DEBUG - 2011-08-30 12:06:13 --> Output Class Initialized
DEBUG - 2011-08-30 12:06:13 --> Input Class Initialized
DEBUG - 2011-08-30 12:06:13 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-30 12:06:13 --> Language Class Initialized
DEBUG - 2011-08-30 12:06:13 --> Loader Class Initialized
DEBUG - 2011-08-30 12:06:13 --> Controller Class Initialized
DEBUG - 2011-08-30 12:06:13 --> Model Class Initialized
DEBUG - 2011-08-30 12:06:13 --> Model Class Initialized
DEBUG - 2011-08-30 12:06:13 --> Model Class Initialized
DEBUG - 2011-08-30 12:06:13 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-30 12:06:13 --> Database Driver Class Initialized
DEBUG - 2011-08-30 12:06:14 --> File loaded: application/views/table/main.php
DEBUG - 2011-08-30 12:06:14 --> Helper loaded: url_helper
DEBUG - 2011-08-30 12:06:14 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-30 12:06:14 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-30 12:06:14 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-30 12:06:14 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-30 12:06:14 --> Final output sent to browser
DEBUG - 2011-08-30 12:06:14 --> Total execution time: 0.3728
DEBUG - 2011-08-30 12:06:20 --> Config Class Initialized
DEBUG - 2011-08-30 12:06:20 --> Hooks Class Initialized
DEBUG - 2011-08-30 12:06:20 --> Utf8 Class Initialized
DEBUG - 2011-08-30 12:06:20 --> UTF-8 Support Enabled
DEBUG - 2011-08-30 12:06:20 --> URI Class Initialized
DEBUG - 2011-08-30 12:06:20 --> Router Class Initialized
DEBUG - 2011-08-30 12:06:20 --> Output Class Initialized
DEBUG - 2011-08-30 12:06:20 --> Input Class Initialized
DEBUG - 2011-08-30 12:06:20 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-30 12:06:20 --> Language Class Initialized
DEBUG - 2011-08-30 12:06:20 --> Loader Class Initialized
DEBUG - 2011-08-30 12:06:20 --> Controller Class Initialized
ERROR - 2011-08-30 12:06:20 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-08-30 12:06:20 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-08-30 12:06:20 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-08-30 12:06:20 --> Model Class Initialized
DEBUG - 2011-08-30 12:06:20 --> Model Class Initialized
DEBUG - 2011-08-30 12:06:20 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-30 12:06:20 --> Database Driver Class Initialized
DEBUG - 2011-08-30 12:06:20 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-08-30 12:06:20 --> Helper loaded: url_helper
DEBUG - 2011-08-30 12:06:20 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-30 12:06:20 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-30 12:06:20 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-30 12:06:20 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-30 12:06:20 --> Final output sent to browser
DEBUG - 2011-08-30 12:06:20 --> Total execution time: 0.0319
DEBUG - 2011-08-30 12:06:21 --> Config Class Initialized
DEBUG - 2011-08-30 12:06:21 --> Hooks Class Initialized
DEBUG - 2011-08-30 12:06:21 --> Utf8 Class Initialized
DEBUG - 2011-08-30 12:06:21 --> UTF-8 Support Enabled
DEBUG - 2011-08-30 12:06:21 --> URI Class Initialized
DEBUG - 2011-08-30 12:06:21 --> Router Class Initialized
DEBUG - 2011-08-30 12:06:21 --> Output Class Initialized
DEBUG - 2011-08-30 12:06:21 --> Input Class Initialized
DEBUG - 2011-08-30 12:06:21 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-30 12:06:21 --> Language Class Initialized
DEBUG - 2011-08-30 12:06:21 --> Loader Class Initialized
DEBUG - 2011-08-30 12:06:21 --> Controller Class Initialized
DEBUG - 2011-08-30 12:06:21 --> Model Class Initialized
DEBUG - 2011-08-30 12:06:21 --> Model Class Initialized
DEBUG - 2011-08-30 12:06:21 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-30 12:06:21 --> Database Driver Class Initialized
DEBUG - 2011-08-30 12:06:22 --> Final output sent to browser
DEBUG - 2011-08-30 12:06:22 --> Total execution time: 0.7271
DEBUG - 2011-08-30 12:06:22 --> Config Class Initialized
DEBUG - 2011-08-30 12:06:22 --> Hooks Class Initialized
DEBUG - 2011-08-30 12:06:22 --> Utf8 Class Initialized
DEBUG - 2011-08-30 12:06:22 --> UTF-8 Support Enabled
DEBUG - 2011-08-30 12:06:22 --> URI Class Initialized
DEBUG - 2011-08-30 12:06:22 --> Router Class Initialized
ERROR - 2011-08-30 12:06:22 --> 404 Page Not Found --> robots.txt
DEBUG - 2011-08-30 12:06:22 --> Config Class Initialized
DEBUG - 2011-08-30 12:06:22 --> Hooks Class Initialized
DEBUG - 2011-08-30 12:06:22 --> Utf8 Class Initialized
DEBUG - 2011-08-30 12:06:22 --> UTF-8 Support Enabled
DEBUG - 2011-08-30 12:06:22 --> URI Class Initialized
DEBUG - 2011-08-30 12:06:22 --> Router Class Initialized
DEBUG - 2011-08-30 12:06:22 --> Output Class Initialized
DEBUG - 2011-08-30 12:06:22 --> Input Class Initialized
DEBUG - 2011-08-30 12:06:22 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-30 12:06:22 --> Language Class Initialized
DEBUG - 2011-08-30 12:06:22 --> Loader Class Initialized
DEBUG - 2011-08-30 12:06:22 --> Controller Class Initialized
DEBUG - 2011-08-30 12:06:22 --> Model Class Initialized
DEBUG - 2011-08-30 12:06:22 --> Model Class Initialized
DEBUG - 2011-08-30 12:06:22 --> Model Class Initialized
DEBUG - 2011-08-30 12:06:22 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-30 12:06:22 --> Database Driver Class Initialized
DEBUG - 2011-08-30 12:06:22 --> Config Class Initialized
DEBUG - 2011-08-30 12:06:22 --> Hooks Class Initialized
DEBUG - 2011-08-30 12:06:22 --> Utf8 Class Initialized
DEBUG - 2011-08-30 12:06:22 --> UTF-8 Support Enabled
DEBUG - 2011-08-30 12:06:22 --> URI Class Initialized
DEBUG - 2011-08-30 12:06:22 --> Router Class Initialized
DEBUG - 2011-08-30 12:06:22 --> Output Class Initialized
DEBUG - 2011-08-30 12:06:22 --> Input Class Initialized
DEBUG - 2011-08-30 12:06:22 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-30 12:06:22 --> Language Class Initialized
DEBUG - 2011-08-30 12:06:22 --> Loader Class Initialized
DEBUG - 2011-08-30 12:06:22 --> Controller Class Initialized
ERROR - 2011-08-30 12:06:22 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-08-30 12:06:22 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-08-30 12:06:22 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-08-30 12:06:22 --> Model Class Initialized
DEBUG - 2011-08-30 12:06:22 --> Model Class Initialized
DEBUG - 2011-08-30 12:06:22 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-30 12:06:22 --> Database Driver Class Initialized
DEBUG - 2011-08-30 12:06:22 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-08-30 12:06:22 --> Helper loaded: url_helper
DEBUG - 2011-08-30 12:06:22 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-30 12:06:22 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-30 12:06:22 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-30 12:06:22 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-30 12:06:22 --> Final output sent to browser
DEBUG - 2011-08-30 12:06:22 --> Total execution time: 0.0340
DEBUG - 2011-08-30 12:06:22 --> File loaded: application/views/table/main.php
DEBUG - 2011-08-30 12:06:22 --> Helper loaded: url_helper
DEBUG - 2011-08-30 12:06:22 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-30 12:06:22 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-30 12:06:22 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-30 12:06:22 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-30 12:06:22 --> Final output sent to browser
DEBUG - 2011-08-30 12:06:22 --> Total execution time: 0.3175
DEBUG - 2011-08-30 12:06:32 --> Config Class Initialized
DEBUG - 2011-08-30 12:06:32 --> Hooks Class Initialized
DEBUG - 2011-08-30 12:06:32 --> Utf8 Class Initialized
DEBUG - 2011-08-30 12:06:32 --> UTF-8 Support Enabled
DEBUG - 2011-08-30 12:06:32 --> URI Class Initialized
DEBUG - 2011-08-30 12:06:32 --> Router Class Initialized
DEBUG - 2011-08-30 12:06:32 --> Output Class Initialized
DEBUG - 2011-08-30 12:06:32 --> Input Class Initialized
DEBUG - 2011-08-30 12:06:32 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-30 12:06:32 --> Language Class Initialized
DEBUG - 2011-08-30 12:06:32 --> Loader Class Initialized
DEBUG - 2011-08-30 12:06:32 --> Controller Class Initialized
ERROR - 2011-08-30 12:06:32 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-08-30 12:06:32 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-08-30 12:06:32 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-08-30 12:06:32 --> Model Class Initialized
DEBUG - 2011-08-30 12:06:32 --> Model Class Initialized
DEBUG - 2011-08-30 12:06:32 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-30 12:06:32 --> Database Driver Class Initialized
DEBUG - 2011-08-30 12:06:32 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-08-30 12:06:32 --> Helper loaded: url_helper
DEBUG - 2011-08-30 12:06:32 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-30 12:06:32 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-30 12:06:32 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-30 12:06:32 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-30 12:06:32 --> Final output sent to browser
DEBUG - 2011-08-30 12:06:32 --> Total execution time: 0.0307
DEBUG - 2011-08-30 12:06:33 --> Config Class Initialized
DEBUG - 2011-08-30 12:06:33 --> Hooks Class Initialized
DEBUG - 2011-08-30 12:06:33 --> Utf8 Class Initialized
DEBUG - 2011-08-30 12:06:33 --> UTF-8 Support Enabled
DEBUG - 2011-08-30 12:06:33 --> URI Class Initialized
DEBUG - 2011-08-30 12:06:33 --> Config Class Initialized
DEBUG - 2011-08-30 12:06:33 --> Router Class Initialized
DEBUG - 2011-08-30 12:06:33 --> Hooks Class Initialized
DEBUG - 2011-08-30 12:06:33 --> Utf8 Class Initialized
DEBUG - 2011-08-30 12:06:33 --> UTF-8 Support Enabled
DEBUG - 2011-08-30 12:06:33 --> Output Class Initialized
DEBUG - 2011-08-30 12:06:33 --> URI Class Initialized
DEBUG - 2011-08-30 12:06:33 --> Input Class Initialized
DEBUG - 2011-08-30 12:06:33 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-30 12:06:33 --> Language Class Initialized
DEBUG - 2011-08-30 12:06:33 --> Router Class Initialized
DEBUG - 2011-08-30 12:06:33 --> Loader Class Initialized
DEBUG - 2011-08-30 12:06:33 --> Controller Class Initialized
DEBUG - 2011-08-30 12:06:33 --> Model Class Initialized
DEBUG - 2011-08-30 12:06:33 --> Model Class Initialized
DEBUG - 2011-08-30 12:06:33 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-30 12:06:33 --> Output Class Initialized
DEBUG - 2011-08-30 12:06:33 --> Input Class Initialized
DEBUG - 2011-08-30 12:06:33 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-30 12:06:33 --> Language Class Initialized
DEBUG - 2011-08-30 12:06:33 --> Database Driver Class Initialized
DEBUG - 2011-08-30 12:06:33 --> Loader Class Initialized
DEBUG - 2011-08-30 12:06:33 --> Controller Class Initialized
DEBUG - 2011-08-30 12:06:33 --> Model Class Initialized
DEBUG - 2011-08-30 12:06:33 --> Model Class Initialized
DEBUG - 2011-08-30 12:06:33 --> Model Class Initialized
DEBUG - 2011-08-30 12:06:33 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-30 12:06:33 --> Database Driver Class Initialized
DEBUG - 2011-08-30 12:06:33 --> Final output sent to browser
DEBUG - 2011-08-30 12:06:33 --> Total execution time: 0.7778
DEBUG - 2011-08-30 12:06:34 --> File loaded: application/views/table/main.php
DEBUG - 2011-08-30 12:06:34 --> Helper loaded: url_helper
DEBUG - 2011-08-30 12:06:34 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-30 12:06:34 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-30 12:06:34 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-30 12:06:34 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-30 12:06:34 --> Final output sent to browser
DEBUG - 2011-08-30 12:06:34 --> Total execution time: 1.2994
DEBUG - 2011-08-30 12:06:35 --> Config Class Initialized
DEBUG - 2011-08-30 12:06:35 --> Hooks Class Initialized
DEBUG - 2011-08-30 12:06:35 --> Utf8 Class Initialized
DEBUG - 2011-08-30 12:06:35 --> UTF-8 Support Enabled
DEBUG - 2011-08-30 12:06:35 --> URI Class Initialized
DEBUG - 2011-08-30 12:06:35 --> Router Class Initialized
DEBUG - 2011-08-30 12:06:35 --> Output Class Initialized
DEBUG - 2011-08-30 12:06:35 --> Input Class Initialized
DEBUG - 2011-08-30 12:06:35 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-30 12:06:35 --> Language Class Initialized
DEBUG - 2011-08-30 12:06:35 --> Loader Class Initialized
DEBUG - 2011-08-30 12:06:35 --> Controller Class Initialized
ERROR - 2011-08-30 12:06:35 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-08-30 12:06:35 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-08-30 12:06:35 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-08-30 12:06:35 --> Model Class Initialized
DEBUG - 2011-08-30 12:06:35 --> Model Class Initialized
DEBUG - 2011-08-30 12:06:35 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-30 12:06:35 --> Database Driver Class Initialized
DEBUG - 2011-08-30 12:06:35 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-08-30 12:06:35 --> Helper loaded: url_helper
DEBUG - 2011-08-30 12:06:35 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-30 12:06:35 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-30 12:06:35 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-30 12:06:35 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-30 12:06:35 --> Final output sent to browser
DEBUG - 2011-08-30 12:06:35 --> Total execution time: 0.0954
DEBUG - 2011-08-30 12:06:41 --> Config Class Initialized
DEBUG - 2011-08-30 12:06:41 --> Hooks Class Initialized
DEBUG - 2011-08-30 12:06:41 --> Utf8 Class Initialized
DEBUG - 2011-08-30 12:06:41 --> UTF-8 Support Enabled
DEBUG - 2011-08-30 12:06:41 --> URI Class Initialized
DEBUG - 2011-08-30 12:06:41 --> Router Class Initialized
DEBUG - 2011-08-30 12:06:41 --> Output Class Initialized
DEBUG - 2011-08-30 12:06:41 --> Input Class Initialized
DEBUG - 2011-08-30 12:06:41 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-30 12:06:41 --> Language Class Initialized
DEBUG - 2011-08-30 12:06:41 --> Loader Class Initialized
DEBUG - 2011-08-30 12:06:41 --> Controller Class Initialized
DEBUG - 2011-08-30 12:06:41 --> Model Class Initialized
DEBUG - 2011-08-30 12:06:41 --> Model Class Initialized
DEBUG - 2011-08-30 12:06:41 --> Model Class Initialized
DEBUG - 2011-08-30 12:06:41 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-30 12:06:41 --> Database Driver Class Initialized
DEBUG - 2011-08-30 12:06:41 --> File loaded: application/views/table/main.php
DEBUG - 2011-08-30 12:06:41 --> Helper loaded: url_helper
DEBUG - 2011-08-30 12:06:41 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-30 12:06:41 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-30 12:06:41 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-30 12:06:41 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-30 12:06:41 --> Final output sent to browser
DEBUG - 2011-08-30 12:06:41 --> Total execution time: 0.6343
DEBUG - 2011-08-30 12:06:42 --> Config Class Initialized
DEBUG - 2011-08-30 12:06:42 --> Hooks Class Initialized
DEBUG - 2011-08-30 12:06:42 --> Utf8 Class Initialized
DEBUG - 2011-08-30 12:06:42 --> UTF-8 Support Enabled
DEBUG - 2011-08-30 12:06:42 --> URI Class Initialized
DEBUG - 2011-08-30 12:06:42 --> Router Class Initialized
DEBUG - 2011-08-30 12:06:42 --> Output Class Initialized
DEBUG - 2011-08-30 12:06:42 --> Input Class Initialized
DEBUG - 2011-08-30 12:06:42 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-30 12:06:42 --> Language Class Initialized
DEBUG - 2011-08-30 12:06:42 --> Loader Class Initialized
DEBUG - 2011-08-30 12:06:42 --> Controller Class Initialized
ERROR - 2011-08-30 12:06:42 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-08-30 12:06:42 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-08-30 12:06:42 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-08-30 12:06:42 --> Model Class Initialized
DEBUG - 2011-08-30 12:06:42 --> Model Class Initialized
DEBUG - 2011-08-30 12:06:42 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-30 12:06:42 --> Database Driver Class Initialized
DEBUG - 2011-08-30 12:06:42 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-08-30 12:06:42 --> Helper loaded: url_helper
DEBUG - 2011-08-30 12:06:42 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-30 12:06:42 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-30 12:06:42 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-30 12:06:42 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-30 12:06:42 --> Final output sent to browser
DEBUG - 2011-08-30 12:06:42 --> Total execution time: 0.0303
DEBUG - 2011-08-30 12:06:43 --> Config Class Initialized
DEBUG - 2011-08-30 12:06:43 --> Hooks Class Initialized
DEBUG - 2011-08-30 12:06:43 --> Utf8 Class Initialized
DEBUG - 2011-08-30 12:06:43 --> UTF-8 Support Enabled
DEBUG - 2011-08-30 12:06:43 --> URI Class Initialized
DEBUG - 2011-08-30 12:06:43 --> Router Class Initialized
DEBUG - 2011-08-30 12:06:43 --> Output Class Initialized
DEBUG - 2011-08-30 12:06:43 --> Input Class Initialized
DEBUG - 2011-08-30 12:06:43 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-30 12:06:43 --> Language Class Initialized
DEBUG - 2011-08-30 12:06:43 --> Loader Class Initialized
DEBUG - 2011-08-30 12:06:43 --> Controller Class Initialized
DEBUG - 2011-08-30 12:06:43 --> Model Class Initialized
DEBUG - 2011-08-30 12:06:43 --> Model Class Initialized
DEBUG - 2011-08-30 12:06:43 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-30 12:06:43 --> Database Driver Class Initialized
DEBUG - 2011-08-30 12:06:44 --> Final output sent to browser
DEBUG - 2011-08-30 12:06:44 --> Total execution time: 0.5399
DEBUG - 2011-08-30 12:06:47 --> Config Class Initialized
DEBUG - 2011-08-30 12:06:47 --> Hooks Class Initialized
DEBUG - 2011-08-30 12:06:47 --> Utf8 Class Initialized
DEBUG - 2011-08-30 12:06:47 --> UTF-8 Support Enabled
DEBUG - 2011-08-30 12:06:47 --> URI Class Initialized
DEBUG - 2011-08-30 12:06:47 --> Router Class Initialized
DEBUG - 2011-08-30 12:06:47 --> Output Class Initialized
DEBUG - 2011-08-30 12:06:47 --> Input Class Initialized
DEBUG - 2011-08-30 12:06:47 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-30 12:06:47 --> Language Class Initialized
DEBUG - 2011-08-30 12:06:47 --> Loader Class Initialized
DEBUG - 2011-08-30 12:06:47 --> Controller Class Initialized
DEBUG - 2011-08-30 12:06:47 --> Model Class Initialized
DEBUG - 2011-08-30 12:06:47 --> Model Class Initialized
DEBUG - 2011-08-30 12:06:47 --> Model Class Initialized
DEBUG - 2011-08-30 12:06:47 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-30 12:06:47 --> Database Driver Class Initialized
DEBUG - 2011-08-30 12:06:48 --> File loaded: application/views/table/main.php
DEBUG - 2011-08-30 12:06:48 --> Helper loaded: url_helper
DEBUG - 2011-08-30 12:06:48 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-30 12:06:48 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-30 12:06:48 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-30 12:06:48 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-30 12:06:48 --> Final output sent to browser
DEBUG - 2011-08-30 12:06:48 --> Total execution time: 0.6563
DEBUG - 2011-08-30 12:06:50 --> Config Class Initialized
DEBUG - 2011-08-30 12:06:50 --> Hooks Class Initialized
DEBUG - 2011-08-30 12:06:50 --> Utf8 Class Initialized
DEBUG - 2011-08-30 12:06:50 --> UTF-8 Support Enabled
DEBUG - 2011-08-30 12:06:50 --> URI Class Initialized
DEBUG - 2011-08-30 12:06:50 --> Router Class Initialized
DEBUG - 2011-08-30 12:06:50 --> Output Class Initialized
DEBUG - 2011-08-30 12:06:50 --> Input Class Initialized
DEBUG - 2011-08-30 12:06:50 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-30 12:06:50 --> Language Class Initialized
DEBUG - 2011-08-30 12:06:50 --> Loader Class Initialized
DEBUG - 2011-08-30 12:06:50 --> Controller Class Initialized
ERROR - 2011-08-30 12:06:50 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-08-30 12:06:50 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-08-30 12:06:50 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-08-30 12:06:50 --> Model Class Initialized
DEBUG - 2011-08-30 12:06:50 --> Model Class Initialized
DEBUG - 2011-08-30 12:06:50 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-30 12:06:50 --> Database Driver Class Initialized
DEBUG - 2011-08-30 12:06:50 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-08-30 12:06:50 --> Helper loaded: url_helper
DEBUG - 2011-08-30 12:06:50 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-30 12:06:50 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-30 12:06:50 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-30 12:06:50 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-30 12:06:50 --> Final output sent to browser
DEBUG - 2011-08-30 12:06:50 --> Total execution time: 0.0446
DEBUG - 2011-08-30 12:06:50 --> Config Class Initialized
DEBUG - 2011-08-30 12:06:50 --> Hooks Class Initialized
DEBUG - 2011-08-30 12:06:50 --> Utf8 Class Initialized
DEBUG - 2011-08-30 12:06:50 --> UTF-8 Support Enabled
DEBUG - 2011-08-30 12:06:50 --> URI Class Initialized
DEBUG - 2011-08-30 12:06:50 --> Router Class Initialized
DEBUG - 2011-08-30 12:06:50 --> Output Class Initialized
DEBUG - 2011-08-30 12:06:50 --> Input Class Initialized
DEBUG - 2011-08-30 12:06:50 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-30 12:06:50 --> Language Class Initialized
DEBUG - 2011-08-30 12:06:50 --> Loader Class Initialized
DEBUG - 2011-08-30 12:06:50 --> Controller Class Initialized
DEBUG - 2011-08-30 12:06:50 --> Model Class Initialized
DEBUG - 2011-08-30 12:06:50 --> Model Class Initialized
DEBUG - 2011-08-30 12:06:50 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-30 12:06:50 --> Database Driver Class Initialized
DEBUG - 2011-08-30 12:06:51 --> Final output sent to browser
DEBUG - 2011-08-30 12:06:51 --> Total execution time: 0.8753
DEBUG - 2011-08-30 12:06:54 --> Config Class Initialized
DEBUG - 2011-08-30 12:06:54 --> Hooks Class Initialized
DEBUG - 2011-08-30 12:06:54 --> Utf8 Class Initialized
DEBUG - 2011-08-30 12:06:54 --> UTF-8 Support Enabled
DEBUG - 2011-08-30 12:06:54 --> URI Class Initialized
DEBUG - 2011-08-30 12:06:54 --> Router Class Initialized
DEBUG - 2011-08-30 12:06:54 --> Output Class Initialized
DEBUG - 2011-08-30 12:06:54 --> Input Class Initialized
DEBUG - 2011-08-30 12:06:54 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-30 12:06:54 --> Language Class Initialized
DEBUG - 2011-08-30 12:06:54 --> Loader Class Initialized
DEBUG - 2011-08-30 12:06:54 --> Controller Class Initialized
DEBUG - 2011-08-30 12:06:54 --> Model Class Initialized
DEBUG - 2011-08-30 12:06:54 --> Model Class Initialized
DEBUG - 2011-08-30 12:06:54 --> Model Class Initialized
DEBUG - 2011-08-30 12:06:54 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-30 12:06:54 --> Database Driver Class Initialized
DEBUG - 2011-08-30 12:06:54 --> File loaded: application/views/table/main.php
DEBUG - 2011-08-30 12:06:54 --> Helper loaded: url_helper
DEBUG - 2011-08-30 12:06:54 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-30 12:06:54 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-30 12:06:54 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-30 12:06:54 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-30 12:06:54 --> Final output sent to browser
DEBUG - 2011-08-30 12:06:54 --> Total execution time: 0.3560
DEBUG - 2011-08-30 12:07:00 --> Config Class Initialized
DEBUG - 2011-08-30 12:07:00 --> Hooks Class Initialized
DEBUG - 2011-08-30 12:07:00 --> Utf8 Class Initialized
DEBUG - 2011-08-30 12:07:00 --> UTF-8 Support Enabled
DEBUG - 2011-08-30 12:07:00 --> URI Class Initialized
DEBUG - 2011-08-30 12:07:00 --> Router Class Initialized
DEBUG - 2011-08-30 12:07:00 --> Output Class Initialized
DEBUG - 2011-08-30 12:07:00 --> Input Class Initialized
DEBUG - 2011-08-30 12:07:00 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-30 12:07:00 --> Language Class Initialized
DEBUG - 2011-08-30 12:07:00 --> Loader Class Initialized
DEBUG - 2011-08-30 12:07:00 --> Controller Class Initialized
DEBUG - 2011-08-30 12:07:00 --> Model Class Initialized
DEBUG - 2011-08-30 12:07:00 --> Model Class Initialized
DEBUG - 2011-08-30 12:07:00 --> Model Class Initialized
DEBUG - 2011-08-30 12:07:00 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-30 12:07:00 --> Database Driver Class Initialized
DEBUG - 2011-08-30 12:07:00 --> File loaded: application/views/table/main.php
DEBUG - 2011-08-30 12:07:00 --> Helper loaded: url_helper
DEBUG - 2011-08-30 12:07:00 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-30 12:07:00 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-30 12:07:00 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-30 12:07:00 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-30 12:07:00 --> Final output sent to browser
DEBUG - 2011-08-30 12:07:00 --> Total execution time: 0.2666
DEBUG - 2011-08-30 12:07:08 --> Config Class Initialized
DEBUG - 2011-08-30 12:07:08 --> Hooks Class Initialized
DEBUG - 2011-08-30 12:07:08 --> Utf8 Class Initialized
DEBUG - 2011-08-30 12:07:08 --> UTF-8 Support Enabled
DEBUG - 2011-08-30 12:07:08 --> URI Class Initialized
DEBUG - 2011-08-30 12:07:08 --> Router Class Initialized
DEBUG - 2011-08-30 12:07:08 --> Output Class Initialized
DEBUG - 2011-08-30 12:07:09 --> Input Class Initialized
DEBUG - 2011-08-30 12:07:09 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-30 12:07:09 --> Language Class Initialized
DEBUG - 2011-08-30 12:07:09 --> Loader Class Initialized
DEBUG - 2011-08-30 12:07:09 --> Controller Class Initialized
DEBUG - 2011-08-30 12:07:09 --> Model Class Initialized
DEBUG - 2011-08-30 12:07:09 --> Model Class Initialized
DEBUG - 2011-08-30 12:07:09 --> Model Class Initialized
DEBUG - 2011-08-30 12:07:09 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-30 12:07:09 --> Database Driver Class Initialized
DEBUG - 2011-08-30 12:07:09 --> File loaded: application/views/table/main.php
DEBUG - 2011-08-30 12:07:09 --> Helper loaded: url_helper
DEBUG - 2011-08-30 12:07:09 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-30 12:07:09 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-30 12:07:09 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-30 12:07:09 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-30 12:07:09 --> Final output sent to browser
DEBUG - 2011-08-30 12:07:09 --> Total execution time: 0.1702
DEBUG - 2011-08-30 12:07:14 --> Config Class Initialized
DEBUG - 2011-08-30 12:07:14 --> Hooks Class Initialized
DEBUG - 2011-08-30 12:07:14 --> Utf8 Class Initialized
DEBUG - 2011-08-30 12:07:14 --> UTF-8 Support Enabled
DEBUG - 2011-08-30 12:07:14 --> URI Class Initialized
DEBUG - 2011-08-30 12:07:14 --> Router Class Initialized
DEBUG - 2011-08-30 12:07:14 --> Output Class Initialized
DEBUG - 2011-08-30 12:07:14 --> Input Class Initialized
DEBUG - 2011-08-30 12:07:14 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-30 12:07:14 --> Language Class Initialized
DEBUG - 2011-08-30 12:07:14 --> Loader Class Initialized
DEBUG - 2011-08-30 12:07:14 --> Controller Class Initialized
DEBUG - 2011-08-30 12:07:14 --> Model Class Initialized
DEBUG - 2011-08-30 12:07:14 --> Model Class Initialized
DEBUG - 2011-08-30 12:07:14 --> Model Class Initialized
DEBUG - 2011-08-30 12:07:14 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-30 12:07:14 --> Database Driver Class Initialized
DEBUG - 2011-08-30 12:07:14 --> File loaded: application/views/table/main.php
DEBUG - 2011-08-30 12:07:14 --> Helper loaded: url_helper
DEBUG - 2011-08-30 12:07:14 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-30 12:07:14 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-30 12:07:14 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-30 12:07:14 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-30 12:07:14 --> Final output sent to browser
DEBUG - 2011-08-30 12:07:14 --> Total execution time: 0.1325
DEBUG - 2011-08-30 12:36:22 --> Config Class Initialized
DEBUG - 2011-08-30 12:36:22 --> Hooks Class Initialized
DEBUG - 2011-08-30 12:36:22 --> Utf8 Class Initialized
DEBUG - 2011-08-30 12:36:22 --> UTF-8 Support Enabled
DEBUG - 2011-08-30 12:36:22 --> URI Class Initialized
DEBUG - 2011-08-30 12:36:22 --> Router Class Initialized
DEBUG - 2011-08-30 12:36:22 --> Output Class Initialized
DEBUG - 2011-08-30 12:36:22 --> Input Class Initialized
DEBUG - 2011-08-30 12:36:22 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-30 12:36:22 --> Language Class Initialized
DEBUG - 2011-08-30 12:36:22 --> Loader Class Initialized
DEBUG - 2011-08-30 12:36:22 --> Controller Class Initialized
DEBUG - 2011-08-30 12:36:22 --> Model Class Initialized
DEBUG - 2011-08-30 12:36:22 --> Model Class Initialized
DEBUG - 2011-08-30 12:36:22 --> Model Class Initialized
DEBUG - 2011-08-30 12:36:22 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-30 12:36:22 --> Database Driver Class Initialized
DEBUG - 2011-08-30 12:36:23 --> File loaded: application/views/table/main.php
DEBUG - 2011-08-30 12:36:23 --> Helper loaded: url_helper
DEBUG - 2011-08-30 12:36:23 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-30 12:36:23 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-30 12:36:23 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-30 12:36:23 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-30 12:36:23 --> Final output sent to browser
DEBUG - 2011-08-30 12:36:23 --> Total execution time: 0.4929
DEBUG - 2011-08-30 12:36:30 --> Config Class Initialized
DEBUG - 2011-08-30 12:36:30 --> Hooks Class Initialized
DEBUG - 2011-08-30 12:36:30 --> Utf8 Class Initialized
DEBUG - 2011-08-30 12:36:30 --> UTF-8 Support Enabled
DEBUG - 2011-08-30 12:36:30 --> URI Class Initialized
DEBUG - 2011-08-30 12:36:30 --> Router Class Initialized
ERROR - 2011-08-30 12:36:30 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-08-30 12:36:57 --> Config Class Initialized
DEBUG - 2011-08-30 12:36:57 --> Hooks Class Initialized
DEBUG - 2011-08-30 12:36:57 --> Utf8 Class Initialized
DEBUG - 2011-08-30 12:36:57 --> UTF-8 Support Enabled
DEBUG - 2011-08-30 12:36:57 --> URI Class Initialized
DEBUG - 2011-08-30 12:36:57 --> Router Class Initialized
DEBUG - 2011-08-30 12:36:57 --> Output Class Initialized
DEBUG - 2011-08-30 12:36:57 --> Input Class Initialized
DEBUG - 2011-08-30 12:36:57 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-30 12:36:57 --> Language Class Initialized
DEBUG - 2011-08-30 12:36:57 --> Loader Class Initialized
DEBUG - 2011-08-30 12:36:57 --> Controller Class Initialized
DEBUG - 2011-08-30 12:36:57 --> Model Class Initialized
DEBUG - 2011-08-30 12:36:57 --> Model Class Initialized
DEBUG - 2011-08-30 12:36:57 --> Model Class Initialized
DEBUG - 2011-08-30 12:36:57 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-30 12:36:57 --> Database Driver Class Initialized
DEBUG - 2011-08-30 12:36:57 --> File loaded: application/views/table/main.php
DEBUG - 2011-08-30 12:36:57 --> Helper loaded: url_helper
DEBUG - 2011-08-30 12:36:57 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-30 12:36:57 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-30 12:36:57 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-30 12:36:57 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-30 12:36:57 --> Final output sent to browser
DEBUG - 2011-08-30 12:36:57 --> Total execution time: 0.0455
DEBUG - 2011-08-30 12:37:01 --> Config Class Initialized
DEBUG - 2011-08-30 12:37:01 --> Hooks Class Initialized
DEBUG - 2011-08-30 12:37:01 --> Utf8 Class Initialized
DEBUG - 2011-08-30 12:37:01 --> UTF-8 Support Enabled
DEBUG - 2011-08-30 12:37:01 --> URI Class Initialized
DEBUG - 2011-08-30 12:37:01 --> Router Class Initialized
ERROR - 2011-08-30 12:37:01 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-08-30 12:37:01 --> Config Class Initialized
DEBUG - 2011-08-30 12:37:01 --> Hooks Class Initialized
DEBUG - 2011-08-30 12:37:01 --> Utf8 Class Initialized
DEBUG - 2011-08-30 12:37:01 --> UTF-8 Support Enabled
DEBUG - 2011-08-30 12:37:01 --> URI Class Initialized
DEBUG - 2011-08-30 12:37:01 --> Router Class Initialized
DEBUG - 2011-08-30 12:37:01 --> Output Class Initialized
DEBUG - 2011-08-30 12:37:01 --> Input Class Initialized
DEBUG - 2011-08-30 12:37:01 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-30 12:37:01 --> Language Class Initialized
DEBUG - 2011-08-30 12:37:01 --> Loader Class Initialized
DEBUG - 2011-08-30 12:37:01 --> Controller Class Initialized
DEBUG - 2011-08-30 12:37:01 --> Model Class Initialized
DEBUG - 2011-08-30 12:37:01 --> Model Class Initialized
DEBUG - 2011-08-30 12:37:01 --> Model Class Initialized
DEBUG - 2011-08-30 12:37:01 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-30 12:37:01 --> Database Driver Class Initialized
DEBUG - 2011-08-30 12:37:01 --> File loaded: application/views/table/main.php
DEBUG - 2011-08-30 12:37:01 --> Helper loaded: url_helper
DEBUG - 2011-08-30 12:37:01 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-30 12:37:01 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-30 12:37:01 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-30 12:37:01 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-30 12:37:01 --> Final output sent to browser
DEBUG - 2011-08-30 12:37:01 --> Total execution time: 0.0902
DEBUG - 2011-08-30 12:37:11 --> Config Class Initialized
DEBUG - 2011-08-30 12:37:11 --> Hooks Class Initialized
DEBUG - 2011-08-30 12:37:11 --> Utf8 Class Initialized
DEBUG - 2011-08-30 12:37:11 --> UTF-8 Support Enabled
DEBUG - 2011-08-30 12:37:11 --> URI Class Initialized
DEBUG - 2011-08-30 12:37:11 --> Router Class Initialized
DEBUG - 2011-08-30 12:37:11 --> Output Class Initialized
DEBUG - 2011-08-30 12:37:11 --> Input Class Initialized
DEBUG - 2011-08-30 12:37:11 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-30 12:37:11 --> Language Class Initialized
DEBUG - 2011-08-30 12:37:11 --> Loader Class Initialized
DEBUG - 2011-08-30 12:37:11 --> Controller Class Initialized
DEBUG - 2011-08-30 12:37:11 --> Model Class Initialized
DEBUG - 2011-08-30 12:37:11 --> Model Class Initialized
DEBUG - 2011-08-30 12:37:11 --> Model Class Initialized
DEBUG - 2011-08-30 12:37:11 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-30 12:37:11 --> Database Driver Class Initialized
DEBUG - 2011-08-30 12:37:12 --> File loaded: application/views/table/main.php
DEBUG - 2011-08-30 12:37:12 --> Helper loaded: url_helper
DEBUG - 2011-08-30 12:37:12 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-30 12:37:12 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-30 12:37:12 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-30 12:37:12 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-30 12:37:12 --> Final output sent to browser
DEBUG - 2011-08-30 12:37:12 --> Total execution time: 0.6515
DEBUG - 2011-08-30 12:37:16 --> Config Class Initialized
DEBUG - 2011-08-30 12:37:16 --> Hooks Class Initialized
DEBUG - 2011-08-30 12:37:16 --> Utf8 Class Initialized
DEBUG - 2011-08-30 12:37:16 --> UTF-8 Support Enabled
DEBUG - 2011-08-30 12:37:16 --> URI Class Initialized
DEBUG - 2011-08-30 12:37:16 --> Router Class Initialized
ERROR - 2011-08-30 12:37:16 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-08-30 12:43:40 --> Config Class Initialized
DEBUG - 2011-08-30 12:43:40 --> Hooks Class Initialized
DEBUG - 2011-08-30 12:43:40 --> Utf8 Class Initialized
DEBUG - 2011-08-30 12:43:40 --> UTF-8 Support Enabled
DEBUG - 2011-08-30 12:43:40 --> URI Class Initialized
DEBUG - 2011-08-30 12:43:40 --> Router Class Initialized
ERROR - 2011-08-30 12:43:40 --> 404 Page Not Found --> robots.txt
DEBUG - 2011-08-30 12:46:54 --> Config Class Initialized
DEBUG - 2011-08-30 12:46:54 --> Hooks Class Initialized
DEBUG - 2011-08-30 12:46:54 --> Utf8 Class Initialized
DEBUG - 2011-08-30 12:46:54 --> UTF-8 Support Enabled
DEBUG - 2011-08-30 12:46:54 --> URI Class Initialized
DEBUG - 2011-08-30 12:46:54 --> Router Class Initialized
DEBUG - 2011-08-30 12:46:54 --> Output Class Initialized
DEBUG - 2011-08-30 12:46:54 --> Input Class Initialized
DEBUG - 2011-08-30 12:46:54 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-30 12:46:54 --> Language Class Initialized
DEBUG - 2011-08-30 12:46:54 --> Loader Class Initialized
DEBUG - 2011-08-30 12:46:54 --> Controller Class Initialized
ERROR - 2011-08-30 12:46:54 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-08-30 12:46:54 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-08-30 12:46:54 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-08-30 12:46:54 --> Model Class Initialized
DEBUG - 2011-08-30 12:46:54 --> Model Class Initialized
DEBUG - 2011-08-30 12:46:54 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-30 12:46:54 --> Database Driver Class Initialized
DEBUG - 2011-08-30 12:46:54 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-08-30 12:46:54 --> Helper loaded: url_helper
DEBUG - 2011-08-30 12:46:54 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-30 12:46:54 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-30 12:46:54 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-30 12:46:54 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-30 12:46:54 --> Final output sent to browser
DEBUG - 2011-08-30 12:46:54 --> Total execution time: 0.0707
DEBUG - 2011-08-30 12:46:57 --> Config Class Initialized
DEBUG - 2011-08-30 12:46:57 --> Hooks Class Initialized
DEBUG - 2011-08-30 12:46:57 --> Utf8 Class Initialized
DEBUG - 2011-08-30 12:46:57 --> UTF-8 Support Enabled
DEBUG - 2011-08-30 12:46:57 --> URI Class Initialized
DEBUG - 2011-08-30 12:46:57 --> Router Class Initialized
DEBUG - 2011-08-30 12:46:57 --> Output Class Initialized
DEBUG - 2011-08-30 12:46:57 --> Input Class Initialized
DEBUG - 2011-08-30 12:46:57 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-30 12:46:57 --> Language Class Initialized
DEBUG - 2011-08-30 12:46:57 --> Loader Class Initialized
DEBUG - 2011-08-30 12:46:57 --> Controller Class Initialized
DEBUG - 2011-08-30 12:46:57 --> Model Class Initialized
DEBUG - 2011-08-30 12:46:57 --> Model Class Initialized
DEBUG - 2011-08-30 12:46:57 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-30 12:46:57 --> Database Driver Class Initialized
DEBUG - 2011-08-30 12:46:58 --> Final output sent to browser
DEBUG - 2011-08-30 12:46:58 --> Total execution time: 0.7004
DEBUG - 2011-08-30 12:47:01 --> Config Class Initialized
DEBUG - 2011-08-30 12:47:01 --> Hooks Class Initialized
DEBUG - 2011-08-30 12:47:01 --> Utf8 Class Initialized
DEBUG - 2011-08-30 12:47:01 --> UTF-8 Support Enabled
DEBUG - 2011-08-30 12:47:01 --> URI Class Initialized
DEBUG - 2011-08-30 12:47:01 --> Router Class Initialized
ERROR - 2011-08-30 12:47:01 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-08-30 12:47:21 --> Config Class Initialized
DEBUG - 2011-08-30 12:47:21 --> Hooks Class Initialized
DEBUG - 2011-08-30 12:47:21 --> Utf8 Class Initialized
DEBUG - 2011-08-30 12:47:21 --> UTF-8 Support Enabled
DEBUG - 2011-08-30 12:47:21 --> URI Class Initialized
DEBUG - 2011-08-30 12:47:21 --> Router Class Initialized
DEBUG - 2011-08-30 12:47:21 --> Output Class Initialized
DEBUG - 2011-08-30 12:47:21 --> Input Class Initialized
DEBUG - 2011-08-30 12:47:21 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-30 12:47:21 --> Language Class Initialized
DEBUG - 2011-08-30 12:47:21 --> Loader Class Initialized
DEBUG - 2011-08-30 12:47:21 --> Controller Class Initialized
ERROR - 2011-08-30 12:47:21 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-08-30 12:47:21 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-08-30 12:47:21 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-08-30 12:47:21 --> Model Class Initialized
DEBUG - 2011-08-30 12:47:21 --> Model Class Initialized
DEBUG - 2011-08-30 12:47:21 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-30 12:47:21 --> Database Driver Class Initialized
DEBUG - 2011-08-30 12:47:21 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-08-30 12:47:21 --> Helper loaded: url_helper
DEBUG - 2011-08-30 12:47:21 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-30 12:47:21 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-30 12:47:21 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-30 12:47:21 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-30 12:47:21 --> Final output sent to browser
DEBUG - 2011-08-30 12:47:21 --> Total execution time: 0.0290
DEBUG - 2011-08-30 12:47:22 --> Config Class Initialized
DEBUG - 2011-08-30 12:47:22 --> Hooks Class Initialized
DEBUG - 2011-08-30 12:47:22 --> Utf8 Class Initialized
DEBUG - 2011-08-30 12:47:22 --> UTF-8 Support Enabled
DEBUG - 2011-08-30 12:47:22 --> URI Class Initialized
DEBUG - 2011-08-30 12:47:22 --> Router Class Initialized
DEBUG - 2011-08-30 12:47:22 --> Output Class Initialized
DEBUG - 2011-08-30 12:47:22 --> Input Class Initialized
DEBUG - 2011-08-30 12:47:22 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-30 12:47:22 --> Language Class Initialized
DEBUG - 2011-08-30 12:47:22 --> Loader Class Initialized
DEBUG - 2011-08-30 12:47:22 --> Controller Class Initialized
DEBUG - 2011-08-30 12:47:22 --> Model Class Initialized
DEBUG - 2011-08-30 12:47:22 --> Model Class Initialized
DEBUG - 2011-08-30 12:47:22 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-30 12:47:22 --> Database Driver Class Initialized
DEBUG - 2011-08-30 12:47:23 --> Final output sent to browser
DEBUG - 2011-08-30 12:47:23 --> Total execution time: 0.4888
DEBUG - 2011-08-30 13:02:40 --> Config Class Initialized
DEBUG - 2011-08-30 13:02:40 --> Hooks Class Initialized
DEBUG - 2011-08-30 13:02:40 --> Utf8 Class Initialized
DEBUG - 2011-08-30 13:02:40 --> UTF-8 Support Enabled
DEBUG - 2011-08-30 13:02:40 --> URI Class Initialized
DEBUG - 2011-08-30 13:02:40 --> Router Class Initialized
DEBUG - 2011-08-30 13:02:40 --> Output Class Initialized
DEBUG - 2011-08-30 13:02:40 --> Input Class Initialized
DEBUG - 2011-08-30 13:02:40 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-30 13:02:40 --> Language Class Initialized
DEBUG - 2011-08-30 13:02:40 --> Loader Class Initialized
DEBUG - 2011-08-30 13:02:40 --> Controller Class Initialized
ERROR - 2011-08-30 13:02:40 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-08-30 13:02:40 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-08-30 13:02:40 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-08-30 13:02:40 --> Model Class Initialized
DEBUG - 2011-08-30 13:02:40 --> Model Class Initialized
DEBUG - 2011-08-30 13:02:40 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-30 13:02:40 --> Database Driver Class Initialized
DEBUG - 2011-08-30 13:02:40 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-08-30 13:02:40 --> Helper loaded: url_helper
DEBUG - 2011-08-30 13:02:40 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-30 13:02:40 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-30 13:02:40 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-30 13:02:40 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-30 13:02:40 --> Final output sent to browser
DEBUG - 2011-08-30 13:02:40 --> Total execution time: 0.0738
DEBUG - 2011-08-30 13:02:43 --> Config Class Initialized
DEBUG - 2011-08-30 13:02:43 --> Hooks Class Initialized
DEBUG - 2011-08-30 13:02:43 --> Utf8 Class Initialized
DEBUG - 2011-08-30 13:02:43 --> UTF-8 Support Enabled
DEBUG - 2011-08-30 13:02:43 --> URI Class Initialized
DEBUG - 2011-08-30 13:02:43 --> Router Class Initialized
DEBUG - 2011-08-30 13:02:43 --> Output Class Initialized
DEBUG - 2011-08-30 13:02:43 --> Input Class Initialized
DEBUG - 2011-08-30 13:02:43 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-30 13:02:43 --> Language Class Initialized
DEBUG - 2011-08-30 13:02:43 --> Loader Class Initialized
DEBUG - 2011-08-30 13:02:43 --> Controller Class Initialized
DEBUG - 2011-08-30 13:02:43 --> Model Class Initialized
DEBUG - 2011-08-30 13:02:43 --> Model Class Initialized
DEBUG - 2011-08-30 13:02:43 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-30 13:02:43 --> Database Driver Class Initialized
DEBUG - 2011-08-30 13:02:43 --> Final output sent to browser
DEBUG - 2011-08-30 13:02:43 --> Total execution time: 0.5796
DEBUG - 2011-08-30 13:02:48 --> Config Class Initialized
DEBUG - 2011-08-30 13:02:48 --> Hooks Class Initialized
DEBUG - 2011-08-30 13:02:48 --> Utf8 Class Initialized
DEBUG - 2011-08-30 13:02:48 --> UTF-8 Support Enabled
DEBUG - 2011-08-30 13:02:48 --> URI Class Initialized
DEBUG - 2011-08-30 13:02:48 --> Router Class Initialized
ERROR - 2011-08-30 13:02:48 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-08-30 14:09:29 --> Config Class Initialized
DEBUG - 2011-08-30 14:09:29 --> Hooks Class Initialized
DEBUG - 2011-08-30 14:09:29 --> Utf8 Class Initialized
DEBUG - 2011-08-30 14:09:29 --> UTF-8 Support Enabled
DEBUG - 2011-08-30 14:09:29 --> URI Class Initialized
DEBUG - 2011-08-30 14:09:29 --> Router Class Initialized
DEBUG - 2011-08-30 14:09:29 --> Output Class Initialized
DEBUG - 2011-08-30 14:09:29 --> Input Class Initialized
DEBUG - 2011-08-30 14:09:29 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-30 14:09:29 --> Language Class Initialized
DEBUG - 2011-08-30 14:09:29 --> Loader Class Initialized
DEBUG - 2011-08-30 14:09:29 --> Controller Class Initialized
ERROR - 2011-08-30 14:09:29 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-08-30 14:09:29 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-08-30 14:09:29 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-08-30 14:09:29 --> Model Class Initialized
DEBUG - 2011-08-30 14:09:29 --> Model Class Initialized
DEBUG - 2011-08-30 14:09:29 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-30 14:09:29 --> Database Driver Class Initialized
DEBUG - 2011-08-30 14:09:29 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-08-30 14:09:29 --> Helper loaded: url_helper
DEBUG - 2011-08-30 14:09:29 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-30 14:09:29 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-30 14:09:29 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-30 14:09:29 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-30 14:09:29 --> Final output sent to browser
DEBUG - 2011-08-30 14:09:29 --> Total execution time: 0.0605
DEBUG - 2011-08-30 14:09:29 --> Config Class Initialized
DEBUG - 2011-08-30 14:09:29 --> Hooks Class Initialized
DEBUG - 2011-08-30 14:09:29 --> Utf8 Class Initialized
DEBUG - 2011-08-30 14:09:29 --> UTF-8 Support Enabled
DEBUG - 2011-08-30 14:09:29 --> URI Class Initialized
DEBUG - 2011-08-30 14:09:29 --> Router Class Initialized
DEBUG - 2011-08-30 14:09:29 --> Output Class Initialized
DEBUG - 2011-08-30 14:09:29 --> Input Class Initialized
DEBUG - 2011-08-30 14:09:29 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-30 14:09:29 --> Language Class Initialized
DEBUG - 2011-08-30 14:09:29 --> Loader Class Initialized
DEBUG - 2011-08-30 14:09:29 --> Controller Class Initialized
DEBUG - 2011-08-30 14:09:29 --> Model Class Initialized
DEBUG - 2011-08-30 14:09:29 --> Model Class Initialized
DEBUG - 2011-08-30 14:09:29 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-30 14:09:29 --> Database Driver Class Initialized
DEBUG - 2011-08-30 14:09:30 --> Final output sent to browser
DEBUG - 2011-08-30 14:09:30 --> Total execution time: 0.7033
DEBUG - 2011-08-30 14:09:30 --> Config Class Initialized
DEBUG - 2011-08-30 14:09:30 --> Hooks Class Initialized
DEBUG - 2011-08-30 14:09:30 --> Utf8 Class Initialized
DEBUG - 2011-08-30 14:09:30 --> UTF-8 Support Enabled
DEBUG - 2011-08-30 14:09:30 --> URI Class Initialized
DEBUG - 2011-08-30 14:09:30 --> Router Class Initialized
ERROR - 2011-08-30 14:09:30 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-08-30 14:09:31 --> Config Class Initialized
DEBUG - 2011-08-30 14:09:31 --> Hooks Class Initialized
DEBUG - 2011-08-30 14:09:31 --> Utf8 Class Initialized
DEBUG - 2011-08-30 14:09:31 --> UTF-8 Support Enabled
DEBUG - 2011-08-30 14:09:31 --> URI Class Initialized
DEBUG - 2011-08-30 14:09:31 --> Router Class Initialized
ERROR - 2011-08-30 14:09:31 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-08-30 14:17:58 --> Config Class Initialized
DEBUG - 2011-08-30 14:17:58 --> Hooks Class Initialized
DEBUG - 2011-08-30 14:17:58 --> Utf8 Class Initialized
DEBUG - 2011-08-30 14:17:58 --> UTF-8 Support Enabled
DEBUG - 2011-08-30 14:17:58 --> URI Class Initialized
DEBUG - 2011-08-30 14:17:58 --> Router Class Initialized
DEBUG - 2011-08-30 14:17:58 --> Output Class Initialized
DEBUG - 2011-08-30 14:17:58 --> Input Class Initialized
DEBUG - 2011-08-30 14:17:58 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-30 14:17:58 --> Language Class Initialized
DEBUG - 2011-08-30 14:17:58 --> Loader Class Initialized
DEBUG - 2011-08-30 14:17:58 --> Controller Class Initialized
DEBUG - 2011-08-30 14:17:58 --> Model Class Initialized
DEBUG - 2011-08-30 14:17:58 --> Model Class Initialized
DEBUG - 2011-08-30 14:17:58 --> Model Class Initialized
DEBUG - 2011-08-30 14:17:58 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-30 14:17:58 --> Database Driver Class Initialized
DEBUG - 2011-08-30 14:17:58 --> File loaded: application/views/table/main.php
DEBUG - 2011-08-30 14:17:58 --> Helper loaded: url_helper
DEBUG - 2011-08-30 14:17:58 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-30 14:17:58 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-30 14:17:58 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-30 14:17:58 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-30 14:17:58 --> Final output sent to browser
DEBUG - 2011-08-30 14:17:58 --> Total execution time: 0.2195
DEBUG - 2011-08-30 14:18:06 --> Config Class Initialized
DEBUG - 2011-08-30 14:18:06 --> Hooks Class Initialized
DEBUG - 2011-08-30 14:18:06 --> Utf8 Class Initialized
DEBUG - 2011-08-30 14:18:06 --> UTF-8 Support Enabled
DEBUG - 2011-08-30 14:18:06 --> URI Class Initialized
DEBUG - 2011-08-30 14:18:06 --> Router Class Initialized
ERROR - 2011-08-30 14:18:06 --> 404 Page Not Found --> crossdomain.xml
DEBUG - 2011-08-30 14:18:29 --> Config Class Initialized
DEBUG - 2011-08-30 14:18:29 --> Hooks Class Initialized
DEBUG - 2011-08-30 14:18:29 --> Utf8 Class Initialized
DEBUG - 2011-08-30 14:18:29 --> UTF-8 Support Enabled
DEBUG - 2011-08-30 14:18:29 --> URI Class Initialized
DEBUG - 2011-08-30 14:18:29 --> Router Class Initialized
DEBUG - 2011-08-30 14:18:29 --> Output Class Initialized
DEBUG - 2011-08-30 14:18:29 --> Input Class Initialized
DEBUG - 2011-08-30 14:18:29 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-30 14:18:29 --> Language Class Initialized
DEBUG - 2011-08-30 14:18:29 --> Loader Class Initialized
DEBUG - 2011-08-30 14:18:29 --> Controller Class Initialized
DEBUG - 2011-08-30 14:18:29 --> Model Class Initialized
DEBUG - 2011-08-30 14:18:29 --> Model Class Initialized
DEBUG - 2011-08-30 14:18:29 --> Model Class Initialized
DEBUG - 2011-08-30 14:18:29 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-30 14:18:29 --> Database Driver Class Initialized
DEBUG - 2011-08-30 14:18:29 --> File loaded: application/views/table/main.php
DEBUG - 2011-08-30 14:18:29 --> Helper loaded: url_helper
DEBUG - 2011-08-30 14:18:29 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-30 14:18:29 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-30 14:18:29 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-30 14:18:29 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-30 14:18:29 --> Final output sent to browser
DEBUG - 2011-08-30 14:18:29 --> Total execution time: 0.2732
DEBUG - 2011-08-30 14:18:30 --> Config Class Initialized
DEBUG - 2011-08-30 14:18:30 --> Hooks Class Initialized
DEBUG - 2011-08-30 14:18:30 --> Utf8 Class Initialized
DEBUG - 2011-08-30 14:18:30 --> UTF-8 Support Enabled
DEBUG - 2011-08-30 14:18:30 --> URI Class Initialized
DEBUG - 2011-08-30 14:18:30 --> Router Class Initialized
ERROR - 2011-08-30 14:18:30 --> 404 Page Not Found --> robots.txt
DEBUG - 2011-08-30 14:18:30 --> Config Class Initialized
DEBUG - 2011-08-30 14:18:30 --> Hooks Class Initialized
DEBUG - 2011-08-30 14:18:30 --> Utf8 Class Initialized
DEBUG - 2011-08-30 14:18:30 --> UTF-8 Support Enabled
DEBUG - 2011-08-30 14:18:30 --> URI Class Initialized
DEBUG - 2011-08-30 14:18:30 --> Router Class Initialized
DEBUG - 2011-08-30 14:18:30 --> Output Class Initialized
DEBUG - 2011-08-30 14:18:30 --> Input Class Initialized
DEBUG - 2011-08-30 14:18:30 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-30 14:18:30 --> Language Class Initialized
DEBUG - 2011-08-30 14:18:30 --> Loader Class Initialized
DEBUG - 2011-08-30 14:18:30 --> Controller Class Initialized
DEBUG - 2011-08-30 14:18:30 --> Model Class Initialized
DEBUG - 2011-08-30 14:18:30 --> Model Class Initialized
DEBUG - 2011-08-30 14:18:30 --> Model Class Initialized
DEBUG - 2011-08-30 14:18:30 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-30 14:18:30 --> Database Driver Class Initialized
DEBUG - 2011-08-30 14:18:30 --> File loaded: application/views/table/main.php
DEBUG - 2011-08-30 14:18:30 --> Helper loaded: url_helper
DEBUG - 2011-08-30 14:18:30 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-30 14:18:30 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-30 14:18:30 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-30 14:18:30 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-30 14:18:30 --> Final output sent to browser
DEBUG - 2011-08-30 14:18:30 --> Total execution time: 0.0468
DEBUG - 2011-08-30 14:18:32 --> Config Class Initialized
DEBUG - 2011-08-30 14:18:32 --> Hooks Class Initialized
DEBUG - 2011-08-30 14:18:32 --> Utf8 Class Initialized
DEBUG - 2011-08-30 14:18:32 --> UTF-8 Support Enabled
DEBUG - 2011-08-30 14:18:32 --> URI Class Initialized
DEBUG - 2011-08-30 14:18:32 --> Router Class Initialized
DEBUG - 2011-08-30 14:18:32 --> Output Class Initialized
DEBUG - 2011-08-30 14:18:32 --> Input Class Initialized
DEBUG - 2011-08-30 14:18:32 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-30 14:18:32 --> Language Class Initialized
DEBUG - 2011-08-30 14:18:32 --> Loader Class Initialized
DEBUG - 2011-08-30 14:18:32 --> Controller Class Initialized
DEBUG - 2011-08-30 14:18:32 --> Model Class Initialized
DEBUG - 2011-08-30 14:18:32 --> Model Class Initialized
DEBUG - 2011-08-30 14:18:32 --> Model Class Initialized
DEBUG - 2011-08-30 14:18:32 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-30 14:18:32 --> Database Driver Class Initialized
DEBUG - 2011-08-30 14:18:32 --> File loaded: application/views/table/main.php
DEBUG - 2011-08-30 14:18:32 --> Helper loaded: url_helper
DEBUG - 2011-08-30 14:18:32 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-30 14:18:32 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-30 14:18:32 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-30 14:18:32 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-30 14:18:32 --> Final output sent to browser
DEBUG - 2011-08-30 14:18:32 --> Total execution time: 0.0791
DEBUG - 2011-08-30 14:18:54 --> Config Class Initialized
DEBUG - 2011-08-30 14:18:54 --> Hooks Class Initialized
DEBUG - 2011-08-30 14:18:54 --> Utf8 Class Initialized
DEBUG - 2011-08-30 14:18:54 --> UTF-8 Support Enabled
DEBUG - 2011-08-30 14:18:54 --> URI Class Initialized
DEBUG - 2011-08-30 14:18:54 --> Router Class Initialized
DEBUG - 2011-08-30 14:18:54 --> Output Class Initialized
DEBUG - 2011-08-30 14:18:54 --> Input Class Initialized
DEBUG - 2011-08-30 14:18:54 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-30 14:18:54 --> Language Class Initialized
DEBUG - 2011-08-30 14:18:54 --> Loader Class Initialized
DEBUG - 2011-08-30 14:18:54 --> Controller Class Initialized
DEBUG - 2011-08-30 14:18:54 --> Model Class Initialized
DEBUG - 2011-08-30 14:18:54 --> Model Class Initialized
DEBUG - 2011-08-30 14:18:54 --> Model Class Initialized
DEBUG - 2011-08-30 14:18:54 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-30 14:18:54 --> Database Driver Class Initialized
DEBUG - 2011-08-30 14:18:54 --> File loaded: application/views/table/main.php
DEBUG - 2011-08-30 14:18:54 --> Helper loaded: url_helper
DEBUG - 2011-08-30 14:18:54 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-30 14:18:54 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-30 14:18:54 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-30 14:18:54 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-30 14:18:54 --> Final output sent to browser
DEBUG - 2011-08-30 14:18:54 --> Total execution time: 0.2403
DEBUG - 2011-08-30 14:18:57 --> Config Class Initialized
DEBUG - 2011-08-30 14:18:57 --> Hooks Class Initialized
DEBUG - 2011-08-30 14:18:57 --> Utf8 Class Initialized
DEBUG - 2011-08-30 14:18:57 --> UTF-8 Support Enabled
DEBUG - 2011-08-30 14:18:57 --> URI Class Initialized
DEBUG - 2011-08-30 14:18:57 --> Router Class Initialized
DEBUG - 2011-08-30 14:18:57 --> Output Class Initialized
DEBUG - 2011-08-30 14:18:57 --> Input Class Initialized
DEBUG - 2011-08-30 14:18:57 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-30 14:18:57 --> Language Class Initialized
DEBUG - 2011-08-30 14:18:57 --> Loader Class Initialized
DEBUG - 2011-08-30 14:18:57 --> Controller Class Initialized
DEBUG - 2011-08-30 14:18:57 --> Model Class Initialized
DEBUG - 2011-08-30 14:18:57 --> Model Class Initialized
DEBUG - 2011-08-30 14:18:57 --> Model Class Initialized
DEBUG - 2011-08-30 14:18:57 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-30 14:18:57 --> Database Driver Class Initialized
DEBUG - 2011-08-30 14:18:57 --> File loaded: application/views/table/main.php
DEBUG - 2011-08-30 14:18:57 --> Helper loaded: url_helper
DEBUG - 2011-08-30 14:18:57 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-30 14:18:57 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-30 14:18:57 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-30 14:18:57 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-30 14:18:57 --> Final output sent to browser
DEBUG - 2011-08-30 14:18:57 --> Total execution time: 0.0419
DEBUG - 2011-08-30 14:19:29 --> Config Class Initialized
DEBUG - 2011-08-30 14:19:29 --> Hooks Class Initialized
DEBUG - 2011-08-30 14:19:29 --> Utf8 Class Initialized
DEBUG - 2011-08-30 14:19:29 --> UTF-8 Support Enabled
DEBUG - 2011-08-30 14:19:29 --> URI Class Initialized
DEBUG - 2011-08-30 14:19:29 --> Router Class Initialized
DEBUG - 2011-08-30 14:19:29 --> Output Class Initialized
DEBUG - 2011-08-30 14:19:29 --> Input Class Initialized
DEBUG - 2011-08-30 14:19:29 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-30 14:19:29 --> Language Class Initialized
DEBUG - 2011-08-30 14:19:29 --> Loader Class Initialized
DEBUG - 2011-08-30 14:19:29 --> Controller Class Initialized
DEBUG - 2011-08-30 14:19:29 --> Model Class Initialized
DEBUG - 2011-08-30 14:19:29 --> Model Class Initialized
DEBUG - 2011-08-30 14:19:29 --> Model Class Initialized
DEBUG - 2011-08-30 14:19:29 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-30 14:19:29 --> Database Driver Class Initialized
DEBUG - 2011-08-30 14:19:30 --> File loaded: application/views/table/main.php
DEBUG - 2011-08-30 14:19:30 --> Helper loaded: url_helper
DEBUG - 2011-08-30 14:19:30 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-30 14:19:30 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-30 14:19:30 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-30 14:19:30 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-30 14:19:30 --> Final output sent to browser
DEBUG - 2011-08-30 14:19:30 --> Total execution time: 0.4159
DEBUG - 2011-08-30 14:19:32 --> Config Class Initialized
DEBUG - 2011-08-30 14:19:32 --> Hooks Class Initialized
DEBUG - 2011-08-30 14:19:32 --> Utf8 Class Initialized
DEBUG - 2011-08-30 14:19:32 --> UTF-8 Support Enabled
DEBUG - 2011-08-30 14:19:32 --> URI Class Initialized
DEBUG - 2011-08-30 14:19:32 --> Router Class Initialized
DEBUG - 2011-08-30 14:19:32 --> Output Class Initialized
DEBUG - 2011-08-30 14:19:32 --> Input Class Initialized
DEBUG - 2011-08-30 14:19:32 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-30 14:19:32 --> Language Class Initialized
DEBUG - 2011-08-30 14:19:32 --> Loader Class Initialized
DEBUG - 2011-08-30 14:19:32 --> Controller Class Initialized
DEBUG - 2011-08-30 14:19:32 --> Model Class Initialized
DEBUG - 2011-08-30 14:19:32 --> Model Class Initialized
DEBUG - 2011-08-30 14:19:32 --> Model Class Initialized
DEBUG - 2011-08-30 14:19:32 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-30 14:19:32 --> Database Driver Class Initialized
DEBUG - 2011-08-30 14:19:32 --> File loaded: application/views/table/main.php
DEBUG - 2011-08-30 14:19:32 --> Helper loaded: url_helper
DEBUG - 2011-08-30 14:19:32 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-30 14:19:32 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-30 14:19:32 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-30 14:19:32 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-30 14:19:32 --> Final output sent to browser
DEBUG - 2011-08-30 14:19:32 --> Total execution time: 0.0542
DEBUG - 2011-08-30 14:43:43 --> Config Class Initialized
DEBUG - 2011-08-30 14:43:43 --> Hooks Class Initialized
DEBUG - 2011-08-30 14:43:43 --> Utf8 Class Initialized
DEBUG - 2011-08-30 14:43:43 --> UTF-8 Support Enabled
DEBUG - 2011-08-30 14:43:43 --> URI Class Initialized
DEBUG - 2011-08-30 14:43:43 --> Router Class Initialized
DEBUG - 2011-08-30 14:43:43 --> Output Class Initialized
DEBUG - 2011-08-30 14:43:43 --> Input Class Initialized
DEBUG - 2011-08-30 14:43:43 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-30 14:43:43 --> Language Class Initialized
DEBUG - 2011-08-30 14:43:43 --> Loader Class Initialized
DEBUG - 2011-08-30 14:43:43 --> Controller Class Initialized
ERROR - 2011-08-30 14:43:43 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-08-30 14:43:43 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-08-30 14:43:43 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-08-30 14:43:43 --> Model Class Initialized
DEBUG - 2011-08-30 14:43:43 --> Model Class Initialized
DEBUG - 2011-08-30 14:43:43 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-30 14:43:43 --> Database Driver Class Initialized
DEBUG - 2011-08-30 14:43:43 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-08-30 14:43:43 --> Helper loaded: url_helper
DEBUG - 2011-08-30 14:43:43 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-30 14:43:43 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-30 14:43:43 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-30 14:43:43 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-30 14:43:43 --> Final output sent to browser
DEBUG - 2011-08-30 14:43:43 --> Total execution time: 0.0416
DEBUG - 2011-08-30 15:01:52 --> Config Class Initialized
DEBUG - 2011-08-30 15:01:52 --> Hooks Class Initialized
DEBUG - 2011-08-30 15:01:52 --> Utf8 Class Initialized
DEBUG - 2011-08-30 15:01:52 --> UTF-8 Support Enabled
DEBUG - 2011-08-30 15:01:52 --> URI Class Initialized
DEBUG - 2011-08-30 15:01:52 --> Router Class Initialized
DEBUG - 2011-08-30 15:01:52 --> Output Class Initialized
DEBUG - 2011-08-30 15:01:52 --> Input Class Initialized
DEBUG - 2011-08-30 15:01:52 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-30 15:01:52 --> Language Class Initialized
DEBUG - 2011-08-30 15:01:52 --> Loader Class Initialized
DEBUG - 2011-08-30 15:01:52 --> Controller Class Initialized
ERROR - 2011-08-30 15:01:52 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-08-30 15:01:52 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-08-30 15:01:52 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-08-30 15:01:52 --> Model Class Initialized
DEBUG - 2011-08-30 15:01:52 --> Model Class Initialized
DEBUG - 2011-08-30 15:01:52 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-30 15:01:52 --> Database Driver Class Initialized
DEBUG - 2011-08-30 15:01:52 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-08-30 15:01:52 --> Helper loaded: url_helper
DEBUG - 2011-08-30 15:01:52 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-30 15:01:52 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-30 15:01:52 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-30 15:01:52 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-30 15:01:52 --> Final output sent to browser
DEBUG - 2011-08-30 15:01:52 --> Total execution time: 0.0598
DEBUG - 2011-08-30 15:01:57 --> Config Class Initialized
DEBUG - 2011-08-30 15:01:57 --> Hooks Class Initialized
DEBUG - 2011-08-30 15:01:57 --> Utf8 Class Initialized
DEBUG - 2011-08-30 15:01:57 --> UTF-8 Support Enabled
DEBUG - 2011-08-30 15:01:57 --> URI Class Initialized
DEBUG - 2011-08-30 15:01:57 --> Router Class Initialized
DEBUG - 2011-08-30 15:01:57 --> Output Class Initialized
DEBUG - 2011-08-30 15:01:57 --> Input Class Initialized
DEBUG - 2011-08-30 15:01:57 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-30 15:01:57 --> Language Class Initialized
DEBUG - 2011-08-30 15:01:57 --> Loader Class Initialized
DEBUG - 2011-08-30 15:01:57 --> Controller Class Initialized
DEBUG - 2011-08-30 15:01:57 --> Model Class Initialized
DEBUG - 2011-08-30 15:01:57 --> Model Class Initialized
DEBUG - 2011-08-30 15:01:57 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-30 15:01:57 --> Database Driver Class Initialized
DEBUG - 2011-08-30 15:01:58 --> Final output sent to browser
DEBUG - 2011-08-30 15:01:58 --> Total execution time: 0.5560
DEBUG - 2011-08-30 15:02:05 --> Config Class Initialized
DEBUG - 2011-08-30 15:02:05 --> Hooks Class Initialized
DEBUG - 2011-08-30 15:02:05 --> Utf8 Class Initialized
DEBUG - 2011-08-30 15:02:05 --> UTF-8 Support Enabled
DEBUG - 2011-08-30 15:02:05 --> URI Class Initialized
DEBUG - 2011-08-30 15:02:05 --> Router Class Initialized
ERROR - 2011-08-30 15:02:05 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-08-30 15:02:33 --> Config Class Initialized
DEBUG - 2011-08-30 15:02:33 --> Hooks Class Initialized
DEBUG - 2011-08-30 15:02:33 --> Utf8 Class Initialized
DEBUG - 2011-08-30 15:02:33 --> UTF-8 Support Enabled
DEBUG - 2011-08-30 15:02:33 --> URI Class Initialized
DEBUG - 2011-08-30 15:02:33 --> Router Class Initialized
DEBUG - 2011-08-30 15:02:33 --> Output Class Initialized
DEBUG - 2011-08-30 15:02:33 --> Input Class Initialized
DEBUG - 2011-08-30 15:02:33 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-30 15:02:33 --> Language Class Initialized
DEBUG - 2011-08-30 15:02:33 --> Loader Class Initialized
DEBUG - 2011-08-30 15:02:33 --> Controller Class Initialized
ERROR - 2011-08-30 15:02:33 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-08-30 15:02:33 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-08-30 15:02:33 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-08-30 15:02:33 --> Model Class Initialized
DEBUG - 2011-08-30 15:02:33 --> Model Class Initialized
DEBUG - 2011-08-30 15:02:33 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-30 15:02:33 --> Database Driver Class Initialized
DEBUG - 2011-08-30 15:02:33 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-08-30 15:02:33 --> Helper loaded: url_helper
DEBUG - 2011-08-30 15:02:33 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-30 15:02:33 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-30 15:02:33 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-30 15:02:33 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-30 15:02:33 --> Final output sent to browser
DEBUG - 2011-08-30 15:02:33 --> Total execution time: 0.0719
DEBUG - 2011-08-30 15:02:35 --> Config Class Initialized
DEBUG - 2011-08-30 15:02:35 --> Hooks Class Initialized
DEBUG - 2011-08-30 15:02:35 --> Utf8 Class Initialized
DEBUG - 2011-08-30 15:02:35 --> UTF-8 Support Enabled
DEBUG - 2011-08-30 15:02:35 --> URI Class Initialized
DEBUG - 2011-08-30 15:02:35 --> Router Class Initialized
DEBUG - 2011-08-30 15:02:35 --> Output Class Initialized
DEBUG - 2011-08-30 15:02:35 --> Input Class Initialized
DEBUG - 2011-08-30 15:02:35 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-30 15:02:35 --> Language Class Initialized
DEBUG - 2011-08-30 15:02:35 --> Loader Class Initialized
DEBUG - 2011-08-30 15:02:35 --> Controller Class Initialized
DEBUG - 2011-08-30 15:02:35 --> Model Class Initialized
DEBUG - 2011-08-30 15:02:35 --> Model Class Initialized
DEBUG - 2011-08-30 15:02:35 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-30 15:02:35 --> Database Driver Class Initialized
DEBUG - 2011-08-30 15:02:35 --> Final output sent to browser
DEBUG - 2011-08-30 15:02:35 --> Total execution time: 0.5342
DEBUG - 2011-08-30 15:02:40 --> Config Class Initialized
DEBUG - 2011-08-30 15:02:40 --> Hooks Class Initialized
DEBUG - 2011-08-30 15:02:40 --> Utf8 Class Initialized
DEBUG - 2011-08-30 15:02:40 --> UTF-8 Support Enabled
DEBUG - 2011-08-30 15:02:40 --> URI Class Initialized
DEBUG - 2011-08-30 15:02:40 --> Router Class Initialized
ERROR - 2011-08-30 15:02:40 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-08-30 16:16:21 --> Config Class Initialized
DEBUG - 2011-08-30 16:16:21 --> Hooks Class Initialized
DEBUG - 2011-08-30 16:16:21 --> Utf8 Class Initialized
DEBUG - 2011-08-30 16:16:21 --> UTF-8 Support Enabled
DEBUG - 2011-08-30 16:16:21 --> URI Class Initialized
DEBUG - 2011-08-30 16:16:21 --> Router Class Initialized
DEBUG - 2011-08-30 16:16:21 --> Output Class Initialized
DEBUG - 2011-08-30 16:16:21 --> Input Class Initialized
DEBUG - 2011-08-30 16:16:21 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-30 16:16:21 --> Language Class Initialized
DEBUG - 2011-08-30 16:16:21 --> Loader Class Initialized
DEBUG - 2011-08-30 16:16:21 --> Controller Class Initialized
ERROR - 2011-08-30 16:16:21 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-08-30 16:16:21 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-08-30 16:16:21 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-08-30 16:16:21 --> Model Class Initialized
DEBUG - 2011-08-30 16:16:21 --> Model Class Initialized
DEBUG - 2011-08-30 16:16:21 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-30 16:16:21 --> Database Driver Class Initialized
DEBUG - 2011-08-30 16:16:21 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-08-30 16:16:21 --> Helper loaded: url_helper
DEBUG - 2011-08-30 16:16:21 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-30 16:16:21 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-30 16:16:21 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-30 16:16:21 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-30 16:16:21 --> Final output sent to browser
DEBUG - 2011-08-30 16:16:21 --> Total execution time: 0.0359
DEBUG - 2011-08-30 16:16:21 --> Config Class Initialized
DEBUG - 2011-08-30 16:16:21 --> Hooks Class Initialized
DEBUG - 2011-08-30 16:16:21 --> Utf8 Class Initialized
DEBUG - 2011-08-30 16:16:21 --> UTF-8 Support Enabled
DEBUG - 2011-08-30 16:16:21 --> URI Class Initialized
DEBUG - 2011-08-30 16:16:21 --> Router Class Initialized
DEBUG - 2011-08-30 16:16:21 --> Output Class Initialized
DEBUG - 2011-08-30 16:16:21 --> Input Class Initialized
DEBUG - 2011-08-30 16:16:21 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-30 16:16:21 --> Language Class Initialized
DEBUG - 2011-08-30 16:16:22 --> Loader Class Initialized
DEBUG - 2011-08-30 16:16:22 --> Controller Class Initialized
DEBUG - 2011-08-30 16:16:22 --> Model Class Initialized
DEBUG - 2011-08-30 16:16:22 --> Model Class Initialized
DEBUG - 2011-08-30 16:16:22 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-30 16:16:22 --> Database Driver Class Initialized
DEBUG - 2011-08-30 16:16:22 --> Final output sent to browser
DEBUG - 2011-08-30 16:16:22 --> Total execution time: 0.4985
DEBUG - 2011-08-30 16:16:23 --> Config Class Initialized
DEBUG - 2011-08-30 16:16:23 --> Hooks Class Initialized
DEBUG - 2011-08-30 16:16:23 --> Utf8 Class Initialized
DEBUG - 2011-08-30 16:16:23 --> UTF-8 Support Enabled
DEBUG - 2011-08-30 16:16:23 --> URI Class Initialized
DEBUG - 2011-08-30 16:16:23 --> Router Class Initialized
ERROR - 2011-08-30 16:16:23 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-08-30 16:16:24 --> Config Class Initialized
DEBUG - 2011-08-30 16:16:24 --> Hooks Class Initialized
DEBUG - 2011-08-30 16:16:24 --> Utf8 Class Initialized
DEBUG - 2011-08-30 16:16:24 --> UTF-8 Support Enabled
DEBUG - 2011-08-30 16:16:24 --> URI Class Initialized
DEBUG - 2011-08-30 16:16:24 --> Router Class Initialized
ERROR - 2011-08-30 16:16:24 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-08-30 16:16:34 --> Config Class Initialized
DEBUG - 2011-08-30 16:16:34 --> Hooks Class Initialized
DEBUG - 2011-08-30 16:16:34 --> Utf8 Class Initialized
DEBUG - 2011-08-30 16:16:34 --> UTF-8 Support Enabled
DEBUG - 2011-08-30 16:16:34 --> URI Class Initialized
DEBUG - 2011-08-30 16:16:34 --> Router Class Initialized
DEBUG - 2011-08-30 16:16:34 --> Output Class Initialized
DEBUG - 2011-08-30 16:16:34 --> Input Class Initialized
DEBUG - 2011-08-30 16:16:34 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-30 16:16:34 --> Language Class Initialized
DEBUG - 2011-08-30 16:16:34 --> Loader Class Initialized
DEBUG - 2011-08-30 16:16:34 --> Controller Class Initialized
ERROR - 2011-08-30 16:16:34 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-08-30 16:16:34 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-08-30 16:16:34 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-08-30 16:16:34 --> Model Class Initialized
DEBUG - 2011-08-30 16:16:34 --> Model Class Initialized
DEBUG - 2011-08-30 16:16:34 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-30 16:16:34 --> Database Driver Class Initialized
DEBUG - 2011-08-30 16:16:34 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-08-30 16:16:34 --> Helper loaded: url_helper
DEBUG - 2011-08-30 16:16:34 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-30 16:16:34 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-30 16:16:34 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-30 16:16:34 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-30 16:16:34 --> Final output sent to browser
DEBUG - 2011-08-30 16:16:34 --> Total execution time: 0.0282
DEBUG - 2011-08-30 16:16:35 --> Config Class Initialized
DEBUG - 2011-08-30 16:16:35 --> Hooks Class Initialized
DEBUG - 2011-08-30 16:16:35 --> Utf8 Class Initialized
DEBUG - 2011-08-30 16:16:35 --> UTF-8 Support Enabled
DEBUG - 2011-08-30 16:16:35 --> URI Class Initialized
DEBUG - 2011-08-30 16:16:35 --> Router Class Initialized
DEBUG - 2011-08-30 16:16:35 --> Output Class Initialized
DEBUG - 2011-08-30 16:16:35 --> Input Class Initialized
DEBUG - 2011-08-30 16:16:35 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-30 16:16:35 --> Language Class Initialized
DEBUG - 2011-08-30 16:16:35 --> Loader Class Initialized
DEBUG - 2011-08-30 16:16:35 --> Controller Class Initialized
DEBUG - 2011-08-30 16:16:35 --> Model Class Initialized
DEBUG - 2011-08-30 16:16:35 --> Model Class Initialized
DEBUG - 2011-08-30 16:16:35 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-30 16:16:35 --> Database Driver Class Initialized
DEBUG - 2011-08-30 16:16:35 --> Final output sent to browser
DEBUG - 2011-08-30 16:16:35 --> Total execution time: 0.4908
DEBUG - 2011-08-30 16:16:53 --> Config Class Initialized
DEBUG - 2011-08-30 16:16:53 --> Hooks Class Initialized
DEBUG - 2011-08-30 16:16:53 --> Utf8 Class Initialized
DEBUG - 2011-08-30 16:16:53 --> UTF-8 Support Enabled
DEBUG - 2011-08-30 16:16:53 --> URI Class Initialized
DEBUG - 2011-08-30 16:16:53 --> Router Class Initialized
DEBUG - 2011-08-30 16:16:53 --> Output Class Initialized
DEBUG - 2011-08-30 16:16:53 --> Input Class Initialized
DEBUG - 2011-08-30 16:16:53 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-30 16:16:53 --> Language Class Initialized
DEBUG - 2011-08-30 16:16:53 --> Loader Class Initialized
DEBUG - 2011-08-30 16:16:53 --> Controller Class Initialized
DEBUG - 2011-08-30 16:16:53 --> Model Class Initialized
DEBUG - 2011-08-30 16:16:53 --> Model Class Initialized
DEBUG - 2011-08-30 16:16:53 --> Model Class Initialized
DEBUG - 2011-08-30 16:16:53 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-30 16:16:53 --> Database Driver Class Initialized
DEBUG - 2011-08-30 16:16:54 --> File loaded: application/views/table/main.php
DEBUG - 2011-08-30 16:16:54 --> Helper loaded: url_helper
DEBUG - 2011-08-30 16:16:54 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-30 16:16:54 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-30 16:16:54 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-30 16:16:54 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-30 16:16:54 --> Final output sent to browser
DEBUG - 2011-08-30 16:16:54 --> Total execution time: 0.3736
DEBUG - 2011-08-30 16:16:56 --> Config Class Initialized
DEBUG - 2011-08-30 16:16:56 --> Hooks Class Initialized
DEBUG - 2011-08-30 16:16:56 --> Utf8 Class Initialized
DEBUG - 2011-08-30 16:16:56 --> UTF-8 Support Enabled
DEBUG - 2011-08-30 16:16:56 --> URI Class Initialized
DEBUG - 2011-08-30 16:16:56 --> Router Class Initialized
ERROR - 2011-08-30 16:16:56 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-08-30 16:17:06 --> Config Class Initialized
DEBUG - 2011-08-30 16:17:06 --> Hooks Class Initialized
DEBUG - 2011-08-30 16:17:06 --> Utf8 Class Initialized
DEBUG - 2011-08-30 16:17:06 --> UTF-8 Support Enabled
DEBUG - 2011-08-30 16:17:06 --> URI Class Initialized
DEBUG - 2011-08-30 16:17:06 --> Router Class Initialized
DEBUG - 2011-08-30 16:17:06 --> Output Class Initialized
DEBUG - 2011-08-30 16:17:06 --> Input Class Initialized
DEBUG - 2011-08-30 16:17:06 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-30 16:17:06 --> Language Class Initialized
DEBUG - 2011-08-30 16:17:06 --> Loader Class Initialized
DEBUG - 2011-08-30 16:17:06 --> Controller Class Initialized
DEBUG - 2011-08-30 16:17:06 --> Model Class Initialized
DEBUG - 2011-08-30 16:17:06 --> Model Class Initialized
DEBUG - 2011-08-30 16:17:06 --> Model Class Initialized
DEBUG - 2011-08-30 16:17:06 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-30 16:17:06 --> Database Driver Class Initialized
DEBUG - 2011-08-30 16:17:07 --> File loaded: application/views/table/main.php
DEBUG - 2011-08-30 16:17:07 --> Helper loaded: url_helper
DEBUG - 2011-08-30 16:17:07 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-30 16:17:07 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-30 16:17:07 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-30 16:17:07 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-30 16:17:07 --> Final output sent to browser
DEBUG - 2011-08-30 16:17:07 --> Total execution time: 0.4415
DEBUG - 2011-08-30 16:17:09 --> Config Class Initialized
DEBUG - 2011-08-30 16:17:09 --> Hooks Class Initialized
DEBUG - 2011-08-30 16:17:09 --> Utf8 Class Initialized
DEBUG - 2011-08-30 16:17:09 --> UTF-8 Support Enabled
DEBUG - 2011-08-30 16:17:09 --> URI Class Initialized
DEBUG - 2011-08-30 16:17:09 --> Router Class Initialized
DEBUG - 2011-08-30 16:17:09 --> Output Class Initialized
DEBUG - 2011-08-30 16:17:09 --> Input Class Initialized
DEBUG - 2011-08-30 16:17:09 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-30 16:17:09 --> Language Class Initialized
DEBUG - 2011-08-30 16:17:09 --> Loader Class Initialized
DEBUG - 2011-08-30 16:17:09 --> Controller Class Initialized
DEBUG - 2011-08-30 16:17:09 --> Model Class Initialized
DEBUG - 2011-08-30 16:17:09 --> Model Class Initialized
DEBUG - 2011-08-30 16:17:09 --> Model Class Initialized
DEBUG - 2011-08-30 16:17:09 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-30 16:17:09 --> Database Driver Class Initialized
DEBUG - 2011-08-30 16:17:09 --> File loaded: application/views/table/main.php
DEBUG - 2011-08-30 16:17:09 --> Helper loaded: url_helper
DEBUG - 2011-08-30 16:17:09 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-30 16:17:09 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-30 16:17:09 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-30 16:17:09 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-30 16:17:09 --> Final output sent to browser
DEBUG - 2011-08-30 16:17:09 --> Total execution time: 0.0417
DEBUG - 2011-08-30 16:17:38 --> Config Class Initialized
DEBUG - 2011-08-30 16:17:38 --> Hooks Class Initialized
DEBUG - 2011-08-30 16:17:38 --> Utf8 Class Initialized
DEBUG - 2011-08-30 16:17:38 --> UTF-8 Support Enabled
DEBUG - 2011-08-30 16:17:38 --> URI Class Initialized
DEBUG - 2011-08-30 16:17:38 --> Router Class Initialized
DEBUG - 2011-08-30 16:17:38 --> Output Class Initialized
DEBUG - 2011-08-30 16:17:38 --> Input Class Initialized
DEBUG - 2011-08-30 16:17:38 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-30 16:17:38 --> Language Class Initialized
DEBUG - 2011-08-30 16:17:38 --> Loader Class Initialized
DEBUG - 2011-08-30 16:17:38 --> Controller Class Initialized
DEBUG - 2011-08-30 16:17:38 --> Model Class Initialized
DEBUG - 2011-08-30 16:17:38 --> Model Class Initialized
DEBUG - 2011-08-30 16:17:38 --> Model Class Initialized
DEBUG - 2011-08-30 16:17:38 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-30 16:17:38 --> Database Driver Class Initialized
DEBUG - 2011-08-30 16:17:39 --> File loaded: application/views/table/main.php
DEBUG - 2011-08-30 16:17:39 --> Helper loaded: url_helper
DEBUG - 2011-08-30 16:17:39 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-30 16:17:39 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-30 16:17:39 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-30 16:17:39 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-30 16:17:39 --> Final output sent to browser
DEBUG - 2011-08-30 16:17:39 --> Total execution time: 0.1374
DEBUG - 2011-08-30 16:17:48 --> Config Class Initialized
DEBUG - 2011-08-30 16:17:48 --> Hooks Class Initialized
DEBUG - 2011-08-30 16:17:48 --> Utf8 Class Initialized
DEBUG - 2011-08-30 16:17:48 --> UTF-8 Support Enabled
DEBUG - 2011-08-30 16:17:48 --> URI Class Initialized
DEBUG - 2011-08-30 16:17:48 --> Router Class Initialized
DEBUG - 2011-08-30 16:17:48 --> Output Class Initialized
DEBUG - 2011-08-30 16:17:48 --> Input Class Initialized
DEBUG - 2011-08-30 16:17:48 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-30 16:17:48 --> Language Class Initialized
DEBUG - 2011-08-30 16:17:48 --> Loader Class Initialized
DEBUG - 2011-08-30 16:17:48 --> Controller Class Initialized
DEBUG - 2011-08-30 16:17:48 --> Model Class Initialized
DEBUG - 2011-08-30 16:17:48 --> Model Class Initialized
DEBUG - 2011-08-30 16:17:48 --> Model Class Initialized
DEBUG - 2011-08-30 16:17:48 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-30 16:17:48 --> Database Driver Class Initialized
DEBUG - 2011-08-30 16:17:48 --> File loaded: application/views/table/main.php
DEBUG - 2011-08-30 16:17:48 --> Helper loaded: url_helper
DEBUG - 2011-08-30 16:17:48 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-30 16:17:48 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-30 16:17:48 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-30 16:17:48 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-30 16:17:48 --> Final output sent to browser
DEBUG - 2011-08-30 16:17:48 --> Total execution time: 0.5330
DEBUG - 2011-08-30 16:17:54 --> Config Class Initialized
DEBUG - 2011-08-30 16:17:54 --> Hooks Class Initialized
DEBUG - 2011-08-30 16:17:54 --> Utf8 Class Initialized
DEBUG - 2011-08-30 16:17:54 --> UTF-8 Support Enabled
DEBUG - 2011-08-30 16:17:54 --> URI Class Initialized
DEBUG - 2011-08-30 16:17:54 --> Router Class Initialized
DEBUG - 2011-08-30 16:17:54 --> Output Class Initialized
DEBUG - 2011-08-30 16:17:54 --> Input Class Initialized
DEBUG - 2011-08-30 16:17:54 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-30 16:17:54 --> Language Class Initialized
DEBUG - 2011-08-30 16:17:54 --> Loader Class Initialized
DEBUG - 2011-08-30 16:17:54 --> Controller Class Initialized
DEBUG - 2011-08-30 16:17:54 --> Model Class Initialized
DEBUG - 2011-08-30 16:17:54 --> Model Class Initialized
DEBUG - 2011-08-30 16:17:54 --> Model Class Initialized
DEBUG - 2011-08-30 16:17:54 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-30 16:17:54 --> Database Driver Class Initialized
DEBUG - 2011-08-30 16:17:54 --> File loaded: application/views/table/main.php
DEBUG - 2011-08-30 16:17:54 --> Helper loaded: url_helper
DEBUG - 2011-08-30 16:17:54 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-30 16:17:54 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-30 16:17:54 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-30 16:17:54 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-30 16:17:54 --> Final output sent to browser
DEBUG - 2011-08-30 16:17:54 --> Total execution time: 0.2942
DEBUG - 2011-08-30 16:17:55 --> Config Class Initialized
DEBUG - 2011-08-30 16:17:55 --> Hooks Class Initialized
DEBUG - 2011-08-30 16:17:55 --> Utf8 Class Initialized
DEBUG - 2011-08-30 16:17:55 --> UTF-8 Support Enabled
DEBUG - 2011-08-30 16:17:55 --> URI Class Initialized
DEBUG - 2011-08-30 16:17:55 --> Router Class Initialized
DEBUG - 2011-08-30 16:17:55 --> Output Class Initialized
DEBUG - 2011-08-30 16:17:55 --> Input Class Initialized
DEBUG - 2011-08-30 16:17:55 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-30 16:17:55 --> Language Class Initialized
DEBUG - 2011-08-30 16:17:55 --> Loader Class Initialized
DEBUG - 2011-08-30 16:17:55 --> Controller Class Initialized
DEBUG - 2011-08-30 16:17:55 --> Model Class Initialized
DEBUG - 2011-08-30 16:17:55 --> Model Class Initialized
DEBUG - 2011-08-30 16:17:55 --> Model Class Initialized
DEBUG - 2011-08-30 16:17:55 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-30 16:17:55 --> Database Driver Class Initialized
DEBUG - 2011-08-30 16:17:55 --> File loaded: application/views/table/main.php
DEBUG - 2011-08-30 16:17:55 --> Helper loaded: url_helper
DEBUG - 2011-08-30 16:17:55 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-30 16:17:55 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-30 16:17:55 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-30 16:17:55 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-30 16:17:55 --> Final output sent to browser
DEBUG - 2011-08-30 16:17:55 --> Total execution time: 0.0476
DEBUG - 2011-08-30 16:18:02 --> Config Class Initialized
DEBUG - 2011-08-30 16:18:02 --> Hooks Class Initialized
DEBUG - 2011-08-30 16:18:02 --> Utf8 Class Initialized
DEBUG - 2011-08-30 16:18:02 --> UTF-8 Support Enabled
DEBUG - 2011-08-30 16:18:02 --> URI Class Initialized
DEBUG - 2011-08-30 16:18:02 --> Router Class Initialized
DEBUG - 2011-08-30 16:18:02 --> Output Class Initialized
DEBUG - 2011-08-30 16:18:02 --> Input Class Initialized
DEBUG - 2011-08-30 16:18:02 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-30 16:18:02 --> Language Class Initialized
DEBUG - 2011-08-30 16:18:02 --> Loader Class Initialized
DEBUG - 2011-08-30 16:18:02 --> Controller Class Initialized
DEBUG - 2011-08-30 16:18:02 --> Model Class Initialized
DEBUG - 2011-08-30 16:18:02 --> Model Class Initialized
DEBUG - 2011-08-30 16:18:02 --> Model Class Initialized
DEBUG - 2011-08-30 16:18:02 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-30 16:18:02 --> Database Driver Class Initialized
DEBUG - 2011-08-30 16:18:02 --> File loaded: application/views/table/main.php
DEBUG - 2011-08-30 16:18:02 --> Helper loaded: url_helper
DEBUG - 2011-08-30 16:18:02 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-30 16:18:02 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-30 16:18:02 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-30 16:18:02 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-30 16:18:02 --> Final output sent to browser
DEBUG - 2011-08-30 16:18:02 --> Total execution time: 0.5605
DEBUG - 2011-08-30 16:18:09 --> Config Class Initialized
DEBUG - 2011-08-30 16:18:09 --> Hooks Class Initialized
DEBUG - 2011-08-30 16:18:09 --> Utf8 Class Initialized
DEBUG - 2011-08-30 16:18:09 --> UTF-8 Support Enabled
DEBUG - 2011-08-30 16:18:09 --> URI Class Initialized
DEBUG - 2011-08-30 16:18:09 --> Router Class Initialized
DEBUG - 2011-08-30 16:18:09 --> Output Class Initialized
DEBUG - 2011-08-30 16:18:09 --> Input Class Initialized
DEBUG - 2011-08-30 16:18:09 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-30 16:18:09 --> Language Class Initialized
DEBUG - 2011-08-30 16:18:09 --> Loader Class Initialized
DEBUG - 2011-08-30 16:18:09 --> Controller Class Initialized
DEBUG - 2011-08-30 16:18:09 --> Model Class Initialized
DEBUG - 2011-08-30 16:18:09 --> Model Class Initialized
DEBUG - 2011-08-30 16:18:09 --> Model Class Initialized
DEBUG - 2011-08-30 16:18:09 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-30 16:18:09 --> Database Driver Class Initialized
DEBUG - 2011-08-30 16:18:10 --> File loaded: application/views/table/main.php
DEBUG - 2011-08-30 16:18:10 --> Helper loaded: url_helper
DEBUG - 2011-08-30 16:18:10 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-30 16:18:10 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-30 16:18:10 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-30 16:18:10 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-30 16:18:10 --> Final output sent to browser
DEBUG - 2011-08-30 16:18:10 --> Total execution time: 0.2757
DEBUG - 2011-08-30 16:18:22 --> Config Class Initialized
DEBUG - 2011-08-30 16:18:22 --> Hooks Class Initialized
DEBUG - 2011-08-30 16:18:22 --> Utf8 Class Initialized
DEBUG - 2011-08-30 16:18:22 --> UTF-8 Support Enabled
DEBUG - 2011-08-30 16:18:22 --> URI Class Initialized
DEBUG - 2011-08-30 16:18:22 --> Router Class Initialized
DEBUG - 2011-08-30 16:18:22 --> Output Class Initialized
DEBUG - 2011-08-30 16:18:22 --> Input Class Initialized
DEBUG - 2011-08-30 16:18:22 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-30 16:18:22 --> Language Class Initialized
DEBUG - 2011-08-30 16:18:22 --> Loader Class Initialized
DEBUG - 2011-08-30 16:18:22 --> Controller Class Initialized
DEBUG - 2011-08-30 16:18:22 --> Model Class Initialized
DEBUG - 2011-08-30 16:18:22 --> Model Class Initialized
DEBUG - 2011-08-30 16:18:22 --> Model Class Initialized
DEBUG - 2011-08-30 16:18:22 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-30 16:18:22 --> Database Driver Class Initialized
DEBUG - 2011-08-30 16:18:22 --> File loaded: application/views/table/main.php
DEBUG - 2011-08-30 16:18:22 --> Helper loaded: url_helper
DEBUG - 2011-08-30 16:18:22 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-30 16:18:22 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-30 16:18:22 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-30 16:18:22 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-30 16:18:22 --> Final output sent to browser
DEBUG - 2011-08-30 16:18:22 --> Total execution time: 0.2720
DEBUG - 2011-08-30 16:18:30 --> Config Class Initialized
DEBUG - 2011-08-30 16:18:30 --> Hooks Class Initialized
DEBUG - 2011-08-30 16:18:30 --> Utf8 Class Initialized
DEBUG - 2011-08-30 16:18:30 --> UTF-8 Support Enabled
DEBUG - 2011-08-30 16:18:30 --> URI Class Initialized
DEBUG - 2011-08-30 16:18:30 --> Router Class Initialized
DEBUG - 2011-08-30 16:18:30 --> Output Class Initialized
DEBUG - 2011-08-30 16:18:30 --> Input Class Initialized
DEBUG - 2011-08-30 16:18:30 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-30 16:18:30 --> Language Class Initialized
DEBUG - 2011-08-30 16:18:30 --> Loader Class Initialized
DEBUG - 2011-08-30 16:18:30 --> Controller Class Initialized
DEBUG - 2011-08-30 16:18:30 --> Model Class Initialized
DEBUG - 2011-08-30 16:18:30 --> Model Class Initialized
DEBUG - 2011-08-30 16:18:30 --> Model Class Initialized
DEBUG - 2011-08-30 16:18:30 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-30 16:18:30 --> Database Driver Class Initialized
DEBUG - 2011-08-30 16:18:30 --> File loaded: application/views/table/main.php
DEBUG - 2011-08-30 16:18:30 --> Helper loaded: url_helper
DEBUG - 2011-08-30 16:18:30 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-30 16:18:30 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-30 16:18:30 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-30 16:18:30 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-30 16:18:30 --> Final output sent to browser
DEBUG - 2011-08-30 16:18:30 --> Total execution time: 0.0477
DEBUG - 2011-08-30 16:18:33 --> Config Class Initialized
DEBUG - 2011-08-30 16:18:33 --> Hooks Class Initialized
DEBUG - 2011-08-30 16:18:33 --> Utf8 Class Initialized
DEBUG - 2011-08-30 16:18:33 --> UTF-8 Support Enabled
DEBUG - 2011-08-30 16:18:33 --> URI Class Initialized
DEBUG - 2011-08-30 16:18:33 --> Router Class Initialized
DEBUG - 2011-08-30 16:18:33 --> Output Class Initialized
DEBUG - 2011-08-30 16:18:33 --> Input Class Initialized
DEBUG - 2011-08-30 16:18:33 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-30 16:18:33 --> Language Class Initialized
DEBUG - 2011-08-30 16:18:33 --> Loader Class Initialized
DEBUG - 2011-08-30 16:18:33 --> Controller Class Initialized
DEBUG - 2011-08-30 16:18:33 --> Model Class Initialized
DEBUG - 2011-08-30 16:18:33 --> Model Class Initialized
DEBUG - 2011-08-30 16:18:33 --> Model Class Initialized
DEBUG - 2011-08-30 16:18:33 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-30 16:18:33 --> Database Driver Class Initialized
DEBUG - 2011-08-30 16:18:34 --> File loaded: application/views/table/main.php
DEBUG - 2011-08-30 16:18:34 --> Helper loaded: url_helper
DEBUG - 2011-08-30 16:18:34 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-30 16:18:34 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-30 16:18:34 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-30 16:18:34 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-30 16:18:34 --> Final output sent to browser
DEBUG - 2011-08-30 16:18:34 --> Total execution time: 0.3395
DEBUG - 2011-08-30 16:18:48 --> Config Class Initialized
DEBUG - 2011-08-30 16:18:48 --> Hooks Class Initialized
DEBUG - 2011-08-30 16:18:48 --> Utf8 Class Initialized
DEBUG - 2011-08-30 16:18:48 --> UTF-8 Support Enabled
DEBUG - 2011-08-30 16:18:48 --> URI Class Initialized
DEBUG - 2011-08-30 16:18:48 --> Router Class Initialized
DEBUG - 2011-08-30 16:18:48 --> Output Class Initialized
DEBUG - 2011-08-30 16:18:48 --> Input Class Initialized
DEBUG - 2011-08-30 16:18:48 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-30 16:18:48 --> Language Class Initialized
DEBUG - 2011-08-30 16:18:48 --> Loader Class Initialized
DEBUG - 2011-08-30 16:18:48 --> Controller Class Initialized
DEBUG - 2011-08-30 16:18:48 --> Model Class Initialized
DEBUG - 2011-08-30 16:18:48 --> Model Class Initialized
DEBUG - 2011-08-30 16:18:48 --> Model Class Initialized
DEBUG - 2011-08-30 16:18:48 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-30 16:18:48 --> Database Driver Class Initialized
DEBUG - 2011-08-30 16:18:48 --> File loaded: application/views/table/main.php
DEBUG - 2011-08-30 16:18:48 --> Helper loaded: url_helper
DEBUG - 2011-08-30 16:18:48 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-30 16:18:48 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-30 16:18:48 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-30 16:18:48 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-30 16:18:48 --> Final output sent to browser
DEBUG - 2011-08-30 16:18:48 --> Total execution time: 0.0471
DEBUG - 2011-08-30 16:18:53 --> Config Class Initialized
DEBUG - 2011-08-30 16:18:53 --> Hooks Class Initialized
DEBUG - 2011-08-30 16:18:53 --> Utf8 Class Initialized
DEBUG - 2011-08-30 16:18:53 --> UTF-8 Support Enabled
DEBUG - 2011-08-30 16:18:53 --> URI Class Initialized
DEBUG - 2011-08-30 16:18:53 --> Router Class Initialized
DEBUG - 2011-08-30 16:18:53 --> Output Class Initialized
DEBUG - 2011-08-30 16:18:53 --> Input Class Initialized
DEBUG - 2011-08-30 16:18:53 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-30 16:18:53 --> Language Class Initialized
DEBUG - 2011-08-30 16:18:53 --> Loader Class Initialized
DEBUG - 2011-08-30 16:18:53 --> Controller Class Initialized
DEBUG - 2011-08-30 16:18:53 --> Model Class Initialized
DEBUG - 2011-08-30 16:18:53 --> Model Class Initialized
DEBUG - 2011-08-30 16:18:53 --> Model Class Initialized
DEBUG - 2011-08-30 16:18:53 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-30 16:18:53 --> Database Driver Class Initialized
DEBUG - 2011-08-30 16:18:54 --> File loaded: application/views/table/main.php
DEBUG - 2011-08-30 16:18:54 --> Helper loaded: url_helper
DEBUG - 2011-08-30 16:18:54 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-30 16:18:54 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-30 16:18:54 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-30 16:18:54 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-30 16:18:54 --> Final output sent to browser
DEBUG - 2011-08-30 16:18:54 --> Total execution time: 0.3091
DEBUG - 2011-08-30 16:18:56 --> Config Class Initialized
DEBUG - 2011-08-30 16:18:56 --> Hooks Class Initialized
DEBUG - 2011-08-30 16:18:56 --> Utf8 Class Initialized
DEBUG - 2011-08-30 16:18:56 --> UTF-8 Support Enabled
DEBUG - 2011-08-30 16:18:56 --> URI Class Initialized
DEBUG - 2011-08-30 16:18:56 --> Router Class Initialized
DEBUG - 2011-08-30 16:18:56 --> Output Class Initialized
DEBUG - 2011-08-30 16:18:56 --> Input Class Initialized
DEBUG - 2011-08-30 16:18:56 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-30 16:18:56 --> Language Class Initialized
DEBUG - 2011-08-30 16:18:56 --> Loader Class Initialized
DEBUG - 2011-08-30 16:18:56 --> Controller Class Initialized
DEBUG - 2011-08-30 16:18:56 --> Model Class Initialized
DEBUG - 2011-08-30 16:18:56 --> Model Class Initialized
DEBUG - 2011-08-30 16:18:56 --> Model Class Initialized
DEBUG - 2011-08-30 16:18:56 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-30 16:18:56 --> Database Driver Class Initialized
DEBUG - 2011-08-30 16:18:56 --> File loaded: application/views/table/main.php
DEBUG - 2011-08-30 16:18:56 --> Helper loaded: url_helper
DEBUG - 2011-08-30 16:18:56 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-30 16:18:56 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-30 16:18:56 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-30 16:18:56 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-30 16:18:56 --> Final output sent to browser
DEBUG - 2011-08-30 16:18:56 --> Total execution time: 0.0408
DEBUG - 2011-08-30 16:19:07 --> Config Class Initialized
DEBUG - 2011-08-30 16:19:07 --> Hooks Class Initialized
DEBUG - 2011-08-30 16:19:07 --> Utf8 Class Initialized
DEBUG - 2011-08-30 16:19:07 --> UTF-8 Support Enabled
DEBUG - 2011-08-30 16:19:07 --> URI Class Initialized
DEBUG - 2011-08-30 16:19:07 --> Router Class Initialized
DEBUG - 2011-08-30 16:19:07 --> Output Class Initialized
DEBUG - 2011-08-30 16:19:07 --> Input Class Initialized
DEBUG - 2011-08-30 16:19:07 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-30 16:19:07 --> Language Class Initialized
DEBUG - 2011-08-30 16:19:07 --> Loader Class Initialized
DEBUG - 2011-08-30 16:19:07 --> Controller Class Initialized
DEBUG - 2011-08-30 16:19:07 --> Model Class Initialized
DEBUG - 2011-08-30 16:19:07 --> Model Class Initialized
DEBUG - 2011-08-30 16:19:07 --> Model Class Initialized
DEBUG - 2011-08-30 16:19:07 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-30 16:19:07 --> Database Driver Class Initialized
DEBUG - 2011-08-30 16:19:07 --> File loaded: application/views/table/main.php
DEBUG - 2011-08-30 16:19:07 --> Helper loaded: url_helper
DEBUG - 2011-08-30 16:19:07 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-30 16:19:07 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-30 16:19:07 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-30 16:19:07 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-30 16:19:07 --> Final output sent to browser
DEBUG - 2011-08-30 16:19:07 --> Total execution time: 0.2212
DEBUG - 2011-08-30 16:19:08 --> Config Class Initialized
DEBUG - 2011-08-30 16:19:08 --> Hooks Class Initialized
DEBUG - 2011-08-30 16:19:08 --> Utf8 Class Initialized
DEBUG - 2011-08-30 16:19:08 --> UTF-8 Support Enabled
DEBUG - 2011-08-30 16:19:08 --> URI Class Initialized
DEBUG - 2011-08-30 16:19:08 --> Router Class Initialized
DEBUG - 2011-08-30 16:19:08 --> Output Class Initialized
DEBUG - 2011-08-30 16:19:08 --> Input Class Initialized
DEBUG - 2011-08-30 16:19:08 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-30 16:19:08 --> Language Class Initialized
DEBUG - 2011-08-30 16:19:08 --> Loader Class Initialized
DEBUG - 2011-08-30 16:19:08 --> Controller Class Initialized
DEBUG - 2011-08-30 16:19:08 --> Model Class Initialized
DEBUG - 2011-08-30 16:19:08 --> Model Class Initialized
DEBUG - 2011-08-30 16:19:08 --> Model Class Initialized
DEBUG - 2011-08-30 16:19:08 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-30 16:19:08 --> Database Driver Class Initialized
DEBUG - 2011-08-30 16:19:08 --> File loaded: application/views/table/main.php
DEBUG - 2011-08-30 16:19:08 --> Helper loaded: url_helper
DEBUG - 2011-08-30 16:19:08 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-30 16:19:08 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-30 16:19:08 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-30 16:19:08 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-30 16:19:08 --> Final output sent to browser
DEBUG - 2011-08-30 16:19:08 --> Total execution time: 0.0518
DEBUG - 2011-08-30 16:19:23 --> Config Class Initialized
DEBUG - 2011-08-30 16:19:23 --> Hooks Class Initialized
DEBUG - 2011-08-30 16:19:23 --> Utf8 Class Initialized
DEBUG - 2011-08-30 16:19:23 --> UTF-8 Support Enabled
DEBUG - 2011-08-30 16:19:23 --> URI Class Initialized
DEBUG - 2011-08-30 16:19:23 --> Router Class Initialized
DEBUG - 2011-08-30 16:19:23 --> Output Class Initialized
DEBUG - 2011-08-30 16:19:23 --> Input Class Initialized
DEBUG - 2011-08-30 16:19:23 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-30 16:19:23 --> Language Class Initialized
DEBUG - 2011-08-30 16:19:23 --> Loader Class Initialized
DEBUG - 2011-08-30 16:19:23 --> Controller Class Initialized
DEBUG - 2011-08-30 16:19:23 --> Model Class Initialized
DEBUG - 2011-08-30 16:19:23 --> Model Class Initialized
DEBUG - 2011-08-30 16:19:23 --> Model Class Initialized
DEBUG - 2011-08-30 16:19:23 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-30 16:19:23 --> Database Driver Class Initialized
DEBUG - 2011-08-30 16:19:23 --> File loaded: application/views/table/main.php
DEBUG - 2011-08-30 16:19:23 --> Helper loaded: url_helper
DEBUG - 2011-08-30 16:19:23 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-30 16:19:23 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-30 16:19:23 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-30 16:19:23 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-30 16:19:23 --> Final output sent to browser
DEBUG - 2011-08-30 16:19:23 --> Total execution time: 0.3131
DEBUG - 2011-08-30 16:19:40 --> Config Class Initialized
DEBUG - 2011-08-30 16:19:40 --> Hooks Class Initialized
DEBUG - 2011-08-30 16:19:40 --> Utf8 Class Initialized
DEBUG - 2011-08-30 16:19:40 --> UTF-8 Support Enabled
DEBUG - 2011-08-30 16:19:40 --> URI Class Initialized
DEBUG - 2011-08-30 16:19:40 --> Router Class Initialized
DEBUG - 2011-08-30 16:19:40 --> Output Class Initialized
DEBUG - 2011-08-30 16:19:40 --> Input Class Initialized
DEBUG - 2011-08-30 16:19:40 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-30 16:19:40 --> Language Class Initialized
DEBUG - 2011-08-30 16:19:40 --> Loader Class Initialized
DEBUG - 2011-08-30 16:19:40 --> Controller Class Initialized
DEBUG - 2011-08-30 16:19:40 --> Model Class Initialized
DEBUG - 2011-08-30 16:19:40 --> Model Class Initialized
DEBUG - 2011-08-30 16:19:40 --> Model Class Initialized
DEBUG - 2011-08-30 16:19:40 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-30 16:19:41 --> Database Driver Class Initialized
DEBUG - 2011-08-30 16:19:41 --> File loaded: application/views/table/main.php
DEBUG - 2011-08-30 16:19:41 --> Helper loaded: url_helper
DEBUG - 2011-08-30 16:19:41 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-30 16:19:41 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-30 16:19:41 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-30 16:19:41 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-30 16:19:41 --> Final output sent to browser
DEBUG - 2011-08-30 16:19:41 --> Total execution time: 0.3059
DEBUG - 2011-08-30 16:19:49 --> Config Class Initialized
DEBUG - 2011-08-30 16:19:49 --> Hooks Class Initialized
DEBUG - 2011-08-30 16:19:49 --> Utf8 Class Initialized
DEBUG - 2011-08-30 16:19:49 --> UTF-8 Support Enabled
DEBUG - 2011-08-30 16:19:49 --> URI Class Initialized
DEBUG - 2011-08-30 16:19:49 --> Router Class Initialized
DEBUG - 2011-08-30 16:19:49 --> Output Class Initialized
DEBUG - 2011-08-30 16:19:49 --> Input Class Initialized
DEBUG - 2011-08-30 16:19:49 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-30 16:19:49 --> Language Class Initialized
DEBUG - 2011-08-30 16:19:49 --> Loader Class Initialized
DEBUG - 2011-08-30 16:19:49 --> Controller Class Initialized
DEBUG - 2011-08-30 16:19:49 --> Model Class Initialized
DEBUG - 2011-08-30 16:19:49 --> Model Class Initialized
DEBUG - 2011-08-30 16:19:49 --> Model Class Initialized
DEBUG - 2011-08-30 16:19:49 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-30 16:19:49 --> Database Driver Class Initialized
DEBUG - 2011-08-30 16:19:50 --> File loaded: application/views/table/main.php
DEBUG - 2011-08-30 16:19:50 --> Helper loaded: url_helper
DEBUG - 2011-08-30 16:19:50 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-30 16:19:50 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-30 16:19:50 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-30 16:19:50 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-30 16:19:50 --> Final output sent to browser
DEBUG - 2011-08-30 16:19:50 --> Total execution time: 0.2901
DEBUG - 2011-08-30 16:20:10 --> Config Class Initialized
DEBUG - 2011-08-30 16:20:10 --> Hooks Class Initialized
DEBUG - 2011-08-30 16:20:10 --> Utf8 Class Initialized
DEBUG - 2011-08-30 16:20:10 --> UTF-8 Support Enabled
DEBUG - 2011-08-30 16:20:10 --> URI Class Initialized
DEBUG - 2011-08-30 16:20:10 --> Router Class Initialized
DEBUG - 2011-08-30 16:20:10 --> Output Class Initialized
DEBUG - 2011-08-30 16:20:10 --> Input Class Initialized
DEBUG - 2011-08-30 16:20:10 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-30 16:20:10 --> Language Class Initialized
DEBUG - 2011-08-30 16:20:10 --> Loader Class Initialized
DEBUG - 2011-08-30 16:20:10 --> Controller Class Initialized
DEBUG - 2011-08-30 16:20:10 --> Model Class Initialized
DEBUG - 2011-08-30 16:20:10 --> Model Class Initialized
DEBUG - 2011-08-30 16:20:10 --> Model Class Initialized
DEBUG - 2011-08-30 16:20:10 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-30 16:20:10 --> Database Driver Class Initialized
DEBUG - 2011-08-30 16:20:10 --> File loaded: application/views/table/main.php
DEBUG - 2011-08-30 16:20:10 --> Helper loaded: url_helper
DEBUG - 2011-08-30 16:20:10 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-30 16:20:10 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-30 16:20:10 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-30 16:20:10 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-30 16:20:10 --> Final output sent to browser
DEBUG - 2011-08-30 16:20:10 --> Total execution time: 0.5762
DEBUG - 2011-08-30 16:36:59 --> Config Class Initialized
DEBUG - 2011-08-30 16:36:59 --> Hooks Class Initialized
DEBUG - 2011-08-30 16:36:59 --> Utf8 Class Initialized
DEBUG - 2011-08-30 16:36:59 --> UTF-8 Support Enabled
DEBUG - 2011-08-30 16:36:59 --> URI Class Initialized
DEBUG - 2011-08-30 16:36:59 --> Router Class Initialized
DEBUG - 2011-08-30 16:36:59 --> No URI present. Default controller set.
DEBUG - 2011-08-30 16:36:59 --> Output Class Initialized
DEBUG - 2011-08-30 16:36:59 --> Input Class Initialized
DEBUG - 2011-08-30 16:36:59 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-30 16:36:59 --> Language Class Initialized
DEBUG - 2011-08-30 16:36:59 --> Loader Class Initialized
DEBUG - 2011-08-30 16:36:59 --> Controller Class Initialized
DEBUG - 2011-08-30 16:36:59 --> File loaded: application/views/splash/main.php
DEBUG - 2011-08-30 16:36:59 --> Helper loaded: url_helper
DEBUG - 2011-08-30 16:36:59 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-30 16:36:59 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-30 16:36:59 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-30 16:36:59 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-30 16:36:59 --> Final output sent to browser
DEBUG - 2011-08-30 16:36:59 --> Total execution time: 0.0761
DEBUG - 2011-08-30 16:57:45 --> Config Class Initialized
DEBUG - 2011-08-30 16:57:45 --> Hooks Class Initialized
DEBUG - 2011-08-30 16:57:45 --> Utf8 Class Initialized
DEBUG - 2011-08-30 16:57:45 --> UTF-8 Support Enabled
DEBUG - 2011-08-30 16:57:45 --> URI Class Initialized
DEBUG - 2011-08-30 16:57:45 --> Router Class Initialized
DEBUG - 2011-08-30 16:57:45 --> Output Class Initialized
DEBUG - 2011-08-30 16:57:45 --> Input Class Initialized
DEBUG - 2011-08-30 16:57:45 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-30 16:57:45 --> Language Class Initialized
DEBUG - 2011-08-30 16:57:45 --> Loader Class Initialized
DEBUG - 2011-08-30 16:57:45 --> Controller Class Initialized
ERROR - 2011-08-30 16:57:45 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-08-30 16:57:45 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-08-30 16:57:45 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-08-30 16:57:45 --> Model Class Initialized
DEBUG - 2011-08-30 16:57:45 --> Model Class Initialized
DEBUG - 2011-08-30 16:57:45 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-30 16:57:45 --> Database Driver Class Initialized
DEBUG - 2011-08-30 16:57:45 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-08-30 16:57:45 --> Helper loaded: url_helper
DEBUG - 2011-08-30 16:57:45 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-30 16:57:45 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-30 16:57:45 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-30 16:57:45 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-30 16:57:45 --> Final output sent to browser
DEBUG - 2011-08-30 16:57:45 --> Total execution time: 0.2497
DEBUG - 2011-08-30 16:57:47 --> Config Class Initialized
DEBUG - 2011-08-30 16:57:47 --> Hooks Class Initialized
DEBUG - 2011-08-30 16:57:47 --> Utf8 Class Initialized
DEBUG - 2011-08-30 16:57:47 --> UTF-8 Support Enabled
DEBUG - 2011-08-30 16:57:47 --> URI Class Initialized
DEBUG - 2011-08-30 16:57:47 --> Router Class Initialized
DEBUG - 2011-08-30 16:57:47 --> Output Class Initialized
DEBUG - 2011-08-30 16:57:47 --> Input Class Initialized
DEBUG - 2011-08-30 16:57:47 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-30 16:57:47 --> Language Class Initialized
DEBUG - 2011-08-30 16:57:47 --> Loader Class Initialized
DEBUG - 2011-08-30 16:57:47 --> Controller Class Initialized
DEBUG - 2011-08-30 16:57:47 --> Model Class Initialized
DEBUG - 2011-08-30 16:57:47 --> Model Class Initialized
DEBUG - 2011-08-30 16:57:47 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-30 16:57:47 --> Database Driver Class Initialized
DEBUG - 2011-08-30 16:57:48 --> Final output sent to browser
DEBUG - 2011-08-30 16:57:48 --> Total execution time: 0.6456
DEBUG - 2011-08-30 16:57:49 --> Config Class Initialized
DEBUG - 2011-08-30 16:57:49 --> Hooks Class Initialized
DEBUG - 2011-08-30 16:57:49 --> Utf8 Class Initialized
DEBUG - 2011-08-30 16:57:49 --> UTF-8 Support Enabled
DEBUG - 2011-08-30 16:57:49 --> URI Class Initialized
DEBUG - 2011-08-30 16:57:49 --> Router Class Initialized
ERROR - 2011-08-30 16:57:49 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-08-30 17:04:41 --> Config Class Initialized
DEBUG - 2011-08-30 17:04:41 --> Hooks Class Initialized
DEBUG - 2011-08-30 17:04:41 --> Utf8 Class Initialized
DEBUG - 2011-08-30 17:04:41 --> UTF-8 Support Enabled
DEBUG - 2011-08-30 17:04:41 --> URI Class Initialized
DEBUG - 2011-08-30 17:04:41 --> Router Class Initialized
DEBUG - 2011-08-30 17:04:41 --> Output Class Initialized
DEBUG - 2011-08-30 17:04:41 --> Input Class Initialized
DEBUG - 2011-08-30 17:04:41 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-30 17:04:41 --> Language Class Initialized
DEBUG - 2011-08-30 17:04:41 --> Loader Class Initialized
DEBUG - 2011-08-30 17:04:41 --> Controller Class Initialized
DEBUG - 2011-08-30 17:04:41 --> Model Class Initialized
DEBUG - 2011-08-30 17:04:41 --> Model Class Initialized
DEBUG - 2011-08-30 17:04:41 --> Model Class Initialized
DEBUG - 2011-08-30 17:04:41 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-30 17:04:41 --> Database Driver Class Initialized
DEBUG - 2011-08-30 17:04:41 --> File loaded: application/views/table/main.php
DEBUG - 2011-08-30 17:04:41 --> Helper loaded: url_helper
DEBUG - 2011-08-30 17:04:41 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-30 17:04:41 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-30 17:04:41 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-30 17:04:41 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-30 17:04:41 --> Final output sent to browser
DEBUG - 2011-08-30 17:04:41 --> Total execution time: 0.2540
DEBUG - 2011-08-30 17:04:48 --> Config Class Initialized
DEBUG - 2011-08-30 17:04:48 --> Hooks Class Initialized
DEBUG - 2011-08-30 17:04:48 --> Utf8 Class Initialized
DEBUG - 2011-08-30 17:04:48 --> UTF-8 Support Enabled
DEBUG - 2011-08-30 17:04:48 --> URI Class Initialized
DEBUG - 2011-08-30 17:04:48 --> Router Class Initialized
ERROR - 2011-08-30 17:04:48 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-08-30 17:04:48 --> Config Class Initialized
DEBUG - 2011-08-30 17:04:48 --> Hooks Class Initialized
DEBUG - 2011-08-30 17:04:48 --> Utf8 Class Initialized
DEBUG - 2011-08-30 17:04:48 --> UTF-8 Support Enabled
DEBUG - 2011-08-30 17:04:48 --> URI Class Initialized
DEBUG - 2011-08-30 17:04:48 --> Router Class Initialized
ERROR - 2011-08-30 17:04:48 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-08-30 17:04:49 --> Config Class Initialized
DEBUG - 2011-08-30 17:04:49 --> Hooks Class Initialized
DEBUG - 2011-08-30 17:04:49 --> Utf8 Class Initialized
DEBUG - 2011-08-30 17:04:49 --> UTF-8 Support Enabled
DEBUG - 2011-08-30 17:04:49 --> URI Class Initialized
DEBUG - 2011-08-30 17:04:49 --> Router Class Initialized
ERROR - 2011-08-30 17:04:49 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-08-30 17:05:02 --> Config Class Initialized
DEBUG - 2011-08-30 17:05:02 --> Hooks Class Initialized
DEBUG - 2011-08-30 17:05:02 --> Utf8 Class Initialized
DEBUG - 2011-08-30 17:05:02 --> UTF-8 Support Enabled
DEBUG - 2011-08-30 17:05:02 --> URI Class Initialized
DEBUG - 2011-08-30 17:05:02 --> Router Class Initialized
DEBUG - 2011-08-30 17:05:02 --> Output Class Initialized
DEBUG - 2011-08-30 17:05:02 --> Input Class Initialized
DEBUG - 2011-08-30 17:05:02 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-30 17:05:02 --> Language Class Initialized
DEBUG - 2011-08-30 17:05:02 --> Loader Class Initialized
DEBUG - 2011-08-30 17:05:02 --> Controller Class Initialized
DEBUG - 2011-08-30 17:05:02 --> Model Class Initialized
DEBUG - 2011-08-30 17:05:02 --> Model Class Initialized
DEBUG - 2011-08-30 17:05:02 --> Model Class Initialized
DEBUG - 2011-08-30 17:05:02 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-30 17:05:02 --> Database Driver Class Initialized
DEBUG - 2011-08-30 17:05:03 --> File loaded: application/views/table/main.php
DEBUG - 2011-08-30 17:05:03 --> Helper loaded: url_helper
DEBUG - 2011-08-30 17:05:03 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-30 17:05:03 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-30 17:05:03 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-30 17:05:03 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-30 17:05:03 --> Final output sent to browser
DEBUG - 2011-08-30 17:05:03 --> Total execution time: 0.8702
DEBUG - 2011-08-30 17:05:26 --> Config Class Initialized
DEBUG - 2011-08-30 17:05:26 --> Hooks Class Initialized
DEBUG - 2011-08-30 17:05:26 --> Utf8 Class Initialized
DEBUG - 2011-08-30 17:05:26 --> UTF-8 Support Enabled
DEBUG - 2011-08-30 17:05:26 --> URI Class Initialized
DEBUG - 2011-08-30 17:05:26 --> Router Class Initialized
DEBUG - 2011-08-30 17:05:26 --> Output Class Initialized
DEBUG - 2011-08-30 17:05:26 --> Input Class Initialized
DEBUG - 2011-08-30 17:05:26 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-30 17:05:26 --> Language Class Initialized
DEBUG - 2011-08-30 17:05:26 --> Loader Class Initialized
DEBUG - 2011-08-30 17:05:26 --> Controller Class Initialized
DEBUG - 2011-08-30 17:05:26 --> Model Class Initialized
DEBUG - 2011-08-30 17:05:26 --> Model Class Initialized
DEBUG - 2011-08-30 17:05:26 --> Model Class Initialized
DEBUG - 2011-08-30 17:05:26 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-30 17:05:26 --> Database Driver Class Initialized
DEBUG - 2011-08-30 17:05:26 --> File loaded: application/views/table/main.php
DEBUG - 2011-08-30 17:05:26 --> Helper loaded: url_helper
DEBUG - 2011-08-30 17:05:26 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-30 17:05:26 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-30 17:05:26 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-30 17:05:26 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-30 17:05:26 --> Final output sent to browser
DEBUG - 2011-08-30 17:05:26 --> Total execution time: 0.0772
DEBUG - 2011-08-30 17:05:37 --> Config Class Initialized
DEBUG - 2011-08-30 17:05:37 --> Hooks Class Initialized
DEBUG - 2011-08-30 17:05:37 --> Utf8 Class Initialized
DEBUG - 2011-08-30 17:05:37 --> UTF-8 Support Enabled
DEBUG - 2011-08-30 17:05:37 --> URI Class Initialized
DEBUG - 2011-08-30 17:05:37 --> Router Class Initialized
DEBUG - 2011-08-30 17:05:37 --> Output Class Initialized
DEBUG - 2011-08-30 17:05:37 --> Input Class Initialized
DEBUG - 2011-08-30 17:05:37 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-30 17:05:37 --> Language Class Initialized
DEBUG - 2011-08-30 17:05:37 --> Loader Class Initialized
DEBUG - 2011-08-30 17:05:37 --> Controller Class Initialized
DEBUG - 2011-08-30 17:05:37 --> Model Class Initialized
DEBUG - 2011-08-30 17:05:37 --> Model Class Initialized
DEBUG - 2011-08-30 17:05:37 --> Model Class Initialized
DEBUG - 2011-08-30 17:05:37 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-30 17:05:37 --> Database Driver Class Initialized
DEBUG - 2011-08-30 17:05:37 --> File loaded: application/views/table/main.php
DEBUG - 2011-08-30 17:05:37 --> Helper loaded: url_helper
DEBUG - 2011-08-30 17:05:37 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-30 17:05:37 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-30 17:05:37 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-30 17:05:37 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-30 17:05:37 --> Final output sent to browser
DEBUG - 2011-08-30 17:05:37 --> Total execution time: 0.2342
DEBUG - 2011-08-30 17:05:58 --> Config Class Initialized
DEBUG - 2011-08-30 17:05:58 --> Hooks Class Initialized
DEBUG - 2011-08-30 17:05:58 --> Utf8 Class Initialized
DEBUG - 2011-08-30 17:05:58 --> UTF-8 Support Enabled
DEBUG - 2011-08-30 17:05:58 --> URI Class Initialized
DEBUG - 2011-08-30 17:05:58 --> Router Class Initialized
DEBUG - 2011-08-30 17:05:58 --> Output Class Initialized
DEBUG - 2011-08-30 17:05:58 --> Input Class Initialized
DEBUG - 2011-08-30 17:05:58 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-30 17:05:58 --> Language Class Initialized
DEBUG - 2011-08-30 17:05:58 --> Loader Class Initialized
DEBUG - 2011-08-30 17:05:58 --> Controller Class Initialized
DEBUG - 2011-08-30 17:05:58 --> Model Class Initialized
DEBUG - 2011-08-30 17:05:58 --> Model Class Initialized
DEBUG - 2011-08-30 17:05:58 --> Model Class Initialized
DEBUG - 2011-08-30 17:05:58 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-30 17:05:58 --> Database Driver Class Initialized
DEBUG - 2011-08-30 17:05:58 --> File loaded: application/views/table/main.php
DEBUG - 2011-08-30 17:05:58 --> Helper loaded: url_helper
DEBUG - 2011-08-30 17:05:58 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-30 17:05:58 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-30 17:05:58 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-30 17:05:58 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-30 17:05:58 --> Final output sent to browser
DEBUG - 2011-08-30 17:05:58 --> Total execution time: 0.2728
DEBUG - 2011-08-30 17:06:38 --> Config Class Initialized
DEBUG - 2011-08-30 17:06:38 --> Hooks Class Initialized
DEBUG - 2011-08-30 17:06:38 --> Utf8 Class Initialized
DEBUG - 2011-08-30 17:06:38 --> UTF-8 Support Enabled
DEBUG - 2011-08-30 17:06:38 --> URI Class Initialized
DEBUG - 2011-08-30 17:06:38 --> Router Class Initialized
DEBUG - 2011-08-30 17:06:38 --> Output Class Initialized
DEBUG - 2011-08-30 17:06:38 --> Input Class Initialized
DEBUG - 2011-08-30 17:06:38 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-30 17:06:38 --> Language Class Initialized
DEBUG - 2011-08-30 17:06:38 --> Loader Class Initialized
DEBUG - 2011-08-30 17:06:38 --> Controller Class Initialized
DEBUG - 2011-08-30 17:06:38 --> Model Class Initialized
DEBUG - 2011-08-30 17:06:38 --> Model Class Initialized
DEBUG - 2011-08-30 17:06:38 --> Model Class Initialized
DEBUG - 2011-08-30 17:06:38 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-30 17:06:38 --> Database Driver Class Initialized
DEBUG - 2011-08-30 17:06:38 --> File loaded: application/views/table/main.php
DEBUG - 2011-08-30 17:06:38 --> Helper loaded: url_helper
DEBUG - 2011-08-30 17:06:38 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-30 17:06:38 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-30 17:06:38 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-30 17:06:38 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-30 17:06:38 --> Final output sent to browser
DEBUG - 2011-08-30 17:06:38 --> Total execution time: 0.4082
DEBUG - 2011-08-30 17:06:56 --> Config Class Initialized
DEBUG - 2011-08-30 17:06:56 --> Hooks Class Initialized
DEBUG - 2011-08-30 17:06:56 --> Utf8 Class Initialized
DEBUG - 2011-08-30 17:06:56 --> UTF-8 Support Enabled
DEBUG - 2011-08-30 17:06:56 --> URI Class Initialized
DEBUG - 2011-08-30 17:06:56 --> Router Class Initialized
DEBUG - 2011-08-30 17:06:56 --> Output Class Initialized
DEBUG - 2011-08-30 17:06:56 --> Input Class Initialized
DEBUG - 2011-08-30 17:06:56 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-30 17:06:56 --> Language Class Initialized
DEBUG - 2011-08-30 17:06:56 --> Loader Class Initialized
DEBUG - 2011-08-30 17:06:56 --> Controller Class Initialized
DEBUG - 2011-08-30 17:06:56 --> Model Class Initialized
DEBUG - 2011-08-30 17:06:56 --> Model Class Initialized
DEBUG - 2011-08-30 17:06:56 --> Model Class Initialized
DEBUG - 2011-08-30 17:06:56 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-30 17:06:56 --> Database Driver Class Initialized
DEBUG - 2011-08-30 17:06:56 --> File loaded: application/views/table/main.php
DEBUG - 2011-08-30 17:06:56 --> Helper loaded: url_helper
DEBUG - 2011-08-30 17:06:56 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-30 17:06:56 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-30 17:06:56 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-30 17:06:56 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-30 17:06:56 --> Final output sent to browser
DEBUG - 2011-08-30 17:06:56 --> Total execution time: 0.3194
DEBUG - 2011-08-30 17:07:18 --> Config Class Initialized
DEBUG - 2011-08-30 17:07:18 --> Hooks Class Initialized
DEBUG - 2011-08-30 17:07:18 --> Utf8 Class Initialized
DEBUG - 2011-08-30 17:07:18 --> UTF-8 Support Enabled
DEBUG - 2011-08-30 17:07:18 --> URI Class Initialized
DEBUG - 2011-08-30 17:07:18 --> Router Class Initialized
DEBUG - 2011-08-30 17:07:18 --> Output Class Initialized
DEBUG - 2011-08-30 17:07:18 --> Input Class Initialized
DEBUG - 2011-08-30 17:07:18 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-30 17:07:18 --> Language Class Initialized
DEBUG - 2011-08-30 17:07:18 --> Loader Class Initialized
DEBUG - 2011-08-30 17:07:18 --> Controller Class Initialized
DEBUG - 2011-08-30 17:07:18 --> Model Class Initialized
DEBUG - 2011-08-30 17:07:18 --> Model Class Initialized
DEBUG - 2011-08-30 17:07:18 --> Model Class Initialized
DEBUG - 2011-08-30 17:07:18 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-30 17:07:18 --> Database Driver Class Initialized
DEBUG - 2011-08-30 17:07:18 --> File loaded: application/views/table/main.php
DEBUG - 2011-08-30 17:07:18 --> Helper loaded: url_helper
DEBUG - 2011-08-30 17:07:18 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-30 17:07:18 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-30 17:07:18 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-30 17:07:18 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-30 17:07:18 --> Final output sent to browser
DEBUG - 2011-08-30 17:07:18 --> Total execution time: 0.2368
DEBUG - 2011-08-30 17:07:20 --> Config Class Initialized
DEBUG - 2011-08-30 17:07:20 --> Hooks Class Initialized
DEBUG - 2011-08-30 17:07:20 --> Utf8 Class Initialized
DEBUG - 2011-08-30 17:07:20 --> UTF-8 Support Enabled
DEBUG - 2011-08-30 17:07:20 --> URI Class Initialized
DEBUG - 2011-08-30 17:07:20 --> Router Class Initialized
DEBUG - 2011-08-30 17:07:20 --> Output Class Initialized
DEBUG - 2011-08-30 17:07:20 --> Input Class Initialized
DEBUG - 2011-08-30 17:07:20 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-30 17:07:20 --> Language Class Initialized
DEBUG - 2011-08-30 17:07:20 --> Loader Class Initialized
DEBUG - 2011-08-30 17:07:20 --> Controller Class Initialized
DEBUG - 2011-08-30 17:07:20 --> Model Class Initialized
DEBUG - 2011-08-30 17:07:20 --> Model Class Initialized
DEBUG - 2011-08-30 17:07:20 --> Model Class Initialized
DEBUG - 2011-08-30 17:07:20 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-30 17:07:20 --> Database Driver Class Initialized
DEBUG - 2011-08-30 17:07:20 --> File loaded: application/views/table/main.php
DEBUG - 2011-08-30 17:07:20 --> Helper loaded: url_helper
DEBUG - 2011-08-30 17:07:20 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-30 17:07:20 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-30 17:07:20 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-30 17:07:20 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-30 17:07:20 --> Final output sent to browser
DEBUG - 2011-08-30 17:07:20 --> Total execution time: 0.0438
DEBUG - 2011-08-30 17:07:46 --> Config Class Initialized
DEBUG - 2011-08-30 17:07:46 --> Hooks Class Initialized
DEBUG - 2011-08-30 17:07:46 --> Utf8 Class Initialized
DEBUG - 2011-08-30 17:07:46 --> UTF-8 Support Enabled
DEBUG - 2011-08-30 17:07:46 --> URI Class Initialized
DEBUG - 2011-08-30 17:07:46 --> Router Class Initialized
DEBUG - 2011-08-30 17:07:46 --> Output Class Initialized
DEBUG - 2011-08-30 17:07:46 --> Input Class Initialized
DEBUG - 2011-08-30 17:07:46 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-30 17:07:46 --> Language Class Initialized
DEBUG - 2011-08-30 17:07:46 --> Loader Class Initialized
DEBUG - 2011-08-30 17:07:46 --> Controller Class Initialized
DEBUG - 2011-08-30 17:07:46 --> Model Class Initialized
DEBUG - 2011-08-30 17:07:46 --> Model Class Initialized
DEBUG - 2011-08-30 17:07:46 --> Model Class Initialized
DEBUG - 2011-08-30 17:07:46 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-30 17:07:46 --> Database Driver Class Initialized
DEBUG - 2011-08-30 17:07:47 --> File loaded: application/views/table/main.php
DEBUG - 2011-08-30 17:07:47 --> Helper loaded: url_helper
DEBUG - 2011-08-30 17:07:47 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-30 17:07:47 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-30 17:07:47 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-30 17:07:47 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-30 17:07:47 --> Final output sent to browser
DEBUG - 2011-08-30 17:07:47 --> Total execution time: 0.2093
DEBUG - 2011-08-30 17:08:04 --> Config Class Initialized
DEBUG - 2011-08-30 17:08:04 --> Hooks Class Initialized
DEBUG - 2011-08-30 17:08:04 --> Utf8 Class Initialized
DEBUG - 2011-08-30 17:08:04 --> UTF-8 Support Enabled
DEBUG - 2011-08-30 17:08:04 --> URI Class Initialized
DEBUG - 2011-08-30 17:08:04 --> Router Class Initialized
DEBUG - 2011-08-30 17:08:04 --> Output Class Initialized
DEBUG - 2011-08-30 17:08:04 --> Input Class Initialized
DEBUG - 2011-08-30 17:08:04 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-30 17:08:04 --> Language Class Initialized
DEBUG - 2011-08-30 17:08:04 --> Loader Class Initialized
DEBUG - 2011-08-30 17:08:04 --> Controller Class Initialized
DEBUG - 2011-08-30 17:08:04 --> Model Class Initialized
DEBUG - 2011-08-30 17:08:04 --> Model Class Initialized
DEBUG - 2011-08-30 17:08:04 --> Model Class Initialized
DEBUG - 2011-08-30 17:08:04 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-30 17:08:04 --> Database Driver Class Initialized
DEBUG - 2011-08-30 17:08:04 --> File loaded: application/views/table/main.php
DEBUG - 2011-08-30 17:08:04 --> Helper loaded: url_helper
DEBUG - 2011-08-30 17:08:04 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-30 17:08:04 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-30 17:08:04 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-30 17:08:04 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-30 17:08:04 --> Final output sent to browser
DEBUG - 2011-08-30 17:08:04 --> Total execution time: 0.2498
DEBUG - 2011-08-30 17:08:19 --> Config Class Initialized
DEBUG - 2011-08-30 17:08:19 --> Hooks Class Initialized
DEBUG - 2011-08-30 17:08:19 --> Utf8 Class Initialized
DEBUG - 2011-08-30 17:08:19 --> UTF-8 Support Enabled
DEBUG - 2011-08-30 17:08:19 --> URI Class Initialized
DEBUG - 2011-08-30 17:08:19 --> Router Class Initialized
DEBUG - 2011-08-30 17:08:19 --> Output Class Initialized
DEBUG - 2011-08-30 17:08:19 --> Input Class Initialized
DEBUG - 2011-08-30 17:08:19 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-30 17:08:19 --> Language Class Initialized
DEBUG - 2011-08-30 17:08:19 --> Loader Class Initialized
DEBUG - 2011-08-30 17:08:19 --> Controller Class Initialized
DEBUG - 2011-08-30 17:08:19 --> Model Class Initialized
DEBUG - 2011-08-30 17:08:19 --> Model Class Initialized
DEBUG - 2011-08-30 17:08:19 --> Model Class Initialized
DEBUG - 2011-08-30 17:08:19 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-30 17:08:19 --> Database Driver Class Initialized
DEBUG - 2011-08-30 17:08:19 --> File loaded: application/views/table/main.php
DEBUG - 2011-08-30 17:08:19 --> Helper loaded: url_helper
DEBUG - 2011-08-30 17:08:19 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-30 17:08:19 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-30 17:08:19 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-30 17:08:19 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-30 17:08:19 --> Final output sent to browser
DEBUG - 2011-08-30 17:08:19 --> Total execution time: 0.2811
DEBUG - 2011-08-30 17:09:06 --> Config Class Initialized
DEBUG - 2011-08-30 17:09:06 --> Hooks Class Initialized
DEBUG - 2011-08-30 17:09:06 --> Utf8 Class Initialized
DEBUG - 2011-08-30 17:09:06 --> UTF-8 Support Enabled
DEBUG - 2011-08-30 17:09:06 --> URI Class Initialized
DEBUG - 2011-08-30 17:09:06 --> Router Class Initialized
DEBUG - 2011-08-30 17:09:06 --> Output Class Initialized
DEBUG - 2011-08-30 17:09:06 --> Input Class Initialized
DEBUG - 2011-08-30 17:09:06 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-30 17:09:06 --> Language Class Initialized
DEBUG - 2011-08-30 17:09:06 --> Loader Class Initialized
DEBUG - 2011-08-30 17:09:06 --> Controller Class Initialized
DEBUG - 2011-08-30 17:09:06 --> Model Class Initialized
DEBUG - 2011-08-30 17:09:06 --> Model Class Initialized
DEBUG - 2011-08-30 17:09:06 --> Model Class Initialized
DEBUG - 2011-08-30 17:09:06 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-30 17:09:06 --> Database Driver Class Initialized
DEBUG - 2011-08-30 17:09:06 --> File loaded: application/views/table/main.php
DEBUG - 2011-08-30 17:09:06 --> Helper loaded: url_helper
DEBUG - 2011-08-30 17:09:06 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-30 17:09:06 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-30 17:09:06 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-30 17:09:06 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-30 17:09:06 --> Final output sent to browser
DEBUG - 2011-08-30 17:09:06 --> Total execution time: 0.2722
DEBUG - 2011-08-30 17:09:26 --> Config Class Initialized
DEBUG - 2011-08-30 17:09:26 --> Hooks Class Initialized
DEBUG - 2011-08-30 17:09:26 --> Utf8 Class Initialized
DEBUG - 2011-08-30 17:09:26 --> UTF-8 Support Enabled
DEBUG - 2011-08-30 17:09:26 --> URI Class Initialized
DEBUG - 2011-08-30 17:09:26 --> Router Class Initialized
DEBUG - 2011-08-30 17:09:26 --> Output Class Initialized
DEBUG - 2011-08-30 17:09:26 --> Input Class Initialized
DEBUG - 2011-08-30 17:09:26 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-30 17:09:26 --> Language Class Initialized
DEBUG - 2011-08-30 17:09:26 --> Loader Class Initialized
DEBUG - 2011-08-30 17:09:26 --> Controller Class Initialized
DEBUG - 2011-08-30 17:09:26 --> Model Class Initialized
DEBUG - 2011-08-30 17:09:26 --> Model Class Initialized
DEBUG - 2011-08-30 17:09:26 --> Model Class Initialized
DEBUG - 2011-08-30 17:09:26 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-30 17:09:26 --> Database Driver Class Initialized
DEBUG - 2011-08-30 17:09:27 --> File loaded: application/views/table/main.php
DEBUG - 2011-08-30 17:09:27 --> Helper loaded: url_helper
DEBUG - 2011-08-30 17:09:27 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-30 17:09:27 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-30 17:09:27 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-30 17:09:27 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-30 17:09:27 --> Final output sent to browser
DEBUG - 2011-08-30 17:09:27 --> Total execution time: 0.3324
DEBUG - 2011-08-30 17:09:42 --> Config Class Initialized
DEBUG - 2011-08-30 17:09:42 --> Hooks Class Initialized
DEBUG - 2011-08-30 17:09:42 --> Utf8 Class Initialized
DEBUG - 2011-08-30 17:09:42 --> UTF-8 Support Enabled
DEBUG - 2011-08-30 17:09:42 --> URI Class Initialized
DEBUG - 2011-08-30 17:09:42 --> Router Class Initialized
DEBUG - 2011-08-30 17:09:42 --> Output Class Initialized
DEBUG - 2011-08-30 17:09:42 --> Input Class Initialized
DEBUG - 2011-08-30 17:09:42 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-30 17:09:42 --> Language Class Initialized
DEBUG - 2011-08-30 17:09:42 --> Loader Class Initialized
DEBUG - 2011-08-30 17:09:42 --> Controller Class Initialized
DEBUG - 2011-08-30 17:09:42 --> Model Class Initialized
DEBUG - 2011-08-30 17:09:42 --> Model Class Initialized
DEBUG - 2011-08-30 17:09:42 --> Model Class Initialized
DEBUG - 2011-08-30 17:09:42 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-30 17:09:42 --> Database Driver Class Initialized
DEBUG - 2011-08-30 17:09:42 --> File loaded: application/views/table/main.php
DEBUG - 2011-08-30 17:09:42 --> Helper loaded: url_helper
DEBUG - 2011-08-30 17:09:42 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-30 17:09:42 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-30 17:09:42 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-30 17:09:42 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-30 17:09:42 --> Final output sent to browser
DEBUG - 2011-08-30 17:09:42 --> Total execution time: 0.1076
DEBUG - 2011-08-30 17:09:56 --> Config Class Initialized
DEBUG - 2011-08-30 17:09:56 --> Hooks Class Initialized
DEBUG - 2011-08-30 17:09:56 --> Utf8 Class Initialized
DEBUG - 2011-08-30 17:09:56 --> UTF-8 Support Enabled
DEBUG - 2011-08-30 17:09:56 --> URI Class Initialized
DEBUG - 2011-08-30 17:09:56 --> Router Class Initialized
DEBUG - 2011-08-30 17:09:56 --> Output Class Initialized
DEBUG - 2011-08-30 17:09:56 --> Input Class Initialized
DEBUG - 2011-08-30 17:09:56 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-30 17:09:56 --> Language Class Initialized
DEBUG - 2011-08-30 17:09:56 --> Loader Class Initialized
DEBUG - 2011-08-30 17:09:56 --> Controller Class Initialized
DEBUG - 2011-08-30 17:09:56 --> Model Class Initialized
DEBUG - 2011-08-30 17:09:56 --> Model Class Initialized
DEBUG - 2011-08-30 17:09:56 --> Model Class Initialized
DEBUG - 2011-08-30 17:09:56 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-30 17:09:56 --> Database Driver Class Initialized
DEBUG - 2011-08-30 17:09:56 --> File loaded: application/views/table/main.php
DEBUG - 2011-08-30 17:09:56 --> Helper loaded: url_helper
DEBUG - 2011-08-30 17:09:56 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-30 17:09:56 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-30 17:09:56 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-30 17:09:56 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-30 17:09:56 --> Final output sent to browser
DEBUG - 2011-08-30 17:09:56 --> Total execution time: 0.0833
DEBUG - 2011-08-30 17:10:08 --> Config Class Initialized
DEBUG - 2011-08-30 17:10:08 --> Hooks Class Initialized
DEBUG - 2011-08-30 17:10:08 --> Utf8 Class Initialized
DEBUG - 2011-08-30 17:10:08 --> UTF-8 Support Enabled
DEBUG - 2011-08-30 17:10:08 --> URI Class Initialized
DEBUG - 2011-08-30 17:10:08 --> Router Class Initialized
DEBUG - 2011-08-30 17:10:08 --> Output Class Initialized
DEBUG - 2011-08-30 17:10:08 --> Input Class Initialized
DEBUG - 2011-08-30 17:10:08 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-30 17:10:08 --> Language Class Initialized
DEBUG - 2011-08-30 17:10:08 --> Loader Class Initialized
DEBUG - 2011-08-30 17:10:08 --> Controller Class Initialized
DEBUG - 2011-08-30 17:10:08 --> Model Class Initialized
DEBUG - 2011-08-30 17:10:08 --> Model Class Initialized
DEBUG - 2011-08-30 17:10:08 --> Model Class Initialized
DEBUG - 2011-08-30 17:10:08 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-30 17:10:08 --> Database Driver Class Initialized
DEBUG - 2011-08-30 17:10:08 --> File loaded: application/views/table/main.php
DEBUG - 2011-08-30 17:10:08 --> Helper loaded: url_helper
DEBUG - 2011-08-30 17:10:08 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-30 17:10:08 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-30 17:10:08 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-30 17:10:08 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-30 17:10:08 --> Final output sent to browser
DEBUG - 2011-08-30 17:10:08 --> Total execution time: 0.2174
DEBUG - 2011-08-30 17:10:46 --> Config Class Initialized
DEBUG - 2011-08-30 17:10:46 --> Hooks Class Initialized
DEBUG - 2011-08-30 17:10:46 --> Utf8 Class Initialized
DEBUG - 2011-08-30 17:10:46 --> UTF-8 Support Enabled
DEBUG - 2011-08-30 17:10:46 --> URI Class Initialized
DEBUG - 2011-08-30 17:10:46 --> Router Class Initialized
DEBUG - 2011-08-30 17:10:46 --> Output Class Initialized
DEBUG - 2011-08-30 17:10:46 --> Input Class Initialized
DEBUG - 2011-08-30 17:10:46 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-30 17:10:46 --> Language Class Initialized
DEBUG - 2011-08-30 17:10:46 --> Loader Class Initialized
DEBUG - 2011-08-30 17:10:46 --> Controller Class Initialized
DEBUG - 2011-08-30 17:10:46 --> Model Class Initialized
DEBUG - 2011-08-30 17:10:46 --> Model Class Initialized
DEBUG - 2011-08-30 17:10:46 --> Model Class Initialized
DEBUG - 2011-08-30 17:10:46 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-30 17:10:47 --> Database Driver Class Initialized
DEBUG - 2011-08-30 17:10:47 --> File loaded: application/views/table/main.php
DEBUG - 2011-08-30 17:10:47 --> Helper loaded: url_helper
DEBUG - 2011-08-30 17:10:47 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-30 17:10:47 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-30 17:10:47 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-30 17:10:47 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-30 17:10:47 --> Final output sent to browser
DEBUG - 2011-08-30 17:10:47 --> Total execution time: 0.4836
DEBUG - 2011-08-30 17:11:32 --> Config Class Initialized
DEBUG - 2011-08-30 17:11:32 --> Hooks Class Initialized
DEBUG - 2011-08-30 17:11:32 --> Utf8 Class Initialized
DEBUG - 2011-08-30 17:11:32 --> UTF-8 Support Enabled
DEBUG - 2011-08-30 17:11:32 --> URI Class Initialized
DEBUG - 2011-08-30 17:11:32 --> Router Class Initialized
DEBUG - 2011-08-30 17:11:32 --> Output Class Initialized
DEBUG - 2011-08-30 17:11:32 --> Input Class Initialized
DEBUG - 2011-08-30 17:11:32 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-30 17:11:32 --> Language Class Initialized
DEBUG - 2011-08-30 17:11:32 --> Loader Class Initialized
DEBUG - 2011-08-30 17:11:32 --> Controller Class Initialized
DEBUG - 2011-08-30 17:11:32 --> Model Class Initialized
DEBUG - 2011-08-30 17:11:32 --> Model Class Initialized
DEBUG - 2011-08-30 17:11:32 --> Model Class Initialized
DEBUG - 2011-08-30 17:11:32 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-30 17:11:32 --> Database Driver Class Initialized
DEBUG - 2011-08-30 17:11:34 --> File loaded: application/views/table/main.php
DEBUG - 2011-08-30 17:11:34 --> Helper loaded: url_helper
DEBUG - 2011-08-30 17:11:34 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-30 17:11:34 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-30 17:11:34 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-30 17:11:34 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-30 17:11:34 --> Final output sent to browser
DEBUG - 2011-08-30 17:11:34 --> Total execution time: 1.9886
DEBUG - 2011-08-30 17:12:00 --> Config Class Initialized
DEBUG - 2011-08-30 17:12:00 --> Hooks Class Initialized
DEBUG - 2011-08-30 17:12:00 --> Utf8 Class Initialized
DEBUG - 2011-08-30 17:12:00 --> UTF-8 Support Enabled
DEBUG - 2011-08-30 17:12:00 --> URI Class Initialized
DEBUG - 2011-08-30 17:12:00 --> Router Class Initialized
DEBUG - 2011-08-30 17:12:00 --> Output Class Initialized
DEBUG - 2011-08-30 17:12:00 --> Input Class Initialized
DEBUG - 2011-08-30 17:12:00 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-30 17:12:00 --> Language Class Initialized
DEBUG - 2011-08-30 17:12:00 --> Loader Class Initialized
DEBUG - 2011-08-30 17:12:00 --> Controller Class Initialized
DEBUG - 2011-08-30 17:12:00 --> Model Class Initialized
DEBUG - 2011-08-30 17:12:00 --> Model Class Initialized
DEBUG - 2011-08-30 17:12:00 --> Model Class Initialized
DEBUG - 2011-08-30 17:12:00 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-30 17:12:00 --> Database Driver Class Initialized
DEBUG - 2011-08-30 17:12:00 --> File loaded: application/views/table/main.php
DEBUG - 2011-08-30 17:12:00 --> Helper loaded: url_helper
DEBUG - 2011-08-30 17:12:00 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-30 17:12:00 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-30 17:12:00 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-30 17:12:00 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-30 17:12:00 --> Final output sent to browser
DEBUG - 2011-08-30 17:12:00 --> Total execution time: 0.0932
DEBUG - 2011-08-30 17:12:36 --> Config Class Initialized
DEBUG - 2011-08-30 17:12:36 --> Hooks Class Initialized
DEBUG - 2011-08-30 17:12:36 --> Utf8 Class Initialized
DEBUG - 2011-08-30 17:12:36 --> UTF-8 Support Enabled
DEBUG - 2011-08-30 17:12:36 --> URI Class Initialized
DEBUG - 2011-08-30 17:12:36 --> Router Class Initialized
DEBUG - 2011-08-30 17:12:36 --> Output Class Initialized
DEBUG - 2011-08-30 17:12:36 --> Input Class Initialized
DEBUG - 2011-08-30 17:12:36 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-30 17:12:36 --> Language Class Initialized
DEBUG - 2011-08-30 17:12:36 --> Loader Class Initialized
DEBUG - 2011-08-30 17:12:36 --> Controller Class Initialized
DEBUG - 2011-08-30 17:12:36 --> Model Class Initialized
DEBUG - 2011-08-30 17:12:36 --> Model Class Initialized
DEBUG - 2011-08-30 17:12:36 --> Model Class Initialized
DEBUG - 2011-08-30 17:12:36 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-30 17:12:36 --> Database Driver Class Initialized
DEBUG - 2011-08-30 17:12:36 --> File loaded: application/views/table/main.php
DEBUG - 2011-08-30 17:12:36 --> Helper loaded: url_helper
DEBUG - 2011-08-30 17:12:36 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-30 17:12:36 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-30 17:12:36 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-30 17:12:36 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-30 17:12:36 --> Final output sent to browser
DEBUG - 2011-08-30 17:12:36 --> Total execution time: 0.0502
DEBUG - 2011-08-30 17:12:46 --> Config Class Initialized
DEBUG - 2011-08-30 17:12:46 --> Hooks Class Initialized
DEBUG - 2011-08-30 17:12:46 --> Utf8 Class Initialized
DEBUG - 2011-08-30 17:12:46 --> UTF-8 Support Enabled
DEBUG - 2011-08-30 17:12:46 --> URI Class Initialized
DEBUG - 2011-08-30 17:12:46 --> Router Class Initialized
DEBUG - 2011-08-30 17:12:46 --> Output Class Initialized
DEBUG - 2011-08-30 17:12:46 --> Input Class Initialized
DEBUG - 2011-08-30 17:12:46 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-30 17:12:46 --> Language Class Initialized
DEBUG - 2011-08-30 17:12:46 --> Loader Class Initialized
DEBUG - 2011-08-30 17:12:46 --> Controller Class Initialized
DEBUG - 2011-08-30 17:12:46 --> Model Class Initialized
DEBUG - 2011-08-30 17:12:46 --> Model Class Initialized
DEBUG - 2011-08-30 17:12:46 --> Model Class Initialized
DEBUG - 2011-08-30 17:12:46 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-30 17:12:46 --> Database Driver Class Initialized
DEBUG - 2011-08-30 17:12:46 --> File loaded: application/views/table/main.php
DEBUG - 2011-08-30 17:12:46 --> Helper loaded: url_helper
DEBUG - 2011-08-30 17:12:46 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-30 17:12:46 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-30 17:12:46 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-30 17:12:46 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-30 17:12:46 --> Final output sent to browser
DEBUG - 2011-08-30 17:12:46 --> Total execution time: 0.1091
DEBUG - 2011-08-30 18:11:36 --> Config Class Initialized
DEBUG - 2011-08-30 18:11:36 --> Hooks Class Initialized
DEBUG - 2011-08-30 18:11:36 --> Utf8 Class Initialized
DEBUG - 2011-08-30 18:11:36 --> UTF-8 Support Enabled
DEBUG - 2011-08-30 18:11:36 --> URI Class Initialized
DEBUG - 2011-08-30 18:11:36 --> Router Class Initialized
DEBUG - 2011-08-30 18:11:36 --> No URI present. Default controller set.
DEBUG - 2011-08-30 18:11:36 --> Output Class Initialized
DEBUG - 2011-08-30 18:11:36 --> Input Class Initialized
DEBUG - 2011-08-30 18:11:36 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-30 18:11:36 --> Language Class Initialized
DEBUG - 2011-08-30 18:11:36 --> Loader Class Initialized
DEBUG - 2011-08-30 18:11:36 --> Controller Class Initialized
DEBUG - 2011-08-30 18:11:36 --> File loaded: application/views/splash/main.php
DEBUG - 2011-08-30 18:11:36 --> Helper loaded: url_helper
DEBUG - 2011-08-30 18:11:36 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-30 18:11:36 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-30 18:11:36 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-30 18:11:36 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-30 18:11:36 --> Final output sent to browser
DEBUG - 2011-08-30 18:11:36 --> Total execution time: 0.0640
DEBUG - 2011-08-30 18:12:46 --> Config Class Initialized
DEBUG - 2011-08-30 18:12:46 --> Hooks Class Initialized
DEBUG - 2011-08-30 18:12:46 --> Utf8 Class Initialized
DEBUG - 2011-08-30 18:12:46 --> UTF-8 Support Enabled
DEBUG - 2011-08-30 18:12:46 --> URI Class Initialized
DEBUG - 2011-08-30 18:12:46 --> Router Class Initialized
DEBUG - 2011-08-30 18:12:46 --> Output Class Initialized
DEBUG - 2011-08-30 18:12:46 --> Input Class Initialized
DEBUG - 2011-08-30 18:12:46 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-30 18:12:46 --> Language Class Initialized
DEBUG - 2011-08-30 18:12:46 --> Loader Class Initialized
DEBUG - 2011-08-30 18:12:46 --> Controller Class Initialized
DEBUG - 2011-08-30 18:12:46 --> Model Class Initialized
DEBUG - 2011-08-30 18:12:46 --> Model Class Initialized
DEBUG - 2011-08-30 18:12:46 --> Model Class Initialized
DEBUG - 2011-08-30 18:12:46 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-30 18:12:46 --> Database Driver Class Initialized
DEBUG - 2011-08-30 18:12:46 --> File loaded: application/views/table/main.php
DEBUG - 2011-08-30 18:12:46 --> Helper loaded: url_helper
DEBUG - 2011-08-30 18:12:46 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-30 18:12:46 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-30 18:12:46 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-30 18:12:46 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-30 18:12:46 --> Final output sent to browser
DEBUG - 2011-08-30 18:12:46 --> Total execution time: 0.3212
DEBUG - 2011-08-30 18:12:48 --> Config Class Initialized
DEBUG - 2011-08-30 18:12:48 --> Hooks Class Initialized
DEBUG - 2011-08-30 18:12:48 --> Utf8 Class Initialized
DEBUG - 2011-08-30 18:12:48 --> UTF-8 Support Enabled
DEBUG - 2011-08-30 18:12:48 --> URI Class Initialized
DEBUG - 2011-08-30 18:12:48 --> Router Class Initialized
ERROR - 2011-08-30 18:12:48 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-08-30 18:14:11 --> Config Class Initialized
DEBUG - 2011-08-30 18:14:11 --> Hooks Class Initialized
DEBUG - 2011-08-30 18:14:11 --> Utf8 Class Initialized
DEBUG - 2011-08-30 18:14:11 --> UTF-8 Support Enabled
DEBUG - 2011-08-30 18:14:11 --> URI Class Initialized
DEBUG - 2011-08-30 18:14:11 --> Router Class Initialized
DEBUG - 2011-08-30 18:14:11 --> Output Class Initialized
DEBUG - 2011-08-30 18:14:11 --> Input Class Initialized
DEBUG - 2011-08-30 18:14:11 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-30 18:14:11 --> Language Class Initialized
DEBUG - 2011-08-30 18:14:11 --> Loader Class Initialized
DEBUG - 2011-08-30 18:14:11 --> Controller Class Initialized
DEBUG - 2011-08-30 18:14:11 --> Model Class Initialized
DEBUG - 2011-08-30 18:14:11 --> Model Class Initialized
DEBUG - 2011-08-30 18:14:11 --> Model Class Initialized
DEBUG - 2011-08-30 18:14:11 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-30 18:14:11 --> Database Driver Class Initialized
DEBUG - 2011-08-30 18:14:11 --> File loaded: application/views/table/main.php
DEBUG - 2011-08-30 18:14:11 --> Helper loaded: url_helper
DEBUG - 2011-08-30 18:14:11 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-30 18:14:11 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-30 18:14:11 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-30 18:14:11 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-30 18:14:11 --> Final output sent to browser
DEBUG - 2011-08-30 18:14:11 --> Total execution time: 0.2176
DEBUG - 2011-08-30 19:05:07 --> Config Class Initialized
DEBUG - 2011-08-30 19:05:07 --> Hooks Class Initialized
DEBUG - 2011-08-30 19:05:07 --> Utf8 Class Initialized
DEBUG - 2011-08-30 19:05:07 --> UTF-8 Support Enabled
DEBUG - 2011-08-30 19:05:07 --> URI Class Initialized
DEBUG - 2011-08-30 19:05:07 --> Router Class Initialized
DEBUG - 2011-08-30 19:05:07 --> Output Class Initialized
DEBUG - 2011-08-30 19:05:07 --> Input Class Initialized
DEBUG - 2011-08-30 19:05:07 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-30 19:05:07 --> Language Class Initialized
DEBUG - 2011-08-30 19:05:07 --> Loader Class Initialized
DEBUG - 2011-08-30 19:05:07 --> Controller Class Initialized
DEBUG - 2011-08-30 19:05:07 --> Model Class Initialized
DEBUG - 2011-08-30 19:05:07 --> Model Class Initialized
DEBUG - 2011-08-30 19:05:07 --> Model Class Initialized
DEBUG - 2011-08-30 19:05:07 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-30 19:05:07 --> Database Driver Class Initialized
DEBUG - 2011-08-30 19:05:07 --> File loaded: application/views/table/main.php
DEBUG - 2011-08-30 19:05:07 --> Helper loaded: url_helper
DEBUG - 2011-08-30 19:05:07 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-30 19:05:07 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-30 19:05:07 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-30 19:05:07 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-30 19:05:07 --> Final output sent to browser
DEBUG - 2011-08-30 19:05:07 --> Total execution time: 0.2656
DEBUG - 2011-08-30 19:05:08 --> Config Class Initialized
DEBUG - 2011-08-30 19:05:08 --> Hooks Class Initialized
DEBUG - 2011-08-30 19:05:08 --> Utf8 Class Initialized
DEBUG - 2011-08-30 19:05:08 --> UTF-8 Support Enabled
DEBUG - 2011-08-30 19:05:08 --> URI Class Initialized
DEBUG - 2011-08-30 19:05:08 --> Router Class Initialized
DEBUG - 2011-08-30 19:05:08 --> Output Class Initialized
DEBUG - 2011-08-30 19:05:08 --> Input Class Initialized
DEBUG - 2011-08-30 19:05:08 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-30 19:05:08 --> Language Class Initialized
DEBUG - 2011-08-30 19:05:08 --> Loader Class Initialized
DEBUG - 2011-08-30 19:05:08 --> Controller Class Initialized
ERROR - 2011-08-30 19:05:08 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-08-30 19:05:08 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-08-30 19:05:08 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-08-30 19:05:08 --> Model Class Initialized
DEBUG - 2011-08-30 19:05:08 --> Model Class Initialized
DEBUG - 2011-08-30 19:05:08 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-30 19:05:08 --> Database Driver Class Initialized
DEBUG - 2011-08-30 19:05:08 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-08-30 19:05:08 --> Helper loaded: url_helper
DEBUG - 2011-08-30 19:05:08 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-30 19:05:08 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-30 19:05:08 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-30 19:05:08 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-30 19:05:08 --> Final output sent to browser
DEBUG - 2011-08-30 19:05:08 --> Total execution time: 0.1583
DEBUG - 2011-08-30 19:08:27 --> Config Class Initialized
DEBUG - 2011-08-30 19:08:27 --> Hooks Class Initialized
DEBUG - 2011-08-30 19:08:27 --> Utf8 Class Initialized
DEBUG - 2011-08-30 19:08:27 --> UTF-8 Support Enabled
DEBUG - 2011-08-30 19:08:27 --> URI Class Initialized
DEBUG - 2011-08-30 19:08:27 --> Router Class Initialized
DEBUG - 2011-08-30 19:08:27 --> Output Class Initialized
DEBUG - 2011-08-30 19:08:27 --> Input Class Initialized
DEBUG - 2011-08-30 19:08:27 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-30 19:08:27 --> Language Class Initialized
DEBUG - 2011-08-30 19:08:27 --> Loader Class Initialized
DEBUG - 2011-08-30 19:08:27 --> Controller Class Initialized
ERROR - 2011-08-30 19:08:27 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-08-30 19:08:27 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-08-30 19:08:27 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-08-30 19:08:27 --> Model Class Initialized
DEBUG - 2011-08-30 19:08:27 --> Model Class Initialized
DEBUG - 2011-08-30 19:08:27 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-30 19:08:27 --> Database Driver Class Initialized
DEBUG - 2011-08-30 19:08:27 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-08-30 19:08:27 --> Helper loaded: url_helper
DEBUG - 2011-08-30 19:08:27 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-30 19:08:27 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-30 19:08:27 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-30 19:08:27 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-30 19:08:27 --> Final output sent to browser
DEBUG - 2011-08-30 19:08:27 --> Total execution time: 0.0565
DEBUG - 2011-08-30 20:29:14 --> Config Class Initialized
DEBUG - 2011-08-30 20:29:14 --> Hooks Class Initialized
DEBUG - 2011-08-30 20:29:14 --> Utf8 Class Initialized
DEBUG - 2011-08-30 20:29:14 --> UTF-8 Support Enabled
DEBUG - 2011-08-30 20:29:14 --> URI Class Initialized
DEBUG - 2011-08-30 20:29:14 --> Router Class Initialized
DEBUG - 2011-08-30 20:29:14 --> Output Class Initialized
DEBUG - 2011-08-30 20:29:14 --> Input Class Initialized
DEBUG - 2011-08-30 20:29:14 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-30 20:29:14 --> Language Class Initialized
DEBUG - 2011-08-30 20:29:14 --> Loader Class Initialized
DEBUG - 2011-08-30 20:29:14 --> Controller Class Initialized
ERROR - 2011-08-30 20:29:14 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-08-30 20:29:14 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-08-30 20:29:14 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-08-30 20:29:14 --> Model Class Initialized
DEBUG - 2011-08-30 20:29:14 --> Model Class Initialized
DEBUG - 2011-08-30 20:29:14 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-30 20:29:14 --> Database Driver Class Initialized
DEBUG - 2011-08-30 20:29:14 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-08-30 20:29:14 --> Helper loaded: url_helper
DEBUG - 2011-08-30 20:29:14 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-30 20:29:14 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-30 20:29:14 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-30 20:29:14 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-30 20:29:14 --> Final output sent to browser
DEBUG - 2011-08-30 20:29:14 --> Total execution time: 0.0775
DEBUG - 2011-08-30 20:29:15 --> Config Class Initialized
DEBUG - 2011-08-30 20:29:15 --> Hooks Class Initialized
DEBUG - 2011-08-30 20:29:15 --> Utf8 Class Initialized
DEBUG - 2011-08-30 20:29:15 --> UTF-8 Support Enabled
DEBUG - 2011-08-30 20:29:15 --> URI Class Initialized
DEBUG - 2011-08-30 20:29:15 --> Router Class Initialized
DEBUG - 2011-08-30 20:29:15 --> Output Class Initialized
DEBUG - 2011-08-30 20:29:15 --> Input Class Initialized
DEBUG - 2011-08-30 20:29:15 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-30 20:29:15 --> Language Class Initialized
DEBUG - 2011-08-30 20:29:15 --> Loader Class Initialized
DEBUG - 2011-08-30 20:29:15 --> Controller Class Initialized
DEBUG - 2011-08-30 20:29:15 --> Model Class Initialized
DEBUG - 2011-08-30 20:29:15 --> Model Class Initialized
DEBUG - 2011-08-30 20:29:15 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-30 20:29:15 --> Database Driver Class Initialized
DEBUG - 2011-08-30 20:29:15 --> Config Class Initialized
DEBUG - 2011-08-30 20:29:15 --> Hooks Class Initialized
DEBUG - 2011-08-30 20:29:15 --> Utf8 Class Initialized
DEBUG - 2011-08-30 20:29:15 --> UTF-8 Support Enabled
DEBUG - 2011-08-30 20:29:15 --> URI Class Initialized
DEBUG - 2011-08-30 20:29:15 --> Router Class Initialized
DEBUG - 2011-08-30 20:29:15 --> Output Class Initialized
DEBUG - 2011-08-30 20:29:15 --> Input Class Initialized
DEBUG - 2011-08-30 20:29:15 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-30 20:29:15 --> Language Class Initialized
DEBUG - 2011-08-30 20:29:15 --> Loader Class Initialized
DEBUG - 2011-08-30 20:29:15 --> Controller Class Initialized
DEBUG - 2011-08-30 20:29:15 --> Model Class Initialized
DEBUG - 2011-08-30 20:29:15 --> Model Class Initialized
DEBUG - 2011-08-30 20:29:15 --> Model Class Initialized
DEBUG - 2011-08-30 20:29:15 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-30 20:29:15 --> Database Driver Class Initialized
DEBUG - 2011-08-30 20:29:16 --> Final output sent to browser
DEBUG - 2011-08-30 20:29:16 --> Total execution time: 0.6548
DEBUG - 2011-08-30 20:29:16 --> File loaded: application/views/table/main.php
DEBUG - 2011-08-30 20:29:16 --> Helper loaded: url_helper
DEBUG - 2011-08-30 20:29:16 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-30 20:29:16 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-30 20:29:16 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-30 20:29:16 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-30 20:29:16 --> Final output sent to browser
DEBUG - 2011-08-30 20:29:16 --> Total execution time: 0.2419
DEBUG - 2011-08-30 20:29:17 --> Config Class Initialized
DEBUG - 2011-08-30 20:29:17 --> Hooks Class Initialized
DEBUG - 2011-08-30 20:29:17 --> Utf8 Class Initialized
DEBUG - 2011-08-30 20:29:17 --> UTF-8 Support Enabled
DEBUG - 2011-08-30 20:29:17 --> URI Class Initialized
DEBUG - 2011-08-30 20:29:17 --> Router Class Initialized
ERROR - 2011-08-30 20:29:17 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-08-30 20:29:17 --> Config Class Initialized
DEBUG - 2011-08-30 20:29:17 --> Hooks Class Initialized
DEBUG - 2011-08-30 20:29:17 --> Utf8 Class Initialized
DEBUG - 2011-08-30 20:29:17 --> UTF-8 Support Enabled
DEBUG - 2011-08-30 20:29:17 --> URI Class Initialized
DEBUG - 2011-08-30 20:29:17 --> Router Class Initialized
ERROR - 2011-08-30 20:29:17 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-08-30 21:54:08 --> Config Class Initialized
DEBUG - 2011-08-30 21:54:08 --> Hooks Class Initialized
DEBUG - 2011-08-30 21:54:08 --> Utf8 Class Initialized
DEBUG - 2011-08-30 21:54:08 --> UTF-8 Support Enabled
DEBUG - 2011-08-30 21:54:08 --> URI Class Initialized
DEBUG - 2011-08-30 21:54:08 --> Router Class Initialized
DEBUG - 2011-08-30 21:54:08 --> Output Class Initialized
DEBUG - 2011-08-30 21:54:08 --> Input Class Initialized
DEBUG - 2011-08-30 21:54:08 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-30 21:54:08 --> Language Class Initialized
DEBUG - 2011-08-30 21:54:08 --> Loader Class Initialized
DEBUG - 2011-08-30 21:54:08 --> Controller Class Initialized
ERROR - 2011-08-30 21:54:08 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-08-30 21:54:08 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-08-30 21:54:08 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-08-30 21:54:08 --> Model Class Initialized
DEBUG - 2011-08-30 21:54:08 --> Model Class Initialized
DEBUG - 2011-08-30 21:54:08 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-30 21:54:08 --> Database Driver Class Initialized
DEBUG - 2011-08-30 21:54:08 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-08-30 21:54:08 --> Helper loaded: url_helper
DEBUG - 2011-08-30 21:54:08 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-30 21:54:08 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-30 21:54:08 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-30 21:54:08 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-30 21:54:08 --> Final output sent to browser
DEBUG - 2011-08-30 21:54:08 --> Total execution time: 0.0971
DEBUG - 2011-08-30 21:54:09 --> Config Class Initialized
DEBUG - 2011-08-30 21:54:09 --> Hooks Class Initialized
DEBUG - 2011-08-30 21:54:09 --> Utf8 Class Initialized
DEBUG - 2011-08-30 21:54:09 --> UTF-8 Support Enabled
DEBUG - 2011-08-30 21:54:09 --> URI Class Initialized
DEBUG - 2011-08-30 21:54:09 --> Router Class Initialized
DEBUG - 2011-08-30 21:54:09 --> Output Class Initialized
DEBUG - 2011-08-30 21:54:09 --> Input Class Initialized
DEBUG - 2011-08-30 21:54:09 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-30 21:54:09 --> Language Class Initialized
DEBUG - 2011-08-30 21:54:09 --> Loader Class Initialized
DEBUG - 2011-08-30 21:54:09 --> Controller Class Initialized
DEBUG - 2011-08-30 21:54:09 --> Model Class Initialized
DEBUG - 2011-08-30 21:54:09 --> Model Class Initialized
DEBUG - 2011-08-30 21:54:09 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-30 21:54:09 --> Database Driver Class Initialized
DEBUG - 2011-08-30 21:54:10 --> Final output sent to browser
DEBUG - 2011-08-30 21:54:10 --> Total execution time: 0.7010
DEBUG - 2011-08-30 21:55:03 --> Config Class Initialized
DEBUG - 2011-08-30 21:55:03 --> Hooks Class Initialized
DEBUG - 2011-08-30 21:55:03 --> Utf8 Class Initialized
DEBUG - 2011-08-30 21:55:03 --> UTF-8 Support Enabled
DEBUG - 2011-08-30 21:55:03 --> URI Class Initialized
DEBUG - 2011-08-30 21:55:03 --> Router Class Initialized
DEBUG - 2011-08-30 21:55:03 --> Output Class Initialized
DEBUG - 2011-08-30 21:55:03 --> Input Class Initialized
DEBUG - 2011-08-30 21:55:03 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-30 21:55:03 --> Language Class Initialized
DEBUG - 2011-08-30 21:55:03 --> Loader Class Initialized
DEBUG - 2011-08-30 21:55:03 --> Controller Class Initialized
ERROR - 2011-08-30 21:55:03 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-08-30 21:55:03 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-08-30 21:55:03 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-08-30 21:55:03 --> Model Class Initialized
DEBUG - 2011-08-30 21:55:03 --> Model Class Initialized
DEBUG - 2011-08-30 21:55:03 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-30 21:55:03 --> Database Driver Class Initialized
DEBUG - 2011-08-30 21:55:03 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-08-30 21:55:03 --> Helper loaded: url_helper
DEBUG - 2011-08-30 21:55:03 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-30 21:55:03 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-30 21:55:03 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-30 21:55:03 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-30 21:55:03 --> Final output sent to browser
DEBUG - 2011-08-30 21:55:03 --> Total execution time: 0.0649
DEBUG - 2011-08-30 21:55:05 --> Config Class Initialized
DEBUG - 2011-08-30 21:55:05 --> Hooks Class Initialized
DEBUG - 2011-08-30 21:55:05 --> Utf8 Class Initialized
DEBUG - 2011-08-30 21:55:05 --> UTF-8 Support Enabled
DEBUG - 2011-08-30 21:55:05 --> URI Class Initialized
DEBUG - 2011-08-30 21:55:05 --> Router Class Initialized
DEBUG - 2011-08-30 21:55:05 --> Output Class Initialized
DEBUG - 2011-08-30 21:55:05 --> Input Class Initialized
DEBUG - 2011-08-30 21:55:05 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-30 21:55:05 --> Language Class Initialized
DEBUG - 2011-08-30 21:55:05 --> Loader Class Initialized
DEBUG - 2011-08-30 21:55:05 --> Controller Class Initialized
DEBUG - 2011-08-30 21:55:05 --> Model Class Initialized
DEBUG - 2011-08-30 21:55:05 --> Model Class Initialized
DEBUG - 2011-08-30 21:55:05 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-30 21:55:05 --> Database Driver Class Initialized
DEBUG - 2011-08-30 21:55:05 --> Final output sent to browser
DEBUG - 2011-08-30 21:55:05 --> Total execution time: 0.6984
DEBUG - 2011-08-30 21:55:06 --> Config Class Initialized
DEBUG - 2011-08-30 21:55:06 --> Hooks Class Initialized
DEBUG - 2011-08-30 21:55:06 --> Utf8 Class Initialized
DEBUG - 2011-08-30 21:55:06 --> UTF-8 Support Enabled
DEBUG - 2011-08-30 21:55:06 --> URI Class Initialized
DEBUG - 2011-08-30 21:55:06 --> Router Class Initialized
DEBUG - 2011-08-30 21:55:06 --> Output Class Initialized
DEBUG - 2011-08-30 21:55:06 --> Input Class Initialized
DEBUG - 2011-08-30 21:55:06 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-30 21:55:06 --> Language Class Initialized
DEBUG - 2011-08-30 21:55:06 --> Loader Class Initialized
DEBUG - 2011-08-30 21:55:06 --> Controller Class Initialized
ERROR - 2011-08-30 21:55:06 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-08-30 21:55:06 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-08-30 21:55:06 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-08-30 21:55:06 --> Model Class Initialized
DEBUG - 2011-08-30 21:55:06 --> Model Class Initialized
DEBUG - 2011-08-30 21:55:06 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-30 21:55:06 --> Database Driver Class Initialized
DEBUG - 2011-08-30 21:55:06 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-08-30 21:55:06 --> Helper loaded: url_helper
DEBUG - 2011-08-30 21:55:06 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-30 21:55:06 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-30 21:55:06 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-30 21:55:06 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-30 21:55:06 --> Final output sent to browser
DEBUG - 2011-08-30 21:55:06 --> Total execution time: 0.0294
DEBUG - 2011-08-30 21:55:19 --> Config Class Initialized
DEBUG - 2011-08-30 21:55:19 --> Hooks Class Initialized
DEBUG - 2011-08-30 21:55:19 --> Utf8 Class Initialized
DEBUG - 2011-08-30 21:55:19 --> UTF-8 Support Enabled
DEBUG - 2011-08-30 21:55:19 --> URI Class Initialized
DEBUG - 2011-08-30 21:55:19 --> Router Class Initialized
DEBUG - 2011-08-30 21:55:19 --> Output Class Initialized
DEBUG - 2011-08-30 21:55:19 --> Input Class Initialized
DEBUG - 2011-08-30 21:55:19 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-30 21:55:19 --> Language Class Initialized
DEBUG - 2011-08-30 21:55:19 --> Loader Class Initialized
DEBUG - 2011-08-30 21:55:19 --> Controller Class Initialized
ERROR - 2011-08-30 21:55:19 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-08-30 21:55:19 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-08-30 21:55:19 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-08-30 21:55:19 --> Model Class Initialized
DEBUG - 2011-08-30 21:55:19 --> Model Class Initialized
DEBUG - 2011-08-30 21:55:19 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-30 21:55:19 --> Database Driver Class Initialized
DEBUG - 2011-08-30 21:55:19 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-08-30 21:55:19 --> Helper loaded: url_helper
DEBUG - 2011-08-30 21:55:19 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-30 21:55:19 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-30 21:55:19 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-30 21:55:19 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-30 21:55:19 --> Final output sent to browser
DEBUG - 2011-08-30 21:55:19 --> Total execution time: 0.0284
DEBUG - 2011-08-30 21:55:20 --> Config Class Initialized
DEBUG - 2011-08-30 21:55:20 --> Hooks Class Initialized
DEBUG - 2011-08-30 21:55:20 --> Utf8 Class Initialized
DEBUG - 2011-08-30 21:55:20 --> UTF-8 Support Enabled
DEBUG - 2011-08-30 21:55:20 --> URI Class Initialized
DEBUG - 2011-08-30 21:55:20 --> Router Class Initialized
DEBUG - 2011-08-30 21:55:20 --> Output Class Initialized
DEBUG - 2011-08-30 21:55:20 --> Input Class Initialized
DEBUG - 2011-08-30 21:55:20 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-30 21:55:20 --> Language Class Initialized
DEBUG - 2011-08-30 21:55:20 --> Loader Class Initialized
DEBUG - 2011-08-30 21:55:20 --> Controller Class Initialized
DEBUG - 2011-08-30 21:55:20 --> Model Class Initialized
DEBUG - 2011-08-30 21:55:20 --> Model Class Initialized
DEBUG - 2011-08-30 21:55:20 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-30 21:55:20 --> Database Driver Class Initialized
DEBUG - 2011-08-30 21:55:20 --> Final output sent to browser
DEBUG - 2011-08-30 21:55:20 --> Total execution time: 0.7353
DEBUG - 2011-08-30 21:55:54 --> Config Class Initialized
DEBUG - 2011-08-30 21:55:54 --> Hooks Class Initialized
DEBUG - 2011-08-30 21:55:54 --> Utf8 Class Initialized
DEBUG - 2011-08-30 21:55:54 --> UTF-8 Support Enabled
DEBUG - 2011-08-30 21:55:54 --> URI Class Initialized
DEBUG - 2011-08-30 21:55:54 --> Router Class Initialized
DEBUG - 2011-08-30 21:55:54 --> Output Class Initialized
DEBUG - 2011-08-30 21:55:54 --> Input Class Initialized
DEBUG - 2011-08-30 21:55:54 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-30 21:55:54 --> Language Class Initialized
DEBUG - 2011-08-30 21:55:54 --> Loader Class Initialized
DEBUG - 2011-08-30 21:55:54 --> Controller Class Initialized
ERROR - 2011-08-30 21:55:54 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-08-30 21:55:54 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-08-30 21:55:54 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-08-30 21:55:54 --> Model Class Initialized
DEBUG - 2011-08-30 21:55:54 --> Model Class Initialized
DEBUG - 2011-08-30 21:55:54 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-30 21:55:55 --> Database Driver Class Initialized
DEBUG - 2011-08-30 21:55:55 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-08-30 21:55:55 --> Helper loaded: url_helper
DEBUG - 2011-08-30 21:55:55 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-30 21:55:55 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-30 21:55:55 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-30 21:55:55 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-30 21:55:55 --> Final output sent to browser
DEBUG - 2011-08-30 21:55:55 --> Total execution time: 0.0291
DEBUG - 2011-08-30 21:55:55 --> Config Class Initialized
DEBUG - 2011-08-30 21:55:55 --> Hooks Class Initialized
DEBUG - 2011-08-30 21:55:55 --> Utf8 Class Initialized
DEBUG - 2011-08-30 21:55:55 --> UTF-8 Support Enabled
DEBUG - 2011-08-30 21:55:55 --> URI Class Initialized
DEBUG - 2011-08-30 21:55:55 --> Router Class Initialized
DEBUG - 2011-08-30 21:55:55 --> Output Class Initialized
DEBUG - 2011-08-30 21:55:55 --> Input Class Initialized
DEBUG - 2011-08-30 21:55:55 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-30 21:55:55 --> Language Class Initialized
DEBUG - 2011-08-30 21:55:55 --> Loader Class Initialized
DEBUG - 2011-08-30 21:55:55 --> Controller Class Initialized
DEBUG - 2011-08-30 21:55:55 --> Model Class Initialized
DEBUG - 2011-08-30 21:55:55 --> Model Class Initialized
DEBUG - 2011-08-30 21:55:55 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-30 21:55:55 --> Database Driver Class Initialized
DEBUG - 2011-08-30 21:55:56 --> Final output sent to browser
DEBUG - 2011-08-30 21:55:56 --> Total execution time: 0.5203
DEBUG - 2011-08-30 22:46:32 --> Config Class Initialized
DEBUG - 2011-08-30 22:46:32 --> Hooks Class Initialized
DEBUG - 2011-08-30 22:46:32 --> Utf8 Class Initialized
DEBUG - 2011-08-30 22:46:32 --> UTF-8 Support Enabled
DEBUG - 2011-08-30 22:46:32 --> URI Class Initialized
DEBUG - 2011-08-30 22:46:32 --> Router Class Initialized
DEBUG - 2011-08-30 22:46:32 --> Output Class Initialized
DEBUG - 2011-08-30 22:46:32 --> Input Class Initialized
DEBUG - 2011-08-30 22:46:32 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-30 22:46:32 --> Language Class Initialized
DEBUG - 2011-08-30 22:46:32 --> Loader Class Initialized
DEBUG - 2011-08-30 22:46:32 --> Controller Class Initialized
DEBUG - 2011-08-30 22:46:32 --> Model Class Initialized
DEBUG - 2011-08-30 22:46:32 --> Model Class Initialized
DEBUG - 2011-08-30 22:46:32 --> Model Class Initialized
DEBUG - 2011-08-30 22:46:32 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-30 22:46:32 --> Database Driver Class Initialized
DEBUG - 2011-08-30 22:46:32 --> File loaded: application/views/table/main.php
DEBUG - 2011-08-30 22:46:32 --> Helper loaded: url_helper
DEBUG - 2011-08-30 22:46:32 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-30 22:46:32 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-30 22:46:32 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-30 22:46:32 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-30 22:46:32 --> Final output sent to browser
DEBUG - 2011-08-30 22:46:32 --> Total execution time: 0.2556
DEBUG - 2011-08-30 22:46:35 --> Config Class Initialized
DEBUG - 2011-08-30 22:46:35 --> Hooks Class Initialized
DEBUG - 2011-08-30 22:46:35 --> Utf8 Class Initialized
DEBUG - 2011-08-30 22:46:35 --> UTF-8 Support Enabled
DEBUG - 2011-08-30 22:46:35 --> URI Class Initialized
DEBUG - 2011-08-30 22:46:35 --> Router Class Initialized
ERROR - 2011-08-30 22:46:35 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-08-30 22:46:36 --> Config Class Initialized
DEBUG - 2011-08-30 22:46:36 --> Hooks Class Initialized
DEBUG - 2011-08-30 22:46:36 --> Utf8 Class Initialized
DEBUG - 2011-08-30 22:46:36 --> UTF-8 Support Enabled
DEBUG - 2011-08-30 22:46:36 --> URI Class Initialized
DEBUG - 2011-08-30 22:46:36 --> Router Class Initialized
ERROR - 2011-08-30 22:46:36 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-08-30 22:46:45 --> Config Class Initialized
DEBUG - 2011-08-30 22:46:45 --> Hooks Class Initialized
DEBUG - 2011-08-30 22:46:45 --> Utf8 Class Initialized
DEBUG - 2011-08-30 22:46:45 --> UTF-8 Support Enabled
DEBUG - 2011-08-30 22:46:45 --> URI Class Initialized
DEBUG - 2011-08-30 22:46:45 --> Router Class Initialized
DEBUG - 2011-08-30 22:46:45 --> Output Class Initialized
DEBUG - 2011-08-30 22:46:45 --> Input Class Initialized
DEBUG - 2011-08-30 22:46:45 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-30 22:46:45 --> Language Class Initialized
DEBUG - 2011-08-30 22:46:45 --> Loader Class Initialized
DEBUG - 2011-08-30 22:46:45 --> Controller Class Initialized
DEBUG - 2011-08-30 22:46:45 --> Model Class Initialized
DEBUG - 2011-08-30 22:46:45 --> Model Class Initialized
DEBUG - 2011-08-30 22:46:45 --> Model Class Initialized
DEBUG - 2011-08-30 22:46:45 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-30 22:46:45 --> Database Driver Class Initialized
DEBUG - 2011-08-30 22:46:45 --> File loaded: application/views/table/main.php
DEBUG - 2011-08-30 22:46:45 --> Helper loaded: url_helper
DEBUG - 2011-08-30 22:46:45 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-30 22:46:45 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-30 22:46:45 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-30 22:46:45 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-30 22:46:45 --> Final output sent to browser
DEBUG - 2011-08-30 22:46:45 --> Total execution time: 0.0537
DEBUG - 2011-08-30 22:46:48 --> Config Class Initialized
DEBUG - 2011-08-30 22:46:48 --> Hooks Class Initialized
DEBUG - 2011-08-30 22:46:48 --> Utf8 Class Initialized
DEBUG - 2011-08-30 22:46:48 --> UTF-8 Support Enabled
DEBUG - 2011-08-30 22:46:48 --> URI Class Initialized
DEBUG - 2011-08-30 22:46:48 --> Router Class Initialized
ERROR - 2011-08-30 22:46:48 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-08-30 22:46:52 --> Config Class Initialized
DEBUG - 2011-08-30 22:46:52 --> Hooks Class Initialized
DEBUG - 2011-08-30 22:46:52 --> Utf8 Class Initialized
DEBUG - 2011-08-30 22:46:52 --> UTF-8 Support Enabled
DEBUG - 2011-08-30 22:46:52 --> URI Class Initialized
DEBUG - 2011-08-30 22:46:52 --> Router Class Initialized
DEBUG - 2011-08-30 22:46:52 --> Output Class Initialized
DEBUG - 2011-08-30 22:46:52 --> Input Class Initialized
DEBUG - 2011-08-30 22:46:52 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-30 22:46:52 --> Language Class Initialized
DEBUG - 2011-08-30 22:46:52 --> Loader Class Initialized
DEBUG - 2011-08-30 22:46:52 --> Controller Class Initialized
DEBUG - 2011-08-30 22:46:52 --> Model Class Initialized
DEBUG - 2011-08-30 22:46:52 --> Model Class Initialized
DEBUG - 2011-08-30 22:46:52 --> Model Class Initialized
DEBUG - 2011-08-30 22:46:52 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-30 22:46:52 --> Database Driver Class Initialized
DEBUG - 2011-08-30 22:46:52 --> File loaded: application/views/table/main.php
DEBUG - 2011-08-30 22:46:52 --> Helper loaded: url_helper
DEBUG - 2011-08-30 22:46:52 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-30 22:46:52 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-30 22:46:52 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-30 22:46:52 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-30 22:46:52 --> Final output sent to browser
DEBUG - 2011-08-30 22:46:52 --> Total execution time: 0.0442
DEBUG - 2011-08-30 22:46:54 --> Config Class Initialized
DEBUG - 2011-08-30 22:46:54 --> Hooks Class Initialized
DEBUG - 2011-08-30 22:46:54 --> Utf8 Class Initialized
DEBUG - 2011-08-30 22:46:54 --> UTF-8 Support Enabled
DEBUG - 2011-08-30 22:46:54 --> URI Class Initialized
DEBUG - 2011-08-30 22:46:54 --> Router Class Initialized
ERROR - 2011-08-30 22:46:54 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-08-30 22:47:01 --> Config Class Initialized
DEBUG - 2011-08-30 22:47:01 --> Hooks Class Initialized
DEBUG - 2011-08-30 22:47:01 --> Utf8 Class Initialized
DEBUG - 2011-08-30 22:47:01 --> UTF-8 Support Enabled
DEBUG - 2011-08-30 22:47:01 --> URI Class Initialized
DEBUG - 2011-08-30 22:47:01 --> Router Class Initialized
DEBUG - 2011-08-30 22:47:01 --> Output Class Initialized
DEBUG - 2011-08-30 22:47:01 --> Input Class Initialized
DEBUG - 2011-08-30 22:47:01 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-30 22:47:01 --> Language Class Initialized
DEBUG - 2011-08-30 22:47:01 --> Loader Class Initialized
DEBUG - 2011-08-30 22:47:01 --> Controller Class Initialized
DEBUG - 2011-08-30 22:47:01 --> Model Class Initialized
DEBUG - 2011-08-30 22:47:01 --> Model Class Initialized
DEBUG - 2011-08-30 22:47:01 --> Model Class Initialized
DEBUG - 2011-08-30 22:47:01 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-30 22:47:01 --> Database Driver Class Initialized
DEBUG - 2011-08-30 22:47:01 --> File loaded: application/views/table/main.php
DEBUG - 2011-08-30 22:47:01 --> Helper loaded: url_helper
DEBUG - 2011-08-30 22:47:01 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-30 22:47:01 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-30 22:47:01 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-30 22:47:01 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-30 22:47:01 --> Final output sent to browser
DEBUG - 2011-08-30 22:47:01 --> Total execution time: 0.3308
DEBUG - 2011-08-30 22:47:02 --> Config Class Initialized
DEBUG - 2011-08-30 22:47:02 --> Hooks Class Initialized
DEBUG - 2011-08-30 22:47:02 --> Utf8 Class Initialized
DEBUG - 2011-08-30 22:47:02 --> UTF-8 Support Enabled
DEBUG - 2011-08-30 22:47:02 --> URI Class Initialized
DEBUG - 2011-08-30 22:47:02 --> Router Class Initialized
DEBUG - 2011-08-30 22:47:02 --> Output Class Initialized
DEBUG - 2011-08-30 22:47:02 --> Input Class Initialized
DEBUG - 2011-08-30 22:47:02 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-30 22:47:02 --> Language Class Initialized
DEBUG - 2011-08-30 22:47:02 --> Loader Class Initialized
DEBUG - 2011-08-30 22:47:02 --> Controller Class Initialized
DEBUG - 2011-08-30 22:47:02 --> Model Class Initialized
DEBUG - 2011-08-30 22:47:02 --> Model Class Initialized
DEBUG - 2011-08-30 22:47:02 --> Model Class Initialized
DEBUG - 2011-08-30 22:47:02 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-30 22:47:02 --> Database Driver Class Initialized
DEBUG - 2011-08-30 22:47:02 --> File loaded: application/views/table/main.php
DEBUG - 2011-08-30 22:47:02 --> Helper loaded: url_helper
DEBUG - 2011-08-30 22:47:02 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-30 22:47:02 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-30 22:47:02 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-30 22:47:02 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-30 22:47:02 --> Final output sent to browser
DEBUG - 2011-08-30 22:47:02 --> Total execution time: 0.0547
DEBUG - 2011-08-30 22:47:03 --> Config Class Initialized
DEBUG - 2011-08-30 22:47:03 --> Hooks Class Initialized
DEBUG - 2011-08-30 22:47:03 --> Utf8 Class Initialized
DEBUG - 2011-08-30 22:47:03 --> UTF-8 Support Enabled
DEBUG - 2011-08-30 22:47:03 --> URI Class Initialized
DEBUG - 2011-08-30 22:47:03 --> Router Class Initialized
ERROR - 2011-08-30 22:47:03 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-08-30 22:47:10 --> Config Class Initialized
DEBUG - 2011-08-30 22:47:10 --> Hooks Class Initialized
DEBUG - 2011-08-30 22:47:10 --> Utf8 Class Initialized
DEBUG - 2011-08-30 22:47:10 --> UTF-8 Support Enabled
DEBUG - 2011-08-30 22:47:10 --> URI Class Initialized
DEBUG - 2011-08-30 22:47:10 --> Router Class Initialized
DEBUG - 2011-08-30 22:47:10 --> Output Class Initialized
DEBUG - 2011-08-30 22:47:10 --> Input Class Initialized
DEBUG - 2011-08-30 22:47:10 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-30 22:47:10 --> Language Class Initialized
DEBUG - 2011-08-30 22:47:10 --> Loader Class Initialized
DEBUG - 2011-08-30 22:47:10 --> Controller Class Initialized
DEBUG - 2011-08-30 22:47:10 --> Model Class Initialized
DEBUG - 2011-08-30 22:47:10 --> Model Class Initialized
DEBUG - 2011-08-30 22:47:10 --> Model Class Initialized
DEBUG - 2011-08-30 22:47:10 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-30 22:47:10 --> Database Driver Class Initialized
DEBUG - 2011-08-30 22:47:10 --> File loaded: application/views/table/main.php
DEBUG - 2011-08-30 22:47:10 --> Helper loaded: url_helper
DEBUG - 2011-08-30 22:47:10 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-30 22:47:10 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-30 22:47:10 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-30 22:47:10 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-30 22:47:10 --> Final output sent to browser
DEBUG - 2011-08-30 22:47:10 --> Total execution time: 0.0985
DEBUG - 2011-08-30 22:47:13 --> Config Class Initialized
DEBUG - 2011-08-30 22:47:13 --> Hooks Class Initialized
DEBUG - 2011-08-30 22:47:13 --> Utf8 Class Initialized
DEBUG - 2011-08-30 22:47:13 --> UTF-8 Support Enabled
DEBUG - 2011-08-30 22:47:13 --> URI Class Initialized
DEBUG - 2011-08-30 22:47:13 --> Router Class Initialized
ERROR - 2011-08-30 22:47:13 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-08-30 22:47:19 --> Config Class Initialized
DEBUG - 2011-08-30 22:47:19 --> Hooks Class Initialized
DEBUG - 2011-08-30 22:47:19 --> Utf8 Class Initialized
DEBUG - 2011-08-30 22:47:19 --> UTF-8 Support Enabled
DEBUG - 2011-08-30 22:47:19 --> URI Class Initialized
DEBUG - 2011-08-30 22:47:19 --> Router Class Initialized
DEBUG - 2011-08-30 22:47:19 --> Output Class Initialized
DEBUG - 2011-08-30 22:47:19 --> Input Class Initialized
DEBUG - 2011-08-30 22:47:19 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-30 22:47:19 --> Language Class Initialized
DEBUG - 2011-08-30 22:47:19 --> Loader Class Initialized
DEBUG - 2011-08-30 22:47:19 --> Controller Class Initialized
DEBUG - 2011-08-30 22:47:19 --> Model Class Initialized
DEBUG - 2011-08-30 22:47:19 --> Model Class Initialized
DEBUG - 2011-08-30 22:47:19 --> Model Class Initialized
DEBUG - 2011-08-30 22:47:19 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-30 22:47:19 --> Database Driver Class Initialized
DEBUG - 2011-08-30 22:47:20 --> File loaded: application/views/table/main.php
DEBUG - 2011-08-30 22:47:20 --> Helper loaded: url_helper
DEBUG - 2011-08-30 22:47:20 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-30 22:47:20 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-30 22:47:20 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-30 22:47:20 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-30 22:47:20 --> Final output sent to browser
DEBUG - 2011-08-30 22:47:20 --> Total execution time: 0.2503
DEBUG - 2011-08-30 22:47:21 --> Config Class Initialized
DEBUG - 2011-08-30 22:47:21 --> Hooks Class Initialized
DEBUG - 2011-08-30 22:47:21 --> Utf8 Class Initialized
DEBUG - 2011-08-30 22:47:21 --> UTF-8 Support Enabled
DEBUG - 2011-08-30 22:47:21 --> URI Class Initialized
DEBUG - 2011-08-30 22:47:21 --> Router Class Initialized
DEBUG - 2011-08-30 22:47:21 --> Output Class Initialized
DEBUG - 2011-08-30 22:47:21 --> Input Class Initialized
DEBUG - 2011-08-30 22:47:21 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-30 22:47:21 --> Language Class Initialized
DEBUG - 2011-08-30 22:47:21 --> Loader Class Initialized
DEBUG - 2011-08-30 22:47:21 --> Controller Class Initialized
DEBUG - 2011-08-30 22:47:21 --> Model Class Initialized
DEBUG - 2011-08-30 22:47:21 --> Model Class Initialized
DEBUG - 2011-08-30 22:47:21 --> Model Class Initialized
DEBUG - 2011-08-30 22:47:21 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-30 22:47:21 --> Database Driver Class Initialized
DEBUG - 2011-08-30 22:47:21 --> File loaded: application/views/table/main.php
DEBUG - 2011-08-30 22:47:21 --> Helper loaded: url_helper
DEBUG - 2011-08-30 22:47:21 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-30 22:47:21 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-30 22:47:21 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-30 22:47:21 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-30 22:47:21 --> Final output sent to browser
DEBUG - 2011-08-30 22:47:21 --> Total execution time: 0.0446
DEBUG - 2011-08-30 22:47:21 --> Config Class Initialized
DEBUG - 2011-08-30 22:47:21 --> Hooks Class Initialized
DEBUG - 2011-08-30 22:47:21 --> Utf8 Class Initialized
DEBUG - 2011-08-30 22:47:21 --> UTF-8 Support Enabled
DEBUG - 2011-08-30 22:47:21 --> URI Class Initialized
DEBUG - 2011-08-30 22:47:21 --> Router Class Initialized
ERROR - 2011-08-30 22:47:21 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-08-30 22:47:25 --> Config Class Initialized
DEBUG - 2011-08-30 22:47:25 --> Hooks Class Initialized
DEBUG - 2011-08-30 22:47:25 --> Utf8 Class Initialized
DEBUG - 2011-08-30 22:47:25 --> UTF-8 Support Enabled
DEBUG - 2011-08-30 22:47:25 --> URI Class Initialized
DEBUG - 2011-08-30 22:47:25 --> Router Class Initialized
DEBUG - 2011-08-30 22:47:25 --> Output Class Initialized
DEBUG - 2011-08-30 22:47:25 --> Input Class Initialized
DEBUG - 2011-08-30 22:47:25 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-30 22:47:25 --> Language Class Initialized
DEBUG - 2011-08-30 22:47:25 --> Loader Class Initialized
DEBUG - 2011-08-30 22:47:25 --> Controller Class Initialized
DEBUG - 2011-08-30 22:47:25 --> Model Class Initialized
DEBUG - 2011-08-30 22:47:25 --> Model Class Initialized
DEBUG - 2011-08-30 22:47:25 --> Model Class Initialized
DEBUG - 2011-08-30 22:47:25 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-30 22:47:25 --> Database Driver Class Initialized
DEBUG - 2011-08-30 22:47:26 --> File loaded: application/views/table/main.php
DEBUG - 2011-08-30 22:47:26 --> Helper loaded: url_helper
DEBUG - 2011-08-30 22:47:26 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-30 22:47:26 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-30 22:47:26 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-30 22:47:26 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-30 22:47:26 --> Final output sent to browser
DEBUG - 2011-08-30 22:47:26 --> Total execution time: 0.3256
DEBUG - 2011-08-30 22:47:27 --> Config Class Initialized
DEBUG - 2011-08-30 22:47:27 --> Hooks Class Initialized
DEBUG - 2011-08-30 22:47:27 --> Utf8 Class Initialized
DEBUG - 2011-08-30 22:47:27 --> UTF-8 Support Enabled
DEBUG - 2011-08-30 22:47:27 --> URI Class Initialized
DEBUG - 2011-08-30 22:47:27 --> Router Class Initialized
DEBUG - 2011-08-30 22:47:27 --> Output Class Initialized
DEBUG - 2011-08-30 22:47:27 --> Input Class Initialized
DEBUG - 2011-08-30 22:47:27 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-30 22:47:27 --> Language Class Initialized
DEBUG - 2011-08-30 22:47:27 --> Loader Class Initialized
DEBUG - 2011-08-30 22:47:27 --> Controller Class Initialized
DEBUG - 2011-08-30 22:47:27 --> Model Class Initialized
DEBUG - 2011-08-30 22:47:27 --> Model Class Initialized
DEBUG - 2011-08-30 22:47:27 --> Model Class Initialized
DEBUG - 2011-08-30 22:47:27 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-30 22:47:27 --> Database Driver Class Initialized
DEBUG - 2011-08-30 22:47:27 --> File loaded: application/views/table/main.php
DEBUG - 2011-08-30 22:47:27 --> Helper loaded: url_helper
DEBUG - 2011-08-30 22:47:27 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-30 22:47:27 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-30 22:47:27 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-30 22:47:27 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-30 22:47:27 --> Final output sent to browser
DEBUG - 2011-08-30 22:47:27 --> Total execution time: 0.0468
DEBUG - 2011-08-30 22:47:27 --> Config Class Initialized
DEBUG - 2011-08-30 22:47:27 --> Hooks Class Initialized
DEBUG - 2011-08-30 22:47:27 --> Utf8 Class Initialized
DEBUG - 2011-08-30 22:47:27 --> UTF-8 Support Enabled
DEBUG - 2011-08-30 22:47:27 --> URI Class Initialized
DEBUG - 2011-08-30 22:47:27 --> Router Class Initialized
ERROR - 2011-08-30 22:47:27 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-08-30 23:36:51 --> Config Class Initialized
DEBUG - 2011-08-30 23:36:51 --> Hooks Class Initialized
DEBUG - 2011-08-30 23:36:51 --> Utf8 Class Initialized
DEBUG - 2011-08-30 23:36:51 --> UTF-8 Support Enabled
DEBUG - 2011-08-30 23:36:51 --> URI Class Initialized
DEBUG - 2011-08-30 23:36:51 --> Router Class Initialized
DEBUG - 2011-08-30 23:36:51 --> No URI present. Default controller set.
DEBUG - 2011-08-30 23:36:51 --> Output Class Initialized
DEBUG - 2011-08-30 23:36:51 --> Input Class Initialized
DEBUG - 2011-08-30 23:36:51 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-30 23:36:51 --> Language Class Initialized
DEBUG - 2011-08-30 23:36:51 --> Loader Class Initialized
DEBUG - 2011-08-30 23:36:51 --> Controller Class Initialized
DEBUG - 2011-08-30 23:36:51 --> File loaded: application/views/splash/main.php
DEBUG - 2011-08-30 23:36:51 --> Helper loaded: url_helper
DEBUG - 2011-08-30 23:36:51 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-30 23:36:51 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-30 23:36:51 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-30 23:36:51 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-30 23:36:51 --> Final output sent to browser
DEBUG - 2011-08-30 23:36:51 --> Total execution time: 0.0827

<?php  if ( ! defined('BASEPATH')) exit('No direct script access allowed'); ?>

DEBUG - 2011-05-04 01:24:33 --> Config Class Initialized
DEBUG - 2011-05-04 01:24:33 --> Hooks Class Initialized
DEBUG - 2011-05-04 01:24:33 --> Utf8 Class Initialized
DEBUG - 2011-05-04 01:24:33 --> UTF-8 Support Enabled
DEBUG - 2011-05-04 01:24:33 --> URI Class Initialized
DEBUG - 2011-05-04 01:24:33 --> Router Class Initialized
DEBUG - 2011-05-04 01:24:33 --> Output Class Initialized
DEBUG - 2011-05-04 01:24:33 --> Input Class Initialized
DEBUG - 2011-05-04 01:24:33 --> Global POST and COOKIE data sanitized
DEBUG - 2011-05-04 01:24:33 --> Language Class Initialized
DEBUG - 2011-05-04 01:24:33 --> Loader Class Initialized
DEBUG - 2011-05-04 01:24:33 --> Controller Class Initialized
ERROR - 2011-05-04 01:24:34 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-05-04 01:24:34 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-05-04 01:24:34 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-05-04 01:24:34 --> Model Class Initialized
DEBUG - 2011-05-04 01:24:34 --> Model Class Initialized
DEBUG - 2011-05-04 01:24:34 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-05-04 01:24:34 --> Database Driver Class Initialized
DEBUG - 2011-05-04 01:24:34 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-05-04 01:24:34 --> Helper loaded: url_helper
DEBUG - 2011-05-04 01:24:34 --> File loaded: application/views/common/header.php
DEBUG - 2011-05-04 01:24:34 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-05-04 01:24:34 --> File loaded: application/views/common/footer.php
DEBUG - 2011-05-04 01:24:34 --> File loaded: application/views/layout/main.php
DEBUG - 2011-05-04 01:24:34 --> Final output sent to browser
DEBUG - 2011-05-04 01:24:34 --> Total execution time: 1.4854
DEBUG - 2011-05-04 01:24:35 --> Config Class Initialized
DEBUG - 2011-05-04 01:24:35 --> Hooks Class Initialized
DEBUG - 2011-05-04 01:24:35 --> Utf8 Class Initialized
DEBUG - 2011-05-04 01:24:35 --> UTF-8 Support Enabled
DEBUG - 2011-05-04 01:24:35 --> URI Class Initialized
DEBUG - 2011-05-04 01:24:35 --> Router Class Initialized
DEBUG - 2011-05-04 01:24:35 --> Output Class Initialized
DEBUG - 2011-05-04 01:24:35 --> Input Class Initialized
DEBUG - 2011-05-04 01:24:35 --> Global POST and COOKIE data sanitized
DEBUG - 2011-05-04 01:24:35 --> Language Class Initialized
DEBUG - 2011-05-04 01:24:35 --> Loader Class Initialized
DEBUG - 2011-05-04 01:24:35 --> Controller Class Initialized
ERROR - 2011-05-04 01:24:35 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-05-04 01:24:35 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-05-04 01:24:35 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-05-04 01:24:35 --> Model Class Initialized
DEBUG - 2011-05-04 01:24:35 --> Model Class Initialized
DEBUG - 2011-05-04 01:24:35 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-05-04 01:24:35 --> Database Driver Class Initialized
DEBUG - 2011-05-04 01:24:35 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-05-04 01:24:35 --> Helper loaded: url_helper
DEBUG - 2011-05-04 01:24:35 --> File loaded: application/views/common/header.php
DEBUG - 2011-05-04 01:24:35 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-05-04 01:24:35 --> File loaded: application/views/common/footer.php
DEBUG - 2011-05-04 01:24:35 --> File loaded: application/views/layout/main.php
DEBUG - 2011-05-04 01:24:35 --> Final output sent to browser
DEBUG - 2011-05-04 01:24:35 --> Total execution time: 0.0309
DEBUG - 2011-05-04 01:24:37 --> Config Class Initialized
DEBUG - 2011-05-04 01:24:37 --> Hooks Class Initialized
DEBUG - 2011-05-04 01:24:37 --> Utf8 Class Initialized
DEBUG - 2011-05-04 01:24:37 --> UTF-8 Support Enabled
DEBUG - 2011-05-04 01:24:37 --> URI Class Initialized
DEBUG - 2011-05-04 01:24:37 --> Router Class Initialized
DEBUG - 2011-05-04 01:24:37 --> Output Class Initialized
DEBUG - 2011-05-04 01:24:37 --> Input Class Initialized
DEBUG - 2011-05-04 01:24:37 --> Global POST and COOKIE data sanitized
DEBUG - 2011-05-04 01:24:37 --> Language Class Initialized
DEBUG - 2011-05-04 01:24:37 --> Loader Class Initialized
DEBUG - 2011-05-04 01:24:37 --> Controller Class Initialized
ERROR - 2011-05-04 01:24:37 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-05-04 01:24:37 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-05-04 01:24:37 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-05-04 01:24:37 --> Model Class Initialized
DEBUG - 2011-05-04 01:24:37 --> Model Class Initialized
DEBUG - 2011-05-04 01:24:37 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-05-04 01:24:37 --> Database Driver Class Initialized
DEBUG - 2011-05-04 01:24:37 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-05-04 01:24:37 --> Helper loaded: url_helper
DEBUG - 2011-05-04 01:24:37 --> File loaded: application/views/common/header.php
DEBUG - 2011-05-04 01:24:37 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-05-04 01:24:37 --> File loaded: application/views/common/footer.php
DEBUG - 2011-05-04 01:24:37 --> File loaded: application/views/layout/main.php
DEBUG - 2011-05-04 01:24:37 --> Final output sent to browser
DEBUG - 2011-05-04 01:24:37 --> Total execution time: 0.1532
DEBUG - 2011-05-04 01:24:37 --> Config Class Initialized
DEBUG - 2011-05-04 01:24:37 --> Hooks Class Initialized
DEBUG - 2011-05-04 01:24:37 --> Utf8 Class Initialized
DEBUG - 2011-05-04 01:24:37 --> UTF-8 Support Enabled
DEBUG - 2011-05-04 01:24:37 --> URI Class Initialized
DEBUG - 2011-05-04 01:24:37 --> Router Class Initialized
DEBUG - 2011-05-04 01:24:37 --> Output Class Initialized
DEBUG - 2011-05-04 01:24:37 --> Input Class Initialized
DEBUG - 2011-05-04 01:24:37 --> Global POST and COOKIE data sanitized
DEBUG - 2011-05-04 01:24:37 --> Language Class Initialized
DEBUG - 2011-05-04 01:24:37 --> Loader Class Initialized
DEBUG - 2011-05-04 01:24:37 --> Controller Class Initialized
ERROR - 2011-05-04 01:24:37 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-05-04 01:24:37 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-05-04 01:24:37 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-05-04 01:24:37 --> Model Class Initialized
DEBUG - 2011-05-04 01:24:37 --> Model Class Initialized
DEBUG - 2011-05-04 01:24:37 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-05-04 01:24:37 --> Database Driver Class Initialized
DEBUG - 2011-05-04 01:24:37 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-05-04 01:24:37 --> Helper loaded: url_helper
DEBUG - 2011-05-04 01:24:37 --> File loaded: application/views/common/header.php
DEBUG - 2011-05-04 01:24:37 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-05-04 01:24:37 --> File loaded: application/views/common/footer.php
DEBUG - 2011-05-04 01:24:37 --> File loaded: application/views/layout/main.php
DEBUG - 2011-05-04 01:24:37 --> Final output sent to browser
DEBUG - 2011-05-04 01:24:37 --> Total execution time: 0.0871
DEBUG - 2011-05-04 01:32:23 --> Config Class Initialized
DEBUG - 2011-05-04 01:32:23 --> Hooks Class Initialized
DEBUG - 2011-05-04 01:32:23 --> Utf8 Class Initialized
DEBUG - 2011-05-04 01:32:23 --> UTF-8 Support Enabled
DEBUG - 2011-05-04 01:32:23 --> URI Class Initialized
DEBUG - 2011-05-04 01:32:23 --> Router Class Initialized
DEBUG - 2011-05-04 01:32:23 --> Output Class Initialized
DEBUG - 2011-05-04 01:32:23 --> Input Class Initialized
DEBUG - 2011-05-04 01:32:23 --> Global POST and COOKIE data sanitized
DEBUG - 2011-05-04 01:32:23 --> Language Class Initialized
DEBUG - 2011-05-04 01:32:23 --> Loader Class Initialized
DEBUG - 2011-05-04 01:32:23 --> Controller Class Initialized
ERROR - 2011-05-04 01:32:23 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-05-04 01:32:23 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-05-04 01:32:23 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-05-04 01:32:23 --> Model Class Initialized
DEBUG - 2011-05-04 01:32:23 --> Model Class Initialized
DEBUG - 2011-05-04 01:32:23 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-05-04 01:32:23 --> Database Driver Class Initialized
DEBUG - 2011-05-04 01:32:23 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-05-04 01:32:23 --> Helper loaded: url_helper
DEBUG - 2011-05-04 01:32:23 --> File loaded: application/views/common/header.php
DEBUG - 2011-05-04 01:32:23 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-05-04 01:32:23 --> File loaded: application/views/common/footer.php
DEBUG - 2011-05-04 01:32:23 --> File loaded: application/views/layout/main.php
DEBUG - 2011-05-04 01:32:23 --> Final output sent to browser
DEBUG - 2011-05-04 01:32:23 --> Total execution time: 0.0307
DEBUG - 2011-05-04 01:32:24 --> Config Class Initialized
DEBUG - 2011-05-04 01:32:24 --> Hooks Class Initialized
DEBUG - 2011-05-04 01:32:24 --> Utf8 Class Initialized
DEBUG - 2011-05-04 01:32:24 --> UTF-8 Support Enabled
DEBUG - 2011-05-04 01:32:24 --> URI Class Initialized
DEBUG - 2011-05-04 01:32:24 --> Router Class Initialized
DEBUG - 2011-05-04 01:32:24 --> Output Class Initialized
DEBUG - 2011-05-04 01:32:24 --> Input Class Initialized
DEBUG - 2011-05-04 01:32:24 --> Global POST and COOKIE data sanitized
DEBUG - 2011-05-04 01:32:24 --> Language Class Initialized
DEBUG - 2011-05-04 01:32:24 --> Loader Class Initialized
DEBUG - 2011-05-04 01:32:24 --> Controller Class Initialized
ERROR - 2011-05-04 01:32:24 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-05-04 01:32:24 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-05-04 01:32:24 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-05-04 01:32:24 --> Model Class Initialized
DEBUG - 2011-05-04 01:32:24 --> Model Class Initialized
DEBUG - 2011-05-04 01:32:24 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-05-04 01:32:24 --> Database Driver Class Initialized
DEBUG - 2011-05-04 01:32:24 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-05-04 01:32:24 --> Helper loaded: url_helper
DEBUG - 2011-05-04 01:32:24 --> File loaded: application/views/common/header.php
DEBUG - 2011-05-04 01:32:24 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-05-04 01:32:24 --> File loaded: application/views/common/footer.php
DEBUG - 2011-05-04 01:32:24 --> File loaded: application/views/layout/main.php
DEBUG - 2011-05-04 01:32:24 --> Final output sent to browser
DEBUG - 2011-05-04 01:32:24 --> Total execution time: 0.0292
DEBUG - 2011-05-04 01:32:29 --> Config Class Initialized
DEBUG - 2011-05-04 01:32:29 --> Hooks Class Initialized
DEBUG - 2011-05-04 01:32:29 --> Utf8 Class Initialized
DEBUG - 2011-05-04 01:32:29 --> UTF-8 Support Enabled
DEBUG - 2011-05-04 01:32:29 --> URI Class Initialized
DEBUG - 2011-05-04 01:32:29 --> Router Class Initialized
DEBUG - 2011-05-04 01:32:29 --> Output Class Initialized
DEBUG - 2011-05-04 01:32:29 --> Input Class Initialized
DEBUG - 2011-05-04 01:32:29 --> Global POST and COOKIE data sanitized
DEBUG - 2011-05-04 01:32:29 --> Language Class Initialized
DEBUG - 2011-05-04 01:32:29 --> Loader Class Initialized
DEBUG - 2011-05-04 01:32:29 --> Controller Class Initialized
ERROR - 2011-05-04 01:32:29 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-05-04 01:32:29 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-05-04 01:32:29 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-05-04 01:32:29 --> Model Class Initialized
DEBUG - 2011-05-04 01:32:29 --> Model Class Initialized
DEBUG - 2011-05-04 01:32:29 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-05-04 01:32:29 --> Database Driver Class Initialized
DEBUG - 2011-05-04 01:32:29 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-05-04 01:32:29 --> Helper loaded: url_helper
DEBUG - 2011-05-04 01:32:29 --> File loaded: application/views/common/header.php
DEBUG - 2011-05-04 01:32:29 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-05-04 01:32:29 --> File loaded: application/views/common/footer.php
DEBUG - 2011-05-04 01:32:29 --> File loaded: application/views/layout/main.php
DEBUG - 2011-05-04 01:32:29 --> Final output sent to browser
DEBUG - 2011-05-04 01:32:29 --> Total execution time: 0.0400
DEBUG - 2011-05-04 01:32:40 --> Config Class Initialized
DEBUG - 2011-05-04 01:32:40 --> Hooks Class Initialized
DEBUG - 2011-05-04 01:32:40 --> Utf8 Class Initialized
DEBUG - 2011-05-04 01:32:40 --> UTF-8 Support Enabled
DEBUG - 2011-05-04 01:32:40 --> URI Class Initialized
DEBUG - 2011-05-04 01:32:40 --> Router Class Initialized
DEBUG - 2011-05-04 01:32:40 --> Output Class Initialized
DEBUG - 2011-05-04 01:32:40 --> Input Class Initialized
DEBUG - 2011-05-04 01:32:40 --> Global POST and COOKIE data sanitized
DEBUG - 2011-05-04 01:32:40 --> Language Class Initialized
DEBUG - 2011-05-04 01:32:40 --> Loader Class Initialized
DEBUG - 2011-05-04 01:32:40 --> Controller Class Initialized
ERROR - 2011-05-04 01:32:40 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-05-04 01:32:40 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-05-04 01:32:40 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-05-04 01:32:40 --> Model Class Initialized
DEBUG - 2011-05-04 01:32:40 --> Model Class Initialized
DEBUG - 2011-05-04 01:32:40 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-05-04 01:32:40 --> Database Driver Class Initialized
DEBUG - 2011-05-04 01:32:40 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-05-04 01:32:40 --> Helper loaded: url_helper
DEBUG - 2011-05-04 01:32:40 --> File loaded: application/views/common/header.php
DEBUG - 2011-05-04 01:32:40 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-05-04 01:32:40 --> File loaded: application/views/common/footer.php
DEBUG - 2011-05-04 01:32:40 --> File loaded: application/views/layout/main.php
DEBUG - 2011-05-04 01:32:40 --> Final output sent to browser
DEBUG - 2011-05-04 01:32:40 --> Total execution time: 0.0323
DEBUG - 2011-05-04 03:20:05 --> Config Class Initialized
DEBUG - 2011-05-04 03:20:05 --> Hooks Class Initialized
DEBUG - 2011-05-04 03:20:05 --> Utf8 Class Initialized
DEBUG - 2011-05-04 03:20:05 --> UTF-8 Support Enabled
DEBUG - 2011-05-04 03:20:05 --> URI Class Initialized
DEBUG - 2011-05-04 03:20:05 --> Router Class Initialized
DEBUG - 2011-05-04 03:20:05 --> Output Class Initialized
DEBUG - 2011-05-04 03:20:05 --> Input Class Initialized
DEBUG - 2011-05-04 03:20:05 --> Global POST and COOKIE data sanitized
DEBUG - 2011-05-04 03:20:05 --> Language Class Initialized
DEBUG - 2011-05-04 03:20:05 --> Loader Class Initialized
DEBUG - 2011-05-04 03:20:05 --> Controller Class Initialized
ERROR - 2011-05-04 03:20:05 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-05-04 03:20:05 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-05-04 03:20:05 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-05-04 03:20:05 --> Model Class Initialized
DEBUG - 2011-05-04 03:20:05 --> Model Class Initialized
DEBUG - 2011-05-04 03:20:05 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-05-04 03:20:05 --> Database Driver Class Initialized
DEBUG - 2011-05-04 03:20:07 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-05-04 03:20:07 --> Helper loaded: url_helper
DEBUG - 2011-05-04 03:20:07 --> File loaded: application/views/common/header.php
DEBUG - 2011-05-04 03:20:07 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-05-04 03:20:07 --> File loaded: application/views/common/footer.php
DEBUG - 2011-05-04 03:20:07 --> File loaded: application/views/layout/main.php
DEBUG - 2011-05-04 03:20:07 --> Final output sent to browser
DEBUG - 2011-05-04 03:20:07 --> Total execution time: 2.6933
DEBUG - 2011-05-04 03:20:09 --> Config Class Initialized
DEBUG - 2011-05-04 03:20:09 --> Hooks Class Initialized
DEBUG - 2011-05-04 03:20:09 --> Utf8 Class Initialized
DEBUG - 2011-05-04 03:20:09 --> UTF-8 Support Enabled
DEBUG - 2011-05-04 03:20:09 --> URI Class Initialized
DEBUG - 2011-05-04 03:20:09 --> Router Class Initialized
DEBUG - 2011-05-04 03:20:09 --> Output Class Initialized
DEBUG - 2011-05-04 03:20:09 --> Input Class Initialized
DEBUG - 2011-05-04 03:20:09 --> Global POST and COOKIE data sanitized
DEBUG - 2011-05-04 03:20:09 --> Language Class Initialized
DEBUG - 2011-05-04 03:20:09 --> Loader Class Initialized
DEBUG - 2011-05-04 03:20:09 --> Controller Class Initialized
DEBUG - 2011-05-04 03:20:09 --> Model Class Initialized
DEBUG - 2011-05-04 03:20:09 --> Model Class Initialized
DEBUG - 2011-05-04 03:20:09 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-05-04 03:20:09 --> Database Driver Class Initialized
DEBUG - 2011-05-04 03:20:16 --> Final output sent to browser
DEBUG - 2011-05-04 03:20:16 --> Total execution time: 7.7714
DEBUG - 2011-05-04 04:24:38 --> Config Class Initialized
DEBUG - 2011-05-04 04:24:38 --> Hooks Class Initialized
DEBUG - 2011-05-04 04:24:38 --> Utf8 Class Initialized
DEBUG - 2011-05-04 04:24:38 --> UTF-8 Support Enabled
DEBUG - 2011-05-04 04:24:38 --> URI Class Initialized
DEBUG - 2011-05-04 04:24:38 --> Router Class Initialized
DEBUG - 2011-05-04 04:24:38 --> Output Class Initialized
DEBUG - 2011-05-04 04:24:38 --> Input Class Initialized
DEBUG - 2011-05-04 04:24:38 --> Global POST and COOKIE data sanitized
DEBUG - 2011-05-04 04:24:38 --> Language Class Initialized
DEBUG - 2011-05-04 04:24:38 --> Loader Class Initialized
DEBUG - 2011-05-04 04:24:38 --> Controller Class Initialized
DEBUG - 2011-05-04 04:24:38 --> Model Class Initialized
DEBUG - 2011-05-04 04:24:39 --> Model Class Initialized
DEBUG - 2011-05-04 04:24:39 --> Model Class Initialized
DEBUG - 2011-05-04 04:24:39 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-05-04 04:24:39 --> Database Driver Class Initialized
DEBUG - 2011-05-04 04:24:43 --> File loaded: application/views/table/main.php
DEBUG - 2011-05-04 04:24:43 --> Helper loaded: url_helper
DEBUG - 2011-05-04 04:24:43 --> File loaded: application/views/common/header.php
DEBUG - 2011-05-04 04:24:43 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-05-04 04:24:43 --> File loaded: application/views/common/footer.php
DEBUG - 2011-05-04 04:24:43 --> File loaded: application/views/layout/main.php
DEBUG - 2011-05-04 04:24:43 --> Final output sent to browser
DEBUG - 2011-05-04 04:24:43 --> Total execution time: 4.5394
DEBUG - 2011-05-04 04:24:57 --> Config Class Initialized
DEBUG - 2011-05-04 04:24:57 --> Hooks Class Initialized
DEBUG - 2011-05-04 04:24:57 --> Utf8 Class Initialized
DEBUG - 2011-05-04 04:24:57 --> UTF-8 Support Enabled
DEBUG - 2011-05-04 04:24:57 --> URI Class Initialized
DEBUG - 2011-05-04 04:24:57 --> Router Class Initialized
DEBUG - 2011-05-04 04:24:57 --> Output Class Initialized
DEBUG - 2011-05-04 04:24:57 --> Input Class Initialized
DEBUG - 2011-05-04 04:24:57 --> Global POST and COOKIE data sanitized
DEBUG - 2011-05-04 04:24:57 --> Language Class Initialized
DEBUG - 2011-05-04 04:24:57 --> Loader Class Initialized
DEBUG - 2011-05-04 04:24:57 --> Controller Class Initialized
ERROR - 2011-05-04 04:24:57 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-05-04 04:24:57 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-05-04 04:24:57 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-05-04 04:24:57 --> Model Class Initialized
DEBUG - 2011-05-04 04:24:57 --> Model Class Initialized
DEBUG - 2011-05-04 04:24:57 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-05-04 04:24:57 --> Database Driver Class Initialized
DEBUG - 2011-05-04 04:24:57 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-05-04 04:24:57 --> Helper loaded: url_helper
DEBUG - 2011-05-04 04:24:57 --> File loaded: application/views/common/header.php
DEBUG - 2011-05-04 04:24:57 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-05-04 04:24:57 --> File loaded: application/views/common/footer.php
DEBUG - 2011-05-04 04:24:57 --> File loaded: application/views/layout/main.php
DEBUG - 2011-05-04 04:24:57 --> Final output sent to browser
DEBUG - 2011-05-04 04:24:57 --> Total execution time: 0.1531
DEBUG - 2011-05-04 04:25:52 --> Config Class Initialized
DEBUG - 2011-05-04 04:25:52 --> Hooks Class Initialized
DEBUG - 2011-05-04 04:25:52 --> Utf8 Class Initialized
DEBUG - 2011-05-04 04:25:52 --> UTF-8 Support Enabled
DEBUG - 2011-05-04 04:25:52 --> URI Class Initialized
DEBUG - 2011-05-04 04:25:52 --> Router Class Initialized
DEBUG - 2011-05-04 04:25:52 --> Output Class Initialized
DEBUG - 2011-05-04 04:25:52 --> Input Class Initialized
DEBUG - 2011-05-04 04:25:52 --> Global POST and COOKIE data sanitized
DEBUG - 2011-05-04 04:25:52 --> Language Class Initialized
DEBUG - 2011-05-04 04:25:52 --> Loader Class Initialized
DEBUG - 2011-05-04 04:25:52 --> Controller Class Initialized
ERROR - 2011-05-04 04:25:52 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-05-04 04:25:52 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-05-04 04:25:52 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-05-04 04:25:52 --> Model Class Initialized
DEBUG - 2011-05-04 04:25:52 --> Model Class Initialized
DEBUG - 2011-05-04 04:25:52 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-05-04 04:25:52 --> Database Driver Class Initialized
DEBUG - 2011-05-04 04:25:52 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-05-04 04:25:52 --> Helper loaded: url_helper
DEBUG - 2011-05-04 04:25:52 --> File loaded: application/views/common/header.php
DEBUG - 2011-05-04 04:25:52 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-05-04 04:25:52 --> File loaded: application/views/common/footer.php
DEBUG - 2011-05-04 04:25:52 --> File loaded: application/views/layout/main.php
DEBUG - 2011-05-04 04:25:52 --> Final output sent to browser
DEBUG - 2011-05-04 04:25:52 --> Total execution time: 0.0431
DEBUG - 2011-05-04 05:03:03 --> Config Class Initialized
DEBUG - 2011-05-04 05:03:03 --> Hooks Class Initialized
DEBUG - 2011-05-04 05:03:03 --> Utf8 Class Initialized
DEBUG - 2011-05-04 05:03:03 --> UTF-8 Support Enabled
DEBUG - 2011-05-04 05:03:03 --> URI Class Initialized
DEBUG - 2011-05-04 05:03:03 --> Router Class Initialized
DEBUG - 2011-05-04 05:03:03 --> Output Class Initialized
DEBUG - 2011-05-04 05:03:03 --> Input Class Initialized
DEBUG - 2011-05-04 05:03:03 --> Global POST and COOKIE data sanitized
DEBUG - 2011-05-04 05:03:03 --> Language Class Initialized
DEBUG - 2011-05-04 05:03:03 --> Loader Class Initialized
DEBUG - 2011-05-04 05:03:03 --> Controller Class Initialized
DEBUG - 2011-05-04 05:03:03 --> Model Class Initialized
DEBUG - 2011-05-04 05:03:03 --> Model Class Initialized
DEBUG - 2011-05-04 05:03:03 --> Model Class Initialized
DEBUG - 2011-05-04 05:03:03 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-05-04 05:03:03 --> Database Driver Class Initialized
DEBUG - 2011-05-04 05:03:04 --> File loaded: application/views/table/main.php
DEBUG - 2011-05-04 05:03:04 --> Helper loaded: url_helper
DEBUG - 2011-05-04 05:03:04 --> File loaded: application/views/common/header.php
DEBUG - 2011-05-04 05:03:04 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-05-04 05:03:04 --> File loaded: application/views/common/footer.php
DEBUG - 2011-05-04 05:03:04 --> File loaded: application/views/layout/main.php
DEBUG - 2011-05-04 05:03:04 --> Final output sent to browser
DEBUG - 2011-05-04 05:03:04 --> Total execution time: 0.8728
DEBUG - 2011-05-04 05:37:58 --> Config Class Initialized
DEBUG - 2011-05-04 05:37:58 --> Hooks Class Initialized
DEBUG - 2011-05-04 05:37:58 --> Utf8 Class Initialized
DEBUG - 2011-05-04 05:37:58 --> UTF-8 Support Enabled
DEBUG - 2011-05-04 05:37:58 --> URI Class Initialized
DEBUG - 2011-05-04 05:37:58 --> Router Class Initialized
DEBUG - 2011-05-04 05:37:58 --> Output Class Initialized
DEBUG - 2011-05-04 05:37:58 --> Input Class Initialized
DEBUG - 2011-05-04 05:37:58 --> Global POST and COOKIE data sanitized
DEBUG - 2011-05-04 05:37:58 --> Language Class Initialized
DEBUG - 2011-05-04 05:37:58 --> Loader Class Initialized
DEBUG - 2011-05-04 05:37:58 --> Controller Class Initialized
ERROR - 2011-05-04 05:37:58 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-05-04 05:37:58 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-05-04 05:37:58 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-05-04 05:37:58 --> Model Class Initialized
DEBUG - 2011-05-04 05:37:58 --> Model Class Initialized
DEBUG - 2011-05-04 05:37:58 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-05-04 05:37:59 --> Database Driver Class Initialized
DEBUG - 2011-05-04 05:37:59 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-05-04 05:37:59 --> Helper loaded: url_helper
DEBUG - 2011-05-04 05:37:59 --> File loaded: application/views/common/header.php
DEBUG - 2011-05-04 05:37:59 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-05-04 05:37:59 --> File loaded: application/views/common/footer.php
DEBUG - 2011-05-04 05:37:59 --> File loaded: application/views/layout/main.php
DEBUG - 2011-05-04 05:37:59 --> Final output sent to browser
DEBUG - 2011-05-04 05:37:59 --> Total execution time: 0.5214
DEBUG - 2011-05-04 05:38:01 --> Config Class Initialized
DEBUG - 2011-05-04 05:38:01 --> Hooks Class Initialized
DEBUG - 2011-05-04 05:38:01 --> Utf8 Class Initialized
DEBUG - 2011-05-04 05:38:01 --> UTF-8 Support Enabled
DEBUG - 2011-05-04 05:38:01 --> URI Class Initialized
DEBUG - 2011-05-04 05:38:01 --> Router Class Initialized
DEBUG - 2011-05-04 05:38:01 --> Output Class Initialized
DEBUG - 2011-05-04 05:38:01 --> Input Class Initialized
DEBUG - 2011-05-04 05:38:01 --> Global POST and COOKIE data sanitized
DEBUG - 2011-05-04 05:38:01 --> Language Class Initialized
DEBUG - 2011-05-04 05:38:01 --> Loader Class Initialized
DEBUG - 2011-05-04 05:38:01 --> Controller Class Initialized
DEBUG - 2011-05-04 05:38:01 --> Model Class Initialized
DEBUG - 2011-05-04 05:38:01 --> Model Class Initialized
DEBUG - 2011-05-04 05:38:01 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-05-04 05:38:01 --> Database Driver Class Initialized
DEBUG - 2011-05-04 05:38:02 --> Final output sent to browser
DEBUG - 2011-05-04 05:38:02 --> Total execution time: 1.4862
DEBUG - 2011-05-04 05:38:05 --> Config Class Initialized
DEBUG - 2011-05-04 05:38:05 --> Hooks Class Initialized
DEBUG - 2011-05-04 05:38:05 --> Utf8 Class Initialized
DEBUG - 2011-05-04 05:38:05 --> UTF-8 Support Enabled
DEBUG - 2011-05-04 05:38:05 --> URI Class Initialized
DEBUG - 2011-05-04 05:38:05 --> Router Class Initialized
ERROR - 2011-05-04 05:38:05 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-05-04 05:38:23 --> Config Class Initialized
DEBUG - 2011-05-04 05:38:23 --> Hooks Class Initialized
DEBUG - 2011-05-04 05:38:23 --> Utf8 Class Initialized
DEBUG - 2011-05-04 05:38:23 --> UTF-8 Support Enabled
DEBUG - 2011-05-04 05:38:23 --> URI Class Initialized
DEBUG - 2011-05-04 05:38:23 --> Router Class Initialized
DEBUG - 2011-05-04 05:38:23 --> Output Class Initialized
DEBUG - 2011-05-04 05:38:23 --> Input Class Initialized
DEBUG - 2011-05-04 05:38:23 --> Global POST and COOKIE data sanitized
DEBUG - 2011-05-04 05:38:23 --> Language Class Initialized
DEBUG - 2011-05-04 05:38:23 --> Loader Class Initialized
DEBUG - 2011-05-04 05:38:23 --> Controller Class Initialized
ERROR - 2011-05-04 05:38:23 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-05-04 05:38:23 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-05-04 05:38:23 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-05-04 05:38:23 --> Model Class Initialized
DEBUG - 2011-05-04 05:38:23 --> Model Class Initialized
DEBUG - 2011-05-04 05:38:23 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-05-04 05:38:23 --> Database Driver Class Initialized
DEBUG - 2011-05-04 05:38:23 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-05-04 05:38:23 --> Helper loaded: url_helper
DEBUG - 2011-05-04 05:38:23 --> File loaded: application/views/common/header.php
DEBUG - 2011-05-04 05:38:23 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-05-04 05:38:23 --> File loaded: application/views/common/footer.php
DEBUG - 2011-05-04 05:38:23 --> File loaded: application/views/layout/main.php
DEBUG - 2011-05-04 05:38:23 --> Final output sent to browser
DEBUG - 2011-05-04 05:38:23 --> Total execution time: 0.0307
DEBUG - 2011-05-04 05:38:25 --> Config Class Initialized
DEBUG - 2011-05-04 05:38:25 --> Hooks Class Initialized
DEBUG - 2011-05-04 05:38:25 --> Utf8 Class Initialized
DEBUG - 2011-05-04 05:38:25 --> UTF-8 Support Enabled
DEBUG - 2011-05-04 05:38:25 --> URI Class Initialized
DEBUG - 2011-05-04 05:38:25 --> Router Class Initialized
DEBUG - 2011-05-04 05:38:25 --> Output Class Initialized
DEBUG - 2011-05-04 05:38:25 --> Input Class Initialized
DEBUG - 2011-05-04 05:38:25 --> Global POST and COOKIE data sanitized
DEBUG - 2011-05-04 05:38:25 --> Language Class Initialized
DEBUG - 2011-05-04 05:38:25 --> Loader Class Initialized
DEBUG - 2011-05-04 05:38:25 --> Controller Class Initialized
DEBUG - 2011-05-04 05:38:25 --> Model Class Initialized
DEBUG - 2011-05-04 05:38:25 --> Model Class Initialized
DEBUG - 2011-05-04 05:38:25 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-05-04 05:38:25 --> Database Driver Class Initialized
DEBUG - 2011-05-04 05:38:28 --> Final output sent to browser
DEBUG - 2011-05-04 05:38:28 --> Total execution time: 2.7713
DEBUG - 2011-05-04 05:38:31 --> Config Class Initialized
DEBUG - 2011-05-04 05:38:31 --> Hooks Class Initialized
DEBUG - 2011-05-04 05:38:31 --> Utf8 Class Initialized
DEBUG - 2011-05-04 05:38:31 --> UTF-8 Support Enabled
DEBUG - 2011-05-04 05:38:31 --> URI Class Initialized
DEBUG - 2011-05-04 05:38:31 --> Router Class Initialized
ERROR - 2011-05-04 05:38:31 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-05-04 05:38:47 --> Config Class Initialized
DEBUG - 2011-05-04 05:38:47 --> Hooks Class Initialized
DEBUG - 2011-05-04 05:38:47 --> Utf8 Class Initialized
DEBUG - 2011-05-04 05:38:47 --> UTF-8 Support Enabled
DEBUG - 2011-05-04 05:38:47 --> URI Class Initialized
DEBUG - 2011-05-04 05:38:47 --> Router Class Initialized
DEBUG - 2011-05-04 05:38:47 --> Output Class Initialized
DEBUG - 2011-05-04 05:38:47 --> Input Class Initialized
DEBUG - 2011-05-04 05:38:47 --> Global POST and COOKIE data sanitized
DEBUG - 2011-05-04 05:38:47 --> Language Class Initialized
DEBUG - 2011-05-04 05:38:47 --> Loader Class Initialized
DEBUG - 2011-05-04 05:38:47 --> Controller Class Initialized
DEBUG - 2011-05-04 05:38:47 --> Model Class Initialized
DEBUG - 2011-05-04 05:38:47 --> Model Class Initialized
DEBUG - 2011-05-04 05:38:47 --> Model Class Initialized
DEBUG - 2011-05-04 05:38:47 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-05-04 05:38:47 --> Database Driver Class Initialized
DEBUG - 2011-05-04 05:38:47 --> File loaded: application/views/table/main.php
DEBUG - 2011-05-04 05:38:47 --> Helper loaded: url_helper
DEBUG - 2011-05-04 05:38:47 --> File loaded: application/views/common/header.php
DEBUG - 2011-05-04 05:38:47 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-05-04 05:38:47 --> File loaded: application/views/common/footer.php
DEBUG - 2011-05-04 05:38:47 --> File loaded: application/views/layout/main.php
DEBUG - 2011-05-04 05:38:47 --> Final output sent to browser
DEBUG - 2011-05-04 05:38:47 --> Total execution time: 0.3213
DEBUG - 2011-05-04 05:38:50 --> Config Class Initialized
DEBUG - 2011-05-04 05:38:50 --> Hooks Class Initialized
DEBUG - 2011-05-04 05:38:50 --> Utf8 Class Initialized
DEBUG - 2011-05-04 05:38:50 --> UTF-8 Support Enabled
DEBUG - 2011-05-04 05:38:50 --> URI Class Initialized
DEBUG - 2011-05-04 05:38:50 --> Router Class Initialized
ERROR - 2011-05-04 05:38:50 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-05-04 05:39:50 --> Config Class Initialized
DEBUG - 2011-05-04 05:39:50 --> Hooks Class Initialized
DEBUG - 2011-05-04 05:39:50 --> Utf8 Class Initialized
DEBUG - 2011-05-04 05:39:50 --> UTF-8 Support Enabled
DEBUG - 2011-05-04 05:39:50 --> URI Class Initialized
DEBUG - 2011-05-04 05:39:50 --> Router Class Initialized
DEBUG - 2011-05-04 05:39:50 --> Output Class Initialized
DEBUG - 2011-05-04 05:39:50 --> Input Class Initialized
DEBUG - 2011-05-04 05:39:50 --> Global POST and COOKIE data sanitized
DEBUG - 2011-05-04 05:39:50 --> Language Class Initialized
DEBUG - 2011-05-04 05:39:50 --> Loader Class Initialized
DEBUG - 2011-05-04 05:39:50 --> Controller Class Initialized
DEBUG - 2011-05-04 05:39:50 --> Model Class Initialized
DEBUG - 2011-05-04 05:39:50 --> Model Class Initialized
DEBUG - 2011-05-04 05:39:50 --> Model Class Initialized
DEBUG - 2011-05-04 05:39:50 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-05-04 05:39:50 --> Database Driver Class Initialized
DEBUG - 2011-05-04 05:39:50 --> File loaded: application/views/table/main.php
DEBUG - 2011-05-04 05:39:50 --> Helper loaded: url_helper
DEBUG - 2011-05-04 05:39:50 --> File loaded: application/views/common/header.php
DEBUG - 2011-05-04 05:39:50 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-05-04 05:39:50 --> File loaded: application/views/common/footer.php
DEBUG - 2011-05-04 05:39:50 --> File loaded: application/views/layout/main.php
DEBUG - 2011-05-04 05:39:50 --> Final output sent to browser
DEBUG - 2011-05-04 05:39:50 --> Total execution time: 0.4043
DEBUG - 2011-05-04 05:39:53 --> Config Class Initialized
DEBUG - 2011-05-04 05:39:53 --> Hooks Class Initialized
DEBUG - 2011-05-04 05:39:53 --> Utf8 Class Initialized
DEBUG - 2011-05-04 05:39:53 --> UTF-8 Support Enabled
DEBUG - 2011-05-04 05:39:53 --> URI Class Initialized
DEBUG - 2011-05-04 05:39:53 --> Router Class Initialized
ERROR - 2011-05-04 05:39:53 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-05-04 05:40:04 --> Config Class Initialized
DEBUG - 2011-05-04 05:40:04 --> Hooks Class Initialized
DEBUG - 2011-05-04 05:40:04 --> Utf8 Class Initialized
DEBUG - 2011-05-04 05:40:04 --> UTF-8 Support Enabled
DEBUG - 2011-05-04 05:40:04 --> URI Class Initialized
DEBUG - 2011-05-04 05:40:04 --> Router Class Initialized
DEBUG - 2011-05-04 05:40:04 --> Output Class Initialized
DEBUG - 2011-05-04 05:40:04 --> Input Class Initialized
DEBUG - 2011-05-04 05:40:04 --> Global POST and COOKIE data sanitized
DEBUG - 2011-05-04 05:40:04 --> Language Class Initialized
DEBUG - 2011-05-04 05:40:04 --> Loader Class Initialized
DEBUG - 2011-05-04 05:40:04 --> Controller Class Initialized
DEBUG - 2011-05-04 05:40:04 --> Model Class Initialized
DEBUG - 2011-05-04 05:40:04 --> Model Class Initialized
DEBUG - 2011-05-04 05:40:04 --> Model Class Initialized
DEBUG - 2011-05-04 05:40:04 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-05-04 05:40:05 --> Database Driver Class Initialized
DEBUG - 2011-05-04 05:40:05 --> File loaded: application/views/table/main.php
DEBUG - 2011-05-04 05:40:05 --> Helper loaded: url_helper
DEBUG - 2011-05-04 05:40:05 --> File loaded: application/views/common/header.php
DEBUG - 2011-05-04 05:40:05 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-05-04 05:40:05 --> File loaded: application/views/common/footer.php
DEBUG - 2011-05-04 05:40:05 --> File loaded: application/views/layout/main.php
DEBUG - 2011-05-04 05:40:05 --> Final output sent to browser
DEBUG - 2011-05-04 05:40:05 --> Total execution time: 0.8095
DEBUG - 2011-05-04 05:40:08 --> Config Class Initialized
DEBUG - 2011-05-04 05:40:08 --> Hooks Class Initialized
DEBUG - 2011-05-04 05:40:08 --> Utf8 Class Initialized
DEBUG - 2011-05-04 05:40:08 --> UTF-8 Support Enabled
DEBUG - 2011-05-04 05:40:08 --> URI Class Initialized
DEBUG - 2011-05-04 05:40:08 --> Router Class Initialized
ERROR - 2011-05-04 05:40:08 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-05-04 05:40:28 --> Config Class Initialized
DEBUG - 2011-05-04 05:40:28 --> Hooks Class Initialized
DEBUG - 2011-05-04 05:40:28 --> Utf8 Class Initialized
DEBUG - 2011-05-04 05:40:28 --> UTF-8 Support Enabled
DEBUG - 2011-05-04 05:40:28 --> URI Class Initialized
DEBUG - 2011-05-04 05:40:28 --> Router Class Initialized
DEBUG - 2011-05-04 05:40:28 --> Output Class Initialized
DEBUG - 2011-05-04 05:40:28 --> Input Class Initialized
DEBUG - 2011-05-04 05:40:28 --> Global POST and COOKIE data sanitized
DEBUG - 2011-05-04 05:40:28 --> Language Class Initialized
DEBUG - 2011-05-04 05:40:28 --> Loader Class Initialized
DEBUG - 2011-05-04 05:40:28 --> Controller Class Initialized
DEBUG - 2011-05-04 05:40:28 --> Model Class Initialized
DEBUG - 2011-05-04 05:40:28 --> Model Class Initialized
DEBUG - 2011-05-04 05:40:28 --> Model Class Initialized
DEBUG - 2011-05-04 05:40:28 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-05-04 05:40:28 --> Database Driver Class Initialized
DEBUG - 2011-05-04 05:40:30 --> File loaded: application/views/table/main.php
DEBUG - 2011-05-04 05:40:30 --> Helper loaded: url_helper
DEBUG - 2011-05-04 05:40:30 --> File loaded: application/views/common/header.php
DEBUG - 2011-05-04 05:40:30 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-05-04 05:40:30 --> File loaded: application/views/common/footer.php
DEBUG - 2011-05-04 05:40:30 --> File loaded: application/views/layout/main.php
DEBUG - 2011-05-04 05:40:30 --> Final output sent to browser
DEBUG - 2011-05-04 05:40:30 --> Total execution time: 1.7132
DEBUG - 2011-05-04 05:40:32 --> Config Class Initialized
DEBUG - 2011-05-04 05:40:32 --> Hooks Class Initialized
DEBUG - 2011-05-04 05:40:32 --> Utf8 Class Initialized
DEBUG - 2011-05-04 05:40:32 --> UTF-8 Support Enabled
DEBUG - 2011-05-04 05:40:32 --> URI Class Initialized
DEBUG - 2011-05-04 05:40:32 --> Router Class Initialized
ERROR - 2011-05-04 05:40:32 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-05-04 05:40:42 --> Config Class Initialized
DEBUG - 2011-05-04 05:40:42 --> Hooks Class Initialized
DEBUG - 2011-05-04 05:40:42 --> Utf8 Class Initialized
DEBUG - 2011-05-04 05:40:42 --> UTF-8 Support Enabled
DEBUG - 2011-05-04 05:40:42 --> URI Class Initialized
DEBUG - 2011-05-04 05:40:42 --> Router Class Initialized
DEBUG - 2011-05-04 05:40:42 --> Output Class Initialized
DEBUG - 2011-05-04 05:40:42 --> Input Class Initialized
DEBUG - 2011-05-04 05:40:42 --> Global POST and COOKIE data sanitized
DEBUG - 2011-05-04 05:40:42 --> Language Class Initialized
DEBUG - 2011-05-04 05:40:42 --> Loader Class Initialized
DEBUG - 2011-05-04 05:40:42 --> Controller Class Initialized
DEBUG - 2011-05-04 05:40:42 --> Model Class Initialized
DEBUG - 2011-05-04 05:40:42 --> Model Class Initialized
DEBUG - 2011-05-04 05:40:42 --> Model Class Initialized
DEBUG - 2011-05-04 05:40:42 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-05-04 05:40:42 --> Database Driver Class Initialized
DEBUG - 2011-05-04 05:40:44 --> File loaded: application/views/table/main.php
DEBUG - 2011-05-04 05:40:44 --> Helper loaded: url_helper
DEBUG - 2011-05-04 05:40:44 --> File loaded: application/views/common/header.php
DEBUG - 2011-05-04 05:40:44 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-05-04 05:40:44 --> File loaded: application/views/common/footer.php
DEBUG - 2011-05-04 05:40:44 --> File loaded: application/views/layout/main.php
DEBUG - 2011-05-04 05:40:44 --> Final output sent to browser
DEBUG - 2011-05-04 05:40:44 --> Total execution time: 2.0507
DEBUG - 2011-05-04 05:40:46 --> Config Class Initialized
DEBUG - 2011-05-04 05:40:46 --> Hooks Class Initialized
DEBUG - 2011-05-04 05:40:46 --> Utf8 Class Initialized
DEBUG - 2011-05-04 05:40:46 --> UTF-8 Support Enabled
DEBUG - 2011-05-04 05:40:46 --> URI Class Initialized
DEBUG - 2011-05-04 05:40:46 --> Router Class Initialized
ERROR - 2011-05-04 05:40:46 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-05-04 05:40:55 --> Config Class Initialized
DEBUG - 2011-05-04 05:40:55 --> Hooks Class Initialized
DEBUG - 2011-05-04 05:40:55 --> Utf8 Class Initialized
DEBUG - 2011-05-04 05:40:55 --> UTF-8 Support Enabled
DEBUG - 2011-05-04 05:40:55 --> URI Class Initialized
DEBUG - 2011-05-04 05:40:55 --> Router Class Initialized
DEBUG - 2011-05-04 05:40:55 --> Output Class Initialized
DEBUG - 2011-05-04 05:40:55 --> Input Class Initialized
DEBUG - 2011-05-04 05:40:55 --> Global POST and COOKIE data sanitized
DEBUG - 2011-05-04 05:40:55 --> Language Class Initialized
DEBUG - 2011-05-04 05:40:55 --> Loader Class Initialized
DEBUG - 2011-05-04 05:40:55 --> Controller Class Initialized
DEBUG - 2011-05-04 05:40:55 --> Model Class Initialized
DEBUG - 2011-05-04 05:40:55 --> Model Class Initialized
DEBUG - 2011-05-04 05:40:55 --> Model Class Initialized
DEBUG - 2011-05-04 05:40:55 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-05-04 05:40:55 --> Database Driver Class Initialized
DEBUG - 2011-05-04 05:40:55 --> File loaded: application/views/table/main.php
DEBUG - 2011-05-04 05:40:55 --> Helper loaded: url_helper
DEBUG - 2011-05-04 05:40:55 --> File loaded: application/views/common/header.php
DEBUG - 2011-05-04 05:40:55 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-05-04 05:40:55 --> File loaded: application/views/common/footer.php
DEBUG - 2011-05-04 05:40:55 --> File loaded: application/views/layout/main.php
DEBUG - 2011-05-04 05:40:55 --> Final output sent to browser
DEBUG - 2011-05-04 05:40:55 --> Total execution time: 0.0820
DEBUG - 2011-05-04 05:40:58 --> Config Class Initialized
DEBUG - 2011-05-04 05:40:58 --> Hooks Class Initialized
DEBUG - 2011-05-04 05:40:58 --> Utf8 Class Initialized
DEBUG - 2011-05-04 05:40:58 --> UTF-8 Support Enabled
DEBUG - 2011-05-04 05:40:58 --> URI Class Initialized
DEBUG - 2011-05-04 05:40:58 --> Router Class Initialized
ERROR - 2011-05-04 05:40:58 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-05-04 05:41:01 --> Config Class Initialized
DEBUG - 2011-05-04 05:41:01 --> Hooks Class Initialized
DEBUG - 2011-05-04 05:41:01 --> Utf8 Class Initialized
DEBUG - 2011-05-04 05:41:01 --> UTF-8 Support Enabled
DEBUG - 2011-05-04 05:41:01 --> URI Class Initialized
DEBUG - 2011-05-04 05:41:01 --> Router Class Initialized
DEBUG - 2011-05-04 05:41:01 --> Output Class Initialized
DEBUG - 2011-05-04 05:41:01 --> Input Class Initialized
DEBUG - 2011-05-04 05:41:01 --> Global POST and COOKIE data sanitized
DEBUG - 2011-05-04 05:41:01 --> Language Class Initialized
DEBUG - 2011-05-04 05:41:01 --> Loader Class Initialized
DEBUG - 2011-05-04 05:41:01 --> Controller Class Initialized
DEBUG - 2011-05-04 05:41:01 --> Model Class Initialized
DEBUG - 2011-05-04 05:41:01 --> Model Class Initialized
DEBUG - 2011-05-04 05:41:01 --> Model Class Initialized
DEBUG - 2011-05-04 05:41:01 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-05-04 05:41:01 --> Database Driver Class Initialized
DEBUG - 2011-05-04 05:41:01 --> File loaded: application/views/table/main.php
DEBUG - 2011-05-04 05:41:01 --> Helper loaded: url_helper
DEBUG - 2011-05-04 05:41:01 --> File loaded: application/views/common/header.php
DEBUG - 2011-05-04 05:41:01 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-05-04 05:41:01 --> File loaded: application/views/common/footer.php
DEBUG - 2011-05-04 05:41:01 --> File loaded: application/views/layout/main.php
DEBUG - 2011-05-04 05:41:01 --> Final output sent to browser
DEBUG - 2011-05-04 05:41:01 --> Total execution time: 0.0909
DEBUG - 2011-05-04 05:41:03 --> Config Class Initialized
DEBUG - 2011-05-04 05:41:03 --> Hooks Class Initialized
DEBUG - 2011-05-04 05:41:03 --> Utf8 Class Initialized
DEBUG - 2011-05-04 05:41:03 --> UTF-8 Support Enabled
DEBUG - 2011-05-04 05:41:03 --> URI Class Initialized
DEBUG - 2011-05-04 05:41:03 --> Router Class Initialized
DEBUG - 2011-05-04 05:41:03 --> Output Class Initialized
DEBUG - 2011-05-04 05:41:03 --> Input Class Initialized
DEBUG - 2011-05-04 05:41:03 --> Global POST and COOKIE data sanitized
DEBUG - 2011-05-04 05:41:03 --> Language Class Initialized
DEBUG - 2011-05-04 05:41:03 --> Loader Class Initialized
DEBUG - 2011-05-04 05:41:03 --> Controller Class Initialized
DEBUG - 2011-05-04 05:41:03 --> Model Class Initialized
DEBUG - 2011-05-04 05:41:03 --> Model Class Initialized
DEBUG - 2011-05-04 05:41:03 --> Model Class Initialized
DEBUG - 2011-05-04 05:41:03 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-05-04 05:41:03 --> Database Driver Class Initialized
DEBUG - 2011-05-04 05:41:03 --> File loaded: application/views/table/main.php
DEBUG - 2011-05-04 05:41:03 --> Helper loaded: url_helper
DEBUG - 2011-05-04 05:41:03 --> File loaded: application/views/common/header.php
DEBUG - 2011-05-04 05:41:03 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-05-04 05:41:03 --> File loaded: application/views/common/footer.php
DEBUG - 2011-05-04 05:41:03 --> File loaded: application/views/layout/main.php
DEBUG - 2011-05-04 05:41:03 --> Final output sent to browser
DEBUG - 2011-05-04 05:41:03 --> Total execution time: 0.0496
DEBUG - 2011-05-04 05:41:35 --> Config Class Initialized
DEBUG - 2011-05-04 05:41:35 --> Hooks Class Initialized
DEBUG - 2011-05-04 05:41:35 --> Utf8 Class Initialized
DEBUG - 2011-05-04 05:41:35 --> UTF-8 Support Enabled
DEBUG - 2011-05-04 05:41:35 --> URI Class Initialized
DEBUG - 2011-05-04 05:41:35 --> Router Class Initialized
DEBUG - 2011-05-04 05:41:35 --> Output Class Initialized
DEBUG - 2011-05-04 05:41:35 --> Input Class Initialized
DEBUG - 2011-05-04 05:41:35 --> Global POST and COOKIE data sanitized
DEBUG - 2011-05-04 05:41:35 --> Language Class Initialized
DEBUG - 2011-05-04 05:41:35 --> Loader Class Initialized
DEBUG - 2011-05-04 05:41:35 --> Controller Class Initialized
DEBUG - 2011-05-04 05:41:35 --> Model Class Initialized
DEBUG - 2011-05-04 05:41:35 --> Model Class Initialized
DEBUG - 2011-05-04 05:41:35 --> Model Class Initialized
DEBUG - 2011-05-04 05:41:35 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-05-04 05:41:35 --> Database Driver Class Initialized
DEBUG - 2011-05-04 05:41:35 --> File loaded: application/views/table/main.php
DEBUG - 2011-05-04 05:41:35 --> Helper loaded: url_helper
DEBUG - 2011-05-04 05:41:35 --> File loaded: application/views/common/header.php
DEBUG - 2011-05-04 05:41:35 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-05-04 05:41:35 --> File loaded: application/views/common/footer.php
DEBUG - 2011-05-04 05:41:35 --> File loaded: application/views/layout/main.php
DEBUG - 2011-05-04 05:41:35 --> Final output sent to browser
DEBUG - 2011-05-04 05:41:35 --> Total execution time: 0.0398
DEBUG - 2011-05-04 05:41:41 --> Config Class Initialized
DEBUG - 2011-05-04 05:41:41 --> Hooks Class Initialized
DEBUG - 2011-05-04 05:41:41 --> Utf8 Class Initialized
DEBUG - 2011-05-04 05:41:41 --> UTF-8 Support Enabled
DEBUG - 2011-05-04 05:41:41 --> URI Class Initialized
DEBUG - 2011-05-04 05:41:41 --> Router Class Initialized
DEBUG - 2011-05-04 05:41:41 --> Output Class Initialized
DEBUG - 2011-05-04 05:41:41 --> Input Class Initialized
DEBUG - 2011-05-04 05:41:41 --> Global POST and COOKIE data sanitized
DEBUG - 2011-05-04 05:41:41 --> Language Class Initialized
DEBUG - 2011-05-04 05:41:41 --> Loader Class Initialized
DEBUG - 2011-05-04 05:41:41 --> Controller Class Initialized
DEBUG - 2011-05-04 05:41:41 --> Model Class Initialized
DEBUG - 2011-05-04 05:41:41 --> Model Class Initialized
DEBUG - 2011-05-04 05:41:41 --> Model Class Initialized
DEBUG - 2011-05-04 05:41:41 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-05-04 05:41:41 --> Database Driver Class Initialized
DEBUG - 2011-05-04 05:41:41 --> File loaded: application/views/table/main.php
DEBUG - 2011-05-04 05:41:41 --> Helper loaded: url_helper
DEBUG - 2011-05-04 05:41:41 --> File loaded: application/views/common/header.php
DEBUG - 2011-05-04 05:41:41 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-05-04 05:41:41 --> File loaded: application/views/common/footer.php
DEBUG - 2011-05-04 05:41:41 --> File loaded: application/views/layout/main.php
DEBUG - 2011-05-04 05:41:41 --> Final output sent to browser
DEBUG - 2011-05-04 05:41:41 --> Total execution time: 0.0843
DEBUG - 2011-05-04 05:58:53 --> Config Class Initialized
DEBUG - 2011-05-04 05:58:53 --> Hooks Class Initialized
DEBUG - 2011-05-04 05:58:53 --> Utf8 Class Initialized
DEBUG - 2011-05-04 05:58:53 --> UTF-8 Support Enabled
DEBUG - 2011-05-04 05:58:53 --> URI Class Initialized
DEBUG - 2011-05-04 05:58:53 --> Router Class Initialized
DEBUG - 2011-05-04 05:58:53 --> Output Class Initialized
DEBUG - 2011-05-04 05:58:53 --> Input Class Initialized
DEBUG - 2011-05-04 05:58:53 --> Global POST and COOKIE data sanitized
DEBUG - 2011-05-04 05:58:53 --> Language Class Initialized
DEBUG - 2011-05-04 05:58:53 --> Loader Class Initialized
DEBUG - 2011-05-04 05:58:53 --> Controller Class Initialized
DEBUG - 2011-05-04 05:58:53 --> Model Class Initialized
DEBUG - 2011-05-04 05:58:53 --> Model Class Initialized
DEBUG - 2011-05-04 05:58:53 --> Model Class Initialized
DEBUG - 2011-05-04 05:58:53 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-05-04 05:58:54 --> Database Driver Class Initialized
DEBUG - 2011-05-04 05:58:54 --> File loaded: application/views/table/main.php
DEBUG - 2011-05-04 05:58:54 --> Helper loaded: url_helper
DEBUG - 2011-05-04 05:58:54 --> File loaded: application/views/common/header.php
DEBUG - 2011-05-04 05:58:54 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-05-04 05:58:54 --> File loaded: application/views/common/footer.php
DEBUG - 2011-05-04 05:58:54 --> File loaded: application/views/layout/main.php
DEBUG - 2011-05-04 05:58:54 --> Final output sent to browser
DEBUG - 2011-05-04 05:58:54 --> Total execution time: 1.1803
DEBUG - 2011-05-04 05:58:55 --> Config Class Initialized
DEBUG - 2011-05-04 05:58:55 --> Hooks Class Initialized
DEBUG - 2011-05-04 05:58:55 --> Utf8 Class Initialized
DEBUG - 2011-05-04 05:58:55 --> UTF-8 Support Enabled
DEBUG - 2011-05-04 05:58:55 --> URI Class Initialized
DEBUG - 2011-05-04 05:58:55 --> Router Class Initialized
DEBUG - 2011-05-04 05:58:55 --> Output Class Initialized
DEBUG - 2011-05-04 05:58:55 --> Input Class Initialized
DEBUG - 2011-05-04 05:58:55 --> Global POST and COOKIE data sanitized
DEBUG - 2011-05-04 05:58:55 --> Language Class Initialized
DEBUG - 2011-05-04 05:58:55 --> Loader Class Initialized
DEBUG - 2011-05-04 05:58:55 --> Controller Class Initialized
ERROR - 2011-05-04 05:58:55 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-05-04 05:58:55 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-05-04 05:58:55 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-05-04 05:58:55 --> Model Class Initialized
DEBUG - 2011-05-04 05:58:55 --> Model Class Initialized
DEBUG - 2011-05-04 05:58:55 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-05-04 05:58:55 --> Database Driver Class Initialized
DEBUG - 2011-05-04 05:58:55 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-05-04 05:58:55 --> Helper loaded: url_helper
DEBUG - 2011-05-04 05:58:55 --> File loaded: application/views/common/header.php
DEBUG - 2011-05-04 05:58:55 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-05-04 05:58:55 --> File loaded: application/views/common/footer.php
DEBUG - 2011-05-04 05:58:55 --> File loaded: application/views/layout/main.php
DEBUG - 2011-05-04 05:58:55 --> Final output sent to browser
DEBUG - 2011-05-04 05:58:55 --> Total execution time: 0.3252
DEBUG - 2011-05-04 08:08:12 --> Config Class Initialized
DEBUG - 2011-05-04 08:08:12 --> Hooks Class Initialized
DEBUG - 2011-05-04 08:08:12 --> Utf8 Class Initialized
DEBUG - 2011-05-04 08:08:12 --> UTF-8 Support Enabled
DEBUG - 2011-05-04 08:08:12 --> URI Class Initialized
DEBUG - 2011-05-04 08:08:12 --> Router Class Initialized
DEBUG - 2011-05-04 08:08:12 --> Output Class Initialized
DEBUG - 2011-05-04 08:08:12 --> Input Class Initialized
DEBUG - 2011-05-04 08:08:12 --> Global POST and COOKIE data sanitized
DEBUG - 2011-05-04 08:08:12 --> Language Class Initialized
DEBUG - 2011-05-04 08:08:12 --> Loader Class Initialized
DEBUG - 2011-05-04 08:08:12 --> Controller Class Initialized
DEBUG - 2011-05-04 08:08:12 --> Model Class Initialized
DEBUG - 2011-05-04 08:08:12 --> Model Class Initialized
DEBUG - 2011-05-04 08:08:12 --> Model Class Initialized
DEBUG - 2011-05-04 08:08:12 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-05-04 08:08:12 --> Database Driver Class Initialized
DEBUG - 2011-05-04 08:08:12 --> File loaded: application/views/table/main.php
DEBUG - 2011-05-04 08:08:12 --> Helper loaded: url_helper
DEBUG - 2011-05-04 08:08:12 --> File loaded: application/views/common/header.php
DEBUG - 2011-05-04 08:08:12 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-05-04 08:08:12 --> File loaded: application/views/common/footer.php
DEBUG - 2011-05-04 08:08:12 --> File loaded: application/views/layout/main.php
DEBUG - 2011-05-04 08:08:12 --> Final output sent to browser
DEBUG - 2011-05-04 08:08:12 --> Total execution time: 0.5985
DEBUG - 2011-05-04 08:08:26 --> Config Class Initialized
DEBUG - 2011-05-04 08:08:26 --> Hooks Class Initialized
DEBUG - 2011-05-04 08:08:26 --> Utf8 Class Initialized
DEBUG - 2011-05-04 08:08:26 --> UTF-8 Support Enabled
DEBUG - 2011-05-04 08:08:26 --> URI Class Initialized
DEBUG - 2011-05-04 08:08:26 --> Router Class Initialized
ERROR - 2011-05-04 08:08:26 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-05-04 08:08:31 --> Config Class Initialized
DEBUG - 2011-05-04 08:08:31 --> Hooks Class Initialized
DEBUG - 2011-05-04 08:08:31 --> Utf8 Class Initialized
DEBUG - 2011-05-04 08:08:31 --> UTF-8 Support Enabled
DEBUG - 2011-05-04 08:08:31 --> URI Class Initialized
DEBUG - 2011-05-04 08:08:31 --> Router Class Initialized
ERROR - 2011-05-04 08:08:31 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-05-04 08:08:33 --> Config Class Initialized
DEBUG - 2011-05-04 08:08:33 --> Hooks Class Initialized
DEBUG - 2011-05-04 08:08:33 --> Utf8 Class Initialized
DEBUG - 2011-05-04 08:08:33 --> UTF-8 Support Enabled
DEBUG - 2011-05-04 08:08:33 --> URI Class Initialized
DEBUG - 2011-05-04 08:08:33 --> Router Class Initialized
DEBUG - 2011-05-04 08:08:33 --> Output Class Initialized
DEBUG - 2011-05-04 08:08:33 --> Input Class Initialized
DEBUG - 2011-05-04 08:08:33 --> Global POST and COOKIE data sanitized
DEBUG - 2011-05-04 08:08:33 --> Language Class Initialized
DEBUG - 2011-05-04 08:08:33 --> Loader Class Initialized
DEBUG - 2011-05-04 08:08:33 --> Controller Class Initialized
DEBUG - 2011-05-04 08:08:33 --> Model Class Initialized
DEBUG - 2011-05-04 08:08:33 --> Model Class Initialized
DEBUG - 2011-05-04 08:08:33 --> Model Class Initialized
DEBUG - 2011-05-04 08:08:33 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-05-04 08:08:33 --> Database Driver Class Initialized
DEBUG - 2011-05-04 08:08:33 --> File loaded: application/views/table/main.php
DEBUG - 2011-05-04 08:08:33 --> Helper loaded: url_helper
DEBUG - 2011-05-04 08:08:33 --> File loaded: application/views/common/header.php
DEBUG - 2011-05-04 08:08:33 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-05-04 08:08:33 --> File loaded: application/views/common/footer.php
DEBUG - 2011-05-04 08:08:33 --> File loaded: application/views/layout/main.php
DEBUG - 2011-05-04 08:08:33 --> Final output sent to browser
DEBUG - 2011-05-04 08:08:33 --> Total execution time: 0.0688
DEBUG - 2011-05-04 08:08:53 --> Config Class Initialized
DEBUG - 2011-05-04 08:08:53 --> Hooks Class Initialized
DEBUG - 2011-05-04 08:08:53 --> Utf8 Class Initialized
DEBUG - 2011-05-04 08:08:53 --> UTF-8 Support Enabled
DEBUG - 2011-05-04 08:08:53 --> URI Class Initialized
DEBUG - 2011-05-04 08:08:53 --> Router Class Initialized
DEBUG - 2011-05-04 08:08:53 --> Output Class Initialized
DEBUG - 2011-05-04 08:08:53 --> Input Class Initialized
DEBUG - 2011-05-04 08:08:53 --> Global POST and COOKIE data sanitized
DEBUG - 2011-05-04 08:08:53 --> Language Class Initialized
DEBUG - 2011-05-04 08:08:53 --> Loader Class Initialized
DEBUG - 2011-05-04 08:08:53 --> Controller Class Initialized
ERROR - 2011-05-04 08:08:53 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-05-04 08:08:53 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-05-04 08:08:53 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-05-04 08:08:53 --> Model Class Initialized
DEBUG - 2011-05-04 08:08:53 --> Model Class Initialized
DEBUG - 2011-05-04 08:08:53 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-05-04 08:08:53 --> Database Driver Class Initialized
DEBUG - 2011-05-04 08:08:53 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-05-04 08:08:53 --> Helper loaded: url_helper
DEBUG - 2011-05-04 08:08:53 --> File loaded: application/views/common/header.php
DEBUG - 2011-05-04 08:08:53 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-05-04 08:08:53 --> File loaded: application/views/common/footer.php
DEBUG - 2011-05-04 08:08:53 --> File loaded: application/views/layout/main.php
DEBUG - 2011-05-04 08:08:53 --> Final output sent to browser
DEBUG - 2011-05-04 08:08:53 --> Total execution time: 0.1239
DEBUG - 2011-05-04 08:08:55 --> Config Class Initialized
DEBUG - 2011-05-04 08:08:55 --> Hooks Class Initialized
DEBUG - 2011-05-04 08:08:55 --> Utf8 Class Initialized
DEBUG - 2011-05-04 08:08:55 --> UTF-8 Support Enabled
DEBUG - 2011-05-04 08:08:55 --> URI Class Initialized
DEBUG - 2011-05-04 08:08:55 --> Router Class Initialized
DEBUG - 2011-05-04 08:08:55 --> Output Class Initialized
DEBUG - 2011-05-04 08:08:55 --> Input Class Initialized
DEBUG - 2011-05-04 08:08:55 --> Global POST and COOKIE data sanitized
DEBUG - 2011-05-04 08:08:55 --> Language Class Initialized
DEBUG - 2011-05-04 08:08:55 --> Loader Class Initialized
DEBUG - 2011-05-04 08:08:55 --> Controller Class Initialized
DEBUG - 2011-05-04 08:08:55 --> Model Class Initialized
DEBUG - 2011-05-04 08:08:55 --> Model Class Initialized
DEBUG - 2011-05-04 08:08:55 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-05-04 08:08:55 --> Database Driver Class Initialized
DEBUG - 2011-05-04 08:08:56 --> Final output sent to browser
DEBUG - 2011-05-04 08:08:56 --> Total execution time: 1.4272
DEBUG - 2011-05-04 08:13:32 --> Config Class Initialized
DEBUG - 2011-05-04 08:13:32 --> Hooks Class Initialized
DEBUG - 2011-05-04 08:13:32 --> Utf8 Class Initialized
DEBUG - 2011-05-04 08:13:32 --> UTF-8 Support Enabled
DEBUG - 2011-05-04 08:13:32 --> URI Class Initialized
DEBUG - 2011-05-04 08:13:32 --> Router Class Initialized
DEBUG - 2011-05-04 08:13:32 --> Output Class Initialized
DEBUG - 2011-05-04 08:13:32 --> Input Class Initialized
DEBUG - 2011-05-04 08:13:32 --> Global POST and COOKIE data sanitized
DEBUG - 2011-05-04 08:13:32 --> Language Class Initialized
DEBUG - 2011-05-04 08:13:32 --> Loader Class Initialized
DEBUG - 2011-05-04 08:13:32 --> Controller Class Initialized
ERROR - 2011-05-04 08:13:32 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-05-04 08:13:32 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-05-04 08:13:32 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-05-04 08:13:32 --> Model Class Initialized
DEBUG - 2011-05-04 08:13:32 --> Model Class Initialized
DEBUG - 2011-05-04 08:13:32 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-05-04 08:13:32 --> Database Driver Class Initialized
DEBUG - 2011-05-04 08:13:32 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-05-04 08:13:32 --> Helper loaded: url_helper
DEBUG - 2011-05-04 08:13:32 --> File loaded: application/views/common/header.php
DEBUG - 2011-05-04 08:13:32 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-05-04 08:13:32 --> File loaded: application/views/common/footer.php
DEBUG - 2011-05-04 08:13:32 --> File loaded: application/views/layout/main.php
DEBUG - 2011-05-04 08:13:32 --> Final output sent to browser
DEBUG - 2011-05-04 08:13:32 --> Total execution time: 0.0865
DEBUG - 2011-05-04 08:13:34 --> Config Class Initialized
DEBUG - 2011-05-04 08:13:34 --> Hooks Class Initialized
DEBUG - 2011-05-04 08:13:34 --> Utf8 Class Initialized
DEBUG - 2011-05-04 08:13:34 --> UTF-8 Support Enabled
DEBUG - 2011-05-04 08:13:34 --> URI Class Initialized
DEBUG - 2011-05-04 08:13:34 --> Router Class Initialized
DEBUG - 2011-05-04 08:13:34 --> Output Class Initialized
DEBUG - 2011-05-04 08:13:34 --> Input Class Initialized
DEBUG - 2011-05-04 08:13:34 --> Global POST and COOKIE data sanitized
DEBUG - 2011-05-04 08:13:34 --> Language Class Initialized
DEBUG - 2011-05-04 08:13:34 --> Loader Class Initialized
DEBUG - 2011-05-04 08:13:34 --> Controller Class Initialized
DEBUG - 2011-05-04 08:13:34 --> Model Class Initialized
DEBUG - 2011-05-04 08:13:34 --> Model Class Initialized
DEBUG - 2011-05-04 08:13:34 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-05-04 08:13:34 --> Database Driver Class Initialized
DEBUG - 2011-05-04 08:13:35 --> Final output sent to browser
DEBUG - 2011-05-04 08:13:35 --> Total execution time: 0.9378
DEBUG - 2011-05-04 08:19:27 --> Config Class Initialized
DEBUG - 2011-05-04 08:19:27 --> Hooks Class Initialized
DEBUG - 2011-05-04 08:19:27 --> Utf8 Class Initialized
DEBUG - 2011-05-04 08:19:27 --> UTF-8 Support Enabled
DEBUG - 2011-05-04 08:19:27 --> URI Class Initialized
DEBUG - 2011-05-04 08:19:27 --> Router Class Initialized
DEBUG - 2011-05-04 08:19:27 --> Output Class Initialized
DEBUG - 2011-05-04 08:19:27 --> Input Class Initialized
DEBUG - 2011-05-04 08:19:27 --> Global POST and COOKIE data sanitized
DEBUG - 2011-05-04 08:19:27 --> Language Class Initialized
DEBUG - 2011-05-04 08:19:27 --> Loader Class Initialized
DEBUG - 2011-05-04 08:19:27 --> Controller Class Initialized
DEBUG - 2011-05-04 08:19:27 --> Model Class Initialized
DEBUG - 2011-05-04 08:19:27 --> Model Class Initialized
DEBUG - 2011-05-04 08:19:27 --> Model Class Initialized
DEBUG - 2011-05-04 08:19:27 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-05-04 08:19:27 --> Database Driver Class Initialized
DEBUG - 2011-05-04 08:19:27 --> File loaded: application/views/table/main.php
DEBUG - 2011-05-04 08:19:27 --> Helper loaded: url_helper
DEBUG - 2011-05-04 08:19:27 --> File loaded: application/views/common/header.php
DEBUG - 2011-05-04 08:19:27 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-05-04 08:19:27 --> File loaded: application/views/common/footer.php
DEBUG - 2011-05-04 08:19:27 --> File loaded: application/views/layout/main.php
DEBUG - 2011-05-04 08:19:27 --> Final output sent to browser
DEBUG - 2011-05-04 08:19:27 --> Total execution time: 0.3112
DEBUG - 2011-05-04 09:06:49 --> Config Class Initialized
DEBUG - 2011-05-04 09:06:49 --> Hooks Class Initialized
DEBUG - 2011-05-04 09:06:49 --> Utf8 Class Initialized
DEBUG - 2011-05-04 09:06:49 --> UTF-8 Support Enabled
DEBUG - 2011-05-04 09:06:49 --> URI Class Initialized
DEBUG - 2011-05-04 09:06:49 --> Router Class Initialized
DEBUG - 2011-05-04 09:06:49 --> Output Class Initialized
DEBUG - 2011-05-04 09:06:49 --> Input Class Initialized
DEBUG - 2011-05-04 09:06:49 --> Global POST and COOKIE data sanitized
DEBUG - 2011-05-04 09:06:49 --> Language Class Initialized
DEBUG - 2011-05-04 09:06:49 --> Loader Class Initialized
DEBUG - 2011-05-04 09:06:49 --> Controller Class Initialized
DEBUG - 2011-05-04 09:06:49 --> Model Class Initialized
DEBUG - 2011-05-04 09:06:49 --> Model Class Initialized
DEBUG - 2011-05-04 09:06:49 --> Model Class Initialized
DEBUG - 2011-05-04 09:06:49 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-05-04 09:06:49 --> Database Driver Class Initialized
DEBUG - 2011-05-04 09:06:50 --> File loaded: application/views/table/main.php
DEBUG - 2011-05-04 09:06:50 --> Helper loaded: url_helper
DEBUG - 2011-05-04 09:06:50 --> File loaded: application/views/common/header.php
DEBUG - 2011-05-04 09:06:50 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-05-04 09:06:50 --> File loaded: application/views/common/footer.php
DEBUG - 2011-05-04 09:06:50 --> File loaded: application/views/layout/main.php
DEBUG - 2011-05-04 09:06:50 --> Final output sent to browser
DEBUG - 2011-05-04 09:06:50 --> Total execution time: 0.6075
DEBUG - 2011-05-04 09:08:44 --> Config Class Initialized
DEBUG - 2011-05-04 09:08:44 --> Hooks Class Initialized
DEBUG - 2011-05-04 09:08:44 --> Utf8 Class Initialized
DEBUG - 2011-05-04 09:08:44 --> UTF-8 Support Enabled
DEBUG - 2011-05-04 09:08:44 --> URI Class Initialized
DEBUG - 2011-05-04 09:08:44 --> Router Class Initialized
ERROR - 2011-05-04 09:08:44 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-05-04 09:08:50 --> Config Class Initialized
DEBUG - 2011-05-04 09:08:50 --> Hooks Class Initialized
DEBUG - 2011-05-04 09:08:50 --> Utf8 Class Initialized
DEBUG - 2011-05-04 09:08:50 --> UTF-8 Support Enabled
DEBUG - 2011-05-04 09:08:50 --> URI Class Initialized
DEBUG - 2011-05-04 09:08:50 --> Router Class Initialized
ERROR - 2011-05-04 09:08:50 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-05-04 09:12:16 --> Config Class Initialized
DEBUG - 2011-05-04 09:12:16 --> Hooks Class Initialized
DEBUG - 2011-05-04 09:12:16 --> Utf8 Class Initialized
DEBUG - 2011-05-04 09:12:16 --> UTF-8 Support Enabled
DEBUG - 2011-05-04 09:12:16 --> URI Class Initialized
DEBUG - 2011-05-04 09:12:16 --> Router Class Initialized
DEBUG - 2011-05-04 09:12:16 --> Output Class Initialized
DEBUG - 2011-05-04 09:12:16 --> Input Class Initialized
DEBUG - 2011-05-04 09:12:16 --> Global POST and COOKIE data sanitized
DEBUG - 2011-05-04 09:12:16 --> Language Class Initialized
DEBUG - 2011-05-04 09:12:16 --> Loader Class Initialized
DEBUG - 2011-05-04 09:12:16 --> Controller Class Initialized
DEBUG - 2011-05-04 09:12:16 --> Model Class Initialized
DEBUG - 2011-05-04 09:12:16 --> Model Class Initialized
DEBUG - 2011-05-04 09:12:16 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-05-04 09:12:16 --> Database Driver Class Initialized
DEBUG - 2011-05-04 09:12:17 --> Final output sent to browser
DEBUG - 2011-05-04 09:12:17 --> Total execution time: 1.0396
DEBUG - 2011-05-04 09:12:19 --> Config Class Initialized
DEBUG - 2011-05-04 09:12:19 --> Hooks Class Initialized
DEBUG - 2011-05-04 09:12:19 --> Utf8 Class Initialized
DEBUG - 2011-05-04 09:12:19 --> UTF-8 Support Enabled
DEBUG - 2011-05-04 09:12:19 --> URI Class Initialized
DEBUG - 2011-05-04 09:12:19 --> Router Class Initialized
DEBUG - 2011-05-04 09:12:19 --> Output Class Initialized
DEBUG - 2011-05-04 09:12:19 --> Input Class Initialized
DEBUG - 2011-05-04 09:12:19 --> Global POST and COOKIE data sanitized
DEBUG - 2011-05-04 09:12:19 --> Language Class Initialized
DEBUG - 2011-05-04 09:12:19 --> Loader Class Initialized
DEBUG - 2011-05-04 09:12:19 --> Controller Class Initialized
DEBUG - 2011-05-04 09:12:19 --> Model Class Initialized
DEBUG - 2011-05-04 09:12:19 --> Model Class Initialized
DEBUG - 2011-05-04 09:12:19 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-05-04 09:12:19 --> Database Driver Class Initialized
DEBUG - 2011-05-04 09:12:19 --> Final output sent to browser
DEBUG - 2011-05-04 09:12:19 --> Total execution time: 0.6199
DEBUG - 2011-05-04 09:19:34 --> Config Class Initialized
DEBUG - 2011-05-04 09:19:35 --> Hooks Class Initialized
DEBUG - 2011-05-04 09:19:35 --> Utf8 Class Initialized
DEBUG - 2011-05-04 09:19:35 --> UTF-8 Support Enabled
DEBUG - 2011-05-04 09:19:35 --> URI Class Initialized
DEBUG - 2011-05-04 09:19:35 --> Router Class Initialized
DEBUG - 2011-05-04 09:19:35 --> Output Class Initialized
DEBUG - 2011-05-04 09:19:35 --> Input Class Initialized
DEBUG - 2011-05-04 09:19:35 --> Global POST and COOKIE data sanitized
DEBUG - 2011-05-04 09:19:35 --> Language Class Initialized
DEBUG - 2011-05-04 09:19:35 --> Loader Class Initialized
DEBUG - 2011-05-04 09:19:35 --> Controller Class Initialized
DEBUG - 2011-05-04 09:19:35 --> Model Class Initialized
DEBUG - 2011-05-04 09:19:35 --> Model Class Initialized
DEBUG - 2011-05-04 09:19:35 --> Model Class Initialized
DEBUG - 2011-05-04 09:19:35 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-05-04 09:19:35 --> Database Driver Class Initialized
DEBUG - 2011-05-04 09:19:35 --> File loaded: application/views/table/main.php
DEBUG - 2011-05-04 09:19:35 --> Helper loaded: url_helper
DEBUG - 2011-05-04 09:19:35 --> File loaded: application/views/common/header.php
DEBUG - 2011-05-04 09:19:35 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-05-04 09:19:35 --> File loaded: application/views/common/footer.php
DEBUG - 2011-05-04 09:19:35 --> File loaded: application/views/layout/main.php
DEBUG - 2011-05-04 09:19:35 --> Final output sent to browser
DEBUG - 2011-05-04 09:19:35 --> Total execution time: 0.1911
DEBUG - 2011-05-04 09:19:37 --> Config Class Initialized
DEBUG - 2011-05-04 09:19:37 --> Hooks Class Initialized
DEBUG - 2011-05-04 09:19:37 --> Utf8 Class Initialized
DEBUG - 2011-05-04 09:19:37 --> UTF-8 Support Enabled
DEBUG - 2011-05-04 09:19:37 --> URI Class Initialized
DEBUG - 2011-05-04 09:19:37 --> Router Class Initialized
ERROR - 2011-05-04 09:19:37 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-05-04 09:19:39 --> Config Class Initialized
DEBUG - 2011-05-04 09:19:39 --> Hooks Class Initialized
DEBUG - 2011-05-04 09:19:39 --> Utf8 Class Initialized
DEBUG - 2011-05-04 09:19:39 --> UTF-8 Support Enabled
DEBUG - 2011-05-04 09:19:39 --> URI Class Initialized
DEBUG - 2011-05-04 09:19:39 --> Router Class Initialized
ERROR - 2011-05-04 09:19:39 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-05-04 09:21:22 --> Config Class Initialized
DEBUG - 2011-05-04 09:21:22 --> Hooks Class Initialized
DEBUG - 2011-05-04 09:21:22 --> Utf8 Class Initialized
DEBUG - 2011-05-04 09:21:22 --> UTF-8 Support Enabled
DEBUG - 2011-05-04 09:21:22 --> URI Class Initialized
DEBUG - 2011-05-04 09:21:22 --> Router Class Initialized
ERROR - 2011-05-04 09:21:22 --> 404 Page Not Found --> robots.txt
DEBUG - 2011-05-04 09:21:22 --> Config Class Initialized
DEBUG - 2011-05-04 09:21:22 --> Hooks Class Initialized
DEBUG - 2011-05-04 09:21:22 --> Utf8 Class Initialized
DEBUG - 2011-05-04 09:21:22 --> UTF-8 Support Enabled
DEBUG - 2011-05-04 09:21:22 --> URI Class Initialized
DEBUG - 2011-05-04 09:21:22 --> Router Class Initialized
DEBUG - 2011-05-04 09:21:22 --> Output Class Initialized
DEBUG - 2011-05-04 09:21:22 --> Input Class Initialized
DEBUG - 2011-05-04 09:21:22 --> Global POST and COOKIE data sanitized
DEBUG - 2011-05-04 09:21:22 --> Language Class Initialized
DEBUG - 2011-05-04 09:21:22 --> Loader Class Initialized
DEBUG - 2011-05-04 09:21:22 --> Controller Class Initialized
DEBUG - 2011-05-04 09:21:22 --> Model Class Initialized
DEBUG - 2011-05-04 09:21:22 --> Model Class Initialized
DEBUG - 2011-05-04 09:21:22 --> Model Class Initialized
DEBUG - 2011-05-04 09:21:22 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-05-04 09:21:22 --> Database Driver Class Initialized
DEBUG - 2011-05-04 09:21:22 --> File loaded: application/views/table/main.php
DEBUG - 2011-05-04 09:21:22 --> Helper loaded: url_helper
DEBUG - 2011-05-04 09:21:22 --> File loaded: application/views/common/header.php
DEBUG - 2011-05-04 09:21:22 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-05-04 09:21:22 --> File loaded: application/views/common/footer.php
DEBUG - 2011-05-04 09:21:22 --> File loaded: application/views/layout/main.php
DEBUG - 2011-05-04 09:21:22 --> Final output sent to browser
DEBUG - 2011-05-04 09:21:22 --> Total execution time: 0.0468
DEBUG - 2011-05-04 09:40:53 --> Config Class Initialized
DEBUG - 2011-05-04 09:40:53 --> Hooks Class Initialized
DEBUG - 2011-05-04 09:40:53 --> Utf8 Class Initialized
DEBUG - 2011-05-04 09:40:53 --> UTF-8 Support Enabled
DEBUG - 2011-05-04 09:40:53 --> URI Class Initialized
DEBUG - 2011-05-04 09:40:53 --> Router Class Initialized
DEBUG - 2011-05-04 09:40:53 --> Output Class Initialized
DEBUG - 2011-05-04 09:40:53 --> Input Class Initialized
DEBUG - 2011-05-04 09:40:53 --> Global POST and COOKIE data sanitized
DEBUG - 2011-05-04 09:40:53 --> Language Class Initialized
DEBUG - 2011-05-04 09:40:54 --> Loader Class Initialized
DEBUG - 2011-05-04 09:40:54 --> Controller Class Initialized
ERROR - 2011-05-04 09:40:54 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-05-04 09:40:54 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-05-04 09:40:54 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-05-04 09:40:54 --> Model Class Initialized
DEBUG - 2011-05-04 09:40:54 --> Model Class Initialized
DEBUG - 2011-05-04 09:40:54 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-05-04 09:40:54 --> Database Driver Class Initialized
DEBUG - 2011-05-04 09:40:54 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-05-04 09:40:54 --> Helper loaded: url_helper
DEBUG - 2011-05-04 09:40:54 --> File loaded: application/views/common/header.php
DEBUG - 2011-05-04 09:40:54 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-05-04 09:40:54 --> File loaded: application/views/common/footer.php
DEBUG - 2011-05-04 09:40:54 --> File loaded: application/views/layout/main.php
DEBUG - 2011-05-04 09:40:54 --> Final output sent to browser
DEBUG - 2011-05-04 09:40:54 --> Total execution time: 1.3394
DEBUG - 2011-05-04 09:40:56 --> Config Class Initialized
DEBUG - 2011-05-04 09:40:56 --> Hooks Class Initialized
DEBUG - 2011-05-04 09:40:56 --> Utf8 Class Initialized
DEBUG - 2011-05-04 09:40:56 --> UTF-8 Support Enabled
DEBUG - 2011-05-04 09:40:56 --> URI Class Initialized
DEBUG - 2011-05-04 09:40:56 --> Router Class Initialized
DEBUG - 2011-05-04 09:40:56 --> Output Class Initialized
DEBUG - 2011-05-04 09:40:56 --> Input Class Initialized
DEBUG - 2011-05-04 09:40:56 --> Global POST and COOKIE data sanitized
DEBUG - 2011-05-04 09:40:56 --> Language Class Initialized
DEBUG - 2011-05-04 09:40:56 --> Loader Class Initialized
DEBUG - 2011-05-04 09:40:56 --> Controller Class Initialized
DEBUG - 2011-05-04 09:40:56 --> Model Class Initialized
DEBUG - 2011-05-04 09:40:56 --> Model Class Initialized
DEBUG - 2011-05-04 09:40:56 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-05-04 09:40:56 --> Database Driver Class Initialized
DEBUG - 2011-05-04 09:40:56 --> Final output sent to browser
DEBUG - 2011-05-04 09:40:56 --> Total execution time: 0.6898
DEBUG - 2011-05-04 09:40:59 --> Config Class Initialized
DEBUG - 2011-05-04 09:40:59 --> Hooks Class Initialized
DEBUG - 2011-05-04 09:40:59 --> Utf8 Class Initialized
DEBUG - 2011-05-04 09:40:59 --> UTF-8 Support Enabled
DEBUG - 2011-05-04 09:40:59 --> URI Class Initialized
DEBUG - 2011-05-04 09:40:59 --> Router Class Initialized
ERROR - 2011-05-04 09:40:59 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-05-04 09:40:59 --> Config Class Initialized
DEBUG - 2011-05-04 09:40:59 --> Hooks Class Initialized
DEBUG - 2011-05-04 09:40:59 --> Utf8 Class Initialized
DEBUG - 2011-05-04 09:40:59 --> UTF-8 Support Enabled
DEBUG - 2011-05-04 09:40:59 --> URI Class Initialized
DEBUG - 2011-05-04 09:40:59 --> Router Class Initialized
ERROR - 2011-05-04 09:40:59 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-05-04 09:41:01 --> Config Class Initialized
DEBUG - 2011-05-04 09:41:01 --> Hooks Class Initialized
DEBUG - 2011-05-04 09:41:01 --> Utf8 Class Initialized
DEBUG - 2011-05-04 09:41:01 --> UTF-8 Support Enabled
DEBUG - 2011-05-04 09:41:01 --> URI Class Initialized
DEBUG - 2011-05-04 09:41:01 --> Router Class Initialized
ERROR - 2011-05-04 09:41:01 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-05-04 11:42:31 --> Config Class Initialized
DEBUG - 2011-05-04 11:42:31 --> Hooks Class Initialized
DEBUG - 2011-05-04 11:42:31 --> Utf8 Class Initialized
DEBUG - 2011-05-04 11:42:31 --> UTF-8 Support Enabled
DEBUG - 2011-05-04 11:42:31 --> URI Class Initialized
DEBUG - 2011-05-04 11:42:31 --> Router Class Initialized
DEBUG - 2011-05-04 11:42:32 --> Output Class Initialized
DEBUG - 2011-05-04 11:42:32 --> Input Class Initialized
DEBUG - 2011-05-04 11:42:32 --> Global POST and COOKIE data sanitized
DEBUG - 2011-05-04 11:42:32 --> Language Class Initialized
DEBUG - 2011-05-04 11:42:32 --> Loader Class Initialized
DEBUG - 2011-05-04 11:42:32 --> Controller Class Initialized
ERROR - 2011-05-04 11:42:32 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-05-04 11:42:32 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-05-04 11:42:32 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-05-04 11:42:32 --> Model Class Initialized
DEBUG - 2011-05-04 11:42:32 --> Model Class Initialized
DEBUG - 2011-05-04 11:42:32 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-05-04 11:42:32 --> Database Driver Class Initialized
DEBUG - 2011-05-04 11:42:32 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-05-04 11:42:32 --> Helper loaded: url_helper
DEBUG - 2011-05-04 11:42:32 --> File loaded: application/views/common/header.php
DEBUG - 2011-05-04 11:42:32 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-05-04 11:42:32 --> File loaded: application/views/common/footer.php
DEBUG - 2011-05-04 11:42:32 --> File loaded: application/views/layout/main.php
DEBUG - 2011-05-04 11:42:32 --> Final output sent to browser
DEBUG - 2011-05-04 11:42:32 --> Total execution time: 0.5377
DEBUG - 2011-05-04 11:42:33 --> Config Class Initialized
DEBUG - 2011-05-04 11:42:33 --> Hooks Class Initialized
DEBUG - 2011-05-04 11:42:33 --> Utf8 Class Initialized
DEBUG - 2011-05-04 11:42:33 --> UTF-8 Support Enabled
DEBUG - 2011-05-04 11:42:33 --> URI Class Initialized
DEBUG - 2011-05-04 11:42:33 --> Router Class Initialized
DEBUG - 2011-05-04 11:42:33 --> Output Class Initialized
DEBUG - 2011-05-04 11:42:33 --> Input Class Initialized
DEBUG - 2011-05-04 11:42:33 --> Global POST and COOKIE data sanitized
DEBUG - 2011-05-04 11:42:33 --> Language Class Initialized
DEBUG - 2011-05-04 11:42:33 --> Loader Class Initialized
DEBUG - 2011-05-04 11:42:33 --> Controller Class Initialized
DEBUG - 2011-05-04 11:42:33 --> Model Class Initialized
DEBUG - 2011-05-04 11:42:33 --> Model Class Initialized
DEBUG - 2011-05-04 11:42:33 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-05-04 11:42:33 --> Database Driver Class Initialized
DEBUG - 2011-05-04 11:42:34 --> Final output sent to browser
DEBUG - 2011-05-04 11:42:34 --> Total execution time: 0.7021
DEBUG - 2011-05-04 11:42:36 --> Config Class Initialized
DEBUG - 2011-05-04 11:42:36 --> Hooks Class Initialized
DEBUG - 2011-05-04 11:42:36 --> Utf8 Class Initialized
DEBUG - 2011-05-04 11:42:36 --> UTF-8 Support Enabled
DEBUG - 2011-05-04 11:42:36 --> URI Class Initialized
DEBUG - 2011-05-04 11:42:36 --> Router Class Initialized
ERROR - 2011-05-04 11:42:36 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-05-04 11:42:36 --> Config Class Initialized
DEBUG - 2011-05-04 11:42:36 --> Hooks Class Initialized
DEBUG - 2011-05-04 11:42:36 --> Utf8 Class Initialized
DEBUG - 2011-05-04 11:42:36 --> UTF-8 Support Enabled
DEBUG - 2011-05-04 11:42:36 --> URI Class Initialized
DEBUG - 2011-05-04 11:42:36 --> Router Class Initialized
ERROR - 2011-05-04 11:42:36 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-05-04 11:42:56 --> Config Class Initialized
DEBUG - 2011-05-04 11:42:56 --> Hooks Class Initialized
DEBUG - 2011-05-04 11:42:56 --> Utf8 Class Initialized
DEBUG - 2011-05-04 11:42:56 --> UTF-8 Support Enabled
DEBUG - 2011-05-04 11:42:56 --> URI Class Initialized
DEBUG - 2011-05-04 11:42:56 --> Router Class Initialized
DEBUG - 2011-05-04 11:42:56 --> Output Class Initialized
DEBUG - 2011-05-04 11:42:56 --> Input Class Initialized
DEBUG - 2011-05-04 11:42:56 --> Global POST and COOKIE data sanitized
DEBUG - 2011-05-04 11:42:56 --> Language Class Initialized
DEBUG - 2011-05-04 11:42:56 --> Loader Class Initialized
DEBUG - 2011-05-04 11:42:56 --> Controller Class Initialized
ERROR - 2011-05-04 11:42:56 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-05-04 11:42:56 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-05-04 11:42:56 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-05-04 11:42:56 --> Model Class Initialized
DEBUG - 2011-05-04 11:42:56 --> Model Class Initialized
DEBUG - 2011-05-04 11:42:56 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-05-04 11:42:56 --> Database Driver Class Initialized
DEBUG - 2011-05-04 11:42:56 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-05-04 11:42:56 --> Helper loaded: url_helper
DEBUG - 2011-05-04 11:42:56 --> File loaded: application/views/common/header.php
DEBUG - 2011-05-04 11:42:56 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-05-04 11:42:56 --> File loaded: application/views/common/footer.php
DEBUG - 2011-05-04 11:42:56 --> File loaded: application/views/layout/main.php
DEBUG - 2011-05-04 11:42:56 --> Final output sent to browser
DEBUG - 2011-05-04 11:42:56 --> Total execution time: 0.0273
DEBUG - 2011-05-04 11:42:57 --> Config Class Initialized
DEBUG - 2011-05-04 11:42:57 --> Hooks Class Initialized
DEBUG - 2011-05-04 11:42:57 --> Utf8 Class Initialized
DEBUG - 2011-05-04 11:42:57 --> UTF-8 Support Enabled
DEBUG - 2011-05-04 11:42:57 --> URI Class Initialized
DEBUG - 2011-05-04 11:42:57 --> Router Class Initialized
DEBUG - 2011-05-04 11:42:57 --> Output Class Initialized
DEBUG - 2011-05-04 11:42:57 --> Input Class Initialized
DEBUG - 2011-05-04 11:42:57 --> Global POST and COOKIE data sanitized
DEBUG - 2011-05-04 11:42:57 --> Language Class Initialized
DEBUG - 2011-05-04 11:42:57 --> Loader Class Initialized
DEBUG - 2011-05-04 11:42:57 --> Controller Class Initialized
DEBUG - 2011-05-04 11:42:57 --> Model Class Initialized
DEBUG - 2011-05-04 11:42:57 --> Model Class Initialized
DEBUG - 2011-05-04 11:42:57 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-05-04 11:42:57 --> Database Driver Class Initialized
DEBUG - 2011-05-04 11:42:58 --> Final output sent to browser
DEBUG - 2011-05-04 11:42:58 --> Total execution time: 0.7384
DEBUG - 2011-05-04 11:43:08 --> Config Class Initialized
DEBUG - 2011-05-04 11:43:08 --> Hooks Class Initialized
DEBUG - 2011-05-04 11:43:08 --> Utf8 Class Initialized
DEBUG - 2011-05-04 11:43:08 --> UTF-8 Support Enabled
DEBUG - 2011-05-04 11:43:08 --> URI Class Initialized
DEBUG - 2011-05-04 11:43:08 --> Router Class Initialized
DEBUG - 2011-05-04 11:43:08 --> Output Class Initialized
DEBUG - 2011-05-04 11:43:08 --> Input Class Initialized
DEBUG - 2011-05-04 11:43:08 --> Global POST and COOKIE data sanitized
DEBUG - 2011-05-04 11:43:08 --> Language Class Initialized
DEBUG - 2011-05-04 11:43:08 --> Loader Class Initialized
DEBUG - 2011-05-04 11:43:08 --> Controller Class Initialized
ERROR - 2011-05-04 11:43:08 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-05-04 11:43:08 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-05-04 11:43:08 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-05-04 11:43:08 --> Model Class Initialized
DEBUG - 2011-05-04 11:43:08 --> Model Class Initialized
DEBUG - 2011-05-04 11:43:08 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-05-04 11:43:08 --> Database Driver Class Initialized
DEBUG - 2011-05-04 11:43:08 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-05-04 11:43:08 --> Helper loaded: url_helper
DEBUG - 2011-05-04 11:43:08 --> File loaded: application/views/common/header.php
DEBUG - 2011-05-04 11:43:08 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-05-04 11:43:08 --> File loaded: application/views/common/footer.php
DEBUG - 2011-05-04 11:43:08 --> File loaded: application/views/layout/main.php
DEBUG - 2011-05-04 11:43:08 --> Final output sent to browser
DEBUG - 2011-05-04 11:43:08 --> Total execution time: 0.1542
DEBUG - 2011-05-04 11:43:09 --> Config Class Initialized
DEBUG - 2011-05-04 11:43:09 --> Hooks Class Initialized
DEBUG - 2011-05-04 11:43:09 --> Utf8 Class Initialized
DEBUG - 2011-05-04 11:43:09 --> UTF-8 Support Enabled
DEBUG - 2011-05-04 11:43:09 --> URI Class Initialized
DEBUG - 2011-05-04 11:43:09 --> Router Class Initialized
DEBUG - 2011-05-04 11:43:09 --> Output Class Initialized
DEBUG - 2011-05-04 11:43:09 --> Input Class Initialized
DEBUG - 2011-05-04 11:43:09 --> Global POST and COOKIE data sanitized
DEBUG - 2011-05-04 11:43:09 --> Language Class Initialized
DEBUG - 2011-05-04 11:43:09 --> Loader Class Initialized
DEBUG - 2011-05-04 11:43:09 --> Controller Class Initialized
DEBUG - 2011-05-04 11:43:09 --> Model Class Initialized
DEBUG - 2011-05-04 11:43:09 --> Model Class Initialized
DEBUG - 2011-05-04 11:43:09 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-05-04 11:43:09 --> Database Driver Class Initialized
DEBUG - 2011-05-04 11:43:10 --> Final output sent to browser
DEBUG - 2011-05-04 11:43:10 --> Total execution time: 0.6489
DEBUG - 2011-05-04 11:43:15 --> Config Class Initialized
DEBUG - 2011-05-04 11:43:15 --> Hooks Class Initialized
DEBUG - 2011-05-04 11:43:15 --> Utf8 Class Initialized
DEBUG - 2011-05-04 11:43:15 --> UTF-8 Support Enabled
DEBUG - 2011-05-04 11:43:15 --> URI Class Initialized
DEBUG - 2011-05-04 11:43:15 --> Router Class Initialized
DEBUG - 2011-05-04 11:43:15 --> Output Class Initialized
DEBUG - 2011-05-04 11:43:15 --> Input Class Initialized
DEBUG - 2011-05-04 11:43:15 --> Global POST and COOKIE data sanitized
DEBUG - 2011-05-04 11:43:15 --> Language Class Initialized
DEBUG - 2011-05-04 11:43:15 --> Loader Class Initialized
DEBUG - 2011-05-04 11:43:15 --> Controller Class Initialized
ERROR - 2011-05-04 11:43:15 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-05-04 11:43:15 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-05-04 11:43:15 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-05-04 11:43:15 --> Model Class Initialized
DEBUG - 2011-05-04 11:43:15 --> Model Class Initialized
DEBUG - 2011-05-04 11:43:15 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-05-04 11:43:15 --> Database Driver Class Initialized
DEBUG - 2011-05-04 11:43:15 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-05-04 11:43:15 --> Helper loaded: url_helper
DEBUG - 2011-05-04 11:43:15 --> File loaded: application/views/common/header.php
DEBUG - 2011-05-04 11:43:15 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-05-04 11:43:15 --> File loaded: application/views/common/footer.php
DEBUG - 2011-05-04 11:43:15 --> File loaded: application/views/layout/main.php
DEBUG - 2011-05-04 11:43:15 --> Final output sent to browser
DEBUG - 2011-05-04 11:43:15 --> Total execution time: 0.0411
DEBUG - 2011-05-04 11:43:16 --> Config Class Initialized
DEBUG - 2011-05-04 11:43:16 --> Hooks Class Initialized
DEBUG - 2011-05-04 11:43:16 --> Utf8 Class Initialized
DEBUG - 2011-05-04 11:43:16 --> UTF-8 Support Enabled
DEBUG - 2011-05-04 11:43:16 --> URI Class Initialized
DEBUG - 2011-05-04 11:43:16 --> Router Class Initialized
DEBUG - 2011-05-04 11:43:16 --> Output Class Initialized
DEBUG - 2011-05-04 11:43:16 --> Input Class Initialized
DEBUG - 2011-05-04 11:43:16 --> Global POST and COOKIE data sanitized
DEBUG - 2011-05-04 11:43:16 --> Language Class Initialized
DEBUG - 2011-05-04 11:43:16 --> Loader Class Initialized
DEBUG - 2011-05-04 11:43:16 --> Controller Class Initialized
DEBUG - 2011-05-04 11:43:16 --> Model Class Initialized
DEBUG - 2011-05-04 11:43:16 --> Model Class Initialized
DEBUG - 2011-05-04 11:43:16 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-05-04 11:43:16 --> Database Driver Class Initialized
DEBUG - 2011-05-04 11:43:17 --> Final output sent to browser
DEBUG - 2011-05-04 11:43:17 --> Total execution time: 0.8388
DEBUG - 2011-05-04 11:55:32 --> Config Class Initialized
DEBUG - 2011-05-04 11:55:32 --> Hooks Class Initialized
DEBUG - 2011-05-04 11:55:32 --> Utf8 Class Initialized
DEBUG - 2011-05-04 11:55:32 --> UTF-8 Support Enabled
DEBUG - 2011-05-04 11:55:32 --> URI Class Initialized
DEBUG - 2011-05-04 11:55:32 --> Router Class Initialized
DEBUG - 2011-05-04 11:55:32 --> Output Class Initialized
DEBUG - 2011-05-04 11:55:32 --> Input Class Initialized
DEBUG - 2011-05-04 11:55:32 --> Global POST and COOKIE data sanitized
DEBUG - 2011-05-04 11:55:32 --> Language Class Initialized
DEBUG - 2011-05-04 11:55:32 --> Loader Class Initialized
DEBUG - 2011-05-04 11:55:32 --> Controller Class Initialized
DEBUG - 2011-05-04 11:55:32 --> Model Class Initialized
DEBUG - 2011-05-04 11:55:32 --> Model Class Initialized
DEBUG - 2011-05-04 11:55:32 --> Model Class Initialized
DEBUG - 2011-05-04 11:55:32 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-05-04 11:55:32 --> Database Driver Class Initialized
DEBUG - 2011-05-04 11:55:32 --> File loaded: application/views/table/main.php
DEBUG - 2011-05-04 11:55:32 --> Helper loaded: url_helper
DEBUG - 2011-05-04 11:55:32 --> File loaded: application/views/common/header.php
DEBUG - 2011-05-04 11:55:32 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-05-04 11:55:32 --> File loaded: application/views/common/footer.php
DEBUG - 2011-05-04 11:55:32 --> File loaded: application/views/layout/main.php
DEBUG - 2011-05-04 11:55:32 --> Final output sent to browser
DEBUG - 2011-05-04 11:55:32 --> Total execution time: 0.3521
DEBUG - 2011-05-04 12:18:07 --> Config Class Initialized
DEBUG - 2011-05-04 12:18:07 --> Hooks Class Initialized
DEBUG - 2011-05-04 12:18:07 --> Utf8 Class Initialized
DEBUG - 2011-05-04 12:18:07 --> UTF-8 Support Enabled
DEBUG - 2011-05-04 12:18:07 --> URI Class Initialized
DEBUG - 2011-05-04 12:18:07 --> Router Class Initialized
DEBUG - 2011-05-04 12:18:07 --> Output Class Initialized
DEBUG - 2011-05-04 12:18:07 --> Input Class Initialized
DEBUG - 2011-05-04 12:18:07 --> Global POST and COOKIE data sanitized
DEBUG - 2011-05-04 12:18:07 --> Language Class Initialized
DEBUG - 2011-05-04 12:18:07 --> Loader Class Initialized
DEBUG - 2011-05-04 12:18:07 --> Controller Class Initialized
DEBUG - 2011-05-04 12:18:07 --> Model Class Initialized
DEBUG - 2011-05-04 12:18:07 --> Model Class Initialized
DEBUG - 2011-05-04 12:18:07 --> Model Class Initialized
DEBUG - 2011-05-04 12:18:07 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-05-04 12:18:07 --> Database Driver Class Initialized
DEBUG - 2011-05-04 12:18:08 --> File loaded: application/views/table/main.php
DEBUG - 2011-05-04 12:18:08 --> Helper loaded: url_helper
DEBUG - 2011-05-04 12:18:08 --> File loaded: application/views/common/header.php
DEBUG - 2011-05-04 12:18:08 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-05-04 12:18:08 --> File loaded: application/views/common/footer.php
DEBUG - 2011-05-04 12:18:08 --> File loaded: application/views/layout/main.php
DEBUG - 2011-05-04 12:18:08 --> Final output sent to browser
DEBUG - 2011-05-04 12:18:08 --> Total execution time: 0.8348
DEBUG - 2011-05-04 12:55:08 --> Config Class Initialized
DEBUG - 2011-05-04 12:55:08 --> Hooks Class Initialized
DEBUG - 2011-05-04 12:55:08 --> Utf8 Class Initialized
DEBUG - 2011-05-04 12:55:08 --> UTF-8 Support Enabled
DEBUG - 2011-05-04 12:55:08 --> URI Class Initialized
DEBUG - 2011-05-04 12:55:08 --> Router Class Initialized
DEBUG - 2011-05-04 12:55:08 --> Output Class Initialized
DEBUG - 2011-05-04 12:55:08 --> Input Class Initialized
DEBUG - 2011-05-04 12:55:08 --> Global POST and COOKIE data sanitized
DEBUG - 2011-05-04 12:55:08 --> Language Class Initialized
DEBUG - 2011-05-04 12:55:08 --> Loader Class Initialized
DEBUG - 2011-05-04 12:55:08 --> Controller Class Initialized
DEBUG - 2011-05-04 12:55:08 --> Model Class Initialized
DEBUG - 2011-05-04 12:55:08 --> Model Class Initialized
DEBUG - 2011-05-04 12:55:08 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-05-04 12:55:09 --> Database Driver Class Initialized
DEBUG - 2011-05-04 12:55:09 --> Final output sent to browser
DEBUG - 2011-05-04 12:55:09 --> Total execution time: 1.8259
DEBUG - 2011-05-04 13:31:23 --> Config Class Initialized
DEBUG - 2011-05-04 13:31:23 --> Hooks Class Initialized
DEBUG - 2011-05-04 13:31:23 --> Utf8 Class Initialized
DEBUG - 2011-05-04 13:31:23 --> UTF-8 Support Enabled
DEBUG - 2011-05-04 13:31:23 --> URI Class Initialized
DEBUG - 2011-05-04 13:31:23 --> Router Class Initialized
DEBUG - 2011-05-04 13:31:24 --> Output Class Initialized
DEBUG - 2011-05-04 13:31:24 --> Input Class Initialized
DEBUG - 2011-05-04 13:31:24 --> Global POST and COOKIE data sanitized
DEBUG - 2011-05-04 13:31:24 --> Language Class Initialized
DEBUG - 2011-05-04 13:31:24 --> Loader Class Initialized
DEBUG - 2011-05-04 13:31:24 --> Controller Class Initialized
DEBUG - 2011-05-04 13:31:24 --> Model Class Initialized
DEBUG - 2011-05-04 13:31:24 --> Model Class Initialized
DEBUG - 2011-05-04 13:31:24 --> Model Class Initialized
DEBUG - 2011-05-04 13:31:24 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-05-04 13:31:24 --> Database Driver Class Initialized
DEBUG - 2011-05-04 13:31:24 --> File loaded: application/views/table/main.php
DEBUG - 2011-05-04 13:31:24 --> Helper loaded: url_helper
DEBUG - 2011-05-04 13:31:24 --> File loaded: application/views/common/header.php
DEBUG - 2011-05-04 13:31:24 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-05-04 13:31:24 --> File loaded: application/views/common/footer.php
DEBUG - 2011-05-04 13:31:24 --> File loaded: application/views/layout/main.php
DEBUG - 2011-05-04 13:31:24 --> Final output sent to browser
DEBUG - 2011-05-04 13:31:24 --> Total execution time: 1.0100
DEBUG - 2011-05-04 13:31:25 --> Config Class Initialized
DEBUG - 2011-05-04 13:31:25 --> Hooks Class Initialized
DEBUG - 2011-05-04 13:31:25 --> Utf8 Class Initialized
DEBUG - 2011-05-04 13:31:25 --> UTF-8 Support Enabled
DEBUG - 2011-05-04 13:31:25 --> URI Class Initialized
DEBUG - 2011-05-04 13:31:25 --> Router Class Initialized
DEBUG - 2011-05-04 13:31:25 --> Output Class Initialized
DEBUG - 2011-05-04 13:31:25 --> Input Class Initialized
DEBUG - 2011-05-04 13:31:25 --> Global POST and COOKIE data sanitized
DEBUG - 2011-05-04 13:31:25 --> Language Class Initialized
DEBUG - 2011-05-04 13:31:25 --> Loader Class Initialized
DEBUG - 2011-05-04 13:31:25 --> Controller Class Initialized
ERROR - 2011-05-04 13:31:25 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-05-04 13:31:25 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-05-04 13:31:25 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-05-04 13:31:25 --> Model Class Initialized
DEBUG - 2011-05-04 13:31:25 --> Model Class Initialized
DEBUG - 2011-05-04 13:31:25 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-05-04 13:31:25 --> Database Driver Class Initialized
DEBUG - 2011-05-04 13:31:25 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-05-04 13:31:25 --> Helper loaded: url_helper
DEBUG - 2011-05-04 13:31:25 --> File loaded: application/views/common/header.php
DEBUG - 2011-05-04 13:31:25 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-05-04 13:31:25 --> File loaded: application/views/common/footer.php
DEBUG - 2011-05-04 13:31:25 --> File loaded: application/views/layout/main.php
DEBUG - 2011-05-04 13:31:25 --> Final output sent to browser
DEBUG - 2011-05-04 13:31:25 --> Total execution time: 0.1411
DEBUG - 2011-05-04 13:56:10 --> Config Class Initialized
DEBUG - 2011-05-04 13:56:10 --> Hooks Class Initialized
DEBUG - 2011-05-04 13:56:10 --> Utf8 Class Initialized
DEBUG - 2011-05-04 13:56:10 --> UTF-8 Support Enabled
DEBUG - 2011-05-04 13:56:10 --> URI Class Initialized
DEBUG - 2011-05-04 13:56:10 --> Router Class Initialized
DEBUG - 2011-05-04 13:56:10 --> Output Class Initialized
DEBUG - 2011-05-04 13:56:10 --> Input Class Initialized
DEBUG - 2011-05-04 13:56:10 --> Global POST and COOKIE data sanitized
DEBUG - 2011-05-04 13:56:10 --> Language Class Initialized
DEBUG - 2011-05-04 13:56:10 --> Loader Class Initialized
DEBUG - 2011-05-04 13:56:10 --> Controller Class Initialized
DEBUG - 2011-05-04 13:56:10 --> Model Class Initialized
DEBUG - 2011-05-04 13:56:10 --> Model Class Initialized
DEBUG - 2011-05-04 13:56:10 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-05-04 13:56:10 --> Database Driver Class Initialized
DEBUG - 2011-05-04 13:56:11 --> Final output sent to browser
DEBUG - 2011-05-04 13:56:11 --> Total execution time: 0.8206
DEBUG - 2011-05-04 14:56:06 --> Config Class Initialized
DEBUG - 2011-05-04 14:56:06 --> Hooks Class Initialized
DEBUG - 2011-05-04 14:56:06 --> Utf8 Class Initialized
DEBUG - 2011-05-04 14:56:06 --> UTF-8 Support Enabled
DEBUG - 2011-05-04 14:56:06 --> URI Class Initialized
DEBUG - 2011-05-04 14:56:06 --> Router Class Initialized
DEBUG - 2011-05-04 14:56:06 --> No URI present. Default controller set.
DEBUG - 2011-05-04 14:56:06 --> Output Class Initialized
DEBUG - 2011-05-04 14:56:06 --> Input Class Initialized
DEBUG - 2011-05-04 14:56:06 --> Global POST and COOKIE data sanitized
DEBUG - 2011-05-04 14:56:06 --> Language Class Initialized
DEBUG - 2011-05-04 14:56:06 --> Loader Class Initialized
DEBUG - 2011-05-04 14:56:06 --> Controller Class Initialized
DEBUG - 2011-05-04 14:56:06 --> File loaded: application/views/splash/main.php
DEBUG - 2011-05-04 14:56:06 --> Helper loaded: url_helper
DEBUG - 2011-05-04 14:56:06 --> File loaded: application/views/common/header.php
DEBUG - 2011-05-04 14:56:06 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-05-04 14:56:06 --> File loaded: application/views/common/footer.php
DEBUG - 2011-05-04 14:56:06 --> File loaded: application/views/layout/main.php
DEBUG - 2011-05-04 14:56:06 --> Final output sent to browser
DEBUG - 2011-05-04 14:56:06 --> Total execution time: 0.2514
DEBUG - 2011-05-04 15:04:36 --> Config Class Initialized
DEBUG - 2011-05-04 15:04:36 --> Hooks Class Initialized
DEBUG - 2011-05-04 15:04:36 --> Utf8 Class Initialized
DEBUG - 2011-05-04 15:04:36 --> UTF-8 Support Enabled
DEBUG - 2011-05-04 15:04:36 --> URI Class Initialized
DEBUG - 2011-05-04 15:04:36 --> Router Class Initialized
DEBUG - 2011-05-04 15:04:36 --> Output Class Initialized
DEBUG - 2011-05-04 15:04:36 --> Input Class Initialized
DEBUG - 2011-05-04 15:04:36 --> Global POST and COOKIE data sanitized
DEBUG - 2011-05-04 15:04:36 --> Language Class Initialized
DEBUG - 2011-05-04 15:04:36 --> Loader Class Initialized
DEBUG - 2011-05-04 15:04:36 --> Controller Class Initialized
ERROR - 2011-05-04 15:04:36 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-05-04 15:04:36 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-05-04 15:04:36 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-05-04 15:04:36 --> Model Class Initialized
DEBUG - 2011-05-04 15:04:36 --> Model Class Initialized
DEBUG - 2011-05-04 15:04:36 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-05-04 15:04:36 --> Database Driver Class Initialized
DEBUG - 2011-05-04 15:04:36 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-05-04 15:04:36 --> Helper loaded: url_helper
DEBUG - 2011-05-04 15:04:36 --> File loaded: application/views/common/header.php
DEBUG - 2011-05-04 15:04:36 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-05-04 15:04:36 --> File loaded: application/views/common/footer.php
DEBUG - 2011-05-04 15:04:36 --> File loaded: application/views/layout/main.php
DEBUG - 2011-05-04 15:04:36 --> Final output sent to browser
DEBUG - 2011-05-04 15:04:36 --> Total execution time: 0.2858
DEBUG - 2011-05-04 15:04:37 --> Config Class Initialized
DEBUG - 2011-05-04 15:04:37 --> Hooks Class Initialized
DEBUG - 2011-05-04 15:04:37 --> Utf8 Class Initialized
DEBUG - 2011-05-04 15:04:37 --> UTF-8 Support Enabled
DEBUG - 2011-05-04 15:04:37 --> URI Class Initialized
DEBUG - 2011-05-04 15:04:37 --> Router Class Initialized
DEBUG - 2011-05-04 15:04:37 --> Output Class Initialized
DEBUG - 2011-05-04 15:04:37 --> Input Class Initialized
DEBUG - 2011-05-04 15:04:37 --> Global POST and COOKIE data sanitized
DEBUG - 2011-05-04 15:04:37 --> Language Class Initialized
DEBUG - 2011-05-04 15:04:37 --> Loader Class Initialized
DEBUG - 2011-05-04 15:04:37 --> Controller Class Initialized
DEBUG - 2011-05-04 15:04:37 --> Model Class Initialized
DEBUG - 2011-05-04 15:04:37 --> Model Class Initialized
DEBUG - 2011-05-04 15:04:37 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-05-04 15:04:37 --> Database Driver Class Initialized
DEBUG - 2011-05-04 15:04:38 --> Final output sent to browser
DEBUG - 2011-05-04 15:04:38 --> Total execution time: 0.5409
DEBUG - 2011-05-04 15:04:42 --> Config Class Initialized
DEBUG - 2011-05-04 15:04:42 --> Hooks Class Initialized
DEBUG - 2011-05-04 15:04:42 --> Utf8 Class Initialized
DEBUG - 2011-05-04 15:04:42 --> UTF-8 Support Enabled
DEBUG - 2011-05-04 15:04:42 --> URI Class Initialized
DEBUG - 2011-05-04 15:04:42 --> Router Class Initialized
ERROR - 2011-05-04 15:04:42 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-05-04 15:04:45 --> Config Class Initialized
DEBUG - 2011-05-04 15:04:45 --> Hooks Class Initialized
DEBUG - 2011-05-04 15:04:45 --> Utf8 Class Initialized
DEBUG - 2011-05-04 15:04:45 --> UTF-8 Support Enabled
DEBUG - 2011-05-04 15:04:45 --> URI Class Initialized
DEBUG - 2011-05-04 15:04:45 --> Router Class Initialized
ERROR - 2011-05-04 15:04:45 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-05-04 15:04:48 --> Config Class Initialized
DEBUG - 2011-05-04 15:04:48 --> Hooks Class Initialized
DEBUG - 2011-05-04 15:04:48 --> Utf8 Class Initialized
DEBUG - 2011-05-04 15:04:48 --> UTF-8 Support Enabled
DEBUG - 2011-05-04 15:04:48 --> URI Class Initialized
DEBUG - 2011-05-04 15:04:48 --> Router Class Initialized
DEBUG - 2011-05-04 15:04:48 --> Output Class Initialized
DEBUG - 2011-05-04 15:04:48 --> Input Class Initialized
DEBUG - 2011-05-04 15:04:48 --> Global POST and COOKIE data sanitized
DEBUG - 2011-05-04 15:04:48 --> Language Class Initialized
DEBUG - 2011-05-04 15:04:48 --> Loader Class Initialized
DEBUG - 2011-05-04 15:04:48 --> Controller Class Initialized
ERROR - 2011-05-04 15:04:48 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-05-04 15:04:48 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-05-04 15:04:48 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-05-04 15:04:48 --> Model Class Initialized
DEBUG - 2011-05-04 15:04:48 --> Model Class Initialized
DEBUG - 2011-05-04 15:04:48 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-05-04 15:04:48 --> Database Driver Class Initialized
DEBUG - 2011-05-04 15:04:48 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-05-04 15:04:48 --> Helper loaded: url_helper
DEBUG - 2011-05-04 15:04:48 --> File loaded: application/views/common/header.php
DEBUG - 2011-05-04 15:04:48 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-05-04 15:04:48 --> File loaded: application/views/common/footer.php
DEBUG - 2011-05-04 15:04:48 --> File loaded: application/views/layout/main.php
DEBUG - 2011-05-04 15:04:48 --> Final output sent to browser
DEBUG - 2011-05-04 15:04:48 --> Total execution time: 0.0334
DEBUG - 2011-05-04 15:04:50 --> Config Class Initialized
DEBUG - 2011-05-04 15:04:50 --> Hooks Class Initialized
DEBUG - 2011-05-04 15:04:50 --> Utf8 Class Initialized
DEBUG - 2011-05-04 15:04:50 --> UTF-8 Support Enabled
DEBUG - 2011-05-04 15:04:50 --> URI Class Initialized
DEBUG - 2011-05-04 15:04:50 --> Router Class Initialized
DEBUG - 2011-05-04 15:04:50 --> Output Class Initialized
DEBUG - 2011-05-04 15:04:50 --> Input Class Initialized
DEBUG - 2011-05-04 15:04:50 --> Global POST and COOKIE data sanitized
DEBUG - 2011-05-04 15:04:50 --> Language Class Initialized
DEBUG - 2011-05-04 15:04:50 --> Loader Class Initialized
DEBUG - 2011-05-04 15:04:50 --> Controller Class Initialized
DEBUG - 2011-05-04 15:04:50 --> Model Class Initialized
DEBUG - 2011-05-04 15:04:50 --> Model Class Initialized
DEBUG - 2011-05-04 15:04:50 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-05-04 15:04:50 --> Database Driver Class Initialized
DEBUG - 2011-05-04 15:04:50 --> Final output sent to browser
DEBUG - 2011-05-04 15:04:50 --> Total execution time: 0.6148
DEBUG - 2011-05-04 15:04:51 --> Config Class Initialized
DEBUG - 2011-05-04 15:04:51 --> Hooks Class Initialized
DEBUG - 2011-05-04 15:04:51 --> Utf8 Class Initialized
DEBUG - 2011-05-04 15:04:51 --> UTF-8 Support Enabled
DEBUG - 2011-05-04 15:04:51 --> URI Class Initialized
DEBUG - 2011-05-04 15:04:51 --> Router Class Initialized
DEBUG - 2011-05-04 15:04:51 --> Output Class Initialized
DEBUG - 2011-05-04 15:04:51 --> Input Class Initialized
DEBUG - 2011-05-04 15:04:51 --> Global POST and COOKIE data sanitized
DEBUG - 2011-05-04 15:04:51 --> Language Class Initialized
DEBUG - 2011-05-04 15:04:51 --> Loader Class Initialized
DEBUG - 2011-05-04 15:04:51 --> Controller Class Initialized
ERROR - 2011-05-04 15:04:51 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-05-04 15:04:51 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-05-04 15:04:51 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-05-04 15:04:51 --> Model Class Initialized
DEBUG - 2011-05-04 15:04:51 --> Model Class Initialized
DEBUG - 2011-05-04 15:04:51 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-05-04 15:04:51 --> Database Driver Class Initialized
DEBUG - 2011-05-04 15:04:51 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-05-04 15:04:51 --> Helper loaded: url_helper
DEBUG - 2011-05-04 15:04:51 --> File loaded: application/views/common/header.php
DEBUG - 2011-05-04 15:04:51 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-05-04 15:04:51 --> File loaded: application/views/common/footer.php
DEBUG - 2011-05-04 15:04:51 --> File loaded: application/views/layout/main.php
DEBUG - 2011-05-04 15:04:51 --> Final output sent to browser
DEBUG - 2011-05-04 15:04:51 --> Total execution time: 0.0567
DEBUG - 2011-05-04 15:05:13 --> Config Class Initialized
DEBUG - 2011-05-04 15:05:13 --> Hooks Class Initialized
DEBUG - 2011-05-04 15:05:13 --> Utf8 Class Initialized
DEBUG - 2011-05-04 15:05:13 --> UTF-8 Support Enabled
DEBUG - 2011-05-04 15:05:13 --> URI Class Initialized
DEBUG - 2011-05-04 15:05:13 --> Router Class Initialized
DEBUG - 2011-05-04 15:05:13 --> Output Class Initialized
DEBUG - 2011-05-04 15:05:13 --> Input Class Initialized
DEBUG - 2011-05-04 15:05:13 --> Global POST and COOKIE data sanitized
DEBUG - 2011-05-04 15:05:13 --> Language Class Initialized
DEBUG - 2011-05-04 15:05:13 --> Loader Class Initialized
DEBUG - 2011-05-04 15:05:13 --> Controller Class Initialized
ERROR - 2011-05-04 15:05:13 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-05-04 15:05:13 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-05-04 15:05:13 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-05-04 15:05:13 --> Model Class Initialized
DEBUG - 2011-05-04 15:05:13 --> Model Class Initialized
DEBUG - 2011-05-04 15:05:13 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-05-04 15:05:13 --> Database Driver Class Initialized
DEBUG - 2011-05-04 15:05:13 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-05-04 15:05:14 --> Helper loaded: url_helper
DEBUG - 2011-05-04 15:05:14 --> File loaded: application/views/common/header.php
DEBUG - 2011-05-04 15:05:14 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-05-04 15:05:14 --> File loaded: application/views/common/footer.php
DEBUG - 2011-05-04 15:05:14 --> File loaded: application/views/layout/main.php
DEBUG - 2011-05-04 15:05:14 --> Final output sent to browser
DEBUG - 2011-05-04 15:05:14 --> Total execution time: 0.0385
DEBUG - 2011-05-04 15:05:15 --> Config Class Initialized
DEBUG - 2011-05-04 15:05:15 --> Hooks Class Initialized
DEBUG - 2011-05-04 15:05:15 --> Utf8 Class Initialized
DEBUG - 2011-05-04 15:05:15 --> UTF-8 Support Enabled
DEBUG - 2011-05-04 15:05:15 --> URI Class Initialized
DEBUG - 2011-05-04 15:05:15 --> Router Class Initialized
DEBUG - 2011-05-04 15:05:15 --> Output Class Initialized
DEBUG - 2011-05-04 15:05:15 --> Input Class Initialized
DEBUG - 2011-05-04 15:05:15 --> Global POST and COOKIE data sanitized
DEBUG - 2011-05-04 15:05:15 --> Language Class Initialized
DEBUG - 2011-05-04 15:05:15 --> Loader Class Initialized
DEBUG - 2011-05-04 15:05:15 --> Controller Class Initialized
DEBUG - 2011-05-04 15:05:15 --> Model Class Initialized
DEBUG - 2011-05-04 15:05:15 --> Model Class Initialized
DEBUG - 2011-05-04 15:05:15 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-05-04 15:05:15 --> Database Driver Class Initialized
DEBUG - 2011-05-04 15:05:16 --> Final output sent to browser
DEBUG - 2011-05-04 15:05:16 --> Total execution time: 1.8960
DEBUG - 2011-05-04 15:05:17 --> Config Class Initialized
DEBUG - 2011-05-04 15:05:17 --> Hooks Class Initialized
DEBUG - 2011-05-04 15:05:17 --> Utf8 Class Initialized
DEBUG - 2011-05-04 15:05:17 --> UTF-8 Support Enabled
DEBUG - 2011-05-04 15:05:17 --> URI Class Initialized
DEBUG - 2011-05-04 15:05:17 --> Router Class Initialized
DEBUG - 2011-05-04 15:05:17 --> Output Class Initialized
DEBUG - 2011-05-04 15:05:17 --> Input Class Initialized
DEBUG - 2011-05-04 15:05:17 --> Global POST and COOKIE data sanitized
DEBUG - 2011-05-04 15:05:17 --> Language Class Initialized
DEBUG - 2011-05-04 15:05:17 --> Loader Class Initialized
DEBUG - 2011-05-04 15:05:17 --> Controller Class Initialized
ERROR - 2011-05-04 15:05:17 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-05-04 15:05:17 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-05-04 15:05:17 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-05-04 15:05:17 --> Model Class Initialized
DEBUG - 2011-05-04 15:05:17 --> Model Class Initialized
DEBUG - 2011-05-04 15:05:17 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-05-04 15:05:17 --> Database Driver Class Initialized
DEBUG - 2011-05-04 15:05:17 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-05-04 15:05:17 --> Helper loaded: url_helper
DEBUG - 2011-05-04 15:05:17 --> File loaded: application/views/common/header.php
DEBUG - 2011-05-04 15:05:17 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-05-04 15:05:17 --> File loaded: application/views/common/footer.php
DEBUG - 2011-05-04 15:05:17 --> File loaded: application/views/layout/main.php
DEBUG - 2011-05-04 15:05:17 --> Final output sent to browser
DEBUG - 2011-05-04 15:05:17 --> Total execution time: 0.0596
DEBUG - 2011-05-04 15:05:25 --> Config Class Initialized
DEBUG - 2011-05-04 15:05:25 --> Hooks Class Initialized
DEBUG - 2011-05-04 15:05:25 --> Utf8 Class Initialized
DEBUG - 2011-05-04 15:05:25 --> UTF-8 Support Enabled
DEBUG - 2011-05-04 15:05:25 --> URI Class Initialized
DEBUG - 2011-05-04 15:05:25 --> Router Class Initialized
DEBUG - 2011-05-04 15:05:25 --> Output Class Initialized
DEBUG - 2011-05-04 15:05:25 --> Input Class Initialized
DEBUG - 2011-05-04 15:05:25 --> Global POST and COOKIE data sanitized
DEBUG - 2011-05-04 15:05:25 --> Language Class Initialized
DEBUG - 2011-05-04 15:05:25 --> Loader Class Initialized
DEBUG - 2011-05-04 15:05:25 --> Controller Class Initialized
ERROR - 2011-05-04 15:05:25 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-05-04 15:05:25 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-05-04 15:05:25 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-05-04 15:05:25 --> Model Class Initialized
DEBUG - 2011-05-04 15:05:25 --> Model Class Initialized
DEBUG - 2011-05-04 15:05:25 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-05-04 15:05:25 --> Database Driver Class Initialized
DEBUG - 2011-05-04 15:05:25 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-05-04 15:05:25 --> Helper loaded: url_helper
DEBUG - 2011-05-04 15:05:25 --> File loaded: application/views/common/header.php
DEBUG - 2011-05-04 15:05:25 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-05-04 15:05:25 --> File loaded: application/views/common/footer.php
DEBUG - 2011-05-04 15:05:25 --> File loaded: application/views/layout/main.php
DEBUG - 2011-05-04 15:05:25 --> Final output sent to browser
DEBUG - 2011-05-04 15:05:25 --> Total execution time: 0.0351
DEBUG - 2011-05-04 15:05:25 --> Config Class Initialized
DEBUG - 2011-05-04 15:05:25 --> Hooks Class Initialized
DEBUG - 2011-05-04 15:05:25 --> Utf8 Class Initialized
DEBUG - 2011-05-04 15:05:25 --> UTF-8 Support Enabled
DEBUG - 2011-05-04 15:05:25 --> URI Class Initialized
DEBUG - 2011-05-04 15:05:25 --> Router Class Initialized
DEBUG - 2011-05-04 15:05:25 --> Output Class Initialized
DEBUG - 2011-05-04 15:05:25 --> Input Class Initialized
DEBUG - 2011-05-04 15:05:25 --> Global POST and COOKIE data sanitized
DEBUG - 2011-05-04 15:05:25 --> Language Class Initialized
DEBUG - 2011-05-04 15:05:25 --> Loader Class Initialized
DEBUG - 2011-05-04 15:05:25 --> Controller Class Initialized
DEBUG - 2011-05-04 15:05:25 --> Model Class Initialized
DEBUG - 2011-05-04 15:05:25 --> Model Class Initialized
DEBUG - 2011-05-04 15:05:25 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-05-04 15:05:25 --> Database Driver Class Initialized
DEBUG - 2011-05-04 15:05:26 --> Final output sent to browser
DEBUG - 2011-05-04 15:05:26 --> Total execution time: 0.5100
DEBUG - 2011-05-04 15:05:27 --> Config Class Initialized
DEBUG - 2011-05-04 15:05:27 --> Hooks Class Initialized
DEBUG - 2011-05-04 15:05:27 --> Utf8 Class Initialized
DEBUG - 2011-05-04 15:05:27 --> UTF-8 Support Enabled
DEBUG - 2011-05-04 15:05:27 --> URI Class Initialized
DEBUG - 2011-05-04 15:05:27 --> Router Class Initialized
DEBUG - 2011-05-04 15:05:27 --> Output Class Initialized
DEBUG - 2011-05-04 15:05:27 --> Input Class Initialized
DEBUG - 2011-05-04 15:05:27 --> Global POST and COOKIE data sanitized
DEBUG - 2011-05-04 15:05:27 --> Language Class Initialized
DEBUG - 2011-05-04 15:05:27 --> Loader Class Initialized
DEBUG - 2011-05-04 15:05:27 --> Controller Class Initialized
ERROR - 2011-05-04 15:05:27 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-05-04 15:05:27 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-05-04 15:05:27 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-05-04 15:05:27 --> Model Class Initialized
DEBUG - 2011-05-04 15:05:27 --> Model Class Initialized
DEBUG - 2011-05-04 15:05:27 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-05-04 15:05:27 --> Database Driver Class Initialized
DEBUG - 2011-05-04 15:05:27 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-05-04 15:05:27 --> Helper loaded: url_helper
DEBUG - 2011-05-04 15:05:27 --> File loaded: application/views/common/header.php
DEBUG - 2011-05-04 15:05:27 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-05-04 15:05:27 --> File loaded: application/views/common/footer.php
DEBUG - 2011-05-04 15:05:27 --> File loaded: application/views/layout/main.php
DEBUG - 2011-05-04 15:05:27 --> Final output sent to browser
DEBUG - 2011-05-04 15:05:27 --> Total execution time: 0.0285
DEBUG - 2011-05-04 15:12:44 --> Config Class Initialized
DEBUG - 2011-05-04 15:12:44 --> Hooks Class Initialized
DEBUG - 2011-05-04 15:12:44 --> Utf8 Class Initialized
DEBUG - 2011-05-04 15:12:44 --> UTF-8 Support Enabled
DEBUG - 2011-05-04 15:12:44 --> URI Class Initialized
DEBUG - 2011-05-04 15:12:44 --> Router Class Initialized
DEBUG - 2011-05-04 15:12:44 --> Output Class Initialized
DEBUG - 2011-05-04 15:12:44 --> Input Class Initialized
DEBUG - 2011-05-04 15:12:44 --> Global POST and COOKIE data sanitized
DEBUG - 2011-05-04 15:12:44 --> Language Class Initialized
DEBUG - 2011-05-04 15:12:44 --> Loader Class Initialized
DEBUG - 2011-05-04 15:12:44 --> Controller Class Initialized
DEBUG - 2011-05-04 15:12:44 --> Model Class Initialized
DEBUG - 2011-05-04 15:12:44 --> Model Class Initialized
DEBUG - 2011-05-04 15:12:44 --> Model Class Initialized
DEBUG - 2011-05-04 15:12:44 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-05-04 15:12:44 --> Database Driver Class Initialized
DEBUG - 2011-05-04 15:12:44 --> File loaded: application/views/table/main.php
DEBUG - 2011-05-04 15:12:44 --> Helper loaded: url_helper
DEBUG - 2011-05-04 15:12:44 --> File loaded: application/views/common/header.php
DEBUG - 2011-05-04 15:12:44 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-05-04 15:12:44 --> File loaded: application/views/common/footer.php
DEBUG - 2011-05-04 15:12:44 --> File loaded: application/views/layout/main.php
DEBUG - 2011-05-04 15:12:44 --> Final output sent to browser
DEBUG - 2011-05-04 15:12:44 --> Total execution time: 0.3028
DEBUG - 2011-05-04 15:12:46 --> Config Class Initialized
DEBUG - 2011-05-04 15:12:46 --> Hooks Class Initialized
DEBUG - 2011-05-04 15:12:46 --> Utf8 Class Initialized
DEBUG - 2011-05-04 15:12:46 --> UTF-8 Support Enabled
DEBUG - 2011-05-04 15:12:46 --> URI Class Initialized
DEBUG - 2011-05-04 15:12:46 --> Router Class Initialized
ERROR - 2011-05-04 15:12:46 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-05-04 15:12:47 --> Config Class Initialized
DEBUG - 2011-05-04 15:12:47 --> Hooks Class Initialized
DEBUG - 2011-05-04 15:12:47 --> Utf8 Class Initialized
DEBUG - 2011-05-04 15:12:47 --> UTF-8 Support Enabled
DEBUG - 2011-05-04 15:12:47 --> URI Class Initialized
DEBUG - 2011-05-04 15:12:47 --> Router Class Initialized
ERROR - 2011-05-04 15:12:47 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-05-04 15:14:10 --> Config Class Initialized
DEBUG - 2011-05-04 15:14:10 --> Hooks Class Initialized
DEBUG - 2011-05-04 15:14:10 --> Utf8 Class Initialized
DEBUG - 2011-05-04 15:14:10 --> UTF-8 Support Enabled
DEBUG - 2011-05-04 15:14:10 --> URI Class Initialized
DEBUG - 2011-05-04 15:14:10 --> Router Class Initialized
DEBUG - 2011-05-04 15:14:10 --> Output Class Initialized
DEBUG - 2011-05-04 15:14:10 --> Input Class Initialized
DEBUG - 2011-05-04 15:14:10 --> Global POST and COOKIE data sanitized
DEBUG - 2011-05-04 15:14:10 --> Language Class Initialized
DEBUG - 2011-05-04 15:14:10 --> Loader Class Initialized
DEBUG - 2011-05-04 15:14:10 --> Controller Class Initialized
ERROR - 2011-05-04 15:14:10 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-05-04 15:14:10 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-05-04 15:14:10 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-05-04 15:14:10 --> Model Class Initialized
DEBUG - 2011-05-04 15:14:10 --> Model Class Initialized
DEBUG - 2011-05-04 15:14:10 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-05-04 15:14:10 --> Database Driver Class Initialized
DEBUG - 2011-05-04 15:14:10 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-05-04 15:14:10 --> Helper loaded: url_helper
DEBUG - 2011-05-04 15:14:10 --> File loaded: application/views/common/header.php
DEBUG - 2011-05-04 15:14:10 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-05-04 15:14:10 --> File loaded: application/views/common/footer.php
DEBUG - 2011-05-04 15:14:10 --> File loaded: application/views/layout/main.php
DEBUG - 2011-05-04 15:14:10 --> Final output sent to browser
DEBUG - 2011-05-04 15:14:10 --> Total execution time: 0.0824
DEBUG - 2011-05-04 15:14:12 --> Config Class Initialized
DEBUG - 2011-05-04 15:14:12 --> Hooks Class Initialized
DEBUG - 2011-05-04 15:14:12 --> Utf8 Class Initialized
DEBUG - 2011-05-04 15:14:12 --> UTF-8 Support Enabled
DEBUG - 2011-05-04 15:14:12 --> URI Class Initialized
DEBUG - 2011-05-04 15:14:12 --> Router Class Initialized
DEBUG - 2011-05-04 15:14:12 --> Output Class Initialized
DEBUG - 2011-05-04 15:14:12 --> Input Class Initialized
DEBUG - 2011-05-04 15:14:12 --> Global POST and COOKIE data sanitized
DEBUG - 2011-05-04 15:14:12 --> Language Class Initialized
DEBUG - 2011-05-04 15:14:12 --> Loader Class Initialized
DEBUG - 2011-05-04 15:14:12 --> Controller Class Initialized
DEBUG - 2011-05-04 15:14:12 --> Model Class Initialized
DEBUG - 2011-05-04 15:14:12 --> Model Class Initialized
DEBUG - 2011-05-04 15:14:12 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-05-04 15:14:12 --> Database Driver Class Initialized
DEBUG - 2011-05-04 15:14:12 --> Final output sent to browser
DEBUG - 2011-05-04 15:14:12 --> Total execution time: 0.6041
DEBUG - 2011-05-04 16:52:17 --> Config Class Initialized
DEBUG - 2011-05-04 16:52:17 --> Hooks Class Initialized
DEBUG - 2011-05-04 16:52:17 --> Utf8 Class Initialized
DEBUG - 2011-05-04 16:52:17 --> UTF-8 Support Enabled
DEBUG - 2011-05-04 16:52:17 --> URI Class Initialized
DEBUG - 2011-05-04 16:52:17 --> Router Class Initialized
DEBUG - 2011-05-04 16:52:17 --> Output Class Initialized
DEBUG - 2011-05-04 16:52:17 --> Input Class Initialized
DEBUG - 2011-05-04 16:52:17 --> Global POST and COOKIE data sanitized
DEBUG - 2011-05-04 16:52:17 --> Language Class Initialized
DEBUG - 2011-05-04 16:52:17 --> Loader Class Initialized
DEBUG - 2011-05-04 16:52:17 --> Controller Class Initialized
ERROR - 2011-05-04 16:52:17 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-05-04 16:52:17 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-05-04 16:52:17 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-05-04 16:52:17 --> Model Class Initialized
DEBUG - 2011-05-04 16:52:17 --> Model Class Initialized
DEBUG - 2011-05-04 16:52:17 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-05-04 16:52:18 --> Database Driver Class Initialized
DEBUG - 2011-05-04 16:52:18 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-05-04 16:52:18 --> Helper loaded: url_helper
DEBUG - 2011-05-04 16:52:18 --> File loaded: application/views/common/header.php
DEBUG - 2011-05-04 16:52:18 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-05-04 16:52:18 --> File loaded: application/views/common/footer.php
DEBUG - 2011-05-04 16:52:18 --> File loaded: application/views/layout/main.php
DEBUG - 2011-05-04 16:52:18 --> Final output sent to browser
DEBUG - 2011-05-04 16:52:18 --> Total execution time: 0.4132
DEBUG - 2011-05-04 16:52:19 --> Config Class Initialized
DEBUG - 2011-05-04 16:52:19 --> Hooks Class Initialized
DEBUG - 2011-05-04 16:52:19 --> Utf8 Class Initialized
DEBUG - 2011-05-04 16:52:19 --> UTF-8 Support Enabled
DEBUG - 2011-05-04 16:52:19 --> URI Class Initialized
DEBUG - 2011-05-04 16:52:19 --> Router Class Initialized
DEBUG - 2011-05-04 16:52:19 --> Output Class Initialized
DEBUG - 2011-05-04 16:52:19 --> Input Class Initialized
DEBUG - 2011-05-04 16:52:19 --> Global POST and COOKIE data sanitized
DEBUG - 2011-05-04 16:52:19 --> Language Class Initialized
DEBUG - 2011-05-04 16:52:19 --> Loader Class Initialized
DEBUG - 2011-05-04 16:52:19 --> Controller Class Initialized
DEBUG - 2011-05-04 16:52:19 --> Model Class Initialized
DEBUG - 2011-05-04 16:52:19 --> Model Class Initialized
DEBUG - 2011-05-04 16:52:19 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-05-04 16:52:19 --> Database Driver Class Initialized
DEBUG - 2011-05-04 16:52:20 --> Final output sent to browser
DEBUG - 2011-05-04 16:52:20 --> Total execution time: 0.9138
DEBUG - 2011-05-04 17:18:16 --> Config Class Initialized
DEBUG - 2011-05-04 17:18:16 --> Hooks Class Initialized
DEBUG - 2011-05-04 17:18:16 --> Utf8 Class Initialized
DEBUG - 2011-05-04 17:18:16 --> UTF-8 Support Enabled
DEBUG - 2011-05-04 17:18:16 --> URI Class Initialized
DEBUG - 2011-05-04 17:18:16 --> Router Class Initialized
DEBUG - 2011-05-04 17:18:16 --> Output Class Initialized
DEBUG - 2011-05-04 17:18:16 --> Input Class Initialized
DEBUG - 2011-05-04 17:18:16 --> Global POST and COOKIE data sanitized
DEBUG - 2011-05-04 17:18:16 --> Language Class Initialized
DEBUG - 2011-05-04 17:18:16 --> Loader Class Initialized
DEBUG - 2011-05-04 17:18:16 --> Controller Class Initialized
ERROR - 2011-05-04 17:18:16 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-05-04 17:18:16 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-05-04 17:18:16 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-05-04 17:18:16 --> Model Class Initialized
DEBUG - 2011-05-04 17:18:16 --> Model Class Initialized
DEBUG - 2011-05-04 17:18:16 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-05-04 17:18:16 --> Database Driver Class Initialized
DEBUG - 2011-05-04 17:18:16 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-05-04 17:18:16 --> Helper loaded: url_helper
DEBUG - 2011-05-04 17:18:16 --> File loaded: application/views/common/header.php
DEBUG - 2011-05-04 17:18:16 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-05-04 17:18:16 --> File loaded: application/views/common/footer.php
DEBUG - 2011-05-04 17:18:16 --> File loaded: application/views/layout/main.php
DEBUG - 2011-05-04 17:18:16 --> Final output sent to browser
DEBUG - 2011-05-04 17:18:16 --> Total execution time: 0.2410
DEBUG - 2011-05-04 17:18:17 --> Config Class Initialized
DEBUG - 2011-05-04 17:18:17 --> Hooks Class Initialized
DEBUG - 2011-05-04 17:18:17 --> Utf8 Class Initialized
DEBUG - 2011-05-04 17:18:17 --> UTF-8 Support Enabled
DEBUG - 2011-05-04 17:18:17 --> URI Class Initialized
DEBUG - 2011-05-04 17:18:17 --> Router Class Initialized
DEBUG - 2011-05-04 17:18:17 --> Output Class Initialized
DEBUG - 2011-05-04 17:18:17 --> Input Class Initialized
DEBUG - 2011-05-04 17:18:17 --> Global POST and COOKIE data sanitized
DEBUG - 2011-05-04 17:18:17 --> Language Class Initialized
DEBUG - 2011-05-04 17:18:17 --> Loader Class Initialized
DEBUG - 2011-05-04 17:18:17 --> Controller Class Initialized
DEBUG - 2011-05-04 17:18:17 --> Model Class Initialized
DEBUG - 2011-05-04 17:18:17 --> Model Class Initialized
DEBUG - 2011-05-04 17:18:17 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-05-04 17:18:17 --> Database Driver Class Initialized
DEBUG - 2011-05-04 17:18:18 --> Final output sent to browser
DEBUG - 2011-05-04 17:18:18 --> Total execution time: 0.8740
DEBUG - 2011-05-04 17:18:18 --> Config Class Initialized
DEBUG - 2011-05-04 17:18:18 --> Hooks Class Initialized
DEBUG - 2011-05-04 17:18:18 --> Utf8 Class Initialized
DEBUG - 2011-05-04 17:18:18 --> UTF-8 Support Enabled
DEBUG - 2011-05-04 17:18:18 --> URI Class Initialized
DEBUG - 2011-05-04 17:18:18 --> Router Class Initialized
DEBUG - 2011-05-04 17:18:18 --> Output Class Initialized
DEBUG - 2011-05-04 17:18:18 --> Input Class Initialized
DEBUG - 2011-05-04 17:18:18 --> Global POST and COOKIE data sanitized
DEBUG - 2011-05-04 17:18:18 --> Language Class Initialized
DEBUG - 2011-05-04 17:18:18 --> Loader Class Initialized
DEBUG - 2011-05-04 17:18:18 --> Controller Class Initialized
ERROR - 2011-05-04 17:18:18 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-05-04 17:18:18 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-05-04 17:18:18 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-05-04 17:18:18 --> Model Class Initialized
DEBUG - 2011-05-04 17:18:18 --> Model Class Initialized
DEBUG - 2011-05-04 17:18:18 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-05-04 17:18:18 --> Database Driver Class Initialized
DEBUG - 2011-05-04 17:18:18 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-05-04 17:18:18 --> Helper loaded: url_helper
DEBUG - 2011-05-04 17:18:18 --> File loaded: application/views/common/header.php
DEBUG - 2011-05-04 17:18:18 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-05-04 17:18:18 --> File loaded: application/views/common/footer.php
DEBUG - 2011-05-04 17:18:18 --> File loaded: application/views/layout/main.php
DEBUG - 2011-05-04 17:18:18 --> Final output sent to browser
DEBUG - 2011-05-04 17:18:18 --> Total execution time: 0.0300
DEBUG - 2011-05-04 17:18:18 --> Config Class Initialized
DEBUG - 2011-05-04 17:18:18 --> Hooks Class Initialized
DEBUG - 2011-05-04 17:18:18 --> Utf8 Class Initialized
DEBUG - 2011-05-04 17:18:18 --> UTF-8 Support Enabled
DEBUG - 2011-05-04 17:18:18 --> URI Class Initialized
DEBUG - 2011-05-04 17:18:18 --> Router Class Initialized
ERROR - 2011-05-04 17:18:18 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-05-04 17:18:19 --> Config Class Initialized
DEBUG - 2011-05-04 17:18:19 --> Hooks Class Initialized
DEBUG - 2011-05-04 17:18:19 --> Utf8 Class Initialized
DEBUG - 2011-05-04 17:18:19 --> UTF-8 Support Enabled
DEBUG - 2011-05-04 17:18:19 --> URI Class Initialized
DEBUG - 2011-05-04 17:18:19 --> Router Class Initialized
ERROR - 2011-05-04 17:18:19 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-05-04 17:18:19 --> Config Class Initialized
DEBUG - 2011-05-04 17:18:19 --> Hooks Class Initialized
DEBUG - 2011-05-04 17:18:19 --> Utf8 Class Initialized
DEBUG - 2011-05-04 17:18:19 --> UTF-8 Support Enabled
DEBUG - 2011-05-04 17:18:19 --> URI Class Initialized
DEBUG - 2011-05-04 17:18:19 --> Router Class Initialized
ERROR - 2011-05-04 17:18:19 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-05-04 18:09:24 --> Config Class Initialized
DEBUG - 2011-05-04 18:09:24 --> Hooks Class Initialized
DEBUG - 2011-05-04 18:09:24 --> Utf8 Class Initialized
DEBUG - 2011-05-04 18:09:24 --> UTF-8 Support Enabled
DEBUG - 2011-05-04 18:09:24 --> URI Class Initialized
DEBUG - 2011-05-04 18:09:24 --> Router Class Initialized
DEBUG - 2011-05-04 18:09:24 --> Output Class Initialized
DEBUG - 2011-05-04 18:09:24 --> Input Class Initialized
DEBUG - 2011-05-04 18:09:24 --> Global POST and COOKIE data sanitized
DEBUG - 2011-05-04 18:09:24 --> Language Class Initialized
DEBUG - 2011-05-04 18:09:24 --> Loader Class Initialized
DEBUG - 2011-05-04 18:09:24 --> Controller Class Initialized
DEBUG - 2011-05-04 18:09:24 --> Model Class Initialized
DEBUG - 2011-05-04 18:09:24 --> Model Class Initialized
DEBUG - 2011-05-04 18:09:24 --> Model Class Initialized
DEBUG - 2011-05-04 18:09:24 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-05-04 18:09:24 --> Database Driver Class Initialized
DEBUG - 2011-05-04 18:09:24 --> File loaded: application/views/table/main.php
DEBUG - 2011-05-04 18:09:24 --> Helper loaded: url_helper
DEBUG - 2011-05-04 18:09:24 --> File loaded: application/views/common/header.php
DEBUG - 2011-05-04 18:09:24 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-05-04 18:09:24 --> File loaded: application/views/common/footer.php
DEBUG - 2011-05-04 18:09:24 --> File loaded: application/views/layout/main.php
DEBUG - 2011-05-04 18:09:24 --> Final output sent to browser
DEBUG - 2011-05-04 18:09:24 --> Total execution time: 0.6198
DEBUG - 2011-05-04 18:09:26 --> Config Class Initialized
DEBUG - 2011-05-04 18:09:26 --> Hooks Class Initialized
DEBUG - 2011-05-04 18:09:26 --> Utf8 Class Initialized
DEBUG - 2011-05-04 18:09:26 --> UTF-8 Support Enabled
DEBUG - 2011-05-04 18:09:26 --> URI Class Initialized
DEBUG - 2011-05-04 18:09:26 --> Router Class Initialized
ERROR - 2011-05-04 18:09:26 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-05-04 21:17:51 --> Config Class Initialized
DEBUG - 2011-05-04 21:17:51 --> Hooks Class Initialized
DEBUG - 2011-05-04 21:17:51 --> Utf8 Class Initialized
DEBUG - 2011-05-04 21:17:51 --> UTF-8 Support Enabled
DEBUG - 2011-05-04 21:17:51 --> URI Class Initialized
DEBUG - 2011-05-04 21:17:51 --> Router Class Initialized
DEBUG - 2011-05-04 21:17:52 --> Output Class Initialized
DEBUG - 2011-05-04 21:17:52 --> Input Class Initialized
DEBUG - 2011-05-04 21:17:52 --> Global POST and COOKIE data sanitized
DEBUG - 2011-05-04 21:17:52 --> Language Class Initialized
DEBUG - 2011-05-04 21:17:52 --> Loader Class Initialized
DEBUG - 2011-05-04 21:17:52 --> Controller Class Initialized
ERROR - 2011-05-04 21:17:52 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-05-04 21:17:52 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-05-04 21:17:52 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-05-04 21:17:52 --> Model Class Initialized
DEBUG - 2011-05-04 21:17:52 --> Model Class Initialized
DEBUG - 2011-05-04 21:17:52 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-05-04 21:17:52 --> Database Driver Class Initialized
DEBUG - 2011-05-04 21:17:52 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-05-04 21:17:52 --> Helper loaded: url_helper
DEBUG - 2011-05-04 21:17:52 --> File loaded: application/views/common/header.php
DEBUG - 2011-05-04 21:17:52 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-05-04 21:17:52 --> File loaded: application/views/common/footer.php
DEBUG - 2011-05-04 21:17:52 --> File loaded: application/views/layout/main.php
DEBUG - 2011-05-04 21:17:52 --> Final output sent to browser
DEBUG - 2011-05-04 21:17:52 --> Total execution time: 0.2855
DEBUG - 2011-05-04 21:17:53 --> Config Class Initialized
DEBUG - 2011-05-04 21:17:53 --> Hooks Class Initialized
DEBUG - 2011-05-04 21:17:53 --> Utf8 Class Initialized
DEBUG - 2011-05-04 21:17:53 --> UTF-8 Support Enabled
DEBUG - 2011-05-04 21:17:53 --> URI Class Initialized
DEBUG - 2011-05-04 21:17:53 --> Router Class Initialized
DEBUG - 2011-05-04 21:17:53 --> Output Class Initialized
DEBUG - 2011-05-04 21:17:53 --> Input Class Initialized
DEBUG - 2011-05-04 21:17:53 --> Global POST and COOKIE data sanitized
DEBUG - 2011-05-04 21:17:53 --> Language Class Initialized
DEBUG - 2011-05-04 21:17:53 --> Loader Class Initialized
DEBUG - 2011-05-04 21:17:53 --> Controller Class Initialized
DEBUG - 2011-05-04 21:17:53 --> Model Class Initialized
DEBUG - 2011-05-04 21:17:53 --> Model Class Initialized
DEBUG - 2011-05-04 21:17:53 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-05-04 21:17:53 --> Database Driver Class Initialized
DEBUG - 2011-05-04 21:17:54 --> Final output sent to browser
DEBUG - 2011-05-04 21:17:54 --> Total execution time: 0.6223
DEBUG - 2011-05-04 22:09:28 --> Config Class Initialized
DEBUG - 2011-05-04 22:09:28 --> Hooks Class Initialized
DEBUG - 2011-05-04 22:09:28 --> Utf8 Class Initialized
DEBUG - 2011-05-04 22:09:28 --> UTF-8 Support Enabled
DEBUG - 2011-05-04 22:09:28 --> URI Class Initialized
DEBUG - 2011-05-04 22:09:28 --> Router Class Initialized
DEBUG - 2011-05-04 22:09:28 --> No URI present. Default controller set.
DEBUG - 2011-05-04 22:09:28 --> Output Class Initialized
DEBUG - 2011-05-04 22:09:28 --> Input Class Initialized
DEBUG - 2011-05-04 22:09:28 --> Global POST and COOKIE data sanitized
DEBUG - 2011-05-04 22:09:28 --> Language Class Initialized
DEBUG - 2011-05-04 22:09:28 --> Loader Class Initialized
DEBUG - 2011-05-04 22:09:28 --> Controller Class Initialized
DEBUG - 2011-05-04 22:09:28 --> File loaded: application/views/splash/main.php
DEBUG - 2011-05-04 22:09:28 --> Helper loaded: url_helper
DEBUG - 2011-05-04 22:09:28 --> File loaded: application/views/common/header.php
DEBUG - 2011-05-04 22:09:28 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-05-04 22:09:28 --> File loaded: application/views/common/footer.php
DEBUG - 2011-05-04 22:09:28 --> File loaded: application/views/layout/main.php
DEBUG - 2011-05-04 22:09:28 --> Final output sent to browser
DEBUG - 2011-05-04 22:09:28 --> Total execution time: 0.2344
DEBUG - 2011-05-04 23:14:44 --> Config Class Initialized
DEBUG - 2011-05-04 23:14:44 --> Hooks Class Initialized
DEBUG - 2011-05-04 23:14:44 --> Utf8 Class Initialized
DEBUG - 2011-05-04 23:14:44 --> UTF-8 Support Enabled
DEBUG - 2011-05-04 23:14:44 --> URI Class Initialized
DEBUG - 2011-05-04 23:14:44 --> Router Class Initialized
DEBUG - 2011-05-04 23:14:44 --> Output Class Initialized
DEBUG - 2011-05-04 23:14:44 --> Input Class Initialized
DEBUG - 2011-05-04 23:14:44 --> Global POST and COOKIE data sanitized
DEBUG - 2011-05-04 23:14:44 --> Language Class Initialized
DEBUG - 2011-05-04 23:14:45 --> Loader Class Initialized
DEBUG - 2011-05-04 23:14:45 --> Controller Class Initialized
DEBUG - 2011-05-04 23:14:45 --> Model Class Initialized
DEBUG - 2011-05-04 23:14:46 --> Model Class Initialized
DEBUG - 2011-05-04 23:14:46 --> Model Class Initialized
DEBUG - 2011-05-04 23:14:46 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-05-04 23:14:46 --> Database Driver Class Initialized
DEBUG - 2011-05-04 23:14:46 --> File loaded: application/views/table/main.php
DEBUG - 2011-05-04 23:14:46 --> Helper loaded: url_helper
DEBUG - 2011-05-04 23:14:46 --> File loaded: application/views/common/header.php
DEBUG - 2011-05-04 23:14:46 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-05-04 23:14:46 --> File loaded: application/views/common/footer.php
DEBUG - 2011-05-04 23:14:46 --> File loaded: application/views/layout/main.php
DEBUG - 2011-05-04 23:14:46 --> Final output sent to browser
DEBUG - 2011-05-04 23:14:46 --> Total execution time: 2.1163
DEBUG - 2011-05-04 23:14:47 --> Config Class Initialized
DEBUG - 2011-05-04 23:14:47 --> Hooks Class Initialized
DEBUG - 2011-05-04 23:14:47 --> Utf8 Class Initialized
DEBUG - 2011-05-04 23:14:47 --> UTF-8 Support Enabled
DEBUG - 2011-05-04 23:14:47 --> URI Class Initialized
DEBUG - 2011-05-04 23:14:47 --> Router Class Initialized
DEBUG - 2011-05-04 23:14:47 --> Output Class Initialized
DEBUG - 2011-05-04 23:14:47 --> Input Class Initialized
DEBUG - 2011-05-04 23:14:47 --> Global POST and COOKIE data sanitized
DEBUG - 2011-05-04 23:14:47 --> Language Class Initialized
DEBUG - 2011-05-04 23:14:47 --> Loader Class Initialized
DEBUG - 2011-05-04 23:14:47 --> Controller Class Initialized
ERROR - 2011-05-04 23:14:47 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-05-04 23:14:47 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-05-04 23:14:47 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-05-04 23:14:47 --> Model Class Initialized
DEBUG - 2011-05-04 23:14:47 --> Model Class Initialized
DEBUG - 2011-05-04 23:14:47 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-05-04 23:14:47 --> Database Driver Class Initialized
DEBUG - 2011-05-04 23:14:47 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-05-04 23:14:47 --> Helper loaded: url_helper
DEBUG - 2011-05-04 23:14:47 --> File loaded: application/views/common/header.php
DEBUG - 2011-05-04 23:14:47 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-05-04 23:14:47 --> File loaded: application/views/common/footer.php
DEBUG - 2011-05-04 23:14:47 --> File loaded: application/views/layout/main.php
DEBUG - 2011-05-04 23:14:47 --> Final output sent to browser
DEBUG - 2011-05-04 23:14:47 --> Total execution time: 0.1561

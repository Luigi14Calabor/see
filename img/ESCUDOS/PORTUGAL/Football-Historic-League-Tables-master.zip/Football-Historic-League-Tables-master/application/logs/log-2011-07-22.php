<?php  if ( ! defined('BASEPATH')) exit('No direct script access allowed'); ?>

DEBUG - 2011-07-22 00:53:27 --> Config Class Initialized
DEBUG - 2011-07-22 00:53:27 --> Hooks Class Initialized
DEBUG - 2011-07-22 00:53:27 --> Utf8 Class Initialized
DEBUG - 2011-07-22 00:53:27 --> UTF-8 Support Enabled
DEBUG - 2011-07-22 00:53:27 --> URI Class Initialized
DEBUG - 2011-07-22 00:53:27 --> Router Class Initialized
DEBUG - 2011-07-22 00:53:27 --> Output Class Initialized
DEBUG - 2011-07-22 00:53:27 --> Input Class Initialized
DEBUG - 2011-07-22 00:53:27 --> Global POST and COOKIE data sanitized
DEBUG - 2011-07-22 00:53:27 --> Language Class Initialized
DEBUG - 2011-07-22 00:53:27 --> Loader Class Initialized
DEBUG - 2011-07-22 00:53:27 --> Controller Class Initialized
ERROR - 2011-07-22 00:53:27 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-07-22 00:53:27 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-07-22 00:53:27 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-07-22 00:53:27 --> Model Class Initialized
DEBUG - 2011-07-22 00:53:27 --> Model Class Initialized
DEBUG - 2011-07-22 00:53:27 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-07-22 00:53:27 --> Database Driver Class Initialized
DEBUG - 2011-07-22 00:53:27 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-07-22 00:53:27 --> Helper loaded: url_helper
DEBUG - 2011-07-22 00:53:27 --> File loaded: application/views/common/header.php
DEBUG - 2011-07-22 00:53:27 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-07-22 00:53:27 --> File loaded: application/views/common/footer.php
DEBUG - 2011-07-22 00:53:27 --> File loaded: application/views/layout/main.php
DEBUG - 2011-07-22 00:53:27 --> Final output sent to browser
DEBUG - 2011-07-22 00:53:27 --> Total execution time: 0.2578
DEBUG - 2011-07-22 00:53:29 --> Config Class Initialized
DEBUG - 2011-07-22 00:53:29 --> Hooks Class Initialized
DEBUG - 2011-07-22 00:53:29 --> Utf8 Class Initialized
DEBUG - 2011-07-22 00:53:29 --> UTF-8 Support Enabled
DEBUG - 2011-07-22 00:53:29 --> URI Class Initialized
DEBUG - 2011-07-22 00:53:29 --> Router Class Initialized
DEBUG - 2011-07-22 00:53:29 --> Output Class Initialized
DEBUG - 2011-07-22 00:53:29 --> Input Class Initialized
DEBUG - 2011-07-22 00:53:29 --> Global POST and COOKIE data sanitized
DEBUG - 2011-07-22 00:53:29 --> Language Class Initialized
DEBUG - 2011-07-22 00:53:29 --> Loader Class Initialized
DEBUG - 2011-07-22 00:53:29 --> Controller Class Initialized
DEBUG - 2011-07-22 00:53:29 --> Model Class Initialized
DEBUG - 2011-07-22 00:53:29 --> Model Class Initialized
DEBUG - 2011-07-22 00:53:29 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-07-22 00:53:29 --> Database Driver Class Initialized
DEBUG - 2011-07-22 00:53:30 --> Final output sent to browser
DEBUG - 2011-07-22 00:53:30 --> Total execution time: 1.4024
DEBUG - 2011-07-22 00:53:33 --> Config Class Initialized
DEBUG - 2011-07-22 00:53:33 --> Hooks Class Initialized
DEBUG - 2011-07-22 00:53:33 --> Utf8 Class Initialized
DEBUG - 2011-07-22 00:53:33 --> UTF-8 Support Enabled
DEBUG - 2011-07-22 00:53:33 --> URI Class Initialized
DEBUG - 2011-07-22 00:53:33 --> Router Class Initialized
ERROR - 2011-07-22 00:53:33 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-07-22 00:53:34 --> Config Class Initialized
DEBUG - 2011-07-22 00:53:34 --> Hooks Class Initialized
DEBUG - 2011-07-22 00:53:34 --> Utf8 Class Initialized
DEBUG - 2011-07-22 00:53:34 --> UTF-8 Support Enabled
DEBUG - 2011-07-22 00:53:34 --> URI Class Initialized
DEBUG - 2011-07-22 00:53:34 --> Router Class Initialized
ERROR - 2011-07-22 00:53:34 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-07-22 00:53:34 --> Config Class Initialized
DEBUG - 2011-07-22 00:53:34 --> Hooks Class Initialized
DEBUG - 2011-07-22 00:53:34 --> Utf8 Class Initialized
DEBUG - 2011-07-22 00:53:34 --> UTF-8 Support Enabled
DEBUG - 2011-07-22 00:53:34 --> URI Class Initialized
DEBUG - 2011-07-22 00:53:34 --> Router Class Initialized
ERROR - 2011-07-22 00:53:34 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-07-22 04:01:59 --> Config Class Initialized
DEBUG - 2011-07-22 04:01:59 --> Hooks Class Initialized
DEBUG - 2011-07-22 04:01:59 --> Utf8 Class Initialized
DEBUG - 2011-07-22 04:01:59 --> UTF-8 Support Enabled
DEBUG - 2011-07-22 04:01:59 --> URI Class Initialized
DEBUG - 2011-07-22 04:01:59 --> Router Class Initialized
DEBUG - 2011-07-22 04:01:59 --> Output Class Initialized
DEBUG - 2011-07-22 04:01:59 --> Input Class Initialized
DEBUG - 2011-07-22 04:01:59 --> Global POST and COOKIE data sanitized
DEBUG - 2011-07-22 04:01:59 --> Language Class Initialized
DEBUG - 2011-07-22 04:01:59 --> Loader Class Initialized
DEBUG - 2011-07-22 04:01:59 --> Controller Class Initialized
DEBUG - 2011-07-22 04:01:59 --> Model Class Initialized
DEBUG - 2011-07-22 04:01:59 --> Model Class Initialized
DEBUG - 2011-07-22 04:01:59 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-07-22 04:01:59 --> Database Driver Class Initialized
DEBUG - 2011-07-22 04:02:00 --> Final output sent to browser
DEBUG - 2011-07-22 04:02:00 --> Total execution time: 0.8317
DEBUG - 2011-07-22 04:46:44 --> Config Class Initialized
DEBUG - 2011-07-22 04:46:44 --> Hooks Class Initialized
DEBUG - 2011-07-22 04:46:44 --> Utf8 Class Initialized
DEBUG - 2011-07-22 04:46:44 --> UTF-8 Support Enabled
DEBUG - 2011-07-22 04:46:44 --> URI Class Initialized
DEBUG - 2011-07-22 04:46:44 --> Router Class Initialized
DEBUG - 2011-07-22 04:46:44 --> Output Class Initialized
DEBUG - 2011-07-22 04:46:44 --> Input Class Initialized
DEBUG - 2011-07-22 04:46:44 --> Global POST and COOKIE data sanitized
DEBUG - 2011-07-22 04:46:44 --> Language Class Initialized
DEBUG - 2011-07-22 04:46:44 --> Loader Class Initialized
DEBUG - 2011-07-22 04:46:44 --> Controller Class Initialized
ERROR - 2011-07-22 04:46:44 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-07-22 04:46:44 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-07-22 04:46:44 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-07-22 04:46:44 --> Model Class Initialized
DEBUG - 2011-07-22 04:46:44 --> Model Class Initialized
DEBUG - 2011-07-22 04:46:44 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-07-22 04:46:44 --> Database Driver Class Initialized
DEBUG - 2011-07-22 04:46:48 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-07-22 04:46:48 --> Helper loaded: url_helper
DEBUG - 2011-07-22 04:46:48 --> File loaded: application/views/common/header.php
DEBUG - 2011-07-22 04:46:48 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-07-22 04:46:48 --> File loaded: application/views/common/footer.php
DEBUG - 2011-07-22 04:46:48 --> File loaded: application/views/layout/main.php
DEBUG - 2011-07-22 04:46:48 --> Final output sent to browser
DEBUG - 2011-07-22 04:46:48 --> Total execution time: 3.9536
DEBUG - 2011-07-22 04:46:50 --> Config Class Initialized
DEBUG - 2011-07-22 04:46:50 --> Hooks Class Initialized
DEBUG - 2011-07-22 04:46:50 --> Utf8 Class Initialized
DEBUG - 2011-07-22 04:46:50 --> UTF-8 Support Enabled
DEBUG - 2011-07-22 04:46:50 --> URI Class Initialized
DEBUG - 2011-07-22 04:46:50 --> Router Class Initialized
DEBUG - 2011-07-22 04:46:50 --> Output Class Initialized
DEBUG - 2011-07-22 04:46:50 --> Input Class Initialized
DEBUG - 2011-07-22 04:46:50 --> Global POST and COOKIE data sanitized
DEBUG - 2011-07-22 04:46:50 --> Language Class Initialized
DEBUG - 2011-07-22 04:46:50 --> Loader Class Initialized
DEBUG - 2011-07-22 04:46:50 --> Controller Class Initialized
DEBUG - 2011-07-22 04:46:50 --> Model Class Initialized
DEBUG - 2011-07-22 04:46:50 --> Model Class Initialized
DEBUG - 2011-07-22 04:46:50 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-07-22 04:46:50 --> Database Driver Class Initialized
DEBUG - 2011-07-22 04:46:52 --> Final output sent to browser
DEBUG - 2011-07-22 04:46:52 --> Total execution time: 2.0558
DEBUG - 2011-07-22 04:46:59 --> Config Class Initialized
DEBUG - 2011-07-22 04:46:59 --> Hooks Class Initialized
DEBUG - 2011-07-22 04:46:59 --> Utf8 Class Initialized
DEBUG - 2011-07-22 04:46:59 --> UTF-8 Support Enabled
DEBUG - 2011-07-22 04:46:59 --> URI Class Initialized
DEBUG - 2011-07-22 04:46:59 --> Router Class Initialized
ERROR - 2011-07-22 04:46:59 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-07-22 04:47:00 --> Config Class Initialized
DEBUG - 2011-07-22 04:47:00 --> Hooks Class Initialized
DEBUG - 2011-07-22 04:47:00 --> Utf8 Class Initialized
DEBUG - 2011-07-22 04:47:00 --> UTF-8 Support Enabled
DEBUG - 2011-07-22 04:47:00 --> URI Class Initialized
DEBUG - 2011-07-22 04:47:00 --> Router Class Initialized
ERROR - 2011-07-22 04:47:00 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-07-22 04:47:07 --> Config Class Initialized
DEBUG - 2011-07-22 04:47:07 --> Hooks Class Initialized
DEBUG - 2011-07-22 04:47:07 --> Utf8 Class Initialized
DEBUG - 2011-07-22 04:47:07 --> UTF-8 Support Enabled
DEBUG - 2011-07-22 04:47:07 --> URI Class Initialized
DEBUG - 2011-07-22 04:47:07 --> Router Class Initialized
ERROR - 2011-07-22 04:47:07 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-07-22 04:57:20 --> Config Class Initialized
DEBUG - 2011-07-22 04:57:20 --> Hooks Class Initialized
DEBUG - 2011-07-22 04:57:20 --> Utf8 Class Initialized
DEBUG - 2011-07-22 04:57:20 --> UTF-8 Support Enabled
DEBUG - 2011-07-22 04:57:20 --> URI Class Initialized
DEBUG - 2011-07-22 04:57:20 --> Router Class Initialized
DEBUG - 2011-07-22 04:57:20 --> No URI present. Default controller set.
DEBUG - 2011-07-22 04:57:20 --> Output Class Initialized
DEBUG - 2011-07-22 04:57:20 --> Input Class Initialized
DEBUG - 2011-07-22 04:57:20 --> Global POST and COOKIE data sanitized
DEBUG - 2011-07-22 04:57:20 --> Language Class Initialized
DEBUG - 2011-07-22 04:57:21 --> Loader Class Initialized
DEBUG - 2011-07-22 04:57:21 --> Controller Class Initialized
DEBUG - 2011-07-22 04:57:21 --> File loaded: application/views/splash/main.php
DEBUG - 2011-07-22 04:57:21 --> Helper loaded: url_helper
DEBUG - 2011-07-22 04:57:21 --> File loaded: application/views/common/header.php
DEBUG - 2011-07-22 04:57:21 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-07-22 04:57:21 --> File loaded: application/views/common/footer.php
DEBUG - 2011-07-22 04:57:21 --> File loaded: application/views/layout/main.php
DEBUG - 2011-07-22 04:57:21 --> Final output sent to browser
DEBUG - 2011-07-22 04:57:21 --> Total execution time: 0.6262
DEBUG - 2011-07-22 05:44:20 --> Config Class Initialized
DEBUG - 2011-07-22 05:44:20 --> Hooks Class Initialized
DEBUG - 2011-07-22 05:44:20 --> Utf8 Class Initialized
DEBUG - 2011-07-22 05:44:20 --> UTF-8 Support Enabled
DEBUG - 2011-07-22 05:44:20 --> URI Class Initialized
DEBUG - 2011-07-22 05:44:20 --> Router Class Initialized
ERROR - 2011-07-22 05:44:20 --> 404 Page Not Found --> robots.txt
DEBUG - 2011-07-22 10:44:53 --> Config Class Initialized
DEBUG - 2011-07-22 10:44:53 --> Hooks Class Initialized
DEBUG - 2011-07-22 10:44:53 --> Utf8 Class Initialized
DEBUG - 2011-07-22 10:44:53 --> UTF-8 Support Enabled
DEBUG - 2011-07-22 10:44:53 --> URI Class Initialized
DEBUG - 2011-07-22 10:44:53 --> Router Class Initialized
ERROR - 2011-07-22 10:44:53 --> 404 Page Not Found --> robots.txt
DEBUG - 2011-07-22 10:45:27 --> Config Class Initialized
DEBUG - 2011-07-22 10:45:27 --> Hooks Class Initialized
DEBUG - 2011-07-22 10:45:27 --> Utf8 Class Initialized
DEBUG - 2011-07-22 10:45:27 --> UTF-8 Support Enabled
DEBUG - 2011-07-22 10:45:27 --> URI Class Initialized
DEBUG - 2011-07-22 10:45:27 --> Router Class Initialized
DEBUG - 2011-07-22 10:45:27 --> Output Class Initialized
DEBUG - 2011-07-22 10:45:27 --> Input Class Initialized
DEBUG - 2011-07-22 10:45:27 --> Global POST and COOKIE data sanitized
DEBUG - 2011-07-22 10:45:27 --> Language Class Initialized
DEBUG - 2011-07-22 10:45:27 --> Loader Class Initialized
DEBUG - 2011-07-22 10:45:27 --> Controller Class Initialized
ERROR - 2011-07-22 10:45:27 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-07-22 10:45:27 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-07-22 10:45:27 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-07-22 10:45:27 --> Model Class Initialized
DEBUG - 2011-07-22 10:45:27 --> Model Class Initialized
DEBUG - 2011-07-22 10:45:27 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-07-22 10:45:27 --> Database Driver Class Initialized
DEBUG - 2011-07-22 10:45:28 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-07-22 10:45:28 --> Helper loaded: url_helper
DEBUG - 2011-07-22 10:45:28 --> File loaded: application/views/common/header.php
DEBUG - 2011-07-22 10:45:28 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-07-22 10:45:28 --> File loaded: application/views/common/footer.php
DEBUG - 2011-07-22 10:45:28 --> File loaded: application/views/layout/main.php
DEBUG - 2011-07-22 10:45:28 --> Final output sent to browser
DEBUG - 2011-07-22 10:45:28 --> Total execution time: 1.1846
DEBUG - 2011-07-22 10:58:58 --> Config Class Initialized
DEBUG - 2011-07-22 10:58:58 --> Hooks Class Initialized
DEBUG - 2011-07-22 10:58:58 --> Utf8 Class Initialized
DEBUG - 2011-07-22 10:58:58 --> UTF-8 Support Enabled
DEBUG - 2011-07-22 10:58:58 --> URI Class Initialized
DEBUG - 2011-07-22 10:58:58 --> Router Class Initialized
DEBUG - 2011-07-22 10:58:58 --> No URI present. Default controller set.
DEBUG - 2011-07-22 10:58:58 --> Output Class Initialized
DEBUG - 2011-07-22 10:58:58 --> Input Class Initialized
DEBUG - 2011-07-22 10:58:58 --> Global POST and COOKIE data sanitized
DEBUG - 2011-07-22 10:58:58 --> Language Class Initialized
DEBUG - 2011-07-22 10:58:58 --> Loader Class Initialized
DEBUG - 2011-07-22 10:58:58 --> Controller Class Initialized
DEBUG - 2011-07-22 10:58:58 --> File loaded: application/views/splash/main.php
DEBUG - 2011-07-22 10:58:58 --> Helper loaded: url_helper
DEBUG - 2011-07-22 10:58:58 --> File loaded: application/views/common/header.php
DEBUG - 2011-07-22 10:58:58 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-07-22 10:58:58 --> File loaded: application/views/common/footer.php
DEBUG - 2011-07-22 10:58:58 --> File loaded: application/views/layout/main.php
DEBUG - 2011-07-22 10:58:58 --> Final output sent to browser
DEBUG - 2011-07-22 10:58:58 --> Total execution time: 0.1663
DEBUG - 2011-07-22 14:33:20 --> Config Class Initialized
DEBUG - 2011-07-22 14:33:20 --> Hooks Class Initialized
DEBUG - 2011-07-22 14:33:20 --> Utf8 Class Initialized
DEBUG - 2011-07-22 14:33:20 --> UTF-8 Support Enabled
DEBUG - 2011-07-22 14:33:20 --> URI Class Initialized
DEBUG - 2011-07-22 14:33:20 --> Router Class Initialized
DEBUG - 2011-07-22 14:33:20 --> Output Class Initialized
DEBUG - 2011-07-22 14:33:20 --> Input Class Initialized
DEBUG - 2011-07-22 14:33:20 --> Global POST and COOKIE data sanitized
DEBUG - 2011-07-22 14:33:20 --> Language Class Initialized
DEBUG - 2011-07-22 14:33:20 --> Loader Class Initialized
DEBUG - 2011-07-22 14:33:20 --> Controller Class Initialized
DEBUG - 2011-07-22 14:33:20 --> Model Class Initialized
DEBUG - 2011-07-22 14:33:21 --> Model Class Initialized
DEBUG - 2011-07-22 14:33:21 --> Model Class Initialized
DEBUG - 2011-07-22 14:33:21 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-07-22 14:33:21 --> Database Driver Class Initialized
DEBUG - 2011-07-22 14:33:21 --> File loaded: application/views/table/main.php
DEBUG - 2011-07-22 14:33:21 --> Helper loaded: url_helper
DEBUG - 2011-07-22 14:33:21 --> File loaded: application/views/common/header.php
DEBUG - 2011-07-22 14:33:21 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-07-22 14:33:21 --> File loaded: application/views/common/footer.php
DEBUG - 2011-07-22 14:33:21 --> File loaded: application/views/layout/main.php
DEBUG - 2011-07-22 14:33:21 --> Final output sent to browser
DEBUG - 2011-07-22 14:33:21 --> Total execution time: 0.9460
DEBUG - 2011-07-22 14:33:25 --> Config Class Initialized
DEBUG - 2011-07-22 14:33:25 --> Hooks Class Initialized
DEBUG - 2011-07-22 14:33:25 --> Utf8 Class Initialized
DEBUG - 2011-07-22 14:33:25 --> UTF-8 Support Enabled
DEBUG - 2011-07-22 14:33:25 --> URI Class Initialized
DEBUG - 2011-07-22 14:33:25 --> Router Class Initialized
ERROR - 2011-07-22 14:33:25 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-07-22 14:33:25 --> Config Class Initialized
DEBUG - 2011-07-22 14:33:25 --> Hooks Class Initialized
DEBUG - 2011-07-22 14:33:25 --> Utf8 Class Initialized
DEBUG - 2011-07-22 14:33:25 --> UTF-8 Support Enabled
DEBUG - 2011-07-22 14:33:25 --> URI Class Initialized
DEBUG - 2011-07-22 14:33:25 --> Router Class Initialized
ERROR - 2011-07-22 14:33:25 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-07-22 14:33:26 --> Config Class Initialized
DEBUG - 2011-07-22 14:33:26 --> Hooks Class Initialized
DEBUG - 2011-07-22 14:33:26 --> Utf8 Class Initialized
DEBUG - 2011-07-22 14:33:26 --> UTF-8 Support Enabled
DEBUG - 2011-07-22 14:33:26 --> URI Class Initialized
DEBUG - 2011-07-22 14:33:26 --> Router Class Initialized
ERROR - 2011-07-22 14:33:26 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-07-22 15:07:10 --> Config Class Initialized
DEBUG - 2011-07-22 15:07:10 --> Hooks Class Initialized
DEBUG - 2011-07-22 15:07:10 --> Utf8 Class Initialized
DEBUG - 2011-07-22 15:07:10 --> UTF-8 Support Enabled
DEBUG - 2011-07-22 15:07:10 --> URI Class Initialized
DEBUG - 2011-07-22 15:07:10 --> Router Class Initialized
DEBUG - 2011-07-22 15:07:10 --> Output Class Initialized
DEBUG - 2011-07-22 15:07:10 --> Input Class Initialized
DEBUG - 2011-07-22 15:07:10 --> Global POST and COOKIE data sanitized
DEBUG - 2011-07-22 15:07:10 --> Language Class Initialized
DEBUG - 2011-07-22 15:07:10 --> Loader Class Initialized
DEBUG - 2011-07-22 15:07:10 --> Controller Class Initialized
DEBUG - 2011-07-22 15:07:10 --> Model Class Initialized
DEBUG - 2011-07-22 15:07:10 --> Model Class Initialized
DEBUG - 2011-07-22 15:07:10 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-07-22 15:07:10 --> Database Driver Class Initialized
DEBUG - 2011-07-22 15:07:11 --> Final output sent to browser
DEBUG - 2011-07-22 15:07:11 --> Total execution time: 1.0540
DEBUG - 2011-07-22 15:16:06 --> Config Class Initialized
DEBUG - 2011-07-22 15:16:06 --> Hooks Class Initialized
DEBUG - 2011-07-22 15:16:06 --> Utf8 Class Initialized
DEBUG - 2011-07-22 15:16:06 --> UTF-8 Support Enabled
DEBUG - 2011-07-22 15:16:06 --> URI Class Initialized
DEBUG - 2011-07-22 15:16:06 --> Router Class Initialized
DEBUG - 2011-07-22 15:16:06 --> Output Class Initialized
DEBUG - 2011-07-22 15:16:06 --> Input Class Initialized
DEBUG - 2011-07-22 15:16:06 --> Global POST and COOKIE data sanitized
DEBUG - 2011-07-22 15:16:06 --> Language Class Initialized
DEBUG - 2011-07-22 15:16:06 --> Loader Class Initialized
DEBUG - 2011-07-22 15:16:06 --> Controller Class Initialized
DEBUG - 2011-07-22 15:16:06 --> Model Class Initialized
DEBUG - 2011-07-22 15:16:06 --> Model Class Initialized
DEBUG - 2011-07-22 15:16:06 --> Model Class Initialized
DEBUG - 2011-07-22 15:16:06 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-07-22 15:16:06 --> Database Driver Class Initialized
DEBUG - 2011-07-22 15:16:07 --> File loaded: application/views/table/main.php
DEBUG - 2011-07-22 15:16:07 --> Helper loaded: url_helper
DEBUG - 2011-07-22 15:16:07 --> File loaded: application/views/common/header.php
DEBUG - 2011-07-22 15:16:07 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-07-22 15:16:07 --> File loaded: application/views/common/footer.php
DEBUG - 2011-07-22 15:16:07 --> File loaded: application/views/layout/main.php
DEBUG - 2011-07-22 15:16:07 --> Final output sent to browser
DEBUG - 2011-07-22 15:16:07 --> Total execution time: 1.1454
DEBUG - 2011-07-22 15:16:09 --> Config Class Initialized
DEBUG - 2011-07-22 15:16:09 --> Hooks Class Initialized
DEBUG - 2011-07-22 15:16:09 --> Utf8 Class Initialized
DEBUG - 2011-07-22 15:16:09 --> UTF-8 Support Enabled
DEBUG - 2011-07-22 15:16:09 --> URI Class Initialized
DEBUG - 2011-07-22 15:16:09 --> Router Class Initialized
DEBUG - 2011-07-22 15:16:09 --> Output Class Initialized
DEBUG - 2011-07-22 15:16:09 --> Input Class Initialized
DEBUG - 2011-07-22 15:16:09 --> Global POST and COOKIE data sanitized
DEBUG - 2011-07-22 15:16:09 --> Language Class Initialized
DEBUG - 2011-07-22 15:16:09 --> Loader Class Initialized
DEBUG - 2011-07-22 15:16:09 --> Controller Class Initialized
ERROR - 2011-07-22 15:16:09 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-07-22 15:16:09 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-07-22 15:16:09 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-07-22 15:16:09 --> Model Class Initialized
DEBUG - 2011-07-22 15:16:09 --> Model Class Initialized
DEBUG - 2011-07-22 15:16:09 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-07-22 15:16:09 --> Database Driver Class Initialized
DEBUG - 2011-07-22 15:16:09 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-07-22 15:16:09 --> Helper loaded: url_helper
DEBUG - 2011-07-22 15:16:09 --> File loaded: application/views/common/header.php
DEBUG - 2011-07-22 15:16:09 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-07-22 15:16:09 --> File loaded: application/views/common/footer.php
DEBUG - 2011-07-22 15:16:09 --> File loaded: application/views/layout/main.php
DEBUG - 2011-07-22 15:16:09 --> Final output sent to browser
DEBUG - 2011-07-22 15:16:09 --> Total execution time: 0.0912
DEBUG - 2011-07-22 15:45:25 --> Config Class Initialized
DEBUG - 2011-07-22 15:45:25 --> Hooks Class Initialized
DEBUG - 2011-07-22 15:45:25 --> Utf8 Class Initialized
DEBUG - 2011-07-22 15:45:25 --> UTF-8 Support Enabled
DEBUG - 2011-07-22 15:45:25 --> URI Class Initialized
DEBUG - 2011-07-22 15:45:25 --> Router Class Initialized
ERROR - 2011-07-22 15:45:25 --> 404 Page Not Found --> robots.txt
DEBUG - 2011-07-22 15:45:25 --> Config Class Initialized
DEBUG - 2011-07-22 15:45:25 --> Hooks Class Initialized
DEBUG - 2011-07-22 15:45:25 --> Utf8 Class Initialized
DEBUG - 2011-07-22 15:45:25 --> UTF-8 Support Enabled
DEBUG - 2011-07-22 15:45:25 --> URI Class Initialized
DEBUG - 2011-07-22 15:45:25 --> Router Class Initialized
DEBUG - 2011-07-22 15:45:25 --> Output Class Initialized
DEBUG - 2011-07-22 15:45:25 --> Input Class Initialized
DEBUG - 2011-07-22 15:45:25 --> Global POST and COOKIE data sanitized
DEBUG - 2011-07-22 15:45:25 --> Language Class Initialized
DEBUG - 2011-07-22 15:45:25 --> Loader Class Initialized
DEBUG - 2011-07-22 15:45:25 --> Controller Class Initialized
DEBUG - 2011-07-22 15:45:25 --> Model Class Initialized
DEBUG - 2011-07-22 15:45:25 --> Model Class Initialized
DEBUG - 2011-07-22 15:45:25 --> Model Class Initialized
DEBUG - 2011-07-22 15:45:25 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-07-22 15:45:25 --> Database Driver Class Initialized
DEBUG - 2011-07-22 15:45:26 --> File loaded: application/views/table/main.php
DEBUG - 2011-07-22 15:45:26 --> Helper loaded: url_helper
DEBUG - 2011-07-22 15:45:26 --> File loaded: application/views/common/header.php
DEBUG - 2011-07-22 15:45:26 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-07-22 15:45:26 --> File loaded: application/views/common/footer.php
DEBUG - 2011-07-22 15:45:26 --> File loaded: application/views/layout/main.php
DEBUG - 2011-07-22 15:45:26 --> Final output sent to browser
DEBUG - 2011-07-22 15:45:26 --> Total execution time: 0.6584
DEBUG - 2011-07-22 15:59:15 --> Config Class Initialized
DEBUG - 2011-07-22 15:59:15 --> Hooks Class Initialized
DEBUG - 2011-07-22 15:59:15 --> Utf8 Class Initialized
DEBUG - 2011-07-22 15:59:15 --> UTF-8 Support Enabled
DEBUG - 2011-07-22 15:59:15 --> URI Class Initialized
DEBUG - 2011-07-22 15:59:15 --> Router Class Initialized
DEBUG - 2011-07-22 15:59:15 --> Output Class Initialized
DEBUG - 2011-07-22 15:59:15 --> Input Class Initialized
DEBUG - 2011-07-22 15:59:15 --> Global POST and COOKIE data sanitized
DEBUG - 2011-07-22 15:59:15 --> Language Class Initialized
DEBUG - 2011-07-22 15:59:15 --> Loader Class Initialized
DEBUG - 2011-07-22 15:59:15 --> Controller Class Initialized
ERROR - 2011-07-22 15:59:15 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-07-22 15:59:15 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-07-22 15:59:15 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-07-22 15:59:15 --> Model Class Initialized
DEBUG - 2011-07-22 15:59:15 --> Model Class Initialized
DEBUG - 2011-07-22 15:59:15 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-07-22 15:59:15 --> Database Driver Class Initialized
DEBUG - 2011-07-22 15:59:15 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-07-22 15:59:15 --> Helper loaded: url_helper
DEBUG - 2011-07-22 15:59:15 --> File loaded: application/views/common/header.php
DEBUG - 2011-07-22 15:59:15 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-07-22 15:59:15 --> File loaded: application/views/common/footer.php
DEBUG - 2011-07-22 15:59:15 --> File loaded: application/views/layout/main.php
DEBUG - 2011-07-22 15:59:15 --> Final output sent to browser
DEBUG - 2011-07-22 15:59:15 --> Total execution time: 0.2677
DEBUG - 2011-07-22 15:59:18 --> Config Class Initialized
DEBUG - 2011-07-22 15:59:18 --> Hooks Class Initialized
DEBUG - 2011-07-22 15:59:18 --> Utf8 Class Initialized
DEBUG - 2011-07-22 15:59:18 --> UTF-8 Support Enabled
DEBUG - 2011-07-22 15:59:18 --> URI Class Initialized
DEBUG - 2011-07-22 15:59:18 --> Router Class Initialized
DEBUG - 2011-07-22 15:59:18 --> Output Class Initialized
DEBUG - 2011-07-22 15:59:18 --> Input Class Initialized
DEBUG - 2011-07-22 15:59:18 --> Global POST and COOKIE data sanitized
DEBUG - 2011-07-22 15:59:18 --> Language Class Initialized
DEBUG - 2011-07-22 15:59:18 --> Loader Class Initialized
DEBUG - 2011-07-22 15:59:18 --> Controller Class Initialized
DEBUG - 2011-07-22 15:59:18 --> Model Class Initialized
DEBUG - 2011-07-22 15:59:18 --> Model Class Initialized
DEBUG - 2011-07-22 15:59:18 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-07-22 15:59:18 --> Database Driver Class Initialized
DEBUG - 2011-07-22 15:59:19 --> Final output sent to browser
DEBUG - 2011-07-22 15:59:19 --> Total execution time: 1.2104
DEBUG - 2011-07-22 16:10:47 --> Config Class Initialized
DEBUG - 2011-07-22 16:10:47 --> Hooks Class Initialized
DEBUG - 2011-07-22 16:10:47 --> Utf8 Class Initialized
DEBUG - 2011-07-22 16:10:47 --> UTF-8 Support Enabled
DEBUG - 2011-07-22 16:10:47 --> URI Class Initialized
DEBUG - 2011-07-22 16:10:47 --> Router Class Initialized
DEBUG - 2011-07-22 16:10:47 --> No URI present. Default controller set.
DEBUG - 2011-07-22 16:10:47 --> Output Class Initialized
DEBUG - 2011-07-22 16:10:47 --> Input Class Initialized
DEBUG - 2011-07-22 16:10:47 --> Global POST and COOKIE data sanitized
DEBUG - 2011-07-22 16:10:47 --> Language Class Initialized
DEBUG - 2011-07-22 16:10:47 --> Loader Class Initialized
DEBUG - 2011-07-22 16:10:47 --> Controller Class Initialized
DEBUG - 2011-07-22 16:10:47 --> File loaded: application/views/splash/main.php
DEBUG - 2011-07-22 16:10:47 --> Helper loaded: url_helper
DEBUG - 2011-07-22 16:10:47 --> File loaded: application/views/common/header.php
DEBUG - 2011-07-22 16:10:47 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-07-22 16:10:47 --> File loaded: application/views/common/footer.php
DEBUG - 2011-07-22 16:10:47 --> File loaded: application/views/layout/main.php
DEBUG - 2011-07-22 16:10:47 --> Final output sent to browser
DEBUG - 2011-07-22 16:10:47 --> Total execution time: 0.1011
DEBUG - 2011-07-22 18:07:24 --> Config Class Initialized
DEBUG - 2011-07-22 18:07:24 --> Hooks Class Initialized
DEBUG - 2011-07-22 18:07:24 --> Utf8 Class Initialized
DEBUG - 2011-07-22 18:07:24 --> UTF-8 Support Enabled
DEBUG - 2011-07-22 18:07:24 --> URI Class Initialized
DEBUG - 2011-07-22 18:07:24 --> Router Class Initialized
ERROR - 2011-07-22 18:07:24 --> 404 Page Not Found --> robots.txt
DEBUG - 2011-07-22 18:11:34 --> Config Class Initialized
DEBUG - 2011-07-22 18:11:34 --> Hooks Class Initialized
DEBUG - 2011-07-22 18:11:34 --> Utf8 Class Initialized
DEBUG - 2011-07-22 18:11:34 --> UTF-8 Support Enabled
DEBUG - 2011-07-22 18:11:34 --> URI Class Initialized
DEBUG - 2011-07-22 18:11:34 --> Router Class Initialized
ERROR - 2011-07-22 18:11:34 --> 404 Page Not Found --> robots.txt
DEBUG - 2011-07-22 18:11:34 --> Config Class Initialized
DEBUG - 2011-07-22 18:11:34 --> Hooks Class Initialized
DEBUG - 2011-07-22 18:11:34 --> Utf8 Class Initialized
DEBUG - 2011-07-22 18:11:34 --> UTF-8 Support Enabled
DEBUG - 2011-07-22 18:11:34 --> URI Class Initialized
DEBUG - 2011-07-22 18:11:34 --> Router Class Initialized
DEBUG - 2011-07-22 18:11:34 --> No URI present. Default controller set.
DEBUG - 2011-07-22 18:11:35 --> Output Class Initialized
DEBUG - 2011-07-22 18:11:35 --> Input Class Initialized
DEBUG - 2011-07-22 18:11:35 --> Global POST and COOKIE data sanitized
DEBUG - 2011-07-22 18:11:35 --> Language Class Initialized
DEBUG - 2011-07-22 18:11:35 --> Loader Class Initialized
DEBUG - 2011-07-22 18:11:35 --> Controller Class Initialized
DEBUG - 2011-07-22 18:11:35 --> File loaded: application/views/splash/main.php
DEBUG - 2011-07-22 18:11:35 --> Helper loaded: url_helper
DEBUG - 2011-07-22 18:11:35 --> File loaded: application/views/common/header.php
DEBUG - 2011-07-22 18:11:35 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-07-22 18:11:35 --> File loaded: application/views/common/footer.php
DEBUG - 2011-07-22 18:11:35 --> File loaded: application/views/layout/main.php
DEBUG - 2011-07-22 18:11:35 --> Config Class Initialized
DEBUG - 2011-07-22 18:11:35 --> Hooks Class Initialized
DEBUG - 2011-07-22 18:11:35 --> Utf8 Class Initialized
DEBUG - 2011-07-22 18:11:35 --> UTF-8 Support Enabled
DEBUG - 2011-07-22 18:11:35 --> URI Class Initialized
DEBUG - 2011-07-22 18:11:35 --> Router Class Initialized
DEBUG - 2011-07-22 18:11:35 --> No URI present. Default controller set.
DEBUG - 2011-07-22 18:11:35 --> Output Class Initialized
DEBUG - 2011-07-22 18:11:35 --> Input Class Initialized
DEBUG - 2011-07-22 18:11:35 --> Global POST and COOKIE data sanitized
DEBUG - 2011-07-22 18:11:35 --> Language Class Initialized
DEBUG - 2011-07-22 18:11:35 --> Loader Class Initialized
DEBUG - 2011-07-22 18:11:35 --> Controller Class Initialized
DEBUG - 2011-07-22 18:11:35 --> File loaded: application/views/splash/main.php
DEBUG - 2011-07-22 18:11:35 --> Helper loaded: url_helper
DEBUG - 2011-07-22 18:11:35 --> File loaded: application/views/common/header.php
DEBUG - 2011-07-22 18:11:35 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-07-22 18:11:35 --> File loaded: application/views/common/footer.php
DEBUG - 2011-07-22 18:11:35 --> File loaded: application/views/layout/main.php
DEBUG - 2011-07-22 18:11:35 --> Final output sent to browser
DEBUG - 2011-07-22 18:11:35 --> Total execution time: 0.0135
DEBUG - 2011-07-22 18:11:35 --> Config Class Initialized
DEBUG - 2011-07-22 18:11:35 --> Hooks Class Initialized
DEBUG - 2011-07-22 18:11:35 --> Utf8 Class Initialized
DEBUG - 2011-07-22 18:11:35 --> UTF-8 Support Enabled
DEBUG - 2011-07-22 18:11:35 --> URI Class Initialized
DEBUG - 2011-07-22 18:11:35 --> Router Class Initialized
DEBUG - 2011-07-22 18:11:35 --> Output Class Initialized
DEBUG - 2011-07-22 18:11:35 --> Input Class Initialized
DEBUG - 2011-07-22 18:11:35 --> Global POST and COOKIE data sanitized
DEBUG - 2011-07-22 18:11:35 --> Language Class Initialized
DEBUG - 2011-07-22 18:11:35 --> Loader Class Initialized
DEBUG - 2011-07-22 18:11:35 --> Controller Class Initialized
DEBUG - 2011-07-22 18:11:35 --> Model Class Initialized
DEBUG - 2011-07-22 18:11:35 --> Model Class Initialized
DEBUG - 2011-07-22 18:11:35 --> Model Class Initialized
DEBUG - 2011-07-22 18:11:35 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-07-22 18:11:35 --> Database Driver Class Initialized
DEBUG - 2011-07-22 18:11:36 --> File loaded: application/views/table/main.php
DEBUG - 2011-07-22 18:11:36 --> Helper loaded: url_helper
DEBUG - 2011-07-22 18:11:36 --> File loaded: application/views/common/header.php
DEBUG - 2011-07-22 18:11:36 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-07-22 18:11:36 --> File loaded: application/views/common/footer.php
DEBUG - 2011-07-22 18:11:36 --> File loaded: application/views/layout/main.php
DEBUG - 2011-07-22 18:11:37 --> Config Class Initialized
DEBUG - 2011-07-22 18:11:37 --> Hooks Class Initialized
DEBUG - 2011-07-22 18:11:37 --> Utf8 Class Initialized
DEBUG - 2011-07-22 18:11:37 --> UTF-8 Support Enabled
DEBUG - 2011-07-22 18:11:37 --> URI Class Initialized
DEBUG - 2011-07-22 18:11:37 --> Router Class Initialized
DEBUG - 2011-07-22 18:11:37 --> Output Class Initialized
DEBUG - 2011-07-22 18:11:37 --> Input Class Initialized
DEBUG - 2011-07-22 18:11:37 --> Global POST and COOKIE data sanitized
DEBUG - 2011-07-22 18:11:37 --> Language Class Initialized
DEBUG - 2011-07-22 18:11:37 --> Loader Class Initialized
DEBUG - 2011-07-22 18:11:37 --> Controller Class Initialized
DEBUG - 2011-07-22 18:11:37 --> Model Class Initialized
DEBUG - 2011-07-22 18:11:37 --> Model Class Initialized
DEBUG - 2011-07-22 18:11:37 --> Model Class Initialized
DEBUG - 2011-07-22 18:11:37 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-07-22 18:11:37 --> Database Driver Class Initialized
DEBUG - 2011-07-22 18:11:37 --> File loaded: application/views/table/main.php
DEBUG - 2011-07-22 18:11:37 --> Helper loaded: url_helper
DEBUG - 2011-07-22 18:11:37 --> File loaded: application/views/common/header.php
DEBUG - 2011-07-22 18:11:37 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-07-22 18:11:37 --> File loaded: application/views/common/footer.php
DEBUG - 2011-07-22 18:11:37 --> File loaded: application/views/layout/main.php
DEBUG - 2011-07-22 18:11:37 --> Final output sent to browser
DEBUG - 2011-07-22 18:11:37 --> Total execution time: 0.0806
DEBUG - 2011-07-22 18:11:38 --> Config Class Initialized
DEBUG - 2011-07-22 18:11:38 --> Hooks Class Initialized
DEBUG - 2011-07-22 18:11:38 --> Utf8 Class Initialized
DEBUG - 2011-07-22 18:11:38 --> UTF-8 Support Enabled
DEBUG - 2011-07-22 18:11:38 --> URI Class Initialized
DEBUG - 2011-07-22 18:11:38 --> Router Class Initialized
DEBUG - 2011-07-22 18:11:38 --> Output Class Initialized
DEBUG - 2011-07-22 18:11:38 --> Input Class Initialized
DEBUG - 2011-07-22 18:11:38 --> Global POST and COOKIE data sanitized
DEBUG - 2011-07-22 18:11:38 --> Language Class Initialized
DEBUG - 2011-07-22 18:11:38 --> Loader Class Initialized
DEBUG - 2011-07-22 18:11:38 --> Controller Class Initialized
ERROR - 2011-07-22 18:11:38 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-07-22 18:11:38 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-07-22 18:11:38 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-07-22 18:11:38 --> Model Class Initialized
DEBUG - 2011-07-22 18:11:38 --> Model Class Initialized
DEBUG - 2011-07-22 18:11:38 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-07-22 18:11:38 --> Database Driver Class Initialized
DEBUG - 2011-07-22 18:11:38 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-07-22 18:11:38 --> Helper loaded: url_helper
DEBUG - 2011-07-22 18:11:38 --> File loaded: application/views/common/header.php
DEBUG - 2011-07-22 18:11:38 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-07-22 18:11:38 --> File loaded: application/views/common/footer.php
DEBUG - 2011-07-22 18:11:38 --> File loaded: application/views/layout/main.php
DEBUG - 2011-07-22 18:11:39 --> Config Class Initialized
DEBUG - 2011-07-22 18:11:39 --> Hooks Class Initialized
DEBUG - 2011-07-22 18:11:39 --> Utf8 Class Initialized
DEBUG - 2011-07-22 18:11:39 --> UTF-8 Support Enabled
DEBUG - 2011-07-22 18:11:39 --> URI Class Initialized
DEBUG - 2011-07-22 18:11:39 --> Router Class Initialized
DEBUG - 2011-07-22 18:11:39 --> Output Class Initialized
DEBUG - 2011-07-22 18:11:39 --> Input Class Initialized
DEBUG - 2011-07-22 18:11:39 --> Global POST and COOKIE data sanitized
DEBUG - 2011-07-22 18:11:39 --> Language Class Initialized
DEBUG - 2011-07-22 18:11:39 --> Loader Class Initialized
DEBUG - 2011-07-22 18:11:39 --> Controller Class Initialized
ERROR - 2011-07-22 18:11:39 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-07-22 18:11:39 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-07-22 18:11:39 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-07-22 18:11:39 --> Model Class Initialized
DEBUG - 2011-07-22 18:11:39 --> Model Class Initialized
DEBUG - 2011-07-22 18:11:39 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-07-22 18:11:39 --> Database Driver Class Initialized
DEBUG - 2011-07-22 18:11:39 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-07-22 18:11:39 --> Helper loaded: url_helper
DEBUG - 2011-07-22 18:11:39 --> File loaded: application/views/common/header.php
DEBUG - 2011-07-22 18:11:39 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-07-22 18:11:39 --> File loaded: application/views/common/footer.php
DEBUG - 2011-07-22 18:11:39 --> File loaded: application/views/layout/main.php
DEBUG - 2011-07-22 18:11:39 --> Final output sent to browser
DEBUG - 2011-07-22 18:11:39 --> Total execution time: 0.0314
DEBUG - 2011-07-22 18:48:34 --> Config Class Initialized
DEBUG - 2011-07-22 18:48:34 --> Hooks Class Initialized
DEBUG - 2011-07-22 18:48:34 --> Utf8 Class Initialized
DEBUG - 2011-07-22 18:48:34 --> UTF-8 Support Enabled
DEBUG - 2011-07-22 18:48:34 --> URI Class Initialized
DEBUG - 2011-07-22 18:48:34 --> Router Class Initialized
DEBUG - 2011-07-22 18:48:34 --> Output Class Initialized
DEBUG - 2011-07-22 18:48:34 --> Input Class Initialized
DEBUG - 2011-07-22 18:48:34 --> Global POST and COOKIE data sanitized
DEBUG - 2011-07-22 18:48:34 --> Language Class Initialized
DEBUG - 2011-07-22 18:48:34 --> Loader Class Initialized
DEBUG - 2011-07-22 18:48:34 --> Controller Class Initialized
DEBUG - 2011-07-22 18:48:34 --> Model Class Initialized
DEBUG - 2011-07-22 18:48:34 --> Model Class Initialized
DEBUG - 2011-07-22 18:48:34 --> Model Class Initialized
DEBUG - 2011-07-22 18:48:34 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-07-22 18:48:34 --> Database Driver Class Initialized
DEBUG - 2011-07-22 18:48:34 --> File loaded: application/views/table/main.php
DEBUG - 2011-07-22 18:48:34 --> Helper loaded: url_helper
DEBUG - 2011-07-22 18:48:34 --> File loaded: application/views/common/header.php
DEBUG - 2011-07-22 18:48:34 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-07-22 18:48:34 --> File loaded: application/views/common/footer.php
DEBUG - 2011-07-22 18:48:34 --> File loaded: application/views/layout/main.php
DEBUG - 2011-07-22 18:48:34 --> Final output sent to browser
DEBUG - 2011-07-22 18:48:34 --> Total execution time: 0.4836
DEBUG - 2011-07-22 19:46:12 --> Config Class Initialized
DEBUG - 2011-07-22 19:46:12 --> Hooks Class Initialized
DEBUG - 2011-07-22 19:46:12 --> Utf8 Class Initialized
DEBUG - 2011-07-22 19:46:12 --> UTF-8 Support Enabled
DEBUG - 2011-07-22 19:46:12 --> URI Class Initialized
DEBUG - 2011-07-22 19:46:12 --> Router Class Initialized
DEBUG - 2011-07-22 19:46:12 --> Output Class Initialized
DEBUG - 2011-07-22 19:46:12 --> Input Class Initialized
DEBUG - 2011-07-22 19:46:12 --> Global POST and COOKIE data sanitized
DEBUG - 2011-07-22 19:46:12 --> Language Class Initialized
DEBUG - 2011-07-22 19:46:12 --> Loader Class Initialized
DEBUG - 2011-07-22 19:46:12 --> Controller Class Initialized
ERROR - 2011-07-22 19:46:12 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-07-22 19:46:12 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-07-22 19:46:12 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-07-22 19:46:12 --> Model Class Initialized
DEBUG - 2011-07-22 19:46:12 --> Model Class Initialized
DEBUG - 2011-07-22 19:46:12 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-07-22 19:46:12 --> Database Driver Class Initialized
DEBUG - 2011-07-22 19:46:12 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-07-22 19:46:12 --> Helper loaded: url_helper
DEBUG - 2011-07-22 19:46:12 --> File loaded: application/views/common/header.php
DEBUG - 2011-07-22 19:46:12 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-07-22 19:46:12 --> File loaded: application/views/common/footer.php
DEBUG - 2011-07-22 19:46:12 --> File loaded: application/views/layout/main.php
DEBUG - 2011-07-22 19:46:12 --> Final output sent to browser
DEBUG - 2011-07-22 19:46:12 --> Total execution time: 0.2927
DEBUG - 2011-07-22 19:46:14 --> Config Class Initialized
DEBUG - 2011-07-22 19:46:14 --> Hooks Class Initialized
DEBUG - 2011-07-22 19:46:14 --> Utf8 Class Initialized
DEBUG - 2011-07-22 19:46:14 --> UTF-8 Support Enabled
DEBUG - 2011-07-22 19:46:14 --> URI Class Initialized
DEBUG - 2011-07-22 19:46:14 --> Router Class Initialized
DEBUG - 2011-07-22 19:46:14 --> Output Class Initialized
DEBUG - 2011-07-22 19:46:14 --> Input Class Initialized
DEBUG - 2011-07-22 19:46:14 --> Global POST and COOKIE data sanitized
DEBUG - 2011-07-22 19:46:14 --> Language Class Initialized
DEBUG - 2011-07-22 19:46:14 --> Loader Class Initialized
DEBUG - 2011-07-22 19:46:14 --> Controller Class Initialized
DEBUG - 2011-07-22 19:46:14 --> Model Class Initialized
DEBUG - 2011-07-22 19:46:15 --> Model Class Initialized
DEBUG - 2011-07-22 19:46:15 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-07-22 19:46:15 --> Database Driver Class Initialized
DEBUG - 2011-07-22 19:46:15 --> Final output sent to browser
DEBUG - 2011-07-22 19:46:15 --> Total execution time: 1.0348
DEBUG - 2011-07-22 20:12:15 --> Config Class Initialized
DEBUG - 2011-07-22 20:12:15 --> Hooks Class Initialized
DEBUG - 2011-07-22 20:12:15 --> Utf8 Class Initialized
DEBUG - 2011-07-22 20:12:15 --> UTF-8 Support Enabled
DEBUG - 2011-07-22 20:12:15 --> URI Class Initialized
DEBUG - 2011-07-22 20:12:15 --> Router Class Initialized
ERROR - 2011-07-22 20:12:15 --> 404 Page Not Found --> robots.txt
DEBUG - 2011-07-22 20:12:57 --> Config Class Initialized
DEBUG - 2011-07-22 20:12:57 --> Hooks Class Initialized
DEBUG - 2011-07-22 20:12:57 --> Utf8 Class Initialized
DEBUG - 2011-07-22 20:12:57 --> UTF-8 Support Enabled
DEBUG - 2011-07-22 20:12:57 --> URI Class Initialized
DEBUG - 2011-07-22 20:12:57 --> Router Class Initialized
DEBUG - 2011-07-22 20:12:57 --> Output Class Initialized
DEBUG - 2011-07-22 20:12:57 --> Input Class Initialized
DEBUG - 2011-07-22 20:12:57 --> Global POST and COOKIE data sanitized
DEBUG - 2011-07-22 20:12:57 --> Language Class Initialized
DEBUG - 2011-07-22 20:12:57 --> Loader Class Initialized
DEBUG - 2011-07-22 20:12:57 --> Controller Class Initialized
DEBUG - 2011-07-22 20:12:57 --> Model Class Initialized
DEBUG - 2011-07-22 20:12:57 --> Model Class Initialized
DEBUG - 2011-07-22 20:12:58 --> Model Class Initialized
DEBUG - 2011-07-22 20:12:58 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-07-22 20:12:58 --> Database Driver Class Initialized
DEBUG - 2011-07-22 20:12:59 --> File loaded: application/views/table/main.php
DEBUG - 2011-07-22 20:12:59 --> Helper loaded: url_helper
DEBUG - 2011-07-22 20:12:59 --> File loaded: application/views/common/header.php
DEBUG - 2011-07-22 20:13:00 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-07-22 20:13:00 --> File loaded: application/views/common/footer.php
DEBUG - 2011-07-22 20:13:00 --> File loaded: application/views/layout/main.php
DEBUG - 2011-07-22 20:13:00 --> Final output sent to browser
DEBUG - 2011-07-22 20:13:00 --> Total execution time: 2.5558
DEBUG - 2011-07-22 21:50:42 --> Config Class Initialized
DEBUG - 2011-07-22 21:50:42 --> Hooks Class Initialized
DEBUG - 2011-07-22 21:50:42 --> Utf8 Class Initialized
DEBUG - 2011-07-22 21:50:42 --> UTF-8 Support Enabled
DEBUG - 2011-07-22 21:50:42 --> URI Class Initialized
DEBUG - 2011-07-22 21:50:42 --> Router Class Initialized
DEBUG - 2011-07-22 21:50:42 --> Output Class Initialized
DEBUG - 2011-07-22 21:50:42 --> Input Class Initialized
DEBUG - 2011-07-22 21:50:42 --> Global POST and COOKIE data sanitized
DEBUG - 2011-07-22 21:50:42 --> Language Class Initialized
DEBUG - 2011-07-22 21:50:42 --> Loader Class Initialized
DEBUG - 2011-07-22 21:50:42 --> Controller Class Initialized
DEBUG - 2011-07-22 21:50:42 --> Model Class Initialized
DEBUG - 2011-07-22 21:50:42 --> Model Class Initialized
DEBUG - 2011-07-22 21:50:42 --> Model Class Initialized
DEBUG - 2011-07-22 21:50:42 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-07-22 21:50:42 --> Database Driver Class Initialized
DEBUG - 2011-07-22 21:50:42 --> File loaded: application/views/table/main.php
DEBUG - 2011-07-22 21:50:42 --> Helper loaded: url_helper
DEBUG - 2011-07-22 21:50:42 --> File loaded: application/views/common/header.php
DEBUG - 2011-07-22 21:50:42 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-07-22 21:50:42 --> File loaded: application/views/common/footer.php
DEBUG - 2011-07-22 21:50:42 --> File loaded: application/views/layout/main.php
DEBUG - 2011-07-22 21:50:42 --> Final output sent to browser
DEBUG - 2011-07-22 21:50:42 --> Total execution time: 0.6495
DEBUG - 2011-07-22 21:50:45 --> Config Class Initialized
DEBUG - 2011-07-22 21:50:45 --> Hooks Class Initialized
DEBUG - 2011-07-22 21:50:45 --> Utf8 Class Initialized
DEBUG - 2011-07-22 21:50:45 --> UTF-8 Support Enabled
DEBUG - 2011-07-22 21:50:45 --> URI Class Initialized
DEBUG - 2011-07-22 21:50:45 --> Router Class Initialized
ERROR - 2011-07-22 21:50:45 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-07-22 23:10:23 --> Config Class Initialized
DEBUG - 2011-07-22 23:10:23 --> Hooks Class Initialized
DEBUG - 2011-07-22 23:10:23 --> Utf8 Class Initialized
DEBUG - 2011-07-22 23:10:23 --> UTF-8 Support Enabled
DEBUG - 2011-07-22 23:10:23 --> URI Class Initialized
DEBUG - 2011-07-22 23:10:23 --> Router Class Initialized
DEBUG - 2011-07-22 23:10:23 --> Output Class Initialized
DEBUG - 2011-07-22 23:10:23 --> Input Class Initialized
DEBUG - 2011-07-22 23:10:23 --> Global POST and COOKIE data sanitized
DEBUG - 2011-07-22 23:10:23 --> Language Class Initialized
DEBUG - 2011-07-22 23:10:23 --> Loader Class Initialized
DEBUG - 2011-07-22 23:10:23 --> Controller Class Initialized
DEBUG - 2011-07-22 23:10:23 --> Model Class Initialized
DEBUG - 2011-07-22 23:10:23 --> Model Class Initialized
DEBUG - 2011-07-22 23:10:23 --> Config Class Initialized
DEBUG - 2011-07-22 23:10:23 --> Model Class Initialized
DEBUG - 2011-07-22 23:10:23 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-07-22 23:10:23 --> Hooks Class Initialized
DEBUG - 2011-07-22 23:10:23 --> Utf8 Class Initialized
DEBUG - 2011-07-22 23:10:23 --> UTF-8 Support Enabled
DEBUG - 2011-07-22 23:10:23 --> URI Class Initialized
DEBUG - 2011-07-22 23:10:23 --> Router Class Initialized
DEBUG - 2011-07-22 23:10:23 --> Output Class Initialized
DEBUG - 2011-07-22 23:10:23 --> Input Class Initialized
DEBUG - 2011-07-22 23:10:23 --> Global POST and COOKIE data sanitized
DEBUG - 2011-07-22 23:10:23 --> Language Class Initialized
DEBUG - 2011-07-22 23:10:23 --> Loader Class Initialized
DEBUG - 2011-07-22 23:10:23 --> Controller Class Initialized
DEBUG - 2011-07-22 23:10:23 --> Model Class Initialized
DEBUG - 2011-07-22 23:10:23 --> Model Class Initialized
DEBUG - 2011-07-22 23:10:23 --> Model Class Initialized
DEBUG - 2011-07-22 23:10:23 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-07-22 23:10:23 --> Database Driver Class Initialized
DEBUG - 2011-07-22 23:10:23 --> Database Driver Class Initialized
DEBUG - 2011-07-22 23:10:24 --> File loaded: application/views/table/main.php
DEBUG - 2011-07-22 23:10:24 --> File loaded: application/views/table/main.php
DEBUG - 2011-07-22 23:10:24 --> Helper loaded: url_helper
DEBUG - 2011-07-22 23:10:24 --> File loaded: application/views/common/header.php
DEBUG - 2011-07-22 23:10:24 --> Helper loaded: url_helper
DEBUG - 2011-07-22 23:10:24 --> File loaded: application/views/common/header.php
DEBUG - 2011-07-22 23:10:24 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-07-22 23:10:24 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-07-22 23:10:24 --> File loaded: application/views/common/footer.php
DEBUG - 2011-07-22 23:10:24 --> File loaded: application/views/layout/main.php
DEBUG - 2011-07-22 23:10:24 --> Final output sent to browser
DEBUG - 2011-07-22 23:10:24 --> Total execution time: 0.8559
DEBUG - 2011-07-22 23:10:24 --> File loaded: application/views/common/footer.php
DEBUG - 2011-07-22 23:10:24 --> File loaded: application/views/layout/main.php
DEBUG - 2011-07-22 23:10:24 --> Final output sent to browser
DEBUG - 2011-07-22 23:10:24 --> Total execution time: 0.6234
DEBUG - 2011-07-22 23:10:25 --> Config Class Initialized
DEBUG - 2011-07-22 23:10:25 --> Hooks Class Initialized
DEBUG - 2011-07-22 23:10:25 --> Utf8 Class Initialized
DEBUG - 2011-07-22 23:10:25 --> UTF-8 Support Enabled
DEBUG - 2011-07-22 23:10:25 --> URI Class Initialized
DEBUG - 2011-07-22 23:10:25 --> Router Class Initialized
ERROR - 2011-07-22 23:10:25 --> 404 Page Not Found --> favicon.ico

<?php  if ( ! defined('BASEPATH')) exit('No direct script access allowed'); ?>

DEBUG - 2011-10-11 01:29:32 --> Config Class Initialized
DEBUG - 2011-10-11 01:29:32 --> Hooks Class Initialized
DEBUG - 2011-10-11 01:29:32 --> Utf8 Class Initialized
DEBUG - 2011-10-11 01:29:32 --> UTF-8 Support Enabled
DEBUG - 2011-10-11 01:29:32 --> URI Class Initialized
DEBUG - 2011-10-11 01:29:32 --> Router Class Initialized
DEBUG - 2011-10-11 01:29:32 --> No URI present. Default controller set.
DEBUG - 2011-10-11 01:29:32 --> Output Class Initialized
DEBUG - 2011-10-11 01:29:32 --> Input Class Initialized
DEBUG - 2011-10-11 01:29:32 --> Global POST and COOKIE data sanitized
DEBUG - 2011-10-11 01:29:32 --> Language Class Initialized
DEBUG - 2011-10-11 01:29:32 --> Loader Class Initialized
DEBUG - 2011-10-11 01:29:32 --> Controller Class Initialized
DEBUG - 2011-10-11 01:29:32 --> File loaded: application/views/splash/main.php
DEBUG - 2011-10-11 01:29:32 --> Helper loaded: url_helper
DEBUG - 2011-10-11 01:29:32 --> File loaded: application/views/common/header.php
DEBUG - 2011-10-11 01:29:32 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-10-11 01:29:32 --> File loaded: application/views/common/footer.php
DEBUG - 2011-10-11 01:29:32 --> File loaded: application/views/layout/main.php
DEBUG - 2011-10-11 01:29:32 --> Final output sent to browser
DEBUG - 2011-10-11 01:29:32 --> Total execution time: 0.2243
DEBUG - 2011-10-11 02:14:22 --> Config Class Initialized
DEBUG - 2011-10-11 02:14:22 --> Hooks Class Initialized
DEBUG - 2011-10-11 02:14:22 --> Utf8 Class Initialized
DEBUG - 2011-10-11 02:14:22 --> UTF-8 Support Enabled
DEBUG - 2011-10-11 02:14:22 --> URI Class Initialized
DEBUG - 2011-10-11 02:14:22 --> Router Class Initialized
DEBUG - 2011-10-11 02:14:22 --> Output Class Initialized
DEBUG - 2011-10-11 02:14:22 --> Input Class Initialized
DEBUG - 2011-10-11 02:14:22 --> Global POST and COOKIE data sanitized
DEBUG - 2011-10-11 02:14:22 --> Language Class Initialized
DEBUG - 2011-10-11 02:14:22 --> Loader Class Initialized
DEBUG - 2011-10-11 02:14:22 --> Controller Class Initialized
DEBUG - 2011-10-11 02:14:22 --> Model Class Initialized
DEBUG - 2011-10-11 02:14:22 --> Model Class Initialized
DEBUG - 2011-10-11 02:14:22 --> Model Class Initialized
DEBUG - 2011-10-11 02:14:22 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-10-11 02:14:23 --> Database Driver Class Initialized
DEBUG - 2011-10-11 02:14:24 --> File loaded: application/views/table/main.php
DEBUG - 2011-10-11 02:14:24 --> Helper loaded: url_helper
DEBUG - 2011-10-11 02:14:24 --> File loaded: application/views/common/header.php
DEBUG - 2011-10-11 02:14:24 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-10-11 02:14:24 --> File loaded: application/views/common/footer.php
DEBUG - 2011-10-11 02:14:24 --> File loaded: application/views/layout/main.php
DEBUG - 2011-10-11 02:14:24 --> Final output sent to browser
DEBUG - 2011-10-11 02:14:24 --> Total execution time: 2.0629
DEBUG - 2011-10-11 02:14:25 --> Config Class Initialized
DEBUG - 2011-10-11 02:14:25 --> Hooks Class Initialized
DEBUG - 2011-10-11 02:14:25 --> Utf8 Class Initialized
DEBUG - 2011-10-11 02:14:25 --> UTF-8 Support Enabled
DEBUG - 2011-10-11 02:14:25 --> URI Class Initialized
DEBUG - 2011-10-11 02:14:25 --> Router Class Initialized
DEBUG - 2011-10-11 02:14:25 --> Output Class Initialized
DEBUG - 2011-10-11 02:14:25 --> Input Class Initialized
DEBUG - 2011-10-11 02:14:25 --> Global POST and COOKIE data sanitized
DEBUG - 2011-10-11 02:14:25 --> Language Class Initialized
DEBUG - 2011-10-11 02:14:25 --> Loader Class Initialized
DEBUG - 2011-10-11 02:14:25 --> Controller Class Initialized
DEBUG - 2011-10-11 02:14:25 --> Model Class Initialized
DEBUG - 2011-10-11 02:14:25 --> Model Class Initialized
DEBUG - 2011-10-11 02:14:25 --> Model Class Initialized
DEBUG - 2011-10-11 02:14:25 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-10-11 02:14:25 --> Database Driver Class Initialized
DEBUG - 2011-10-11 02:14:25 --> File loaded: application/views/table/main.php
DEBUG - 2011-10-11 02:14:25 --> Helper loaded: url_helper
DEBUG - 2011-10-11 02:14:25 --> File loaded: application/views/common/header.php
DEBUG - 2011-10-11 02:14:25 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-10-11 02:14:25 --> File loaded: application/views/common/footer.php
DEBUG - 2011-10-11 02:14:25 --> File loaded: application/views/layout/main.php
DEBUG - 2011-10-11 02:14:25 --> Final output sent to browser
DEBUG - 2011-10-11 02:14:25 --> Total execution time: 0.0576
DEBUG - 2011-10-11 04:32:48 --> Config Class Initialized
DEBUG - 2011-10-11 04:32:48 --> Hooks Class Initialized
DEBUG - 2011-10-11 04:32:48 --> Utf8 Class Initialized
DEBUG - 2011-10-11 04:32:48 --> UTF-8 Support Enabled
DEBUG - 2011-10-11 04:32:48 --> URI Class Initialized
DEBUG - 2011-10-11 04:32:48 --> Router Class Initialized
ERROR - 2011-10-11 04:32:48 --> 404 Page Not Found --> robots.txt
DEBUG - 2011-10-11 04:32:51 --> Config Class Initialized
DEBUG - 2011-10-11 04:32:51 --> Hooks Class Initialized
DEBUG - 2011-10-11 04:32:51 --> Utf8 Class Initialized
DEBUG - 2011-10-11 04:32:51 --> UTF-8 Support Enabled
DEBUG - 2011-10-11 04:32:51 --> URI Class Initialized
DEBUG - 2011-10-11 04:32:51 --> Router Class Initialized
DEBUG - 2011-10-11 04:32:51 --> Output Class Initialized
DEBUG - 2011-10-11 04:32:51 --> Input Class Initialized
DEBUG - 2011-10-11 04:32:51 --> Global POST and COOKIE data sanitized
DEBUG - 2011-10-11 04:32:51 --> Language Class Initialized
DEBUG - 2011-10-11 04:32:51 --> Loader Class Initialized
DEBUG - 2011-10-11 04:32:51 --> Controller Class Initialized
ERROR - 2011-10-11 04:32:51 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-10-11 04:32:51 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-10-11 04:32:51 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-10-11 04:32:51 --> Model Class Initialized
DEBUG - 2011-10-11 04:32:51 --> Model Class Initialized
DEBUG - 2011-10-11 04:32:51 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-10-11 04:32:51 --> Database Driver Class Initialized
DEBUG - 2011-10-11 04:32:51 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-10-11 04:32:51 --> Helper loaded: url_helper
DEBUG - 2011-10-11 04:32:51 --> File loaded: application/views/common/header.php
DEBUG - 2011-10-11 04:32:51 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-10-11 04:32:51 --> File loaded: application/views/common/footer.php
DEBUG - 2011-10-11 04:32:51 --> File loaded: application/views/layout/main.php
DEBUG - 2011-10-11 04:32:52 --> Config Class Initialized
DEBUG - 2011-10-11 04:32:52 --> Hooks Class Initialized
DEBUG - 2011-10-11 04:32:52 --> Utf8 Class Initialized
DEBUG - 2011-10-11 04:32:52 --> UTF-8 Support Enabled
DEBUG - 2011-10-11 04:32:52 --> URI Class Initialized
DEBUG - 2011-10-11 04:32:52 --> Router Class Initialized
DEBUG - 2011-10-11 04:32:52 --> Output Class Initialized
DEBUG - 2011-10-11 04:32:52 --> Input Class Initialized
DEBUG - 2011-10-11 04:32:52 --> Global POST and COOKIE data sanitized
DEBUG - 2011-10-11 04:32:52 --> Language Class Initialized
DEBUG - 2011-10-11 04:32:52 --> Loader Class Initialized
DEBUG - 2011-10-11 04:32:52 --> Controller Class Initialized
ERROR - 2011-10-11 04:32:52 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-10-11 04:32:52 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-10-11 04:32:52 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-10-11 04:32:52 --> Model Class Initialized
DEBUG - 2011-10-11 04:32:52 --> Model Class Initialized
DEBUG - 2011-10-11 04:32:52 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-10-11 04:32:52 --> Database Driver Class Initialized
DEBUG - 2011-10-11 04:32:52 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-10-11 04:32:52 --> Helper loaded: url_helper
DEBUG - 2011-10-11 04:32:52 --> File loaded: application/views/common/header.php
DEBUG - 2011-10-11 04:32:52 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-10-11 04:32:52 --> File loaded: application/views/common/footer.php
DEBUG - 2011-10-11 04:32:52 --> File loaded: application/views/layout/main.php
DEBUG - 2011-10-11 04:32:52 --> Final output sent to browser
DEBUG - 2011-10-11 04:32:52 --> Total execution time: 0.0306
DEBUG - 2011-10-11 05:29:41 --> Config Class Initialized
DEBUG - 2011-10-11 05:29:41 --> Hooks Class Initialized
DEBUG - 2011-10-11 05:29:41 --> Utf8 Class Initialized
DEBUG - 2011-10-11 05:29:41 --> UTF-8 Support Enabled
DEBUG - 2011-10-11 05:29:41 --> URI Class Initialized
DEBUG - 2011-10-11 05:29:41 --> Router Class Initialized
DEBUG - 2011-10-11 05:29:41 --> No URI present. Default controller set.
DEBUG - 2011-10-11 05:29:41 --> Output Class Initialized
DEBUG - 2011-10-11 05:29:41 --> Input Class Initialized
DEBUG - 2011-10-11 05:29:41 --> Global POST and COOKIE data sanitized
DEBUG - 2011-10-11 05:29:41 --> Language Class Initialized
DEBUG - 2011-10-11 05:29:41 --> Loader Class Initialized
DEBUG - 2011-10-11 05:29:41 --> Controller Class Initialized
DEBUG - 2011-10-11 05:29:41 --> File loaded: application/views/splash/main.php
DEBUG - 2011-10-11 05:29:41 --> Helper loaded: url_helper
DEBUG - 2011-10-11 05:29:41 --> File loaded: application/views/common/header.php
DEBUG - 2011-10-11 05:29:41 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-10-11 05:29:41 --> File loaded: application/views/common/footer.php
DEBUG - 2011-10-11 05:29:41 --> File loaded: application/views/layout/main.php
DEBUG - 2011-10-11 05:29:41 --> Final output sent to browser
DEBUG - 2011-10-11 05:29:41 --> Total execution time: 0.1150
DEBUG - 2011-10-11 05:45:34 --> Config Class Initialized
DEBUG - 2011-10-11 05:45:34 --> Hooks Class Initialized
DEBUG - 2011-10-11 05:45:34 --> Utf8 Class Initialized
DEBUG - 2011-10-11 05:45:34 --> UTF-8 Support Enabled
DEBUG - 2011-10-11 05:45:34 --> URI Class Initialized
DEBUG - 2011-10-11 05:45:34 --> Router Class Initialized
ERROR - 2011-10-11 05:45:34 --> 404 Page Not Found --> robots.txt
DEBUG - 2011-10-11 06:18:24 --> Config Class Initialized
DEBUG - 2011-10-11 06:18:24 --> Hooks Class Initialized
DEBUG - 2011-10-11 06:18:24 --> Utf8 Class Initialized
DEBUG - 2011-10-11 06:18:24 --> UTF-8 Support Enabled
DEBUG - 2011-10-11 06:18:24 --> URI Class Initialized
DEBUG - 2011-10-11 06:18:24 --> Router Class Initialized
DEBUG - 2011-10-11 06:18:24 --> Output Class Initialized
DEBUG - 2011-10-11 06:18:24 --> Input Class Initialized
DEBUG - 2011-10-11 06:18:24 --> Global POST and COOKIE data sanitized
DEBUG - 2011-10-11 06:18:24 --> Language Class Initialized
DEBUG - 2011-10-11 06:18:24 --> Loader Class Initialized
DEBUG - 2011-10-11 06:18:24 --> Controller Class Initialized
ERROR - 2011-10-11 06:18:24 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-10-11 06:18:24 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-10-11 06:18:24 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-10-11 06:18:24 --> Model Class Initialized
DEBUG - 2011-10-11 06:18:24 --> Model Class Initialized
DEBUG - 2011-10-11 06:18:24 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-10-11 06:18:24 --> Database Driver Class Initialized
DEBUG - 2011-10-11 06:18:25 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-10-11 06:18:25 --> Helper loaded: url_helper
DEBUG - 2011-10-11 06:18:25 --> File loaded: application/views/common/header.php
DEBUG - 2011-10-11 06:18:25 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-10-11 06:18:25 --> File loaded: application/views/common/footer.php
DEBUG - 2011-10-11 06:18:25 --> File loaded: application/views/layout/main.php
DEBUG - 2011-10-11 06:18:25 --> Final output sent to browser
DEBUG - 2011-10-11 06:18:25 --> Total execution time: 0.7899
DEBUG - 2011-10-11 06:18:27 --> Config Class Initialized
DEBUG - 2011-10-11 06:18:27 --> Hooks Class Initialized
DEBUG - 2011-10-11 06:18:27 --> Utf8 Class Initialized
DEBUG - 2011-10-11 06:18:27 --> UTF-8 Support Enabled
DEBUG - 2011-10-11 06:18:27 --> URI Class Initialized
DEBUG - 2011-10-11 06:18:27 --> Router Class Initialized
DEBUG - 2011-10-11 06:18:27 --> Output Class Initialized
DEBUG - 2011-10-11 06:18:27 --> Input Class Initialized
DEBUG - 2011-10-11 06:18:27 --> Global POST and COOKIE data sanitized
DEBUG - 2011-10-11 06:18:27 --> Language Class Initialized
DEBUG - 2011-10-11 06:18:27 --> Loader Class Initialized
DEBUG - 2011-10-11 06:18:27 --> Controller Class Initialized
DEBUG - 2011-10-11 06:18:27 --> Model Class Initialized
DEBUG - 2011-10-11 06:18:27 --> Model Class Initialized
DEBUG - 2011-10-11 06:18:27 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-10-11 06:18:27 --> Database Driver Class Initialized
DEBUG - 2011-10-11 06:18:28 --> Final output sent to browser
DEBUG - 2011-10-11 06:18:28 --> Total execution time: 0.8130
DEBUG - 2011-10-11 07:28:19 --> Config Class Initialized
DEBUG - 2011-10-11 07:28:19 --> Hooks Class Initialized
DEBUG - 2011-10-11 07:28:19 --> Utf8 Class Initialized
DEBUG - 2011-10-11 07:28:19 --> UTF-8 Support Enabled
DEBUG - 2011-10-11 07:28:19 --> URI Class Initialized
DEBUG - 2011-10-11 07:28:19 --> Router Class Initialized
DEBUG - 2011-10-11 07:28:19 --> Output Class Initialized
DEBUG - 2011-10-11 07:28:19 --> Input Class Initialized
DEBUG - 2011-10-11 07:28:19 --> Global POST and COOKIE data sanitized
DEBUG - 2011-10-11 07:28:19 --> Language Class Initialized
DEBUG - 2011-10-11 07:28:20 --> Loader Class Initialized
DEBUG - 2011-10-11 07:28:20 --> Controller Class Initialized
ERROR - 2011-10-11 07:28:20 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-10-11 07:28:20 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-10-11 07:28:20 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-10-11 07:28:20 --> Model Class Initialized
DEBUG - 2011-10-11 07:28:20 --> Model Class Initialized
DEBUG - 2011-10-11 07:28:20 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-10-11 07:28:20 --> Database Driver Class Initialized
DEBUG - 2011-10-11 07:28:20 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-10-11 07:28:20 --> Helper loaded: url_helper
DEBUG - 2011-10-11 07:28:20 --> File loaded: application/views/common/header.php
DEBUG - 2011-10-11 07:28:20 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-10-11 07:28:20 --> File loaded: application/views/common/footer.php
DEBUG - 2011-10-11 07:28:20 --> File loaded: application/views/layout/main.php
DEBUG - 2011-10-11 07:28:20 --> Final output sent to browser
DEBUG - 2011-10-11 07:28:20 --> Total execution time: 0.6374
DEBUG - 2011-10-11 07:28:22 --> Config Class Initialized
DEBUG - 2011-10-11 07:28:22 --> Hooks Class Initialized
DEBUG - 2011-10-11 07:28:22 --> Utf8 Class Initialized
DEBUG - 2011-10-11 07:28:22 --> UTF-8 Support Enabled
DEBUG - 2011-10-11 07:28:22 --> URI Class Initialized
DEBUG - 2011-10-11 07:28:22 --> Router Class Initialized
DEBUG - 2011-10-11 07:28:22 --> Output Class Initialized
DEBUG - 2011-10-11 07:28:22 --> Input Class Initialized
DEBUG - 2011-10-11 07:28:22 --> Global POST and COOKIE data sanitized
DEBUG - 2011-10-11 07:28:22 --> Language Class Initialized
DEBUG - 2011-10-11 07:28:22 --> Loader Class Initialized
DEBUG - 2011-10-11 07:28:22 --> Controller Class Initialized
DEBUG - 2011-10-11 07:28:23 --> Model Class Initialized
DEBUG - 2011-10-11 07:28:23 --> Model Class Initialized
DEBUG - 2011-10-11 07:28:23 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-10-11 07:28:23 --> Database Driver Class Initialized
DEBUG - 2011-10-11 07:28:24 --> Final output sent to browser
DEBUG - 2011-10-11 07:28:24 --> Total execution time: 1.4399
DEBUG - 2011-10-11 07:28:26 --> Config Class Initialized
DEBUG - 2011-10-11 07:28:26 --> Hooks Class Initialized
DEBUG - 2011-10-11 07:28:26 --> Utf8 Class Initialized
DEBUG - 2011-10-11 07:28:26 --> UTF-8 Support Enabled
DEBUG - 2011-10-11 07:28:26 --> URI Class Initialized
DEBUG - 2011-10-11 07:28:26 --> Router Class Initialized
ERROR - 2011-10-11 07:28:26 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-10-11 07:29:11 --> Config Class Initialized
DEBUG - 2011-10-11 07:29:11 --> Hooks Class Initialized
DEBUG - 2011-10-11 07:29:11 --> Utf8 Class Initialized
DEBUG - 2011-10-11 07:29:11 --> UTF-8 Support Enabled
DEBUG - 2011-10-11 07:29:11 --> URI Class Initialized
DEBUG - 2011-10-11 07:29:11 --> Router Class Initialized
DEBUG - 2011-10-11 07:29:11 --> Output Class Initialized
DEBUG - 2011-10-11 07:29:11 --> Input Class Initialized
DEBUG - 2011-10-11 07:29:11 --> Global POST and COOKIE data sanitized
DEBUG - 2011-10-11 07:29:11 --> Language Class Initialized
DEBUG - 2011-10-11 07:29:11 --> Loader Class Initialized
DEBUG - 2011-10-11 07:29:11 --> Controller Class Initialized
ERROR - 2011-10-11 07:29:11 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-10-11 07:29:11 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-10-11 07:29:11 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-10-11 07:29:11 --> Model Class Initialized
DEBUG - 2011-10-11 07:29:11 --> Model Class Initialized
DEBUG - 2011-10-11 07:29:11 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-10-11 07:29:11 --> Database Driver Class Initialized
DEBUG - 2011-10-11 07:29:11 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-10-11 07:29:11 --> Helper loaded: url_helper
DEBUG - 2011-10-11 07:29:11 --> File loaded: application/views/common/header.php
DEBUG - 2011-10-11 07:29:11 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-10-11 07:29:11 --> File loaded: application/views/common/footer.php
DEBUG - 2011-10-11 07:29:11 --> File loaded: application/views/layout/main.php
DEBUG - 2011-10-11 07:29:11 --> Final output sent to browser
DEBUG - 2011-10-11 07:29:11 --> Total execution time: 0.1725
DEBUG - 2011-10-11 07:29:13 --> Config Class Initialized
DEBUG - 2011-10-11 07:29:13 --> Hooks Class Initialized
DEBUG - 2011-10-11 07:29:13 --> Utf8 Class Initialized
DEBUG - 2011-10-11 07:29:13 --> UTF-8 Support Enabled
DEBUG - 2011-10-11 07:29:13 --> URI Class Initialized
DEBUG - 2011-10-11 07:29:13 --> Router Class Initialized
DEBUG - 2011-10-11 07:29:13 --> Output Class Initialized
DEBUG - 2011-10-11 07:29:13 --> Input Class Initialized
DEBUG - 2011-10-11 07:29:13 --> Global POST and COOKIE data sanitized
DEBUG - 2011-10-11 07:29:13 --> Language Class Initialized
DEBUG - 2011-10-11 07:29:13 --> Loader Class Initialized
DEBUG - 2011-10-11 07:29:13 --> Controller Class Initialized
DEBUG - 2011-10-11 07:29:13 --> Model Class Initialized
DEBUG - 2011-10-11 07:29:13 --> Model Class Initialized
DEBUG - 2011-10-11 07:29:13 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-10-11 07:29:13 --> Database Driver Class Initialized
DEBUG - 2011-10-11 07:29:14 --> Final output sent to browser
DEBUG - 2011-10-11 07:29:14 --> Total execution time: 0.7480
DEBUG - 2011-10-11 07:29:15 --> Config Class Initialized
DEBUG - 2011-10-11 07:29:15 --> Hooks Class Initialized
DEBUG - 2011-10-11 07:29:15 --> Utf8 Class Initialized
DEBUG - 2011-10-11 07:29:15 --> UTF-8 Support Enabled
DEBUG - 2011-10-11 07:29:15 --> URI Class Initialized
DEBUG - 2011-10-11 07:29:15 --> Router Class Initialized
ERROR - 2011-10-11 07:29:15 --> 404 Page Not Found --> robots.txt
DEBUG - 2011-10-11 07:29:15 --> Config Class Initialized
DEBUG - 2011-10-11 07:29:15 --> Hooks Class Initialized
DEBUG - 2011-10-11 07:29:15 --> Utf8 Class Initialized
DEBUG - 2011-10-11 07:29:15 --> UTF-8 Support Enabled
DEBUG - 2011-10-11 07:29:15 --> URI Class Initialized
DEBUG - 2011-10-11 07:29:15 --> Router Class Initialized
ERROR - 2011-10-11 07:29:15 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-10-11 07:29:16 --> Config Class Initialized
DEBUG - 2011-10-11 07:29:16 --> Hooks Class Initialized
DEBUG - 2011-10-11 07:29:16 --> Utf8 Class Initialized
DEBUG - 2011-10-11 07:29:16 --> UTF-8 Support Enabled
DEBUG - 2011-10-11 07:29:16 --> URI Class Initialized
DEBUG - 2011-10-11 07:29:16 --> Router Class Initialized
DEBUG - 2011-10-11 07:29:16 --> Output Class Initialized
DEBUG - 2011-10-11 07:29:16 --> Input Class Initialized
DEBUG - 2011-10-11 07:29:16 --> Global POST and COOKIE data sanitized
DEBUG - 2011-10-11 07:29:16 --> Language Class Initialized
DEBUG - 2011-10-11 07:29:16 --> Loader Class Initialized
DEBUG - 2011-10-11 07:29:16 --> Controller Class Initialized
ERROR - 2011-10-11 07:29:16 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-10-11 07:29:16 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-10-11 07:29:16 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-10-11 07:29:16 --> Model Class Initialized
DEBUG - 2011-10-11 07:29:16 --> Model Class Initialized
DEBUG - 2011-10-11 07:29:16 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-10-11 07:29:16 --> Database Driver Class Initialized
DEBUG - 2011-10-11 07:29:16 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-10-11 07:29:16 --> Helper loaded: url_helper
DEBUG - 2011-10-11 07:29:16 --> File loaded: application/views/common/header.php
DEBUG - 2011-10-11 07:29:16 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-10-11 07:29:16 --> File loaded: application/views/common/footer.php
DEBUG - 2011-10-11 07:29:16 --> File loaded: application/views/layout/main.php
DEBUG - 2011-10-11 07:29:16 --> Final output sent to browser
DEBUG - 2011-10-11 07:29:16 --> Total execution time: 0.1010
DEBUG - 2011-10-11 07:29:52 --> Config Class Initialized
DEBUG - 2011-10-11 07:29:52 --> Hooks Class Initialized
DEBUG - 2011-10-11 07:29:52 --> Utf8 Class Initialized
DEBUG - 2011-10-11 07:29:52 --> UTF-8 Support Enabled
DEBUG - 2011-10-11 07:29:52 --> URI Class Initialized
DEBUG - 2011-10-11 07:29:52 --> Router Class Initialized
DEBUG - 2011-10-11 07:29:52 --> Output Class Initialized
DEBUG - 2011-10-11 07:29:52 --> Input Class Initialized
DEBUG - 2011-10-11 07:29:52 --> Global POST and COOKIE data sanitized
DEBUG - 2011-10-11 07:29:52 --> Language Class Initialized
DEBUG - 2011-10-11 07:29:52 --> Loader Class Initialized
DEBUG - 2011-10-11 07:29:52 --> Controller Class Initialized
ERROR - 2011-10-11 07:29:52 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-10-11 07:29:52 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-10-11 07:29:52 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-10-11 07:29:52 --> Model Class Initialized
DEBUG - 2011-10-11 07:29:52 --> Model Class Initialized
DEBUG - 2011-10-11 07:29:52 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-10-11 07:29:52 --> Database Driver Class Initialized
DEBUG - 2011-10-11 07:29:52 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-10-11 07:29:52 --> Helper loaded: url_helper
DEBUG - 2011-10-11 07:29:52 --> File loaded: application/views/common/header.php
DEBUG - 2011-10-11 07:29:52 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-10-11 07:29:52 --> File loaded: application/views/common/footer.php
DEBUG - 2011-10-11 07:29:52 --> File loaded: application/views/layout/main.php
DEBUG - 2011-10-11 07:29:52 --> Final output sent to browser
DEBUG - 2011-10-11 07:29:52 --> Total execution time: 0.1134
DEBUG - 2011-10-11 07:29:54 --> Config Class Initialized
DEBUG - 2011-10-11 07:29:54 --> Hooks Class Initialized
DEBUG - 2011-10-11 07:29:54 --> Utf8 Class Initialized
DEBUG - 2011-10-11 07:29:54 --> UTF-8 Support Enabled
DEBUG - 2011-10-11 07:29:54 --> URI Class Initialized
DEBUG - 2011-10-11 07:29:54 --> Router Class Initialized
DEBUG - 2011-10-11 07:29:54 --> Output Class Initialized
DEBUG - 2011-10-11 07:29:54 --> Input Class Initialized
DEBUG - 2011-10-11 07:29:54 --> Global POST and COOKIE data sanitized
DEBUG - 2011-10-11 07:29:54 --> Language Class Initialized
DEBUG - 2011-10-11 07:29:54 --> Loader Class Initialized
DEBUG - 2011-10-11 07:29:54 --> Controller Class Initialized
DEBUG - 2011-10-11 07:29:54 --> Model Class Initialized
DEBUG - 2011-10-11 07:29:54 --> Model Class Initialized
DEBUG - 2011-10-11 07:29:54 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-10-11 07:29:54 --> Database Driver Class Initialized
DEBUG - 2011-10-11 07:29:54 --> Final output sent to browser
DEBUG - 2011-10-11 07:29:54 --> Total execution time: 0.6555
DEBUG - 2011-10-11 07:29:56 --> Config Class Initialized
DEBUG - 2011-10-11 07:29:56 --> Hooks Class Initialized
DEBUG - 2011-10-11 07:29:56 --> Utf8 Class Initialized
DEBUG - 2011-10-11 07:29:56 --> UTF-8 Support Enabled
DEBUG - 2011-10-11 07:29:56 --> URI Class Initialized
DEBUG - 2011-10-11 07:29:56 --> Router Class Initialized
ERROR - 2011-10-11 07:29:56 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-10-11 07:30:08 --> Config Class Initialized
DEBUG - 2011-10-11 07:30:08 --> Hooks Class Initialized
DEBUG - 2011-10-11 07:30:08 --> Utf8 Class Initialized
DEBUG - 2011-10-11 07:30:08 --> UTF-8 Support Enabled
DEBUG - 2011-10-11 07:30:08 --> URI Class Initialized
DEBUG - 2011-10-11 07:30:08 --> Router Class Initialized
DEBUG - 2011-10-11 07:30:08 --> Output Class Initialized
DEBUG - 2011-10-11 07:30:08 --> Input Class Initialized
DEBUG - 2011-10-11 07:30:08 --> Global POST and COOKIE data sanitized
DEBUG - 2011-10-11 07:30:08 --> Language Class Initialized
DEBUG - 2011-10-11 07:30:08 --> Loader Class Initialized
DEBUG - 2011-10-11 07:30:08 --> Controller Class Initialized
ERROR - 2011-10-11 07:30:08 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-10-11 07:30:08 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-10-11 07:30:08 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-10-11 07:30:08 --> Model Class Initialized
DEBUG - 2011-10-11 07:30:08 --> Model Class Initialized
DEBUG - 2011-10-11 07:30:08 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-10-11 07:30:08 --> Database Driver Class Initialized
DEBUG - 2011-10-11 07:30:08 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-10-11 07:30:08 --> Helper loaded: url_helper
DEBUG - 2011-10-11 07:30:08 --> File loaded: application/views/common/header.php
DEBUG - 2011-10-11 07:30:08 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-10-11 07:30:08 --> File loaded: application/views/common/footer.php
DEBUG - 2011-10-11 07:30:08 --> File loaded: application/views/layout/main.php
DEBUG - 2011-10-11 07:30:08 --> Final output sent to browser
DEBUG - 2011-10-11 07:30:08 --> Total execution time: 0.0608
DEBUG - 2011-10-11 07:30:10 --> Config Class Initialized
DEBUG - 2011-10-11 07:30:10 --> Hooks Class Initialized
DEBUG - 2011-10-11 07:30:10 --> Utf8 Class Initialized
DEBUG - 2011-10-11 07:30:10 --> UTF-8 Support Enabled
DEBUG - 2011-10-11 07:30:10 --> URI Class Initialized
DEBUG - 2011-10-11 07:30:10 --> Router Class Initialized
DEBUG - 2011-10-11 07:30:10 --> Output Class Initialized
DEBUG - 2011-10-11 07:30:10 --> Input Class Initialized
DEBUG - 2011-10-11 07:30:10 --> Global POST and COOKIE data sanitized
DEBUG - 2011-10-11 07:30:10 --> Language Class Initialized
DEBUG - 2011-10-11 07:30:10 --> Loader Class Initialized
DEBUG - 2011-10-11 07:30:10 --> Controller Class Initialized
DEBUG - 2011-10-11 07:30:10 --> Model Class Initialized
DEBUG - 2011-10-11 07:30:10 --> Model Class Initialized
DEBUG - 2011-10-11 07:30:10 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-10-11 07:30:10 --> Database Driver Class Initialized
DEBUG - 2011-10-11 07:30:10 --> Final output sent to browser
DEBUG - 2011-10-11 07:30:10 --> Total execution time: 0.6803
DEBUG - 2011-10-11 07:30:12 --> Config Class Initialized
DEBUG - 2011-10-11 07:30:12 --> Hooks Class Initialized
DEBUG - 2011-10-11 07:30:12 --> Utf8 Class Initialized
DEBUG - 2011-10-11 07:30:12 --> UTF-8 Support Enabled
DEBUG - 2011-10-11 07:30:12 --> URI Class Initialized
DEBUG - 2011-10-11 07:30:12 --> Router Class Initialized
ERROR - 2011-10-11 07:30:12 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-10-11 07:30:34 --> Config Class Initialized
DEBUG - 2011-10-11 07:30:34 --> Hooks Class Initialized
DEBUG - 2011-10-11 07:30:34 --> Utf8 Class Initialized
DEBUG - 2011-10-11 07:30:34 --> UTF-8 Support Enabled
DEBUG - 2011-10-11 07:30:34 --> URI Class Initialized
DEBUG - 2011-10-11 07:30:34 --> Router Class Initialized
DEBUG - 2011-10-11 07:30:34 --> Output Class Initialized
DEBUG - 2011-10-11 07:30:34 --> Input Class Initialized
DEBUG - 2011-10-11 07:30:34 --> Global POST and COOKIE data sanitized
DEBUG - 2011-10-11 07:30:34 --> Language Class Initialized
DEBUG - 2011-10-11 07:30:34 --> Loader Class Initialized
DEBUG - 2011-10-11 07:30:34 --> Controller Class Initialized
ERROR - 2011-10-11 07:30:34 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-10-11 07:30:34 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-10-11 07:30:34 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-10-11 07:30:34 --> Model Class Initialized
DEBUG - 2011-10-11 07:30:34 --> Model Class Initialized
DEBUG - 2011-10-11 07:30:34 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-10-11 07:30:34 --> Database Driver Class Initialized
DEBUG - 2011-10-11 07:30:34 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-10-11 07:30:34 --> Helper loaded: url_helper
DEBUG - 2011-10-11 07:30:34 --> File loaded: application/views/common/header.php
DEBUG - 2011-10-11 07:30:34 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-10-11 07:30:34 --> File loaded: application/views/common/footer.php
DEBUG - 2011-10-11 07:30:34 --> File loaded: application/views/layout/main.php
DEBUG - 2011-10-11 07:30:34 --> Final output sent to browser
DEBUG - 2011-10-11 07:30:34 --> Total execution time: 0.0303
DEBUG - 2011-10-11 07:30:36 --> Config Class Initialized
DEBUG - 2011-10-11 07:30:36 --> Hooks Class Initialized
DEBUG - 2011-10-11 07:30:36 --> Utf8 Class Initialized
DEBUG - 2011-10-11 07:30:36 --> UTF-8 Support Enabled
DEBUG - 2011-10-11 07:30:36 --> URI Class Initialized
DEBUG - 2011-10-11 07:30:36 --> Router Class Initialized
DEBUG - 2011-10-11 07:30:36 --> Output Class Initialized
DEBUG - 2011-10-11 07:30:36 --> Input Class Initialized
DEBUG - 2011-10-11 07:30:36 --> Global POST and COOKIE data sanitized
DEBUG - 2011-10-11 07:30:36 --> Language Class Initialized
DEBUG - 2011-10-11 07:30:36 --> Loader Class Initialized
DEBUG - 2011-10-11 07:30:36 --> Controller Class Initialized
DEBUG - 2011-10-11 07:30:36 --> Model Class Initialized
DEBUG - 2011-10-11 07:30:36 --> Model Class Initialized
DEBUG - 2011-10-11 07:30:36 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-10-11 07:30:36 --> Database Driver Class Initialized
DEBUG - 2011-10-11 07:30:36 --> Final output sent to browser
DEBUG - 2011-10-11 07:30:36 --> Total execution time: 0.5518
DEBUG - 2011-10-11 07:30:37 --> Config Class Initialized
DEBUG - 2011-10-11 07:30:37 --> Hooks Class Initialized
DEBUG - 2011-10-11 07:30:37 --> Utf8 Class Initialized
DEBUG - 2011-10-11 07:30:37 --> UTF-8 Support Enabled
DEBUG - 2011-10-11 07:30:37 --> URI Class Initialized
DEBUG - 2011-10-11 07:30:37 --> Router Class Initialized
ERROR - 2011-10-11 07:30:37 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-10-11 07:31:02 --> Config Class Initialized
DEBUG - 2011-10-11 07:31:02 --> Hooks Class Initialized
DEBUG - 2011-10-11 07:31:02 --> Utf8 Class Initialized
DEBUG - 2011-10-11 07:31:02 --> UTF-8 Support Enabled
DEBUG - 2011-10-11 07:31:02 --> URI Class Initialized
DEBUG - 2011-10-11 07:31:02 --> Router Class Initialized
DEBUG - 2011-10-11 07:31:02 --> Output Class Initialized
DEBUG - 2011-10-11 07:31:02 --> Input Class Initialized
DEBUG - 2011-10-11 07:31:02 --> Global POST and COOKIE data sanitized
DEBUG - 2011-10-11 07:31:02 --> Language Class Initialized
DEBUG - 2011-10-11 07:31:02 --> Loader Class Initialized
DEBUG - 2011-10-11 07:31:02 --> Controller Class Initialized
ERROR - 2011-10-11 07:31:02 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-10-11 07:31:02 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-10-11 07:31:02 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-10-11 07:31:02 --> Model Class Initialized
DEBUG - 2011-10-11 07:31:02 --> Model Class Initialized
DEBUG - 2011-10-11 07:31:02 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-10-11 07:31:02 --> Database Driver Class Initialized
DEBUG - 2011-10-11 07:31:02 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-10-11 07:31:02 --> Helper loaded: url_helper
DEBUG - 2011-10-11 07:31:02 --> File loaded: application/views/common/header.php
DEBUG - 2011-10-11 07:31:02 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-10-11 07:31:02 --> File loaded: application/views/common/footer.php
DEBUG - 2011-10-11 07:31:02 --> File loaded: application/views/layout/main.php
DEBUG - 2011-10-11 07:31:02 --> Final output sent to browser
DEBUG - 2011-10-11 07:31:02 --> Total execution time: 0.1361
DEBUG - 2011-10-11 07:31:04 --> Config Class Initialized
DEBUG - 2011-10-11 07:31:04 --> Hooks Class Initialized
DEBUG - 2011-10-11 07:31:04 --> Utf8 Class Initialized
DEBUG - 2011-10-11 07:31:04 --> UTF-8 Support Enabled
DEBUG - 2011-10-11 07:31:04 --> URI Class Initialized
DEBUG - 2011-10-11 07:31:04 --> Router Class Initialized
DEBUG - 2011-10-11 07:31:04 --> Output Class Initialized
DEBUG - 2011-10-11 07:31:04 --> Input Class Initialized
DEBUG - 2011-10-11 07:31:04 --> Global POST and COOKIE data sanitized
DEBUG - 2011-10-11 07:31:04 --> Language Class Initialized
DEBUG - 2011-10-11 07:31:04 --> Loader Class Initialized
DEBUG - 2011-10-11 07:31:04 --> Controller Class Initialized
DEBUG - 2011-10-11 07:31:04 --> Model Class Initialized
DEBUG - 2011-10-11 07:31:04 --> Model Class Initialized
DEBUG - 2011-10-11 07:31:04 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-10-11 07:31:04 --> Database Driver Class Initialized
DEBUG - 2011-10-11 07:31:05 --> Final output sent to browser
DEBUG - 2011-10-11 07:31:05 --> Total execution time: 1.3834
DEBUG - 2011-10-11 07:31:07 --> Config Class Initialized
DEBUG - 2011-10-11 07:31:07 --> Hooks Class Initialized
DEBUG - 2011-10-11 07:31:07 --> Utf8 Class Initialized
DEBUG - 2011-10-11 07:31:07 --> UTF-8 Support Enabled
DEBUG - 2011-10-11 07:31:07 --> URI Class Initialized
DEBUG - 2011-10-11 07:31:07 --> Router Class Initialized
ERROR - 2011-10-11 07:31:07 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-10-11 07:31:25 --> Config Class Initialized
DEBUG - 2011-10-11 07:31:25 --> Hooks Class Initialized
DEBUG - 2011-10-11 07:31:25 --> Utf8 Class Initialized
DEBUG - 2011-10-11 07:31:25 --> UTF-8 Support Enabled
DEBUG - 2011-10-11 07:31:25 --> URI Class Initialized
DEBUG - 2011-10-11 07:31:25 --> Router Class Initialized
DEBUG - 2011-10-11 07:31:25 --> Output Class Initialized
DEBUG - 2011-10-11 07:31:25 --> Input Class Initialized
DEBUG - 2011-10-11 07:31:25 --> Global POST and COOKIE data sanitized
DEBUG - 2011-10-11 07:31:25 --> Language Class Initialized
DEBUG - 2011-10-11 07:31:25 --> Loader Class Initialized
DEBUG - 2011-10-11 07:31:25 --> Controller Class Initialized
ERROR - 2011-10-11 07:31:25 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-10-11 07:31:25 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-10-11 07:31:25 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-10-11 07:31:25 --> Model Class Initialized
DEBUG - 2011-10-11 07:31:25 --> Model Class Initialized
DEBUG - 2011-10-11 07:31:25 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-10-11 07:31:25 --> Database Driver Class Initialized
DEBUG - 2011-10-11 07:31:25 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-10-11 07:31:25 --> Helper loaded: url_helper
DEBUG - 2011-10-11 07:31:25 --> File loaded: application/views/common/header.php
DEBUG - 2011-10-11 07:31:25 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-10-11 07:31:25 --> File loaded: application/views/common/footer.php
DEBUG - 2011-10-11 07:31:25 --> File loaded: application/views/layout/main.php
DEBUG - 2011-10-11 07:31:25 --> Final output sent to browser
DEBUG - 2011-10-11 07:31:25 --> Total execution time: 0.0319
DEBUG - 2011-10-11 07:31:26 --> Config Class Initialized
DEBUG - 2011-10-11 07:31:26 --> Hooks Class Initialized
DEBUG - 2011-10-11 07:31:26 --> Utf8 Class Initialized
DEBUG - 2011-10-11 07:31:26 --> UTF-8 Support Enabled
DEBUG - 2011-10-11 07:31:26 --> URI Class Initialized
DEBUG - 2011-10-11 07:31:26 --> Router Class Initialized
DEBUG - 2011-10-11 07:31:26 --> Output Class Initialized
DEBUG - 2011-10-11 07:31:26 --> Input Class Initialized
DEBUG - 2011-10-11 07:31:26 --> Global POST and COOKIE data sanitized
DEBUG - 2011-10-11 07:31:26 --> Language Class Initialized
DEBUG - 2011-10-11 07:31:26 --> Loader Class Initialized
DEBUG - 2011-10-11 07:31:26 --> Controller Class Initialized
DEBUG - 2011-10-11 07:31:26 --> Model Class Initialized
DEBUG - 2011-10-11 07:31:26 --> Model Class Initialized
DEBUG - 2011-10-11 07:31:26 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-10-11 07:31:26 --> Database Driver Class Initialized
DEBUG - 2011-10-11 07:31:26 --> Final output sent to browser
DEBUG - 2011-10-11 07:31:26 --> Total execution time: 0.5527
DEBUG - 2011-10-11 07:31:28 --> Config Class Initialized
DEBUG - 2011-10-11 07:31:28 --> Hooks Class Initialized
DEBUG - 2011-10-11 07:31:28 --> Utf8 Class Initialized
DEBUG - 2011-10-11 07:31:28 --> UTF-8 Support Enabled
DEBUG - 2011-10-11 07:31:28 --> URI Class Initialized
DEBUG - 2011-10-11 07:31:28 --> Router Class Initialized
ERROR - 2011-10-11 07:31:28 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-10-11 07:31:39 --> Config Class Initialized
DEBUG - 2011-10-11 07:31:39 --> Hooks Class Initialized
DEBUG - 2011-10-11 07:31:39 --> Utf8 Class Initialized
DEBUG - 2011-10-11 07:31:39 --> UTF-8 Support Enabled
DEBUG - 2011-10-11 07:31:39 --> URI Class Initialized
DEBUG - 2011-10-11 07:31:39 --> Router Class Initialized
DEBUG - 2011-10-11 07:31:39 --> Output Class Initialized
DEBUG - 2011-10-11 07:31:39 --> Input Class Initialized
DEBUG - 2011-10-11 07:31:39 --> Global POST and COOKIE data sanitized
DEBUG - 2011-10-11 07:31:39 --> Language Class Initialized
DEBUG - 2011-10-11 07:31:39 --> Loader Class Initialized
DEBUG - 2011-10-11 07:31:39 --> Controller Class Initialized
ERROR - 2011-10-11 07:31:39 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-10-11 07:31:39 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-10-11 07:31:39 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-10-11 07:31:39 --> Model Class Initialized
DEBUG - 2011-10-11 07:31:39 --> Model Class Initialized
DEBUG - 2011-10-11 07:31:39 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-10-11 07:31:39 --> Database Driver Class Initialized
DEBUG - 2011-10-11 07:31:39 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-10-11 07:31:39 --> Helper loaded: url_helper
DEBUG - 2011-10-11 07:31:39 --> File loaded: application/views/common/header.php
DEBUG - 2011-10-11 07:31:39 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-10-11 07:31:39 --> File loaded: application/views/common/footer.php
DEBUG - 2011-10-11 07:31:39 --> File loaded: application/views/layout/main.php
DEBUG - 2011-10-11 07:31:39 --> Final output sent to browser
DEBUG - 2011-10-11 07:31:39 --> Total execution time: 0.0999
DEBUG - 2011-10-11 07:31:41 --> Config Class Initialized
DEBUG - 2011-10-11 07:31:41 --> Hooks Class Initialized
DEBUG - 2011-10-11 07:31:41 --> Utf8 Class Initialized
DEBUG - 2011-10-11 07:31:41 --> UTF-8 Support Enabled
DEBUG - 2011-10-11 07:31:41 --> URI Class Initialized
DEBUG - 2011-10-11 07:31:41 --> Router Class Initialized
DEBUG - 2011-10-11 07:31:41 --> Output Class Initialized
DEBUG - 2011-10-11 07:31:41 --> Input Class Initialized
DEBUG - 2011-10-11 07:31:41 --> Global POST and COOKIE data sanitized
DEBUG - 2011-10-11 07:31:41 --> Language Class Initialized
DEBUG - 2011-10-11 07:31:41 --> Loader Class Initialized
DEBUG - 2011-10-11 07:31:41 --> Controller Class Initialized
DEBUG - 2011-10-11 07:31:41 --> Model Class Initialized
DEBUG - 2011-10-11 07:31:41 --> Model Class Initialized
DEBUG - 2011-10-11 07:31:41 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-10-11 07:31:41 --> Database Driver Class Initialized
DEBUG - 2011-10-11 07:31:41 --> Final output sent to browser
DEBUG - 2011-10-11 07:31:41 --> Total execution time: 0.6675
DEBUG - 2011-10-11 07:31:43 --> Config Class Initialized
DEBUG - 2011-10-11 07:31:43 --> Hooks Class Initialized
DEBUG - 2011-10-11 07:31:43 --> Utf8 Class Initialized
DEBUG - 2011-10-11 07:31:43 --> UTF-8 Support Enabled
DEBUG - 2011-10-11 07:31:43 --> URI Class Initialized
DEBUG - 2011-10-11 07:31:43 --> Router Class Initialized
ERROR - 2011-10-11 07:31:43 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-10-11 07:31:54 --> Config Class Initialized
DEBUG - 2011-10-11 07:31:54 --> Hooks Class Initialized
DEBUG - 2011-10-11 07:31:54 --> Utf8 Class Initialized
DEBUG - 2011-10-11 07:31:54 --> UTF-8 Support Enabled
DEBUG - 2011-10-11 07:31:54 --> URI Class Initialized
DEBUG - 2011-10-11 07:31:54 --> Router Class Initialized
DEBUG - 2011-10-11 07:31:54 --> Output Class Initialized
DEBUG - 2011-10-11 07:31:54 --> Input Class Initialized
DEBUG - 2011-10-11 07:31:54 --> Global POST and COOKIE data sanitized
DEBUG - 2011-10-11 07:31:54 --> Language Class Initialized
DEBUG - 2011-10-11 07:31:54 --> Loader Class Initialized
DEBUG - 2011-10-11 07:31:54 --> Controller Class Initialized
ERROR - 2011-10-11 07:31:54 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-10-11 07:31:54 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-10-11 07:31:54 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-10-11 07:31:54 --> Model Class Initialized
DEBUG - 2011-10-11 07:31:54 --> Model Class Initialized
DEBUG - 2011-10-11 07:31:54 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-10-11 07:31:54 --> Database Driver Class Initialized
DEBUG - 2011-10-11 07:31:54 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-10-11 07:31:54 --> Helper loaded: url_helper
DEBUG - 2011-10-11 07:31:54 --> File loaded: application/views/common/header.php
DEBUG - 2011-10-11 07:31:54 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-10-11 07:31:54 --> File loaded: application/views/common/footer.php
DEBUG - 2011-10-11 07:31:54 --> File loaded: application/views/layout/main.php
DEBUG - 2011-10-11 07:31:54 --> Final output sent to browser
DEBUG - 2011-10-11 07:31:54 --> Total execution time: 0.0348
DEBUG - 2011-10-11 07:31:55 --> Config Class Initialized
DEBUG - 2011-10-11 07:31:55 --> Hooks Class Initialized
DEBUG - 2011-10-11 07:31:55 --> Utf8 Class Initialized
DEBUG - 2011-10-11 07:31:55 --> UTF-8 Support Enabled
DEBUG - 2011-10-11 07:31:55 --> URI Class Initialized
DEBUG - 2011-10-11 07:31:55 --> Router Class Initialized
DEBUG - 2011-10-11 07:31:55 --> Output Class Initialized
DEBUG - 2011-10-11 07:31:55 --> Input Class Initialized
DEBUG - 2011-10-11 07:31:55 --> Global POST and COOKIE data sanitized
DEBUG - 2011-10-11 07:31:55 --> Language Class Initialized
DEBUG - 2011-10-11 07:31:55 --> Loader Class Initialized
DEBUG - 2011-10-11 07:31:55 --> Controller Class Initialized
DEBUG - 2011-10-11 07:31:55 --> Model Class Initialized
DEBUG - 2011-10-11 07:31:55 --> Model Class Initialized
DEBUG - 2011-10-11 07:31:55 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-10-11 07:31:55 --> Database Driver Class Initialized
DEBUG - 2011-10-11 07:31:56 --> Final output sent to browser
DEBUG - 2011-10-11 07:31:56 --> Total execution time: 0.6188
DEBUG - 2011-10-11 07:31:57 --> Config Class Initialized
DEBUG - 2011-10-11 07:31:57 --> Hooks Class Initialized
DEBUG - 2011-10-11 07:31:57 --> Utf8 Class Initialized
DEBUG - 2011-10-11 07:31:57 --> UTF-8 Support Enabled
DEBUG - 2011-10-11 07:31:57 --> URI Class Initialized
DEBUG - 2011-10-11 07:31:57 --> Router Class Initialized
ERROR - 2011-10-11 07:31:57 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-10-11 07:32:13 --> Config Class Initialized
DEBUG - 2011-10-11 07:32:13 --> Hooks Class Initialized
DEBUG - 2011-10-11 07:32:13 --> Utf8 Class Initialized
DEBUG - 2011-10-11 07:32:13 --> UTF-8 Support Enabled
DEBUG - 2011-10-11 07:32:13 --> URI Class Initialized
DEBUG - 2011-10-11 07:32:13 --> Router Class Initialized
DEBUG - 2011-10-11 07:32:13 --> Output Class Initialized
DEBUG - 2011-10-11 07:32:13 --> Input Class Initialized
DEBUG - 2011-10-11 07:32:13 --> Global POST and COOKIE data sanitized
DEBUG - 2011-10-11 07:32:13 --> Language Class Initialized
DEBUG - 2011-10-11 07:32:14 --> Loader Class Initialized
DEBUG - 2011-10-11 07:32:14 --> Controller Class Initialized
ERROR - 2011-10-11 07:32:14 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-10-11 07:32:14 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-10-11 07:32:14 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-10-11 07:32:14 --> Model Class Initialized
DEBUG - 2011-10-11 07:32:14 --> Model Class Initialized
DEBUG - 2011-10-11 07:32:14 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-10-11 07:32:14 --> Database Driver Class Initialized
DEBUG - 2011-10-11 07:32:14 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-10-11 07:32:14 --> Helper loaded: url_helper
DEBUG - 2011-10-11 07:32:14 --> File loaded: application/views/common/header.php
DEBUG - 2011-10-11 07:32:14 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-10-11 07:32:14 --> File loaded: application/views/common/footer.php
DEBUG - 2011-10-11 07:32:14 --> File loaded: application/views/layout/main.php
DEBUG - 2011-10-11 07:32:14 --> Final output sent to browser
DEBUG - 2011-10-11 07:32:14 --> Total execution time: 0.0471
DEBUG - 2011-10-11 07:32:15 --> Config Class Initialized
DEBUG - 2011-10-11 07:32:15 --> Hooks Class Initialized
DEBUG - 2011-10-11 07:32:15 --> Utf8 Class Initialized
DEBUG - 2011-10-11 07:32:15 --> UTF-8 Support Enabled
DEBUG - 2011-10-11 07:32:15 --> URI Class Initialized
DEBUG - 2011-10-11 07:32:15 --> Router Class Initialized
DEBUG - 2011-10-11 07:32:15 --> Output Class Initialized
DEBUG - 2011-10-11 07:32:15 --> Input Class Initialized
DEBUG - 2011-10-11 07:32:15 --> Global POST and COOKIE data sanitized
DEBUG - 2011-10-11 07:32:15 --> Language Class Initialized
DEBUG - 2011-10-11 07:32:15 --> Loader Class Initialized
DEBUG - 2011-10-11 07:32:15 --> Controller Class Initialized
DEBUG - 2011-10-11 07:32:15 --> Model Class Initialized
DEBUG - 2011-10-11 07:32:15 --> Model Class Initialized
DEBUG - 2011-10-11 07:32:15 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-10-11 07:32:15 --> Database Driver Class Initialized
DEBUG - 2011-10-11 07:32:16 --> Final output sent to browser
DEBUG - 2011-10-11 07:32:16 --> Total execution time: 0.7395
DEBUG - 2011-10-11 07:32:17 --> Config Class Initialized
DEBUG - 2011-10-11 07:32:17 --> Hooks Class Initialized
DEBUG - 2011-10-11 07:32:17 --> Utf8 Class Initialized
DEBUG - 2011-10-11 07:32:17 --> UTF-8 Support Enabled
DEBUG - 2011-10-11 07:32:17 --> URI Class Initialized
DEBUG - 2011-10-11 07:32:17 --> Router Class Initialized
ERROR - 2011-10-11 07:32:17 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-10-11 07:32:23 --> Config Class Initialized
DEBUG - 2011-10-11 07:32:23 --> Hooks Class Initialized
DEBUG - 2011-10-11 07:32:23 --> Utf8 Class Initialized
DEBUG - 2011-10-11 07:32:23 --> UTF-8 Support Enabled
DEBUG - 2011-10-11 07:32:23 --> URI Class Initialized
DEBUG - 2011-10-11 07:32:23 --> Router Class Initialized
DEBUG - 2011-10-11 07:32:23 --> Output Class Initialized
DEBUG - 2011-10-11 07:32:23 --> Input Class Initialized
DEBUG - 2011-10-11 07:32:23 --> Global POST and COOKIE data sanitized
DEBUG - 2011-10-11 07:32:23 --> Language Class Initialized
DEBUG - 2011-10-11 07:32:23 --> Loader Class Initialized
DEBUG - 2011-10-11 07:32:23 --> Controller Class Initialized
ERROR - 2011-10-11 07:32:23 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-10-11 07:32:23 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-10-11 07:32:23 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-10-11 07:32:23 --> Model Class Initialized
DEBUG - 2011-10-11 07:32:23 --> Model Class Initialized
DEBUG - 2011-10-11 07:32:23 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-10-11 07:32:23 --> Database Driver Class Initialized
DEBUG - 2011-10-11 07:32:23 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-10-11 07:32:23 --> Helper loaded: url_helper
DEBUG - 2011-10-11 07:32:23 --> File loaded: application/views/common/header.php
DEBUG - 2011-10-11 07:32:23 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-10-11 07:32:23 --> File loaded: application/views/common/footer.php
DEBUG - 2011-10-11 07:32:23 --> File loaded: application/views/layout/main.php
DEBUG - 2011-10-11 07:32:23 --> Final output sent to browser
DEBUG - 2011-10-11 07:32:23 --> Total execution time: 0.0392
DEBUG - 2011-10-11 07:32:24 --> Config Class Initialized
DEBUG - 2011-10-11 07:32:24 --> Hooks Class Initialized
DEBUG - 2011-10-11 07:32:24 --> Utf8 Class Initialized
DEBUG - 2011-10-11 07:32:24 --> UTF-8 Support Enabled
DEBUG - 2011-10-11 07:32:24 --> URI Class Initialized
DEBUG - 2011-10-11 07:32:24 --> Router Class Initialized
DEBUG - 2011-10-11 07:32:24 --> Output Class Initialized
DEBUG - 2011-10-11 07:32:24 --> Input Class Initialized
DEBUG - 2011-10-11 07:32:24 --> Global POST and COOKIE data sanitized
DEBUG - 2011-10-11 07:32:24 --> Language Class Initialized
DEBUG - 2011-10-11 07:32:24 --> Loader Class Initialized
DEBUG - 2011-10-11 07:32:24 --> Controller Class Initialized
DEBUG - 2011-10-11 07:32:24 --> Model Class Initialized
DEBUG - 2011-10-11 07:32:24 --> Model Class Initialized
DEBUG - 2011-10-11 07:32:24 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-10-11 07:32:24 --> Database Driver Class Initialized
DEBUG - 2011-10-11 07:32:25 --> Final output sent to browser
DEBUG - 2011-10-11 07:32:25 --> Total execution time: 0.5345
DEBUG - 2011-10-11 07:32:26 --> Config Class Initialized
DEBUG - 2011-10-11 07:32:26 --> Hooks Class Initialized
DEBUG - 2011-10-11 07:32:26 --> Utf8 Class Initialized
DEBUG - 2011-10-11 07:32:26 --> UTF-8 Support Enabled
DEBUG - 2011-10-11 07:32:26 --> URI Class Initialized
DEBUG - 2011-10-11 07:32:26 --> Router Class Initialized
DEBUG - 2011-10-11 07:32:26 --> Output Class Initialized
DEBUG - 2011-10-11 07:32:26 --> Input Class Initialized
DEBUG - 2011-10-11 07:32:26 --> Global POST and COOKIE data sanitized
DEBUG - 2011-10-11 07:32:26 --> Language Class Initialized
DEBUG - 2011-10-11 07:32:26 --> Loader Class Initialized
DEBUG - 2011-10-11 07:32:26 --> Controller Class Initialized
ERROR - 2011-10-11 07:32:26 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-10-11 07:32:26 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-10-11 07:32:26 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-10-11 07:32:26 --> Model Class Initialized
DEBUG - 2011-10-11 07:32:26 --> Model Class Initialized
DEBUG - 2011-10-11 07:32:26 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-10-11 07:32:26 --> Database Driver Class Initialized
DEBUG - 2011-10-11 07:32:26 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-10-11 07:32:26 --> Helper loaded: url_helper
DEBUG - 2011-10-11 07:32:26 --> File loaded: application/views/common/header.php
DEBUG - 2011-10-11 07:32:26 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-10-11 07:32:26 --> File loaded: application/views/common/footer.php
DEBUG - 2011-10-11 07:32:26 --> File loaded: application/views/layout/main.php
DEBUG - 2011-10-11 07:32:26 --> Final output sent to browser
DEBUG - 2011-10-11 07:32:26 --> Total execution time: 0.0325
DEBUG - 2011-10-11 07:32:26 --> Config Class Initialized
DEBUG - 2011-10-11 07:32:26 --> Hooks Class Initialized
DEBUG - 2011-10-11 07:32:26 --> Utf8 Class Initialized
DEBUG - 2011-10-11 07:32:26 --> UTF-8 Support Enabled
DEBUG - 2011-10-11 07:32:26 --> URI Class Initialized
DEBUG - 2011-10-11 07:32:26 --> Router Class Initialized
ERROR - 2011-10-11 07:32:26 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-10-11 07:32:38 --> Config Class Initialized
DEBUG - 2011-10-11 07:32:38 --> Hooks Class Initialized
DEBUG - 2011-10-11 07:32:38 --> Utf8 Class Initialized
DEBUG - 2011-10-11 07:32:38 --> UTF-8 Support Enabled
DEBUG - 2011-10-11 07:32:38 --> URI Class Initialized
DEBUG - 2011-10-11 07:32:38 --> Router Class Initialized
DEBUG - 2011-10-11 07:32:38 --> Output Class Initialized
DEBUG - 2011-10-11 07:32:38 --> Input Class Initialized
DEBUG - 2011-10-11 07:32:38 --> Global POST and COOKIE data sanitized
DEBUG - 2011-10-11 07:32:38 --> Language Class Initialized
DEBUG - 2011-10-11 07:32:38 --> Loader Class Initialized
DEBUG - 2011-10-11 07:32:38 --> Controller Class Initialized
ERROR - 2011-10-11 07:32:38 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-10-11 07:32:38 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-10-11 07:32:38 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-10-11 07:32:38 --> Model Class Initialized
DEBUG - 2011-10-11 07:32:38 --> Model Class Initialized
DEBUG - 2011-10-11 07:32:38 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-10-11 07:32:38 --> Database Driver Class Initialized
DEBUG - 2011-10-11 07:32:38 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-10-11 07:32:38 --> Helper loaded: url_helper
DEBUG - 2011-10-11 07:32:38 --> File loaded: application/views/common/header.php
DEBUG - 2011-10-11 07:32:38 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-10-11 07:32:38 --> File loaded: application/views/common/footer.php
DEBUG - 2011-10-11 07:32:38 --> File loaded: application/views/layout/main.php
DEBUG - 2011-10-11 07:32:38 --> Final output sent to browser
DEBUG - 2011-10-11 07:32:38 --> Total execution time: 0.0685
DEBUG - 2011-10-11 07:32:39 --> Config Class Initialized
DEBUG - 2011-10-11 07:32:39 --> Hooks Class Initialized
DEBUG - 2011-10-11 07:32:39 --> Utf8 Class Initialized
DEBUG - 2011-10-11 07:32:39 --> UTF-8 Support Enabled
DEBUG - 2011-10-11 07:32:39 --> URI Class Initialized
DEBUG - 2011-10-11 07:32:39 --> Router Class Initialized
DEBUG - 2011-10-11 07:32:39 --> Output Class Initialized
DEBUG - 2011-10-11 07:32:39 --> Input Class Initialized
DEBUG - 2011-10-11 07:32:39 --> Global POST and COOKIE data sanitized
DEBUG - 2011-10-11 07:32:39 --> Language Class Initialized
DEBUG - 2011-10-11 07:32:40 --> Loader Class Initialized
DEBUG - 2011-10-11 07:32:40 --> Controller Class Initialized
DEBUG - 2011-10-11 07:32:40 --> Model Class Initialized
DEBUG - 2011-10-11 07:32:40 --> Model Class Initialized
DEBUG - 2011-10-11 07:32:40 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-10-11 07:32:40 --> Database Driver Class Initialized
DEBUG - 2011-10-11 07:32:40 --> Final output sent to browser
DEBUG - 2011-10-11 07:32:40 --> Total execution time: 0.8436
DEBUG - 2011-10-11 07:32:42 --> Config Class Initialized
DEBUG - 2011-10-11 07:32:42 --> Hooks Class Initialized
DEBUG - 2011-10-11 07:32:42 --> Utf8 Class Initialized
DEBUG - 2011-10-11 07:32:42 --> UTF-8 Support Enabled
DEBUG - 2011-10-11 07:32:42 --> URI Class Initialized
DEBUG - 2011-10-11 07:32:42 --> Router Class Initialized
ERROR - 2011-10-11 07:32:42 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-10-11 07:32:52 --> Config Class Initialized
DEBUG - 2011-10-11 07:32:52 --> Hooks Class Initialized
DEBUG - 2011-10-11 07:32:52 --> Utf8 Class Initialized
DEBUG - 2011-10-11 07:32:52 --> UTF-8 Support Enabled
DEBUG - 2011-10-11 07:32:52 --> URI Class Initialized
DEBUG - 2011-10-11 07:32:52 --> Router Class Initialized
DEBUG - 2011-10-11 07:32:52 --> Output Class Initialized
DEBUG - 2011-10-11 07:32:52 --> Input Class Initialized
DEBUG - 2011-10-11 07:32:52 --> Global POST and COOKIE data sanitized
DEBUG - 2011-10-11 07:32:52 --> Language Class Initialized
DEBUG - 2011-10-11 07:32:52 --> Loader Class Initialized
DEBUG - 2011-10-11 07:32:52 --> Controller Class Initialized
ERROR - 2011-10-11 07:32:52 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-10-11 07:32:52 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-10-11 07:32:52 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-10-11 07:32:52 --> Model Class Initialized
DEBUG - 2011-10-11 07:32:52 --> Model Class Initialized
DEBUG - 2011-10-11 07:32:52 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-10-11 07:32:52 --> Database Driver Class Initialized
DEBUG - 2011-10-11 07:32:52 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-10-11 07:32:52 --> Helper loaded: url_helper
DEBUG - 2011-10-11 07:32:52 --> File loaded: application/views/common/header.php
DEBUG - 2011-10-11 07:32:52 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-10-11 07:32:52 --> File loaded: application/views/common/footer.php
DEBUG - 2011-10-11 07:32:52 --> File loaded: application/views/layout/main.php
DEBUG - 2011-10-11 07:32:52 --> Final output sent to browser
DEBUG - 2011-10-11 07:32:52 --> Total execution time: 0.0307
DEBUG - 2011-10-11 07:32:54 --> Config Class Initialized
DEBUG - 2011-10-11 07:32:54 --> Hooks Class Initialized
DEBUG - 2011-10-11 07:32:54 --> Utf8 Class Initialized
DEBUG - 2011-10-11 07:32:54 --> UTF-8 Support Enabled
DEBUG - 2011-10-11 07:32:54 --> URI Class Initialized
DEBUG - 2011-10-11 07:32:54 --> Router Class Initialized
DEBUG - 2011-10-11 07:32:54 --> Output Class Initialized
DEBUG - 2011-10-11 07:32:54 --> Input Class Initialized
DEBUG - 2011-10-11 07:32:54 --> Global POST and COOKIE data sanitized
DEBUG - 2011-10-11 07:32:54 --> Language Class Initialized
DEBUG - 2011-10-11 07:32:54 --> Loader Class Initialized
DEBUG - 2011-10-11 07:32:54 --> Controller Class Initialized
DEBUG - 2011-10-11 07:32:54 --> Model Class Initialized
DEBUG - 2011-10-11 07:32:54 --> Model Class Initialized
DEBUG - 2011-10-11 07:32:54 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-10-11 07:32:54 --> Database Driver Class Initialized
DEBUG - 2011-10-11 07:32:54 --> Final output sent to browser
DEBUG - 2011-10-11 07:32:54 --> Total execution time: 0.6307
DEBUG - 2011-10-11 07:32:55 --> Config Class Initialized
DEBUG - 2011-10-11 07:32:55 --> Hooks Class Initialized
DEBUG - 2011-10-11 07:32:55 --> Utf8 Class Initialized
DEBUG - 2011-10-11 07:32:55 --> UTF-8 Support Enabled
DEBUG - 2011-10-11 07:32:56 --> URI Class Initialized
DEBUG - 2011-10-11 07:32:56 --> Router Class Initialized
ERROR - 2011-10-11 07:32:56 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-10-11 07:33:03 --> Config Class Initialized
DEBUG - 2011-10-11 07:33:03 --> Hooks Class Initialized
DEBUG - 2011-10-11 07:33:03 --> Utf8 Class Initialized
DEBUG - 2011-10-11 07:33:03 --> UTF-8 Support Enabled
DEBUG - 2011-10-11 07:33:03 --> URI Class Initialized
DEBUG - 2011-10-11 07:33:03 --> Router Class Initialized
DEBUG - 2011-10-11 07:33:03 --> Output Class Initialized
DEBUG - 2011-10-11 07:33:03 --> Input Class Initialized
DEBUG - 2011-10-11 07:33:03 --> Global POST and COOKIE data sanitized
DEBUG - 2011-10-11 07:33:03 --> Language Class Initialized
DEBUG - 2011-10-11 07:33:03 --> Loader Class Initialized
DEBUG - 2011-10-11 07:33:03 --> Controller Class Initialized
ERROR - 2011-10-11 07:33:03 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-10-11 07:33:03 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-10-11 07:33:03 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-10-11 07:33:03 --> Model Class Initialized
DEBUG - 2011-10-11 07:33:03 --> Model Class Initialized
DEBUG - 2011-10-11 07:33:03 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-10-11 07:33:03 --> Database Driver Class Initialized
DEBUG - 2011-10-11 07:33:03 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-10-11 07:33:03 --> Helper loaded: url_helper
DEBUG - 2011-10-11 07:33:03 --> File loaded: application/views/common/header.php
DEBUG - 2011-10-11 07:33:03 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-10-11 07:33:03 --> File loaded: application/views/common/footer.php
DEBUG - 2011-10-11 07:33:03 --> File loaded: application/views/layout/main.php
DEBUG - 2011-10-11 07:33:03 --> Final output sent to browser
DEBUG - 2011-10-11 07:33:03 --> Total execution time: 0.0787
DEBUG - 2011-10-11 07:33:04 --> Config Class Initialized
DEBUG - 2011-10-11 07:33:04 --> Hooks Class Initialized
DEBUG - 2011-10-11 07:33:04 --> Utf8 Class Initialized
DEBUG - 2011-10-11 07:33:04 --> UTF-8 Support Enabled
DEBUG - 2011-10-11 07:33:04 --> URI Class Initialized
DEBUG - 2011-10-11 07:33:04 --> Router Class Initialized
DEBUG - 2011-10-11 07:33:04 --> Output Class Initialized
DEBUG - 2011-10-11 07:33:04 --> Input Class Initialized
DEBUG - 2011-10-11 07:33:04 --> Global POST and COOKIE data sanitized
DEBUG - 2011-10-11 07:33:04 --> Language Class Initialized
DEBUG - 2011-10-11 07:33:04 --> Loader Class Initialized
DEBUG - 2011-10-11 07:33:04 --> Controller Class Initialized
DEBUG - 2011-10-11 07:33:04 --> Model Class Initialized
DEBUG - 2011-10-11 07:33:04 --> Model Class Initialized
DEBUG - 2011-10-11 07:33:04 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-10-11 07:33:04 --> Database Driver Class Initialized
DEBUG - 2011-10-11 07:33:05 --> Final output sent to browser
DEBUG - 2011-10-11 07:33:05 --> Total execution time: 0.7979
DEBUG - 2011-10-11 07:33:06 --> Config Class Initialized
DEBUG - 2011-10-11 07:33:06 --> Hooks Class Initialized
DEBUG - 2011-10-11 07:33:06 --> Utf8 Class Initialized
DEBUG - 2011-10-11 07:33:06 --> UTF-8 Support Enabled
DEBUG - 2011-10-11 07:33:06 --> URI Class Initialized
DEBUG - 2011-10-11 07:33:06 --> Router Class Initialized
ERROR - 2011-10-11 07:33:06 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-10-11 07:33:07 --> Config Class Initialized
DEBUG - 2011-10-11 07:33:07 --> Hooks Class Initialized
DEBUG - 2011-10-11 07:33:07 --> Utf8 Class Initialized
DEBUG - 2011-10-11 07:33:07 --> UTF-8 Support Enabled
DEBUG - 2011-10-11 07:33:07 --> URI Class Initialized
DEBUG - 2011-10-11 07:33:07 --> Router Class Initialized
DEBUG - 2011-10-11 07:33:07 --> Output Class Initialized
DEBUG - 2011-10-11 07:33:07 --> Input Class Initialized
DEBUG - 2011-10-11 07:33:07 --> Global POST and COOKIE data sanitized
DEBUG - 2011-10-11 07:33:07 --> Language Class Initialized
DEBUG - 2011-10-11 07:33:07 --> Loader Class Initialized
DEBUG - 2011-10-11 07:33:07 --> Controller Class Initialized
ERROR - 2011-10-11 07:33:07 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-10-11 07:33:07 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-10-11 07:33:07 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-10-11 07:33:07 --> Model Class Initialized
DEBUG - 2011-10-11 07:33:07 --> Model Class Initialized
DEBUG - 2011-10-11 07:33:07 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-10-11 07:33:07 --> Database Driver Class Initialized
DEBUG - 2011-10-11 07:33:07 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-10-11 07:33:07 --> Helper loaded: url_helper
DEBUG - 2011-10-11 07:33:07 --> File loaded: application/views/common/header.php
DEBUG - 2011-10-11 07:33:07 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-10-11 07:33:07 --> File loaded: application/views/common/footer.php
DEBUG - 2011-10-11 07:33:07 --> File loaded: application/views/layout/main.php
DEBUG - 2011-10-11 07:33:07 --> Final output sent to browser
DEBUG - 2011-10-11 07:33:07 --> Total execution time: 0.0466
DEBUG - 2011-10-11 07:33:18 --> Config Class Initialized
DEBUG - 2011-10-11 07:33:18 --> Hooks Class Initialized
DEBUG - 2011-10-11 07:33:18 --> Utf8 Class Initialized
DEBUG - 2011-10-11 07:33:18 --> UTF-8 Support Enabled
DEBUG - 2011-10-11 07:33:18 --> URI Class Initialized
DEBUG - 2011-10-11 07:33:18 --> Router Class Initialized
DEBUG - 2011-10-11 07:33:18 --> Output Class Initialized
DEBUG - 2011-10-11 07:33:18 --> Input Class Initialized
DEBUG - 2011-10-11 07:33:18 --> Global POST and COOKIE data sanitized
DEBUG - 2011-10-11 07:33:18 --> Language Class Initialized
DEBUG - 2011-10-11 07:33:18 --> Loader Class Initialized
DEBUG - 2011-10-11 07:33:18 --> Controller Class Initialized
ERROR - 2011-10-11 07:33:18 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-10-11 07:33:18 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-10-11 07:33:18 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-10-11 07:33:18 --> Model Class Initialized
DEBUG - 2011-10-11 07:33:18 --> Model Class Initialized
DEBUG - 2011-10-11 07:33:18 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-10-11 07:33:18 --> Database Driver Class Initialized
DEBUG - 2011-10-11 07:33:18 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-10-11 07:33:18 --> Helper loaded: url_helper
DEBUG - 2011-10-11 07:33:18 --> File loaded: application/views/common/header.php
DEBUG - 2011-10-11 07:33:18 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-10-11 07:33:18 --> File loaded: application/views/common/footer.php
DEBUG - 2011-10-11 07:33:18 --> File loaded: application/views/layout/main.php
DEBUG - 2011-10-11 07:33:18 --> Final output sent to browser
DEBUG - 2011-10-11 07:33:18 --> Total execution time: 0.0433
DEBUG - 2011-10-11 07:33:19 --> Config Class Initialized
DEBUG - 2011-10-11 07:33:19 --> Hooks Class Initialized
DEBUG - 2011-10-11 07:33:19 --> Utf8 Class Initialized
DEBUG - 2011-10-11 07:33:19 --> UTF-8 Support Enabled
DEBUG - 2011-10-11 07:33:19 --> URI Class Initialized
DEBUG - 2011-10-11 07:33:19 --> Router Class Initialized
DEBUG - 2011-10-11 07:33:19 --> Output Class Initialized
DEBUG - 2011-10-11 07:33:19 --> Input Class Initialized
DEBUG - 2011-10-11 07:33:19 --> Global POST and COOKIE data sanitized
DEBUG - 2011-10-11 07:33:19 --> Language Class Initialized
DEBUG - 2011-10-11 07:33:19 --> Loader Class Initialized
DEBUG - 2011-10-11 07:33:19 --> Controller Class Initialized
DEBUG - 2011-10-11 07:33:19 --> Model Class Initialized
DEBUG - 2011-10-11 07:33:19 --> Model Class Initialized
DEBUG - 2011-10-11 07:33:19 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-10-11 07:33:19 --> Database Driver Class Initialized
DEBUG - 2011-10-11 07:33:20 --> Final output sent to browser
DEBUG - 2011-10-11 07:33:20 --> Total execution time: 0.6340
DEBUG - 2011-10-11 07:33:21 --> Config Class Initialized
DEBUG - 2011-10-11 07:33:21 --> Hooks Class Initialized
DEBUG - 2011-10-11 07:33:21 --> Utf8 Class Initialized
DEBUG - 2011-10-11 07:33:21 --> UTF-8 Support Enabled
DEBUG - 2011-10-11 07:33:21 --> URI Class Initialized
DEBUG - 2011-10-11 07:33:21 --> Router Class Initialized
ERROR - 2011-10-11 07:33:21 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-10-11 07:33:21 --> Config Class Initialized
DEBUG - 2011-10-11 07:33:21 --> Hooks Class Initialized
DEBUG - 2011-10-11 07:33:21 --> Utf8 Class Initialized
DEBUG - 2011-10-11 07:33:21 --> UTF-8 Support Enabled
DEBUG - 2011-10-11 07:33:21 --> URI Class Initialized
DEBUG - 2011-10-11 07:33:21 --> Router Class Initialized
DEBUG - 2011-10-11 07:33:21 --> Output Class Initialized
DEBUG - 2011-10-11 07:33:21 --> Input Class Initialized
DEBUG - 2011-10-11 07:33:21 --> Global POST and COOKIE data sanitized
DEBUG - 2011-10-11 07:33:21 --> Language Class Initialized
DEBUG - 2011-10-11 07:33:21 --> Loader Class Initialized
DEBUG - 2011-10-11 07:33:21 --> Controller Class Initialized
ERROR - 2011-10-11 07:33:21 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-10-11 07:33:21 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-10-11 07:33:21 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-10-11 07:33:21 --> Model Class Initialized
DEBUG - 2011-10-11 07:33:21 --> Model Class Initialized
DEBUG - 2011-10-11 07:33:21 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-10-11 07:33:21 --> Database Driver Class Initialized
DEBUG - 2011-10-11 07:33:21 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-10-11 07:33:21 --> Helper loaded: url_helper
DEBUG - 2011-10-11 07:33:21 --> File loaded: application/views/common/header.php
DEBUG - 2011-10-11 07:33:21 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-10-11 07:33:21 --> File loaded: application/views/common/footer.php
DEBUG - 2011-10-11 07:33:21 --> File loaded: application/views/layout/main.php
DEBUG - 2011-10-11 07:33:21 --> Final output sent to browser
DEBUG - 2011-10-11 07:33:21 --> Total execution time: 0.0345
DEBUG - 2011-10-11 07:33:34 --> Config Class Initialized
DEBUG - 2011-10-11 07:33:34 --> Hooks Class Initialized
DEBUG - 2011-10-11 07:33:34 --> Utf8 Class Initialized
DEBUG - 2011-10-11 07:33:34 --> UTF-8 Support Enabled
DEBUG - 2011-10-11 07:33:34 --> URI Class Initialized
DEBUG - 2011-10-11 07:33:34 --> Router Class Initialized
DEBUG - 2011-10-11 07:33:34 --> Output Class Initialized
DEBUG - 2011-10-11 07:33:34 --> Input Class Initialized
DEBUG - 2011-10-11 07:33:34 --> Global POST and COOKIE data sanitized
DEBUG - 2011-10-11 07:33:34 --> Language Class Initialized
DEBUG - 2011-10-11 07:33:34 --> Loader Class Initialized
DEBUG - 2011-10-11 07:33:34 --> Controller Class Initialized
ERROR - 2011-10-11 07:33:34 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-10-11 07:33:34 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-10-11 07:33:34 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-10-11 07:33:34 --> Model Class Initialized
DEBUG - 2011-10-11 07:33:34 --> Model Class Initialized
DEBUG - 2011-10-11 07:33:34 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-10-11 07:33:34 --> Database Driver Class Initialized
DEBUG - 2011-10-11 07:33:34 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-10-11 07:33:34 --> Helper loaded: url_helper
DEBUG - 2011-10-11 07:33:34 --> File loaded: application/views/common/header.php
DEBUG - 2011-10-11 07:33:34 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-10-11 07:33:34 --> File loaded: application/views/common/footer.php
DEBUG - 2011-10-11 07:33:34 --> File loaded: application/views/layout/main.php
DEBUG - 2011-10-11 07:33:34 --> Final output sent to browser
DEBUG - 2011-10-11 07:33:34 --> Total execution time: 0.0342
DEBUG - 2011-10-11 07:33:35 --> Config Class Initialized
DEBUG - 2011-10-11 07:33:35 --> Hooks Class Initialized
DEBUG - 2011-10-11 07:33:35 --> Utf8 Class Initialized
DEBUG - 2011-10-11 07:33:35 --> UTF-8 Support Enabled
DEBUG - 2011-10-11 07:33:35 --> URI Class Initialized
DEBUG - 2011-10-11 07:33:35 --> Router Class Initialized
DEBUG - 2011-10-11 07:33:35 --> Output Class Initialized
DEBUG - 2011-10-11 07:33:35 --> Input Class Initialized
DEBUG - 2011-10-11 07:33:35 --> Global POST and COOKIE data sanitized
DEBUG - 2011-10-11 07:33:35 --> Language Class Initialized
DEBUG - 2011-10-11 07:33:35 --> Loader Class Initialized
DEBUG - 2011-10-11 07:33:35 --> Controller Class Initialized
DEBUG - 2011-10-11 07:33:35 --> Model Class Initialized
DEBUG - 2011-10-11 07:33:35 --> Model Class Initialized
DEBUG - 2011-10-11 07:33:35 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-10-11 07:33:35 --> Database Driver Class Initialized
DEBUG - 2011-10-11 07:33:36 --> Final output sent to browser
DEBUG - 2011-10-11 07:33:36 --> Total execution time: 0.6213
DEBUG - 2011-10-11 07:33:37 --> Config Class Initialized
DEBUG - 2011-10-11 07:33:37 --> Hooks Class Initialized
DEBUG - 2011-10-11 07:33:37 --> Utf8 Class Initialized
DEBUG - 2011-10-11 07:33:37 --> UTF-8 Support Enabled
DEBUG - 2011-10-11 07:33:37 --> URI Class Initialized
DEBUG - 2011-10-11 07:33:37 --> Router Class Initialized
ERROR - 2011-10-11 07:33:37 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-10-11 07:33:42 --> Config Class Initialized
DEBUG - 2011-10-11 07:33:42 --> Hooks Class Initialized
DEBUG - 2011-10-11 07:33:42 --> Utf8 Class Initialized
DEBUG - 2011-10-11 07:33:42 --> UTF-8 Support Enabled
DEBUG - 2011-10-11 07:33:42 --> URI Class Initialized
DEBUG - 2011-10-11 07:33:42 --> Router Class Initialized
DEBUG - 2011-10-11 07:33:42 --> Output Class Initialized
DEBUG - 2011-10-11 07:33:42 --> Input Class Initialized
DEBUG - 2011-10-11 07:33:42 --> Global POST and COOKIE data sanitized
DEBUG - 2011-10-11 07:33:42 --> Language Class Initialized
DEBUG - 2011-10-11 07:33:42 --> Loader Class Initialized
DEBUG - 2011-10-11 07:33:42 --> Controller Class Initialized
ERROR - 2011-10-11 07:33:42 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-10-11 07:33:42 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-10-11 07:33:42 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-10-11 07:33:42 --> Model Class Initialized
DEBUG - 2011-10-11 07:33:42 --> Model Class Initialized
DEBUG - 2011-10-11 07:33:42 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-10-11 07:33:42 --> Database Driver Class Initialized
DEBUG - 2011-10-11 07:33:42 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-10-11 07:33:42 --> Helper loaded: url_helper
DEBUG - 2011-10-11 07:33:42 --> File loaded: application/views/common/header.php
DEBUG - 2011-10-11 07:33:42 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-10-11 07:33:42 --> File loaded: application/views/common/footer.php
DEBUG - 2011-10-11 07:33:42 --> File loaded: application/views/layout/main.php
DEBUG - 2011-10-11 07:33:42 --> Final output sent to browser
DEBUG - 2011-10-11 07:33:42 --> Total execution time: 0.0516
DEBUG - 2011-10-11 07:33:43 --> Config Class Initialized
DEBUG - 2011-10-11 07:33:43 --> Hooks Class Initialized
DEBUG - 2011-10-11 07:33:43 --> Utf8 Class Initialized
DEBUG - 2011-10-11 07:33:43 --> UTF-8 Support Enabled
DEBUG - 2011-10-11 07:33:43 --> URI Class Initialized
DEBUG - 2011-10-11 07:33:43 --> Router Class Initialized
DEBUG - 2011-10-11 07:33:43 --> Output Class Initialized
DEBUG - 2011-10-11 07:33:43 --> Input Class Initialized
DEBUG - 2011-10-11 07:33:43 --> Global POST and COOKIE data sanitized
DEBUG - 2011-10-11 07:33:43 --> Language Class Initialized
DEBUG - 2011-10-11 07:33:43 --> Loader Class Initialized
DEBUG - 2011-10-11 07:33:43 --> Controller Class Initialized
DEBUG - 2011-10-11 07:33:43 --> Model Class Initialized
DEBUG - 2011-10-11 07:33:43 --> Model Class Initialized
DEBUG - 2011-10-11 07:33:43 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-10-11 07:33:43 --> Database Driver Class Initialized
DEBUG - 2011-10-11 07:33:44 --> Final output sent to browser
DEBUG - 2011-10-11 07:33:44 --> Total execution time: 0.7099
DEBUG - 2011-10-11 07:33:46 --> Config Class Initialized
DEBUG - 2011-10-11 07:33:46 --> Hooks Class Initialized
DEBUG - 2011-10-11 07:33:46 --> Utf8 Class Initialized
DEBUG - 2011-10-11 07:33:46 --> UTF-8 Support Enabled
DEBUG - 2011-10-11 07:33:46 --> URI Class Initialized
DEBUG - 2011-10-11 07:33:46 --> Router Class Initialized
ERROR - 2011-10-11 07:33:46 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-10-11 07:33:51 --> Config Class Initialized
DEBUG - 2011-10-11 07:33:51 --> Hooks Class Initialized
DEBUG - 2011-10-11 07:33:51 --> Utf8 Class Initialized
DEBUG - 2011-10-11 07:33:51 --> UTF-8 Support Enabled
DEBUG - 2011-10-11 07:33:51 --> URI Class Initialized
DEBUG - 2011-10-11 07:33:51 --> Router Class Initialized
DEBUG - 2011-10-11 07:33:51 --> Output Class Initialized
DEBUG - 2011-10-11 07:33:51 --> Input Class Initialized
DEBUG - 2011-10-11 07:33:51 --> Global POST and COOKIE data sanitized
DEBUG - 2011-10-11 07:33:51 --> Language Class Initialized
DEBUG - 2011-10-11 07:33:51 --> Loader Class Initialized
DEBUG - 2011-10-11 07:33:51 --> Controller Class Initialized
ERROR - 2011-10-11 07:33:51 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-10-11 07:33:51 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-10-11 07:33:51 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-10-11 07:33:51 --> Model Class Initialized
DEBUG - 2011-10-11 07:33:51 --> Model Class Initialized
DEBUG - 2011-10-11 07:33:51 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-10-11 07:33:51 --> Database Driver Class Initialized
DEBUG - 2011-10-11 07:33:51 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-10-11 07:33:51 --> Helper loaded: url_helper
DEBUG - 2011-10-11 07:33:51 --> File loaded: application/views/common/header.php
DEBUG - 2011-10-11 07:33:51 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-10-11 07:33:51 --> File loaded: application/views/common/footer.php
DEBUG - 2011-10-11 07:33:51 --> File loaded: application/views/layout/main.php
DEBUG - 2011-10-11 07:33:51 --> Final output sent to browser
DEBUG - 2011-10-11 07:33:51 --> Total execution time: 0.0355
DEBUG - 2011-10-11 07:33:52 --> Config Class Initialized
DEBUG - 2011-10-11 07:33:52 --> Hooks Class Initialized
DEBUG - 2011-10-11 07:33:52 --> Utf8 Class Initialized
DEBUG - 2011-10-11 07:33:52 --> UTF-8 Support Enabled
DEBUG - 2011-10-11 07:33:52 --> URI Class Initialized
DEBUG - 2011-10-11 07:33:52 --> Router Class Initialized
DEBUG - 2011-10-11 07:33:52 --> Output Class Initialized
DEBUG - 2011-10-11 07:33:52 --> Input Class Initialized
DEBUG - 2011-10-11 07:33:52 --> Global POST and COOKIE data sanitized
DEBUG - 2011-10-11 07:33:52 --> Language Class Initialized
DEBUG - 2011-10-11 07:33:52 --> Loader Class Initialized
DEBUG - 2011-10-11 07:33:52 --> Controller Class Initialized
DEBUG - 2011-10-11 07:33:52 --> Model Class Initialized
DEBUG - 2011-10-11 07:33:52 --> Model Class Initialized
DEBUG - 2011-10-11 07:33:52 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-10-11 07:33:52 --> Database Driver Class Initialized
DEBUG - 2011-10-11 07:33:53 --> Final output sent to browser
DEBUG - 2011-10-11 07:33:53 --> Total execution time: 0.7823
DEBUG - 2011-10-11 07:33:54 --> Config Class Initialized
DEBUG - 2011-10-11 07:33:54 --> Hooks Class Initialized
DEBUG - 2011-10-11 07:33:54 --> Utf8 Class Initialized
DEBUG - 2011-10-11 07:33:54 --> UTF-8 Support Enabled
DEBUG - 2011-10-11 07:33:54 --> URI Class Initialized
DEBUG - 2011-10-11 07:33:54 --> Router Class Initialized
ERROR - 2011-10-11 07:33:54 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-10-11 07:34:10 --> Config Class Initialized
DEBUG - 2011-10-11 07:34:10 --> Hooks Class Initialized
DEBUG - 2011-10-11 07:34:10 --> Utf8 Class Initialized
DEBUG - 2011-10-11 07:34:10 --> UTF-8 Support Enabled
DEBUG - 2011-10-11 07:34:10 --> URI Class Initialized
DEBUG - 2011-10-11 07:34:10 --> Router Class Initialized
DEBUG - 2011-10-11 07:34:10 --> Output Class Initialized
DEBUG - 2011-10-11 07:34:10 --> Input Class Initialized
DEBUG - 2011-10-11 07:34:10 --> Global POST and COOKIE data sanitized
DEBUG - 2011-10-11 07:34:10 --> Language Class Initialized
DEBUG - 2011-10-11 07:34:10 --> Loader Class Initialized
DEBUG - 2011-10-11 07:34:10 --> Controller Class Initialized
ERROR - 2011-10-11 07:34:10 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-10-11 07:34:10 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-10-11 07:34:10 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-10-11 07:34:10 --> Model Class Initialized
DEBUG - 2011-10-11 07:34:10 --> Model Class Initialized
DEBUG - 2011-10-11 07:34:10 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-10-11 07:34:10 --> Database Driver Class Initialized
DEBUG - 2011-10-11 07:34:10 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-10-11 07:34:10 --> Helper loaded: url_helper
DEBUG - 2011-10-11 07:34:10 --> File loaded: application/views/common/header.php
DEBUG - 2011-10-11 07:34:10 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-10-11 07:34:10 --> File loaded: application/views/common/footer.php
DEBUG - 2011-10-11 07:34:10 --> File loaded: application/views/layout/main.php
DEBUG - 2011-10-11 07:34:10 --> Final output sent to browser
DEBUG - 2011-10-11 07:34:10 --> Total execution time: 0.0334
DEBUG - 2011-10-11 07:34:12 --> Config Class Initialized
DEBUG - 2011-10-11 07:34:12 --> Hooks Class Initialized
DEBUG - 2011-10-11 07:34:12 --> Utf8 Class Initialized
DEBUG - 2011-10-11 07:34:12 --> UTF-8 Support Enabled
DEBUG - 2011-10-11 07:34:12 --> URI Class Initialized
DEBUG - 2011-10-11 07:34:12 --> Router Class Initialized
DEBUG - 2011-10-11 07:34:12 --> Output Class Initialized
DEBUG - 2011-10-11 07:34:12 --> Input Class Initialized
DEBUG - 2011-10-11 07:34:12 --> Global POST and COOKIE data sanitized
DEBUG - 2011-10-11 07:34:12 --> Language Class Initialized
DEBUG - 2011-10-11 07:34:12 --> Loader Class Initialized
DEBUG - 2011-10-11 07:34:12 --> Controller Class Initialized
DEBUG - 2011-10-11 07:34:12 --> Model Class Initialized
DEBUG - 2011-10-11 07:34:12 --> Model Class Initialized
DEBUG - 2011-10-11 07:34:12 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-10-11 07:34:12 --> Database Driver Class Initialized
DEBUG - 2011-10-11 07:34:13 --> Final output sent to browser
DEBUG - 2011-10-11 07:34:13 --> Total execution time: 0.8415
DEBUG - 2011-10-11 07:34:14 --> Config Class Initialized
DEBUG - 2011-10-11 07:34:14 --> Hooks Class Initialized
DEBUG - 2011-10-11 07:34:14 --> Utf8 Class Initialized
DEBUG - 2011-10-11 07:34:14 --> UTF-8 Support Enabled
DEBUG - 2011-10-11 07:34:14 --> URI Class Initialized
DEBUG - 2011-10-11 07:34:14 --> Router Class Initialized
ERROR - 2011-10-11 07:34:14 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-10-11 07:34:19 --> Config Class Initialized
DEBUG - 2011-10-11 07:34:19 --> Hooks Class Initialized
DEBUG - 2011-10-11 07:34:19 --> Utf8 Class Initialized
DEBUG - 2011-10-11 07:34:19 --> UTF-8 Support Enabled
DEBUG - 2011-10-11 07:34:19 --> URI Class Initialized
DEBUG - 2011-10-11 07:34:19 --> Router Class Initialized
DEBUG - 2011-10-11 07:34:19 --> Output Class Initialized
DEBUG - 2011-10-11 07:34:19 --> Input Class Initialized
DEBUG - 2011-10-11 07:34:19 --> Global POST and COOKIE data sanitized
DEBUG - 2011-10-11 07:34:19 --> Language Class Initialized
DEBUG - 2011-10-11 07:34:19 --> Loader Class Initialized
DEBUG - 2011-10-11 07:34:19 --> Controller Class Initialized
ERROR - 2011-10-11 07:34:19 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-10-11 07:34:19 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-10-11 07:34:19 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-10-11 07:34:19 --> Model Class Initialized
DEBUG - 2011-10-11 07:34:19 --> Model Class Initialized
DEBUG - 2011-10-11 07:34:19 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-10-11 07:34:19 --> Database Driver Class Initialized
DEBUG - 2011-10-11 07:34:19 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-10-11 07:34:19 --> Helper loaded: url_helper
DEBUG - 2011-10-11 07:34:19 --> File loaded: application/views/common/header.php
DEBUG - 2011-10-11 07:34:19 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-10-11 07:34:19 --> File loaded: application/views/common/footer.php
DEBUG - 2011-10-11 07:34:19 --> File loaded: application/views/layout/main.php
DEBUG - 2011-10-11 07:34:19 --> Final output sent to browser
DEBUG - 2011-10-11 07:34:19 --> Total execution time: 0.0515
DEBUG - 2011-10-11 07:34:20 --> Config Class Initialized
DEBUG - 2011-10-11 07:34:20 --> Hooks Class Initialized
DEBUG - 2011-10-11 07:34:20 --> Utf8 Class Initialized
DEBUG - 2011-10-11 07:34:20 --> UTF-8 Support Enabled
DEBUG - 2011-10-11 07:34:20 --> URI Class Initialized
DEBUG - 2011-10-11 07:34:20 --> Router Class Initialized
DEBUG - 2011-10-11 07:34:20 --> Output Class Initialized
DEBUG - 2011-10-11 07:34:20 --> Input Class Initialized
DEBUG - 2011-10-11 07:34:20 --> Global POST and COOKIE data sanitized
DEBUG - 2011-10-11 07:34:20 --> Language Class Initialized
DEBUG - 2011-10-11 07:34:20 --> Loader Class Initialized
DEBUG - 2011-10-11 07:34:20 --> Controller Class Initialized
DEBUG - 2011-10-11 07:34:20 --> Model Class Initialized
DEBUG - 2011-10-11 07:34:20 --> Model Class Initialized
DEBUG - 2011-10-11 07:34:20 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-10-11 07:34:20 --> Database Driver Class Initialized
DEBUG - 2011-10-11 07:34:20 --> Final output sent to browser
DEBUG - 2011-10-11 07:34:20 --> Total execution time: 0.5652
DEBUG - 2011-10-11 07:34:22 --> Config Class Initialized
DEBUG - 2011-10-11 07:34:22 --> Hooks Class Initialized
DEBUG - 2011-10-11 07:34:22 --> Utf8 Class Initialized
DEBUG - 2011-10-11 07:34:22 --> UTF-8 Support Enabled
DEBUG - 2011-10-11 07:34:22 --> URI Class Initialized
DEBUG - 2011-10-11 07:34:22 --> Router Class Initialized
ERROR - 2011-10-11 07:34:22 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-10-11 07:34:46 --> Config Class Initialized
DEBUG - 2011-10-11 07:34:46 --> Hooks Class Initialized
DEBUG - 2011-10-11 07:34:46 --> Utf8 Class Initialized
DEBUG - 2011-10-11 07:34:46 --> UTF-8 Support Enabled
DEBUG - 2011-10-11 07:34:46 --> URI Class Initialized
DEBUG - 2011-10-11 07:34:46 --> Router Class Initialized
DEBUG - 2011-10-11 07:34:46 --> Output Class Initialized
DEBUG - 2011-10-11 07:34:46 --> Input Class Initialized
DEBUG - 2011-10-11 07:34:46 --> Global POST and COOKIE data sanitized
DEBUG - 2011-10-11 07:34:46 --> Language Class Initialized
DEBUG - 2011-10-11 07:34:46 --> Loader Class Initialized
DEBUG - 2011-10-11 07:34:46 --> Controller Class Initialized
ERROR - 2011-10-11 07:34:46 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-10-11 07:34:46 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-10-11 07:34:46 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-10-11 07:34:46 --> Model Class Initialized
DEBUG - 2011-10-11 07:34:46 --> Model Class Initialized
DEBUG - 2011-10-11 07:34:46 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-10-11 07:34:46 --> Database Driver Class Initialized
DEBUG - 2011-10-11 07:34:46 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-10-11 07:34:46 --> Helper loaded: url_helper
DEBUG - 2011-10-11 07:34:46 --> File loaded: application/views/common/header.php
DEBUG - 2011-10-11 07:34:46 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-10-11 07:34:46 --> File loaded: application/views/common/footer.php
DEBUG - 2011-10-11 07:34:46 --> File loaded: application/views/layout/main.php
DEBUG - 2011-10-11 07:34:46 --> Final output sent to browser
DEBUG - 2011-10-11 07:34:46 --> Total execution time: 0.0412
DEBUG - 2011-10-11 07:34:48 --> Config Class Initialized
DEBUG - 2011-10-11 07:34:48 --> Hooks Class Initialized
DEBUG - 2011-10-11 07:34:48 --> Utf8 Class Initialized
DEBUG - 2011-10-11 07:34:48 --> UTF-8 Support Enabled
DEBUG - 2011-10-11 07:34:48 --> URI Class Initialized
DEBUG - 2011-10-11 07:34:48 --> Router Class Initialized
DEBUG - 2011-10-11 07:34:48 --> Output Class Initialized
DEBUG - 2011-10-11 07:34:48 --> Input Class Initialized
DEBUG - 2011-10-11 07:34:48 --> Global POST and COOKIE data sanitized
DEBUG - 2011-10-11 07:34:48 --> Language Class Initialized
DEBUG - 2011-10-11 07:34:48 --> Loader Class Initialized
DEBUG - 2011-10-11 07:34:48 --> Controller Class Initialized
DEBUG - 2011-10-11 07:34:48 --> Model Class Initialized
DEBUG - 2011-10-11 07:34:48 --> Model Class Initialized
DEBUG - 2011-10-11 07:34:48 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-10-11 07:34:48 --> Database Driver Class Initialized
DEBUG - 2011-10-11 07:34:48 --> Config Class Initialized
DEBUG - 2011-10-11 07:34:48 --> Hooks Class Initialized
DEBUG - 2011-10-11 07:34:48 --> Utf8 Class Initialized
DEBUG - 2011-10-11 07:34:48 --> UTF-8 Support Enabled
DEBUG - 2011-10-11 07:34:48 --> URI Class Initialized
DEBUG - 2011-10-11 07:34:48 --> Router Class Initialized
DEBUG - 2011-10-11 07:34:48 --> Output Class Initialized
DEBUG - 2011-10-11 07:34:48 --> Input Class Initialized
DEBUG - 2011-10-11 07:34:48 --> Global POST and COOKIE data sanitized
DEBUG - 2011-10-11 07:34:48 --> Language Class Initialized
DEBUG - 2011-10-11 07:34:48 --> Loader Class Initialized
DEBUG - 2011-10-11 07:34:48 --> Controller Class Initialized
ERROR - 2011-10-11 07:34:48 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-10-11 07:34:48 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-10-11 07:34:48 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-10-11 07:34:48 --> Model Class Initialized
DEBUG - 2011-10-11 07:34:48 --> Model Class Initialized
DEBUG - 2011-10-11 07:34:48 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-10-11 07:34:48 --> Database Driver Class Initialized
DEBUG - 2011-10-11 07:34:48 --> Final output sent to browser
DEBUG - 2011-10-11 07:34:48 --> Total execution time: 0.7166
DEBUG - 2011-10-11 07:34:48 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-10-11 07:34:48 --> Helper loaded: url_helper
DEBUG - 2011-10-11 07:34:48 --> File loaded: application/views/common/header.php
DEBUG - 2011-10-11 07:34:48 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-10-11 07:34:48 --> File loaded: application/views/common/footer.php
DEBUG - 2011-10-11 07:34:48 --> File loaded: application/views/layout/main.php
DEBUG - 2011-10-11 07:34:48 --> Final output sent to browser
DEBUG - 2011-10-11 07:34:48 --> Total execution time: 0.1719
DEBUG - 2011-10-11 07:34:50 --> Config Class Initialized
DEBUG - 2011-10-11 07:34:50 --> Hooks Class Initialized
DEBUG - 2011-10-11 07:34:50 --> Utf8 Class Initialized
DEBUG - 2011-10-11 07:34:50 --> UTF-8 Support Enabled
DEBUG - 2011-10-11 07:34:50 --> URI Class Initialized
DEBUG - 2011-10-11 07:34:50 --> Router Class Initialized
ERROR - 2011-10-11 07:34:50 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-10-11 07:35:03 --> Config Class Initialized
DEBUG - 2011-10-11 07:35:03 --> Hooks Class Initialized
DEBUG - 2011-10-11 07:35:03 --> Utf8 Class Initialized
DEBUG - 2011-10-11 07:35:03 --> UTF-8 Support Enabled
DEBUG - 2011-10-11 07:35:03 --> URI Class Initialized
DEBUG - 2011-10-11 07:35:03 --> Router Class Initialized
DEBUG - 2011-10-11 07:35:03 --> Output Class Initialized
DEBUG - 2011-10-11 07:35:03 --> Input Class Initialized
DEBUG - 2011-10-11 07:35:03 --> Global POST and COOKIE data sanitized
DEBUG - 2011-10-11 07:35:03 --> Language Class Initialized
DEBUG - 2011-10-11 07:35:03 --> Loader Class Initialized
DEBUG - 2011-10-11 07:35:03 --> Controller Class Initialized
ERROR - 2011-10-11 07:35:03 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-10-11 07:35:03 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-10-11 07:35:03 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-10-11 07:35:03 --> Model Class Initialized
DEBUG - 2011-10-11 07:35:03 --> Model Class Initialized
DEBUG - 2011-10-11 07:35:03 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-10-11 07:35:03 --> Database Driver Class Initialized
DEBUG - 2011-10-11 07:35:03 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-10-11 07:35:03 --> Helper loaded: url_helper
DEBUG - 2011-10-11 07:35:03 --> File loaded: application/views/common/header.php
DEBUG - 2011-10-11 07:35:03 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-10-11 07:35:03 --> File loaded: application/views/common/footer.php
DEBUG - 2011-10-11 07:35:03 --> File loaded: application/views/layout/main.php
DEBUG - 2011-10-11 07:35:03 --> Final output sent to browser
DEBUG - 2011-10-11 07:35:03 --> Total execution time: 0.3427
DEBUG - 2011-10-11 07:35:05 --> Config Class Initialized
DEBUG - 2011-10-11 07:35:05 --> Hooks Class Initialized
DEBUG - 2011-10-11 07:35:05 --> Utf8 Class Initialized
DEBUG - 2011-10-11 07:35:05 --> UTF-8 Support Enabled
DEBUG - 2011-10-11 07:35:05 --> URI Class Initialized
DEBUG - 2011-10-11 07:35:05 --> Router Class Initialized
DEBUG - 2011-10-11 07:35:05 --> Output Class Initialized
DEBUG - 2011-10-11 07:35:05 --> Input Class Initialized
DEBUG - 2011-10-11 07:35:05 --> Global POST and COOKIE data sanitized
DEBUG - 2011-10-11 07:35:05 --> Language Class Initialized
DEBUG - 2011-10-11 07:35:05 --> Loader Class Initialized
DEBUG - 2011-10-11 07:35:05 --> Controller Class Initialized
DEBUG - 2011-10-11 07:35:05 --> Model Class Initialized
DEBUG - 2011-10-11 07:35:05 --> Model Class Initialized
DEBUG - 2011-10-11 07:35:05 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-10-11 07:35:05 --> Database Driver Class Initialized
DEBUG - 2011-10-11 07:35:06 --> Final output sent to browser
DEBUG - 2011-10-11 07:35:06 --> Total execution time: 0.6737
DEBUG - 2011-10-11 07:35:06 --> Config Class Initialized
DEBUG - 2011-10-11 07:35:06 --> Hooks Class Initialized
DEBUG - 2011-10-11 07:35:06 --> Utf8 Class Initialized
DEBUG - 2011-10-11 07:35:06 --> UTF-8 Support Enabled
DEBUG - 2011-10-11 07:35:06 --> URI Class Initialized
DEBUG - 2011-10-11 07:35:06 --> Router Class Initialized
DEBUG - 2011-10-11 07:35:06 --> Output Class Initialized
DEBUG - 2011-10-11 07:35:06 --> Input Class Initialized
DEBUG - 2011-10-11 07:35:06 --> Global POST and COOKIE data sanitized
DEBUG - 2011-10-11 07:35:06 --> Language Class Initialized
DEBUG - 2011-10-11 07:35:06 --> Loader Class Initialized
DEBUG - 2011-10-11 07:35:06 --> Controller Class Initialized
ERROR - 2011-10-11 07:35:06 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-10-11 07:35:06 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-10-11 07:35:06 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-10-11 07:35:06 --> Model Class Initialized
DEBUG - 2011-10-11 07:35:06 --> Model Class Initialized
DEBUG - 2011-10-11 07:35:06 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-10-11 07:35:06 --> Database Driver Class Initialized
DEBUG - 2011-10-11 07:35:06 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-10-11 07:35:06 --> Helper loaded: url_helper
DEBUG - 2011-10-11 07:35:06 --> File loaded: application/views/common/header.php
DEBUG - 2011-10-11 07:35:06 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-10-11 07:35:06 --> File loaded: application/views/common/footer.php
DEBUG - 2011-10-11 07:35:06 --> File loaded: application/views/layout/main.php
DEBUG - 2011-10-11 07:35:06 --> Final output sent to browser
DEBUG - 2011-10-11 07:35:06 --> Total execution time: 0.0333
DEBUG - 2011-10-11 07:35:07 --> Config Class Initialized
DEBUG - 2011-10-11 07:35:07 --> Hooks Class Initialized
DEBUG - 2011-10-11 07:35:07 --> Utf8 Class Initialized
DEBUG - 2011-10-11 07:35:07 --> UTF-8 Support Enabled
DEBUG - 2011-10-11 07:35:07 --> URI Class Initialized
DEBUG - 2011-10-11 07:35:07 --> Router Class Initialized
ERROR - 2011-10-11 07:35:07 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-10-11 07:35:11 --> Config Class Initialized
DEBUG - 2011-10-11 07:35:11 --> Hooks Class Initialized
DEBUG - 2011-10-11 07:35:11 --> Utf8 Class Initialized
DEBUG - 2011-10-11 07:35:11 --> UTF-8 Support Enabled
DEBUG - 2011-10-11 07:35:11 --> URI Class Initialized
DEBUG - 2011-10-11 07:35:11 --> Router Class Initialized
DEBUG - 2011-10-11 07:35:11 --> Output Class Initialized
DEBUG - 2011-10-11 07:35:11 --> Input Class Initialized
DEBUG - 2011-10-11 07:35:11 --> Global POST and COOKIE data sanitized
DEBUG - 2011-10-11 07:35:11 --> Language Class Initialized
DEBUG - 2011-10-11 07:35:11 --> Loader Class Initialized
DEBUG - 2011-10-11 07:35:11 --> Controller Class Initialized
ERROR - 2011-10-11 07:35:11 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-10-11 07:35:11 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-10-11 07:35:11 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-10-11 07:35:11 --> Model Class Initialized
DEBUG - 2011-10-11 07:35:11 --> Model Class Initialized
DEBUG - 2011-10-11 07:35:11 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-10-11 07:35:11 --> Database Driver Class Initialized
DEBUG - 2011-10-11 07:35:11 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-10-11 07:35:11 --> Helper loaded: url_helper
DEBUG - 2011-10-11 07:35:11 --> File loaded: application/views/common/header.php
DEBUG - 2011-10-11 07:35:11 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-10-11 07:35:11 --> File loaded: application/views/common/footer.php
DEBUG - 2011-10-11 07:35:11 --> File loaded: application/views/layout/main.php
DEBUG - 2011-10-11 07:35:11 --> Final output sent to browser
DEBUG - 2011-10-11 07:35:11 --> Total execution time: 0.2410
DEBUG - 2011-10-11 07:35:12 --> Config Class Initialized
DEBUG - 2011-10-11 07:35:12 --> Hooks Class Initialized
DEBUG - 2011-10-11 07:35:12 --> Utf8 Class Initialized
DEBUG - 2011-10-11 07:35:12 --> UTF-8 Support Enabled
DEBUG - 2011-10-11 07:35:12 --> URI Class Initialized
DEBUG - 2011-10-11 07:35:12 --> Router Class Initialized
DEBUG - 2011-10-11 07:35:12 --> Output Class Initialized
DEBUG - 2011-10-11 07:35:12 --> Input Class Initialized
DEBUG - 2011-10-11 07:35:12 --> Global POST and COOKIE data sanitized
DEBUG - 2011-10-11 07:35:12 --> Language Class Initialized
DEBUG - 2011-10-11 07:35:12 --> Loader Class Initialized
DEBUG - 2011-10-11 07:35:12 --> Controller Class Initialized
DEBUG - 2011-10-11 07:35:12 --> Model Class Initialized
DEBUG - 2011-10-11 07:35:12 --> Model Class Initialized
DEBUG - 2011-10-11 07:35:12 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-10-11 07:35:12 --> Database Driver Class Initialized
DEBUG - 2011-10-11 07:35:13 --> Final output sent to browser
DEBUG - 2011-10-11 07:35:13 --> Total execution time: 0.6671
DEBUG - 2011-10-11 07:35:15 --> Config Class Initialized
DEBUG - 2011-10-11 07:35:15 --> Hooks Class Initialized
DEBUG - 2011-10-11 07:35:15 --> Utf8 Class Initialized
DEBUG - 2011-10-11 07:35:15 --> UTF-8 Support Enabled
DEBUG - 2011-10-11 07:35:15 --> URI Class Initialized
DEBUG - 2011-10-11 07:35:15 --> Router Class Initialized
ERROR - 2011-10-11 07:35:15 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-10-11 07:35:25 --> Config Class Initialized
DEBUG - 2011-10-11 07:35:25 --> Hooks Class Initialized
DEBUG - 2011-10-11 07:35:25 --> Utf8 Class Initialized
DEBUG - 2011-10-11 07:35:25 --> UTF-8 Support Enabled
DEBUG - 2011-10-11 07:35:25 --> URI Class Initialized
DEBUG - 2011-10-11 07:35:25 --> Router Class Initialized
DEBUG - 2011-10-11 07:35:25 --> Output Class Initialized
DEBUG - 2011-10-11 07:35:25 --> Input Class Initialized
DEBUG - 2011-10-11 07:35:25 --> Global POST and COOKIE data sanitized
DEBUG - 2011-10-11 07:35:25 --> Language Class Initialized
DEBUG - 2011-10-11 07:35:25 --> Loader Class Initialized
DEBUG - 2011-10-11 07:35:25 --> Controller Class Initialized
ERROR - 2011-10-11 07:35:25 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-10-11 07:35:25 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-10-11 07:35:25 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-10-11 07:35:25 --> Model Class Initialized
DEBUG - 2011-10-11 07:35:25 --> Model Class Initialized
DEBUG - 2011-10-11 07:35:25 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-10-11 07:35:25 --> Database Driver Class Initialized
DEBUG - 2011-10-11 07:35:25 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-10-11 07:35:25 --> Helper loaded: url_helper
DEBUG - 2011-10-11 07:35:25 --> File loaded: application/views/common/header.php
DEBUG - 2011-10-11 07:35:25 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-10-11 07:35:25 --> File loaded: application/views/common/footer.php
DEBUG - 2011-10-11 07:35:25 --> File loaded: application/views/layout/main.php
DEBUG - 2011-10-11 07:35:25 --> Final output sent to browser
DEBUG - 2011-10-11 07:35:25 --> Total execution time: 0.0300
DEBUG - 2011-10-11 07:35:26 --> Config Class Initialized
DEBUG - 2011-10-11 07:35:26 --> Hooks Class Initialized
DEBUG - 2011-10-11 07:35:26 --> Utf8 Class Initialized
DEBUG - 2011-10-11 07:35:26 --> UTF-8 Support Enabled
DEBUG - 2011-10-11 07:35:26 --> URI Class Initialized
DEBUG - 2011-10-11 07:35:26 --> Router Class Initialized
DEBUG - 2011-10-11 07:35:26 --> Output Class Initialized
DEBUG - 2011-10-11 07:35:26 --> Input Class Initialized
DEBUG - 2011-10-11 07:35:26 --> Global POST and COOKIE data sanitized
DEBUG - 2011-10-11 07:35:26 --> Language Class Initialized
DEBUG - 2011-10-11 07:35:26 --> Loader Class Initialized
DEBUG - 2011-10-11 07:35:26 --> Controller Class Initialized
DEBUG - 2011-10-11 07:35:26 --> Model Class Initialized
DEBUG - 2011-10-11 07:35:26 --> Model Class Initialized
DEBUG - 2011-10-11 07:35:26 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-10-11 07:35:26 --> Database Driver Class Initialized
DEBUG - 2011-10-11 07:35:26 --> Final output sent to browser
DEBUG - 2011-10-11 07:35:26 --> Total execution time: 0.4624
DEBUG - 2011-10-11 07:35:28 --> Config Class Initialized
DEBUG - 2011-10-11 07:35:28 --> Hooks Class Initialized
DEBUG - 2011-10-11 07:35:28 --> Utf8 Class Initialized
DEBUG - 2011-10-11 07:35:28 --> UTF-8 Support Enabled
DEBUG - 2011-10-11 07:35:28 --> URI Class Initialized
DEBUG - 2011-10-11 07:35:28 --> Router Class Initialized
ERROR - 2011-10-11 07:35:28 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-10-11 08:14:22 --> Config Class Initialized
DEBUG - 2011-10-11 08:14:22 --> Hooks Class Initialized
DEBUG - 2011-10-11 08:14:22 --> Utf8 Class Initialized
DEBUG - 2011-10-11 08:14:22 --> UTF-8 Support Enabled
DEBUG - 2011-10-11 08:14:22 --> URI Class Initialized
DEBUG - 2011-10-11 08:14:22 --> Router Class Initialized
DEBUG - 2011-10-11 08:14:22 --> Output Class Initialized
DEBUG - 2011-10-11 08:14:22 --> Input Class Initialized
DEBUG - 2011-10-11 08:14:22 --> Global POST and COOKIE data sanitized
DEBUG - 2011-10-11 08:14:22 --> Language Class Initialized
DEBUG - 2011-10-11 08:14:22 --> Loader Class Initialized
DEBUG - 2011-10-11 08:14:22 --> Controller Class Initialized
ERROR - 2011-10-11 08:14:22 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-10-11 08:14:22 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-10-11 08:14:22 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-10-11 08:14:22 --> Model Class Initialized
DEBUG - 2011-10-11 08:14:22 --> Model Class Initialized
DEBUG - 2011-10-11 08:14:22 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-10-11 08:14:22 --> Database Driver Class Initialized
DEBUG - 2011-10-11 08:14:23 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-10-11 08:14:23 --> Helper loaded: url_helper
DEBUG - 2011-10-11 08:14:23 --> File loaded: application/views/common/header.php
DEBUG - 2011-10-11 08:14:23 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-10-11 08:14:23 --> File loaded: application/views/common/footer.php
DEBUG - 2011-10-11 08:14:23 --> File loaded: application/views/layout/main.php
DEBUG - 2011-10-11 08:14:23 --> Final output sent to browser
DEBUG - 2011-10-11 08:14:23 --> Total execution time: 1.6641
DEBUG - 2011-10-11 08:18:09 --> Config Class Initialized
DEBUG - 2011-10-11 08:18:09 --> Hooks Class Initialized
DEBUG - 2011-10-11 08:18:09 --> Utf8 Class Initialized
DEBUG - 2011-10-11 08:18:09 --> UTF-8 Support Enabled
DEBUG - 2011-10-11 08:18:09 --> URI Class Initialized
DEBUG - 2011-10-11 08:18:09 --> Router Class Initialized
DEBUG - 2011-10-11 08:18:09 --> Output Class Initialized
DEBUG - 2011-10-11 08:18:09 --> Input Class Initialized
DEBUG - 2011-10-11 08:18:09 --> Global POST and COOKIE data sanitized
DEBUG - 2011-10-11 08:18:09 --> Language Class Initialized
DEBUG - 2011-10-11 08:18:09 --> Loader Class Initialized
DEBUG - 2011-10-11 08:18:09 --> Controller Class Initialized
DEBUG - 2011-10-11 08:18:09 --> Model Class Initialized
DEBUG - 2011-10-11 08:18:09 --> Model Class Initialized
DEBUG - 2011-10-11 08:18:09 --> Model Class Initialized
DEBUG - 2011-10-11 08:18:09 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-10-11 08:18:09 --> Database Driver Class Initialized
DEBUG - 2011-10-11 08:18:09 --> File loaded: application/views/table/main.php
DEBUG - 2011-10-11 08:18:09 --> Helper loaded: url_helper
DEBUG - 2011-10-11 08:18:09 --> File loaded: application/views/common/header.php
DEBUG - 2011-10-11 08:18:09 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-10-11 08:18:09 --> File loaded: application/views/common/footer.php
DEBUG - 2011-10-11 08:18:09 --> File loaded: application/views/layout/main.php
DEBUG - 2011-10-11 08:18:09 --> Final output sent to browser
DEBUG - 2011-10-11 08:18:09 --> Total execution time: 0.5227
DEBUG - 2011-10-11 09:21:21 --> Config Class Initialized
DEBUG - 2011-10-11 09:21:21 --> Hooks Class Initialized
DEBUG - 2011-10-11 09:21:21 --> Utf8 Class Initialized
DEBUG - 2011-10-11 09:21:21 --> UTF-8 Support Enabled
DEBUG - 2011-10-11 09:21:21 --> URI Class Initialized
DEBUG - 2011-10-11 09:21:21 --> Router Class Initialized
DEBUG - 2011-10-11 09:21:21 --> Output Class Initialized
DEBUG - 2011-10-11 09:21:21 --> Input Class Initialized
DEBUG - 2011-10-11 09:21:21 --> Global POST and COOKIE data sanitized
DEBUG - 2011-10-11 09:21:21 --> Language Class Initialized
DEBUG - 2011-10-11 09:21:21 --> Loader Class Initialized
DEBUG - 2011-10-11 09:21:21 --> Controller Class Initialized
ERROR - 2011-10-11 09:21:21 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-10-11 09:21:21 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-10-11 09:21:21 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-10-11 09:21:21 --> Model Class Initialized
DEBUG - 2011-10-11 09:21:21 --> Model Class Initialized
DEBUG - 2011-10-11 09:21:21 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-10-11 09:21:21 --> Database Driver Class Initialized
DEBUG - 2011-10-11 09:21:22 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-10-11 09:21:22 --> Helper loaded: url_helper
DEBUG - 2011-10-11 09:21:22 --> File loaded: application/views/common/header.php
DEBUG - 2011-10-11 09:21:22 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-10-11 09:21:22 --> File loaded: application/views/common/footer.php
DEBUG - 2011-10-11 09:21:22 --> File loaded: application/views/layout/main.php
DEBUG - 2011-10-11 09:21:22 --> Final output sent to browser
DEBUG - 2011-10-11 09:21:22 --> Total execution time: 0.6734
DEBUG - 2011-10-11 09:21:24 --> Config Class Initialized
DEBUG - 2011-10-11 09:21:24 --> Hooks Class Initialized
DEBUG - 2011-10-11 09:21:24 --> Utf8 Class Initialized
DEBUG - 2011-10-11 09:21:24 --> UTF-8 Support Enabled
DEBUG - 2011-10-11 09:21:24 --> URI Class Initialized
DEBUG - 2011-10-11 09:21:24 --> Router Class Initialized
DEBUG - 2011-10-11 09:21:24 --> Output Class Initialized
DEBUG - 2011-10-11 09:21:24 --> Input Class Initialized
DEBUG - 2011-10-11 09:21:24 --> Global POST and COOKIE data sanitized
DEBUG - 2011-10-11 09:21:24 --> Language Class Initialized
DEBUG - 2011-10-11 09:21:24 --> Loader Class Initialized
DEBUG - 2011-10-11 09:21:24 --> Controller Class Initialized
DEBUG - 2011-10-11 09:21:24 --> Model Class Initialized
DEBUG - 2011-10-11 09:21:24 --> Model Class Initialized
DEBUG - 2011-10-11 09:21:24 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-10-11 09:21:24 --> Database Driver Class Initialized
DEBUG - 2011-10-11 09:21:24 --> Final output sent to browser
DEBUG - 2011-10-11 09:21:24 --> Total execution time: 0.6994
DEBUG - 2011-10-11 09:21:27 --> Config Class Initialized
DEBUG - 2011-10-11 09:21:27 --> Hooks Class Initialized
DEBUG - 2011-10-11 09:21:27 --> Utf8 Class Initialized
DEBUG - 2011-10-11 09:21:27 --> UTF-8 Support Enabled
DEBUG - 2011-10-11 09:21:27 --> URI Class Initialized
DEBUG - 2011-10-11 09:21:27 --> Router Class Initialized
ERROR - 2011-10-11 09:21:27 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-10-11 09:22:22 --> Config Class Initialized
DEBUG - 2011-10-11 09:22:22 --> Hooks Class Initialized
DEBUG - 2011-10-11 09:22:22 --> Utf8 Class Initialized
DEBUG - 2011-10-11 09:22:22 --> UTF-8 Support Enabled
DEBUG - 2011-10-11 09:22:22 --> URI Class Initialized
DEBUG - 2011-10-11 09:22:22 --> Router Class Initialized
DEBUG - 2011-10-11 09:22:22 --> Output Class Initialized
DEBUG - 2011-10-11 09:22:22 --> Input Class Initialized
DEBUG - 2011-10-11 09:22:22 --> Global POST and COOKIE data sanitized
DEBUG - 2011-10-11 09:22:22 --> Language Class Initialized
DEBUG - 2011-10-11 09:22:22 --> Loader Class Initialized
DEBUG - 2011-10-11 09:22:22 --> Controller Class Initialized
DEBUG - 2011-10-11 09:22:22 --> Model Class Initialized
DEBUG - 2011-10-11 09:22:22 --> Model Class Initialized
DEBUG - 2011-10-11 09:22:22 --> Model Class Initialized
DEBUG - 2011-10-11 09:22:22 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-10-11 09:22:22 --> Database Driver Class Initialized
DEBUG - 2011-10-11 09:22:23 --> File loaded: application/views/table/main.php
DEBUG - 2011-10-11 09:22:23 --> Helper loaded: url_helper
DEBUG - 2011-10-11 09:22:23 --> File loaded: application/views/common/header.php
DEBUG - 2011-10-11 09:22:23 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-10-11 09:22:23 --> File loaded: application/views/common/footer.php
DEBUG - 2011-10-11 09:22:23 --> File loaded: application/views/layout/main.php
DEBUG - 2011-10-11 09:22:23 --> Final output sent to browser
DEBUG - 2011-10-11 09:22:23 --> Total execution time: 1.1285
DEBUG - 2011-10-11 09:22:25 --> Config Class Initialized
DEBUG - 2011-10-11 09:22:25 --> Hooks Class Initialized
DEBUG - 2011-10-11 09:22:25 --> Utf8 Class Initialized
DEBUG - 2011-10-11 09:22:25 --> UTF-8 Support Enabled
DEBUG - 2011-10-11 09:22:25 --> URI Class Initialized
DEBUG - 2011-10-11 09:22:25 --> Router Class Initialized
ERROR - 2011-10-11 09:22:25 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-10-11 09:36:20 --> Config Class Initialized
DEBUG - 2011-10-11 09:36:20 --> Hooks Class Initialized
DEBUG - 2011-10-11 09:36:20 --> Utf8 Class Initialized
DEBUG - 2011-10-11 09:36:20 --> UTF-8 Support Enabled
DEBUG - 2011-10-11 09:36:20 --> URI Class Initialized
DEBUG - 2011-10-11 09:36:20 --> Router Class Initialized
DEBUG - 2011-10-11 09:36:20 --> Output Class Initialized
DEBUG - 2011-10-11 09:36:20 --> Input Class Initialized
DEBUG - 2011-10-11 09:36:20 --> Global POST and COOKIE data sanitized
DEBUG - 2011-10-11 09:36:20 --> Language Class Initialized
DEBUG - 2011-10-11 09:36:20 --> Loader Class Initialized
DEBUG - 2011-10-11 09:36:20 --> Controller Class Initialized
ERROR - 2011-10-11 09:36:20 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-10-11 09:36:20 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-10-11 09:36:20 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-10-11 09:36:20 --> Model Class Initialized
DEBUG - 2011-10-11 09:36:20 --> Model Class Initialized
DEBUG - 2011-10-11 09:36:20 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-10-11 09:36:20 --> Database Driver Class Initialized
DEBUG - 2011-10-11 09:36:20 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-10-11 09:36:20 --> Helper loaded: url_helper
DEBUG - 2011-10-11 09:36:20 --> File loaded: application/views/common/header.php
DEBUG - 2011-10-11 09:36:20 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-10-11 09:36:20 --> File loaded: application/views/common/footer.php
DEBUG - 2011-10-11 09:36:20 --> File loaded: application/views/layout/main.php
DEBUG - 2011-10-11 09:36:20 --> Final output sent to browser
DEBUG - 2011-10-11 09:36:20 --> Total execution time: 0.0988
DEBUG - 2011-10-11 10:54:50 --> Config Class Initialized
DEBUG - 2011-10-11 10:54:50 --> Hooks Class Initialized
DEBUG - 2011-10-11 10:54:50 --> Utf8 Class Initialized
DEBUG - 2011-10-11 10:54:50 --> UTF-8 Support Enabled
DEBUG - 2011-10-11 10:54:50 --> URI Class Initialized
DEBUG - 2011-10-11 10:54:50 --> Router Class Initialized
DEBUG - 2011-10-11 10:54:50 --> Output Class Initialized
DEBUG - 2011-10-11 10:54:50 --> Input Class Initialized
DEBUG - 2011-10-11 10:54:50 --> Global POST and COOKIE data sanitized
DEBUG - 2011-10-11 10:54:50 --> Language Class Initialized
DEBUG - 2011-10-11 10:54:50 --> Loader Class Initialized
DEBUG - 2011-10-11 10:54:50 --> Controller Class Initialized
DEBUG - 2011-10-11 10:54:50 --> Model Class Initialized
DEBUG - 2011-10-11 10:54:50 --> Model Class Initialized
DEBUG - 2011-10-11 10:54:50 --> Model Class Initialized
DEBUG - 2011-10-11 10:54:50 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-10-11 10:54:50 --> Database Driver Class Initialized
DEBUG - 2011-10-11 10:54:51 --> File loaded: application/views/table/main.php
DEBUG - 2011-10-11 10:54:51 --> Helper loaded: url_helper
DEBUG - 2011-10-11 10:54:51 --> File loaded: application/views/common/header.php
DEBUG - 2011-10-11 10:54:51 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-10-11 10:54:51 --> File loaded: application/views/common/footer.php
DEBUG - 2011-10-11 10:54:51 --> File loaded: application/views/layout/main.php
DEBUG - 2011-10-11 10:54:51 --> Final output sent to browser
DEBUG - 2011-10-11 10:54:51 --> Total execution time: 1.2326
DEBUG - 2011-10-11 10:54:53 --> Config Class Initialized
DEBUG - 2011-10-11 10:54:53 --> Hooks Class Initialized
DEBUG - 2011-10-11 10:54:53 --> Utf8 Class Initialized
DEBUG - 2011-10-11 10:54:53 --> UTF-8 Support Enabled
DEBUG - 2011-10-11 10:54:53 --> URI Class Initialized
DEBUG - 2011-10-11 10:54:53 --> Router Class Initialized
ERROR - 2011-10-11 10:54:53 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-10-11 10:54:53 --> Config Class Initialized
DEBUG - 2011-10-11 10:54:53 --> Hooks Class Initialized
DEBUG - 2011-10-11 10:54:53 --> Utf8 Class Initialized
DEBUG - 2011-10-11 10:54:53 --> UTF-8 Support Enabled
DEBUG - 2011-10-11 10:54:53 --> URI Class Initialized
DEBUG - 2011-10-11 10:54:53 --> Router Class Initialized
ERROR - 2011-10-11 10:54:53 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-10-11 10:54:55 --> Config Class Initialized
DEBUG - 2011-10-11 10:54:55 --> Hooks Class Initialized
DEBUG - 2011-10-11 10:54:55 --> Utf8 Class Initialized
DEBUG - 2011-10-11 10:54:55 --> UTF-8 Support Enabled
DEBUG - 2011-10-11 10:54:55 --> URI Class Initialized
DEBUG - 2011-10-11 10:54:55 --> Router Class Initialized
ERROR - 2011-10-11 10:54:55 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-10-11 12:42:27 --> Config Class Initialized
DEBUG - 2011-10-11 12:42:27 --> Hooks Class Initialized
DEBUG - 2011-10-11 12:42:27 --> Utf8 Class Initialized
DEBUG - 2011-10-11 12:42:27 --> UTF-8 Support Enabled
DEBUG - 2011-10-11 12:42:27 --> URI Class Initialized
DEBUG - 2011-10-11 12:42:27 --> Router Class Initialized
DEBUG - 2011-10-11 12:42:27 --> No URI present. Default controller set.
DEBUG - 2011-10-11 12:42:27 --> Output Class Initialized
DEBUG - 2011-10-11 12:42:27 --> Input Class Initialized
DEBUG - 2011-10-11 12:42:27 --> Global POST and COOKIE data sanitized
DEBUG - 2011-10-11 12:42:27 --> Language Class Initialized
DEBUG - 2011-10-11 12:42:27 --> Loader Class Initialized
DEBUG - 2011-10-11 12:42:27 --> Controller Class Initialized
DEBUG - 2011-10-11 12:42:27 --> File loaded: application/views/splash/main.php
DEBUG - 2011-10-11 12:42:27 --> Helper loaded: url_helper
DEBUG - 2011-10-11 12:42:27 --> File loaded: application/views/common/header.php
DEBUG - 2011-10-11 12:42:27 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-10-11 12:42:27 --> File loaded: application/views/common/footer.php
DEBUG - 2011-10-11 12:42:27 --> File loaded: application/views/layout/main.php
DEBUG - 2011-10-11 12:42:27 --> Final output sent to browser
DEBUG - 2011-10-11 12:42:27 --> Total execution time: 0.1220
DEBUG - 2011-10-11 14:01:48 --> Config Class Initialized
DEBUG - 2011-10-11 14:01:48 --> Hooks Class Initialized
DEBUG - 2011-10-11 14:01:48 --> Utf8 Class Initialized
DEBUG - 2011-10-11 14:01:48 --> UTF-8 Support Enabled
DEBUG - 2011-10-11 14:01:48 --> URI Class Initialized
DEBUG - 2011-10-11 14:01:48 --> Router Class Initialized
ERROR - 2011-10-11 14:01:48 --> 404 Page Not Found --> robots.txt
DEBUG - 2011-10-11 14:01:49 --> Config Class Initialized
DEBUG - 2011-10-11 14:01:49 --> Hooks Class Initialized
DEBUG - 2011-10-11 14:01:49 --> Utf8 Class Initialized
DEBUG - 2011-10-11 14:01:49 --> UTF-8 Support Enabled
DEBUG - 2011-10-11 14:01:49 --> URI Class Initialized
DEBUG - 2011-10-11 14:01:49 --> Router Class Initialized
DEBUG - 2011-10-11 14:01:49 --> No URI present. Default controller set.
DEBUG - 2011-10-11 14:01:49 --> Output Class Initialized
DEBUG - 2011-10-11 14:01:49 --> Input Class Initialized
DEBUG - 2011-10-11 14:01:49 --> Global POST and COOKIE data sanitized
DEBUG - 2011-10-11 14:01:49 --> Language Class Initialized
DEBUG - 2011-10-11 14:01:49 --> Loader Class Initialized
DEBUG - 2011-10-11 14:01:49 --> Controller Class Initialized
DEBUG - 2011-10-11 14:01:49 --> File loaded: application/views/splash/main.php
DEBUG - 2011-10-11 14:01:49 --> Helper loaded: url_helper
DEBUG - 2011-10-11 14:01:49 --> File loaded: application/views/common/header.php
DEBUG - 2011-10-11 14:01:49 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-10-11 14:01:49 --> File loaded: application/views/common/footer.php
DEBUG - 2011-10-11 14:01:49 --> File loaded: application/views/layout/main.php
DEBUG - 2011-10-11 14:01:49 --> Final output sent to browser
DEBUG - 2011-10-11 14:01:49 --> Total execution time: 0.0408
DEBUG - 2011-10-11 15:13:22 --> Config Class Initialized
DEBUG - 2011-10-11 15:13:22 --> Hooks Class Initialized
DEBUG - 2011-10-11 15:13:22 --> Utf8 Class Initialized
DEBUG - 2011-10-11 15:13:22 --> UTF-8 Support Enabled
DEBUG - 2011-10-11 15:13:22 --> URI Class Initialized
DEBUG - 2011-10-11 15:13:22 --> Router Class Initialized
DEBUG - 2011-10-11 15:13:22 --> No URI present. Default controller set.
DEBUG - 2011-10-11 15:13:22 --> Output Class Initialized
DEBUG - 2011-10-11 15:13:22 --> Input Class Initialized
DEBUG - 2011-10-11 15:13:22 --> Global POST and COOKIE data sanitized
DEBUG - 2011-10-11 15:13:22 --> Language Class Initialized
DEBUG - 2011-10-11 15:13:22 --> Loader Class Initialized
DEBUG - 2011-10-11 15:13:22 --> Controller Class Initialized
DEBUG - 2011-10-11 15:13:22 --> File loaded: application/views/splash/main.php
DEBUG - 2011-10-11 15:13:22 --> Helper loaded: url_helper
DEBUG - 2011-10-11 15:13:22 --> File loaded: application/views/common/header.php
DEBUG - 2011-10-11 15:13:22 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-10-11 15:13:22 --> File loaded: application/views/common/footer.php
DEBUG - 2011-10-11 15:13:22 --> File loaded: application/views/layout/main.php
DEBUG - 2011-10-11 15:13:22 --> Final output sent to browser
DEBUG - 2011-10-11 15:13:22 --> Total execution time: 0.0524
DEBUG - 2011-10-11 15:27:18 --> Config Class Initialized
DEBUG - 2011-10-11 15:27:18 --> Hooks Class Initialized
DEBUG - 2011-10-11 15:27:18 --> Utf8 Class Initialized
DEBUG - 2011-10-11 15:27:18 --> UTF-8 Support Enabled
DEBUG - 2011-10-11 15:27:18 --> URI Class Initialized
DEBUG - 2011-10-11 15:27:18 --> Router Class Initialized
DEBUG - 2011-10-11 15:27:18 --> Output Class Initialized
DEBUG - 2011-10-11 15:27:18 --> Input Class Initialized
DEBUG - 2011-10-11 15:27:18 --> Global POST and COOKIE data sanitized
DEBUG - 2011-10-11 15:27:18 --> Language Class Initialized
DEBUG - 2011-10-11 15:27:18 --> Loader Class Initialized
DEBUG - 2011-10-11 15:27:18 --> Controller Class Initialized
DEBUG - 2011-10-11 15:27:18 --> Model Class Initialized
DEBUG - 2011-10-11 15:27:18 --> Model Class Initialized
DEBUG - 2011-10-11 15:27:18 --> Model Class Initialized
DEBUG - 2011-10-11 15:27:18 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-10-11 15:27:18 --> Database Driver Class Initialized
DEBUG - 2011-10-11 15:27:20 --> File loaded: application/views/table/main.php
DEBUG - 2011-10-11 15:27:20 --> Helper loaded: url_helper
DEBUG - 2011-10-11 15:27:20 --> File loaded: application/views/common/header.php
DEBUG - 2011-10-11 15:27:20 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-10-11 15:27:20 --> File loaded: application/views/common/footer.php
DEBUG - 2011-10-11 15:27:20 --> File loaded: application/views/layout/main.php
DEBUG - 2011-10-11 15:27:20 --> Final output sent to browser
DEBUG - 2011-10-11 15:27:20 --> Total execution time: 1.5615
DEBUG - 2011-10-11 15:27:51 --> Config Class Initialized
DEBUG - 2011-10-11 15:27:51 --> Hooks Class Initialized
DEBUG - 2011-10-11 15:27:51 --> Utf8 Class Initialized
DEBUG - 2011-10-11 15:27:51 --> UTF-8 Support Enabled
DEBUG - 2011-10-11 15:27:51 --> URI Class Initialized
DEBUG - 2011-10-11 15:27:51 --> Router Class Initialized
DEBUG - 2011-10-11 15:27:51 --> Output Class Initialized
DEBUG - 2011-10-11 15:27:51 --> Input Class Initialized
DEBUG - 2011-10-11 15:27:51 --> Global POST and COOKIE data sanitized
DEBUG - 2011-10-11 15:27:51 --> Language Class Initialized
DEBUG - 2011-10-11 15:27:51 --> Loader Class Initialized
DEBUG - 2011-10-11 15:27:51 --> Controller Class Initialized
DEBUG - 2011-10-11 15:27:51 --> Model Class Initialized
DEBUG - 2011-10-11 15:27:51 --> Model Class Initialized
DEBUG - 2011-10-11 15:27:51 --> Model Class Initialized
DEBUG - 2011-10-11 15:27:51 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-10-11 15:27:51 --> Database Driver Class Initialized
DEBUG - 2011-10-11 15:27:52 --> File loaded: application/views/table/main.php
DEBUG - 2011-10-11 15:27:52 --> Helper loaded: url_helper
DEBUG - 2011-10-11 15:27:52 --> File loaded: application/views/common/header.php
DEBUG - 2011-10-11 15:27:52 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-10-11 15:27:52 --> File loaded: application/views/common/footer.php
DEBUG - 2011-10-11 15:27:52 --> File loaded: application/views/layout/main.php
DEBUG - 2011-10-11 15:27:52 --> Final output sent to browser
DEBUG - 2011-10-11 15:27:52 --> Total execution time: 1.1631
DEBUG - 2011-10-11 15:27:57 --> Config Class Initialized
DEBUG - 2011-10-11 15:27:57 --> Hooks Class Initialized
DEBUG - 2011-10-11 15:27:57 --> Utf8 Class Initialized
DEBUG - 2011-10-11 15:27:57 --> UTF-8 Support Enabled
DEBUG - 2011-10-11 15:27:57 --> URI Class Initialized
DEBUG - 2011-10-11 15:27:57 --> Router Class Initialized
ERROR - 2011-10-11 15:27:57 --> 404 Page Not Found --> robots.txt
DEBUG - 2011-10-11 15:27:57 --> Config Class Initialized
DEBUG - 2011-10-11 15:27:57 --> Hooks Class Initialized
DEBUG - 2011-10-11 15:27:57 --> Utf8 Class Initialized
DEBUG - 2011-10-11 15:27:57 --> UTF-8 Support Enabled
DEBUG - 2011-10-11 15:27:57 --> URI Class Initialized
DEBUG - 2011-10-11 15:27:57 --> Router Class Initialized
DEBUG - 2011-10-11 15:27:57 --> Output Class Initialized
DEBUG - 2011-10-11 15:27:57 --> Input Class Initialized
DEBUG - 2011-10-11 15:27:57 --> Global POST and COOKIE data sanitized
DEBUG - 2011-10-11 15:27:57 --> Language Class Initialized
DEBUG - 2011-10-11 15:27:57 --> Loader Class Initialized
DEBUG - 2011-10-11 15:27:57 --> Controller Class Initialized
DEBUG - 2011-10-11 15:27:57 --> Model Class Initialized
DEBUG - 2011-10-11 15:27:57 --> Model Class Initialized
DEBUG - 2011-10-11 15:27:57 --> Model Class Initialized
DEBUG - 2011-10-11 15:27:57 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-10-11 15:27:57 --> Database Driver Class Initialized
DEBUG - 2011-10-11 15:27:57 --> File loaded: application/views/table/main.php
DEBUG - 2011-10-11 15:27:57 --> Helper loaded: url_helper
DEBUG - 2011-10-11 15:27:57 --> File loaded: application/views/common/header.php
DEBUG - 2011-10-11 15:27:57 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-10-11 15:27:57 --> File loaded: application/views/common/footer.php
DEBUG - 2011-10-11 15:27:57 --> File loaded: application/views/layout/main.php
DEBUG - 2011-10-11 15:27:57 --> Final output sent to browser
DEBUG - 2011-10-11 15:27:57 --> Total execution time: 0.0609
DEBUG - 2011-10-11 15:28:39 --> Config Class Initialized
DEBUG - 2011-10-11 15:28:39 --> Hooks Class Initialized
DEBUG - 2011-10-11 15:28:39 --> Utf8 Class Initialized
DEBUG - 2011-10-11 15:28:39 --> UTF-8 Support Enabled
DEBUG - 2011-10-11 15:28:39 --> URI Class Initialized
DEBUG - 2011-10-11 15:28:39 --> Router Class Initialized
DEBUG - 2011-10-11 15:28:39 --> Output Class Initialized
DEBUG - 2011-10-11 15:28:39 --> Input Class Initialized
DEBUG - 2011-10-11 15:28:39 --> Global POST and COOKIE data sanitized
DEBUG - 2011-10-11 15:28:39 --> Language Class Initialized
DEBUG - 2011-10-11 15:28:39 --> Loader Class Initialized
DEBUG - 2011-10-11 15:28:39 --> Controller Class Initialized
DEBUG - 2011-10-11 15:28:39 --> Model Class Initialized
DEBUG - 2011-10-11 15:28:39 --> Model Class Initialized
DEBUG - 2011-10-11 15:28:39 --> Model Class Initialized
DEBUG - 2011-10-11 15:28:39 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-10-11 15:28:39 --> Database Driver Class Initialized
DEBUG - 2011-10-11 15:28:40 --> File loaded: application/views/table/main.php
DEBUG - 2011-10-11 15:28:40 --> Helper loaded: url_helper
DEBUG - 2011-10-11 15:28:40 --> File loaded: application/views/common/header.php
DEBUG - 2011-10-11 15:28:40 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-10-11 15:28:40 --> File loaded: application/views/common/footer.php
DEBUG - 2011-10-11 15:28:40 --> File loaded: application/views/layout/main.php
DEBUG - 2011-10-11 15:28:40 --> Final output sent to browser
DEBUG - 2011-10-11 15:28:40 --> Total execution time: 0.4965
DEBUG - 2011-10-11 15:29:06 --> Config Class Initialized
DEBUG - 2011-10-11 15:29:06 --> Hooks Class Initialized
DEBUG - 2011-10-11 15:29:06 --> Utf8 Class Initialized
DEBUG - 2011-10-11 15:29:06 --> UTF-8 Support Enabled
DEBUG - 2011-10-11 15:29:06 --> URI Class Initialized
DEBUG - 2011-10-11 15:29:06 --> Router Class Initialized
DEBUG - 2011-10-11 15:29:06 --> Output Class Initialized
DEBUG - 2011-10-11 15:29:06 --> Input Class Initialized
DEBUG - 2011-10-11 15:29:06 --> Global POST and COOKIE data sanitized
DEBUG - 2011-10-11 15:29:06 --> Language Class Initialized
DEBUG - 2011-10-11 15:29:06 --> Loader Class Initialized
DEBUG - 2011-10-11 15:29:06 --> Controller Class Initialized
DEBUG - 2011-10-11 15:29:06 --> Model Class Initialized
DEBUG - 2011-10-11 15:29:06 --> Model Class Initialized
DEBUG - 2011-10-11 15:29:06 --> Model Class Initialized
DEBUG - 2011-10-11 15:29:06 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-10-11 15:29:06 --> Database Driver Class Initialized
DEBUG - 2011-10-11 15:29:07 --> File loaded: application/views/table/main.php
DEBUG - 2011-10-11 15:29:07 --> Helper loaded: url_helper
DEBUG - 2011-10-11 15:29:07 --> File loaded: application/views/common/header.php
DEBUG - 2011-10-11 15:29:07 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-10-11 15:29:07 --> File loaded: application/views/common/footer.php
DEBUG - 2011-10-11 15:29:07 --> File loaded: application/views/layout/main.php
DEBUG - 2011-10-11 15:29:07 --> Final output sent to browser
DEBUG - 2011-10-11 15:29:07 --> Total execution time: 0.9692
DEBUG - 2011-10-11 15:29:10 --> Config Class Initialized
DEBUG - 2011-10-11 15:29:10 --> Hooks Class Initialized
DEBUG - 2011-10-11 15:29:10 --> Utf8 Class Initialized
DEBUG - 2011-10-11 15:29:10 --> UTF-8 Support Enabled
DEBUG - 2011-10-11 15:29:10 --> URI Class Initialized
DEBUG - 2011-10-11 15:29:10 --> Router Class Initialized
DEBUG - 2011-10-11 15:29:10 --> Output Class Initialized
DEBUG - 2011-10-11 15:29:10 --> Input Class Initialized
DEBUG - 2011-10-11 15:29:10 --> Global POST and COOKIE data sanitized
DEBUG - 2011-10-11 15:29:10 --> Language Class Initialized
DEBUG - 2011-10-11 15:29:10 --> Loader Class Initialized
DEBUG - 2011-10-11 15:29:10 --> Controller Class Initialized
DEBUG - 2011-10-11 15:29:10 --> Model Class Initialized
DEBUG - 2011-10-11 15:29:10 --> Model Class Initialized
DEBUG - 2011-10-11 15:29:10 --> Model Class Initialized
DEBUG - 2011-10-11 15:29:10 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-10-11 15:29:10 --> Database Driver Class Initialized
DEBUG - 2011-10-11 15:29:10 --> File loaded: application/views/table/main.php
DEBUG - 2011-10-11 15:29:10 --> Helper loaded: url_helper
DEBUG - 2011-10-11 15:29:10 --> File loaded: application/views/common/header.php
DEBUG - 2011-10-11 15:29:10 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-10-11 15:29:10 --> File loaded: application/views/common/footer.php
DEBUG - 2011-10-11 15:29:10 --> File loaded: application/views/layout/main.php
DEBUG - 2011-10-11 15:29:10 --> Final output sent to browser
DEBUG - 2011-10-11 15:29:10 --> Total execution time: 0.0545
DEBUG - 2011-10-11 15:29:25 --> Config Class Initialized
DEBUG - 2011-10-11 15:29:25 --> Hooks Class Initialized
DEBUG - 2011-10-11 15:29:25 --> Utf8 Class Initialized
DEBUG - 2011-10-11 15:29:25 --> UTF-8 Support Enabled
DEBUG - 2011-10-11 15:29:25 --> URI Class Initialized
DEBUG - 2011-10-11 15:29:25 --> Router Class Initialized
DEBUG - 2011-10-11 15:29:25 --> Output Class Initialized
DEBUG - 2011-10-11 15:29:25 --> Input Class Initialized
DEBUG - 2011-10-11 15:29:25 --> Global POST and COOKIE data sanitized
DEBUG - 2011-10-11 15:29:25 --> Language Class Initialized
DEBUG - 2011-10-11 15:29:25 --> Loader Class Initialized
DEBUG - 2011-10-11 15:29:25 --> Controller Class Initialized
DEBUG - 2011-10-11 15:29:25 --> Model Class Initialized
DEBUG - 2011-10-11 15:29:25 --> Model Class Initialized
DEBUG - 2011-10-11 15:29:25 --> Model Class Initialized
DEBUG - 2011-10-11 15:29:25 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-10-11 15:29:25 --> Database Driver Class Initialized
DEBUG - 2011-10-11 15:29:25 --> File loaded: application/views/table/main.php
DEBUG - 2011-10-11 15:29:25 --> Helper loaded: url_helper
DEBUG - 2011-10-11 15:29:25 --> File loaded: application/views/common/header.php
DEBUG - 2011-10-11 15:29:25 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-10-11 15:29:25 --> File loaded: application/views/common/footer.php
DEBUG - 2011-10-11 15:29:25 --> File loaded: application/views/layout/main.php
DEBUG - 2011-10-11 15:29:25 --> Final output sent to browser
DEBUG - 2011-10-11 15:29:25 --> Total execution time: 0.3183
DEBUG - 2011-10-11 15:29:40 --> Config Class Initialized
DEBUG - 2011-10-11 15:29:40 --> Hooks Class Initialized
DEBUG - 2011-10-11 15:29:40 --> Utf8 Class Initialized
DEBUG - 2011-10-11 15:29:40 --> UTF-8 Support Enabled
DEBUG - 2011-10-11 15:29:40 --> URI Class Initialized
DEBUG - 2011-10-11 15:29:40 --> Router Class Initialized
DEBUG - 2011-10-11 15:29:40 --> Output Class Initialized
DEBUG - 2011-10-11 15:29:40 --> Input Class Initialized
DEBUG - 2011-10-11 15:29:40 --> Global POST and COOKIE data sanitized
DEBUG - 2011-10-11 15:29:40 --> Language Class Initialized
DEBUG - 2011-10-11 15:29:40 --> Loader Class Initialized
DEBUG - 2011-10-11 15:29:40 --> Controller Class Initialized
DEBUG - 2011-10-11 15:29:40 --> Model Class Initialized
DEBUG - 2011-10-11 15:29:40 --> Model Class Initialized
DEBUG - 2011-10-11 15:29:40 --> Model Class Initialized
DEBUG - 2011-10-11 15:29:40 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-10-11 15:29:40 --> Database Driver Class Initialized
DEBUG - 2011-10-11 15:29:40 --> File loaded: application/views/table/main.php
DEBUG - 2011-10-11 15:29:40 --> Helper loaded: url_helper
DEBUG - 2011-10-11 15:29:40 --> File loaded: application/views/common/header.php
DEBUG - 2011-10-11 15:29:40 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-10-11 15:29:41 --> File loaded: application/views/common/footer.php
DEBUG - 2011-10-11 15:29:41 --> File loaded: application/views/layout/main.php
DEBUG - 2011-10-11 15:29:41 --> Final output sent to browser
DEBUG - 2011-10-11 15:29:41 --> Total execution time: 0.0605
DEBUG - 2011-10-11 15:29:46 --> Config Class Initialized
DEBUG - 2011-10-11 15:29:46 --> Hooks Class Initialized
DEBUG - 2011-10-11 15:29:46 --> Utf8 Class Initialized
DEBUG - 2011-10-11 15:29:46 --> UTF-8 Support Enabled
DEBUG - 2011-10-11 15:29:46 --> URI Class Initialized
DEBUG - 2011-10-11 15:29:46 --> Router Class Initialized
DEBUG - 2011-10-11 15:29:46 --> Output Class Initialized
DEBUG - 2011-10-11 15:29:46 --> Input Class Initialized
DEBUG - 2011-10-11 15:29:46 --> Global POST and COOKIE data sanitized
DEBUG - 2011-10-11 15:29:46 --> Language Class Initialized
DEBUG - 2011-10-11 15:29:46 --> Loader Class Initialized
DEBUG - 2011-10-11 15:29:46 --> Controller Class Initialized
DEBUG - 2011-10-11 15:29:46 --> Model Class Initialized
DEBUG - 2011-10-11 15:29:46 --> Model Class Initialized
DEBUG - 2011-10-11 15:29:46 --> Model Class Initialized
DEBUG - 2011-10-11 15:29:46 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-10-11 15:29:46 --> Database Driver Class Initialized
DEBUG - 2011-10-11 15:29:47 --> File loaded: application/views/table/main.php
DEBUG - 2011-10-11 15:29:47 --> Helper loaded: url_helper
DEBUG - 2011-10-11 15:29:47 --> File loaded: application/views/common/header.php
DEBUG - 2011-10-11 15:29:47 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-10-11 15:29:47 --> File loaded: application/views/common/footer.php
DEBUG - 2011-10-11 15:29:47 --> File loaded: application/views/layout/main.php
DEBUG - 2011-10-11 15:29:47 --> Final output sent to browser
DEBUG - 2011-10-11 15:29:47 --> Total execution time: 0.5575
DEBUG - 2011-10-11 15:29:48 --> Config Class Initialized
DEBUG - 2011-10-11 15:29:48 --> Hooks Class Initialized
DEBUG - 2011-10-11 15:29:48 --> Utf8 Class Initialized
DEBUG - 2011-10-11 15:29:48 --> UTF-8 Support Enabled
DEBUG - 2011-10-11 15:29:48 --> URI Class Initialized
DEBUG - 2011-10-11 15:29:48 --> Router Class Initialized
DEBUG - 2011-10-11 15:29:48 --> Output Class Initialized
DEBUG - 2011-10-11 15:29:48 --> Input Class Initialized
DEBUG - 2011-10-11 15:29:48 --> Global POST and COOKIE data sanitized
DEBUG - 2011-10-11 15:29:48 --> Language Class Initialized
DEBUG - 2011-10-11 15:29:48 --> Loader Class Initialized
DEBUG - 2011-10-11 15:29:48 --> Controller Class Initialized
DEBUG - 2011-10-11 15:29:48 --> Model Class Initialized
DEBUG - 2011-10-11 15:29:48 --> Model Class Initialized
DEBUG - 2011-10-11 15:29:48 --> Model Class Initialized
DEBUG - 2011-10-11 15:29:48 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-10-11 15:29:48 --> Database Driver Class Initialized
DEBUG - 2011-10-11 15:29:48 --> File loaded: application/views/table/main.php
DEBUG - 2011-10-11 15:29:48 --> Helper loaded: url_helper
DEBUG - 2011-10-11 15:29:48 --> File loaded: application/views/common/header.php
DEBUG - 2011-10-11 15:29:48 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-10-11 15:29:48 --> File loaded: application/views/common/footer.php
DEBUG - 2011-10-11 15:29:48 --> File loaded: application/views/layout/main.php
DEBUG - 2011-10-11 15:29:48 --> Final output sent to browser
DEBUG - 2011-10-11 15:29:48 --> Total execution time: 0.0497
DEBUG - 2011-10-11 15:29:55 --> Config Class Initialized
DEBUG - 2011-10-11 15:29:55 --> Hooks Class Initialized
DEBUG - 2011-10-11 15:29:55 --> Utf8 Class Initialized
DEBUG - 2011-10-11 15:29:55 --> UTF-8 Support Enabled
DEBUG - 2011-10-11 15:29:55 --> URI Class Initialized
DEBUG - 2011-10-11 15:29:55 --> Router Class Initialized
DEBUG - 2011-10-11 15:29:55 --> Output Class Initialized
DEBUG - 2011-10-11 15:29:55 --> Input Class Initialized
DEBUG - 2011-10-11 15:29:55 --> Global POST and COOKIE data sanitized
DEBUG - 2011-10-11 15:29:55 --> Language Class Initialized
DEBUG - 2011-10-11 15:29:55 --> Loader Class Initialized
DEBUG - 2011-10-11 15:29:55 --> Controller Class Initialized
DEBUG - 2011-10-11 15:29:55 --> Model Class Initialized
DEBUG - 2011-10-11 15:29:55 --> Model Class Initialized
DEBUG - 2011-10-11 15:29:55 --> Model Class Initialized
DEBUG - 2011-10-11 15:29:55 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-10-11 15:29:55 --> Database Driver Class Initialized
DEBUG - 2011-10-11 15:29:55 --> File loaded: application/views/table/main.php
DEBUG - 2011-10-11 15:29:55 --> Helper loaded: url_helper
DEBUG - 2011-10-11 15:29:55 --> File loaded: application/views/common/header.php
DEBUG - 2011-10-11 15:29:55 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-10-11 15:29:55 --> File loaded: application/views/common/footer.php
DEBUG - 2011-10-11 15:29:55 --> File loaded: application/views/layout/main.php
DEBUG - 2011-10-11 15:29:55 --> Final output sent to browser
DEBUG - 2011-10-11 15:29:55 --> Total execution time: 0.0780
DEBUG - 2011-10-11 15:30:03 --> Config Class Initialized
DEBUG - 2011-10-11 15:30:03 --> Hooks Class Initialized
DEBUG - 2011-10-11 15:30:03 --> Utf8 Class Initialized
DEBUG - 2011-10-11 15:30:03 --> UTF-8 Support Enabled
DEBUG - 2011-10-11 15:30:03 --> URI Class Initialized
DEBUG - 2011-10-11 15:30:03 --> Router Class Initialized
DEBUG - 2011-10-11 15:30:03 --> Output Class Initialized
DEBUG - 2011-10-11 15:30:03 --> Input Class Initialized
DEBUG - 2011-10-11 15:30:03 --> Global POST and COOKIE data sanitized
DEBUG - 2011-10-11 15:30:03 --> Language Class Initialized
DEBUG - 2011-10-11 15:30:03 --> Loader Class Initialized
DEBUG - 2011-10-11 15:30:03 --> Controller Class Initialized
DEBUG - 2011-10-11 15:30:03 --> Model Class Initialized
DEBUG - 2011-10-11 15:30:03 --> Model Class Initialized
DEBUG - 2011-10-11 15:30:03 --> Model Class Initialized
DEBUG - 2011-10-11 15:30:03 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-10-11 15:30:03 --> Database Driver Class Initialized
DEBUG - 2011-10-11 15:30:03 --> File loaded: application/views/table/main.php
DEBUG - 2011-10-11 15:30:03 --> Helper loaded: url_helper
DEBUG - 2011-10-11 15:30:03 --> File loaded: application/views/common/header.php
DEBUG - 2011-10-11 15:30:03 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-10-11 15:30:03 --> File loaded: application/views/common/footer.php
DEBUG - 2011-10-11 15:30:03 --> File loaded: application/views/layout/main.php
DEBUG - 2011-10-11 15:30:03 --> Final output sent to browser
DEBUG - 2011-10-11 15:30:03 --> Total execution time: 0.1285
DEBUG - 2011-10-11 15:30:11 --> Config Class Initialized
DEBUG - 2011-10-11 15:30:11 --> Hooks Class Initialized
DEBUG - 2011-10-11 15:30:11 --> Utf8 Class Initialized
DEBUG - 2011-10-11 15:30:11 --> UTF-8 Support Enabled
DEBUG - 2011-10-11 15:30:11 --> URI Class Initialized
DEBUG - 2011-10-11 15:30:11 --> Router Class Initialized
DEBUG - 2011-10-11 15:30:11 --> Output Class Initialized
DEBUG - 2011-10-11 15:30:11 --> Input Class Initialized
DEBUG - 2011-10-11 15:30:11 --> Global POST and COOKIE data sanitized
DEBUG - 2011-10-11 15:30:11 --> Language Class Initialized
DEBUG - 2011-10-11 15:30:11 --> Loader Class Initialized
DEBUG - 2011-10-11 15:30:11 --> Controller Class Initialized
DEBUG - 2011-10-11 15:30:11 --> Model Class Initialized
DEBUG - 2011-10-11 15:30:11 --> Model Class Initialized
DEBUG - 2011-10-11 15:30:11 --> Model Class Initialized
DEBUG - 2011-10-11 15:30:11 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-10-11 15:30:11 --> Database Driver Class Initialized
DEBUG - 2011-10-11 15:30:11 --> File loaded: application/views/table/main.php
DEBUG - 2011-10-11 15:30:11 --> Helper loaded: url_helper
DEBUG - 2011-10-11 15:30:11 --> File loaded: application/views/common/header.php
DEBUG - 2011-10-11 15:30:11 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-10-11 15:30:11 --> File loaded: application/views/common/footer.php
DEBUG - 2011-10-11 15:30:11 --> File loaded: application/views/layout/main.php
DEBUG - 2011-10-11 15:30:11 --> Final output sent to browser
DEBUG - 2011-10-11 15:30:11 --> Total execution time: 0.8876
DEBUG - 2011-10-11 15:30:16 --> Config Class Initialized
DEBUG - 2011-10-11 15:30:16 --> Hooks Class Initialized
DEBUG - 2011-10-11 15:30:16 --> Utf8 Class Initialized
DEBUG - 2011-10-11 15:30:16 --> UTF-8 Support Enabled
DEBUG - 2011-10-11 15:30:16 --> URI Class Initialized
DEBUG - 2011-10-11 15:30:16 --> Router Class Initialized
DEBUG - 2011-10-11 15:30:16 --> Output Class Initialized
DEBUG - 2011-10-11 15:30:16 --> Input Class Initialized
DEBUG - 2011-10-11 15:30:16 --> Global POST and COOKIE data sanitized
DEBUG - 2011-10-11 15:30:16 --> Language Class Initialized
DEBUG - 2011-10-11 15:30:16 --> Loader Class Initialized
DEBUG - 2011-10-11 15:30:16 --> Controller Class Initialized
DEBUG - 2011-10-11 15:30:16 --> Model Class Initialized
DEBUG - 2011-10-11 15:30:16 --> Model Class Initialized
DEBUG - 2011-10-11 15:30:16 --> Model Class Initialized
DEBUG - 2011-10-11 15:30:16 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-10-11 15:30:16 --> Database Driver Class Initialized
DEBUG - 2011-10-11 15:30:16 --> File loaded: application/views/table/main.php
DEBUG - 2011-10-11 15:30:16 --> Helper loaded: url_helper
DEBUG - 2011-10-11 15:30:16 --> File loaded: application/views/common/header.php
DEBUG - 2011-10-11 15:30:16 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-10-11 15:30:16 --> File loaded: application/views/common/footer.php
DEBUG - 2011-10-11 15:30:16 --> File loaded: application/views/layout/main.php
DEBUG - 2011-10-11 15:30:16 --> Final output sent to browser
DEBUG - 2011-10-11 15:30:16 --> Total execution time: 0.0527
DEBUG - 2011-10-11 15:30:27 --> Config Class Initialized
DEBUG - 2011-10-11 15:30:27 --> Hooks Class Initialized
DEBUG - 2011-10-11 15:30:27 --> Utf8 Class Initialized
DEBUG - 2011-10-11 15:30:27 --> UTF-8 Support Enabled
DEBUG - 2011-10-11 15:30:27 --> URI Class Initialized
DEBUG - 2011-10-11 15:30:27 --> Router Class Initialized
DEBUG - 2011-10-11 15:30:27 --> Output Class Initialized
DEBUG - 2011-10-11 15:30:27 --> Input Class Initialized
DEBUG - 2011-10-11 15:30:27 --> Global POST and COOKIE data sanitized
DEBUG - 2011-10-11 15:30:27 --> Language Class Initialized
DEBUG - 2011-10-11 15:30:27 --> Loader Class Initialized
DEBUG - 2011-10-11 15:30:27 --> Controller Class Initialized
DEBUG - 2011-10-11 15:30:27 --> Model Class Initialized
DEBUG - 2011-10-11 15:30:27 --> Model Class Initialized
DEBUG - 2011-10-11 15:30:27 --> Model Class Initialized
DEBUG - 2011-10-11 15:30:27 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-10-11 15:30:27 --> Database Driver Class Initialized
DEBUG - 2011-10-11 15:30:27 --> File loaded: application/views/table/main.php
DEBUG - 2011-10-11 15:30:27 --> Helper loaded: url_helper
DEBUG - 2011-10-11 15:30:27 --> File loaded: application/views/common/header.php
DEBUG - 2011-10-11 15:30:27 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-10-11 15:30:27 --> File loaded: application/views/common/footer.php
DEBUG - 2011-10-11 15:30:27 --> File loaded: application/views/layout/main.php
DEBUG - 2011-10-11 15:30:27 --> Final output sent to browser
DEBUG - 2011-10-11 15:30:27 --> Total execution time: 0.2514
DEBUG - 2011-10-11 15:30:32 --> Config Class Initialized
DEBUG - 2011-10-11 15:30:32 --> Hooks Class Initialized
DEBUG - 2011-10-11 15:30:32 --> Utf8 Class Initialized
DEBUG - 2011-10-11 15:30:32 --> UTF-8 Support Enabled
DEBUG - 2011-10-11 15:30:32 --> URI Class Initialized
DEBUG - 2011-10-11 15:30:32 --> Router Class Initialized
DEBUG - 2011-10-11 15:30:32 --> Output Class Initialized
DEBUG - 2011-10-11 15:30:32 --> Input Class Initialized
DEBUG - 2011-10-11 15:30:32 --> Global POST and COOKIE data sanitized
DEBUG - 2011-10-11 15:30:32 --> Language Class Initialized
DEBUG - 2011-10-11 15:30:32 --> Loader Class Initialized
DEBUG - 2011-10-11 15:30:32 --> Controller Class Initialized
DEBUG - 2011-10-11 15:30:32 --> Model Class Initialized
DEBUG - 2011-10-11 15:30:32 --> Model Class Initialized
DEBUG - 2011-10-11 15:30:32 --> Model Class Initialized
DEBUG - 2011-10-11 15:30:32 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-10-11 15:30:32 --> Database Driver Class Initialized
DEBUG - 2011-10-11 15:30:32 --> File loaded: application/views/table/main.php
DEBUG - 2011-10-11 15:30:32 --> Helper loaded: url_helper
DEBUG - 2011-10-11 15:30:32 --> File loaded: application/views/common/header.php
DEBUG - 2011-10-11 15:30:32 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-10-11 15:30:32 --> File loaded: application/views/common/footer.php
DEBUG - 2011-10-11 15:30:32 --> File loaded: application/views/layout/main.php
DEBUG - 2011-10-11 15:30:32 --> Final output sent to browser
DEBUG - 2011-10-11 15:30:32 --> Total execution time: 0.1815
DEBUG - 2011-10-11 15:30:43 --> Config Class Initialized
DEBUG - 2011-10-11 15:30:43 --> Hooks Class Initialized
DEBUG - 2011-10-11 15:30:43 --> Utf8 Class Initialized
DEBUG - 2011-10-11 15:30:43 --> UTF-8 Support Enabled
DEBUG - 2011-10-11 15:30:43 --> URI Class Initialized
DEBUG - 2011-10-11 15:30:43 --> Router Class Initialized
DEBUG - 2011-10-11 15:30:43 --> Output Class Initialized
DEBUG - 2011-10-11 15:30:43 --> Input Class Initialized
DEBUG - 2011-10-11 15:30:43 --> Global POST and COOKIE data sanitized
DEBUG - 2011-10-11 15:30:43 --> Language Class Initialized
DEBUG - 2011-10-11 15:30:43 --> Loader Class Initialized
DEBUG - 2011-10-11 15:30:43 --> Controller Class Initialized
DEBUG - 2011-10-11 15:30:43 --> Model Class Initialized
DEBUG - 2011-10-11 15:30:43 --> Model Class Initialized
DEBUG - 2011-10-11 15:30:43 --> Model Class Initialized
DEBUG - 2011-10-11 15:30:43 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-10-11 15:30:43 --> Database Driver Class Initialized
DEBUG - 2011-10-11 15:30:43 --> File loaded: application/views/table/main.php
DEBUG - 2011-10-11 15:30:43 --> Helper loaded: url_helper
DEBUG - 2011-10-11 15:30:43 --> File loaded: application/views/common/header.php
DEBUG - 2011-10-11 15:30:43 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-10-11 15:30:43 --> File loaded: application/views/common/footer.php
DEBUG - 2011-10-11 15:30:43 --> File loaded: application/views/layout/main.php
DEBUG - 2011-10-11 15:30:43 --> Final output sent to browser
DEBUG - 2011-10-11 15:30:43 --> Total execution time: 0.2852
DEBUG - 2011-10-11 15:30:46 --> Config Class Initialized
DEBUG - 2011-10-11 15:30:46 --> Hooks Class Initialized
DEBUG - 2011-10-11 15:30:46 --> Utf8 Class Initialized
DEBUG - 2011-10-11 15:30:46 --> UTF-8 Support Enabled
DEBUG - 2011-10-11 15:30:46 --> URI Class Initialized
DEBUG - 2011-10-11 15:30:46 --> Router Class Initialized
DEBUG - 2011-10-11 15:30:46 --> Output Class Initialized
DEBUG - 2011-10-11 15:30:46 --> Input Class Initialized
DEBUG - 2011-10-11 15:30:46 --> Global POST and COOKIE data sanitized
DEBUG - 2011-10-11 15:30:46 --> Language Class Initialized
DEBUG - 2011-10-11 15:30:46 --> Loader Class Initialized
DEBUG - 2011-10-11 15:30:46 --> Controller Class Initialized
DEBUG - 2011-10-11 15:30:46 --> Model Class Initialized
DEBUG - 2011-10-11 15:30:46 --> Model Class Initialized
DEBUG - 2011-10-11 15:30:46 --> Model Class Initialized
DEBUG - 2011-10-11 15:30:46 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-10-11 15:30:46 --> Database Driver Class Initialized
DEBUG - 2011-10-11 15:30:46 --> File loaded: application/views/table/main.php
DEBUG - 2011-10-11 15:30:46 --> Helper loaded: url_helper
DEBUG - 2011-10-11 15:30:46 --> File loaded: application/views/common/header.php
DEBUG - 2011-10-11 15:30:46 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-10-11 15:30:46 --> File loaded: application/views/common/footer.php
DEBUG - 2011-10-11 15:30:46 --> File loaded: application/views/layout/main.php
DEBUG - 2011-10-11 15:30:46 --> Final output sent to browser
DEBUG - 2011-10-11 15:30:46 --> Total execution time: 0.0562
DEBUG - 2011-10-11 15:31:10 --> Config Class Initialized
DEBUG - 2011-10-11 15:31:11 --> Hooks Class Initialized
DEBUG - 2011-10-11 15:31:11 --> Utf8 Class Initialized
DEBUG - 2011-10-11 15:31:11 --> UTF-8 Support Enabled
DEBUG - 2011-10-11 15:31:11 --> URI Class Initialized
DEBUG - 2011-10-11 15:31:11 --> Router Class Initialized
DEBUG - 2011-10-11 15:31:11 --> Output Class Initialized
DEBUG - 2011-10-11 15:31:11 --> Input Class Initialized
DEBUG - 2011-10-11 15:31:11 --> Global POST and COOKIE data sanitized
DEBUG - 2011-10-11 15:31:11 --> Language Class Initialized
DEBUG - 2011-10-11 15:31:11 --> Loader Class Initialized
DEBUG - 2011-10-11 15:31:11 --> Controller Class Initialized
DEBUG - 2011-10-11 15:31:11 --> Model Class Initialized
DEBUG - 2011-10-11 15:31:11 --> Model Class Initialized
DEBUG - 2011-10-11 15:31:11 --> Model Class Initialized
DEBUG - 2011-10-11 15:31:11 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-10-11 15:31:11 --> Database Driver Class Initialized
DEBUG - 2011-10-11 15:31:12 --> File loaded: application/views/table/main.php
DEBUG - 2011-10-11 15:31:12 --> Helper loaded: url_helper
DEBUG - 2011-10-11 15:31:12 --> File loaded: application/views/common/header.php
DEBUG - 2011-10-11 15:31:12 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-10-11 15:31:12 --> File loaded: application/views/common/footer.php
DEBUG - 2011-10-11 15:31:12 --> File loaded: application/views/layout/main.php
DEBUG - 2011-10-11 15:31:12 --> Final output sent to browser
DEBUG - 2011-10-11 15:31:12 --> Total execution time: 1.1558
DEBUG - 2011-10-11 15:31:14 --> Config Class Initialized
DEBUG - 2011-10-11 15:31:14 --> Hooks Class Initialized
DEBUG - 2011-10-11 15:31:14 --> Utf8 Class Initialized
DEBUG - 2011-10-11 15:31:14 --> UTF-8 Support Enabled
DEBUG - 2011-10-11 15:31:14 --> URI Class Initialized
DEBUG - 2011-10-11 15:31:14 --> Router Class Initialized
DEBUG - 2011-10-11 15:31:14 --> Output Class Initialized
DEBUG - 2011-10-11 15:31:14 --> Input Class Initialized
DEBUG - 2011-10-11 15:31:14 --> Global POST and COOKIE data sanitized
DEBUG - 2011-10-11 15:31:14 --> Language Class Initialized
DEBUG - 2011-10-11 15:31:14 --> Loader Class Initialized
DEBUG - 2011-10-11 15:31:14 --> Controller Class Initialized
DEBUG - 2011-10-11 15:31:14 --> Model Class Initialized
DEBUG - 2011-10-11 15:31:14 --> Model Class Initialized
DEBUG - 2011-10-11 15:31:14 --> Model Class Initialized
DEBUG - 2011-10-11 15:31:14 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-10-11 15:31:14 --> Database Driver Class Initialized
DEBUG - 2011-10-11 15:31:14 --> File loaded: application/views/table/main.php
DEBUG - 2011-10-11 15:31:14 --> Helper loaded: url_helper
DEBUG - 2011-10-11 15:31:14 --> File loaded: application/views/common/header.php
DEBUG - 2011-10-11 15:31:14 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-10-11 15:31:14 --> File loaded: application/views/common/footer.php
DEBUG - 2011-10-11 15:31:14 --> File loaded: application/views/layout/main.php
DEBUG - 2011-10-11 15:31:14 --> Final output sent to browser
DEBUG - 2011-10-11 15:31:14 --> Total execution time: 0.0557
DEBUG - 2011-10-11 15:31:47 --> Config Class Initialized
DEBUG - 2011-10-11 15:31:47 --> Hooks Class Initialized
DEBUG - 2011-10-11 15:31:47 --> Utf8 Class Initialized
DEBUG - 2011-10-11 15:31:47 --> UTF-8 Support Enabled
DEBUG - 2011-10-11 15:31:47 --> URI Class Initialized
DEBUG - 2011-10-11 15:31:47 --> Router Class Initialized
DEBUG - 2011-10-11 15:31:47 --> Output Class Initialized
DEBUG - 2011-10-11 15:31:47 --> Input Class Initialized
DEBUG - 2011-10-11 15:31:47 --> Global POST and COOKIE data sanitized
DEBUG - 2011-10-11 15:31:47 --> Language Class Initialized
DEBUG - 2011-10-11 15:31:47 --> Loader Class Initialized
DEBUG - 2011-10-11 15:31:47 --> Controller Class Initialized
DEBUG - 2011-10-11 15:31:47 --> Model Class Initialized
DEBUG - 2011-10-11 15:31:47 --> Model Class Initialized
DEBUG - 2011-10-11 15:31:47 --> Model Class Initialized
DEBUG - 2011-10-11 15:31:47 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-10-11 15:31:47 --> Database Driver Class Initialized
DEBUG - 2011-10-11 15:31:47 --> File loaded: application/views/table/main.php
DEBUG - 2011-10-11 15:31:47 --> Helper loaded: url_helper
DEBUG - 2011-10-11 15:31:47 --> File loaded: application/views/common/header.php
DEBUG - 2011-10-11 15:31:47 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-10-11 15:31:47 --> File loaded: application/views/common/footer.php
DEBUG - 2011-10-11 15:31:47 --> File loaded: application/views/layout/main.php
DEBUG - 2011-10-11 15:31:47 --> Final output sent to browser
DEBUG - 2011-10-11 15:31:47 --> Total execution time: 0.2286
DEBUG - 2011-10-11 15:31:50 --> Config Class Initialized
DEBUG - 2011-10-11 15:31:50 --> Hooks Class Initialized
DEBUG - 2011-10-11 15:31:50 --> Utf8 Class Initialized
DEBUG - 2011-10-11 15:31:50 --> UTF-8 Support Enabled
DEBUG - 2011-10-11 15:31:50 --> URI Class Initialized
DEBUG - 2011-10-11 15:31:50 --> Router Class Initialized
DEBUG - 2011-10-11 15:31:50 --> Output Class Initialized
DEBUG - 2011-10-11 15:31:50 --> Input Class Initialized
DEBUG - 2011-10-11 15:31:50 --> Global POST and COOKIE data sanitized
DEBUG - 2011-10-11 15:31:50 --> Language Class Initialized
DEBUG - 2011-10-11 15:31:50 --> Loader Class Initialized
DEBUG - 2011-10-11 15:31:50 --> Controller Class Initialized
DEBUG - 2011-10-11 15:31:50 --> Model Class Initialized
DEBUG - 2011-10-11 15:31:50 --> Model Class Initialized
DEBUG - 2011-10-11 15:31:50 --> Model Class Initialized
DEBUG - 2011-10-11 15:31:50 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-10-11 15:31:50 --> Database Driver Class Initialized
DEBUG - 2011-10-11 15:31:50 --> File loaded: application/views/table/main.php
DEBUG - 2011-10-11 15:31:50 --> Helper loaded: url_helper
DEBUG - 2011-10-11 15:31:50 --> File loaded: application/views/common/header.php
DEBUG - 2011-10-11 15:31:50 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-10-11 15:31:50 --> File loaded: application/views/common/footer.php
DEBUG - 2011-10-11 15:31:50 --> File loaded: application/views/layout/main.php
DEBUG - 2011-10-11 15:31:50 --> Final output sent to browser
DEBUG - 2011-10-11 15:31:50 --> Total execution time: 0.0498
DEBUG - 2011-10-11 15:55:54 --> Config Class Initialized
DEBUG - 2011-10-11 15:55:54 --> Hooks Class Initialized
DEBUG - 2011-10-11 15:55:54 --> Utf8 Class Initialized
DEBUG - 2011-10-11 15:55:54 --> UTF-8 Support Enabled
DEBUG - 2011-10-11 15:55:54 --> URI Class Initialized
DEBUG - 2011-10-11 15:55:54 --> Router Class Initialized
DEBUG - 2011-10-11 15:55:54 --> Output Class Initialized
DEBUG - 2011-10-11 15:55:54 --> Input Class Initialized
DEBUG - 2011-10-11 15:55:54 --> Global POST and COOKIE data sanitized
DEBUG - 2011-10-11 15:55:54 --> Language Class Initialized
DEBUG - 2011-10-11 15:55:54 --> Loader Class Initialized
DEBUG - 2011-10-11 15:55:54 --> Controller Class Initialized
DEBUG - 2011-10-11 15:55:54 --> Model Class Initialized
DEBUG - 2011-10-11 15:55:54 --> Model Class Initialized
DEBUG - 2011-10-11 15:55:54 --> Model Class Initialized
DEBUG - 2011-10-11 15:55:54 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-10-11 15:55:54 --> Database Driver Class Initialized
DEBUG - 2011-10-11 15:55:55 --> File loaded: application/views/table/main.php
DEBUG - 2011-10-11 15:55:55 --> Helper loaded: url_helper
DEBUG - 2011-10-11 15:55:55 --> File loaded: application/views/common/header.php
DEBUG - 2011-10-11 15:55:55 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-10-11 15:55:55 --> File loaded: application/views/common/footer.php
DEBUG - 2011-10-11 15:55:55 --> File loaded: application/views/layout/main.php
DEBUG - 2011-10-11 15:55:55 --> Final output sent to browser
DEBUG - 2011-10-11 15:55:55 --> Total execution time: 0.3610
DEBUG - 2011-10-11 15:56:44 --> Config Class Initialized
DEBUG - 2011-10-11 15:56:44 --> Hooks Class Initialized
DEBUG - 2011-10-11 15:56:44 --> Utf8 Class Initialized
DEBUG - 2011-10-11 15:56:44 --> UTF-8 Support Enabled
DEBUG - 2011-10-11 15:56:44 --> URI Class Initialized
DEBUG - 2011-10-11 15:56:44 --> Router Class Initialized
ERROR - 2011-10-11 15:56:44 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-10-11 15:56:45 --> Config Class Initialized
DEBUG - 2011-10-11 15:56:45 --> Hooks Class Initialized
DEBUG - 2011-10-11 15:56:45 --> Utf8 Class Initialized
DEBUG - 2011-10-11 15:56:45 --> UTF-8 Support Enabled
DEBUG - 2011-10-11 15:56:45 --> URI Class Initialized
DEBUG - 2011-10-11 15:56:45 --> Router Class Initialized
ERROR - 2011-10-11 15:56:45 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-10-11 15:56:46 --> Config Class Initialized
DEBUG - 2011-10-11 15:56:46 --> Hooks Class Initialized
DEBUG - 2011-10-11 15:56:46 --> Utf8 Class Initialized
DEBUG - 2011-10-11 15:56:46 --> UTF-8 Support Enabled
DEBUG - 2011-10-11 15:56:46 --> URI Class Initialized
DEBUG - 2011-10-11 15:56:46 --> Router Class Initialized
ERROR - 2011-10-11 15:56:46 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-10-11 16:00:09 --> Config Class Initialized
DEBUG - 2011-10-11 16:00:09 --> Hooks Class Initialized
DEBUG - 2011-10-11 16:00:09 --> Utf8 Class Initialized
DEBUG - 2011-10-11 16:00:09 --> UTF-8 Support Enabled
DEBUG - 2011-10-11 16:00:09 --> URI Class Initialized
DEBUG - 2011-10-11 16:00:09 --> Router Class Initialized
DEBUG - 2011-10-11 16:00:09 --> Output Class Initialized
DEBUG - 2011-10-11 16:00:09 --> Input Class Initialized
DEBUG - 2011-10-11 16:00:09 --> Global POST and COOKIE data sanitized
DEBUG - 2011-10-11 16:00:09 --> Language Class Initialized
DEBUG - 2011-10-11 16:00:09 --> Loader Class Initialized
DEBUG - 2011-10-11 16:00:09 --> Controller Class Initialized
ERROR - 2011-10-11 16:00:09 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-10-11 16:00:09 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-10-11 16:00:09 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-10-11 16:00:09 --> Model Class Initialized
DEBUG - 2011-10-11 16:00:09 --> Model Class Initialized
DEBUG - 2011-10-11 16:00:09 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-10-11 16:00:09 --> Database Driver Class Initialized
DEBUG - 2011-10-11 16:00:09 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-10-11 16:00:09 --> Helper loaded: url_helper
DEBUG - 2011-10-11 16:00:09 --> File loaded: application/views/common/header.php
DEBUG - 2011-10-11 16:00:09 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-10-11 16:00:09 --> File loaded: application/views/common/footer.php
DEBUG - 2011-10-11 16:00:09 --> File loaded: application/views/layout/main.php
DEBUG - 2011-10-11 16:00:09 --> Final output sent to browser
DEBUG - 2011-10-11 16:00:09 --> Total execution time: 0.1314
DEBUG - 2011-10-11 16:00:10 --> Config Class Initialized
DEBUG - 2011-10-11 16:00:10 --> Hooks Class Initialized
DEBUG - 2011-10-11 16:00:10 --> Utf8 Class Initialized
DEBUG - 2011-10-11 16:00:10 --> UTF-8 Support Enabled
DEBUG - 2011-10-11 16:00:10 --> URI Class Initialized
DEBUG - 2011-10-11 16:00:10 --> Router Class Initialized
DEBUG - 2011-10-11 16:00:10 --> Output Class Initialized
DEBUG - 2011-10-11 16:00:10 --> Input Class Initialized
DEBUG - 2011-10-11 16:00:10 --> Global POST and COOKIE data sanitized
DEBUG - 2011-10-11 16:00:10 --> Language Class Initialized
DEBUG - 2011-10-11 16:00:10 --> Loader Class Initialized
DEBUG - 2011-10-11 16:00:10 --> Controller Class Initialized
DEBUG - 2011-10-11 16:00:10 --> Model Class Initialized
DEBUG - 2011-10-11 16:00:10 --> Model Class Initialized
DEBUG - 2011-10-11 16:00:10 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-10-11 16:00:10 --> Database Driver Class Initialized
DEBUG - 2011-10-11 16:00:11 --> Final output sent to browser
DEBUG - 2011-10-11 16:00:11 --> Total execution time: 0.7097
DEBUG - 2011-10-11 16:30:05 --> Config Class Initialized
DEBUG - 2011-10-11 16:30:05 --> Hooks Class Initialized
DEBUG - 2011-10-11 16:30:05 --> Utf8 Class Initialized
DEBUG - 2011-10-11 16:30:05 --> UTF-8 Support Enabled
DEBUG - 2011-10-11 16:30:05 --> URI Class Initialized
DEBUG - 2011-10-11 16:30:05 --> Router Class Initialized
DEBUG - 2011-10-11 16:30:05 --> Output Class Initialized
DEBUG - 2011-10-11 16:30:05 --> Input Class Initialized
DEBUG - 2011-10-11 16:30:05 --> Global POST and COOKIE data sanitized
DEBUG - 2011-10-11 16:30:05 --> Language Class Initialized
DEBUG - 2011-10-11 16:30:06 --> Loader Class Initialized
DEBUG - 2011-10-11 16:30:06 --> Controller Class Initialized
ERROR - 2011-10-11 16:30:06 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-10-11 16:30:06 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-10-11 16:30:06 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-10-11 16:30:06 --> Model Class Initialized
DEBUG - 2011-10-11 16:30:06 --> Model Class Initialized
DEBUG - 2011-10-11 16:30:06 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-10-11 16:30:06 --> Database Driver Class Initialized
DEBUG - 2011-10-11 16:30:06 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-10-11 16:30:06 --> Helper loaded: url_helper
DEBUG - 2011-10-11 16:30:06 --> File loaded: application/views/common/header.php
DEBUG - 2011-10-11 16:30:06 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-10-11 16:30:06 --> File loaded: application/views/common/footer.php
DEBUG - 2011-10-11 16:30:06 --> File loaded: application/views/layout/main.php
DEBUG - 2011-10-11 16:30:06 --> Final output sent to browser
DEBUG - 2011-10-11 16:30:06 --> Total execution time: 0.4375
DEBUG - 2011-10-11 16:30:17 --> Config Class Initialized
DEBUG - 2011-10-11 16:30:17 --> Hooks Class Initialized
DEBUG - 2011-10-11 16:30:17 --> Utf8 Class Initialized
DEBUG - 2011-10-11 16:30:17 --> UTF-8 Support Enabled
DEBUG - 2011-10-11 16:30:17 --> URI Class Initialized
DEBUG - 2011-10-11 16:30:17 --> Router Class Initialized
DEBUG - 2011-10-11 16:30:17 --> Output Class Initialized
DEBUG - 2011-10-11 16:30:17 --> Input Class Initialized
DEBUG - 2011-10-11 16:30:17 --> Global POST and COOKIE data sanitized
DEBUG - 2011-10-11 16:30:17 --> Language Class Initialized
DEBUG - 2011-10-11 16:30:17 --> Loader Class Initialized
DEBUG - 2011-10-11 16:30:17 --> Controller Class Initialized
DEBUG - 2011-10-11 16:30:17 --> Model Class Initialized
DEBUG - 2011-10-11 16:30:17 --> Model Class Initialized
DEBUG - 2011-10-11 16:30:17 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-10-11 16:30:17 --> Database Driver Class Initialized
DEBUG - 2011-10-11 16:30:18 --> Final output sent to browser
DEBUG - 2011-10-11 16:30:18 --> Total execution time: 0.7896
DEBUG - 2011-10-11 16:30:30 --> Config Class Initialized
DEBUG - 2011-10-11 16:30:30 --> Hooks Class Initialized
DEBUG - 2011-10-11 16:30:30 --> Utf8 Class Initialized
DEBUG - 2011-10-11 16:30:30 --> UTF-8 Support Enabled
DEBUG - 2011-10-11 16:30:30 --> URI Class Initialized
DEBUG - 2011-10-11 16:30:30 --> Router Class Initialized
ERROR - 2011-10-11 16:30:30 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-10-11 16:30:30 --> Config Class Initialized
DEBUG - 2011-10-11 16:30:30 --> Hooks Class Initialized
DEBUG - 2011-10-11 16:30:30 --> Utf8 Class Initialized
DEBUG - 2011-10-11 16:30:30 --> UTF-8 Support Enabled
DEBUG - 2011-10-11 16:30:30 --> URI Class Initialized
DEBUG - 2011-10-11 16:30:31 --> Router Class Initialized
ERROR - 2011-10-11 16:30:31 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-10-11 16:30:31 --> Config Class Initialized
DEBUG - 2011-10-11 16:30:31 --> Hooks Class Initialized
DEBUG - 2011-10-11 16:30:31 --> Utf8 Class Initialized
DEBUG - 2011-10-11 16:30:31 --> UTF-8 Support Enabled
DEBUG - 2011-10-11 16:30:31 --> URI Class Initialized
DEBUG - 2011-10-11 16:30:31 --> Router Class Initialized
ERROR - 2011-10-11 16:30:31 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-10-11 16:32:03 --> Config Class Initialized
DEBUG - 2011-10-11 16:32:03 --> Hooks Class Initialized
DEBUG - 2011-10-11 16:32:03 --> Utf8 Class Initialized
DEBUG - 2011-10-11 16:32:03 --> UTF-8 Support Enabled
DEBUG - 2011-10-11 16:32:03 --> URI Class Initialized
DEBUG - 2011-10-11 16:32:03 --> Router Class Initialized
DEBUG - 2011-10-11 16:32:03 --> Output Class Initialized
DEBUG - 2011-10-11 16:32:03 --> Input Class Initialized
DEBUG - 2011-10-11 16:32:03 --> Global POST and COOKIE data sanitized
DEBUG - 2011-10-11 16:32:03 --> Language Class Initialized
DEBUG - 2011-10-11 16:32:03 --> Loader Class Initialized
DEBUG - 2011-10-11 16:32:03 --> Controller Class Initialized
ERROR - 2011-10-11 16:32:03 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-10-11 16:32:03 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-10-11 16:32:03 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-10-11 16:32:03 --> Model Class Initialized
DEBUG - 2011-10-11 16:32:03 --> Model Class Initialized
DEBUG - 2011-10-11 16:32:03 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-10-11 16:32:03 --> Database Driver Class Initialized
DEBUG - 2011-10-11 16:32:03 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-10-11 16:32:03 --> Helper loaded: url_helper
DEBUG - 2011-10-11 16:32:03 --> File loaded: application/views/common/header.php
DEBUG - 2011-10-11 16:32:03 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-10-11 16:32:03 --> File loaded: application/views/common/footer.php
DEBUG - 2011-10-11 16:32:03 --> File loaded: application/views/layout/main.php
DEBUG - 2011-10-11 16:32:03 --> Final output sent to browser
DEBUG - 2011-10-11 16:32:03 --> Total execution time: 0.0329
DEBUG - 2011-10-11 17:49:09 --> Config Class Initialized
DEBUG - 2011-10-11 17:49:09 --> Hooks Class Initialized
DEBUG - 2011-10-11 17:49:09 --> Utf8 Class Initialized
DEBUG - 2011-10-11 17:49:09 --> UTF-8 Support Enabled
DEBUG - 2011-10-11 17:49:09 --> URI Class Initialized
DEBUG - 2011-10-11 17:49:09 --> Router Class Initialized
ERROR - 2011-10-11 17:49:09 --> 404 Page Not Found --> robots.txt
DEBUG - 2011-10-11 18:21:57 --> Config Class Initialized
DEBUG - 2011-10-11 18:21:57 --> Hooks Class Initialized
DEBUG - 2011-10-11 18:21:57 --> Utf8 Class Initialized
DEBUG - 2011-10-11 18:21:57 --> UTF-8 Support Enabled
DEBUG - 2011-10-11 18:21:57 --> URI Class Initialized
DEBUG - 2011-10-11 18:21:57 --> Router Class Initialized
DEBUG - 2011-10-11 18:21:57 --> Output Class Initialized
DEBUG - 2011-10-11 18:21:57 --> Input Class Initialized
DEBUG - 2011-10-11 18:21:57 --> Global POST and COOKIE data sanitized
DEBUG - 2011-10-11 18:21:57 --> Language Class Initialized
DEBUG - 2011-10-11 18:21:57 --> Loader Class Initialized
DEBUG - 2011-10-11 18:21:57 --> Controller Class Initialized
ERROR - 2011-10-11 18:21:57 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-10-11 18:21:57 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-10-11 18:21:57 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-10-11 18:21:57 --> Model Class Initialized
DEBUG - 2011-10-11 18:21:57 --> Model Class Initialized
DEBUG - 2011-10-11 18:21:57 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-10-11 18:21:57 --> Database Driver Class Initialized
DEBUG - 2011-10-11 18:21:58 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-10-11 18:21:58 --> Helper loaded: url_helper
DEBUG - 2011-10-11 18:21:58 --> File loaded: application/views/common/header.php
DEBUG - 2011-10-11 18:21:58 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-10-11 18:21:58 --> File loaded: application/views/common/footer.php
DEBUG - 2011-10-11 18:21:58 --> File loaded: application/views/layout/main.php
DEBUG - 2011-10-11 18:21:58 --> Final output sent to browser
DEBUG - 2011-10-11 18:21:58 --> Total execution time: 0.6693
DEBUG - 2011-10-11 19:03:21 --> Config Class Initialized
DEBUG - 2011-10-11 19:03:21 --> Hooks Class Initialized
DEBUG - 2011-10-11 19:03:21 --> Utf8 Class Initialized
DEBUG - 2011-10-11 19:03:21 --> UTF-8 Support Enabled
DEBUG - 2011-10-11 19:03:21 --> URI Class Initialized
DEBUG - 2011-10-11 19:03:21 --> Router Class Initialized
ERROR - 2011-10-11 19:03:21 --> 404 Page Not Found --> robots.txt
DEBUG - 2011-10-11 19:03:21 --> Config Class Initialized
DEBUG - 2011-10-11 19:03:21 --> Hooks Class Initialized
DEBUG - 2011-10-11 19:03:21 --> Utf8 Class Initialized
DEBUG - 2011-10-11 19:03:21 --> UTF-8 Support Enabled
DEBUG - 2011-10-11 19:03:21 --> URI Class Initialized
DEBUG - 2011-10-11 19:03:21 --> Router Class Initialized
DEBUG - 2011-10-11 19:03:21 --> Output Class Initialized
DEBUG - 2011-10-11 19:03:21 --> Input Class Initialized
DEBUG - 2011-10-11 19:03:21 --> Global POST and COOKIE data sanitized
DEBUG - 2011-10-11 19:03:21 --> Language Class Initialized
DEBUG - 2011-10-11 19:03:21 --> Loader Class Initialized
DEBUG - 2011-10-11 19:03:21 --> Controller Class Initialized
DEBUG - 2011-10-11 19:03:21 --> Model Class Initialized
DEBUG - 2011-10-11 19:03:21 --> Model Class Initialized
DEBUG - 2011-10-11 19:03:21 --> Model Class Initialized
DEBUG - 2011-10-11 19:03:21 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-10-11 19:03:21 --> Database Driver Class Initialized
DEBUG - 2011-10-11 19:03:23 --> File loaded: application/views/table/main.php
DEBUG - 2011-10-11 19:03:23 --> Helper loaded: url_helper
DEBUG - 2011-10-11 19:03:23 --> File loaded: application/views/common/header.php
DEBUG - 2011-10-11 19:03:23 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-10-11 19:03:23 --> File loaded: application/views/common/footer.php
DEBUG - 2011-10-11 19:03:23 --> File loaded: application/views/layout/main.php
DEBUG - 2011-10-11 19:03:23 --> Final output sent to browser
DEBUG - 2011-10-11 19:03:23 --> Total execution time: 2.1171
DEBUG - 2011-10-11 19:46:20 --> Config Class Initialized
DEBUG - 2011-10-11 19:46:20 --> Hooks Class Initialized
DEBUG - 2011-10-11 19:46:20 --> Utf8 Class Initialized
DEBUG - 2011-10-11 19:46:20 --> UTF-8 Support Enabled
DEBUG - 2011-10-11 19:46:20 --> URI Class Initialized
DEBUG - 2011-10-11 19:46:20 --> Router Class Initialized
DEBUG - 2011-10-11 19:46:20 --> No URI present. Default controller set.
DEBUG - 2011-10-11 19:46:20 --> Output Class Initialized
DEBUG - 2011-10-11 19:46:20 --> Input Class Initialized
DEBUG - 2011-10-11 19:46:20 --> Global POST and COOKIE data sanitized
DEBUG - 2011-10-11 19:46:20 --> Language Class Initialized
DEBUG - 2011-10-11 19:46:20 --> Loader Class Initialized
DEBUG - 2011-10-11 19:46:20 --> Controller Class Initialized
DEBUG - 2011-10-11 19:46:20 --> File loaded: application/views/splash/main.php
DEBUG - 2011-10-11 19:46:20 --> Helper loaded: url_helper
DEBUG - 2011-10-11 19:46:20 --> File loaded: application/views/common/header.php
DEBUG - 2011-10-11 19:46:20 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-10-11 19:46:20 --> File loaded: application/views/common/footer.php
DEBUG - 2011-10-11 19:46:20 --> File loaded: application/views/layout/main.php
DEBUG - 2011-10-11 19:46:20 --> Final output sent to browser
DEBUG - 2011-10-11 19:46:20 --> Total execution time: 0.0575
DEBUG - 2011-10-11 21:43:14 --> Config Class Initialized
DEBUG - 2011-10-11 21:43:14 --> Hooks Class Initialized
DEBUG - 2011-10-11 21:43:14 --> Utf8 Class Initialized
DEBUG - 2011-10-11 21:43:14 --> UTF-8 Support Enabled
DEBUG - 2011-10-11 21:43:14 --> URI Class Initialized
DEBUG - 2011-10-11 21:43:14 --> Router Class Initialized
DEBUG - 2011-10-11 21:43:14 --> Output Class Initialized
DEBUG - 2011-10-11 21:43:14 --> Input Class Initialized
DEBUG - 2011-10-11 21:43:14 --> Global POST and COOKIE data sanitized
DEBUG - 2011-10-11 21:43:14 --> Language Class Initialized
DEBUG - 2011-10-11 21:43:14 --> Loader Class Initialized
DEBUG - 2011-10-11 21:43:14 --> Controller Class Initialized
DEBUG - 2011-10-11 21:43:14 --> Model Class Initialized
DEBUG - 2011-10-11 21:43:14 --> Model Class Initialized
DEBUG - 2011-10-11 21:43:14 --> Model Class Initialized
DEBUG - 2011-10-11 21:43:14 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-10-11 21:43:14 --> Database Driver Class Initialized
DEBUG - 2011-10-11 21:43:16 --> File loaded: application/views/table/main.php
DEBUG - 2011-10-11 21:43:16 --> Helper loaded: url_helper
DEBUG - 2011-10-11 21:43:16 --> File loaded: application/views/common/header.php
DEBUG - 2011-10-11 21:43:16 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-10-11 21:43:16 --> File loaded: application/views/common/footer.php
DEBUG - 2011-10-11 21:43:16 --> File loaded: application/views/layout/main.php
DEBUG - 2011-10-11 21:43:16 --> Final output sent to browser
DEBUG - 2011-10-11 21:43:16 --> Total execution time: 1.2502
DEBUG - 2011-10-11 21:43:42 --> Config Class Initialized
DEBUG - 2011-10-11 21:43:42 --> Hooks Class Initialized
DEBUG - 2011-10-11 21:43:42 --> Utf8 Class Initialized
DEBUG - 2011-10-11 21:43:42 --> UTF-8 Support Enabled
DEBUG - 2011-10-11 21:43:42 --> URI Class Initialized
DEBUG - 2011-10-11 21:43:42 --> Router Class Initialized
DEBUG - 2011-10-11 21:43:42 --> Output Class Initialized
DEBUG - 2011-10-11 21:43:42 --> Input Class Initialized
DEBUG - 2011-10-11 21:43:42 --> Global POST and COOKIE data sanitized
DEBUG - 2011-10-11 21:43:42 --> Language Class Initialized
DEBUG - 2011-10-11 21:43:42 --> Loader Class Initialized
DEBUG - 2011-10-11 21:43:42 --> Controller Class Initialized
DEBUG - 2011-10-11 21:43:42 --> Model Class Initialized
DEBUG - 2011-10-11 21:43:42 --> Model Class Initialized
DEBUG - 2011-10-11 21:43:42 --> Model Class Initialized
DEBUG - 2011-10-11 21:43:42 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-10-11 21:43:42 --> Database Driver Class Initialized
DEBUG - 2011-10-11 21:43:42 --> File loaded: application/views/table/main.php
DEBUG - 2011-10-11 21:43:42 --> Helper loaded: url_helper
DEBUG - 2011-10-11 21:43:42 --> File loaded: application/views/common/header.php
DEBUG - 2011-10-11 21:43:42 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-10-11 21:43:42 --> File loaded: application/views/common/footer.php
DEBUG - 2011-10-11 21:43:42 --> File loaded: application/views/layout/main.php
DEBUG - 2011-10-11 21:43:42 --> Final output sent to browser
DEBUG - 2011-10-11 21:43:42 --> Total execution time: 0.2932
DEBUG - 2011-10-11 21:43:45 --> Config Class Initialized
DEBUG - 2011-10-11 21:43:45 --> Hooks Class Initialized
DEBUG - 2011-10-11 21:43:45 --> Utf8 Class Initialized
DEBUG - 2011-10-11 21:43:45 --> UTF-8 Support Enabled
DEBUG - 2011-10-11 21:43:45 --> URI Class Initialized
DEBUG - 2011-10-11 21:43:45 --> Router Class Initialized
DEBUG - 2011-10-11 21:43:45 --> Output Class Initialized
DEBUG - 2011-10-11 21:43:45 --> Input Class Initialized
DEBUG - 2011-10-11 21:43:45 --> Global POST and COOKIE data sanitized
DEBUG - 2011-10-11 21:43:45 --> Language Class Initialized
DEBUG - 2011-10-11 21:43:45 --> Loader Class Initialized
DEBUG - 2011-10-11 21:43:45 --> Controller Class Initialized
DEBUG - 2011-10-11 21:43:45 --> Model Class Initialized
DEBUG - 2011-10-11 21:43:45 --> Model Class Initialized
DEBUG - 2011-10-11 21:43:45 --> Model Class Initialized
DEBUG - 2011-10-11 21:43:45 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-10-11 21:43:45 --> Database Driver Class Initialized
DEBUG - 2011-10-11 21:43:45 --> File loaded: application/views/table/main.php
DEBUG - 2011-10-11 21:43:45 --> Helper loaded: url_helper
DEBUG - 2011-10-11 21:43:45 --> File loaded: application/views/common/header.php
DEBUG - 2011-10-11 21:43:45 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-10-11 21:43:45 --> File loaded: application/views/common/footer.php
DEBUG - 2011-10-11 21:43:45 --> File loaded: application/views/layout/main.php
DEBUG - 2011-10-11 21:43:45 --> Final output sent to browser
DEBUG - 2011-10-11 21:43:45 --> Total execution time: 0.0462
DEBUG - 2011-10-11 21:44:11 --> Config Class Initialized
DEBUG - 2011-10-11 21:44:11 --> Hooks Class Initialized
DEBUG - 2011-10-11 21:44:11 --> Utf8 Class Initialized
DEBUG - 2011-10-11 21:44:11 --> UTF-8 Support Enabled
DEBUG - 2011-10-11 21:44:11 --> URI Class Initialized
DEBUG - 2011-10-11 21:44:11 --> Router Class Initialized
DEBUG - 2011-10-11 21:44:11 --> Output Class Initialized
DEBUG - 2011-10-11 21:44:11 --> Input Class Initialized
DEBUG - 2011-10-11 21:44:11 --> Global POST and COOKIE data sanitized
DEBUG - 2011-10-11 21:44:11 --> Language Class Initialized
DEBUG - 2011-10-11 21:44:11 --> Loader Class Initialized
DEBUG - 2011-10-11 21:44:11 --> Controller Class Initialized
DEBUG - 2011-10-11 21:44:11 --> Model Class Initialized
DEBUG - 2011-10-11 21:44:11 --> Model Class Initialized
DEBUG - 2011-10-11 21:44:11 --> Model Class Initialized
DEBUG - 2011-10-11 21:44:11 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-10-11 21:44:11 --> Database Driver Class Initialized
DEBUG - 2011-10-11 21:44:11 --> File loaded: application/views/table/main.php
DEBUG - 2011-10-11 21:44:11 --> Helper loaded: url_helper
DEBUG - 2011-10-11 21:44:11 --> File loaded: application/views/common/header.php
DEBUG - 2011-10-11 21:44:11 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-10-11 21:44:11 --> File loaded: application/views/common/footer.php
DEBUG - 2011-10-11 21:44:11 --> File loaded: application/views/layout/main.php
DEBUG - 2011-10-11 21:44:11 --> Final output sent to browser
DEBUG - 2011-10-11 21:44:11 --> Total execution time: 0.3427
DEBUG - 2011-10-11 21:44:15 --> Config Class Initialized
DEBUG - 2011-10-11 21:44:15 --> Hooks Class Initialized
DEBUG - 2011-10-11 21:44:15 --> Utf8 Class Initialized
DEBUG - 2011-10-11 21:44:15 --> UTF-8 Support Enabled
DEBUG - 2011-10-11 21:44:15 --> URI Class Initialized
DEBUG - 2011-10-11 21:44:15 --> Router Class Initialized
DEBUG - 2011-10-11 21:44:15 --> Output Class Initialized
DEBUG - 2011-10-11 21:44:15 --> Input Class Initialized
DEBUG - 2011-10-11 21:44:15 --> Global POST and COOKIE data sanitized
DEBUG - 2011-10-11 21:44:15 --> Language Class Initialized
DEBUG - 2011-10-11 21:44:15 --> Loader Class Initialized
DEBUG - 2011-10-11 21:44:15 --> Controller Class Initialized
DEBUG - 2011-10-11 21:44:15 --> Model Class Initialized
DEBUG - 2011-10-11 21:44:15 --> Model Class Initialized
DEBUG - 2011-10-11 21:44:15 --> Model Class Initialized
DEBUG - 2011-10-11 21:44:15 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-10-11 21:44:15 --> Database Driver Class Initialized
DEBUG - 2011-10-11 21:44:15 --> File loaded: application/views/table/main.php
DEBUG - 2011-10-11 21:44:15 --> Helper loaded: url_helper
DEBUG - 2011-10-11 21:44:15 --> File loaded: application/views/common/header.php
DEBUG - 2011-10-11 21:44:15 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-10-11 21:44:15 --> File loaded: application/views/common/footer.php
DEBUG - 2011-10-11 21:44:15 --> File loaded: application/views/layout/main.php
DEBUG - 2011-10-11 21:44:15 --> Final output sent to browser
DEBUG - 2011-10-11 21:44:15 --> Total execution time: 0.0489
DEBUG - 2011-10-11 21:44:33 --> Config Class Initialized
DEBUG - 2011-10-11 21:44:33 --> Hooks Class Initialized
DEBUG - 2011-10-11 21:44:33 --> Utf8 Class Initialized
DEBUG - 2011-10-11 21:44:33 --> UTF-8 Support Enabled
DEBUG - 2011-10-11 21:44:33 --> URI Class Initialized
DEBUG - 2011-10-11 21:44:33 --> Router Class Initialized
DEBUG - 2011-10-11 21:44:33 --> Output Class Initialized
DEBUG - 2011-10-11 21:44:33 --> Input Class Initialized
DEBUG - 2011-10-11 21:44:33 --> Global POST and COOKIE data sanitized
DEBUG - 2011-10-11 21:44:33 --> Language Class Initialized
DEBUG - 2011-10-11 21:44:33 --> Loader Class Initialized
DEBUG - 2011-10-11 21:44:33 --> Controller Class Initialized
DEBUG - 2011-10-11 21:44:33 --> Model Class Initialized
DEBUG - 2011-10-11 21:44:33 --> Model Class Initialized
DEBUG - 2011-10-11 21:44:33 --> Model Class Initialized
DEBUG - 2011-10-11 21:44:33 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-10-11 21:44:33 --> Database Driver Class Initialized
DEBUG - 2011-10-11 21:44:34 --> File loaded: application/views/table/main.php
DEBUG - 2011-10-11 21:44:34 --> Helper loaded: url_helper
DEBUG - 2011-10-11 21:44:34 --> File loaded: application/views/common/header.php
DEBUG - 2011-10-11 21:44:34 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-10-11 21:44:34 --> File loaded: application/views/common/footer.php
DEBUG - 2011-10-11 21:44:34 --> File loaded: application/views/layout/main.php
DEBUG - 2011-10-11 21:44:34 --> Final output sent to browser
DEBUG - 2011-10-11 21:44:34 --> Total execution time: 0.4047
DEBUG - 2011-10-11 21:44:36 --> Config Class Initialized
DEBUG - 2011-10-11 21:44:36 --> Hooks Class Initialized
DEBUG - 2011-10-11 21:44:36 --> Utf8 Class Initialized
DEBUG - 2011-10-11 21:44:36 --> UTF-8 Support Enabled
DEBUG - 2011-10-11 21:44:36 --> URI Class Initialized
DEBUG - 2011-10-11 21:44:36 --> Router Class Initialized
DEBUG - 2011-10-11 21:44:36 --> Output Class Initialized
DEBUG - 2011-10-11 21:44:36 --> Input Class Initialized
DEBUG - 2011-10-11 21:44:36 --> Global POST and COOKIE data sanitized
DEBUG - 2011-10-11 21:44:36 --> Language Class Initialized
DEBUG - 2011-10-11 21:44:36 --> Loader Class Initialized
DEBUG - 2011-10-11 21:44:36 --> Controller Class Initialized
DEBUG - 2011-10-11 21:44:36 --> Model Class Initialized
DEBUG - 2011-10-11 21:44:36 --> Model Class Initialized
DEBUG - 2011-10-11 21:44:36 --> Model Class Initialized
DEBUG - 2011-10-11 21:44:36 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-10-11 21:44:36 --> Database Driver Class Initialized
DEBUG - 2011-10-11 21:44:36 --> File loaded: application/views/table/main.php
DEBUG - 2011-10-11 21:44:36 --> Helper loaded: url_helper
DEBUG - 2011-10-11 21:44:36 --> File loaded: application/views/common/header.php
DEBUG - 2011-10-11 21:44:36 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-10-11 21:44:36 --> File loaded: application/views/common/footer.php
DEBUG - 2011-10-11 21:44:36 --> File loaded: application/views/layout/main.php
DEBUG - 2011-10-11 21:44:36 --> Final output sent to browser
DEBUG - 2011-10-11 21:44:36 --> Total execution time: 0.0485
DEBUG - 2011-10-11 21:45:22 --> Config Class Initialized
DEBUG - 2011-10-11 21:45:22 --> Hooks Class Initialized
DEBUG - 2011-10-11 21:45:22 --> Utf8 Class Initialized
DEBUG - 2011-10-11 21:45:22 --> UTF-8 Support Enabled
DEBUG - 2011-10-11 21:45:22 --> URI Class Initialized
DEBUG - 2011-10-11 21:45:22 --> Router Class Initialized
DEBUG - 2011-10-11 21:45:22 --> Output Class Initialized
DEBUG - 2011-10-11 21:45:22 --> Input Class Initialized
DEBUG - 2011-10-11 21:45:22 --> Global POST and COOKIE data sanitized
DEBUG - 2011-10-11 21:45:22 --> Language Class Initialized
DEBUG - 2011-10-11 21:45:22 --> Loader Class Initialized
DEBUG - 2011-10-11 21:45:22 --> Controller Class Initialized
DEBUG - 2011-10-11 21:45:22 --> Model Class Initialized
DEBUG - 2011-10-11 21:45:22 --> Model Class Initialized
DEBUG - 2011-10-11 21:45:22 --> Model Class Initialized
DEBUG - 2011-10-11 21:45:22 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-10-11 21:45:22 --> Database Driver Class Initialized
DEBUG - 2011-10-11 21:45:22 --> File loaded: application/views/table/main.php
DEBUG - 2011-10-11 21:45:22 --> Helper loaded: url_helper
DEBUG - 2011-10-11 21:45:22 --> File loaded: application/views/common/header.php
DEBUG - 2011-10-11 21:45:22 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-10-11 21:45:22 --> File loaded: application/views/common/footer.php
DEBUG - 2011-10-11 21:45:22 --> File loaded: application/views/layout/main.php
DEBUG - 2011-10-11 21:45:22 --> Final output sent to browser
DEBUG - 2011-10-11 21:45:22 --> Total execution time: 0.3257
DEBUG - 2011-10-11 21:45:27 --> Config Class Initialized
DEBUG - 2011-10-11 21:45:27 --> Hooks Class Initialized
DEBUG - 2011-10-11 21:45:27 --> Utf8 Class Initialized
DEBUG - 2011-10-11 21:45:27 --> UTF-8 Support Enabled
DEBUG - 2011-10-11 21:45:27 --> URI Class Initialized
DEBUG - 2011-10-11 21:45:27 --> Router Class Initialized
DEBUG - 2011-10-11 21:45:27 --> Output Class Initialized
DEBUG - 2011-10-11 21:45:27 --> Input Class Initialized
DEBUG - 2011-10-11 21:45:27 --> Global POST and COOKIE data sanitized
DEBUG - 2011-10-11 21:45:27 --> Language Class Initialized
DEBUG - 2011-10-11 21:45:27 --> Loader Class Initialized
DEBUG - 2011-10-11 21:45:27 --> Controller Class Initialized
DEBUG - 2011-10-11 21:45:27 --> Model Class Initialized
DEBUG - 2011-10-11 21:45:27 --> Model Class Initialized
DEBUG - 2011-10-11 21:45:27 --> Model Class Initialized
DEBUG - 2011-10-11 21:45:27 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-10-11 21:45:27 --> Database Driver Class Initialized
DEBUG - 2011-10-11 21:45:27 --> File loaded: application/views/table/main.php
DEBUG - 2011-10-11 21:45:27 --> Helper loaded: url_helper
DEBUG - 2011-10-11 21:45:27 --> File loaded: application/views/common/header.php
DEBUG - 2011-10-11 21:45:27 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-10-11 21:45:27 --> File loaded: application/views/common/footer.php
DEBUG - 2011-10-11 21:45:27 --> File loaded: application/views/layout/main.php
DEBUG - 2011-10-11 21:45:27 --> Final output sent to browser
DEBUG - 2011-10-11 21:45:27 --> Total execution time: 0.0580
DEBUG - 2011-10-11 21:45:46 --> Config Class Initialized
DEBUG - 2011-10-11 21:45:46 --> Hooks Class Initialized
DEBUG - 2011-10-11 21:45:46 --> Utf8 Class Initialized
DEBUG - 2011-10-11 21:45:46 --> UTF-8 Support Enabled
DEBUG - 2011-10-11 21:45:46 --> URI Class Initialized
DEBUG - 2011-10-11 21:45:46 --> Router Class Initialized
DEBUG - 2011-10-11 21:45:46 --> Output Class Initialized
DEBUG - 2011-10-11 21:45:46 --> Input Class Initialized
DEBUG - 2011-10-11 21:45:46 --> Global POST and COOKIE data sanitized
DEBUG - 2011-10-11 21:45:46 --> Language Class Initialized
DEBUG - 2011-10-11 21:45:46 --> Loader Class Initialized
DEBUG - 2011-10-11 21:45:46 --> Controller Class Initialized
DEBUG - 2011-10-11 21:45:46 --> Model Class Initialized
DEBUG - 2011-10-11 21:45:46 --> Model Class Initialized
DEBUG - 2011-10-11 21:45:46 --> Model Class Initialized
DEBUG - 2011-10-11 21:45:46 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-10-11 21:45:46 --> Database Driver Class Initialized
DEBUG - 2011-10-11 21:45:46 --> File loaded: application/views/table/main.php
DEBUG - 2011-10-11 21:45:46 --> Helper loaded: url_helper
DEBUG - 2011-10-11 21:45:46 --> File loaded: application/views/common/header.php
DEBUG - 2011-10-11 21:45:46 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-10-11 21:45:46 --> File loaded: application/views/common/footer.php
DEBUG - 2011-10-11 21:45:46 --> File loaded: application/views/layout/main.php
DEBUG - 2011-10-11 21:45:46 --> Final output sent to browser
DEBUG - 2011-10-11 21:45:46 --> Total execution time: 0.2253
DEBUG - 2011-10-11 21:45:49 --> Config Class Initialized
DEBUG - 2011-10-11 21:45:49 --> Hooks Class Initialized
DEBUG - 2011-10-11 21:45:49 --> Utf8 Class Initialized
DEBUG - 2011-10-11 21:45:49 --> UTF-8 Support Enabled
DEBUG - 2011-10-11 21:45:49 --> URI Class Initialized
DEBUG - 2011-10-11 21:45:49 --> Router Class Initialized
DEBUG - 2011-10-11 21:45:49 --> Output Class Initialized
DEBUG - 2011-10-11 21:45:49 --> Input Class Initialized
DEBUG - 2011-10-11 21:45:49 --> Global POST and COOKIE data sanitized
DEBUG - 2011-10-11 21:45:49 --> Language Class Initialized
DEBUG - 2011-10-11 21:45:49 --> Loader Class Initialized
DEBUG - 2011-10-11 21:45:49 --> Controller Class Initialized
DEBUG - 2011-10-11 21:45:49 --> Model Class Initialized
DEBUG - 2011-10-11 21:45:49 --> Model Class Initialized
DEBUG - 2011-10-11 21:45:49 --> Model Class Initialized
DEBUG - 2011-10-11 21:45:49 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-10-11 21:45:49 --> Database Driver Class Initialized
DEBUG - 2011-10-11 21:45:49 --> File loaded: application/views/table/main.php
DEBUG - 2011-10-11 21:45:49 --> Helper loaded: url_helper
DEBUG - 2011-10-11 21:45:49 --> File loaded: application/views/common/header.php
DEBUG - 2011-10-11 21:45:49 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-10-11 21:45:49 --> File loaded: application/views/common/footer.php
DEBUG - 2011-10-11 21:45:49 --> File loaded: application/views/layout/main.php
DEBUG - 2011-10-11 21:45:49 --> Final output sent to browser
DEBUG - 2011-10-11 21:45:49 --> Total execution time: 0.0549
DEBUG - 2011-10-11 21:46:18 --> Config Class Initialized
DEBUG - 2011-10-11 21:46:18 --> Hooks Class Initialized
DEBUG - 2011-10-11 21:46:18 --> Utf8 Class Initialized
DEBUG - 2011-10-11 21:46:18 --> UTF-8 Support Enabled
DEBUG - 2011-10-11 21:46:18 --> URI Class Initialized
DEBUG - 2011-10-11 21:46:18 --> Router Class Initialized
DEBUG - 2011-10-11 21:46:18 --> Output Class Initialized
DEBUG - 2011-10-11 21:46:18 --> Input Class Initialized
DEBUG - 2011-10-11 21:46:18 --> Global POST and COOKIE data sanitized
DEBUG - 2011-10-11 21:46:18 --> Language Class Initialized
DEBUG - 2011-10-11 21:46:18 --> Loader Class Initialized
DEBUG - 2011-10-11 21:46:18 --> Controller Class Initialized
DEBUG - 2011-10-11 21:46:18 --> Model Class Initialized
DEBUG - 2011-10-11 21:46:18 --> Model Class Initialized
DEBUG - 2011-10-11 21:46:18 --> Model Class Initialized
DEBUG - 2011-10-11 21:46:18 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-10-11 21:46:18 --> Database Driver Class Initialized
DEBUG - 2011-10-11 21:46:18 --> File loaded: application/views/table/main.php
DEBUG - 2011-10-11 21:46:18 --> Helper loaded: url_helper
DEBUG - 2011-10-11 21:46:18 --> File loaded: application/views/common/header.php
DEBUG - 2011-10-11 21:46:18 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-10-11 21:46:18 --> File loaded: application/views/common/footer.php
DEBUG - 2011-10-11 21:46:18 --> File loaded: application/views/layout/main.php
DEBUG - 2011-10-11 21:46:18 --> Final output sent to browser
DEBUG - 2011-10-11 21:46:18 --> Total execution time: 0.2181
DEBUG - 2011-10-11 21:46:41 --> Config Class Initialized
DEBUG - 2011-10-11 21:46:41 --> Hooks Class Initialized
DEBUG - 2011-10-11 21:46:41 --> Utf8 Class Initialized
DEBUG - 2011-10-11 21:46:41 --> UTF-8 Support Enabled
DEBUG - 2011-10-11 21:46:41 --> URI Class Initialized
DEBUG - 2011-10-11 21:46:41 --> Router Class Initialized
DEBUG - 2011-10-11 21:46:41 --> Output Class Initialized
DEBUG - 2011-10-11 21:46:41 --> Input Class Initialized
DEBUG - 2011-10-11 21:46:41 --> Global POST and COOKIE data sanitized
DEBUG - 2011-10-11 21:46:41 --> Language Class Initialized
DEBUG - 2011-10-11 21:46:41 --> Loader Class Initialized
DEBUG - 2011-10-11 21:46:41 --> Controller Class Initialized
DEBUG - 2011-10-11 21:46:41 --> Model Class Initialized
DEBUG - 2011-10-11 21:46:41 --> Model Class Initialized
DEBUG - 2011-10-11 21:46:41 --> Model Class Initialized
DEBUG - 2011-10-11 21:46:41 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-10-11 21:46:41 --> Database Driver Class Initialized
DEBUG - 2011-10-11 21:46:42 --> File loaded: application/views/table/main.php
DEBUG - 2011-10-11 21:46:42 --> Helper loaded: url_helper
DEBUG - 2011-10-11 21:46:42 --> File loaded: application/views/common/header.php
DEBUG - 2011-10-11 21:46:42 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-10-11 21:46:42 --> File loaded: application/views/common/footer.php
DEBUG - 2011-10-11 21:46:42 --> File loaded: application/views/layout/main.php
DEBUG - 2011-10-11 21:46:42 --> Final output sent to browser
DEBUG - 2011-10-11 21:46:42 --> Total execution time: 0.2235
DEBUG - 2011-10-11 21:47:00 --> Config Class Initialized
DEBUG - 2011-10-11 21:47:00 --> Hooks Class Initialized
DEBUG - 2011-10-11 21:47:00 --> Utf8 Class Initialized
DEBUG - 2011-10-11 21:47:00 --> UTF-8 Support Enabled
DEBUG - 2011-10-11 21:47:00 --> URI Class Initialized
DEBUG - 2011-10-11 21:47:00 --> Router Class Initialized
DEBUG - 2011-10-11 21:47:00 --> Output Class Initialized
DEBUG - 2011-10-11 21:47:00 --> Input Class Initialized
DEBUG - 2011-10-11 21:47:00 --> Global POST and COOKIE data sanitized
DEBUG - 2011-10-11 21:47:00 --> Language Class Initialized
DEBUG - 2011-10-11 21:47:00 --> Loader Class Initialized
DEBUG - 2011-10-11 21:47:00 --> Controller Class Initialized
DEBUG - 2011-10-11 21:47:00 --> Model Class Initialized
DEBUG - 2011-10-11 21:47:00 --> Model Class Initialized
DEBUG - 2011-10-11 21:47:00 --> Model Class Initialized
DEBUG - 2011-10-11 21:47:00 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-10-11 21:47:00 --> Database Driver Class Initialized
DEBUG - 2011-10-11 21:47:00 --> File loaded: application/views/table/main.php
DEBUG - 2011-10-11 21:47:00 --> Helper loaded: url_helper
DEBUG - 2011-10-11 21:47:00 --> File loaded: application/views/common/header.php
DEBUG - 2011-10-11 21:47:00 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-10-11 21:47:00 --> File loaded: application/views/common/footer.php
DEBUG - 2011-10-11 21:47:00 --> File loaded: application/views/layout/main.php
DEBUG - 2011-10-11 21:47:00 --> Final output sent to browser
DEBUG - 2011-10-11 21:47:00 --> Total execution time: 0.2933
DEBUG - 2011-10-11 21:47:30 --> Config Class Initialized
DEBUG - 2011-10-11 21:47:30 --> Hooks Class Initialized
DEBUG - 2011-10-11 21:47:30 --> Utf8 Class Initialized
DEBUG - 2011-10-11 21:47:30 --> UTF-8 Support Enabled
DEBUG - 2011-10-11 21:47:30 --> URI Class Initialized
DEBUG - 2011-10-11 21:47:30 --> Router Class Initialized
DEBUG - 2011-10-11 21:47:30 --> Output Class Initialized
DEBUG - 2011-10-11 21:47:30 --> Input Class Initialized
DEBUG - 2011-10-11 21:47:30 --> Global POST and COOKIE data sanitized
DEBUG - 2011-10-11 21:47:30 --> Language Class Initialized
DEBUG - 2011-10-11 21:47:30 --> Loader Class Initialized
DEBUG - 2011-10-11 21:47:30 --> Controller Class Initialized
DEBUG - 2011-10-11 21:47:30 --> Model Class Initialized
DEBUG - 2011-10-11 21:47:30 --> Model Class Initialized
DEBUG - 2011-10-11 21:47:30 --> Model Class Initialized
DEBUG - 2011-10-11 21:47:30 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-10-11 21:47:30 --> Database Driver Class Initialized
DEBUG - 2011-10-11 21:47:31 --> File loaded: application/views/table/main.php
DEBUG - 2011-10-11 21:47:31 --> Helper loaded: url_helper
DEBUG - 2011-10-11 21:47:31 --> File loaded: application/views/common/header.php
DEBUG - 2011-10-11 21:47:31 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-10-11 21:47:31 --> File loaded: application/views/common/footer.php
DEBUG - 2011-10-11 21:47:31 --> File loaded: application/views/layout/main.php
DEBUG - 2011-10-11 21:47:31 --> Final output sent to browser
DEBUG - 2011-10-11 21:47:31 --> Total execution time: 0.6590
DEBUG - 2011-10-11 21:47:50 --> Config Class Initialized
DEBUG - 2011-10-11 21:47:50 --> Hooks Class Initialized
DEBUG - 2011-10-11 21:47:50 --> Utf8 Class Initialized
DEBUG - 2011-10-11 21:47:50 --> UTF-8 Support Enabled
DEBUG - 2011-10-11 21:47:50 --> URI Class Initialized
DEBUG - 2011-10-11 21:47:50 --> Router Class Initialized
DEBUG - 2011-10-11 21:47:50 --> Output Class Initialized
DEBUG - 2011-10-11 21:47:50 --> Input Class Initialized
DEBUG - 2011-10-11 21:47:50 --> Global POST and COOKIE data sanitized
DEBUG - 2011-10-11 21:47:50 --> Language Class Initialized
DEBUG - 2011-10-11 21:47:50 --> Loader Class Initialized
DEBUG - 2011-10-11 21:47:50 --> Controller Class Initialized
DEBUG - 2011-10-11 21:47:50 --> Model Class Initialized
DEBUG - 2011-10-11 21:47:50 --> Model Class Initialized
DEBUG - 2011-10-11 21:47:50 --> Model Class Initialized
DEBUG - 2011-10-11 21:47:50 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-10-11 21:47:50 --> Database Driver Class Initialized
DEBUG - 2011-10-11 21:47:51 --> File loaded: application/views/table/main.php
DEBUG - 2011-10-11 21:47:51 --> Helper loaded: url_helper
DEBUG - 2011-10-11 21:47:51 --> File loaded: application/views/common/header.php
DEBUG - 2011-10-11 21:47:51 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-10-11 21:47:51 --> File loaded: application/views/common/footer.php
DEBUG - 2011-10-11 21:47:51 --> File loaded: application/views/layout/main.php
DEBUG - 2011-10-11 21:47:51 --> Final output sent to browser
DEBUG - 2011-10-11 21:47:51 --> Total execution time: 0.2683
DEBUG - 2011-10-11 21:47:51 --> Config Class Initialized
DEBUG - 2011-10-11 21:47:51 --> Hooks Class Initialized
DEBUG - 2011-10-11 21:47:51 --> Utf8 Class Initialized
DEBUG - 2011-10-11 21:47:51 --> UTF-8 Support Enabled
DEBUG - 2011-10-11 21:47:51 --> URI Class Initialized
DEBUG - 2011-10-11 21:47:51 --> Router Class Initialized
DEBUG - 2011-10-11 21:47:51 --> Output Class Initialized
DEBUG - 2011-10-11 21:47:51 --> Input Class Initialized
DEBUG - 2011-10-11 21:47:51 --> Global POST and COOKIE data sanitized
DEBUG - 2011-10-11 21:47:51 --> Language Class Initialized
DEBUG - 2011-10-11 21:47:51 --> Loader Class Initialized
DEBUG - 2011-10-11 21:47:51 --> Controller Class Initialized
DEBUG - 2011-10-11 21:47:51 --> Model Class Initialized
DEBUG - 2011-10-11 21:47:51 --> Model Class Initialized
DEBUG - 2011-10-11 21:47:51 --> Model Class Initialized
DEBUG - 2011-10-11 21:47:51 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-10-11 21:47:51 --> Database Driver Class Initialized
DEBUG - 2011-10-11 21:47:51 --> File loaded: application/views/table/main.php
DEBUG - 2011-10-11 21:47:51 --> Helper loaded: url_helper
DEBUG - 2011-10-11 21:47:51 --> File loaded: application/views/common/header.php
DEBUG - 2011-10-11 21:47:51 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-10-11 21:47:51 --> File loaded: application/views/common/footer.php
DEBUG - 2011-10-11 21:47:51 --> File loaded: application/views/layout/main.php
DEBUG - 2011-10-11 21:47:51 --> Final output sent to browser
DEBUG - 2011-10-11 21:47:51 --> Total execution time: 0.0498
DEBUG - 2011-10-11 21:47:53 --> Config Class Initialized
DEBUG - 2011-10-11 21:47:53 --> Hooks Class Initialized
DEBUG - 2011-10-11 21:47:53 --> Utf8 Class Initialized
DEBUG - 2011-10-11 21:47:53 --> UTF-8 Support Enabled
DEBUG - 2011-10-11 21:47:53 --> URI Class Initialized
DEBUG - 2011-10-11 21:47:53 --> Router Class Initialized
DEBUG - 2011-10-11 21:47:53 --> Output Class Initialized
DEBUG - 2011-10-11 21:47:53 --> Input Class Initialized
DEBUG - 2011-10-11 21:47:53 --> Global POST and COOKIE data sanitized
DEBUG - 2011-10-11 21:47:53 --> Language Class Initialized
DEBUG - 2011-10-11 21:47:53 --> Loader Class Initialized
DEBUG - 2011-10-11 21:47:53 --> Controller Class Initialized
DEBUG - 2011-10-11 21:47:53 --> Model Class Initialized
DEBUG - 2011-10-11 21:47:53 --> Model Class Initialized
DEBUG - 2011-10-11 21:47:53 --> Model Class Initialized
DEBUG - 2011-10-11 21:47:53 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-10-11 21:47:53 --> Database Driver Class Initialized
DEBUG - 2011-10-11 21:47:54 --> File loaded: application/views/table/main.php
DEBUG - 2011-10-11 21:47:54 --> Helper loaded: url_helper
DEBUG - 2011-10-11 21:47:54 --> File loaded: application/views/common/header.php
DEBUG - 2011-10-11 21:47:54 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-10-11 21:47:54 --> File loaded: application/views/common/footer.php
DEBUG - 2011-10-11 21:47:54 --> File loaded: application/views/layout/main.php
DEBUG - 2011-10-11 21:47:54 --> Final output sent to browser
DEBUG - 2011-10-11 21:47:54 --> Total execution time: 0.0528
DEBUG - 2011-10-11 21:48:06 --> Config Class Initialized
DEBUG - 2011-10-11 21:48:06 --> Hooks Class Initialized
DEBUG - 2011-10-11 21:48:06 --> Utf8 Class Initialized
DEBUG - 2011-10-11 21:48:06 --> UTF-8 Support Enabled
DEBUG - 2011-10-11 21:48:06 --> URI Class Initialized
DEBUG - 2011-10-11 21:48:06 --> Router Class Initialized
DEBUG - 2011-10-11 21:48:06 --> Output Class Initialized
DEBUG - 2011-10-11 21:48:06 --> Input Class Initialized
DEBUG - 2011-10-11 21:48:06 --> Global POST and COOKIE data sanitized
DEBUG - 2011-10-11 21:48:06 --> Language Class Initialized
DEBUG - 2011-10-11 21:48:06 --> Loader Class Initialized
DEBUG - 2011-10-11 21:48:06 --> Controller Class Initialized
DEBUG - 2011-10-11 21:48:06 --> Model Class Initialized
DEBUG - 2011-10-11 21:48:06 --> Model Class Initialized
DEBUG - 2011-10-11 21:48:06 --> Model Class Initialized
DEBUG - 2011-10-11 21:48:06 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-10-11 21:48:06 --> Database Driver Class Initialized
DEBUG - 2011-10-11 21:48:06 --> File loaded: application/views/table/main.php
DEBUG - 2011-10-11 21:48:06 --> Helper loaded: url_helper
DEBUG - 2011-10-11 21:48:06 --> File loaded: application/views/common/header.php
DEBUG - 2011-10-11 21:48:06 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-10-11 21:48:06 --> File loaded: application/views/common/footer.php
DEBUG - 2011-10-11 21:48:06 --> File loaded: application/views/layout/main.php
DEBUG - 2011-10-11 21:48:06 --> Final output sent to browser
DEBUG - 2011-10-11 21:48:06 --> Total execution time: 0.2105
DEBUG - 2011-10-11 21:48:22 --> Config Class Initialized
DEBUG - 2011-10-11 21:48:22 --> Hooks Class Initialized
DEBUG - 2011-10-11 21:48:22 --> Utf8 Class Initialized
DEBUG - 2011-10-11 21:48:22 --> UTF-8 Support Enabled
DEBUG - 2011-10-11 21:48:22 --> URI Class Initialized
DEBUG - 2011-10-11 21:48:22 --> Router Class Initialized
DEBUG - 2011-10-11 21:48:22 --> Output Class Initialized
DEBUG - 2011-10-11 21:48:22 --> Input Class Initialized
DEBUG - 2011-10-11 21:48:22 --> Global POST and COOKIE data sanitized
DEBUG - 2011-10-11 21:48:22 --> Language Class Initialized
DEBUG - 2011-10-11 21:48:22 --> Loader Class Initialized
DEBUG - 2011-10-11 21:48:22 --> Controller Class Initialized
DEBUG - 2011-10-11 21:48:22 --> Model Class Initialized
DEBUG - 2011-10-11 21:48:22 --> Model Class Initialized
DEBUG - 2011-10-11 21:48:22 --> Model Class Initialized
DEBUG - 2011-10-11 21:48:22 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-10-11 21:48:22 --> Database Driver Class Initialized
DEBUG - 2011-10-11 21:48:22 --> File loaded: application/views/table/main.php
DEBUG - 2011-10-11 21:48:22 --> Helper loaded: url_helper
DEBUG - 2011-10-11 21:48:22 --> File loaded: application/views/common/header.php
DEBUG - 2011-10-11 21:48:22 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-10-11 21:48:22 --> File loaded: application/views/common/footer.php
DEBUG - 2011-10-11 21:48:22 --> File loaded: application/views/layout/main.php
DEBUG - 2011-10-11 21:48:22 --> Final output sent to browser
DEBUG - 2011-10-11 21:48:22 --> Total execution time: 0.2318
DEBUG - 2011-10-11 21:48:24 --> Config Class Initialized
DEBUG - 2011-10-11 21:48:24 --> Hooks Class Initialized
DEBUG - 2011-10-11 21:48:24 --> Utf8 Class Initialized
DEBUG - 2011-10-11 21:48:24 --> UTF-8 Support Enabled
DEBUG - 2011-10-11 21:48:24 --> URI Class Initialized
DEBUG - 2011-10-11 21:48:24 --> Router Class Initialized
DEBUG - 2011-10-11 21:48:24 --> Output Class Initialized
DEBUG - 2011-10-11 21:48:24 --> Input Class Initialized
DEBUG - 2011-10-11 21:48:24 --> Global POST and COOKIE data sanitized
DEBUG - 2011-10-11 21:48:24 --> Language Class Initialized
DEBUG - 2011-10-11 21:48:24 --> Loader Class Initialized
DEBUG - 2011-10-11 21:48:24 --> Controller Class Initialized
DEBUG - 2011-10-11 21:48:24 --> Model Class Initialized
DEBUG - 2011-10-11 21:48:24 --> Model Class Initialized
DEBUG - 2011-10-11 21:48:24 --> Model Class Initialized
DEBUG - 2011-10-11 21:48:24 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-10-11 21:48:24 --> Database Driver Class Initialized
DEBUG - 2011-10-11 21:48:24 --> File loaded: application/views/table/main.php
DEBUG - 2011-10-11 21:48:24 --> Helper loaded: url_helper
DEBUG - 2011-10-11 21:48:24 --> File loaded: application/views/common/header.php
DEBUG - 2011-10-11 21:48:24 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-10-11 21:48:24 --> File loaded: application/views/common/footer.php
DEBUG - 2011-10-11 21:48:24 --> File loaded: application/views/layout/main.php
DEBUG - 2011-10-11 21:48:24 --> Final output sent to browser
DEBUG - 2011-10-11 21:48:24 --> Total execution time: 0.0472
DEBUG - 2011-10-11 21:48:39 --> Config Class Initialized
DEBUG - 2011-10-11 21:48:39 --> Hooks Class Initialized
DEBUG - 2011-10-11 21:48:39 --> Utf8 Class Initialized
DEBUG - 2011-10-11 21:48:39 --> UTF-8 Support Enabled
DEBUG - 2011-10-11 21:48:39 --> URI Class Initialized
DEBUG - 2011-10-11 21:48:39 --> Router Class Initialized
DEBUG - 2011-10-11 21:48:39 --> Output Class Initialized
DEBUG - 2011-10-11 21:48:39 --> Input Class Initialized
DEBUG - 2011-10-11 21:48:39 --> Global POST and COOKIE data sanitized
DEBUG - 2011-10-11 21:48:39 --> Language Class Initialized
DEBUG - 2011-10-11 21:48:39 --> Loader Class Initialized
DEBUG - 2011-10-11 21:48:39 --> Controller Class Initialized
DEBUG - 2011-10-11 21:48:39 --> Model Class Initialized
DEBUG - 2011-10-11 21:48:39 --> Model Class Initialized
DEBUG - 2011-10-11 21:48:39 --> Model Class Initialized
DEBUG - 2011-10-11 21:48:39 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-10-11 21:48:39 --> Database Driver Class Initialized
DEBUG - 2011-10-11 21:48:39 --> File loaded: application/views/table/main.php
DEBUG - 2011-10-11 21:48:39 --> Helper loaded: url_helper
DEBUG - 2011-10-11 21:48:39 --> File loaded: application/views/common/header.php
DEBUG - 2011-10-11 21:48:39 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-10-11 21:48:39 --> File loaded: application/views/common/footer.php
DEBUG - 2011-10-11 21:48:39 --> File loaded: application/views/layout/main.php
DEBUG - 2011-10-11 21:48:39 --> Final output sent to browser
DEBUG - 2011-10-11 21:48:39 --> Total execution time: 0.3929
DEBUG - 2011-10-11 21:48:52 --> Config Class Initialized
DEBUG - 2011-10-11 21:48:52 --> Hooks Class Initialized
DEBUG - 2011-10-11 21:48:52 --> Utf8 Class Initialized
DEBUG - 2011-10-11 21:48:52 --> UTF-8 Support Enabled
DEBUG - 2011-10-11 21:48:52 --> URI Class Initialized
DEBUG - 2011-10-11 21:48:52 --> Router Class Initialized
DEBUG - 2011-10-11 21:48:52 --> Output Class Initialized
DEBUG - 2011-10-11 21:48:52 --> Input Class Initialized
DEBUG - 2011-10-11 21:48:52 --> Global POST and COOKIE data sanitized
DEBUG - 2011-10-11 21:48:52 --> Language Class Initialized
DEBUG - 2011-10-11 21:48:52 --> Loader Class Initialized
DEBUG - 2011-10-11 21:48:52 --> Controller Class Initialized
DEBUG - 2011-10-11 21:48:52 --> Model Class Initialized
DEBUG - 2011-10-11 21:48:52 --> Model Class Initialized
DEBUG - 2011-10-11 21:48:52 --> Model Class Initialized
DEBUG - 2011-10-11 21:48:52 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-10-11 21:48:52 --> Database Driver Class Initialized
DEBUG - 2011-10-11 21:48:52 --> File loaded: application/views/table/main.php
DEBUG - 2011-10-11 21:48:52 --> Helper loaded: url_helper
DEBUG - 2011-10-11 21:48:52 --> File loaded: application/views/common/header.php
DEBUG - 2011-10-11 21:48:52 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-10-11 21:48:52 --> File loaded: application/views/common/footer.php
DEBUG - 2011-10-11 21:48:52 --> File loaded: application/views/layout/main.php
DEBUG - 2011-10-11 21:48:52 --> Final output sent to browser
DEBUG - 2011-10-11 21:48:52 --> Total execution time: 0.5565
DEBUG - 2011-10-11 21:49:05 --> Config Class Initialized
DEBUG - 2011-10-11 21:49:05 --> Hooks Class Initialized
DEBUG - 2011-10-11 21:49:05 --> Utf8 Class Initialized
DEBUG - 2011-10-11 21:49:05 --> UTF-8 Support Enabled
DEBUG - 2011-10-11 21:49:05 --> URI Class Initialized
DEBUG - 2011-10-11 21:49:05 --> Router Class Initialized
DEBUG - 2011-10-11 21:49:05 --> Output Class Initialized
DEBUG - 2011-10-11 21:49:05 --> Input Class Initialized
DEBUG - 2011-10-11 21:49:05 --> Global POST and COOKIE data sanitized
DEBUG - 2011-10-11 21:49:05 --> Language Class Initialized
DEBUG - 2011-10-11 21:49:05 --> Loader Class Initialized
DEBUG - 2011-10-11 21:49:05 --> Controller Class Initialized
DEBUG - 2011-10-11 21:49:05 --> Model Class Initialized
DEBUG - 2011-10-11 21:49:05 --> Model Class Initialized
DEBUG - 2011-10-11 21:49:05 --> Model Class Initialized
DEBUG - 2011-10-11 21:49:05 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-10-11 21:49:05 --> Database Driver Class Initialized
DEBUG - 2011-10-11 21:49:06 --> File loaded: application/views/table/main.php
DEBUG - 2011-10-11 21:49:06 --> Helper loaded: url_helper
DEBUG - 2011-10-11 21:49:06 --> File loaded: application/views/common/header.php
DEBUG - 2011-10-11 21:49:06 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-10-11 21:49:06 --> File loaded: application/views/common/footer.php
DEBUG - 2011-10-11 21:49:06 --> File loaded: application/views/layout/main.php
DEBUG - 2011-10-11 21:49:06 --> Final output sent to browser
DEBUG - 2011-10-11 21:49:06 --> Total execution time: 0.2940
DEBUG - 2011-10-11 21:49:28 --> Config Class Initialized
DEBUG - 2011-10-11 21:49:28 --> Hooks Class Initialized
DEBUG - 2011-10-11 21:49:28 --> Utf8 Class Initialized
DEBUG - 2011-10-11 21:49:28 --> UTF-8 Support Enabled
DEBUG - 2011-10-11 21:49:28 --> URI Class Initialized
DEBUG - 2011-10-11 21:49:28 --> Router Class Initialized
DEBUG - 2011-10-11 21:49:28 --> Output Class Initialized
DEBUG - 2011-10-11 21:49:28 --> Input Class Initialized
DEBUG - 2011-10-11 21:49:28 --> Global POST and COOKIE data sanitized
DEBUG - 2011-10-11 21:49:28 --> Language Class Initialized
DEBUG - 2011-10-11 21:49:28 --> Loader Class Initialized
DEBUG - 2011-10-11 21:49:28 --> Controller Class Initialized
DEBUG - 2011-10-11 21:49:28 --> Model Class Initialized
DEBUG - 2011-10-11 21:49:28 --> Model Class Initialized
DEBUG - 2011-10-11 21:49:28 --> Model Class Initialized
DEBUG - 2011-10-11 21:49:28 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-10-11 21:49:28 --> Database Driver Class Initialized
DEBUG - 2011-10-11 21:49:29 --> File loaded: application/views/table/main.php
DEBUG - 2011-10-11 21:49:29 --> Helper loaded: url_helper
DEBUG - 2011-10-11 21:49:29 --> File loaded: application/views/common/header.php
DEBUG - 2011-10-11 21:49:29 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-10-11 21:49:29 --> File loaded: application/views/common/footer.php
DEBUG - 2011-10-11 21:49:29 --> File loaded: application/views/layout/main.php
DEBUG - 2011-10-11 21:49:29 --> Final output sent to browser
DEBUG - 2011-10-11 21:49:29 --> Total execution time: 0.2938
DEBUG - 2011-10-11 21:49:31 --> Config Class Initialized
DEBUG - 2011-10-11 21:49:31 --> Hooks Class Initialized
DEBUG - 2011-10-11 21:49:31 --> Utf8 Class Initialized
DEBUG - 2011-10-11 21:49:31 --> UTF-8 Support Enabled
DEBUG - 2011-10-11 21:49:31 --> URI Class Initialized
DEBUG - 2011-10-11 21:49:31 --> Router Class Initialized
DEBUG - 2011-10-11 21:49:31 --> Output Class Initialized
DEBUG - 2011-10-11 21:49:31 --> Input Class Initialized
DEBUG - 2011-10-11 21:49:31 --> Global POST and COOKIE data sanitized
DEBUG - 2011-10-11 21:49:31 --> Language Class Initialized
DEBUG - 2011-10-11 21:49:31 --> Loader Class Initialized
DEBUG - 2011-10-11 21:49:31 --> Controller Class Initialized
DEBUG - 2011-10-11 21:49:31 --> Model Class Initialized
DEBUG - 2011-10-11 21:49:31 --> Model Class Initialized
DEBUG - 2011-10-11 21:49:31 --> Model Class Initialized
DEBUG - 2011-10-11 21:49:31 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-10-11 21:49:31 --> Database Driver Class Initialized
DEBUG - 2011-10-11 21:49:31 --> File loaded: application/views/table/main.php
DEBUG - 2011-10-11 21:49:31 --> Helper loaded: url_helper
DEBUG - 2011-10-11 21:49:31 --> File loaded: application/views/common/header.php
DEBUG - 2011-10-11 21:49:31 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-10-11 21:49:31 --> File loaded: application/views/common/footer.php
DEBUG - 2011-10-11 21:49:31 --> File loaded: application/views/layout/main.php
DEBUG - 2011-10-11 21:49:31 --> Final output sent to browser
DEBUG - 2011-10-11 21:49:31 --> Total execution time: 0.0483
DEBUG - 2011-10-11 23:50:29 --> Config Class Initialized
DEBUG - 2011-10-11 23:50:29 --> Hooks Class Initialized
DEBUG - 2011-10-11 23:50:29 --> Utf8 Class Initialized
DEBUG - 2011-10-11 23:50:29 --> UTF-8 Support Enabled
DEBUG - 2011-10-11 23:50:29 --> URI Class Initialized
DEBUG - 2011-10-11 23:50:29 --> Router Class Initialized
DEBUG - 2011-10-11 23:50:29 --> No URI present. Default controller set.
DEBUG - 2011-10-11 23:50:29 --> Output Class Initialized
DEBUG - 2011-10-11 23:50:29 --> Input Class Initialized
DEBUG - 2011-10-11 23:50:29 --> Global POST and COOKIE data sanitized
DEBUG - 2011-10-11 23:50:29 --> Language Class Initialized
DEBUG - 2011-10-11 23:50:29 --> Loader Class Initialized
DEBUG - 2011-10-11 23:50:29 --> Controller Class Initialized
DEBUG - 2011-10-11 23:50:29 --> File loaded: application/views/splash/main.php
DEBUG - 2011-10-11 23:50:29 --> Helper loaded: url_helper
DEBUG - 2011-10-11 23:50:29 --> File loaded: application/views/common/header.php
DEBUG - 2011-10-11 23:50:29 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-10-11 23:50:29 --> File loaded: application/views/common/footer.php
DEBUG - 2011-10-11 23:50:29 --> File loaded: application/views/layout/main.php
DEBUG - 2011-10-11 23:50:29 --> Final output sent to browser
DEBUG - 2011-10-11 23:50:29 --> Total execution time: 0.1005

<?php  if ( ! defined('BASEPATH')) exit('No direct script access allowed'); ?>

DEBUG - 2011-10-01 01:20:54 --> Config Class Initialized
DEBUG - 2011-10-01 01:20:54 --> Hooks Class Initialized
DEBUG - 2011-10-01 01:20:54 --> Utf8 Class Initialized
DEBUG - 2011-10-01 01:20:54 --> UTF-8 Support Enabled
DEBUG - 2011-10-01 01:20:54 --> URI Class Initialized
DEBUG - 2011-10-01 01:20:54 --> Router Class Initialized
DEBUG - 2011-10-01 01:20:54 --> Output Class Initialized
DEBUG - 2011-10-01 01:20:54 --> Input Class Initialized
DEBUG - 2011-10-01 01:20:54 --> Global POST and COOKIE data sanitized
DEBUG - 2011-10-01 01:20:54 --> Language Class Initialized
DEBUG - 2011-10-01 01:20:54 --> Loader Class Initialized
DEBUG - 2011-10-01 01:20:54 --> Controller Class Initialized
DEBUG - 2011-10-01 01:20:54 --> Model Class Initialized
DEBUG - 2011-10-01 01:20:54 --> Model Class Initialized
DEBUG - 2011-10-01 01:20:54 --> Model Class Initialized
DEBUG - 2011-10-01 01:20:54 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-10-01 01:20:54 --> Database Driver Class Initialized
DEBUG - 2011-10-01 01:20:56 --> File loaded: application/views/table/main.php
DEBUG - 2011-10-01 01:20:56 --> Helper loaded: url_helper
DEBUG - 2011-10-01 01:20:56 --> File loaded: application/views/common/header.php
DEBUG - 2011-10-01 01:20:56 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-10-01 01:20:56 --> File loaded: application/views/common/footer.php
DEBUG - 2011-10-01 01:20:56 --> File loaded: application/views/layout/main.php
DEBUG - 2011-10-01 01:20:56 --> Final output sent to browser
DEBUG - 2011-10-01 01:20:56 --> Total execution time: 2.0318
DEBUG - 2011-10-01 01:21:00 --> Config Class Initialized
DEBUG - 2011-10-01 01:21:00 --> Hooks Class Initialized
DEBUG - 2011-10-01 01:21:00 --> Utf8 Class Initialized
DEBUG - 2011-10-01 01:21:00 --> UTF-8 Support Enabled
DEBUG - 2011-10-01 01:21:00 --> URI Class Initialized
DEBUG - 2011-10-01 01:21:00 --> Router Class Initialized
ERROR - 2011-10-01 01:21:00 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-10-01 01:21:03 --> Config Class Initialized
DEBUG - 2011-10-01 01:21:03 --> Hooks Class Initialized
DEBUG - 2011-10-01 01:21:03 --> Utf8 Class Initialized
DEBUG - 2011-10-01 01:21:03 --> UTF-8 Support Enabled
DEBUG - 2011-10-01 01:21:03 --> URI Class Initialized
DEBUG - 2011-10-01 01:21:03 --> Router Class Initialized
ERROR - 2011-10-01 01:21:03 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-10-01 01:21:13 --> Config Class Initialized
DEBUG - 2011-10-01 01:21:13 --> Hooks Class Initialized
DEBUG - 2011-10-01 01:21:13 --> Utf8 Class Initialized
DEBUG - 2011-10-01 01:21:13 --> UTF-8 Support Enabled
DEBUG - 2011-10-01 01:21:13 --> URI Class Initialized
DEBUG - 2011-10-01 01:21:13 --> Router Class Initialized
DEBUG - 2011-10-01 01:21:13 --> Output Class Initialized
DEBUG - 2011-10-01 01:21:13 --> Input Class Initialized
DEBUG - 2011-10-01 01:21:13 --> Global POST and COOKIE data sanitized
DEBUG - 2011-10-01 01:21:13 --> Language Class Initialized
DEBUG - 2011-10-01 01:21:13 --> Loader Class Initialized
DEBUG - 2011-10-01 01:21:13 --> Controller Class Initialized
DEBUG - 2011-10-01 01:21:13 --> Model Class Initialized
DEBUG - 2011-10-01 01:21:13 --> Model Class Initialized
DEBUG - 2011-10-01 01:21:13 --> Model Class Initialized
DEBUG - 2011-10-01 01:21:13 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-10-01 01:21:13 --> Database Driver Class Initialized
DEBUG - 2011-10-01 01:21:22 --> File loaded: application/views/table/main.php
DEBUG - 2011-10-01 01:21:22 --> Helper loaded: url_helper
DEBUG - 2011-10-01 01:21:22 --> File loaded: application/views/common/header.php
DEBUG - 2011-10-01 01:21:22 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-10-01 01:21:22 --> File loaded: application/views/common/footer.php
DEBUG - 2011-10-01 01:21:22 --> File loaded: application/views/layout/main.php
DEBUG - 2011-10-01 01:21:22 --> Final output sent to browser
DEBUG - 2011-10-01 01:21:22 --> Total execution time: 9.3954
DEBUG - 2011-10-01 01:21:24 --> Config Class Initialized
DEBUG - 2011-10-01 01:21:24 --> Hooks Class Initialized
DEBUG - 2011-10-01 01:21:24 --> Utf8 Class Initialized
DEBUG - 2011-10-01 01:21:24 --> UTF-8 Support Enabled
DEBUG - 2011-10-01 01:21:24 --> URI Class Initialized
DEBUG - 2011-10-01 01:21:24 --> Router Class Initialized
DEBUG - 2011-10-01 01:21:24 --> Output Class Initialized
DEBUG - 2011-10-01 01:21:24 --> Input Class Initialized
DEBUG - 2011-10-01 01:21:24 --> Global POST and COOKIE data sanitized
DEBUG - 2011-10-01 01:21:24 --> Language Class Initialized
DEBUG - 2011-10-01 01:21:24 --> Loader Class Initialized
DEBUG - 2011-10-01 01:21:24 --> Controller Class Initialized
DEBUG - 2011-10-01 01:21:24 --> Model Class Initialized
DEBUG - 2011-10-01 01:21:24 --> Model Class Initialized
DEBUG - 2011-10-01 01:21:24 --> Model Class Initialized
DEBUG - 2011-10-01 01:21:24 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-10-01 01:21:24 --> Database Driver Class Initialized
DEBUG - 2011-10-01 01:21:24 --> File loaded: application/views/table/main.php
DEBUG - 2011-10-01 01:21:24 --> Helper loaded: url_helper
DEBUG - 2011-10-01 01:21:24 --> File loaded: application/views/common/header.php
DEBUG - 2011-10-01 01:21:24 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-10-01 01:21:24 --> File loaded: application/views/common/footer.php
DEBUG - 2011-10-01 01:21:24 --> File loaded: application/views/layout/main.php
DEBUG - 2011-10-01 01:21:24 --> Final output sent to browser
DEBUG - 2011-10-01 01:21:24 --> Total execution time: 0.1272
DEBUG - 2011-10-01 01:21:24 --> Config Class Initialized
DEBUG - 2011-10-01 01:21:24 --> Hooks Class Initialized
DEBUG - 2011-10-01 01:21:24 --> Utf8 Class Initialized
DEBUG - 2011-10-01 01:21:24 --> UTF-8 Support Enabled
DEBUG - 2011-10-01 01:21:24 --> URI Class Initialized
DEBUG - 2011-10-01 01:21:24 --> Router Class Initialized
ERROR - 2011-10-01 01:21:24 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-10-01 01:21:58 --> Config Class Initialized
DEBUG - 2011-10-01 01:21:58 --> Hooks Class Initialized
DEBUG - 2011-10-01 01:21:58 --> Utf8 Class Initialized
DEBUG - 2011-10-01 01:21:58 --> UTF-8 Support Enabled
DEBUG - 2011-10-01 01:21:58 --> URI Class Initialized
DEBUG - 2011-10-01 01:21:58 --> Router Class Initialized
DEBUG - 2011-10-01 01:21:58 --> Output Class Initialized
DEBUG - 2011-10-01 01:21:58 --> Input Class Initialized
DEBUG - 2011-10-01 01:21:58 --> Global POST and COOKIE data sanitized
DEBUG - 2011-10-01 01:21:58 --> Language Class Initialized
DEBUG - 2011-10-01 01:21:58 --> Loader Class Initialized
DEBUG - 2011-10-01 01:21:58 --> Controller Class Initialized
DEBUG - 2011-10-01 01:21:58 --> Model Class Initialized
DEBUG - 2011-10-01 01:21:58 --> Model Class Initialized
DEBUG - 2011-10-01 01:21:58 --> Model Class Initialized
DEBUG - 2011-10-01 01:21:58 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-10-01 01:21:58 --> Database Driver Class Initialized
DEBUG - 2011-10-01 01:21:59 --> File loaded: application/views/table/main.php
DEBUG - 2011-10-01 01:21:59 --> Helper loaded: url_helper
DEBUG - 2011-10-01 01:21:59 --> File loaded: application/views/common/header.php
DEBUG - 2011-10-01 01:21:59 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-10-01 01:21:59 --> File loaded: application/views/common/footer.php
DEBUG - 2011-10-01 01:21:59 --> File loaded: application/views/layout/main.php
DEBUG - 2011-10-01 01:21:59 --> Final output sent to browser
DEBUG - 2011-10-01 01:21:59 --> Total execution time: 1.0088
DEBUG - 2011-10-01 01:22:00 --> Config Class Initialized
DEBUG - 2011-10-01 01:22:00 --> Hooks Class Initialized
DEBUG - 2011-10-01 01:22:00 --> Utf8 Class Initialized
DEBUG - 2011-10-01 01:22:00 --> UTF-8 Support Enabled
DEBUG - 2011-10-01 01:22:00 --> URI Class Initialized
DEBUG - 2011-10-01 01:22:00 --> Router Class Initialized
DEBUG - 2011-10-01 01:22:00 --> Output Class Initialized
DEBUG - 2011-10-01 01:22:00 --> Input Class Initialized
DEBUG - 2011-10-01 01:22:00 --> Global POST and COOKIE data sanitized
DEBUG - 2011-10-01 01:22:00 --> Language Class Initialized
DEBUG - 2011-10-01 01:22:00 --> Loader Class Initialized
DEBUG - 2011-10-01 01:22:00 --> Controller Class Initialized
DEBUG - 2011-10-01 01:22:00 --> Model Class Initialized
DEBUG - 2011-10-01 01:22:00 --> Model Class Initialized
DEBUG - 2011-10-01 01:22:00 --> Model Class Initialized
DEBUG - 2011-10-01 01:22:00 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-10-01 01:22:00 --> Database Driver Class Initialized
DEBUG - 2011-10-01 01:22:00 --> File loaded: application/views/table/main.php
DEBUG - 2011-10-01 01:22:00 --> Helper loaded: url_helper
DEBUG - 2011-10-01 01:22:00 --> File loaded: application/views/common/header.php
DEBUG - 2011-10-01 01:22:00 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-10-01 01:22:00 --> File loaded: application/views/common/footer.php
DEBUG - 2011-10-01 01:22:00 --> File loaded: application/views/layout/main.php
DEBUG - 2011-10-01 01:22:00 --> Final output sent to browser
DEBUG - 2011-10-01 01:22:00 --> Total execution time: 0.0496
DEBUG - 2011-10-01 01:22:01 --> Config Class Initialized
DEBUG - 2011-10-01 01:22:01 --> Hooks Class Initialized
DEBUG - 2011-10-01 01:22:01 --> Utf8 Class Initialized
DEBUG - 2011-10-01 01:22:01 --> UTF-8 Support Enabled
DEBUG - 2011-10-01 01:22:01 --> URI Class Initialized
DEBUG - 2011-10-01 01:22:01 --> Router Class Initialized
ERROR - 2011-10-01 01:22:01 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-10-01 01:22:16 --> Config Class Initialized
DEBUG - 2011-10-01 01:22:16 --> Hooks Class Initialized
DEBUG - 2011-10-01 01:22:16 --> Utf8 Class Initialized
DEBUG - 2011-10-01 01:22:16 --> UTF-8 Support Enabled
DEBUG - 2011-10-01 01:22:16 --> URI Class Initialized
DEBUG - 2011-10-01 01:22:16 --> Router Class Initialized
DEBUG - 2011-10-01 01:22:16 --> Output Class Initialized
DEBUG - 2011-10-01 01:22:16 --> Input Class Initialized
DEBUG - 2011-10-01 01:22:16 --> Global POST and COOKIE data sanitized
DEBUG - 2011-10-01 01:22:16 --> Language Class Initialized
DEBUG - 2011-10-01 01:22:16 --> Loader Class Initialized
DEBUG - 2011-10-01 01:22:16 --> Controller Class Initialized
DEBUG - 2011-10-01 01:22:16 --> Model Class Initialized
DEBUG - 2011-10-01 01:22:16 --> Model Class Initialized
DEBUG - 2011-10-01 01:22:16 --> Model Class Initialized
DEBUG - 2011-10-01 01:22:16 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-10-01 01:22:16 --> Database Driver Class Initialized
DEBUG - 2011-10-01 01:22:22 --> File loaded: application/views/table/main.php
DEBUG - 2011-10-01 01:22:22 --> Helper loaded: url_helper
DEBUG - 2011-10-01 01:22:22 --> File loaded: application/views/common/header.php
DEBUG - 2011-10-01 01:22:22 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-10-01 01:22:22 --> File loaded: application/views/common/footer.php
DEBUG - 2011-10-01 01:22:22 --> File loaded: application/views/layout/main.php
DEBUG - 2011-10-01 01:22:22 --> Final output sent to browser
DEBUG - 2011-10-01 01:22:22 --> Total execution time: 6.0152
DEBUG - 2011-10-01 01:22:24 --> Config Class Initialized
DEBUG - 2011-10-01 01:22:24 --> Hooks Class Initialized
DEBUG - 2011-10-01 01:22:24 --> Utf8 Class Initialized
DEBUG - 2011-10-01 01:22:24 --> UTF-8 Support Enabled
DEBUG - 2011-10-01 01:22:24 --> URI Class Initialized
DEBUG - 2011-10-01 01:22:24 --> Router Class Initialized
ERROR - 2011-10-01 01:22:24 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-10-01 01:22:27 --> Config Class Initialized
DEBUG - 2011-10-01 01:22:27 --> Hooks Class Initialized
DEBUG - 2011-10-01 01:22:27 --> Utf8 Class Initialized
DEBUG - 2011-10-01 01:22:27 --> UTF-8 Support Enabled
DEBUG - 2011-10-01 01:22:27 --> URI Class Initialized
DEBUG - 2011-10-01 01:22:27 --> Router Class Initialized
DEBUG - 2011-10-01 01:22:27 --> Output Class Initialized
DEBUG - 2011-10-01 01:22:27 --> Input Class Initialized
DEBUG - 2011-10-01 01:22:27 --> Global POST and COOKIE data sanitized
DEBUG - 2011-10-01 01:22:27 --> Language Class Initialized
DEBUG - 2011-10-01 01:22:27 --> Loader Class Initialized
DEBUG - 2011-10-01 01:22:27 --> Controller Class Initialized
DEBUG - 2011-10-01 01:22:27 --> Model Class Initialized
DEBUG - 2011-10-01 01:22:27 --> Model Class Initialized
DEBUG - 2011-10-01 01:22:27 --> Model Class Initialized
DEBUG - 2011-10-01 01:22:27 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-10-01 01:22:28 --> Database Driver Class Initialized
DEBUG - 2011-10-01 01:22:28 --> File loaded: application/views/table/main.php
DEBUG - 2011-10-01 01:22:28 --> Helper loaded: url_helper
DEBUG - 2011-10-01 01:22:28 --> File loaded: application/views/common/header.php
DEBUG - 2011-10-01 01:22:28 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-10-01 01:22:28 --> File loaded: application/views/common/footer.php
DEBUG - 2011-10-01 01:22:28 --> File loaded: application/views/layout/main.php
DEBUG - 2011-10-01 01:22:28 --> Final output sent to browser
DEBUG - 2011-10-01 01:22:28 --> Total execution time: 0.2978
DEBUG - 2011-10-01 02:31:47 --> Config Class Initialized
DEBUG - 2011-10-01 02:31:47 --> Hooks Class Initialized
DEBUG - 2011-10-01 02:31:47 --> Utf8 Class Initialized
DEBUG - 2011-10-01 02:31:47 --> UTF-8 Support Enabled
DEBUG - 2011-10-01 02:31:47 --> URI Class Initialized
DEBUG - 2011-10-01 02:31:47 --> Router Class Initialized
DEBUG - 2011-10-01 02:31:48 --> Output Class Initialized
DEBUG - 2011-10-01 02:31:48 --> Input Class Initialized
DEBUG - 2011-10-01 02:31:48 --> Global POST and COOKIE data sanitized
DEBUG - 2011-10-01 02:31:48 --> Language Class Initialized
DEBUG - 2011-10-01 02:31:48 --> Loader Class Initialized
DEBUG - 2011-10-01 02:31:48 --> Controller Class Initialized
ERROR - 2011-10-01 02:31:49 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-10-01 02:31:49 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-10-01 02:31:49 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-10-01 02:31:49 --> Model Class Initialized
DEBUG - 2011-10-01 02:31:49 --> Model Class Initialized
DEBUG - 2011-10-01 02:31:49 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-10-01 02:31:49 --> Database Driver Class Initialized
DEBUG - 2011-10-01 02:31:50 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-10-01 02:31:50 --> Helper loaded: url_helper
DEBUG - 2011-10-01 02:31:50 --> File loaded: application/views/common/header.php
DEBUG - 2011-10-01 02:31:50 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-10-01 02:31:50 --> File loaded: application/views/common/footer.php
DEBUG - 2011-10-01 02:31:50 --> File loaded: application/views/layout/main.php
DEBUG - 2011-10-01 02:31:50 --> Final output sent to browser
DEBUG - 2011-10-01 02:31:50 --> Total execution time: 4.2354
DEBUG - 2011-10-01 02:31:55 --> Config Class Initialized
DEBUG - 2011-10-01 02:31:55 --> Hooks Class Initialized
DEBUG - 2011-10-01 02:31:55 --> Utf8 Class Initialized
DEBUG - 2011-10-01 02:31:55 --> UTF-8 Support Enabled
DEBUG - 2011-10-01 02:31:55 --> URI Class Initialized
DEBUG - 2011-10-01 02:31:55 --> Router Class Initialized
DEBUG - 2011-10-01 02:31:55 --> Output Class Initialized
DEBUG - 2011-10-01 02:31:55 --> Input Class Initialized
DEBUG - 2011-10-01 02:31:55 --> Global POST and COOKIE data sanitized
DEBUG - 2011-10-01 02:31:55 --> Language Class Initialized
DEBUG - 2011-10-01 02:31:55 --> Loader Class Initialized
DEBUG - 2011-10-01 02:31:55 --> Controller Class Initialized
DEBUG - 2011-10-01 02:31:55 --> Model Class Initialized
DEBUG - 2011-10-01 02:31:55 --> Model Class Initialized
DEBUG - 2011-10-01 02:31:55 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-10-01 02:31:55 --> Database Driver Class Initialized
DEBUG - 2011-10-01 02:31:57 --> Final output sent to browser
DEBUG - 2011-10-01 02:31:57 --> Total execution time: 2.0490
DEBUG - 2011-10-01 02:32:01 --> Config Class Initialized
DEBUG - 2011-10-01 02:32:01 --> Hooks Class Initialized
DEBUG - 2011-10-01 02:32:01 --> Utf8 Class Initialized
DEBUG - 2011-10-01 02:32:01 --> UTF-8 Support Enabled
DEBUG - 2011-10-01 02:32:01 --> URI Class Initialized
DEBUG - 2011-10-01 02:32:01 --> Router Class Initialized
ERROR - 2011-10-01 02:32:01 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-10-01 03:34:29 --> Config Class Initialized
DEBUG - 2011-10-01 03:34:29 --> Hooks Class Initialized
DEBUG - 2011-10-01 03:34:29 --> Utf8 Class Initialized
DEBUG - 2011-10-01 03:34:29 --> UTF-8 Support Enabled
DEBUG - 2011-10-01 03:34:29 --> URI Class Initialized
DEBUG - 2011-10-01 03:34:29 --> Router Class Initialized
DEBUG - 2011-10-01 03:34:29 --> Output Class Initialized
DEBUG - 2011-10-01 03:34:29 --> Input Class Initialized
DEBUG - 2011-10-01 03:34:29 --> Global POST and COOKIE data sanitized
DEBUG - 2011-10-01 03:34:29 --> Language Class Initialized
DEBUG - 2011-10-01 03:34:29 --> Loader Class Initialized
DEBUG - 2011-10-01 03:34:29 --> Controller Class Initialized
DEBUG - 2011-10-01 03:34:29 --> Model Class Initialized
DEBUG - 2011-10-01 03:34:29 --> Model Class Initialized
DEBUG - 2011-10-01 03:34:29 --> Model Class Initialized
DEBUG - 2011-10-01 03:34:29 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-10-01 03:34:29 --> Database Driver Class Initialized
DEBUG - 2011-10-01 03:34:32 --> File loaded: application/views/table/main.php
DEBUG - 2011-10-01 03:34:32 --> Helper loaded: url_helper
DEBUG - 2011-10-01 03:34:32 --> File loaded: application/views/common/header.php
DEBUG - 2011-10-01 03:34:32 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-10-01 03:34:32 --> File loaded: application/views/common/footer.php
DEBUG - 2011-10-01 03:34:32 --> File loaded: application/views/layout/main.php
DEBUG - 2011-10-01 03:34:32 --> Final output sent to browser
DEBUG - 2011-10-01 03:34:32 --> Total execution time: 2.6273
DEBUG - 2011-10-01 03:34:49 --> Config Class Initialized
DEBUG - 2011-10-01 03:34:49 --> Hooks Class Initialized
DEBUG - 2011-10-01 03:34:49 --> Utf8 Class Initialized
DEBUG - 2011-10-01 03:34:49 --> UTF-8 Support Enabled
DEBUG - 2011-10-01 03:34:49 --> URI Class Initialized
DEBUG - 2011-10-01 03:34:49 --> Router Class Initialized
ERROR - 2011-10-01 03:34:49 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-10-01 03:38:41 --> Config Class Initialized
DEBUG - 2011-10-01 03:38:41 --> Hooks Class Initialized
DEBUG - 2011-10-01 03:38:41 --> Utf8 Class Initialized
DEBUG - 2011-10-01 03:38:41 --> UTF-8 Support Enabled
DEBUG - 2011-10-01 03:38:41 --> URI Class Initialized
DEBUG - 2011-10-01 03:38:41 --> Router Class Initialized
DEBUG - 2011-10-01 03:38:41 --> Output Class Initialized
DEBUG - 2011-10-01 03:38:41 --> Input Class Initialized
DEBUG - 2011-10-01 03:38:41 --> Global POST and COOKIE data sanitized
DEBUG - 2011-10-01 03:38:41 --> Language Class Initialized
DEBUG - 2011-10-01 03:38:41 --> Loader Class Initialized
DEBUG - 2011-10-01 03:38:41 --> Controller Class Initialized
DEBUG - 2011-10-01 03:38:41 --> Model Class Initialized
DEBUG - 2011-10-01 03:38:41 --> Model Class Initialized
DEBUG - 2011-10-01 03:38:41 --> Model Class Initialized
DEBUG - 2011-10-01 03:38:41 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-10-01 03:38:42 --> Database Driver Class Initialized
DEBUG - 2011-10-01 03:38:45 --> File loaded: application/views/table/main.php
DEBUG - 2011-10-01 03:38:45 --> Helper loaded: url_helper
DEBUG - 2011-10-01 03:38:45 --> File loaded: application/views/common/header.php
DEBUG - 2011-10-01 03:38:45 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-10-01 03:38:45 --> File loaded: application/views/common/footer.php
DEBUG - 2011-10-01 03:38:45 --> File loaded: application/views/layout/main.php
DEBUG - 2011-10-01 03:38:45 --> Final output sent to browser
DEBUG - 2011-10-01 03:38:45 --> Total execution time: 3.7816
DEBUG - 2011-10-01 03:38:48 --> Config Class Initialized
DEBUG - 2011-10-01 03:38:48 --> Hooks Class Initialized
DEBUG - 2011-10-01 03:38:48 --> Utf8 Class Initialized
DEBUG - 2011-10-01 03:38:48 --> UTF-8 Support Enabled
DEBUG - 2011-10-01 03:38:48 --> URI Class Initialized
DEBUG - 2011-10-01 03:38:48 --> Router Class Initialized
ERROR - 2011-10-01 03:38:48 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-10-01 03:38:49 --> Config Class Initialized
DEBUG - 2011-10-01 03:38:49 --> Hooks Class Initialized
DEBUG - 2011-10-01 03:38:49 --> Utf8 Class Initialized
DEBUG - 2011-10-01 03:38:49 --> UTF-8 Support Enabled
DEBUG - 2011-10-01 03:38:49 --> URI Class Initialized
DEBUG - 2011-10-01 03:38:49 --> Router Class Initialized
DEBUG - 2011-10-01 03:38:49 --> Output Class Initialized
DEBUG - 2011-10-01 03:38:49 --> Input Class Initialized
DEBUG - 2011-10-01 03:38:49 --> Global POST and COOKIE data sanitized
DEBUG - 2011-10-01 03:38:49 --> Language Class Initialized
DEBUG - 2011-10-01 03:38:49 --> Loader Class Initialized
DEBUG - 2011-10-01 03:38:49 --> Controller Class Initialized
DEBUG - 2011-10-01 03:38:49 --> Model Class Initialized
DEBUG - 2011-10-01 03:38:49 --> Model Class Initialized
DEBUG - 2011-10-01 03:38:49 --> Model Class Initialized
DEBUG - 2011-10-01 03:38:49 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-10-01 03:38:49 --> Database Driver Class Initialized
DEBUG - 2011-10-01 03:38:49 --> File loaded: application/views/table/main.php
DEBUG - 2011-10-01 03:38:49 --> Helper loaded: url_helper
DEBUG - 2011-10-01 03:38:49 --> File loaded: application/views/common/header.php
DEBUG - 2011-10-01 03:38:49 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-10-01 03:38:49 --> File loaded: application/views/common/footer.php
DEBUG - 2011-10-01 03:38:49 --> File loaded: application/views/layout/main.php
DEBUG - 2011-10-01 03:38:49 --> Final output sent to browser
DEBUG - 2011-10-01 03:38:49 --> Total execution time: 0.0647
DEBUG - 2011-10-01 03:39:44 --> Config Class Initialized
DEBUG - 2011-10-01 03:39:44 --> Hooks Class Initialized
DEBUG - 2011-10-01 03:39:44 --> Utf8 Class Initialized
DEBUG - 2011-10-01 03:39:44 --> UTF-8 Support Enabled
DEBUG - 2011-10-01 03:39:44 --> URI Class Initialized
DEBUG - 2011-10-01 03:39:44 --> Router Class Initialized
DEBUG - 2011-10-01 03:39:44 --> Output Class Initialized
DEBUG - 2011-10-01 03:39:44 --> Input Class Initialized
DEBUG - 2011-10-01 03:39:44 --> Global POST and COOKIE data sanitized
DEBUG - 2011-10-01 03:39:44 --> Language Class Initialized
DEBUG - 2011-10-01 03:39:44 --> Loader Class Initialized
DEBUG - 2011-10-01 03:39:44 --> Controller Class Initialized
DEBUG - 2011-10-01 03:39:44 --> Model Class Initialized
DEBUG - 2011-10-01 03:39:44 --> Model Class Initialized
DEBUG - 2011-10-01 03:39:44 --> Model Class Initialized
DEBUG - 2011-10-01 03:39:44 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-10-01 03:39:44 --> Database Driver Class Initialized
DEBUG - 2011-10-01 03:39:44 --> File loaded: application/views/table/main.php
DEBUG - 2011-10-01 03:39:44 --> Helper loaded: url_helper
DEBUG - 2011-10-01 03:39:44 --> File loaded: application/views/common/header.php
DEBUG - 2011-10-01 03:39:44 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-10-01 03:39:44 --> File loaded: application/views/common/footer.php
DEBUG - 2011-10-01 03:39:44 --> File loaded: application/views/layout/main.php
DEBUG - 2011-10-01 03:39:44 --> Final output sent to browser
DEBUG - 2011-10-01 03:39:44 --> Total execution time: 0.2588
DEBUG - 2011-10-01 03:39:47 --> Config Class Initialized
DEBUG - 2011-10-01 03:39:47 --> Hooks Class Initialized
DEBUG - 2011-10-01 03:39:47 --> Utf8 Class Initialized
DEBUG - 2011-10-01 03:39:47 --> UTF-8 Support Enabled
DEBUG - 2011-10-01 03:39:47 --> URI Class Initialized
DEBUG - 2011-10-01 03:39:47 --> Router Class Initialized
ERROR - 2011-10-01 03:39:47 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-10-01 03:39:47 --> Config Class Initialized
DEBUG - 2011-10-01 03:39:47 --> Hooks Class Initialized
DEBUG - 2011-10-01 03:39:47 --> Utf8 Class Initialized
DEBUG - 2011-10-01 03:39:47 --> UTF-8 Support Enabled
DEBUG - 2011-10-01 03:39:47 --> URI Class Initialized
DEBUG - 2011-10-01 03:39:47 --> Router Class Initialized
DEBUG - 2011-10-01 03:39:47 --> Output Class Initialized
DEBUG - 2011-10-01 03:39:47 --> Input Class Initialized
DEBUG - 2011-10-01 03:39:47 --> Global POST and COOKIE data sanitized
DEBUG - 2011-10-01 03:39:47 --> Language Class Initialized
DEBUG - 2011-10-01 03:39:47 --> Loader Class Initialized
DEBUG - 2011-10-01 03:39:47 --> Controller Class Initialized
DEBUG - 2011-10-01 03:39:47 --> Model Class Initialized
DEBUG - 2011-10-01 03:39:47 --> Model Class Initialized
DEBUG - 2011-10-01 03:39:47 --> Model Class Initialized
DEBUG - 2011-10-01 03:39:47 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-10-01 03:39:47 --> Database Driver Class Initialized
DEBUG - 2011-10-01 03:39:47 --> File loaded: application/views/table/main.php
DEBUG - 2011-10-01 03:39:47 --> Helper loaded: url_helper
DEBUG - 2011-10-01 03:39:47 --> File loaded: application/views/common/header.php
DEBUG - 2011-10-01 03:39:47 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-10-01 03:39:47 --> File loaded: application/views/common/footer.php
DEBUG - 2011-10-01 03:39:47 --> File loaded: application/views/layout/main.php
DEBUG - 2011-10-01 03:39:47 --> Final output sent to browser
DEBUG - 2011-10-01 03:39:47 --> Total execution time: 0.0559
DEBUG - 2011-10-01 03:40:29 --> Config Class Initialized
DEBUG - 2011-10-01 03:40:29 --> Hooks Class Initialized
DEBUG - 2011-10-01 03:40:29 --> Utf8 Class Initialized
DEBUG - 2011-10-01 03:40:29 --> UTF-8 Support Enabled
DEBUG - 2011-10-01 03:40:29 --> URI Class Initialized
DEBUG - 2011-10-01 03:40:29 --> Router Class Initialized
DEBUG - 2011-10-01 03:40:29 --> Output Class Initialized
DEBUG - 2011-10-01 03:40:29 --> Input Class Initialized
DEBUG - 2011-10-01 03:40:29 --> Global POST and COOKIE data sanitized
DEBUG - 2011-10-01 03:40:29 --> Language Class Initialized
DEBUG - 2011-10-01 03:40:29 --> Loader Class Initialized
DEBUG - 2011-10-01 03:40:29 --> Controller Class Initialized
DEBUG - 2011-10-01 03:40:29 --> Model Class Initialized
DEBUG - 2011-10-01 03:40:29 --> Model Class Initialized
DEBUG - 2011-10-01 03:40:29 --> Model Class Initialized
DEBUG - 2011-10-01 03:40:29 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-10-01 03:40:29 --> Database Driver Class Initialized
DEBUG - 2011-10-01 03:40:30 --> File loaded: application/views/table/main.php
DEBUG - 2011-10-01 03:40:30 --> Helper loaded: url_helper
DEBUG - 2011-10-01 03:40:30 --> File loaded: application/views/common/header.php
DEBUG - 2011-10-01 03:40:30 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-10-01 03:40:30 --> File loaded: application/views/common/footer.php
DEBUG - 2011-10-01 03:40:30 --> File loaded: application/views/layout/main.php
DEBUG - 2011-10-01 03:40:30 --> Final output sent to browser
DEBUG - 2011-10-01 03:40:30 --> Total execution time: 1.0591
DEBUG - 2011-10-01 03:40:32 --> Config Class Initialized
DEBUG - 2011-10-01 03:40:32 --> Hooks Class Initialized
DEBUG - 2011-10-01 03:40:32 --> Utf8 Class Initialized
DEBUG - 2011-10-01 03:40:32 --> UTF-8 Support Enabled
DEBUG - 2011-10-01 03:40:32 --> URI Class Initialized
DEBUG - 2011-10-01 03:40:32 --> Router Class Initialized
ERROR - 2011-10-01 03:40:32 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-10-01 03:41:10 --> Config Class Initialized
DEBUG - 2011-10-01 03:41:10 --> Hooks Class Initialized
DEBUG - 2011-10-01 03:41:10 --> Utf8 Class Initialized
DEBUG - 2011-10-01 03:41:10 --> UTF-8 Support Enabled
DEBUG - 2011-10-01 03:41:10 --> URI Class Initialized
DEBUG - 2011-10-01 03:41:10 --> Router Class Initialized
DEBUG - 2011-10-01 03:41:10 --> Output Class Initialized
DEBUG - 2011-10-01 03:41:10 --> Input Class Initialized
DEBUG - 2011-10-01 03:41:10 --> Global POST and COOKIE data sanitized
DEBUG - 2011-10-01 03:41:10 --> Language Class Initialized
DEBUG - 2011-10-01 03:41:10 --> Loader Class Initialized
DEBUG - 2011-10-01 03:41:10 --> Controller Class Initialized
DEBUG - 2011-10-01 03:41:10 --> Model Class Initialized
DEBUG - 2011-10-01 03:41:10 --> Model Class Initialized
DEBUG - 2011-10-01 03:41:10 --> Model Class Initialized
DEBUG - 2011-10-01 03:41:10 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-10-01 03:41:10 --> Database Driver Class Initialized
DEBUG - 2011-10-01 03:41:10 --> File loaded: application/views/table/main.php
DEBUG - 2011-10-01 03:41:10 --> Helper loaded: url_helper
DEBUG - 2011-10-01 03:41:10 --> File loaded: application/views/common/header.php
DEBUG - 2011-10-01 03:41:10 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-10-01 03:41:10 --> File loaded: application/views/common/footer.php
DEBUG - 2011-10-01 03:41:10 --> File loaded: application/views/layout/main.php
DEBUG - 2011-10-01 03:41:10 --> Final output sent to browser
DEBUG - 2011-10-01 03:41:10 --> Total execution time: 0.3621
DEBUG - 2011-10-01 03:41:12 --> Config Class Initialized
DEBUG - 2011-10-01 03:41:12 --> Hooks Class Initialized
DEBUG - 2011-10-01 03:41:12 --> Utf8 Class Initialized
DEBUG - 2011-10-01 03:41:12 --> UTF-8 Support Enabled
DEBUG - 2011-10-01 03:41:12 --> URI Class Initialized
DEBUG - 2011-10-01 03:41:12 --> Router Class Initialized
ERROR - 2011-10-01 03:41:12 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-10-01 03:41:20 --> Config Class Initialized
DEBUG - 2011-10-01 03:41:20 --> Hooks Class Initialized
DEBUG - 2011-10-01 03:41:20 --> Utf8 Class Initialized
DEBUG - 2011-10-01 03:41:20 --> UTF-8 Support Enabled
DEBUG - 2011-10-01 03:41:20 --> URI Class Initialized
DEBUG - 2011-10-01 03:41:20 --> Router Class Initialized
DEBUG - 2011-10-01 03:41:20 --> Output Class Initialized
DEBUG - 2011-10-01 03:41:20 --> Input Class Initialized
DEBUG - 2011-10-01 03:41:20 --> Global POST and COOKIE data sanitized
DEBUG - 2011-10-01 03:41:20 --> Language Class Initialized
DEBUG - 2011-10-01 03:41:20 --> Loader Class Initialized
DEBUG - 2011-10-01 03:41:20 --> Controller Class Initialized
DEBUG - 2011-10-01 03:41:20 --> Model Class Initialized
DEBUG - 2011-10-01 03:41:20 --> Model Class Initialized
DEBUG - 2011-10-01 03:41:20 --> Model Class Initialized
DEBUG - 2011-10-01 03:41:20 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-10-01 03:41:20 --> Database Driver Class Initialized
DEBUG - 2011-10-01 03:41:20 --> File loaded: application/views/table/main.php
DEBUG - 2011-10-01 03:41:20 --> Helper loaded: url_helper
DEBUG - 2011-10-01 03:41:20 --> File loaded: application/views/common/header.php
DEBUG - 2011-10-01 03:41:20 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-10-01 03:41:20 --> File loaded: application/views/common/footer.php
DEBUG - 2011-10-01 03:41:20 --> File loaded: application/views/layout/main.php
DEBUG - 2011-10-01 03:41:20 --> Final output sent to browser
DEBUG - 2011-10-01 03:41:20 --> Total execution time: 0.0695
DEBUG - 2011-10-01 03:41:30 --> Config Class Initialized
DEBUG - 2011-10-01 03:41:30 --> Hooks Class Initialized
DEBUG - 2011-10-01 03:41:30 --> Utf8 Class Initialized
DEBUG - 2011-10-01 03:41:30 --> UTF-8 Support Enabled
DEBUG - 2011-10-01 03:41:30 --> URI Class Initialized
DEBUG - 2011-10-01 03:41:30 --> Router Class Initialized
DEBUG - 2011-10-01 03:41:30 --> Output Class Initialized
DEBUG - 2011-10-01 03:41:30 --> Input Class Initialized
DEBUG - 2011-10-01 03:41:30 --> Global POST and COOKIE data sanitized
DEBUG - 2011-10-01 03:41:30 --> Language Class Initialized
DEBUG - 2011-10-01 03:41:30 --> Loader Class Initialized
DEBUG - 2011-10-01 03:41:30 --> Controller Class Initialized
DEBUG - 2011-10-01 03:41:30 --> Model Class Initialized
DEBUG - 2011-10-01 03:41:30 --> Model Class Initialized
DEBUG - 2011-10-01 03:41:30 --> Model Class Initialized
DEBUG - 2011-10-01 03:41:30 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-10-01 03:41:30 --> Database Driver Class Initialized
DEBUG - 2011-10-01 03:41:35 --> File loaded: application/views/table/main.php
DEBUG - 2011-10-01 03:41:35 --> Helper loaded: url_helper
DEBUG - 2011-10-01 03:41:35 --> File loaded: application/views/common/header.php
DEBUG - 2011-10-01 03:41:35 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-10-01 03:41:35 --> File loaded: application/views/common/footer.php
DEBUG - 2011-10-01 03:41:35 --> File loaded: application/views/layout/main.php
DEBUG - 2011-10-01 03:41:35 --> Final output sent to browser
DEBUG - 2011-10-01 03:41:35 --> Total execution time: 4.9764
DEBUG - 2011-10-01 03:41:38 --> Config Class Initialized
DEBUG - 2011-10-01 03:41:39 --> Hooks Class Initialized
DEBUG - 2011-10-01 03:41:39 --> Utf8 Class Initialized
DEBUG - 2011-10-01 03:41:39 --> UTF-8 Support Enabled
DEBUG - 2011-10-01 03:41:39 --> URI Class Initialized
DEBUG - 2011-10-01 03:41:39 --> Router Class Initialized
ERROR - 2011-10-01 03:41:39 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-10-01 03:41:51 --> Config Class Initialized
DEBUG - 2011-10-01 03:41:51 --> Hooks Class Initialized
DEBUG - 2011-10-01 03:41:51 --> Utf8 Class Initialized
DEBUG - 2011-10-01 03:41:51 --> UTF-8 Support Enabled
DEBUG - 2011-10-01 03:41:51 --> URI Class Initialized
DEBUG - 2011-10-01 03:41:51 --> Router Class Initialized
DEBUG - 2011-10-01 03:41:51 --> Output Class Initialized
DEBUG - 2011-10-01 03:41:51 --> Input Class Initialized
DEBUG - 2011-10-01 03:41:51 --> Global POST and COOKIE data sanitized
DEBUG - 2011-10-01 03:41:51 --> Language Class Initialized
DEBUG - 2011-10-01 03:41:51 --> Loader Class Initialized
DEBUG - 2011-10-01 03:41:51 --> Controller Class Initialized
DEBUG - 2011-10-01 03:41:51 --> Model Class Initialized
DEBUG - 2011-10-01 03:41:51 --> Model Class Initialized
DEBUG - 2011-10-01 03:41:51 --> Model Class Initialized
DEBUG - 2011-10-01 03:41:51 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-10-01 03:41:51 --> Database Driver Class Initialized
DEBUG - 2011-10-01 03:41:56 --> File loaded: application/views/table/main.php
DEBUG - 2011-10-01 03:41:56 --> Helper loaded: url_helper
DEBUG - 2011-10-01 03:41:56 --> File loaded: application/views/common/header.php
DEBUG - 2011-10-01 03:41:56 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-10-01 03:41:56 --> File loaded: application/views/common/footer.php
DEBUG - 2011-10-01 03:41:56 --> File loaded: application/views/layout/main.php
DEBUG - 2011-10-01 03:41:56 --> Final output sent to browser
DEBUG - 2011-10-01 03:41:56 --> Total execution time: 5.3786
DEBUG - 2011-10-01 03:41:58 --> Config Class Initialized
DEBUG - 2011-10-01 03:41:58 --> Hooks Class Initialized
DEBUG - 2011-10-01 03:41:58 --> Utf8 Class Initialized
DEBUG - 2011-10-01 03:41:58 --> UTF-8 Support Enabled
DEBUG - 2011-10-01 03:41:58 --> URI Class Initialized
DEBUG - 2011-10-01 03:41:58 --> Router Class Initialized
ERROR - 2011-10-01 03:41:58 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-10-01 03:42:12 --> Config Class Initialized
DEBUG - 2011-10-01 03:42:12 --> Hooks Class Initialized
DEBUG - 2011-10-01 03:42:12 --> Utf8 Class Initialized
DEBUG - 2011-10-01 03:42:12 --> UTF-8 Support Enabled
DEBUG - 2011-10-01 03:42:12 --> URI Class Initialized
DEBUG - 2011-10-01 03:42:12 --> Router Class Initialized
DEBUG - 2011-10-01 03:42:12 --> Output Class Initialized
DEBUG - 2011-10-01 03:42:12 --> Input Class Initialized
DEBUG - 2011-10-01 03:42:12 --> Global POST and COOKIE data sanitized
DEBUG - 2011-10-01 03:42:12 --> Language Class Initialized
DEBUG - 2011-10-01 03:42:12 --> Loader Class Initialized
DEBUG - 2011-10-01 03:42:12 --> Controller Class Initialized
DEBUG - 2011-10-01 03:42:12 --> Model Class Initialized
DEBUG - 2011-10-01 03:42:12 --> Model Class Initialized
DEBUG - 2011-10-01 03:42:12 --> Model Class Initialized
DEBUG - 2011-10-01 03:42:12 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-10-01 03:42:12 --> Database Driver Class Initialized
DEBUG - 2011-10-01 03:42:12 --> File loaded: application/views/table/main.php
DEBUG - 2011-10-01 03:42:12 --> Helper loaded: url_helper
DEBUG - 2011-10-01 03:42:12 --> File loaded: application/views/common/header.php
DEBUG - 2011-10-01 03:42:12 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-10-01 03:42:12 --> File loaded: application/views/common/footer.php
DEBUG - 2011-10-01 03:42:12 --> File loaded: application/views/layout/main.php
DEBUG - 2011-10-01 03:42:12 --> Final output sent to browser
DEBUG - 2011-10-01 03:42:12 --> Total execution time: 0.4387
DEBUG - 2011-10-01 03:42:15 --> Config Class Initialized
DEBUG - 2011-10-01 03:42:15 --> Hooks Class Initialized
DEBUG - 2011-10-01 03:42:15 --> Utf8 Class Initialized
DEBUG - 2011-10-01 03:42:15 --> UTF-8 Support Enabled
DEBUG - 2011-10-01 03:42:15 --> URI Class Initialized
DEBUG - 2011-10-01 03:42:15 --> Router Class Initialized
ERROR - 2011-10-01 03:42:15 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-10-01 03:42:52 --> Config Class Initialized
DEBUG - 2011-10-01 03:42:52 --> Hooks Class Initialized
DEBUG - 2011-10-01 03:42:52 --> Utf8 Class Initialized
DEBUG - 2011-10-01 03:42:52 --> UTF-8 Support Enabled
DEBUG - 2011-10-01 03:42:52 --> URI Class Initialized
DEBUG - 2011-10-01 03:42:52 --> Router Class Initialized
DEBUG - 2011-10-01 03:42:52 --> Output Class Initialized
DEBUG - 2011-10-01 03:42:52 --> Input Class Initialized
DEBUG - 2011-10-01 03:42:52 --> Global POST and COOKIE data sanitized
DEBUG - 2011-10-01 03:42:52 --> Language Class Initialized
DEBUG - 2011-10-01 03:42:52 --> Loader Class Initialized
DEBUG - 2011-10-01 03:42:52 --> Controller Class Initialized
DEBUG - 2011-10-01 03:42:52 --> Model Class Initialized
DEBUG - 2011-10-01 03:42:52 --> Model Class Initialized
DEBUG - 2011-10-01 03:42:52 --> Model Class Initialized
DEBUG - 2011-10-01 03:42:52 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-10-01 03:42:52 --> Database Driver Class Initialized
DEBUG - 2011-10-01 03:42:53 --> File loaded: application/views/table/main.php
DEBUG - 2011-10-01 03:42:53 --> Helper loaded: url_helper
DEBUG - 2011-10-01 03:42:53 --> File loaded: application/views/common/header.php
DEBUG - 2011-10-01 03:42:53 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-10-01 03:42:53 --> File loaded: application/views/common/footer.php
DEBUG - 2011-10-01 03:42:53 --> File loaded: application/views/layout/main.php
DEBUG - 2011-10-01 03:42:53 --> Final output sent to browser
DEBUG - 2011-10-01 03:42:53 --> Total execution time: 0.5802
DEBUG - 2011-10-01 03:42:56 --> Config Class Initialized
DEBUG - 2011-10-01 03:42:56 --> Hooks Class Initialized
DEBUG - 2011-10-01 03:42:56 --> Utf8 Class Initialized
DEBUG - 2011-10-01 03:42:56 --> UTF-8 Support Enabled
DEBUG - 2011-10-01 03:42:56 --> URI Class Initialized
DEBUG - 2011-10-01 03:42:56 --> Router Class Initialized
ERROR - 2011-10-01 03:42:56 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-10-01 03:43:30 --> Config Class Initialized
DEBUG - 2011-10-01 03:43:30 --> Hooks Class Initialized
DEBUG - 2011-10-01 03:43:30 --> Utf8 Class Initialized
DEBUG - 2011-10-01 03:43:30 --> UTF-8 Support Enabled
DEBUG - 2011-10-01 03:43:30 --> URI Class Initialized
DEBUG - 2011-10-01 03:43:30 --> Router Class Initialized
DEBUG - 2011-10-01 03:43:30 --> Output Class Initialized
DEBUG - 2011-10-01 03:43:30 --> Input Class Initialized
DEBUG - 2011-10-01 03:43:30 --> Global POST and COOKIE data sanitized
DEBUG - 2011-10-01 03:43:30 --> Language Class Initialized
DEBUG - 2011-10-01 03:43:30 --> Loader Class Initialized
DEBUG - 2011-10-01 03:43:30 --> Controller Class Initialized
DEBUG - 2011-10-01 03:43:30 --> Model Class Initialized
DEBUG - 2011-10-01 03:43:30 --> Model Class Initialized
DEBUG - 2011-10-01 03:43:30 --> Model Class Initialized
DEBUG - 2011-10-01 03:43:30 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-10-01 03:43:30 --> Database Driver Class Initialized
DEBUG - 2011-10-01 03:43:30 --> File loaded: application/views/table/main.php
DEBUG - 2011-10-01 03:43:30 --> Helper loaded: url_helper
DEBUG - 2011-10-01 03:43:30 --> File loaded: application/views/common/header.php
DEBUG - 2011-10-01 03:43:30 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-10-01 03:43:30 --> File loaded: application/views/common/footer.php
DEBUG - 2011-10-01 03:43:30 --> File loaded: application/views/layout/main.php
DEBUG - 2011-10-01 03:43:30 --> Final output sent to browser
DEBUG - 2011-10-01 03:43:30 --> Total execution time: 0.0465
DEBUG - 2011-10-01 03:43:31 --> Config Class Initialized
DEBUG - 2011-10-01 03:43:31 --> Hooks Class Initialized
DEBUG - 2011-10-01 03:43:31 --> Utf8 Class Initialized
DEBUG - 2011-10-01 03:43:31 --> UTF-8 Support Enabled
DEBUG - 2011-10-01 03:43:31 --> URI Class Initialized
DEBUG - 2011-10-01 03:43:31 --> Router Class Initialized
DEBUG - 2011-10-01 03:43:31 --> Output Class Initialized
DEBUG - 2011-10-01 03:43:31 --> Input Class Initialized
DEBUG - 2011-10-01 03:43:31 --> Global POST and COOKIE data sanitized
DEBUG - 2011-10-01 03:43:31 --> Language Class Initialized
DEBUG - 2011-10-01 03:43:31 --> Loader Class Initialized
DEBUG - 2011-10-01 03:43:31 --> Controller Class Initialized
DEBUG - 2011-10-01 03:43:31 --> Model Class Initialized
DEBUG - 2011-10-01 03:43:31 --> Model Class Initialized
DEBUG - 2011-10-01 03:43:31 --> Model Class Initialized
DEBUG - 2011-10-01 03:43:31 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-10-01 03:43:31 --> Database Driver Class Initialized
DEBUG - 2011-10-01 03:43:31 --> File loaded: application/views/table/main.php
DEBUG - 2011-10-01 03:43:31 --> Helper loaded: url_helper
DEBUG - 2011-10-01 03:43:31 --> File loaded: application/views/common/header.php
DEBUG - 2011-10-01 03:43:31 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-10-01 03:43:31 --> File loaded: application/views/common/footer.php
DEBUG - 2011-10-01 03:43:31 --> File loaded: application/views/layout/main.php
DEBUG - 2011-10-01 03:43:31 --> Final output sent to browser
DEBUG - 2011-10-01 03:43:31 --> Total execution time: 0.0617
DEBUG - 2011-10-01 03:43:35 --> Config Class Initialized
DEBUG - 2011-10-01 03:43:35 --> Hooks Class Initialized
DEBUG - 2011-10-01 03:43:35 --> Utf8 Class Initialized
DEBUG - 2011-10-01 03:43:35 --> UTF-8 Support Enabled
DEBUG - 2011-10-01 03:43:35 --> URI Class Initialized
DEBUG - 2011-10-01 03:43:35 --> Router Class Initialized
DEBUG - 2011-10-01 03:43:35 --> Output Class Initialized
DEBUG - 2011-10-01 03:43:35 --> Input Class Initialized
DEBUG - 2011-10-01 03:43:35 --> Global POST and COOKIE data sanitized
DEBUG - 2011-10-01 03:43:35 --> Language Class Initialized
DEBUG - 2011-10-01 03:43:35 --> Loader Class Initialized
DEBUG - 2011-10-01 03:43:35 --> Controller Class Initialized
DEBUG - 2011-10-01 03:43:35 --> Model Class Initialized
DEBUG - 2011-10-01 03:43:35 --> Model Class Initialized
DEBUG - 2011-10-01 03:43:35 --> Model Class Initialized
DEBUG - 2011-10-01 03:43:35 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-10-01 03:43:35 --> Database Driver Class Initialized
DEBUG - 2011-10-01 03:43:37 --> File loaded: application/views/table/main.php
DEBUG - 2011-10-01 03:43:37 --> Helper loaded: url_helper
DEBUG - 2011-10-01 03:43:37 --> File loaded: application/views/common/header.php
DEBUG - 2011-10-01 03:43:37 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-10-01 03:43:37 --> File loaded: application/views/common/footer.php
DEBUG - 2011-10-01 03:43:37 --> File loaded: application/views/layout/main.php
DEBUG - 2011-10-01 03:43:37 --> Final output sent to browser
DEBUG - 2011-10-01 03:43:37 --> Total execution time: 2.3336
DEBUG - 2011-10-01 03:43:37 --> Config Class Initialized
DEBUG - 2011-10-01 03:43:37 --> Hooks Class Initialized
DEBUG - 2011-10-01 03:43:37 --> Utf8 Class Initialized
DEBUG - 2011-10-01 03:43:37 --> UTF-8 Support Enabled
DEBUG - 2011-10-01 03:43:37 --> URI Class Initialized
DEBUG - 2011-10-01 03:43:37 --> Router Class Initialized
DEBUG - 2011-10-01 03:43:37 --> Output Class Initialized
DEBUG - 2011-10-01 03:43:37 --> Input Class Initialized
DEBUG - 2011-10-01 03:43:37 --> Global POST and COOKIE data sanitized
DEBUG - 2011-10-01 03:43:37 --> Language Class Initialized
DEBUG - 2011-10-01 03:43:37 --> Loader Class Initialized
DEBUG - 2011-10-01 03:43:37 --> Controller Class Initialized
DEBUG - 2011-10-01 03:43:37 --> Model Class Initialized
DEBUG - 2011-10-01 03:43:37 --> Model Class Initialized
DEBUG - 2011-10-01 03:43:37 --> Model Class Initialized
DEBUG - 2011-10-01 03:43:37 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-10-01 03:43:37 --> Database Driver Class Initialized
DEBUG - 2011-10-01 03:43:37 --> File loaded: application/views/table/main.php
DEBUG - 2011-10-01 03:43:37 --> Helper loaded: url_helper
DEBUG - 2011-10-01 03:43:37 --> File loaded: application/views/common/header.php
DEBUG - 2011-10-01 03:43:37 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-10-01 03:43:37 --> File loaded: application/views/common/footer.php
DEBUG - 2011-10-01 03:43:37 --> File loaded: application/views/layout/main.php
DEBUG - 2011-10-01 03:43:37 --> Final output sent to browser
DEBUG - 2011-10-01 03:43:37 --> Total execution time: 0.0654
DEBUG - 2011-10-01 03:43:38 --> Config Class Initialized
DEBUG - 2011-10-01 03:43:38 --> Hooks Class Initialized
DEBUG - 2011-10-01 03:43:38 --> Utf8 Class Initialized
DEBUG - 2011-10-01 03:43:38 --> UTF-8 Support Enabled
DEBUG - 2011-10-01 03:43:38 --> URI Class Initialized
DEBUG - 2011-10-01 03:43:38 --> Router Class Initialized
DEBUG - 2011-10-01 03:43:38 --> Output Class Initialized
DEBUG - 2011-10-01 03:43:38 --> Input Class Initialized
DEBUG - 2011-10-01 03:43:38 --> Global POST and COOKIE data sanitized
DEBUG - 2011-10-01 03:43:38 --> Language Class Initialized
DEBUG - 2011-10-01 03:43:38 --> Loader Class Initialized
DEBUG - 2011-10-01 03:43:38 --> Controller Class Initialized
DEBUG - 2011-10-01 03:43:38 --> Model Class Initialized
DEBUG - 2011-10-01 03:43:38 --> Model Class Initialized
DEBUG - 2011-10-01 03:43:38 --> Model Class Initialized
DEBUG - 2011-10-01 03:43:38 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-10-01 03:43:38 --> Database Driver Class Initialized
DEBUG - 2011-10-01 03:43:38 --> File loaded: application/views/table/main.php
DEBUG - 2011-10-01 03:43:38 --> Helper loaded: url_helper
DEBUG - 2011-10-01 03:43:38 --> File loaded: application/views/common/header.php
DEBUG - 2011-10-01 03:43:38 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-10-01 03:43:38 --> File loaded: application/views/common/footer.php
DEBUG - 2011-10-01 03:43:38 --> File loaded: application/views/layout/main.php
DEBUG - 2011-10-01 03:43:38 --> Final output sent to browser
DEBUG - 2011-10-01 03:43:38 --> Total execution time: 0.0996
DEBUG - 2011-10-01 03:43:39 --> Config Class Initialized
DEBUG - 2011-10-01 03:43:39 --> Hooks Class Initialized
DEBUG - 2011-10-01 03:43:39 --> Utf8 Class Initialized
DEBUG - 2011-10-01 03:43:39 --> UTF-8 Support Enabled
DEBUG - 2011-10-01 03:43:39 --> URI Class Initialized
DEBUG - 2011-10-01 03:43:39 --> Router Class Initialized
ERROR - 2011-10-01 03:43:39 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-10-01 03:43:44 --> Config Class Initialized
DEBUG - 2011-10-01 03:43:44 --> Hooks Class Initialized
DEBUG - 2011-10-01 03:43:44 --> Utf8 Class Initialized
DEBUG - 2011-10-01 03:43:44 --> UTF-8 Support Enabled
DEBUG - 2011-10-01 03:43:44 --> URI Class Initialized
DEBUG - 2011-10-01 03:43:44 --> Router Class Initialized
DEBUG - 2011-10-01 03:43:44 --> Output Class Initialized
DEBUG - 2011-10-01 03:43:44 --> Input Class Initialized
DEBUG - 2011-10-01 03:43:44 --> Global POST and COOKIE data sanitized
DEBUG - 2011-10-01 03:43:44 --> Language Class Initialized
DEBUG - 2011-10-01 03:43:44 --> Loader Class Initialized
DEBUG - 2011-10-01 03:43:44 --> Controller Class Initialized
DEBUG - 2011-10-01 03:43:44 --> Model Class Initialized
DEBUG - 2011-10-01 03:43:44 --> Model Class Initialized
DEBUG - 2011-10-01 03:43:44 --> Model Class Initialized
DEBUG - 2011-10-01 03:43:44 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-10-01 03:43:44 --> Database Driver Class Initialized
DEBUG - 2011-10-01 03:43:44 --> File loaded: application/views/table/main.php
DEBUG - 2011-10-01 03:43:44 --> Helper loaded: url_helper
DEBUG - 2011-10-01 03:43:44 --> File loaded: application/views/common/header.php
DEBUG - 2011-10-01 03:43:44 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-10-01 03:43:44 --> File loaded: application/views/common/footer.php
DEBUG - 2011-10-01 03:43:44 --> File loaded: application/views/layout/main.php
DEBUG - 2011-10-01 03:43:44 --> Final output sent to browser
DEBUG - 2011-10-01 03:43:44 --> Total execution time: 0.1220
DEBUG - 2011-10-01 03:43:51 --> Config Class Initialized
DEBUG - 2011-10-01 03:43:51 --> Hooks Class Initialized
DEBUG - 2011-10-01 03:43:51 --> Utf8 Class Initialized
DEBUG - 2011-10-01 03:43:51 --> UTF-8 Support Enabled
DEBUG - 2011-10-01 03:43:51 --> URI Class Initialized
DEBUG - 2011-10-01 03:43:51 --> Router Class Initialized
DEBUG - 2011-10-01 03:43:51 --> Output Class Initialized
DEBUG - 2011-10-01 03:43:51 --> Input Class Initialized
DEBUG - 2011-10-01 03:43:51 --> Global POST and COOKIE data sanitized
DEBUG - 2011-10-01 03:43:51 --> Language Class Initialized
DEBUG - 2011-10-01 03:43:51 --> Loader Class Initialized
DEBUG - 2011-10-01 03:43:51 --> Controller Class Initialized
DEBUG - 2011-10-01 03:43:51 --> Model Class Initialized
DEBUG - 2011-10-01 03:43:51 --> Model Class Initialized
DEBUG - 2011-10-01 03:43:51 --> Model Class Initialized
DEBUG - 2011-10-01 03:43:51 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-10-01 03:43:51 --> Database Driver Class Initialized
DEBUG - 2011-10-01 03:43:54 --> File loaded: application/views/table/main.php
DEBUG - 2011-10-01 03:43:54 --> Helper loaded: url_helper
DEBUG - 2011-10-01 03:43:54 --> File loaded: application/views/common/header.php
DEBUG - 2011-10-01 03:43:54 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-10-01 03:43:54 --> File loaded: application/views/common/footer.php
DEBUG - 2011-10-01 03:43:54 --> File loaded: application/views/layout/main.php
DEBUG - 2011-10-01 03:43:54 --> Final output sent to browser
DEBUG - 2011-10-01 03:43:54 --> Total execution time: 3.5731
DEBUG - 2011-10-01 03:43:56 --> Config Class Initialized
DEBUG - 2011-10-01 03:43:56 --> Hooks Class Initialized
DEBUG - 2011-10-01 03:43:56 --> Utf8 Class Initialized
DEBUG - 2011-10-01 03:43:56 --> UTF-8 Support Enabled
DEBUG - 2011-10-01 03:43:56 --> URI Class Initialized
DEBUG - 2011-10-01 03:43:56 --> Router Class Initialized
DEBUG - 2011-10-01 03:43:56 --> Output Class Initialized
DEBUG - 2011-10-01 03:43:56 --> Input Class Initialized
DEBUG - 2011-10-01 03:43:56 --> Global POST and COOKIE data sanitized
DEBUG - 2011-10-01 03:43:56 --> Language Class Initialized
DEBUG - 2011-10-01 03:43:56 --> Loader Class Initialized
DEBUG - 2011-10-01 03:43:56 --> Controller Class Initialized
DEBUG - 2011-10-01 03:43:56 --> Model Class Initialized
DEBUG - 2011-10-01 03:43:56 --> Model Class Initialized
DEBUG - 2011-10-01 03:43:56 --> Model Class Initialized
DEBUG - 2011-10-01 03:43:56 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-10-01 03:43:56 --> Database Driver Class Initialized
DEBUG - 2011-10-01 03:43:56 --> File loaded: application/views/table/main.php
DEBUG - 2011-10-01 03:43:56 --> Helper loaded: url_helper
DEBUG - 2011-10-01 03:43:56 --> File loaded: application/views/common/header.php
DEBUG - 2011-10-01 03:43:56 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-10-01 03:43:56 --> File loaded: application/views/common/footer.php
DEBUG - 2011-10-01 03:43:56 --> File loaded: application/views/layout/main.php
DEBUG - 2011-10-01 03:43:56 --> Final output sent to browser
DEBUG - 2011-10-01 03:43:56 --> Total execution time: 0.0519
DEBUG - 2011-10-01 03:43:57 --> Config Class Initialized
DEBUG - 2011-10-01 03:43:57 --> Hooks Class Initialized
DEBUG - 2011-10-01 03:43:57 --> Utf8 Class Initialized
DEBUG - 2011-10-01 03:43:57 --> UTF-8 Support Enabled
DEBUG - 2011-10-01 03:43:57 --> URI Class Initialized
DEBUG - 2011-10-01 03:43:57 --> Router Class Initialized
ERROR - 2011-10-01 03:43:57 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-10-01 03:44:02 --> Config Class Initialized
DEBUG - 2011-10-01 03:44:02 --> Hooks Class Initialized
DEBUG - 2011-10-01 03:44:02 --> Utf8 Class Initialized
DEBUG - 2011-10-01 03:44:02 --> UTF-8 Support Enabled
DEBUG - 2011-10-01 03:44:02 --> URI Class Initialized
DEBUG - 2011-10-01 03:44:02 --> Router Class Initialized
DEBUG - 2011-10-01 03:44:02 --> Output Class Initialized
DEBUG - 2011-10-01 03:44:02 --> Input Class Initialized
DEBUG - 2011-10-01 03:44:02 --> Global POST and COOKIE data sanitized
DEBUG - 2011-10-01 03:44:02 --> Language Class Initialized
DEBUG - 2011-10-01 03:44:02 --> Loader Class Initialized
DEBUG - 2011-10-01 03:44:02 --> Controller Class Initialized
DEBUG - 2011-10-01 03:44:02 --> Model Class Initialized
DEBUG - 2011-10-01 03:44:02 --> Model Class Initialized
DEBUG - 2011-10-01 03:44:02 --> Model Class Initialized
DEBUG - 2011-10-01 03:44:02 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-10-01 03:44:02 --> Database Driver Class Initialized
DEBUG - 2011-10-01 03:44:02 --> File loaded: application/views/table/main.php
DEBUG - 2011-10-01 03:44:02 --> Helper loaded: url_helper
DEBUG - 2011-10-01 03:44:02 --> File loaded: application/views/common/header.php
DEBUG - 2011-10-01 03:44:02 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-10-01 03:44:02 --> File loaded: application/views/common/footer.php
DEBUG - 2011-10-01 03:44:02 --> File loaded: application/views/layout/main.php
DEBUG - 2011-10-01 03:44:02 --> Final output sent to browser
DEBUG - 2011-10-01 03:44:02 --> Total execution time: 0.1957
DEBUG - 2011-10-01 03:44:04 --> Config Class Initialized
DEBUG - 2011-10-01 03:44:04 --> Hooks Class Initialized
DEBUG - 2011-10-01 03:44:04 --> Utf8 Class Initialized
DEBUG - 2011-10-01 03:44:04 --> UTF-8 Support Enabled
DEBUG - 2011-10-01 03:44:04 --> URI Class Initialized
DEBUG - 2011-10-01 03:44:04 --> Router Class Initialized
ERROR - 2011-10-01 03:44:04 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-10-01 03:44:41 --> Config Class Initialized
DEBUG - 2011-10-01 03:44:41 --> Hooks Class Initialized
DEBUG - 2011-10-01 03:44:41 --> Utf8 Class Initialized
DEBUG - 2011-10-01 03:44:41 --> UTF-8 Support Enabled
DEBUG - 2011-10-01 03:44:41 --> URI Class Initialized
DEBUG - 2011-10-01 03:44:41 --> Router Class Initialized
DEBUG - 2011-10-01 03:44:41 --> Output Class Initialized
DEBUG - 2011-10-01 03:44:41 --> Input Class Initialized
DEBUG - 2011-10-01 03:44:41 --> Global POST and COOKIE data sanitized
DEBUG - 2011-10-01 03:44:41 --> Language Class Initialized
DEBUG - 2011-10-01 03:44:41 --> Loader Class Initialized
DEBUG - 2011-10-01 03:44:41 --> Controller Class Initialized
DEBUG - 2011-10-01 03:44:41 --> Model Class Initialized
DEBUG - 2011-10-01 03:44:41 --> Model Class Initialized
DEBUG - 2011-10-01 03:44:41 --> Model Class Initialized
DEBUG - 2011-10-01 03:44:41 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-10-01 03:44:41 --> Database Driver Class Initialized
DEBUG - 2011-10-01 03:44:41 --> File loaded: application/views/table/main.php
DEBUG - 2011-10-01 03:44:41 --> Helper loaded: url_helper
DEBUG - 2011-10-01 03:44:41 --> File loaded: application/views/common/header.php
DEBUG - 2011-10-01 03:44:41 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-10-01 03:44:41 --> File loaded: application/views/common/footer.php
DEBUG - 2011-10-01 03:44:41 --> File loaded: application/views/layout/main.php
DEBUG - 2011-10-01 03:44:41 --> Final output sent to browser
DEBUG - 2011-10-01 03:44:41 --> Total execution time: 0.2316
DEBUG - 2011-10-01 03:44:43 --> Config Class Initialized
DEBUG - 2011-10-01 03:44:43 --> Hooks Class Initialized
DEBUG - 2011-10-01 03:44:43 --> Utf8 Class Initialized
DEBUG - 2011-10-01 03:44:43 --> UTF-8 Support Enabled
DEBUG - 2011-10-01 03:44:43 --> URI Class Initialized
DEBUG - 2011-10-01 03:44:43 --> Router Class Initialized
ERROR - 2011-10-01 03:44:43 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-10-01 03:44:43 --> Config Class Initialized
DEBUG - 2011-10-01 03:44:43 --> Hooks Class Initialized
DEBUG - 2011-10-01 03:44:43 --> Utf8 Class Initialized
DEBUG - 2011-10-01 03:44:43 --> UTF-8 Support Enabled
DEBUG - 2011-10-01 03:44:43 --> URI Class Initialized
DEBUG - 2011-10-01 03:44:43 --> Router Class Initialized
ERROR - 2011-10-01 03:44:43 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-10-01 03:44:44 --> Config Class Initialized
DEBUG - 2011-10-01 03:44:44 --> Hooks Class Initialized
DEBUG - 2011-10-01 03:44:44 --> Utf8 Class Initialized
DEBUG - 2011-10-01 03:44:44 --> UTF-8 Support Enabled
DEBUG - 2011-10-01 03:44:44 --> URI Class Initialized
DEBUG - 2011-10-01 03:44:44 --> Router Class Initialized
DEBUG - 2011-10-01 03:44:44 --> Output Class Initialized
DEBUG - 2011-10-01 03:44:44 --> Input Class Initialized
DEBUG - 2011-10-01 03:44:44 --> Global POST and COOKIE data sanitized
DEBUG - 2011-10-01 03:44:44 --> Language Class Initialized
DEBUG - 2011-10-01 03:44:44 --> Loader Class Initialized
DEBUG - 2011-10-01 03:44:44 --> Controller Class Initialized
DEBUG - 2011-10-01 03:44:44 --> Model Class Initialized
DEBUG - 2011-10-01 03:44:44 --> Model Class Initialized
DEBUG - 2011-10-01 03:44:44 --> Model Class Initialized
DEBUG - 2011-10-01 03:44:44 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-10-01 03:44:44 --> Database Driver Class Initialized
DEBUG - 2011-10-01 03:44:44 --> File loaded: application/views/table/main.php
DEBUG - 2011-10-01 03:44:44 --> Helper loaded: url_helper
DEBUG - 2011-10-01 03:44:44 --> File loaded: application/views/common/header.php
DEBUG - 2011-10-01 03:44:44 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-10-01 03:44:44 --> File loaded: application/views/common/footer.php
DEBUG - 2011-10-01 03:44:44 --> File loaded: application/views/layout/main.php
DEBUG - 2011-10-01 03:44:44 --> Final output sent to browser
DEBUG - 2011-10-01 03:44:44 --> Total execution time: 0.0682
DEBUG - 2011-10-01 03:54:54 --> Config Class Initialized
DEBUG - 2011-10-01 03:54:54 --> Hooks Class Initialized
DEBUG - 2011-10-01 03:54:54 --> Utf8 Class Initialized
DEBUG - 2011-10-01 03:54:54 --> UTF-8 Support Enabled
DEBUG - 2011-10-01 03:54:54 --> URI Class Initialized
DEBUG - 2011-10-01 03:54:54 --> Router Class Initialized
ERROR - 2011-10-01 03:54:54 --> 404 Page Not Found --> robots.txt
DEBUG - 2011-10-01 03:54:54 --> Config Class Initialized
DEBUG - 2011-10-01 03:54:54 --> Hooks Class Initialized
DEBUG - 2011-10-01 03:54:54 --> Utf8 Class Initialized
DEBUG - 2011-10-01 03:54:54 --> UTF-8 Support Enabled
DEBUG - 2011-10-01 03:54:54 --> URI Class Initialized
DEBUG - 2011-10-01 03:54:54 --> Router Class Initialized
DEBUG - 2011-10-01 03:54:54 --> Output Class Initialized
DEBUG - 2011-10-01 03:54:54 --> Input Class Initialized
DEBUG - 2011-10-01 03:54:54 --> Global POST and COOKIE data sanitized
DEBUG - 2011-10-01 03:54:54 --> Language Class Initialized
DEBUG - 2011-10-01 03:54:54 --> Loader Class Initialized
DEBUG - 2011-10-01 03:54:54 --> Controller Class Initialized
DEBUG - 2011-10-01 03:54:54 --> Model Class Initialized
DEBUG - 2011-10-01 03:54:54 --> Model Class Initialized
DEBUG - 2011-10-01 03:54:54 --> Model Class Initialized
DEBUG - 2011-10-01 03:54:54 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-10-01 03:54:54 --> Database Driver Class Initialized
DEBUG - 2011-10-01 03:54:54 --> File loaded: application/views/table/main.php
DEBUG - 2011-10-01 03:54:54 --> Helper loaded: url_helper
DEBUG - 2011-10-01 03:54:54 --> File loaded: application/views/common/header.php
DEBUG - 2011-10-01 03:54:54 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-10-01 03:54:54 --> File loaded: application/views/common/footer.php
DEBUG - 2011-10-01 03:54:54 --> File loaded: application/views/layout/main.php
DEBUG - 2011-10-01 03:54:54 --> Final output sent to browser
DEBUG - 2011-10-01 03:54:54 --> Total execution time: 0.0762
DEBUG - 2011-10-01 04:40:09 --> Config Class Initialized
DEBUG - 2011-10-01 04:40:09 --> Hooks Class Initialized
DEBUG - 2011-10-01 04:40:09 --> Utf8 Class Initialized
DEBUG - 2011-10-01 04:40:09 --> UTF-8 Support Enabled
DEBUG - 2011-10-01 04:40:09 --> URI Class Initialized
DEBUG - 2011-10-01 04:40:09 --> Router Class Initialized
DEBUG - 2011-10-01 04:40:09 --> Output Class Initialized
DEBUG - 2011-10-01 04:40:09 --> Input Class Initialized
DEBUG - 2011-10-01 04:40:09 --> Global POST and COOKIE data sanitized
DEBUG - 2011-10-01 04:40:09 --> Language Class Initialized
DEBUG - 2011-10-01 04:40:09 --> Loader Class Initialized
DEBUG - 2011-10-01 04:40:09 --> Controller Class Initialized
DEBUG - 2011-10-01 04:40:09 --> Model Class Initialized
DEBUG - 2011-10-01 04:40:09 --> Model Class Initialized
DEBUG - 2011-10-01 04:40:09 --> Model Class Initialized
DEBUG - 2011-10-01 04:40:09 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-10-01 04:40:09 --> Database Driver Class Initialized
DEBUG - 2011-10-01 04:40:10 --> File loaded: application/views/table/main.php
DEBUG - 2011-10-01 04:40:10 --> Helper loaded: url_helper
DEBUG - 2011-10-01 04:40:10 --> File loaded: application/views/common/header.php
DEBUG - 2011-10-01 04:40:10 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-10-01 04:40:10 --> File loaded: application/views/common/footer.php
DEBUG - 2011-10-01 04:40:10 --> File loaded: application/views/layout/main.php
DEBUG - 2011-10-01 04:40:10 --> Final output sent to browser
DEBUG - 2011-10-01 04:40:10 --> Total execution time: 1.7810
DEBUG - 2011-10-01 04:40:14 --> Config Class Initialized
DEBUG - 2011-10-01 04:40:14 --> Hooks Class Initialized
DEBUG - 2011-10-01 04:40:14 --> Utf8 Class Initialized
DEBUG - 2011-10-01 04:40:14 --> UTF-8 Support Enabled
DEBUG - 2011-10-01 04:40:14 --> URI Class Initialized
DEBUG - 2011-10-01 04:40:14 --> Router Class Initialized
ERROR - 2011-10-01 04:40:14 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-10-01 04:40:15 --> Config Class Initialized
DEBUG - 2011-10-01 04:40:15 --> Hooks Class Initialized
DEBUG - 2011-10-01 04:40:15 --> Utf8 Class Initialized
DEBUG - 2011-10-01 04:40:15 --> UTF-8 Support Enabled
DEBUG - 2011-10-01 04:40:15 --> URI Class Initialized
DEBUG - 2011-10-01 04:40:15 --> Router Class Initialized
ERROR - 2011-10-01 04:40:15 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-10-01 04:40:30 --> Config Class Initialized
DEBUG - 2011-10-01 04:40:30 --> Hooks Class Initialized
DEBUG - 2011-10-01 04:40:30 --> Utf8 Class Initialized
DEBUG - 2011-10-01 04:40:30 --> UTF-8 Support Enabled
DEBUG - 2011-10-01 04:40:30 --> URI Class Initialized
DEBUG - 2011-10-01 04:40:30 --> Router Class Initialized
DEBUG - 2011-10-01 04:40:30 --> Output Class Initialized
DEBUG - 2011-10-01 04:40:30 --> Input Class Initialized
DEBUG - 2011-10-01 04:40:30 --> Global POST and COOKIE data sanitized
DEBUG - 2011-10-01 04:40:30 --> Language Class Initialized
DEBUG - 2011-10-01 04:40:30 --> Loader Class Initialized
DEBUG - 2011-10-01 04:40:30 --> Controller Class Initialized
ERROR - 2011-10-01 04:40:30 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-10-01 04:40:30 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-10-01 04:40:30 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-10-01 04:40:30 --> Model Class Initialized
DEBUG - 2011-10-01 04:40:30 --> Model Class Initialized
DEBUG - 2011-10-01 04:40:30 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-10-01 04:40:30 --> Database Driver Class Initialized
DEBUG - 2011-10-01 04:40:30 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-10-01 04:40:30 --> Helper loaded: url_helper
DEBUG - 2011-10-01 04:40:30 --> File loaded: application/views/common/header.php
DEBUG - 2011-10-01 04:40:30 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-10-01 04:40:30 --> File loaded: application/views/common/footer.php
DEBUG - 2011-10-01 04:40:30 --> File loaded: application/views/layout/main.php
DEBUG - 2011-10-01 04:40:30 --> Final output sent to browser
DEBUG - 2011-10-01 04:40:30 --> Total execution time: 0.1120
DEBUG - 2011-10-01 04:40:31 --> Config Class Initialized
DEBUG - 2011-10-01 04:40:31 --> Hooks Class Initialized
DEBUG - 2011-10-01 04:40:31 --> Utf8 Class Initialized
DEBUG - 2011-10-01 04:40:31 --> UTF-8 Support Enabled
DEBUG - 2011-10-01 04:40:31 --> URI Class Initialized
DEBUG - 2011-10-01 04:40:31 --> Router Class Initialized
DEBUG - 2011-10-01 04:40:31 --> Output Class Initialized
DEBUG - 2011-10-01 04:40:31 --> Input Class Initialized
DEBUG - 2011-10-01 04:40:31 --> Global POST and COOKIE data sanitized
DEBUG - 2011-10-01 04:40:31 --> Language Class Initialized
DEBUG - 2011-10-01 04:40:31 --> Loader Class Initialized
DEBUG - 2011-10-01 04:40:31 --> Controller Class Initialized
DEBUG - 2011-10-01 04:40:31 --> Model Class Initialized
DEBUG - 2011-10-01 04:40:31 --> Model Class Initialized
DEBUG - 2011-10-01 04:40:31 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-10-01 04:40:31 --> Database Driver Class Initialized
DEBUG - 2011-10-01 04:40:32 --> Final output sent to browser
DEBUG - 2011-10-01 04:40:32 --> Total execution time: 0.7380
DEBUG - 2011-10-01 04:45:15 --> Config Class Initialized
DEBUG - 2011-10-01 04:45:15 --> Hooks Class Initialized
DEBUG - 2011-10-01 04:45:15 --> Utf8 Class Initialized
DEBUG - 2011-10-01 04:45:15 --> UTF-8 Support Enabled
DEBUG - 2011-10-01 04:45:15 --> URI Class Initialized
DEBUG - 2011-10-01 04:45:15 --> Router Class Initialized
DEBUG - 2011-10-01 04:45:15 --> No URI present. Default controller set.
DEBUG - 2011-10-01 04:45:15 --> Output Class Initialized
DEBUG - 2011-10-01 04:45:15 --> Input Class Initialized
DEBUG - 2011-10-01 04:45:15 --> Global POST and COOKIE data sanitized
DEBUG - 2011-10-01 04:45:15 --> Language Class Initialized
DEBUG - 2011-10-01 04:45:15 --> Loader Class Initialized
DEBUG - 2011-10-01 04:45:15 --> Controller Class Initialized
DEBUG - 2011-10-01 04:45:16 --> File loaded: application/views/splash/main.php
DEBUG - 2011-10-01 04:45:16 --> Helper loaded: url_helper
DEBUG - 2011-10-01 04:45:16 --> File loaded: application/views/common/header.php
DEBUG - 2011-10-01 04:45:16 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-10-01 04:45:16 --> File loaded: application/views/common/footer.php
DEBUG - 2011-10-01 04:45:16 --> File loaded: application/views/layout/main.php
DEBUG - 2011-10-01 04:45:16 --> Final output sent to browser
DEBUG - 2011-10-01 04:45:16 --> Total execution time: 0.0472
DEBUG - 2011-10-01 04:46:38 --> Config Class Initialized
DEBUG - 2011-10-01 04:46:38 --> Hooks Class Initialized
DEBUG - 2011-10-01 04:46:38 --> Utf8 Class Initialized
DEBUG - 2011-10-01 04:46:38 --> UTF-8 Support Enabled
DEBUG - 2011-10-01 04:46:38 --> URI Class Initialized
DEBUG - 2011-10-01 04:46:38 --> Router Class Initialized
ERROR - 2011-10-01 04:46:38 --> 404 Page Not Found --> robots.txt
DEBUG - 2011-10-01 04:46:41 --> Config Class Initialized
DEBUG - 2011-10-01 04:46:41 --> Hooks Class Initialized
DEBUG - 2011-10-01 04:46:41 --> Utf8 Class Initialized
DEBUG - 2011-10-01 04:46:41 --> UTF-8 Support Enabled
DEBUG - 2011-10-01 04:46:41 --> URI Class Initialized
DEBUG - 2011-10-01 04:46:41 --> Router Class Initialized
DEBUG - 2011-10-01 04:46:41 --> Output Class Initialized
DEBUG - 2011-10-01 04:46:41 --> Input Class Initialized
DEBUG - 2011-10-01 04:46:41 --> Global POST and COOKIE data sanitized
DEBUG - 2011-10-01 04:46:41 --> Language Class Initialized
DEBUG - 2011-10-01 04:46:42 --> Loader Class Initialized
DEBUG - 2011-10-01 04:46:42 --> Controller Class Initialized
DEBUG - 2011-10-01 04:46:42 --> Model Class Initialized
DEBUG - 2011-10-01 04:46:42 --> Model Class Initialized
DEBUG - 2011-10-01 04:46:42 --> Model Class Initialized
DEBUG - 2011-10-01 04:46:42 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-10-01 04:46:42 --> Database Driver Class Initialized
DEBUG - 2011-10-01 04:46:42 --> File loaded: application/views/table/main.php
DEBUG - 2011-10-01 04:46:42 --> Helper loaded: url_helper
DEBUG - 2011-10-01 04:46:42 --> File loaded: application/views/common/header.php
DEBUG - 2011-10-01 04:46:42 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-10-01 04:46:42 --> File loaded: application/views/common/footer.php
DEBUG - 2011-10-01 04:46:42 --> File loaded: application/views/layout/main.php
DEBUG - 2011-10-01 04:46:42 --> Final output sent to browser
DEBUG - 2011-10-01 04:46:42 --> Total execution time: 0.2640
DEBUG - 2011-10-01 07:25:46 --> Config Class Initialized
DEBUG - 2011-10-01 07:25:46 --> Hooks Class Initialized
DEBUG - 2011-10-01 07:25:46 --> Utf8 Class Initialized
DEBUG - 2011-10-01 07:25:46 --> UTF-8 Support Enabled
DEBUG - 2011-10-01 07:25:46 --> URI Class Initialized
DEBUG - 2011-10-01 07:25:46 --> Router Class Initialized
DEBUG - 2011-10-01 07:25:46 --> No URI present. Default controller set.
DEBUG - 2011-10-01 07:25:46 --> Output Class Initialized
DEBUG - 2011-10-01 07:25:46 --> Input Class Initialized
DEBUG - 2011-10-01 07:25:46 --> Global POST and COOKIE data sanitized
DEBUG - 2011-10-01 07:25:46 --> Language Class Initialized
DEBUG - 2011-10-01 07:25:46 --> Loader Class Initialized
DEBUG - 2011-10-01 07:25:46 --> Controller Class Initialized
DEBUG - 2011-10-01 07:25:46 --> File loaded: application/views/splash/main.php
DEBUG - 2011-10-01 07:25:46 --> Helper loaded: url_helper
DEBUG - 2011-10-01 07:25:46 --> File loaded: application/views/common/header.php
DEBUG - 2011-10-01 07:25:46 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-10-01 07:25:46 --> File loaded: application/views/common/footer.php
DEBUG - 2011-10-01 07:25:46 --> File loaded: application/views/layout/main.php
DEBUG - 2011-10-01 07:25:46 --> Final output sent to browser
DEBUG - 2011-10-01 07:25:46 --> Total execution time: 0.3672
DEBUG - 2011-10-01 07:26:11 --> Config Class Initialized
DEBUG - 2011-10-01 07:26:11 --> Hooks Class Initialized
DEBUG - 2011-10-01 07:26:11 --> Utf8 Class Initialized
DEBUG - 2011-10-01 07:26:11 --> UTF-8 Support Enabled
DEBUG - 2011-10-01 07:26:11 --> URI Class Initialized
DEBUG - 2011-10-01 07:26:11 --> Router Class Initialized
ERROR - 2011-10-01 07:26:11 --> 404 Page Not Found --> robots.txt
DEBUG - 2011-10-01 07:26:12 --> Config Class Initialized
DEBUG - 2011-10-01 07:26:12 --> Hooks Class Initialized
DEBUG - 2011-10-01 07:26:12 --> Utf8 Class Initialized
DEBUG - 2011-10-01 07:26:12 --> UTF-8 Support Enabled
DEBUG - 2011-10-01 07:26:12 --> URI Class Initialized
DEBUG - 2011-10-01 07:26:12 --> Router Class Initialized
DEBUG - 2011-10-01 07:26:12 --> Output Class Initialized
DEBUG - 2011-10-01 07:26:12 --> Input Class Initialized
DEBUG - 2011-10-01 07:26:12 --> Global POST and COOKIE data sanitized
DEBUG - 2011-10-01 07:26:12 --> Language Class Initialized
DEBUG - 2011-10-01 07:26:12 --> Loader Class Initialized
DEBUG - 2011-10-01 07:26:12 --> Controller Class Initialized
ERROR - 2011-10-01 07:26:12 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-10-01 07:26:12 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-10-01 07:26:12 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-10-01 07:26:12 --> Model Class Initialized
DEBUG - 2011-10-01 07:26:12 --> Model Class Initialized
DEBUG - 2011-10-01 07:26:12 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-10-01 07:26:12 --> Database Driver Class Initialized
DEBUG - 2011-10-01 07:26:13 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-10-01 07:26:13 --> Helper loaded: url_helper
DEBUG - 2011-10-01 07:26:13 --> File loaded: application/views/common/header.php
DEBUG - 2011-10-01 07:26:13 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-10-01 07:26:13 --> File loaded: application/views/common/footer.php
DEBUG - 2011-10-01 07:26:13 --> File loaded: application/views/layout/main.php
DEBUG - 2011-10-01 07:26:13 --> Final output sent to browser
DEBUG - 2011-10-01 07:26:13 --> Total execution time: 0.7681
DEBUG - 2011-10-01 07:56:21 --> Config Class Initialized
DEBUG - 2011-10-01 07:56:21 --> Hooks Class Initialized
DEBUG - 2011-10-01 07:56:21 --> Utf8 Class Initialized
DEBUG - 2011-10-01 07:56:21 --> UTF-8 Support Enabled
DEBUG - 2011-10-01 07:56:21 --> URI Class Initialized
DEBUG - 2011-10-01 07:56:21 --> Router Class Initialized
DEBUG - 2011-10-01 07:56:21 --> Output Class Initialized
DEBUG - 2011-10-01 07:56:21 --> Input Class Initialized
DEBUG - 2011-10-01 07:56:21 --> Global POST and COOKIE data sanitized
DEBUG - 2011-10-01 07:56:21 --> Language Class Initialized
DEBUG - 2011-10-01 07:56:21 --> Loader Class Initialized
DEBUG - 2011-10-01 07:56:21 --> Controller Class Initialized
ERROR - 2011-10-01 07:56:21 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-10-01 07:56:21 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-10-01 07:56:21 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-10-01 07:56:21 --> Model Class Initialized
DEBUG - 2011-10-01 07:56:21 --> Model Class Initialized
DEBUG - 2011-10-01 07:56:21 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-10-01 07:56:21 --> Database Driver Class Initialized
DEBUG - 2011-10-01 07:56:22 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-10-01 07:56:22 --> Helper loaded: url_helper
DEBUG - 2011-10-01 07:56:22 --> File loaded: application/views/common/header.php
DEBUG - 2011-10-01 07:56:22 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-10-01 07:56:22 --> File loaded: application/views/common/footer.php
DEBUG - 2011-10-01 07:56:22 --> File loaded: application/views/layout/main.php
DEBUG - 2011-10-01 07:56:22 --> Final output sent to browser
DEBUG - 2011-10-01 07:56:22 --> Total execution time: 1.0597
DEBUG - 2011-10-01 07:56:24 --> Config Class Initialized
DEBUG - 2011-10-01 07:56:24 --> Hooks Class Initialized
DEBUG - 2011-10-01 07:56:24 --> Utf8 Class Initialized
DEBUG - 2011-10-01 07:56:24 --> UTF-8 Support Enabled
DEBUG - 2011-10-01 07:56:24 --> URI Class Initialized
DEBUG - 2011-10-01 07:56:24 --> Router Class Initialized
DEBUG - 2011-10-01 07:56:24 --> Output Class Initialized
DEBUG - 2011-10-01 07:56:24 --> Input Class Initialized
DEBUG - 2011-10-01 07:56:24 --> Global POST and COOKIE data sanitized
DEBUG - 2011-10-01 07:56:24 --> Language Class Initialized
DEBUG - 2011-10-01 07:56:24 --> Loader Class Initialized
DEBUG - 2011-10-01 07:56:24 --> Controller Class Initialized
DEBUG - 2011-10-01 07:56:24 --> Model Class Initialized
DEBUG - 2011-10-01 07:56:24 --> Model Class Initialized
DEBUG - 2011-10-01 07:56:24 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-10-01 07:56:24 --> Database Driver Class Initialized
DEBUG - 2011-10-01 07:56:24 --> Final output sent to browser
DEBUG - 2011-10-01 07:56:24 --> Total execution time: 0.8449
DEBUG - 2011-10-01 07:56:26 --> Config Class Initialized
DEBUG - 2011-10-01 07:56:26 --> Hooks Class Initialized
DEBUG - 2011-10-01 07:56:26 --> Utf8 Class Initialized
DEBUG - 2011-10-01 07:56:26 --> UTF-8 Support Enabled
DEBUG - 2011-10-01 07:56:26 --> URI Class Initialized
DEBUG - 2011-10-01 07:56:26 --> Router Class Initialized
ERROR - 2011-10-01 07:56:26 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-10-01 09:13:25 --> Config Class Initialized
DEBUG - 2011-10-01 09:13:25 --> Hooks Class Initialized
DEBUG - 2011-10-01 09:13:25 --> Utf8 Class Initialized
DEBUG - 2011-10-01 09:13:25 --> UTF-8 Support Enabled
DEBUG - 2011-10-01 09:13:25 --> URI Class Initialized
DEBUG - 2011-10-01 09:13:25 --> Router Class Initialized
DEBUG - 2011-10-01 09:13:25 --> Output Class Initialized
DEBUG - 2011-10-01 09:13:25 --> Input Class Initialized
DEBUG - 2011-10-01 09:13:25 --> Global POST and COOKIE data sanitized
DEBUG - 2011-10-01 09:13:25 --> Language Class Initialized
DEBUG - 2011-10-01 09:13:25 --> Loader Class Initialized
DEBUG - 2011-10-01 09:13:25 --> Controller Class Initialized
DEBUG - 2011-10-01 09:13:25 --> Model Class Initialized
DEBUG - 2011-10-01 09:13:25 --> Model Class Initialized
DEBUG - 2011-10-01 09:13:25 --> Model Class Initialized
DEBUG - 2011-10-01 09:13:25 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-10-01 09:13:25 --> Database Driver Class Initialized
DEBUG - 2011-10-01 09:13:27 --> File loaded: application/views/table/main.php
DEBUG - 2011-10-01 09:13:27 --> Helper loaded: url_helper
DEBUG - 2011-10-01 09:13:27 --> File loaded: application/views/common/header.php
DEBUG - 2011-10-01 09:13:27 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-10-01 09:13:27 --> File loaded: application/views/common/footer.php
DEBUG - 2011-10-01 09:13:27 --> File loaded: application/views/layout/main.php
DEBUG - 2011-10-01 09:13:27 --> Final output sent to browser
DEBUG - 2011-10-01 09:13:27 --> Total execution time: 1.7998
DEBUG - 2011-10-01 10:25:31 --> Config Class Initialized
DEBUG - 2011-10-01 10:25:31 --> Hooks Class Initialized
DEBUG - 2011-10-01 10:25:31 --> Utf8 Class Initialized
DEBUG - 2011-10-01 10:25:31 --> UTF-8 Support Enabled
DEBUG - 2011-10-01 10:25:31 --> URI Class Initialized
DEBUG - 2011-10-01 10:25:31 --> Router Class Initialized
DEBUG - 2011-10-01 10:25:31 --> Output Class Initialized
DEBUG - 2011-10-01 10:25:31 --> Input Class Initialized
DEBUG - 2011-10-01 10:25:31 --> Global POST and COOKIE data sanitized
DEBUG - 2011-10-01 10:25:31 --> Language Class Initialized
DEBUG - 2011-10-01 10:25:31 --> Loader Class Initialized
DEBUG - 2011-10-01 10:25:31 --> Controller Class Initialized
ERROR - 2011-10-01 10:25:31 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-10-01 10:25:31 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-10-01 10:25:31 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-10-01 10:25:31 --> Model Class Initialized
DEBUG - 2011-10-01 10:25:31 --> Model Class Initialized
DEBUG - 2011-10-01 10:25:31 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-10-01 10:25:31 --> Database Driver Class Initialized
DEBUG - 2011-10-01 10:25:32 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-10-01 10:25:32 --> Helper loaded: url_helper
DEBUG - 2011-10-01 10:25:32 --> File loaded: application/views/common/header.php
DEBUG - 2011-10-01 10:25:32 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-10-01 10:25:32 --> File loaded: application/views/common/footer.php
DEBUG - 2011-10-01 10:25:32 --> File loaded: application/views/layout/main.php
DEBUG - 2011-10-01 10:25:32 --> Final output sent to browser
DEBUG - 2011-10-01 10:25:32 --> Total execution time: 0.8078
DEBUG - 2011-10-01 11:58:32 --> Config Class Initialized
DEBUG - 2011-10-01 11:58:32 --> Hooks Class Initialized
DEBUG - 2011-10-01 11:58:32 --> Utf8 Class Initialized
DEBUG - 2011-10-01 11:58:32 --> UTF-8 Support Enabled
DEBUG - 2011-10-01 11:58:32 --> URI Class Initialized
DEBUG - 2011-10-01 11:58:32 --> Router Class Initialized
DEBUG - 2011-10-01 11:58:32 --> No URI present. Default controller set.
DEBUG - 2011-10-01 11:58:32 --> Output Class Initialized
DEBUG - 2011-10-01 11:58:32 --> Input Class Initialized
DEBUG - 2011-10-01 11:58:32 --> Global POST and COOKIE data sanitized
DEBUG - 2011-10-01 11:58:32 --> Language Class Initialized
DEBUG - 2011-10-01 11:58:32 --> Loader Class Initialized
DEBUG - 2011-10-01 11:58:32 --> Controller Class Initialized
DEBUG - 2011-10-01 11:58:32 --> File loaded: application/views/splash/main.php
DEBUG - 2011-10-01 11:58:32 --> Helper loaded: url_helper
DEBUG - 2011-10-01 11:58:32 --> File loaded: application/views/common/header.php
DEBUG - 2011-10-01 11:58:32 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-10-01 11:58:32 --> File loaded: application/views/common/footer.php
DEBUG - 2011-10-01 11:58:32 --> File loaded: application/views/layout/main.php
DEBUG - 2011-10-01 11:58:32 --> Final output sent to browser
DEBUG - 2011-10-01 11:58:32 --> Total execution time: 0.2883
DEBUG - 2011-10-01 12:32:32 --> Config Class Initialized
DEBUG - 2011-10-01 12:32:33 --> Hooks Class Initialized
DEBUG - 2011-10-01 12:32:33 --> Utf8 Class Initialized
DEBUG - 2011-10-01 12:32:33 --> UTF-8 Support Enabled
DEBUG - 2011-10-01 12:32:33 --> URI Class Initialized
DEBUG - 2011-10-01 12:32:33 --> Router Class Initialized
DEBUG - 2011-10-01 12:32:33 --> Output Class Initialized
DEBUG - 2011-10-01 12:32:33 --> Input Class Initialized
DEBUG - 2011-10-01 12:32:33 --> Global POST and COOKIE data sanitized
DEBUG - 2011-10-01 12:32:33 --> Language Class Initialized
DEBUG - 2011-10-01 12:32:33 --> Loader Class Initialized
DEBUG - 2011-10-01 12:32:33 --> Controller Class Initialized
ERROR - 2011-10-01 12:32:33 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-10-01 12:32:33 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-10-01 12:32:33 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-10-01 12:32:33 --> Model Class Initialized
DEBUG - 2011-10-01 12:32:33 --> Model Class Initialized
DEBUG - 2011-10-01 12:32:33 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-10-01 12:32:33 --> Database Driver Class Initialized
DEBUG - 2011-10-01 12:32:33 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-10-01 12:32:33 --> Helper loaded: url_helper
DEBUG - 2011-10-01 12:32:33 --> File loaded: application/views/common/header.php
DEBUG - 2011-10-01 12:32:33 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-10-01 12:32:33 --> File loaded: application/views/common/footer.php
DEBUG - 2011-10-01 12:32:33 --> File loaded: application/views/layout/main.php
DEBUG - 2011-10-01 12:32:33 --> Final output sent to browser
DEBUG - 2011-10-01 12:32:33 --> Total execution time: 0.8967
DEBUG - 2011-10-01 12:32:36 --> Config Class Initialized
DEBUG - 2011-10-01 12:32:36 --> Hooks Class Initialized
DEBUG - 2011-10-01 12:32:36 --> Utf8 Class Initialized
DEBUG - 2011-10-01 12:32:36 --> UTF-8 Support Enabled
DEBUG - 2011-10-01 12:32:36 --> URI Class Initialized
DEBUG - 2011-10-01 12:32:36 --> Router Class Initialized
DEBUG - 2011-10-01 12:32:36 --> Output Class Initialized
DEBUG - 2011-10-01 12:32:36 --> Input Class Initialized
DEBUG - 2011-10-01 12:32:36 --> Global POST and COOKIE data sanitized
DEBUG - 2011-10-01 12:32:36 --> Language Class Initialized
DEBUG - 2011-10-01 12:32:36 --> Loader Class Initialized
DEBUG - 2011-10-01 12:32:36 --> Controller Class Initialized
DEBUG - 2011-10-01 12:32:36 --> Model Class Initialized
DEBUG - 2011-10-01 12:32:36 --> Model Class Initialized
DEBUG - 2011-10-01 12:32:36 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-10-01 12:32:36 --> Database Driver Class Initialized
DEBUG - 2011-10-01 12:32:37 --> Final output sent to browser
DEBUG - 2011-10-01 12:32:37 --> Total execution time: 0.7152
DEBUG - 2011-10-01 12:32:40 --> Config Class Initialized
DEBUG - 2011-10-01 12:32:40 --> Hooks Class Initialized
DEBUG - 2011-10-01 12:32:40 --> Utf8 Class Initialized
DEBUG - 2011-10-01 12:32:40 --> UTF-8 Support Enabled
DEBUG - 2011-10-01 12:32:40 --> URI Class Initialized
DEBUG - 2011-10-01 12:32:40 --> Router Class Initialized
ERROR - 2011-10-01 12:32:40 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-10-01 12:52:15 --> Config Class Initialized
DEBUG - 2011-10-01 12:52:15 --> Hooks Class Initialized
DEBUG - 2011-10-01 12:52:15 --> Utf8 Class Initialized
DEBUG - 2011-10-01 12:52:15 --> UTF-8 Support Enabled
DEBUG - 2011-10-01 12:52:15 --> URI Class Initialized
DEBUG - 2011-10-01 12:52:15 --> Router Class Initialized
ERROR - 2011-10-01 12:52:15 --> 404 Page Not Found --> robots.txt
DEBUG - 2011-10-01 14:56:14 --> Config Class Initialized
DEBUG - 2011-10-01 14:56:14 --> Hooks Class Initialized
DEBUG - 2011-10-01 14:56:14 --> Utf8 Class Initialized
DEBUG - 2011-10-01 14:56:14 --> UTF-8 Support Enabled
DEBUG - 2011-10-01 14:56:14 --> URI Class Initialized
DEBUG - 2011-10-01 14:56:14 --> Router Class Initialized
DEBUG - 2011-10-01 14:56:14 --> Output Class Initialized
DEBUG - 2011-10-01 14:56:14 --> Input Class Initialized
DEBUG - 2011-10-01 14:56:14 --> Global POST and COOKIE data sanitized
DEBUG - 2011-10-01 14:56:14 --> Language Class Initialized
DEBUG - 2011-10-01 14:56:14 --> Loader Class Initialized
DEBUG - 2011-10-01 14:56:14 --> Controller Class Initialized
DEBUG - 2011-10-01 14:56:14 --> Model Class Initialized
DEBUG - 2011-10-01 14:56:14 --> Model Class Initialized
DEBUG - 2011-10-01 14:56:14 --> Model Class Initialized
DEBUG - 2011-10-01 14:56:14 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-10-01 14:56:14 --> Database Driver Class Initialized
DEBUG - 2011-10-01 14:56:15 --> File loaded: application/views/table/main.php
DEBUG - 2011-10-01 14:56:15 --> Helper loaded: url_helper
DEBUG - 2011-10-01 14:56:15 --> File loaded: application/views/common/header.php
DEBUG - 2011-10-01 14:56:15 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-10-01 14:56:15 --> File loaded: application/views/common/footer.php
DEBUG - 2011-10-01 14:56:15 --> File loaded: application/views/layout/main.php
DEBUG - 2011-10-01 14:56:15 --> Final output sent to browser
DEBUG - 2011-10-01 14:56:15 --> Total execution time: 1.2345
DEBUG - 2011-10-01 14:56:18 --> Config Class Initialized
DEBUG - 2011-10-01 14:56:18 --> Hooks Class Initialized
DEBUG - 2011-10-01 14:56:18 --> Utf8 Class Initialized
DEBUG - 2011-10-01 14:56:18 --> UTF-8 Support Enabled
DEBUG - 2011-10-01 14:56:18 --> URI Class Initialized
DEBUG - 2011-10-01 14:56:18 --> Router Class Initialized
ERROR - 2011-10-01 14:56:18 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-10-01 14:56:18 --> Config Class Initialized
DEBUG - 2011-10-01 14:56:18 --> Hooks Class Initialized
DEBUG - 2011-10-01 14:56:18 --> Utf8 Class Initialized
DEBUG - 2011-10-01 14:56:18 --> UTF-8 Support Enabled
DEBUG - 2011-10-01 14:56:18 --> URI Class Initialized
DEBUG - 2011-10-01 14:56:18 --> Router Class Initialized
ERROR - 2011-10-01 14:56:18 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-10-01 14:57:23 --> Config Class Initialized
DEBUG - 2011-10-01 14:57:23 --> Hooks Class Initialized
DEBUG - 2011-10-01 14:57:23 --> Utf8 Class Initialized
DEBUG - 2011-10-01 14:57:23 --> UTF-8 Support Enabled
DEBUG - 2011-10-01 14:57:23 --> URI Class Initialized
DEBUG - 2011-10-01 14:57:23 --> Router Class Initialized
DEBUG - 2011-10-01 14:57:23 --> Output Class Initialized
DEBUG - 2011-10-01 14:57:23 --> Input Class Initialized
DEBUG - 2011-10-01 14:57:23 --> Global POST and COOKIE data sanitized
DEBUG - 2011-10-01 14:57:23 --> Language Class Initialized
DEBUG - 2011-10-01 14:57:23 --> Loader Class Initialized
DEBUG - 2011-10-01 14:57:23 --> Controller Class Initialized
DEBUG - 2011-10-01 14:57:23 --> Model Class Initialized
DEBUG - 2011-10-01 14:57:23 --> Model Class Initialized
DEBUG - 2011-10-01 14:57:23 --> Model Class Initialized
DEBUG - 2011-10-01 14:57:23 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-10-01 14:57:23 --> Database Driver Class Initialized
DEBUG - 2011-10-01 14:57:24 --> File loaded: application/views/table/main.php
DEBUG - 2011-10-01 14:57:24 --> Helper loaded: url_helper
DEBUG - 2011-10-01 14:57:24 --> File loaded: application/views/common/header.php
DEBUG - 2011-10-01 14:57:24 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-10-01 14:57:24 --> File loaded: application/views/common/footer.php
DEBUG - 2011-10-01 14:57:24 --> File loaded: application/views/layout/main.php
DEBUG - 2011-10-01 14:57:24 --> Final output sent to browser
DEBUG - 2011-10-01 14:57:24 --> Total execution time: 0.4475
DEBUG - 2011-10-01 14:57:42 --> Config Class Initialized
DEBUG - 2011-10-01 14:57:42 --> Hooks Class Initialized
DEBUG - 2011-10-01 14:57:42 --> Utf8 Class Initialized
DEBUG - 2011-10-01 14:57:42 --> UTF-8 Support Enabled
DEBUG - 2011-10-01 14:57:42 --> URI Class Initialized
DEBUG - 2011-10-01 14:57:42 --> Router Class Initialized
DEBUG - 2011-10-01 14:57:42 --> Output Class Initialized
DEBUG - 2011-10-01 14:57:42 --> Input Class Initialized
DEBUG - 2011-10-01 14:57:42 --> Global POST and COOKIE data sanitized
DEBUG - 2011-10-01 14:57:42 --> Language Class Initialized
DEBUG - 2011-10-01 14:57:42 --> Loader Class Initialized
DEBUG - 2011-10-01 14:57:42 --> Controller Class Initialized
DEBUG - 2011-10-01 14:57:42 --> Model Class Initialized
DEBUG - 2011-10-01 14:57:42 --> Model Class Initialized
DEBUG - 2011-10-01 14:57:42 --> Model Class Initialized
DEBUG - 2011-10-01 14:57:42 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-10-01 14:57:42 --> Database Driver Class Initialized
DEBUG - 2011-10-01 14:57:42 --> File loaded: application/views/table/main.php
DEBUG - 2011-10-01 14:57:42 --> Helper loaded: url_helper
DEBUG - 2011-10-01 14:57:42 --> File loaded: application/views/common/header.php
DEBUG - 2011-10-01 14:57:42 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-10-01 14:57:42 --> File loaded: application/views/common/footer.php
DEBUG - 2011-10-01 14:57:42 --> File loaded: application/views/layout/main.php
DEBUG - 2011-10-01 14:57:42 --> Final output sent to browser
DEBUG - 2011-10-01 14:57:42 --> Total execution time: 0.5698
DEBUG - 2011-10-01 14:57:59 --> Config Class Initialized
DEBUG - 2011-10-01 14:57:59 --> Hooks Class Initialized
DEBUG - 2011-10-01 14:57:59 --> Utf8 Class Initialized
DEBUG - 2011-10-01 14:57:59 --> UTF-8 Support Enabled
DEBUG - 2011-10-01 14:57:59 --> URI Class Initialized
DEBUG - 2011-10-01 14:57:59 --> Router Class Initialized
DEBUG - 2011-10-01 14:57:59 --> Output Class Initialized
DEBUG - 2011-10-01 14:57:59 --> Input Class Initialized
DEBUG - 2011-10-01 14:57:59 --> Global POST and COOKIE data sanitized
DEBUG - 2011-10-01 14:57:59 --> Language Class Initialized
DEBUG - 2011-10-01 14:57:59 --> Loader Class Initialized
DEBUG - 2011-10-01 14:57:59 --> Controller Class Initialized
DEBUG - 2011-10-01 14:57:59 --> Model Class Initialized
DEBUG - 2011-10-01 14:57:59 --> Model Class Initialized
DEBUG - 2011-10-01 14:57:59 --> Model Class Initialized
DEBUG - 2011-10-01 14:57:59 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-10-01 14:57:59 --> Database Driver Class Initialized
DEBUG - 2011-10-01 14:58:00 --> File loaded: application/views/table/main.php
DEBUG - 2011-10-01 14:58:00 --> Helper loaded: url_helper
DEBUG - 2011-10-01 14:58:00 --> File loaded: application/views/common/header.php
DEBUG - 2011-10-01 14:58:00 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-10-01 14:58:00 --> File loaded: application/views/common/footer.php
DEBUG - 2011-10-01 14:58:00 --> File loaded: application/views/layout/main.php
DEBUG - 2011-10-01 14:58:00 --> Final output sent to browser
DEBUG - 2011-10-01 14:58:00 --> Total execution time: 0.3325
DEBUG - 2011-10-01 14:58:19 --> Config Class Initialized
DEBUG - 2011-10-01 14:58:19 --> Hooks Class Initialized
DEBUG - 2011-10-01 14:58:19 --> Utf8 Class Initialized
DEBUG - 2011-10-01 14:58:19 --> UTF-8 Support Enabled
DEBUG - 2011-10-01 14:58:19 --> URI Class Initialized
DEBUG - 2011-10-01 14:58:19 --> Router Class Initialized
DEBUG - 2011-10-01 14:58:19 --> Output Class Initialized
DEBUG - 2011-10-01 14:58:19 --> Input Class Initialized
DEBUG - 2011-10-01 14:58:19 --> Global POST and COOKIE data sanitized
DEBUG - 2011-10-01 14:58:19 --> Language Class Initialized
DEBUG - 2011-10-01 14:58:19 --> Loader Class Initialized
DEBUG - 2011-10-01 14:58:19 --> Controller Class Initialized
DEBUG - 2011-10-01 14:58:19 --> Model Class Initialized
DEBUG - 2011-10-01 14:58:19 --> Model Class Initialized
DEBUG - 2011-10-01 14:58:19 --> Model Class Initialized
DEBUG - 2011-10-01 14:58:19 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-10-01 14:58:19 --> Database Driver Class Initialized
DEBUG - 2011-10-01 14:58:19 --> File loaded: application/views/table/main.php
DEBUG - 2011-10-01 14:58:19 --> Helper loaded: url_helper
DEBUG - 2011-10-01 14:58:19 --> File loaded: application/views/common/header.php
DEBUG - 2011-10-01 14:58:19 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-10-01 14:58:19 --> File loaded: application/views/common/footer.php
DEBUG - 2011-10-01 14:58:19 --> File loaded: application/views/layout/main.php
DEBUG - 2011-10-01 14:58:19 --> Final output sent to browser
DEBUG - 2011-10-01 14:58:19 --> Total execution time: 0.4194
DEBUG - 2011-10-01 14:58:28 --> Config Class Initialized
DEBUG - 2011-10-01 14:58:28 --> Hooks Class Initialized
DEBUG - 2011-10-01 14:58:28 --> Utf8 Class Initialized
DEBUG - 2011-10-01 14:58:28 --> UTF-8 Support Enabled
DEBUG - 2011-10-01 14:58:28 --> URI Class Initialized
DEBUG - 2011-10-01 14:58:28 --> Router Class Initialized
DEBUG - 2011-10-01 14:58:28 --> Output Class Initialized
DEBUG - 2011-10-01 14:58:28 --> Input Class Initialized
DEBUG - 2011-10-01 14:58:28 --> Global POST and COOKIE data sanitized
DEBUG - 2011-10-01 14:58:28 --> Language Class Initialized
DEBUG - 2011-10-01 14:58:28 --> Loader Class Initialized
DEBUG - 2011-10-01 14:58:28 --> Controller Class Initialized
DEBUG - 2011-10-01 14:58:28 --> Model Class Initialized
DEBUG - 2011-10-01 14:58:28 --> Model Class Initialized
DEBUG - 2011-10-01 14:58:28 --> Model Class Initialized
DEBUG - 2011-10-01 14:58:28 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-10-01 14:58:28 --> Database Driver Class Initialized
DEBUG - 2011-10-01 14:58:28 --> File loaded: application/views/table/main.php
DEBUG - 2011-10-01 14:58:28 --> Helper loaded: url_helper
DEBUG - 2011-10-01 14:58:28 --> File loaded: application/views/common/header.php
DEBUG - 2011-10-01 14:58:28 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-10-01 14:58:28 --> File loaded: application/views/common/footer.php
DEBUG - 2011-10-01 14:58:28 --> File loaded: application/views/layout/main.php
DEBUG - 2011-10-01 14:58:28 --> Final output sent to browser
DEBUG - 2011-10-01 14:58:28 --> Total execution time: 0.1971
DEBUG - 2011-10-01 14:58:40 --> Config Class Initialized
DEBUG - 2011-10-01 14:58:40 --> Hooks Class Initialized
DEBUG - 2011-10-01 14:58:40 --> Utf8 Class Initialized
DEBUG - 2011-10-01 14:58:40 --> UTF-8 Support Enabled
DEBUG - 2011-10-01 14:58:40 --> URI Class Initialized
DEBUG - 2011-10-01 14:58:40 --> Router Class Initialized
DEBUG - 2011-10-01 14:58:40 --> Output Class Initialized
DEBUG - 2011-10-01 14:58:40 --> Input Class Initialized
DEBUG - 2011-10-01 14:58:40 --> Global POST and COOKIE data sanitized
DEBUG - 2011-10-01 14:58:40 --> Language Class Initialized
DEBUG - 2011-10-01 14:58:40 --> Loader Class Initialized
DEBUG - 2011-10-01 14:58:40 --> Controller Class Initialized
DEBUG - 2011-10-01 14:58:40 --> Model Class Initialized
DEBUG - 2011-10-01 14:58:40 --> Model Class Initialized
DEBUG - 2011-10-01 14:58:40 --> Model Class Initialized
DEBUG - 2011-10-01 14:58:40 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-10-01 14:58:40 --> Database Driver Class Initialized
DEBUG - 2011-10-01 14:58:41 --> File loaded: application/views/table/main.php
DEBUG - 2011-10-01 14:58:41 --> Helper loaded: url_helper
DEBUG - 2011-10-01 14:58:41 --> File loaded: application/views/common/header.php
DEBUG - 2011-10-01 14:58:41 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-10-01 14:58:41 --> File loaded: application/views/common/footer.php
DEBUG - 2011-10-01 14:58:41 --> File loaded: application/views/layout/main.php
DEBUG - 2011-10-01 14:58:41 --> Final output sent to browser
DEBUG - 2011-10-01 14:58:41 --> Total execution time: 0.7795
DEBUG - 2011-10-01 14:58:57 --> Config Class Initialized
DEBUG - 2011-10-01 14:58:57 --> Hooks Class Initialized
DEBUG - 2011-10-01 14:58:57 --> Utf8 Class Initialized
DEBUG - 2011-10-01 14:58:57 --> UTF-8 Support Enabled
DEBUG - 2011-10-01 14:58:57 --> URI Class Initialized
DEBUG - 2011-10-01 14:58:57 --> Router Class Initialized
DEBUG - 2011-10-01 14:58:57 --> Output Class Initialized
DEBUG - 2011-10-01 14:58:57 --> Input Class Initialized
DEBUG - 2011-10-01 14:58:57 --> Global POST and COOKIE data sanitized
DEBUG - 2011-10-01 14:58:57 --> Language Class Initialized
DEBUG - 2011-10-01 14:58:57 --> Loader Class Initialized
DEBUG - 2011-10-01 14:58:57 --> Controller Class Initialized
DEBUG - 2011-10-01 14:58:57 --> Model Class Initialized
DEBUG - 2011-10-01 14:58:57 --> Model Class Initialized
DEBUG - 2011-10-01 14:58:57 --> Model Class Initialized
DEBUG - 2011-10-01 14:58:57 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-10-01 14:58:57 --> Database Driver Class Initialized
DEBUG - 2011-10-01 14:58:57 --> File loaded: application/views/table/main.php
DEBUG - 2011-10-01 14:58:57 --> Helper loaded: url_helper
DEBUG - 2011-10-01 14:58:57 --> File loaded: application/views/common/header.php
DEBUG - 2011-10-01 14:58:57 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-10-01 14:58:57 --> File loaded: application/views/common/footer.php
DEBUG - 2011-10-01 14:58:57 --> File loaded: application/views/layout/main.php
DEBUG - 2011-10-01 14:58:57 --> Final output sent to browser
DEBUG - 2011-10-01 14:58:57 --> Total execution time: 0.2452
DEBUG - 2011-10-01 15:00:16 --> Config Class Initialized
DEBUG - 2011-10-01 15:00:16 --> Hooks Class Initialized
DEBUG - 2011-10-01 15:00:16 --> Utf8 Class Initialized
DEBUG - 2011-10-01 15:00:16 --> UTF-8 Support Enabled
DEBUG - 2011-10-01 15:00:16 --> URI Class Initialized
DEBUG - 2011-10-01 15:00:16 --> Router Class Initialized
DEBUG - 2011-10-01 15:00:16 --> Output Class Initialized
DEBUG - 2011-10-01 15:00:16 --> Input Class Initialized
DEBUG - 2011-10-01 15:00:16 --> Global POST and COOKIE data sanitized
DEBUG - 2011-10-01 15:00:16 --> Language Class Initialized
DEBUG - 2011-10-01 15:00:16 --> Loader Class Initialized
DEBUG - 2011-10-01 15:00:16 --> Controller Class Initialized
DEBUG - 2011-10-01 15:00:16 --> Model Class Initialized
DEBUG - 2011-10-01 15:00:16 --> Model Class Initialized
DEBUG - 2011-10-01 15:00:16 --> Model Class Initialized
DEBUG - 2011-10-01 15:00:16 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-10-01 15:00:16 --> Database Driver Class Initialized
DEBUG - 2011-10-01 15:00:16 --> File loaded: application/views/table/main.php
DEBUG - 2011-10-01 15:00:16 --> Helper loaded: url_helper
DEBUG - 2011-10-01 15:00:16 --> File loaded: application/views/common/header.php
DEBUG - 2011-10-01 15:00:16 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-10-01 15:00:16 --> File loaded: application/views/common/footer.php
DEBUG - 2011-10-01 15:00:16 --> File loaded: application/views/layout/main.php
DEBUG - 2011-10-01 15:00:16 --> Final output sent to browser
DEBUG - 2011-10-01 15:00:16 --> Total execution time: 0.2811
DEBUG - 2011-10-01 15:00:33 --> Config Class Initialized
DEBUG - 2011-10-01 15:00:33 --> Hooks Class Initialized
DEBUG - 2011-10-01 15:00:33 --> Utf8 Class Initialized
DEBUG - 2011-10-01 15:00:33 --> UTF-8 Support Enabled
DEBUG - 2011-10-01 15:00:33 --> URI Class Initialized
DEBUG - 2011-10-01 15:00:33 --> Router Class Initialized
DEBUG - 2011-10-01 15:00:33 --> Output Class Initialized
DEBUG - 2011-10-01 15:00:33 --> Input Class Initialized
DEBUG - 2011-10-01 15:00:33 --> Global POST and COOKIE data sanitized
DEBUG - 2011-10-01 15:00:33 --> Language Class Initialized
DEBUG - 2011-10-01 15:00:33 --> Loader Class Initialized
DEBUG - 2011-10-01 15:00:33 --> Controller Class Initialized
DEBUG - 2011-10-01 15:00:33 --> Model Class Initialized
DEBUG - 2011-10-01 15:00:33 --> Model Class Initialized
DEBUG - 2011-10-01 15:00:33 --> Model Class Initialized
DEBUG - 2011-10-01 15:00:33 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-10-01 15:00:33 --> Database Driver Class Initialized
DEBUG - 2011-10-01 15:00:34 --> File loaded: application/views/table/main.php
DEBUG - 2011-10-01 15:00:34 --> Helper loaded: url_helper
DEBUG - 2011-10-01 15:00:34 --> File loaded: application/views/common/header.php
DEBUG - 2011-10-01 15:00:34 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-10-01 15:00:34 --> File loaded: application/views/common/footer.php
DEBUG - 2011-10-01 15:00:34 --> File loaded: application/views/layout/main.php
DEBUG - 2011-10-01 15:00:34 --> Final output sent to browser
DEBUG - 2011-10-01 15:00:34 --> Total execution time: 0.6113
DEBUG - 2011-10-01 15:00:55 --> Config Class Initialized
DEBUG - 2011-10-01 15:00:56 --> Hooks Class Initialized
DEBUG - 2011-10-01 15:00:56 --> Utf8 Class Initialized
DEBUG - 2011-10-01 15:00:56 --> UTF-8 Support Enabled
DEBUG - 2011-10-01 15:00:56 --> URI Class Initialized
DEBUG - 2011-10-01 15:00:56 --> Router Class Initialized
DEBUG - 2011-10-01 15:00:56 --> Output Class Initialized
DEBUG - 2011-10-01 15:00:56 --> Input Class Initialized
DEBUG - 2011-10-01 15:00:56 --> Global POST and COOKIE data sanitized
DEBUG - 2011-10-01 15:00:56 --> Language Class Initialized
DEBUG - 2011-10-01 15:00:56 --> Loader Class Initialized
DEBUG - 2011-10-01 15:00:56 --> Controller Class Initialized
DEBUG - 2011-10-01 15:00:56 --> Model Class Initialized
DEBUG - 2011-10-01 15:00:56 --> Model Class Initialized
DEBUG - 2011-10-01 15:00:56 --> Model Class Initialized
DEBUG - 2011-10-01 15:00:56 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-10-01 15:00:56 --> Database Driver Class Initialized
DEBUG - 2011-10-01 15:00:56 --> File loaded: application/views/table/main.php
DEBUG - 2011-10-01 15:00:56 --> Helper loaded: url_helper
DEBUG - 2011-10-01 15:00:56 --> File loaded: application/views/common/header.php
DEBUG - 2011-10-01 15:00:56 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-10-01 15:00:56 --> File loaded: application/views/common/footer.php
DEBUG - 2011-10-01 15:00:56 --> File loaded: application/views/layout/main.php
DEBUG - 2011-10-01 15:00:56 --> Final output sent to browser
DEBUG - 2011-10-01 15:00:56 --> Total execution time: 0.3896
DEBUG - 2011-10-01 15:00:58 --> Config Class Initialized
DEBUG - 2011-10-01 15:00:58 --> Hooks Class Initialized
DEBUG - 2011-10-01 15:00:58 --> Utf8 Class Initialized
DEBUG - 2011-10-01 15:00:58 --> UTF-8 Support Enabled
DEBUG - 2011-10-01 15:00:58 --> URI Class Initialized
DEBUG - 2011-10-01 15:00:58 --> Router Class Initialized
ERROR - 2011-10-01 15:00:58 --> 404 Page Not Found --> robots.txt
DEBUG - 2011-10-01 15:00:58 --> Config Class Initialized
DEBUG - 2011-10-01 15:00:58 --> Hooks Class Initialized
DEBUG - 2011-10-01 15:00:58 --> Utf8 Class Initialized
DEBUG - 2011-10-01 15:00:58 --> UTF-8 Support Enabled
DEBUG - 2011-10-01 15:00:58 --> URI Class Initialized
DEBUG - 2011-10-01 15:00:58 --> Router Class Initialized
DEBUG - 2011-10-01 15:00:58 --> Output Class Initialized
DEBUG - 2011-10-01 15:00:58 --> Input Class Initialized
DEBUG - 2011-10-01 15:00:58 --> Global POST and COOKIE data sanitized
DEBUG - 2011-10-01 15:00:58 --> Language Class Initialized
DEBUG - 2011-10-01 15:00:58 --> Loader Class Initialized
DEBUG - 2011-10-01 15:00:58 --> Controller Class Initialized
DEBUG - 2011-10-01 15:00:58 --> Model Class Initialized
DEBUG - 2011-10-01 15:00:58 --> Model Class Initialized
DEBUG - 2011-10-01 15:00:58 --> Model Class Initialized
DEBUG - 2011-10-01 15:00:58 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-10-01 15:00:58 --> Database Driver Class Initialized
DEBUG - 2011-10-01 15:00:58 --> File loaded: application/views/table/main.php
DEBUG - 2011-10-01 15:00:58 --> Helper loaded: url_helper
DEBUG - 2011-10-01 15:00:58 --> File loaded: application/views/common/header.php
DEBUG - 2011-10-01 15:00:58 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-10-01 15:00:58 --> File loaded: application/views/common/footer.php
DEBUG - 2011-10-01 15:00:58 --> File loaded: application/views/layout/main.php
DEBUG - 2011-10-01 15:00:58 --> Final output sent to browser
DEBUG - 2011-10-01 15:00:58 --> Total execution time: 0.1151
DEBUG - 2011-10-01 15:01:06 --> Config Class Initialized
DEBUG - 2011-10-01 15:01:06 --> Hooks Class Initialized
DEBUG - 2011-10-01 15:01:06 --> Utf8 Class Initialized
DEBUG - 2011-10-01 15:01:06 --> UTF-8 Support Enabled
DEBUG - 2011-10-01 15:01:06 --> URI Class Initialized
DEBUG - 2011-10-01 15:01:06 --> Router Class Initialized
DEBUG - 2011-10-01 15:01:06 --> Output Class Initialized
DEBUG - 2011-10-01 15:01:06 --> Input Class Initialized
DEBUG - 2011-10-01 15:01:06 --> Global POST and COOKIE data sanitized
DEBUG - 2011-10-01 15:01:06 --> Language Class Initialized
DEBUG - 2011-10-01 15:01:06 --> Loader Class Initialized
DEBUG - 2011-10-01 15:01:06 --> Controller Class Initialized
DEBUG - 2011-10-01 15:01:06 --> Model Class Initialized
DEBUG - 2011-10-01 15:01:06 --> Model Class Initialized
DEBUG - 2011-10-01 15:01:06 --> Model Class Initialized
DEBUG - 2011-10-01 15:01:06 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-10-01 15:01:06 --> Database Driver Class Initialized
DEBUG - 2011-10-01 15:01:07 --> File loaded: application/views/table/main.php
DEBUG - 2011-10-01 15:01:07 --> Helper loaded: url_helper
DEBUG - 2011-10-01 15:01:07 --> File loaded: application/views/common/header.php
DEBUG - 2011-10-01 15:01:07 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-10-01 15:01:07 --> File loaded: application/views/common/footer.php
DEBUG - 2011-10-01 15:01:07 --> File loaded: application/views/layout/main.php
DEBUG - 2011-10-01 15:01:07 --> Final output sent to browser
DEBUG - 2011-10-01 15:01:07 --> Total execution time: 0.3438
DEBUG - 2011-10-01 15:01:08 --> Config Class Initialized
DEBUG - 2011-10-01 15:01:08 --> Hooks Class Initialized
DEBUG - 2011-10-01 15:01:08 --> Utf8 Class Initialized
DEBUG - 2011-10-01 15:01:08 --> UTF-8 Support Enabled
DEBUG - 2011-10-01 15:01:08 --> URI Class Initialized
DEBUG - 2011-10-01 15:01:08 --> Router Class Initialized
DEBUG - 2011-10-01 15:01:08 --> Output Class Initialized
DEBUG - 2011-10-01 15:01:08 --> Input Class Initialized
DEBUG - 2011-10-01 15:01:08 --> Global POST and COOKIE data sanitized
DEBUG - 2011-10-01 15:01:08 --> Language Class Initialized
DEBUG - 2011-10-01 15:01:08 --> Loader Class Initialized
DEBUG - 2011-10-01 15:01:08 --> Controller Class Initialized
DEBUG - 2011-10-01 15:01:08 --> Model Class Initialized
DEBUG - 2011-10-01 15:01:08 --> Model Class Initialized
DEBUG - 2011-10-01 15:01:08 --> Model Class Initialized
DEBUG - 2011-10-01 15:01:08 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-10-01 15:01:08 --> Database Driver Class Initialized
DEBUG - 2011-10-01 15:01:08 --> File loaded: application/views/table/main.php
DEBUG - 2011-10-01 15:01:08 --> Helper loaded: url_helper
DEBUG - 2011-10-01 15:01:08 --> File loaded: application/views/common/header.php
DEBUG - 2011-10-01 15:01:08 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-10-01 15:01:08 --> File loaded: application/views/common/footer.php
DEBUG - 2011-10-01 15:01:08 --> File loaded: application/views/layout/main.php
DEBUG - 2011-10-01 15:01:08 --> Final output sent to browser
DEBUG - 2011-10-01 15:01:08 --> Total execution time: 0.0586
DEBUG - 2011-10-01 15:15:45 --> Config Class Initialized
DEBUG - 2011-10-01 15:15:45 --> Hooks Class Initialized
DEBUG - 2011-10-01 15:15:45 --> Utf8 Class Initialized
DEBUG - 2011-10-01 15:15:45 --> UTF-8 Support Enabled
DEBUG - 2011-10-01 15:15:45 --> URI Class Initialized
DEBUG - 2011-10-01 15:15:45 --> Router Class Initialized
DEBUG - 2011-10-01 15:15:45 --> Output Class Initialized
DEBUG - 2011-10-01 15:15:45 --> Input Class Initialized
DEBUG - 2011-10-01 15:15:45 --> Global POST and COOKIE data sanitized
DEBUG - 2011-10-01 15:15:45 --> Language Class Initialized
DEBUG - 2011-10-01 15:15:45 --> Loader Class Initialized
DEBUG - 2011-10-01 15:15:45 --> Controller Class Initialized
DEBUG - 2011-10-01 15:15:45 --> Model Class Initialized
DEBUG - 2011-10-01 15:15:45 --> Model Class Initialized
DEBUG - 2011-10-01 15:15:45 --> Model Class Initialized
DEBUG - 2011-10-01 15:15:45 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-10-01 15:15:45 --> Database Driver Class Initialized
DEBUG - 2011-10-01 15:15:46 --> File loaded: application/views/table/main.php
DEBUG - 2011-10-01 15:15:46 --> Helper loaded: url_helper
DEBUG - 2011-10-01 15:15:46 --> File loaded: application/views/common/header.php
DEBUG - 2011-10-01 15:15:46 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-10-01 15:15:46 --> File loaded: application/views/common/footer.php
DEBUG - 2011-10-01 15:15:46 --> File loaded: application/views/layout/main.php
DEBUG - 2011-10-01 15:15:46 --> Final output sent to browser
DEBUG - 2011-10-01 15:15:46 --> Total execution time: 0.1976
DEBUG - 2011-10-01 15:15:50 --> Config Class Initialized
DEBUG - 2011-10-01 15:15:50 --> Hooks Class Initialized
DEBUG - 2011-10-01 15:15:50 --> Utf8 Class Initialized
DEBUG - 2011-10-01 15:15:50 --> UTF-8 Support Enabled
DEBUG - 2011-10-01 15:15:50 --> URI Class Initialized
DEBUG - 2011-10-01 15:15:50 --> Router Class Initialized
ERROR - 2011-10-01 15:15:50 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-10-01 15:15:55 --> Config Class Initialized
DEBUG - 2011-10-01 15:15:55 --> Hooks Class Initialized
DEBUG - 2011-10-01 15:15:55 --> Utf8 Class Initialized
DEBUG - 2011-10-01 15:15:55 --> UTF-8 Support Enabled
DEBUG - 2011-10-01 15:15:55 --> URI Class Initialized
DEBUG - 2011-10-01 15:15:55 --> Router Class Initialized
DEBUG - 2011-10-01 15:15:55 --> Output Class Initialized
DEBUG - 2011-10-01 15:15:55 --> Input Class Initialized
DEBUG - 2011-10-01 15:15:55 --> Global POST and COOKIE data sanitized
DEBUG - 2011-10-01 15:15:55 --> Language Class Initialized
DEBUG - 2011-10-01 15:15:55 --> Loader Class Initialized
DEBUG - 2011-10-01 15:15:55 --> Controller Class Initialized
DEBUG - 2011-10-01 15:15:55 --> Model Class Initialized
DEBUG - 2011-10-01 15:15:55 --> Model Class Initialized
DEBUG - 2011-10-01 15:15:55 --> Model Class Initialized
DEBUG - 2011-10-01 15:15:55 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-10-01 15:15:55 --> Database Driver Class Initialized
DEBUG - 2011-10-01 15:15:55 --> File loaded: application/views/table/main.php
DEBUG - 2011-10-01 15:15:55 --> Helper loaded: url_helper
DEBUG - 2011-10-01 15:15:55 --> File loaded: application/views/common/header.php
DEBUG - 2011-10-01 15:15:55 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-10-01 15:15:55 --> File loaded: application/views/common/footer.php
DEBUG - 2011-10-01 15:15:55 --> File loaded: application/views/layout/main.php
DEBUG - 2011-10-01 15:15:55 --> Final output sent to browser
DEBUG - 2011-10-01 15:15:55 --> Total execution time: 0.2102
DEBUG - 2011-10-01 15:15:58 --> Config Class Initialized
DEBUG - 2011-10-01 15:15:58 --> Hooks Class Initialized
DEBUG - 2011-10-01 15:15:58 --> Utf8 Class Initialized
DEBUG - 2011-10-01 15:15:58 --> UTF-8 Support Enabled
DEBUG - 2011-10-01 15:15:58 --> URI Class Initialized
DEBUG - 2011-10-01 15:15:58 --> Router Class Initialized
ERROR - 2011-10-01 15:15:58 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-10-01 15:32:11 --> Config Class Initialized
DEBUG - 2011-10-01 15:32:11 --> Hooks Class Initialized
DEBUG - 2011-10-01 15:32:11 --> Utf8 Class Initialized
DEBUG - 2011-10-01 15:32:11 --> UTF-8 Support Enabled
DEBUG - 2011-10-01 15:32:11 --> URI Class Initialized
DEBUG - 2011-10-01 15:32:11 --> Router Class Initialized
DEBUG - 2011-10-01 15:32:11 --> Output Class Initialized
DEBUG - 2011-10-01 15:32:11 --> Input Class Initialized
DEBUG - 2011-10-01 15:32:11 --> Global POST and COOKIE data sanitized
DEBUG - 2011-10-01 15:32:11 --> Language Class Initialized
DEBUG - 2011-10-01 15:32:11 --> Loader Class Initialized
DEBUG - 2011-10-01 15:32:11 --> Controller Class Initialized
DEBUG - 2011-10-01 15:32:11 --> Model Class Initialized
DEBUG - 2011-10-01 15:32:11 --> Model Class Initialized
DEBUG - 2011-10-01 15:32:11 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-10-01 15:32:11 --> Database Driver Class Initialized
DEBUG - 2011-10-01 15:32:12 --> Final output sent to browser
DEBUG - 2011-10-01 15:32:12 --> Total execution time: 0.6014
DEBUG - 2011-10-01 15:32:13 --> Config Class Initialized
DEBUG - 2011-10-01 15:32:13 --> Hooks Class Initialized
DEBUG - 2011-10-01 15:32:13 --> Utf8 Class Initialized
DEBUG - 2011-10-01 15:32:13 --> UTF-8 Support Enabled
DEBUG - 2011-10-01 15:32:13 --> URI Class Initialized
DEBUG - 2011-10-01 15:32:13 --> Router Class Initialized
DEBUG - 2011-10-01 15:32:13 --> Output Class Initialized
DEBUG - 2011-10-01 15:32:13 --> Input Class Initialized
DEBUG - 2011-10-01 15:32:13 --> Global POST and COOKIE data sanitized
DEBUG - 2011-10-01 15:32:13 --> Language Class Initialized
DEBUG - 2011-10-01 15:32:13 --> Loader Class Initialized
DEBUG - 2011-10-01 15:32:13 --> Controller Class Initialized
ERROR - 2011-10-01 15:32:13 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-10-01 15:32:13 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-10-01 15:32:13 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-10-01 15:32:13 --> Model Class Initialized
DEBUG - 2011-10-01 15:32:13 --> Model Class Initialized
DEBUG - 2011-10-01 15:32:13 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-10-01 15:32:13 --> Database Driver Class Initialized
DEBUG - 2011-10-01 15:32:13 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-10-01 15:32:13 --> Helper loaded: url_helper
DEBUG - 2011-10-01 15:32:13 --> File loaded: application/views/common/header.php
DEBUG - 2011-10-01 15:32:13 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-10-01 15:32:13 --> File loaded: application/views/common/footer.php
DEBUG - 2011-10-01 15:32:13 --> File loaded: application/views/layout/main.php
DEBUG - 2011-10-01 15:32:13 --> Final output sent to browser
DEBUG - 2011-10-01 15:32:13 --> Total execution time: 0.0498
DEBUG - 2011-10-01 15:42:06 --> Config Class Initialized
DEBUG - 2011-10-01 15:42:06 --> Hooks Class Initialized
DEBUG - 2011-10-01 15:42:06 --> Utf8 Class Initialized
DEBUG - 2011-10-01 15:42:06 --> UTF-8 Support Enabled
DEBUG - 2011-10-01 15:42:06 --> URI Class Initialized
DEBUG - 2011-10-01 15:42:06 --> Router Class Initialized
DEBUG - 2011-10-01 15:42:06 --> Output Class Initialized
DEBUG - 2011-10-01 15:42:06 --> Input Class Initialized
DEBUG - 2011-10-01 15:42:06 --> Global POST and COOKIE data sanitized
DEBUG - 2011-10-01 15:42:06 --> Language Class Initialized
DEBUG - 2011-10-01 15:42:06 --> Loader Class Initialized
DEBUG - 2011-10-01 15:42:06 --> Controller Class Initialized
DEBUG - 2011-10-01 15:42:06 --> Model Class Initialized
DEBUG - 2011-10-01 15:42:06 --> Model Class Initialized
DEBUG - 2011-10-01 15:42:06 --> Model Class Initialized
DEBUG - 2011-10-01 15:42:06 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-10-01 15:42:06 --> Database Driver Class Initialized
DEBUG - 2011-10-01 15:42:07 --> File loaded: application/views/table/main.php
DEBUG - 2011-10-01 15:42:07 --> Helper loaded: url_helper
DEBUG - 2011-10-01 15:42:07 --> File loaded: application/views/common/header.php
DEBUG - 2011-10-01 15:42:07 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-10-01 15:42:07 --> File loaded: application/views/common/footer.php
DEBUG - 2011-10-01 15:42:07 --> File loaded: application/views/layout/main.php
DEBUG - 2011-10-01 15:42:07 --> Final output sent to browser
DEBUG - 2011-10-01 15:42:07 --> Total execution time: 1.0985
DEBUG - 2011-10-01 15:42:08 --> Config Class Initialized
DEBUG - 2011-10-01 15:42:08 --> Hooks Class Initialized
DEBUG - 2011-10-01 15:42:08 --> Utf8 Class Initialized
DEBUG - 2011-10-01 15:42:08 --> UTF-8 Support Enabled
DEBUG - 2011-10-01 15:42:08 --> URI Class Initialized
DEBUG - 2011-10-01 15:42:08 --> Router Class Initialized
ERROR - 2011-10-01 15:42:08 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-10-01 15:42:09 --> Config Class Initialized
DEBUG - 2011-10-01 15:42:09 --> Hooks Class Initialized
DEBUG - 2011-10-01 15:42:09 --> Utf8 Class Initialized
DEBUG - 2011-10-01 15:42:09 --> UTF-8 Support Enabled
DEBUG - 2011-10-01 15:42:09 --> URI Class Initialized
DEBUG - 2011-10-01 15:42:09 --> Router Class Initialized
ERROR - 2011-10-01 15:42:09 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-10-01 15:42:20 --> Config Class Initialized
DEBUG - 2011-10-01 15:42:20 --> Hooks Class Initialized
DEBUG - 2011-10-01 15:42:20 --> Utf8 Class Initialized
DEBUG - 2011-10-01 15:42:20 --> UTF-8 Support Enabled
DEBUG - 2011-10-01 15:42:20 --> URI Class Initialized
DEBUG - 2011-10-01 15:42:20 --> Router Class Initialized
DEBUG - 2011-10-01 15:42:20 --> Output Class Initialized
DEBUG - 2011-10-01 15:42:20 --> Input Class Initialized
DEBUG - 2011-10-01 15:42:20 --> Global POST and COOKIE data sanitized
DEBUG - 2011-10-01 15:42:20 --> Language Class Initialized
DEBUG - 2011-10-01 15:42:20 --> Loader Class Initialized
DEBUG - 2011-10-01 15:42:20 --> Controller Class Initialized
DEBUG - 2011-10-01 15:42:20 --> Model Class Initialized
DEBUG - 2011-10-01 15:42:20 --> Model Class Initialized
DEBUG - 2011-10-01 15:42:20 --> Model Class Initialized
DEBUG - 2011-10-01 15:42:20 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-10-01 15:42:20 --> Database Driver Class Initialized
DEBUG - 2011-10-01 15:42:20 --> File loaded: application/views/table/main.php
DEBUG - 2011-10-01 15:42:20 --> Helper loaded: url_helper
DEBUG - 2011-10-01 15:42:20 --> File loaded: application/views/common/header.php
DEBUG - 2011-10-01 15:42:20 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-10-01 15:42:20 --> File loaded: application/views/common/footer.php
DEBUG - 2011-10-01 15:42:20 --> File loaded: application/views/layout/main.php
DEBUG - 2011-10-01 15:42:20 --> Final output sent to browser
DEBUG - 2011-10-01 15:42:20 --> Total execution time: 0.0517
DEBUG - 2011-10-01 15:42:25 --> Config Class Initialized
DEBUG - 2011-10-01 15:42:25 --> Hooks Class Initialized
DEBUG - 2011-10-01 15:42:25 --> Utf8 Class Initialized
DEBUG - 2011-10-01 15:42:25 --> UTF-8 Support Enabled
DEBUG - 2011-10-01 15:42:25 --> URI Class Initialized
DEBUG - 2011-10-01 15:42:25 --> Router Class Initialized
DEBUG - 2011-10-01 15:42:25 --> Output Class Initialized
DEBUG - 2011-10-01 15:42:25 --> Input Class Initialized
DEBUG - 2011-10-01 15:42:25 --> Global POST and COOKIE data sanitized
DEBUG - 2011-10-01 15:42:25 --> Language Class Initialized
DEBUG - 2011-10-01 15:42:25 --> Loader Class Initialized
DEBUG - 2011-10-01 15:42:25 --> Controller Class Initialized
DEBUG - 2011-10-01 15:42:25 --> Model Class Initialized
DEBUG - 2011-10-01 15:42:25 --> Model Class Initialized
DEBUG - 2011-10-01 15:42:25 --> Model Class Initialized
DEBUG - 2011-10-01 15:42:25 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-10-01 15:42:25 --> Database Driver Class Initialized
DEBUG - 2011-10-01 15:42:26 --> File loaded: application/views/table/main.php
DEBUG - 2011-10-01 15:42:26 --> Helper loaded: url_helper
DEBUG - 2011-10-01 15:42:26 --> File loaded: application/views/common/header.php
DEBUG - 2011-10-01 15:42:26 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-10-01 15:42:26 --> File loaded: application/views/common/footer.php
DEBUG - 2011-10-01 15:42:26 --> File loaded: application/views/layout/main.php
DEBUG - 2011-10-01 15:42:26 --> Final output sent to browser
DEBUG - 2011-10-01 15:42:26 --> Total execution time: 0.5770
DEBUG - 2011-10-01 15:53:02 --> Config Class Initialized
DEBUG - 2011-10-01 15:53:02 --> Hooks Class Initialized
DEBUG - 2011-10-01 15:53:02 --> Utf8 Class Initialized
DEBUG - 2011-10-01 15:53:02 --> UTF-8 Support Enabled
DEBUG - 2011-10-01 15:53:02 --> URI Class Initialized
DEBUG - 2011-10-01 15:53:02 --> Router Class Initialized
DEBUG - 2011-10-01 15:53:02 --> Output Class Initialized
DEBUG - 2011-10-01 15:53:02 --> Input Class Initialized
DEBUG - 2011-10-01 15:53:02 --> Global POST and COOKIE data sanitized
DEBUG - 2011-10-01 15:53:02 --> Language Class Initialized
DEBUG - 2011-10-01 15:53:02 --> Loader Class Initialized
DEBUG - 2011-10-01 15:53:02 --> Controller Class Initialized
ERROR - 2011-10-01 15:53:02 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-10-01 15:53:02 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-10-01 15:53:02 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-10-01 15:53:02 --> Model Class Initialized
DEBUG - 2011-10-01 15:53:02 --> Model Class Initialized
DEBUG - 2011-10-01 15:53:02 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-10-01 15:53:02 --> Database Driver Class Initialized
DEBUG - 2011-10-01 15:53:02 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-10-01 15:53:02 --> Helper loaded: url_helper
DEBUG - 2011-10-01 15:53:02 --> File loaded: application/views/common/header.php
DEBUG - 2011-10-01 15:53:02 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-10-01 15:53:02 --> File loaded: application/views/common/footer.php
DEBUG - 2011-10-01 15:53:02 --> File loaded: application/views/layout/main.php
DEBUG - 2011-10-01 15:53:02 --> Final output sent to browser
DEBUG - 2011-10-01 15:53:02 --> Total execution time: 0.0631
DEBUG - 2011-10-01 15:53:03 --> Config Class Initialized
DEBUG - 2011-10-01 15:53:03 --> Hooks Class Initialized
DEBUG - 2011-10-01 15:53:03 --> Utf8 Class Initialized
DEBUG - 2011-10-01 15:53:03 --> UTF-8 Support Enabled
DEBUG - 2011-10-01 15:53:03 --> URI Class Initialized
DEBUG - 2011-10-01 15:53:03 --> Router Class Initialized
DEBUG - 2011-10-01 15:53:03 --> Output Class Initialized
DEBUG - 2011-10-01 15:53:03 --> Input Class Initialized
DEBUG - 2011-10-01 15:53:03 --> Global POST and COOKIE data sanitized
DEBUG - 2011-10-01 15:53:03 --> Language Class Initialized
DEBUG - 2011-10-01 15:53:03 --> Loader Class Initialized
DEBUG - 2011-10-01 15:53:03 --> Controller Class Initialized
DEBUG - 2011-10-01 15:53:03 --> Model Class Initialized
DEBUG - 2011-10-01 15:53:03 --> Model Class Initialized
DEBUG - 2011-10-01 15:53:03 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-10-01 15:53:03 --> Database Driver Class Initialized
DEBUG - 2011-10-01 15:53:04 --> Final output sent to browser
DEBUG - 2011-10-01 15:53:04 --> Total execution time: 0.7088
DEBUG - 2011-10-01 15:53:08 --> Config Class Initialized
DEBUG - 2011-10-01 15:53:08 --> Hooks Class Initialized
DEBUG - 2011-10-01 15:53:08 --> Utf8 Class Initialized
DEBUG - 2011-10-01 15:53:08 --> UTF-8 Support Enabled
DEBUG - 2011-10-01 15:53:08 --> URI Class Initialized
DEBUG - 2011-10-01 15:53:08 --> Router Class Initialized
ERROR - 2011-10-01 15:53:08 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-10-01 15:53:09 --> Config Class Initialized
DEBUG - 2011-10-01 15:53:09 --> Hooks Class Initialized
DEBUG - 2011-10-01 15:53:09 --> Utf8 Class Initialized
DEBUG - 2011-10-01 15:53:09 --> UTF-8 Support Enabled
DEBUG - 2011-10-01 15:53:09 --> URI Class Initialized
DEBUG - 2011-10-01 15:53:09 --> Router Class Initialized
ERROR - 2011-10-01 15:53:09 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-10-01 15:54:25 --> Config Class Initialized
DEBUG - 2011-10-01 15:54:25 --> Hooks Class Initialized
DEBUG - 2011-10-01 15:54:25 --> Utf8 Class Initialized
DEBUG - 2011-10-01 15:54:25 --> UTF-8 Support Enabled
DEBUG - 2011-10-01 15:54:25 --> URI Class Initialized
DEBUG - 2011-10-01 15:54:25 --> Router Class Initialized
DEBUG - 2011-10-01 15:54:25 --> Output Class Initialized
DEBUG - 2011-10-01 15:54:25 --> Input Class Initialized
DEBUG - 2011-10-01 15:54:25 --> Global POST and COOKIE data sanitized
DEBUG - 2011-10-01 15:54:25 --> Language Class Initialized
DEBUG - 2011-10-01 15:54:25 --> Loader Class Initialized
DEBUG - 2011-10-01 15:54:25 --> Controller Class Initialized
ERROR - 2011-10-01 15:54:25 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-10-01 15:54:25 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-10-01 15:54:25 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-10-01 15:54:25 --> Model Class Initialized
DEBUG - 2011-10-01 15:54:25 --> Model Class Initialized
DEBUG - 2011-10-01 15:54:25 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-10-01 15:54:25 --> Database Driver Class Initialized
DEBUG - 2011-10-01 15:54:25 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-10-01 15:54:25 --> Helper loaded: url_helper
DEBUG - 2011-10-01 15:54:25 --> File loaded: application/views/common/header.php
DEBUG - 2011-10-01 15:54:25 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-10-01 15:54:25 --> File loaded: application/views/common/footer.php
DEBUG - 2011-10-01 15:54:25 --> File loaded: application/views/layout/main.php
DEBUG - 2011-10-01 15:54:25 --> Final output sent to browser
DEBUG - 2011-10-01 15:54:25 --> Total execution time: 0.0357
DEBUG - 2011-10-01 15:54:26 --> Config Class Initialized
DEBUG - 2011-10-01 15:54:26 --> Hooks Class Initialized
DEBUG - 2011-10-01 15:54:26 --> Utf8 Class Initialized
DEBUG - 2011-10-01 15:54:26 --> UTF-8 Support Enabled
DEBUG - 2011-10-01 15:54:26 --> URI Class Initialized
DEBUG - 2011-10-01 15:54:26 --> Router Class Initialized
DEBUG - 2011-10-01 15:54:26 --> Output Class Initialized
DEBUG - 2011-10-01 15:54:26 --> Input Class Initialized
DEBUG - 2011-10-01 15:54:26 --> Global POST and COOKIE data sanitized
DEBUG - 2011-10-01 15:54:26 --> Language Class Initialized
DEBUG - 2011-10-01 15:54:26 --> Loader Class Initialized
DEBUG - 2011-10-01 15:54:26 --> Controller Class Initialized
DEBUG - 2011-10-01 15:54:26 --> Model Class Initialized
DEBUG - 2011-10-01 15:54:26 --> Model Class Initialized
DEBUG - 2011-10-01 15:54:26 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-10-01 15:54:26 --> Database Driver Class Initialized
DEBUG - 2011-10-01 15:54:28 --> Final output sent to browser
DEBUG - 2011-10-01 15:54:28 --> Total execution time: 1.4483
DEBUG - 2011-10-01 16:22:12 --> Config Class Initialized
DEBUG - 2011-10-01 16:22:12 --> Hooks Class Initialized
DEBUG - 2011-10-01 16:22:12 --> Utf8 Class Initialized
DEBUG - 2011-10-01 16:22:12 --> UTF-8 Support Enabled
DEBUG - 2011-10-01 16:22:12 --> URI Class Initialized
DEBUG - 2011-10-01 16:22:12 --> Router Class Initialized
DEBUG - 2011-10-01 16:22:12 --> No URI present. Default controller set.
DEBUG - 2011-10-01 16:22:12 --> Output Class Initialized
DEBUG - 2011-10-01 16:22:12 --> Input Class Initialized
DEBUG - 2011-10-01 16:22:12 --> Global POST and COOKIE data sanitized
DEBUG - 2011-10-01 16:22:12 --> Language Class Initialized
DEBUG - 2011-10-01 16:22:12 --> Loader Class Initialized
DEBUG - 2011-10-01 16:22:12 --> Controller Class Initialized
DEBUG - 2011-10-01 16:22:12 --> File loaded: application/views/splash/main.php
DEBUG - 2011-10-01 16:22:12 --> Helper loaded: url_helper
DEBUG - 2011-10-01 16:22:12 --> File loaded: application/views/common/header.php
DEBUG - 2011-10-01 16:22:12 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-10-01 16:22:12 --> File loaded: application/views/common/footer.php
DEBUG - 2011-10-01 16:22:12 --> File loaded: application/views/layout/main.php
DEBUG - 2011-10-01 16:22:12 --> Final output sent to browser
DEBUG - 2011-10-01 16:22:12 --> Total execution time: 0.0790
DEBUG - 2011-10-01 16:45:11 --> Config Class Initialized
DEBUG - 2011-10-01 16:45:11 --> Hooks Class Initialized
DEBUG - 2011-10-01 16:45:11 --> Utf8 Class Initialized
DEBUG - 2011-10-01 16:45:11 --> UTF-8 Support Enabled
DEBUG - 2011-10-01 16:45:11 --> URI Class Initialized
DEBUG - 2011-10-01 16:45:11 --> Router Class Initialized
DEBUG - 2011-10-01 16:45:11 --> Output Class Initialized
DEBUG - 2011-10-01 16:45:11 --> Input Class Initialized
DEBUG - 2011-10-01 16:45:11 --> Global POST and COOKIE data sanitized
DEBUG - 2011-10-01 16:45:11 --> Language Class Initialized
DEBUG - 2011-10-01 16:45:11 --> Loader Class Initialized
DEBUG - 2011-10-01 16:45:11 --> Controller Class Initialized
DEBUG - 2011-10-01 16:45:11 --> Model Class Initialized
DEBUG - 2011-10-01 16:45:11 --> Model Class Initialized
DEBUG - 2011-10-01 16:45:11 --> Model Class Initialized
DEBUG - 2011-10-01 16:45:11 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-10-01 16:45:11 --> Database Driver Class Initialized
DEBUG - 2011-10-01 16:45:13 --> File loaded: application/views/table/main.php
DEBUG - 2011-10-01 16:45:13 --> Helper loaded: url_helper
DEBUG - 2011-10-01 16:45:13 --> File loaded: application/views/common/header.php
DEBUG - 2011-10-01 16:45:13 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-10-01 16:45:13 --> File loaded: application/views/common/footer.php
DEBUG - 2011-10-01 16:45:13 --> File loaded: application/views/layout/main.php
DEBUG - 2011-10-01 16:45:13 --> Final output sent to browser
DEBUG - 2011-10-01 16:45:13 --> Total execution time: 1.4856
DEBUG - 2011-10-01 16:49:58 --> Config Class Initialized
DEBUG - 2011-10-01 16:49:58 --> Hooks Class Initialized
DEBUG - 2011-10-01 16:49:58 --> Utf8 Class Initialized
DEBUG - 2011-10-01 16:49:58 --> UTF-8 Support Enabled
DEBUG - 2011-10-01 16:49:58 --> URI Class Initialized
DEBUG - 2011-10-01 16:49:58 --> Router Class Initialized
DEBUG - 2011-10-01 16:49:58 --> Output Class Initialized
DEBUG - 2011-10-01 16:49:58 --> Input Class Initialized
DEBUG - 2011-10-01 16:49:58 --> Global POST and COOKIE data sanitized
DEBUG - 2011-10-01 16:49:58 --> Language Class Initialized
DEBUG - 2011-10-01 16:49:58 --> Loader Class Initialized
DEBUG - 2011-10-01 16:49:58 --> Controller Class Initialized
DEBUG - 2011-10-01 16:49:58 --> Model Class Initialized
DEBUG - 2011-10-01 16:49:58 --> Model Class Initialized
DEBUG - 2011-10-01 16:49:58 --> Model Class Initialized
DEBUG - 2011-10-01 16:49:58 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-10-01 16:49:58 --> Database Driver Class Initialized
DEBUG - 2011-10-01 16:49:58 --> File loaded: application/views/table/main.php
DEBUG - 2011-10-01 16:49:58 --> Helper loaded: url_helper
DEBUG - 2011-10-01 16:49:58 --> File loaded: application/views/common/header.php
DEBUG - 2011-10-01 16:49:58 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-10-01 16:49:58 --> File loaded: application/views/common/footer.php
DEBUG - 2011-10-01 16:49:58 --> File loaded: application/views/layout/main.php
DEBUG - 2011-10-01 16:49:58 --> Final output sent to browser
DEBUG - 2011-10-01 16:49:58 --> Total execution time: 0.0482
DEBUG - 2011-10-01 16:49:59 --> Config Class Initialized
DEBUG - 2011-10-01 16:49:59 --> Hooks Class Initialized
DEBUG - 2011-10-01 16:49:59 --> Utf8 Class Initialized
DEBUG - 2011-10-01 16:49:59 --> UTF-8 Support Enabled
DEBUG - 2011-10-01 16:49:59 --> URI Class Initialized
DEBUG - 2011-10-01 16:49:59 --> Router Class Initialized
DEBUG - 2011-10-01 16:49:59 --> Output Class Initialized
DEBUG - 2011-10-01 16:49:59 --> Input Class Initialized
DEBUG - 2011-10-01 16:49:59 --> Global POST and COOKIE data sanitized
DEBUG - 2011-10-01 16:49:59 --> Language Class Initialized
DEBUG - 2011-10-01 16:49:59 --> Loader Class Initialized
DEBUG - 2011-10-01 16:49:59 --> Controller Class Initialized
ERROR - 2011-10-01 16:49:59 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-10-01 16:49:59 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-10-01 16:49:59 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-10-01 16:49:59 --> Model Class Initialized
DEBUG - 2011-10-01 16:49:59 --> Model Class Initialized
DEBUG - 2011-10-01 16:49:59 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-10-01 16:49:59 --> Database Driver Class Initialized
DEBUG - 2011-10-01 16:49:59 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-10-01 16:49:59 --> Helper loaded: url_helper
DEBUG - 2011-10-01 16:49:59 --> File loaded: application/views/common/header.php
DEBUG - 2011-10-01 16:49:59 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-10-01 16:49:59 --> File loaded: application/views/common/footer.php
DEBUG - 2011-10-01 16:49:59 --> File loaded: application/views/layout/main.php
DEBUG - 2011-10-01 16:49:59 --> Final output sent to browser
DEBUG - 2011-10-01 16:49:59 --> Total execution time: 0.0321
DEBUG - 2011-10-01 17:55:17 --> Config Class Initialized
DEBUG - 2011-10-01 17:55:17 --> Hooks Class Initialized
DEBUG - 2011-10-01 17:55:17 --> Utf8 Class Initialized
DEBUG - 2011-10-01 17:55:17 --> UTF-8 Support Enabled
DEBUG - 2011-10-01 17:55:17 --> URI Class Initialized
DEBUG - 2011-10-01 17:55:17 --> Router Class Initialized
ERROR - 2011-10-01 17:55:17 --> 404 Page Not Found --> robots.txt
DEBUG - 2011-10-01 17:55:18 --> Config Class Initialized
DEBUG - 2011-10-01 17:55:18 --> Hooks Class Initialized
DEBUG - 2011-10-01 17:55:18 --> Utf8 Class Initialized
DEBUG - 2011-10-01 17:55:18 --> UTF-8 Support Enabled
DEBUG - 2011-10-01 17:55:18 --> URI Class Initialized
DEBUG - 2011-10-01 17:55:18 --> Router Class Initialized
DEBUG - 2011-10-01 17:55:18 --> Output Class Initialized
DEBUG - 2011-10-01 17:55:18 --> Input Class Initialized
DEBUG - 2011-10-01 17:55:18 --> Global POST and COOKIE data sanitized
DEBUG - 2011-10-01 17:55:18 --> Language Class Initialized
DEBUG - 2011-10-01 17:55:18 --> Loader Class Initialized
DEBUG - 2011-10-01 17:55:18 --> Controller Class Initialized
ERROR - 2011-10-01 17:55:18 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-10-01 17:55:18 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-10-01 17:55:18 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-10-01 17:55:18 --> Model Class Initialized
DEBUG - 2011-10-01 17:55:18 --> Model Class Initialized
DEBUG - 2011-10-01 17:55:18 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-10-01 17:55:18 --> Database Driver Class Initialized
DEBUG - 2011-10-01 17:55:18 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-10-01 17:55:18 --> Helper loaded: url_helper
DEBUG - 2011-10-01 17:55:18 --> File loaded: application/views/common/header.php
DEBUG - 2011-10-01 17:55:18 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-10-01 17:55:18 --> File loaded: application/views/common/footer.php
DEBUG - 2011-10-01 17:55:18 --> File loaded: application/views/layout/main.php
DEBUG - 2011-10-01 17:55:18 --> Final output sent to browser
DEBUG - 2011-10-01 17:55:18 --> Total execution time: 0.3497
DEBUG - 2011-10-01 18:29:49 --> Config Class Initialized
DEBUG - 2011-10-01 18:29:49 --> Hooks Class Initialized
DEBUG - 2011-10-01 18:29:49 --> Utf8 Class Initialized
DEBUG - 2011-10-01 18:29:49 --> UTF-8 Support Enabled
DEBUG - 2011-10-01 18:29:49 --> URI Class Initialized
DEBUG - 2011-10-01 18:29:49 --> Router Class Initialized
DEBUG - 2011-10-01 18:29:49 --> Output Class Initialized
DEBUG - 2011-10-01 18:29:49 --> Input Class Initialized
DEBUG - 2011-10-01 18:29:49 --> Global POST and COOKIE data sanitized
DEBUG - 2011-10-01 18:29:49 --> Language Class Initialized
DEBUG - 2011-10-01 18:29:49 --> Loader Class Initialized
DEBUG - 2011-10-01 18:29:49 --> Controller Class Initialized
DEBUG - 2011-10-01 18:29:49 --> Model Class Initialized
DEBUG - 2011-10-01 18:29:49 --> Model Class Initialized
DEBUG - 2011-10-01 18:29:49 --> Model Class Initialized
DEBUG - 2011-10-01 18:29:49 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-10-01 18:29:49 --> Database Driver Class Initialized
DEBUG - 2011-10-01 18:29:51 --> File loaded: application/views/table/main.php
DEBUG - 2011-10-01 18:29:51 --> Helper loaded: url_helper
DEBUG - 2011-10-01 18:29:51 --> File loaded: application/views/common/header.php
DEBUG - 2011-10-01 18:29:51 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-10-01 18:29:51 --> File loaded: application/views/common/footer.php
DEBUG - 2011-10-01 18:29:51 --> File loaded: application/views/layout/main.php
DEBUG - 2011-10-01 18:29:51 --> Final output sent to browser
DEBUG - 2011-10-01 18:29:51 --> Total execution time: 1.8077
DEBUG - 2011-10-01 18:33:03 --> Config Class Initialized
DEBUG - 2011-10-01 18:33:03 --> Hooks Class Initialized
DEBUG - 2011-10-01 18:33:03 --> Utf8 Class Initialized
DEBUG - 2011-10-01 18:33:03 --> UTF-8 Support Enabled
DEBUG - 2011-10-01 18:33:03 --> URI Class Initialized
DEBUG - 2011-10-01 18:33:03 --> Router Class Initialized
ERROR - 2011-10-01 18:33:03 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-10-01 19:24:07 --> Config Class Initialized
DEBUG - 2011-10-01 19:24:07 --> Hooks Class Initialized
DEBUG - 2011-10-01 19:24:07 --> Utf8 Class Initialized
DEBUG - 2011-10-01 19:24:07 --> UTF-8 Support Enabled
DEBUG - 2011-10-01 19:24:07 --> URI Class Initialized
DEBUG - 2011-10-01 19:24:07 --> Router Class Initialized
DEBUG - 2011-10-01 19:24:07 --> No URI present. Default controller set.
DEBUG - 2011-10-01 19:24:07 --> Output Class Initialized
DEBUG - 2011-10-01 19:24:07 --> Input Class Initialized
DEBUG - 2011-10-01 19:24:07 --> Global POST and COOKIE data sanitized
DEBUG - 2011-10-01 19:24:07 --> Language Class Initialized
DEBUG - 2011-10-01 19:24:07 --> Loader Class Initialized
DEBUG - 2011-10-01 19:24:07 --> Controller Class Initialized
DEBUG - 2011-10-01 19:24:07 --> File loaded: application/views/splash/main.php
DEBUG - 2011-10-01 19:24:07 --> Helper loaded: url_helper
DEBUG - 2011-10-01 19:24:07 --> File loaded: application/views/common/header.php
DEBUG - 2011-10-01 19:24:07 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-10-01 19:24:07 --> File loaded: application/views/common/footer.php
DEBUG - 2011-10-01 19:24:07 --> File loaded: application/views/layout/main.php
DEBUG - 2011-10-01 19:24:07 --> Final output sent to browser
DEBUG - 2011-10-01 19:24:07 --> Total execution time: 0.0721
DEBUG - 2011-10-01 19:33:45 --> Config Class Initialized
DEBUG - 2011-10-01 19:33:45 --> Hooks Class Initialized
DEBUG - 2011-10-01 19:33:45 --> Utf8 Class Initialized
DEBUG - 2011-10-01 19:33:45 --> UTF-8 Support Enabled
DEBUG - 2011-10-01 19:33:45 --> URI Class Initialized
DEBUG - 2011-10-01 19:33:45 --> Router Class Initialized
DEBUG - 2011-10-01 19:33:45 --> Output Class Initialized
DEBUG - 2011-10-01 19:33:45 --> Input Class Initialized
DEBUG - 2011-10-01 19:33:45 --> Global POST and COOKIE data sanitized
DEBUG - 2011-10-01 19:33:45 --> Language Class Initialized
DEBUG - 2011-10-01 19:33:45 --> Loader Class Initialized
DEBUG - 2011-10-01 19:33:45 --> Controller Class Initialized
ERROR - 2011-10-01 19:33:45 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-10-01 19:33:45 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-10-01 19:33:45 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-10-01 19:33:45 --> Model Class Initialized
DEBUG - 2011-10-01 19:33:45 --> Model Class Initialized
DEBUG - 2011-10-01 19:33:45 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-10-01 19:33:45 --> Database Driver Class Initialized
DEBUG - 2011-10-01 19:33:45 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-10-01 19:33:45 --> Helper loaded: url_helper
DEBUG - 2011-10-01 19:33:45 --> File loaded: application/views/common/header.php
DEBUG - 2011-10-01 19:33:45 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-10-01 19:33:45 --> File loaded: application/views/common/footer.php
DEBUG - 2011-10-01 19:33:45 --> File loaded: application/views/layout/main.php
DEBUG - 2011-10-01 19:33:45 --> Final output sent to browser
DEBUG - 2011-10-01 19:33:45 --> Total execution time: 0.2969
DEBUG - 2011-10-01 21:39:51 --> Config Class Initialized
DEBUG - 2011-10-01 21:39:51 --> Hooks Class Initialized
DEBUG - 2011-10-01 21:39:51 --> Utf8 Class Initialized
DEBUG - 2011-10-01 21:39:51 --> UTF-8 Support Enabled
DEBUG - 2011-10-01 21:39:51 --> URI Class Initialized
DEBUG - 2011-10-01 21:39:51 --> Router Class Initialized
DEBUG - 2011-10-01 21:39:51 --> Output Class Initialized
DEBUG - 2011-10-01 21:39:51 --> Input Class Initialized
DEBUG - 2011-10-01 21:39:51 --> Global POST and COOKIE data sanitized
DEBUG - 2011-10-01 21:39:51 --> Language Class Initialized
DEBUG - 2011-10-01 21:39:51 --> Loader Class Initialized
DEBUG - 2011-10-01 21:39:51 --> Controller Class Initialized
DEBUG - 2011-10-01 21:39:51 --> Model Class Initialized
DEBUG - 2011-10-01 21:39:51 --> Model Class Initialized
DEBUG - 2011-10-01 21:39:51 --> Model Class Initialized
DEBUG - 2011-10-01 21:39:51 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-10-01 21:39:51 --> Database Driver Class Initialized
DEBUG - 2011-10-01 21:39:52 --> File loaded: application/views/table/main.php
DEBUG - 2011-10-01 21:39:52 --> Helper loaded: url_helper
DEBUG - 2011-10-01 21:39:52 --> File loaded: application/views/common/header.php
DEBUG - 2011-10-01 21:39:52 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-10-01 21:39:52 --> File loaded: application/views/common/footer.php
DEBUG - 2011-10-01 21:39:52 --> File loaded: application/views/layout/main.php
DEBUG - 2011-10-01 21:39:52 --> Final output sent to browser
DEBUG - 2011-10-01 21:39:52 --> Total execution time: 1.0446
DEBUG - 2011-10-01 21:39:55 --> Config Class Initialized
DEBUG - 2011-10-01 21:39:55 --> Hooks Class Initialized
DEBUG - 2011-10-01 21:39:55 --> Utf8 Class Initialized
DEBUG - 2011-10-01 21:39:55 --> UTF-8 Support Enabled
DEBUG - 2011-10-01 21:39:55 --> URI Class Initialized
DEBUG - 2011-10-01 21:39:55 --> Router Class Initialized
DEBUG - 2011-10-01 21:39:55 --> Output Class Initialized
DEBUG - 2011-10-01 21:39:55 --> Input Class Initialized
DEBUG - 2011-10-01 21:39:55 --> Global POST and COOKIE data sanitized
DEBUG - 2011-10-01 21:39:55 --> Language Class Initialized
DEBUG - 2011-10-01 21:39:55 --> Loader Class Initialized
DEBUG - 2011-10-01 21:39:55 --> Controller Class Initialized
ERROR - 2011-10-01 21:39:55 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-10-01 21:39:55 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-10-01 21:39:55 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-10-01 21:39:55 --> Model Class Initialized
DEBUG - 2011-10-01 21:39:55 --> Model Class Initialized
DEBUG - 2011-10-01 21:39:55 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-10-01 21:39:56 --> Database Driver Class Initialized
DEBUG - 2011-10-01 21:39:56 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-10-01 21:39:56 --> Helper loaded: url_helper
DEBUG - 2011-10-01 21:39:56 --> File loaded: application/views/common/header.php
DEBUG - 2011-10-01 21:39:56 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-10-01 21:39:56 --> File loaded: application/views/common/footer.php
DEBUG - 2011-10-01 21:39:56 --> File loaded: application/views/layout/main.php
DEBUG - 2011-10-01 21:39:56 --> Final output sent to browser
DEBUG - 2011-10-01 21:39:56 --> Total execution time: 0.0303
DEBUG - 2011-10-01 21:39:57 --> Config Class Initialized
DEBUG - 2011-10-01 21:39:57 --> Hooks Class Initialized
DEBUG - 2011-10-01 21:39:57 --> Utf8 Class Initialized
DEBUG - 2011-10-01 21:39:57 --> UTF-8 Support Enabled
DEBUG - 2011-10-01 21:39:57 --> URI Class Initialized
DEBUG - 2011-10-01 21:39:57 --> Router Class Initialized
DEBUG - 2011-10-01 21:39:57 --> Output Class Initialized
DEBUG - 2011-10-01 21:39:57 --> Input Class Initialized
DEBUG - 2011-10-01 21:39:57 --> Global POST and COOKIE data sanitized
DEBUG - 2011-10-01 21:39:57 --> Language Class Initialized
DEBUG - 2011-10-01 21:39:57 --> Loader Class Initialized
DEBUG - 2011-10-01 21:39:57 --> Controller Class Initialized
DEBUG - 2011-10-01 21:39:57 --> Model Class Initialized
DEBUG - 2011-10-01 21:39:57 --> Model Class Initialized
DEBUG - 2011-10-01 21:39:57 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-10-01 21:39:57 --> Database Driver Class Initialized
DEBUG - 2011-10-01 21:39:57 --> Final output sent to browser
DEBUG - 2011-10-01 21:39:57 --> Total execution time: 0.6805
DEBUG - 2011-10-01 21:40:01 --> Config Class Initialized
DEBUG - 2011-10-01 21:40:01 --> Hooks Class Initialized
DEBUG - 2011-10-01 21:40:01 --> Utf8 Class Initialized
DEBUG - 2011-10-01 21:40:01 --> UTF-8 Support Enabled
DEBUG - 2011-10-01 21:40:01 --> URI Class Initialized
DEBUG - 2011-10-01 21:40:01 --> Router Class Initialized
ERROR - 2011-10-01 21:40:01 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-10-01 21:40:02 --> Config Class Initialized
DEBUG - 2011-10-01 21:40:02 --> Hooks Class Initialized
DEBUG - 2011-10-01 21:40:02 --> Utf8 Class Initialized
DEBUG - 2011-10-01 21:40:02 --> UTF-8 Support Enabled
DEBUG - 2011-10-01 21:40:02 --> URI Class Initialized
DEBUG - 2011-10-01 21:40:02 --> Router Class Initialized
ERROR - 2011-10-01 21:40:02 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-10-01 21:40:02 --> Config Class Initialized
DEBUG - 2011-10-01 21:40:02 --> Hooks Class Initialized
DEBUG - 2011-10-01 21:40:02 --> Utf8 Class Initialized
DEBUG - 2011-10-01 21:40:02 --> UTF-8 Support Enabled
DEBUG - 2011-10-01 21:40:02 --> URI Class Initialized
DEBUG - 2011-10-01 21:40:02 --> Router Class Initialized
ERROR - 2011-10-01 21:40:02 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-10-01 21:44:31 --> Config Class Initialized
DEBUG - 2011-10-01 21:44:31 --> Hooks Class Initialized
DEBUG - 2011-10-01 21:44:31 --> Utf8 Class Initialized
DEBUG - 2011-10-01 21:44:31 --> UTF-8 Support Enabled
DEBUG - 2011-10-01 21:44:31 --> URI Class Initialized
DEBUG - 2011-10-01 21:44:31 --> Router Class Initialized
DEBUG - 2011-10-01 21:44:31 --> Output Class Initialized
DEBUG - 2011-10-01 21:44:31 --> Input Class Initialized
DEBUG - 2011-10-01 21:44:31 --> Global POST and COOKIE data sanitized
DEBUG - 2011-10-01 21:44:31 --> Language Class Initialized
DEBUG - 2011-10-01 21:44:31 --> Loader Class Initialized
DEBUG - 2011-10-01 21:44:31 --> Controller Class Initialized
ERROR - 2011-10-01 21:44:31 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-10-01 21:44:31 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-10-01 21:44:31 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-10-01 21:44:31 --> Model Class Initialized
DEBUG - 2011-10-01 21:44:31 --> Model Class Initialized
DEBUG - 2011-10-01 21:44:31 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-10-01 21:44:31 --> Database Driver Class Initialized
DEBUG - 2011-10-01 21:44:31 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-10-01 21:44:31 --> Helper loaded: url_helper
DEBUG - 2011-10-01 21:44:31 --> File loaded: application/views/common/header.php
DEBUG - 2011-10-01 21:44:31 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-10-01 21:44:31 --> File loaded: application/views/common/footer.php
DEBUG - 2011-10-01 21:44:31 --> File loaded: application/views/layout/main.php
DEBUG - 2011-10-01 21:44:31 --> Final output sent to browser
DEBUG - 2011-10-01 21:44:31 --> Total execution time: 0.0343
DEBUG - 2011-10-01 21:44:33 --> Config Class Initialized
DEBUG - 2011-10-01 21:44:33 --> Hooks Class Initialized
DEBUG - 2011-10-01 21:44:33 --> Utf8 Class Initialized
DEBUG - 2011-10-01 21:44:33 --> UTF-8 Support Enabled
DEBUG - 2011-10-01 21:44:33 --> URI Class Initialized
DEBUG - 2011-10-01 21:44:33 --> Router Class Initialized
DEBUG - 2011-10-01 21:44:33 --> Output Class Initialized
DEBUG - 2011-10-01 21:44:33 --> Input Class Initialized
DEBUG - 2011-10-01 21:44:33 --> Global POST and COOKIE data sanitized
DEBUG - 2011-10-01 21:44:33 --> Language Class Initialized
DEBUG - 2011-10-01 21:44:33 --> Loader Class Initialized
DEBUG - 2011-10-01 21:44:33 --> Controller Class Initialized
DEBUG - 2011-10-01 21:44:33 --> Model Class Initialized
DEBUG - 2011-10-01 21:44:33 --> Model Class Initialized
DEBUG - 2011-10-01 21:44:33 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-10-01 21:44:33 --> Database Driver Class Initialized
DEBUG - 2011-10-01 21:44:34 --> Final output sent to browser
DEBUG - 2011-10-01 21:44:34 --> Total execution time: 0.6287
DEBUG - 2011-10-01 21:44:35 --> Config Class Initialized
DEBUG - 2011-10-01 21:44:35 --> Hooks Class Initialized
DEBUG - 2011-10-01 21:44:35 --> Utf8 Class Initialized
DEBUG - 2011-10-01 21:44:35 --> UTF-8 Support Enabled
DEBUG - 2011-10-01 21:44:35 --> URI Class Initialized
DEBUG - 2011-10-01 21:44:36 --> Router Class Initialized
ERROR - 2011-10-01 21:44:36 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-10-01 21:44:49 --> Config Class Initialized
DEBUG - 2011-10-01 21:44:49 --> Hooks Class Initialized
DEBUG - 2011-10-01 21:44:49 --> Utf8 Class Initialized
DEBUG - 2011-10-01 21:44:49 --> UTF-8 Support Enabled
DEBUG - 2011-10-01 21:44:49 --> URI Class Initialized
DEBUG - 2011-10-01 21:44:49 --> Router Class Initialized
DEBUG - 2011-10-01 21:44:49 --> Output Class Initialized
DEBUG - 2011-10-01 21:44:49 --> Input Class Initialized
DEBUG - 2011-10-01 21:44:49 --> Global POST and COOKIE data sanitized
DEBUG - 2011-10-01 21:44:49 --> Language Class Initialized
DEBUG - 2011-10-01 21:44:49 --> Loader Class Initialized
DEBUG - 2011-10-01 21:44:49 --> Controller Class Initialized
ERROR - 2011-10-01 21:44:49 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-10-01 21:44:49 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-10-01 21:44:49 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-10-01 21:44:49 --> Model Class Initialized
DEBUG - 2011-10-01 21:44:49 --> Model Class Initialized
DEBUG - 2011-10-01 21:44:49 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-10-01 21:44:49 --> Database Driver Class Initialized
DEBUG - 2011-10-01 21:44:49 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-10-01 21:44:49 --> Helper loaded: url_helper
DEBUG - 2011-10-01 21:44:49 --> File loaded: application/views/common/header.php
DEBUG - 2011-10-01 21:44:49 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-10-01 21:44:49 --> File loaded: application/views/common/footer.php
DEBUG - 2011-10-01 21:44:49 --> File loaded: application/views/layout/main.php
DEBUG - 2011-10-01 21:44:49 --> Final output sent to browser
DEBUG - 2011-10-01 21:44:49 --> Total execution time: 0.0441
DEBUG - 2011-10-01 21:44:49 --> Config Class Initialized
DEBUG - 2011-10-01 21:44:49 --> Hooks Class Initialized
DEBUG - 2011-10-01 21:44:49 --> Utf8 Class Initialized
DEBUG - 2011-10-01 21:44:49 --> UTF-8 Support Enabled
DEBUG - 2011-10-01 21:44:49 --> URI Class Initialized
DEBUG - 2011-10-01 21:44:49 --> Router Class Initialized
DEBUG - 2011-10-01 21:44:49 --> Output Class Initialized
DEBUG - 2011-10-01 21:44:49 --> Input Class Initialized
DEBUG - 2011-10-01 21:44:49 --> Global POST and COOKIE data sanitized
DEBUG - 2011-10-01 21:44:49 --> Language Class Initialized
DEBUG - 2011-10-01 21:44:49 --> Loader Class Initialized
DEBUG - 2011-10-01 21:44:49 --> Controller Class Initialized
DEBUG - 2011-10-01 21:44:49 --> Model Class Initialized
DEBUG - 2011-10-01 21:44:49 --> Model Class Initialized
DEBUG - 2011-10-01 21:44:49 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-10-01 21:44:49 --> Database Driver Class Initialized
DEBUG - 2011-10-01 21:44:50 --> Final output sent to browser
DEBUG - 2011-10-01 21:44:50 --> Total execution time: 0.5551
DEBUG - 2011-10-01 23:15:36 --> Config Class Initialized
DEBUG - 2011-10-01 23:15:36 --> Hooks Class Initialized
DEBUG - 2011-10-01 23:15:36 --> Utf8 Class Initialized
DEBUG - 2011-10-01 23:15:36 --> UTF-8 Support Enabled
DEBUG - 2011-10-01 23:15:36 --> URI Class Initialized
DEBUG - 2011-10-01 23:15:36 --> Router Class Initialized
DEBUG - 2011-10-01 23:15:36 --> Output Class Initialized
DEBUG - 2011-10-01 23:15:36 --> Input Class Initialized
DEBUG - 2011-10-01 23:15:36 --> Global POST and COOKIE data sanitized
DEBUG - 2011-10-01 23:15:36 --> Language Class Initialized
DEBUG - 2011-10-01 23:15:36 --> Loader Class Initialized
DEBUG - 2011-10-01 23:15:36 --> Controller Class Initialized
DEBUG - 2011-10-01 23:15:36 --> Model Class Initialized
DEBUG - 2011-10-01 23:15:36 --> Model Class Initialized
DEBUG - 2011-10-01 23:15:36 --> Model Class Initialized
DEBUG - 2011-10-01 23:15:36 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-10-01 23:15:36 --> Database Driver Class Initialized
DEBUG - 2011-10-01 23:15:37 --> File loaded: application/views/table/main.php
DEBUG - 2011-10-01 23:15:37 --> Helper loaded: url_helper
DEBUG - 2011-10-01 23:15:37 --> File loaded: application/views/common/header.php
DEBUG - 2011-10-01 23:15:37 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-10-01 23:15:37 --> File loaded: application/views/common/footer.php
DEBUG - 2011-10-01 23:15:37 --> File loaded: application/views/layout/main.php
DEBUG - 2011-10-01 23:15:37 --> Final output sent to browser
DEBUG - 2011-10-01 23:15:37 --> Total execution time: 0.8515
DEBUG - 2011-10-01 23:16:05 --> Config Class Initialized
DEBUG - 2011-10-01 23:16:05 --> Hooks Class Initialized
DEBUG - 2011-10-01 23:16:05 --> Utf8 Class Initialized
DEBUG - 2011-10-01 23:16:05 --> UTF-8 Support Enabled
DEBUG - 2011-10-01 23:16:05 --> URI Class Initialized
DEBUG - 2011-10-01 23:16:05 --> Router Class Initialized
DEBUG - 2011-10-01 23:16:05 --> Output Class Initialized
DEBUG - 2011-10-01 23:16:05 --> Input Class Initialized
DEBUG - 2011-10-01 23:16:05 --> Global POST and COOKIE data sanitized
DEBUG - 2011-10-01 23:16:05 --> Language Class Initialized
DEBUG - 2011-10-01 23:16:05 --> Loader Class Initialized
DEBUG - 2011-10-01 23:16:05 --> Controller Class Initialized
ERROR - 2011-10-01 23:16:05 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-10-01 23:16:05 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-10-01 23:16:05 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-10-01 23:16:05 --> Model Class Initialized
DEBUG - 2011-10-01 23:16:05 --> Model Class Initialized
DEBUG - 2011-10-01 23:16:05 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-10-01 23:16:05 --> Database Driver Class Initialized
DEBUG - 2011-10-01 23:16:05 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-10-01 23:16:05 --> Helper loaded: url_helper
DEBUG - 2011-10-01 23:16:05 --> File loaded: application/views/common/header.php
DEBUG - 2011-10-01 23:16:05 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-10-01 23:16:05 --> File loaded: application/views/common/footer.php
DEBUG - 2011-10-01 23:16:05 --> File loaded: application/views/layout/main.php
DEBUG - 2011-10-01 23:16:05 --> Final output sent to browser
DEBUG - 2011-10-01 23:16:05 --> Total execution time: 0.0346
DEBUG - 2011-10-01 23:16:48 --> Config Class Initialized
DEBUG - 2011-10-01 23:16:48 --> Hooks Class Initialized
DEBUG - 2011-10-01 23:16:48 --> Utf8 Class Initialized
DEBUG - 2011-10-01 23:16:48 --> UTF-8 Support Enabled
DEBUG - 2011-10-01 23:16:48 --> URI Class Initialized
DEBUG - 2011-10-01 23:16:48 --> Router Class Initialized
DEBUG - 2011-10-01 23:16:48 --> Output Class Initialized
DEBUG - 2011-10-01 23:16:48 --> Input Class Initialized
DEBUG - 2011-10-01 23:16:48 --> Global POST and COOKIE data sanitized
DEBUG - 2011-10-01 23:16:48 --> Language Class Initialized
DEBUG - 2011-10-01 23:16:48 --> Loader Class Initialized
DEBUG - 2011-10-01 23:16:48 --> Controller Class Initialized
ERROR - 2011-10-01 23:16:48 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-10-01 23:16:48 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-10-01 23:16:48 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-10-01 23:16:48 --> Model Class Initialized
DEBUG - 2011-10-01 23:16:48 --> Model Class Initialized
DEBUG - 2011-10-01 23:16:48 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-10-01 23:16:48 --> Database Driver Class Initialized
DEBUG - 2011-10-01 23:16:48 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-10-01 23:16:48 --> Helper loaded: url_helper
DEBUG - 2011-10-01 23:16:48 --> File loaded: application/views/common/header.php
DEBUG - 2011-10-01 23:16:48 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-10-01 23:16:48 --> File loaded: application/views/common/footer.php
DEBUG - 2011-10-01 23:16:48 --> File loaded: application/views/layout/main.php
DEBUG - 2011-10-01 23:16:48 --> Final output sent to browser
DEBUG - 2011-10-01 23:16:48 --> Total execution time: 0.0304
DEBUG - 2011-10-01 23:16:53 --> Config Class Initialized
DEBUG - 2011-10-01 23:16:53 --> Hooks Class Initialized
DEBUG - 2011-10-01 23:16:53 --> Utf8 Class Initialized
DEBUG - 2011-10-01 23:16:53 --> UTF-8 Support Enabled
DEBUG - 2011-10-01 23:16:53 --> URI Class Initialized
DEBUG - 2011-10-01 23:16:53 --> Router Class Initialized
DEBUG - 2011-10-01 23:16:53 --> Output Class Initialized
DEBUG - 2011-10-01 23:16:53 --> Input Class Initialized
DEBUG - 2011-10-01 23:16:53 --> Global POST and COOKIE data sanitized
DEBUG - 2011-10-01 23:16:53 --> Language Class Initialized
DEBUG - 2011-10-01 23:16:53 --> Loader Class Initialized
DEBUG - 2011-10-01 23:16:53 --> Controller Class Initialized
ERROR - 2011-10-01 23:16:53 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-10-01 23:16:53 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-10-01 23:16:53 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-10-01 23:16:53 --> Model Class Initialized
DEBUG - 2011-10-01 23:16:53 --> Model Class Initialized
DEBUG - 2011-10-01 23:16:53 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-10-01 23:16:53 --> Database Driver Class Initialized
DEBUG - 2011-10-01 23:16:53 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-10-01 23:16:53 --> Helper loaded: url_helper
DEBUG - 2011-10-01 23:16:53 --> File loaded: application/views/common/header.php
DEBUG - 2011-10-01 23:16:53 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-10-01 23:16:53 --> File loaded: application/views/common/footer.php
DEBUG - 2011-10-01 23:16:53 --> File loaded: application/views/layout/main.php
DEBUG - 2011-10-01 23:16:53 --> Final output sent to browser
DEBUG - 2011-10-01 23:16:53 --> Total execution time: 0.0312
DEBUG - 2011-10-01 23:18:27 --> Config Class Initialized
DEBUG - 2011-10-01 23:18:27 --> Hooks Class Initialized
DEBUG - 2011-10-01 23:18:27 --> Utf8 Class Initialized
DEBUG - 2011-10-01 23:18:27 --> UTF-8 Support Enabled
DEBUG - 2011-10-01 23:18:27 --> URI Class Initialized
DEBUG - 2011-10-01 23:18:27 --> Router Class Initialized
DEBUG - 2011-10-01 23:18:27 --> Output Class Initialized
DEBUG - 2011-10-01 23:18:27 --> Input Class Initialized
DEBUG - 2011-10-01 23:18:27 --> Global POST and COOKIE data sanitized
DEBUG - 2011-10-01 23:18:27 --> Language Class Initialized
DEBUG - 2011-10-01 23:18:27 --> Loader Class Initialized
DEBUG - 2011-10-01 23:18:27 --> Controller Class Initialized
DEBUG - 2011-10-01 23:18:27 --> Model Class Initialized
DEBUG - 2011-10-01 23:18:27 --> Model Class Initialized
DEBUG - 2011-10-01 23:18:27 --> Model Class Initialized
DEBUG - 2011-10-01 23:18:27 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-10-01 23:18:27 --> Database Driver Class Initialized
DEBUG - 2011-10-01 23:18:27 --> File loaded: application/views/table/main.php
DEBUG - 2011-10-01 23:18:27 --> Helper loaded: url_helper
DEBUG - 2011-10-01 23:18:27 --> File loaded: application/views/common/header.php
DEBUG - 2011-10-01 23:18:27 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-10-01 23:18:27 --> File loaded: application/views/common/footer.php
DEBUG - 2011-10-01 23:18:27 --> File loaded: application/views/layout/main.php
DEBUG - 2011-10-01 23:18:27 --> Final output sent to browser
DEBUG - 2011-10-01 23:18:27 --> Total execution time: 0.0551
DEBUG - 2011-10-01 23:18:35 --> Config Class Initialized
DEBUG - 2011-10-01 23:18:35 --> Hooks Class Initialized
DEBUG - 2011-10-01 23:18:35 --> Utf8 Class Initialized
DEBUG - 2011-10-01 23:18:35 --> UTF-8 Support Enabled
DEBUG - 2011-10-01 23:18:35 --> URI Class Initialized
DEBUG - 2011-10-01 23:18:35 --> Router Class Initialized
DEBUG - 2011-10-01 23:18:35 --> Output Class Initialized
DEBUG - 2011-10-01 23:18:35 --> Input Class Initialized
DEBUG - 2011-10-01 23:18:35 --> Global POST and COOKIE data sanitized
DEBUG - 2011-10-01 23:18:35 --> Language Class Initialized
DEBUG - 2011-10-01 23:18:35 --> Loader Class Initialized
DEBUG - 2011-10-01 23:18:35 --> Controller Class Initialized
ERROR - 2011-10-01 23:18:35 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-10-01 23:18:35 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-10-01 23:18:35 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-10-01 23:18:35 --> Model Class Initialized
DEBUG - 2011-10-01 23:18:35 --> Model Class Initialized
DEBUG - 2011-10-01 23:18:35 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-10-01 23:18:35 --> Database Driver Class Initialized
DEBUG - 2011-10-01 23:18:35 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-10-01 23:18:35 --> Helper loaded: url_helper
DEBUG - 2011-10-01 23:18:35 --> File loaded: application/views/common/header.php
DEBUG - 2011-10-01 23:18:35 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-10-01 23:18:35 --> File loaded: application/views/common/footer.php
DEBUG - 2011-10-01 23:18:35 --> File loaded: application/views/layout/main.php
DEBUG - 2011-10-01 23:18:35 --> Final output sent to browser
DEBUG - 2011-10-01 23:18:35 --> Total execution time: 0.0431

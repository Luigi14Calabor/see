<?php  if ( ! defined('BASEPATH')) exit('No direct script access allowed'); ?>

DEBUG - 2011-05-22 03:24:11 --> Config Class Initialized
DEBUG - 2011-05-22 03:24:11 --> Hooks Class Initialized
DEBUG - 2011-05-22 03:24:11 --> Utf8 Class Initialized
DEBUG - 2011-05-22 03:24:11 --> UTF-8 Support Enabled
DEBUG - 2011-05-22 03:24:11 --> URI Class Initialized
DEBUG - 2011-05-22 03:24:11 --> Router Class Initialized
DEBUG - 2011-05-22 03:24:11 --> Output Class Initialized
DEBUG - 2011-05-22 03:24:11 --> Input Class Initialized
DEBUG - 2011-05-22 03:24:11 --> Global POST and COOKIE data sanitized
DEBUG - 2011-05-22 03:24:11 --> Language Class Initialized
DEBUG - 2011-05-22 03:24:11 --> Loader Class Initialized
DEBUG - 2011-05-22 03:24:11 --> Controller Class Initialized
DEBUG - 2011-05-22 03:24:11 --> Model Class Initialized
DEBUG - 2011-05-22 03:24:11 --> Model Class Initialized
DEBUG - 2011-05-22 03:24:11 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-05-22 03:24:11 --> Database Driver Class Initialized
DEBUG - 2011-05-22 03:24:12 --> Final output sent to browser
DEBUG - 2011-05-22 03:24:12 --> Total execution time: 1.4015
DEBUG - 2011-05-22 05:50:28 --> Config Class Initialized
DEBUG - 2011-05-22 05:50:28 --> Hooks Class Initialized
DEBUG - 2011-05-22 05:50:28 --> Utf8 Class Initialized
DEBUG - 2011-05-22 05:50:28 --> UTF-8 Support Enabled
DEBUG - 2011-05-22 05:50:28 --> URI Class Initialized
DEBUG - 2011-05-22 05:50:28 --> Router Class Initialized
DEBUG - 2011-05-22 05:50:28 --> No URI present. Default controller set.
DEBUG - 2011-05-22 05:50:28 --> Output Class Initialized
DEBUG - 2011-05-22 05:50:28 --> Input Class Initialized
DEBUG - 2011-05-22 05:50:28 --> Global POST and COOKIE data sanitized
DEBUG - 2011-05-22 05:50:28 --> Language Class Initialized
DEBUG - 2011-05-22 05:50:28 --> Loader Class Initialized
DEBUG - 2011-05-22 05:50:28 --> Controller Class Initialized
DEBUG - 2011-05-22 05:50:28 --> File loaded: application/views/splash/main.php
DEBUG - 2011-05-22 05:50:29 --> Helper loaded: url_helper
DEBUG - 2011-05-22 05:50:29 --> File loaded: application/views/common/header.php
DEBUG - 2011-05-22 05:50:29 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-05-22 05:50:29 --> File loaded: application/views/common/footer.php
DEBUG - 2011-05-22 05:50:29 --> File loaded: application/views/layout/main.php
DEBUG - 2011-05-22 05:50:29 --> Final output sent to browser
DEBUG - 2011-05-22 05:50:29 --> Total execution time: 0.7308
DEBUG - 2011-05-22 05:50:36 --> Config Class Initialized
DEBUG - 2011-05-22 05:50:36 --> Hooks Class Initialized
DEBUG - 2011-05-22 05:50:36 --> Utf8 Class Initialized
DEBUG - 2011-05-22 05:50:36 --> UTF-8 Support Enabled
DEBUG - 2011-05-22 05:50:36 --> URI Class Initialized
DEBUG - 2011-05-22 05:50:36 --> Router Class Initialized
ERROR - 2011-05-22 05:50:36 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-05-22 05:51:04 --> Config Class Initialized
DEBUG - 2011-05-22 05:51:04 --> Hooks Class Initialized
DEBUG - 2011-05-22 05:51:04 --> Utf8 Class Initialized
DEBUG - 2011-05-22 05:51:04 --> UTF-8 Support Enabled
DEBUG - 2011-05-22 05:51:04 --> URI Class Initialized
DEBUG - 2011-05-22 05:51:04 --> Router Class Initialized
DEBUG - 2011-05-22 05:51:04 --> Output Class Initialized
DEBUG - 2011-05-22 05:51:04 --> Input Class Initialized
DEBUG - 2011-05-22 05:51:04 --> Global POST and COOKIE data sanitized
DEBUG - 2011-05-22 05:51:04 --> Language Class Initialized
DEBUG - 2011-05-22 05:51:04 --> Loader Class Initialized
DEBUG - 2011-05-22 05:51:04 --> Controller Class Initialized
DEBUG - 2011-05-22 05:51:05 --> Model Class Initialized
DEBUG - 2011-05-22 05:51:06 --> Model Class Initialized
DEBUG - 2011-05-22 05:51:06 --> Model Class Initialized
DEBUG - 2011-05-22 05:51:06 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-05-22 05:51:07 --> Database Driver Class Initialized
DEBUG - 2011-05-22 05:51:08 --> File loaded: application/views/table/main.php
DEBUG - 2011-05-22 05:51:08 --> Helper loaded: url_helper
DEBUG - 2011-05-22 05:51:08 --> File loaded: application/views/common/header.php
DEBUG - 2011-05-22 05:51:08 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-05-22 05:51:08 --> File loaded: application/views/common/footer.php
DEBUG - 2011-05-22 05:51:08 --> File loaded: application/views/layout/main.php
DEBUG - 2011-05-22 05:51:08 --> Final output sent to browser
DEBUG - 2011-05-22 05:51:08 --> Total execution time: 4.1534
DEBUG - 2011-05-22 05:51:11 --> Config Class Initialized
DEBUG - 2011-05-22 05:51:11 --> Hooks Class Initialized
DEBUG - 2011-05-22 05:51:11 --> Utf8 Class Initialized
DEBUG - 2011-05-22 05:51:11 --> UTF-8 Support Enabled
DEBUG - 2011-05-22 05:51:11 --> URI Class Initialized
DEBUG - 2011-05-22 05:51:11 --> Router Class Initialized
ERROR - 2011-05-22 05:51:11 --> 404 Page Not Found --> robots.txt
DEBUG - 2011-05-22 05:51:11 --> Config Class Initialized
DEBUG - 2011-05-22 05:51:11 --> Hooks Class Initialized
DEBUG - 2011-05-22 05:51:11 --> Utf8 Class Initialized
DEBUG - 2011-05-22 05:51:11 --> UTF-8 Support Enabled
DEBUG - 2011-05-22 05:51:11 --> URI Class Initialized
DEBUG - 2011-05-22 05:51:11 --> Router Class Initialized
ERROR - 2011-05-22 05:51:11 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-05-22 05:51:11 --> Config Class Initialized
DEBUG - 2011-05-22 05:51:11 --> Hooks Class Initialized
DEBUG - 2011-05-22 05:51:11 --> Utf8 Class Initialized
DEBUG - 2011-05-22 05:51:11 --> UTF-8 Support Enabled
DEBUG - 2011-05-22 05:51:11 --> URI Class Initialized
DEBUG - 2011-05-22 05:51:11 --> Router Class Initialized
DEBUG - 2011-05-22 05:51:11 --> Output Class Initialized
DEBUG - 2011-05-22 05:51:11 --> Input Class Initialized
DEBUG - 2011-05-22 05:51:11 --> Global POST and COOKIE data sanitized
DEBUG - 2011-05-22 05:51:11 --> Language Class Initialized
DEBUG - 2011-05-22 05:51:11 --> Loader Class Initialized
DEBUG - 2011-05-22 05:51:11 --> Controller Class Initialized
DEBUG - 2011-05-22 05:51:11 --> Model Class Initialized
DEBUG - 2011-05-22 05:51:11 --> Model Class Initialized
DEBUG - 2011-05-22 05:51:11 --> Model Class Initialized
DEBUG - 2011-05-22 05:51:11 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-05-22 05:51:11 --> Database Driver Class Initialized
DEBUG - 2011-05-22 05:51:11 --> File loaded: application/views/table/main.php
DEBUG - 2011-05-22 05:51:11 --> Helper loaded: url_helper
DEBUG - 2011-05-22 05:51:11 --> File loaded: application/views/common/header.php
DEBUG - 2011-05-22 05:51:11 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-05-22 05:51:11 --> File loaded: application/views/common/footer.php
DEBUG - 2011-05-22 05:51:11 --> File loaded: application/views/layout/main.php
DEBUG - 2011-05-22 05:51:11 --> Final output sent to browser
DEBUG - 2011-05-22 05:51:11 --> Total execution time: 0.0475
DEBUG - 2011-05-22 05:51:19 --> Config Class Initialized
DEBUG - 2011-05-22 05:51:19 --> Hooks Class Initialized
DEBUG - 2011-05-22 05:51:19 --> Utf8 Class Initialized
DEBUG - 2011-05-22 05:51:19 --> UTF-8 Support Enabled
DEBUG - 2011-05-22 05:51:19 --> URI Class Initialized
DEBUG - 2011-05-22 05:51:19 --> Router Class Initialized
DEBUG - 2011-05-22 05:51:19 --> Output Class Initialized
DEBUG - 2011-05-22 05:51:19 --> Input Class Initialized
DEBUG - 2011-05-22 05:51:19 --> Global POST and COOKIE data sanitized
DEBUG - 2011-05-22 05:51:19 --> Language Class Initialized
DEBUG - 2011-05-22 05:51:19 --> Loader Class Initialized
DEBUG - 2011-05-22 05:51:19 --> Controller Class Initialized
DEBUG - 2011-05-22 05:51:19 --> Model Class Initialized
DEBUG - 2011-05-22 05:51:19 --> Model Class Initialized
DEBUG - 2011-05-22 05:51:19 --> Model Class Initialized
DEBUG - 2011-05-22 05:51:19 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-05-22 05:51:19 --> Database Driver Class Initialized
DEBUG - 2011-05-22 05:51:19 --> File loaded: application/views/table/main.php
DEBUG - 2011-05-22 05:51:19 --> Helper loaded: url_helper
DEBUG - 2011-05-22 05:51:19 --> File loaded: application/views/common/header.php
DEBUG - 2011-05-22 05:51:19 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-05-22 05:51:19 --> File loaded: application/views/common/footer.php
DEBUG - 2011-05-22 05:51:19 --> File loaded: application/views/layout/main.php
DEBUG - 2011-05-22 05:51:19 --> Final output sent to browser
DEBUG - 2011-05-22 05:51:19 --> Total execution time: 0.3562
DEBUG - 2011-05-22 05:51:23 --> Config Class Initialized
DEBUG - 2011-05-22 05:51:23 --> Hooks Class Initialized
DEBUG - 2011-05-22 05:51:23 --> Utf8 Class Initialized
DEBUG - 2011-05-22 05:51:23 --> UTF-8 Support Enabled
DEBUG - 2011-05-22 05:51:23 --> URI Class Initialized
DEBUG - 2011-05-22 05:51:23 --> Router Class Initialized
ERROR - 2011-05-22 05:51:23 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-05-22 05:51:49 --> Config Class Initialized
DEBUG - 2011-05-22 05:51:49 --> Hooks Class Initialized
DEBUG - 2011-05-22 05:51:49 --> Utf8 Class Initialized
DEBUG - 2011-05-22 05:51:49 --> UTF-8 Support Enabled
DEBUG - 2011-05-22 05:51:49 --> URI Class Initialized
DEBUG - 2011-05-22 05:51:49 --> Router Class Initialized
DEBUG - 2011-05-22 05:51:49 --> Output Class Initialized
DEBUG - 2011-05-22 05:51:49 --> Input Class Initialized
DEBUG - 2011-05-22 05:51:49 --> Global POST and COOKIE data sanitized
DEBUG - 2011-05-22 05:51:49 --> Language Class Initialized
DEBUG - 2011-05-22 05:51:49 --> Loader Class Initialized
DEBUG - 2011-05-22 05:51:49 --> Controller Class Initialized
DEBUG - 2011-05-22 05:51:49 --> Model Class Initialized
DEBUG - 2011-05-22 05:51:49 --> Model Class Initialized
DEBUG - 2011-05-22 05:51:49 --> Model Class Initialized
DEBUG - 2011-05-22 05:51:49 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-05-22 05:51:49 --> Database Driver Class Initialized
DEBUG - 2011-05-22 05:51:49 --> File loaded: application/views/table/main.php
DEBUG - 2011-05-22 05:51:49 --> Helper loaded: url_helper
DEBUG - 2011-05-22 05:51:49 --> File loaded: application/views/common/header.php
DEBUG - 2011-05-22 05:51:49 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-05-22 05:51:49 --> File loaded: application/views/common/footer.php
DEBUG - 2011-05-22 05:51:49 --> File loaded: application/views/layout/main.php
DEBUG - 2011-05-22 05:51:49 --> Final output sent to browser
DEBUG - 2011-05-22 05:51:49 --> Total execution time: 0.0509
DEBUG - 2011-05-22 05:51:51 --> Config Class Initialized
DEBUG - 2011-05-22 05:51:51 --> Hooks Class Initialized
DEBUG - 2011-05-22 05:51:51 --> Utf8 Class Initialized
DEBUG - 2011-05-22 05:51:51 --> UTF-8 Support Enabled
DEBUG - 2011-05-22 05:51:51 --> URI Class Initialized
DEBUG - 2011-05-22 05:51:51 --> Router Class Initialized
ERROR - 2011-05-22 05:51:51 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-05-22 05:51:53 --> Config Class Initialized
DEBUG - 2011-05-22 05:51:53 --> Hooks Class Initialized
DEBUG - 2011-05-22 05:51:53 --> Utf8 Class Initialized
DEBUG - 2011-05-22 05:51:53 --> UTF-8 Support Enabled
DEBUG - 2011-05-22 05:51:53 --> URI Class Initialized
DEBUG - 2011-05-22 05:51:53 --> Router Class Initialized
DEBUG - 2011-05-22 05:51:53 --> Output Class Initialized
DEBUG - 2011-05-22 05:51:53 --> Input Class Initialized
DEBUG - 2011-05-22 05:51:53 --> Global POST and COOKIE data sanitized
DEBUG - 2011-05-22 05:51:53 --> Language Class Initialized
DEBUG - 2011-05-22 05:51:53 --> Loader Class Initialized
DEBUG - 2011-05-22 05:51:53 --> Controller Class Initialized
DEBUG - 2011-05-22 05:51:53 --> Model Class Initialized
DEBUG - 2011-05-22 05:51:53 --> Model Class Initialized
DEBUG - 2011-05-22 05:51:53 --> Model Class Initialized
DEBUG - 2011-05-22 05:51:53 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-05-22 05:51:53 --> Database Driver Class Initialized
DEBUG - 2011-05-22 05:51:53 --> File loaded: application/views/table/main.php
DEBUG - 2011-05-22 05:51:53 --> Helper loaded: url_helper
DEBUG - 2011-05-22 05:51:53 --> File loaded: application/views/common/header.php
DEBUG - 2011-05-22 05:51:53 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-05-22 05:51:53 --> File loaded: application/views/common/footer.php
DEBUG - 2011-05-22 05:51:53 --> File loaded: application/views/layout/main.php
DEBUG - 2011-05-22 05:51:53 --> Final output sent to browser
DEBUG - 2011-05-22 05:51:53 --> Total execution time: 0.0471
DEBUG - 2011-05-22 05:51:58 --> Config Class Initialized
DEBUG - 2011-05-22 05:51:58 --> Hooks Class Initialized
DEBUG - 2011-05-22 05:51:58 --> Utf8 Class Initialized
DEBUG - 2011-05-22 05:51:58 --> UTF-8 Support Enabled
DEBUG - 2011-05-22 05:51:58 --> URI Class Initialized
DEBUG - 2011-05-22 05:51:58 --> Router Class Initialized
DEBUG - 2011-05-22 05:51:58 --> Output Class Initialized
DEBUG - 2011-05-22 05:51:58 --> Input Class Initialized
DEBUG - 2011-05-22 05:51:58 --> Global POST and COOKIE data sanitized
DEBUG - 2011-05-22 05:51:58 --> Language Class Initialized
DEBUG - 2011-05-22 05:51:58 --> Loader Class Initialized
DEBUG - 2011-05-22 05:51:58 --> Controller Class Initialized
DEBUG - 2011-05-22 05:51:58 --> Model Class Initialized
DEBUG - 2011-05-22 05:51:58 --> Model Class Initialized
DEBUG - 2011-05-22 05:51:58 --> Model Class Initialized
DEBUG - 2011-05-22 05:51:58 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-05-22 05:51:58 --> Database Driver Class Initialized
DEBUG - 2011-05-22 05:51:58 --> File loaded: application/views/table/main.php
DEBUG - 2011-05-22 05:51:58 --> Helper loaded: url_helper
DEBUG - 2011-05-22 05:51:58 --> File loaded: application/views/common/header.php
DEBUG - 2011-05-22 05:51:58 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-05-22 05:51:58 --> File loaded: application/views/common/footer.php
DEBUG - 2011-05-22 05:51:58 --> File loaded: application/views/layout/main.php
DEBUG - 2011-05-22 05:51:58 --> Final output sent to browser
DEBUG - 2011-05-22 05:51:58 --> Total execution time: 0.3216
DEBUG - 2011-05-22 05:51:59 --> Config Class Initialized
DEBUG - 2011-05-22 05:51:59 --> Hooks Class Initialized
DEBUG - 2011-05-22 05:51:59 --> Utf8 Class Initialized
DEBUG - 2011-05-22 05:51:59 --> UTF-8 Support Enabled
DEBUG - 2011-05-22 05:51:59 --> URI Class Initialized
DEBUG - 2011-05-22 05:51:59 --> Router Class Initialized
DEBUG - 2011-05-22 05:51:59 --> Output Class Initialized
DEBUG - 2011-05-22 05:51:59 --> Input Class Initialized
DEBUG - 2011-05-22 05:51:59 --> Global POST and COOKIE data sanitized
DEBUG - 2011-05-22 05:51:59 --> Language Class Initialized
DEBUG - 2011-05-22 05:51:59 --> Loader Class Initialized
DEBUG - 2011-05-22 05:51:59 --> Controller Class Initialized
DEBUG - 2011-05-22 05:51:59 --> Model Class Initialized
DEBUG - 2011-05-22 05:51:59 --> Model Class Initialized
DEBUG - 2011-05-22 05:51:59 --> Model Class Initialized
DEBUG - 2011-05-22 05:51:59 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-05-22 05:51:59 --> Database Driver Class Initialized
DEBUG - 2011-05-22 05:51:59 --> File loaded: application/views/table/main.php
DEBUG - 2011-05-22 05:51:59 --> Helper loaded: url_helper
DEBUG - 2011-05-22 05:51:59 --> File loaded: application/views/common/header.php
DEBUG - 2011-05-22 05:51:59 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-05-22 05:51:59 --> File loaded: application/views/common/footer.php
DEBUG - 2011-05-22 05:51:59 --> File loaded: application/views/layout/main.php
DEBUG - 2011-05-22 05:51:59 --> Final output sent to browser
DEBUG - 2011-05-22 05:51:59 --> Total execution time: 0.0493
DEBUG - 2011-05-22 05:52:00 --> Config Class Initialized
DEBUG - 2011-05-22 05:52:00 --> Hooks Class Initialized
DEBUG - 2011-05-22 05:52:00 --> Utf8 Class Initialized
DEBUG - 2011-05-22 05:52:00 --> UTF-8 Support Enabled
DEBUG - 2011-05-22 05:52:00 --> URI Class Initialized
DEBUG - 2011-05-22 05:52:00 --> Router Class Initialized
ERROR - 2011-05-22 05:52:00 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-05-22 05:52:03 --> Config Class Initialized
DEBUG - 2011-05-22 05:52:03 --> Hooks Class Initialized
DEBUG - 2011-05-22 05:52:03 --> Utf8 Class Initialized
DEBUG - 2011-05-22 05:52:03 --> UTF-8 Support Enabled
DEBUG - 2011-05-22 05:52:03 --> URI Class Initialized
DEBUG - 2011-05-22 05:52:03 --> Router Class Initialized
DEBUG - 2011-05-22 05:52:03 --> Output Class Initialized
DEBUG - 2011-05-22 05:52:03 --> Input Class Initialized
DEBUG - 2011-05-22 05:52:03 --> Global POST and COOKIE data sanitized
DEBUG - 2011-05-22 05:52:03 --> Language Class Initialized
DEBUG - 2011-05-22 05:52:03 --> Loader Class Initialized
DEBUG - 2011-05-22 05:52:03 --> Controller Class Initialized
DEBUG - 2011-05-22 05:52:03 --> Model Class Initialized
DEBUG - 2011-05-22 05:52:03 --> Model Class Initialized
DEBUG - 2011-05-22 05:52:03 --> Model Class Initialized
DEBUG - 2011-05-22 05:52:03 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-05-22 05:52:03 --> Database Driver Class Initialized
DEBUG - 2011-05-22 05:52:03 --> File loaded: application/views/table/main.php
DEBUG - 2011-05-22 05:52:03 --> Helper loaded: url_helper
DEBUG - 2011-05-22 05:52:03 --> File loaded: application/views/common/header.php
DEBUG - 2011-05-22 05:52:03 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-05-22 05:52:03 --> File loaded: application/views/common/footer.php
DEBUG - 2011-05-22 05:52:03 --> File loaded: application/views/layout/main.php
DEBUG - 2011-05-22 05:52:03 --> Final output sent to browser
DEBUG - 2011-05-22 05:52:03 --> Total execution time: 0.0467
DEBUG - 2011-05-22 06:04:28 --> Config Class Initialized
DEBUG - 2011-05-22 06:04:28 --> Hooks Class Initialized
DEBUG - 2011-05-22 06:04:28 --> Utf8 Class Initialized
DEBUG - 2011-05-22 06:04:28 --> UTF-8 Support Enabled
DEBUG - 2011-05-22 06:04:28 --> URI Class Initialized
DEBUG - 2011-05-22 06:04:28 --> Router Class Initialized
DEBUG - 2011-05-22 06:04:28 --> Output Class Initialized
DEBUG - 2011-05-22 06:04:28 --> Input Class Initialized
DEBUG - 2011-05-22 06:04:28 --> Global POST and COOKIE data sanitized
DEBUG - 2011-05-22 06:04:28 --> Language Class Initialized
DEBUG - 2011-05-22 06:04:28 --> Loader Class Initialized
DEBUG - 2011-05-22 06:04:28 --> Controller Class Initialized
DEBUG - 2011-05-22 06:04:28 --> Model Class Initialized
DEBUG - 2011-05-22 06:04:28 --> Model Class Initialized
DEBUG - 2011-05-22 06:04:28 --> Model Class Initialized
DEBUG - 2011-05-22 06:04:28 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-05-22 06:04:28 --> Database Driver Class Initialized
DEBUG - 2011-05-22 06:04:28 --> File loaded: application/views/table/main.php
DEBUG - 2011-05-22 06:04:28 --> Helper loaded: url_helper
DEBUG - 2011-05-22 06:04:28 --> File loaded: application/views/common/header.php
DEBUG - 2011-05-22 06:04:28 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-05-22 06:04:28 --> File loaded: application/views/common/footer.php
DEBUG - 2011-05-22 06:04:28 --> File loaded: application/views/layout/main.php
DEBUG - 2011-05-22 06:04:28 --> Final output sent to browser
DEBUG - 2011-05-22 06:04:28 --> Total execution time: 0.2444
DEBUG - 2011-05-22 06:37:47 --> Config Class Initialized
DEBUG - 2011-05-22 06:37:47 --> Hooks Class Initialized
DEBUG - 2011-05-22 06:37:47 --> Utf8 Class Initialized
DEBUG - 2011-05-22 06:37:47 --> UTF-8 Support Enabled
DEBUG - 2011-05-22 06:37:47 --> URI Class Initialized
DEBUG - 2011-05-22 06:37:47 --> Router Class Initialized
DEBUG - 2011-05-22 06:37:47 --> Output Class Initialized
DEBUG - 2011-05-22 06:37:47 --> Input Class Initialized
DEBUG - 2011-05-22 06:37:47 --> Global POST and COOKIE data sanitized
DEBUG - 2011-05-22 06:37:47 --> Language Class Initialized
DEBUG - 2011-05-22 06:37:47 --> Loader Class Initialized
DEBUG - 2011-05-22 06:37:47 --> Controller Class Initialized
DEBUG - 2011-05-22 06:37:47 --> Model Class Initialized
DEBUG - 2011-05-22 06:37:47 --> Model Class Initialized
DEBUG - 2011-05-22 06:37:47 --> Model Class Initialized
DEBUG - 2011-05-22 06:37:47 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-05-22 06:37:47 --> Database Driver Class Initialized
DEBUG - 2011-05-22 06:37:48 --> File loaded: application/views/table/main.php
DEBUG - 2011-05-22 06:37:48 --> Helper loaded: url_helper
DEBUG - 2011-05-22 06:37:48 --> File loaded: application/views/common/header.php
DEBUG - 2011-05-22 06:37:48 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-05-22 06:37:48 --> File loaded: application/views/common/footer.php
DEBUG - 2011-05-22 06:37:48 --> File loaded: application/views/layout/main.php
DEBUG - 2011-05-22 06:37:48 --> Final output sent to browser
DEBUG - 2011-05-22 06:37:48 --> Total execution time: 0.5991
DEBUG - 2011-05-22 06:37:48 --> Config Class Initialized
DEBUG - 2011-05-22 06:37:48 --> Hooks Class Initialized
DEBUG - 2011-05-22 06:37:48 --> Utf8 Class Initialized
DEBUG - 2011-05-22 06:37:48 --> UTF-8 Support Enabled
DEBUG - 2011-05-22 06:37:48 --> URI Class Initialized
DEBUG - 2011-05-22 06:37:48 --> Router Class Initialized
DEBUG - 2011-05-22 06:37:48 --> Output Class Initialized
DEBUG - 2011-05-22 06:37:48 --> Input Class Initialized
DEBUG - 2011-05-22 06:37:48 --> Global POST and COOKIE data sanitized
DEBUG - 2011-05-22 06:37:48 --> Language Class Initialized
DEBUG - 2011-05-22 06:37:48 --> Loader Class Initialized
DEBUG - 2011-05-22 06:37:48 --> Controller Class Initialized
ERROR - 2011-05-22 06:37:48 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-05-22 06:37:48 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-05-22 06:37:48 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-05-22 06:37:48 --> Model Class Initialized
DEBUG - 2011-05-22 06:37:48 --> Model Class Initialized
DEBUG - 2011-05-22 06:37:48 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-05-22 06:37:48 --> Database Driver Class Initialized
DEBUG - 2011-05-22 06:37:48 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-05-22 06:37:49 --> Helper loaded: url_helper
DEBUG - 2011-05-22 06:37:49 --> File loaded: application/views/common/header.php
DEBUG - 2011-05-22 06:37:49 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-05-22 06:37:49 --> File loaded: application/views/common/footer.php
DEBUG - 2011-05-22 06:37:49 --> File loaded: application/views/layout/main.php
DEBUG - 2011-05-22 06:37:49 --> Final output sent to browser
DEBUG - 2011-05-22 06:37:49 --> Total execution time: 0.0819
DEBUG - 2011-05-22 08:37:15 --> Config Class Initialized
DEBUG - 2011-05-22 08:37:15 --> Hooks Class Initialized
DEBUG - 2011-05-22 08:37:15 --> Utf8 Class Initialized
DEBUG - 2011-05-22 08:37:15 --> UTF-8 Support Enabled
DEBUG - 2011-05-22 08:37:15 --> URI Class Initialized
DEBUG - 2011-05-22 08:37:15 --> Router Class Initialized
ERROR - 2011-05-22 08:37:15 --> 404 Page Not Found --> robots.txt
DEBUG - 2011-05-22 08:52:23 --> Config Class Initialized
DEBUG - 2011-05-22 08:52:23 --> Hooks Class Initialized
DEBUG - 2011-05-22 08:52:23 --> Utf8 Class Initialized
DEBUG - 2011-05-22 08:52:23 --> UTF-8 Support Enabled
DEBUG - 2011-05-22 08:52:23 --> URI Class Initialized
DEBUG - 2011-05-22 08:52:23 --> Router Class Initialized
DEBUG - 2011-05-22 08:52:23 --> Output Class Initialized
DEBUG - 2011-05-22 08:52:23 --> Input Class Initialized
DEBUG - 2011-05-22 08:52:23 --> Global POST and COOKIE data sanitized
DEBUG - 2011-05-22 08:52:23 --> Language Class Initialized
DEBUG - 2011-05-22 08:52:23 --> Loader Class Initialized
DEBUG - 2011-05-22 08:52:23 --> Controller Class Initialized
ERROR - 2011-05-22 08:52:23 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-05-22 08:52:23 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-05-22 08:52:23 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-05-22 08:52:23 --> Model Class Initialized
DEBUG - 2011-05-22 08:52:23 --> Model Class Initialized
DEBUG - 2011-05-22 08:52:23 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-05-22 08:52:23 --> Database Driver Class Initialized
DEBUG - 2011-05-22 08:52:23 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-05-22 08:52:23 --> Helper loaded: url_helper
DEBUG - 2011-05-22 08:52:23 --> File loaded: application/views/common/header.php
DEBUG - 2011-05-22 08:52:23 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-05-22 08:52:23 --> File loaded: application/views/common/footer.php
DEBUG - 2011-05-22 08:52:23 --> File loaded: application/views/layout/main.php
DEBUG - 2011-05-22 08:52:23 --> Final output sent to browser
DEBUG - 2011-05-22 08:52:23 --> Total execution time: 0.3163
DEBUG - 2011-05-22 08:52:31 --> Config Class Initialized
DEBUG - 2011-05-22 08:52:31 --> Hooks Class Initialized
DEBUG - 2011-05-22 08:52:31 --> Utf8 Class Initialized
DEBUG - 2011-05-22 08:52:31 --> UTF-8 Support Enabled
DEBUG - 2011-05-22 08:52:31 --> URI Class Initialized
DEBUG - 2011-05-22 08:52:31 --> Router Class Initialized
ERROR - 2011-05-22 08:52:31 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-05-22 08:52:44 --> Config Class Initialized
DEBUG - 2011-05-22 08:52:44 --> Hooks Class Initialized
DEBUG - 2011-05-22 08:52:44 --> Utf8 Class Initialized
DEBUG - 2011-05-22 08:52:44 --> UTF-8 Support Enabled
DEBUG - 2011-05-22 08:52:44 --> URI Class Initialized
DEBUG - 2011-05-22 08:52:44 --> Router Class Initialized
DEBUG - 2011-05-22 08:52:44 --> Output Class Initialized
DEBUG - 2011-05-22 08:52:44 --> Input Class Initialized
DEBUG - 2011-05-22 08:52:44 --> Global POST and COOKIE data sanitized
DEBUG - 2011-05-22 08:52:44 --> Language Class Initialized
DEBUG - 2011-05-22 08:52:44 --> Loader Class Initialized
DEBUG - 2011-05-22 08:52:44 --> Controller Class Initialized
DEBUG - 2011-05-22 08:52:44 --> Model Class Initialized
DEBUG - 2011-05-22 08:52:44 --> Model Class Initialized
DEBUG - 2011-05-22 08:52:44 --> Model Class Initialized
DEBUG - 2011-05-22 08:52:44 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-05-22 08:52:44 --> Database Driver Class Initialized
DEBUG - 2011-05-22 08:52:45 --> File loaded: application/views/table/main.php
DEBUG - 2011-05-22 08:52:45 --> Helper loaded: url_helper
DEBUG - 2011-05-22 08:52:45 --> File loaded: application/views/common/header.php
DEBUG - 2011-05-22 08:52:45 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-05-22 08:52:45 --> File loaded: application/views/common/footer.php
DEBUG - 2011-05-22 08:52:45 --> File loaded: application/views/layout/main.php
DEBUG - 2011-05-22 08:52:45 --> Final output sent to browser
DEBUG - 2011-05-22 08:52:45 --> Total execution time: 0.3523
DEBUG - 2011-05-22 08:52:51 --> Config Class Initialized
DEBUG - 2011-05-22 08:52:51 --> Hooks Class Initialized
DEBUG - 2011-05-22 08:52:51 --> Utf8 Class Initialized
DEBUG - 2011-05-22 08:52:51 --> UTF-8 Support Enabled
DEBUG - 2011-05-22 08:52:51 --> URI Class Initialized
DEBUG - 2011-05-22 08:52:51 --> Router Class Initialized
DEBUG - 2011-05-22 08:52:51 --> No URI present. Default controller set.
DEBUG - 2011-05-22 08:52:51 --> Output Class Initialized
DEBUG - 2011-05-22 08:52:51 --> Input Class Initialized
DEBUG - 2011-05-22 08:52:51 --> Global POST and COOKIE data sanitized
DEBUG - 2011-05-22 08:52:51 --> Language Class Initialized
DEBUG - 2011-05-22 08:52:51 --> Loader Class Initialized
DEBUG - 2011-05-22 08:52:51 --> Controller Class Initialized
DEBUG - 2011-05-22 08:52:51 --> File loaded: application/views/splash/main.php
DEBUG - 2011-05-22 08:52:51 --> Helper loaded: url_helper
DEBUG - 2011-05-22 08:52:51 --> File loaded: application/views/common/header.php
DEBUG - 2011-05-22 08:52:51 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-05-22 08:52:51 --> File loaded: application/views/common/footer.php
DEBUG - 2011-05-22 08:52:51 --> File loaded: application/views/layout/main.php
DEBUG - 2011-05-22 08:52:51 --> Final output sent to browser
DEBUG - 2011-05-22 08:52:51 --> Total execution time: 0.0625
DEBUG - 2011-05-22 09:46:00 --> Config Class Initialized
DEBUG - 2011-05-22 09:46:00 --> Hooks Class Initialized
DEBUG - 2011-05-22 09:46:00 --> Utf8 Class Initialized
DEBUG - 2011-05-22 09:46:00 --> UTF-8 Support Enabled
DEBUG - 2011-05-22 09:46:00 --> URI Class Initialized
DEBUG - 2011-05-22 09:46:00 --> Router Class Initialized
DEBUG - 2011-05-22 09:46:00 --> No URI present. Default controller set.
DEBUG - 2011-05-22 09:46:00 --> Output Class Initialized
DEBUG - 2011-05-22 09:46:00 --> Input Class Initialized
DEBUG - 2011-05-22 09:46:00 --> Global POST and COOKIE data sanitized
DEBUG - 2011-05-22 09:46:00 --> Language Class Initialized
DEBUG - 2011-05-22 09:46:00 --> Loader Class Initialized
DEBUG - 2011-05-22 09:46:00 --> Controller Class Initialized
DEBUG - 2011-05-22 09:46:01 --> File loaded: application/views/splash/main.php
DEBUG - 2011-05-22 09:46:01 --> Helper loaded: url_helper
DEBUG - 2011-05-22 09:46:01 --> File loaded: application/views/common/header.php
DEBUG - 2011-05-22 09:46:01 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-05-22 09:46:01 --> File loaded: application/views/common/footer.php
DEBUG - 2011-05-22 09:46:01 --> File loaded: application/views/layout/main.php
DEBUG - 2011-05-22 09:46:01 --> Final output sent to browser
DEBUG - 2011-05-22 09:46:01 --> Total execution time: 0.6285
DEBUG - 2011-05-22 10:00:03 --> Config Class Initialized
DEBUG - 2011-05-22 10:00:03 --> Hooks Class Initialized
DEBUG - 2011-05-22 10:00:03 --> Utf8 Class Initialized
DEBUG - 2011-05-22 10:00:03 --> UTF-8 Support Enabled
DEBUG - 2011-05-22 10:00:03 --> URI Class Initialized
DEBUG - 2011-05-22 10:00:03 --> Router Class Initialized
DEBUG - 2011-05-22 10:00:03 --> Output Class Initialized
DEBUG - 2011-05-22 10:00:03 --> Input Class Initialized
DEBUG - 2011-05-22 10:00:03 --> Global POST and COOKIE data sanitized
DEBUG - 2011-05-22 10:00:03 --> Language Class Initialized
DEBUG - 2011-05-22 10:00:03 --> Loader Class Initialized
DEBUG - 2011-05-22 10:00:03 --> Controller Class Initialized
ERROR - 2011-05-22 10:00:03 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-05-22 10:00:03 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-05-22 10:00:03 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-05-22 10:00:03 --> Model Class Initialized
DEBUG - 2011-05-22 10:00:04 --> Model Class Initialized
DEBUG - 2011-05-22 10:00:04 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-05-22 10:00:04 --> Database Driver Class Initialized
DEBUG - 2011-05-22 10:00:04 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-05-22 10:00:04 --> Helper loaded: url_helper
DEBUG - 2011-05-22 10:00:04 --> File loaded: application/views/common/header.php
DEBUG - 2011-05-22 10:00:04 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-05-22 10:00:04 --> File loaded: application/views/common/footer.php
DEBUG - 2011-05-22 10:00:04 --> File loaded: application/views/layout/main.php
DEBUG - 2011-05-22 10:00:04 --> Final output sent to browser
DEBUG - 2011-05-22 10:00:04 --> Total execution time: 1.5242
DEBUG - 2011-05-22 10:00:05 --> Config Class Initialized
DEBUG - 2011-05-22 10:00:05 --> Hooks Class Initialized
DEBUG - 2011-05-22 10:00:05 --> Utf8 Class Initialized
DEBUG - 2011-05-22 10:00:05 --> UTF-8 Support Enabled
DEBUG - 2011-05-22 10:00:05 --> URI Class Initialized
DEBUG - 2011-05-22 10:00:05 --> Router Class Initialized
DEBUG - 2011-05-22 10:00:05 --> Output Class Initialized
DEBUG - 2011-05-22 10:00:05 --> Input Class Initialized
DEBUG - 2011-05-22 10:00:05 --> Global POST and COOKIE data sanitized
DEBUG - 2011-05-22 10:00:05 --> Language Class Initialized
DEBUG - 2011-05-22 10:00:05 --> Loader Class Initialized
DEBUG - 2011-05-22 10:00:05 --> Controller Class Initialized
DEBUG - 2011-05-22 10:00:05 --> Model Class Initialized
DEBUG - 2011-05-22 10:00:05 --> Model Class Initialized
DEBUG - 2011-05-22 10:00:05 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-05-22 10:00:05 --> Database Driver Class Initialized
DEBUG - 2011-05-22 10:00:06 --> Final output sent to browser
DEBUG - 2011-05-22 10:00:06 --> Total execution time: 0.9239
DEBUG - 2011-05-22 10:00:06 --> Config Class Initialized
DEBUG - 2011-05-22 10:00:06 --> Hooks Class Initialized
DEBUG - 2011-05-22 10:00:06 --> Utf8 Class Initialized
DEBUG - 2011-05-22 10:00:06 --> UTF-8 Support Enabled
DEBUG - 2011-05-22 10:00:06 --> URI Class Initialized
DEBUG - 2011-05-22 10:00:06 --> Router Class Initialized
ERROR - 2011-05-22 10:00:06 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-05-22 10:00:08 --> Config Class Initialized
DEBUG - 2011-05-22 10:00:08 --> Hooks Class Initialized
DEBUG - 2011-05-22 10:00:08 --> Utf8 Class Initialized
DEBUG - 2011-05-22 10:00:08 --> UTF-8 Support Enabled
DEBUG - 2011-05-22 10:00:08 --> URI Class Initialized
DEBUG - 2011-05-22 10:00:08 --> Router Class Initialized
DEBUG - 2011-05-22 10:00:08 --> Output Class Initialized
DEBUG - 2011-05-22 10:00:08 --> Input Class Initialized
DEBUG - 2011-05-22 10:00:08 --> Global POST and COOKIE data sanitized
DEBUG - 2011-05-22 10:00:08 --> Language Class Initialized
DEBUG - 2011-05-22 10:00:08 --> Loader Class Initialized
DEBUG - 2011-05-22 10:00:08 --> Controller Class Initialized
ERROR - 2011-05-22 10:00:08 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-05-22 10:00:08 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-05-22 10:00:08 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-05-22 10:00:08 --> Model Class Initialized
DEBUG - 2011-05-22 10:00:08 --> Model Class Initialized
DEBUG - 2011-05-22 10:00:08 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-05-22 10:00:08 --> Database Driver Class Initialized
DEBUG - 2011-05-22 10:00:08 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-05-22 10:00:08 --> Helper loaded: url_helper
DEBUG - 2011-05-22 10:00:08 --> File loaded: application/views/common/header.php
DEBUG - 2011-05-22 10:00:08 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-05-22 10:00:08 --> File loaded: application/views/common/footer.php
DEBUG - 2011-05-22 10:00:08 --> File loaded: application/views/layout/main.php
DEBUG - 2011-05-22 10:00:08 --> Final output sent to browser
DEBUG - 2011-05-22 10:00:08 --> Total execution time: 0.0296
DEBUG - 2011-05-22 10:00:22 --> Config Class Initialized
DEBUG - 2011-05-22 10:00:22 --> Hooks Class Initialized
DEBUG - 2011-05-22 10:00:22 --> Utf8 Class Initialized
DEBUG - 2011-05-22 10:00:22 --> UTF-8 Support Enabled
DEBUG - 2011-05-22 10:00:22 --> URI Class Initialized
DEBUG - 2011-05-22 10:00:22 --> Router Class Initialized
DEBUG - 2011-05-22 10:00:22 --> Output Class Initialized
DEBUG - 2011-05-22 10:00:22 --> Input Class Initialized
DEBUG - 2011-05-22 10:00:22 --> Global POST and COOKIE data sanitized
DEBUG - 2011-05-22 10:00:22 --> Language Class Initialized
DEBUG - 2011-05-22 10:00:22 --> Loader Class Initialized
DEBUG - 2011-05-22 10:00:22 --> Controller Class Initialized
ERROR - 2011-05-22 10:00:22 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-05-22 10:00:22 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-05-22 10:00:22 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-05-22 10:00:22 --> Model Class Initialized
DEBUG - 2011-05-22 10:00:22 --> Model Class Initialized
DEBUG - 2011-05-22 10:00:22 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-05-22 10:00:22 --> Database Driver Class Initialized
DEBUG - 2011-05-22 10:00:24 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-05-22 10:00:24 --> Helper loaded: url_helper
DEBUG - 2011-05-22 10:00:24 --> File loaded: application/views/common/header.php
DEBUG - 2011-05-22 10:00:24 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-05-22 10:00:24 --> File loaded: application/views/common/footer.php
DEBUG - 2011-05-22 10:00:24 --> File loaded: application/views/layout/main.php
DEBUG - 2011-05-22 10:00:24 --> Final output sent to browser
DEBUG - 2011-05-22 10:00:24 --> Total execution time: 2.3855
DEBUG - 2011-05-22 10:00:25 --> Config Class Initialized
DEBUG - 2011-05-22 10:00:25 --> Hooks Class Initialized
DEBUG - 2011-05-22 10:00:25 --> Utf8 Class Initialized
DEBUG - 2011-05-22 10:00:25 --> UTF-8 Support Enabled
DEBUG - 2011-05-22 10:00:25 --> URI Class Initialized
DEBUG - 2011-05-22 10:00:25 --> Router Class Initialized
DEBUG - 2011-05-22 10:00:25 --> Output Class Initialized
DEBUG - 2011-05-22 10:00:25 --> Input Class Initialized
DEBUG - 2011-05-22 10:00:25 --> Global POST and COOKIE data sanitized
DEBUG - 2011-05-22 10:00:25 --> Language Class Initialized
DEBUG - 2011-05-22 10:00:25 --> Loader Class Initialized
DEBUG - 2011-05-22 10:00:25 --> Controller Class Initialized
DEBUG - 2011-05-22 10:00:25 --> Model Class Initialized
DEBUG - 2011-05-22 10:00:25 --> Model Class Initialized
DEBUG - 2011-05-22 10:00:25 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-05-22 10:00:25 --> Database Driver Class Initialized
DEBUG - 2011-05-22 10:00:25 --> Final output sent to browser
DEBUG - 2011-05-22 10:00:25 --> Total execution time: 0.5969
DEBUG - 2011-05-22 10:00:26 --> Config Class Initialized
DEBUG - 2011-05-22 10:00:26 --> Hooks Class Initialized
DEBUG - 2011-05-22 10:00:26 --> Utf8 Class Initialized
DEBUG - 2011-05-22 10:00:26 --> UTF-8 Support Enabled
DEBUG - 2011-05-22 10:00:26 --> URI Class Initialized
DEBUG - 2011-05-22 10:00:26 --> Router Class Initialized
ERROR - 2011-05-22 10:00:26 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-05-22 10:00:33 --> Config Class Initialized
DEBUG - 2011-05-22 10:00:33 --> Hooks Class Initialized
DEBUG - 2011-05-22 10:00:33 --> Utf8 Class Initialized
DEBUG - 2011-05-22 10:00:33 --> UTF-8 Support Enabled
DEBUG - 2011-05-22 10:00:33 --> URI Class Initialized
DEBUG - 2011-05-22 10:00:33 --> Router Class Initialized
DEBUG - 2011-05-22 10:00:33 --> Output Class Initialized
DEBUG - 2011-05-22 10:00:33 --> Input Class Initialized
DEBUG - 2011-05-22 10:00:33 --> Global POST and COOKIE data sanitized
DEBUG - 2011-05-22 10:00:33 --> Language Class Initialized
DEBUG - 2011-05-22 10:00:33 --> Loader Class Initialized
DEBUG - 2011-05-22 10:00:33 --> Controller Class Initialized
ERROR - 2011-05-22 10:00:33 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-05-22 10:00:33 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-05-22 10:00:33 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-05-22 10:00:33 --> Model Class Initialized
DEBUG - 2011-05-22 10:00:33 --> Model Class Initialized
DEBUG - 2011-05-22 10:00:33 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-05-22 10:00:33 --> Database Driver Class Initialized
DEBUG - 2011-05-22 10:00:34 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-05-22 10:00:34 --> Helper loaded: url_helper
DEBUG - 2011-05-22 10:00:34 --> File loaded: application/views/common/header.php
DEBUG - 2011-05-22 10:00:34 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-05-22 10:00:34 --> File loaded: application/views/common/footer.php
DEBUG - 2011-05-22 10:00:34 --> File loaded: application/views/layout/main.php
DEBUG - 2011-05-22 10:00:34 --> Final output sent to browser
DEBUG - 2011-05-22 10:00:34 --> Total execution time: 0.7194
DEBUG - 2011-05-22 10:00:34 --> Config Class Initialized
DEBUG - 2011-05-22 10:00:34 --> Hooks Class Initialized
DEBUG - 2011-05-22 10:00:34 --> Utf8 Class Initialized
DEBUG - 2011-05-22 10:00:34 --> UTF-8 Support Enabled
DEBUG - 2011-05-22 10:00:34 --> URI Class Initialized
DEBUG - 2011-05-22 10:00:34 --> Router Class Initialized
DEBUG - 2011-05-22 10:00:34 --> Output Class Initialized
DEBUG - 2011-05-22 10:00:34 --> Input Class Initialized
DEBUG - 2011-05-22 10:00:34 --> Global POST and COOKIE data sanitized
DEBUG - 2011-05-22 10:00:34 --> Language Class Initialized
DEBUG - 2011-05-22 10:00:34 --> Loader Class Initialized
DEBUG - 2011-05-22 10:00:34 --> Controller Class Initialized
DEBUG - 2011-05-22 10:00:34 --> Model Class Initialized
DEBUG - 2011-05-22 10:00:34 --> Model Class Initialized
DEBUG - 2011-05-22 10:00:34 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-05-22 10:00:34 --> Database Driver Class Initialized
DEBUG - 2011-05-22 10:00:35 --> Final output sent to browser
DEBUG - 2011-05-22 10:00:35 --> Total execution time: 0.5276
DEBUG - 2011-05-22 10:00:36 --> Config Class Initialized
DEBUG - 2011-05-22 10:00:36 --> Hooks Class Initialized
DEBUG - 2011-05-22 10:00:36 --> Utf8 Class Initialized
DEBUG - 2011-05-22 10:00:36 --> UTF-8 Support Enabled
DEBUG - 2011-05-22 10:00:36 --> URI Class Initialized
DEBUG - 2011-05-22 10:00:36 --> Router Class Initialized
ERROR - 2011-05-22 10:00:36 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-05-22 10:00:59 --> Config Class Initialized
DEBUG - 2011-05-22 10:00:59 --> Hooks Class Initialized
DEBUG - 2011-05-22 10:00:59 --> Utf8 Class Initialized
DEBUG - 2011-05-22 10:00:59 --> UTF-8 Support Enabled
DEBUG - 2011-05-22 10:00:59 --> URI Class Initialized
DEBUG - 2011-05-22 10:00:59 --> Router Class Initialized
DEBUG - 2011-05-22 10:00:59 --> Output Class Initialized
DEBUG - 2011-05-22 10:00:59 --> Input Class Initialized
DEBUG - 2011-05-22 10:00:59 --> Global POST and COOKIE data sanitized
DEBUG - 2011-05-22 10:00:59 --> Language Class Initialized
DEBUG - 2011-05-22 10:00:59 --> Loader Class Initialized
DEBUG - 2011-05-22 10:00:59 --> Controller Class Initialized
DEBUG - 2011-05-22 10:00:59 --> Model Class Initialized
DEBUG - 2011-05-22 10:00:59 --> Model Class Initialized
DEBUG - 2011-05-22 10:00:59 --> Model Class Initialized
DEBUG - 2011-05-22 10:00:59 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-05-22 10:00:59 --> Database Driver Class Initialized
DEBUG - 2011-05-22 10:00:59 --> File loaded: application/views/table/main.php
DEBUG - 2011-05-22 10:00:59 --> Helper loaded: url_helper
DEBUG - 2011-05-22 10:00:59 --> File loaded: application/views/common/header.php
DEBUG - 2011-05-22 10:00:59 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-05-22 10:00:59 --> File loaded: application/views/common/footer.php
DEBUG - 2011-05-22 10:00:59 --> File loaded: application/views/layout/main.php
DEBUG - 2011-05-22 10:00:59 --> Final output sent to browser
DEBUG - 2011-05-22 10:00:59 --> Total execution time: 0.3398
DEBUG - 2011-05-22 10:01:00 --> Config Class Initialized
DEBUG - 2011-05-22 10:01:00 --> Hooks Class Initialized
DEBUG - 2011-05-22 10:01:00 --> Utf8 Class Initialized
DEBUG - 2011-05-22 10:01:00 --> UTF-8 Support Enabled
DEBUG - 2011-05-22 10:01:00 --> URI Class Initialized
DEBUG - 2011-05-22 10:01:00 --> Router Class Initialized
ERROR - 2011-05-22 10:01:00 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-05-22 10:22:52 --> Config Class Initialized
DEBUG - 2011-05-22 10:22:52 --> Hooks Class Initialized
DEBUG - 2011-05-22 10:22:52 --> Utf8 Class Initialized
DEBUG - 2011-05-22 10:22:52 --> UTF-8 Support Enabled
DEBUG - 2011-05-22 10:22:52 --> URI Class Initialized
DEBUG - 2011-05-22 10:22:52 --> Router Class Initialized
DEBUG - 2011-05-22 10:22:52 --> No URI present. Default controller set.
DEBUG - 2011-05-22 10:22:52 --> Output Class Initialized
DEBUG - 2011-05-22 10:22:52 --> Input Class Initialized
DEBUG - 2011-05-22 10:22:52 --> Global POST and COOKIE data sanitized
DEBUG - 2011-05-22 10:22:52 --> Language Class Initialized
DEBUG - 2011-05-22 10:22:52 --> Loader Class Initialized
DEBUG - 2011-05-22 10:22:52 --> Controller Class Initialized
DEBUG - 2011-05-22 10:22:52 --> File loaded: application/views/splash/main.php
DEBUG - 2011-05-22 10:22:52 --> Helper loaded: url_helper
DEBUG - 2011-05-22 10:22:52 --> File loaded: application/views/common/header.php
DEBUG - 2011-05-22 10:22:52 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-05-22 10:22:52 --> File loaded: application/views/common/footer.php
DEBUG - 2011-05-22 10:22:52 --> File loaded: application/views/layout/main.php
DEBUG - 2011-05-22 10:22:52 --> Final output sent to browser
DEBUG - 2011-05-22 10:22:52 --> Total execution time: 0.1900
DEBUG - 2011-05-22 10:46:12 --> Config Class Initialized
DEBUG - 2011-05-22 10:46:12 --> Hooks Class Initialized
DEBUG - 2011-05-22 10:46:12 --> Utf8 Class Initialized
DEBUG - 2011-05-22 10:46:12 --> UTF-8 Support Enabled
DEBUG - 2011-05-22 10:46:12 --> URI Class Initialized
DEBUG - 2011-05-22 10:46:12 --> Router Class Initialized
DEBUG - 2011-05-22 10:46:12 --> No URI present. Default controller set.
DEBUG - 2011-05-22 10:46:12 --> Output Class Initialized
DEBUG - 2011-05-22 10:46:12 --> Input Class Initialized
DEBUG - 2011-05-22 10:46:12 --> Global POST and COOKIE data sanitized
DEBUG - 2011-05-22 10:46:12 --> Language Class Initialized
DEBUG - 2011-05-22 10:46:12 --> Loader Class Initialized
DEBUG - 2011-05-22 10:46:12 --> Controller Class Initialized
DEBUG - 2011-05-22 10:46:12 --> File loaded: application/views/splash/main.php
DEBUG - 2011-05-22 10:46:12 --> Helper loaded: url_helper
DEBUG - 2011-05-22 10:46:12 --> File loaded: application/views/common/header.php
DEBUG - 2011-05-22 10:46:12 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-05-22 10:46:12 --> File loaded: application/views/common/footer.php
DEBUG - 2011-05-22 10:46:12 --> File loaded: application/views/layout/main.php
DEBUG - 2011-05-22 10:46:12 --> Final output sent to browser
DEBUG - 2011-05-22 10:46:12 --> Total execution time: 0.2399
DEBUG - 2011-05-22 10:48:29 --> Config Class Initialized
DEBUG - 2011-05-22 10:48:29 --> Hooks Class Initialized
DEBUG - 2011-05-22 10:48:29 --> Utf8 Class Initialized
DEBUG - 2011-05-22 10:48:29 --> UTF-8 Support Enabled
DEBUG - 2011-05-22 10:48:29 --> URI Class Initialized
DEBUG - 2011-05-22 10:48:29 --> Router Class Initialized
DEBUG - 2011-05-22 10:48:29 --> No URI present. Default controller set.
DEBUG - 2011-05-22 10:48:29 --> Output Class Initialized
DEBUG - 2011-05-22 10:48:29 --> Input Class Initialized
DEBUG - 2011-05-22 10:48:29 --> Global POST and COOKIE data sanitized
DEBUG - 2011-05-22 10:48:29 --> Language Class Initialized
DEBUG - 2011-05-22 10:48:29 --> Loader Class Initialized
DEBUG - 2011-05-22 10:48:29 --> Controller Class Initialized
DEBUG - 2011-05-22 10:48:29 --> File loaded: application/views/splash/main.php
DEBUG - 2011-05-22 10:48:29 --> Helper loaded: url_helper
DEBUG - 2011-05-22 10:48:29 --> File loaded: application/views/common/header.php
DEBUG - 2011-05-22 10:48:29 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-05-22 10:48:29 --> File loaded: application/views/common/footer.php
DEBUG - 2011-05-22 10:48:29 --> File loaded: application/views/layout/main.php
DEBUG - 2011-05-22 10:48:29 --> Final output sent to browser
DEBUG - 2011-05-22 10:48:29 --> Total execution time: 0.0145
DEBUG - 2011-05-22 10:52:21 --> Config Class Initialized
DEBUG - 2011-05-22 10:52:21 --> Hooks Class Initialized
DEBUG - 2011-05-22 10:52:21 --> Utf8 Class Initialized
DEBUG - 2011-05-22 10:52:21 --> UTF-8 Support Enabled
DEBUG - 2011-05-22 10:52:21 --> URI Class Initialized
DEBUG - 2011-05-22 10:52:21 --> Router Class Initialized
DEBUG - 2011-05-22 10:52:21 --> Output Class Initialized
DEBUG - 2011-05-22 10:52:21 --> Input Class Initialized
DEBUG - 2011-05-22 10:52:21 --> Global POST and COOKIE data sanitized
DEBUG - 2011-05-22 10:52:21 --> Language Class Initialized
DEBUG - 2011-05-22 10:52:21 --> Loader Class Initialized
DEBUG - 2011-05-22 10:52:21 --> Controller Class Initialized
ERROR - 2011-05-22 10:52:21 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-05-22 10:52:21 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-05-22 10:52:21 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-05-22 10:52:21 --> Model Class Initialized
DEBUG - 2011-05-22 10:52:21 --> Model Class Initialized
DEBUG - 2011-05-22 10:52:21 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-05-22 10:52:21 --> Database Driver Class Initialized
DEBUG - 2011-05-22 10:52:21 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-05-22 10:52:21 --> Helper loaded: url_helper
DEBUG - 2011-05-22 10:52:21 --> File loaded: application/views/common/header.php
DEBUG - 2011-05-22 10:52:21 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-05-22 10:52:21 --> File loaded: application/views/common/footer.php
DEBUG - 2011-05-22 10:52:21 --> File loaded: application/views/layout/main.php
DEBUG - 2011-05-22 10:52:22 --> Config Class Initialized
DEBUG - 2011-05-22 10:52:22 --> Hooks Class Initialized
DEBUG - 2011-05-22 10:52:22 --> Utf8 Class Initialized
DEBUG - 2011-05-22 10:52:22 --> UTF-8 Support Enabled
DEBUG - 2011-05-22 10:52:22 --> URI Class Initialized
DEBUG - 2011-05-22 10:52:22 --> Router Class Initialized
DEBUG - 2011-05-22 10:52:22 --> Output Class Initialized
DEBUG - 2011-05-22 10:52:22 --> Input Class Initialized
DEBUG - 2011-05-22 10:52:22 --> Global POST and COOKIE data sanitized
DEBUG - 2011-05-22 10:52:22 --> Language Class Initialized
DEBUG - 2011-05-22 10:52:22 --> Loader Class Initialized
DEBUG - 2011-05-22 10:52:22 --> Controller Class Initialized
DEBUG - 2011-05-22 10:52:22 --> Model Class Initialized
DEBUG - 2011-05-22 10:52:23 --> Model Class Initialized
DEBUG - 2011-05-22 10:52:23 --> Model Class Initialized
DEBUG - 2011-05-22 10:52:23 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-05-22 10:52:23 --> Database Driver Class Initialized
DEBUG - 2011-05-22 10:52:26 --> File loaded: application/views/table/main.php
DEBUG - 2011-05-22 10:52:26 --> Helper loaded: url_helper
DEBUG - 2011-05-22 10:52:26 --> File loaded: application/views/common/header.php
DEBUG - 2011-05-22 10:52:26 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-05-22 10:52:26 --> File loaded: application/views/common/footer.php
DEBUG - 2011-05-22 10:52:26 --> File loaded: application/views/layout/main.php
DEBUG - 2011-05-22 10:52:27 --> Config Class Initialized
DEBUG - 2011-05-22 10:52:27 --> Hooks Class Initialized
DEBUG - 2011-05-22 10:52:27 --> Utf8 Class Initialized
DEBUG - 2011-05-22 10:52:27 --> UTF-8 Support Enabled
DEBUG - 2011-05-22 10:52:27 --> URI Class Initialized
DEBUG - 2011-05-22 10:52:27 --> Router Class Initialized
DEBUG - 2011-05-22 10:52:27 --> Output Class Initialized
DEBUG - 2011-05-22 10:52:27 --> Input Class Initialized
DEBUG - 2011-05-22 10:52:27 --> Global POST and COOKIE data sanitized
DEBUG - 2011-05-22 10:52:27 --> Language Class Initialized
DEBUG - 2011-05-22 10:52:27 --> Loader Class Initialized
DEBUG - 2011-05-22 10:52:27 --> Controller Class Initialized
DEBUG - 2011-05-22 10:52:27 --> Model Class Initialized
DEBUG - 2011-05-22 10:52:27 --> Model Class Initialized
DEBUG - 2011-05-22 10:52:27 --> Model Class Initialized
DEBUG - 2011-05-22 10:52:27 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-05-22 10:52:27 --> Database Driver Class Initialized
DEBUG - 2011-05-22 10:52:27 --> File loaded: application/views/table/main.php
DEBUG - 2011-05-22 10:52:27 --> Helper loaded: url_helper
DEBUG - 2011-05-22 10:52:27 --> File loaded: application/views/common/header.php
DEBUG - 2011-05-22 10:52:27 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-05-22 10:52:27 --> File loaded: application/views/common/footer.php
DEBUG - 2011-05-22 10:52:27 --> File loaded: application/views/layout/main.php
DEBUG - 2011-05-22 10:52:27 --> Final output sent to browser
DEBUG - 2011-05-22 10:52:27 --> Total execution time: 0.0574
DEBUG - 2011-05-22 10:52:29 --> Config Class Initialized
DEBUG - 2011-05-22 10:52:29 --> Hooks Class Initialized
DEBUG - 2011-05-22 10:52:29 --> Utf8 Class Initialized
DEBUG - 2011-05-22 10:52:29 --> UTF-8 Support Enabled
DEBUG - 2011-05-22 10:52:29 --> URI Class Initialized
DEBUG - 2011-05-22 10:52:29 --> Router Class Initialized
DEBUG - 2011-05-22 10:52:29 --> Output Class Initialized
DEBUG - 2011-05-22 10:52:29 --> Input Class Initialized
DEBUG - 2011-05-22 10:52:29 --> Global POST and COOKIE data sanitized
DEBUG - 2011-05-22 10:52:29 --> Language Class Initialized
DEBUG - 2011-05-22 10:52:29 --> Loader Class Initialized
DEBUG - 2011-05-22 10:52:29 --> Controller Class Initialized
ERROR - 2011-05-22 10:52:29 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-05-22 10:52:29 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-05-22 10:52:29 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-05-22 10:52:29 --> Model Class Initialized
DEBUG - 2011-05-22 10:52:29 --> Model Class Initialized
DEBUG - 2011-05-22 10:52:29 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-05-22 10:52:29 --> Database Driver Class Initialized
DEBUG - 2011-05-22 10:52:29 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-05-22 10:52:29 --> Helper loaded: url_helper
DEBUG - 2011-05-22 10:52:29 --> File loaded: application/views/common/header.php
DEBUG - 2011-05-22 10:52:29 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-05-22 10:52:29 --> File loaded: application/views/common/footer.php
DEBUG - 2011-05-22 10:52:29 --> File loaded: application/views/layout/main.php
DEBUG - 2011-05-22 10:52:29 --> Final output sent to browser
DEBUG - 2011-05-22 10:52:29 --> Total execution time: 0.0524
DEBUG - 2011-05-22 11:08:41 --> Config Class Initialized
DEBUG - 2011-05-22 11:08:41 --> Hooks Class Initialized
DEBUG - 2011-05-22 11:08:41 --> Utf8 Class Initialized
DEBUG - 2011-05-22 11:08:41 --> UTF-8 Support Enabled
DEBUG - 2011-05-22 11:08:41 --> URI Class Initialized
DEBUG - 2011-05-22 11:08:41 --> Router Class Initialized
DEBUG - 2011-05-22 11:08:41 --> No URI present. Default controller set.
DEBUG - 2011-05-22 11:08:41 --> Output Class Initialized
DEBUG - 2011-05-22 11:08:41 --> Input Class Initialized
DEBUG - 2011-05-22 11:08:41 --> Global POST and COOKIE data sanitized
DEBUG - 2011-05-22 11:08:42 --> Language Class Initialized
DEBUG - 2011-05-22 11:08:42 --> Loader Class Initialized
DEBUG - 2011-05-22 11:08:42 --> Controller Class Initialized
DEBUG - 2011-05-22 11:08:42 --> File loaded: application/views/splash/main.php
DEBUG - 2011-05-22 11:08:42 --> Helper loaded: url_helper
DEBUG - 2011-05-22 11:08:42 --> File loaded: application/views/common/header.php
DEBUG - 2011-05-22 11:08:42 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-05-22 11:08:42 --> File loaded: application/views/common/footer.php
DEBUG - 2011-05-22 11:08:42 --> File loaded: application/views/layout/main.php
DEBUG - 2011-05-22 11:08:42 --> Final output sent to browser
DEBUG - 2011-05-22 11:08:42 --> Total execution time: 0.4674
DEBUG - 2011-05-22 11:08:51 --> Config Class Initialized
DEBUG - 2011-05-22 11:08:51 --> Hooks Class Initialized
DEBUG - 2011-05-22 11:08:51 --> Utf8 Class Initialized
DEBUG - 2011-05-22 11:08:51 --> UTF-8 Support Enabled
DEBUG - 2011-05-22 11:08:51 --> URI Class Initialized
DEBUG - 2011-05-22 11:08:51 --> Router Class Initialized
DEBUG - 2011-05-22 11:08:51 --> Output Class Initialized
DEBUG - 2011-05-22 11:08:51 --> Input Class Initialized
DEBUG - 2011-05-22 11:08:51 --> Global POST and COOKIE data sanitized
DEBUG - 2011-05-22 11:08:51 --> Language Class Initialized
DEBUG - 2011-05-22 11:08:51 --> Loader Class Initialized
DEBUG - 2011-05-22 11:08:51 --> Controller Class Initialized
ERROR - 2011-05-22 11:08:51 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-05-22 11:08:51 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-05-22 11:08:51 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-05-22 11:08:51 --> Model Class Initialized
DEBUG - 2011-05-22 11:08:51 --> Model Class Initialized
DEBUG - 2011-05-22 11:08:51 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-05-22 11:08:51 --> Database Driver Class Initialized
DEBUG - 2011-05-22 11:08:51 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-05-22 11:08:51 --> Helper loaded: url_helper
DEBUG - 2011-05-22 11:08:51 --> File loaded: application/views/common/header.php
DEBUG - 2011-05-22 11:08:51 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-05-22 11:08:51 --> File loaded: application/views/common/footer.php
DEBUG - 2011-05-22 11:08:51 --> File loaded: application/views/layout/main.php
DEBUG - 2011-05-22 11:08:51 --> Final output sent to browser
DEBUG - 2011-05-22 11:08:51 --> Total execution time: 0.1706
DEBUG - 2011-05-22 11:08:51 --> Config Class Initialized
DEBUG - 2011-05-22 11:08:51 --> Hooks Class Initialized
DEBUG - 2011-05-22 11:08:51 --> Utf8 Class Initialized
DEBUG - 2011-05-22 11:08:51 --> UTF-8 Support Enabled
DEBUG - 2011-05-22 11:08:51 --> URI Class Initialized
DEBUG - 2011-05-22 11:08:51 --> Router Class Initialized
DEBUG - 2011-05-22 11:08:51 --> Output Class Initialized
DEBUG - 2011-05-22 11:08:51 --> Input Class Initialized
DEBUG - 2011-05-22 11:08:51 --> Global POST and COOKIE data sanitized
DEBUG - 2011-05-22 11:08:51 --> Language Class Initialized
DEBUG - 2011-05-22 11:08:51 --> Loader Class Initialized
DEBUG - 2011-05-22 11:08:51 --> Controller Class Initialized
DEBUG - 2011-05-22 11:08:51 --> Model Class Initialized
DEBUG - 2011-05-22 11:08:51 --> Model Class Initialized
DEBUG - 2011-05-22 11:08:51 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-05-22 11:08:51 --> Database Driver Class Initialized
DEBUG - 2011-05-22 11:08:52 --> Final output sent to browser
DEBUG - 2011-05-22 11:08:52 --> Total execution time: 0.6531
DEBUG - 2011-05-22 11:08:53 --> Config Class Initialized
DEBUG - 2011-05-22 11:08:53 --> Hooks Class Initialized
DEBUG - 2011-05-22 11:08:53 --> Utf8 Class Initialized
DEBUG - 2011-05-22 11:08:53 --> UTF-8 Support Enabled
DEBUG - 2011-05-22 11:08:53 --> URI Class Initialized
DEBUG - 2011-05-22 11:08:53 --> Router Class Initialized
DEBUG - 2011-05-22 11:08:53 --> Output Class Initialized
DEBUG - 2011-05-22 11:08:53 --> Input Class Initialized
DEBUG - 2011-05-22 11:08:53 --> Global POST and COOKIE data sanitized
DEBUG - 2011-05-22 11:08:53 --> Language Class Initialized
DEBUG - 2011-05-22 11:08:53 --> Loader Class Initialized
DEBUG - 2011-05-22 11:08:53 --> Controller Class Initialized
DEBUG - 2011-05-22 11:08:53 --> Model Class Initialized
DEBUG - 2011-05-22 11:08:53 --> Model Class Initialized
DEBUG - 2011-05-22 11:08:53 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-05-22 11:08:53 --> Database Driver Class Initialized
DEBUG - 2011-05-22 11:08:54 --> Final output sent to browser
DEBUG - 2011-05-22 11:08:54 --> Total execution time: 0.6295
DEBUG - 2011-05-22 11:09:12 --> Config Class Initialized
DEBUG - 2011-05-22 11:09:12 --> Hooks Class Initialized
DEBUG - 2011-05-22 11:09:12 --> Utf8 Class Initialized
DEBUG - 2011-05-22 11:09:12 --> UTF-8 Support Enabled
DEBUG - 2011-05-22 11:09:12 --> URI Class Initialized
DEBUG - 2011-05-22 11:09:12 --> Router Class Initialized
DEBUG - 2011-05-22 11:09:12 --> Output Class Initialized
DEBUG - 2011-05-22 11:09:12 --> Input Class Initialized
DEBUG - 2011-05-22 11:09:12 --> Global POST and COOKIE data sanitized
DEBUG - 2011-05-22 11:09:12 --> Language Class Initialized
DEBUG - 2011-05-22 11:09:12 --> Loader Class Initialized
DEBUG - 2011-05-22 11:09:12 --> Controller Class Initialized
ERROR - 2011-05-22 11:09:12 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-05-22 11:09:12 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-05-22 11:09:12 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-05-22 11:09:12 --> Model Class Initialized
DEBUG - 2011-05-22 11:09:12 --> Model Class Initialized
DEBUG - 2011-05-22 11:09:12 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-05-22 11:09:12 --> Database Driver Class Initialized
DEBUG - 2011-05-22 11:09:12 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-05-22 11:09:12 --> Helper loaded: url_helper
DEBUG - 2011-05-22 11:09:12 --> File loaded: application/views/common/header.php
DEBUG - 2011-05-22 11:09:12 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-05-22 11:09:12 --> File loaded: application/views/common/footer.php
DEBUG - 2011-05-22 11:09:12 --> File loaded: application/views/layout/main.php
DEBUG - 2011-05-22 11:09:12 --> Final output sent to browser
DEBUG - 2011-05-22 11:09:12 --> Total execution time: 0.0346
DEBUG - 2011-05-22 11:09:14 --> Config Class Initialized
DEBUG - 2011-05-22 11:09:14 --> Hooks Class Initialized
DEBUG - 2011-05-22 11:09:14 --> Utf8 Class Initialized
DEBUG - 2011-05-22 11:09:14 --> UTF-8 Support Enabled
DEBUG - 2011-05-22 11:09:14 --> URI Class Initialized
DEBUG - 2011-05-22 11:09:14 --> Router Class Initialized
DEBUG - 2011-05-22 11:09:14 --> Output Class Initialized
DEBUG - 2011-05-22 11:09:14 --> Input Class Initialized
DEBUG - 2011-05-22 11:09:14 --> Global POST and COOKIE data sanitized
DEBUG - 2011-05-22 11:09:14 --> Language Class Initialized
DEBUG - 2011-05-22 11:09:14 --> Loader Class Initialized
DEBUG - 2011-05-22 11:09:14 --> Controller Class Initialized
DEBUG - 2011-05-22 11:09:14 --> Model Class Initialized
DEBUG - 2011-05-22 11:09:14 --> Model Class Initialized
DEBUG - 2011-05-22 11:09:14 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-05-22 11:09:14 --> Database Driver Class Initialized
DEBUG - 2011-05-22 11:09:15 --> Final output sent to browser
DEBUG - 2011-05-22 11:09:15 --> Total execution time: 0.8123
DEBUG - 2011-05-22 11:09:16 --> Config Class Initialized
DEBUG - 2011-05-22 11:09:16 --> Hooks Class Initialized
DEBUG - 2011-05-22 11:09:16 --> Utf8 Class Initialized
DEBUG - 2011-05-22 11:09:16 --> UTF-8 Support Enabled
DEBUG - 2011-05-22 11:09:16 --> URI Class Initialized
DEBUG - 2011-05-22 11:09:16 --> Router Class Initialized
ERROR - 2011-05-22 11:09:16 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-05-22 11:09:16 --> Config Class Initialized
DEBUG - 2011-05-22 11:09:16 --> Hooks Class Initialized
DEBUG - 2011-05-22 11:09:16 --> Utf8 Class Initialized
DEBUG - 2011-05-22 11:09:16 --> UTF-8 Support Enabled
DEBUG - 2011-05-22 11:09:16 --> URI Class Initialized
DEBUG - 2011-05-22 11:09:16 --> Router Class Initialized
ERROR - 2011-05-22 11:09:16 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-05-22 11:09:29 --> Config Class Initialized
DEBUG - 2011-05-22 11:09:29 --> Hooks Class Initialized
DEBUG - 2011-05-22 11:09:29 --> Utf8 Class Initialized
DEBUG - 2011-05-22 11:09:29 --> UTF-8 Support Enabled
DEBUG - 2011-05-22 11:09:29 --> URI Class Initialized
DEBUG - 2011-05-22 11:09:29 --> Router Class Initialized
DEBUG - 2011-05-22 11:09:29 --> Output Class Initialized
DEBUG - 2011-05-22 11:09:29 --> Input Class Initialized
DEBUG - 2011-05-22 11:09:29 --> Global POST and COOKIE data sanitized
DEBUG - 2011-05-22 11:09:29 --> Language Class Initialized
DEBUG - 2011-05-22 11:09:29 --> Loader Class Initialized
DEBUG - 2011-05-22 11:09:29 --> Controller Class Initialized
ERROR - 2011-05-22 11:09:29 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-05-22 11:09:29 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-05-22 11:09:29 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-05-22 11:09:29 --> Model Class Initialized
DEBUG - 2011-05-22 11:09:29 --> Model Class Initialized
DEBUG - 2011-05-22 11:09:29 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-05-22 11:09:29 --> Database Driver Class Initialized
DEBUG - 2011-05-22 11:09:29 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-05-22 11:09:29 --> Helper loaded: url_helper
DEBUG - 2011-05-22 11:09:29 --> File loaded: application/views/common/header.php
DEBUG - 2011-05-22 11:09:29 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-05-22 11:09:29 --> File loaded: application/views/common/footer.php
DEBUG - 2011-05-22 11:09:29 --> File loaded: application/views/layout/main.php
DEBUG - 2011-05-22 11:09:29 --> Final output sent to browser
DEBUG - 2011-05-22 11:09:29 --> Total execution time: 0.0428
DEBUG - 2011-05-22 11:09:30 --> Config Class Initialized
DEBUG - 2011-05-22 11:09:30 --> Hooks Class Initialized
DEBUG - 2011-05-22 11:09:30 --> Utf8 Class Initialized
DEBUG - 2011-05-22 11:09:30 --> UTF-8 Support Enabled
DEBUG - 2011-05-22 11:09:30 --> URI Class Initialized
DEBUG - 2011-05-22 11:09:30 --> Router Class Initialized
DEBUG - 2011-05-22 11:09:30 --> Output Class Initialized
DEBUG - 2011-05-22 11:09:30 --> Input Class Initialized
DEBUG - 2011-05-22 11:09:30 --> Global POST and COOKIE data sanitized
DEBUG - 2011-05-22 11:09:30 --> Language Class Initialized
DEBUG - 2011-05-22 11:09:30 --> Loader Class Initialized
DEBUG - 2011-05-22 11:09:30 --> Controller Class Initialized
DEBUG - 2011-05-22 11:09:30 --> Model Class Initialized
DEBUG - 2011-05-22 11:09:30 --> Model Class Initialized
DEBUG - 2011-05-22 11:09:30 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-05-22 11:09:30 --> Database Driver Class Initialized
DEBUG - 2011-05-22 11:09:31 --> Final output sent to browser
DEBUG - 2011-05-22 11:09:31 --> Total execution time: 0.9941
DEBUG - 2011-05-22 11:09:32 --> Config Class Initialized
DEBUG - 2011-05-22 11:09:32 --> Hooks Class Initialized
DEBUG - 2011-05-22 11:09:32 --> Utf8 Class Initialized
DEBUG - 2011-05-22 11:09:32 --> UTF-8 Support Enabled
DEBUG - 2011-05-22 11:09:32 --> URI Class Initialized
DEBUG - 2011-05-22 11:09:32 --> Router Class Initialized
DEBUG - 2011-05-22 11:09:32 --> Output Class Initialized
DEBUG - 2011-05-22 11:09:32 --> Input Class Initialized
DEBUG - 2011-05-22 11:09:32 --> Global POST and COOKIE data sanitized
DEBUG - 2011-05-22 11:09:32 --> Language Class Initialized
DEBUG - 2011-05-22 11:09:32 --> Loader Class Initialized
DEBUG - 2011-05-22 11:09:32 --> Controller Class Initialized
DEBUG - 2011-05-22 11:09:32 --> Model Class Initialized
DEBUG - 2011-05-22 11:09:32 --> Model Class Initialized
DEBUG - 2011-05-22 11:09:32 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-05-22 11:09:32 --> Database Driver Class Initialized
DEBUG - 2011-05-22 11:09:32 --> Final output sent to browser
DEBUG - 2011-05-22 11:09:32 --> Total execution time: 0.6902
DEBUG - 2011-05-22 11:09:41 --> Config Class Initialized
DEBUG - 2011-05-22 11:09:41 --> Hooks Class Initialized
DEBUG - 2011-05-22 11:09:41 --> Utf8 Class Initialized
DEBUG - 2011-05-22 11:09:41 --> UTF-8 Support Enabled
DEBUG - 2011-05-22 11:09:41 --> URI Class Initialized
DEBUG - 2011-05-22 11:09:41 --> Router Class Initialized
DEBUG - 2011-05-22 11:09:41 --> Output Class Initialized
DEBUG - 2011-05-22 11:09:41 --> Input Class Initialized
DEBUG - 2011-05-22 11:09:41 --> Global POST and COOKIE data sanitized
DEBUG - 2011-05-22 11:09:41 --> Language Class Initialized
DEBUG - 2011-05-22 11:09:41 --> Loader Class Initialized
DEBUG - 2011-05-22 11:09:41 --> Controller Class Initialized
ERROR - 2011-05-22 11:09:41 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-05-22 11:09:41 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-05-22 11:09:41 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-05-22 11:09:41 --> Model Class Initialized
DEBUG - 2011-05-22 11:09:41 --> Model Class Initialized
DEBUG - 2011-05-22 11:09:41 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-05-22 11:09:41 --> Database Driver Class Initialized
DEBUG - 2011-05-22 11:09:41 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-05-22 11:09:41 --> Helper loaded: url_helper
DEBUG - 2011-05-22 11:09:41 --> File loaded: application/views/common/header.php
DEBUG - 2011-05-22 11:09:41 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-05-22 11:09:41 --> File loaded: application/views/common/footer.php
DEBUG - 2011-05-22 11:09:41 --> File loaded: application/views/layout/main.php
DEBUG - 2011-05-22 11:09:41 --> Final output sent to browser
DEBUG - 2011-05-22 11:09:41 --> Total execution time: 0.0553
DEBUG - 2011-05-22 11:09:42 --> Config Class Initialized
DEBUG - 2011-05-22 11:09:42 --> Hooks Class Initialized
DEBUG - 2011-05-22 11:09:42 --> Utf8 Class Initialized
DEBUG - 2011-05-22 11:09:42 --> UTF-8 Support Enabled
DEBUG - 2011-05-22 11:09:42 --> URI Class Initialized
DEBUG - 2011-05-22 11:09:42 --> Router Class Initialized
DEBUG - 2011-05-22 11:09:42 --> Output Class Initialized
DEBUG - 2011-05-22 11:09:42 --> Input Class Initialized
DEBUG - 2011-05-22 11:09:42 --> Global POST and COOKIE data sanitized
DEBUG - 2011-05-22 11:09:42 --> Language Class Initialized
DEBUG - 2011-05-22 11:09:42 --> Loader Class Initialized
DEBUG - 2011-05-22 11:09:42 --> Controller Class Initialized
DEBUG - 2011-05-22 11:09:42 --> Model Class Initialized
DEBUG - 2011-05-22 11:09:42 --> Model Class Initialized
DEBUG - 2011-05-22 11:09:42 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-05-22 11:09:42 --> Database Driver Class Initialized
DEBUG - 2011-05-22 11:09:42 --> Final output sent to browser
DEBUG - 2011-05-22 11:09:42 --> Total execution time: 0.7232
DEBUG - 2011-05-22 11:09:44 --> Config Class Initialized
DEBUG - 2011-05-22 11:09:44 --> Hooks Class Initialized
DEBUG - 2011-05-22 11:09:44 --> Utf8 Class Initialized
DEBUG - 2011-05-22 11:09:44 --> UTF-8 Support Enabled
DEBUG - 2011-05-22 11:09:44 --> URI Class Initialized
DEBUG - 2011-05-22 11:09:44 --> Router Class Initialized
DEBUG - 2011-05-22 11:09:44 --> Output Class Initialized
DEBUG - 2011-05-22 11:09:44 --> Input Class Initialized
DEBUG - 2011-05-22 11:09:44 --> Global POST and COOKIE data sanitized
DEBUG - 2011-05-22 11:09:44 --> Language Class Initialized
DEBUG - 2011-05-22 11:09:44 --> Loader Class Initialized
DEBUG - 2011-05-22 11:09:44 --> Controller Class Initialized
DEBUG - 2011-05-22 11:09:44 --> Model Class Initialized
DEBUG - 2011-05-22 11:09:44 --> Model Class Initialized
DEBUG - 2011-05-22 11:09:44 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-05-22 11:09:44 --> Database Driver Class Initialized
DEBUG - 2011-05-22 11:09:45 --> Final output sent to browser
DEBUG - 2011-05-22 11:09:45 --> Total execution time: 0.8244
DEBUG - 2011-05-22 11:10:05 --> Config Class Initialized
DEBUG - 2011-05-22 11:10:05 --> Hooks Class Initialized
DEBUG - 2011-05-22 11:10:05 --> Utf8 Class Initialized
DEBUG - 2011-05-22 11:10:05 --> UTF-8 Support Enabled
DEBUG - 2011-05-22 11:10:05 --> URI Class Initialized
DEBUG - 2011-05-22 11:10:05 --> Router Class Initialized
DEBUG - 2011-05-22 11:10:05 --> Output Class Initialized
DEBUG - 2011-05-22 11:10:05 --> Input Class Initialized
DEBUG - 2011-05-22 11:10:05 --> Global POST and COOKIE data sanitized
DEBUG - 2011-05-22 11:10:05 --> Language Class Initialized
DEBUG - 2011-05-22 11:10:05 --> Loader Class Initialized
DEBUG - 2011-05-22 11:10:05 --> Controller Class Initialized
DEBUG - 2011-05-22 11:10:05 --> Model Class Initialized
DEBUG - 2011-05-22 11:10:05 --> Model Class Initialized
DEBUG - 2011-05-22 11:10:05 --> Model Class Initialized
DEBUG - 2011-05-22 11:10:05 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-05-22 11:10:05 --> Database Driver Class Initialized
DEBUG - 2011-05-22 11:10:05 --> File loaded: application/views/table/main.php
DEBUG - 2011-05-22 11:10:05 --> Helper loaded: url_helper
DEBUG - 2011-05-22 11:10:05 --> File loaded: application/views/common/header.php
DEBUG - 2011-05-22 11:10:05 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-05-22 11:10:05 --> File loaded: application/views/common/footer.php
DEBUG - 2011-05-22 11:10:05 --> File loaded: application/views/layout/main.php
DEBUG - 2011-05-22 11:10:05 --> Final output sent to browser
DEBUG - 2011-05-22 11:10:05 --> Total execution time: 0.4398
DEBUG - 2011-05-22 11:10:11 --> Config Class Initialized
DEBUG - 2011-05-22 11:10:11 --> Hooks Class Initialized
DEBUG - 2011-05-22 11:10:11 --> Utf8 Class Initialized
DEBUG - 2011-05-22 11:10:11 --> UTF-8 Support Enabled
DEBUG - 2011-05-22 11:10:11 --> URI Class Initialized
DEBUG - 2011-05-22 11:10:11 --> Router Class Initialized
DEBUG - 2011-05-22 11:10:11 --> Output Class Initialized
DEBUG - 2011-05-22 11:10:11 --> Input Class Initialized
DEBUG - 2011-05-22 11:10:11 --> Global POST and COOKIE data sanitized
DEBUG - 2011-05-22 11:10:11 --> Language Class Initialized
DEBUG - 2011-05-22 11:10:11 --> Loader Class Initialized
DEBUG - 2011-05-22 11:10:11 --> Controller Class Initialized
ERROR - 2011-05-22 11:10:11 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-05-22 11:10:11 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-05-22 11:10:11 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-05-22 11:10:11 --> Model Class Initialized
DEBUG - 2011-05-22 11:10:11 --> Model Class Initialized
DEBUG - 2011-05-22 11:10:11 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-05-22 11:10:11 --> Database Driver Class Initialized
DEBUG - 2011-05-22 11:10:11 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-05-22 11:10:11 --> Helper loaded: url_helper
DEBUG - 2011-05-22 11:10:11 --> File loaded: application/views/common/header.php
DEBUG - 2011-05-22 11:10:11 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-05-22 11:10:11 --> File loaded: application/views/common/footer.php
DEBUG - 2011-05-22 11:10:11 --> File loaded: application/views/layout/main.php
DEBUG - 2011-05-22 11:10:11 --> Final output sent to browser
DEBUG - 2011-05-22 11:10:11 --> Total execution time: 0.0269
DEBUG - 2011-05-22 11:10:11 --> Config Class Initialized
DEBUG - 2011-05-22 11:10:11 --> Hooks Class Initialized
DEBUG - 2011-05-22 11:10:11 --> Utf8 Class Initialized
DEBUG - 2011-05-22 11:10:11 --> UTF-8 Support Enabled
DEBUG - 2011-05-22 11:10:11 --> URI Class Initialized
DEBUG - 2011-05-22 11:10:11 --> Router Class Initialized
DEBUG - 2011-05-22 11:10:11 --> Output Class Initialized
DEBUG - 2011-05-22 11:10:11 --> Input Class Initialized
DEBUG - 2011-05-22 11:10:11 --> Global POST and COOKIE data sanitized
DEBUG - 2011-05-22 11:10:11 --> Language Class Initialized
DEBUG - 2011-05-22 11:10:11 --> Loader Class Initialized
DEBUG - 2011-05-22 11:10:11 --> Controller Class Initialized
DEBUG - 2011-05-22 11:10:11 --> Model Class Initialized
DEBUG - 2011-05-22 11:10:11 --> Model Class Initialized
DEBUG - 2011-05-22 11:10:11 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-05-22 11:10:11 --> Database Driver Class Initialized
DEBUG - 2011-05-22 11:10:12 --> Final output sent to browser
DEBUG - 2011-05-22 11:10:12 --> Total execution time: 0.6626
DEBUG - 2011-05-22 11:10:13 --> Config Class Initialized
DEBUG - 2011-05-22 11:10:13 --> Hooks Class Initialized
DEBUG - 2011-05-22 11:10:13 --> Utf8 Class Initialized
DEBUG - 2011-05-22 11:10:13 --> UTF-8 Support Enabled
DEBUG - 2011-05-22 11:10:13 --> URI Class Initialized
DEBUG - 2011-05-22 11:10:13 --> Router Class Initialized
DEBUG - 2011-05-22 11:10:13 --> Output Class Initialized
DEBUG - 2011-05-22 11:10:13 --> Input Class Initialized
DEBUG - 2011-05-22 11:10:13 --> Global POST and COOKIE data sanitized
DEBUG - 2011-05-22 11:10:13 --> Language Class Initialized
DEBUG - 2011-05-22 11:10:13 --> Loader Class Initialized
DEBUG - 2011-05-22 11:10:13 --> Controller Class Initialized
DEBUG - 2011-05-22 11:10:13 --> Model Class Initialized
DEBUG - 2011-05-22 11:10:13 --> Model Class Initialized
DEBUG - 2011-05-22 11:10:13 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-05-22 11:10:13 --> Database Driver Class Initialized
DEBUG - 2011-05-22 11:10:14 --> Final output sent to browser
DEBUG - 2011-05-22 11:10:14 --> Total execution time: 0.5267
DEBUG - 2011-05-22 11:10:47 --> Config Class Initialized
DEBUG - 2011-05-22 11:10:47 --> Hooks Class Initialized
DEBUG - 2011-05-22 11:10:47 --> Utf8 Class Initialized
DEBUG - 2011-05-22 11:10:47 --> UTF-8 Support Enabled
DEBUG - 2011-05-22 11:10:47 --> URI Class Initialized
DEBUG - 2011-05-22 11:10:47 --> Router Class Initialized
DEBUG - 2011-05-22 11:10:47 --> Output Class Initialized
DEBUG - 2011-05-22 11:10:47 --> Input Class Initialized
DEBUG - 2011-05-22 11:10:47 --> Global POST and COOKIE data sanitized
DEBUG - 2011-05-22 11:10:47 --> Language Class Initialized
DEBUG - 2011-05-22 11:10:47 --> Loader Class Initialized
DEBUG - 2011-05-22 11:10:47 --> Controller Class Initialized
ERROR - 2011-05-22 11:10:47 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-05-22 11:10:47 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-05-22 11:10:47 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-05-22 11:10:47 --> Model Class Initialized
DEBUG - 2011-05-22 11:10:47 --> Model Class Initialized
DEBUG - 2011-05-22 11:10:47 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-05-22 11:10:47 --> Database Driver Class Initialized
DEBUG - 2011-05-22 11:10:47 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-05-22 11:10:47 --> Helper loaded: url_helper
DEBUG - 2011-05-22 11:10:47 --> File loaded: application/views/common/header.php
DEBUG - 2011-05-22 11:10:47 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-05-22 11:10:47 --> File loaded: application/views/common/footer.php
DEBUG - 2011-05-22 11:10:47 --> File loaded: application/views/layout/main.php
DEBUG - 2011-05-22 11:10:47 --> Final output sent to browser
DEBUG - 2011-05-22 11:10:47 --> Total execution time: 0.0308
DEBUG - 2011-05-22 11:10:53 --> Config Class Initialized
DEBUG - 2011-05-22 11:10:53 --> Hooks Class Initialized
DEBUG - 2011-05-22 11:10:53 --> Utf8 Class Initialized
DEBUG - 2011-05-22 11:10:53 --> UTF-8 Support Enabled
DEBUG - 2011-05-22 11:10:53 --> URI Class Initialized
DEBUG - 2011-05-22 11:10:53 --> Router Class Initialized
DEBUG - 2011-05-22 11:10:53 --> Output Class Initialized
DEBUG - 2011-05-22 11:10:53 --> Input Class Initialized
DEBUG - 2011-05-22 11:10:53 --> Global POST and COOKIE data sanitized
DEBUG - 2011-05-22 11:10:53 --> Language Class Initialized
DEBUG - 2011-05-22 11:10:53 --> Loader Class Initialized
DEBUG - 2011-05-22 11:10:53 --> Controller Class Initialized
ERROR - 2011-05-22 11:10:53 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-05-22 11:10:53 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-05-22 11:10:53 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-05-22 11:10:53 --> Model Class Initialized
DEBUG - 2011-05-22 11:10:53 --> Model Class Initialized
DEBUG - 2011-05-22 11:10:53 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-05-22 11:10:53 --> Database Driver Class Initialized
DEBUG - 2011-05-22 11:10:53 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-05-22 11:10:53 --> Helper loaded: url_helper
DEBUG - 2011-05-22 11:10:53 --> File loaded: application/views/common/header.php
DEBUG - 2011-05-22 11:10:53 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-05-22 11:10:53 --> File loaded: application/views/common/footer.php
DEBUG - 2011-05-22 11:10:53 --> File loaded: application/views/layout/main.php
DEBUG - 2011-05-22 11:10:53 --> Final output sent to browser
DEBUG - 2011-05-22 11:10:53 --> Total execution time: 0.0285
DEBUG - 2011-05-22 11:10:53 --> Config Class Initialized
DEBUG - 2011-05-22 11:10:53 --> Hooks Class Initialized
DEBUG - 2011-05-22 11:10:53 --> Utf8 Class Initialized
DEBUG - 2011-05-22 11:10:53 --> UTF-8 Support Enabled
DEBUG - 2011-05-22 11:10:53 --> URI Class Initialized
DEBUG - 2011-05-22 11:10:53 --> Router Class Initialized
DEBUG - 2011-05-22 11:10:53 --> Output Class Initialized
DEBUG - 2011-05-22 11:10:53 --> Input Class Initialized
DEBUG - 2011-05-22 11:10:53 --> Global POST and COOKIE data sanitized
DEBUG - 2011-05-22 11:10:53 --> Language Class Initialized
DEBUG - 2011-05-22 11:10:53 --> Loader Class Initialized
DEBUG - 2011-05-22 11:10:53 --> Controller Class Initialized
DEBUG - 2011-05-22 11:10:53 --> Model Class Initialized
DEBUG - 2011-05-22 11:10:53 --> Model Class Initialized
DEBUG - 2011-05-22 11:10:53 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-05-22 11:10:53 --> Database Driver Class Initialized
DEBUG - 2011-05-22 11:10:54 --> Final output sent to browser
DEBUG - 2011-05-22 11:10:54 --> Total execution time: 0.6636
DEBUG - 2011-05-22 11:10:55 --> Config Class Initialized
DEBUG - 2011-05-22 11:10:55 --> Hooks Class Initialized
DEBUG - 2011-05-22 11:10:55 --> Utf8 Class Initialized
DEBUG - 2011-05-22 11:10:55 --> UTF-8 Support Enabled
DEBUG - 2011-05-22 11:10:55 --> URI Class Initialized
DEBUG - 2011-05-22 11:10:55 --> Router Class Initialized
DEBUG - 2011-05-22 11:10:55 --> Output Class Initialized
DEBUG - 2011-05-22 11:10:55 --> Input Class Initialized
DEBUG - 2011-05-22 11:10:55 --> Global POST and COOKIE data sanitized
DEBUG - 2011-05-22 11:10:55 --> Language Class Initialized
DEBUG - 2011-05-22 11:10:55 --> Loader Class Initialized
DEBUG - 2011-05-22 11:10:55 --> Controller Class Initialized
DEBUG - 2011-05-22 11:10:55 --> Model Class Initialized
DEBUG - 2011-05-22 11:10:55 --> Model Class Initialized
DEBUG - 2011-05-22 11:10:55 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-05-22 11:10:55 --> Database Driver Class Initialized
DEBUG - 2011-05-22 11:10:56 --> Final output sent to browser
DEBUG - 2011-05-22 11:10:56 --> Total execution time: 0.5209
DEBUG - 2011-05-22 11:11:01 --> Config Class Initialized
DEBUG - 2011-05-22 11:11:01 --> Hooks Class Initialized
DEBUG - 2011-05-22 11:11:01 --> Utf8 Class Initialized
DEBUG - 2011-05-22 11:11:01 --> UTF-8 Support Enabled
DEBUG - 2011-05-22 11:11:01 --> URI Class Initialized
DEBUG - 2011-05-22 11:11:01 --> Router Class Initialized
DEBUG - 2011-05-22 11:11:01 --> Output Class Initialized
DEBUG - 2011-05-22 11:11:01 --> Input Class Initialized
DEBUG - 2011-05-22 11:11:01 --> Global POST and COOKIE data sanitized
DEBUG - 2011-05-22 11:11:01 --> Language Class Initialized
DEBUG - 2011-05-22 11:11:01 --> Loader Class Initialized
DEBUG - 2011-05-22 11:11:01 --> Controller Class Initialized
DEBUG - 2011-05-22 11:11:01 --> Model Class Initialized
DEBUG - 2011-05-22 11:11:01 --> Model Class Initialized
DEBUG - 2011-05-22 11:11:01 --> Model Class Initialized
DEBUG - 2011-05-22 11:11:01 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-05-22 11:11:01 --> Database Driver Class Initialized
DEBUG - 2011-05-22 11:11:02 --> File loaded: application/views/table/main.php
DEBUG - 2011-05-22 11:11:02 --> Helper loaded: url_helper
DEBUG - 2011-05-22 11:11:02 --> File loaded: application/views/common/header.php
DEBUG - 2011-05-22 11:11:02 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-05-22 11:11:02 --> File loaded: application/views/common/footer.php
DEBUG - 2011-05-22 11:11:02 --> File loaded: application/views/layout/main.php
DEBUG - 2011-05-22 11:11:02 --> Final output sent to browser
DEBUG - 2011-05-22 11:11:02 --> Total execution time: 0.3020
DEBUG - 2011-05-22 11:11:08 --> Config Class Initialized
DEBUG - 2011-05-22 11:11:08 --> Hooks Class Initialized
DEBUG - 2011-05-22 11:11:08 --> Utf8 Class Initialized
DEBUG - 2011-05-22 11:11:08 --> UTF-8 Support Enabled
DEBUG - 2011-05-22 11:11:08 --> URI Class Initialized
DEBUG - 2011-05-22 11:11:08 --> Router Class Initialized
DEBUG - 2011-05-22 11:11:08 --> Output Class Initialized
DEBUG - 2011-05-22 11:11:08 --> Input Class Initialized
DEBUG - 2011-05-22 11:11:08 --> Global POST and COOKIE data sanitized
DEBUG - 2011-05-22 11:11:08 --> Language Class Initialized
DEBUG - 2011-05-22 11:11:08 --> Loader Class Initialized
DEBUG - 2011-05-22 11:11:08 --> Controller Class Initialized
DEBUG - 2011-05-22 11:11:08 --> Model Class Initialized
DEBUG - 2011-05-22 11:11:08 --> Model Class Initialized
DEBUG - 2011-05-22 11:11:08 --> Model Class Initialized
DEBUG - 2011-05-22 11:11:08 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-05-22 11:11:08 --> Database Driver Class Initialized
DEBUG - 2011-05-22 11:11:08 --> File loaded: application/views/table/main.php
DEBUG - 2011-05-22 11:11:08 --> Helper loaded: url_helper
DEBUG - 2011-05-22 11:11:08 --> File loaded: application/views/common/header.php
DEBUG - 2011-05-22 11:11:08 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-05-22 11:11:08 --> File loaded: application/views/common/footer.php
DEBUG - 2011-05-22 11:11:08 --> File loaded: application/views/layout/main.php
DEBUG - 2011-05-22 11:11:08 --> Final output sent to browser
DEBUG - 2011-05-22 11:11:08 --> Total execution time: 0.2347
DEBUG - 2011-05-22 11:11:16 --> Config Class Initialized
DEBUG - 2011-05-22 11:11:16 --> Hooks Class Initialized
DEBUG - 2011-05-22 11:11:16 --> Utf8 Class Initialized
DEBUG - 2011-05-22 11:11:16 --> UTF-8 Support Enabled
DEBUG - 2011-05-22 11:11:16 --> URI Class Initialized
DEBUG - 2011-05-22 11:11:16 --> Router Class Initialized
DEBUG - 2011-05-22 11:11:16 --> Output Class Initialized
DEBUG - 2011-05-22 11:11:16 --> Input Class Initialized
DEBUG - 2011-05-22 11:11:16 --> Global POST and COOKIE data sanitized
DEBUG - 2011-05-22 11:11:16 --> Language Class Initialized
DEBUG - 2011-05-22 11:11:16 --> Loader Class Initialized
DEBUG - 2011-05-22 11:11:16 --> Controller Class Initialized
ERROR - 2011-05-22 11:11:16 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-05-22 11:11:16 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-05-22 11:11:16 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-05-22 11:11:16 --> Model Class Initialized
DEBUG - 2011-05-22 11:11:16 --> Model Class Initialized
DEBUG - 2011-05-22 11:11:16 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-05-22 11:11:16 --> Database Driver Class Initialized
DEBUG - 2011-05-22 11:11:17 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-05-22 11:11:17 --> Helper loaded: url_helper
DEBUG - 2011-05-22 11:11:17 --> File loaded: application/views/common/header.php
DEBUG - 2011-05-22 11:11:17 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-05-22 11:11:17 --> File loaded: application/views/common/footer.php
DEBUG - 2011-05-22 11:11:17 --> File loaded: application/views/layout/main.php
DEBUG - 2011-05-22 11:11:17 --> Final output sent to browser
DEBUG - 2011-05-22 11:11:17 --> Total execution time: 0.0279
DEBUG - 2011-05-22 11:11:17 --> Config Class Initialized
DEBUG - 2011-05-22 11:11:17 --> Hooks Class Initialized
DEBUG - 2011-05-22 11:11:17 --> Utf8 Class Initialized
DEBUG - 2011-05-22 11:11:17 --> UTF-8 Support Enabled
DEBUG - 2011-05-22 11:11:17 --> URI Class Initialized
DEBUG - 2011-05-22 11:11:17 --> Router Class Initialized
DEBUG - 2011-05-22 11:11:17 --> Output Class Initialized
DEBUG - 2011-05-22 11:11:17 --> Input Class Initialized
DEBUG - 2011-05-22 11:11:17 --> Global POST and COOKIE data sanitized
DEBUG - 2011-05-22 11:11:17 --> Language Class Initialized
DEBUG - 2011-05-22 11:11:17 --> Loader Class Initialized
DEBUG - 2011-05-22 11:11:17 --> Controller Class Initialized
DEBUG - 2011-05-22 11:11:17 --> Model Class Initialized
DEBUG - 2011-05-22 11:11:17 --> Model Class Initialized
DEBUG - 2011-05-22 11:11:17 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-05-22 11:11:17 --> Database Driver Class Initialized
DEBUG - 2011-05-22 11:11:17 --> Final output sent to browser
DEBUG - 2011-05-22 11:11:17 --> Total execution time: 0.5326
DEBUG - 2011-05-22 11:11:19 --> Config Class Initialized
DEBUG - 2011-05-22 11:11:19 --> Hooks Class Initialized
DEBUG - 2011-05-22 11:11:19 --> Utf8 Class Initialized
DEBUG - 2011-05-22 11:11:19 --> UTF-8 Support Enabled
DEBUG - 2011-05-22 11:11:19 --> URI Class Initialized
DEBUG - 2011-05-22 11:11:19 --> Router Class Initialized
DEBUG - 2011-05-22 11:11:19 --> Output Class Initialized
DEBUG - 2011-05-22 11:11:19 --> Input Class Initialized
DEBUG - 2011-05-22 11:11:19 --> Global POST and COOKIE data sanitized
DEBUG - 2011-05-22 11:11:19 --> Language Class Initialized
DEBUG - 2011-05-22 11:11:19 --> Loader Class Initialized
DEBUG - 2011-05-22 11:11:19 --> Controller Class Initialized
DEBUG - 2011-05-22 11:11:19 --> Model Class Initialized
DEBUG - 2011-05-22 11:11:19 --> Model Class Initialized
DEBUG - 2011-05-22 11:11:19 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-05-22 11:11:19 --> Database Driver Class Initialized
DEBUG - 2011-05-22 11:11:20 --> Final output sent to browser
DEBUG - 2011-05-22 11:11:20 --> Total execution time: 0.4776
DEBUG - 2011-05-22 11:11:31 --> Config Class Initialized
DEBUG - 2011-05-22 11:11:31 --> Hooks Class Initialized
DEBUG - 2011-05-22 11:11:31 --> Utf8 Class Initialized
DEBUG - 2011-05-22 11:11:31 --> UTF-8 Support Enabled
DEBUG - 2011-05-22 11:11:31 --> URI Class Initialized
DEBUG - 2011-05-22 11:11:31 --> Router Class Initialized
DEBUG - 2011-05-22 11:11:31 --> Output Class Initialized
DEBUG - 2011-05-22 11:11:31 --> Input Class Initialized
DEBUG - 2011-05-22 11:11:31 --> Global POST and COOKIE data sanitized
DEBUG - 2011-05-22 11:11:31 --> Language Class Initialized
DEBUG - 2011-05-22 11:11:31 --> Loader Class Initialized
DEBUG - 2011-05-22 11:11:31 --> Controller Class Initialized
DEBUG - 2011-05-22 11:11:31 --> Model Class Initialized
DEBUG - 2011-05-22 11:11:31 --> Model Class Initialized
DEBUG - 2011-05-22 11:11:31 --> Model Class Initialized
DEBUG - 2011-05-22 11:11:31 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-05-22 11:11:31 --> Database Driver Class Initialized
DEBUG - 2011-05-22 11:11:31 --> File loaded: application/views/table/main.php
DEBUG - 2011-05-22 11:11:31 --> Helper loaded: url_helper
DEBUG - 2011-05-22 11:11:31 --> File loaded: application/views/common/header.php
DEBUG - 2011-05-22 11:11:31 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-05-22 11:11:31 --> File loaded: application/views/common/footer.php
DEBUG - 2011-05-22 11:11:31 --> File loaded: application/views/layout/main.php
DEBUG - 2011-05-22 11:11:31 --> Final output sent to browser
DEBUG - 2011-05-22 11:11:31 --> Total execution time: 0.0458
DEBUG - 2011-05-22 11:11:33 --> Config Class Initialized
DEBUG - 2011-05-22 11:11:33 --> Hooks Class Initialized
DEBUG - 2011-05-22 11:11:33 --> Utf8 Class Initialized
DEBUG - 2011-05-22 11:11:33 --> UTF-8 Support Enabled
DEBUG - 2011-05-22 11:11:33 --> URI Class Initialized
DEBUG - 2011-05-22 11:11:33 --> Router Class Initialized
DEBUG - 2011-05-22 11:11:33 --> Output Class Initialized
DEBUG - 2011-05-22 11:11:33 --> Input Class Initialized
DEBUG - 2011-05-22 11:11:33 --> Global POST and COOKIE data sanitized
DEBUG - 2011-05-22 11:11:33 --> Language Class Initialized
DEBUG - 2011-05-22 11:11:33 --> Loader Class Initialized
DEBUG - 2011-05-22 11:11:33 --> Controller Class Initialized
ERROR - 2011-05-22 11:11:33 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-05-22 11:11:33 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-05-22 11:11:33 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-05-22 11:11:33 --> Model Class Initialized
DEBUG - 2011-05-22 11:11:33 --> Model Class Initialized
DEBUG - 2011-05-22 11:11:33 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-05-22 11:11:33 --> Database Driver Class Initialized
DEBUG - 2011-05-22 11:11:33 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-05-22 11:11:33 --> Helper loaded: url_helper
DEBUG - 2011-05-22 11:11:33 --> File loaded: application/views/common/header.php
DEBUG - 2011-05-22 11:11:33 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-05-22 11:11:33 --> File loaded: application/views/common/footer.php
DEBUG - 2011-05-22 11:11:33 --> File loaded: application/views/layout/main.php
DEBUG - 2011-05-22 11:11:33 --> Final output sent to browser
DEBUG - 2011-05-22 11:11:33 --> Total execution time: 0.0436
DEBUG - 2011-05-22 11:11:33 --> Config Class Initialized
DEBUG - 2011-05-22 11:11:33 --> Hooks Class Initialized
DEBUG - 2011-05-22 11:11:33 --> Utf8 Class Initialized
DEBUG - 2011-05-22 11:11:33 --> UTF-8 Support Enabled
DEBUG - 2011-05-22 11:11:33 --> URI Class Initialized
DEBUG - 2011-05-22 11:11:33 --> Router Class Initialized
DEBUG - 2011-05-22 11:11:33 --> Output Class Initialized
DEBUG - 2011-05-22 11:11:33 --> Input Class Initialized
DEBUG - 2011-05-22 11:11:33 --> Global POST and COOKIE data sanitized
DEBUG - 2011-05-22 11:11:33 --> Language Class Initialized
DEBUG - 2011-05-22 11:11:33 --> Loader Class Initialized
DEBUG - 2011-05-22 11:11:33 --> Controller Class Initialized
DEBUG - 2011-05-22 11:11:33 --> Model Class Initialized
DEBUG - 2011-05-22 11:11:33 --> Model Class Initialized
DEBUG - 2011-05-22 11:11:33 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-05-22 11:11:33 --> Database Driver Class Initialized
DEBUG - 2011-05-22 11:11:34 --> Final output sent to browser
DEBUG - 2011-05-22 11:11:34 --> Total execution time: 0.5573
DEBUG - 2011-05-22 11:11:35 --> Config Class Initialized
DEBUG - 2011-05-22 11:11:35 --> Hooks Class Initialized
DEBUG - 2011-05-22 11:11:35 --> Utf8 Class Initialized
DEBUG - 2011-05-22 11:11:35 --> UTF-8 Support Enabled
DEBUG - 2011-05-22 11:11:35 --> URI Class Initialized
DEBUG - 2011-05-22 11:11:35 --> Router Class Initialized
DEBUG - 2011-05-22 11:11:35 --> Output Class Initialized
DEBUG - 2011-05-22 11:11:35 --> Input Class Initialized
DEBUG - 2011-05-22 11:11:35 --> Global POST and COOKIE data sanitized
DEBUG - 2011-05-22 11:11:35 --> Language Class Initialized
DEBUG - 2011-05-22 11:11:35 --> Loader Class Initialized
DEBUG - 2011-05-22 11:11:35 --> Controller Class Initialized
DEBUG - 2011-05-22 11:11:35 --> Model Class Initialized
DEBUG - 2011-05-22 11:11:35 --> Model Class Initialized
DEBUG - 2011-05-22 11:11:35 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-05-22 11:11:35 --> Database Driver Class Initialized
DEBUG - 2011-05-22 11:11:35 --> Config Class Initialized
DEBUG - 2011-05-22 11:11:35 --> Hooks Class Initialized
DEBUG - 2011-05-22 11:11:35 --> Utf8 Class Initialized
DEBUG - 2011-05-22 11:11:35 --> UTF-8 Support Enabled
DEBUG - 2011-05-22 11:11:35 --> URI Class Initialized
DEBUG - 2011-05-22 11:11:35 --> Router Class Initialized
DEBUG - 2011-05-22 11:11:35 --> Output Class Initialized
DEBUG - 2011-05-22 11:11:35 --> Input Class Initialized
DEBUG - 2011-05-22 11:11:35 --> Global POST and COOKIE data sanitized
DEBUG - 2011-05-22 11:11:35 --> Language Class Initialized
DEBUG - 2011-05-22 11:11:35 --> Loader Class Initialized
DEBUG - 2011-05-22 11:11:35 --> Controller Class Initialized
ERROR - 2011-05-22 11:11:35 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-05-22 11:11:35 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-05-22 11:11:35 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-05-22 11:11:35 --> Model Class Initialized
DEBUG - 2011-05-22 11:11:35 --> Model Class Initialized
DEBUG - 2011-05-22 11:11:35 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-05-22 11:11:35 --> Database Driver Class Initialized
DEBUG - 2011-05-22 11:11:35 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-05-22 11:11:35 --> Helper loaded: url_helper
DEBUG - 2011-05-22 11:11:35 --> File loaded: application/views/common/header.php
DEBUG - 2011-05-22 11:11:35 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-05-22 11:11:35 --> File loaded: application/views/common/footer.php
DEBUG - 2011-05-22 11:11:35 --> File loaded: application/views/layout/main.php
DEBUG - 2011-05-22 11:11:35 --> Final output sent to browser
DEBUG - 2011-05-22 11:11:35 --> Total execution time: 0.0339
DEBUG - 2011-05-22 11:11:36 --> Final output sent to browser
DEBUG - 2011-05-22 11:11:36 --> Total execution time: 0.4765
DEBUG - 2011-05-22 11:11:46 --> Config Class Initialized
DEBUG - 2011-05-22 11:11:46 --> Hooks Class Initialized
DEBUG - 2011-05-22 11:11:46 --> Utf8 Class Initialized
DEBUG - 2011-05-22 11:11:46 --> UTF-8 Support Enabled
DEBUG - 2011-05-22 11:11:46 --> URI Class Initialized
DEBUG - 2011-05-22 11:11:46 --> Router Class Initialized
DEBUG - 2011-05-22 11:11:46 --> Output Class Initialized
DEBUG - 2011-05-22 11:11:46 --> Input Class Initialized
DEBUG - 2011-05-22 11:11:46 --> Global POST and COOKIE data sanitized
DEBUG - 2011-05-22 11:11:46 --> Language Class Initialized
DEBUG - 2011-05-22 11:11:46 --> Loader Class Initialized
DEBUG - 2011-05-22 11:11:46 --> Controller Class Initialized
DEBUG - 2011-05-22 11:11:46 --> Model Class Initialized
DEBUG - 2011-05-22 11:11:46 --> Model Class Initialized
DEBUG - 2011-05-22 11:11:46 --> Model Class Initialized
DEBUG - 2011-05-22 11:11:46 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-05-22 11:11:46 --> Database Driver Class Initialized
DEBUG - 2011-05-22 11:11:46 --> File loaded: application/views/table/main.php
DEBUG - 2011-05-22 11:11:46 --> Helper loaded: url_helper
DEBUG - 2011-05-22 11:11:46 --> File loaded: application/views/common/header.php
DEBUG - 2011-05-22 11:11:46 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-05-22 11:11:46 --> File loaded: application/views/common/footer.php
DEBUG - 2011-05-22 11:11:46 --> File loaded: application/views/layout/main.php
DEBUG - 2011-05-22 11:11:46 --> Final output sent to browser
DEBUG - 2011-05-22 11:11:46 --> Total execution time: 0.1992
DEBUG - 2011-05-22 11:11:55 --> Config Class Initialized
DEBUG - 2011-05-22 11:11:55 --> Hooks Class Initialized
DEBUG - 2011-05-22 11:11:55 --> Utf8 Class Initialized
DEBUG - 2011-05-22 11:11:55 --> UTF-8 Support Enabled
DEBUG - 2011-05-22 11:11:55 --> URI Class Initialized
DEBUG - 2011-05-22 11:11:55 --> Router Class Initialized
DEBUG - 2011-05-22 11:11:55 --> Output Class Initialized
DEBUG - 2011-05-22 11:11:55 --> Input Class Initialized
DEBUG - 2011-05-22 11:11:55 --> Global POST and COOKIE data sanitized
DEBUG - 2011-05-22 11:11:55 --> Language Class Initialized
DEBUG - 2011-05-22 11:11:55 --> Loader Class Initialized
DEBUG - 2011-05-22 11:11:55 --> Controller Class Initialized
ERROR - 2011-05-22 11:11:55 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-05-22 11:11:55 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-05-22 11:11:55 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-05-22 11:11:55 --> Model Class Initialized
DEBUG - 2011-05-22 11:11:55 --> Model Class Initialized
DEBUG - 2011-05-22 11:11:55 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-05-22 11:11:55 --> Database Driver Class Initialized
DEBUG - 2011-05-22 11:11:55 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-05-22 11:11:55 --> Helper loaded: url_helper
DEBUG - 2011-05-22 11:11:55 --> File loaded: application/views/common/header.php
DEBUG - 2011-05-22 11:11:55 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-05-22 11:11:55 --> File loaded: application/views/common/footer.php
DEBUG - 2011-05-22 11:11:55 --> File loaded: application/views/layout/main.php
DEBUG - 2011-05-22 11:11:55 --> Final output sent to browser
DEBUG - 2011-05-22 11:11:55 --> Total execution time: 0.0284
DEBUG - 2011-05-22 11:11:56 --> Config Class Initialized
DEBUG - 2011-05-22 11:11:56 --> Hooks Class Initialized
DEBUG - 2011-05-22 11:11:56 --> Utf8 Class Initialized
DEBUG - 2011-05-22 11:11:56 --> UTF-8 Support Enabled
DEBUG - 2011-05-22 11:11:56 --> URI Class Initialized
DEBUG - 2011-05-22 11:11:56 --> Router Class Initialized
DEBUG - 2011-05-22 11:11:56 --> Output Class Initialized
DEBUG - 2011-05-22 11:11:56 --> Input Class Initialized
DEBUG - 2011-05-22 11:11:56 --> Global POST and COOKIE data sanitized
DEBUG - 2011-05-22 11:11:56 --> Language Class Initialized
DEBUG - 2011-05-22 11:11:56 --> Loader Class Initialized
DEBUG - 2011-05-22 11:11:56 --> Controller Class Initialized
DEBUG - 2011-05-22 11:11:56 --> Model Class Initialized
DEBUG - 2011-05-22 11:11:56 --> Model Class Initialized
DEBUG - 2011-05-22 11:11:56 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-05-22 11:11:56 --> Database Driver Class Initialized
DEBUG - 2011-05-22 11:11:57 --> Final output sent to browser
DEBUG - 2011-05-22 11:11:57 --> Total execution time: 0.7573
DEBUG - 2011-05-22 11:11:57 --> Config Class Initialized
DEBUG - 2011-05-22 11:11:57 --> Hooks Class Initialized
DEBUG - 2011-05-22 11:11:57 --> Utf8 Class Initialized
DEBUG - 2011-05-22 11:11:57 --> UTF-8 Support Enabled
DEBUG - 2011-05-22 11:11:57 --> URI Class Initialized
DEBUG - 2011-05-22 11:11:57 --> Router Class Initialized
DEBUG - 2011-05-22 11:11:57 --> No URI present. Default controller set.
DEBUG - 2011-05-22 11:11:57 --> Output Class Initialized
DEBUG - 2011-05-22 11:11:57 --> Input Class Initialized
DEBUG - 2011-05-22 11:11:57 --> Global POST and COOKIE data sanitized
DEBUG - 2011-05-22 11:11:57 --> Language Class Initialized
DEBUG - 2011-05-22 11:11:57 --> Loader Class Initialized
DEBUG - 2011-05-22 11:11:57 --> Controller Class Initialized
DEBUG - 2011-05-22 11:11:57 --> File loaded: application/views/splash/main.php
DEBUG - 2011-05-22 11:11:57 --> Helper loaded: url_helper
DEBUG - 2011-05-22 11:11:57 --> File loaded: application/views/common/header.php
DEBUG - 2011-05-22 11:11:57 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-05-22 11:11:57 --> File loaded: application/views/common/footer.php
DEBUG - 2011-05-22 11:11:57 --> File loaded: application/views/layout/main.php
DEBUG - 2011-05-22 11:11:57 --> Final output sent to browser
DEBUG - 2011-05-22 11:11:57 --> Total execution time: 0.0123
DEBUG - 2011-05-22 11:11:58 --> Config Class Initialized
DEBUG - 2011-05-22 11:11:58 --> Hooks Class Initialized
DEBUG - 2011-05-22 11:11:58 --> Utf8 Class Initialized
DEBUG - 2011-05-22 11:11:58 --> UTF-8 Support Enabled
DEBUG - 2011-05-22 11:11:58 --> URI Class Initialized
DEBUG - 2011-05-22 11:11:58 --> Router Class Initialized
DEBUG - 2011-05-22 11:11:58 --> Output Class Initialized
DEBUG - 2011-05-22 11:11:58 --> Input Class Initialized
DEBUG - 2011-05-22 11:11:58 --> Global POST and COOKIE data sanitized
DEBUG - 2011-05-22 11:11:58 --> Language Class Initialized
DEBUG - 2011-05-22 11:11:58 --> Loader Class Initialized
DEBUG - 2011-05-22 11:11:58 --> Controller Class Initialized
DEBUG - 2011-05-22 11:11:58 --> Model Class Initialized
DEBUG - 2011-05-22 11:11:58 --> Model Class Initialized
DEBUG - 2011-05-22 11:11:58 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-05-22 11:11:58 --> Database Driver Class Initialized
DEBUG - 2011-05-22 11:11:58 --> Final output sent to browser
DEBUG - 2011-05-22 11:11:58 --> Total execution time: 0.5281
DEBUG - 2011-05-22 11:12:36 --> Config Class Initialized
DEBUG - 2011-05-22 11:12:36 --> Hooks Class Initialized
DEBUG - 2011-05-22 11:12:36 --> Utf8 Class Initialized
DEBUG - 2011-05-22 11:12:36 --> UTF-8 Support Enabled
DEBUG - 2011-05-22 11:12:36 --> URI Class Initialized
DEBUG - 2011-05-22 11:12:36 --> Router Class Initialized
DEBUG - 2011-05-22 11:12:36 --> Output Class Initialized
DEBUG - 2011-05-22 11:12:36 --> Input Class Initialized
DEBUG - 2011-05-22 11:12:36 --> Global POST and COOKIE data sanitized
DEBUG - 2011-05-22 11:12:36 --> Language Class Initialized
DEBUG - 2011-05-22 11:12:36 --> Loader Class Initialized
DEBUG - 2011-05-22 11:12:36 --> Controller Class Initialized
ERROR - 2011-05-22 11:12:36 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-05-22 11:12:36 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-05-22 11:12:36 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-05-22 11:12:36 --> Model Class Initialized
DEBUG - 2011-05-22 11:12:36 --> Model Class Initialized
DEBUG - 2011-05-22 11:12:36 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-05-22 11:12:36 --> Database Driver Class Initialized
DEBUG - 2011-05-22 11:12:36 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-05-22 11:12:36 --> Helper loaded: url_helper
DEBUG - 2011-05-22 11:12:36 --> File loaded: application/views/common/header.php
DEBUG - 2011-05-22 11:12:36 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-05-22 11:12:36 --> File loaded: application/views/common/footer.php
DEBUG - 2011-05-22 11:12:36 --> File loaded: application/views/layout/main.php
DEBUG - 2011-05-22 11:12:36 --> Final output sent to browser
DEBUG - 2011-05-22 11:12:36 --> Total execution time: 0.0318
DEBUG - 2011-05-22 11:12:37 --> Config Class Initialized
DEBUG - 2011-05-22 11:12:37 --> Hooks Class Initialized
DEBUG - 2011-05-22 11:12:37 --> Utf8 Class Initialized
DEBUG - 2011-05-22 11:12:37 --> UTF-8 Support Enabled
DEBUG - 2011-05-22 11:12:37 --> URI Class Initialized
DEBUG - 2011-05-22 11:12:37 --> Router Class Initialized
DEBUG - 2011-05-22 11:12:37 --> Output Class Initialized
DEBUG - 2011-05-22 11:12:37 --> Input Class Initialized
DEBUG - 2011-05-22 11:12:37 --> Global POST and COOKIE data sanitized
DEBUG - 2011-05-22 11:12:37 --> Language Class Initialized
DEBUG - 2011-05-22 11:12:37 --> Loader Class Initialized
DEBUG - 2011-05-22 11:12:37 --> Controller Class Initialized
DEBUG - 2011-05-22 11:12:37 --> Model Class Initialized
DEBUG - 2011-05-22 11:12:37 --> Model Class Initialized
DEBUG - 2011-05-22 11:12:37 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-05-22 11:12:37 --> Database Driver Class Initialized
DEBUG - 2011-05-22 11:12:37 --> Final output sent to browser
DEBUG - 2011-05-22 11:12:37 --> Total execution time: 0.6181
DEBUG - 2011-05-22 11:12:39 --> Config Class Initialized
DEBUG - 2011-05-22 11:12:39 --> Hooks Class Initialized
DEBUG - 2011-05-22 11:12:39 --> Utf8 Class Initialized
DEBUG - 2011-05-22 11:12:39 --> UTF-8 Support Enabled
DEBUG - 2011-05-22 11:12:39 --> URI Class Initialized
DEBUG - 2011-05-22 11:12:39 --> Router Class Initialized
DEBUG - 2011-05-22 11:12:39 --> Output Class Initialized
DEBUG - 2011-05-22 11:12:39 --> Input Class Initialized
DEBUG - 2011-05-22 11:12:39 --> Global POST and COOKIE data sanitized
DEBUG - 2011-05-22 11:12:39 --> Language Class Initialized
DEBUG - 2011-05-22 11:12:39 --> Loader Class Initialized
DEBUG - 2011-05-22 11:12:39 --> Controller Class Initialized
DEBUG - 2011-05-22 11:12:39 --> Model Class Initialized
DEBUG - 2011-05-22 11:12:39 --> Model Class Initialized
DEBUG - 2011-05-22 11:12:39 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-05-22 11:12:39 --> Database Driver Class Initialized
DEBUG - 2011-05-22 11:12:39 --> Config Class Initialized
DEBUG - 2011-05-22 11:12:39 --> Hooks Class Initialized
DEBUG - 2011-05-22 11:12:39 --> Utf8 Class Initialized
DEBUG - 2011-05-22 11:12:39 --> UTF-8 Support Enabled
DEBUG - 2011-05-22 11:12:39 --> URI Class Initialized
DEBUG - 2011-05-22 11:12:39 --> Router Class Initialized
DEBUG - 2011-05-22 11:12:39 --> Output Class Initialized
DEBUG - 2011-05-22 11:12:39 --> Input Class Initialized
DEBUG - 2011-05-22 11:12:39 --> Global POST and COOKIE data sanitized
DEBUG - 2011-05-22 11:12:39 --> Language Class Initialized
DEBUG - 2011-05-22 11:12:39 --> Loader Class Initialized
DEBUG - 2011-05-22 11:12:39 --> Controller Class Initialized
ERROR - 2011-05-22 11:12:39 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-05-22 11:12:39 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-05-22 11:12:39 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-05-22 11:12:39 --> Model Class Initialized
DEBUG - 2011-05-22 11:12:39 --> Model Class Initialized
DEBUG - 2011-05-22 11:12:39 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-05-22 11:12:39 --> Database Driver Class Initialized
DEBUG - 2011-05-22 11:12:39 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-05-22 11:12:39 --> Helper loaded: url_helper
DEBUG - 2011-05-22 11:12:39 --> File loaded: application/views/common/header.php
DEBUG - 2011-05-22 11:12:39 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-05-22 11:12:39 --> File loaded: application/views/common/footer.php
DEBUG - 2011-05-22 11:12:39 --> File loaded: application/views/layout/main.php
DEBUG - 2011-05-22 11:12:39 --> Final output sent to browser
DEBUG - 2011-05-22 11:12:39 --> Total execution time: 0.0292
DEBUG - 2011-05-22 11:12:39 --> Config Class Initialized
DEBUG - 2011-05-22 11:12:39 --> Hooks Class Initialized
DEBUG - 2011-05-22 11:12:39 --> Utf8 Class Initialized
DEBUG - 2011-05-22 11:12:39 --> UTF-8 Support Enabled
DEBUG - 2011-05-22 11:12:39 --> URI Class Initialized
DEBUG - 2011-05-22 11:12:39 --> Router Class Initialized
DEBUG - 2011-05-22 11:12:39 --> Output Class Initialized
DEBUG - 2011-05-22 11:12:39 --> Input Class Initialized
DEBUG - 2011-05-22 11:12:39 --> Global POST and COOKIE data sanitized
DEBUG - 2011-05-22 11:12:39 --> Language Class Initialized
DEBUG - 2011-05-22 11:12:39 --> Loader Class Initialized
DEBUG - 2011-05-22 11:12:39 --> Controller Class Initialized
ERROR - 2011-05-22 11:12:39 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-05-22 11:12:39 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-05-22 11:12:39 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-05-22 11:12:39 --> Model Class Initialized
DEBUG - 2011-05-22 11:12:39 --> Model Class Initialized
DEBUG - 2011-05-22 11:12:39 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-05-22 11:12:39 --> Database Driver Class Initialized
DEBUG - 2011-05-22 11:12:39 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-05-22 11:12:39 --> Helper loaded: url_helper
DEBUG - 2011-05-22 11:12:39 --> File loaded: application/views/common/header.php
DEBUG - 2011-05-22 11:12:39 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-05-22 11:12:39 --> File loaded: application/views/common/footer.php
DEBUG - 2011-05-22 11:12:39 --> File loaded: application/views/layout/main.php
DEBUG - 2011-05-22 11:12:39 --> Final output sent to browser
DEBUG - 2011-05-22 11:12:39 --> Total execution time: 0.0364
DEBUG - 2011-05-22 11:12:39 --> Final output sent to browser
DEBUG - 2011-05-22 11:12:39 --> Total execution time: 0.5898
DEBUG - 2011-05-22 11:12:55 --> Config Class Initialized
DEBUG - 2011-05-22 11:12:55 --> Hooks Class Initialized
DEBUG - 2011-05-22 11:12:55 --> Utf8 Class Initialized
DEBUG - 2011-05-22 11:12:55 --> UTF-8 Support Enabled
DEBUG - 2011-05-22 11:12:55 --> URI Class Initialized
DEBUG - 2011-05-22 11:12:55 --> Router Class Initialized
DEBUG - 2011-05-22 11:12:55 --> Output Class Initialized
DEBUG - 2011-05-22 11:12:55 --> Input Class Initialized
DEBUG - 2011-05-22 11:12:55 --> Global POST and COOKIE data sanitized
DEBUG - 2011-05-22 11:12:55 --> Language Class Initialized
DEBUG - 2011-05-22 11:12:55 --> Loader Class Initialized
DEBUG - 2011-05-22 11:12:55 --> Controller Class Initialized
ERROR - 2011-05-22 11:12:55 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-05-22 11:12:55 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-05-22 11:12:55 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-05-22 11:12:55 --> Model Class Initialized
DEBUG - 2011-05-22 11:12:55 --> Model Class Initialized
DEBUG - 2011-05-22 11:12:55 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-05-22 11:12:55 --> Database Driver Class Initialized
DEBUG - 2011-05-22 11:12:55 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-05-22 11:12:55 --> Helper loaded: url_helper
DEBUG - 2011-05-22 11:12:55 --> File loaded: application/views/common/header.php
DEBUG - 2011-05-22 11:12:55 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-05-22 11:12:55 --> File loaded: application/views/common/footer.php
DEBUG - 2011-05-22 11:12:55 --> File loaded: application/views/layout/main.php
DEBUG - 2011-05-22 11:12:55 --> Final output sent to browser
DEBUG - 2011-05-22 11:12:55 --> Total execution time: 0.0305
DEBUG - 2011-05-22 11:12:58 --> Config Class Initialized
DEBUG - 2011-05-22 11:12:58 --> Hooks Class Initialized
DEBUG - 2011-05-22 11:12:58 --> Utf8 Class Initialized
DEBUG - 2011-05-22 11:12:58 --> UTF-8 Support Enabled
DEBUG - 2011-05-22 11:12:58 --> URI Class Initialized
DEBUG - 2011-05-22 11:12:58 --> Router Class Initialized
DEBUG - 2011-05-22 11:12:58 --> Output Class Initialized
DEBUG - 2011-05-22 11:12:58 --> Input Class Initialized
DEBUG - 2011-05-22 11:12:58 --> Global POST and COOKIE data sanitized
DEBUG - 2011-05-22 11:12:58 --> Language Class Initialized
DEBUG - 2011-05-22 11:12:58 --> Loader Class Initialized
DEBUG - 2011-05-22 11:12:58 --> Controller Class Initialized
DEBUG - 2011-05-22 11:12:58 --> Model Class Initialized
DEBUG - 2011-05-22 11:12:58 --> Model Class Initialized
DEBUG - 2011-05-22 11:12:58 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-05-22 11:12:58 --> Database Driver Class Initialized
DEBUG - 2011-05-22 11:12:58 --> Final output sent to browser
DEBUG - 2011-05-22 11:12:58 --> Total execution time: 0.4844
DEBUG - 2011-05-22 11:13:02 --> Config Class Initialized
DEBUG - 2011-05-22 11:13:02 --> Hooks Class Initialized
DEBUG - 2011-05-22 11:13:02 --> Utf8 Class Initialized
DEBUG - 2011-05-22 11:13:02 --> UTF-8 Support Enabled
DEBUG - 2011-05-22 11:13:02 --> URI Class Initialized
DEBUG - 2011-05-22 11:13:02 --> Router Class Initialized
DEBUG - 2011-05-22 11:13:02 --> Output Class Initialized
DEBUG - 2011-05-22 11:13:02 --> Input Class Initialized
DEBUG - 2011-05-22 11:13:02 --> Global POST and COOKIE data sanitized
DEBUG - 2011-05-22 11:13:02 --> Language Class Initialized
DEBUG - 2011-05-22 11:13:02 --> Loader Class Initialized
DEBUG - 2011-05-22 11:13:02 --> Controller Class Initialized
ERROR - 2011-05-22 11:13:02 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-05-22 11:13:02 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-05-22 11:13:02 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-05-22 11:13:02 --> Model Class Initialized
DEBUG - 2011-05-22 11:13:02 --> Model Class Initialized
DEBUG - 2011-05-22 11:13:02 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-05-22 11:13:02 --> Database Driver Class Initialized
DEBUG - 2011-05-22 11:13:02 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-05-22 11:13:02 --> Helper loaded: url_helper
DEBUG - 2011-05-22 11:13:02 --> File loaded: application/views/common/header.php
DEBUG - 2011-05-22 11:13:02 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-05-22 11:13:02 --> File loaded: application/views/common/footer.php
DEBUG - 2011-05-22 11:13:02 --> File loaded: application/views/layout/main.php
DEBUG - 2011-05-22 11:13:02 --> Final output sent to browser
DEBUG - 2011-05-22 11:13:02 --> Total execution time: 0.0308
DEBUG - 2011-05-22 11:13:05 --> Config Class Initialized
DEBUG - 2011-05-22 11:13:05 --> Hooks Class Initialized
DEBUG - 2011-05-22 11:13:05 --> Utf8 Class Initialized
DEBUG - 2011-05-22 11:13:05 --> UTF-8 Support Enabled
DEBUG - 2011-05-22 11:13:05 --> URI Class Initialized
DEBUG - 2011-05-22 11:13:05 --> Router Class Initialized
DEBUG - 2011-05-22 11:13:05 --> Output Class Initialized
DEBUG - 2011-05-22 11:13:05 --> Input Class Initialized
DEBUG - 2011-05-22 11:13:05 --> Global POST and COOKIE data sanitized
DEBUG - 2011-05-22 11:13:05 --> Language Class Initialized
DEBUG - 2011-05-22 11:13:05 --> Loader Class Initialized
DEBUG - 2011-05-22 11:13:05 --> Controller Class Initialized
DEBUG - 2011-05-22 11:13:05 --> Model Class Initialized
DEBUG - 2011-05-22 11:13:05 --> Model Class Initialized
DEBUG - 2011-05-22 11:13:05 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-05-22 11:13:05 --> Database Driver Class Initialized
DEBUG - 2011-05-22 11:13:05 --> Final output sent to browser
DEBUG - 2011-05-22 11:13:05 --> Total execution time: 0.4557
DEBUG - 2011-05-22 11:13:11 --> Config Class Initialized
DEBUG - 2011-05-22 11:13:11 --> Hooks Class Initialized
DEBUG - 2011-05-22 11:13:11 --> Utf8 Class Initialized
DEBUG - 2011-05-22 11:13:11 --> UTF-8 Support Enabled
DEBUG - 2011-05-22 11:13:11 --> URI Class Initialized
DEBUG - 2011-05-22 11:13:11 --> Router Class Initialized
DEBUG - 2011-05-22 11:13:11 --> Output Class Initialized
DEBUG - 2011-05-22 11:13:11 --> Input Class Initialized
DEBUG - 2011-05-22 11:13:11 --> Global POST and COOKIE data sanitized
DEBUG - 2011-05-22 11:13:11 --> Language Class Initialized
DEBUG - 2011-05-22 11:13:11 --> Loader Class Initialized
DEBUG - 2011-05-22 11:13:11 --> Controller Class Initialized
ERROR - 2011-05-22 11:13:11 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-05-22 11:13:11 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-05-22 11:13:11 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-05-22 11:13:11 --> Model Class Initialized
DEBUG - 2011-05-22 11:13:11 --> Model Class Initialized
DEBUG - 2011-05-22 11:13:11 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-05-22 11:13:11 --> Database Driver Class Initialized
DEBUG - 2011-05-22 11:13:11 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-05-22 11:13:11 --> Helper loaded: url_helper
DEBUG - 2011-05-22 11:13:11 --> File loaded: application/views/common/header.php
DEBUG - 2011-05-22 11:13:11 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-05-22 11:13:11 --> File loaded: application/views/common/footer.php
DEBUG - 2011-05-22 11:13:11 --> File loaded: application/views/layout/main.php
DEBUG - 2011-05-22 11:13:11 --> Final output sent to browser
DEBUG - 2011-05-22 11:13:11 --> Total execution time: 0.1007
DEBUG - 2011-05-22 11:13:11 --> Config Class Initialized
DEBUG - 2011-05-22 11:13:11 --> Hooks Class Initialized
DEBUG - 2011-05-22 11:13:11 --> Utf8 Class Initialized
DEBUG - 2011-05-22 11:13:11 --> UTF-8 Support Enabled
DEBUG - 2011-05-22 11:13:11 --> URI Class Initialized
DEBUG - 2011-05-22 11:13:11 --> Router Class Initialized
DEBUG - 2011-05-22 11:13:11 --> Output Class Initialized
DEBUG - 2011-05-22 11:13:11 --> Input Class Initialized
DEBUG - 2011-05-22 11:13:11 --> Global POST and COOKIE data sanitized
DEBUG - 2011-05-22 11:13:11 --> Language Class Initialized
DEBUG - 2011-05-22 11:13:11 --> Loader Class Initialized
DEBUG - 2011-05-22 11:13:11 --> Controller Class Initialized
DEBUG - 2011-05-22 11:13:11 --> Model Class Initialized
DEBUG - 2011-05-22 11:13:11 --> Model Class Initialized
DEBUG - 2011-05-22 11:13:11 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-05-22 11:13:11 --> Database Driver Class Initialized
DEBUG - 2011-05-22 11:13:12 --> Final output sent to browser
DEBUG - 2011-05-22 11:13:12 --> Total execution time: 0.5038
DEBUG - 2011-05-22 11:13:14 --> Config Class Initialized
DEBUG - 2011-05-22 11:13:14 --> Hooks Class Initialized
DEBUG - 2011-05-22 11:13:14 --> Utf8 Class Initialized
DEBUG - 2011-05-22 11:13:14 --> UTF-8 Support Enabled
DEBUG - 2011-05-22 11:13:14 --> URI Class Initialized
DEBUG - 2011-05-22 11:13:14 --> Router Class Initialized
DEBUG - 2011-05-22 11:13:14 --> Output Class Initialized
DEBUG - 2011-05-22 11:13:14 --> Input Class Initialized
DEBUG - 2011-05-22 11:13:14 --> Global POST and COOKIE data sanitized
DEBUG - 2011-05-22 11:13:14 --> Language Class Initialized
DEBUG - 2011-05-22 11:13:14 --> Loader Class Initialized
DEBUG - 2011-05-22 11:13:14 --> Controller Class Initialized
DEBUG - 2011-05-22 11:13:14 --> Model Class Initialized
DEBUG - 2011-05-22 11:13:14 --> Model Class Initialized
DEBUG - 2011-05-22 11:13:14 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-05-22 11:13:14 --> Database Driver Class Initialized
DEBUG - 2011-05-22 11:13:14 --> Final output sent to browser
DEBUG - 2011-05-22 11:13:14 --> Total execution time: 0.6420
DEBUG - 2011-05-22 11:13:50 --> Config Class Initialized
DEBUG - 2011-05-22 11:13:50 --> Hooks Class Initialized
DEBUG - 2011-05-22 11:13:50 --> Utf8 Class Initialized
DEBUG - 2011-05-22 11:13:50 --> UTF-8 Support Enabled
DEBUG - 2011-05-22 11:13:50 --> URI Class Initialized
DEBUG - 2011-05-22 11:13:50 --> Router Class Initialized
DEBUG - 2011-05-22 11:13:50 --> Output Class Initialized
DEBUG - 2011-05-22 11:13:50 --> Input Class Initialized
DEBUG - 2011-05-22 11:13:50 --> Global POST and COOKIE data sanitized
DEBUG - 2011-05-22 11:13:50 --> Language Class Initialized
DEBUG - 2011-05-22 11:13:50 --> Loader Class Initialized
DEBUG - 2011-05-22 11:13:50 --> Controller Class Initialized
ERROR - 2011-05-22 11:13:50 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-05-22 11:13:50 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-05-22 11:13:50 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-05-22 11:13:50 --> Model Class Initialized
DEBUG - 2011-05-22 11:13:50 --> Model Class Initialized
DEBUG - 2011-05-22 11:13:50 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-05-22 11:13:50 --> Database Driver Class Initialized
DEBUG - 2011-05-22 11:13:50 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-05-22 11:13:50 --> Helper loaded: url_helper
DEBUG - 2011-05-22 11:13:50 --> File loaded: application/views/common/header.php
DEBUG - 2011-05-22 11:13:50 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-05-22 11:13:50 --> File loaded: application/views/common/footer.php
DEBUG - 2011-05-22 11:13:50 --> File loaded: application/views/layout/main.php
DEBUG - 2011-05-22 11:13:50 --> Final output sent to browser
DEBUG - 2011-05-22 11:13:50 --> Total execution time: 0.0277
DEBUG - 2011-05-22 11:13:50 --> Config Class Initialized
DEBUG - 2011-05-22 11:13:50 --> Hooks Class Initialized
DEBUG - 2011-05-22 11:13:50 --> Utf8 Class Initialized
DEBUG - 2011-05-22 11:13:50 --> UTF-8 Support Enabled
DEBUG - 2011-05-22 11:13:50 --> URI Class Initialized
DEBUG - 2011-05-22 11:13:50 --> Router Class Initialized
DEBUG - 2011-05-22 11:13:50 --> Output Class Initialized
DEBUG - 2011-05-22 11:13:50 --> Input Class Initialized
DEBUG - 2011-05-22 11:13:50 --> Global POST and COOKIE data sanitized
DEBUG - 2011-05-22 11:13:50 --> Language Class Initialized
DEBUG - 2011-05-22 11:13:50 --> Loader Class Initialized
DEBUG - 2011-05-22 11:13:50 --> Controller Class Initialized
DEBUG - 2011-05-22 11:13:50 --> Model Class Initialized
DEBUG - 2011-05-22 11:13:50 --> Model Class Initialized
DEBUG - 2011-05-22 11:13:50 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-05-22 11:13:50 --> Database Driver Class Initialized
DEBUG - 2011-05-22 11:13:51 --> Final output sent to browser
DEBUG - 2011-05-22 11:13:51 --> Total execution time: 0.5868
DEBUG - 2011-05-22 11:13:52 --> Config Class Initialized
DEBUG - 2011-05-22 11:13:52 --> Hooks Class Initialized
DEBUG - 2011-05-22 11:13:52 --> Utf8 Class Initialized
DEBUG - 2011-05-22 11:13:52 --> UTF-8 Support Enabled
DEBUG - 2011-05-22 11:13:52 --> URI Class Initialized
DEBUG - 2011-05-22 11:13:52 --> Router Class Initialized
DEBUG - 2011-05-22 11:13:52 --> Output Class Initialized
DEBUG - 2011-05-22 11:13:52 --> Input Class Initialized
DEBUG - 2011-05-22 11:13:52 --> Global POST and COOKIE data sanitized
DEBUG - 2011-05-22 11:13:52 --> Language Class Initialized
DEBUG - 2011-05-22 11:13:52 --> Loader Class Initialized
DEBUG - 2011-05-22 11:13:52 --> Controller Class Initialized
DEBUG - 2011-05-22 11:13:52 --> Model Class Initialized
DEBUG - 2011-05-22 11:13:52 --> Model Class Initialized
DEBUG - 2011-05-22 11:13:52 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-05-22 11:13:52 --> Database Driver Class Initialized
DEBUG - 2011-05-22 11:13:53 --> Config Class Initialized
DEBUG - 2011-05-22 11:13:53 --> Hooks Class Initialized
DEBUG - 2011-05-22 11:13:53 --> Utf8 Class Initialized
DEBUG - 2011-05-22 11:13:53 --> UTF-8 Support Enabled
DEBUG - 2011-05-22 11:13:53 --> URI Class Initialized
DEBUG - 2011-05-22 11:13:53 --> Router Class Initialized
DEBUG - 2011-05-22 11:13:53 --> Output Class Initialized
DEBUG - 2011-05-22 11:13:53 --> Input Class Initialized
DEBUG - 2011-05-22 11:13:53 --> Global POST and COOKIE data sanitized
DEBUG - 2011-05-22 11:13:53 --> Language Class Initialized
DEBUG - 2011-05-22 11:13:53 --> Loader Class Initialized
DEBUG - 2011-05-22 11:13:53 --> Controller Class Initialized
ERROR - 2011-05-22 11:13:53 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-05-22 11:13:53 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-05-22 11:13:53 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-05-22 11:13:53 --> Model Class Initialized
DEBUG - 2011-05-22 11:13:53 --> Model Class Initialized
DEBUG - 2011-05-22 11:13:53 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-05-22 11:13:53 --> Database Driver Class Initialized
DEBUG - 2011-05-22 11:13:53 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-05-22 11:13:53 --> Helper loaded: url_helper
DEBUG - 2011-05-22 11:13:53 --> File loaded: application/views/common/header.php
DEBUG - 2011-05-22 11:13:53 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-05-22 11:13:53 --> File loaded: application/views/common/footer.php
DEBUG - 2011-05-22 11:13:53 --> File loaded: application/views/layout/main.php
DEBUG - 2011-05-22 11:13:53 --> Final output sent to browser
DEBUG - 2011-05-22 11:13:53 --> Total execution time: 0.0372
DEBUG - 2011-05-22 11:13:53 --> Final output sent to browser
DEBUG - 2011-05-22 11:13:53 --> Total execution time: 0.5122
DEBUG - 2011-05-22 11:14:02 --> Config Class Initialized
DEBUG - 2011-05-22 11:14:02 --> Hooks Class Initialized
DEBUG - 2011-05-22 11:14:02 --> Utf8 Class Initialized
DEBUG - 2011-05-22 11:14:02 --> UTF-8 Support Enabled
DEBUG - 2011-05-22 11:14:02 --> URI Class Initialized
DEBUG - 2011-05-22 11:14:02 --> Router Class Initialized
DEBUG - 2011-05-22 11:14:02 --> Output Class Initialized
DEBUG - 2011-05-22 11:14:02 --> Input Class Initialized
DEBUG - 2011-05-22 11:14:02 --> Global POST and COOKIE data sanitized
DEBUG - 2011-05-22 11:14:02 --> Language Class Initialized
DEBUG - 2011-05-22 11:14:02 --> Loader Class Initialized
DEBUG - 2011-05-22 11:14:02 --> Controller Class Initialized
ERROR - 2011-05-22 11:14:02 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-05-22 11:14:02 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-05-22 11:14:02 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-05-22 11:14:02 --> Model Class Initialized
DEBUG - 2011-05-22 11:14:02 --> Model Class Initialized
DEBUG - 2011-05-22 11:14:02 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-05-22 11:14:02 --> Database Driver Class Initialized
DEBUG - 2011-05-22 11:14:02 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-05-22 11:14:02 --> Helper loaded: url_helper
DEBUG - 2011-05-22 11:14:02 --> File loaded: application/views/common/header.php
DEBUG - 2011-05-22 11:14:02 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-05-22 11:14:02 --> File loaded: application/views/common/footer.php
DEBUG - 2011-05-22 11:14:02 --> File loaded: application/views/layout/main.php
DEBUG - 2011-05-22 11:14:02 --> Final output sent to browser
DEBUG - 2011-05-22 11:14:02 --> Total execution time: 0.0410
DEBUG - 2011-05-22 11:14:02 --> Config Class Initialized
DEBUG - 2011-05-22 11:14:02 --> Hooks Class Initialized
DEBUG - 2011-05-22 11:14:02 --> Utf8 Class Initialized
DEBUG - 2011-05-22 11:14:02 --> UTF-8 Support Enabled
DEBUG - 2011-05-22 11:14:02 --> URI Class Initialized
DEBUG - 2011-05-22 11:14:02 --> Router Class Initialized
DEBUG - 2011-05-22 11:14:02 --> Output Class Initialized
DEBUG - 2011-05-22 11:14:02 --> Input Class Initialized
DEBUG - 2011-05-22 11:14:02 --> Global POST and COOKIE data sanitized
DEBUG - 2011-05-22 11:14:02 --> Language Class Initialized
DEBUG - 2011-05-22 11:14:02 --> Loader Class Initialized
DEBUG - 2011-05-22 11:14:02 --> Controller Class Initialized
DEBUG - 2011-05-22 11:14:02 --> Model Class Initialized
DEBUG - 2011-05-22 11:14:02 --> Model Class Initialized
DEBUG - 2011-05-22 11:14:02 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-05-22 11:14:02 --> Database Driver Class Initialized
DEBUG - 2011-05-22 11:14:03 --> Final output sent to browser
DEBUG - 2011-05-22 11:14:03 --> Total execution time: 0.5131
DEBUG - 2011-05-22 11:14:04 --> Config Class Initialized
DEBUG - 2011-05-22 11:14:04 --> Hooks Class Initialized
DEBUG - 2011-05-22 11:14:04 --> Utf8 Class Initialized
DEBUG - 2011-05-22 11:14:04 --> UTF-8 Support Enabled
DEBUG - 2011-05-22 11:14:04 --> URI Class Initialized
DEBUG - 2011-05-22 11:14:04 --> Router Class Initialized
DEBUG - 2011-05-22 11:14:04 --> Output Class Initialized
DEBUG - 2011-05-22 11:14:04 --> Input Class Initialized
DEBUG - 2011-05-22 11:14:04 --> Global POST and COOKIE data sanitized
DEBUG - 2011-05-22 11:14:04 --> Language Class Initialized
DEBUG - 2011-05-22 11:14:04 --> Loader Class Initialized
DEBUG - 2011-05-22 11:14:04 --> Controller Class Initialized
DEBUG - 2011-05-22 11:14:04 --> Model Class Initialized
DEBUG - 2011-05-22 11:14:04 --> Model Class Initialized
DEBUG - 2011-05-22 11:14:04 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-05-22 11:14:04 --> Database Driver Class Initialized
DEBUG - 2011-05-22 11:14:04 --> Config Class Initialized
DEBUG - 2011-05-22 11:14:04 --> Hooks Class Initialized
DEBUG - 2011-05-22 11:14:04 --> Utf8 Class Initialized
DEBUG - 2011-05-22 11:14:04 --> UTF-8 Support Enabled
DEBUG - 2011-05-22 11:14:04 --> URI Class Initialized
DEBUG - 2011-05-22 11:14:04 --> Router Class Initialized
DEBUG - 2011-05-22 11:14:04 --> Output Class Initialized
DEBUG - 2011-05-22 11:14:04 --> Input Class Initialized
DEBUG - 2011-05-22 11:14:04 --> Global POST and COOKIE data sanitized
DEBUG - 2011-05-22 11:14:04 --> Language Class Initialized
DEBUG - 2011-05-22 11:14:04 --> Loader Class Initialized
DEBUG - 2011-05-22 11:14:04 --> Controller Class Initialized
ERROR - 2011-05-22 11:14:04 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-05-22 11:14:04 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-05-22 11:14:04 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-05-22 11:14:04 --> Model Class Initialized
DEBUG - 2011-05-22 11:14:04 --> Model Class Initialized
DEBUG - 2011-05-22 11:14:04 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-05-22 11:14:04 --> Database Driver Class Initialized
DEBUG - 2011-05-22 11:14:04 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-05-22 11:14:04 --> Helper loaded: url_helper
DEBUG - 2011-05-22 11:14:04 --> File loaded: application/views/common/header.php
DEBUG - 2011-05-22 11:14:04 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-05-22 11:14:04 --> File loaded: application/views/common/footer.php
DEBUG - 2011-05-22 11:14:04 --> File loaded: application/views/layout/main.php
DEBUG - 2011-05-22 11:14:04 --> Final output sent to browser
DEBUG - 2011-05-22 11:14:04 --> Total execution time: 0.0295
DEBUG - 2011-05-22 11:14:05 --> Final output sent to browser
DEBUG - 2011-05-22 11:14:05 --> Total execution time: 0.4715
DEBUG - 2011-05-22 11:14:16 --> Config Class Initialized
DEBUG - 2011-05-22 11:14:16 --> Hooks Class Initialized
DEBUG - 2011-05-22 11:14:16 --> Utf8 Class Initialized
DEBUG - 2011-05-22 11:14:16 --> UTF-8 Support Enabled
DEBUG - 2011-05-22 11:14:16 --> URI Class Initialized
DEBUG - 2011-05-22 11:14:16 --> Router Class Initialized
DEBUG - 2011-05-22 11:14:16 --> Output Class Initialized
DEBUG - 2011-05-22 11:14:16 --> Input Class Initialized
DEBUG - 2011-05-22 11:14:16 --> Global POST and COOKIE data sanitized
DEBUG - 2011-05-22 11:14:16 --> Language Class Initialized
DEBUG - 2011-05-22 11:14:16 --> Loader Class Initialized
DEBUG - 2011-05-22 11:14:16 --> Controller Class Initialized
ERROR - 2011-05-22 11:14:16 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-05-22 11:14:16 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-05-22 11:14:16 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-05-22 11:14:16 --> Model Class Initialized
DEBUG - 2011-05-22 11:14:16 --> Model Class Initialized
DEBUG - 2011-05-22 11:14:16 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-05-22 11:14:16 --> Database Driver Class Initialized
DEBUG - 2011-05-22 11:14:16 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-05-22 11:14:16 --> Helper loaded: url_helper
DEBUG - 2011-05-22 11:14:16 --> File loaded: application/views/common/header.php
DEBUG - 2011-05-22 11:14:16 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-05-22 11:14:16 --> File loaded: application/views/common/footer.php
DEBUG - 2011-05-22 11:14:16 --> File loaded: application/views/layout/main.php
DEBUG - 2011-05-22 11:14:16 --> Final output sent to browser
DEBUG - 2011-05-22 11:14:16 --> Total execution time: 0.0262
DEBUG - 2011-05-22 11:14:17 --> Config Class Initialized
DEBUG - 2011-05-22 11:14:17 --> Hooks Class Initialized
DEBUG - 2011-05-22 11:14:17 --> Utf8 Class Initialized
DEBUG - 2011-05-22 11:14:17 --> UTF-8 Support Enabled
DEBUG - 2011-05-22 11:14:17 --> URI Class Initialized
DEBUG - 2011-05-22 11:14:17 --> Router Class Initialized
DEBUG - 2011-05-22 11:14:17 --> Output Class Initialized
DEBUG - 2011-05-22 11:14:17 --> Input Class Initialized
DEBUG - 2011-05-22 11:14:17 --> Global POST and COOKIE data sanitized
DEBUG - 2011-05-22 11:14:17 --> Language Class Initialized
DEBUG - 2011-05-22 11:14:17 --> Loader Class Initialized
DEBUG - 2011-05-22 11:14:17 --> Controller Class Initialized
DEBUG - 2011-05-22 11:14:17 --> Model Class Initialized
DEBUG - 2011-05-22 11:14:17 --> Model Class Initialized
DEBUG - 2011-05-22 11:14:17 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-05-22 11:14:17 --> Database Driver Class Initialized
DEBUG - 2011-05-22 11:14:18 --> Final output sent to browser
DEBUG - 2011-05-22 11:14:18 --> Total execution time: 0.7095
DEBUG - 2011-05-22 11:14:19 --> Config Class Initialized
DEBUG - 2011-05-22 11:14:19 --> Hooks Class Initialized
DEBUG - 2011-05-22 11:14:19 --> Utf8 Class Initialized
DEBUG - 2011-05-22 11:14:19 --> UTF-8 Support Enabled
DEBUG - 2011-05-22 11:14:19 --> URI Class Initialized
DEBUG - 2011-05-22 11:14:19 --> Router Class Initialized
DEBUG - 2011-05-22 11:14:19 --> Output Class Initialized
DEBUG - 2011-05-22 11:14:19 --> Input Class Initialized
DEBUG - 2011-05-22 11:14:19 --> Global POST and COOKIE data sanitized
DEBUG - 2011-05-22 11:14:19 --> Language Class Initialized
DEBUG - 2011-05-22 11:14:19 --> Loader Class Initialized
DEBUG - 2011-05-22 11:14:19 --> Controller Class Initialized
DEBUG - 2011-05-22 11:14:19 --> Model Class Initialized
DEBUG - 2011-05-22 11:14:19 --> Model Class Initialized
DEBUG - 2011-05-22 11:14:19 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-05-22 11:14:19 --> Database Driver Class Initialized
DEBUG - 2011-05-22 11:14:19 --> Config Class Initialized
DEBUG - 2011-05-22 11:14:19 --> Hooks Class Initialized
DEBUG - 2011-05-22 11:14:19 --> Utf8 Class Initialized
DEBUG - 2011-05-22 11:14:19 --> UTF-8 Support Enabled
DEBUG - 2011-05-22 11:14:19 --> URI Class Initialized
DEBUG - 2011-05-22 11:14:19 --> Router Class Initialized
DEBUG - 2011-05-22 11:14:19 --> Output Class Initialized
DEBUG - 2011-05-22 11:14:19 --> Input Class Initialized
DEBUG - 2011-05-22 11:14:19 --> Global POST and COOKIE data sanitized
DEBUG - 2011-05-22 11:14:19 --> Language Class Initialized
DEBUG - 2011-05-22 11:14:19 --> Loader Class Initialized
DEBUG - 2011-05-22 11:14:19 --> Controller Class Initialized
ERROR - 2011-05-22 11:14:19 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-05-22 11:14:19 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-05-22 11:14:19 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-05-22 11:14:19 --> Model Class Initialized
DEBUG - 2011-05-22 11:14:19 --> Model Class Initialized
DEBUG - 2011-05-22 11:14:19 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-05-22 11:14:19 --> Database Driver Class Initialized
DEBUG - 2011-05-22 11:14:19 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-05-22 11:14:19 --> Helper loaded: url_helper
DEBUG - 2011-05-22 11:14:19 --> File loaded: application/views/common/header.php
DEBUG - 2011-05-22 11:14:19 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-05-22 11:14:19 --> File loaded: application/views/common/footer.php
DEBUG - 2011-05-22 11:14:19 --> File loaded: application/views/layout/main.php
DEBUG - 2011-05-22 11:14:19 --> Final output sent to browser
DEBUG - 2011-05-22 11:14:19 --> Total execution time: 0.0448
DEBUG - 2011-05-22 11:14:19 --> Final output sent to browser
DEBUG - 2011-05-22 11:14:19 --> Total execution time: 0.4691
DEBUG - 2011-05-22 11:14:20 --> Config Class Initialized
DEBUG - 2011-05-22 11:14:20 --> Hooks Class Initialized
DEBUG - 2011-05-22 11:14:20 --> Utf8 Class Initialized
DEBUG - 2011-05-22 11:14:20 --> UTF-8 Support Enabled
DEBUG - 2011-05-22 11:14:20 --> URI Class Initialized
DEBUG - 2011-05-22 11:14:20 --> Router Class Initialized
DEBUG - 2011-05-22 11:14:20 --> Output Class Initialized
DEBUG - 2011-05-22 11:14:20 --> Input Class Initialized
DEBUG - 2011-05-22 11:14:20 --> Global POST and COOKIE data sanitized
DEBUG - 2011-05-22 11:14:20 --> Language Class Initialized
DEBUG - 2011-05-22 11:14:20 --> Loader Class Initialized
DEBUG - 2011-05-22 11:14:20 --> Controller Class Initialized
ERROR - 2011-05-22 11:14:20 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-05-22 11:14:20 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-05-22 11:14:20 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-05-22 11:14:20 --> Model Class Initialized
DEBUG - 2011-05-22 11:14:20 --> Model Class Initialized
DEBUG - 2011-05-22 11:14:20 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-05-22 11:14:20 --> Database Driver Class Initialized
DEBUG - 2011-05-22 11:14:20 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-05-22 11:14:20 --> Helper loaded: url_helper
DEBUG - 2011-05-22 11:14:20 --> File loaded: application/views/common/header.php
DEBUG - 2011-05-22 11:14:20 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-05-22 11:14:20 --> File loaded: application/views/common/footer.php
DEBUG - 2011-05-22 11:14:20 --> File loaded: application/views/layout/main.php
DEBUG - 2011-05-22 11:14:20 --> Final output sent to browser
DEBUG - 2011-05-22 11:14:20 --> Total execution time: 0.0462
DEBUG - 2011-05-22 11:14:52 --> Config Class Initialized
DEBUG - 2011-05-22 11:14:52 --> Hooks Class Initialized
DEBUG - 2011-05-22 11:14:52 --> Utf8 Class Initialized
DEBUG - 2011-05-22 11:14:52 --> UTF-8 Support Enabled
DEBUG - 2011-05-22 11:14:52 --> URI Class Initialized
DEBUG - 2011-05-22 11:14:52 --> Router Class Initialized
DEBUG - 2011-05-22 11:14:52 --> Output Class Initialized
DEBUG - 2011-05-22 11:14:52 --> Input Class Initialized
DEBUG - 2011-05-22 11:14:52 --> Global POST and COOKIE data sanitized
DEBUG - 2011-05-22 11:14:52 --> Language Class Initialized
DEBUG - 2011-05-22 11:14:52 --> Loader Class Initialized
DEBUG - 2011-05-22 11:14:52 --> Controller Class Initialized
ERROR - 2011-05-22 11:14:52 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-05-22 11:14:52 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-05-22 11:14:52 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-05-22 11:14:52 --> Model Class Initialized
DEBUG - 2011-05-22 11:14:52 --> Model Class Initialized
DEBUG - 2011-05-22 11:14:52 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-05-22 11:14:52 --> Database Driver Class Initialized
DEBUG - 2011-05-22 11:14:52 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-05-22 11:14:52 --> Helper loaded: url_helper
DEBUG - 2011-05-22 11:14:52 --> File loaded: application/views/common/header.php
DEBUG - 2011-05-22 11:14:52 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-05-22 11:14:52 --> File loaded: application/views/common/footer.php
DEBUG - 2011-05-22 11:14:52 --> File loaded: application/views/layout/main.php
DEBUG - 2011-05-22 11:14:52 --> Final output sent to browser
DEBUG - 2011-05-22 11:14:52 --> Total execution time: 0.0275
DEBUG - 2011-05-22 11:14:52 --> Config Class Initialized
DEBUG - 2011-05-22 11:14:52 --> Hooks Class Initialized
DEBUG - 2011-05-22 11:14:52 --> Utf8 Class Initialized
DEBUG - 2011-05-22 11:14:52 --> UTF-8 Support Enabled
DEBUG - 2011-05-22 11:14:52 --> URI Class Initialized
DEBUG - 2011-05-22 11:14:52 --> Router Class Initialized
DEBUG - 2011-05-22 11:14:52 --> Output Class Initialized
DEBUG - 2011-05-22 11:14:52 --> Input Class Initialized
DEBUG - 2011-05-22 11:14:52 --> Global POST and COOKIE data sanitized
DEBUG - 2011-05-22 11:14:52 --> Language Class Initialized
DEBUG - 2011-05-22 11:14:52 --> Loader Class Initialized
DEBUG - 2011-05-22 11:14:52 --> Controller Class Initialized
DEBUG - 2011-05-22 11:14:52 --> Model Class Initialized
DEBUG - 2011-05-22 11:14:52 --> Model Class Initialized
DEBUG - 2011-05-22 11:14:52 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-05-22 11:14:52 --> Database Driver Class Initialized
DEBUG - 2011-05-22 11:14:53 --> Final output sent to browser
DEBUG - 2011-05-22 11:14:53 --> Total execution time: 0.5592
DEBUG - 2011-05-22 11:14:54 --> Config Class Initialized
DEBUG - 2011-05-22 11:14:54 --> Hooks Class Initialized
DEBUG - 2011-05-22 11:14:54 --> Utf8 Class Initialized
DEBUG - 2011-05-22 11:14:54 --> UTF-8 Support Enabled
DEBUG - 2011-05-22 11:14:54 --> URI Class Initialized
DEBUG - 2011-05-22 11:14:54 --> Router Class Initialized
DEBUG - 2011-05-22 11:14:54 --> Output Class Initialized
DEBUG - 2011-05-22 11:14:54 --> Input Class Initialized
DEBUG - 2011-05-22 11:14:54 --> Global POST and COOKIE data sanitized
DEBUG - 2011-05-22 11:14:54 --> Language Class Initialized
DEBUG - 2011-05-22 11:14:54 --> Loader Class Initialized
DEBUG - 2011-05-22 11:14:54 --> Controller Class Initialized
DEBUG - 2011-05-22 11:14:54 --> Model Class Initialized
DEBUG - 2011-05-22 11:14:54 --> Model Class Initialized
DEBUG - 2011-05-22 11:14:54 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-05-22 11:14:54 --> Database Driver Class Initialized
DEBUG - 2011-05-22 11:14:55 --> Config Class Initialized
DEBUG - 2011-05-22 11:14:55 --> Hooks Class Initialized
DEBUG - 2011-05-22 11:14:55 --> Utf8 Class Initialized
DEBUG - 2011-05-22 11:14:55 --> UTF-8 Support Enabled
DEBUG - 2011-05-22 11:14:55 --> URI Class Initialized
DEBUG - 2011-05-22 11:14:55 --> Router Class Initialized
DEBUG - 2011-05-22 11:14:55 --> Output Class Initialized
DEBUG - 2011-05-22 11:14:55 --> Input Class Initialized
DEBUG - 2011-05-22 11:14:55 --> Global POST and COOKIE data sanitized
DEBUG - 2011-05-22 11:14:55 --> Language Class Initialized
DEBUG - 2011-05-22 11:14:55 --> Loader Class Initialized
DEBUG - 2011-05-22 11:14:55 --> Controller Class Initialized
ERROR - 2011-05-22 11:14:55 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-05-22 11:14:55 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-05-22 11:14:55 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-05-22 11:14:55 --> Model Class Initialized
DEBUG - 2011-05-22 11:14:55 --> Model Class Initialized
DEBUG - 2011-05-22 11:14:55 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-05-22 11:14:55 --> Database Driver Class Initialized
DEBUG - 2011-05-22 11:14:55 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-05-22 11:14:55 --> Helper loaded: url_helper
DEBUG - 2011-05-22 11:14:55 --> File loaded: application/views/common/header.php
DEBUG - 2011-05-22 11:14:55 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-05-22 11:14:55 --> File loaded: application/views/common/footer.php
DEBUG - 2011-05-22 11:14:55 --> File loaded: application/views/layout/main.php
DEBUG - 2011-05-22 11:14:55 --> Final output sent to browser
DEBUG - 2011-05-22 11:14:55 --> Total execution time: 0.0530
DEBUG - 2011-05-22 11:14:55 --> Final output sent to browser
DEBUG - 2011-05-22 11:14:55 --> Total execution time: 0.5026
DEBUG - 2011-05-22 11:15:13 --> Config Class Initialized
DEBUG - 2011-05-22 11:15:13 --> Hooks Class Initialized
DEBUG - 2011-05-22 11:15:13 --> Utf8 Class Initialized
DEBUG - 2011-05-22 11:15:13 --> UTF-8 Support Enabled
DEBUG - 2011-05-22 11:15:13 --> URI Class Initialized
DEBUG - 2011-05-22 11:15:13 --> Router Class Initialized
DEBUG - 2011-05-22 11:15:13 --> Output Class Initialized
DEBUG - 2011-05-22 11:15:13 --> Input Class Initialized
DEBUG - 2011-05-22 11:15:13 --> Global POST and COOKIE data sanitized
DEBUG - 2011-05-22 11:15:13 --> Language Class Initialized
DEBUG - 2011-05-22 11:15:13 --> Loader Class Initialized
DEBUG - 2011-05-22 11:15:13 --> Controller Class Initialized
ERROR - 2011-05-22 11:15:13 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-05-22 11:15:13 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-05-22 11:15:13 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-05-22 11:15:13 --> Model Class Initialized
DEBUG - 2011-05-22 11:15:13 --> Model Class Initialized
DEBUG - 2011-05-22 11:15:13 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-05-22 11:15:13 --> Database Driver Class Initialized
DEBUG - 2011-05-22 11:15:13 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-05-22 11:15:13 --> Helper loaded: url_helper
DEBUG - 2011-05-22 11:15:13 --> File loaded: application/views/common/header.php
DEBUG - 2011-05-22 11:15:13 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-05-22 11:15:13 --> File loaded: application/views/common/footer.php
DEBUG - 2011-05-22 11:15:13 --> File loaded: application/views/layout/main.php
DEBUG - 2011-05-22 11:15:13 --> Final output sent to browser
DEBUG - 2011-05-22 11:15:13 --> Total execution time: 0.0402
DEBUG - 2011-05-22 11:15:14 --> Config Class Initialized
DEBUG - 2011-05-22 11:15:14 --> Hooks Class Initialized
DEBUG - 2011-05-22 11:15:14 --> Utf8 Class Initialized
DEBUG - 2011-05-22 11:15:14 --> UTF-8 Support Enabled
DEBUG - 2011-05-22 11:15:14 --> URI Class Initialized
DEBUG - 2011-05-22 11:15:14 --> Router Class Initialized
DEBUG - 2011-05-22 11:15:14 --> Output Class Initialized
DEBUG - 2011-05-22 11:15:14 --> Input Class Initialized
DEBUG - 2011-05-22 11:15:14 --> Global POST and COOKIE data sanitized
DEBUG - 2011-05-22 11:15:14 --> Language Class Initialized
DEBUG - 2011-05-22 11:15:14 --> Loader Class Initialized
DEBUG - 2011-05-22 11:15:14 --> Controller Class Initialized
DEBUG - 2011-05-22 11:15:14 --> Model Class Initialized
DEBUG - 2011-05-22 11:15:14 --> Model Class Initialized
DEBUG - 2011-05-22 11:15:14 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-05-22 11:15:14 --> Database Driver Class Initialized
DEBUG - 2011-05-22 11:15:14 --> Final output sent to browser
DEBUG - 2011-05-22 11:15:14 --> Total execution time: 0.6489
DEBUG - 2011-05-22 11:15:16 --> Config Class Initialized
DEBUG - 2011-05-22 11:15:16 --> Hooks Class Initialized
DEBUG - 2011-05-22 11:15:16 --> Utf8 Class Initialized
DEBUG - 2011-05-22 11:15:16 --> UTF-8 Support Enabled
DEBUG - 2011-05-22 11:15:16 --> URI Class Initialized
DEBUG - 2011-05-22 11:15:16 --> Router Class Initialized
DEBUG - 2011-05-22 11:15:16 --> Output Class Initialized
DEBUG - 2011-05-22 11:15:16 --> Input Class Initialized
DEBUG - 2011-05-22 11:15:16 --> Global POST and COOKIE data sanitized
DEBUG - 2011-05-22 11:15:16 --> Language Class Initialized
DEBUG - 2011-05-22 11:15:16 --> Loader Class Initialized
DEBUG - 2011-05-22 11:15:16 --> Controller Class Initialized
DEBUG - 2011-05-22 11:15:16 --> Model Class Initialized
DEBUG - 2011-05-22 11:15:16 --> Model Class Initialized
DEBUG - 2011-05-22 11:15:16 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-05-22 11:15:16 --> Database Driver Class Initialized
DEBUG - 2011-05-22 11:15:16 --> Config Class Initialized
DEBUG - 2011-05-22 11:15:16 --> Hooks Class Initialized
DEBUG - 2011-05-22 11:15:16 --> Utf8 Class Initialized
DEBUG - 2011-05-22 11:15:16 --> UTF-8 Support Enabled
DEBUG - 2011-05-22 11:15:16 --> URI Class Initialized
DEBUG - 2011-05-22 11:15:16 --> Router Class Initialized
DEBUG - 2011-05-22 11:15:16 --> Output Class Initialized
DEBUG - 2011-05-22 11:15:16 --> Input Class Initialized
DEBUG - 2011-05-22 11:15:16 --> Global POST and COOKIE data sanitized
DEBUG - 2011-05-22 11:15:16 --> Language Class Initialized
DEBUG - 2011-05-22 11:15:16 --> Loader Class Initialized
DEBUG - 2011-05-22 11:15:16 --> Controller Class Initialized
ERROR - 2011-05-22 11:15:16 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-05-22 11:15:16 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-05-22 11:15:16 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-05-22 11:15:16 --> Model Class Initialized
DEBUG - 2011-05-22 11:15:16 --> Model Class Initialized
DEBUG - 2011-05-22 11:15:16 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-05-22 11:15:16 --> Database Driver Class Initialized
DEBUG - 2011-05-22 11:15:16 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-05-22 11:15:16 --> Helper loaded: url_helper
DEBUG - 2011-05-22 11:15:16 --> File loaded: application/views/common/header.php
DEBUG - 2011-05-22 11:15:16 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-05-22 11:15:16 --> File loaded: application/views/common/footer.php
DEBUG - 2011-05-22 11:15:16 --> File loaded: application/views/layout/main.php
DEBUG - 2011-05-22 11:15:16 --> Final output sent to browser
DEBUG - 2011-05-22 11:15:16 --> Total execution time: 0.0373
DEBUG - 2011-05-22 11:15:16 --> Final output sent to browser
DEBUG - 2011-05-22 11:15:16 --> Total execution time: 0.5115
DEBUG - 2011-05-22 11:15:22 --> Config Class Initialized
DEBUG - 2011-05-22 11:15:22 --> Hooks Class Initialized
DEBUG - 2011-05-22 11:15:22 --> Utf8 Class Initialized
DEBUG - 2011-05-22 11:15:22 --> UTF-8 Support Enabled
DEBUG - 2011-05-22 11:15:22 --> URI Class Initialized
DEBUG - 2011-05-22 11:15:22 --> Router Class Initialized
DEBUG - 2011-05-22 11:15:22 --> Output Class Initialized
DEBUG - 2011-05-22 11:15:22 --> Input Class Initialized
DEBUG - 2011-05-22 11:15:22 --> Global POST and COOKIE data sanitized
DEBUG - 2011-05-22 11:15:22 --> Language Class Initialized
DEBUG - 2011-05-22 11:15:22 --> Loader Class Initialized
DEBUG - 2011-05-22 11:15:22 --> Controller Class Initialized
ERROR - 2011-05-22 11:15:22 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-05-22 11:15:22 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-05-22 11:15:22 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-05-22 11:15:22 --> Model Class Initialized
DEBUG - 2011-05-22 11:15:22 --> Model Class Initialized
DEBUG - 2011-05-22 11:15:22 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-05-22 11:15:22 --> Database Driver Class Initialized
DEBUG - 2011-05-22 11:15:22 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-05-22 11:15:22 --> Helper loaded: url_helper
DEBUG - 2011-05-22 11:15:22 --> File loaded: application/views/common/header.php
DEBUG - 2011-05-22 11:15:22 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-05-22 11:15:22 --> File loaded: application/views/common/footer.php
DEBUG - 2011-05-22 11:15:22 --> File loaded: application/views/layout/main.php
DEBUG - 2011-05-22 11:15:22 --> Final output sent to browser
DEBUG - 2011-05-22 11:15:22 --> Total execution time: 0.0265
DEBUG - 2011-05-22 11:15:22 --> Config Class Initialized
DEBUG - 2011-05-22 11:15:22 --> Hooks Class Initialized
DEBUG - 2011-05-22 11:15:22 --> Utf8 Class Initialized
DEBUG - 2011-05-22 11:15:22 --> UTF-8 Support Enabled
DEBUG - 2011-05-22 11:15:22 --> URI Class Initialized
DEBUG - 2011-05-22 11:15:22 --> Router Class Initialized
DEBUG - 2011-05-22 11:15:22 --> Output Class Initialized
DEBUG - 2011-05-22 11:15:22 --> Input Class Initialized
DEBUG - 2011-05-22 11:15:22 --> Global POST and COOKIE data sanitized
DEBUG - 2011-05-22 11:15:22 --> Language Class Initialized
DEBUG - 2011-05-22 11:15:22 --> Loader Class Initialized
DEBUG - 2011-05-22 11:15:22 --> Controller Class Initialized
DEBUG - 2011-05-22 11:15:22 --> Model Class Initialized
DEBUG - 2011-05-22 11:15:22 --> Model Class Initialized
DEBUG - 2011-05-22 11:15:22 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-05-22 11:15:22 --> Database Driver Class Initialized
DEBUG - 2011-05-22 11:15:23 --> Final output sent to browser
DEBUG - 2011-05-22 11:15:23 --> Total execution time: 0.6029
DEBUG - 2011-05-22 11:15:24 --> Config Class Initialized
DEBUG - 2011-05-22 11:15:24 --> Hooks Class Initialized
DEBUG - 2011-05-22 11:15:24 --> Utf8 Class Initialized
DEBUG - 2011-05-22 11:15:24 --> UTF-8 Support Enabled
DEBUG - 2011-05-22 11:15:24 --> URI Class Initialized
DEBUG - 2011-05-22 11:15:24 --> Router Class Initialized
DEBUG - 2011-05-22 11:15:24 --> Output Class Initialized
DEBUG - 2011-05-22 11:15:24 --> Input Class Initialized
DEBUG - 2011-05-22 11:15:24 --> Global POST and COOKIE data sanitized
DEBUG - 2011-05-22 11:15:24 --> Language Class Initialized
DEBUG - 2011-05-22 11:15:24 --> Loader Class Initialized
DEBUG - 2011-05-22 11:15:24 --> Controller Class Initialized
DEBUG - 2011-05-22 11:15:24 --> Model Class Initialized
DEBUG - 2011-05-22 11:15:24 --> Model Class Initialized
DEBUG - 2011-05-22 11:15:24 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-05-22 11:15:24 --> Database Driver Class Initialized
DEBUG - 2011-05-22 11:15:25 --> Final output sent to browser
DEBUG - 2011-05-22 11:15:25 --> Total execution time: 0.5007
DEBUG - 2011-05-22 11:15:27 --> Config Class Initialized
DEBUG - 2011-05-22 11:15:27 --> Hooks Class Initialized
DEBUG - 2011-05-22 11:15:27 --> Utf8 Class Initialized
DEBUG - 2011-05-22 11:15:27 --> UTF-8 Support Enabled
DEBUG - 2011-05-22 11:15:27 --> URI Class Initialized
DEBUG - 2011-05-22 11:15:27 --> Router Class Initialized
DEBUG - 2011-05-22 11:15:27 --> Output Class Initialized
DEBUG - 2011-05-22 11:15:27 --> Input Class Initialized
DEBUG - 2011-05-22 11:15:27 --> Global POST and COOKIE data sanitized
DEBUG - 2011-05-22 11:15:27 --> Language Class Initialized
DEBUG - 2011-05-22 11:15:27 --> Loader Class Initialized
DEBUG - 2011-05-22 11:15:27 --> Controller Class Initialized
ERROR - 2011-05-22 11:15:27 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-05-22 11:15:27 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-05-22 11:15:27 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-05-22 11:15:27 --> Model Class Initialized
DEBUG - 2011-05-22 11:15:27 --> Model Class Initialized
DEBUG - 2011-05-22 11:15:27 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-05-22 11:15:27 --> Database Driver Class Initialized
DEBUG - 2011-05-22 11:15:27 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-05-22 11:15:27 --> Helper loaded: url_helper
DEBUG - 2011-05-22 11:15:27 --> File loaded: application/views/common/header.php
DEBUG - 2011-05-22 11:15:27 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-05-22 11:15:27 --> File loaded: application/views/common/footer.php
DEBUG - 2011-05-22 11:15:27 --> File loaded: application/views/layout/main.php
DEBUG - 2011-05-22 11:15:27 --> Final output sent to browser
DEBUG - 2011-05-22 11:15:27 --> Total execution time: 0.0450
DEBUG - 2011-05-22 11:15:38 --> Config Class Initialized
DEBUG - 2011-05-22 11:15:38 --> Hooks Class Initialized
DEBUG - 2011-05-22 11:15:38 --> Utf8 Class Initialized
DEBUG - 2011-05-22 11:15:38 --> UTF-8 Support Enabled
DEBUG - 2011-05-22 11:15:38 --> URI Class Initialized
DEBUG - 2011-05-22 11:15:38 --> Router Class Initialized
DEBUG - 2011-05-22 11:15:38 --> Output Class Initialized
DEBUG - 2011-05-22 11:15:38 --> Input Class Initialized
DEBUG - 2011-05-22 11:15:38 --> Global POST and COOKIE data sanitized
DEBUG - 2011-05-22 11:15:38 --> Language Class Initialized
DEBUG - 2011-05-22 11:15:38 --> Loader Class Initialized
DEBUG - 2011-05-22 11:15:38 --> Controller Class Initialized
ERROR - 2011-05-22 11:15:38 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-05-22 11:15:38 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-05-22 11:15:38 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-05-22 11:15:38 --> Model Class Initialized
DEBUG - 2011-05-22 11:15:38 --> Model Class Initialized
DEBUG - 2011-05-22 11:15:38 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-05-22 11:15:38 --> Database Driver Class Initialized
DEBUG - 2011-05-22 11:15:38 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-05-22 11:15:38 --> Helper loaded: url_helper
DEBUG - 2011-05-22 11:15:38 --> File loaded: application/views/common/header.php
DEBUG - 2011-05-22 11:15:38 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-05-22 11:15:38 --> File loaded: application/views/common/footer.php
DEBUG - 2011-05-22 11:15:38 --> File loaded: application/views/layout/main.php
DEBUG - 2011-05-22 11:15:38 --> Final output sent to browser
DEBUG - 2011-05-22 11:15:38 --> Total execution time: 0.0292
DEBUG - 2011-05-22 11:15:38 --> Config Class Initialized
DEBUG - 2011-05-22 11:15:38 --> Hooks Class Initialized
DEBUG - 2011-05-22 11:15:38 --> Utf8 Class Initialized
DEBUG - 2011-05-22 11:15:38 --> UTF-8 Support Enabled
DEBUG - 2011-05-22 11:15:38 --> URI Class Initialized
DEBUG - 2011-05-22 11:15:38 --> Router Class Initialized
DEBUG - 2011-05-22 11:15:38 --> Output Class Initialized
DEBUG - 2011-05-22 11:15:38 --> Input Class Initialized
DEBUG - 2011-05-22 11:15:38 --> Global POST and COOKIE data sanitized
DEBUG - 2011-05-22 11:15:38 --> Language Class Initialized
DEBUG - 2011-05-22 11:15:38 --> Loader Class Initialized
DEBUG - 2011-05-22 11:15:38 --> Controller Class Initialized
DEBUG - 2011-05-22 11:15:38 --> Model Class Initialized
DEBUG - 2011-05-22 11:15:38 --> Model Class Initialized
DEBUG - 2011-05-22 11:15:38 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-05-22 11:15:38 --> Database Driver Class Initialized
DEBUG - 2011-05-22 11:15:39 --> Final output sent to browser
DEBUG - 2011-05-22 11:15:39 --> Total execution time: 0.5746
DEBUG - 2011-05-22 11:15:40 --> Config Class Initialized
DEBUG - 2011-05-22 11:15:40 --> Hooks Class Initialized
DEBUG - 2011-05-22 11:15:40 --> Utf8 Class Initialized
DEBUG - 2011-05-22 11:15:40 --> UTF-8 Support Enabled
DEBUG - 2011-05-22 11:15:40 --> URI Class Initialized
DEBUG - 2011-05-22 11:15:40 --> Router Class Initialized
DEBUG - 2011-05-22 11:15:40 --> Output Class Initialized
DEBUG - 2011-05-22 11:15:40 --> Input Class Initialized
DEBUG - 2011-05-22 11:15:40 --> Global POST and COOKIE data sanitized
DEBUG - 2011-05-22 11:15:40 --> Language Class Initialized
DEBUG - 2011-05-22 11:15:40 --> Loader Class Initialized
DEBUG - 2011-05-22 11:15:40 --> Controller Class Initialized
DEBUG - 2011-05-22 11:15:40 --> Model Class Initialized
DEBUG - 2011-05-22 11:15:40 --> Model Class Initialized
DEBUG - 2011-05-22 11:15:40 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-05-22 11:15:40 --> Database Driver Class Initialized
DEBUG - 2011-05-22 11:15:41 --> Final output sent to browser
DEBUG - 2011-05-22 11:15:41 --> Total execution time: 0.5095
DEBUG - 2011-05-22 11:15:47 --> Config Class Initialized
DEBUG - 2011-05-22 11:15:47 --> Hooks Class Initialized
DEBUG - 2011-05-22 11:15:47 --> Utf8 Class Initialized
DEBUG - 2011-05-22 11:15:47 --> UTF-8 Support Enabled
DEBUG - 2011-05-22 11:15:47 --> URI Class Initialized
DEBUG - 2011-05-22 11:15:47 --> Router Class Initialized
DEBUG - 2011-05-22 11:15:47 --> Output Class Initialized
DEBUG - 2011-05-22 11:15:47 --> Input Class Initialized
DEBUG - 2011-05-22 11:15:47 --> Global POST and COOKIE data sanitized
DEBUG - 2011-05-22 11:15:47 --> Language Class Initialized
DEBUG - 2011-05-22 11:15:47 --> Loader Class Initialized
DEBUG - 2011-05-22 11:15:47 --> Controller Class Initialized
ERROR - 2011-05-22 11:15:47 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-05-22 11:15:47 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-05-22 11:15:47 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-05-22 11:15:47 --> Model Class Initialized
DEBUG - 2011-05-22 11:15:47 --> Model Class Initialized
DEBUG - 2011-05-22 11:15:47 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-05-22 11:15:47 --> Database Driver Class Initialized
DEBUG - 2011-05-22 11:15:47 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-05-22 11:15:47 --> Helper loaded: url_helper
DEBUG - 2011-05-22 11:15:47 --> File loaded: application/views/common/header.php
DEBUG - 2011-05-22 11:15:47 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-05-22 11:15:47 --> File loaded: application/views/common/footer.php
DEBUG - 2011-05-22 11:15:47 --> File loaded: application/views/layout/main.php
DEBUG - 2011-05-22 11:15:47 --> Final output sent to browser
DEBUG - 2011-05-22 11:15:47 --> Total execution time: 0.0290
DEBUG - 2011-05-22 11:16:01 --> Config Class Initialized
DEBUG - 2011-05-22 11:16:01 --> Hooks Class Initialized
DEBUG - 2011-05-22 11:16:01 --> Utf8 Class Initialized
DEBUG - 2011-05-22 11:16:01 --> UTF-8 Support Enabled
DEBUG - 2011-05-22 11:16:01 --> URI Class Initialized
DEBUG - 2011-05-22 11:16:01 --> Router Class Initialized
DEBUG - 2011-05-22 11:16:01 --> Output Class Initialized
DEBUG - 2011-05-22 11:16:01 --> Input Class Initialized
DEBUG - 2011-05-22 11:16:01 --> Global POST and COOKIE data sanitized
DEBUG - 2011-05-22 11:16:01 --> Language Class Initialized
DEBUG - 2011-05-22 11:16:01 --> Loader Class Initialized
DEBUG - 2011-05-22 11:16:01 --> Controller Class Initialized
ERROR - 2011-05-22 11:16:01 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-05-22 11:16:01 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-05-22 11:16:01 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-05-22 11:16:01 --> Model Class Initialized
DEBUG - 2011-05-22 11:16:01 --> Model Class Initialized
DEBUG - 2011-05-22 11:16:01 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-05-22 11:16:01 --> Database Driver Class Initialized
DEBUG - 2011-05-22 11:16:01 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-05-22 11:16:01 --> Helper loaded: url_helper
DEBUG - 2011-05-22 11:16:01 --> File loaded: application/views/common/header.php
DEBUG - 2011-05-22 11:16:01 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-05-22 11:16:01 --> File loaded: application/views/common/footer.php
DEBUG - 2011-05-22 11:16:01 --> File loaded: application/views/layout/main.php
DEBUG - 2011-05-22 11:16:01 --> Final output sent to browser
DEBUG - 2011-05-22 11:16:01 --> Total execution time: 0.0539
DEBUG - 2011-05-22 11:16:02 --> Config Class Initialized
DEBUG - 2011-05-22 11:16:02 --> Hooks Class Initialized
DEBUG - 2011-05-22 11:16:02 --> Utf8 Class Initialized
DEBUG - 2011-05-22 11:16:02 --> UTF-8 Support Enabled
DEBUG - 2011-05-22 11:16:02 --> URI Class Initialized
DEBUG - 2011-05-22 11:16:02 --> Router Class Initialized
DEBUG - 2011-05-22 11:16:02 --> Output Class Initialized
DEBUG - 2011-05-22 11:16:02 --> Input Class Initialized
DEBUG - 2011-05-22 11:16:02 --> Global POST and COOKIE data sanitized
DEBUG - 2011-05-22 11:16:02 --> Language Class Initialized
DEBUG - 2011-05-22 11:16:02 --> Loader Class Initialized
DEBUG - 2011-05-22 11:16:02 --> Controller Class Initialized
DEBUG - 2011-05-22 11:16:02 --> Model Class Initialized
DEBUG - 2011-05-22 11:16:02 --> Model Class Initialized
DEBUG - 2011-05-22 11:16:02 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-05-22 11:16:02 --> Database Driver Class Initialized
DEBUG - 2011-05-22 11:16:02 --> Final output sent to browser
DEBUG - 2011-05-22 11:16:02 --> Total execution time: 0.7147
DEBUG - 2011-05-22 11:16:04 --> Config Class Initialized
DEBUG - 2011-05-22 11:16:04 --> Hooks Class Initialized
DEBUG - 2011-05-22 11:16:04 --> Utf8 Class Initialized
DEBUG - 2011-05-22 11:16:04 --> UTF-8 Support Enabled
DEBUG - 2011-05-22 11:16:04 --> URI Class Initialized
DEBUG - 2011-05-22 11:16:04 --> Router Class Initialized
DEBUG - 2011-05-22 11:16:04 --> Output Class Initialized
DEBUG - 2011-05-22 11:16:04 --> Input Class Initialized
DEBUG - 2011-05-22 11:16:04 --> Global POST and COOKIE data sanitized
DEBUG - 2011-05-22 11:16:04 --> Language Class Initialized
DEBUG - 2011-05-22 11:16:04 --> Loader Class Initialized
DEBUG - 2011-05-22 11:16:04 --> Controller Class Initialized
DEBUG - 2011-05-22 11:16:04 --> Model Class Initialized
DEBUG - 2011-05-22 11:16:04 --> Model Class Initialized
DEBUG - 2011-05-22 11:16:04 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-05-22 11:16:04 --> Database Driver Class Initialized
DEBUG - 2011-05-22 11:16:04 --> Final output sent to browser
DEBUG - 2011-05-22 11:16:04 --> Total execution time: 0.6380
DEBUG - 2011-05-22 11:16:14 --> Config Class Initialized
DEBUG - 2011-05-22 11:16:14 --> Hooks Class Initialized
DEBUG - 2011-05-22 11:16:14 --> Utf8 Class Initialized
DEBUG - 2011-05-22 11:16:14 --> UTF-8 Support Enabled
DEBUG - 2011-05-22 11:16:14 --> URI Class Initialized
DEBUG - 2011-05-22 11:16:14 --> Router Class Initialized
DEBUG - 2011-05-22 11:16:14 --> Output Class Initialized
DEBUG - 2011-05-22 11:16:14 --> Input Class Initialized
DEBUG - 2011-05-22 11:16:14 --> Global POST and COOKIE data sanitized
DEBUG - 2011-05-22 11:16:14 --> Language Class Initialized
DEBUG - 2011-05-22 11:16:14 --> Loader Class Initialized
DEBUG - 2011-05-22 11:16:14 --> Controller Class Initialized
ERROR - 2011-05-22 11:16:14 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-05-22 11:16:14 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-05-22 11:16:14 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-05-22 11:16:14 --> Model Class Initialized
DEBUG - 2011-05-22 11:16:14 --> Model Class Initialized
DEBUG - 2011-05-22 11:16:14 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-05-22 11:16:14 --> Database Driver Class Initialized
DEBUG - 2011-05-22 11:16:14 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-05-22 11:16:14 --> Helper loaded: url_helper
DEBUG - 2011-05-22 11:16:14 --> File loaded: application/views/common/header.php
DEBUG - 2011-05-22 11:16:14 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-05-22 11:16:14 --> File loaded: application/views/common/footer.php
DEBUG - 2011-05-22 11:16:14 --> File loaded: application/views/layout/main.php
DEBUG - 2011-05-22 11:16:14 --> Final output sent to browser
DEBUG - 2011-05-22 11:16:14 --> Total execution time: 0.0347
DEBUG - 2011-05-22 11:16:16 --> Config Class Initialized
DEBUG - 2011-05-22 11:16:16 --> Hooks Class Initialized
DEBUG - 2011-05-22 11:16:16 --> Utf8 Class Initialized
DEBUG - 2011-05-22 11:16:16 --> UTF-8 Support Enabled
DEBUG - 2011-05-22 11:16:16 --> URI Class Initialized
DEBUG - 2011-05-22 11:16:16 --> Router Class Initialized
DEBUG - 2011-05-22 11:16:16 --> Output Class Initialized
DEBUG - 2011-05-22 11:16:16 --> Input Class Initialized
DEBUG - 2011-05-22 11:16:16 --> Global POST and COOKIE data sanitized
DEBUG - 2011-05-22 11:16:16 --> Language Class Initialized
DEBUG - 2011-05-22 11:16:16 --> Loader Class Initialized
DEBUG - 2011-05-22 11:16:16 --> Controller Class Initialized
DEBUG - 2011-05-22 11:16:16 --> Model Class Initialized
DEBUG - 2011-05-22 11:16:16 --> Model Class Initialized
DEBUG - 2011-05-22 11:16:16 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-05-22 11:16:16 --> Database Driver Class Initialized
DEBUG - 2011-05-22 11:16:17 --> Final output sent to browser
DEBUG - 2011-05-22 11:16:17 --> Total execution time: 0.6976
DEBUG - 2011-05-22 11:16:22 --> Config Class Initialized
DEBUG - 2011-05-22 11:16:22 --> Hooks Class Initialized
DEBUG - 2011-05-22 11:16:22 --> Utf8 Class Initialized
DEBUG - 2011-05-22 11:16:22 --> UTF-8 Support Enabled
DEBUG - 2011-05-22 11:16:22 --> URI Class Initialized
DEBUG - 2011-05-22 11:16:22 --> Router Class Initialized
DEBUG - 2011-05-22 11:16:22 --> Output Class Initialized
DEBUG - 2011-05-22 11:16:22 --> Input Class Initialized
DEBUG - 2011-05-22 11:16:22 --> Global POST and COOKIE data sanitized
DEBUG - 2011-05-22 11:16:22 --> Language Class Initialized
DEBUG - 2011-05-22 11:16:22 --> Loader Class Initialized
DEBUG - 2011-05-22 11:16:22 --> Controller Class Initialized
ERROR - 2011-05-22 11:16:22 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-05-22 11:16:22 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-05-22 11:16:22 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-05-22 11:16:22 --> Model Class Initialized
DEBUG - 2011-05-22 11:16:22 --> Model Class Initialized
DEBUG - 2011-05-22 11:16:22 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-05-22 11:16:22 --> Database Driver Class Initialized
DEBUG - 2011-05-22 11:16:22 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-05-22 11:16:22 --> Helper loaded: url_helper
DEBUG - 2011-05-22 11:16:22 --> File loaded: application/views/common/header.php
DEBUG - 2011-05-22 11:16:22 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-05-22 11:16:22 --> File loaded: application/views/common/footer.php
DEBUG - 2011-05-22 11:16:22 --> File loaded: application/views/layout/main.php
DEBUG - 2011-05-22 11:16:22 --> Final output sent to browser
DEBUG - 2011-05-22 11:16:22 --> Total execution time: 0.0295
DEBUG - 2011-05-22 11:16:23 --> Config Class Initialized
DEBUG - 2011-05-22 11:16:23 --> Hooks Class Initialized
DEBUG - 2011-05-22 11:16:23 --> Utf8 Class Initialized
DEBUG - 2011-05-22 11:16:23 --> UTF-8 Support Enabled
DEBUG - 2011-05-22 11:16:23 --> URI Class Initialized
DEBUG - 2011-05-22 11:16:23 --> Router Class Initialized
DEBUG - 2011-05-22 11:16:23 --> Output Class Initialized
DEBUG - 2011-05-22 11:16:23 --> Input Class Initialized
DEBUG - 2011-05-22 11:16:23 --> Global POST and COOKIE data sanitized
DEBUG - 2011-05-22 11:16:23 --> Language Class Initialized
DEBUG - 2011-05-22 11:16:23 --> Loader Class Initialized
DEBUG - 2011-05-22 11:16:23 --> Controller Class Initialized
DEBUG - 2011-05-22 11:16:23 --> Model Class Initialized
DEBUG - 2011-05-22 11:16:23 --> Model Class Initialized
DEBUG - 2011-05-22 11:16:23 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-05-22 11:16:23 --> Database Driver Class Initialized
DEBUG - 2011-05-22 11:16:24 --> Final output sent to browser
DEBUG - 2011-05-22 11:16:24 --> Total execution time: 1.3780
DEBUG - 2011-05-22 11:16:25 --> Config Class Initialized
DEBUG - 2011-05-22 11:16:25 --> Hooks Class Initialized
DEBUG - 2011-05-22 11:16:25 --> Utf8 Class Initialized
DEBUG - 2011-05-22 11:16:25 --> UTF-8 Support Enabled
DEBUG - 2011-05-22 11:16:25 --> URI Class Initialized
DEBUG - 2011-05-22 11:16:25 --> Router Class Initialized
DEBUG - 2011-05-22 11:16:25 --> Output Class Initialized
DEBUG - 2011-05-22 11:16:25 --> Input Class Initialized
DEBUG - 2011-05-22 11:16:25 --> Global POST and COOKIE data sanitized
DEBUG - 2011-05-22 11:16:25 --> Language Class Initialized
DEBUG - 2011-05-22 11:16:25 --> Loader Class Initialized
DEBUG - 2011-05-22 11:16:25 --> Controller Class Initialized
DEBUG - 2011-05-22 11:16:25 --> Model Class Initialized
DEBUG - 2011-05-22 11:16:25 --> Model Class Initialized
DEBUG - 2011-05-22 11:16:25 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-05-22 11:16:25 --> Database Driver Class Initialized
DEBUG - 2011-05-22 11:16:25 --> Final output sent to browser
DEBUG - 2011-05-22 11:16:25 --> Total execution time: 0.4497
DEBUG - 2011-05-22 11:16:43 --> Config Class Initialized
DEBUG - 2011-05-22 11:16:43 --> Hooks Class Initialized
DEBUG - 2011-05-22 11:16:43 --> Utf8 Class Initialized
DEBUG - 2011-05-22 11:16:43 --> UTF-8 Support Enabled
DEBUG - 2011-05-22 11:16:43 --> URI Class Initialized
DEBUG - 2011-05-22 11:16:43 --> Router Class Initialized
DEBUG - 2011-05-22 11:16:43 --> Output Class Initialized
DEBUG - 2011-05-22 11:16:43 --> Input Class Initialized
DEBUG - 2011-05-22 11:16:43 --> Global POST and COOKIE data sanitized
DEBUG - 2011-05-22 11:16:43 --> Language Class Initialized
DEBUG - 2011-05-22 11:16:43 --> Loader Class Initialized
DEBUG - 2011-05-22 11:16:43 --> Controller Class Initialized
ERROR - 2011-05-22 11:16:43 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-05-22 11:16:43 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-05-22 11:16:43 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-05-22 11:16:43 --> Model Class Initialized
DEBUG - 2011-05-22 11:16:43 --> Model Class Initialized
DEBUG - 2011-05-22 11:16:43 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-05-22 11:16:43 --> Database Driver Class Initialized
DEBUG - 2011-05-22 11:16:43 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-05-22 11:16:43 --> Helper loaded: url_helper
DEBUG - 2011-05-22 11:16:43 --> File loaded: application/views/common/header.php
DEBUG - 2011-05-22 11:16:43 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-05-22 11:16:43 --> File loaded: application/views/common/footer.php
DEBUG - 2011-05-22 11:16:43 --> File loaded: application/views/layout/main.php
DEBUG - 2011-05-22 11:16:43 --> Final output sent to browser
DEBUG - 2011-05-22 11:16:43 --> Total execution time: 0.0293
DEBUG - 2011-05-22 11:16:43 --> Config Class Initialized
DEBUG - 2011-05-22 11:16:43 --> Hooks Class Initialized
DEBUG - 2011-05-22 11:16:43 --> Utf8 Class Initialized
DEBUG - 2011-05-22 11:16:43 --> UTF-8 Support Enabled
DEBUG - 2011-05-22 11:16:43 --> URI Class Initialized
DEBUG - 2011-05-22 11:16:43 --> Router Class Initialized
DEBUG - 2011-05-22 11:16:43 --> Output Class Initialized
DEBUG - 2011-05-22 11:16:43 --> Input Class Initialized
DEBUG - 2011-05-22 11:16:43 --> Global POST and COOKIE data sanitized
DEBUG - 2011-05-22 11:16:43 --> Language Class Initialized
DEBUG - 2011-05-22 11:16:43 --> Loader Class Initialized
DEBUG - 2011-05-22 11:16:43 --> Controller Class Initialized
DEBUG - 2011-05-22 11:16:43 --> Model Class Initialized
DEBUG - 2011-05-22 11:16:43 --> Model Class Initialized
DEBUG - 2011-05-22 11:16:43 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-05-22 11:16:43 --> Database Driver Class Initialized
DEBUG - 2011-05-22 11:16:44 --> Final output sent to browser
DEBUG - 2011-05-22 11:16:44 --> Total execution time: 0.7748
DEBUG - 2011-05-22 11:16:45 --> Config Class Initialized
DEBUG - 2011-05-22 11:16:45 --> Hooks Class Initialized
DEBUG - 2011-05-22 11:16:45 --> Utf8 Class Initialized
DEBUG - 2011-05-22 11:16:45 --> UTF-8 Support Enabled
DEBUG - 2011-05-22 11:16:45 --> URI Class Initialized
DEBUG - 2011-05-22 11:16:45 --> Router Class Initialized
DEBUG - 2011-05-22 11:16:45 --> Output Class Initialized
DEBUG - 2011-05-22 11:16:45 --> Input Class Initialized
DEBUG - 2011-05-22 11:16:45 --> Global POST and COOKIE data sanitized
DEBUG - 2011-05-22 11:16:45 --> Language Class Initialized
DEBUG - 2011-05-22 11:16:45 --> Loader Class Initialized
DEBUG - 2011-05-22 11:16:45 --> Controller Class Initialized
DEBUG - 2011-05-22 11:16:45 --> Model Class Initialized
DEBUG - 2011-05-22 11:16:45 --> Model Class Initialized
DEBUG - 2011-05-22 11:16:45 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-05-22 11:16:45 --> Database Driver Class Initialized
DEBUG - 2011-05-22 11:16:46 --> Final output sent to browser
DEBUG - 2011-05-22 11:16:46 --> Total execution time: 0.4542
DEBUG - 2011-05-22 11:16:51 --> Config Class Initialized
DEBUG - 2011-05-22 11:16:51 --> Hooks Class Initialized
DEBUG - 2011-05-22 11:16:51 --> Utf8 Class Initialized
DEBUG - 2011-05-22 11:16:51 --> UTF-8 Support Enabled
DEBUG - 2011-05-22 11:16:51 --> URI Class Initialized
DEBUG - 2011-05-22 11:16:51 --> Router Class Initialized
DEBUG - 2011-05-22 11:16:51 --> Output Class Initialized
DEBUG - 2011-05-22 11:16:51 --> Input Class Initialized
DEBUG - 2011-05-22 11:16:51 --> Global POST and COOKIE data sanitized
DEBUG - 2011-05-22 11:16:51 --> Language Class Initialized
DEBUG - 2011-05-22 11:16:51 --> Loader Class Initialized
DEBUG - 2011-05-22 11:16:51 --> Controller Class Initialized
ERROR - 2011-05-22 11:16:51 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-05-22 11:16:51 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-05-22 11:16:51 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-05-22 11:16:51 --> Model Class Initialized
DEBUG - 2011-05-22 11:16:51 --> Model Class Initialized
DEBUG - 2011-05-22 11:16:51 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-05-22 11:16:51 --> Database Driver Class Initialized
DEBUG - 2011-05-22 11:16:51 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-05-22 11:16:51 --> Helper loaded: url_helper
DEBUG - 2011-05-22 11:16:51 --> File loaded: application/views/common/header.php
DEBUG - 2011-05-22 11:16:51 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-05-22 11:16:51 --> File loaded: application/views/common/footer.php
DEBUG - 2011-05-22 11:16:51 --> File loaded: application/views/layout/main.php
DEBUG - 2011-05-22 11:16:51 --> Final output sent to browser
DEBUG - 2011-05-22 11:16:51 --> Total execution time: 0.0291
DEBUG - 2011-05-22 11:16:52 --> Config Class Initialized
DEBUG - 2011-05-22 11:16:52 --> Hooks Class Initialized
DEBUG - 2011-05-22 11:16:52 --> Utf8 Class Initialized
DEBUG - 2011-05-22 11:16:52 --> UTF-8 Support Enabled
DEBUG - 2011-05-22 11:16:52 --> URI Class Initialized
DEBUG - 2011-05-22 11:16:52 --> Router Class Initialized
DEBUG - 2011-05-22 11:16:52 --> Output Class Initialized
DEBUG - 2011-05-22 11:16:52 --> Input Class Initialized
DEBUG - 2011-05-22 11:16:52 --> Global POST and COOKIE data sanitized
DEBUG - 2011-05-22 11:16:52 --> Language Class Initialized
DEBUG - 2011-05-22 11:16:52 --> Loader Class Initialized
DEBUG - 2011-05-22 11:16:52 --> Controller Class Initialized
DEBUG - 2011-05-22 11:16:52 --> Model Class Initialized
DEBUG - 2011-05-22 11:16:52 --> Model Class Initialized
DEBUG - 2011-05-22 11:16:52 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-05-22 11:16:52 --> Database Driver Class Initialized
DEBUG - 2011-05-22 11:16:52 --> Final output sent to browser
DEBUG - 2011-05-22 11:16:52 --> Total execution time: 0.5353
DEBUG - 2011-05-22 11:16:54 --> Config Class Initialized
DEBUG - 2011-05-22 11:16:54 --> Hooks Class Initialized
DEBUG - 2011-05-22 11:16:54 --> Utf8 Class Initialized
DEBUG - 2011-05-22 11:16:54 --> UTF-8 Support Enabled
DEBUG - 2011-05-22 11:16:54 --> URI Class Initialized
DEBUG - 2011-05-22 11:16:54 --> Config Class Initialized
DEBUG - 2011-05-22 11:16:54 --> Hooks Class Initialized
DEBUG - 2011-05-22 11:16:54 --> Utf8 Class Initialized
DEBUG - 2011-05-22 11:16:54 --> UTF-8 Support Enabled
DEBUG - 2011-05-22 11:16:54 --> Router Class Initialized
DEBUG - 2011-05-22 11:16:54 --> URI Class Initialized
DEBUG - 2011-05-22 11:16:54 --> Output Class Initialized
DEBUG - 2011-05-22 11:16:54 --> Router Class Initialized
DEBUG - 2011-05-22 11:16:54 --> Input Class Initialized
DEBUG - 2011-05-22 11:16:54 --> Global POST and COOKIE data sanitized
DEBUG - 2011-05-22 11:16:54 --> Language Class Initialized
DEBUG - 2011-05-22 11:16:54 --> Loader Class Initialized
DEBUG - 2011-05-22 11:16:54 --> Controller Class Initialized
DEBUG - 2011-05-22 11:16:54 --> Output Class Initialized
ERROR - 2011-05-22 11:16:54 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-05-22 11:16:54 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-05-22 11:16:54 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-05-22 11:16:54 --> Model Class Initialized
DEBUG - 2011-05-22 11:16:54 --> Model Class Initialized
DEBUG - 2011-05-22 11:16:54 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-05-22 11:16:54 --> Input Class Initialized
DEBUG - 2011-05-22 11:16:54 --> Global POST and COOKIE data sanitized
DEBUG - 2011-05-22 11:16:54 --> Language Class Initialized
DEBUG - 2011-05-22 11:16:54 --> Loader Class Initialized
DEBUG - 2011-05-22 11:16:54 --> Controller Class Initialized
DEBUG - 2011-05-22 11:16:54 --> Model Class Initialized
DEBUG - 2011-05-22 11:16:54 --> Database Driver Class Initialized
DEBUG - 2011-05-22 11:16:54 --> Model Class Initialized
DEBUG - 2011-05-22 11:16:54 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-05-22 11:16:54 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-05-22 11:16:54 --> Database Driver Class Initialized
DEBUG - 2011-05-22 11:16:54 --> Helper loaded: url_helper
DEBUG - 2011-05-22 11:16:54 --> File loaded: application/views/common/header.php
DEBUG - 2011-05-22 11:16:54 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-05-22 11:16:54 --> File loaded: application/views/common/footer.php
DEBUG - 2011-05-22 11:16:54 --> File loaded: application/views/layout/main.php
DEBUG - 2011-05-22 11:16:54 --> Final output sent to browser
DEBUG - 2011-05-22 11:16:54 --> Total execution time: 0.0287
DEBUG - 2011-05-22 11:16:55 --> Final output sent to browser
DEBUG - 2011-05-22 11:16:55 --> Total execution time: 0.4740
DEBUG - 2011-05-22 11:16:55 --> Config Class Initialized
DEBUG - 2011-05-22 11:16:55 --> Hooks Class Initialized
DEBUG - 2011-05-22 11:16:55 --> Utf8 Class Initialized
DEBUG - 2011-05-22 11:16:55 --> UTF-8 Support Enabled
DEBUG - 2011-05-22 11:16:55 --> URI Class Initialized
DEBUG - 2011-05-22 11:16:55 --> Router Class Initialized
DEBUG - 2011-05-22 11:16:55 --> Output Class Initialized
DEBUG - 2011-05-22 11:16:55 --> Input Class Initialized
DEBUG - 2011-05-22 11:16:55 --> Global POST and COOKIE data sanitized
DEBUG - 2011-05-22 11:16:55 --> Language Class Initialized
DEBUG - 2011-05-22 11:16:55 --> Loader Class Initialized
DEBUG - 2011-05-22 11:16:55 --> Controller Class Initialized
ERROR - 2011-05-22 11:16:55 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-05-22 11:16:55 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-05-22 11:16:55 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-05-22 11:16:55 --> Model Class Initialized
DEBUG - 2011-05-22 11:16:55 --> Model Class Initialized
DEBUG - 2011-05-22 11:16:55 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-05-22 11:16:55 --> Database Driver Class Initialized
DEBUG - 2011-05-22 11:16:55 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-05-22 11:16:55 --> Helper loaded: url_helper
DEBUG - 2011-05-22 11:16:55 --> File loaded: application/views/common/header.php
DEBUG - 2011-05-22 11:16:55 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-05-22 11:16:55 --> File loaded: application/views/common/footer.php
DEBUG - 2011-05-22 11:16:55 --> File loaded: application/views/layout/main.php
DEBUG - 2011-05-22 11:16:55 --> Final output sent to browser
DEBUG - 2011-05-22 11:16:55 --> Total execution time: 0.0281
DEBUG - 2011-05-22 11:17:03 --> Config Class Initialized
DEBUG - 2011-05-22 11:17:03 --> Hooks Class Initialized
DEBUG - 2011-05-22 11:17:03 --> Utf8 Class Initialized
DEBUG - 2011-05-22 11:17:03 --> UTF-8 Support Enabled
DEBUG - 2011-05-22 11:17:03 --> URI Class Initialized
DEBUG - 2011-05-22 11:17:03 --> Router Class Initialized
DEBUG - 2011-05-22 11:17:03 --> Output Class Initialized
DEBUG - 2011-05-22 11:17:03 --> Input Class Initialized
DEBUG - 2011-05-22 11:17:03 --> Global POST and COOKIE data sanitized
DEBUG - 2011-05-22 11:17:03 --> Language Class Initialized
DEBUG - 2011-05-22 11:17:03 --> Loader Class Initialized
DEBUG - 2011-05-22 11:17:03 --> Controller Class Initialized
ERROR - 2011-05-22 11:17:03 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-05-22 11:17:03 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-05-22 11:17:03 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-05-22 11:17:03 --> Model Class Initialized
DEBUG - 2011-05-22 11:17:03 --> Model Class Initialized
DEBUG - 2011-05-22 11:17:03 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-05-22 11:17:03 --> Database Driver Class Initialized
DEBUG - 2011-05-22 11:17:03 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-05-22 11:17:03 --> Helper loaded: url_helper
DEBUG - 2011-05-22 11:17:03 --> File loaded: application/views/common/header.php
DEBUG - 2011-05-22 11:17:03 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-05-22 11:17:03 --> File loaded: application/views/common/footer.php
DEBUG - 2011-05-22 11:17:03 --> File loaded: application/views/layout/main.php
DEBUG - 2011-05-22 11:17:03 --> Final output sent to browser
DEBUG - 2011-05-22 11:17:03 --> Total execution time: 0.0278
DEBUG - 2011-05-22 11:17:03 --> Config Class Initialized
DEBUG - 2011-05-22 11:17:03 --> Hooks Class Initialized
DEBUG - 2011-05-22 11:17:03 --> Utf8 Class Initialized
DEBUG - 2011-05-22 11:17:03 --> UTF-8 Support Enabled
DEBUG - 2011-05-22 11:17:03 --> URI Class Initialized
DEBUG - 2011-05-22 11:17:03 --> Router Class Initialized
DEBUG - 2011-05-22 11:17:03 --> Output Class Initialized
DEBUG - 2011-05-22 11:17:03 --> Input Class Initialized
DEBUG - 2011-05-22 11:17:03 --> Global POST and COOKIE data sanitized
DEBUG - 2011-05-22 11:17:03 --> Language Class Initialized
DEBUG - 2011-05-22 11:17:03 --> Loader Class Initialized
DEBUG - 2011-05-22 11:17:03 --> Controller Class Initialized
DEBUG - 2011-05-22 11:17:03 --> Model Class Initialized
DEBUG - 2011-05-22 11:17:03 --> Model Class Initialized
DEBUG - 2011-05-22 11:17:03 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-05-22 11:17:03 --> Database Driver Class Initialized
DEBUG - 2011-05-22 11:17:04 --> Final output sent to browser
DEBUG - 2011-05-22 11:17:04 --> Total execution time: 0.5464
DEBUG - 2011-05-22 11:17:05 --> Config Class Initialized
DEBUG - 2011-05-22 11:17:05 --> Hooks Class Initialized
DEBUG - 2011-05-22 11:17:05 --> Utf8 Class Initialized
DEBUG - 2011-05-22 11:17:05 --> UTF-8 Support Enabled
DEBUG - 2011-05-22 11:17:05 --> URI Class Initialized
DEBUG - 2011-05-22 11:17:05 --> Router Class Initialized
DEBUG - 2011-05-22 11:17:05 --> Output Class Initialized
DEBUG - 2011-05-22 11:17:05 --> Input Class Initialized
DEBUG - 2011-05-22 11:17:05 --> Global POST and COOKIE data sanitized
DEBUG - 2011-05-22 11:17:05 --> Language Class Initialized
DEBUG - 2011-05-22 11:17:05 --> Loader Class Initialized
DEBUG - 2011-05-22 11:17:05 --> Controller Class Initialized
DEBUG - 2011-05-22 11:17:05 --> Model Class Initialized
DEBUG - 2011-05-22 11:17:05 --> Model Class Initialized
DEBUG - 2011-05-22 11:17:05 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-05-22 11:17:05 --> Database Driver Class Initialized
DEBUG - 2011-05-22 11:17:06 --> Final output sent to browser
DEBUG - 2011-05-22 11:17:06 --> Total execution time: 0.4650
DEBUG - 2011-05-22 11:17:12 --> Config Class Initialized
DEBUG - 2011-05-22 11:17:12 --> Hooks Class Initialized
DEBUG - 2011-05-22 11:17:12 --> Utf8 Class Initialized
DEBUG - 2011-05-22 11:17:12 --> UTF-8 Support Enabled
DEBUG - 2011-05-22 11:17:12 --> URI Class Initialized
DEBUG - 2011-05-22 11:17:12 --> Router Class Initialized
DEBUG - 2011-05-22 11:17:12 --> Output Class Initialized
DEBUG - 2011-05-22 11:17:12 --> Input Class Initialized
DEBUG - 2011-05-22 11:17:12 --> Global POST and COOKIE data sanitized
DEBUG - 2011-05-22 11:17:12 --> Language Class Initialized
DEBUG - 2011-05-22 11:17:12 --> Loader Class Initialized
DEBUG - 2011-05-22 11:17:12 --> Controller Class Initialized
ERROR - 2011-05-22 11:17:12 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-05-22 11:17:12 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-05-22 11:17:12 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-05-22 11:17:12 --> Model Class Initialized
DEBUG - 2011-05-22 11:17:12 --> Model Class Initialized
DEBUG - 2011-05-22 11:17:12 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-05-22 11:17:12 --> Database Driver Class Initialized
DEBUG - 2011-05-22 11:17:12 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-05-22 11:17:12 --> Helper loaded: url_helper
DEBUG - 2011-05-22 11:17:12 --> File loaded: application/views/common/header.php
DEBUG - 2011-05-22 11:17:12 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-05-22 11:17:12 --> File loaded: application/views/common/footer.php
DEBUG - 2011-05-22 11:17:12 --> File loaded: application/views/layout/main.php
DEBUG - 2011-05-22 11:17:12 --> Final output sent to browser
DEBUG - 2011-05-22 11:17:12 --> Total execution time: 0.0295
DEBUG - 2011-05-22 11:17:12 --> Config Class Initialized
DEBUG - 2011-05-22 11:17:12 --> Hooks Class Initialized
DEBUG - 2011-05-22 11:17:12 --> Utf8 Class Initialized
DEBUG - 2011-05-22 11:17:12 --> UTF-8 Support Enabled
DEBUG - 2011-05-22 11:17:12 --> URI Class Initialized
DEBUG - 2011-05-22 11:17:12 --> Router Class Initialized
DEBUG - 2011-05-22 11:17:12 --> Output Class Initialized
DEBUG - 2011-05-22 11:17:12 --> Input Class Initialized
DEBUG - 2011-05-22 11:17:12 --> Global POST and COOKIE data sanitized
DEBUG - 2011-05-22 11:17:12 --> Language Class Initialized
DEBUG - 2011-05-22 11:17:12 --> Loader Class Initialized
DEBUG - 2011-05-22 11:17:12 --> Controller Class Initialized
DEBUG - 2011-05-22 11:17:12 --> Model Class Initialized
DEBUG - 2011-05-22 11:17:12 --> Model Class Initialized
DEBUG - 2011-05-22 11:17:12 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-05-22 11:17:12 --> Database Driver Class Initialized
DEBUG - 2011-05-22 11:17:13 --> Final output sent to browser
DEBUG - 2011-05-22 11:17:13 --> Total execution time: 0.6158
DEBUG - 2011-05-22 11:17:15 --> Config Class Initialized
DEBUG - 2011-05-22 11:17:15 --> Hooks Class Initialized
DEBUG - 2011-05-22 11:17:15 --> Utf8 Class Initialized
DEBUG - 2011-05-22 11:17:15 --> UTF-8 Support Enabled
DEBUG - 2011-05-22 11:17:15 --> URI Class Initialized
DEBUG - 2011-05-22 11:17:15 --> Router Class Initialized
DEBUG - 2011-05-22 11:17:15 --> Output Class Initialized
DEBUG - 2011-05-22 11:17:15 --> Input Class Initialized
DEBUG - 2011-05-22 11:17:15 --> Global POST and COOKIE data sanitized
DEBUG - 2011-05-22 11:17:15 --> Language Class Initialized
DEBUG - 2011-05-22 11:17:15 --> Loader Class Initialized
DEBUG - 2011-05-22 11:17:15 --> Controller Class Initialized
DEBUG - 2011-05-22 11:17:15 --> Model Class Initialized
DEBUG - 2011-05-22 11:17:15 --> Model Class Initialized
DEBUG - 2011-05-22 11:17:15 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-05-22 11:17:15 --> Database Driver Class Initialized
DEBUG - 2011-05-22 11:17:15 --> Final output sent to browser
DEBUG - 2011-05-22 11:17:15 --> Total execution time: 0.5192
DEBUG - 2011-05-22 11:17:20 --> Config Class Initialized
DEBUG - 2011-05-22 11:17:20 --> Hooks Class Initialized
DEBUG - 2011-05-22 11:17:20 --> Utf8 Class Initialized
DEBUG - 2011-05-22 11:17:20 --> UTF-8 Support Enabled
DEBUG - 2011-05-22 11:17:20 --> URI Class Initialized
DEBUG - 2011-05-22 11:17:20 --> Router Class Initialized
DEBUG - 2011-05-22 11:17:20 --> Output Class Initialized
DEBUG - 2011-05-22 11:17:20 --> Input Class Initialized
DEBUG - 2011-05-22 11:17:20 --> Global POST and COOKIE data sanitized
DEBUG - 2011-05-22 11:17:20 --> Language Class Initialized
DEBUG - 2011-05-22 11:17:20 --> Loader Class Initialized
DEBUG - 2011-05-22 11:17:20 --> Controller Class Initialized
ERROR - 2011-05-22 11:17:20 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-05-22 11:17:20 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-05-22 11:17:20 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-05-22 11:17:20 --> Model Class Initialized
DEBUG - 2011-05-22 11:17:20 --> Model Class Initialized
DEBUG - 2011-05-22 11:17:20 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-05-22 11:17:20 --> Database Driver Class Initialized
DEBUG - 2011-05-22 11:17:20 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-05-22 11:17:20 --> Helper loaded: url_helper
DEBUG - 2011-05-22 11:17:20 --> File loaded: application/views/common/header.php
DEBUG - 2011-05-22 11:17:20 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-05-22 11:17:20 --> File loaded: application/views/common/footer.php
DEBUG - 2011-05-22 11:17:20 --> File loaded: application/views/layout/main.php
DEBUG - 2011-05-22 11:17:20 --> Final output sent to browser
DEBUG - 2011-05-22 11:17:20 --> Total execution time: 0.0440
DEBUG - 2011-05-22 11:17:21 --> Config Class Initialized
DEBUG - 2011-05-22 11:17:21 --> Hooks Class Initialized
DEBUG - 2011-05-22 11:17:21 --> Utf8 Class Initialized
DEBUG - 2011-05-22 11:17:21 --> UTF-8 Support Enabled
DEBUG - 2011-05-22 11:17:21 --> URI Class Initialized
DEBUG - 2011-05-22 11:17:21 --> Router Class Initialized
DEBUG - 2011-05-22 11:17:21 --> Output Class Initialized
DEBUG - 2011-05-22 11:17:22 --> Input Class Initialized
DEBUG - 2011-05-22 11:17:22 --> Global POST and COOKIE data sanitized
DEBUG - 2011-05-22 11:17:22 --> Language Class Initialized
DEBUG - 2011-05-22 11:17:22 --> Loader Class Initialized
DEBUG - 2011-05-22 11:17:22 --> Controller Class Initialized
ERROR - 2011-05-22 11:17:22 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-05-22 11:17:22 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-05-22 11:17:22 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-05-22 11:17:22 --> Model Class Initialized
DEBUG - 2011-05-22 11:17:22 --> Model Class Initialized
DEBUG - 2011-05-22 11:17:22 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-05-22 11:17:22 --> Database Driver Class Initialized
DEBUG - 2011-05-22 11:17:22 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-05-22 11:17:22 --> Helper loaded: url_helper
DEBUG - 2011-05-22 11:17:22 --> File loaded: application/views/common/header.php
DEBUG - 2011-05-22 11:17:22 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-05-22 11:17:22 --> File loaded: application/views/common/footer.php
DEBUG - 2011-05-22 11:17:22 --> File loaded: application/views/layout/main.php
DEBUG - 2011-05-22 11:17:22 --> Final output sent to browser
DEBUG - 2011-05-22 11:17:22 --> Total execution time: 0.0544
DEBUG - 2011-05-22 11:17:24 --> Config Class Initialized
DEBUG - 2011-05-22 11:17:24 --> Hooks Class Initialized
DEBUG - 2011-05-22 11:17:24 --> Utf8 Class Initialized
DEBUG - 2011-05-22 11:17:24 --> UTF-8 Support Enabled
DEBUG - 2011-05-22 11:17:24 --> URI Class Initialized
DEBUG - 2011-05-22 11:17:24 --> Router Class Initialized
DEBUG - 2011-05-22 11:17:24 --> Output Class Initialized
DEBUG - 2011-05-22 11:17:24 --> Input Class Initialized
DEBUG - 2011-05-22 11:17:24 --> Global POST and COOKIE data sanitized
DEBUG - 2011-05-22 11:17:24 --> Language Class Initialized
DEBUG - 2011-05-22 11:17:24 --> Loader Class Initialized
DEBUG - 2011-05-22 11:17:24 --> Controller Class Initialized
ERROR - 2011-05-22 11:17:24 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-05-22 11:17:24 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-05-22 11:17:24 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-05-22 11:17:24 --> Model Class Initialized
DEBUG - 2011-05-22 11:17:24 --> Model Class Initialized
DEBUG - 2011-05-22 11:17:24 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-05-22 11:17:24 --> Database Driver Class Initialized
DEBUG - 2011-05-22 11:17:24 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-05-22 11:17:24 --> Helper loaded: url_helper
DEBUG - 2011-05-22 11:17:24 --> File loaded: application/views/common/header.php
DEBUG - 2011-05-22 11:17:24 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-05-22 11:17:24 --> File loaded: application/views/common/footer.php
DEBUG - 2011-05-22 11:17:24 --> File loaded: application/views/layout/main.php
DEBUG - 2011-05-22 11:17:24 --> Final output sent to browser
DEBUG - 2011-05-22 11:17:24 --> Total execution time: 0.0405
DEBUG - 2011-05-22 11:17:24 --> Config Class Initialized
DEBUG - 2011-05-22 11:17:24 --> Hooks Class Initialized
DEBUG - 2011-05-22 11:17:24 --> Utf8 Class Initialized
DEBUG - 2011-05-22 11:17:24 --> UTF-8 Support Enabled
DEBUG - 2011-05-22 11:17:24 --> URI Class Initialized
DEBUG - 2011-05-22 11:17:24 --> Router Class Initialized
DEBUG - 2011-05-22 11:17:24 --> Output Class Initialized
DEBUG - 2011-05-22 11:17:24 --> Input Class Initialized
DEBUG - 2011-05-22 11:17:24 --> Global POST and COOKIE data sanitized
DEBUG - 2011-05-22 11:17:24 --> Language Class Initialized
DEBUG - 2011-05-22 11:17:24 --> Loader Class Initialized
DEBUG - 2011-05-22 11:17:24 --> Controller Class Initialized
DEBUG - 2011-05-22 11:17:24 --> Model Class Initialized
DEBUG - 2011-05-22 11:17:24 --> Model Class Initialized
DEBUG - 2011-05-22 11:17:24 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-05-22 11:17:24 --> Database Driver Class Initialized
DEBUG - 2011-05-22 11:17:25 --> Final output sent to browser
DEBUG - 2011-05-22 11:17:25 --> Total execution time: 0.5201
DEBUG - 2011-05-22 11:17:26 --> Config Class Initialized
DEBUG - 2011-05-22 11:17:26 --> Hooks Class Initialized
DEBUG - 2011-05-22 11:17:26 --> Utf8 Class Initialized
DEBUG - 2011-05-22 11:17:26 --> UTF-8 Support Enabled
DEBUG - 2011-05-22 11:17:26 --> URI Class Initialized
DEBUG - 2011-05-22 11:17:26 --> Router Class Initialized
DEBUG - 2011-05-22 11:17:26 --> Output Class Initialized
DEBUG - 2011-05-22 11:17:26 --> Input Class Initialized
DEBUG - 2011-05-22 11:17:26 --> Global POST and COOKIE data sanitized
DEBUG - 2011-05-22 11:17:26 --> Language Class Initialized
DEBUG - 2011-05-22 11:17:26 --> Loader Class Initialized
DEBUG - 2011-05-22 11:17:26 --> Controller Class Initialized
DEBUG - 2011-05-22 11:17:26 --> Model Class Initialized
DEBUG - 2011-05-22 11:17:26 --> Model Class Initialized
DEBUG - 2011-05-22 11:17:26 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-05-22 11:17:26 --> Database Driver Class Initialized
DEBUG - 2011-05-22 11:17:27 --> Config Class Initialized
DEBUG - 2011-05-22 11:17:27 --> Hooks Class Initialized
DEBUG - 2011-05-22 11:17:27 --> Utf8 Class Initialized
DEBUG - 2011-05-22 11:17:27 --> UTF-8 Support Enabled
DEBUG - 2011-05-22 11:17:27 --> URI Class Initialized
DEBUG - 2011-05-22 11:17:27 --> Router Class Initialized
DEBUG - 2011-05-22 11:17:27 --> Output Class Initialized
DEBUG - 2011-05-22 11:17:27 --> Input Class Initialized
DEBUG - 2011-05-22 11:17:27 --> Global POST and COOKIE data sanitized
DEBUG - 2011-05-22 11:17:27 --> Language Class Initialized
DEBUG - 2011-05-22 11:17:27 --> Loader Class Initialized
DEBUG - 2011-05-22 11:17:27 --> Controller Class Initialized
ERROR - 2011-05-22 11:17:27 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-05-22 11:17:27 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-05-22 11:17:27 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-05-22 11:17:27 --> Model Class Initialized
DEBUG - 2011-05-22 11:17:27 --> Model Class Initialized
DEBUG - 2011-05-22 11:17:27 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-05-22 11:17:27 --> Database Driver Class Initialized
DEBUG - 2011-05-22 11:17:27 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-05-22 11:17:27 --> Helper loaded: url_helper
DEBUG - 2011-05-22 11:17:27 --> File loaded: application/views/common/header.php
DEBUG - 2011-05-22 11:17:27 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-05-22 11:17:27 --> File loaded: application/views/common/footer.php
DEBUG - 2011-05-22 11:17:27 --> File loaded: application/views/layout/main.php
DEBUG - 2011-05-22 11:17:27 --> Final output sent to browser
DEBUG - 2011-05-22 11:17:27 --> Total execution time: 0.0284
DEBUG - 2011-05-22 11:17:27 --> Final output sent to browser
DEBUG - 2011-05-22 11:17:27 --> Total execution time: 0.4840
DEBUG - 2011-05-22 11:17:32 --> Config Class Initialized
DEBUG - 2011-05-22 11:17:32 --> Hooks Class Initialized
DEBUG - 2011-05-22 11:17:32 --> Utf8 Class Initialized
DEBUG - 2011-05-22 11:17:32 --> UTF-8 Support Enabled
DEBUG - 2011-05-22 11:17:32 --> URI Class Initialized
DEBUG - 2011-05-22 11:17:32 --> Router Class Initialized
DEBUG - 2011-05-22 11:17:32 --> Output Class Initialized
DEBUG - 2011-05-22 11:17:32 --> Input Class Initialized
DEBUG - 2011-05-22 11:17:32 --> Global POST and COOKIE data sanitized
DEBUG - 2011-05-22 11:17:32 --> Language Class Initialized
DEBUG - 2011-05-22 11:17:32 --> Loader Class Initialized
DEBUG - 2011-05-22 11:17:32 --> Controller Class Initialized
ERROR - 2011-05-22 11:17:32 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-05-22 11:17:32 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-05-22 11:17:32 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-05-22 11:17:32 --> Model Class Initialized
DEBUG - 2011-05-22 11:17:32 --> Model Class Initialized
DEBUG - 2011-05-22 11:17:32 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-05-22 11:17:32 --> Database Driver Class Initialized
DEBUG - 2011-05-22 11:17:32 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-05-22 11:17:32 --> Helper loaded: url_helper
DEBUG - 2011-05-22 11:17:32 --> File loaded: application/views/common/header.php
DEBUG - 2011-05-22 11:17:32 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-05-22 11:17:32 --> File loaded: application/views/common/footer.php
DEBUG - 2011-05-22 11:17:32 --> File loaded: application/views/layout/main.php
DEBUG - 2011-05-22 11:17:32 --> Final output sent to browser
DEBUG - 2011-05-22 11:17:32 --> Total execution time: 0.0306
DEBUG - 2011-05-22 11:17:32 --> Config Class Initialized
DEBUG - 2011-05-22 11:17:32 --> Hooks Class Initialized
DEBUG - 2011-05-22 11:17:32 --> Utf8 Class Initialized
DEBUG - 2011-05-22 11:17:32 --> UTF-8 Support Enabled
DEBUG - 2011-05-22 11:17:32 --> URI Class Initialized
DEBUG - 2011-05-22 11:17:32 --> Router Class Initialized
DEBUG - 2011-05-22 11:17:32 --> Output Class Initialized
DEBUG - 2011-05-22 11:17:32 --> Input Class Initialized
DEBUG - 2011-05-22 11:17:32 --> Global POST and COOKIE data sanitized
DEBUG - 2011-05-22 11:17:32 --> Language Class Initialized
DEBUG - 2011-05-22 11:17:32 --> Loader Class Initialized
DEBUG - 2011-05-22 11:17:32 --> Controller Class Initialized
DEBUG - 2011-05-22 11:17:32 --> Model Class Initialized
DEBUG - 2011-05-22 11:17:32 --> Model Class Initialized
DEBUG - 2011-05-22 11:17:32 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-05-22 11:17:32 --> Database Driver Class Initialized
DEBUG - 2011-05-22 11:17:32 --> Final output sent to browser
DEBUG - 2011-05-22 11:17:32 --> Total execution time: 0.5212
DEBUG - 2011-05-22 11:17:34 --> Config Class Initialized
DEBUG - 2011-05-22 11:17:34 --> Hooks Class Initialized
DEBUG - 2011-05-22 11:17:34 --> Utf8 Class Initialized
DEBUG - 2011-05-22 11:17:34 --> UTF-8 Support Enabled
DEBUG - 2011-05-22 11:17:34 --> URI Class Initialized
DEBUG - 2011-05-22 11:17:34 --> Router Class Initialized
DEBUG - 2011-05-22 11:17:34 --> Output Class Initialized
DEBUG - 2011-05-22 11:17:34 --> Input Class Initialized
DEBUG - 2011-05-22 11:17:34 --> Global POST and COOKIE data sanitized
DEBUG - 2011-05-22 11:17:34 --> Language Class Initialized
DEBUG - 2011-05-22 11:17:34 --> Loader Class Initialized
DEBUG - 2011-05-22 11:17:34 --> Controller Class Initialized
DEBUG - 2011-05-22 11:17:34 --> Model Class Initialized
DEBUG - 2011-05-22 11:17:34 --> Model Class Initialized
DEBUG - 2011-05-22 11:17:34 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-05-22 11:17:34 --> Database Driver Class Initialized
DEBUG - 2011-05-22 11:17:34 --> Config Class Initialized
DEBUG - 2011-05-22 11:17:34 --> Hooks Class Initialized
DEBUG - 2011-05-22 11:17:34 --> Utf8 Class Initialized
DEBUG - 2011-05-22 11:17:34 --> UTF-8 Support Enabled
DEBUG - 2011-05-22 11:17:34 --> URI Class Initialized
DEBUG - 2011-05-22 11:17:34 --> Router Class Initialized
DEBUG - 2011-05-22 11:17:34 --> Output Class Initialized
DEBUG - 2011-05-22 11:17:34 --> Input Class Initialized
DEBUG - 2011-05-22 11:17:34 --> Global POST and COOKIE data sanitized
DEBUG - 2011-05-22 11:17:34 --> Language Class Initialized
DEBUG - 2011-05-22 11:17:34 --> Loader Class Initialized
DEBUG - 2011-05-22 11:17:34 --> Controller Class Initialized
ERROR - 2011-05-22 11:17:34 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-05-22 11:17:34 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-05-22 11:17:34 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-05-22 11:17:34 --> Model Class Initialized
DEBUG - 2011-05-22 11:17:34 --> Model Class Initialized
DEBUG - 2011-05-22 11:17:34 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-05-22 11:17:34 --> Database Driver Class Initialized
DEBUG - 2011-05-22 11:17:34 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-05-22 11:17:34 --> Helper loaded: url_helper
DEBUG - 2011-05-22 11:17:34 --> File loaded: application/views/common/header.php
DEBUG - 2011-05-22 11:17:34 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-05-22 11:17:34 --> File loaded: application/views/common/footer.php
DEBUG - 2011-05-22 11:17:34 --> File loaded: application/views/layout/main.php
DEBUG - 2011-05-22 11:17:34 --> Final output sent to browser
DEBUG - 2011-05-22 11:17:34 --> Total execution time: 0.0291
DEBUG - 2011-05-22 11:17:35 --> Final output sent to browser
DEBUG - 2011-05-22 11:17:35 --> Total execution time: 0.5000
DEBUG - 2011-05-22 11:17:38 --> Config Class Initialized
DEBUG - 2011-05-22 11:17:38 --> Hooks Class Initialized
DEBUG - 2011-05-22 11:17:38 --> Utf8 Class Initialized
DEBUG - 2011-05-22 11:17:38 --> UTF-8 Support Enabled
DEBUG - 2011-05-22 11:17:38 --> URI Class Initialized
DEBUG - 2011-05-22 11:17:38 --> Router Class Initialized
DEBUG - 2011-05-22 11:17:38 --> Output Class Initialized
DEBUG - 2011-05-22 11:17:38 --> Input Class Initialized
DEBUG - 2011-05-22 11:17:38 --> Global POST and COOKIE data sanitized
DEBUG - 2011-05-22 11:17:38 --> Language Class Initialized
DEBUG - 2011-05-22 11:17:38 --> Loader Class Initialized
DEBUG - 2011-05-22 11:17:38 --> Controller Class Initialized
ERROR - 2011-05-22 11:17:38 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-05-22 11:17:38 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-05-22 11:17:38 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-05-22 11:17:38 --> Model Class Initialized
DEBUG - 2011-05-22 11:17:38 --> Model Class Initialized
DEBUG - 2011-05-22 11:17:38 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-05-22 11:17:38 --> Database Driver Class Initialized
DEBUG - 2011-05-22 11:17:38 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-05-22 11:17:38 --> Helper loaded: url_helper
DEBUG - 2011-05-22 11:17:38 --> File loaded: application/views/common/header.php
DEBUG - 2011-05-22 11:17:38 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-05-22 11:17:38 --> File loaded: application/views/common/footer.php
DEBUG - 2011-05-22 11:17:38 --> File loaded: application/views/layout/main.php
DEBUG - 2011-05-22 11:17:38 --> Final output sent to browser
DEBUG - 2011-05-22 11:17:38 --> Total execution time: 0.0321
DEBUG - 2011-05-22 11:17:38 --> Config Class Initialized
DEBUG - 2011-05-22 11:17:38 --> Hooks Class Initialized
DEBUG - 2011-05-22 11:17:38 --> Utf8 Class Initialized
DEBUG - 2011-05-22 11:17:38 --> UTF-8 Support Enabled
DEBUG - 2011-05-22 11:17:38 --> URI Class Initialized
DEBUG - 2011-05-22 11:17:38 --> Router Class Initialized
DEBUG - 2011-05-22 11:17:38 --> Output Class Initialized
DEBUG - 2011-05-22 11:17:38 --> Input Class Initialized
DEBUG - 2011-05-22 11:17:38 --> Global POST and COOKIE data sanitized
DEBUG - 2011-05-22 11:17:38 --> Language Class Initialized
DEBUG - 2011-05-22 11:17:38 --> Loader Class Initialized
DEBUG - 2011-05-22 11:17:38 --> Controller Class Initialized
DEBUG - 2011-05-22 11:17:38 --> Model Class Initialized
DEBUG - 2011-05-22 11:17:38 --> Model Class Initialized
DEBUG - 2011-05-22 11:17:38 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-05-22 11:17:38 --> Database Driver Class Initialized
DEBUG - 2011-05-22 11:17:38 --> Final output sent to browser
DEBUG - 2011-05-22 11:17:38 --> Total execution time: 0.5020
DEBUG - 2011-05-22 11:17:40 --> Config Class Initialized
DEBUG - 2011-05-22 11:17:40 --> Hooks Class Initialized
DEBUG - 2011-05-22 11:17:40 --> Utf8 Class Initialized
DEBUG - 2011-05-22 11:17:40 --> UTF-8 Support Enabled
DEBUG - 2011-05-22 11:17:40 --> URI Class Initialized
DEBUG - 2011-05-22 11:17:40 --> Router Class Initialized
DEBUG - 2011-05-22 11:17:40 --> Output Class Initialized
DEBUG - 2011-05-22 11:17:40 --> Input Class Initialized
DEBUG - 2011-05-22 11:17:40 --> Global POST and COOKIE data sanitized
DEBUG - 2011-05-22 11:17:40 --> Language Class Initialized
DEBUG - 2011-05-22 11:17:40 --> Loader Class Initialized
DEBUG - 2011-05-22 11:17:40 --> Controller Class Initialized
DEBUG - 2011-05-22 11:17:40 --> Model Class Initialized
DEBUG - 2011-05-22 11:17:40 --> Model Class Initialized
DEBUG - 2011-05-22 11:17:40 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-05-22 11:17:40 --> Database Driver Class Initialized
DEBUG - 2011-05-22 11:17:40 --> Config Class Initialized
DEBUG - 2011-05-22 11:17:40 --> Hooks Class Initialized
DEBUG - 2011-05-22 11:17:40 --> Utf8 Class Initialized
DEBUG - 2011-05-22 11:17:40 --> UTF-8 Support Enabled
DEBUG - 2011-05-22 11:17:40 --> URI Class Initialized
DEBUG - 2011-05-22 11:17:40 --> Router Class Initialized
DEBUG - 2011-05-22 11:17:40 --> Output Class Initialized
DEBUG - 2011-05-22 11:17:40 --> Input Class Initialized
DEBUG - 2011-05-22 11:17:40 --> Global POST and COOKIE data sanitized
DEBUG - 2011-05-22 11:17:40 --> Language Class Initialized
DEBUG - 2011-05-22 11:17:40 --> Loader Class Initialized
DEBUG - 2011-05-22 11:17:40 --> Controller Class Initialized
ERROR - 2011-05-22 11:17:40 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-05-22 11:17:40 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-05-22 11:17:40 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-05-22 11:17:40 --> Model Class Initialized
DEBUG - 2011-05-22 11:17:40 --> Model Class Initialized
DEBUG - 2011-05-22 11:17:40 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-05-22 11:17:40 --> Database Driver Class Initialized
DEBUG - 2011-05-22 11:17:40 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-05-22 11:17:40 --> Helper loaded: url_helper
DEBUG - 2011-05-22 11:17:40 --> File loaded: application/views/common/header.php
DEBUG - 2011-05-22 11:17:40 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-05-22 11:17:40 --> File loaded: application/views/common/footer.php
DEBUG - 2011-05-22 11:17:40 --> File loaded: application/views/layout/main.php
DEBUG - 2011-05-22 11:17:40 --> Final output sent to browser
DEBUG - 2011-05-22 11:17:40 --> Total execution time: 0.0310
DEBUG - 2011-05-22 11:17:41 --> Final output sent to browser
DEBUG - 2011-05-22 11:17:41 --> Total execution time: 0.5470
DEBUG - 2011-05-22 11:17:44 --> Config Class Initialized
DEBUG - 2011-05-22 11:17:44 --> Hooks Class Initialized
DEBUG - 2011-05-22 11:17:44 --> Utf8 Class Initialized
DEBUG - 2011-05-22 11:17:44 --> UTF-8 Support Enabled
DEBUG - 2011-05-22 11:17:44 --> URI Class Initialized
DEBUG - 2011-05-22 11:17:44 --> Router Class Initialized
DEBUG - 2011-05-22 11:17:44 --> Output Class Initialized
DEBUG - 2011-05-22 11:17:44 --> Input Class Initialized
DEBUG - 2011-05-22 11:17:44 --> Global POST and COOKIE data sanitized
DEBUG - 2011-05-22 11:17:44 --> Language Class Initialized
DEBUG - 2011-05-22 11:17:44 --> Loader Class Initialized
DEBUG - 2011-05-22 11:17:44 --> Controller Class Initialized
ERROR - 2011-05-22 11:17:44 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-05-22 11:17:44 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-05-22 11:17:44 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-05-22 11:17:44 --> Model Class Initialized
DEBUG - 2011-05-22 11:17:44 --> Model Class Initialized
DEBUG - 2011-05-22 11:17:44 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-05-22 11:17:44 --> Database Driver Class Initialized
DEBUG - 2011-05-22 11:17:44 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-05-22 11:17:44 --> Helper loaded: url_helper
DEBUG - 2011-05-22 11:17:44 --> File loaded: application/views/common/header.php
DEBUG - 2011-05-22 11:17:44 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-05-22 11:17:44 --> File loaded: application/views/common/footer.php
DEBUG - 2011-05-22 11:17:44 --> File loaded: application/views/layout/main.php
DEBUG - 2011-05-22 11:17:44 --> Final output sent to browser
DEBUG - 2011-05-22 11:17:44 --> Total execution time: 0.0300
DEBUG - 2011-05-22 11:17:44 --> Config Class Initialized
DEBUG - 2011-05-22 11:17:44 --> Hooks Class Initialized
DEBUG - 2011-05-22 11:17:44 --> Utf8 Class Initialized
DEBUG - 2011-05-22 11:17:44 --> UTF-8 Support Enabled
DEBUG - 2011-05-22 11:17:44 --> URI Class Initialized
DEBUG - 2011-05-22 11:17:44 --> Router Class Initialized
DEBUG - 2011-05-22 11:17:44 --> Output Class Initialized
DEBUG - 2011-05-22 11:17:44 --> Input Class Initialized
DEBUG - 2011-05-22 11:17:44 --> Global POST and COOKIE data sanitized
DEBUG - 2011-05-22 11:17:44 --> Language Class Initialized
DEBUG - 2011-05-22 11:17:44 --> Loader Class Initialized
DEBUG - 2011-05-22 11:17:44 --> Controller Class Initialized
DEBUG - 2011-05-22 11:17:44 --> Model Class Initialized
DEBUG - 2011-05-22 11:17:44 --> Model Class Initialized
DEBUG - 2011-05-22 11:17:44 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-05-22 11:17:44 --> Database Driver Class Initialized
DEBUG - 2011-05-22 11:17:45 --> Final output sent to browser
DEBUG - 2011-05-22 11:17:45 --> Total execution time: 0.8287
DEBUG - 2011-05-22 11:17:46 --> Config Class Initialized
DEBUG - 2011-05-22 11:17:46 --> Hooks Class Initialized
DEBUG - 2011-05-22 11:17:46 --> Utf8 Class Initialized
DEBUG - 2011-05-22 11:17:46 --> UTF-8 Support Enabled
DEBUG - 2011-05-22 11:17:46 --> URI Class Initialized
DEBUG - 2011-05-22 11:17:46 --> Router Class Initialized
DEBUG - 2011-05-22 11:17:46 --> Output Class Initialized
DEBUG - 2011-05-22 11:17:46 --> Input Class Initialized
DEBUG - 2011-05-22 11:17:46 --> Global POST and COOKIE data sanitized
DEBUG - 2011-05-22 11:17:46 --> Language Class Initialized
DEBUG - 2011-05-22 11:17:46 --> Loader Class Initialized
DEBUG - 2011-05-22 11:17:46 --> Controller Class Initialized
DEBUG - 2011-05-22 11:17:46 --> Model Class Initialized
DEBUG - 2011-05-22 11:17:46 --> Model Class Initialized
DEBUG - 2011-05-22 11:17:46 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-05-22 11:17:46 --> Database Driver Class Initialized
DEBUG - 2011-05-22 11:17:47 --> Config Class Initialized
DEBUG - 2011-05-22 11:17:47 --> Hooks Class Initialized
DEBUG - 2011-05-22 11:17:47 --> Utf8 Class Initialized
DEBUG - 2011-05-22 11:17:47 --> UTF-8 Support Enabled
DEBUG - 2011-05-22 11:17:47 --> URI Class Initialized
DEBUG - 2011-05-22 11:17:47 --> Router Class Initialized
DEBUG - 2011-05-22 11:17:47 --> Output Class Initialized
DEBUG - 2011-05-22 11:17:47 --> Input Class Initialized
DEBUG - 2011-05-22 11:17:47 --> Global POST and COOKIE data sanitized
DEBUG - 2011-05-22 11:17:47 --> Language Class Initialized
DEBUG - 2011-05-22 11:17:47 --> Loader Class Initialized
DEBUG - 2011-05-22 11:17:47 --> Controller Class Initialized
ERROR - 2011-05-22 11:17:47 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-05-22 11:17:47 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-05-22 11:17:47 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-05-22 11:17:47 --> Model Class Initialized
DEBUG - 2011-05-22 11:17:47 --> Model Class Initialized
DEBUG - 2011-05-22 11:17:47 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-05-22 11:17:47 --> Database Driver Class Initialized
DEBUG - 2011-05-22 11:17:47 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-05-22 11:17:47 --> Helper loaded: url_helper
DEBUG - 2011-05-22 11:17:47 --> File loaded: application/views/common/header.php
DEBUG - 2011-05-22 11:17:47 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-05-22 11:17:47 --> File loaded: application/views/common/footer.php
DEBUG - 2011-05-22 11:17:47 --> File loaded: application/views/layout/main.php
DEBUG - 2011-05-22 11:17:47 --> Final output sent to browser
DEBUG - 2011-05-22 11:17:47 --> Total execution time: 0.0310
DEBUG - 2011-05-22 11:17:47 --> Final output sent to browser
DEBUG - 2011-05-22 11:17:47 --> Total execution time: 0.6903
DEBUG - 2011-05-22 11:17:54 --> Config Class Initialized
DEBUG - 2011-05-22 11:17:54 --> Hooks Class Initialized
DEBUG - 2011-05-22 11:17:54 --> Utf8 Class Initialized
DEBUG - 2011-05-22 11:17:54 --> UTF-8 Support Enabled
DEBUG - 2011-05-22 11:17:54 --> URI Class Initialized
DEBUG - 2011-05-22 11:17:54 --> Router Class Initialized
DEBUG - 2011-05-22 11:17:54 --> Output Class Initialized
DEBUG - 2011-05-22 11:17:54 --> Input Class Initialized
DEBUG - 2011-05-22 11:17:54 --> Global POST and COOKIE data sanitized
DEBUG - 2011-05-22 11:17:54 --> Language Class Initialized
DEBUG - 2011-05-22 11:17:54 --> Loader Class Initialized
DEBUG - 2011-05-22 11:17:54 --> Controller Class Initialized
ERROR - 2011-05-22 11:17:54 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-05-22 11:17:54 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-05-22 11:17:54 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-05-22 11:17:54 --> Model Class Initialized
DEBUG - 2011-05-22 11:17:54 --> Model Class Initialized
DEBUG - 2011-05-22 11:17:54 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-05-22 11:17:54 --> Database Driver Class Initialized
DEBUG - 2011-05-22 11:17:54 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-05-22 11:17:54 --> Helper loaded: url_helper
DEBUG - 2011-05-22 11:17:54 --> File loaded: application/views/common/header.php
DEBUG - 2011-05-22 11:17:54 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-05-22 11:17:54 --> File loaded: application/views/common/footer.php
DEBUG - 2011-05-22 11:17:54 --> File loaded: application/views/layout/main.php
DEBUG - 2011-05-22 11:17:54 --> Final output sent to browser
DEBUG - 2011-05-22 11:17:54 --> Total execution time: 0.0316
DEBUG - 2011-05-22 11:17:55 --> Config Class Initialized
DEBUG - 2011-05-22 11:17:55 --> Hooks Class Initialized
DEBUG - 2011-05-22 11:17:55 --> Utf8 Class Initialized
DEBUG - 2011-05-22 11:17:55 --> UTF-8 Support Enabled
DEBUG - 2011-05-22 11:17:55 --> URI Class Initialized
DEBUG - 2011-05-22 11:17:55 --> Router Class Initialized
DEBUG - 2011-05-22 11:17:55 --> Output Class Initialized
DEBUG - 2011-05-22 11:17:55 --> Input Class Initialized
DEBUG - 2011-05-22 11:17:55 --> Global POST and COOKIE data sanitized
DEBUG - 2011-05-22 11:17:55 --> Language Class Initialized
DEBUG - 2011-05-22 11:17:55 --> Loader Class Initialized
DEBUG - 2011-05-22 11:17:55 --> Controller Class Initialized
DEBUG - 2011-05-22 11:17:55 --> Model Class Initialized
DEBUG - 2011-05-22 11:17:55 --> Model Class Initialized
DEBUG - 2011-05-22 11:17:55 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-05-22 11:17:55 --> Database Driver Class Initialized
DEBUG - 2011-05-22 11:17:55 --> Final output sent to browser
DEBUG - 2011-05-22 11:17:55 --> Total execution time: 0.5855
DEBUG - 2011-05-22 11:17:57 --> Config Class Initialized
DEBUG - 2011-05-22 11:17:57 --> Hooks Class Initialized
DEBUG - 2011-05-22 11:17:57 --> Utf8 Class Initialized
DEBUG - 2011-05-22 11:17:57 --> UTF-8 Support Enabled
DEBUG - 2011-05-22 11:17:57 --> URI Class Initialized
DEBUG - 2011-05-22 11:17:57 --> Router Class Initialized
DEBUG - 2011-05-22 11:17:57 --> Output Class Initialized
DEBUG - 2011-05-22 11:17:57 --> Input Class Initialized
DEBUG - 2011-05-22 11:17:57 --> Global POST and COOKIE data sanitized
DEBUG - 2011-05-22 11:17:57 --> Language Class Initialized
DEBUG - 2011-05-22 11:17:57 --> Loader Class Initialized
DEBUG - 2011-05-22 11:17:57 --> Controller Class Initialized
DEBUG - 2011-05-22 11:17:57 --> Model Class Initialized
DEBUG - 2011-05-22 11:17:57 --> Model Class Initialized
DEBUG - 2011-05-22 11:17:57 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-05-22 11:17:57 --> Database Driver Class Initialized
DEBUG - 2011-05-22 11:17:57 --> Config Class Initialized
DEBUG - 2011-05-22 11:17:57 --> Hooks Class Initialized
DEBUG - 2011-05-22 11:17:57 --> Utf8 Class Initialized
DEBUG - 2011-05-22 11:17:57 --> UTF-8 Support Enabled
DEBUG - 2011-05-22 11:17:57 --> URI Class Initialized
DEBUG - 2011-05-22 11:17:57 --> Router Class Initialized
DEBUG - 2011-05-22 11:17:57 --> Output Class Initialized
DEBUG - 2011-05-22 11:17:57 --> Input Class Initialized
DEBUG - 2011-05-22 11:17:57 --> Global POST and COOKIE data sanitized
DEBUG - 2011-05-22 11:17:57 --> Language Class Initialized
DEBUG - 2011-05-22 11:17:57 --> Loader Class Initialized
DEBUG - 2011-05-22 11:17:57 --> Controller Class Initialized
ERROR - 2011-05-22 11:17:57 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-05-22 11:17:57 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-05-22 11:17:57 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-05-22 11:17:57 --> Model Class Initialized
DEBUG - 2011-05-22 11:17:57 --> Model Class Initialized
DEBUG - 2011-05-22 11:17:57 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-05-22 11:17:57 --> Database Driver Class Initialized
DEBUG - 2011-05-22 11:17:57 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-05-22 11:17:57 --> Helper loaded: url_helper
DEBUG - 2011-05-22 11:17:57 --> File loaded: application/views/common/header.php
DEBUG - 2011-05-22 11:17:57 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-05-22 11:17:57 --> File loaded: application/views/common/footer.php
DEBUG - 2011-05-22 11:17:57 --> File loaded: application/views/layout/main.php
DEBUG - 2011-05-22 11:17:57 --> Final output sent to browser
DEBUG - 2011-05-22 11:17:57 --> Total execution time: 0.0313
DEBUG - 2011-05-22 11:17:58 --> Final output sent to browser
DEBUG - 2011-05-22 11:17:58 --> Total execution time: 0.4649
DEBUG - 2011-05-22 11:18:08 --> Config Class Initialized
DEBUG - 2011-05-22 11:18:08 --> Hooks Class Initialized
DEBUG - 2011-05-22 11:18:08 --> Utf8 Class Initialized
DEBUG - 2011-05-22 11:18:08 --> UTF-8 Support Enabled
DEBUG - 2011-05-22 11:18:08 --> URI Class Initialized
DEBUG - 2011-05-22 11:18:08 --> Router Class Initialized
DEBUG - 2011-05-22 11:18:08 --> Output Class Initialized
DEBUG - 2011-05-22 11:18:08 --> Input Class Initialized
DEBUG - 2011-05-22 11:18:08 --> Global POST and COOKIE data sanitized
DEBUG - 2011-05-22 11:18:08 --> Language Class Initialized
DEBUG - 2011-05-22 11:18:08 --> Loader Class Initialized
DEBUG - 2011-05-22 11:18:08 --> Controller Class Initialized
ERROR - 2011-05-22 11:18:08 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-05-22 11:18:08 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-05-22 11:18:08 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-05-22 11:18:08 --> Model Class Initialized
DEBUG - 2011-05-22 11:18:08 --> Model Class Initialized
DEBUG - 2011-05-22 11:18:08 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-05-22 11:18:08 --> Database Driver Class Initialized
DEBUG - 2011-05-22 11:18:08 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-05-22 11:18:08 --> Helper loaded: url_helper
DEBUG - 2011-05-22 11:18:08 --> File loaded: application/views/common/header.php
DEBUG - 2011-05-22 11:18:08 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-05-22 11:18:08 --> File loaded: application/views/common/footer.php
DEBUG - 2011-05-22 11:18:08 --> File loaded: application/views/layout/main.php
DEBUG - 2011-05-22 11:18:08 --> Final output sent to browser
DEBUG - 2011-05-22 11:18:08 --> Total execution time: 0.0284
DEBUG - 2011-05-22 11:18:09 --> Config Class Initialized
DEBUG - 2011-05-22 11:18:09 --> Hooks Class Initialized
DEBUG - 2011-05-22 11:18:09 --> Utf8 Class Initialized
DEBUG - 2011-05-22 11:18:09 --> UTF-8 Support Enabled
DEBUG - 2011-05-22 11:18:09 --> URI Class Initialized
DEBUG - 2011-05-22 11:18:09 --> Router Class Initialized
DEBUG - 2011-05-22 11:18:09 --> Output Class Initialized
DEBUG - 2011-05-22 11:18:09 --> Input Class Initialized
DEBUG - 2011-05-22 11:18:09 --> Global POST and COOKIE data sanitized
DEBUG - 2011-05-22 11:18:09 --> Language Class Initialized
DEBUG - 2011-05-22 11:18:09 --> Loader Class Initialized
DEBUG - 2011-05-22 11:18:09 --> Controller Class Initialized
DEBUG - 2011-05-22 11:18:09 --> Model Class Initialized
DEBUG - 2011-05-22 11:18:09 --> Model Class Initialized
DEBUG - 2011-05-22 11:18:09 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-05-22 11:18:09 --> Database Driver Class Initialized
DEBUG - 2011-05-22 11:18:09 --> Final output sent to browser
DEBUG - 2011-05-22 11:18:09 --> Total execution time: 0.5002
DEBUG - 2011-05-22 11:18:11 --> Config Class Initialized
DEBUG - 2011-05-22 11:18:11 --> Hooks Class Initialized
DEBUG - 2011-05-22 11:18:11 --> Utf8 Class Initialized
DEBUG - 2011-05-22 11:18:11 --> UTF-8 Support Enabled
DEBUG - 2011-05-22 11:18:11 --> URI Class Initialized
DEBUG - 2011-05-22 11:18:11 --> Router Class Initialized
DEBUG - 2011-05-22 11:18:11 --> Output Class Initialized
DEBUG - 2011-05-22 11:18:11 --> Input Class Initialized
DEBUG - 2011-05-22 11:18:11 --> Global POST and COOKIE data sanitized
DEBUG - 2011-05-22 11:18:11 --> Language Class Initialized
DEBUG - 2011-05-22 11:18:11 --> Loader Class Initialized
DEBUG - 2011-05-22 11:18:11 --> Controller Class Initialized
DEBUG - 2011-05-22 11:18:11 --> Model Class Initialized
DEBUG - 2011-05-22 11:18:11 --> Model Class Initialized
DEBUG - 2011-05-22 11:18:11 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-05-22 11:18:11 --> Database Driver Class Initialized
DEBUG - 2011-05-22 11:18:11 --> Final output sent to browser
DEBUG - 2011-05-22 11:18:11 --> Total execution time: 0.4626
DEBUG - 2011-05-22 11:18:12 --> Config Class Initialized
DEBUG - 2011-05-22 11:18:12 --> Hooks Class Initialized
DEBUG - 2011-05-22 11:18:12 --> Utf8 Class Initialized
DEBUG - 2011-05-22 11:18:12 --> UTF-8 Support Enabled
DEBUG - 2011-05-22 11:18:12 --> URI Class Initialized
DEBUG - 2011-05-22 11:18:12 --> Router Class Initialized
DEBUG - 2011-05-22 11:18:12 --> Output Class Initialized
DEBUG - 2011-05-22 11:18:12 --> Input Class Initialized
DEBUG - 2011-05-22 11:18:12 --> Global POST and COOKIE data sanitized
DEBUG - 2011-05-22 11:18:12 --> Language Class Initialized
DEBUG - 2011-05-22 11:18:12 --> Loader Class Initialized
DEBUG - 2011-05-22 11:18:12 --> Controller Class Initialized
ERROR - 2011-05-22 11:18:12 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-05-22 11:18:12 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-05-22 11:18:12 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-05-22 11:18:12 --> Model Class Initialized
DEBUG - 2011-05-22 11:18:12 --> Model Class Initialized
DEBUG - 2011-05-22 11:18:12 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-05-22 11:18:12 --> Database Driver Class Initialized
DEBUG - 2011-05-22 11:18:12 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-05-22 11:18:12 --> Helper loaded: url_helper
DEBUG - 2011-05-22 11:18:12 --> File loaded: application/views/common/header.php
DEBUG - 2011-05-22 11:18:12 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-05-22 11:18:12 --> File loaded: application/views/common/footer.php
DEBUG - 2011-05-22 11:18:12 --> File loaded: application/views/layout/main.php
DEBUG - 2011-05-22 11:18:12 --> Final output sent to browser
DEBUG - 2011-05-22 11:18:12 --> Total execution time: 0.0278
DEBUG - 2011-05-22 11:18:16 --> Config Class Initialized
DEBUG - 2011-05-22 11:18:16 --> Hooks Class Initialized
DEBUG - 2011-05-22 11:18:16 --> Utf8 Class Initialized
DEBUG - 2011-05-22 11:18:16 --> UTF-8 Support Enabled
DEBUG - 2011-05-22 11:18:16 --> URI Class Initialized
DEBUG - 2011-05-22 11:18:16 --> Router Class Initialized
DEBUG - 2011-05-22 11:18:16 --> Output Class Initialized
DEBUG - 2011-05-22 11:18:16 --> Input Class Initialized
DEBUG - 2011-05-22 11:18:16 --> Global POST and COOKIE data sanitized
DEBUG - 2011-05-22 11:18:16 --> Language Class Initialized
DEBUG - 2011-05-22 11:18:16 --> Loader Class Initialized
DEBUG - 2011-05-22 11:18:16 --> Controller Class Initialized
ERROR - 2011-05-22 11:18:16 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-05-22 11:18:16 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-05-22 11:18:16 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-05-22 11:18:16 --> Model Class Initialized
DEBUG - 2011-05-22 11:18:16 --> Model Class Initialized
DEBUG - 2011-05-22 11:18:16 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-05-22 11:18:16 --> Database Driver Class Initialized
DEBUG - 2011-05-22 11:18:16 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-05-22 11:18:16 --> Helper loaded: url_helper
DEBUG - 2011-05-22 11:18:16 --> File loaded: application/views/common/header.php
DEBUG - 2011-05-22 11:18:16 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-05-22 11:18:16 --> File loaded: application/views/common/footer.php
DEBUG - 2011-05-22 11:18:16 --> File loaded: application/views/layout/main.php
DEBUG - 2011-05-22 11:18:16 --> Final output sent to browser
DEBUG - 2011-05-22 11:18:16 --> Total execution time: 0.0279
DEBUG - 2011-05-22 11:18:16 --> Config Class Initialized
DEBUG - 2011-05-22 11:18:16 --> Hooks Class Initialized
DEBUG - 2011-05-22 11:18:16 --> Utf8 Class Initialized
DEBUG - 2011-05-22 11:18:16 --> UTF-8 Support Enabled
DEBUG - 2011-05-22 11:18:16 --> URI Class Initialized
DEBUG - 2011-05-22 11:18:16 --> Router Class Initialized
DEBUG - 2011-05-22 11:18:16 --> Output Class Initialized
DEBUG - 2011-05-22 11:18:16 --> Input Class Initialized
DEBUG - 2011-05-22 11:18:16 --> Global POST and COOKIE data sanitized
DEBUG - 2011-05-22 11:18:16 --> Language Class Initialized
DEBUG - 2011-05-22 11:18:16 --> Loader Class Initialized
DEBUG - 2011-05-22 11:18:16 --> Controller Class Initialized
DEBUG - 2011-05-22 11:18:16 --> Model Class Initialized
DEBUG - 2011-05-22 11:18:16 --> Model Class Initialized
DEBUG - 2011-05-22 11:18:16 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-05-22 11:18:16 --> Database Driver Class Initialized
DEBUG - 2011-05-22 11:18:17 --> Final output sent to browser
DEBUG - 2011-05-22 11:18:17 --> Total execution time: 0.5598
DEBUG - 2011-05-22 11:18:18 --> Config Class Initialized
DEBUG - 2011-05-22 11:18:18 --> Hooks Class Initialized
DEBUG - 2011-05-22 11:18:18 --> Utf8 Class Initialized
DEBUG - 2011-05-22 11:18:18 --> UTF-8 Support Enabled
DEBUG - 2011-05-22 11:18:18 --> URI Class Initialized
DEBUG - 2011-05-22 11:18:18 --> Router Class Initialized
DEBUG - 2011-05-22 11:18:18 --> Output Class Initialized
DEBUG - 2011-05-22 11:18:18 --> Input Class Initialized
DEBUG - 2011-05-22 11:18:18 --> Global POST and COOKIE data sanitized
DEBUG - 2011-05-22 11:18:18 --> Language Class Initialized
DEBUG - 2011-05-22 11:18:18 --> Loader Class Initialized
DEBUG - 2011-05-22 11:18:18 --> Controller Class Initialized
DEBUG - 2011-05-22 11:18:18 --> Model Class Initialized
DEBUG - 2011-05-22 11:18:18 --> Model Class Initialized
DEBUG - 2011-05-22 11:18:18 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-05-22 11:18:18 --> Database Driver Class Initialized
DEBUG - 2011-05-22 11:18:19 --> Config Class Initialized
DEBUG - 2011-05-22 11:18:19 --> Hooks Class Initialized
DEBUG - 2011-05-22 11:18:19 --> Utf8 Class Initialized
DEBUG - 2011-05-22 11:18:19 --> UTF-8 Support Enabled
DEBUG - 2011-05-22 11:18:19 --> URI Class Initialized
DEBUG - 2011-05-22 11:18:19 --> Router Class Initialized
DEBUG - 2011-05-22 11:18:19 --> Output Class Initialized
DEBUG - 2011-05-22 11:18:19 --> Input Class Initialized
DEBUG - 2011-05-22 11:18:19 --> Global POST and COOKIE data sanitized
DEBUG - 2011-05-22 11:18:19 --> Language Class Initialized
DEBUG - 2011-05-22 11:18:19 --> Loader Class Initialized
DEBUG - 2011-05-22 11:18:19 --> Controller Class Initialized
ERROR - 2011-05-22 11:18:19 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-05-22 11:18:19 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-05-22 11:18:19 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-05-22 11:18:19 --> Model Class Initialized
DEBUG - 2011-05-22 11:18:19 --> Model Class Initialized
DEBUG - 2011-05-22 11:18:19 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-05-22 11:18:19 --> Database Driver Class Initialized
DEBUG - 2011-05-22 11:18:19 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-05-22 11:18:19 --> Helper loaded: url_helper
DEBUG - 2011-05-22 11:18:19 --> File loaded: application/views/common/header.php
DEBUG - 2011-05-22 11:18:19 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-05-22 11:18:19 --> File loaded: application/views/common/footer.php
DEBUG - 2011-05-22 11:18:19 --> File loaded: application/views/layout/main.php
DEBUG - 2011-05-22 11:18:19 --> Final output sent to browser
DEBUG - 2011-05-22 11:18:19 --> Total execution time: 0.0318
DEBUG - 2011-05-22 11:18:19 --> Final output sent to browser
DEBUG - 2011-05-22 11:18:19 --> Total execution time: 0.5002
DEBUG - 2011-05-22 11:18:30 --> Config Class Initialized
DEBUG - 2011-05-22 11:18:30 --> Hooks Class Initialized
DEBUG - 2011-05-22 11:18:30 --> Utf8 Class Initialized
DEBUG - 2011-05-22 11:18:30 --> UTF-8 Support Enabled
DEBUG - 2011-05-22 11:18:30 --> URI Class Initialized
DEBUG - 2011-05-22 11:18:30 --> Router Class Initialized
DEBUG - 2011-05-22 11:18:30 --> Output Class Initialized
DEBUG - 2011-05-22 11:18:30 --> Input Class Initialized
DEBUG - 2011-05-22 11:18:30 --> Global POST and COOKIE data sanitized
DEBUG - 2011-05-22 11:18:30 --> Language Class Initialized
DEBUG - 2011-05-22 11:18:30 --> Loader Class Initialized
DEBUG - 2011-05-22 11:18:30 --> Controller Class Initialized
ERROR - 2011-05-22 11:18:30 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-05-22 11:18:30 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-05-22 11:18:30 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-05-22 11:18:30 --> Model Class Initialized
DEBUG - 2011-05-22 11:18:30 --> Model Class Initialized
DEBUG - 2011-05-22 11:18:30 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-05-22 11:18:30 --> Database Driver Class Initialized
DEBUG - 2011-05-22 11:18:30 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-05-22 11:18:30 --> Helper loaded: url_helper
DEBUG - 2011-05-22 11:18:30 --> File loaded: application/views/common/header.php
DEBUG - 2011-05-22 11:18:30 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-05-22 11:18:30 --> File loaded: application/views/common/footer.php
DEBUG - 2011-05-22 11:18:30 --> File loaded: application/views/layout/main.php
DEBUG - 2011-05-22 11:18:31 --> Final output sent to browser
DEBUG - 2011-05-22 11:18:31 --> Total execution time: 0.0280
DEBUG - 2011-05-22 11:18:31 --> Config Class Initialized
DEBUG - 2011-05-22 11:18:31 --> Hooks Class Initialized
DEBUG - 2011-05-22 11:18:31 --> Utf8 Class Initialized
DEBUG - 2011-05-22 11:18:31 --> UTF-8 Support Enabled
DEBUG - 2011-05-22 11:18:31 --> URI Class Initialized
DEBUG - 2011-05-22 11:18:31 --> Router Class Initialized
DEBUG - 2011-05-22 11:18:31 --> Output Class Initialized
DEBUG - 2011-05-22 11:18:31 --> Input Class Initialized
DEBUG - 2011-05-22 11:18:31 --> Global POST and COOKIE data sanitized
DEBUG - 2011-05-22 11:18:31 --> Language Class Initialized
DEBUG - 2011-05-22 11:18:31 --> Loader Class Initialized
DEBUG - 2011-05-22 11:18:31 --> Controller Class Initialized
DEBUG - 2011-05-22 11:18:31 --> Model Class Initialized
DEBUG - 2011-05-22 11:18:31 --> Model Class Initialized
DEBUG - 2011-05-22 11:18:31 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-05-22 11:18:31 --> Database Driver Class Initialized
DEBUG - 2011-05-22 11:18:31 --> Final output sent to browser
DEBUG - 2011-05-22 11:18:31 --> Total execution time: 0.5042
DEBUG - 2011-05-22 11:18:33 --> Config Class Initialized
DEBUG - 2011-05-22 11:18:33 --> Hooks Class Initialized
DEBUG - 2011-05-22 11:18:33 --> Utf8 Class Initialized
DEBUG - 2011-05-22 11:18:33 --> UTF-8 Support Enabled
DEBUG - 2011-05-22 11:18:33 --> URI Class Initialized
DEBUG - 2011-05-22 11:18:33 --> Router Class Initialized
DEBUG - 2011-05-22 11:18:33 --> Output Class Initialized
DEBUG - 2011-05-22 11:18:33 --> Input Class Initialized
DEBUG - 2011-05-22 11:18:33 --> Global POST and COOKIE data sanitized
DEBUG - 2011-05-22 11:18:33 --> Language Class Initialized
DEBUG - 2011-05-22 11:18:33 --> Loader Class Initialized
DEBUG - 2011-05-22 11:18:33 --> Controller Class Initialized
DEBUG - 2011-05-22 11:18:33 --> Model Class Initialized
DEBUG - 2011-05-22 11:18:33 --> Model Class Initialized
DEBUG - 2011-05-22 11:18:33 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-05-22 11:18:33 --> Database Driver Class Initialized
DEBUG - 2011-05-22 11:18:34 --> Final output sent to browser
DEBUG - 2011-05-22 11:18:34 --> Total execution time: 0.5081
DEBUG - 2011-05-22 11:19:09 --> Config Class Initialized
DEBUG - 2011-05-22 11:19:09 --> Hooks Class Initialized
DEBUG - 2011-05-22 11:19:09 --> Utf8 Class Initialized
DEBUG - 2011-05-22 11:19:09 --> UTF-8 Support Enabled
DEBUG - 2011-05-22 11:19:09 --> URI Class Initialized
DEBUG - 2011-05-22 11:19:09 --> Router Class Initialized
DEBUG - 2011-05-22 11:19:09 --> Output Class Initialized
DEBUG - 2011-05-22 11:19:09 --> Input Class Initialized
DEBUG - 2011-05-22 11:19:09 --> Global POST and COOKIE data sanitized
DEBUG - 2011-05-22 11:19:09 --> Language Class Initialized
DEBUG - 2011-05-22 11:19:09 --> Loader Class Initialized
DEBUG - 2011-05-22 11:19:09 --> Controller Class Initialized
ERROR - 2011-05-22 11:19:09 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-05-22 11:19:09 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-05-22 11:19:09 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-05-22 11:19:09 --> Model Class Initialized
DEBUG - 2011-05-22 11:19:09 --> Model Class Initialized
DEBUG - 2011-05-22 11:19:09 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-05-22 11:19:09 --> Database Driver Class Initialized
DEBUG - 2011-05-22 11:19:09 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-05-22 11:19:09 --> Helper loaded: url_helper
DEBUG - 2011-05-22 11:19:09 --> File loaded: application/views/common/header.php
DEBUG - 2011-05-22 11:19:09 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-05-22 11:19:09 --> File loaded: application/views/common/footer.php
DEBUG - 2011-05-22 11:19:09 --> File loaded: application/views/layout/main.php
DEBUG - 2011-05-22 11:19:09 --> Final output sent to browser
DEBUG - 2011-05-22 11:19:09 --> Total execution time: 0.1070
DEBUG - 2011-05-22 11:19:10 --> Config Class Initialized
DEBUG - 2011-05-22 11:19:10 --> Hooks Class Initialized
DEBUG - 2011-05-22 11:19:10 --> Utf8 Class Initialized
DEBUG - 2011-05-22 11:19:10 --> UTF-8 Support Enabled
DEBUG - 2011-05-22 11:19:10 --> URI Class Initialized
DEBUG - 2011-05-22 11:19:10 --> Router Class Initialized
DEBUG - 2011-05-22 11:19:10 --> Output Class Initialized
DEBUG - 2011-05-22 11:19:10 --> Input Class Initialized
DEBUG - 2011-05-22 11:19:10 --> Global POST and COOKIE data sanitized
DEBUG - 2011-05-22 11:19:10 --> Language Class Initialized
DEBUG - 2011-05-22 11:19:10 --> Loader Class Initialized
DEBUG - 2011-05-22 11:19:10 --> Controller Class Initialized
DEBUG - 2011-05-22 11:19:10 --> Model Class Initialized
DEBUG - 2011-05-22 11:19:10 --> Model Class Initialized
DEBUG - 2011-05-22 11:19:10 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-05-22 11:19:10 --> Database Driver Class Initialized
DEBUG - 2011-05-22 11:19:10 --> Final output sent to browser
DEBUG - 2011-05-22 11:19:10 --> Total execution time: 0.5037
DEBUG - 2011-05-22 11:19:12 --> Config Class Initialized
DEBUG - 2011-05-22 11:19:12 --> Hooks Class Initialized
DEBUG - 2011-05-22 11:19:12 --> Utf8 Class Initialized
DEBUG - 2011-05-22 11:19:12 --> UTF-8 Support Enabled
DEBUG - 2011-05-22 11:19:12 --> URI Class Initialized
DEBUG - 2011-05-22 11:19:12 --> Router Class Initialized
DEBUG - 2011-05-22 11:19:12 --> Output Class Initialized
DEBUG - 2011-05-22 11:19:12 --> Input Class Initialized
DEBUG - 2011-05-22 11:19:12 --> Global POST and COOKIE data sanitized
DEBUG - 2011-05-22 11:19:12 --> Language Class Initialized
DEBUG - 2011-05-22 11:19:12 --> Loader Class Initialized
DEBUG - 2011-05-22 11:19:12 --> Controller Class Initialized
DEBUG - 2011-05-22 11:19:12 --> Model Class Initialized
DEBUG - 2011-05-22 11:19:12 --> Model Class Initialized
DEBUG - 2011-05-22 11:19:12 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-05-22 11:19:12 --> Database Driver Class Initialized
DEBUG - 2011-05-22 11:19:12 --> Final output sent to browser
DEBUG - 2011-05-22 11:19:12 --> Total execution time: 0.4576
DEBUG - 2011-05-22 11:19:13 --> Config Class Initialized
DEBUG - 2011-05-22 11:19:13 --> Hooks Class Initialized
DEBUG - 2011-05-22 11:19:13 --> Utf8 Class Initialized
DEBUG - 2011-05-22 11:19:13 --> UTF-8 Support Enabled
DEBUG - 2011-05-22 11:19:13 --> URI Class Initialized
DEBUG - 2011-05-22 11:19:13 --> Router Class Initialized
DEBUG - 2011-05-22 11:19:13 --> Output Class Initialized
DEBUG - 2011-05-22 11:19:13 --> Input Class Initialized
DEBUG - 2011-05-22 11:19:13 --> Global POST and COOKIE data sanitized
DEBUG - 2011-05-22 11:19:13 --> Language Class Initialized
DEBUG - 2011-05-22 11:19:13 --> Loader Class Initialized
DEBUG - 2011-05-22 11:19:13 --> Controller Class Initialized
ERROR - 2011-05-22 11:19:13 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-05-22 11:19:13 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-05-22 11:19:13 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-05-22 11:19:13 --> Model Class Initialized
DEBUG - 2011-05-22 11:19:13 --> Model Class Initialized
DEBUG - 2011-05-22 11:19:13 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-05-22 11:19:13 --> Database Driver Class Initialized
DEBUG - 2011-05-22 11:19:13 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-05-22 11:19:13 --> Helper loaded: url_helper
DEBUG - 2011-05-22 11:19:13 --> File loaded: application/views/common/header.php
DEBUG - 2011-05-22 11:19:13 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-05-22 11:19:13 --> File loaded: application/views/common/footer.php
DEBUG - 2011-05-22 11:19:13 --> File loaded: application/views/layout/main.php
DEBUG - 2011-05-22 11:19:13 --> Final output sent to browser
DEBUG - 2011-05-22 11:19:13 --> Total execution time: 0.0285
DEBUG - 2011-05-22 11:19:24 --> Config Class Initialized
DEBUG - 2011-05-22 11:19:24 --> Hooks Class Initialized
DEBUG - 2011-05-22 11:19:24 --> Utf8 Class Initialized
DEBUG - 2011-05-22 11:19:24 --> UTF-8 Support Enabled
DEBUG - 2011-05-22 11:19:24 --> URI Class Initialized
DEBUG - 2011-05-22 11:19:24 --> Router Class Initialized
DEBUG - 2011-05-22 11:19:24 --> Output Class Initialized
DEBUG - 2011-05-22 11:19:24 --> Input Class Initialized
DEBUG - 2011-05-22 11:19:24 --> Global POST and COOKIE data sanitized
DEBUG - 2011-05-22 11:19:24 --> Language Class Initialized
DEBUG - 2011-05-22 11:19:24 --> Loader Class Initialized
DEBUG - 2011-05-22 11:19:24 --> Controller Class Initialized
ERROR - 2011-05-22 11:19:24 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-05-22 11:19:24 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-05-22 11:19:24 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-05-22 11:19:24 --> Model Class Initialized
DEBUG - 2011-05-22 11:19:24 --> Model Class Initialized
DEBUG - 2011-05-22 11:19:24 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-05-22 11:19:24 --> Database Driver Class Initialized
DEBUG - 2011-05-22 11:19:24 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-05-22 11:19:24 --> Helper loaded: url_helper
DEBUG - 2011-05-22 11:19:24 --> File loaded: application/views/common/header.php
DEBUG - 2011-05-22 11:19:24 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-05-22 11:19:24 --> File loaded: application/views/common/footer.php
DEBUG - 2011-05-22 11:19:24 --> File loaded: application/views/layout/main.php
DEBUG - 2011-05-22 11:19:24 --> Final output sent to browser
DEBUG - 2011-05-22 11:19:24 --> Total execution time: 0.0298
DEBUG - 2011-05-22 11:19:24 --> Config Class Initialized
DEBUG - 2011-05-22 11:19:24 --> Hooks Class Initialized
DEBUG - 2011-05-22 11:19:24 --> Utf8 Class Initialized
DEBUG - 2011-05-22 11:19:24 --> UTF-8 Support Enabled
DEBUG - 2011-05-22 11:19:24 --> URI Class Initialized
DEBUG - 2011-05-22 11:19:24 --> Router Class Initialized
DEBUG - 2011-05-22 11:19:24 --> Output Class Initialized
DEBUG - 2011-05-22 11:19:24 --> Input Class Initialized
DEBUG - 2011-05-22 11:19:24 --> Global POST and COOKIE data sanitized
DEBUG - 2011-05-22 11:19:24 --> Language Class Initialized
DEBUG - 2011-05-22 11:19:24 --> Loader Class Initialized
DEBUG - 2011-05-22 11:19:24 --> Controller Class Initialized
DEBUG - 2011-05-22 11:19:24 --> Model Class Initialized
DEBUG - 2011-05-22 11:19:24 --> Model Class Initialized
DEBUG - 2011-05-22 11:19:24 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-05-22 11:19:24 --> Database Driver Class Initialized
DEBUG - 2011-05-22 11:19:25 --> Final output sent to browser
DEBUG - 2011-05-22 11:19:25 --> Total execution time: 0.5690
DEBUG - 2011-05-22 11:19:26 --> Config Class Initialized
DEBUG - 2011-05-22 11:19:26 --> Hooks Class Initialized
DEBUG - 2011-05-22 11:19:26 --> Utf8 Class Initialized
DEBUG - 2011-05-22 11:19:26 --> UTF-8 Support Enabled
DEBUG - 2011-05-22 11:19:26 --> URI Class Initialized
DEBUG - 2011-05-22 11:19:26 --> Router Class Initialized
DEBUG - 2011-05-22 11:19:26 --> Output Class Initialized
DEBUG - 2011-05-22 11:19:26 --> Input Class Initialized
DEBUG - 2011-05-22 11:19:26 --> Global POST and COOKIE data sanitized
DEBUG - 2011-05-22 11:19:26 --> Language Class Initialized
DEBUG - 2011-05-22 11:19:26 --> Loader Class Initialized
DEBUG - 2011-05-22 11:19:26 --> Controller Class Initialized
DEBUG - 2011-05-22 11:19:26 --> Model Class Initialized
DEBUG - 2011-05-22 11:19:26 --> Model Class Initialized
DEBUG - 2011-05-22 11:19:26 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-05-22 11:19:26 --> Database Driver Class Initialized
DEBUG - 2011-05-22 11:19:27 --> Config Class Initialized
DEBUG - 2011-05-22 11:19:27 --> Hooks Class Initialized
DEBUG - 2011-05-22 11:19:27 --> Utf8 Class Initialized
DEBUG - 2011-05-22 11:19:27 --> UTF-8 Support Enabled
DEBUG - 2011-05-22 11:19:27 --> URI Class Initialized
DEBUG - 2011-05-22 11:19:27 --> Router Class Initialized
DEBUG - 2011-05-22 11:19:27 --> Output Class Initialized
DEBUG - 2011-05-22 11:19:27 --> Input Class Initialized
DEBUG - 2011-05-22 11:19:27 --> Global POST and COOKIE data sanitized
DEBUG - 2011-05-22 11:19:27 --> Language Class Initialized
DEBUG - 2011-05-22 11:19:27 --> Loader Class Initialized
DEBUG - 2011-05-22 11:19:27 --> Controller Class Initialized
ERROR - 2011-05-22 11:19:27 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-05-22 11:19:27 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-05-22 11:19:27 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-05-22 11:19:27 --> Model Class Initialized
DEBUG - 2011-05-22 11:19:27 --> Model Class Initialized
DEBUG - 2011-05-22 11:19:27 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-05-22 11:19:27 --> Database Driver Class Initialized
DEBUG - 2011-05-22 11:19:27 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-05-22 11:19:27 --> Helper loaded: url_helper
DEBUG - 2011-05-22 11:19:27 --> File loaded: application/views/common/header.php
DEBUG - 2011-05-22 11:19:27 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-05-22 11:19:27 --> File loaded: application/views/common/footer.php
DEBUG - 2011-05-22 11:19:27 --> File loaded: application/views/layout/main.php
DEBUG - 2011-05-22 11:19:27 --> Final output sent to browser
DEBUG - 2011-05-22 11:19:27 --> Total execution time: 0.0306
DEBUG - 2011-05-22 11:19:27 --> Final output sent to browser
DEBUG - 2011-05-22 11:19:27 --> Total execution time: 0.4993
DEBUG - 2011-05-22 11:19:32 --> Config Class Initialized
DEBUG - 2011-05-22 11:19:32 --> Hooks Class Initialized
DEBUG - 2011-05-22 11:19:32 --> Utf8 Class Initialized
DEBUG - 2011-05-22 11:19:32 --> UTF-8 Support Enabled
DEBUG - 2011-05-22 11:19:32 --> URI Class Initialized
DEBUG - 2011-05-22 11:19:32 --> Router Class Initialized
DEBUG - 2011-05-22 11:19:32 --> Output Class Initialized
DEBUG - 2011-05-22 11:19:32 --> Input Class Initialized
DEBUG - 2011-05-22 11:19:32 --> Global POST and COOKIE data sanitized
DEBUG - 2011-05-22 11:19:32 --> Language Class Initialized
DEBUG - 2011-05-22 11:19:32 --> Loader Class Initialized
DEBUG - 2011-05-22 11:19:32 --> Controller Class Initialized
ERROR - 2011-05-22 11:19:32 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-05-22 11:19:32 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-05-22 11:19:32 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-05-22 11:19:32 --> Model Class Initialized
DEBUG - 2011-05-22 11:19:32 --> Model Class Initialized
DEBUG - 2011-05-22 11:19:32 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-05-22 11:19:32 --> Database Driver Class Initialized
DEBUG - 2011-05-22 11:19:32 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-05-22 11:19:32 --> Helper loaded: url_helper
DEBUG - 2011-05-22 11:19:32 --> File loaded: application/views/common/header.php
DEBUG - 2011-05-22 11:19:32 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-05-22 11:19:32 --> File loaded: application/views/common/footer.php
DEBUG - 2011-05-22 11:19:32 --> File loaded: application/views/layout/main.php
DEBUG - 2011-05-22 11:19:32 --> Final output sent to browser
DEBUG - 2011-05-22 11:19:32 --> Total execution time: 0.0303
DEBUG - 2011-05-22 11:19:32 --> Config Class Initialized
DEBUG - 2011-05-22 11:19:32 --> Hooks Class Initialized
DEBUG - 2011-05-22 11:19:32 --> Utf8 Class Initialized
DEBUG - 2011-05-22 11:19:32 --> UTF-8 Support Enabled
DEBUG - 2011-05-22 11:19:32 --> URI Class Initialized
DEBUG - 2011-05-22 11:19:32 --> Router Class Initialized
DEBUG - 2011-05-22 11:19:32 --> Output Class Initialized
DEBUG - 2011-05-22 11:19:32 --> Input Class Initialized
DEBUG - 2011-05-22 11:19:32 --> Global POST and COOKIE data sanitized
DEBUG - 2011-05-22 11:19:32 --> Language Class Initialized
DEBUG - 2011-05-22 11:19:32 --> Loader Class Initialized
DEBUG - 2011-05-22 11:19:32 --> Controller Class Initialized
DEBUG - 2011-05-22 11:19:32 --> Model Class Initialized
DEBUG - 2011-05-22 11:19:32 --> Model Class Initialized
DEBUG - 2011-05-22 11:19:32 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-05-22 11:19:32 --> Database Driver Class Initialized
DEBUG - 2011-05-22 11:19:32 --> Final output sent to browser
DEBUG - 2011-05-22 11:19:32 --> Total execution time: 0.5014
DEBUG - 2011-05-22 11:19:34 --> Config Class Initialized
DEBUG - 2011-05-22 11:19:34 --> Hooks Class Initialized
DEBUG - 2011-05-22 11:19:34 --> Utf8 Class Initialized
DEBUG - 2011-05-22 11:19:34 --> UTF-8 Support Enabled
DEBUG - 2011-05-22 11:19:34 --> URI Class Initialized
DEBUG - 2011-05-22 11:19:34 --> Router Class Initialized
DEBUG - 2011-05-22 11:19:34 --> Output Class Initialized
DEBUG - 2011-05-22 11:19:34 --> Input Class Initialized
DEBUG - 2011-05-22 11:19:34 --> Global POST and COOKIE data sanitized
DEBUG - 2011-05-22 11:19:34 --> Language Class Initialized
DEBUG - 2011-05-22 11:19:34 --> Loader Class Initialized
DEBUG - 2011-05-22 11:19:34 --> Controller Class Initialized
DEBUG - 2011-05-22 11:19:34 --> Model Class Initialized
DEBUG - 2011-05-22 11:19:34 --> Model Class Initialized
DEBUG - 2011-05-22 11:19:34 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-05-22 11:19:34 --> Database Driver Class Initialized
DEBUG - 2011-05-22 11:19:34 --> Config Class Initialized
DEBUG - 2011-05-22 11:19:34 --> Hooks Class Initialized
DEBUG - 2011-05-22 11:19:34 --> Utf8 Class Initialized
DEBUG - 2011-05-22 11:19:34 --> UTF-8 Support Enabled
DEBUG - 2011-05-22 11:19:34 --> URI Class Initialized
DEBUG - 2011-05-22 11:19:34 --> Router Class Initialized
DEBUG - 2011-05-22 11:19:34 --> Output Class Initialized
DEBUG - 2011-05-22 11:19:34 --> Input Class Initialized
DEBUG - 2011-05-22 11:19:34 --> Global POST and COOKIE data sanitized
DEBUG - 2011-05-22 11:19:34 --> Language Class Initialized
DEBUG - 2011-05-22 11:19:34 --> Loader Class Initialized
DEBUG - 2011-05-22 11:19:34 --> Controller Class Initialized
ERROR - 2011-05-22 11:19:34 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-05-22 11:19:34 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-05-22 11:19:34 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-05-22 11:19:34 --> Model Class Initialized
DEBUG - 2011-05-22 11:19:34 --> Model Class Initialized
DEBUG - 2011-05-22 11:19:34 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-05-22 11:19:34 --> Database Driver Class Initialized
DEBUG - 2011-05-22 11:19:34 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-05-22 11:19:34 --> Helper loaded: url_helper
DEBUG - 2011-05-22 11:19:34 --> File loaded: application/views/common/header.php
DEBUG - 2011-05-22 11:19:34 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-05-22 11:19:34 --> File loaded: application/views/common/footer.php
DEBUG - 2011-05-22 11:19:34 --> File loaded: application/views/layout/main.php
DEBUG - 2011-05-22 11:19:34 --> Final output sent to browser
DEBUG - 2011-05-22 11:19:34 --> Total execution time: 0.0325
DEBUG - 2011-05-22 11:19:35 --> Final output sent to browser
DEBUG - 2011-05-22 11:19:35 --> Total execution time: 0.5108
DEBUG - 2011-05-22 11:19:41 --> Config Class Initialized
DEBUG - 2011-05-22 11:19:41 --> Hooks Class Initialized
DEBUG - 2011-05-22 11:19:41 --> Utf8 Class Initialized
DEBUG - 2011-05-22 11:19:41 --> UTF-8 Support Enabled
DEBUG - 2011-05-22 11:19:41 --> URI Class Initialized
DEBUG - 2011-05-22 11:19:41 --> Router Class Initialized
DEBUG - 2011-05-22 11:19:41 --> Output Class Initialized
DEBUG - 2011-05-22 11:19:41 --> Input Class Initialized
DEBUG - 2011-05-22 11:19:41 --> Global POST and COOKIE data sanitized
DEBUG - 2011-05-22 11:19:41 --> Language Class Initialized
DEBUG - 2011-05-22 11:19:41 --> Loader Class Initialized
DEBUG - 2011-05-22 11:19:41 --> Controller Class Initialized
ERROR - 2011-05-22 11:19:41 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-05-22 11:19:41 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-05-22 11:19:41 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-05-22 11:19:41 --> Model Class Initialized
DEBUG - 2011-05-22 11:19:41 --> Model Class Initialized
DEBUG - 2011-05-22 11:19:41 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-05-22 11:19:41 --> Database Driver Class Initialized
DEBUG - 2011-05-22 11:19:41 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-05-22 11:19:41 --> Helper loaded: url_helper
DEBUG - 2011-05-22 11:19:41 --> File loaded: application/views/common/header.php
DEBUG - 2011-05-22 11:19:41 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-05-22 11:19:41 --> File loaded: application/views/common/footer.php
DEBUG - 2011-05-22 11:19:41 --> File loaded: application/views/layout/main.php
DEBUG - 2011-05-22 11:19:41 --> Final output sent to browser
DEBUG - 2011-05-22 11:19:41 --> Total execution time: 0.0330
DEBUG - 2011-05-22 11:19:42 --> Config Class Initialized
DEBUG - 2011-05-22 11:19:42 --> Hooks Class Initialized
DEBUG - 2011-05-22 11:19:42 --> Utf8 Class Initialized
DEBUG - 2011-05-22 11:19:42 --> UTF-8 Support Enabled
DEBUG - 2011-05-22 11:19:42 --> URI Class Initialized
DEBUG - 2011-05-22 11:19:42 --> Router Class Initialized
DEBUG - 2011-05-22 11:19:42 --> Output Class Initialized
DEBUG - 2011-05-22 11:19:42 --> Input Class Initialized
DEBUG - 2011-05-22 11:19:42 --> Global POST and COOKIE data sanitized
DEBUG - 2011-05-22 11:19:42 --> Language Class Initialized
DEBUG - 2011-05-22 11:19:42 --> Loader Class Initialized
DEBUG - 2011-05-22 11:19:42 --> Controller Class Initialized
DEBUG - 2011-05-22 11:19:42 --> Model Class Initialized
DEBUG - 2011-05-22 11:19:42 --> Model Class Initialized
DEBUG - 2011-05-22 11:19:42 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-05-22 11:19:42 --> Database Driver Class Initialized
DEBUG - 2011-05-22 11:19:42 --> Final output sent to browser
DEBUG - 2011-05-22 11:19:42 --> Total execution time: 0.5021
DEBUG - 2011-05-22 11:19:44 --> Config Class Initialized
DEBUG - 2011-05-22 11:19:44 --> Hooks Class Initialized
DEBUG - 2011-05-22 11:19:44 --> Utf8 Class Initialized
DEBUG - 2011-05-22 11:19:44 --> UTF-8 Support Enabled
DEBUG - 2011-05-22 11:19:44 --> URI Class Initialized
DEBUG - 2011-05-22 11:19:44 --> Router Class Initialized
DEBUG - 2011-05-22 11:19:44 --> Output Class Initialized
DEBUG - 2011-05-22 11:19:44 --> Input Class Initialized
DEBUG - 2011-05-22 11:19:44 --> Global POST and COOKIE data sanitized
DEBUG - 2011-05-22 11:19:44 --> Language Class Initialized
DEBUG - 2011-05-22 11:19:44 --> Loader Class Initialized
DEBUG - 2011-05-22 11:19:44 --> Controller Class Initialized
DEBUG - 2011-05-22 11:19:44 --> Model Class Initialized
DEBUG - 2011-05-22 11:19:44 --> Model Class Initialized
DEBUG - 2011-05-22 11:19:44 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-05-22 11:19:44 --> Database Driver Class Initialized
DEBUG - 2011-05-22 11:19:44 --> Final output sent to browser
DEBUG - 2011-05-22 11:19:44 --> Total execution time: 0.6011
DEBUG - 2011-05-22 11:19:55 --> Config Class Initialized
DEBUG - 2011-05-22 11:19:55 --> Hooks Class Initialized
DEBUG - 2011-05-22 11:19:55 --> Utf8 Class Initialized
DEBUG - 2011-05-22 11:19:55 --> UTF-8 Support Enabled
DEBUG - 2011-05-22 11:19:55 --> URI Class Initialized
DEBUG - 2011-05-22 11:19:55 --> Router Class Initialized
DEBUG - 2011-05-22 11:19:55 --> Output Class Initialized
DEBUG - 2011-05-22 11:19:55 --> Input Class Initialized
DEBUG - 2011-05-22 11:19:55 --> Global POST and COOKIE data sanitized
DEBUG - 2011-05-22 11:19:55 --> Language Class Initialized
DEBUG - 2011-05-22 11:19:55 --> Loader Class Initialized
DEBUG - 2011-05-22 11:19:55 --> Controller Class Initialized
ERROR - 2011-05-22 11:19:55 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-05-22 11:19:55 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-05-22 11:19:55 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-05-22 11:19:55 --> Model Class Initialized
DEBUG - 2011-05-22 11:19:55 --> Model Class Initialized
DEBUG - 2011-05-22 11:19:55 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-05-22 11:19:55 --> Database Driver Class Initialized
DEBUG - 2011-05-22 11:19:55 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-05-22 11:19:55 --> Helper loaded: url_helper
DEBUG - 2011-05-22 11:19:55 --> File loaded: application/views/common/header.php
DEBUG - 2011-05-22 11:19:55 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-05-22 11:19:55 --> File loaded: application/views/common/footer.php
DEBUG - 2011-05-22 11:19:55 --> File loaded: application/views/layout/main.php
DEBUG - 2011-05-22 11:19:55 --> Final output sent to browser
DEBUG - 2011-05-22 11:19:55 --> Total execution time: 0.0296
DEBUG - 2011-05-22 11:19:56 --> Config Class Initialized
DEBUG - 2011-05-22 11:19:56 --> Hooks Class Initialized
DEBUG - 2011-05-22 11:19:56 --> Utf8 Class Initialized
DEBUG - 2011-05-22 11:19:56 --> UTF-8 Support Enabled
DEBUG - 2011-05-22 11:19:56 --> URI Class Initialized
DEBUG - 2011-05-22 11:19:56 --> Router Class Initialized
DEBUG - 2011-05-22 11:19:56 --> Output Class Initialized
DEBUG - 2011-05-22 11:19:56 --> Input Class Initialized
DEBUG - 2011-05-22 11:19:56 --> Global POST and COOKIE data sanitized
DEBUG - 2011-05-22 11:19:56 --> Language Class Initialized
DEBUG - 2011-05-22 11:19:56 --> Loader Class Initialized
DEBUG - 2011-05-22 11:19:56 --> Controller Class Initialized
DEBUG - 2011-05-22 11:19:56 --> Model Class Initialized
DEBUG - 2011-05-22 11:19:56 --> Model Class Initialized
DEBUG - 2011-05-22 11:19:56 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-05-22 11:19:56 --> Database Driver Class Initialized
DEBUG - 2011-05-22 11:19:56 --> Final output sent to browser
DEBUG - 2011-05-22 11:19:56 --> Total execution time: 0.5678
DEBUG - 2011-05-22 11:19:58 --> Config Class Initialized
DEBUG - 2011-05-22 11:19:58 --> Hooks Class Initialized
DEBUG - 2011-05-22 11:19:58 --> Utf8 Class Initialized
DEBUG - 2011-05-22 11:19:58 --> UTF-8 Support Enabled
DEBUG - 2011-05-22 11:19:58 --> URI Class Initialized
DEBUG - 2011-05-22 11:19:58 --> Router Class Initialized
DEBUG - 2011-05-22 11:19:58 --> Output Class Initialized
DEBUG - 2011-05-22 11:19:58 --> Input Class Initialized
DEBUG - 2011-05-22 11:19:58 --> Global POST and COOKIE data sanitized
DEBUG - 2011-05-22 11:19:58 --> Language Class Initialized
DEBUG - 2011-05-22 11:19:58 --> Loader Class Initialized
DEBUG - 2011-05-22 11:19:58 --> Controller Class Initialized
DEBUG - 2011-05-22 11:19:58 --> Model Class Initialized
DEBUG - 2011-05-22 11:19:58 --> Model Class Initialized
DEBUG - 2011-05-22 11:19:58 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-05-22 11:19:58 --> Database Driver Class Initialized
DEBUG - 2011-05-22 11:19:58 --> Config Class Initialized
DEBUG - 2011-05-22 11:19:58 --> Hooks Class Initialized
DEBUG - 2011-05-22 11:19:58 --> Utf8 Class Initialized
DEBUG - 2011-05-22 11:19:58 --> UTF-8 Support Enabled
DEBUG - 2011-05-22 11:19:58 --> URI Class Initialized
DEBUG - 2011-05-22 11:19:58 --> Router Class Initialized
DEBUG - 2011-05-22 11:19:58 --> Output Class Initialized
DEBUG - 2011-05-22 11:19:58 --> Input Class Initialized
DEBUG - 2011-05-22 11:19:58 --> Global POST and COOKIE data sanitized
DEBUG - 2011-05-22 11:19:58 --> Language Class Initialized
DEBUG - 2011-05-22 11:19:58 --> Loader Class Initialized
DEBUG - 2011-05-22 11:19:58 --> Controller Class Initialized
ERROR - 2011-05-22 11:19:58 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-05-22 11:19:58 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-05-22 11:19:58 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-05-22 11:19:58 --> Model Class Initialized
DEBUG - 2011-05-22 11:19:58 --> Model Class Initialized
DEBUG - 2011-05-22 11:19:58 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-05-22 11:19:58 --> Database Driver Class Initialized
DEBUG - 2011-05-22 11:19:58 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-05-22 11:19:58 --> Helper loaded: url_helper
DEBUG - 2011-05-22 11:19:58 --> File loaded: application/views/common/header.php
DEBUG - 2011-05-22 11:19:58 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-05-22 11:19:58 --> File loaded: application/views/common/footer.php
DEBUG - 2011-05-22 11:19:58 --> File loaded: application/views/layout/main.php
DEBUG - 2011-05-22 11:19:58 --> Final output sent to browser
DEBUG - 2011-05-22 11:19:58 --> Total execution time: 0.0286
DEBUG - 2011-05-22 11:19:58 --> Final output sent to browser
DEBUG - 2011-05-22 11:19:58 --> Total execution time: 0.5557
DEBUG - 2011-05-22 11:20:04 --> Config Class Initialized
DEBUG - 2011-05-22 11:20:04 --> Hooks Class Initialized
DEBUG - 2011-05-22 11:20:04 --> Utf8 Class Initialized
DEBUG - 2011-05-22 11:20:04 --> UTF-8 Support Enabled
DEBUG - 2011-05-22 11:20:04 --> URI Class Initialized
DEBUG - 2011-05-22 11:20:04 --> Router Class Initialized
DEBUG - 2011-05-22 11:20:04 --> Output Class Initialized
DEBUG - 2011-05-22 11:20:04 --> Input Class Initialized
DEBUG - 2011-05-22 11:20:04 --> Global POST and COOKIE data sanitized
DEBUG - 2011-05-22 11:20:04 --> Language Class Initialized
DEBUG - 2011-05-22 11:20:04 --> Loader Class Initialized
DEBUG - 2011-05-22 11:20:04 --> Controller Class Initialized
ERROR - 2011-05-22 11:20:04 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-05-22 11:20:04 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-05-22 11:20:04 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-05-22 11:20:04 --> Model Class Initialized
DEBUG - 2011-05-22 11:20:04 --> Model Class Initialized
DEBUG - 2011-05-22 11:20:04 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-05-22 11:20:04 --> Database Driver Class Initialized
DEBUG - 2011-05-22 11:20:04 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-05-22 11:20:04 --> Helper loaded: url_helper
DEBUG - 2011-05-22 11:20:04 --> File loaded: application/views/common/header.php
DEBUG - 2011-05-22 11:20:04 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-05-22 11:20:04 --> File loaded: application/views/common/footer.php
DEBUG - 2011-05-22 11:20:04 --> File loaded: application/views/layout/main.php
DEBUG - 2011-05-22 11:20:04 --> Final output sent to browser
DEBUG - 2011-05-22 11:20:04 --> Total execution time: 0.1656
DEBUG - 2011-05-22 11:20:04 --> Config Class Initialized
DEBUG - 2011-05-22 11:20:04 --> Hooks Class Initialized
DEBUG - 2011-05-22 11:20:04 --> Utf8 Class Initialized
DEBUG - 2011-05-22 11:20:04 --> UTF-8 Support Enabled
DEBUG - 2011-05-22 11:20:04 --> URI Class Initialized
DEBUG - 2011-05-22 11:20:04 --> Router Class Initialized
DEBUG - 2011-05-22 11:20:04 --> Output Class Initialized
DEBUG - 2011-05-22 11:20:04 --> Input Class Initialized
DEBUG - 2011-05-22 11:20:04 --> Global POST and COOKIE data sanitized
DEBUG - 2011-05-22 11:20:04 --> Language Class Initialized
DEBUG - 2011-05-22 11:20:04 --> Loader Class Initialized
DEBUG - 2011-05-22 11:20:04 --> Controller Class Initialized
DEBUG - 2011-05-22 11:20:04 --> Model Class Initialized
DEBUG - 2011-05-22 11:20:04 --> Model Class Initialized
DEBUG - 2011-05-22 11:20:04 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-05-22 11:20:04 --> Database Driver Class Initialized
DEBUG - 2011-05-22 11:20:05 --> Final output sent to browser
DEBUG - 2011-05-22 11:20:05 --> Total execution time: 0.9508
DEBUG - 2011-05-22 11:20:06 --> Config Class Initialized
DEBUG - 2011-05-22 11:20:06 --> Hooks Class Initialized
DEBUG - 2011-05-22 11:20:06 --> Utf8 Class Initialized
DEBUG - 2011-05-22 11:20:06 --> UTF-8 Support Enabled
DEBUG - 2011-05-22 11:20:06 --> URI Class Initialized
DEBUG - 2011-05-22 11:20:06 --> Router Class Initialized
DEBUG - 2011-05-22 11:20:06 --> Output Class Initialized
DEBUG - 2011-05-22 11:20:06 --> Input Class Initialized
DEBUG - 2011-05-22 11:20:06 --> Global POST and COOKIE data sanitized
DEBUG - 2011-05-22 11:20:06 --> Language Class Initialized
DEBUG - 2011-05-22 11:20:06 --> Loader Class Initialized
DEBUG - 2011-05-22 11:20:06 --> Controller Class Initialized
DEBUG - 2011-05-22 11:20:06 --> Model Class Initialized
DEBUG - 2011-05-22 11:20:06 --> Model Class Initialized
DEBUG - 2011-05-22 11:20:06 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-05-22 11:20:06 --> Database Driver Class Initialized
DEBUG - 2011-05-22 11:20:06 --> Config Class Initialized
DEBUG - 2011-05-22 11:20:06 --> Hooks Class Initialized
DEBUG - 2011-05-22 11:20:06 --> Utf8 Class Initialized
DEBUG - 2011-05-22 11:20:06 --> UTF-8 Support Enabled
DEBUG - 2011-05-22 11:20:06 --> URI Class Initialized
DEBUG - 2011-05-22 11:20:06 --> Router Class Initialized
DEBUG - 2011-05-22 11:20:06 --> Output Class Initialized
DEBUG - 2011-05-22 11:20:06 --> Input Class Initialized
DEBUG - 2011-05-22 11:20:06 --> Global POST and COOKIE data sanitized
DEBUG - 2011-05-22 11:20:06 --> Language Class Initialized
DEBUG - 2011-05-22 11:20:06 --> Loader Class Initialized
DEBUG - 2011-05-22 11:20:06 --> Controller Class Initialized
ERROR - 2011-05-22 11:20:06 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-05-22 11:20:06 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-05-22 11:20:06 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-05-22 11:20:06 --> Model Class Initialized
DEBUG - 2011-05-22 11:20:06 --> Model Class Initialized
DEBUG - 2011-05-22 11:20:06 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-05-22 11:20:06 --> Database Driver Class Initialized
DEBUG - 2011-05-22 11:20:07 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-05-22 11:20:07 --> Helper loaded: url_helper
DEBUG - 2011-05-22 11:20:07 --> File loaded: application/views/common/header.php
DEBUG - 2011-05-22 11:20:07 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-05-22 11:20:07 --> File loaded: application/views/common/footer.php
DEBUG - 2011-05-22 11:20:07 --> File loaded: application/views/layout/main.php
DEBUG - 2011-05-22 11:20:07 --> Final output sent to browser
DEBUG - 2011-05-22 11:20:07 --> Total execution time: 0.0514
DEBUG - 2011-05-22 11:20:07 --> Final output sent to browser
DEBUG - 2011-05-22 11:20:07 --> Total execution time: 0.5025
DEBUG - 2011-05-22 11:20:17 --> Config Class Initialized
DEBUG - 2011-05-22 11:20:17 --> Hooks Class Initialized
DEBUG - 2011-05-22 11:20:17 --> Utf8 Class Initialized
DEBUG - 2011-05-22 11:20:17 --> UTF-8 Support Enabled
DEBUG - 2011-05-22 11:20:17 --> URI Class Initialized
DEBUG - 2011-05-22 11:20:17 --> Router Class Initialized
DEBUG - 2011-05-22 11:20:17 --> Output Class Initialized
DEBUG - 2011-05-22 11:20:17 --> Input Class Initialized
DEBUG - 2011-05-22 11:20:17 --> Global POST and COOKIE data sanitized
DEBUG - 2011-05-22 11:20:17 --> Language Class Initialized
DEBUG - 2011-05-22 11:20:17 --> Loader Class Initialized
DEBUG - 2011-05-22 11:20:17 --> Controller Class Initialized
ERROR - 2011-05-22 11:20:17 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-05-22 11:20:17 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-05-22 11:20:17 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-05-22 11:20:17 --> Model Class Initialized
DEBUG - 2011-05-22 11:20:17 --> Model Class Initialized
DEBUG - 2011-05-22 11:20:17 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-05-22 11:20:17 --> Database Driver Class Initialized
DEBUG - 2011-05-22 11:20:17 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-05-22 11:20:17 --> Helper loaded: url_helper
DEBUG - 2011-05-22 11:20:17 --> File loaded: application/views/common/header.php
DEBUG - 2011-05-22 11:20:17 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-05-22 11:20:17 --> File loaded: application/views/common/footer.php
DEBUG - 2011-05-22 11:20:17 --> File loaded: application/views/layout/main.php
DEBUG - 2011-05-22 11:20:17 --> Final output sent to browser
DEBUG - 2011-05-22 11:20:17 --> Total execution time: 0.0277
DEBUG - 2011-05-22 11:20:20 --> Config Class Initialized
DEBUG - 2011-05-22 11:20:20 --> Hooks Class Initialized
DEBUG - 2011-05-22 11:20:20 --> Utf8 Class Initialized
DEBUG - 2011-05-22 11:20:20 --> UTF-8 Support Enabled
DEBUG - 2011-05-22 11:20:20 --> URI Class Initialized
DEBUG - 2011-05-22 11:20:20 --> Router Class Initialized
DEBUG - 2011-05-22 11:20:20 --> Output Class Initialized
DEBUG - 2011-05-22 11:20:20 --> Input Class Initialized
DEBUG - 2011-05-22 11:20:20 --> Global POST and COOKIE data sanitized
DEBUG - 2011-05-22 11:20:20 --> Language Class Initialized
DEBUG - 2011-05-22 11:20:20 --> Loader Class Initialized
DEBUG - 2011-05-22 11:20:20 --> Controller Class Initialized
DEBUG - 2011-05-22 11:20:20 --> Model Class Initialized
DEBUG - 2011-05-22 11:20:20 --> Model Class Initialized
DEBUG - 2011-05-22 11:20:20 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-05-22 11:20:20 --> Database Driver Class Initialized
DEBUG - 2011-05-22 11:20:20 --> Final output sent to browser
DEBUG - 2011-05-22 11:20:20 --> Total execution time: 0.8500
DEBUG - 2011-05-22 11:20:30 --> Config Class Initialized
DEBUG - 2011-05-22 11:20:30 --> Hooks Class Initialized
DEBUG - 2011-05-22 11:20:30 --> Utf8 Class Initialized
DEBUG - 2011-05-22 11:20:30 --> UTF-8 Support Enabled
DEBUG - 2011-05-22 11:20:30 --> URI Class Initialized
DEBUG - 2011-05-22 11:20:30 --> Router Class Initialized
DEBUG - 2011-05-22 11:20:30 --> Output Class Initialized
DEBUG - 2011-05-22 11:20:30 --> Input Class Initialized
DEBUG - 2011-05-22 11:20:30 --> Global POST and COOKIE data sanitized
DEBUG - 2011-05-22 11:20:30 --> Language Class Initialized
DEBUG - 2011-05-22 11:20:30 --> Loader Class Initialized
DEBUG - 2011-05-22 11:20:30 --> Controller Class Initialized
ERROR - 2011-05-22 11:20:30 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-05-22 11:20:30 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-05-22 11:20:30 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-05-22 11:20:30 --> Model Class Initialized
DEBUG - 2011-05-22 11:20:30 --> Model Class Initialized
DEBUG - 2011-05-22 11:20:30 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-05-22 11:20:30 --> Database Driver Class Initialized
DEBUG - 2011-05-22 11:20:30 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-05-22 11:20:30 --> Helper loaded: url_helper
DEBUG - 2011-05-22 11:20:30 --> File loaded: application/views/common/header.php
DEBUG - 2011-05-22 11:20:30 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-05-22 11:20:30 --> File loaded: application/views/common/footer.php
DEBUG - 2011-05-22 11:20:30 --> File loaded: application/views/layout/main.php
DEBUG - 2011-05-22 11:20:30 --> Final output sent to browser
DEBUG - 2011-05-22 11:20:30 --> Total execution time: 0.0329
DEBUG - 2011-05-22 11:20:32 --> Config Class Initialized
DEBUG - 2011-05-22 11:20:32 --> Hooks Class Initialized
DEBUG - 2011-05-22 11:20:32 --> Utf8 Class Initialized
DEBUG - 2011-05-22 11:20:32 --> UTF-8 Support Enabled
DEBUG - 2011-05-22 11:20:32 --> URI Class Initialized
DEBUG - 2011-05-22 11:20:32 --> Router Class Initialized
DEBUG - 2011-05-22 11:20:32 --> Output Class Initialized
DEBUG - 2011-05-22 11:20:32 --> Input Class Initialized
DEBUG - 2011-05-22 11:20:32 --> Global POST and COOKIE data sanitized
DEBUG - 2011-05-22 11:20:32 --> Language Class Initialized
DEBUG - 2011-05-22 11:20:32 --> Loader Class Initialized
DEBUG - 2011-05-22 11:20:32 --> Controller Class Initialized
DEBUG - 2011-05-22 11:20:32 --> Model Class Initialized
DEBUG - 2011-05-22 11:20:32 --> Model Class Initialized
DEBUG - 2011-05-22 11:20:32 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-05-22 11:20:32 --> Database Driver Class Initialized
DEBUG - 2011-05-22 11:20:33 --> Final output sent to browser
DEBUG - 2011-05-22 11:20:33 --> Total execution time: 0.4739
DEBUG - 2011-05-22 11:20:36 --> Config Class Initialized
DEBUG - 2011-05-22 11:20:36 --> Hooks Class Initialized
DEBUG - 2011-05-22 11:20:36 --> Utf8 Class Initialized
DEBUG - 2011-05-22 11:20:36 --> UTF-8 Support Enabled
DEBUG - 2011-05-22 11:20:36 --> URI Class Initialized
DEBUG - 2011-05-22 11:20:36 --> Router Class Initialized
DEBUG - 2011-05-22 11:20:36 --> Output Class Initialized
DEBUG - 2011-05-22 11:20:36 --> Input Class Initialized
DEBUG - 2011-05-22 11:20:36 --> Global POST and COOKIE data sanitized
DEBUG - 2011-05-22 11:20:36 --> Language Class Initialized
DEBUG - 2011-05-22 11:20:36 --> Loader Class Initialized
DEBUG - 2011-05-22 11:20:36 --> Controller Class Initialized
ERROR - 2011-05-22 11:20:36 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-05-22 11:20:36 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-05-22 11:20:36 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-05-22 11:20:36 --> Model Class Initialized
DEBUG - 2011-05-22 11:20:36 --> Model Class Initialized
DEBUG - 2011-05-22 11:20:36 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-05-22 11:20:36 --> Database Driver Class Initialized
DEBUG - 2011-05-22 11:20:36 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-05-22 11:20:36 --> Helper loaded: url_helper
DEBUG - 2011-05-22 11:20:36 --> File loaded: application/views/common/header.php
DEBUG - 2011-05-22 11:20:36 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-05-22 11:20:36 --> File loaded: application/views/common/footer.php
DEBUG - 2011-05-22 11:20:36 --> File loaded: application/views/layout/main.php
DEBUG - 2011-05-22 11:20:36 --> Final output sent to browser
DEBUG - 2011-05-22 11:20:36 --> Total execution time: 0.0285
DEBUG - 2011-05-22 11:20:36 --> Config Class Initialized
DEBUG - 2011-05-22 11:20:36 --> Hooks Class Initialized
DEBUG - 2011-05-22 11:20:36 --> Utf8 Class Initialized
DEBUG - 2011-05-22 11:20:36 --> UTF-8 Support Enabled
DEBUG - 2011-05-22 11:20:36 --> URI Class Initialized
DEBUG - 2011-05-22 11:20:36 --> Router Class Initialized
DEBUG - 2011-05-22 11:20:36 --> Output Class Initialized
DEBUG - 2011-05-22 11:20:36 --> Input Class Initialized
DEBUG - 2011-05-22 11:20:36 --> Global POST and COOKIE data sanitized
DEBUG - 2011-05-22 11:20:36 --> Language Class Initialized
DEBUG - 2011-05-22 11:20:36 --> Loader Class Initialized
DEBUG - 2011-05-22 11:20:36 --> Controller Class Initialized
DEBUG - 2011-05-22 11:20:36 --> Model Class Initialized
DEBUG - 2011-05-22 11:20:36 --> Model Class Initialized
DEBUG - 2011-05-22 11:20:36 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-05-22 11:20:36 --> Database Driver Class Initialized
DEBUG - 2011-05-22 11:20:37 --> Final output sent to browser
DEBUG - 2011-05-22 11:20:37 --> Total execution time: 0.5314
DEBUG - 2011-05-22 11:20:38 --> Config Class Initialized
DEBUG - 2011-05-22 11:20:38 --> Hooks Class Initialized
DEBUG - 2011-05-22 11:20:38 --> Utf8 Class Initialized
DEBUG - 2011-05-22 11:20:38 --> UTF-8 Support Enabled
DEBUG - 2011-05-22 11:20:38 --> URI Class Initialized
DEBUG - 2011-05-22 11:20:38 --> Router Class Initialized
DEBUG - 2011-05-22 11:20:38 --> Output Class Initialized
DEBUG - 2011-05-22 11:20:38 --> Input Class Initialized
DEBUG - 2011-05-22 11:20:38 --> Global POST and COOKIE data sanitized
DEBUG - 2011-05-22 11:20:38 --> Language Class Initialized
DEBUG - 2011-05-22 11:20:38 --> Loader Class Initialized
DEBUG - 2011-05-22 11:20:38 --> Controller Class Initialized
DEBUG - 2011-05-22 11:20:38 --> Model Class Initialized
DEBUG - 2011-05-22 11:20:38 --> Model Class Initialized
DEBUG - 2011-05-22 11:20:38 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-05-22 11:20:38 --> Database Driver Class Initialized
DEBUG - 2011-05-22 11:20:38 --> Config Class Initialized
DEBUG - 2011-05-22 11:20:38 --> Hooks Class Initialized
DEBUG - 2011-05-22 11:20:38 --> Utf8 Class Initialized
DEBUG - 2011-05-22 11:20:38 --> UTF-8 Support Enabled
DEBUG - 2011-05-22 11:20:38 --> URI Class Initialized
DEBUG - 2011-05-22 11:20:38 --> Router Class Initialized
DEBUG - 2011-05-22 11:20:38 --> Output Class Initialized
DEBUG - 2011-05-22 11:20:38 --> Input Class Initialized
DEBUG - 2011-05-22 11:20:38 --> Global POST and COOKIE data sanitized
DEBUG - 2011-05-22 11:20:38 --> Language Class Initialized
DEBUG - 2011-05-22 11:20:38 --> Loader Class Initialized
DEBUG - 2011-05-22 11:20:38 --> Controller Class Initialized
ERROR - 2011-05-22 11:20:38 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-05-22 11:20:38 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-05-22 11:20:38 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-05-22 11:20:38 --> Model Class Initialized
DEBUG - 2011-05-22 11:20:38 --> Model Class Initialized
DEBUG - 2011-05-22 11:20:38 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-05-22 11:20:38 --> Database Driver Class Initialized
DEBUG - 2011-05-22 11:20:38 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-05-22 11:20:38 --> Helper loaded: url_helper
DEBUG - 2011-05-22 11:20:38 --> File loaded: application/views/common/header.php
DEBUG - 2011-05-22 11:20:38 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-05-22 11:20:38 --> File loaded: application/views/common/footer.php
DEBUG - 2011-05-22 11:20:38 --> File loaded: application/views/layout/main.php
DEBUG - 2011-05-22 11:20:38 --> Final output sent to browser
DEBUG - 2011-05-22 11:20:38 --> Total execution time: 0.0264
DEBUG - 2011-05-22 11:20:39 --> Config Class Initialized
DEBUG - 2011-05-22 11:20:39 --> Hooks Class Initialized
DEBUG - 2011-05-22 11:20:39 --> Utf8 Class Initialized
DEBUG - 2011-05-22 11:20:39 --> UTF-8 Support Enabled
DEBUG - 2011-05-22 11:20:39 --> URI Class Initialized
DEBUG - 2011-05-22 11:20:39 --> Router Class Initialized
DEBUG - 2011-05-22 11:20:39 --> Output Class Initialized
DEBUG - 2011-05-22 11:20:39 --> Input Class Initialized
DEBUG - 2011-05-22 11:20:39 --> Global POST and COOKIE data sanitized
DEBUG - 2011-05-22 11:20:39 --> Language Class Initialized
DEBUG - 2011-05-22 11:20:39 --> Loader Class Initialized
DEBUG - 2011-05-22 11:20:39 --> Controller Class Initialized
ERROR - 2011-05-22 11:20:39 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-05-22 11:20:39 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-05-22 11:20:39 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-05-22 11:20:39 --> Model Class Initialized
DEBUG - 2011-05-22 11:20:39 --> Model Class Initialized
DEBUG - 2011-05-22 11:20:39 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-05-22 11:20:39 --> Database Driver Class Initialized
DEBUG - 2011-05-22 11:20:39 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-05-22 11:20:39 --> Helper loaded: url_helper
DEBUG - 2011-05-22 11:20:39 --> File loaded: application/views/common/header.php
DEBUG - 2011-05-22 11:20:39 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-05-22 11:20:39 --> File loaded: application/views/common/footer.php
DEBUG - 2011-05-22 11:20:39 --> File loaded: application/views/layout/main.php
DEBUG - 2011-05-22 11:20:39 --> Final output sent to browser
DEBUG - 2011-05-22 11:20:39 --> Total execution time: 0.0290
DEBUG - 2011-05-22 11:20:39 --> Final output sent to browser
DEBUG - 2011-05-22 11:20:39 --> Total execution time: 0.4802
DEBUG - 2011-05-22 11:20:42 --> Config Class Initialized
DEBUG - 2011-05-22 11:20:42 --> Hooks Class Initialized
DEBUG - 2011-05-22 11:20:42 --> Utf8 Class Initialized
DEBUG - 2011-05-22 11:20:42 --> UTF-8 Support Enabled
DEBUG - 2011-05-22 11:20:42 --> URI Class Initialized
DEBUG - 2011-05-22 11:20:42 --> Router Class Initialized
DEBUG - 2011-05-22 11:20:42 --> Output Class Initialized
DEBUG - 2011-05-22 11:20:42 --> Input Class Initialized
DEBUG - 2011-05-22 11:20:42 --> Global POST and COOKIE data sanitized
DEBUG - 2011-05-22 11:20:42 --> Language Class Initialized
DEBUG - 2011-05-22 11:20:42 --> Loader Class Initialized
DEBUG - 2011-05-22 11:20:42 --> Controller Class Initialized
ERROR - 2011-05-22 11:20:42 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-05-22 11:20:42 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-05-22 11:20:42 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-05-22 11:20:42 --> Model Class Initialized
DEBUG - 2011-05-22 11:20:42 --> Model Class Initialized
DEBUG - 2011-05-22 11:20:42 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-05-22 11:20:42 --> Database Driver Class Initialized
DEBUG - 2011-05-22 11:20:42 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-05-22 11:20:42 --> Helper loaded: url_helper
DEBUG - 2011-05-22 11:20:42 --> File loaded: application/views/common/header.php
DEBUG - 2011-05-22 11:20:42 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-05-22 11:20:42 --> File loaded: application/views/common/footer.php
DEBUG - 2011-05-22 11:20:42 --> File loaded: application/views/layout/main.php
DEBUG - 2011-05-22 11:20:42 --> Final output sent to browser
DEBUG - 2011-05-22 11:20:42 --> Total execution time: 0.0290
DEBUG - 2011-05-22 11:20:43 --> Config Class Initialized
DEBUG - 2011-05-22 11:20:43 --> Hooks Class Initialized
DEBUG - 2011-05-22 11:20:43 --> Utf8 Class Initialized
DEBUG - 2011-05-22 11:20:43 --> UTF-8 Support Enabled
DEBUG - 2011-05-22 11:20:43 --> URI Class Initialized
DEBUG - 2011-05-22 11:20:43 --> Router Class Initialized
DEBUG - 2011-05-22 11:20:43 --> Output Class Initialized
DEBUG - 2011-05-22 11:20:43 --> Input Class Initialized
DEBUG - 2011-05-22 11:20:43 --> Global POST and COOKIE data sanitized
DEBUG - 2011-05-22 11:20:43 --> Language Class Initialized
DEBUG - 2011-05-22 11:20:43 --> Loader Class Initialized
DEBUG - 2011-05-22 11:20:43 --> Controller Class Initialized
DEBUG - 2011-05-22 11:20:43 --> Model Class Initialized
DEBUG - 2011-05-22 11:20:43 --> Model Class Initialized
DEBUG - 2011-05-22 11:20:43 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-05-22 11:20:43 --> Database Driver Class Initialized
DEBUG - 2011-05-22 11:20:43 --> Final output sent to browser
DEBUG - 2011-05-22 11:20:43 --> Total execution time: 0.5541
DEBUG - 2011-05-22 11:20:45 --> Config Class Initialized
DEBUG - 2011-05-22 11:20:45 --> Hooks Class Initialized
DEBUG - 2011-05-22 11:20:45 --> Utf8 Class Initialized
DEBUG - 2011-05-22 11:20:45 --> UTF-8 Support Enabled
DEBUG - 2011-05-22 11:20:45 --> URI Class Initialized
DEBUG - 2011-05-22 11:20:45 --> Router Class Initialized
DEBUG - 2011-05-22 11:20:45 --> Output Class Initialized
DEBUG - 2011-05-22 11:20:45 --> Input Class Initialized
DEBUG - 2011-05-22 11:20:45 --> Global POST and COOKIE data sanitized
DEBUG - 2011-05-22 11:20:45 --> Language Class Initialized
DEBUG - 2011-05-22 11:20:45 --> Loader Class Initialized
DEBUG - 2011-05-22 11:20:45 --> Controller Class Initialized
DEBUG - 2011-05-22 11:20:45 --> Model Class Initialized
DEBUG - 2011-05-22 11:20:45 --> Model Class Initialized
DEBUG - 2011-05-22 11:20:45 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-05-22 11:20:45 --> Database Driver Class Initialized
DEBUG - 2011-05-22 11:20:45 --> Config Class Initialized
DEBUG - 2011-05-22 11:20:45 --> Hooks Class Initialized
DEBUG - 2011-05-22 11:20:45 --> Utf8 Class Initialized
DEBUG - 2011-05-22 11:20:45 --> UTF-8 Support Enabled
DEBUG - 2011-05-22 11:20:45 --> URI Class Initialized
DEBUG - 2011-05-22 11:20:45 --> Router Class Initialized
DEBUG - 2011-05-22 11:20:45 --> Output Class Initialized
DEBUG - 2011-05-22 11:20:45 --> Input Class Initialized
DEBUG - 2011-05-22 11:20:45 --> Global POST and COOKIE data sanitized
DEBUG - 2011-05-22 11:20:45 --> Language Class Initialized
DEBUG - 2011-05-22 11:20:45 --> Loader Class Initialized
DEBUG - 2011-05-22 11:20:45 --> Controller Class Initialized
ERROR - 2011-05-22 11:20:45 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-05-22 11:20:45 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-05-22 11:20:45 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-05-22 11:20:45 --> Model Class Initialized
DEBUG - 2011-05-22 11:20:45 --> Model Class Initialized
DEBUG - 2011-05-22 11:20:45 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-05-22 11:20:45 --> Database Driver Class Initialized
DEBUG - 2011-05-22 11:20:45 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-05-22 11:20:45 --> Helper loaded: url_helper
DEBUG - 2011-05-22 11:20:45 --> File loaded: application/views/common/header.php
DEBUG - 2011-05-22 11:20:45 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-05-22 11:20:45 --> File loaded: application/views/common/footer.php
DEBUG - 2011-05-22 11:20:45 --> File loaded: application/views/layout/main.php
DEBUG - 2011-05-22 11:20:45 --> Final output sent to browser
DEBUG - 2011-05-22 11:20:45 --> Total execution time: 0.0330
DEBUG - 2011-05-22 11:20:45 --> Final output sent to browser
DEBUG - 2011-05-22 11:20:45 --> Total execution time: 0.4572
DEBUG - 2011-05-22 11:20:51 --> Config Class Initialized
DEBUG - 2011-05-22 11:20:51 --> Hooks Class Initialized
DEBUG - 2011-05-22 11:20:51 --> Utf8 Class Initialized
DEBUG - 2011-05-22 11:20:51 --> UTF-8 Support Enabled
DEBUG - 2011-05-22 11:20:51 --> URI Class Initialized
DEBUG - 2011-05-22 11:20:51 --> Router Class Initialized
DEBUG - 2011-05-22 11:20:51 --> Output Class Initialized
DEBUG - 2011-05-22 11:20:51 --> Input Class Initialized
DEBUG - 2011-05-22 11:20:51 --> Global POST and COOKIE data sanitized
DEBUG - 2011-05-22 11:20:51 --> Language Class Initialized
DEBUG - 2011-05-22 11:20:51 --> Loader Class Initialized
DEBUG - 2011-05-22 11:20:51 --> Controller Class Initialized
ERROR - 2011-05-22 11:20:51 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-05-22 11:20:51 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-05-22 11:20:51 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-05-22 11:20:51 --> Model Class Initialized
DEBUG - 2011-05-22 11:20:51 --> Model Class Initialized
DEBUG - 2011-05-22 11:20:51 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-05-22 11:20:51 --> Database Driver Class Initialized
DEBUG - 2011-05-22 11:20:51 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-05-22 11:20:51 --> Helper loaded: url_helper
DEBUG - 2011-05-22 11:20:51 --> File loaded: application/views/common/header.php
DEBUG - 2011-05-22 11:20:51 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-05-22 11:20:51 --> File loaded: application/views/common/footer.php
DEBUG - 2011-05-22 11:20:51 --> File loaded: application/views/layout/main.php
DEBUG - 2011-05-22 11:20:51 --> Final output sent to browser
DEBUG - 2011-05-22 11:20:51 --> Total execution time: 0.0298
DEBUG - 2011-05-22 11:20:51 --> Config Class Initialized
DEBUG - 2011-05-22 11:20:51 --> Hooks Class Initialized
DEBUG - 2011-05-22 11:20:51 --> Utf8 Class Initialized
DEBUG - 2011-05-22 11:20:51 --> UTF-8 Support Enabled
DEBUG - 2011-05-22 11:20:51 --> URI Class Initialized
DEBUG - 2011-05-22 11:20:51 --> Router Class Initialized
DEBUG - 2011-05-22 11:20:51 --> Output Class Initialized
DEBUG - 2011-05-22 11:20:51 --> Input Class Initialized
DEBUG - 2011-05-22 11:20:51 --> Global POST and COOKIE data sanitized
DEBUG - 2011-05-22 11:20:51 --> Language Class Initialized
DEBUG - 2011-05-22 11:20:51 --> Loader Class Initialized
DEBUG - 2011-05-22 11:20:51 --> Controller Class Initialized
DEBUG - 2011-05-22 11:20:51 --> Model Class Initialized
DEBUG - 2011-05-22 11:20:51 --> Model Class Initialized
DEBUG - 2011-05-22 11:20:51 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-05-22 11:20:51 --> Database Driver Class Initialized
DEBUG - 2011-05-22 11:20:52 --> Final output sent to browser
DEBUG - 2011-05-22 11:20:52 --> Total execution time: 0.6186
DEBUG - 2011-05-22 11:20:54 --> Config Class Initialized
DEBUG - 2011-05-22 11:20:54 --> Hooks Class Initialized
DEBUG - 2011-05-22 11:20:54 --> Utf8 Class Initialized
DEBUG - 2011-05-22 11:20:54 --> UTF-8 Support Enabled
DEBUG - 2011-05-22 11:20:54 --> URI Class Initialized
DEBUG - 2011-05-22 11:20:54 --> Router Class Initialized
DEBUG - 2011-05-22 11:20:54 --> Output Class Initialized
DEBUG - 2011-05-22 11:20:54 --> Input Class Initialized
DEBUG - 2011-05-22 11:20:54 --> Global POST and COOKIE data sanitized
DEBUG - 2011-05-22 11:20:54 --> Language Class Initialized
DEBUG - 2011-05-22 11:20:54 --> Loader Class Initialized
DEBUG - 2011-05-22 11:20:54 --> Controller Class Initialized
DEBUG - 2011-05-22 11:20:54 --> Model Class Initialized
DEBUG - 2011-05-22 11:20:54 --> Model Class Initialized
DEBUG - 2011-05-22 11:20:54 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-05-22 11:20:54 --> Database Driver Class Initialized
DEBUG - 2011-05-22 11:20:54 --> Config Class Initialized
DEBUG - 2011-05-22 11:20:54 --> Hooks Class Initialized
DEBUG - 2011-05-22 11:20:54 --> Utf8 Class Initialized
DEBUG - 2011-05-22 11:20:54 --> UTF-8 Support Enabled
DEBUG - 2011-05-22 11:20:54 --> URI Class Initialized
DEBUG - 2011-05-22 11:20:54 --> Router Class Initialized
DEBUG - 2011-05-22 11:20:54 --> Output Class Initialized
DEBUG - 2011-05-22 11:20:54 --> Input Class Initialized
DEBUG - 2011-05-22 11:20:54 --> Global POST and COOKIE data sanitized
DEBUG - 2011-05-22 11:20:54 --> Language Class Initialized
DEBUG - 2011-05-22 11:20:54 --> Loader Class Initialized
DEBUG - 2011-05-22 11:20:54 --> Controller Class Initialized
ERROR - 2011-05-22 11:20:54 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-05-22 11:20:54 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-05-22 11:20:54 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-05-22 11:20:54 --> Model Class Initialized
DEBUG - 2011-05-22 11:20:54 --> Model Class Initialized
DEBUG - 2011-05-22 11:20:54 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-05-22 11:20:54 --> Database Driver Class Initialized
DEBUG - 2011-05-22 11:20:54 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-05-22 11:20:54 --> Helper loaded: url_helper
DEBUG - 2011-05-22 11:20:54 --> File loaded: application/views/common/header.php
DEBUG - 2011-05-22 11:20:54 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-05-22 11:20:54 --> File loaded: application/views/common/footer.php
DEBUG - 2011-05-22 11:20:54 --> File loaded: application/views/layout/main.php
DEBUG - 2011-05-22 11:20:54 --> Final output sent to browser
DEBUG - 2011-05-22 11:20:54 --> Total execution time: 0.0561
DEBUG - 2011-05-22 11:20:54 --> Final output sent to browser
DEBUG - 2011-05-22 11:20:54 --> Total execution time: 0.5882
DEBUG - 2011-05-22 11:20:58 --> Config Class Initialized
DEBUG - 2011-05-22 11:20:58 --> Hooks Class Initialized
DEBUG - 2011-05-22 11:20:58 --> Utf8 Class Initialized
DEBUG - 2011-05-22 11:20:58 --> UTF-8 Support Enabled
DEBUG - 2011-05-22 11:20:58 --> URI Class Initialized
DEBUG - 2011-05-22 11:20:58 --> Router Class Initialized
DEBUG - 2011-05-22 11:20:58 --> Output Class Initialized
DEBUG - 2011-05-22 11:20:58 --> Input Class Initialized
DEBUG - 2011-05-22 11:20:58 --> Global POST and COOKIE data sanitized
DEBUG - 2011-05-22 11:20:58 --> Language Class Initialized
DEBUG - 2011-05-22 11:20:58 --> Loader Class Initialized
DEBUG - 2011-05-22 11:20:58 --> Controller Class Initialized
ERROR - 2011-05-22 11:20:58 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-05-22 11:20:58 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-05-22 11:20:58 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-05-22 11:20:58 --> Model Class Initialized
DEBUG - 2011-05-22 11:20:58 --> Model Class Initialized
DEBUG - 2011-05-22 11:20:58 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-05-22 11:20:58 --> Database Driver Class Initialized
DEBUG - 2011-05-22 11:20:58 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-05-22 11:20:58 --> Helper loaded: url_helper
DEBUG - 2011-05-22 11:20:58 --> File loaded: application/views/common/header.php
DEBUG - 2011-05-22 11:20:58 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-05-22 11:20:58 --> File loaded: application/views/common/footer.php
DEBUG - 2011-05-22 11:20:58 --> File loaded: application/views/layout/main.php
DEBUG - 2011-05-22 11:20:58 --> Final output sent to browser
DEBUG - 2011-05-22 11:20:58 --> Total execution time: 0.1306
DEBUG - 2011-05-22 11:20:59 --> Config Class Initialized
DEBUG - 2011-05-22 11:20:59 --> Hooks Class Initialized
DEBUG - 2011-05-22 11:20:59 --> Utf8 Class Initialized
DEBUG - 2011-05-22 11:20:59 --> UTF-8 Support Enabled
DEBUG - 2011-05-22 11:20:59 --> URI Class Initialized
DEBUG - 2011-05-22 11:20:59 --> Router Class Initialized
DEBUG - 2011-05-22 11:20:59 --> Output Class Initialized
DEBUG - 2011-05-22 11:20:59 --> Input Class Initialized
DEBUG - 2011-05-22 11:20:59 --> Global POST and COOKIE data sanitized
DEBUG - 2011-05-22 11:20:59 --> Language Class Initialized
DEBUG - 2011-05-22 11:20:59 --> Loader Class Initialized
DEBUG - 2011-05-22 11:20:59 --> Controller Class Initialized
DEBUG - 2011-05-22 11:20:59 --> Model Class Initialized
DEBUG - 2011-05-22 11:20:59 --> Model Class Initialized
DEBUG - 2011-05-22 11:20:59 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-05-22 11:20:59 --> Database Driver Class Initialized
DEBUG - 2011-05-22 11:20:59 --> Final output sent to browser
DEBUG - 2011-05-22 11:20:59 --> Total execution time: 0.7908
DEBUG - 2011-05-22 11:21:01 --> Config Class Initialized
DEBUG - 2011-05-22 11:21:01 --> Hooks Class Initialized
DEBUG - 2011-05-22 11:21:01 --> Utf8 Class Initialized
DEBUG - 2011-05-22 11:21:01 --> UTF-8 Support Enabled
DEBUG - 2011-05-22 11:21:01 --> URI Class Initialized
DEBUG - 2011-05-22 11:21:01 --> Router Class Initialized
DEBUG - 2011-05-22 11:21:01 --> Output Class Initialized
DEBUG - 2011-05-22 11:21:01 --> Input Class Initialized
DEBUG - 2011-05-22 11:21:01 --> Global POST and COOKIE data sanitized
DEBUG - 2011-05-22 11:21:01 --> Language Class Initialized
DEBUG - 2011-05-22 11:21:01 --> Loader Class Initialized
DEBUG - 2011-05-22 11:21:01 --> Controller Class Initialized
DEBUG - 2011-05-22 11:21:01 --> Model Class Initialized
DEBUG - 2011-05-22 11:21:01 --> Model Class Initialized
DEBUG - 2011-05-22 11:21:01 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-05-22 11:21:01 --> Database Driver Class Initialized
DEBUG - 2011-05-22 11:21:01 --> Final output sent to browser
DEBUG - 2011-05-22 11:21:01 --> Total execution time: 0.5386
DEBUG - 2011-05-22 11:21:05 --> Config Class Initialized
DEBUG - 2011-05-22 11:21:05 --> Hooks Class Initialized
DEBUG - 2011-05-22 11:21:05 --> Utf8 Class Initialized
DEBUG - 2011-05-22 11:21:05 --> UTF-8 Support Enabled
DEBUG - 2011-05-22 11:21:05 --> URI Class Initialized
DEBUG - 2011-05-22 11:21:05 --> Router Class Initialized
DEBUG - 2011-05-22 11:21:05 --> Output Class Initialized
DEBUG - 2011-05-22 11:21:05 --> Input Class Initialized
DEBUG - 2011-05-22 11:21:05 --> Global POST and COOKIE data sanitized
DEBUG - 2011-05-22 11:21:05 --> Language Class Initialized
DEBUG - 2011-05-22 11:21:05 --> Loader Class Initialized
DEBUG - 2011-05-22 11:21:05 --> Controller Class Initialized
ERROR - 2011-05-22 11:21:05 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-05-22 11:21:05 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-05-22 11:21:05 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-05-22 11:21:05 --> Model Class Initialized
DEBUG - 2011-05-22 11:21:05 --> Model Class Initialized
DEBUG - 2011-05-22 11:21:05 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-05-22 11:21:05 --> Database Driver Class Initialized
DEBUG - 2011-05-22 11:21:05 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-05-22 11:21:05 --> Helper loaded: url_helper
DEBUG - 2011-05-22 11:21:05 --> File loaded: application/views/common/header.php
DEBUG - 2011-05-22 11:21:05 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-05-22 11:21:05 --> File loaded: application/views/common/footer.php
DEBUG - 2011-05-22 11:21:05 --> File loaded: application/views/layout/main.php
DEBUG - 2011-05-22 11:21:05 --> Final output sent to browser
DEBUG - 2011-05-22 11:21:05 --> Total execution time: 0.0752
DEBUG - 2011-05-22 11:21:13 --> Config Class Initialized
DEBUG - 2011-05-22 11:21:13 --> Hooks Class Initialized
DEBUG - 2011-05-22 11:21:13 --> Utf8 Class Initialized
DEBUG - 2011-05-22 11:21:13 --> UTF-8 Support Enabled
DEBUG - 2011-05-22 11:21:13 --> URI Class Initialized
DEBUG - 2011-05-22 11:21:13 --> Router Class Initialized
DEBUG - 2011-05-22 11:21:13 --> No URI present. Default controller set.
DEBUG - 2011-05-22 11:21:13 --> Output Class Initialized
DEBUG - 2011-05-22 11:21:13 --> Input Class Initialized
DEBUG - 2011-05-22 11:21:13 --> Global POST and COOKIE data sanitized
DEBUG - 2011-05-22 11:21:13 --> Language Class Initialized
DEBUG - 2011-05-22 11:21:13 --> Loader Class Initialized
DEBUG - 2011-05-22 11:21:13 --> Controller Class Initialized
DEBUG - 2011-05-22 11:21:13 --> File loaded: application/views/splash/main.php
DEBUG - 2011-05-22 11:21:13 --> Helper loaded: url_helper
DEBUG - 2011-05-22 11:21:13 --> File loaded: application/views/common/header.php
DEBUG - 2011-05-22 11:21:13 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-05-22 11:21:13 --> File loaded: application/views/common/footer.php
DEBUG - 2011-05-22 11:21:13 --> File loaded: application/views/layout/main.php
DEBUG - 2011-05-22 11:21:13 --> Final output sent to browser
DEBUG - 2011-05-22 11:21:13 --> Total execution time: 0.0494
DEBUG - 2011-05-22 11:22:17 --> Config Class Initialized
DEBUG - 2011-05-22 11:22:17 --> Hooks Class Initialized
DEBUG - 2011-05-22 11:22:17 --> Utf8 Class Initialized
DEBUG - 2011-05-22 11:22:17 --> UTF-8 Support Enabled
DEBUG - 2011-05-22 11:22:17 --> URI Class Initialized
DEBUG - 2011-05-22 11:22:17 --> Router Class Initialized
DEBUG - 2011-05-22 11:22:17 --> Output Class Initialized
DEBUG - 2011-05-22 11:22:17 --> Input Class Initialized
DEBUG - 2011-05-22 11:22:17 --> Global POST and COOKIE data sanitized
DEBUG - 2011-05-22 11:22:17 --> Language Class Initialized
DEBUG - 2011-05-22 11:22:17 --> Loader Class Initialized
DEBUG - 2011-05-22 11:22:17 --> Controller Class Initialized
DEBUG - 2011-05-22 11:22:17 --> Model Class Initialized
DEBUG - 2011-05-22 11:22:17 --> Model Class Initialized
DEBUG - 2011-05-22 11:22:17 --> Model Class Initialized
DEBUG - 2011-05-22 11:22:17 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-05-22 11:22:17 --> Database Driver Class Initialized
DEBUG - 2011-05-22 11:22:17 --> File loaded: application/views/table/main.php
DEBUG - 2011-05-22 11:22:17 --> Helper loaded: url_helper
DEBUG - 2011-05-22 11:22:17 --> File loaded: application/views/common/header.php
DEBUG - 2011-05-22 11:22:17 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-05-22 11:22:17 --> File loaded: application/views/common/footer.php
DEBUG - 2011-05-22 11:22:17 --> File loaded: application/views/layout/main.php
DEBUG - 2011-05-22 11:22:17 --> Final output sent to browser
DEBUG - 2011-05-22 11:22:17 --> Total execution time: 0.0541
DEBUG - 2011-05-22 11:22:21 --> Config Class Initialized
DEBUG - 2011-05-22 11:22:21 --> Hooks Class Initialized
DEBUG - 2011-05-22 11:22:21 --> Utf8 Class Initialized
DEBUG - 2011-05-22 11:22:21 --> UTF-8 Support Enabled
DEBUG - 2011-05-22 11:22:21 --> URI Class Initialized
DEBUG - 2011-05-22 11:22:21 --> Router Class Initialized
ERROR - 2011-05-22 11:22:21 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-05-22 11:22:25 --> Config Class Initialized
DEBUG - 2011-05-22 11:22:25 --> Hooks Class Initialized
DEBUG - 2011-05-22 11:22:25 --> Utf8 Class Initialized
DEBUG - 2011-05-22 11:22:25 --> UTF-8 Support Enabled
DEBUG - 2011-05-22 11:22:25 --> URI Class Initialized
DEBUG - 2011-05-22 11:22:25 --> Router Class Initialized
ERROR - 2011-05-22 11:22:25 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-05-22 11:22:36 --> Config Class Initialized
DEBUG - 2011-05-22 11:22:36 --> Hooks Class Initialized
DEBUG - 2011-05-22 11:22:36 --> Utf8 Class Initialized
DEBUG - 2011-05-22 11:22:36 --> UTF-8 Support Enabled
DEBUG - 2011-05-22 11:22:36 --> URI Class Initialized
DEBUG - 2011-05-22 11:22:36 --> Router Class Initialized
DEBUG - 2011-05-22 11:22:36 --> No URI present. Default controller set.
DEBUG - 2011-05-22 11:22:36 --> Output Class Initialized
DEBUG - 2011-05-22 11:22:36 --> Input Class Initialized
DEBUG - 2011-05-22 11:22:36 --> Global POST and COOKIE data sanitized
DEBUG - 2011-05-22 11:22:36 --> Language Class Initialized
DEBUG - 2011-05-22 11:22:36 --> Loader Class Initialized
DEBUG - 2011-05-22 11:22:36 --> Controller Class Initialized
DEBUG - 2011-05-22 11:22:36 --> File loaded: application/views/splash/main.php
DEBUG - 2011-05-22 11:22:36 --> Helper loaded: url_helper
DEBUG - 2011-05-22 11:22:36 --> File loaded: application/views/common/header.php
DEBUG - 2011-05-22 11:22:36 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-05-22 11:22:36 --> File loaded: application/views/common/footer.php
DEBUG - 2011-05-22 11:22:36 --> File loaded: application/views/layout/main.php
DEBUG - 2011-05-22 11:22:36 --> Final output sent to browser
DEBUG - 2011-05-22 11:22:36 --> Total execution time: 0.0155
DEBUG - 2011-05-22 11:22:37 --> Config Class Initialized
DEBUG - 2011-05-22 11:22:37 --> Hooks Class Initialized
DEBUG - 2011-05-22 11:22:37 --> Utf8 Class Initialized
DEBUG - 2011-05-22 11:22:37 --> UTF-8 Support Enabled
DEBUG - 2011-05-22 11:22:37 --> URI Class Initialized
DEBUG - 2011-05-22 11:22:37 --> Router Class Initialized
ERROR - 2011-05-22 11:22:37 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-05-22 11:22:37 --> Config Class Initialized
DEBUG - 2011-05-22 11:22:37 --> Hooks Class Initialized
DEBUG - 2011-05-22 11:22:37 --> Utf8 Class Initialized
DEBUG - 2011-05-22 11:22:37 --> UTF-8 Support Enabled
DEBUG - 2011-05-22 11:22:37 --> URI Class Initialized
DEBUG - 2011-05-22 11:22:37 --> Router Class Initialized
ERROR - 2011-05-22 11:22:37 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-05-22 11:22:39 --> Config Class Initialized
DEBUG - 2011-05-22 11:22:39 --> Hooks Class Initialized
DEBUG - 2011-05-22 11:22:39 --> Utf8 Class Initialized
DEBUG - 2011-05-22 11:22:39 --> UTF-8 Support Enabled
DEBUG - 2011-05-22 11:22:39 --> URI Class Initialized
DEBUG - 2011-05-22 11:22:39 --> Router Class Initialized
DEBUG - 2011-05-22 11:22:39 --> Output Class Initialized
DEBUG - 2011-05-22 11:22:39 --> Input Class Initialized
DEBUG - 2011-05-22 11:22:39 --> Global POST and COOKIE data sanitized
DEBUG - 2011-05-22 11:22:39 --> Language Class Initialized
DEBUG - 2011-05-22 11:22:39 --> Loader Class Initialized
DEBUG - 2011-05-22 11:22:39 --> Controller Class Initialized
DEBUG - 2011-05-22 11:22:39 --> Model Class Initialized
DEBUG - 2011-05-22 11:22:39 --> Model Class Initialized
DEBUG - 2011-05-22 11:22:39 --> Model Class Initialized
DEBUG - 2011-05-22 11:22:39 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-05-22 11:22:39 --> Database Driver Class Initialized
DEBUG - 2011-05-22 11:22:39 --> File loaded: application/views/table/main.php
DEBUG - 2011-05-22 11:22:39 --> Helper loaded: url_helper
DEBUG - 2011-05-22 11:22:39 --> File loaded: application/views/common/header.php
DEBUG - 2011-05-22 11:22:39 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-05-22 11:22:39 --> File loaded: application/views/common/footer.php
DEBUG - 2011-05-22 11:22:39 --> File loaded: application/views/layout/main.php
DEBUG - 2011-05-22 11:22:39 --> Final output sent to browser
DEBUG - 2011-05-22 11:22:39 --> Total execution time: 0.0483
DEBUG - 2011-05-22 11:22:45 --> Config Class Initialized
DEBUG - 2011-05-22 11:22:45 --> Hooks Class Initialized
DEBUG - 2011-05-22 11:22:45 --> Utf8 Class Initialized
DEBUG - 2011-05-22 11:22:45 --> UTF-8 Support Enabled
DEBUG - 2011-05-22 11:22:45 --> URI Class Initialized
DEBUG - 2011-05-22 11:22:45 --> Router Class Initialized
DEBUG - 2011-05-22 11:22:45 --> Output Class Initialized
DEBUG - 2011-05-22 11:22:45 --> Input Class Initialized
DEBUG - 2011-05-22 11:22:45 --> Global POST and COOKIE data sanitized
DEBUG - 2011-05-22 11:22:45 --> Language Class Initialized
DEBUG - 2011-05-22 11:22:45 --> Loader Class Initialized
DEBUG - 2011-05-22 11:22:45 --> Controller Class Initialized
DEBUG - 2011-05-22 11:22:45 --> Model Class Initialized
DEBUG - 2011-05-22 11:22:45 --> Model Class Initialized
DEBUG - 2011-05-22 11:22:45 --> Model Class Initialized
DEBUG - 2011-05-22 11:22:45 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-05-22 11:22:45 --> Database Driver Class Initialized
DEBUG - 2011-05-22 11:22:45 --> File loaded: application/views/table/main.php
DEBUG - 2011-05-22 11:22:45 --> Helper loaded: url_helper
DEBUG - 2011-05-22 11:22:45 --> File loaded: application/views/common/header.php
DEBUG - 2011-05-22 11:22:45 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-05-22 11:22:45 --> File loaded: application/views/common/footer.php
DEBUG - 2011-05-22 11:22:45 --> File loaded: application/views/layout/main.php
DEBUG - 2011-05-22 11:22:45 --> Final output sent to browser
DEBUG - 2011-05-22 11:22:45 --> Total execution time: 0.2072
DEBUG - 2011-05-22 11:22:55 --> Config Class Initialized
DEBUG - 2011-05-22 11:22:55 --> Hooks Class Initialized
DEBUG - 2011-05-22 11:22:55 --> Utf8 Class Initialized
DEBUG - 2011-05-22 11:22:55 --> UTF-8 Support Enabled
DEBUG - 2011-05-22 11:22:55 --> URI Class Initialized
DEBUG - 2011-05-22 11:22:55 --> Router Class Initialized
DEBUG - 2011-05-22 11:22:55 --> Output Class Initialized
DEBUG - 2011-05-22 11:22:55 --> Input Class Initialized
DEBUG - 2011-05-22 11:22:55 --> Global POST and COOKIE data sanitized
DEBUG - 2011-05-22 11:22:55 --> Language Class Initialized
DEBUG - 2011-05-22 11:22:55 --> Loader Class Initialized
DEBUG - 2011-05-22 11:22:55 --> Controller Class Initialized
DEBUG - 2011-05-22 11:22:55 --> Model Class Initialized
DEBUG - 2011-05-22 11:22:55 --> Model Class Initialized
DEBUG - 2011-05-22 11:22:55 --> Model Class Initialized
DEBUG - 2011-05-22 11:22:55 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-05-22 11:22:55 --> Database Driver Class Initialized
DEBUG - 2011-05-22 11:22:55 --> File loaded: application/views/table/main.php
DEBUG - 2011-05-22 11:22:55 --> Helper loaded: url_helper
DEBUG - 2011-05-22 11:22:55 --> File loaded: application/views/common/header.php
DEBUG - 2011-05-22 11:22:55 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-05-22 11:22:55 --> File loaded: application/views/common/footer.php
DEBUG - 2011-05-22 11:22:55 --> File loaded: application/views/layout/main.php
DEBUG - 2011-05-22 11:22:55 --> Final output sent to browser
DEBUG - 2011-05-22 11:22:55 --> Total execution time: 0.2451
DEBUG - 2011-05-22 11:23:04 --> Config Class Initialized
DEBUG - 2011-05-22 11:23:04 --> Hooks Class Initialized
DEBUG - 2011-05-22 11:23:04 --> Utf8 Class Initialized
DEBUG - 2011-05-22 11:23:04 --> UTF-8 Support Enabled
DEBUG - 2011-05-22 11:23:04 --> URI Class Initialized
DEBUG - 2011-05-22 11:23:04 --> Router Class Initialized
DEBUG - 2011-05-22 11:23:04 --> Output Class Initialized
DEBUG - 2011-05-22 11:23:04 --> Input Class Initialized
DEBUG - 2011-05-22 11:23:04 --> Global POST and COOKIE data sanitized
DEBUG - 2011-05-22 11:23:04 --> Language Class Initialized
DEBUG - 2011-05-22 11:23:04 --> Loader Class Initialized
DEBUG - 2011-05-22 11:23:04 --> Controller Class Initialized
DEBUG - 2011-05-22 11:23:04 --> Model Class Initialized
DEBUG - 2011-05-22 11:23:04 --> Model Class Initialized
DEBUG - 2011-05-22 11:23:04 --> Model Class Initialized
DEBUG - 2011-05-22 11:23:04 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-05-22 11:23:04 --> Database Driver Class Initialized
DEBUG - 2011-05-22 11:23:04 --> File loaded: application/views/table/main.php
DEBUG - 2011-05-22 11:23:04 --> Helper loaded: url_helper
DEBUG - 2011-05-22 11:23:04 --> File loaded: application/views/common/header.php
DEBUG - 2011-05-22 11:23:04 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-05-22 11:23:04 --> File loaded: application/views/common/footer.php
DEBUG - 2011-05-22 11:23:04 --> File loaded: application/views/layout/main.php
DEBUG - 2011-05-22 11:23:04 --> Final output sent to browser
DEBUG - 2011-05-22 11:23:04 --> Total execution time: 0.2917
DEBUG - 2011-05-22 11:23:08 --> Config Class Initialized
DEBUG - 2011-05-22 11:23:08 --> Hooks Class Initialized
DEBUG - 2011-05-22 11:23:08 --> Utf8 Class Initialized
DEBUG - 2011-05-22 11:23:08 --> UTF-8 Support Enabled
DEBUG - 2011-05-22 11:23:08 --> URI Class Initialized
DEBUG - 2011-05-22 11:23:08 --> Router Class Initialized
DEBUG - 2011-05-22 11:23:08 --> Output Class Initialized
DEBUG - 2011-05-22 11:23:08 --> Input Class Initialized
DEBUG - 2011-05-22 11:23:08 --> Global POST and COOKIE data sanitized
DEBUG - 2011-05-22 11:23:08 --> Language Class Initialized
DEBUG - 2011-05-22 11:23:08 --> Loader Class Initialized
DEBUG - 2011-05-22 11:23:08 --> Controller Class Initialized
DEBUG - 2011-05-22 11:23:08 --> Model Class Initialized
DEBUG - 2011-05-22 11:23:08 --> Model Class Initialized
DEBUG - 2011-05-22 11:23:08 --> Model Class Initialized
DEBUG - 2011-05-22 11:23:08 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-05-22 11:23:08 --> Database Driver Class Initialized
DEBUG - 2011-05-22 11:23:08 --> File loaded: application/views/table/main.php
DEBUG - 2011-05-22 11:23:08 --> Helper loaded: url_helper
DEBUG - 2011-05-22 11:23:08 --> File loaded: application/views/common/header.php
DEBUG - 2011-05-22 11:23:08 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-05-22 11:23:08 --> File loaded: application/views/common/footer.php
DEBUG - 2011-05-22 11:23:08 --> File loaded: application/views/layout/main.php
DEBUG - 2011-05-22 11:23:08 --> Final output sent to browser
DEBUG - 2011-05-22 11:23:08 --> Total execution time: 0.0716
DEBUG - 2011-05-22 11:23:10 --> Config Class Initialized
DEBUG - 2011-05-22 11:23:10 --> Hooks Class Initialized
DEBUG - 2011-05-22 11:23:10 --> Utf8 Class Initialized
DEBUG - 2011-05-22 11:23:10 --> UTF-8 Support Enabled
DEBUG - 2011-05-22 11:23:10 --> URI Class Initialized
DEBUG - 2011-05-22 11:23:10 --> Router Class Initialized
DEBUG - 2011-05-22 11:23:10 --> Output Class Initialized
DEBUG - 2011-05-22 11:23:10 --> Input Class Initialized
DEBUG - 2011-05-22 11:23:10 --> Global POST and COOKIE data sanitized
DEBUG - 2011-05-22 11:23:10 --> Language Class Initialized
DEBUG - 2011-05-22 11:23:10 --> Loader Class Initialized
DEBUG - 2011-05-22 11:23:10 --> Controller Class Initialized
DEBUG - 2011-05-22 11:23:10 --> Model Class Initialized
DEBUG - 2011-05-22 11:23:10 --> Model Class Initialized
DEBUG - 2011-05-22 11:23:10 --> Model Class Initialized
DEBUG - 2011-05-22 11:23:10 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-05-22 11:23:10 --> Database Driver Class Initialized
DEBUG - 2011-05-22 11:23:10 --> File loaded: application/views/table/main.php
DEBUG - 2011-05-22 11:23:10 --> Helper loaded: url_helper
DEBUG - 2011-05-22 11:23:10 --> File loaded: application/views/common/header.php
DEBUG - 2011-05-22 11:23:10 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-05-22 11:23:10 --> File loaded: application/views/common/footer.php
DEBUG - 2011-05-22 11:23:10 --> File loaded: application/views/layout/main.php
DEBUG - 2011-05-22 11:23:10 --> Final output sent to browser
DEBUG - 2011-05-22 11:23:10 --> Total execution time: 0.0491
DEBUG - 2011-05-22 11:23:11 --> Config Class Initialized
DEBUG - 2011-05-22 11:23:11 --> Hooks Class Initialized
DEBUG - 2011-05-22 11:23:11 --> Utf8 Class Initialized
DEBUG - 2011-05-22 11:23:11 --> UTF-8 Support Enabled
DEBUG - 2011-05-22 11:23:11 --> URI Class Initialized
DEBUG - 2011-05-22 11:23:11 --> Router Class Initialized
DEBUG - 2011-05-22 11:23:11 --> Output Class Initialized
DEBUG - 2011-05-22 11:23:11 --> Input Class Initialized
DEBUG - 2011-05-22 11:23:11 --> Global POST and COOKIE data sanitized
DEBUG - 2011-05-22 11:23:11 --> Language Class Initialized
DEBUG - 2011-05-22 11:23:11 --> Loader Class Initialized
DEBUG - 2011-05-22 11:23:11 --> Controller Class Initialized
DEBUG - 2011-05-22 11:23:11 --> Model Class Initialized
DEBUG - 2011-05-22 11:23:11 --> Model Class Initialized
DEBUG - 2011-05-22 11:23:11 --> Model Class Initialized
DEBUG - 2011-05-22 11:23:11 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-05-22 11:23:11 --> Database Driver Class Initialized
DEBUG - 2011-05-22 11:23:11 --> File loaded: application/views/table/main.php
DEBUG - 2011-05-22 11:23:11 --> Helper loaded: url_helper
DEBUG - 2011-05-22 11:23:11 --> File loaded: application/views/common/header.php
DEBUG - 2011-05-22 11:23:11 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-05-22 11:23:11 --> File loaded: application/views/common/footer.php
DEBUG - 2011-05-22 11:23:11 --> File loaded: application/views/layout/main.php
DEBUG - 2011-05-22 11:23:11 --> Final output sent to browser
DEBUG - 2011-05-22 11:23:11 --> Total execution time: 0.1887
DEBUG - 2011-05-22 11:23:11 --> Config Class Initialized
DEBUG - 2011-05-22 11:23:11 --> Hooks Class Initialized
DEBUG - 2011-05-22 11:23:11 --> Utf8 Class Initialized
DEBUG - 2011-05-22 11:23:11 --> UTF-8 Support Enabled
DEBUG - 2011-05-22 11:23:11 --> URI Class Initialized
DEBUG - 2011-05-22 11:23:11 --> Router Class Initialized
DEBUG - 2011-05-22 11:23:11 --> Output Class Initialized
DEBUG - 2011-05-22 11:23:11 --> Input Class Initialized
DEBUG - 2011-05-22 11:23:11 --> Global POST and COOKIE data sanitized
DEBUG - 2011-05-22 11:23:11 --> Language Class Initialized
DEBUG - 2011-05-22 11:23:11 --> Loader Class Initialized
DEBUG - 2011-05-22 11:23:11 --> Controller Class Initialized
DEBUG - 2011-05-22 11:23:11 --> Model Class Initialized
DEBUG - 2011-05-22 11:23:11 --> Model Class Initialized
DEBUG - 2011-05-22 11:23:11 --> Model Class Initialized
DEBUG - 2011-05-22 11:23:11 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-05-22 11:23:11 --> Database Driver Class Initialized
DEBUG - 2011-05-22 11:23:11 --> File loaded: application/views/table/main.php
DEBUG - 2011-05-22 11:23:11 --> Helper loaded: url_helper
DEBUG - 2011-05-22 11:23:11 --> File loaded: application/views/common/header.php
DEBUG - 2011-05-22 11:23:11 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-05-22 11:23:11 --> File loaded: application/views/common/footer.php
DEBUG - 2011-05-22 11:23:11 --> File loaded: application/views/layout/main.php
DEBUG - 2011-05-22 11:23:11 --> Final output sent to browser
DEBUG - 2011-05-22 11:23:11 --> Total execution time: 0.0494
DEBUG - 2011-05-22 11:23:12 --> Config Class Initialized
DEBUG - 2011-05-22 11:23:12 --> Hooks Class Initialized
DEBUG - 2011-05-22 11:23:12 --> Utf8 Class Initialized
DEBUG - 2011-05-22 11:23:12 --> UTF-8 Support Enabled
DEBUG - 2011-05-22 11:23:12 --> URI Class Initialized
DEBUG - 2011-05-22 11:23:12 --> Router Class Initialized
DEBUG - 2011-05-22 11:23:12 --> Output Class Initialized
DEBUG - 2011-05-22 11:23:12 --> Input Class Initialized
DEBUG - 2011-05-22 11:23:12 --> Global POST and COOKIE data sanitized
DEBUG - 2011-05-22 11:23:12 --> Language Class Initialized
DEBUG - 2011-05-22 11:23:12 --> Loader Class Initialized
DEBUG - 2011-05-22 11:23:12 --> Controller Class Initialized
DEBUG - 2011-05-22 11:23:12 --> Model Class Initialized
DEBUG - 2011-05-22 11:23:12 --> Model Class Initialized
DEBUG - 2011-05-22 11:23:12 --> Model Class Initialized
DEBUG - 2011-05-22 11:23:12 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-05-22 11:23:12 --> Database Driver Class Initialized
DEBUG - 2011-05-22 11:23:13 --> File loaded: application/views/table/main.php
DEBUG - 2011-05-22 11:23:13 --> Helper loaded: url_helper
DEBUG - 2011-05-22 11:23:13 --> File loaded: application/views/common/header.php
DEBUG - 2011-05-22 11:23:13 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-05-22 11:23:13 --> File loaded: application/views/common/footer.php
DEBUG - 2011-05-22 11:23:13 --> File loaded: application/views/layout/main.php
DEBUG - 2011-05-22 11:23:13 --> Final output sent to browser
DEBUG - 2011-05-22 11:23:13 --> Total execution time: 0.0660
DEBUG - 2011-05-22 11:23:18 --> Config Class Initialized
DEBUG - 2011-05-22 11:23:18 --> Hooks Class Initialized
DEBUG - 2011-05-22 11:23:18 --> Utf8 Class Initialized
DEBUG - 2011-05-22 11:23:18 --> UTF-8 Support Enabled
DEBUG - 2011-05-22 11:23:18 --> URI Class Initialized
DEBUG - 2011-05-22 11:23:18 --> Router Class Initialized
DEBUG - 2011-05-22 11:23:18 --> Output Class Initialized
DEBUG - 2011-05-22 11:23:18 --> Input Class Initialized
DEBUG - 2011-05-22 11:23:18 --> Global POST and COOKIE data sanitized
DEBUG - 2011-05-22 11:23:18 --> Language Class Initialized
DEBUG - 2011-05-22 11:23:18 --> Loader Class Initialized
DEBUG - 2011-05-22 11:23:18 --> Controller Class Initialized
DEBUG - 2011-05-22 11:23:18 --> Model Class Initialized
DEBUG - 2011-05-22 11:23:18 --> Model Class Initialized
DEBUG - 2011-05-22 11:23:18 --> Model Class Initialized
DEBUG - 2011-05-22 11:23:18 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-05-22 11:23:18 --> Database Driver Class Initialized
DEBUG - 2011-05-22 11:23:18 --> File loaded: application/views/table/main.php
DEBUG - 2011-05-22 11:23:18 --> Helper loaded: url_helper
DEBUG - 2011-05-22 11:23:18 --> File loaded: application/views/common/header.php
DEBUG - 2011-05-22 11:23:18 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-05-22 11:23:18 --> File loaded: application/views/common/footer.php
DEBUG - 2011-05-22 11:23:18 --> File loaded: application/views/layout/main.php
DEBUG - 2011-05-22 11:23:18 --> Final output sent to browser
DEBUG - 2011-05-22 11:23:18 --> Total execution time: 0.2726
DEBUG - 2011-05-22 11:23:19 --> Config Class Initialized
DEBUG - 2011-05-22 11:23:19 --> Hooks Class Initialized
DEBUG - 2011-05-22 11:23:19 --> Utf8 Class Initialized
DEBUG - 2011-05-22 11:23:19 --> UTF-8 Support Enabled
DEBUG - 2011-05-22 11:23:19 --> URI Class Initialized
DEBUG - 2011-05-22 11:23:19 --> Router Class Initialized
DEBUG - 2011-05-22 11:23:19 --> Output Class Initialized
DEBUG - 2011-05-22 11:23:19 --> Input Class Initialized
DEBUG - 2011-05-22 11:23:19 --> Global POST and COOKIE data sanitized
DEBUG - 2011-05-22 11:23:19 --> Language Class Initialized
DEBUG - 2011-05-22 11:23:19 --> Loader Class Initialized
DEBUG - 2011-05-22 11:23:19 --> Controller Class Initialized
DEBUG - 2011-05-22 11:23:19 --> Model Class Initialized
DEBUG - 2011-05-22 11:23:19 --> Model Class Initialized
DEBUG - 2011-05-22 11:23:19 --> Model Class Initialized
DEBUG - 2011-05-22 11:23:19 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-05-22 11:23:19 --> Database Driver Class Initialized
DEBUG - 2011-05-22 11:23:19 --> File loaded: application/views/table/main.php
DEBUG - 2011-05-22 11:23:19 --> Helper loaded: url_helper
DEBUG - 2011-05-22 11:23:19 --> File loaded: application/views/common/header.php
DEBUG - 2011-05-22 11:23:19 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-05-22 11:23:19 --> File loaded: application/views/common/footer.php
DEBUG - 2011-05-22 11:23:19 --> File loaded: application/views/layout/main.php
DEBUG - 2011-05-22 11:23:19 --> Final output sent to browser
DEBUG - 2011-05-22 11:23:19 --> Total execution time: 0.0460
DEBUG - 2011-05-22 11:23:25 --> Config Class Initialized
DEBUG - 2011-05-22 11:23:25 --> Hooks Class Initialized
DEBUG - 2011-05-22 11:23:25 --> Utf8 Class Initialized
DEBUG - 2011-05-22 11:23:25 --> UTF-8 Support Enabled
DEBUG - 2011-05-22 11:23:25 --> URI Class Initialized
DEBUG - 2011-05-22 11:23:25 --> Router Class Initialized
DEBUG - 2011-05-22 11:23:25 --> Output Class Initialized
DEBUG - 2011-05-22 11:23:25 --> Input Class Initialized
DEBUG - 2011-05-22 11:23:25 --> Global POST and COOKIE data sanitized
DEBUG - 2011-05-22 11:23:25 --> Language Class Initialized
DEBUG - 2011-05-22 11:23:25 --> Loader Class Initialized
DEBUG - 2011-05-22 11:23:25 --> Controller Class Initialized
DEBUG - 2011-05-22 11:23:25 --> Model Class Initialized
DEBUG - 2011-05-22 11:23:25 --> Model Class Initialized
DEBUG - 2011-05-22 11:23:25 --> Model Class Initialized
DEBUG - 2011-05-22 11:23:25 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-05-22 11:23:25 --> Database Driver Class Initialized
DEBUG - 2011-05-22 11:23:26 --> File loaded: application/views/table/main.php
DEBUG - 2011-05-22 11:23:26 --> Helper loaded: url_helper
DEBUG - 2011-05-22 11:23:26 --> File loaded: application/views/common/header.php
DEBUG - 2011-05-22 11:23:26 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-05-22 11:23:26 --> File loaded: application/views/common/footer.php
DEBUG - 2011-05-22 11:23:26 --> File loaded: application/views/layout/main.php
DEBUG - 2011-05-22 11:23:26 --> Final output sent to browser
DEBUG - 2011-05-22 11:23:26 --> Total execution time: 0.2123
DEBUG - 2011-05-22 11:23:42 --> Config Class Initialized
DEBUG - 2011-05-22 11:23:42 --> Hooks Class Initialized
DEBUG - 2011-05-22 11:23:42 --> Utf8 Class Initialized
DEBUG - 2011-05-22 11:23:42 --> UTF-8 Support Enabled
DEBUG - 2011-05-22 11:23:42 --> URI Class Initialized
DEBUG - 2011-05-22 11:23:42 --> Router Class Initialized
DEBUG - 2011-05-22 11:23:42 --> Output Class Initialized
DEBUG - 2011-05-22 11:23:42 --> Input Class Initialized
DEBUG - 2011-05-22 11:23:42 --> Global POST and COOKIE data sanitized
DEBUG - 2011-05-22 11:23:42 --> Language Class Initialized
DEBUG - 2011-05-22 11:23:42 --> Loader Class Initialized
DEBUG - 2011-05-22 11:23:42 --> Controller Class Initialized
DEBUG - 2011-05-22 11:23:42 --> Model Class Initialized
DEBUG - 2011-05-22 11:23:42 --> Model Class Initialized
DEBUG - 2011-05-22 11:23:42 --> Model Class Initialized
DEBUG - 2011-05-22 11:23:42 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-05-22 11:23:42 --> Database Driver Class Initialized
DEBUG - 2011-05-22 11:23:42 --> File loaded: application/views/table/main.php
DEBUG - 2011-05-22 11:23:42 --> Helper loaded: url_helper
DEBUG - 2011-05-22 11:23:42 --> File loaded: application/views/common/header.php
DEBUG - 2011-05-22 11:23:42 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-05-22 11:23:42 --> File loaded: application/views/common/footer.php
DEBUG - 2011-05-22 11:23:42 --> File loaded: application/views/layout/main.php
DEBUG - 2011-05-22 11:23:42 --> Final output sent to browser
DEBUG - 2011-05-22 11:23:42 --> Total execution time: 0.2025
DEBUG - 2011-05-22 11:24:25 --> Config Class Initialized
DEBUG - 2011-05-22 11:24:25 --> Hooks Class Initialized
DEBUG - 2011-05-22 11:24:25 --> Utf8 Class Initialized
DEBUG - 2011-05-22 11:24:25 --> UTF-8 Support Enabled
DEBUG - 2011-05-22 11:24:25 --> URI Class Initialized
DEBUG - 2011-05-22 11:24:25 --> Router Class Initialized
DEBUG - 2011-05-22 11:24:25 --> Output Class Initialized
DEBUG - 2011-05-22 11:24:25 --> Input Class Initialized
DEBUG - 2011-05-22 11:24:25 --> Global POST and COOKIE data sanitized
DEBUG - 2011-05-22 11:24:25 --> Language Class Initialized
DEBUG - 2011-05-22 11:24:25 --> Loader Class Initialized
DEBUG - 2011-05-22 11:24:25 --> Controller Class Initialized
DEBUG - 2011-05-22 11:24:25 --> Model Class Initialized
DEBUG - 2011-05-22 11:24:25 --> Model Class Initialized
DEBUG - 2011-05-22 11:24:25 --> Model Class Initialized
DEBUG - 2011-05-22 11:24:25 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-05-22 11:24:25 --> Database Driver Class Initialized
DEBUG - 2011-05-22 11:24:25 --> File loaded: application/views/table/main.php
DEBUG - 2011-05-22 11:24:25 --> Helper loaded: url_helper
DEBUG - 2011-05-22 11:24:25 --> File loaded: application/views/common/header.php
DEBUG - 2011-05-22 11:24:25 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-05-22 11:24:25 --> File loaded: application/views/common/footer.php
DEBUG - 2011-05-22 11:24:25 --> File loaded: application/views/layout/main.php
DEBUG - 2011-05-22 11:24:25 --> Final output sent to browser
DEBUG - 2011-05-22 11:24:25 --> Total execution time: 0.0497
DEBUG - 2011-05-22 11:34:02 --> Config Class Initialized
DEBUG - 2011-05-22 11:34:02 --> Hooks Class Initialized
DEBUG - 2011-05-22 11:34:02 --> Utf8 Class Initialized
DEBUG - 2011-05-22 11:34:02 --> UTF-8 Support Enabled
DEBUG - 2011-05-22 11:34:02 --> URI Class Initialized
DEBUG - 2011-05-22 11:34:02 --> Router Class Initialized
DEBUG - 2011-05-22 11:34:02 --> Output Class Initialized
DEBUG - 2011-05-22 11:34:02 --> Input Class Initialized
DEBUG - 2011-05-22 11:34:02 --> Global POST and COOKIE data sanitized
DEBUG - 2011-05-22 11:34:02 --> Language Class Initialized
DEBUG - 2011-05-22 11:34:02 --> Loader Class Initialized
DEBUG - 2011-05-22 11:34:02 --> Controller Class Initialized
ERROR - 2011-05-22 11:34:02 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-05-22 11:34:02 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-05-22 11:34:02 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-05-22 11:34:02 --> Model Class Initialized
DEBUG - 2011-05-22 11:34:02 --> Model Class Initialized
DEBUG - 2011-05-22 11:34:02 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-05-22 11:34:02 --> Database Driver Class Initialized
DEBUG - 2011-05-22 11:34:02 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-05-22 11:34:02 --> Helper loaded: url_helper
DEBUG - 2011-05-22 11:34:02 --> File loaded: application/views/common/header.php
DEBUG - 2011-05-22 11:34:02 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-05-22 11:34:02 --> File loaded: application/views/common/footer.php
DEBUG - 2011-05-22 11:34:02 --> File loaded: application/views/layout/main.php
DEBUG - 2011-05-22 11:34:02 --> Final output sent to browser
DEBUG - 2011-05-22 11:34:02 --> Total execution time: 0.2196
DEBUG - 2011-05-22 11:34:03 --> Config Class Initialized
DEBUG - 2011-05-22 11:34:03 --> Hooks Class Initialized
DEBUG - 2011-05-22 11:34:03 --> Utf8 Class Initialized
DEBUG - 2011-05-22 11:34:03 --> UTF-8 Support Enabled
DEBUG - 2011-05-22 11:34:03 --> URI Class Initialized
DEBUG - 2011-05-22 11:34:03 --> Router Class Initialized
DEBUG - 2011-05-22 11:34:03 --> Output Class Initialized
DEBUG - 2011-05-22 11:34:03 --> Input Class Initialized
DEBUG - 2011-05-22 11:34:03 --> Global POST and COOKIE data sanitized
DEBUG - 2011-05-22 11:34:03 --> Language Class Initialized
DEBUG - 2011-05-22 11:34:03 --> Loader Class Initialized
DEBUG - 2011-05-22 11:34:03 --> Controller Class Initialized
DEBUG - 2011-05-22 11:34:03 --> Model Class Initialized
DEBUG - 2011-05-22 11:34:04 --> Model Class Initialized
DEBUG - 2011-05-22 11:34:04 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-05-22 11:34:04 --> Database Driver Class Initialized
DEBUG - 2011-05-22 11:34:04 --> Final output sent to browser
DEBUG - 2011-05-22 11:34:04 --> Total execution time: 0.7335
DEBUG - 2011-05-22 12:22:10 --> Config Class Initialized
DEBUG - 2011-05-22 12:22:10 --> Hooks Class Initialized
DEBUG - 2011-05-22 12:22:10 --> Utf8 Class Initialized
DEBUG - 2011-05-22 12:22:10 --> UTF-8 Support Enabled
DEBUG - 2011-05-22 12:22:10 --> URI Class Initialized
DEBUG - 2011-05-22 12:22:10 --> Router Class Initialized
DEBUG - 2011-05-22 12:22:10 --> Output Class Initialized
DEBUG - 2011-05-22 12:22:10 --> Input Class Initialized
DEBUG - 2011-05-22 12:22:10 --> Global POST and COOKIE data sanitized
DEBUG - 2011-05-22 12:22:10 --> Language Class Initialized
DEBUG - 2011-05-22 12:22:10 --> Loader Class Initialized
DEBUG - 2011-05-22 12:22:10 --> Controller Class Initialized
DEBUG - 2011-05-22 12:22:10 --> Model Class Initialized
DEBUG - 2011-05-22 12:22:10 --> Model Class Initialized
DEBUG - 2011-05-22 12:22:10 --> Model Class Initialized
DEBUG - 2011-05-22 12:22:10 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-05-22 12:22:10 --> Database Driver Class Initialized
DEBUG - 2011-05-22 12:22:10 --> File loaded: application/views/table/main.php
DEBUG - 2011-05-22 12:22:10 --> Helper loaded: url_helper
DEBUG - 2011-05-22 12:22:10 --> File loaded: application/views/common/header.php
DEBUG - 2011-05-22 12:22:10 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-05-22 12:22:10 --> File loaded: application/views/common/footer.php
DEBUG - 2011-05-22 12:22:10 --> File loaded: application/views/layout/main.php
DEBUG - 2011-05-22 12:22:10 --> Final output sent to browser
DEBUG - 2011-05-22 12:22:10 --> Total execution time: 0.5156
DEBUG - 2011-05-22 12:25:43 --> Config Class Initialized
DEBUG - 2011-05-22 12:25:43 --> Hooks Class Initialized
DEBUG - 2011-05-22 12:25:43 --> Utf8 Class Initialized
DEBUG - 2011-05-22 12:25:43 --> UTF-8 Support Enabled
DEBUG - 2011-05-22 12:25:43 --> URI Class Initialized
DEBUG - 2011-05-22 12:25:43 --> Router Class Initialized
DEBUG - 2011-05-22 12:25:43 --> Output Class Initialized
DEBUG - 2011-05-22 12:25:43 --> Input Class Initialized
DEBUG - 2011-05-22 12:25:43 --> Global POST and COOKIE data sanitized
DEBUG - 2011-05-22 12:25:43 --> Language Class Initialized
DEBUG - 2011-05-22 12:25:43 --> Loader Class Initialized
DEBUG - 2011-05-22 12:25:43 --> Controller Class Initialized
ERROR - 2011-05-22 12:25:43 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-05-22 12:25:43 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-05-22 12:25:43 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-05-22 12:25:43 --> Model Class Initialized
DEBUG - 2011-05-22 12:25:43 --> Model Class Initialized
DEBUG - 2011-05-22 12:25:43 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-05-22 12:25:43 --> Database Driver Class Initialized
DEBUG - 2011-05-22 12:25:43 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-05-22 12:25:43 --> Helper loaded: url_helper
DEBUG - 2011-05-22 12:25:43 --> File loaded: application/views/common/header.php
DEBUG - 2011-05-22 12:25:43 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-05-22 12:25:43 --> File loaded: application/views/common/footer.php
DEBUG - 2011-05-22 12:25:43 --> File loaded: application/views/layout/main.php
DEBUG - 2011-05-22 12:25:43 --> Final output sent to browser
DEBUG - 2011-05-22 12:25:43 --> Total execution time: 0.1015
DEBUG - 2011-05-22 12:25:43 --> Config Class Initialized
DEBUG - 2011-05-22 12:25:43 --> Hooks Class Initialized
DEBUG - 2011-05-22 12:25:43 --> Utf8 Class Initialized
DEBUG - 2011-05-22 12:25:43 --> UTF-8 Support Enabled
DEBUG - 2011-05-22 12:25:43 --> URI Class Initialized
DEBUG - 2011-05-22 12:25:43 --> Router Class Initialized
DEBUG - 2011-05-22 12:25:43 --> Output Class Initialized
DEBUG - 2011-05-22 12:25:43 --> Input Class Initialized
DEBUG - 2011-05-22 12:25:43 --> Global POST and COOKIE data sanitized
DEBUG - 2011-05-22 12:25:43 --> Language Class Initialized
DEBUG - 2011-05-22 12:25:43 --> Loader Class Initialized
DEBUG - 2011-05-22 12:25:43 --> Controller Class Initialized
DEBUG - 2011-05-22 12:25:43 --> Model Class Initialized
DEBUG - 2011-05-22 12:25:43 --> Model Class Initialized
DEBUG - 2011-05-22 12:25:43 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-05-22 12:25:43 --> Database Driver Class Initialized
DEBUG - 2011-05-22 12:25:44 --> Final output sent to browser
DEBUG - 2011-05-22 12:25:44 --> Total execution time: 0.8998
DEBUG - 2011-05-22 12:25:45 --> Config Class Initialized
DEBUG - 2011-05-22 12:25:45 --> Hooks Class Initialized
DEBUG - 2011-05-22 12:25:45 --> Utf8 Class Initialized
DEBUG - 2011-05-22 12:25:45 --> UTF-8 Support Enabled
DEBUG - 2011-05-22 12:25:45 --> URI Class Initialized
DEBUG - 2011-05-22 12:25:45 --> Router Class Initialized
ERROR - 2011-05-22 12:25:45 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-05-22 12:25:46 --> Config Class Initialized
DEBUG - 2011-05-22 12:25:46 --> Hooks Class Initialized
DEBUG - 2011-05-22 12:25:46 --> Utf8 Class Initialized
DEBUG - 2011-05-22 12:25:46 --> UTF-8 Support Enabled
DEBUG - 2011-05-22 12:25:46 --> URI Class Initialized
DEBUG - 2011-05-22 12:25:46 --> Router Class Initialized
ERROR - 2011-05-22 12:25:46 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-05-22 12:25:47 --> Config Class Initialized
DEBUG - 2011-05-22 12:25:47 --> Hooks Class Initialized
DEBUG - 2011-05-22 12:25:47 --> Utf8 Class Initialized
DEBUG - 2011-05-22 12:25:47 --> UTF-8 Support Enabled
DEBUG - 2011-05-22 12:25:47 --> URI Class Initialized
DEBUG - 2011-05-22 12:25:47 --> Router Class Initialized
ERROR - 2011-05-22 12:25:47 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-05-22 12:37:07 --> Config Class Initialized
DEBUG - 2011-05-22 12:37:07 --> Hooks Class Initialized
DEBUG - 2011-05-22 12:37:07 --> Utf8 Class Initialized
DEBUG - 2011-05-22 12:37:07 --> UTF-8 Support Enabled
DEBUG - 2011-05-22 12:37:07 --> URI Class Initialized
DEBUG - 2011-05-22 12:37:07 --> Router Class Initialized
DEBUG - 2011-05-22 12:37:07 --> No URI present. Default controller set.
DEBUG - 2011-05-22 12:37:07 --> Output Class Initialized
DEBUG - 2011-05-22 12:37:07 --> Input Class Initialized
DEBUG - 2011-05-22 12:37:07 --> Global POST and COOKIE data sanitized
DEBUG - 2011-05-22 12:37:07 --> Language Class Initialized
DEBUG - 2011-05-22 12:37:07 --> Loader Class Initialized
DEBUG - 2011-05-22 12:37:07 --> Controller Class Initialized
DEBUG - 2011-05-22 12:37:07 --> File loaded: application/views/splash/main.php
DEBUG - 2011-05-22 12:37:07 --> Helper loaded: url_helper
DEBUG - 2011-05-22 12:37:07 --> File loaded: application/views/common/header.php
DEBUG - 2011-05-22 12:37:07 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-05-22 12:37:07 --> File loaded: application/views/common/footer.php
DEBUG - 2011-05-22 12:37:07 --> File loaded: application/views/layout/main.php
DEBUG - 2011-05-22 12:37:07 --> Final output sent to browser
DEBUG - 2011-05-22 12:37:07 --> Total execution time: 0.0626
DEBUG - 2011-05-22 12:38:45 --> Config Class Initialized
DEBUG - 2011-05-22 12:38:45 --> Hooks Class Initialized
DEBUG - 2011-05-22 12:38:45 --> Utf8 Class Initialized
DEBUG - 2011-05-22 12:38:45 --> UTF-8 Support Enabled
DEBUG - 2011-05-22 12:38:45 --> URI Class Initialized
DEBUG - 2011-05-22 12:38:45 --> Router Class Initialized
DEBUG - 2011-05-22 12:38:45 --> No URI present. Default controller set.
DEBUG - 2011-05-22 12:38:45 --> Output Class Initialized
DEBUG - 2011-05-22 12:38:45 --> Input Class Initialized
DEBUG - 2011-05-22 12:38:45 --> Global POST and COOKIE data sanitized
DEBUG - 2011-05-22 12:38:45 --> Language Class Initialized
DEBUG - 2011-05-22 12:38:45 --> Loader Class Initialized
DEBUG - 2011-05-22 12:38:45 --> Controller Class Initialized
DEBUG - 2011-05-22 12:38:45 --> File loaded: application/views/splash/main.php
DEBUG - 2011-05-22 12:38:45 --> Helper loaded: url_helper
DEBUG - 2011-05-22 12:38:45 --> File loaded: application/views/common/header.php
DEBUG - 2011-05-22 12:38:45 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-05-22 12:38:45 --> File loaded: application/views/common/footer.php
DEBUG - 2011-05-22 12:38:45 --> File loaded: application/views/layout/main.php
DEBUG - 2011-05-22 12:38:45 --> Final output sent to browser
DEBUG - 2011-05-22 12:38:45 --> Total execution time: 0.0565
DEBUG - 2011-05-22 12:38:47 --> Config Class Initialized
DEBUG - 2011-05-22 12:38:47 --> Hooks Class Initialized
DEBUG - 2011-05-22 12:38:47 --> Utf8 Class Initialized
DEBUG - 2011-05-22 12:38:47 --> UTF-8 Support Enabled
DEBUG - 2011-05-22 12:38:47 --> URI Class Initialized
DEBUG - 2011-05-22 12:38:47 --> Router Class Initialized
ERROR - 2011-05-22 12:38:47 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-05-22 12:38:47 --> Config Class Initialized
DEBUG - 2011-05-22 12:38:47 --> Hooks Class Initialized
DEBUG - 2011-05-22 12:38:47 --> Utf8 Class Initialized
DEBUG - 2011-05-22 12:38:47 --> UTF-8 Support Enabled
DEBUG - 2011-05-22 12:38:47 --> URI Class Initialized
DEBUG - 2011-05-22 12:38:47 --> Router Class Initialized
DEBUG - 2011-05-22 12:38:47 --> No URI present. Default controller set.
DEBUG - 2011-05-22 12:38:47 --> Output Class Initialized
DEBUG - 2011-05-22 12:38:47 --> Input Class Initialized
DEBUG - 2011-05-22 12:38:47 --> Global POST and COOKIE data sanitized
DEBUG - 2011-05-22 12:38:47 --> Language Class Initialized
DEBUG - 2011-05-22 12:38:47 --> Loader Class Initialized
DEBUG - 2011-05-22 12:38:47 --> Controller Class Initialized
DEBUG - 2011-05-22 12:38:47 --> File loaded: application/views/splash/main.php
DEBUG - 2011-05-22 12:38:47 --> Helper loaded: url_helper
DEBUG - 2011-05-22 12:38:47 --> File loaded: application/views/common/header.php
DEBUG - 2011-05-22 12:38:47 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-05-22 12:38:47 --> File loaded: application/views/common/footer.php
DEBUG - 2011-05-22 12:38:47 --> File loaded: application/views/layout/main.php
DEBUG - 2011-05-22 12:38:47 --> Final output sent to browser
DEBUG - 2011-05-22 12:38:47 --> Total execution time: 0.0257
DEBUG - 2011-05-22 12:42:02 --> Config Class Initialized
DEBUG - 2011-05-22 12:42:02 --> Hooks Class Initialized
DEBUG - 2011-05-22 12:42:02 --> Utf8 Class Initialized
DEBUG - 2011-05-22 12:42:02 --> UTF-8 Support Enabled
DEBUG - 2011-05-22 12:42:02 --> URI Class Initialized
DEBUG - 2011-05-22 12:42:02 --> Router Class Initialized
DEBUG - 2011-05-22 12:42:02 --> No URI present. Default controller set.
DEBUG - 2011-05-22 12:42:02 --> Output Class Initialized
DEBUG - 2011-05-22 12:42:02 --> Input Class Initialized
DEBUG - 2011-05-22 12:42:02 --> Global POST and COOKIE data sanitized
DEBUG - 2011-05-22 12:42:02 --> Language Class Initialized
DEBUG - 2011-05-22 12:42:02 --> Loader Class Initialized
DEBUG - 2011-05-22 12:42:02 --> Controller Class Initialized
DEBUG - 2011-05-22 12:42:02 --> File loaded: application/views/splash/main.php
DEBUG - 2011-05-22 12:42:02 --> Helper loaded: url_helper
DEBUG - 2011-05-22 12:42:02 --> File loaded: application/views/common/header.php
DEBUG - 2011-05-22 12:42:02 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-05-22 12:42:02 --> File loaded: application/views/common/footer.php
DEBUG - 2011-05-22 12:42:02 --> File loaded: application/views/layout/main.php
DEBUG - 2011-05-22 12:42:02 --> Final output sent to browser
DEBUG - 2011-05-22 12:42:02 --> Total execution time: 0.0152
DEBUG - 2011-05-22 12:42:04 --> Config Class Initialized
DEBUG - 2011-05-22 12:42:04 --> Hooks Class Initialized
DEBUG - 2011-05-22 12:42:04 --> Utf8 Class Initialized
DEBUG - 2011-05-22 12:42:04 --> UTF-8 Support Enabled
DEBUG - 2011-05-22 12:42:04 --> URI Class Initialized
DEBUG - 2011-05-22 12:42:04 --> Router Class Initialized
ERROR - 2011-05-22 12:42:04 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-05-22 12:42:06 --> Config Class Initialized
DEBUG - 2011-05-22 12:42:06 --> Hooks Class Initialized
DEBUG - 2011-05-22 12:42:06 --> Utf8 Class Initialized
DEBUG - 2011-05-22 12:42:06 --> UTF-8 Support Enabled
DEBUG - 2011-05-22 12:42:06 --> URI Class Initialized
DEBUG - 2011-05-22 12:42:06 --> Router Class Initialized
ERROR - 2011-05-22 12:42:06 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-05-22 13:07:23 --> Config Class Initialized
DEBUG - 2011-05-22 13:07:23 --> Hooks Class Initialized
DEBUG - 2011-05-22 13:07:23 --> Utf8 Class Initialized
DEBUG - 2011-05-22 13:07:23 --> UTF-8 Support Enabled
DEBUG - 2011-05-22 13:07:23 --> URI Class Initialized
DEBUG - 2011-05-22 13:07:23 --> Router Class Initialized
DEBUG - 2011-05-22 13:07:23 --> Output Class Initialized
DEBUG - 2011-05-22 13:07:23 --> Input Class Initialized
DEBUG - 2011-05-22 13:07:23 --> Global POST and COOKIE data sanitized
DEBUG - 2011-05-22 13:07:23 --> Language Class Initialized
DEBUG - 2011-05-22 13:07:23 --> Loader Class Initialized
DEBUG - 2011-05-22 13:07:23 --> Controller Class Initialized
DEBUG - 2011-05-22 13:07:23 --> Model Class Initialized
DEBUG - 2011-05-22 13:07:23 --> Model Class Initialized
DEBUG - 2011-05-22 13:07:23 --> Model Class Initialized
DEBUG - 2011-05-22 13:07:23 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-05-22 13:07:23 --> Database Driver Class Initialized
DEBUG - 2011-05-22 13:07:24 --> File loaded: application/views/table/main.php
DEBUG - 2011-05-22 13:07:24 --> Helper loaded: url_helper
DEBUG - 2011-05-22 13:07:24 --> File loaded: application/views/common/header.php
DEBUG - 2011-05-22 13:07:24 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-05-22 13:07:24 --> File loaded: application/views/common/footer.php
DEBUG - 2011-05-22 13:07:24 --> File loaded: application/views/layout/main.php
DEBUG - 2011-05-22 13:07:24 --> Final output sent to browser
DEBUG - 2011-05-22 13:07:24 --> Total execution time: 0.6281
DEBUG - 2011-05-22 13:07:27 --> Config Class Initialized
DEBUG - 2011-05-22 13:07:27 --> Hooks Class Initialized
DEBUG - 2011-05-22 13:07:27 --> Utf8 Class Initialized
DEBUG - 2011-05-22 13:07:27 --> UTF-8 Support Enabled
DEBUG - 2011-05-22 13:07:27 --> URI Class Initialized
DEBUG - 2011-05-22 13:07:27 --> Router Class Initialized
ERROR - 2011-05-22 13:07:27 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-05-22 13:07:38 --> Config Class Initialized
DEBUG - 2011-05-22 13:07:38 --> Hooks Class Initialized
DEBUG - 2011-05-22 13:07:38 --> Utf8 Class Initialized
DEBUG - 2011-05-22 13:07:38 --> UTF-8 Support Enabled
DEBUG - 2011-05-22 13:07:38 --> URI Class Initialized
DEBUG - 2011-05-22 13:07:38 --> Router Class Initialized
DEBUG - 2011-05-22 13:07:38 --> Output Class Initialized
DEBUG - 2011-05-22 13:07:38 --> Input Class Initialized
DEBUG - 2011-05-22 13:07:38 --> Global POST and COOKIE data sanitized
DEBUG - 2011-05-22 13:07:38 --> Language Class Initialized
DEBUG - 2011-05-22 13:07:38 --> Loader Class Initialized
DEBUG - 2011-05-22 13:07:38 --> Controller Class Initialized
ERROR - 2011-05-22 13:07:38 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-05-22 13:07:38 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-05-22 13:07:38 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-05-22 13:07:38 --> Model Class Initialized
DEBUG - 2011-05-22 13:07:38 --> Model Class Initialized
DEBUG - 2011-05-22 13:07:38 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-05-22 13:07:38 --> Database Driver Class Initialized
DEBUG - 2011-05-22 13:07:38 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-05-22 13:07:38 --> Helper loaded: url_helper
DEBUG - 2011-05-22 13:07:38 --> File loaded: application/views/common/header.php
DEBUG - 2011-05-22 13:07:38 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-05-22 13:07:38 --> File loaded: application/views/common/footer.php
DEBUG - 2011-05-22 13:07:38 --> File loaded: application/views/layout/main.php
DEBUG - 2011-05-22 13:07:38 --> Final output sent to browser
DEBUG - 2011-05-22 13:07:38 --> Total execution time: 0.5527
DEBUG - 2011-05-22 13:07:39 --> Config Class Initialized
DEBUG - 2011-05-22 13:07:39 --> Hooks Class Initialized
DEBUG - 2011-05-22 13:07:39 --> Utf8 Class Initialized
DEBUG - 2011-05-22 13:07:39 --> UTF-8 Support Enabled
DEBUG - 2011-05-22 13:07:39 --> URI Class Initialized
DEBUG - 2011-05-22 13:07:39 --> Router Class Initialized
DEBUG - 2011-05-22 13:07:39 --> Output Class Initialized
DEBUG - 2011-05-22 13:07:39 --> Input Class Initialized
DEBUG - 2011-05-22 13:07:39 --> Global POST and COOKIE data sanitized
DEBUG - 2011-05-22 13:07:39 --> Language Class Initialized
DEBUG - 2011-05-22 13:07:39 --> Loader Class Initialized
DEBUG - 2011-05-22 13:07:39 --> Controller Class Initialized
DEBUG - 2011-05-22 13:07:39 --> Model Class Initialized
DEBUG - 2011-05-22 13:07:39 --> Model Class Initialized
DEBUG - 2011-05-22 13:07:39 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-05-22 13:07:39 --> Database Driver Class Initialized
DEBUG - 2011-05-22 13:07:40 --> Final output sent to browser
DEBUG - 2011-05-22 13:07:40 --> Total execution time: 0.8457
DEBUG - 2011-05-22 13:07:54 --> Config Class Initialized
DEBUG - 2011-05-22 13:07:54 --> Hooks Class Initialized
DEBUG - 2011-05-22 13:07:54 --> Utf8 Class Initialized
DEBUG - 2011-05-22 13:07:54 --> UTF-8 Support Enabled
DEBUG - 2011-05-22 13:07:54 --> URI Class Initialized
DEBUG - 2011-05-22 13:07:54 --> Router Class Initialized
DEBUG - 2011-05-22 13:07:54 --> Output Class Initialized
DEBUG - 2011-05-22 13:07:54 --> Input Class Initialized
DEBUG - 2011-05-22 13:07:54 --> Global POST and COOKIE data sanitized
DEBUG - 2011-05-22 13:07:54 --> Language Class Initialized
DEBUG - 2011-05-22 13:07:54 --> Loader Class Initialized
DEBUG - 2011-05-22 13:07:54 --> Controller Class Initialized
DEBUG - 2011-05-22 13:07:54 --> Model Class Initialized
DEBUG - 2011-05-22 13:07:54 --> Model Class Initialized
DEBUG - 2011-05-22 13:07:54 --> Model Class Initialized
DEBUG - 2011-05-22 13:07:54 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-05-22 13:07:54 --> Database Driver Class Initialized
DEBUG - 2011-05-22 13:07:54 --> File loaded: application/views/table/main.php
DEBUG - 2011-05-22 13:07:54 --> Helper loaded: url_helper
DEBUG - 2011-05-22 13:07:54 --> File loaded: application/views/common/header.php
DEBUG - 2011-05-22 13:07:54 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-05-22 13:07:54 --> File loaded: application/views/common/footer.php
DEBUG - 2011-05-22 13:07:54 --> File loaded: application/views/layout/main.php
DEBUG - 2011-05-22 13:07:54 --> Final output sent to browser
DEBUG - 2011-05-22 13:07:54 --> Total execution time: 0.0560
DEBUG - 2011-05-22 13:08:08 --> Config Class Initialized
DEBUG - 2011-05-22 13:08:08 --> Hooks Class Initialized
DEBUG - 2011-05-22 13:08:08 --> Utf8 Class Initialized
DEBUG - 2011-05-22 13:08:08 --> UTF-8 Support Enabled
DEBUG - 2011-05-22 13:08:08 --> URI Class Initialized
DEBUG - 2011-05-22 13:08:08 --> Router Class Initialized
DEBUG - 2011-05-22 13:08:08 --> Output Class Initialized
DEBUG - 2011-05-22 13:08:08 --> Input Class Initialized
DEBUG - 2011-05-22 13:08:08 --> Global POST and COOKIE data sanitized
DEBUG - 2011-05-22 13:08:08 --> Language Class Initialized
DEBUG - 2011-05-22 13:08:08 --> Loader Class Initialized
DEBUG - 2011-05-22 13:08:08 --> Controller Class Initialized
ERROR - 2011-05-22 13:08:08 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-05-22 13:08:08 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-05-22 13:08:08 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-05-22 13:08:08 --> Model Class Initialized
DEBUG - 2011-05-22 13:08:08 --> Model Class Initialized
DEBUG - 2011-05-22 13:08:08 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-05-22 13:08:08 --> Database Driver Class Initialized
DEBUG - 2011-05-22 13:08:08 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-05-22 13:08:08 --> Helper loaded: url_helper
DEBUG - 2011-05-22 13:08:08 --> File loaded: application/views/common/header.php
DEBUG - 2011-05-22 13:08:08 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-05-22 13:08:08 --> File loaded: application/views/common/footer.php
DEBUG - 2011-05-22 13:08:08 --> File loaded: application/views/layout/main.php
DEBUG - 2011-05-22 13:08:08 --> Final output sent to browser
DEBUG - 2011-05-22 13:08:08 --> Total execution time: 0.0272
DEBUG - 2011-05-22 13:08:10 --> Config Class Initialized
DEBUG - 2011-05-22 13:08:10 --> Hooks Class Initialized
DEBUG - 2011-05-22 13:08:10 --> Utf8 Class Initialized
DEBUG - 2011-05-22 13:08:10 --> UTF-8 Support Enabled
DEBUG - 2011-05-22 13:08:10 --> URI Class Initialized
DEBUG - 2011-05-22 13:08:10 --> Router Class Initialized
DEBUG - 2011-05-22 13:08:10 --> Output Class Initialized
DEBUG - 2011-05-22 13:08:10 --> Input Class Initialized
DEBUG - 2011-05-22 13:08:10 --> Global POST and COOKIE data sanitized
DEBUG - 2011-05-22 13:08:10 --> Language Class Initialized
DEBUG - 2011-05-22 13:08:10 --> Loader Class Initialized
DEBUG - 2011-05-22 13:08:10 --> Controller Class Initialized
DEBUG - 2011-05-22 13:08:10 --> Model Class Initialized
DEBUG - 2011-05-22 13:08:10 --> Model Class Initialized
DEBUG - 2011-05-22 13:08:10 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-05-22 13:08:10 --> Database Driver Class Initialized
DEBUG - 2011-05-22 13:08:11 --> Final output sent to browser
DEBUG - 2011-05-22 13:08:11 --> Total execution time: 0.4265
DEBUG - 2011-05-22 13:08:13 --> Config Class Initialized
DEBUG - 2011-05-22 13:08:13 --> Hooks Class Initialized
DEBUG - 2011-05-22 13:08:13 --> Utf8 Class Initialized
DEBUG - 2011-05-22 13:08:13 --> UTF-8 Support Enabled
DEBUG - 2011-05-22 13:08:13 --> URI Class Initialized
DEBUG - 2011-05-22 13:08:13 --> Router Class Initialized
DEBUG - 2011-05-22 13:08:13 --> Output Class Initialized
DEBUG - 2011-05-22 13:08:13 --> Input Class Initialized
DEBUG - 2011-05-22 13:08:13 --> Global POST and COOKIE data sanitized
DEBUG - 2011-05-22 13:08:13 --> Language Class Initialized
DEBUG - 2011-05-22 13:08:13 --> Loader Class Initialized
DEBUG - 2011-05-22 13:08:13 --> Controller Class Initialized
ERROR - 2011-05-22 13:08:13 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-05-22 13:08:13 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-05-22 13:08:13 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-05-22 13:08:13 --> Model Class Initialized
DEBUG - 2011-05-22 13:08:13 --> Model Class Initialized
DEBUG - 2011-05-22 13:08:13 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-05-22 13:08:13 --> Database Driver Class Initialized
DEBUG - 2011-05-22 13:08:13 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-05-22 13:08:13 --> Helper loaded: url_helper
DEBUG - 2011-05-22 13:08:13 --> File loaded: application/views/common/header.php
DEBUG - 2011-05-22 13:08:13 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-05-22 13:08:13 --> File loaded: application/views/common/footer.php
DEBUG - 2011-05-22 13:08:13 --> File loaded: application/views/layout/main.php
DEBUG - 2011-05-22 13:08:13 --> Final output sent to browser
DEBUG - 2011-05-22 13:08:13 --> Total execution time: 0.0321
DEBUG - 2011-05-22 13:08:14 --> Config Class Initialized
DEBUG - 2011-05-22 13:08:14 --> Hooks Class Initialized
DEBUG - 2011-05-22 13:08:14 --> Utf8 Class Initialized
DEBUG - 2011-05-22 13:08:14 --> UTF-8 Support Enabled
DEBUG - 2011-05-22 13:08:14 --> URI Class Initialized
DEBUG - 2011-05-22 13:08:14 --> Router Class Initialized
DEBUG - 2011-05-22 13:08:14 --> Output Class Initialized
DEBUG - 2011-05-22 13:08:14 --> Input Class Initialized
DEBUG - 2011-05-22 13:08:14 --> Global POST and COOKIE data sanitized
DEBUG - 2011-05-22 13:08:14 --> Language Class Initialized
DEBUG - 2011-05-22 13:08:14 --> Loader Class Initialized
DEBUG - 2011-05-22 13:08:14 --> Controller Class Initialized
DEBUG - 2011-05-22 13:08:14 --> Model Class Initialized
DEBUG - 2011-05-22 13:08:14 --> Model Class Initialized
DEBUG - 2011-05-22 13:08:14 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-05-22 13:08:14 --> Database Driver Class Initialized
DEBUG - 2011-05-22 13:08:14 --> Final output sent to browser
DEBUG - 2011-05-22 13:08:14 --> Total execution time: 0.5791
DEBUG - 2011-05-22 13:08:24 --> Config Class Initialized
DEBUG - 2011-05-22 13:08:24 --> Hooks Class Initialized
DEBUG - 2011-05-22 13:08:24 --> Utf8 Class Initialized
DEBUG - 2011-05-22 13:08:24 --> UTF-8 Support Enabled
DEBUG - 2011-05-22 13:08:24 --> URI Class Initialized
DEBUG - 2011-05-22 13:08:24 --> Router Class Initialized
DEBUG - 2011-05-22 13:08:24 --> Output Class Initialized
DEBUG - 2011-05-22 13:08:24 --> Input Class Initialized
DEBUG - 2011-05-22 13:08:24 --> Global POST and COOKIE data sanitized
DEBUG - 2011-05-22 13:08:24 --> Language Class Initialized
DEBUG - 2011-05-22 13:08:24 --> Loader Class Initialized
DEBUG - 2011-05-22 13:08:24 --> Controller Class Initialized
ERROR - 2011-05-22 13:08:24 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-05-22 13:08:24 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-05-22 13:08:24 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-05-22 13:08:24 --> Model Class Initialized
DEBUG - 2011-05-22 13:08:24 --> Model Class Initialized
DEBUG - 2011-05-22 13:08:24 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-05-22 13:08:24 --> Database Driver Class Initialized
DEBUG - 2011-05-22 13:08:24 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-05-22 13:08:24 --> Helper loaded: url_helper
DEBUG - 2011-05-22 13:08:24 --> File loaded: application/views/common/header.php
DEBUG - 2011-05-22 13:08:24 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-05-22 13:08:24 --> File loaded: application/views/common/footer.php
DEBUG - 2011-05-22 13:08:24 --> File loaded: application/views/layout/main.php
DEBUG - 2011-05-22 13:08:24 --> Final output sent to browser
DEBUG - 2011-05-22 13:08:24 --> Total execution time: 0.0285
DEBUG - 2011-05-22 13:08:25 --> Config Class Initialized
DEBUG - 2011-05-22 13:08:25 --> Hooks Class Initialized
DEBUG - 2011-05-22 13:08:25 --> Utf8 Class Initialized
DEBUG - 2011-05-22 13:08:25 --> UTF-8 Support Enabled
DEBUG - 2011-05-22 13:08:25 --> URI Class Initialized
DEBUG - 2011-05-22 13:08:25 --> Router Class Initialized
DEBUG - 2011-05-22 13:08:25 --> Output Class Initialized
DEBUG - 2011-05-22 13:08:25 --> Input Class Initialized
DEBUG - 2011-05-22 13:08:25 --> Global POST and COOKIE data sanitized
DEBUG - 2011-05-22 13:08:25 --> Language Class Initialized
DEBUG - 2011-05-22 13:08:25 --> Loader Class Initialized
DEBUG - 2011-05-22 13:08:25 --> Controller Class Initialized
DEBUG - 2011-05-22 13:08:25 --> Model Class Initialized
DEBUG - 2011-05-22 13:08:25 --> Model Class Initialized
DEBUG - 2011-05-22 13:08:25 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-05-22 13:08:25 --> Database Driver Class Initialized
DEBUG - 2011-05-22 13:08:25 --> Final output sent to browser
DEBUG - 2011-05-22 13:08:25 --> Total execution time: 0.5679
DEBUG - 2011-05-22 13:12:28 --> Config Class Initialized
DEBUG - 2011-05-22 13:12:28 --> Hooks Class Initialized
DEBUG - 2011-05-22 13:12:28 --> Utf8 Class Initialized
DEBUG - 2011-05-22 13:12:28 --> UTF-8 Support Enabled
DEBUG - 2011-05-22 13:12:28 --> URI Class Initialized
DEBUG - 2011-05-22 13:12:28 --> Router Class Initialized
DEBUG - 2011-05-22 13:12:28 --> Output Class Initialized
DEBUG - 2011-05-22 13:12:28 --> Input Class Initialized
DEBUG - 2011-05-22 13:12:28 --> Global POST and COOKIE data sanitized
DEBUG - 2011-05-22 13:12:28 --> Language Class Initialized
DEBUG - 2011-05-22 13:12:28 --> Loader Class Initialized
DEBUG - 2011-05-22 13:12:28 --> Controller Class Initialized
DEBUG - 2011-05-22 13:12:28 --> Model Class Initialized
DEBUG - 2011-05-22 13:12:28 --> Model Class Initialized
DEBUG - 2011-05-22 13:12:28 --> Model Class Initialized
DEBUG - 2011-05-22 13:12:28 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-05-22 13:12:28 --> Config Class Initialized
DEBUG - 2011-05-22 13:12:28 --> Hooks Class Initialized
DEBUG - 2011-05-22 13:12:28 --> Utf8 Class Initialized
DEBUG - 2011-05-22 13:12:28 --> UTF-8 Support Enabled
DEBUG - 2011-05-22 13:12:28 --> URI Class Initialized
DEBUG - 2011-05-22 13:12:28 --> Router Class Initialized
DEBUG - 2011-05-22 13:12:28 --> Output Class Initialized
DEBUG - 2011-05-22 13:12:28 --> Database Driver Class Initialized
DEBUG - 2011-05-22 13:12:28 --> Input Class Initialized
DEBUG - 2011-05-22 13:12:28 --> Global POST and COOKIE data sanitized
DEBUG - 2011-05-22 13:12:28 --> Language Class Initialized
DEBUG - 2011-05-22 13:12:28 --> Loader Class Initialized
DEBUG - 2011-05-22 13:12:28 --> Controller Class Initialized
ERROR - 2011-05-22 13:12:28 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-05-22 13:12:28 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-05-22 13:12:28 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-05-22 13:12:28 --> Model Class Initialized
DEBUG - 2011-05-22 13:12:28 --> Model Class Initialized
DEBUG - 2011-05-22 13:12:28 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-05-22 13:12:28 --> Database Driver Class Initialized
DEBUG - 2011-05-22 13:12:28 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-05-22 13:12:28 --> Helper loaded: url_helper
DEBUG - 2011-05-22 13:12:28 --> File loaded: application/views/common/header.php
DEBUG - 2011-05-22 13:12:28 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-05-22 13:12:28 --> File loaded: application/views/common/footer.php
DEBUG - 2011-05-22 13:12:28 --> File loaded: application/views/layout/main.php
DEBUG - 2011-05-22 13:12:28 --> Final output sent to browser
DEBUG - 2011-05-22 13:12:28 --> Total execution time: 0.0350
DEBUG - 2011-05-22 13:12:28 --> File loaded: application/views/table/main.php
DEBUG - 2011-05-22 13:12:28 --> Helper loaded: url_helper
DEBUG - 2011-05-22 13:12:28 --> File loaded: application/views/common/header.php
DEBUG - 2011-05-22 13:12:28 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-05-22 13:12:28 --> File loaded: application/views/common/footer.php
DEBUG - 2011-05-22 13:12:28 --> File loaded: application/views/layout/main.php
DEBUG - 2011-05-22 13:12:28 --> Final output sent to browser
DEBUG - 2011-05-22 13:12:28 --> Total execution time: 0.0759
DEBUG - 2011-05-22 13:39:05 --> Config Class Initialized
DEBUG - 2011-05-22 13:39:05 --> Hooks Class Initialized
DEBUG - 2011-05-22 13:39:05 --> Utf8 Class Initialized
DEBUG - 2011-05-22 13:39:05 --> UTF-8 Support Enabled
DEBUG - 2011-05-22 13:39:05 --> URI Class Initialized
DEBUG - 2011-05-22 13:39:05 --> Router Class Initialized
DEBUG - 2011-05-22 13:39:05 --> Output Class Initialized
DEBUG - 2011-05-22 13:39:05 --> Input Class Initialized
DEBUG - 2011-05-22 13:39:05 --> Global POST and COOKIE data sanitized
DEBUG - 2011-05-22 13:39:05 --> Language Class Initialized
DEBUG - 2011-05-22 13:39:05 --> Loader Class Initialized
DEBUG - 2011-05-22 13:39:05 --> Controller Class Initialized
DEBUG - 2011-05-22 13:39:05 --> Model Class Initialized
DEBUG - 2011-05-22 13:39:05 --> Model Class Initialized
DEBUG - 2011-05-22 13:39:05 --> Model Class Initialized
DEBUG - 2011-05-22 13:39:05 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-05-22 13:39:05 --> Database Driver Class Initialized
DEBUG - 2011-05-22 13:39:05 --> File loaded: application/views/table/main.php
DEBUG - 2011-05-22 13:39:05 --> Helper loaded: url_helper
DEBUG - 2011-05-22 13:39:05 --> File loaded: application/views/common/header.php
DEBUG - 2011-05-22 13:39:05 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-05-22 13:39:05 --> File loaded: application/views/common/footer.php
DEBUG - 2011-05-22 13:39:05 --> File loaded: application/views/layout/main.php
DEBUG - 2011-05-22 13:39:05 --> Final output sent to browser
DEBUG - 2011-05-22 13:39:05 --> Total execution time: 0.4818
DEBUG - 2011-05-22 14:34:22 --> Config Class Initialized
DEBUG - 2011-05-22 14:34:22 --> Hooks Class Initialized
DEBUG - 2011-05-22 14:34:22 --> Utf8 Class Initialized
DEBUG - 2011-05-22 14:34:22 --> UTF-8 Support Enabled
DEBUG - 2011-05-22 14:34:22 --> URI Class Initialized
DEBUG - 2011-05-22 14:34:22 --> Router Class Initialized
DEBUG - 2011-05-22 14:34:22 --> No URI present. Default controller set.
DEBUG - 2011-05-22 14:34:22 --> Output Class Initialized
DEBUG - 2011-05-22 14:34:22 --> Input Class Initialized
DEBUG - 2011-05-22 14:34:22 --> Global POST and COOKIE data sanitized
DEBUG - 2011-05-22 14:34:22 --> Language Class Initialized
DEBUG - 2011-05-22 14:34:22 --> Loader Class Initialized
DEBUG - 2011-05-22 14:34:22 --> Controller Class Initialized
DEBUG - 2011-05-22 14:34:22 --> File loaded: application/views/splash/main.php
DEBUG - 2011-05-22 14:34:22 --> Helper loaded: url_helper
DEBUG - 2011-05-22 14:34:22 --> File loaded: application/views/common/header.php
DEBUG - 2011-05-22 14:34:22 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-05-22 14:34:22 --> File loaded: application/views/common/footer.php
DEBUG - 2011-05-22 14:34:22 --> File loaded: application/views/layout/main.php
DEBUG - 2011-05-22 14:34:22 --> Final output sent to browser
DEBUG - 2011-05-22 14:34:22 --> Total execution time: 0.2597
DEBUG - 2011-05-22 14:34:22 --> Config Class Initialized
DEBUG - 2011-05-22 14:34:22 --> Hooks Class Initialized
DEBUG - 2011-05-22 14:34:22 --> Utf8 Class Initialized
DEBUG - 2011-05-22 14:34:22 --> UTF-8 Support Enabled
DEBUG - 2011-05-22 14:34:22 --> URI Class Initialized
DEBUG - 2011-05-22 14:34:22 --> Router Class Initialized
ERROR - 2011-05-22 14:34:22 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-05-22 14:43:05 --> Config Class Initialized
DEBUG - 2011-05-22 14:43:05 --> Hooks Class Initialized
DEBUG - 2011-05-22 14:43:05 --> Utf8 Class Initialized
DEBUG - 2011-05-22 14:43:05 --> UTF-8 Support Enabled
DEBUG - 2011-05-22 14:43:05 --> URI Class Initialized
DEBUG - 2011-05-22 14:43:05 --> Router Class Initialized
DEBUG - 2011-05-22 14:43:05 --> Output Class Initialized
DEBUG - 2011-05-22 14:43:05 --> Input Class Initialized
DEBUG - 2011-05-22 14:43:05 --> Global POST and COOKIE data sanitized
DEBUG - 2011-05-22 14:43:05 --> Language Class Initialized
DEBUG - 2011-05-22 14:43:05 --> Loader Class Initialized
DEBUG - 2011-05-22 14:43:05 --> Controller Class Initialized
ERROR - 2011-05-22 14:43:05 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-05-22 14:43:05 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-05-22 14:43:05 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-05-22 14:43:05 --> Model Class Initialized
DEBUG - 2011-05-22 14:43:05 --> Model Class Initialized
DEBUG - 2011-05-22 14:43:05 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-05-22 14:43:06 --> Database Driver Class Initialized
DEBUG - 2011-05-22 14:43:06 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-05-22 14:43:06 --> Helper loaded: url_helper
DEBUG - 2011-05-22 14:43:06 --> File loaded: application/views/common/header.php
DEBUG - 2011-05-22 14:43:06 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-05-22 14:43:06 --> File loaded: application/views/common/footer.php
DEBUG - 2011-05-22 14:43:06 --> File loaded: application/views/layout/main.php
DEBUG - 2011-05-22 14:43:06 --> Final output sent to browser
DEBUG - 2011-05-22 14:43:06 --> Total execution time: 0.1837
DEBUG - 2011-05-22 14:45:02 --> Config Class Initialized
DEBUG - 2011-05-22 14:45:02 --> Hooks Class Initialized
DEBUG - 2011-05-22 14:45:02 --> Utf8 Class Initialized
DEBUG - 2011-05-22 14:45:02 --> UTF-8 Support Enabled
DEBUG - 2011-05-22 14:45:02 --> URI Class Initialized
DEBUG - 2011-05-22 14:45:02 --> Router Class Initialized
DEBUG - 2011-05-22 14:45:02 --> No URI present. Default controller set.
DEBUG - 2011-05-22 14:45:02 --> Output Class Initialized
DEBUG - 2011-05-22 14:45:02 --> Input Class Initialized
DEBUG - 2011-05-22 14:45:02 --> Global POST and COOKIE data sanitized
DEBUG - 2011-05-22 14:45:02 --> Language Class Initialized
DEBUG - 2011-05-22 14:45:02 --> Loader Class Initialized
DEBUG - 2011-05-22 14:45:02 --> Controller Class Initialized
DEBUG - 2011-05-22 14:45:02 --> File loaded: application/views/splash/main.php
DEBUG - 2011-05-22 14:45:02 --> Helper loaded: url_helper
DEBUG - 2011-05-22 14:45:02 --> File loaded: application/views/common/header.php
DEBUG - 2011-05-22 14:45:02 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-05-22 14:45:02 --> File loaded: application/views/common/footer.php
DEBUG - 2011-05-22 14:45:02 --> File loaded: application/views/layout/main.php
DEBUG - 2011-05-22 14:45:02 --> Final output sent to browser
DEBUG - 2011-05-22 14:45:02 --> Total execution time: 0.0814
DEBUG - 2011-05-22 15:32:56 --> Config Class Initialized
DEBUG - 2011-05-22 15:32:56 --> Config Class Initialized
DEBUG - 2011-05-22 15:32:56 --> Hooks Class Initialized
DEBUG - 2011-05-22 15:32:56 --> Hooks Class Initialized
DEBUG - 2011-05-22 15:32:56 --> Utf8 Class Initialized
DEBUG - 2011-05-22 15:32:56 --> Utf8 Class Initialized
DEBUG - 2011-05-22 15:32:56 --> UTF-8 Support Enabled
DEBUG - 2011-05-22 15:32:56 --> UTF-8 Support Enabled
DEBUG - 2011-05-22 15:32:56 --> URI Class Initialized
DEBUG - 2011-05-22 15:32:56 --> URI Class Initialized
DEBUG - 2011-05-22 15:32:56 --> Router Class Initialized
DEBUG - 2011-05-22 15:32:56 --> Router Class Initialized
DEBUG - 2011-05-22 15:32:56 --> Output Class Initialized
DEBUG - 2011-05-22 15:32:56 --> Output Class Initialized
DEBUG - 2011-05-22 15:32:56 --> Input Class Initialized
DEBUG - 2011-05-22 15:32:56 --> Global POST and COOKIE data sanitized
DEBUG - 2011-05-22 15:32:56 --> Input Class Initialized
DEBUG - 2011-05-22 15:32:56 --> Global POST and COOKIE data sanitized
DEBUG - 2011-05-22 15:32:56 --> Language Class Initialized
DEBUG - 2011-05-22 15:32:56 --> Language Class Initialized
DEBUG - 2011-05-22 15:32:56 --> Loader Class Initialized
DEBUG - 2011-05-22 15:32:56 --> Loader Class Initialized
DEBUG - 2011-05-22 15:32:56 --> Controller Class Initialized
DEBUG - 2011-05-22 15:32:56 --> Controller Class Initialized
DEBUG - 2011-05-22 15:32:56 --> Model Class Initialized
DEBUG - 2011-05-22 15:32:56 --> Model Class Initialized
DEBUG - 2011-05-22 15:32:56 --> Model Class Initialized
DEBUG - 2011-05-22 15:32:56 --> Model Class Initialized
DEBUG - 2011-05-22 15:32:56 --> Model Class Initialized
DEBUG - 2011-05-22 15:32:56 --> Model Class Initialized
DEBUG - 2011-05-22 15:32:56 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-05-22 15:32:56 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-05-22 15:32:56 --> Database Driver Class Initialized
DEBUG - 2011-05-22 15:32:56 --> Database Driver Class Initialized
DEBUG - 2011-05-22 15:32:56 --> File loaded: application/views/table/main.php
DEBUG - 2011-05-22 15:32:56 --> File loaded: application/views/table/main.php
DEBUG - 2011-05-22 15:32:56 --> Helper loaded: url_helper
DEBUG - 2011-05-22 15:32:56 --> File loaded: application/views/common/header.php
DEBUG - 2011-05-22 15:32:56 --> Helper loaded: url_helper
DEBUG - 2011-05-22 15:32:56 --> File loaded: application/views/common/header.php
DEBUG - 2011-05-22 15:32:56 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-05-22 15:32:56 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-05-22 15:32:56 --> File loaded: application/views/common/footer.php
DEBUG - 2011-05-22 15:32:56 --> File loaded: application/views/common/footer.php
DEBUG - 2011-05-22 15:32:56 --> File loaded: application/views/layout/main.php
DEBUG - 2011-05-22 15:32:56 --> File loaded: application/views/layout/main.php
DEBUG - 2011-05-22 15:32:56 --> Final output sent to browser
DEBUG - 2011-05-22 15:32:56 --> Total execution time: 0.8099
DEBUG - 2011-05-22 15:32:56 --> Final output sent to browser
DEBUG - 2011-05-22 15:32:56 --> Total execution time: 0.8101
DEBUG - 2011-05-22 15:32:57 --> Config Class Initialized
DEBUG - 2011-05-22 15:32:57 --> Hooks Class Initialized
DEBUG - 2011-05-22 15:32:57 --> Utf8 Class Initialized
DEBUG - 2011-05-22 15:32:57 --> UTF-8 Support Enabled
DEBUG - 2011-05-22 15:32:57 --> URI Class Initialized
DEBUG - 2011-05-22 15:32:57 --> Router Class Initialized
ERROR - 2011-05-22 15:32:57 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-05-22 15:32:58 --> Config Class Initialized
DEBUG - 2011-05-22 15:32:58 --> Hooks Class Initialized
DEBUG - 2011-05-22 15:32:58 --> Utf8 Class Initialized
DEBUG - 2011-05-22 15:32:58 --> UTF-8 Support Enabled
DEBUG - 2011-05-22 15:32:58 --> URI Class Initialized
DEBUG - 2011-05-22 15:32:58 --> Router Class Initialized
ERROR - 2011-05-22 15:32:58 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-05-22 16:38:27 --> Config Class Initialized
DEBUG - 2011-05-22 16:38:27 --> Hooks Class Initialized
DEBUG - 2011-05-22 16:38:27 --> Utf8 Class Initialized
DEBUG - 2011-05-22 16:38:27 --> UTF-8 Support Enabled
DEBUG - 2011-05-22 16:38:27 --> URI Class Initialized
DEBUG - 2011-05-22 16:38:27 --> Router Class Initialized
DEBUG - 2011-05-22 16:38:27 --> Output Class Initialized
DEBUG - 2011-05-22 16:38:27 --> Input Class Initialized
DEBUG - 2011-05-22 16:38:27 --> Global POST and COOKIE data sanitized
DEBUG - 2011-05-22 16:38:27 --> Language Class Initialized
DEBUG - 2011-05-22 16:38:27 --> Loader Class Initialized
DEBUG - 2011-05-22 16:38:27 --> Controller Class Initialized
DEBUG - 2011-05-22 16:38:27 --> Model Class Initialized
DEBUG - 2011-05-22 16:38:27 --> Model Class Initialized
DEBUG - 2011-05-22 16:38:28 --> Model Class Initialized
DEBUG - 2011-05-22 16:38:28 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-05-22 16:38:28 --> Database Driver Class Initialized
DEBUG - 2011-05-22 16:38:28 --> File loaded: application/views/table/main.php
DEBUG - 2011-05-22 16:38:28 --> Helper loaded: url_helper
DEBUG - 2011-05-22 16:38:28 --> File loaded: application/views/common/header.php
DEBUG - 2011-05-22 16:38:28 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-05-22 16:38:28 --> File loaded: application/views/common/footer.php
DEBUG - 2011-05-22 16:38:28 --> File loaded: application/views/layout/main.php
DEBUG - 2011-05-22 16:38:28 --> Final output sent to browser
DEBUG - 2011-05-22 16:38:28 --> Total execution time: 0.5968
DEBUG - 2011-05-22 19:10:35 --> Config Class Initialized
DEBUG - 2011-05-22 19:10:35 --> Hooks Class Initialized
DEBUG - 2011-05-22 19:10:35 --> Utf8 Class Initialized
DEBUG - 2011-05-22 19:10:35 --> UTF-8 Support Enabled
DEBUG - 2011-05-22 19:10:35 --> URI Class Initialized
DEBUG - 2011-05-22 19:10:35 --> Router Class Initialized
DEBUG - 2011-05-22 19:10:35 --> Output Class Initialized
DEBUG - 2011-05-22 19:10:35 --> Input Class Initialized
DEBUG - 2011-05-22 19:10:35 --> Global POST and COOKIE data sanitized
DEBUG - 2011-05-22 19:10:35 --> Language Class Initialized
DEBUG - 2011-05-22 19:10:35 --> Loader Class Initialized
DEBUG - 2011-05-22 19:10:35 --> Controller Class Initialized
DEBUG - 2011-05-22 19:10:35 --> Model Class Initialized
DEBUG - 2011-05-22 19:10:35 --> Model Class Initialized
DEBUG - 2011-05-22 19:10:35 --> Model Class Initialized
DEBUG - 2011-05-22 19:10:35 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-05-22 19:10:35 --> Database Driver Class Initialized
DEBUG - 2011-05-22 19:10:36 --> File loaded: application/views/table/main.php
DEBUG - 2011-05-22 19:10:36 --> Helper loaded: url_helper
DEBUG - 2011-05-22 19:10:36 --> File loaded: application/views/common/header.php
DEBUG - 2011-05-22 19:10:36 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-05-22 19:10:36 --> File loaded: application/views/common/footer.php
DEBUG - 2011-05-22 19:10:36 --> File loaded: application/views/layout/main.php
DEBUG - 2011-05-22 19:10:36 --> Final output sent to browser
DEBUG - 2011-05-22 19:10:36 --> Total execution time: 0.7231
DEBUG - 2011-05-22 19:10:41 --> Config Class Initialized
DEBUG - 2011-05-22 19:10:41 --> Hooks Class Initialized
DEBUG - 2011-05-22 19:10:41 --> Utf8 Class Initialized
DEBUG - 2011-05-22 19:10:41 --> UTF-8 Support Enabled
DEBUG - 2011-05-22 19:10:41 --> URI Class Initialized
DEBUG - 2011-05-22 19:10:41 --> Router Class Initialized
ERROR - 2011-05-22 19:10:41 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-05-22 19:10:41 --> Config Class Initialized
DEBUG - 2011-05-22 19:10:41 --> Hooks Class Initialized
DEBUG - 2011-05-22 19:10:41 --> Utf8 Class Initialized
DEBUG - 2011-05-22 19:10:41 --> UTF-8 Support Enabled
DEBUG - 2011-05-22 19:10:41 --> URI Class Initialized
DEBUG - 2011-05-22 19:10:41 --> Router Class Initialized
ERROR - 2011-05-22 19:10:41 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-05-22 21:12:16 --> Config Class Initialized
DEBUG - 2011-05-22 21:12:16 --> Hooks Class Initialized
DEBUG - 2011-05-22 21:12:16 --> Utf8 Class Initialized
DEBUG - 2011-05-22 21:12:16 --> UTF-8 Support Enabled
DEBUG - 2011-05-22 21:12:16 --> URI Class Initialized
DEBUG - 2011-05-22 21:12:16 --> Router Class Initialized
DEBUG - 2011-05-22 21:12:16 --> Output Class Initialized
DEBUG - 2011-05-22 21:12:16 --> Input Class Initialized
DEBUG - 2011-05-22 21:12:16 --> Global POST and COOKIE data sanitized
DEBUG - 2011-05-22 21:12:16 --> Language Class Initialized
DEBUG - 2011-05-22 21:12:16 --> Loader Class Initialized
DEBUG - 2011-05-22 21:12:16 --> Controller Class Initialized
DEBUG - 2011-05-22 21:12:16 --> Model Class Initialized
DEBUG - 2011-05-22 21:12:16 --> Model Class Initialized
DEBUG - 2011-05-22 21:12:16 --> Model Class Initialized
DEBUG - 2011-05-22 21:12:16 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-05-22 21:12:16 --> Database Driver Class Initialized
DEBUG - 2011-05-22 21:12:16 --> File loaded: application/views/table/main.php
DEBUG - 2011-05-22 21:12:17 --> Helper loaded: url_helper
DEBUG - 2011-05-22 21:12:17 --> File loaded: application/views/common/header.php
DEBUG - 2011-05-22 21:12:17 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-05-22 21:12:17 --> File loaded: application/views/common/footer.php
DEBUG - 2011-05-22 21:12:17 --> File loaded: application/views/layout/main.php
DEBUG - 2011-05-22 21:12:17 --> Final output sent to browser
DEBUG - 2011-05-22 21:12:17 --> Total execution time: 0.6628
DEBUG - 2011-05-22 21:12:24 --> Config Class Initialized
DEBUG - 2011-05-22 21:12:24 --> Hooks Class Initialized
DEBUG - 2011-05-22 21:12:24 --> Utf8 Class Initialized
DEBUG - 2011-05-22 21:12:24 --> UTF-8 Support Enabled
DEBUG - 2011-05-22 21:12:24 --> URI Class Initialized
DEBUG - 2011-05-22 21:12:24 --> Router Class Initialized
ERROR - 2011-05-22 21:12:24 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-05-22 21:12:24 --> Config Class Initialized
DEBUG - 2011-05-22 21:12:24 --> Hooks Class Initialized
DEBUG - 2011-05-22 21:12:24 --> Utf8 Class Initialized
DEBUG - 2011-05-22 21:12:24 --> UTF-8 Support Enabled
DEBUG - 2011-05-22 21:12:24 --> URI Class Initialized
DEBUG - 2011-05-22 21:12:24 --> Router Class Initialized
ERROR - 2011-05-22 21:12:24 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-05-22 21:12:24 --> Config Class Initialized
DEBUG - 2011-05-22 21:12:24 --> Hooks Class Initialized
DEBUG - 2011-05-22 21:12:24 --> Utf8 Class Initialized
DEBUG - 2011-05-22 21:12:24 --> UTF-8 Support Enabled
DEBUG - 2011-05-22 21:12:24 --> URI Class Initialized
DEBUG - 2011-05-22 21:12:24 --> Router Class Initialized
ERROR - 2011-05-22 21:12:24 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-05-22 21:17:21 --> Config Class Initialized
DEBUG - 2011-05-22 21:17:21 --> Hooks Class Initialized
DEBUG - 2011-05-22 21:17:21 --> Utf8 Class Initialized
DEBUG - 2011-05-22 21:17:21 --> UTF-8 Support Enabled
DEBUG - 2011-05-22 21:17:21 --> URI Class Initialized
DEBUG - 2011-05-22 21:17:21 --> Router Class Initialized
DEBUG - 2011-05-22 21:17:21 --> Output Class Initialized
DEBUG - 2011-05-22 21:17:21 --> Input Class Initialized
DEBUG - 2011-05-22 21:17:21 --> Global POST and COOKIE data sanitized
DEBUG - 2011-05-22 21:17:21 --> Language Class Initialized
DEBUG - 2011-05-22 21:17:21 --> Loader Class Initialized
DEBUG - 2011-05-22 21:17:21 --> Controller Class Initialized
ERROR - 2011-05-22 21:17:21 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-05-22 21:17:21 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-05-22 21:17:21 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-05-22 21:17:21 --> Model Class Initialized
DEBUG - 2011-05-22 21:17:21 --> Model Class Initialized
DEBUG - 2011-05-22 21:17:21 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-05-22 21:17:21 --> Database Driver Class Initialized
DEBUG - 2011-05-22 21:17:21 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-05-22 21:17:21 --> Helper loaded: url_helper
DEBUG - 2011-05-22 21:17:21 --> File loaded: application/views/common/header.php
DEBUG - 2011-05-22 21:17:21 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-05-22 21:17:21 --> File loaded: application/views/common/footer.php
DEBUG - 2011-05-22 21:17:21 --> File loaded: application/views/layout/main.php
DEBUG - 2011-05-22 21:17:21 --> Final output sent to browser
DEBUG - 2011-05-22 21:17:21 --> Total execution time: 0.1754
DEBUG - 2011-05-22 21:17:24 --> Config Class Initialized
DEBUG - 2011-05-22 21:17:24 --> Hooks Class Initialized
DEBUG - 2011-05-22 21:17:24 --> Utf8 Class Initialized
DEBUG - 2011-05-22 21:17:24 --> UTF-8 Support Enabled
DEBUG - 2011-05-22 21:17:24 --> URI Class Initialized
DEBUG - 2011-05-22 21:17:24 --> Router Class Initialized
DEBUG - 2011-05-22 21:17:24 --> Output Class Initialized
DEBUG - 2011-05-22 21:17:24 --> Input Class Initialized
DEBUG - 2011-05-22 21:17:24 --> Global POST and COOKIE data sanitized
DEBUG - 2011-05-22 21:17:24 --> Language Class Initialized
DEBUG - 2011-05-22 21:17:24 --> Loader Class Initialized
DEBUG - 2011-05-22 21:17:24 --> Controller Class Initialized
DEBUG - 2011-05-22 21:17:24 --> Model Class Initialized
DEBUG - 2011-05-22 21:17:24 --> Model Class Initialized
DEBUG - 2011-05-22 21:17:24 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-05-22 21:17:24 --> Database Driver Class Initialized
DEBUG - 2011-05-22 21:17:25 --> Final output sent to browser
DEBUG - 2011-05-22 21:17:25 --> Total execution time: 0.7393
DEBUG - 2011-05-22 21:17:28 --> Config Class Initialized
DEBUG - 2011-05-22 21:17:28 --> Hooks Class Initialized
DEBUG - 2011-05-22 21:17:28 --> Utf8 Class Initialized
DEBUG - 2011-05-22 21:17:28 --> UTF-8 Support Enabled
DEBUG - 2011-05-22 21:17:28 --> URI Class Initialized
DEBUG - 2011-05-22 21:17:28 --> Router Class Initialized
ERROR - 2011-05-22 21:17:28 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-05-22 22:23:07 --> Config Class Initialized
DEBUG - 2011-05-22 22:23:07 --> Hooks Class Initialized
DEBUG - 2011-05-22 22:23:07 --> Utf8 Class Initialized
DEBUG - 2011-05-22 22:23:07 --> UTF-8 Support Enabled
DEBUG - 2011-05-22 22:23:07 --> URI Class Initialized
DEBUG - 2011-05-22 22:23:07 --> Router Class Initialized
DEBUG - 2011-05-22 22:23:07 --> No URI present. Default controller set.
DEBUG - 2011-05-22 22:23:07 --> Output Class Initialized
DEBUG - 2011-05-22 22:23:07 --> Input Class Initialized
DEBUG - 2011-05-22 22:23:07 --> Global POST and COOKIE data sanitized
DEBUG - 2011-05-22 22:23:07 --> Language Class Initialized
DEBUG - 2011-05-22 22:23:07 --> Loader Class Initialized
DEBUG - 2011-05-22 22:23:07 --> Controller Class Initialized
DEBUG - 2011-05-22 22:23:07 --> File loaded: application/views/splash/main.php
DEBUG - 2011-05-22 22:23:07 --> Helper loaded: url_helper
DEBUG - 2011-05-22 22:23:07 --> File loaded: application/views/common/header.php
DEBUG - 2011-05-22 22:23:07 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-05-22 22:23:07 --> File loaded: application/views/common/footer.php
DEBUG - 2011-05-22 22:23:07 --> File loaded: application/views/layout/main.php
DEBUG - 2011-05-22 22:23:07 --> Final output sent to browser
DEBUG - 2011-05-22 22:23:07 --> Total execution time: 0.2548

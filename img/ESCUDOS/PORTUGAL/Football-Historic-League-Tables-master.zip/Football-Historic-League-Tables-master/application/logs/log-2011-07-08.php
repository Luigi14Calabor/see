<?php  if ( ! defined('BASEPATH')) exit('No direct script access allowed'); ?>

DEBUG - 2011-07-08 00:35:32 --> Config Class Initialized
DEBUG - 2011-07-08 00:35:32 --> Hooks Class Initialized
DEBUG - 2011-07-08 00:35:32 --> Utf8 Class Initialized
DEBUG - 2011-07-08 00:35:32 --> UTF-8 Support Enabled
DEBUG - 2011-07-08 00:35:32 --> URI Class Initialized
DEBUG - 2011-07-08 00:35:32 --> Router Class Initialized
DEBUG - 2011-07-08 00:35:32 --> Output Class Initialized
DEBUG - 2011-07-08 00:35:32 --> Input Class Initialized
DEBUG - 2011-07-08 00:35:32 --> Global POST and COOKIE data sanitized
DEBUG - 2011-07-08 00:35:32 --> Language Class Initialized
DEBUG - 2011-07-08 00:35:32 --> Loader Class Initialized
DEBUG - 2011-07-08 00:35:32 --> Controller Class Initialized
ERROR - 2011-07-08 00:35:32 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-07-08 00:35:32 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-07-08 00:35:32 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-07-08 00:35:32 --> Model Class Initialized
DEBUG - 2011-07-08 00:35:32 --> Model Class Initialized
DEBUG - 2011-07-08 00:35:32 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-07-08 00:35:32 --> Database Driver Class Initialized
DEBUG - 2011-07-08 00:35:32 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-07-08 00:35:32 --> Helper loaded: url_helper
DEBUG - 2011-07-08 00:35:32 --> File loaded: application/views/common/header.php
DEBUG - 2011-07-08 00:35:32 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-07-08 00:35:32 --> File loaded: application/views/common/footer.php
DEBUG - 2011-07-08 00:35:32 --> File loaded: application/views/layout/main.php
DEBUG - 2011-07-08 00:35:32 --> Final output sent to browser
DEBUG - 2011-07-08 00:35:32 --> Total execution time: 0.3157
DEBUG - 2011-07-08 00:35:34 --> Config Class Initialized
DEBUG - 2011-07-08 00:35:34 --> Hooks Class Initialized
DEBUG - 2011-07-08 00:35:34 --> Utf8 Class Initialized
DEBUG - 2011-07-08 00:35:34 --> UTF-8 Support Enabled
DEBUG - 2011-07-08 00:35:34 --> URI Class Initialized
DEBUG - 2011-07-08 00:35:34 --> Router Class Initialized
DEBUG - 2011-07-08 00:35:34 --> Output Class Initialized
DEBUG - 2011-07-08 00:35:34 --> Input Class Initialized
DEBUG - 2011-07-08 00:35:34 --> Global POST and COOKIE data sanitized
DEBUG - 2011-07-08 00:35:34 --> Language Class Initialized
DEBUG - 2011-07-08 00:35:34 --> Loader Class Initialized
DEBUG - 2011-07-08 00:35:34 --> Controller Class Initialized
DEBUG - 2011-07-08 00:35:34 --> Model Class Initialized
DEBUG - 2011-07-08 00:35:34 --> Model Class Initialized
DEBUG - 2011-07-08 00:35:34 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-07-08 00:35:34 --> Database Driver Class Initialized
DEBUG - 2011-07-08 00:35:35 --> Final output sent to browser
DEBUG - 2011-07-08 00:35:35 --> Total execution time: 0.7913
DEBUG - 2011-07-08 01:30:22 --> Config Class Initialized
DEBUG - 2011-07-08 01:30:22 --> Hooks Class Initialized
DEBUG - 2011-07-08 01:30:22 --> Utf8 Class Initialized
DEBUG - 2011-07-08 01:30:22 --> UTF-8 Support Enabled
DEBUG - 2011-07-08 01:30:22 --> URI Class Initialized
DEBUG - 2011-07-08 01:30:22 --> Router Class Initialized
DEBUG - 2011-07-08 01:30:22 --> Output Class Initialized
DEBUG - 2011-07-08 01:30:22 --> Input Class Initialized
DEBUG - 2011-07-08 01:30:22 --> Global POST and COOKIE data sanitized
DEBUG - 2011-07-08 01:30:22 --> Language Class Initialized
DEBUG - 2011-07-08 01:30:23 --> Loader Class Initialized
DEBUG - 2011-07-08 01:30:23 --> Controller Class Initialized
ERROR - 2011-07-08 01:30:23 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-07-08 01:30:23 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-07-08 01:30:23 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-07-08 01:30:23 --> Model Class Initialized
DEBUG - 2011-07-08 01:30:23 --> Model Class Initialized
DEBUG - 2011-07-08 01:30:23 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-07-08 01:30:23 --> Database Driver Class Initialized
DEBUG - 2011-07-08 01:30:23 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-07-08 01:30:23 --> Helper loaded: url_helper
DEBUG - 2011-07-08 01:30:23 --> File loaded: application/views/common/header.php
DEBUG - 2011-07-08 01:30:23 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-07-08 01:30:23 --> File loaded: application/views/common/footer.php
DEBUG - 2011-07-08 01:30:23 --> File loaded: application/views/layout/main.php
DEBUG - 2011-07-08 01:30:23 --> Final output sent to browser
DEBUG - 2011-07-08 01:30:23 --> Total execution time: 0.3585
DEBUG - 2011-07-08 02:25:31 --> Config Class Initialized
DEBUG - 2011-07-08 02:25:31 --> Hooks Class Initialized
DEBUG - 2011-07-08 02:25:31 --> Utf8 Class Initialized
DEBUG - 2011-07-08 02:25:31 --> UTF-8 Support Enabled
DEBUG - 2011-07-08 02:25:31 --> URI Class Initialized
DEBUG - 2011-07-08 02:25:32 --> Router Class Initialized
DEBUG - 2011-07-08 02:25:32 --> Output Class Initialized
DEBUG - 2011-07-08 02:25:32 --> Input Class Initialized
DEBUG - 2011-07-08 02:25:32 --> Global POST and COOKIE data sanitized
DEBUG - 2011-07-08 02:25:32 --> Language Class Initialized
DEBUG - 2011-07-08 02:25:32 --> Loader Class Initialized
DEBUG - 2011-07-08 02:25:32 --> Controller Class Initialized
DEBUG - 2011-07-08 02:25:32 --> Model Class Initialized
DEBUG - 2011-07-08 02:25:32 --> Model Class Initialized
DEBUG - 2011-07-08 02:25:32 --> Model Class Initialized
DEBUG - 2011-07-08 02:25:32 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-07-08 02:25:32 --> Database Driver Class Initialized
DEBUG - 2011-07-08 02:25:42 --> File loaded: application/views/table/main.php
DEBUG - 2011-07-08 02:25:42 --> Helper loaded: url_helper
DEBUG - 2011-07-08 02:25:42 --> File loaded: application/views/common/header.php
DEBUG - 2011-07-08 02:25:42 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-07-08 02:25:42 --> File loaded: application/views/common/footer.php
DEBUG - 2011-07-08 02:25:42 --> File loaded: application/views/layout/main.php
DEBUG - 2011-07-08 02:25:42 --> Final output sent to browser
DEBUG - 2011-07-08 02:25:42 --> Total execution time: 10.3887
DEBUG - 2011-07-08 02:25:43 --> Config Class Initialized
DEBUG - 2011-07-08 02:25:43 --> Hooks Class Initialized
DEBUG - 2011-07-08 02:25:43 --> Utf8 Class Initialized
DEBUG - 2011-07-08 02:25:43 --> UTF-8 Support Enabled
DEBUG - 2011-07-08 02:25:43 --> URI Class Initialized
DEBUG - 2011-07-08 02:25:43 --> Router Class Initialized
DEBUG - 2011-07-08 02:25:43 --> Output Class Initialized
DEBUG - 2011-07-08 02:25:43 --> Input Class Initialized
DEBUG - 2011-07-08 02:25:43 --> Global POST and COOKIE data sanitized
DEBUG - 2011-07-08 02:25:43 --> Language Class Initialized
DEBUG - 2011-07-08 02:25:43 --> Loader Class Initialized
DEBUG - 2011-07-08 02:25:43 --> Controller Class Initialized
ERROR - 2011-07-08 02:25:43 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-07-08 02:25:43 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-07-08 02:25:43 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-07-08 02:25:43 --> Model Class Initialized
DEBUG - 2011-07-08 02:25:43 --> Model Class Initialized
DEBUG - 2011-07-08 02:25:43 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-07-08 02:25:43 --> Database Driver Class Initialized
DEBUG - 2011-07-08 02:25:43 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-07-08 02:25:43 --> Helper loaded: url_helper
DEBUG - 2011-07-08 02:25:43 --> File loaded: application/views/common/header.php
DEBUG - 2011-07-08 02:25:43 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-07-08 02:25:43 --> File loaded: application/views/common/footer.php
DEBUG - 2011-07-08 02:25:43 --> File loaded: application/views/layout/main.php
DEBUG - 2011-07-08 02:25:43 --> Final output sent to browser
DEBUG - 2011-07-08 02:25:43 --> Total execution time: 0.2227
DEBUG - 2011-07-08 03:18:17 --> Config Class Initialized
DEBUG - 2011-07-08 03:18:17 --> Hooks Class Initialized
DEBUG - 2011-07-08 03:18:17 --> Utf8 Class Initialized
DEBUG - 2011-07-08 03:18:17 --> UTF-8 Support Enabled
DEBUG - 2011-07-08 03:18:17 --> URI Class Initialized
DEBUG - 2011-07-08 03:18:17 --> Router Class Initialized
DEBUG - 2011-07-08 03:18:17 --> Output Class Initialized
DEBUG - 2011-07-08 03:18:17 --> Input Class Initialized
DEBUG - 2011-07-08 03:18:17 --> Global POST and COOKIE data sanitized
DEBUG - 2011-07-08 03:18:17 --> Language Class Initialized
DEBUG - 2011-07-08 03:18:17 --> Loader Class Initialized
DEBUG - 2011-07-08 03:18:17 --> Controller Class Initialized
DEBUG - 2011-07-08 03:18:17 --> Model Class Initialized
DEBUG - 2011-07-08 03:18:17 --> Model Class Initialized
DEBUG - 2011-07-08 03:18:17 --> Model Class Initialized
DEBUG - 2011-07-08 03:18:17 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-07-08 03:18:17 --> Database Driver Class Initialized
DEBUG - 2011-07-08 03:18:20 --> File loaded: application/views/table/main.php
DEBUG - 2011-07-08 03:18:20 --> Helper loaded: url_helper
DEBUG - 2011-07-08 03:18:20 --> File loaded: application/views/common/header.php
DEBUG - 2011-07-08 03:18:20 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-07-08 03:18:20 --> File loaded: application/views/common/footer.php
DEBUG - 2011-07-08 03:18:20 --> File loaded: application/views/layout/main.php
DEBUG - 2011-07-08 03:18:20 --> Final output sent to browser
DEBUG - 2011-07-08 03:18:20 --> Total execution time: 2.5553
DEBUG - 2011-07-08 03:18:24 --> Config Class Initialized
DEBUG - 2011-07-08 03:18:24 --> Hooks Class Initialized
DEBUG - 2011-07-08 03:18:24 --> Utf8 Class Initialized
DEBUG - 2011-07-08 03:18:24 --> UTF-8 Support Enabled
DEBUG - 2011-07-08 03:18:24 --> URI Class Initialized
DEBUG - 2011-07-08 03:18:24 --> Router Class Initialized
DEBUG - 2011-07-08 03:18:24 --> Output Class Initialized
DEBUG - 2011-07-08 03:18:24 --> Input Class Initialized
DEBUG - 2011-07-08 03:18:24 --> Global POST and COOKIE data sanitized
DEBUG - 2011-07-08 03:18:24 --> Language Class Initialized
DEBUG - 2011-07-08 03:18:24 --> Loader Class Initialized
DEBUG - 2011-07-08 03:18:24 --> Controller Class Initialized
ERROR - 2011-07-08 03:18:24 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-07-08 03:18:24 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-07-08 03:18:24 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-07-08 03:18:24 --> Model Class Initialized
DEBUG - 2011-07-08 03:18:24 --> Model Class Initialized
DEBUG - 2011-07-08 03:18:24 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-07-08 03:18:24 --> Database Driver Class Initialized
DEBUG - 2011-07-08 03:18:24 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-07-08 03:18:24 --> Helper loaded: url_helper
DEBUG - 2011-07-08 03:18:24 --> File loaded: application/views/common/header.php
DEBUG - 2011-07-08 03:18:24 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-07-08 03:18:24 --> File loaded: application/views/common/footer.php
DEBUG - 2011-07-08 03:18:24 --> File loaded: application/views/layout/main.php
DEBUG - 2011-07-08 03:18:24 --> Final output sent to browser
DEBUG - 2011-07-08 03:18:24 --> Total execution time: 0.0835
DEBUG - 2011-07-08 04:02:44 --> Config Class Initialized
DEBUG - 2011-07-08 04:02:44 --> Hooks Class Initialized
DEBUG - 2011-07-08 04:02:44 --> Utf8 Class Initialized
DEBUG - 2011-07-08 04:02:44 --> UTF-8 Support Enabled
DEBUG - 2011-07-08 04:02:44 --> URI Class Initialized
DEBUG - 2011-07-08 04:02:44 --> Router Class Initialized
DEBUG - 2011-07-08 04:02:44 --> Output Class Initialized
DEBUG - 2011-07-08 04:02:44 --> Input Class Initialized
DEBUG - 2011-07-08 04:02:44 --> Global POST and COOKIE data sanitized
DEBUG - 2011-07-08 04:02:44 --> Language Class Initialized
DEBUG - 2011-07-08 04:02:44 --> Loader Class Initialized
DEBUG - 2011-07-08 04:02:44 --> Controller Class Initialized
DEBUG - 2011-07-08 04:02:44 --> Model Class Initialized
DEBUG - 2011-07-08 04:02:44 --> Model Class Initialized
DEBUG - 2011-07-08 04:02:44 --> Model Class Initialized
DEBUG - 2011-07-08 04:02:44 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-07-08 04:02:44 --> Database Driver Class Initialized
DEBUG - 2011-07-08 04:02:46 --> File loaded: application/views/table/main.php
DEBUG - 2011-07-08 04:02:46 --> Helper loaded: url_helper
DEBUG - 2011-07-08 04:02:46 --> File loaded: application/views/common/header.php
DEBUG - 2011-07-08 04:02:46 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-07-08 04:02:46 --> File loaded: application/views/common/footer.php
DEBUG - 2011-07-08 04:02:46 --> File loaded: application/views/layout/main.php
DEBUG - 2011-07-08 04:02:46 --> Final output sent to browser
DEBUG - 2011-07-08 04:02:46 --> Total execution time: 1.8739
DEBUG - 2011-07-08 04:02:49 --> Config Class Initialized
DEBUG - 2011-07-08 04:02:49 --> Hooks Class Initialized
DEBUG - 2011-07-08 04:02:49 --> Utf8 Class Initialized
DEBUG - 2011-07-08 04:02:49 --> UTF-8 Support Enabled
DEBUG - 2011-07-08 04:02:49 --> URI Class Initialized
DEBUG - 2011-07-08 04:02:49 --> Router Class Initialized
ERROR - 2011-07-08 04:02:49 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-07-08 04:02:50 --> Config Class Initialized
DEBUG - 2011-07-08 04:02:50 --> Hooks Class Initialized
DEBUG - 2011-07-08 04:02:50 --> Utf8 Class Initialized
DEBUG - 2011-07-08 04:02:50 --> UTF-8 Support Enabled
DEBUG - 2011-07-08 04:02:50 --> URI Class Initialized
DEBUG - 2011-07-08 04:02:50 --> Router Class Initialized
DEBUG - 2011-07-08 04:02:50 --> Output Class Initialized
DEBUG - 2011-07-08 04:02:50 --> Input Class Initialized
DEBUG - 2011-07-08 04:02:50 --> Global POST and COOKIE data sanitized
DEBUG - 2011-07-08 04:02:50 --> Language Class Initialized
DEBUG - 2011-07-08 04:02:50 --> Loader Class Initialized
DEBUG - 2011-07-08 04:02:50 --> Controller Class Initialized
DEBUG - 2011-07-08 04:02:50 --> Model Class Initialized
DEBUG - 2011-07-08 04:02:50 --> Model Class Initialized
DEBUG - 2011-07-08 04:02:50 --> Model Class Initialized
DEBUG - 2011-07-08 04:02:50 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-07-08 04:02:50 --> Database Driver Class Initialized
DEBUG - 2011-07-08 04:02:50 --> File loaded: application/views/table/main.php
DEBUG - 2011-07-08 04:02:50 --> Helper loaded: url_helper
DEBUG - 2011-07-08 04:02:50 --> File loaded: application/views/common/header.php
DEBUG - 2011-07-08 04:02:50 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-07-08 04:02:50 --> File loaded: application/views/common/footer.php
DEBUG - 2011-07-08 04:02:50 --> File loaded: application/views/layout/main.php
DEBUG - 2011-07-08 04:02:50 --> Final output sent to browser
DEBUG - 2011-07-08 04:02:50 --> Total execution time: 0.0492
DEBUG - 2011-07-08 04:02:55 --> Config Class Initialized
DEBUG - 2011-07-08 04:02:55 --> Hooks Class Initialized
DEBUG - 2011-07-08 04:02:55 --> Utf8 Class Initialized
DEBUG - 2011-07-08 04:02:55 --> UTF-8 Support Enabled
DEBUG - 2011-07-08 04:02:55 --> URI Class Initialized
DEBUG - 2011-07-08 04:02:55 --> Router Class Initialized
ERROR - 2011-07-08 04:02:55 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-07-08 04:04:52 --> Config Class Initialized
DEBUG - 2011-07-08 04:04:52 --> Hooks Class Initialized
DEBUG - 2011-07-08 04:04:52 --> Utf8 Class Initialized
DEBUG - 2011-07-08 04:04:52 --> UTF-8 Support Enabled
DEBUG - 2011-07-08 04:04:52 --> URI Class Initialized
DEBUG - 2011-07-08 04:04:52 --> Router Class Initialized
DEBUG - 2011-07-08 04:04:52 --> Output Class Initialized
DEBUG - 2011-07-08 04:04:52 --> Input Class Initialized
DEBUG - 2011-07-08 04:04:52 --> Global POST and COOKIE data sanitized
DEBUG - 2011-07-08 04:04:52 --> Language Class Initialized
DEBUG - 2011-07-08 04:04:52 --> Loader Class Initialized
DEBUG - 2011-07-08 04:04:52 --> Controller Class Initialized
DEBUG - 2011-07-08 04:04:52 --> Model Class Initialized
DEBUG - 2011-07-08 04:04:52 --> Model Class Initialized
DEBUG - 2011-07-08 04:04:52 --> Model Class Initialized
DEBUG - 2011-07-08 04:04:52 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-07-08 04:04:52 --> Database Driver Class Initialized
DEBUG - 2011-07-08 04:04:52 --> File loaded: application/views/table/main.php
DEBUG - 2011-07-08 04:04:52 --> Helper loaded: url_helper
DEBUG - 2011-07-08 04:04:52 --> File loaded: application/views/common/header.php
DEBUG - 2011-07-08 04:04:52 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-07-08 04:04:52 --> File loaded: application/views/common/footer.php
DEBUG - 2011-07-08 04:04:52 --> File loaded: application/views/layout/main.php
DEBUG - 2011-07-08 04:04:52 --> Final output sent to browser
DEBUG - 2011-07-08 04:04:52 --> Total execution time: 0.0571
DEBUG - 2011-07-08 04:04:54 --> Config Class Initialized
DEBUG - 2011-07-08 04:04:54 --> Hooks Class Initialized
DEBUG - 2011-07-08 04:04:54 --> Utf8 Class Initialized
DEBUG - 2011-07-08 04:04:54 --> UTF-8 Support Enabled
DEBUG - 2011-07-08 04:04:54 --> URI Class Initialized
DEBUG - 2011-07-08 04:04:54 --> Router Class Initialized
ERROR - 2011-07-08 04:04:54 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-07-08 04:04:55 --> Config Class Initialized
DEBUG - 2011-07-08 04:04:55 --> Hooks Class Initialized
DEBUG - 2011-07-08 04:04:55 --> Utf8 Class Initialized
DEBUG - 2011-07-08 04:04:55 --> UTF-8 Support Enabled
DEBUG - 2011-07-08 04:04:55 --> URI Class Initialized
DEBUG - 2011-07-08 04:04:55 --> Router Class Initialized
DEBUG - 2011-07-08 04:04:55 --> Output Class Initialized
DEBUG - 2011-07-08 04:04:55 --> Input Class Initialized
DEBUG - 2011-07-08 04:04:55 --> Global POST and COOKIE data sanitized
DEBUG - 2011-07-08 04:04:55 --> Language Class Initialized
DEBUG - 2011-07-08 04:04:55 --> Loader Class Initialized
DEBUG - 2011-07-08 04:04:55 --> Controller Class Initialized
DEBUG - 2011-07-08 04:04:55 --> Model Class Initialized
DEBUG - 2011-07-08 04:04:55 --> Model Class Initialized
DEBUG - 2011-07-08 04:04:55 --> Model Class Initialized
DEBUG - 2011-07-08 04:04:55 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-07-08 04:04:55 --> Database Driver Class Initialized
DEBUG - 2011-07-08 04:04:55 --> File loaded: application/views/table/main.php
DEBUG - 2011-07-08 04:04:55 --> Helper loaded: url_helper
DEBUG - 2011-07-08 04:04:55 --> File loaded: application/views/common/header.php
DEBUG - 2011-07-08 04:04:55 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-07-08 04:04:55 --> File loaded: application/views/common/footer.php
DEBUG - 2011-07-08 04:04:55 --> File loaded: application/views/layout/main.php
DEBUG - 2011-07-08 04:04:55 --> Final output sent to browser
DEBUG - 2011-07-08 04:04:55 --> Total execution time: 0.1623
DEBUG - 2011-07-08 04:05:00 --> Config Class Initialized
DEBUG - 2011-07-08 04:05:00 --> Hooks Class Initialized
DEBUG - 2011-07-08 04:05:00 --> Utf8 Class Initialized
DEBUG - 2011-07-08 04:05:00 --> UTF-8 Support Enabled
DEBUG - 2011-07-08 04:05:00 --> URI Class Initialized
DEBUG - 2011-07-08 04:05:00 --> Router Class Initialized
ERROR - 2011-07-08 04:05:00 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-07-08 04:06:33 --> Config Class Initialized
DEBUG - 2011-07-08 04:06:33 --> Hooks Class Initialized
DEBUG - 2011-07-08 04:06:33 --> Utf8 Class Initialized
DEBUG - 2011-07-08 04:06:33 --> UTF-8 Support Enabled
DEBUG - 2011-07-08 04:06:33 --> URI Class Initialized
DEBUG - 2011-07-08 04:06:33 --> Router Class Initialized
DEBUG - 2011-07-08 04:06:33 --> Output Class Initialized
DEBUG - 2011-07-08 04:06:33 --> Input Class Initialized
DEBUG - 2011-07-08 04:06:33 --> Global POST and COOKIE data sanitized
DEBUG - 2011-07-08 04:06:33 --> Language Class Initialized
DEBUG - 2011-07-08 04:06:33 --> Loader Class Initialized
DEBUG - 2011-07-08 04:06:33 --> Controller Class Initialized
DEBUG - 2011-07-08 04:06:33 --> Model Class Initialized
DEBUG - 2011-07-08 04:06:33 --> Model Class Initialized
DEBUG - 2011-07-08 04:06:33 --> Model Class Initialized
DEBUG - 2011-07-08 04:06:33 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-07-08 04:06:34 --> Database Driver Class Initialized
DEBUG - 2011-07-08 04:06:34 --> File loaded: application/views/table/main.php
DEBUG - 2011-07-08 04:06:34 --> Helper loaded: url_helper
DEBUG - 2011-07-08 04:06:34 --> File loaded: application/views/common/header.php
DEBUG - 2011-07-08 04:06:34 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-07-08 04:06:34 --> File loaded: application/views/common/footer.php
DEBUG - 2011-07-08 04:06:34 --> File loaded: application/views/layout/main.php
DEBUG - 2011-07-08 04:06:34 --> Final output sent to browser
DEBUG - 2011-07-08 04:06:34 --> Total execution time: 0.1144
DEBUG - 2011-07-08 04:26:42 --> Config Class Initialized
DEBUG - 2011-07-08 04:26:42 --> Hooks Class Initialized
DEBUG - 2011-07-08 04:26:42 --> Utf8 Class Initialized
DEBUG - 2011-07-08 04:26:42 --> UTF-8 Support Enabled
DEBUG - 2011-07-08 04:26:42 --> URI Class Initialized
DEBUG - 2011-07-08 04:26:42 --> Router Class Initialized
ERROR - 2011-07-08 04:26:42 --> 404 Page Not Found --> robots.txt
DEBUG - 2011-07-08 04:26:42 --> Config Class Initialized
DEBUG - 2011-07-08 04:26:42 --> Hooks Class Initialized
DEBUG - 2011-07-08 04:26:42 --> Utf8 Class Initialized
DEBUG - 2011-07-08 04:26:42 --> UTF-8 Support Enabled
DEBUG - 2011-07-08 04:26:42 --> URI Class Initialized
DEBUG - 2011-07-08 04:26:42 --> Router Class Initialized
DEBUG - 2011-07-08 04:26:42 --> Output Class Initialized
DEBUG - 2011-07-08 04:26:42 --> Input Class Initialized
DEBUG - 2011-07-08 04:26:42 --> Global POST and COOKIE data sanitized
DEBUG - 2011-07-08 04:26:42 --> Language Class Initialized
DEBUG - 2011-07-08 04:26:42 --> Loader Class Initialized
DEBUG - 2011-07-08 04:26:42 --> Controller Class Initialized
DEBUG - 2011-07-08 04:26:42 --> Model Class Initialized
DEBUG - 2011-07-08 04:26:42 --> Model Class Initialized
DEBUG - 2011-07-08 04:26:42 --> Model Class Initialized
DEBUG - 2011-07-08 04:26:42 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-07-08 04:26:42 --> Database Driver Class Initialized
DEBUG - 2011-07-08 04:26:43 --> File loaded: application/views/table/main.php
DEBUG - 2011-07-08 04:26:43 --> Helper loaded: url_helper
DEBUG - 2011-07-08 04:26:43 --> File loaded: application/views/common/header.php
DEBUG - 2011-07-08 04:26:43 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-07-08 04:26:43 --> File loaded: application/views/common/footer.php
DEBUG - 2011-07-08 04:26:43 --> File loaded: application/views/layout/main.php
DEBUG - 2011-07-08 04:26:43 --> Final output sent to browser
DEBUG - 2011-07-08 04:26:43 --> Total execution time: 0.2705
DEBUG - 2011-07-08 04:32:32 --> Config Class Initialized
DEBUG - 2011-07-08 04:32:32 --> Hooks Class Initialized
DEBUG - 2011-07-08 04:32:32 --> Utf8 Class Initialized
DEBUG - 2011-07-08 04:32:32 --> UTF-8 Support Enabled
DEBUG - 2011-07-08 04:32:32 --> URI Class Initialized
DEBUG - 2011-07-08 04:32:32 --> Router Class Initialized
DEBUG - 2011-07-08 04:32:32 --> Output Class Initialized
DEBUG - 2011-07-08 04:32:32 --> Input Class Initialized
DEBUG - 2011-07-08 04:32:32 --> Global POST and COOKIE data sanitized
DEBUG - 2011-07-08 04:32:32 --> Language Class Initialized
DEBUG - 2011-07-08 04:32:32 --> Loader Class Initialized
DEBUG - 2011-07-08 04:32:32 --> Controller Class Initialized
DEBUG - 2011-07-08 04:32:32 --> Model Class Initialized
DEBUG - 2011-07-08 04:32:32 --> Model Class Initialized
DEBUG - 2011-07-08 04:32:32 --> Model Class Initialized
DEBUG - 2011-07-08 04:32:32 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-07-08 04:32:32 --> Database Driver Class Initialized
DEBUG - 2011-07-08 04:32:32 --> File loaded: application/views/table/main.php
DEBUG - 2011-07-08 04:32:32 --> Helper loaded: url_helper
DEBUG - 2011-07-08 04:32:32 --> File loaded: application/views/common/header.php
DEBUG - 2011-07-08 04:32:32 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-07-08 04:32:32 --> File loaded: application/views/common/footer.php
DEBUG - 2011-07-08 04:32:32 --> File loaded: application/views/layout/main.php
DEBUG - 2011-07-08 04:32:32 --> Final output sent to browser
DEBUG - 2011-07-08 04:32:32 --> Total execution time: 0.2501
DEBUG - 2011-07-08 04:32:34 --> Config Class Initialized
DEBUG - 2011-07-08 04:32:34 --> Hooks Class Initialized
DEBUG - 2011-07-08 04:32:34 --> Utf8 Class Initialized
DEBUG - 2011-07-08 04:32:34 --> UTF-8 Support Enabled
DEBUG - 2011-07-08 04:32:34 --> URI Class Initialized
DEBUG - 2011-07-08 04:32:34 --> Router Class Initialized
DEBUG - 2011-07-08 04:32:34 --> Output Class Initialized
DEBUG - 2011-07-08 04:32:34 --> Input Class Initialized
DEBUG - 2011-07-08 04:32:34 --> Global POST and COOKIE data sanitized
DEBUG - 2011-07-08 04:32:34 --> Language Class Initialized
DEBUG - 2011-07-08 04:32:34 --> Loader Class Initialized
DEBUG - 2011-07-08 04:32:34 --> Controller Class Initialized
ERROR - 2011-07-08 04:32:34 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-07-08 04:32:34 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-07-08 04:32:34 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-07-08 04:32:34 --> Model Class Initialized
DEBUG - 2011-07-08 04:32:34 --> Model Class Initialized
DEBUG - 2011-07-08 04:32:34 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-07-08 04:32:34 --> Database Driver Class Initialized
DEBUG - 2011-07-08 04:32:34 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-07-08 04:32:34 --> Helper loaded: url_helper
DEBUG - 2011-07-08 04:32:34 --> File loaded: application/views/common/header.php
DEBUG - 2011-07-08 04:32:34 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-07-08 04:32:34 --> File loaded: application/views/common/footer.php
DEBUG - 2011-07-08 04:32:34 --> File loaded: application/views/layout/main.php
DEBUG - 2011-07-08 04:32:34 --> Final output sent to browser
DEBUG - 2011-07-08 04:32:34 --> Total execution time: 0.0928
DEBUG - 2011-07-08 06:02:26 --> Config Class Initialized
DEBUG - 2011-07-08 06:02:26 --> Config Class Initialized
DEBUG - 2011-07-08 06:02:26 --> Hooks Class Initialized
DEBUG - 2011-07-08 06:02:26 --> Hooks Class Initialized
DEBUG - 2011-07-08 06:02:26 --> Utf8 Class Initialized
DEBUG - 2011-07-08 06:02:26 --> Utf8 Class Initialized
DEBUG - 2011-07-08 06:02:26 --> UTF-8 Support Enabled
DEBUG - 2011-07-08 06:02:26 --> UTF-8 Support Enabled
DEBUG - 2011-07-08 06:02:26 --> URI Class Initialized
DEBUG - 2011-07-08 06:02:26 --> URI Class Initialized
DEBUG - 2011-07-08 06:02:26 --> Router Class Initialized
DEBUG - 2011-07-08 06:02:26 --> Router Class Initialized
DEBUG - 2011-07-08 06:02:26 --> Output Class Initialized
DEBUG - 2011-07-08 06:02:26 --> Output Class Initialized
DEBUG - 2011-07-08 06:02:26 --> Input Class Initialized
DEBUG - 2011-07-08 06:02:26 --> Input Class Initialized
DEBUG - 2011-07-08 06:02:26 --> Global POST and COOKIE data sanitized
DEBUG - 2011-07-08 06:02:26 --> Global POST and COOKIE data sanitized
DEBUG - 2011-07-08 06:02:26 --> Language Class Initialized
DEBUG - 2011-07-08 06:02:26 --> Language Class Initialized
DEBUG - 2011-07-08 06:02:26 --> Loader Class Initialized
DEBUG - 2011-07-08 06:02:26 --> Loader Class Initialized
DEBUG - 2011-07-08 06:02:26 --> Controller Class Initialized
DEBUG - 2011-07-08 06:02:26 --> Controller Class Initialized
DEBUG - 2011-07-08 06:02:26 --> Model Class Initialized
DEBUG - 2011-07-08 06:02:26 --> Model Class Initialized
ERROR - 2011-07-08 06:02:26 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-07-08 06:02:26 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-07-08 06:02:26 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-07-08 06:02:26 --> Model Class Initialized
DEBUG - 2011-07-08 06:02:26 --> Model Class Initialized
DEBUG - 2011-07-08 06:02:26 --> Model Class Initialized
DEBUG - 2011-07-08 06:02:26 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-07-08 06:02:26 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-07-08 06:02:26 --> Database Driver Class Initialized
DEBUG - 2011-07-08 06:02:26 --> Database Driver Class Initialized
DEBUG - 2011-07-08 06:02:27 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-07-08 06:02:27 --> Helper loaded: url_helper
DEBUG - 2011-07-08 06:02:27 --> File loaded: application/views/common/header.php
DEBUG - 2011-07-08 06:02:27 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-07-08 06:02:27 --> File loaded: application/views/common/footer.php
DEBUG - 2011-07-08 06:02:27 --> File loaded: application/views/layout/main.php
DEBUG - 2011-07-08 06:02:27 --> Final output sent to browser
DEBUG - 2011-07-08 06:02:27 --> Total execution time: 0.9226
DEBUG - 2011-07-08 06:02:27 --> File loaded: application/views/table/main.php
DEBUG - 2011-07-08 06:02:27 --> Helper loaded: url_helper
DEBUG - 2011-07-08 06:02:27 --> File loaded: application/views/common/header.php
DEBUG - 2011-07-08 06:02:27 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-07-08 06:02:27 --> File loaded: application/views/common/footer.php
DEBUG - 2011-07-08 06:02:27 --> File loaded: application/views/layout/main.php
DEBUG - 2011-07-08 06:02:27 --> Final output sent to browser
DEBUG - 2011-07-08 06:02:27 --> Total execution time: 1.0718
DEBUG - 2011-07-08 06:05:49 --> Config Class Initialized
DEBUG - 2011-07-08 06:05:49 --> Hooks Class Initialized
DEBUG - 2011-07-08 06:05:49 --> Utf8 Class Initialized
DEBUG - 2011-07-08 06:05:49 --> UTF-8 Support Enabled
DEBUG - 2011-07-08 06:05:49 --> URI Class Initialized
DEBUG - 2011-07-08 06:05:49 --> Router Class Initialized
ERROR - 2011-07-08 06:05:49 --> 404 Page Not Found --> robots.txt
DEBUG - 2011-07-08 06:11:00 --> Config Class Initialized
DEBUG - 2011-07-08 06:11:00 --> Hooks Class Initialized
DEBUG - 2011-07-08 06:11:00 --> Utf8 Class Initialized
DEBUG - 2011-07-08 06:11:00 --> UTF-8 Support Enabled
DEBUG - 2011-07-08 06:11:00 --> URI Class Initialized
DEBUG - 2011-07-08 06:11:00 --> Router Class Initialized
DEBUG - 2011-07-08 06:11:00 --> Output Class Initialized
DEBUG - 2011-07-08 06:11:00 --> Input Class Initialized
DEBUG - 2011-07-08 06:11:00 --> Global POST and COOKIE data sanitized
DEBUG - 2011-07-08 06:11:00 --> Language Class Initialized
DEBUG - 2011-07-08 06:11:00 --> Loader Class Initialized
DEBUG - 2011-07-08 06:11:00 --> Controller Class Initialized
ERROR - 2011-07-08 06:11:01 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-07-08 06:11:01 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-07-08 06:11:01 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-07-08 06:11:01 --> Model Class Initialized
DEBUG - 2011-07-08 06:11:01 --> Model Class Initialized
DEBUG - 2011-07-08 06:11:01 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-07-08 06:11:01 --> Database Driver Class Initialized
DEBUG - 2011-07-08 06:11:01 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-07-08 06:11:01 --> Helper loaded: url_helper
DEBUG - 2011-07-08 06:11:01 --> File loaded: application/views/common/header.php
DEBUG - 2011-07-08 06:11:01 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-07-08 06:11:01 --> File loaded: application/views/common/footer.php
DEBUG - 2011-07-08 06:11:01 --> File loaded: application/views/layout/main.php
DEBUG - 2011-07-08 06:11:01 --> Final output sent to browser
DEBUG - 2011-07-08 06:11:01 --> Total execution time: 0.3910
DEBUG - 2011-07-08 06:23:05 --> Config Class Initialized
DEBUG - 2011-07-08 06:23:05 --> Hooks Class Initialized
DEBUG - 2011-07-08 06:23:05 --> Utf8 Class Initialized
DEBUG - 2011-07-08 06:23:05 --> UTF-8 Support Enabled
DEBUG - 2011-07-08 06:23:05 --> URI Class Initialized
DEBUG - 2011-07-08 06:23:05 --> Router Class Initialized
DEBUG - 2011-07-08 06:23:05 --> Output Class Initialized
DEBUG - 2011-07-08 06:23:05 --> Input Class Initialized
DEBUG - 2011-07-08 06:23:05 --> Global POST and COOKIE data sanitized
DEBUG - 2011-07-08 06:23:05 --> Language Class Initialized
DEBUG - 2011-07-08 06:23:05 --> Loader Class Initialized
DEBUG - 2011-07-08 06:23:05 --> Controller Class Initialized
DEBUG - 2011-07-08 06:23:05 --> Model Class Initialized
DEBUG - 2011-07-08 06:23:05 --> Model Class Initialized
DEBUG - 2011-07-08 06:23:05 --> Model Class Initialized
DEBUG - 2011-07-08 06:23:05 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-07-08 06:23:05 --> Database Driver Class Initialized
DEBUG - 2011-07-08 06:23:05 --> File loaded: application/views/table/main.php
DEBUG - 2011-07-08 06:23:05 --> Helper loaded: url_helper
DEBUG - 2011-07-08 06:23:05 --> File loaded: application/views/common/header.php
DEBUG - 2011-07-08 06:23:05 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-07-08 06:23:05 --> File loaded: application/views/common/footer.php
DEBUG - 2011-07-08 06:23:05 --> File loaded: application/views/layout/main.php
DEBUG - 2011-07-08 06:23:05 --> Final output sent to browser
DEBUG - 2011-07-08 06:23:05 --> Total execution time: 0.3274
DEBUG - 2011-07-08 06:23:15 --> Config Class Initialized
DEBUG - 2011-07-08 06:23:15 --> Hooks Class Initialized
DEBUG - 2011-07-08 06:23:15 --> Utf8 Class Initialized
DEBUG - 2011-07-08 06:23:15 --> UTF-8 Support Enabled
DEBUG - 2011-07-08 06:23:15 --> Config Class Initialized
DEBUG - 2011-07-08 06:23:15 --> Hooks Class Initialized
DEBUG - 2011-07-08 06:23:15 --> Utf8 Class Initialized
DEBUG - 2011-07-08 06:23:15 --> URI Class Initialized
DEBUG - 2011-07-08 06:23:15 --> UTF-8 Support Enabled
DEBUG - 2011-07-08 06:23:15 --> Router Class Initialized
DEBUG - 2011-07-08 06:23:15 --> URI Class Initialized
DEBUG - 2011-07-08 06:23:15 --> Router Class Initialized
DEBUG - 2011-07-08 06:23:15 --> Output Class Initialized
DEBUG - 2011-07-08 06:23:15 --> Input Class Initialized
DEBUG - 2011-07-08 06:23:15 --> Global POST and COOKIE data sanitized
DEBUG - 2011-07-08 06:23:15 --> Language Class Initialized
DEBUG - 2011-07-08 06:23:15 --> Loader Class Initialized
DEBUG - 2011-07-08 06:23:15 --> Controller Class Initialized
DEBUG - 2011-07-08 06:23:15 --> Model Class Initialized
DEBUG - 2011-07-08 06:23:15 --> Model Class Initialized
ERROR - 2011-07-08 06:23:15 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-07-08 06:23:15 --> Model Class Initialized
DEBUG - 2011-07-08 06:23:15 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-07-08 06:23:15 --> Database Driver Class Initialized
DEBUG - 2011-07-08 06:23:15 --> Config Class Initialized
DEBUG - 2011-07-08 06:23:15 --> Hooks Class Initialized
DEBUG - 2011-07-08 06:23:15 --> Utf8 Class Initialized
DEBUG - 2011-07-08 06:23:15 --> UTF-8 Support Enabled
DEBUG - 2011-07-08 06:23:15 --> URI Class Initialized
DEBUG - 2011-07-08 06:23:15 --> Router Class Initialized
ERROR - 2011-07-08 06:23:15 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-07-08 06:23:15 --> File loaded: application/views/table/main.php
DEBUG - 2011-07-08 06:23:15 --> Helper loaded: url_helper
DEBUG - 2011-07-08 06:23:15 --> File loaded: application/views/common/header.php
DEBUG - 2011-07-08 06:23:15 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-07-08 06:23:15 --> File loaded: application/views/common/footer.php
DEBUG - 2011-07-08 06:23:15 --> File loaded: application/views/layout/main.php
DEBUG - 2011-07-08 06:23:15 --> Final output sent to browser
DEBUG - 2011-07-08 06:23:15 --> Total execution time: 0.3989
DEBUG - 2011-07-08 06:23:17 --> Config Class Initialized
DEBUG - 2011-07-08 06:23:17 --> Hooks Class Initialized
DEBUG - 2011-07-08 06:23:17 --> Utf8 Class Initialized
DEBUG - 2011-07-08 06:23:17 --> UTF-8 Support Enabled
DEBUG - 2011-07-08 06:23:17 --> URI Class Initialized
DEBUG - 2011-07-08 06:23:17 --> Router Class Initialized
ERROR - 2011-07-08 06:23:17 --> 404 Page Not Found --> robots.txt
DEBUG - 2011-07-08 06:23:17 --> Config Class Initialized
DEBUG - 2011-07-08 06:23:17 --> Hooks Class Initialized
DEBUG - 2011-07-08 06:23:17 --> Utf8 Class Initialized
DEBUG - 2011-07-08 06:23:17 --> UTF-8 Support Enabled
DEBUG - 2011-07-08 06:23:17 --> URI Class Initialized
DEBUG - 2011-07-08 06:23:17 --> Router Class Initialized
DEBUG - 2011-07-08 06:23:17 --> Output Class Initialized
DEBUG - 2011-07-08 06:23:17 --> Input Class Initialized
DEBUG - 2011-07-08 06:23:17 --> Global POST and COOKIE data sanitized
DEBUG - 2011-07-08 06:23:17 --> Language Class Initialized
DEBUG - 2011-07-08 06:23:17 --> Loader Class Initialized
DEBUG - 2011-07-08 06:23:17 --> Controller Class Initialized
DEBUG - 2011-07-08 06:23:17 --> Model Class Initialized
DEBUG - 2011-07-08 06:23:17 --> Model Class Initialized
DEBUG - 2011-07-08 06:23:17 --> Model Class Initialized
DEBUG - 2011-07-08 06:23:17 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-07-08 06:23:17 --> Database Driver Class Initialized
DEBUG - 2011-07-08 06:23:17 --> File loaded: application/views/table/main.php
DEBUG - 2011-07-08 06:23:17 --> Helper loaded: url_helper
DEBUG - 2011-07-08 06:23:17 --> File loaded: application/views/common/header.php
DEBUG - 2011-07-08 06:23:17 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-07-08 06:23:17 --> File loaded: application/views/common/footer.php
DEBUG - 2011-07-08 06:23:17 --> File loaded: application/views/layout/main.php
DEBUG - 2011-07-08 06:23:17 --> Final output sent to browser
DEBUG - 2011-07-08 06:23:17 --> Total execution time: 0.0470
DEBUG - 2011-07-08 06:23:19 --> Config Class Initialized
DEBUG - 2011-07-08 06:23:19 --> Hooks Class Initialized
DEBUG - 2011-07-08 06:23:19 --> Utf8 Class Initialized
DEBUG - 2011-07-08 06:23:19 --> UTF-8 Support Enabled
DEBUG - 2011-07-08 06:23:19 --> URI Class Initialized
DEBUG - 2011-07-08 06:23:19 --> Router Class Initialized
ERROR - 2011-07-08 06:23:19 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-07-08 06:23:19 --> Config Class Initialized
DEBUG - 2011-07-08 06:23:19 --> Hooks Class Initialized
DEBUG - 2011-07-08 06:23:19 --> Utf8 Class Initialized
DEBUG - 2011-07-08 06:23:19 --> UTF-8 Support Enabled
DEBUG - 2011-07-08 06:23:19 --> URI Class Initialized
DEBUG - 2011-07-08 06:23:19 --> Router Class Initialized
ERROR - 2011-07-08 06:23:19 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-07-08 06:23:24 --> Config Class Initialized
DEBUG - 2011-07-08 06:23:24 --> Hooks Class Initialized
DEBUG - 2011-07-08 06:23:24 --> Utf8 Class Initialized
DEBUG - 2011-07-08 06:23:24 --> UTF-8 Support Enabled
DEBUG - 2011-07-08 06:23:24 --> URI Class Initialized
DEBUG - 2011-07-08 06:23:24 --> Router Class Initialized
DEBUG - 2011-07-08 06:23:24 --> Output Class Initialized
DEBUG - 2011-07-08 06:23:24 --> Input Class Initialized
DEBUG - 2011-07-08 06:23:24 --> Global POST and COOKIE data sanitized
DEBUG - 2011-07-08 06:23:24 --> Language Class Initialized
DEBUG - 2011-07-08 06:23:24 --> Loader Class Initialized
DEBUG - 2011-07-08 06:23:24 --> Controller Class Initialized
DEBUG - 2011-07-08 06:23:24 --> Model Class Initialized
DEBUG - 2011-07-08 06:23:24 --> Model Class Initialized
DEBUG - 2011-07-08 06:23:24 --> Model Class Initialized
DEBUG - 2011-07-08 06:23:24 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-07-08 06:23:24 --> Database Driver Class Initialized
DEBUG - 2011-07-08 06:23:25 --> File loaded: application/views/table/main.php
DEBUG - 2011-07-08 06:23:25 --> Helper loaded: url_helper
DEBUG - 2011-07-08 06:23:25 --> File loaded: application/views/common/header.php
DEBUG - 2011-07-08 06:23:25 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-07-08 06:23:25 --> File loaded: application/views/common/footer.php
DEBUG - 2011-07-08 06:23:25 --> File loaded: application/views/layout/main.php
DEBUG - 2011-07-08 06:23:25 --> Final output sent to browser
DEBUG - 2011-07-08 06:23:25 --> Total execution time: 0.2281
DEBUG - 2011-07-08 06:23:27 --> Config Class Initialized
DEBUG - 2011-07-08 06:23:27 --> Hooks Class Initialized
DEBUG - 2011-07-08 06:23:27 --> Utf8 Class Initialized
DEBUG - 2011-07-08 06:23:27 --> UTF-8 Support Enabled
DEBUG - 2011-07-08 06:23:27 --> URI Class Initialized
DEBUG - 2011-07-08 06:23:27 --> Router Class Initialized
DEBUG - 2011-07-08 06:23:27 --> Output Class Initialized
DEBUG - 2011-07-08 06:23:27 --> Input Class Initialized
DEBUG - 2011-07-08 06:23:27 --> Global POST and COOKIE data sanitized
DEBUG - 2011-07-08 06:23:27 --> Language Class Initialized
DEBUG - 2011-07-08 06:23:27 --> Loader Class Initialized
DEBUG - 2011-07-08 06:23:27 --> Controller Class Initialized
DEBUG - 2011-07-08 06:23:27 --> Model Class Initialized
DEBUG - 2011-07-08 06:23:27 --> Model Class Initialized
DEBUG - 2011-07-08 06:23:27 --> Model Class Initialized
DEBUG - 2011-07-08 06:23:27 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-07-08 06:23:27 --> Database Driver Class Initialized
DEBUG - 2011-07-08 06:23:27 --> File loaded: application/views/table/main.php
DEBUG - 2011-07-08 06:23:27 --> Helper loaded: url_helper
DEBUG - 2011-07-08 06:23:27 --> File loaded: application/views/common/header.php
DEBUG - 2011-07-08 06:23:27 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-07-08 06:23:27 --> File loaded: application/views/common/footer.php
DEBUG - 2011-07-08 06:23:27 --> File loaded: application/views/layout/main.php
DEBUG - 2011-07-08 06:23:27 --> Final output sent to browser
DEBUG - 2011-07-08 06:23:27 --> Total execution time: 0.0574
DEBUG - 2011-07-08 06:23:32 --> Config Class Initialized
DEBUG - 2011-07-08 06:23:32 --> Hooks Class Initialized
DEBUG - 2011-07-08 06:23:32 --> Utf8 Class Initialized
DEBUG - 2011-07-08 06:23:32 --> UTF-8 Support Enabled
DEBUG - 2011-07-08 06:23:32 --> URI Class Initialized
DEBUG - 2011-07-08 06:23:32 --> Router Class Initialized
DEBUG - 2011-07-08 06:23:32 --> Output Class Initialized
DEBUG - 2011-07-08 06:23:32 --> Input Class Initialized
DEBUG - 2011-07-08 06:23:32 --> Global POST and COOKIE data sanitized
DEBUG - 2011-07-08 06:23:32 --> Language Class Initialized
DEBUG - 2011-07-08 06:23:32 --> Loader Class Initialized
DEBUG - 2011-07-08 06:23:32 --> Controller Class Initialized
DEBUG - 2011-07-08 06:23:32 --> Model Class Initialized
DEBUG - 2011-07-08 06:23:32 --> Model Class Initialized
DEBUG - 2011-07-08 06:23:32 --> Model Class Initialized
DEBUG - 2011-07-08 06:23:32 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-07-08 06:23:32 --> Database Driver Class Initialized
DEBUG - 2011-07-08 06:23:32 --> File loaded: application/views/table/main.php
DEBUG - 2011-07-08 06:23:32 --> Helper loaded: url_helper
DEBUG - 2011-07-08 06:23:32 --> File loaded: application/views/common/header.php
DEBUG - 2011-07-08 06:23:32 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-07-08 06:23:32 --> File loaded: application/views/common/footer.php
DEBUG - 2011-07-08 06:23:32 --> File loaded: application/views/layout/main.php
DEBUG - 2011-07-08 06:23:32 --> Final output sent to browser
DEBUG - 2011-07-08 06:23:32 --> Total execution time: 0.0635
DEBUG - 2011-07-08 06:23:33 --> Config Class Initialized
DEBUG - 2011-07-08 06:23:33 --> Hooks Class Initialized
DEBUG - 2011-07-08 06:23:33 --> Utf8 Class Initialized
DEBUG - 2011-07-08 06:23:33 --> UTF-8 Support Enabled
DEBUG - 2011-07-08 06:23:33 --> URI Class Initialized
DEBUG - 2011-07-08 06:23:33 --> Router Class Initialized
DEBUG - 2011-07-08 06:23:33 --> Output Class Initialized
DEBUG - 2011-07-08 06:23:33 --> Input Class Initialized
DEBUG - 2011-07-08 06:23:33 --> Global POST and COOKIE data sanitized
DEBUG - 2011-07-08 06:23:33 --> Language Class Initialized
DEBUG - 2011-07-08 06:23:33 --> Loader Class Initialized
DEBUG - 2011-07-08 06:23:33 --> Controller Class Initialized
DEBUG - 2011-07-08 06:23:33 --> Model Class Initialized
DEBUG - 2011-07-08 06:23:33 --> Model Class Initialized
DEBUG - 2011-07-08 06:23:33 --> Model Class Initialized
DEBUG - 2011-07-08 06:23:33 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-07-08 06:23:33 --> Database Driver Class Initialized
DEBUG - 2011-07-08 06:23:33 --> File loaded: application/views/table/main.php
DEBUG - 2011-07-08 06:23:33 --> Helper loaded: url_helper
DEBUG - 2011-07-08 06:23:33 --> File loaded: application/views/common/header.php
DEBUG - 2011-07-08 06:23:33 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-07-08 06:23:33 --> File loaded: application/views/common/footer.php
DEBUG - 2011-07-08 06:23:33 --> File loaded: application/views/layout/main.php
DEBUG - 2011-07-08 06:23:33 --> Final output sent to browser
DEBUG - 2011-07-08 06:23:33 --> Total execution time: 0.0554
DEBUG - 2011-07-08 06:23:34 --> Config Class Initialized
DEBUG - 2011-07-08 06:23:34 --> Hooks Class Initialized
DEBUG - 2011-07-08 06:23:34 --> Utf8 Class Initialized
DEBUG - 2011-07-08 06:23:34 --> UTF-8 Support Enabled
DEBUG - 2011-07-08 06:23:34 --> URI Class Initialized
DEBUG - 2011-07-08 06:23:34 --> Router Class Initialized
DEBUG - 2011-07-08 06:23:34 --> Output Class Initialized
DEBUG - 2011-07-08 06:23:34 --> Input Class Initialized
DEBUG - 2011-07-08 06:23:34 --> Global POST and COOKIE data sanitized
DEBUG - 2011-07-08 06:23:34 --> Language Class Initialized
DEBUG - 2011-07-08 06:23:34 --> Loader Class Initialized
DEBUG - 2011-07-08 06:23:34 --> Controller Class Initialized
DEBUG - 2011-07-08 06:23:34 --> Model Class Initialized
DEBUG - 2011-07-08 06:23:34 --> Model Class Initialized
DEBUG - 2011-07-08 06:23:34 --> Model Class Initialized
DEBUG - 2011-07-08 06:23:34 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-07-08 06:23:34 --> Database Driver Class Initialized
DEBUG - 2011-07-08 06:23:34 --> File loaded: application/views/table/main.php
DEBUG - 2011-07-08 06:23:34 --> Helper loaded: url_helper
DEBUG - 2011-07-08 06:23:34 --> File loaded: application/views/common/header.php
DEBUG - 2011-07-08 06:23:34 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-07-08 06:23:34 --> File loaded: application/views/common/footer.php
DEBUG - 2011-07-08 06:23:34 --> File loaded: application/views/layout/main.php
DEBUG - 2011-07-08 06:23:34 --> Final output sent to browser
DEBUG - 2011-07-08 06:23:34 --> Total execution time: 0.0438
DEBUG - 2011-07-08 06:23:39 --> Config Class Initialized
DEBUG - 2011-07-08 06:23:39 --> Hooks Class Initialized
DEBUG - 2011-07-08 06:23:39 --> Utf8 Class Initialized
DEBUG - 2011-07-08 06:23:39 --> UTF-8 Support Enabled
DEBUG - 2011-07-08 06:23:39 --> URI Class Initialized
DEBUG - 2011-07-08 06:23:39 --> Router Class Initialized
DEBUG - 2011-07-08 06:23:39 --> Output Class Initialized
DEBUG - 2011-07-08 06:23:39 --> Input Class Initialized
DEBUG - 2011-07-08 06:23:39 --> Global POST and COOKIE data sanitized
DEBUG - 2011-07-08 06:23:39 --> Language Class Initialized
DEBUG - 2011-07-08 06:23:39 --> Loader Class Initialized
DEBUG - 2011-07-08 06:23:39 --> Controller Class Initialized
DEBUG - 2011-07-08 06:23:39 --> Model Class Initialized
DEBUG - 2011-07-08 06:23:39 --> Model Class Initialized
DEBUG - 2011-07-08 06:23:39 --> Model Class Initialized
DEBUG - 2011-07-08 06:23:39 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-07-08 06:23:39 --> Database Driver Class Initialized
DEBUG - 2011-07-08 06:23:39 --> File loaded: application/views/table/main.php
DEBUG - 2011-07-08 06:23:39 --> Helper loaded: url_helper
DEBUG - 2011-07-08 06:23:39 --> File loaded: application/views/common/header.php
DEBUG - 2011-07-08 06:23:39 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-07-08 06:23:39 --> File loaded: application/views/common/footer.php
DEBUG - 2011-07-08 06:23:39 --> File loaded: application/views/layout/main.php
DEBUG - 2011-07-08 06:23:39 --> Final output sent to browser
DEBUG - 2011-07-08 06:23:39 --> Total execution time: 0.2913
DEBUG - 2011-07-08 06:23:40 --> Config Class Initialized
DEBUG - 2011-07-08 06:23:40 --> Hooks Class Initialized
DEBUG - 2011-07-08 06:23:40 --> Utf8 Class Initialized
DEBUG - 2011-07-08 06:23:40 --> UTF-8 Support Enabled
DEBUG - 2011-07-08 06:23:40 --> URI Class Initialized
DEBUG - 2011-07-08 06:23:40 --> Router Class Initialized
DEBUG - 2011-07-08 06:23:40 --> Output Class Initialized
DEBUG - 2011-07-08 06:23:40 --> Input Class Initialized
DEBUG - 2011-07-08 06:23:40 --> Global POST and COOKIE data sanitized
DEBUG - 2011-07-08 06:23:40 --> Language Class Initialized
DEBUG - 2011-07-08 06:23:40 --> Loader Class Initialized
DEBUG - 2011-07-08 06:23:40 --> Controller Class Initialized
DEBUG - 2011-07-08 06:23:40 --> Model Class Initialized
DEBUG - 2011-07-08 06:23:40 --> Model Class Initialized
DEBUG - 2011-07-08 06:23:40 --> Model Class Initialized
DEBUG - 2011-07-08 06:23:40 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-07-08 06:23:40 --> Database Driver Class Initialized
DEBUG - 2011-07-08 06:23:40 --> File loaded: application/views/table/main.php
DEBUG - 2011-07-08 06:23:40 --> Helper loaded: url_helper
DEBUG - 2011-07-08 06:23:40 --> File loaded: application/views/common/header.php
DEBUG - 2011-07-08 06:23:40 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-07-08 06:23:40 --> File loaded: application/views/common/footer.php
DEBUG - 2011-07-08 06:23:40 --> File loaded: application/views/layout/main.php
DEBUG - 2011-07-08 06:23:40 --> Final output sent to browser
DEBUG - 2011-07-08 06:23:40 --> Total execution time: 0.0450
DEBUG - 2011-07-08 06:23:41 --> Config Class Initialized
DEBUG - 2011-07-08 06:23:41 --> Hooks Class Initialized
DEBUG - 2011-07-08 06:23:41 --> Utf8 Class Initialized
DEBUG - 2011-07-08 06:23:41 --> UTF-8 Support Enabled
DEBUG - 2011-07-08 06:23:41 --> URI Class Initialized
DEBUG - 2011-07-08 06:23:41 --> Router Class Initialized
DEBUG - 2011-07-08 06:23:41 --> Output Class Initialized
DEBUG - 2011-07-08 06:23:41 --> Input Class Initialized
DEBUG - 2011-07-08 06:23:41 --> Global POST and COOKIE data sanitized
DEBUG - 2011-07-08 06:23:41 --> Language Class Initialized
DEBUG - 2011-07-08 06:23:41 --> Loader Class Initialized
DEBUG - 2011-07-08 06:23:41 --> Controller Class Initialized
DEBUG - 2011-07-08 06:23:41 --> Model Class Initialized
DEBUG - 2011-07-08 06:23:41 --> Model Class Initialized
DEBUG - 2011-07-08 06:23:41 --> Model Class Initialized
DEBUG - 2011-07-08 06:23:41 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-07-08 06:23:41 --> Database Driver Class Initialized
DEBUG - 2011-07-08 06:23:41 --> File loaded: application/views/table/main.php
DEBUG - 2011-07-08 06:23:41 --> Helper loaded: url_helper
DEBUG - 2011-07-08 06:23:41 --> File loaded: application/views/common/header.php
DEBUG - 2011-07-08 06:23:41 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-07-08 06:23:41 --> File loaded: application/views/common/footer.php
DEBUG - 2011-07-08 06:23:41 --> File loaded: application/views/layout/main.php
DEBUG - 2011-07-08 06:23:41 --> Final output sent to browser
DEBUG - 2011-07-08 06:23:41 --> Total execution time: 0.0459
DEBUG - 2011-07-08 06:23:54 --> Config Class Initialized
DEBUG - 2011-07-08 06:23:54 --> Hooks Class Initialized
DEBUG - 2011-07-08 06:23:54 --> Utf8 Class Initialized
DEBUG - 2011-07-08 06:23:54 --> UTF-8 Support Enabled
DEBUG - 2011-07-08 06:23:54 --> URI Class Initialized
DEBUG - 2011-07-08 06:23:54 --> Router Class Initialized
DEBUG - 2011-07-08 06:23:54 --> Output Class Initialized
DEBUG - 2011-07-08 06:23:54 --> Input Class Initialized
DEBUG - 2011-07-08 06:23:54 --> Global POST and COOKIE data sanitized
DEBUG - 2011-07-08 06:23:54 --> Language Class Initialized
DEBUG - 2011-07-08 06:23:54 --> Loader Class Initialized
DEBUG - 2011-07-08 06:23:54 --> Controller Class Initialized
DEBUG - 2011-07-08 06:23:54 --> Model Class Initialized
DEBUG - 2011-07-08 06:23:54 --> Model Class Initialized
DEBUG - 2011-07-08 06:23:54 --> Model Class Initialized
DEBUG - 2011-07-08 06:23:54 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-07-08 06:23:54 --> Database Driver Class Initialized
DEBUG - 2011-07-08 06:23:55 --> File loaded: application/views/table/main.php
DEBUG - 2011-07-08 06:23:55 --> Helper loaded: url_helper
DEBUG - 2011-07-08 06:23:55 --> File loaded: application/views/common/header.php
DEBUG - 2011-07-08 06:23:55 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-07-08 06:23:55 --> File loaded: application/views/common/footer.php
DEBUG - 2011-07-08 06:23:55 --> File loaded: application/views/layout/main.php
DEBUG - 2011-07-08 06:23:55 --> Final output sent to browser
DEBUG - 2011-07-08 06:23:55 --> Total execution time: 0.3344
DEBUG - 2011-07-08 06:23:59 --> Config Class Initialized
DEBUG - 2011-07-08 06:23:59 --> Hooks Class Initialized
DEBUG - 2011-07-08 06:23:59 --> Utf8 Class Initialized
DEBUG - 2011-07-08 06:23:59 --> UTF-8 Support Enabled
DEBUG - 2011-07-08 06:23:59 --> URI Class Initialized
DEBUG - 2011-07-08 06:23:59 --> Router Class Initialized
DEBUG - 2011-07-08 06:23:59 --> Output Class Initialized
DEBUG - 2011-07-08 06:23:59 --> Input Class Initialized
DEBUG - 2011-07-08 06:23:59 --> Global POST and COOKIE data sanitized
DEBUG - 2011-07-08 06:23:59 --> Language Class Initialized
DEBUG - 2011-07-08 06:23:59 --> Loader Class Initialized
DEBUG - 2011-07-08 06:23:59 --> Controller Class Initialized
DEBUG - 2011-07-08 06:23:59 --> Model Class Initialized
DEBUG - 2011-07-08 06:23:59 --> Model Class Initialized
DEBUG - 2011-07-08 06:23:59 --> Model Class Initialized
DEBUG - 2011-07-08 06:23:59 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-07-08 06:23:59 --> Database Driver Class Initialized
DEBUG - 2011-07-08 06:23:59 --> File loaded: application/views/table/main.php
DEBUG - 2011-07-08 06:23:59 --> Helper loaded: url_helper
DEBUG - 2011-07-08 06:23:59 --> File loaded: application/views/common/header.php
DEBUG - 2011-07-08 06:23:59 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-07-08 06:23:59 --> File loaded: application/views/common/footer.php
DEBUG - 2011-07-08 06:23:59 --> File loaded: application/views/layout/main.php
DEBUG - 2011-07-08 06:23:59 --> Final output sent to browser
DEBUG - 2011-07-08 06:23:59 --> Total execution time: 0.0469
DEBUG - 2011-07-08 06:24:06 --> Config Class Initialized
DEBUG - 2011-07-08 06:24:06 --> Hooks Class Initialized
DEBUG - 2011-07-08 06:24:06 --> Utf8 Class Initialized
DEBUG - 2011-07-08 06:24:06 --> UTF-8 Support Enabled
DEBUG - 2011-07-08 06:24:06 --> URI Class Initialized
DEBUG - 2011-07-08 06:24:06 --> Router Class Initialized
DEBUG - 2011-07-08 06:24:06 --> Output Class Initialized
DEBUG - 2011-07-08 06:24:06 --> Input Class Initialized
DEBUG - 2011-07-08 06:24:06 --> Global POST and COOKIE data sanitized
DEBUG - 2011-07-08 06:24:06 --> Language Class Initialized
DEBUG - 2011-07-08 06:24:06 --> Loader Class Initialized
DEBUG - 2011-07-08 06:24:06 --> Controller Class Initialized
DEBUG - 2011-07-08 06:24:06 --> Model Class Initialized
DEBUG - 2011-07-08 06:24:06 --> Model Class Initialized
DEBUG - 2011-07-08 06:24:06 --> Model Class Initialized
DEBUG - 2011-07-08 06:24:06 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-07-08 06:24:06 --> Database Driver Class Initialized
DEBUG - 2011-07-08 06:24:06 --> File loaded: application/views/table/main.php
DEBUG - 2011-07-08 06:24:06 --> Helper loaded: url_helper
DEBUG - 2011-07-08 06:24:06 --> File loaded: application/views/common/header.php
DEBUG - 2011-07-08 06:24:06 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-07-08 06:24:06 --> File loaded: application/views/common/footer.php
DEBUG - 2011-07-08 06:24:06 --> File loaded: application/views/layout/main.php
DEBUG - 2011-07-08 06:24:06 --> Final output sent to browser
DEBUG - 2011-07-08 06:24:06 --> Total execution time: 0.2488
DEBUG - 2011-07-08 06:24:08 --> Config Class Initialized
DEBUG - 2011-07-08 06:24:08 --> Hooks Class Initialized
DEBUG - 2011-07-08 06:24:08 --> Utf8 Class Initialized
DEBUG - 2011-07-08 06:24:08 --> UTF-8 Support Enabled
DEBUG - 2011-07-08 06:24:08 --> URI Class Initialized
DEBUG - 2011-07-08 06:24:08 --> Router Class Initialized
DEBUG - 2011-07-08 06:24:08 --> Output Class Initialized
DEBUG - 2011-07-08 06:24:08 --> Input Class Initialized
DEBUG - 2011-07-08 06:24:08 --> Global POST and COOKIE data sanitized
DEBUG - 2011-07-08 06:24:08 --> Language Class Initialized
DEBUG - 2011-07-08 06:24:08 --> Loader Class Initialized
DEBUG - 2011-07-08 06:24:08 --> Controller Class Initialized
DEBUG - 2011-07-08 06:24:08 --> Model Class Initialized
DEBUG - 2011-07-08 06:24:08 --> Model Class Initialized
DEBUG - 2011-07-08 06:24:08 --> Model Class Initialized
DEBUG - 2011-07-08 06:24:08 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-07-08 06:24:08 --> Database Driver Class Initialized
DEBUG - 2011-07-08 06:24:08 --> File loaded: application/views/table/main.php
DEBUG - 2011-07-08 06:24:08 --> Helper loaded: url_helper
DEBUG - 2011-07-08 06:24:08 --> File loaded: application/views/common/header.php
DEBUG - 2011-07-08 06:24:08 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-07-08 06:24:08 --> File loaded: application/views/common/footer.php
DEBUG - 2011-07-08 06:24:08 --> File loaded: application/views/layout/main.php
DEBUG - 2011-07-08 06:24:08 --> Final output sent to browser
DEBUG - 2011-07-08 06:24:08 --> Total execution time: 0.0471
DEBUG - 2011-07-08 06:24:18 --> Config Class Initialized
DEBUG - 2011-07-08 06:24:18 --> Hooks Class Initialized
DEBUG - 2011-07-08 06:24:18 --> Utf8 Class Initialized
DEBUG - 2011-07-08 06:24:18 --> UTF-8 Support Enabled
DEBUG - 2011-07-08 06:24:18 --> URI Class Initialized
DEBUG - 2011-07-08 06:24:18 --> Router Class Initialized
DEBUG - 2011-07-08 06:24:18 --> Output Class Initialized
DEBUG - 2011-07-08 06:24:18 --> Input Class Initialized
DEBUG - 2011-07-08 06:24:18 --> Global POST and COOKIE data sanitized
DEBUG - 2011-07-08 06:24:18 --> Language Class Initialized
DEBUG - 2011-07-08 06:24:18 --> Loader Class Initialized
DEBUG - 2011-07-08 06:24:18 --> Controller Class Initialized
DEBUG - 2011-07-08 06:24:18 --> Model Class Initialized
DEBUG - 2011-07-08 06:24:18 --> Model Class Initialized
DEBUG - 2011-07-08 06:24:18 --> Model Class Initialized
DEBUG - 2011-07-08 06:24:18 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-07-08 06:24:18 --> Database Driver Class Initialized
DEBUG - 2011-07-08 06:24:18 --> File loaded: application/views/table/main.php
DEBUG - 2011-07-08 06:24:18 --> Helper loaded: url_helper
DEBUG - 2011-07-08 06:24:18 --> File loaded: application/views/common/header.php
DEBUG - 2011-07-08 06:24:18 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-07-08 06:24:18 --> File loaded: application/views/common/footer.php
DEBUG - 2011-07-08 06:24:18 --> File loaded: application/views/layout/main.php
DEBUG - 2011-07-08 06:24:18 --> Final output sent to browser
DEBUG - 2011-07-08 06:24:18 --> Total execution time: 0.0441
DEBUG - 2011-07-08 06:24:33 --> Config Class Initialized
DEBUG - 2011-07-08 06:24:33 --> Hooks Class Initialized
DEBUG - 2011-07-08 06:24:33 --> Utf8 Class Initialized
DEBUG - 2011-07-08 06:24:33 --> UTF-8 Support Enabled
DEBUG - 2011-07-08 06:24:33 --> URI Class Initialized
DEBUG - 2011-07-08 06:24:33 --> Router Class Initialized
DEBUG - 2011-07-08 06:24:33 --> Output Class Initialized
DEBUG - 2011-07-08 06:24:33 --> Input Class Initialized
DEBUG - 2011-07-08 06:24:33 --> Global POST and COOKIE data sanitized
DEBUG - 2011-07-08 06:24:33 --> Language Class Initialized
DEBUG - 2011-07-08 06:24:33 --> Loader Class Initialized
DEBUG - 2011-07-08 06:24:33 --> Controller Class Initialized
DEBUG - 2011-07-08 06:24:33 --> Model Class Initialized
DEBUG - 2011-07-08 06:24:33 --> Model Class Initialized
DEBUG - 2011-07-08 06:24:33 --> Model Class Initialized
DEBUG - 2011-07-08 06:24:33 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-07-08 06:24:33 --> Database Driver Class Initialized
DEBUG - 2011-07-08 06:24:33 --> File loaded: application/views/table/main.php
DEBUG - 2011-07-08 06:24:33 --> Helper loaded: url_helper
DEBUG - 2011-07-08 06:24:33 --> File loaded: application/views/common/header.php
DEBUG - 2011-07-08 06:24:33 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-07-08 06:24:33 --> File loaded: application/views/common/footer.php
DEBUG - 2011-07-08 06:24:33 --> File loaded: application/views/layout/main.php
DEBUG - 2011-07-08 06:24:33 --> Final output sent to browser
DEBUG - 2011-07-08 06:24:33 --> Total execution time: 0.0467
DEBUG - 2011-07-08 06:24:39 --> Config Class Initialized
DEBUG - 2011-07-08 06:24:39 --> Hooks Class Initialized
DEBUG - 2011-07-08 06:24:39 --> Utf8 Class Initialized
DEBUG - 2011-07-08 06:24:39 --> UTF-8 Support Enabled
DEBUG - 2011-07-08 06:24:39 --> URI Class Initialized
DEBUG - 2011-07-08 06:24:39 --> Router Class Initialized
DEBUG - 2011-07-08 06:24:39 --> Output Class Initialized
DEBUG - 2011-07-08 06:24:39 --> Input Class Initialized
DEBUG - 2011-07-08 06:24:39 --> Global POST and COOKIE data sanitized
DEBUG - 2011-07-08 06:24:39 --> Language Class Initialized
DEBUG - 2011-07-08 06:24:39 --> Loader Class Initialized
DEBUG - 2011-07-08 06:24:39 --> Controller Class Initialized
DEBUG - 2011-07-08 06:24:39 --> Model Class Initialized
DEBUG - 2011-07-08 06:24:39 --> Model Class Initialized
DEBUG - 2011-07-08 06:24:39 --> Model Class Initialized
DEBUG - 2011-07-08 06:24:39 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-07-08 06:24:39 --> Database Driver Class Initialized
DEBUG - 2011-07-08 06:24:39 --> File loaded: application/views/table/main.php
DEBUG - 2011-07-08 06:24:39 --> Helper loaded: url_helper
DEBUG - 2011-07-08 06:24:39 --> File loaded: application/views/common/header.php
DEBUG - 2011-07-08 06:24:39 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-07-08 06:24:39 --> File loaded: application/views/common/footer.php
DEBUG - 2011-07-08 06:24:39 --> File loaded: application/views/layout/main.php
DEBUG - 2011-07-08 06:24:39 --> Final output sent to browser
DEBUG - 2011-07-08 06:24:39 --> Total execution time: 0.3644
DEBUG - 2011-07-08 06:24:41 --> Config Class Initialized
DEBUG - 2011-07-08 06:24:41 --> Hooks Class Initialized
DEBUG - 2011-07-08 06:24:41 --> Utf8 Class Initialized
DEBUG - 2011-07-08 06:24:41 --> UTF-8 Support Enabled
DEBUG - 2011-07-08 06:24:41 --> URI Class Initialized
DEBUG - 2011-07-08 06:24:41 --> Router Class Initialized
DEBUG - 2011-07-08 06:24:41 --> Output Class Initialized
DEBUG - 2011-07-08 06:24:41 --> Input Class Initialized
DEBUG - 2011-07-08 06:24:41 --> Global POST and COOKIE data sanitized
DEBUG - 2011-07-08 06:24:41 --> Language Class Initialized
DEBUG - 2011-07-08 06:24:41 --> Loader Class Initialized
DEBUG - 2011-07-08 06:24:41 --> Controller Class Initialized
DEBUG - 2011-07-08 06:24:41 --> Model Class Initialized
DEBUG - 2011-07-08 06:24:41 --> Model Class Initialized
DEBUG - 2011-07-08 06:24:41 --> Model Class Initialized
DEBUG - 2011-07-08 06:24:41 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-07-08 06:24:41 --> Database Driver Class Initialized
DEBUG - 2011-07-08 06:24:41 --> File loaded: application/views/table/main.php
DEBUG - 2011-07-08 06:24:41 --> Helper loaded: url_helper
DEBUG - 2011-07-08 06:24:41 --> File loaded: application/views/common/header.php
DEBUG - 2011-07-08 06:24:41 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-07-08 06:24:41 --> File loaded: application/views/common/footer.php
DEBUG - 2011-07-08 06:24:41 --> File loaded: application/views/layout/main.php
DEBUG - 2011-07-08 06:24:41 --> Final output sent to browser
DEBUG - 2011-07-08 06:24:41 --> Total execution time: 0.0511
DEBUG - 2011-07-08 06:34:12 --> Config Class Initialized
DEBUG - 2011-07-08 06:34:13 --> Hooks Class Initialized
DEBUG - 2011-07-08 06:34:13 --> Utf8 Class Initialized
DEBUG - 2011-07-08 06:34:13 --> UTF-8 Support Enabled
DEBUG - 2011-07-08 06:34:13 --> URI Class Initialized
DEBUG - 2011-07-08 06:34:13 --> Router Class Initialized
DEBUG - 2011-07-08 06:34:13 --> Output Class Initialized
DEBUG - 2011-07-08 06:34:13 --> Input Class Initialized
DEBUG - 2011-07-08 06:34:13 --> Global POST and COOKIE data sanitized
DEBUG - 2011-07-08 06:34:13 --> Language Class Initialized
DEBUG - 2011-07-08 06:34:13 --> Loader Class Initialized
DEBUG - 2011-07-08 06:34:13 --> Controller Class Initialized
DEBUG - 2011-07-08 06:34:13 --> Model Class Initialized
DEBUG - 2011-07-08 06:34:13 --> Model Class Initialized
DEBUG - 2011-07-08 06:34:13 --> Model Class Initialized
DEBUG - 2011-07-08 06:34:13 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-07-08 06:34:13 --> Database Driver Class Initialized
DEBUG - 2011-07-08 06:34:14 --> File loaded: application/views/table/main.php
DEBUG - 2011-07-08 06:34:14 --> Helper loaded: url_helper
DEBUG - 2011-07-08 06:34:14 --> File loaded: application/views/common/header.php
DEBUG - 2011-07-08 06:34:14 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-07-08 06:34:14 --> File loaded: application/views/common/footer.php
DEBUG - 2011-07-08 06:34:14 --> File loaded: application/views/layout/main.php
DEBUG - 2011-07-08 06:34:14 --> Final output sent to browser
DEBUG - 2011-07-08 06:34:14 --> Total execution time: 1.9349
DEBUG - 2011-07-08 06:34:16 --> Config Class Initialized
DEBUG - 2011-07-08 06:34:16 --> Hooks Class Initialized
DEBUG - 2011-07-08 06:34:16 --> Utf8 Class Initialized
DEBUG - 2011-07-08 06:34:16 --> UTF-8 Support Enabled
DEBUG - 2011-07-08 06:34:16 --> URI Class Initialized
DEBUG - 2011-07-08 06:34:16 --> Router Class Initialized
DEBUG - 2011-07-08 06:34:16 --> Output Class Initialized
DEBUG - 2011-07-08 06:34:16 --> Input Class Initialized
DEBUG - 2011-07-08 06:34:16 --> Global POST and COOKIE data sanitized
DEBUG - 2011-07-08 06:34:16 --> Language Class Initialized
DEBUG - 2011-07-08 06:34:16 --> Loader Class Initialized
DEBUG - 2011-07-08 06:34:16 --> Controller Class Initialized
ERROR - 2011-07-08 06:34:17 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-07-08 06:34:17 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-07-08 06:34:17 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-07-08 06:34:17 --> Model Class Initialized
DEBUG - 2011-07-08 06:34:17 --> Model Class Initialized
DEBUG - 2011-07-08 06:34:17 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-07-08 06:34:17 --> Database Driver Class Initialized
DEBUG - 2011-07-08 06:34:17 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-07-08 06:34:17 --> Helper loaded: url_helper
DEBUG - 2011-07-08 06:34:17 --> File loaded: application/views/common/header.php
DEBUG - 2011-07-08 06:34:17 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-07-08 06:34:17 --> File loaded: application/views/common/footer.php
DEBUG - 2011-07-08 06:34:17 --> File loaded: application/views/layout/main.php
DEBUG - 2011-07-08 06:34:17 --> Final output sent to browser
DEBUG - 2011-07-08 06:34:17 --> Total execution time: 0.9942
DEBUG - 2011-07-08 07:02:27 --> Config Class Initialized
DEBUG - 2011-07-08 07:02:27 --> Hooks Class Initialized
DEBUG - 2011-07-08 07:02:27 --> Utf8 Class Initialized
DEBUG - 2011-07-08 07:02:27 --> UTF-8 Support Enabled
DEBUG - 2011-07-08 07:02:27 --> URI Class Initialized
DEBUG - 2011-07-08 07:02:27 --> Router Class Initialized
ERROR - 2011-07-08 07:02:27 --> 404 Page Not Found --> robots.txt
DEBUG - 2011-07-08 07:47:39 --> Config Class Initialized
DEBUG - 2011-07-08 07:47:39 --> Hooks Class Initialized
DEBUG - 2011-07-08 07:47:39 --> Utf8 Class Initialized
DEBUG - 2011-07-08 07:47:39 --> UTF-8 Support Enabled
DEBUG - 2011-07-08 07:47:39 --> URI Class Initialized
DEBUG - 2011-07-08 07:47:39 --> Router Class Initialized
DEBUG - 2011-07-08 07:47:39 --> Output Class Initialized
DEBUG - 2011-07-08 07:47:39 --> Input Class Initialized
DEBUG - 2011-07-08 07:47:39 --> Global POST and COOKIE data sanitized
DEBUG - 2011-07-08 07:47:39 --> Language Class Initialized
DEBUG - 2011-07-08 07:47:39 --> Loader Class Initialized
DEBUG - 2011-07-08 07:47:39 --> Controller Class Initialized
DEBUG - 2011-07-08 07:47:39 --> Model Class Initialized
DEBUG - 2011-07-08 07:47:39 --> Model Class Initialized
DEBUG - 2011-07-08 07:47:39 --> Model Class Initialized
DEBUG - 2011-07-08 07:47:39 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-07-08 07:47:39 --> Database Driver Class Initialized
DEBUG - 2011-07-08 07:47:40 --> File loaded: application/views/table/main.php
DEBUG - 2011-07-08 07:47:40 --> Helper loaded: url_helper
DEBUG - 2011-07-08 07:47:40 --> File loaded: application/views/common/header.php
DEBUG - 2011-07-08 07:47:40 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-07-08 07:47:40 --> File loaded: application/views/common/footer.php
DEBUG - 2011-07-08 07:47:40 --> File loaded: application/views/layout/main.php
DEBUG - 2011-07-08 07:47:40 --> Final output sent to browser
DEBUG - 2011-07-08 07:47:40 --> Total execution time: 0.6921
DEBUG - 2011-07-08 11:27:13 --> Config Class Initialized
DEBUG - 2011-07-08 11:27:13 --> Hooks Class Initialized
DEBUG - 2011-07-08 11:27:13 --> Utf8 Class Initialized
DEBUG - 2011-07-08 11:27:13 --> UTF-8 Support Enabled
DEBUG - 2011-07-08 11:27:13 --> URI Class Initialized
DEBUG - 2011-07-08 11:27:13 --> Router Class Initialized
DEBUG - 2011-07-08 11:27:13 --> Output Class Initialized
DEBUG - 2011-07-08 11:27:13 --> Input Class Initialized
DEBUG - 2011-07-08 11:27:13 --> Global POST and COOKIE data sanitized
DEBUG - 2011-07-08 11:27:13 --> Language Class Initialized
DEBUG - 2011-07-08 11:27:13 --> Loader Class Initialized
DEBUG - 2011-07-08 11:27:14 --> Controller Class Initialized
DEBUG - 2011-07-08 11:27:14 --> Model Class Initialized
DEBUG - 2011-07-08 11:27:14 --> Model Class Initialized
DEBUG - 2011-07-08 11:27:14 --> Model Class Initialized
DEBUG - 2011-07-08 11:27:14 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-07-08 11:27:14 --> Database Driver Class Initialized
DEBUG - 2011-07-08 11:27:14 --> File loaded: application/views/table/main.php
DEBUG - 2011-07-08 11:27:14 --> Helper loaded: url_helper
DEBUG - 2011-07-08 11:27:14 --> File loaded: application/views/common/header.php
DEBUG - 2011-07-08 11:27:14 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-07-08 11:27:14 --> File loaded: application/views/common/footer.php
DEBUG - 2011-07-08 11:27:14 --> File loaded: application/views/layout/main.php
DEBUG - 2011-07-08 11:27:14 --> Final output sent to browser
DEBUG - 2011-07-08 11:27:14 --> Total execution time: 1.0120
DEBUG - 2011-07-08 11:27:34 --> Config Class Initialized
DEBUG - 2011-07-08 11:27:34 --> Hooks Class Initialized
DEBUG - 2011-07-08 11:27:34 --> Utf8 Class Initialized
DEBUG - 2011-07-08 11:27:34 --> UTF-8 Support Enabled
DEBUG - 2011-07-08 11:27:34 --> URI Class Initialized
DEBUG - 2011-07-08 11:27:34 --> Router Class Initialized
DEBUG - 2011-07-08 11:27:34 --> Output Class Initialized
DEBUG - 2011-07-08 11:27:34 --> Input Class Initialized
DEBUG - 2011-07-08 11:27:34 --> Global POST and COOKIE data sanitized
DEBUG - 2011-07-08 11:27:34 --> Language Class Initialized
DEBUG - 2011-07-08 11:27:34 --> Loader Class Initialized
DEBUG - 2011-07-08 11:27:34 --> Controller Class Initialized
DEBUG - 2011-07-08 11:27:34 --> Model Class Initialized
DEBUG - 2011-07-08 11:27:34 --> Model Class Initialized
DEBUG - 2011-07-08 11:27:34 --> Model Class Initialized
DEBUG - 2011-07-08 11:27:34 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-07-08 11:27:34 --> Database Driver Class Initialized
DEBUG - 2011-07-08 11:27:34 --> File loaded: application/views/table/main.php
DEBUG - 2011-07-08 11:27:34 --> Helper loaded: url_helper
DEBUG - 2011-07-08 11:27:34 --> File loaded: application/views/common/header.php
DEBUG - 2011-07-08 11:27:34 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-07-08 11:27:34 --> File loaded: application/views/common/footer.php
DEBUG - 2011-07-08 11:27:34 --> File loaded: application/views/layout/main.php
DEBUG - 2011-07-08 11:27:34 --> Final output sent to browser
DEBUG - 2011-07-08 11:27:34 --> Total execution time: 0.2369
DEBUG - 2011-07-08 11:27:54 --> Config Class Initialized
DEBUG - 2011-07-08 11:27:54 --> Hooks Class Initialized
DEBUG - 2011-07-08 11:27:54 --> Utf8 Class Initialized
DEBUG - 2011-07-08 11:27:54 --> UTF-8 Support Enabled
DEBUG - 2011-07-08 11:27:54 --> URI Class Initialized
DEBUG - 2011-07-08 11:27:54 --> Router Class Initialized
DEBUG - 2011-07-08 11:27:54 --> Output Class Initialized
DEBUG - 2011-07-08 11:27:54 --> Input Class Initialized
DEBUG - 2011-07-08 11:27:54 --> Global POST and COOKIE data sanitized
DEBUG - 2011-07-08 11:27:54 --> Language Class Initialized
DEBUG - 2011-07-08 11:27:54 --> Loader Class Initialized
DEBUG - 2011-07-08 11:27:54 --> Controller Class Initialized
DEBUG - 2011-07-08 11:27:54 --> Model Class Initialized
DEBUG - 2011-07-08 11:27:54 --> Model Class Initialized
DEBUG - 2011-07-08 11:27:54 --> Model Class Initialized
DEBUG - 2011-07-08 11:27:54 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-07-08 11:27:54 --> Database Driver Class Initialized
DEBUG - 2011-07-08 11:27:55 --> File loaded: application/views/table/main.php
DEBUG - 2011-07-08 11:27:55 --> Helper loaded: url_helper
DEBUG - 2011-07-08 11:27:55 --> File loaded: application/views/common/header.php
DEBUG - 2011-07-08 11:27:55 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-07-08 11:27:55 --> File loaded: application/views/common/footer.php
DEBUG - 2011-07-08 11:27:55 --> File loaded: application/views/layout/main.php
DEBUG - 2011-07-08 11:27:55 --> Final output sent to browser
DEBUG - 2011-07-08 11:27:55 --> Total execution time: 0.7528
DEBUG - 2011-07-08 11:27:57 --> Config Class Initialized
DEBUG - 2011-07-08 11:27:57 --> Hooks Class Initialized
DEBUG - 2011-07-08 11:27:57 --> Utf8 Class Initialized
DEBUG - 2011-07-08 11:27:57 --> UTF-8 Support Enabled
DEBUG - 2011-07-08 11:27:57 --> URI Class Initialized
DEBUG - 2011-07-08 11:27:57 --> Router Class Initialized
DEBUG - 2011-07-08 11:27:57 --> Output Class Initialized
DEBUG - 2011-07-08 11:27:57 --> Input Class Initialized
DEBUG - 2011-07-08 11:27:57 --> Global POST and COOKIE data sanitized
DEBUG - 2011-07-08 11:27:57 --> Language Class Initialized
DEBUG - 2011-07-08 11:27:57 --> Loader Class Initialized
DEBUG - 2011-07-08 11:27:57 --> Controller Class Initialized
DEBUG - 2011-07-08 11:27:57 --> Model Class Initialized
DEBUG - 2011-07-08 11:27:57 --> Model Class Initialized
DEBUG - 2011-07-08 11:27:57 --> Model Class Initialized
DEBUG - 2011-07-08 11:27:57 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-07-08 11:27:57 --> Database Driver Class Initialized
DEBUG - 2011-07-08 11:27:57 --> File loaded: application/views/table/main.php
DEBUG - 2011-07-08 11:27:57 --> Helper loaded: url_helper
DEBUG - 2011-07-08 11:27:57 --> File loaded: application/views/common/header.php
DEBUG - 2011-07-08 11:27:57 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-07-08 11:27:57 --> File loaded: application/views/common/footer.php
DEBUG - 2011-07-08 11:27:57 --> File loaded: application/views/layout/main.php
DEBUG - 2011-07-08 11:27:57 --> Final output sent to browser
DEBUG - 2011-07-08 11:27:57 --> Total execution time: 0.0606
DEBUG - 2011-07-08 11:28:02 --> Config Class Initialized
DEBUG - 2011-07-08 11:28:02 --> Hooks Class Initialized
DEBUG - 2011-07-08 11:28:02 --> Utf8 Class Initialized
DEBUG - 2011-07-08 11:28:02 --> UTF-8 Support Enabled
DEBUG - 2011-07-08 11:28:02 --> URI Class Initialized
DEBUG - 2011-07-08 11:28:02 --> Router Class Initialized
DEBUG - 2011-07-08 11:28:02 --> Output Class Initialized
DEBUG - 2011-07-08 11:28:02 --> Input Class Initialized
DEBUG - 2011-07-08 11:28:02 --> Global POST and COOKIE data sanitized
DEBUG - 2011-07-08 11:28:02 --> Language Class Initialized
DEBUG - 2011-07-08 11:28:02 --> Loader Class Initialized
DEBUG - 2011-07-08 11:28:02 --> Controller Class Initialized
DEBUG - 2011-07-08 11:28:02 --> Model Class Initialized
DEBUG - 2011-07-08 11:28:02 --> Model Class Initialized
DEBUG - 2011-07-08 11:28:02 --> Model Class Initialized
DEBUG - 2011-07-08 11:28:02 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-07-08 11:28:02 --> Database Driver Class Initialized
DEBUG - 2011-07-08 11:28:02 --> File loaded: application/views/table/main.php
DEBUG - 2011-07-08 11:28:02 --> Helper loaded: url_helper
DEBUG - 2011-07-08 11:28:02 --> File loaded: application/views/common/header.php
DEBUG - 2011-07-08 11:28:02 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-07-08 11:28:02 --> File loaded: application/views/common/footer.php
DEBUG - 2011-07-08 11:28:02 --> File loaded: application/views/layout/main.php
DEBUG - 2011-07-08 11:28:02 --> Final output sent to browser
DEBUG - 2011-07-08 11:28:02 --> Total execution time: 0.2915
DEBUG - 2011-07-08 11:28:04 --> Config Class Initialized
DEBUG - 2011-07-08 11:28:04 --> Hooks Class Initialized
DEBUG - 2011-07-08 11:28:04 --> Utf8 Class Initialized
DEBUG - 2011-07-08 11:28:04 --> UTF-8 Support Enabled
DEBUG - 2011-07-08 11:28:04 --> URI Class Initialized
DEBUG - 2011-07-08 11:28:04 --> Router Class Initialized
DEBUG - 2011-07-08 11:28:04 --> Output Class Initialized
DEBUG - 2011-07-08 11:28:04 --> Input Class Initialized
DEBUG - 2011-07-08 11:28:04 --> Global POST and COOKIE data sanitized
DEBUG - 2011-07-08 11:28:04 --> Language Class Initialized
DEBUG - 2011-07-08 11:28:04 --> Loader Class Initialized
DEBUG - 2011-07-08 11:28:04 --> Controller Class Initialized
DEBUG - 2011-07-08 11:28:04 --> Model Class Initialized
DEBUG - 2011-07-08 11:28:04 --> Model Class Initialized
DEBUG - 2011-07-08 11:28:04 --> Model Class Initialized
DEBUG - 2011-07-08 11:28:04 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-07-08 11:28:04 --> Database Driver Class Initialized
DEBUG - 2011-07-08 11:28:04 --> File loaded: application/views/table/main.php
DEBUG - 2011-07-08 11:28:04 --> Helper loaded: url_helper
DEBUG - 2011-07-08 11:28:04 --> File loaded: application/views/common/header.php
DEBUG - 2011-07-08 11:28:04 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-07-08 11:28:04 --> File loaded: application/views/common/footer.php
DEBUG - 2011-07-08 11:28:04 --> File loaded: application/views/layout/main.php
DEBUG - 2011-07-08 11:28:04 --> Final output sent to browser
DEBUG - 2011-07-08 11:28:04 --> Total execution time: 0.0454
DEBUG - 2011-07-08 11:28:05 --> Config Class Initialized
DEBUG - 2011-07-08 11:28:05 --> Hooks Class Initialized
DEBUG - 2011-07-08 11:28:05 --> Utf8 Class Initialized
DEBUG - 2011-07-08 11:28:05 --> UTF-8 Support Enabled
DEBUG - 2011-07-08 11:28:05 --> URI Class Initialized
DEBUG - 2011-07-08 11:28:05 --> Router Class Initialized
DEBUG - 2011-07-08 11:28:05 --> Output Class Initialized
DEBUG - 2011-07-08 11:28:05 --> Input Class Initialized
DEBUG - 2011-07-08 11:28:05 --> Global POST and COOKIE data sanitized
DEBUG - 2011-07-08 11:28:05 --> Language Class Initialized
DEBUG - 2011-07-08 11:28:05 --> Loader Class Initialized
DEBUG - 2011-07-08 11:28:05 --> Controller Class Initialized
DEBUG - 2011-07-08 11:28:05 --> Model Class Initialized
DEBUG - 2011-07-08 11:28:05 --> Model Class Initialized
DEBUG - 2011-07-08 11:28:05 --> Model Class Initialized
DEBUG - 2011-07-08 11:28:05 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-07-08 11:28:05 --> Database Driver Class Initialized
DEBUG - 2011-07-08 11:28:05 --> File loaded: application/views/table/main.php
DEBUG - 2011-07-08 11:28:05 --> Helper loaded: url_helper
DEBUG - 2011-07-08 11:28:05 --> File loaded: application/views/common/header.php
DEBUG - 2011-07-08 11:28:05 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-07-08 11:28:05 --> File loaded: application/views/common/footer.php
DEBUG - 2011-07-08 11:28:05 --> File loaded: application/views/layout/main.php
DEBUG - 2011-07-08 11:28:05 --> Final output sent to browser
DEBUG - 2011-07-08 11:28:05 --> Total execution time: 0.0771
DEBUG - 2011-07-08 11:28:24 --> Config Class Initialized
DEBUG - 2011-07-08 11:28:24 --> Hooks Class Initialized
DEBUG - 2011-07-08 11:28:24 --> Utf8 Class Initialized
DEBUG - 2011-07-08 11:28:24 --> UTF-8 Support Enabled
DEBUG - 2011-07-08 11:28:24 --> URI Class Initialized
DEBUG - 2011-07-08 11:28:24 --> Router Class Initialized
DEBUG - 2011-07-08 11:28:24 --> Output Class Initialized
DEBUG - 2011-07-08 11:28:24 --> Input Class Initialized
DEBUG - 2011-07-08 11:28:24 --> Global POST and COOKIE data sanitized
DEBUG - 2011-07-08 11:28:24 --> Language Class Initialized
DEBUG - 2011-07-08 11:28:24 --> Loader Class Initialized
DEBUG - 2011-07-08 11:28:24 --> Controller Class Initialized
DEBUG - 2011-07-08 11:28:24 --> Model Class Initialized
DEBUG - 2011-07-08 11:28:24 --> Model Class Initialized
DEBUG - 2011-07-08 11:28:24 --> Model Class Initialized
DEBUG - 2011-07-08 11:28:24 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-07-08 11:28:24 --> Database Driver Class Initialized
DEBUG - 2011-07-08 11:28:24 --> File loaded: application/views/table/main.php
DEBUG - 2011-07-08 11:28:24 --> Helper loaded: url_helper
DEBUG - 2011-07-08 11:28:24 --> File loaded: application/views/common/header.php
DEBUG - 2011-07-08 11:28:24 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-07-08 11:28:24 --> File loaded: application/views/common/footer.php
DEBUG - 2011-07-08 11:28:24 --> File loaded: application/views/layout/main.php
DEBUG - 2011-07-08 11:28:24 --> Final output sent to browser
DEBUG - 2011-07-08 11:28:24 --> Total execution time: 0.3027
DEBUG - 2011-07-08 11:28:40 --> Config Class Initialized
DEBUG - 2011-07-08 11:28:40 --> Hooks Class Initialized
DEBUG - 2011-07-08 11:28:40 --> Utf8 Class Initialized
DEBUG - 2011-07-08 11:28:40 --> UTF-8 Support Enabled
DEBUG - 2011-07-08 11:28:40 --> URI Class Initialized
DEBUG - 2011-07-08 11:28:40 --> Router Class Initialized
DEBUG - 2011-07-08 11:28:40 --> Output Class Initialized
DEBUG - 2011-07-08 11:28:40 --> Input Class Initialized
DEBUG - 2011-07-08 11:28:40 --> Global POST and COOKIE data sanitized
DEBUG - 2011-07-08 11:28:40 --> Language Class Initialized
DEBUG - 2011-07-08 11:28:40 --> Loader Class Initialized
DEBUG - 2011-07-08 11:28:40 --> Controller Class Initialized
DEBUG - 2011-07-08 11:28:40 --> Model Class Initialized
DEBUG - 2011-07-08 11:28:40 --> Model Class Initialized
DEBUG - 2011-07-08 11:28:40 --> Model Class Initialized
DEBUG - 2011-07-08 11:28:40 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-07-08 11:28:40 --> Database Driver Class Initialized
DEBUG - 2011-07-08 11:28:40 --> File loaded: application/views/table/main.php
DEBUG - 2011-07-08 11:28:40 --> Helper loaded: url_helper
DEBUG - 2011-07-08 11:28:40 --> File loaded: application/views/common/header.php
DEBUG - 2011-07-08 11:28:40 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-07-08 11:28:40 --> File loaded: application/views/common/footer.php
DEBUG - 2011-07-08 11:28:40 --> File loaded: application/views/layout/main.php
DEBUG - 2011-07-08 11:28:40 --> Final output sent to browser
DEBUG - 2011-07-08 11:28:40 --> Total execution time: 0.2692
DEBUG - 2011-07-08 11:28:50 --> Config Class Initialized
DEBUG - 2011-07-08 11:28:50 --> Hooks Class Initialized
DEBUG - 2011-07-08 11:28:50 --> Utf8 Class Initialized
DEBUG - 2011-07-08 11:28:50 --> UTF-8 Support Enabled
DEBUG - 2011-07-08 11:28:50 --> URI Class Initialized
DEBUG - 2011-07-08 11:28:50 --> Router Class Initialized
DEBUG - 2011-07-08 11:28:50 --> Output Class Initialized
DEBUG - 2011-07-08 11:28:50 --> Input Class Initialized
DEBUG - 2011-07-08 11:28:50 --> Global POST and COOKIE data sanitized
DEBUG - 2011-07-08 11:28:50 --> Language Class Initialized
DEBUG - 2011-07-08 11:28:50 --> Loader Class Initialized
DEBUG - 2011-07-08 11:28:50 --> Controller Class Initialized
DEBUG - 2011-07-08 11:28:50 --> Model Class Initialized
DEBUG - 2011-07-08 11:28:50 --> Model Class Initialized
DEBUG - 2011-07-08 11:28:50 --> Model Class Initialized
DEBUG - 2011-07-08 11:28:50 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-07-08 11:28:50 --> Database Driver Class Initialized
DEBUG - 2011-07-08 11:28:50 --> File loaded: application/views/table/main.php
DEBUG - 2011-07-08 11:28:50 --> Helper loaded: url_helper
DEBUG - 2011-07-08 11:28:50 --> File loaded: application/views/common/header.php
DEBUG - 2011-07-08 11:28:50 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-07-08 11:28:50 --> File loaded: application/views/common/footer.php
DEBUG - 2011-07-08 11:28:50 --> File loaded: application/views/layout/main.php
DEBUG - 2011-07-08 11:28:50 --> Final output sent to browser
DEBUG - 2011-07-08 11:28:50 --> Total execution time: 0.4463
DEBUG - 2011-07-08 11:29:07 --> Config Class Initialized
DEBUG - 2011-07-08 11:29:07 --> Hooks Class Initialized
DEBUG - 2011-07-08 11:29:07 --> Utf8 Class Initialized
DEBUG - 2011-07-08 11:29:07 --> UTF-8 Support Enabled
DEBUG - 2011-07-08 11:29:07 --> URI Class Initialized
DEBUG - 2011-07-08 11:29:07 --> Router Class Initialized
DEBUG - 2011-07-08 11:29:07 --> Output Class Initialized
DEBUG - 2011-07-08 11:29:07 --> Input Class Initialized
DEBUG - 2011-07-08 11:29:07 --> Global POST and COOKIE data sanitized
DEBUG - 2011-07-08 11:29:07 --> Language Class Initialized
DEBUG - 2011-07-08 11:29:07 --> Loader Class Initialized
DEBUG - 2011-07-08 11:29:07 --> Controller Class Initialized
DEBUG - 2011-07-08 11:29:07 --> Model Class Initialized
DEBUG - 2011-07-08 11:29:07 --> Model Class Initialized
DEBUG - 2011-07-08 11:29:07 --> Model Class Initialized
DEBUG - 2011-07-08 11:29:07 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-07-08 11:29:07 --> Database Driver Class Initialized
DEBUG - 2011-07-08 11:29:07 --> File loaded: application/views/table/main.php
DEBUG - 2011-07-08 11:29:07 --> Helper loaded: url_helper
DEBUG - 2011-07-08 11:29:07 --> File loaded: application/views/common/header.php
DEBUG - 2011-07-08 11:29:07 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-07-08 11:29:07 --> File loaded: application/views/common/footer.php
DEBUG - 2011-07-08 11:29:07 --> File loaded: application/views/layout/main.php
DEBUG - 2011-07-08 11:29:07 --> Final output sent to browser
DEBUG - 2011-07-08 11:29:07 --> Total execution time: 0.3648
DEBUG - 2011-07-08 11:29:19 --> Config Class Initialized
DEBUG - 2011-07-08 11:29:19 --> Hooks Class Initialized
DEBUG - 2011-07-08 11:29:19 --> Utf8 Class Initialized
DEBUG - 2011-07-08 11:29:19 --> UTF-8 Support Enabled
DEBUG - 2011-07-08 11:29:19 --> URI Class Initialized
DEBUG - 2011-07-08 11:29:19 --> Router Class Initialized
DEBUG - 2011-07-08 11:29:19 --> Output Class Initialized
DEBUG - 2011-07-08 11:29:19 --> Input Class Initialized
DEBUG - 2011-07-08 11:29:19 --> Global POST and COOKIE data sanitized
DEBUG - 2011-07-08 11:29:19 --> Language Class Initialized
DEBUG - 2011-07-08 11:29:19 --> Loader Class Initialized
DEBUG - 2011-07-08 11:29:19 --> Controller Class Initialized
DEBUG - 2011-07-08 11:29:19 --> Model Class Initialized
DEBUG - 2011-07-08 11:29:19 --> Model Class Initialized
DEBUG - 2011-07-08 11:29:19 --> Model Class Initialized
DEBUG - 2011-07-08 11:29:19 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-07-08 11:29:19 --> Database Driver Class Initialized
DEBUG - 2011-07-08 11:29:19 --> File loaded: application/views/table/main.php
DEBUG - 2011-07-08 11:29:19 --> Helper loaded: url_helper
DEBUG - 2011-07-08 11:29:19 --> File loaded: application/views/common/header.php
DEBUG - 2011-07-08 11:29:19 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-07-08 11:29:19 --> File loaded: application/views/common/footer.php
DEBUG - 2011-07-08 11:29:19 --> File loaded: application/views/layout/main.php
DEBUG - 2011-07-08 11:29:19 --> Final output sent to browser
DEBUG - 2011-07-08 11:29:19 --> Total execution time: 0.3992
DEBUG - 2011-07-08 11:29:30 --> Config Class Initialized
DEBUG - 2011-07-08 11:29:30 --> Hooks Class Initialized
DEBUG - 2011-07-08 11:29:30 --> Utf8 Class Initialized
DEBUG - 2011-07-08 11:29:30 --> UTF-8 Support Enabled
DEBUG - 2011-07-08 11:29:30 --> URI Class Initialized
DEBUG - 2011-07-08 11:29:30 --> Router Class Initialized
DEBUG - 2011-07-08 11:29:30 --> Output Class Initialized
DEBUG - 2011-07-08 11:29:30 --> Input Class Initialized
DEBUG - 2011-07-08 11:29:30 --> Global POST and COOKIE data sanitized
DEBUG - 2011-07-08 11:29:30 --> Language Class Initialized
DEBUG - 2011-07-08 11:29:30 --> Loader Class Initialized
DEBUG - 2011-07-08 11:29:30 --> Controller Class Initialized
DEBUG - 2011-07-08 11:29:30 --> Model Class Initialized
DEBUG - 2011-07-08 11:29:30 --> Model Class Initialized
DEBUG - 2011-07-08 11:29:30 --> Model Class Initialized
DEBUG - 2011-07-08 11:29:30 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-07-08 11:29:30 --> Database Driver Class Initialized
DEBUG - 2011-07-08 11:29:30 --> File loaded: application/views/table/main.php
DEBUG - 2011-07-08 11:29:30 --> Helper loaded: url_helper
DEBUG - 2011-07-08 11:29:30 --> File loaded: application/views/common/header.php
DEBUG - 2011-07-08 11:29:30 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-07-08 11:29:30 --> File loaded: application/views/common/footer.php
DEBUG - 2011-07-08 11:29:30 --> File loaded: application/views/layout/main.php
DEBUG - 2011-07-08 11:29:30 --> Final output sent to browser
DEBUG - 2011-07-08 11:29:30 --> Total execution time: 0.0526
DEBUG - 2011-07-08 11:29:40 --> Config Class Initialized
DEBUG - 2011-07-08 11:29:40 --> Hooks Class Initialized
DEBUG - 2011-07-08 11:29:40 --> Utf8 Class Initialized
DEBUG - 2011-07-08 11:29:40 --> UTF-8 Support Enabled
DEBUG - 2011-07-08 11:29:40 --> URI Class Initialized
DEBUG - 2011-07-08 11:29:40 --> Router Class Initialized
DEBUG - 2011-07-08 11:29:40 --> Output Class Initialized
DEBUG - 2011-07-08 11:29:40 --> Input Class Initialized
DEBUG - 2011-07-08 11:29:40 --> Global POST and COOKIE data sanitized
DEBUG - 2011-07-08 11:29:40 --> Language Class Initialized
DEBUG - 2011-07-08 11:29:40 --> Loader Class Initialized
DEBUG - 2011-07-08 11:29:40 --> Controller Class Initialized
DEBUG - 2011-07-08 11:29:40 --> Model Class Initialized
DEBUG - 2011-07-08 11:29:40 --> Model Class Initialized
DEBUG - 2011-07-08 11:29:40 --> Model Class Initialized
DEBUG - 2011-07-08 11:29:40 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-07-08 11:29:40 --> Database Driver Class Initialized
DEBUG - 2011-07-08 11:29:41 --> File loaded: application/views/table/main.php
DEBUG - 2011-07-08 11:29:41 --> Helper loaded: url_helper
DEBUG - 2011-07-08 11:29:41 --> File loaded: application/views/common/header.php
DEBUG - 2011-07-08 11:29:41 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-07-08 11:29:41 --> File loaded: application/views/common/footer.php
DEBUG - 2011-07-08 11:29:41 --> File loaded: application/views/layout/main.php
DEBUG - 2011-07-08 11:29:41 --> Final output sent to browser
DEBUG - 2011-07-08 11:29:41 --> Total execution time: 0.3850
DEBUG - 2011-07-08 11:29:44 --> Config Class Initialized
DEBUG - 2011-07-08 11:29:44 --> Hooks Class Initialized
DEBUG - 2011-07-08 11:29:44 --> Utf8 Class Initialized
DEBUG - 2011-07-08 11:29:44 --> UTF-8 Support Enabled
DEBUG - 2011-07-08 11:29:44 --> URI Class Initialized
DEBUG - 2011-07-08 11:29:44 --> Router Class Initialized
DEBUG - 2011-07-08 11:29:44 --> Output Class Initialized
DEBUG - 2011-07-08 11:29:44 --> Input Class Initialized
DEBUG - 2011-07-08 11:29:44 --> Global POST and COOKIE data sanitized
DEBUG - 2011-07-08 11:29:44 --> Language Class Initialized
DEBUG - 2011-07-08 11:29:44 --> Loader Class Initialized
DEBUG - 2011-07-08 11:29:44 --> Controller Class Initialized
DEBUG - 2011-07-08 11:29:44 --> Model Class Initialized
DEBUG - 2011-07-08 11:29:44 --> Model Class Initialized
DEBUG - 2011-07-08 11:29:44 --> Model Class Initialized
DEBUG - 2011-07-08 11:29:44 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-07-08 11:29:44 --> Database Driver Class Initialized
DEBUG - 2011-07-08 11:29:44 --> File loaded: application/views/table/main.php
DEBUG - 2011-07-08 11:29:44 --> Helper loaded: url_helper
DEBUG - 2011-07-08 11:29:44 --> File loaded: application/views/common/header.php
DEBUG - 2011-07-08 11:29:44 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-07-08 11:29:44 --> File loaded: application/views/common/footer.php
DEBUG - 2011-07-08 11:29:44 --> File loaded: application/views/layout/main.php
DEBUG - 2011-07-08 11:29:44 --> Final output sent to browser
DEBUG - 2011-07-08 11:29:44 --> Total execution time: 0.0460
DEBUG - 2011-07-08 11:29:52 --> Config Class Initialized
DEBUG - 2011-07-08 11:29:52 --> Hooks Class Initialized
DEBUG - 2011-07-08 11:29:52 --> Utf8 Class Initialized
DEBUG - 2011-07-08 11:29:52 --> UTF-8 Support Enabled
DEBUG - 2011-07-08 11:29:52 --> URI Class Initialized
DEBUG - 2011-07-08 11:29:52 --> Router Class Initialized
DEBUG - 2011-07-08 11:29:52 --> Output Class Initialized
DEBUG - 2011-07-08 11:29:52 --> Input Class Initialized
DEBUG - 2011-07-08 11:29:52 --> Global POST and COOKIE data sanitized
DEBUG - 2011-07-08 11:29:52 --> Language Class Initialized
DEBUG - 2011-07-08 11:29:52 --> Loader Class Initialized
DEBUG - 2011-07-08 11:29:52 --> Controller Class Initialized
DEBUG - 2011-07-08 11:29:52 --> Model Class Initialized
DEBUG - 2011-07-08 11:29:52 --> Model Class Initialized
DEBUG - 2011-07-08 11:29:52 --> Model Class Initialized
DEBUG - 2011-07-08 11:29:52 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-07-08 11:29:52 --> Database Driver Class Initialized
DEBUG - 2011-07-08 11:29:53 --> File loaded: application/views/table/main.php
DEBUG - 2011-07-08 11:29:53 --> Helper loaded: url_helper
DEBUG - 2011-07-08 11:29:53 --> File loaded: application/views/common/header.php
DEBUG - 2011-07-08 11:29:53 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-07-08 11:29:53 --> File loaded: application/views/common/footer.php
DEBUG - 2011-07-08 11:29:53 --> File loaded: application/views/layout/main.php
DEBUG - 2011-07-08 11:29:53 --> Final output sent to browser
DEBUG - 2011-07-08 11:29:53 --> Total execution time: 0.6791
DEBUG - 2011-07-08 11:29:56 --> Config Class Initialized
DEBUG - 2011-07-08 11:29:56 --> Hooks Class Initialized
DEBUG - 2011-07-08 11:29:56 --> Utf8 Class Initialized
DEBUG - 2011-07-08 11:29:56 --> UTF-8 Support Enabled
DEBUG - 2011-07-08 11:29:56 --> URI Class Initialized
DEBUG - 2011-07-08 11:29:56 --> Router Class Initialized
DEBUG - 2011-07-08 11:29:56 --> Output Class Initialized
DEBUG - 2011-07-08 11:29:56 --> Input Class Initialized
DEBUG - 2011-07-08 11:29:56 --> Global POST and COOKIE data sanitized
DEBUG - 2011-07-08 11:29:56 --> Language Class Initialized
DEBUG - 2011-07-08 11:29:56 --> Loader Class Initialized
DEBUG - 2011-07-08 11:29:56 --> Controller Class Initialized
DEBUG - 2011-07-08 11:29:56 --> Model Class Initialized
DEBUG - 2011-07-08 11:29:56 --> Model Class Initialized
DEBUG - 2011-07-08 11:29:56 --> Model Class Initialized
DEBUG - 2011-07-08 11:29:56 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-07-08 11:29:56 --> Database Driver Class Initialized
DEBUG - 2011-07-08 11:29:57 --> File loaded: application/views/table/main.php
DEBUG - 2011-07-08 11:29:57 --> Helper loaded: url_helper
DEBUG - 2011-07-08 11:29:57 --> File loaded: application/views/common/header.php
DEBUG - 2011-07-08 11:29:57 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-07-08 11:29:57 --> File loaded: application/views/common/footer.php
DEBUG - 2011-07-08 11:29:57 --> File loaded: application/views/layout/main.php
DEBUG - 2011-07-08 11:29:57 --> Final output sent to browser
DEBUG - 2011-07-08 11:29:57 --> Total execution time: 0.0564
DEBUG - 2011-07-08 11:30:05 --> Config Class Initialized
DEBUG - 2011-07-08 11:30:05 --> Hooks Class Initialized
DEBUG - 2011-07-08 11:30:05 --> Utf8 Class Initialized
DEBUG - 2011-07-08 11:30:05 --> UTF-8 Support Enabled
DEBUG - 2011-07-08 11:30:05 --> URI Class Initialized
DEBUG - 2011-07-08 11:30:05 --> Router Class Initialized
DEBUG - 2011-07-08 11:30:05 --> Output Class Initialized
DEBUG - 2011-07-08 11:30:05 --> Input Class Initialized
DEBUG - 2011-07-08 11:30:05 --> Global POST and COOKIE data sanitized
DEBUG - 2011-07-08 11:30:05 --> Language Class Initialized
DEBUG - 2011-07-08 11:30:05 --> Loader Class Initialized
DEBUG - 2011-07-08 11:30:05 --> Controller Class Initialized
DEBUG - 2011-07-08 11:30:05 --> Model Class Initialized
DEBUG - 2011-07-08 11:30:05 --> Model Class Initialized
DEBUG - 2011-07-08 11:30:05 --> Model Class Initialized
DEBUG - 2011-07-08 11:30:05 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-07-08 11:30:05 --> Database Driver Class Initialized
DEBUG - 2011-07-08 11:30:07 --> File loaded: application/views/table/main.php
DEBUG - 2011-07-08 11:30:07 --> Helper loaded: url_helper
DEBUG - 2011-07-08 11:30:07 --> File loaded: application/views/common/header.php
DEBUG - 2011-07-08 11:30:07 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-07-08 11:30:07 --> File loaded: application/views/common/footer.php
DEBUG - 2011-07-08 11:30:07 --> File loaded: application/views/layout/main.php
DEBUG - 2011-07-08 11:30:07 --> Final output sent to browser
DEBUG - 2011-07-08 11:30:07 --> Total execution time: 1.8548
DEBUG - 2011-07-08 11:30:13 --> Config Class Initialized
DEBUG - 2011-07-08 11:30:13 --> Hooks Class Initialized
DEBUG - 2011-07-08 11:30:13 --> Utf8 Class Initialized
DEBUG - 2011-07-08 11:30:13 --> UTF-8 Support Enabled
DEBUG - 2011-07-08 11:30:13 --> URI Class Initialized
DEBUG - 2011-07-08 11:30:13 --> Router Class Initialized
DEBUG - 2011-07-08 11:30:13 --> Output Class Initialized
DEBUG - 2011-07-08 11:30:13 --> Input Class Initialized
DEBUG - 2011-07-08 11:30:13 --> Global POST and COOKIE data sanitized
DEBUG - 2011-07-08 11:30:13 --> Language Class Initialized
DEBUG - 2011-07-08 11:30:13 --> Loader Class Initialized
DEBUG - 2011-07-08 11:30:13 --> Controller Class Initialized
DEBUG - 2011-07-08 11:30:13 --> Model Class Initialized
DEBUG - 2011-07-08 11:30:13 --> Model Class Initialized
DEBUG - 2011-07-08 11:30:13 --> Model Class Initialized
DEBUG - 2011-07-08 11:30:13 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-07-08 11:30:13 --> Database Driver Class Initialized
DEBUG - 2011-07-08 11:30:14 --> File loaded: application/views/table/main.php
DEBUG - 2011-07-08 11:30:14 --> Helper loaded: url_helper
DEBUG - 2011-07-08 11:30:14 --> File loaded: application/views/common/header.php
DEBUG - 2011-07-08 11:30:14 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-07-08 11:30:14 --> File loaded: application/views/common/footer.php
DEBUG - 2011-07-08 11:30:14 --> File loaded: application/views/layout/main.php
DEBUG - 2011-07-08 11:30:14 --> Final output sent to browser
DEBUG - 2011-07-08 11:30:14 --> Total execution time: 0.2185
DEBUG - 2011-07-08 11:30:17 --> Config Class Initialized
DEBUG - 2011-07-08 11:30:17 --> Hooks Class Initialized
DEBUG - 2011-07-08 11:30:17 --> Utf8 Class Initialized
DEBUG - 2011-07-08 11:30:17 --> UTF-8 Support Enabled
DEBUG - 2011-07-08 11:30:17 --> URI Class Initialized
DEBUG - 2011-07-08 11:30:17 --> Router Class Initialized
DEBUG - 2011-07-08 11:30:17 --> Output Class Initialized
DEBUG - 2011-07-08 11:30:17 --> Input Class Initialized
DEBUG - 2011-07-08 11:30:17 --> Global POST and COOKIE data sanitized
DEBUG - 2011-07-08 11:30:17 --> Language Class Initialized
DEBUG - 2011-07-08 11:30:17 --> Loader Class Initialized
DEBUG - 2011-07-08 11:30:17 --> Controller Class Initialized
DEBUG - 2011-07-08 11:30:17 --> Model Class Initialized
DEBUG - 2011-07-08 11:30:17 --> Model Class Initialized
DEBUG - 2011-07-08 11:30:17 --> Model Class Initialized
DEBUG - 2011-07-08 11:30:17 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-07-08 11:30:17 --> Database Driver Class Initialized
DEBUG - 2011-07-08 11:30:17 --> File loaded: application/views/table/main.php
DEBUG - 2011-07-08 11:30:17 --> Helper loaded: url_helper
DEBUG - 2011-07-08 11:30:17 --> File loaded: application/views/common/header.php
DEBUG - 2011-07-08 11:30:17 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-07-08 11:30:17 --> File loaded: application/views/common/footer.php
DEBUG - 2011-07-08 11:30:17 --> File loaded: application/views/layout/main.php
DEBUG - 2011-07-08 11:30:17 --> Final output sent to browser
DEBUG - 2011-07-08 11:30:17 --> Total execution time: 0.1962
DEBUG - 2011-07-08 11:30:23 --> Config Class Initialized
DEBUG - 2011-07-08 11:30:23 --> Hooks Class Initialized
DEBUG - 2011-07-08 11:30:23 --> Utf8 Class Initialized
DEBUG - 2011-07-08 11:30:23 --> UTF-8 Support Enabled
DEBUG - 2011-07-08 11:30:23 --> URI Class Initialized
DEBUG - 2011-07-08 11:30:23 --> Router Class Initialized
DEBUG - 2011-07-08 11:30:23 --> Output Class Initialized
DEBUG - 2011-07-08 11:30:23 --> Input Class Initialized
DEBUG - 2011-07-08 11:30:23 --> Global POST and COOKIE data sanitized
DEBUG - 2011-07-08 11:30:23 --> Language Class Initialized
DEBUG - 2011-07-08 11:30:23 --> Loader Class Initialized
DEBUG - 2011-07-08 11:30:23 --> Controller Class Initialized
DEBUG - 2011-07-08 11:30:23 --> Model Class Initialized
DEBUG - 2011-07-08 11:30:23 --> Model Class Initialized
DEBUG - 2011-07-08 11:30:23 --> Model Class Initialized
DEBUG - 2011-07-08 11:30:23 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-07-08 11:30:23 --> Database Driver Class Initialized
DEBUG - 2011-07-08 11:30:24 --> File loaded: application/views/table/main.php
DEBUG - 2011-07-08 11:30:24 --> Helper loaded: url_helper
DEBUG - 2011-07-08 11:30:24 --> File loaded: application/views/common/header.php
DEBUG - 2011-07-08 11:30:24 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-07-08 11:30:24 --> File loaded: application/views/common/footer.php
DEBUG - 2011-07-08 11:30:24 --> File loaded: application/views/layout/main.php
DEBUG - 2011-07-08 11:30:24 --> Final output sent to browser
DEBUG - 2011-07-08 11:30:24 --> Total execution time: 0.0724
DEBUG - 2011-07-08 11:30:26 --> Config Class Initialized
DEBUG - 2011-07-08 11:30:26 --> Hooks Class Initialized
DEBUG - 2011-07-08 11:30:26 --> Utf8 Class Initialized
DEBUG - 2011-07-08 11:30:26 --> UTF-8 Support Enabled
DEBUG - 2011-07-08 11:30:26 --> URI Class Initialized
DEBUG - 2011-07-08 11:30:26 --> Router Class Initialized
DEBUG - 2011-07-08 11:30:26 --> Output Class Initialized
DEBUG - 2011-07-08 11:30:26 --> Input Class Initialized
DEBUG - 2011-07-08 11:30:26 --> Global POST and COOKIE data sanitized
DEBUG - 2011-07-08 11:30:26 --> Language Class Initialized
DEBUG - 2011-07-08 11:30:26 --> Loader Class Initialized
DEBUG - 2011-07-08 11:30:26 --> Controller Class Initialized
DEBUG - 2011-07-08 11:30:26 --> Model Class Initialized
DEBUG - 2011-07-08 11:30:26 --> Model Class Initialized
DEBUG - 2011-07-08 11:30:26 --> Model Class Initialized
DEBUG - 2011-07-08 11:30:26 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-07-08 11:30:27 --> Database Driver Class Initialized
DEBUG - 2011-07-08 11:30:27 --> File loaded: application/views/table/main.php
DEBUG - 2011-07-08 11:30:27 --> Helper loaded: url_helper
DEBUG - 2011-07-08 11:30:27 --> File loaded: application/views/common/header.php
DEBUG - 2011-07-08 11:30:27 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-07-08 11:30:27 --> File loaded: application/views/common/footer.php
DEBUG - 2011-07-08 11:30:27 --> File loaded: application/views/layout/main.php
DEBUG - 2011-07-08 11:30:27 --> Final output sent to browser
DEBUG - 2011-07-08 11:30:27 --> Total execution time: 0.3582
DEBUG - 2011-07-08 11:30:30 --> Config Class Initialized
DEBUG - 2011-07-08 11:30:30 --> Hooks Class Initialized
DEBUG - 2011-07-08 11:30:30 --> Utf8 Class Initialized
DEBUG - 2011-07-08 11:30:30 --> UTF-8 Support Enabled
DEBUG - 2011-07-08 11:30:30 --> URI Class Initialized
DEBUG - 2011-07-08 11:30:30 --> Router Class Initialized
DEBUG - 2011-07-08 11:30:30 --> Output Class Initialized
DEBUG - 2011-07-08 11:30:30 --> Input Class Initialized
DEBUG - 2011-07-08 11:30:30 --> Global POST and COOKIE data sanitized
DEBUG - 2011-07-08 11:30:30 --> Language Class Initialized
DEBUG - 2011-07-08 11:30:30 --> Loader Class Initialized
DEBUG - 2011-07-08 11:30:30 --> Controller Class Initialized
DEBUG - 2011-07-08 11:30:30 --> Model Class Initialized
DEBUG - 2011-07-08 11:30:30 --> Model Class Initialized
DEBUG - 2011-07-08 11:30:30 --> Model Class Initialized
DEBUG - 2011-07-08 11:30:30 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-07-08 11:30:30 --> Database Driver Class Initialized
DEBUG - 2011-07-08 11:30:30 --> File loaded: application/views/table/main.php
DEBUG - 2011-07-08 11:30:30 --> Helper loaded: url_helper
DEBUG - 2011-07-08 11:30:30 --> File loaded: application/views/common/header.php
DEBUG - 2011-07-08 11:30:30 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-07-08 11:30:30 --> File loaded: application/views/common/footer.php
DEBUG - 2011-07-08 11:30:30 --> File loaded: application/views/layout/main.php
DEBUG - 2011-07-08 11:30:30 --> Final output sent to browser
DEBUG - 2011-07-08 11:30:30 --> Total execution time: 0.0431
DEBUG - 2011-07-08 11:30:37 --> Config Class Initialized
DEBUG - 2011-07-08 11:30:37 --> Hooks Class Initialized
DEBUG - 2011-07-08 11:30:37 --> Utf8 Class Initialized
DEBUG - 2011-07-08 11:30:37 --> UTF-8 Support Enabled
DEBUG - 2011-07-08 11:30:37 --> URI Class Initialized
DEBUG - 2011-07-08 11:30:37 --> Router Class Initialized
DEBUG - 2011-07-08 11:30:37 --> Output Class Initialized
DEBUG - 2011-07-08 11:30:37 --> Input Class Initialized
DEBUG - 2011-07-08 11:30:37 --> Global POST and COOKIE data sanitized
DEBUG - 2011-07-08 11:30:37 --> Language Class Initialized
DEBUG - 2011-07-08 11:30:37 --> Loader Class Initialized
DEBUG - 2011-07-08 11:30:37 --> Controller Class Initialized
DEBUG - 2011-07-08 11:30:37 --> Model Class Initialized
DEBUG - 2011-07-08 11:30:37 --> Model Class Initialized
DEBUG - 2011-07-08 11:30:37 --> Model Class Initialized
DEBUG - 2011-07-08 11:30:37 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-07-08 11:30:37 --> Database Driver Class Initialized
DEBUG - 2011-07-08 11:30:37 --> File loaded: application/views/table/main.php
DEBUG - 2011-07-08 11:30:37 --> Helper loaded: url_helper
DEBUG - 2011-07-08 11:30:37 --> File loaded: application/views/common/header.php
DEBUG - 2011-07-08 11:30:37 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-07-08 11:30:37 --> File loaded: application/views/common/footer.php
DEBUG - 2011-07-08 11:30:37 --> File loaded: application/views/layout/main.php
DEBUG - 2011-07-08 11:30:37 --> Final output sent to browser
DEBUG - 2011-07-08 11:30:37 --> Total execution time: 0.4870
DEBUG - 2011-07-08 11:30:39 --> Config Class Initialized
DEBUG - 2011-07-08 11:30:39 --> Hooks Class Initialized
DEBUG - 2011-07-08 11:30:39 --> Utf8 Class Initialized
DEBUG - 2011-07-08 11:30:39 --> UTF-8 Support Enabled
DEBUG - 2011-07-08 11:30:39 --> URI Class Initialized
DEBUG - 2011-07-08 11:30:39 --> Router Class Initialized
DEBUG - 2011-07-08 11:30:39 --> Output Class Initialized
DEBUG - 2011-07-08 11:30:39 --> Input Class Initialized
DEBUG - 2011-07-08 11:30:39 --> Global POST and COOKIE data sanitized
DEBUG - 2011-07-08 11:30:39 --> Language Class Initialized
DEBUG - 2011-07-08 11:30:39 --> Loader Class Initialized
DEBUG - 2011-07-08 11:30:39 --> Controller Class Initialized
DEBUG - 2011-07-08 11:30:39 --> Model Class Initialized
DEBUG - 2011-07-08 11:30:39 --> Model Class Initialized
DEBUG - 2011-07-08 11:30:39 --> Model Class Initialized
DEBUG - 2011-07-08 11:30:39 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-07-08 11:30:39 --> Database Driver Class Initialized
DEBUG - 2011-07-08 11:30:39 --> File loaded: application/views/table/main.php
DEBUG - 2011-07-08 11:30:39 --> Helper loaded: url_helper
DEBUG - 2011-07-08 11:30:39 --> File loaded: application/views/common/header.php
DEBUG - 2011-07-08 11:30:39 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-07-08 11:30:39 --> File loaded: application/views/common/footer.php
DEBUG - 2011-07-08 11:30:39 --> File loaded: application/views/layout/main.php
DEBUG - 2011-07-08 11:30:39 --> Final output sent to browser
DEBUG - 2011-07-08 11:30:39 --> Total execution time: 0.0492
DEBUG - 2011-07-08 11:30:40 --> Config Class Initialized
DEBUG - 2011-07-08 11:30:40 --> Hooks Class Initialized
DEBUG - 2011-07-08 11:30:40 --> Utf8 Class Initialized
DEBUG - 2011-07-08 11:30:40 --> UTF-8 Support Enabled
DEBUG - 2011-07-08 11:30:40 --> URI Class Initialized
DEBUG - 2011-07-08 11:30:40 --> Router Class Initialized
DEBUG - 2011-07-08 11:30:40 --> Output Class Initialized
DEBUG - 2011-07-08 11:30:40 --> Input Class Initialized
DEBUG - 2011-07-08 11:30:40 --> Global POST and COOKIE data sanitized
DEBUG - 2011-07-08 11:30:40 --> Language Class Initialized
DEBUG - 2011-07-08 11:30:40 --> Loader Class Initialized
DEBUG - 2011-07-08 11:30:40 --> Controller Class Initialized
DEBUG - 2011-07-08 11:30:40 --> Model Class Initialized
DEBUG - 2011-07-08 11:30:40 --> Model Class Initialized
DEBUG - 2011-07-08 11:30:40 --> Model Class Initialized
DEBUG - 2011-07-08 11:30:40 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-07-08 11:30:40 --> Database Driver Class Initialized
DEBUG - 2011-07-08 11:30:40 --> File loaded: application/views/table/main.php
DEBUG - 2011-07-08 11:30:40 --> Helper loaded: url_helper
DEBUG - 2011-07-08 11:30:40 --> File loaded: application/views/common/header.php
DEBUG - 2011-07-08 11:30:40 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-07-08 11:30:40 --> File loaded: application/views/common/footer.php
DEBUG - 2011-07-08 11:30:40 --> File loaded: application/views/layout/main.php
DEBUG - 2011-07-08 11:30:40 --> Final output sent to browser
DEBUG - 2011-07-08 11:30:40 --> Total execution time: 0.0474
DEBUG - 2011-07-08 11:30:49 --> Config Class Initialized
DEBUG - 2011-07-08 11:30:49 --> Hooks Class Initialized
DEBUG - 2011-07-08 11:30:49 --> Utf8 Class Initialized
DEBUG - 2011-07-08 11:30:49 --> UTF-8 Support Enabled
DEBUG - 2011-07-08 11:30:49 --> URI Class Initialized
DEBUG - 2011-07-08 11:30:49 --> Router Class Initialized
DEBUG - 2011-07-08 11:30:49 --> Output Class Initialized
DEBUG - 2011-07-08 11:30:49 --> Input Class Initialized
DEBUG - 2011-07-08 11:30:49 --> Global POST and COOKIE data sanitized
DEBUG - 2011-07-08 11:30:49 --> Language Class Initialized
DEBUG - 2011-07-08 11:30:49 --> Loader Class Initialized
DEBUG - 2011-07-08 11:30:49 --> Controller Class Initialized
DEBUG - 2011-07-08 11:30:49 --> Model Class Initialized
DEBUG - 2011-07-08 11:30:49 --> Model Class Initialized
DEBUG - 2011-07-08 11:30:49 --> Model Class Initialized
DEBUG - 2011-07-08 11:30:49 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-07-08 11:30:49 --> Database Driver Class Initialized
DEBUG - 2011-07-08 11:30:50 --> File loaded: application/views/table/main.php
DEBUG - 2011-07-08 11:30:50 --> Helper loaded: url_helper
DEBUG - 2011-07-08 11:30:50 --> File loaded: application/views/common/header.php
DEBUG - 2011-07-08 11:30:50 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-07-08 11:30:50 --> File loaded: application/views/common/footer.php
DEBUG - 2011-07-08 11:30:50 --> File loaded: application/views/layout/main.php
DEBUG - 2011-07-08 11:30:50 --> Final output sent to browser
DEBUG - 2011-07-08 11:30:50 --> Total execution time: 0.6083
DEBUG - 2011-07-08 11:30:52 --> Config Class Initialized
DEBUG - 2011-07-08 11:30:52 --> Hooks Class Initialized
DEBUG - 2011-07-08 11:30:52 --> Utf8 Class Initialized
DEBUG - 2011-07-08 11:30:52 --> UTF-8 Support Enabled
DEBUG - 2011-07-08 11:30:52 --> URI Class Initialized
DEBUG - 2011-07-08 11:30:52 --> Router Class Initialized
DEBUG - 2011-07-08 11:30:52 --> Output Class Initialized
DEBUG - 2011-07-08 11:30:52 --> Input Class Initialized
DEBUG - 2011-07-08 11:30:52 --> Global POST and COOKIE data sanitized
DEBUG - 2011-07-08 11:30:52 --> Language Class Initialized
DEBUG - 2011-07-08 11:30:52 --> Loader Class Initialized
DEBUG - 2011-07-08 11:30:52 --> Controller Class Initialized
DEBUG - 2011-07-08 11:30:52 --> Model Class Initialized
DEBUG - 2011-07-08 11:30:52 --> Model Class Initialized
DEBUG - 2011-07-08 11:30:52 --> Model Class Initialized
DEBUG - 2011-07-08 11:30:52 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-07-08 11:30:52 --> Database Driver Class Initialized
DEBUG - 2011-07-08 11:30:52 --> File loaded: application/views/table/main.php
DEBUG - 2011-07-08 11:30:52 --> Helper loaded: url_helper
DEBUG - 2011-07-08 11:30:52 --> File loaded: application/views/common/header.php
DEBUG - 2011-07-08 11:30:52 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-07-08 11:30:52 --> File loaded: application/views/common/footer.php
DEBUG - 2011-07-08 11:30:52 --> File loaded: application/views/layout/main.php
DEBUG - 2011-07-08 11:30:52 --> Final output sent to browser
DEBUG - 2011-07-08 11:30:52 --> Total execution time: 0.0741
DEBUG - 2011-07-08 11:30:53 --> Config Class Initialized
DEBUG - 2011-07-08 11:30:53 --> Hooks Class Initialized
DEBUG - 2011-07-08 11:30:53 --> Utf8 Class Initialized
DEBUG - 2011-07-08 11:30:53 --> UTF-8 Support Enabled
DEBUG - 2011-07-08 11:30:53 --> URI Class Initialized
DEBUG - 2011-07-08 11:30:53 --> Router Class Initialized
DEBUG - 2011-07-08 11:30:53 --> Output Class Initialized
DEBUG - 2011-07-08 11:30:53 --> Input Class Initialized
DEBUG - 2011-07-08 11:30:53 --> Global POST and COOKIE data sanitized
DEBUG - 2011-07-08 11:30:53 --> Language Class Initialized
DEBUG - 2011-07-08 11:30:53 --> Loader Class Initialized
DEBUG - 2011-07-08 11:30:53 --> Controller Class Initialized
DEBUG - 2011-07-08 11:30:53 --> Model Class Initialized
DEBUG - 2011-07-08 11:30:53 --> Model Class Initialized
DEBUG - 2011-07-08 11:30:53 --> Model Class Initialized
DEBUG - 2011-07-08 11:30:53 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-07-08 11:30:53 --> Database Driver Class Initialized
DEBUG - 2011-07-08 11:30:53 --> File loaded: application/views/table/main.php
DEBUG - 2011-07-08 11:30:53 --> Helper loaded: url_helper
DEBUG - 2011-07-08 11:30:53 --> File loaded: application/views/common/header.php
DEBUG - 2011-07-08 11:30:53 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-07-08 11:30:53 --> File loaded: application/views/common/footer.php
DEBUG - 2011-07-08 11:30:53 --> File loaded: application/views/layout/main.php
DEBUG - 2011-07-08 11:30:53 --> Final output sent to browser
DEBUG - 2011-07-08 11:30:53 --> Total execution time: 0.0744
DEBUG - 2011-07-08 11:31:03 --> Config Class Initialized
DEBUG - 2011-07-08 11:31:03 --> Hooks Class Initialized
DEBUG - 2011-07-08 11:31:03 --> Utf8 Class Initialized
DEBUG - 2011-07-08 11:31:03 --> UTF-8 Support Enabled
DEBUG - 2011-07-08 11:31:03 --> URI Class Initialized
DEBUG - 2011-07-08 11:31:03 --> Router Class Initialized
DEBUG - 2011-07-08 11:31:03 --> Output Class Initialized
DEBUG - 2011-07-08 11:31:03 --> Input Class Initialized
DEBUG - 2011-07-08 11:31:03 --> Global POST and COOKIE data sanitized
DEBUG - 2011-07-08 11:31:03 --> Language Class Initialized
DEBUG - 2011-07-08 11:31:03 --> Loader Class Initialized
DEBUG - 2011-07-08 11:31:03 --> Controller Class Initialized
DEBUG - 2011-07-08 11:31:03 --> Model Class Initialized
DEBUG - 2011-07-08 11:31:03 --> Model Class Initialized
DEBUG - 2011-07-08 11:31:03 --> Model Class Initialized
DEBUG - 2011-07-08 11:31:03 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-07-08 11:31:03 --> Database Driver Class Initialized
DEBUG - 2011-07-08 11:31:03 --> File loaded: application/views/table/main.php
DEBUG - 2011-07-08 11:31:03 --> Helper loaded: url_helper
DEBUG - 2011-07-08 11:31:03 --> File loaded: application/views/common/header.php
DEBUG - 2011-07-08 11:31:03 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-07-08 11:31:03 --> File loaded: application/views/common/footer.php
DEBUG - 2011-07-08 11:31:03 --> File loaded: application/views/layout/main.php
DEBUG - 2011-07-08 11:31:03 --> Final output sent to browser
DEBUG - 2011-07-08 11:31:03 --> Total execution time: 0.1777
DEBUG - 2011-07-08 11:31:05 --> Config Class Initialized
DEBUG - 2011-07-08 11:31:05 --> Hooks Class Initialized
DEBUG - 2011-07-08 11:31:05 --> Utf8 Class Initialized
DEBUG - 2011-07-08 11:31:05 --> UTF-8 Support Enabled
DEBUG - 2011-07-08 11:31:05 --> URI Class Initialized
DEBUG - 2011-07-08 11:31:05 --> Router Class Initialized
DEBUG - 2011-07-08 11:31:05 --> Output Class Initialized
DEBUG - 2011-07-08 11:31:05 --> Input Class Initialized
DEBUG - 2011-07-08 11:31:05 --> Global POST and COOKIE data sanitized
DEBUG - 2011-07-08 11:31:05 --> Language Class Initialized
DEBUG - 2011-07-08 11:31:05 --> Loader Class Initialized
DEBUG - 2011-07-08 11:31:05 --> Controller Class Initialized
DEBUG - 2011-07-08 11:31:05 --> Model Class Initialized
DEBUG - 2011-07-08 11:31:05 --> Model Class Initialized
DEBUG - 2011-07-08 11:31:05 --> Model Class Initialized
DEBUG - 2011-07-08 11:31:05 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-07-08 11:31:05 --> Database Driver Class Initialized
DEBUG - 2011-07-08 11:31:05 --> File loaded: application/views/table/main.php
DEBUG - 2011-07-08 11:31:05 --> Helper loaded: url_helper
DEBUG - 2011-07-08 11:31:05 --> File loaded: application/views/common/header.php
DEBUG - 2011-07-08 11:31:05 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-07-08 11:31:05 --> File loaded: application/views/common/footer.php
DEBUG - 2011-07-08 11:31:05 --> File loaded: application/views/layout/main.php
DEBUG - 2011-07-08 11:31:05 --> Final output sent to browser
DEBUG - 2011-07-08 11:31:05 --> Total execution time: 0.0441
DEBUG - 2011-07-08 11:31:15 --> Config Class Initialized
DEBUG - 2011-07-08 11:31:15 --> Hooks Class Initialized
DEBUG - 2011-07-08 11:31:15 --> Utf8 Class Initialized
DEBUG - 2011-07-08 11:31:15 --> UTF-8 Support Enabled
DEBUG - 2011-07-08 11:31:15 --> URI Class Initialized
DEBUG - 2011-07-08 11:31:15 --> Router Class Initialized
DEBUG - 2011-07-08 11:31:15 --> Output Class Initialized
DEBUG - 2011-07-08 11:31:15 --> Input Class Initialized
DEBUG - 2011-07-08 11:31:15 --> Global POST and COOKIE data sanitized
DEBUG - 2011-07-08 11:31:15 --> Language Class Initialized
DEBUG - 2011-07-08 11:31:15 --> Loader Class Initialized
DEBUG - 2011-07-08 11:31:15 --> Controller Class Initialized
DEBUG - 2011-07-08 11:31:15 --> Model Class Initialized
DEBUG - 2011-07-08 11:31:15 --> Model Class Initialized
DEBUG - 2011-07-08 11:31:15 --> Model Class Initialized
DEBUG - 2011-07-08 11:31:15 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-07-08 11:31:15 --> Database Driver Class Initialized
DEBUG - 2011-07-08 11:31:15 --> File loaded: application/views/table/main.php
DEBUG - 2011-07-08 11:31:15 --> Helper loaded: url_helper
DEBUG - 2011-07-08 11:31:15 --> File loaded: application/views/common/header.php
DEBUG - 2011-07-08 11:31:15 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-07-08 11:31:15 --> File loaded: application/views/common/footer.php
DEBUG - 2011-07-08 11:31:15 --> File loaded: application/views/layout/main.php
DEBUG - 2011-07-08 11:31:15 --> Final output sent to browser
DEBUG - 2011-07-08 11:31:15 --> Total execution time: 0.2508
DEBUG - 2011-07-08 11:31:17 --> Config Class Initialized
DEBUG - 2011-07-08 11:31:17 --> Hooks Class Initialized
DEBUG - 2011-07-08 11:31:17 --> Utf8 Class Initialized
DEBUG - 2011-07-08 11:31:17 --> UTF-8 Support Enabled
DEBUG - 2011-07-08 11:31:17 --> URI Class Initialized
DEBUG - 2011-07-08 11:31:17 --> Router Class Initialized
DEBUG - 2011-07-08 11:31:17 --> Output Class Initialized
DEBUG - 2011-07-08 11:31:17 --> Input Class Initialized
DEBUG - 2011-07-08 11:31:17 --> Global POST and COOKIE data sanitized
DEBUG - 2011-07-08 11:31:17 --> Language Class Initialized
DEBUG - 2011-07-08 11:31:17 --> Loader Class Initialized
DEBUG - 2011-07-08 11:31:17 --> Controller Class Initialized
DEBUG - 2011-07-08 11:31:17 --> Model Class Initialized
DEBUG - 2011-07-08 11:31:17 --> Model Class Initialized
DEBUG - 2011-07-08 11:31:17 --> Model Class Initialized
DEBUG - 2011-07-08 11:31:17 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-07-08 11:31:17 --> Database Driver Class Initialized
DEBUG - 2011-07-08 11:31:17 --> File loaded: application/views/table/main.php
DEBUG - 2011-07-08 11:31:17 --> Helper loaded: url_helper
DEBUG - 2011-07-08 11:31:17 --> File loaded: application/views/common/header.php
DEBUG - 2011-07-08 11:31:17 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-07-08 11:31:17 --> File loaded: application/views/common/footer.php
DEBUG - 2011-07-08 11:31:17 --> File loaded: application/views/layout/main.php
DEBUG - 2011-07-08 11:31:17 --> Final output sent to browser
DEBUG - 2011-07-08 11:31:17 --> Total execution time: 0.0445
DEBUG - 2011-07-08 11:31:27 --> Config Class Initialized
DEBUG - 2011-07-08 11:31:27 --> Hooks Class Initialized
DEBUG - 2011-07-08 11:31:27 --> Utf8 Class Initialized
DEBUG - 2011-07-08 11:31:27 --> UTF-8 Support Enabled
DEBUG - 2011-07-08 11:31:27 --> URI Class Initialized
DEBUG - 2011-07-08 11:31:27 --> Router Class Initialized
DEBUG - 2011-07-08 11:31:27 --> Output Class Initialized
DEBUG - 2011-07-08 11:31:27 --> Input Class Initialized
DEBUG - 2011-07-08 11:31:27 --> Global POST and COOKIE data sanitized
DEBUG - 2011-07-08 11:31:27 --> Language Class Initialized
DEBUG - 2011-07-08 11:31:27 --> Loader Class Initialized
DEBUG - 2011-07-08 11:31:27 --> Controller Class Initialized
DEBUG - 2011-07-08 11:31:27 --> Model Class Initialized
DEBUG - 2011-07-08 11:31:27 --> Model Class Initialized
DEBUG - 2011-07-08 11:31:27 --> Model Class Initialized
DEBUG - 2011-07-08 11:31:27 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-07-08 11:31:27 --> Database Driver Class Initialized
DEBUG - 2011-07-08 11:31:27 --> File loaded: application/views/table/main.php
DEBUG - 2011-07-08 11:31:27 --> Helper loaded: url_helper
DEBUG - 2011-07-08 11:31:27 --> File loaded: application/views/common/header.php
DEBUG - 2011-07-08 11:31:27 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-07-08 11:31:27 --> File loaded: application/views/common/footer.php
DEBUG - 2011-07-08 11:31:27 --> File loaded: application/views/layout/main.php
DEBUG - 2011-07-08 11:31:27 --> Final output sent to browser
DEBUG - 2011-07-08 11:31:27 --> Total execution time: 0.1386
DEBUG - 2011-07-08 11:31:34 --> Config Class Initialized
DEBUG - 2011-07-08 11:31:34 --> Hooks Class Initialized
DEBUG - 2011-07-08 11:31:34 --> Utf8 Class Initialized
DEBUG - 2011-07-08 11:31:34 --> UTF-8 Support Enabled
DEBUG - 2011-07-08 11:31:34 --> URI Class Initialized
DEBUG - 2011-07-08 11:31:34 --> Router Class Initialized
DEBUG - 2011-07-08 11:31:34 --> Output Class Initialized
DEBUG - 2011-07-08 11:31:34 --> Input Class Initialized
DEBUG - 2011-07-08 11:31:34 --> Global POST and COOKIE data sanitized
DEBUG - 2011-07-08 11:31:34 --> Language Class Initialized
DEBUG - 2011-07-08 11:31:34 --> Loader Class Initialized
DEBUG - 2011-07-08 11:31:34 --> Controller Class Initialized
DEBUG - 2011-07-08 11:31:34 --> Model Class Initialized
DEBUG - 2011-07-08 11:31:34 --> Model Class Initialized
DEBUG - 2011-07-08 11:31:34 --> Model Class Initialized
DEBUG - 2011-07-08 11:31:34 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-07-08 11:31:34 --> Database Driver Class Initialized
DEBUG - 2011-07-08 11:31:34 --> File loaded: application/views/table/main.php
DEBUG - 2011-07-08 11:31:34 --> Helper loaded: url_helper
DEBUG - 2011-07-08 11:31:34 --> File loaded: application/views/common/header.php
DEBUG - 2011-07-08 11:31:34 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-07-08 11:31:34 --> File loaded: application/views/common/footer.php
DEBUG - 2011-07-08 11:31:34 --> File loaded: application/views/layout/main.php
DEBUG - 2011-07-08 11:31:34 --> Final output sent to browser
DEBUG - 2011-07-08 11:31:34 --> Total execution time: 0.1502
DEBUG - 2011-07-08 11:31:37 --> Config Class Initialized
DEBUG - 2011-07-08 11:31:37 --> Hooks Class Initialized
DEBUG - 2011-07-08 11:31:37 --> Utf8 Class Initialized
DEBUG - 2011-07-08 11:31:37 --> UTF-8 Support Enabled
DEBUG - 2011-07-08 11:31:37 --> URI Class Initialized
DEBUG - 2011-07-08 11:31:37 --> Router Class Initialized
DEBUG - 2011-07-08 11:31:37 --> Output Class Initialized
DEBUG - 2011-07-08 11:31:37 --> Input Class Initialized
DEBUG - 2011-07-08 11:31:37 --> Global POST and COOKIE data sanitized
DEBUG - 2011-07-08 11:31:37 --> Language Class Initialized
DEBUG - 2011-07-08 11:31:37 --> Loader Class Initialized
DEBUG - 2011-07-08 11:31:37 --> Controller Class Initialized
DEBUG - 2011-07-08 11:31:37 --> Model Class Initialized
DEBUG - 2011-07-08 11:31:37 --> Model Class Initialized
DEBUG - 2011-07-08 11:31:37 --> Model Class Initialized
DEBUG - 2011-07-08 11:31:37 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-07-08 11:31:37 --> Database Driver Class Initialized
DEBUG - 2011-07-08 11:31:37 --> File loaded: application/views/table/main.php
DEBUG - 2011-07-08 11:31:37 --> Helper loaded: url_helper
DEBUG - 2011-07-08 11:31:37 --> File loaded: application/views/common/header.php
DEBUG - 2011-07-08 11:31:37 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-07-08 11:31:37 --> File loaded: application/views/common/footer.php
DEBUG - 2011-07-08 11:31:37 --> File loaded: application/views/layout/main.php
DEBUG - 2011-07-08 11:31:37 --> Final output sent to browser
DEBUG - 2011-07-08 11:31:37 --> Total execution time: 0.0483
DEBUG - 2011-07-08 11:31:44 --> Config Class Initialized
DEBUG - 2011-07-08 11:31:44 --> Hooks Class Initialized
DEBUG - 2011-07-08 11:31:44 --> Utf8 Class Initialized
DEBUG - 2011-07-08 11:31:44 --> UTF-8 Support Enabled
DEBUG - 2011-07-08 11:31:44 --> URI Class Initialized
DEBUG - 2011-07-08 11:31:44 --> Router Class Initialized
DEBUG - 2011-07-08 11:31:44 --> Output Class Initialized
DEBUG - 2011-07-08 11:31:44 --> Input Class Initialized
DEBUG - 2011-07-08 11:31:44 --> Global POST and COOKIE data sanitized
DEBUG - 2011-07-08 11:31:44 --> Language Class Initialized
DEBUG - 2011-07-08 11:31:44 --> Loader Class Initialized
DEBUG - 2011-07-08 11:31:44 --> Controller Class Initialized
DEBUG - 2011-07-08 11:31:44 --> Model Class Initialized
DEBUG - 2011-07-08 11:31:44 --> Model Class Initialized
DEBUG - 2011-07-08 11:31:44 --> Model Class Initialized
DEBUG - 2011-07-08 11:31:44 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-07-08 11:31:44 --> Database Driver Class Initialized
DEBUG - 2011-07-08 11:31:45 --> File loaded: application/views/table/main.php
DEBUG - 2011-07-08 11:31:45 --> Helper loaded: url_helper
DEBUG - 2011-07-08 11:31:45 --> File loaded: application/views/common/header.php
DEBUG - 2011-07-08 11:31:45 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-07-08 11:31:45 --> File loaded: application/views/common/footer.php
DEBUG - 2011-07-08 11:31:45 --> File loaded: application/views/layout/main.php
DEBUG - 2011-07-08 11:31:45 --> Final output sent to browser
DEBUG - 2011-07-08 11:31:45 --> Total execution time: 0.7255
DEBUG - 2011-07-08 11:31:51 --> Config Class Initialized
DEBUG - 2011-07-08 11:31:51 --> Hooks Class Initialized
DEBUG - 2011-07-08 11:31:51 --> Utf8 Class Initialized
DEBUG - 2011-07-08 11:31:51 --> UTF-8 Support Enabled
DEBUG - 2011-07-08 11:31:51 --> URI Class Initialized
DEBUG - 2011-07-08 11:31:51 --> Router Class Initialized
DEBUG - 2011-07-08 11:31:51 --> Output Class Initialized
DEBUG - 2011-07-08 11:31:51 --> Input Class Initialized
DEBUG - 2011-07-08 11:31:51 --> Global POST and COOKIE data sanitized
DEBUG - 2011-07-08 11:31:51 --> Language Class Initialized
DEBUG - 2011-07-08 11:31:51 --> Loader Class Initialized
DEBUG - 2011-07-08 11:31:51 --> Controller Class Initialized
DEBUG - 2011-07-08 11:31:51 --> Model Class Initialized
DEBUG - 2011-07-08 11:31:51 --> Model Class Initialized
DEBUG - 2011-07-08 11:31:51 --> Model Class Initialized
DEBUG - 2011-07-08 11:31:51 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-07-08 11:31:51 --> Database Driver Class Initialized
DEBUG - 2011-07-08 11:31:51 --> File loaded: application/views/table/main.php
DEBUG - 2011-07-08 11:31:51 --> Helper loaded: url_helper
DEBUG - 2011-07-08 11:31:51 --> File loaded: application/views/common/header.php
DEBUG - 2011-07-08 11:31:51 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-07-08 11:31:51 --> File loaded: application/views/common/footer.php
DEBUG - 2011-07-08 11:31:51 --> File loaded: application/views/layout/main.php
DEBUG - 2011-07-08 11:31:51 --> Final output sent to browser
DEBUG - 2011-07-08 11:31:51 --> Total execution time: 0.0404
DEBUG - 2011-07-08 11:31:55 --> Config Class Initialized
DEBUG - 2011-07-08 11:31:55 --> Hooks Class Initialized
DEBUG - 2011-07-08 11:31:55 --> Utf8 Class Initialized
DEBUG - 2011-07-08 11:31:55 --> UTF-8 Support Enabled
DEBUG - 2011-07-08 11:31:55 --> URI Class Initialized
DEBUG - 2011-07-08 11:31:55 --> Router Class Initialized
DEBUG - 2011-07-08 11:31:55 --> Output Class Initialized
DEBUG - 2011-07-08 11:31:55 --> Input Class Initialized
DEBUG - 2011-07-08 11:31:55 --> Global POST and COOKIE data sanitized
DEBUG - 2011-07-08 11:31:55 --> Language Class Initialized
DEBUG - 2011-07-08 11:31:55 --> Loader Class Initialized
DEBUG - 2011-07-08 11:31:55 --> Controller Class Initialized
DEBUG - 2011-07-08 11:31:55 --> Model Class Initialized
DEBUG - 2011-07-08 11:31:55 --> Model Class Initialized
DEBUG - 2011-07-08 11:31:55 --> Model Class Initialized
DEBUG - 2011-07-08 11:31:55 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-07-08 11:31:55 --> Database Driver Class Initialized
DEBUG - 2011-07-08 11:31:56 --> File loaded: application/views/table/main.php
DEBUG - 2011-07-08 11:31:56 --> Helper loaded: url_helper
DEBUG - 2011-07-08 11:31:56 --> File loaded: application/views/common/header.php
DEBUG - 2011-07-08 11:31:56 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-07-08 11:31:56 --> File loaded: application/views/common/footer.php
DEBUG - 2011-07-08 11:31:56 --> File loaded: application/views/layout/main.php
DEBUG - 2011-07-08 11:31:56 --> Final output sent to browser
DEBUG - 2011-07-08 11:31:56 --> Total execution time: 0.2858
DEBUG - 2011-07-08 11:31:59 --> Config Class Initialized
DEBUG - 2011-07-08 11:31:59 --> Hooks Class Initialized
DEBUG - 2011-07-08 11:31:59 --> Utf8 Class Initialized
DEBUG - 2011-07-08 11:31:59 --> UTF-8 Support Enabled
DEBUG - 2011-07-08 11:31:59 --> URI Class Initialized
DEBUG - 2011-07-08 11:31:59 --> Router Class Initialized
DEBUG - 2011-07-08 11:31:59 --> Output Class Initialized
DEBUG - 2011-07-08 11:31:59 --> Input Class Initialized
DEBUG - 2011-07-08 11:31:59 --> Global POST and COOKIE data sanitized
DEBUG - 2011-07-08 11:31:59 --> Language Class Initialized
DEBUG - 2011-07-08 11:31:59 --> Loader Class Initialized
DEBUG - 2011-07-08 11:31:59 --> Controller Class Initialized
DEBUG - 2011-07-08 11:31:59 --> Model Class Initialized
DEBUG - 2011-07-08 11:31:59 --> Model Class Initialized
DEBUG - 2011-07-08 11:31:59 --> Model Class Initialized
DEBUG - 2011-07-08 11:31:59 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-07-08 11:31:59 --> Database Driver Class Initialized
DEBUG - 2011-07-08 11:31:59 --> File loaded: application/views/table/main.php
DEBUG - 2011-07-08 11:31:59 --> Helper loaded: url_helper
DEBUG - 2011-07-08 11:31:59 --> File loaded: application/views/common/header.php
DEBUG - 2011-07-08 11:31:59 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-07-08 11:31:59 --> File loaded: application/views/common/footer.php
DEBUG - 2011-07-08 11:31:59 --> File loaded: application/views/layout/main.php
DEBUG - 2011-07-08 11:31:59 --> Final output sent to browser
DEBUG - 2011-07-08 11:31:59 --> Total execution time: 0.0453
DEBUG - 2011-07-08 11:32:10 --> Config Class Initialized
DEBUG - 2011-07-08 11:32:10 --> Hooks Class Initialized
DEBUG - 2011-07-08 11:32:10 --> Utf8 Class Initialized
DEBUG - 2011-07-08 11:32:10 --> UTF-8 Support Enabled
DEBUG - 2011-07-08 11:32:10 --> URI Class Initialized
DEBUG - 2011-07-08 11:32:10 --> Router Class Initialized
DEBUG - 2011-07-08 11:32:10 --> Output Class Initialized
DEBUG - 2011-07-08 11:32:10 --> Input Class Initialized
DEBUG - 2011-07-08 11:32:10 --> Global POST and COOKIE data sanitized
DEBUG - 2011-07-08 11:32:10 --> Language Class Initialized
DEBUG - 2011-07-08 11:32:10 --> Loader Class Initialized
DEBUG - 2011-07-08 11:32:10 --> Controller Class Initialized
DEBUG - 2011-07-08 11:32:10 --> Model Class Initialized
DEBUG - 2011-07-08 11:32:10 --> Model Class Initialized
DEBUG - 2011-07-08 11:32:10 --> Model Class Initialized
DEBUG - 2011-07-08 11:32:10 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-07-08 11:32:10 --> Database Driver Class Initialized
DEBUG - 2011-07-08 11:32:11 --> File loaded: application/views/table/main.php
DEBUG - 2011-07-08 11:32:11 --> Helper loaded: url_helper
DEBUG - 2011-07-08 11:32:11 --> File loaded: application/views/common/header.php
DEBUG - 2011-07-08 11:32:11 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-07-08 11:32:11 --> File loaded: application/views/common/footer.php
DEBUG - 2011-07-08 11:32:11 --> File loaded: application/views/layout/main.php
DEBUG - 2011-07-08 11:32:11 --> Final output sent to browser
DEBUG - 2011-07-08 11:32:11 --> Total execution time: 0.4835
DEBUG - 2011-07-08 11:32:13 --> Config Class Initialized
DEBUG - 2011-07-08 11:32:13 --> Hooks Class Initialized
DEBUG - 2011-07-08 11:32:13 --> Utf8 Class Initialized
DEBUG - 2011-07-08 11:32:13 --> UTF-8 Support Enabled
DEBUG - 2011-07-08 11:32:13 --> URI Class Initialized
DEBUG - 2011-07-08 11:32:13 --> Router Class Initialized
DEBUG - 2011-07-08 11:32:13 --> Output Class Initialized
DEBUG - 2011-07-08 11:32:13 --> Input Class Initialized
DEBUG - 2011-07-08 11:32:13 --> Global POST and COOKIE data sanitized
DEBUG - 2011-07-08 11:32:13 --> Language Class Initialized
DEBUG - 2011-07-08 11:32:13 --> Loader Class Initialized
DEBUG - 2011-07-08 11:32:13 --> Controller Class Initialized
DEBUG - 2011-07-08 11:32:13 --> Model Class Initialized
DEBUG - 2011-07-08 11:32:13 --> Model Class Initialized
DEBUG - 2011-07-08 11:32:13 --> Model Class Initialized
DEBUG - 2011-07-08 11:32:13 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-07-08 11:32:13 --> Database Driver Class Initialized
DEBUG - 2011-07-08 11:32:13 --> File loaded: application/views/table/main.php
DEBUG - 2011-07-08 11:32:13 --> Helper loaded: url_helper
DEBUG - 2011-07-08 11:32:13 --> File loaded: application/views/common/header.php
DEBUG - 2011-07-08 11:32:13 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-07-08 11:32:13 --> File loaded: application/views/common/footer.php
DEBUG - 2011-07-08 11:32:13 --> File loaded: application/views/layout/main.php
DEBUG - 2011-07-08 11:32:13 --> Final output sent to browser
DEBUG - 2011-07-08 11:32:13 --> Total execution time: 0.0504
DEBUG - 2011-07-08 11:32:21 --> Config Class Initialized
DEBUG - 2011-07-08 11:32:21 --> Hooks Class Initialized
DEBUG - 2011-07-08 11:32:21 --> Utf8 Class Initialized
DEBUG - 2011-07-08 11:32:21 --> UTF-8 Support Enabled
DEBUG - 2011-07-08 11:32:21 --> URI Class Initialized
DEBUG - 2011-07-08 11:32:21 --> Router Class Initialized
DEBUG - 2011-07-08 11:32:21 --> Output Class Initialized
DEBUG - 2011-07-08 11:32:21 --> Input Class Initialized
DEBUG - 2011-07-08 11:32:21 --> Global POST and COOKIE data sanitized
DEBUG - 2011-07-08 11:32:21 --> Language Class Initialized
DEBUG - 2011-07-08 11:32:21 --> Loader Class Initialized
DEBUG - 2011-07-08 11:32:21 --> Controller Class Initialized
DEBUG - 2011-07-08 11:32:21 --> Model Class Initialized
DEBUG - 2011-07-08 11:32:21 --> Model Class Initialized
DEBUG - 2011-07-08 11:32:21 --> Model Class Initialized
DEBUG - 2011-07-08 11:32:21 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-07-08 11:32:21 --> Database Driver Class Initialized
DEBUG - 2011-07-08 11:32:22 --> File loaded: application/views/table/main.php
DEBUG - 2011-07-08 11:32:22 --> Helper loaded: url_helper
DEBUG - 2011-07-08 11:32:22 --> File loaded: application/views/common/header.php
DEBUG - 2011-07-08 11:32:22 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-07-08 11:32:22 --> File loaded: application/views/common/footer.php
DEBUG - 2011-07-08 11:32:22 --> File loaded: application/views/layout/main.php
DEBUG - 2011-07-08 11:32:22 --> Final output sent to browser
DEBUG - 2011-07-08 11:32:22 --> Total execution time: 0.5529
DEBUG - 2011-07-08 11:32:42 --> Config Class Initialized
DEBUG - 2011-07-08 11:32:42 --> Hooks Class Initialized
DEBUG - 2011-07-08 11:32:42 --> Utf8 Class Initialized
DEBUG - 2011-07-08 11:32:42 --> UTF-8 Support Enabled
DEBUG - 2011-07-08 11:32:42 --> URI Class Initialized
DEBUG - 2011-07-08 11:32:42 --> Router Class Initialized
DEBUG - 2011-07-08 11:32:42 --> Output Class Initialized
DEBUG - 2011-07-08 11:32:42 --> Input Class Initialized
DEBUG - 2011-07-08 11:32:42 --> Global POST and COOKIE data sanitized
DEBUG - 2011-07-08 11:32:42 --> Language Class Initialized
DEBUG - 2011-07-08 11:32:42 --> Loader Class Initialized
DEBUG - 2011-07-08 11:32:42 --> Controller Class Initialized
DEBUG - 2011-07-08 11:32:42 --> Model Class Initialized
DEBUG - 2011-07-08 11:32:42 --> Model Class Initialized
DEBUG - 2011-07-08 11:32:42 --> Model Class Initialized
DEBUG - 2011-07-08 11:32:42 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-07-08 11:32:42 --> Database Driver Class Initialized
DEBUG - 2011-07-08 11:32:42 --> File loaded: application/views/table/main.php
DEBUG - 2011-07-08 11:32:42 --> Helper loaded: url_helper
DEBUG - 2011-07-08 11:32:42 --> File loaded: application/views/common/header.php
DEBUG - 2011-07-08 11:32:42 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-07-08 11:32:42 --> File loaded: application/views/common/footer.php
DEBUG - 2011-07-08 11:32:42 --> File loaded: application/views/layout/main.php
DEBUG - 2011-07-08 11:32:42 --> Final output sent to browser
DEBUG - 2011-07-08 11:32:42 --> Total execution time: 0.0447
DEBUG - 2011-07-08 11:33:01 --> Config Class Initialized
DEBUG - 2011-07-08 11:33:01 --> Hooks Class Initialized
DEBUG - 2011-07-08 11:33:01 --> Utf8 Class Initialized
DEBUG - 2011-07-08 11:33:01 --> UTF-8 Support Enabled
DEBUG - 2011-07-08 11:33:01 --> URI Class Initialized
DEBUG - 2011-07-08 11:33:01 --> Router Class Initialized
DEBUG - 2011-07-08 11:33:01 --> Output Class Initialized
DEBUG - 2011-07-08 11:33:01 --> Input Class Initialized
DEBUG - 2011-07-08 11:33:01 --> Global POST and COOKIE data sanitized
DEBUG - 2011-07-08 11:33:01 --> Language Class Initialized
DEBUG - 2011-07-08 11:33:01 --> Loader Class Initialized
DEBUG - 2011-07-08 11:33:01 --> Controller Class Initialized
DEBUG - 2011-07-08 11:33:01 --> Model Class Initialized
DEBUG - 2011-07-08 11:33:01 --> Model Class Initialized
DEBUG - 2011-07-08 11:33:01 --> Model Class Initialized
DEBUG - 2011-07-08 11:33:01 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-07-08 11:33:01 --> Database Driver Class Initialized
DEBUG - 2011-07-08 11:33:02 --> File loaded: application/views/table/main.php
DEBUG - 2011-07-08 11:33:02 --> Helper loaded: url_helper
DEBUG - 2011-07-08 11:33:02 --> File loaded: application/views/common/header.php
DEBUG - 2011-07-08 11:33:02 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-07-08 11:33:02 --> File loaded: application/views/common/footer.php
DEBUG - 2011-07-08 11:33:02 --> File loaded: application/views/layout/main.php
DEBUG - 2011-07-08 11:33:02 --> Final output sent to browser
DEBUG - 2011-07-08 11:33:02 --> Total execution time: 1.0949
DEBUG - 2011-07-08 11:33:05 --> Config Class Initialized
DEBUG - 2011-07-08 11:33:05 --> Hooks Class Initialized
DEBUG - 2011-07-08 11:33:05 --> Utf8 Class Initialized
DEBUG - 2011-07-08 11:33:05 --> UTF-8 Support Enabled
DEBUG - 2011-07-08 11:33:05 --> URI Class Initialized
DEBUG - 2011-07-08 11:33:05 --> Router Class Initialized
DEBUG - 2011-07-08 11:33:05 --> Output Class Initialized
DEBUG - 2011-07-08 11:33:05 --> Input Class Initialized
DEBUG - 2011-07-08 11:33:05 --> Global POST and COOKIE data sanitized
DEBUG - 2011-07-08 11:33:05 --> Language Class Initialized
DEBUG - 2011-07-08 11:33:05 --> Loader Class Initialized
DEBUG - 2011-07-08 11:33:05 --> Controller Class Initialized
DEBUG - 2011-07-08 11:33:05 --> Model Class Initialized
DEBUG - 2011-07-08 11:33:05 --> Model Class Initialized
DEBUG - 2011-07-08 11:33:05 --> Model Class Initialized
DEBUG - 2011-07-08 11:33:05 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-07-08 11:33:05 --> Database Driver Class Initialized
DEBUG - 2011-07-08 11:33:05 --> File loaded: application/views/table/main.php
DEBUG - 2011-07-08 11:33:05 --> Helper loaded: url_helper
DEBUG - 2011-07-08 11:33:05 --> File loaded: application/views/common/header.php
DEBUG - 2011-07-08 11:33:05 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-07-08 11:33:05 --> File loaded: application/views/common/footer.php
DEBUG - 2011-07-08 11:33:05 --> File loaded: application/views/layout/main.php
DEBUG - 2011-07-08 11:33:05 --> Final output sent to browser
DEBUG - 2011-07-08 11:33:05 --> Total execution time: 0.0462
DEBUG - 2011-07-08 11:33:14 --> Config Class Initialized
DEBUG - 2011-07-08 11:33:14 --> Hooks Class Initialized
DEBUG - 2011-07-08 11:33:14 --> Utf8 Class Initialized
DEBUG - 2011-07-08 11:33:14 --> UTF-8 Support Enabled
DEBUG - 2011-07-08 11:33:14 --> URI Class Initialized
DEBUG - 2011-07-08 11:33:14 --> Router Class Initialized
DEBUG - 2011-07-08 11:33:14 --> Output Class Initialized
DEBUG - 2011-07-08 11:33:14 --> Input Class Initialized
DEBUG - 2011-07-08 11:33:14 --> Global POST and COOKIE data sanitized
DEBUG - 2011-07-08 11:33:14 --> Language Class Initialized
DEBUG - 2011-07-08 11:33:14 --> Loader Class Initialized
DEBUG - 2011-07-08 11:33:14 --> Controller Class Initialized
DEBUG - 2011-07-08 11:33:14 --> Model Class Initialized
DEBUG - 2011-07-08 11:33:14 --> Model Class Initialized
DEBUG - 2011-07-08 11:33:14 --> Model Class Initialized
DEBUG - 2011-07-08 11:33:14 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-07-08 11:33:14 --> Database Driver Class Initialized
DEBUG - 2011-07-08 11:33:15 --> File loaded: application/views/table/main.php
DEBUG - 2011-07-08 11:33:15 --> Helper loaded: url_helper
DEBUG - 2011-07-08 11:33:15 --> File loaded: application/views/common/header.php
DEBUG - 2011-07-08 11:33:15 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-07-08 11:33:15 --> File loaded: application/views/common/footer.php
DEBUG - 2011-07-08 11:33:15 --> File loaded: application/views/layout/main.php
DEBUG - 2011-07-08 11:33:15 --> Final output sent to browser
DEBUG - 2011-07-08 11:33:15 --> Total execution time: 0.8150
DEBUG - 2011-07-08 11:33:17 --> Config Class Initialized
DEBUG - 2011-07-08 11:33:17 --> Hooks Class Initialized
DEBUG - 2011-07-08 11:33:17 --> Utf8 Class Initialized
DEBUG - 2011-07-08 11:33:17 --> UTF-8 Support Enabled
DEBUG - 2011-07-08 11:33:17 --> URI Class Initialized
DEBUG - 2011-07-08 11:33:17 --> Router Class Initialized
DEBUG - 2011-07-08 11:33:17 --> Output Class Initialized
DEBUG - 2011-07-08 11:33:17 --> Input Class Initialized
DEBUG - 2011-07-08 11:33:17 --> Global POST and COOKIE data sanitized
DEBUG - 2011-07-08 11:33:17 --> Language Class Initialized
DEBUG - 2011-07-08 11:33:17 --> Loader Class Initialized
DEBUG - 2011-07-08 11:33:17 --> Controller Class Initialized
DEBUG - 2011-07-08 11:33:17 --> Model Class Initialized
DEBUG - 2011-07-08 11:33:17 --> Model Class Initialized
DEBUG - 2011-07-08 11:33:17 --> Model Class Initialized
DEBUG - 2011-07-08 11:33:17 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-07-08 11:33:17 --> Database Driver Class Initialized
DEBUG - 2011-07-08 11:33:17 --> File loaded: application/views/table/main.php
DEBUG - 2011-07-08 11:33:17 --> Helper loaded: url_helper
DEBUG - 2011-07-08 11:33:17 --> File loaded: application/views/common/header.php
DEBUG - 2011-07-08 11:33:17 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-07-08 11:33:17 --> File loaded: application/views/common/footer.php
DEBUG - 2011-07-08 11:33:17 --> File loaded: application/views/layout/main.php
DEBUG - 2011-07-08 11:33:17 --> Final output sent to browser
DEBUG - 2011-07-08 11:33:17 --> Total execution time: 0.0455
DEBUG - 2011-07-08 11:33:26 --> Config Class Initialized
DEBUG - 2011-07-08 11:33:26 --> Hooks Class Initialized
DEBUG - 2011-07-08 11:33:26 --> Utf8 Class Initialized
DEBUG - 2011-07-08 11:33:26 --> UTF-8 Support Enabled
DEBUG - 2011-07-08 11:33:26 --> URI Class Initialized
DEBUG - 2011-07-08 11:33:26 --> Router Class Initialized
DEBUG - 2011-07-08 11:33:26 --> Output Class Initialized
DEBUG - 2011-07-08 11:33:26 --> Input Class Initialized
DEBUG - 2011-07-08 11:33:26 --> Global POST and COOKIE data sanitized
DEBUG - 2011-07-08 11:33:26 --> Language Class Initialized
DEBUG - 2011-07-08 11:33:26 --> Loader Class Initialized
DEBUG - 2011-07-08 11:33:26 --> Controller Class Initialized
DEBUG - 2011-07-08 11:33:26 --> Model Class Initialized
DEBUG - 2011-07-08 11:33:26 --> Model Class Initialized
DEBUG - 2011-07-08 11:33:26 --> Model Class Initialized
DEBUG - 2011-07-08 11:33:26 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-07-08 11:33:26 --> Database Driver Class Initialized
DEBUG - 2011-07-08 11:33:26 --> File loaded: application/views/table/main.php
DEBUG - 2011-07-08 11:33:26 --> Helper loaded: url_helper
DEBUG - 2011-07-08 11:33:26 --> File loaded: application/views/common/header.php
DEBUG - 2011-07-08 11:33:26 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-07-08 11:33:26 --> File loaded: application/views/common/footer.php
DEBUG - 2011-07-08 11:33:26 --> File loaded: application/views/layout/main.php
DEBUG - 2011-07-08 11:33:26 --> Final output sent to browser
DEBUG - 2011-07-08 11:33:26 --> Total execution time: 0.3464
DEBUG - 2011-07-08 11:33:28 --> Config Class Initialized
DEBUG - 2011-07-08 11:33:28 --> Hooks Class Initialized
DEBUG - 2011-07-08 11:33:28 --> Utf8 Class Initialized
DEBUG - 2011-07-08 11:33:28 --> UTF-8 Support Enabled
DEBUG - 2011-07-08 11:33:28 --> URI Class Initialized
DEBUG - 2011-07-08 11:33:28 --> Router Class Initialized
DEBUG - 2011-07-08 11:33:28 --> Output Class Initialized
DEBUG - 2011-07-08 11:33:28 --> Input Class Initialized
DEBUG - 2011-07-08 11:33:28 --> Global POST and COOKIE data sanitized
DEBUG - 2011-07-08 11:33:28 --> Language Class Initialized
DEBUG - 2011-07-08 11:33:28 --> Loader Class Initialized
DEBUG - 2011-07-08 11:33:28 --> Controller Class Initialized
DEBUG - 2011-07-08 11:33:28 --> Model Class Initialized
DEBUG - 2011-07-08 11:33:28 --> Model Class Initialized
DEBUG - 2011-07-08 11:33:28 --> Model Class Initialized
DEBUG - 2011-07-08 11:33:28 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-07-08 11:33:28 --> Database Driver Class Initialized
DEBUG - 2011-07-08 11:33:28 --> File loaded: application/views/table/main.php
DEBUG - 2011-07-08 11:33:28 --> Helper loaded: url_helper
DEBUG - 2011-07-08 11:33:28 --> File loaded: application/views/common/header.php
DEBUG - 2011-07-08 11:33:28 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-07-08 11:33:28 --> File loaded: application/views/common/footer.php
DEBUG - 2011-07-08 11:33:28 --> File loaded: application/views/layout/main.php
DEBUG - 2011-07-08 11:33:28 --> Final output sent to browser
DEBUG - 2011-07-08 11:33:28 --> Total execution time: 0.0784
DEBUG - 2011-07-08 11:33:36 --> Config Class Initialized
DEBUG - 2011-07-08 11:33:36 --> Hooks Class Initialized
DEBUG - 2011-07-08 11:33:36 --> Utf8 Class Initialized
DEBUG - 2011-07-08 11:33:36 --> UTF-8 Support Enabled
DEBUG - 2011-07-08 11:33:36 --> URI Class Initialized
DEBUG - 2011-07-08 11:33:36 --> Router Class Initialized
DEBUG - 2011-07-08 11:33:36 --> Output Class Initialized
DEBUG - 2011-07-08 11:33:36 --> Input Class Initialized
DEBUG - 2011-07-08 11:33:36 --> Global POST and COOKIE data sanitized
DEBUG - 2011-07-08 11:33:36 --> Language Class Initialized
DEBUG - 2011-07-08 11:33:36 --> Loader Class Initialized
DEBUG - 2011-07-08 11:33:36 --> Controller Class Initialized
DEBUG - 2011-07-08 11:33:36 --> Model Class Initialized
DEBUG - 2011-07-08 11:33:36 --> Model Class Initialized
DEBUG - 2011-07-08 11:33:36 --> Model Class Initialized
DEBUG - 2011-07-08 11:33:36 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-07-08 11:33:36 --> Database Driver Class Initialized
DEBUG - 2011-07-08 11:33:36 --> File loaded: application/views/table/main.php
DEBUG - 2011-07-08 11:33:36 --> Helper loaded: url_helper
DEBUG - 2011-07-08 11:33:36 --> File loaded: application/views/common/header.php
DEBUG - 2011-07-08 11:33:36 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-07-08 11:33:36 --> File loaded: application/views/common/footer.php
DEBUG - 2011-07-08 11:33:36 --> File loaded: application/views/layout/main.php
DEBUG - 2011-07-08 11:33:36 --> Final output sent to browser
DEBUG - 2011-07-08 11:33:36 --> Total execution time: 0.2071
DEBUG - 2011-07-08 11:33:38 --> Config Class Initialized
DEBUG - 2011-07-08 11:33:38 --> Hooks Class Initialized
DEBUG - 2011-07-08 11:33:38 --> Utf8 Class Initialized
DEBUG - 2011-07-08 11:33:38 --> UTF-8 Support Enabled
DEBUG - 2011-07-08 11:33:38 --> URI Class Initialized
DEBUG - 2011-07-08 11:33:38 --> Router Class Initialized
DEBUG - 2011-07-08 11:33:38 --> Output Class Initialized
DEBUG - 2011-07-08 11:33:38 --> Input Class Initialized
DEBUG - 2011-07-08 11:33:38 --> Global POST and COOKIE data sanitized
DEBUG - 2011-07-08 11:33:38 --> Language Class Initialized
DEBUG - 2011-07-08 11:33:38 --> Loader Class Initialized
DEBUG - 2011-07-08 11:33:38 --> Controller Class Initialized
DEBUG - 2011-07-08 11:33:38 --> Model Class Initialized
DEBUG - 2011-07-08 11:33:38 --> Model Class Initialized
DEBUG - 2011-07-08 11:33:38 --> Model Class Initialized
DEBUG - 2011-07-08 11:33:38 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-07-08 11:33:38 --> Database Driver Class Initialized
DEBUG - 2011-07-08 11:33:38 --> File loaded: application/views/table/main.php
DEBUG - 2011-07-08 11:33:38 --> Helper loaded: url_helper
DEBUG - 2011-07-08 11:33:38 --> File loaded: application/views/common/header.php
DEBUG - 2011-07-08 11:33:38 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-07-08 11:33:38 --> File loaded: application/views/common/footer.php
DEBUG - 2011-07-08 11:33:38 --> File loaded: application/views/layout/main.php
DEBUG - 2011-07-08 11:33:38 --> Final output sent to browser
DEBUG - 2011-07-08 11:33:38 --> Total execution time: 0.0457
DEBUG - 2011-07-08 11:33:43 --> Config Class Initialized
DEBUG - 2011-07-08 11:33:43 --> Hooks Class Initialized
DEBUG - 2011-07-08 11:33:43 --> Utf8 Class Initialized
DEBUG - 2011-07-08 11:33:43 --> UTF-8 Support Enabled
DEBUG - 2011-07-08 11:33:43 --> URI Class Initialized
DEBUG - 2011-07-08 11:33:43 --> Router Class Initialized
DEBUG - 2011-07-08 11:33:43 --> Output Class Initialized
DEBUG - 2011-07-08 11:33:43 --> Input Class Initialized
DEBUG - 2011-07-08 11:33:43 --> Global POST and COOKIE data sanitized
DEBUG - 2011-07-08 11:33:43 --> Language Class Initialized
DEBUG - 2011-07-08 11:33:43 --> Loader Class Initialized
DEBUG - 2011-07-08 11:33:43 --> Controller Class Initialized
DEBUG - 2011-07-08 11:33:43 --> Model Class Initialized
DEBUG - 2011-07-08 11:33:43 --> Model Class Initialized
DEBUG - 2011-07-08 11:33:43 --> Model Class Initialized
DEBUG - 2011-07-08 11:33:43 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-07-08 11:33:43 --> Database Driver Class Initialized
DEBUG - 2011-07-08 11:33:43 --> File loaded: application/views/table/main.php
DEBUG - 2011-07-08 11:33:43 --> Helper loaded: url_helper
DEBUG - 2011-07-08 11:33:43 --> File loaded: application/views/common/header.php
DEBUG - 2011-07-08 11:33:43 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-07-08 11:33:43 --> File loaded: application/views/common/footer.php
DEBUG - 2011-07-08 11:33:43 --> File loaded: application/views/layout/main.php
DEBUG - 2011-07-08 11:33:43 --> Final output sent to browser
DEBUG - 2011-07-08 11:33:43 --> Total execution time: 0.2674
DEBUG - 2011-07-08 11:33:45 --> Config Class Initialized
DEBUG - 2011-07-08 11:33:45 --> Hooks Class Initialized
DEBUG - 2011-07-08 11:33:45 --> Utf8 Class Initialized
DEBUG - 2011-07-08 11:33:45 --> UTF-8 Support Enabled
DEBUG - 2011-07-08 11:33:45 --> URI Class Initialized
DEBUG - 2011-07-08 11:33:45 --> Router Class Initialized
DEBUG - 2011-07-08 11:33:45 --> Output Class Initialized
DEBUG - 2011-07-08 11:33:45 --> Input Class Initialized
DEBUG - 2011-07-08 11:33:45 --> Global POST and COOKIE data sanitized
DEBUG - 2011-07-08 11:33:45 --> Language Class Initialized
DEBUG - 2011-07-08 11:33:45 --> Loader Class Initialized
DEBUG - 2011-07-08 11:33:45 --> Controller Class Initialized
DEBUG - 2011-07-08 11:33:45 --> Model Class Initialized
DEBUG - 2011-07-08 11:33:45 --> Model Class Initialized
DEBUG - 2011-07-08 11:33:45 --> Model Class Initialized
DEBUG - 2011-07-08 11:33:45 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-07-08 11:33:45 --> Database Driver Class Initialized
DEBUG - 2011-07-08 11:33:45 --> File loaded: application/views/table/main.php
DEBUG - 2011-07-08 11:33:45 --> Helper loaded: url_helper
DEBUG - 2011-07-08 11:33:45 --> File loaded: application/views/common/header.php
DEBUG - 2011-07-08 11:33:45 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-07-08 11:33:45 --> File loaded: application/views/common/footer.php
DEBUG - 2011-07-08 11:33:45 --> File loaded: application/views/layout/main.php
DEBUG - 2011-07-08 11:33:45 --> Final output sent to browser
DEBUG - 2011-07-08 11:33:45 --> Total execution time: 0.0474
DEBUG - 2011-07-08 11:33:46 --> Config Class Initialized
DEBUG - 2011-07-08 11:33:46 --> Hooks Class Initialized
DEBUG - 2011-07-08 11:33:46 --> Utf8 Class Initialized
DEBUG - 2011-07-08 11:33:46 --> UTF-8 Support Enabled
DEBUG - 2011-07-08 11:33:46 --> URI Class Initialized
DEBUG - 2011-07-08 11:33:46 --> Router Class Initialized
DEBUG - 2011-07-08 11:33:46 --> Output Class Initialized
DEBUG - 2011-07-08 11:33:46 --> Input Class Initialized
DEBUG - 2011-07-08 11:33:46 --> Global POST and COOKIE data sanitized
DEBUG - 2011-07-08 11:33:46 --> Language Class Initialized
DEBUG - 2011-07-08 11:33:46 --> Loader Class Initialized
DEBUG - 2011-07-08 11:33:46 --> Controller Class Initialized
DEBUG - 2011-07-08 11:33:46 --> Model Class Initialized
DEBUG - 2011-07-08 11:33:46 --> Model Class Initialized
DEBUG - 2011-07-08 11:33:46 --> Model Class Initialized
DEBUG - 2011-07-08 11:33:46 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-07-08 11:33:46 --> Database Driver Class Initialized
DEBUG - 2011-07-08 11:33:46 --> File loaded: application/views/table/main.php
DEBUG - 2011-07-08 11:33:46 --> Helper loaded: url_helper
DEBUG - 2011-07-08 11:33:46 --> File loaded: application/views/common/header.php
DEBUG - 2011-07-08 11:33:46 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-07-08 11:33:46 --> File loaded: application/views/common/footer.php
DEBUG - 2011-07-08 11:33:46 --> File loaded: application/views/layout/main.php
DEBUG - 2011-07-08 11:33:46 --> Final output sent to browser
DEBUG - 2011-07-08 11:33:46 --> Total execution time: 0.0427
DEBUG - 2011-07-08 11:33:50 --> Config Class Initialized
DEBUG - 2011-07-08 11:33:50 --> Hooks Class Initialized
DEBUG - 2011-07-08 11:33:50 --> Utf8 Class Initialized
DEBUG - 2011-07-08 11:33:50 --> UTF-8 Support Enabled
DEBUG - 2011-07-08 11:33:50 --> URI Class Initialized
DEBUG - 2011-07-08 11:33:50 --> Router Class Initialized
DEBUG - 2011-07-08 11:33:50 --> Output Class Initialized
DEBUG - 2011-07-08 11:33:50 --> Input Class Initialized
DEBUG - 2011-07-08 11:33:50 --> Global POST and COOKIE data sanitized
DEBUG - 2011-07-08 11:33:50 --> Language Class Initialized
DEBUG - 2011-07-08 11:33:50 --> Loader Class Initialized
DEBUG - 2011-07-08 11:33:50 --> Controller Class Initialized
DEBUG - 2011-07-08 11:33:50 --> Model Class Initialized
DEBUG - 2011-07-08 11:33:50 --> Model Class Initialized
DEBUG - 2011-07-08 11:33:50 --> Model Class Initialized
DEBUG - 2011-07-08 11:33:50 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-07-08 11:33:50 --> Database Driver Class Initialized
DEBUG - 2011-07-08 11:33:50 --> File loaded: application/views/table/main.php
DEBUG - 2011-07-08 11:33:50 --> Helper loaded: url_helper
DEBUG - 2011-07-08 11:33:50 --> File loaded: application/views/common/header.php
DEBUG - 2011-07-08 11:33:50 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-07-08 11:33:50 --> File loaded: application/views/common/footer.php
DEBUG - 2011-07-08 11:33:50 --> File loaded: application/views/layout/main.php
DEBUG - 2011-07-08 11:33:50 --> Final output sent to browser
DEBUG - 2011-07-08 11:33:50 --> Total execution time: 0.2412
DEBUG - 2011-07-08 11:33:53 --> Config Class Initialized
DEBUG - 2011-07-08 11:33:53 --> Hooks Class Initialized
DEBUG - 2011-07-08 11:33:53 --> Utf8 Class Initialized
DEBUG - 2011-07-08 11:33:53 --> UTF-8 Support Enabled
DEBUG - 2011-07-08 11:33:53 --> URI Class Initialized
DEBUG - 2011-07-08 11:33:53 --> Router Class Initialized
DEBUG - 2011-07-08 11:33:53 --> Output Class Initialized
DEBUG - 2011-07-08 11:33:53 --> Input Class Initialized
DEBUG - 2011-07-08 11:33:53 --> Global POST and COOKIE data sanitized
DEBUG - 2011-07-08 11:33:53 --> Language Class Initialized
DEBUG - 2011-07-08 11:33:53 --> Loader Class Initialized
DEBUG - 2011-07-08 11:33:53 --> Controller Class Initialized
DEBUG - 2011-07-08 11:33:53 --> Model Class Initialized
DEBUG - 2011-07-08 11:33:53 --> Model Class Initialized
DEBUG - 2011-07-08 11:33:53 --> Model Class Initialized
DEBUG - 2011-07-08 11:33:53 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-07-08 11:33:53 --> Database Driver Class Initialized
DEBUG - 2011-07-08 11:33:53 --> File loaded: application/views/table/main.php
DEBUG - 2011-07-08 11:33:53 --> Helper loaded: url_helper
DEBUG - 2011-07-08 11:33:53 --> File loaded: application/views/common/header.php
DEBUG - 2011-07-08 11:33:53 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-07-08 11:33:53 --> File loaded: application/views/common/footer.php
DEBUG - 2011-07-08 11:33:53 --> File loaded: application/views/layout/main.php
DEBUG - 2011-07-08 11:33:53 --> Final output sent to browser
DEBUG - 2011-07-08 11:33:53 --> Total execution time: 0.0533
DEBUG - 2011-07-08 11:33:56 --> Config Class Initialized
DEBUG - 2011-07-08 11:33:56 --> Hooks Class Initialized
DEBUG - 2011-07-08 11:33:56 --> Utf8 Class Initialized
DEBUG - 2011-07-08 11:33:56 --> UTF-8 Support Enabled
DEBUG - 2011-07-08 11:33:56 --> URI Class Initialized
DEBUG - 2011-07-08 11:33:56 --> Router Class Initialized
DEBUG - 2011-07-08 11:33:56 --> Output Class Initialized
DEBUG - 2011-07-08 11:33:56 --> Input Class Initialized
DEBUG - 2011-07-08 11:33:56 --> Global POST and COOKIE data sanitized
DEBUG - 2011-07-08 11:33:56 --> Language Class Initialized
DEBUG - 2011-07-08 11:33:56 --> Loader Class Initialized
DEBUG - 2011-07-08 11:33:56 --> Controller Class Initialized
DEBUG - 2011-07-08 11:33:56 --> Model Class Initialized
DEBUG - 2011-07-08 11:33:56 --> Model Class Initialized
DEBUG - 2011-07-08 11:33:56 --> Model Class Initialized
DEBUG - 2011-07-08 11:33:56 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-07-08 11:33:56 --> Database Driver Class Initialized
DEBUG - 2011-07-08 11:33:56 --> File loaded: application/views/table/main.php
DEBUG - 2011-07-08 11:33:56 --> Helper loaded: url_helper
DEBUG - 2011-07-08 11:33:56 --> File loaded: application/views/common/header.php
DEBUG - 2011-07-08 11:33:56 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-07-08 11:33:56 --> File loaded: application/views/common/footer.php
DEBUG - 2011-07-08 11:33:56 --> File loaded: application/views/layout/main.php
DEBUG - 2011-07-08 11:33:56 --> Final output sent to browser
DEBUG - 2011-07-08 11:33:56 --> Total execution time: 0.2275
DEBUG - 2011-07-08 11:33:58 --> Config Class Initialized
DEBUG - 2011-07-08 11:33:58 --> Hooks Class Initialized
DEBUG - 2011-07-08 11:33:58 --> Utf8 Class Initialized
DEBUG - 2011-07-08 11:33:58 --> UTF-8 Support Enabled
DEBUG - 2011-07-08 11:33:58 --> URI Class Initialized
DEBUG - 2011-07-08 11:33:58 --> Router Class Initialized
DEBUG - 2011-07-08 11:33:58 --> Output Class Initialized
DEBUG - 2011-07-08 11:33:58 --> Input Class Initialized
DEBUG - 2011-07-08 11:33:58 --> Global POST and COOKIE data sanitized
DEBUG - 2011-07-08 11:33:58 --> Language Class Initialized
DEBUG - 2011-07-08 11:33:58 --> Loader Class Initialized
DEBUG - 2011-07-08 11:33:58 --> Controller Class Initialized
DEBUG - 2011-07-08 11:33:58 --> Model Class Initialized
DEBUG - 2011-07-08 11:33:58 --> Model Class Initialized
DEBUG - 2011-07-08 11:33:58 --> Model Class Initialized
DEBUG - 2011-07-08 11:33:58 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-07-08 11:33:58 --> Database Driver Class Initialized
DEBUG - 2011-07-08 11:33:58 --> File loaded: application/views/table/main.php
DEBUG - 2011-07-08 11:33:58 --> Helper loaded: url_helper
DEBUG - 2011-07-08 11:33:58 --> File loaded: application/views/common/header.php
DEBUG - 2011-07-08 11:33:58 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-07-08 11:33:58 --> File loaded: application/views/common/footer.php
DEBUG - 2011-07-08 11:33:58 --> File loaded: application/views/layout/main.php
DEBUG - 2011-07-08 11:33:58 --> Final output sent to browser
DEBUG - 2011-07-08 11:33:58 --> Total execution time: 0.0866
DEBUG - 2011-07-08 11:34:03 --> Config Class Initialized
DEBUG - 2011-07-08 11:34:03 --> Hooks Class Initialized
DEBUG - 2011-07-08 11:34:03 --> Utf8 Class Initialized
DEBUG - 2011-07-08 11:34:03 --> UTF-8 Support Enabled
DEBUG - 2011-07-08 11:34:03 --> URI Class Initialized
DEBUG - 2011-07-08 11:34:03 --> Router Class Initialized
DEBUG - 2011-07-08 11:34:03 --> Output Class Initialized
DEBUG - 2011-07-08 11:34:03 --> Input Class Initialized
DEBUG - 2011-07-08 11:34:03 --> Global POST and COOKIE data sanitized
DEBUG - 2011-07-08 11:34:03 --> Language Class Initialized
DEBUG - 2011-07-08 11:34:03 --> Loader Class Initialized
DEBUG - 2011-07-08 11:34:03 --> Controller Class Initialized
DEBUG - 2011-07-08 11:34:03 --> Model Class Initialized
DEBUG - 2011-07-08 11:34:03 --> Model Class Initialized
DEBUG - 2011-07-08 11:34:03 --> Model Class Initialized
DEBUG - 2011-07-08 11:34:03 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-07-08 11:34:03 --> Database Driver Class Initialized
DEBUG - 2011-07-08 11:34:03 --> File loaded: application/views/table/main.php
DEBUG - 2011-07-08 11:34:03 --> Helper loaded: url_helper
DEBUG - 2011-07-08 11:34:03 --> File loaded: application/views/common/header.php
DEBUG - 2011-07-08 11:34:03 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-07-08 11:34:03 --> File loaded: application/views/common/footer.php
DEBUG - 2011-07-08 11:34:03 --> File loaded: application/views/layout/main.php
DEBUG - 2011-07-08 11:34:03 --> Final output sent to browser
DEBUG - 2011-07-08 11:34:03 --> Total execution time: 0.2077
DEBUG - 2011-07-08 11:34:05 --> Config Class Initialized
DEBUG - 2011-07-08 11:34:05 --> Hooks Class Initialized
DEBUG - 2011-07-08 11:34:05 --> Utf8 Class Initialized
DEBUG - 2011-07-08 11:34:05 --> UTF-8 Support Enabled
DEBUG - 2011-07-08 11:34:05 --> URI Class Initialized
DEBUG - 2011-07-08 11:34:05 --> Router Class Initialized
DEBUG - 2011-07-08 11:34:05 --> Output Class Initialized
DEBUG - 2011-07-08 11:34:05 --> Input Class Initialized
DEBUG - 2011-07-08 11:34:05 --> Global POST and COOKIE data sanitized
DEBUG - 2011-07-08 11:34:05 --> Language Class Initialized
DEBUG - 2011-07-08 11:34:05 --> Loader Class Initialized
DEBUG - 2011-07-08 11:34:05 --> Controller Class Initialized
DEBUG - 2011-07-08 11:34:05 --> Model Class Initialized
DEBUG - 2011-07-08 11:34:05 --> Model Class Initialized
DEBUG - 2011-07-08 11:34:05 --> Model Class Initialized
DEBUG - 2011-07-08 11:34:05 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-07-08 11:34:05 --> Database Driver Class Initialized
DEBUG - 2011-07-08 11:34:05 --> File loaded: application/views/table/main.php
DEBUG - 2011-07-08 11:34:05 --> Helper loaded: url_helper
DEBUG - 2011-07-08 11:34:05 --> File loaded: application/views/common/header.php
DEBUG - 2011-07-08 11:34:05 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-07-08 11:34:05 --> File loaded: application/views/common/footer.php
DEBUG - 2011-07-08 11:34:05 --> File loaded: application/views/layout/main.php
DEBUG - 2011-07-08 11:34:05 --> Final output sent to browser
DEBUG - 2011-07-08 11:34:05 --> Total execution time: 0.0687
DEBUG - 2011-07-08 11:34:09 --> Config Class Initialized
DEBUG - 2011-07-08 11:34:09 --> Hooks Class Initialized
DEBUG - 2011-07-08 11:34:09 --> Utf8 Class Initialized
DEBUG - 2011-07-08 11:34:09 --> UTF-8 Support Enabled
DEBUG - 2011-07-08 11:34:09 --> URI Class Initialized
DEBUG - 2011-07-08 11:34:09 --> Router Class Initialized
DEBUG - 2011-07-08 11:34:09 --> Output Class Initialized
DEBUG - 2011-07-08 11:34:09 --> Input Class Initialized
DEBUG - 2011-07-08 11:34:09 --> Global POST and COOKIE data sanitized
DEBUG - 2011-07-08 11:34:09 --> Language Class Initialized
DEBUG - 2011-07-08 11:34:09 --> Loader Class Initialized
DEBUG - 2011-07-08 11:34:09 --> Controller Class Initialized
DEBUG - 2011-07-08 11:34:09 --> Model Class Initialized
DEBUG - 2011-07-08 11:34:09 --> Model Class Initialized
DEBUG - 2011-07-08 11:34:09 --> Model Class Initialized
DEBUG - 2011-07-08 11:34:09 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-07-08 11:34:09 --> Database Driver Class Initialized
DEBUG - 2011-07-08 11:34:09 --> File loaded: application/views/table/main.php
DEBUG - 2011-07-08 11:34:09 --> Helper loaded: url_helper
DEBUG - 2011-07-08 11:34:09 --> File loaded: application/views/common/header.php
DEBUG - 2011-07-08 11:34:09 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-07-08 11:34:09 --> File loaded: application/views/common/footer.php
DEBUG - 2011-07-08 11:34:09 --> File loaded: application/views/layout/main.php
DEBUG - 2011-07-08 11:34:09 --> Final output sent to browser
DEBUG - 2011-07-08 11:34:09 --> Total execution time: 0.0499
DEBUG - 2011-07-08 11:34:14 --> Config Class Initialized
DEBUG - 2011-07-08 11:34:14 --> Hooks Class Initialized
DEBUG - 2011-07-08 11:34:14 --> Utf8 Class Initialized
DEBUG - 2011-07-08 11:34:14 --> UTF-8 Support Enabled
DEBUG - 2011-07-08 11:34:14 --> URI Class Initialized
DEBUG - 2011-07-08 11:34:14 --> Router Class Initialized
DEBUG - 2011-07-08 11:34:14 --> Output Class Initialized
DEBUG - 2011-07-08 11:34:14 --> Input Class Initialized
DEBUG - 2011-07-08 11:34:14 --> Global POST and COOKIE data sanitized
DEBUG - 2011-07-08 11:34:14 --> Language Class Initialized
DEBUG - 2011-07-08 11:34:14 --> Loader Class Initialized
DEBUG - 2011-07-08 11:34:14 --> Controller Class Initialized
DEBUG - 2011-07-08 11:34:14 --> Model Class Initialized
DEBUG - 2011-07-08 11:34:14 --> Model Class Initialized
DEBUG - 2011-07-08 11:34:14 --> Model Class Initialized
DEBUG - 2011-07-08 11:34:14 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-07-08 11:34:14 --> Database Driver Class Initialized
DEBUG - 2011-07-08 11:34:14 --> File loaded: application/views/table/main.php
DEBUG - 2011-07-08 11:34:14 --> Helper loaded: url_helper
DEBUG - 2011-07-08 11:34:14 --> File loaded: application/views/common/header.php
DEBUG - 2011-07-08 11:34:14 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-07-08 11:34:14 --> File loaded: application/views/common/footer.php
DEBUG - 2011-07-08 11:34:14 --> File loaded: application/views/layout/main.php
DEBUG - 2011-07-08 11:34:14 --> Final output sent to browser
DEBUG - 2011-07-08 11:34:14 --> Total execution time: 0.0468
DEBUG - 2011-07-08 11:34:33 --> Config Class Initialized
DEBUG - 2011-07-08 11:34:33 --> Hooks Class Initialized
DEBUG - 2011-07-08 11:34:33 --> Utf8 Class Initialized
DEBUG - 2011-07-08 11:34:33 --> UTF-8 Support Enabled
DEBUG - 2011-07-08 11:34:33 --> URI Class Initialized
DEBUG - 2011-07-08 11:34:33 --> Router Class Initialized
DEBUG - 2011-07-08 11:34:33 --> Output Class Initialized
DEBUG - 2011-07-08 11:34:33 --> Input Class Initialized
DEBUG - 2011-07-08 11:34:33 --> Global POST and COOKIE data sanitized
DEBUG - 2011-07-08 11:34:33 --> Language Class Initialized
DEBUG - 2011-07-08 11:34:33 --> Loader Class Initialized
DEBUG - 2011-07-08 11:34:33 --> Controller Class Initialized
DEBUG - 2011-07-08 11:34:33 --> Model Class Initialized
DEBUG - 2011-07-08 11:34:33 --> Model Class Initialized
DEBUG - 2011-07-08 11:34:33 --> Model Class Initialized
DEBUG - 2011-07-08 11:34:33 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-07-08 11:34:33 --> Database Driver Class Initialized
DEBUG - 2011-07-08 11:34:33 --> File loaded: application/views/table/main.php
DEBUG - 2011-07-08 11:34:33 --> Helper loaded: url_helper
DEBUG - 2011-07-08 11:34:33 --> File loaded: application/views/common/header.php
DEBUG - 2011-07-08 11:34:33 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-07-08 11:34:33 --> File loaded: application/views/common/footer.php
DEBUG - 2011-07-08 11:34:33 --> File loaded: application/views/layout/main.php
DEBUG - 2011-07-08 11:34:33 --> Final output sent to browser
DEBUG - 2011-07-08 11:34:33 --> Total execution time: 0.6753
DEBUG - 2011-07-08 11:34:35 --> Config Class Initialized
DEBUG - 2011-07-08 11:34:35 --> Hooks Class Initialized
DEBUG - 2011-07-08 11:34:35 --> Utf8 Class Initialized
DEBUG - 2011-07-08 11:34:35 --> UTF-8 Support Enabled
DEBUG - 2011-07-08 11:34:35 --> URI Class Initialized
DEBUG - 2011-07-08 11:34:35 --> Router Class Initialized
DEBUG - 2011-07-08 11:34:35 --> Output Class Initialized
DEBUG - 2011-07-08 11:34:35 --> Input Class Initialized
DEBUG - 2011-07-08 11:34:35 --> Global POST and COOKIE data sanitized
DEBUG - 2011-07-08 11:34:35 --> Language Class Initialized
DEBUG - 2011-07-08 11:34:35 --> Loader Class Initialized
DEBUG - 2011-07-08 11:34:35 --> Controller Class Initialized
DEBUG - 2011-07-08 11:34:35 --> Model Class Initialized
DEBUG - 2011-07-08 11:34:35 --> Model Class Initialized
DEBUG - 2011-07-08 11:34:35 --> Model Class Initialized
DEBUG - 2011-07-08 11:34:35 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-07-08 11:34:35 --> Database Driver Class Initialized
DEBUG - 2011-07-08 11:34:35 --> File loaded: application/views/table/main.php
DEBUG - 2011-07-08 11:34:35 --> Helper loaded: url_helper
DEBUG - 2011-07-08 11:34:35 --> File loaded: application/views/common/header.php
DEBUG - 2011-07-08 11:34:35 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-07-08 11:34:35 --> File loaded: application/views/common/footer.php
DEBUG - 2011-07-08 11:34:35 --> File loaded: application/views/layout/main.php
DEBUG - 2011-07-08 11:34:35 --> Final output sent to browser
DEBUG - 2011-07-08 11:34:35 --> Total execution time: 0.0392
DEBUG - 2011-07-08 13:05:36 --> Config Class Initialized
DEBUG - 2011-07-08 13:05:36 --> Hooks Class Initialized
DEBUG - 2011-07-08 13:05:36 --> Utf8 Class Initialized
DEBUG - 2011-07-08 13:05:36 --> UTF-8 Support Enabled
DEBUG - 2011-07-08 13:05:36 --> URI Class Initialized
DEBUG - 2011-07-08 13:05:36 --> Router Class Initialized
DEBUG - 2011-07-08 13:05:36 --> Output Class Initialized
DEBUG - 2011-07-08 13:05:36 --> Input Class Initialized
DEBUG - 2011-07-08 13:05:36 --> Global POST and COOKIE data sanitized
DEBUG - 2011-07-08 13:05:36 --> Language Class Initialized
DEBUG - 2011-07-08 13:05:36 --> Loader Class Initialized
DEBUG - 2011-07-08 13:05:36 --> Controller Class Initialized
DEBUG - 2011-07-08 13:05:36 --> Model Class Initialized
DEBUG - 2011-07-08 13:05:36 --> Model Class Initialized
DEBUG - 2011-07-08 13:05:36 --> Model Class Initialized
DEBUG - 2011-07-08 13:05:36 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-07-08 13:05:36 --> Database Driver Class Initialized
DEBUG - 2011-07-08 13:05:37 --> File loaded: application/views/table/main.php
DEBUG - 2011-07-08 13:05:37 --> Helper loaded: url_helper
DEBUG - 2011-07-08 13:05:37 --> File loaded: application/views/common/header.php
DEBUG - 2011-07-08 13:05:37 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-07-08 13:05:37 --> File loaded: application/views/common/footer.php
DEBUG - 2011-07-08 13:05:37 --> File loaded: application/views/layout/main.php
DEBUG - 2011-07-08 13:05:37 --> Final output sent to browser
DEBUG - 2011-07-08 13:05:37 --> Total execution time: 0.9823
DEBUG - 2011-07-08 13:05:39 --> Config Class Initialized
DEBUG - 2011-07-08 13:05:39 --> Hooks Class Initialized
DEBUG - 2011-07-08 13:05:39 --> Utf8 Class Initialized
DEBUG - 2011-07-08 13:05:39 --> UTF-8 Support Enabled
DEBUG - 2011-07-08 13:05:39 --> URI Class Initialized
DEBUG - 2011-07-08 13:05:39 --> Router Class Initialized
DEBUG - 2011-07-08 13:05:39 --> Output Class Initialized
DEBUG - 2011-07-08 13:05:39 --> Input Class Initialized
DEBUG - 2011-07-08 13:05:39 --> Global POST and COOKIE data sanitized
DEBUG - 2011-07-08 13:05:39 --> Language Class Initialized
DEBUG - 2011-07-08 13:05:39 --> Loader Class Initialized
DEBUG - 2011-07-08 13:05:39 --> Controller Class Initialized
ERROR - 2011-07-08 13:05:39 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-07-08 13:05:39 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-07-08 13:05:39 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-07-08 13:05:39 --> Model Class Initialized
DEBUG - 2011-07-08 13:05:39 --> Model Class Initialized
DEBUG - 2011-07-08 13:05:39 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-07-08 13:05:39 --> Database Driver Class Initialized
DEBUG - 2011-07-08 13:05:39 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-07-08 13:05:39 --> Helper loaded: url_helper
DEBUG - 2011-07-08 13:05:39 --> File loaded: application/views/common/header.php
DEBUG - 2011-07-08 13:05:39 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-07-08 13:05:39 --> File loaded: application/views/common/footer.php
DEBUG - 2011-07-08 13:05:39 --> File loaded: application/views/layout/main.php
DEBUG - 2011-07-08 13:05:39 --> Final output sent to browser
DEBUG - 2011-07-08 13:05:39 --> Total execution time: 0.0774
DEBUG - 2011-07-08 13:14:36 --> Config Class Initialized
DEBUG - 2011-07-08 13:14:36 --> Hooks Class Initialized
DEBUG - 2011-07-08 13:14:36 --> Utf8 Class Initialized
DEBUG - 2011-07-08 13:14:36 --> UTF-8 Support Enabled
DEBUG - 2011-07-08 13:14:36 --> URI Class Initialized
DEBUG - 2011-07-08 13:14:36 --> Router Class Initialized
DEBUG - 2011-07-08 13:14:36 --> No URI present. Default controller set.
DEBUG - 2011-07-08 13:14:36 --> Output Class Initialized
DEBUG - 2011-07-08 13:14:36 --> Input Class Initialized
DEBUG - 2011-07-08 13:14:36 --> Global POST and COOKIE data sanitized
DEBUG - 2011-07-08 13:14:36 --> Language Class Initialized
DEBUG - 2011-07-08 13:14:36 --> Loader Class Initialized
DEBUG - 2011-07-08 13:14:36 --> Controller Class Initialized
DEBUG - 2011-07-08 13:14:36 --> File loaded: application/views/splash/main.php
DEBUG - 2011-07-08 13:14:36 --> Helper loaded: url_helper
DEBUG - 2011-07-08 13:14:36 --> File loaded: application/views/common/header.php
DEBUG - 2011-07-08 13:14:36 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-07-08 13:14:36 --> File loaded: application/views/common/footer.php
DEBUG - 2011-07-08 13:14:36 --> File loaded: application/views/layout/main.php
DEBUG - 2011-07-08 13:14:36 --> Final output sent to browser
DEBUG - 2011-07-08 13:14:36 --> Total execution time: 0.2856
DEBUG - 2011-07-08 13:20:13 --> Config Class Initialized
DEBUG - 2011-07-08 13:20:13 --> Hooks Class Initialized
DEBUG - 2011-07-08 13:20:13 --> Utf8 Class Initialized
DEBUG - 2011-07-08 13:20:13 --> UTF-8 Support Enabled
DEBUG - 2011-07-08 13:20:13 --> URI Class Initialized
DEBUG - 2011-07-08 13:20:13 --> Router Class Initialized
DEBUG - 2011-07-08 13:20:13 --> Output Class Initialized
DEBUG - 2011-07-08 13:20:13 --> Input Class Initialized
DEBUG - 2011-07-08 13:20:13 --> Global POST and COOKIE data sanitized
DEBUG - 2011-07-08 13:20:13 --> Language Class Initialized
DEBUG - 2011-07-08 13:20:13 --> Loader Class Initialized
DEBUG - 2011-07-08 13:20:13 --> Controller Class Initialized
DEBUG - 2011-07-08 13:20:13 --> Model Class Initialized
DEBUG - 2011-07-08 13:20:13 --> Model Class Initialized
DEBUG - 2011-07-08 13:20:13 --> Model Class Initialized
DEBUG - 2011-07-08 13:20:13 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-07-08 13:20:13 --> Database Driver Class Initialized
DEBUG - 2011-07-08 13:20:13 --> File loaded: application/views/table/main.php
DEBUG - 2011-07-08 13:20:13 --> Helper loaded: url_helper
DEBUG - 2011-07-08 13:20:13 --> File loaded: application/views/common/header.php
DEBUG - 2011-07-08 13:20:13 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-07-08 13:20:13 --> File loaded: application/views/common/footer.php
DEBUG - 2011-07-08 13:20:13 --> File loaded: application/views/layout/main.php
DEBUG - 2011-07-08 13:20:13 --> Final output sent to browser
DEBUG - 2011-07-08 13:20:13 --> Total execution time: 0.1224
DEBUG - 2011-07-08 16:01:51 --> Config Class Initialized
DEBUG - 2011-07-08 16:01:51 --> Hooks Class Initialized
DEBUG - 2011-07-08 16:01:51 --> Utf8 Class Initialized
DEBUG - 2011-07-08 16:01:51 --> UTF-8 Support Enabled
DEBUG - 2011-07-08 16:01:51 --> URI Class Initialized
DEBUG - 2011-07-08 16:01:51 --> Router Class Initialized
ERROR - 2011-07-08 16:01:51 --> 404 Page Not Found --> robots.txt
DEBUG - 2011-07-08 16:01:52 --> Config Class Initialized
DEBUG - 2011-07-08 16:01:52 --> Hooks Class Initialized
DEBUG - 2011-07-08 16:01:52 --> Utf8 Class Initialized
DEBUG - 2011-07-08 16:01:52 --> UTF-8 Support Enabled
DEBUG - 2011-07-08 16:01:52 --> URI Class Initialized
DEBUG - 2011-07-08 16:01:52 --> Router Class Initialized
DEBUG - 2011-07-08 16:01:52 --> No URI present. Default controller set.
DEBUG - 2011-07-08 16:01:52 --> Output Class Initialized
DEBUG - 2011-07-08 16:01:52 --> Input Class Initialized
DEBUG - 2011-07-08 16:01:52 --> Global POST and COOKIE data sanitized
DEBUG - 2011-07-08 16:01:52 --> Language Class Initialized
DEBUG - 2011-07-08 16:01:52 --> Loader Class Initialized
DEBUG - 2011-07-08 16:01:52 --> Controller Class Initialized
DEBUG - 2011-07-08 16:01:52 --> File loaded: application/views/splash/main.php
DEBUG - 2011-07-08 16:01:52 --> Helper loaded: url_helper
DEBUG - 2011-07-08 16:01:52 --> File loaded: application/views/common/header.php
DEBUG - 2011-07-08 16:01:52 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-07-08 16:01:52 --> File loaded: application/views/common/footer.php
DEBUG - 2011-07-08 16:01:52 --> File loaded: application/views/layout/main.php
DEBUG - 2011-07-08 16:01:52 --> Final output sent to browser
DEBUG - 2011-07-08 16:01:52 --> Total execution time: 0.2052
DEBUG - 2011-07-08 22:07:48 --> Config Class Initialized
DEBUG - 2011-07-08 22:07:48 --> Hooks Class Initialized
DEBUG - 2011-07-08 22:07:48 --> Utf8 Class Initialized
DEBUG - 2011-07-08 22:07:48 --> UTF-8 Support Enabled
DEBUG - 2011-07-08 22:07:48 --> URI Class Initialized
DEBUG - 2011-07-08 22:07:48 --> Router Class Initialized
DEBUG - 2011-07-08 22:07:48 --> No URI present. Default controller set.
DEBUG - 2011-07-08 22:07:49 --> Output Class Initialized
DEBUG - 2011-07-08 22:07:49 --> Input Class Initialized
DEBUG - 2011-07-08 22:07:49 --> Global POST and COOKIE data sanitized
DEBUG - 2011-07-08 22:07:49 --> Language Class Initialized
DEBUG - 2011-07-08 22:07:49 --> Loader Class Initialized
DEBUG - 2011-07-08 22:07:49 --> Controller Class Initialized
DEBUG - 2011-07-08 22:07:49 --> File loaded: application/views/splash/main.php
DEBUG - 2011-07-08 22:07:49 --> Helper loaded: url_helper
DEBUG - 2011-07-08 22:07:49 --> File loaded: application/views/common/header.php
DEBUG - 2011-07-08 22:07:49 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-07-08 22:07:49 --> File loaded: application/views/common/footer.php
DEBUG - 2011-07-08 22:07:49 --> File loaded: application/views/layout/main.php
DEBUG - 2011-07-08 22:07:49 --> Final output sent to browser
DEBUG - 2011-07-08 22:07:49 --> Total execution time: 0.2948
DEBUG - 2011-07-08 23:05:55 --> Config Class Initialized
DEBUG - 2011-07-08 23:05:55 --> Hooks Class Initialized
DEBUG - 2011-07-08 23:05:55 --> Utf8 Class Initialized
DEBUG - 2011-07-08 23:05:55 --> UTF-8 Support Enabled
DEBUG - 2011-07-08 23:05:55 --> URI Class Initialized
DEBUG - 2011-07-08 23:05:55 --> Router Class Initialized
ERROR - 2011-07-08 23:05:55 --> 404 Page Not Found --> robots.txt

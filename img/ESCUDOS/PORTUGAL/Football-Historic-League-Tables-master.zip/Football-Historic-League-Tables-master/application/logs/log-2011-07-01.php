<?php  if ( ! defined('BASEPATH')) exit('No direct script access allowed'); ?>

DEBUG - 2011-07-01 01:10:29 --> Config Class Initialized
DEBUG - 2011-07-01 01:10:29 --> Hooks Class Initialized
DEBUG - 2011-07-01 01:10:29 --> Utf8 Class Initialized
DEBUG - 2011-07-01 01:10:29 --> UTF-8 Support Enabled
DEBUG - 2011-07-01 01:10:29 --> URI Class Initialized
DEBUG - 2011-07-01 01:10:29 --> Router Class Initialized
ERROR - 2011-07-01 01:10:29 --> 404 Page Not Found --> robots.txt
DEBUG - 2011-07-01 01:10:30 --> Config Class Initialized
DEBUG - 2011-07-01 01:10:30 --> Hooks Class Initialized
DEBUG - 2011-07-01 01:10:30 --> Utf8 Class Initialized
DEBUG - 2011-07-01 01:10:30 --> UTF-8 Support Enabled
DEBUG - 2011-07-01 01:10:30 --> URI Class Initialized
DEBUG - 2011-07-01 01:10:30 --> Router Class Initialized
DEBUG - 2011-07-01 01:10:30 --> Output Class Initialized
DEBUG - 2011-07-01 01:10:30 --> Input Class Initialized
DEBUG - 2011-07-01 01:10:30 --> Global POST and COOKIE data sanitized
DEBUG - 2011-07-01 01:10:30 --> Language Class Initialized
DEBUG - 2011-07-01 01:10:30 --> Loader Class Initialized
DEBUG - 2011-07-01 01:10:30 --> Controller Class Initialized
DEBUG - 2011-07-01 01:10:30 --> Model Class Initialized
DEBUG - 2011-07-01 01:10:30 --> Model Class Initialized
DEBUG - 2011-07-01 01:10:30 --> Model Class Initialized
DEBUG - 2011-07-01 01:10:30 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-07-01 01:10:30 --> Database Driver Class Initialized
DEBUG - 2011-07-01 01:10:31 --> File loaded: application/views/table/main.php
DEBUG - 2011-07-01 01:10:31 --> Helper loaded: url_helper
DEBUG - 2011-07-01 01:10:31 --> File loaded: application/views/common/header.php
DEBUG - 2011-07-01 01:10:31 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-07-01 01:10:31 --> File loaded: application/views/common/footer.php
DEBUG - 2011-07-01 01:10:31 --> File loaded: application/views/layout/main.php
DEBUG - 2011-07-01 01:10:31 --> Final output sent to browser
DEBUG - 2011-07-01 01:10:31 --> Total execution time: 1.7405
DEBUG - 2011-07-01 01:11:02 --> Config Class Initialized
DEBUG - 2011-07-01 01:11:02 --> Hooks Class Initialized
DEBUG - 2011-07-01 01:11:02 --> Utf8 Class Initialized
DEBUG - 2011-07-01 01:11:02 --> UTF-8 Support Enabled
DEBUG - 2011-07-01 01:11:02 --> URI Class Initialized
DEBUG - 2011-07-01 01:11:02 --> Router Class Initialized
DEBUG - 2011-07-01 01:11:02 --> Output Class Initialized
DEBUG - 2011-07-01 01:11:02 --> Input Class Initialized
DEBUG - 2011-07-01 01:11:02 --> Global POST and COOKIE data sanitized
DEBUG - 2011-07-01 01:11:02 --> Language Class Initialized
DEBUG - 2011-07-01 01:11:02 --> Loader Class Initialized
DEBUG - 2011-07-01 01:11:02 --> Controller Class Initialized
ERROR - 2011-07-01 01:11:02 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-07-01 01:11:02 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-07-01 01:11:02 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-07-01 01:11:02 --> Model Class Initialized
DEBUG - 2011-07-01 01:11:02 --> Model Class Initialized
DEBUG - 2011-07-01 01:11:02 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-07-01 01:11:02 --> Database Driver Class Initialized
DEBUG - 2011-07-01 01:11:02 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-07-01 01:11:02 --> Helper loaded: url_helper
DEBUG - 2011-07-01 01:11:02 --> File loaded: application/views/common/header.php
DEBUG - 2011-07-01 01:11:02 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-07-01 01:11:02 --> File loaded: application/views/common/footer.php
DEBUG - 2011-07-01 01:11:02 --> File loaded: application/views/layout/main.php
DEBUG - 2011-07-01 01:11:02 --> Final output sent to browser
DEBUG - 2011-07-01 01:11:02 --> Total execution time: 0.0955
DEBUG - 2011-07-01 02:41:14 --> Config Class Initialized
DEBUG - 2011-07-01 02:41:14 --> Hooks Class Initialized
DEBUG - 2011-07-01 02:41:14 --> Utf8 Class Initialized
DEBUG - 2011-07-01 02:41:14 --> UTF-8 Support Enabled
DEBUG - 2011-07-01 02:41:14 --> URI Class Initialized
DEBUG - 2011-07-01 02:41:14 --> Router Class Initialized
ERROR - 2011-07-01 02:41:14 --> 404 Page Not Found --> robots.txt
DEBUG - 2011-07-01 02:42:08 --> Config Class Initialized
DEBUG - 2011-07-01 02:42:08 --> Hooks Class Initialized
DEBUG - 2011-07-01 02:42:08 --> Utf8 Class Initialized
DEBUG - 2011-07-01 02:42:08 --> UTF-8 Support Enabled
DEBUG - 2011-07-01 02:42:08 --> URI Class Initialized
DEBUG - 2011-07-01 02:42:08 --> Router Class Initialized
DEBUG - 2011-07-01 02:42:08 --> Output Class Initialized
DEBUG - 2011-07-01 02:42:08 --> Input Class Initialized
DEBUG - 2011-07-01 02:42:08 --> Global POST and COOKIE data sanitized
DEBUG - 2011-07-01 02:42:08 --> Language Class Initialized
DEBUG - 2011-07-01 02:42:08 --> Loader Class Initialized
DEBUG - 2011-07-01 02:42:08 --> Controller Class Initialized
DEBUG - 2011-07-01 02:42:08 --> Model Class Initialized
DEBUG - 2011-07-01 02:42:08 --> Model Class Initialized
DEBUG - 2011-07-01 02:42:08 --> Model Class Initialized
DEBUG - 2011-07-01 02:42:08 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-07-01 02:42:08 --> Database Driver Class Initialized
DEBUG - 2011-07-01 02:42:13 --> File loaded: application/views/table/main.php
DEBUG - 2011-07-01 02:42:13 --> Helper loaded: url_helper
DEBUG - 2011-07-01 02:42:13 --> File loaded: application/views/common/header.php
DEBUG - 2011-07-01 02:42:13 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-07-01 02:42:13 --> File loaded: application/views/common/footer.php
DEBUG - 2011-07-01 02:42:13 --> File loaded: application/views/layout/main.php
DEBUG - 2011-07-01 02:42:13 --> Final output sent to browser
DEBUG - 2011-07-01 02:42:13 --> Total execution time: 4.7138
DEBUG - 2011-07-01 03:04:32 --> Config Class Initialized
DEBUG - 2011-07-01 03:04:32 --> Hooks Class Initialized
DEBUG - 2011-07-01 03:04:32 --> Utf8 Class Initialized
DEBUG - 2011-07-01 03:04:32 --> UTF-8 Support Enabled
DEBUG - 2011-07-01 03:04:32 --> URI Class Initialized
DEBUG - 2011-07-01 03:04:32 --> Router Class Initialized
DEBUG - 2011-07-01 03:04:32 --> No URI present. Default controller set.
DEBUG - 2011-07-01 03:04:32 --> Output Class Initialized
DEBUG - 2011-07-01 03:04:32 --> Input Class Initialized
DEBUG - 2011-07-01 03:04:32 --> Global POST and COOKIE data sanitized
DEBUG - 2011-07-01 03:04:32 --> Language Class Initialized
DEBUG - 2011-07-01 03:04:32 --> Loader Class Initialized
DEBUG - 2011-07-01 03:04:32 --> Controller Class Initialized
DEBUG - 2011-07-01 03:04:32 --> File loaded: application/views/splash/main.php
DEBUG - 2011-07-01 03:04:32 --> Helper loaded: url_helper
DEBUG - 2011-07-01 03:04:32 --> File loaded: application/views/common/header.php
DEBUG - 2011-07-01 03:04:32 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-07-01 03:04:32 --> File loaded: application/views/common/footer.php
DEBUG - 2011-07-01 03:04:32 --> File loaded: application/views/layout/main.php
DEBUG - 2011-07-01 03:04:32 --> Final output sent to browser
DEBUG - 2011-07-01 03:04:32 --> Total execution time: 0.6166
DEBUG - 2011-07-01 07:45:20 --> Config Class Initialized
DEBUG - 2011-07-01 07:45:20 --> Hooks Class Initialized
DEBUG - 2011-07-01 07:45:20 --> Utf8 Class Initialized
DEBUG - 2011-07-01 07:45:20 --> UTF-8 Support Enabled
DEBUG - 2011-07-01 07:45:20 --> URI Class Initialized
DEBUG - 2011-07-01 07:45:20 --> Router Class Initialized
DEBUG - 2011-07-01 07:45:20 --> Output Class Initialized
DEBUG - 2011-07-01 07:45:20 --> Input Class Initialized
DEBUG - 2011-07-01 07:45:20 --> Global POST and COOKIE data sanitized
DEBUG - 2011-07-01 07:45:20 --> Language Class Initialized
DEBUG - 2011-07-01 07:45:20 --> Loader Class Initialized
DEBUG - 2011-07-01 07:45:20 --> Controller Class Initialized
DEBUG - 2011-07-01 07:45:20 --> Model Class Initialized
DEBUG - 2011-07-01 07:45:20 --> Model Class Initialized
DEBUG - 2011-07-01 07:45:20 --> Model Class Initialized
DEBUG - 2011-07-01 07:45:20 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-07-01 07:45:20 --> Database Driver Class Initialized
DEBUG - 2011-07-01 07:45:20 --> File loaded: application/views/table/main.php
DEBUG - 2011-07-01 07:45:21 --> Helper loaded: url_helper
DEBUG - 2011-07-01 07:45:21 --> File loaded: application/views/common/header.php
DEBUG - 2011-07-01 07:45:21 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-07-01 07:45:21 --> File loaded: application/views/common/footer.php
DEBUG - 2011-07-01 07:45:21 --> File loaded: application/views/layout/main.php
DEBUG - 2011-07-01 07:45:21 --> Final output sent to browser
DEBUG - 2011-07-01 07:45:21 --> Total execution time: 1.1076
DEBUG - 2011-07-01 07:45:22 --> Config Class Initialized
DEBUG - 2011-07-01 07:45:22 --> Hooks Class Initialized
DEBUG - 2011-07-01 07:45:22 --> Utf8 Class Initialized
DEBUG - 2011-07-01 07:45:22 --> UTF-8 Support Enabled
DEBUG - 2011-07-01 07:45:22 --> URI Class Initialized
DEBUG - 2011-07-01 07:45:22 --> Router Class Initialized
DEBUG - 2011-07-01 07:45:22 --> Output Class Initialized
DEBUG - 2011-07-01 07:45:22 --> Input Class Initialized
DEBUG - 2011-07-01 07:45:22 --> Global POST and COOKIE data sanitized
DEBUG - 2011-07-01 07:45:22 --> Language Class Initialized
DEBUG - 2011-07-01 07:45:22 --> Loader Class Initialized
DEBUG - 2011-07-01 07:45:22 --> Controller Class Initialized
ERROR - 2011-07-01 07:45:22 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-07-01 07:45:22 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-07-01 07:45:22 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-07-01 07:45:22 --> Model Class Initialized
DEBUG - 2011-07-01 07:45:22 --> Model Class Initialized
DEBUG - 2011-07-01 07:45:22 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-07-01 07:45:22 --> Database Driver Class Initialized
DEBUG - 2011-07-01 07:45:22 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-07-01 07:45:22 --> Helper loaded: url_helper
DEBUG - 2011-07-01 07:45:22 --> File loaded: application/views/common/header.php
DEBUG - 2011-07-01 07:45:22 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-07-01 07:45:22 --> File loaded: application/views/common/footer.php
DEBUG - 2011-07-01 07:45:22 --> File loaded: application/views/layout/main.php
DEBUG - 2011-07-01 07:45:22 --> Final output sent to browser
DEBUG - 2011-07-01 07:45:22 --> Total execution time: 0.0970
DEBUG - 2011-07-01 07:46:51 --> Config Class Initialized
DEBUG - 2011-07-01 07:46:51 --> Hooks Class Initialized
DEBUG - 2011-07-01 07:46:51 --> Utf8 Class Initialized
DEBUG - 2011-07-01 07:46:51 --> UTF-8 Support Enabled
DEBUG - 2011-07-01 07:46:51 --> URI Class Initialized
DEBUG - 2011-07-01 07:46:51 --> Router Class Initialized
DEBUG - 2011-07-01 07:46:51 --> Output Class Initialized
DEBUG - 2011-07-01 07:46:51 --> Input Class Initialized
DEBUG - 2011-07-01 07:46:51 --> Global POST and COOKIE data sanitized
DEBUG - 2011-07-01 07:46:51 --> Language Class Initialized
DEBUG - 2011-07-01 07:46:51 --> Loader Class Initialized
DEBUG - 2011-07-01 07:46:51 --> Controller Class Initialized
DEBUG - 2011-07-01 07:46:51 --> Model Class Initialized
DEBUG - 2011-07-01 07:46:51 --> Model Class Initialized
DEBUG - 2011-07-01 07:46:51 --> Model Class Initialized
DEBUG - 2011-07-01 07:46:51 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-07-01 07:46:51 --> Database Driver Class Initialized
DEBUG - 2011-07-01 07:46:52 --> File loaded: application/views/table/main.php
DEBUG - 2011-07-01 07:46:52 --> Helper loaded: url_helper
DEBUG - 2011-07-01 07:46:52 --> File loaded: application/views/common/header.php
DEBUG - 2011-07-01 07:46:52 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-07-01 07:46:52 --> File loaded: application/views/common/footer.php
DEBUG - 2011-07-01 07:46:52 --> File loaded: application/views/layout/main.php
DEBUG - 2011-07-01 07:46:52 --> Final output sent to browser
DEBUG - 2011-07-01 07:46:52 --> Total execution time: 0.1719
DEBUG - 2011-07-01 07:46:56 --> Config Class Initialized
DEBUG - 2011-07-01 07:46:56 --> Hooks Class Initialized
DEBUG - 2011-07-01 07:46:56 --> Utf8 Class Initialized
DEBUG - 2011-07-01 07:46:56 --> UTF-8 Support Enabled
DEBUG - 2011-07-01 07:46:56 --> URI Class Initialized
DEBUG - 2011-07-01 07:46:56 --> Router Class Initialized
ERROR - 2011-07-01 07:46:56 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-07-01 07:46:56 --> Config Class Initialized
DEBUG - 2011-07-01 07:46:56 --> Hooks Class Initialized
DEBUG - 2011-07-01 07:46:56 --> Utf8 Class Initialized
DEBUG - 2011-07-01 07:46:56 --> UTF-8 Support Enabled
DEBUG - 2011-07-01 07:46:56 --> URI Class Initialized
DEBUG - 2011-07-01 07:46:56 --> Router Class Initialized
ERROR - 2011-07-01 07:46:56 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-07-01 11:42:44 --> Config Class Initialized
DEBUG - 2011-07-01 11:42:44 --> Hooks Class Initialized
DEBUG - 2011-07-01 11:42:44 --> Utf8 Class Initialized
DEBUG - 2011-07-01 11:42:44 --> UTF-8 Support Enabled
DEBUG - 2011-07-01 11:42:44 --> URI Class Initialized
DEBUG - 2011-07-01 11:42:44 --> Router Class Initialized
DEBUG - 2011-07-01 11:42:44 --> No URI present. Default controller set.
DEBUG - 2011-07-01 11:42:44 --> Output Class Initialized
DEBUG - 2011-07-01 11:42:44 --> Input Class Initialized
DEBUG - 2011-07-01 11:42:44 --> Global POST and COOKIE data sanitized
DEBUG - 2011-07-01 11:42:44 --> Language Class Initialized
DEBUG - 2011-07-01 11:42:44 --> Loader Class Initialized
DEBUG - 2011-07-01 11:42:44 --> Controller Class Initialized
DEBUG - 2011-07-01 11:42:44 --> File loaded: application/views/splash/main.php
DEBUG - 2011-07-01 11:42:44 --> Helper loaded: url_helper
DEBUG - 2011-07-01 11:42:44 --> File loaded: application/views/common/header.php
DEBUG - 2011-07-01 11:42:44 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-07-01 11:42:44 --> File loaded: application/views/common/footer.php
DEBUG - 2011-07-01 11:42:44 --> File loaded: application/views/layout/main.php
DEBUG - 2011-07-01 11:42:44 --> Final output sent to browser
DEBUG - 2011-07-01 11:42:44 --> Total execution time: 0.2741
DEBUG - 2011-07-01 11:42:46 --> Config Class Initialized
DEBUG - 2011-07-01 11:42:46 --> Hooks Class Initialized
DEBUG - 2011-07-01 11:42:46 --> Utf8 Class Initialized
DEBUG - 2011-07-01 11:42:46 --> UTF-8 Support Enabled
DEBUG - 2011-07-01 11:42:46 --> URI Class Initialized
DEBUG - 2011-07-01 11:42:46 --> Router Class Initialized
ERROR - 2011-07-01 11:42:46 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-07-01 11:42:51 --> Config Class Initialized
DEBUG - 2011-07-01 11:42:51 --> Hooks Class Initialized
DEBUG - 2011-07-01 11:42:51 --> Utf8 Class Initialized
DEBUG - 2011-07-01 11:42:51 --> UTF-8 Support Enabled
DEBUG - 2011-07-01 11:42:51 --> URI Class Initialized
DEBUG - 2011-07-01 11:42:51 --> Router Class Initialized
DEBUG - 2011-07-01 11:42:51 --> Output Class Initialized
DEBUG - 2011-07-01 11:42:51 --> Input Class Initialized
DEBUG - 2011-07-01 11:42:51 --> Global POST and COOKIE data sanitized
DEBUG - 2011-07-01 11:42:51 --> Language Class Initialized
DEBUG - 2011-07-01 11:42:51 --> Loader Class Initialized
DEBUG - 2011-07-01 11:42:51 --> Controller Class Initialized
DEBUG - 2011-07-01 11:42:51 --> Model Class Initialized
DEBUG - 2011-07-01 11:42:51 --> Model Class Initialized
DEBUG - 2011-07-01 11:42:51 --> Model Class Initialized
DEBUG - 2011-07-01 11:42:51 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-07-01 11:42:51 --> Database Driver Class Initialized
DEBUG - 2011-07-01 11:42:52 --> File loaded: application/views/table/main.php
DEBUG - 2011-07-01 11:42:52 --> Helper loaded: url_helper
DEBUG - 2011-07-01 11:42:52 --> File loaded: application/views/common/header.php
DEBUG - 2011-07-01 11:42:52 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-07-01 11:42:52 --> File loaded: application/views/common/footer.php
DEBUG - 2011-07-01 11:42:52 --> File loaded: application/views/layout/main.php
DEBUG - 2011-07-01 11:42:52 --> Final output sent to browser
DEBUG - 2011-07-01 11:42:52 --> Total execution time: 0.5653
DEBUG - 2011-07-01 11:42:53 --> Config Class Initialized
DEBUG - 2011-07-01 11:42:53 --> Hooks Class Initialized
DEBUG - 2011-07-01 11:42:53 --> Utf8 Class Initialized
DEBUG - 2011-07-01 11:42:53 --> UTF-8 Support Enabled
DEBUG - 2011-07-01 11:42:53 --> URI Class Initialized
DEBUG - 2011-07-01 11:42:53 --> Router Class Initialized
ERROR - 2011-07-01 11:42:53 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-07-01 11:43:04 --> Config Class Initialized
DEBUG - 2011-07-01 11:43:04 --> Hooks Class Initialized
DEBUG - 2011-07-01 11:43:04 --> Utf8 Class Initialized
DEBUG - 2011-07-01 11:43:04 --> UTF-8 Support Enabled
DEBUG - 2011-07-01 11:43:04 --> URI Class Initialized
DEBUG - 2011-07-01 11:43:04 --> Router Class Initialized
DEBUG - 2011-07-01 11:43:04 --> Output Class Initialized
DEBUG - 2011-07-01 11:43:04 --> Input Class Initialized
DEBUG - 2011-07-01 11:43:04 --> Global POST and COOKIE data sanitized
DEBUG - 2011-07-01 11:43:04 --> Language Class Initialized
DEBUG - 2011-07-01 11:43:04 --> Loader Class Initialized
DEBUG - 2011-07-01 11:43:04 --> Controller Class Initialized
DEBUG - 2011-07-01 11:43:04 --> Model Class Initialized
DEBUG - 2011-07-01 11:43:04 --> Model Class Initialized
DEBUG - 2011-07-01 11:43:04 --> Model Class Initialized
DEBUG - 2011-07-01 11:43:04 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-07-01 11:43:04 --> Database Driver Class Initialized
DEBUG - 2011-07-01 11:43:05 --> File loaded: application/views/table/main.php
DEBUG - 2011-07-01 11:43:05 --> Helper loaded: url_helper
DEBUG - 2011-07-01 11:43:05 --> File loaded: application/views/common/header.php
DEBUG - 2011-07-01 11:43:05 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-07-01 11:43:05 --> File loaded: application/views/common/footer.php
DEBUG - 2011-07-01 11:43:05 --> File loaded: application/views/layout/main.php
DEBUG - 2011-07-01 11:43:05 --> Final output sent to browser
DEBUG - 2011-07-01 11:43:05 --> Total execution time: 0.5358
DEBUG - 2011-07-01 11:43:07 --> Config Class Initialized
DEBUG - 2011-07-01 11:43:07 --> Hooks Class Initialized
DEBUG - 2011-07-01 11:43:07 --> Utf8 Class Initialized
DEBUG - 2011-07-01 11:43:07 --> UTF-8 Support Enabled
DEBUG - 2011-07-01 11:43:07 --> URI Class Initialized
DEBUG - 2011-07-01 11:43:07 --> Router Class Initialized
ERROR - 2011-07-01 11:43:07 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-07-01 11:43:27 --> Config Class Initialized
DEBUG - 2011-07-01 11:43:27 --> Hooks Class Initialized
DEBUG - 2011-07-01 11:43:27 --> Utf8 Class Initialized
DEBUG - 2011-07-01 11:43:27 --> UTF-8 Support Enabled
DEBUG - 2011-07-01 11:43:27 --> URI Class Initialized
DEBUG - 2011-07-01 11:43:27 --> Router Class Initialized
DEBUG - 2011-07-01 11:43:27 --> Output Class Initialized
DEBUG - 2011-07-01 11:43:27 --> Input Class Initialized
DEBUG - 2011-07-01 11:43:27 --> Global POST and COOKIE data sanitized
DEBUG - 2011-07-01 11:43:27 --> Language Class Initialized
DEBUG - 2011-07-01 11:43:27 --> Loader Class Initialized
DEBUG - 2011-07-01 11:43:27 --> Controller Class Initialized
DEBUG - 2011-07-01 11:43:27 --> Model Class Initialized
DEBUG - 2011-07-01 11:43:27 --> Model Class Initialized
DEBUG - 2011-07-01 11:43:27 --> Model Class Initialized
DEBUG - 2011-07-01 11:43:27 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-07-01 11:43:27 --> Database Driver Class Initialized
DEBUG - 2011-07-01 11:43:28 --> File loaded: application/views/table/main.php
DEBUG - 2011-07-01 11:43:28 --> Helper loaded: url_helper
DEBUG - 2011-07-01 11:43:28 --> File loaded: application/views/common/header.php
DEBUG - 2011-07-01 11:43:28 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-07-01 11:43:28 --> File loaded: application/views/common/footer.php
DEBUG - 2011-07-01 11:43:28 --> File loaded: application/views/layout/main.php
DEBUG - 2011-07-01 11:43:28 --> Final output sent to browser
DEBUG - 2011-07-01 11:43:28 --> Total execution time: 1.0422
DEBUG - 2011-07-01 11:43:30 --> Config Class Initialized
DEBUG - 2011-07-01 11:43:30 --> Hooks Class Initialized
DEBUG - 2011-07-01 11:43:30 --> Utf8 Class Initialized
DEBUG - 2011-07-01 11:43:30 --> UTF-8 Support Enabled
DEBUG - 2011-07-01 11:43:30 --> URI Class Initialized
DEBUG - 2011-07-01 11:43:30 --> Router Class Initialized
ERROR - 2011-07-01 11:43:30 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-07-01 11:43:36 --> Config Class Initialized
DEBUG - 2011-07-01 11:43:36 --> Hooks Class Initialized
DEBUG - 2011-07-01 11:43:36 --> Utf8 Class Initialized
DEBUG - 2011-07-01 11:43:36 --> UTF-8 Support Enabled
DEBUG - 2011-07-01 11:43:36 --> URI Class Initialized
DEBUG - 2011-07-01 11:43:36 --> Router Class Initialized
ERROR - 2011-07-01 11:43:36 --> 404 Page Not Found --> robots.txt
DEBUG - 2011-07-01 11:43:36 --> Config Class Initialized
DEBUG - 2011-07-01 11:43:36 --> Hooks Class Initialized
DEBUG - 2011-07-01 11:43:36 --> Utf8 Class Initialized
DEBUG - 2011-07-01 11:43:36 --> UTF-8 Support Enabled
DEBUG - 2011-07-01 11:43:36 --> URI Class Initialized
DEBUG - 2011-07-01 11:43:36 --> Router Class Initialized
DEBUG - 2011-07-01 11:43:36 --> No URI present. Default controller set.
DEBUG - 2011-07-01 11:43:36 --> Output Class Initialized
DEBUG - 2011-07-01 11:43:36 --> Input Class Initialized
DEBUG - 2011-07-01 11:43:36 --> Global POST and COOKIE data sanitized
DEBUG - 2011-07-01 11:43:36 --> Language Class Initialized
DEBUG - 2011-07-01 11:43:36 --> Loader Class Initialized
DEBUG - 2011-07-01 11:43:36 --> Controller Class Initialized
DEBUG - 2011-07-01 11:43:36 --> File loaded: application/views/splash/main.php
DEBUG - 2011-07-01 11:43:36 --> Helper loaded: url_helper
DEBUG - 2011-07-01 11:43:36 --> File loaded: application/views/common/header.php
DEBUG - 2011-07-01 11:43:36 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-07-01 11:43:36 --> File loaded: application/views/common/footer.php
DEBUG - 2011-07-01 11:43:36 --> File loaded: application/views/layout/main.php
DEBUG - 2011-07-01 11:43:36 --> Final output sent to browser
DEBUG - 2011-07-01 11:43:36 --> Total execution time: 0.0154
DEBUG - 2011-07-01 11:43:41 --> Config Class Initialized
DEBUG - 2011-07-01 11:43:41 --> Hooks Class Initialized
DEBUG - 2011-07-01 11:43:41 --> Utf8 Class Initialized
DEBUG - 2011-07-01 11:43:41 --> UTF-8 Support Enabled
DEBUG - 2011-07-01 11:43:41 --> URI Class Initialized
DEBUG - 2011-07-01 11:43:41 --> Router Class Initialized
DEBUG - 2011-07-01 11:43:41 --> Output Class Initialized
DEBUG - 2011-07-01 11:43:41 --> Input Class Initialized
DEBUG - 2011-07-01 11:43:41 --> Global POST and COOKIE data sanitized
DEBUG - 2011-07-01 11:43:41 --> Language Class Initialized
DEBUG - 2011-07-01 11:43:41 --> Loader Class Initialized
DEBUG - 2011-07-01 11:43:41 --> Controller Class Initialized
DEBUG - 2011-07-01 11:43:41 --> Model Class Initialized
DEBUG - 2011-07-01 11:43:41 --> Model Class Initialized
DEBUG - 2011-07-01 11:43:41 --> Model Class Initialized
DEBUG - 2011-07-01 11:43:41 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-07-01 11:43:41 --> Database Driver Class Initialized
DEBUG - 2011-07-01 11:43:41 --> File loaded: application/views/table/main.php
DEBUG - 2011-07-01 11:43:41 --> Helper loaded: url_helper
DEBUG - 2011-07-01 11:43:41 --> File loaded: application/views/common/header.php
DEBUG - 2011-07-01 11:43:41 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-07-01 11:43:41 --> File loaded: application/views/common/footer.php
DEBUG - 2011-07-01 11:43:41 --> File loaded: application/views/layout/main.php
DEBUG - 2011-07-01 11:43:41 --> Final output sent to browser
DEBUG - 2011-07-01 11:43:41 --> Total execution time: 0.2189
DEBUG - 2011-07-01 11:43:43 --> Config Class Initialized
DEBUG - 2011-07-01 11:43:43 --> Hooks Class Initialized
DEBUG - 2011-07-01 11:43:43 --> Utf8 Class Initialized
DEBUG - 2011-07-01 11:43:43 --> UTF-8 Support Enabled
DEBUG - 2011-07-01 11:43:43 --> URI Class Initialized
DEBUG - 2011-07-01 11:43:43 --> Router Class Initialized
ERROR - 2011-07-01 11:43:43 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-07-01 11:44:57 --> Config Class Initialized
DEBUG - 2011-07-01 11:44:57 --> Hooks Class Initialized
DEBUG - 2011-07-01 11:44:57 --> Utf8 Class Initialized
DEBUG - 2011-07-01 11:44:57 --> UTF-8 Support Enabled
DEBUG - 2011-07-01 11:44:57 --> URI Class Initialized
DEBUG - 2011-07-01 11:44:57 --> Router Class Initialized
DEBUG - 2011-07-01 11:44:57 --> Output Class Initialized
DEBUG - 2011-07-01 11:44:57 --> Input Class Initialized
DEBUG - 2011-07-01 11:44:57 --> Global POST and COOKIE data sanitized
DEBUG - 2011-07-01 11:44:57 --> Language Class Initialized
DEBUG - 2011-07-01 11:44:57 --> Loader Class Initialized
DEBUG - 2011-07-01 11:44:57 --> Controller Class Initialized
DEBUG - 2011-07-01 11:44:57 --> Model Class Initialized
DEBUG - 2011-07-01 11:44:57 --> Model Class Initialized
DEBUG - 2011-07-01 11:44:57 --> Model Class Initialized
DEBUG - 2011-07-01 11:44:57 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-07-01 11:44:57 --> Database Driver Class Initialized
DEBUG - 2011-07-01 11:44:57 --> File loaded: application/views/table/main.php
DEBUG - 2011-07-01 11:44:57 --> Helper loaded: url_helper
DEBUG - 2011-07-01 11:44:57 --> File loaded: application/views/common/header.php
DEBUG - 2011-07-01 11:44:57 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-07-01 11:44:57 --> File loaded: application/views/common/footer.php
DEBUG - 2011-07-01 11:44:57 --> File loaded: application/views/layout/main.php
DEBUG - 2011-07-01 11:44:57 --> Final output sent to browser
DEBUG - 2011-07-01 11:44:57 --> Total execution time: 0.0469
DEBUG - 2011-07-01 11:44:58 --> Config Class Initialized
DEBUG - 2011-07-01 11:44:58 --> Hooks Class Initialized
DEBUG - 2011-07-01 11:44:58 --> Utf8 Class Initialized
DEBUG - 2011-07-01 11:44:58 --> UTF-8 Support Enabled
DEBUG - 2011-07-01 11:44:58 --> URI Class Initialized
DEBUG - 2011-07-01 11:44:58 --> Router Class Initialized
DEBUG - 2011-07-01 11:44:58 --> Output Class Initialized
DEBUG - 2011-07-01 11:44:58 --> Input Class Initialized
DEBUG - 2011-07-01 11:44:58 --> Global POST and COOKIE data sanitized
DEBUG - 2011-07-01 11:44:58 --> Language Class Initialized
DEBUG - 2011-07-01 11:44:58 --> Loader Class Initialized
DEBUG - 2011-07-01 11:44:58 --> Controller Class Initialized
DEBUG - 2011-07-01 11:44:58 --> Model Class Initialized
DEBUG - 2011-07-01 11:44:58 --> Model Class Initialized
DEBUG - 2011-07-01 11:44:58 --> Model Class Initialized
DEBUG - 2011-07-01 11:44:58 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-07-01 11:44:58 --> Database Driver Class Initialized
DEBUG - 2011-07-01 11:44:58 --> File loaded: application/views/table/main.php
DEBUG - 2011-07-01 11:44:58 --> Helper loaded: url_helper
DEBUG - 2011-07-01 11:44:58 --> File loaded: application/views/common/header.php
DEBUG - 2011-07-01 11:44:58 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-07-01 11:44:58 --> File loaded: application/views/common/footer.php
DEBUG - 2011-07-01 11:44:58 --> File loaded: application/views/layout/main.php
DEBUG - 2011-07-01 11:44:58 --> Final output sent to browser
DEBUG - 2011-07-01 11:44:58 --> Total execution time: 0.0464
DEBUG - 2011-07-01 11:44:59 --> Config Class Initialized
DEBUG - 2011-07-01 11:44:59 --> Hooks Class Initialized
DEBUG - 2011-07-01 11:44:59 --> Utf8 Class Initialized
DEBUG - 2011-07-01 11:44:59 --> UTF-8 Support Enabled
DEBUG - 2011-07-01 11:44:59 --> URI Class Initialized
DEBUG - 2011-07-01 11:44:59 --> Router Class Initialized
DEBUG - 2011-07-01 11:44:59 --> Output Class Initialized
DEBUG - 2011-07-01 11:44:59 --> Input Class Initialized
DEBUG - 2011-07-01 11:44:59 --> Global POST and COOKIE data sanitized
DEBUG - 2011-07-01 11:44:59 --> Language Class Initialized
DEBUG - 2011-07-01 11:44:59 --> Loader Class Initialized
DEBUG - 2011-07-01 11:44:59 --> Controller Class Initialized
DEBUG - 2011-07-01 11:44:59 --> Model Class Initialized
DEBUG - 2011-07-01 11:44:59 --> Model Class Initialized
DEBUG - 2011-07-01 11:44:59 --> Model Class Initialized
DEBUG - 2011-07-01 11:44:59 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-07-01 11:44:59 --> Database Driver Class Initialized
DEBUG - 2011-07-01 11:44:59 --> File loaded: application/views/table/main.php
DEBUG - 2011-07-01 11:44:59 --> Helper loaded: url_helper
DEBUG - 2011-07-01 11:44:59 --> File loaded: application/views/common/header.php
DEBUG - 2011-07-01 11:44:59 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-07-01 11:44:59 --> File loaded: application/views/common/footer.php
DEBUG - 2011-07-01 11:44:59 --> File loaded: application/views/layout/main.php
DEBUG - 2011-07-01 11:44:59 --> Final output sent to browser
DEBUG - 2011-07-01 11:44:59 --> Total execution time: 0.0510
DEBUG - 2011-07-01 12:35:41 --> Config Class Initialized
DEBUG - 2011-07-01 12:35:41 --> Hooks Class Initialized
DEBUG - 2011-07-01 12:35:41 --> Utf8 Class Initialized
DEBUG - 2011-07-01 12:35:41 --> UTF-8 Support Enabled
DEBUG - 2011-07-01 12:35:41 --> URI Class Initialized
DEBUG - 2011-07-01 12:35:41 --> Router Class Initialized
DEBUG - 2011-07-01 12:35:41 --> No URI present. Default controller set.
DEBUG - 2011-07-01 12:35:41 --> Output Class Initialized
DEBUG - 2011-07-01 12:35:41 --> Input Class Initialized
DEBUG - 2011-07-01 12:35:41 --> Global POST and COOKIE data sanitized
DEBUG - 2011-07-01 12:35:41 --> Language Class Initialized
DEBUG - 2011-07-01 12:35:41 --> Loader Class Initialized
DEBUG - 2011-07-01 12:35:41 --> Controller Class Initialized
DEBUG - 2011-07-01 12:35:41 --> File loaded: application/views/splash/main.php
DEBUG - 2011-07-01 12:35:42 --> Helper loaded: url_helper
DEBUG - 2011-07-01 12:35:42 --> File loaded: application/views/common/header.php
DEBUG - 2011-07-01 12:35:42 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-07-01 12:35:42 --> File loaded: application/views/common/footer.php
DEBUG - 2011-07-01 12:35:42 --> File loaded: application/views/layout/main.php
DEBUG - 2011-07-01 12:35:42 --> Final output sent to browser
DEBUG - 2011-07-01 12:35:42 --> Total execution time: 0.2483
DEBUG - 2011-07-01 14:19:31 --> Config Class Initialized
DEBUG - 2011-07-01 14:19:31 --> Hooks Class Initialized
DEBUG - 2011-07-01 14:19:31 --> Utf8 Class Initialized
DEBUG - 2011-07-01 14:19:31 --> UTF-8 Support Enabled
DEBUG - 2011-07-01 14:19:31 --> URI Class Initialized
DEBUG - 2011-07-01 14:19:31 --> Router Class Initialized
DEBUG - 2011-07-01 14:19:31 --> Output Class Initialized
DEBUG - 2011-07-01 14:19:32 --> Input Class Initialized
DEBUG - 2011-07-01 14:19:32 --> Global POST and COOKIE data sanitized
DEBUG - 2011-07-01 14:19:32 --> Language Class Initialized
DEBUG - 2011-07-01 14:19:32 --> Loader Class Initialized
DEBUG - 2011-07-01 14:19:32 --> Controller Class Initialized
ERROR - 2011-07-01 14:19:32 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-07-01 14:19:32 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-07-01 14:19:32 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-07-01 14:19:32 --> Model Class Initialized
DEBUG - 2011-07-01 14:19:32 --> Model Class Initialized
DEBUG - 2011-07-01 14:19:32 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-07-01 14:19:32 --> Database Driver Class Initialized
DEBUG - 2011-07-01 14:19:32 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-07-01 14:19:32 --> Helper loaded: url_helper
DEBUG - 2011-07-01 14:19:32 --> File loaded: application/views/common/header.php
DEBUG - 2011-07-01 14:19:32 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-07-01 14:19:32 --> File loaded: application/views/common/footer.php
DEBUG - 2011-07-01 14:19:32 --> File loaded: application/views/layout/main.php
DEBUG - 2011-07-01 14:19:32 --> Final output sent to browser
DEBUG - 2011-07-01 14:19:32 --> Total execution time: 0.6762
DEBUG - 2011-07-01 14:19:33 --> Config Class Initialized
DEBUG - 2011-07-01 14:19:33 --> Hooks Class Initialized
DEBUG - 2011-07-01 14:19:33 --> Utf8 Class Initialized
DEBUG - 2011-07-01 14:19:33 --> UTF-8 Support Enabled
DEBUG - 2011-07-01 14:19:33 --> URI Class Initialized
DEBUG - 2011-07-01 14:19:33 --> Router Class Initialized
DEBUG - 2011-07-01 14:19:33 --> Output Class Initialized
DEBUG - 2011-07-01 14:19:33 --> Input Class Initialized
DEBUG - 2011-07-01 14:19:33 --> Global POST and COOKIE data sanitized
DEBUG - 2011-07-01 14:19:33 --> Language Class Initialized
DEBUG - 2011-07-01 14:19:33 --> Loader Class Initialized
DEBUG - 2011-07-01 14:19:33 --> Controller Class Initialized
DEBUG - 2011-07-01 14:19:33 --> Model Class Initialized
DEBUG - 2011-07-01 14:19:33 --> Model Class Initialized
DEBUG - 2011-07-01 14:19:33 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-07-01 14:19:33 --> Database Driver Class Initialized
DEBUG - 2011-07-01 14:19:34 --> Final output sent to browser
DEBUG - 2011-07-01 14:19:34 --> Total execution time: 1.0754
DEBUG - 2011-07-01 14:19:36 --> Config Class Initialized
DEBUG - 2011-07-01 14:19:36 --> Hooks Class Initialized
DEBUG - 2011-07-01 14:19:36 --> Utf8 Class Initialized
DEBUG - 2011-07-01 14:19:36 --> UTF-8 Support Enabled
DEBUG - 2011-07-01 14:19:36 --> URI Class Initialized
DEBUG - 2011-07-01 14:19:36 --> Router Class Initialized
ERROR - 2011-07-01 14:19:36 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-07-01 14:19:37 --> Config Class Initialized
DEBUG - 2011-07-01 14:19:37 --> Hooks Class Initialized
DEBUG - 2011-07-01 14:19:37 --> Utf8 Class Initialized
DEBUG - 2011-07-01 14:19:37 --> UTF-8 Support Enabled
DEBUG - 2011-07-01 14:19:37 --> URI Class Initialized
DEBUG - 2011-07-01 14:19:37 --> Router Class Initialized
ERROR - 2011-07-01 14:19:37 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-07-01 14:19:37 --> Config Class Initialized
DEBUG - 2011-07-01 14:19:37 --> Hooks Class Initialized
DEBUG - 2011-07-01 14:19:37 --> Utf8 Class Initialized
DEBUG - 2011-07-01 14:19:37 --> UTF-8 Support Enabled
DEBUG - 2011-07-01 14:19:37 --> URI Class Initialized
DEBUG - 2011-07-01 14:19:37 --> Router Class Initialized
ERROR - 2011-07-01 14:19:37 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-07-01 18:54:54 --> Config Class Initialized
DEBUG - 2011-07-01 18:54:54 --> Hooks Class Initialized
DEBUG - 2011-07-01 18:54:54 --> Utf8 Class Initialized
DEBUG - 2011-07-01 18:54:54 --> UTF-8 Support Enabled
DEBUG - 2011-07-01 18:54:54 --> URI Class Initialized
DEBUG - 2011-07-01 18:54:54 --> Router Class Initialized
DEBUG - 2011-07-01 18:54:54 --> No URI present. Default controller set.
DEBUG - 2011-07-01 18:54:54 --> Output Class Initialized
DEBUG - 2011-07-01 18:54:54 --> Input Class Initialized
DEBUG - 2011-07-01 18:54:54 --> Global POST and COOKIE data sanitized
DEBUG - 2011-07-01 18:54:54 --> Language Class Initialized
DEBUG - 2011-07-01 18:54:54 --> Loader Class Initialized
DEBUG - 2011-07-01 18:54:54 --> Controller Class Initialized
DEBUG - 2011-07-01 18:54:54 --> File loaded: application/views/splash/main.php
DEBUG - 2011-07-01 18:54:55 --> Helper loaded: url_helper
DEBUG - 2011-07-01 18:54:55 --> File loaded: application/views/common/header.php
DEBUG - 2011-07-01 18:54:55 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-07-01 18:54:55 --> File loaded: application/views/common/footer.php
DEBUG - 2011-07-01 18:54:55 --> File loaded: application/views/layout/main.php
DEBUG - 2011-07-01 18:54:55 --> Final output sent to browser
DEBUG - 2011-07-01 18:54:55 --> Total execution time: 0.2705
DEBUG - 2011-07-01 18:59:43 --> Config Class Initialized
DEBUG - 2011-07-01 18:59:43 --> Hooks Class Initialized
DEBUG - 2011-07-01 18:59:43 --> Utf8 Class Initialized
DEBUG - 2011-07-01 18:59:43 --> UTF-8 Support Enabled
DEBUG - 2011-07-01 18:59:43 --> URI Class Initialized
DEBUG - 2011-07-01 18:59:43 --> Config Class Initialized
DEBUG - 2011-07-01 18:59:43 --> Router Class Initialized
DEBUG - 2011-07-01 18:59:43 --> Hooks Class Initialized
DEBUG - 2011-07-01 18:59:43 --> Utf8 Class Initialized
DEBUG - 2011-07-01 18:59:43 --> UTF-8 Support Enabled
DEBUG - 2011-07-01 18:59:43 --> URI Class Initialized
DEBUG - 2011-07-01 18:59:43 --> Router Class Initialized
DEBUG - 2011-07-01 18:59:43 --> Output Class Initialized
DEBUG - 2011-07-01 18:59:43 --> Output Class Initialized
DEBUG - 2011-07-01 18:59:43 --> Input Class Initialized
DEBUG - 2011-07-01 18:59:43 --> Input Class Initialized
DEBUG - 2011-07-01 18:59:43 --> Global POST and COOKIE data sanitized
DEBUG - 2011-07-01 18:59:43 --> Global POST and COOKIE data sanitized
DEBUG - 2011-07-01 18:59:43 --> Language Class Initialized
DEBUG - 2011-07-01 18:59:43 --> Language Class Initialized
DEBUG - 2011-07-01 18:59:43 --> Loader Class Initialized
DEBUG - 2011-07-01 18:59:43 --> Controller Class Initialized
DEBUG - 2011-07-01 18:59:43 --> Loader Class Initialized
DEBUG - 2011-07-01 18:59:43 --> Controller Class Initialized
DEBUG - 2011-07-01 18:59:43 --> Model Class Initialized
ERROR - 2011-07-01 18:59:43 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-07-01 18:59:43 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-07-01 18:59:43 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-07-01 18:59:43 --> Model Class Initialized
DEBUG - 2011-07-01 18:59:43 --> Model Class Initialized
DEBUG - 2011-07-01 18:59:43 --> Model Class Initialized
DEBUG - 2011-07-01 18:59:43 --> Model Class Initialized
DEBUG - 2011-07-01 18:59:43 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-07-01 18:59:43 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-07-01 18:59:43 --> Database Driver Class Initialized
DEBUG - 2011-07-01 18:59:43 --> Database Driver Class Initialized
DEBUG - 2011-07-01 18:59:43 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-07-01 18:59:43 --> Helper loaded: url_helper
DEBUG - 2011-07-01 18:59:43 --> File loaded: application/views/common/header.php
DEBUG - 2011-07-01 18:59:43 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-07-01 18:59:43 --> File loaded: application/views/common/footer.php
DEBUG - 2011-07-01 18:59:43 --> File loaded: application/views/layout/main.php
DEBUG - 2011-07-01 18:59:43 --> Final output sent to browser
DEBUG - 2011-07-01 18:59:43 --> Total execution time: 0.2003
DEBUG - 2011-07-01 18:59:43 --> File loaded: application/views/table/main.php
DEBUG - 2011-07-01 18:59:43 --> Helper loaded: url_helper
DEBUG - 2011-07-01 18:59:43 --> File loaded: application/views/common/header.php
DEBUG - 2011-07-01 18:59:43 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-07-01 18:59:43 --> File loaded: application/views/common/footer.php
DEBUG - 2011-07-01 18:59:43 --> File loaded: application/views/layout/main.php
DEBUG - 2011-07-01 18:59:43 --> Final output sent to browser
DEBUG - 2011-07-01 18:59:43 --> Total execution time: 0.4495
DEBUG - 2011-07-01 22:21:37 --> Config Class Initialized
DEBUG - 2011-07-01 22:21:37 --> Hooks Class Initialized
DEBUG - 2011-07-01 22:21:37 --> Utf8 Class Initialized
DEBUG - 2011-07-01 22:21:37 --> UTF-8 Support Enabled
DEBUG - 2011-07-01 22:21:37 --> URI Class Initialized
DEBUG - 2011-07-01 22:21:37 --> Router Class Initialized
DEBUG - 2011-07-01 22:21:37 --> No URI present. Default controller set.
DEBUG - 2011-07-01 22:21:37 --> Output Class Initialized
DEBUG - 2011-07-01 22:21:37 --> Input Class Initialized
DEBUG - 2011-07-01 22:21:37 --> Global POST and COOKIE data sanitized
DEBUG - 2011-07-01 22:21:37 --> Language Class Initialized
DEBUG - 2011-07-01 22:21:37 --> Loader Class Initialized
DEBUG - 2011-07-01 22:21:37 --> Controller Class Initialized
DEBUG - 2011-07-01 22:21:37 --> File loaded: application/views/splash/main.php
DEBUG - 2011-07-01 22:21:37 --> Helper loaded: url_helper
DEBUG - 2011-07-01 22:21:37 --> File loaded: application/views/common/header.php
DEBUG - 2011-07-01 22:21:37 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-07-01 22:21:37 --> File loaded: application/views/common/footer.php
DEBUG - 2011-07-01 22:21:37 --> File loaded: application/views/layout/main.php
DEBUG - 2011-07-01 22:21:37 --> Final output sent to browser
DEBUG - 2011-07-01 22:21:37 --> Total execution time: 0.2898
DEBUG - 2011-07-01 22:33:48 --> Config Class Initialized
DEBUG - 2011-07-01 22:33:48 --> Hooks Class Initialized
DEBUG - 2011-07-01 22:33:48 --> Utf8 Class Initialized
DEBUG - 2011-07-01 22:33:48 --> UTF-8 Support Enabled
DEBUG - 2011-07-01 22:33:48 --> URI Class Initialized
DEBUG - 2011-07-01 22:33:48 --> Router Class Initialized
ERROR - 2011-07-01 22:33:48 --> 404 Page Not Found --> robots.txt

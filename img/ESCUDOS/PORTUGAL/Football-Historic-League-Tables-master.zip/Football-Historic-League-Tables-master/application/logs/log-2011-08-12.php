<?php  if ( ! defined('BASEPATH')) exit('No direct script access allowed'); ?>

DEBUG - 2011-08-12 02:11:13 --> Config Class Initialized
DEBUG - 2011-08-12 02:11:13 --> Hooks Class Initialized
DEBUG - 2011-08-12 02:11:13 --> Utf8 Class Initialized
DEBUG - 2011-08-12 02:11:13 --> UTF-8 Support Enabled
DEBUG - 2011-08-12 02:11:13 --> URI Class Initialized
DEBUG - 2011-08-12 02:11:13 --> Router Class Initialized
ERROR - 2011-08-12 02:11:13 --> 404 Page Not Found --> robots.txt
DEBUG - 2011-08-12 02:11:13 --> Config Class Initialized
DEBUG - 2011-08-12 02:11:13 --> Hooks Class Initialized
DEBUG - 2011-08-12 02:11:13 --> Utf8 Class Initialized
DEBUG - 2011-08-12 02:11:13 --> UTF-8 Support Enabled
DEBUG - 2011-08-12 02:11:13 --> URI Class Initialized
DEBUG - 2011-08-12 02:11:13 --> Router Class Initialized
DEBUG - 2011-08-12 02:11:13 --> Output Class Initialized
DEBUG - 2011-08-12 02:11:13 --> Input Class Initialized
DEBUG - 2011-08-12 02:11:13 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-12 02:11:13 --> Language Class Initialized
DEBUG - 2011-08-12 02:11:13 --> Loader Class Initialized
DEBUG - 2011-08-12 02:11:13 --> Controller Class Initialized
DEBUG - 2011-08-12 02:11:13 --> Model Class Initialized
DEBUG - 2011-08-12 02:11:13 --> Model Class Initialized
DEBUG - 2011-08-12 02:11:13 --> Model Class Initialized
DEBUG - 2011-08-12 02:11:13 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-12 02:11:13 --> Database Driver Class Initialized
DEBUG - 2011-08-12 02:11:16 --> File loaded: application/views/table/main.php
DEBUG - 2011-08-12 02:11:16 --> Helper loaded: url_helper
DEBUG - 2011-08-12 02:11:16 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-12 02:11:16 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-12 02:11:16 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-12 02:11:16 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-12 02:11:16 --> Final output sent to browser
DEBUG - 2011-08-12 02:11:16 --> Total execution time: 2.7033
DEBUG - 2011-08-12 02:14:06 --> Config Class Initialized
DEBUG - 2011-08-12 02:14:06 --> Hooks Class Initialized
DEBUG - 2011-08-12 02:14:06 --> Utf8 Class Initialized
DEBUG - 2011-08-12 02:14:06 --> UTF-8 Support Enabled
DEBUG - 2011-08-12 02:14:06 --> URI Class Initialized
DEBUG - 2011-08-12 02:14:06 --> Router Class Initialized
DEBUG - 2011-08-12 02:14:06 --> No URI present. Default controller set.
DEBUG - 2011-08-12 02:14:06 --> Output Class Initialized
DEBUG - 2011-08-12 02:14:06 --> Input Class Initialized
DEBUG - 2011-08-12 02:14:06 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-12 02:14:06 --> Language Class Initialized
DEBUG - 2011-08-12 02:14:06 --> Loader Class Initialized
DEBUG - 2011-08-12 02:14:06 --> Controller Class Initialized
DEBUG - 2011-08-12 02:14:06 --> File loaded: application/views/splash/main.php
DEBUG - 2011-08-12 02:14:06 --> Helper loaded: url_helper
DEBUG - 2011-08-12 02:14:06 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-12 02:14:06 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-12 02:14:06 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-12 02:14:06 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-12 02:14:06 --> Final output sent to browser
DEBUG - 2011-08-12 02:14:06 --> Total execution time: 0.2829
DEBUG - 2011-08-12 03:54:31 --> Config Class Initialized
DEBUG - 2011-08-12 03:54:31 --> Hooks Class Initialized
DEBUG - 2011-08-12 03:54:31 --> Utf8 Class Initialized
DEBUG - 2011-08-12 03:54:31 --> UTF-8 Support Enabled
DEBUG - 2011-08-12 03:54:31 --> URI Class Initialized
DEBUG - 2011-08-12 03:54:31 --> Router Class Initialized
DEBUG - 2011-08-12 03:54:31 --> Output Class Initialized
DEBUG - 2011-08-12 03:54:31 --> Input Class Initialized
DEBUG - 2011-08-12 03:54:31 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-12 03:54:31 --> Language Class Initialized
DEBUG - 2011-08-12 03:54:31 --> Loader Class Initialized
DEBUG - 2011-08-12 03:54:31 --> Controller Class Initialized
ERROR - 2011-08-12 03:54:31 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-08-12 03:54:31 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-08-12 03:54:31 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-08-12 03:54:31 --> Model Class Initialized
DEBUG - 2011-08-12 03:54:31 --> Model Class Initialized
DEBUG - 2011-08-12 03:54:31 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-12 03:54:31 --> Database Driver Class Initialized
DEBUG - 2011-08-12 03:54:32 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-08-12 03:54:32 --> Helper loaded: url_helper
DEBUG - 2011-08-12 03:54:32 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-12 03:54:32 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-12 03:54:32 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-12 03:54:32 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-12 03:54:32 --> Final output sent to browser
DEBUG - 2011-08-12 03:54:32 --> Total execution time: 0.5461
DEBUG - 2011-08-12 03:54:34 --> Config Class Initialized
DEBUG - 2011-08-12 03:54:34 --> Hooks Class Initialized
DEBUG - 2011-08-12 03:54:34 --> Utf8 Class Initialized
DEBUG - 2011-08-12 03:54:34 --> UTF-8 Support Enabled
DEBUG - 2011-08-12 03:54:34 --> URI Class Initialized
DEBUG - 2011-08-12 03:54:34 --> Router Class Initialized
DEBUG - 2011-08-12 03:54:34 --> Output Class Initialized
DEBUG - 2011-08-12 03:54:34 --> Input Class Initialized
DEBUG - 2011-08-12 03:54:34 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-12 03:54:34 --> Language Class Initialized
DEBUG - 2011-08-12 03:54:34 --> Loader Class Initialized
DEBUG - 2011-08-12 03:54:34 --> Controller Class Initialized
DEBUG - 2011-08-12 03:54:34 --> Model Class Initialized
DEBUG - 2011-08-12 03:54:34 --> Model Class Initialized
DEBUG - 2011-08-12 03:54:34 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-12 03:54:34 --> Database Driver Class Initialized
DEBUG - 2011-08-12 03:54:36 --> Final output sent to browser
DEBUG - 2011-08-12 03:54:36 --> Total execution time: 2.4551
DEBUG - 2011-08-12 03:54:38 --> Config Class Initialized
DEBUG - 2011-08-12 03:54:38 --> Hooks Class Initialized
DEBUG - 2011-08-12 03:54:38 --> Utf8 Class Initialized
DEBUG - 2011-08-12 03:54:38 --> UTF-8 Support Enabled
DEBUG - 2011-08-12 03:54:38 --> URI Class Initialized
DEBUG - 2011-08-12 03:54:38 --> Router Class Initialized
ERROR - 2011-08-12 03:54:38 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-08-12 03:56:58 --> Config Class Initialized
DEBUG - 2011-08-12 03:56:58 --> Hooks Class Initialized
DEBUG - 2011-08-12 03:56:58 --> Utf8 Class Initialized
DEBUG - 2011-08-12 03:56:58 --> UTF-8 Support Enabled
DEBUG - 2011-08-12 03:56:58 --> URI Class Initialized
DEBUG - 2011-08-12 03:56:58 --> Router Class Initialized
DEBUG - 2011-08-12 03:56:58 --> Output Class Initialized
DEBUG - 2011-08-12 03:56:58 --> Input Class Initialized
DEBUG - 2011-08-12 03:56:58 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-12 03:56:58 --> Language Class Initialized
DEBUG - 2011-08-12 03:56:58 --> Loader Class Initialized
DEBUG - 2011-08-12 03:56:58 --> Controller Class Initialized
ERROR - 2011-08-12 03:56:58 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-08-12 03:56:58 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-08-12 03:56:58 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-08-12 03:56:58 --> Model Class Initialized
DEBUG - 2011-08-12 03:56:58 --> Model Class Initialized
DEBUG - 2011-08-12 03:56:58 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-12 03:56:58 --> Database Driver Class Initialized
DEBUG - 2011-08-12 03:56:58 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-08-12 03:56:58 --> Helper loaded: url_helper
DEBUG - 2011-08-12 03:56:58 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-12 03:56:58 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-12 03:56:58 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-12 03:56:58 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-12 03:56:58 --> Final output sent to browser
DEBUG - 2011-08-12 03:56:58 --> Total execution time: 0.0480
DEBUG - 2011-08-12 03:57:07 --> Config Class Initialized
DEBUG - 2011-08-12 03:57:07 --> Hooks Class Initialized
DEBUG - 2011-08-12 03:57:07 --> Utf8 Class Initialized
DEBUG - 2011-08-12 03:57:07 --> UTF-8 Support Enabled
DEBUG - 2011-08-12 03:57:07 --> URI Class Initialized
DEBUG - 2011-08-12 03:57:07 --> Router Class Initialized
DEBUG - 2011-08-12 03:57:07 --> Output Class Initialized
DEBUG - 2011-08-12 03:57:07 --> Input Class Initialized
DEBUG - 2011-08-12 03:57:07 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-12 03:57:07 --> Language Class Initialized
DEBUG - 2011-08-12 03:57:07 --> Loader Class Initialized
DEBUG - 2011-08-12 03:57:07 --> Controller Class Initialized
ERROR - 2011-08-12 03:57:07 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-08-12 03:57:07 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-08-12 03:57:07 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-08-12 03:57:07 --> Model Class Initialized
DEBUG - 2011-08-12 03:57:07 --> Model Class Initialized
DEBUG - 2011-08-12 03:57:07 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-12 03:57:07 --> Database Driver Class Initialized
DEBUG - 2011-08-12 03:57:07 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-08-12 03:57:07 --> Helper loaded: url_helper
DEBUG - 2011-08-12 03:57:07 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-12 03:57:07 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-12 03:57:07 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-12 03:57:07 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-12 03:57:07 --> Final output sent to browser
DEBUG - 2011-08-12 03:57:07 --> Total execution time: 0.0562
DEBUG - 2011-08-12 03:57:08 --> Config Class Initialized
DEBUG - 2011-08-12 03:57:08 --> Hooks Class Initialized
DEBUG - 2011-08-12 03:57:08 --> Utf8 Class Initialized
DEBUG - 2011-08-12 03:57:08 --> UTF-8 Support Enabled
DEBUG - 2011-08-12 03:57:08 --> URI Class Initialized
DEBUG - 2011-08-12 03:57:08 --> Router Class Initialized
DEBUG - 2011-08-12 03:57:08 --> Output Class Initialized
DEBUG - 2011-08-12 03:57:08 --> Input Class Initialized
DEBUG - 2011-08-12 03:57:08 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-12 03:57:08 --> Language Class Initialized
DEBUG - 2011-08-12 03:57:08 --> Loader Class Initialized
DEBUG - 2011-08-12 03:57:08 --> Controller Class Initialized
DEBUG - 2011-08-12 03:57:08 --> Model Class Initialized
DEBUG - 2011-08-12 03:57:08 --> Model Class Initialized
DEBUG - 2011-08-12 03:57:08 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-12 03:57:08 --> Database Driver Class Initialized
DEBUG - 2011-08-12 03:57:09 --> Final output sent to browser
DEBUG - 2011-08-12 03:57:09 --> Total execution time: 0.5725
DEBUG - 2011-08-12 03:57:18 --> Config Class Initialized
DEBUG - 2011-08-12 03:57:18 --> Hooks Class Initialized
DEBUG - 2011-08-12 03:57:18 --> Utf8 Class Initialized
DEBUG - 2011-08-12 03:57:18 --> UTF-8 Support Enabled
DEBUG - 2011-08-12 03:57:18 --> URI Class Initialized
DEBUG - 2011-08-12 03:57:18 --> Router Class Initialized
ERROR - 2011-08-12 03:57:18 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-08-12 03:57:18 --> Config Class Initialized
DEBUG - 2011-08-12 03:57:18 --> Hooks Class Initialized
DEBUG - 2011-08-12 03:57:18 --> Utf8 Class Initialized
DEBUG - 2011-08-12 03:57:18 --> UTF-8 Support Enabled
DEBUG - 2011-08-12 03:57:18 --> URI Class Initialized
DEBUG - 2011-08-12 03:57:18 --> Router Class Initialized
ERROR - 2011-08-12 03:57:18 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-08-12 03:57:18 --> Config Class Initialized
DEBUG - 2011-08-12 03:57:18 --> Hooks Class Initialized
DEBUG - 2011-08-12 03:57:18 --> Utf8 Class Initialized
DEBUG - 2011-08-12 03:57:18 --> UTF-8 Support Enabled
DEBUG - 2011-08-12 03:57:18 --> URI Class Initialized
DEBUG - 2011-08-12 03:57:18 --> Router Class Initialized
ERROR - 2011-08-12 03:57:18 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-08-12 03:57:46 --> Config Class Initialized
DEBUG - 2011-08-12 03:57:46 --> Hooks Class Initialized
DEBUG - 2011-08-12 03:57:46 --> Utf8 Class Initialized
DEBUG - 2011-08-12 03:57:46 --> UTF-8 Support Enabled
DEBUG - 2011-08-12 03:57:46 --> URI Class Initialized
DEBUG - 2011-08-12 03:57:46 --> Router Class Initialized
DEBUG - 2011-08-12 03:57:46 --> Output Class Initialized
DEBUG - 2011-08-12 03:57:46 --> Input Class Initialized
DEBUG - 2011-08-12 03:57:46 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-12 03:57:46 --> Language Class Initialized
DEBUG - 2011-08-12 03:57:46 --> Loader Class Initialized
DEBUG - 2011-08-12 03:57:46 --> Controller Class Initialized
ERROR - 2011-08-12 03:57:46 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-08-12 03:57:46 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-08-12 03:57:46 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-08-12 03:57:46 --> Model Class Initialized
DEBUG - 2011-08-12 03:57:46 --> Model Class Initialized
DEBUG - 2011-08-12 03:57:46 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-12 03:57:46 --> Database Driver Class Initialized
DEBUG - 2011-08-12 03:57:46 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-08-12 03:57:46 --> Helper loaded: url_helper
DEBUG - 2011-08-12 03:57:46 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-12 03:57:46 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-12 03:57:46 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-12 03:57:46 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-12 03:57:46 --> Final output sent to browser
DEBUG - 2011-08-12 03:57:46 --> Total execution time: 0.0289
DEBUG - 2011-08-12 03:57:48 --> Config Class Initialized
DEBUG - 2011-08-12 03:57:48 --> Hooks Class Initialized
DEBUG - 2011-08-12 03:57:48 --> Utf8 Class Initialized
DEBUG - 2011-08-12 03:57:48 --> UTF-8 Support Enabled
DEBUG - 2011-08-12 03:57:48 --> URI Class Initialized
DEBUG - 2011-08-12 03:57:48 --> Router Class Initialized
DEBUG - 2011-08-12 03:57:48 --> Output Class Initialized
DEBUG - 2011-08-12 03:57:48 --> Input Class Initialized
DEBUG - 2011-08-12 03:57:48 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-12 03:57:48 --> Language Class Initialized
DEBUG - 2011-08-12 03:57:48 --> Loader Class Initialized
DEBUG - 2011-08-12 03:57:48 --> Controller Class Initialized
DEBUG - 2011-08-12 03:57:48 --> Model Class Initialized
DEBUG - 2011-08-12 03:57:48 --> Model Class Initialized
DEBUG - 2011-08-12 03:57:48 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-12 03:57:48 --> Database Driver Class Initialized
DEBUG - 2011-08-12 03:57:48 --> Config Class Initialized
DEBUG - 2011-08-12 03:57:48 --> Hooks Class Initialized
DEBUG - 2011-08-12 03:57:48 --> Utf8 Class Initialized
DEBUG - 2011-08-12 03:57:48 --> UTF-8 Support Enabled
DEBUG - 2011-08-12 03:57:48 --> URI Class Initialized
DEBUG - 2011-08-12 03:57:48 --> Router Class Initialized
DEBUG - 2011-08-12 03:57:48 --> Output Class Initialized
DEBUG - 2011-08-12 03:57:48 --> Input Class Initialized
DEBUG - 2011-08-12 03:57:48 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-12 03:57:48 --> Language Class Initialized
DEBUG - 2011-08-12 03:57:48 --> Loader Class Initialized
DEBUG - 2011-08-12 03:57:48 --> Controller Class Initialized
ERROR - 2011-08-12 03:57:48 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-08-12 03:57:48 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-08-12 03:57:48 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-08-12 03:57:48 --> Model Class Initialized
DEBUG - 2011-08-12 03:57:48 --> Model Class Initialized
DEBUG - 2011-08-12 03:57:48 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-12 03:57:48 --> Database Driver Class Initialized
DEBUG - 2011-08-12 03:57:48 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-08-12 03:57:48 --> Helper loaded: url_helper
DEBUG - 2011-08-12 03:57:48 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-12 03:57:48 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-12 03:57:48 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-12 03:57:48 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-12 03:57:48 --> Final output sent to browser
DEBUG - 2011-08-12 03:57:48 --> Total execution time: 0.0289
DEBUG - 2011-08-12 03:57:48 --> Final output sent to browser
DEBUG - 2011-08-12 03:57:48 --> Total execution time: 0.7915
DEBUG - 2011-08-12 04:31:13 --> Config Class Initialized
DEBUG - 2011-08-12 04:31:13 --> Hooks Class Initialized
DEBUG - 2011-08-12 04:31:13 --> Utf8 Class Initialized
DEBUG - 2011-08-12 04:31:13 --> UTF-8 Support Enabled
DEBUG - 2011-08-12 04:31:13 --> URI Class Initialized
DEBUG - 2011-08-12 04:31:13 --> Router Class Initialized
DEBUG - 2011-08-12 04:31:13 --> Output Class Initialized
DEBUG - 2011-08-12 04:31:13 --> Input Class Initialized
DEBUG - 2011-08-12 04:31:13 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-12 04:31:13 --> Language Class Initialized
DEBUG - 2011-08-12 04:31:13 --> Loader Class Initialized
DEBUG - 2011-08-12 04:31:13 --> Controller Class Initialized
DEBUG - 2011-08-12 04:31:13 --> Model Class Initialized
DEBUG - 2011-08-12 04:31:13 --> Model Class Initialized
DEBUG - 2011-08-12 04:31:13 --> Model Class Initialized
DEBUG - 2011-08-12 04:31:13 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-12 04:31:13 --> Database Driver Class Initialized
DEBUG - 2011-08-12 04:31:14 --> File loaded: application/views/table/main.php
DEBUG - 2011-08-12 04:31:14 --> Helper loaded: url_helper
DEBUG - 2011-08-12 04:31:14 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-12 04:31:14 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-12 04:31:14 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-12 04:31:14 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-12 04:31:14 --> Final output sent to browser
DEBUG - 2011-08-12 04:31:14 --> Total execution time: 1.3615
DEBUG - 2011-08-12 04:31:16 --> Config Class Initialized
DEBUG - 2011-08-12 04:31:16 --> Hooks Class Initialized
DEBUG - 2011-08-12 04:31:16 --> Utf8 Class Initialized
DEBUG - 2011-08-12 04:31:16 --> UTF-8 Support Enabled
DEBUG - 2011-08-12 04:31:16 --> URI Class Initialized
DEBUG - 2011-08-12 04:31:16 --> Router Class Initialized
ERROR - 2011-08-12 04:31:16 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-08-12 05:27:49 --> Config Class Initialized
DEBUG - 2011-08-12 05:27:49 --> Hooks Class Initialized
DEBUG - 2011-08-12 05:27:49 --> Utf8 Class Initialized
DEBUG - 2011-08-12 05:27:49 --> UTF-8 Support Enabled
DEBUG - 2011-08-12 05:27:49 --> URI Class Initialized
DEBUG - 2011-08-12 05:27:50 --> Router Class Initialized
DEBUG - 2011-08-12 05:27:50 --> Output Class Initialized
DEBUG - 2011-08-12 05:27:50 --> Input Class Initialized
DEBUG - 2011-08-12 05:27:50 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-12 05:27:50 --> Language Class Initialized
DEBUG - 2011-08-12 05:27:50 --> Loader Class Initialized
DEBUG - 2011-08-12 05:27:50 --> Controller Class Initialized
ERROR - 2011-08-12 05:27:50 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-08-12 05:27:50 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-08-12 05:27:50 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-08-12 05:27:50 --> Model Class Initialized
DEBUG - 2011-08-12 05:27:50 --> Model Class Initialized
DEBUG - 2011-08-12 05:27:50 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-12 05:27:50 --> Database Driver Class Initialized
DEBUG - 2011-08-12 05:27:50 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-08-12 05:27:50 --> Helper loaded: url_helper
DEBUG - 2011-08-12 05:27:50 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-12 05:27:50 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-12 05:27:50 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-12 05:27:50 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-12 05:27:50 --> Final output sent to browser
DEBUG - 2011-08-12 05:27:50 --> Total execution time: 0.2764
DEBUG - 2011-08-12 05:27:50 --> Config Class Initialized
DEBUG - 2011-08-12 05:27:50 --> Hooks Class Initialized
DEBUG - 2011-08-12 05:27:50 --> Utf8 Class Initialized
DEBUG - 2011-08-12 05:27:50 --> UTF-8 Support Enabled
DEBUG - 2011-08-12 05:27:50 --> URI Class Initialized
DEBUG - 2011-08-12 05:27:50 --> Router Class Initialized
DEBUG - 2011-08-12 05:27:50 --> Output Class Initialized
DEBUG - 2011-08-12 05:27:50 --> Input Class Initialized
DEBUG - 2011-08-12 05:27:50 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-12 05:27:50 --> Language Class Initialized
DEBUG - 2011-08-12 05:27:50 --> Loader Class Initialized
DEBUG - 2011-08-12 05:27:50 --> Controller Class Initialized
DEBUG - 2011-08-12 05:27:50 --> Model Class Initialized
DEBUG - 2011-08-12 05:27:50 --> Model Class Initialized
DEBUG - 2011-08-12 05:27:50 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-12 05:27:50 --> Database Driver Class Initialized
DEBUG - 2011-08-12 05:27:51 --> Final output sent to browser
DEBUG - 2011-08-12 05:27:51 --> Total execution time: 0.5527
DEBUG - 2011-08-12 07:02:55 --> Config Class Initialized
DEBUG - 2011-08-12 07:02:55 --> Hooks Class Initialized
DEBUG - 2011-08-12 07:02:55 --> Utf8 Class Initialized
DEBUG - 2011-08-12 07:02:55 --> UTF-8 Support Enabled
DEBUG - 2011-08-12 07:02:55 --> URI Class Initialized
DEBUG - 2011-08-12 07:02:55 --> Router Class Initialized
DEBUG - 2011-08-12 07:02:55 --> No URI present. Default controller set.
DEBUG - 2011-08-12 07:02:55 --> Output Class Initialized
DEBUG - 2011-08-12 07:02:55 --> Input Class Initialized
DEBUG - 2011-08-12 07:02:55 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-12 07:02:55 --> Language Class Initialized
DEBUG - 2011-08-12 07:02:55 --> Loader Class Initialized
DEBUG - 2011-08-12 07:02:55 --> Controller Class Initialized
DEBUG - 2011-08-12 07:02:55 --> File loaded: application/views/splash/main.php
DEBUG - 2011-08-12 07:02:56 --> Helper loaded: url_helper
DEBUG - 2011-08-12 07:02:56 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-12 07:02:56 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-12 07:02:56 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-12 07:02:56 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-12 07:02:56 --> Final output sent to browser
DEBUG - 2011-08-12 07:02:56 --> Total execution time: 0.3234
DEBUG - 2011-08-12 07:29:54 --> Config Class Initialized
DEBUG - 2011-08-12 07:29:54 --> Hooks Class Initialized
DEBUG - 2011-08-12 07:29:54 --> Utf8 Class Initialized
DEBUG - 2011-08-12 07:29:54 --> UTF-8 Support Enabled
DEBUG - 2011-08-12 07:29:54 --> URI Class Initialized
DEBUG - 2011-08-12 07:29:54 --> Router Class Initialized
DEBUG - 2011-08-12 07:29:54 --> Output Class Initialized
DEBUG - 2011-08-12 07:29:54 --> Input Class Initialized
DEBUG - 2011-08-12 07:29:54 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-12 07:29:54 --> Language Class Initialized
DEBUG - 2011-08-12 07:29:54 --> Loader Class Initialized
DEBUG - 2011-08-12 07:29:54 --> Controller Class Initialized
DEBUG - 2011-08-12 07:29:54 --> Model Class Initialized
DEBUG - 2011-08-12 07:29:54 --> Model Class Initialized
DEBUG - 2011-08-12 07:29:54 --> Model Class Initialized
DEBUG - 2011-08-12 07:29:54 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-12 07:29:54 --> Database Driver Class Initialized
DEBUG - 2011-08-12 07:29:55 --> File loaded: application/views/table/main.php
DEBUG - 2011-08-12 07:29:55 --> Helper loaded: url_helper
DEBUG - 2011-08-12 07:29:55 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-12 07:29:55 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-12 07:29:55 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-12 07:29:55 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-12 07:29:55 --> Final output sent to browser
DEBUG - 2011-08-12 07:29:55 --> Total execution time: 0.5168
DEBUG - 2011-08-12 07:30:02 --> Config Class Initialized
DEBUG - 2011-08-12 07:30:02 --> Hooks Class Initialized
DEBUG - 2011-08-12 07:30:02 --> Utf8 Class Initialized
DEBUG - 2011-08-12 07:30:02 --> UTF-8 Support Enabled
DEBUG - 2011-08-12 07:30:02 --> URI Class Initialized
DEBUG - 2011-08-12 07:30:02 --> Router Class Initialized
DEBUG - 2011-08-12 07:30:02 --> Output Class Initialized
DEBUG - 2011-08-12 07:30:02 --> Input Class Initialized
DEBUG - 2011-08-12 07:30:02 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-12 07:30:02 --> Language Class Initialized
DEBUG - 2011-08-12 07:30:02 --> Loader Class Initialized
DEBUG - 2011-08-12 07:30:02 --> Controller Class Initialized
ERROR - 2011-08-12 07:30:02 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-08-12 07:30:02 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-08-12 07:30:02 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-08-12 07:30:02 --> Model Class Initialized
DEBUG - 2011-08-12 07:30:02 --> Model Class Initialized
DEBUG - 2011-08-12 07:30:02 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-12 07:30:02 --> Database Driver Class Initialized
DEBUG - 2011-08-12 07:30:02 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-08-12 07:30:02 --> Helper loaded: url_helper
DEBUG - 2011-08-12 07:30:02 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-12 07:30:02 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-12 07:30:02 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-12 07:30:02 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-12 07:30:02 --> Final output sent to browser
DEBUG - 2011-08-12 07:30:02 --> Total execution time: 0.4238
DEBUG - 2011-08-12 07:30:04 --> Config Class Initialized
DEBUG - 2011-08-12 07:30:04 --> Hooks Class Initialized
DEBUG - 2011-08-12 07:30:04 --> Utf8 Class Initialized
DEBUG - 2011-08-12 07:30:04 --> UTF-8 Support Enabled
DEBUG - 2011-08-12 07:30:04 --> URI Class Initialized
DEBUG - 2011-08-12 07:30:04 --> Router Class Initialized
DEBUG - 2011-08-12 07:30:04 --> Output Class Initialized
DEBUG - 2011-08-12 07:30:04 --> Input Class Initialized
DEBUG - 2011-08-12 07:30:04 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-12 07:30:04 --> Language Class Initialized
DEBUG - 2011-08-12 07:30:04 --> Loader Class Initialized
DEBUG - 2011-08-12 07:30:04 --> Controller Class Initialized
DEBUG - 2011-08-12 07:30:04 --> Model Class Initialized
DEBUG - 2011-08-12 07:30:04 --> Model Class Initialized
DEBUG - 2011-08-12 07:30:04 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-12 07:30:04 --> Database Driver Class Initialized
DEBUG - 2011-08-12 07:30:05 --> Final output sent to browser
DEBUG - 2011-08-12 07:30:05 --> Total execution time: 1.2729
DEBUG - 2011-08-12 07:30:18 --> Config Class Initialized
DEBUG - 2011-08-12 07:30:18 --> Hooks Class Initialized
DEBUG - 2011-08-12 07:30:18 --> Utf8 Class Initialized
DEBUG - 2011-08-12 07:30:18 --> UTF-8 Support Enabled
DEBUG - 2011-08-12 07:30:18 --> URI Class Initialized
DEBUG - 2011-08-12 07:30:18 --> Router Class Initialized
DEBUG - 2011-08-12 07:30:18 --> Output Class Initialized
DEBUG - 2011-08-12 07:30:18 --> Input Class Initialized
DEBUG - 2011-08-12 07:30:18 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-12 07:30:18 --> Language Class Initialized
DEBUG - 2011-08-12 07:30:18 --> Loader Class Initialized
DEBUG - 2011-08-12 07:30:18 --> Controller Class Initialized
ERROR - 2011-08-12 07:30:18 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-08-12 07:30:18 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-08-12 07:30:18 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-08-12 07:30:18 --> Model Class Initialized
DEBUG - 2011-08-12 07:30:18 --> Model Class Initialized
DEBUG - 2011-08-12 07:30:18 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-12 07:30:18 --> Database Driver Class Initialized
DEBUG - 2011-08-12 07:30:18 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-08-12 07:30:18 --> Helper loaded: url_helper
DEBUG - 2011-08-12 07:30:18 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-12 07:30:18 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-12 07:30:18 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-12 07:30:18 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-12 07:30:18 --> Final output sent to browser
DEBUG - 2011-08-12 07:30:18 --> Total execution time: 0.0329
DEBUG - 2011-08-12 07:30:19 --> Config Class Initialized
DEBUG - 2011-08-12 07:30:19 --> Hooks Class Initialized
DEBUG - 2011-08-12 07:30:19 --> Utf8 Class Initialized
DEBUG - 2011-08-12 07:30:19 --> UTF-8 Support Enabled
DEBUG - 2011-08-12 07:30:19 --> URI Class Initialized
DEBUG - 2011-08-12 07:30:19 --> Router Class Initialized
DEBUG - 2011-08-12 07:30:19 --> Output Class Initialized
DEBUG - 2011-08-12 07:30:19 --> Input Class Initialized
DEBUG - 2011-08-12 07:30:19 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-12 07:30:19 --> Language Class Initialized
DEBUG - 2011-08-12 07:30:19 --> Loader Class Initialized
DEBUG - 2011-08-12 07:30:19 --> Controller Class Initialized
DEBUG - 2011-08-12 07:30:19 --> Model Class Initialized
DEBUG - 2011-08-12 07:30:19 --> Model Class Initialized
DEBUG - 2011-08-12 07:30:19 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-12 07:30:19 --> Database Driver Class Initialized
DEBUG - 2011-08-12 07:30:19 --> Final output sent to browser
DEBUG - 2011-08-12 07:30:19 --> Total execution time: 0.6995
DEBUG - 2011-08-12 07:30:20 --> Config Class Initialized
DEBUG - 2011-08-12 07:30:20 --> Hooks Class Initialized
DEBUG - 2011-08-12 07:30:20 --> Utf8 Class Initialized
DEBUG - 2011-08-12 07:30:20 --> UTF-8 Support Enabled
DEBUG - 2011-08-12 07:30:20 --> URI Class Initialized
DEBUG - 2011-08-12 07:30:20 --> Router Class Initialized
ERROR - 2011-08-12 07:30:20 --> 404 Page Not Found --> robots.txt
DEBUG - 2011-08-12 07:30:20 --> Config Class Initialized
DEBUG - 2011-08-12 07:30:20 --> Hooks Class Initialized
DEBUG - 2011-08-12 07:30:20 --> Utf8 Class Initialized
DEBUG - 2011-08-12 07:30:20 --> UTF-8 Support Enabled
DEBUG - 2011-08-12 07:30:20 --> URI Class Initialized
DEBUG - 2011-08-12 07:30:20 --> Router Class Initialized
DEBUG - 2011-08-12 07:30:20 --> Output Class Initialized
DEBUG - 2011-08-12 07:30:20 --> Input Class Initialized
DEBUG - 2011-08-12 07:30:20 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-12 07:30:20 --> Language Class Initialized
DEBUG - 2011-08-12 07:30:20 --> Loader Class Initialized
DEBUG - 2011-08-12 07:30:20 --> Controller Class Initialized
ERROR - 2011-08-12 07:30:20 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-08-12 07:30:20 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-08-12 07:30:20 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-08-12 07:30:20 --> Model Class Initialized
DEBUG - 2011-08-12 07:30:20 --> Model Class Initialized
DEBUG - 2011-08-12 07:30:20 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-12 07:30:20 --> Database Driver Class Initialized
DEBUG - 2011-08-12 07:30:20 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-08-12 07:30:20 --> Helper loaded: url_helper
DEBUG - 2011-08-12 07:30:20 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-12 07:30:20 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-12 07:30:20 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-12 07:30:20 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-12 07:30:20 --> Final output sent to browser
DEBUG - 2011-08-12 07:30:20 --> Total execution time: 0.0291
DEBUG - 2011-08-12 07:37:26 --> Config Class Initialized
DEBUG - 2011-08-12 07:37:26 --> Hooks Class Initialized
DEBUG - 2011-08-12 07:37:26 --> Utf8 Class Initialized
DEBUG - 2011-08-12 07:37:26 --> UTF-8 Support Enabled
DEBUG - 2011-08-12 07:37:26 --> URI Class Initialized
DEBUG - 2011-08-12 07:37:26 --> Router Class Initialized
DEBUG - 2011-08-12 07:37:26 --> Output Class Initialized
DEBUG - 2011-08-12 07:37:26 --> Input Class Initialized
DEBUG - 2011-08-12 07:37:26 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-12 07:37:26 --> Language Class Initialized
DEBUG - 2011-08-12 07:37:26 --> Loader Class Initialized
DEBUG - 2011-08-12 07:37:26 --> Controller Class Initialized
ERROR - 2011-08-12 07:37:26 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-08-12 07:37:26 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-08-12 07:37:26 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-08-12 07:37:26 --> Model Class Initialized
DEBUG - 2011-08-12 07:37:26 --> Model Class Initialized
DEBUG - 2011-08-12 07:37:26 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-12 07:37:26 --> Database Driver Class Initialized
DEBUG - 2011-08-12 07:37:26 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-08-12 07:37:26 --> Helper loaded: url_helper
DEBUG - 2011-08-12 07:37:26 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-12 07:37:26 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-12 07:37:26 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-12 07:37:26 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-12 07:37:26 --> Final output sent to browser
DEBUG - 2011-08-12 07:37:26 --> Total execution time: 0.0398
DEBUG - 2011-08-12 07:37:30 --> Config Class Initialized
DEBUG - 2011-08-12 07:37:30 --> Hooks Class Initialized
DEBUG - 2011-08-12 07:37:30 --> Utf8 Class Initialized
DEBUG - 2011-08-12 07:37:30 --> UTF-8 Support Enabled
DEBUG - 2011-08-12 07:37:30 --> URI Class Initialized
DEBUG - 2011-08-12 07:37:30 --> Router Class Initialized
DEBUG - 2011-08-12 07:37:30 --> Output Class Initialized
DEBUG - 2011-08-12 07:37:30 --> Input Class Initialized
DEBUG - 2011-08-12 07:37:30 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-12 07:37:30 --> Language Class Initialized
DEBUG - 2011-08-12 07:37:30 --> Loader Class Initialized
DEBUG - 2011-08-12 07:37:30 --> Controller Class Initialized
DEBUG - 2011-08-12 07:37:30 --> Model Class Initialized
DEBUG - 2011-08-12 07:37:30 --> Model Class Initialized
DEBUG - 2011-08-12 07:37:30 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-12 07:37:30 --> Database Driver Class Initialized
DEBUG - 2011-08-12 07:37:30 --> Final output sent to browser
DEBUG - 2011-08-12 07:37:30 --> Total execution time: 0.5469
DEBUG - 2011-08-12 07:39:05 --> Config Class Initialized
DEBUG - 2011-08-12 07:39:05 --> Hooks Class Initialized
DEBUG - 2011-08-12 07:39:05 --> Utf8 Class Initialized
DEBUG - 2011-08-12 07:39:05 --> UTF-8 Support Enabled
DEBUG - 2011-08-12 07:39:05 --> URI Class Initialized
DEBUG - 2011-08-12 07:39:05 --> Router Class Initialized
DEBUG - 2011-08-12 07:39:05 --> Output Class Initialized
DEBUG - 2011-08-12 07:39:05 --> Input Class Initialized
DEBUG - 2011-08-12 07:39:05 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-12 07:39:05 --> Language Class Initialized
DEBUG - 2011-08-12 07:39:05 --> Loader Class Initialized
DEBUG - 2011-08-12 07:39:05 --> Controller Class Initialized
ERROR - 2011-08-12 07:39:05 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-08-12 07:39:05 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-08-12 07:39:05 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-08-12 07:39:05 --> Model Class Initialized
DEBUG - 2011-08-12 07:39:05 --> Model Class Initialized
DEBUG - 2011-08-12 07:39:05 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-12 07:39:05 --> Database Driver Class Initialized
DEBUG - 2011-08-12 07:39:05 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-08-12 07:39:05 --> Helper loaded: url_helper
DEBUG - 2011-08-12 07:39:05 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-12 07:39:05 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-12 07:39:05 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-12 07:39:05 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-12 07:39:05 --> Final output sent to browser
DEBUG - 2011-08-12 07:39:05 --> Total execution time: 0.0311
DEBUG - 2011-08-12 07:39:09 --> Config Class Initialized
DEBUG - 2011-08-12 07:39:09 --> Hooks Class Initialized
DEBUG - 2011-08-12 07:39:09 --> Utf8 Class Initialized
DEBUG - 2011-08-12 07:39:09 --> UTF-8 Support Enabled
DEBUG - 2011-08-12 07:39:09 --> URI Class Initialized
DEBUG - 2011-08-12 07:39:09 --> Router Class Initialized
DEBUG - 2011-08-12 07:39:09 --> Output Class Initialized
DEBUG - 2011-08-12 07:39:09 --> Input Class Initialized
DEBUG - 2011-08-12 07:39:09 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-12 07:39:09 --> Language Class Initialized
DEBUG - 2011-08-12 07:39:09 --> Loader Class Initialized
DEBUG - 2011-08-12 07:39:09 --> Controller Class Initialized
DEBUG - 2011-08-12 07:39:09 --> Model Class Initialized
DEBUG - 2011-08-12 07:39:09 --> Model Class Initialized
DEBUG - 2011-08-12 07:39:09 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-12 07:39:09 --> Database Driver Class Initialized
DEBUG - 2011-08-12 07:39:09 --> Final output sent to browser
DEBUG - 2011-08-12 07:39:09 --> Total execution time: 0.5288
DEBUG - 2011-08-12 07:39:22 --> Config Class Initialized
DEBUG - 2011-08-12 07:39:22 --> Hooks Class Initialized
DEBUG - 2011-08-12 07:39:22 --> Utf8 Class Initialized
DEBUG - 2011-08-12 07:39:22 --> UTF-8 Support Enabled
DEBUG - 2011-08-12 07:39:22 --> URI Class Initialized
DEBUG - 2011-08-12 07:39:22 --> Router Class Initialized
DEBUG - 2011-08-12 07:39:22 --> Output Class Initialized
DEBUG - 2011-08-12 07:39:22 --> Input Class Initialized
DEBUG - 2011-08-12 07:39:22 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-12 07:39:22 --> Language Class Initialized
DEBUG - 2011-08-12 07:39:22 --> Loader Class Initialized
DEBUG - 2011-08-12 07:39:22 --> Controller Class Initialized
ERROR - 2011-08-12 07:39:22 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-08-12 07:39:22 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-08-12 07:39:22 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-08-12 07:39:22 --> Model Class Initialized
DEBUG - 2011-08-12 07:39:22 --> Model Class Initialized
DEBUG - 2011-08-12 07:39:22 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-12 07:39:22 --> Database Driver Class Initialized
DEBUG - 2011-08-12 07:39:22 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-08-12 07:39:22 --> Helper loaded: url_helper
DEBUG - 2011-08-12 07:39:22 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-12 07:39:22 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-12 07:39:22 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-12 07:39:22 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-12 07:39:22 --> Final output sent to browser
DEBUG - 2011-08-12 07:39:22 --> Total execution time: 0.0287
DEBUG - 2011-08-12 07:39:23 --> Config Class Initialized
DEBUG - 2011-08-12 07:39:23 --> Hooks Class Initialized
DEBUG - 2011-08-12 07:39:23 --> Utf8 Class Initialized
DEBUG - 2011-08-12 07:39:23 --> UTF-8 Support Enabled
DEBUG - 2011-08-12 07:39:23 --> URI Class Initialized
DEBUG - 2011-08-12 07:39:23 --> Router Class Initialized
DEBUG - 2011-08-12 07:39:23 --> Output Class Initialized
DEBUG - 2011-08-12 07:39:23 --> Input Class Initialized
DEBUG - 2011-08-12 07:39:23 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-12 07:39:23 --> Language Class Initialized
DEBUG - 2011-08-12 07:39:23 --> Loader Class Initialized
DEBUG - 2011-08-12 07:39:23 --> Controller Class Initialized
DEBUG - 2011-08-12 07:39:23 --> Model Class Initialized
DEBUG - 2011-08-12 07:39:23 --> Model Class Initialized
DEBUG - 2011-08-12 07:39:23 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-12 07:39:23 --> Database Driver Class Initialized
DEBUG - 2011-08-12 07:39:24 --> Final output sent to browser
DEBUG - 2011-08-12 07:39:24 --> Total execution time: 0.5793
DEBUG - 2011-08-12 07:58:56 --> Config Class Initialized
DEBUG - 2011-08-12 07:58:56 --> Hooks Class Initialized
DEBUG - 2011-08-12 07:58:56 --> Utf8 Class Initialized
DEBUG - 2011-08-12 07:58:56 --> UTF-8 Support Enabled
DEBUG - 2011-08-12 07:58:56 --> URI Class Initialized
DEBUG - 2011-08-12 07:58:56 --> Router Class Initialized
ERROR - 2011-08-12 07:58:56 --> 404 Page Not Found --> robots.txt
DEBUG - 2011-08-12 08:44:29 --> Config Class Initialized
DEBUG - 2011-08-12 08:44:29 --> Hooks Class Initialized
DEBUG - 2011-08-12 08:44:29 --> Utf8 Class Initialized
DEBUG - 2011-08-12 08:44:29 --> UTF-8 Support Enabled
DEBUG - 2011-08-12 08:44:29 --> URI Class Initialized
DEBUG - 2011-08-12 08:44:29 --> Router Class Initialized
DEBUG - 2011-08-12 08:44:29 --> No URI present. Default controller set.
DEBUG - 2011-08-12 08:44:29 --> Output Class Initialized
DEBUG - 2011-08-12 08:44:29 --> Input Class Initialized
DEBUG - 2011-08-12 08:44:29 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-12 08:44:29 --> Language Class Initialized
DEBUG - 2011-08-12 08:44:29 --> Loader Class Initialized
DEBUG - 2011-08-12 08:44:29 --> Controller Class Initialized
DEBUG - 2011-08-12 08:44:29 --> File loaded: application/views/splash/main.php
DEBUG - 2011-08-12 08:44:29 --> Helper loaded: url_helper
DEBUG - 2011-08-12 08:44:29 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-12 08:44:29 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-12 08:44:29 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-12 08:44:29 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-12 08:44:29 --> Final output sent to browser
DEBUG - 2011-08-12 08:44:29 --> Total execution time: 0.2299
DEBUG - 2011-08-12 09:12:06 --> Config Class Initialized
DEBUG - 2011-08-12 09:12:06 --> Hooks Class Initialized
DEBUG - 2011-08-12 09:12:06 --> Utf8 Class Initialized
DEBUG - 2011-08-12 09:12:06 --> UTF-8 Support Enabled
DEBUG - 2011-08-12 09:12:06 --> URI Class Initialized
DEBUG - 2011-08-12 09:12:06 --> Router Class Initialized
DEBUG - 2011-08-12 09:12:06 --> Output Class Initialized
DEBUG - 2011-08-12 09:12:06 --> Input Class Initialized
DEBUG - 2011-08-12 09:12:06 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-12 09:12:06 --> Language Class Initialized
DEBUG - 2011-08-12 09:12:06 --> Loader Class Initialized
DEBUG - 2011-08-12 09:12:06 --> Controller Class Initialized
DEBUG - 2011-08-12 09:12:06 --> Model Class Initialized
DEBUG - 2011-08-12 09:12:06 --> Model Class Initialized
DEBUG - 2011-08-12 09:12:06 --> Model Class Initialized
DEBUG - 2011-08-12 09:12:06 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-12 09:12:06 --> Database Driver Class Initialized
DEBUG - 2011-08-12 09:12:06 --> File loaded: application/views/table/main.php
DEBUG - 2011-08-12 09:12:06 --> Helper loaded: url_helper
DEBUG - 2011-08-12 09:12:06 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-12 09:12:06 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-12 09:12:06 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-12 09:12:06 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-12 09:12:06 --> Final output sent to browser
DEBUG - 2011-08-12 09:12:06 --> Total execution time: 0.7158
DEBUG - 2011-08-12 09:12:15 --> Config Class Initialized
DEBUG - 2011-08-12 09:12:15 --> Hooks Class Initialized
DEBUG - 2011-08-12 09:12:15 --> Utf8 Class Initialized
DEBUG - 2011-08-12 09:12:15 --> UTF-8 Support Enabled
DEBUG - 2011-08-12 09:12:15 --> URI Class Initialized
DEBUG - 2011-08-12 09:12:15 --> Router Class Initialized
ERROR - 2011-08-12 09:12:15 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-08-12 09:12:16 --> Config Class Initialized
DEBUG - 2011-08-12 09:12:16 --> Hooks Class Initialized
DEBUG - 2011-08-12 09:12:16 --> Utf8 Class Initialized
DEBUG - 2011-08-12 09:12:16 --> UTF-8 Support Enabled
DEBUG - 2011-08-12 09:12:16 --> URI Class Initialized
DEBUG - 2011-08-12 09:12:16 --> Router Class Initialized
ERROR - 2011-08-12 09:12:16 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-08-12 09:25:36 --> Config Class Initialized
DEBUG - 2011-08-12 09:25:36 --> Hooks Class Initialized
DEBUG - 2011-08-12 09:25:36 --> Utf8 Class Initialized
DEBUG - 2011-08-12 09:25:36 --> UTF-8 Support Enabled
DEBUG - 2011-08-12 09:25:36 --> URI Class Initialized
DEBUG - 2011-08-12 09:25:36 --> Router Class Initialized
DEBUG - 2011-08-12 09:25:36 --> Output Class Initialized
DEBUG - 2011-08-12 09:25:36 --> Input Class Initialized
DEBUG - 2011-08-12 09:25:36 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-12 09:25:36 --> Language Class Initialized
DEBUG - 2011-08-12 09:25:36 --> Loader Class Initialized
DEBUG - 2011-08-12 09:25:36 --> Controller Class Initialized
DEBUG - 2011-08-12 09:25:36 --> Model Class Initialized
DEBUG - 2011-08-12 09:25:36 --> Model Class Initialized
DEBUG - 2011-08-12 09:25:36 --> Model Class Initialized
DEBUG - 2011-08-12 09:25:36 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-12 09:25:36 --> Database Driver Class Initialized
DEBUG - 2011-08-12 09:25:36 --> File loaded: application/views/table/main.php
DEBUG - 2011-08-12 09:25:37 --> Helper loaded: url_helper
DEBUG - 2011-08-12 09:25:37 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-12 09:25:37 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-12 09:25:37 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-12 09:25:37 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-12 09:25:37 --> Final output sent to browser
DEBUG - 2011-08-12 09:25:37 --> Total execution time: 0.1946
DEBUG - 2011-08-12 09:25:39 --> Config Class Initialized
DEBUG - 2011-08-12 09:25:39 --> Hooks Class Initialized
DEBUG - 2011-08-12 09:25:39 --> Utf8 Class Initialized
DEBUG - 2011-08-12 09:25:39 --> UTF-8 Support Enabled
DEBUG - 2011-08-12 09:25:39 --> URI Class Initialized
DEBUG - 2011-08-12 09:25:39 --> Router Class Initialized
ERROR - 2011-08-12 09:25:39 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-08-12 09:25:40 --> Config Class Initialized
DEBUG - 2011-08-12 09:25:40 --> Hooks Class Initialized
DEBUG - 2011-08-12 09:25:40 --> Utf8 Class Initialized
DEBUG - 2011-08-12 09:25:40 --> UTF-8 Support Enabled
DEBUG - 2011-08-12 09:25:40 --> URI Class Initialized
DEBUG - 2011-08-12 09:25:40 --> Router Class Initialized
ERROR - 2011-08-12 09:25:40 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-08-12 09:25:48 --> Config Class Initialized
DEBUG - 2011-08-12 09:25:48 --> Hooks Class Initialized
DEBUG - 2011-08-12 09:25:48 --> Utf8 Class Initialized
DEBUG - 2011-08-12 09:25:48 --> UTF-8 Support Enabled
DEBUG - 2011-08-12 09:25:48 --> URI Class Initialized
DEBUG - 2011-08-12 09:25:48 --> Router Class Initialized
DEBUG - 2011-08-12 09:25:48 --> Output Class Initialized
DEBUG - 2011-08-12 09:25:48 --> Input Class Initialized
DEBUG - 2011-08-12 09:25:48 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-12 09:25:48 --> Language Class Initialized
DEBUG - 2011-08-12 09:25:48 --> Loader Class Initialized
DEBUG - 2011-08-12 09:25:48 --> Controller Class Initialized
DEBUG - 2011-08-12 09:25:48 --> Model Class Initialized
DEBUG - 2011-08-12 09:25:48 --> Model Class Initialized
DEBUG - 2011-08-12 09:25:48 --> Model Class Initialized
DEBUG - 2011-08-12 09:25:48 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-12 09:25:48 --> Database Driver Class Initialized
DEBUG - 2011-08-12 09:25:49 --> File loaded: application/views/table/main.php
DEBUG - 2011-08-12 09:25:49 --> Helper loaded: url_helper
DEBUG - 2011-08-12 09:25:49 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-12 09:25:49 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-12 09:25:49 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-12 09:25:49 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-12 09:25:49 --> Final output sent to browser
DEBUG - 2011-08-12 09:25:49 --> Total execution time: 1.0204
DEBUG - 2011-08-12 09:25:51 --> Config Class Initialized
DEBUG - 2011-08-12 09:25:51 --> Hooks Class Initialized
DEBUG - 2011-08-12 09:25:51 --> Utf8 Class Initialized
DEBUG - 2011-08-12 09:25:51 --> UTF-8 Support Enabled
DEBUG - 2011-08-12 09:25:51 --> URI Class Initialized
DEBUG - 2011-08-12 09:25:51 --> Router Class Initialized
ERROR - 2011-08-12 09:25:51 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-08-12 09:25:59 --> Config Class Initialized
DEBUG - 2011-08-12 09:25:59 --> Hooks Class Initialized
DEBUG - 2011-08-12 09:25:59 --> Utf8 Class Initialized
DEBUG - 2011-08-12 09:25:59 --> UTF-8 Support Enabled
DEBUG - 2011-08-12 09:25:59 --> URI Class Initialized
DEBUG - 2011-08-12 09:25:59 --> Router Class Initialized
DEBUG - 2011-08-12 09:25:59 --> Output Class Initialized
DEBUG - 2011-08-12 09:25:59 --> Input Class Initialized
DEBUG - 2011-08-12 09:25:59 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-12 09:25:59 --> Language Class Initialized
DEBUG - 2011-08-12 09:25:59 --> Loader Class Initialized
DEBUG - 2011-08-12 09:25:59 --> Controller Class Initialized
DEBUG - 2011-08-12 09:25:59 --> Model Class Initialized
DEBUG - 2011-08-12 09:25:59 --> Model Class Initialized
DEBUG - 2011-08-12 09:25:59 --> Model Class Initialized
DEBUG - 2011-08-12 09:25:59 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-12 09:25:59 --> Database Driver Class Initialized
DEBUG - 2011-08-12 09:25:59 --> File loaded: application/views/table/main.php
DEBUG - 2011-08-12 09:25:59 --> Helper loaded: url_helper
DEBUG - 2011-08-12 09:25:59 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-12 09:25:59 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-12 09:25:59 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-12 09:25:59 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-12 09:25:59 --> Final output sent to browser
DEBUG - 2011-08-12 09:25:59 --> Total execution time: 0.0736
DEBUG - 2011-08-12 09:26:29 --> Config Class Initialized
DEBUG - 2011-08-12 09:26:29 --> Hooks Class Initialized
DEBUG - 2011-08-12 09:26:29 --> Utf8 Class Initialized
DEBUG - 2011-08-12 09:26:29 --> UTF-8 Support Enabled
DEBUG - 2011-08-12 09:26:29 --> URI Class Initialized
DEBUG - 2011-08-12 09:26:29 --> Router Class Initialized
DEBUG - 2011-08-12 09:26:29 --> Output Class Initialized
DEBUG - 2011-08-12 09:26:29 --> Input Class Initialized
DEBUG - 2011-08-12 09:26:29 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-12 09:26:29 --> Language Class Initialized
DEBUG - 2011-08-12 09:26:29 --> Loader Class Initialized
DEBUG - 2011-08-12 09:26:29 --> Controller Class Initialized
DEBUG - 2011-08-12 09:26:29 --> Model Class Initialized
DEBUG - 2011-08-12 09:26:29 --> Model Class Initialized
DEBUG - 2011-08-12 09:26:29 --> Model Class Initialized
DEBUG - 2011-08-12 09:26:29 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-12 09:26:29 --> Database Driver Class Initialized
DEBUG - 2011-08-12 09:26:30 --> File loaded: application/views/table/main.php
DEBUG - 2011-08-12 09:26:30 --> Helper loaded: url_helper
DEBUG - 2011-08-12 09:26:30 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-12 09:26:30 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-12 09:26:30 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-12 09:26:30 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-12 09:26:30 --> Final output sent to browser
DEBUG - 2011-08-12 09:26:30 --> Total execution time: 0.4562
DEBUG - 2011-08-12 09:26:33 --> Config Class Initialized
DEBUG - 2011-08-12 09:26:33 --> Hooks Class Initialized
DEBUG - 2011-08-12 09:26:33 --> Utf8 Class Initialized
DEBUG - 2011-08-12 09:26:33 --> UTF-8 Support Enabled
DEBUG - 2011-08-12 09:26:33 --> URI Class Initialized
DEBUG - 2011-08-12 09:26:33 --> Router Class Initialized
ERROR - 2011-08-12 09:26:33 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-08-12 09:26:58 --> Config Class Initialized
DEBUG - 2011-08-12 09:26:58 --> Hooks Class Initialized
DEBUG - 2011-08-12 09:26:58 --> Utf8 Class Initialized
DEBUG - 2011-08-12 09:26:58 --> UTF-8 Support Enabled
DEBUG - 2011-08-12 09:26:58 --> URI Class Initialized
DEBUG - 2011-08-12 09:26:58 --> Router Class Initialized
DEBUG - 2011-08-12 09:26:58 --> Output Class Initialized
DEBUG - 2011-08-12 09:26:58 --> Input Class Initialized
DEBUG - 2011-08-12 09:26:58 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-12 09:26:58 --> Language Class Initialized
DEBUG - 2011-08-12 09:26:58 --> Loader Class Initialized
DEBUG - 2011-08-12 09:26:58 --> Controller Class Initialized
DEBUG - 2011-08-12 09:26:58 --> Model Class Initialized
DEBUG - 2011-08-12 09:26:58 --> Model Class Initialized
DEBUG - 2011-08-12 09:26:58 --> Model Class Initialized
DEBUG - 2011-08-12 09:26:58 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-12 09:26:58 --> Database Driver Class Initialized
DEBUG - 2011-08-12 09:26:58 --> File loaded: application/views/table/main.php
DEBUG - 2011-08-12 09:26:58 --> Helper loaded: url_helper
DEBUG - 2011-08-12 09:26:58 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-12 09:26:58 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-12 09:26:58 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-12 09:26:58 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-12 09:26:58 --> Final output sent to browser
DEBUG - 2011-08-12 09:26:58 --> Total execution time: 0.0496
DEBUG - 2011-08-12 09:27:07 --> Config Class Initialized
DEBUG - 2011-08-12 09:27:07 --> Hooks Class Initialized
DEBUG - 2011-08-12 09:27:07 --> Utf8 Class Initialized
DEBUG - 2011-08-12 09:27:07 --> UTF-8 Support Enabled
DEBUG - 2011-08-12 09:27:07 --> URI Class Initialized
DEBUG - 2011-08-12 09:27:07 --> Router Class Initialized
DEBUG - 2011-08-12 09:27:07 --> Output Class Initialized
DEBUG - 2011-08-12 09:27:07 --> Input Class Initialized
DEBUG - 2011-08-12 09:27:07 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-12 09:27:07 --> Language Class Initialized
DEBUG - 2011-08-12 09:27:07 --> Loader Class Initialized
DEBUG - 2011-08-12 09:27:07 --> Controller Class Initialized
DEBUG - 2011-08-12 09:27:07 --> Model Class Initialized
DEBUG - 2011-08-12 09:27:07 --> Model Class Initialized
DEBUG - 2011-08-12 09:27:07 --> Model Class Initialized
DEBUG - 2011-08-12 09:27:07 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-12 09:27:07 --> Database Driver Class Initialized
DEBUG - 2011-08-12 09:27:07 --> File loaded: application/views/table/main.php
DEBUG - 2011-08-12 09:27:07 --> Helper loaded: url_helper
DEBUG - 2011-08-12 09:27:07 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-12 09:27:07 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-12 09:27:07 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-12 09:27:07 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-12 09:27:07 --> Final output sent to browser
DEBUG - 2011-08-12 09:27:07 --> Total execution time: 0.7088
DEBUG - 2011-08-12 09:27:10 --> Config Class Initialized
DEBUG - 2011-08-12 09:27:10 --> Hooks Class Initialized
DEBUG - 2011-08-12 09:27:10 --> Utf8 Class Initialized
DEBUG - 2011-08-12 09:27:10 --> UTF-8 Support Enabled
DEBUG - 2011-08-12 09:27:10 --> URI Class Initialized
DEBUG - 2011-08-12 09:27:10 --> Router Class Initialized
DEBUG - 2011-08-12 09:27:10 --> Output Class Initialized
DEBUG - 2011-08-12 09:27:10 --> Input Class Initialized
DEBUG - 2011-08-12 09:27:10 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-12 09:27:10 --> Language Class Initialized
DEBUG - 2011-08-12 09:27:11 --> Loader Class Initialized
DEBUG - 2011-08-12 09:27:11 --> Controller Class Initialized
DEBUG - 2011-08-12 09:27:11 --> Model Class Initialized
DEBUG - 2011-08-12 09:27:11 --> Model Class Initialized
DEBUG - 2011-08-12 09:27:11 --> Model Class Initialized
DEBUG - 2011-08-12 09:27:11 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-12 09:27:11 --> Database Driver Class Initialized
DEBUG - 2011-08-12 09:27:11 --> File loaded: application/views/table/main.php
DEBUG - 2011-08-12 09:27:11 --> Helper loaded: url_helper
DEBUG - 2011-08-12 09:27:11 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-12 09:27:11 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-12 09:27:11 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-12 09:27:11 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-12 09:27:11 --> Final output sent to browser
DEBUG - 2011-08-12 09:27:11 --> Total execution time: 0.0485
DEBUG - 2011-08-12 09:27:11 --> Config Class Initialized
DEBUG - 2011-08-12 09:27:11 --> Hooks Class Initialized
DEBUG - 2011-08-12 09:27:11 --> Utf8 Class Initialized
DEBUG - 2011-08-12 09:27:11 --> UTF-8 Support Enabled
DEBUG - 2011-08-12 09:27:11 --> URI Class Initialized
DEBUG - 2011-08-12 09:27:11 --> Router Class Initialized
ERROR - 2011-08-12 09:27:11 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-08-12 09:27:28 --> Config Class Initialized
DEBUG - 2011-08-12 09:27:28 --> Hooks Class Initialized
DEBUG - 2011-08-12 09:27:28 --> Utf8 Class Initialized
DEBUG - 2011-08-12 09:27:28 --> UTF-8 Support Enabled
DEBUG - 2011-08-12 09:27:28 --> URI Class Initialized
DEBUG - 2011-08-12 09:27:28 --> Router Class Initialized
DEBUG - 2011-08-12 09:27:28 --> Output Class Initialized
DEBUG - 2011-08-12 09:27:28 --> Input Class Initialized
DEBUG - 2011-08-12 09:27:28 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-12 09:27:28 --> Language Class Initialized
DEBUG - 2011-08-12 09:27:28 --> Loader Class Initialized
DEBUG - 2011-08-12 09:27:28 --> Controller Class Initialized
DEBUG - 2011-08-12 09:27:28 --> Model Class Initialized
DEBUG - 2011-08-12 09:27:28 --> Model Class Initialized
DEBUG - 2011-08-12 09:27:28 --> Model Class Initialized
DEBUG - 2011-08-12 09:27:28 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-12 09:27:28 --> Database Driver Class Initialized
DEBUG - 2011-08-12 09:27:29 --> File loaded: application/views/table/main.php
DEBUG - 2011-08-12 09:27:29 --> Helper loaded: url_helper
DEBUG - 2011-08-12 09:27:29 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-12 09:27:29 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-12 09:27:29 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-12 09:27:29 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-12 09:27:29 --> Final output sent to browser
DEBUG - 2011-08-12 09:27:29 --> Total execution time: 1.1365
DEBUG - 2011-08-12 09:27:31 --> Config Class Initialized
DEBUG - 2011-08-12 09:27:31 --> Hooks Class Initialized
DEBUG - 2011-08-12 09:27:31 --> Utf8 Class Initialized
DEBUG - 2011-08-12 09:27:31 --> UTF-8 Support Enabled
DEBUG - 2011-08-12 09:27:31 --> URI Class Initialized
DEBUG - 2011-08-12 09:27:31 --> Router Class Initialized
DEBUG - 2011-08-12 09:27:31 --> Output Class Initialized
DEBUG - 2011-08-12 09:27:31 --> Input Class Initialized
DEBUG - 2011-08-12 09:27:31 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-12 09:27:31 --> Language Class Initialized
DEBUG - 2011-08-12 09:27:31 --> Loader Class Initialized
DEBUG - 2011-08-12 09:27:31 --> Controller Class Initialized
DEBUG - 2011-08-12 09:27:31 --> Model Class Initialized
DEBUG - 2011-08-12 09:27:31 --> Model Class Initialized
DEBUG - 2011-08-12 09:27:31 --> Model Class Initialized
DEBUG - 2011-08-12 09:27:31 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-12 09:27:31 --> Database Driver Class Initialized
DEBUG - 2011-08-12 09:27:31 --> File loaded: application/views/table/main.php
DEBUG - 2011-08-12 09:27:31 --> Helper loaded: url_helper
DEBUG - 2011-08-12 09:27:31 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-12 09:27:31 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-12 09:27:31 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-12 09:27:31 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-12 09:27:31 --> Final output sent to browser
DEBUG - 2011-08-12 09:27:31 --> Total execution time: 0.0574
DEBUG - 2011-08-12 09:27:31 --> Config Class Initialized
DEBUG - 2011-08-12 09:27:31 --> Hooks Class Initialized
DEBUG - 2011-08-12 09:27:31 --> Utf8 Class Initialized
DEBUG - 2011-08-12 09:27:31 --> UTF-8 Support Enabled
DEBUG - 2011-08-12 09:27:31 --> URI Class Initialized
DEBUG - 2011-08-12 09:27:31 --> Router Class Initialized
ERROR - 2011-08-12 09:27:31 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-08-12 09:27:48 --> Config Class Initialized
DEBUG - 2011-08-12 09:27:48 --> Hooks Class Initialized
DEBUG - 2011-08-12 09:27:48 --> Utf8 Class Initialized
DEBUG - 2011-08-12 09:27:48 --> UTF-8 Support Enabled
DEBUG - 2011-08-12 09:27:48 --> URI Class Initialized
DEBUG - 2011-08-12 09:27:48 --> Router Class Initialized
DEBUG - 2011-08-12 09:27:48 --> Output Class Initialized
DEBUG - 2011-08-12 09:27:48 --> Input Class Initialized
DEBUG - 2011-08-12 09:27:48 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-12 09:27:48 --> Language Class Initialized
DEBUG - 2011-08-12 09:27:48 --> Loader Class Initialized
DEBUG - 2011-08-12 09:27:48 --> Controller Class Initialized
DEBUG - 2011-08-12 09:27:48 --> Model Class Initialized
DEBUG - 2011-08-12 09:27:48 --> Model Class Initialized
DEBUG - 2011-08-12 09:27:48 --> Model Class Initialized
DEBUG - 2011-08-12 09:27:48 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-12 09:27:48 --> Database Driver Class Initialized
DEBUG - 2011-08-12 09:27:48 --> File loaded: application/views/table/main.php
DEBUG - 2011-08-12 09:27:48 --> Helper loaded: url_helper
DEBUG - 2011-08-12 09:27:48 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-12 09:27:48 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-12 09:27:48 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-12 09:27:48 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-12 09:27:48 --> Final output sent to browser
DEBUG - 2011-08-12 09:27:48 --> Total execution time: 0.3305
DEBUG - 2011-08-12 09:27:49 --> Config Class Initialized
DEBUG - 2011-08-12 09:27:49 --> Hooks Class Initialized
DEBUG - 2011-08-12 09:27:49 --> Utf8 Class Initialized
DEBUG - 2011-08-12 09:27:49 --> UTF-8 Support Enabled
DEBUG - 2011-08-12 09:27:49 --> URI Class Initialized
DEBUG - 2011-08-12 09:27:49 --> Router Class Initialized
DEBUG - 2011-08-12 09:27:49 --> Output Class Initialized
DEBUG - 2011-08-12 09:27:49 --> Input Class Initialized
DEBUG - 2011-08-12 09:27:49 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-12 09:27:49 --> Language Class Initialized
DEBUG - 2011-08-12 09:27:49 --> Loader Class Initialized
DEBUG - 2011-08-12 09:27:49 --> Controller Class Initialized
DEBUG - 2011-08-12 09:27:49 --> Model Class Initialized
DEBUG - 2011-08-12 09:27:49 --> Model Class Initialized
DEBUG - 2011-08-12 09:27:49 --> Model Class Initialized
DEBUG - 2011-08-12 09:27:49 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-12 09:27:49 --> Database Driver Class Initialized
DEBUG - 2011-08-12 09:27:49 --> File loaded: application/views/table/main.php
DEBUG - 2011-08-12 09:27:49 --> Helper loaded: url_helper
DEBUG - 2011-08-12 09:27:49 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-12 09:27:49 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-12 09:27:49 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-12 09:27:49 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-12 09:27:49 --> Final output sent to browser
DEBUG - 2011-08-12 09:27:49 --> Total execution time: 0.0456
DEBUG - 2011-08-12 09:27:50 --> Config Class Initialized
DEBUG - 2011-08-12 09:27:50 --> Hooks Class Initialized
DEBUG - 2011-08-12 09:27:50 --> Utf8 Class Initialized
DEBUG - 2011-08-12 09:27:50 --> UTF-8 Support Enabled
DEBUG - 2011-08-12 09:27:50 --> URI Class Initialized
DEBUG - 2011-08-12 09:27:50 --> Router Class Initialized
ERROR - 2011-08-12 09:27:50 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-08-12 09:28:16 --> Config Class Initialized
DEBUG - 2011-08-12 09:28:16 --> Hooks Class Initialized
DEBUG - 2011-08-12 09:28:16 --> Utf8 Class Initialized
DEBUG - 2011-08-12 09:28:16 --> UTF-8 Support Enabled
DEBUG - 2011-08-12 09:28:16 --> URI Class Initialized
DEBUG - 2011-08-12 09:28:16 --> Router Class Initialized
DEBUG - 2011-08-12 09:28:16 --> Output Class Initialized
DEBUG - 2011-08-12 09:28:16 --> Input Class Initialized
DEBUG - 2011-08-12 09:28:16 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-12 09:28:16 --> Language Class Initialized
DEBUG - 2011-08-12 09:28:16 --> Loader Class Initialized
DEBUG - 2011-08-12 09:28:16 --> Controller Class Initialized
DEBUG - 2011-08-12 09:28:16 --> Model Class Initialized
DEBUG - 2011-08-12 09:28:16 --> Model Class Initialized
DEBUG - 2011-08-12 09:28:16 --> Model Class Initialized
DEBUG - 2011-08-12 09:28:16 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-12 09:28:16 --> Database Driver Class Initialized
DEBUG - 2011-08-12 09:28:16 --> File loaded: application/views/table/main.php
DEBUG - 2011-08-12 09:28:16 --> Helper loaded: url_helper
DEBUG - 2011-08-12 09:28:16 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-12 09:28:16 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-12 09:28:16 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-12 09:28:16 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-12 09:28:16 --> Final output sent to browser
DEBUG - 2011-08-12 09:28:16 --> Total execution time: 0.2383
DEBUG - 2011-08-12 09:28:18 --> Config Class Initialized
DEBUG - 2011-08-12 09:28:18 --> Hooks Class Initialized
DEBUG - 2011-08-12 09:28:18 --> Utf8 Class Initialized
DEBUG - 2011-08-12 09:28:18 --> UTF-8 Support Enabled
DEBUG - 2011-08-12 09:28:18 --> URI Class Initialized
DEBUG - 2011-08-12 09:28:18 --> Router Class Initialized
ERROR - 2011-08-12 09:28:18 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-08-12 09:28:20 --> Config Class Initialized
DEBUG - 2011-08-12 09:28:20 --> Hooks Class Initialized
DEBUG - 2011-08-12 09:28:20 --> Utf8 Class Initialized
DEBUG - 2011-08-12 09:28:20 --> UTF-8 Support Enabled
DEBUG - 2011-08-12 09:28:20 --> URI Class Initialized
DEBUG - 2011-08-12 09:28:20 --> Router Class Initialized
DEBUG - 2011-08-12 09:28:20 --> Output Class Initialized
DEBUG - 2011-08-12 09:28:20 --> Input Class Initialized
DEBUG - 2011-08-12 09:28:20 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-12 09:28:20 --> Language Class Initialized
DEBUG - 2011-08-12 09:28:20 --> Loader Class Initialized
DEBUG - 2011-08-12 09:28:20 --> Controller Class Initialized
DEBUG - 2011-08-12 09:28:20 --> Model Class Initialized
DEBUG - 2011-08-12 09:28:20 --> Model Class Initialized
DEBUG - 2011-08-12 09:28:20 --> Model Class Initialized
DEBUG - 2011-08-12 09:28:20 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-12 09:28:20 --> Database Driver Class Initialized
DEBUG - 2011-08-12 09:28:20 --> File loaded: application/views/table/main.php
DEBUG - 2011-08-12 09:28:20 --> Helper loaded: url_helper
DEBUG - 2011-08-12 09:28:20 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-12 09:28:20 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-12 09:28:20 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-12 09:28:20 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-12 09:28:20 --> Final output sent to browser
DEBUG - 2011-08-12 09:28:20 --> Total execution time: 0.0497
DEBUG - 2011-08-12 09:28:34 --> Config Class Initialized
DEBUG - 2011-08-12 09:28:34 --> Hooks Class Initialized
DEBUG - 2011-08-12 09:28:34 --> Utf8 Class Initialized
DEBUG - 2011-08-12 09:28:34 --> UTF-8 Support Enabled
DEBUG - 2011-08-12 09:28:34 --> URI Class Initialized
DEBUG - 2011-08-12 09:28:34 --> Router Class Initialized
DEBUG - 2011-08-12 09:28:34 --> Output Class Initialized
DEBUG - 2011-08-12 09:28:34 --> Input Class Initialized
DEBUG - 2011-08-12 09:28:34 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-12 09:28:34 --> Language Class Initialized
DEBUG - 2011-08-12 09:28:34 --> Loader Class Initialized
DEBUG - 2011-08-12 09:28:34 --> Controller Class Initialized
DEBUG - 2011-08-12 09:28:34 --> Model Class Initialized
DEBUG - 2011-08-12 09:28:34 --> Model Class Initialized
DEBUG - 2011-08-12 09:28:34 --> Model Class Initialized
DEBUG - 2011-08-12 09:28:34 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-12 09:28:34 --> Database Driver Class Initialized
DEBUG - 2011-08-12 09:28:34 --> File loaded: application/views/table/main.php
DEBUG - 2011-08-12 09:28:34 --> Helper loaded: url_helper
DEBUG - 2011-08-12 09:28:34 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-12 09:28:34 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-12 09:28:34 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-12 09:28:34 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-12 09:28:34 --> Final output sent to browser
DEBUG - 2011-08-12 09:28:34 --> Total execution time: 0.2965
DEBUG - 2011-08-12 09:28:36 --> Config Class Initialized
DEBUG - 2011-08-12 09:28:36 --> Hooks Class Initialized
DEBUG - 2011-08-12 09:28:36 --> Utf8 Class Initialized
DEBUG - 2011-08-12 09:28:36 --> UTF-8 Support Enabled
DEBUG - 2011-08-12 09:28:36 --> URI Class Initialized
DEBUG - 2011-08-12 09:28:36 --> Router Class Initialized
ERROR - 2011-08-12 09:28:36 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-08-12 09:28:48 --> Config Class Initialized
DEBUG - 2011-08-12 09:28:48 --> Hooks Class Initialized
DEBUG - 2011-08-12 09:28:48 --> Utf8 Class Initialized
DEBUG - 2011-08-12 09:28:48 --> UTF-8 Support Enabled
DEBUG - 2011-08-12 09:28:48 --> URI Class Initialized
DEBUG - 2011-08-12 09:28:48 --> Router Class Initialized
DEBUG - 2011-08-12 09:28:48 --> Output Class Initialized
DEBUG - 2011-08-12 09:28:48 --> Input Class Initialized
DEBUG - 2011-08-12 09:28:48 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-12 09:28:48 --> Language Class Initialized
DEBUG - 2011-08-12 09:28:48 --> Loader Class Initialized
DEBUG - 2011-08-12 09:28:48 --> Controller Class Initialized
DEBUG - 2011-08-12 09:28:48 --> Model Class Initialized
DEBUG - 2011-08-12 09:28:48 --> Model Class Initialized
DEBUG - 2011-08-12 09:28:48 --> Model Class Initialized
DEBUG - 2011-08-12 09:28:48 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-12 09:28:48 --> Database Driver Class Initialized
DEBUG - 2011-08-12 09:28:48 --> File loaded: application/views/table/main.php
DEBUG - 2011-08-12 09:28:48 --> Helper loaded: url_helper
DEBUG - 2011-08-12 09:28:48 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-12 09:28:48 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-12 09:28:48 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-12 09:28:48 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-12 09:28:48 --> Final output sent to browser
DEBUG - 2011-08-12 09:28:48 --> Total execution time: 0.2607
DEBUG - 2011-08-12 09:28:50 --> Config Class Initialized
DEBUG - 2011-08-12 09:28:50 --> Hooks Class Initialized
DEBUG - 2011-08-12 09:28:50 --> Utf8 Class Initialized
DEBUG - 2011-08-12 09:28:50 --> UTF-8 Support Enabled
DEBUG - 2011-08-12 09:28:50 --> URI Class Initialized
DEBUG - 2011-08-12 09:28:50 --> Router Class Initialized
ERROR - 2011-08-12 09:28:50 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-08-12 09:28:59 --> Config Class Initialized
DEBUG - 2011-08-12 09:28:59 --> Hooks Class Initialized
DEBUG - 2011-08-12 09:28:59 --> Utf8 Class Initialized
DEBUG - 2011-08-12 09:28:59 --> UTF-8 Support Enabled
DEBUG - 2011-08-12 09:28:59 --> URI Class Initialized
DEBUG - 2011-08-12 09:28:59 --> Router Class Initialized
DEBUG - 2011-08-12 09:28:59 --> Output Class Initialized
DEBUG - 2011-08-12 09:28:59 --> Input Class Initialized
DEBUG - 2011-08-12 09:28:59 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-12 09:28:59 --> Language Class Initialized
DEBUG - 2011-08-12 09:28:59 --> Loader Class Initialized
DEBUG - 2011-08-12 09:28:59 --> Controller Class Initialized
DEBUG - 2011-08-12 09:28:59 --> Model Class Initialized
DEBUG - 2011-08-12 09:28:59 --> Model Class Initialized
DEBUG - 2011-08-12 09:28:59 --> Model Class Initialized
DEBUG - 2011-08-12 09:28:59 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-12 09:28:59 --> Database Driver Class Initialized
DEBUG - 2011-08-12 09:28:59 --> File loaded: application/views/table/main.php
DEBUG - 2011-08-12 09:28:59 --> Helper loaded: url_helper
DEBUG - 2011-08-12 09:28:59 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-12 09:28:59 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-12 09:28:59 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-12 09:28:59 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-12 09:28:59 --> Final output sent to browser
DEBUG - 2011-08-12 09:28:59 --> Total execution time: 0.2515
DEBUG - 2011-08-12 09:29:01 --> Config Class Initialized
DEBUG - 2011-08-12 09:29:01 --> Hooks Class Initialized
DEBUG - 2011-08-12 09:29:01 --> Utf8 Class Initialized
DEBUG - 2011-08-12 09:29:01 --> UTF-8 Support Enabled
DEBUG - 2011-08-12 09:29:01 --> URI Class Initialized
DEBUG - 2011-08-12 09:29:01 --> Router Class Initialized
ERROR - 2011-08-12 09:29:01 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-08-12 09:29:14 --> Config Class Initialized
DEBUG - 2011-08-12 09:29:14 --> Hooks Class Initialized
DEBUG - 2011-08-12 09:29:14 --> Utf8 Class Initialized
DEBUG - 2011-08-12 09:29:14 --> UTF-8 Support Enabled
DEBUG - 2011-08-12 09:29:14 --> URI Class Initialized
DEBUG - 2011-08-12 09:29:14 --> Router Class Initialized
DEBUG - 2011-08-12 09:29:14 --> Output Class Initialized
DEBUG - 2011-08-12 09:29:14 --> Input Class Initialized
DEBUG - 2011-08-12 09:29:14 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-12 09:29:14 --> Language Class Initialized
DEBUG - 2011-08-12 09:29:14 --> Loader Class Initialized
DEBUG - 2011-08-12 09:29:14 --> Controller Class Initialized
DEBUG - 2011-08-12 09:29:14 --> Model Class Initialized
DEBUG - 2011-08-12 09:29:14 --> Model Class Initialized
DEBUG - 2011-08-12 09:29:14 --> Model Class Initialized
DEBUG - 2011-08-12 09:29:14 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-12 09:29:14 --> Database Driver Class Initialized
DEBUG - 2011-08-12 09:29:14 --> File loaded: application/views/table/main.php
DEBUG - 2011-08-12 09:29:14 --> Helper loaded: url_helper
DEBUG - 2011-08-12 09:29:14 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-12 09:29:14 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-12 09:29:14 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-12 09:29:14 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-12 09:29:14 --> Final output sent to browser
DEBUG - 2011-08-12 09:29:14 --> Total execution time: 0.2169
DEBUG - 2011-08-12 09:29:16 --> Config Class Initialized
DEBUG - 2011-08-12 09:29:16 --> Hooks Class Initialized
DEBUG - 2011-08-12 09:29:16 --> Utf8 Class Initialized
DEBUG - 2011-08-12 09:29:16 --> UTF-8 Support Enabled
DEBUG - 2011-08-12 09:29:16 --> URI Class Initialized
DEBUG - 2011-08-12 09:29:16 --> Router Class Initialized
ERROR - 2011-08-12 09:29:16 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-08-12 09:29:29 --> Config Class Initialized
DEBUG - 2011-08-12 09:29:29 --> Hooks Class Initialized
DEBUG - 2011-08-12 09:29:29 --> Utf8 Class Initialized
DEBUG - 2011-08-12 09:29:29 --> UTF-8 Support Enabled
DEBUG - 2011-08-12 09:29:29 --> URI Class Initialized
DEBUG - 2011-08-12 09:29:29 --> Router Class Initialized
DEBUG - 2011-08-12 09:29:29 --> Output Class Initialized
DEBUG - 2011-08-12 09:29:29 --> Input Class Initialized
DEBUG - 2011-08-12 09:29:29 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-12 09:29:29 --> Language Class Initialized
DEBUG - 2011-08-12 09:29:29 --> Loader Class Initialized
DEBUG - 2011-08-12 09:29:29 --> Controller Class Initialized
DEBUG - 2011-08-12 09:29:29 --> Model Class Initialized
DEBUG - 2011-08-12 09:29:29 --> Model Class Initialized
DEBUG - 2011-08-12 09:29:29 --> Model Class Initialized
DEBUG - 2011-08-12 09:29:29 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-12 09:29:29 --> Database Driver Class Initialized
DEBUG - 2011-08-12 09:29:29 --> File loaded: application/views/table/main.php
DEBUG - 2011-08-12 09:29:29 --> Helper loaded: url_helper
DEBUG - 2011-08-12 09:29:29 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-12 09:29:29 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-12 09:29:29 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-12 09:29:29 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-12 09:29:29 --> Final output sent to browser
DEBUG - 2011-08-12 09:29:29 --> Total execution time: 0.0474
DEBUG - 2011-08-12 09:29:29 --> Config Class Initialized
DEBUG - 2011-08-12 09:29:29 --> Hooks Class Initialized
DEBUG - 2011-08-12 09:29:29 --> Utf8 Class Initialized
DEBUG - 2011-08-12 09:29:29 --> UTF-8 Support Enabled
DEBUG - 2011-08-12 09:29:29 --> URI Class Initialized
DEBUG - 2011-08-12 09:29:29 --> Router Class Initialized
DEBUG - 2011-08-12 09:29:29 --> Output Class Initialized
DEBUG - 2011-08-12 09:29:29 --> Input Class Initialized
DEBUG - 2011-08-12 09:29:29 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-12 09:29:29 --> Language Class Initialized
DEBUG - 2011-08-12 09:29:29 --> Loader Class Initialized
DEBUG - 2011-08-12 09:29:29 --> Controller Class Initialized
DEBUG - 2011-08-12 09:29:29 --> Model Class Initialized
DEBUG - 2011-08-12 09:29:29 --> Model Class Initialized
DEBUG - 2011-08-12 09:29:29 --> Model Class Initialized
DEBUG - 2011-08-12 09:29:29 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-12 09:29:29 --> Database Driver Class Initialized
DEBUG - 2011-08-12 09:29:29 --> File loaded: application/views/table/main.php
DEBUG - 2011-08-12 09:29:30 --> Helper loaded: url_helper
DEBUG - 2011-08-12 09:29:30 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-12 09:29:30 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-12 09:29:30 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-12 09:29:30 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-12 09:29:30 --> Final output sent to browser
DEBUG - 2011-08-12 09:29:30 --> Total execution time: 0.0988
DEBUG - 2011-08-12 09:29:34 --> Config Class Initialized
DEBUG - 2011-08-12 09:29:34 --> Hooks Class Initialized
DEBUG - 2011-08-12 09:29:34 --> Utf8 Class Initialized
DEBUG - 2011-08-12 09:29:34 --> UTF-8 Support Enabled
DEBUG - 2011-08-12 09:29:34 --> URI Class Initialized
DEBUG - 2011-08-12 09:29:34 --> Router Class Initialized
DEBUG - 2011-08-12 09:29:34 --> Output Class Initialized
DEBUG - 2011-08-12 09:29:34 --> Input Class Initialized
DEBUG - 2011-08-12 09:29:34 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-12 09:29:34 --> Language Class Initialized
DEBUG - 2011-08-12 09:29:34 --> Loader Class Initialized
DEBUG - 2011-08-12 09:29:34 --> Controller Class Initialized
DEBUG - 2011-08-12 09:29:34 --> Model Class Initialized
DEBUG - 2011-08-12 09:29:34 --> Model Class Initialized
DEBUG - 2011-08-12 09:29:34 --> Model Class Initialized
DEBUG - 2011-08-12 09:29:34 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-12 09:29:34 --> Database Driver Class Initialized
DEBUG - 2011-08-12 09:29:34 --> File loaded: application/views/table/main.php
DEBUG - 2011-08-12 09:29:34 --> Helper loaded: url_helper
DEBUG - 2011-08-12 09:29:34 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-12 09:29:34 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-12 09:29:34 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-12 09:29:34 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-12 09:29:34 --> Final output sent to browser
DEBUG - 2011-08-12 09:29:34 --> Total execution time: 0.0763
DEBUG - 2011-08-12 09:29:36 --> Config Class Initialized
DEBUG - 2011-08-12 09:29:36 --> Hooks Class Initialized
DEBUG - 2011-08-12 09:29:36 --> Utf8 Class Initialized
DEBUG - 2011-08-12 09:29:36 --> UTF-8 Support Enabled
DEBUG - 2011-08-12 09:29:36 --> URI Class Initialized
DEBUG - 2011-08-12 09:29:36 --> Router Class Initialized
DEBUG - 2011-08-12 09:29:36 --> Output Class Initialized
DEBUG - 2011-08-12 09:29:36 --> Input Class Initialized
DEBUG - 2011-08-12 09:29:36 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-12 09:29:36 --> Language Class Initialized
DEBUG - 2011-08-12 09:29:36 --> Loader Class Initialized
DEBUG - 2011-08-12 09:29:36 --> Controller Class Initialized
DEBUG - 2011-08-12 09:29:36 --> Model Class Initialized
DEBUG - 2011-08-12 09:29:36 --> Model Class Initialized
DEBUG - 2011-08-12 09:29:36 --> Model Class Initialized
DEBUG - 2011-08-12 09:29:36 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-12 09:29:36 --> Database Driver Class Initialized
DEBUG - 2011-08-12 09:29:36 --> File loaded: application/views/table/main.php
DEBUG - 2011-08-12 09:29:36 --> Helper loaded: url_helper
DEBUG - 2011-08-12 09:29:36 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-12 09:29:36 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-12 09:29:36 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-12 09:29:36 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-12 09:29:36 --> Final output sent to browser
DEBUG - 2011-08-12 09:29:36 --> Total execution time: 0.0867
DEBUG - 2011-08-12 09:29:39 --> Config Class Initialized
DEBUG - 2011-08-12 09:29:39 --> Hooks Class Initialized
DEBUG - 2011-08-12 09:29:39 --> Utf8 Class Initialized
DEBUG - 2011-08-12 09:29:39 --> UTF-8 Support Enabled
DEBUG - 2011-08-12 09:29:39 --> URI Class Initialized
DEBUG - 2011-08-12 09:29:39 --> Router Class Initialized
DEBUG - 2011-08-12 09:29:39 --> Output Class Initialized
DEBUG - 2011-08-12 09:29:39 --> Input Class Initialized
DEBUG - 2011-08-12 09:29:39 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-12 09:29:39 --> Language Class Initialized
DEBUG - 2011-08-12 09:29:39 --> Loader Class Initialized
DEBUG - 2011-08-12 09:29:39 --> Controller Class Initialized
DEBUG - 2011-08-12 09:29:39 --> Model Class Initialized
DEBUG - 2011-08-12 09:29:39 --> Model Class Initialized
DEBUG - 2011-08-12 09:29:39 --> Model Class Initialized
DEBUG - 2011-08-12 09:29:39 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-12 09:29:39 --> Database Driver Class Initialized
DEBUG - 2011-08-12 09:29:39 --> File loaded: application/views/table/main.php
DEBUG - 2011-08-12 09:29:39 --> Helper loaded: url_helper
DEBUG - 2011-08-12 09:29:39 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-12 09:29:39 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-12 09:29:39 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-12 09:29:39 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-12 09:29:39 --> Final output sent to browser
DEBUG - 2011-08-12 09:29:39 --> Total execution time: 0.5110
DEBUG - 2011-08-12 09:29:40 --> Config Class Initialized
DEBUG - 2011-08-12 09:29:40 --> Hooks Class Initialized
DEBUG - 2011-08-12 09:29:40 --> Utf8 Class Initialized
DEBUG - 2011-08-12 09:29:40 --> UTF-8 Support Enabled
DEBUG - 2011-08-12 09:29:40 --> URI Class Initialized
DEBUG - 2011-08-12 09:29:40 --> Router Class Initialized
DEBUG - 2011-08-12 09:29:40 --> Output Class Initialized
DEBUG - 2011-08-12 09:29:40 --> Input Class Initialized
DEBUG - 2011-08-12 09:29:40 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-12 09:29:40 --> Language Class Initialized
DEBUG - 2011-08-12 09:29:40 --> Loader Class Initialized
DEBUG - 2011-08-12 09:29:40 --> Controller Class Initialized
DEBUG - 2011-08-12 09:29:40 --> Model Class Initialized
DEBUG - 2011-08-12 09:29:40 --> Model Class Initialized
DEBUG - 2011-08-12 09:29:40 --> Model Class Initialized
DEBUG - 2011-08-12 09:29:40 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-12 09:29:40 --> Database Driver Class Initialized
DEBUG - 2011-08-12 09:29:40 --> File loaded: application/views/table/main.php
DEBUG - 2011-08-12 09:29:40 --> Helper loaded: url_helper
DEBUG - 2011-08-12 09:29:40 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-12 09:29:40 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-12 09:29:40 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-12 09:29:40 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-12 09:29:40 --> Final output sent to browser
DEBUG - 2011-08-12 09:29:40 --> Total execution time: 0.0731
DEBUG - 2011-08-12 09:29:41 --> Config Class Initialized
DEBUG - 2011-08-12 09:29:41 --> Hooks Class Initialized
DEBUG - 2011-08-12 09:29:41 --> Utf8 Class Initialized
DEBUG - 2011-08-12 09:29:41 --> UTF-8 Support Enabled
DEBUG - 2011-08-12 09:29:41 --> URI Class Initialized
DEBUG - 2011-08-12 09:29:41 --> Router Class Initialized
DEBUG - 2011-08-12 09:29:41 --> Output Class Initialized
DEBUG - 2011-08-12 09:29:41 --> Input Class Initialized
DEBUG - 2011-08-12 09:29:41 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-12 09:29:41 --> Language Class Initialized
DEBUG - 2011-08-12 09:29:41 --> Loader Class Initialized
DEBUG - 2011-08-12 09:29:41 --> Controller Class Initialized
DEBUG - 2011-08-12 09:29:41 --> Model Class Initialized
DEBUG - 2011-08-12 09:29:41 --> Model Class Initialized
DEBUG - 2011-08-12 09:29:41 --> Model Class Initialized
DEBUG - 2011-08-12 09:29:41 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-12 09:29:41 --> Database Driver Class Initialized
DEBUG - 2011-08-12 09:29:41 --> File loaded: application/views/table/main.php
DEBUG - 2011-08-12 09:29:41 --> Helper loaded: url_helper
DEBUG - 2011-08-12 09:29:41 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-12 09:29:41 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-12 09:29:41 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-12 09:29:41 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-12 09:29:41 --> Final output sent to browser
DEBUG - 2011-08-12 09:29:41 --> Total execution time: 0.0789
DEBUG - 2011-08-12 09:29:41 --> Config Class Initialized
DEBUG - 2011-08-12 09:29:41 --> Hooks Class Initialized
DEBUG - 2011-08-12 09:29:41 --> Utf8 Class Initialized
DEBUG - 2011-08-12 09:29:41 --> UTF-8 Support Enabled
DEBUG - 2011-08-12 09:29:41 --> URI Class Initialized
DEBUG - 2011-08-12 09:29:41 --> Router Class Initialized
ERROR - 2011-08-12 09:29:41 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-08-12 09:30:18 --> Config Class Initialized
DEBUG - 2011-08-12 09:30:18 --> Hooks Class Initialized
DEBUG - 2011-08-12 09:30:18 --> Utf8 Class Initialized
DEBUG - 2011-08-12 09:30:18 --> UTF-8 Support Enabled
DEBUG - 2011-08-12 09:30:18 --> URI Class Initialized
DEBUG - 2011-08-12 09:30:18 --> Router Class Initialized
DEBUG - 2011-08-12 09:30:18 --> Output Class Initialized
DEBUG - 2011-08-12 09:30:18 --> Input Class Initialized
DEBUG - 2011-08-12 09:30:18 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-12 09:30:18 --> Language Class Initialized
DEBUG - 2011-08-12 09:30:18 --> Loader Class Initialized
DEBUG - 2011-08-12 09:30:18 --> Controller Class Initialized
DEBUG - 2011-08-12 09:30:18 --> Model Class Initialized
DEBUG - 2011-08-12 09:30:18 --> Model Class Initialized
DEBUG - 2011-08-12 09:30:18 --> Model Class Initialized
DEBUG - 2011-08-12 09:30:18 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-12 09:30:18 --> Database Driver Class Initialized
DEBUG - 2011-08-12 09:30:19 --> File loaded: application/views/table/main.php
DEBUG - 2011-08-12 09:30:19 --> Helper loaded: url_helper
DEBUG - 2011-08-12 09:30:19 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-12 09:30:19 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-12 09:30:19 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-12 09:30:19 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-12 09:30:19 --> Final output sent to browser
DEBUG - 2011-08-12 09:30:19 --> Total execution time: 0.3923
DEBUG - 2011-08-12 09:30:20 --> Config Class Initialized
DEBUG - 2011-08-12 09:30:20 --> Hooks Class Initialized
DEBUG - 2011-08-12 09:30:20 --> Utf8 Class Initialized
DEBUG - 2011-08-12 09:30:20 --> UTF-8 Support Enabled
DEBUG - 2011-08-12 09:30:20 --> URI Class Initialized
DEBUG - 2011-08-12 09:30:20 --> Router Class Initialized
ERROR - 2011-08-12 09:30:20 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-08-12 09:30:41 --> Config Class Initialized
DEBUG - 2011-08-12 09:30:41 --> Hooks Class Initialized
DEBUG - 2011-08-12 09:30:41 --> Utf8 Class Initialized
DEBUG - 2011-08-12 09:30:41 --> UTF-8 Support Enabled
DEBUG - 2011-08-12 09:30:41 --> URI Class Initialized
DEBUG - 2011-08-12 09:30:41 --> Router Class Initialized
DEBUG - 2011-08-12 09:30:41 --> Output Class Initialized
DEBUG - 2011-08-12 09:30:41 --> Input Class Initialized
DEBUG - 2011-08-12 09:30:41 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-12 09:30:41 --> Language Class Initialized
DEBUG - 2011-08-12 09:30:41 --> Loader Class Initialized
DEBUG - 2011-08-12 09:30:41 --> Controller Class Initialized
DEBUG - 2011-08-12 09:30:41 --> Model Class Initialized
DEBUG - 2011-08-12 09:30:41 --> Model Class Initialized
DEBUG - 2011-08-12 09:30:41 --> Model Class Initialized
DEBUG - 2011-08-12 09:30:41 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-12 09:30:41 --> Database Driver Class Initialized
DEBUG - 2011-08-12 09:30:41 --> File loaded: application/views/table/main.php
DEBUG - 2011-08-12 09:30:41 --> Helper loaded: url_helper
DEBUG - 2011-08-12 09:30:41 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-12 09:30:41 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-12 09:30:41 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-12 09:30:41 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-12 09:30:41 --> Final output sent to browser
DEBUG - 2011-08-12 09:30:41 --> Total execution time: 0.6270
DEBUG - 2011-08-12 09:30:43 --> Config Class Initialized
DEBUG - 2011-08-12 09:30:43 --> Hooks Class Initialized
DEBUG - 2011-08-12 09:30:43 --> Utf8 Class Initialized
DEBUG - 2011-08-12 09:30:43 --> UTF-8 Support Enabled
DEBUG - 2011-08-12 09:30:43 --> URI Class Initialized
DEBUG - 2011-08-12 09:30:43 --> Router Class Initialized
DEBUG - 2011-08-12 09:30:43 --> Output Class Initialized
DEBUG - 2011-08-12 09:30:43 --> Input Class Initialized
DEBUG - 2011-08-12 09:30:43 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-12 09:30:43 --> Language Class Initialized
DEBUG - 2011-08-12 09:30:43 --> Loader Class Initialized
DEBUG - 2011-08-12 09:30:43 --> Controller Class Initialized
DEBUG - 2011-08-12 09:30:43 --> Model Class Initialized
DEBUG - 2011-08-12 09:30:43 --> Model Class Initialized
DEBUG - 2011-08-12 09:30:43 --> Model Class Initialized
DEBUG - 2011-08-12 09:30:43 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-12 09:30:43 --> Database Driver Class Initialized
DEBUG - 2011-08-12 09:30:43 --> File loaded: application/views/table/main.php
DEBUG - 2011-08-12 09:30:43 --> Helper loaded: url_helper
DEBUG - 2011-08-12 09:30:43 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-12 09:30:43 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-12 09:30:43 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-12 09:30:43 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-12 09:30:43 --> Final output sent to browser
DEBUG - 2011-08-12 09:30:43 --> Total execution time: 0.1030
DEBUG - 2011-08-12 09:30:43 --> Config Class Initialized
DEBUG - 2011-08-12 09:30:43 --> Hooks Class Initialized
DEBUG - 2011-08-12 09:30:43 --> Utf8 Class Initialized
DEBUG - 2011-08-12 09:30:43 --> UTF-8 Support Enabled
DEBUG - 2011-08-12 09:30:43 --> URI Class Initialized
DEBUG - 2011-08-12 09:30:43 --> Router Class Initialized
ERROR - 2011-08-12 09:30:43 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-08-12 09:30:47 --> Config Class Initialized
DEBUG - 2011-08-12 09:30:47 --> Hooks Class Initialized
DEBUG - 2011-08-12 09:30:47 --> Utf8 Class Initialized
DEBUG - 2011-08-12 09:30:47 --> UTF-8 Support Enabled
DEBUG - 2011-08-12 09:30:47 --> URI Class Initialized
DEBUG - 2011-08-12 09:30:47 --> Router Class Initialized
DEBUG - 2011-08-12 09:30:47 --> Output Class Initialized
DEBUG - 2011-08-12 09:30:47 --> Input Class Initialized
DEBUG - 2011-08-12 09:30:47 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-12 09:30:47 --> Language Class Initialized
DEBUG - 2011-08-12 09:30:47 --> Loader Class Initialized
DEBUG - 2011-08-12 09:30:47 --> Controller Class Initialized
DEBUG - 2011-08-12 09:30:47 --> Model Class Initialized
DEBUG - 2011-08-12 09:30:47 --> Model Class Initialized
DEBUG - 2011-08-12 09:30:47 --> Model Class Initialized
DEBUG - 2011-08-12 09:30:47 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-12 09:30:47 --> Database Driver Class Initialized
DEBUG - 2011-08-12 09:30:47 --> File loaded: application/views/table/main.php
DEBUG - 2011-08-12 09:30:47 --> Helper loaded: url_helper
DEBUG - 2011-08-12 09:30:47 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-12 09:30:47 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-12 09:30:47 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-12 09:30:47 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-12 09:30:47 --> Final output sent to browser
DEBUG - 2011-08-12 09:30:47 --> Total execution time: 0.0470
DEBUG - 2011-08-12 09:30:56 --> Config Class Initialized
DEBUG - 2011-08-12 09:30:56 --> Hooks Class Initialized
DEBUG - 2011-08-12 09:30:56 --> Utf8 Class Initialized
DEBUG - 2011-08-12 09:30:56 --> UTF-8 Support Enabled
DEBUG - 2011-08-12 09:30:56 --> URI Class Initialized
DEBUG - 2011-08-12 09:30:56 --> Router Class Initialized
DEBUG - 2011-08-12 09:30:56 --> Output Class Initialized
DEBUG - 2011-08-12 09:30:56 --> Input Class Initialized
DEBUG - 2011-08-12 09:30:56 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-12 09:30:56 --> Language Class Initialized
DEBUG - 2011-08-12 09:30:56 --> Loader Class Initialized
DEBUG - 2011-08-12 09:30:56 --> Controller Class Initialized
DEBUG - 2011-08-12 09:30:56 --> Model Class Initialized
DEBUG - 2011-08-12 09:30:56 --> Model Class Initialized
DEBUG - 2011-08-12 09:30:56 --> Model Class Initialized
DEBUG - 2011-08-12 09:30:56 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-12 09:30:56 --> Database Driver Class Initialized
DEBUG - 2011-08-12 09:30:56 --> File loaded: application/views/table/main.php
DEBUG - 2011-08-12 09:30:56 --> Helper loaded: url_helper
DEBUG - 2011-08-12 09:30:56 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-12 09:30:56 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-12 09:30:56 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-12 09:30:56 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-12 09:30:56 --> Final output sent to browser
DEBUG - 2011-08-12 09:30:56 --> Total execution time: 0.5906
DEBUG - 2011-08-12 09:30:58 --> Config Class Initialized
DEBUG - 2011-08-12 09:30:58 --> Hooks Class Initialized
DEBUG - 2011-08-12 09:30:58 --> Utf8 Class Initialized
DEBUG - 2011-08-12 09:30:58 --> UTF-8 Support Enabled
DEBUG - 2011-08-12 09:30:58 --> URI Class Initialized
DEBUG - 2011-08-12 09:30:58 --> Router Class Initialized
ERROR - 2011-08-12 09:30:58 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-08-12 09:30:59 --> Config Class Initialized
DEBUG - 2011-08-12 09:30:59 --> Hooks Class Initialized
DEBUG - 2011-08-12 09:30:59 --> Utf8 Class Initialized
DEBUG - 2011-08-12 09:30:59 --> UTF-8 Support Enabled
DEBUG - 2011-08-12 09:30:59 --> URI Class Initialized
DEBUG - 2011-08-12 09:30:59 --> Router Class Initialized
DEBUG - 2011-08-12 09:30:59 --> Output Class Initialized
DEBUG - 2011-08-12 09:30:59 --> Input Class Initialized
DEBUG - 2011-08-12 09:30:59 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-12 09:30:59 --> Language Class Initialized
DEBUG - 2011-08-12 09:30:59 --> Loader Class Initialized
DEBUG - 2011-08-12 09:30:59 --> Controller Class Initialized
DEBUG - 2011-08-12 09:30:59 --> Model Class Initialized
DEBUG - 2011-08-12 09:30:59 --> Model Class Initialized
DEBUG - 2011-08-12 09:30:59 --> Model Class Initialized
DEBUG - 2011-08-12 09:30:59 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-12 09:30:59 --> Database Driver Class Initialized
DEBUG - 2011-08-12 09:30:59 --> File loaded: application/views/table/main.php
DEBUG - 2011-08-12 09:30:59 --> Helper loaded: url_helper
DEBUG - 2011-08-12 09:30:59 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-12 09:30:59 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-12 09:30:59 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-12 09:30:59 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-12 09:30:59 --> Final output sent to browser
DEBUG - 2011-08-12 09:30:59 --> Total execution time: 0.0430
DEBUG - 2011-08-12 09:31:06 --> Config Class Initialized
DEBUG - 2011-08-12 09:31:06 --> Hooks Class Initialized
DEBUG - 2011-08-12 09:31:06 --> Utf8 Class Initialized
DEBUG - 2011-08-12 09:31:06 --> UTF-8 Support Enabled
DEBUG - 2011-08-12 09:31:06 --> URI Class Initialized
DEBUG - 2011-08-12 09:31:06 --> Router Class Initialized
DEBUG - 2011-08-12 09:31:06 --> Output Class Initialized
DEBUG - 2011-08-12 09:31:06 --> Input Class Initialized
DEBUG - 2011-08-12 09:31:06 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-12 09:31:06 --> Language Class Initialized
DEBUG - 2011-08-12 09:31:06 --> Loader Class Initialized
DEBUG - 2011-08-12 09:31:06 --> Controller Class Initialized
DEBUG - 2011-08-12 09:31:06 --> Model Class Initialized
DEBUG - 2011-08-12 09:31:06 --> Model Class Initialized
DEBUG - 2011-08-12 09:31:06 --> Model Class Initialized
DEBUG - 2011-08-12 09:31:06 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-12 09:31:06 --> Database Driver Class Initialized
DEBUG - 2011-08-12 09:31:07 --> File loaded: application/views/table/main.php
DEBUG - 2011-08-12 09:31:07 --> Helper loaded: url_helper
DEBUG - 2011-08-12 09:31:07 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-12 09:31:07 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-12 09:31:07 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-12 09:31:07 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-12 09:31:07 --> Final output sent to browser
DEBUG - 2011-08-12 09:31:07 --> Total execution time: 0.4496
DEBUG - 2011-08-12 09:31:08 --> Config Class Initialized
DEBUG - 2011-08-12 09:31:08 --> Hooks Class Initialized
DEBUG - 2011-08-12 09:31:08 --> Utf8 Class Initialized
DEBUG - 2011-08-12 09:31:08 --> UTF-8 Support Enabled
DEBUG - 2011-08-12 09:31:08 --> URI Class Initialized
DEBUG - 2011-08-12 09:31:08 --> Router Class Initialized
ERROR - 2011-08-12 09:31:08 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-08-12 09:31:09 --> Config Class Initialized
DEBUG - 2011-08-12 09:31:09 --> Hooks Class Initialized
DEBUG - 2011-08-12 09:31:09 --> Utf8 Class Initialized
DEBUG - 2011-08-12 09:31:09 --> UTF-8 Support Enabled
DEBUG - 2011-08-12 09:31:09 --> URI Class Initialized
DEBUG - 2011-08-12 09:31:09 --> Router Class Initialized
DEBUG - 2011-08-12 09:31:09 --> Output Class Initialized
DEBUG - 2011-08-12 09:31:09 --> Input Class Initialized
DEBUG - 2011-08-12 09:31:09 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-12 09:31:09 --> Language Class Initialized
DEBUG - 2011-08-12 09:31:09 --> Loader Class Initialized
DEBUG - 2011-08-12 09:31:09 --> Controller Class Initialized
DEBUG - 2011-08-12 09:31:09 --> Model Class Initialized
DEBUG - 2011-08-12 09:31:09 --> Model Class Initialized
DEBUG - 2011-08-12 09:31:09 --> Model Class Initialized
DEBUG - 2011-08-12 09:31:09 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-12 09:31:09 --> Database Driver Class Initialized
DEBUG - 2011-08-12 09:31:09 --> File loaded: application/views/table/main.php
DEBUG - 2011-08-12 09:31:09 --> Helper loaded: url_helper
DEBUG - 2011-08-12 09:31:09 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-12 09:31:09 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-12 09:31:09 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-12 09:31:09 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-12 09:31:09 --> Final output sent to browser
DEBUG - 2011-08-12 09:31:09 --> Total execution time: 0.0520
DEBUG - 2011-08-12 09:31:27 --> Config Class Initialized
DEBUG - 2011-08-12 09:31:27 --> Hooks Class Initialized
DEBUG - 2011-08-12 09:31:27 --> Utf8 Class Initialized
DEBUG - 2011-08-12 09:31:27 --> UTF-8 Support Enabled
DEBUG - 2011-08-12 09:31:27 --> URI Class Initialized
DEBUG - 2011-08-12 09:31:27 --> Router Class Initialized
DEBUG - 2011-08-12 09:31:27 --> Output Class Initialized
DEBUG - 2011-08-12 09:31:27 --> Input Class Initialized
DEBUG - 2011-08-12 09:31:27 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-12 09:31:27 --> Language Class Initialized
DEBUG - 2011-08-12 09:31:27 --> Loader Class Initialized
DEBUG - 2011-08-12 09:31:27 --> Controller Class Initialized
DEBUG - 2011-08-12 09:31:27 --> Model Class Initialized
DEBUG - 2011-08-12 09:31:27 --> Model Class Initialized
DEBUG - 2011-08-12 09:31:27 --> Model Class Initialized
DEBUG - 2011-08-12 09:31:27 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-12 09:31:27 --> Database Driver Class Initialized
DEBUG - 2011-08-12 09:31:28 --> File loaded: application/views/table/main.php
DEBUG - 2011-08-12 09:31:28 --> Helper loaded: url_helper
DEBUG - 2011-08-12 09:31:28 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-12 09:31:28 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-12 09:31:28 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-12 09:31:28 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-12 09:31:28 --> Final output sent to browser
DEBUG - 2011-08-12 09:31:28 --> Total execution time: 0.3521
DEBUG - 2011-08-12 09:31:29 --> Config Class Initialized
DEBUG - 2011-08-12 09:31:29 --> Hooks Class Initialized
DEBUG - 2011-08-12 09:31:29 --> Utf8 Class Initialized
DEBUG - 2011-08-12 09:31:29 --> UTF-8 Support Enabled
DEBUG - 2011-08-12 09:31:29 --> URI Class Initialized
DEBUG - 2011-08-12 09:31:29 --> Router Class Initialized
DEBUG - 2011-08-12 09:31:29 --> Output Class Initialized
DEBUG - 2011-08-12 09:31:29 --> Input Class Initialized
DEBUG - 2011-08-12 09:31:29 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-12 09:31:29 --> Language Class Initialized
DEBUG - 2011-08-12 09:31:29 --> Loader Class Initialized
DEBUG - 2011-08-12 09:31:29 --> Controller Class Initialized
DEBUG - 2011-08-12 09:31:29 --> Model Class Initialized
DEBUG - 2011-08-12 09:31:29 --> Model Class Initialized
DEBUG - 2011-08-12 09:31:29 --> Model Class Initialized
DEBUG - 2011-08-12 09:31:29 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-12 09:31:29 --> Database Driver Class Initialized
DEBUG - 2011-08-12 09:31:29 --> File loaded: application/views/table/main.php
DEBUG - 2011-08-12 09:31:29 --> Helper loaded: url_helper
DEBUG - 2011-08-12 09:31:29 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-12 09:31:29 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-12 09:31:29 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-12 09:31:29 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-12 09:31:29 --> Final output sent to browser
DEBUG - 2011-08-12 09:31:29 --> Total execution time: 0.0694
DEBUG - 2011-08-12 09:31:29 --> Config Class Initialized
DEBUG - 2011-08-12 09:31:29 --> Hooks Class Initialized
DEBUG - 2011-08-12 09:31:29 --> Utf8 Class Initialized
DEBUG - 2011-08-12 09:31:29 --> UTF-8 Support Enabled
DEBUG - 2011-08-12 09:31:29 --> URI Class Initialized
DEBUG - 2011-08-12 09:31:29 --> Router Class Initialized
ERROR - 2011-08-12 09:31:29 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-08-12 09:31:40 --> Config Class Initialized
DEBUG - 2011-08-12 09:31:40 --> Hooks Class Initialized
DEBUG - 2011-08-12 09:31:40 --> Utf8 Class Initialized
DEBUG - 2011-08-12 09:31:40 --> UTF-8 Support Enabled
DEBUG - 2011-08-12 09:31:40 --> URI Class Initialized
DEBUG - 2011-08-12 09:31:40 --> Router Class Initialized
DEBUG - 2011-08-12 09:31:40 --> Output Class Initialized
DEBUG - 2011-08-12 09:31:40 --> Input Class Initialized
DEBUG - 2011-08-12 09:31:40 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-12 09:31:40 --> Language Class Initialized
DEBUG - 2011-08-12 09:31:40 --> Loader Class Initialized
DEBUG - 2011-08-12 09:31:40 --> Controller Class Initialized
DEBUG - 2011-08-12 09:31:40 --> Model Class Initialized
DEBUG - 2011-08-12 09:31:40 --> Model Class Initialized
DEBUG - 2011-08-12 09:31:40 --> Model Class Initialized
DEBUG - 2011-08-12 09:31:40 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-12 09:31:40 --> Database Driver Class Initialized
DEBUG - 2011-08-12 09:31:40 --> File loaded: application/views/table/main.php
DEBUG - 2011-08-12 09:31:40 --> Helper loaded: url_helper
DEBUG - 2011-08-12 09:31:40 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-12 09:31:40 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-12 09:31:40 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-12 09:31:40 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-12 09:31:40 --> Final output sent to browser
DEBUG - 2011-08-12 09:31:40 --> Total execution time: 0.0478
DEBUG - 2011-08-12 09:31:41 --> Config Class Initialized
DEBUG - 2011-08-12 09:31:41 --> Hooks Class Initialized
DEBUG - 2011-08-12 09:31:41 --> Utf8 Class Initialized
DEBUG - 2011-08-12 09:31:41 --> UTF-8 Support Enabled
DEBUG - 2011-08-12 09:31:41 --> URI Class Initialized
DEBUG - 2011-08-12 09:31:41 --> Router Class Initialized
DEBUG - 2011-08-12 09:31:41 --> Output Class Initialized
DEBUG - 2011-08-12 09:31:41 --> Input Class Initialized
DEBUG - 2011-08-12 09:31:41 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-12 09:31:41 --> Language Class Initialized
DEBUG - 2011-08-12 09:31:41 --> Loader Class Initialized
DEBUG - 2011-08-12 09:31:41 --> Controller Class Initialized
DEBUG - 2011-08-12 09:31:41 --> Model Class Initialized
DEBUG - 2011-08-12 09:31:41 --> Model Class Initialized
DEBUG - 2011-08-12 09:31:41 --> Model Class Initialized
DEBUG - 2011-08-12 09:31:41 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-12 09:31:41 --> Database Driver Class Initialized
DEBUG - 2011-08-12 09:31:41 --> File loaded: application/views/table/main.php
DEBUG - 2011-08-12 09:31:41 --> Helper loaded: url_helper
DEBUG - 2011-08-12 09:31:41 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-12 09:31:41 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-12 09:31:41 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-12 09:31:41 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-12 09:31:41 --> Final output sent to browser
DEBUG - 2011-08-12 09:31:41 --> Total execution time: 0.0513
DEBUG - 2011-08-12 09:31:41 --> Config Class Initialized
DEBUG - 2011-08-12 09:31:41 --> Hooks Class Initialized
DEBUG - 2011-08-12 09:31:41 --> Utf8 Class Initialized
DEBUG - 2011-08-12 09:31:41 --> UTF-8 Support Enabled
DEBUG - 2011-08-12 09:31:41 --> URI Class Initialized
DEBUG - 2011-08-12 09:31:41 --> Router Class Initialized
ERROR - 2011-08-12 09:31:41 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-08-12 09:32:24 --> Config Class Initialized
DEBUG - 2011-08-12 09:32:24 --> Hooks Class Initialized
DEBUG - 2011-08-12 09:32:24 --> Utf8 Class Initialized
DEBUG - 2011-08-12 09:32:24 --> UTF-8 Support Enabled
DEBUG - 2011-08-12 09:32:24 --> URI Class Initialized
DEBUG - 2011-08-12 09:32:24 --> Router Class Initialized
DEBUG - 2011-08-12 09:32:24 --> Output Class Initialized
DEBUG - 2011-08-12 09:32:24 --> Input Class Initialized
DEBUG - 2011-08-12 09:32:24 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-12 09:32:24 --> Language Class Initialized
DEBUG - 2011-08-12 09:32:24 --> Loader Class Initialized
DEBUG - 2011-08-12 09:32:24 --> Controller Class Initialized
DEBUG - 2011-08-12 09:32:24 --> Model Class Initialized
DEBUG - 2011-08-12 09:32:24 --> Model Class Initialized
DEBUG - 2011-08-12 09:32:24 --> Model Class Initialized
DEBUG - 2011-08-12 09:32:24 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-12 09:32:24 --> Database Driver Class Initialized
DEBUG - 2011-08-12 09:32:24 --> File loaded: application/views/table/main.php
DEBUG - 2011-08-12 09:32:25 --> Helper loaded: url_helper
DEBUG - 2011-08-12 09:32:25 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-12 09:32:25 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-12 09:32:25 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-12 09:32:25 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-12 09:32:25 --> Final output sent to browser
DEBUG - 2011-08-12 09:32:25 --> Total execution time: 0.3916
DEBUG - 2011-08-12 09:32:26 --> Config Class Initialized
DEBUG - 2011-08-12 09:32:26 --> Hooks Class Initialized
DEBUG - 2011-08-12 09:32:26 --> Utf8 Class Initialized
DEBUG - 2011-08-12 09:32:26 --> UTF-8 Support Enabled
DEBUG - 2011-08-12 09:32:26 --> URI Class Initialized
DEBUG - 2011-08-12 09:32:26 --> Router Class Initialized
DEBUG - 2011-08-12 09:32:26 --> Output Class Initialized
DEBUG - 2011-08-12 09:32:26 --> Input Class Initialized
DEBUG - 2011-08-12 09:32:26 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-12 09:32:26 --> Language Class Initialized
DEBUG - 2011-08-12 09:32:26 --> Loader Class Initialized
DEBUG - 2011-08-12 09:32:26 --> Controller Class Initialized
DEBUG - 2011-08-12 09:32:26 --> Model Class Initialized
DEBUG - 2011-08-12 09:32:26 --> Model Class Initialized
DEBUG - 2011-08-12 09:32:26 --> Model Class Initialized
DEBUG - 2011-08-12 09:32:26 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-12 09:32:26 --> Database Driver Class Initialized
DEBUG - 2011-08-12 09:32:26 --> File loaded: application/views/table/main.php
DEBUG - 2011-08-12 09:32:26 --> Helper loaded: url_helper
DEBUG - 2011-08-12 09:32:26 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-12 09:32:26 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-12 09:32:26 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-12 09:32:26 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-12 09:32:26 --> Final output sent to browser
DEBUG - 2011-08-12 09:32:26 --> Total execution time: 0.0458
DEBUG - 2011-08-12 09:32:27 --> Config Class Initialized
DEBUG - 2011-08-12 09:32:27 --> Hooks Class Initialized
DEBUG - 2011-08-12 09:32:27 --> Utf8 Class Initialized
DEBUG - 2011-08-12 09:32:27 --> UTF-8 Support Enabled
DEBUG - 2011-08-12 09:32:27 --> URI Class Initialized
DEBUG - 2011-08-12 09:32:27 --> Router Class Initialized
ERROR - 2011-08-12 09:32:27 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-08-12 09:33:01 --> Config Class Initialized
DEBUG - 2011-08-12 09:33:01 --> Hooks Class Initialized
DEBUG - 2011-08-12 09:33:01 --> Utf8 Class Initialized
DEBUG - 2011-08-12 09:33:01 --> UTF-8 Support Enabled
DEBUG - 2011-08-12 09:33:01 --> URI Class Initialized
DEBUG - 2011-08-12 09:33:01 --> Router Class Initialized
DEBUG - 2011-08-12 09:33:01 --> Output Class Initialized
DEBUG - 2011-08-12 09:33:01 --> Input Class Initialized
DEBUG - 2011-08-12 09:33:01 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-12 09:33:01 --> Language Class Initialized
DEBUG - 2011-08-12 09:33:01 --> Loader Class Initialized
DEBUG - 2011-08-12 09:33:01 --> Controller Class Initialized
ERROR - 2011-08-12 09:33:01 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-08-12 09:33:01 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-08-12 09:33:01 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-08-12 09:33:01 --> Model Class Initialized
DEBUG - 2011-08-12 09:33:01 --> Model Class Initialized
DEBUG - 2011-08-12 09:33:01 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-12 09:33:01 --> Database Driver Class Initialized
DEBUG - 2011-08-12 09:33:01 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-08-12 09:33:01 --> Helper loaded: url_helper
DEBUG - 2011-08-12 09:33:01 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-12 09:33:01 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-12 09:33:01 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-12 09:33:01 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-12 09:33:01 --> Final output sent to browser
DEBUG - 2011-08-12 09:33:01 --> Total execution time: 0.1344
DEBUG - 2011-08-12 09:33:02 --> Config Class Initialized
DEBUG - 2011-08-12 09:33:02 --> Hooks Class Initialized
DEBUG - 2011-08-12 09:33:02 --> Utf8 Class Initialized
DEBUG - 2011-08-12 09:33:02 --> UTF-8 Support Enabled
DEBUG - 2011-08-12 09:33:02 --> URI Class Initialized
DEBUG - 2011-08-12 09:33:02 --> Router Class Initialized
DEBUG - 2011-08-12 09:33:02 --> Output Class Initialized
DEBUG - 2011-08-12 09:33:02 --> Input Class Initialized
DEBUG - 2011-08-12 09:33:02 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-12 09:33:02 --> Language Class Initialized
DEBUG - 2011-08-12 09:33:02 --> Loader Class Initialized
DEBUG - 2011-08-12 09:33:02 --> Controller Class Initialized
DEBUG - 2011-08-12 09:33:02 --> Model Class Initialized
DEBUG - 2011-08-12 09:33:02 --> Model Class Initialized
DEBUG - 2011-08-12 09:33:02 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-12 09:33:02 --> Database Driver Class Initialized
DEBUG - 2011-08-12 09:33:03 --> Final output sent to browser
DEBUG - 2011-08-12 09:33:03 --> Total execution time: 0.8566
DEBUG - 2011-08-12 09:33:04 --> Config Class Initialized
DEBUG - 2011-08-12 09:33:04 --> Hooks Class Initialized
DEBUG - 2011-08-12 09:33:04 --> Utf8 Class Initialized
DEBUG - 2011-08-12 09:33:04 --> UTF-8 Support Enabled
DEBUG - 2011-08-12 09:33:04 --> URI Class Initialized
DEBUG - 2011-08-12 09:33:04 --> Router Class Initialized
ERROR - 2011-08-12 09:33:04 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-08-12 09:33:53 --> Config Class Initialized
DEBUG - 2011-08-12 09:33:53 --> Hooks Class Initialized
DEBUG - 2011-08-12 09:33:53 --> Utf8 Class Initialized
DEBUG - 2011-08-12 09:33:53 --> UTF-8 Support Enabled
DEBUG - 2011-08-12 09:33:53 --> URI Class Initialized
DEBUG - 2011-08-12 09:33:53 --> Router Class Initialized
DEBUG - 2011-08-12 09:33:53 --> Output Class Initialized
DEBUG - 2011-08-12 09:33:53 --> Input Class Initialized
DEBUG - 2011-08-12 09:33:53 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-12 09:33:53 --> Language Class Initialized
DEBUG - 2011-08-12 09:33:53 --> Loader Class Initialized
DEBUG - 2011-08-12 09:33:53 --> Controller Class Initialized
ERROR - 2011-08-12 09:33:53 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-08-12 09:33:53 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-08-12 09:33:53 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-08-12 09:33:53 --> Model Class Initialized
DEBUG - 2011-08-12 09:33:53 --> Model Class Initialized
DEBUG - 2011-08-12 09:33:53 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-12 09:33:53 --> Database Driver Class Initialized
DEBUG - 2011-08-12 09:33:53 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-08-12 09:33:53 --> Helper loaded: url_helper
DEBUG - 2011-08-12 09:33:53 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-12 09:33:53 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-12 09:33:53 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-12 09:33:53 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-12 09:33:53 --> Final output sent to browser
DEBUG - 2011-08-12 09:33:53 --> Total execution time: 0.0267
DEBUG - 2011-08-12 09:33:54 --> Config Class Initialized
DEBUG - 2011-08-12 09:33:54 --> Hooks Class Initialized
DEBUG - 2011-08-12 09:33:54 --> Utf8 Class Initialized
DEBUG - 2011-08-12 09:33:54 --> UTF-8 Support Enabled
DEBUG - 2011-08-12 09:33:54 --> URI Class Initialized
DEBUG - 2011-08-12 09:33:54 --> Router Class Initialized
DEBUG - 2011-08-12 09:33:54 --> Output Class Initialized
DEBUG - 2011-08-12 09:33:54 --> Input Class Initialized
DEBUG - 2011-08-12 09:33:54 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-12 09:33:54 --> Language Class Initialized
DEBUG - 2011-08-12 09:33:54 --> Loader Class Initialized
DEBUG - 2011-08-12 09:33:54 --> Controller Class Initialized
DEBUG - 2011-08-12 09:33:54 --> Model Class Initialized
DEBUG - 2011-08-12 09:33:54 --> Model Class Initialized
DEBUG - 2011-08-12 09:33:54 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-12 09:33:54 --> Database Driver Class Initialized
DEBUG - 2011-08-12 09:33:54 --> Final output sent to browser
DEBUG - 2011-08-12 09:33:54 --> Total execution time: 0.5943
DEBUG - 2011-08-12 09:33:55 --> Config Class Initialized
DEBUG - 2011-08-12 09:33:55 --> Hooks Class Initialized
DEBUG - 2011-08-12 09:33:55 --> Utf8 Class Initialized
DEBUG - 2011-08-12 09:33:55 --> UTF-8 Support Enabled
DEBUG - 2011-08-12 09:33:55 --> URI Class Initialized
DEBUG - 2011-08-12 09:33:55 --> Router Class Initialized
ERROR - 2011-08-12 09:33:55 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-08-12 09:34:07 --> Config Class Initialized
DEBUG - 2011-08-12 09:34:07 --> Hooks Class Initialized
DEBUG - 2011-08-12 09:34:07 --> Utf8 Class Initialized
DEBUG - 2011-08-12 09:34:07 --> UTF-8 Support Enabled
DEBUG - 2011-08-12 09:34:07 --> URI Class Initialized
DEBUG - 2011-08-12 09:34:07 --> Router Class Initialized
DEBUG - 2011-08-12 09:34:07 --> Output Class Initialized
DEBUG - 2011-08-12 09:34:07 --> Input Class Initialized
DEBUG - 2011-08-12 09:34:07 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-12 09:34:07 --> Language Class Initialized
DEBUG - 2011-08-12 09:34:07 --> Loader Class Initialized
DEBUG - 2011-08-12 09:34:07 --> Controller Class Initialized
ERROR - 2011-08-12 09:34:07 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-08-12 09:34:07 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-08-12 09:34:07 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-08-12 09:34:07 --> Model Class Initialized
DEBUG - 2011-08-12 09:34:07 --> Model Class Initialized
DEBUG - 2011-08-12 09:34:07 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-12 09:34:08 --> Database Driver Class Initialized
DEBUG - 2011-08-12 09:34:08 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-08-12 09:34:08 --> Helper loaded: url_helper
DEBUG - 2011-08-12 09:34:08 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-12 09:34:08 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-12 09:34:08 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-12 09:34:08 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-12 09:34:08 --> Final output sent to browser
DEBUG - 2011-08-12 09:34:08 --> Total execution time: 0.0371
DEBUG - 2011-08-12 09:34:12 --> Config Class Initialized
DEBUG - 2011-08-12 09:34:12 --> Hooks Class Initialized
DEBUG - 2011-08-12 09:34:12 --> Utf8 Class Initialized
DEBUG - 2011-08-12 09:34:12 --> UTF-8 Support Enabled
DEBUG - 2011-08-12 09:34:12 --> URI Class Initialized
DEBUG - 2011-08-12 09:34:12 --> Router Class Initialized
DEBUG - 2011-08-12 09:34:12 --> Output Class Initialized
DEBUG - 2011-08-12 09:34:12 --> Input Class Initialized
DEBUG - 2011-08-12 09:34:12 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-12 09:34:12 --> Language Class Initialized
DEBUG - 2011-08-12 09:34:12 --> Loader Class Initialized
DEBUG - 2011-08-12 09:34:12 --> Controller Class Initialized
DEBUG - 2011-08-12 09:34:12 --> Model Class Initialized
DEBUG - 2011-08-12 09:34:12 --> Model Class Initialized
DEBUG - 2011-08-12 09:34:12 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-12 09:34:12 --> Database Driver Class Initialized
DEBUG - 2011-08-12 09:34:12 --> Final output sent to browser
DEBUG - 2011-08-12 09:34:12 --> Total execution time: 0.6360
DEBUG - 2011-08-12 09:34:14 --> Config Class Initialized
DEBUG - 2011-08-12 09:34:14 --> Hooks Class Initialized
DEBUG - 2011-08-12 09:34:14 --> Utf8 Class Initialized
DEBUG - 2011-08-12 09:34:14 --> UTF-8 Support Enabled
DEBUG - 2011-08-12 09:34:14 --> URI Class Initialized
DEBUG - 2011-08-12 09:34:14 --> Router Class Initialized
ERROR - 2011-08-12 09:34:14 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-08-12 09:34:31 --> Config Class Initialized
DEBUG - 2011-08-12 09:34:31 --> Hooks Class Initialized
DEBUG - 2011-08-12 09:34:31 --> Utf8 Class Initialized
DEBUG - 2011-08-12 09:34:31 --> UTF-8 Support Enabled
DEBUG - 2011-08-12 09:34:31 --> URI Class Initialized
DEBUG - 2011-08-12 09:34:31 --> Router Class Initialized
DEBUG - 2011-08-12 09:34:31 --> Output Class Initialized
DEBUG - 2011-08-12 09:34:31 --> Input Class Initialized
DEBUG - 2011-08-12 09:34:31 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-12 09:34:31 --> Language Class Initialized
DEBUG - 2011-08-12 09:34:31 --> Loader Class Initialized
DEBUG - 2011-08-12 09:34:31 --> Controller Class Initialized
ERROR - 2011-08-12 09:34:31 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-08-12 09:34:31 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-08-12 09:34:31 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-08-12 09:34:31 --> Model Class Initialized
DEBUG - 2011-08-12 09:34:31 --> Model Class Initialized
DEBUG - 2011-08-12 09:34:31 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-12 09:34:31 --> Database Driver Class Initialized
DEBUG - 2011-08-12 09:34:31 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-08-12 09:34:31 --> Helper loaded: url_helper
DEBUG - 2011-08-12 09:34:31 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-12 09:34:31 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-12 09:34:31 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-12 09:34:31 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-12 09:34:31 --> Final output sent to browser
DEBUG - 2011-08-12 09:34:31 --> Total execution time: 0.1947
DEBUG - 2011-08-12 09:34:32 --> Config Class Initialized
DEBUG - 2011-08-12 09:34:32 --> Hooks Class Initialized
DEBUG - 2011-08-12 09:34:32 --> Utf8 Class Initialized
DEBUG - 2011-08-12 09:34:32 --> UTF-8 Support Enabled
DEBUG - 2011-08-12 09:34:32 --> URI Class Initialized
DEBUG - 2011-08-12 09:34:32 --> Router Class Initialized
DEBUG - 2011-08-12 09:34:32 --> Output Class Initialized
DEBUG - 2011-08-12 09:34:32 --> Input Class Initialized
DEBUG - 2011-08-12 09:34:32 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-12 09:34:32 --> Language Class Initialized
DEBUG - 2011-08-12 09:34:32 --> Loader Class Initialized
DEBUG - 2011-08-12 09:34:32 --> Controller Class Initialized
DEBUG - 2011-08-12 09:34:32 --> Model Class Initialized
DEBUG - 2011-08-12 09:34:32 --> Model Class Initialized
DEBUG - 2011-08-12 09:34:32 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-12 09:34:32 --> Database Driver Class Initialized
DEBUG - 2011-08-12 09:34:32 --> Config Class Initialized
DEBUG - 2011-08-12 09:34:32 --> Hooks Class Initialized
DEBUG - 2011-08-12 09:34:32 --> Utf8 Class Initialized
DEBUG - 2011-08-12 09:34:32 --> UTF-8 Support Enabled
DEBUG - 2011-08-12 09:34:32 --> URI Class Initialized
DEBUG - 2011-08-12 09:34:32 --> Router Class Initialized
DEBUG - 2011-08-12 09:34:32 --> Output Class Initialized
DEBUG - 2011-08-12 09:34:32 --> Input Class Initialized
DEBUG - 2011-08-12 09:34:32 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-12 09:34:32 --> Language Class Initialized
DEBUG - 2011-08-12 09:34:32 --> Loader Class Initialized
DEBUG - 2011-08-12 09:34:32 --> Controller Class Initialized
ERROR - 2011-08-12 09:34:32 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-08-12 09:34:32 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-08-12 09:34:32 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-08-12 09:34:32 --> Model Class Initialized
DEBUG - 2011-08-12 09:34:32 --> Model Class Initialized
DEBUG - 2011-08-12 09:34:32 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-12 09:34:32 --> Database Driver Class Initialized
DEBUG - 2011-08-12 09:34:32 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-08-12 09:34:32 --> Helper loaded: url_helper
DEBUG - 2011-08-12 09:34:32 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-12 09:34:32 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-12 09:34:32 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-12 09:34:32 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-12 09:34:32 --> Final output sent to browser
DEBUG - 2011-08-12 09:34:32 --> Total execution time: 0.0612
DEBUG - 2011-08-12 09:34:32 --> Final output sent to browser
DEBUG - 2011-08-12 09:34:32 --> Total execution time: 0.6921
DEBUG - 2011-08-12 09:34:33 --> Config Class Initialized
DEBUG - 2011-08-12 09:34:33 --> Hooks Class Initialized
DEBUG - 2011-08-12 09:34:33 --> Utf8 Class Initialized
DEBUG - 2011-08-12 09:34:33 --> UTF-8 Support Enabled
DEBUG - 2011-08-12 09:34:33 --> URI Class Initialized
DEBUG - 2011-08-12 09:34:33 --> Router Class Initialized
ERROR - 2011-08-12 09:34:33 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-08-12 10:11:10 --> Config Class Initialized
DEBUG - 2011-08-12 10:11:10 --> Hooks Class Initialized
DEBUG - 2011-08-12 10:11:10 --> Utf8 Class Initialized
DEBUG - 2011-08-12 10:11:10 --> UTF-8 Support Enabled
DEBUG - 2011-08-12 10:11:10 --> URI Class Initialized
DEBUG - 2011-08-12 10:11:10 --> Router Class Initialized
DEBUG - 2011-08-12 10:11:10 --> Output Class Initialized
DEBUG - 2011-08-12 10:11:10 --> Input Class Initialized
DEBUG - 2011-08-12 10:11:10 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-12 10:11:10 --> Language Class Initialized
DEBUG - 2011-08-12 10:11:10 --> Loader Class Initialized
DEBUG - 2011-08-12 10:11:10 --> Controller Class Initialized
DEBUG - 2011-08-12 10:11:10 --> Model Class Initialized
DEBUG - 2011-08-12 10:11:10 --> Model Class Initialized
DEBUG - 2011-08-12 10:11:10 --> Model Class Initialized
DEBUG - 2011-08-12 10:11:10 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-12 10:11:10 --> Database Driver Class Initialized
DEBUG - 2011-08-12 10:11:10 --> File loaded: application/views/table/main.php
DEBUG - 2011-08-12 10:11:10 --> Helper loaded: url_helper
DEBUG - 2011-08-12 10:11:10 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-12 10:11:10 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-12 10:11:10 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-12 10:11:10 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-12 10:11:10 --> Final output sent to browser
DEBUG - 2011-08-12 10:11:10 --> Total execution time: 0.3065
DEBUG - 2011-08-12 10:18:04 --> Config Class Initialized
DEBUG - 2011-08-12 10:18:04 --> Hooks Class Initialized
DEBUG - 2011-08-12 10:18:04 --> Utf8 Class Initialized
DEBUG - 2011-08-12 10:18:04 --> UTF-8 Support Enabled
DEBUG - 2011-08-12 10:18:04 --> URI Class Initialized
DEBUG - 2011-08-12 10:18:04 --> Router Class Initialized
DEBUG - 2011-08-12 10:18:04 --> Output Class Initialized
DEBUG - 2011-08-12 10:18:04 --> Input Class Initialized
DEBUG - 2011-08-12 10:18:04 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-12 10:18:04 --> Language Class Initialized
DEBUG - 2011-08-12 10:18:04 --> Loader Class Initialized
DEBUG - 2011-08-12 10:18:04 --> Controller Class Initialized
DEBUG - 2011-08-12 10:18:04 --> Model Class Initialized
DEBUG - 2011-08-12 10:18:04 --> Model Class Initialized
DEBUG - 2011-08-12 10:18:04 --> Model Class Initialized
DEBUG - 2011-08-12 10:18:04 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-12 10:18:04 --> Database Driver Class Initialized
DEBUG - 2011-08-12 10:18:04 --> File loaded: application/views/table/main.php
DEBUG - 2011-08-12 10:18:04 --> Helper loaded: url_helper
DEBUG - 2011-08-12 10:18:04 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-12 10:18:04 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-12 10:18:04 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-12 10:18:04 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-12 10:18:04 --> Final output sent to browser
DEBUG - 2011-08-12 10:18:04 --> Total execution time: 0.0617
DEBUG - 2011-08-12 10:33:25 --> Config Class Initialized
DEBUG - 2011-08-12 10:33:25 --> Hooks Class Initialized
DEBUG - 2011-08-12 10:33:25 --> Utf8 Class Initialized
DEBUG - 2011-08-12 10:33:25 --> UTF-8 Support Enabled
DEBUG - 2011-08-12 10:33:25 --> URI Class Initialized
DEBUG - 2011-08-12 10:33:25 --> Router Class Initialized
DEBUG - 2011-08-12 10:33:25 --> Output Class Initialized
DEBUG - 2011-08-12 10:33:25 --> Input Class Initialized
DEBUG - 2011-08-12 10:33:25 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-12 10:33:25 --> Language Class Initialized
DEBUG - 2011-08-12 10:33:25 --> Loader Class Initialized
DEBUG - 2011-08-12 10:33:25 --> Controller Class Initialized
ERROR - 2011-08-12 10:33:25 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-08-12 10:33:25 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-08-12 10:33:25 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-08-12 10:33:25 --> Model Class Initialized
DEBUG - 2011-08-12 10:33:25 --> Model Class Initialized
DEBUG - 2011-08-12 10:33:25 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-12 10:33:25 --> Database Driver Class Initialized
DEBUG - 2011-08-12 10:33:25 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-08-12 10:33:25 --> Helper loaded: url_helper
DEBUG - 2011-08-12 10:33:25 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-12 10:33:25 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-12 10:33:25 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-12 10:33:25 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-12 10:33:25 --> Final output sent to browser
DEBUG - 2011-08-12 10:33:25 --> Total execution time: 0.0984
DEBUG - 2011-08-12 10:33:26 --> Config Class Initialized
DEBUG - 2011-08-12 10:33:26 --> Hooks Class Initialized
DEBUG - 2011-08-12 10:33:26 --> Utf8 Class Initialized
DEBUG - 2011-08-12 10:33:26 --> UTF-8 Support Enabled
DEBUG - 2011-08-12 10:33:26 --> URI Class Initialized
DEBUG - 2011-08-12 10:33:26 --> Router Class Initialized
DEBUG - 2011-08-12 10:33:26 --> Output Class Initialized
DEBUG - 2011-08-12 10:33:26 --> Input Class Initialized
DEBUG - 2011-08-12 10:33:26 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-12 10:33:26 --> Language Class Initialized
DEBUG - 2011-08-12 10:33:26 --> Loader Class Initialized
DEBUG - 2011-08-12 10:33:26 --> Controller Class Initialized
DEBUG - 2011-08-12 10:33:26 --> Model Class Initialized
DEBUG - 2011-08-12 10:33:26 --> Model Class Initialized
DEBUG - 2011-08-12 10:33:26 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-12 10:33:26 --> Database Driver Class Initialized
DEBUG - 2011-08-12 10:33:28 --> Final output sent to browser
DEBUG - 2011-08-12 10:33:28 --> Total execution time: 1.1844
DEBUG - 2011-08-12 10:33:30 --> Config Class Initialized
DEBUG - 2011-08-12 10:33:30 --> Hooks Class Initialized
DEBUG - 2011-08-12 10:33:30 --> Utf8 Class Initialized
DEBUG - 2011-08-12 10:33:30 --> UTF-8 Support Enabled
DEBUG - 2011-08-12 10:33:30 --> URI Class Initialized
DEBUG - 2011-08-12 10:33:30 --> Router Class Initialized
ERROR - 2011-08-12 10:33:30 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-08-12 10:33:31 --> Config Class Initialized
DEBUG - 2011-08-12 10:33:31 --> Hooks Class Initialized
DEBUG - 2011-08-12 10:33:31 --> Utf8 Class Initialized
DEBUG - 2011-08-12 10:33:31 --> UTF-8 Support Enabled
DEBUG - 2011-08-12 10:33:31 --> URI Class Initialized
DEBUG - 2011-08-12 10:33:31 --> Router Class Initialized
ERROR - 2011-08-12 10:33:31 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-08-12 10:33:31 --> Config Class Initialized
DEBUG - 2011-08-12 10:33:31 --> Hooks Class Initialized
DEBUG - 2011-08-12 10:33:31 --> Utf8 Class Initialized
DEBUG - 2011-08-12 10:33:31 --> UTF-8 Support Enabled
DEBUG - 2011-08-12 10:33:31 --> URI Class Initialized
DEBUG - 2011-08-12 10:33:31 --> Router Class Initialized
ERROR - 2011-08-12 10:33:31 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-08-12 10:34:03 --> Config Class Initialized
DEBUG - 2011-08-12 10:34:03 --> Hooks Class Initialized
DEBUG - 2011-08-12 10:34:03 --> Utf8 Class Initialized
DEBUG - 2011-08-12 10:34:03 --> UTF-8 Support Enabled
DEBUG - 2011-08-12 10:34:03 --> URI Class Initialized
DEBUG - 2011-08-12 10:34:03 --> Router Class Initialized
DEBUG - 2011-08-12 10:34:03 --> Output Class Initialized
DEBUG - 2011-08-12 10:34:03 --> Input Class Initialized
DEBUG - 2011-08-12 10:34:03 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-12 10:34:03 --> Language Class Initialized
DEBUG - 2011-08-12 10:34:03 --> Loader Class Initialized
DEBUG - 2011-08-12 10:34:03 --> Controller Class Initialized
ERROR - 2011-08-12 10:34:03 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-08-12 10:34:03 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-08-12 10:34:03 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-08-12 10:34:03 --> Model Class Initialized
DEBUG - 2011-08-12 10:34:03 --> Model Class Initialized
DEBUG - 2011-08-12 10:34:03 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-12 10:34:03 --> Database Driver Class Initialized
DEBUG - 2011-08-12 10:34:03 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-08-12 10:34:03 --> Helper loaded: url_helper
DEBUG - 2011-08-12 10:34:03 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-12 10:34:03 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-12 10:34:03 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-12 10:34:03 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-12 10:34:03 --> Final output sent to browser
DEBUG - 2011-08-12 10:34:03 --> Total execution time: 0.0293
DEBUG - 2011-08-12 10:34:04 --> Config Class Initialized
DEBUG - 2011-08-12 10:34:04 --> Hooks Class Initialized
DEBUG - 2011-08-12 10:34:04 --> Utf8 Class Initialized
DEBUG - 2011-08-12 10:34:04 --> UTF-8 Support Enabled
DEBUG - 2011-08-12 10:34:04 --> URI Class Initialized
DEBUG - 2011-08-12 10:34:04 --> Router Class Initialized
DEBUG - 2011-08-12 10:34:04 --> Output Class Initialized
DEBUG - 2011-08-12 10:34:04 --> Input Class Initialized
DEBUG - 2011-08-12 10:34:04 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-12 10:34:04 --> Language Class Initialized
DEBUG - 2011-08-12 10:34:04 --> Loader Class Initialized
DEBUG - 2011-08-12 10:34:04 --> Controller Class Initialized
DEBUG - 2011-08-12 10:34:04 --> Model Class Initialized
DEBUG - 2011-08-12 10:34:04 --> Model Class Initialized
DEBUG - 2011-08-12 10:34:04 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-12 10:34:04 --> Database Driver Class Initialized
DEBUG - 2011-08-12 10:34:04 --> Final output sent to browser
DEBUG - 2011-08-12 10:34:04 --> Total execution time: 0.5568
DEBUG - 2011-08-12 10:34:17 --> Config Class Initialized
DEBUG - 2011-08-12 10:34:17 --> Hooks Class Initialized
DEBUG - 2011-08-12 10:34:17 --> Utf8 Class Initialized
DEBUG - 2011-08-12 10:34:17 --> UTF-8 Support Enabled
DEBUG - 2011-08-12 10:34:17 --> URI Class Initialized
DEBUG - 2011-08-12 10:34:17 --> Router Class Initialized
DEBUG - 2011-08-12 10:34:17 --> Output Class Initialized
DEBUG - 2011-08-12 10:34:17 --> Input Class Initialized
DEBUG - 2011-08-12 10:34:17 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-12 10:34:17 --> Language Class Initialized
DEBUG - 2011-08-12 10:34:17 --> Loader Class Initialized
DEBUG - 2011-08-12 10:34:17 --> Controller Class Initialized
ERROR - 2011-08-12 10:34:17 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-08-12 10:34:17 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-08-12 10:34:17 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-08-12 10:34:17 --> Model Class Initialized
DEBUG - 2011-08-12 10:34:17 --> Model Class Initialized
DEBUG - 2011-08-12 10:34:17 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-12 10:34:17 --> Database Driver Class Initialized
DEBUG - 2011-08-12 10:34:17 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-08-12 10:34:17 --> Helper loaded: url_helper
DEBUG - 2011-08-12 10:34:17 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-12 10:34:17 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-12 10:34:17 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-12 10:34:17 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-12 10:34:17 --> Final output sent to browser
DEBUG - 2011-08-12 10:34:17 --> Total execution time: 0.0279
DEBUG - 2011-08-12 10:34:18 --> Config Class Initialized
DEBUG - 2011-08-12 10:34:18 --> Hooks Class Initialized
DEBUG - 2011-08-12 10:34:18 --> Utf8 Class Initialized
DEBUG - 2011-08-12 10:34:18 --> UTF-8 Support Enabled
DEBUG - 2011-08-12 10:34:18 --> URI Class Initialized
DEBUG - 2011-08-12 10:34:18 --> Router Class Initialized
DEBUG - 2011-08-12 10:34:18 --> Output Class Initialized
DEBUG - 2011-08-12 10:34:18 --> Input Class Initialized
DEBUG - 2011-08-12 10:34:18 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-12 10:34:18 --> Language Class Initialized
DEBUG - 2011-08-12 10:34:18 --> Loader Class Initialized
DEBUG - 2011-08-12 10:34:18 --> Controller Class Initialized
DEBUG - 2011-08-12 10:34:18 --> Model Class Initialized
DEBUG - 2011-08-12 10:34:18 --> Model Class Initialized
DEBUG - 2011-08-12 10:34:18 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-12 10:34:18 --> Database Driver Class Initialized
DEBUG - 2011-08-12 10:34:19 --> Final output sent to browser
DEBUG - 2011-08-12 10:34:19 --> Total execution time: 0.8657
DEBUG - 2011-08-12 10:34:19 --> Config Class Initialized
DEBUG - 2011-08-12 10:34:19 --> Hooks Class Initialized
DEBUG - 2011-08-12 10:34:19 --> Utf8 Class Initialized
DEBUG - 2011-08-12 10:34:19 --> UTF-8 Support Enabled
DEBUG - 2011-08-12 10:34:19 --> URI Class Initialized
DEBUG - 2011-08-12 10:34:19 --> Router Class Initialized
DEBUG - 2011-08-12 10:34:19 --> Output Class Initialized
DEBUG - 2011-08-12 10:34:19 --> Input Class Initialized
DEBUG - 2011-08-12 10:34:19 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-12 10:34:19 --> Language Class Initialized
DEBUG - 2011-08-12 10:34:19 --> Loader Class Initialized
DEBUG - 2011-08-12 10:34:19 --> Controller Class Initialized
ERROR - 2011-08-12 10:34:19 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-08-12 10:34:19 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-08-12 10:34:19 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-08-12 10:34:19 --> Model Class Initialized
DEBUG - 2011-08-12 10:34:19 --> Model Class Initialized
DEBUG - 2011-08-12 10:34:19 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-12 10:34:19 --> Database Driver Class Initialized
DEBUG - 2011-08-12 10:34:19 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-08-12 10:34:19 --> Helper loaded: url_helper
DEBUG - 2011-08-12 10:34:19 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-12 10:34:19 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-12 10:34:19 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-12 10:34:19 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-12 10:34:19 --> Final output sent to browser
DEBUG - 2011-08-12 10:34:19 --> Total execution time: 0.0280
DEBUG - 2011-08-12 10:35:20 --> Config Class Initialized
DEBUG - 2011-08-12 10:35:20 --> Hooks Class Initialized
DEBUG - 2011-08-12 10:35:20 --> Utf8 Class Initialized
DEBUG - 2011-08-12 10:35:20 --> UTF-8 Support Enabled
DEBUG - 2011-08-12 10:35:20 --> URI Class Initialized
DEBUG - 2011-08-12 10:35:20 --> Router Class Initialized
DEBUG - 2011-08-12 10:35:20 --> Output Class Initialized
DEBUG - 2011-08-12 10:35:20 --> Input Class Initialized
DEBUG - 2011-08-12 10:35:20 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-12 10:35:20 --> Language Class Initialized
DEBUG - 2011-08-12 10:35:20 --> Loader Class Initialized
DEBUG - 2011-08-12 10:35:20 --> Controller Class Initialized
ERROR - 2011-08-12 10:35:20 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-08-12 10:35:20 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-08-12 10:35:20 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-08-12 10:35:20 --> Model Class Initialized
DEBUG - 2011-08-12 10:35:20 --> Model Class Initialized
DEBUG - 2011-08-12 10:35:20 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-12 10:35:20 --> Database Driver Class Initialized
DEBUG - 2011-08-12 10:35:20 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-08-12 10:35:20 --> Helper loaded: url_helper
DEBUG - 2011-08-12 10:35:20 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-12 10:35:20 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-12 10:35:20 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-12 10:35:20 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-12 10:35:20 --> Final output sent to browser
DEBUG - 2011-08-12 10:35:20 --> Total execution time: 0.0380
DEBUG - 2011-08-12 10:35:21 --> Config Class Initialized
DEBUG - 2011-08-12 10:35:21 --> Hooks Class Initialized
DEBUG - 2011-08-12 10:35:21 --> Utf8 Class Initialized
DEBUG - 2011-08-12 10:35:21 --> UTF-8 Support Enabled
DEBUG - 2011-08-12 10:35:21 --> URI Class Initialized
DEBUG - 2011-08-12 10:35:21 --> Router Class Initialized
DEBUG - 2011-08-12 10:35:21 --> Output Class Initialized
DEBUG - 2011-08-12 10:35:21 --> Input Class Initialized
DEBUG - 2011-08-12 10:35:21 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-12 10:35:21 --> Language Class Initialized
DEBUG - 2011-08-12 10:35:21 --> Loader Class Initialized
DEBUG - 2011-08-12 10:35:21 --> Controller Class Initialized
DEBUG - 2011-08-12 10:35:21 --> Model Class Initialized
DEBUG - 2011-08-12 10:35:21 --> Model Class Initialized
DEBUG - 2011-08-12 10:35:21 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-12 10:35:21 --> Database Driver Class Initialized
DEBUG - 2011-08-12 10:35:21 --> Final output sent to browser
DEBUG - 2011-08-12 10:35:21 --> Total execution time: 0.5112
DEBUG - 2011-08-12 10:36:12 --> Config Class Initialized
DEBUG - 2011-08-12 10:36:12 --> Hooks Class Initialized
DEBUG - 2011-08-12 10:36:12 --> Utf8 Class Initialized
DEBUG - 2011-08-12 10:36:12 --> UTF-8 Support Enabled
DEBUG - 2011-08-12 10:36:12 --> URI Class Initialized
DEBUG - 2011-08-12 10:36:12 --> Router Class Initialized
DEBUG - 2011-08-12 10:36:12 --> Output Class Initialized
DEBUG - 2011-08-12 10:36:12 --> Input Class Initialized
DEBUG - 2011-08-12 10:36:12 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-12 10:36:12 --> Language Class Initialized
DEBUG - 2011-08-12 10:36:12 --> Loader Class Initialized
DEBUG - 2011-08-12 10:36:12 --> Controller Class Initialized
ERROR - 2011-08-12 10:36:12 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-08-12 10:36:12 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-08-12 10:36:12 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-08-12 10:36:12 --> Model Class Initialized
DEBUG - 2011-08-12 10:36:12 --> Model Class Initialized
DEBUG - 2011-08-12 10:36:12 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-12 10:36:12 --> Database Driver Class Initialized
DEBUG - 2011-08-12 10:36:12 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-08-12 10:36:12 --> Helper loaded: url_helper
DEBUG - 2011-08-12 10:36:12 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-12 10:36:12 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-12 10:36:12 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-12 10:36:12 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-12 10:36:12 --> Final output sent to browser
DEBUG - 2011-08-12 10:36:12 --> Total execution time: 0.0319
DEBUG - 2011-08-12 10:36:30 --> Config Class Initialized
DEBUG - 2011-08-12 10:36:30 --> Hooks Class Initialized
DEBUG - 2011-08-12 10:36:30 --> Utf8 Class Initialized
DEBUG - 2011-08-12 10:36:30 --> UTF-8 Support Enabled
DEBUG - 2011-08-12 10:36:30 --> URI Class Initialized
DEBUG - 2011-08-12 10:36:30 --> Router Class Initialized
DEBUG - 2011-08-12 10:36:30 --> Output Class Initialized
DEBUG - 2011-08-12 10:36:30 --> Input Class Initialized
DEBUG - 2011-08-12 10:36:30 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-12 10:36:30 --> Language Class Initialized
DEBUG - 2011-08-12 10:36:30 --> Loader Class Initialized
DEBUG - 2011-08-12 10:36:30 --> Controller Class Initialized
DEBUG - 2011-08-12 10:36:30 --> Model Class Initialized
DEBUG - 2011-08-12 10:36:30 --> Model Class Initialized
DEBUG - 2011-08-12 10:36:30 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-12 10:36:30 --> Database Driver Class Initialized
DEBUG - 2011-08-12 10:36:30 --> Final output sent to browser
DEBUG - 2011-08-12 10:36:30 --> Total execution time: 0.6204
DEBUG - 2011-08-12 11:16:40 --> Config Class Initialized
DEBUG - 2011-08-12 11:16:40 --> Hooks Class Initialized
DEBUG - 2011-08-12 11:16:40 --> Utf8 Class Initialized
DEBUG - 2011-08-12 11:16:40 --> UTF-8 Support Enabled
DEBUG - 2011-08-12 11:16:40 --> URI Class Initialized
DEBUG - 2011-08-12 11:16:40 --> Router Class Initialized
DEBUG - 2011-08-12 11:16:40 --> Output Class Initialized
DEBUG - 2011-08-12 11:16:40 --> Input Class Initialized
DEBUG - 2011-08-12 11:16:40 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-12 11:16:40 --> Language Class Initialized
DEBUG - 2011-08-12 11:16:40 --> Loader Class Initialized
DEBUG - 2011-08-12 11:16:40 --> Controller Class Initialized
DEBUG - 2011-08-12 11:16:40 --> Model Class Initialized
DEBUG - 2011-08-12 11:16:40 --> Model Class Initialized
DEBUG - 2011-08-12 11:16:40 --> Model Class Initialized
DEBUG - 2011-08-12 11:16:40 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-12 11:16:40 --> Database Driver Class Initialized
DEBUG - 2011-08-12 11:16:40 --> File loaded: application/views/table/main.php
DEBUG - 2011-08-12 11:16:40 --> Helper loaded: url_helper
DEBUG - 2011-08-12 11:16:40 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-12 11:16:40 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-12 11:16:40 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-12 11:16:40 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-12 11:16:40 --> Final output sent to browser
DEBUG - 2011-08-12 11:16:40 --> Total execution time: 0.3828
DEBUG - 2011-08-12 11:16:42 --> Config Class Initialized
DEBUG - 2011-08-12 11:16:42 --> Hooks Class Initialized
DEBUG - 2011-08-12 11:16:42 --> Utf8 Class Initialized
DEBUG - 2011-08-12 11:16:42 --> UTF-8 Support Enabled
DEBUG - 2011-08-12 11:16:42 --> URI Class Initialized
DEBUG - 2011-08-12 11:16:42 --> Router Class Initialized
ERROR - 2011-08-12 11:16:42 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-08-12 11:16:49 --> Config Class Initialized
DEBUG - 2011-08-12 11:16:49 --> Hooks Class Initialized
DEBUG - 2011-08-12 11:16:49 --> Utf8 Class Initialized
DEBUG - 2011-08-12 11:16:49 --> UTF-8 Support Enabled
DEBUG - 2011-08-12 11:16:49 --> URI Class Initialized
DEBUG - 2011-08-12 11:16:49 --> Router Class Initialized
DEBUG - 2011-08-12 11:16:49 --> Output Class Initialized
DEBUG - 2011-08-12 11:16:49 --> Input Class Initialized
DEBUG - 2011-08-12 11:16:49 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-12 11:16:49 --> Language Class Initialized
DEBUG - 2011-08-12 11:16:49 --> Loader Class Initialized
DEBUG - 2011-08-12 11:16:49 --> Controller Class Initialized
DEBUG - 2011-08-12 11:16:49 --> Model Class Initialized
DEBUG - 2011-08-12 11:16:49 --> Model Class Initialized
DEBUG - 2011-08-12 11:16:49 --> Model Class Initialized
DEBUG - 2011-08-12 11:16:49 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-12 11:16:49 --> Database Driver Class Initialized
DEBUG - 2011-08-12 11:16:49 --> File loaded: application/views/table/main.php
DEBUG - 2011-08-12 11:16:49 --> Helper loaded: url_helper
DEBUG - 2011-08-12 11:16:49 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-12 11:16:49 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-12 11:16:49 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-12 11:16:49 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-12 11:16:49 --> Final output sent to browser
DEBUG - 2011-08-12 11:16:49 --> Total execution time: 0.2485
DEBUG - 2011-08-12 11:16:50 --> Config Class Initialized
DEBUG - 2011-08-12 11:16:50 --> Hooks Class Initialized
DEBUG - 2011-08-12 11:16:50 --> Utf8 Class Initialized
DEBUG - 2011-08-12 11:16:50 --> UTF-8 Support Enabled
DEBUG - 2011-08-12 11:16:50 --> URI Class Initialized
DEBUG - 2011-08-12 11:16:50 --> Router Class Initialized
DEBUG - 2011-08-12 11:16:50 --> Output Class Initialized
DEBUG - 2011-08-12 11:16:50 --> Input Class Initialized
DEBUG - 2011-08-12 11:16:50 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-12 11:16:50 --> Language Class Initialized
DEBUG - 2011-08-12 11:16:50 --> Loader Class Initialized
DEBUG - 2011-08-12 11:16:50 --> Controller Class Initialized
DEBUG - 2011-08-12 11:16:50 --> Model Class Initialized
DEBUG - 2011-08-12 11:16:50 --> Model Class Initialized
DEBUG - 2011-08-12 11:16:50 --> Model Class Initialized
DEBUG - 2011-08-12 11:16:50 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-12 11:16:50 --> Database Driver Class Initialized
DEBUG - 2011-08-12 11:16:50 --> File loaded: application/views/table/main.php
DEBUG - 2011-08-12 11:16:50 --> Helper loaded: url_helper
DEBUG - 2011-08-12 11:16:50 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-12 11:16:50 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-12 11:16:50 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-12 11:16:50 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-12 11:16:50 --> Final output sent to browser
DEBUG - 2011-08-12 11:16:50 --> Total execution time: 0.0701
DEBUG - 2011-08-12 11:16:50 --> Config Class Initialized
DEBUG - 2011-08-12 11:16:50 --> Hooks Class Initialized
DEBUG - 2011-08-12 11:16:50 --> Utf8 Class Initialized
DEBUG - 2011-08-12 11:16:50 --> UTF-8 Support Enabled
DEBUG - 2011-08-12 11:16:50 --> URI Class Initialized
DEBUG - 2011-08-12 11:16:50 --> Router Class Initialized
ERROR - 2011-08-12 11:16:50 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-08-12 11:17:02 --> Config Class Initialized
DEBUG - 2011-08-12 11:17:02 --> Hooks Class Initialized
DEBUG - 2011-08-12 11:17:02 --> Utf8 Class Initialized
DEBUG - 2011-08-12 11:17:02 --> UTF-8 Support Enabled
DEBUG - 2011-08-12 11:17:02 --> URI Class Initialized
DEBUG - 2011-08-12 11:17:02 --> Router Class Initialized
DEBUG - 2011-08-12 11:17:02 --> Output Class Initialized
DEBUG - 2011-08-12 11:17:02 --> Input Class Initialized
DEBUG - 2011-08-12 11:17:02 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-12 11:17:02 --> Language Class Initialized
DEBUG - 2011-08-12 11:17:02 --> Loader Class Initialized
DEBUG - 2011-08-12 11:17:02 --> Controller Class Initialized
DEBUG - 2011-08-12 11:17:02 --> Model Class Initialized
DEBUG - 2011-08-12 11:17:02 --> Model Class Initialized
DEBUG - 2011-08-12 11:17:02 --> Model Class Initialized
DEBUG - 2011-08-12 11:17:02 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-12 11:17:02 --> Database Driver Class Initialized
DEBUG - 2011-08-12 11:17:03 --> File loaded: application/views/table/main.php
DEBUG - 2011-08-12 11:17:03 --> Helper loaded: url_helper
DEBUG - 2011-08-12 11:17:03 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-12 11:17:03 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-12 11:17:03 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-12 11:17:03 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-12 11:17:03 --> Final output sent to browser
DEBUG - 2011-08-12 11:17:03 --> Total execution time: 0.2437
DEBUG - 2011-08-12 11:17:03 --> Config Class Initialized
DEBUG - 2011-08-12 11:17:03 --> Hooks Class Initialized
DEBUG - 2011-08-12 11:17:03 --> Utf8 Class Initialized
DEBUG - 2011-08-12 11:17:03 --> UTF-8 Support Enabled
DEBUG - 2011-08-12 11:17:03 --> URI Class Initialized
DEBUG - 2011-08-12 11:17:03 --> Router Class Initialized
DEBUG - 2011-08-12 11:17:03 --> Output Class Initialized
DEBUG - 2011-08-12 11:17:03 --> Input Class Initialized
DEBUG - 2011-08-12 11:17:03 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-12 11:17:03 --> Language Class Initialized
DEBUG - 2011-08-12 11:17:03 --> Loader Class Initialized
DEBUG - 2011-08-12 11:17:03 --> Controller Class Initialized
DEBUG - 2011-08-12 11:17:03 --> Model Class Initialized
DEBUG - 2011-08-12 11:17:03 --> Model Class Initialized
DEBUG - 2011-08-12 11:17:03 --> Model Class Initialized
DEBUG - 2011-08-12 11:17:03 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-12 11:17:03 --> Database Driver Class Initialized
DEBUG - 2011-08-12 11:17:03 --> File loaded: application/views/table/main.php
DEBUG - 2011-08-12 11:17:03 --> Helper loaded: url_helper
DEBUG - 2011-08-12 11:17:03 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-12 11:17:03 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-12 11:17:03 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-12 11:17:03 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-12 11:17:03 --> Final output sent to browser
DEBUG - 2011-08-12 11:17:03 --> Total execution time: 0.0465
DEBUG - 2011-08-12 11:17:03 --> Config Class Initialized
DEBUG - 2011-08-12 11:17:03 --> Hooks Class Initialized
DEBUG - 2011-08-12 11:17:03 --> Utf8 Class Initialized
DEBUG - 2011-08-12 11:17:03 --> UTF-8 Support Enabled
DEBUG - 2011-08-12 11:17:03 --> URI Class Initialized
DEBUG - 2011-08-12 11:17:03 --> Router Class Initialized
ERROR - 2011-08-12 11:17:03 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-08-12 11:17:14 --> Config Class Initialized
DEBUG - 2011-08-12 11:17:14 --> Hooks Class Initialized
DEBUG - 2011-08-12 11:17:14 --> Utf8 Class Initialized
DEBUG - 2011-08-12 11:17:14 --> UTF-8 Support Enabled
DEBUG - 2011-08-12 11:17:14 --> URI Class Initialized
DEBUG - 2011-08-12 11:17:14 --> Router Class Initialized
DEBUG - 2011-08-12 11:17:14 --> Output Class Initialized
DEBUG - 2011-08-12 11:17:14 --> Input Class Initialized
DEBUG - 2011-08-12 11:17:14 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-12 11:17:14 --> Language Class Initialized
DEBUG - 2011-08-12 11:17:14 --> Loader Class Initialized
DEBUG - 2011-08-12 11:17:14 --> Controller Class Initialized
DEBUG - 2011-08-12 11:17:14 --> Model Class Initialized
DEBUG - 2011-08-12 11:17:14 --> Model Class Initialized
DEBUG - 2011-08-12 11:17:14 --> Model Class Initialized
DEBUG - 2011-08-12 11:17:14 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-12 11:17:14 --> Database Driver Class Initialized
DEBUG - 2011-08-12 11:17:14 --> File loaded: application/views/table/main.php
DEBUG - 2011-08-12 11:17:14 --> Helper loaded: url_helper
DEBUG - 2011-08-12 11:17:14 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-12 11:17:14 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-12 11:17:14 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-12 11:17:14 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-12 11:17:14 --> Final output sent to browser
DEBUG - 2011-08-12 11:17:14 --> Total execution time: 0.2345
DEBUG - 2011-08-12 11:17:15 --> Config Class Initialized
DEBUG - 2011-08-12 11:17:15 --> Hooks Class Initialized
DEBUG - 2011-08-12 11:17:15 --> Utf8 Class Initialized
DEBUG - 2011-08-12 11:17:15 --> UTF-8 Support Enabled
DEBUG - 2011-08-12 11:17:15 --> URI Class Initialized
DEBUG - 2011-08-12 11:17:15 --> Router Class Initialized
ERROR - 2011-08-12 11:17:15 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-08-12 11:17:16 --> Config Class Initialized
DEBUG - 2011-08-12 11:17:16 --> Hooks Class Initialized
DEBUG - 2011-08-12 11:17:16 --> Utf8 Class Initialized
DEBUG - 2011-08-12 11:17:16 --> UTF-8 Support Enabled
DEBUG - 2011-08-12 11:17:16 --> URI Class Initialized
DEBUG - 2011-08-12 11:17:16 --> Router Class Initialized
DEBUG - 2011-08-12 11:17:16 --> Output Class Initialized
DEBUG - 2011-08-12 11:17:16 --> Input Class Initialized
DEBUG - 2011-08-12 11:17:16 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-12 11:17:16 --> Language Class Initialized
DEBUG - 2011-08-12 11:17:16 --> Loader Class Initialized
DEBUG - 2011-08-12 11:17:16 --> Controller Class Initialized
DEBUG - 2011-08-12 11:17:16 --> Model Class Initialized
DEBUG - 2011-08-12 11:17:16 --> Model Class Initialized
DEBUG - 2011-08-12 11:17:16 --> Model Class Initialized
DEBUG - 2011-08-12 11:17:16 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-12 11:17:16 --> Database Driver Class Initialized
DEBUG - 2011-08-12 11:17:16 --> File loaded: application/views/table/main.php
DEBUG - 2011-08-12 11:17:16 --> Helper loaded: url_helper
DEBUG - 2011-08-12 11:17:16 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-12 11:17:16 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-12 11:17:16 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-12 11:17:16 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-12 11:17:16 --> Final output sent to browser
DEBUG - 2011-08-12 11:17:16 --> Total execution time: 0.0546
DEBUG - 2011-08-12 11:17:20 --> Config Class Initialized
DEBUG - 2011-08-12 11:17:20 --> Hooks Class Initialized
DEBUG - 2011-08-12 11:17:20 --> Utf8 Class Initialized
DEBUG - 2011-08-12 11:17:20 --> UTF-8 Support Enabled
DEBUG - 2011-08-12 11:17:20 --> URI Class Initialized
DEBUG - 2011-08-12 11:17:20 --> Router Class Initialized
DEBUG - 2011-08-12 11:17:20 --> Output Class Initialized
DEBUG - 2011-08-12 11:17:20 --> Input Class Initialized
DEBUG - 2011-08-12 11:17:20 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-12 11:17:20 --> Language Class Initialized
DEBUG - 2011-08-12 11:17:20 --> Loader Class Initialized
DEBUG - 2011-08-12 11:17:20 --> Controller Class Initialized
DEBUG - 2011-08-12 11:17:20 --> Model Class Initialized
DEBUG - 2011-08-12 11:17:20 --> Model Class Initialized
DEBUG - 2011-08-12 11:17:20 --> Model Class Initialized
DEBUG - 2011-08-12 11:17:20 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-12 11:17:20 --> Database Driver Class Initialized
DEBUG - 2011-08-12 11:17:21 --> File loaded: application/views/table/main.php
DEBUG - 2011-08-12 11:17:21 --> Helper loaded: url_helper
DEBUG - 2011-08-12 11:17:21 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-12 11:17:21 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-12 11:17:21 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-12 11:17:21 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-12 11:17:21 --> Final output sent to browser
DEBUG - 2011-08-12 11:17:21 --> Total execution time: 0.2882
DEBUG - 2011-08-12 11:17:21 --> Config Class Initialized
DEBUG - 2011-08-12 11:17:21 --> Hooks Class Initialized
DEBUG - 2011-08-12 11:17:21 --> Utf8 Class Initialized
DEBUG - 2011-08-12 11:17:21 --> UTF-8 Support Enabled
DEBUG - 2011-08-12 11:17:21 --> URI Class Initialized
DEBUG - 2011-08-12 11:17:21 --> Router Class Initialized
DEBUG - 2011-08-12 11:17:21 --> Output Class Initialized
DEBUG - 2011-08-12 11:17:21 --> Input Class Initialized
DEBUG - 2011-08-12 11:17:21 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-12 11:17:21 --> Language Class Initialized
DEBUG - 2011-08-12 11:17:21 --> Loader Class Initialized
DEBUG - 2011-08-12 11:17:21 --> Controller Class Initialized
DEBUG - 2011-08-12 11:17:21 --> Model Class Initialized
DEBUG - 2011-08-12 11:17:21 --> Model Class Initialized
DEBUG - 2011-08-12 11:17:21 --> Model Class Initialized
DEBUG - 2011-08-12 11:17:21 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-12 11:17:21 --> Database Driver Class Initialized
DEBUG - 2011-08-12 11:17:21 --> File loaded: application/views/table/main.php
DEBUG - 2011-08-12 11:17:21 --> Helper loaded: url_helper
DEBUG - 2011-08-12 11:17:21 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-12 11:17:21 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-12 11:17:21 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-12 11:17:21 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-12 11:17:21 --> Final output sent to browser
DEBUG - 2011-08-12 11:17:21 --> Total execution time: 0.0490
DEBUG - 2011-08-12 11:17:21 --> Config Class Initialized
DEBUG - 2011-08-12 11:17:21 --> Hooks Class Initialized
DEBUG - 2011-08-12 11:17:21 --> Utf8 Class Initialized
DEBUG - 2011-08-12 11:17:21 --> UTF-8 Support Enabled
DEBUG - 2011-08-12 11:17:21 --> URI Class Initialized
DEBUG - 2011-08-12 11:17:21 --> Router Class Initialized
ERROR - 2011-08-12 11:17:21 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-08-12 11:17:28 --> Config Class Initialized
DEBUG - 2011-08-12 11:17:28 --> Hooks Class Initialized
DEBUG - 2011-08-12 11:17:28 --> Utf8 Class Initialized
DEBUG - 2011-08-12 11:17:28 --> UTF-8 Support Enabled
DEBUG - 2011-08-12 11:17:28 --> URI Class Initialized
DEBUG - 2011-08-12 11:17:28 --> Router Class Initialized
DEBUG - 2011-08-12 11:17:28 --> Output Class Initialized
DEBUG - 2011-08-12 11:17:28 --> Input Class Initialized
DEBUG - 2011-08-12 11:17:28 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-12 11:17:28 --> Language Class Initialized
DEBUG - 2011-08-12 11:17:28 --> Loader Class Initialized
DEBUG - 2011-08-12 11:17:28 --> Controller Class Initialized
DEBUG - 2011-08-12 11:17:28 --> Model Class Initialized
DEBUG - 2011-08-12 11:17:28 --> Model Class Initialized
DEBUG - 2011-08-12 11:17:28 --> Model Class Initialized
DEBUG - 2011-08-12 11:17:28 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-12 11:17:28 --> Database Driver Class Initialized
DEBUG - 2011-08-12 11:17:28 --> File loaded: application/views/table/main.php
DEBUG - 2011-08-12 11:17:28 --> Helper loaded: url_helper
DEBUG - 2011-08-12 11:17:28 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-12 11:17:28 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-12 11:17:28 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-12 11:17:28 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-12 11:17:28 --> Final output sent to browser
DEBUG - 2011-08-12 11:17:28 --> Total execution time: 0.1991
DEBUG - 2011-08-12 11:17:29 --> Config Class Initialized
DEBUG - 2011-08-12 11:17:29 --> Hooks Class Initialized
DEBUG - 2011-08-12 11:17:29 --> Utf8 Class Initialized
DEBUG - 2011-08-12 11:17:29 --> UTF-8 Support Enabled
DEBUG - 2011-08-12 11:17:29 --> URI Class Initialized
DEBUG - 2011-08-12 11:17:29 --> Router Class Initialized
ERROR - 2011-08-12 11:17:29 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-08-12 11:17:29 --> Config Class Initialized
DEBUG - 2011-08-12 11:17:29 --> Hooks Class Initialized
DEBUG - 2011-08-12 11:17:29 --> Utf8 Class Initialized
DEBUG - 2011-08-12 11:17:29 --> UTF-8 Support Enabled
DEBUG - 2011-08-12 11:17:29 --> URI Class Initialized
DEBUG - 2011-08-12 11:17:29 --> Router Class Initialized
DEBUG - 2011-08-12 11:17:29 --> Output Class Initialized
DEBUG - 2011-08-12 11:17:29 --> Input Class Initialized
DEBUG - 2011-08-12 11:17:29 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-12 11:17:29 --> Language Class Initialized
DEBUG - 2011-08-12 11:17:29 --> Loader Class Initialized
DEBUG - 2011-08-12 11:17:29 --> Controller Class Initialized
DEBUG - 2011-08-12 11:17:29 --> Model Class Initialized
DEBUG - 2011-08-12 11:17:29 --> Model Class Initialized
DEBUG - 2011-08-12 11:17:29 --> Model Class Initialized
DEBUG - 2011-08-12 11:17:29 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-12 11:17:29 --> Database Driver Class Initialized
DEBUG - 2011-08-12 11:17:29 --> File loaded: application/views/table/main.php
DEBUG - 2011-08-12 11:17:29 --> Helper loaded: url_helper
DEBUG - 2011-08-12 11:17:29 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-12 11:17:29 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-12 11:17:29 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-12 11:17:29 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-12 11:17:29 --> Final output sent to browser
DEBUG - 2011-08-12 11:17:29 --> Total execution time: 0.1001
DEBUG - 2011-08-12 11:17:33 --> Config Class Initialized
DEBUG - 2011-08-12 11:17:33 --> Hooks Class Initialized
DEBUG - 2011-08-12 11:17:33 --> Utf8 Class Initialized
DEBUG - 2011-08-12 11:17:33 --> UTF-8 Support Enabled
DEBUG - 2011-08-12 11:17:33 --> URI Class Initialized
DEBUG - 2011-08-12 11:17:33 --> Router Class Initialized
DEBUG - 2011-08-12 11:17:33 --> Output Class Initialized
DEBUG - 2011-08-12 11:17:33 --> Input Class Initialized
DEBUG - 2011-08-12 11:17:33 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-12 11:17:33 --> Language Class Initialized
DEBUG - 2011-08-12 11:17:33 --> Loader Class Initialized
DEBUG - 2011-08-12 11:17:33 --> Controller Class Initialized
DEBUG - 2011-08-12 11:17:33 --> Model Class Initialized
DEBUG - 2011-08-12 11:17:33 --> Model Class Initialized
DEBUG - 2011-08-12 11:17:33 --> Model Class Initialized
DEBUG - 2011-08-12 11:17:33 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-12 11:17:33 --> Database Driver Class Initialized
DEBUG - 2011-08-12 11:17:34 --> File loaded: application/views/table/main.php
DEBUG - 2011-08-12 11:17:34 --> Helper loaded: url_helper
DEBUG - 2011-08-12 11:17:34 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-12 11:17:34 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-12 11:17:34 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-12 11:17:34 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-12 11:17:34 --> Final output sent to browser
DEBUG - 2011-08-12 11:17:34 --> Total execution time: 0.2051
DEBUG - 2011-08-12 11:17:35 --> Config Class Initialized
DEBUG - 2011-08-12 11:17:35 --> Hooks Class Initialized
DEBUG - 2011-08-12 11:17:35 --> Utf8 Class Initialized
DEBUG - 2011-08-12 11:17:35 --> UTF-8 Support Enabled
DEBUG - 2011-08-12 11:17:35 --> URI Class Initialized
DEBUG - 2011-08-12 11:17:35 --> Router Class Initialized
ERROR - 2011-08-12 11:17:35 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-08-12 11:17:36 --> Config Class Initialized
DEBUG - 2011-08-12 11:17:36 --> Hooks Class Initialized
DEBUG - 2011-08-12 11:17:36 --> Utf8 Class Initialized
DEBUG - 2011-08-12 11:17:36 --> UTF-8 Support Enabled
DEBUG - 2011-08-12 11:17:36 --> URI Class Initialized
DEBUG - 2011-08-12 11:17:36 --> Router Class Initialized
DEBUG - 2011-08-12 11:17:36 --> Output Class Initialized
DEBUG - 2011-08-12 11:17:36 --> Input Class Initialized
DEBUG - 2011-08-12 11:17:36 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-12 11:17:36 --> Language Class Initialized
DEBUG - 2011-08-12 11:17:36 --> Loader Class Initialized
DEBUG - 2011-08-12 11:17:36 --> Controller Class Initialized
DEBUG - 2011-08-12 11:17:36 --> Model Class Initialized
DEBUG - 2011-08-12 11:17:36 --> Model Class Initialized
DEBUG - 2011-08-12 11:17:36 --> Model Class Initialized
DEBUG - 2011-08-12 11:17:36 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-12 11:17:36 --> Database Driver Class Initialized
DEBUG - 2011-08-12 11:17:36 --> File loaded: application/views/table/main.php
DEBUG - 2011-08-12 11:17:36 --> Helper loaded: url_helper
DEBUG - 2011-08-12 11:17:36 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-12 11:17:36 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-12 11:17:36 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-12 11:17:36 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-12 11:17:36 --> Final output sent to browser
DEBUG - 2011-08-12 11:17:36 --> Total execution time: 0.0466
DEBUG - 2011-08-12 11:17:38 --> Config Class Initialized
DEBUG - 2011-08-12 11:17:38 --> Hooks Class Initialized
DEBUG - 2011-08-12 11:17:38 --> Utf8 Class Initialized
DEBUG - 2011-08-12 11:17:38 --> UTF-8 Support Enabled
DEBUG - 2011-08-12 11:17:38 --> URI Class Initialized
DEBUG - 2011-08-12 11:17:38 --> Router Class Initialized
DEBUG - 2011-08-12 11:17:38 --> Output Class Initialized
DEBUG - 2011-08-12 11:17:38 --> Input Class Initialized
DEBUG - 2011-08-12 11:17:38 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-12 11:17:38 --> Language Class Initialized
DEBUG - 2011-08-12 11:17:38 --> Loader Class Initialized
DEBUG - 2011-08-12 11:17:38 --> Controller Class Initialized
DEBUG - 2011-08-12 11:17:38 --> Model Class Initialized
DEBUG - 2011-08-12 11:17:38 --> Model Class Initialized
DEBUG - 2011-08-12 11:17:38 --> Model Class Initialized
DEBUG - 2011-08-12 11:17:38 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-12 11:17:38 --> Database Driver Class Initialized
DEBUG - 2011-08-12 11:17:39 --> File loaded: application/views/table/main.php
DEBUG - 2011-08-12 11:17:39 --> Helper loaded: url_helper
DEBUG - 2011-08-12 11:17:39 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-12 11:17:39 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-12 11:17:39 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-12 11:17:39 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-12 11:17:39 --> Final output sent to browser
DEBUG - 2011-08-12 11:17:39 --> Total execution time: 0.6274
DEBUG - 2011-08-12 11:17:40 --> Config Class Initialized
DEBUG - 2011-08-12 11:17:40 --> Hooks Class Initialized
DEBUG - 2011-08-12 11:17:40 --> Utf8 Class Initialized
DEBUG - 2011-08-12 11:17:40 --> UTF-8 Support Enabled
DEBUG - 2011-08-12 11:17:40 --> URI Class Initialized
DEBUG - 2011-08-12 11:17:40 --> Router Class Initialized
ERROR - 2011-08-12 11:17:40 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-08-12 11:17:40 --> Config Class Initialized
DEBUG - 2011-08-12 11:17:40 --> Hooks Class Initialized
DEBUG - 2011-08-12 11:17:40 --> Utf8 Class Initialized
DEBUG - 2011-08-12 11:17:40 --> UTF-8 Support Enabled
DEBUG - 2011-08-12 11:17:40 --> URI Class Initialized
DEBUG - 2011-08-12 11:17:40 --> Router Class Initialized
DEBUG - 2011-08-12 11:17:40 --> Output Class Initialized
DEBUG - 2011-08-12 11:17:40 --> Input Class Initialized
DEBUG - 2011-08-12 11:17:40 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-12 11:17:40 --> Language Class Initialized
DEBUG - 2011-08-12 11:17:40 --> Loader Class Initialized
DEBUG - 2011-08-12 11:17:40 --> Controller Class Initialized
DEBUG - 2011-08-12 11:17:40 --> Model Class Initialized
DEBUG - 2011-08-12 11:17:40 --> Model Class Initialized
DEBUG - 2011-08-12 11:17:40 --> Model Class Initialized
DEBUG - 2011-08-12 11:17:40 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-12 11:17:40 --> Database Driver Class Initialized
DEBUG - 2011-08-12 11:17:40 --> File loaded: application/views/table/main.php
DEBUG - 2011-08-12 11:17:40 --> Helper loaded: url_helper
DEBUG - 2011-08-12 11:17:40 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-12 11:17:40 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-12 11:17:40 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-12 11:17:40 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-12 11:17:40 --> Final output sent to browser
DEBUG - 2011-08-12 11:17:40 --> Total execution time: 0.0616
DEBUG - 2011-08-12 11:40:49 --> Config Class Initialized
DEBUG - 2011-08-12 11:40:49 --> Hooks Class Initialized
DEBUG - 2011-08-12 11:40:49 --> Utf8 Class Initialized
DEBUG - 2011-08-12 11:40:49 --> UTF-8 Support Enabled
DEBUG - 2011-08-12 11:40:49 --> URI Class Initialized
DEBUG - 2011-08-12 11:40:49 --> Router Class Initialized
DEBUG - 2011-08-12 11:40:49 --> Output Class Initialized
DEBUG - 2011-08-12 11:40:49 --> Input Class Initialized
DEBUG - 2011-08-12 11:40:49 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-12 11:40:49 --> Language Class Initialized
DEBUG - 2011-08-12 11:40:49 --> Loader Class Initialized
DEBUG - 2011-08-12 11:40:49 --> Controller Class Initialized
ERROR - 2011-08-12 11:40:49 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-08-12 11:40:49 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-08-12 11:40:49 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-08-12 11:40:49 --> Model Class Initialized
DEBUG - 2011-08-12 11:40:49 --> Model Class Initialized
DEBUG - 2011-08-12 11:40:49 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-12 11:40:49 --> Database Driver Class Initialized
DEBUG - 2011-08-12 11:40:49 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-08-12 11:40:49 --> Helper loaded: url_helper
DEBUG - 2011-08-12 11:40:49 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-12 11:40:49 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-12 11:40:49 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-12 11:40:49 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-12 11:40:49 --> Final output sent to browser
DEBUG - 2011-08-12 11:40:49 --> Total execution time: 0.0686
DEBUG - 2011-08-12 11:40:50 --> Config Class Initialized
DEBUG - 2011-08-12 11:40:50 --> Hooks Class Initialized
DEBUG - 2011-08-12 11:40:50 --> Utf8 Class Initialized
DEBUG - 2011-08-12 11:40:50 --> UTF-8 Support Enabled
DEBUG - 2011-08-12 11:40:50 --> URI Class Initialized
DEBUG - 2011-08-12 11:40:50 --> Router Class Initialized
DEBUG - 2011-08-12 11:40:50 --> Output Class Initialized
DEBUG - 2011-08-12 11:40:50 --> Input Class Initialized
DEBUG - 2011-08-12 11:40:50 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-12 11:40:50 --> Language Class Initialized
DEBUG - 2011-08-12 11:40:50 --> Loader Class Initialized
DEBUG - 2011-08-12 11:40:50 --> Controller Class Initialized
DEBUG - 2011-08-12 11:40:50 --> Model Class Initialized
DEBUG - 2011-08-12 11:40:50 --> Model Class Initialized
DEBUG - 2011-08-12 11:40:50 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-12 11:40:50 --> Database Driver Class Initialized
DEBUG - 2011-08-12 11:40:51 --> Final output sent to browser
DEBUG - 2011-08-12 11:40:51 --> Total execution time: 0.5989
DEBUG - 2011-08-12 11:40:52 --> Config Class Initialized
DEBUG - 2011-08-12 11:40:52 --> Hooks Class Initialized
DEBUG - 2011-08-12 11:40:52 --> Utf8 Class Initialized
DEBUG - 2011-08-12 11:40:52 --> UTF-8 Support Enabled
DEBUG - 2011-08-12 11:40:52 --> URI Class Initialized
DEBUG - 2011-08-12 11:40:52 --> Router Class Initialized
ERROR - 2011-08-12 11:40:52 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-08-12 11:45:46 --> Config Class Initialized
DEBUG - 2011-08-12 11:45:46 --> Hooks Class Initialized
DEBUG - 2011-08-12 11:45:46 --> Utf8 Class Initialized
DEBUG - 2011-08-12 11:45:46 --> UTF-8 Support Enabled
DEBUG - 2011-08-12 11:45:46 --> URI Class Initialized
DEBUG - 2011-08-12 11:45:46 --> Router Class Initialized
DEBUG - 2011-08-12 11:45:46 --> Output Class Initialized
DEBUG - 2011-08-12 11:45:46 --> Input Class Initialized
DEBUG - 2011-08-12 11:45:46 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-12 11:45:46 --> Language Class Initialized
DEBUG - 2011-08-12 11:45:46 --> Loader Class Initialized
DEBUG - 2011-08-12 11:45:46 --> Controller Class Initialized
ERROR - 2011-08-12 11:45:46 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-08-12 11:45:46 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-08-12 11:45:46 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-08-12 11:45:46 --> Model Class Initialized
DEBUG - 2011-08-12 11:45:46 --> Model Class Initialized
DEBUG - 2011-08-12 11:45:46 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-12 11:45:46 --> Database Driver Class Initialized
DEBUG - 2011-08-12 11:45:46 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-08-12 11:45:46 --> Helper loaded: url_helper
DEBUG - 2011-08-12 11:45:46 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-12 11:45:46 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-12 11:45:46 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-12 11:45:46 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-12 11:45:46 --> Final output sent to browser
DEBUG - 2011-08-12 11:45:46 --> Total execution time: 0.0448
DEBUG - 2011-08-12 11:45:46 --> Config Class Initialized
DEBUG - 2011-08-12 11:45:46 --> Hooks Class Initialized
DEBUG - 2011-08-12 11:45:46 --> Utf8 Class Initialized
DEBUG - 2011-08-12 11:45:46 --> UTF-8 Support Enabled
DEBUG - 2011-08-12 11:45:46 --> URI Class Initialized
DEBUG - 2011-08-12 11:45:46 --> Router Class Initialized
DEBUG - 2011-08-12 11:45:46 --> Output Class Initialized
DEBUG - 2011-08-12 11:45:46 --> Input Class Initialized
DEBUG - 2011-08-12 11:45:46 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-12 11:45:46 --> Language Class Initialized
DEBUG - 2011-08-12 11:45:46 --> Loader Class Initialized
DEBUG - 2011-08-12 11:45:46 --> Controller Class Initialized
DEBUG - 2011-08-12 11:45:46 --> Model Class Initialized
DEBUG - 2011-08-12 11:45:46 --> Model Class Initialized
DEBUG - 2011-08-12 11:45:46 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-12 11:45:46 --> Database Driver Class Initialized
DEBUG - 2011-08-12 11:45:47 --> Final output sent to browser
DEBUG - 2011-08-12 11:45:47 --> Total execution time: 0.5133
DEBUG - 2011-08-12 11:51:05 --> Config Class Initialized
DEBUG - 2011-08-12 11:51:05 --> Hooks Class Initialized
DEBUG - 2011-08-12 11:51:05 --> Utf8 Class Initialized
DEBUG - 2011-08-12 11:51:05 --> UTF-8 Support Enabled
DEBUG - 2011-08-12 11:51:05 --> URI Class Initialized
DEBUG - 2011-08-12 11:51:05 --> Router Class Initialized
ERROR - 2011-08-12 11:51:05 --> 404 Page Not Found --> robots.txt
DEBUG - 2011-08-12 11:51:05 --> Config Class Initialized
DEBUG - 2011-08-12 11:51:05 --> Hooks Class Initialized
DEBUG - 2011-08-12 11:51:05 --> Utf8 Class Initialized
DEBUG - 2011-08-12 11:51:05 --> UTF-8 Support Enabled
DEBUG - 2011-08-12 11:51:05 --> URI Class Initialized
DEBUG - 2011-08-12 11:51:05 --> Router Class Initialized
DEBUG - 2011-08-12 11:51:05 --> Output Class Initialized
DEBUG - 2011-08-12 11:51:05 --> Input Class Initialized
DEBUG - 2011-08-12 11:51:05 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-12 11:51:05 --> Language Class Initialized
DEBUG - 2011-08-12 11:51:05 --> Loader Class Initialized
DEBUG - 2011-08-12 11:51:05 --> Controller Class Initialized
ERROR - 2011-08-12 11:51:05 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-08-12 11:51:05 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-08-12 11:51:05 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-08-12 11:51:05 --> Model Class Initialized
DEBUG - 2011-08-12 11:51:05 --> Model Class Initialized
DEBUG - 2011-08-12 11:51:05 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-12 11:51:05 --> Database Driver Class Initialized
DEBUG - 2011-08-12 11:51:05 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-08-12 11:51:05 --> Helper loaded: url_helper
DEBUG - 2011-08-12 11:51:05 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-12 11:51:05 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-12 11:51:05 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-12 11:51:05 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-12 11:51:05 --> Final output sent to browser
DEBUG - 2011-08-12 11:51:05 --> Total execution time: 0.0351
DEBUG - 2011-08-12 15:53:00 --> Config Class Initialized
DEBUG - 2011-08-12 15:53:00 --> Hooks Class Initialized
DEBUG - 2011-08-12 15:53:00 --> Utf8 Class Initialized
DEBUG - 2011-08-12 15:53:00 --> UTF-8 Support Enabled
DEBUG - 2011-08-12 15:53:00 --> URI Class Initialized
DEBUG - 2011-08-12 15:53:00 --> Router Class Initialized
DEBUG - 2011-08-12 15:53:01 --> Output Class Initialized
DEBUG - 2011-08-12 15:53:01 --> Input Class Initialized
DEBUG - 2011-08-12 15:53:01 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-12 15:53:01 --> Language Class Initialized
DEBUG - 2011-08-12 15:53:01 --> Loader Class Initialized
DEBUG - 2011-08-12 15:53:01 --> Controller Class Initialized
ERROR - 2011-08-12 15:53:01 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-08-12 15:53:01 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-08-12 15:53:01 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-08-12 15:53:01 --> Model Class Initialized
DEBUG - 2011-08-12 15:53:01 --> Model Class Initialized
DEBUG - 2011-08-12 15:53:01 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-12 15:53:01 --> Database Driver Class Initialized
DEBUG - 2011-08-12 15:53:01 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-08-12 15:53:01 --> Helper loaded: url_helper
DEBUG - 2011-08-12 15:53:01 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-12 15:53:01 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-12 15:53:01 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-12 15:53:01 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-12 15:53:01 --> Final output sent to browser
DEBUG - 2011-08-12 15:53:01 --> Total execution time: 0.3151
DEBUG - 2011-08-12 15:53:05 --> Config Class Initialized
DEBUG - 2011-08-12 15:53:05 --> Hooks Class Initialized
DEBUG - 2011-08-12 15:53:05 --> Utf8 Class Initialized
DEBUG - 2011-08-12 15:53:05 --> UTF-8 Support Enabled
DEBUG - 2011-08-12 15:53:05 --> URI Class Initialized
DEBUG - 2011-08-12 15:53:05 --> Router Class Initialized
DEBUG - 2011-08-12 15:53:05 --> Output Class Initialized
DEBUG - 2011-08-12 15:53:05 --> Input Class Initialized
DEBUG - 2011-08-12 15:53:05 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-12 15:53:05 --> Language Class Initialized
DEBUG - 2011-08-12 15:53:05 --> Loader Class Initialized
DEBUG - 2011-08-12 15:53:05 --> Controller Class Initialized
DEBUG - 2011-08-12 15:53:05 --> Model Class Initialized
DEBUG - 2011-08-12 15:53:05 --> Model Class Initialized
DEBUG - 2011-08-12 15:53:05 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-12 15:53:05 --> Database Driver Class Initialized
DEBUG - 2011-08-12 15:53:05 --> Final output sent to browser
DEBUG - 2011-08-12 15:53:05 --> Total execution time: 0.6189
DEBUG - 2011-08-12 15:54:06 --> Config Class Initialized
DEBUG - 2011-08-12 15:54:06 --> Hooks Class Initialized
DEBUG - 2011-08-12 15:54:06 --> Utf8 Class Initialized
DEBUG - 2011-08-12 15:54:06 --> UTF-8 Support Enabled
DEBUG - 2011-08-12 15:54:06 --> URI Class Initialized
DEBUG - 2011-08-12 15:54:06 --> Router Class Initialized
ERROR - 2011-08-12 15:54:06 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-08-12 15:54:07 --> Config Class Initialized
DEBUG - 2011-08-12 15:54:07 --> Hooks Class Initialized
DEBUG - 2011-08-12 15:54:07 --> Utf8 Class Initialized
DEBUG - 2011-08-12 15:54:07 --> UTF-8 Support Enabled
DEBUG - 2011-08-12 15:54:07 --> URI Class Initialized
DEBUG - 2011-08-12 15:54:07 --> Router Class Initialized
ERROR - 2011-08-12 15:54:07 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-08-12 15:54:07 --> Config Class Initialized
DEBUG - 2011-08-12 15:54:07 --> Hooks Class Initialized
DEBUG - 2011-08-12 15:54:07 --> Utf8 Class Initialized
DEBUG - 2011-08-12 15:54:07 --> UTF-8 Support Enabled
DEBUG - 2011-08-12 15:54:07 --> URI Class Initialized
DEBUG - 2011-08-12 15:54:07 --> Router Class Initialized
ERROR - 2011-08-12 15:54:07 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-08-12 16:05:00 --> Config Class Initialized
DEBUG - 2011-08-12 16:05:00 --> Hooks Class Initialized
DEBUG - 2011-08-12 16:05:00 --> Utf8 Class Initialized
DEBUG - 2011-08-12 16:05:00 --> UTF-8 Support Enabled
DEBUG - 2011-08-12 16:05:00 --> URI Class Initialized
DEBUG - 2011-08-12 16:05:00 --> Router Class Initialized
DEBUG - 2011-08-12 16:05:01 --> No URI present. Default controller set.
DEBUG - 2011-08-12 16:05:01 --> Output Class Initialized
DEBUG - 2011-08-12 16:05:01 --> Input Class Initialized
DEBUG - 2011-08-12 16:05:01 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-12 16:05:01 --> Language Class Initialized
DEBUG - 2011-08-12 16:05:01 --> Loader Class Initialized
DEBUG - 2011-08-12 16:05:01 --> Controller Class Initialized
DEBUG - 2011-08-12 16:05:01 --> File loaded: application/views/splash/main.php
DEBUG - 2011-08-12 16:05:01 --> Helper loaded: url_helper
DEBUG - 2011-08-12 16:05:01 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-12 16:05:01 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-12 16:05:01 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-12 16:05:01 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-12 16:05:01 --> Final output sent to browser
DEBUG - 2011-08-12 16:05:01 --> Total execution time: 0.0607
DEBUG - 2011-08-12 17:04:25 --> Config Class Initialized
DEBUG - 2011-08-12 17:04:25 --> Hooks Class Initialized
DEBUG - 2011-08-12 17:04:25 --> Utf8 Class Initialized
DEBUG - 2011-08-12 17:04:25 --> UTF-8 Support Enabled
DEBUG - 2011-08-12 17:04:25 --> URI Class Initialized
DEBUG - 2011-08-12 17:04:25 --> Router Class Initialized
DEBUG - 2011-08-12 17:04:25 --> Output Class Initialized
DEBUG - 2011-08-12 17:04:25 --> Input Class Initialized
DEBUG - 2011-08-12 17:04:25 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-12 17:04:25 --> Language Class Initialized
DEBUG - 2011-08-12 17:04:25 --> Loader Class Initialized
DEBUG - 2011-08-12 17:04:25 --> Controller Class Initialized
ERROR - 2011-08-12 17:04:25 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-08-12 17:04:25 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-08-12 17:04:25 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-08-12 17:04:25 --> Model Class Initialized
DEBUG - 2011-08-12 17:04:25 --> Model Class Initialized
DEBUG - 2011-08-12 17:04:25 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-12 17:04:25 --> Database Driver Class Initialized
DEBUG - 2011-08-12 17:04:25 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-08-12 17:04:25 --> Helper loaded: url_helper
DEBUG - 2011-08-12 17:04:25 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-12 17:04:25 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-12 17:04:25 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-12 17:04:25 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-12 17:04:25 --> Final output sent to browser
DEBUG - 2011-08-12 17:04:25 --> Total execution time: 0.0880
DEBUG - 2011-08-12 17:04:26 --> Config Class Initialized
DEBUG - 2011-08-12 17:04:26 --> Hooks Class Initialized
DEBUG - 2011-08-12 17:04:26 --> Utf8 Class Initialized
DEBUG - 2011-08-12 17:04:26 --> UTF-8 Support Enabled
DEBUG - 2011-08-12 17:04:26 --> URI Class Initialized
DEBUG - 2011-08-12 17:04:26 --> Router Class Initialized
DEBUG - 2011-08-12 17:04:26 --> Output Class Initialized
DEBUG - 2011-08-12 17:04:26 --> Input Class Initialized
DEBUG - 2011-08-12 17:04:26 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-12 17:04:26 --> Language Class Initialized
DEBUG - 2011-08-12 17:04:26 --> Loader Class Initialized
DEBUG - 2011-08-12 17:04:26 --> Controller Class Initialized
DEBUG - 2011-08-12 17:04:26 --> Model Class Initialized
DEBUG - 2011-08-12 17:04:26 --> Model Class Initialized
DEBUG - 2011-08-12 17:04:26 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-12 17:04:26 --> Database Driver Class Initialized
DEBUG - 2011-08-12 17:04:26 --> Final output sent to browser
DEBUG - 2011-08-12 17:04:26 --> Total execution time: 0.6716
DEBUG - 2011-08-12 17:04:27 --> Config Class Initialized
DEBUG - 2011-08-12 17:04:27 --> Hooks Class Initialized
DEBUG - 2011-08-12 17:04:27 --> Utf8 Class Initialized
DEBUG - 2011-08-12 17:04:27 --> UTF-8 Support Enabled
DEBUG - 2011-08-12 17:04:27 --> URI Class Initialized
DEBUG - 2011-08-12 17:04:27 --> Router Class Initialized
ERROR - 2011-08-12 17:04:27 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-08-12 17:55:18 --> Config Class Initialized
DEBUG - 2011-08-12 17:55:18 --> Hooks Class Initialized
DEBUG - 2011-08-12 17:55:18 --> Utf8 Class Initialized
DEBUG - 2011-08-12 17:55:18 --> UTF-8 Support Enabled
DEBUG - 2011-08-12 17:55:18 --> URI Class Initialized
DEBUG - 2011-08-12 17:55:18 --> Router Class Initialized
DEBUG - 2011-08-12 17:55:18 --> Output Class Initialized
DEBUG - 2011-08-12 17:55:18 --> Input Class Initialized
DEBUG - 2011-08-12 17:55:18 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-12 17:55:18 --> Language Class Initialized
DEBUG - 2011-08-12 17:55:18 --> Loader Class Initialized
DEBUG - 2011-08-12 17:55:18 --> Controller Class Initialized
ERROR - 2011-08-12 17:55:18 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-08-12 17:55:18 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-08-12 17:55:18 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-08-12 17:55:18 --> Model Class Initialized
DEBUG - 2011-08-12 17:55:18 --> Model Class Initialized
DEBUG - 2011-08-12 17:55:18 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-12 17:55:18 --> Database Driver Class Initialized
DEBUG - 2011-08-12 17:55:18 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-08-12 17:55:18 --> Helper loaded: url_helper
DEBUG - 2011-08-12 17:55:18 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-12 17:55:18 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-12 17:55:18 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-12 17:55:18 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-12 17:55:18 --> Final output sent to browser
DEBUG - 2011-08-12 17:55:18 --> Total execution time: 0.2813
DEBUG - 2011-08-12 18:02:13 --> Config Class Initialized
DEBUG - 2011-08-12 18:02:13 --> Hooks Class Initialized
DEBUG - 2011-08-12 18:02:13 --> Utf8 Class Initialized
DEBUG - 2011-08-12 18:02:13 --> UTF-8 Support Enabled
DEBUG - 2011-08-12 18:02:13 --> URI Class Initialized
DEBUG - 2011-08-12 18:02:13 --> Router Class Initialized
DEBUG - 2011-08-12 18:02:13 --> Output Class Initialized
DEBUG - 2011-08-12 18:02:13 --> Input Class Initialized
DEBUG - 2011-08-12 18:02:13 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-12 18:02:13 --> Language Class Initialized
DEBUG - 2011-08-12 18:02:13 --> Loader Class Initialized
DEBUG - 2011-08-12 18:02:13 --> Controller Class Initialized
ERROR - 2011-08-12 18:02:13 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-08-12 18:02:13 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-08-12 18:02:13 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-08-12 18:02:13 --> Model Class Initialized
DEBUG - 2011-08-12 18:02:13 --> Model Class Initialized
DEBUG - 2011-08-12 18:02:13 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-12 18:02:13 --> Database Driver Class Initialized
DEBUG - 2011-08-12 18:02:13 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-08-12 18:02:13 --> Helper loaded: url_helper
DEBUG - 2011-08-12 18:02:13 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-12 18:02:13 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-12 18:02:13 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-12 18:02:13 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-12 18:02:13 --> Final output sent to browser
DEBUG - 2011-08-12 18:02:13 --> Total execution time: 0.0463
DEBUG - 2011-08-12 18:02:13 --> Config Class Initialized
DEBUG - 2011-08-12 18:02:13 --> Hooks Class Initialized
DEBUG - 2011-08-12 18:02:13 --> Utf8 Class Initialized
DEBUG - 2011-08-12 18:02:13 --> UTF-8 Support Enabled
DEBUG - 2011-08-12 18:02:13 --> URI Class Initialized
DEBUG - 2011-08-12 18:02:13 --> Router Class Initialized
DEBUG - 2011-08-12 18:02:13 --> Output Class Initialized
DEBUG - 2011-08-12 18:02:13 --> Input Class Initialized
DEBUG - 2011-08-12 18:02:13 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-12 18:02:13 --> Language Class Initialized
DEBUG - 2011-08-12 18:02:13 --> Loader Class Initialized
DEBUG - 2011-08-12 18:02:13 --> Controller Class Initialized
DEBUG - 2011-08-12 18:02:13 --> Model Class Initialized
DEBUG - 2011-08-12 18:02:13 --> Model Class Initialized
DEBUG - 2011-08-12 18:02:13 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-12 18:02:13 --> Database Driver Class Initialized
DEBUG - 2011-08-12 18:02:14 --> Final output sent to browser
DEBUG - 2011-08-12 18:02:14 --> Total execution time: 0.7853
DEBUG - 2011-08-12 18:02:15 --> Config Class Initialized
DEBUG - 2011-08-12 18:02:15 --> Hooks Class Initialized
DEBUG - 2011-08-12 18:02:15 --> Utf8 Class Initialized
DEBUG - 2011-08-12 18:02:15 --> UTF-8 Support Enabled
DEBUG - 2011-08-12 18:02:15 --> URI Class Initialized
DEBUG - 2011-08-12 18:02:15 --> Router Class Initialized
ERROR - 2011-08-12 18:02:15 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-08-12 18:02:15 --> Config Class Initialized
DEBUG - 2011-08-12 18:02:15 --> Hooks Class Initialized
DEBUG - 2011-08-12 18:02:15 --> Utf8 Class Initialized
DEBUG - 2011-08-12 18:02:15 --> UTF-8 Support Enabled
DEBUG - 2011-08-12 18:02:15 --> URI Class Initialized
DEBUG - 2011-08-12 18:02:15 --> Router Class Initialized
ERROR - 2011-08-12 18:02:15 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-08-12 18:02:15 --> Config Class Initialized
DEBUG - 2011-08-12 18:02:15 --> Hooks Class Initialized
DEBUG - 2011-08-12 18:02:15 --> Utf8 Class Initialized
DEBUG - 2011-08-12 18:02:15 --> UTF-8 Support Enabled
DEBUG - 2011-08-12 18:02:15 --> URI Class Initialized
DEBUG - 2011-08-12 18:02:15 --> Router Class Initialized
ERROR - 2011-08-12 18:02:15 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-08-12 18:08:13 --> Config Class Initialized
DEBUG - 2011-08-12 18:08:13 --> Hooks Class Initialized
DEBUG - 2011-08-12 18:08:13 --> Utf8 Class Initialized
DEBUG - 2011-08-12 18:08:13 --> UTF-8 Support Enabled
DEBUG - 2011-08-12 18:08:13 --> URI Class Initialized
DEBUG - 2011-08-12 18:08:13 --> Router Class Initialized
DEBUG - 2011-08-12 18:08:13 --> Output Class Initialized
DEBUG - 2011-08-12 18:08:13 --> Input Class Initialized
DEBUG - 2011-08-12 18:08:13 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-12 18:08:13 --> Language Class Initialized
DEBUG - 2011-08-12 18:08:13 --> Loader Class Initialized
DEBUG - 2011-08-12 18:08:13 --> Controller Class Initialized
ERROR - 2011-08-12 18:08:13 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-08-12 18:08:13 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-08-12 18:08:13 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-08-12 18:08:13 --> Model Class Initialized
DEBUG - 2011-08-12 18:08:13 --> Model Class Initialized
DEBUG - 2011-08-12 18:08:13 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-12 18:08:13 --> Database Driver Class Initialized
DEBUG - 2011-08-12 18:08:13 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-08-12 18:08:13 --> Helper loaded: url_helper
DEBUG - 2011-08-12 18:08:13 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-12 18:08:13 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-12 18:08:13 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-12 18:08:13 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-12 18:08:13 --> Final output sent to browser
DEBUG - 2011-08-12 18:08:13 --> Total execution time: 0.0482
DEBUG - 2011-08-12 18:08:14 --> Config Class Initialized
DEBUG - 2011-08-12 18:08:14 --> Hooks Class Initialized
DEBUG - 2011-08-12 18:08:14 --> Utf8 Class Initialized
DEBUG - 2011-08-12 18:08:14 --> UTF-8 Support Enabled
DEBUG - 2011-08-12 18:08:14 --> URI Class Initialized
DEBUG - 2011-08-12 18:08:14 --> Router Class Initialized
DEBUG - 2011-08-12 18:08:14 --> Output Class Initialized
DEBUG - 2011-08-12 18:08:14 --> Input Class Initialized
DEBUG - 2011-08-12 18:08:14 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-12 18:08:14 --> Language Class Initialized
DEBUG - 2011-08-12 18:08:14 --> Loader Class Initialized
DEBUG - 2011-08-12 18:08:14 --> Controller Class Initialized
DEBUG - 2011-08-12 18:08:14 --> Model Class Initialized
DEBUG - 2011-08-12 18:08:14 --> Model Class Initialized
DEBUG - 2011-08-12 18:08:14 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-12 18:08:14 --> Database Driver Class Initialized
DEBUG - 2011-08-12 18:08:15 --> Final output sent to browser
DEBUG - 2011-08-12 18:08:15 --> Total execution time: 0.6950
DEBUG - 2011-08-12 18:08:17 --> Config Class Initialized
DEBUG - 2011-08-12 18:08:17 --> Hooks Class Initialized
DEBUG - 2011-08-12 18:08:17 --> Utf8 Class Initialized
DEBUG - 2011-08-12 18:08:17 --> UTF-8 Support Enabled
DEBUG - 2011-08-12 18:08:17 --> URI Class Initialized
DEBUG - 2011-08-12 18:08:17 --> Router Class Initialized
ERROR - 2011-08-12 18:08:17 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-08-12 18:08:53 --> Config Class Initialized
DEBUG - 2011-08-12 18:08:53 --> Hooks Class Initialized
DEBUG - 2011-08-12 18:08:53 --> Utf8 Class Initialized
DEBUG - 2011-08-12 18:08:53 --> UTF-8 Support Enabled
DEBUG - 2011-08-12 18:08:53 --> URI Class Initialized
DEBUG - 2011-08-12 18:08:53 --> Router Class Initialized
DEBUG - 2011-08-12 18:08:53 --> Output Class Initialized
DEBUG - 2011-08-12 18:08:53 --> Input Class Initialized
DEBUG - 2011-08-12 18:08:53 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-12 18:08:53 --> Language Class Initialized
DEBUG - 2011-08-12 18:08:53 --> Loader Class Initialized
DEBUG - 2011-08-12 18:08:53 --> Controller Class Initialized
ERROR - 2011-08-12 18:08:53 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-08-12 18:08:53 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-08-12 18:08:53 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-08-12 18:08:53 --> Model Class Initialized
DEBUG - 2011-08-12 18:08:53 --> Model Class Initialized
DEBUG - 2011-08-12 18:08:53 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-12 18:08:53 --> Database Driver Class Initialized
DEBUG - 2011-08-12 18:08:53 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-08-12 18:08:53 --> Helper loaded: url_helper
DEBUG - 2011-08-12 18:08:53 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-12 18:08:53 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-12 18:08:53 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-12 18:08:53 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-12 18:08:53 --> Final output sent to browser
DEBUG - 2011-08-12 18:08:53 --> Total execution time: 0.0333
DEBUG - 2011-08-12 18:08:54 --> Config Class Initialized
DEBUG - 2011-08-12 18:08:54 --> Hooks Class Initialized
DEBUG - 2011-08-12 18:08:54 --> Utf8 Class Initialized
DEBUG - 2011-08-12 18:08:54 --> UTF-8 Support Enabled
DEBUG - 2011-08-12 18:08:54 --> URI Class Initialized
DEBUG - 2011-08-12 18:08:54 --> Router Class Initialized
DEBUG - 2011-08-12 18:08:54 --> Output Class Initialized
DEBUG - 2011-08-12 18:08:54 --> Input Class Initialized
DEBUG - 2011-08-12 18:08:54 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-12 18:08:54 --> Language Class Initialized
DEBUG - 2011-08-12 18:08:54 --> Loader Class Initialized
DEBUG - 2011-08-12 18:08:54 --> Controller Class Initialized
DEBUG - 2011-08-12 18:08:54 --> Model Class Initialized
DEBUG - 2011-08-12 18:08:54 --> Model Class Initialized
DEBUG - 2011-08-12 18:08:54 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-12 18:08:54 --> Database Driver Class Initialized
DEBUG - 2011-08-12 18:08:55 --> Final output sent to browser
DEBUG - 2011-08-12 18:08:55 --> Total execution time: 0.5515
DEBUG - 2011-08-12 18:08:56 --> Config Class Initialized
DEBUG - 2011-08-12 18:08:56 --> Hooks Class Initialized
DEBUG - 2011-08-12 18:08:56 --> Utf8 Class Initialized
DEBUG - 2011-08-12 18:08:56 --> UTF-8 Support Enabled
DEBUG - 2011-08-12 18:08:56 --> URI Class Initialized
DEBUG - 2011-08-12 18:08:56 --> Router Class Initialized
ERROR - 2011-08-12 18:08:56 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-08-12 18:09:06 --> Config Class Initialized
DEBUG - 2011-08-12 18:09:06 --> Hooks Class Initialized
DEBUG - 2011-08-12 18:09:06 --> Utf8 Class Initialized
DEBUG - 2011-08-12 18:09:06 --> UTF-8 Support Enabled
DEBUG - 2011-08-12 18:09:06 --> URI Class Initialized
DEBUG - 2011-08-12 18:09:06 --> Router Class Initialized
DEBUG - 2011-08-12 18:09:06 --> Output Class Initialized
DEBUG - 2011-08-12 18:09:06 --> Input Class Initialized
DEBUG - 2011-08-12 18:09:06 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-12 18:09:06 --> Language Class Initialized
DEBUG - 2011-08-12 18:09:06 --> Loader Class Initialized
DEBUG - 2011-08-12 18:09:06 --> Controller Class Initialized
ERROR - 2011-08-12 18:09:06 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-08-12 18:09:06 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-08-12 18:09:06 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-08-12 18:09:06 --> Model Class Initialized
DEBUG - 2011-08-12 18:09:06 --> Model Class Initialized
DEBUG - 2011-08-12 18:09:06 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-12 18:09:06 --> Database Driver Class Initialized
DEBUG - 2011-08-12 18:09:06 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-08-12 18:09:06 --> Helper loaded: url_helper
DEBUG - 2011-08-12 18:09:06 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-12 18:09:06 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-12 18:09:06 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-12 18:09:06 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-12 18:09:06 --> Final output sent to browser
DEBUG - 2011-08-12 18:09:06 --> Total execution time: 0.0333
DEBUG - 2011-08-12 18:09:07 --> Config Class Initialized
DEBUG - 2011-08-12 18:09:07 --> Hooks Class Initialized
DEBUG - 2011-08-12 18:09:07 --> Utf8 Class Initialized
DEBUG - 2011-08-12 18:09:07 --> UTF-8 Support Enabled
DEBUG - 2011-08-12 18:09:07 --> URI Class Initialized
DEBUG - 2011-08-12 18:09:07 --> Router Class Initialized
DEBUG - 2011-08-12 18:09:07 --> Output Class Initialized
DEBUG - 2011-08-12 18:09:07 --> Input Class Initialized
DEBUG - 2011-08-12 18:09:07 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-12 18:09:07 --> Language Class Initialized
DEBUG - 2011-08-12 18:09:07 --> Loader Class Initialized
DEBUG - 2011-08-12 18:09:07 --> Controller Class Initialized
DEBUG - 2011-08-12 18:09:07 --> Model Class Initialized
DEBUG - 2011-08-12 18:09:07 --> Model Class Initialized
DEBUG - 2011-08-12 18:09:07 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-12 18:09:07 --> Database Driver Class Initialized
DEBUG - 2011-08-12 18:09:07 --> Final output sent to browser
DEBUG - 2011-08-12 18:09:07 --> Total execution time: 0.6078
DEBUG - 2011-08-12 18:09:09 --> Config Class Initialized
DEBUG - 2011-08-12 18:09:09 --> Hooks Class Initialized
DEBUG - 2011-08-12 18:09:09 --> Utf8 Class Initialized
DEBUG - 2011-08-12 18:09:09 --> UTF-8 Support Enabled
DEBUG - 2011-08-12 18:09:09 --> URI Class Initialized
DEBUG - 2011-08-12 18:09:09 --> Router Class Initialized
ERROR - 2011-08-12 18:09:09 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-08-12 18:09:14 --> Config Class Initialized
DEBUG - 2011-08-12 18:09:14 --> Hooks Class Initialized
DEBUG - 2011-08-12 18:09:14 --> Utf8 Class Initialized
DEBUG - 2011-08-12 18:09:14 --> UTF-8 Support Enabled
DEBUG - 2011-08-12 18:09:14 --> URI Class Initialized
DEBUG - 2011-08-12 18:09:14 --> Router Class Initialized
DEBUG - 2011-08-12 18:09:14 --> Output Class Initialized
DEBUG - 2011-08-12 18:09:14 --> Input Class Initialized
DEBUG - 2011-08-12 18:09:14 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-12 18:09:14 --> Language Class Initialized
DEBUG - 2011-08-12 18:09:14 --> Loader Class Initialized
DEBUG - 2011-08-12 18:09:14 --> Controller Class Initialized
ERROR - 2011-08-12 18:09:14 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-08-12 18:09:14 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-08-12 18:09:14 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-08-12 18:09:14 --> Model Class Initialized
DEBUG - 2011-08-12 18:09:14 --> Model Class Initialized
DEBUG - 2011-08-12 18:09:14 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-12 18:09:14 --> Database Driver Class Initialized
DEBUG - 2011-08-12 18:09:14 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-08-12 18:09:14 --> Helper loaded: url_helper
DEBUG - 2011-08-12 18:09:14 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-12 18:09:14 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-12 18:09:14 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-12 18:09:14 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-12 18:09:14 --> Final output sent to browser
DEBUG - 2011-08-12 18:09:14 --> Total execution time: 0.0291
DEBUG - 2011-08-12 18:09:20 --> Config Class Initialized
DEBUG - 2011-08-12 18:09:20 --> Hooks Class Initialized
DEBUG - 2011-08-12 18:09:20 --> Utf8 Class Initialized
DEBUG - 2011-08-12 18:09:20 --> UTF-8 Support Enabled
DEBUG - 2011-08-12 18:09:20 --> URI Class Initialized
DEBUG - 2011-08-12 18:09:20 --> Router Class Initialized
DEBUG - 2011-08-12 18:09:20 --> Output Class Initialized
DEBUG - 2011-08-12 18:09:20 --> Input Class Initialized
DEBUG - 2011-08-12 18:09:20 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-12 18:09:20 --> Language Class Initialized
DEBUG - 2011-08-12 18:09:20 --> Loader Class Initialized
DEBUG - 2011-08-12 18:09:20 --> Controller Class Initialized
DEBUG - 2011-08-12 18:09:20 --> Model Class Initialized
DEBUG - 2011-08-12 18:09:20 --> Model Class Initialized
DEBUG - 2011-08-12 18:09:20 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-12 18:09:20 --> Database Driver Class Initialized
DEBUG - 2011-08-12 18:09:21 --> Final output sent to browser
DEBUG - 2011-08-12 18:09:21 --> Total execution time: 0.6468
DEBUG - 2011-08-12 18:09:23 --> Config Class Initialized
DEBUG - 2011-08-12 18:09:23 --> Hooks Class Initialized
DEBUG - 2011-08-12 18:09:23 --> Utf8 Class Initialized
DEBUG - 2011-08-12 18:09:23 --> UTF-8 Support Enabled
DEBUG - 2011-08-12 18:09:23 --> URI Class Initialized
DEBUG - 2011-08-12 18:09:23 --> Router Class Initialized
ERROR - 2011-08-12 18:09:23 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-08-12 18:09:23 --> Config Class Initialized
DEBUG - 2011-08-12 18:09:23 --> Hooks Class Initialized
DEBUG - 2011-08-12 18:09:23 --> Utf8 Class Initialized
DEBUG - 2011-08-12 18:09:23 --> UTF-8 Support Enabled
DEBUG - 2011-08-12 18:09:23 --> URI Class Initialized
DEBUG - 2011-08-12 18:09:23 --> Router Class Initialized
DEBUG - 2011-08-12 18:09:23 --> Output Class Initialized
DEBUG - 2011-08-12 18:09:23 --> Input Class Initialized
DEBUG - 2011-08-12 18:09:23 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-12 18:09:23 --> Language Class Initialized
DEBUG - 2011-08-12 18:09:23 --> Loader Class Initialized
DEBUG - 2011-08-12 18:09:23 --> Controller Class Initialized
ERROR - 2011-08-12 18:09:23 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-08-12 18:09:23 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-08-12 18:09:23 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-08-12 18:09:23 --> Model Class Initialized
DEBUG - 2011-08-12 18:09:23 --> Model Class Initialized
DEBUG - 2011-08-12 18:09:23 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-12 18:09:23 --> Database Driver Class Initialized
DEBUG - 2011-08-12 18:09:23 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-08-12 18:09:23 --> Helper loaded: url_helper
DEBUG - 2011-08-12 18:09:23 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-12 18:09:23 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-12 18:09:23 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-12 18:09:23 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-12 18:09:23 --> Final output sent to browser
DEBUG - 2011-08-12 18:09:23 --> Total execution time: 0.0377
DEBUG - 2011-08-12 18:09:28 --> Config Class Initialized
DEBUG - 2011-08-12 18:09:28 --> Hooks Class Initialized
DEBUG - 2011-08-12 18:09:28 --> Utf8 Class Initialized
DEBUG - 2011-08-12 18:09:28 --> UTF-8 Support Enabled
DEBUG - 2011-08-12 18:09:28 --> URI Class Initialized
DEBUG - 2011-08-12 18:09:28 --> Router Class Initialized
DEBUG - 2011-08-12 18:09:28 --> Output Class Initialized
DEBUG - 2011-08-12 18:09:28 --> Input Class Initialized
DEBUG - 2011-08-12 18:09:28 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-12 18:09:28 --> Language Class Initialized
DEBUG - 2011-08-12 18:09:28 --> Loader Class Initialized
DEBUG - 2011-08-12 18:09:28 --> Controller Class Initialized
ERROR - 2011-08-12 18:09:28 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-08-12 18:09:28 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-08-12 18:09:28 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-08-12 18:09:28 --> Model Class Initialized
DEBUG - 2011-08-12 18:09:28 --> Model Class Initialized
DEBUG - 2011-08-12 18:09:28 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-12 18:09:28 --> Database Driver Class Initialized
DEBUG - 2011-08-12 18:09:28 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-08-12 18:09:28 --> Helper loaded: url_helper
DEBUG - 2011-08-12 18:09:28 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-12 18:09:28 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-12 18:09:28 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-12 18:09:28 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-12 18:09:28 --> Final output sent to browser
DEBUG - 2011-08-12 18:09:28 --> Total execution time: 0.0304
DEBUG - 2011-08-12 18:09:29 --> Config Class Initialized
DEBUG - 2011-08-12 18:09:29 --> Hooks Class Initialized
DEBUG - 2011-08-12 18:09:29 --> Utf8 Class Initialized
DEBUG - 2011-08-12 18:09:29 --> UTF-8 Support Enabled
DEBUG - 2011-08-12 18:09:29 --> URI Class Initialized
DEBUG - 2011-08-12 18:09:29 --> Router Class Initialized
DEBUG - 2011-08-12 18:09:29 --> Output Class Initialized
DEBUG - 2011-08-12 18:09:29 --> Input Class Initialized
DEBUG - 2011-08-12 18:09:29 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-12 18:09:29 --> Language Class Initialized
DEBUG - 2011-08-12 18:09:29 --> Loader Class Initialized
DEBUG - 2011-08-12 18:09:29 --> Controller Class Initialized
DEBUG - 2011-08-12 18:09:29 --> Model Class Initialized
DEBUG - 2011-08-12 18:09:29 --> Model Class Initialized
DEBUG - 2011-08-12 18:09:29 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-12 18:09:29 --> Database Driver Class Initialized
DEBUG - 2011-08-12 18:09:29 --> Final output sent to browser
DEBUG - 2011-08-12 18:09:29 --> Total execution time: 0.6575
DEBUG - 2011-08-12 18:09:31 --> Config Class Initialized
DEBUG - 2011-08-12 18:09:31 --> Hooks Class Initialized
DEBUG - 2011-08-12 18:09:31 --> Utf8 Class Initialized
DEBUG - 2011-08-12 18:09:31 --> UTF-8 Support Enabled
DEBUG - 2011-08-12 18:09:31 --> URI Class Initialized
DEBUG - 2011-08-12 18:09:31 --> Router Class Initialized
ERROR - 2011-08-12 18:09:31 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-08-12 18:09:38 --> Config Class Initialized
DEBUG - 2011-08-12 18:09:38 --> Hooks Class Initialized
DEBUG - 2011-08-12 18:09:38 --> Utf8 Class Initialized
DEBUG - 2011-08-12 18:09:38 --> UTF-8 Support Enabled
DEBUG - 2011-08-12 18:09:38 --> URI Class Initialized
DEBUG - 2011-08-12 18:09:38 --> Router Class Initialized
DEBUG - 2011-08-12 18:09:38 --> Output Class Initialized
DEBUG - 2011-08-12 18:09:38 --> Input Class Initialized
DEBUG - 2011-08-12 18:09:38 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-12 18:09:38 --> Language Class Initialized
DEBUG - 2011-08-12 18:09:38 --> Loader Class Initialized
DEBUG - 2011-08-12 18:09:38 --> Controller Class Initialized
ERROR - 2011-08-12 18:09:38 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-08-12 18:09:38 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-08-12 18:09:38 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-08-12 18:09:38 --> Model Class Initialized
DEBUG - 2011-08-12 18:09:38 --> Model Class Initialized
DEBUG - 2011-08-12 18:09:38 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-12 18:09:38 --> Database Driver Class Initialized
DEBUG - 2011-08-12 18:09:39 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-08-12 18:09:39 --> Helper loaded: url_helper
DEBUG - 2011-08-12 18:09:39 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-12 18:09:39 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-12 18:09:39 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-12 18:09:39 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-12 18:09:39 --> Final output sent to browser
DEBUG - 2011-08-12 18:09:39 --> Total execution time: 0.1408
DEBUG - 2011-08-12 18:09:40 --> Config Class Initialized
DEBUG - 2011-08-12 18:09:40 --> Hooks Class Initialized
DEBUG - 2011-08-12 18:09:40 --> Utf8 Class Initialized
DEBUG - 2011-08-12 18:09:40 --> UTF-8 Support Enabled
DEBUG - 2011-08-12 18:09:40 --> URI Class Initialized
DEBUG - 2011-08-12 18:09:40 --> Router Class Initialized
DEBUG - 2011-08-12 18:09:40 --> Output Class Initialized
DEBUG - 2011-08-12 18:09:40 --> Input Class Initialized
DEBUG - 2011-08-12 18:09:40 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-12 18:09:40 --> Language Class Initialized
DEBUG - 2011-08-12 18:09:40 --> Loader Class Initialized
DEBUG - 2011-08-12 18:09:40 --> Controller Class Initialized
DEBUG - 2011-08-12 18:09:40 --> Model Class Initialized
DEBUG - 2011-08-12 18:09:40 --> Model Class Initialized
DEBUG - 2011-08-12 18:09:40 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-12 18:09:40 --> Database Driver Class Initialized
DEBUG - 2011-08-12 18:09:40 --> Final output sent to browser
DEBUG - 2011-08-12 18:09:40 --> Total execution time: 0.6686
DEBUG - 2011-08-12 18:09:42 --> Config Class Initialized
DEBUG - 2011-08-12 18:09:42 --> Hooks Class Initialized
DEBUG - 2011-08-12 18:09:42 --> Utf8 Class Initialized
DEBUG - 2011-08-12 18:09:42 --> UTF-8 Support Enabled
DEBUG - 2011-08-12 18:09:42 --> URI Class Initialized
DEBUG - 2011-08-12 18:09:42 --> Router Class Initialized
ERROR - 2011-08-12 18:09:42 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-08-12 18:09:49 --> Config Class Initialized
DEBUG - 2011-08-12 18:09:49 --> Hooks Class Initialized
DEBUG - 2011-08-12 18:09:49 --> Utf8 Class Initialized
DEBUG - 2011-08-12 18:09:49 --> UTF-8 Support Enabled
DEBUG - 2011-08-12 18:09:49 --> URI Class Initialized
DEBUG - 2011-08-12 18:09:49 --> Router Class Initialized
DEBUG - 2011-08-12 18:09:49 --> Output Class Initialized
DEBUG - 2011-08-12 18:09:49 --> Input Class Initialized
DEBUG - 2011-08-12 18:09:49 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-12 18:09:49 --> Language Class Initialized
DEBUG - 2011-08-12 18:09:49 --> Loader Class Initialized
DEBUG - 2011-08-12 18:09:49 --> Controller Class Initialized
ERROR - 2011-08-12 18:09:49 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-08-12 18:09:49 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-08-12 18:09:49 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-08-12 18:09:49 --> Model Class Initialized
DEBUG - 2011-08-12 18:09:49 --> Model Class Initialized
DEBUG - 2011-08-12 18:09:49 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-12 18:09:49 --> Database Driver Class Initialized
DEBUG - 2011-08-12 18:09:49 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-08-12 18:09:49 --> Helper loaded: url_helper
DEBUG - 2011-08-12 18:09:49 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-12 18:09:49 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-12 18:09:49 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-12 18:09:49 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-12 18:09:49 --> Final output sent to browser
DEBUG - 2011-08-12 18:09:49 --> Total execution time: 0.0294
DEBUG - 2011-08-12 18:09:50 --> Config Class Initialized
DEBUG - 2011-08-12 18:09:50 --> Hooks Class Initialized
DEBUG - 2011-08-12 18:09:50 --> Utf8 Class Initialized
DEBUG - 2011-08-12 18:09:50 --> UTF-8 Support Enabled
DEBUG - 2011-08-12 18:09:50 --> URI Class Initialized
DEBUG - 2011-08-12 18:09:50 --> Router Class Initialized
DEBUG - 2011-08-12 18:09:50 --> Output Class Initialized
DEBUG - 2011-08-12 18:09:50 --> Input Class Initialized
DEBUG - 2011-08-12 18:09:50 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-12 18:09:50 --> Language Class Initialized
DEBUG - 2011-08-12 18:09:50 --> Loader Class Initialized
DEBUG - 2011-08-12 18:09:50 --> Controller Class Initialized
DEBUG - 2011-08-12 18:09:50 --> Model Class Initialized
DEBUG - 2011-08-12 18:09:50 --> Model Class Initialized
DEBUG - 2011-08-12 18:09:50 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-12 18:09:50 --> Database Driver Class Initialized
DEBUG - 2011-08-12 18:09:51 --> Final output sent to browser
DEBUG - 2011-08-12 18:09:51 --> Total execution time: 0.5657
DEBUG - 2011-08-12 18:09:52 --> Config Class Initialized
DEBUG - 2011-08-12 18:09:52 --> Hooks Class Initialized
DEBUG - 2011-08-12 18:09:52 --> Utf8 Class Initialized
DEBUG - 2011-08-12 18:09:52 --> UTF-8 Support Enabled
DEBUG - 2011-08-12 18:09:52 --> URI Class Initialized
DEBUG - 2011-08-12 18:09:52 --> Router Class Initialized
ERROR - 2011-08-12 18:09:52 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-08-12 18:09:58 --> Config Class Initialized
DEBUG - 2011-08-12 18:09:58 --> Hooks Class Initialized
DEBUG - 2011-08-12 18:09:58 --> Utf8 Class Initialized
DEBUG - 2011-08-12 18:09:58 --> UTF-8 Support Enabled
DEBUG - 2011-08-12 18:09:58 --> URI Class Initialized
DEBUG - 2011-08-12 18:09:58 --> Router Class Initialized
ERROR - 2011-08-12 18:09:58 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-08-12 18:09:59 --> Config Class Initialized
DEBUG - 2011-08-12 18:09:59 --> Hooks Class Initialized
DEBUG - 2011-08-12 18:09:59 --> Utf8 Class Initialized
DEBUG - 2011-08-12 18:09:59 --> UTF-8 Support Enabled
DEBUG - 2011-08-12 18:09:59 --> URI Class Initialized
DEBUG - 2011-08-12 18:09:59 --> Router Class Initialized
ERROR - 2011-08-12 18:09:59 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-08-12 18:10:00 --> Config Class Initialized
DEBUG - 2011-08-12 18:10:00 --> Hooks Class Initialized
DEBUG - 2011-08-12 18:10:00 --> Utf8 Class Initialized
DEBUG - 2011-08-12 18:10:00 --> UTF-8 Support Enabled
DEBUG - 2011-08-12 18:10:00 --> URI Class Initialized
DEBUG - 2011-08-12 18:10:00 --> Router Class Initialized
ERROR - 2011-08-12 18:10:00 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-08-12 18:10:10 --> Config Class Initialized
DEBUG - 2011-08-12 18:10:10 --> Hooks Class Initialized
DEBUG - 2011-08-12 18:10:10 --> Utf8 Class Initialized
DEBUG - 2011-08-12 18:10:10 --> UTF-8 Support Enabled
DEBUG - 2011-08-12 18:10:10 --> URI Class Initialized
DEBUG - 2011-08-12 18:10:10 --> Router Class Initialized
DEBUG - 2011-08-12 18:10:10 --> Config Class Initialized
DEBUG - 2011-08-12 18:10:10 --> Hooks Class Initialized
DEBUG - 2011-08-12 18:10:10 --> Utf8 Class Initialized
DEBUG - 2011-08-12 18:10:10 --> UTF-8 Support Enabled
DEBUG - 2011-08-12 18:10:10 --> URI Class Initialized
DEBUG - 2011-08-12 18:10:10 --> Router Class Initialized
DEBUG - 2011-08-12 18:10:10 --> Output Class Initialized
DEBUG - 2011-08-12 18:10:10 --> Input Class Initialized
DEBUG - 2011-08-12 18:10:10 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-12 18:10:10 --> Language Class Initialized
DEBUG - 2011-08-12 18:10:10 --> Output Class Initialized
DEBUG - 2011-08-12 18:10:10 --> Input Class Initialized
DEBUG - 2011-08-12 18:10:10 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-12 18:10:10 --> Language Class Initialized
DEBUG - 2011-08-12 18:10:10 --> Loader Class Initialized
DEBUG - 2011-08-12 18:10:10 --> Loader Class Initialized
DEBUG - 2011-08-12 18:10:10 --> Controller Class Initialized
DEBUG - 2011-08-12 18:10:10 --> Controller Class Initialized
DEBUG - 2011-08-12 18:10:10 --> Model Class Initialized
DEBUG - 2011-08-12 18:10:10 --> Model Class Initialized
DEBUG - 2011-08-12 18:10:10 --> Model Class Initialized
DEBUG - 2011-08-12 18:10:10 --> Model Class Initialized
DEBUG - 2011-08-12 18:10:10 --> Model Class Initialized
DEBUG - 2011-08-12 18:10:10 --> Model Class Initialized
DEBUG - 2011-08-12 18:10:10 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-12 18:10:10 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-12 18:10:10 --> Database Driver Class Initialized
DEBUG - 2011-08-12 18:10:10 --> Database Driver Class Initialized
DEBUG - 2011-08-12 18:10:11 --> File loaded: application/views/table/main.php
DEBUG - 2011-08-12 18:10:11 --> Helper loaded: url_helper
DEBUG - 2011-08-12 18:10:11 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-12 18:10:11 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-12 18:10:11 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-12 18:10:11 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-12 18:10:11 --> Final output sent to browser
DEBUG - 2011-08-12 18:10:11 --> File loaded: application/views/table/main.php
DEBUG - 2011-08-12 18:10:11 --> Total execution time: 0.4931
DEBUG - 2011-08-12 18:10:11 --> Helper loaded: url_helper
DEBUG - 2011-08-12 18:10:11 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-12 18:10:11 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-12 18:10:11 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-12 18:10:11 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-12 18:10:11 --> Final output sent to browser
DEBUG - 2011-08-12 18:10:11 --> Total execution time: 0.5023
DEBUG - 2011-08-12 18:10:12 --> Config Class Initialized
DEBUG - 2011-08-12 18:10:12 --> Hooks Class Initialized
DEBUG - 2011-08-12 18:10:12 --> Utf8 Class Initialized
DEBUG - 2011-08-12 18:10:12 --> UTF-8 Support Enabled
DEBUG - 2011-08-12 18:10:12 --> URI Class Initialized
DEBUG - 2011-08-12 18:10:12 --> Router Class Initialized
ERROR - 2011-08-12 18:10:12 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-08-12 18:10:30 --> Config Class Initialized
DEBUG - 2011-08-12 18:10:30 --> Hooks Class Initialized
DEBUG - 2011-08-12 18:10:30 --> Utf8 Class Initialized
DEBUG - 2011-08-12 18:10:30 --> UTF-8 Support Enabled
DEBUG - 2011-08-12 18:10:30 --> URI Class Initialized
DEBUG - 2011-08-12 18:10:30 --> Router Class Initialized
DEBUG - 2011-08-12 18:10:30 --> Output Class Initialized
DEBUG - 2011-08-12 18:10:30 --> Input Class Initialized
DEBUG - 2011-08-12 18:10:30 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-12 18:10:30 --> Language Class Initialized
DEBUG - 2011-08-12 18:10:30 --> Loader Class Initialized
DEBUG - 2011-08-12 18:10:30 --> Controller Class Initialized
DEBUG - 2011-08-12 18:10:30 --> Model Class Initialized
DEBUG - 2011-08-12 18:10:30 --> Model Class Initialized
DEBUG - 2011-08-12 18:10:30 --> Model Class Initialized
DEBUG - 2011-08-12 18:10:30 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-12 18:10:30 --> Database Driver Class Initialized
DEBUG - 2011-08-12 18:10:31 --> File loaded: application/views/table/main.php
DEBUG - 2011-08-12 18:10:31 --> Helper loaded: url_helper
DEBUG - 2011-08-12 18:10:31 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-12 18:10:31 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-12 18:10:31 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-12 18:10:31 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-12 18:10:31 --> Final output sent to browser
DEBUG - 2011-08-12 18:10:31 --> Total execution time: 0.4223
DEBUG - 2011-08-12 18:10:32 --> Config Class Initialized
DEBUG - 2011-08-12 18:10:32 --> Hooks Class Initialized
DEBUG - 2011-08-12 18:10:32 --> Utf8 Class Initialized
DEBUG - 2011-08-12 18:10:32 --> UTF-8 Support Enabled
DEBUG - 2011-08-12 18:10:32 --> URI Class Initialized
DEBUG - 2011-08-12 18:10:32 --> Router Class Initialized
ERROR - 2011-08-12 18:10:32 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-08-12 18:10:53 --> Config Class Initialized
DEBUG - 2011-08-12 18:10:53 --> Hooks Class Initialized
DEBUG - 2011-08-12 18:10:53 --> Utf8 Class Initialized
DEBUG - 2011-08-12 18:10:53 --> UTF-8 Support Enabled
DEBUG - 2011-08-12 18:10:53 --> URI Class Initialized
DEBUG - 2011-08-12 18:10:53 --> Router Class Initialized
DEBUG - 2011-08-12 18:10:53 --> Output Class Initialized
DEBUG - 2011-08-12 18:10:53 --> Input Class Initialized
DEBUG - 2011-08-12 18:10:53 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-12 18:10:53 --> Language Class Initialized
DEBUG - 2011-08-12 18:10:53 --> Loader Class Initialized
DEBUG - 2011-08-12 18:10:53 --> Controller Class Initialized
DEBUG - 2011-08-12 18:10:53 --> Model Class Initialized
DEBUG - 2011-08-12 18:10:53 --> Model Class Initialized
DEBUG - 2011-08-12 18:10:53 --> Model Class Initialized
DEBUG - 2011-08-12 18:10:53 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-12 18:10:53 --> Database Driver Class Initialized
DEBUG - 2011-08-12 18:10:53 --> File loaded: application/views/table/main.php
DEBUG - 2011-08-12 18:10:53 --> Helper loaded: url_helper
DEBUG - 2011-08-12 18:10:53 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-12 18:10:53 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-12 18:10:53 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-12 18:10:53 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-12 18:10:53 --> Final output sent to browser
DEBUG - 2011-08-12 18:10:53 --> Total execution time: 0.2270
DEBUG - 2011-08-12 18:10:55 --> Config Class Initialized
DEBUG - 2011-08-12 18:10:55 --> Hooks Class Initialized
DEBUG - 2011-08-12 18:10:55 --> Utf8 Class Initialized
DEBUG - 2011-08-12 18:10:55 --> UTF-8 Support Enabled
DEBUG - 2011-08-12 18:10:55 --> URI Class Initialized
DEBUG - 2011-08-12 18:10:55 --> Router Class Initialized
ERROR - 2011-08-12 18:10:55 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-08-12 18:11:15 --> Config Class Initialized
DEBUG - 2011-08-12 18:11:15 --> Hooks Class Initialized
DEBUG - 2011-08-12 18:11:15 --> Utf8 Class Initialized
DEBUG - 2011-08-12 18:11:15 --> UTF-8 Support Enabled
DEBUG - 2011-08-12 18:11:15 --> URI Class Initialized
DEBUG - 2011-08-12 18:11:15 --> Router Class Initialized
DEBUG - 2011-08-12 18:11:15 --> Output Class Initialized
DEBUG - 2011-08-12 18:11:15 --> Input Class Initialized
DEBUG - 2011-08-12 18:11:15 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-12 18:11:15 --> Language Class Initialized
DEBUG - 2011-08-12 18:11:15 --> Loader Class Initialized
DEBUG - 2011-08-12 18:11:15 --> Controller Class Initialized
DEBUG - 2011-08-12 18:11:15 --> Model Class Initialized
DEBUG - 2011-08-12 18:11:15 --> Model Class Initialized
DEBUG - 2011-08-12 18:11:15 --> Model Class Initialized
DEBUG - 2011-08-12 18:11:15 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-12 18:11:15 --> Database Driver Class Initialized
DEBUG - 2011-08-12 18:11:15 --> File loaded: application/views/table/main.php
DEBUG - 2011-08-12 18:11:15 --> Helper loaded: url_helper
DEBUG - 2011-08-12 18:11:15 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-12 18:11:15 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-12 18:11:15 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-12 18:11:15 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-12 18:11:15 --> Final output sent to browser
DEBUG - 2011-08-12 18:11:15 --> Total execution time: 0.2653
DEBUG - 2011-08-12 18:11:17 --> Config Class Initialized
DEBUG - 2011-08-12 18:11:17 --> Hooks Class Initialized
DEBUG - 2011-08-12 18:11:17 --> Utf8 Class Initialized
DEBUG - 2011-08-12 18:11:17 --> UTF-8 Support Enabled
DEBUG - 2011-08-12 18:11:17 --> URI Class Initialized
DEBUG - 2011-08-12 18:11:17 --> Router Class Initialized
ERROR - 2011-08-12 18:11:17 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-08-12 18:11:23 --> Config Class Initialized
DEBUG - 2011-08-12 18:11:23 --> Hooks Class Initialized
DEBUG - 2011-08-12 18:11:23 --> Utf8 Class Initialized
DEBUG - 2011-08-12 18:11:23 --> UTF-8 Support Enabled
DEBUG - 2011-08-12 18:11:23 --> URI Class Initialized
DEBUG - 2011-08-12 18:11:23 --> Router Class Initialized
DEBUG - 2011-08-12 18:11:23 --> Output Class Initialized
DEBUG - 2011-08-12 18:11:23 --> Input Class Initialized
DEBUG - 2011-08-12 18:11:23 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-12 18:11:23 --> Language Class Initialized
DEBUG - 2011-08-12 18:11:23 --> Loader Class Initialized
DEBUG - 2011-08-12 18:11:23 --> Controller Class Initialized
DEBUG - 2011-08-12 18:11:23 --> Model Class Initialized
DEBUG - 2011-08-12 18:11:23 --> Model Class Initialized
DEBUG - 2011-08-12 18:11:23 --> Model Class Initialized
DEBUG - 2011-08-12 18:11:23 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-12 18:11:23 --> Database Driver Class Initialized
DEBUG - 2011-08-12 18:11:23 --> File loaded: application/views/table/main.php
DEBUG - 2011-08-12 18:11:23 --> Helper loaded: url_helper
DEBUG - 2011-08-12 18:11:23 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-12 18:11:23 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-12 18:11:23 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-12 18:11:23 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-12 18:11:23 --> Final output sent to browser
DEBUG - 2011-08-12 18:11:23 --> Total execution time: 0.3142
DEBUG - 2011-08-12 18:11:25 --> Config Class Initialized
DEBUG - 2011-08-12 18:11:25 --> Hooks Class Initialized
DEBUG - 2011-08-12 18:11:25 --> Utf8 Class Initialized
DEBUG - 2011-08-12 18:11:25 --> UTF-8 Support Enabled
DEBUG - 2011-08-12 18:11:25 --> URI Class Initialized
DEBUG - 2011-08-12 18:11:25 --> Router Class Initialized
ERROR - 2011-08-12 18:11:25 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-08-12 18:30:35 --> Config Class Initialized
DEBUG - 2011-08-12 18:30:35 --> Hooks Class Initialized
DEBUG - 2011-08-12 18:30:35 --> Utf8 Class Initialized
DEBUG - 2011-08-12 18:30:35 --> UTF-8 Support Enabled
DEBUG - 2011-08-12 18:30:35 --> URI Class Initialized
DEBUG - 2011-08-12 18:30:35 --> Router Class Initialized
ERROR - 2011-08-12 18:30:35 --> 404 Page Not Found --> robots.txt
DEBUG - 2011-08-12 18:31:24 --> Config Class Initialized
DEBUG - 2011-08-12 18:31:24 --> Hooks Class Initialized
DEBUG - 2011-08-12 18:31:24 --> Utf8 Class Initialized
DEBUG - 2011-08-12 18:31:24 --> UTF-8 Support Enabled
DEBUG - 2011-08-12 18:31:24 --> URI Class Initialized
DEBUG - 2011-08-12 18:31:24 --> Router Class Initialized
DEBUG - 2011-08-12 18:31:24 --> No URI present. Default controller set.
DEBUG - 2011-08-12 18:31:24 --> Output Class Initialized
DEBUG - 2011-08-12 18:31:24 --> Input Class Initialized
DEBUG - 2011-08-12 18:31:24 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-12 18:31:24 --> Language Class Initialized
DEBUG - 2011-08-12 18:31:24 --> Loader Class Initialized
DEBUG - 2011-08-12 18:31:24 --> Controller Class Initialized
DEBUG - 2011-08-12 18:31:24 --> File loaded: application/views/splash/main.php
DEBUG - 2011-08-12 18:31:24 --> Helper loaded: url_helper
DEBUG - 2011-08-12 18:31:24 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-12 18:31:24 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-12 18:31:24 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-12 18:31:24 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-12 18:31:24 --> Final output sent to browser
DEBUG - 2011-08-12 18:31:24 --> Total execution time: 0.6141
DEBUG - 2011-08-12 18:53:07 --> Config Class Initialized
DEBUG - 2011-08-12 18:53:07 --> Hooks Class Initialized
DEBUG - 2011-08-12 18:53:07 --> Utf8 Class Initialized
DEBUG - 2011-08-12 18:53:07 --> UTF-8 Support Enabled
DEBUG - 2011-08-12 18:53:07 --> URI Class Initialized
DEBUG - 2011-08-12 18:53:07 --> Router Class Initialized
ERROR - 2011-08-12 18:53:07 --> 404 Page Not Found --> robots.txt
DEBUG - 2011-08-12 18:53:08 --> Config Class Initialized
DEBUG - 2011-08-12 18:53:08 --> Hooks Class Initialized
DEBUG - 2011-08-12 18:53:08 --> Utf8 Class Initialized
DEBUG - 2011-08-12 18:53:08 --> UTF-8 Support Enabled
DEBUG - 2011-08-12 18:53:08 --> URI Class Initialized
DEBUG - 2011-08-12 18:53:08 --> Router Class Initialized
DEBUG - 2011-08-12 18:53:08 --> No URI present. Default controller set.
DEBUG - 2011-08-12 18:53:08 --> Output Class Initialized
DEBUG - 2011-08-12 18:53:08 --> Input Class Initialized
DEBUG - 2011-08-12 18:53:08 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-12 18:53:08 --> Language Class Initialized
DEBUG - 2011-08-12 18:53:08 --> Loader Class Initialized
DEBUG - 2011-08-12 18:53:08 --> Controller Class Initialized
DEBUG - 2011-08-12 18:53:08 --> File loaded: application/views/splash/main.php
DEBUG - 2011-08-12 18:53:08 --> Helper loaded: url_helper
DEBUG - 2011-08-12 18:53:08 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-12 18:53:08 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-12 18:53:08 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-12 18:53:08 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-12 18:53:08 --> Final output sent to browser
DEBUG - 2011-08-12 18:53:08 --> Total execution time: 0.0153
DEBUG - 2011-08-12 18:53:09 --> Config Class Initialized
DEBUG - 2011-08-12 18:53:09 --> Hooks Class Initialized
DEBUG - 2011-08-12 18:53:09 --> Utf8 Class Initialized
DEBUG - 2011-08-12 18:53:09 --> UTF-8 Support Enabled
DEBUG - 2011-08-12 18:53:09 --> URI Class Initialized
DEBUG - 2011-08-12 18:53:09 --> Router Class Initialized
DEBUG - 2011-08-12 18:53:09 --> Output Class Initialized
DEBUG - 2011-08-12 18:53:09 --> Input Class Initialized
DEBUG - 2011-08-12 18:53:09 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-12 18:53:09 --> Language Class Initialized
DEBUG - 2011-08-12 18:53:09 --> Loader Class Initialized
DEBUG - 2011-08-12 18:53:09 --> Controller Class Initialized
DEBUG - 2011-08-12 18:53:09 --> Model Class Initialized
DEBUG - 2011-08-12 18:53:09 --> Model Class Initialized
DEBUG - 2011-08-12 18:53:09 --> Model Class Initialized
DEBUG - 2011-08-12 18:53:09 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-12 18:53:09 --> Database Driver Class Initialized
DEBUG - 2011-08-12 18:53:09 --> File loaded: application/views/table/main.php
DEBUG - 2011-08-12 18:53:09 --> Helper loaded: url_helper
DEBUG - 2011-08-12 18:53:09 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-12 18:53:09 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-12 18:53:09 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-12 18:53:09 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-12 18:53:09 --> Final output sent to browser
DEBUG - 2011-08-12 18:53:09 --> Total execution time: 0.3066
DEBUG - 2011-08-12 18:53:10 --> Config Class Initialized
DEBUG - 2011-08-12 18:53:10 --> Hooks Class Initialized
DEBUG - 2011-08-12 18:53:10 --> Utf8 Class Initialized
DEBUG - 2011-08-12 18:53:10 --> UTF-8 Support Enabled
DEBUG - 2011-08-12 18:53:10 --> URI Class Initialized
DEBUG - 2011-08-12 18:53:10 --> Router Class Initialized
DEBUG - 2011-08-12 18:53:10 --> Output Class Initialized
DEBUG - 2011-08-12 18:53:10 --> Input Class Initialized
DEBUG - 2011-08-12 18:53:10 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-12 18:53:10 --> Language Class Initialized
DEBUG - 2011-08-12 18:53:10 --> Loader Class Initialized
DEBUG - 2011-08-12 18:53:10 --> Controller Class Initialized
ERROR - 2011-08-12 18:53:10 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-08-12 18:53:10 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-08-12 18:53:10 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-08-12 18:53:10 --> Model Class Initialized
DEBUG - 2011-08-12 18:53:10 --> Model Class Initialized
DEBUG - 2011-08-12 18:53:10 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-12 18:53:10 --> Database Driver Class Initialized
DEBUG - 2011-08-12 18:53:10 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-08-12 18:53:10 --> Helper loaded: url_helper
DEBUG - 2011-08-12 18:53:10 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-12 18:53:10 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-12 18:53:10 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-12 18:53:10 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-12 18:53:10 --> Final output sent to browser
DEBUG - 2011-08-12 18:53:10 --> Total execution time: 0.0300
DEBUG - 2011-08-12 19:13:25 --> Config Class Initialized
DEBUG - 2011-08-12 19:13:25 --> Hooks Class Initialized
DEBUG - 2011-08-12 19:13:25 --> Utf8 Class Initialized
DEBUG - 2011-08-12 19:13:25 --> UTF-8 Support Enabled
DEBUG - 2011-08-12 19:13:25 --> URI Class Initialized
DEBUG - 2011-08-12 19:13:25 --> Router Class Initialized
DEBUG - 2011-08-12 19:13:25 --> Output Class Initialized
DEBUG - 2011-08-12 19:13:25 --> Input Class Initialized
DEBUG - 2011-08-12 19:13:25 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-12 19:13:25 --> Language Class Initialized
DEBUG - 2011-08-12 19:13:25 --> Loader Class Initialized
DEBUG - 2011-08-12 19:13:25 --> Controller Class Initialized
DEBUG - 2011-08-12 19:13:25 --> Model Class Initialized
DEBUG - 2011-08-12 19:13:25 --> Model Class Initialized
DEBUG - 2011-08-12 19:13:25 --> Model Class Initialized
DEBUG - 2011-08-12 19:13:25 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-12 19:13:26 --> Database Driver Class Initialized
DEBUG - 2011-08-12 19:13:26 --> File loaded: application/views/table/main.php
DEBUG - 2011-08-12 19:13:26 --> Helper loaded: url_helper
DEBUG - 2011-08-12 19:13:26 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-12 19:13:26 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-12 19:13:26 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-12 19:13:26 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-12 19:13:26 --> Final output sent to browser
DEBUG - 2011-08-12 19:13:26 --> Total execution time: 0.2994
DEBUG - 2011-08-12 19:18:11 --> Config Class Initialized
DEBUG - 2011-08-12 19:18:11 --> Hooks Class Initialized
DEBUG - 2011-08-12 19:18:11 --> Utf8 Class Initialized
DEBUG - 2011-08-12 19:18:11 --> UTF-8 Support Enabled
DEBUG - 2011-08-12 19:18:11 --> URI Class Initialized
DEBUG - 2011-08-12 19:18:11 --> Router Class Initialized
DEBUG - 2011-08-12 19:18:11 --> No URI present. Default controller set.
DEBUG - 2011-08-12 19:18:11 --> Output Class Initialized
DEBUG - 2011-08-12 19:18:11 --> Input Class Initialized
DEBUG - 2011-08-12 19:18:11 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-12 19:18:11 --> Language Class Initialized
DEBUG - 2011-08-12 19:18:11 --> Loader Class Initialized
DEBUG - 2011-08-12 19:18:11 --> Controller Class Initialized
DEBUG - 2011-08-12 19:18:11 --> File loaded: application/views/splash/main.php
DEBUG - 2011-08-12 19:18:11 --> Helper loaded: url_helper
DEBUG - 2011-08-12 19:18:11 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-12 19:18:11 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-12 19:18:11 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-12 19:18:11 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-12 19:18:11 --> Final output sent to browser
DEBUG - 2011-08-12 19:18:11 --> Total execution time: 0.0125
DEBUG - 2011-08-12 19:52:52 --> Config Class Initialized
DEBUG - 2011-08-12 19:52:52 --> Hooks Class Initialized
DEBUG - 2011-08-12 19:52:52 --> Utf8 Class Initialized
DEBUG - 2011-08-12 19:52:52 --> UTF-8 Support Enabled
DEBUG - 2011-08-12 19:52:52 --> URI Class Initialized
DEBUG - 2011-08-12 19:52:52 --> Router Class Initialized
DEBUG - 2011-08-12 19:52:52 --> No URI present. Default controller set.
DEBUG - 2011-08-12 19:52:52 --> Output Class Initialized
DEBUG - 2011-08-12 19:52:52 --> Input Class Initialized
DEBUG - 2011-08-12 19:52:52 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-12 19:52:52 --> Language Class Initialized
DEBUG - 2011-08-12 19:52:52 --> Loader Class Initialized
DEBUG - 2011-08-12 19:52:52 --> Controller Class Initialized
DEBUG - 2011-08-12 19:52:52 --> File loaded: application/views/splash/main.php
DEBUG - 2011-08-12 19:52:52 --> Helper loaded: url_helper
DEBUG - 2011-08-12 19:52:52 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-12 19:52:52 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-12 19:52:52 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-12 19:52:52 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-12 19:52:52 --> Final output sent to browser
DEBUG - 2011-08-12 19:52:52 --> Total execution time: 0.0202
DEBUG - 2011-08-12 20:10:22 --> Config Class Initialized
DEBUG - 2011-08-12 20:10:22 --> Hooks Class Initialized
DEBUG - 2011-08-12 20:10:22 --> Utf8 Class Initialized
DEBUG - 2011-08-12 20:10:22 --> UTF-8 Support Enabled
DEBUG - 2011-08-12 20:10:22 --> URI Class Initialized
DEBUG - 2011-08-12 20:10:22 --> Router Class Initialized
DEBUG - 2011-08-12 20:10:22 --> Output Class Initialized
DEBUG - 2011-08-12 20:10:22 --> Input Class Initialized
DEBUG - 2011-08-12 20:10:22 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-12 20:10:22 --> Language Class Initialized
DEBUG - 2011-08-12 20:10:22 --> Loader Class Initialized
DEBUG - 2011-08-12 20:10:22 --> Controller Class Initialized
DEBUG - 2011-08-12 20:10:22 --> Model Class Initialized
DEBUG - 2011-08-12 20:10:22 --> Model Class Initialized
DEBUG - 2011-08-12 20:10:22 --> Model Class Initialized
DEBUG - 2011-08-12 20:10:22 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-12 20:10:22 --> Database Driver Class Initialized
DEBUG - 2011-08-12 20:10:22 --> File loaded: application/views/table/main.php
DEBUG - 2011-08-12 20:10:22 --> Helper loaded: url_helper
DEBUG - 2011-08-12 20:10:22 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-12 20:10:22 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-12 20:10:22 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-12 20:10:22 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-12 20:10:22 --> Final output sent to browser
DEBUG - 2011-08-12 20:10:22 --> Total execution time: 0.3106
DEBUG - 2011-08-12 20:10:25 --> Config Class Initialized
DEBUG - 2011-08-12 20:10:25 --> Hooks Class Initialized
DEBUG - 2011-08-12 20:10:25 --> Utf8 Class Initialized
DEBUG - 2011-08-12 20:10:25 --> UTF-8 Support Enabled
DEBUG - 2011-08-12 20:10:25 --> URI Class Initialized
DEBUG - 2011-08-12 20:10:25 --> Router Class Initialized
ERROR - 2011-08-12 20:10:25 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-08-12 20:47:01 --> Config Class Initialized
DEBUG - 2011-08-12 20:47:01 --> Hooks Class Initialized
DEBUG - 2011-08-12 20:47:01 --> Utf8 Class Initialized
DEBUG - 2011-08-12 20:47:01 --> UTF-8 Support Enabled
DEBUG - 2011-08-12 20:47:01 --> URI Class Initialized
DEBUG - 2011-08-12 20:47:01 --> Router Class Initialized
DEBUG - 2011-08-12 20:47:01 --> Output Class Initialized
DEBUG - 2011-08-12 20:47:01 --> Input Class Initialized
DEBUG - 2011-08-12 20:47:01 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-12 20:47:01 --> Language Class Initialized
DEBUG - 2011-08-12 20:47:01 --> Loader Class Initialized
DEBUG - 2011-08-12 20:47:01 --> Controller Class Initialized
ERROR - 2011-08-12 20:47:01 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-08-12 20:47:01 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-08-12 20:47:01 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-08-12 20:47:01 --> Model Class Initialized
DEBUG - 2011-08-12 20:47:01 --> Model Class Initialized
DEBUG - 2011-08-12 20:47:01 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-12 20:47:01 --> Database Driver Class Initialized
DEBUG - 2011-08-12 20:47:01 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-08-12 20:47:01 --> Helper loaded: url_helper
DEBUG - 2011-08-12 20:47:01 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-12 20:47:01 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-12 20:47:01 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-12 20:47:01 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-12 20:47:01 --> Final output sent to browser
DEBUG - 2011-08-12 20:47:01 --> Total execution time: 0.0796
DEBUG - 2011-08-12 20:47:02 --> Config Class Initialized
DEBUG - 2011-08-12 20:47:02 --> Hooks Class Initialized
DEBUG - 2011-08-12 20:47:02 --> Utf8 Class Initialized
DEBUG - 2011-08-12 20:47:02 --> UTF-8 Support Enabled
DEBUG - 2011-08-12 20:47:02 --> URI Class Initialized
DEBUG - 2011-08-12 20:47:02 --> Router Class Initialized
DEBUG - 2011-08-12 20:47:02 --> Output Class Initialized
DEBUG - 2011-08-12 20:47:02 --> Input Class Initialized
DEBUG - 2011-08-12 20:47:02 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-12 20:47:02 --> Language Class Initialized
DEBUG - 2011-08-12 20:47:02 --> Loader Class Initialized
DEBUG - 2011-08-12 20:47:02 --> Controller Class Initialized
DEBUG - 2011-08-12 20:47:02 --> Model Class Initialized
DEBUG - 2011-08-12 20:47:02 --> Model Class Initialized
DEBUG - 2011-08-12 20:47:02 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-12 20:47:02 --> Database Driver Class Initialized
DEBUG - 2011-08-12 20:47:03 --> Final output sent to browser
DEBUG - 2011-08-12 20:47:03 --> Total execution time: 0.5657
DEBUG - 2011-08-12 20:47:04 --> Config Class Initialized
DEBUG - 2011-08-12 20:47:04 --> Hooks Class Initialized
DEBUG - 2011-08-12 20:47:04 --> Utf8 Class Initialized
DEBUG - 2011-08-12 20:47:04 --> UTF-8 Support Enabled
DEBUG - 2011-08-12 20:47:04 --> URI Class Initialized
DEBUG - 2011-08-12 20:47:04 --> Router Class Initialized
ERROR - 2011-08-12 20:47:04 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-08-12 20:52:36 --> Config Class Initialized
DEBUG - 2011-08-12 20:52:36 --> Hooks Class Initialized
DEBUG - 2011-08-12 20:52:36 --> Utf8 Class Initialized
DEBUG - 2011-08-12 20:52:36 --> UTF-8 Support Enabled
DEBUG - 2011-08-12 20:52:36 --> URI Class Initialized
DEBUG - 2011-08-12 20:52:36 --> Router Class Initialized
DEBUG - 2011-08-12 20:52:36 --> Output Class Initialized
DEBUG - 2011-08-12 20:52:36 --> Input Class Initialized
DEBUG - 2011-08-12 20:52:36 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-12 20:52:36 --> Language Class Initialized
DEBUG - 2011-08-12 20:52:36 --> Loader Class Initialized
DEBUG - 2011-08-12 20:52:36 --> Controller Class Initialized
DEBUG - 2011-08-12 20:52:36 --> Model Class Initialized
DEBUG - 2011-08-12 20:52:36 --> Model Class Initialized
DEBUG - 2011-08-12 20:52:36 --> Model Class Initialized
DEBUG - 2011-08-12 20:52:36 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-12 20:52:36 --> Database Driver Class Initialized
DEBUG - 2011-08-12 20:52:36 --> File loaded: application/views/table/main.php
DEBUG - 2011-08-12 20:52:36 --> Helper loaded: url_helper
DEBUG - 2011-08-12 20:52:36 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-12 20:52:36 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-12 20:52:36 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-12 20:52:36 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-12 20:52:36 --> Final output sent to browser
DEBUG - 2011-08-12 20:52:36 --> Total execution time: 0.2210
DEBUG - 2011-08-12 20:52:38 --> Config Class Initialized
DEBUG - 2011-08-12 20:52:38 --> Hooks Class Initialized
DEBUG - 2011-08-12 20:52:38 --> Utf8 Class Initialized
DEBUG - 2011-08-12 20:52:38 --> UTF-8 Support Enabled
DEBUG - 2011-08-12 20:52:38 --> URI Class Initialized
DEBUG - 2011-08-12 20:52:38 --> Router Class Initialized
ERROR - 2011-08-12 20:52:38 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-08-12 20:52:39 --> Config Class Initialized
DEBUG - 2011-08-12 20:52:39 --> Hooks Class Initialized
DEBUG - 2011-08-12 20:52:39 --> Utf8 Class Initialized
DEBUG - 2011-08-12 20:52:39 --> UTF-8 Support Enabled
DEBUG - 2011-08-12 20:52:39 --> URI Class Initialized
DEBUG - 2011-08-12 20:52:39 --> Router Class Initialized
ERROR - 2011-08-12 20:52:39 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-08-12 20:52:39 --> Config Class Initialized
DEBUG - 2011-08-12 20:52:39 --> Hooks Class Initialized
DEBUG - 2011-08-12 20:52:39 --> Utf8 Class Initialized
DEBUG - 2011-08-12 20:52:39 --> UTF-8 Support Enabled
DEBUG - 2011-08-12 20:52:39 --> URI Class Initialized
DEBUG - 2011-08-12 20:52:39 --> Router Class Initialized
ERROR - 2011-08-12 20:52:39 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-08-12 20:52:56 --> Config Class Initialized
DEBUG - 2011-08-12 20:52:56 --> Hooks Class Initialized
DEBUG - 2011-08-12 20:52:56 --> Utf8 Class Initialized
DEBUG - 2011-08-12 20:52:56 --> UTF-8 Support Enabled
DEBUG - 2011-08-12 20:52:56 --> URI Class Initialized
DEBUG - 2011-08-12 20:52:56 --> Router Class Initialized
DEBUG - 2011-08-12 20:52:56 --> Output Class Initialized
DEBUG - 2011-08-12 20:52:56 --> Input Class Initialized
DEBUG - 2011-08-12 20:52:56 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-12 20:52:56 --> Language Class Initialized
DEBUG - 2011-08-12 20:52:56 --> Loader Class Initialized
DEBUG - 2011-08-12 20:52:56 --> Controller Class Initialized
ERROR - 2011-08-12 20:52:56 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-08-12 20:52:56 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-08-12 20:52:56 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-08-12 20:52:56 --> Model Class Initialized
DEBUG - 2011-08-12 20:52:56 --> Model Class Initialized
DEBUG - 2011-08-12 20:52:56 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-12 20:52:56 --> Database Driver Class Initialized
DEBUG - 2011-08-12 20:52:56 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-08-12 20:52:56 --> Helper loaded: url_helper
DEBUG - 2011-08-12 20:52:56 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-12 20:52:56 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-12 20:52:56 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-12 20:52:56 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-12 20:52:56 --> Final output sent to browser
DEBUG - 2011-08-12 20:52:56 --> Total execution time: 0.0299
DEBUG - 2011-08-12 20:52:56 --> Config Class Initialized
DEBUG - 2011-08-12 20:52:56 --> Hooks Class Initialized
DEBUG - 2011-08-12 20:52:56 --> Utf8 Class Initialized
DEBUG - 2011-08-12 20:52:56 --> UTF-8 Support Enabled
DEBUG - 2011-08-12 20:52:56 --> URI Class Initialized
DEBUG - 2011-08-12 20:52:56 --> Router Class Initialized
DEBUG - 2011-08-12 20:52:56 --> Output Class Initialized
DEBUG - 2011-08-12 20:52:56 --> Input Class Initialized
DEBUG - 2011-08-12 20:52:56 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-12 20:52:56 --> Language Class Initialized
DEBUG - 2011-08-12 20:52:56 --> Loader Class Initialized
DEBUG - 2011-08-12 20:52:56 --> Controller Class Initialized
DEBUG - 2011-08-12 20:52:56 --> Model Class Initialized
DEBUG - 2011-08-12 20:52:56 --> Model Class Initialized
DEBUG - 2011-08-12 20:52:56 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-12 20:52:56 --> Database Driver Class Initialized
DEBUG - 2011-08-12 20:52:57 --> Final output sent to browser
DEBUG - 2011-08-12 20:52:57 --> Total execution time: 0.5769
DEBUG - 2011-08-12 23:09:44 --> Config Class Initialized
DEBUG - 2011-08-12 23:09:44 --> Hooks Class Initialized
DEBUG - 2011-08-12 23:09:44 --> Utf8 Class Initialized
DEBUG - 2011-08-12 23:09:44 --> UTF-8 Support Enabled
DEBUG - 2011-08-12 23:09:44 --> URI Class Initialized
DEBUG - 2011-08-12 23:09:44 --> Router Class Initialized
DEBUG - 2011-08-12 23:09:44 --> No URI present. Default controller set.
DEBUG - 2011-08-12 23:09:44 --> Output Class Initialized
DEBUG - 2011-08-12 23:09:44 --> Input Class Initialized
DEBUG - 2011-08-12 23:09:44 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-12 23:09:44 --> Language Class Initialized
DEBUG - 2011-08-12 23:09:44 --> Loader Class Initialized
DEBUG - 2011-08-12 23:09:44 --> Controller Class Initialized
DEBUG - 2011-08-12 23:09:44 --> File loaded: application/views/splash/main.php
DEBUG - 2011-08-12 23:09:44 --> Helper loaded: url_helper
DEBUG - 2011-08-12 23:09:44 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-12 23:09:44 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-12 23:09:44 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-12 23:09:44 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-12 23:09:44 --> Final output sent to browser
DEBUG - 2011-08-12 23:09:44 --> Total execution time: 0.1197
DEBUG - 2011-08-12 23:32:53 --> Config Class Initialized
DEBUG - 2011-08-12 23:32:53 --> Hooks Class Initialized
DEBUG - 2011-08-12 23:32:53 --> Utf8 Class Initialized
DEBUG - 2011-08-12 23:32:53 --> UTF-8 Support Enabled
DEBUG - 2011-08-12 23:32:53 --> URI Class Initialized
DEBUG - 2011-08-12 23:32:53 --> Router Class Initialized
ERROR - 2011-08-12 23:32:53 --> 404 Page Not Found --> robots.txt
DEBUG - 2011-08-12 23:35:51 --> Config Class Initialized
DEBUG - 2011-08-12 23:35:51 --> Hooks Class Initialized
DEBUG - 2011-08-12 23:35:51 --> Utf8 Class Initialized
DEBUG - 2011-08-12 23:35:51 --> UTF-8 Support Enabled
DEBUG - 2011-08-12 23:35:51 --> URI Class Initialized
DEBUG - 2011-08-12 23:35:51 --> Router Class Initialized
DEBUG - 2011-08-12 23:35:51 --> Output Class Initialized
DEBUG - 2011-08-12 23:35:51 --> Input Class Initialized
DEBUG - 2011-08-12 23:35:51 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-12 23:35:51 --> Language Class Initialized
DEBUG - 2011-08-12 23:35:51 --> Loader Class Initialized
DEBUG - 2011-08-12 23:35:51 --> Controller Class Initialized
DEBUG - 2011-08-12 23:35:51 --> Model Class Initialized
DEBUG - 2011-08-12 23:35:51 --> Model Class Initialized
DEBUG - 2011-08-12 23:35:51 --> Model Class Initialized
DEBUG - 2011-08-12 23:35:51 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-12 23:35:51 --> Database Driver Class Initialized
DEBUG - 2011-08-12 23:35:52 --> File loaded: application/views/table/main.php
DEBUG - 2011-08-12 23:35:52 --> Helper loaded: url_helper
DEBUG - 2011-08-12 23:35:52 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-12 23:35:52 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-12 23:35:52 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-12 23:35:52 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-12 23:35:52 --> Final output sent to browser
DEBUG - 2011-08-12 23:35:52 --> Total execution time: 0.2517

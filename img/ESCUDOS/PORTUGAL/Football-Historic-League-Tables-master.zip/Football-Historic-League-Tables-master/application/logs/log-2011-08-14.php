<?php  if ( ! defined('BASEPATH')) exit('No direct script access allowed'); ?>

DEBUG - 2011-08-14 00:01:54 --> Config Class Initialized
DEBUG - 2011-08-14 00:01:54 --> Hooks Class Initialized
DEBUG - 2011-08-14 00:01:54 --> Utf8 Class Initialized
DEBUG - 2011-08-14 00:01:54 --> UTF-8 Support Enabled
DEBUG - 2011-08-14 00:01:54 --> URI Class Initialized
DEBUG - 2011-08-14 00:01:54 --> Router Class Initialized
DEBUG - 2011-08-14 00:01:54 --> Output Class Initialized
DEBUG - 2011-08-14 00:01:54 --> Input Class Initialized
DEBUG - 2011-08-14 00:01:54 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-14 00:01:54 --> Language Class Initialized
DEBUG - 2011-08-14 00:01:54 --> Loader Class Initialized
DEBUG - 2011-08-14 00:01:54 --> Controller Class Initialized
DEBUG - 2011-08-14 00:01:54 --> Model Class Initialized
DEBUG - 2011-08-14 00:01:54 --> Model Class Initialized
DEBUG - 2011-08-14 00:01:54 --> Model Class Initialized
DEBUG - 2011-08-14 00:01:54 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-14 00:01:54 --> Database Driver Class Initialized
DEBUG - 2011-08-14 00:01:54 --> File loaded: application/views/table/main.php
DEBUG - 2011-08-14 00:01:54 --> Helper loaded: url_helper
DEBUG - 2011-08-14 00:01:54 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-14 00:01:54 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-14 00:01:54 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-14 00:01:54 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-14 00:01:54 --> Final output sent to browser
DEBUG - 2011-08-14 00:01:54 --> Total execution time: 0.4827
DEBUG - 2011-08-14 00:02:00 --> Config Class Initialized
DEBUG - 2011-08-14 00:02:00 --> Hooks Class Initialized
DEBUG - 2011-08-14 00:02:00 --> Utf8 Class Initialized
DEBUG - 2011-08-14 00:02:00 --> UTF-8 Support Enabled
DEBUG - 2011-08-14 00:02:00 --> URI Class Initialized
DEBUG - 2011-08-14 00:02:00 --> Router Class Initialized
ERROR - 2011-08-14 00:02:00 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-08-14 00:03:03 --> Config Class Initialized
DEBUG - 2011-08-14 00:03:03 --> Hooks Class Initialized
DEBUG - 2011-08-14 00:03:03 --> Utf8 Class Initialized
DEBUG - 2011-08-14 00:03:03 --> UTF-8 Support Enabled
DEBUG - 2011-08-14 00:03:03 --> URI Class Initialized
DEBUG - 2011-08-14 00:03:03 --> Router Class Initialized
DEBUG - 2011-08-14 00:03:03 --> Output Class Initialized
DEBUG - 2011-08-14 00:03:03 --> Input Class Initialized
DEBUG - 2011-08-14 00:03:03 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-14 00:03:03 --> Language Class Initialized
DEBUG - 2011-08-14 00:03:03 --> Loader Class Initialized
DEBUG - 2011-08-14 00:03:03 --> Controller Class Initialized
DEBUG - 2011-08-14 00:03:03 --> Model Class Initialized
DEBUG - 2011-08-14 00:03:03 --> Model Class Initialized
DEBUG - 2011-08-14 00:03:03 --> Model Class Initialized
DEBUG - 2011-08-14 00:03:03 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-14 00:03:03 --> Database Driver Class Initialized
DEBUG - 2011-08-14 00:03:03 --> File loaded: application/views/table/main.php
DEBUG - 2011-08-14 00:03:03 --> Helper loaded: url_helper
DEBUG - 2011-08-14 00:03:03 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-14 00:03:03 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-14 00:03:03 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-14 00:03:03 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-14 00:03:03 --> Final output sent to browser
DEBUG - 2011-08-14 00:03:03 --> Total execution time: 0.4042
DEBUG - 2011-08-14 00:03:07 --> Config Class Initialized
DEBUG - 2011-08-14 00:03:07 --> Hooks Class Initialized
DEBUG - 2011-08-14 00:03:07 --> Utf8 Class Initialized
DEBUG - 2011-08-14 00:03:07 --> UTF-8 Support Enabled
DEBUG - 2011-08-14 00:03:07 --> URI Class Initialized
DEBUG - 2011-08-14 00:03:07 --> Router Class Initialized
DEBUG - 2011-08-14 00:03:07 --> Output Class Initialized
DEBUG - 2011-08-14 00:03:07 --> Input Class Initialized
DEBUG - 2011-08-14 00:03:07 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-14 00:03:07 --> Language Class Initialized
DEBUG - 2011-08-14 00:03:07 --> Loader Class Initialized
DEBUG - 2011-08-14 00:03:07 --> Controller Class Initialized
DEBUG - 2011-08-14 00:03:07 --> Model Class Initialized
DEBUG - 2011-08-14 00:03:07 --> Model Class Initialized
DEBUG - 2011-08-14 00:03:07 --> Model Class Initialized
DEBUG - 2011-08-14 00:03:07 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-14 00:03:07 --> Database Driver Class Initialized
DEBUG - 2011-08-14 00:03:07 --> File loaded: application/views/table/main.php
DEBUG - 2011-08-14 00:03:07 --> Helper loaded: url_helper
DEBUG - 2011-08-14 00:03:07 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-14 00:03:07 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-14 00:03:07 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-14 00:03:07 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-14 00:03:07 --> Final output sent to browser
DEBUG - 2011-08-14 00:03:07 --> Total execution time: 0.0800
DEBUG - 2011-08-14 00:03:34 --> Config Class Initialized
DEBUG - 2011-08-14 00:03:34 --> Hooks Class Initialized
DEBUG - 2011-08-14 00:03:34 --> Utf8 Class Initialized
DEBUG - 2011-08-14 00:03:34 --> UTF-8 Support Enabled
DEBUG - 2011-08-14 00:03:34 --> URI Class Initialized
DEBUG - 2011-08-14 00:03:34 --> Router Class Initialized
ERROR - 2011-08-14 00:03:34 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-08-14 00:03:36 --> Config Class Initialized
DEBUG - 2011-08-14 00:03:36 --> Hooks Class Initialized
DEBUG - 2011-08-14 00:03:36 --> Utf8 Class Initialized
DEBUG - 2011-08-14 00:03:36 --> UTF-8 Support Enabled
DEBUG - 2011-08-14 00:03:36 --> URI Class Initialized
DEBUG - 2011-08-14 00:03:36 --> Router Class Initialized
DEBUG - 2011-08-14 00:03:36 --> Output Class Initialized
DEBUG - 2011-08-14 00:03:36 --> Input Class Initialized
DEBUG - 2011-08-14 00:03:36 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-14 00:03:36 --> Language Class Initialized
DEBUG - 2011-08-14 00:03:36 --> Loader Class Initialized
DEBUG - 2011-08-14 00:03:36 --> Controller Class Initialized
DEBUG - 2011-08-14 00:03:36 --> Model Class Initialized
DEBUG - 2011-08-14 00:03:36 --> Model Class Initialized
DEBUG - 2011-08-14 00:03:36 --> Model Class Initialized
DEBUG - 2011-08-14 00:03:36 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-14 00:03:36 --> Database Driver Class Initialized
DEBUG - 2011-08-14 00:03:36 --> File loaded: application/views/table/main.php
DEBUG - 2011-08-14 00:03:36 --> Helper loaded: url_helper
DEBUG - 2011-08-14 00:03:36 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-14 00:03:36 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-14 00:03:36 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-14 00:03:36 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-14 00:03:36 --> Final output sent to browser
DEBUG - 2011-08-14 00:03:36 --> Total execution time: 0.3175
DEBUG - 2011-08-14 00:03:40 --> Config Class Initialized
DEBUG - 2011-08-14 00:03:40 --> Hooks Class Initialized
DEBUG - 2011-08-14 00:03:40 --> Utf8 Class Initialized
DEBUG - 2011-08-14 00:03:40 --> UTF-8 Support Enabled
DEBUG - 2011-08-14 00:03:40 --> URI Class Initialized
DEBUG - 2011-08-14 00:03:40 --> Router Class Initialized
DEBUG - 2011-08-14 00:03:40 --> Output Class Initialized
DEBUG - 2011-08-14 00:03:40 --> Input Class Initialized
DEBUG - 2011-08-14 00:03:40 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-14 00:03:40 --> Language Class Initialized
DEBUG - 2011-08-14 00:03:40 --> Loader Class Initialized
DEBUG - 2011-08-14 00:03:40 --> Controller Class Initialized
DEBUG - 2011-08-14 00:03:40 --> Model Class Initialized
DEBUG - 2011-08-14 00:03:40 --> Model Class Initialized
DEBUG - 2011-08-14 00:03:40 --> Model Class Initialized
DEBUG - 2011-08-14 00:03:40 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-14 00:03:40 --> Database Driver Class Initialized
DEBUG - 2011-08-14 00:03:40 --> File loaded: application/views/table/main.php
DEBUG - 2011-08-14 00:03:40 --> Helper loaded: url_helper
DEBUG - 2011-08-14 00:03:40 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-14 00:03:40 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-14 00:03:40 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-14 00:03:40 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-14 00:03:40 --> Final output sent to browser
DEBUG - 2011-08-14 00:03:40 --> Total execution time: 0.0468
DEBUG - 2011-08-14 00:03:45 --> Config Class Initialized
DEBUG - 2011-08-14 00:03:45 --> Hooks Class Initialized
DEBUG - 2011-08-14 00:03:45 --> Utf8 Class Initialized
DEBUG - 2011-08-14 00:03:45 --> UTF-8 Support Enabled
DEBUG - 2011-08-14 00:03:45 --> URI Class Initialized
DEBUG - 2011-08-14 00:03:45 --> Router Class Initialized
DEBUG - 2011-08-14 00:03:45 --> Output Class Initialized
DEBUG - 2011-08-14 00:03:45 --> Input Class Initialized
DEBUG - 2011-08-14 00:03:45 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-14 00:03:45 --> Language Class Initialized
DEBUG - 2011-08-14 00:03:45 --> Loader Class Initialized
DEBUG - 2011-08-14 00:03:45 --> Controller Class Initialized
DEBUG - 2011-08-14 00:03:45 --> Model Class Initialized
DEBUG - 2011-08-14 00:03:45 --> Model Class Initialized
DEBUG - 2011-08-14 00:03:45 --> Model Class Initialized
DEBUG - 2011-08-14 00:03:45 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-14 00:03:45 --> Database Driver Class Initialized
DEBUG - 2011-08-14 00:03:45 --> File loaded: application/views/table/main.php
DEBUG - 2011-08-14 00:03:45 --> Helper loaded: url_helper
DEBUG - 2011-08-14 00:03:45 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-14 00:03:45 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-14 00:03:45 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-14 00:03:45 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-14 00:03:45 --> Final output sent to browser
DEBUG - 2011-08-14 00:03:45 --> Total execution time: 0.0568
DEBUG - 2011-08-14 00:30:29 --> Config Class Initialized
DEBUG - 2011-08-14 00:30:29 --> Hooks Class Initialized
DEBUG - 2011-08-14 00:30:29 --> Utf8 Class Initialized
DEBUG - 2011-08-14 00:30:29 --> UTF-8 Support Enabled
DEBUG - 2011-08-14 00:30:29 --> URI Class Initialized
DEBUG - 2011-08-14 00:30:29 --> Router Class Initialized
ERROR - 2011-08-14 00:30:29 --> 404 Page Not Found --> robots.txt
DEBUG - 2011-08-14 00:37:38 --> Config Class Initialized
DEBUG - 2011-08-14 00:37:38 --> Hooks Class Initialized
DEBUG - 2011-08-14 00:37:38 --> Utf8 Class Initialized
DEBUG - 2011-08-14 00:37:38 --> UTF-8 Support Enabled
DEBUG - 2011-08-14 00:37:38 --> URI Class Initialized
DEBUG - 2011-08-14 00:37:38 --> Router Class Initialized
DEBUG - 2011-08-14 00:37:38 --> No URI present. Default controller set.
DEBUG - 2011-08-14 00:37:38 --> Output Class Initialized
DEBUG - 2011-08-14 00:37:38 --> Input Class Initialized
DEBUG - 2011-08-14 00:37:38 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-14 00:37:38 --> Language Class Initialized
DEBUG - 2011-08-14 00:37:38 --> Loader Class Initialized
DEBUG - 2011-08-14 00:37:38 --> Controller Class Initialized
DEBUG - 2011-08-14 00:37:38 --> File loaded: application/views/splash/main.php
DEBUG - 2011-08-14 00:37:38 --> Helper loaded: url_helper
DEBUG - 2011-08-14 00:37:38 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-14 00:37:38 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-14 00:37:38 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-14 00:37:38 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-14 00:37:38 --> Final output sent to browser
DEBUG - 2011-08-14 00:37:38 --> Total execution time: 0.0145
DEBUG - 2011-08-14 00:37:40 --> Config Class Initialized
DEBUG - 2011-08-14 00:37:40 --> Hooks Class Initialized
DEBUG - 2011-08-14 00:37:40 --> Utf8 Class Initialized
DEBUG - 2011-08-14 00:37:40 --> UTF-8 Support Enabled
DEBUG - 2011-08-14 00:37:40 --> URI Class Initialized
DEBUG - 2011-08-14 00:37:40 --> Router Class Initialized
ERROR - 2011-08-14 00:37:40 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-08-14 02:20:40 --> Config Class Initialized
DEBUG - 2011-08-14 02:20:40 --> Hooks Class Initialized
DEBUG - 2011-08-14 02:20:40 --> Utf8 Class Initialized
DEBUG - 2011-08-14 02:20:40 --> UTF-8 Support Enabled
DEBUG - 2011-08-14 02:20:40 --> URI Class Initialized
DEBUG - 2011-08-14 02:20:40 --> Router Class Initialized
DEBUG - 2011-08-14 02:20:40 --> Output Class Initialized
DEBUG - 2011-08-14 02:20:40 --> Input Class Initialized
DEBUG - 2011-08-14 02:20:40 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-14 02:20:40 --> Language Class Initialized
DEBUG - 2011-08-14 02:20:40 --> Loader Class Initialized
DEBUG - 2011-08-14 02:20:40 --> Controller Class Initialized
ERROR - 2011-08-14 02:20:40 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-08-14 02:20:40 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-08-14 02:20:40 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-08-14 02:20:40 --> Model Class Initialized
DEBUG - 2011-08-14 02:20:40 --> Model Class Initialized
DEBUG - 2011-08-14 02:20:40 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-14 02:20:40 --> Database Driver Class Initialized
DEBUG - 2011-08-14 02:20:41 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-08-14 02:20:41 --> Helper loaded: url_helper
DEBUG - 2011-08-14 02:20:41 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-14 02:20:41 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-14 02:20:41 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-14 02:20:41 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-14 02:20:41 --> Final output sent to browser
DEBUG - 2011-08-14 02:20:41 --> Total execution time: 0.6332
DEBUG - 2011-08-14 02:20:42 --> Config Class Initialized
DEBUG - 2011-08-14 02:20:42 --> Hooks Class Initialized
DEBUG - 2011-08-14 02:20:42 --> Utf8 Class Initialized
DEBUG - 2011-08-14 02:20:42 --> UTF-8 Support Enabled
DEBUG - 2011-08-14 02:20:42 --> URI Class Initialized
DEBUG - 2011-08-14 02:20:42 --> Router Class Initialized
DEBUG - 2011-08-14 02:20:42 --> Output Class Initialized
DEBUG - 2011-08-14 02:20:42 --> Input Class Initialized
DEBUG - 2011-08-14 02:20:42 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-14 02:20:42 --> Language Class Initialized
DEBUG - 2011-08-14 02:20:42 --> Loader Class Initialized
DEBUG - 2011-08-14 02:20:42 --> Controller Class Initialized
DEBUG - 2011-08-14 02:20:42 --> Model Class Initialized
DEBUG - 2011-08-14 02:20:42 --> Model Class Initialized
DEBUG - 2011-08-14 02:20:42 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-14 02:20:42 --> Database Driver Class Initialized
DEBUG - 2011-08-14 02:20:42 --> Final output sent to browser
DEBUG - 2011-08-14 02:20:42 --> Total execution time: 0.5748
DEBUG - 2011-08-14 02:20:44 --> Config Class Initialized
DEBUG - 2011-08-14 02:20:44 --> Hooks Class Initialized
DEBUG - 2011-08-14 02:20:44 --> Utf8 Class Initialized
DEBUG - 2011-08-14 02:20:44 --> UTF-8 Support Enabled
DEBUG - 2011-08-14 02:20:44 --> URI Class Initialized
DEBUG - 2011-08-14 02:20:44 --> Router Class Initialized
ERROR - 2011-08-14 02:20:44 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-08-14 02:20:44 --> Config Class Initialized
DEBUG - 2011-08-14 02:20:44 --> Hooks Class Initialized
DEBUG - 2011-08-14 02:20:44 --> Utf8 Class Initialized
DEBUG - 2011-08-14 02:20:44 --> UTF-8 Support Enabled
DEBUG - 2011-08-14 02:20:44 --> URI Class Initialized
DEBUG - 2011-08-14 02:20:44 --> Router Class Initialized
ERROR - 2011-08-14 02:20:44 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-08-14 02:20:45 --> Config Class Initialized
DEBUG - 2011-08-14 02:20:45 --> Hooks Class Initialized
DEBUG - 2011-08-14 02:20:45 --> Utf8 Class Initialized
DEBUG - 2011-08-14 02:20:45 --> UTF-8 Support Enabled
DEBUG - 2011-08-14 02:20:45 --> URI Class Initialized
DEBUG - 2011-08-14 02:20:45 --> Router Class Initialized
ERROR - 2011-08-14 02:20:45 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-08-14 02:20:56 --> Config Class Initialized
DEBUG - 2011-08-14 02:20:56 --> Hooks Class Initialized
DEBUG - 2011-08-14 02:20:56 --> Utf8 Class Initialized
DEBUG - 2011-08-14 02:20:56 --> UTF-8 Support Enabled
DEBUG - 2011-08-14 02:20:56 --> URI Class Initialized
DEBUG - 2011-08-14 02:20:56 --> Router Class Initialized
DEBUG - 2011-08-14 02:20:56 --> Output Class Initialized
DEBUG - 2011-08-14 02:20:56 --> Input Class Initialized
DEBUG - 2011-08-14 02:20:56 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-14 02:20:56 --> Language Class Initialized
DEBUG - 2011-08-14 02:20:56 --> Loader Class Initialized
DEBUG - 2011-08-14 02:20:56 --> Controller Class Initialized
ERROR - 2011-08-14 02:20:56 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-08-14 02:20:56 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-08-14 02:20:56 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-08-14 02:20:56 --> Model Class Initialized
DEBUG - 2011-08-14 02:20:56 --> Model Class Initialized
DEBUG - 2011-08-14 02:20:56 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-14 02:20:56 --> Database Driver Class Initialized
DEBUG - 2011-08-14 02:20:56 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-08-14 02:20:56 --> Helper loaded: url_helper
DEBUG - 2011-08-14 02:20:56 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-14 02:20:56 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-14 02:20:56 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-14 02:20:56 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-14 02:20:56 --> Final output sent to browser
DEBUG - 2011-08-14 02:20:56 --> Total execution time: 0.0282
DEBUG - 2011-08-14 02:20:57 --> Config Class Initialized
DEBUG - 2011-08-14 02:20:57 --> Hooks Class Initialized
DEBUG - 2011-08-14 02:20:57 --> Utf8 Class Initialized
DEBUG - 2011-08-14 02:20:57 --> UTF-8 Support Enabled
DEBUG - 2011-08-14 02:20:57 --> URI Class Initialized
DEBUG - 2011-08-14 02:20:57 --> Router Class Initialized
DEBUG - 2011-08-14 02:20:57 --> Output Class Initialized
DEBUG - 2011-08-14 02:20:57 --> Input Class Initialized
DEBUG - 2011-08-14 02:20:57 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-14 02:20:57 --> Language Class Initialized
DEBUG - 2011-08-14 02:20:57 --> Loader Class Initialized
DEBUG - 2011-08-14 02:20:57 --> Controller Class Initialized
DEBUG - 2011-08-14 02:20:57 --> Model Class Initialized
DEBUG - 2011-08-14 02:20:57 --> Model Class Initialized
DEBUG - 2011-08-14 02:20:57 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-14 02:20:57 --> Database Driver Class Initialized
DEBUG - 2011-08-14 02:20:58 --> Final output sent to browser
DEBUG - 2011-08-14 02:20:58 --> Total execution time: 0.9965
DEBUG - 2011-08-14 02:28:26 --> Config Class Initialized
DEBUG - 2011-08-14 02:28:26 --> Hooks Class Initialized
DEBUG - 2011-08-14 02:28:26 --> Utf8 Class Initialized
DEBUG - 2011-08-14 02:28:26 --> UTF-8 Support Enabled
DEBUG - 2011-08-14 02:28:26 --> URI Class Initialized
DEBUG - 2011-08-14 02:28:26 --> Router Class Initialized
DEBUG - 2011-08-14 02:28:26 --> Output Class Initialized
DEBUG - 2011-08-14 02:28:26 --> Input Class Initialized
DEBUG - 2011-08-14 02:28:26 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-14 02:28:26 --> Language Class Initialized
DEBUG - 2011-08-14 02:28:26 --> Loader Class Initialized
DEBUG - 2011-08-14 02:28:26 --> Controller Class Initialized
ERROR - 2011-08-14 02:28:26 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-08-14 02:28:26 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-08-14 02:28:26 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-08-14 02:28:26 --> Model Class Initialized
DEBUG - 2011-08-14 02:28:26 --> Model Class Initialized
DEBUG - 2011-08-14 02:28:26 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-14 02:28:26 --> Database Driver Class Initialized
DEBUG - 2011-08-14 02:28:26 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-08-14 02:28:26 --> Helper loaded: url_helper
DEBUG - 2011-08-14 02:28:26 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-14 02:28:26 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-14 02:28:26 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-14 02:28:26 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-14 02:28:26 --> Final output sent to browser
DEBUG - 2011-08-14 02:28:26 --> Total execution time: 0.0638
DEBUG - 2011-08-14 02:28:39 --> Config Class Initialized
DEBUG - 2011-08-14 02:28:39 --> Hooks Class Initialized
DEBUG - 2011-08-14 02:28:39 --> Utf8 Class Initialized
DEBUG - 2011-08-14 02:28:39 --> UTF-8 Support Enabled
DEBUG - 2011-08-14 02:28:39 --> URI Class Initialized
DEBUG - 2011-08-14 02:28:39 --> Router Class Initialized
DEBUG - 2011-08-14 02:28:39 --> Output Class Initialized
DEBUG - 2011-08-14 02:28:39 --> Input Class Initialized
DEBUG - 2011-08-14 02:28:39 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-14 02:28:39 --> Language Class Initialized
DEBUG - 2011-08-14 02:28:39 --> Loader Class Initialized
DEBUG - 2011-08-14 02:28:39 --> Controller Class Initialized
DEBUG - 2011-08-14 02:28:39 --> Model Class Initialized
DEBUG - 2011-08-14 02:28:39 --> Model Class Initialized
DEBUG - 2011-08-14 02:28:39 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-14 02:28:39 --> Database Driver Class Initialized
DEBUG - 2011-08-14 02:28:40 --> Final output sent to browser
DEBUG - 2011-08-14 02:28:40 --> Total execution time: 0.6247
DEBUG - 2011-08-14 02:28:58 --> Config Class Initialized
DEBUG - 2011-08-14 02:28:58 --> Hooks Class Initialized
DEBUG - 2011-08-14 02:28:58 --> Utf8 Class Initialized
DEBUG - 2011-08-14 02:28:58 --> UTF-8 Support Enabled
DEBUG - 2011-08-14 02:28:58 --> URI Class Initialized
DEBUG - 2011-08-14 02:28:58 --> Router Class Initialized
DEBUG - 2011-08-14 02:28:58 --> Output Class Initialized
DEBUG - 2011-08-14 02:28:58 --> Input Class Initialized
DEBUG - 2011-08-14 02:28:58 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-14 02:28:58 --> Language Class Initialized
DEBUG - 2011-08-14 02:28:58 --> Loader Class Initialized
DEBUG - 2011-08-14 02:28:58 --> Controller Class Initialized
ERROR - 2011-08-14 02:28:58 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-08-14 02:28:58 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-08-14 02:28:58 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-08-14 02:28:58 --> Model Class Initialized
DEBUG - 2011-08-14 02:28:58 --> Model Class Initialized
DEBUG - 2011-08-14 02:28:58 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-14 02:28:58 --> Database Driver Class Initialized
DEBUG - 2011-08-14 02:28:58 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-08-14 02:28:58 --> Helper loaded: url_helper
DEBUG - 2011-08-14 02:28:58 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-14 02:28:58 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-14 02:28:58 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-14 02:28:58 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-14 02:28:58 --> Final output sent to browser
DEBUG - 2011-08-14 02:28:58 --> Total execution time: 0.0266
DEBUG - 2011-08-14 02:29:01 --> Config Class Initialized
DEBUG - 2011-08-14 02:29:01 --> Hooks Class Initialized
DEBUG - 2011-08-14 02:29:01 --> Utf8 Class Initialized
DEBUG - 2011-08-14 02:29:01 --> UTF-8 Support Enabled
DEBUG - 2011-08-14 02:29:01 --> URI Class Initialized
DEBUG - 2011-08-14 02:29:01 --> Router Class Initialized
DEBUG - 2011-08-14 02:29:01 --> Output Class Initialized
DEBUG - 2011-08-14 02:29:01 --> Input Class Initialized
DEBUG - 2011-08-14 02:29:01 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-14 02:29:01 --> Language Class Initialized
DEBUG - 2011-08-14 02:29:01 --> Loader Class Initialized
DEBUG - 2011-08-14 02:29:01 --> Controller Class Initialized
DEBUG - 2011-08-14 02:29:01 --> Model Class Initialized
DEBUG - 2011-08-14 02:29:01 --> Model Class Initialized
DEBUG - 2011-08-14 02:29:01 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-14 02:29:01 --> Database Driver Class Initialized
DEBUG - 2011-08-14 02:29:02 --> Final output sent to browser
DEBUG - 2011-08-14 02:29:02 --> Total execution time: 0.9436
DEBUG - 2011-08-14 02:34:07 --> Config Class Initialized
DEBUG - 2011-08-14 02:34:07 --> Hooks Class Initialized
DEBUG - 2011-08-14 02:34:07 --> Utf8 Class Initialized
DEBUG - 2011-08-14 02:34:07 --> UTF-8 Support Enabled
DEBUG - 2011-08-14 02:34:07 --> URI Class Initialized
DEBUG - 2011-08-14 02:34:07 --> Router Class Initialized
DEBUG - 2011-08-14 02:34:07 --> Output Class Initialized
DEBUG - 2011-08-14 02:34:07 --> Input Class Initialized
DEBUG - 2011-08-14 02:34:07 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-14 02:34:07 --> Language Class Initialized
DEBUG - 2011-08-14 02:34:07 --> Loader Class Initialized
DEBUG - 2011-08-14 02:34:07 --> Controller Class Initialized
DEBUG - 2011-08-14 02:34:07 --> Model Class Initialized
DEBUG - 2011-08-14 02:34:07 --> Model Class Initialized
DEBUG - 2011-08-14 02:34:07 --> Model Class Initialized
DEBUG - 2011-08-14 02:34:07 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-14 02:34:07 --> Database Driver Class Initialized
DEBUG - 2011-08-14 02:34:07 --> File loaded: application/views/table/main.php
DEBUG - 2011-08-14 02:34:07 --> Helper loaded: url_helper
DEBUG - 2011-08-14 02:34:07 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-14 02:34:07 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-14 02:34:07 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-14 02:34:07 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-14 02:34:07 --> Final output sent to browser
DEBUG - 2011-08-14 02:34:07 --> Total execution time: 0.8166
DEBUG - 2011-08-14 02:37:01 --> Config Class Initialized
DEBUG - 2011-08-14 02:37:01 --> Hooks Class Initialized
DEBUG - 2011-08-14 02:37:01 --> Utf8 Class Initialized
DEBUG - 2011-08-14 02:37:01 --> UTF-8 Support Enabled
DEBUG - 2011-08-14 02:37:01 --> URI Class Initialized
DEBUG - 2011-08-14 02:37:01 --> Router Class Initialized
DEBUG - 2011-08-14 02:37:01 --> Output Class Initialized
DEBUG - 2011-08-14 02:37:01 --> Input Class Initialized
DEBUG - 2011-08-14 02:37:01 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-14 02:37:01 --> Language Class Initialized
DEBUG - 2011-08-14 02:37:01 --> Loader Class Initialized
DEBUG - 2011-08-14 02:37:01 --> Controller Class Initialized
DEBUG - 2011-08-14 02:37:01 --> Model Class Initialized
DEBUG - 2011-08-14 02:37:01 --> Model Class Initialized
DEBUG - 2011-08-14 02:37:01 --> Model Class Initialized
DEBUG - 2011-08-14 02:37:01 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-14 02:37:01 --> Database Driver Class Initialized
DEBUG - 2011-08-14 02:37:01 --> File loaded: application/views/table/main.php
DEBUG - 2011-08-14 02:37:01 --> Helper loaded: url_helper
DEBUG - 2011-08-14 02:37:01 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-14 02:37:01 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-14 02:37:01 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-14 02:37:01 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-14 02:37:01 --> Final output sent to browser
DEBUG - 2011-08-14 02:37:01 --> Total execution time: 0.0698
DEBUG - 2011-08-14 02:37:24 --> Config Class Initialized
DEBUG - 2011-08-14 02:37:24 --> Hooks Class Initialized
DEBUG - 2011-08-14 02:37:24 --> Utf8 Class Initialized
DEBUG - 2011-08-14 02:37:24 --> UTF-8 Support Enabled
DEBUG - 2011-08-14 02:37:24 --> URI Class Initialized
DEBUG - 2011-08-14 02:37:24 --> Router Class Initialized
ERROR - 2011-08-14 02:37:24 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-08-14 02:37:27 --> Config Class Initialized
DEBUG - 2011-08-14 02:37:27 --> Hooks Class Initialized
DEBUG - 2011-08-14 02:37:27 --> Utf8 Class Initialized
DEBUG - 2011-08-14 02:37:27 --> UTF-8 Support Enabled
DEBUG - 2011-08-14 02:37:27 --> URI Class Initialized
DEBUG - 2011-08-14 02:37:27 --> Router Class Initialized
ERROR - 2011-08-14 02:37:27 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-08-14 02:38:40 --> Config Class Initialized
DEBUG - 2011-08-14 02:38:40 --> Hooks Class Initialized
DEBUG - 2011-08-14 02:38:40 --> Utf8 Class Initialized
DEBUG - 2011-08-14 02:38:40 --> UTF-8 Support Enabled
DEBUG - 2011-08-14 02:38:40 --> URI Class Initialized
DEBUG - 2011-08-14 02:38:40 --> Router Class Initialized
DEBUG - 2011-08-14 02:38:40 --> Output Class Initialized
DEBUG - 2011-08-14 02:38:40 --> Input Class Initialized
DEBUG - 2011-08-14 02:38:40 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-14 02:38:40 --> Language Class Initialized
DEBUG - 2011-08-14 02:38:40 --> Loader Class Initialized
DEBUG - 2011-08-14 02:38:40 --> Controller Class Initialized
DEBUG - 2011-08-14 02:38:40 --> Model Class Initialized
DEBUG - 2011-08-14 02:38:40 --> Model Class Initialized
DEBUG - 2011-08-14 02:38:40 --> Model Class Initialized
DEBUG - 2011-08-14 02:38:40 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-14 02:38:40 --> Database Driver Class Initialized
DEBUG - 2011-08-14 02:38:41 --> File loaded: application/views/table/main.php
DEBUG - 2011-08-14 02:38:41 --> Helper loaded: url_helper
DEBUG - 2011-08-14 02:38:41 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-14 02:38:41 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-14 02:38:41 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-14 02:38:41 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-14 02:38:41 --> Final output sent to browser
DEBUG - 2011-08-14 02:38:41 --> Total execution time: 0.5363
DEBUG - 2011-08-14 02:39:03 --> Config Class Initialized
DEBUG - 2011-08-14 02:39:03 --> Hooks Class Initialized
DEBUG - 2011-08-14 02:39:03 --> Utf8 Class Initialized
DEBUG - 2011-08-14 02:39:03 --> UTF-8 Support Enabled
DEBUG - 2011-08-14 02:39:03 --> URI Class Initialized
DEBUG - 2011-08-14 02:39:03 --> Router Class Initialized
ERROR - 2011-08-14 02:39:03 --> 404 Page Not Found --> robots.txt
DEBUG - 2011-08-14 02:39:03 --> Config Class Initialized
DEBUG - 2011-08-14 02:39:03 --> Hooks Class Initialized
DEBUG - 2011-08-14 02:39:03 --> Utf8 Class Initialized
DEBUG - 2011-08-14 02:39:03 --> UTF-8 Support Enabled
DEBUG - 2011-08-14 02:39:03 --> URI Class Initialized
DEBUG - 2011-08-14 02:39:03 --> Router Class Initialized
DEBUG - 2011-08-14 02:39:03 --> Output Class Initialized
DEBUG - 2011-08-14 02:39:03 --> Input Class Initialized
DEBUG - 2011-08-14 02:39:03 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-14 02:39:03 --> Language Class Initialized
DEBUG - 2011-08-14 02:39:03 --> Loader Class Initialized
DEBUG - 2011-08-14 02:39:03 --> Controller Class Initialized
DEBUG - 2011-08-14 02:39:03 --> Model Class Initialized
DEBUG - 2011-08-14 02:39:03 --> Model Class Initialized
DEBUG - 2011-08-14 02:39:03 --> Model Class Initialized
DEBUG - 2011-08-14 02:39:03 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-14 02:39:03 --> Database Driver Class Initialized
DEBUG - 2011-08-14 02:39:03 --> File loaded: application/views/table/main.php
DEBUG - 2011-08-14 02:39:03 --> Helper loaded: url_helper
DEBUG - 2011-08-14 02:39:03 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-14 02:39:03 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-14 02:39:03 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-14 02:39:03 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-14 02:39:03 --> Final output sent to browser
DEBUG - 2011-08-14 02:39:03 --> Total execution time: 0.0439
DEBUG - 2011-08-14 02:54:31 --> Config Class Initialized
DEBUG - 2011-08-14 02:54:31 --> Hooks Class Initialized
DEBUG - 2011-08-14 02:54:31 --> Utf8 Class Initialized
DEBUG - 2011-08-14 02:54:31 --> UTF-8 Support Enabled
DEBUG - 2011-08-14 02:54:31 --> URI Class Initialized
DEBUG - 2011-08-14 02:54:31 --> Router Class Initialized
DEBUG - 2011-08-14 02:54:31 --> Output Class Initialized
DEBUG - 2011-08-14 02:54:31 --> Input Class Initialized
DEBUG - 2011-08-14 02:54:31 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-14 02:54:31 --> Language Class Initialized
DEBUG - 2011-08-14 02:54:31 --> Loader Class Initialized
DEBUG - 2011-08-14 02:54:31 --> Controller Class Initialized
DEBUG - 2011-08-14 02:54:31 --> Model Class Initialized
DEBUG - 2011-08-14 02:54:31 --> Model Class Initialized
DEBUG - 2011-08-14 02:54:31 --> Model Class Initialized
DEBUG - 2011-08-14 02:54:31 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-14 02:54:31 --> Database Driver Class Initialized
DEBUG - 2011-08-14 02:54:31 --> File loaded: application/views/table/main.php
DEBUG - 2011-08-14 02:54:31 --> Helper loaded: url_helper
DEBUG - 2011-08-14 02:54:31 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-14 02:54:31 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-14 02:54:31 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-14 02:54:31 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-14 02:54:31 --> Final output sent to browser
DEBUG - 2011-08-14 02:54:31 --> Total execution time: 0.5255
DEBUG - 2011-08-14 02:54:33 --> Config Class Initialized
DEBUG - 2011-08-14 02:54:33 --> Hooks Class Initialized
DEBUG - 2011-08-14 02:54:33 --> Utf8 Class Initialized
DEBUG - 2011-08-14 02:54:33 --> UTF-8 Support Enabled
DEBUG - 2011-08-14 02:54:33 --> URI Class Initialized
DEBUG - 2011-08-14 02:54:33 --> Router Class Initialized
DEBUG - 2011-08-14 02:54:34 --> Output Class Initialized
DEBUG - 2011-08-14 02:54:34 --> Input Class Initialized
DEBUG - 2011-08-14 02:54:34 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-14 02:54:34 --> Language Class Initialized
DEBUG - 2011-08-14 02:54:34 --> Loader Class Initialized
DEBUG - 2011-08-14 02:54:34 --> Controller Class Initialized
ERROR - 2011-08-14 02:54:34 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-08-14 02:54:34 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-08-14 02:54:34 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-08-14 02:54:34 --> Model Class Initialized
DEBUG - 2011-08-14 02:54:34 --> Model Class Initialized
DEBUG - 2011-08-14 02:54:34 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-14 02:54:34 --> Database Driver Class Initialized
DEBUG - 2011-08-14 02:54:34 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-08-14 02:54:34 --> Helper loaded: url_helper
DEBUG - 2011-08-14 02:54:34 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-14 02:54:34 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-14 02:54:34 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-14 02:54:34 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-14 02:54:34 --> Final output sent to browser
DEBUG - 2011-08-14 02:54:34 --> Total execution time: 0.3371
DEBUG - 2011-08-14 02:54:37 --> Config Class Initialized
DEBUG - 2011-08-14 02:54:37 --> Hooks Class Initialized
DEBUG - 2011-08-14 02:54:37 --> Utf8 Class Initialized
DEBUG - 2011-08-14 02:54:37 --> UTF-8 Support Enabled
DEBUG - 2011-08-14 02:54:37 --> URI Class Initialized
DEBUG - 2011-08-14 02:54:37 --> Router Class Initialized
DEBUG - 2011-08-14 02:54:37 --> Output Class Initialized
DEBUG - 2011-08-14 02:54:37 --> Input Class Initialized
DEBUG - 2011-08-14 02:54:37 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-14 02:54:37 --> Language Class Initialized
DEBUG - 2011-08-14 02:54:37 --> Loader Class Initialized
DEBUG - 2011-08-14 02:54:37 --> Config Class Initialized
DEBUG - 2011-08-14 02:54:37 --> Hooks Class Initialized
DEBUG - 2011-08-14 02:54:37 --> Utf8 Class Initialized
DEBUG - 2011-08-14 02:54:37 --> UTF-8 Support Enabled
DEBUG - 2011-08-14 02:54:37 --> URI Class Initialized
DEBUG - 2011-08-14 02:54:37 --> Router Class Initialized
ERROR - 2011-08-14 02:54:37 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-08-14 02:54:37 --> Controller Class Initialized
DEBUG - 2011-08-14 02:54:37 --> Model Class Initialized
DEBUG - 2011-08-14 02:54:37 --> Model Class Initialized
DEBUG - 2011-08-14 02:54:37 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-14 02:54:37 --> Database Driver Class Initialized
DEBUG - 2011-08-14 02:54:38 --> Config Class Initialized
DEBUG - 2011-08-14 02:54:38 --> Hooks Class Initialized
DEBUG - 2011-08-14 02:54:38 --> Utf8 Class Initialized
DEBUG - 2011-08-14 02:54:38 --> UTF-8 Support Enabled
DEBUG - 2011-08-14 02:54:38 --> URI Class Initialized
DEBUG - 2011-08-14 02:54:38 --> Router Class Initialized
ERROR - 2011-08-14 02:54:38 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-08-14 02:54:38 --> Config Class Initialized
DEBUG - 2011-08-14 02:54:38 --> Hooks Class Initialized
DEBUG - 2011-08-14 02:54:38 --> Utf8 Class Initialized
DEBUG - 2011-08-14 02:54:38 --> UTF-8 Support Enabled
DEBUG - 2011-08-14 02:54:38 --> URI Class Initialized
DEBUG - 2011-08-14 02:54:38 --> Router Class Initialized
ERROR - 2011-08-14 02:54:38 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-08-14 02:54:39 --> Final output sent to browser
DEBUG - 2011-08-14 02:54:39 --> Total execution time: 1.9215
DEBUG - 2011-08-14 02:54:41 --> Config Class Initialized
DEBUG - 2011-08-14 02:54:41 --> Hooks Class Initialized
DEBUG - 2011-08-14 02:54:41 --> Utf8 Class Initialized
DEBUG - 2011-08-14 02:54:41 --> UTF-8 Support Enabled
DEBUG - 2011-08-14 02:54:41 --> URI Class Initialized
DEBUG - 2011-08-14 02:54:41 --> Router Class Initialized
ERROR - 2011-08-14 02:54:41 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-08-14 02:54:55 --> Config Class Initialized
DEBUG - 2011-08-14 02:54:55 --> Hooks Class Initialized
DEBUG - 2011-08-14 02:54:55 --> Utf8 Class Initialized
DEBUG - 2011-08-14 02:54:55 --> UTF-8 Support Enabled
DEBUG - 2011-08-14 02:54:55 --> URI Class Initialized
DEBUG - 2011-08-14 02:54:55 --> Router Class Initialized
DEBUG - 2011-08-14 02:54:55 --> Output Class Initialized
DEBUG - 2011-08-14 02:54:55 --> Input Class Initialized
DEBUG - 2011-08-14 02:54:55 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-14 02:54:55 --> Language Class Initialized
DEBUG - 2011-08-14 02:54:55 --> Loader Class Initialized
DEBUG - 2011-08-14 02:54:55 --> Controller Class Initialized
DEBUG - 2011-08-14 02:54:55 --> Model Class Initialized
DEBUG - 2011-08-14 02:54:55 --> Model Class Initialized
DEBUG - 2011-08-14 02:54:55 --> Model Class Initialized
DEBUG - 2011-08-14 02:54:55 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-14 02:54:55 --> Database Driver Class Initialized
DEBUG - 2011-08-14 02:54:55 --> File loaded: application/views/table/main.php
DEBUG - 2011-08-14 02:54:55 --> Helper loaded: url_helper
DEBUG - 2011-08-14 02:54:55 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-14 02:54:55 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-14 02:54:55 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-14 02:54:55 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-14 02:54:55 --> Final output sent to browser
DEBUG - 2011-08-14 02:54:55 --> Total execution time: 0.5245
DEBUG - 2011-08-14 02:54:57 --> Config Class Initialized
DEBUG - 2011-08-14 02:54:57 --> Hooks Class Initialized
DEBUG - 2011-08-14 02:54:57 --> Utf8 Class Initialized
DEBUG - 2011-08-14 02:54:57 --> UTF-8 Support Enabled
DEBUG - 2011-08-14 02:54:57 --> URI Class Initialized
DEBUG - 2011-08-14 02:54:57 --> Router Class Initialized
ERROR - 2011-08-14 02:54:57 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-08-14 02:55:30 --> Config Class Initialized
DEBUG - 2011-08-14 02:55:30 --> Hooks Class Initialized
DEBUG - 2011-08-14 02:55:30 --> Utf8 Class Initialized
DEBUG - 2011-08-14 02:55:30 --> UTF-8 Support Enabled
DEBUG - 2011-08-14 02:55:30 --> URI Class Initialized
DEBUG - 2011-08-14 02:55:30 --> Router Class Initialized
DEBUG - 2011-08-14 02:55:30 --> Output Class Initialized
DEBUG - 2011-08-14 02:55:30 --> Input Class Initialized
DEBUG - 2011-08-14 02:55:30 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-14 02:55:30 --> Language Class Initialized
DEBUG - 2011-08-14 02:55:30 --> Loader Class Initialized
DEBUG - 2011-08-14 02:55:30 --> Controller Class Initialized
DEBUG - 2011-08-14 02:55:30 --> Model Class Initialized
DEBUG - 2011-08-14 02:55:30 --> Model Class Initialized
DEBUG - 2011-08-14 02:55:30 --> Model Class Initialized
DEBUG - 2011-08-14 02:55:30 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-14 02:55:30 --> Database Driver Class Initialized
DEBUG - 2011-08-14 02:55:30 --> File loaded: application/views/table/main.php
DEBUG - 2011-08-14 02:55:30 --> Helper loaded: url_helper
DEBUG - 2011-08-14 02:55:30 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-14 02:55:30 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-14 02:55:30 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-14 02:55:30 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-14 02:55:30 --> Final output sent to browser
DEBUG - 2011-08-14 02:55:30 --> Total execution time: 0.0527
DEBUG - 2011-08-14 03:32:07 --> Config Class Initialized
DEBUG - 2011-08-14 03:32:07 --> Hooks Class Initialized
DEBUG - 2011-08-14 03:32:07 --> Utf8 Class Initialized
DEBUG - 2011-08-14 03:32:07 --> UTF-8 Support Enabled
DEBUG - 2011-08-14 03:32:07 --> URI Class Initialized
DEBUG - 2011-08-14 03:32:07 --> Router Class Initialized
DEBUG - 2011-08-14 03:32:07 --> No URI present. Default controller set.
DEBUG - 2011-08-14 03:32:07 --> Output Class Initialized
DEBUG - 2011-08-14 03:32:07 --> Input Class Initialized
DEBUG - 2011-08-14 03:32:07 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-14 03:32:07 --> Language Class Initialized
DEBUG - 2011-08-14 03:32:07 --> Loader Class Initialized
DEBUG - 2011-08-14 03:32:07 --> Controller Class Initialized
DEBUG - 2011-08-14 03:32:07 --> File loaded: application/views/splash/main.php
DEBUG - 2011-08-14 03:32:07 --> Helper loaded: url_helper
DEBUG - 2011-08-14 03:32:07 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-14 03:32:07 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-14 03:32:07 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-14 03:32:07 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-14 03:32:07 --> Final output sent to browser
DEBUG - 2011-08-14 03:32:07 --> Total execution time: 0.1825
DEBUG - 2011-08-14 03:43:57 --> Config Class Initialized
DEBUG - 2011-08-14 03:43:57 --> Hooks Class Initialized
DEBUG - 2011-08-14 03:43:57 --> Utf8 Class Initialized
DEBUG - 2011-08-14 03:43:57 --> UTF-8 Support Enabled
DEBUG - 2011-08-14 03:43:57 --> URI Class Initialized
DEBUG - 2011-08-14 03:43:57 --> Router Class Initialized
DEBUG - 2011-08-14 03:43:57 --> Output Class Initialized
DEBUG - 2011-08-14 03:43:57 --> Input Class Initialized
DEBUG - 2011-08-14 03:43:57 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-14 03:43:57 --> Language Class Initialized
DEBUG - 2011-08-14 03:43:57 --> Loader Class Initialized
DEBUG - 2011-08-14 03:43:57 --> Controller Class Initialized
DEBUG - 2011-08-14 03:43:57 --> Model Class Initialized
DEBUG - 2011-08-14 03:43:57 --> Model Class Initialized
DEBUG - 2011-08-14 03:43:57 --> Model Class Initialized
DEBUG - 2011-08-14 03:43:57 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-14 03:43:57 --> Database Driver Class Initialized
DEBUG - 2011-08-14 03:43:58 --> File loaded: application/views/table/main.php
DEBUG - 2011-08-14 03:43:58 --> Helper loaded: url_helper
DEBUG - 2011-08-14 03:43:58 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-14 03:43:58 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-14 03:43:58 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-14 03:43:58 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-14 03:43:58 --> Final output sent to browser
DEBUG - 2011-08-14 03:43:58 --> Total execution time: 0.9407
DEBUG - 2011-08-14 03:44:01 --> Config Class Initialized
DEBUG - 2011-08-14 03:44:01 --> Hooks Class Initialized
DEBUG - 2011-08-14 03:44:01 --> Utf8 Class Initialized
DEBUG - 2011-08-14 03:44:01 --> UTF-8 Support Enabled
DEBUG - 2011-08-14 03:44:01 --> URI Class Initialized
DEBUG - 2011-08-14 03:44:01 --> Router Class Initialized
ERROR - 2011-08-14 03:44:01 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-08-14 03:44:01 --> Config Class Initialized
DEBUG - 2011-08-14 03:44:01 --> Hooks Class Initialized
DEBUG - 2011-08-14 03:44:01 --> Utf8 Class Initialized
DEBUG - 2011-08-14 03:44:01 --> UTF-8 Support Enabled
DEBUG - 2011-08-14 03:44:01 --> URI Class Initialized
DEBUG - 2011-08-14 03:44:01 --> Router Class Initialized
ERROR - 2011-08-14 03:44:01 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-08-14 03:44:21 --> Config Class Initialized
DEBUG - 2011-08-14 03:44:21 --> Hooks Class Initialized
DEBUG - 2011-08-14 03:44:21 --> Utf8 Class Initialized
DEBUG - 2011-08-14 03:44:21 --> UTF-8 Support Enabled
DEBUG - 2011-08-14 03:44:21 --> URI Class Initialized
DEBUG - 2011-08-14 03:44:21 --> Router Class Initialized
DEBUG - 2011-08-14 03:44:21 --> Output Class Initialized
DEBUG - 2011-08-14 03:44:21 --> Input Class Initialized
DEBUG - 2011-08-14 03:44:21 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-14 03:44:21 --> Language Class Initialized
DEBUG - 2011-08-14 03:44:21 --> Loader Class Initialized
DEBUG - 2011-08-14 03:44:21 --> Controller Class Initialized
ERROR - 2011-08-14 03:44:21 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-08-14 03:44:21 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-08-14 03:44:21 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-08-14 03:44:21 --> Model Class Initialized
DEBUG - 2011-08-14 03:44:21 --> Model Class Initialized
DEBUG - 2011-08-14 03:44:21 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-14 03:44:21 --> Database Driver Class Initialized
DEBUG - 2011-08-14 03:44:21 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-08-14 03:44:21 --> Helper loaded: url_helper
DEBUG - 2011-08-14 03:44:21 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-14 03:44:21 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-14 03:44:21 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-14 03:44:21 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-14 03:44:21 --> Final output sent to browser
DEBUG - 2011-08-14 03:44:21 --> Total execution time: 0.0596
DEBUG - 2011-08-14 03:44:22 --> Config Class Initialized
DEBUG - 2011-08-14 03:44:22 --> Hooks Class Initialized
DEBUG - 2011-08-14 03:44:22 --> Utf8 Class Initialized
DEBUG - 2011-08-14 03:44:22 --> UTF-8 Support Enabled
DEBUG - 2011-08-14 03:44:22 --> URI Class Initialized
DEBUG - 2011-08-14 03:44:22 --> Router Class Initialized
DEBUG - 2011-08-14 03:44:22 --> Output Class Initialized
DEBUG - 2011-08-14 03:44:22 --> Input Class Initialized
DEBUG - 2011-08-14 03:44:22 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-14 03:44:22 --> Language Class Initialized
DEBUG - 2011-08-14 03:44:22 --> Loader Class Initialized
DEBUG - 2011-08-14 03:44:22 --> Controller Class Initialized
DEBUG - 2011-08-14 03:44:22 --> Model Class Initialized
DEBUG - 2011-08-14 03:44:22 --> Model Class Initialized
DEBUG - 2011-08-14 03:44:22 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-14 03:44:22 --> Database Driver Class Initialized
DEBUG - 2011-08-14 03:44:22 --> Final output sent to browser
DEBUG - 2011-08-14 03:44:22 --> Total execution time: 0.6861
DEBUG - 2011-08-14 04:15:39 --> Config Class Initialized
DEBUG - 2011-08-14 04:15:39 --> Hooks Class Initialized
DEBUG - 2011-08-14 04:15:39 --> Utf8 Class Initialized
DEBUG - 2011-08-14 04:15:39 --> UTF-8 Support Enabled
DEBUG - 2011-08-14 04:15:39 --> URI Class Initialized
DEBUG - 2011-08-14 04:15:39 --> Router Class Initialized
DEBUG - 2011-08-14 04:15:39 --> Output Class Initialized
DEBUG - 2011-08-14 04:15:39 --> Input Class Initialized
DEBUG - 2011-08-14 04:15:39 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-14 04:15:39 --> Language Class Initialized
DEBUG - 2011-08-14 04:15:39 --> Loader Class Initialized
DEBUG - 2011-08-14 04:15:39 --> Controller Class Initialized
DEBUG - 2011-08-14 04:15:39 --> Model Class Initialized
DEBUG - 2011-08-14 04:15:39 --> Model Class Initialized
DEBUG - 2011-08-14 04:15:39 --> Model Class Initialized
DEBUG - 2011-08-14 04:15:39 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-14 04:15:39 --> Database Driver Class Initialized
DEBUG - 2011-08-14 04:15:40 --> File loaded: application/views/table/main.php
DEBUG - 2011-08-14 04:15:40 --> Helper loaded: url_helper
DEBUG - 2011-08-14 04:15:40 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-14 04:15:40 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-14 04:15:40 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-14 04:15:40 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-14 04:15:40 --> Final output sent to browser
DEBUG - 2011-08-14 04:15:40 --> Total execution time: 0.3529
DEBUG - 2011-08-14 04:15:41 --> Config Class Initialized
DEBUG - 2011-08-14 04:15:41 --> Hooks Class Initialized
DEBUG - 2011-08-14 04:15:41 --> Utf8 Class Initialized
DEBUG - 2011-08-14 04:15:41 --> UTF-8 Support Enabled
DEBUG - 2011-08-14 04:15:41 --> URI Class Initialized
DEBUG - 2011-08-14 04:15:41 --> Router Class Initialized
ERROR - 2011-08-14 04:15:41 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-08-14 04:19:34 --> Config Class Initialized
DEBUG - 2011-08-14 04:19:34 --> Hooks Class Initialized
DEBUG - 2011-08-14 04:19:34 --> Utf8 Class Initialized
DEBUG - 2011-08-14 04:19:34 --> UTF-8 Support Enabled
DEBUG - 2011-08-14 04:19:34 --> URI Class Initialized
DEBUG - 2011-08-14 04:19:34 --> Router Class Initialized
DEBUG - 2011-08-14 04:19:34 --> Output Class Initialized
DEBUG - 2011-08-14 04:19:34 --> Input Class Initialized
DEBUG - 2011-08-14 04:19:34 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-14 04:19:34 --> Language Class Initialized
DEBUG - 2011-08-14 04:19:34 --> Loader Class Initialized
DEBUG - 2011-08-14 04:19:34 --> Controller Class Initialized
ERROR - 2011-08-14 04:19:34 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-08-14 04:19:34 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-08-14 04:19:34 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-08-14 04:19:34 --> Model Class Initialized
DEBUG - 2011-08-14 04:19:34 --> Model Class Initialized
DEBUG - 2011-08-14 04:19:34 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-14 04:19:34 --> Database Driver Class Initialized
DEBUG - 2011-08-14 04:19:34 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-08-14 04:19:34 --> Helper loaded: url_helper
DEBUG - 2011-08-14 04:19:34 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-14 04:19:34 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-14 04:19:34 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-14 04:19:34 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-14 04:19:34 --> Final output sent to browser
DEBUG - 2011-08-14 04:19:34 --> Total execution time: 0.0586
DEBUG - 2011-08-14 04:19:38 --> Config Class Initialized
DEBUG - 2011-08-14 04:19:38 --> Hooks Class Initialized
DEBUG - 2011-08-14 04:19:38 --> Utf8 Class Initialized
DEBUG - 2011-08-14 04:19:38 --> UTF-8 Support Enabled
DEBUG - 2011-08-14 04:19:38 --> URI Class Initialized
DEBUG - 2011-08-14 04:19:38 --> Router Class Initialized
DEBUG - 2011-08-14 04:19:38 --> Output Class Initialized
DEBUG - 2011-08-14 04:19:38 --> Input Class Initialized
DEBUG - 2011-08-14 04:19:38 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-14 04:19:38 --> Language Class Initialized
DEBUG - 2011-08-14 04:19:38 --> Loader Class Initialized
DEBUG - 2011-08-14 04:19:38 --> Controller Class Initialized
DEBUG - 2011-08-14 04:19:38 --> Model Class Initialized
DEBUG - 2011-08-14 04:19:38 --> Model Class Initialized
DEBUG - 2011-08-14 04:19:38 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-14 04:19:38 --> Database Driver Class Initialized
DEBUG - 2011-08-14 04:19:39 --> Final output sent to browser
DEBUG - 2011-08-14 04:19:39 --> Total execution time: 0.5998
DEBUG - 2011-08-14 04:19:44 --> Config Class Initialized
DEBUG - 2011-08-14 04:19:44 --> Hooks Class Initialized
DEBUG - 2011-08-14 04:19:44 --> Utf8 Class Initialized
DEBUG - 2011-08-14 04:19:44 --> UTF-8 Support Enabled
DEBUG - 2011-08-14 04:19:44 --> URI Class Initialized
DEBUG - 2011-08-14 04:19:44 --> Router Class Initialized
ERROR - 2011-08-14 04:19:44 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-08-14 04:19:45 --> Config Class Initialized
DEBUG - 2011-08-14 04:19:45 --> Hooks Class Initialized
DEBUG - 2011-08-14 04:19:45 --> Utf8 Class Initialized
DEBUG - 2011-08-14 04:19:45 --> UTF-8 Support Enabled
DEBUG - 2011-08-14 04:19:45 --> URI Class Initialized
DEBUG - 2011-08-14 04:19:45 --> Router Class Initialized
ERROR - 2011-08-14 04:19:45 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-08-14 04:20:09 --> Config Class Initialized
DEBUG - 2011-08-14 04:20:09 --> Hooks Class Initialized
DEBUG - 2011-08-14 04:20:09 --> Utf8 Class Initialized
DEBUG - 2011-08-14 04:20:09 --> UTF-8 Support Enabled
DEBUG - 2011-08-14 04:20:09 --> URI Class Initialized
DEBUG - 2011-08-14 04:20:09 --> Router Class Initialized
DEBUG - 2011-08-14 04:20:09 --> Output Class Initialized
DEBUG - 2011-08-14 04:20:09 --> Input Class Initialized
DEBUG - 2011-08-14 04:20:09 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-14 04:20:09 --> Language Class Initialized
DEBUG - 2011-08-14 04:20:09 --> Loader Class Initialized
DEBUG - 2011-08-14 04:20:09 --> Controller Class Initialized
ERROR - 2011-08-14 04:20:09 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-08-14 04:20:09 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-08-14 04:20:09 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-08-14 04:20:09 --> Model Class Initialized
DEBUG - 2011-08-14 04:20:09 --> Model Class Initialized
DEBUG - 2011-08-14 04:20:09 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-14 04:20:09 --> Database Driver Class Initialized
DEBUG - 2011-08-14 04:20:09 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-08-14 04:20:09 --> Helper loaded: url_helper
DEBUG - 2011-08-14 04:20:09 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-14 04:20:09 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-14 04:20:09 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-14 04:20:09 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-14 04:20:09 --> Final output sent to browser
DEBUG - 2011-08-14 04:20:09 --> Total execution time: 0.0305
DEBUG - 2011-08-14 04:20:10 --> Config Class Initialized
DEBUG - 2011-08-14 04:20:10 --> Hooks Class Initialized
DEBUG - 2011-08-14 04:20:10 --> Utf8 Class Initialized
DEBUG - 2011-08-14 04:20:10 --> UTF-8 Support Enabled
DEBUG - 2011-08-14 04:20:10 --> URI Class Initialized
DEBUG - 2011-08-14 04:20:10 --> Router Class Initialized
DEBUG - 2011-08-14 04:20:10 --> Output Class Initialized
DEBUG - 2011-08-14 04:20:10 --> Input Class Initialized
DEBUG - 2011-08-14 04:20:10 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-14 04:20:10 --> Language Class Initialized
DEBUG - 2011-08-14 04:20:10 --> Loader Class Initialized
DEBUG - 2011-08-14 04:20:10 --> Controller Class Initialized
DEBUG - 2011-08-14 04:20:10 --> Model Class Initialized
DEBUG - 2011-08-14 04:20:10 --> Model Class Initialized
DEBUG - 2011-08-14 04:20:10 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-14 04:20:10 --> Database Driver Class Initialized
DEBUG - 2011-08-14 04:20:10 --> Final output sent to browser
DEBUG - 2011-08-14 04:20:10 --> Total execution time: 0.6633
DEBUG - 2011-08-14 04:29:19 --> Config Class Initialized
DEBUG - 2011-08-14 04:29:19 --> Hooks Class Initialized
DEBUG - 2011-08-14 04:29:19 --> Utf8 Class Initialized
DEBUG - 2011-08-14 04:29:19 --> UTF-8 Support Enabled
DEBUG - 2011-08-14 04:29:19 --> URI Class Initialized
DEBUG - 2011-08-14 04:29:19 --> Router Class Initialized
DEBUG - 2011-08-14 04:29:19 --> Output Class Initialized
DEBUG - 2011-08-14 04:29:19 --> Input Class Initialized
DEBUG - 2011-08-14 04:29:19 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-14 04:29:19 --> Language Class Initialized
DEBUG - 2011-08-14 04:29:19 --> Loader Class Initialized
DEBUG - 2011-08-14 04:29:19 --> Controller Class Initialized
DEBUG - 2011-08-14 04:29:19 --> Model Class Initialized
DEBUG - 2011-08-14 04:29:19 --> Model Class Initialized
DEBUG - 2011-08-14 04:29:19 --> Model Class Initialized
DEBUG - 2011-08-14 04:29:19 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-14 04:29:19 --> Database Driver Class Initialized
DEBUG - 2011-08-14 04:29:19 --> File loaded: application/views/table/main.php
DEBUG - 2011-08-14 04:29:19 --> Helper loaded: url_helper
DEBUG - 2011-08-14 04:29:19 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-14 04:29:19 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-14 04:29:19 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-14 04:29:19 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-14 04:29:19 --> Final output sent to browser
DEBUG - 2011-08-14 04:29:19 --> Total execution time: 0.0607
DEBUG - 2011-08-14 04:29:19 --> Config Class Initialized
DEBUG - 2011-08-14 04:29:19 --> Hooks Class Initialized
DEBUG - 2011-08-14 04:29:19 --> Utf8 Class Initialized
DEBUG - 2011-08-14 04:29:19 --> UTF-8 Support Enabled
DEBUG - 2011-08-14 04:29:19 --> URI Class Initialized
DEBUG - 2011-08-14 04:29:19 --> Router Class Initialized
DEBUG - 2011-08-14 04:29:19 --> Output Class Initialized
DEBUG - 2011-08-14 04:29:19 --> Input Class Initialized
DEBUG - 2011-08-14 04:29:19 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-14 04:29:19 --> Language Class Initialized
DEBUG - 2011-08-14 04:29:19 --> Loader Class Initialized
DEBUG - 2011-08-14 04:29:19 --> Controller Class Initialized
ERROR - 2011-08-14 04:29:19 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-08-14 04:29:19 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-08-14 04:29:19 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-08-14 04:29:19 --> Model Class Initialized
DEBUG - 2011-08-14 04:29:19 --> Model Class Initialized
DEBUG - 2011-08-14 04:29:19 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-14 04:29:19 --> Database Driver Class Initialized
DEBUG - 2011-08-14 04:29:19 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-08-14 04:29:19 --> Helper loaded: url_helper
DEBUG - 2011-08-14 04:29:19 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-14 04:29:19 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-14 04:29:19 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-14 04:29:19 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-14 04:29:19 --> Final output sent to browser
DEBUG - 2011-08-14 04:29:19 --> Total execution time: 0.0269
DEBUG - 2011-08-14 04:29:20 --> Config Class Initialized
DEBUG - 2011-08-14 04:29:20 --> Hooks Class Initialized
DEBUG - 2011-08-14 04:29:20 --> Utf8 Class Initialized
DEBUG - 2011-08-14 04:29:20 --> UTF-8 Support Enabled
DEBUG - 2011-08-14 04:29:20 --> URI Class Initialized
DEBUG - 2011-08-14 04:29:20 --> Router Class Initialized
DEBUG - 2011-08-14 04:29:20 --> Output Class Initialized
DEBUG - 2011-08-14 04:29:20 --> Input Class Initialized
DEBUG - 2011-08-14 04:29:20 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-14 04:29:20 --> Language Class Initialized
DEBUG - 2011-08-14 04:29:20 --> Loader Class Initialized
DEBUG - 2011-08-14 04:29:20 --> Controller Class Initialized
DEBUG - 2011-08-14 04:29:20 --> Model Class Initialized
DEBUG - 2011-08-14 04:29:20 --> Model Class Initialized
DEBUG - 2011-08-14 04:29:20 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-14 04:29:20 --> Database Driver Class Initialized
DEBUG - 2011-08-14 04:29:20 --> Final output sent to browser
DEBUG - 2011-08-14 04:29:20 --> Total execution time: 0.4756
DEBUG - 2011-08-14 04:29:22 --> Config Class Initialized
DEBUG - 2011-08-14 04:29:22 --> Hooks Class Initialized
DEBUG - 2011-08-14 04:29:22 --> Utf8 Class Initialized
DEBUG - 2011-08-14 04:29:22 --> UTF-8 Support Enabled
DEBUG - 2011-08-14 04:29:22 --> URI Class Initialized
DEBUG - 2011-08-14 04:29:22 --> Router Class Initialized
ERROR - 2011-08-14 04:29:22 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-08-14 04:29:22 --> Config Class Initialized
DEBUG - 2011-08-14 04:29:22 --> Hooks Class Initialized
DEBUG - 2011-08-14 04:29:22 --> Utf8 Class Initialized
DEBUG - 2011-08-14 04:29:22 --> UTF-8 Support Enabled
DEBUG - 2011-08-14 04:29:22 --> URI Class Initialized
DEBUG - 2011-08-14 04:29:22 --> Router Class Initialized
ERROR - 2011-08-14 04:29:22 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-08-14 04:29:22 --> Config Class Initialized
DEBUG - 2011-08-14 04:29:22 --> Hooks Class Initialized
DEBUG - 2011-08-14 04:29:22 --> Utf8 Class Initialized
DEBUG - 2011-08-14 04:29:22 --> UTF-8 Support Enabled
DEBUG - 2011-08-14 04:29:22 --> URI Class Initialized
DEBUG - 2011-08-14 04:29:22 --> Router Class Initialized
ERROR - 2011-08-14 04:29:22 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-08-14 04:29:22 --> Config Class Initialized
DEBUG - 2011-08-14 04:29:22 --> Hooks Class Initialized
DEBUG - 2011-08-14 04:29:22 --> Utf8 Class Initialized
DEBUG - 2011-08-14 04:29:22 --> UTF-8 Support Enabled
DEBUG - 2011-08-14 04:29:22 --> URI Class Initialized
DEBUG - 2011-08-14 04:29:22 --> Router Class Initialized
ERROR - 2011-08-14 04:29:22 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-08-14 04:29:22 --> Config Class Initialized
DEBUG - 2011-08-14 04:29:22 --> Hooks Class Initialized
DEBUG - 2011-08-14 04:29:22 --> Utf8 Class Initialized
DEBUG - 2011-08-14 04:29:22 --> UTF-8 Support Enabled
DEBUG - 2011-08-14 04:29:22 --> URI Class Initialized
DEBUG - 2011-08-14 04:29:22 --> Router Class Initialized
ERROR - 2011-08-14 04:29:22 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-08-14 04:29:25 --> Config Class Initialized
DEBUG - 2011-08-14 04:29:25 --> Hooks Class Initialized
DEBUG - 2011-08-14 04:29:25 --> Utf8 Class Initialized
DEBUG - 2011-08-14 04:29:25 --> UTF-8 Support Enabled
DEBUG - 2011-08-14 04:29:25 --> URI Class Initialized
DEBUG - 2011-08-14 04:29:25 --> Router Class Initialized
ERROR - 2011-08-14 04:29:25 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-08-14 04:29:30 --> Config Class Initialized
DEBUG - 2011-08-14 04:29:30 --> Hooks Class Initialized
DEBUG - 2011-08-14 04:29:30 --> Utf8 Class Initialized
DEBUG - 2011-08-14 04:29:30 --> UTF-8 Support Enabled
DEBUG - 2011-08-14 04:29:30 --> URI Class Initialized
DEBUG - 2011-08-14 04:29:30 --> Router Class Initialized
ERROR - 2011-08-14 04:29:30 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-08-14 04:29:31 --> Config Class Initialized
DEBUG - 2011-08-14 04:29:31 --> Hooks Class Initialized
DEBUG - 2011-08-14 04:29:31 --> Utf8 Class Initialized
DEBUG - 2011-08-14 04:29:31 --> UTF-8 Support Enabled
DEBUG - 2011-08-14 04:29:31 --> URI Class Initialized
DEBUG - 2011-08-14 04:29:31 --> Router Class Initialized
ERROR - 2011-08-14 04:29:31 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-08-14 05:06:14 --> Config Class Initialized
DEBUG - 2011-08-14 05:06:14 --> Hooks Class Initialized
DEBUG - 2011-08-14 05:06:14 --> Utf8 Class Initialized
DEBUG - 2011-08-14 05:06:14 --> UTF-8 Support Enabled
DEBUG - 2011-08-14 05:06:14 --> URI Class Initialized
DEBUG - 2011-08-14 05:06:14 --> Router Class Initialized
DEBUG - 2011-08-14 05:06:14 --> Output Class Initialized
DEBUG - 2011-08-14 05:06:14 --> Input Class Initialized
DEBUG - 2011-08-14 05:06:14 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-14 05:06:14 --> Language Class Initialized
DEBUG - 2011-08-14 05:06:14 --> Loader Class Initialized
DEBUG - 2011-08-14 05:06:14 --> Controller Class Initialized
DEBUG - 2011-08-14 05:06:14 --> Model Class Initialized
DEBUG - 2011-08-14 05:06:14 --> Model Class Initialized
DEBUG - 2011-08-14 05:06:14 --> Model Class Initialized
DEBUG - 2011-08-14 05:06:14 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-14 05:06:14 --> Database Driver Class Initialized
DEBUG - 2011-08-14 05:06:14 --> File loaded: application/views/table/main.php
DEBUG - 2011-08-14 05:06:14 --> Helper loaded: url_helper
DEBUG - 2011-08-14 05:06:14 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-14 05:06:14 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-14 05:06:14 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-14 05:06:14 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-14 05:06:14 --> Final output sent to browser
DEBUG - 2011-08-14 05:06:14 --> Total execution time: 0.6661
DEBUG - 2011-08-14 05:06:16 --> Config Class Initialized
DEBUG - 2011-08-14 05:06:16 --> Hooks Class Initialized
DEBUG - 2011-08-14 05:06:16 --> Utf8 Class Initialized
DEBUG - 2011-08-14 05:06:16 --> UTF-8 Support Enabled
DEBUG - 2011-08-14 05:06:16 --> URI Class Initialized
DEBUG - 2011-08-14 05:06:16 --> Router Class Initialized
DEBUG - 2011-08-14 05:06:16 --> Output Class Initialized
DEBUG - 2011-08-14 05:06:16 --> Input Class Initialized
DEBUG - 2011-08-14 05:06:16 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-14 05:06:16 --> Language Class Initialized
DEBUG - 2011-08-14 05:06:16 --> Loader Class Initialized
DEBUG - 2011-08-14 05:06:16 --> Controller Class Initialized
ERROR - 2011-08-14 05:06:16 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-08-14 05:06:16 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-08-14 05:06:16 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-08-14 05:06:16 --> Model Class Initialized
DEBUG - 2011-08-14 05:06:16 --> Model Class Initialized
DEBUG - 2011-08-14 05:06:16 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-14 05:06:16 --> Database Driver Class Initialized
DEBUG - 2011-08-14 05:06:16 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-08-14 05:06:16 --> Helper loaded: url_helper
DEBUG - 2011-08-14 05:06:16 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-14 05:06:16 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-14 05:06:16 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-14 05:06:16 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-14 05:06:16 --> Final output sent to browser
DEBUG - 2011-08-14 05:06:16 --> Total execution time: 0.1004
DEBUG - 2011-08-14 05:06:17 --> Config Class Initialized
DEBUG - 2011-08-14 05:06:17 --> Hooks Class Initialized
DEBUG - 2011-08-14 05:06:17 --> Utf8 Class Initialized
DEBUG - 2011-08-14 05:06:17 --> UTF-8 Support Enabled
DEBUG - 2011-08-14 05:06:17 --> URI Class Initialized
DEBUG - 2011-08-14 05:06:17 --> Router Class Initialized
DEBUG - 2011-08-14 05:06:17 --> Output Class Initialized
DEBUG - 2011-08-14 05:06:17 --> Input Class Initialized
DEBUG - 2011-08-14 05:06:17 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-14 05:06:17 --> Language Class Initialized
DEBUG - 2011-08-14 05:06:17 --> Loader Class Initialized
DEBUG - 2011-08-14 05:06:17 --> Controller Class Initialized
DEBUG - 2011-08-14 05:06:17 --> Model Class Initialized
DEBUG - 2011-08-14 05:06:17 --> Model Class Initialized
DEBUG - 2011-08-14 05:06:17 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-14 05:06:17 --> Database Driver Class Initialized
DEBUG - 2011-08-14 05:06:18 --> Final output sent to browser
DEBUG - 2011-08-14 05:06:18 --> Total execution time: 0.5812
DEBUG - 2011-08-14 05:06:33 --> Config Class Initialized
DEBUG - 2011-08-14 05:06:33 --> Hooks Class Initialized
DEBUG - 2011-08-14 05:06:33 --> Utf8 Class Initialized
DEBUG - 2011-08-14 05:06:33 --> UTF-8 Support Enabled
DEBUG - 2011-08-14 05:06:33 --> URI Class Initialized
DEBUG - 2011-08-14 05:06:33 --> Router Class Initialized
DEBUG - 2011-08-14 05:06:33 --> Output Class Initialized
DEBUG - 2011-08-14 05:06:33 --> Input Class Initialized
DEBUG - 2011-08-14 05:06:33 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-14 05:06:33 --> Language Class Initialized
DEBUG - 2011-08-14 05:06:33 --> Loader Class Initialized
DEBUG - 2011-08-14 05:06:33 --> Controller Class Initialized
ERROR - 2011-08-14 05:06:33 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-08-14 05:06:33 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-08-14 05:06:33 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-08-14 05:06:33 --> Model Class Initialized
DEBUG - 2011-08-14 05:06:33 --> Model Class Initialized
DEBUG - 2011-08-14 05:06:33 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-14 05:06:33 --> Database Driver Class Initialized
DEBUG - 2011-08-14 05:06:33 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-08-14 05:06:33 --> Helper loaded: url_helper
DEBUG - 2011-08-14 05:06:33 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-14 05:06:33 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-14 05:06:33 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-14 05:06:33 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-14 05:06:33 --> Final output sent to browser
DEBUG - 2011-08-14 05:06:33 --> Total execution time: 0.0313
DEBUG - 2011-08-14 05:06:34 --> Config Class Initialized
DEBUG - 2011-08-14 05:06:34 --> Hooks Class Initialized
DEBUG - 2011-08-14 05:06:34 --> Utf8 Class Initialized
DEBUG - 2011-08-14 05:06:34 --> UTF-8 Support Enabled
DEBUG - 2011-08-14 05:06:34 --> URI Class Initialized
DEBUG - 2011-08-14 05:06:34 --> Router Class Initialized
DEBUG - 2011-08-14 05:06:34 --> Output Class Initialized
DEBUG - 2011-08-14 05:06:34 --> Input Class Initialized
DEBUG - 2011-08-14 05:06:34 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-14 05:06:34 --> Language Class Initialized
DEBUG - 2011-08-14 05:06:34 --> Loader Class Initialized
DEBUG - 2011-08-14 05:06:34 --> Controller Class Initialized
DEBUG - 2011-08-14 05:06:34 --> Model Class Initialized
DEBUG - 2011-08-14 05:06:34 --> Model Class Initialized
DEBUG - 2011-08-14 05:06:34 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-14 05:06:34 --> Database Driver Class Initialized
DEBUG - 2011-08-14 05:06:34 --> Final output sent to browser
DEBUG - 2011-08-14 05:06:34 --> Total execution time: 0.6369
DEBUG - 2011-08-14 05:48:27 --> Config Class Initialized
DEBUG - 2011-08-14 05:48:27 --> Hooks Class Initialized
DEBUG - 2011-08-14 05:48:27 --> Utf8 Class Initialized
DEBUG - 2011-08-14 05:48:27 --> UTF-8 Support Enabled
DEBUG - 2011-08-14 05:48:27 --> URI Class Initialized
DEBUG - 2011-08-14 05:48:27 --> Router Class Initialized
ERROR - 2011-08-14 05:48:27 --> 404 Page Not Found --> robots.txt
DEBUG - 2011-08-14 07:31:38 --> Config Class Initialized
DEBUG - 2011-08-14 07:31:38 --> Hooks Class Initialized
DEBUG - 2011-08-14 07:31:38 --> Utf8 Class Initialized
DEBUG - 2011-08-14 07:31:38 --> UTF-8 Support Enabled
DEBUG - 2011-08-14 07:31:38 --> URI Class Initialized
DEBUG - 2011-08-14 07:31:38 --> Router Class Initialized
DEBUG - 2011-08-14 07:31:38 --> Output Class Initialized
DEBUG - 2011-08-14 07:31:38 --> Input Class Initialized
DEBUG - 2011-08-14 07:31:38 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-14 07:31:38 --> Language Class Initialized
DEBUG - 2011-08-14 07:31:38 --> Loader Class Initialized
DEBUG - 2011-08-14 07:31:38 --> Controller Class Initialized
ERROR - 2011-08-14 07:31:38 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-08-14 07:31:38 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-08-14 07:31:38 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-08-14 07:31:38 --> Model Class Initialized
DEBUG - 2011-08-14 07:31:38 --> Model Class Initialized
DEBUG - 2011-08-14 07:31:38 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-14 07:31:38 --> Database Driver Class Initialized
DEBUG - 2011-08-14 07:31:38 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-08-14 07:31:38 --> Helper loaded: url_helper
DEBUG - 2011-08-14 07:31:38 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-14 07:31:38 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-14 07:31:38 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-14 07:31:38 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-14 07:31:38 --> Final output sent to browser
DEBUG - 2011-08-14 07:31:38 --> Total execution time: 0.3067
DEBUG - 2011-08-14 07:31:40 --> Config Class Initialized
DEBUG - 2011-08-14 07:31:40 --> Hooks Class Initialized
DEBUG - 2011-08-14 07:31:40 --> Utf8 Class Initialized
DEBUG - 2011-08-14 07:31:40 --> UTF-8 Support Enabled
DEBUG - 2011-08-14 07:31:40 --> URI Class Initialized
DEBUG - 2011-08-14 07:31:40 --> Router Class Initialized
DEBUG - 2011-08-14 07:31:40 --> Output Class Initialized
DEBUG - 2011-08-14 07:31:40 --> Input Class Initialized
DEBUG - 2011-08-14 07:31:40 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-14 07:31:40 --> Language Class Initialized
DEBUG - 2011-08-14 07:31:40 --> Loader Class Initialized
DEBUG - 2011-08-14 07:31:40 --> Controller Class Initialized
DEBUG - 2011-08-14 07:31:40 --> Model Class Initialized
DEBUG - 2011-08-14 07:31:40 --> Model Class Initialized
DEBUG - 2011-08-14 07:31:40 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-14 07:31:40 --> Database Driver Class Initialized
DEBUG - 2011-08-14 07:31:40 --> Final output sent to browser
DEBUG - 2011-08-14 07:31:40 --> Total execution time: 0.6128
DEBUG - 2011-08-14 07:31:42 --> Config Class Initialized
DEBUG - 2011-08-14 07:31:42 --> Hooks Class Initialized
DEBUG - 2011-08-14 07:31:42 --> Utf8 Class Initialized
DEBUG - 2011-08-14 07:31:42 --> UTF-8 Support Enabled
DEBUG - 2011-08-14 07:31:42 --> URI Class Initialized
DEBUG - 2011-08-14 07:31:42 --> Router Class Initialized
ERROR - 2011-08-14 07:31:42 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-08-14 07:31:50 --> Config Class Initialized
DEBUG - 2011-08-14 07:31:50 --> Hooks Class Initialized
DEBUG - 2011-08-14 07:31:50 --> Utf8 Class Initialized
DEBUG - 2011-08-14 07:31:50 --> UTF-8 Support Enabled
DEBUG - 2011-08-14 07:31:50 --> URI Class Initialized
DEBUG - 2011-08-14 07:31:50 --> Router Class Initialized
DEBUG - 2011-08-14 07:31:50 --> Output Class Initialized
DEBUG - 2011-08-14 07:31:50 --> Input Class Initialized
DEBUG - 2011-08-14 07:31:50 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-14 07:31:50 --> Language Class Initialized
DEBUG - 2011-08-14 07:31:50 --> Loader Class Initialized
DEBUG - 2011-08-14 07:31:50 --> Controller Class Initialized
ERROR - 2011-08-14 07:31:50 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-08-14 07:31:50 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-08-14 07:31:50 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-08-14 07:31:50 --> Model Class Initialized
DEBUG - 2011-08-14 07:31:50 --> Model Class Initialized
DEBUG - 2011-08-14 07:31:50 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-14 07:31:50 --> Database Driver Class Initialized
DEBUG - 2011-08-14 07:31:50 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-08-14 07:31:50 --> Helper loaded: url_helper
DEBUG - 2011-08-14 07:31:50 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-14 07:31:50 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-14 07:31:50 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-14 07:31:50 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-14 07:31:50 --> Final output sent to browser
DEBUG - 2011-08-14 07:31:50 --> Total execution time: 0.0259
DEBUG - 2011-08-14 07:31:50 --> Config Class Initialized
DEBUG - 2011-08-14 07:31:50 --> Hooks Class Initialized
DEBUG - 2011-08-14 07:31:50 --> Utf8 Class Initialized
DEBUG - 2011-08-14 07:31:50 --> UTF-8 Support Enabled
DEBUG - 2011-08-14 07:31:50 --> URI Class Initialized
DEBUG - 2011-08-14 07:31:50 --> Router Class Initialized
DEBUG - 2011-08-14 07:31:50 --> Output Class Initialized
DEBUG - 2011-08-14 07:31:50 --> Input Class Initialized
DEBUG - 2011-08-14 07:31:50 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-14 07:31:50 --> Language Class Initialized
DEBUG - 2011-08-14 07:31:50 --> Loader Class Initialized
DEBUG - 2011-08-14 07:31:50 --> Controller Class Initialized
DEBUG - 2011-08-14 07:31:50 --> Model Class Initialized
DEBUG - 2011-08-14 07:31:50 --> Model Class Initialized
DEBUG - 2011-08-14 07:31:50 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-14 07:31:50 --> Database Driver Class Initialized
DEBUG - 2011-08-14 07:31:51 --> Final output sent to browser
DEBUG - 2011-08-14 07:31:51 --> Total execution time: 0.9514
DEBUG - 2011-08-14 07:31:53 --> Config Class Initialized
DEBUG - 2011-08-14 07:31:53 --> Hooks Class Initialized
DEBUG - 2011-08-14 07:31:53 --> Utf8 Class Initialized
DEBUG - 2011-08-14 07:31:53 --> UTF-8 Support Enabled
DEBUG - 2011-08-14 07:31:53 --> URI Class Initialized
DEBUG - 2011-08-14 07:31:53 --> Router Class Initialized
ERROR - 2011-08-14 07:31:53 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-08-14 07:31:55 --> Config Class Initialized
DEBUG - 2011-08-14 07:31:55 --> Hooks Class Initialized
DEBUG - 2011-08-14 07:31:55 --> Utf8 Class Initialized
DEBUG - 2011-08-14 07:31:55 --> UTF-8 Support Enabled
DEBUG - 2011-08-14 07:31:55 --> URI Class Initialized
DEBUG - 2011-08-14 07:31:55 --> Router Class Initialized
DEBUG - 2011-08-14 07:31:55 --> Output Class Initialized
DEBUG - 2011-08-14 07:31:55 --> Input Class Initialized
DEBUG - 2011-08-14 07:31:55 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-14 07:31:55 --> Language Class Initialized
DEBUG - 2011-08-14 07:31:55 --> Loader Class Initialized
DEBUG - 2011-08-14 07:31:55 --> Controller Class Initialized
ERROR - 2011-08-14 07:31:55 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-08-14 07:31:55 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-08-14 07:31:55 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-08-14 07:31:55 --> Model Class Initialized
DEBUG - 2011-08-14 07:31:55 --> Model Class Initialized
DEBUG - 2011-08-14 07:31:55 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-14 07:31:55 --> Database Driver Class Initialized
DEBUG - 2011-08-14 07:31:55 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-08-14 07:31:55 --> Helper loaded: url_helper
DEBUG - 2011-08-14 07:31:55 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-14 07:31:55 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-14 07:31:55 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-14 07:31:55 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-14 07:31:55 --> Final output sent to browser
DEBUG - 2011-08-14 07:31:55 --> Total execution time: 0.0296
DEBUG - 2011-08-14 07:31:55 --> Config Class Initialized
DEBUG - 2011-08-14 07:31:55 --> Hooks Class Initialized
DEBUG - 2011-08-14 07:31:55 --> Utf8 Class Initialized
DEBUG - 2011-08-14 07:31:55 --> UTF-8 Support Enabled
DEBUG - 2011-08-14 07:31:55 --> URI Class Initialized
DEBUG - 2011-08-14 07:31:55 --> Router Class Initialized
DEBUG - 2011-08-14 07:31:55 --> Output Class Initialized
DEBUG - 2011-08-14 07:31:55 --> Input Class Initialized
DEBUG - 2011-08-14 07:31:55 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-14 07:31:55 --> Language Class Initialized
DEBUG - 2011-08-14 07:31:55 --> Loader Class Initialized
DEBUG - 2011-08-14 07:31:55 --> Controller Class Initialized
DEBUG - 2011-08-14 07:31:55 --> Model Class Initialized
DEBUG - 2011-08-14 07:31:55 --> Model Class Initialized
DEBUG - 2011-08-14 07:31:55 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-14 07:31:55 --> Database Driver Class Initialized
DEBUG - 2011-08-14 07:31:56 --> Final output sent to browser
DEBUG - 2011-08-14 07:31:56 --> Total execution time: 0.5650
DEBUG - 2011-08-14 07:31:57 --> Config Class Initialized
DEBUG - 2011-08-14 07:31:57 --> Hooks Class Initialized
DEBUG - 2011-08-14 07:31:57 --> Utf8 Class Initialized
DEBUG - 2011-08-14 07:31:57 --> UTF-8 Support Enabled
DEBUG - 2011-08-14 07:31:57 --> URI Class Initialized
DEBUG - 2011-08-14 07:31:57 --> Router Class Initialized
ERROR - 2011-08-14 07:31:57 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-08-14 07:32:05 --> Config Class Initialized
DEBUG - 2011-08-14 07:32:05 --> Hooks Class Initialized
DEBUG - 2011-08-14 07:32:05 --> Utf8 Class Initialized
DEBUG - 2011-08-14 07:32:05 --> UTF-8 Support Enabled
DEBUG - 2011-08-14 07:32:05 --> URI Class Initialized
DEBUG - 2011-08-14 07:32:05 --> Router Class Initialized
DEBUG - 2011-08-14 07:32:05 --> Output Class Initialized
DEBUG - 2011-08-14 07:32:05 --> Input Class Initialized
DEBUG - 2011-08-14 07:32:05 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-14 07:32:05 --> Language Class Initialized
DEBUG - 2011-08-14 07:32:05 --> Loader Class Initialized
DEBUG - 2011-08-14 07:32:05 --> Controller Class Initialized
ERROR - 2011-08-14 07:32:05 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-08-14 07:32:05 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-08-14 07:32:05 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-08-14 07:32:05 --> Model Class Initialized
DEBUG - 2011-08-14 07:32:05 --> Model Class Initialized
DEBUG - 2011-08-14 07:32:05 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-14 07:32:05 --> Database Driver Class Initialized
DEBUG - 2011-08-14 07:32:05 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-08-14 07:32:05 --> Helper loaded: url_helper
DEBUG - 2011-08-14 07:32:05 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-14 07:32:05 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-14 07:32:05 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-14 07:32:05 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-14 07:32:05 --> Final output sent to browser
DEBUG - 2011-08-14 07:32:05 --> Total execution time: 0.0322
DEBUG - 2011-08-14 07:32:06 --> Config Class Initialized
DEBUG - 2011-08-14 07:32:06 --> Hooks Class Initialized
DEBUG - 2011-08-14 07:32:06 --> Utf8 Class Initialized
DEBUG - 2011-08-14 07:32:06 --> UTF-8 Support Enabled
DEBUG - 2011-08-14 07:32:06 --> URI Class Initialized
DEBUG - 2011-08-14 07:32:06 --> Router Class Initialized
DEBUG - 2011-08-14 07:32:06 --> Output Class Initialized
DEBUG - 2011-08-14 07:32:06 --> Input Class Initialized
DEBUG - 2011-08-14 07:32:06 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-14 07:32:06 --> Language Class Initialized
DEBUG - 2011-08-14 07:32:06 --> Loader Class Initialized
DEBUG - 2011-08-14 07:32:06 --> Controller Class Initialized
DEBUG - 2011-08-14 07:32:06 --> Model Class Initialized
DEBUG - 2011-08-14 07:32:06 --> Model Class Initialized
DEBUG - 2011-08-14 07:32:06 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-14 07:32:06 --> Database Driver Class Initialized
DEBUG - 2011-08-14 07:32:07 --> Final output sent to browser
DEBUG - 2011-08-14 07:32:07 --> Total execution time: 0.6508
DEBUG - 2011-08-14 07:32:08 --> Config Class Initialized
DEBUG - 2011-08-14 07:32:08 --> Hooks Class Initialized
DEBUG - 2011-08-14 07:32:08 --> Utf8 Class Initialized
DEBUG - 2011-08-14 07:32:08 --> UTF-8 Support Enabled
DEBUG - 2011-08-14 07:32:08 --> URI Class Initialized
DEBUG - 2011-08-14 07:32:08 --> Router Class Initialized
ERROR - 2011-08-14 07:32:08 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-08-14 08:10:07 --> Config Class Initialized
DEBUG - 2011-08-14 08:10:07 --> Hooks Class Initialized
DEBUG - 2011-08-14 08:10:07 --> Utf8 Class Initialized
DEBUG - 2011-08-14 08:10:07 --> UTF-8 Support Enabled
DEBUG - 2011-08-14 08:10:07 --> URI Class Initialized
DEBUG - 2011-08-14 08:10:07 --> Router Class Initialized
DEBUG - 2011-08-14 08:10:07 --> Output Class Initialized
DEBUG - 2011-08-14 08:10:07 --> Input Class Initialized
DEBUG - 2011-08-14 08:10:07 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-14 08:10:07 --> Language Class Initialized
DEBUG - 2011-08-14 08:10:07 --> Loader Class Initialized
DEBUG - 2011-08-14 08:10:07 --> Controller Class Initialized
ERROR - 2011-08-14 08:10:07 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-08-14 08:10:07 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-08-14 08:10:07 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-08-14 08:10:07 --> Model Class Initialized
DEBUG - 2011-08-14 08:10:07 --> Model Class Initialized
DEBUG - 2011-08-14 08:10:07 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-14 08:10:07 --> Database Driver Class Initialized
DEBUG - 2011-08-14 08:10:07 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-08-14 08:10:07 --> Helper loaded: url_helper
DEBUG - 2011-08-14 08:10:07 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-14 08:10:07 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-14 08:10:07 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-14 08:10:07 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-14 08:10:07 --> Final output sent to browser
DEBUG - 2011-08-14 08:10:07 --> Total execution time: 0.0300
DEBUG - 2011-08-14 08:10:08 --> Config Class Initialized
DEBUG - 2011-08-14 08:10:08 --> Hooks Class Initialized
DEBUG - 2011-08-14 08:10:08 --> Utf8 Class Initialized
DEBUG - 2011-08-14 08:10:08 --> UTF-8 Support Enabled
DEBUG - 2011-08-14 08:10:08 --> URI Class Initialized
DEBUG - 2011-08-14 08:10:08 --> Router Class Initialized
DEBUG - 2011-08-14 08:10:08 --> Output Class Initialized
DEBUG - 2011-08-14 08:10:08 --> Input Class Initialized
DEBUG - 2011-08-14 08:10:08 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-14 08:10:08 --> Language Class Initialized
DEBUG - 2011-08-14 08:10:08 --> Loader Class Initialized
DEBUG - 2011-08-14 08:10:08 --> Controller Class Initialized
DEBUG - 2011-08-14 08:10:08 --> Model Class Initialized
DEBUG - 2011-08-14 08:10:08 --> Model Class Initialized
DEBUG - 2011-08-14 08:10:08 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-14 08:10:08 --> Database Driver Class Initialized
DEBUG - 2011-08-14 08:10:08 --> Final output sent to browser
DEBUG - 2011-08-14 08:10:08 --> Total execution time: 0.4931
DEBUG - 2011-08-14 08:10:10 --> Config Class Initialized
DEBUG - 2011-08-14 08:10:10 --> Hooks Class Initialized
DEBUG - 2011-08-14 08:10:10 --> Utf8 Class Initialized
DEBUG - 2011-08-14 08:10:10 --> UTF-8 Support Enabled
DEBUG - 2011-08-14 08:10:10 --> URI Class Initialized
DEBUG - 2011-08-14 08:10:10 --> Router Class Initialized
ERROR - 2011-08-14 08:10:10 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-08-14 08:37:26 --> Config Class Initialized
DEBUG - 2011-08-14 08:37:26 --> Hooks Class Initialized
DEBUG - 2011-08-14 08:37:26 --> Utf8 Class Initialized
DEBUG - 2011-08-14 08:37:26 --> UTF-8 Support Enabled
DEBUG - 2011-08-14 08:37:26 --> URI Class Initialized
DEBUG - 2011-08-14 08:37:26 --> Router Class Initialized
DEBUG - 2011-08-14 08:37:26 --> Output Class Initialized
DEBUG - 2011-08-14 08:37:26 --> Input Class Initialized
DEBUG - 2011-08-14 08:37:26 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-14 08:37:26 --> Language Class Initialized
DEBUG - 2011-08-14 08:37:26 --> Loader Class Initialized
DEBUG - 2011-08-14 08:37:26 --> Controller Class Initialized
DEBUG - 2011-08-14 08:37:26 --> Model Class Initialized
DEBUG - 2011-08-14 08:37:26 --> Model Class Initialized
DEBUG - 2011-08-14 08:37:26 --> Model Class Initialized
DEBUG - 2011-08-14 08:37:26 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-14 08:37:26 --> Database Driver Class Initialized
DEBUG - 2011-08-14 08:37:27 --> File loaded: application/views/table/main.php
DEBUG - 2011-08-14 08:37:27 --> Helper loaded: url_helper
DEBUG - 2011-08-14 08:37:27 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-14 08:37:27 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-14 08:37:27 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-14 08:37:27 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-14 08:37:27 --> Final output sent to browser
DEBUG - 2011-08-14 08:37:27 --> Total execution time: 1.6394
DEBUG - 2011-08-14 08:37:30 --> Config Class Initialized
DEBUG - 2011-08-14 08:37:30 --> Hooks Class Initialized
DEBUG - 2011-08-14 08:37:30 --> Utf8 Class Initialized
DEBUG - 2011-08-14 08:37:30 --> UTF-8 Support Enabled
DEBUG - 2011-08-14 08:37:30 --> URI Class Initialized
DEBUG - 2011-08-14 08:37:30 --> Router Class Initialized
ERROR - 2011-08-14 08:37:30 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-08-14 08:37:30 --> Config Class Initialized
DEBUG - 2011-08-14 08:37:30 --> Hooks Class Initialized
DEBUG - 2011-08-14 08:37:30 --> Utf8 Class Initialized
DEBUG - 2011-08-14 08:37:30 --> UTF-8 Support Enabled
DEBUG - 2011-08-14 08:37:30 --> URI Class Initialized
DEBUG - 2011-08-14 08:37:30 --> Router Class Initialized
ERROR - 2011-08-14 08:37:30 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-08-14 08:37:34 --> Config Class Initialized
DEBUG - 2011-08-14 08:37:34 --> Hooks Class Initialized
DEBUG - 2011-08-14 08:37:34 --> Utf8 Class Initialized
DEBUG - 2011-08-14 08:37:34 --> UTF-8 Support Enabled
DEBUG - 2011-08-14 08:37:34 --> URI Class Initialized
DEBUG - 2011-08-14 08:37:34 --> Router Class Initialized
DEBUG - 2011-08-14 08:37:34 --> Output Class Initialized
DEBUG - 2011-08-14 08:37:34 --> Input Class Initialized
DEBUG - 2011-08-14 08:37:34 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-14 08:37:34 --> Language Class Initialized
DEBUG - 2011-08-14 08:37:34 --> Loader Class Initialized
DEBUG - 2011-08-14 08:37:34 --> Controller Class Initialized
ERROR - 2011-08-14 08:37:34 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-08-14 08:37:34 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-08-14 08:37:34 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-08-14 08:37:34 --> Model Class Initialized
DEBUG - 2011-08-14 08:37:34 --> Model Class Initialized
DEBUG - 2011-08-14 08:37:34 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-14 08:37:34 --> Database Driver Class Initialized
DEBUG - 2011-08-14 08:37:34 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-08-14 08:37:34 --> Helper loaded: url_helper
DEBUG - 2011-08-14 08:37:34 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-14 08:37:34 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-14 08:37:34 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-14 08:37:34 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-14 08:37:34 --> Final output sent to browser
DEBUG - 2011-08-14 08:37:34 --> Total execution time: 0.0271
DEBUG - 2011-08-14 08:37:35 --> Config Class Initialized
DEBUG - 2011-08-14 08:37:35 --> Hooks Class Initialized
DEBUG - 2011-08-14 08:37:35 --> Utf8 Class Initialized
DEBUG - 2011-08-14 08:37:35 --> UTF-8 Support Enabled
DEBUG - 2011-08-14 08:37:35 --> URI Class Initialized
DEBUG - 2011-08-14 08:37:35 --> Router Class Initialized
DEBUG - 2011-08-14 08:37:35 --> Output Class Initialized
DEBUG - 2011-08-14 08:37:35 --> Input Class Initialized
DEBUG - 2011-08-14 08:37:35 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-14 08:37:35 --> Language Class Initialized
DEBUG - 2011-08-14 08:37:35 --> Loader Class Initialized
DEBUG - 2011-08-14 08:37:35 --> Controller Class Initialized
DEBUG - 2011-08-14 08:37:35 --> Model Class Initialized
DEBUG - 2011-08-14 08:37:35 --> Model Class Initialized
DEBUG - 2011-08-14 08:37:35 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-14 08:37:35 --> Database Driver Class Initialized
DEBUG - 2011-08-14 08:37:36 --> Final output sent to browser
DEBUG - 2011-08-14 08:37:36 --> Total execution time: 0.6004
DEBUG - 2011-08-14 08:38:34 --> Config Class Initialized
DEBUG - 2011-08-14 08:38:34 --> Hooks Class Initialized
DEBUG - 2011-08-14 08:38:34 --> Utf8 Class Initialized
DEBUG - 2011-08-14 08:38:34 --> UTF-8 Support Enabled
DEBUG - 2011-08-14 08:38:34 --> URI Class Initialized
DEBUG - 2011-08-14 08:38:34 --> Router Class Initialized
DEBUG - 2011-08-14 08:38:34 --> Output Class Initialized
DEBUG - 2011-08-14 08:38:34 --> Input Class Initialized
DEBUG - 2011-08-14 08:38:34 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-14 08:38:34 --> Language Class Initialized
DEBUG - 2011-08-14 08:38:34 --> Loader Class Initialized
DEBUG - 2011-08-14 08:38:34 --> Controller Class Initialized
ERROR - 2011-08-14 08:38:34 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-08-14 08:38:34 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-08-14 08:38:34 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-08-14 08:38:34 --> Model Class Initialized
DEBUG - 2011-08-14 08:38:34 --> Model Class Initialized
DEBUG - 2011-08-14 08:38:34 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-14 08:38:34 --> Database Driver Class Initialized
DEBUG - 2011-08-14 08:38:34 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-08-14 08:38:34 --> Helper loaded: url_helper
DEBUG - 2011-08-14 08:38:34 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-14 08:38:34 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-14 08:38:34 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-14 08:38:34 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-14 08:38:34 --> Final output sent to browser
DEBUG - 2011-08-14 08:38:34 --> Total execution time: 0.0341
DEBUG - 2011-08-14 08:38:35 --> Config Class Initialized
DEBUG - 2011-08-14 08:38:35 --> Hooks Class Initialized
DEBUG - 2011-08-14 08:38:35 --> Utf8 Class Initialized
DEBUG - 2011-08-14 08:38:35 --> UTF-8 Support Enabled
DEBUG - 2011-08-14 08:38:35 --> URI Class Initialized
DEBUG - 2011-08-14 08:38:35 --> Router Class Initialized
DEBUG - 2011-08-14 08:38:35 --> Output Class Initialized
DEBUG - 2011-08-14 08:38:35 --> Input Class Initialized
DEBUG - 2011-08-14 08:38:35 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-14 08:38:35 --> Language Class Initialized
DEBUG - 2011-08-14 08:38:35 --> Loader Class Initialized
DEBUG - 2011-08-14 08:38:35 --> Controller Class Initialized
DEBUG - 2011-08-14 08:38:35 --> Model Class Initialized
DEBUG - 2011-08-14 08:38:35 --> Model Class Initialized
DEBUG - 2011-08-14 08:38:35 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-14 08:38:35 --> Database Driver Class Initialized
DEBUG - 2011-08-14 08:38:35 --> Final output sent to browser
DEBUG - 2011-08-14 08:38:35 --> Total execution time: 0.5531
DEBUG - 2011-08-14 08:38:44 --> Config Class Initialized
DEBUG - 2011-08-14 08:38:44 --> Hooks Class Initialized
DEBUG - 2011-08-14 08:38:44 --> Utf8 Class Initialized
DEBUG - 2011-08-14 08:38:44 --> UTF-8 Support Enabled
DEBUG - 2011-08-14 08:38:44 --> URI Class Initialized
DEBUG - 2011-08-14 08:38:44 --> Router Class Initialized
DEBUG - 2011-08-14 08:38:44 --> Output Class Initialized
DEBUG - 2011-08-14 08:38:44 --> Input Class Initialized
DEBUG - 2011-08-14 08:38:44 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-14 08:38:44 --> Language Class Initialized
DEBUG - 2011-08-14 08:38:44 --> Loader Class Initialized
DEBUG - 2011-08-14 08:38:44 --> Controller Class Initialized
ERROR - 2011-08-14 08:38:44 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-08-14 08:38:44 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-08-14 08:38:44 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-08-14 08:38:44 --> Model Class Initialized
DEBUG - 2011-08-14 08:38:44 --> Model Class Initialized
DEBUG - 2011-08-14 08:38:44 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-14 08:38:44 --> Database Driver Class Initialized
DEBUG - 2011-08-14 08:38:44 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-08-14 08:38:44 --> Helper loaded: url_helper
DEBUG - 2011-08-14 08:38:44 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-14 08:38:44 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-14 08:38:44 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-14 08:38:44 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-14 08:38:44 --> Final output sent to browser
DEBUG - 2011-08-14 08:38:44 --> Total execution time: 0.0276
DEBUG - 2011-08-14 08:38:44 --> Config Class Initialized
DEBUG - 2011-08-14 08:38:44 --> Hooks Class Initialized
DEBUG - 2011-08-14 08:38:44 --> Utf8 Class Initialized
DEBUG - 2011-08-14 08:38:44 --> UTF-8 Support Enabled
DEBUG - 2011-08-14 08:38:44 --> URI Class Initialized
DEBUG - 2011-08-14 08:38:44 --> Router Class Initialized
DEBUG - 2011-08-14 08:38:44 --> Output Class Initialized
DEBUG - 2011-08-14 08:38:44 --> Input Class Initialized
DEBUG - 2011-08-14 08:38:44 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-14 08:38:44 --> Language Class Initialized
DEBUG - 2011-08-14 08:38:44 --> Loader Class Initialized
DEBUG - 2011-08-14 08:38:44 --> Controller Class Initialized
DEBUG - 2011-08-14 08:38:44 --> Model Class Initialized
DEBUG - 2011-08-14 08:38:44 --> Model Class Initialized
DEBUG - 2011-08-14 08:38:44 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-14 08:38:44 --> Database Driver Class Initialized
DEBUG - 2011-08-14 08:38:44 --> Final output sent to browser
DEBUG - 2011-08-14 08:38:44 --> Total execution time: 0.7242
DEBUG - 2011-08-14 08:39:06 --> Config Class Initialized
DEBUG - 2011-08-14 08:39:06 --> Hooks Class Initialized
DEBUG - 2011-08-14 08:39:06 --> Utf8 Class Initialized
DEBUG - 2011-08-14 08:39:06 --> UTF-8 Support Enabled
DEBUG - 2011-08-14 08:39:06 --> URI Class Initialized
DEBUG - 2011-08-14 08:39:06 --> Router Class Initialized
DEBUG - 2011-08-14 08:39:06 --> Output Class Initialized
DEBUG - 2011-08-14 08:39:06 --> Input Class Initialized
DEBUG - 2011-08-14 08:39:06 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-14 08:39:06 --> Language Class Initialized
DEBUG - 2011-08-14 08:39:06 --> Loader Class Initialized
DEBUG - 2011-08-14 08:39:06 --> Controller Class Initialized
ERROR - 2011-08-14 08:39:06 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-08-14 08:39:06 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-08-14 08:39:06 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-08-14 08:39:06 --> Model Class Initialized
DEBUG - 2011-08-14 08:39:06 --> Model Class Initialized
DEBUG - 2011-08-14 08:39:06 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-14 08:39:06 --> Database Driver Class Initialized
DEBUG - 2011-08-14 08:39:06 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-08-14 08:39:06 --> Helper loaded: url_helper
DEBUG - 2011-08-14 08:39:06 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-14 08:39:06 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-14 08:39:06 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-14 08:39:06 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-14 08:39:06 --> Final output sent to browser
DEBUG - 2011-08-14 08:39:06 --> Total execution time: 0.0269
DEBUG - 2011-08-14 08:39:06 --> Config Class Initialized
DEBUG - 2011-08-14 08:39:06 --> Hooks Class Initialized
DEBUG - 2011-08-14 08:39:06 --> Utf8 Class Initialized
DEBUG - 2011-08-14 08:39:06 --> UTF-8 Support Enabled
DEBUG - 2011-08-14 08:39:06 --> URI Class Initialized
DEBUG - 2011-08-14 08:39:06 --> Router Class Initialized
DEBUG - 2011-08-14 08:39:06 --> Output Class Initialized
DEBUG - 2011-08-14 08:39:06 --> Input Class Initialized
DEBUG - 2011-08-14 08:39:06 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-14 08:39:06 --> Language Class Initialized
DEBUG - 2011-08-14 08:39:06 --> Loader Class Initialized
DEBUG - 2011-08-14 08:39:06 --> Controller Class Initialized
DEBUG - 2011-08-14 08:39:06 --> Model Class Initialized
DEBUG - 2011-08-14 08:39:06 --> Model Class Initialized
DEBUG - 2011-08-14 08:39:06 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-14 08:39:06 --> Database Driver Class Initialized
DEBUG - 2011-08-14 08:39:07 --> Final output sent to browser
DEBUG - 2011-08-14 08:39:07 --> Total execution time: 0.5773
DEBUG - 2011-08-14 08:39:32 --> Config Class Initialized
DEBUG - 2011-08-14 08:39:32 --> Hooks Class Initialized
DEBUG - 2011-08-14 08:39:32 --> Utf8 Class Initialized
DEBUG - 2011-08-14 08:39:32 --> UTF-8 Support Enabled
DEBUG - 2011-08-14 08:39:32 --> URI Class Initialized
DEBUG - 2011-08-14 08:39:32 --> Router Class Initialized
DEBUG - 2011-08-14 08:39:32 --> Output Class Initialized
DEBUG - 2011-08-14 08:39:32 --> Input Class Initialized
DEBUG - 2011-08-14 08:39:32 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-14 08:39:32 --> Language Class Initialized
DEBUG - 2011-08-14 08:39:32 --> Loader Class Initialized
DEBUG - 2011-08-14 08:39:32 --> Controller Class Initialized
ERROR - 2011-08-14 08:39:32 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-08-14 08:39:32 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-08-14 08:39:32 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-08-14 08:39:32 --> Model Class Initialized
DEBUG - 2011-08-14 08:39:32 --> Model Class Initialized
DEBUG - 2011-08-14 08:39:32 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-14 08:39:32 --> Database Driver Class Initialized
DEBUG - 2011-08-14 08:39:32 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-08-14 08:39:32 --> Helper loaded: url_helper
DEBUG - 2011-08-14 08:39:32 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-14 08:39:32 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-14 08:39:32 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-14 08:39:32 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-14 08:39:32 --> Final output sent to browser
DEBUG - 2011-08-14 08:39:32 --> Total execution time: 0.0287
DEBUG - 2011-08-14 08:39:32 --> Config Class Initialized
DEBUG - 2011-08-14 08:39:32 --> Hooks Class Initialized
DEBUG - 2011-08-14 08:39:32 --> Utf8 Class Initialized
DEBUG - 2011-08-14 08:39:32 --> UTF-8 Support Enabled
DEBUG - 2011-08-14 08:39:32 --> URI Class Initialized
DEBUG - 2011-08-14 08:39:32 --> Router Class Initialized
DEBUG - 2011-08-14 08:39:32 --> Output Class Initialized
DEBUG - 2011-08-14 08:39:32 --> Input Class Initialized
DEBUG - 2011-08-14 08:39:32 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-14 08:39:32 --> Language Class Initialized
DEBUG - 2011-08-14 08:39:32 --> Loader Class Initialized
DEBUG - 2011-08-14 08:39:32 --> Controller Class Initialized
DEBUG - 2011-08-14 08:39:32 --> Model Class Initialized
DEBUG - 2011-08-14 08:39:32 --> Model Class Initialized
DEBUG - 2011-08-14 08:39:32 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-14 08:39:32 --> Database Driver Class Initialized
DEBUG - 2011-08-14 08:39:33 --> Final output sent to browser
DEBUG - 2011-08-14 08:39:33 --> Total execution time: 0.5833
DEBUG - 2011-08-14 08:39:44 --> Config Class Initialized
DEBUG - 2011-08-14 08:39:44 --> Hooks Class Initialized
DEBUG - 2011-08-14 08:39:44 --> Utf8 Class Initialized
DEBUG - 2011-08-14 08:39:44 --> UTF-8 Support Enabled
DEBUG - 2011-08-14 08:39:44 --> URI Class Initialized
DEBUG - 2011-08-14 08:39:44 --> Router Class Initialized
DEBUG - 2011-08-14 08:39:44 --> Output Class Initialized
DEBUG - 2011-08-14 08:39:44 --> Input Class Initialized
DEBUG - 2011-08-14 08:39:44 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-14 08:39:44 --> Language Class Initialized
DEBUG - 2011-08-14 08:39:44 --> Loader Class Initialized
DEBUG - 2011-08-14 08:39:44 --> Controller Class Initialized
ERROR - 2011-08-14 08:39:44 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-08-14 08:39:44 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-08-14 08:39:44 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-08-14 08:39:44 --> Model Class Initialized
DEBUG - 2011-08-14 08:39:44 --> Model Class Initialized
DEBUG - 2011-08-14 08:39:44 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-14 08:39:44 --> Database Driver Class Initialized
DEBUG - 2011-08-14 08:39:44 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-08-14 08:39:44 --> Helper loaded: url_helper
DEBUG - 2011-08-14 08:39:44 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-14 08:39:44 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-14 08:39:44 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-14 08:39:44 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-14 08:39:44 --> Final output sent to browser
DEBUG - 2011-08-14 08:39:44 --> Total execution time: 0.0277
DEBUG - 2011-08-14 08:39:44 --> Config Class Initialized
DEBUG - 2011-08-14 08:39:44 --> Hooks Class Initialized
DEBUG - 2011-08-14 08:39:44 --> Utf8 Class Initialized
DEBUG - 2011-08-14 08:39:44 --> UTF-8 Support Enabled
DEBUG - 2011-08-14 08:39:44 --> URI Class Initialized
DEBUG - 2011-08-14 08:39:44 --> Router Class Initialized
DEBUG - 2011-08-14 08:39:44 --> Output Class Initialized
DEBUG - 2011-08-14 08:39:44 --> Input Class Initialized
DEBUG - 2011-08-14 08:39:44 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-14 08:39:44 --> Language Class Initialized
DEBUG - 2011-08-14 08:39:44 --> Loader Class Initialized
DEBUG - 2011-08-14 08:39:44 --> Controller Class Initialized
DEBUG - 2011-08-14 08:39:44 --> Model Class Initialized
DEBUG - 2011-08-14 08:39:44 --> Model Class Initialized
DEBUG - 2011-08-14 08:39:44 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-14 08:39:44 --> Database Driver Class Initialized
DEBUG - 2011-08-14 08:39:45 --> Final output sent to browser
DEBUG - 2011-08-14 08:39:45 --> Total execution time: 0.5444
DEBUG - 2011-08-14 09:11:10 --> Config Class Initialized
DEBUG - 2011-08-14 09:11:10 --> Hooks Class Initialized
DEBUG - 2011-08-14 09:11:10 --> Utf8 Class Initialized
DEBUG - 2011-08-14 09:11:10 --> UTF-8 Support Enabled
DEBUG - 2011-08-14 09:11:10 --> URI Class Initialized
DEBUG - 2011-08-14 09:11:10 --> Router Class Initialized
DEBUG - 2011-08-14 09:11:10 --> Output Class Initialized
DEBUG - 2011-08-14 09:11:10 --> Input Class Initialized
DEBUG - 2011-08-14 09:11:10 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-14 09:11:10 --> Language Class Initialized
DEBUG - 2011-08-14 09:11:10 --> Loader Class Initialized
DEBUG - 2011-08-14 09:11:10 --> Controller Class Initialized
ERROR - 2011-08-14 09:11:10 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-08-14 09:11:10 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-08-14 09:11:10 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-08-14 09:11:10 --> Model Class Initialized
DEBUG - 2011-08-14 09:11:10 --> Model Class Initialized
DEBUG - 2011-08-14 09:11:10 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-14 09:11:10 --> Database Driver Class Initialized
DEBUG - 2011-08-14 09:11:10 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-08-14 09:11:10 --> Helper loaded: url_helper
DEBUG - 2011-08-14 09:11:10 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-14 09:11:10 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-14 09:11:10 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-14 09:11:10 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-14 09:11:10 --> Final output sent to browser
DEBUG - 2011-08-14 09:11:10 --> Total execution time: 0.0375
DEBUG - 2011-08-14 09:11:11 --> Config Class Initialized
DEBUG - 2011-08-14 09:11:11 --> Hooks Class Initialized
DEBUG - 2011-08-14 09:11:11 --> Utf8 Class Initialized
DEBUG - 2011-08-14 09:11:11 --> UTF-8 Support Enabled
DEBUG - 2011-08-14 09:11:11 --> URI Class Initialized
DEBUG - 2011-08-14 09:11:11 --> Router Class Initialized
DEBUG - 2011-08-14 09:11:11 --> Output Class Initialized
DEBUG - 2011-08-14 09:11:11 --> Input Class Initialized
DEBUG - 2011-08-14 09:11:11 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-14 09:11:11 --> Language Class Initialized
DEBUG - 2011-08-14 09:11:11 --> Loader Class Initialized
DEBUG - 2011-08-14 09:11:11 --> Controller Class Initialized
DEBUG - 2011-08-14 09:11:11 --> Model Class Initialized
DEBUG - 2011-08-14 09:11:11 --> Model Class Initialized
DEBUG - 2011-08-14 09:11:11 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-14 09:11:11 --> Database Driver Class Initialized
DEBUG - 2011-08-14 09:11:11 --> Final output sent to browser
DEBUG - 2011-08-14 09:11:11 --> Total execution time: 0.5580
DEBUG - 2011-08-14 09:11:15 --> Config Class Initialized
DEBUG - 2011-08-14 09:11:15 --> Hooks Class Initialized
DEBUG - 2011-08-14 09:11:15 --> Utf8 Class Initialized
DEBUG - 2011-08-14 09:11:15 --> UTF-8 Support Enabled
DEBUG - 2011-08-14 09:11:15 --> URI Class Initialized
DEBUG - 2011-08-14 09:11:15 --> Router Class Initialized
ERROR - 2011-08-14 09:11:15 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-08-14 10:15:45 --> Config Class Initialized
DEBUG - 2011-08-14 10:15:45 --> Hooks Class Initialized
DEBUG - 2011-08-14 10:15:45 --> Utf8 Class Initialized
DEBUG - 2011-08-14 10:15:45 --> UTF-8 Support Enabled
DEBUG - 2011-08-14 10:15:45 --> URI Class Initialized
DEBUG - 2011-08-14 10:15:45 --> Router Class Initialized
DEBUG - 2011-08-14 10:15:45 --> Output Class Initialized
DEBUG - 2011-08-14 10:15:45 --> Input Class Initialized
DEBUG - 2011-08-14 10:15:45 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-14 10:15:45 --> Language Class Initialized
DEBUG - 2011-08-14 10:15:45 --> Loader Class Initialized
DEBUG - 2011-08-14 10:15:45 --> Controller Class Initialized
DEBUG - 2011-08-14 10:15:45 --> Model Class Initialized
DEBUG - 2011-08-14 10:15:45 --> Model Class Initialized
DEBUG - 2011-08-14 10:15:45 --> Model Class Initialized
DEBUG - 2011-08-14 10:15:45 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-14 10:15:45 --> Database Driver Class Initialized
DEBUG - 2011-08-14 10:15:46 --> File loaded: application/views/table/main.php
DEBUG - 2011-08-14 10:15:46 --> Helper loaded: url_helper
DEBUG - 2011-08-14 10:15:46 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-14 10:15:46 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-14 10:15:46 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-14 10:15:46 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-14 10:15:46 --> Final output sent to browser
DEBUG - 2011-08-14 10:15:46 --> Total execution time: 0.8817
DEBUG - 2011-08-14 10:15:46 --> Config Class Initialized
DEBUG - 2011-08-14 10:15:46 --> Hooks Class Initialized
DEBUG - 2011-08-14 10:15:46 --> Utf8 Class Initialized
DEBUG - 2011-08-14 10:15:46 --> UTF-8 Support Enabled
DEBUG - 2011-08-14 10:15:46 --> URI Class Initialized
DEBUG - 2011-08-14 10:15:46 --> Router Class Initialized
DEBUG - 2011-08-14 10:15:46 --> Output Class Initialized
DEBUG - 2011-08-14 10:15:46 --> Input Class Initialized
DEBUG - 2011-08-14 10:15:46 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-14 10:15:46 --> Language Class Initialized
DEBUG - 2011-08-14 10:15:46 --> Loader Class Initialized
DEBUG - 2011-08-14 10:15:46 --> Controller Class Initialized
ERROR - 2011-08-14 10:15:46 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-08-14 10:15:46 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-08-14 10:15:46 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-08-14 10:15:46 --> Model Class Initialized
DEBUG - 2011-08-14 10:15:46 --> Model Class Initialized
DEBUG - 2011-08-14 10:15:46 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-14 10:15:46 --> Database Driver Class Initialized
DEBUG - 2011-08-14 10:15:46 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-08-14 10:15:46 --> Helper loaded: url_helper
DEBUG - 2011-08-14 10:15:46 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-14 10:15:46 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-14 10:15:46 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-14 10:15:46 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-14 10:15:46 --> Final output sent to browser
DEBUG - 2011-08-14 10:15:46 --> Total execution time: 0.0299
DEBUG - 2011-08-14 10:15:47 --> Config Class Initialized
DEBUG - 2011-08-14 10:15:47 --> Hooks Class Initialized
DEBUG - 2011-08-14 10:15:47 --> Utf8 Class Initialized
DEBUG - 2011-08-14 10:15:47 --> UTF-8 Support Enabled
DEBUG - 2011-08-14 10:15:47 --> URI Class Initialized
DEBUG - 2011-08-14 10:15:47 --> Router Class Initialized
ERROR - 2011-08-14 10:15:47 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-08-14 10:15:47 --> Config Class Initialized
DEBUG - 2011-08-14 10:15:47 --> Hooks Class Initialized
DEBUG - 2011-08-14 10:15:47 --> Utf8 Class Initialized
DEBUG - 2011-08-14 10:15:47 --> UTF-8 Support Enabled
DEBUG - 2011-08-14 10:15:47 --> URI Class Initialized
DEBUG - 2011-08-14 10:15:47 --> Router Class Initialized
DEBUG - 2011-08-14 10:15:47 --> Output Class Initialized
DEBUG - 2011-08-14 10:15:47 --> Input Class Initialized
DEBUG - 2011-08-14 10:15:47 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-14 10:15:47 --> Language Class Initialized
DEBUG - 2011-08-14 10:15:47 --> Loader Class Initialized
DEBUG - 2011-08-14 10:15:47 --> Controller Class Initialized
DEBUG - 2011-08-14 10:15:47 --> Model Class Initialized
DEBUG - 2011-08-14 10:15:47 --> Model Class Initialized
DEBUG - 2011-08-14 10:15:47 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-14 10:15:47 --> Database Driver Class Initialized
DEBUG - 2011-08-14 10:15:47 --> Config Class Initialized
DEBUG - 2011-08-14 10:15:47 --> Hooks Class Initialized
DEBUG - 2011-08-14 10:15:47 --> Utf8 Class Initialized
DEBUG - 2011-08-14 10:15:47 --> UTF-8 Support Enabled
DEBUG - 2011-08-14 10:15:47 --> URI Class Initialized
DEBUG - 2011-08-14 10:15:47 --> Router Class Initialized
ERROR - 2011-08-14 10:15:47 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-08-14 10:15:48 --> Final output sent to browser
DEBUG - 2011-08-14 10:15:48 --> Total execution time: 0.7914
DEBUG - 2011-08-14 10:15:50 --> Config Class Initialized
DEBUG - 2011-08-14 10:15:50 --> Hooks Class Initialized
DEBUG - 2011-08-14 10:15:50 --> Utf8 Class Initialized
DEBUG - 2011-08-14 10:15:50 --> UTF-8 Support Enabled
DEBUG - 2011-08-14 10:15:50 --> URI Class Initialized
DEBUG - 2011-08-14 10:15:50 --> Router Class Initialized
ERROR - 2011-08-14 10:15:50 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-08-14 10:22:04 --> Config Class Initialized
DEBUG - 2011-08-14 10:22:04 --> Hooks Class Initialized
DEBUG - 2011-08-14 10:22:04 --> Utf8 Class Initialized
DEBUG - 2011-08-14 10:22:04 --> UTF-8 Support Enabled
DEBUG - 2011-08-14 10:22:04 --> URI Class Initialized
DEBUG - 2011-08-14 10:22:04 --> Router Class Initialized
DEBUG - 2011-08-14 10:22:04 --> No URI present. Default controller set.
DEBUG - 2011-08-14 10:22:04 --> Output Class Initialized
DEBUG - 2011-08-14 10:22:04 --> Input Class Initialized
DEBUG - 2011-08-14 10:22:04 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-14 10:22:04 --> Language Class Initialized
DEBUG - 2011-08-14 10:22:04 --> Loader Class Initialized
DEBUG - 2011-08-14 10:22:04 --> Controller Class Initialized
DEBUG - 2011-08-14 10:22:04 --> File loaded: application/views/splash/main.php
DEBUG - 2011-08-14 10:22:04 --> Helper loaded: url_helper
DEBUG - 2011-08-14 10:22:04 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-14 10:22:04 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-14 10:22:04 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-14 10:22:04 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-14 10:22:04 --> Final output sent to browser
DEBUG - 2011-08-14 10:22:04 --> Total execution time: 0.0634
DEBUG - 2011-08-14 10:32:59 --> Config Class Initialized
DEBUG - 2011-08-14 10:32:59 --> Hooks Class Initialized
DEBUG - 2011-08-14 10:32:59 --> Utf8 Class Initialized
DEBUG - 2011-08-14 10:32:59 --> UTF-8 Support Enabled
DEBUG - 2011-08-14 10:32:59 --> URI Class Initialized
DEBUG - 2011-08-14 10:32:59 --> Router Class Initialized
DEBUG - 2011-08-14 10:32:59 --> Output Class Initialized
DEBUG - 2011-08-14 10:32:59 --> Input Class Initialized
DEBUG - 2011-08-14 10:32:59 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-14 10:32:59 --> Language Class Initialized
DEBUG - 2011-08-14 10:32:59 --> Loader Class Initialized
DEBUG - 2011-08-14 10:32:59 --> Controller Class Initialized
ERROR - 2011-08-14 10:32:59 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-08-14 10:32:59 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-08-14 10:32:59 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-08-14 10:32:59 --> Model Class Initialized
DEBUG - 2011-08-14 10:32:59 --> Model Class Initialized
DEBUG - 2011-08-14 10:32:59 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-14 10:32:59 --> Database Driver Class Initialized
DEBUG - 2011-08-14 10:32:59 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-08-14 10:32:59 --> Helper loaded: url_helper
DEBUG - 2011-08-14 10:32:59 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-14 10:32:59 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-14 10:32:59 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-14 10:32:59 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-14 10:32:59 --> Final output sent to browser
DEBUG - 2011-08-14 10:32:59 --> Total execution time: 0.0291
DEBUG - 2011-08-14 10:42:00 --> Config Class Initialized
DEBUG - 2011-08-14 10:42:00 --> Hooks Class Initialized
DEBUG - 2011-08-14 10:42:00 --> Utf8 Class Initialized
DEBUG - 2011-08-14 10:42:00 --> UTF-8 Support Enabled
DEBUG - 2011-08-14 10:42:00 --> URI Class Initialized
DEBUG - 2011-08-14 10:42:00 --> Router Class Initialized
DEBUG - 2011-08-14 10:42:00 --> Output Class Initialized
DEBUG - 2011-08-14 10:42:00 --> Input Class Initialized
DEBUG - 2011-08-14 10:42:00 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-14 10:42:00 --> Language Class Initialized
DEBUG - 2011-08-14 10:42:00 --> Loader Class Initialized
DEBUG - 2011-08-14 10:42:00 --> Controller Class Initialized
ERROR - 2011-08-14 10:42:00 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-08-14 10:42:00 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-08-14 10:42:00 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-08-14 10:42:00 --> Model Class Initialized
DEBUG - 2011-08-14 10:42:00 --> Model Class Initialized
DEBUG - 2011-08-14 10:42:00 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-14 10:42:00 --> Database Driver Class Initialized
DEBUG - 2011-08-14 10:42:00 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-08-14 10:42:00 --> Helper loaded: url_helper
DEBUG - 2011-08-14 10:42:00 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-14 10:42:00 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-14 10:42:00 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-14 10:42:00 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-14 10:42:00 --> Final output sent to browser
DEBUG - 2011-08-14 10:42:00 --> Total execution time: 0.0620
DEBUG - 2011-08-14 10:42:00 --> Config Class Initialized
DEBUG - 2011-08-14 10:42:00 --> Hooks Class Initialized
DEBUG - 2011-08-14 10:42:00 --> Utf8 Class Initialized
DEBUG - 2011-08-14 10:42:00 --> UTF-8 Support Enabled
DEBUG - 2011-08-14 10:42:00 --> URI Class Initialized
DEBUG - 2011-08-14 10:42:00 --> Router Class Initialized
DEBUG - 2011-08-14 10:42:00 --> Output Class Initialized
DEBUG - 2011-08-14 10:42:00 --> Input Class Initialized
DEBUG - 2011-08-14 10:42:00 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-14 10:42:00 --> Language Class Initialized
DEBUG - 2011-08-14 10:42:00 --> Loader Class Initialized
DEBUG - 2011-08-14 10:42:00 --> Controller Class Initialized
DEBUG - 2011-08-14 10:42:00 --> Model Class Initialized
DEBUG - 2011-08-14 10:42:00 --> Model Class Initialized
DEBUG - 2011-08-14 10:42:00 --> Model Class Initialized
DEBUG - 2011-08-14 10:42:00 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-14 10:42:00 --> Database Driver Class Initialized
DEBUG - 2011-08-14 10:42:00 --> File loaded: application/views/table/main.php
DEBUG - 2011-08-14 10:42:00 --> Helper loaded: url_helper
DEBUG - 2011-08-14 10:42:00 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-14 10:42:00 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-14 10:42:00 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-14 10:42:00 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-14 10:42:00 --> Final output sent to browser
DEBUG - 2011-08-14 10:42:00 --> Total execution time: 0.3527
DEBUG - 2011-08-14 10:50:00 --> Config Class Initialized
DEBUG - 2011-08-14 10:50:00 --> Hooks Class Initialized
DEBUG - 2011-08-14 10:50:00 --> Utf8 Class Initialized
DEBUG - 2011-08-14 10:50:00 --> UTF-8 Support Enabled
DEBUG - 2011-08-14 10:50:00 --> URI Class Initialized
DEBUG - 2011-08-14 10:50:00 --> Router Class Initialized
DEBUG - 2011-08-14 10:50:00 --> Output Class Initialized
DEBUG - 2011-08-14 10:50:00 --> Input Class Initialized
DEBUG - 2011-08-14 10:50:00 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-14 10:50:00 --> Language Class Initialized
DEBUG - 2011-08-14 10:50:00 --> Loader Class Initialized
DEBUG - 2011-08-14 10:50:00 --> Controller Class Initialized
DEBUG - 2011-08-14 10:50:00 --> Model Class Initialized
DEBUG - 2011-08-14 10:50:00 --> Model Class Initialized
DEBUG - 2011-08-14 10:50:00 --> Model Class Initialized
DEBUG - 2011-08-14 10:50:00 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-14 10:50:00 --> Database Driver Class Initialized
DEBUG - 2011-08-14 10:50:00 --> File loaded: application/views/table/main.php
DEBUG - 2011-08-14 10:50:00 --> Helper loaded: url_helper
DEBUG - 2011-08-14 10:50:00 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-14 10:50:00 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-14 10:50:00 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-14 10:50:00 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-14 10:50:00 --> Final output sent to browser
DEBUG - 2011-08-14 10:50:00 --> Total execution time: 0.0502
DEBUG - 2011-08-14 11:14:21 --> Config Class Initialized
DEBUG - 2011-08-14 11:14:21 --> Hooks Class Initialized
DEBUG - 2011-08-14 11:14:21 --> Utf8 Class Initialized
DEBUG - 2011-08-14 11:14:21 --> UTF-8 Support Enabled
DEBUG - 2011-08-14 11:14:21 --> URI Class Initialized
DEBUG - 2011-08-14 11:14:21 --> Router Class Initialized
DEBUG - 2011-08-14 11:14:21 --> Output Class Initialized
DEBUG - 2011-08-14 11:14:21 --> Input Class Initialized
DEBUG - 2011-08-14 11:14:21 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-14 11:14:21 --> Language Class Initialized
DEBUG - 2011-08-14 11:14:21 --> Loader Class Initialized
DEBUG - 2011-08-14 11:14:21 --> Controller Class Initialized
DEBUG - 2011-08-14 11:14:21 --> Model Class Initialized
DEBUG - 2011-08-14 11:14:21 --> Model Class Initialized
DEBUG - 2011-08-14 11:14:21 --> Model Class Initialized
DEBUG - 2011-08-14 11:14:21 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-14 11:14:21 --> Database Driver Class Initialized
DEBUG - 2011-08-14 11:14:21 --> File loaded: application/views/table/main.php
DEBUG - 2011-08-14 11:14:21 --> Helper loaded: url_helper
DEBUG - 2011-08-14 11:14:21 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-14 11:14:21 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-14 11:14:21 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-14 11:14:21 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-14 11:14:21 --> Final output sent to browser
DEBUG - 2011-08-14 11:14:21 --> Total execution time: 0.3820
DEBUG - 2011-08-14 11:28:39 --> Config Class Initialized
DEBUG - 2011-08-14 11:28:39 --> Hooks Class Initialized
DEBUG - 2011-08-14 11:28:39 --> Utf8 Class Initialized
DEBUG - 2011-08-14 11:28:39 --> UTF-8 Support Enabled
DEBUG - 2011-08-14 11:28:39 --> URI Class Initialized
DEBUG - 2011-08-14 11:28:39 --> Router Class Initialized
ERROR - 2011-08-14 11:28:39 --> 404 Page Not Found --> robots.txt
DEBUG - 2011-08-14 13:16:28 --> Config Class Initialized
DEBUG - 2011-08-14 13:16:28 --> Hooks Class Initialized
DEBUG - 2011-08-14 13:16:28 --> Utf8 Class Initialized
DEBUG - 2011-08-14 13:16:28 --> UTF-8 Support Enabled
DEBUG - 2011-08-14 13:16:28 --> URI Class Initialized
DEBUG - 2011-08-14 13:16:28 --> Router Class Initialized
DEBUG - 2011-08-14 13:16:28 --> Output Class Initialized
DEBUG - 2011-08-14 13:16:29 --> Input Class Initialized
DEBUG - 2011-08-14 13:16:29 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-14 13:16:29 --> Language Class Initialized
DEBUG - 2011-08-14 13:16:29 --> Loader Class Initialized
DEBUG - 2011-08-14 13:16:29 --> Controller Class Initialized
ERROR - 2011-08-14 13:16:29 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-08-14 13:16:29 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-08-14 13:16:29 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-08-14 13:16:29 --> Model Class Initialized
DEBUG - 2011-08-14 13:16:29 --> Model Class Initialized
DEBUG - 2011-08-14 13:16:29 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-14 13:16:29 --> Database Driver Class Initialized
DEBUG - 2011-08-14 13:16:29 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-08-14 13:16:29 --> Helper loaded: url_helper
DEBUG - 2011-08-14 13:16:29 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-14 13:16:29 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-14 13:16:29 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-14 13:16:29 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-14 13:16:29 --> Final output sent to browser
DEBUG - 2011-08-14 13:16:29 --> Total execution time: 0.1745
DEBUG - 2011-08-14 13:16:29 --> Config Class Initialized
DEBUG - 2011-08-14 13:16:29 --> Hooks Class Initialized
DEBUG - 2011-08-14 13:16:29 --> Utf8 Class Initialized
DEBUG - 2011-08-14 13:16:29 --> UTF-8 Support Enabled
DEBUG - 2011-08-14 13:16:29 --> URI Class Initialized
DEBUG - 2011-08-14 13:16:29 --> Router Class Initialized
DEBUG - 2011-08-14 13:16:29 --> Output Class Initialized
DEBUG - 2011-08-14 13:16:29 --> Input Class Initialized
DEBUG - 2011-08-14 13:16:29 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-14 13:16:29 --> Language Class Initialized
DEBUG - 2011-08-14 13:16:29 --> Loader Class Initialized
DEBUG - 2011-08-14 13:16:29 --> Controller Class Initialized
DEBUG - 2011-08-14 13:16:29 --> Model Class Initialized
DEBUG - 2011-08-14 13:16:30 --> Model Class Initialized
DEBUG - 2011-08-14 13:16:30 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-14 13:16:30 --> Database Driver Class Initialized
DEBUG - 2011-08-14 13:16:31 --> Final output sent to browser
DEBUG - 2011-08-14 13:16:31 --> Total execution time: 1.0808
DEBUG - 2011-08-14 14:08:36 --> Config Class Initialized
DEBUG - 2011-08-14 14:08:36 --> Hooks Class Initialized
DEBUG - 2011-08-14 14:08:36 --> Utf8 Class Initialized
DEBUG - 2011-08-14 14:08:36 --> UTF-8 Support Enabled
DEBUG - 2011-08-14 14:08:36 --> URI Class Initialized
DEBUG - 2011-08-14 14:08:36 --> Router Class Initialized
DEBUG - 2011-08-14 14:08:36 --> Output Class Initialized
DEBUG - 2011-08-14 14:08:36 --> Input Class Initialized
DEBUG - 2011-08-14 14:08:36 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-14 14:08:36 --> Language Class Initialized
DEBUG - 2011-08-14 14:08:36 --> Loader Class Initialized
DEBUG - 2011-08-14 14:08:36 --> Controller Class Initialized
ERROR - 2011-08-14 14:08:36 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-08-14 14:08:36 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-08-14 14:08:36 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-08-14 14:08:36 --> Model Class Initialized
DEBUG - 2011-08-14 14:08:36 --> Model Class Initialized
DEBUG - 2011-08-14 14:08:36 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-14 14:08:36 --> Database Driver Class Initialized
DEBUG - 2011-08-14 14:08:36 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-08-14 14:08:36 --> Helper loaded: url_helper
DEBUG - 2011-08-14 14:08:36 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-14 14:08:36 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-14 14:08:36 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-14 14:08:36 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-14 14:08:36 --> Final output sent to browser
DEBUG - 2011-08-14 14:08:36 --> Total execution time: 0.0603
DEBUG - 2011-08-14 14:08:38 --> Config Class Initialized
DEBUG - 2011-08-14 14:08:38 --> Hooks Class Initialized
DEBUG - 2011-08-14 14:08:38 --> Utf8 Class Initialized
DEBUG - 2011-08-14 14:08:38 --> UTF-8 Support Enabled
DEBUG - 2011-08-14 14:08:38 --> URI Class Initialized
DEBUG - 2011-08-14 14:08:38 --> Router Class Initialized
DEBUG - 2011-08-14 14:08:38 --> Output Class Initialized
DEBUG - 2011-08-14 14:08:38 --> Input Class Initialized
DEBUG - 2011-08-14 14:08:38 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-14 14:08:38 --> Language Class Initialized
DEBUG - 2011-08-14 14:08:38 --> Loader Class Initialized
DEBUG - 2011-08-14 14:08:38 --> Controller Class Initialized
DEBUG - 2011-08-14 14:08:38 --> Model Class Initialized
DEBUG - 2011-08-14 14:08:38 --> Model Class Initialized
DEBUG - 2011-08-14 14:08:38 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-14 14:08:38 --> Database Driver Class Initialized
DEBUG - 2011-08-14 14:08:39 --> Final output sent to browser
DEBUG - 2011-08-14 14:08:39 --> Total execution time: 0.7535
DEBUG - 2011-08-14 14:08:41 --> Config Class Initialized
DEBUG - 2011-08-14 14:08:41 --> Hooks Class Initialized
DEBUG - 2011-08-14 14:08:41 --> Utf8 Class Initialized
DEBUG - 2011-08-14 14:08:41 --> UTF-8 Support Enabled
DEBUG - 2011-08-14 14:08:41 --> URI Class Initialized
DEBUG - 2011-08-14 14:08:41 --> Router Class Initialized
ERROR - 2011-08-14 14:08:41 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-08-14 14:09:17 --> Config Class Initialized
DEBUG - 2011-08-14 14:09:17 --> Hooks Class Initialized
DEBUG - 2011-08-14 14:09:17 --> Utf8 Class Initialized
DEBUG - 2011-08-14 14:09:17 --> UTF-8 Support Enabled
DEBUG - 2011-08-14 14:09:17 --> URI Class Initialized
DEBUG - 2011-08-14 14:09:17 --> Router Class Initialized
DEBUG - 2011-08-14 14:09:17 --> Output Class Initialized
DEBUG - 2011-08-14 14:09:17 --> Input Class Initialized
DEBUG - 2011-08-14 14:09:17 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-14 14:09:17 --> Language Class Initialized
DEBUG - 2011-08-14 14:09:17 --> Loader Class Initialized
DEBUG - 2011-08-14 14:09:17 --> Controller Class Initialized
ERROR - 2011-08-14 14:09:17 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-08-14 14:09:17 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-08-14 14:09:17 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-08-14 14:09:17 --> Model Class Initialized
DEBUG - 2011-08-14 14:09:17 --> Model Class Initialized
DEBUG - 2011-08-14 14:09:17 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-14 14:09:17 --> Database Driver Class Initialized
DEBUG - 2011-08-14 14:09:17 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-08-14 14:09:17 --> Helper loaded: url_helper
DEBUG - 2011-08-14 14:09:17 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-14 14:09:17 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-14 14:09:17 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-14 14:09:17 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-14 14:09:17 --> Final output sent to browser
DEBUG - 2011-08-14 14:09:17 --> Total execution time: 0.0330
DEBUG - 2011-08-14 14:09:18 --> Config Class Initialized
DEBUG - 2011-08-14 14:09:18 --> Hooks Class Initialized
DEBUG - 2011-08-14 14:09:18 --> Utf8 Class Initialized
DEBUG - 2011-08-14 14:09:18 --> UTF-8 Support Enabled
DEBUG - 2011-08-14 14:09:18 --> URI Class Initialized
DEBUG - 2011-08-14 14:09:18 --> Router Class Initialized
DEBUG - 2011-08-14 14:09:18 --> Output Class Initialized
DEBUG - 2011-08-14 14:09:18 --> Input Class Initialized
DEBUG - 2011-08-14 14:09:18 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-14 14:09:18 --> Language Class Initialized
DEBUG - 2011-08-14 14:09:18 --> Loader Class Initialized
DEBUG - 2011-08-14 14:09:18 --> Controller Class Initialized
DEBUG - 2011-08-14 14:09:18 --> Model Class Initialized
DEBUG - 2011-08-14 14:09:18 --> Model Class Initialized
DEBUG - 2011-08-14 14:09:18 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-14 14:09:18 --> Database Driver Class Initialized
DEBUG - 2011-08-14 14:09:18 --> Final output sent to browser
DEBUG - 2011-08-14 14:09:18 --> Total execution time: 0.5598
DEBUG - 2011-08-14 14:09:20 --> Config Class Initialized
DEBUG - 2011-08-14 14:09:20 --> Hooks Class Initialized
DEBUG - 2011-08-14 14:09:20 --> Utf8 Class Initialized
DEBUG - 2011-08-14 14:09:20 --> UTF-8 Support Enabled
DEBUG - 2011-08-14 14:09:20 --> URI Class Initialized
DEBUG - 2011-08-14 14:09:20 --> Router Class Initialized
ERROR - 2011-08-14 14:09:20 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-08-14 14:09:27 --> Config Class Initialized
DEBUG - 2011-08-14 14:09:27 --> Hooks Class Initialized
DEBUG - 2011-08-14 14:09:27 --> Utf8 Class Initialized
DEBUG - 2011-08-14 14:09:27 --> UTF-8 Support Enabled
DEBUG - 2011-08-14 14:09:27 --> URI Class Initialized
DEBUG - 2011-08-14 14:09:27 --> Router Class Initialized
DEBUG - 2011-08-14 14:09:27 --> Output Class Initialized
DEBUG - 2011-08-14 14:09:27 --> Input Class Initialized
DEBUG - 2011-08-14 14:09:27 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-14 14:09:27 --> Language Class Initialized
DEBUG - 2011-08-14 14:09:27 --> Loader Class Initialized
DEBUG - 2011-08-14 14:09:27 --> Controller Class Initialized
ERROR - 2011-08-14 14:09:27 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-08-14 14:09:27 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-08-14 14:09:27 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-08-14 14:09:27 --> Model Class Initialized
DEBUG - 2011-08-14 14:09:27 --> Model Class Initialized
DEBUG - 2011-08-14 14:09:27 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-14 14:09:27 --> Database Driver Class Initialized
DEBUG - 2011-08-14 14:09:27 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-08-14 14:09:27 --> Helper loaded: url_helper
DEBUG - 2011-08-14 14:09:27 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-14 14:09:27 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-14 14:09:27 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-14 14:09:27 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-14 14:09:27 --> Final output sent to browser
DEBUG - 2011-08-14 14:09:27 --> Total execution time: 0.0293
DEBUG - 2011-08-14 14:09:27 --> Config Class Initialized
DEBUG - 2011-08-14 14:09:27 --> Hooks Class Initialized
DEBUG - 2011-08-14 14:09:27 --> Utf8 Class Initialized
DEBUG - 2011-08-14 14:09:27 --> UTF-8 Support Enabled
DEBUG - 2011-08-14 14:09:27 --> URI Class Initialized
DEBUG - 2011-08-14 14:09:27 --> Router Class Initialized
DEBUG - 2011-08-14 14:09:27 --> Output Class Initialized
DEBUG - 2011-08-14 14:09:27 --> Input Class Initialized
DEBUG - 2011-08-14 14:09:27 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-14 14:09:27 --> Language Class Initialized
DEBUG - 2011-08-14 14:09:27 --> Loader Class Initialized
DEBUG - 2011-08-14 14:09:27 --> Controller Class Initialized
DEBUG - 2011-08-14 14:09:27 --> Model Class Initialized
DEBUG - 2011-08-14 14:09:27 --> Model Class Initialized
DEBUG - 2011-08-14 14:09:27 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-14 14:09:27 --> Database Driver Class Initialized
DEBUG - 2011-08-14 14:09:28 --> Final output sent to browser
DEBUG - 2011-08-14 14:09:28 --> Total execution time: 0.5386
DEBUG - 2011-08-14 14:09:30 --> Config Class Initialized
DEBUG - 2011-08-14 14:09:30 --> Hooks Class Initialized
DEBUG - 2011-08-14 14:09:30 --> Utf8 Class Initialized
DEBUG - 2011-08-14 14:09:30 --> UTF-8 Support Enabled
DEBUG - 2011-08-14 14:09:30 --> URI Class Initialized
DEBUG - 2011-08-14 14:09:30 --> Router Class Initialized
ERROR - 2011-08-14 14:09:30 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-08-14 14:09:33 --> Config Class Initialized
DEBUG - 2011-08-14 14:09:33 --> Hooks Class Initialized
DEBUG - 2011-08-14 14:09:33 --> Utf8 Class Initialized
DEBUG - 2011-08-14 14:09:33 --> UTF-8 Support Enabled
DEBUG - 2011-08-14 14:09:33 --> URI Class Initialized
DEBUG - 2011-08-14 14:09:33 --> Router Class Initialized
ERROR - 2011-08-14 14:09:33 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-08-14 14:24:07 --> Config Class Initialized
DEBUG - 2011-08-14 14:24:07 --> Hooks Class Initialized
DEBUG - 2011-08-14 14:24:07 --> Utf8 Class Initialized
DEBUG - 2011-08-14 14:24:07 --> UTF-8 Support Enabled
DEBUG - 2011-08-14 14:24:07 --> URI Class Initialized
DEBUG - 2011-08-14 14:24:07 --> Router Class Initialized
DEBUG - 2011-08-14 14:24:07 --> Output Class Initialized
DEBUG - 2011-08-14 14:24:07 --> Input Class Initialized
DEBUG - 2011-08-14 14:24:07 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-14 14:24:07 --> Language Class Initialized
DEBUG - 2011-08-14 14:24:07 --> Loader Class Initialized
DEBUG - 2011-08-14 14:24:07 --> Controller Class Initialized
ERROR - 2011-08-14 14:24:07 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-08-14 14:24:07 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-08-14 14:24:07 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-08-14 14:24:07 --> Model Class Initialized
DEBUG - 2011-08-14 14:24:07 --> Model Class Initialized
DEBUG - 2011-08-14 14:24:07 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-14 14:24:07 --> Database Driver Class Initialized
DEBUG - 2011-08-14 14:24:07 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-08-14 14:24:07 --> Helper loaded: url_helper
DEBUG - 2011-08-14 14:24:07 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-14 14:24:07 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-14 14:24:07 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-14 14:24:07 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-14 14:24:07 --> Final output sent to browser
DEBUG - 2011-08-14 14:24:07 --> Total execution time: 0.0306
DEBUG - 2011-08-14 14:38:11 --> Config Class Initialized
DEBUG - 2011-08-14 14:38:11 --> Hooks Class Initialized
DEBUG - 2011-08-14 14:38:11 --> Utf8 Class Initialized
DEBUG - 2011-08-14 14:38:11 --> UTF-8 Support Enabled
DEBUG - 2011-08-14 14:38:11 --> URI Class Initialized
DEBUG - 2011-08-14 14:38:11 --> Router Class Initialized
ERROR - 2011-08-14 14:38:11 --> 404 Page Not Found --> robots.txt
DEBUG - 2011-08-14 14:41:54 --> Config Class Initialized
DEBUG - 2011-08-14 14:41:54 --> Hooks Class Initialized
DEBUG - 2011-08-14 14:41:54 --> Utf8 Class Initialized
DEBUG - 2011-08-14 14:41:54 --> UTF-8 Support Enabled
DEBUG - 2011-08-14 14:41:54 --> URI Class Initialized
DEBUG - 2011-08-14 14:41:54 --> Router Class Initialized
DEBUG - 2011-08-14 14:41:54 --> Output Class Initialized
DEBUG - 2011-08-14 14:41:54 --> Input Class Initialized
DEBUG - 2011-08-14 14:41:54 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-14 14:41:54 --> Language Class Initialized
DEBUG - 2011-08-14 14:41:54 --> Loader Class Initialized
DEBUG - 2011-08-14 14:41:54 --> Controller Class Initialized
DEBUG - 2011-08-14 14:41:54 --> Model Class Initialized
DEBUG - 2011-08-14 14:41:54 --> Model Class Initialized
DEBUG - 2011-08-14 14:41:54 --> Model Class Initialized
DEBUG - 2011-08-14 14:41:54 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-14 14:41:54 --> Database Driver Class Initialized
DEBUG - 2011-08-14 14:41:54 --> File loaded: application/views/table/main.php
DEBUG - 2011-08-14 14:41:54 --> Helper loaded: url_helper
DEBUG - 2011-08-14 14:41:54 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-14 14:41:54 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-14 14:41:54 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-14 14:41:54 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-14 14:41:54 --> Final output sent to browser
DEBUG - 2011-08-14 14:41:54 --> Total execution time: 0.4591
DEBUG - 2011-08-14 14:42:00 --> Config Class Initialized
DEBUG - 2011-08-14 14:42:00 --> Hooks Class Initialized
DEBUG - 2011-08-14 14:42:00 --> Utf8 Class Initialized
DEBUG - 2011-08-14 14:42:00 --> UTF-8 Support Enabled
DEBUG - 2011-08-14 14:42:00 --> URI Class Initialized
DEBUG - 2011-08-14 14:42:00 --> Router Class Initialized
ERROR - 2011-08-14 14:42:00 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-08-14 14:42:00 --> Config Class Initialized
DEBUG - 2011-08-14 14:42:00 --> Hooks Class Initialized
DEBUG - 2011-08-14 14:42:00 --> Utf8 Class Initialized
DEBUG - 2011-08-14 14:42:00 --> UTF-8 Support Enabled
DEBUG - 2011-08-14 14:42:00 --> URI Class Initialized
DEBUG - 2011-08-14 14:42:00 --> Router Class Initialized
ERROR - 2011-08-14 14:42:00 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-08-14 14:42:09 --> Config Class Initialized
DEBUG - 2011-08-14 14:42:09 --> Hooks Class Initialized
DEBUG - 2011-08-14 14:42:09 --> Utf8 Class Initialized
DEBUG - 2011-08-14 14:42:09 --> UTF-8 Support Enabled
DEBUG - 2011-08-14 14:42:09 --> URI Class Initialized
DEBUG - 2011-08-14 14:42:09 --> Router Class Initialized
DEBUG - 2011-08-14 14:42:09 --> Output Class Initialized
DEBUG - 2011-08-14 14:42:09 --> Input Class Initialized
DEBUG - 2011-08-14 14:42:09 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-14 14:42:09 --> Language Class Initialized
DEBUG - 2011-08-14 14:42:09 --> Loader Class Initialized
DEBUG - 2011-08-14 14:42:09 --> Controller Class Initialized
DEBUG - 2011-08-14 14:42:09 --> Model Class Initialized
DEBUG - 2011-08-14 14:42:09 --> Model Class Initialized
DEBUG - 2011-08-14 14:42:09 --> Model Class Initialized
DEBUG - 2011-08-14 14:42:09 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-14 14:42:09 --> Database Driver Class Initialized
DEBUG - 2011-08-14 14:42:10 --> File loaded: application/views/table/main.php
DEBUG - 2011-08-14 14:42:10 --> Helper loaded: url_helper
DEBUG - 2011-08-14 14:42:10 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-14 14:42:10 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-14 14:42:10 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-14 14:42:10 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-14 14:42:10 --> Final output sent to browser
DEBUG - 2011-08-14 14:42:10 --> Total execution time: 0.4891
DEBUG - 2011-08-14 15:18:23 --> Config Class Initialized
DEBUG - 2011-08-14 15:18:23 --> Hooks Class Initialized
DEBUG - 2011-08-14 15:18:23 --> Utf8 Class Initialized
DEBUG - 2011-08-14 15:18:23 --> UTF-8 Support Enabled
DEBUG - 2011-08-14 15:18:23 --> URI Class Initialized
DEBUG - 2011-08-14 15:18:23 --> Router Class Initialized
DEBUG - 2011-08-14 15:18:23 --> Output Class Initialized
DEBUG - 2011-08-14 15:18:23 --> Input Class Initialized
DEBUG - 2011-08-14 15:18:23 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-14 15:18:23 --> Language Class Initialized
DEBUG - 2011-08-14 15:18:23 --> Loader Class Initialized
DEBUG - 2011-08-14 15:18:23 --> Controller Class Initialized
ERROR - 2011-08-14 15:18:23 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-08-14 15:18:23 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-08-14 15:18:23 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-08-14 15:18:23 --> Model Class Initialized
DEBUG - 2011-08-14 15:18:23 --> Model Class Initialized
DEBUG - 2011-08-14 15:18:23 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-14 15:18:23 --> Database Driver Class Initialized
DEBUG - 2011-08-14 15:18:23 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-08-14 15:18:23 --> Helper loaded: url_helper
DEBUG - 2011-08-14 15:18:23 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-14 15:18:23 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-14 15:18:23 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-14 15:18:23 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-14 15:18:23 --> Final output sent to browser
DEBUG - 2011-08-14 15:18:23 --> Total execution time: 0.0319
DEBUG - 2011-08-14 15:18:23 --> Config Class Initialized
DEBUG - 2011-08-14 15:18:23 --> Hooks Class Initialized
DEBUG - 2011-08-14 15:18:23 --> Utf8 Class Initialized
DEBUG - 2011-08-14 15:18:23 --> UTF-8 Support Enabled
DEBUG - 2011-08-14 15:18:23 --> URI Class Initialized
DEBUG - 2011-08-14 15:18:23 --> Router Class Initialized
DEBUG - 2011-08-14 15:18:23 --> Output Class Initialized
DEBUG - 2011-08-14 15:18:23 --> Input Class Initialized
DEBUG - 2011-08-14 15:18:23 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-14 15:18:23 --> Language Class Initialized
DEBUG - 2011-08-14 15:18:23 --> Loader Class Initialized
DEBUG - 2011-08-14 15:18:23 --> Controller Class Initialized
DEBUG - 2011-08-14 15:18:23 --> Model Class Initialized
DEBUG - 2011-08-14 15:18:23 --> Model Class Initialized
DEBUG - 2011-08-14 15:18:23 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-14 15:18:23 --> Database Driver Class Initialized
DEBUG - 2011-08-14 15:18:24 --> Final output sent to browser
DEBUG - 2011-08-14 15:18:24 --> Total execution time: 0.6705
DEBUG - 2011-08-14 15:18:25 --> Config Class Initialized
DEBUG - 2011-08-14 15:18:25 --> Hooks Class Initialized
DEBUG - 2011-08-14 15:18:25 --> Utf8 Class Initialized
DEBUG - 2011-08-14 15:18:25 --> UTF-8 Support Enabled
DEBUG - 2011-08-14 15:18:25 --> URI Class Initialized
DEBUG - 2011-08-14 15:18:25 --> Router Class Initialized
ERROR - 2011-08-14 15:18:25 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-08-14 15:18:25 --> Config Class Initialized
DEBUG - 2011-08-14 15:18:25 --> Hooks Class Initialized
DEBUG - 2011-08-14 15:18:25 --> Utf8 Class Initialized
DEBUG - 2011-08-14 15:18:25 --> UTF-8 Support Enabled
DEBUG - 2011-08-14 15:18:25 --> URI Class Initialized
DEBUG - 2011-08-14 15:18:25 --> Router Class Initialized
ERROR - 2011-08-14 15:18:25 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-08-14 15:18:57 --> Config Class Initialized
DEBUG - 2011-08-14 15:18:57 --> Hooks Class Initialized
DEBUG - 2011-08-14 15:18:57 --> Utf8 Class Initialized
DEBUG - 2011-08-14 15:18:57 --> UTF-8 Support Enabled
DEBUG - 2011-08-14 15:18:57 --> URI Class Initialized
DEBUG - 2011-08-14 15:18:57 --> Router Class Initialized
DEBUG - 2011-08-14 15:18:57 --> Output Class Initialized
DEBUG - 2011-08-14 15:18:57 --> Input Class Initialized
DEBUG - 2011-08-14 15:18:57 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-14 15:18:57 --> Language Class Initialized
DEBUG - 2011-08-14 15:18:57 --> Loader Class Initialized
DEBUG - 2011-08-14 15:18:57 --> Controller Class Initialized
ERROR - 2011-08-14 15:18:57 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-08-14 15:18:57 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-08-14 15:18:57 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-08-14 15:18:57 --> Model Class Initialized
DEBUG - 2011-08-14 15:18:57 --> Model Class Initialized
DEBUG - 2011-08-14 15:18:57 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-14 15:18:57 --> Database Driver Class Initialized
DEBUG - 2011-08-14 15:18:57 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-08-14 15:18:57 --> Helper loaded: url_helper
DEBUG - 2011-08-14 15:18:57 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-14 15:18:57 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-14 15:18:57 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-14 15:18:57 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-14 15:18:57 --> Final output sent to browser
DEBUG - 2011-08-14 15:18:57 --> Total execution time: 0.0288
DEBUG - 2011-08-14 15:18:57 --> Config Class Initialized
DEBUG - 2011-08-14 15:18:57 --> Hooks Class Initialized
DEBUG - 2011-08-14 15:18:57 --> Utf8 Class Initialized
DEBUG - 2011-08-14 15:18:57 --> UTF-8 Support Enabled
DEBUG - 2011-08-14 15:18:57 --> URI Class Initialized
DEBUG - 2011-08-14 15:18:57 --> Router Class Initialized
DEBUG - 2011-08-14 15:18:57 --> Output Class Initialized
DEBUG - 2011-08-14 15:18:57 --> Input Class Initialized
DEBUG - 2011-08-14 15:18:57 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-14 15:18:57 --> Language Class Initialized
DEBUG - 2011-08-14 15:18:57 --> Loader Class Initialized
DEBUG - 2011-08-14 15:18:57 --> Controller Class Initialized
DEBUG - 2011-08-14 15:18:57 --> Model Class Initialized
DEBUG - 2011-08-14 15:18:57 --> Model Class Initialized
DEBUG - 2011-08-14 15:18:57 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-14 15:18:57 --> Database Driver Class Initialized
DEBUG - 2011-08-14 15:18:58 --> Final output sent to browser
DEBUG - 2011-08-14 15:18:58 --> Total execution time: 0.5719
DEBUG - 2011-08-14 15:19:13 --> Config Class Initialized
DEBUG - 2011-08-14 15:19:13 --> Hooks Class Initialized
DEBUG - 2011-08-14 15:19:13 --> Utf8 Class Initialized
DEBUG - 2011-08-14 15:19:13 --> UTF-8 Support Enabled
DEBUG - 2011-08-14 15:19:13 --> URI Class Initialized
DEBUG - 2011-08-14 15:19:13 --> Router Class Initialized
DEBUG - 2011-08-14 15:19:13 --> Output Class Initialized
DEBUG - 2011-08-14 15:19:13 --> Input Class Initialized
DEBUG - 2011-08-14 15:19:13 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-14 15:19:13 --> Language Class Initialized
DEBUG - 2011-08-14 15:19:13 --> Loader Class Initialized
DEBUG - 2011-08-14 15:19:13 --> Controller Class Initialized
ERROR - 2011-08-14 15:19:13 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-08-14 15:19:13 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-08-14 15:19:13 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-08-14 15:19:13 --> Model Class Initialized
DEBUG - 2011-08-14 15:19:13 --> Model Class Initialized
DEBUG - 2011-08-14 15:19:13 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-14 15:19:13 --> Database Driver Class Initialized
DEBUG - 2011-08-14 15:19:13 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-08-14 15:19:13 --> Helper loaded: url_helper
DEBUG - 2011-08-14 15:19:13 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-14 15:19:13 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-14 15:19:13 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-14 15:19:13 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-14 15:19:13 --> Final output sent to browser
DEBUG - 2011-08-14 15:19:13 --> Total execution time: 0.0276
DEBUG - 2011-08-14 15:19:13 --> Config Class Initialized
DEBUG - 2011-08-14 15:19:13 --> Hooks Class Initialized
DEBUG - 2011-08-14 15:19:13 --> Utf8 Class Initialized
DEBUG - 2011-08-14 15:19:13 --> UTF-8 Support Enabled
DEBUG - 2011-08-14 15:19:13 --> URI Class Initialized
DEBUG - 2011-08-14 15:19:13 --> Router Class Initialized
DEBUG - 2011-08-14 15:19:13 --> Output Class Initialized
DEBUG - 2011-08-14 15:19:13 --> Input Class Initialized
DEBUG - 2011-08-14 15:19:13 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-14 15:19:13 --> Language Class Initialized
DEBUG - 2011-08-14 15:19:13 --> Loader Class Initialized
DEBUG - 2011-08-14 15:19:13 --> Controller Class Initialized
DEBUG - 2011-08-14 15:19:13 --> Model Class Initialized
DEBUG - 2011-08-14 15:19:13 --> Model Class Initialized
DEBUG - 2011-08-14 15:19:13 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-14 15:19:13 --> Database Driver Class Initialized
DEBUG - 2011-08-14 15:19:14 --> Final output sent to browser
DEBUG - 2011-08-14 15:19:14 --> Total execution time: 0.6480
DEBUG - 2011-08-14 15:19:25 --> Config Class Initialized
DEBUG - 2011-08-14 15:19:25 --> Hooks Class Initialized
DEBUG - 2011-08-14 15:19:25 --> Utf8 Class Initialized
DEBUG - 2011-08-14 15:19:25 --> UTF-8 Support Enabled
DEBUG - 2011-08-14 15:19:25 --> URI Class Initialized
DEBUG - 2011-08-14 15:19:25 --> Router Class Initialized
DEBUG - 2011-08-14 15:19:25 --> Output Class Initialized
DEBUG - 2011-08-14 15:19:25 --> Input Class Initialized
DEBUG - 2011-08-14 15:19:25 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-14 15:19:25 --> Language Class Initialized
DEBUG - 2011-08-14 15:19:25 --> Loader Class Initialized
DEBUG - 2011-08-14 15:19:25 --> Controller Class Initialized
ERROR - 2011-08-14 15:19:25 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-08-14 15:19:25 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-08-14 15:19:25 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-08-14 15:19:25 --> Model Class Initialized
DEBUG - 2011-08-14 15:19:25 --> Model Class Initialized
DEBUG - 2011-08-14 15:19:25 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-14 15:19:25 --> Database Driver Class Initialized
DEBUG - 2011-08-14 15:19:25 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-08-14 15:19:25 --> Helper loaded: url_helper
DEBUG - 2011-08-14 15:19:25 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-14 15:19:25 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-14 15:19:25 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-14 15:19:25 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-14 15:19:25 --> Final output sent to browser
DEBUG - 2011-08-14 15:19:25 --> Total execution time: 0.0292
DEBUG - 2011-08-14 15:19:25 --> Config Class Initialized
DEBUG - 2011-08-14 15:19:25 --> Hooks Class Initialized
DEBUG - 2011-08-14 15:19:25 --> Utf8 Class Initialized
DEBUG - 2011-08-14 15:19:25 --> UTF-8 Support Enabled
DEBUG - 2011-08-14 15:19:25 --> URI Class Initialized
DEBUG - 2011-08-14 15:19:25 --> Router Class Initialized
DEBUG - 2011-08-14 15:19:25 --> Output Class Initialized
DEBUG - 2011-08-14 15:19:25 --> Input Class Initialized
DEBUG - 2011-08-14 15:19:25 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-14 15:19:25 --> Language Class Initialized
DEBUG - 2011-08-14 15:19:25 --> Loader Class Initialized
DEBUG - 2011-08-14 15:19:25 --> Controller Class Initialized
DEBUG - 2011-08-14 15:19:25 --> Model Class Initialized
DEBUG - 2011-08-14 15:19:25 --> Model Class Initialized
DEBUG - 2011-08-14 15:19:25 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-14 15:19:25 --> Database Driver Class Initialized
DEBUG - 2011-08-14 15:19:26 --> Final output sent to browser
DEBUG - 2011-08-14 15:19:26 --> Total execution time: 0.5965
DEBUG - 2011-08-14 15:19:32 --> Config Class Initialized
DEBUG - 2011-08-14 15:19:32 --> Hooks Class Initialized
DEBUG - 2011-08-14 15:19:32 --> Utf8 Class Initialized
DEBUG - 2011-08-14 15:19:32 --> UTF-8 Support Enabled
DEBUG - 2011-08-14 15:19:32 --> URI Class Initialized
DEBUG - 2011-08-14 15:19:32 --> Router Class Initialized
DEBUG - 2011-08-14 15:19:32 --> Output Class Initialized
DEBUG - 2011-08-14 15:19:32 --> Input Class Initialized
DEBUG - 2011-08-14 15:19:32 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-14 15:19:32 --> Language Class Initialized
DEBUG - 2011-08-14 15:19:32 --> Loader Class Initialized
DEBUG - 2011-08-14 15:19:32 --> Controller Class Initialized
ERROR - 2011-08-14 15:19:32 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-08-14 15:19:32 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-08-14 15:19:32 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-08-14 15:19:32 --> Model Class Initialized
DEBUG - 2011-08-14 15:19:32 --> Model Class Initialized
DEBUG - 2011-08-14 15:19:32 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-14 15:19:32 --> Database Driver Class Initialized
DEBUG - 2011-08-14 15:19:32 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-08-14 15:19:32 --> Helper loaded: url_helper
DEBUG - 2011-08-14 15:19:32 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-14 15:19:32 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-14 15:19:32 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-14 15:19:32 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-14 15:19:32 --> Final output sent to browser
DEBUG - 2011-08-14 15:19:32 --> Total execution time: 0.0308
DEBUG - 2011-08-14 15:19:32 --> Config Class Initialized
DEBUG - 2011-08-14 15:19:32 --> Hooks Class Initialized
DEBUG - 2011-08-14 15:19:32 --> Utf8 Class Initialized
DEBUG - 2011-08-14 15:19:32 --> UTF-8 Support Enabled
DEBUG - 2011-08-14 15:19:32 --> URI Class Initialized
DEBUG - 2011-08-14 15:19:32 --> Router Class Initialized
DEBUG - 2011-08-14 15:19:32 --> Output Class Initialized
DEBUG - 2011-08-14 15:19:32 --> Input Class Initialized
DEBUG - 2011-08-14 15:19:32 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-14 15:19:32 --> Language Class Initialized
DEBUG - 2011-08-14 15:19:32 --> Loader Class Initialized
DEBUG - 2011-08-14 15:19:32 --> Controller Class Initialized
DEBUG - 2011-08-14 15:19:32 --> Model Class Initialized
DEBUG - 2011-08-14 15:19:32 --> Model Class Initialized
DEBUG - 2011-08-14 15:19:32 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-14 15:19:32 --> Database Driver Class Initialized
DEBUG - 2011-08-14 15:19:33 --> Final output sent to browser
DEBUG - 2011-08-14 15:19:33 --> Total execution time: 0.6873
DEBUG - 2011-08-14 15:19:41 --> Config Class Initialized
DEBUG - 2011-08-14 15:19:41 --> Hooks Class Initialized
DEBUG - 2011-08-14 15:19:41 --> Utf8 Class Initialized
DEBUG - 2011-08-14 15:19:41 --> UTF-8 Support Enabled
DEBUG - 2011-08-14 15:19:41 --> URI Class Initialized
DEBUG - 2011-08-14 15:19:41 --> Router Class Initialized
DEBUG - 2011-08-14 15:19:41 --> Output Class Initialized
DEBUG - 2011-08-14 15:19:41 --> Input Class Initialized
DEBUG - 2011-08-14 15:19:41 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-14 15:19:41 --> Language Class Initialized
DEBUG - 2011-08-14 15:19:41 --> Loader Class Initialized
DEBUG - 2011-08-14 15:19:41 --> Controller Class Initialized
ERROR - 2011-08-14 15:19:41 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-08-14 15:19:41 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-08-14 15:19:41 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-08-14 15:19:41 --> Model Class Initialized
DEBUG - 2011-08-14 15:19:41 --> Model Class Initialized
DEBUG - 2011-08-14 15:19:41 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-14 15:19:41 --> Database Driver Class Initialized
DEBUG - 2011-08-14 15:19:41 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-08-14 15:19:41 --> Helper loaded: url_helper
DEBUG - 2011-08-14 15:19:41 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-14 15:19:41 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-14 15:19:41 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-14 15:19:41 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-14 15:19:41 --> Final output sent to browser
DEBUG - 2011-08-14 15:19:41 --> Total execution time: 0.0282
DEBUG - 2011-08-14 15:19:41 --> Config Class Initialized
DEBUG - 2011-08-14 15:19:41 --> Hooks Class Initialized
DEBUG - 2011-08-14 15:19:41 --> Utf8 Class Initialized
DEBUG - 2011-08-14 15:19:41 --> UTF-8 Support Enabled
DEBUG - 2011-08-14 15:19:41 --> URI Class Initialized
DEBUG - 2011-08-14 15:19:41 --> Router Class Initialized
DEBUG - 2011-08-14 15:19:41 --> Output Class Initialized
DEBUG - 2011-08-14 15:19:41 --> Input Class Initialized
DEBUG - 2011-08-14 15:19:41 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-14 15:19:41 --> Language Class Initialized
DEBUG - 2011-08-14 15:19:41 --> Loader Class Initialized
DEBUG - 2011-08-14 15:19:41 --> Controller Class Initialized
DEBUG - 2011-08-14 15:19:41 --> Model Class Initialized
DEBUG - 2011-08-14 15:19:41 --> Model Class Initialized
DEBUG - 2011-08-14 15:19:41 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-14 15:19:41 --> Database Driver Class Initialized
DEBUG - 2011-08-14 15:19:42 --> Final output sent to browser
DEBUG - 2011-08-14 15:19:42 --> Total execution time: 0.4929
DEBUG - 2011-08-14 15:19:51 --> Config Class Initialized
DEBUG - 2011-08-14 15:19:51 --> Hooks Class Initialized
DEBUG - 2011-08-14 15:19:51 --> Utf8 Class Initialized
DEBUG - 2011-08-14 15:19:51 --> UTF-8 Support Enabled
DEBUG - 2011-08-14 15:19:51 --> URI Class Initialized
DEBUG - 2011-08-14 15:19:51 --> Router Class Initialized
DEBUG - 2011-08-14 15:19:51 --> Output Class Initialized
DEBUG - 2011-08-14 15:19:51 --> Input Class Initialized
DEBUG - 2011-08-14 15:19:51 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-14 15:19:51 --> Language Class Initialized
DEBUG - 2011-08-14 15:19:51 --> Loader Class Initialized
DEBUG - 2011-08-14 15:19:51 --> Controller Class Initialized
ERROR - 2011-08-14 15:19:51 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-08-14 15:19:51 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-08-14 15:19:51 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-08-14 15:19:51 --> Model Class Initialized
DEBUG - 2011-08-14 15:19:51 --> Model Class Initialized
DEBUG - 2011-08-14 15:19:51 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-14 15:19:51 --> Database Driver Class Initialized
DEBUG - 2011-08-14 15:19:51 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-08-14 15:19:51 --> Helper loaded: url_helper
DEBUG - 2011-08-14 15:19:51 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-14 15:19:51 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-14 15:19:51 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-14 15:19:51 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-14 15:19:51 --> Final output sent to browser
DEBUG - 2011-08-14 15:19:51 --> Total execution time: 0.0853
DEBUG - 2011-08-14 15:19:51 --> Config Class Initialized
DEBUG - 2011-08-14 15:19:51 --> Hooks Class Initialized
DEBUG - 2011-08-14 15:19:51 --> Utf8 Class Initialized
DEBUG - 2011-08-14 15:19:51 --> UTF-8 Support Enabled
DEBUG - 2011-08-14 15:19:51 --> URI Class Initialized
DEBUG - 2011-08-14 15:19:51 --> Router Class Initialized
DEBUG - 2011-08-14 15:19:51 --> Output Class Initialized
DEBUG - 2011-08-14 15:19:51 --> Input Class Initialized
DEBUG - 2011-08-14 15:19:51 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-14 15:19:51 --> Language Class Initialized
DEBUG - 2011-08-14 15:19:51 --> Loader Class Initialized
DEBUG - 2011-08-14 15:19:51 --> Controller Class Initialized
DEBUG - 2011-08-14 15:19:51 --> Model Class Initialized
DEBUG - 2011-08-14 15:19:51 --> Model Class Initialized
DEBUG - 2011-08-14 15:19:51 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-14 15:19:51 --> Database Driver Class Initialized
DEBUG - 2011-08-14 15:19:52 --> Final output sent to browser
DEBUG - 2011-08-14 15:19:52 --> Total execution time: 0.6576
DEBUG - 2011-08-14 15:20:00 --> Config Class Initialized
DEBUG - 2011-08-14 15:20:00 --> Hooks Class Initialized
DEBUG - 2011-08-14 15:20:00 --> Utf8 Class Initialized
DEBUG - 2011-08-14 15:20:00 --> UTF-8 Support Enabled
DEBUG - 2011-08-14 15:20:00 --> URI Class Initialized
DEBUG - 2011-08-14 15:20:00 --> Router Class Initialized
DEBUG - 2011-08-14 15:20:00 --> Output Class Initialized
DEBUG - 2011-08-14 15:20:00 --> Input Class Initialized
DEBUG - 2011-08-14 15:20:00 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-14 15:20:00 --> Language Class Initialized
DEBUG - 2011-08-14 15:20:00 --> Loader Class Initialized
DEBUG - 2011-08-14 15:20:00 --> Controller Class Initialized
ERROR - 2011-08-14 15:20:00 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-08-14 15:20:00 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-08-14 15:20:00 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-08-14 15:20:00 --> Model Class Initialized
DEBUG - 2011-08-14 15:20:00 --> Model Class Initialized
DEBUG - 2011-08-14 15:20:00 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-14 15:20:00 --> Database Driver Class Initialized
DEBUG - 2011-08-14 15:20:00 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-08-14 15:20:00 --> Helper loaded: url_helper
DEBUG - 2011-08-14 15:20:00 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-14 15:20:00 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-14 15:20:00 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-14 15:20:00 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-14 15:20:00 --> Final output sent to browser
DEBUG - 2011-08-14 15:20:00 --> Total execution time: 0.0280
DEBUG - 2011-08-14 15:20:00 --> Config Class Initialized
DEBUG - 2011-08-14 15:20:00 --> Hooks Class Initialized
DEBUG - 2011-08-14 15:20:00 --> Utf8 Class Initialized
DEBUG - 2011-08-14 15:20:00 --> UTF-8 Support Enabled
DEBUG - 2011-08-14 15:20:00 --> URI Class Initialized
DEBUG - 2011-08-14 15:20:00 --> Router Class Initialized
DEBUG - 2011-08-14 15:20:00 --> Output Class Initialized
DEBUG - 2011-08-14 15:20:00 --> Input Class Initialized
DEBUG - 2011-08-14 15:20:00 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-14 15:20:00 --> Language Class Initialized
DEBUG - 2011-08-14 15:20:00 --> Loader Class Initialized
DEBUG - 2011-08-14 15:20:00 --> Controller Class Initialized
DEBUG - 2011-08-14 15:20:00 --> Model Class Initialized
DEBUG - 2011-08-14 15:20:00 --> Model Class Initialized
DEBUG - 2011-08-14 15:20:00 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-14 15:20:00 --> Database Driver Class Initialized
DEBUG - 2011-08-14 15:20:01 --> Final output sent to browser
DEBUG - 2011-08-14 15:20:01 --> Total execution time: 0.5515
DEBUG - 2011-08-14 17:16:44 --> Config Class Initialized
DEBUG - 2011-08-14 17:16:44 --> Hooks Class Initialized
DEBUG - 2011-08-14 17:16:44 --> Utf8 Class Initialized
DEBUG - 2011-08-14 17:16:44 --> UTF-8 Support Enabled
DEBUG - 2011-08-14 17:16:44 --> URI Class Initialized
DEBUG - 2011-08-14 17:16:44 --> Router Class Initialized
DEBUG - 2011-08-14 17:16:44 --> No URI present. Default controller set.
DEBUG - 2011-08-14 17:16:44 --> Output Class Initialized
DEBUG - 2011-08-14 17:16:44 --> Input Class Initialized
DEBUG - 2011-08-14 17:16:44 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-14 17:16:44 --> Language Class Initialized
DEBUG - 2011-08-14 17:16:44 --> Loader Class Initialized
DEBUG - 2011-08-14 17:16:44 --> Controller Class Initialized
DEBUG - 2011-08-14 17:16:44 --> File loaded: application/views/splash/main.php
DEBUG - 2011-08-14 17:16:44 --> Helper loaded: url_helper
DEBUG - 2011-08-14 17:16:44 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-14 17:16:44 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-14 17:16:44 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-14 17:16:44 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-14 17:16:44 --> Final output sent to browser
DEBUG - 2011-08-14 17:16:44 --> Total execution time: 0.0748
DEBUG - 2011-08-14 17:20:54 --> Config Class Initialized
DEBUG - 2011-08-14 17:20:54 --> Hooks Class Initialized
DEBUG - 2011-08-14 17:20:54 --> Utf8 Class Initialized
DEBUG - 2011-08-14 17:20:54 --> UTF-8 Support Enabled
DEBUG - 2011-08-14 17:20:54 --> URI Class Initialized
DEBUG - 2011-08-14 17:20:54 --> Router Class Initialized
ERROR - 2011-08-14 17:20:54 --> 404 Page Not Found --> robots.txt
DEBUG - 2011-08-14 17:44:14 --> Config Class Initialized
DEBUG - 2011-08-14 17:44:14 --> Hooks Class Initialized
DEBUG - 2011-08-14 17:44:14 --> Utf8 Class Initialized
DEBUG - 2011-08-14 17:44:14 --> UTF-8 Support Enabled
DEBUG - 2011-08-14 17:44:14 --> URI Class Initialized
DEBUG - 2011-08-14 17:44:14 --> Router Class Initialized
DEBUG - 2011-08-14 17:44:14 --> Output Class Initialized
DEBUG - 2011-08-14 17:44:14 --> Input Class Initialized
DEBUG - 2011-08-14 17:44:14 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-14 17:44:14 --> Language Class Initialized
DEBUG - 2011-08-14 17:44:14 --> Loader Class Initialized
DEBUG - 2011-08-14 17:44:14 --> Controller Class Initialized
ERROR - 2011-08-14 17:44:14 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-08-14 17:44:14 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-08-14 17:44:14 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-08-14 17:44:14 --> Model Class Initialized
DEBUG - 2011-08-14 17:44:14 --> Model Class Initialized
DEBUG - 2011-08-14 17:44:14 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-14 17:44:14 --> Database Driver Class Initialized
DEBUG - 2011-08-14 17:44:14 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-08-14 17:44:14 --> Helper loaded: url_helper
DEBUG - 2011-08-14 17:44:14 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-14 17:44:14 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-14 17:44:14 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-14 17:44:14 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-14 17:44:14 --> Final output sent to browser
DEBUG - 2011-08-14 17:44:14 --> Total execution time: 0.1833
DEBUG - 2011-08-14 17:44:16 --> Config Class Initialized
DEBUG - 2011-08-14 17:44:16 --> Hooks Class Initialized
DEBUG - 2011-08-14 17:44:16 --> Utf8 Class Initialized
DEBUG - 2011-08-14 17:44:16 --> UTF-8 Support Enabled
DEBUG - 2011-08-14 17:44:16 --> URI Class Initialized
DEBUG - 2011-08-14 17:44:16 --> Router Class Initialized
DEBUG - 2011-08-14 17:44:16 --> Output Class Initialized
DEBUG - 2011-08-14 17:44:16 --> Input Class Initialized
DEBUG - 2011-08-14 17:44:16 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-14 17:44:16 --> Language Class Initialized
DEBUG - 2011-08-14 17:44:16 --> Loader Class Initialized
DEBUG - 2011-08-14 17:44:16 --> Controller Class Initialized
DEBUG - 2011-08-14 17:44:16 --> Model Class Initialized
DEBUG - 2011-08-14 17:44:16 --> Model Class Initialized
DEBUG - 2011-08-14 17:44:16 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-14 17:44:16 --> Database Driver Class Initialized
DEBUG - 2011-08-14 17:44:16 --> Final output sent to browser
DEBUG - 2011-08-14 17:44:16 --> Total execution time: 0.6622
DEBUG - 2011-08-14 17:44:18 --> Config Class Initialized
DEBUG - 2011-08-14 17:44:18 --> Hooks Class Initialized
DEBUG - 2011-08-14 17:44:18 --> Utf8 Class Initialized
DEBUG - 2011-08-14 17:44:18 --> UTF-8 Support Enabled
DEBUG - 2011-08-14 17:44:18 --> URI Class Initialized
DEBUG - 2011-08-14 17:44:18 --> Router Class Initialized
ERROR - 2011-08-14 17:44:18 --> 404 Page Not Found --> robots.txt
DEBUG - 2011-08-14 17:44:18 --> Config Class Initialized
DEBUG - 2011-08-14 17:44:18 --> Hooks Class Initialized
DEBUG - 2011-08-14 17:44:18 --> Utf8 Class Initialized
DEBUG - 2011-08-14 17:44:18 --> UTF-8 Support Enabled
DEBUG - 2011-08-14 17:44:18 --> URI Class Initialized
DEBUG - 2011-08-14 17:44:18 --> Router Class Initialized
DEBUG - 2011-08-14 17:44:18 --> Output Class Initialized
DEBUG - 2011-08-14 17:44:18 --> Input Class Initialized
DEBUG - 2011-08-14 17:44:18 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-14 17:44:18 --> Language Class Initialized
DEBUG - 2011-08-14 17:44:18 --> Loader Class Initialized
DEBUG - 2011-08-14 17:44:18 --> Controller Class Initialized
ERROR - 2011-08-14 17:44:18 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-08-14 17:44:18 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-08-14 17:44:18 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-08-14 17:44:18 --> Model Class Initialized
DEBUG - 2011-08-14 17:44:18 --> Model Class Initialized
DEBUG - 2011-08-14 17:44:18 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-14 17:44:18 --> Database Driver Class Initialized
DEBUG - 2011-08-14 17:44:18 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-08-14 17:44:18 --> Helper loaded: url_helper
DEBUG - 2011-08-14 17:44:18 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-14 17:44:18 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-14 17:44:18 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-14 17:44:18 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-14 17:44:18 --> Final output sent to browser
DEBUG - 2011-08-14 17:44:18 --> Total execution time: 0.0505
DEBUG - 2011-08-14 17:44:18 --> Config Class Initialized
DEBUG - 2011-08-14 17:44:18 --> Hooks Class Initialized
DEBUG - 2011-08-14 17:44:18 --> Utf8 Class Initialized
DEBUG - 2011-08-14 17:44:18 --> UTF-8 Support Enabled
DEBUG - 2011-08-14 17:44:18 --> URI Class Initialized
DEBUG - 2011-08-14 17:44:18 --> Router Class Initialized
ERROR - 2011-08-14 17:44:18 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-08-14 17:44:19 --> Config Class Initialized
DEBUG - 2011-08-14 17:44:19 --> Hooks Class Initialized
DEBUG - 2011-08-14 17:44:19 --> Utf8 Class Initialized
DEBUG - 2011-08-14 17:44:19 --> UTF-8 Support Enabled
DEBUG - 2011-08-14 17:44:19 --> URI Class Initialized
DEBUG - 2011-08-14 17:44:19 --> Router Class Initialized
ERROR - 2011-08-14 17:44:19 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-08-14 17:45:58 --> Config Class Initialized
DEBUG - 2011-08-14 17:45:58 --> Hooks Class Initialized
DEBUG - 2011-08-14 17:45:58 --> Utf8 Class Initialized
DEBUG - 2011-08-14 17:45:58 --> UTF-8 Support Enabled
DEBUG - 2011-08-14 17:45:58 --> URI Class Initialized
DEBUG - 2011-08-14 17:45:58 --> Router Class Initialized
DEBUG - 2011-08-14 17:45:58 --> Output Class Initialized
DEBUG - 2011-08-14 17:45:58 --> Input Class Initialized
DEBUG - 2011-08-14 17:45:58 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-14 17:45:58 --> Language Class Initialized
DEBUG - 2011-08-14 17:45:58 --> Loader Class Initialized
DEBUG - 2011-08-14 17:45:58 --> Controller Class Initialized
DEBUG - 2011-08-14 17:45:58 --> Model Class Initialized
DEBUG - 2011-08-14 17:45:58 --> Model Class Initialized
DEBUG - 2011-08-14 17:45:58 --> Model Class Initialized
DEBUG - 2011-08-14 17:45:58 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-14 17:45:58 --> Database Driver Class Initialized
DEBUG - 2011-08-14 17:45:59 --> File loaded: application/views/table/main.php
DEBUG - 2011-08-14 17:45:59 --> Helper loaded: url_helper
DEBUG - 2011-08-14 17:45:59 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-14 17:45:59 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-14 17:45:59 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-14 17:45:59 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-14 17:45:59 --> Final output sent to browser
DEBUG - 2011-08-14 17:45:59 --> Total execution time: 0.2875
DEBUG - 2011-08-14 17:46:34 --> Config Class Initialized
DEBUG - 2011-08-14 17:46:34 --> Hooks Class Initialized
DEBUG - 2011-08-14 17:46:34 --> Utf8 Class Initialized
DEBUG - 2011-08-14 17:46:34 --> UTF-8 Support Enabled
DEBUG - 2011-08-14 17:46:34 --> URI Class Initialized
DEBUG - 2011-08-14 17:46:35 --> Router Class Initialized
DEBUG - 2011-08-14 17:46:35 --> Output Class Initialized
DEBUG - 2011-08-14 17:46:35 --> Input Class Initialized
DEBUG - 2011-08-14 17:46:35 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-14 17:46:35 --> Language Class Initialized
DEBUG - 2011-08-14 17:46:35 --> Loader Class Initialized
DEBUG - 2011-08-14 17:46:35 --> Controller Class Initialized
DEBUG - 2011-08-14 17:46:35 --> Model Class Initialized
DEBUG - 2011-08-14 17:46:35 --> Model Class Initialized
DEBUG - 2011-08-14 17:46:35 --> Model Class Initialized
DEBUG - 2011-08-14 17:46:35 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-14 17:46:35 --> Database Driver Class Initialized
DEBUG - 2011-08-14 17:46:35 --> File loaded: application/views/table/main.php
DEBUG - 2011-08-14 17:46:35 --> Helper loaded: url_helper
DEBUG - 2011-08-14 17:46:35 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-14 17:46:35 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-14 17:46:35 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-14 17:46:35 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-14 17:46:35 --> Final output sent to browser
DEBUG - 2011-08-14 17:46:35 --> Total execution time: 0.0468
DEBUG - 2011-08-14 17:46:42 --> Config Class Initialized
DEBUG - 2011-08-14 17:46:42 --> Hooks Class Initialized
DEBUG - 2011-08-14 17:46:42 --> Utf8 Class Initialized
DEBUG - 2011-08-14 17:46:42 --> UTF-8 Support Enabled
DEBUG - 2011-08-14 17:46:42 --> URI Class Initialized
DEBUG - 2011-08-14 17:46:42 --> Router Class Initialized
ERROR - 2011-08-14 17:46:42 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-08-14 17:46:44 --> Config Class Initialized
DEBUG - 2011-08-14 17:46:44 --> Hooks Class Initialized
DEBUG - 2011-08-14 17:46:44 --> Utf8 Class Initialized
DEBUG - 2011-08-14 17:46:44 --> UTF-8 Support Enabled
DEBUG - 2011-08-14 17:46:44 --> URI Class Initialized
DEBUG - 2011-08-14 17:46:44 --> Router Class Initialized
ERROR - 2011-08-14 17:46:44 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-08-14 17:47:15 --> Config Class Initialized
DEBUG - 2011-08-14 17:47:15 --> Hooks Class Initialized
DEBUG - 2011-08-14 17:47:15 --> Utf8 Class Initialized
DEBUG - 2011-08-14 17:47:15 --> UTF-8 Support Enabled
DEBUG - 2011-08-14 17:47:15 --> URI Class Initialized
DEBUG - 2011-08-14 17:47:15 --> Router Class Initialized
DEBUG - 2011-08-14 17:47:15 --> Output Class Initialized
DEBUG - 2011-08-14 17:47:15 --> Input Class Initialized
DEBUG - 2011-08-14 17:47:15 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-14 17:47:15 --> Language Class Initialized
DEBUG - 2011-08-14 17:47:15 --> Loader Class Initialized
DEBUG - 2011-08-14 17:47:15 --> Controller Class Initialized
DEBUG - 2011-08-14 17:47:15 --> Model Class Initialized
DEBUG - 2011-08-14 17:47:15 --> Model Class Initialized
DEBUG - 2011-08-14 17:47:15 --> Model Class Initialized
DEBUG - 2011-08-14 17:47:15 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-14 17:47:15 --> Database Driver Class Initialized
DEBUG - 2011-08-14 17:47:15 --> File loaded: application/views/table/main.php
DEBUG - 2011-08-14 17:47:15 --> Helper loaded: url_helper
DEBUG - 2011-08-14 17:47:15 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-14 17:47:15 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-14 17:47:15 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-14 17:47:15 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-14 17:47:15 --> Final output sent to browser
DEBUG - 2011-08-14 17:47:15 --> Total execution time: 0.4566
DEBUG - 2011-08-14 17:47:18 --> Config Class Initialized
DEBUG - 2011-08-14 17:47:18 --> Hooks Class Initialized
DEBUG - 2011-08-14 17:47:18 --> Utf8 Class Initialized
DEBUG - 2011-08-14 17:47:18 --> UTF-8 Support Enabled
DEBUG - 2011-08-14 17:47:18 --> URI Class Initialized
DEBUG - 2011-08-14 17:47:18 --> Router Class Initialized
DEBUG - 2011-08-14 17:47:18 --> Output Class Initialized
DEBUG - 2011-08-14 17:47:18 --> Input Class Initialized
DEBUG - 2011-08-14 17:47:18 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-14 17:47:18 --> Language Class Initialized
DEBUG - 2011-08-14 17:47:18 --> Loader Class Initialized
DEBUG - 2011-08-14 17:47:18 --> Controller Class Initialized
DEBUG - 2011-08-14 17:47:18 --> Model Class Initialized
DEBUG - 2011-08-14 17:47:18 --> Model Class Initialized
DEBUG - 2011-08-14 17:47:18 --> Model Class Initialized
DEBUG - 2011-08-14 17:47:18 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-14 17:47:18 --> Database Driver Class Initialized
DEBUG - 2011-08-14 17:47:18 --> File loaded: application/views/table/main.php
DEBUG - 2011-08-14 17:47:18 --> Helper loaded: url_helper
DEBUG - 2011-08-14 17:47:18 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-14 17:47:18 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-14 17:47:18 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-14 17:47:18 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-14 17:47:18 --> Final output sent to browser
DEBUG - 2011-08-14 17:47:18 --> Total execution time: 0.0447
DEBUG - 2011-08-14 17:47:24 --> Config Class Initialized
DEBUG - 2011-08-14 17:47:24 --> Hooks Class Initialized
DEBUG - 2011-08-14 17:47:24 --> Utf8 Class Initialized
DEBUG - 2011-08-14 17:47:24 --> UTF-8 Support Enabled
DEBUG - 2011-08-14 17:47:24 --> URI Class Initialized
DEBUG - 2011-08-14 17:47:24 --> Router Class Initialized
ERROR - 2011-08-14 17:47:24 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-08-14 17:47:52 --> Config Class Initialized
DEBUG - 2011-08-14 17:47:52 --> Hooks Class Initialized
DEBUG - 2011-08-14 17:47:52 --> Utf8 Class Initialized
DEBUG - 2011-08-14 17:47:52 --> UTF-8 Support Enabled
DEBUG - 2011-08-14 17:47:52 --> URI Class Initialized
DEBUG - 2011-08-14 17:47:52 --> Router Class Initialized
DEBUG - 2011-08-14 17:47:52 --> Output Class Initialized
DEBUG - 2011-08-14 17:47:52 --> Input Class Initialized
DEBUG - 2011-08-14 17:47:52 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-14 17:47:52 --> Language Class Initialized
DEBUG - 2011-08-14 17:47:52 --> Loader Class Initialized
DEBUG - 2011-08-14 17:47:52 --> Controller Class Initialized
DEBUG - 2011-08-14 17:47:52 --> Model Class Initialized
DEBUG - 2011-08-14 17:47:52 --> Model Class Initialized
DEBUG - 2011-08-14 17:47:52 --> Model Class Initialized
DEBUG - 2011-08-14 17:47:52 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-14 17:47:52 --> Database Driver Class Initialized
DEBUG - 2011-08-14 17:47:53 --> File loaded: application/views/table/main.php
DEBUG - 2011-08-14 17:47:53 --> Helper loaded: url_helper
DEBUG - 2011-08-14 17:47:53 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-14 17:47:53 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-14 17:47:53 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-14 17:47:53 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-14 17:47:53 --> Final output sent to browser
DEBUG - 2011-08-14 17:47:53 --> Total execution time: 0.6652
DEBUG - 2011-08-14 17:47:55 --> Config Class Initialized
DEBUG - 2011-08-14 17:47:55 --> Hooks Class Initialized
DEBUG - 2011-08-14 17:47:55 --> Utf8 Class Initialized
DEBUG - 2011-08-14 17:47:55 --> UTF-8 Support Enabled
DEBUG - 2011-08-14 17:47:55 --> URI Class Initialized
DEBUG - 2011-08-14 17:47:55 --> Router Class Initialized
DEBUG - 2011-08-14 17:47:55 --> Output Class Initialized
DEBUG - 2011-08-14 17:47:55 --> Input Class Initialized
DEBUG - 2011-08-14 17:47:55 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-14 17:47:55 --> Language Class Initialized
DEBUG - 2011-08-14 17:47:55 --> Loader Class Initialized
DEBUG - 2011-08-14 17:47:55 --> Controller Class Initialized
DEBUG - 2011-08-14 17:47:55 --> Model Class Initialized
DEBUG - 2011-08-14 17:47:55 --> Model Class Initialized
DEBUG - 2011-08-14 17:47:55 --> Model Class Initialized
DEBUG - 2011-08-14 17:47:55 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-14 17:47:55 --> Database Driver Class Initialized
DEBUG - 2011-08-14 17:47:55 --> File loaded: application/views/table/main.php
DEBUG - 2011-08-14 17:47:55 --> Helper loaded: url_helper
DEBUG - 2011-08-14 17:47:55 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-14 17:47:55 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-14 17:47:55 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-14 17:47:55 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-14 17:47:55 --> Final output sent to browser
DEBUG - 2011-08-14 17:47:55 --> Total execution time: 0.0423
DEBUG - 2011-08-14 17:48:02 --> Config Class Initialized
DEBUG - 2011-08-14 17:48:02 --> Hooks Class Initialized
DEBUG - 2011-08-14 17:48:02 --> Utf8 Class Initialized
DEBUG - 2011-08-14 17:48:02 --> UTF-8 Support Enabled
DEBUG - 2011-08-14 17:48:02 --> URI Class Initialized
DEBUG - 2011-08-14 17:48:02 --> Router Class Initialized
ERROR - 2011-08-14 17:48:02 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-08-14 17:48:32 --> Config Class Initialized
DEBUG - 2011-08-14 17:48:32 --> Hooks Class Initialized
DEBUG - 2011-08-14 17:48:32 --> Utf8 Class Initialized
DEBUG - 2011-08-14 17:48:32 --> UTF-8 Support Enabled
DEBUG - 2011-08-14 17:48:32 --> URI Class Initialized
DEBUG - 2011-08-14 17:48:32 --> Router Class Initialized
DEBUG - 2011-08-14 17:48:32 --> Output Class Initialized
DEBUG - 2011-08-14 17:48:32 --> Input Class Initialized
DEBUG - 2011-08-14 17:48:32 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-14 17:48:32 --> Language Class Initialized
DEBUG - 2011-08-14 17:48:32 --> Loader Class Initialized
DEBUG - 2011-08-14 17:48:32 --> Controller Class Initialized
DEBUG - 2011-08-14 17:48:32 --> Model Class Initialized
DEBUG - 2011-08-14 17:48:32 --> Model Class Initialized
DEBUG - 2011-08-14 17:48:32 --> Model Class Initialized
DEBUG - 2011-08-14 17:48:32 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-14 17:48:32 --> Database Driver Class Initialized
DEBUG - 2011-08-14 17:48:32 --> File loaded: application/views/table/main.php
DEBUG - 2011-08-14 17:48:32 --> Helper loaded: url_helper
DEBUG - 2011-08-14 17:48:32 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-14 17:48:32 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-14 17:48:32 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-14 17:48:32 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-14 17:48:32 --> Final output sent to browser
DEBUG - 2011-08-14 17:48:32 --> Total execution time: 0.3014
DEBUG - 2011-08-14 17:48:35 --> Config Class Initialized
DEBUG - 2011-08-14 17:48:35 --> Hooks Class Initialized
DEBUG - 2011-08-14 17:48:35 --> Utf8 Class Initialized
DEBUG - 2011-08-14 17:48:35 --> UTF-8 Support Enabled
DEBUG - 2011-08-14 17:48:35 --> URI Class Initialized
DEBUG - 2011-08-14 17:48:35 --> Router Class Initialized
DEBUG - 2011-08-14 17:48:35 --> Output Class Initialized
DEBUG - 2011-08-14 17:48:35 --> Input Class Initialized
DEBUG - 2011-08-14 17:48:35 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-14 17:48:35 --> Language Class Initialized
DEBUG - 2011-08-14 17:48:35 --> Loader Class Initialized
DEBUG - 2011-08-14 17:48:35 --> Controller Class Initialized
DEBUG - 2011-08-14 17:48:35 --> Model Class Initialized
DEBUG - 2011-08-14 17:48:35 --> Model Class Initialized
DEBUG - 2011-08-14 17:48:35 --> Model Class Initialized
DEBUG - 2011-08-14 17:48:35 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-14 17:48:35 --> Database Driver Class Initialized
DEBUG - 2011-08-14 17:48:35 --> File loaded: application/views/table/main.php
DEBUG - 2011-08-14 17:48:35 --> Helper loaded: url_helper
DEBUG - 2011-08-14 17:48:35 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-14 17:48:35 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-14 17:48:35 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-14 17:48:35 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-14 17:48:35 --> Final output sent to browser
DEBUG - 2011-08-14 17:48:35 --> Total execution time: 0.0501
DEBUG - 2011-08-14 17:48:38 --> Config Class Initialized
DEBUG - 2011-08-14 17:48:38 --> Hooks Class Initialized
DEBUG - 2011-08-14 17:48:38 --> Utf8 Class Initialized
DEBUG - 2011-08-14 17:48:38 --> UTF-8 Support Enabled
DEBUG - 2011-08-14 17:48:38 --> URI Class Initialized
DEBUG - 2011-08-14 17:48:38 --> Router Class Initialized
ERROR - 2011-08-14 17:48:38 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-08-14 17:51:09 --> Config Class Initialized
DEBUG - 2011-08-14 17:51:09 --> Hooks Class Initialized
DEBUG - 2011-08-14 17:51:09 --> Utf8 Class Initialized
DEBUG - 2011-08-14 17:51:09 --> UTF-8 Support Enabled
DEBUG - 2011-08-14 17:51:09 --> URI Class Initialized
DEBUG - 2011-08-14 17:51:09 --> Router Class Initialized
DEBUG - 2011-08-14 17:51:09 --> Output Class Initialized
DEBUG - 2011-08-14 17:51:09 --> Input Class Initialized
DEBUG - 2011-08-14 17:51:09 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-14 17:51:09 --> Language Class Initialized
DEBUG - 2011-08-14 17:51:09 --> Loader Class Initialized
DEBUG - 2011-08-14 17:51:09 --> Controller Class Initialized
DEBUG - 2011-08-14 17:51:09 --> Model Class Initialized
DEBUG - 2011-08-14 17:51:09 --> Model Class Initialized
DEBUG - 2011-08-14 17:51:09 --> Model Class Initialized
DEBUG - 2011-08-14 17:51:09 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-14 17:51:09 --> Database Driver Class Initialized
DEBUG - 2011-08-14 17:51:09 --> File loaded: application/views/table/main.php
DEBUG - 2011-08-14 17:51:09 --> Helper loaded: url_helper
DEBUG - 2011-08-14 17:51:09 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-14 17:51:09 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-14 17:51:09 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-14 17:51:09 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-14 17:51:09 --> Final output sent to browser
DEBUG - 2011-08-14 17:51:09 --> Total execution time: 0.3042
DEBUG - 2011-08-14 17:51:12 --> Config Class Initialized
DEBUG - 2011-08-14 17:51:12 --> Hooks Class Initialized
DEBUG - 2011-08-14 17:51:12 --> Utf8 Class Initialized
DEBUG - 2011-08-14 17:51:12 --> UTF-8 Support Enabled
DEBUG - 2011-08-14 17:51:12 --> URI Class Initialized
DEBUG - 2011-08-14 17:51:12 --> Router Class Initialized
DEBUG - 2011-08-14 17:51:12 --> Output Class Initialized
DEBUG - 2011-08-14 17:51:12 --> Input Class Initialized
DEBUG - 2011-08-14 17:51:12 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-14 17:51:12 --> Language Class Initialized
DEBUG - 2011-08-14 17:51:12 --> Loader Class Initialized
DEBUG - 2011-08-14 17:51:12 --> Controller Class Initialized
DEBUG - 2011-08-14 17:51:12 --> Model Class Initialized
DEBUG - 2011-08-14 17:51:12 --> Model Class Initialized
DEBUG - 2011-08-14 17:51:12 --> Model Class Initialized
DEBUG - 2011-08-14 17:51:12 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-14 17:51:12 --> Database Driver Class Initialized
DEBUG - 2011-08-14 17:51:12 --> File loaded: application/views/table/main.php
DEBUG - 2011-08-14 17:51:12 --> Helper loaded: url_helper
DEBUG - 2011-08-14 17:51:12 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-14 17:51:12 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-14 17:51:12 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-14 17:51:12 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-14 17:51:12 --> Final output sent to browser
DEBUG - 2011-08-14 17:51:12 --> Total execution time: 0.1049
DEBUG - 2011-08-14 17:51:15 --> Config Class Initialized
DEBUG - 2011-08-14 17:51:15 --> Hooks Class Initialized
DEBUG - 2011-08-14 17:51:15 --> Utf8 Class Initialized
DEBUG - 2011-08-14 17:51:15 --> UTF-8 Support Enabled
DEBUG - 2011-08-14 17:51:15 --> URI Class Initialized
DEBUG - 2011-08-14 17:51:15 --> Router Class Initialized
ERROR - 2011-08-14 17:51:15 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-08-14 17:55:36 --> Config Class Initialized
DEBUG - 2011-08-14 17:55:36 --> Hooks Class Initialized
DEBUG - 2011-08-14 17:55:36 --> Utf8 Class Initialized
DEBUG - 2011-08-14 17:55:36 --> UTF-8 Support Enabled
DEBUG - 2011-08-14 17:55:36 --> URI Class Initialized
DEBUG - 2011-08-14 17:55:36 --> Router Class Initialized
DEBUG - 2011-08-14 17:55:36 --> Output Class Initialized
DEBUG - 2011-08-14 17:55:36 --> Input Class Initialized
DEBUG - 2011-08-14 17:55:36 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-14 17:55:36 --> Language Class Initialized
DEBUG - 2011-08-14 17:55:36 --> Loader Class Initialized
DEBUG - 2011-08-14 17:55:36 --> Controller Class Initialized
DEBUG - 2011-08-14 17:55:36 --> Model Class Initialized
DEBUG - 2011-08-14 17:55:36 --> Model Class Initialized
DEBUG - 2011-08-14 17:55:36 --> Model Class Initialized
DEBUG - 2011-08-14 17:55:36 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-14 17:55:36 --> Database Driver Class Initialized
DEBUG - 2011-08-14 17:55:37 --> File loaded: application/views/table/main.php
DEBUG - 2011-08-14 17:55:37 --> Helper loaded: url_helper
DEBUG - 2011-08-14 17:55:37 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-14 17:55:37 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-14 17:55:37 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-14 17:55:37 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-14 17:55:37 --> Final output sent to browser
DEBUG - 2011-08-14 17:55:37 --> Total execution time: 0.2503
DEBUG - 2011-08-14 17:55:42 --> Config Class Initialized
DEBUG - 2011-08-14 17:55:42 --> Hooks Class Initialized
DEBUG - 2011-08-14 17:55:42 --> Utf8 Class Initialized
DEBUG - 2011-08-14 17:55:42 --> UTF-8 Support Enabled
DEBUG - 2011-08-14 17:55:42 --> URI Class Initialized
DEBUG - 2011-08-14 17:55:42 --> Router Class Initialized
DEBUG - 2011-08-14 17:55:42 --> Output Class Initialized
DEBUG - 2011-08-14 17:55:42 --> Input Class Initialized
DEBUG - 2011-08-14 17:55:42 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-14 17:55:42 --> Language Class Initialized
DEBUG - 2011-08-14 17:55:42 --> Loader Class Initialized
DEBUG - 2011-08-14 17:55:42 --> Controller Class Initialized
DEBUG - 2011-08-14 17:55:42 --> Model Class Initialized
DEBUG - 2011-08-14 17:55:42 --> Model Class Initialized
DEBUG - 2011-08-14 17:55:42 --> Model Class Initialized
DEBUG - 2011-08-14 17:55:42 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-14 17:55:42 --> Database Driver Class Initialized
DEBUG - 2011-08-14 17:55:42 --> File loaded: application/views/table/main.php
DEBUG - 2011-08-14 17:55:42 --> Helper loaded: url_helper
DEBUG - 2011-08-14 17:55:42 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-14 17:55:42 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-14 17:55:42 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-14 17:55:42 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-14 17:55:42 --> Final output sent to browser
DEBUG - 2011-08-14 17:55:42 --> Total execution time: 0.0429
DEBUG - 2011-08-14 17:55:52 --> Config Class Initialized
DEBUG - 2011-08-14 17:55:52 --> Hooks Class Initialized
DEBUG - 2011-08-14 17:55:52 --> Utf8 Class Initialized
DEBUG - 2011-08-14 17:55:52 --> UTF-8 Support Enabled
DEBUG - 2011-08-14 17:55:52 --> URI Class Initialized
DEBUG - 2011-08-14 17:55:52 --> Router Class Initialized
DEBUG - 2011-08-14 17:55:52 --> Output Class Initialized
DEBUG - 2011-08-14 17:55:52 --> Input Class Initialized
DEBUG - 2011-08-14 17:55:52 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-14 17:55:52 --> Language Class Initialized
DEBUG - 2011-08-14 17:55:52 --> Loader Class Initialized
DEBUG - 2011-08-14 17:55:52 --> Controller Class Initialized
DEBUG - 2011-08-14 17:55:52 --> Model Class Initialized
DEBUG - 2011-08-14 17:55:52 --> Model Class Initialized
DEBUG - 2011-08-14 17:55:52 --> Model Class Initialized
DEBUG - 2011-08-14 17:55:52 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-14 17:55:53 --> Database Driver Class Initialized
DEBUG - 2011-08-14 17:55:53 --> File loaded: application/views/table/main.php
DEBUG - 2011-08-14 17:55:53 --> Helper loaded: url_helper
DEBUG - 2011-08-14 17:55:53 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-14 17:55:53 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-14 17:55:53 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-14 17:55:53 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-14 17:55:53 --> Final output sent to browser
DEBUG - 2011-08-14 17:55:53 --> Total execution time: 0.2033
DEBUG - 2011-08-14 17:55:53 --> Config Class Initialized
DEBUG - 2011-08-14 17:55:53 --> Hooks Class Initialized
DEBUG - 2011-08-14 17:55:53 --> Utf8 Class Initialized
DEBUG - 2011-08-14 17:55:53 --> UTF-8 Support Enabled
DEBUG - 2011-08-14 17:55:53 --> URI Class Initialized
DEBUG - 2011-08-14 17:55:53 --> Router Class Initialized
ERROR - 2011-08-14 17:55:53 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-08-14 17:55:54 --> Config Class Initialized
DEBUG - 2011-08-14 17:55:54 --> Hooks Class Initialized
DEBUG - 2011-08-14 17:55:54 --> Utf8 Class Initialized
DEBUG - 2011-08-14 17:55:54 --> UTF-8 Support Enabled
DEBUG - 2011-08-14 17:55:54 --> URI Class Initialized
DEBUG - 2011-08-14 17:55:54 --> Router Class Initialized
DEBUG - 2011-08-14 17:55:54 --> Output Class Initialized
DEBUG - 2011-08-14 17:55:54 --> Input Class Initialized
DEBUG - 2011-08-14 17:55:54 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-14 17:55:54 --> Language Class Initialized
DEBUG - 2011-08-14 17:55:54 --> Loader Class Initialized
DEBUG - 2011-08-14 17:55:54 --> Controller Class Initialized
DEBUG - 2011-08-14 17:55:54 --> Model Class Initialized
DEBUG - 2011-08-14 17:55:54 --> Model Class Initialized
DEBUG - 2011-08-14 17:55:54 --> Model Class Initialized
DEBUG - 2011-08-14 17:55:54 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-14 17:55:54 --> Database Driver Class Initialized
DEBUG - 2011-08-14 17:55:54 --> File loaded: application/views/table/main.php
DEBUG - 2011-08-14 17:55:54 --> Helper loaded: url_helper
DEBUG - 2011-08-14 17:55:54 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-14 17:55:54 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-14 17:55:54 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-14 17:55:54 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-14 17:55:54 --> Final output sent to browser
DEBUG - 2011-08-14 17:55:54 --> Total execution time: 0.0432
DEBUG - 2011-08-14 17:56:02 --> Config Class Initialized
DEBUG - 2011-08-14 17:56:02 --> Hooks Class Initialized
DEBUG - 2011-08-14 17:56:02 --> Utf8 Class Initialized
DEBUG - 2011-08-14 17:56:02 --> UTF-8 Support Enabled
DEBUG - 2011-08-14 17:56:02 --> URI Class Initialized
DEBUG - 2011-08-14 17:56:02 --> Router Class Initialized
ERROR - 2011-08-14 17:56:02 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-08-14 17:56:18 --> Config Class Initialized
DEBUG - 2011-08-14 17:56:18 --> Hooks Class Initialized
DEBUG - 2011-08-14 17:56:18 --> Utf8 Class Initialized
DEBUG - 2011-08-14 17:56:18 --> UTF-8 Support Enabled
DEBUG - 2011-08-14 17:56:18 --> URI Class Initialized
DEBUG - 2011-08-14 17:56:18 --> Router Class Initialized
DEBUG - 2011-08-14 17:56:18 --> Output Class Initialized
DEBUG - 2011-08-14 17:56:18 --> Input Class Initialized
DEBUG - 2011-08-14 17:56:18 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-14 17:56:18 --> Language Class Initialized
DEBUG - 2011-08-14 17:56:18 --> Loader Class Initialized
DEBUG - 2011-08-14 17:56:18 --> Controller Class Initialized
DEBUG - 2011-08-14 17:56:18 --> Model Class Initialized
DEBUG - 2011-08-14 17:56:18 --> Model Class Initialized
DEBUG - 2011-08-14 17:56:18 --> Model Class Initialized
DEBUG - 2011-08-14 17:56:18 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-14 17:56:18 --> Database Driver Class Initialized
DEBUG - 2011-08-14 17:56:18 --> File loaded: application/views/table/main.php
DEBUG - 2011-08-14 17:56:18 --> Helper loaded: url_helper
DEBUG - 2011-08-14 17:56:18 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-14 17:56:18 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-14 17:56:18 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-14 17:56:18 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-14 17:56:18 --> Final output sent to browser
DEBUG - 2011-08-14 17:56:18 --> Total execution time: 0.1849
DEBUG - 2011-08-14 17:56:20 --> Config Class Initialized
DEBUG - 2011-08-14 17:56:20 --> Hooks Class Initialized
DEBUG - 2011-08-14 17:56:20 --> Utf8 Class Initialized
DEBUG - 2011-08-14 17:56:20 --> UTF-8 Support Enabled
DEBUG - 2011-08-14 17:56:20 --> URI Class Initialized
DEBUG - 2011-08-14 17:56:20 --> Router Class Initialized
DEBUG - 2011-08-14 17:56:20 --> Output Class Initialized
DEBUG - 2011-08-14 17:56:20 --> Input Class Initialized
DEBUG - 2011-08-14 17:56:20 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-14 17:56:20 --> Language Class Initialized
DEBUG - 2011-08-14 17:56:20 --> Loader Class Initialized
DEBUG - 2011-08-14 17:56:20 --> Controller Class Initialized
DEBUG - 2011-08-14 17:56:20 --> Model Class Initialized
DEBUG - 2011-08-14 17:56:20 --> Model Class Initialized
DEBUG - 2011-08-14 17:56:20 --> Model Class Initialized
DEBUG - 2011-08-14 17:56:20 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-14 17:56:20 --> Database Driver Class Initialized
DEBUG - 2011-08-14 17:56:20 --> File loaded: application/views/table/main.php
DEBUG - 2011-08-14 17:56:20 --> Helper loaded: url_helper
DEBUG - 2011-08-14 17:56:20 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-14 17:56:20 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-14 17:56:20 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-14 17:56:20 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-14 17:56:20 --> Final output sent to browser
DEBUG - 2011-08-14 17:56:20 --> Total execution time: 0.0769
DEBUG - 2011-08-14 17:56:22 --> Config Class Initialized
DEBUG - 2011-08-14 17:56:22 --> Hooks Class Initialized
DEBUG - 2011-08-14 17:56:22 --> Utf8 Class Initialized
DEBUG - 2011-08-14 17:56:22 --> UTF-8 Support Enabled
DEBUG - 2011-08-14 17:56:22 --> URI Class Initialized
DEBUG - 2011-08-14 17:56:22 --> Router Class Initialized
ERROR - 2011-08-14 17:56:22 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-08-14 17:56:30 --> Config Class Initialized
DEBUG - 2011-08-14 17:56:30 --> Hooks Class Initialized
DEBUG - 2011-08-14 17:56:30 --> Utf8 Class Initialized
DEBUG - 2011-08-14 17:56:30 --> UTF-8 Support Enabled
DEBUG - 2011-08-14 17:56:30 --> URI Class Initialized
DEBUG - 2011-08-14 17:56:30 --> Router Class Initialized
DEBUG - 2011-08-14 17:56:30 --> No URI present. Default controller set.
DEBUG - 2011-08-14 17:56:30 --> Output Class Initialized
DEBUG - 2011-08-14 17:56:30 --> Input Class Initialized
DEBUG - 2011-08-14 17:56:30 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-14 17:56:30 --> Language Class Initialized
DEBUG - 2011-08-14 17:56:30 --> Loader Class Initialized
DEBUG - 2011-08-14 17:56:30 --> Controller Class Initialized
DEBUG - 2011-08-14 17:56:30 --> File loaded: application/views/splash/main.php
DEBUG - 2011-08-14 17:56:30 --> Helper loaded: url_helper
DEBUG - 2011-08-14 17:56:30 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-14 17:56:30 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-14 17:56:30 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-14 17:56:30 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-14 17:56:30 --> Final output sent to browser
DEBUG - 2011-08-14 17:56:30 --> Total execution time: 0.0129
DEBUG - 2011-08-14 17:56:35 --> Config Class Initialized
DEBUG - 2011-08-14 17:56:35 --> Hooks Class Initialized
DEBUG - 2011-08-14 17:56:35 --> Utf8 Class Initialized
DEBUG - 2011-08-14 17:56:35 --> UTF-8 Support Enabled
DEBUG - 2011-08-14 17:56:35 --> URI Class Initialized
DEBUG - 2011-08-14 17:56:35 --> Router Class Initialized
DEBUG - 2011-08-14 17:56:35 --> Output Class Initialized
DEBUG - 2011-08-14 17:56:35 --> Input Class Initialized
DEBUG - 2011-08-14 17:56:35 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-14 17:56:35 --> Language Class Initialized
DEBUG - 2011-08-14 17:56:35 --> Loader Class Initialized
DEBUG - 2011-08-14 17:56:35 --> Controller Class Initialized
ERROR - 2011-08-14 17:56:35 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-08-14 17:56:35 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-08-14 17:56:35 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-08-14 17:56:35 --> Model Class Initialized
DEBUG - 2011-08-14 17:56:35 --> Model Class Initialized
DEBUG - 2011-08-14 17:56:35 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-14 17:56:35 --> Database Driver Class Initialized
DEBUG - 2011-08-14 17:56:35 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-08-14 17:56:35 --> Helper loaded: url_helper
DEBUG - 2011-08-14 17:56:35 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-14 17:56:35 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-14 17:56:35 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-14 17:56:35 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-14 17:56:35 --> Final output sent to browser
DEBUG - 2011-08-14 17:56:35 --> Total execution time: 0.0292
DEBUG - 2011-08-14 17:56:35 --> Config Class Initialized
DEBUG - 2011-08-14 17:56:35 --> Hooks Class Initialized
DEBUG - 2011-08-14 17:56:35 --> Utf8 Class Initialized
DEBUG - 2011-08-14 17:56:35 --> UTF-8 Support Enabled
DEBUG - 2011-08-14 17:56:35 --> URI Class Initialized
DEBUG - 2011-08-14 17:56:35 --> Router Class Initialized
ERROR - 2011-08-14 17:56:35 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-08-14 17:56:41 --> Config Class Initialized
DEBUG - 2011-08-14 17:56:41 --> Hooks Class Initialized
DEBUG - 2011-08-14 17:56:41 --> Utf8 Class Initialized
DEBUG - 2011-08-14 17:56:41 --> UTF-8 Support Enabled
DEBUG - 2011-08-14 17:56:41 --> URI Class Initialized
DEBUG - 2011-08-14 17:56:41 --> Router Class Initialized
DEBUG - 2011-08-14 17:56:41 --> Output Class Initialized
DEBUG - 2011-08-14 17:56:41 --> Input Class Initialized
DEBUG - 2011-08-14 17:56:41 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-14 17:56:41 --> Language Class Initialized
DEBUG - 2011-08-14 17:56:41 --> Loader Class Initialized
DEBUG - 2011-08-14 17:56:41 --> Controller Class Initialized
DEBUG - 2011-08-14 17:56:41 --> Model Class Initialized
DEBUG - 2011-08-14 17:56:41 --> Model Class Initialized
DEBUG - 2011-08-14 17:56:41 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-14 17:56:41 --> Database Driver Class Initialized
DEBUG - 2011-08-14 17:56:42 --> Final output sent to browser
DEBUG - 2011-08-14 17:56:42 --> Total execution time: 0.5417
DEBUG - 2011-08-14 17:57:08 --> Config Class Initialized
DEBUG - 2011-08-14 17:57:08 --> Hooks Class Initialized
DEBUG - 2011-08-14 17:57:08 --> Utf8 Class Initialized
DEBUG - 2011-08-14 17:57:08 --> UTF-8 Support Enabled
DEBUG - 2011-08-14 17:57:08 --> URI Class Initialized
DEBUG - 2011-08-14 17:57:08 --> Router Class Initialized
ERROR - 2011-08-14 17:57:08 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-08-14 18:50:35 --> Config Class Initialized
DEBUG - 2011-08-14 18:50:35 --> Hooks Class Initialized
DEBUG - 2011-08-14 18:50:35 --> Utf8 Class Initialized
DEBUG - 2011-08-14 18:50:35 --> UTF-8 Support Enabled
DEBUG - 2011-08-14 18:50:35 --> URI Class Initialized
DEBUG - 2011-08-14 18:50:35 --> Router Class Initialized
DEBUG - 2011-08-14 18:50:35 --> Output Class Initialized
DEBUG - 2011-08-14 18:50:35 --> Input Class Initialized
DEBUG - 2011-08-14 18:50:35 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-14 18:50:35 --> Language Class Initialized
DEBUG - 2011-08-14 18:50:35 --> Loader Class Initialized
DEBUG - 2011-08-14 18:50:35 --> Controller Class Initialized
DEBUG - 2011-08-14 18:50:35 --> Model Class Initialized
DEBUG - 2011-08-14 18:50:35 --> Model Class Initialized
DEBUG - 2011-08-14 18:50:35 --> Model Class Initialized
DEBUG - 2011-08-14 18:50:35 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-14 18:50:35 --> Database Driver Class Initialized
DEBUG - 2011-08-14 18:50:35 --> File loaded: application/views/table/main.php
DEBUG - 2011-08-14 18:50:35 --> Helper loaded: url_helper
DEBUG - 2011-08-14 18:50:35 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-14 18:50:35 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-14 18:50:35 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-14 18:50:35 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-14 18:50:35 --> Final output sent to browser
DEBUG - 2011-08-14 18:50:35 --> Total execution time: 0.2756
DEBUG - 2011-08-14 19:04:13 --> Config Class Initialized
DEBUG - 2011-08-14 19:04:13 --> Hooks Class Initialized
DEBUG - 2011-08-14 19:04:13 --> Utf8 Class Initialized
DEBUG - 2011-08-14 19:04:13 --> UTF-8 Support Enabled
DEBUG - 2011-08-14 19:04:13 --> URI Class Initialized
DEBUG - 2011-08-14 19:04:13 --> Router Class Initialized
DEBUG - 2011-08-14 19:04:13 --> No URI present. Default controller set.
DEBUG - 2011-08-14 19:04:13 --> Output Class Initialized
DEBUG - 2011-08-14 19:04:13 --> Input Class Initialized
DEBUG - 2011-08-14 19:04:13 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-14 19:04:13 --> Language Class Initialized
DEBUG - 2011-08-14 19:04:13 --> Loader Class Initialized
DEBUG - 2011-08-14 19:04:13 --> Controller Class Initialized
DEBUG - 2011-08-14 19:04:13 --> File loaded: application/views/splash/main.php
DEBUG - 2011-08-14 19:04:13 --> Helper loaded: url_helper
DEBUG - 2011-08-14 19:04:13 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-14 19:04:13 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-14 19:04:13 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-14 19:04:13 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-14 19:04:13 --> Final output sent to browser
DEBUG - 2011-08-14 19:04:13 --> Total execution time: 0.0254
DEBUG - 2011-08-14 19:40:02 --> Config Class Initialized
DEBUG - 2011-08-14 19:40:02 --> Hooks Class Initialized
DEBUG - 2011-08-14 19:40:02 --> Utf8 Class Initialized
DEBUG - 2011-08-14 19:40:02 --> UTF-8 Support Enabled
DEBUG - 2011-08-14 19:40:02 --> URI Class Initialized
DEBUG - 2011-08-14 19:40:02 --> Router Class Initialized
DEBUG - 2011-08-14 19:40:02 --> Output Class Initialized
DEBUG - 2011-08-14 19:40:02 --> Input Class Initialized
DEBUG - 2011-08-14 19:40:02 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-14 19:40:02 --> Language Class Initialized
DEBUG - 2011-08-14 19:40:02 --> Loader Class Initialized
DEBUG - 2011-08-14 19:40:02 --> Controller Class Initialized
DEBUG - 2011-08-14 19:40:02 --> Model Class Initialized
DEBUG - 2011-08-14 19:40:02 --> Model Class Initialized
DEBUG - 2011-08-14 19:40:02 --> Model Class Initialized
DEBUG - 2011-08-14 19:40:02 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-14 19:40:02 --> Database Driver Class Initialized
DEBUG - 2011-08-14 19:40:04 --> File loaded: application/views/table/main.php
DEBUG - 2011-08-14 19:40:04 --> Helper loaded: url_helper
DEBUG - 2011-08-14 19:40:04 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-14 19:40:04 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-14 19:40:04 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-14 19:40:04 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-14 19:40:04 --> Final output sent to browser
DEBUG - 2011-08-14 19:40:04 --> Total execution time: 1.2627
DEBUG - 2011-08-14 19:40:16 --> Config Class Initialized
DEBUG - 2011-08-14 19:40:16 --> Hooks Class Initialized
DEBUG - 2011-08-14 19:40:16 --> Utf8 Class Initialized
DEBUG - 2011-08-14 19:40:16 --> UTF-8 Support Enabled
DEBUG - 2011-08-14 19:40:16 --> URI Class Initialized
DEBUG - 2011-08-14 19:40:16 --> Router Class Initialized
DEBUG - 2011-08-14 19:40:16 --> Output Class Initialized
DEBUG - 2011-08-14 19:40:16 --> Input Class Initialized
DEBUG - 2011-08-14 19:40:16 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-14 19:40:16 --> Language Class Initialized
DEBUG - 2011-08-14 19:40:16 --> Loader Class Initialized
DEBUG - 2011-08-14 19:40:16 --> Controller Class Initialized
ERROR - 2011-08-14 19:40:16 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-08-14 19:40:16 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-08-14 19:40:16 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-08-14 19:40:16 --> Model Class Initialized
DEBUG - 2011-08-14 19:40:16 --> Model Class Initialized
DEBUG - 2011-08-14 19:40:16 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-14 19:40:16 --> Database Driver Class Initialized
DEBUG - 2011-08-14 19:40:16 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-08-14 19:40:16 --> Helper loaded: url_helper
DEBUG - 2011-08-14 19:40:16 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-14 19:40:16 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-14 19:40:16 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-14 19:40:16 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-14 19:40:16 --> Final output sent to browser
DEBUG - 2011-08-14 19:40:16 --> Total execution time: 0.0344
DEBUG - 2011-08-14 20:10:54 --> Config Class Initialized
DEBUG - 2011-08-14 20:10:54 --> Hooks Class Initialized
DEBUG - 2011-08-14 20:10:54 --> Utf8 Class Initialized
DEBUG - 2011-08-14 20:10:54 --> UTF-8 Support Enabled
DEBUG - 2011-08-14 20:10:54 --> URI Class Initialized
DEBUG - 2011-08-14 20:10:54 --> Router Class Initialized
DEBUG - 2011-08-14 20:10:54 --> Output Class Initialized
DEBUG - 2011-08-14 20:10:54 --> Input Class Initialized
DEBUG - 2011-08-14 20:10:54 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-14 20:10:54 --> Language Class Initialized
DEBUG - 2011-08-14 20:10:54 --> Loader Class Initialized
DEBUG - 2011-08-14 20:10:54 --> Controller Class Initialized
ERROR - 2011-08-14 20:10:54 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-08-14 20:10:54 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-08-14 20:10:54 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-08-14 20:10:54 --> Model Class Initialized
DEBUG - 2011-08-14 20:10:54 --> Model Class Initialized
DEBUG - 2011-08-14 20:10:54 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-14 20:10:54 --> Database Driver Class Initialized
DEBUG - 2011-08-14 20:10:54 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-08-14 20:10:54 --> Helper loaded: url_helper
DEBUG - 2011-08-14 20:10:54 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-14 20:10:54 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-14 20:10:54 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-14 20:10:54 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-14 20:10:54 --> Final output sent to browser
DEBUG - 2011-08-14 20:10:54 --> Total execution time: 0.0293
DEBUG - 2011-08-14 20:10:56 --> Config Class Initialized
DEBUG - 2011-08-14 20:10:56 --> Hooks Class Initialized
DEBUG - 2011-08-14 20:10:56 --> Utf8 Class Initialized
DEBUG - 2011-08-14 20:10:56 --> UTF-8 Support Enabled
DEBUG - 2011-08-14 20:10:56 --> URI Class Initialized
DEBUG - 2011-08-14 20:10:56 --> Router Class Initialized
DEBUG - 2011-08-14 20:10:56 --> Output Class Initialized
DEBUG - 2011-08-14 20:10:56 --> Input Class Initialized
DEBUG - 2011-08-14 20:10:56 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-14 20:10:56 --> Language Class Initialized
DEBUG - 2011-08-14 20:10:56 --> Loader Class Initialized
DEBUG - 2011-08-14 20:10:56 --> Controller Class Initialized
DEBUG - 2011-08-14 20:10:56 --> Model Class Initialized
DEBUG - 2011-08-14 20:10:56 --> Model Class Initialized
DEBUG - 2011-08-14 20:10:56 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-14 20:10:56 --> Database Driver Class Initialized
DEBUG - 2011-08-14 20:10:56 --> Final output sent to browser
DEBUG - 2011-08-14 20:10:56 --> Total execution time: 0.5542
DEBUG - 2011-08-14 20:10:58 --> Config Class Initialized
DEBUG - 2011-08-14 20:10:58 --> Hooks Class Initialized
DEBUG - 2011-08-14 20:10:58 --> Utf8 Class Initialized
DEBUG - 2011-08-14 20:10:58 --> UTF-8 Support Enabled
DEBUG - 2011-08-14 20:10:58 --> URI Class Initialized
DEBUG - 2011-08-14 20:10:58 --> Router Class Initialized
ERROR - 2011-08-14 20:10:58 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-08-14 20:10:59 --> Config Class Initialized
DEBUG - 2011-08-14 20:10:59 --> Hooks Class Initialized
DEBUG - 2011-08-14 20:10:59 --> Utf8 Class Initialized
DEBUG - 2011-08-14 20:10:59 --> UTF-8 Support Enabled
DEBUG - 2011-08-14 20:10:59 --> URI Class Initialized
DEBUG - 2011-08-14 20:10:59 --> Router Class Initialized
ERROR - 2011-08-14 20:10:59 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-08-14 20:55:56 --> Config Class Initialized
DEBUG - 2011-08-14 20:55:56 --> Hooks Class Initialized
DEBUG - 2011-08-14 20:55:56 --> Utf8 Class Initialized
DEBUG - 2011-08-14 20:55:56 --> UTF-8 Support Enabled
DEBUG - 2011-08-14 20:55:56 --> URI Class Initialized
DEBUG - 2011-08-14 20:55:56 --> Router Class Initialized
DEBUG - 2011-08-14 20:55:56 --> No URI present. Default controller set.
DEBUG - 2011-08-14 20:55:56 --> Output Class Initialized
DEBUG - 2011-08-14 20:55:56 --> Input Class Initialized
DEBUG - 2011-08-14 20:55:56 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-14 20:55:56 --> Language Class Initialized
DEBUG - 2011-08-14 20:55:56 --> Loader Class Initialized
DEBUG - 2011-08-14 20:55:56 --> Controller Class Initialized
DEBUG - 2011-08-14 20:55:56 --> File loaded: application/views/splash/main.php
DEBUG - 2011-08-14 20:55:56 --> Helper loaded: url_helper
DEBUG - 2011-08-14 20:55:56 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-14 20:55:56 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-14 20:55:56 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-14 20:55:56 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-14 20:55:56 --> Final output sent to browser
DEBUG - 2011-08-14 20:55:56 --> Total execution time: 0.0943
DEBUG - 2011-08-14 20:55:57 --> Config Class Initialized
DEBUG - 2011-08-14 20:55:57 --> Hooks Class Initialized
DEBUG - 2011-08-14 20:55:57 --> Utf8 Class Initialized
DEBUG - 2011-08-14 20:55:57 --> UTF-8 Support Enabled
DEBUG - 2011-08-14 20:55:57 --> URI Class Initialized
DEBUG - 2011-08-14 20:55:57 --> Router Class Initialized
ERROR - 2011-08-14 20:55:57 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-08-14 22:10:31 --> Config Class Initialized
DEBUG - 2011-08-14 22:10:31 --> Hooks Class Initialized
DEBUG - 2011-08-14 22:10:31 --> Utf8 Class Initialized
DEBUG - 2011-08-14 22:10:31 --> UTF-8 Support Enabled
DEBUG - 2011-08-14 22:10:31 --> URI Class Initialized
DEBUG - 2011-08-14 22:10:31 --> Router Class Initialized
ERROR - 2011-08-14 22:10:31 --> 404 Page Not Found --> robots.txt
DEBUG - 2011-08-14 22:10:31 --> Config Class Initialized
DEBUG - 2011-08-14 22:10:31 --> Hooks Class Initialized
DEBUG - 2011-08-14 22:10:31 --> Utf8 Class Initialized
DEBUG - 2011-08-14 22:10:31 --> UTF-8 Support Enabled
DEBUG - 2011-08-14 22:10:31 --> URI Class Initialized
DEBUG - 2011-08-14 22:10:31 --> Router Class Initialized
DEBUG - 2011-08-14 22:10:31 --> No URI present. Default controller set.
DEBUG - 2011-08-14 22:10:31 --> Output Class Initialized
DEBUG - 2011-08-14 22:10:31 --> Input Class Initialized
DEBUG - 2011-08-14 22:10:31 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-14 22:10:31 --> Language Class Initialized
DEBUG - 2011-08-14 22:10:31 --> Loader Class Initialized
DEBUG - 2011-08-14 22:10:31 --> Controller Class Initialized
DEBUG - 2011-08-14 22:10:31 --> File loaded: application/views/splash/main.php
DEBUG - 2011-08-14 22:10:31 --> Helper loaded: url_helper
DEBUG - 2011-08-14 22:10:31 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-14 22:10:31 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-14 22:10:31 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-14 22:10:31 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-14 22:10:31 --> Final output sent to browser
DEBUG - 2011-08-14 22:10:31 --> Total execution time: 0.0660
DEBUG - 2011-08-14 22:10:52 --> Config Class Initialized
DEBUG - 2011-08-14 22:10:52 --> Hooks Class Initialized
DEBUG - 2011-08-14 22:10:52 --> Utf8 Class Initialized
DEBUG - 2011-08-14 22:10:52 --> UTF-8 Support Enabled
DEBUG - 2011-08-14 22:10:52 --> URI Class Initialized
DEBUG - 2011-08-14 22:10:52 --> Router Class Initialized
DEBUG - 2011-08-14 22:10:52 --> Output Class Initialized
DEBUG - 2011-08-14 22:10:52 --> Input Class Initialized
DEBUG - 2011-08-14 22:10:52 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-14 22:10:52 --> Language Class Initialized
DEBUG - 2011-08-14 22:10:52 --> Loader Class Initialized
DEBUG - 2011-08-14 22:10:52 --> Controller Class Initialized
DEBUG - 2011-08-14 22:10:52 --> Model Class Initialized
DEBUG - 2011-08-14 22:10:52 --> Model Class Initialized
DEBUG - 2011-08-14 22:10:52 --> Model Class Initialized
DEBUG - 2011-08-14 22:10:52 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-14 22:10:52 --> Database Driver Class Initialized
DEBUG - 2011-08-14 22:10:52 --> File loaded: application/views/table/main.php
DEBUG - 2011-08-14 22:10:52 --> Helper loaded: url_helper
DEBUG - 2011-08-14 22:10:52 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-14 22:10:52 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-14 22:10:52 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-14 22:10:52 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-14 22:10:52 --> Final output sent to browser
DEBUG - 2011-08-14 22:10:52 --> Total execution time: 0.2757
DEBUG - 2011-08-14 22:11:36 --> Config Class Initialized
DEBUG - 2011-08-14 22:11:36 --> Hooks Class Initialized
DEBUG - 2011-08-14 22:11:36 --> Utf8 Class Initialized
DEBUG - 2011-08-14 22:11:36 --> UTF-8 Support Enabled
DEBUG - 2011-08-14 22:11:36 --> URI Class Initialized
DEBUG - 2011-08-14 22:11:36 --> Router Class Initialized
ERROR - 2011-08-14 22:11:36 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-08-14 22:11:38 --> Config Class Initialized
DEBUG - 2011-08-14 22:11:38 --> Hooks Class Initialized
DEBUG - 2011-08-14 22:11:38 --> Utf8 Class Initialized
DEBUG - 2011-08-14 22:11:38 --> UTF-8 Support Enabled
DEBUG - 2011-08-14 22:11:38 --> URI Class Initialized
DEBUG - 2011-08-14 22:11:38 --> Router Class Initialized
ERROR - 2011-08-14 22:11:38 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-08-14 22:13:23 --> Config Class Initialized
DEBUG - 2011-08-14 22:13:23 --> Hooks Class Initialized
DEBUG - 2011-08-14 22:13:23 --> Utf8 Class Initialized
DEBUG - 2011-08-14 22:13:23 --> UTF-8 Support Enabled
DEBUG - 2011-08-14 22:13:23 --> URI Class Initialized
DEBUG - 2011-08-14 22:13:23 --> Router Class Initialized
DEBUG - 2011-08-14 22:13:23 --> Output Class Initialized
DEBUG - 2011-08-14 22:13:23 --> Input Class Initialized
DEBUG - 2011-08-14 22:13:23 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-14 22:13:23 --> Language Class Initialized
DEBUG - 2011-08-14 22:13:23 --> Loader Class Initialized
DEBUG - 2011-08-14 22:13:23 --> Controller Class Initialized
ERROR - 2011-08-14 22:13:23 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-08-14 22:13:23 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-08-14 22:13:23 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-08-14 22:13:23 --> Model Class Initialized
DEBUG - 2011-08-14 22:13:23 --> Model Class Initialized
DEBUG - 2011-08-14 22:13:23 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-14 22:13:23 --> Database Driver Class Initialized
DEBUG - 2011-08-14 22:13:23 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-08-14 22:13:23 --> Helper loaded: url_helper
DEBUG - 2011-08-14 22:13:23 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-14 22:13:23 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-14 22:13:23 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-14 22:13:23 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-14 22:13:23 --> Final output sent to browser
DEBUG - 2011-08-14 22:13:23 --> Total execution time: 0.0456
DEBUG - 2011-08-14 22:13:24 --> Config Class Initialized
DEBUG - 2011-08-14 22:13:24 --> Hooks Class Initialized
DEBUG - 2011-08-14 22:13:24 --> Utf8 Class Initialized
DEBUG - 2011-08-14 22:13:24 --> UTF-8 Support Enabled
DEBUG - 2011-08-14 22:13:24 --> URI Class Initialized
DEBUG - 2011-08-14 22:13:24 --> Router Class Initialized
DEBUG - 2011-08-14 22:13:24 --> Output Class Initialized
DEBUG - 2011-08-14 22:13:24 --> Input Class Initialized
DEBUG - 2011-08-14 22:13:24 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-14 22:13:24 --> Language Class Initialized
DEBUG - 2011-08-14 22:13:24 --> Loader Class Initialized
DEBUG - 2011-08-14 22:13:24 --> Controller Class Initialized
DEBUG - 2011-08-14 22:13:24 --> Model Class Initialized
DEBUG - 2011-08-14 22:13:24 --> Model Class Initialized
DEBUG - 2011-08-14 22:13:24 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-14 22:13:24 --> Database Driver Class Initialized
DEBUG - 2011-08-14 22:13:24 --> Final output sent to browser
DEBUG - 2011-08-14 22:13:24 --> Total execution time: 0.5370
DEBUG - 2011-08-14 22:58:23 --> Config Class Initialized
DEBUG - 2011-08-14 22:58:23 --> Hooks Class Initialized
DEBUG - 2011-08-14 22:58:23 --> Utf8 Class Initialized
DEBUG - 2011-08-14 22:58:23 --> UTF-8 Support Enabled
DEBUG - 2011-08-14 22:58:23 --> URI Class Initialized
DEBUG - 2011-08-14 22:58:23 --> Router Class Initialized
ERROR - 2011-08-14 22:58:23 --> 404 Page Not Found --> robots.txt
DEBUG - 2011-08-14 23:29:03 --> Config Class Initialized
DEBUG - 2011-08-14 23:29:03 --> Hooks Class Initialized
DEBUG - 2011-08-14 23:29:03 --> Utf8 Class Initialized
DEBUG - 2011-08-14 23:29:03 --> UTF-8 Support Enabled
DEBUG - 2011-08-14 23:29:03 --> URI Class Initialized
DEBUG - 2011-08-14 23:29:03 --> Router Class Initialized
ERROR - 2011-08-14 23:29:03 --> 404 Page Not Found --> robots.txt
DEBUG - 2011-08-14 23:29:06 --> Config Class Initialized
DEBUG - 2011-08-14 23:29:06 --> Hooks Class Initialized
DEBUG - 2011-08-14 23:29:06 --> Utf8 Class Initialized
DEBUG - 2011-08-14 23:29:06 --> UTF-8 Support Enabled
DEBUG - 2011-08-14 23:29:06 --> URI Class Initialized
DEBUG - 2011-08-14 23:29:06 --> Router Class Initialized
DEBUG - 2011-08-14 23:29:06 --> Output Class Initialized
DEBUG - 2011-08-14 23:29:06 --> Input Class Initialized
DEBUG - 2011-08-14 23:29:06 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-14 23:29:06 --> Language Class Initialized
DEBUG - 2011-08-14 23:29:06 --> Loader Class Initialized
DEBUG - 2011-08-14 23:29:06 --> Controller Class Initialized
ERROR - 2011-08-14 23:29:06 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-08-14 23:29:06 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-08-14 23:29:06 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-08-14 23:29:06 --> Model Class Initialized
DEBUG - 2011-08-14 23:29:06 --> Model Class Initialized
DEBUG - 2011-08-14 23:29:06 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-14 23:29:06 --> Database Driver Class Initialized
DEBUG - 2011-08-14 23:29:06 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-08-14 23:29:06 --> Helper loaded: url_helper
DEBUG - 2011-08-14 23:29:06 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-14 23:29:06 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-14 23:29:06 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-14 23:29:06 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-14 23:29:06 --> Final output sent to browser
DEBUG - 2011-08-14 23:29:06 --> Total execution time: 0.0407
DEBUG - 2011-08-14 23:29:07 --> Config Class Initialized
DEBUG - 2011-08-14 23:29:07 --> Hooks Class Initialized
DEBUG - 2011-08-14 23:29:07 --> Utf8 Class Initialized
DEBUG - 2011-08-14 23:29:07 --> UTF-8 Support Enabled
DEBUG - 2011-08-14 23:29:07 --> URI Class Initialized
DEBUG - 2011-08-14 23:29:07 --> Router Class Initialized
DEBUG - 2011-08-14 23:29:07 --> Output Class Initialized
DEBUG - 2011-08-14 23:29:07 --> Input Class Initialized
DEBUG - 2011-08-14 23:29:07 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-14 23:29:07 --> Language Class Initialized
DEBUG - 2011-08-14 23:29:07 --> Loader Class Initialized
DEBUG - 2011-08-14 23:29:07 --> Controller Class Initialized
DEBUG - 2011-08-14 23:29:07 --> Model Class Initialized
DEBUG - 2011-08-14 23:29:07 --> Model Class Initialized
DEBUG - 2011-08-14 23:29:07 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-14 23:29:07 --> Database Driver Class Initialized
DEBUG - 2011-08-14 23:29:08 --> Final output sent to browser
DEBUG - 2011-08-14 23:29:08 --> Total execution time: 0.6372
DEBUG - 2011-08-14 23:29:10 --> Config Class Initialized
DEBUG - 2011-08-14 23:29:10 --> Hooks Class Initialized
DEBUG - 2011-08-14 23:29:10 --> Utf8 Class Initialized
DEBUG - 2011-08-14 23:29:10 --> UTF-8 Support Enabled
DEBUG - 2011-08-14 23:29:10 --> URI Class Initialized
DEBUG - 2011-08-14 23:29:10 --> Router Class Initialized
ERROR - 2011-08-14 23:29:10 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-08-14 23:29:48 --> Config Class Initialized
DEBUG - 2011-08-14 23:29:48 --> Hooks Class Initialized
DEBUG - 2011-08-14 23:29:48 --> Utf8 Class Initialized
DEBUG - 2011-08-14 23:29:48 --> UTF-8 Support Enabled
DEBUG - 2011-08-14 23:29:48 --> URI Class Initialized
DEBUG - 2011-08-14 23:29:48 --> Router Class Initialized
DEBUG - 2011-08-14 23:29:48 --> Output Class Initialized
DEBUG - 2011-08-14 23:29:48 --> Input Class Initialized
DEBUG - 2011-08-14 23:29:48 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-14 23:29:48 --> Language Class Initialized
DEBUG - 2011-08-14 23:29:48 --> Loader Class Initialized
DEBUG - 2011-08-14 23:29:48 --> Controller Class Initialized
ERROR - 2011-08-14 23:29:48 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-08-14 23:29:48 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-08-14 23:29:48 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-08-14 23:29:48 --> Model Class Initialized
DEBUG - 2011-08-14 23:29:48 --> Model Class Initialized
DEBUG - 2011-08-14 23:29:48 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-14 23:29:48 --> Database Driver Class Initialized
DEBUG - 2011-08-14 23:29:48 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-08-14 23:29:48 --> Helper loaded: url_helper
DEBUG - 2011-08-14 23:29:48 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-14 23:29:48 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-14 23:29:48 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-14 23:29:48 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-14 23:29:48 --> Final output sent to browser
DEBUG - 2011-08-14 23:29:48 --> Total execution time: 0.0376
DEBUG - 2011-08-14 23:29:48 --> Config Class Initialized
DEBUG - 2011-08-14 23:29:48 --> Hooks Class Initialized
DEBUG - 2011-08-14 23:29:48 --> Utf8 Class Initialized
DEBUG - 2011-08-14 23:29:48 --> UTF-8 Support Enabled
DEBUG - 2011-08-14 23:29:48 --> URI Class Initialized
DEBUG - 2011-08-14 23:29:48 --> Router Class Initialized
DEBUG - 2011-08-14 23:29:48 --> Output Class Initialized
DEBUG - 2011-08-14 23:29:48 --> Input Class Initialized
DEBUG - 2011-08-14 23:29:48 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-14 23:29:48 --> Language Class Initialized
DEBUG - 2011-08-14 23:29:48 --> Loader Class Initialized
DEBUG - 2011-08-14 23:29:48 --> Controller Class Initialized
DEBUG - 2011-08-14 23:29:48 --> Model Class Initialized
DEBUG - 2011-08-14 23:29:48 --> Model Class Initialized
DEBUG - 2011-08-14 23:29:48 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-14 23:29:48 --> Database Driver Class Initialized
DEBUG - 2011-08-14 23:29:49 --> Final output sent to browser
DEBUG - 2011-08-14 23:29:49 --> Total execution time: 0.5520
DEBUG - 2011-08-14 23:29:57 --> Config Class Initialized
DEBUG - 2011-08-14 23:29:57 --> Hooks Class Initialized
DEBUG - 2011-08-14 23:29:57 --> Utf8 Class Initialized
DEBUG - 2011-08-14 23:29:57 --> UTF-8 Support Enabled
DEBUG - 2011-08-14 23:29:57 --> URI Class Initialized
DEBUG - 2011-08-14 23:29:57 --> Router Class Initialized
DEBUG - 2011-08-14 23:29:57 --> Output Class Initialized
DEBUG - 2011-08-14 23:29:57 --> Input Class Initialized
DEBUG - 2011-08-14 23:29:57 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-14 23:29:57 --> Language Class Initialized
DEBUG - 2011-08-14 23:29:57 --> Loader Class Initialized
DEBUG - 2011-08-14 23:29:57 --> Controller Class Initialized
ERROR - 2011-08-14 23:29:57 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-08-14 23:29:57 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-08-14 23:29:57 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-08-14 23:29:57 --> Model Class Initialized
DEBUG - 2011-08-14 23:29:57 --> Model Class Initialized
DEBUG - 2011-08-14 23:29:57 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-14 23:29:57 --> Database Driver Class Initialized
DEBUG - 2011-08-14 23:29:57 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-08-14 23:29:57 --> Helper loaded: url_helper
DEBUG - 2011-08-14 23:29:57 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-14 23:29:57 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-14 23:29:57 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-14 23:29:57 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-14 23:29:57 --> Final output sent to browser
DEBUG - 2011-08-14 23:29:57 --> Total execution time: 0.0962
DEBUG - 2011-08-14 23:29:57 --> Config Class Initialized
DEBUG - 2011-08-14 23:29:57 --> Hooks Class Initialized
DEBUG - 2011-08-14 23:29:57 --> Utf8 Class Initialized
DEBUG - 2011-08-14 23:29:57 --> UTF-8 Support Enabled
DEBUG - 2011-08-14 23:29:57 --> URI Class Initialized
DEBUG - 2011-08-14 23:29:57 --> Router Class Initialized
DEBUG - 2011-08-14 23:29:57 --> Output Class Initialized
DEBUG - 2011-08-14 23:29:57 --> Input Class Initialized
DEBUG - 2011-08-14 23:29:57 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-14 23:29:57 --> Language Class Initialized
DEBUG - 2011-08-14 23:29:57 --> Loader Class Initialized
DEBUG - 2011-08-14 23:29:57 --> Controller Class Initialized
DEBUG - 2011-08-14 23:29:57 --> Model Class Initialized
DEBUG - 2011-08-14 23:29:57 --> Model Class Initialized
DEBUG - 2011-08-14 23:29:57 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-14 23:29:57 --> Database Driver Class Initialized
DEBUG - 2011-08-14 23:29:58 --> Final output sent to browser
DEBUG - 2011-08-14 23:29:58 --> Total execution time: 0.5697
DEBUG - 2011-08-14 23:30:05 --> Config Class Initialized
DEBUG - 2011-08-14 23:30:05 --> Hooks Class Initialized
DEBUG - 2011-08-14 23:30:05 --> Utf8 Class Initialized
DEBUG - 2011-08-14 23:30:05 --> UTF-8 Support Enabled
DEBUG - 2011-08-14 23:30:05 --> URI Class Initialized
DEBUG - 2011-08-14 23:30:05 --> Router Class Initialized
DEBUG - 2011-08-14 23:30:05 --> Output Class Initialized
DEBUG - 2011-08-14 23:30:05 --> Input Class Initialized
DEBUG - 2011-08-14 23:30:05 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-14 23:30:05 --> Language Class Initialized
DEBUG - 2011-08-14 23:30:05 --> Loader Class Initialized
DEBUG - 2011-08-14 23:30:05 --> Controller Class Initialized
ERROR - 2011-08-14 23:30:05 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-08-14 23:30:05 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-08-14 23:30:05 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-08-14 23:30:05 --> Model Class Initialized
DEBUG - 2011-08-14 23:30:05 --> Model Class Initialized
DEBUG - 2011-08-14 23:30:05 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-14 23:30:05 --> Database Driver Class Initialized
DEBUG - 2011-08-14 23:30:05 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-08-14 23:30:05 --> Helper loaded: url_helper
DEBUG - 2011-08-14 23:30:05 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-14 23:30:05 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-14 23:30:05 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-14 23:30:05 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-14 23:30:05 --> Final output sent to browser
DEBUG - 2011-08-14 23:30:05 --> Total execution time: 0.0672
DEBUG - 2011-08-14 23:30:07 --> Config Class Initialized
DEBUG - 2011-08-14 23:30:07 --> Hooks Class Initialized
DEBUG - 2011-08-14 23:30:07 --> Utf8 Class Initialized
DEBUG - 2011-08-14 23:30:07 --> UTF-8 Support Enabled
DEBUG - 2011-08-14 23:30:07 --> URI Class Initialized
DEBUG - 2011-08-14 23:30:07 --> Router Class Initialized
DEBUG - 2011-08-14 23:30:07 --> Output Class Initialized
DEBUG - 2011-08-14 23:30:07 --> Input Class Initialized
DEBUG - 2011-08-14 23:30:07 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-14 23:30:07 --> Language Class Initialized
DEBUG - 2011-08-14 23:30:07 --> Loader Class Initialized
DEBUG - 2011-08-14 23:30:07 --> Controller Class Initialized
DEBUG - 2011-08-14 23:30:07 --> Model Class Initialized
DEBUG - 2011-08-14 23:30:07 --> Model Class Initialized
DEBUG - 2011-08-14 23:30:07 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-14 23:30:07 --> Database Driver Class Initialized
DEBUG - 2011-08-14 23:30:07 --> Final output sent to browser
DEBUG - 2011-08-14 23:30:07 --> Total execution time: 0.4984
DEBUG - 2011-08-14 23:30:18 --> Config Class Initialized
DEBUG - 2011-08-14 23:30:18 --> Hooks Class Initialized
DEBUG - 2011-08-14 23:30:18 --> Utf8 Class Initialized
DEBUG - 2011-08-14 23:30:18 --> UTF-8 Support Enabled
DEBUG - 2011-08-14 23:30:18 --> URI Class Initialized
DEBUG - 2011-08-14 23:30:18 --> Router Class Initialized
DEBUG - 2011-08-14 23:30:18 --> Output Class Initialized
DEBUG - 2011-08-14 23:30:18 --> Input Class Initialized
DEBUG - 2011-08-14 23:30:18 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-14 23:30:18 --> Language Class Initialized
DEBUG - 2011-08-14 23:30:18 --> Loader Class Initialized
DEBUG - 2011-08-14 23:30:18 --> Controller Class Initialized
ERROR - 2011-08-14 23:30:18 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-08-14 23:30:18 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-08-14 23:30:18 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-08-14 23:30:18 --> Model Class Initialized
DEBUG - 2011-08-14 23:30:18 --> Model Class Initialized
DEBUG - 2011-08-14 23:30:18 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-14 23:30:18 --> Database Driver Class Initialized
DEBUG - 2011-08-14 23:30:18 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-08-14 23:30:18 --> Helper loaded: url_helper
DEBUG - 2011-08-14 23:30:18 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-14 23:30:18 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-14 23:30:18 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-14 23:30:18 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-14 23:30:18 --> Final output sent to browser
DEBUG - 2011-08-14 23:30:18 --> Total execution time: 0.0304
DEBUG - 2011-08-14 23:30:19 --> Config Class Initialized
DEBUG - 2011-08-14 23:30:19 --> Hooks Class Initialized
DEBUG - 2011-08-14 23:30:19 --> Utf8 Class Initialized
DEBUG - 2011-08-14 23:30:19 --> UTF-8 Support Enabled
DEBUG - 2011-08-14 23:30:19 --> URI Class Initialized
DEBUG - 2011-08-14 23:30:19 --> Router Class Initialized
DEBUG - 2011-08-14 23:30:19 --> Output Class Initialized
DEBUG - 2011-08-14 23:30:19 --> Input Class Initialized
DEBUG - 2011-08-14 23:30:19 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-14 23:30:19 --> Language Class Initialized
DEBUG - 2011-08-14 23:30:19 --> Loader Class Initialized
DEBUG - 2011-08-14 23:30:19 --> Controller Class Initialized
DEBUG - 2011-08-14 23:30:19 --> Model Class Initialized
DEBUG - 2011-08-14 23:30:19 --> Model Class Initialized
DEBUG - 2011-08-14 23:30:19 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-14 23:30:19 --> Database Driver Class Initialized
DEBUG - 2011-08-14 23:30:19 --> Final output sent to browser
DEBUG - 2011-08-14 23:30:19 --> Total execution time: 0.6452
DEBUG - 2011-08-14 23:30:24 --> Config Class Initialized
DEBUG - 2011-08-14 23:30:24 --> Hooks Class Initialized
DEBUG - 2011-08-14 23:30:24 --> Utf8 Class Initialized
DEBUG - 2011-08-14 23:30:24 --> UTF-8 Support Enabled
DEBUG - 2011-08-14 23:30:24 --> URI Class Initialized
DEBUG - 2011-08-14 23:30:24 --> Router Class Initialized
DEBUG - 2011-08-14 23:30:24 --> Output Class Initialized
DEBUG - 2011-08-14 23:30:24 --> Input Class Initialized
DEBUG - 2011-08-14 23:30:24 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-14 23:30:24 --> Language Class Initialized
DEBUG - 2011-08-14 23:30:24 --> Loader Class Initialized
DEBUG - 2011-08-14 23:30:24 --> Controller Class Initialized
ERROR - 2011-08-14 23:30:24 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-08-14 23:30:24 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-08-14 23:30:24 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-08-14 23:30:24 --> Model Class Initialized
DEBUG - 2011-08-14 23:30:24 --> Model Class Initialized
DEBUG - 2011-08-14 23:30:24 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-14 23:30:24 --> Database Driver Class Initialized
DEBUG - 2011-08-14 23:30:24 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-08-14 23:30:24 --> Helper loaded: url_helper
DEBUG - 2011-08-14 23:30:24 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-14 23:30:24 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-14 23:30:24 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-14 23:30:24 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-14 23:30:24 --> Final output sent to browser
DEBUG - 2011-08-14 23:30:24 --> Total execution time: 0.0284
DEBUG - 2011-08-14 23:30:25 --> Config Class Initialized
DEBUG - 2011-08-14 23:30:25 --> Hooks Class Initialized
DEBUG - 2011-08-14 23:30:25 --> Utf8 Class Initialized
DEBUG - 2011-08-14 23:30:25 --> UTF-8 Support Enabled
DEBUG - 2011-08-14 23:30:25 --> URI Class Initialized
DEBUG - 2011-08-14 23:30:25 --> Router Class Initialized
DEBUG - 2011-08-14 23:30:25 --> Output Class Initialized
DEBUG - 2011-08-14 23:30:25 --> Input Class Initialized
DEBUG - 2011-08-14 23:30:25 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-14 23:30:25 --> Language Class Initialized
DEBUG - 2011-08-14 23:30:25 --> Loader Class Initialized
DEBUG - 2011-08-14 23:30:25 --> Controller Class Initialized
DEBUG - 2011-08-14 23:30:25 --> Model Class Initialized
DEBUG - 2011-08-14 23:30:25 --> Model Class Initialized
DEBUG - 2011-08-14 23:30:25 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-14 23:30:25 --> Database Driver Class Initialized
DEBUG - 2011-08-14 23:30:26 --> Final output sent to browser
DEBUG - 2011-08-14 23:30:26 --> Total execution time: 0.5117
DEBUG - 2011-08-14 23:30:30 --> Config Class Initialized
DEBUG - 2011-08-14 23:30:30 --> Hooks Class Initialized
DEBUG - 2011-08-14 23:30:30 --> Utf8 Class Initialized
DEBUG - 2011-08-14 23:30:30 --> UTF-8 Support Enabled
DEBUG - 2011-08-14 23:30:30 --> URI Class Initialized
DEBUG - 2011-08-14 23:30:30 --> Router Class Initialized
DEBUG - 2011-08-14 23:30:30 --> Output Class Initialized
DEBUG - 2011-08-14 23:30:30 --> Input Class Initialized
DEBUG - 2011-08-14 23:30:30 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-14 23:30:30 --> Language Class Initialized
DEBUG - 2011-08-14 23:30:30 --> Loader Class Initialized
DEBUG - 2011-08-14 23:30:30 --> Controller Class Initialized
DEBUG - 2011-08-14 23:30:30 --> Model Class Initialized
DEBUG - 2011-08-14 23:30:30 --> Model Class Initialized
DEBUG - 2011-08-14 23:30:30 --> Model Class Initialized
DEBUG - 2011-08-14 23:30:30 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-14 23:30:31 --> Database Driver Class Initialized
DEBUG - 2011-08-14 23:30:31 --> File loaded: application/views/table/main.php
DEBUG - 2011-08-14 23:30:31 --> Helper loaded: url_helper
DEBUG - 2011-08-14 23:30:31 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-14 23:30:31 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-14 23:30:31 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-14 23:30:31 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-14 23:30:31 --> Final output sent to browser
DEBUG - 2011-08-14 23:30:31 --> Total execution time: 0.2579
DEBUG - 2011-08-14 23:48:06 --> Config Class Initialized
DEBUG - 2011-08-14 23:48:06 --> Hooks Class Initialized
DEBUG - 2011-08-14 23:48:06 --> Utf8 Class Initialized
DEBUG - 2011-08-14 23:48:06 --> UTF-8 Support Enabled
DEBUG - 2011-08-14 23:48:06 --> URI Class Initialized
DEBUG - 2011-08-14 23:48:06 --> Router Class Initialized
DEBUG - 2011-08-14 23:48:06 --> Output Class Initialized
DEBUG - 2011-08-14 23:48:06 --> Input Class Initialized
DEBUG - 2011-08-14 23:48:06 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-14 23:48:06 --> Language Class Initialized
DEBUG - 2011-08-14 23:48:06 --> Loader Class Initialized
DEBUG - 2011-08-14 23:48:06 --> Controller Class Initialized
DEBUG - 2011-08-14 23:48:06 --> Model Class Initialized
DEBUG - 2011-08-14 23:48:06 --> Model Class Initialized
DEBUG - 2011-08-14 23:48:06 --> Model Class Initialized
DEBUG - 2011-08-14 23:48:06 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-14 23:48:06 --> Database Driver Class Initialized
DEBUG - 2011-08-14 23:48:06 --> File loaded: application/views/table/main.php
DEBUG - 2011-08-14 23:48:06 --> Helper loaded: url_helper
DEBUG - 2011-08-14 23:48:06 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-14 23:48:06 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-14 23:48:06 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-14 23:48:06 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-14 23:48:06 --> Final output sent to browser
DEBUG - 2011-08-14 23:48:06 --> Total execution time: 0.0437
DEBUG - 2011-08-14 23:48:08 --> Config Class Initialized
DEBUG - 2011-08-14 23:48:08 --> Hooks Class Initialized
DEBUG - 2011-08-14 23:48:08 --> Utf8 Class Initialized
DEBUG - 2011-08-14 23:48:08 --> UTF-8 Support Enabled
DEBUG - 2011-08-14 23:48:08 --> URI Class Initialized
DEBUG - 2011-08-14 23:48:08 --> Router Class Initialized
ERROR - 2011-08-14 23:48:08 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-08-14 23:48:10 --> Config Class Initialized
DEBUG - 2011-08-14 23:48:10 --> Hooks Class Initialized
DEBUG - 2011-08-14 23:48:10 --> Utf8 Class Initialized
DEBUG - 2011-08-14 23:48:10 --> UTF-8 Support Enabled
DEBUG - 2011-08-14 23:48:10 --> URI Class Initialized
DEBUG - 2011-08-14 23:48:10 --> Router Class Initialized
ERROR - 2011-08-14 23:48:10 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-08-14 23:48:20 --> Config Class Initialized
DEBUG - 2011-08-14 23:48:20 --> Hooks Class Initialized
DEBUG - 2011-08-14 23:48:20 --> Utf8 Class Initialized
DEBUG - 2011-08-14 23:48:20 --> UTF-8 Support Enabled
DEBUG - 2011-08-14 23:48:20 --> URI Class Initialized
DEBUG - 2011-08-14 23:48:20 --> Router Class Initialized
DEBUG - 2011-08-14 23:48:20 --> Output Class Initialized
DEBUG - 2011-08-14 23:48:20 --> Input Class Initialized
DEBUG - 2011-08-14 23:48:20 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-14 23:48:20 --> Language Class Initialized
DEBUG - 2011-08-14 23:48:20 --> Loader Class Initialized
DEBUG - 2011-08-14 23:48:20 --> Controller Class Initialized
DEBUG - 2011-08-14 23:48:20 --> Model Class Initialized
DEBUG - 2011-08-14 23:48:20 --> Model Class Initialized
DEBUG - 2011-08-14 23:48:20 --> Model Class Initialized
DEBUG - 2011-08-14 23:48:20 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-14 23:48:20 --> Database Driver Class Initialized
DEBUG - 2011-08-14 23:48:20 --> File loaded: application/views/table/main.php
DEBUG - 2011-08-14 23:48:20 --> Helper loaded: url_helper
DEBUG - 2011-08-14 23:48:20 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-14 23:48:20 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-14 23:48:20 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-14 23:48:20 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-14 23:48:20 --> Final output sent to browser
DEBUG - 2011-08-14 23:48:20 --> Total execution time: 0.3068
DEBUG - 2011-08-14 23:48:41 --> Config Class Initialized
DEBUG - 2011-08-14 23:48:41 --> Hooks Class Initialized
DEBUG - 2011-08-14 23:48:41 --> Utf8 Class Initialized
DEBUG - 2011-08-14 23:48:41 --> UTF-8 Support Enabled
DEBUG - 2011-08-14 23:48:41 --> URI Class Initialized
DEBUG - 2011-08-14 23:48:41 --> Router Class Initialized
DEBUG - 2011-08-14 23:48:41 --> Output Class Initialized
DEBUG - 2011-08-14 23:48:41 --> Input Class Initialized
DEBUG - 2011-08-14 23:48:41 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-14 23:48:41 --> Language Class Initialized
DEBUG - 2011-08-14 23:48:41 --> Loader Class Initialized
DEBUG - 2011-08-14 23:48:41 --> Controller Class Initialized
DEBUG - 2011-08-14 23:48:41 --> Model Class Initialized
DEBUG - 2011-08-14 23:48:41 --> Model Class Initialized
DEBUG - 2011-08-14 23:48:41 --> Model Class Initialized
DEBUG - 2011-08-14 23:48:41 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-14 23:48:41 --> Database Driver Class Initialized
DEBUG - 2011-08-14 23:48:41 --> File loaded: application/views/table/main.php
DEBUG - 2011-08-14 23:48:41 --> Helper loaded: url_helper
DEBUG - 2011-08-14 23:48:41 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-14 23:48:41 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-14 23:48:41 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-14 23:48:41 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-14 23:48:41 --> Final output sent to browser
DEBUG - 2011-08-14 23:48:41 --> Total execution time: 0.2036
DEBUG - 2011-08-14 23:48:49 --> Config Class Initialized
DEBUG - 2011-08-14 23:48:49 --> Hooks Class Initialized
DEBUG - 2011-08-14 23:48:49 --> Utf8 Class Initialized
DEBUG - 2011-08-14 23:48:49 --> UTF-8 Support Enabled
DEBUG - 2011-08-14 23:48:49 --> URI Class Initialized
DEBUG - 2011-08-14 23:48:49 --> Router Class Initialized
DEBUG - 2011-08-14 23:48:49 --> Output Class Initialized
DEBUG - 2011-08-14 23:48:49 --> Input Class Initialized
DEBUG - 2011-08-14 23:48:49 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-14 23:48:49 --> Language Class Initialized
DEBUG - 2011-08-14 23:48:49 --> Loader Class Initialized
DEBUG - 2011-08-14 23:48:49 --> Controller Class Initialized
DEBUG - 2011-08-14 23:48:49 --> Model Class Initialized
DEBUG - 2011-08-14 23:48:49 --> Model Class Initialized
DEBUG - 2011-08-14 23:48:49 --> Model Class Initialized
DEBUG - 2011-08-14 23:48:49 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-14 23:48:49 --> Database Driver Class Initialized
DEBUG - 2011-08-14 23:48:49 --> File loaded: application/views/table/main.php
DEBUG - 2011-08-14 23:48:49 --> Helper loaded: url_helper
DEBUG - 2011-08-14 23:48:49 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-14 23:48:49 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-14 23:48:49 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-14 23:48:49 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-14 23:48:49 --> Final output sent to browser
DEBUG - 2011-08-14 23:48:49 --> Total execution time: 0.2097
DEBUG - 2011-08-14 23:48:51 --> Config Class Initialized
DEBUG - 2011-08-14 23:48:51 --> Hooks Class Initialized
DEBUG - 2011-08-14 23:48:51 --> Utf8 Class Initialized
DEBUG - 2011-08-14 23:48:51 --> UTF-8 Support Enabled
DEBUG - 2011-08-14 23:48:51 --> URI Class Initialized
DEBUG - 2011-08-14 23:48:51 --> Router Class Initialized
DEBUG - 2011-08-14 23:48:51 --> Output Class Initialized
DEBUG - 2011-08-14 23:48:51 --> Input Class Initialized
DEBUG - 2011-08-14 23:48:51 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-14 23:48:51 --> Language Class Initialized
DEBUG - 2011-08-14 23:48:51 --> Loader Class Initialized
DEBUG - 2011-08-14 23:48:51 --> Controller Class Initialized
DEBUG - 2011-08-14 23:48:51 --> Model Class Initialized
DEBUG - 2011-08-14 23:48:51 --> Model Class Initialized
DEBUG - 2011-08-14 23:48:51 --> Model Class Initialized
DEBUG - 2011-08-14 23:48:51 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-14 23:48:51 --> Database Driver Class Initialized
DEBUG - 2011-08-14 23:48:51 --> File loaded: application/views/table/main.php
DEBUG - 2011-08-14 23:48:51 --> Helper loaded: url_helper
DEBUG - 2011-08-14 23:48:51 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-14 23:48:51 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-14 23:48:51 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-14 23:48:51 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-14 23:48:51 --> Final output sent to browser
DEBUG - 2011-08-14 23:48:51 --> Total execution time: 0.0433
DEBUG - 2011-08-14 23:49:02 --> Config Class Initialized
DEBUG - 2011-08-14 23:49:02 --> Hooks Class Initialized
DEBUG - 2011-08-14 23:49:02 --> Utf8 Class Initialized
DEBUG - 2011-08-14 23:49:02 --> UTF-8 Support Enabled
DEBUG - 2011-08-14 23:49:02 --> URI Class Initialized
DEBUG - 2011-08-14 23:49:02 --> Router Class Initialized
DEBUG - 2011-08-14 23:49:02 --> Output Class Initialized
DEBUG - 2011-08-14 23:49:02 --> Input Class Initialized
DEBUG - 2011-08-14 23:49:02 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-14 23:49:02 --> Language Class Initialized
DEBUG - 2011-08-14 23:49:02 --> Loader Class Initialized
DEBUG - 2011-08-14 23:49:02 --> Controller Class Initialized
DEBUG - 2011-08-14 23:49:02 --> Model Class Initialized
DEBUG - 2011-08-14 23:49:02 --> Model Class Initialized
DEBUG - 2011-08-14 23:49:02 --> Model Class Initialized
DEBUG - 2011-08-14 23:49:02 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-14 23:49:02 --> Database Driver Class Initialized
DEBUG - 2011-08-14 23:49:02 --> File loaded: application/views/table/main.php
DEBUG - 2011-08-14 23:49:02 --> Helper loaded: url_helper
DEBUG - 2011-08-14 23:49:02 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-14 23:49:02 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-14 23:49:02 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-14 23:49:02 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-14 23:49:02 --> Final output sent to browser
DEBUG - 2011-08-14 23:49:02 --> Total execution time: 0.2329
DEBUG - 2011-08-14 23:49:04 --> Config Class Initialized
DEBUG - 2011-08-14 23:49:04 --> Hooks Class Initialized
DEBUG - 2011-08-14 23:49:04 --> Utf8 Class Initialized
DEBUG - 2011-08-14 23:49:04 --> UTF-8 Support Enabled
DEBUG - 2011-08-14 23:49:04 --> URI Class Initialized
DEBUG - 2011-08-14 23:49:04 --> Router Class Initialized
DEBUG - 2011-08-14 23:49:04 --> Output Class Initialized
DEBUG - 2011-08-14 23:49:04 --> Input Class Initialized
DEBUG - 2011-08-14 23:49:04 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-14 23:49:04 --> Language Class Initialized
DEBUG - 2011-08-14 23:49:04 --> Loader Class Initialized
DEBUG - 2011-08-14 23:49:04 --> Controller Class Initialized
DEBUG - 2011-08-14 23:49:04 --> Model Class Initialized
DEBUG - 2011-08-14 23:49:04 --> Model Class Initialized
DEBUG - 2011-08-14 23:49:04 --> Model Class Initialized
DEBUG - 2011-08-14 23:49:04 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-14 23:49:04 --> Database Driver Class Initialized
DEBUG - 2011-08-14 23:49:04 --> File loaded: application/views/table/main.php
DEBUG - 2011-08-14 23:49:04 --> Helper loaded: url_helper
DEBUG - 2011-08-14 23:49:04 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-14 23:49:04 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-14 23:49:04 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-14 23:49:04 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-14 23:49:04 --> Final output sent to browser
DEBUG - 2011-08-14 23:49:04 --> Total execution time: 0.0468
DEBUG - 2011-08-14 23:49:12 --> Config Class Initialized
DEBUG - 2011-08-14 23:49:12 --> Hooks Class Initialized
DEBUG - 2011-08-14 23:49:12 --> Utf8 Class Initialized
DEBUG - 2011-08-14 23:49:12 --> UTF-8 Support Enabled
DEBUG - 2011-08-14 23:49:12 --> URI Class Initialized
DEBUG - 2011-08-14 23:49:12 --> Router Class Initialized
DEBUG - 2011-08-14 23:49:12 --> Output Class Initialized
DEBUG - 2011-08-14 23:49:12 --> Input Class Initialized
DEBUG - 2011-08-14 23:49:12 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-14 23:49:12 --> Language Class Initialized
DEBUG - 2011-08-14 23:49:12 --> Loader Class Initialized
DEBUG - 2011-08-14 23:49:12 --> Controller Class Initialized
DEBUG - 2011-08-14 23:49:12 --> Model Class Initialized
DEBUG - 2011-08-14 23:49:12 --> Model Class Initialized
DEBUG - 2011-08-14 23:49:12 --> Model Class Initialized
DEBUG - 2011-08-14 23:49:12 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-14 23:49:12 --> Database Driver Class Initialized
DEBUG - 2011-08-14 23:49:12 --> File loaded: application/views/table/main.php
DEBUG - 2011-08-14 23:49:12 --> Helper loaded: url_helper
DEBUG - 2011-08-14 23:49:12 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-14 23:49:12 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-14 23:49:12 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-14 23:49:12 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-14 23:49:12 --> Final output sent to browser
DEBUG - 2011-08-14 23:49:12 --> Total execution time: 0.1897
DEBUG - 2011-08-14 23:49:13 --> Config Class Initialized
DEBUG - 2011-08-14 23:49:13 --> Hooks Class Initialized
DEBUG - 2011-08-14 23:49:13 --> Utf8 Class Initialized
DEBUG - 2011-08-14 23:49:13 --> UTF-8 Support Enabled
DEBUG - 2011-08-14 23:49:13 --> URI Class Initialized
DEBUG - 2011-08-14 23:49:13 --> Router Class Initialized
DEBUG - 2011-08-14 23:49:13 --> Output Class Initialized
DEBUG - 2011-08-14 23:49:13 --> Input Class Initialized
DEBUG - 2011-08-14 23:49:13 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-14 23:49:13 --> Language Class Initialized
DEBUG - 2011-08-14 23:49:13 --> Loader Class Initialized
DEBUG - 2011-08-14 23:49:13 --> Controller Class Initialized
DEBUG - 2011-08-14 23:49:13 --> Model Class Initialized
DEBUG - 2011-08-14 23:49:13 --> Model Class Initialized
DEBUG - 2011-08-14 23:49:13 --> Model Class Initialized
DEBUG - 2011-08-14 23:49:13 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-14 23:49:13 --> Database Driver Class Initialized
DEBUG - 2011-08-14 23:49:13 --> File loaded: application/views/table/main.php
DEBUG - 2011-08-14 23:49:13 --> Helper loaded: url_helper
DEBUG - 2011-08-14 23:49:13 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-14 23:49:13 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-14 23:49:13 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-14 23:49:13 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-14 23:49:13 --> Final output sent to browser
DEBUG - 2011-08-14 23:49:13 --> Total execution time: 0.0496
DEBUG - 2011-08-14 23:49:23 --> Config Class Initialized
DEBUG - 2011-08-14 23:49:23 --> Hooks Class Initialized
DEBUG - 2011-08-14 23:49:23 --> Utf8 Class Initialized
DEBUG - 2011-08-14 23:49:23 --> UTF-8 Support Enabled
DEBUG - 2011-08-14 23:49:23 --> URI Class Initialized
DEBUG - 2011-08-14 23:49:23 --> Router Class Initialized
DEBUG - 2011-08-14 23:49:23 --> Output Class Initialized
DEBUG - 2011-08-14 23:49:23 --> Input Class Initialized
DEBUG - 2011-08-14 23:49:23 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-14 23:49:23 --> Language Class Initialized
DEBUG - 2011-08-14 23:49:23 --> Loader Class Initialized
DEBUG - 2011-08-14 23:49:23 --> Controller Class Initialized
DEBUG - 2011-08-14 23:49:23 --> Model Class Initialized
DEBUG - 2011-08-14 23:49:23 --> Model Class Initialized
DEBUG - 2011-08-14 23:49:23 --> Model Class Initialized
DEBUG - 2011-08-14 23:49:23 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-14 23:49:23 --> Database Driver Class Initialized
DEBUG - 2011-08-14 23:49:23 --> File loaded: application/views/table/main.php
DEBUG - 2011-08-14 23:49:23 --> Helper loaded: url_helper
DEBUG - 2011-08-14 23:49:23 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-14 23:49:23 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-14 23:49:23 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-14 23:49:23 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-14 23:49:23 --> Final output sent to browser
DEBUG - 2011-08-14 23:49:23 --> Total execution time: 0.2010
DEBUG - 2011-08-14 23:49:26 --> Config Class Initialized
DEBUG - 2011-08-14 23:49:26 --> Hooks Class Initialized
DEBUG - 2011-08-14 23:49:26 --> Utf8 Class Initialized
DEBUG - 2011-08-14 23:49:26 --> UTF-8 Support Enabled
DEBUG - 2011-08-14 23:49:26 --> URI Class Initialized
DEBUG - 2011-08-14 23:49:26 --> Router Class Initialized
DEBUG - 2011-08-14 23:49:26 --> Output Class Initialized
DEBUG - 2011-08-14 23:49:26 --> Input Class Initialized
DEBUG - 2011-08-14 23:49:26 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-14 23:49:26 --> Language Class Initialized
DEBUG - 2011-08-14 23:49:26 --> Loader Class Initialized
DEBUG - 2011-08-14 23:49:26 --> Controller Class Initialized
DEBUG - 2011-08-14 23:49:26 --> Model Class Initialized
DEBUG - 2011-08-14 23:49:26 --> Model Class Initialized
DEBUG - 2011-08-14 23:49:26 --> Model Class Initialized
DEBUG - 2011-08-14 23:49:26 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-14 23:49:26 --> Database Driver Class Initialized
DEBUG - 2011-08-14 23:49:26 --> File loaded: application/views/table/main.php
DEBUG - 2011-08-14 23:49:26 --> Helper loaded: url_helper
DEBUG - 2011-08-14 23:49:26 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-14 23:49:26 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-14 23:49:26 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-14 23:49:26 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-14 23:49:26 --> Final output sent to browser
DEBUG - 2011-08-14 23:49:26 --> Total execution time: 0.0448
DEBUG - 2011-08-14 23:49:47 --> Config Class Initialized
DEBUG - 2011-08-14 23:49:47 --> Hooks Class Initialized
DEBUG - 2011-08-14 23:49:47 --> Utf8 Class Initialized
DEBUG - 2011-08-14 23:49:47 --> UTF-8 Support Enabled
DEBUG - 2011-08-14 23:49:47 --> URI Class Initialized
DEBUG - 2011-08-14 23:49:47 --> Router Class Initialized
DEBUG - 2011-08-14 23:49:47 --> Output Class Initialized
DEBUG - 2011-08-14 23:49:47 --> Input Class Initialized
DEBUG - 2011-08-14 23:49:47 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-14 23:49:47 --> Language Class Initialized
DEBUG - 2011-08-14 23:49:47 --> Loader Class Initialized
DEBUG - 2011-08-14 23:49:47 --> Controller Class Initialized
DEBUG - 2011-08-14 23:49:47 --> Model Class Initialized
DEBUG - 2011-08-14 23:49:47 --> Model Class Initialized
DEBUG - 2011-08-14 23:49:47 --> Model Class Initialized
DEBUG - 2011-08-14 23:49:47 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-14 23:49:47 --> Database Driver Class Initialized
DEBUG - 2011-08-14 23:49:47 --> File loaded: application/views/table/main.php
DEBUG - 2011-08-14 23:49:47 --> Helper loaded: url_helper
DEBUG - 2011-08-14 23:49:47 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-14 23:49:47 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-14 23:49:47 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-14 23:49:47 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-14 23:49:47 --> Final output sent to browser
DEBUG - 2011-08-14 23:49:47 --> Total execution time: 0.3001
DEBUG - 2011-08-14 23:49:48 --> Config Class Initialized
DEBUG - 2011-08-14 23:49:48 --> Hooks Class Initialized
DEBUG - 2011-08-14 23:49:48 --> Utf8 Class Initialized
DEBUG - 2011-08-14 23:49:48 --> UTF-8 Support Enabled
DEBUG - 2011-08-14 23:49:48 --> URI Class Initialized
DEBUG - 2011-08-14 23:49:48 --> Router Class Initialized
DEBUG - 2011-08-14 23:49:48 --> Output Class Initialized
DEBUG - 2011-08-14 23:49:48 --> Input Class Initialized
DEBUG - 2011-08-14 23:49:48 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-14 23:49:48 --> Language Class Initialized
DEBUG - 2011-08-14 23:49:48 --> Loader Class Initialized
DEBUG - 2011-08-14 23:49:48 --> Controller Class Initialized
DEBUG - 2011-08-14 23:49:48 --> Model Class Initialized
DEBUG - 2011-08-14 23:49:48 --> Model Class Initialized
DEBUG - 2011-08-14 23:49:48 --> Model Class Initialized
DEBUG - 2011-08-14 23:49:48 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-14 23:49:48 --> Database Driver Class Initialized
DEBUG - 2011-08-14 23:49:48 --> File loaded: application/views/table/main.php
DEBUG - 2011-08-14 23:49:48 --> Helper loaded: url_helper
DEBUG - 2011-08-14 23:49:48 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-14 23:49:48 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-14 23:49:48 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-14 23:49:48 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-14 23:49:48 --> Final output sent to browser
DEBUG - 2011-08-14 23:49:48 --> Total execution time: 0.0449
DEBUG - 2011-08-14 23:50:20 --> Config Class Initialized
DEBUG - 2011-08-14 23:50:20 --> Hooks Class Initialized
DEBUG - 2011-08-14 23:50:20 --> Utf8 Class Initialized
DEBUG - 2011-08-14 23:50:20 --> UTF-8 Support Enabled
DEBUG - 2011-08-14 23:50:20 --> URI Class Initialized
DEBUG - 2011-08-14 23:50:20 --> Router Class Initialized
DEBUG - 2011-08-14 23:50:20 --> Output Class Initialized
DEBUG - 2011-08-14 23:50:20 --> Input Class Initialized
DEBUG - 2011-08-14 23:50:20 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-14 23:50:20 --> Language Class Initialized
DEBUG - 2011-08-14 23:50:20 --> Loader Class Initialized
DEBUG - 2011-08-14 23:50:20 --> Controller Class Initialized
DEBUG - 2011-08-14 23:50:20 --> Model Class Initialized
DEBUG - 2011-08-14 23:50:20 --> Model Class Initialized
DEBUG - 2011-08-14 23:50:20 --> Model Class Initialized
DEBUG - 2011-08-14 23:50:20 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-14 23:50:20 --> Database Driver Class Initialized
DEBUG - 2011-08-14 23:50:20 --> File loaded: application/views/table/main.php
DEBUG - 2011-08-14 23:50:20 --> Helper loaded: url_helper
DEBUG - 2011-08-14 23:50:20 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-14 23:50:20 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-14 23:50:20 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-14 23:50:20 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-14 23:50:20 --> Final output sent to browser
DEBUG - 2011-08-14 23:50:20 --> Total execution time: 0.3435
DEBUG - 2011-08-14 23:50:29 --> Config Class Initialized
DEBUG - 2011-08-14 23:50:29 --> Hooks Class Initialized
DEBUG - 2011-08-14 23:50:29 --> Utf8 Class Initialized
DEBUG - 2011-08-14 23:50:29 --> UTF-8 Support Enabled
DEBUG - 2011-08-14 23:50:29 --> URI Class Initialized
DEBUG - 2011-08-14 23:50:29 --> Router Class Initialized
DEBUG - 2011-08-14 23:50:29 --> Output Class Initialized
DEBUG - 2011-08-14 23:50:29 --> Input Class Initialized
DEBUG - 2011-08-14 23:50:29 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-14 23:50:29 --> Language Class Initialized
DEBUG - 2011-08-14 23:50:29 --> Loader Class Initialized
DEBUG - 2011-08-14 23:50:29 --> Controller Class Initialized
DEBUG - 2011-08-14 23:50:29 --> Model Class Initialized
DEBUG - 2011-08-14 23:50:29 --> Model Class Initialized
DEBUG - 2011-08-14 23:50:29 --> Model Class Initialized
DEBUG - 2011-08-14 23:50:29 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-14 23:50:29 --> Database Driver Class Initialized
DEBUG - 2011-08-14 23:50:29 --> File loaded: application/views/table/main.php
DEBUG - 2011-08-14 23:50:29 --> Helper loaded: url_helper
DEBUG - 2011-08-14 23:50:29 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-14 23:50:29 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-14 23:50:29 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-14 23:50:29 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-14 23:50:29 --> Final output sent to browser
DEBUG - 2011-08-14 23:50:29 --> Total execution time: 0.2367
DEBUG - 2011-08-14 23:50:37 --> Config Class Initialized
DEBUG - 2011-08-14 23:50:37 --> Hooks Class Initialized
DEBUG - 2011-08-14 23:50:37 --> Utf8 Class Initialized
DEBUG - 2011-08-14 23:50:37 --> UTF-8 Support Enabled
DEBUG - 2011-08-14 23:50:37 --> URI Class Initialized
DEBUG - 2011-08-14 23:50:37 --> Router Class Initialized
DEBUG - 2011-08-14 23:50:37 --> Output Class Initialized
DEBUG - 2011-08-14 23:50:37 --> Input Class Initialized
DEBUG - 2011-08-14 23:50:37 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-14 23:50:37 --> Language Class Initialized
DEBUG - 2011-08-14 23:50:37 --> Loader Class Initialized
DEBUG - 2011-08-14 23:50:37 --> Controller Class Initialized
DEBUG - 2011-08-14 23:50:37 --> Model Class Initialized
DEBUG - 2011-08-14 23:50:37 --> Model Class Initialized
DEBUG - 2011-08-14 23:50:37 --> Model Class Initialized
DEBUG - 2011-08-14 23:50:37 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-14 23:50:37 --> Database Driver Class Initialized
DEBUG - 2011-08-14 23:50:37 --> File loaded: application/views/table/main.php
DEBUG - 2011-08-14 23:50:37 --> Helper loaded: url_helper
DEBUG - 2011-08-14 23:50:37 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-14 23:50:37 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-14 23:50:37 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-14 23:50:37 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-14 23:50:37 --> Final output sent to browser
DEBUG - 2011-08-14 23:50:37 --> Total execution time: 0.2027
DEBUG - 2011-08-14 23:50:48 --> Config Class Initialized
DEBUG - 2011-08-14 23:50:48 --> Hooks Class Initialized
DEBUG - 2011-08-14 23:50:48 --> Utf8 Class Initialized
DEBUG - 2011-08-14 23:50:48 --> UTF-8 Support Enabled
DEBUG - 2011-08-14 23:50:48 --> URI Class Initialized
DEBUG - 2011-08-14 23:50:48 --> Router Class Initialized
DEBUG - 2011-08-14 23:50:48 --> Output Class Initialized
DEBUG - 2011-08-14 23:50:48 --> Input Class Initialized
DEBUG - 2011-08-14 23:50:48 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-14 23:50:48 --> Language Class Initialized
DEBUG - 2011-08-14 23:50:48 --> Loader Class Initialized
DEBUG - 2011-08-14 23:50:48 --> Controller Class Initialized
DEBUG - 2011-08-14 23:50:48 --> Model Class Initialized
DEBUG - 2011-08-14 23:50:48 --> Model Class Initialized
DEBUG - 2011-08-14 23:50:48 --> Model Class Initialized
DEBUG - 2011-08-14 23:50:48 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-14 23:50:48 --> Database Driver Class Initialized
DEBUG - 2011-08-14 23:50:48 --> File loaded: application/views/table/main.php
DEBUG - 2011-08-14 23:50:48 --> Helper loaded: url_helper
DEBUG - 2011-08-14 23:50:48 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-14 23:50:48 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-14 23:50:48 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-14 23:50:48 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-14 23:50:48 --> Final output sent to browser
DEBUG - 2011-08-14 23:50:48 --> Total execution time: 0.2189
DEBUG - 2011-08-14 23:50:49 --> Config Class Initialized
DEBUG - 2011-08-14 23:50:49 --> Hooks Class Initialized
DEBUG - 2011-08-14 23:50:49 --> Utf8 Class Initialized
DEBUG - 2011-08-14 23:50:49 --> UTF-8 Support Enabled
DEBUG - 2011-08-14 23:50:49 --> URI Class Initialized
DEBUG - 2011-08-14 23:50:49 --> Router Class Initialized
DEBUG - 2011-08-14 23:50:49 --> Output Class Initialized
DEBUG - 2011-08-14 23:50:49 --> Input Class Initialized
DEBUG - 2011-08-14 23:50:49 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-14 23:50:49 --> Language Class Initialized
DEBUG - 2011-08-14 23:50:49 --> Loader Class Initialized
DEBUG - 2011-08-14 23:50:49 --> Controller Class Initialized
DEBUG - 2011-08-14 23:50:49 --> Model Class Initialized
DEBUG - 2011-08-14 23:50:49 --> Model Class Initialized
DEBUG - 2011-08-14 23:50:49 --> Model Class Initialized
DEBUG - 2011-08-14 23:50:49 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-14 23:50:49 --> Database Driver Class Initialized
DEBUG - 2011-08-14 23:50:49 --> File loaded: application/views/table/main.php
DEBUG - 2011-08-14 23:50:49 --> Helper loaded: url_helper
DEBUG - 2011-08-14 23:50:49 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-14 23:50:49 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-14 23:50:49 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-14 23:50:49 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-14 23:50:49 --> Final output sent to browser
DEBUG - 2011-08-14 23:50:49 --> Total execution time: 0.0503

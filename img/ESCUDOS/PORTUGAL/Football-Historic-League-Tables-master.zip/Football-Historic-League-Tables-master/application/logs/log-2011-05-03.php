<?php  if ( ! defined('BASEPATH')) exit('No direct script access allowed'); ?>

DEBUG - 2011-05-03 00:02:56 --> Config Class Initialized
DEBUG - 2011-05-03 00:02:56 --> Hooks Class Initialized
DEBUG - 2011-05-03 00:02:56 --> Utf8 Class Initialized
DEBUG - 2011-05-03 00:02:56 --> UTF-8 Support Enabled
DEBUG - 2011-05-03 00:02:56 --> URI Class Initialized
DEBUG - 2011-05-03 00:02:56 --> Router Class Initialized
DEBUG - 2011-05-03 00:02:56 --> Output Class Initialized
DEBUG - 2011-05-03 00:02:56 --> Input Class Initialized
DEBUG - 2011-05-03 00:02:56 --> Global POST and COOKIE data sanitized
DEBUG - 2011-05-03 00:02:56 --> Language Class Initialized
DEBUG - 2011-05-03 00:02:56 --> Loader Class Initialized
DEBUG - 2011-05-03 00:02:56 --> Controller Class Initialized
DEBUG - 2011-05-03 00:02:56 --> Model Class Initialized
DEBUG - 2011-05-03 00:02:56 --> Model Class Initialized
DEBUG - 2011-05-03 00:02:56 --> Model Class Initialized
DEBUG - 2011-05-03 00:02:56 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-05-03 00:02:56 --> Database Driver Class Initialized
DEBUG - 2011-05-03 00:02:57 --> File loaded: application/views/table/main.php
DEBUG - 2011-05-03 00:02:57 --> Helper loaded: url_helper
DEBUG - 2011-05-03 00:02:57 --> File loaded: application/views/common/header.php
DEBUG - 2011-05-03 00:02:57 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-05-03 00:02:57 --> File loaded: application/views/common/footer.php
DEBUG - 2011-05-03 00:02:57 --> File loaded: application/views/layout/main.php
DEBUG - 2011-05-03 00:02:57 --> Final output sent to browser
DEBUG - 2011-05-03 00:02:57 --> Total execution time: 1.2545
DEBUG - 2011-05-03 00:02:58 --> Config Class Initialized
DEBUG - 2011-05-03 00:02:58 --> Hooks Class Initialized
DEBUG - 2011-05-03 00:02:58 --> Utf8 Class Initialized
DEBUG - 2011-05-03 00:02:58 --> UTF-8 Support Enabled
DEBUG - 2011-05-03 00:02:58 --> URI Class Initialized
DEBUG - 2011-05-03 00:02:58 --> Router Class Initialized
DEBUG - 2011-05-03 00:02:58 --> Output Class Initialized
DEBUG - 2011-05-03 00:02:58 --> Input Class Initialized
DEBUG - 2011-05-03 00:02:58 --> Global POST and COOKIE data sanitized
DEBUG - 2011-05-03 00:02:58 --> Language Class Initialized
DEBUG - 2011-05-03 00:02:58 --> Loader Class Initialized
DEBUG - 2011-05-03 00:02:58 --> Controller Class Initialized
ERROR - 2011-05-03 00:02:58 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-05-03 00:02:58 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-05-03 00:02:58 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-05-03 00:02:58 --> Model Class Initialized
DEBUG - 2011-05-03 00:02:58 --> Model Class Initialized
DEBUG - 2011-05-03 00:02:58 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-05-03 00:02:58 --> Database Driver Class Initialized
DEBUG - 2011-05-03 00:02:58 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-05-03 00:02:58 --> Helper loaded: url_helper
DEBUG - 2011-05-03 00:02:58 --> File loaded: application/views/common/header.php
DEBUG - 2011-05-03 00:02:58 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-05-03 00:02:58 --> File loaded: application/views/common/footer.php
DEBUG - 2011-05-03 00:02:58 --> File loaded: application/views/layout/main.php
DEBUG - 2011-05-03 00:02:58 --> Final output sent to browser
DEBUG - 2011-05-03 00:02:58 --> Total execution time: 0.2481
DEBUG - 2011-05-03 00:44:16 --> Config Class Initialized
DEBUG - 2011-05-03 00:44:16 --> Hooks Class Initialized
DEBUG - 2011-05-03 00:44:16 --> Utf8 Class Initialized
DEBUG - 2011-05-03 00:44:16 --> UTF-8 Support Enabled
DEBUG - 2011-05-03 00:44:16 --> URI Class Initialized
DEBUG - 2011-05-03 00:44:16 --> Router Class Initialized
ERROR - 2011-05-03 00:44:16 --> 404 Page Not Found --> robots.txt
DEBUG - 2011-05-03 00:44:48 --> Config Class Initialized
DEBUG - 2011-05-03 00:44:48 --> Hooks Class Initialized
DEBUG - 2011-05-03 00:44:48 --> Utf8 Class Initialized
DEBUG - 2011-05-03 00:44:48 --> UTF-8 Support Enabled
DEBUG - 2011-05-03 00:44:48 --> URI Class Initialized
DEBUG - 2011-05-03 00:44:48 --> Router Class Initialized
DEBUG - 2011-05-03 00:44:48 --> No URI present. Default controller set.
DEBUG - 2011-05-03 00:44:48 --> Output Class Initialized
DEBUG - 2011-05-03 00:44:48 --> Input Class Initialized
DEBUG - 2011-05-03 00:44:48 --> Global POST and COOKIE data sanitized
DEBUG - 2011-05-03 00:44:48 --> Language Class Initialized
DEBUG - 2011-05-03 00:44:48 --> Loader Class Initialized
DEBUG - 2011-05-03 00:44:48 --> Controller Class Initialized
DEBUG - 2011-05-03 00:44:48 --> File loaded: application/views/splash/main.php
DEBUG - 2011-05-03 00:44:48 --> Helper loaded: url_helper
DEBUG - 2011-05-03 00:44:48 --> File loaded: application/views/common/header.php
DEBUG - 2011-05-03 00:44:48 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-05-03 00:44:48 --> File loaded: application/views/common/footer.php
DEBUG - 2011-05-03 00:44:48 --> File loaded: application/views/layout/main.php
DEBUG - 2011-05-03 00:44:48 --> Final output sent to browser
DEBUG - 2011-05-03 00:44:48 --> Total execution time: 0.1902
DEBUG - 2011-05-03 00:55:53 --> Config Class Initialized
DEBUG - 2011-05-03 00:55:53 --> Hooks Class Initialized
DEBUG - 2011-05-03 00:55:53 --> Utf8 Class Initialized
DEBUG - 2011-05-03 00:55:53 --> UTF-8 Support Enabled
DEBUG - 2011-05-03 00:55:53 --> URI Class Initialized
DEBUG - 2011-05-03 00:55:53 --> Router Class Initialized
DEBUG - 2011-05-03 00:55:53 --> Output Class Initialized
DEBUG - 2011-05-03 00:55:53 --> Input Class Initialized
DEBUG - 2011-05-03 00:55:53 --> Global POST and COOKIE data sanitized
DEBUG - 2011-05-03 00:55:53 --> Language Class Initialized
DEBUG - 2011-05-03 00:55:53 --> Loader Class Initialized
DEBUG - 2011-05-03 00:55:53 --> Controller Class Initialized
DEBUG - 2011-05-03 00:55:53 --> Model Class Initialized
DEBUG - 2011-05-03 00:55:53 --> Model Class Initialized
DEBUG - 2011-05-03 00:55:53 --> Model Class Initialized
DEBUG - 2011-05-03 00:55:53 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-05-03 00:55:53 --> Database Driver Class Initialized
DEBUG - 2011-05-03 00:55:53 --> File loaded: application/views/table/main.php
DEBUG - 2011-05-03 00:55:54 --> Helper loaded: url_helper
DEBUG - 2011-05-03 00:55:54 --> File loaded: application/views/common/header.php
DEBUG - 2011-05-03 00:55:54 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-05-03 00:55:54 --> File loaded: application/views/common/footer.php
DEBUG - 2011-05-03 00:55:54 --> File loaded: application/views/layout/main.php
DEBUG - 2011-05-03 00:55:54 --> Final output sent to browser
DEBUG - 2011-05-03 00:55:54 --> Total execution time: 0.4206
DEBUG - 2011-05-03 00:55:58 --> Config Class Initialized
DEBUG - 2011-05-03 00:55:58 --> Hooks Class Initialized
DEBUG - 2011-05-03 00:55:58 --> Utf8 Class Initialized
DEBUG - 2011-05-03 00:55:58 --> UTF-8 Support Enabled
DEBUG - 2011-05-03 00:55:58 --> URI Class Initialized
DEBUG - 2011-05-03 00:55:58 --> Router Class Initialized
DEBUG - 2011-05-03 00:55:58 --> No URI present. Default controller set.
DEBUG - 2011-05-03 00:55:58 --> Output Class Initialized
DEBUG - 2011-05-03 00:55:58 --> Input Class Initialized
DEBUG - 2011-05-03 00:55:58 --> Global POST and COOKIE data sanitized
DEBUG - 2011-05-03 00:55:58 --> Language Class Initialized
DEBUG - 2011-05-03 00:55:58 --> Loader Class Initialized
DEBUG - 2011-05-03 00:55:58 --> Controller Class Initialized
DEBUG - 2011-05-03 00:55:58 --> File loaded: application/views/splash/main.php
DEBUG - 2011-05-03 00:55:58 --> Helper loaded: url_helper
DEBUG - 2011-05-03 00:55:58 --> File loaded: application/views/common/header.php
DEBUG - 2011-05-03 00:55:58 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-05-03 00:55:58 --> File loaded: application/views/common/footer.php
DEBUG - 2011-05-03 00:55:58 --> File loaded: application/views/layout/main.php
DEBUG - 2011-05-03 00:55:58 --> Final output sent to browser
DEBUG - 2011-05-03 00:55:58 --> Total execution time: 0.0154
DEBUG - 2011-05-03 00:55:58 --> Config Class Initialized
DEBUG - 2011-05-03 00:55:58 --> Hooks Class Initialized
DEBUG - 2011-05-03 00:55:58 --> Utf8 Class Initialized
DEBUG - 2011-05-03 00:55:58 --> UTF-8 Support Enabled
DEBUG - 2011-05-03 00:55:58 --> URI Class Initialized
DEBUG - 2011-05-03 00:55:58 --> Router Class Initialized
ERROR - 2011-05-03 00:55:58 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-05-03 00:55:59 --> Config Class Initialized
DEBUG - 2011-05-03 00:55:59 --> Hooks Class Initialized
DEBUG - 2011-05-03 00:55:59 --> Utf8 Class Initialized
DEBUG - 2011-05-03 00:55:59 --> UTF-8 Support Enabled
DEBUG - 2011-05-03 00:55:59 --> URI Class Initialized
DEBUG - 2011-05-03 00:55:59 --> Router Class Initialized
ERROR - 2011-05-03 00:55:59 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-05-03 00:56:16 --> Config Class Initialized
DEBUG - 2011-05-03 00:56:16 --> Hooks Class Initialized
DEBUG - 2011-05-03 00:56:16 --> Utf8 Class Initialized
DEBUG - 2011-05-03 00:56:16 --> UTF-8 Support Enabled
DEBUG - 2011-05-03 00:56:16 --> URI Class Initialized
DEBUG - 2011-05-03 00:56:16 --> Router Class Initialized
DEBUG - 2011-05-03 00:56:16 --> No URI present. Default controller set.
DEBUG - 2011-05-03 00:56:16 --> Output Class Initialized
DEBUG - 2011-05-03 00:56:16 --> Input Class Initialized
DEBUG - 2011-05-03 00:56:16 --> Global POST and COOKIE data sanitized
DEBUG - 2011-05-03 00:56:16 --> Language Class Initialized
DEBUG - 2011-05-03 00:56:16 --> Loader Class Initialized
DEBUG - 2011-05-03 00:56:16 --> Controller Class Initialized
DEBUG - 2011-05-03 00:56:16 --> File loaded: application/views/splash/main.php
DEBUG - 2011-05-03 00:56:16 --> Helper loaded: url_helper
DEBUG - 2011-05-03 00:56:16 --> File loaded: application/views/common/header.php
DEBUG - 2011-05-03 00:56:16 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-05-03 00:56:16 --> File loaded: application/views/common/footer.php
DEBUG - 2011-05-03 00:56:16 --> File loaded: application/views/layout/main.php
DEBUG - 2011-05-03 00:56:16 --> Final output sent to browser
DEBUG - 2011-05-03 00:56:16 --> Total execution time: 0.0122
DEBUG - 2011-05-03 00:56:20 --> Config Class Initialized
DEBUG - 2011-05-03 00:56:20 --> Hooks Class Initialized
DEBUG - 2011-05-03 00:56:20 --> Utf8 Class Initialized
DEBUG - 2011-05-03 00:56:20 --> UTF-8 Support Enabled
DEBUG - 2011-05-03 00:56:20 --> URI Class Initialized
DEBUG - 2011-05-03 00:56:20 --> Router Class Initialized
DEBUG - 2011-05-03 00:56:20 --> Output Class Initialized
DEBUG - 2011-05-03 00:56:20 --> Input Class Initialized
DEBUG - 2011-05-03 00:56:20 --> Global POST and COOKIE data sanitized
DEBUG - 2011-05-03 00:56:20 --> Language Class Initialized
DEBUG - 2011-05-03 00:56:20 --> Loader Class Initialized
DEBUG - 2011-05-03 00:56:20 --> Controller Class Initialized
DEBUG - 2011-05-03 00:56:20 --> Model Class Initialized
DEBUG - 2011-05-03 00:56:20 --> Model Class Initialized
DEBUG - 2011-05-03 00:56:20 --> Model Class Initialized
DEBUG - 2011-05-03 00:56:20 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-05-03 00:56:20 --> Database Driver Class Initialized
DEBUG - 2011-05-03 00:56:20 --> File loaded: application/views/table/main.php
DEBUG - 2011-05-03 00:56:20 --> Helper loaded: url_helper
DEBUG - 2011-05-03 00:56:20 --> File loaded: application/views/common/header.php
DEBUG - 2011-05-03 00:56:20 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-05-03 00:56:20 --> File loaded: application/views/common/footer.php
DEBUG - 2011-05-03 00:56:20 --> File loaded: application/views/layout/main.php
DEBUG - 2011-05-03 00:56:20 --> Final output sent to browser
DEBUG - 2011-05-03 00:56:20 --> Total execution time: 0.0534
DEBUG - 2011-05-03 00:56:22 --> Config Class Initialized
DEBUG - 2011-05-03 00:56:22 --> Hooks Class Initialized
DEBUG - 2011-05-03 00:56:22 --> Utf8 Class Initialized
DEBUG - 2011-05-03 00:56:22 --> UTF-8 Support Enabled
DEBUG - 2011-05-03 00:56:22 --> URI Class Initialized
DEBUG - 2011-05-03 00:56:22 --> Router Class Initialized
ERROR - 2011-05-03 00:56:22 --> 404 Page Not Found --> robots.txt
DEBUG - 2011-05-03 00:56:23 --> Config Class Initialized
DEBUG - 2011-05-03 00:56:23 --> Hooks Class Initialized
DEBUG - 2011-05-03 00:56:23 --> Utf8 Class Initialized
DEBUG - 2011-05-03 00:56:23 --> UTF-8 Support Enabled
DEBUG - 2011-05-03 00:56:23 --> URI Class Initialized
DEBUG - 2011-05-03 00:56:23 --> Router Class Initialized
DEBUG - 2011-05-03 00:56:23 --> Output Class Initialized
DEBUG - 2011-05-03 00:56:23 --> Input Class Initialized
DEBUG - 2011-05-03 00:56:23 --> Global POST and COOKIE data sanitized
DEBUG - 2011-05-03 00:56:23 --> Language Class Initialized
DEBUG - 2011-05-03 00:56:23 --> Loader Class Initialized
DEBUG - 2011-05-03 00:56:23 --> Controller Class Initialized
DEBUG - 2011-05-03 00:56:23 --> Model Class Initialized
DEBUG - 2011-05-03 00:56:23 --> Model Class Initialized
DEBUG - 2011-05-03 00:56:23 --> Model Class Initialized
DEBUG - 2011-05-03 00:56:23 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-05-03 00:56:23 --> Database Driver Class Initialized
DEBUG - 2011-05-03 00:56:23 --> File loaded: application/views/table/main.php
DEBUG - 2011-05-03 00:56:23 --> Helper loaded: url_helper
DEBUG - 2011-05-03 00:56:23 --> File loaded: application/views/common/header.php
DEBUG - 2011-05-03 00:56:23 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-05-03 00:56:23 --> File loaded: application/views/common/footer.php
DEBUG - 2011-05-03 00:56:23 --> File loaded: application/views/layout/main.php
DEBUG - 2011-05-03 00:56:23 --> Final output sent to browser
DEBUG - 2011-05-03 00:56:23 --> Total execution time: 0.0446
DEBUG - 2011-05-03 00:56:46 --> Config Class Initialized
DEBUG - 2011-05-03 00:56:46 --> Hooks Class Initialized
DEBUG - 2011-05-03 00:56:46 --> Utf8 Class Initialized
DEBUG - 2011-05-03 00:56:46 --> UTF-8 Support Enabled
DEBUG - 2011-05-03 00:56:46 --> URI Class Initialized
DEBUG - 2011-05-03 00:56:46 --> Router Class Initialized
DEBUG - 2011-05-03 00:56:46 --> Output Class Initialized
DEBUG - 2011-05-03 00:56:46 --> Input Class Initialized
DEBUG - 2011-05-03 00:56:46 --> Global POST and COOKIE data sanitized
DEBUG - 2011-05-03 00:56:46 --> Language Class Initialized
DEBUG - 2011-05-03 00:56:46 --> Loader Class Initialized
DEBUG - 2011-05-03 00:56:46 --> Controller Class Initialized
DEBUG - 2011-05-03 00:56:46 --> Model Class Initialized
DEBUG - 2011-05-03 00:56:46 --> Model Class Initialized
DEBUG - 2011-05-03 00:56:46 --> Model Class Initialized
DEBUG - 2011-05-03 00:56:46 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-05-03 00:56:46 --> Database Driver Class Initialized
DEBUG - 2011-05-03 00:56:46 --> File loaded: application/views/table/main.php
DEBUG - 2011-05-03 00:56:46 --> Helper loaded: url_helper
DEBUG - 2011-05-03 00:56:46 --> File loaded: application/views/common/header.php
DEBUG - 2011-05-03 00:56:46 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-05-03 00:56:46 --> File loaded: application/views/common/footer.php
DEBUG - 2011-05-03 00:56:46 --> File loaded: application/views/layout/main.php
DEBUG - 2011-05-03 00:56:46 --> Final output sent to browser
DEBUG - 2011-05-03 00:56:46 --> Total execution time: 0.2089
DEBUG - 2011-05-03 00:56:48 --> Config Class Initialized
DEBUG - 2011-05-03 00:56:48 --> Hooks Class Initialized
DEBUG - 2011-05-03 00:56:48 --> Utf8 Class Initialized
DEBUG - 2011-05-03 00:56:48 --> UTF-8 Support Enabled
DEBUG - 2011-05-03 00:56:48 --> URI Class Initialized
DEBUG - 2011-05-03 00:56:48 --> Router Class Initialized
DEBUG - 2011-05-03 00:56:48 --> Output Class Initialized
DEBUG - 2011-05-03 00:56:48 --> Input Class Initialized
DEBUG - 2011-05-03 00:56:48 --> Global POST and COOKIE data sanitized
DEBUG - 2011-05-03 00:56:48 --> Language Class Initialized
DEBUG - 2011-05-03 00:56:48 --> Loader Class Initialized
DEBUG - 2011-05-03 00:56:48 --> Controller Class Initialized
DEBUG - 2011-05-03 00:56:48 --> Model Class Initialized
DEBUG - 2011-05-03 00:56:48 --> Model Class Initialized
DEBUG - 2011-05-03 00:56:48 --> Model Class Initialized
DEBUG - 2011-05-03 00:56:48 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-05-03 00:56:48 --> Database Driver Class Initialized
DEBUG - 2011-05-03 00:56:48 --> File loaded: application/views/table/main.php
DEBUG - 2011-05-03 00:56:48 --> Helper loaded: url_helper
DEBUG - 2011-05-03 00:56:48 --> File loaded: application/views/common/header.php
DEBUG - 2011-05-03 00:56:48 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-05-03 00:56:48 --> File loaded: application/views/common/footer.php
DEBUG - 2011-05-03 00:56:48 --> File loaded: application/views/layout/main.php
DEBUG - 2011-05-03 00:56:48 --> Final output sent to browser
DEBUG - 2011-05-03 00:56:48 --> Total execution time: 0.0459
DEBUG - 2011-05-03 00:56:48 --> Config Class Initialized
DEBUG - 2011-05-03 00:56:48 --> Hooks Class Initialized
DEBUG - 2011-05-03 00:56:48 --> Utf8 Class Initialized
DEBUG - 2011-05-03 00:56:48 --> UTF-8 Support Enabled
DEBUG - 2011-05-03 00:56:48 --> URI Class Initialized
DEBUG - 2011-05-03 00:56:48 --> Router Class Initialized
DEBUG - 2011-05-03 00:56:48 --> Output Class Initialized
DEBUG - 2011-05-03 00:56:48 --> Input Class Initialized
DEBUG - 2011-05-03 00:56:48 --> Global POST and COOKIE data sanitized
DEBUG - 2011-05-03 00:56:48 --> Language Class Initialized
DEBUG - 2011-05-03 00:56:48 --> Loader Class Initialized
DEBUG - 2011-05-03 00:56:48 --> Controller Class Initialized
DEBUG - 2011-05-03 00:56:48 --> Model Class Initialized
DEBUG - 2011-05-03 00:56:48 --> Model Class Initialized
DEBUG - 2011-05-03 00:56:48 --> Model Class Initialized
DEBUG - 2011-05-03 00:56:48 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-05-03 00:56:48 --> Database Driver Class Initialized
DEBUG - 2011-05-03 00:56:48 --> File loaded: application/views/table/main.php
DEBUG - 2011-05-03 00:56:48 --> Helper loaded: url_helper
DEBUG - 2011-05-03 00:56:48 --> File loaded: application/views/common/header.php
DEBUG - 2011-05-03 00:56:48 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-05-03 00:56:48 --> File loaded: application/views/common/footer.php
DEBUG - 2011-05-03 00:56:48 --> File loaded: application/views/layout/main.php
DEBUG - 2011-05-03 00:56:48 --> Final output sent to browser
DEBUG - 2011-05-03 00:56:48 --> Total execution time: 0.0635
DEBUG - 2011-05-03 02:29:34 --> Config Class Initialized
DEBUG - 2011-05-03 02:29:34 --> Hooks Class Initialized
DEBUG - 2011-05-03 02:29:34 --> Utf8 Class Initialized
DEBUG - 2011-05-03 02:29:34 --> UTF-8 Support Enabled
DEBUG - 2011-05-03 02:29:34 --> URI Class Initialized
DEBUG - 2011-05-03 02:29:34 --> Router Class Initialized
ERROR - 2011-05-03 02:29:34 --> 404 Page Not Found --> robots.txt
DEBUG - 2011-05-03 02:29:35 --> Config Class Initialized
DEBUG - 2011-05-03 02:29:35 --> Hooks Class Initialized
DEBUG - 2011-05-03 02:29:35 --> Utf8 Class Initialized
DEBUG - 2011-05-03 02:29:35 --> UTF-8 Support Enabled
DEBUG - 2011-05-03 02:29:35 --> URI Class Initialized
DEBUG - 2011-05-03 02:29:35 --> Router Class Initialized
DEBUG - 2011-05-03 02:29:35 --> Output Class Initialized
DEBUG - 2011-05-03 02:29:35 --> Input Class Initialized
DEBUG - 2011-05-03 02:29:35 --> Global POST and COOKIE data sanitized
DEBUG - 2011-05-03 02:29:35 --> Language Class Initialized
DEBUG - 2011-05-03 02:29:35 --> Loader Class Initialized
DEBUG - 2011-05-03 02:29:35 --> Controller Class Initialized
ERROR - 2011-05-03 02:29:35 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-05-03 02:29:35 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-05-03 02:29:35 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-05-03 02:29:35 --> Model Class Initialized
DEBUG - 2011-05-03 02:29:35 --> Model Class Initialized
DEBUG - 2011-05-03 02:29:35 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-05-03 02:29:35 --> Database Driver Class Initialized
DEBUG - 2011-05-03 02:29:36 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-05-03 02:29:36 --> Helper loaded: url_helper
DEBUG - 2011-05-03 02:29:36 --> File loaded: application/views/common/header.php
DEBUG - 2011-05-03 02:29:36 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-05-03 02:29:36 --> File loaded: application/views/common/footer.php
DEBUG - 2011-05-03 02:29:36 --> File loaded: application/views/layout/main.php
DEBUG - 2011-05-03 02:29:36 --> Final output sent to browser
DEBUG - 2011-05-03 02:29:36 --> Total execution time: 0.6863
DEBUG - 2011-05-03 03:23:21 --> Config Class Initialized
DEBUG - 2011-05-03 03:23:21 --> Hooks Class Initialized
DEBUG - 2011-05-03 03:23:21 --> Utf8 Class Initialized
DEBUG - 2011-05-03 03:23:21 --> UTF-8 Support Enabled
DEBUG - 2011-05-03 03:23:21 --> URI Class Initialized
DEBUG - 2011-05-03 03:23:21 --> Router Class Initialized
DEBUG - 2011-05-03 03:23:21 --> Output Class Initialized
DEBUG - 2011-05-03 03:23:21 --> Input Class Initialized
DEBUG - 2011-05-03 03:23:21 --> Global POST and COOKIE data sanitized
DEBUG - 2011-05-03 03:23:21 --> Language Class Initialized
DEBUG - 2011-05-03 03:23:21 --> Loader Class Initialized
DEBUG - 2011-05-03 03:23:21 --> Controller Class Initialized
DEBUG - 2011-05-03 03:23:21 --> Model Class Initialized
DEBUG - 2011-05-03 03:23:21 --> Model Class Initialized
DEBUG - 2011-05-03 03:23:21 --> Model Class Initialized
DEBUG - 2011-05-03 03:23:21 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-05-03 03:23:22 --> Database Driver Class Initialized
DEBUG - 2011-05-03 03:23:26 --> File loaded: application/views/table/main.php
DEBUG - 2011-05-03 03:23:26 --> Helper loaded: url_helper
DEBUG - 2011-05-03 03:23:26 --> File loaded: application/views/common/header.php
DEBUG - 2011-05-03 03:23:26 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-05-03 03:23:26 --> File loaded: application/views/common/footer.php
DEBUG - 2011-05-03 03:23:26 --> File loaded: application/views/layout/main.php
DEBUG - 2011-05-03 03:23:26 --> Final output sent to browser
DEBUG - 2011-05-03 03:23:26 --> Total execution time: 5.5453
DEBUG - 2011-05-03 05:09:23 --> Config Class Initialized
DEBUG - 2011-05-03 05:09:23 --> Hooks Class Initialized
DEBUG - 2011-05-03 05:09:24 --> Utf8 Class Initialized
DEBUG - 2011-05-03 05:09:24 --> UTF-8 Support Enabled
DEBUG - 2011-05-03 05:09:24 --> URI Class Initialized
DEBUG - 2011-05-03 05:09:24 --> Router Class Initialized
DEBUG - 2011-05-03 05:09:24 --> Output Class Initialized
DEBUG - 2011-05-03 05:09:24 --> Input Class Initialized
DEBUG - 2011-05-03 05:09:24 --> Global POST and COOKIE data sanitized
DEBUG - 2011-05-03 05:09:24 --> Language Class Initialized
DEBUG - 2011-05-03 05:09:24 --> Loader Class Initialized
DEBUG - 2011-05-03 05:09:24 --> Controller Class Initialized
ERROR - 2011-05-03 05:09:24 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-05-03 05:09:24 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-05-03 05:09:24 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-05-03 05:09:25 --> Model Class Initialized
DEBUG - 2011-05-03 05:09:25 --> Model Class Initialized
DEBUG - 2011-05-03 05:09:25 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-05-03 05:09:26 --> Database Driver Class Initialized
DEBUG - 2011-05-03 05:09:28 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-05-03 05:09:28 --> Helper loaded: url_helper
DEBUG - 2011-05-03 05:09:28 --> File loaded: application/views/common/header.php
DEBUG - 2011-05-03 05:09:28 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-05-03 05:09:28 --> File loaded: application/views/common/footer.php
DEBUG - 2011-05-03 05:09:28 --> File loaded: application/views/layout/main.php
DEBUG - 2011-05-03 05:09:28 --> Final output sent to browser
DEBUG - 2011-05-03 05:09:28 --> Total execution time: 4.5939
DEBUG - 2011-05-03 05:09:29 --> Config Class Initialized
DEBUG - 2011-05-03 05:09:29 --> Hooks Class Initialized
DEBUG - 2011-05-03 05:09:29 --> Utf8 Class Initialized
DEBUG - 2011-05-03 05:09:29 --> UTF-8 Support Enabled
DEBUG - 2011-05-03 05:09:29 --> URI Class Initialized
DEBUG - 2011-05-03 05:09:29 --> Router Class Initialized
DEBUG - 2011-05-03 05:09:29 --> Output Class Initialized
DEBUG - 2011-05-03 05:09:29 --> Input Class Initialized
DEBUG - 2011-05-03 05:09:29 --> Global POST and COOKIE data sanitized
DEBUG - 2011-05-03 05:09:29 --> Language Class Initialized
DEBUG - 2011-05-03 05:09:29 --> Loader Class Initialized
DEBUG - 2011-05-03 05:09:29 --> Controller Class Initialized
DEBUG - 2011-05-03 05:09:29 --> Model Class Initialized
DEBUG - 2011-05-03 05:09:29 --> Model Class Initialized
DEBUG - 2011-05-03 05:09:29 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-05-03 05:09:29 --> Database Driver Class Initialized
DEBUG - 2011-05-03 05:09:30 --> Final output sent to browser
DEBUG - 2011-05-03 05:09:30 --> Total execution time: 0.8410
DEBUG - 2011-05-03 05:09:31 --> Config Class Initialized
DEBUG - 2011-05-03 05:09:31 --> Hooks Class Initialized
DEBUG - 2011-05-03 05:09:31 --> Utf8 Class Initialized
DEBUG - 2011-05-03 05:09:31 --> UTF-8 Support Enabled
DEBUG - 2011-05-03 05:09:31 --> URI Class Initialized
DEBUG - 2011-05-03 05:09:31 --> Router Class Initialized
ERROR - 2011-05-03 05:09:31 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-05-03 05:09:32 --> Config Class Initialized
DEBUG - 2011-05-03 05:09:32 --> Hooks Class Initialized
DEBUG - 2011-05-03 05:09:32 --> Utf8 Class Initialized
DEBUG - 2011-05-03 05:09:32 --> UTF-8 Support Enabled
DEBUG - 2011-05-03 05:09:32 --> URI Class Initialized
DEBUG - 2011-05-03 05:09:32 --> Router Class Initialized
ERROR - 2011-05-03 05:09:32 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-05-03 05:09:32 --> Config Class Initialized
DEBUG - 2011-05-03 05:09:32 --> Hooks Class Initialized
DEBUG - 2011-05-03 05:09:32 --> Utf8 Class Initialized
DEBUG - 2011-05-03 05:09:32 --> UTF-8 Support Enabled
DEBUG - 2011-05-03 05:09:32 --> URI Class Initialized
DEBUG - 2011-05-03 05:09:32 --> Router Class Initialized
ERROR - 2011-05-03 05:09:32 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-05-03 05:09:40 --> Config Class Initialized
DEBUG - 2011-05-03 05:09:40 --> Hooks Class Initialized
DEBUG - 2011-05-03 05:09:40 --> Utf8 Class Initialized
DEBUG - 2011-05-03 05:09:40 --> UTF-8 Support Enabled
DEBUG - 2011-05-03 05:09:40 --> URI Class Initialized
DEBUG - 2011-05-03 05:09:40 --> Router Class Initialized
DEBUG - 2011-05-03 05:09:40 --> Output Class Initialized
DEBUG - 2011-05-03 05:09:40 --> Input Class Initialized
DEBUG - 2011-05-03 05:09:40 --> Global POST and COOKIE data sanitized
DEBUG - 2011-05-03 05:09:40 --> Language Class Initialized
DEBUG - 2011-05-03 05:09:40 --> Loader Class Initialized
DEBUG - 2011-05-03 05:09:40 --> Controller Class Initialized
ERROR - 2011-05-03 05:09:40 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-05-03 05:09:40 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-05-03 05:09:40 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-05-03 05:09:40 --> Model Class Initialized
DEBUG - 2011-05-03 05:09:40 --> Model Class Initialized
DEBUG - 2011-05-03 05:09:40 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-05-03 05:09:40 --> Database Driver Class Initialized
DEBUG - 2011-05-03 05:09:40 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-05-03 05:09:40 --> Helper loaded: url_helper
DEBUG - 2011-05-03 05:09:40 --> File loaded: application/views/common/header.php
DEBUG - 2011-05-03 05:09:40 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-05-03 05:09:40 --> File loaded: application/views/common/footer.php
DEBUG - 2011-05-03 05:09:40 --> File loaded: application/views/layout/main.php
DEBUG - 2011-05-03 05:09:40 --> Final output sent to browser
DEBUG - 2011-05-03 05:09:40 --> Total execution time: 0.0304
DEBUG - 2011-05-03 05:09:41 --> Config Class Initialized
DEBUG - 2011-05-03 05:09:41 --> Hooks Class Initialized
DEBUG - 2011-05-03 05:09:41 --> Utf8 Class Initialized
DEBUG - 2011-05-03 05:09:41 --> UTF-8 Support Enabled
DEBUG - 2011-05-03 05:09:41 --> URI Class Initialized
DEBUG - 2011-05-03 05:09:41 --> Router Class Initialized
DEBUG - 2011-05-03 05:09:41 --> Output Class Initialized
DEBUG - 2011-05-03 05:09:41 --> Input Class Initialized
DEBUG - 2011-05-03 05:09:41 --> Global POST and COOKIE data sanitized
DEBUG - 2011-05-03 05:09:41 --> Language Class Initialized
DEBUG - 2011-05-03 05:09:41 --> Loader Class Initialized
DEBUG - 2011-05-03 05:09:41 --> Controller Class Initialized
DEBUG - 2011-05-03 05:09:41 --> Model Class Initialized
DEBUG - 2011-05-03 05:09:41 --> Model Class Initialized
DEBUG - 2011-05-03 05:09:41 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-05-03 05:09:41 --> Database Driver Class Initialized
DEBUG - 2011-05-03 05:09:41 --> Final output sent to browser
DEBUG - 2011-05-03 05:09:41 --> Total execution time: 0.7119
DEBUG - 2011-05-03 05:09:46 --> Config Class Initialized
DEBUG - 2011-05-03 05:09:46 --> Hooks Class Initialized
DEBUG - 2011-05-03 05:09:46 --> Utf8 Class Initialized
DEBUG - 2011-05-03 05:09:46 --> UTF-8 Support Enabled
DEBUG - 2011-05-03 05:09:46 --> URI Class Initialized
DEBUG - 2011-05-03 05:09:46 --> Router Class Initialized
DEBUG - 2011-05-03 05:09:46 --> Output Class Initialized
DEBUG - 2011-05-03 05:09:46 --> Input Class Initialized
DEBUG - 2011-05-03 05:09:46 --> Global POST and COOKIE data sanitized
DEBUG - 2011-05-03 05:09:46 --> Language Class Initialized
DEBUG - 2011-05-03 05:09:46 --> Loader Class Initialized
DEBUG - 2011-05-03 05:09:46 --> Controller Class Initialized
ERROR - 2011-05-03 05:09:46 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-05-03 05:09:46 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-05-03 05:09:46 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-05-03 05:09:46 --> Model Class Initialized
DEBUG - 2011-05-03 05:09:46 --> Model Class Initialized
DEBUG - 2011-05-03 05:09:46 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-05-03 05:09:46 --> Database Driver Class Initialized
DEBUG - 2011-05-03 05:09:46 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-05-03 05:09:46 --> Helper loaded: url_helper
DEBUG - 2011-05-03 05:09:46 --> File loaded: application/views/common/header.php
DEBUG - 2011-05-03 05:09:46 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-05-03 05:09:46 --> File loaded: application/views/common/footer.php
DEBUG - 2011-05-03 05:09:46 --> File loaded: application/views/layout/main.php
DEBUG - 2011-05-03 05:09:46 --> Final output sent to browser
DEBUG - 2011-05-03 05:09:46 --> Total execution time: 0.0302
DEBUG - 2011-05-03 05:09:47 --> Config Class Initialized
DEBUG - 2011-05-03 05:09:47 --> Hooks Class Initialized
DEBUG - 2011-05-03 05:09:47 --> Utf8 Class Initialized
DEBUG - 2011-05-03 05:09:47 --> UTF-8 Support Enabled
DEBUG - 2011-05-03 05:09:47 --> URI Class Initialized
DEBUG - 2011-05-03 05:09:47 --> Router Class Initialized
DEBUG - 2011-05-03 05:09:47 --> Output Class Initialized
DEBUG - 2011-05-03 05:09:47 --> Input Class Initialized
DEBUG - 2011-05-03 05:09:47 --> Global POST and COOKIE data sanitized
DEBUG - 2011-05-03 05:09:47 --> Language Class Initialized
DEBUG - 2011-05-03 05:09:47 --> Loader Class Initialized
DEBUG - 2011-05-03 05:09:47 --> Controller Class Initialized
DEBUG - 2011-05-03 05:09:47 --> Model Class Initialized
DEBUG - 2011-05-03 05:09:47 --> Model Class Initialized
DEBUG - 2011-05-03 05:09:47 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-05-03 05:09:47 --> Database Driver Class Initialized
DEBUG - 2011-05-03 05:09:47 --> Final output sent to browser
DEBUG - 2011-05-03 05:09:47 --> Total execution time: 0.5036
DEBUG - 2011-05-03 05:09:55 --> Config Class Initialized
DEBUG - 2011-05-03 05:09:55 --> Hooks Class Initialized
DEBUG - 2011-05-03 05:09:55 --> Utf8 Class Initialized
DEBUG - 2011-05-03 05:09:55 --> UTF-8 Support Enabled
DEBUG - 2011-05-03 05:09:55 --> URI Class Initialized
DEBUG - 2011-05-03 05:09:55 --> Router Class Initialized
DEBUG - 2011-05-03 05:09:55 --> Output Class Initialized
DEBUG - 2011-05-03 05:09:55 --> Input Class Initialized
DEBUG - 2011-05-03 05:09:55 --> Global POST and COOKIE data sanitized
DEBUG - 2011-05-03 05:09:55 --> Language Class Initialized
DEBUG - 2011-05-03 05:09:55 --> Loader Class Initialized
DEBUG - 2011-05-03 05:09:55 --> Controller Class Initialized
ERROR - 2011-05-03 05:09:55 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-05-03 05:09:55 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-05-03 05:09:55 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-05-03 05:09:55 --> Model Class Initialized
DEBUG - 2011-05-03 05:09:55 --> Model Class Initialized
DEBUG - 2011-05-03 05:09:55 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-05-03 05:09:55 --> Database Driver Class Initialized
DEBUG - 2011-05-03 05:09:55 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-05-03 05:09:55 --> Helper loaded: url_helper
DEBUG - 2011-05-03 05:09:55 --> File loaded: application/views/common/header.php
DEBUG - 2011-05-03 05:09:55 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-05-03 05:09:55 --> File loaded: application/views/common/footer.php
DEBUG - 2011-05-03 05:09:55 --> File loaded: application/views/layout/main.php
DEBUG - 2011-05-03 05:09:55 --> Final output sent to browser
DEBUG - 2011-05-03 05:09:55 --> Total execution time: 0.0333
DEBUG - 2011-05-03 05:09:56 --> Config Class Initialized
DEBUG - 2011-05-03 05:09:56 --> Hooks Class Initialized
DEBUG - 2011-05-03 05:09:56 --> Utf8 Class Initialized
DEBUG - 2011-05-03 05:09:56 --> UTF-8 Support Enabled
DEBUG - 2011-05-03 05:09:56 --> URI Class Initialized
DEBUG - 2011-05-03 05:09:56 --> Router Class Initialized
DEBUG - 2011-05-03 05:09:56 --> Output Class Initialized
DEBUG - 2011-05-03 05:09:56 --> Input Class Initialized
DEBUG - 2011-05-03 05:09:56 --> Global POST and COOKIE data sanitized
DEBUG - 2011-05-03 05:09:56 --> Language Class Initialized
DEBUG - 2011-05-03 05:09:56 --> Loader Class Initialized
DEBUG - 2011-05-03 05:09:56 --> Controller Class Initialized
DEBUG - 2011-05-03 05:09:56 --> Model Class Initialized
DEBUG - 2011-05-03 05:09:56 --> Model Class Initialized
DEBUG - 2011-05-03 05:09:56 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-05-03 05:09:56 --> Database Driver Class Initialized
DEBUG - 2011-05-03 05:09:57 --> Final output sent to browser
DEBUG - 2011-05-03 05:09:57 --> Total execution time: 1.0271
DEBUG - 2011-05-03 05:09:58 --> Config Class Initialized
DEBUG - 2011-05-03 05:09:58 --> Hooks Class Initialized
DEBUG - 2011-05-03 05:09:58 --> Utf8 Class Initialized
DEBUG - 2011-05-03 05:09:58 --> UTF-8 Support Enabled
DEBUG - 2011-05-03 05:09:58 --> URI Class Initialized
DEBUG - 2011-05-03 05:09:58 --> Router Class Initialized
DEBUG - 2011-05-03 05:09:58 --> Output Class Initialized
DEBUG - 2011-05-03 05:09:58 --> Input Class Initialized
DEBUG - 2011-05-03 05:09:58 --> Global POST and COOKIE data sanitized
DEBUG - 2011-05-03 05:09:58 --> Language Class Initialized
DEBUG - 2011-05-03 05:09:58 --> Loader Class Initialized
DEBUG - 2011-05-03 05:09:58 --> Controller Class Initialized
ERROR - 2011-05-03 05:09:58 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-05-03 05:09:58 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-05-03 05:09:58 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-05-03 05:09:58 --> Model Class Initialized
DEBUG - 2011-05-03 05:09:58 --> Model Class Initialized
DEBUG - 2011-05-03 05:09:58 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-05-03 05:09:58 --> Database Driver Class Initialized
DEBUG - 2011-05-03 05:09:58 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-05-03 05:09:58 --> Helper loaded: url_helper
DEBUG - 2011-05-03 05:09:58 --> File loaded: application/views/common/header.php
DEBUG - 2011-05-03 05:09:58 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-05-03 05:09:58 --> File loaded: application/views/common/footer.php
DEBUG - 2011-05-03 05:09:58 --> File loaded: application/views/layout/main.php
DEBUG - 2011-05-03 05:09:58 --> Final output sent to browser
DEBUG - 2011-05-03 05:09:58 --> Total execution time: 0.0485
DEBUG - 2011-05-03 05:10:06 --> Config Class Initialized
DEBUG - 2011-05-03 05:10:06 --> Hooks Class Initialized
DEBUG - 2011-05-03 05:10:06 --> Utf8 Class Initialized
DEBUG - 2011-05-03 05:10:06 --> UTF-8 Support Enabled
DEBUG - 2011-05-03 05:10:06 --> URI Class Initialized
DEBUG - 2011-05-03 05:10:06 --> Router Class Initialized
DEBUG - 2011-05-03 05:10:06 --> Output Class Initialized
DEBUG - 2011-05-03 05:10:06 --> Input Class Initialized
DEBUG - 2011-05-03 05:10:06 --> Global POST and COOKIE data sanitized
DEBUG - 2011-05-03 05:10:06 --> Language Class Initialized
DEBUG - 2011-05-03 05:10:06 --> Loader Class Initialized
DEBUG - 2011-05-03 05:10:06 --> Controller Class Initialized
ERROR - 2011-05-03 05:10:06 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-05-03 05:10:06 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-05-03 05:10:06 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-05-03 05:10:06 --> Model Class Initialized
DEBUG - 2011-05-03 05:10:06 --> Model Class Initialized
DEBUG - 2011-05-03 05:10:06 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-05-03 05:10:06 --> Database Driver Class Initialized
DEBUG - 2011-05-03 05:10:06 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-05-03 05:10:06 --> Helper loaded: url_helper
DEBUG - 2011-05-03 05:10:06 --> File loaded: application/views/common/header.php
DEBUG - 2011-05-03 05:10:06 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-05-03 05:10:06 --> File loaded: application/views/common/footer.php
DEBUG - 2011-05-03 05:10:06 --> File loaded: application/views/layout/main.php
DEBUG - 2011-05-03 05:10:06 --> Final output sent to browser
DEBUG - 2011-05-03 05:10:06 --> Total execution time: 0.0295
DEBUG - 2011-05-03 05:10:07 --> Config Class Initialized
DEBUG - 2011-05-03 05:10:07 --> Hooks Class Initialized
DEBUG - 2011-05-03 05:10:07 --> Utf8 Class Initialized
DEBUG - 2011-05-03 05:10:07 --> UTF-8 Support Enabled
DEBUG - 2011-05-03 05:10:07 --> URI Class Initialized
DEBUG - 2011-05-03 05:10:07 --> Router Class Initialized
DEBUG - 2011-05-03 05:10:07 --> Output Class Initialized
DEBUG - 2011-05-03 05:10:07 --> Input Class Initialized
DEBUG - 2011-05-03 05:10:07 --> Global POST and COOKIE data sanitized
DEBUG - 2011-05-03 05:10:07 --> Language Class Initialized
DEBUG - 2011-05-03 05:10:07 --> Loader Class Initialized
DEBUG - 2011-05-03 05:10:07 --> Controller Class Initialized
DEBUG - 2011-05-03 05:10:07 --> Model Class Initialized
DEBUG - 2011-05-03 05:10:07 --> Model Class Initialized
DEBUG - 2011-05-03 05:10:07 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-05-03 05:10:07 --> Database Driver Class Initialized
DEBUG - 2011-05-03 05:10:07 --> Final output sent to browser
DEBUG - 2011-05-03 05:10:07 --> Total execution time: 0.6149
DEBUG - 2011-05-03 05:10:12 --> Config Class Initialized
DEBUG - 2011-05-03 05:10:12 --> Hooks Class Initialized
DEBUG - 2011-05-03 05:10:12 --> Utf8 Class Initialized
DEBUG - 2011-05-03 05:10:12 --> UTF-8 Support Enabled
DEBUG - 2011-05-03 05:10:12 --> URI Class Initialized
DEBUG - 2011-05-03 05:10:12 --> Router Class Initialized
DEBUG - 2011-05-03 05:10:12 --> Output Class Initialized
DEBUG - 2011-05-03 05:10:12 --> Input Class Initialized
DEBUG - 2011-05-03 05:10:12 --> Global POST and COOKIE data sanitized
DEBUG - 2011-05-03 05:10:12 --> Language Class Initialized
DEBUG - 2011-05-03 05:10:12 --> Loader Class Initialized
DEBUG - 2011-05-03 05:10:12 --> Controller Class Initialized
ERROR - 2011-05-03 05:10:12 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-05-03 05:10:12 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-05-03 05:10:12 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-05-03 05:10:12 --> Model Class Initialized
DEBUG - 2011-05-03 05:10:12 --> Model Class Initialized
DEBUG - 2011-05-03 05:10:12 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-05-03 05:10:12 --> Database Driver Class Initialized
DEBUG - 2011-05-03 05:10:12 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-05-03 05:10:12 --> Helper loaded: url_helper
DEBUG - 2011-05-03 05:10:12 --> File loaded: application/views/common/header.php
DEBUG - 2011-05-03 05:10:12 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-05-03 05:10:12 --> File loaded: application/views/common/footer.php
DEBUG - 2011-05-03 05:10:12 --> File loaded: application/views/layout/main.php
DEBUG - 2011-05-03 05:10:12 --> Final output sent to browser
DEBUG - 2011-05-03 05:10:12 --> Total execution time: 0.1517
DEBUG - 2011-05-03 05:10:21 --> Config Class Initialized
DEBUG - 2011-05-03 05:10:21 --> Hooks Class Initialized
DEBUG - 2011-05-03 05:10:21 --> Utf8 Class Initialized
DEBUG - 2011-05-03 05:10:21 --> UTF-8 Support Enabled
DEBUG - 2011-05-03 05:10:21 --> URI Class Initialized
DEBUG - 2011-05-03 05:10:21 --> Router Class Initialized
DEBUG - 2011-05-03 05:10:21 --> Output Class Initialized
DEBUG - 2011-05-03 05:10:21 --> Input Class Initialized
DEBUG - 2011-05-03 05:10:21 --> Global POST and COOKIE data sanitized
DEBUG - 2011-05-03 05:10:21 --> Language Class Initialized
DEBUG - 2011-05-03 05:10:21 --> Loader Class Initialized
DEBUG - 2011-05-03 05:10:21 --> Controller Class Initialized
ERROR - 2011-05-03 05:10:21 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-05-03 05:10:21 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-05-03 05:10:21 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-05-03 05:10:21 --> Model Class Initialized
DEBUG - 2011-05-03 05:10:21 --> Model Class Initialized
DEBUG - 2011-05-03 05:10:21 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-05-03 05:10:21 --> Database Driver Class Initialized
DEBUG - 2011-05-03 05:10:21 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-05-03 05:10:21 --> Helper loaded: url_helper
DEBUG - 2011-05-03 05:10:21 --> File loaded: application/views/common/header.php
DEBUG - 2011-05-03 05:10:21 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-05-03 05:10:21 --> File loaded: application/views/common/footer.php
DEBUG - 2011-05-03 05:10:21 --> File loaded: application/views/layout/main.php
DEBUG - 2011-05-03 05:10:21 --> Final output sent to browser
DEBUG - 2011-05-03 05:10:21 --> Total execution time: 0.1633
DEBUG - 2011-05-03 05:10:23 --> Config Class Initialized
DEBUG - 2011-05-03 05:10:23 --> Hooks Class Initialized
DEBUG - 2011-05-03 05:10:23 --> Utf8 Class Initialized
DEBUG - 2011-05-03 05:10:23 --> UTF-8 Support Enabled
DEBUG - 2011-05-03 05:10:23 --> URI Class Initialized
DEBUG - 2011-05-03 05:10:23 --> Router Class Initialized
DEBUG - 2011-05-03 05:10:23 --> Output Class Initialized
DEBUG - 2011-05-03 05:10:23 --> Input Class Initialized
DEBUG - 2011-05-03 05:10:23 --> Global POST and COOKIE data sanitized
DEBUG - 2011-05-03 05:10:23 --> Language Class Initialized
DEBUG - 2011-05-03 05:10:23 --> Loader Class Initialized
DEBUG - 2011-05-03 05:10:23 --> Controller Class Initialized
DEBUG - 2011-05-03 05:10:23 --> Model Class Initialized
DEBUG - 2011-05-03 05:10:23 --> Model Class Initialized
DEBUG - 2011-05-03 05:10:23 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-05-03 05:10:23 --> Database Driver Class Initialized
DEBUG - 2011-05-03 05:10:29 --> Final output sent to browser
DEBUG - 2011-05-03 05:10:29 --> Total execution time: 5.7984
DEBUG - 2011-05-03 05:10:34 --> Config Class Initialized
DEBUG - 2011-05-03 05:10:34 --> Hooks Class Initialized
DEBUG - 2011-05-03 05:10:34 --> Utf8 Class Initialized
DEBUG - 2011-05-03 05:10:34 --> UTF-8 Support Enabled
DEBUG - 2011-05-03 05:10:34 --> URI Class Initialized
DEBUG - 2011-05-03 05:10:34 --> Router Class Initialized
DEBUG - 2011-05-03 05:10:34 --> Output Class Initialized
DEBUG - 2011-05-03 05:10:34 --> Input Class Initialized
DEBUG - 2011-05-03 05:10:34 --> Global POST and COOKIE data sanitized
DEBUG - 2011-05-03 05:10:34 --> Language Class Initialized
DEBUG - 2011-05-03 05:10:34 --> Loader Class Initialized
DEBUG - 2011-05-03 05:10:34 --> Controller Class Initialized
ERROR - 2011-05-03 05:10:34 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-05-03 05:10:34 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-05-03 05:10:34 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-05-03 05:10:34 --> Model Class Initialized
DEBUG - 2011-05-03 05:10:34 --> Model Class Initialized
DEBUG - 2011-05-03 05:10:34 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-05-03 05:10:34 --> Database Driver Class Initialized
DEBUG - 2011-05-03 05:10:34 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-05-03 05:10:34 --> Helper loaded: url_helper
DEBUG - 2011-05-03 05:10:34 --> File loaded: application/views/common/header.php
DEBUG - 2011-05-03 05:10:34 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-05-03 05:10:34 --> File loaded: application/views/common/footer.php
DEBUG - 2011-05-03 05:10:34 --> File loaded: application/views/layout/main.php
DEBUG - 2011-05-03 05:10:34 --> Final output sent to browser
DEBUG - 2011-05-03 05:10:34 --> Total execution time: 0.2655
DEBUG - 2011-05-03 05:10:38 --> Config Class Initialized
DEBUG - 2011-05-03 05:10:38 --> Hooks Class Initialized
DEBUG - 2011-05-03 05:10:38 --> Utf8 Class Initialized
DEBUG - 2011-05-03 05:10:38 --> UTF-8 Support Enabled
DEBUG - 2011-05-03 05:10:38 --> URI Class Initialized
DEBUG - 2011-05-03 05:10:38 --> Router Class Initialized
DEBUG - 2011-05-03 05:10:38 --> Output Class Initialized
DEBUG - 2011-05-03 05:10:38 --> Input Class Initialized
DEBUG - 2011-05-03 05:10:38 --> Global POST and COOKIE data sanitized
DEBUG - 2011-05-03 05:10:38 --> Language Class Initialized
DEBUG - 2011-05-03 05:10:38 --> Loader Class Initialized
DEBUG - 2011-05-03 05:10:38 --> Controller Class Initialized
ERROR - 2011-05-03 05:10:38 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-05-03 05:10:38 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-05-03 05:10:38 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-05-03 05:10:38 --> Model Class Initialized
DEBUG - 2011-05-03 05:10:38 --> Model Class Initialized
DEBUG - 2011-05-03 05:10:38 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-05-03 05:10:38 --> Database Driver Class Initialized
DEBUG - 2011-05-03 05:10:38 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-05-03 05:10:38 --> Helper loaded: url_helper
DEBUG - 2011-05-03 05:10:38 --> File loaded: application/views/common/header.php
DEBUG - 2011-05-03 05:10:38 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-05-03 05:10:38 --> File loaded: application/views/common/footer.php
DEBUG - 2011-05-03 05:10:38 --> File loaded: application/views/layout/main.php
DEBUG - 2011-05-03 05:10:38 --> Final output sent to browser
DEBUG - 2011-05-03 05:10:38 --> Total execution time: 0.0981
DEBUG - 2011-05-03 05:10:39 --> Config Class Initialized
DEBUG - 2011-05-03 05:10:39 --> Hooks Class Initialized
DEBUG - 2011-05-03 05:10:39 --> Utf8 Class Initialized
DEBUG - 2011-05-03 05:10:39 --> UTF-8 Support Enabled
DEBUG - 2011-05-03 05:10:39 --> URI Class Initialized
DEBUG - 2011-05-03 05:10:39 --> Router Class Initialized
DEBUG - 2011-05-03 05:10:39 --> Output Class Initialized
DEBUG - 2011-05-03 05:10:39 --> Input Class Initialized
DEBUG - 2011-05-03 05:10:39 --> Global POST and COOKIE data sanitized
DEBUG - 2011-05-03 05:10:39 --> Language Class Initialized
DEBUG - 2011-05-03 05:10:39 --> Loader Class Initialized
DEBUG - 2011-05-03 05:10:39 --> Controller Class Initialized
DEBUG - 2011-05-03 05:10:39 --> Model Class Initialized
DEBUG - 2011-05-03 05:10:39 --> Model Class Initialized
DEBUG - 2011-05-03 05:10:39 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-05-03 05:10:39 --> Database Driver Class Initialized
DEBUG - 2011-05-03 05:10:39 --> Final output sent to browser
DEBUG - 2011-05-03 05:10:39 --> Total execution time: 0.7540
DEBUG - 2011-05-03 05:10:53 --> Config Class Initialized
DEBUG - 2011-05-03 05:10:53 --> Hooks Class Initialized
DEBUG - 2011-05-03 05:10:53 --> Utf8 Class Initialized
DEBUG - 2011-05-03 05:10:53 --> UTF-8 Support Enabled
DEBUG - 2011-05-03 05:10:53 --> URI Class Initialized
DEBUG - 2011-05-03 05:10:53 --> Router Class Initialized
DEBUG - 2011-05-03 05:10:53 --> Output Class Initialized
DEBUG - 2011-05-03 05:10:53 --> Input Class Initialized
DEBUG - 2011-05-03 05:10:53 --> Global POST and COOKIE data sanitized
DEBUG - 2011-05-03 05:10:53 --> Language Class Initialized
DEBUG - 2011-05-03 05:10:53 --> Loader Class Initialized
DEBUG - 2011-05-03 05:10:53 --> Controller Class Initialized
ERROR - 2011-05-03 05:10:53 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-05-03 05:10:53 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-05-03 05:10:53 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-05-03 05:10:53 --> Model Class Initialized
DEBUG - 2011-05-03 05:10:53 --> Model Class Initialized
DEBUG - 2011-05-03 05:10:53 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-05-03 05:10:53 --> Database Driver Class Initialized
DEBUG - 2011-05-03 05:10:53 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-05-03 05:10:53 --> Helper loaded: url_helper
DEBUG - 2011-05-03 05:10:53 --> File loaded: application/views/common/header.php
DEBUG - 2011-05-03 05:10:53 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-05-03 05:10:53 --> File loaded: application/views/common/footer.php
DEBUG - 2011-05-03 05:10:53 --> File loaded: application/views/layout/main.php
DEBUG - 2011-05-03 05:10:53 --> Final output sent to browser
DEBUG - 2011-05-03 05:10:53 --> Total execution time: 0.0390
DEBUG - 2011-05-03 05:10:54 --> Config Class Initialized
DEBUG - 2011-05-03 05:10:54 --> Hooks Class Initialized
DEBUG - 2011-05-03 05:10:54 --> Utf8 Class Initialized
DEBUG - 2011-05-03 05:10:54 --> UTF-8 Support Enabled
DEBUG - 2011-05-03 05:10:54 --> URI Class Initialized
DEBUG - 2011-05-03 05:10:54 --> Router Class Initialized
DEBUG - 2011-05-03 05:10:54 --> Output Class Initialized
DEBUG - 2011-05-03 05:10:54 --> Input Class Initialized
DEBUG - 2011-05-03 05:10:54 --> Global POST and COOKIE data sanitized
DEBUG - 2011-05-03 05:10:54 --> Language Class Initialized
DEBUG - 2011-05-03 05:10:54 --> Loader Class Initialized
DEBUG - 2011-05-03 05:10:54 --> Controller Class Initialized
DEBUG - 2011-05-03 05:10:54 --> Model Class Initialized
DEBUG - 2011-05-03 05:10:54 --> Model Class Initialized
DEBUG - 2011-05-03 05:10:54 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-05-03 05:10:54 --> Database Driver Class Initialized
DEBUG - 2011-05-03 05:10:55 --> Final output sent to browser
DEBUG - 2011-05-03 05:10:55 --> Total execution time: 0.5949
DEBUG - 2011-05-03 05:11:04 --> Config Class Initialized
DEBUG - 2011-05-03 05:11:04 --> Hooks Class Initialized
DEBUG - 2011-05-03 05:11:04 --> Utf8 Class Initialized
DEBUG - 2011-05-03 05:11:04 --> UTF-8 Support Enabled
DEBUG - 2011-05-03 05:11:04 --> URI Class Initialized
DEBUG - 2011-05-03 05:11:04 --> Router Class Initialized
DEBUG - 2011-05-03 05:11:04 --> Output Class Initialized
DEBUG - 2011-05-03 05:11:04 --> Input Class Initialized
DEBUG - 2011-05-03 05:11:04 --> Global POST and COOKIE data sanitized
DEBUG - 2011-05-03 05:11:04 --> Language Class Initialized
DEBUG - 2011-05-03 05:11:04 --> Loader Class Initialized
DEBUG - 2011-05-03 05:11:04 --> Controller Class Initialized
ERROR - 2011-05-03 05:11:04 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-05-03 05:11:04 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-05-03 05:11:04 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-05-03 05:11:04 --> Model Class Initialized
DEBUG - 2011-05-03 05:11:04 --> Model Class Initialized
DEBUG - 2011-05-03 05:11:04 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-05-03 05:11:04 --> Database Driver Class Initialized
DEBUG - 2011-05-03 05:11:04 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-05-03 05:11:04 --> Helper loaded: url_helper
DEBUG - 2011-05-03 05:11:04 --> File loaded: application/views/common/header.php
DEBUG - 2011-05-03 05:11:04 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-05-03 05:11:04 --> File loaded: application/views/common/footer.php
DEBUG - 2011-05-03 05:11:04 --> File loaded: application/views/layout/main.php
DEBUG - 2011-05-03 05:11:04 --> Final output sent to browser
DEBUG - 2011-05-03 05:11:04 --> Total execution time: 0.1497
DEBUG - 2011-05-03 05:11:05 --> Config Class Initialized
DEBUG - 2011-05-03 05:11:05 --> Hooks Class Initialized
DEBUG - 2011-05-03 05:11:05 --> Utf8 Class Initialized
DEBUG - 2011-05-03 05:11:05 --> UTF-8 Support Enabled
DEBUG - 2011-05-03 05:11:05 --> URI Class Initialized
DEBUG - 2011-05-03 05:11:05 --> Router Class Initialized
DEBUG - 2011-05-03 05:11:05 --> Output Class Initialized
DEBUG - 2011-05-03 05:11:05 --> Input Class Initialized
DEBUG - 2011-05-03 05:11:05 --> Global POST and COOKIE data sanitized
DEBUG - 2011-05-03 05:11:05 --> Language Class Initialized
DEBUG - 2011-05-03 05:11:05 --> Loader Class Initialized
DEBUG - 2011-05-03 05:11:05 --> Controller Class Initialized
DEBUG - 2011-05-03 05:11:05 --> Model Class Initialized
DEBUG - 2011-05-03 05:11:05 --> Model Class Initialized
DEBUG - 2011-05-03 05:11:05 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-05-03 05:11:05 --> Database Driver Class Initialized
DEBUG - 2011-05-03 05:11:06 --> Final output sent to browser
DEBUG - 2011-05-03 05:11:06 --> Total execution time: 1.3181
DEBUG - 2011-05-03 05:11:12 --> Config Class Initialized
DEBUG - 2011-05-03 05:11:12 --> Hooks Class Initialized
DEBUG - 2011-05-03 05:11:12 --> Utf8 Class Initialized
DEBUG - 2011-05-03 05:11:12 --> UTF-8 Support Enabled
DEBUG - 2011-05-03 05:11:12 --> URI Class Initialized
DEBUG - 2011-05-03 05:11:12 --> Router Class Initialized
DEBUG - 2011-05-03 05:11:12 --> Output Class Initialized
DEBUG - 2011-05-03 05:11:12 --> Input Class Initialized
DEBUG - 2011-05-03 05:11:12 --> Global POST and COOKIE data sanitized
DEBUG - 2011-05-03 05:11:12 --> Language Class Initialized
DEBUG - 2011-05-03 05:11:12 --> Loader Class Initialized
DEBUG - 2011-05-03 05:11:12 --> Controller Class Initialized
ERROR - 2011-05-03 05:11:12 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-05-03 05:11:12 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-05-03 05:11:12 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-05-03 05:11:12 --> Model Class Initialized
DEBUG - 2011-05-03 05:11:12 --> Model Class Initialized
DEBUG - 2011-05-03 05:11:12 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-05-03 05:11:12 --> Database Driver Class Initialized
DEBUG - 2011-05-03 05:11:12 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-05-03 05:11:12 --> Helper loaded: url_helper
DEBUG - 2011-05-03 05:11:12 --> File loaded: application/views/common/header.php
DEBUG - 2011-05-03 05:11:12 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-05-03 05:11:12 --> File loaded: application/views/common/footer.php
DEBUG - 2011-05-03 05:11:12 --> File loaded: application/views/layout/main.php
DEBUG - 2011-05-03 05:11:12 --> Final output sent to browser
DEBUG - 2011-05-03 05:11:12 --> Total execution time: 0.0547
DEBUG - 2011-05-03 05:11:13 --> Config Class Initialized
DEBUG - 2011-05-03 05:11:13 --> Hooks Class Initialized
DEBUG - 2011-05-03 05:11:13 --> Utf8 Class Initialized
DEBUG - 2011-05-03 05:11:13 --> UTF-8 Support Enabled
DEBUG - 2011-05-03 05:11:13 --> URI Class Initialized
DEBUG - 2011-05-03 05:11:13 --> Router Class Initialized
DEBUG - 2011-05-03 05:11:13 --> Output Class Initialized
DEBUG - 2011-05-03 05:11:13 --> Input Class Initialized
DEBUG - 2011-05-03 05:11:13 --> Global POST and COOKIE data sanitized
DEBUG - 2011-05-03 05:11:13 --> Language Class Initialized
DEBUG - 2011-05-03 05:11:13 --> Loader Class Initialized
DEBUG - 2011-05-03 05:11:13 --> Controller Class Initialized
DEBUG - 2011-05-03 05:11:13 --> Model Class Initialized
DEBUG - 2011-05-03 05:11:13 --> Model Class Initialized
DEBUG - 2011-05-03 05:11:13 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-05-03 05:11:13 --> Database Driver Class Initialized
DEBUG - 2011-05-03 05:11:14 --> Final output sent to browser
DEBUG - 2011-05-03 05:11:14 --> Total execution time: 0.4836
DEBUG - 2011-05-03 06:22:05 --> Config Class Initialized
DEBUG - 2011-05-03 06:22:05 --> Hooks Class Initialized
DEBUG - 2011-05-03 06:22:05 --> Utf8 Class Initialized
DEBUG - 2011-05-03 06:22:05 --> UTF-8 Support Enabled
DEBUG - 2011-05-03 06:22:05 --> URI Class Initialized
DEBUG - 2011-05-03 06:22:05 --> Router Class Initialized
DEBUG - 2011-05-03 06:22:05 --> Output Class Initialized
DEBUG - 2011-05-03 06:22:05 --> Input Class Initialized
DEBUG - 2011-05-03 06:22:05 --> Global POST and COOKIE data sanitized
DEBUG - 2011-05-03 06:22:05 --> Language Class Initialized
DEBUG - 2011-05-03 06:22:05 --> Loader Class Initialized
DEBUG - 2011-05-03 06:22:05 --> Controller Class Initialized
DEBUG - 2011-05-03 06:22:05 --> Model Class Initialized
DEBUG - 2011-05-03 06:22:05 --> Model Class Initialized
DEBUG - 2011-05-03 06:22:05 --> Model Class Initialized
DEBUG - 2011-05-03 06:22:05 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-05-03 06:22:05 --> Database Driver Class Initialized
DEBUG - 2011-05-03 06:22:07 --> File loaded: application/views/table/main.php
DEBUG - 2011-05-03 06:22:07 --> Helper loaded: url_helper
DEBUG - 2011-05-03 06:22:07 --> File loaded: application/views/common/header.php
DEBUG - 2011-05-03 06:22:07 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-05-03 06:22:07 --> File loaded: application/views/common/footer.php
DEBUG - 2011-05-03 06:22:07 --> File loaded: application/views/layout/main.php
DEBUG - 2011-05-03 06:22:07 --> Final output sent to browser
DEBUG - 2011-05-03 06:22:07 --> Total execution time: 2.1514
DEBUG - 2011-05-03 06:22:12 --> Config Class Initialized
DEBUG - 2011-05-03 06:22:12 --> Hooks Class Initialized
DEBUG - 2011-05-03 06:22:12 --> Utf8 Class Initialized
DEBUG - 2011-05-03 06:22:12 --> UTF-8 Support Enabled
DEBUG - 2011-05-03 06:22:12 --> URI Class Initialized
DEBUG - 2011-05-03 06:22:12 --> Router Class Initialized
DEBUG - 2011-05-03 06:22:12 --> Output Class Initialized
DEBUG - 2011-05-03 06:22:12 --> Input Class Initialized
DEBUG - 2011-05-03 06:22:12 --> Global POST and COOKIE data sanitized
DEBUG - 2011-05-03 06:22:12 --> Language Class Initialized
DEBUG - 2011-05-03 06:22:12 --> Loader Class Initialized
DEBUG - 2011-05-03 06:22:12 --> Controller Class Initialized
ERROR - 2011-05-03 06:22:12 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-05-03 06:22:12 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-05-03 06:22:12 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-05-03 06:22:12 --> Model Class Initialized
DEBUG - 2011-05-03 06:22:12 --> Model Class Initialized
DEBUG - 2011-05-03 06:22:12 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-05-03 06:22:12 --> Database Driver Class Initialized
DEBUG - 2011-05-03 06:22:12 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-05-03 06:22:12 --> Helper loaded: url_helper
DEBUG - 2011-05-03 06:22:12 --> File loaded: application/views/common/header.php
DEBUG - 2011-05-03 06:22:12 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-05-03 06:22:12 --> File loaded: application/views/common/footer.php
DEBUG - 2011-05-03 06:22:12 --> File loaded: application/views/layout/main.php
DEBUG - 2011-05-03 06:22:12 --> Final output sent to browser
DEBUG - 2011-05-03 06:22:12 --> Total execution time: 0.1231
DEBUG - 2011-05-03 06:30:59 --> Config Class Initialized
DEBUG - 2011-05-03 06:30:59 --> Hooks Class Initialized
DEBUG - 2011-05-03 06:30:59 --> Utf8 Class Initialized
DEBUG - 2011-05-03 06:30:59 --> UTF-8 Support Enabled
DEBUG - 2011-05-03 06:30:59 --> URI Class Initialized
DEBUG - 2011-05-03 06:30:59 --> Router Class Initialized
DEBUG - 2011-05-03 06:30:59 --> Output Class Initialized
DEBUG - 2011-05-03 06:30:59 --> Input Class Initialized
DEBUG - 2011-05-03 06:30:59 --> Global POST and COOKIE data sanitized
DEBUG - 2011-05-03 06:30:59 --> Language Class Initialized
DEBUG - 2011-05-03 06:30:59 --> Loader Class Initialized
DEBUG - 2011-05-03 06:30:59 --> Controller Class Initialized
DEBUG - 2011-05-03 06:30:59 --> Model Class Initialized
DEBUG - 2011-05-03 06:30:59 --> Model Class Initialized
DEBUG - 2011-05-03 06:30:59 --> Model Class Initialized
DEBUG - 2011-05-03 06:30:59 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-05-03 06:30:59 --> Database Driver Class Initialized
DEBUG - 2011-05-03 06:30:59 --> File loaded: application/views/table/main.php
DEBUG - 2011-05-03 06:30:59 --> Helper loaded: url_helper
DEBUG - 2011-05-03 06:30:59 --> File loaded: application/views/common/header.php
DEBUG - 2011-05-03 06:30:59 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-05-03 06:30:59 --> File loaded: application/views/common/footer.php
DEBUG - 2011-05-03 06:30:59 --> File loaded: application/views/layout/main.php
DEBUG - 2011-05-03 06:30:59 --> Final output sent to browser
DEBUG - 2011-05-03 06:30:59 --> Total execution time: 0.1711
DEBUG - 2011-05-03 06:31:04 --> Config Class Initialized
DEBUG - 2011-05-03 06:31:04 --> Hooks Class Initialized
DEBUG - 2011-05-03 06:31:04 --> Utf8 Class Initialized
DEBUG - 2011-05-03 06:31:04 --> UTF-8 Support Enabled
DEBUG - 2011-05-03 06:31:04 --> URI Class Initialized
DEBUG - 2011-05-03 06:31:04 --> Router Class Initialized
ERROR - 2011-05-03 06:31:04 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-05-03 06:48:18 --> Config Class Initialized
DEBUG - 2011-05-03 06:48:18 --> Hooks Class Initialized
DEBUG - 2011-05-03 06:48:18 --> Utf8 Class Initialized
DEBUG - 2011-05-03 06:48:18 --> UTF-8 Support Enabled
DEBUG - 2011-05-03 06:48:18 --> URI Class Initialized
DEBUG - 2011-05-03 06:48:18 --> Router Class Initialized
DEBUG - 2011-05-03 06:48:18 --> Output Class Initialized
DEBUG - 2011-05-03 06:48:18 --> Input Class Initialized
DEBUG - 2011-05-03 06:48:18 --> Global POST and COOKIE data sanitized
DEBUG - 2011-05-03 06:48:18 --> Language Class Initialized
DEBUG - 2011-05-03 06:48:19 --> Loader Class Initialized
DEBUG - 2011-05-03 06:48:19 --> Controller Class Initialized
DEBUG - 2011-05-03 06:48:19 --> Model Class Initialized
DEBUG - 2011-05-03 06:48:19 --> Model Class Initialized
DEBUG - 2011-05-03 06:48:19 --> Model Class Initialized
DEBUG - 2011-05-03 06:48:19 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-05-03 06:48:19 --> Database Driver Class Initialized
DEBUG - 2011-05-03 06:48:20 --> File loaded: application/views/table/main.php
DEBUG - 2011-05-03 06:48:20 --> Helper loaded: url_helper
DEBUG - 2011-05-03 06:48:20 --> File loaded: application/views/common/header.php
DEBUG - 2011-05-03 06:48:20 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-05-03 06:48:20 --> File loaded: application/views/common/footer.php
DEBUG - 2011-05-03 06:48:20 --> File loaded: application/views/layout/main.php
DEBUG - 2011-05-03 06:48:20 --> Final output sent to browser
DEBUG - 2011-05-03 06:48:20 --> Total execution time: 1.7339
DEBUG - 2011-05-03 06:48:22 --> Config Class Initialized
DEBUG - 2011-05-03 06:48:22 --> Hooks Class Initialized
DEBUG - 2011-05-03 06:48:22 --> Utf8 Class Initialized
DEBUG - 2011-05-03 06:48:22 --> UTF-8 Support Enabled
DEBUG - 2011-05-03 06:48:22 --> URI Class Initialized
DEBUG - 2011-05-03 06:48:22 --> Router Class Initialized
DEBUG - 2011-05-03 06:48:22 --> Output Class Initialized
DEBUG - 2011-05-03 06:48:22 --> Input Class Initialized
DEBUG - 2011-05-03 06:48:22 --> Global POST and COOKIE data sanitized
DEBUG - 2011-05-03 06:48:22 --> Language Class Initialized
DEBUG - 2011-05-03 06:48:22 --> Loader Class Initialized
DEBUG - 2011-05-03 06:48:22 --> Controller Class Initialized
ERROR - 2011-05-03 06:48:22 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-05-03 06:48:22 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-05-03 06:48:22 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-05-03 06:48:22 --> Model Class Initialized
DEBUG - 2011-05-03 06:48:22 --> Model Class Initialized
DEBUG - 2011-05-03 06:48:22 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-05-03 06:48:22 --> Database Driver Class Initialized
DEBUG - 2011-05-03 06:48:22 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-05-03 06:48:22 --> Helper loaded: url_helper
DEBUG - 2011-05-03 06:48:22 --> File loaded: application/views/common/header.php
DEBUG - 2011-05-03 06:48:22 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-05-03 06:48:22 --> File loaded: application/views/common/footer.php
DEBUG - 2011-05-03 06:48:22 --> File loaded: application/views/layout/main.php
DEBUG - 2011-05-03 06:48:22 --> Final output sent to browser
DEBUG - 2011-05-03 06:48:22 --> Total execution time: 0.1202
DEBUG - 2011-05-03 06:52:37 --> Config Class Initialized
DEBUG - 2011-05-03 06:52:37 --> Hooks Class Initialized
DEBUG - 2011-05-03 06:52:37 --> Utf8 Class Initialized
DEBUG - 2011-05-03 06:52:37 --> UTF-8 Support Enabled
DEBUG - 2011-05-03 06:52:37 --> URI Class Initialized
DEBUG - 2011-05-03 06:52:37 --> Router Class Initialized
DEBUG - 2011-05-03 06:52:37 --> Output Class Initialized
DEBUG - 2011-05-03 06:52:37 --> Input Class Initialized
DEBUG - 2011-05-03 06:52:37 --> Global POST and COOKIE data sanitized
DEBUG - 2011-05-03 06:52:37 --> Language Class Initialized
DEBUG - 2011-05-03 06:52:37 --> Loader Class Initialized
DEBUG - 2011-05-03 06:52:37 --> Controller Class Initialized
DEBUG - 2011-05-03 06:52:37 --> Model Class Initialized
DEBUG - 2011-05-03 06:52:37 --> Model Class Initialized
DEBUG - 2011-05-03 06:52:37 --> Model Class Initialized
DEBUG - 2011-05-03 06:52:37 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-05-03 06:52:37 --> Database Driver Class Initialized
DEBUG - 2011-05-03 06:52:37 --> File loaded: application/views/table/main.php
DEBUG - 2011-05-03 06:52:37 --> Helper loaded: url_helper
DEBUG - 2011-05-03 06:52:37 --> File loaded: application/views/common/header.php
DEBUG - 2011-05-03 06:52:37 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-05-03 06:52:37 --> File loaded: application/views/common/footer.php
DEBUG - 2011-05-03 06:52:37 --> File loaded: application/views/layout/main.php
DEBUG - 2011-05-03 06:52:37 --> Final output sent to browser
DEBUG - 2011-05-03 06:52:37 --> Total execution time: 0.0960
DEBUG - 2011-05-03 07:08:29 --> Config Class Initialized
DEBUG - 2011-05-03 07:08:29 --> Hooks Class Initialized
DEBUG - 2011-05-03 07:08:29 --> Utf8 Class Initialized
DEBUG - 2011-05-03 07:08:29 --> UTF-8 Support Enabled
DEBUG - 2011-05-03 07:08:29 --> URI Class Initialized
DEBUG - 2011-05-03 07:08:29 --> Router Class Initialized
DEBUG - 2011-05-03 07:08:29 --> Output Class Initialized
DEBUG - 2011-05-03 07:08:29 --> Input Class Initialized
DEBUG - 2011-05-03 07:08:29 --> Global POST and COOKIE data sanitized
DEBUG - 2011-05-03 07:08:29 --> Language Class Initialized
DEBUG - 2011-05-03 07:08:29 --> Loader Class Initialized
DEBUG - 2011-05-03 07:08:29 --> Controller Class Initialized
ERROR - 2011-05-03 07:08:30 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-05-03 07:08:30 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-05-03 07:08:30 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-05-03 07:08:30 --> Model Class Initialized
DEBUG - 2011-05-03 07:08:30 --> Model Class Initialized
DEBUG - 2011-05-03 07:08:30 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-05-03 07:08:30 --> Database Driver Class Initialized
DEBUG - 2011-05-03 07:08:30 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-05-03 07:08:30 --> Helper loaded: url_helper
DEBUG - 2011-05-03 07:08:30 --> File loaded: application/views/common/header.php
DEBUG - 2011-05-03 07:08:30 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-05-03 07:08:30 --> File loaded: application/views/common/footer.php
DEBUG - 2011-05-03 07:08:30 --> File loaded: application/views/layout/main.php
DEBUG - 2011-05-03 07:08:30 --> Final output sent to browser
DEBUG - 2011-05-03 07:08:30 --> Total execution time: 0.3746
DEBUG - 2011-05-03 07:33:09 --> Config Class Initialized
DEBUG - 2011-05-03 07:33:09 --> Hooks Class Initialized
DEBUG - 2011-05-03 07:33:09 --> Utf8 Class Initialized
DEBUG - 2011-05-03 07:33:09 --> UTF-8 Support Enabled
DEBUG - 2011-05-03 07:33:09 --> URI Class Initialized
DEBUG - 2011-05-03 07:33:09 --> Router Class Initialized
DEBUG - 2011-05-03 07:33:09 --> Output Class Initialized
DEBUG - 2011-05-03 07:33:09 --> Input Class Initialized
DEBUG - 2011-05-03 07:33:09 --> Global POST and COOKIE data sanitized
DEBUG - 2011-05-03 07:33:09 --> Language Class Initialized
DEBUG - 2011-05-03 07:33:09 --> Loader Class Initialized
DEBUG - 2011-05-03 07:33:09 --> Controller Class Initialized
ERROR - 2011-05-03 07:33:09 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-05-03 07:33:09 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-05-03 07:33:09 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-05-03 07:33:09 --> Model Class Initialized
DEBUG - 2011-05-03 07:33:09 --> Model Class Initialized
DEBUG - 2011-05-03 07:33:09 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-05-03 07:33:09 --> Database Driver Class Initialized
DEBUG - 2011-05-03 07:33:09 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-05-03 07:33:09 --> Helper loaded: url_helper
DEBUG - 2011-05-03 07:33:09 --> File loaded: application/views/common/header.php
DEBUG - 2011-05-03 07:33:09 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-05-03 07:33:09 --> File loaded: application/views/common/footer.php
DEBUG - 2011-05-03 07:33:09 --> File loaded: application/views/layout/main.php
DEBUG - 2011-05-03 07:33:09 --> Final output sent to browser
DEBUG - 2011-05-03 07:33:09 --> Total execution time: 0.6066
DEBUG - 2011-05-03 07:33:11 --> Config Class Initialized
DEBUG - 2011-05-03 07:33:11 --> Hooks Class Initialized
DEBUG - 2011-05-03 07:33:11 --> Utf8 Class Initialized
DEBUG - 2011-05-03 07:33:11 --> UTF-8 Support Enabled
DEBUG - 2011-05-03 07:33:11 --> URI Class Initialized
DEBUG - 2011-05-03 07:33:11 --> Router Class Initialized
DEBUG - 2011-05-03 07:33:11 --> Output Class Initialized
DEBUG - 2011-05-03 07:33:11 --> Input Class Initialized
DEBUG - 2011-05-03 07:33:11 --> Global POST and COOKIE data sanitized
DEBUG - 2011-05-03 07:33:11 --> Language Class Initialized
DEBUG - 2011-05-03 07:33:11 --> Loader Class Initialized
DEBUG - 2011-05-03 07:33:11 --> Controller Class Initialized
DEBUG - 2011-05-03 07:33:11 --> Model Class Initialized
DEBUG - 2011-05-03 07:33:11 --> Model Class Initialized
DEBUG - 2011-05-03 07:33:11 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-05-03 07:33:11 --> Database Driver Class Initialized
DEBUG - 2011-05-03 07:33:12 --> Final output sent to browser
DEBUG - 2011-05-03 07:33:12 --> Total execution time: 0.8445
DEBUG - 2011-05-03 07:49:43 --> Config Class Initialized
DEBUG - 2011-05-03 07:49:43 --> Hooks Class Initialized
DEBUG - 2011-05-03 07:49:43 --> Utf8 Class Initialized
DEBUG - 2011-05-03 07:49:43 --> UTF-8 Support Enabled
DEBUG - 2011-05-03 07:49:43 --> URI Class Initialized
DEBUG - 2011-05-03 07:49:43 --> Router Class Initialized
DEBUG - 2011-05-03 07:49:43 --> Output Class Initialized
DEBUG - 2011-05-03 07:49:43 --> Input Class Initialized
DEBUG - 2011-05-03 07:49:43 --> Global POST and COOKIE data sanitized
DEBUG - 2011-05-03 07:49:43 --> Language Class Initialized
DEBUG - 2011-05-03 07:49:43 --> Loader Class Initialized
DEBUG - 2011-05-03 07:49:43 --> Controller Class Initialized
ERROR - 2011-05-03 07:49:43 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-05-03 07:49:43 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-05-03 07:49:43 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-05-03 07:49:43 --> Model Class Initialized
DEBUG - 2011-05-03 07:49:43 --> Model Class Initialized
DEBUG - 2011-05-03 07:49:43 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-05-03 07:49:43 --> Database Driver Class Initialized
DEBUG - 2011-05-03 07:49:43 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-05-03 07:49:43 --> Helper loaded: url_helper
DEBUG - 2011-05-03 07:49:43 --> File loaded: application/views/common/header.php
DEBUG - 2011-05-03 07:49:43 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-05-03 07:49:43 --> File loaded: application/views/common/footer.php
DEBUG - 2011-05-03 07:49:43 --> File loaded: application/views/layout/main.php
DEBUG - 2011-05-03 07:49:43 --> Final output sent to browser
DEBUG - 2011-05-03 07:49:43 --> Total execution time: 0.2227
DEBUG - 2011-05-03 07:49:45 --> Config Class Initialized
DEBUG - 2011-05-03 07:49:45 --> Hooks Class Initialized
DEBUG - 2011-05-03 07:49:45 --> Utf8 Class Initialized
DEBUG - 2011-05-03 07:49:45 --> UTF-8 Support Enabled
DEBUG - 2011-05-03 07:49:45 --> URI Class Initialized
DEBUG - 2011-05-03 07:49:45 --> Router Class Initialized
DEBUG - 2011-05-03 07:49:45 --> Output Class Initialized
DEBUG - 2011-05-03 07:49:45 --> Input Class Initialized
DEBUG - 2011-05-03 07:49:45 --> Global POST and COOKIE data sanitized
DEBUG - 2011-05-03 07:49:45 --> Language Class Initialized
DEBUG - 2011-05-03 07:49:45 --> Loader Class Initialized
DEBUG - 2011-05-03 07:49:45 --> Controller Class Initialized
DEBUG - 2011-05-03 07:49:45 --> Model Class Initialized
DEBUG - 2011-05-03 07:49:45 --> Model Class Initialized
DEBUG - 2011-05-03 07:49:45 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-05-03 07:49:45 --> Database Driver Class Initialized
DEBUG - 2011-05-03 07:49:46 --> Final output sent to browser
DEBUG - 2011-05-03 07:49:46 --> Total execution time: 1.2191
DEBUG - 2011-05-03 07:49:47 --> Config Class Initialized
DEBUG - 2011-05-03 07:49:47 --> Hooks Class Initialized
DEBUG - 2011-05-03 07:49:47 --> Utf8 Class Initialized
DEBUG - 2011-05-03 07:49:47 --> UTF-8 Support Enabled
DEBUG - 2011-05-03 07:49:47 --> URI Class Initialized
DEBUG - 2011-05-03 07:49:47 --> Router Class Initialized
ERROR - 2011-05-03 07:49:47 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-05-03 07:49:56 --> Config Class Initialized
DEBUG - 2011-05-03 07:49:56 --> Hooks Class Initialized
DEBUG - 2011-05-03 07:49:56 --> Utf8 Class Initialized
DEBUG - 2011-05-03 07:49:56 --> UTF-8 Support Enabled
DEBUG - 2011-05-03 07:49:56 --> URI Class Initialized
DEBUG - 2011-05-03 07:49:56 --> Router Class Initialized
DEBUG - 2011-05-03 07:49:56 --> Output Class Initialized
DEBUG - 2011-05-03 07:49:56 --> Input Class Initialized
DEBUG - 2011-05-03 07:49:56 --> Global POST and COOKIE data sanitized
DEBUG - 2011-05-03 07:49:56 --> Language Class Initialized
DEBUG - 2011-05-03 07:49:56 --> Loader Class Initialized
DEBUG - 2011-05-03 07:49:56 --> Controller Class Initialized
ERROR - 2011-05-03 07:49:56 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-05-03 07:49:56 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-05-03 07:49:56 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-05-03 07:49:56 --> Model Class Initialized
DEBUG - 2011-05-03 07:49:56 --> Model Class Initialized
DEBUG - 2011-05-03 07:49:56 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-05-03 07:49:56 --> Database Driver Class Initialized
DEBUG - 2011-05-03 07:49:56 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-05-03 07:49:56 --> Helper loaded: url_helper
DEBUG - 2011-05-03 07:49:56 --> File loaded: application/views/common/header.php
DEBUG - 2011-05-03 07:49:56 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-05-03 07:49:56 --> File loaded: application/views/common/footer.php
DEBUG - 2011-05-03 07:49:56 --> File loaded: application/views/layout/main.php
DEBUG - 2011-05-03 07:49:56 --> Final output sent to browser
DEBUG - 2011-05-03 07:49:56 --> Total execution time: 0.0430
DEBUG - 2011-05-03 07:49:58 --> Config Class Initialized
DEBUG - 2011-05-03 07:49:58 --> Hooks Class Initialized
DEBUG - 2011-05-03 07:49:58 --> Utf8 Class Initialized
DEBUG - 2011-05-03 07:49:58 --> UTF-8 Support Enabled
DEBUG - 2011-05-03 07:49:58 --> URI Class Initialized
DEBUG - 2011-05-03 07:49:58 --> Router Class Initialized
DEBUG - 2011-05-03 07:49:58 --> Output Class Initialized
DEBUG - 2011-05-03 07:49:58 --> Input Class Initialized
DEBUG - 2011-05-03 07:49:58 --> Global POST and COOKIE data sanitized
DEBUG - 2011-05-03 07:49:58 --> Language Class Initialized
DEBUG - 2011-05-03 07:49:58 --> Loader Class Initialized
DEBUG - 2011-05-03 07:49:58 --> Controller Class Initialized
DEBUG - 2011-05-03 07:49:58 --> Model Class Initialized
DEBUG - 2011-05-03 07:49:58 --> Model Class Initialized
DEBUG - 2011-05-03 07:49:58 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-05-03 07:49:58 --> Database Driver Class Initialized
DEBUG - 2011-05-03 07:49:59 --> Final output sent to browser
DEBUG - 2011-05-03 07:49:59 --> Total execution time: 0.8261
DEBUG - 2011-05-03 07:50:00 --> Config Class Initialized
DEBUG - 2011-05-03 07:50:00 --> Hooks Class Initialized
DEBUG - 2011-05-03 07:50:00 --> Utf8 Class Initialized
DEBUG - 2011-05-03 07:50:00 --> UTF-8 Support Enabled
DEBUG - 2011-05-03 07:50:00 --> URI Class Initialized
DEBUG - 2011-05-03 07:50:00 --> Router Class Initialized
ERROR - 2011-05-03 07:50:00 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-05-03 07:50:35 --> Config Class Initialized
DEBUG - 2011-05-03 07:50:35 --> Hooks Class Initialized
DEBUG - 2011-05-03 07:50:35 --> Utf8 Class Initialized
DEBUG - 2011-05-03 07:50:35 --> UTF-8 Support Enabled
DEBUG - 2011-05-03 07:50:35 --> URI Class Initialized
DEBUG - 2011-05-03 07:50:35 --> Router Class Initialized
DEBUG - 2011-05-03 07:50:35 --> Output Class Initialized
DEBUG - 2011-05-03 07:50:35 --> Input Class Initialized
DEBUG - 2011-05-03 07:50:35 --> Global POST and COOKIE data sanitized
DEBUG - 2011-05-03 07:50:35 --> Language Class Initialized
DEBUG - 2011-05-03 07:50:35 --> Loader Class Initialized
DEBUG - 2011-05-03 07:50:35 --> Controller Class Initialized
ERROR - 2011-05-03 07:50:35 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-05-03 07:50:35 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-05-03 07:50:35 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-05-03 07:50:35 --> Model Class Initialized
DEBUG - 2011-05-03 07:50:35 --> Model Class Initialized
DEBUG - 2011-05-03 07:50:35 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-05-03 07:50:35 --> Database Driver Class Initialized
DEBUG - 2011-05-03 07:50:35 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-05-03 07:50:35 --> Helper loaded: url_helper
DEBUG - 2011-05-03 07:50:35 --> File loaded: application/views/common/header.php
DEBUG - 2011-05-03 07:50:35 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-05-03 07:50:35 --> File loaded: application/views/common/footer.php
DEBUG - 2011-05-03 07:50:35 --> File loaded: application/views/layout/main.php
DEBUG - 2011-05-03 07:50:35 --> Final output sent to browser
DEBUG - 2011-05-03 07:50:35 --> Total execution time: 0.0626
DEBUG - 2011-05-03 07:50:36 --> Config Class Initialized
DEBUG - 2011-05-03 07:50:36 --> Hooks Class Initialized
DEBUG - 2011-05-03 07:50:36 --> Utf8 Class Initialized
DEBUG - 2011-05-03 07:50:36 --> UTF-8 Support Enabled
DEBUG - 2011-05-03 07:50:36 --> URI Class Initialized
DEBUG - 2011-05-03 07:50:36 --> Router Class Initialized
DEBUG - 2011-05-03 07:50:36 --> Output Class Initialized
DEBUG - 2011-05-03 07:50:36 --> Input Class Initialized
DEBUG - 2011-05-03 07:50:36 --> Global POST and COOKIE data sanitized
DEBUG - 2011-05-03 07:50:36 --> Language Class Initialized
DEBUG - 2011-05-03 07:50:36 --> Loader Class Initialized
DEBUG - 2011-05-03 07:50:36 --> Controller Class Initialized
DEBUG - 2011-05-03 07:50:36 --> Model Class Initialized
DEBUG - 2011-05-03 07:50:36 --> Model Class Initialized
DEBUG - 2011-05-03 07:50:36 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-05-03 07:50:36 --> Database Driver Class Initialized
DEBUG - 2011-05-03 07:50:37 --> Final output sent to browser
DEBUG - 2011-05-03 07:50:37 --> Total execution time: 0.5159
DEBUG - 2011-05-03 07:50:39 --> Config Class Initialized
DEBUG - 2011-05-03 07:50:39 --> Hooks Class Initialized
DEBUG - 2011-05-03 07:50:39 --> Utf8 Class Initialized
DEBUG - 2011-05-03 07:50:39 --> UTF-8 Support Enabled
DEBUG - 2011-05-03 07:50:39 --> URI Class Initialized
DEBUG - 2011-05-03 07:50:39 --> Router Class Initialized
ERROR - 2011-05-03 07:50:39 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-05-03 08:50:27 --> Config Class Initialized
DEBUG - 2011-05-03 08:50:27 --> Hooks Class Initialized
DEBUG - 2011-05-03 08:50:27 --> Utf8 Class Initialized
DEBUG - 2011-05-03 08:50:27 --> UTF-8 Support Enabled
DEBUG - 2011-05-03 08:50:27 --> URI Class Initialized
DEBUG - 2011-05-03 08:50:27 --> Router Class Initialized
DEBUG - 2011-05-03 08:50:27 --> Output Class Initialized
DEBUG - 2011-05-03 08:50:27 --> Input Class Initialized
DEBUG - 2011-05-03 08:50:27 --> Global POST and COOKIE data sanitized
DEBUG - 2011-05-03 08:50:27 --> Language Class Initialized
DEBUG - 2011-05-03 08:50:27 --> Loader Class Initialized
DEBUG - 2011-05-03 08:50:27 --> Controller Class Initialized
DEBUG - 2011-05-03 08:50:27 --> Model Class Initialized
DEBUG - 2011-05-03 08:50:28 --> Model Class Initialized
DEBUG - 2011-05-03 08:50:28 --> Model Class Initialized
DEBUG - 2011-05-03 08:50:28 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-05-03 08:50:28 --> Database Driver Class Initialized
DEBUG - 2011-05-03 08:50:30 --> File loaded: application/views/table/main.php
DEBUG - 2011-05-03 08:50:31 --> Helper loaded: url_helper
DEBUG - 2011-05-03 08:50:31 --> File loaded: application/views/common/header.php
DEBUG - 2011-05-03 08:50:31 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-05-03 08:50:31 --> File loaded: application/views/common/footer.php
DEBUG - 2011-05-03 08:50:31 --> File loaded: application/views/layout/main.php
DEBUG - 2011-05-03 08:50:31 --> Final output sent to browser
DEBUG - 2011-05-03 08:50:31 --> Total execution time: 4.0946
DEBUG - 2011-05-03 08:50:54 --> Config Class Initialized
DEBUG - 2011-05-03 08:50:54 --> Hooks Class Initialized
DEBUG - 2011-05-03 08:50:54 --> Utf8 Class Initialized
DEBUG - 2011-05-03 08:50:54 --> UTF-8 Support Enabled
DEBUG - 2011-05-03 08:50:54 --> URI Class Initialized
DEBUG - 2011-05-03 08:50:54 --> Router Class Initialized
DEBUG - 2011-05-03 08:50:54 --> Output Class Initialized
DEBUG - 2011-05-03 08:50:54 --> Input Class Initialized
DEBUG - 2011-05-03 08:50:54 --> Global POST and COOKIE data sanitized
DEBUG - 2011-05-03 08:50:54 --> Language Class Initialized
DEBUG - 2011-05-03 08:50:54 --> Loader Class Initialized
DEBUG - 2011-05-03 08:50:54 --> Controller Class Initialized
DEBUG - 2011-05-03 08:50:54 --> Model Class Initialized
DEBUG - 2011-05-03 08:50:54 --> Model Class Initialized
DEBUG - 2011-05-03 08:50:54 --> Model Class Initialized
DEBUG - 2011-05-03 08:50:54 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-05-03 08:50:54 --> Database Driver Class Initialized
DEBUG - 2011-05-03 08:50:55 --> File loaded: application/views/table/main.php
DEBUG - 2011-05-03 08:50:55 --> Helper loaded: url_helper
DEBUG - 2011-05-03 08:50:55 --> File loaded: application/views/common/header.php
DEBUG - 2011-05-03 08:50:55 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-05-03 08:50:55 --> File loaded: application/views/common/footer.php
DEBUG - 2011-05-03 08:50:55 --> File loaded: application/views/layout/main.php
DEBUG - 2011-05-03 08:50:55 --> Final output sent to browser
DEBUG - 2011-05-03 08:50:55 --> Total execution time: 0.9211
DEBUG - 2011-05-03 08:51:02 --> Config Class Initialized
DEBUG - 2011-05-03 08:51:02 --> Hooks Class Initialized
DEBUG - 2011-05-03 08:51:02 --> Utf8 Class Initialized
DEBUG - 2011-05-03 08:51:02 --> UTF-8 Support Enabled
DEBUG - 2011-05-03 08:51:02 --> URI Class Initialized
DEBUG - 2011-05-03 08:51:02 --> Router Class Initialized
DEBUG - 2011-05-03 08:51:02 --> Output Class Initialized
DEBUG - 2011-05-03 08:51:02 --> Input Class Initialized
DEBUG - 2011-05-03 08:51:02 --> Global POST and COOKIE data sanitized
DEBUG - 2011-05-03 08:51:02 --> Language Class Initialized
DEBUG - 2011-05-03 08:51:02 --> Loader Class Initialized
DEBUG - 2011-05-03 08:51:02 --> Controller Class Initialized
DEBUG - 2011-05-03 08:51:02 --> Model Class Initialized
DEBUG - 2011-05-03 08:51:02 --> Model Class Initialized
DEBUG - 2011-05-03 08:51:02 --> Model Class Initialized
DEBUG - 2011-05-03 08:51:02 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-05-03 08:51:02 --> Database Driver Class Initialized
DEBUG - 2011-05-03 08:51:02 --> File loaded: application/views/table/main.php
DEBUG - 2011-05-03 08:51:02 --> Helper loaded: url_helper
DEBUG - 2011-05-03 08:51:02 --> File loaded: application/views/common/header.php
DEBUG - 2011-05-03 08:51:02 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-05-03 08:51:02 --> File loaded: application/views/common/footer.php
DEBUG - 2011-05-03 08:51:02 --> File loaded: application/views/layout/main.php
DEBUG - 2011-05-03 08:51:02 --> Final output sent to browser
DEBUG - 2011-05-03 08:51:02 --> Total execution time: 0.0462
DEBUG - 2011-05-03 09:25:54 --> Config Class Initialized
DEBUG - 2011-05-03 09:25:54 --> Hooks Class Initialized
DEBUG - 2011-05-03 09:25:54 --> Utf8 Class Initialized
DEBUG - 2011-05-03 09:25:54 --> UTF-8 Support Enabled
DEBUG - 2011-05-03 09:25:54 --> URI Class Initialized
DEBUG - 2011-05-03 09:25:54 --> Router Class Initialized
DEBUG - 2011-05-03 09:25:54 --> Output Class Initialized
DEBUG - 2011-05-03 09:25:54 --> Input Class Initialized
DEBUG - 2011-05-03 09:25:54 --> Global POST and COOKIE data sanitized
DEBUG - 2011-05-03 09:25:54 --> Language Class Initialized
DEBUG - 2011-05-03 09:25:55 --> Loader Class Initialized
DEBUG - 2011-05-03 09:25:55 --> Controller Class Initialized
DEBUG - 2011-05-03 09:25:55 --> Model Class Initialized
DEBUG - 2011-05-03 09:25:55 --> Model Class Initialized
DEBUG - 2011-05-03 09:25:55 --> Model Class Initialized
DEBUG - 2011-05-03 09:25:55 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-05-03 09:25:55 --> Database Driver Class Initialized
DEBUG - 2011-05-03 09:25:56 --> Config Class Initialized
DEBUG - 2011-05-03 09:25:56 --> Hooks Class Initialized
DEBUG - 2011-05-03 09:25:56 --> Utf8 Class Initialized
DEBUG - 2011-05-03 09:25:56 --> UTF-8 Support Enabled
DEBUG - 2011-05-03 09:25:56 --> URI Class Initialized
DEBUG - 2011-05-03 09:25:56 --> Router Class Initialized
DEBUG - 2011-05-03 09:25:56 --> Output Class Initialized
DEBUG - 2011-05-03 09:25:56 --> Input Class Initialized
DEBUG - 2011-05-03 09:25:56 --> Global POST and COOKIE data sanitized
DEBUG - 2011-05-03 09:25:56 --> Language Class Initialized
DEBUG - 2011-05-03 09:25:56 --> Loader Class Initialized
DEBUG - 2011-05-03 09:25:56 --> Controller Class Initialized
DEBUG - 2011-05-03 09:25:56 --> File loaded: application/views/table/main.php
ERROR - 2011-05-03 09:25:56 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-05-03 09:25:56 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-05-03 09:25:56 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-05-03 09:25:56 --> Model Class Initialized
DEBUG - 2011-05-03 09:25:56 --> Model Class Initialized
DEBUG - 2011-05-03 09:25:56 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-05-03 09:25:56 --> Helper loaded: url_helper
DEBUG - 2011-05-03 09:25:56 --> File loaded: application/views/common/header.php
DEBUG - 2011-05-03 09:25:56 --> Database Driver Class Initialized
DEBUG - 2011-05-03 09:25:56 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-05-03 09:25:56 --> File loaded: application/views/common/footer.php
DEBUG - 2011-05-03 09:25:56 --> File loaded: application/views/layout/main.php
DEBUG - 2011-05-03 09:25:56 --> Final output sent to browser
DEBUG - 2011-05-03 09:25:56 --> Total execution time: 1.8136
DEBUG - 2011-05-03 09:25:56 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-05-03 09:25:56 --> Helper loaded: url_helper
DEBUG - 2011-05-03 09:25:56 --> File loaded: application/views/common/header.php
DEBUG - 2011-05-03 09:25:56 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-05-03 09:25:56 --> File loaded: application/views/common/footer.php
DEBUG - 2011-05-03 09:25:56 --> File loaded: application/views/layout/main.php
DEBUG - 2011-05-03 09:25:56 --> Final output sent to browser
DEBUG - 2011-05-03 09:25:56 --> Total execution time: 0.2228
DEBUG - 2011-05-03 09:25:57 --> Config Class Initialized
DEBUG - 2011-05-03 09:25:57 --> Hooks Class Initialized
DEBUG - 2011-05-03 09:25:57 --> Utf8 Class Initialized
DEBUG - 2011-05-03 09:25:57 --> UTF-8 Support Enabled
DEBUG - 2011-05-03 09:25:57 --> Config Class Initialized
DEBUG - 2011-05-03 09:25:57 --> Hooks Class Initialized
DEBUG - 2011-05-03 09:25:57 --> URI Class Initialized
DEBUG - 2011-05-03 09:25:57 --> Utf8 Class Initialized
DEBUG - 2011-05-03 09:25:57 --> UTF-8 Support Enabled
DEBUG - 2011-05-03 09:25:57 --> Router Class Initialized
DEBUG - 2011-05-03 09:25:57 --> URI Class Initialized
DEBUG - 2011-05-03 09:25:57 --> Output Class Initialized
DEBUG - 2011-05-03 09:25:57 --> Router Class Initialized
DEBUG - 2011-05-03 09:25:57 --> Input Class Initialized
DEBUG - 2011-05-03 09:25:57 --> Global POST and COOKIE data sanitized
DEBUG - 2011-05-03 09:25:57 --> Language Class Initialized
DEBUG - 2011-05-03 09:25:57 --> Output Class Initialized
DEBUG - 2011-05-03 09:25:57 --> Input Class Initialized
DEBUG - 2011-05-03 09:25:57 --> Global POST and COOKIE data sanitized
DEBUG - 2011-05-03 09:25:57 --> Language Class Initialized
DEBUG - 2011-05-03 09:25:57 --> Loader Class Initialized
DEBUG - 2011-05-03 09:25:57 --> Controller Class Initialized
ERROR - 2011-05-03 09:25:57 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-05-03 09:25:57 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-05-03 09:25:57 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-05-03 09:25:57 --> Model Class Initialized
DEBUG - 2011-05-03 09:25:57 --> Model Class Initialized
DEBUG - 2011-05-03 09:25:57 --> Loader Class Initialized
DEBUG - 2011-05-03 09:25:57 --> Controller Class Initialized
DEBUG - 2011-05-03 09:25:57 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-05-03 09:25:57 --> Model Class Initialized
DEBUG - 2011-05-03 09:25:57 --> Database Driver Class Initialized
DEBUG - 2011-05-03 09:25:57 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-05-03 09:25:57 --> Model Class Initialized
DEBUG - 2011-05-03 09:25:57 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-05-03 09:25:57 --> Helper loaded: url_helper
DEBUG - 2011-05-03 09:25:57 --> File loaded: application/views/common/header.php
DEBUG - 2011-05-03 09:25:57 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-05-03 09:25:57 --> File loaded: application/views/common/footer.php
DEBUG - 2011-05-03 09:25:57 --> File loaded: application/views/layout/main.php
DEBUG - 2011-05-03 09:25:57 --> Final output sent to browser
DEBUG - 2011-05-03 09:25:57 --> Total execution time: 0.0294
DEBUG - 2011-05-03 09:25:57 --> Database Driver Class Initialized
DEBUG - 2011-05-03 09:25:58 --> Final output sent to browser
DEBUG - 2011-05-03 09:25:58 --> Total execution time: 0.6576
DEBUG - 2011-05-03 09:26:00 --> Config Class Initialized
DEBUG - 2011-05-03 09:26:00 --> Hooks Class Initialized
DEBUG - 2011-05-03 09:26:00 --> Utf8 Class Initialized
DEBUG - 2011-05-03 09:26:00 --> UTF-8 Support Enabled
DEBUG - 2011-05-03 09:26:00 --> URI Class Initialized
DEBUG - 2011-05-03 09:26:00 --> Router Class Initialized
DEBUG - 2011-05-03 09:26:00 --> Output Class Initialized
DEBUG - 2011-05-03 09:26:00 --> Input Class Initialized
DEBUG - 2011-05-03 09:26:00 --> Global POST and COOKIE data sanitized
DEBUG - 2011-05-03 09:26:00 --> Language Class Initialized
DEBUG - 2011-05-03 09:26:00 --> Loader Class Initialized
DEBUG - 2011-05-03 09:26:00 --> Controller Class Initialized
DEBUG - 2011-05-03 09:26:00 --> Model Class Initialized
DEBUG - 2011-05-03 09:26:00 --> Model Class Initialized
DEBUG - 2011-05-03 09:26:00 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-05-03 09:26:00 --> Database Driver Class Initialized
DEBUG - 2011-05-03 09:26:00 --> Config Class Initialized
DEBUG - 2011-05-03 09:26:00 --> Hooks Class Initialized
DEBUG - 2011-05-03 09:26:00 --> Utf8 Class Initialized
DEBUG - 2011-05-03 09:26:00 --> UTF-8 Support Enabled
DEBUG - 2011-05-03 09:26:00 --> URI Class Initialized
DEBUG - 2011-05-03 09:26:00 --> Router Class Initialized
ERROR - 2011-05-03 09:26:00 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-05-03 09:26:00 --> Final output sent to browser
DEBUG - 2011-05-03 09:26:00 --> Total execution time: 0.6038
DEBUG - 2011-05-03 09:26:42 --> Config Class Initialized
DEBUG - 2011-05-03 09:26:42 --> Hooks Class Initialized
DEBUG - 2011-05-03 09:26:42 --> Utf8 Class Initialized
DEBUG - 2011-05-03 09:26:42 --> UTF-8 Support Enabled
DEBUG - 2011-05-03 09:26:42 --> URI Class Initialized
DEBUG - 2011-05-03 09:26:42 --> Router Class Initialized
DEBUG - 2011-05-03 09:26:42 --> Output Class Initialized
DEBUG - 2011-05-03 09:26:42 --> Input Class Initialized
DEBUG - 2011-05-03 09:26:42 --> Global POST and COOKIE data sanitized
DEBUG - 2011-05-03 09:26:42 --> Language Class Initialized
DEBUG - 2011-05-03 09:26:42 --> Loader Class Initialized
DEBUG - 2011-05-03 09:26:42 --> Controller Class Initialized
ERROR - 2011-05-03 09:26:42 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-05-03 09:26:42 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-05-03 09:26:42 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-05-03 09:26:42 --> Model Class Initialized
DEBUG - 2011-05-03 09:26:42 --> Model Class Initialized
DEBUG - 2011-05-03 09:26:42 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-05-03 09:26:42 --> Database Driver Class Initialized
DEBUG - 2011-05-03 09:26:42 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-05-03 09:26:42 --> Helper loaded: url_helper
DEBUG - 2011-05-03 09:26:42 --> File loaded: application/views/common/header.php
DEBUG - 2011-05-03 09:26:42 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-05-03 09:26:42 --> File loaded: application/views/common/footer.php
DEBUG - 2011-05-03 09:26:42 --> File loaded: application/views/layout/main.php
DEBUG - 2011-05-03 09:26:42 --> Final output sent to browser
DEBUG - 2011-05-03 09:26:42 --> Total execution time: 0.0307
DEBUG - 2011-05-03 09:26:43 --> Config Class Initialized
DEBUG - 2011-05-03 09:26:43 --> Hooks Class Initialized
DEBUG - 2011-05-03 09:26:43 --> Utf8 Class Initialized
DEBUG - 2011-05-03 09:26:43 --> UTF-8 Support Enabled
DEBUG - 2011-05-03 09:26:43 --> URI Class Initialized
DEBUG - 2011-05-03 09:26:43 --> Router Class Initialized
DEBUG - 2011-05-03 09:26:43 --> Output Class Initialized
DEBUG - 2011-05-03 09:26:43 --> Input Class Initialized
DEBUG - 2011-05-03 09:26:43 --> Global POST and COOKIE data sanitized
DEBUG - 2011-05-03 09:26:43 --> Language Class Initialized
DEBUG - 2011-05-03 09:26:43 --> Loader Class Initialized
DEBUG - 2011-05-03 09:26:43 --> Controller Class Initialized
DEBUG - 2011-05-03 09:26:43 --> Model Class Initialized
DEBUG - 2011-05-03 09:26:43 --> Model Class Initialized
DEBUG - 2011-05-03 09:26:43 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-05-03 09:26:43 --> Database Driver Class Initialized
DEBUG - 2011-05-03 09:26:44 --> Final output sent to browser
DEBUG - 2011-05-03 09:26:44 --> Total execution time: 0.7297
DEBUG - 2011-05-03 09:27:00 --> Config Class Initialized
DEBUG - 2011-05-03 09:27:00 --> Hooks Class Initialized
DEBUG - 2011-05-03 09:27:00 --> Utf8 Class Initialized
DEBUG - 2011-05-03 09:27:00 --> UTF-8 Support Enabled
DEBUG - 2011-05-03 09:27:00 --> URI Class Initialized
DEBUG - 2011-05-03 09:27:00 --> Router Class Initialized
DEBUG - 2011-05-03 09:27:00 --> Output Class Initialized
DEBUG - 2011-05-03 09:27:00 --> Input Class Initialized
DEBUG - 2011-05-03 09:27:00 --> Global POST and COOKIE data sanitized
DEBUG - 2011-05-03 09:27:00 --> Language Class Initialized
DEBUG - 2011-05-03 09:27:00 --> Loader Class Initialized
DEBUG - 2011-05-03 09:27:00 --> Controller Class Initialized
ERROR - 2011-05-03 09:27:00 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-05-03 09:27:00 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-05-03 09:27:00 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-05-03 09:27:00 --> Model Class Initialized
DEBUG - 2011-05-03 09:27:00 --> Model Class Initialized
DEBUG - 2011-05-03 09:27:00 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-05-03 09:27:00 --> Database Driver Class Initialized
DEBUG - 2011-05-03 09:27:00 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-05-03 09:27:00 --> Helper loaded: url_helper
DEBUG - 2011-05-03 09:27:00 --> File loaded: application/views/common/header.php
DEBUG - 2011-05-03 09:27:00 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-05-03 09:27:00 --> File loaded: application/views/common/footer.php
DEBUG - 2011-05-03 09:27:00 --> File loaded: application/views/layout/main.php
DEBUG - 2011-05-03 09:27:00 --> Final output sent to browser
DEBUG - 2011-05-03 09:27:00 --> Total execution time: 0.0404
DEBUG - 2011-05-03 09:27:01 --> Config Class Initialized
DEBUG - 2011-05-03 09:27:01 --> Hooks Class Initialized
DEBUG - 2011-05-03 09:27:01 --> Utf8 Class Initialized
DEBUG - 2011-05-03 09:27:01 --> UTF-8 Support Enabled
DEBUG - 2011-05-03 09:27:01 --> URI Class Initialized
DEBUG - 2011-05-03 09:27:01 --> Router Class Initialized
DEBUG - 2011-05-03 09:27:01 --> Output Class Initialized
DEBUG - 2011-05-03 09:27:01 --> Input Class Initialized
DEBUG - 2011-05-03 09:27:01 --> Global POST and COOKIE data sanitized
DEBUG - 2011-05-03 09:27:01 --> Language Class Initialized
DEBUG - 2011-05-03 09:27:01 --> Loader Class Initialized
DEBUG - 2011-05-03 09:27:01 --> Controller Class Initialized
DEBUG - 2011-05-03 09:27:01 --> Model Class Initialized
DEBUG - 2011-05-03 09:27:01 --> Model Class Initialized
DEBUG - 2011-05-03 09:27:01 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-05-03 09:27:01 --> Database Driver Class Initialized
DEBUG - 2011-05-03 09:27:01 --> Final output sent to browser
DEBUG - 2011-05-03 09:27:01 --> Total execution time: 0.6910
DEBUG - 2011-05-03 09:27:39 --> Config Class Initialized
DEBUG - 2011-05-03 09:27:39 --> Hooks Class Initialized
DEBUG - 2011-05-03 09:27:39 --> Utf8 Class Initialized
DEBUG - 2011-05-03 09:27:39 --> UTF-8 Support Enabled
DEBUG - 2011-05-03 09:27:39 --> URI Class Initialized
DEBUG - 2011-05-03 09:27:39 --> Router Class Initialized
DEBUG - 2011-05-03 09:27:39 --> Output Class Initialized
DEBUG - 2011-05-03 09:27:39 --> Input Class Initialized
DEBUG - 2011-05-03 09:27:39 --> Global POST and COOKIE data sanitized
DEBUG - 2011-05-03 09:27:39 --> Language Class Initialized
DEBUG - 2011-05-03 09:27:39 --> Loader Class Initialized
DEBUG - 2011-05-03 09:27:39 --> Controller Class Initialized
ERROR - 2011-05-03 09:27:39 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-05-03 09:27:39 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-05-03 09:27:39 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-05-03 09:27:39 --> Model Class Initialized
DEBUG - 2011-05-03 09:27:39 --> Model Class Initialized
DEBUG - 2011-05-03 09:27:39 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-05-03 09:27:39 --> Database Driver Class Initialized
DEBUG - 2011-05-03 09:27:39 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-05-03 09:27:39 --> Helper loaded: url_helper
DEBUG - 2011-05-03 09:27:39 --> File loaded: application/views/common/header.php
DEBUG - 2011-05-03 09:27:39 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-05-03 09:27:39 --> File loaded: application/views/common/footer.php
DEBUG - 2011-05-03 09:27:39 --> File loaded: application/views/layout/main.php
DEBUG - 2011-05-03 09:27:39 --> Final output sent to browser
DEBUG - 2011-05-03 09:27:39 --> Total execution time: 0.0515
DEBUG - 2011-05-03 09:27:40 --> Config Class Initialized
DEBUG - 2011-05-03 09:27:40 --> Hooks Class Initialized
DEBUG - 2011-05-03 09:27:40 --> Utf8 Class Initialized
DEBUG - 2011-05-03 09:27:40 --> UTF-8 Support Enabled
DEBUG - 2011-05-03 09:27:40 --> URI Class Initialized
DEBUG - 2011-05-03 09:27:40 --> Router Class Initialized
DEBUG - 2011-05-03 09:27:40 --> Output Class Initialized
DEBUG - 2011-05-03 09:27:40 --> Input Class Initialized
DEBUG - 2011-05-03 09:27:40 --> Global POST and COOKIE data sanitized
DEBUG - 2011-05-03 09:27:40 --> Language Class Initialized
DEBUG - 2011-05-03 09:27:40 --> Loader Class Initialized
DEBUG - 2011-05-03 09:27:40 --> Controller Class Initialized
DEBUG - 2011-05-03 09:27:40 --> Model Class Initialized
DEBUG - 2011-05-03 09:27:40 --> Model Class Initialized
DEBUG - 2011-05-03 09:27:40 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-05-03 09:27:40 --> Database Driver Class Initialized
DEBUG - 2011-05-03 09:27:40 --> Config Class Initialized
DEBUG - 2011-05-03 09:27:40 --> Hooks Class Initialized
DEBUG - 2011-05-03 09:27:40 --> Utf8 Class Initialized
DEBUG - 2011-05-03 09:27:40 --> UTF-8 Support Enabled
DEBUG - 2011-05-03 09:27:40 --> URI Class Initialized
DEBUG - 2011-05-03 09:27:40 --> Router Class Initialized
DEBUG - 2011-05-03 09:27:40 --> Output Class Initialized
DEBUG - 2011-05-03 09:27:40 --> Input Class Initialized
DEBUG - 2011-05-03 09:27:40 --> Global POST and COOKIE data sanitized
DEBUG - 2011-05-03 09:27:40 --> Language Class Initialized
DEBUG - 2011-05-03 09:27:40 --> Loader Class Initialized
DEBUG - 2011-05-03 09:27:40 --> Controller Class Initialized
ERROR - 2011-05-03 09:27:40 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-05-03 09:27:40 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-05-03 09:27:40 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-05-03 09:27:40 --> Model Class Initialized
DEBUG - 2011-05-03 09:27:40 --> Model Class Initialized
DEBUG - 2011-05-03 09:27:40 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-05-03 09:27:40 --> Database Driver Class Initialized
DEBUG - 2011-05-03 09:27:40 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-05-03 09:27:40 --> Helper loaded: url_helper
DEBUG - 2011-05-03 09:27:40 --> File loaded: application/views/common/header.php
DEBUG - 2011-05-03 09:27:40 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-05-03 09:27:40 --> File loaded: application/views/common/footer.php
DEBUG - 2011-05-03 09:27:40 --> File loaded: application/views/layout/main.php
DEBUG - 2011-05-03 09:27:40 --> Final output sent to browser
DEBUG - 2011-05-03 09:27:40 --> Total execution time: 0.0585
DEBUG - 2011-05-03 09:27:41 --> Final output sent to browser
DEBUG - 2011-05-03 09:27:41 --> Total execution time: 0.7023
DEBUG - 2011-05-03 09:27:56 --> Config Class Initialized
DEBUG - 2011-05-03 09:27:56 --> Hooks Class Initialized
DEBUG - 2011-05-03 09:27:56 --> Utf8 Class Initialized
DEBUG - 2011-05-03 09:27:56 --> UTF-8 Support Enabled
DEBUG - 2011-05-03 09:27:56 --> URI Class Initialized
DEBUG - 2011-05-03 09:27:56 --> Router Class Initialized
DEBUG - 2011-05-03 09:27:56 --> Output Class Initialized
DEBUG - 2011-05-03 09:27:56 --> Input Class Initialized
DEBUG - 2011-05-03 09:27:56 --> Global POST and COOKIE data sanitized
DEBUG - 2011-05-03 09:27:56 --> Language Class Initialized
DEBUG - 2011-05-03 09:27:56 --> Loader Class Initialized
DEBUG - 2011-05-03 09:27:56 --> Controller Class Initialized
ERROR - 2011-05-03 09:27:56 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-05-03 09:27:56 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-05-03 09:27:56 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-05-03 09:27:56 --> Model Class Initialized
DEBUG - 2011-05-03 09:27:56 --> Model Class Initialized
DEBUG - 2011-05-03 09:27:56 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-05-03 09:27:56 --> Database Driver Class Initialized
DEBUG - 2011-05-03 09:27:56 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-05-03 09:27:56 --> Helper loaded: url_helper
DEBUG - 2011-05-03 09:27:56 --> File loaded: application/views/common/header.php
DEBUG - 2011-05-03 09:27:56 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-05-03 09:27:56 --> File loaded: application/views/common/footer.php
DEBUG - 2011-05-03 09:27:56 --> File loaded: application/views/layout/main.php
DEBUG - 2011-05-03 09:27:56 --> Final output sent to browser
DEBUG - 2011-05-03 09:27:56 --> Total execution time: 0.0291
DEBUG - 2011-05-03 09:27:57 --> Config Class Initialized
DEBUG - 2011-05-03 09:27:57 --> Hooks Class Initialized
DEBUG - 2011-05-03 09:27:57 --> Utf8 Class Initialized
DEBUG - 2011-05-03 09:27:57 --> UTF-8 Support Enabled
DEBUG - 2011-05-03 09:27:57 --> URI Class Initialized
DEBUG - 2011-05-03 09:27:57 --> Router Class Initialized
DEBUG - 2011-05-03 09:27:57 --> Output Class Initialized
DEBUG - 2011-05-03 09:27:57 --> Input Class Initialized
DEBUG - 2011-05-03 09:27:57 --> Global POST and COOKIE data sanitized
DEBUG - 2011-05-03 09:27:57 --> Language Class Initialized
DEBUG - 2011-05-03 09:27:57 --> Loader Class Initialized
DEBUG - 2011-05-03 09:27:57 --> Controller Class Initialized
DEBUG - 2011-05-03 09:27:57 --> Model Class Initialized
DEBUG - 2011-05-03 09:27:57 --> Model Class Initialized
DEBUG - 2011-05-03 09:27:57 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-05-03 09:27:57 --> Database Driver Class Initialized
DEBUG - 2011-05-03 09:27:57 --> Final output sent to browser
DEBUG - 2011-05-03 09:27:57 --> Total execution time: 0.7007
DEBUG - 2011-05-03 09:28:04 --> Config Class Initialized
DEBUG - 2011-05-03 09:28:04 --> Hooks Class Initialized
DEBUG - 2011-05-03 09:28:04 --> Utf8 Class Initialized
DEBUG - 2011-05-03 09:28:04 --> UTF-8 Support Enabled
DEBUG - 2011-05-03 09:28:04 --> URI Class Initialized
DEBUG - 2011-05-03 09:28:04 --> Router Class Initialized
DEBUG - 2011-05-03 09:28:04 --> Output Class Initialized
DEBUG - 2011-05-03 09:28:04 --> Input Class Initialized
DEBUG - 2011-05-03 09:28:04 --> Global POST and COOKIE data sanitized
DEBUG - 2011-05-03 09:28:04 --> Language Class Initialized
DEBUG - 2011-05-03 09:28:04 --> Loader Class Initialized
DEBUG - 2011-05-03 09:28:04 --> Controller Class Initialized
ERROR - 2011-05-03 09:28:04 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-05-03 09:28:04 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-05-03 09:28:04 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-05-03 09:28:04 --> Model Class Initialized
DEBUG - 2011-05-03 09:28:04 --> Model Class Initialized
DEBUG - 2011-05-03 09:28:04 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-05-03 09:28:04 --> Database Driver Class Initialized
DEBUG - 2011-05-03 09:28:04 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-05-03 09:28:04 --> Helper loaded: url_helper
DEBUG - 2011-05-03 09:28:04 --> File loaded: application/views/common/header.php
DEBUG - 2011-05-03 09:28:04 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-05-03 09:28:04 --> File loaded: application/views/common/footer.php
DEBUG - 2011-05-03 09:28:04 --> File loaded: application/views/layout/main.php
DEBUG - 2011-05-03 09:28:04 --> Final output sent to browser
DEBUG - 2011-05-03 09:28:04 --> Total execution time: 0.0585
DEBUG - 2011-05-03 09:28:05 --> Config Class Initialized
DEBUG - 2011-05-03 09:28:05 --> Hooks Class Initialized
DEBUG - 2011-05-03 09:28:05 --> Utf8 Class Initialized
DEBUG - 2011-05-03 09:28:05 --> UTF-8 Support Enabled
DEBUG - 2011-05-03 09:28:05 --> URI Class Initialized
DEBUG - 2011-05-03 09:28:05 --> Router Class Initialized
DEBUG - 2011-05-03 09:28:05 --> Output Class Initialized
DEBUG - 2011-05-03 09:28:05 --> Input Class Initialized
DEBUG - 2011-05-03 09:28:05 --> Global POST and COOKIE data sanitized
DEBUG - 2011-05-03 09:28:05 --> Language Class Initialized
DEBUG - 2011-05-03 09:28:05 --> Loader Class Initialized
DEBUG - 2011-05-03 09:28:05 --> Controller Class Initialized
DEBUG - 2011-05-03 09:28:05 --> Model Class Initialized
DEBUG - 2011-05-03 09:28:05 --> Model Class Initialized
DEBUG - 2011-05-03 09:28:05 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-05-03 09:28:05 --> Database Driver Class Initialized
DEBUG - 2011-05-03 09:28:05 --> Final output sent to browser
DEBUG - 2011-05-03 09:28:05 --> Total execution time: 0.5520
DEBUG - 2011-05-03 09:28:09 --> Config Class Initialized
DEBUG - 2011-05-03 09:28:09 --> Hooks Class Initialized
DEBUG - 2011-05-03 09:28:09 --> Utf8 Class Initialized
DEBUG - 2011-05-03 09:28:09 --> UTF-8 Support Enabled
DEBUG - 2011-05-03 09:28:09 --> URI Class Initialized
DEBUG - 2011-05-03 09:28:09 --> Router Class Initialized
DEBUG - 2011-05-03 09:28:09 --> Output Class Initialized
DEBUG - 2011-05-03 09:28:09 --> Input Class Initialized
DEBUG - 2011-05-03 09:28:09 --> Global POST and COOKIE data sanitized
DEBUG - 2011-05-03 09:28:09 --> Language Class Initialized
DEBUG - 2011-05-03 09:28:09 --> Loader Class Initialized
DEBUG - 2011-05-03 09:28:09 --> Controller Class Initialized
ERROR - 2011-05-03 09:28:09 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-05-03 09:28:09 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-05-03 09:28:09 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-05-03 09:28:09 --> Model Class Initialized
DEBUG - 2011-05-03 09:28:09 --> Model Class Initialized
DEBUG - 2011-05-03 09:28:09 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-05-03 09:28:09 --> Database Driver Class Initialized
DEBUG - 2011-05-03 09:28:09 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-05-03 09:28:09 --> Helper loaded: url_helper
DEBUG - 2011-05-03 09:28:09 --> File loaded: application/views/common/header.php
DEBUG - 2011-05-03 09:28:09 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-05-03 09:28:09 --> File loaded: application/views/common/footer.php
DEBUG - 2011-05-03 09:28:09 --> File loaded: application/views/layout/main.php
DEBUG - 2011-05-03 09:28:09 --> Final output sent to browser
DEBUG - 2011-05-03 09:28:09 --> Total execution time: 0.0304
DEBUG - 2011-05-03 09:28:10 --> Config Class Initialized
DEBUG - 2011-05-03 09:28:10 --> Hooks Class Initialized
DEBUG - 2011-05-03 09:28:10 --> Utf8 Class Initialized
DEBUG - 2011-05-03 09:28:10 --> UTF-8 Support Enabled
DEBUG - 2011-05-03 09:28:10 --> URI Class Initialized
DEBUG - 2011-05-03 09:28:10 --> Router Class Initialized
DEBUG - 2011-05-03 09:28:10 --> Output Class Initialized
DEBUG - 2011-05-03 09:28:10 --> Input Class Initialized
DEBUG - 2011-05-03 09:28:10 --> Global POST and COOKIE data sanitized
DEBUG - 2011-05-03 09:28:10 --> Language Class Initialized
DEBUG - 2011-05-03 09:28:10 --> Loader Class Initialized
DEBUG - 2011-05-03 09:28:10 --> Controller Class Initialized
DEBUG - 2011-05-03 09:28:10 --> Model Class Initialized
DEBUG - 2011-05-03 09:28:10 --> Model Class Initialized
DEBUG - 2011-05-03 09:28:10 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-05-03 09:28:10 --> Database Driver Class Initialized
DEBUG - 2011-05-03 09:28:11 --> Final output sent to browser
DEBUG - 2011-05-03 09:28:11 --> Total execution time: 0.5134
DEBUG - 2011-05-03 09:28:16 --> Config Class Initialized
DEBUG - 2011-05-03 09:28:16 --> Hooks Class Initialized
DEBUG - 2011-05-03 09:28:16 --> Utf8 Class Initialized
DEBUG - 2011-05-03 09:28:16 --> UTF-8 Support Enabled
DEBUG - 2011-05-03 09:28:16 --> URI Class Initialized
DEBUG - 2011-05-03 09:28:16 --> Router Class Initialized
DEBUG - 2011-05-03 09:28:16 --> Output Class Initialized
DEBUG - 2011-05-03 09:28:16 --> Input Class Initialized
DEBUG - 2011-05-03 09:28:16 --> Global POST and COOKIE data sanitized
DEBUG - 2011-05-03 09:28:16 --> Language Class Initialized
DEBUG - 2011-05-03 09:28:16 --> Loader Class Initialized
DEBUG - 2011-05-03 09:28:16 --> Controller Class Initialized
ERROR - 2011-05-03 09:28:16 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-05-03 09:28:16 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-05-03 09:28:16 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-05-03 09:28:16 --> Model Class Initialized
DEBUG - 2011-05-03 09:28:16 --> Model Class Initialized
DEBUG - 2011-05-03 09:28:16 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-05-03 09:28:16 --> Database Driver Class Initialized
DEBUG - 2011-05-03 09:28:16 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-05-03 09:28:16 --> Helper loaded: url_helper
DEBUG - 2011-05-03 09:28:16 --> File loaded: application/views/common/header.php
DEBUG - 2011-05-03 09:28:16 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-05-03 09:28:16 --> File loaded: application/views/common/footer.php
DEBUG - 2011-05-03 09:28:16 --> File loaded: application/views/layout/main.php
DEBUG - 2011-05-03 09:28:16 --> Final output sent to browser
DEBUG - 2011-05-03 09:28:16 --> Total execution time: 0.0567
DEBUG - 2011-05-03 09:28:16 --> Config Class Initialized
DEBUG - 2011-05-03 09:28:16 --> Hooks Class Initialized
DEBUG - 2011-05-03 09:28:16 --> Utf8 Class Initialized
DEBUG - 2011-05-03 09:28:16 --> UTF-8 Support Enabled
DEBUG - 2011-05-03 09:28:16 --> URI Class Initialized
DEBUG - 2011-05-03 09:28:16 --> Router Class Initialized
DEBUG - 2011-05-03 09:28:16 --> Output Class Initialized
DEBUG - 2011-05-03 09:28:16 --> Input Class Initialized
DEBUG - 2011-05-03 09:28:16 --> Global POST and COOKIE data sanitized
DEBUG - 2011-05-03 09:28:16 --> Language Class Initialized
DEBUG - 2011-05-03 09:28:16 --> Loader Class Initialized
DEBUG - 2011-05-03 09:28:16 --> Controller Class Initialized
DEBUG - 2011-05-03 09:28:16 --> Model Class Initialized
DEBUG - 2011-05-03 09:28:16 --> Model Class Initialized
DEBUG - 2011-05-03 09:28:16 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-05-03 09:28:16 --> Database Driver Class Initialized
DEBUG - 2011-05-03 09:28:17 --> Final output sent to browser
DEBUG - 2011-05-03 09:28:17 --> Total execution time: 0.5619
DEBUG - 2011-05-03 09:28:22 --> Config Class Initialized
DEBUG - 2011-05-03 09:28:22 --> Hooks Class Initialized
DEBUG - 2011-05-03 09:28:22 --> Utf8 Class Initialized
DEBUG - 2011-05-03 09:28:22 --> UTF-8 Support Enabled
DEBUG - 2011-05-03 09:28:22 --> URI Class Initialized
DEBUG - 2011-05-03 09:28:22 --> Router Class Initialized
DEBUG - 2011-05-03 09:28:22 --> Output Class Initialized
DEBUG - 2011-05-03 09:28:22 --> Input Class Initialized
DEBUG - 2011-05-03 09:28:22 --> Global POST and COOKIE data sanitized
DEBUG - 2011-05-03 09:28:22 --> Language Class Initialized
DEBUG - 2011-05-03 09:28:22 --> Loader Class Initialized
DEBUG - 2011-05-03 09:28:22 --> Controller Class Initialized
ERROR - 2011-05-03 09:28:22 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-05-03 09:28:22 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-05-03 09:28:22 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-05-03 09:28:22 --> Model Class Initialized
DEBUG - 2011-05-03 09:28:22 --> Model Class Initialized
DEBUG - 2011-05-03 09:28:22 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-05-03 09:28:22 --> Database Driver Class Initialized
DEBUG - 2011-05-03 09:28:23 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-05-03 09:28:23 --> Helper loaded: url_helper
DEBUG - 2011-05-03 09:28:23 --> File loaded: application/views/common/header.php
DEBUG - 2011-05-03 09:28:23 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-05-03 09:28:23 --> File loaded: application/views/common/footer.php
DEBUG - 2011-05-03 09:28:23 --> File loaded: application/views/layout/main.php
DEBUG - 2011-05-03 09:28:23 --> Final output sent to browser
DEBUG - 2011-05-03 09:28:23 --> Total execution time: 0.0419
DEBUG - 2011-05-03 09:28:29 --> Config Class Initialized
DEBUG - 2011-05-03 09:28:29 --> Hooks Class Initialized
DEBUG - 2011-05-03 09:28:29 --> Utf8 Class Initialized
DEBUG - 2011-05-03 09:28:29 --> UTF-8 Support Enabled
DEBUG - 2011-05-03 09:28:29 --> URI Class Initialized
DEBUG - 2011-05-03 09:28:29 --> Router Class Initialized
DEBUG - 2011-05-03 09:28:29 --> Output Class Initialized
DEBUG - 2011-05-03 09:28:29 --> Input Class Initialized
DEBUG - 2011-05-03 09:28:29 --> Global POST and COOKIE data sanitized
DEBUG - 2011-05-03 09:28:29 --> Language Class Initialized
DEBUG - 2011-05-03 09:28:29 --> Loader Class Initialized
DEBUG - 2011-05-03 09:28:29 --> Controller Class Initialized
ERROR - 2011-05-03 09:28:29 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-05-03 09:28:29 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-05-03 09:28:29 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-05-03 09:28:29 --> Model Class Initialized
DEBUG - 2011-05-03 09:28:29 --> Model Class Initialized
DEBUG - 2011-05-03 09:28:29 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-05-03 09:28:29 --> Database Driver Class Initialized
DEBUG - 2011-05-03 09:28:29 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-05-03 09:28:29 --> Helper loaded: url_helper
DEBUG - 2011-05-03 09:28:29 --> File loaded: application/views/common/header.php
DEBUG - 2011-05-03 09:28:29 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-05-03 09:28:29 --> File loaded: application/views/common/footer.php
DEBUG - 2011-05-03 09:28:29 --> File loaded: application/views/layout/main.php
DEBUG - 2011-05-03 09:28:29 --> Final output sent to browser
DEBUG - 2011-05-03 09:28:29 --> Total execution time: 0.0641
DEBUG - 2011-05-03 09:28:30 --> Config Class Initialized
DEBUG - 2011-05-03 09:28:30 --> Hooks Class Initialized
DEBUG - 2011-05-03 09:28:30 --> Utf8 Class Initialized
DEBUG - 2011-05-03 09:28:30 --> UTF-8 Support Enabled
DEBUG - 2011-05-03 09:28:30 --> URI Class Initialized
DEBUG - 2011-05-03 09:28:30 --> Router Class Initialized
DEBUG - 2011-05-03 09:28:30 --> Output Class Initialized
DEBUG - 2011-05-03 09:28:30 --> Input Class Initialized
DEBUG - 2011-05-03 09:28:30 --> Global POST and COOKIE data sanitized
DEBUG - 2011-05-03 09:28:30 --> Language Class Initialized
DEBUG - 2011-05-03 09:28:30 --> Loader Class Initialized
DEBUG - 2011-05-03 09:28:30 --> Controller Class Initialized
DEBUG - 2011-05-03 09:28:30 --> Model Class Initialized
DEBUG - 2011-05-03 09:28:30 --> Model Class Initialized
DEBUG - 2011-05-03 09:28:30 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-05-03 09:28:30 --> Database Driver Class Initialized
DEBUG - 2011-05-03 09:28:31 --> Final output sent to browser
DEBUG - 2011-05-03 09:28:31 --> Total execution time: 0.4857
DEBUG - 2011-05-03 09:28:45 --> Config Class Initialized
DEBUG - 2011-05-03 09:28:45 --> Hooks Class Initialized
DEBUG - 2011-05-03 09:28:45 --> Utf8 Class Initialized
DEBUG - 2011-05-03 09:28:45 --> UTF-8 Support Enabled
DEBUG - 2011-05-03 09:28:45 --> URI Class Initialized
DEBUG - 2011-05-03 09:28:45 --> Router Class Initialized
DEBUG - 2011-05-03 09:28:45 --> Output Class Initialized
DEBUG - 2011-05-03 09:28:45 --> Input Class Initialized
DEBUG - 2011-05-03 09:28:45 --> Global POST and COOKIE data sanitized
DEBUG - 2011-05-03 09:28:45 --> Language Class Initialized
DEBUG - 2011-05-03 09:28:45 --> Loader Class Initialized
DEBUG - 2011-05-03 09:28:45 --> Controller Class Initialized
ERROR - 2011-05-03 09:28:45 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-05-03 09:28:45 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-05-03 09:28:45 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-05-03 09:28:45 --> Model Class Initialized
DEBUG - 2011-05-03 09:28:45 --> Model Class Initialized
DEBUG - 2011-05-03 09:28:45 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-05-03 09:28:45 --> Database Driver Class Initialized
DEBUG - 2011-05-03 09:28:45 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-05-03 09:28:45 --> Helper loaded: url_helper
DEBUG - 2011-05-03 09:28:45 --> File loaded: application/views/common/header.php
DEBUG - 2011-05-03 09:28:45 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-05-03 09:28:45 --> File loaded: application/views/common/footer.php
DEBUG - 2011-05-03 09:28:45 --> File loaded: application/views/layout/main.php
DEBUG - 2011-05-03 09:28:45 --> Final output sent to browser
DEBUG - 2011-05-03 09:28:45 --> Total execution time: 0.0558
DEBUG - 2011-05-03 09:28:46 --> Config Class Initialized
DEBUG - 2011-05-03 09:28:46 --> Hooks Class Initialized
DEBUG - 2011-05-03 09:28:46 --> Utf8 Class Initialized
DEBUG - 2011-05-03 09:28:46 --> UTF-8 Support Enabled
DEBUG - 2011-05-03 09:28:46 --> URI Class Initialized
DEBUG - 2011-05-03 09:28:46 --> Router Class Initialized
DEBUG - 2011-05-03 09:28:46 --> Output Class Initialized
DEBUG - 2011-05-03 09:28:46 --> Input Class Initialized
DEBUG - 2011-05-03 09:28:46 --> Global POST and COOKIE data sanitized
DEBUG - 2011-05-03 09:28:46 --> Language Class Initialized
DEBUG - 2011-05-03 09:28:46 --> Loader Class Initialized
DEBUG - 2011-05-03 09:28:46 --> Controller Class Initialized
DEBUG - 2011-05-03 09:28:46 --> Model Class Initialized
DEBUG - 2011-05-03 09:28:46 --> Model Class Initialized
DEBUG - 2011-05-03 09:28:46 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-05-03 09:28:46 --> Database Driver Class Initialized
DEBUG - 2011-05-03 09:28:46 --> Config Class Initialized
DEBUG - 2011-05-03 09:28:46 --> Hooks Class Initialized
DEBUG - 2011-05-03 09:28:46 --> Utf8 Class Initialized
DEBUG - 2011-05-03 09:28:46 --> UTF-8 Support Enabled
DEBUG - 2011-05-03 09:28:46 --> URI Class Initialized
DEBUG - 2011-05-03 09:28:46 --> Router Class Initialized
DEBUG - 2011-05-03 09:28:46 --> Output Class Initialized
DEBUG - 2011-05-03 09:28:46 --> Input Class Initialized
DEBUG - 2011-05-03 09:28:46 --> Global POST and COOKIE data sanitized
DEBUG - 2011-05-03 09:28:46 --> Language Class Initialized
DEBUG - 2011-05-03 09:28:46 --> Loader Class Initialized
DEBUG - 2011-05-03 09:28:46 --> Controller Class Initialized
ERROR - 2011-05-03 09:28:46 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-05-03 09:28:46 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-05-03 09:28:46 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-05-03 09:28:46 --> Model Class Initialized
DEBUG - 2011-05-03 09:28:46 --> Model Class Initialized
DEBUG - 2011-05-03 09:28:46 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-05-03 09:28:46 --> Database Driver Class Initialized
DEBUG - 2011-05-03 09:28:46 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-05-03 09:28:46 --> Helper loaded: url_helper
DEBUG - 2011-05-03 09:28:46 --> File loaded: application/views/common/header.php
DEBUG - 2011-05-03 09:28:46 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-05-03 09:28:46 --> File loaded: application/views/common/footer.php
DEBUG - 2011-05-03 09:28:46 --> File loaded: application/views/layout/main.php
DEBUG - 2011-05-03 09:28:46 --> Final output sent to browser
DEBUG - 2011-05-03 09:28:46 --> Total execution time: 0.0330
DEBUG - 2011-05-03 09:28:47 --> Final output sent to browser
DEBUG - 2011-05-03 09:28:47 --> Total execution time: 0.6537
DEBUG - 2011-05-03 09:28:50 --> Config Class Initialized
DEBUG - 2011-05-03 09:28:50 --> Hooks Class Initialized
DEBUG - 2011-05-03 09:28:50 --> Utf8 Class Initialized
DEBUG - 2011-05-03 09:28:50 --> UTF-8 Support Enabled
DEBUG - 2011-05-03 09:28:50 --> URI Class Initialized
DEBUG - 2011-05-03 09:28:50 --> Router Class Initialized
DEBUG - 2011-05-03 09:28:50 --> Output Class Initialized
DEBUG - 2011-05-03 09:28:50 --> Input Class Initialized
DEBUG - 2011-05-03 09:28:50 --> Global POST and COOKIE data sanitized
DEBUG - 2011-05-03 09:28:50 --> Language Class Initialized
DEBUG - 2011-05-03 09:28:50 --> Loader Class Initialized
DEBUG - 2011-05-03 09:28:50 --> Controller Class Initialized
ERROR - 2011-05-03 09:28:50 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-05-03 09:28:50 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-05-03 09:28:50 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-05-03 09:28:50 --> Model Class Initialized
DEBUG - 2011-05-03 09:28:50 --> Model Class Initialized
DEBUG - 2011-05-03 09:28:50 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-05-03 09:28:50 --> Database Driver Class Initialized
DEBUG - 2011-05-03 09:28:50 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-05-03 09:28:50 --> Helper loaded: url_helper
DEBUG - 2011-05-03 09:28:50 --> File loaded: application/views/common/header.php
DEBUG - 2011-05-03 09:28:50 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-05-03 09:28:50 --> File loaded: application/views/common/footer.php
DEBUG - 2011-05-03 09:28:50 --> File loaded: application/views/layout/main.php
DEBUG - 2011-05-03 09:28:50 --> Final output sent to browser
DEBUG - 2011-05-03 09:28:50 --> Total execution time: 0.0295
DEBUG - 2011-05-03 09:28:51 --> Config Class Initialized
DEBUG - 2011-05-03 09:28:51 --> Hooks Class Initialized
DEBUG - 2011-05-03 09:28:51 --> Utf8 Class Initialized
DEBUG - 2011-05-03 09:28:51 --> UTF-8 Support Enabled
DEBUG - 2011-05-03 09:28:51 --> URI Class Initialized
DEBUG - 2011-05-03 09:28:51 --> Router Class Initialized
DEBUG - 2011-05-03 09:28:51 --> Output Class Initialized
DEBUG - 2011-05-03 09:28:51 --> Input Class Initialized
DEBUG - 2011-05-03 09:28:51 --> Global POST and COOKIE data sanitized
DEBUG - 2011-05-03 09:28:51 --> Language Class Initialized
DEBUG - 2011-05-03 09:28:51 --> Loader Class Initialized
DEBUG - 2011-05-03 09:28:51 --> Controller Class Initialized
DEBUG - 2011-05-03 09:28:51 --> Model Class Initialized
DEBUG - 2011-05-03 09:28:51 --> Model Class Initialized
DEBUG - 2011-05-03 09:28:51 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-05-03 09:28:51 --> Database Driver Class Initialized
DEBUG - 2011-05-03 09:28:52 --> Config Class Initialized
DEBUG - 2011-05-03 09:28:52 --> Hooks Class Initialized
DEBUG - 2011-05-03 09:28:52 --> Utf8 Class Initialized
DEBUG - 2011-05-03 09:28:52 --> UTF-8 Support Enabled
DEBUG - 2011-05-03 09:28:52 --> URI Class Initialized
DEBUG - 2011-05-03 09:28:52 --> Router Class Initialized
DEBUG - 2011-05-03 09:28:52 --> Output Class Initialized
DEBUG - 2011-05-03 09:28:52 --> Input Class Initialized
DEBUG - 2011-05-03 09:28:52 --> Global POST and COOKIE data sanitized
DEBUG - 2011-05-03 09:28:52 --> Language Class Initialized
DEBUG - 2011-05-03 09:28:52 --> Loader Class Initialized
DEBUG - 2011-05-03 09:28:52 --> Controller Class Initialized
ERROR - 2011-05-03 09:28:52 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-05-03 09:28:52 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-05-03 09:28:52 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-05-03 09:28:52 --> Model Class Initialized
DEBUG - 2011-05-03 09:28:52 --> Model Class Initialized
DEBUG - 2011-05-03 09:28:52 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-05-03 09:28:52 --> Database Driver Class Initialized
DEBUG - 2011-05-03 09:28:52 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-05-03 09:28:52 --> Helper loaded: url_helper
DEBUG - 2011-05-03 09:28:52 --> File loaded: application/views/common/header.php
DEBUG - 2011-05-03 09:28:52 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-05-03 09:28:52 --> File loaded: application/views/common/footer.php
DEBUG - 2011-05-03 09:28:52 --> File loaded: application/views/layout/main.php
DEBUG - 2011-05-03 09:28:52 --> Final output sent to browser
DEBUG - 2011-05-03 09:28:52 --> Total execution time: 0.0338
DEBUG - 2011-05-03 09:28:52 --> Final output sent to browser
DEBUG - 2011-05-03 09:28:52 --> Total execution time: 1.2015
DEBUG - 2011-05-03 09:29:01 --> Config Class Initialized
DEBUG - 2011-05-03 09:29:01 --> Hooks Class Initialized
DEBUG - 2011-05-03 09:29:01 --> Utf8 Class Initialized
DEBUG - 2011-05-03 09:29:01 --> UTF-8 Support Enabled
DEBUG - 2011-05-03 09:29:01 --> URI Class Initialized
DEBUG - 2011-05-03 09:29:01 --> Router Class Initialized
DEBUG - 2011-05-03 09:29:01 --> Output Class Initialized
DEBUG - 2011-05-03 09:29:01 --> Input Class Initialized
DEBUG - 2011-05-03 09:29:01 --> Global POST and COOKIE data sanitized
DEBUG - 2011-05-03 09:29:01 --> Language Class Initialized
DEBUG - 2011-05-03 09:29:01 --> Loader Class Initialized
DEBUG - 2011-05-03 09:29:01 --> Controller Class Initialized
ERROR - 2011-05-03 09:29:01 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-05-03 09:29:01 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-05-03 09:29:01 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-05-03 09:29:01 --> Model Class Initialized
DEBUG - 2011-05-03 09:29:01 --> Model Class Initialized
DEBUG - 2011-05-03 09:29:01 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-05-03 09:29:01 --> Database Driver Class Initialized
DEBUG - 2011-05-03 09:29:01 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-05-03 09:29:01 --> Helper loaded: url_helper
DEBUG - 2011-05-03 09:29:01 --> File loaded: application/views/common/header.php
DEBUG - 2011-05-03 09:29:01 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-05-03 09:29:01 --> File loaded: application/views/common/footer.php
DEBUG - 2011-05-03 09:29:01 --> File loaded: application/views/layout/main.php
DEBUG - 2011-05-03 09:29:01 --> Final output sent to browser
DEBUG - 2011-05-03 09:29:01 --> Total execution time: 0.0910
DEBUG - 2011-05-03 09:29:02 --> Config Class Initialized
DEBUG - 2011-05-03 09:29:02 --> Hooks Class Initialized
DEBUG - 2011-05-03 09:29:02 --> Utf8 Class Initialized
DEBUG - 2011-05-03 09:29:02 --> UTF-8 Support Enabled
DEBUG - 2011-05-03 09:29:02 --> URI Class Initialized
DEBUG - 2011-05-03 09:29:02 --> Router Class Initialized
DEBUG - 2011-05-03 09:29:02 --> Output Class Initialized
DEBUG - 2011-05-03 09:29:02 --> Input Class Initialized
DEBUG - 2011-05-03 09:29:02 --> Global POST and COOKIE data sanitized
DEBUG - 2011-05-03 09:29:02 --> Language Class Initialized
DEBUG - 2011-05-03 09:29:02 --> Loader Class Initialized
DEBUG - 2011-05-03 09:29:02 --> Controller Class Initialized
DEBUG - 2011-05-03 09:29:02 --> Model Class Initialized
DEBUG - 2011-05-03 09:29:02 --> Model Class Initialized
DEBUG - 2011-05-03 09:29:02 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-05-03 09:29:02 --> Database Driver Class Initialized
DEBUG - 2011-05-03 09:29:03 --> Final output sent to browser
DEBUG - 2011-05-03 09:29:03 --> Total execution time: 0.6473
DEBUG - 2011-05-03 09:29:53 --> Config Class Initialized
DEBUG - 2011-05-03 09:29:53 --> Hooks Class Initialized
DEBUG - 2011-05-03 09:29:53 --> Utf8 Class Initialized
DEBUG - 2011-05-03 09:29:53 --> UTF-8 Support Enabled
DEBUG - 2011-05-03 09:29:53 --> URI Class Initialized
DEBUG - 2011-05-03 09:29:53 --> Router Class Initialized
DEBUG - 2011-05-03 09:29:53 --> No URI present. Default controller set.
DEBUG - 2011-05-03 09:29:53 --> Output Class Initialized
DEBUG - 2011-05-03 09:29:53 --> Input Class Initialized
DEBUG - 2011-05-03 09:29:53 --> Global POST and COOKIE data sanitized
DEBUG - 2011-05-03 09:29:53 --> Language Class Initialized
DEBUG - 2011-05-03 09:29:53 --> Loader Class Initialized
DEBUG - 2011-05-03 09:29:53 --> Controller Class Initialized
DEBUG - 2011-05-03 09:29:53 --> File loaded: application/views/splash/main.php
DEBUG - 2011-05-03 09:29:53 --> Helper loaded: url_helper
DEBUG - 2011-05-03 09:29:53 --> File loaded: application/views/common/header.php
DEBUG - 2011-05-03 09:29:53 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-05-03 09:29:53 --> File loaded: application/views/common/footer.php
DEBUG - 2011-05-03 09:29:53 --> File loaded: application/views/layout/main.php
DEBUG - 2011-05-03 09:29:53 --> Final output sent to browser
DEBUG - 2011-05-03 09:29:53 --> Total execution time: 0.2111
DEBUG - 2011-05-03 09:29:57 --> Config Class Initialized
DEBUG - 2011-05-03 09:29:57 --> Hooks Class Initialized
DEBUG - 2011-05-03 09:29:57 --> Utf8 Class Initialized
DEBUG - 2011-05-03 09:29:57 --> UTF-8 Support Enabled
DEBUG - 2011-05-03 09:29:57 --> URI Class Initialized
DEBUG - 2011-05-03 09:29:57 --> Router Class Initialized
DEBUG - 2011-05-03 09:29:57 --> No URI present. Default controller set.
DEBUG - 2011-05-03 09:29:57 --> Output Class Initialized
DEBUG - 2011-05-03 09:29:57 --> Input Class Initialized
DEBUG - 2011-05-03 09:29:57 --> Global POST and COOKIE data sanitized
DEBUG - 2011-05-03 09:29:57 --> Language Class Initialized
DEBUG - 2011-05-03 09:29:57 --> Loader Class Initialized
DEBUG - 2011-05-03 09:29:57 --> Controller Class Initialized
DEBUG - 2011-05-03 09:29:57 --> File loaded: application/views/splash/main.php
DEBUG - 2011-05-03 09:29:57 --> Helper loaded: url_helper
DEBUG - 2011-05-03 09:29:57 --> File loaded: application/views/common/header.php
DEBUG - 2011-05-03 09:29:57 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-05-03 09:29:57 --> File loaded: application/views/common/footer.php
DEBUG - 2011-05-03 09:29:57 --> File loaded: application/views/layout/main.php
DEBUG - 2011-05-03 09:29:57 --> Final output sent to browser
DEBUG - 2011-05-03 09:29:57 --> Total execution time: 0.3391
DEBUG - 2011-05-03 09:30:03 --> Config Class Initialized
DEBUG - 2011-05-03 09:30:03 --> Hooks Class Initialized
DEBUG - 2011-05-03 09:30:03 --> Utf8 Class Initialized
DEBUG - 2011-05-03 09:30:03 --> UTF-8 Support Enabled
DEBUG - 2011-05-03 09:30:03 --> URI Class Initialized
DEBUG - 2011-05-03 09:30:03 --> Router Class Initialized
DEBUG - 2011-05-03 09:30:03 --> Output Class Initialized
DEBUG - 2011-05-03 09:30:03 --> Input Class Initialized
DEBUG - 2011-05-03 09:30:03 --> Global POST and COOKIE data sanitized
DEBUG - 2011-05-03 09:30:03 --> Language Class Initialized
DEBUG - 2011-05-03 09:30:03 --> Loader Class Initialized
DEBUG - 2011-05-03 09:30:03 --> Controller Class Initialized
ERROR - 2011-05-03 09:30:03 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-05-03 09:30:03 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-05-03 09:30:03 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-05-03 09:30:03 --> Model Class Initialized
DEBUG - 2011-05-03 09:30:03 --> Model Class Initialized
DEBUG - 2011-05-03 09:30:03 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-05-03 09:30:03 --> Database Driver Class Initialized
DEBUG - 2011-05-03 09:30:04 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-05-03 09:30:04 --> Helper loaded: url_helper
DEBUG - 2011-05-03 09:30:04 --> File loaded: application/views/common/header.php
DEBUG - 2011-05-03 09:30:04 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-05-03 09:30:04 --> File loaded: application/views/common/footer.php
DEBUG - 2011-05-03 09:30:04 --> File loaded: application/views/layout/main.php
DEBUG - 2011-05-03 09:30:04 --> Final output sent to browser
DEBUG - 2011-05-03 09:30:04 --> Total execution time: 1.2600
DEBUG - 2011-05-03 09:30:06 --> Config Class Initialized
DEBUG - 2011-05-03 09:30:06 --> Hooks Class Initialized
DEBUG - 2011-05-03 09:30:06 --> Utf8 Class Initialized
DEBUG - 2011-05-03 09:30:06 --> UTF-8 Support Enabled
DEBUG - 2011-05-03 09:30:06 --> URI Class Initialized
DEBUG - 2011-05-03 09:30:06 --> Router Class Initialized
DEBUG - 2011-05-03 09:30:06 --> Output Class Initialized
DEBUG - 2011-05-03 09:30:06 --> Input Class Initialized
DEBUG - 2011-05-03 09:30:06 --> Global POST and COOKIE data sanitized
DEBUG - 2011-05-03 09:30:06 --> Language Class Initialized
DEBUG - 2011-05-03 09:30:06 --> Loader Class Initialized
DEBUG - 2011-05-03 09:30:06 --> Controller Class Initialized
DEBUG - 2011-05-03 09:30:06 --> Model Class Initialized
DEBUG - 2011-05-03 09:30:06 --> Model Class Initialized
DEBUG - 2011-05-03 09:30:06 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-05-03 09:30:06 --> Database Driver Class Initialized
DEBUG - 2011-05-03 09:30:07 --> Final output sent to browser
DEBUG - 2011-05-03 09:30:07 --> Total execution time: 1.0197
DEBUG - 2011-05-03 09:30:16 --> Config Class Initialized
DEBUG - 2011-05-03 09:30:16 --> Hooks Class Initialized
DEBUG - 2011-05-03 09:30:16 --> Utf8 Class Initialized
DEBUG - 2011-05-03 09:30:16 --> UTF-8 Support Enabled
DEBUG - 2011-05-03 09:30:16 --> URI Class Initialized
DEBUG - 2011-05-03 09:30:16 --> Router Class Initialized
DEBUG - 2011-05-03 09:30:16 --> Output Class Initialized
DEBUG - 2011-05-03 09:30:16 --> Input Class Initialized
DEBUG - 2011-05-03 09:30:16 --> Global POST and COOKIE data sanitized
DEBUG - 2011-05-03 09:30:16 --> Language Class Initialized
DEBUG - 2011-05-03 09:30:17 --> Loader Class Initialized
DEBUG - 2011-05-03 09:30:17 --> Controller Class Initialized
DEBUG - 2011-05-03 09:30:17 --> Model Class Initialized
DEBUG - 2011-05-03 09:30:18 --> Model Class Initialized
DEBUG - 2011-05-03 09:30:18 --> Model Class Initialized
DEBUG - 2011-05-03 09:30:18 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-05-03 09:30:18 --> Database Driver Class Initialized
DEBUG - 2011-05-03 09:30:18 --> File loaded: application/views/table/main.php
DEBUG - 2011-05-03 09:30:18 --> Helper loaded: url_helper
DEBUG - 2011-05-03 09:30:18 --> File loaded: application/views/common/header.php
DEBUG - 2011-05-03 09:30:18 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-05-03 09:30:18 --> File loaded: application/views/common/footer.php
DEBUG - 2011-05-03 09:30:18 --> File loaded: application/views/layout/main.php
DEBUG - 2011-05-03 09:30:18 --> Final output sent to browser
DEBUG - 2011-05-03 09:30:18 --> Total execution time: 1.5413
DEBUG - 2011-05-03 09:30:21 --> Config Class Initialized
DEBUG - 2011-05-03 09:30:21 --> Hooks Class Initialized
DEBUG - 2011-05-03 09:30:21 --> Utf8 Class Initialized
DEBUG - 2011-05-03 09:30:21 --> UTF-8 Support Enabled
DEBUG - 2011-05-03 09:30:21 --> URI Class Initialized
DEBUG - 2011-05-03 09:30:21 --> Router Class Initialized
DEBUG - 2011-05-03 09:30:21 --> Output Class Initialized
DEBUG - 2011-05-03 09:30:21 --> Input Class Initialized
DEBUG - 2011-05-03 09:30:21 --> Global POST and COOKIE data sanitized
DEBUG - 2011-05-03 09:30:21 --> Language Class Initialized
DEBUG - 2011-05-03 09:30:21 --> Loader Class Initialized
DEBUG - 2011-05-03 09:30:21 --> Controller Class Initialized
DEBUG - 2011-05-03 09:30:21 --> Model Class Initialized
DEBUG - 2011-05-03 09:30:21 --> Model Class Initialized
DEBUG - 2011-05-03 09:30:21 --> Model Class Initialized
DEBUG - 2011-05-03 09:30:21 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-05-03 09:30:21 --> Database Driver Class Initialized
DEBUG - 2011-05-03 09:30:21 --> File loaded: application/views/table/main.php
DEBUG - 2011-05-03 09:30:21 --> Helper loaded: url_helper
DEBUG - 2011-05-03 09:30:21 --> File loaded: application/views/common/header.php
DEBUG - 2011-05-03 09:30:21 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-05-03 09:30:21 --> File loaded: application/views/common/footer.php
DEBUG - 2011-05-03 09:30:21 --> File loaded: application/views/layout/main.php
DEBUG - 2011-05-03 09:30:21 --> Final output sent to browser
DEBUG - 2011-05-03 09:30:21 --> Total execution time: 0.2394
DEBUG - 2011-05-03 09:30:25 --> Config Class Initialized
DEBUG - 2011-05-03 09:30:25 --> Hooks Class Initialized
DEBUG - 2011-05-03 09:30:25 --> Utf8 Class Initialized
DEBUG - 2011-05-03 09:30:25 --> UTF-8 Support Enabled
DEBUG - 2011-05-03 09:30:25 --> URI Class Initialized
DEBUG - 2011-05-03 09:30:25 --> Router Class Initialized
DEBUG - 2011-05-03 09:30:25 --> Output Class Initialized
DEBUG - 2011-05-03 09:30:25 --> Input Class Initialized
DEBUG - 2011-05-03 09:30:25 --> Global POST and COOKIE data sanitized
DEBUG - 2011-05-03 09:30:25 --> Language Class Initialized
DEBUG - 2011-05-03 09:30:25 --> Loader Class Initialized
DEBUG - 2011-05-03 09:30:25 --> Controller Class Initialized
ERROR - 2011-05-03 09:30:25 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-05-03 09:30:25 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-05-03 09:30:25 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-05-03 09:30:25 --> Model Class Initialized
DEBUG - 2011-05-03 09:30:25 --> Model Class Initialized
DEBUG - 2011-05-03 09:30:25 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-05-03 09:30:25 --> Database Driver Class Initialized
DEBUG - 2011-05-03 09:30:25 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-05-03 09:30:25 --> Helper loaded: url_helper
DEBUG - 2011-05-03 09:30:25 --> File loaded: application/views/common/header.php
DEBUG - 2011-05-03 09:30:25 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-05-03 09:30:25 --> File loaded: application/views/common/footer.php
DEBUG - 2011-05-03 09:30:25 --> File loaded: application/views/layout/main.php
DEBUG - 2011-05-03 09:30:25 --> Final output sent to browser
DEBUG - 2011-05-03 09:30:25 --> Total execution time: 0.1162
DEBUG - 2011-05-03 09:30:34 --> Config Class Initialized
DEBUG - 2011-05-03 09:30:34 --> Hooks Class Initialized
DEBUG - 2011-05-03 09:30:34 --> Utf8 Class Initialized
DEBUG - 2011-05-03 09:30:34 --> UTF-8 Support Enabled
DEBUG - 2011-05-03 09:30:34 --> URI Class Initialized
DEBUG - 2011-05-03 09:30:35 --> Router Class Initialized
DEBUG - 2011-05-03 09:30:35 --> Output Class Initialized
DEBUG - 2011-05-03 09:30:35 --> Input Class Initialized
DEBUG - 2011-05-03 09:30:35 --> Global POST and COOKIE data sanitized
DEBUG - 2011-05-03 09:30:35 --> Language Class Initialized
DEBUG - 2011-05-03 09:30:35 --> Loader Class Initialized
DEBUG - 2011-05-03 09:30:35 --> Controller Class Initialized
DEBUG - 2011-05-03 09:30:35 --> Model Class Initialized
DEBUG - 2011-05-03 09:30:35 --> Model Class Initialized
DEBUG - 2011-05-03 09:30:35 --> Model Class Initialized
DEBUG - 2011-05-03 09:30:35 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-05-03 09:30:35 --> Database Driver Class Initialized
DEBUG - 2011-05-03 09:30:39 --> File loaded: application/views/table/main.php
DEBUG - 2011-05-03 09:30:39 --> Helper loaded: url_helper
DEBUG - 2011-05-03 09:30:39 --> File loaded: application/views/common/header.php
DEBUG - 2011-05-03 09:30:39 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-05-03 09:30:39 --> File loaded: application/views/common/footer.php
DEBUG - 2011-05-03 09:30:39 --> File loaded: application/views/layout/main.php
DEBUG - 2011-05-03 09:30:39 --> Final output sent to browser
DEBUG - 2011-05-03 09:30:39 --> Total execution time: 5.0196
DEBUG - 2011-05-03 09:30:43 --> Config Class Initialized
DEBUG - 2011-05-03 09:30:43 --> Hooks Class Initialized
DEBUG - 2011-05-03 09:30:43 --> Utf8 Class Initialized
DEBUG - 2011-05-03 09:30:43 --> UTF-8 Support Enabled
DEBUG - 2011-05-03 09:30:43 --> URI Class Initialized
DEBUG - 2011-05-03 09:30:43 --> Router Class Initialized
DEBUG - 2011-05-03 09:30:43 --> Output Class Initialized
DEBUG - 2011-05-03 09:30:43 --> Input Class Initialized
DEBUG - 2011-05-03 09:30:43 --> Global POST and COOKIE data sanitized
DEBUG - 2011-05-03 09:30:43 --> Language Class Initialized
DEBUG - 2011-05-03 09:30:43 --> Loader Class Initialized
DEBUG - 2011-05-03 09:30:43 --> Controller Class Initialized
DEBUG - 2011-05-03 09:30:43 --> Model Class Initialized
DEBUG - 2011-05-03 09:30:43 --> Model Class Initialized
DEBUG - 2011-05-03 09:30:43 --> Model Class Initialized
DEBUG - 2011-05-03 09:30:43 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-05-03 09:30:43 --> Database Driver Class Initialized
DEBUG - 2011-05-03 09:30:43 --> File loaded: application/views/table/main.php
DEBUG - 2011-05-03 09:30:43 --> Helper loaded: url_helper
DEBUG - 2011-05-03 09:30:43 --> File loaded: application/views/common/header.php
DEBUG - 2011-05-03 09:30:43 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-05-03 09:30:43 --> File loaded: application/views/common/footer.php
DEBUG - 2011-05-03 09:30:43 --> File loaded: application/views/layout/main.php
DEBUG - 2011-05-03 09:30:43 --> Final output sent to browser
DEBUG - 2011-05-03 09:30:43 --> Total execution time: 0.3358
DEBUG - 2011-05-03 09:31:12 --> Config Class Initialized
DEBUG - 2011-05-03 09:31:12 --> Hooks Class Initialized
DEBUG - 2011-05-03 09:31:12 --> Utf8 Class Initialized
DEBUG - 2011-05-03 09:31:12 --> UTF-8 Support Enabled
DEBUG - 2011-05-03 09:31:12 --> URI Class Initialized
DEBUG - 2011-05-03 09:31:12 --> Router Class Initialized
DEBUG - 2011-05-03 09:31:12 --> Output Class Initialized
DEBUG - 2011-05-03 09:31:12 --> Input Class Initialized
DEBUG - 2011-05-03 09:31:12 --> Global POST and COOKIE data sanitized
DEBUG - 2011-05-03 09:31:12 --> Language Class Initialized
DEBUG - 2011-05-03 09:31:12 --> Loader Class Initialized
DEBUG - 2011-05-03 09:31:12 --> Controller Class Initialized
DEBUG - 2011-05-03 09:31:12 --> Model Class Initialized
DEBUG - 2011-05-03 09:31:12 --> Model Class Initialized
DEBUG - 2011-05-03 09:31:12 --> Model Class Initialized
DEBUG - 2011-05-03 09:31:12 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-05-03 09:31:12 --> Database Driver Class Initialized
DEBUG - 2011-05-03 09:31:14 --> File loaded: application/views/table/main.php
DEBUG - 2011-05-03 09:31:14 --> Helper loaded: url_helper
DEBUG - 2011-05-03 09:31:14 --> File loaded: application/views/common/header.php
DEBUG - 2011-05-03 09:31:14 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-05-03 09:31:14 --> File loaded: application/views/common/footer.php
DEBUG - 2011-05-03 09:31:14 --> File loaded: application/views/layout/main.php
DEBUG - 2011-05-03 09:31:14 --> Final output sent to browser
DEBUG - 2011-05-03 09:31:14 --> Total execution time: 2.4957
DEBUG - 2011-05-03 09:31:26 --> Config Class Initialized
DEBUG - 2011-05-03 09:31:26 --> Hooks Class Initialized
DEBUG - 2011-05-03 09:31:26 --> Utf8 Class Initialized
DEBUG - 2011-05-03 09:31:26 --> UTF-8 Support Enabled
DEBUG - 2011-05-03 09:31:26 --> URI Class Initialized
DEBUG - 2011-05-03 09:31:26 --> Router Class Initialized
DEBUG - 2011-05-03 09:31:26 --> Output Class Initialized
DEBUG - 2011-05-03 09:31:26 --> Input Class Initialized
DEBUG - 2011-05-03 09:31:26 --> Global POST and COOKIE data sanitized
DEBUG - 2011-05-03 09:31:26 --> Language Class Initialized
DEBUG - 2011-05-03 09:31:26 --> Loader Class Initialized
DEBUG - 2011-05-03 09:31:26 --> Controller Class Initialized
DEBUG - 2011-05-03 09:31:26 --> Model Class Initialized
DEBUG - 2011-05-03 09:31:26 --> Model Class Initialized
DEBUG - 2011-05-03 09:31:26 --> Model Class Initialized
DEBUG - 2011-05-03 09:31:26 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-05-03 09:31:26 --> Database Driver Class Initialized
DEBUG - 2011-05-03 09:31:26 --> File loaded: application/views/table/main.php
DEBUG - 2011-05-03 09:31:26 --> Helper loaded: url_helper
DEBUG - 2011-05-03 09:31:26 --> File loaded: application/views/common/header.php
DEBUG - 2011-05-03 09:31:26 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-05-03 09:31:26 --> File loaded: application/views/common/footer.php
DEBUG - 2011-05-03 09:31:26 --> File loaded: application/views/layout/main.php
DEBUG - 2011-05-03 09:31:26 --> Final output sent to browser
DEBUG - 2011-05-03 09:31:26 --> Total execution time: 0.0801
DEBUG - 2011-05-03 09:36:50 --> Config Class Initialized
DEBUG - 2011-05-03 09:36:50 --> Hooks Class Initialized
DEBUG - 2011-05-03 09:36:50 --> Utf8 Class Initialized
DEBUG - 2011-05-03 09:36:50 --> UTF-8 Support Enabled
DEBUG - 2011-05-03 09:36:50 --> URI Class Initialized
DEBUG - 2011-05-03 09:36:50 --> Router Class Initialized
DEBUG - 2011-05-03 09:36:50 --> No URI present. Default controller set.
DEBUG - 2011-05-03 09:36:50 --> Output Class Initialized
DEBUG - 2011-05-03 09:36:50 --> Input Class Initialized
DEBUG - 2011-05-03 09:36:50 --> Global POST and COOKIE data sanitized
DEBUG - 2011-05-03 09:36:50 --> Language Class Initialized
DEBUG - 2011-05-03 09:36:50 --> Loader Class Initialized
DEBUG - 2011-05-03 09:36:50 --> Controller Class Initialized
DEBUG - 2011-05-03 09:36:50 --> File loaded: application/views/splash/main.php
DEBUG - 2011-05-03 09:36:50 --> Helper loaded: url_helper
DEBUG - 2011-05-03 09:36:50 --> File loaded: application/views/common/header.php
DEBUG - 2011-05-03 09:36:50 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-05-03 09:36:50 --> File loaded: application/views/common/footer.php
DEBUG - 2011-05-03 09:36:50 --> File loaded: application/views/layout/main.php
DEBUG - 2011-05-03 09:36:50 --> Final output sent to browser
DEBUG - 2011-05-03 09:36:50 --> Total execution time: 0.0891
DEBUG - 2011-05-03 09:55:40 --> Config Class Initialized
DEBUG - 2011-05-03 09:55:40 --> Hooks Class Initialized
DEBUG - 2011-05-03 09:55:40 --> Utf8 Class Initialized
DEBUG - 2011-05-03 09:55:40 --> UTF-8 Support Enabled
DEBUG - 2011-05-03 09:55:40 --> URI Class Initialized
DEBUG - 2011-05-03 09:55:40 --> Router Class Initialized
ERROR - 2011-05-03 09:55:40 --> 404 Page Not Found --> robots.txt
DEBUG - 2011-05-03 09:56:18 --> Config Class Initialized
DEBUG - 2011-05-03 09:56:18 --> Hooks Class Initialized
DEBUG - 2011-05-03 09:56:18 --> Utf8 Class Initialized
DEBUG - 2011-05-03 09:56:18 --> UTF-8 Support Enabled
DEBUG - 2011-05-03 09:56:18 --> URI Class Initialized
DEBUG - 2011-05-03 09:56:18 --> Router Class Initialized
DEBUG - 2011-05-03 09:56:18 --> Output Class Initialized
DEBUG - 2011-05-03 09:56:18 --> Input Class Initialized
DEBUG - 2011-05-03 09:56:18 --> Global POST and COOKIE data sanitized
DEBUG - 2011-05-03 09:56:18 --> Language Class Initialized
DEBUG - 2011-05-03 09:56:18 --> Loader Class Initialized
DEBUG - 2011-05-03 09:56:18 --> Controller Class Initialized
ERROR - 2011-05-03 09:56:18 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-05-03 09:56:18 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-05-03 09:56:18 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-05-03 09:56:18 --> Model Class Initialized
DEBUG - 2011-05-03 09:56:18 --> Model Class Initialized
DEBUG - 2011-05-03 09:56:18 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-05-03 09:56:18 --> Database Driver Class Initialized
DEBUG - 2011-05-03 09:56:18 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-05-03 09:56:18 --> Helper loaded: url_helper
DEBUG - 2011-05-03 09:56:18 --> File loaded: application/views/common/header.php
DEBUG - 2011-05-03 09:56:18 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-05-03 09:56:18 --> File loaded: application/views/common/footer.php
DEBUG - 2011-05-03 09:56:18 --> File loaded: application/views/layout/main.php
DEBUG - 2011-05-03 09:56:18 --> Final output sent to browser
DEBUG - 2011-05-03 09:56:18 --> Total execution time: 0.3622
DEBUG - 2011-05-03 10:04:54 --> Config Class Initialized
DEBUG - 2011-05-03 10:04:54 --> Hooks Class Initialized
DEBUG - 2011-05-03 10:04:54 --> Utf8 Class Initialized
DEBUG - 2011-05-03 10:04:54 --> UTF-8 Support Enabled
DEBUG - 2011-05-03 10:04:54 --> URI Class Initialized
DEBUG - 2011-05-03 10:04:54 --> Router Class Initialized
ERROR - 2011-05-03 10:04:54 --> 404 Page Not Found --> robots.txt
DEBUG - 2011-05-03 10:04:55 --> Config Class Initialized
DEBUG - 2011-05-03 10:04:55 --> Hooks Class Initialized
DEBUG - 2011-05-03 10:04:55 --> Utf8 Class Initialized
DEBUG - 2011-05-03 10:04:55 --> UTF-8 Support Enabled
DEBUG - 2011-05-03 10:04:55 --> URI Class Initialized
DEBUG - 2011-05-03 10:04:55 --> Router Class Initialized
DEBUG - 2011-05-03 10:04:55 --> No URI present. Default controller set.
DEBUG - 2011-05-03 10:04:55 --> Output Class Initialized
DEBUG - 2011-05-03 10:04:55 --> Input Class Initialized
DEBUG - 2011-05-03 10:04:55 --> Global POST and COOKIE data sanitized
DEBUG - 2011-05-03 10:04:55 --> Language Class Initialized
DEBUG - 2011-05-03 10:04:55 --> Loader Class Initialized
DEBUG - 2011-05-03 10:04:55 --> Controller Class Initialized
DEBUG - 2011-05-03 10:04:55 --> File loaded: application/views/splash/main.php
DEBUG - 2011-05-03 10:04:55 --> Helper loaded: url_helper
DEBUG - 2011-05-03 10:04:55 --> File loaded: application/views/common/header.php
DEBUG - 2011-05-03 10:04:55 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-05-03 10:04:55 --> File loaded: application/views/common/footer.php
DEBUG - 2011-05-03 10:04:55 --> File loaded: application/views/layout/main.php
DEBUG - 2011-05-03 10:04:55 --> Final output sent to browser
DEBUG - 2011-05-03 10:04:55 --> Total execution time: 0.1619
DEBUG - 2011-05-03 11:05:11 --> Config Class Initialized
DEBUG - 2011-05-03 11:05:12 --> Hooks Class Initialized
DEBUG - 2011-05-03 11:05:12 --> Utf8 Class Initialized
DEBUG - 2011-05-03 11:05:12 --> UTF-8 Support Enabled
DEBUG - 2011-05-03 11:05:12 --> URI Class Initialized
DEBUG - 2011-05-03 11:05:12 --> Router Class Initialized
DEBUG - 2011-05-03 11:05:12 --> Output Class Initialized
DEBUG - 2011-05-03 11:05:12 --> Input Class Initialized
DEBUG - 2011-05-03 11:05:12 --> Global POST and COOKIE data sanitized
DEBUG - 2011-05-03 11:05:12 --> Language Class Initialized
DEBUG - 2011-05-03 11:05:12 --> Loader Class Initialized
DEBUG - 2011-05-03 11:05:12 --> Controller Class Initialized
DEBUG - 2011-05-03 11:05:12 --> Model Class Initialized
DEBUG - 2011-05-03 11:05:12 --> Model Class Initialized
DEBUG - 2011-05-03 11:05:12 --> Model Class Initialized
DEBUG - 2011-05-03 11:05:12 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-05-03 11:05:12 --> Database Driver Class Initialized
DEBUG - 2011-05-03 11:05:13 --> File loaded: application/views/table/main.php
DEBUG - 2011-05-03 11:05:13 --> Helper loaded: url_helper
DEBUG - 2011-05-03 11:05:13 --> File loaded: application/views/common/header.php
DEBUG - 2011-05-03 11:05:13 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-05-03 11:05:13 --> File loaded: application/views/common/footer.php
DEBUG - 2011-05-03 11:05:13 --> File loaded: application/views/layout/main.php
DEBUG - 2011-05-03 11:05:13 --> Final output sent to browser
DEBUG - 2011-05-03 11:05:13 --> Total execution time: 1.9727
DEBUG - 2011-05-03 11:05:14 --> Config Class Initialized
DEBUG - 2011-05-03 11:05:14 --> Hooks Class Initialized
DEBUG - 2011-05-03 11:05:14 --> Utf8 Class Initialized
DEBUG - 2011-05-03 11:05:14 --> UTF-8 Support Enabled
DEBUG - 2011-05-03 11:05:14 --> URI Class Initialized
DEBUG - 2011-05-03 11:05:14 --> Router Class Initialized
DEBUG - 2011-05-03 11:05:14 --> Output Class Initialized
DEBUG - 2011-05-03 11:05:14 --> Input Class Initialized
DEBUG - 2011-05-03 11:05:14 --> Global POST and COOKIE data sanitized
DEBUG - 2011-05-03 11:05:14 --> Language Class Initialized
DEBUG - 2011-05-03 11:05:14 --> Loader Class Initialized
DEBUG - 2011-05-03 11:05:14 --> Controller Class Initialized
ERROR - 2011-05-03 11:05:14 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-05-03 11:05:14 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-05-03 11:05:14 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-05-03 11:05:14 --> Model Class Initialized
DEBUG - 2011-05-03 11:05:14 --> Model Class Initialized
DEBUG - 2011-05-03 11:05:14 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-05-03 11:05:14 --> Database Driver Class Initialized
DEBUG - 2011-05-03 11:05:14 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-05-03 11:05:14 --> Helper loaded: url_helper
DEBUG - 2011-05-03 11:05:14 --> File loaded: application/views/common/header.php
DEBUG - 2011-05-03 11:05:14 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-05-03 11:05:14 --> File loaded: application/views/common/footer.php
DEBUG - 2011-05-03 11:05:14 --> File loaded: application/views/layout/main.php
DEBUG - 2011-05-03 11:05:14 --> Final output sent to browser
DEBUG - 2011-05-03 11:05:14 --> Total execution time: 0.2861
DEBUG - 2011-05-03 11:26:30 --> Config Class Initialized
DEBUG - 2011-05-03 11:26:30 --> Hooks Class Initialized
DEBUG - 2011-05-03 11:26:30 --> Utf8 Class Initialized
DEBUG - 2011-05-03 11:26:30 --> UTF-8 Support Enabled
DEBUG - 2011-05-03 11:26:30 --> URI Class Initialized
DEBUG - 2011-05-03 11:26:30 --> Router Class Initialized
DEBUG - 2011-05-03 11:26:30 --> Output Class Initialized
DEBUG - 2011-05-03 11:26:30 --> Input Class Initialized
DEBUG - 2011-05-03 11:26:30 --> Global POST and COOKIE data sanitized
DEBUG - 2011-05-03 11:26:30 --> Language Class Initialized
DEBUG - 2011-05-03 11:26:30 --> Loader Class Initialized
DEBUG - 2011-05-03 11:26:30 --> Controller Class Initialized
ERROR - 2011-05-03 11:26:30 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-05-03 11:26:30 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-05-03 11:26:30 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-05-03 11:26:30 --> Model Class Initialized
DEBUG - 2011-05-03 11:26:30 --> Model Class Initialized
DEBUG - 2011-05-03 11:26:30 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-05-03 11:26:30 --> Database Driver Class Initialized
DEBUG - 2011-05-03 11:26:30 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-05-03 11:26:30 --> Helper loaded: url_helper
DEBUG - 2011-05-03 11:26:30 --> File loaded: application/views/common/header.php
DEBUG - 2011-05-03 11:26:30 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-05-03 11:26:30 --> File loaded: application/views/common/footer.php
DEBUG - 2011-05-03 11:26:30 --> File loaded: application/views/layout/main.php
DEBUG - 2011-05-03 11:26:30 --> Final output sent to browser
DEBUG - 2011-05-03 11:26:30 --> Total execution time: 0.4196
DEBUG - 2011-05-03 11:26:31 --> Config Class Initialized
DEBUG - 2011-05-03 11:26:31 --> Hooks Class Initialized
DEBUG - 2011-05-03 11:26:31 --> Utf8 Class Initialized
DEBUG - 2011-05-03 11:26:31 --> UTF-8 Support Enabled
DEBUG - 2011-05-03 11:26:31 --> URI Class Initialized
DEBUG - 2011-05-03 11:26:31 --> Router Class Initialized
DEBUG - 2011-05-03 11:26:31 --> Output Class Initialized
DEBUG - 2011-05-03 11:26:31 --> Input Class Initialized
DEBUG - 2011-05-03 11:26:31 --> Global POST and COOKIE data sanitized
DEBUG - 2011-05-03 11:26:31 --> Language Class Initialized
DEBUG - 2011-05-03 11:26:31 --> Loader Class Initialized
DEBUG - 2011-05-03 11:26:31 --> Controller Class Initialized
DEBUG - 2011-05-03 11:26:32 --> Model Class Initialized
DEBUG - 2011-05-03 11:26:32 --> Model Class Initialized
DEBUG - 2011-05-03 11:26:32 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-05-03 11:26:32 --> Database Driver Class Initialized
DEBUG - 2011-05-03 11:26:32 --> Final output sent to browser
DEBUG - 2011-05-03 11:26:32 --> Total execution time: 0.9192
DEBUG - 2011-05-03 11:26:34 --> Config Class Initialized
DEBUG - 2011-05-03 11:26:34 --> Hooks Class Initialized
DEBUG - 2011-05-03 11:26:34 --> Utf8 Class Initialized
DEBUG - 2011-05-03 11:26:34 --> UTF-8 Support Enabled
DEBUG - 2011-05-03 11:26:34 --> URI Class Initialized
DEBUG - 2011-05-03 11:26:34 --> Router Class Initialized
ERROR - 2011-05-03 11:26:34 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-05-03 12:38:36 --> Config Class Initialized
DEBUG - 2011-05-03 12:38:36 --> Hooks Class Initialized
DEBUG - 2011-05-03 12:38:36 --> Utf8 Class Initialized
DEBUG - 2011-05-03 12:38:36 --> UTF-8 Support Enabled
DEBUG - 2011-05-03 12:38:36 --> URI Class Initialized
DEBUG - 2011-05-03 12:38:36 --> Router Class Initialized
ERROR - 2011-05-03 12:38:36 --> 404 Page Not Found --> robots.txt
DEBUG - 2011-05-03 12:38:38 --> Config Class Initialized
DEBUG - 2011-05-03 12:38:38 --> Hooks Class Initialized
DEBUG - 2011-05-03 12:38:38 --> Utf8 Class Initialized
DEBUG - 2011-05-03 12:38:38 --> UTF-8 Support Enabled
DEBUG - 2011-05-03 12:38:38 --> URI Class Initialized
DEBUG - 2011-05-03 12:38:38 --> Router Class Initialized
DEBUG - 2011-05-03 12:38:38 --> Output Class Initialized
DEBUG - 2011-05-03 12:38:38 --> Input Class Initialized
DEBUG - 2011-05-03 12:38:38 --> Global POST and COOKIE data sanitized
DEBUG - 2011-05-03 12:38:38 --> Language Class Initialized
DEBUG - 2011-05-03 12:38:38 --> Loader Class Initialized
DEBUG - 2011-05-03 12:38:38 --> Controller Class Initialized
DEBUG - 2011-05-03 12:38:38 --> Model Class Initialized
DEBUG - 2011-05-03 12:38:38 --> Model Class Initialized
DEBUG - 2011-05-03 12:38:38 --> Model Class Initialized
DEBUG - 2011-05-03 12:38:38 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-05-03 12:38:38 --> Database Driver Class Initialized
DEBUG - 2011-05-03 12:38:39 --> File loaded: application/views/table/main.php
DEBUG - 2011-05-03 12:38:39 --> Helper loaded: url_helper
DEBUG - 2011-05-03 12:38:39 --> File loaded: application/views/common/header.php
DEBUG - 2011-05-03 12:38:39 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-05-03 12:38:39 --> File loaded: application/views/common/footer.php
DEBUG - 2011-05-03 12:38:39 --> File loaded: application/views/layout/main.php
DEBUG - 2011-05-03 12:38:39 --> Final output sent to browser
DEBUG - 2011-05-03 12:38:39 --> Total execution time: 0.5116
DEBUG - 2011-05-03 12:53:28 --> Config Class Initialized
DEBUG - 2011-05-03 12:53:28 --> Hooks Class Initialized
DEBUG - 2011-05-03 12:53:28 --> Utf8 Class Initialized
DEBUG - 2011-05-03 12:53:28 --> UTF-8 Support Enabled
DEBUG - 2011-05-03 12:53:28 --> URI Class Initialized
DEBUG - 2011-05-03 12:53:28 --> Router Class Initialized
DEBUG - 2011-05-03 12:53:28 --> Output Class Initialized
DEBUG - 2011-05-03 12:53:28 --> Input Class Initialized
DEBUG - 2011-05-03 12:53:28 --> Global POST and COOKIE data sanitized
DEBUG - 2011-05-03 12:53:28 --> Language Class Initialized
DEBUG - 2011-05-03 12:53:28 --> Loader Class Initialized
DEBUG - 2011-05-03 12:53:28 --> Controller Class Initialized
ERROR - 2011-05-03 12:53:28 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-05-03 12:53:28 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-05-03 12:53:28 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-05-03 12:53:28 --> Model Class Initialized
DEBUG - 2011-05-03 12:53:28 --> Model Class Initialized
DEBUG - 2011-05-03 12:53:28 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-05-03 12:53:28 --> Database Driver Class Initialized
DEBUG - 2011-05-03 12:53:28 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-05-03 12:53:28 --> Helper loaded: url_helper
DEBUG - 2011-05-03 12:53:28 --> File loaded: application/views/common/header.php
DEBUG - 2011-05-03 12:53:28 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-05-03 12:53:28 --> File loaded: application/views/common/footer.php
DEBUG - 2011-05-03 12:53:28 --> File loaded: application/views/layout/main.php
DEBUG - 2011-05-03 12:53:28 --> Final output sent to browser
DEBUG - 2011-05-03 12:53:28 --> Total execution time: 0.3408
DEBUG - 2011-05-03 12:53:29 --> Config Class Initialized
DEBUG - 2011-05-03 12:53:29 --> Hooks Class Initialized
DEBUG - 2011-05-03 12:53:29 --> Utf8 Class Initialized
DEBUG - 2011-05-03 12:53:29 --> UTF-8 Support Enabled
DEBUG - 2011-05-03 12:53:29 --> URI Class Initialized
DEBUG - 2011-05-03 12:53:29 --> Router Class Initialized
DEBUG - 2011-05-03 12:53:29 --> Output Class Initialized
DEBUG - 2011-05-03 12:53:29 --> Input Class Initialized
DEBUG - 2011-05-03 12:53:29 --> Global POST and COOKIE data sanitized
DEBUG - 2011-05-03 12:53:29 --> Language Class Initialized
DEBUG - 2011-05-03 12:53:29 --> Loader Class Initialized
DEBUG - 2011-05-03 12:53:29 --> Controller Class Initialized
DEBUG - 2011-05-03 12:53:29 --> Model Class Initialized
DEBUG - 2011-05-03 12:53:29 --> Model Class Initialized
DEBUG - 2011-05-03 12:53:29 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-05-03 12:53:29 --> Database Driver Class Initialized
DEBUG - 2011-05-03 12:53:31 --> Final output sent to browser
DEBUG - 2011-05-03 12:53:31 --> Total execution time: 1.1297
DEBUG - 2011-05-03 12:53:32 --> Config Class Initialized
DEBUG - 2011-05-03 12:53:32 --> Hooks Class Initialized
DEBUG - 2011-05-03 12:53:32 --> Utf8 Class Initialized
DEBUG - 2011-05-03 12:53:32 --> UTF-8 Support Enabled
DEBUG - 2011-05-03 12:53:32 --> URI Class Initialized
DEBUG - 2011-05-03 12:53:32 --> Router Class Initialized
ERROR - 2011-05-03 12:53:32 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-05-03 12:53:32 --> Config Class Initialized
DEBUG - 2011-05-03 12:53:32 --> Hooks Class Initialized
DEBUG - 2011-05-03 12:53:32 --> Utf8 Class Initialized
DEBUG - 2011-05-03 12:53:32 --> UTF-8 Support Enabled
DEBUG - 2011-05-03 12:53:32 --> URI Class Initialized
DEBUG - 2011-05-03 12:53:32 --> Router Class Initialized
ERROR - 2011-05-03 12:53:32 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-05-03 12:53:32 --> Config Class Initialized
DEBUG - 2011-05-03 12:53:32 --> Hooks Class Initialized
DEBUG - 2011-05-03 12:53:32 --> Utf8 Class Initialized
DEBUG - 2011-05-03 12:53:32 --> UTF-8 Support Enabled
DEBUG - 2011-05-03 12:53:32 --> URI Class Initialized
DEBUG - 2011-05-03 12:53:32 --> Router Class Initialized
ERROR - 2011-05-03 12:53:32 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-05-03 12:53:49 --> Config Class Initialized
DEBUG - 2011-05-03 12:53:49 --> Hooks Class Initialized
DEBUG - 2011-05-03 12:53:49 --> Utf8 Class Initialized
DEBUG - 2011-05-03 12:53:49 --> UTF-8 Support Enabled
DEBUG - 2011-05-03 12:53:49 --> URI Class Initialized
DEBUG - 2011-05-03 12:53:49 --> Router Class Initialized
DEBUG - 2011-05-03 12:53:49 --> Output Class Initialized
DEBUG - 2011-05-03 12:53:49 --> Input Class Initialized
DEBUG - 2011-05-03 12:53:49 --> Global POST and COOKIE data sanitized
DEBUG - 2011-05-03 12:53:49 --> Language Class Initialized
DEBUG - 2011-05-03 12:53:49 --> Loader Class Initialized
DEBUG - 2011-05-03 12:53:49 --> Controller Class Initialized
ERROR - 2011-05-03 12:53:49 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-05-03 12:53:49 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-05-03 12:53:49 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-05-03 12:53:49 --> Model Class Initialized
DEBUG - 2011-05-03 12:53:49 --> Model Class Initialized
DEBUG - 2011-05-03 12:53:49 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-05-03 12:53:49 --> Database Driver Class Initialized
DEBUG - 2011-05-03 12:53:49 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-05-03 12:53:49 --> Helper loaded: url_helper
DEBUG - 2011-05-03 12:53:49 --> File loaded: application/views/common/header.php
DEBUG - 2011-05-03 12:53:49 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-05-03 12:53:49 --> File loaded: application/views/common/footer.php
DEBUG - 2011-05-03 12:53:49 --> File loaded: application/views/layout/main.php
DEBUG - 2011-05-03 12:53:49 --> Final output sent to browser
DEBUG - 2011-05-03 12:53:49 --> Total execution time: 0.0339
DEBUG - 2011-05-03 12:53:50 --> Config Class Initialized
DEBUG - 2011-05-03 12:53:50 --> Hooks Class Initialized
DEBUG - 2011-05-03 12:53:50 --> Utf8 Class Initialized
DEBUG - 2011-05-03 12:53:50 --> UTF-8 Support Enabled
DEBUG - 2011-05-03 12:53:50 --> URI Class Initialized
DEBUG - 2011-05-03 12:53:50 --> Router Class Initialized
DEBUG - 2011-05-03 12:53:50 --> Output Class Initialized
DEBUG - 2011-05-03 12:53:50 --> Input Class Initialized
DEBUG - 2011-05-03 12:53:50 --> Global POST and COOKIE data sanitized
DEBUG - 2011-05-03 12:53:50 --> Language Class Initialized
DEBUG - 2011-05-03 12:53:50 --> Loader Class Initialized
DEBUG - 2011-05-03 12:53:50 --> Controller Class Initialized
DEBUG - 2011-05-03 12:53:50 --> Model Class Initialized
DEBUG - 2011-05-03 12:53:50 --> Model Class Initialized
DEBUG - 2011-05-03 12:53:50 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-05-03 12:53:50 --> Database Driver Class Initialized
DEBUG - 2011-05-03 12:53:51 --> Final output sent to browser
DEBUG - 2011-05-03 12:53:51 --> Total execution time: 0.7952
DEBUG - 2011-05-03 12:53:59 --> Config Class Initialized
DEBUG - 2011-05-03 12:53:59 --> Hooks Class Initialized
DEBUG - 2011-05-03 12:53:59 --> Utf8 Class Initialized
DEBUG - 2011-05-03 12:53:59 --> UTF-8 Support Enabled
DEBUG - 2011-05-03 12:53:59 --> URI Class Initialized
DEBUG - 2011-05-03 12:53:59 --> Router Class Initialized
DEBUG - 2011-05-03 12:53:59 --> Output Class Initialized
DEBUG - 2011-05-03 12:53:59 --> Input Class Initialized
DEBUG - 2011-05-03 12:53:59 --> Global POST and COOKIE data sanitized
DEBUG - 2011-05-03 12:53:59 --> Language Class Initialized
DEBUG - 2011-05-03 12:53:59 --> Loader Class Initialized
DEBUG - 2011-05-03 12:53:59 --> Controller Class Initialized
ERROR - 2011-05-03 12:53:59 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-05-03 12:53:59 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-05-03 12:53:59 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-05-03 12:53:59 --> Model Class Initialized
DEBUG - 2011-05-03 12:53:59 --> Model Class Initialized
DEBUG - 2011-05-03 12:53:59 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-05-03 12:53:59 --> Database Driver Class Initialized
DEBUG - 2011-05-03 12:53:59 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-05-03 12:53:59 --> Helper loaded: url_helper
DEBUG - 2011-05-03 12:53:59 --> File loaded: application/views/common/header.php
DEBUG - 2011-05-03 12:53:59 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-05-03 12:53:59 --> File loaded: application/views/common/footer.php
DEBUG - 2011-05-03 12:53:59 --> File loaded: application/views/layout/main.php
DEBUG - 2011-05-03 12:53:59 --> Final output sent to browser
DEBUG - 2011-05-03 12:53:59 --> Total execution time: 0.0300
DEBUG - 2011-05-03 12:54:00 --> Config Class Initialized
DEBUG - 2011-05-03 12:54:00 --> Hooks Class Initialized
DEBUG - 2011-05-03 12:54:00 --> Utf8 Class Initialized
DEBUG - 2011-05-03 12:54:00 --> UTF-8 Support Enabled
DEBUG - 2011-05-03 12:54:00 --> URI Class Initialized
DEBUG - 2011-05-03 12:54:00 --> Router Class Initialized
DEBUG - 2011-05-03 12:54:00 --> Output Class Initialized
DEBUG - 2011-05-03 12:54:00 --> Input Class Initialized
DEBUG - 2011-05-03 12:54:00 --> Global POST and COOKIE data sanitized
DEBUG - 2011-05-03 12:54:00 --> Language Class Initialized
DEBUG - 2011-05-03 12:54:00 --> Loader Class Initialized
DEBUG - 2011-05-03 12:54:00 --> Controller Class Initialized
DEBUG - 2011-05-03 12:54:00 --> Model Class Initialized
DEBUG - 2011-05-03 12:54:00 --> Model Class Initialized
DEBUG - 2011-05-03 12:54:00 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-05-03 12:54:00 --> Database Driver Class Initialized
DEBUG - 2011-05-03 12:54:01 --> Final output sent to browser
DEBUG - 2011-05-03 12:54:01 --> Total execution time: 0.5241
DEBUG - 2011-05-03 12:54:09 --> Config Class Initialized
DEBUG - 2011-05-03 12:54:09 --> Hooks Class Initialized
DEBUG - 2011-05-03 12:54:09 --> Utf8 Class Initialized
DEBUG - 2011-05-03 12:54:09 --> UTF-8 Support Enabled
DEBUG - 2011-05-03 12:54:09 --> URI Class Initialized
DEBUG - 2011-05-03 12:54:09 --> Router Class Initialized
DEBUG - 2011-05-03 12:54:09 --> Output Class Initialized
DEBUG - 2011-05-03 12:54:09 --> Input Class Initialized
DEBUG - 2011-05-03 12:54:09 --> Global POST and COOKIE data sanitized
DEBUG - 2011-05-03 12:54:09 --> Language Class Initialized
DEBUG - 2011-05-03 12:54:09 --> Loader Class Initialized
DEBUG - 2011-05-03 12:54:09 --> Controller Class Initialized
ERROR - 2011-05-03 12:54:09 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-05-03 12:54:09 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-05-03 12:54:09 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-05-03 12:54:09 --> Model Class Initialized
DEBUG - 2011-05-03 12:54:09 --> Model Class Initialized
DEBUG - 2011-05-03 12:54:09 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-05-03 12:54:10 --> Database Driver Class Initialized
DEBUG - 2011-05-03 12:54:10 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-05-03 12:54:10 --> Helper loaded: url_helper
DEBUG - 2011-05-03 12:54:10 --> File loaded: application/views/common/header.php
DEBUG - 2011-05-03 12:54:10 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-05-03 12:54:10 --> File loaded: application/views/common/footer.php
DEBUG - 2011-05-03 12:54:10 --> File loaded: application/views/layout/main.php
DEBUG - 2011-05-03 12:54:10 --> Final output sent to browser
DEBUG - 2011-05-03 12:54:10 --> Total execution time: 0.0805
DEBUG - 2011-05-03 12:54:10 --> Config Class Initialized
DEBUG - 2011-05-03 12:54:10 --> Hooks Class Initialized
DEBUG - 2011-05-03 12:54:10 --> Utf8 Class Initialized
DEBUG - 2011-05-03 12:54:10 --> UTF-8 Support Enabled
DEBUG - 2011-05-03 12:54:10 --> URI Class Initialized
DEBUG - 2011-05-03 12:54:10 --> Router Class Initialized
DEBUG - 2011-05-03 12:54:10 --> Output Class Initialized
DEBUG - 2011-05-03 12:54:10 --> Input Class Initialized
DEBUG - 2011-05-03 12:54:10 --> Global POST and COOKIE data sanitized
DEBUG - 2011-05-03 12:54:10 --> Language Class Initialized
DEBUG - 2011-05-03 12:54:10 --> Loader Class Initialized
DEBUG - 2011-05-03 12:54:10 --> Controller Class Initialized
DEBUG - 2011-05-03 12:54:10 --> Model Class Initialized
DEBUG - 2011-05-03 12:54:10 --> Model Class Initialized
DEBUG - 2011-05-03 12:54:10 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-05-03 12:54:10 --> Database Driver Class Initialized
DEBUG - 2011-05-03 12:54:11 --> Final output sent to browser
DEBUG - 2011-05-03 12:54:11 --> Total execution time: 0.7079
DEBUG - 2011-05-03 12:54:22 --> Config Class Initialized
DEBUG - 2011-05-03 12:54:22 --> Hooks Class Initialized
DEBUG - 2011-05-03 12:54:22 --> Utf8 Class Initialized
DEBUG - 2011-05-03 12:54:22 --> UTF-8 Support Enabled
DEBUG - 2011-05-03 12:54:22 --> URI Class Initialized
DEBUG - 2011-05-03 12:54:22 --> Router Class Initialized
DEBUG - 2011-05-03 12:54:22 --> Output Class Initialized
DEBUG - 2011-05-03 12:54:22 --> Input Class Initialized
DEBUG - 2011-05-03 12:54:22 --> Global POST and COOKIE data sanitized
DEBUG - 2011-05-03 12:54:22 --> Language Class Initialized
DEBUG - 2011-05-03 12:54:22 --> Loader Class Initialized
DEBUG - 2011-05-03 12:54:22 --> Controller Class Initialized
ERROR - 2011-05-03 12:54:22 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-05-03 12:54:22 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-05-03 12:54:22 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-05-03 12:54:22 --> Model Class Initialized
DEBUG - 2011-05-03 12:54:22 --> Model Class Initialized
DEBUG - 2011-05-03 12:54:22 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-05-03 12:54:22 --> Database Driver Class Initialized
DEBUG - 2011-05-03 12:54:22 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-05-03 12:54:22 --> Helper loaded: url_helper
DEBUG - 2011-05-03 12:54:22 --> File loaded: application/views/common/header.php
DEBUG - 2011-05-03 12:54:22 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-05-03 12:54:22 --> File loaded: application/views/common/footer.php
DEBUG - 2011-05-03 12:54:22 --> File loaded: application/views/layout/main.php
DEBUG - 2011-05-03 12:54:22 --> Final output sent to browser
DEBUG - 2011-05-03 12:54:22 --> Total execution time: 0.0629
DEBUG - 2011-05-03 12:54:23 --> Config Class Initialized
DEBUG - 2011-05-03 12:54:23 --> Hooks Class Initialized
DEBUG - 2011-05-03 12:54:23 --> Utf8 Class Initialized
DEBUG - 2011-05-03 12:54:23 --> UTF-8 Support Enabled
DEBUG - 2011-05-03 12:54:23 --> URI Class Initialized
DEBUG - 2011-05-03 12:54:23 --> Router Class Initialized
DEBUG - 2011-05-03 12:54:23 --> Output Class Initialized
DEBUG - 2011-05-03 12:54:23 --> Input Class Initialized
DEBUG - 2011-05-03 12:54:23 --> Global POST and COOKIE data sanitized
DEBUG - 2011-05-03 12:54:23 --> Language Class Initialized
DEBUG - 2011-05-03 12:54:23 --> Loader Class Initialized
DEBUG - 2011-05-03 12:54:23 --> Controller Class Initialized
DEBUG - 2011-05-03 12:54:23 --> Model Class Initialized
DEBUG - 2011-05-03 12:54:23 --> Model Class Initialized
DEBUG - 2011-05-03 12:54:23 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-05-03 12:54:23 --> Database Driver Class Initialized
DEBUG - 2011-05-03 12:54:24 --> Final output sent to browser
DEBUG - 2011-05-03 12:54:24 --> Total execution time: 1.0963
DEBUG - 2011-05-03 12:54:37 --> Config Class Initialized
DEBUG - 2011-05-03 12:54:37 --> Hooks Class Initialized
DEBUG - 2011-05-03 12:54:37 --> Utf8 Class Initialized
DEBUG - 2011-05-03 12:54:37 --> UTF-8 Support Enabled
DEBUG - 2011-05-03 12:54:37 --> URI Class Initialized
DEBUG - 2011-05-03 12:54:37 --> Router Class Initialized
DEBUG - 2011-05-03 12:54:37 --> Output Class Initialized
DEBUG - 2011-05-03 12:54:37 --> Input Class Initialized
DEBUG - 2011-05-03 12:54:37 --> Global POST and COOKIE data sanitized
DEBUG - 2011-05-03 12:54:37 --> Language Class Initialized
DEBUG - 2011-05-03 12:54:37 --> Loader Class Initialized
DEBUG - 2011-05-03 12:54:37 --> Controller Class Initialized
ERROR - 2011-05-03 12:54:37 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-05-03 12:54:37 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-05-03 12:54:37 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-05-03 12:54:37 --> Model Class Initialized
DEBUG - 2011-05-03 12:54:37 --> Model Class Initialized
DEBUG - 2011-05-03 12:54:37 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-05-03 12:54:37 --> Database Driver Class Initialized
DEBUG - 2011-05-03 12:54:37 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-05-03 12:54:37 --> Helper loaded: url_helper
DEBUG - 2011-05-03 12:54:37 --> File loaded: application/views/common/header.php
DEBUG - 2011-05-03 12:54:37 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-05-03 12:54:37 --> File loaded: application/views/common/footer.php
DEBUG - 2011-05-03 12:54:37 --> File loaded: application/views/layout/main.php
DEBUG - 2011-05-03 12:54:37 --> Final output sent to browser
DEBUG - 2011-05-03 12:54:37 --> Total execution time: 0.0646
DEBUG - 2011-05-03 12:54:38 --> Config Class Initialized
DEBUG - 2011-05-03 12:54:38 --> Hooks Class Initialized
DEBUG - 2011-05-03 12:54:38 --> Utf8 Class Initialized
DEBUG - 2011-05-03 12:54:38 --> UTF-8 Support Enabled
DEBUG - 2011-05-03 12:54:38 --> URI Class Initialized
DEBUG - 2011-05-03 12:54:38 --> Router Class Initialized
DEBUG - 2011-05-03 12:54:38 --> Output Class Initialized
DEBUG - 2011-05-03 12:54:38 --> Input Class Initialized
DEBUG - 2011-05-03 12:54:38 --> Global POST and COOKIE data sanitized
DEBUG - 2011-05-03 12:54:38 --> Language Class Initialized
DEBUG - 2011-05-03 12:54:38 --> Loader Class Initialized
DEBUG - 2011-05-03 12:54:38 --> Controller Class Initialized
DEBUG - 2011-05-03 12:54:38 --> Model Class Initialized
DEBUG - 2011-05-03 12:54:38 --> Model Class Initialized
DEBUG - 2011-05-03 12:54:38 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-05-03 12:54:39 --> Database Driver Class Initialized
DEBUG - 2011-05-03 12:54:40 --> Final output sent to browser
DEBUG - 2011-05-03 12:54:40 --> Total execution time: 1.4099
DEBUG - 2011-05-03 12:54:52 --> Config Class Initialized
DEBUG - 2011-05-03 12:54:52 --> Hooks Class Initialized
DEBUG - 2011-05-03 12:54:52 --> Utf8 Class Initialized
DEBUG - 2011-05-03 12:54:52 --> UTF-8 Support Enabled
DEBUG - 2011-05-03 12:54:52 --> URI Class Initialized
DEBUG - 2011-05-03 12:54:52 --> Router Class Initialized
DEBUG - 2011-05-03 12:54:52 --> Output Class Initialized
DEBUG - 2011-05-03 12:54:52 --> Input Class Initialized
DEBUG - 2011-05-03 12:54:52 --> Global POST and COOKIE data sanitized
DEBUG - 2011-05-03 12:54:52 --> Language Class Initialized
DEBUG - 2011-05-03 12:54:52 --> Loader Class Initialized
DEBUG - 2011-05-03 12:54:52 --> Controller Class Initialized
ERROR - 2011-05-03 12:54:52 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-05-03 12:54:52 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-05-03 12:54:52 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-05-03 12:54:52 --> Model Class Initialized
DEBUG - 2011-05-03 12:54:52 --> Model Class Initialized
DEBUG - 2011-05-03 12:54:52 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-05-03 12:54:52 --> Database Driver Class Initialized
DEBUG - 2011-05-03 12:54:52 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-05-03 12:54:52 --> Helper loaded: url_helper
DEBUG - 2011-05-03 12:54:52 --> File loaded: application/views/common/header.php
DEBUG - 2011-05-03 12:54:52 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-05-03 12:54:52 --> File loaded: application/views/common/footer.php
DEBUG - 2011-05-03 12:54:52 --> File loaded: application/views/layout/main.php
DEBUG - 2011-05-03 12:54:52 --> Final output sent to browser
DEBUG - 2011-05-03 12:54:52 --> Total execution time: 0.0328
DEBUG - 2011-05-03 12:54:53 --> Config Class Initialized
DEBUG - 2011-05-03 12:54:53 --> Hooks Class Initialized
DEBUG - 2011-05-03 12:54:53 --> Utf8 Class Initialized
DEBUG - 2011-05-03 12:54:53 --> UTF-8 Support Enabled
DEBUG - 2011-05-03 12:54:53 --> URI Class Initialized
DEBUG - 2011-05-03 12:54:53 --> Router Class Initialized
DEBUG - 2011-05-03 12:54:53 --> Output Class Initialized
DEBUG - 2011-05-03 12:54:53 --> Input Class Initialized
DEBUG - 2011-05-03 12:54:53 --> Global POST and COOKIE data sanitized
DEBUG - 2011-05-03 12:54:53 --> Language Class Initialized
DEBUG - 2011-05-03 12:54:53 --> Loader Class Initialized
DEBUG - 2011-05-03 12:54:53 --> Controller Class Initialized
DEBUG - 2011-05-03 12:54:53 --> Model Class Initialized
DEBUG - 2011-05-03 12:54:53 --> Model Class Initialized
DEBUG - 2011-05-03 12:54:53 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-05-03 12:54:53 --> Database Driver Class Initialized
DEBUG - 2011-05-03 12:54:54 --> Final output sent to browser
DEBUG - 2011-05-03 12:54:54 --> Total execution time: 0.6566
DEBUG - 2011-05-03 12:54:59 --> Config Class Initialized
DEBUG - 2011-05-03 12:54:59 --> Hooks Class Initialized
DEBUG - 2011-05-03 12:54:59 --> Utf8 Class Initialized
DEBUG - 2011-05-03 12:54:59 --> UTF-8 Support Enabled
DEBUG - 2011-05-03 12:54:59 --> URI Class Initialized
DEBUG - 2011-05-03 12:54:59 --> Router Class Initialized
DEBUG - 2011-05-03 12:54:59 --> Output Class Initialized
DEBUG - 2011-05-03 12:54:59 --> Input Class Initialized
DEBUG - 2011-05-03 12:54:59 --> Global POST and COOKIE data sanitized
DEBUG - 2011-05-03 12:54:59 --> Language Class Initialized
DEBUG - 2011-05-03 12:54:59 --> Loader Class Initialized
DEBUG - 2011-05-03 12:54:59 --> Controller Class Initialized
ERROR - 2011-05-03 12:54:59 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-05-03 12:54:59 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-05-03 12:54:59 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-05-03 12:54:59 --> Model Class Initialized
DEBUG - 2011-05-03 12:54:59 --> Model Class Initialized
DEBUG - 2011-05-03 12:54:59 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-05-03 12:54:59 --> Database Driver Class Initialized
DEBUG - 2011-05-03 12:54:59 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-05-03 12:54:59 --> Helper loaded: url_helper
DEBUG - 2011-05-03 12:54:59 --> File loaded: application/views/common/header.php
DEBUG - 2011-05-03 12:54:59 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-05-03 12:54:59 --> File loaded: application/views/common/footer.php
DEBUG - 2011-05-03 12:54:59 --> File loaded: application/views/layout/main.php
DEBUG - 2011-05-03 12:54:59 --> Final output sent to browser
DEBUG - 2011-05-03 12:54:59 --> Total execution time: 0.0312
DEBUG - 2011-05-03 12:55:00 --> Config Class Initialized
DEBUG - 2011-05-03 12:55:00 --> Hooks Class Initialized
DEBUG - 2011-05-03 12:55:00 --> Utf8 Class Initialized
DEBUG - 2011-05-03 12:55:00 --> UTF-8 Support Enabled
DEBUG - 2011-05-03 12:55:00 --> URI Class Initialized
DEBUG - 2011-05-03 12:55:00 --> Router Class Initialized
DEBUG - 2011-05-03 12:55:00 --> Output Class Initialized
DEBUG - 2011-05-03 12:55:00 --> Input Class Initialized
DEBUG - 2011-05-03 12:55:00 --> Global POST and COOKIE data sanitized
DEBUG - 2011-05-03 12:55:00 --> Language Class Initialized
DEBUG - 2011-05-03 12:55:00 --> Loader Class Initialized
DEBUG - 2011-05-03 12:55:00 --> Controller Class Initialized
DEBUG - 2011-05-03 12:55:00 --> Model Class Initialized
DEBUG - 2011-05-03 12:55:00 --> Model Class Initialized
DEBUG - 2011-05-03 12:55:00 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-05-03 12:55:00 --> Database Driver Class Initialized
DEBUG - 2011-05-03 12:55:01 --> Final output sent to browser
DEBUG - 2011-05-03 12:55:01 --> Total execution time: 0.5154
DEBUG - 2011-05-03 12:55:07 --> Config Class Initialized
DEBUG - 2011-05-03 12:55:07 --> Hooks Class Initialized
DEBUG - 2011-05-03 12:55:07 --> Utf8 Class Initialized
DEBUG - 2011-05-03 12:55:07 --> UTF-8 Support Enabled
DEBUG - 2011-05-03 12:55:07 --> URI Class Initialized
DEBUG - 2011-05-03 12:55:07 --> Router Class Initialized
DEBUG - 2011-05-03 12:55:07 --> Output Class Initialized
DEBUG - 2011-05-03 12:55:07 --> Input Class Initialized
DEBUG - 2011-05-03 12:55:07 --> Global POST and COOKIE data sanitized
DEBUG - 2011-05-03 12:55:07 --> Language Class Initialized
DEBUG - 2011-05-03 12:55:07 --> Loader Class Initialized
DEBUG - 2011-05-03 12:55:07 --> Controller Class Initialized
ERROR - 2011-05-03 12:55:07 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-05-03 12:55:07 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-05-03 12:55:07 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-05-03 12:55:07 --> Model Class Initialized
DEBUG - 2011-05-03 12:55:07 --> Model Class Initialized
DEBUG - 2011-05-03 12:55:07 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-05-03 12:55:07 --> Database Driver Class Initialized
DEBUG - 2011-05-03 12:55:07 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-05-03 12:55:07 --> Helper loaded: url_helper
DEBUG - 2011-05-03 12:55:07 --> File loaded: application/views/common/header.php
DEBUG - 2011-05-03 12:55:07 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-05-03 12:55:07 --> File loaded: application/views/common/footer.php
DEBUG - 2011-05-03 12:55:07 --> File loaded: application/views/layout/main.php
DEBUG - 2011-05-03 12:55:07 --> Final output sent to browser
DEBUG - 2011-05-03 12:55:07 --> Total execution time: 0.0432
DEBUG - 2011-05-03 12:55:08 --> Config Class Initialized
DEBUG - 2011-05-03 12:55:08 --> Hooks Class Initialized
DEBUG - 2011-05-03 12:55:08 --> Utf8 Class Initialized
DEBUG - 2011-05-03 12:55:08 --> UTF-8 Support Enabled
DEBUG - 2011-05-03 12:55:08 --> URI Class Initialized
DEBUG - 2011-05-03 12:55:08 --> Router Class Initialized
DEBUG - 2011-05-03 12:55:08 --> Output Class Initialized
DEBUG - 2011-05-03 12:55:08 --> Input Class Initialized
DEBUG - 2011-05-03 12:55:08 --> Global POST and COOKIE data sanitized
DEBUG - 2011-05-03 12:55:08 --> Language Class Initialized
DEBUG - 2011-05-03 12:55:08 --> Loader Class Initialized
DEBUG - 2011-05-03 12:55:08 --> Controller Class Initialized
DEBUG - 2011-05-03 12:55:08 --> Model Class Initialized
DEBUG - 2011-05-03 12:55:08 --> Model Class Initialized
DEBUG - 2011-05-03 12:55:08 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-05-03 12:55:08 --> Database Driver Class Initialized
DEBUG - 2011-05-03 12:55:08 --> Final output sent to browser
DEBUG - 2011-05-03 12:55:08 --> Total execution time: 0.5550
DEBUG - 2011-05-03 13:11:40 --> Config Class Initialized
DEBUG - 2011-05-03 13:11:40 --> Hooks Class Initialized
DEBUG - 2011-05-03 13:11:40 --> Utf8 Class Initialized
DEBUG - 2011-05-03 13:11:40 --> UTF-8 Support Enabled
DEBUG - 2011-05-03 13:11:40 --> URI Class Initialized
DEBUG - 2011-05-03 13:11:40 --> Router Class Initialized
DEBUG - 2011-05-03 13:11:40 --> Output Class Initialized
DEBUG - 2011-05-03 13:11:40 --> Input Class Initialized
DEBUG - 2011-05-03 13:11:40 --> Global POST and COOKIE data sanitized
DEBUG - 2011-05-03 13:11:40 --> Language Class Initialized
DEBUG - 2011-05-03 13:11:40 --> Loader Class Initialized
DEBUG - 2011-05-03 13:11:40 --> Controller Class Initialized
ERROR - 2011-05-03 13:11:40 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-05-03 13:11:40 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-05-03 13:11:40 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-05-03 13:11:40 --> Model Class Initialized
DEBUG - 2011-05-03 13:11:40 --> Model Class Initialized
DEBUG - 2011-05-03 13:11:40 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-05-03 13:11:40 --> Database Driver Class Initialized
DEBUG - 2011-05-03 13:11:40 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-05-03 13:11:40 --> Helper loaded: url_helper
DEBUG - 2011-05-03 13:11:40 --> File loaded: application/views/common/header.php
DEBUG - 2011-05-03 13:11:40 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-05-03 13:11:40 --> File loaded: application/views/common/footer.php
DEBUG - 2011-05-03 13:11:40 --> File loaded: application/views/layout/main.php
DEBUG - 2011-05-03 13:11:40 --> Final output sent to browser
DEBUG - 2011-05-03 13:11:40 --> Total execution time: 0.2568
DEBUG - 2011-05-03 13:11:45 --> Config Class Initialized
DEBUG - 2011-05-03 13:11:45 --> Hooks Class Initialized
DEBUG - 2011-05-03 13:11:45 --> Utf8 Class Initialized
DEBUG - 2011-05-03 13:11:45 --> UTF-8 Support Enabled
DEBUG - 2011-05-03 13:11:45 --> URI Class Initialized
DEBUG - 2011-05-03 13:11:45 --> Router Class Initialized
DEBUG - 2011-05-03 13:11:45 --> Output Class Initialized
DEBUG - 2011-05-03 13:11:45 --> Input Class Initialized
DEBUG - 2011-05-03 13:11:45 --> Global POST and COOKIE data sanitized
DEBUG - 2011-05-03 13:11:45 --> Language Class Initialized
DEBUG - 2011-05-03 13:11:45 --> Loader Class Initialized
DEBUG - 2011-05-03 13:11:45 --> Controller Class Initialized
DEBUG - 2011-05-03 13:11:45 --> Model Class Initialized
DEBUG - 2011-05-03 13:11:45 --> Model Class Initialized
DEBUG - 2011-05-03 13:11:45 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-05-03 13:11:45 --> Database Driver Class Initialized
DEBUG - 2011-05-03 13:11:46 --> Final output sent to browser
DEBUG - 2011-05-03 13:11:46 --> Total execution time: 0.8400
DEBUG - 2011-05-03 13:11:49 --> Config Class Initialized
DEBUG - 2011-05-03 13:11:49 --> Hooks Class Initialized
DEBUG - 2011-05-03 13:11:49 --> Utf8 Class Initialized
DEBUG - 2011-05-03 13:11:49 --> UTF-8 Support Enabled
DEBUG - 2011-05-03 13:11:49 --> URI Class Initialized
DEBUG - 2011-05-03 13:11:49 --> Router Class Initialized
ERROR - 2011-05-03 13:11:49 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-05-03 13:32:59 --> Config Class Initialized
DEBUG - 2011-05-03 13:32:59 --> Hooks Class Initialized
DEBUG - 2011-05-03 13:32:59 --> Utf8 Class Initialized
DEBUG - 2011-05-03 13:32:59 --> UTF-8 Support Enabled
DEBUG - 2011-05-03 13:32:59 --> URI Class Initialized
DEBUG - 2011-05-03 13:32:59 --> Router Class Initialized
DEBUG - 2011-05-03 13:32:59 --> Output Class Initialized
DEBUG - 2011-05-03 13:32:59 --> Input Class Initialized
DEBUG - 2011-05-03 13:32:59 --> Global POST and COOKIE data sanitized
DEBUG - 2011-05-03 13:32:59 --> Language Class Initialized
DEBUG - 2011-05-03 13:32:59 --> Loader Class Initialized
DEBUG - 2011-05-03 13:32:59 --> Controller Class Initialized
ERROR - 2011-05-03 13:32:59 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-05-03 13:32:59 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-05-03 13:32:59 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-05-03 13:32:59 --> Model Class Initialized
DEBUG - 2011-05-03 13:32:59 --> Model Class Initialized
DEBUG - 2011-05-03 13:32:59 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-05-03 13:32:59 --> Database Driver Class Initialized
DEBUG - 2011-05-03 13:32:59 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-05-03 13:32:59 --> Helper loaded: url_helper
DEBUG - 2011-05-03 13:32:59 --> File loaded: application/views/common/header.php
DEBUG - 2011-05-03 13:32:59 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-05-03 13:32:59 --> File loaded: application/views/common/footer.php
DEBUG - 2011-05-03 13:32:59 --> File loaded: application/views/layout/main.php
DEBUG - 2011-05-03 13:32:59 --> Final output sent to browser
DEBUG - 2011-05-03 13:32:59 --> Total execution time: 0.3086
DEBUG - 2011-05-03 13:33:00 --> Config Class Initialized
DEBUG - 2011-05-03 13:33:00 --> Hooks Class Initialized
DEBUG - 2011-05-03 13:33:00 --> Utf8 Class Initialized
DEBUG - 2011-05-03 13:33:00 --> UTF-8 Support Enabled
DEBUG - 2011-05-03 13:33:00 --> URI Class Initialized
DEBUG - 2011-05-03 13:33:00 --> Router Class Initialized
DEBUG - 2011-05-03 13:33:00 --> Output Class Initialized
DEBUG - 2011-05-03 13:33:00 --> Input Class Initialized
DEBUG - 2011-05-03 13:33:00 --> Global POST and COOKIE data sanitized
DEBUG - 2011-05-03 13:33:00 --> Language Class Initialized
DEBUG - 2011-05-03 13:33:00 --> Loader Class Initialized
DEBUG - 2011-05-03 13:33:00 --> Controller Class Initialized
DEBUG - 2011-05-03 13:33:00 --> Model Class Initialized
DEBUG - 2011-05-03 13:33:00 --> Model Class Initialized
DEBUG - 2011-05-03 13:33:00 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-05-03 13:33:00 --> Database Driver Class Initialized
DEBUG - 2011-05-03 13:33:01 --> Final output sent to browser
DEBUG - 2011-05-03 13:33:01 --> Total execution time: 0.6861
DEBUG - 2011-05-03 13:33:02 --> Config Class Initialized
DEBUG - 2011-05-03 13:33:02 --> Hooks Class Initialized
DEBUG - 2011-05-03 13:33:02 --> Utf8 Class Initialized
DEBUG - 2011-05-03 13:33:02 --> UTF-8 Support Enabled
DEBUG - 2011-05-03 13:33:02 --> URI Class Initialized
DEBUG - 2011-05-03 13:33:02 --> Router Class Initialized
ERROR - 2011-05-03 13:33:02 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-05-03 13:33:32 --> Config Class Initialized
DEBUG - 2011-05-03 13:33:32 --> Hooks Class Initialized
DEBUG - 2011-05-03 13:33:32 --> Utf8 Class Initialized
DEBUG - 2011-05-03 13:33:32 --> UTF-8 Support Enabled
DEBUG - 2011-05-03 13:33:32 --> URI Class Initialized
DEBUG - 2011-05-03 13:33:32 --> Router Class Initialized
DEBUG - 2011-05-03 13:33:32 --> Output Class Initialized
DEBUG - 2011-05-03 13:33:32 --> Input Class Initialized
DEBUG - 2011-05-03 13:33:32 --> Global POST and COOKIE data sanitized
DEBUG - 2011-05-03 13:33:32 --> Language Class Initialized
DEBUG - 2011-05-03 13:33:32 --> Loader Class Initialized
DEBUG - 2011-05-03 13:33:32 --> Controller Class Initialized
ERROR - 2011-05-03 13:33:32 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-05-03 13:33:32 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-05-03 13:33:32 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-05-03 13:33:32 --> Model Class Initialized
DEBUG - 2011-05-03 13:33:32 --> Model Class Initialized
DEBUG - 2011-05-03 13:33:32 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-05-03 13:33:32 --> Database Driver Class Initialized
DEBUG - 2011-05-03 13:33:32 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-05-03 13:33:32 --> Helper loaded: url_helper
DEBUG - 2011-05-03 13:33:32 --> File loaded: application/views/common/header.php
DEBUG - 2011-05-03 13:33:32 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-05-03 13:33:32 --> File loaded: application/views/common/footer.php
DEBUG - 2011-05-03 13:33:32 --> File loaded: application/views/layout/main.php
DEBUG - 2011-05-03 13:33:32 --> Final output sent to browser
DEBUG - 2011-05-03 13:33:32 --> Total execution time: 0.0307
DEBUG - 2011-05-03 13:33:33 --> Config Class Initialized
DEBUG - 2011-05-03 13:33:33 --> Hooks Class Initialized
DEBUG - 2011-05-03 13:33:33 --> Utf8 Class Initialized
DEBUG - 2011-05-03 13:33:33 --> UTF-8 Support Enabled
DEBUG - 2011-05-03 13:33:33 --> URI Class Initialized
DEBUG - 2011-05-03 13:33:33 --> Router Class Initialized
DEBUG - 2011-05-03 13:33:33 --> Output Class Initialized
DEBUG - 2011-05-03 13:33:33 --> Input Class Initialized
DEBUG - 2011-05-03 13:33:33 --> Global POST and COOKIE data sanitized
DEBUG - 2011-05-03 13:33:33 --> Language Class Initialized
DEBUG - 2011-05-03 13:33:33 --> Loader Class Initialized
DEBUG - 2011-05-03 13:33:33 --> Controller Class Initialized
DEBUG - 2011-05-03 13:33:33 --> Model Class Initialized
DEBUG - 2011-05-03 13:33:33 --> Model Class Initialized
DEBUG - 2011-05-03 13:33:33 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-05-03 13:33:33 --> Database Driver Class Initialized
DEBUG - 2011-05-03 13:33:33 --> Final output sent to browser
DEBUG - 2011-05-03 13:33:33 --> Total execution time: 0.6139
DEBUG - 2011-05-03 13:33:34 --> Config Class Initialized
DEBUG - 2011-05-03 13:33:34 --> Hooks Class Initialized
DEBUG - 2011-05-03 13:33:34 --> Utf8 Class Initialized
DEBUG - 2011-05-03 13:33:34 --> UTF-8 Support Enabled
DEBUG - 2011-05-03 13:33:34 --> URI Class Initialized
DEBUG - 2011-05-03 13:33:34 --> Router Class Initialized
ERROR - 2011-05-03 13:33:34 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-05-03 13:33:47 --> Config Class Initialized
DEBUG - 2011-05-03 13:33:47 --> Hooks Class Initialized
DEBUG - 2011-05-03 13:33:47 --> Utf8 Class Initialized
DEBUG - 2011-05-03 13:33:47 --> UTF-8 Support Enabled
DEBUG - 2011-05-03 13:33:47 --> URI Class Initialized
DEBUG - 2011-05-03 13:33:47 --> Router Class Initialized
DEBUG - 2011-05-03 13:33:47 --> Output Class Initialized
DEBUG - 2011-05-03 13:33:47 --> Input Class Initialized
DEBUG - 2011-05-03 13:33:47 --> Global POST and COOKIE data sanitized
DEBUG - 2011-05-03 13:33:47 --> Language Class Initialized
DEBUG - 2011-05-03 13:33:47 --> Loader Class Initialized
DEBUG - 2011-05-03 13:33:47 --> Controller Class Initialized
ERROR - 2011-05-03 13:33:47 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-05-03 13:33:47 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-05-03 13:33:47 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-05-03 13:33:47 --> Model Class Initialized
DEBUG - 2011-05-03 13:33:47 --> Model Class Initialized
DEBUG - 2011-05-03 13:33:47 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-05-03 13:33:47 --> Database Driver Class Initialized
DEBUG - 2011-05-03 13:33:47 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-05-03 13:33:47 --> Helper loaded: url_helper
DEBUG - 2011-05-03 13:33:47 --> File loaded: application/views/common/header.php
DEBUG - 2011-05-03 13:33:47 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-05-03 13:33:47 --> File loaded: application/views/common/footer.php
DEBUG - 2011-05-03 13:33:47 --> File loaded: application/views/layout/main.php
DEBUG - 2011-05-03 13:33:47 --> Final output sent to browser
DEBUG - 2011-05-03 13:33:47 --> Total execution time: 0.0323
DEBUG - 2011-05-03 13:33:48 --> Config Class Initialized
DEBUG - 2011-05-03 13:33:48 --> Hooks Class Initialized
DEBUG - 2011-05-03 13:33:48 --> Utf8 Class Initialized
DEBUG - 2011-05-03 13:33:48 --> UTF-8 Support Enabled
DEBUG - 2011-05-03 13:33:48 --> URI Class Initialized
DEBUG - 2011-05-03 13:33:48 --> Router Class Initialized
DEBUG - 2011-05-03 13:33:48 --> Output Class Initialized
DEBUG - 2011-05-03 13:33:48 --> Input Class Initialized
DEBUG - 2011-05-03 13:33:48 --> Global POST and COOKIE data sanitized
DEBUG - 2011-05-03 13:33:48 --> Language Class Initialized
DEBUG - 2011-05-03 13:33:48 --> Loader Class Initialized
DEBUG - 2011-05-03 13:33:48 --> Controller Class Initialized
DEBUG - 2011-05-03 13:33:48 --> Model Class Initialized
DEBUG - 2011-05-03 13:33:48 --> Model Class Initialized
DEBUG - 2011-05-03 13:33:48 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-05-03 13:33:48 --> Database Driver Class Initialized
DEBUG - 2011-05-03 13:33:49 --> Final output sent to browser
DEBUG - 2011-05-03 13:33:49 --> Total execution time: 0.5387
DEBUG - 2011-05-03 13:33:50 --> Config Class Initialized
DEBUG - 2011-05-03 13:33:50 --> Hooks Class Initialized
DEBUG - 2011-05-03 13:33:50 --> Utf8 Class Initialized
DEBUG - 2011-05-03 13:33:50 --> UTF-8 Support Enabled
DEBUG - 2011-05-03 13:33:50 --> URI Class Initialized
DEBUG - 2011-05-03 13:33:50 --> Router Class Initialized
ERROR - 2011-05-03 13:33:50 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-05-03 13:33:58 --> Config Class Initialized
DEBUG - 2011-05-03 13:33:58 --> Hooks Class Initialized
DEBUG - 2011-05-03 13:33:58 --> Utf8 Class Initialized
DEBUG - 2011-05-03 13:33:58 --> UTF-8 Support Enabled
DEBUG - 2011-05-03 13:33:58 --> URI Class Initialized
DEBUG - 2011-05-03 13:33:58 --> Router Class Initialized
DEBUG - 2011-05-03 13:33:58 --> Output Class Initialized
DEBUG - 2011-05-03 13:33:58 --> Input Class Initialized
DEBUG - 2011-05-03 13:33:58 --> Global POST and COOKIE data sanitized
DEBUG - 2011-05-03 13:33:58 --> Language Class Initialized
DEBUG - 2011-05-03 13:33:58 --> Loader Class Initialized
DEBUG - 2011-05-03 13:33:58 --> Controller Class Initialized
ERROR - 2011-05-03 13:33:58 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-05-03 13:33:58 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-05-03 13:33:58 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-05-03 13:33:58 --> Model Class Initialized
DEBUG - 2011-05-03 13:33:58 --> Model Class Initialized
DEBUG - 2011-05-03 13:33:58 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-05-03 13:33:59 --> Database Driver Class Initialized
DEBUG - 2011-05-03 13:33:59 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-05-03 13:33:59 --> Helper loaded: url_helper
DEBUG - 2011-05-03 13:33:59 --> File loaded: application/views/common/header.php
DEBUG - 2011-05-03 13:33:59 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-05-03 13:33:59 --> File loaded: application/views/common/footer.php
DEBUG - 2011-05-03 13:33:59 --> File loaded: application/views/layout/main.php
DEBUG - 2011-05-03 13:33:59 --> Final output sent to browser
DEBUG - 2011-05-03 13:33:59 --> Total execution time: 0.0308
DEBUG - 2011-05-03 13:33:59 --> Config Class Initialized
DEBUG - 2011-05-03 13:33:59 --> Hooks Class Initialized
DEBUG - 2011-05-03 13:33:59 --> Utf8 Class Initialized
DEBUG - 2011-05-03 13:33:59 --> UTF-8 Support Enabled
DEBUG - 2011-05-03 13:33:59 --> URI Class Initialized
DEBUG - 2011-05-03 13:33:59 --> Router Class Initialized
DEBUG - 2011-05-03 13:33:59 --> Output Class Initialized
DEBUG - 2011-05-03 13:33:59 --> Input Class Initialized
DEBUG - 2011-05-03 13:33:59 --> Global POST and COOKIE data sanitized
DEBUG - 2011-05-03 13:33:59 --> Language Class Initialized
DEBUG - 2011-05-03 13:33:59 --> Loader Class Initialized
DEBUG - 2011-05-03 13:33:59 --> Controller Class Initialized
DEBUG - 2011-05-03 13:33:59 --> Model Class Initialized
DEBUG - 2011-05-03 13:33:59 --> Model Class Initialized
DEBUG - 2011-05-03 13:33:59 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-05-03 13:33:59 --> Database Driver Class Initialized
DEBUG - 2011-05-03 13:34:00 --> Final output sent to browser
DEBUG - 2011-05-03 13:34:00 --> Total execution time: 0.5756
DEBUG - 2011-05-03 13:34:00 --> Config Class Initialized
DEBUG - 2011-05-03 13:34:00 --> Hooks Class Initialized
DEBUG - 2011-05-03 13:34:00 --> Utf8 Class Initialized
DEBUG - 2011-05-03 13:34:00 --> UTF-8 Support Enabled
DEBUG - 2011-05-03 13:34:00 --> URI Class Initialized
DEBUG - 2011-05-03 13:34:00 --> Router Class Initialized
ERROR - 2011-05-03 13:34:00 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-05-03 13:34:05 --> Config Class Initialized
DEBUG - 2011-05-03 13:34:05 --> Hooks Class Initialized
DEBUG - 2011-05-03 13:34:05 --> Utf8 Class Initialized
DEBUG - 2011-05-03 13:34:05 --> UTF-8 Support Enabled
DEBUG - 2011-05-03 13:34:05 --> URI Class Initialized
DEBUG - 2011-05-03 13:34:05 --> Router Class Initialized
DEBUG - 2011-05-03 13:34:05 --> Output Class Initialized
DEBUG - 2011-05-03 13:34:05 --> Input Class Initialized
DEBUG - 2011-05-03 13:34:05 --> Global POST and COOKIE data sanitized
DEBUG - 2011-05-03 13:34:05 --> Language Class Initialized
DEBUG - 2011-05-03 13:34:05 --> Loader Class Initialized
DEBUG - 2011-05-03 13:34:05 --> Controller Class Initialized
ERROR - 2011-05-03 13:34:05 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-05-03 13:34:05 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-05-03 13:34:05 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-05-03 13:34:05 --> Model Class Initialized
DEBUG - 2011-05-03 13:34:05 --> Model Class Initialized
DEBUG - 2011-05-03 13:34:05 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-05-03 13:34:05 --> Database Driver Class Initialized
DEBUG - 2011-05-03 13:34:05 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-05-03 13:34:05 --> Helper loaded: url_helper
DEBUG - 2011-05-03 13:34:05 --> File loaded: application/views/common/header.php
DEBUG - 2011-05-03 13:34:05 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-05-03 13:34:05 --> File loaded: application/views/common/footer.php
DEBUG - 2011-05-03 13:34:05 --> File loaded: application/views/layout/main.php
DEBUG - 2011-05-03 13:34:05 --> Final output sent to browser
DEBUG - 2011-05-03 13:34:05 --> Total execution time: 0.0298
DEBUG - 2011-05-03 13:34:06 --> Config Class Initialized
DEBUG - 2011-05-03 13:34:06 --> Hooks Class Initialized
DEBUG - 2011-05-03 13:34:06 --> Utf8 Class Initialized
DEBUG - 2011-05-03 13:34:06 --> UTF-8 Support Enabled
DEBUG - 2011-05-03 13:34:06 --> URI Class Initialized
DEBUG - 2011-05-03 13:34:06 --> Router Class Initialized
DEBUG - 2011-05-03 13:34:06 --> Output Class Initialized
DEBUG - 2011-05-03 13:34:06 --> Input Class Initialized
DEBUG - 2011-05-03 13:34:06 --> Global POST and COOKIE data sanitized
DEBUG - 2011-05-03 13:34:06 --> Language Class Initialized
DEBUG - 2011-05-03 13:34:06 --> Loader Class Initialized
DEBUG - 2011-05-03 13:34:06 --> Controller Class Initialized
DEBUG - 2011-05-03 13:34:06 --> Model Class Initialized
DEBUG - 2011-05-03 13:34:06 --> Model Class Initialized
DEBUG - 2011-05-03 13:34:06 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-05-03 13:34:06 --> Database Driver Class Initialized
DEBUG - 2011-05-03 13:34:07 --> Final output sent to browser
DEBUG - 2011-05-03 13:34:07 --> Total execution time: 0.5690
DEBUG - 2011-05-03 13:34:08 --> Config Class Initialized
DEBUG - 2011-05-03 13:34:08 --> Hooks Class Initialized
DEBUG - 2011-05-03 13:34:08 --> Utf8 Class Initialized
DEBUG - 2011-05-03 13:34:08 --> UTF-8 Support Enabled
DEBUG - 2011-05-03 13:34:08 --> URI Class Initialized
DEBUG - 2011-05-03 13:34:08 --> Router Class Initialized
ERROR - 2011-05-03 13:34:08 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-05-03 13:34:15 --> Config Class Initialized
DEBUG - 2011-05-03 13:34:15 --> Hooks Class Initialized
DEBUG - 2011-05-03 13:34:15 --> Utf8 Class Initialized
DEBUG - 2011-05-03 13:34:15 --> UTF-8 Support Enabled
DEBUG - 2011-05-03 13:34:15 --> URI Class Initialized
DEBUG - 2011-05-03 13:34:15 --> Router Class Initialized
DEBUG - 2011-05-03 13:34:15 --> Output Class Initialized
DEBUG - 2011-05-03 13:34:15 --> Input Class Initialized
DEBUG - 2011-05-03 13:34:15 --> Global POST and COOKIE data sanitized
DEBUG - 2011-05-03 13:34:15 --> Language Class Initialized
DEBUG - 2011-05-03 13:34:15 --> Loader Class Initialized
DEBUG - 2011-05-03 13:34:15 --> Controller Class Initialized
ERROR - 2011-05-03 13:34:15 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-05-03 13:34:15 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-05-03 13:34:15 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-05-03 13:34:15 --> Model Class Initialized
DEBUG - 2011-05-03 13:34:15 --> Model Class Initialized
DEBUG - 2011-05-03 13:34:15 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-05-03 13:34:15 --> Database Driver Class Initialized
DEBUG - 2011-05-03 13:34:15 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-05-03 13:34:15 --> Helper loaded: url_helper
DEBUG - 2011-05-03 13:34:15 --> File loaded: application/views/common/header.php
DEBUG - 2011-05-03 13:34:15 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-05-03 13:34:15 --> File loaded: application/views/common/footer.php
DEBUG - 2011-05-03 13:34:15 --> File loaded: application/views/layout/main.php
DEBUG - 2011-05-03 13:34:15 --> Final output sent to browser
DEBUG - 2011-05-03 13:34:15 --> Total execution time: 0.0311
DEBUG - 2011-05-03 13:34:15 --> Config Class Initialized
DEBUG - 2011-05-03 13:34:15 --> Hooks Class Initialized
DEBUG - 2011-05-03 13:34:15 --> Utf8 Class Initialized
DEBUG - 2011-05-03 13:34:15 --> UTF-8 Support Enabled
DEBUG - 2011-05-03 13:34:15 --> URI Class Initialized
DEBUG - 2011-05-03 13:34:15 --> Router Class Initialized
DEBUG - 2011-05-03 13:34:15 --> Output Class Initialized
DEBUG - 2011-05-03 13:34:15 --> Input Class Initialized
DEBUG - 2011-05-03 13:34:15 --> Global POST and COOKIE data sanitized
DEBUG - 2011-05-03 13:34:15 --> Language Class Initialized
DEBUG - 2011-05-03 13:34:15 --> Loader Class Initialized
DEBUG - 2011-05-03 13:34:15 --> Controller Class Initialized
DEBUG - 2011-05-03 13:34:15 --> Model Class Initialized
DEBUG - 2011-05-03 13:34:15 --> Model Class Initialized
DEBUG - 2011-05-03 13:34:15 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-05-03 13:34:15 --> Database Driver Class Initialized
DEBUG - 2011-05-03 13:34:16 --> Final output sent to browser
DEBUG - 2011-05-03 13:34:16 --> Total execution time: 0.5968
DEBUG - 2011-05-03 13:34:19 --> Config Class Initialized
DEBUG - 2011-05-03 13:34:19 --> Hooks Class Initialized
DEBUG - 2011-05-03 13:34:19 --> Utf8 Class Initialized
DEBUG - 2011-05-03 13:34:19 --> UTF-8 Support Enabled
DEBUG - 2011-05-03 13:34:19 --> URI Class Initialized
DEBUG - 2011-05-03 13:34:19 --> Router Class Initialized
ERROR - 2011-05-03 13:34:19 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-05-03 13:34:27 --> Config Class Initialized
DEBUG - 2011-05-03 13:34:27 --> Hooks Class Initialized
DEBUG - 2011-05-03 13:34:27 --> Utf8 Class Initialized
DEBUG - 2011-05-03 13:34:27 --> UTF-8 Support Enabled
DEBUG - 2011-05-03 13:34:27 --> URI Class Initialized
DEBUG - 2011-05-03 13:34:27 --> Router Class Initialized
DEBUG - 2011-05-03 13:34:27 --> Output Class Initialized
DEBUG - 2011-05-03 13:34:27 --> Input Class Initialized
DEBUG - 2011-05-03 13:34:27 --> Global POST and COOKIE data sanitized
DEBUG - 2011-05-03 13:34:27 --> Language Class Initialized
DEBUG - 2011-05-03 13:34:27 --> Loader Class Initialized
DEBUG - 2011-05-03 13:34:27 --> Controller Class Initialized
ERROR - 2011-05-03 13:34:27 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-05-03 13:34:27 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-05-03 13:34:27 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-05-03 13:34:27 --> Model Class Initialized
DEBUG - 2011-05-03 13:34:27 --> Model Class Initialized
DEBUG - 2011-05-03 13:34:27 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-05-03 13:34:27 --> Database Driver Class Initialized
DEBUG - 2011-05-03 13:34:27 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-05-03 13:34:27 --> Helper loaded: url_helper
DEBUG - 2011-05-03 13:34:27 --> File loaded: application/views/common/header.php
DEBUG - 2011-05-03 13:34:27 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-05-03 13:34:27 --> File loaded: application/views/common/footer.php
DEBUG - 2011-05-03 13:34:27 --> File loaded: application/views/layout/main.php
DEBUG - 2011-05-03 13:34:27 --> Final output sent to browser
DEBUG - 2011-05-03 13:34:27 --> Total execution time: 0.0321
DEBUG - 2011-05-03 13:34:28 --> Config Class Initialized
DEBUG - 2011-05-03 13:34:28 --> Hooks Class Initialized
DEBUG - 2011-05-03 13:34:28 --> Utf8 Class Initialized
DEBUG - 2011-05-03 13:34:28 --> UTF-8 Support Enabled
DEBUG - 2011-05-03 13:34:28 --> URI Class Initialized
DEBUG - 2011-05-03 13:34:28 --> Router Class Initialized
DEBUG - 2011-05-03 13:34:28 --> Output Class Initialized
DEBUG - 2011-05-03 13:34:28 --> Input Class Initialized
DEBUG - 2011-05-03 13:34:28 --> Global POST and COOKIE data sanitized
DEBUG - 2011-05-03 13:34:28 --> Language Class Initialized
DEBUG - 2011-05-03 13:34:28 --> Loader Class Initialized
DEBUG - 2011-05-03 13:34:28 --> Controller Class Initialized
DEBUG - 2011-05-03 13:34:28 --> Model Class Initialized
DEBUG - 2011-05-03 13:34:28 --> Model Class Initialized
DEBUG - 2011-05-03 13:34:28 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-05-03 13:34:28 --> Database Driver Class Initialized
DEBUG - 2011-05-03 13:34:29 --> Final output sent to browser
DEBUG - 2011-05-03 13:34:29 --> Total execution time: 0.5428
DEBUG - 2011-05-03 13:34:30 --> Config Class Initialized
DEBUG - 2011-05-03 13:34:30 --> Hooks Class Initialized
DEBUG - 2011-05-03 13:34:30 --> Utf8 Class Initialized
DEBUG - 2011-05-03 13:34:30 --> UTF-8 Support Enabled
DEBUG - 2011-05-03 13:34:30 --> URI Class Initialized
DEBUG - 2011-05-03 13:34:30 --> Router Class Initialized
ERROR - 2011-05-03 13:34:30 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-05-03 13:34:35 --> Config Class Initialized
DEBUG - 2011-05-03 13:34:35 --> Hooks Class Initialized
DEBUG - 2011-05-03 13:34:35 --> Utf8 Class Initialized
DEBUG - 2011-05-03 13:34:35 --> UTF-8 Support Enabled
DEBUG - 2011-05-03 13:34:35 --> URI Class Initialized
DEBUG - 2011-05-03 13:34:35 --> Router Class Initialized
DEBUG - 2011-05-03 13:34:35 --> Output Class Initialized
DEBUG - 2011-05-03 13:34:35 --> Input Class Initialized
DEBUG - 2011-05-03 13:34:35 --> Global POST and COOKIE data sanitized
DEBUG - 2011-05-03 13:34:35 --> Language Class Initialized
DEBUG - 2011-05-03 13:34:35 --> Loader Class Initialized
DEBUG - 2011-05-03 13:34:35 --> Controller Class Initialized
ERROR - 2011-05-03 13:34:35 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-05-03 13:34:35 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-05-03 13:34:35 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-05-03 13:34:35 --> Model Class Initialized
DEBUG - 2011-05-03 13:34:35 --> Model Class Initialized
DEBUG - 2011-05-03 13:34:35 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-05-03 13:34:35 --> Database Driver Class Initialized
DEBUG - 2011-05-03 13:34:35 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-05-03 13:34:35 --> Helper loaded: url_helper
DEBUG - 2011-05-03 13:34:35 --> File loaded: application/views/common/header.php
DEBUG - 2011-05-03 13:34:35 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-05-03 13:34:35 --> File loaded: application/views/common/footer.php
DEBUG - 2011-05-03 13:34:35 --> File loaded: application/views/layout/main.php
DEBUG - 2011-05-03 13:34:35 --> Final output sent to browser
DEBUG - 2011-05-03 13:34:35 --> Total execution time: 0.0299
DEBUG - 2011-05-03 13:34:35 --> Config Class Initialized
DEBUG - 2011-05-03 13:34:35 --> Hooks Class Initialized
DEBUG - 2011-05-03 13:34:35 --> Utf8 Class Initialized
DEBUG - 2011-05-03 13:34:35 --> UTF-8 Support Enabled
DEBUG - 2011-05-03 13:34:35 --> URI Class Initialized
DEBUG - 2011-05-03 13:34:35 --> Router Class Initialized
DEBUG - 2011-05-03 13:34:35 --> Output Class Initialized
DEBUG - 2011-05-03 13:34:35 --> Input Class Initialized
DEBUG - 2011-05-03 13:34:35 --> Global POST and COOKIE data sanitized
DEBUG - 2011-05-03 13:34:35 --> Language Class Initialized
DEBUG - 2011-05-03 13:34:35 --> Loader Class Initialized
DEBUG - 2011-05-03 13:34:35 --> Controller Class Initialized
DEBUG - 2011-05-03 13:34:35 --> Model Class Initialized
DEBUG - 2011-05-03 13:34:35 --> Model Class Initialized
DEBUG - 2011-05-03 13:34:35 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-05-03 13:34:35 --> Database Driver Class Initialized
DEBUG - 2011-05-03 13:34:36 --> Final output sent to browser
DEBUG - 2011-05-03 13:34:36 --> Total execution time: 0.6111
DEBUG - 2011-05-03 13:34:37 --> Config Class Initialized
DEBUG - 2011-05-03 13:34:37 --> Hooks Class Initialized
DEBUG - 2011-05-03 13:34:37 --> Utf8 Class Initialized
DEBUG - 2011-05-03 13:34:37 --> UTF-8 Support Enabled
DEBUG - 2011-05-03 13:34:37 --> URI Class Initialized
DEBUG - 2011-05-03 13:34:37 --> Router Class Initialized
ERROR - 2011-05-03 13:34:37 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-05-03 13:40:56 --> Config Class Initialized
DEBUG - 2011-05-03 13:40:56 --> Hooks Class Initialized
DEBUG - 2011-05-03 13:40:56 --> Utf8 Class Initialized
DEBUG - 2011-05-03 13:40:56 --> UTF-8 Support Enabled
DEBUG - 2011-05-03 13:40:56 --> URI Class Initialized
DEBUG - 2011-05-03 13:40:56 --> Router Class Initialized
DEBUG - 2011-05-03 13:40:56 --> No URI present. Default controller set.
DEBUG - 2011-05-03 13:40:56 --> Output Class Initialized
DEBUG - 2011-05-03 13:40:56 --> Input Class Initialized
DEBUG - 2011-05-03 13:40:56 --> Global POST and COOKIE data sanitized
DEBUG - 2011-05-03 13:40:56 --> Language Class Initialized
DEBUG - 2011-05-03 13:40:56 --> Loader Class Initialized
DEBUG - 2011-05-03 13:40:56 --> Controller Class Initialized
DEBUG - 2011-05-03 13:40:56 --> File loaded: application/views/splash/main.php
DEBUG - 2011-05-03 13:40:56 --> Helper loaded: url_helper
DEBUG - 2011-05-03 13:40:56 --> File loaded: application/views/common/header.php
DEBUG - 2011-05-03 13:40:56 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-05-03 13:40:56 --> File loaded: application/views/common/footer.php
DEBUG - 2011-05-03 13:40:56 --> File loaded: application/views/layout/main.php
DEBUG - 2011-05-03 13:40:56 --> Final output sent to browser
DEBUG - 2011-05-03 13:40:56 --> Total execution time: 0.0801
DEBUG - 2011-05-03 13:46:33 --> Config Class Initialized
DEBUG - 2011-05-03 13:46:33 --> Hooks Class Initialized
DEBUG - 2011-05-03 13:46:33 --> Utf8 Class Initialized
DEBUG - 2011-05-03 13:46:33 --> UTF-8 Support Enabled
DEBUG - 2011-05-03 13:46:33 --> URI Class Initialized
DEBUG - 2011-05-03 13:46:33 --> Router Class Initialized
DEBUG - 2011-05-03 13:46:33 --> No URI present. Default controller set.
DEBUG - 2011-05-03 13:46:33 --> Output Class Initialized
DEBUG - 2011-05-03 13:46:33 --> Input Class Initialized
DEBUG - 2011-05-03 13:46:33 --> Global POST and COOKIE data sanitized
DEBUG - 2011-05-03 13:46:33 --> Language Class Initialized
DEBUG - 2011-05-03 13:46:33 --> Loader Class Initialized
DEBUG - 2011-05-03 13:46:33 --> Controller Class Initialized
DEBUG - 2011-05-03 13:46:33 --> File loaded: application/views/splash/main.php
DEBUG - 2011-05-03 13:46:33 --> Helper loaded: url_helper
DEBUG - 2011-05-03 13:46:33 --> File loaded: application/views/common/header.php
DEBUG - 2011-05-03 13:46:33 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-05-03 13:46:33 --> File loaded: application/views/common/footer.php
DEBUG - 2011-05-03 13:46:33 --> File loaded: application/views/layout/main.php
DEBUG - 2011-05-03 13:46:33 --> Final output sent to browser
DEBUG - 2011-05-03 13:46:33 --> Total execution time: 0.1540
DEBUG - 2011-05-03 13:46:36 --> Config Class Initialized
DEBUG - 2011-05-03 13:46:36 --> Hooks Class Initialized
DEBUG - 2011-05-03 13:46:36 --> Utf8 Class Initialized
DEBUG - 2011-05-03 13:46:36 --> UTF-8 Support Enabled
DEBUG - 2011-05-03 13:46:36 --> URI Class Initialized
DEBUG - 2011-05-03 13:46:36 --> Router Class Initialized
DEBUG - 2011-05-03 13:46:36 --> Output Class Initialized
DEBUG - 2011-05-03 13:46:36 --> Input Class Initialized
DEBUG - 2011-05-03 13:46:36 --> Global POST and COOKIE data sanitized
DEBUG - 2011-05-03 13:46:36 --> Language Class Initialized
DEBUG - 2011-05-03 13:46:36 --> Loader Class Initialized
DEBUG - 2011-05-03 13:46:36 --> Controller Class Initialized
DEBUG - 2011-05-03 13:46:36 --> Model Class Initialized
DEBUG - 2011-05-03 13:46:36 --> Model Class Initialized
DEBUG - 2011-05-03 13:46:36 --> Model Class Initialized
DEBUG - 2011-05-03 13:46:36 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-05-03 13:46:36 --> Database Driver Class Initialized
DEBUG - 2011-05-03 13:46:38 --> File loaded: application/views/table/main.php
DEBUG - 2011-05-03 13:46:38 --> Helper loaded: url_helper
DEBUG - 2011-05-03 13:46:38 --> File loaded: application/views/common/header.php
DEBUG - 2011-05-03 13:46:38 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-05-03 13:46:38 --> File loaded: application/views/common/footer.php
DEBUG - 2011-05-03 13:46:38 --> File loaded: application/views/layout/main.php
DEBUG - 2011-05-03 13:46:38 --> Final output sent to browser
DEBUG - 2011-05-03 13:46:38 --> Total execution time: 1.9432
DEBUG - 2011-05-03 13:46:39 --> Config Class Initialized
DEBUG - 2011-05-03 13:46:39 --> Hooks Class Initialized
DEBUG - 2011-05-03 13:46:39 --> Utf8 Class Initialized
DEBUG - 2011-05-03 13:46:39 --> UTF-8 Support Enabled
DEBUG - 2011-05-03 13:46:39 --> URI Class Initialized
DEBUG - 2011-05-03 13:46:39 --> Router Class Initialized
DEBUG - 2011-05-03 13:46:39 --> Output Class Initialized
DEBUG - 2011-05-03 13:46:39 --> Input Class Initialized
DEBUG - 2011-05-03 13:46:39 --> Global POST and COOKIE data sanitized
DEBUG - 2011-05-03 13:46:39 --> Language Class Initialized
DEBUG - 2011-05-03 13:46:39 --> Loader Class Initialized
DEBUG - 2011-05-03 13:46:39 --> Controller Class Initialized
ERROR - 2011-05-03 13:46:39 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-05-03 13:46:39 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-05-03 13:46:39 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-05-03 13:46:39 --> Model Class Initialized
DEBUG - 2011-05-03 13:46:39 --> Model Class Initialized
DEBUG - 2011-05-03 13:46:39 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-05-03 13:46:39 --> Database Driver Class Initialized
DEBUG - 2011-05-03 13:46:39 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-05-03 13:46:39 --> Helper loaded: url_helper
DEBUG - 2011-05-03 13:46:39 --> File loaded: application/views/common/header.php
DEBUG - 2011-05-03 13:46:39 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-05-03 13:46:39 --> File loaded: application/views/common/footer.php
DEBUG - 2011-05-03 13:46:39 --> File loaded: application/views/layout/main.php
DEBUG - 2011-05-03 13:46:39 --> Final output sent to browser
DEBUG - 2011-05-03 13:46:39 --> Total execution time: 0.3206
DEBUG - 2011-05-03 15:25:31 --> Config Class Initialized
DEBUG - 2011-05-03 15:25:31 --> Hooks Class Initialized
DEBUG - 2011-05-03 15:25:31 --> Utf8 Class Initialized
DEBUG - 2011-05-03 15:25:31 --> UTF-8 Support Enabled
DEBUG - 2011-05-03 15:25:31 --> URI Class Initialized
DEBUG - 2011-05-03 15:25:31 --> Router Class Initialized
DEBUG - 2011-05-03 15:25:31 --> Output Class Initialized
DEBUG - 2011-05-03 15:25:31 --> Input Class Initialized
DEBUG - 2011-05-03 15:25:31 --> Global POST and COOKIE data sanitized
DEBUG - 2011-05-03 15:25:31 --> Language Class Initialized
DEBUG - 2011-05-03 15:25:31 --> Loader Class Initialized
DEBUG - 2011-05-03 15:25:31 --> Controller Class Initialized
ERROR - 2011-05-03 15:25:31 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-05-03 15:25:31 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-05-03 15:25:31 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-05-03 15:25:31 --> Model Class Initialized
DEBUG - 2011-05-03 15:25:31 --> Model Class Initialized
DEBUG - 2011-05-03 15:25:31 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-05-03 15:25:31 --> Database Driver Class Initialized
DEBUG - 2011-05-03 15:25:31 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-05-03 15:25:31 --> Helper loaded: url_helper
DEBUG - 2011-05-03 15:25:31 --> File loaded: application/views/common/header.php
DEBUG - 2011-05-03 15:25:31 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-05-03 15:25:31 --> File loaded: application/views/common/footer.php
DEBUG - 2011-05-03 15:25:31 --> File loaded: application/views/layout/main.php
DEBUG - 2011-05-03 15:25:31 --> Final output sent to browser
DEBUG - 2011-05-03 15:25:31 --> Total execution time: 0.6230
DEBUG - 2011-05-03 15:25:33 --> Config Class Initialized
DEBUG - 2011-05-03 15:25:33 --> Hooks Class Initialized
DEBUG - 2011-05-03 15:25:33 --> Utf8 Class Initialized
DEBUG - 2011-05-03 15:25:33 --> UTF-8 Support Enabled
DEBUG - 2011-05-03 15:25:33 --> URI Class Initialized
DEBUG - 2011-05-03 15:25:33 --> Router Class Initialized
ERROR - 2011-05-03 15:25:33 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-05-03 15:25:34 --> Config Class Initialized
DEBUG - 2011-05-03 15:25:34 --> Hooks Class Initialized
DEBUG - 2011-05-03 15:25:34 --> Utf8 Class Initialized
DEBUG - 2011-05-03 15:25:34 --> UTF-8 Support Enabled
DEBUG - 2011-05-03 15:25:34 --> URI Class Initialized
DEBUG - 2011-05-03 15:25:34 --> Router Class Initialized
DEBUG - 2011-05-03 15:25:34 --> Output Class Initialized
DEBUG - 2011-05-03 15:25:34 --> Input Class Initialized
DEBUG - 2011-05-03 15:25:34 --> Global POST and COOKIE data sanitized
DEBUG - 2011-05-03 15:25:34 --> Language Class Initialized
DEBUG - 2011-05-03 15:25:34 --> Loader Class Initialized
DEBUG - 2011-05-03 15:25:34 --> Controller Class Initialized
DEBUG - 2011-05-03 15:25:34 --> Model Class Initialized
DEBUG - 2011-05-03 15:25:34 --> Model Class Initialized
DEBUG - 2011-05-03 15:25:34 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-05-03 15:25:34 --> Database Driver Class Initialized
DEBUG - 2011-05-03 15:25:35 --> Final output sent to browser
DEBUG - 2011-05-03 15:25:35 --> Total execution time: 0.7877
DEBUG - 2011-05-03 15:25:57 --> Config Class Initialized
DEBUG - 2011-05-03 15:25:57 --> Hooks Class Initialized
DEBUG - 2011-05-03 15:25:57 --> Utf8 Class Initialized
DEBUG - 2011-05-03 15:25:57 --> UTF-8 Support Enabled
DEBUG - 2011-05-03 15:25:57 --> URI Class Initialized
DEBUG - 2011-05-03 15:25:57 --> Router Class Initialized
DEBUG - 2011-05-03 15:25:57 --> Output Class Initialized
DEBUG - 2011-05-03 15:25:57 --> Input Class Initialized
DEBUG - 2011-05-03 15:25:57 --> Global POST and COOKIE data sanitized
DEBUG - 2011-05-03 15:25:57 --> Language Class Initialized
DEBUG - 2011-05-03 15:25:57 --> Loader Class Initialized
DEBUG - 2011-05-03 15:25:57 --> Controller Class Initialized
ERROR - 2011-05-03 15:25:57 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-05-03 15:25:57 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-05-03 15:25:57 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-05-03 15:25:57 --> Model Class Initialized
DEBUG - 2011-05-03 15:25:57 --> Model Class Initialized
DEBUG - 2011-05-03 15:25:57 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-05-03 15:25:57 --> Database Driver Class Initialized
DEBUG - 2011-05-03 15:25:57 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-05-03 15:25:57 --> Helper loaded: url_helper
DEBUG - 2011-05-03 15:25:57 --> File loaded: application/views/common/header.php
DEBUG - 2011-05-03 15:25:57 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-05-03 15:25:57 --> File loaded: application/views/common/footer.php
DEBUG - 2011-05-03 15:25:57 --> File loaded: application/views/layout/main.php
DEBUG - 2011-05-03 15:25:57 --> Final output sent to browser
DEBUG - 2011-05-03 15:25:57 --> Total execution time: 0.0293
DEBUG - 2011-05-03 15:25:59 --> Config Class Initialized
DEBUG - 2011-05-03 15:25:59 --> Hooks Class Initialized
DEBUG - 2011-05-03 15:25:59 --> Utf8 Class Initialized
DEBUG - 2011-05-03 15:25:59 --> UTF-8 Support Enabled
DEBUG - 2011-05-03 15:25:59 --> URI Class Initialized
DEBUG - 2011-05-03 15:25:59 --> Router Class Initialized
DEBUG - 2011-05-03 15:25:59 --> Output Class Initialized
DEBUG - 2011-05-03 15:25:59 --> Input Class Initialized
DEBUG - 2011-05-03 15:25:59 --> Global POST and COOKIE data sanitized
DEBUG - 2011-05-03 15:25:59 --> Language Class Initialized
DEBUG - 2011-05-03 15:25:59 --> Loader Class Initialized
DEBUG - 2011-05-03 15:25:59 --> Controller Class Initialized
DEBUG - 2011-05-03 15:25:59 --> Model Class Initialized
DEBUG - 2011-05-03 15:25:59 --> Model Class Initialized
DEBUG - 2011-05-03 15:25:59 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-05-03 15:25:59 --> Database Driver Class Initialized
DEBUG - 2011-05-03 15:26:05 --> Final output sent to browser
DEBUG - 2011-05-03 15:26:05 --> Total execution time: 5.9783
DEBUG - 2011-05-03 15:26:29 --> Config Class Initialized
DEBUG - 2011-05-03 15:26:29 --> Hooks Class Initialized
DEBUG - 2011-05-03 15:26:29 --> Utf8 Class Initialized
DEBUG - 2011-05-03 15:26:29 --> UTF-8 Support Enabled
DEBUG - 2011-05-03 15:26:29 --> URI Class Initialized
DEBUG - 2011-05-03 15:26:29 --> Router Class Initialized
DEBUG - 2011-05-03 15:26:29 --> Output Class Initialized
DEBUG - 2011-05-03 15:26:29 --> Input Class Initialized
DEBUG - 2011-05-03 15:26:29 --> Global POST and COOKIE data sanitized
DEBUG - 2011-05-03 15:26:29 --> Language Class Initialized
DEBUG - 2011-05-03 15:26:29 --> Loader Class Initialized
DEBUG - 2011-05-03 15:26:29 --> Controller Class Initialized
ERROR - 2011-05-03 15:26:29 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-05-03 15:26:29 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-05-03 15:26:29 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-05-03 15:26:29 --> Model Class Initialized
DEBUG - 2011-05-03 15:26:29 --> Model Class Initialized
DEBUG - 2011-05-03 15:26:29 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-05-03 15:26:29 --> Database Driver Class Initialized
DEBUG - 2011-05-03 15:26:29 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-05-03 15:26:29 --> Helper loaded: url_helper
DEBUG - 2011-05-03 15:26:29 --> File loaded: application/views/common/header.php
DEBUG - 2011-05-03 15:26:29 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-05-03 15:26:29 --> File loaded: application/views/common/footer.php
DEBUG - 2011-05-03 15:26:29 --> File loaded: application/views/layout/main.php
DEBUG - 2011-05-03 15:26:29 --> Final output sent to browser
DEBUG - 2011-05-03 15:26:29 --> Total execution time: 0.0303
DEBUG - 2011-05-03 15:26:30 --> Config Class Initialized
DEBUG - 2011-05-03 15:26:30 --> Hooks Class Initialized
DEBUG - 2011-05-03 15:26:30 --> Utf8 Class Initialized
DEBUG - 2011-05-03 15:26:30 --> UTF-8 Support Enabled
DEBUG - 2011-05-03 15:26:30 --> URI Class Initialized
DEBUG - 2011-05-03 15:26:30 --> Router Class Initialized
DEBUG - 2011-05-03 15:26:30 --> Output Class Initialized
DEBUG - 2011-05-03 15:26:30 --> Input Class Initialized
DEBUG - 2011-05-03 15:26:30 --> Global POST and COOKIE data sanitized
DEBUG - 2011-05-03 15:26:30 --> Language Class Initialized
DEBUG - 2011-05-03 15:26:30 --> Loader Class Initialized
DEBUG - 2011-05-03 15:26:30 --> Controller Class Initialized
DEBUG - 2011-05-03 15:26:30 --> Model Class Initialized
DEBUG - 2011-05-03 15:26:30 --> Model Class Initialized
DEBUG - 2011-05-03 15:26:30 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-05-03 15:26:30 --> Database Driver Class Initialized
DEBUG - 2011-05-03 15:26:31 --> Final output sent to browser
DEBUG - 2011-05-03 15:26:31 --> Total execution time: 0.5927
DEBUG - 2011-05-03 16:18:03 --> Config Class Initialized
DEBUG - 2011-05-03 16:18:03 --> Hooks Class Initialized
DEBUG - 2011-05-03 16:18:03 --> Utf8 Class Initialized
DEBUG - 2011-05-03 16:18:03 --> UTF-8 Support Enabled
DEBUG - 2011-05-03 16:18:03 --> URI Class Initialized
DEBUG - 2011-05-03 16:18:03 --> Router Class Initialized
DEBUG - 2011-05-03 16:18:03 --> Output Class Initialized
DEBUG - 2011-05-03 16:18:03 --> Input Class Initialized
DEBUG - 2011-05-03 16:18:03 --> Global POST and COOKIE data sanitized
DEBUG - 2011-05-03 16:18:03 --> Language Class Initialized
DEBUG - 2011-05-03 16:18:04 --> Loader Class Initialized
DEBUG - 2011-05-03 16:18:04 --> Controller Class Initialized
DEBUG - 2011-05-03 16:18:04 --> Model Class Initialized
DEBUG - 2011-05-03 16:18:04 --> Model Class Initialized
DEBUG - 2011-05-03 16:18:04 --> Model Class Initialized
DEBUG - 2011-05-03 16:18:04 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-05-03 16:18:04 --> Database Driver Class Initialized
DEBUG - 2011-05-03 16:18:04 --> File loaded: application/views/table/main.php
DEBUG - 2011-05-03 16:18:04 --> Helper loaded: url_helper
DEBUG - 2011-05-03 16:18:04 --> File loaded: application/views/common/header.php
DEBUG - 2011-05-03 16:18:04 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-05-03 16:18:04 --> File loaded: application/views/common/footer.php
DEBUG - 2011-05-03 16:18:04 --> File loaded: application/views/layout/main.php
DEBUG - 2011-05-03 16:18:04 --> Final output sent to browser
DEBUG - 2011-05-03 16:18:04 --> Total execution time: 0.7612
DEBUG - 2011-05-03 16:18:30 --> Config Class Initialized
DEBUG - 2011-05-03 16:18:30 --> Hooks Class Initialized
DEBUG - 2011-05-03 16:18:30 --> Utf8 Class Initialized
DEBUG - 2011-05-03 16:18:30 --> UTF-8 Support Enabled
DEBUG - 2011-05-03 16:18:30 --> URI Class Initialized
DEBUG - 2011-05-03 16:18:30 --> Router Class Initialized
DEBUG - 2011-05-03 16:18:30 --> Output Class Initialized
DEBUG - 2011-05-03 16:18:30 --> Input Class Initialized
DEBUG - 2011-05-03 16:18:30 --> Global POST and COOKIE data sanitized
DEBUG - 2011-05-03 16:18:30 --> Language Class Initialized
DEBUG - 2011-05-03 16:18:30 --> Loader Class Initialized
DEBUG - 2011-05-03 16:18:30 --> Controller Class Initialized
ERROR - 2011-05-03 16:18:30 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-05-03 16:18:30 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-05-03 16:18:30 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-05-03 16:18:30 --> Model Class Initialized
DEBUG - 2011-05-03 16:18:30 --> Model Class Initialized
DEBUG - 2011-05-03 16:18:30 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-05-03 16:18:30 --> Database Driver Class Initialized
DEBUG - 2011-05-03 16:18:30 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-05-03 16:18:30 --> Helper loaded: url_helper
DEBUG - 2011-05-03 16:18:30 --> File loaded: application/views/common/header.php
DEBUG - 2011-05-03 16:18:30 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-05-03 16:18:30 --> File loaded: application/views/common/footer.php
DEBUG - 2011-05-03 16:18:30 --> File loaded: application/views/layout/main.php
DEBUG - 2011-05-03 16:18:30 --> Final output sent to browser
DEBUG - 2011-05-03 16:18:30 --> Total execution time: 0.3266
DEBUG - 2011-05-03 16:18:31 --> Config Class Initialized
DEBUG - 2011-05-03 16:18:31 --> Hooks Class Initialized
DEBUG - 2011-05-03 16:18:31 --> Utf8 Class Initialized
DEBUG - 2011-05-03 16:18:31 --> UTF-8 Support Enabled
DEBUG - 2011-05-03 16:18:31 --> URI Class Initialized
DEBUG - 2011-05-03 16:18:31 --> Router Class Initialized
DEBUG - 2011-05-03 16:18:31 --> Output Class Initialized
DEBUG - 2011-05-03 16:18:31 --> Input Class Initialized
DEBUG - 2011-05-03 16:18:31 --> Global POST and COOKIE data sanitized
DEBUG - 2011-05-03 16:18:31 --> Language Class Initialized
DEBUG - 2011-05-03 16:18:31 --> Loader Class Initialized
DEBUG - 2011-05-03 16:18:31 --> Controller Class Initialized
DEBUG - 2011-05-03 16:18:31 --> Model Class Initialized
DEBUG - 2011-05-03 16:18:31 --> Model Class Initialized
DEBUG - 2011-05-03 16:18:31 --> Model Class Initialized
DEBUG - 2011-05-03 16:18:31 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-05-03 16:18:32 --> Database Driver Class Initialized
DEBUG - 2011-05-03 16:18:32 --> File loaded: application/views/table/main.php
DEBUG - 2011-05-03 16:18:32 --> Helper loaded: url_helper
DEBUG - 2011-05-03 16:18:32 --> File loaded: application/views/common/header.php
DEBUG - 2011-05-03 16:18:32 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-05-03 16:18:32 --> File loaded: application/views/common/footer.php
DEBUG - 2011-05-03 16:18:32 --> File loaded: application/views/layout/main.php
DEBUG - 2011-05-03 16:18:32 --> Final output sent to browser
DEBUG - 2011-05-03 16:18:32 --> Total execution time: 0.0530
DEBUG - 2011-05-03 16:18:32 --> Config Class Initialized
DEBUG - 2011-05-03 16:18:32 --> Hooks Class Initialized
DEBUG - 2011-05-03 16:18:32 --> Utf8 Class Initialized
DEBUG - 2011-05-03 16:18:32 --> UTF-8 Support Enabled
DEBUG - 2011-05-03 16:18:32 --> URI Class Initialized
DEBUG - 2011-05-03 16:18:32 --> Router Class Initialized
DEBUG - 2011-05-03 16:18:32 --> Output Class Initialized
DEBUG - 2011-05-03 16:18:32 --> Input Class Initialized
DEBUG - 2011-05-03 16:18:32 --> Global POST and COOKIE data sanitized
DEBUG - 2011-05-03 16:18:32 --> Language Class Initialized
DEBUG - 2011-05-03 16:18:32 --> Loader Class Initialized
DEBUG - 2011-05-03 16:18:32 --> Controller Class Initialized
ERROR - 2011-05-03 16:18:32 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-05-03 16:18:32 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-05-03 16:18:32 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-05-03 16:18:32 --> Model Class Initialized
DEBUG - 2011-05-03 16:18:32 --> Model Class Initialized
DEBUG - 2011-05-03 16:18:32 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-05-03 16:18:32 --> Database Driver Class Initialized
DEBUG - 2011-05-03 16:18:32 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-05-03 16:18:32 --> Helper loaded: url_helper
DEBUG - 2011-05-03 16:18:32 --> File loaded: application/views/common/header.php
DEBUG - 2011-05-03 16:18:32 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-05-03 16:18:32 --> File loaded: application/views/common/footer.php
DEBUG - 2011-05-03 16:18:32 --> File loaded: application/views/layout/main.php
DEBUG - 2011-05-03 16:18:32 --> Final output sent to browser
DEBUG - 2011-05-03 16:18:32 --> Total execution time: 0.0301
DEBUG - 2011-05-03 16:35:39 --> Config Class Initialized
DEBUG - 2011-05-03 16:35:39 --> Hooks Class Initialized
DEBUG - 2011-05-03 16:35:39 --> Utf8 Class Initialized
DEBUG - 2011-05-03 16:35:39 --> UTF-8 Support Enabled
DEBUG - 2011-05-03 16:35:39 --> URI Class Initialized
DEBUG - 2011-05-03 16:35:39 --> Router Class Initialized
DEBUG - 2011-05-03 16:35:39 --> Output Class Initialized
DEBUG - 2011-05-03 16:35:39 --> Input Class Initialized
DEBUG - 2011-05-03 16:35:39 --> Global POST and COOKIE data sanitized
DEBUG - 2011-05-03 16:35:39 --> Language Class Initialized
DEBUG - 2011-05-03 16:35:39 --> Loader Class Initialized
DEBUG - 2011-05-03 16:35:39 --> Controller Class Initialized
DEBUG - 2011-05-03 16:35:39 --> Model Class Initialized
DEBUG - 2011-05-03 16:35:39 --> Model Class Initialized
DEBUG - 2011-05-03 16:35:39 --> Model Class Initialized
DEBUG - 2011-05-03 16:35:39 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-05-03 16:35:39 --> Database Driver Class Initialized
DEBUG - 2011-05-03 16:35:39 --> File loaded: application/views/table/main.php
DEBUG - 2011-05-03 16:35:39 --> Helper loaded: url_helper
DEBUG - 2011-05-03 16:35:39 --> File loaded: application/views/common/header.php
DEBUG - 2011-05-03 16:35:39 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-05-03 16:35:39 --> File loaded: application/views/common/footer.php
DEBUG - 2011-05-03 16:35:39 --> File loaded: application/views/layout/main.php
DEBUG - 2011-05-03 16:35:39 --> Final output sent to browser
DEBUG - 2011-05-03 16:35:39 --> Total execution time: 0.2341
DEBUG - 2011-05-03 16:35:56 --> Config Class Initialized
DEBUG - 2011-05-03 16:35:56 --> Hooks Class Initialized
DEBUG - 2011-05-03 16:35:56 --> Utf8 Class Initialized
DEBUG - 2011-05-03 16:35:56 --> UTF-8 Support Enabled
DEBUG - 2011-05-03 16:35:56 --> URI Class Initialized
DEBUG - 2011-05-03 16:35:56 --> Router Class Initialized
DEBUG - 2011-05-03 16:35:56 --> Output Class Initialized
DEBUG - 2011-05-03 16:35:56 --> Input Class Initialized
DEBUG - 2011-05-03 16:35:56 --> Global POST and COOKIE data sanitized
DEBUG - 2011-05-03 16:35:56 --> Language Class Initialized
DEBUG - 2011-05-03 16:35:56 --> Loader Class Initialized
DEBUG - 2011-05-03 16:35:56 --> Controller Class Initialized
ERROR - 2011-05-03 16:35:56 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-05-03 16:35:56 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-05-03 16:35:56 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-05-03 16:35:56 --> Model Class Initialized
DEBUG - 2011-05-03 16:35:56 --> Model Class Initialized
DEBUG - 2011-05-03 16:35:56 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-05-03 16:35:56 --> Database Driver Class Initialized
DEBUG - 2011-05-03 16:35:56 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-05-03 16:35:56 --> Helper loaded: url_helper
DEBUG - 2011-05-03 16:35:56 --> File loaded: application/views/common/header.php
DEBUG - 2011-05-03 16:35:56 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-05-03 16:35:56 --> File loaded: application/views/common/footer.php
DEBUG - 2011-05-03 16:35:56 --> File loaded: application/views/layout/main.php
DEBUG - 2011-05-03 16:35:56 --> Final output sent to browser
DEBUG - 2011-05-03 16:35:56 --> Total execution time: 0.0492
DEBUG - 2011-05-03 17:57:49 --> Config Class Initialized
DEBUG - 2011-05-03 17:57:49 --> Hooks Class Initialized
DEBUG - 2011-05-03 17:57:49 --> Utf8 Class Initialized
DEBUG - 2011-05-03 17:57:49 --> UTF-8 Support Enabled
DEBUG - 2011-05-03 17:57:49 --> URI Class Initialized
DEBUG - 2011-05-03 17:57:49 --> Router Class Initialized
DEBUG - 2011-05-03 17:57:49 --> No URI present. Default controller set.
DEBUG - 2011-05-03 17:57:49 --> Output Class Initialized
DEBUG - 2011-05-03 17:57:49 --> Input Class Initialized
DEBUG - 2011-05-03 17:57:49 --> Global POST and COOKIE data sanitized
DEBUG - 2011-05-03 17:57:49 --> Language Class Initialized
DEBUG - 2011-05-03 17:57:49 --> Loader Class Initialized
DEBUG - 2011-05-03 17:57:49 --> Controller Class Initialized
DEBUG - 2011-05-03 17:57:49 --> File loaded: application/views/splash/main.php
DEBUG - 2011-05-03 17:57:49 --> Helper loaded: url_helper
DEBUG - 2011-05-03 17:57:49 --> File loaded: application/views/common/header.php
DEBUG - 2011-05-03 17:57:49 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-05-03 17:57:49 --> File loaded: application/views/common/footer.php
DEBUG - 2011-05-03 17:57:49 --> File loaded: application/views/layout/main.php
DEBUG - 2011-05-03 17:57:49 --> Final output sent to browser
DEBUG - 2011-05-03 17:57:49 --> Total execution time: 0.2899
DEBUG - 2011-05-03 17:57:50 --> Config Class Initialized
DEBUG - 2011-05-03 17:57:50 --> Hooks Class Initialized
DEBUG - 2011-05-03 17:57:50 --> Utf8 Class Initialized
DEBUG - 2011-05-03 17:57:50 --> UTF-8 Support Enabled
DEBUG - 2011-05-03 17:57:50 --> URI Class Initialized
DEBUG - 2011-05-03 17:57:50 --> Router Class Initialized
ERROR - 2011-05-03 17:57:50 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-05-03 17:57:50 --> Config Class Initialized
DEBUG - 2011-05-03 17:57:50 --> Hooks Class Initialized
DEBUG - 2011-05-03 17:57:50 --> Utf8 Class Initialized
DEBUG - 2011-05-03 17:57:50 --> UTF-8 Support Enabled
DEBUG - 2011-05-03 17:57:50 --> URI Class Initialized
DEBUG - 2011-05-03 17:57:50 --> Router Class Initialized
ERROR - 2011-05-03 17:57:50 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-05-03 17:57:54 --> Config Class Initialized
DEBUG - 2011-05-03 17:57:54 --> Hooks Class Initialized
DEBUG - 2011-05-03 17:57:54 --> Utf8 Class Initialized
DEBUG - 2011-05-03 17:57:54 --> UTF-8 Support Enabled
DEBUG - 2011-05-03 17:57:54 --> URI Class Initialized
DEBUG - 2011-05-03 17:57:54 --> Router Class Initialized
DEBUG - 2011-05-03 17:57:54 --> Output Class Initialized
DEBUG - 2011-05-03 17:57:54 --> Input Class Initialized
DEBUG - 2011-05-03 17:57:54 --> Global POST and COOKIE data sanitized
DEBUG - 2011-05-03 17:57:54 --> Language Class Initialized
DEBUG - 2011-05-03 17:57:54 --> Loader Class Initialized
DEBUG - 2011-05-03 17:57:54 --> Controller Class Initialized
DEBUG - 2011-05-03 17:57:54 --> Model Class Initialized
DEBUG - 2011-05-03 17:57:54 --> Model Class Initialized
DEBUG - 2011-05-03 17:57:54 --> Model Class Initialized
DEBUG - 2011-05-03 17:57:54 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-05-03 17:57:54 --> Database Driver Class Initialized
DEBUG - 2011-05-03 17:57:54 --> File loaded: application/views/table/main.php
DEBUG - 2011-05-03 17:57:54 --> Helper loaded: url_helper
DEBUG - 2011-05-03 17:57:54 --> File loaded: application/views/common/header.php
DEBUG - 2011-05-03 17:57:54 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-05-03 17:57:54 --> File loaded: application/views/common/footer.php
DEBUG - 2011-05-03 17:57:54 --> File loaded: application/views/layout/main.php
DEBUG - 2011-05-03 17:57:54 --> Final output sent to browser
DEBUG - 2011-05-03 17:57:54 --> Total execution time: 0.5700
DEBUG - 2011-05-03 17:57:55 --> Config Class Initialized
DEBUG - 2011-05-03 17:57:55 --> Hooks Class Initialized
DEBUG - 2011-05-03 17:57:55 --> Utf8 Class Initialized
DEBUG - 2011-05-03 17:57:55 --> UTF-8 Support Enabled
DEBUG - 2011-05-03 17:57:55 --> URI Class Initialized
DEBUG - 2011-05-03 17:57:55 --> Router Class Initialized
ERROR - 2011-05-03 17:57:55 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-05-03 17:57:58 --> Config Class Initialized
DEBUG - 2011-05-03 17:57:58 --> Hooks Class Initialized
DEBUG - 2011-05-03 17:57:58 --> Utf8 Class Initialized
DEBUG - 2011-05-03 17:57:58 --> UTF-8 Support Enabled
DEBUG - 2011-05-03 17:57:58 --> URI Class Initialized
DEBUG - 2011-05-03 17:57:58 --> Router Class Initialized
ERROR - 2011-05-03 17:57:58 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-05-03 17:57:59 --> Config Class Initialized
DEBUG - 2011-05-03 17:57:59 --> Hooks Class Initialized
DEBUG - 2011-05-03 17:57:59 --> Utf8 Class Initialized
DEBUG - 2011-05-03 17:57:59 --> UTF-8 Support Enabled
DEBUG - 2011-05-03 17:57:59 --> URI Class Initialized
DEBUG - 2011-05-03 17:57:59 --> Router Class Initialized
DEBUG - 2011-05-03 17:57:59 --> Output Class Initialized
DEBUG - 2011-05-03 17:57:59 --> Input Class Initialized
DEBUG - 2011-05-03 17:57:59 --> Global POST and COOKIE data sanitized
DEBUG - 2011-05-03 17:57:59 --> Language Class Initialized
DEBUG - 2011-05-03 17:57:59 --> Loader Class Initialized
DEBUG - 2011-05-03 17:57:59 --> Controller Class Initialized
ERROR - 2011-05-03 17:57:59 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-05-03 17:57:59 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-05-03 17:57:59 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-05-03 17:57:59 --> Model Class Initialized
DEBUG - 2011-05-03 17:57:59 --> Model Class Initialized
DEBUG - 2011-05-03 17:57:59 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-05-03 17:57:59 --> Database Driver Class Initialized
DEBUG - 2011-05-03 17:57:59 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-05-03 17:57:59 --> Helper loaded: url_helper
DEBUG - 2011-05-03 17:57:59 --> File loaded: application/views/common/header.php
DEBUG - 2011-05-03 17:57:59 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-05-03 17:57:59 --> File loaded: application/views/common/footer.php
DEBUG - 2011-05-03 17:57:59 --> File loaded: application/views/layout/main.php
DEBUG - 2011-05-03 17:57:59 --> Final output sent to browser
DEBUG - 2011-05-03 17:57:59 --> Total execution time: 0.0816
DEBUG - 2011-05-03 17:58:00 --> Config Class Initialized
DEBUG - 2011-05-03 17:58:00 --> Hooks Class Initialized
DEBUG - 2011-05-03 17:58:00 --> Utf8 Class Initialized
DEBUG - 2011-05-03 17:58:00 --> UTF-8 Support Enabled
DEBUG - 2011-05-03 17:58:00 --> URI Class Initialized
DEBUG - 2011-05-03 17:58:00 --> Router Class Initialized
DEBUG - 2011-05-03 17:58:00 --> Output Class Initialized
DEBUG - 2011-05-03 17:58:00 --> Input Class Initialized
DEBUG - 2011-05-03 17:58:00 --> Global POST and COOKIE data sanitized
DEBUG - 2011-05-03 17:58:00 --> Language Class Initialized
DEBUG - 2011-05-03 17:58:00 --> Loader Class Initialized
DEBUG - 2011-05-03 17:58:00 --> Controller Class Initialized
DEBUG - 2011-05-03 17:58:00 --> Model Class Initialized
DEBUG - 2011-05-03 17:58:00 --> Model Class Initialized
DEBUG - 2011-05-03 17:58:00 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-05-03 17:58:00 --> Database Driver Class Initialized
DEBUG - 2011-05-03 17:58:00 --> Final output sent to browser
DEBUG - 2011-05-03 17:58:00 --> Total execution time: 0.7000
DEBUG - 2011-05-03 17:58:01 --> Config Class Initialized
DEBUG - 2011-05-03 17:58:01 --> Hooks Class Initialized
DEBUG - 2011-05-03 17:58:01 --> Utf8 Class Initialized
DEBUG - 2011-05-03 17:58:01 --> UTF-8 Support Enabled
DEBUG - 2011-05-03 17:58:01 --> URI Class Initialized
DEBUG - 2011-05-03 17:58:01 --> Router Class Initialized
ERROR - 2011-05-03 17:58:01 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-05-03 17:58:20 --> Config Class Initialized
DEBUG - 2011-05-03 17:58:20 --> Hooks Class Initialized
DEBUG - 2011-05-03 17:58:20 --> Utf8 Class Initialized
DEBUG - 2011-05-03 17:58:20 --> UTF-8 Support Enabled
DEBUG - 2011-05-03 17:58:20 --> URI Class Initialized
DEBUG - 2011-05-03 17:58:20 --> Router Class Initialized
DEBUG - 2011-05-03 17:58:20 --> Output Class Initialized
DEBUG - 2011-05-03 17:58:20 --> Input Class Initialized
DEBUG - 2011-05-03 17:58:20 --> Global POST and COOKIE data sanitized
DEBUG - 2011-05-03 17:58:20 --> Language Class Initialized
DEBUG - 2011-05-03 17:58:20 --> Loader Class Initialized
DEBUG - 2011-05-03 17:58:20 --> Controller Class Initialized
ERROR - 2011-05-03 17:58:20 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-05-03 17:58:20 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-05-03 17:58:20 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-05-03 17:58:20 --> Model Class Initialized
DEBUG - 2011-05-03 17:58:20 --> Model Class Initialized
DEBUG - 2011-05-03 17:58:20 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-05-03 17:58:20 --> Database Driver Class Initialized
DEBUG - 2011-05-03 17:58:20 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-05-03 17:58:20 --> Helper loaded: url_helper
DEBUG - 2011-05-03 17:58:20 --> File loaded: application/views/common/header.php
DEBUG - 2011-05-03 17:58:20 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-05-03 17:58:20 --> File loaded: application/views/common/footer.php
DEBUG - 2011-05-03 17:58:20 --> File loaded: application/views/layout/main.php
DEBUG - 2011-05-03 17:58:20 --> Final output sent to browser
DEBUG - 2011-05-03 17:58:20 --> Total execution time: 0.1143
DEBUG - 2011-05-03 17:58:21 --> Config Class Initialized
DEBUG - 2011-05-03 17:58:21 --> Hooks Class Initialized
DEBUG - 2011-05-03 17:58:21 --> Utf8 Class Initialized
DEBUG - 2011-05-03 17:58:21 --> UTF-8 Support Enabled
DEBUG - 2011-05-03 17:58:21 --> URI Class Initialized
DEBUG - 2011-05-03 17:58:21 --> Router Class Initialized
DEBUG - 2011-05-03 17:58:21 --> Output Class Initialized
DEBUG - 2011-05-03 17:58:21 --> Input Class Initialized
DEBUG - 2011-05-03 17:58:21 --> Global POST and COOKIE data sanitized
DEBUG - 2011-05-03 17:58:21 --> Language Class Initialized
DEBUG - 2011-05-03 17:58:21 --> Loader Class Initialized
DEBUG - 2011-05-03 17:58:21 --> Controller Class Initialized
DEBUG - 2011-05-03 17:58:21 --> Model Class Initialized
DEBUG - 2011-05-03 17:58:21 --> Model Class Initialized
DEBUG - 2011-05-03 17:58:21 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-05-03 17:58:21 --> Database Driver Class Initialized
DEBUG - 2011-05-03 17:58:22 --> Final output sent to browser
DEBUG - 2011-05-03 17:58:22 --> Total execution time: 0.8351
DEBUG - 2011-05-03 17:58:24 --> Config Class Initialized
DEBUG - 2011-05-03 17:58:24 --> Hooks Class Initialized
DEBUG - 2011-05-03 17:58:24 --> Utf8 Class Initialized
DEBUG - 2011-05-03 17:58:24 --> UTF-8 Support Enabled
DEBUG - 2011-05-03 17:58:24 --> URI Class Initialized
DEBUG - 2011-05-03 17:58:24 --> Router Class Initialized
ERROR - 2011-05-03 17:58:24 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-05-03 17:58:27 --> Config Class Initialized
DEBUG - 2011-05-03 17:58:27 --> Hooks Class Initialized
DEBUG - 2011-05-03 17:58:27 --> Utf8 Class Initialized
DEBUG - 2011-05-03 17:58:27 --> UTF-8 Support Enabled
DEBUG - 2011-05-03 17:58:27 --> URI Class Initialized
DEBUG - 2011-05-03 17:58:27 --> Router Class Initialized
DEBUG - 2011-05-03 17:58:27 --> Output Class Initialized
DEBUG - 2011-05-03 17:58:27 --> Input Class Initialized
DEBUG - 2011-05-03 17:58:27 --> Global POST and COOKIE data sanitized
DEBUG - 2011-05-03 17:58:27 --> Language Class Initialized
DEBUG - 2011-05-03 17:58:27 --> Loader Class Initialized
DEBUG - 2011-05-03 17:58:27 --> Controller Class Initialized
ERROR - 2011-05-03 17:58:27 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-05-03 17:58:27 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-05-03 17:58:27 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-05-03 17:58:27 --> Model Class Initialized
DEBUG - 2011-05-03 17:58:27 --> Model Class Initialized
DEBUG - 2011-05-03 17:58:27 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-05-03 17:58:27 --> Database Driver Class Initialized
DEBUG - 2011-05-03 17:58:27 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-05-03 17:58:27 --> Helper loaded: url_helper
DEBUG - 2011-05-03 17:58:27 --> File loaded: application/views/common/header.php
DEBUG - 2011-05-03 17:58:27 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-05-03 17:58:27 --> File loaded: application/views/common/footer.php
DEBUG - 2011-05-03 17:58:27 --> File loaded: application/views/layout/main.php
DEBUG - 2011-05-03 17:58:27 --> Final output sent to browser
DEBUG - 2011-05-03 17:58:27 --> Total execution time: 0.0279
DEBUG - 2011-05-03 17:58:28 --> Config Class Initialized
DEBUG - 2011-05-03 17:58:28 --> Hooks Class Initialized
DEBUG - 2011-05-03 17:58:28 --> Utf8 Class Initialized
DEBUG - 2011-05-03 17:58:28 --> UTF-8 Support Enabled
DEBUG - 2011-05-03 17:58:28 --> URI Class Initialized
DEBUG - 2011-05-03 17:58:28 --> Router Class Initialized
DEBUG - 2011-05-03 17:58:28 --> Output Class Initialized
DEBUG - 2011-05-03 17:58:28 --> Input Class Initialized
DEBUG - 2011-05-03 17:58:28 --> Global POST and COOKIE data sanitized
DEBUG - 2011-05-03 17:58:28 --> Language Class Initialized
DEBUG - 2011-05-03 17:58:28 --> Loader Class Initialized
DEBUG - 2011-05-03 17:58:28 --> Controller Class Initialized
DEBUG - 2011-05-03 17:58:28 --> Model Class Initialized
DEBUG - 2011-05-03 17:58:28 --> Model Class Initialized
DEBUG - 2011-05-03 17:58:28 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-05-03 17:58:28 --> Database Driver Class Initialized
DEBUG - 2011-05-03 17:58:28 --> Final output sent to browser
DEBUG - 2011-05-03 17:58:28 --> Total execution time: 0.5375
DEBUG - 2011-05-03 17:58:29 --> Config Class Initialized
DEBUG - 2011-05-03 17:58:29 --> Hooks Class Initialized
DEBUG - 2011-05-03 17:58:29 --> Utf8 Class Initialized
DEBUG - 2011-05-03 17:58:29 --> UTF-8 Support Enabled
DEBUG - 2011-05-03 17:58:29 --> URI Class Initialized
DEBUG - 2011-05-03 17:58:29 --> Router Class Initialized
ERROR - 2011-05-03 17:58:29 --> 404 Page Not Found --> robots.txt
DEBUG - 2011-05-03 17:58:30 --> Config Class Initialized
DEBUG - 2011-05-03 17:58:30 --> Hooks Class Initialized
DEBUG - 2011-05-03 17:58:30 --> Utf8 Class Initialized
DEBUG - 2011-05-03 17:58:30 --> UTF-8 Support Enabled
DEBUG - 2011-05-03 17:58:30 --> URI Class Initialized
DEBUG - 2011-05-03 17:58:30 --> Router Class Initialized
DEBUG - 2011-05-03 17:58:30 --> Output Class Initialized
DEBUG - 2011-05-03 17:58:30 --> Input Class Initialized
DEBUG - 2011-05-03 17:58:30 --> Global POST and COOKIE data sanitized
DEBUG - 2011-05-03 17:58:30 --> Language Class Initialized
DEBUG - 2011-05-03 17:58:30 --> Loader Class Initialized
DEBUG - 2011-05-03 17:58:30 --> Controller Class Initialized
ERROR - 2011-05-03 17:58:30 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-05-03 17:58:30 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-05-03 17:58:30 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-05-03 17:58:30 --> Model Class Initialized
DEBUG - 2011-05-03 17:58:30 --> Model Class Initialized
DEBUG - 2011-05-03 17:58:30 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-05-03 17:58:30 --> Database Driver Class Initialized
DEBUG - 2011-05-03 17:58:30 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-05-03 17:58:30 --> Helper loaded: url_helper
DEBUG - 2011-05-03 17:58:30 --> File loaded: application/views/common/header.php
DEBUG - 2011-05-03 17:58:30 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-05-03 17:58:30 --> File loaded: application/views/common/footer.php
DEBUG - 2011-05-03 17:58:30 --> File loaded: application/views/layout/main.php
DEBUG - 2011-05-03 17:58:30 --> Final output sent to browser
DEBUG - 2011-05-03 17:58:30 --> Total execution time: 0.0325
DEBUG - 2011-05-03 17:58:30 --> Config Class Initialized
DEBUG - 2011-05-03 17:58:30 --> Hooks Class Initialized
DEBUG - 2011-05-03 17:58:30 --> Utf8 Class Initialized
DEBUG - 2011-05-03 17:58:30 --> UTF-8 Support Enabled
DEBUG - 2011-05-03 17:58:30 --> URI Class Initialized
DEBUG - 2011-05-03 17:58:30 --> Router Class Initialized
ERROR - 2011-05-03 17:58:30 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-05-03 17:58:34 --> Config Class Initialized
DEBUG - 2011-05-03 17:58:34 --> Hooks Class Initialized
DEBUG - 2011-05-03 17:58:34 --> Utf8 Class Initialized
DEBUG - 2011-05-03 17:58:34 --> UTF-8 Support Enabled
DEBUG - 2011-05-03 17:58:34 --> URI Class Initialized
DEBUG - 2011-05-03 17:58:34 --> Router Class Initialized
DEBUG - 2011-05-03 17:58:34 --> Output Class Initialized
DEBUG - 2011-05-03 17:58:34 --> Input Class Initialized
DEBUG - 2011-05-03 17:58:34 --> Global POST and COOKIE data sanitized
DEBUG - 2011-05-03 17:58:34 --> Language Class Initialized
DEBUG - 2011-05-03 17:58:34 --> Loader Class Initialized
DEBUG - 2011-05-03 17:58:34 --> Controller Class Initialized
ERROR - 2011-05-03 17:58:34 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-05-03 17:58:34 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-05-03 17:58:34 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-05-03 17:58:34 --> Model Class Initialized
DEBUG - 2011-05-03 17:58:34 --> Model Class Initialized
DEBUG - 2011-05-03 17:58:34 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-05-03 17:58:35 --> Database Driver Class Initialized
DEBUG - 2011-05-03 17:58:35 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-05-03 17:58:35 --> Helper loaded: url_helper
DEBUG - 2011-05-03 17:58:35 --> File loaded: application/views/common/header.php
DEBUG - 2011-05-03 17:58:35 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-05-03 17:58:35 --> File loaded: application/views/common/footer.php
DEBUG - 2011-05-03 17:58:35 --> File loaded: application/views/layout/main.php
DEBUG - 2011-05-03 17:58:35 --> Final output sent to browser
DEBUG - 2011-05-03 17:58:35 --> Total execution time: 0.1103
DEBUG - 2011-05-03 17:58:35 --> Config Class Initialized
DEBUG - 2011-05-03 17:58:35 --> Hooks Class Initialized
DEBUG - 2011-05-03 17:58:35 --> Utf8 Class Initialized
DEBUG - 2011-05-03 17:58:35 --> UTF-8 Support Enabled
DEBUG - 2011-05-03 17:58:35 --> URI Class Initialized
DEBUG - 2011-05-03 17:58:35 --> Router Class Initialized
DEBUG - 2011-05-03 17:58:35 --> Output Class Initialized
DEBUG - 2011-05-03 17:58:35 --> Input Class Initialized
DEBUG - 2011-05-03 17:58:35 --> Global POST and COOKIE data sanitized
DEBUG - 2011-05-03 17:58:35 --> Language Class Initialized
DEBUG - 2011-05-03 17:58:35 --> Loader Class Initialized
DEBUG - 2011-05-03 17:58:35 --> Controller Class Initialized
DEBUG - 2011-05-03 17:58:35 --> Model Class Initialized
DEBUG - 2011-05-03 17:58:35 --> Model Class Initialized
DEBUG - 2011-05-03 17:58:35 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-05-03 17:58:35 --> Database Driver Class Initialized
DEBUG - 2011-05-03 17:58:35 --> Config Class Initialized
DEBUG - 2011-05-03 17:58:35 --> Hooks Class Initialized
DEBUG - 2011-05-03 17:58:35 --> Utf8 Class Initialized
DEBUG - 2011-05-03 17:58:35 --> UTF-8 Support Enabled
DEBUG - 2011-05-03 17:58:35 --> URI Class Initialized
DEBUG - 2011-05-03 17:58:35 --> Router Class Initialized
DEBUG - 2011-05-03 17:58:35 --> Output Class Initialized
DEBUG - 2011-05-03 17:58:35 --> Input Class Initialized
DEBUG - 2011-05-03 17:58:35 --> Global POST and COOKIE data sanitized
DEBUG - 2011-05-03 17:58:35 --> Language Class Initialized
DEBUG - 2011-05-03 17:58:35 --> Loader Class Initialized
DEBUG - 2011-05-03 17:58:35 --> Controller Class Initialized
ERROR - 2011-05-03 17:58:35 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-05-03 17:58:35 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-05-03 17:58:35 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-05-03 17:58:35 --> Model Class Initialized
DEBUG - 2011-05-03 17:58:35 --> Model Class Initialized
DEBUG - 2011-05-03 17:58:35 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-05-03 17:58:35 --> Database Driver Class Initialized
DEBUG - 2011-05-03 17:58:35 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-05-03 17:58:35 --> Helper loaded: url_helper
DEBUG - 2011-05-03 17:58:35 --> File loaded: application/views/common/header.php
DEBUG - 2011-05-03 17:58:35 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-05-03 17:58:35 --> File loaded: application/views/common/footer.php
DEBUG - 2011-05-03 17:58:35 --> File loaded: application/views/layout/main.php
DEBUG - 2011-05-03 17:58:35 --> Final output sent to browser
DEBUG - 2011-05-03 17:58:35 --> Total execution time: 0.0583
DEBUG - 2011-05-03 17:58:36 --> Final output sent to browser
DEBUG - 2011-05-03 17:58:36 --> Total execution time: 0.7028
DEBUG - 2011-05-03 17:58:37 --> Config Class Initialized
DEBUG - 2011-05-03 17:58:37 --> Hooks Class Initialized
DEBUG - 2011-05-03 17:58:37 --> Utf8 Class Initialized
DEBUG - 2011-05-03 17:58:37 --> UTF-8 Support Enabled
DEBUG - 2011-05-03 17:58:37 --> URI Class Initialized
DEBUG - 2011-05-03 17:58:37 --> Router Class Initialized
ERROR - 2011-05-03 17:58:37 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-05-03 18:02:29 --> Config Class Initialized
DEBUG - 2011-05-03 18:02:29 --> Hooks Class Initialized
DEBUG - 2011-05-03 18:02:29 --> Utf8 Class Initialized
DEBUG - 2011-05-03 18:02:29 --> UTF-8 Support Enabled
DEBUG - 2011-05-03 18:02:29 --> URI Class Initialized
DEBUG - 2011-05-03 18:02:29 --> Router Class Initialized
DEBUG - 2011-05-03 18:02:29 --> Output Class Initialized
DEBUG - 2011-05-03 18:02:29 --> Input Class Initialized
DEBUG - 2011-05-03 18:02:29 --> Global POST and COOKIE data sanitized
DEBUG - 2011-05-03 18:02:29 --> Language Class Initialized
DEBUG - 2011-05-03 18:02:29 --> Loader Class Initialized
DEBUG - 2011-05-03 18:02:29 --> Controller Class Initialized
ERROR - 2011-05-03 18:02:29 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-05-03 18:02:29 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-05-03 18:02:29 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-05-03 18:02:29 --> Model Class Initialized
DEBUG - 2011-05-03 18:02:29 --> Model Class Initialized
DEBUG - 2011-05-03 18:02:29 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-05-03 18:02:29 --> Database Driver Class Initialized
DEBUG - 2011-05-03 18:02:29 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-05-03 18:02:29 --> Helper loaded: url_helper
DEBUG - 2011-05-03 18:02:29 --> File loaded: application/views/common/header.php
DEBUG - 2011-05-03 18:02:29 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-05-03 18:02:29 --> File loaded: application/views/common/footer.php
DEBUG - 2011-05-03 18:02:29 --> File loaded: application/views/layout/main.php
DEBUG - 2011-05-03 18:02:29 --> Final output sent to browser
DEBUG - 2011-05-03 18:02:29 --> Total execution time: 0.0374
DEBUG - 2011-05-03 18:02:30 --> Config Class Initialized
DEBUG - 2011-05-03 18:02:30 --> Hooks Class Initialized
DEBUG - 2011-05-03 18:02:30 --> Utf8 Class Initialized
DEBUG - 2011-05-03 18:02:30 --> UTF-8 Support Enabled
DEBUG - 2011-05-03 18:02:30 --> URI Class Initialized
DEBUG - 2011-05-03 18:02:30 --> Router Class Initialized
ERROR - 2011-05-03 18:02:30 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-05-03 18:02:30 --> Config Class Initialized
DEBUG - 2011-05-03 18:02:30 --> Hooks Class Initialized
DEBUG - 2011-05-03 18:02:30 --> Utf8 Class Initialized
DEBUG - 2011-05-03 18:02:30 --> UTF-8 Support Enabled
DEBUG - 2011-05-03 18:02:30 --> URI Class Initialized
DEBUG - 2011-05-03 18:02:30 --> Router Class Initialized
DEBUG - 2011-05-03 18:02:30 --> Output Class Initialized
DEBUG - 2011-05-03 18:02:30 --> Input Class Initialized
DEBUG - 2011-05-03 18:02:30 --> Global POST and COOKIE data sanitized
DEBUG - 2011-05-03 18:02:30 --> Language Class Initialized
DEBUG - 2011-05-03 18:02:30 --> Loader Class Initialized
DEBUG - 2011-05-03 18:02:30 --> Controller Class Initialized
DEBUG - 2011-05-03 18:02:30 --> Model Class Initialized
DEBUG - 2011-05-03 18:02:30 --> Model Class Initialized
DEBUG - 2011-05-03 18:02:30 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-05-03 18:02:30 --> Database Driver Class Initialized
DEBUG - 2011-05-03 18:02:31 --> Final output sent to browser
DEBUG - 2011-05-03 18:02:31 --> Total execution time: 0.5604
DEBUG - 2011-05-03 23:44:29 --> Config Class Initialized
DEBUG - 2011-05-03 23:44:30 --> Hooks Class Initialized
DEBUG - 2011-05-03 23:44:30 --> Utf8 Class Initialized
DEBUG - 2011-05-03 23:44:30 --> UTF-8 Support Enabled
DEBUG - 2011-05-03 23:44:30 --> URI Class Initialized
DEBUG - 2011-05-03 23:44:30 --> Router Class Initialized
DEBUG - 2011-05-03 23:44:30 --> No URI present. Default controller set.
DEBUG - 2011-05-03 23:44:30 --> Output Class Initialized
DEBUG - 2011-05-03 23:44:30 --> Input Class Initialized
DEBUG - 2011-05-03 23:47:35 --> Config Class Initialized
DEBUG - 2011-05-03 23:47:35 --> Hooks Class Initialized
DEBUG - 2011-05-03 23:47:35 --> Utf8 Class Initialized
DEBUG - 2011-05-03 23:47:35 --> UTF-8 Support Enabled
DEBUG - 2011-05-03 23:47:35 --> URI Class Initialized
DEBUG - 2011-05-03 23:47:35 --> Router Class Initialized
DEBUG - 2011-05-03 23:47:35 --> Output Class Initialized
DEBUG - 2011-05-03 23:47:35 --> Input Class Initialized
DEBUG - 2011-05-03 23:47:35 --> Global POST and COOKIE data sanitized
DEBUG - 2011-05-03 23:47:35 --> Language Class Initialized
DEBUG - 2011-05-03 23:47:35 --> Loader Class Initialized
DEBUG - 2011-05-03 23:47:35 --> Controller Class Initialized
ERROR - 2011-05-03 23:47:35 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-05-03 23:47:35 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-05-03 23:47:35 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-05-03 23:47:35 --> Model Class Initialized
DEBUG - 2011-05-03 23:47:35 --> Model Class Initialized
DEBUG - 2011-05-03 23:47:35 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-05-03 23:47:35 --> Database Driver Class Initialized
DEBUG - 2011-05-03 23:47:35 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-05-03 23:47:35 --> Helper loaded: url_helper
DEBUG - 2011-05-03 23:47:35 --> File loaded: application/views/common/header.php
DEBUG - 2011-05-03 23:47:35 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-05-03 23:47:35 --> File loaded: application/views/common/footer.php
DEBUG - 2011-05-03 23:47:35 --> File loaded: application/views/layout/main.php
DEBUG - 2011-05-03 23:47:35 --> Final output sent to browser
DEBUG - 2011-05-03 23:47:35 --> Total execution time: 0.2897
DEBUG - 2011-05-03 23:47:41 --> Config Class Initialized
DEBUG - 2011-05-03 23:47:41 --> Hooks Class Initialized
DEBUG - 2011-05-03 23:47:41 --> Utf8 Class Initialized
DEBUG - 2011-05-03 23:47:41 --> UTF-8 Support Enabled
DEBUG - 2011-05-03 23:47:41 --> URI Class Initialized
DEBUG - 2011-05-03 23:47:41 --> Router Class Initialized
DEBUG - 2011-05-03 23:47:41 --> Output Class Initialized
DEBUG - 2011-05-03 23:47:41 --> Input Class Initialized
DEBUG - 2011-05-03 23:47:41 --> Global POST and COOKIE data sanitized
DEBUG - 2011-05-03 23:47:41 --> Language Class Initialized
DEBUG - 2011-05-03 23:47:41 --> Loader Class Initialized
DEBUG - 2011-05-03 23:47:41 --> Controller Class Initialized
DEBUG - 2011-05-03 23:47:41 --> Model Class Initialized
DEBUG - 2011-05-03 23:47:41 --> Model Class Initialized
DEBUG - 2011-05-03 23:47:41 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-05-03 23:47:41 --> Database Driver Class Initialized
DEBUG - 2011-05-03 23:47:42 --> Final output sent to browser
DEBUG - 2011-05-03 23:47:42 --> Total execution time: 0.8065

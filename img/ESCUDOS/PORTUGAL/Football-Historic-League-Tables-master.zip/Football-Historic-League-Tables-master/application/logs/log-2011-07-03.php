<?php  if ( ! defined('BASEPATH')) exit('No direct script access allowed'); ?>

DEBUG - 2011-07-03 00:17:54 --> Config Class Initialized
DEBUG - 2011-07-03 00:17:54 --> Hooks Class Initialized
DEBUG - 2011-07-03 00:17:54 --> Utf8 Class Initialized
DEBUG - 2011-07-03 00:17:54 --> UTF-8 Support Enabled
DEBUG - 2011-07-03 00:17:54 --> URI Class Initialized
DEBUG - 2011-07-03 00:17:54 --> Router Class Initialized
ERROR - 2011-07-03 00:17:54 --> 404 Page Not Found --> robots.txt
DEBUG - 2011-07-03 00:17:55 --> Config Class Initialized
DEBUG - 2011-07-03 00:17:55 --> Hooks Class Initialized
DEBUG - 2011-07-03 00:17:55 --> Utf8 Class Initialized
DEBUG - 2011-07-03 00:17:55 --> UTF-8 Support Enabled
DEBUG - 2011-07-03 00:17:55 --> URI Class Initialized
DEBUG - 2011-07-03 00:17:55 --> Router Class Initialized
DEBUG - 2011-07-03 00:17:55 --> Output Class Initialized
DEBUG - 2011-07-03 00:17:55 --> Input Class Initialized
DEBUG - 2011-07-03 00:17:55 --> Global POST and COOKIE data sanitized
DEBUG - 2011-07-03 00:17:55 --> Language Class Initialized
DEBUG - 2011-07-03 00:17:55 --> Loader Class Initialized
DEBUG - 2011-07-03 00:17:55 --> Controller Class Initialized
ERROR - 2011-07-03 00:17:55 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-07-03 00:17:55 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-07-03 00:17:55 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-07-03 00:17:55 --> Model Class Initialized
DEBUG - 2011-07-03 00:17:55 --> Model Class Initialized
DEBUG - 2011-07-03 00:17:55 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-07-03 00:17:56 --> Database Driver Class Initialized
DEBUG - 2011-07-03 00:17:56 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-07-03 00:17:56 --> Helper loaded: url_helper
DEBUG - 2011-07-03 00:17:56 --> File loaded: application/views/common/header.php
DEBUG - 2011-07-03 00:17:56 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-07-03 00:17:56 --> File loaded: application/views/common/footer.php
DEBUG - 2011-07-03 00:17:56 --> File loaded: application/views/layout/main.php
DEBUG - 2011-07-03 00:17:56 --> Final output sent to browser
DEBUG - 2011-07-03 00:17:56 --> Total execution time: 0.3032
DEBUG - 2011-07-03 00:17:57 --> Config Class Initialized
DEBUG - 2011-07-03 00:17:57 --> Hooks Class Initialized
DEBUG - 2011-07-03 00:17:57 --> Utf8 Class Initialized
DEBUG - 2011-07-03 00:17:57 --> UTF-8 Support Enabled
DEBUG - 2011-07-03 00:17:57 --> URI Class Initialized
DEBUG - 2011-07-03 00:17:57 --> Router Class Initialized
DEBUG - 2011-07-03 00:17:57 --> Output Class Initialized
DEBUG - 2011-07-03 00:17:57 --> Input Class Initialized
DEBUG - 2011-07-03 00:17:57 --> Global POST and COOKIE data sanitized
DEBUG - 2011-07-03 00:17:57 --> Language Class Initialized
DEBUG - 2011-07-03 00:17:57 --> Loader Class Initialized
DEBUG - 2011-07-03 00:17:57 --> Controller Class Initialized
DEBUG - 2011-07-03 00:17:58 --> Model Class Initialized
DEBUG - 2011-07-03 00:17:58 --> Model Class Initialized
DEBUG - 2011-07-03 00:17:58 --> Model Class Initialized
DEBUG - 2011-07-03 00:17:58 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-07-03 00:17:58 --> Database Driver Class Initialized
DEBUG - 2011-07-03 00:17:58 --> File loaded: application/views/table/main.php
DEBUG - 2011-07-03 00:17:58 --> Helper loaded: url_helper
DEBUG - 2011-07-03 00:17:58 --> File loaded: application/views/common/header.php
DEBUG - 2011-07-03 00:17:58 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-07-03 00:17:58 --> File loaded: application/views/common/footer.php
DEBUG - 2011-07-03 00:17:58 --> File loaded: application/views/layout/main.php
DEBUG - 2011-07-03 00:17:58 --> Final output sent to browser
DEBUG - 2011-07-03 00:17:58 --> Total execution time: 0.3553
DEBUG - 2011-07-03 01:34:01 --> Config Class Initialized
DEBUG - 2011-07-03 01:34:01 --> Hooks Class Initialized
DEBUG - 2011-07-03 01:34:01 --> Utf8 Class Initialized
DEBUG - 2011-07-03 01:34:01 --> UTF-8 Support Enabled
DEBUG - 2011-07-03 01:34:01 --> URI Class Initialized
DEBUG - 2011-07-03 01:34:01 --> Router Class Initialized
DEBUG - 2011-07-03 01:34:01 --> Output Class Initialized
DEBUG - 2011-07-03 01:34:01 --> Input Class Initialized
DEBUG - 2011-07-03 01:34:01 --> Global POST and COOKIE data sanitized
DEBUG - 2011-07-03 01:34:01 --> Language Class Initialized
DEBUG - 2011-07-03 01:34:01 --> Loader Class Initialized
DEBUG - 2011-07-03 01:34:01 --> Controller Class Initialized
ERROR - 2011-07-03 01:34:01 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-07-03 01:34:01 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-07-03 01:34:01 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-07-03 01:34:01 --> Model Class Initialized
DEBUG - 2011-07-03 01:34:01 --> Model Class Initialized
DEBUG - 2011-07-03 01:34:01 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-07-03 01:34:01 --> Database Driver Class Initialized
DEBUG - 2011-07-03 01:34:01 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-07-03 01:34:01 --> Helper loaded: url_helper
DEBUG - 2011-07-03 01:34:01 --> File loaded: application/views/common/header.php
DEBUG - 2011-07-03 01:34:01 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-07-03 01:34:01 --> File loaded: application/views/common/footer.php
DEBUG - 2011-07-03 01:34:01 --> File loaded: application/views/layout/main.php
DEBUG - 2011-07-03 01:34:01 --> Final output sent to browser
DEBUG - 2011-07-03 01:34:01 --> Total execution time: 0.3091
DEBUG - 2011-07-03 01:34:02 --> Config Class Initialized
DEBUG - 2011-07-03 01:34:02 --> Hooks Class Initialized
DEBUG - 2011-07-03 01:34:02 --> Utf8 Class Initialized
DEBUG - 2011-07-03 01:34:02 --> UTF-8 Support Enabled
DEBUG - 2011-07-03 01:34:02 --> URI Class Initialized
DEBUG - 2011-07-03 01:34:02 --> Router Class Initialized
DEBUG - 2011-07-03 01:34:02 --> Output Class Initialized
DEBUG - 2011-07-03 01:34:02 --> Input Class Initialized
DEBUG - 2011-07-03 01:34:02 --> Global POST and COOKIE data sanitized
DEBUG - 2011-07-03 01:34:02 --> Language Class Initialized
DEBUG - 2011-07-03 01:34:02 --> Loader Class Initialized
DEBUG - 2011-07-03 01:34:02 --> Controller Class Initialized
DEBUG - 2011-07-03 01:34:02 --> Model Class Initialized
DEBUG - 2011-07-03 01:34:02 --> Model Class Initialized
DEBUG - 2011-07-03 01:34:02 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-07-03 01:34:02 --> Database Driver Class Initialized
DEBUG - 2011-07-03 01:34:02 --> Final output sent to browser
DEBUG - 2011-07-03 01:34:02 --> Total execution time: 0.6431
DEBUG - 2011-07-03 01:34:03 --> Config Class Initialized
DEBUG - 2011-07-03 01:34:03 --> Hooks Class Initialized
DEBUG - 2011-07-03 01:34:03 --> Utf8 Class Initialized
DEBUG - 2011-07-03 01:34:03 --> UTF-8 Support Enabled
DEBUG - 2011-07-03 01:34:03 --> URI Class Initialized
DEBUG - 2011-07-03 01:34:03 --> Router Class Initialized
ERROR - 2011-07-03 01:34:03 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-07-03 01:34:04 --> Config Class Initialized
DEBUG - 2011-07-03 01:34:04 --> Hooks Class Initialized
DEBUG - 2011-07-03 01:34:04 --> Utf8 Class Initialized
DEBUG - 2011-07-03 01:34:04 --> UTF-8 Support Enabled
DEBUG - 2011-07-03 01:34:04 --> URI Class Initialized
DEBUG - 2011-07-03 01:34:04 --> Router Class Initialized
ERROR - 2011-07-03 01:34:04 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-07-03 01:36:21 --> Config Class Initialized
DEBUG - 2011-07-03 01:36:21 --> Hooks Class Initialized
DEBUG - 2011-07-03 01:36:21 --> Utf8 Class Initialized
DEBUG - 2011-07-03 01:36:21 --> UTF-8 Support Enabled
DEBUG - 2011-07-03 01:36:21 --> URI Class Initialized
DEBUG - 2011-07-03 01:36:21 --> Router Class Initialized
DEBUG - 2011-07-03 01:36:21 --> Output Class Initialized
DEBUG - 2011-07-03 01:36:21 --> Input Class Initialized
DEBUG - 2011-07-03 01:36:21 --> Global POST and COOKIE data sanitized
DEBUG - 2011-07-03 01:36:21 --> Language Class Initialized
DEBUG - 2011-07-03 01:36:21 --> Loader Class Initialized
DEBUG - 2011-07-03 01:36:21 --> Controller Class Initialized
ERROR - 2011-07-03 01:36:21 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-07-03 01:36:21 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-07-03 01:36:21 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-07-03 01:36:21 --> Model Class Initialized
DEBUG - 2011-07-03 01:36:21 --> Model Class Initialized
DEBUG - 2011-07-03 01:36:21 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-07-03 01:36:21 --> Database Driver Class Initialized
DEBUG - 2011-07-03 01:36:21 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-07-03 01:36:21 --> Helper loaded: url_helper
DEBUG - 2011-07-03 01:36:21 --> File loaded: application/views/common/header.php
DEBUG - 2011-07-03 01:36:21 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-07-03 01:36:21 --> File loaded: application/views/common/footer.php
DEBUG - 2011-07-03 01:36:21 --> File loaded: application/views/layout/main.php
DEBUG - 2011-07-03 01:36:21 --> Final output sent to browser
DEBUG - 2011-07-03 01:36:21 --> Total execution time: 0.0413
DEBUG - 2011-07-03 04:34:58 --> Config Class Initialized
DEBUG - 2011-07-03 04:34:58 --> Hooks Class Initialized
DEBUG - 2011-07-03 04:34:58 --> Utf8 Class Initialized
DEBUG - 2011-07-03 04:34:58 --> UTF-8 Support Enabled
DEBUG - 2011-07-03 04:34:58 --> URI Class Initialized
DEBUG - 2011-07-03 04:34:58 --> Router Class Initialized
ERROR - 2011-07-03 04:34:58 --> 404 Page Not Found --> robots.txt
DEBUG - 2011-07-03 04:34:59 --> Config Class Initialized
DEBUG - 2011-07-03 04:34:59 --> Hooks Class Initialized
DEBUG - 2011-07-03 04:34:59 --> Utf8 Class Initialized
DEBUG - 2011-07-03 04:34:59 --> UTF-8 Support Enabled
DEBUG - 2011-07-03 04:34:59 --> URI Class Initialized
DEBUG - 2011-07-03 04:34:59 --> Router Class Initialized
DEBUG - 2011-07-03 04:34:59 --> No URI present. Default controller set.
DEBUG - 2011-07-03 04:34:59 --> Output Class Initialized
DEBUG - 2011-07-03 04:34:59 --> Input Class Initialized
DEBUG - 2011-07-03 04:34:59 --> Global POST and COOKIE data sanitized
DEBUG - 2011-07-03 04:34:59 --> Language Class Initialized
DEBUG - 2011-07-03 04:34:59 --> Loader Class Initialized
DEBUG - 2011-07-03 04:34:59 --> Controller Class Initialized
DEBUG - 2011-07-03 04:34:59 --> File loaded: application/views/splash/main.php
DEBUG - 2011-07-03 04:34:59 --> Helper loaded: url_helper
DEBUG - 2011-07-03 04:34:59 --> File loaded: application/views/common/header.php
DEBUG - 2011-07-03 04:34:59 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-07-03 04:34:59 --> File loaded: application/views/common/footer.php
DEBUG - 2011-07-03 04:34:59 --> File loaded: application/views/layout/main.php
DEBUG - 2011-07-03 04:34:59 --> Final output sent to browser
DEBUG - 2011-07-03 04:34:59 --> Total execution time: 0.1407
DEBUG - 2011-07-03 04:38:03 --> Config Class Initialized
DEBUG - 2011-07-03 04:38:03 --> Hooks Class Initialized
DEBUG - 2011-07-03 04:38:03 --> Utf8 Class Initialized
DEBUG - 2011-07-03 04:38:03 --> UTF-8 Support Enabled
DEBUG - 2011-07-03 04:38:03 --> URI Class Initialized
DEBUG - 2011-07-03 04:38:03 --> Router Class Initialized
DEBUG - 2011-07-03 04:38:03 --> Output Class Initialized
DEBUG - 2011-07-03 04:38:03 --> Input Class Initialized
DEBUG - 2011-07-03 04:38:03 --> Global POST and COOKIE data sanitized
DEBUG - 2011-07-03 04:38:03 --> Language Class Initialized
DEBUG - 2011-07-03 04:38:03 --> Loader Class Initialized
DEBUG - 2011-07-03 04:38:03 --> Controller Class Initialized
DEBUG - 2011-07-03 04:38:03 --> Model Class Initialized
DEBUG - 2011-07-03 04:38:03 --> Model Class Initialized
DEBUG - 2011-07-03 04:38:03 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-07-03 04:38:03 --> Database Driver Class Initialized
DEBUG - 2011-07-03 04:38:04 --> Final output sent to browser
DEBUG - 2011-07-03 04:38:04 --> Total execution time: 0.9607
DEBUG - 2011-07-03 05:16:17 --> Config Class Initialized
DEBUG - 2011-07-03 05:16:17 --> Hooks Class Initialized
DEBUG - 2011-07-03 05:16:17 --> Utf8 Class Initialized
DEBUG - 2011-07-03 05:16:17 --> UTF-8 Support Enabled
DEBUG - 2011-07-03 05:16:17 --> URI Class Initialized
DEBUG - 2011-07-03 05:16:17 --> Router Class Initialized
DEBUG - 2011-07-03 05:16:17 --> Output Class Initialized
DEBUG - 2011-07-03 05:16:17 --> Input Class Initialized
DEBUG - 2011-07-03 05:16:17 --> Global POST and COOKIE data sanitized
DEBUG - 2011-07-03 05:16:17 --> Language Class Initialized
DEBUG - 2011-07-03 05:16:17 --> Loader Class Initialized
DEBUG - 2011-07-03 05:16:17 --> Controller Class Initialized
ERROR - 2011-07-03 05:16:18 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-07-03 05:16:18 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-07-03 05:16:18 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-07-03 05:16:18 --> Model Class Initialized
DEBUG - 2011-07-03 05:16:18 --> Model Class Initialized
DEBUG - 2011-07-03 05:16:18 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-07-03 05:16:18 --> Database Driver Class Initialized
DEBUG - 2011-07-03 05:16:18 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-07-03 05:16:18 --> Helper loaded: url_helper
DEBUG - 2011-07-03 05:16:18 --> File loaded: application/views/common/header.php
DEBUG - 2011-07-03 05:16:18 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-07-03 05:16:18 --> File loaded: application/views/common/footer.php
DEBUG - 2011-07-03 05:16:18 --> File loaded: application/views/layout/main.php
DEBUG - 2011-07-03 05:16:18 --> Final output sent to browser
DEBUG - 2011-07-03 05:16:18 --> Total execution time: 0.7734
DEBUG - 2011-07-03 05:16:23 --> Config Class Initialized
DEBUG - 2011-07-03 05:16:23 --> Hooks Class Initialized
DEBUG - 2011-07-03 05:16:23 --> Utf8 Class Initialized
DEBUG - 2011-07-03 05:16:23 --> UTF-8 Support Enabled
DEBUG - 2011-07-03 05:16:23 --> URI Class Initialized
DEBUG - 2011-07-03 05:16:23 --> Router Class Initialized
DEBUG - 2011-07-03 05:16:23 --> Output Class Initialized
DEBUG - 2011-07-03 05:16:23 --> Input Class Initialized
DEBUG - 2011-07-03 05:16:23 --> Global POST and COOKIE data sanitized
DEBUG - 2011-07-03 05:16:23 --> Language Class Initialized
DEBUG - 2011-07-03 05:16:23 --> Loader Class Initialized
DEBUG - 2011-07-03 05:16:23 --> Controller Class Initialized
DEBUG - 2011-07-03 05:16:23 --> Model Class Initialized
DEBUG - 2011-07-03 05:16:23 --> Model Class Initialized
DEBUG - 2011-07-03 05:16:23 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-07-03 05:16:23 --> Database Driver Class Initialized
DEBUG - 2011-07-03 05:16:24 --> Final output sent to browser
DEBUG - 2011-07-03 05:16:24 --> Total execution time: 0.7620
DEBUG - 2011-07-03 05:16:29 --> Config Class Initialized
DEBUG - 2011-07-03 05:16:29 --> Hooks Class Initialized
DEBUG - 2011-07-03 05:16:29 --> Utf8 Class Initialized
DEBUG - 2011-07-03 05:16:29 --> UTF-8 Support Enabled
DEBUG - 2011-07-03 05:16:29 --> URI Class Initialized
DEBUG - 2011-07-03 05:16:29 --> Router Class Initialized
ERROR - 2011-07-03 05:16:29 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-07-03 06:28:25 --> Config Class Initialized
DEBUG - 2011-07-03 06:28:25 --> Hooks Class Initialized
DEBUG - 2011-07-03 06:28:25 --> Utf8 Class Initialized
DEBUG - 2011-07-03 06:28:25 --> UTF-8 Support Enabled
DEBUG - 2011-07-03 06:28:25 --> URI Class Initialized
DEBUG - 2011-07-03 06:28:25 --> Router Class Initialized
DEBUG - 2011-07-03 06:28:25 --> Output Class Initialized
DEBUG - 2011-07-03 06:28:25 --> Input Class Initialized
DEBUG - 2011-07-03 06:28:25 --> Global POST and COOKIE data sanitized
DEBUG - 2011-07-03 06:28:25 --> Language Class Initialized
DEBUG - 2011-07-03 06:28:25 --> Loader Class Initialized
DEBUG - 2011-07-03 06:28:25 --> Controller Class Initialized
ERROR - 2011-07-03 06:28:25 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-07-03 06:28:25 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-07-03 06:28:25 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-07-03 06:28:25 --> Model Class Initialized
DEBUG - 2011-07-03 06:28:25 --> Model Class Initialized
DEBUG - 2011-07-03 06:28:25 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-07-03 06:28:25 --> Database Driver Class Initialized
DEBUG - 2011-07-03 06:28:25 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-07-03 06:28:26 --> Helper loaded: url_helper
DEBUG - 2011-07-03 06:28:26 --> File loaded: application/views/common/header.php
DEBUG - 2011-07-03 06:28:26 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-07-03 06:28:26 --> File loaded: application/views/common/footer.php
DEBUG - 2011-07-03 06:28:26 --> File loaded: application/views/layout/main.php
DEBUG - 2011-07-03 06:28:26 --> Final output sent to browser
DEBUG - 2011-07-03 06:28:26 --> Total execution time: 0.3825
DEBUG - 2011-07-03 06:28:27 --> Config Class Initialized
DEBUG - 2011-07-03 06:28:27 --> Hooks Class Initialized
DEBUG - 2011-07-03 06:28:27 --> Utf8 Class Initialized
DEBUG - 2011-07-03 06:28:27 --> UTF-8 Support Enabled
DEBUG - 2011-07-03 06:28:27 --> URI Class Initialized
DEBUG - 2011-07-03 06:28:27 --> Router Class Initialized
DEBUG - 2011-07-03 06:28:27 --> Output Class Initialized
DEBUG - 2011-07-03 06:28:27 --> Input Class Initialized
DEBUG - 2011-07-03 06:28:27 --> Global POST and COOKIE data sanitized
DEBUG - 2011-07-03 06:28:27 --> Language Class Initialized
DEBUG - 2011-07-03 06:28:27 --> Loader Class Initialized
DEBUG - 2011-07-03 06:28:27 --> Controller Class Initialized
DEBUG - 2011-07-03 06:28:27 --> Model Class Initialized
DEBUG - 2011-07-03 06:28:27 --> Model Class Initialized
DEBUG - 2011-07-03 06:28:27 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-07-03 06:28:27 --> Database Driver Class Initialized
DEBUG - 2011-07-03 06:28:28 --> Final output sent to browser
DEBUG - 2011-07-03 06:28:28 --> Total execution time: 0.8218
DEBUG - 2011-07-03 06:28:32 --> Config Class Initialized
DEBUG - 2011-07-03 06:28:32 --> Hooks Class Initialized
DEBUG - 2011-07-03 06:28:32 --> Utf8 Class Initialized
DEBUG - 2011-07-03 06:28:32 --> UTF-8 Support Enabled
DEBUG - 2011-07-03 06:28:32 --> URI Class Initialized
DEBUG - 2011-07-03 06:28:32 --> Router Class Initialized
ERROR - 2011-07-03 06:28:32 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-07-03 11:34:25 --> Config Class Initialized
DEBUG - 2011-07-03 11:34:25 --> Hooks Class Initialized
DEBUG - 2011-07-03 11:34:26 --> Utf8 Class Initialized
DEBUG - 2011-07-03 11:34:26 --> UTF-8 Support Enabled
DEBUG - 2011-07-03 11:34:26 --> URI Class Initialized
DEBUG - 2011-07-03 11:34:26 --> Router Class Initialized
DEBUG - 2011-07-03 11:34:27 --> Output Class Initialized
DEBUG - 2011-07-03 11:34:27 --> Input Class Initialized
DEBUG - 2011-07-03 11:34:27 --> Global POST and COOKIE data sanitized
DEBUG - 2011-07-03 11:34:27 --> Language Class Initialized
DEBUG - 2011-07-03 11:34:27 --> Loader Class Initialized
DEBUG - 2011-07-03 11:34:27 --> Controller Class Initialized
ERROR - 2011-07-03 11:34:27 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-07-03 11:34:27 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-07-03 11:34:27 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-07-03 11:34:28 --> Model Class Initialized
DEBUG - 2011-07-03 11:34:28 --> Model Class Initialized
DEBUG - 2011-07-03 11:34:28 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-07-03 11:34:28 --> Database Driver Class Initialized
DEBUG - 2011-07-03 11:34:28 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-07-03 11:34:29 --> Helper loaded: url_helper
DEBUG - 2011-07-03 11:34:29 --> File loaded: application/views/common/header.php
DEBUG - 2011-07-03 11:34:29 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-07-03 11:34:29 --> File loaded: application/views/common/footer.php
DEBUG - 2011-07-03 11:34:29 --> File loaded: application/views/layout/main.php
DEBUG - 2011-07-03 11:34:29 --> Final output sent to browser
DEBUG - 2011-07-03 11:34:29 --> Total execution time: 4.9823
DEBUG - 2011-07-03 12:07:54 --> Config Class Initialized
DEBUG - 2011-07-03 12:07:54 --> Hooks Class Initialized
DEBUG - 2011-07-03 12:07:54 --> Utf8 Class Initialized
DEBUG - 2011-07-03 12:07:54 --> UTF-8 Support Enabled
DEBUG - 2011-07-03 12:07:54 --> URI Class Initialized
DEBUG - 2011-07-03 12:07:54 --> Router Class Initialized
DEBUG - 2011-07-03 12:07:54 --> Output Class Initialized
DEBUG - 2011-07-03 12:07:54 --> Input Class Initialized
DEBUG - 2011-07-03 12:07:54 --> Global POST and COOKIE data sanitized
DEBUG - 2011-07-03 12:07:54 --> Language Class Initialized
DEBUG - 2011-07-03 12:07:54 --> Loader Class Initialized
DEBUG - 2011-07-03 12:07:54 --> Controller Class Initialized
ERROR - 2011-07-03 12:07:54 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-07-03 12:07:54 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-07-03 12:07:54 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-07-03 12:07:54 --> Model Class Initialized
DEBUG - 2011-07-03 12:07:54 --> Model Class Initialized
DEBUG - 2011-07-03 12:07:54 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-07-03 12:07:54 --> Database Driver Class Initialized
DEBUG - 2011-07-03 12:07:54 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-07-03 12:07:54 --> Helper loaded: url_helper
DEBUG - 2011-07-03 12:07:54 --> File loaded: application/views/common/header.php
DEBUG - 2011-07-03 12:07:54 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-07-03 12:07:54 --> File loaded: application/views/common/footer.php
DEBUG - 2011-07-03 12:07:54 --> File loaded: application/views/layout/main.php
DEBUG - 2011-07-03 12:07:54 --> Final output sent to browser
DEBUG - 2011-07-03 12:07:54 --> Total execution time: 0.2064
DEBUG - 2011-07-03 12:07:56 --> Config Class Initialized
DEBUG - 2011-07-03 12:07:56 --> Hooks Class Initialized
DEBUG - 2011-07-03 12:07:56 --> Utf8 Class Initialized
DEBUG - 2011-07-03 12:07:56 --> UTF-8 Support Enabled
DEBUG - 2011-07-03 12:07:56 --> URI Class Initialized
DEBUG - 2011-07-03 12:07:56 --> Router Class Initialized
DEBUG - 2011-07-03 12:07:56 --> Output Class Initialized
DEBUG - 2011-07-03 12:07:56 --> Input Class Initialized
DEBUG - 2011-07-03 12:07:56 --> Global POST and COOKIE data sanitized
DEBUG - 2011-07-03 12:07:56 --> Language Class Initialized
DEBUG - 2011-07-03 12:07:56 --> Loader Class Initialized
DEBUG - 2011-07-03 12:07:56 --> Controller Class Initialized
DEBUG - 2011-07-03 12:07:56 --> Model Class Initialized
DEBUG - 2011-07-03 12:07:56 --> Model Class Initialized
DEBUG - 2011-07-03 12:07:56 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-07-03 12:07:56 --> Database Driver Class Initialized
DEBUG - 2011-07-03 12:07:56 --> Final output sent to browser
DEBUG - 2011-07-03 12:07:56 --> Total execution time: 0.6947
DEBUG - 2011-07-03 13:07:16 --> Config Class Initialized
DEBUG - 2011-07-03 13:07:16 --> Hooks Class Initialized
DEBUG - 2011-07-03 13:07:16 --> Utf8 Class Initialized
DEBUG - 2011-07-03 13:07:16 --> UTF-8 Support Enabled
DEBUG - 2011-07-03 13:07:16 --> URI Class Initialized
DEBUG - 2011-07-03 13:07:16 --> Router Class Initialized
ERROR - 2011-07-03 13:07:16 --> 404 Page Not Found --> robots.txt
DEBUG - 2011-07-03 13:07:17 --> Config Class Initialized
DEBUG - 2011-07-03 13:07:17 --> Hooks Class Initialized
DEBUG - 2011-07-03 13:07:17 --> Utf8 Class Initialized
DEBUG - 2011-07-03 13:07:17 --> UTF-8 Support Enabled
DEBUG - 2011-07-03 13:07:17 --> URI Class Initialized
DEBUG - 2011-07-03 13:07:17 --> Router Class Initialized
DEBUG - 2011-07-03 13:07:17 --> Output Class Initialized
DEBUG - 2011-07-03 13:07:17 --> Input Class Initialized
DEBUG - 2011-07-03 13:07:17 --> Global POST and COOKIE data sanitized
DEBUG - 2011-07-03 13:07:17 --> Language Class Initialized
DEBUG - 2011-07-03 13:07:17 --> Loader Class Initialized
DEBUG - 2011-07-03 13:07:17 --> Controller Class Initialized
DEBUG - 2011-07-03 13:07:17 --> Model Class Initialized
DEBUG - 2011-07-03 13:07:17 --> Model Class Initialized
DEBUG - 2011-07-03 13:07:17 --> Model Class Initialized
DEBUG - 2011-07-03 13:07:17 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-07-03 13:07:17 --> Database Driver Class Initialized
DEBUG - 2011-07-03 13:07:17 --> File loaded: application/views/table/main.php
DEBUG - 2011-07-03 13:07:17 --> Helper loaded: url_helper
DEBUG - 2011-07-03 13:07:17 --> File loaded: application/views/common/header.php
DEBUG - 2011-07-03 13:07:17 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-07-03 13:07:17 --> File loaded: application/views/common/footer.php
DEBUG - 2011-07-03 13:07:17 --> File loaded: application/views/layout/main.php
DEBUG - 2011-07-03 13:07:17 --> Final output sent to browser
DEBUG - 2011-07-03 13:07:17 --> Total execution time: 0.6960
DEBUG - 2011-07-03 13:56:59 --> Config Class Initialized
DEBUG - 2011-07-03 13:56:59 --> Hooks Class Initialized
DEBUG - 2011-07-03 13:56:59 --> Utf8 Class Initialized
DEBUG - 2011-07-03 13:56:59 --> UTF-8 Support Enabled
DEBUG - 2011-07-03 13:56:59 --> URI Class Initialized
DEBUG - 2011-07-03 13:56:59 --> Router Class Initialized
DEBUG - 2011-07-03 13:56:59 --> Output Class Initialized
DEBUG - 2011-07-03 13:56:59 --> Input Class Initialized
DEBUG - 2011-07-03 13:56:59 --> Global POST and COOKIE data sanitized
DEBUG - 2011-07-03 13:56:59 --> Language Class Initialized
DEBUG - 2011-07-03 13:56:59 --> Loader Class Initialized
DEBUG - 2011-07-03 13:56:59 --> Controller Class Initialized
DEBUG - 2011-07-03 13:56:59 --> Model Class Initialized
DEBUG - 2011-07-03 13:56:59 --> Model Class Initialized
DEBUG - 2011-07-03 13:56:59 --> Model Class Initialized
DEBUG - 2011-07-03 13:56:59 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-07-03 13:56:59 --> Database Driver Class Initialized
DEBUG - 2011-07-03 13:56:59 --> File loaded: application/views/table/main.php
DEBUG - 2011-07-03 13:56:59 --> Helper loaded: url_helper
DEBUG - 2011-07-03 13:56:59 --> File loaded: application/views/common/header.php
DEBUG - 2011-07-03 13:56:59 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-07-03 13:56:59 --> File loaded: application/views/common/footer.php
DEBUG - 2011-07-03 13:56:59 --> File loaded: application/views/layout/main.php
DEBUG - 2011-07-03 13:56:59 --> Final output sent to browser
DEBUG - 2011-07-03 13:56:59 --> Total execution time: 0.6562
DEBUG - 2011-07-03 13:57:36 --> Config Class Initialized
DEBUG - 2011-07-03 13:57:36 --> Hooks Class Initialized
DEBUG - 2011-07-03 13:57:36 --> Utf8 Class Initialized
DEBUG - 2011-07-03 13:57:36 --> UTF-8 Support Enabled
DEBUG - 2011-07-03 13:57:36 --> URI Class Initialized
DEBUG - 2011-07-03 13:57:36 --> Router Class Initialized
DEBUG - 2011-07-03 13:57:36 --> Output Class Initialized
DEBUG - 2011-07-03 13:57:36 --> Input Class Initialized
DEBUG - 2011-07-03 13:57:36 --> Global POST and COOKIE data sanitized
DEBUG - 2011-07-03 13:57:36 --> Language Class Initialized
DEBUG - 2011-07-03 13:57:36 --> Loader Class Initialized
DEBUG - 2011-07-03 13:57:36 --> Controller Class Initialized
ERROR - 2011-07-03 13:57:36 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-07-03 13:57:36 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-07-03 13:57:36 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-07-03 13:57:36 --> Model Class Initialized
DEBUG - 2011-07-03 13:57:36 --> Model Class Initialized
DEBUG - 2011-07-03 13:57:36 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-07-03 13:57:36 --> Database Driver Class Initialized
DEBUG - 2011-07-03 13:57:36 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-07-03 13:57:36 --> Helper loaded: url_helper
DEBUG - 2011-07-03 13:57:36 --> File loaded: application/views/common/header.php
DEBUG - 2011-07-03 13:57:36 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-07-03 13:57:36 --> File loaded: application/views/common/footer.php
DEBUG - 2011-07-03 13:57:36 --> File loaded: application/views/layout/main.php
DEBUG - 2011-07-03 13:57:36 --> Final output sent to browser
DEBUG - 2011-07-03 13:57:36 --> Total execution time: 0.7339
DEBUG - 2011-07-03 14:24:32 --> Config Class Initialized
DEBUG - 2011-07-03 14:24:32 --> Hooks Class Initialized
DEBUG - 2011-07-03 14:24:32 --> Utf8 Class Initialized
DEBUG - 2011-07-03 14:24:32 --> UTF-8 Support Enabled
DEBUG - 2011-07-03 14:24:32 --> URI Class Initialized
DEBUG - 2011-07-03 14:24:32 --> Router Class Initialized
DEBUG - 2011-07-03 14:24:32 --> Output Class Initialized
DEBUG - 2011-07-03 14:24:32 --> Input Class Initialized
DEBUG - 2011-07-03 14:24:32 --> Global POST and COOKIE data sanitized
DEBUG - 2011-07-03 14:24:32 --> Language Class Initialized
DEBUG - 2011-07-03 14:24:32 --> Loader Class Initialized
DEBUG - 2011-07-03 14:24:32 --> Controller Class Initialized
ERROR - 2011-07-03 14:24:32 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-07-03 14:24:32 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-07-03 14:24:32 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-07-03 14:24:32 --> Model Class Initialized
DEBUG - 2011-07-03 14:24:32 --> Model Class Initialized
DEBUG - 2011-07-03 14:24:32 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-07-03 14:24:32 --> Database Driver Class Initialized
DEBUG - 2011-07-03 14:24:32 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-07-03 14:24:32 --> Helper loaded: url_helper
DEBUG - 2011-07-03 14:24:32 --> File loaded: application/views/common/header.php
DEBUG - 2011-07-03 14:24:32 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-07-03 14:24:32 --> File loaded: application/views/common/footer.php
DEBUG - 2011-07-03 14:24:32 --> File loaded: application/views/layout/main.php
DEBUG - 2011-07-03 14:24:32 --> Final output sent to browser
DEBUG - 2011-07-03 14:24:32 --> Total execution time: 0.1242
DEBUG - 2011-07-03 14:24:35 --> Config Class Initialized
DEBUG - 2011-07-03 14:24:35 --> Hooks Class Initialized
DEBUG - 2011-07-03 14:24:35 --> Utf8 Class Initialized
DEBUG - 2011-07-03 14:24:35 --> UTF-8 Support Enabled
DEBUG - 2011-07-03 14:24:35 --> URI Class Initialized
DEBUG - 2011-07-03 14:24:35 --> Router Class Initialized
DEBUG - 2011-07-03 14:24:35 --> Output Class Initialized
DEBUG - 2011-07-03 14:24:35 --> Input Class Initialized
DEBUG - 2011-07-03 14:24:35 --> Global POST and COOKIE data sanitized
DEBUG - 2011-07-03 14:24:35 --> Language Class Initialized
DEBUG - 2011-07-03 14:24:35 --> Loader Class Initialized
DEBUG - 2011-07-03 14:24:35 --> Controller Class Initialized
DEBUG - 2011-07-03 14:24:35 --> Model Class Initialized
DEBUG - 2011-07-03 14:24:35 --> Model Class Initialized
DEBUG - 2011-07-03 14:24:35 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-07-03 14:24:35 --> Database Driver Class Initialized
DEBUG - 2011-07-03 14:24:35 --> Final output sent to browser
DEBUG - 2011-07-03 14:24:35 --> Total execution time: 0.8324
DEBUG - 2011-07-03 14:24:37 --> Config Class Initialized
DEBUG - 2011-07-03 14:24:37 --> Hooks Class Initialized
DEBUG - 2011-07-03 14:24:37 --> Utf8 Class Initialized
DEBUG - 2011-07-03 14:24:37 --> UTF-8 Support Enabled
DEBUG - 2011-07-03 14:24:37 --> URI Class Initialized
DEBUG - 2011-07-03 14:24:37 --> Router Class Initialized
ERROR - 2011-07-03 14:24:37 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-07-03 15:07:11 --> Config Class Initialized
DEBUG - 2011-07-03 15:07:11 --> Hooks Class Initialized
DEBUG - 2011-07-03 15:07:11 --> Utf8 Class Initialized
DEBUG - 2011-07-03 15:07:11 --> UTF-8 Support Enabled
DEBUG - 2011-07-03 15:07:11 --> URI Class Initialized
DEBUG - 2011-07-03 15:07:11 --> Router Class Initialized
DEBUG - 2011-07-03 15:07:11 --> Output Class Initialized
DEBUG - 2011-07-03 15:07:11 --> Input Class Initialized
DEBUG - 2011-07-03 15:07:11 --> Global POST and COOKIE data sanitized
DEBUG - 2011-07-03 15:07:11 --> Language Class Initialized
DEBUG - 2011-07-03 15:07:11 --> Loader Class Initialized
DEBUG - 2011-07-03 15:07:11 --> Controller Class Initialized
DEBUG - 2011-07-03 15:07:11 --> Model Class Initialized
DEBUG - 2011-07-03 15:07:11 --> Model Class Initialized
DEBUG - 2011-07-03 15:07:11 --> Model Class Initialized
DEBUG - 2011-07-03 15:07:11 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-07-03 15:07:11 --> Database Driver Class Initialized
DEBUG - 2011-07-03 15:07:11 --> File loaded: application/views/table/main.php
DEBUG - 2011-07-03 15:07:11 --> Helper loaded: url_helper
DEBUG - 2011-07-03 15:07:11 --> File loaded: application/views/common/header.php
DEBUG - 2011-07-03 15:07:11 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-07-03 15:07:11 --> File loaded: application/views/common/footer.php
DEBUG - 2011-07-03 15:07:11 --> File loaded: application/views/layout/main.php
DEBUG - 2011-07-03 15:07:11 --> Final output sent to browser
DEBUG - 2011-07-03 15:07:11 --> Total execution time: 0.4996
DEBUG - 2011-07-03 15:07:14 --> Config Class Initialized
DEBUG - 2011-07-03 15:07:14 --> Hooks Class Initialized
DEBUG - 2011-07-03 15:07:14 --> Utf8 Class Initialized
DEBUG - 2011-07-03 15:07:14 --> UTF-8 Support Enabled
DEBUG - 2011-07-03 15:07:14 --> URI Class Initialized
DEBUG - 2011-07-03 15:07:14 --> Router Class Initialized
ERROR - 2011-07-03 15:07:14 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-07-03 15:07:14 --> Config Class Initialized
DEBUG - 2011-07-03 15:07:14 --> Hooks Class Initialized
DEBUG - 2011-07-03 15:07:14 --> Utf8 Class Initialized
DEBUG - 2011-07-03 15:07:14 --> UTF-8 Support Enabled
DEBUG - 2011-07-03 15:07:14 --> URI Class Initialized
DEBUG - 2011-07-03 15:07:14 --> Router Class Initialized
ERROR - 2011-07-03 15:07:14 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-07-03 15:07:16 --> Config Class Initialized
DEBUG - 2011-07-03 15:07:16 --> Hooks Class Initialized
DEBUG - 2011-07-03 15:07:16 --> Utf8 Class Initialized
DEBUG - 2011-07-03 15:07:16 --> UTF-8 Support Enabled
DEBUG - 2011-07-03 15:07:16 --> URI Class Initialized
DEBUG - 2011-07-03 15:07:16 --> Router Class Initialized
ERROR - 2011-07-03 15:07:16 --> 404 Page Not Found --> robots.txt
DEBUG - 2011-07-03 15:07:16 --> Config Class Initialized
DEBUG - 2011-07-03 15:07:16 --> Hooks Class Initialized
DEBUG - 2011-07-03 15:07:16 --> Utf8 Class Initialized
DEBUG - 2011-07-03 15:07:16 --> UTF-8 Support Enabled
DEBUG - 2011-07-03 15:07:16 --> URI Class Initialized
DEBUG - 2011-07-03 15:07:16 --> Router Class Initialized
DEBUG - 2011-07-03 15:07:16 --> Output Class Initialized
DEBUG - 2011-07-03 15:07:16 --> Input Class Initialized
DEBUG - 2011-07-03 15:07:16 --> Global POST and COOKIE data sanitized
DEBUG - 2011-07-03 15:07:16 --> Language Class Initialized
DEBUG - 2011-07-03 15:07:16 --> Loader Class Initialized
DEBUG - 2011-07-03 15:07:16 --> Controller Class Initialized
DEBUG - 2011-07-03 15:07:16 --> Model Class Initialized
DEBUG - 2011-07-03 15:07:16 --> Model Class Initialized
DEBUG - 2011-07-03 15:07:16 --> Model Class Initialized
DEBUG - 2011-07-03 15:07:16 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-07-03 15:07:16 --> Database Driver Class Initialized
DEBUG - 2011-07-03 15:07:16 --> File loaded: application/views/table/main.php
DEBUG - 2011-07-03 15:07:16 --> Helper loaded: url_helper
DEBUG - 2011-07-03 15:07:16 --> File loaded: application/views/common/header.php
DEBUG - 2011-07-03 15:07:16 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-07-03 15:07:16 --> File loaded: application/views/common/footer.php
DEBUG - 2011-07-03 15:07:16 --> File loaded: application/views/layout/main.php
DEBUG - 2011-07-03 15:07:16 --> Final output sent to browser
DEBUG - 2011-07-03 15:07:16 --> Total execution time: 0.0478
DEBUG - 2011-07-03 15:07:33 --> Config Class Initialized
DEBUG - 2011-07-03 15:07:33 --> Hooks Class Initialized
DEBUG - 2011-07-03 15:07:33 --> Utf8 Class Initialized
DEBUG - 2011-07-03 15:07:33 --> UTF-8 Support Enabled
DEBUG - 2011-07-03 15:07:33 --> URI Class Initialized
DEBUG - 2011-07-03 15:07:33 --> Router Class Initialized
DEBUG - 2011-07-03 15:07:33 --> Output Class Initialized
DEBUG - 2011-07-03 15:07:33 --> Input Class Initialized
DEBUG - 2011-07-03 15:07:33 --> Global POST and COOKIE data sanitized
DEBUG - 2011-07-03 15:07:33 --> Language Class Initialized
DEBUG - 2011-07-03 15:07:33 --> Loader Class Initialized
DEBUG - 2011-07-03 15:07:33 --> Controller Class Initialized
DEBUG - 2011-07-03 15:07:33 --> Model Class Initialized
DEBUG - 2011-07-03 15:07:33 --> Model Class Initialized
DEBUG - 2011-07-03 15:07:33 --> Model Class Initialized
DEBUG - 2011-07-03 15:07:33 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-07-03 15:07:33 --> Database Driver Class Initialized
DEBUG - 2011-07-03 15:07:33 --> File loaded: application/views/table/main.php
DEBUG - 2011-07-03 15:07:33 --> Helper loaded: url_helper
DEBUG - 2011-07-03 15:07:33 --> File loaded: application/views/common/header.php
DEBUG - 2011-07-03 15:07:33 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-07-03 15:07:33 --> File loaded: application/views/common/footer.php
DEBUG - 2011-07-03 15:07:33 --> File loaded: application/views/layout/main.php
DEBUG - 2011-07-03 15:07:33 --> Final output sent to browser
DEBUG - 2011-07-03 15:07:33 --> Total execution time: 0.3309
DEBUG - 2011-07-03 15:08:15 --> Config Class Initialized
DEBUG - 2011-07-03 15:08:15 --> Hooks Class Initialized
DEBUG - 2011-07-03 15:08:15 --> Utf8 Class Initialized
DEBUG - 2011-07-03 15:08:15 --> UTF-8 Support Enabled
DEBUG - 2011-07-03 15:08:15 --> URI Class Initialized
DEBUG - 2011-07-03 15:08:15 --> Router Class Initialized
DEBUG - 2011-07-03 15:08:15 --> Output Class Initialized
DEBUG - 2011-07-03 15:08:15 --> Input Class Initialized
DEBUG - 2011-07-03 15:08:15 --> Global POST and COOKIE data sanitized
DEBUG - 2011-07-03 15:08:15 --> Language Class Initialized
DEBUG - 2011-07-03 15:08:15 --> Loader Class Initialized
DEBUG - 2011-07-03 15:08:15 --> Controller Class Initialized
DEBUG - 2011-07-03 15:08:15 --> Model Class Initialized
DEBUG - 2011-07-03 15:08:15 --> Model Class Initialized
DEBUG - 2011-07-03 15:08:15 --> Model Class Initialized
DEBUG - 2011-07-03 15:08:15 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-07-03 15:08:15 --> Database Driver Class Initialized
DEBUG - 2011-07-03 15:08:15 --> File loaded: application/views/table/main.php
DEBUG - 2011-07-03 15:08:15 --> Helper loaded: url_helper
DEBUG - 2011-07-03 15:08:15 --> File loaded: application/views/common/header.php
DEBUG - 2011-07-03 15:08:15 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-07-03 15:08:15 --> File loaded: application/views/common/footer.php
DEBUG - 2011-07-03 15:08:15 --> File loaded: application/views/layout/main.php
DEBUG - 2011-07-03 15:08:15 --> Final output sent to browser
DEBUG - 2011-07-03 15:08:15 --> Total execution time: 0.0440
DEBUG - 2011-07-03 15:08:17 --> Config Class Initialized
DEBUG - 2011-07-03 15:08:17 --> Hooks Class Initialized
DEBUG - 2011-07-03 15:08:17 --> Utf8 Class Initialized
DEBUG - 2011-07-03 15:08:17 --> UTF-8 Support Enabled
DEBUG - 2011-07-03 15:08:17 --> URI Class Initialized
DEBUG - 2011-07-03 15:08:17 --> Router Class Initialized
DEBUG - 2011-07-03 15:08:17 --> Output Class Initialized
DEBUG - 2011-07-03 15:08:17 --> Input Class Initialized
DEBUG - 2011-07-03 15:08:17 --> Global POST and COOKIE data sanitized
DEBUG - 2011-07-03 15:08:17 --> Language Class Initialized
DEBUG - 2011-07-03 15:08:17 --> Loader Class Initialized
DEBUG - 2011-07-03 15:08:17 --> Controller Class Initialized
DEBUG - 2011-07-03 15:08:17 --> Model Class Initialized
DEBUG - 2011-07-03 15:08:17 --> Model Class Initialized
DEBUG - 2011-07-03 15:08:17 --> Model Class Initialized
DEBUG - 2011-07-03 15:08:17 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-07-03 15:08:17 --> Database Driver Class Initialized
DEBUG - 2011-07-03 15:08:17 --> File loaded: application/views/table/main.php
DEBUG - 2011-07-03 15:08:17 --> Helper loaded: url_helper
DEBUG - 2011-07-03 15:08:17 --> File loaded: application/views/common/header.php
DEBUG - 2011-07-03 15:08:17 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-07-03 15:08:17 --> File loaded: application/views/common/footer.php
DEBUG - 2011-07-03 15:08:17 --> File loaded: application/views/layout/main.php
DEBUG - 2011-07-03 15:08:17 --> Final output sent to browser
DEBUG - 2011-07-03 15:08:17 --> Total execution time: 0.0418
DEBUG - 2011-07-03 15:08:57 --> Config Class Initialized
DEBUG - 2011-07-03 15:08:57 --> Hooks Class Initialized
DEBUG - 2011-07-03 15:08:57 --> Utf8 Class Initialized
DEBUG - 2011-07-03 15:08:57 --> UTF-8 Support Enabled
DEBUG - 2011-07-03 15:08:57 --> URI Class Initialized
DEBUG - 2011-07-03 15:08:57 --> Router Class Initialized
DEBUG - 2011-07-03 15:08:57 --> Output Class Initialized
DEBUG - 2011-07-03 15:08:57 --> Input Class Initialized
DEBUG - 2011-07-03 15:08:57 --> Global POST and COOKIE data sanitized
DEBUG - 2011-07-03 15:08:57 --> Language Class Initialized
DEBUG - 2011-07-03 15:08:57 --> Loader Class Initialized
DEBUG - 2011-07-03 15:08:57 --> Controller Class Initialized
ERROR - 2011-07-03 15:08:57 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-07-03 15:08:57 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-07-03 15:08:57 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-07-03 15:08:57 --> Model Class Initialized
DEBUG - 2011-07-03 15:08:57 --> Model Class Initialized
DEBUG - 2011-07-03 15:08:57 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-07-03 15:08:57 --> Database Driver Class Initialized
DEBUG - 2011-07-03 15:08:57 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-07-03 15:08:57 --> Helper loaded: url_helper
DEBUG - 2011-07-03 15:08:57 --> File loaded: application/views/common/header.php
DEBUG - 2011-07-03 15:08:57 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-07-03 15:08:57 --> File loaded: application/views/common/footer.php
DEBUG - 2011-07-03 15:08:57 --> File loaded: application/views/layout/main.php
DEBUG - 2011-07-03 15:08:57 --> Final output sent to browser
DEBUG - 2011-07-03 15:08:57 --> Total execution time: 0.0814
DEBUG - 2011-07-03 15:09:00 --> Config Class Initialized
DEBUG - 2011-07-03 15:09:00 --> Hooks Class Initialized
DEBUG - 2011-07-03 15:09:00 --> Utf8 Class Initialized
DEBUG - 2011-07-03 15:09:00 --> UTF-8 Support Enabled
DEBUG - 2011-07-03 15:09:00 --> URI Class Initialized
DEBUG - 2011-07-03 15:09:00 --> Router Class Initialized
DEBUG - 2011-07-03 15:09:00 --> Output Class Initialized
DEBUG - 2011-07-03 15:09:00 --> Input Class Initialized
DEBUG - 2011-07-03 15:09:00 --> Global POST and COOKIE data sanitized
DEBUG - 2011-07-03 15:09:00 --> Language Class Initialized
DEBUG - 2011-07-03 15:09:00 --> Loader Class Initialized
DEBUG - 2011-07-03 15:09:00 --> Controller Class Initialized
DEBUG - 2011-07-03 15:09:00 --> Model Class Initialized
DEBUG - 2011-07-03 15:09:00 --> Model Class Initialized
DEBUG - 2011-07-03 15:09:00 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-07-03 15:09:00 --> Database Driver Class Initialized
DEBUG - 2011-07-03 15:09:01 --> Final output sent to browser
DEBUG - 2011-07-03 15:09:01 --> Total execution time: 0.5995
DEBUG - 2011-07-03 15:59:30 --> Config Class Initialized
DEBUG - 2011-07-03 15:59:30 --> Hooks Class Initialized
DEBUG - 2011-07-03 15:59:30 --> Utf8 Class Initialized
DEBUG - 2011-07-03 15:59:30 --> UTF-8 Support Enabled
DEBUG - 2011-07-03 15:59:30 --> URI Class Initialized
DEBUG - 2011-07-03 15:59:30 --> Router Class Initialized
DEBUG - 2011-07-03 15:59:30 --> Output Class Initialized
DEBUG - 2011-07-03 15:59:30 --> Input Class Initialized
DEBUG - 2011-07-03 15:59:30 --> Global POST and COOKIE data sanitized
DEBUG - 2011-07-03 15:59:30 --> Language Class Initialized
DEBUG - 2011-07-03 15:59:30 --> Loader Class Initialized
DEBUG - 2011-07-03 15:59:30 --> Controller Class Initialized
DEBUG - 2011-07-03 15:59:30 --> Model Class Initialized
DEBUG - 2011-07-03 15:59:30 --> Model Class Initialized
DEBUG - 2011-07-03 15:59:30 --> Model Class Initialized
DEBUG - 2011-07-03 15:59:30 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-07-03 15:59:30 --> Database Driver Class Initialized
DEBUG - 2011-07-03 15:59:30 --> File loaded: application/views/table/main.php
DEBUG - 2011-07-03 15:59:31 --> Helper loaded: url_helper
DEBUG - 2011-07-03 15:59:31 --> File loaded: application/views/common/header.php
DEBUG - 2011-07-03 15:59:31 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-07-03 15:59:31 --> File loaded: application/views/common/footer.php
DEBUG - 2011-07-03 15:59:31 --> File loaded: application/views/layout/main.php
DEBUG - 2011-07-03 15:59:31 --> Final output sent to browser
DEBUG - 2011-07-03 15:59:31 --> Total execution time: 0.6995
DEBUG - 2011-07-03 15:59:50 --> Config Class Initialized
DEBUG - 2011-07-03 15:59:50 --> Hooks Class Initialized
DEBUG - 2011-07-03 15:59:50 --> Utf8 Class Initialized
DEBUG - 2011-07-03 15:59:50 --> UTF-8 Support Enabled
DEBUG - 2011-07-03 15:59:50 --> URI Class Initialized
DEBUG - 2011-07-03 15:59:50 --> Router Class Initialized
DEBUG - 2011-07-03 15:59:50 --> Output Class Initialized
DEBUG - 2011-07-03 15:59:50 --> Input Class Initialized
DEBUG - 2011-07-03 15:59:50 --> Global POST and COOKIE data sanitized
DEBUG - 2011-07-03 15:59:50 --> Language Class Initialized
DEBUG - 2011-07-03 15:59:50 --> Loader Class Initialized
DEBUG - 2011-07-03 15:59:50 --> Controller Class Initialized
ERROR - 2011-07-03 15:59:50 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-07-03 15:59:50 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-07-03 15:59:50 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-07-03 15:59:50 --> Model Class Initialized
DEBUG - 2011-07-03 15:59:50 --> Model Class Initialized
DEBUG - 2011-07-03 15:59:50 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-07-03 15:59:50 --> Database Driver Class Initialized
DEBUG - 2011-07-03 15:59:50 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-07-03 15:59:50 --> Helper loaded: url_helper
DEBUG - 2011-07-03 15:59:50 --> File loaded: application/views/common/header.php
DEBUG - 2011-07-03 15:59:50 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-07-03 15:59:50 --> File loaded: application/views/common/footer.php
DEBUG - 2011-07-03 15:59:50 --> File loaded: application/views/layout/main.php
DEBUG - 2011-07-03 15:59:50 --> Final output sent to browser
DEBUG - 2011-07-03 15:59:50 --> Total execution time: 0.1076
DEBUG - 2011-07-03 18:30:55 --> Config Class Initialized
DEBUG - 2011-07-03 18:30:55 --> Hooks Class Initialized
DEBUG - 2011-07-03 18:30:55 --> Utf8 Class Initialized
DEBUG - 2011-07-03 18:30:55 --> UTF-8 Support Enabled
DEBUG - 2011-07-03 18:30:55 --> URI Class Initialized
DEBUG - 2011-07-03 18:30:55 --> Router Class Initialized
DEBUG - 2011-07-03 18:30:55 --> Output Class Initialized
DEBUG - 2011-07-03 18:30:55 --> Input Class Initialized
DEBUG - 2011-07-03 18:30:55 --> Global POST and COOKIE data sanitized
DEBUG - 2011-07-03 18:30:55 --> Language Class Initialized
DEBUG - 2011-07-03 18:30:55 --> Loader Class Initialized
DEBUG - 2011-07-03 18:30:55 --> Controller Class Initialized
ERROR - 2011-07-03 18:30:55 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-07-03 18:30:55 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-07-03 18:30:55 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-07-03 18:30:55 --> Model Class Initialized
DEBUG - 2011-07-03 18:30:55 --> Model Class Initialized
DEBUG - 2011-07-03 18:30:55 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-07-03 18:30:56 --> Database Driver Class Initialized
DEBUG - 2011-07-03 18:30:56 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-07-03 18:30:56 --> Helper loaded: url_helper
DEBUG - 2011-07-03 18:30:56 --> File loaded: application/views/common/header.php
DEBUG - 2011-07-03 18:30:56 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-07-03 18:30:56 --> File loaded: application/views/common/footer.php
DEBUG - 2011-07-03 18:30:56 --> File loaded: application/views/layout/main.php
DEBUG - 2011-07-03 18:30:56 --> Final output sent to browser
DEBUG - 2011-07-03 18:30:56 --> Total execution time: 0.4409
DEBUG - 2011-07-03 18:30:57 --> Config Class Initialized
DEBUG - 2011-07-03 18:30:57 --> Hooks Class Initialized
DEBUG - 2011-07-03 18:30:57 --> Utf8 Class Initialized
DEBUG - 2011-07-03 18:30:57 --> UTF-8 Support Enabled
DEBUG - 2011-07-03 18:30:57 --> URI Class Initialized
DEBUG - 2011-07-03 18:30:57 --> Router Class Initialized
DEBUG - 2011-07-03 18:30:57 --> Output Class Initialized
DEBUG - 2011-07-03 18:30:57 --> Input Class Initialized
DEBUG - 2011-07-03 18:30:57 --> Global POST and COOKIE data sanitized
DEBUG - 2011-07-03 18:30:57 --> Language Class Initialized
DEBUG - 2011-07-03 18:30:57 --> Loader Class Initialized
DEBUG - 2011-07-03 18:30:57 --> Controller Class Initialized
DEBUG - 2011-07-03 18:30:57 --> Model Class Initialized
DEBUG - 2011-07-03 18:30:57 --> Model Class Initialized
DEBUG - 2011-07-03 18:30:57 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-07-03 18:30:57 --> Database Driver Class Initialized
DEBUG - 2011-07-03 18:30:58 --> Final output sent to browser
DEBUG - 2011-07-03 18:30:58 --> Total execution time: 0.6992
DEBUG - 2011-07-03 18:30:58 --> Config Class Initialized
DEBUG - 2011-07-03 18:30:58 --> Hooks Class Initialized
DEBUG - 2011-07-03 18:30:58 --> Utf8 Class Initialized
DEBUG - 2011-07-03 18:30:58 --> UTF-8 Support Enabled
DEBUG - 2011-07-03 18:30:58 --> URI Class Initialized
DEBUG - 2011-07-03 18:30:58 --> Router Class Initialized
ERROR - 2011-07-03 18:30:58 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-07-03 18:31:35 --> Config Class Initialized
DEBUG - 2011-07-03 18:31:35 --> Hooks Class Initialized
DEBUG - 2011-07-03 18:31:35 --> Utf8 Class Initialized
DEBUG - 2011-07-03 18:31:35 --> UTF-8 Support Enabled
DEBUG - 2011-07-03 18:31:35 --> URI Class Initialized
DEBUG - 2011-07-03 18:31:35 --> Router Class Initialized
DEBUG - 2011-07-03 18:31:35 --> Output Class Initialized
DEBUG - 2011-07-03 18:31:35 --> Input Class Initialized
DEBUG - 2011-07-03 18:31:35 --> Global POST and COOKIE data sanitized
DEBUG - 2011-07-03 18:31:35 --> Language Class Initialized
DEBUG - 2011-07-03 18:31:35 --> Loader Class Initialized
DEBUG - 2011-07-03 18:31:35 --> Controller Class Initialized
ERROR - 2011-07-03 18:31:35 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-07-03 18:31:35 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-07-03 18:31:35 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-07-03 18:31:35 --> Model Class Initialized
DEBUG - 2011-07-03 18:31:35 --> Model Class Initialized
DEBUG - 2011-07-03 18:31:35 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-07-03 18:31:35 --> Database Driver Class Initialized
DEBUG - 2011-07-03 18:31:35 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-07-03 18:31:35 --> Helper loaded: url_helper
DEBUG - 2011-07-03 18:31:35 --> File loaded: application/views/common/header.php
DEBUG - 2011-07-03 18:31:35 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-07-03 18:31:35 --> File loaded: application/views/common/footer.php
DEBUG - 2011-07-03 18:31:35 --> File loaded: application/views/layout/main.php
DEBUG - 2011-07-03 18:31:35 --> Final output sent to browser
DEBUG - 2011-07-03 18:31:35 --> Total execution time: 0.0269
DEBUG - 2011-07-03 18:31:36 --> Config Class Initialized
DEBUG - 2011-07-03 18:31:36 --> Hooks Class Initialized
DEBUG - 2011-07-03 18:31:36 --> Utf8 Class Initialized
DEBUG - 2011-07-03 18:31:36 --> UTF-8 Support Enabled
DEBUG - 2011-07-03 18:31:36 --> URI Class Initialized
DEBUG - 2011-07-03 18:31:36 --> Router Class Initialized
DEBUG - 2011-07-03 18:31:36 --> Output Class Initialized
DEBUG - 2011-07-03 18:31:36 --> Input Class Initialized
DEBUG - 2011-07-03 18:31:36 --> Global POST and COOKIE data sanitized
DEBUG - 2011-07-03 18:31:36 --> Language Class Initialized
DEBUG - 2011-07-03 18:31:36 --> Loader Class Initialized
DEBUG - 2011-07-03 18:31:36 --> Controller Class Initialized
DEBUG - 2011-07-03 18:31:36 --> Model Class Initialized
DEBUG - 2011-07-03 18:31:36 --> Model Class Initialized
DEBUG - 2011-07-03 18:31:36 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-07-03 18:31:36 --> Database Driver Class Initialized
DEBUG - 2011-07-03 18:31:36 --> Config Class Initialized
DEBUG - 2011-07-03 18:31:36 --> Hooks Class Initialized
DEBUG - 2011-07-03 18:31:36 --> Utf8 Class Initialized
DEBUG - 2011-07-03 18:31:36 --> UTF-8 Support Enabled
DEBUG - 2011-07-03 18:31:36 --> URI Class Initialized
DEBUG - 2011-07-03 18:31:36 --> Router Class Initialized
DEBUG - 2011-07-03 18:31:36 --> Output Class Initialized
DEBUG - 2011-07-03 18:31:36 --> Input Class Initialized
DEBUG - 2011-07-03 18:31:36 --> Global POST and COOKIE data sanitized
DEBUG - 2011-07-03 18:31:36 --> Language Class Initialized
DEBUG - 2011-07-03 18:31:36 --> Loader Class Initialized
DEBUG - 2011-07-03 18:31:36 --> Controller Class Initialized
ERROR - 2011-07-03 18:31:36 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-07-03 18:31:36 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-07-03 18:31:36 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-07-03 18:31:36 --> Model Class Initialized
DEBUG - 2011-07-03 18:31:36 --> Model Class Initialized
DEBUG - 2011-07-03 18:31:36 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-07-03 18:31:36 --> Database Driver Class Initialized
DEBUG - 2011-07-03 18:31:36 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-07-03 18:31:36 --> Helper loaded: url_helper
DEBUG - 2011-07-03 18:31:36 --> File loaded: application/views/common/header.php
DEBUG - 2011-07-03 18:31:36 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-07-03 18:31:36 --> File loaded: application/views/common/footer.php
DEBUG - 2011-07-03 18:31:36 --> File loaded: application/views/layout/main.php
DEBUG - 2011-07-03 18:31:36 --> Final output sent to browser
DEBUG - 2011-07-03 18:31:36 --> Total execution time: 0.0259
DEBUG - 2011-07-03 18:31:36 --> Final output sent to browser
DEBUG - 2011-07-03 18:31:36 --> Total execution time: 0.5814
DEBUG - 2011-07-03 20:15:00 --> Config Class Initialized
DEBUG - 2011-07-03 20:15:00 --> Hooks Class Initialized
DEBUG - 2011-07-03 20:15:00 --> Utf8 Class Initialized
DEBUG - 2011-07-03 20:15:00 --> UTF-8 Support Enabled
DEBUG - 2011-07-03 20:15:00 --> URI Class Initialized
DEBUG - 2011-07-03 20:15:00 --> Router Class Initialized
DEBUG - 2011-07-03 20:15:00 --> Output Class Initialized
DEBUG - 2011-07-03 20:15:00 --> Input Class Initialized
DEBUG - 2011-07-03 20:15:00 --> Global POST and COOKIE data sanitized
DEBUG - 2011-07-03 20:15:00 --> Language Class Initialized
DEBUG - 2011-07-03 20:15:00 --> Loader Class Initialized
DEBUG - 2011-07-03 20:15:00 --> Controller Class Initialized
ERROR - 2011-07-03 20:15:00 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-07-03 20:15:00 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-07-03 20:15:00 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-07-03 20:15:00 --> Model Class Initialized
DEBUG - 2011-07-03 20:15:00 --> Model Class Initialized
DEBUG - 2011-07-03 20:15:00 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-07-03 20:15:00 --> Database Driver Class Initialized
DEBUG - 2011-07-03 20:15:00 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-07-03 20:15:00 --> Helper loaded: url_helper
DEBUG - 2011-07-03 20:15:00 --> File loaded: application/views/common/header.php
DEBUG - 2011-07-03 20:15:00 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-07-03 20:15:00 --> File loaded: application/views/common/footer.php
DEBUG - 2011-07-03 20:15:00 --> File loaded: application/views/layout/main.php
DEBUG - 2011-07-03 20:15:00 --> Final output sent to browser
DEBUG - 2011-07-03 20:15:00 --> Total execution time: 0.3951
DEBUG - 2011-07-03 20:15:01 --> Config Class Initialized
DEBUG - 2011-07-03 20:15:01 --> Hooks Class Initialized
DEBUG - 2011-07-03 20:15:01 --> Utf8 Class Initialized
DEBUG - 2011-07-03 20:15:01 --> UTF-8 Support Enabled
DEBUG - 2011-07-03 20:15:01 --> URI Class Initialized
DEBUG - 2011-07-03 20:15:01 --> Router Class Initialized
DEBUG - 2011-07-03 20:15:01 --> Output Class Initialized
DEBUG - 2011-07-03 20:15:01 --> Input Class Initialized
DEBUG - 2011-07-03 20:15:01 --> Global POST and COOKIE data sanitized
DEBUG - 2011-07-03 20:15:01 --> Language Class Initialized
DEBUG - 2011-07-03 20:15:01 --> Loader Class Initialized
DEBUG - 2011-07-03 20:15:01 --> Controller Class Initialized
DEBUG - 2011-07-03 20:15:01 --> Model Class Initialized
DEBUG - 2011-07-03 20:15:01 --> Model Class Initialized
DEBUG - 2011-07-03 20:15:01 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-07-03 20:15:01 --> Database Driver Class Initialized
DEBUG - 2011-07-03 20:15:02 --> Final output sent to browser
DEBUG - 2011-07-03 20:15:02 --> Total execution time: 0.8232
DEBUG - 2011-07-03 20:15:03 --> Config Class Initialized
DEBUG - 2011-07-03 20:15:03 --> Hooks Class Initialized
DEBUG - 2011-07-03 20:15:03 --> Utf8 Class Initialized
DEBUG - 2011-07-03 20:15:03 --> UTF-8 Support Enabled
DEBUG - 2011-07-03 20:15:03 --> URI Class Initialized
DEBUG - 2011-07-03 20:15:03 --> Router Class Initialized
ERROR - 2011-07-03 20:15:03 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-07-03 20:15:19 --> Config Class Initialized
DEBUG - 2011-07-03 20:15:19 --> Hooks Class Initialized
DEBUG - 2011-07-03 20:15:19 --> Utf8 Class Initialized
DEBUG - 2011-07-03 20:15:19 --> UTF-8 Support Enabled
DEBUG - 2011-07-03 20:15:19 --> URI Class Initialized
DEBUG - 2011-07-03 20:15:19 --> Router Class Initialized
DEBUG - 2011-07-03 20:15:19 --> Output Class Initialized
DEBUG - 2011-07-03 20:15:19 --> Input Class Initialized
DEBUG - 2011-07-03 20:15:19 --> Global POST and COOKIE data sanitized
DEBUG - 2011-07-03 20:15:19 --> Language Class Initialized
DEBUG - 2011-07-03 20:15:19 --> Loader Class Initialized
DEBUG - 2011-07-03 20:15:19 --> Controller Class Initialized
DEBUG - 2011-07-03 20:15:19 --> Model Class Initialized
DEBUG - 2011-07-03 20:15:19 --> Model Class Initialized
DEBUG - 2011-07-03 20:15:19 --> Model Class Initialized
DEBUG - 2011-07-03 20:15:19 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-07-03 20:15:19 --> Database Driver Class Initialized
DEBUG - 2011-07-03 20:15:19 --> File loaded: application/views/table/main.php
DEBUG - 2011-07-03 20:15:19 --> Helper loaded: url_helper
DEBUG - 2011-07-03 20:15:19 --> File loaded: application/views/common/header.php
DEBUG - 2011-07-03 20:15:19 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-07-03 20:15:19 --> File loaded: application/views/common/footer.php
DEBUG - 2011-07-03 20:15:19 --> File loaded: application/views/layout/main.php
DEBUG - 2011-07-03 20:15:19 --> Final output sent to browser
DEBUG - 2011-07-03 20:15:19 --> Total execution time: 0.2760
DEBUG - 2011-07-03 22:17:43 --> Config Class Initialized
DEBUG - 2011-07-03 22:17:43 --> Hooks Class Initialized
DEBUG - 2011-07-03 22:17:43 --> Utf8 Class Initialized
DEBUG - 2011-07-03 22:17:43 --> UTF-8 Support Enabled
DEBUG - 2011-07-03 22:17:43 --> URI Class Initialized
DEBUG - 2011-07-03 22:17:43 --> Router Class Initialized
DEBUG - 2011-07-03 22:17:43 --> Output Class Initialized
DEBUG - 2011-07-03 22:17:43 --> Input Class Initialized
DEBUG - 2011-07-03 22:17:43 --> Global POST and COOKIE data sanitized
DEBUG - 2011-07-03 22:17:43 --> Language Class Initialized
DEBUG - 2011-07-03 22:17:43 --> Loader Class Initialized
DEBUG - 2011-07-03 22:17:43 --> Controller Class Initialized
ERROR - 2011-07-03 22:17:43 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-07-03 22:17:43 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-07-03 22:17:43 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-07-03 22:17:43 --> Model Class Initialized
DEBUG - 2011-07-03 22:17:43 --> Model Class Initialized
DEBUG - 2011-07-03 22:17:43 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-07-03 22:17:43 --> Database Driver Class Initialized
DEBUG - 2011-07-03 22:17:43 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-07-03 22:17:43 --> Helper loaded: url_helper
DEBUG - 2011-07-03 22:17:43 --> File loaded: application/views/common/header.php
DEBUG - 2011-07-03 22:17:43 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-07-03 22:17:43 --> File loaded: application/views/common/footer.php
DEBUG - 2011-07-03 22:17:43 --> File loaded: application/views/layout/main.php
DEBUG - 2011-07-03 22:17:43 --> Final output sent to browser
DEBUG - 2011-07-03 22:17:43 --> Total execution time: 0.4314
DEBUG - 2011-07-03 22:26:41 --> Config Class Initialized
DEBUG - 2011-07-03 22:26:41 --> Hooks Class Initialized
DEBUG - 2011-07-03 22:26:41 --> Utf8 Class Initialized
DEBUG - 2011-07-03 22:26:41 --> UTF-8 Support Enabled
DEBUG - 2011-07-03 22:26:41 --> URI Class Initialized
DEBUG - 2011-07-03 22:26:41 --> Router Class Initialized
ERROR - 2011-07-03 22:26:41 --> 404 Page Not Found --> robots.txt
DEBUG - 2011-07-03 22:27:11 --> Config Class Initialized
DEBUG - 2011-07-03 22:27:11 --> Hooks Class Initialized
DEBUG - 2011-07-03 22:27:11 --> Utf8 Class Initialized
DEBUG - 2011-07-03 22:27:11 --> UTF-8 Support Enabled
DEBUG - 2011-07-03 22:27:11 --> URI Class Initialized
DEBUG - 2011-07-03 22:27:11 --> Router Class Initialized
DEBUG - 2011-07-03 22:27:11 --> Output Class Initialized
DEBUG - 2011-07-03 22:27:11 --> Input Class Initialized
DEBUG - 2011-07-03 22:27:11 --> Global POST and COOKIE data sanitized
DEBUG - 2011-07-03 22:27:11 --> Language Class Initialized
DEBUG - 2011-07-03 22:27:11 --> Loader Class Initialized
DEBUG - 2011-07-03 22:27:11 --> Controller Class Initialized
ERROR - 2011-07-03 22:27:11 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-07-03 22:27:11 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-07-03 22:27:11 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-07-03 22:27:11 --> Model Class Initialized
DEBUG - 2011-07-03 22:27:11 --> Model Class Initialized
DEBUG - 2011-07-03 22:27:11 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-07-03 22:27:11 --> Database Driver Class Initialized
DEBUG - 2011-07-03 22:27:11 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-07-03 22:27:11 --> Helper loaded: url_helper
DEBUG - 2011-07-03 22:27:11 --> File loaded: application/views/common/header.php
DEBUG - 2011-07-03 22:27:11 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-07-03 22:27:11 --> File loaded: application/views/common/footer.php
DEBUG - 2011-07-03 22:27:11 --> File loaded: application/views/layout/main.php
DEBUG - 2011-07-03 22:27:11 --> Final output sent to browser
DEBUG - 2011-07-03 22:27:11 --> Total execution time: 0.0640

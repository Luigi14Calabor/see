<?php  if ( ! defined('BASEPATH')) exit('No direct script access allowed'); ?>

DEBUG - 2011-04-08 00:42:06 --> Config Class Initialized
DEBUG - 2011-04-08 00:42:06 --> Hooks Class Initialized
DEBUG - 2011-04-08 00:42:06 --> Utf8 Class Initialized
DEBUG - 2011-04-08 00:42:06 --> UTF-8 Support Enabled
DEBUG - 2011-04-08 00:42:06 --> URI Class Initialized
DEBUG - 2011-04-08 00:42:06 --> Router Class Initialized
DEBUG - 2011-04-08 00:42:06 --> No URI present. Default controller set.
DEBUG - 2011-04-08 00:42:06 --> Output Class Initialized
DEBUG - 2011-04-08 00:42:06 --> Input Class Initialized
DEBUG - 2011-04-08 00:42:06 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-08 00:42:06 --> Language Class Initialized
DEBUG - 2011-04-08 00:42:06 --> Loader Class Initialized
DEBUG - 2011-04-08 00:42:06 --> Controller Class Initialized
DEBUG - 2011-04-08 00:42:06 --> File loaded: application/views/splash/main.php
DEBUG - 2011-04-08 00:42:06 --> Helper loaded: url_helper
DEBUG - 2011-04-08 00:42:06 --> File loaded: application/views/common/header.php
DEBUG - 2011-04-08 00:42:06 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-04-08 00:42:06 --> File loaded: application/views/common/footer.php
DEBUG - 2011-04-08 00:42:06 --> File loaded: application/views/layout/main.php
DEBUG - 2011-04-08 00:42:06 --> Final output sent to browser
DEBUG - 2011-04-08 00:42:06 --> Total execution time: 0.1980
DEBUG - 2011-04-08 00:42:07 --> Config Class Initialized
DEBUG - 2011-04-08 00:42:07 --> Hooks Class Initialized
DEBUG - 2011-04-08 00:42:07 --> Utf8 Class Initialized
DEBUG - 2011-04-08 00:42:07 --> UTF-8 Support Enabled
DEBUG - 2011-04-08 00:42:07 --> URI Class Initialized
DEBUG - 2011-04-08 00:42:07 --> Router Class Initialized
DEBUG - 2011-04-08 00:42:07 --> No URI present. Default controller set.
DEBUG - 2011-04-08 00:42:07 --> Output Class Initialized
DEBUG - 2011-04-08 00:42:07 --> Input Class Initialized
DEBUG - 2011-04-08 00:42:07 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-08 00:42:07 --> Language Class Initialized
DEBUG - 2011-04-08 00:42:07 --> Loader Class Initialized
DEBUG - 2011-04-08 00:42:07 --> Controller Class Initialized
DEBUG - 2011-04-08 00:42:07 --> File loaded: application/views/splash/main.php
DEBUG - 2011-04-08 00:42:07 --> Helper loaded: url_helper
DEBUG - 2011-04-08 00:42:07 --> File loaded: application/views/common/header.php
DEBUG - 2011-04-08 00:42:07 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-04-08 00:42:07 --> File loaded: application/views/common/footer.php
DEBUG - 2011-04-08 00:42:07 --> File loaded: application/views/layout/main.php
DEBUG - 2011-04-08 00:42:07 --> Final output sent to browser
DEBUG - 2011-04-08 00:42:07 --> Total execution time: 0.0124
DEBUG - 2011-04-08 00:42:10 --> Config Class Initialized
DEBUG - 2011-04-08 00:42:10 --> Hooks Class Initialized
DEBUG - 2011-04-08 00:42:10 --> Utf8 Class Initialized
DEBUG - 2011-04-08 00:42:10 --> UTF-8 Support Enabled
DEBUG - 2011-04-08 00:42:10 --> URI Class Initialized
DEBUG - 2011-04-08 00:42:10 --> Router Class Initialized
ERROR - 2011-04-08 00:42:10 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-04-08 00:42:13 --> Config Class Initialized
DEBUG - 2011-04-08 00:42:13 --> Hooks Class Initialized
DEBUG - 2011-04-08 00:42:13 --> Utf8 Class Initialized
DEBUG - 2011-04-08 00:42:13 --> UTF-8 Support Enabled
DEBUG - 2011-04-08 00:42:13 --> URI Class Initialized
DEBUG - 2011-04-08 00:42:13 --> Router Class Initialized
ERROR - 2011-04-08 00:42:13 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-04-08 00:42:25 --> Config Class Initialized
DEBUG - 2011-04-08 00:42:25 --> Hooks Class Initialized
DEBUG - 2011-04-08 00:42:25 --> Utf8 Class Initialized
DEBUG - 2011-04-08 00:42:25 --> UTF-8 Support Enabled
DEBUG - 2011-04-08 00:42:25 --> URI Class Initialized
DEBUG - 2011-04-08 00:42:25 --> Router Class Initialized
DEBUG - 2011-04-08 00:42:25 --> Output Class Initialized
DEBUG - 2011-04-08 00:42:25 --> Input Class Initialized
DEBUG - 2011-04-08 00:42:25 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-08 00:42:25 --> Language Class Initialized
DEBUG - 2011-04-08 00:42:25 --> Loader Class Initialized
DEBUG - 2011-04-08 00:42:25 --> Controller Class Initialized
DEBUG - 2011-04-08 00:42:25 --> Model Class Initialized
DEBUG - 2011-04-08 00:42:25 --> Model Class Initialized
DEBUG - 2011-04-08 00:42:25 --> Model Class Initialized
DEBUG - 2011-04-08 00:42:25 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-08 00:42:25 --> Database Driver Class Initialized
DEBUG - 2011-04-08 00:42:25 --> File loaded: application/views/table/main.php
DEBUG - 2011-04-08 00:42:25 --> Helper loaded: url_helper
DEBUG - 2011-04-08 00:42:25 --> File loaded: application/views/common/header.php
DEBUG - 2011-04-08 00:42:25 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-04-08 00:42:25 --> File loaded: application/views/common/footer.php
DEBUG - 2011-04-08 00:42:25 --> File loaded: application/views/layout/main.php
DEBUG - 2011-04-08 00:42:25 --> Final output sent to browser
DEBUG - 2011-04-08 00:42:25 --> Total execution time: 0.4911
DEBUG - 2011-04-08 00:42:50 --> Config Class Initialized
DEBUG - 2011-04-08 00:42:50 --> Hooks Class Initialized
DEBUG - 2011-04-08 00:42:50 --> Utf8 Class Initialized
DEBUG - 2011-04-08 00:42:50 --> UTF-8 Support Enabled
DEBUG - 2011-04-08 00:42:50 --> URI Class Initialized
DEBUG - 2011-04-08 00:42:50 --> Router Class Initialized
DEBUG - 2011-04-08 00:42:50 --> Output Class Initialized
DEBUG - 2011-04-08 00:42:50 --> Input Class Initialized
DEBUG - 2011-04-08 00:42:50 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-08 00:42:50 --> Language Class Initialized
DEBUG - 2011-04-08 00:42:50 --> Loader Class Initialized
DEBUG - 2011-04-08 00:42:50 --> Controller Class Initialized
DEBUG - 2011-04-08 00:42:50 --> Model Class Initialized
DEBUG - 2011-04-08 00:42:50 --> Model Class Initialized
DEBUG - 2011-04-08 00:42:50 --> Model Class Initialized
DEBUG - 2011-04-08 00:42:50 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-08 00:42:50 --> Database Driver Class Initialized
DEBUG - 2011-04-08 00:42:51 --> File loaded: application/views/table/main.php
DEBUG - 2011-04-08 00:42:51 --> Helper loaded: url_helper
DEBUG - 2011-04-08 00:42:51 --> File loaded: application/views/common/header.php
DEBUG - 2011-04-08 00:42:51 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-04-08 00:42:51 --> File loaded: application/views/common/footer.php
DEBUG - 2011-04-08 00:42:51 --> File loaded: application/views/layout/main.php
DEBUG - 2011-04-08 00:42:51 --> Final output sent to browser
DEBUG - 2011-04-08 00:42:51 --> Total execution time: 0.6254
DEBUG - 2011-04-08 00:42:52 --> Config Class Initialized
DEBUG - 2011-04-08 00:42:52 --> Hooks Class Initialized
DEBUG - 2011-04-08 00:42:52 --> Utf8 Class Initialized
DEBUG - 2011-04-08 00:42:52 --> UTF-8 Support Enabled
DEBUG - 2011-04-08 00:42:52 --> URI Class Initialized
DEBUG - 2011-04-08 00:42:52 --> Router Class Initialized
DEBUG - 2011-04-08 00:42:52 --> Output Class Initialized
DEBUG - 2011-04-08 00:42:52 --> Input Class Initialized
DEBUG - 2011-04-08 00:42:52 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-08 00:42:52 --> Language Class Initialized
DEBUG - 2011-04-08 00:42:52 --> Loader Class Initialized
DEBUG - 2011-04-08 00:42:52 --> Controller Class Initialized
DEBUG - 2011-04-08 00:42:52 --> Model Class Initialized
DEBUG - 2011-04-08 00:42:52 --> Model Class Initialized
DEBUG - 2011-04-08 00:42:52 --> Model Class Initialized
DEBUG - 2011-04-08 00:42:52 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-08 00:42:52 --> Database Driver Class Initialized
DEBUG - 2011-04-08 00:42:52 --> File loaded: application/views/table/main.php
DEBUG - 2011-04-08 00:42:52 --> Helper loaded: url_helper
DEBUG - 2011-04-08 00:42:52 --> File loaded: application/views/common/header.php
DEBUG - 2011-04-08 00:42:52 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-04-08 00:42:52 --> File loaded: application/views/common/footer.php
DEBUG - 2011-04-08 00:42:52 --> File loaded: application/views/layout/main.php
DEBUG - 2011-04-08 00:42:52 --> Final output sent to browser
DEBUG - 2011-04-08 00:42:52 --> Total execution time: 0.0479
DEBUG - 2011-04-08 00:43:09 --> Config Class Initialized
DEBUG - 2011-04-08 00:43:09 --> Hooks Class Initialized
DEBUG - 2011-04-08 00:43:09 --> Utf8 Class Initialized
DEBUG - 2011-04-08 00:43:09 --> UTF-8 Support Enabled
DEBUG - 2011-04-08 00:43:09 --> URI Class Initialized
DEBUG - 2011-04-08 00:43:09 --> Router Class Initialized
DEBUG - 2011-04-08 00:43:09 --> Output Class Initialized
DEBUG - 2011-04-08 00:43:09 --> Input Class Initialized
DEBUG - 2011-04-08 00:43:09 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-08 00:43:09 --> Language Class Initialized
DEBUG - 2011-04-08 00:43:09 --> Loader Class Initialized
DEBUG - 2011-04-08 00:43:09 --> Controller Class Initialized
DEBUG - 2011-04-08 00:43:09 --> Model Class Initialized
DEBUG - 2011-04-08 00:43:09 --> Model Class Initialized
DEBUG - 2011-04-08 00:43:09 --> Model Class Initialized
DEBUG - 2011-04-08 00:43:09 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-08 00:43:09 --> Database Driver Class Initialized
DEBUG - 2011-04-08 00:43:09 --> File loaded: application/views/table/main.php
DEBUG - 2011-04-08 00:43:09 --> Helper loaded: url_helper
DEBUG - 2011-04-08 00:43:09 --> File loaded: application/views/common/header.php
DEBUG - 2011-04-08 00:43:09 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-04-08 00:43:09 --> File loaded: application/views/common/footer.php
DEBUG - 2011-04-08 00:43:09 --> File loaded: application/views/layout/main.php
DEBUG - 2011-04-08 00:43:09 --> Final output sent to browser
DEBUG - 2011-04-08 00:43:09 --> Total execution time: 0.1884
DEBUG - 2011-04-08 00:43:10 --> Config Class Initialized
DEBUG - 2011-04-08 00:43:10 --> Hooks Class Initialized
DEBUG - 2011-04-08 00:43:10 --> Utf8 Class Initialized
DEBUG - 2011-04-08 00:43:10 --> UTF-8 Support Enabled
DEBUG - 2011-04-08 00:43:10 --> URI Class Initialized
DEBUG - 2011-04-08 00:43:10 --> Router Class Initialized
DEBUG - 2011-04-08 00:43:10 --> Output Class Initialized
DEBUG - 2011-04-08 00:43:10 --> Input Class Initialized
DEBUG - 2011-04-08 00:43:10 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-08 00:43:10 --> Language Class Initialized
DEBUG - 2011-04-08 00:43:10 --> Loader Class Initialized
DEBUG - 2011-04-08 00:43:10 --> Controller Class Initialized
DEBUG - 2011-04-08 00:43:10 --> Model Class Initialized
DEBUG - 2011-04-08 00:43:10 --> Model Class Initialized
DEBUG - 2011-04-08 00:43:10 --> Model Class Initialized
DEBUG - 2011-04-08 00:43:10 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-08 00:43:10 --> Database Driver Class Initialized
DEBUG - 2011-04-08 00:43:10 --> File loaded: application/views/table/main.php
DEBUG - 2011-04-08 00:43:10 --> Helper loaded: url_helper
DEBUG - 2011-04-08 00:43:10 --> File loaded: application/views/common/header.php
DEBUG - 2011-04-08 00:43:10 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-04-08 00:43:10 --> File loaded: application/views/common/footer.php
DEBUG - 2011-04-08 00:43:10 --> File loaded: application/views/layout/main.php
DEBUG - 2011-04-08 00:43:10 --> Final output sent to browser
DEBUG - 2011-04-08 00:43:10 --> Total execution time: 0.0427
DEBUG - 2011-04-08 00:43:18 --> Config Class Initialized
DEBUG - 2011-04-08 00:43:18 --> Hooks Class Initialized
DEBUG - 2011-04-08 00:43:18 --> Utf8 Class Initialized
DEBUG - 2011-04-08 00:43:18 --> UTF-8 Support Enabled
DEBUG - 2011-04-08 00:43:18 --> URI Class Initialized
DEBUG - 2011-04-08 00:43:18 --> Router Class Initialized
DEBUG - 2011-04-08 00:43:18 --> Output Class Initialized
DEBUG - 2011-04-08 00:43:18 --> Input Class Initialized
DEBUG - 2011-04-08 00:43:18 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-08 00:43:18 --> Language Class Initialized
DEBUG - 2011-04-08 00:43:18 --> Loader Class Initialized
DEBUG - 2011-04-08 00:43:18 --> Controller Class Initialized
DEBUG - 2011-04-08 00:43:18 --> Model Class Initialized
DEBUG - 2011-04-08 00:43:18 --> Model Class Initialized
DEBUG - 2011-04-08 00:43:18 --> Model Class Initialized
DEBUG - 2011-04-08 00:43:18 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-08 00:43:18 --> Database Driver Class Initialized
DEBUG - 2011-04-08 00:43:18 --> File loaded: application/views/table/main.php
DEBUG - 2011-04-08 00:43:18 --> Helper loaded: url_helper
DEBUG - 2011-04-08 00:43:18 --> File loaded: application/views/common/header.php
DEBUG - 2011-04-08 00:43:18 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-04-08 00:43:18 --> File loaded: application/views/common/footer.php
DEBUG - 2011-04-08 00:43:18 --> File loaded: application/views/layout/main.php
DEBUG - 2011-04-08 00:43:18 --> Final output sent to browser
DEBUG - 2011-04-08 00:43:18 --> Total execution time: 0.2088
DEBUG - 2011-04-08 00:43:19 --> Config Class Initialized
DEBUG - 2011-04-08 00:43:19 --> Hooks Class Initialized
DEBUG - 2011-04-08 00:43:19 --> Utf8 Class Initialized
DEBUG - 2011-04-08 00:43:19 --> UTF-8 Support Enabled
DEBUG - 2011-04-08 00:43:19 --> URI Class Initialized
DEBUG - 2011-04-08 00:43:19 --> Router Class Initialized
DEBUG - 2011-04-08 00:43:19 --> Output Class Initialized
DEBUG - 2011-04-08 00:43:19 --> Input Class Initialized
DEBUG - 2011-04-08 00:43:19 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-08 00:43:19 --> Language Class Initialized
DEBUG - 2011-04-08 00:43:19 --> Loader Class Initialized
DEBUG - 2011-04-08 00:43:19 --> Controller Class Initialized
DEBUG - 2011-04-08 00:43:19 --> Model Class Initialized
DEBUG - 2011-04-08 00:43:19 --> Model Class Initialized
DEBUG - 2011-04-08 00:43:19 --> Model Class Initialized
DEBUG - 2011-04-08 00:43:19 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-08 00:43:19 --> Database Driver Class Initialized
DEBUG - 2011-04-08 00:43:19 --> File loaded: application/views/table/main.php
DEBUG - 2011-04-08 00:43:19 --> Helper loaded: url_helper
DEBUG - 2011-04-08 00:43:19 --> File loaded: application/views/common/header.php
DEBUG - 2011-04-08 00:43:19 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-04-08 00:43:19 --> File loaded: application/views/common/footer.php
DEBUG - 2011-04-08 00:43:19 --> File loaded: application/views/layout/main.php
DEBUG - 2011-04-08 00:43:19 --> Final output sent to browser
DEBUG - 2011-04-08 00:43:19 --> Total execution time: 0.0505
DEBUG - 2011-04-08 00:46:44 --> Config Class Initialized
DEBUG - 2011-04-08 00:46:44 --> Hooks Class Initialized
DEBUG - 2011-04-08 00:46:44 --> Utf8 Class Initialized
DEBUG - 2011-04-08 00:46:44 --> UTF-8 Support Enabled
DEBUG - 2011-04-08 00:46:44 --> URI Class Initialized
DEBUG - 2011-04-08 00:46:44 --> Router Class Initialized
DEBUG - 2011-04-08 00:46:44 --> Output Class Initialized
DEBUG - 2011-04-08 00:46:44 --> Input Class Initialized
DEBUG - 2011-04-08 00:46:44 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-08 00:46:44 --> Language Class Initialized
DEBUG - 2011-04-08 00:46:44 --> Loader Class Initialized
DEBUG - 2011-04-08 00:46:44 --> Controller Class Initialized
DEBUG - 2011-04-08 00:46:44 --> Model Class Initialized
DEBUG - 2011-04-08 00:46:44 --> Model Class Initialized
DEBUG - 2011-04-08 00:46:44 --> Model Class Initialized
DEBUG - 2011-04-08 00:46:44 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-08 00:46:44 --> Database Driver Class Initialized
DEBUG - 2011-04-08 00:46:44 --> File loaded: application/views/table/main.php
DEBUG - 2011-04-08 00:46:44 --> Helper loaded: url_helper
DEBUG - 2011-04-08 00:46:44 --> File loaded: application/views/common/header.php
DEBUG - 2011-04-08 00:46:44 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-04-08 00:46:44 --> File loaded: application/views/common/footer.php
DEBUG - 2011-04-08 00:46:44 --> File loaded: application/views/layout/main.php
DEBUG - 2011-04-08 00:46:44 --> Final output sent to browser
DEBUG - 2011-04-08 00:46:44 --> Total execution time: 0.0424
DEBUG - 2011-04-08 00:46:46 --> Config Class Initialized
DEBUG - 2011-04-08 00:46:46 --> Hooks Class Initialized
DEBUG - 2011-04-08 00:46:46 --> Utf8 Class Initialized
DEBUG - 2011-04-08 00:46:46 --> UTF-8 Support Enabled
DEBUG - 2011-04-08 00:46:46 --> URI Class Initialized
DEBUG - 2011-04-08 00:46:46 --> Router Class Initialized
ERROR - 2011-04-08 00:46:46 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-04-08 00:46:49 --> Config Class Initialized
DEBUG - 2011-04-08 00:46:49 --> Hooks Class Initialized
DEBUG - 2011-04-08 00:46:49 --> Utf8 Class Initialized
DEBUG - 2011-04-08 00:46:49 --> UTF-8 Support Enabled
DEBUG - 2011-04-08 00:46:49 --> URI Class Initialized
DEBUG - 2011-04-08 00:46:49 --> Router Class Initialized
ERROR - 2011-04-08 00:46:49 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-04-08 00:47:17 --> Config Class Initialized
DEBUG - 2011-04-08 00:47:17 --> Hooks Class Initialized
DEBUG - 2011-04-08 00:47:17 --> Utf8 Class Initialized
DEBUG - 2011-04-08 00:47:17 --> UTF-8 Support Enabled
DEBUG - 2011-04-08 00:47:17 --> URI Class Initialized
DEBUG - 2011-04-08 00:47:17 --> Router Class Initialized
DEBUG - 2011-04-08 00:47:17 --> Output Class Initialized
DEBUG - 2011-04-08 00:47:17 --> Input Class Initialized
DEBUG - 2011-04-08 00:47:17 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-08 00:47:17 --> Language Class Initialized
DEBUG - 2011-04-08 00:47:17 --> Loader Class Initialized
DEBUG - 2011-04-08 00:47:17 --> Controller Class Initialized
DEBUG - 2011-04-08 00:47:17 --> Model Class Initialized
DEBUG - 2011-04-08 00:47:17 --> Model Class Initialized
DEBUG - 2011-04-08 00:47:17 --> Model Class Initialized
DEBUG - 2011-04-08 00:47:17 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-08 00:47:17 --> Database Driver Class Initialized
DEBUG - 2011-04-08 00:47:17 --> File loaded: application/views/table/main.php
DEBUG - 2011-04-08 00:47:17 --> Helper loaded: url_helper
DEBUG - 2011-04-08 00:47:17 --> File loaded: application/views/common/header.php
DEBUG - 2011-04-08 00:47:17 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-04-08 00:47:17 --> File loaded: application/views/common/footer.php
DEBUG - 2011-04-08 00:47:17 --> File loaded: application/views/layout/main.php
DEBUG - 2011-04-08 00:47:17 --> Final output sent to browser
DEBUG - 2011-04-08 00:47:17 --> Total execution time: 0.0454
DEBUG - 2011-04-08 00:47:27 --> Config Class Initialized
DEBUG - 2011-04-08 00:47:27 --> Hooks Class Initialized
DEBUG - 2011-04-08 00:47:27 --> Utf8 Class Initialized
DEBUG - 2011-04-08 00:47:27 --> UTF-8 Support Enabled
DEBUG - 2011-04-08 00:47:27 --> URI Class Initialized
DEBUG - 2011-04-08 00:47:27 --> Router Class Initialized
DEBUG - 2011-04-08 00:47:27 --> Output Class Initialized
DEBUG - 2011-04-08 00:47:27 --> Input Class Initialized
DEBUG - 2011-04-08 00:47:27 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-08 00:47:27 --> Language Class Initialized
DEBUG - 2011-04-08 00:47:27 --> Loader Class Initialized
DEBUG - 2011-04-08 00:47:27 --> Controller Class Initialized
DEBUG - 2011-04-08 00:47:27 --> Model Class Initialized
DEBUG - 2011-04-08 00:47:27 --> Model Class Initialized
DEBUG - 2011-04-08 00:47:27 --> Model Class Initialized
DEBUG - 2011-04-08 00:47:27 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-08 00:47:27 --> Database Driver Class Initialized
DEBUG - 2011-04-08 00:47:27 --> File loaded: application/views/table/main.php
DEBUG - 2011-04-08 00:47:27 --> Helper loaded: url_helper
DEBUG - 2011-04-08 00:47:27 --> File loaded: application/views/common/header.php
DEBUG - 2011-04-08 00:47:27 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-04-08 00:47:27 --> File loaded: application/views/common/footer.php
DEBUG - 2011-04-08 00:47:27 --> File loaded: application/views/layout/main.php
DEBUG - 2011-04-08 00:47:27 --> Final output sent to browser
DEBUG - 2011-04-08 00:47:27 --> Total execution time: 0.0449
DEBUG - 2011-04-08 00:47:37 --> Config Class Initialized
DEBUG - 2011-04-08 00:47:37 --> Hooks Class Initialized
DEBUG - 2011-04-08 00:47:37 --> Utf8 Class Initialized
DEBUG - 2011-04-08 00:47:37 --> UTF-8 Support Enabled
DEBUG - 2011-04-08 00:47:37 --> URI Class Initialized
DEBUG - 2011-04-08 00:47:37 --> Router Class Initialized
DEBUG - 2011-04-08 00:47:37 --> Output Class Initialized
DEBUG - 2011-04-08 00:47:37 --> Input Class Initialized
DEBUG - 2011-04-08 00:47:37 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-08 00:47:37 --> Language Class Initialized
DEBUG - 2011-04-08 00:47:37 --> Loader Class Initialized
DEBUG - 2011-04-08 00:47:37 --> Controller Class Initialized
DEBUG - 2011-04-08 00:47:37 --> Model Class Initialized
DEBUG - 2011-04-08 00:47:37 --> Model Class Initialized
DEBUG - 2011-04-08 00:47:37 --> Model Class Initialized
DEBUG - 2011-04-08 00:47:37 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-08 00:47:37 --> Database Driver Class Initialized
DEBUG - 2011-04-08 00:47:37 --> File loaded: application/views/table/main.php
DEBUG - 2011-04-08 00:47:37 --> Helper loaded: url_helper
DEBUG - 2011-04-08 00:47:37 --> File loaded: application/views/common/header.php
DEBUG - 2011-04-08 00:47:37 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-04-08 00:47:37 --> File loaded: application/views/common/footer.php
DEBUG - 2011-04-08 00:47:37 --> File loaded: application/views/layout/main.php
DEBUG - 2011-04-08 00:47:37 --> Final output sent to browser
DEBUG - 2011-04-08 00:47:37 --> Total execution time: 0.1734
DEBUG - 2011-04-08 00:47:43 --> Config Class Initialized
DEBUG - 2011-04-08 00:47:43 --> Hooks Class Initialized
DEBUG - 2011-04-08 00:47:43 --> Utf8 Class Initialized
DEBUG - 2011-04-08 00:47:43 --> UTF-8 Support Enabled
DEBUG - 2011-04-08 00:47:43 --> URI Class Initialized
DEBUG - 2011-04-08 00:47:43 --> Router Class Initialized
DEBUG - 2011-04-08 00:47:43 --> Output Class Initialized
DEBUG - 2011-04-08 00:47:43 --> Input Class Initialized
DEBUG - 2011-04-08 00:47:43 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-08 00:47:43 --> Language Class Initialized
DEBUG - 2011-04-08 00:47:43 --> Loader Class Initialized
DEBUG - 2011-04-08 00:47:43 --> Controller Class Initialized
DEBUG - 2011-04-08 00:47:43 --> Model Class Initialized
DEBUG - 2011-04-08 00:47:43 --> Model Class Initialized
DEBUG - 2011-04-08 00:47:43 --> Model Class Initialized
DEBUG - 2011-04-08 00:47:43 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-08 00:47:43 --> Database Driver Class Initialized
DEBUG - 2011-04-08 00:47:43 --> File loaded: application/views/table/main.php
DEBUG - 2011-04-08 00:47:43 --> Helper loaded: url_helper
DEBUG - 2011-04-08 00:47:43 --> File loaded: application/views/common/header.php
DEBUG - 2011-04-08 00:47:43 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-04-08 00:47:43 --> File loaded: application/views/common/footer.php
DEBUG - 2011-04-08 00:47:43 --> File loaded: application/views/layout/main.php
DEBUG - 2011-04-08 00:47:43 --> Final output sent to browser
DEBUG - 2011-04-08 00:47:43 --> Total execution time: 0.0487
DEBUG - 2011-04-08 00:48:02 --> Config Class Initialized
DEBUG - 2011-04-08 00:48:02 --> Hooks Class Initialized
DEBUG - 2011-04-08 00:48:02 --> Utf8 Class Initialized
DEBUG - 2011-04-08 00:48:02 --> UTF-8 Support Enabled
DEBUG - 2011-04-08 00:48:02 --> URI Class Initialized
DEBUG - 2011-04-08 00:48:02 --> Router Class Initialized
DEBUG - 2011-04-08 00:48:02 --> Output Class Initialized
DEBUG - 2011-04-08 00:48:02 --> Input Class Initialized
DEBUG - 2011-04-08 00:48:02 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-08 00:48:02 --> Language Class Initialized
DEBUG - 2011-04-08 00:48:02 --> Loader Class Initialized
DEBUG - 2011-04-08 00:48:02 --> Controller Class Initialized
DEBUG - 2011-04-08 00:48:02 --> Model Class Initialized
DEBUG - 2011-04-08 00:48:02 --> Model Class Initialized
DEBUG - 2011-04-08 00:48:02 --> Model Class Initialized
DEBUG - 2011-04-08 00:48:02 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-08 00:48:02 --> Database Driver Class Initialized
DEBUG - 2011-04-08 00:48:02 --> File loaded: application/views/table/main.php
DEBUG - 2011-04-08 00:48:02 --> Helper loaded: url_helper
DEBUG - 2011-04-08 00:48:02 --> File loaded: application/views/common/header.php
DEBUG - 2011-04-08 00:48:02 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-04-08 00:48:02 --> File loaded: application/views/common/footer.php
DEBUG - 2011-04-08 00:48:02 --> File loaded: application/views/layout/main.php
DEBUG - 2011-04-08 00:48:02 --> Final output sent to browser
DEBUG - 2011-04-08 00:48:02 --> Total execution time: 0.2002
DEBUG - 2011-04-08 00:48:17 --> Config Class Initialized
DEBUG - 2011-04-08 00:48:17 --> Hooks Class Initialized
DEBUG - 2011-04-08 00:48:17 --> Utf8 Class Initialized
DEBUG - 2011-04-08 00:48:17 --> UTF-8 Support Enabled
DEBUG - 2011-04-08 00:48:17 --> URI Class Initialized
DEBUG - 2011-04-08 00:48:17 --> Router Class Initialized
DEBUG - 2011-04-08 00:48:17 --> Output Class Initialized
DEBUG - 2011-04-08 00:48:17 --> Input Class Initialized
DEBUG - 2011-04-08 00:48:17 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-08 00:48:17 --> Language Class Initialized
DEBUG - 2011-04-08 00:48:17 --> Loader Class Initialized
DEBUG - 2011-04-08 00:48:17 --> Controller Class Initialized
DEBUG - 2011-04-08 00:48:17 --> Model Class Initialized
DEBUG - 2011-04-08 00:48:17 --> Model Class Initialized
DEBUG - 2011-04-08 00:48:17 --> Model Class Initialized
DEBUG - 2011-04-08 00:48:17 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-08 00:48:17 --> Database Driver Class Initialized
DEBUG - 2011-04-08 00:48:17 --> File loaded: application/views/table/main.php
DEBUG - 2011-04-08 00:48:17 --> Helper loaded: url_helper
DEBUG - 2011-04-08 00:48:17 --> File loaded: application/views/common/header.php
DEBUG - 2011-04-08 00:48:17 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-04-08 00:48:17 --> File loaded: application/views/common/footer.php
DEBUG - 2011-04-08 00:48:17 --> File loaded: application/views/layout/main.php
DEBUG - 2011-04-08 00:48:17 --> Final output sent to browser
DEBUG - 2011-04-08 00:48:17 --> Total execution time: 0.2155
DEBUG - 2011-04-08 00:48:28 --> Config Class Initialized
DEBUG - 2011-04-08 00:48:28 --> Hooks Class Initialized
DEBUG - 2011-04-08 00:48:28 --> Utf8 Class Initialized
DEBUG - 2011-04-08 00:48:28 --> UTF-8 Support Enabled
DEBUG - 2011-04-08 00:48:28 --> URI Class Initialized
DEBUG - 2011-04-08 00:48:28 --> Router Class Initialized
DEBUG - 2011-04-08 00:48:28 --> Output Class Initialized
DEBUG - 2011-04-08 00:48:28 --> Input Class Initialized
DEBUG - 2011-04-08 00:48:28 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-08 00:48:28 --> Language Class Initialized
DEBUG - 2011-04-08 00:48:28 --> Loader Class Initialized
DEBUG - 2011-04-08 00:48:28 --> Controller Class Initialized
DEBUG - 2011-04-08 00:48:28 --> Model Class Initialized
DEBUG - 2011-04-08 00:48:28 --> Model Class Initialized
DEBUG - 2011-04-08 00:48:28 --> Model Class Initialized
DEBUG - 2011-04-08 00:48:28 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-08 00:48:28 --> Database Driver Class Initialized
DEBUG - 2011-04-08 00:48:28 --> File loaded: application/views/table/main.php
DEBUG - 2011-04-08 00:48:28 --> Helper loaded: url_helper
DEBUG - 2011-04-08 00:48:28 --> File loaded: application/views/common/header.php
DEBUG - 2011-04-08 00:48:28 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-04-08 00:48:28 --> File loaded: application/views/common/footer.php
DEBUG - 2011-04-08 00:48:28 --> File loaded: application/views/layout/main.php
DEBUG - 2011-04-08 00:48:28 --> Final output sent to browser
DEBUG - 2011-04-08 00:48:28 --> Total execution time: 0.2555
DEBUG - 2011-04-08 00:48:37 --> Config Class Initialized
DEBUG - 2011-04-08 00:48:37 --> Hooks Class Initialized
DEBUG - 2011-04-08 00:48:37 --> Utf8 Class Initialized
DEBUG - 2011-04-08 00:48:37 --> UTF-8 Support Enabled
DEBUG - 2011-04-08 00:48:37 --> URI Class Initialized
DEBUG - 2011-04-08 00:48:37 --> Router Class Initialized
DEBUG - 2011-04-08 00:48:37 --> Output Class Initialized
DEBUG - 2011-04-08 00:48:37 --> Input Class Initialized
DEBUG - 2011-04-08 00:48:37 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-08 00:48:37 --> Language Class Initialized
DEBUG - 2011-04-08 00:48:37 --> Loader Class Initialized
DEBUG - 2011-04-08 00:48:37 --> Controller Class Initialized
DEBUG - 2011-04-08 00:48:37 --> Model Class Initialized
DEBUG - 2011-04-08 00:48:37 --> Model Class Initialized
DEBUG - 2011-04-08 00:48:37 --> Model Class Initialized
DEBUG - 2011-04-08 00:48:37 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-08 00:48:37 --> Database Driver Class Initialized
DEBUG - 2011-04-08 00:48:37 --> File loaded: application/views/table/main.php
DEBUG - 2011-04-08 00:48:37 --> Helper loaded: url_helper
DEBUG - 2011-04-08 00:48:37 --> File loaded: application/views/common/header.php
DEBUG - 2011-04-08 00:48:37 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-04-08 00:48:37 --> File loaded: application/views/common/footer.php
DEBUG - 2011-04-08 00:48:37 --> File loaded: application/views/layout/main.php
DEBUG - 2011-04-08 00:48:37 --> Final output sent to browser
DEBUG - 2011-04-08 00:48:37 --> Total execution time: 0.1920
DEBUG - 2011-04-08 00:48:46 --> Config Class Initialized
DEBUG - 2011-04-08 00:48:46 --> Hooks Class Initialized
DEBUG - 2011-04-08 00:48:46 --> Utf8 Class Initialized
DEBUG - 2011-04-08 00:48:46 --> UTF-8 Support Enabled
DEBUG - 2011-04-08 00:48:46 --> URI Class Initialized
DEBUG - 2011-04-08 00:48:46 --> Router Class Initialized
DEBUG - 2011-04-08 00:48:46 --> Output Class Initialized
DEBUG - 2011-04-08 00:48:46 --> Input Class Initialized
DEBUG - 2011-04-08 00:48:46 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-08 00:48:46 --> Language Class Initialized
DEBUG - 2011-04-08 00:48:46 --> Loader Class Initialized
DEBUG - 2011-04-08 00:48:46 --> Controller Class Initialized
DEBUG - 2011-04-08 00:48:46 --> Model Class Initialized
DEBUG - 2011-04-08 00:48:46 --> Model Class Initialized
DEBUG - 2011-04-08 00:48:46 --> Model Class Initialized
DEBUG - 2011-04-08 00:48:46 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-08 00:48:46 --> Database Driver Class Initialized
DEBUG - 2011-04-08 00:48:47 --> File loaded: application/views/table/main.php
DEBUG - 2011-04-08 00:48:47 --> Helper loaded: url_helper
DEBUG - 2011-04-08 00:48:47 --> File loaded: application/views/common/header.php
DEBUG - 2011-04-08 00:48:47 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-04-08 00:48:47 --> File loaded: application/views/common/footer.php
DEBUG - 2011-04-08 00:48:47 --> File loaded: application/views/layout/main.php
DEBUG - 2011-04-08 00:48:47 --> Final output sent to browser
DEBUG - 2011-04-08 00:48:47 --> Total execution time: 0.2494
DEBUG - 2011-04-08 00:49:12 --> Config Class Initialized
DEBUG - 2011-04-08 00:49:12 --> Hooks Class Initialized
DEBUG - 2011-04-08 00:49:12 --> Utf8 Class Initialized
DEBUG - 2011-04-08 00:49:12 --> UTF-8 Support Enabled
DEBUG - 2011-04-08 00:49:12 --> URI Class Initialized
DEBUG - 2011-04-08 00:49:12 --> Router Class Initialized
DEBUG - 2011-04-08 00:49:12 --> Output Class Initialized
DEBUG - 2011-04-08 00:49:12 --> Input Class Initialized
DEBUG - 2011-04-08 00:49:12 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-08 00:49:12 --> Language Class Initialized
DEBUG - 2011-04-08 00:49:12 --> Loader Class Initialized
DEBUG - 2011-04-08 00:49:12 --> Controller Class Initialized
DEBUG - 2011-04-08 00:49:12 --> Model Class Initialized
DEBUG - 2011-04-08 00:49:12 --> Model Class Initialized
DEBUG - 2011-04-08 00:49:12 --> Model Class Initialized
DEBUG - 2011-04-08 00:49:12 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-08 00:49:13 --> Database Driver Class Initialized
DEBUG - 2011-04-08 00:49:13 --> File loaded: application/views/table/main.php
DEBUG - 2011-04-08 00:49:13 --> Helper loaded: url_helper
DEBUG - 2011-04-08 00:49:13 --> File loaded: application/views/common/header.php
DEBUG - 2011-04-08 00:49:13 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-04-08 00:49:13 --> File loaded: application/views/common/footer.php
DEBUG - 2011-04-08 00:49:13 --> File loaded: application/views/layout/main.php
DEBUG - 2011-04-08 00:49:13 --> Final output sent to browser
DEBUG - 2011-04-08 00:49:13 --> Total execution time: 0.0656
DEBUG - 2011-04-08 00:49:31 --> Config Class Initialized
DEBUG - 2011-04-08 00:49:31 --> Hooks Class Initialized
DEBUG - 2011-04-08 00:49:31 --> Utf8 Class Initialized
DEBUG - 2011-04-08 00:49:31 --> UTF-8 Support Enabled
DEBUG - 2011-04-08 00:49:31 --> URI Class Initialized
DEBUG - 2011-04-08 00:49:31 --> Router Class Initialized
DEBUG - 2011-04-08 00:49:31 --> Output Class Initialized
DEBUG - 2011-04-08 00:49:31 --> Input Class Initialized
DEBUG - 2011-04-08 00:49:31 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-08 00:49:31 --> Language Class Initialized
DEBUG - 2011-04-08 00:49:31 --> Loader Class Initialized
DEBUG - 2011-04-08 00:49:31 --> Controller Class Initialized
DEBUG - 2011-04-08 00:49:31 --> Model Class Initialized
DEBUG - 2011-04-08 00:49:31 --> Model Class Initialized
DEBUG - 2011-04-08 00:49:31 --> Model Class Initialized
DEBUG - 2011-04-08 00:49:31 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-08 00:49:31 --> Database Driver Class Initialized
DEBUG - 2011-04-08 00:49:31 --> File loaded: application/views/table/main.php
DEBUG - 2011-04-08 00:49:31 --> Helper loaded: url_helper
DEBUG - 2011-04-08 00:49:31 --> File loaded: application/views/common/header.php
DEBUG - 2011-04-08 00:49:31 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-04-08 00:49:31 --> File loaded: application/views/common/footer.php
DEBUG - 2011-04-08 00:49:31 --> File loaded: application/views/layout/main.php
DEBUG - 2011-04-08 00:49:31 --> Final output sent to browser
DEBUG - 2011-04-08 00:49:31 --> Total execution time: 0.0454
DEBUG - 2011-04-08 00:49:57 --> Config Class Initialized
DEBUG - 2011-04-08 00:49:57 --> Hooks Class Initialized
DEBUG - 2011-04-08 00:49:57 --> Utf8 Class Initialized
DEBUG - 2011-04-08 00:49:57 --> UTF-8 Support Enabled
DEBUG - 2011-04-08 00:49:57 --> URI Class Initialized
DEBUG - 2011-04-08 00:49:57 --> Router Class Initialized
DEBUG - 2011-04-08 00:49:57 --> Output Class Initialized
DEBUG - 2011-04-08 00:49:57 --> Input Class Initialized
DEBUG - 2011-04-08 00:49:57 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-08 00:49:57 --> Language Class Initialized
DEBUG - 2011-04-08 00:49:57 --> Loader Class Initialized
DEBUG - 2011-04-08 00:49:57 --> Controller Class Initialized
DEBUG - 2011-04-08 00:49:57 --> Model Class Initialized
DEBUG - 2011-04-08 00:49:57 --> Model Class Initialized
DEBUG - 2011-04-08 00:49:57 --> Model Class Initialized
DEBUG - 2011-04-08 00:49:57 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-08 00:49:57 --> Database Driver Class Initialized
DEBUG - 2011-04-08 00:49:57 --> File loaded: application/views/table/main.php
DEBUG - 2011-04-08 00:49:57 --> Helper loaded: url_helper
DEBUG - 2011-04-08 00:49:57 --> File loaded: application/views/common/header.php
DEBUG - 2011-04-08 00:49:57 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-04-08 00:49:57 --> File loaded: application/views/common/footer.php
DEBUG - 2011-04-08 00:49:57 --> File loaded: application/views/layout/main.php
DEBUG - 2011-04-08 00:49:57 --> Final output sent to browser
DEBUG - 2011-04-08 00:49:57 --> Total execution time: 0.4103
DEBUG - 2011-04-08 00:50:07 --> Config Class Initialized
DEBUG - 2011-04-08 00:50:07 --> Hooks Class Initialized
DEBUG - 2011-04-08 00:50:07 --> Utf8 Class Initialized
DEBUG - 2011-04-08 00:50:07 --> UTF-8 Support Enabled
DEBUG - 2011-04-08 00:50:07 --> URI Class Initialized
DEBUG - 2011-04-08 00:50:07 --> Router Class Initialized
DEBUG - 2011-04-08 00:50:07 --> Output Class Initialized
DEBUG - 2011-04-08 00:50:07 --> Input Class Initialized
DEBUG - 2011-04-08 00:50:07 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-08 00:50:07 --> Language Class Initialized
DEBUG - 2011-04-08 00:50:07 --> Loader Class Initialized
DEBUG - 2011-04-08 00:50:07 --> Controller Class Initialized
DEBUG - 2011-04-08 00:50:07 --> Model Class Initialized
DEBUG - 2011-04-08 00:50:07 --> Model Class Initialized
DEBUG - 2011-04-08 00:50:07 --> Model Class Initialized
DEBUG - 2011-04-08 00:50:07 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-08 00:50:07 --> Database Driver Class Initialized
DEBUG - 2011-04-08 00:50:07 --> File loaded: application/views/table/main.php
DEBUG - 2011-04-08 00:50:07 --> Helper loaded: url_helper
DEBUG - 2011-04-08 00:50:07 --> File loaded: application/views/common/header.php
DEBUG - 2011-04-08 00:50:07 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-04-08 00:50:07 --> File loaded: application/views/common/footer.php
DEBUG - 2011-04-08 00:50:07 --> File loaded: application/views/layout/main.php
DEBUG - 2011-04-08 00:50:07 --> Final output sent to browser
DEBUG - 2011-04-08 00:50:07 --> Total execution time: 0.2784
DEBUG - 2011-04-08 00:50:19 --> Config Class Initialized
DEBUG - 2011-04-08 00:50:19 --> Hooks Class Initialized
DEBUG - 2011-04-08 00:50:19 --> Utf8 Class Initialized
DEBUG - 2011-04-08 00:50:19 --> UTF-8 Support Enabled
DEBUG - 2011-04-08 00:50:19 --> URI Class Initialized
DEBUG - 2011-04-08 00:50:19 --> Router Class Initialized
DEBUG - 2011-04-08 00:50:19 --> Output Class Initialized
DEBUG - 2011-04-08 00:50:19 --> Input Class Initialized
DEBUG - 2011-04-08 00:50:19 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-08 00:50:19 --> Language Class Initialized
DEBUG - 2011-04-08 00:50:19 --> Loader Class Initialized
DEBUG - 2011-04-08 00:50:19 --> Controller Class Initialized
DEBUG - 2011-04-08 00:50:19 --> Model Class Initialized
DEBUG - 2011-04-08 00:50:19 --> Model Class Initialized
DEBUG - 2011-04-08 00:50:19 --> Model Class Initialized
DEBUG - 2011-04-08 00:50:19 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-08 00:50:19 --> Database Driver Class Initialized
DEBUG - 2011-04-08 00:50:19 --> File loaded: application/views/table/main.php
DEBUG - 2011-04-08 00:50:19 --> Helper loaded: url_helper
DEBUG - 2011-04-08 00:50:19 --> File loaded: application/views/common/header.php
DEBUG - 2011-04-08 00:50:19 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-04-08 00:50:19 --> File loaded: application/views/common/footer.php
DEBUG - 2011-04-08 00:50:19 --> File loaded: application/views/layout/main.php
DEBUG - 2011-04-08 00:50:19 --> Final output sent to browser
DEBUG - 2011-04-08 00:50:19 --> Total execution time: 0.3013
DEBUG - 2011-04-08 00:50:29 --> Config Class Initialized
DEBUG - 2011-04-08 00:50:29 --> Hooks Class Initialized
DEBUG - 2011-04-08 00:50:29 --> Utf8 Class Initialized
DEBUG - 2011-04-08 00:50:29 --> UTF-8 Support Enabled
DEBUG - 2011-04-08 00:50:29 --> URI Class Initialized
DEBUG - 2011-04-08 00:50:29 --> Router Class Initialized
DEBUG - 2011-04-08 00:50:29 --> Output Class Initialized
DEBUG - 2011-04-08 00:50:29 --> Input Class Initialized
DEBUG - 2011-04-08 00:50:29 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-08 00:50:29 --> Language Class Initialized
DEBUG - 2011-04-08 00:50:29 --> Loader Class Initialized
DEBUG - 2011-04-08 00:50:29 --> Controller Class Initialized
DEBUG - 2011-04-08 00:50:29 --> Model Class Initialized
DEBUG - 2011-04-08 00:50:29 --> Model Class Initialized
DEBUG - 2011-04-08 00:50:29 --> Model Class Initialized
DEBUG - 2011-04-08 00:50:29 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-08 00:50:29 --> Database Driver Class Initialized
DEBUG - 2011-04-08 00:50:29 --> File loaded: application/views/table/main.php
DEBUG - 2011-04-08 00:50:29 --> Helper loaded: url_helper
DEBUG - 2011-04-08 00:50:29 --> File loaded: application/views/common/header.php
DEBUG - 2011-04-08 00:50:29 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-04-08 00:50:29 --> File loaded: application/views/common/footer.php
DEBUG - 2011-04-08 00:50:29 --> File loaded: application/views/layout/main.php
DEBUG - 2011-04-08 00:50:29 --> Final output sent to browser
DEBUG - 2011-04-08 00:50:29 --> Total execution time: 0.2387
DEBUG - 2011-04-08 00:50:44 --> Config Class Initialized
DEBUG - 2011-04-08 00:50:44 --> Hooks Class Initialized
DEBUG - 2011-04-08 00:50:44 --> Utf8 Class Initialized
DEBUG - 2011-04-08 00:50:44 --> UTF-8 Support Enabled
DEBUG - 2011-04-08 00:50:44 --> URI Class Initialized
DEBUG - 2011-04-08 00:50:44 --> Router Class Initialized
DEBUG - 2011-04-08 00:50:44 --> Output Class Initialized
DEBUG - 2011-04-08 00:50:44 --> Input Class Initialized
DEBUG - 2011-04-08 00:50:44 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-08 00:50:44 --> Language Class Initialized
DEBUG - 2011-04-08 00:50:44 --> Loader Class Initialized
DEBUG - 2011-04-08 00:50:44 --> Controller Class Initialized
DEBUG - 2011-04-08 00:50:44 --> Model Class Initialized
DEBUG - 2011-04-08 00:50:44 --> Model Class Initialized
DEBUG - 2011-04-08 00:50:44 --> Model Class Initialized
DEBUG - 2011-04-08 00:50:44 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-08 00:50:44 --> Database Driver Class Initialized
DEBUG - 2011-04-08 00:50:44 --> File loaded: application/views/table/main.php
DEBUG - 2011-04-08 00:50:44 --> Helper loaded: url_helper
DEBUG - 2011-04-08 00:50:44 --> File loaded: application/views/common/header.php
DEBUG - 2011-04-08 00:50:44 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-04-08 00:50:44 --> File loaded: application/views/common/footer.php
DEBUG - 2011-04-08 00:50:44 --> File loaded: application/views/layout/main.php
DEBUG - 2011-04-08 00:50:44 --> Final output sent to browser
DEBUG - 2011-04-08 00:50:44 --> Total execution time: 0.1966
DEBUG - 2011-04-08 00:50:56 --> Config Class Initialized
DEBUG - 2011-04-08 00:50:56 --> Hooks Class Initialized
DEBUG - 2011-04-08 00:50:56 --> Utf8 Class Initialized
DEBUG - 2011-04-08 00:50:56 --> UTF-8 Support Enabled
DEBUG - 2011-04-08 00:50:56 --> URI Class Initialized
DEBUG - 2011-04-08 00:50:56 --> Router Class Initialized
DEBUG - 2011-04-08 00:50:56 --> Output Class Initialized
DEBUG - 2011-04-08 00:50:56 --> Input Class Initialized
DEBUG - 2011-04-08 00:50:56 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-08 00:50:56 --> Language Class Initialized
DEBUG - 2011-04-08 00:50:56 --> Loader Class Initialized
DEBUG - 2011-04-08 00:50:56 --> Controller Class Initialized
DEBUG - 2011-04-08 00:50:56 --> Model Class Initialized
DEBUG - 2011-04-08 00:50:56 --> Model Class Initialized
DEBUG - 2011-04-08 00:50:56 --> Model Class Initialized
DEBUG - 2011-04-08 00:50:56 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-08 00:50:56 --> Database Driver Class Initialized
DEBUG - 2011-04-08 00:50:56 --> File loaded: application/views/table/main.php
DEBUG - 2011-04-08 00:50:56 --> Helper loaded: url_helper
DEBUG - 2011-04-08 00:50:56 --> File loaded: application/views/common/header.php
DEBUG - 2011-04-08 00:50:56 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-04-08 00:50:56 --> File loaded: application/views/common/footer.php
DEBUG - 2011-04-08 00:50:56 --> File loaded: application/views/layout/main.php
DEBUG - 2011-04-08 00:50:56 --> Final output sent to browser
DEBUG - 2011-04-08 00:50:56 --> Total execution time: 0.2588
DEBUG - 2011-04-08 00:51:11 --> Config Class Initialized
DEBUG - 2011-04-08 00:51:11 --> Hooks Class Initialized
DEBUG - 2011-04-08 00:51:11 --> Utf8 Class Initialized
DEBUG - 2011-04-08 00:51:11 --> UTF-8 Support Enabled
DEBUG - 2011-04-08 00:51:11 --> URI Class Initialized
DEBUG - 2011-04-08 00:51:11 --> Router Class Initialized
DEBUG - 2011-04-08 00:51:11 --> Output Class Initialized
DEBUG - 2011-04-08 00:51:11 --> Input Class Initialized
DEBUG - 2011-04-08 00:51:11 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-08 00:51:11 --> Language Class Initialized
DEBUG - 2011-04-08 00:51:11 --> Loader Class Initialized
DEBUG - 2011-04-08 00:51:11 --> Controller Class Initialized
DEBUG - 2011-04-08 00:51:11 --> Model Class Initialized
DEBUG - 2011-04-08 00:51:11 --> Model Class Initialized
DEBUG - 2011-04-08 00:51:11 --> Model Class Initialized
DEBUG - 2011-04-08 00:51:11 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-08 00:51:11 --> Database Driver Class Initialized
DEBUG - 2011-04-08 00:51:11 --> File loaded: application/views/table/main.php
DEBUG - 2011-04-08 00:51:11 --> Helper loaded: url_helper
DEBUG - 2011-04-08 00:51:11 --> File loaded: application/views/common/header.php
DEBUG - 2011-04-08 00:51:11 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-04-08 00:51:11 --> File loaded: application/views/common/footer.php
DEBUG - 2011-04-08 00:51:11 --> File loaded: application/views/layout/main.php
DEBUG - 2011-04-08 00:51:11 --> Final output sent to browser
DEBUG - 2011-04-08 00:51:11 --> Total execution time: 0.2319
DEBUG - 2011-04-08 00:51:21 --> Config Class Initialized
DEBUG - 2011-04-08 00:51:21 --> Hooks Class Initialized
DEBUG - 2011-04-08 00:51:21 --> Utf8 Class Initialized
DEBUG - 2011-04-08 00:51:21 --> UTF-8 Support Enabled
DEBUG - 2011-04-08 00:51:21 --> URI Class Initialized
DEBUG - 2011-04-08 00:51:21 --> Router Class Initialized
DEBUG - 2011-04-08 00:51:21 --> Output Class Initialized
DEBUG - 2011-04-08 00:51:21 --> Input Class Initialized
DEBUG - 2011-04-08 00:51:21 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-08 00:51:21 --> Language Class Initialized
DEBUG - 2011-04-08 00:51:21 --> Loader Class Initialized
DEBUG - 2011-04-08 00:51:21 --> Controller Class Initialized
DEBUG - 2011-04-08 00:51:21 --> Model Class Initialized
DEBUG - 2011-04-08 00:51:21 --> Model Class Initialized
DEBUG - 2011-04-08 00:51:21 --> Model Class Initialized
DEBUG - 2011-04-08 00:51:21 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-08 00:51:21 --> Database Driver Class Initialized
DEBUG - 2011-04-08 00:51:22 --> File loaded: application/views/table/main.php
DEBUG - 2011-04-08 00:51:22 --> Helper loaded: url_helper
DEBUG - 2011-04-08 00:51:22 --> File loaded: application/views/common/header.php
DEBUG - 2011-04-08 00:51:22 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-04-08 00:51:22 --> File loaded: application/views/common/footer.php
DEBUG - 2011-04-08 00:51:22 --> File loaded: application/views/layout/main.php
DEBUG - 2011-04-08 00:51:22 --> Final output sent to browser
DEBUG - 2011-04-08 00:51:22 --> Total execution time: 0.2383
DEBUG - 2011-04-08 00:51:32 --> Config Class Initialized
DEBUG - 2011-04-08 00:51:32 --> Hooks Class Initialized
DEBUG - 2011-04-08 00:51:32 --> Utf8 Class Initialized
DEBUG - 2011-04-08 00:51:32 --> UTF-8 Support Enabled
DEBUG - 2011-04-08 00:51:32 --> URI Class Initialized
DEBUG - 2011-04-08 00:51:32 --> Router Class Initialized
DEBUG - 2011-04-08 00:51:32 --> Output Class Initialized
DEBUG - 2011-04-08 00:51:32 --> Input Class Initialized
DEBUG - 2011-04-08 00:51:32 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-08 00:51:32 --> Language Class Initialized
DEBUG - 2011-04-08 00:51:32 --> Loader Class Initialized
DEBUG - 2011-04-08 00:51:32 --> Controller Class Initialized
DEBUG - 2011-04-08 00:51:32 --> Model Class Initialized
DEBUG - 2011-04-08 00:51:32 --> Model Class Initialized
DEBUG - 2011-04-08 00:51:32 --> Model Class Initialized
DEBUG - 2011-04-08 00:51:32 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-08 00:51:32 --> Database Driver Class Initialized
DEBUG - 2011-04-08 00:51:33 --> File loaded: application/views/table/main.php
DEBUG - 2011-04-08 00:51:33 --> Helper loaded: url_helper
DEBUG - 2011-04-08 00:51:33 --> File loaded: application/views/common/header.php
DEBUG - 2011-04-08 00:51:33 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-04-08 00:51:33 --> File loaded: application/views/common/footer.php
DEBUG - 2011-04-08 00:51:33 --> File loaded: application/views/layout/main.php
DEBUG - 2011-04-08 00:51:33 --> Final output sent to browser
DEBUG - 2011-04-08 00:51:33 --> Total execution time: 0.8087
DEBUG - 2011-04-08 00:51:53 --> Config Class Initialized
DEBUG - 2011-04-08 00:51:53 --> Hooks Class Initialized
DEBUG - 2011-04-08 00:51:53 --> Utf8 Class Initialized
DEBUG - 2011-04-08 00:51:53 --> UTF-8 Support Enabled
DEBUG - 2011-04-08 00:51:53 --> URI Class Initialized
DEBUG - 2011-04-08 00:51:53 --> Router Class Initialized
DEBUG - 2011-04-08 00:51:53 --> Output Class Initialized
DEBUG - 2011-04-08 00:51:53 --> Input Class Initialized
DEBUG - 2011-04-08 00:51:53 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-08 00:51:53 --> Language Class Initialized
DEBUG - 2011-04-08 00:51:53 --> Loader Class Initialized
DEBUG - 2011-04-08 00:51:53 --> Controller Class Initialized
DEBUG - 2011-04-08 00:51:53 --> Model Class Initialized
DEBUG - 2011-04-08 00:51:53 --> Model Class Initialized
DEBUG - 2011-04-08 00:51:53 --> Model Class Initialized
DEBUG - 2011-04-08 00:51:53 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-08 00:51:53 --> Database Driver Class Initialized
DEBUG - 2011-04-08 00:51:53 --> File loaded: application/views/table/main.php
DEBUG - 2011-04-08 00:51:53 --> Helper loaded: url_helper
DEBUG - 2011-04-08 00:51:53 --> File loaded: application/views/common/header.php
DEBUG - 2011-04-08 00:51:53 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-04-08 00:51:53 --> File loaded: application/views/common/footer.php
DEBUG - 2011-04-08 00:51:53 --> File loaded: application/views/layout/main.php
DEBUG - 2011-04-08 00:51:53 --> Final output sent to browser
DEBUG - 2011-04-08 00:51:53 --> Total execution time: 0.2607
DEBUG - 2011-04-08 01:11:56 --> Config Class Initialized
DEBUG - 2011-04-08 01:11:56 --> Hooks Class Initialized
DEBUG - 2011-04-08 01:11:56 --> Utf8 Class Initialized
DEBUG - 2011-04-08 01:11:56 --> UTF-8 Support Enabled
DEBUG - 2011-04-08 01:11:56 --> URI Class Initialized
DEBUG - 2011-04-08 01:11:56 --> Router Class Initialized
DEBUG - 2011-04-08 01:11:56 --> Output Class Initialized
DEBUG - 2011-04-08 01:11:56 --> Input Class Initialized
DEBUG - 2011-04-08 01:11:56 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-08 01:11:56 --> Language Class Initialized
DEBUG - 2011-04-08 01:11:56 --> Loader Class Initialized
DEBUG - 2011-04-08 01:11:56 --> Controller Class Initialized
ERROR - 2011-04-08 01:11:56 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-04-08 01:11:56 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-04-08 01:11:56 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-04-08 01:11:56 --> Model Class Initialized
DEBUG - 2011-04-08 01:11:56 --> Model Class Initialized
DEBUG - 2011-04-08 01:11:56 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-08 01:11:56 --> Database Driver Class Initialized
DEBUG - 2011-04-08 01:11:56 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-04-08 01:11:56 --> Helper loaded: url_helper
DEBUG - 2011-04-08 01:11:56 --> File loaded: application/views/common/header.php
DEBUG - 2011-04-08 01:11:56 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-04-08 01:11:56 --> File loaded: application/views/common/footer.php
DEBUG - 2011-04-08 01:11:56 --> File loaded: application/views/layout/main.php
DEBUG - 2011-04-08 01:11:56 --> Final output sent to browser
DEBUG - 2011-04-08 01:11:56 --> Total execution time: 0.0871
DEBUG - 2011-04-08 01:29:10 --> Config Class Initialized
DEBUG - 2011-04-08 01:29:10 --> Hooks Class Initialized
DEBUG - 2011-04-08 01:29:10 --> Utf8 Class Initialized
DEBUG - 2011-04-08 01:29:10 --> UTF-8 Support Enabled
DEBUG - 2011-04-08 01:29:10 --> URI Class Initialized
DEBUG - 2011-04-08 01:29:10 --> Router Class Initialized
DEBUG - 2011-04-08 01:29:10 --> Output Class Initialized
DEBUG - 2011-04-08 01:29:10 --> Input Class Initialized
DEBUG - 2011-04-08 01:29:10 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-08 01:29:10 --> Language Class Initialized
DEBUG - 2011-04-08 01:29:10 --> Loader Class Initialized
DEBUG - 2011-04-08 01:29:10 --> Controller Class Initialized
DEBUG - 2011-04-08 01:29:10 --> Model Class Initialized
DEBUG - 2011-04-08 01:29:10 --> Model Class Initialized
DEBUG - 2011-04-08 01:29:10 --> Model Class Initialized
DEBUG - 2011-04-08 01:29:10 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-08 01:29:10 --> Database Driver Class Initialized
DEBUG - 2011-04-08 01:29:10 --> File loaded: application/views/table/main.php
DEBUG - 2011-04-08 01:29:10 --> Helper loaded: url_helper
DEBUG - 2011-04-08 01:29:10 --> File loaded: application/views/common/header.php
DEBUG - 2011-04-08 01:29:10 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-04-08 01:29:10 --> File loaded: application/views/common/footer.php
DEBUG - 2011-04-08 01:29:10 --> File loaded: application/views/layout/main.php
DEBUG - 2011-04-08 01:29:10 --> Final output sent to browser
DEBUG - 2011-04-08 01:29:10 --> Total execution time: 0.2925
DEBUG - 2011-04-08 01:29:11 --> Config Class Initialized
DEBUG - 2011-04-08 01:29:11 --> Hooks Class Initialized
DEBUG - 2011-04-08 01:29:11 --> Utf8 Class Initialized
DEBUG - 2011-04-08 01:29:11 --> UTF-8 Support Enabled
DEBUG - 2011-04-08 01:29:11 --> URI Class Initialized
DEBUG - 2011-04-08 01:29:11 --> Router Class Initialized
ERROR - 2011-04-08 01:29:11 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-04-08 01:29:12 --> Config Class Initialized
DEBUG - 2011-04-08 01:29:12 --> Hooks Class Initialized
DEBUG - 2011-04-08 01:29:12 --> Utf8 Class Initialized
DEBUG - 2011-04-08 01:29:12 --> UTF-8 Support Enabled
DEBUG - 2011-04-08 01:29:12 --> URI Class Initialized
DEBUG - 2011-04-08 01:29:12 --> Router Class Initialized
ERROR - 2011-04-08 01:29:12 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-04-08 01:29:27 --> Config Class Initialized
DEBUG - 2011-04-08 01:29:27 --> Hooks Class Initialized
DEBUG - 2011-04-08 01:29:27 --> Utf8 Class Initialized
DEBUG - 2011-04-08 01:29:27 --> UTF-8 Support Enabled
DEBUG - 2011-04-08 01:29:27 --> URI Class Initialized
DEBUG - 2011-04-08 01:29:27 --> Router Class Initialized
DEBUG - 2011-04-08 01:29:27 --> Output Class Initialized
DEBUG - 2011-04-08 01:29:27 --> Input Class Initialized
DEBUG - 2011-04-08 01:29:27 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-08 01:29:27 --> Language Class Initialized
DEBUG - 2011-04-08 01:29:27 --> Loader Class Initialized
DEBUG - 2011-04-08 01:29:27 --> Controller Class Initialized
DEBUG - 2011-04-08 01:29:27 --> Model Class Initialized
DEBUG - 2011-04-08 01:29:27 --> Model Class Initialized
DEBUG - 2011-04-08 01:29:27 --> Model Class Initialized
DEBUG - 2011-04-08 01:29:27 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-08 01:29:27 --> Database Driver Class Initialized
DEBUG - 2011-04-08 01:29:27 --> File loaded: application/views/table/main.php
DEBUG - 2011-04-08 01:29:27 --> Helper loaded: url_helper
DEBUG - 2011-04-08 01:29:27 --> File loaded: application/views/common/header.php
DEBUG - 2011-04-08 01:29:27 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-04-08 01:29:27 --> File loaded: application/views/common/footer.php
DEBUG - 2011-04-08 01:29:27 --> File loaded: application/views/layout/main.php
DEBUG - 2011-04-08 01:29:27 --> Final output sent to browser
DEBUG - 2011-04-08 01:29:27 --> Total execution time: 0.2321
DEBUG - 2011-04-08 01:29:28 --> Config Class Initialized
DEBUG - 2011-04-08 01:29:28 --> Hooks Class Initialized
DEBUG - 2011-04-08 01:29:28 --> Utf8 Class Initialized
DEBUG - 2011-04-08 01:29:28 --> UTF-8 Support Enabled
DEBUG - 2011-04-08 01:29:28 --> URI Class Initialized
DEBUG - 2011-04-08 01:29:28 --> Router Class Initialized
ERROR - 2011-04-08 01:29:28 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-04-08 01:29:34 --> Config Class Initialized
DEBUG - 2011-04-08 01:29:34 --> Hooks Class Initialized
DEBUG - 2011-04-08 01:29:34 --> Utf8 Class Initialized
DEBUG - 2011-04-08 01:29:34 --> UTF-8 Support Enabled
DEBUG - 2011-04-08 01:29:34 --> URI Class Initialized
DEBUG - 2011-04-08 01:29:34 --> Router Class Initialized
DEBUG - 2011-04-08 01:29:34 --> Output Class Initialized
DEBUG - 2011-04-08 01:29:34 --> Input Class Initialized
DEBUG - 2011-04-08 01:29:34 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-08 01:29:34 --> Language Class Initialized
DEBUG - 2011-04-08 01:29:34 --> Loader Class Initialized
DEBUG - 2011-04-08 01:29:34 --> Controller Class Initialized
DEBUG - 2011-04-08 01:29:34 --> Model Class Initialized
DEBUG - 2011-04-08 01:29:34 --> Model Class Initialized
DEBUG - 2011-04-08 01:29:34 --> Model Class Initialized
DEBUG - 2011-04-08 01:29:34 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-08 01:29:35 --> Database Driver Class Initialized
DEBUG - 2011-04-08 01:29:35 --> File loaded: application/views/table/main.php
DEBUG - 2011-04-08 01:29:35 --> Helper loaded: url_helper
DEBUG - 2011-04-08 01:29:35 --> File loaded: application/views/common/header.php
DEBUG - 2011-04-08 01:29:35 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-04-08 01:29:35 --> File loaded: application/views/common/footer.php
DEBUG - 2011-04-08 01:29:35 --> File loaded: application/views/layout/main.php
DEBUG - 2011-04-08 01:29:35 --> Final output sent to browser
DEBUG - 2011-04-08 01:29:35 --> Total execution time: 0.0487
DEBUG - 2011-04-08 01:29:54 --> Config Class Initialized
DEBUG - 2011-04-08 01:29:54 --> Hooks Class Initialized
DEBUG - 2011-04-08 01:29:54 --> Utf8 Class Initialized
DEBUG - 2011-04-08 01:29:54 --> UTF-8 Support Enabled
DEBUG - 2011-04-08 01:29:54 --> URI Class Initialized
DEBUG - 2011-04-08 01:29:54 --> Router Class Initialized
DEBUG - 2011-04-08 01:29:54 --> Output Class Initialized
DEBUG - 2011-04-08 01:29:54 --> Input Class Initialized
DEBUG - 2011-04-08 01:29:54 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-08 01:29:54 --> Language Class Initialized
DEBUG - 2011-04-08 01:29:54 --> Loader Class Initialized
DEBUG - 2011-04-08 01:29:54 --> Controller Class Initialized
DEBUG - 2011-04-08 01:29:54 --> Model Class Initialized
DEBUG - 2011-04-08 01:29:54 --> Model Class Initialized
DEBUG - 2011-04-08 01:29:54 --> Model Class Initialized
DEBUG - 2011-04-08 01:29:54 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-08 01:29:54 --> Database Driver Class Initialized
DEBUG - 2011-04-08 01:29:54 --> File loaded: application/views/table/main.php
DEBUG - 2011-04-08 01:29:54 --> Helper loaded: url_helper
DEBUG - 2011-04-08 01:29:54 --> File loaded: application/views/common/header.php
DEBUG - 2011-04-08 01:29:54 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-04-08 01:29:54 --> File loaded: application/views/common/footer.php
DEBUG - 2011-04-08 01:29:54 --> File loaded: application/views/layout/main.php
DEBUG - 2011-04-08 01:29:54 --> Final output sent to browser
DEBUG - 2011-04-08 01:29:54 --> Total execution time: 0.2382
DEBUG - 2011-04-08 01:29:55 --> Config Class Initialized
DEBUG - 2011-04-08 01:29:55 --> Hooks Class Initialized
DEBUG - 2011-04-08 01:29:55 --> Utf8 Class Initialized
DEBUG - 2011-04-08 01:29:55 --> UTF-8 Support Enabled
DEBUG - 2011-04-08 01:29:55 --> URI Class Initialized
DEBUG - 2011-04-08 01:29:55 --> Router Class Initialized
ERROR - 2011-04-08 01:29:55 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-04-08 01:29:56 --> Config Class Initialized
DEBUG - 2011-04-08 01:29:56 --> Hooks Class Initialized
DEBUG - 2011-04-08 01:29:56 --> Utf8 Class Initialized
DEBUG - 2011-04-08 01:29:56 --> UTF-8 Support Enabled
DEBUG - 2011-04-08 01:29:56 --> URI Class Initialized
DEBUG - 2011-04-08 01:29:56 --> Router Class Initialized
DEBUG - 2011-04-08 01:29:56 --> Output Class Initialized
DEBUG - 2011-04-08 01:29:56 --> Input Class Initialized
DEBUG - 2011-04-08 01:29:56 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-08 01:29:56 --> Language Class Initialized
DEBUG - 2011-04-08 01:29:56 --> Loader Class Initialized
DEBUG - 2011-04-08 01:29:56 --> Controller Class Initialized
DEBUG - 2011-04-08 01:29:56 --> Model Class Initialized
DEBUG - 2011-04-08 01:29:56 --> Model Class Initialized
DEBUG - 2011-04-08 01:29:56 --> Model Class Initialized
DEBUG - 2011-04-08 01:29:56 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-08 01:29:56 --> Database Driver Class Initialized
DEBUG - 2011-04-08 01:29:56 --> File loaded: application/views/table/main.php
DEBUG - 2011-04-08 01:29:56 --> Helper loaded: url_helper
DEBUG - 2011-04-08 01:29:56 --> File loaded: application/views/common/header.php
DEBUG - 2011-04-08 01:29:56 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-04-08 01:29:56 --> File loaded: application/views/common/footer.php
DEBUG - 2011-04-08 01:29:56 --> File loaded: application/views/layout/main.php
DEBUG - 2011-04-08 01:29:56 --> Final output sent to browser
DEBUG - 2011-04-08 01:29:56 --> Total execution time: 0.0439
DEBUG - 2011-04-08 01:30:10 --> Config Class Initialized
DEBUG - 2011-04-08 01:30:10 --> Hooks Class Initialized
DEBUG - 2011-04-08 01:30:10 --> Utf8 Class Initialized
DEBUG - 2011-04-08 01:30:10 --> UTF-8 Support Enabled
DEBUG - 2011-04-08 01:30:10 --> URI Class Initialized
DEBUG - 2011-04-08 01:30:10 --> Router Class Initialized
DEBUG - 2011-04-08 01:30:10 --> Output Class Initialized
DEBUG - 2011-04-08 01:30:10 --> Input Class Initialized
DEBUG - 2011-04-08 01:30:10 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-08 01:30:10 --> Language Class Initialized
DEBUG - 2011-04-08 01:30:10 --> Loader Class Initialized
DEBUG - 2011-04-08 01:30:10 --> Controller Class Initialized
DEBUG - 2011-04-08 01:30:10 --> Model Class Initialized
DEBUG - 2011-04-08 01:30:10 --> Model Class Initialized
DEBUG - 2011-04-08 01:30:10 --> Model Class Initialized
DEBUG - 2011-04-08 01:30:10 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-08 01:30:10 --> Database Driver Class Initialized
DEBUG - 2011-04-08 01:30:10 --> File loaded: application/views/table/main.php
DEBUG - 2011-04-08 01:30:10 --> Helper loaded: url_helper
DEBUG - 2011-04-08 01:30:10 --> File loaded: application/views/common/header.php
DEBUG - 2011-04-08 01:30:10 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-04-08 01:30:10 --> File loaded: application/views/common/footer.php
DEBUG - 2011-04-08 01:30:10 --> File loaded: application/views/layout/main.php
DEBUG - 2011-04-08 01:30:10 --> Final output sent to browser
DEBUG - 2011-04-08 01:30:10 --> Total execution time: 0.2054
DEBUG - 2011-04-08 01:30:11 --> Config Class Initialized
DEBUG - 2011-04-08 01:30:11 --> Hooks Class Initialized
DEBUG - 2011-04-08 01:30:11 --> Utf8 Class Initialized
DEBUG - 2011-04-08 01:30:11 --> UTF-8 Support Enabled
DEBUG - 2011-04-08 01:30:11 --> URI Class Initialized
DEBUG - 2011-04-08 01:30:11 --> Router Class Initialized
ERROR - 2011-04-08 01:30:11 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-04-08 01:30:12 --> Config Class Initialized
DEBUG - 2011-04-08 01:30:12 --> Hooks Class Initialized
DEBUG - 2011-04-08 01:30:12 --> Utf8 Class Initialized
DEBUG - 2011-04-08 01:30:12 --> UTF-8 Support Enabled
DEBUG - 2011-04-08 01:30:12 --> URI Class Initialized
DEBUG - 2011-04-08 01:30:12 --> Router Class Initialized
DEBUG - 2011-04-08 01:30:12 --> Output Class Initialized
DEBUG - 2011-04-08 01:30:12 --> Input Class Initialized
DEBUG - 2011-04-08 01:30:12 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-08 01:30:12 --> Language Class Initialized
DEBUG - 2011-04-08 01:30:12 --> Loader Class Initialized
DEBUG - 2011-04-08 01:30:12 --> Controller Class Initialized
DEBUG - 2011-04-08 01:30:12 --> Model Class Initialized
DEBUG - 2011-04-08 01:30:12 --> Model Class Initialized
DEBUG - 2011-04-08 01:30:12 --> Model Class Initialized
DEBUG - 2011-04-08 01:30:12 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-08 01:30:12 --> Database Driver Class Initialized
DEBUG - 2011-04-08 01:30:12 --> File loaded: application/views/table/main.php
DEBUG - 2011-04-08 01:30:12 --> Helper loaded: url_helper
DEBUG - 2011-04-08 01:30:12 --> File loaded: application/views/common/header.php
DEBUG - 2011-04-08 01:30:12 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-04-08 01:30:12 --> File loaded: application/views/common/footer.php
DEBUG - 2011-04-08 01:30:12 --> File loaded: application/views/layout/main.php
DEBUG - 2011-04-08 01:30:12 --> Final output sent to browser
DEBUG - 2011-04-08 01:30:12 --> Total execution time: 0.0555
DEBUG - 2011-04-08 01:30:27 --> Config Class Initialized
DEBUG - 2011-04-08 01:30:27 --> Hooks Class Initialized
DEBUG - 2011-04-08 01:30:27 --> Utf8 Class Initialized
DEBUG - 2011-04-08 01:30:27 --> UTF-8 Support Enabled
DEBUG - 2011-04-08 01:30:27 --> URI Class Initialized
DEBUG - 2011-04-08 01:30:27 --> Router Class Initialized
DEBUG - 2011-04-08 01:30:27 --> Output Class Initialized
DEBUG - 2011-04-08 01:30:27 --> Input Class Initialized
DEBUG - 2011-04-08 01:30:27 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-08 01:30:27 --> Language Class Initialized
DEBUG - 2011-04-08 01:30:27 --> Loader Class Initialized
DEBUG - 2011-04-08 01:30:27 --> Controller Class Initialized
DEBUG - 2011-04-08 01:30:27 --> Model Class Initialized
DEBUG - 2011-04-08 01:30:27 --> Model Class Initialized
DEBUG - 2011-04-08 01:30:27 --> Model Class Initialized
DEBUG - 2011-04-08 01:30:27 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-08 01:30:27 --> Database Driver Class Initialized
DEBUG - 2011-04-08 01:30:27 --> File loaded: application/views/table/main.php
DEBUG - 2011-04-08 01:30:27 --> Helper loaded: url_helper
DEBUG - 2011-04-08 01:30:27 --> File loaded: application/views/common/header.php
DEBUG - 2011-04-08 01:30:27 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-04-08 01:30:27 --> File loaded: application/views/common/footer.php
DEBUG - 2011-04-08 01:30:27 --> File loaded: application/views/layout/main.php
DEBUG - 2011-04-08 01:30:27 --> Final output sent to browser
DEBUG - 2011-04-08 01:30:27 --> Total execution time: 0.2199
DEBUG - 2011-04-08 01:30:28 --> Config Class Initialized
DEBUG - 2011-04-08 01:30:28 --> Hooks Class Initialized
DEBUG - 2011-04-08 01:30:28 --> Utf8 Class Initialized
DEBUG - 2011-04-08 01:30:28 --> UTF-8 Support Enabled
DEBUG - 2011-04-08 01:30:28 --> URI Class Initialized
DEBUG - 2011-04-08 01:30:28 --> Router Class Initialized
DEBUG - 2011-04-08 01:30:28 --> Output Class Initialized
DEBUG - 2011-04-08 01:30:28 --> Input Class Initialized
DEBUG - 2011-04-08 01:30:28 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-08 01:30:28 --> Language Class Initialized
DEBUG - 2011-04-08 01:30:28 --> Loader Class Initialized
DEBUG - 2011-04-08 01:30:28 --> Controller Class Initialized
DEBUG - 2011-04-08 01:30:28 --> Model Class Initialized
DEBUG - 2011-04-08 01:30:28 --> Model Class Initialized
DEBUG - 2011-04-08 01:30:28 --> Model Class Initialized
DEBUG - 2011-04-08 01:30:28 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-08 01:30:28 --> Database Driver Class Initialized
DEBUG - 2011-04-08 01:30:28 --> File loaded: application/views/table/main.php
DEBUG - 2011-04-08 01:30:28 --> Helper loaded: url_helper
DEBUG - 2011-04-08 01:30:28 --> File loaded: application/views/common/header.php
DEBUG - 2011-04-08 01:30:28 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-04-08 01:30:28 --> File loaded: application/views/common/footer.php
DEBUG - 2011-04-08 01:30:28 --> File loaded: application/views/layout/main.php
DEBUG - 2011-04-08 01:30:28 --> Final output sent to browser
DEBUG - 2011-04-08 01:30:28 --> Total execution time: 0.0428
DEBUG - 2011-04-08 01:30:28 --> Config Class Initialized
DEBUG - 2011-04-08 01:30:28 --> Hooks Class Initialized
DEBUG - 2011-04-08 01:30:28 --> Utf8 Class Initialized
DEBUG - 2011-04-08 01:30:28 --> UTF-8 Support Enabled
DEBUG - 2011-04-08 01:30:28 --> URI Class Initialized
DEBUG - 2011-04-08 01:30:28 --> Router Class Initialized
ERROR - 2011-04-08 01:30:28 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-04-08 01:30:44 --> Config Class Initialized
DEBUG - 2011-04-08 01:30:44 --> Hooks Class Initialized
DEBUG - 2011-04-08 01:30:44 --> Utf8 Class Initialized
DEBUG - 2011-04-08 01:30:44 --> UTF-8 Support Enabled
DEBUG - 2011-04-08 01:30:44 --> URI Class Initialized
DEBUG - 2011-04-08 01:30:44 --> Router Class Initialized
DEBUG - 2011-04-08 01:30:44 --> Output Class Initialized
DEBUG - 2011-04-08 01:30:44 --> Input Class Initialized
DEBUG - 2011-04-08 01:30:44 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-08 01:30:44 --> Language Class Initialized
DEBUG - 2011-04-08 01:30:44 --> Loader Class Initialized
DEBUG - 2011-04-08 01:30:44 --> Controller Class Initialized
DEBUG - 2011-04-08 01:30:44 --> Model Class Initialized
DEBUG - 2011-04-08 01:30:44 --> Model Class Initialized
DEBUG - 2011-04-08 01:30:44 --> Model Class Initialized
DEBUG - 2011-04-08 01:30:44 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-08 01:30:44 --> Database Driver Class Initialized
DEBUG - 2011-04-08 01:30:44 --> File loaded: application/views/table/main.php
DEBUG - 2011-04-08 01:30:44 --> Helper loaded: url_helper
DEBUG - 2011-04-08 01:30:44 --> File loaded: application/views/common/header.php
DEBUG - 2011-04-08 01:30:44 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-04-08 01:30:44 --> File loaded: application/views/common/footer.php
DEBUG - 2011-04-08 01:30:44 --> File loaded: application/views/layout/main.php
DEBUG - 2011-04-08 01:30:44 --> Final output sent to browser
DEBUG - 2011-04-08 01:30:44 --> Total execution time: 0.1915
DEBUG - 2011-04-08 01:30:45 --> Config Class Initialized
DEBUG - 2011-04-08 01:30:45 --> Hooks Class Initialized
DEBUG - 2011-04-08 01:30:45 --> Utf8 Class Initialized
DEBUG - 2011-04-08 01:30:45 --> UTF-8 Support Enabled
DEBUG - 2011-04-08 01:30:45 --> URI Class Initialized
DEBUG - 2011-04-08 01:30:45 --> Router Class Initialized
ERROR - 2011-04-08 01:30:45 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-04-08 01:30:46 --> Config Class Initialized
DEBUG - 2011-04-08 01:30:46 --> Hooks Class Initialized
DEBUG - 2011-04-08 01:30:46 --> Utf8 Class Initialized
DEBUG - 2011-04-08 01:30:46 --> UTF-8 Support Enabled
DEBUG - 2011-04-08 01:30:46 --> URI Class Initialized
DEBUG - 2011-04-08 01:30:46 --> Router Class Initialized
DEBUG - 2011-04-08 01:30:46 --> Output Class Initialized
DEBUG - 2011-04-08 01:30:46 --> Input Class Initialized
DEBUG - 2011-04-08 01:30:46 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-08 01:30:46 --> Language Class Initialized
DEBUG - 2011-04-08 01:30:46 --> Loader Class Initialized
DEBUG - 2011-04-08 01:30:46 --> Controller Class Initialized
DEBUG - 2011-04-08 01:30:46 --> Model Class Initialized
DEBUG - 2011-04-08 01:30:46 --> Model Class Initialized
DEBUG - 2011-04-08 01:30:46 --> Model Class Initialized
DEBUG - 2011-04-08 01:30:46 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-08 01:30:46 --> Database Driver Class Initialized
DEBUG - 2011-04-08 01:30:46 --> File loaded: application/views/table/main.php
DEBUG - 2011-04-08 01:30:46 --> Helper loaded: url_helper
DEBUG - 2011-04-08 01:30:46 --> File loaded: application/views/common/header.php
DEBUG - 2011-04-08 01:30:46 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-04-08 01:30:46 --> File loaded: application/views/common/footer.php
DEBUG - 2011-04-08 01:30:46 --> File loaded: application/views/layout/main.php
DEBUG - 2011-04-08 01:30:46 --> Final output sent to browser
DEBUG - 2011-04-08 01:30:46 --> Total execution time: 0.0419
DEBUG - 2011-04-08 01:30:53 --> Config Class Initialized
DEBUG - 2011-04-08 01:30:53 --> Hooks Class Initialized
DEBUG - 2011-04-08 01:30:53 --> Utf8 Class Initialized
DEBUG - 2011-04-08 01:30:53 --> UTF-8 Support Enabled
DEBUG - 2011-04-08 01:30:53 --> URI Class Initialized
DEBUG - 2011-04-08 01:30:53 --> Router Class Initialized
DEBUG - 2011-04-08 01:30:53 --> Output Class Initialized
DEBUG - 2011-04-08 01:30:53 --> Input Class Initialized
DEBUG - 2011-04-08 01:30:53 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-08 01:30:53 --> Language Class Initialized
DEBUG - 2011-04-08 01:30:53 --> Loader Class Initialized
DEBUG - 2011-04-08 01:30:53 --> Controller Class Initialized
DEBUG - 2011-04-08 01:30:53 --> Model Class Initialized
DEBUG - 2011-04-08 01:30:53 --> Model Class Initialized
DEBUG - 2011-04-08 01:30:53 --> Model Class Initialized
DEBUG - 2011-04-08 01:30:53 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-08 01:30:53 --> Database Driver Class Initialized
DEBUG - 2011-04-08 01:30:54 --> File loaded: application/views/table/main.php
DEBUG - 2011-04-08 01:30:54 --> Helper loaded: url_helper
DEBUG - 2011-04-08 01:30:54 --> File loaded: application/views/common/header.php
DEBUG - 2011-04-08 01:30:54 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-04-08 01:30:54 --> File loaded: application/views/common/footer.php
DEBUG - 2011-04-08 01:30:54 --> File loaded: application/views/layout/main.php
DEBUG - 2011-04-08 01:30:54 --> Final output sent to browser
DEBUG - 2011-04-08 01:30:54 --> Total execution time: 0.1963
DEBUG - 2011-04-08 01:30:54 --> Config Class Initialized
DEBUG - 2011-04-08 01:30:54 --> Hooks Class Initialized
DEBUG - 2011-04-08 01:30:54 --> Utf8 Class Initialized
DEBUG - 2011-04-08 01:30:54 --> UTF-8 Support Enabled
DEBUG - 2011-04-08 01:30:54 --> URI Class Initialized
DEBUG - 2011-04-08 01:30:54 --> Router Class Initialized
DEBUG - 2011-04-08 01:30:54 --> Output Class Initialized
DEBUG - 2011-04-08 01:30:55 --> Input Class Initialized
DEBUG - 2011-04-08 01:30:55 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-08 01:30:55 --> Language Class Initialized
DEBUG - 2011-04-08 01:30:55 --> Loader Class Initialized
DEBUG - 2011-04-08 01:30:55 --> Controller Class Initialized
DEBUG - 2011-04-08 01:30:55 --> Model Class Initialized
DEBUG - 2011-04-08 01:30:55 --> Model Class Initialized
DEBUG - 2011-04-08 01:30:55 --> Model Class Initialized
DEBUG - 2011-04-08 01:30:55 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-08 01:30:55 --> Database Driver Class Initialized
DEBUG - 2011-04-08 01:30:55 --> File loaded: application/views/table/main.php
DEBUG - 2011-04-08 01:30:55 --> Helper loaded: url_helper
DEBUG - 2011-04-08 01:30:55 --> File loaded: application/views/common/header.php
DEBUG - 2011-04-08 01:30:55 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-04-08 01:30:55 --> File loaded: application/views/common/footer.php
DEBUG - 2011-04-08 01:30:55 --> File loaded: application/views/layout/main.php
DEBUG - 2011-04-08 01:30:55 --> Final output sent to browser
DEBUG - 2011-04-08 01:30:55 --> Total execution time: 0.0598
DEBUG - 2011-04-08 01:30:55 --> Config Class Initialized
DEBUG - 2011-04-08 01:30:55 --> Hooks Class Initialized
DEBUG - 2011-04-08 01:30:55 --> Utf8 Class Initialized
DEBUG - 2011-04-08 01:30:55 --> UTF-8 Support Enabled
DEBUG - 2011-04-08 01:30:55 --> URI Class Initialized
DEBUG - 2011-04-08 01:30:55 --> Router Class Initialized
ERROR - 2011-04-08 01:30:55 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-04-08 01:31:09 --> Config Class Initialized
DEBUG - 2011-04-08 01:31:09 --> Hooks Class Initialized
DEBUG - 2011-04-08 01:31:09 --> Utf8 Class Initialized
DEBUG - 2011-04-08 01:31:09 --> UTF-8 Support Enabled
DEBUG - 2011-04-08 01:31:09 --> URI Class Initialized
DEBUG - 2011-04-08 01:31:09 --> Router Class Initialized
DEBUG - 2011-04-08 01:31:09 --> Output Class Initialized
DEBUG - 2011-04-08 01:31:09 --> Input Class Initialized
DEBUG - 2011-04-08 01:31:09 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-08 01:31:09 --> Language Class Initialized
DEBUG - 2011-04-08 01:31:09 --> Loader Class Initialized
DEBUG - 2011-04-08 01:31:09 --> Controller Class Initialized
DEBUG - 2011-04-08 01:31:09 --> Model Class Initialized
DEBUG - 2011-04-08 01:31:09 --> Model Class Initialized
DEBUG - 2011-04-08 01:31:09 --> Model Class Initialized
DEBUG - 2011-04-08 01:31:09 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-08 01:31:09 --> Database Driver Class Initialized
DEBUG - 2011-04-08 01:31:09 --> File loaded: application/views/table/main.php
DEBUG - 2011-04-08 01:31:09 --> Helper loaded: url_helper
DEBUG - 2011-04-08 01:31:09 --> File loaded: application/views/common/header.php
DEBUG - 2011-04-08 01:31:09 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-04-08 01:31:09 --> File loaded: application/views/common/footer.php
DEBUG - 2011-04-08 01:31:09 --> File loaded: application/views/layout/main.php
DEBUG - 2011-04-08 01:31:09 --> Final output sent to browser
DEBUG - 2011-04-08 01:31:09 --> Total execution time: 0.3798
DEBUG - 2011-04-08 01:31:10 --> Config Class Initialized
DEBUG - 2011-04-08 01:31:10 --> Hooks Class Initialized
DEBUG - 2011-04-08 01:31:10 --> Utf8 Class Initialized
DEBUG - 2011-04-08 01:31:10 --> UTF-8 Support Enabled
DEBUG - 2011-04-08 01:31:10 --> URI Class Initialized
DEBUG - 2011-04-08 01:31:10 --> Router Class Initialized
DEBUG - 2011-04-08 01:31:10 --> Output Class Initialized
DEBUG - 2011-04-08 01:31:10 --> Input Class Initialized
DEBUG - 2011-04-08 01:31:10 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-08 01:31:10 --> Language Class Initialized
DEBUG - 2011-04-08 01:31:10 --> Loader Class Initialized
DEBUG - 2011-04-08 01:31:10 --> Controller Class Initialized
DEBUG - 2011-04-08 01:31:10 --> Model Class Initialized
DEBUG - 2011-04-08 01:31:10 --> Model Class Initialized
DEBUG - 2011-04-08 01:31:10 --> Config Class Initialized
DEBUG - 2011-04-08 01:31:10 --> Hooks Class Initialized
DEBUG - 2011-04-08 01:31:10 --> Model Class Initialized
DEBUG - 2011-04-08 01:31:10 --> Utf8 Class Initialized
DEBUG - 2011-04-08 01:31:10 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-08 01:31:10 --> UTF-8 Support Enabled
DEBUG - 2011-04-08 01:31:10 --> URI Class Initialized
DEBUG - 2011-04-08 01:31:10 --> Router Class Initialized
ERROR - 2011-04-08 01:31:10 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-04-08 01:31:10 --> Database Driver Class Initialized
DEBUG - 2011-04-08 01:31:10 --> File loaded: application/views/table/main.php
DEBUG - 2011-04-08 01:31:10 --> Helper loaded: url_helper
DEBUG - 2011-04-08 01:31:10 --> File loaded: application/views/common/header.php
DEBUG - 2011-04-08 01:31:10 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-04-08 01:31:10 --> File loaded: application/views/common/footer.php
DEBUG - 2011-04-08 01:31:10 --> File loaded: application/views/layout/main.php
DEBUG - 2011-04-08 01:31:10 --> Final output sent to browser
DEBUG - 2011-04-08 01:31:10 --> Total execution time: 0.0525
DEBUG - 2011-04-08 01:31:17 --> Config Class Initialized
DEBUG - 2011-04-08 01:31:17 --> Hooks Class Initialized
DEBUG - 2011-04-08 01:31:17 --> Utf8 Class Initialized
DEBUG - 2011-04-08 01:31:17 --> UTF-8 Support Enabled
DEBUG - 2011-04-08 01:31:17 --> URI Class Initialized
DEBUG - 2011-04-08 01:31:17 --> Router Class Initialized
DEBUG - 2011-04-08 01:31:17 --> Output Class Initialized
DEBUG - 2011-04-08 01:31:17 --> Input Class Initialized
DEBUG - 2011-04-08 01:31:17 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-08 01:31:17 --> Language Class Initialized
DEBUG - 2011-04-08 01:31:17 --> Loader Class Initialized
DEBUG - 2011-04-08 01:31:17 --> Controller Class Initialized
DEBUG - 2011-04-08 01:31:17 --> Model Class Initialized
DEBUG - 2011-04-08 01:31:17 --> Model Class Initialized
DEBUG - 2011-04-08 01:31:17 --> Model Class Initialized
DEBUG - 2011-04-08 01:31:17 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-08 01:31:17 --> Database Driver Class Initialized
DEBUG - 2011-04-08 01:31:20 --> File loaded: application/views/table/main.php
DEBUG - 2011-04-08 01:31:20 --> Helper loaded: url_helper
DEBUG - 2011-04-08 01:31:20 --> File loaded: application/views/common/header.php
DEBUG - 2011-04-08 01:31:20 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-04-08 01:31:20 --> File loaded: application/views/common/footer.php
DEBUG - 2011-04-08 01:31:20 --> File loaded: application/views/layout/main.php
DEBUG - 2011-04-08 01:31:20 --> Final output sent to browser
DEBUG - 2011-04-08 01:31:20 --> Total execution time: 2.8463
DEBUG - 2011-04-08 01:31:20 --> Config Class Initialized
DEBUG - 2011-04-08 01:31:20 --> Hooks Class Initialized
DEBUG - 2011-04-08 01:31:20 --> Config Class Initialized
DEBUG - 2011-04-08 01:31:20 --> Hooks Class Initialized
DEBUG - 2011-04-08 01:31:20 --> Utf8 Class Initialized
DEBUG - 2011-04-08 01:31:20 --> UTF-8 Support Enabled
DEBUG - 2011-04-08 01:31:20 --> Utf8 Class Initialized
DEBUG - 2011-04-08 01:31:20 --> URI Class Initialized
DEBUG - 2011-04-08 01:31:20 --> UTF-8 Support Enabled
DEBUG - 2011-04-08 01:31:20 --> Router Class Initialized
DEBUG - 2011-04-08 01:31:20 --> URI Class Initialized
ERROR - 2011-04-08 01:31:20 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-04-08 01:31:20 --> Router Class Initialized
DEBUG - 2011-04-08 01:31:20 --> Output Class Initialized
DEBUG - 2011-04-08 01:31:20 --> Input Class Initialized
DEBUG - 2011-04-08 01:31:20 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-08 01:31:20 --> Language Class Initialized
DEBUG - 2011-04-08 01:31:20 --> Loader Class Initialized
DEBUG - 2011-04-08 01:31:20 --> Controller Class Initialized
DEBUG - 2011-04-08 01:31:20 --> Model Class Initialized
DEBUG - 2011-04-08 01:31:20 --> Model Class Initialized
DEBUG - 2011-04-08 01:31:20 --> Model Class Initialized
DEBUG - 2011-04-08 01:31:20 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-08 01:31:20 --> Database Driver Class Initialized
DEBUG - 2011-04-08 01:31:21 --> File loaded: application/views/table/main.php
DEBUG - 2011-04-08 01:31:21 --> Helper loaded: url_helper
DEBUG - 2011-04-08 01:31:21 --> File loaded: application/views/common/header.php
DEBUG - 2011-04-08 01:31:21 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-04-08 01:31:21 --> File loaded: application/views/common/footer.php
DEBUG - 2011-04-08 01:31:21 --> File loaded: application/views/layout/main.php
DEBUG - 2011-04-08 01:31:21 --> Final output sent to browser
DEBUG - 2011-04-08 01:31:21 --> Total execution time: 0.0552
DEBUG - 2011-04-08 01:31:21 --> Config Class Initialized
DEBUG - 2011-04-08 01:31:21 --> Hooks Class Initialized
DEBUG - 2011-04-08 01:31:21 --> Utf8 Class Initialized
DEBUG - 2011-04-08 01:31:21 --> UTF-8 Support Enabled
DEBUG - 2011-04-08 01:31:21 --> URI Class Initialized
DEBUG - 2011-04-08 01:31:21 --> Router Class Initialized
DEBUG - 2011-04-08 01:31:21 --> Output Class Initialized
DEBUG - 2011-04-08 01:31:21 --> Input Class Initialized
DEBUG - 2011-04-08 01:31:21 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-08 01:31:21 --> Language Class Initialized
DEBUG - 2011-04-08 01:31:21 --> Loader Class Initialized
DEBUG - 2011-04-08 01:31:21 --> Controller Class Initialized
DEBUG - 2011-04-08 01:31:21 --> Model Class Initialized
DEBUG - 2011-04-08 01:31:21 --> Model Class Initialized
DEBUG - 2011-04-08 01:31:21 --> Model Class Initialized
DEBUG - 2011-04-08 01:31:21 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-08 01:31:21 --> Database Driver Class Initialized
DEBUG - 2011-04-08 01:31:21 --> File loaded: application/views/table/main.php
DEBUG - 2011-04-08 01:31:21 --> Helper loaded: url_helper
DEBUG - 2011-04-08 01:31:21 --> File loaded: application/views/common/header.php
DEBUG - 2011-04-08 01:31:21 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-04-08 01:31:21 --> File loaded: application/views/common/footer.php
DEBUG - 2011-04-08 01:31:21 --> File loaded: application/views/layout/main.php
DEBUG - 2011-04-08 01:31:21 --> Final output sent to browser
DEBUG - 2011-04-08 01:31:21 --> Total execution time: 0.0494
DEBUG - 2011-04-08 01:31:21 --> Config Class Initialized
DEBUG - 2011-04-08 01:31:21 --> Hooks Class Initialized
DEBUG - 2011-04-08 01:31:21 --> Utf8 Class Initialized
DEBUG - 2011-04-08 01:31:21 --> UTF-8 Support Enabled
DEBUG - 2011-04-08 01:31:21 --> URI Class Initialized
DEBUG - 2011-04-08 01:31:21 --> Router Class Initialized
ERROR - 2011-04-08 01:31:21 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-04-08 03:34:12 --> Config Class Initialized
DEBUG - 2011-04-08 03:34:12 --> Hooks Class Initialized
DEBUG - 2011-04-08 03:34:12 --> Utf8 Class Initialized
DEBUG - 2011-04-08 03:34:12 --> UTF-8 Support Enabled
DEBUG - 2011-04-08 03:34:12 --> URI Class Initialized
DEBUG - 2011-04-08 03:34:12 --> Router Class Initialized
ERROR - 2011-04-08 03:34:12 --> 404 Page Not Found --> robots.txt
DEBUG - 2011-04-08 03:40:03 --> Config Class Initialized
DEBUG - 2011-04-08 03:40:03 --> Hooks Class Initialized
DEBUG - 2011-04-08 03:40:03 --> Utf8 Class Initialized
DEBUG - 2011-04-08 03:40:03 --> UTF-8 Support Enabled
DEBUG - 2011-04-08 03:40:03 --> URI Class Initialized
DEBUG - 2011-04-08 03:40:03 --> Router Class Initialized
ERROR - 2011-04-08 03:40:03 --> 404 Page Not Found --> robots.txt
DEBUG - 2011-04-08 03:40:04 --> Config Class Initialized
DEBUG - 2011-04-08 03:40:04 --> Hooks Class Initialized
DEBUG - 2011-04-08 03:40:04 --> Utf8 Class Initialized
DEBUG - 2011-04-08 03:40:04 --> UTF-8 Support Enabled
DEBUG - 2011-04-08 03:40:04 --> URI Class Initialized
DEBUG - 2011-04-08 03:40:04 --> Router Class Initialized
DEBUG - 2011-04-08 03:40:04 --> No URI present. Default controller set.
DEBUG - 2011-04-08 03:40:04 --> Output Class Initialized
DEBUG - 2011-04-08 03:40:05 --> Input Class Initialized
DEBUG - 2011-04-08 03:40:05 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-08 03:40:05 --> Language Class Initialized
DEBUG - 2011-04-08 03:40:05 --> Loader Class Initialized
DEBUG - 2011-04-08 03:40:06 --> Controller Class Initialized
DEBUG - 2011-04-08 03:40:06 --> File loaded: application/views/splash/main.php
DEBUG - 2011-04-08 03:40:06 --> Helper loaded: url_helper
DEBUG - 2011-04-08 03:40:06 --> File loaded: application/views/common/header.php
DEBUG - 2011-04-08 03:40:06 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-04-08 03:40:06 --> File loaded: application/views/common/footer.php
DEBUG - 2011-04-08 03:40:06 --> File loaded: application/views/layout/main.php
DEBUG - 2011-04-08 03:40:06 --> Final output sent to browser
DEBUG - 2011-04-08 03:40:06 --> Total execution time: 2.0297
DEBUG - 2011-04-08 03:40:07 --> Config Class Initialized
DEBUG - 2011-04-08 03:40:07 --> Hooks Class Initialized
DEBUG - 2011-04-08 03:40:07 --> Utf8 Class Initialized
DEBUG - 2011-04-08 03:40:07 --> UTF-8 Support Enabled
DEBUG - 2011-04-08 03:40:07 --> URI Class Initialized
DEBUG - 2011-04-08 03:40:07 --> Router Class Initialized
DEBUG - 2011-04-08 03:40:07 --> Output Class Initialized
DEBUG - 2011-04-08 03:40:07 --> Input Class Initialized
DEBUG - 2011-04-08 03:40:07 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-08 03:40:07 --> Language Class Initialized
DEBUG - 2011-04-08 03:40:07 --> Loader Class Initialized
DEBUG - 2011-04-08 03:40:07 --> Controller Class Initialized
DEBUG - 2011-04-08 03:40:07 --> Model Class Initialized
DEBUG - 2011-04-08 03:40:08 --> Model Class Initialized
DEBUG - 2011-04-08 03:40:08 --> Model Class Initialized
DEBUG - 2011-04-08 03:40:08 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-08 03:40:09 --> Database Driver Class Initialized
DEBUG - 2011-04-08 03:40:38 --> File loaded: application/views/table/main.php
DEBUG - 2011-04-08 03:40:38 --> Helper loaded: url_helper
DEBUG - 2011-04-08 03:40:38 --> File loaded: application/views/common/header.php
DEBUG - 2011-04-08 03:40:38 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-04-08 03:40:38 --> File loaded: application/views/common/footer.php
DEBUG - 2011-04-08 03:40:38 --> File loaded: application/views/layout/main.php
DEBUG - 2011-04-08 03:40:38 --> Final output sent to browser
DEBUG - 2011-04-08 03:40:38 --> Total execution time: 30.5016
DEBUG - 2011-04-08 03:40:38 --> Config Class Initialized
DEBUG - 2011-04-08 03:40:38 --> Hooks Class Initialized
DEBUG - 2011-04-08 03:40:38 --> Utf8 Class Initialized
DEBUG - 2011-04-08 03:40:38 --> UTF-8 Support Enabled
DEBUG - 2011-04-08 03:40:38 --> URI Class Initialized
DEBUG - 2011-04-08 03:40:38 --> Router Class Initialized
DEBUG - 2011-04-08 03:40:38 --> Output Class Initialized
DEBUG - 2011-04-08 03:40:38 --> Input Class Initialized
DEBUG - 2011-04-08 03:40:38 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-08 03:40:38 --> Language Class Initialized
DEBUG - 2011-04-08 03:40:38 --> Loader Class Initialized
DEBUG - 2011-04-08 03:40:38 --> Controller Class Initialized
ERROR - 2011-04-08 03:40:38 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-04-08 03:40:38 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-04-08 03:40:38 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-04-08 03:40:38 --> Model Class Initialized
DEBUG - 2011-04-08 03:40:38 --> Model Class Initialized
DEBUG - 2011-04-08 03:40:38 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-08 03:40:38 --> Database Driver Class Initialized
DEBUG - 2011-04-08 03:40:38 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-04-08 03:40:38 --> Helper loaded: url_helper
DEBUG - 2011-04-08 03:40:38 --> File loaded: application/views/common/header.php
DEBUG - 2011-04-08 03:40:38 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-04-08 03:40:38 --> File loaded: application/views/common/footer.php
DEBUG - 2011-04-08 03:40:38 --> File loaded: application/views/layout/main.php
DEBUG - 2011-04-08 03:40:38 --> Final output sent to browser
DEBUG - 2011-04-08 03:40:38 --> Total execution time: 0.1356
DEBUG - 2011-04-08 04:13:28 --> Config Class Initialized
DEBUG - 2011-04-08 04:13:28 --> Hooks Class Initialized
DEBUG - 2011-04-08 04:13:28 --> Utf8 Class Initialized
DEBUG - 2011-04-08 04:13:28 --> UTF-8 Support Enabled
DEBUG - 2011-04-08 04:13:28 --> URI Class Initialized
DEBUG - 2011-04-08 04:13:28 --> Router Class Initialized
DEBUG - 2011-04-08 04:13:28 --> No URI present. Default controller set.
DEBUG - 2011-04-08 04:13:28 --> Output Class Initialized
DEBUG - 2011-04-08 04:13:28 --> Input Class Initialized
DEBUG - 2011-04-08 04:13:28 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-08 04:13:28 --> Language Class Initialized
DEBUG - 2011-04-08 04:13:28 --> Loader Class Initialized
DEBUG - 2011-04-08 04:13:28 --> Controller Class Initialized
DEBUG - 2011-04-08 04:13:28 --> File loaded: application/views/splash/main.php
DEBUG - 2011-04-08 04:13:28 --> Helper loaded: url_helper
DEBUG - 2011-04-08 04:13:28 --> File loaded: application/views/common/header.php
DEBUG - 2011-04-08 04:13:28 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-04-08 04:13:28 --> File loaded: application/views/common/footer.php
DEBUG - 2011-04-08 04:13:28 --> File loaded: application/views/layout/main.php
DEBUG - 2011-04-08 04:13:28 --> Final output sent to browser
DEBUG - 2011-04-08 04:13:28 --> Total execution time: 0.2363
DEBUG - 2011-04-08 04:13:36 --> Config Class Initialized
DEBUG - 2011-04-08 04:13:36 --> Hooks Class Initialized
DEBUG - 2011-04-08 04:13:36 --> Utf8 Class Initialized
DEBUG - 2011-04-08 04:13:36 --> UTF-8 Support Enabled
DEBUG - 2011-04-08 04:13:36 --> URI Class Initialized
DEBUG - 2011-04-08 04:13:36 --> Router Class Initialized
ERROR - 2011-04-08 04:13:36 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-04-08 04:16:26 --> Config Class Initialized
DEBUG - 2011-04-08 04:16:26 --> Hooks Class Initialized
DEBUG - 2011-04-08 04:16:26 --> Utf8 Class Initialized
DEBUG - 2011-04-08 04:16:26 --> UTF-8 Support Enabled
DEBUG - 2011-04-08 04:16:26 --> URI Class Initialized
DEBUG - 2011-04-08 04:16:26 --> Router Class Initialized
ERROR - 2011-04-08 04:16:26 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-04-08 04:16:32 --> Config Class Initialized
DEBUG - 2011-04-08 04:16:32 --> Hooks Class Initialized
DEBUG - 2011-04-08 04:16:32 --> Utf8 Class Initialized
DEBUG - 2011-04-08 04:16:32 --> UTF-8 Support Enabled
DEBUG - 2011-04-08 04:16:32 --> URI Class Initialized
DEBUG - 2011-04-08 04:16:32 --> Router Class Initialized
DEBUG - 2011-04-08 04:16:32 --> Output Class Initialized
DEBUG - 2011-04-08 04:16:32 --> Input Class Initialized
DEBUG - 2011-04-08 04:16:32 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-08 04:16:32 --> Language Class Initialized
DEBUG - 2011-04-08 04:16:32 --> Loader Class Initialized
DEBUG - 2011-04-08 04:16:32 --> Controller Class Initialized
DEBUG - 2011-04-08 04:16:32 --> Model Class Initialized
DEBUG - 2011-04-08 04:16:32 --> Model Class Initialized
DEBUG - 2011-04-08 04:16:32 --> Model Class Initialized
DEBUG - 2011-04-08 04:16:32 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-08 04:16:32 --> Database Driver Class Initialized
DEBUG - 2011-04-08 04:16:35 --> File loaded: application/views/table/main.php
DEBUG - 2011-04-08 04:16:35 --> Helper loaded: url_helper
DEBUG - 2011-04-08 04:16:35 --> File loaded: application/views/common/header.php
DEBUG - 2011-04-08 04:16:35 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-04-08 04:16:35 --> File loaded: application/views/common/footer.php
DEBUG - 2011-04-08 04:16:35 --> File loaded: application/views/layout/main.php
DEBUG - 2011-04-08 04:16:35 --> Final output sent to browser
DEBUG - 2011-04-08 04:16:35 --> Total execution time: 3.8031
DEBUG - 2011-04-08 04:18:18 --> Config Class Initialized
DEBUG - 2011-04-08 04:18:18 --> Hooks Class Initialized
DEBUG - 2011-04-08 04:18:18 --> Utf8 Class Initialized
DEBUG - 2011-04-08 04:18:18 --> UTF-8 Support Enabled
DEBUG - 2011-04-08 04:18:18 --> URI Class Initialized
DEBUG - 2011-04-08 04:18:18 --> Router Class Initialized
DEBUG - 2011-04-08 04:18:18 --> Output Class Initialized
DEBUG - 2011-04-08 04:18:18 --> Input Class Initialized
DEBUG - 2011-04-08 04:18:18 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-08 04:18:18 --> Language Class Initialized
DEBUG - 2011-04-08 04:18:18 --> Loader Class Initialized
DEBUG - 2011-04-08 04:18:18 --> Controller Class Initialized
DEBUG - 2011-04-08 04:18:18 --> Model Class Initialized
DEBUG - 2011-04-08 04:18:18 --> Model Class Initialized
DEBUG - 2011-04-08 04:18:18 --> Model Class Initialized
DEBUG - 2011-04-08 04:18:18 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-08 04:18:18 --> Database Driver Class Initialized
DEBUG - 2011-04-08 04:18:19 --> File loaded: application/views/table/main.php
DEBUG - 2011-04-08 04:18:19 --> Helper loaded: url_helper
DEBUG - 2011-04-08 04:18:19 --> File loaded: application/views/common/header.php
DEBUG - 2011-04-08 04:18:19 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-04-08 04:18:19 --> File loaded: application/views/common/footer.php
DEBUG - 2011-04-08 04:18:19 --> File loaded: application/views/layout/main.php
DEBUG - 2011-04-08 04:18:19 --> Final output sent to browser
DEBUG - 2011-04-08 04:18:19 --> Total execution time: 0.5850
DEBUG - 2011-04-08 04:18:21 --> Config Class Initialized
DEBUG - 2011-04-08 04:18:21 --> Hooks Class Initialized
DEBUG - 2011-04-08 04:18:21 --> Utf8 Class Initialized
DEBUG - 2011-04-08 04:18:21 --> UTF-8 Support Enabled
DEBUG - 2011-04-08 04:18:21 --> URI Class Initialized
DEBUG - 2011-04-08 04:18:21 --> Router Class Initialized
DEBUG - 2011-04-08 04:18:21 --> Output Class Initialized
DEBUG - 2011-04-08 04:18:21 --> Input Class Initialized
DEBUG - 2011-04-08 04:18:21 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-08 04:18:21 --> Language Class Initialized
DEBUG - 2011-04-08 04:18:21 --> Loader Class Initialized
DEBUG - 2011-04-08 04:18:21 --> Controller Class Initialized
DEBUG - 2011-04-08 04:18:21 --> Model Class Initialized
DEBUG - 2011-04-08 04:18:21 --> Model Class Initialized
DEBUG - 2011-04-08 04:18:21 --> Model Class Initialized
DEBUG - 2011-04-08 04:18:21 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-08 04:18:21 --> Database Driver Class Initialized
DEBUG - 2011-04-08 04:18:21 --> File loaded: application/views/table/main.php
DEBUG - 2011-04-08 04:18:21 --> Helper loaded: url_helper
DEBUG - 2011-04-08 04:18:21 --> File loaded: application/views/common/header.php
DEBUG - 2011-04-08 04:18:21 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-04-08 04:18:21 --> File loaded: application/views/common/footer.php
DEBUG - 2011-04-08 04:18:21 --> File loaded: application/views/layout/main.php
DEBUG - 2011-04-08 04:18:21 --> Final output sent to browser
DEBUG - 2011-04-08 04:18:21 --> Total execution time: 0.0615
DEBUG - 2011-04-08 04:18:45 --> Config Class Initialized
DEBUG - 2011-04-08 04:18:45 --> Hooks Class Initialized
DEBUG - 2011-04-08 04:18:45 --> Utf8 Class Initialized
DEBUG - 2011-04-08 04:18:45 --> UTF-8 Support Enabled
DEBUG - 2011-04-08 04:18:45 --> URI Class Initialized
DEBUG - 2011-04-08 04:18:45 --> Router Class Initialized
DEBUG - 2011-04-08 04:18:45 --> Output Class Initialized
DEBUG - 2011-04-08 04:18:45 --> Input Class Initialized
DEBUG - 2011-04-08 04:18:45 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-08 04:18:45 --> Language Class Initialized
DEBUG - 2011-04-08 04:18:45 --> Loader Class Initialized
DEBUG - 2011-04-08 04:18:45 --> Controller Class Initialized
DEBUG - 2011-04-08 04:18:45 --> Model Class Initialized
DEBUG - 2011-04-08 04:18:45 --> Model Class Initialized
DEBUG - 2011-04-08 04:18:45 --> Model Class Initialized
DEBUG - 2011-04-08 04:18:45 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-08 04:18:45 --> Database Driver Class Initialized
DEBUG - 2011-04-08 04:18:53 --> File loaded: application/views/table/main.php
DEBUG - 2011-04-08 04:18:53 --> Helper loaded: url_helper
DEBUG - 2011-04-08 04:18:53 --> File loaded: application/views/common/header.php
DEBUG - 2011-04-08 04:18:53 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-04-08 04:18:53 --> File loaded: application/views/common/footer.php
DEBUG - 2011-04-08 04:18:53 --> File loaded: application/views/layout/main.php
DEBUG - 2011-04-08 04:18:53 --> Final output sent to browser
DEBUG - 2011-04-08 04:18:53 --> Total execution time: 8.0000
DEBUG - 2011-04-08 04:18:55 --> Config Class Initialized
DEBUG - 2011-04-08 04:18:55 --> Hooks Class Initialized
DEBUG - 2011-04-08 04:18:55 --> Utf8 Class Initialized
DEBUG - 2011-04-08 04:18:55 --> UTF-8 Support Enabled
DEBUG - 2011-04-08 04:18:55 --> URI Class Initialized
DEBUG - 2011-04-08 04:18:55 --> Router Class Initialized
DEBUG - 2011-04-08 04:18:55 --> Output Class Initialized
DEBUG - 2011-04-08 04:18:55 --> Input Class Initialized
DEBUG - 2011-04-08 04:18:55 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-08 04:18:55 --> Language Class Initialized
DEBUG - 2011-04-08 04:18:55 --> Loader Class Initialized
DEBUG - 2011-04-08 04:18:55 --> Controller Class Initialized
DEBUG - 2011-04-08 04:18:55 --> Model Class Initialized
DEBUG - 2011-04-08 04:18:55 --> Model Class Initialized
DEBUG - 2011-04-08 04:18:55 --> Model Class Initialized
DEBUG - 2011-04-08 04:18:55 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-08 04:18:55 --> Database Driver Class Initialized
DEBUG - 2011-04-08 04:18:55 --> File loaded: application/views/table/main.php
DEBUG - 2011-04-08 04:18:55 --> Helper loaded: url_helper
DEBUG - 2011-04-08 04:18:55 --> File loaded: application/views/common/header.php
DEBUG - 2011-04-08 04:18:55 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-04-08 04:18:55 --> File loaded: application/views/common/footer.php
DEBUG - 2011-04-08 04:18:55 --> File loaded: application/views/layout/main.php
DEBUG - 2011-04-08 04:18:55 --> Final output sent to browser
DEBUG - 2011-04-08 04:18:55 --> Total execution time: 0.0486
DEBUG - 2011-04-08 04:19:16 --> Config Class Initialized
DEBUG - 2011-04-08 04:19:16 --> Hooks Class Initialized
DEBUG - 2011-04-08 04:19:16 --> Utf8 Class Initialized
DEBUG - 2011-04-08 04:19:16 --> UTF-8 Support Enabled
DEBUG - 2011-04-08 04:19:16 --> URI Class Initialized
DEBUG - 2011-04-08 04:19:16 --> Router Class Initialized
DEBUG - 2011-04-08 04:19:16 --> Output Class Initialized
DEBUG - 2011-04-08 04:19:16 --> Input Class Initialized
DEBUG - 2011-04-08 04:19:16 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-08 04:19:16 --> Language Class Initialized
DEBUG - 2011-04-08 04:19:16 --> Loader Class Initialized
DEBUG - 2011-04-08 04:19:16 --> Controller Class Initialized
DEBUG - 2011-04-08 04:19:16 --> Model Class Initialized
DEBUG - 2011-04-08 04:19:16 --> Model Class Initialized
DEBUG - 2011-04-08 04:19:16 --> Model Class Initialized
DEBUG - 2011-04-08 04:19:16 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-08 04:19:16 --> Database Driver Class Initialized
DEBUG - 2011-04-08 04:19:17 --> File loaded: application/views/table/main.php
DEBUG - 2011-04-08 04:19:17 --> Helper loaded: url_helper
DEBUG - 2011-04-08 04:19:17 --> File loaded: application/views/common/header.php
DEBUG - 2011-04-08 04:19:17 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-04-08 04:19:17 --> File loaded: application/views/common/footer.php
DEBUG - 2011-04-08 04:19:17 --> File loaded: application/views/layout/main.php
DEBUG - 2011-04-08 04:19:17 --> Final output sent to browser
DEBUG - 2011-04-08 04:19:17 --> Total execution time: 0.7695
DEBUG - 2011-04-08 04:19:32 --> Config Class Initialized
DEBUG - 2011-04-08 04:19:32 --> Hooks Class Initialized
DEBUG - 2011-04-08 04:19:32 --> Utf8 Class Initialized
DEBUG - 2011-04-08 04:19:32 --> UTF-8 Support Enabled
DEBUG - 2011-04-08 04:19:32 --> URI Class Initialized
DEBUG - 2011-04-08 04:19:32 --> Router Class Initialized
DEBUG - 2011-04-08 04:19:32 --> Output Class Initialized
DEBUG - 2011-04-08 04:19:32 --> Input Class Initialized
DEBUG - 2011-04-08 04:19:32 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-08 04:19:32 --> Language Class Initialized
DEBUG - 2011-04-08 04:19:32 --> Loader Class Initialized
DEBUG - 2011-04-08 04:19:32 --> Controller Class Initialized
DEBUG - 2011-04-08 04:19:32 --> Model Class Initialized
DEBUG - 2011-04-08 04:19:32 --> Model Class Initialized
DEBUG - 2011-04-08 04:19:32 --> Model Class Initialized
DEBUG - 2011-04-08 04:19:32 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-08 04:19:32 --> Database Driver Class Initialized
DEBUG - 2011-04-08 04:19:33 --> File loaded: application/views/table/main.php
DEBUG - 2011-04-08 04:19:33 --> Helper loaded: url_helper
DEBUG - 2011-04-08 04:19:33 --> File loaded: application/views/common/header.php
DEBUG - 2011-04-08 04:19:33 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-04-08 04:19:33 --> File loaded: application/views/common/footer.php
DEBUG - 2011-04-08 04:19:33 --> File loaded: application/views/layout/main.php
DEBUG - 2011-04-08 04:19:33 --> Final output sent to browser
DEBUG - 2011-04-08 04:19:33 --> Total execution time: 0.3102
DEBUG - 2011-04-08 04:19:34 --> Config Class Initialized
DEBUG - 2011-04-08 04:19:34 --> Hooks Class Initialized
DEBUG - 2011-04-08 04:19:34 --> Utf8 Class Initialized
DEBUG - 2011-04-08 04:19:34 --> UTF-8 Support Enabled
DEBUG - 2011-04-08 04:19:34 --> URI Class Initialized
DEBUG - 2011-04-08 04:19:34 --> Router Class Initialized
DEBUG - 2011-04-08 04:19:34 --> Output Class Initialized
DEBUG - 2011-04-08 04:19:34 --> Input Class Initialized
DEBUG - 2011-04-08 04:19:34 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-08 04:19:34 --> Language Class Initialized
DEBUG - 2011-04-08 04:19:34 --> Loader Class Initialized
DEBUG - 2011-04-08 04:19:34 --> Controller Class Initialized
DEBUG - 2011-04-08 04:19:34 --> Model Class Initialized
DEBUG - 2011-04-08 04:19:34 --> Model Class Initialized
DEBUG - 2011-04-08 04:19:34 --> Model Class Initialized
DEBUG - 2011-04-08 04:19:34 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-08 04:19:34 --> Database Driver Class Initialized
DEBUG - 2011-04-08 04:19:34 --> File loaded: application/views/table/main.php
DEBUG - 2011-04-08 04:19:34 --> Helper loaded: url_helper
DEBUG - 2011-04-08 04:19:34 --> File loaded: application/views/common/header.php
DEBUG - 2011-04-08 04:19:34 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-04-08 04:19:34 --> File loaded: application/views/common/footer.php
DEBUG - 2011-04-08 04:19:34 --> File loaded: application/views/layout/main.php
DEBUG - 2011-04-08 04:19:34 --> Final output sent to browser
DEBUG - 2011-04-08 04:19:34 --> Total execution time: 0.0464
DEBUG - 2011-04-08 04:19:39 --> Config Class Initialized
DEBUG - 2011-04-08 04:19:39 --> Hooks Class Initialized
DEBUG - 2011-04-08 04:19:39 --> Utf8 Class Initialized
DEBUG - 2011-04-08 04:19:39 --> UTF-8 Support Enabled
DEBUG - 2011-04-08 04:19:39 --> URI Class Initialized
DEBUG - 2011-04-08 04:19:39 --> Router Class Initialized
DEBUG - 2011-04-08 04:19:39 --> Output Class Initialized
DEBUG - 2011-04-08 04:19:39 --> Input Class Initialized
DEBUG - 2011-04-08 04:19:39 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-08 04:19:39 --> Language Class Initialized
DEBUG - 2011-04-08 04:19:39 --> Loader Class Initialized
DEBUG - 2011-04-08 04:19:39 --> Controller Class Initialized
DEBUG - 2011-04-08 04:19:39 --> Model Class Initialized
DEBUG - 2011-04-08 04:19:39 --> Model Class Initialized
DEBUG - 2011-04-08 04:19:39 --> Model Class Initialized
DEBUG - 2011-04-08 04:19:39 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-08 04:19:39 --> Database Driver Class Initialized
DEBUG - 2011-04-08 04:19:39 --> File loaded: application/views/table/main.php
DEBUG - 2011-04-08 04:19:39 --> Helper loaded: url_helper
DEBUG - 2011-04-08 04:19:39 --> File loaded: application/views/common/header.php
DEBUG - 2011-04-08 04:19:39 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-04-08 04:19:39 --> File loaded: application/views/common/footer.php
DEBUG - 2011-04-08 04:19:39 --> File loaded: application/views/layout/main.php
DEBUG - 2011-04-08 04:19:39 --> Final output sent to browser
DEBUG - 2011-04-08 04:19:39 --> Total execution time: 0.0580
DEBUG - 2011-04-08 04:19:48 --> Config Class Initialized
DEBUG - 2011-04-08 04:19:48 --> Hooks Class Initialized
DEBUG - 2011-04-08 04:19:48 --> Utf8 Class Initialized
DEBUG - 2011-04-08 04:19:48 --> UTF-8 Support Enabled
DEBUG - 2011-04-08 04:19:48 --> URI Class Initialized
DEBUG - 2011-04-08 04:19:48 --> Router Class Initialized
DEBUG - 2011-04-08 04:19:48 --> Output Class Initialized
DEBUG - 2011-04-08 04:19:48 --> Input Class Initialized
DEBUG - 2011-04-08 04:19:48 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-08 04:19:48 --> Language Class Initialized
DEBUG - 2011-04-08 04:19:48 --> Loader Class Initialized
DEBUG - 2011-04-08 04:19:48 --> Controller Class Initialized
DEBUG - 2011-04-08 04:19:48 --> Model Class Initialized
DEBUG - 2011-04-08 04:19:48 --> Model Class Initialized
DEBUG - 2011-04-08 04:19:48 --> Model Class Initialized
DEBUG - 2011-04-08 04:19:48 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-08 04:19:48 --> Database Driver Class Initialized
DEBUG - 2011-04-08 04:19:51 --> File loaded: application/views/table/main.php
DEBUG - 2011-04-08 04:19:51 --> Helper loaded: url_helper
DEBUG - 2011-04-08 04:19:51 --> File loaded: application/views/common/header.php
DEBUG - 2011-04-08 04:19:51 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-04-08 04:19:51 --> File loaded: application/views/common/footer.php
DEBUG - 2011-04-08 04:19:51 --> File loaded: application/views/layout/main.php
DEBUG - 2011-04-08 04:19:51 --> Final output sent to browser
DEBUG - 2011-04-08 04:19:51 --> Total execution time: 3.3479
DEBUG - 2011-04-08 04:20:37 --> Config Class Initialized
DEBUG - 2011-04-08 04:20:37 --> Hooks Class Initialized
DEBUG - 2011-04-08 04:20:37 --> Utf8 Class Initialized
DEBUG - 2011-04-08 04:20:37 --> UTF-8 Support Enabled
DEBUG - 2011-04-08 04:20:37 --> URI Class Initialized
DEBUG - 2011-04-08 04:20:37 --> Router Class Initialized
DEBUG - 2011-04-08 04:20:37 --> Output Class Initialized
DEBUG - 2011-04-08 04:20:37 --> Input Class Initialized
DEBUG - 2011-04-08 04:20:37 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-08 04:20:37 --> Language Class Initialized
DEBUG - 2011-04-08 04:20:37 --> Loader Class Initialized
DEBUG - 2011-04-08 04:20:37 --> Controller Class Initialized
DEBUG - 2011-04-08 04:20:37 --> Model Class Initialized
DEBUG - 2011-04-08 04:20:37 --> Model Class Initialized
DEBUG - 2011-04-08 04:20:37 --> Model Class Initialized
DEBUG - 2011-04-08 04:20:37 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-08 04:20:37 --> Database Driver Class Initialized
DEBUG - 2011-04-08 04:20:37 --> File loaded: application/views/table/main.php
DEBUG - 2011-04-08 04:20:37 --> Helper loaded: url_helper
DEBUG - 2011-04-08 04:20:37 --> File loaded: application/views/common/header.php
DEBUG - 2011-04-08 04:20:37 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-04-08 04:20:37 --> File loaded: application/views/common/footer.php
DEBUG - 2011-04-08 04:20:37 --> File loaded: application/views/layout/main.php
DEBUG - 2011-04-08 04:20:37 --> Final output sent to browser
DEBUG - 2011-04-08 04:20:37 --> Total execution time: 0.2470
DEBUG - 2011-04-08 04:20:54 --> Config Class Initialized
DEBUG - 2011-04-08 04:20:54 --> Hooks Class Initialized
DEBUG - 2011-04-08 04:20:54 --> Utf8 Class Initialized
DEBUG - 2011-04-08 04:20:54 --> UTF-8 Support Enabled
DEBUG - 2011-04-08 04:20:54 --> URI Class Initialized
DEBUG - 2011-04-08 04:20:54 --> Router Class Initialized
DEBUG - 2011-04-08 04:20:54 --> Output Class Initialized
DEBUG - 2011-04-08 04:20:54 --> Input Class Initialized
DEBUG - 2011-04-08 04:20:54 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-08 04:20:54 --> Language Class Initialized
DEBUG - 2011-04-08 04:20:54 --> Loader Class Initialized
DEBUG - 2011-04-08 04:20:54 --> Controller Class Initialized
DEBUG - 2011-04-08 04:20:54 --> Model Class Initialized
DEBUG - 2011-04-08 04:20:54 --> Model Class Initialized
DEBUG - 2011-04-08 04:20:54 --> Model Class Initialized
DEBUG - 2011-04-08 04:20:54 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-08 04:20:54 --> Database Driver Class Initialized
DEBUG - 2011-04-08 04:21:01 --> File loaded: application/views/table/main.php
DEBUG - 2011-04-08 04:21:01 --> Helper loaded: url_helper
DEBUG - 2011-04-08 04:21:01 --> File loaded: application/views/common/header.php
DEBUG - 2011-04-08 04:21:01 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-04-08 04:21:01 --> File loaded: application/views/common/footer.php
DEBUG - 2011-04-08 04:21:01 --> File loaded: application/views/layout/main.php
DEBUG - 2011-04-08 04:21:01 --> Final output sent to browser
DEBUG - 2011-04-08 04:21:01 --> Total execution time: 6.7879
DEBUG - 2011-04-08 04:21:04 --> Config Class Initialized
DEBUG - 2011-04-08 04:21:04 --> Hooks Class Initialized
DEBUG - 2011-04-08 04:21:04 --> Utf8 Class Initialized
DEBUG - 2011-04-08 04:21:04 --> UTF-8 Support Enabled
DEBUG - 2011-04-08 04:21:04 --> URI Class Initialized
DEBUG - 2011-04-08 04:21:04 --> Router Class Initialized
DEBUG - 2011-04-08 04:21:04 --> Output Class Initialized
DEBUG - 2011-04-08 04:21:04 --> Input Class Initialized
DEBUG - 2011-04-08 04:21:04 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-08 04:21:04 --> Language Class Initialized
DEBUG - 2011-04-08 04:21:04 --> Loader Class Initialized
DEBUG - 2011-04-08 04:21:04 --> Controller Class Initialized
DEBUG - 2011-04-08 04:21:04 --> Model Class Initialized
DEBUG - 2011-04-08 04:21:04 --> Model Class Initialized
DEBUG - 2011-04-08 04:21:04 --> Model Class Initialized
DEBUG - 2011-04-08 04:21:04 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-08 04:21:04 --> Database Driver Class Initialized
DEBUG - 2011-04-08 04:21:04 --> File loaded: application/views/table/main.php
DEBUG - 2011-04-08 04:21:04 --> Helper loaded: url_helper
DEBUG - 2011-04-08 04:21:04 --> File loaded: application/views/common/header.php
DEBUG - 2011-04-08 04:21:04 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-04-08 04:21:04 --> File loaded: application/views/common/footer.php
DEBUG - 2011-04-08 04:21:04 --> File loaded: application/views/layout/main.php
DEBUG - 2011-04-08 04:21:04 --> Final output sent to browser
DEBUG - 2011-04-08 04:21:04 --> Total execution time: 0.1079
DEBUG - 2011-04-08 04:48:47 --> Config Class Initialized
DEBUG - 2011-04-08 04:48:47 --> Hooks Class Initialized
DEBUG - 2011-04-08 04:48:47 --> Utf8 Class Initialized
DEBUG - 2011-04-08 04:48:47 --> UTF-8 Support Enabled
DEBUG - 2011-04-08 04:48:47 --> URI Class Initialized
DEBUG - 2011-04-08 04:48:47 --> Router Class Initialized
DEBUG - 2011-04-08 04:48:47 --> No URI present. Default controller set.
DEBUG - 2011-04-08 04:48:47 --> Output Class Initialized
DEBUG - 2011-04-08 04:48:47 --> Input Class Initialized
DEBUG - 2011-04-08 04:48:47 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-08 04:48:47 --> Language Class Initialized
DEBUG - 2011-04-08 04:48:47 --> Loader Class Initialized
DEBUG - 2011-04-08 04:48:47 --> Controller Class Initialized
DEBUG - 2011-04-08 04:48:47 --> File loaded: application/views/splash/main.php
DEBUG - 2011-04-08 04:48:47 --> Helper loaded: url_helper
DEBUG - 2011-04-08 04:48:47 --> File loaded: application/views/common/header.php
DEBUG - 2011-04-08 04:48:47 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-04-08 04:48:47 --> File loaded: application/views/common/footer.php
DEBUG - 2011-04-08 04:48:47 --> File loaded: application/views/layout/main.php
DEBUG - 2011-04-08 04:48:47 --> Final output sent to browser
DEBUG - 2011-04-08 04:48:47 --> Total execution time: 0.2279
DEBUG - 2011-04-08 05:05:03 --> Config Class Initialized
DEBUG - 2011-04-08 05:05:03 --> Hooks Class Initialized
DEBUG - 2011-04-08 05:05:03 --> Utf8 Class Initialized
DEBUG - 2011-04-08 05:05:03 --> UTF-8 Support Enabled
DEBUG - 2011-04-08 05:05:03 --> URI Class Initialized
DEBUG - 2011-04-08 05:05:03 --> Router Class Initialized
DEBUG - 2011-04-08 05:05:03 --> Output Class Initialized
DEBUG - 2011-04-08 05:05:03 --> Input Class Initialized
DEBUG - 2011-04-08 05:05:03 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-08 05:05:03 --> Language Class Initialized
DEBUG - 2011-04-08 05:05:03 --> Loader Class Initialized
DEBUG - 2011-04-08 05:05:03 --> Controller Class Initialized
DEBUG - 2011-04-08 05:05:03 --> Model Class Initialized
DEBUG - 2011-04-08 05:05:03 --> Model Class Initialized
DEBUG - 2011-04-08 05:05:03 --> Model Class Initialized
DEBUG - 2011-04-08 05:05:03 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-08 05:05:03 --> Database Driver Class Initialized
DEBUG - 2011-04-08 05:05:08 --> File loaded: application/views/table/main.php
DEBUG - 2011-04-08 05:05:08 --> Helper loaded: url_helper
DEBUG - 2011-04-08 05:05:08 --> File loaded: application/views/common/header.php
DEBUG - 2011-04-08 05:05:08 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-04-08 05:05:08 --> File loaded: application/views/common/footer.php
DEBUG - 2011-04-08 05:05:08 --> File loaded: application/views/layout/main.php
DEBUG - 2011-04-08 05:05:08 --> Final output sent to browser
DEBUG - 2011-04-08 05:05:08 --> Total execution time: 5.0882
DEBUG - 2011-04-08 05:05:16 --> Config Class Initialized
DEBUG - 2011-04-08 05:05:16 --> Hooks Class Initialized
DEBUG - 2011-04-08 05:05:16 --> Utf8 Class Initialized
DEBUG - 2011-04-08 05:05:16 --> UTF-8 Support Enabled
DEBUG - 2011-04-08 05:05:16 --> URI Class Initialized
DEBUG - 2011-04-08 05:05:16 --> Router Class Initialized
DEBUG - 2011-04-08 05:05:16 --> Output Class Initialized
DEBUG - 2011-04-08 05:05:16 --> Input Class Initialized
DEBUG - 2011-04-08 05:05:16 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-08 05:05:16 --> Language Class Initialized
DEBUG - 2011-04-08 05:05:16 --> Loader Class Initialized
DEBUG - 2011-04-08 05:05:16 --> Controller Class Initialized
ERROR - 2011-04-08 05:05:16 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-04-08 05:05:16 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-04-08 05:05:16 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-04-08 05:05:16 --> Model Class Initialized
DEBUG - 2011-04-08 05:05:16 --> Model Class Initialized
DEBUG - 2011-04-08 05:05:16 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-08 05:05:16 --> Database Driver Class Initialized
DEBUG - 2011-04-08 05:05:16 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-04-08 05:05:16 --> Helper loaded: url_helper
DEBUG - 2011-04-08 05:05:16 --> File loaded: application/views/common/header.php
DEBUG - 2011-04-08 05:05:16 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-04-08 05:05:16 --> File loaded: application/views/common/footer.php
DEBUG - 2011-04-08 05:05:16 --> File loaded: application/views/layout/main.php
DEBUG - 2011-04-08 05:05:16 --> Final output sent to browser
DEBUG - 2011-04-08 05:05:16 --> Total execution time: 0.1590
DEBUG - 2011-04-08 05:05:17 --> Config Class Initialized
DEBUG - 2011-04-08 05:05:17 --> Hooks Class Initialized
DEBUG - 2011-04-08 05:05:17 --> Utf8 Class Initialized
DEBUG - 2011-04-08 05:05:17 --> UTF-8 Support Enabled
DEBUG - 2011-04-08 05:05:17 --> URI Class Initialized
DEBUG - 2011-04-08 05:05:17 --> Router Class Initialized
DEBUG - 2011-04-08 05:05:17 --> Output Class Initialized
DEBUG - 2011-04-08 05:05:17 --> Input Class Initialized
DEBUG - 2011-04-08 05:05:17 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-08 05:05:17 --> Language Class Initialized
DEBUG - 2011-04-08 05:05:17 --> Loader Class Initialized
DEBUG - 2011-04-08 05:05:17 --> Controller Class Initialized
DEBUG - 2011-04-08 05:05:17 --> Model Class Initialized
DEBUG - 2011-04-08 05:05:17 --> Model Class Initialized
DEBUG - 2011-04-08 05:05:17 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-08 05:05:17 --> Database Driver Class Initialized
DEBUG - 2011-04-08 05:05:19 --> Final output sent to browser
DEBUG - 2011-04-08 05:05:19 --> Total execution time: 2.1294
DEBUG - 2011-04-08 05:05:20 --> Config Class Initialized
DEBUG - 2011-04-08 05:05:20 --> Hooks Class Initialized
DEBUG - 2011-04-08 05:05:20 --> Utf8 Class Initialized
DEBUG - 2011-04-08 05:05:20 --> UTF-8 Support Enabled
DEBUG - 2011-04-08 05:05:20 --> URI Class Initialized
DEBUG - 2011-04-08 05:05:20 --> Router Class Initialized
ERROR - 2011-04-08 05:05:20 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-04-08 07:20:30 --> Config Class Initialized
DEBUG - 2011-04-08 07:20:30 --> Hooks Class Initialized
DEBUG - 2011-04-08 07:20:30 --> Utf8 Class Initialized
DEBUG - 2011-04-08 07:20:30 --> UTF-8 Support Enabled
DEBUG - 2011-04-08 07:20:30 --> URI Class Initialized
DEBUG - 2011-04-08 07:20:30 --> Router Class Initialized
DEBUG - 2011-04-08 07:20:30 --> No URI present. Default controller set.
DEBUG - 2011-04-08 07:20:30 --> Output Class Initialized
DEBUG - 2011-04-08 07:20:30 --> Input Class Initialized
DEBUG - 2011-04-08 07:20:30 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-08 07:20:30 --> Language Class Initialized
DEBUG - 2011-04-08 07:20:30 --> Loader Class Initialized
DEBUG - 2011-04-08 07:20:30 --> Controller Class Initialized
DEBUG - 2011-04-08 07:20:30 --> File loaded: application/views/splash/main.php
DEBUG - 2011-04-08 07:20:30 --> Helper loaded: url_helper
DEBUG - 2011-04-08 07:20:30 --> File loaded: application/views/common/header.php
DEBUG - 2011-04-08 07:20:30 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-04-08 07:20:30 --> File loaded: application/views/common/footer.php
DEBUG - 2011-04-08 07:20:30 --> File loaded: application/views/layout/main.php
DEBUG - 2011-04-08 07:20:30 --> Final output sent to browser
DEBUG - 2011-04-08 07:20:30 --> Total execution time: 0.2508
DEBUG - 2011-04-08 07:20:31 --> Config Class Initialized
DEBUG - 2011-04-08 07:20:31 --> Hooks Class Initialized
DEBUG - 2011-04-08 07:20:31 --> Utf8 Class Initialized
DEBUG - 2011-04-08 07:20:31 --> UTF-8 Support Enabled
DEBUG - 2011-04-08 07:20:31 --> URI Class Initialized
DEBUG - 2011-04-08 07:20:31 --> Router Class Initialized
DEBUG - 2011-04-08 07:20:31 --> No URI present. Default controller set.
DEBUG - 2011-04-08 07:20:31 --> Output Class Initialized
DEBUG - 2011-04-08 07:20:31 --> Input Class Initialized
DEBUG - 2011-04-08 07:20:31 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-08 07:20:31 --> Language Class Initialized
DEBUG - 2011-04-08 07:20:31 --> Loader Class Initialized
DEBUG - 2011-04-08 07:20:31 --> Controller Class Initialized
DEBUG - 2011-04-08 07:20:31 --> File loaded: application/views/splash/main.php
DEBUG - 2011-04-08 07:20:31 --> Helper loaded: url_helper
DEBUG - 2011-04-08 07:20:31 --> File loaded: application/views/common/header.php
DEBUG - 2011-04-08 07:20:31 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-04-08 07:20:31 --> File loaded: application/views/common/footer.php
DEBUG - 2011-04-08 07:20:31 --> File loaded: application/views/layout/main.php
DEBUG - 2011-04-08 07:20:31 --> Final output sent to browser
DEBUG - 2011-04-08 07:20:31 --> Total execution time: 0.0134
DEBUG - 2011-04-08 07:20:35 --> Config Class Initialized
DEBUG - 2011-04-08 07:20:35 --> Hooks Class Initialized
DEBUG - 2011-04-08 07:20:35 --> Utf8 Class Initialized
DEBUG - 2011-04-08 07:20:35 --> UTF-8 Support Enabled
DEBUG - 2011-04-08 07:20:35 --> URI Class Initialized
DEBUG - 2011-04-08 07:20:35 --> Router Class Initialized
ERROR - 2011-04-08 07:20:35 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-04-08 07:20:35 --> Config Class Initialized
DEBUG - 2011-04-08 07:20:35 --> Hooks Class Initialized
DEBUG - 2011-04-08 07:20:35 --> Utf8 Class Initialized
DEBUG - 2011-04-08 07:20:35 --> UTF-8 Support Enabled
DEBUG - 2011-04-08 07:20:35 --> URI Class Initialized
DEBUG - 2011-04-08 07:20:35 --> Router Class Initialized
ERROR - 2011-04-08 07:20:35 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-04-08 07:20:42 --> Config Class Initialized
DEBUG - 2011-04-08 07:20:42 --> Hooks Class Initialized
DEBUG - 2011-04-08 07:20:42 --> Utf8 Class Initialized
DEBUG - 2011-04-08 07:20:42 --> UTF-8 Support Enabled
DEBUG - 2011-04-08 07:20:42 --> URI Class Initialized
DEBUG - 2011-04-08 07:20:42 --> Router Class Initialized
DEBUG - 2011-04-08 07:20:42 --> Output Class Initialized
DEBUG - 2011-04-08 07:20:42 --> Input Class Initialized
DEBUG - 2011-04-08 07:20:42 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-08 07:20:42 --> Language Class Initialized
DEBUG - 2011-04-08 07:20:42 --> Loader Class Initialized
DEBUG - 2011-04-08 07:20:42 --> Controller Class Initialized
DEBUG - 2011-04-08 07:20:42 --> Model Class Initialized
DEBUG - 2011-04-08 07:20:42 --> Model Class Initialized
DEBUG - 2011-04-08 07:20:42 --> Model Class Initialized
DEBUG - 2011-04-08 07:20:42 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-08 07:20:42 --> Database Driver Class Initialized
DEBUG - 2011-04-08 07:20:43 --> File loaded: application/views/table/main.php
DEBUG - 2011-04-08 07:20:43 --> Helper loaded: url_helper
DEBUG - 2011-04-08 07:20:43 --> File loaded: application/views/common/header.php
DEBUG - 2011-04-08 07:20:43 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-04-08 07:20:43 --> File loaded: application/views/common/footer.php
DEBUG - 2011-04-08 07:20:43 --> File loaded: application/views/layout/main.php
DEBUG - 2011-04-08 07:20:43 --> Final output sent to browser
DEBUG - 2011-04-08 07:20:43 --> Total execution time: 0.5950
DEBUG - 2011-04-08 07:20:43 --> Config Class Initialized
DEBUG - 2011-04-08 07:20:43 --> Hooks Class Initialized
DEBUG - 2011-04-08 07:20:43 --> Utf8 Class Initialized
DEBUG - 2011-04-08 07:20:43 --> UTF-8 Support Enabled
DEBUG - 2011-04-08 07:20:43 --> URI Class Initialized
DEBUG - 2011-04-08 07:20:43 --> Router Class Initialized
DEBUG - 2011-04-08 07:20:43 --> Output Class Initialized
DEBUG - 2011-04-08 07:20:43 --> Input Class Initialized
DEBUG - 2011-04-08 07:20:43 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-08 07:20:43 --> Language Class Initialized
DEBUG - 2011-04-08 07:20:43 --> Loader Class Initialized
DEBUG - 2011-04-08 07:20:43 --> Controller Class Initialized
ERROR - 2011-04-08 07:20:43 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-04-08 07:20:43 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-04-08 07:20:43 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-04-08 07:20:43 --> Model Class Initialized
DEBUG - 2011-04-08 07:20:43 --> Model Class Initialized
DEBUG - 2011-04-08 07:20:43 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-08 07:20:43 --> Database Driver Class Initialized
DEBUG - 2011-04-08 07:20:43 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-04-08 07:20:43 --> Helper loaded: url_helper
DEBUG - 2011-04-08 07:20:43 --> File loaded: application/views/common/header.php
DEBUG - 2011-04-08 07:20:43 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-04-08 07:20:43 --> File loaded: application/views/common/footer.php
DEBUG - 2011-04-08 07:20:43 --> File loaded: application/views/layout/main.php
DEBUG - 2011-04-08 07:20:43 --> Final output sent to browser
DEBUG - 2011-04-08 07:20:43 --> Total execution time: 0.0991
DEBUG - 2011-04-08 07:20:45 --> Config Class Initialized
DEBUG - 2011-04-08 07:20:45 --> Hooks Class Initialized
DEBUG - 2011-04-08 07:20:45 --> Utf8 Class Initialized
DEBUG - 2011-04-08 07:20:45 --> UTF-8 Support Enabled
DEBUG - 2011-04-08 07:20:45 --> URI Class Initialized
DEBUG - 2011-04-08 07:20:45 --> Router Class Initialized
DEBUG - 2011-04-08 07:20:45 --> Output Class Initialized
DEBUG - 2011-04-08 07:20:45 --> Input Class Initialized
DEBUG - 2011-04-08 07:20:45 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-08 07:20:45 --> Language Class Initialized
DEBUG - 2011-04-08 07:20:45 --> Loader Class Initialized
DEBUG - 2011-04-08 07:20:45 --> Controller Class Initialized
DEBUG - 2011-04-08 07:20:45 --> Model Class Initialized
DEBUG - 2011-04-08 07:20:45 --> Model Class Initialized
DEBUG - 2011-04-08 07:20:45 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-08 07:20:45 --> Database Driver Class Initialized
DEBUG - 2011-04-08 07:20:46 --> Final output sent to browser
DEBUG - 2011-04-08 07:20:46 --> Total execution time: 0.8235
DEBUG - 2011-04-08 07:21:10 --> Config Class Initialized
DEBUG - 2011-04-08 07:21:10 --> Hooks Class Initialized
DEBUG - 2011-04-08 07:21:10 --> Utf8 Class Initialized
DEBUG - 2011-04-08 07:21:10 --> UTF-8 Support Enabled
DEBUG - 2011-04-08 07:21:10 --> URI Class Initialized
DEBUG - 2011-04-08 07:21:10 --> Router Class Initialized
DEBUG - 2011-04-08 07:21:10 --> Output Class Initialized
DEBUG - 2011-04-08 07:21:10 --> Input Class Initialized
DEBUG - 2011-04-08 07:21:10 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-08 07:21:10 --> Language Class Initialized
DEBUG - 2011-04-08 07:21:10 --> Loader Class Initialized
DEBUG - 2011-04-08 07:21:10 --> Controller Class Initialized
DEBUG - 2011-04-08 07:21:10 --> Model Class Initialized
DEBUG - 2011-04-08 07:21:10 --> Model Class Initialized
DEBUG - 2011-04-08 07:21:10 --> Model Class Initialized
DEBUG - 2011-04-08 07:21:10 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-08 07:21:11 --> Database Driver Class Initialized
DEBUG - 2011-04-08 07:21:11 --> File loaded: application/views/table/main.php
DEBUG - 2011-04-08 07:21:11 --> Helper loaded: url_helper
DEBUG - 2011-04-08 07:21:11 --> File loaded: application/views/common/header.php
DEBUG - 2011-04-08 07:21:11 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-04-08 07:21:11 --> File loaded: application/views/common/footer.php
DEBUG - 2011-04-08 07:21:11 --> File loaded: application/views/layout/main.php
DEBUG - 2011-04-08 07:21:11 --> Final output sent to browser
DEBUG - 2011-04-08 07:21:11 --> Total execution time: 0.0503
DEBUG - 2011-04-08 07:21:12 --> Config Class Initialized
DEBUG - 2011-04-08 07:21:12 --> Hooks Class Initialized
DEBUG - 2011-04-08 07:21:12 --> Utf8 Class Initialized
DEBUG - 2011-04-08 07:21:12 --> UTF-8 Support Enabled
DEBUG - 2011-04-08 07:21:12 --> URI Class Initialized
DEBUG - 2011-04-08 07:21:12 --> Router Class Initialized
DEBUG - 2011-04-08 07:21:12 --> Output Class Initialized
DEBUG - 2011-04-08 07:21:12 --> Input Class Initialized
DEBUG - 2011-04-08 07:21:12 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-08 07:21:12 --> Language Class Initialized
DEBUG - 2011-04-08 07:21:12 --> Loader Class Initialized
DEBUG - 2011-04-08 07:21:12 --> Controller Class Initialized
DEBUG - 2011-04-08 07:21:12 --> Model Class Initialized
DEBUG - 2011-04-08 07:21:12 --> Model Class Initialized
DEBUG - 2011-04-08 07:21:12 --> Model Class Initialized
DEBUG - 2011-04-08 07:21:12 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-08 07:21:12 --> Database Driver Class Initialized
DEBUG - 2011-04-08 07:21:12 --> File loaded: application/views/table/main.php
DEBUG - 2011-04-08 07:21:12 --> Helper loaded: url_helper
DEBUG - 2011-04-08 07:21:12 --> File loaded: application/views/common/header.php
DEBUG - 2011-04-08 07:21:12 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-04-08 07:21:12 --> File loaded: application/views/common/footer.php
DEBUG - 2011-04-08 07:21:12 --> File loaded: application/views/layout/main.php
DEBUG - 2011-04-08 07:21:12 --> Final output sent to browser
DEBUG - 2011-04-08 07:21:12 --> Total execution time: 0.0449
DEBUG - 2011-04-08 07:21:16 --> Config Class Initialized
DEBUG - 2011-04-08 07:21:16 --> Hooks Class Initialized
DEBUG - 2011-04-08 07:21:16 --> Utf8 Class Initialized
DEBUG - 2011-04-08 07:21:16 --> UTF-8 Support Enabled
DEBUG - 2011-04-08 07:21:16 --> URI Class Initialized
DEBUG - 2011-04-08 07:21:16 --> Router Class Initialized
DEBUG - 2011-04-08 07:21:16 --> Output Class Initialized
DEBUG - 2011-04-08 07:21:16 --> Input Class Initialized
DEBUG - 2011-04-08 07:21:16 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-08 07:21:16 --> Language Class Initialized
DEBUG - 2011-04-08 07:21:16 --> Loader Class Initialized
DEBUG - 2011-04-08 07:21:16 --> Controller Class Initialized
DEBUG - 2011-04-08 07:21:16 --> Model Class Initialized
DEBUG - 2011-04-08 07:21:16 --> Model Class Initialized
DEBUG - 2011-04-08 07:21:16 --> Model Class Initialized
DEBUG - 2011-04-08 07:21:16 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-08 07:21:16 --> Database Driver Class Initialized
DEBUG - 2011-04-08 07:21:16 --> File loaded: application/views/table/main.php
DEBUG - 2011-04-08 07:21:16 --> Helper loaded: url_helper
DEBUG - 2011-04-08 07:21:16 --> File loaded: application/views/common/header.php
DEBUG - 2011-04-08 07:21:16 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-04-08 07:21:16 --> File loaded: application/views/common/footer.php
DEBUG - 2011-04-08 07:21:16 --> File loaded: application/views/layout/main.php
DEBUG - 2011-04-08 07:21:16 --> Final output sent to browser
DEBUG - 2011-04-08 07:21:16 --> Total execution time: 0.0448
DEBUG - 2011-04-08 07:21:34 --> Config Class Initialized
DEBUG - 2011-04-08 07:21:34 --> Hooks Class Initialized
DEBUG - 2011-04-08 07:21:34 --> Utf8 Class Initialized
DEBUG - 2011-04-08 07:21:34 --> UTF-8 Support Enabled
DEBUG - 2011-04-08 07:21:34 --> URI Class Initialized
DEBUG - 2011-04-08 07:21:34 --> Router Class Initialized
DEBUG - 2011-04-08 07:21:34 --> Output Class Initialized
DEBUG - 2011-04-08 07:21:34 --> Input Class Initialized
DEBUG - 2011-04-08 07:21:34 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-08 07:21:34 --> Language Class Initialized
DEBUG - 2011-04-08 07:21:34 --> Loader Class Initialized
DEBUG - 2011-04-08 07:21:34 --> Controller Class Initialized
DEBUG - 2011-04-08 07:21:34 --> Model Class Initialized
DEBUG - 2011-04-08 07:21:34 --> Model Class Initialized
DEBUG - 2011-04-08 07:21:34 --> Model Class Initialized
DEBUG - 2011-04-08 07:21:34 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-08 07:21:34 --> Database Driver Class Initialized
DEBUG - 2011-04-08 07:21:34 --> File loaded: application/views/table/main.php
DEBUG - 2011-04-08 07:21:34 --> Helper loaded: url_helper
DEBUG - 2011-04-08 07:21:34 --> File loaded: application/views/common/header.php
DEBUG - 2011-04-08 07:21:34 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-04-08 07:21:34 --> File loaded: application/views/common/footer.php
DEBUG - 2011-04-08 07:21:34 --> File loaded: application/views/layout/main.php
DEBUG - 2011-04-08 07:21:34 --> Final output sent to browser
DEBUG - 2011-04-08 07:21:34 --> Total execution time: 0.0444
DEBUG - 2011-04-08 07:21:39 --> Config Class Initialized
DEBUG - 2011-04-08 07:21:39 --> Hooks Class Initialized
DEBUG - 2011-04-08 07:21:39 --> Utf8 Class Initialized
DEBUG - 2011-04-08 07:21:39 --> UTF-8 Support Enabled
DEBUG - 2011-04-08 07:21:39 --> URI Class Initialized
DEBUG - 2011-04-08 07:21:39 --> Router Class Initialized
DEBUG - 2011-04-08 07:21:39 --> Output Class Initialized
DEBUG - 2011-04-08 07:21:39 --> Input Class Initialized
DEBUG - 2011-04-08 07:21:39 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-08 07:21:39 --> Language Class Initialized
DEBUG - 2011-04-08 07:21:39 --> Loader Class Initialized
DEBUG - 2011-04-08 07:21:39 --> Controller Class Initialized
DEBUG - 2011-04-08 07:21:39 --> Model Class Initialized
DEBUG - 2011-04-08 07:21:39 --> Model Class Initialized
DEBUG - 2011-04-08 07:21:39 --> Model Class Initialized
DEBUG - 2011-04-08 07:21:39 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-08 07:21:39 --> Database Driver Class Initialized
DEBUG - 2011-04-08 07:21:39 --> File loaded: application/views/table/main.php
DEBUG - 2011-04-08 07:21:39 --> Helper loaded: url_helper
DEBUG - 2011-04-08 07:21:39 --> File loaded: application/views/common/header.php
DEBUG - 2011-04-08 07:21:39 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-04-08 07:21:39 --> File loaded: application/views/common/footer.php
DEBUG - 2011-04-08 07:21:39 --> File loaded: application/views/layout/main.php
DEBUG - 2011-04-08 07:21:39 --> Final output sent to browser
DEBUG - 2011-04-08 07:21:39 --> Total execution time: 0.0706
DEBUG - 2011-04-08 07:21:55 --> Config Class Initialized
DEBUG - 2011-04-08 07:21:55 --> Hooks Class Initialized
DEBUG - 2011-04-08 07:21:55 --> Utf8 Class Initialized
DEBUG - 2011-04-08 07:21:55 --> UTF-8 Support Enabled
DEBUG - 2011-04-08 07:21:55 --> URI Class Initialized
DEBUG - 2011-04-08 07:21:55 --> Router Class Initialized
DEBUG - 2011-04-08 07:21:55 --> Output Class Initialized
DEBUG - 2011-04-08 07:21:55 --> Input Class Initialized
DEBUG - 2011-04-08 07:21:55 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-08 07:21:55 --> Language Class Initialized
DEBUG - 2011-04-08 07:21:55 --> Loader Class Initialized
DEBUG - 2011-04-08 07:21:55 --> Controller Class Initialized
DEBUG - 2011-04-08 07:21:55 --> Model Class Initialized
DEBUG - 2011-04-08 07:21:55 --> Model Class Initialized
DEBUG - 2011-04-08 07:21:55 --> Model Class Initialized
DEBUG - 2011-04-08 07:21:55 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-08 07:21:55 --> Database Driver Class Initialized
DEBUG - 2011-04-08 07:21:55 --> File loaded: application/views/table/main.php
DEBUG - 2011-04-08 07:21:55 --> Helper loaded: url_helper
DEBUG - 2011-04-08 07:21:55 --> File loaded: application/views/common/header.php
DEBUG - 2011-04-08 07:21:55 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-04-08 07:21:55 --> File loaded: application/views/common/footer.php
DEBUG - 2011-04-08 07:21:55 --> File loaded: application/views/layout/main.php
DEBUG - 2011-04-08 07:21:55 --> Final output sent to browser
DEBUG - 2011-04-08 07:21:55 --> Total execution time: 0.2784
DEBUG - 2011-04-08 07:21:56 --> Config Class Initialized
DEBUG - 2011-04-08 07:21:56 --> Hooks Class Initialized
DEBUG - 2011-04-08 07:21:56 --> Utf8 Class Initialized
DEBUG - 2011-04-08 07:21:56 --> UTF-8 Support Enabled
DEBUG - 2011-04-08 07:21:56 --> URI Class Initialized
DEBUG - 2011-04-08 07:21:56 --> Router Class Initialized
DEBUG - 2011-04-08 07:21:56 --> Output Class Initialized
DEBUG - 2011-04-08 07:21:56 --> Input Class Initialized
DEBUG - 2011-04-08 07:21:56 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-08 07:21:56 --> Language Class Initialized
DEBUG - 2011-04-08 07:21:56 --> Loader Class Initialized
DEBUG - 2011-04-08 07:21:56 --> Controller Class Initialized
DEBUG - 2011-04-08 07:21:56 --> Model Class Initialized
DEBUG - 2011-04-08 07:21:56 --> Model Class Initialized
DEBUG - 2011-04-08 07:21:56 --> Model Class Initialized
DEBUG - 2011-04-08 07:21:56 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-08 07:21:56 --> Database Driver Class Initialized
DEBUG - 2011-04-08 07:21:56 --> File loaded: application/views/table/main.php
DEBUG - 2011-04-08 07:21:56 --> Helper loaded: url_helper
DEBUG - 2011-04-08 07:21:56 --> File loaded: application/views/common/header.php
DEBUG - 2011-04-08 07:21:56 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-04-08 07:21:56 --> File loaded: application/views/common/footer.php
DEBUG - 2011-04-08 07:21:56 --> File loaded: application/views/layout/main.php
DEBUG - 2011-04-08 07:21:56 --> Final output sent to browser
DEBUG - 2011-04-08 07:21:56 --> Total execution time: 0.0708
DEBUG - 2011-04-08 07:21:56 --> Config Class Initialized
DEBUG - 2011-04-08 07:21:56 --> Hooks Class Initialized
DEBUG - 2011-04-08 07:21:56 --> Utf8 Class Initialized
DEBUG - 2011-04-08 07:21:56 --> UTF-8 Support Enabled
DEBUG - 2011-04-08 07:21:56 --> URI Class Initialized
DEBUG - 2011-04-08 07:21:56 --> Router Class Initialized
DEBUG - 2011-04-08 07:21:56 --> Output Class Initialized
DEBUG - 2011-04-08 07:21:56 --> Input Class Initialized
DEBUG - 2011-04-08 07:21:56 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-08 07:21:56 --> Language Class Initialized
DEBUG - 2011-04-08 07:21:56 --> Loader Class Initialized
DEBUG - 2011-04-08 07:21:56 --> Controller Class Initialized
DEBUG - 2011-04-08 07:21:56 --> Model Class Initialized
DEBUG - 2011-04-08 07:21:56 --> Model Class Initialized
DEBUG - 2011-04-08 07:21:56 --> Model Class Initialized
DEBUG - 2011-04-08 07:21:56 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-08 07:21:56 --> Database Driver Class Initialized
DEBUG - 2011-04-08 07:21:56 --> File loaded: application/views/table/main.php
DEBUG - 2011-04-08 07:21:56 --> Helper loaded: url_helper
DEBUG - 2011-04-08 07:21:56 --> File loaded: application/views/common/header.php
DEBUG - 2011-04-08 07:21:56 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-04-08 07:21:56 --> File loaded: application/views/common/footer.php
DEBUG - 2011-04-08 07:21:56 --> File loaded: application/views/layout/main.php
DEBUG - 2011-04-08 07:21:56 --> Final output sent to browser
DEBUG - 2011-04-08 07:21:56 --> Total execution time: 0.0772
DEBUG - 2011-04-08 07:22:22 --> Config Class Initialized
DEBUG - 2011-04-08 07:22:22 --> Hooks Class Initialized
DEBUG - 2011-04-08 07:22:22 --> Utf8 Class Initialized
DEBUG - 2011-04-08 07:22:22 --> UTF-8 Support Enabled
DEBUG - 2011-04-08 07:22:22 --> URI Class Initialized
DEBUG - 2011-04-08 07:22:22 --> Router Class Initialized
DEBUG - 2011-04-08 07:22:22 --> Output Class Initialized
DEBUG - 2011-04-08 07:22:22 --> Input Class Initialized
DEBUG - 2011-04-08 07:22:22 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-08 07:22:22 --> Language Class Initialized
DEBUG - 2011-04-08 07:22:22 --> Loader Class Initialized
DEBUG - 2011-04-08 07:22:22 --> Controller Class Initialized
DEBUG - 2011-04-08 07:22:22 --> Model Class Initialized
DEBUG - 2011-04-08 07:22:22 --> Model Class Initialized
DEBUG - 2011-04-08 07:22:22 --> Model Class Initialized
DEBUG - 2011-04-08 07:22:22 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-08 07:22:22 --> Database Driver Class Initialized
DEBUG - 2011-04-08 07:22:22 --> File loaded: application/views/table/main.php
DEBUG - 2011-04-08 07:22:22 --> Helper loaded: url_helper
DEBUG - 2011-04-08 07:22:22 --> File loaded: application/views/common/header.php
DEBUG - 2011-04-08 07:22:22 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-04-08 07:22:22 --> File loaded: application/views/common/footer.php
DEBUG - 2011-04-08 07:22:22 --> File loaded: application/views/layout/main.php
DEBUG - 2011-04-08 07:22:22 --> Final output sent to browser
DEBUG - 2011-04-08 07:22:22 --> Total execution time: 0.3254
DEBUG - 2011-04-08 07:22:24 --> Config Class Initialized
DEBUG - 2011-04-08 07:22:24 --> Hooks Class Initialized
DEBUG - 2011-04-08 07:22:24 --> Utf8 Class Initialized
DEBUG - 2011-04-08 07:22:24 --> UTF-8 Support Enabled
DEBUG - 2011-04-08 07:22:24 --> URI Class Initialized
DEBUG - 2011-04-08 07:22:24 --> Router Class Initialized
DEBUG - 2011-04-08 07:22:24 --> Output Class Initialized
DEBUG - 2011-04-08 07:22:24 --> Input Class Initialized
DEBUG - 2011-04-08 07:22:24 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-08 07:22:24 --> Language Class Initialized
DEBUG - 2011-04-08 07:22:24 --> Loader Class Initialized
DEBUG - 2011-04-08 07:22:24 --> Controller Class Initialized
DEBUG - 2011-04-08 07:22:24 --> Model Class Initialized
DEBUG - 2011-04-08 07:22:24 --> Model Class Initialized
DEBUG - 2011-04-08 07:22:24 --> Model Class Initialized
DEBUG - 2011-04-08 07:22:24 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-08 07:22:24 --> Database Driver Class Initialized
DEBUG - 2011-04-08 07:22:24 --> File loaded: application/views/table/main.php
DEBUG - 2011-04-08 07:22:24 --> Helper loaded: url_helper
DEBUG - 2011-04-08 07:22:24 --> File loaded: application/views/common/header.php
DEBUG - 2011-04-08 07:22:24 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-04-08 07:22:24 --> File loaded: application/views/common/footer.php
DEBUG - 2011-04-08 07:22:24 --> File loaded: application/views/layout/main.php
DEBUG - 2011-04-08 07:22:24 --> Final output sent to browser
DEBUG - 2011-04-08 07:22:24 --> Total execution time: 0.0826
DEBUG - 2011-04-08 07:25:12 --> Config Class Initialized
DEBUG - 2011-04-08 07:25:12 --> Hooks Class Initialized
DEBUG - 2011-04-08 07:25:12 --> Utf8 Class Initialized
DEBUG - 2011-04-08 07:25:12 --> UTF-8 Support Enabled
DEBUG - 2011-04-08 07:25:12 --> URI Class Initialized
DEBUG - 2011-04-08 07:25:12 --> Router Class Initialized
DEBUG - 2011-04-08 07:25:12 --> Output Class Initialized
DEBUG - 2011-04-08 07:25:12 --> Input Class Initialized
DEBUG - 2011-04-08 07:25:12 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-08 07:25:12 --> Language Class Initialized
DEBUG - 2011-04-08 07:25:12 --> Loader Class Initialized
DEBUG - 2011-04-08 07:25:12 --> Controller Class Initialized
ERROR - 2011-04-08 07:25:12 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-04-08 07:25:12 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-04-08 07:25:12 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-04-08 07:25:12 --> Model Class Initialized
DEBUG - 2011-04-08 07:25:12 --> Model Class Initialized
DEBUG - 2011-04-08 07:25:12 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-08 07:25:12 --> Database Driver Class Initialized
DEBUG - 2011-04-08 07:25:12 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-04-08 07:25:12 --> Helper loaded: url_helper
DEBUG - 2011-04-08 07:25:12 --> File loaded: application/views/common/header.php
DEBUG - 2011-04-08 07:25:12 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-04-08 07:25:12 --> File loaded: application/views/common/footer.php
DEBUG - 2011-04-08 07:25:12 --> File loaded: application/views/layout/main.php
DEBUG - 2011-04-08 07:25:12 --> Final output sent to browser
DEBUG - 2011-04-08 07:25:12 --> Total execution time: 0.0299
DEBUG - 2011-04-08 07:25:14 --> Config Class Initialized
DEBUG - 2011-04-08 07:25:14 --> Hooks Class Initialized
DEBUG - 2011-04-08 07:25:14 --> Utf8 Class Initialized
DEBUG - 2011-04-08 07:25:14 --> UTF-8 Support Enabled
DEBUG - 2011-04-08 07:25:14 --> URI Class Initialized
DEBUG - 2011-04-08 07:25:14 --> Router Class Initialized
DEBUG - 2011-04-08 07:25:14 --> Output Class Initialized
DEBUG - 2011-04-08 07:25:14 --> Input Class Initialized
DEBUG - 2011-04-08 07:25:14 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-08 07:25:14 --> Language Class Initialized
DEBUG - 2011-04-08 07:25:14 --> Loader Class Initialized
DEBUG - 2011-04-08 07:25:14 --> Controller Class Initialized
DEBUG - 2011-04-08 07:25:14 --> Model Class Initialized
DEBUG - 2011-04-08 07:25:14 --> Model Class Initialized
DEBUG - 2011-04-08 07:25:14 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-08 07:25:14 --> Database Driver Class Initialized
DEBUG - 2011-04-08 07:25:15 --> Final output sent to browser
DEBUG - 2011-04-08 07:25:15 --> Total execution time: 0.7167
DEBUG - 2011-04-08 07:25:22 --> Config Class Initialized
DEBUG - 2011-04-08 07:25:22 --> Hooks Class Initialized
DEBUG - 2011-04-08 07:25:22 --> Utf8 Class Initialized
DEBUG - 2011-04-08 07:25:22 --> UTF-8 Support Enabled
DEBUG - 2011-04-08 07:25:22 --> URI Class Initialized
DEBUG - 2011-04-08 07:25:22 --> Router Class Initialized
DEBUG - 2011-04-08 07:25:22 --> Output Class Initialized
DEBUG - 2011-04-08 07:25:22 --> Input Class Initialized
DEBUG - 2011-04-08 07:25:22 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-08 07:25:22 --> Language Class Initialized
DEBUG - 2011-04-08 07:25:22 --> Loader Class Initialized
DEBUG - 2011-04-08 07:25:22 --> Controller Class Initialized
DEBUG - 2011-04-08 07:25:22 --> Model Class Initialized
DEBUG - 2011-04-08 07:25:22 --> Model Class Initialized
DEBUG - 2011-04-08 07:25:22 --> Model Class Initialized
DEBUG - 2011-04-08 07:25:22 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-08 07:25:22 --> Database Driver Class Initialized
DEBUG - 2011-04-08 07:25:22 --> File loaded: application/views/table/main.php
DEBUG - 2011-04-08 07:25:22 --> Helper loaded: url_helper
DEBUG - 2011-04-08 07:25:22 --> File loaded: application/views/common/header.php
DEBUG - 2011-04-08 07:25:22 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-04-08 07:25:22 --> File loaded: application/views/common/footer.php
DEBUG - 2011-04-08 07:25:22 --> File loaded: application/views/layout/main.php
DEBUG - 2011-04-08 07:25:22 --> Final output sent to browser
DEBUG - 2011-04-08 07:25:22 --> Total execution time: 0.0616
DEBUG - 2011-04-08 07:25:48 --> Config Class Initialized
DEBUG - 2011-04-08 07:25:48 --> Hooks Class Initialized
DEBUG - 2011-04-08 07:25:48 --> Utf8 Class Initialized
DEBUG - 2011-04-08 07:25:48 --> UTF-8 Support Enabled
DEBUG - 2011-04-08 07:25:48 --> URI Class Initialized
DEBUG - 2011-04-08 07:25:48 --> Router Class Initialized
DEBUG - 2011-04-08 07:25:48 --> Output Class Initialized
DEBUG - 2011-04-08 07:25:48 --> Input Class Initialized
DEBUG - 2011-04-08 07:25:48 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-08 07:25:48 --> Language Class Initialized
DEBUG - 2011-04-08 07:25:48 --> Loader Class Initialized
DEBUG - 2011-04-08 07:25:48 --> Controller Class Initialized
DEBUG - 2011-04-08 07:25:48 --> Model Class Initialized
DEBUG - 2011-04-08 07:25:48 --> Model Class Initialized
DEBUG - 2011-04-08 07:25:48 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-08 07:25:48 --> Database Driver Class Initialized
DEBUG - 2011-04-08 07:25:49 --> Final output sent to browser
DEBUG - 2011-04-08 07:25:49 --> Total execution time: 0.6284
DEBUG - 2011-04-08 08:05:16 --> Config Class Initialized
DEBUG - 2011-04-08 08:05:16 --> Config Class Initialized
DEBUG - 2011-04-08 08:05:16 --> Hooks Class Initialized
DEBUG - 2011-04-08 08:05:16 --> Hooks Class Initialized
DEBUG - 2011-04-08 08:05:16 --> Utf8 Class Initialized
DEBUG - 2011-04-08 08:05:16 --> Utf8 Class Initialized
DEBUG - 2011-04-08 08:05:16 --> UTF-8 Support Enabled
DEBUG - 2011-04-08 08:05:16 --> UTF-8 Support Enabled
DEBUG - 2011-04-08 08:05:16 --> URI Class Initialized
DEBUG - 2011-04-08 08:05:16 --> URI Class Initialized
DEBUG - 2011-04-08 08:05:16 --> Router Class Initialized
DEBUG - 2011-04-08 08:05:16 --> Router Class Initialized
DEBUG - 2011-04-08 08:05:16 --> No URI present. Default controller set.
ERROR - 2011-04-08 08:05:16 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-04-08 08:05:16 --> Output Class Initialized
DEBUG - 2011-04-08 08:05:16 --> Input Class Initialized
DEBUG - 2011-04-08 08:05:16 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-08 08:05:16 --> Language Class Initialized
DEBUG - 2011-04-08 08:05:16 --> Loader Class Initialized
DEBUG - 2011-04-08 08:05:16 --> Controller Class Initialized
DEBUG - 2011-04-08 08:05:16 --> File loaded: application/views/splash/main.php
DEBUG - 2011-04-08 08:05:16 --> Helper loaded: url_helper
DEBUG - 2011-04-08 08:05:16 --> File loaded: application/views/common/header.php
DEBUG - 2011-04-08 08:05:16 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-04-08 08:05:16 --> File loaded: application/views/common/footer.php
DEBUG - 2011-04-08 08:05:16 --> File loaded: application/views/layout/main.php
DEBUG - 2011-04-08 08:05:16 --> Final output sent to browser
DEBUG - 2011-04-08 08:05:16 --> Total execution time: 0.2582
DEBUG - 2011-04-08 08:15:23 --> Config Class Initialized
DEBUG - 2011-04-08 08:15:23 --> Hooks Class Initialized
DEBUG - 2011-04-08 08:15:23 --> Utf8 Class Initialized
DEBUG - 2011-04-08 08:15:23 --> UTF-8 Support Enabled
DEBUG - 2011-04-08 08:15:23 --> URI Class Initialized
DEBUG - 2011-04-08 08:15:23 --> Router Class Initialized
DEBUG - 2011-04-08 08:15:23 --> Output Class Initialized
DEBUG - 2011-04-08 08:15:23 --> Input Class Initialized
DEBUG - 2011-04-08 08:15:23 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-08 08:15:23 --> Language Class Initialized
DEBUG - 2011-04-08 08:15:23 --> Loader Class Initialized
DEBUG - 2011-04-08 08:15:23 --> Controller Class Initialized
ERROR - 2011-04-08 08:15:23 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-04-08 08:15:23 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-04-08 08:15:23 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-04-08 08:15:23 --> Model Class Initialized
DEBUG - 2011-04-08 08:15:23 --> Model Class Initialized
DEBUG - 2011-04-08 08:15:23 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-08 08:15:23 --> Database Driver Class Initialized
DEBUG - 2011-04-08 08:15:23 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-04-08 08:15:23 --> Helper loaded: url_helper
DEBUG - 2011-04-08 08:15:23 --> File loaded: application/views/common/header.php
DEBUG - 2011-04-08 08:15:23 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-04-08 08:15:23 --> File loaded: application/views/common/footer.php
DEBUG - 2011-04-08 08:15:23 --> File loaded: application/views/layout/main.php
DEBUG - 2011-04-08 08:15:23 --> Final output sent to browser
DEBUG - 2011-04-08 08:15:23 --> Total execution time: 0.3448
DEBUG - 2011-04-08 08:15:28 --> Config Class Initialized
DEBUG - 2011-04-08 08:15:28 --> Hooks Class Initialized
DEBUG - 2011-04-08 08:15:28 --> Utf8 Class Initialized
DEBUG - 2011-04-08 08:15:28 --> UTF-8 Support Enabled
DEBUG - 2011-04-08 08:15:28 --> URI Class Initialized
DEBUG - 2011-04-08 08:15:28 --> Router Class Initialized
DEBUG - 2011-04-08 08:15:28 --> Output Class Initialized
DEBUG - 2011-04-08 08:15:28 --> Input Class Initialized
DEBUG - 2011-04-08 08:15:28 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-08 08:15:28 --> Language Class Initialized
DEBUG - 2011-04-08 08:15:28 --> Loader Class Initialized
DEBUG - 2011-04-08 08:15:28 --> Controller Class Initialized
DEBUG - 2011-04-08 08:15:28 --> Model Class Initialized
DEBUG - 2011-04-08 08:15:28 --> Model Class Initialized
DEBUG - 2011-04-08 08:15:28 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-08 08:15:28 --> Database Driver Class Initialized
DEBUG - 2011-04-08 08:15:29 --> Final output sent to browser
DEBUG - 2011-04-08 08:15:29 --> Total execution time: 0.6686
DEBUG - 2011-04-08 08:15:34 --> Config Class Initialized
DEBUG - 2011-04-08 08:15:34 --> Hooks Class Initialized
DEBUG - 2011-04-08 08:15:34 --> Utf8 Class Initialized
DEBUG - 2011-04-08 08:15:34 --> UTF-8 Support Enabled
DEBUG - 2011-04-08 08:15:34 --> URI Class Initialized
DEBUG - 2011-04-08 08:15:34 --> Router Class Initialized
ERROR - 2011-04-08 08:15:34 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-04-08 08:16:51 --> Config Class Initialized
DEBUG - 2011-04-08 08:16:51 --> Hooks Class Initialized
DEBUG - 2011-04-08 08:16:51 --> Utf8 Class Initialized
DEBUG - 2011-04-08 08:16:51 --> UTF-8 Support Enabled
DEBUG - 2011-04-08 08:16:51 --> URI Class Initialized
DEBUG - 2011-04-08 08:16:51 --> Router Class Initialized
DEBUG - 2011-04-08 08:16:51 --> Output Class Initialized
DEBUG - 2011-04-08 08:16:51 --> Input Class Initialized
DEBUG - 2011-04-08 08:16:51 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-08 08:16:51 --> Language Class Initialized
DEBUG - 2011-04-08 08:16:51 --> Loader Class Initialized
DEBUG - 2011-04-08 08:16:51 --> Controller Class Initialized
ERROR - 2011-04-08 08:16:51 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-04-08 08:16:51 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-04-08 08:16:51 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-04-08 08:16:51 --> Model Class Initialized
DEBUG - 2011-04-08 08:16:51 --> Model Class Initialized
DEBUG - 2011-04-08 08:16:51 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-08 08:16:51 --> Database Driver Class Initialized
DEBUG - 2011-04-08 08:16:51 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-04-08 08:16:51 --> Helper loaded: url_helper
DEBUG - 2011-04-08 08:16:51 --> File loaded: application/views/common/header.php
DEBUG - 2011-04-08 08:16:51 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-04-08 08:16:51 --> File loaded: application/views/common/footer.php
DEBUG - 2011-04-08 08:16:51 --> File loaded: application/views/layout/main.php
DEBUG - 2011-04-08 08:16:51 --> Final output sent to browser
DEBUG - 2011-04-08 08:16:51 --> Total execution time: 0.0306
DEBUG - 2011-04-08 08:16:53 --> Config Class Initialized
DEBUG - 2011-04-08 08:16:53 --> Hooks Class Initialized
DEBUG - 2011-04-08 08:16:53 --> Utf8 Class Initialized
DEBUG - 2011-04-08 08:16:53 --> UTF-8 Support Enabled
DEBUG - 2011-04-08 08:16:53 --> URI Class Initialized
DEBUG - 2011-04-08 08:16:53 --> Router Class Initialized
DEBUG - 2011-04-08 08:16:53 --> Output Class Initialized
DEBUG - 2011-04-08 08:16:53 --> Input Class Initialized
DEBUG - 2011-04-08 08:16:53 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-08 08:16:53 --> Language Class Initialized
DEBUG - 2011-04-08 08:16:53 --> Loader Class Initialized
DEBUG - 2011-04-08 08:16:53 --> Controller Class Initialized
DEBUG - 2011-04-08 08:16:53 --> Model Class Initialized
DEBUG - 2011-04-08 08:16:53 --> Model Class Initialized
DEBUG - 2011-04-08 08:16:53 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-08 08:16:53 --> Database Driver Class Initialized
DEBUG - 2011-04-08 08:16:53 --> Final output sent to browser
DEBUG - 2011-04-08 08:16:53 --> Total execution time: 0.6948
DEBUG - 2011-04-08 08:16:59 --> Config Class Initialized
DEBUG - 2011-04-08 08:16:59 --> Hooks Class Initialized
DEBUG - 2011-04-08 08:16:59 --> Utf8 Class Initialized
DEBUG - 2011-04-08 08:16:59 --> UTF-8 Support Enabled
DEBUG - 2011-04-08 08:16:59 --> URI Class Initialized
DEBUG - 2011-04-08 08:16:59 --> Router Class Initialized
ERROR - 2011-04-08 08:16:59 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-04-08 08:17:04 --> Config Class Initialized
DEBUG - 2011-04-08 08:17:04 --> Hooks Class Initialized
DEBUG - 2011-04-08 08:17:04 --> Utf8 Class Initialized
DEBUG - 2011-04-08 08:17:04 --> UTF-8 Support Enabled
DEBUG - 2011-04-08 08:17:04 --> URI Class Initialized
DEBUG - 2011-04-08 08:17:04 --> Router Class Initialized
DEBUG - 2011-04-08 08:17:04 --> Output Class Initialized
DEBUG - 2011-04-08 08:17:04 --> Input Class Initialized
DEBUG - 2011-04-08 08:17:04 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-08 08:17:04 --> Language Class Initialized
DEBUG - 2011-04-08 08:17:04 --> Loader Class Initialized
DEBUG - 2011-04-08 08:17:04 --> Controller Class Initialized
ERROR - 2011-04-08 08:17:04 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-04-08 08:17:04 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-04-08 08:17:04 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-04-08 08:17:04 --> Model Class Initialized
DEBUG - 2011-04-08 08:17:04 --> Model Class Initialized
DEBUG - 2011-04-08 08:17:04 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-08 08:17:04 --> Database Driver Class Initialized
DEBUG - 2011-04-08 08:17:04 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-04-08 08:17:04 --> Helper loaded: url_helper
DEBUG - 2011-04-08 08:17:04 --> File loaded: application/views/common/header.php
DEBUG - 2011-04-08 08:17:04 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-04-08 08:17:04 --> File loaded: application/views/common/footer.php
DEBUG - 2011-04-08 08:17:04 --> File loaded: application/views/layout/main.php
DEBUG - 2011-04-08 08:17:04 --> Final output sent to browser
DEBUG - 2011-04-08 08:17:04 --> Total execution time: 0.0293
DEBUG - 2011-04-08 08:17:05 --> Config Class Initialized
DEBUG - 2011-04-08 08:17:05 --> Hooks Class Initialized
DEBUG - 2011-04-08 08:17:05 --> Utf8 Class Initialized
DEBUG - 2011-04-08 08:17:05 --> UTF-8 Support Enabled
DEBUG - 2011-04-08 08:17:05 --> URI Class Initialized
DEBUG - 2011-04-08 08:17:05 --> Router Class Initialized
DEBUG - 2011-04-08 08:17:05 --> Output Class Initialized
DEBUG - 2011-04-08 08:17:05 --> Input Class Initialized
DEBUG - 2011-04-08 08:17:05 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-08 08:17:05 --> Language Class Initialized
DEBUG - 2011-04-08 08:17:05 --> Loader Class Initialized
DEBUG - 2011-04-08 08:17:05 --> Controller Class Initialized
DEBUG - 2011-04-08 08:17:05 --> Model Class Initialized
DEBUG - 2011-04-08 08:17:05 --> Model Class Initialized
DEBUG - 2011-04-08 08:17:05 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-08 08:17:05 --> Database Driver Class Initialized
DEBUG - 2011-04-08 08:17:06 --> Final output sent to browser
DEBUG - 2011-04-08 08:17:06 --> Total execution time: 0.5455
DEBUG - 2011-04-08 08:17:06 --> Config Class Initialized
DEBUG - 2011-04-08 08:17:06 --> Hooks Class Initialized
DEBUG - 2011-04-08 08:17:06 --> Utf8 Class Initialized
DEBUG - 2011-04-08 08:17:06 --> UTF-8 Support Enabled
DEBUG - 2011-04-08 08:17:06 --> URI Class Initialized
DEBUG - 2011-04-08 08:17:06 --> Router Class Initialized
DEBUG - 2011-04-08 08:17:06 --> Output Class Initialized
DEBUG - 2011-04-08 08:17:06 --> Input Class Initialized
DEBUG - 2011-04-08 08:17:06 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-08 08:17:06 --> Language Class Initialized
DEBUG - 2011-04-08 08:17:06 --> Loader Class Initialized
DEBUG - 2011-04-08 08:17:06 --> Controller Class Initialized
ERROR - 2011-04-08 08:17:06 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-04-08 08:17:06 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-04-08 08:17:06 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-04-08 08:17:06 --> Model Class Initialized
DEBUG - 2011-04-08 08:17:06 --> Model Class Initialized
DEBUG - 2011-04-08 08:17:06 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-08 08:17:06 --> Database Driver Class Initialized
DEBUG - 2011-04-08 08:17:06 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-04-08 08:17:06 --> Helper loaded: url_helper
DEBUG - 2011-04-08 08:17:06 --> File loaded: application/views/common/header.php
DEBUG - 2011-04-08 08:17:06 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-04-08 08:17:06 --> File loaded: application/views/common/footer.php
DEBUG - 2011-04-08 08:17:06 --> File loaded: application/views/layout/main.php
DEBUG - 2011-04-08 08:17:06 --> Final output sent to browser
DEBUG - 2011-04-08 08:17:06 --> Total execution time: 0.0311
DEBUG - 2011-04-08 08:17:10 --> Config Class Initialized
DEBUG - 2011-04-08 08:17:10 --> Hooks Class Initialized
DEBUG - 2011-04-08 08:17:10 --> Utf8 Class Initialized
DEBUG - 2011-04-08 08:17:10 --> UTF-8 Support Enabled
DEBUG - 2011-04-08 08:17:10 --> URI Class Initialized
DEBUG - 2011-04-08 08:17:10 --> Router Class Initialized
ERROR - 2011-04-08 08:17:10 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-04-08 08:17:16 --> Config Class Initialized
DEBUG - 2011-04-08 08:17:16 --> Hooks Class Initialized
DEBUG - 2011-04-08 08:17:16 --> Utf8 Class Initialized
DEBUG - 2011-04-08 08:17:16 --> UTF-8 Support Enabled
DEBUG - 2011-04-08 08:17:16 --> URI Class Initialized
DEBUG - 2011-04-08 08:17:16 --> Router Class Initialized
DEBUG - 2011-04-08 08:17:16 --> Output Class Initialized
DEBUG - 2011-04-08 08:17:16 --> Input Class Initialized
DEBUG - 2011-04-08 08:17:16 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-08 08:17:16 --> Language Class Initialized
DEBUG - 2011-04-08 08:17:16 --> Loader Class Initialized
DEBUG - 2011-04-08 08:17:16 --> Controller Class Initialized
ERROR - 2011-04-08 08:17:16 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-04-08 08:17:16 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-04-08 08:17:16 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-04-08 08:17:16 --> Model Class Initialized
DEBUG - 2011-04-08 08:17:16 --> Model Class Initialized
DEBUG - 2011-04-08 08:17:16 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-08 08:17:16 --> Database Driver Class Initialized
DEBUG - 2011-04-08 08:17:16 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-04-08 08:17:16 --> Helper loaded: url_helper
DEBUG - 2011-04-08 08:17:16 --> File loaded: application/views/common/header.php
DEBUG - 2011-04-08 08:17:16 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-04-08 08:17:16 --> File loaded: application/views/common/footer.php
DEBUG - 2011-04-08 08:17:16 --> File loaded: application/views/layout/main.php
DEBUG - 2011-04-08 08:17:16 --> Final output sent to browser
DEBUG - 2011-04-08 08:17:16 --> Total execution time: 0.0279
DEBUG - 2011-04-08 08:17:17 --> Config Class Initialized
DEBUG - 2011-04-08 08:17:17 --> Hooks Class Initialized
DEBUG - 2011-04-08 08:17:17 --> Utf8 Class Initialized
DEBUG - 2011-04-08 08:17:17 --> UTF-8 Support Enabled
DEBUG - 2011-04-08 08:17:17 --> URI Class Initialized
DEBUG - 2011-04-08 08:17:17 --> Router Class Initialized
DEBUG - 2011-04-08 08:17:17 --> Output Class Initialized
DEBUG - 2011-04-08 08:17:17 --> Input Class Initialized
DEBUG - 2011-04-08 08:17:17 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-08 08:17:17 --> Language Class Initialized
DEBUG - 2011-04-08 08:17:17 --> Loader Class Initialized
DEBUG - 2011-04-08 08:17:17 --> Controller Class Initialized
DEBUG - 2011-04-08 08:17:17 --> Model Class Initialized
DEBUG - 2011-04-08 08:17:17 --> Model Class Initialized
DEBUG - 2011-04-08 08:17:17 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-08 08:17:17 --> Database Driver Class Initialized
DEBUG - 2011-04-08 08:17:17 --> Config Class Initialized
DEBUG - 2011-04-08 08:17:17 --> Hooks Class Initialized
DEBUG - 2011-04-08 08:17:17 --> Utf8 Class Initialized
DEBUG - 2011-04-08 08:17:17 --> UTF-8 Support Enabled
DEBUG - 2011-04-08 08:17:17 --> URI Class Initialized
DEBUG - 2011-04-08 08:17:17 --> Router Class Initialized
DEBUG - 2011-04-08 08:17:17 --> Output Class Initialized
DEBUG - 2011-04-08 08:17:17 --> Input Class Initialized
DEBUG - 2011-04-08 08:17:17 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-08 08:17:17 --> Language Class Initialized
DEBUG - 2011-04-08 08:17:17 --> Loader Class Initialized
DEBUG - 2011-04-08 08:17:17 --> Controller Class Initialized
ERROR - 2011-04-08 08:17:17 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-04-08 08:17:17 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-04-08 08:17:17 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-04-08 08:17:17 --> Model Class Initialized
DEBUG - 2011-04-08 08:17:17 --> Model Class Initialized
DEBUG - 2011-04-08 08:17:17 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-08 08:17:17 --> Database Driver Class Initialized
DEBUG - 2011-04-08 08:17:17 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-04-08 08:17:17 --> Helper loaded: url_helper
DEBUG - 2011-04-08 08:17:17 --> File loaded: application/views/common/header.php
DEBUG - 2011-04-08 08:17:17 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-04-08 08:17:17 --> File loaded: application/views/common/footer.php
DEBUG - 2011-04-08 08:17:17 --> File loaded: application/views/layout/main.php
DEBUG - 2011-04-08 08:17:17 --> Final output sent to browser
DEBUG - 2011-04-08 08:17:17 --> Total execution time: 0.0276
DEBUG - 2011-04-08 08:17:18 --> Final output sent to browser
DEBUG - 2011-04-08 08:17:18 --> Total execution time: 0.6851
DEBUG - 2011-04-08 09:04:49 --> Config Class Initialized
DEBUG - 2011-04-08 09:04:49 --> Hooks Class Initialized
DEBUG - 2011-04-08 09:04:49 --> Utf8 Class Initialized
DEBUG - 2011-04-08 09:04:49 --> UTF-8 Support Enabled
DEBUG - 2011-04-08 09:04:49 --> URI Class Initialized
DEBUG - 2011-04-08 09:04:49 --> Router Class Initialized
DEBUG - 2011-04-08 09:04:49 --> Output Class Initialized
DEBUG - 2011-04-08 09:04:49 --> Input Class Initialized
DEBUG - 2011-04-08 09:04:49 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-08 09:04:49 --> Language Class Initialized
DEBUG - 2011-04-08 09:04:49 --> Loader Class Initialized
DEBUG - 2011-04-08 09:04:49 --> Controller Class Initialized
ERROR - 2011-04-08 09:04:49 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-04-08 09:04:49 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-04-08 09:04:49 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-04-08 09:04:49 --> Model Class Initialized
DEBUG - 2011-04-08 09:04:49 --> Model Class Initialized
DEBUG - 2011-04-08 09:04:49 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-08 09:04:50 --> Database Driver Class Initialized
DEBUG - 2011-04-08 09:04:50 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-04-08 09:04:50 --> Helper loaded: url_helper
DEBUG - 2011-04-08 09:04:50 --> File loaded: application/views/common/header.php
DEBUG - 2011-04-08 09:04:50 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-04-08 09:04:50 --> File loaded: application/views/common/footer.php
DEBUG - 2011-04-08 09:04:50 --> File loaded: application/views/layout/main.php
DEBUG - 2011-04-08 09:04:50 --> Final output sent to browser
DEBUG - 2011-04-08 09:04:50 --> Total execution time: 0.3896
DEBUG - 2011-04-08 09:04:51 --> Config Class Initialized
DEBUG - 2011-04-08 09:04:51 --> Hooks Class Initialized
DEBUG - 2011-04-08 09:04:51 --> Utf8 Class Initialized
DEBUG - 2011-04-08 09:04:51 --> UTF-8 Support Enabled
DEBUG - 2011-04-08 09:04:51 --> URI Class Initialized
DEBUG - 2011-04-08 09:04:51 --> Router Class Initialized
DEBUG - 2011-04-08 09:04:51 --> Output Class Initialized
DEBUG - 2011-04-08 09:04:51 --> Input Class Initialized
DEBUG - 2011-04-08 09:04:51 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-08 09:04:51 --> Language Class Initialized
DEBUG - 2011-04-08 09:04:51 --> Loader Class Initialized
DEBUG - 2011-04-08 09:04:51 --> Controller Class Initialized
DEBUG - 2011-04-08 09:04:51 --> Model Class Initialized
DEBUG - 2011-04-08 09:04:51 --> Model Class Initialized
DEBUG - 2011-04-08 09:04:51 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-08 09:04:51 --> Database Driver Class Initialized
DEBUG - 2011-04-08 09:04:52 --> Final output sent to browser
DEBUG - 2011-04-08 09:04:52 --> Total execution time: 0.7272
DEBUG - 2011-04-08 09:04:53 --> Config Class Initialized
DEBUG - 2011-04-08 09:04:53 --> Hooks Class Initialized
DEBUG - 2011-04-08 09:04:53 --> Utf8 Class Initialized
DEBUG - 2011-04-08 09:04:53 --> UTF-8 Support Enabled
DEBUG - 2011-04-08 09:04:53 --> URI Class Initialized
DEBUG - 2011-04-08 09:04:53 --> Router Class Initialized
ERROR - 2011-04-08 09:04:53 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-04-08 09:04:54 --> Config Class Initialized
DEBUG - 2011-04-08 09:04:54 --> Hooks Class Initialized
DEBUG - 2011-04-08 09:04:54 --> Utf8 Class Initialized
DEBUG - 2011-04-08 09:04:54 --> UTF-8 Support Enabled
DEBUG - 2011-04-08 09:04:54 --> URI Class Initialized
DEBUG - 2011-04-08 09:04:54 --> Router Class Initialized
ERROR - 2011-04-08 09:04:54 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-04-08 09:04:54 --> Config Class Initialized
DEBUG - 2011-04-08 09:04:54 --> Hooks Class Initialized
DEBUG - 2011-04-08 09:04:54 --> Utf8 Class Initialized
DEBUG - 2011-04-08 09:04:54 --> UTF-8 Support Enabled
DEBUG - 2011-04-08 09:04:54 --> URI Class Initialized
DEBUG - 2011-04-08 09:04:54 --> Router Class Initialized
ERROR - 2011-04-08 09:04:54 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-04-08 09:50:12 --> Config Class Initialized
DEBUG - 2011-04-08 09:50:12 --> Hooks Class Initialized
DEBUG - 2011-04-08 09:50:12 --> Utf8 Class Initialized
DEBUG - 2011-04-08 09:50:12 --> UTF-8 Support Enabled
DEBUG - 2011-04-08 09:50:12 --> URI Class Initialized
DEBUG - 2011-04-08 09:50:12 --> Router Class Initialized
DEBUG - 2011-04-08 09:50:12 --> Output Class Initialized
DEBUG - 2011-04-08 09:50:12 --> Input Class Initialized
DEBUG - 2011-04-08 09:50:12 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-08 09:50:12 --> Language Class Initialized
DEBUG - 2011-04-08 09:50:12 --> Loader Class Initialized
DEBUG - 2011-04-08 09:50:12 --> Controller Class Initialized
ERROR - 2011-04-08 09:50:12 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-04-08 09:50:12 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-04-08 09:50:12 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-04-08 09:50:12 --> Model Class Initialized
DEBUG - 2011-04-08 09:50:12 --> Model Class Initialized
DEBUG - 2011-04-08 09:50:12 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-08 09:50:12 --> Database Driver Class Initialized
DEBUG - 2011-04-08 09:50:12 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-04-08 09:50:12 --> Helper loaded: url_helper
DEBUG - 2011-04-08 09:50:12 --> File loaded: application/views/common/header.php
DEBUG - 2011-04-08 09:50:12 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-04-08 09:50:12 --> File loaded: application/views/common/footer.php
DEBUG - 2011-04-08 09:50:12 --> File loaded: application/views/layout/main.php
DEBUG - 2011-04-08 09:50:12 --> Final output sent to browser
DEBUG - 2011-04-08 09:50:12 --> Total execution time: 0.3715
DEBUG - 2011-04-08 09:50:15 --> Config Class Initialized
DEBUG - 2011-04-08 09:50:15 --> Hooks Class Initialized
DEBUG - 2011-04-08 09:50:15 --> Utf8 Class Initialized
DEBUG - 2011-04-08 09:50:15 --> UTF-8 Support Enabled
DEBUG - 2011-04-08 09:50:15 --> URI Class Initialized
DEBUG - 2011-04-08 09:50:15 --> Router Class Initialized
DEBUG - 2011-04-08 09:50:15 --> Output Class Initialized
DEBUG - 2011-04-08 09:50:15 --> Input Class Initialized
DEBUG - 2011-04-08 09:50:15 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-08 09:50:15 --> Language Class Initialized
DEBUG - 2011-04-08 09:50:15 --> Loader Class Initialized
DEBUG - 2011-04-08 09:50:15 --> Controller Class Initialized
DEBUG - 2011-04-08 09:50:15 --> Model Class Initialized
DEBUG - 2011-04-08 09:50:15 --> Model Class Initialized
DEBUG - 2011-04-08 09:50:15 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-08 09:50:15 --> Database Driver Class Initialized
DEBUG - 2011-04-08 09:50:16 --> Final output sent to browser
DEBUG - 2011-04-08 09:50:16 --> Total execution time: 0.6865
DEBUG - 2011-04-08 09:50:32 --> Config Class Initialized
DEBUG - 2011-04-08 09:50:32 --> Hooks Class Initialized
DEBUG - 2011-04-08 09:50:32 --> Utf8 Class Initialized
DEBUG - 2011-04-08 09:50:32 --> UTF-8 Support Enabled
DEBUG - 2011-04-08 09:50:32 --> URI Class Initialized
DEBUG - 2011-04-08 09:50:32 --> Router Class Initialized
ERROR - 2011-04-08 09:50:32 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-04-08 09:50:34 --> Config Class Initialized
DEBUG - 2011-04-08 09:50:34 --> Hooks Class Initialized
DEBUG - 2011-04-08 09:50:34 --> Utf8 Class Initialized
DEBUG - 2011-04-08 09:50:34 --> UTF-8 Support Enabled
DEBUG - 2011-04-08 09:50:34 --> URI Class Initialized
DEBUG - 2011-04-08 09:50:34 --> Router Class Initialized
ERROR - 2011-04-08 09:50:34 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-04-08 09:50:34 --> Config Class Initialized
DEBUG - 2011-04-08 09:50:34 --> Hooks Class Initialized
DEBUG - 2011-04-08 09:50:34 --> Utf8 Class Initialized
DEBUG - 2011-04-08 09:50:34 --> UTF-8 Support Enabled
DEBUG - 2011-04-08 09:50:34 --> URI Class Initialized
DEBUG - 2011-04-08 09:50:34 --> Router Class Initialized
ERROR - 2011-04-08 09:50:34 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-04-08 09:51:13 --> Config Class Initialized
DEBUG - 2011-04-08 09:51:13 --> Hooks Class Initialized
DEBUG - 2011-04-08 09:51:13 --> Utf8 Class Initialized
DEBUG - 2011-04-08 09:51:13 --> UTF-8 Support Enabled
DEBUG - 2011-04-08 09:51:13 --> URI Class Initialized
DEBUG - 2011-04-08 09:51:13 --> Router Class Initialized
DEBUG - 2011-04-08 09:51:13 --> Output Class Initialized
DEBUG - 2011-04-08 09:51:13 --> Input Class Initialized
DEBUG - 2011-04-08 09:51:13 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-08 09:51:13 --> Language Class Initialized
DEBUG - 2011-04-08 09:51:13 --> Loader Class Initialized
DEBUG - 2011-04-08 09:51:13 --> Controller Class Initialized
ERROR - 2011-04-08 09:51:13 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-04-08 09:51:13 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-04-08 09:51:13 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-04-08 09:51:13 --> Model Class Initialized
DEBUG - 2011-04-08 09:51:13 --> Model Class Initialized
DEBUG - 2011-04-08 09:51:13 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-08 09:51:13 --> Database Driver Class Initialized
DEBUG - 2011-04-08 09:51:13 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-04-08 09:51:13 --> Helper loaded: url_helper
DEBUG - 2011-04-08 09:51:13 --> File loaded: application/views/common/header.php
DEBUG - 2011-04-08 09:51:13 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-04-08 09:51:13 --> File loaded: application/views/common/footer.php
DEBUG - 2011-04-08 09:51:13 --> File loaded: application/views/layout/main.php
DEBUG - 2011-04-08 09:51:13 --> Final output sent to browser
DEBUG - 2011-04-08 09:51:13 --> Total execution time: 0.0308
DEBUG - 2011-04-08 09:51:14 --> Config Class Initialized
DEBUG - 2011-04-08 09:51:14 --> Hooks Class Initialized
DEBUG - 2011-04-08 09:51:14 --> Utf8 Class Initialized
DEBUG - 2011-04-08 09:51:14 --> UTF-8 Support Enabled
DEBUG - 2011-04-08 09:51:14 --> URI Class Initialized
DEBUG - 2011-04-08 09:51:14 --> Router Class Initialized
DEBUG - 2011-04-08 09:51:14 --> Output Class Initialized
DEBUG - 2011-04-08 09:51:14 --> Input Class Initialized
DEBUG - 2011-04-08 09:51:14 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-08 09:51:14 --> Language Class Initialized
DEBUG - 2011-04-08 09:51:14 --> Loader Class Initialized
DEBUG - 2011-04-08 09:51:14 --> Controller Class Initialized
DEBUG - 2011-04-08 09:51:14 --> Model Class Initialized
DEBUG - 2011-04-08 09:51:14 --> Model Class Initialized
DEBUG - 2011-04-08 09:51:14 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-08 09:51:14 --> Database Driver Class Initialized
DEBUG - 2011-04-08 09:51:14 --> Final output sent to browser
DEBUG - 2011-04-08 09:51:14 --> Total execution time: 0.5789
DEBUG - 2011-04-08 09:51:31 --> Config Class Initialized
DEBUG - 2011-04-08 09:51:31 --> Hooks Class Initialized
DEBUG - 2011-04-08 09:51:31 --> Utf8 Class Initialized
DEBUG - 2011-04-08 09:51:31 --> UTF-8 Support Enabled
DEBUG - 2011-04-08 09:51:31 --> URI Class Initialized
DEBUG - 2011-04-08 09:51:31 --> Router Class Initialized
DEBUG - 2011-04-08 09:51:31 --> Output Class Initialized
DEBUG - 2011-04-08 09:51:31 --> Input Class Initialized
DEBUG - 2011-04-08 09:51:31 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-08 09:51:31 --> Language Class Initialized
DEBUG - 2011-04-08 09:51:31 --> Loader Class Initialized
DEBUG - 2011-04-08 09:51:31 --> Controller Class Initialized
ERROR - 2011-04-08 09:51:31 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-04-08 09:51:31 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-04-08 09:51:31 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-04-08 09:51:31 --> Model Class Initialized
DEBUG - 2011-04-08 09:51:31 --> Model Class Initialized
DEBUG - 2011-04-08 09:51:31 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-08 09:51:31 --> Database Driver Class Initialized
DEBUG - 2011-04-08 09:51:31 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-04-08 09:51:31 --> Helper loaded: url_helper
DEBUG - 2011-04-08 09:51:31 --> File loaded: application/views/common/header.php
DEBUG - 2011-04-08 09:51:31 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-04-08 09:51:31 --> File loaded: application/views/common/footer.php
DEBUG - 2011-04-08 09:51:31 --> File loaded: application/views/layout/main.php
DEBUG - 2011-04-08 09:51:31 --> Final output sent to browser
DEBUG - 2011-04-08 09:51:31 --> Total execution time: 0.0335
DEBUG - 2011-04-08 09:51:33 --> Config Class Initialized
DEBUG - 2011-04-08 09:51:33 --> Hooks Class Initialized
DEBUG - 2011-04-08 09:51:33 --> Utf8 Class Initialized
DEBUG - 2011-04-08 09:51:33 --> UTF-8 Support Enabled
DEBUG - 2011-04-08 09:51:33 --> URI Class Initialized
DEBUG - 2011-04-08 09:51:33 --> Router Class Initialized
DEBUG - 2011-04-08 09:51:33 --> Output Class Initialized
DEBUG - 2011-04-08 09:51:33 --> Input Class Initialized
DEBUG - 2011-04-08 09:51:33 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-08 09:51:33 --> Language Class Initialized
DEBUG - 2011-04-08 09:51:33 --> Loader Class Initialized
DEBUG - 2011-04-08 09:51:33 --> Controller Class Initialized
DEBUG - 2011-04-08 09:51:33 --> Model Class Initialized
DEBUG - 2011-04-08 09:51:33 --> Model Class Initialized
DEBUG - 2011-04-08 09:51:33 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-08 09:51:33 --> Database Driver Class Initialized
DEBUG - 2011-04-08 09:51:34 --> Final output sent to browser
DEBUG - 2011-04-08 09:51:34 --> Total execution time: 0.5292
DEBUG - 2011-04-08 09:51:48 --> Config Class Initialized
DEBUG - 2011-04-08 09:51:48 --> Hooks Class Initialized
DEBUG - 2011-04-08 09:51:48 --> Utf8 Class Initialized
DEBUG - 2011-04-08 09:51:48 --> UTF-8 Support Enabled
DEBUG - 2011-04-08 09:51:48 --> URI Class Initialized
DEBUG - 2011-04-08 09:51:48 --> Router Class Initialized
DEBUG - 2011-04-08 09:51:48 --> Output Class Initialized
DEBUG - 2011-04-08 09:51:48 --> Input Class Initialized
DEBUG - 2011-04-08 09:51:48 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-08 09:51:48 --> Language Class Initialized
DEBUG - 2011-04-08 09:51:48 --> Loader Class Initialized
DEBUG - 2011-04-08 09:51:48 --> Controller Class Initialized
ERROR - 2011-04-08 09:51:48 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-04-08 09:51:48 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-04-08 09:51:48 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-04-08 09:51:48 --> Model Class Initialized
DEBUG - 2011-04-08 09:51:48 --> Model Class Initialized
DEBUG - 2011-04-08 09:51:48 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-08 09:51:48 --> Database Driver Class Initialized
DEBUG - 2011-04-08 09:51:48 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-04-08 09:51:48 --> Helper loaded: url_helper
DEBUG - 2011-04-08 09:51:48 --> File loaded: application/views/common/header.php
DEBUG - 2011-04-08 09:51:48 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-04-08 09:51:48 --> File loaded: application/views/common/footer.php
DEBUG - 2011-04-08 09:51:48 --> File loaded: application/views/layout/main.php
DEBUG - 2011-04-08 09:51:48 --> Final output sent to browser
DEBUG - 2011-04-08 09:51:48 --> Total execution time: 0.0289
DEBUG - 2011-04-08 09:51:51 --> Config Class Initialized
DEBUG - 2011-04-08 09:51:51 --> Hooks Class Initialized
DEBUG - 2011-04-08 09:51:51 --> Utf8 Class Initialized
DEBUG - 2011-04-08 09:51:51 --> UTF-8 Support Enabled
DEBUG - 2011-04-08 09:51:51 --> URI Class Initialized
DEBUG - 2011-04-08 09:51:51 --> Router Class Initialized
DEBUG - 2011-04-08 09:51:51 --> Output Class Initialized
DEBUG - 2011-04-08 09:51:51 --> Input Class Initialized
DEBUG - 2011-04-08 09:51:51 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-08 09:51:51 --> Language Class Initialized
DEBUG - 2011-04-08 09:51:51 --> Loader Class Initialized
DEBUG - 2011-04-08 09:51:51 --> Controller Class Initialized
DEBUG - 2011-04-08 09:51:51 --> Model Class Initialized
DEBUG - 2011-04-08 09:51:51 --> Model Class Initialized
DEBUG - 2011-04-08 09:51:51 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-08 09:51:51 --> Database Driver Class Initialized
DEBUG - 2011-04-08 09:51:51 --> Final output sent to browser
DEBUG - 2011-04-08 09:51:51 --> Total execution time: 0.5054
DEBUG - 2011-04-08 09:52:10 --> Config Class Initialized
DEBUG - 2011-04-08 09:52:10 --> Hooks Class Initialized
DEBUG - 2011-04-08 09:52:10 --> Utf8 Class Initialized
DEBUG - 2011-04-08 09:52:10 --> UTF-8 Support Enabled
DEBUG - 2011-04-08 09:52:10 --> URI Class Initialized
DEBUG - 2011-04-08 09:52:10 --> Router Class Initialized
DEBUG - 2011-04-08 09:52:10 --> Output Class Initialized
DEBUG - 2011-04-08 09:52:10 --> Input Class Initialized
DEBUG - 2011-04-08 09:52:10 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-08 09:52:10 --> Language Class Initialized
DEBUG - 2011-04-08 09:52:10 --> Loader Class Initialized
DEBUG - 2011-04-08 09:52:10 --> Controller Class Initialized
ERROR - 2011-04-08 09:52:10 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-04-08 09:52:10 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-04-08 09:52:10 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-04-08 09:52:10 --> Model Class Initialized
DEBUG - 2011-04-08 09:52:10 --> Model Class Initialized
DEBUG - 2011-04-08 09:52:10 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-08 09:52:10 --> Database Driver Class Initialized
DEBUG - 2011-04-08 09:52:10 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-04-08 09:52:10 --> Helper loaded: url_helper
DEBUG - 2011-04-08 09:52:10 --> File loaded: application/views/common/header.php
DEBUG - 2011-04-08 09:52:10 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-04-08 09:52:10 --> File loaded: application/views/common/footer.php
DEBUG - 2011-04-08 09:52:10 --> File loaded: application/views/layout/main.php
DEBUG - 2011-04-08 09:52:10 --> Final output sent to browser
DEBUG - 2011-04-08 09:52:10 --> Total execution time: 0.0585
DEBUG - 2011-04-08 09:52:14 --> Config Class Initialized
DEBUG - 2011-04-08 09:52:14 --> Hooks Class Initialized
DEBUG - 2011-04-08 09:52:14 --> Utf8 Class Initialized
DEBUG - 2011-04-08 09:52:14 --> UTF-8 Support Enabled
DEBUG - 2011-04-08 09:52:14 --> URI Class Initialized
DEBUG - 2011-04-08 09:52:14 --> Router Class Initialized
DEBUG - 2011-04-08 09:52:14 --> Output Class Initialized
DEBUG - 2011-04-08 09:52:14 --> Input Class Initialized
DEBUG - 2011-04-08 09:52:14 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-08 09:52:14 --> Language Class Initialized
DEBUG - 2011-04-08 09:52:14 --> Loader Class Initialized
DEBUG - 2011-04-08 09:52:14 --> Controller Class Initialized
DEBUG - 2011-04-08 09:52:14 --> Model Class Initialized
DEBUG - 2011-04-08 09:52:14 --> Model Class Initialized
DEBUG - 2011-04-08 09:52:14 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-08 09:52:14 --> Database Driver Class Initialized
DEBUG - 2011-04-08 09:52:14 --> Final output sent to browser
DEBUG - 2011-04-08 09:52:14 --> Total execution time: 0.5451
DEBUG - 2011-04-08 09:52:17 --> Config Class Initialized
DEBUG - 2011-04-08 09:52:17 --> Hooks Class Initialized
DEBUG - 2011-04-08 09:52:17 --> Utf8 Class Initialized
DEBUG - 2011-04-08 09:52:17 --> UTF-8 Support Enabled
DEBUG - 2011-04-08 09:52:17 --> URI Class Initialized
DEBUG - 2011-04-08 09:52:17 --> Router Class Initialized
DEBUG - 2011-04-08 09:52:17 --> Output Class Initialized
DEBUG - 2011-04-08 09:52:17 --> Input Class Initialized
DEBUG - 2011-04-08 09:52:17 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-08 09:52:17 --> Language Class Initialized
DEBUG - 2011-04-08 09:52:17 --> Loader Class Initialized
DEBUG - 2011-04-08 09:52:17 --> Controller Class Initialized
DEBUG - 2011-04-08 09:52:17 --> Model Class Initialized
DEBUG - 2011-04-08 09:52:17 --> Model Class Initialized
DEBUG - 2011-04-08 09:52:17 --> Model Class Initialized
DEBUG - 2011-04-08 09:52:17 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-08 09:52:17 --> Database Driver Class Initialized
DEBUG - 2011-04-08 09:52:17 --> File loaded: application/views/table/main.php
DEBUG - 2011-04-08 09:52:17 --> Helper loaded: url_helper
DEBUG - 2011-04-08 09:52:17 --> File loaded: application/views/common/header.php
DEBUG - 2011-04-08 09:52:17 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-04-08 09:52:17 --> File loaded: application/views/common/footer.php
DEBUG - 2011-04-08 09:52:17 --> File loaded: application/views/layout/main.php
DEBUG - 2011-04-08 09:52:17 --> Final output sent to browser
DEBUG - 2011-04-08 09:52:17 --> Total execution time: 0.2693
DEBUG - 2011-04-08 09:52:34 --> Config Class Initialized
DEBUG - 2011-04-08 09:52:34 --> Hooks Class Initialized
DEBUG - 2011-04-08 09:52:34 --> Utf8 Class Initialized
DEBUG - 2011-04-08 09:52:34 --> UTF-8 Support Enabled
DEBUG - 2011-04-08 09:52:34 --> URI Class Initialized
DEBUG - 2011-04-08 09:52:34 --> Router Class Initialized
DEBUG - 2011-04-08 09:52:34 --> Output Class Initialized
DEBUG - 2011-04-08 09:52:34 --> Input Class Initialized
DEBUG - 2011-04-08 09:52:34 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-08 09:52:34 --> Language Class Initialized
DEBUG - 2011-04-08 09:52:34 --> Loader Class Initialized
DEBUG - 2011-04-08 09:52:34 --> Controller Class Initialized
ERROR - 2011-04-08 09:52:34 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-04-08 09:52:34 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-04-08 09:52:34 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-04-08 09:52:34 --> Model Class Initialized
DEBUG - 2011-04-08 09:52:34 --> Model Class Initialized
DEBUG - 2011-04-08 09:52:34 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-08 09:52:34 --> Database Driver Class Initialized
DEBUG - 2011-04-08 09:52:34 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-04-08 09:52:34 --> Helper loaded: url_helper
DEBUG - 2011-04-08 09:52:34 --> File loaded: application/views/common/header.php
DEBUG - 2011-04-08 09:52:34 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-04-08 09:52:34 --> File loaded: application/views/common/footer.php
DEBUG - 2011-04-08 09:52:34 --> File loaded: application/views/layout/main.php
DEBUG - 2011-04-08 09:52:34 --> Final output sent to browser
DEBUG - 2011-04-08 09:52:34 --> Total execution time: 0.0611
DEBUG - 2011-04-08 09:53:04 --> Config Class Initialized
DEBUG - 2011-04-08 09:53:04 --> Hooks Class Initialized
DEBUG - 2011-04-08 09:53:04 --> Utf8 Class Initialized
DEBUG - 2011-04-08 09:53:04 --> UTF-8 Support Enabled
DEBUG - 2011-04-08 09:53:04 --> URI Class Initialized
DEBUG - 2011-04-08 09:53:04 --> Router Class Initialized
DEBUG - 2011-04-08 09:53:04 --> Output Class Initialized
DEBUG - 2011-04-08 09:53:04 --> Input Class Initialized
DEBUG - 2011-04-08 09:53:04 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-08 09:53:04 --> Language Class Initialized
DEBUG - 2011-04-08 09:53:04 --> Loader Class Initialized
DEBUG - 2011-04-08 09:53:04 --> Controller Class Initialized
ERROR - 2011-04-08 09:53:04 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-04-08 09:53:04 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-04-08 09:53:04 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-04-08 09:53:04 --> Model Class Initialized
DEBUG - 2011-04-08 09:53:04 --> Model Class Initialized
DEBUG - 2011-04-08 09:53:04 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-08 09:53:04 --> Database Driver Class Initialized
DEBUG - 2011-04-08 09:53:04 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-04-08 09:53:04 --> Helper loaded: url_helper
DEBUG - 2011-04-08 09:53:04 --> File loaded: application/views/common/header.php
DEBUG - 2011-04-08 09:53:04 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-04-08 09:53:04 --> File loaded: application/views/common/footer.php
DEBUG - 2011-04-08 09:53:04 --> File loaded: application/views/layout/main.php
DEBUG - 2011-04-08 09:53:04 --> Final output sent to browser
DEBUG - 2011-04-08 09:53:04 --> Total execution time: 0.0307
DEBUG - 2011-04-08 09:53:55 --> Config Class Initialized
DEBUG - 2011-04-08 09:53:55 --> Hooks Class Initialized
DEBUG - 2011-04-08 09:53:55 --> Utf8 Class Initialized
DEBUG - 2011-04-08 09:53:55 --> UTF-8 Support Enabled
DEBUG - 2011-04-08 09:53:55 --> URI Class Initialized
DEBUG - 2011-04-08 09:53:55 --> Router Class Initialized
DEBUG - 2011-04-08 09:53:55 --> Output Class Initialized
DEBUG - 2011-04-08 09:53:55 --> Input Class Initialized
DEBUG - 2011-04-08 09:53:55 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-08 09:53:55 --> Language Class Initialized
DEBUG - 2011-04-08 09:53:55 --> Loader Class Initialized
DEBUG - 2011-04-08 09:53:55 --> Controller Class Initialized
DEBUG - 2011-04-08 09:53:55 --> Model Class Initialized
DEBUG - 2011-04-08 09:53:55 --> Model Class Initialized
DEBUG - 2011-04-08 09:53:55 --> Model Class Initialized
DEBUG - 2011-04-08 09:53:55 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-08 09:53:55 --> Database Driver Class Initialized
DEBUG - 2011-04-08 09:53:56 --> File loaded: application/views/table/main.php
DEBUG - 2011-04-08 09:53:56 --> Helper loaded: url_helper
DEBUG - 2011-04-08 09:53:56 --> File loaded: application/views/common/header.php
DEBUG - 2011-04-08 09:53:56 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-04-08 09:53:56 --> File loaded: application/views/common/footer.php
DEBUG - 2011-04-08 09:53:56 --> File loaded: application/views/layout/main.php
DEBUG - 2011-04-08 09:53:56 --> Final output sent to browser
DEBUG - 2011-04-08 09:53:56 --> Total execution time: 0.8312
DEBUG - 2011-04-08 09:54:43 --> Config Class Initialized
DEBUG - 2011-04-08 09:54:43 --> Hooks Class Initialized
DEBUG - 2011-04-08 09:54:43 --> Utf8 Class Initialized
DEBUG - 2011-04-08 09:54:43 --> UTF-8 Support Enabled
DEBUG - 2011-04-08 09:54:43 --> URI Class Initialized
DEBUG - 2011-04-08 09:54:43 --> Router Class Initialized
DEBUG - 2011-04-08 09:54:43 --> Output Class Initialized
DEBUG - 2011-04-08 09:54:43 --> Input Class Initialized
DEBUG - 2011-04-08 09:54:43 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-08 09:54:43 --> Language Class Initialized
DEBUG - 2011-04-08 09:54:43 --> Loader Class Initialized
DEBUG - 2011-04-08 09:54:43 --> Controller Class Initialized
DEBUG - 2011-04-08 09:54:43 --> Model Class Initialized
DEBUG - 2011-04-08 09:54:43 --> Model Class Initialized
DEBUG - 2011-04-08 09:54:43 --> Model Class Initialized
DEBUG - 2011-04-08 09:54:43 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-08 09:54:43 --> Database Driver Class Initialized
DEBUG - 2011-04-08 09:54:43 --> File loaded: application/views/table/main.php
DEBUG - 2011-04-08 09:54:43 --> Helper loaded: url_helper
DEBUG - 2011-04-08 09:54:44 --> File loaded: application/views/common/header.php
DEBUG - 2011-04-08 09:54:44 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-04-08 09:54:44 --> File loaded: application/views/common/footer.php
DEBUG - 2011-04-08 09:54:44 --> File loaded: application/views/layout/main.php
DEBUG - 2011-04-08 09:54:44 --> Final output sent to browser
DEBUG - 2011-04-08 09:54:44 --> Total execution time: 0.0470
DEBUG - 2011-04-08 11:17:46 --> Config Class Initialized
DEBUG - 2011-04-08 11:17:46 --> Hooks Class Initialized
DEBUG - 2011-04-08 11:17:46 --> Utf8 Class Initialized
DEBUG - 2011-04-08 11:17:46 --> UTF-8 Support Enabled
DEBUG - 2011-04-08 11:17:46 --> URI Class Initialized
DEBUG - 2011-04-08 11:17:46 --> Router Class Initialized
ERROR - 2011-04-08 11:17:46 --> 404 Page Not Found --> robots.txt
DEBUG - 2011-04-08 11:17:47 --> Config Class Initialized
DEBUG - 2011-04-08 11:17:47 --> Hooks Class Initialized
DEBUG - 2011-04-08 11:17:47 --> Utf8 Class Initialized
DEBUG - 2011-04-08 11:17:47 --> UTF-8 Support Enabled
DEBUG - 2011-04-08 11:17:47 --> URI Class Initialized
DEBUG - 2011-04-08 11:17:47 --> Router Class Initialized
DEBUG - 2011-04-08 11:17:47 --> Output Class Initialized
DEBUG - 2011-04-08 11:17:47 --> Input Class Initialized
DEBUG - 2011-04-08 11:17:47 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-08 11:17:47 --> Language Class Initialized
DEBUG - 2011-04-08 11:17:47 --> Loader Class Initialized
DEBUG - 2011-04-08 11:17:47 --> Controller Class Initialized
ERROR - 2011-04-08 11:17:47 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-04-08 11:17:47 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-04-08 11:17:47 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-04-08 11:17:47 --> Model Class Initialized
DEBUG - 2011-04-08 11:17:47 --> Model Class Initialized
DEBUG - 2011-04-08 11:17:47 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-08 11:17:47 --> Database Driver Class Initialized
DEBUG - 2011-04-08 11:17:47 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-04-08 11:17:47 --> Helper loaded: url_helper
DEBUG - 2011-04-08 11:17:47 --> File loaded: application/views/common/header.php
DEBUG - 2011-04-08 11:17:47 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-04-08 11:17:47 --> File loaded: application/views/common/footer.php
DEBUG - 2011-04-08 11:17:47 --> File loaded: application/views/layout/main.php
DEBUG - 2011-04-08 11:17:47 --> Final output sent to browser
DEBUG - 2011-04-08 11:17:47 --> Total execution time: 0.2442
DEBUG - 2011-04-08 11:18:17 --> Config Class Initialized
DEBUG - 2011-04-08 11:18:17 --> Hooks Class Initialized
DEBUG - 2011-04-08 11:18:17 --> Utf8 Class Initialized
DEBUG - 2011-04-08 11:18:17 --> UTF-8 Support Enabled
DEBUG - 2011-04-08 11:18:17 --> URI Class Initialized
DEBUG - 2011-04-08 11:18:17 --> Router Class Initialized
DEBUG - 2011-04-08 11:18:17 --> Output Class Initialized
DEBUG - 2011-04-08 11:18:17 --> Input Class Initialized
DEBUG - 2011-04-08 11:18:17 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-08 11:18:17 --> Language Class Initialized
DEBUG - 2011-04-08 11:18:17 --> Loader Class Initialized
DEBUG - 2011-04-08 11:18:17 --> Controller Class Initialized
DEBUG - 2011-04-08 11:18:17 --> Model Class Initialized
DEBUG - 2011-04-08 11:18:17 --> Model Class Initialized
DEBUG - 2011-04-08 11:18:17 --> Model Class Initialized
DEBUG - 2011-04-08 11:18:17 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-08 11:18:17 --> Database Driver Class Initialized
DEBUG - 2011-04-08 11:18:18 --> File loaded: application/views/table/main.php
DEBUG - 2011-04-08 11:18:18 --> Helper loaded: url_helper
DEBUG - 2011-04-08 11:18:18 --> File loaded: application/views/common/header.php
DEBUG - 2011-04-08 11:18:18 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-04-08 11:18:18 --> File loaded: application/views/common/footer.php
DEBUG - 2011-04-08 11:18:18 --> File loaded: application/views/layout/main.php
DEBUG - 2011-04-08 11:18:18 --> Final output sent to browser
DEBUG - 2011-04-08 11:18:18 --> Total execution time: 0.3523
DEBUG - 2011-04-08 11:19:52 --> Config Class Initialized
DEBUG - 2011-04-08 11:19:52 --> Hooks Class Initialized
DEBUG - 2011-04-08 11:19:52 --> Utf8 Class Initialized
DEBUG - 2011-04-08 11:19:52 --> UTF-8 Support Enabled
DEBUG - 2011-04-08 11:19:52 --> URI Class Initialized
DEBUG - 2011-04-08 11:19:52 --> Router Class Initialized
DEBUG - 2011-04-08 11:19:52 --> No URI present. Default controller set.
DEBUG - 2011-04-08 11:19:52 --> Output Class Initialized
DEBUG - 2011-04-08 11:19:52 --> Input Class Initialized
DEBUG - 2011-04-08 11:19:52 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-08 11:19:52 --> Language Class Initialized
DEBUG - 2011-04-08 11:19:52 --> Loader Class Initialized
DEBUG - 2011-04-08 11:19:52 --> Controller Class Initialized
DEBUG - 2011-04-08 11:19:52 --> File loaded: application/views/splash/main.php
DEBUG - 2011-04-08 11:19:52 --> Helper loaded: url_helper
DEBUG - 2011-04-08 11:19:52 --> File loaded: application/views/common/header.php
DEBUG - 2011-04-08 11:19:52 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-04-08 11:19:52 --> File loaded: application/views/common/footer.php
DEBUG - 2011-04-08 11:19:52 --> File loaded: application/views/layout/main.php
DEBUG - 2011-04-08 11:19:52 --> Final output sent to browser
DEBUG - 2011-04-08 11:19:52 --> Total execution time: 0.0661
DEBUG - 2011-04-08 12:52:21 --> Config Class Initialized
DEBUG - 2011-04-08 12:52:21 --> Hooks Class Initialized
DEBUG - 2011-04-08 12:52:21 --> Utf8 Class Initialized
DEBUG - 2011-04-08 12:52:21 --> UTF-8 Support Enabled
DEBUG - 2011-04-08 12:52:21 --> URI Class Initialized
DEBUG - 2011-04-08 12:52:21 --> Router Class Initialized
DEBUG - 2011-04-08 12:52:22 --> Output Class Initialized
DEBUG - 2011-04-08 12:52:22 --> Input Class Initialized
DEBUG - 2011-04-08 12:52:22 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-08 12:52:22 --> Language Class Initialized
DEBUG - 2011-04-08 12:52:22 --> Loader Class Initialized
DEBUG - 2011-04-08 12:52:22 --> Controller Class Initialized
ERROR - 2011-04-08 12:52:22 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-04-08 12:52:22 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-04-08 12:52:22 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-04-08 12:52:22 --> Model Class Initialized
DEBUG - 2011-04-08 12:52:22 --> Model Class Initialized
DEBUG - 2011-04-08 12:52:22 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-08 12:52:22 --> Database Driver Class Initialized
DEBUG - 2011-04-08 12:52:22 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-04-08 12:52:22 --> Helper loaded: url_helper
DEBUG - 2011-04-08 12:52:22 --> File loaded: application/views/common/header.php
DEBUG - 2011-04-08 12:52:22 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-04-08 12:52:22 --> File loaded: application/views/common/footer.php
DEBUG - 2011-04-08 12:52:22 --> File loaded: application/views/layout/main.php
DEBUG - 2011-04-08 12:52:22 --> Final output sent to browser
DEBUG - 2011-04-08 12:52:22 --> Total execution time: 0.4159
DEBUG - 2011-04-08 12:52:23 --> Config Class Initialized
DEBUG - 2011-04-08 12:52:23 --> Hooks Class Initialized
DEBUG - 2011-04-08 12:52:23 --> Utf8 Class Initialized
DEBUG - 2011-04-08 12:52:23 --> UTF-8 Support Enabled
DEBUG - 2011-04-08 12:52:23 --> URI Class Initialized
DEBUG - 2011-04-08 12:52:23 --> Router Class Initialized
DEBUG - 2011-04-08 12:52:23 --> Output Class Initialized
DEBUG - 2011-04-08 12:52:23 --> Input Class Initialized
DEBUG - 2011-04-08 12:52:23 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-08 12:52:23 --> Language Class Initialized
DEBUG - 2011-04-08 12:52:23 --> Loader Class Initialized
DEBUG - 2011-04-08 12:52:23 --> Controller Class Initialized
DEBUG - 2011-04-08 12:52:23 --> Model Class Initialized
DEBUG - 2011-04-08 12:52:23 --> Model Class Initialized
DEBUG - 2011-04-08 12:52:23 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-08 12:52:23 --> Database Driver Class Initialized
DEBUG - 2011-04-08 12:52:24 --> Final output sent to browser
DEBUG - 2011-04-08 12:52:24 --> Total execution time: 0.7620
DEBUG - 2011-04-08 12:52:25 --> Config Class Initialized
DEBUG - 2011-04-08 12:52:25 --> Hooks Class Initialized
DEBUG - 2011-04-08 12:52:25 --> Utf8 Class Initialized
DEBUG - 2011-04-08 12:52:25 --> UTF-8 Support Enabled
DEBUG - 2011-04-08 12:52:25 --> URI Class Initialized
DEBUG - 2011-04-08 12:52:25 --> Router Class Initialized
ERROR - 2011-04-08 12:52:25 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-04-08 12:52:26 --> Config Class Initialized
DEBUG - 2011-04-08 12:52:26 --> Hooks Class Initialized
DEBUG - 2011-04-08 12:52:26 --> Utf8 Class Initialized
DEBUG - 2011-04-08 12:52:26 --> UTF-8 Support Enabled
DEBUG - 2011-04-08 12:52:26 --> URI Class Initialized
DEBUG - 2011-04-08 12:52:26 --> Router Class Initialized
ERROR - 2011-04-08 12:52:26 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-04-08 12:52:26 --> Config Class Initialized
DEBUG - 2011-04-08 12:52:26 --> Hooks Class Initialized
DEBUG - 2011-04-08 12:52:26 --> Utf8 Class Initialized
DEBUG - 2011-04-08 12:52:26 --> UTF-8 Support Enabled
DEBUG - 2011-04-08 12:52:26 --> URI Class Initialized
DEBUG - 2011-04-08 12:52:26 --> Router Class Initialized
ERROR - 2011-04-08 12:52:26 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-04-08 13:48:42 --> Config Class Initialized
DEBUG - 2011-04-08 13:48:42 --> Hooks Class Initialized
DEBUG - 2011-04-08 13:48:42 --> Utf8 Class Initialized
DEBUG - 2011-04-08 13:48:42 --> UTF-8 Support Enabled
DEBUG - 2011-04-08 13:48:42 --> URI Class Initialized
DEBUG - 2011-04-08 13:48:42 --> Router Class Initialized
DEBUG - 2011-04-08 13:48:42 --> No URI present. Default controller set.
DEBUG - 2011-04-08 13:48:42 --> Output Class Initialized
DEBUG - 2011-04-08 13:48:42 --> Input Class Initialized
DEBUG - 2011-04-08 13:48:42 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-08 13:48:42 --> Language Class Initialized
DEBUG - 2011-04-08 13:48:42 --> Loader Class Initialized
DEBUG - 2011-04-08 13:48:42 --> Controller Class Initialized
DEBUG - 2011-04-08 13:48:42 --> File loaded: application/views/splash/main.php
DEBUG - 2011-04-08 13:48:42 --> Helper loaded: url_helper
DEBUG - 2011-04-08 13:48:42 --> File loaded: application/views/common/header.php
DEBUG - 2011-04-08 13:48:42 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-04-08 13:48:42 --> File loaded: application/views/common/footer.php
DEBUG - 2011-04-08 13:48:42 --> File loaded: application/views/layout/main.php
DEBUG - 2011-04-08 13:48:42 --> Final output sent to browser
DEBUG - 2011-04-08 13:48:42 --> Total execution time: 0.2978
DEBUG - 2011-04-08 13:48:44 --> Config Class Initialized
DEBUG - 2011-04-08 13:48:44 --> Hooks Class Initialized
DEBUG - 2011-04-08 13:48:44 --> Utf8 Class Initialized
DEBUG - 2011-04-08 13:48:44 --> UTF-8 Support Enabled
DEBUG - 2011-04-08 13:48:44 --> URI Class Initialized
DEBUG - 2011-04-08 13:48:44 --> Router Class Initialized
ERROR - 2011-04-08 13:48:44 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-04-08 13:48:46 --> Config Class Initialized
DEBUG - 2011-04-08 13:48:46 --> Hooks Class Initialized
DEBUG - 2011-04-08 13:48:46 --> Utf8 Class Initialized
DEBUG - 2011-04-08 13:48:46 --> UTF-8 Support Enabled
DEBUG - 2011-04-08 13:48:46 --> URI Class Initialized
DEBUG - 2011-04-08 13:48:46 --> Router Class Initialized
ERROR - 2011-04-08 13:48:46 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-04-08 13:49:05 --> Config Class Initialized
DEBUG - 2011-04-08 13:49:05 --> Hooks Class Initialized
DEBUG - 2011-04-08 13:49:05 --> Utf8 Class Initialized
DEBUG - 2011-04-08 13:49:05 --> UTF-8 Support Enabled
DEBUG - 2011-04-08 13:49:05 --> URI Class Initialized
DEBUG - 2011-04-08 13:49:05 --> Router Class Initialized
DEBUG - 2011-04-08 13:49:05 --> No URI present. Default controller set.
DEBUG - 2011-04-08 13:49:05 --> Output Class Initialized
DEBUG - 2011-04-08 13:49:05 --> Input Class Initialized
DEBUG - 2011-04-08 13:49:05 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-08 13:49:05 --> Language Class Initialized
DEBUG - 2011-04-08 13:49:05 --> Loader Class Initialized
DEBUG - 2011-04-08 13:49:05 --> Controller Class Initialized
DEBUG - 2011-04-08 13:49:05 --> File loaded: application/views/splash/main.php
DEBUG - 2011-04-08 13:49:05 --> Helper loaded: url_helper
DEBUG - 2011-04-08 13:49:05 --> File loaded: application/views/common/header.php
DEBUG - 2011-04-08 13:49:05 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-04-08 13:49:05 --> File loaded: application/views/common/footer.php
DEBUG - 2011-04-08 13:49:05 --> File loaded: application/views/layout/main.php
DEBUG - 2011-04-08 13:49:05 --> Final output sent to browser
DEBUG - 2011-04-08 13:49:05 --> Total execution time: 0.0345
DEBUG - 2011-04-08 13:49:06 --> Config Class Initialized
DEBUG - 2011-04-08 13:49:06 --> Hooks Class Initialized
DEBUG - 2011-04-08 13:49:06 --> Utf8 Class Initialized
DEBUG - 2011-04-08 13:49:06 --> UTF-8 Support Enabled
DEBUG - 2011-04-08 13:49:06 --> URI Class Initialized
DEBUG - 2011-04-08 13:49:06 --> Router Class Initialized
DEBUG - 2011-04-08 13:49:06 --> No URI present. Default controller set.
DEBUG - 2011-04-08 13:49:06 --> Output Class Initialized
DEBUG - 2011-04-08 13:49:06 --> Input Class Initialized
DEBUG - 2011-04-08 13:49:06 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-08 13:49:06 --> Language Class Initialized
DEBUG - 2011-04-08 13:49:06 --> Loader Class Initialized
DEBUG - 2011-04-08 13:49:06 --> Controller Class Initialized
DEBUG - 2011-04-08 13:49:06 --> File loaded: application/views/splash/main.php
DEBUG - 2011-04-08 13:49:07 --> Helper loaded: url_helper
DEBUG - 2011-04-08 13:49:07 --> File loaded: application/views/common/header.php
DEBUG - 2011-04-08 13:49:07 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-04-08 13:49:07 --> File loaded: application/views/common/footer.php
DEBUG - 2011-04-08 13:49:07 --> File loaded: application/views/layout/main.php
DEBUG - 2011-04-08 13:49:07 --> Final output sent to browser
DEBUG - 2011-04-08 13:49:07 --> Total execution time: 0.1752
DEBUG - 2011-04-08 13:49:48 --> Config Class Initialized
DEBUG - 2011-04-08 13:49:48 --> Hooks Class Initialized
DEBUG - 2011-04-08 13:49:48 --> Utf8 Class Initialized
DEBUG - 2011-04-08 13:49:48 --> UTF-8 Support Enabled
DEBUG - 2011-04-08 13:49:48 --> URI Class Initialized
DEBUG - 2011-04-08 13:49:48 --> Router Class Initialized
DEBUG - 2011-04-08 13:49:48 --> No URI present. Default controller set.
DEBUG - 2011-04-08 13:49:48 --> Output Class Initialized
DEBUG - 2011-04-08 13:49:48 --> Input Class Initialized
DEBUG - 2011-04-08 13:49:48 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-08 13:49:48 --> Language Class Initialized
DEBUG - 2011-04-08 13:49:48 --> Loader Class Initialized
DEBUG - 2011-04-08 13:49:48 --> Controller Class Initialized
DEBUG - 2011-04-08 13:49:48 --> File loaded: application/views/splash/main.php
DEBUG - 2011-04-08 13:49:48 --> Helper loaded: url_helper
DEBUG - 2011-04-08 13:49:48 --> File loaded: application/views/common/header.php
DEBUG - 2011-04-08 13:49:48 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-04-08 13:49:48 --> File loaded: application/views/common/footer.php
DEBUG - 2011-04-08 13:49:48 --> File loaded: application/views/layout/main.php
DEBUG - 2011-04-08 13:49:48 --> Final output sent to browser
DEBUG - 2011-04-08 13:49:48 --> Total execution time: 0.0488
DEBUG - 2011-04-08 13:49:51 --> Config Class Initialized
DEBUG - 2011-04-08 13:49:51 --> Hooks Class Initialized
DEBUG - 2011-04-08 13:49:51 --> Utf8 Class Initialized
DEBUG - 2011-04-08 13:49:51 --> UTF-8 Support Enabled
DEBUG - 2011-04-08 13:49:51 --> URI Class Initialized
DEBUG - 2011-04-08 13:49:51 --> Router Class Initialized
DEBUG - 2011-04-08 13:49:51 --> Output Class Initialized
DEBUG - 2011-04-08 13:49:51 --> Input Class Initialized
DEBUG - 2011-04-08 13:49:51 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-08 13:49:51 --> Language Class Initialized
DEBUG - 2011-04-08 13:49:51 --> Loader Class Initialized
DEBUG - 2011-04-08 13:49:51 --> Controller Class Initialized
ERROR - 2011-04-08 13:49:51 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-04-08 13:49:51 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-04-08 13:49:51 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-04-08 13:49:51 --> Model Class Initialized
DEBUG - 2011-04-08 13:49:51 --> Model Class Initialized
DEBUG - 2011-04-08 13:49:51 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-08 13:49:52 --> Database Driver Class Initialized
DEBUG - 2011-04-08 13:49:52 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-04-08 13:49:52 --> Helper loaded: url_helper
DEBUG - 2011-04-08 13:49:52 --> File loaded: application/views/common/header.php
DEBUG - 2011-04-08 13:49:52 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-04-08 13:49:52 --> File loaded: application/views/common/footer.php
DEBUG - 2011-04-08 13:49:52 --> File loaded: application/views/layout/main.php
DEBUG - 2011-04-08 13:49:52 --> Final output sent to browser
DEBUG - 2011-04-08 13:49:52 --> Total execution time: 0.3890
DEBUG - 2011-04-08 13:49:52 --> Config Class Initialized
DEBUG - 2011-04-08 13:49:52 --> Hooks Class Initialized
DEBUG - 2011-04-08 13:49:52 --> Utf8 Class Initialized
DEBUG - 2011-04-08 13:49:52 --> UTF-8 Support Enabled
DEBUG - 2011-04-08 13:49:52 --> URI Class Initialized
DEBUG - 2011-04-08 13:49:52 --> Router Class Initialized
DEBUG - 2011-04-08 13:49:52 --> Output Class Initialized
DEBUG - 2011-04-08 13:49:52 --> Input Class Initialized
DEBUG - 2011-04-08 13:49:52 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-08 13:49:52 --> Language Class Initialized
DEBUG - 2011-04-08 13:49:52 --> Loader Class Initialized
DEBUG - 2011-04-08 13:49:52 --> Controller Class Initialized
DEBUG - 2011-04-08 13:49:52 --> Model Class Initialized
DEBUG - 2011-04-08 13:49:53 --> Model Class Initialized
DEBUG - 2011-04-08 13:49:53 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-08 13:49:53 --> Database Driver Class Initialized
DEBUG - 2011-04-08 13:49:53 --> Final output sent to browser
DEBUG - 2011-04-08 13:49:53 --> Total execution time: 0.6371
DEBUG - 2011-04-08 13:49:55 --> Config Class Initialized
DEBUG - 2011-04-08 13:49:55 --> Hooks Class Initialized
DEBUG - 2011-04-08 13:49:55 --> Utf8 Class Initialized
DEBUG - 2011-04-08 13:49:55 --> UTF-8 Support Enabled
DEBUG - 2011-04-08 13:49:55 --> URI Class Initialized
DEBUG - 2011-04-08 13:49:55 --> Router Class Initialized
DEBUG - 2011-04-08 13:49:55 --> Output Class Initialized
DEBUG - 2011-04-08 13:49:55 --> Input Class Initialized
DEBUG - 2011-04-08 13:49:55 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-08 13:49:55 --> Language Class Initialized
DEBUG - 2011-04-08 13:49:55 --> Loader Class Initialized
DEBUG - 2011-04-08 13:49:55 --> Controller Class Initialized
ERROR - 2011-04-08 13:49:55 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-04-08 13:49:55 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-04-08 13:49:55 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-04-08 13:49:55 --> Model Class Initialized
DEBUG - 2011-04-08 13:49:55 --> Model Class Initialized
DEBUG - 2011-04-08 13:49:55 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-08 13:49:55 --> Database Driver Class Initialized
DEBUG - 2011-04-08 13:49:55 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-04-08 13:49:55 --> Helper loaded: url_helper
DEBUG - 2011-04-08 13:49:55 --> File loaded: application/views/common/header.php
DEBUG - 2011-04-08 13:49:55 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-04-08 13:49:55 --> File loaded: application/views/common/footer.php
DEBUG - 2011-04-08 13:49:55 --> File loaded: application/views/layout/main.php
DEBUG - 2011-04-08 13:49:55 --> Final output sent to browser
DEBUG - 2011-04-08 13:49:55 --> Total execution time: 0.0277
DEBUG - 2011-04-08 13:49:56 --> Config Class Initialized
DEBUG - 2011-04-08 13:49:56 --> Hooks Class Initialized
DEBUG - 2011-04-08 13:49:56 --> Utf8 Class Initialized
DEBUG - 2011-04-08 13:49:56 --> UTF-8 Support Enabled
DEBUG - 2011-04-08 13:49:56 --> URI Class Initialized
DEBUG - 2011-04-08 13:49:56 --> Router Class Initialized
DEBUG - 2011-04-08 13:49:56 --> Output Class Initialized
DEBUG - 2011-04-08 13:49:56 --> Input Class Initialized
DEBUG - 2011-04-08 13:49:56 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-08 13:49:56 --> Language Class Initialized
DEBUG - 2011-04-08 13:49:56 --> Loader Class Initialized
DEBUG - 2011-04-08 13:49:56 --> Controller Class Initialized
DEBUG - 2011-04-08 13:49:56 --> Model Class Initialized
DEBUG - 2011-04-08 13:49:56 --> Model Class Initialized
DEBUG - 2011-04-08 13:49:56 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-08 13:49:56 --> Database Driver Class Initialized
DEBUG - 2011-04-08 13:49:56 --> Final output sent to browser
DEBUG - 2011-04-08 13:49:56 --> Total execution time: 0.6230
DEBUG - 2011-04-08 13:51:05 --> Config Class Initialized
DEBUG - 2011-04-08 13:51:05 --> Hooks Class Initialized
DEBUG - 2011-04-08 13:51:05 --> Utf8 Class Initialized
DEBUG - 2011-04-08 13:51:05 --> UTF-8 Support Enabled
DEBUG - 2011-04-08 13:51:05 --> URI Class Initialized
DEBUG - 2011-04-08 13:51:05 --> Router Class Initialized
DEBUG - 2011-04-08 13:51:05 --> Output Class Initialized
DEBUG - 2011-04-08 13:51:05 --> Input Class Initialized
DEBUG - 2011-04-08 13:51:05 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-08 13:51:05 --> Language Class Initialized
DEBUG - 2011-04-08 13:51:05 --> Loader Class Initialized
DEBUG - 2011-04-08 13:51:05 --> Controller Class Initialized
DEBUG - 2011-04-08 13:51:05 --> Model Class Initialized
DEBUG - 2011-04-08 13:51:05 --> Model Class Initialized
DEBUG - 2011-04-08 13:51:05 --> Model Class Initialized
DEBUG - 2011-04-08 13:51:05 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-08 13:51:05 --> Database Driver Class Initialized
DEBUG - 2011-04-08 13:51:05 --> File loaded: application/views/table/main.php
DEBUG - 2011-04-08 13:51:05 --> Helper loaded: url_helper
DEBUG - 2011-04-08 13:51:05 --> File loaded: application/views/common/header.php
DEBUG - 2011-04-08 13:51:05 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-04-08 13:51:05 --> File loaded: application/views/common/footer.php
DEBUG - 2011-04-08 13:51:05 --> File loaded: application/views/layout/main.php
DEBUG - 2011-04-08 13:51:05 --> Final output sent to browser
DEBUG - 2011-04-08 13:51:05 --> Total execution time: 0.2272
DEBUG - 2011-04-08 13:51:25 --> Config Class Initialized
DEBUG - 2011-04-08 13:51:25 --> Hooks Class Initialized
DEBUG - 2011-04-08 13:51:25 --> Utf8 Class Initialized
DEBUG - 2011-04-08 13:51:25 --> UTF-8 Support Enabled
DEBUG - 2011-04-08 13:51:25 --> URI Class Initialized
DEBUG - 2011-04-08 13:51:25 --> Router Class Initialized
DEBUG - 2011-04-08 13:51:25 --> Output Class Initialized
DEBUG - 2011-04-08 13:51:25 --> Input Class Initialized
DEBUG - 2011-04-08 13:51:25 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-08 13:51:25 --> Language Class Initialized
DEBUG - 2011-04-08 13:51:25 --> Loader Class Initialized
DEBUG - 2011-04-08 13:51:25 --> Controller Class Initialized
DEBUG - 2011-04-08 13:51:25 --> Model Class Initialized
DEBUG - 2011-04-08 13:51:25 --> Model Class Initialized
DEBUG - 2011-04-08 13:51:25 --> Model Class Initialized
DEBUG - 2011-04-08 13:51:25 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-08 13:51:25 --> Database Driver Class Initialized
DEBUG - 2011-04-08 13:51:26 --> File loaded: application/views/table/main.php
DEBUG - 2011-04-08 13:51:26 --> Helper loaded: url_helper
DEBUG - 2011-04-08 13:51:26 --> File loaded: application/views/common/header.php
DEBUG - 2011-04-08 13:51:26 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-04-08 13:51:26 --> File loaded: application/views/common/footer.php
DEBUG - 2011-04-08 13:51:26 --> File loaded: application/views/layout/main.php
DEBUG - 2011-04-08 13:51:26 --> Final output sent to browser
DEBUG - 2011-04-08 13:51:26 --> Total execution time: 0.7770
DEBUG - 2011-04-08 13:51:28 --> Config Class Initialized
DEBUG - 2011-04-08 13:51:28 --> Hooks Class Initialized
DEBUG - 2011-04-08 13:51:28 --> Utf8 Class Initialized
DEBUG - 2011-04-08 13:51:28 --> UTF-8 Support Enabled
DEBUG - 2011-04-08 13:51:28 --> URI Class Initialized
DEBUG - 2011-04-08 13:51:28 --> Router Class Initialized
ERROR - 2011-04-08 13:51:28 --> 404 Page Not Found --> robots.txt
DEBUG - 2011-04-08 13:51:28 --> Config Class Initialized
DEBUG - 2011-04-08 13:51:28 --> Hooks Class Initialized
DEBUG - 2011-04-08 13:51:28 --> Utf8 Class Initialized
DEBUG - 2011-04-08 13:51:28 --> UTF-8 Support Enabled
DEBUG - 2011-04-08 13:51:28 --> URI Class Initialized
DEBUG - 2011-04-08 13:51:28 --> Router Class Initialized
DEBUG - 2011-04-08 13:51:28 --> Output Class Initialized
DEBUG - 2011-04-08 13:51:28 --> Input Class Initialized
DEBUG - 2011-04-08 13:51:28 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-08 13:51:28 --> Language Class Initialized
DEBUG - 2011-04-08 13:51:28 --> Loader Class Initialized
DEBUG - 2011-04-08 13:51:28 --> Controller Class Initialized
DEBUG - 2011-04-08 13:51:28 --> Model Class Initialized
DEBUG - 2011-04-08 13:51:28 --> Model Class Initialized
DEBUG - 2011-04-08 13:51:28 --> Model Class Initialized
DEBUG - 2011-04-08 13:51:28 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-08 13:51:28 --> Database Driver Class Initialized
DEBUG - 2011-04-08 13:51:28 --> File loaded: application/views/table/main.php
DEBUG - 2011-04-08 13:51:28 --> Helper loaded: url_helper
DEBUG - 2011-04-08 13:51:28 --> File loaded: application/views/common/header.php
DEBUG - 2011-04-08 13:51:28 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-04-08 13:51:28 --> File loaded: application/views/common/footer.php
DEBUG - 2011-04-08 13:51:28 --> File loaded: application/views/layout/main.php
DEBUG - 2011-04-08 13:51:28 --> Final output sent to browser
DEBUG - 2011-04-08 13:51:28 --> Total execution time: 0.0824
DEBUG - 2011-04-08 13:51:41 --> Config Class Initialized
DEBUG - 2011-04-08 13:51:41 --> Hooks Class Initialized
DEBUG - 2011-04-08 13:51:41 --> Utf8 Class Initialized
DEBUG - 2011-04-08 13:51:41 --> UTF-8 Support Enabled
DEBUG - 2011-04-08 13:51:41 --> URI Class Initialized
DEBUG - 2011-04-08 13:51:41 --> Router Class Initialized
DEBUG - 2011-04-08 13:51:41 --> Output Class Initialized
DEBUG - 2011-04-08 13:51:41 --> Input Class Initialized
DEBUG - 2011-04-08 13:51:41 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-08 13:51:41 --> Language Class Initialized
DEBUG - 2011-04-08 13:51:41 --> Loader Class Initialized
DEBUG - 2011-04-08 13:51:41 --> Controller Class Initialized
DEBUG - 2011-04-08 13:51:41 --> Model Class Initialized
DEBUG - 2011-04-08 13:51:41 --> Model Class Initialized
DEBUG - 2011-04-08 13:51:41 --> Model Class Initialized
DEBUG - 2011-04-08 13:51:41 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-08 13:51:41 --> Database Driver Class Initialized
DEBUG - 2011-04-08 13:51:42 --> File loaded: application/views/table/main.php
DEBUG - 2011-04-08 13:51:42 --> Helper loaded: url_helper
DEBUG - 2011-04-08 13:51:42 --> File loaded: application/views/common/header.php
DEBUG - 2011-04-08 13:51:42 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-04-08 13:51:42 --> File loaded: application/views/common/footer.php
DEBUG - 2011-04-08 13:51:42 --> File loaded: application/views/layout/main.php
DEBUG - 2011-04-08 13:51:42 --> Final output sent to browser
DEBUG - 2011-04-08 13:51:42 --> Total execution time: 0.2868
DEBUG - 2011-04-08 13:51:43 --> Config Class Initialized
DEBUG - 2011-04-08 13:51:43 --> Hooks Class Initialized
DEBUG - 2011-04-08 13:51:43 --> Utf8 Class Initialized
DEBUG - 2011-04-08 13:51:43 --> UTF-8 Support Enabled
DEBUG - 2011-04-08 13:51:43 --> URI Class Initialized
DEBUG - 2011-04-08 13:51:43 --> Router Class Initialized
DEBUG - 2011-04-08 13:51:43 --> Output Class Initialized
DEBUG - 2011-04-08 13:51:43 --> Input Class Initialized
DEBUG - 2011-04-08 13:51:43 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-08 13:51:43 --> Language Class Initialized
DEBUG - 2011-04-08 13:51:43 --> Loader Class Initialized
DEBUG - 2011-04-08 13:51:43 --> Controller Class Initialized
DEBUG - 2011-04-08 13:51:43 --> Model Class Initialized
DEBUG - 2011-04-08 13:51:43 --> Model Class Initialized
DEBUG - 2011-04-08 13:51:43 --> Model Class Initialized
DEBUG - 2011-04-08 13:51:43 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-08 13:51:43 --> Database Driver Class Initialized
DEBUG - 2011-04-08 13:51:43 --> File loaded: application/views/table/main.php
DEBUG - 2011-04-08 13:51:43 --> Helper loaded: url_helper
DEBUG - 2011-04-08 13:51:43 --> File loaded: application/views/common/header.php
DEBUG - 2011-04-08 13:51:43 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-04-08 13:51:43 --> File loaded: application/views/common/footer.php
DEBUG - 2011-04-08 13:51:43 --> File loaded: application/views/layout/main.php
DEBUG - 2011-04-08 13:51:43 --> Final output sent to browser
DEBUG - 2011-04-08 13:51:43 --> Total execution time: 0.0436
DEBUG - 2011-04-08 14:19:38 --> Config Class Initialized
DEBUG - 2011-04-08 14:19:38 --> Hooks Class Initialized
DEBUG - 2011-04-08 14:19:38 --> Utf8 Class Initialized
DEBUG - 2011-04-08 14:19:38 --> UTF-8 Support Enabled
DEBUG - 2011-04-08 14:19:38 --> URI Class Initialized
DEBUG - 2011-04-08 14:19:38 --> Router Class Initialized
DEBUG - 2011-04-08 14:19:38 --> Output Class Initialized
DEBUG - 2011-04-08 14:19:38 --> Input Class Initialized
DEBUG - 2011-04-08 14:19:38 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-08 14:19:38 --> Language Class Initialized
DEBUG - 2011-04-08 14:19:38 --> Loader Class Initialized
DEBUG - 2011-04-08 14:19:38 --> Controller Class Initialized
ERROR - 2011-04-08 14:19:38 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-04-08 14:19:38 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-04-08 14:19:38 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-04-08 14:19:38 --> Model Class Initialized
DEBUG - 2011-04-08 14:19:38 --> Model Class Initialized
DEBUG - 2011-04-08 14:19:38 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-08 14:19:38 --> Database Driver Class Initialized
DEBUG - 2011-04-08 14:19:38 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-04-08 14:19:38 --> Helper loaded: url_helper
DEBUG - 2011-04-08 14:19:38 --> File loaded: application/views/common/header.php
DEBUG - 2011-04-08 14:19:38 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-04-08 14:19:38 --> File loaded: application/views/common/footer.php
DEBUG - 2011-04-08 14:19:38 --> File loaded: application/views/layout/main.php
DEBUG - 2011-04-08 14:19:38 --> Final output sent to browser
DEBUG - 2011-04-08 14:19:38 --> Total execution time: 0.1050
DEBUG - 2011-04-08 14:19:39 --> Config Class Initialized
DEBUG - 2011-04-08 14:19:39 --> Hooks Class Initialized
DEBUG - 2011-04-08 14:19:39 --> Utf8 Class Initialized
DEBUG - 2011-04-08 14:19:39 --> UTF-8 Support Enabled
DEBUG - 2011-04-08 14:19:39 --> URI Class Initialized
DEBUG - 2011-04-08 14:19:39 --> Router Class Initialized
DEBUG - 2011-04-08 14:19:39 --> Output Class Initialized
DEBUG - 2011-04-08 14:19:39 --> Input Class Initialized
DEBUG - 2011-04-08 14:19:39 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-08 14:19:39 --> Language Class Initialized
DEBUG - 2011-04-08 14:19:39 --> Loader Class Initialized
DEBUG - 2011-04-08 14:19:39 --> Controller Class Initialized
DEBUG - 2011-04-08 14:19:39 --> Model Class Initialized
DEBUG - 2011-04-08 14:19:39 --> Model Class Initialized
DEBUG - 2011-04-08 14:19:39 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-08 14:19:39 --> Database Driver Class Initialized
DEBUG - 2011-04-08 14:19:40 --> Final output sent to browser
DEBUG - 2011-04-08 14:19:40 --> Total execution time: 0.6060
DEBUG - 2011-04-08 14:19:41 --> Config Class Initialized
DEBUG - 2011-04-08 14:19:41 --> Hooks Class Initialized
DEBUG - 2011-04-08 14:19:41 --> Utf8 Class Initialized
DEBUG - 2011-04-08 14:19:41 --> UTF-8 Support Enabled
DEBUG - 2011-04-08 14:19:41 --> URI Class Initialized
DEBUG - 2011-04-08 14:19:41 --> Router Class Initialized
ERROR - 2011-04-08 14:19:41 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-04-08 14:19:43 --> Config Class Initialized
DEBUG - 2011-04-08 14:19:43 --> Hooks Class Initialized
DEBUG - 2011-04-08 14:19:43 --> Utf8 Class Initialized
DEBUG - 2011-04-08 14:19:43 --> UTF-8 Support Enabled
DEBUG - 2011-04-08 14:19:43 --> URI Class Initialized
DEBUG - 2011-04-08 14:19:43 --> Router Class Initialized
ERROR - 2011-04-08 14:19:43 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-04-08 14:23:47 --> Config Class Initialized
DEBUG - 2011-04-08 14:23:47 --> Hooks Class Initialized
DEBUG - 2011-04-08 14:23:47 --> Utf8 Class Initialized
DEBUG - 2011-04-08 14:23:47 --> UTF-8 Support Enabled
DEBUG - 2011-04-08 14:23:47 --> URI Class Initialized
DEBUG - 2011-04-08 14:23:47 --> Router Class Initialized
DEBUG - 2011-04-08 14:23:47 --> Output Class Initialized
DEBUG - 2011-04-08 14:23:47 --> Input Class Initialized
DEBUG - 2011-04-08 14:23:47 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-08 14:23:47 --> Language Class Initialized
DEBUG - 2011-04-08 14:23:47 --> Loader Class Initialized
DEBUG - 2011-04-08 14:23:47 --> Controller Class Initialized
ERROR - 2011-04-08 14:23:47 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-04-08 14:23:47 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-04-08 14:23:47 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-04-08 14:23:47 --> Model Class Initialized
DEBUG - 2011-04-08 14:23:47 --> Model Class Initialized
DEBUG - 2011-04-08 14:23:47 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-08 14:23:47 --> Database Driver Class Initialized
DEBUG - 2011-04-08 14:23:47 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-04-08 14:23:47 --> Helper loaded: url_helper
DEBUG - 2011-04-08 14:23:47 --> File loaded: application/views/common/header.php
DEBUG - 2011-04-08 14:23:47 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-04-08 14:23:47 --> File loaded: application/views/common/footer.php
DEBUG - 2011-04-08 14:23:47 --> File loaded: application/views/layout/main.php
DEBUG - 2011-04-08 14:23:47 --> Final output sent to browser
DEBUG - 2011-04-08 14:23:47 --> Total execution time: 0.0710
DEBUG - 2011-04-08 14:23:48 --> Config Class Initialized
DEBUG - 2011-04-08 14:23:48 --> Hooks Class Initialized
DEBUG - 2011-04-08 14:23:48 --> Utf8 Class Initialized
DEBUG - 2011-04-08 14:23:48 --> UTF-8 Support Enabled
DEBUG - 2011-04-08 14:23:48 --> URI Class Initialized
DEBUG - 2011-04-08 14:23:48 --> Router Class Initialized
DEBUG - 2011-04-08 14:23:48 --> Output Class Initialized
DEBUG - 2011-04-08 14:23:48 --> Input Class Initialized
DEBUG - 2011-04-08 14:23:48 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-08 14:23:48 --> Language Class Initialized
DEBUG - 2011-04-08 14:23:48 --> Loader Class Initialized
DEBUG - 2011-04-08 14:23:48 --> Controller Class Initialized
DEBUG - 2011-04-08 14:23:48 --> Model Class Initialized
DEBUG - 2011-04-08 14:23:48 --> Model Class Initialized
DEBUG - 2011-04-08 14:23:48 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-08 14:23:48 --> Database Driver Class Initialized
DEBUG - 2011-04-08 14:23:48 --> Final output sent to browser
DEBUG - 2011-04-08 14:23:48 --> Total execution time: 0.7067
DEBUG - 2011-04-08 14:25:48 --> Config Class Initialized
DEBUG - 2011-04-08 14:25:48 --> Hooks Class Initialized
DEBUG - 2011-04-08 14:25:48 --> Utf8 Class Initialized
DEBUG - 2011-04-08 14:25:48 --> UTF-8 Support Enabled
DEBUG - 2011-04-08 14:25:48 --> URI Class Initialized
DEBUG - 2011-04-08 14:25:48 --> Router Class Initialized
DEBUG - 2011-04-08 14:25:48 --> Output Class Initialized
DEBUG - 2011-04-08 14:25:48 --> Input Class Initialized
DEBUG - 2011-04-08 14:25:48 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-08 14:25:48 --> Language Class Initialized
DEBUG - 2011-04-08 14:25:48 --> Loader Class Initialized
DEBUG - 2011-04-08 14:25:48 --> Controller Class Initialized
DEBUG - 2011-04-08 14:25:48 --> Model Class Initialized
DEBUG - 2011-04-08 14:25:48 --> Model Class Initialized
DEBUG - 2011-04-08 14:25:48 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-08 14:25:48 --> Database Driver Class Initialized
DEBUG - 2011-04-08 14:25:48 --> Final output sent to browser
DEBUG - 2011-04-08 14:25:48 --> Total execution time: 0.6301
DEBUG - 2011-04-08 14:30:52 --> Config Class Initialized
DEBUG - 2011-04-08 14:30:52 --> Hooks Class Initialized
DEBUG - 2011-04-08 14:30:52 --> Utf8 Class Initialized
DEBUG - 2011-04-08 14:30:52 --> UTF-8 Support Enabled
DEBUG - 2011-04-08 14:30:52 --> URI Class Initialized
DEBUG - 2011-04-08 14:30:52 --> Router Class Initialized
DEBUG - 2011-04-08 14:30:52 --> Output Class Initialized
DEBUG - 2011-04-08 14:30:52 --> Input Class Initialized
DEBUG - 2011-04-08 14:30:52 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-08 14:30:52 --> Language Class Initialized
DEBUG - 2011-04-08 14:30:52 --> Loader Class Initialized
DEBUG - 2011-04-08 14:30:52 --> Controller Class Initialized
DEBUG - 2011-04-08 14:30:52 --> Model Class Initialized
DEBUG - 2011-04-08 14:30:52 --> Model Class Initialized
DEBUG - 2011-04-08 14:30:52 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-08 14:30:52 --> Database Driver Class Initialized
DEBUG - 2011-04-08 14:30:52 --> Final output sent to browser
DEBUG - 2011-04-08 14:30:52 --> Total execution time: 0.5018
DEBUG - 2011-04-08 14:42:17 --> Config Class Initialized
DEBUG - 2011-04-08 14:42:17 --> Hooks Class Initialized
DEBUG - 2011-04-08 14:42:17 --> Utf8 Class Initialized
DEBUG - 2011-04-08 14:42:17 --> UTF-8 Support Enabled
DEBUG - 2011-04-08 14:42:17 --> URI Class Initialized
DEBUG - 2011-04-08 14:42:17 --> Router Class Initialized
DEBUG - 2011-04-08 14:42:17 --> No URI present. Default controller set.
DEBUG - 2011-04-08 14:42:17 --> Output Class Initialized
DEBUG - 2011-04-08 14:42:17 --> Input Class Initialized
DEBUG - 2011-04-08 14:42:17 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-08 14:42:17 --> Language Class Initialized
DEBUG - 2011-04-08 14:42:18 --> Loader Class Initialized
DEBUG - 2011-04-08 14:42:18 --> Controller Class Initialized
DEBUG - 2011-04-08 14:42:18 --> File loaded: application/views/splash/main.php
DEBUG - 2011-04-08 14:42:18 --> Helper loaded: url_helper
DEBUG - 2011-04-08 14:42:18 --> File loaded: application/views/common/header.php
DEBUG - 2011-04-08 14:42:18 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-04-08 14:42:18 --> File loaded: application/views/common/footer.php
DEBUG - 2011-04-08 14:42:18 --> File loaded: application/views/layout/main.php
DEBUG - 2011-04-08 14:42:18 --> Final output sent to browser
DEBUG - 2011-04-08 14:42:18 --> Total execution time: 1.0410
DEBUG - 2011-04-08 14:42:20 --> Config Class Initialized
DEBUG - 2011-04-08 14:42:20 --> Hooks Class Initialized
DEBUG - 2011-04-08 14:42:20 --> Utf8 Class Initialized
DEBUG - 2011-04-08 14:42:20 --> UTF-8 Support Enabled
DEBUG - 2011-04-08 14:42:20 --> URI Class Initialized
DEBUG - 2011-04-08 14:42:20 --> Router Class Initialized
ERROR - 2011-04-08 14:42:20 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-04-08 14:43:21 --> Config Class Initialized
DEBUG - 2011-04-08 14:43:21 --> Hooks Class Initialized
DEBUG - 2011-04-08 14:43:21 --> Utf8 Class Initialized
DEBUG - 2011-04-08 14:43:21 --> UTF-8 Support Enabled
DEBUG - 2011-04-08 14:43:21 --> URI Class Initialized
DEBUG - 2011-04-08 14:43:21 --> Router Class Initialized
DEBUG - 2011-04-08 14:43:21 --> Output Class Initialized
DEBUG - 2011-04-08 14:43:21 --> Input Class Initialized
DEBUG - 2011-04-08 14:43:21 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-08 14:43:21 --> Language Class Initialized
DEBUG - 2011-04-08 14:43:21 --> Loader Class Initialized
DEBUG - 2011-04-08 14:43:21 --> Controller Class Initialized
DEBUG - 2011-04-08 14:43:21 --> Model Class Initialized
DEBUG - 2011-04-08 14:43:21 --> Model Class Initialized
DEBUG - 2011-04-08 14:43:21 --> Model Class Initialized
DEBUG - 2011-04-08 14:43:21 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-08 14:43:21 --> Database Driver Class Initialized
DEBUG - 2011-04-08 14:43:21 --> File loaded: application/views/table/main.php
DEBUG - 2011-04-08 14:43:21 --> Helper loaded: url_helper
DEBUG - 2011-04-08 14:43:21 --> File loaded: application/views/common/header.php
DEBUG - 2011-04-08 14:43:21 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-04-08 14:43:21 --> File loaded: application/views/common/footer.php
DEBUG - 2011-04-08 14:43:21 --> File loaded: application/views/layout/main.php
DEBUG - 2011-04-08 14:43:21 --> Final output sent to browser
DEBUG - 2011-04-08 14:43:21 --> Total execution time: 0.3456
DEBUG - 2011-04-08 14:43:23 --> Config Class Initialized
DEBUG - 2011-04-08 14:43:23 --> Hooks Class Initialized
DEBUG - 2011-04-08 14:43:23 --> Utf8 Class Initialized
DEBUG - 2011-04-08 14:43:23 --> UTF-8 Support Enabled
DEBUG - 2011-04-08 14:43:23 --> URI Class Initialized
DEBUG - 2011-04-08 14:43:23 --> Router Class Initialized
ERROR - 2011-04-08 14:43:23 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-04-08 14:43:47 --> Config Class Initialized
DEBUG - 2011-04-08 14:43:47 --> Hooks Class Initialized
DEBUG - 2011-04-08 14:43:47 --> Utf8 Class Initialized
DEBUG - 2011-04-08 14:43:47 --> UTF-8 Support Enabled
DEBUG - 2011-04-08 14:43:47 --> URI Class Initialized
DEBUG - 2011-04-08 14:43:47 --> Router Class Initialized
DEBUG - 2011-04-08 14:43:47 --> Output Class Initialized
DEBUG - 2011-04-08 14:43:47 --> Input Class Initialized
DEBUG - 2011-04-08 14:43:47 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-08 14:43:47 --> Language Class Initialized
DEBUG - 2011-04-08 14:43:47 --> Loader Class Initialized
DEBUG - 2011-04-08 14:43:47 --> Controller Class Initialized
DEBUG - 2011-04-08 14:43:47 --> Model Class Initialized
DEBUG - 2011-04-08 14:43:47 --> Model Class Initialized
DEBUG - 2011-04-08 14:43:47 --> Model Class Initialized
DEBUG - 2011-04-08 14:43:47 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-08 14:43:47 --> Database Driver Class Initialized
DEBUG - 2011-04-08 14:43:48 --> File loaded: application/views/table/main.php
DEBUG - 2011-04-08 14:43:48 --> Helper loaded: url_helper
DEBUG - 2011-04-08 14:43:48 --> File loaded: application/views/common/header.php
DEBUG - 2011-04-08 14:43:48 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-04-08 14:43:48 --> File loaded: application/views/common/footer.php
DEBUG - 2011-04-08 14:43:48 --> File loaded: application/views/layout/main.php
DEBUG - 2011-04-08 14:43:48 --> Final output sent to browser
DEBUG - 2011-04-08 14:43:48 --> Total execution time: 0.3977
DEBUG - 2011-04-08 14:43:50 --> Config Class Initialized
DEBUG - 2011-04-08 14:43:50 --> Hooks Class Initialized
DEBUG - 2011-04-08 14:43:50 --> Utf8 Class Initialized
DEBUG - 2011-04-08 14:43:50 --> UTF-8 Support Enabled
DEBUG - 2011-04-08 14:43:50 --> URI Class Initialized
DEBUG - 2011-04-08 14:43:50 --> Router Class Initialized
ERROR - 2011-04-08 14:43:50 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-04-08 14:44:00 --> Config Class Initialized
DEBUG - 2011-04-08 14:44:00 --> Hooks Class Initialized
DEBUG - 2011-04-08 14:44:00 --> Utf8 Class Initialized
DEBUG - 2011-04-08 14:44:00 --> UTF-8 Support Enabled
DEBUG - 2011-04-08 14:44:00 --> URI Class Initialized
DEBUG - 2011-04-08 14:44:00 --> Router Class Initialized
DEBUG - 2011-04-08 14:44:00 --> Output Class Initialized
DEBUG - 2011-04-08 14:44:00 --> Input Class Initialized
DEBUG - 2011-04-08 14:44:00 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-08 14:44:00 --> Language Class Initialized
DEBUG - 2011-04-08 14:44:00 --> Loader Class Initialized
DEBUG - 2011-04-08 14:44:00 --> Controller Class Initialized
ERROR - 2011-04-08 14:44:00 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-04-08 14:44:00 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-04-08 14:44:00 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-04-08 14:44:00 --> Model Class Initialized
DEBUG - 2011-04-08 14:44:00 --> Model Class Initialized
DEBUG - 2011-04-08 14:44:00 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-08 14:44:00 --> Database Driver Class Initialized
DEBUG - 2011-04-08 14:44:00 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-04-08 14:44:00 --> Helper loaded: url_helper
DEBUG - 2011-04-08 14:44:00 --> File loaded: application/views/common/header.php
DEBUG - 2011-04-08 14:44:00 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-04-08 14:44:00 --> File loaded: application/views/common/footer.php
DEBUG - 2011-04-08 14:44:00 --> File loaded: application/views/layout/main.php
DEBUG - 2011-04-08 14:44:00 --> Final output sent to browser
DEBUG - 2011-04-08 14:44:00 --> Total execution time: 0.0273
DEBUG - 2011-04-08 14:44:01 --> Config Class Initialized
DEBUG - 2011-04-08 14:44:01 --> Hooks Class Initialized
DEBUG - 2011-04-08 14:44:01 --> Utf8 Class Initialized
DEBUG - 2011-04-08 14:44:01 --> UTF-8 Support Enabled
DEBUG - 2011-04-08 14:44:01 --> URI Class Initialized
DEBUG - 2011-04-08 14:44:01 --> Router Class Initialized
DEBUG - 2011-04-08 14:44:01 --> Output Class Initialized
DEBUG - 2011-04-08 14:44:01 --> Input Class Initialized
DEBUG - 2011-04-08 14:44:01 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-08 14:44:01 --> Language Class Initialized
DEBUG - 2011-04-08 14:44:01 --> Loader Class Initialized
DEBUG - 2011-04-08 14:44:01 --> Controller Class Initialized
DEBUG - 2011-04-08 14:44:01 --> Model Class Initialized
DEBUG - 2011-04-08 14:44:01 --> Model Class Initialized
DEBUG - 2011-04-08 14:44:01 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-08 14:44:01 --> Database Driver Class Initialized
DEBUG - 2011-04-08 14:44:02 --> Final output sent to browser
DEBUG - 2011-04-08 14:44:02 --> Total execution time: 0.6114
DEBUG - 2011-04-08 14:44:03 --> Config Class Initialized
DEBUG - 2011-04-08 14:44:03 --> Hooks Class Initialized
DEBUG - 2011-04-08 14:44:03 --> Utf8 Class Initialized
DEBUG - 2011-04-08 14:44:03 --> UTF-8 Support Enabled
DEBUG - 2011-04-08 14:44:03 --> URI Class Initialized
DEBUG - 2011-04-08 14:44:03 --> Router Class Initialized
ERROR - 2011-04-08 14:44:03 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-04-08 14:49:46 --> Config Class Initialized
DEBUG - 2011-04-08 14:49:46 --> Hooks Class Initialized
DEBUG - 2011-04-08 14:49:46 --> Utf8 Class Initialized
DEBUG - 2011-04-08 14:49:46 --> UTF-8 Support Enabled
DEBUG - 2011-04-08 14:49:46 --> URI Class Initialized
DEBUG - 2011-04-08 14:49:46 --> Router Class Initialized
DEBUG - 2011-04-08 14:49:46 --> Output Class Initialized
DEBUG - 2011-04-08 14:49:46 --> Input Class Initialized
DEBUG - 2011-04-08 14:49:46 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-08 14:49:46 --> Language Class Initialized
DEBUG - 2011-04-08 14:49:46 --> Loader Class Initialized
DEBUG - 2011-04-08 14:49:46 --> Controller Class Initialized
ERROR - 2011-04-08 14:49:46 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-04-08 14:49:46 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-04-08 14:49:46 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-04-08 14:49:46 --> Model Class Initialized
DEBUG - 2011-04-08 14:49:46 --> Model Class Initialized
DEBUG - 2011-04-08 14:49:46 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-08 14:49:46 --> Database Driver Class Initialized
DEBUG - 2011-04-08 14:49:46 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-04-08 14:49:46 --> Helper loaded: url_helper
DEBUG - 2011-04-08 14:49:46 --> File loaded: application/views/common/header.php
DEBUG - 2011-04-08 14:49:46 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-04-08 14:49:46 --> File loaded: application/views/common/footer.php
DEBUG - 2011-04-08 14:49:46 --> File loaded: application/views/layout/main.php
DEBUG - 2011-04-08 14:49:46 --> Final output sent to browser
DEBUG - 2011-04-08 14:49:46 --> Total execution time: 0.0329
DEBUG - 2011-04-08 14:49:48 --> Config Class Initialized
DEBUG - 2011-04-08 14:49:48 --> Hooks Class Initialized
DEBUG - 2011-04-08 14:49:48 --> Utf8 Class Initialized
DEBUG - 2011-04-08 14:49:48 --> UTF-8 Support Enabled
DEBUG - 2011-04-08 14:49:48 --> URI Class Initialized
DEBUG - 2011-04-08 14:49:48 --> Router Class Initialized
DEBUG - 2011-04-08 14:49:48 --> Output Class Initialized
DEBUG - 2011-04-08 14:49:48 --> Input Class Initialized
DEBUG - 2011-04-08 14:49:48 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-08 14:49:48 --> Language Class Initialized
DEBUG - 2011-04-08 14:49:48 --> Loader Class Initialized
DEBUG - 2011-04-08 14:49:48 --> Controller Class Initialized
DEBUG - 2011-04-08 14:49:48 --> Model Class Initialized
DEBUG - 2011-04-08 14:49:48 --> Model Class Initialized
DEBUG - 2011-04-08 14:49:48 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-08 14:49:48 --> Database Driver Class Initialized
DEBUG - 2011-04-08 14:49:48 --> Final output sent to browser
DEBUG - 2011-04-08 14:49:48 --> Total execution time: 0.7220
DEBUG - 2011-04-08 14:49:51 --> Config Class Initialized
DEBUG - 2011-04-08 14:49:51 --> Hooks Class Initialized
DEBUG - 2011-04-08 14:49:51 --> Utf8 Class Initialized
DEBUG - 2011-04-08 14:49:51 --> UTF-8 Support Enabled
DEBUG - 2011-04-08 14:49:51 --> URI Class Initialized
DEBUG - 2011-04-08 14:49:51 --> Router Class Initialized
ERROR - 2011-04-08 14:49:51 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-04-08 14:54:24 --> Config Class Initialized
DEBUG - 2011-04-08 14:54:24 --> Hooks Class Initialized
DEBUG - 2011-04-08 14:54:24 --> Utf8 Class Initialized
DEBUG - 2011-04-08 14:54:24 --> UTF-8 Support Enabled
DEBUG - 2011-04-08 14:54:24 --> URI Class Initialized
DEBUG - 2011-04-08 14:54:24 --> Router Class Initialized
DEBUG - 2011-04-08 14:54:24 --> Output Class Initialized
DEBUG - 2011-04-08 14:54:24 --> Input Class Initialized
DEBUG - 2011-04-08 14:54:24 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-08 14:54:24 --> Language Class Initialized
DEBUG - 2011-04-08 14:54:24 --> Loader Class Initialized
DEBUG - 2011-04-08 14:54:24 --> Controller Class Initialized
ERROR - 2011-04-08 14:54:24 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-04-08 14:54:24 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-04-08 14:54:24 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-04-08 14:54:24 --> Model Class Initialized
DEBUG - 2011-04-08 14:54:24 --> Model Class Initialized
DEBUG - 2011-04-08 14:54:24 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-08 14:54:25 --> Database Driver Class Initialized
DEBUG - 2011-04-08 14:54:25 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-04-08 14:54:25 --> Helper loaded: url_helper
DEBUG - 2011-04-08 14:54:25 --> File loaded: application/views/common/header.php
DEBUG - 2011-04-08 14:54:25 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-04-08 14:54:25 --> File loaded: application/views/common/footer.php
DEBUG - 2011-04-08 14:54:25 --> File loaded: application/views/layout/main.php
DEBUG - 2011-04-08 14:54:25 --> Final output sent to browser
DEBUG - 2011-04-08 14:54:25 --> Total execution time: 1.4916
DEBUG - 2011-04-08 14:54:26 --> Config Class Initialized
DEBUG - 2011-04-08 14:54:26 --> Hooks Class Initialized
DEBUG - 2011-04-08 14:54:26 --> Utf8 Class Initialized
DEBUG - 2011-04-08 14:54:26 --> UTF-8 Support Enabled
DEBUG - 2011-04-08 14:54:26 --> URI Class Initialized
DEBUG - 2011-04-08 14:54:26 --> Router Class Initialized
DEBUG - 2011-04-08 14:54:26 --> Output Class Initialized
DEBUG - 2011-04-08 14:54:26 --> Input Class Initialized
DEBUG - 2011-04-08 14:54:26 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-08 14:54:26 --> Language Class Initialized
DEBUG - 2011-04-08 14:54:26 --> Loader Class Initialized
DEBUG - 2011-04-08 14:54:26 --> Controller Class Initialized
DEBUG - 2011-04-08 14:54:26 --> Model Class Initialized
DEBUG - 2011-04-08 14:54:26 --> Model Class Initialized
DEBUG - 2011-04-08 14:54:26 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-08 14:54:26 --> Database Driver Class Initialized
DEBUG - 2011-04-08 14:54:27 --> Final output sent to browser
DEBUG - 2011-04-08 14:54:27 --> Total execution time: 0.6144
DEBUG - 2011-04-08 14:54:28 --> Config Class Initialized
DEBUG - 2011-04-08 14:54:28 --> Hooks Class Initialized
DEBUG - 2011-04-08 14:54:28 --> Utf8 Class Initialized
DEBUG - 2011-04-08 14:54:28 --> UTF-8 Support Enabled
DEBUG - 2011-04-08 14:54:28 --> URI Class Initialized
DEBUG - 2011-04-08 14:54:28 --> Router Class Initialized
ERROR - 2011-04-08 14:54:28 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-04-08 14:54:56 --> Config Class Initialized
DEBUG - 2011-04-08 14:54:56 --> Hooks Class Initialized
DEBUG - 2011-04-08 14:54:56 --> Utf8 Class Initialized
DEBUG - 2011-04-08 14:54:56 --> UTF-8 Support Enabled
DEBUG - 2011-04-08 14:54:56 --> URI Class Initialized
DEBUG - 2011-04-08 14:54:56 --> Router Class Initialized
DEBUG - 2011-04-08 14:54:56 --> Output Class Initialized
DEBUG - 2011-04-08 14:54:56 --> Input Class Initialized
DEBUG - 2011-04-08 14:54:56 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-08 14:54:56 --> Language Class Initialized
DEBUG - 2011-04-08 14:54:56 --> Loader Class Initialized
DEBUG - 2011-04-08 14:54:56 --> Controller Class Initialized
ERROR - 2011-04-08 14:54:56 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-04-08 14:54:56 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-04-08 14:54:56 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-04-08 14:54:56 --> Model Class Initialized
DEBUG - 2011-04-08 14:54:56 --> Model Class Initialized
DEBUG - 2011-04-08 14:54:56 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-08 14:54:56 --> Database Driver Class Initialized
DEBUG - 2011-04-08 14:54:56 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-04-08 14:54:56 --> Helper loaded: url_helper
DEBUG - 2011-04-08 14:54:56 --> File loaded: application/views/common/header.php
DEBUG - 2011-04-08 14:54:56 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-04-08 14:54:56 --> File loaded: application/views/common/footer.php
DEBUG - 2011-04-08 14:54:56 --> File loaded: application/views/layout/main.php
DEBUG - 2011-04-08 14:54:56 --> Final output sent to browser
DEBUG - 2011-04-08 14:54:56 --> Total execution time: 0.0317
DEBUG - 2011-04-08 14:54:56 --> Config Class Initialized
DEBUG - 2011-04-08 14:54:56 --> Hooks Class Initialized
DEBUG - 2011-04-08 14:54:56 --> Utf8 Class Initialized
DEBUG - 2011-04-08 14:54:56 --> UTF-8 Support Enabled
DEBUG - 2011-04-08 14:54:56 --> URI Class Initialized
DEBUG - 2011-04-08 14:54:56 --> Router Class Initialized
DEBUG - 2011-04-08 14:54:56 --> Output Class Initialized
DEBUG - 2011-04-08 14:54:56 --> Input Class Initialized
DEBUG - 2011-04-08 14:54:56 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-08 14:54:56 --> Language Class Initialized
DEBUG - 2011-04-08 14:54:56 --> Loader Class Initialized
DEBUG - 2011-04-08 14:54:56 --> Controller Class Initialized
DEBUG - 2011-04-08 14:54:56 --> Model Class Initialized
DEBUG - 2011-04-08 14:54:56 --> Model Class Initialized
DEBUG - 2011-04-08 14:54:56 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-08 14:54:56 --> Database Driver Class Initialized
DEBUG - 2011-04-08 14:54:57 --> Final output sent to browser
DEBUG - 2011-04-08 14:54:57 --> Total execution time: 0.8589
DEBUG - 2011-04-08 14:54:58 --> Config Class Initialized
DEBUG - 2011-04-08 14:54:58 --> Hooks Class Initialized
DEBUG - 2011-04-08 14:54:58 --> Utf8 Class Initialized
DEBUG - 2011-04-08 14:54:58 --> UTF-8 Support Enabled
DEBUG - 2011-04-08 14:54:58 --> URI Class Initialized
DEBUG - 2011-04-08 14:54:58 --> Router Class Initialized
ERROR - 2011-04-08 14:54:58 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-04-08 14:55:39 --> Config Class Initialized
DEBUG - 2011-04-08 14:55:39 --> Hooks Class Initialized
DEBUG - 2011-04-08 14:55:39 --> Utf8 Class Initialized
DEBUG - 2011-04-08 14:55:39 --> UTF-8 Support Enabled
DEBUG - 2011-04-08 14:55:39 --> URI Class Initialized
DEBUG - 2011-04-08 14:55:39 --> Router Class Initialized
DEBUG - 2011-04-08 14:55:39 --> Output Class Initialized
DEBUG - 2011-04-08 14:55:39 --> Input Class Initialized
DEBUG - 2011-04-08 14:55:39 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-08 14:55:39 --> Language Class Initialized
DEBUG - 2011-04-08 14:55:39 --> Loader Class Initialized
DEBUG - 2011-04-08 14:55:39 --> Controller Class Initialized
ERROR - 2011-04-08 14:55:39 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-04-08 14:55:39 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-04-08 14:55:39 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-04-08 14:55:39 --> Model Class Initialized
DEBUG - 2011-04-08 14:55:39 --> Model Class Initialized
DEBUG - 2011-04-08 14:55:39 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-08 14:55:39 --> Database Driver Class Initialized
DEBUG - 2011-04-08 14:55:39 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-04-08 14:55:39 --> Helper loaded: url_helper
DEBUG - 2011-04-08 14:55:39 --> File loaded: application/views/common/header.php
DEBUG - 2011-04-08 14:55:39 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-04-08 14:55:39 --> File loaded: application/views/common/footer.php
DEBUG - 2011-04-08 14:55:39 --> File loaded: application/views/layout/main.php
DEBUG - 2011-04-08 14:55:39 --> Final output sent to browser
DEBUG - 2011-04-08 14:55:39 --> Total execution time: 0.0621
DEBUG - 2011-04-08 14:55:40 --> Config Class Initialized
DEBUG - 2011-04-08 14:55:40 --> Hooks Class Initialized
DEBUG - 2011-04-08 14:55:40 --> Utf8 Class Initialized
DEBUG - 2011-04-08 14:55:40 --> UTF-8 Support Enabled
DEBUG - 2011-04-08 14:55:40 --> URI Class Initialized
DEBUG - 2011-04-08 14:55:40 --> Router Class Initialized
DEBUG - 2011-04-08 14:55:40 --> Output Class Initialized
DEBUG - 2011-04-08 14:55:40 --> Input Class Initialized
DEBUG - 2011-04-08 14:55:40 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-08 14:55:40 --> Language Class Initialized
DEBUG - 2011-04-08 14:55:40 --> Loader Class Initialized
DEBUG - 2011-04-08 14:55:40 --> Controller Class Initialized
DEBUG - 2011-04-08 14:55:40 --> Model Class Initialized
DEBUG - 2011-04-08 14:55:40 --> Model Class Initialized
DEBUG - 2011-04-08 14:55:40 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-08 14:55:40 --> Database Driver Class Initialized
DEBUG - 2011-04-08 14:55:40 --> Final output sent to browser
DEBUG - 2011-04-08 14:55:40 --> Total execution time: 0.6490
DEBUG - 2011-04-08 14:55:42 --> Config Class Initialized
DEBUG - 2011-04-08 14:55:42 --> Hooks Class Initialized
DEBUG - 2011-04-08 14:55:42 --> Utf8 Class Initialized
DEBUG - 2011-04-08 14:55:42 --> UTF-8 Support Enabled
DEBUG - 2011-04-08 14:55:42 --> URI Class Initialized
DEBUG - 2011-04-08 14:55:42 --> Router Class Initialized
ERROR - 2011-04-08 14:55:42 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-04-08 14:55:44 --> Config Class Initialized
DEBUG - 2011-04-08 14:55:44 --> Hooks Class Initialized
DEBUG - 2011-04-08 14:55:44 --> Utf8 Class Initialized
DEBUG - 2011-04-08 14:55:44 --> UTF-8 Support Enabled
DEBUG - 2011-04-08 14:55:44 --> URI Class Initialized
DEBUG - 2011-04-08 14:55:44 --> Router Class Initialized
DEBUG - 2011-04-08 14:55:44 --> Output Class Initialized
DEBUG - 2011-04-08 14:55:44 --> Input Class Initialized
DEBUG - 2011-04-08 14:55:44 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-08 14:55:44 --> Language Class Initialized
DEBUG - 2011-04-08 14:55:44 --> Loader Class Initialized
DEBUG - 2011-04-08 14:55:44 --> Controller Class Initialized
ERROR - 2011-04-08 14:55:44 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-04-08 14:55:44 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-04-08 14:55:44 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-04-08 14:55:44 --> Model Class Initialized
DEBUG - 2011-04-08 14:55:44 --> Model Class Initialized
DEBUG - 2011-04-08 14:55:44 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-08 14:55:44 --> Database Driver Class Initialized
DEBUG - 2011-04-08 14:55:44 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-04-08 14:55:44 --> Helper loaded: url_helper
DEBUG - 2011-04-08 14:55:44 --> File loaded: application/views/common/header.php
DEBUG - 2011-04-08 14:55:44 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-04-08 14:55:44 --> File loaded: application/views/common/footer.php
DEBUG - 2011-04-08 14:55:44 --> File loaded: application/views/layout/main.php
DEBUG - 2011-04-08 14:55:44 --> Final output sent to browser
DEBUG - 2011-04-08 14:55:44 --> Total execution time: 0.0450
DEBUG - 2011-04-08 14:55:47 --> Config Class Initialized
DEBUG - 2011-04-08 14:55:47 --> Hooks Class Initialized
DEBUG - 2011-04-08 14:55:47 --> Utf8 Class Initialized
DEBUG - 2011-04-08 14:55:47 --> UTF-8 Support Enabled
DEBUG - 2011-04-08 14:55:47 --> URI Class Initialized
DEBUG - 2011-04-08 14:55:47 --> Router Class Initialized
DEBUG - 2011-04-08 14:55:47 --> Output Class Initialized
DEBUG - 2011-04-08 14:55:47 --> Input Class Initialized
DEBUG - 2011-04-08 14:55:47 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-08 14:55:47 --> Language Class Initialized
DEBUG - 2011-04-08 14:55:47 --> Loader Class Initialized
DEBUG - 2011-04-08 14:55:47 --> Controller Class Initialized
ERROR - 2011-04-08 14:55:47 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-04-08 14:55:47 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-04-08 14:55:47 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-04-08 14:55:47 --> Model Class Initialized
DEBUG - 2011-04-08 14:55:47 --> Model Class Initialized
DEBUG - 2011-04-08 14:55:47 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-08 14:55:47 --> Database Driver Class Initialized
DEBUG - 2011-04-08 14:55:47 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-04-08 14:55:47 --> Helper loaded: url_helper
DEBUG - 2011-04-08 14:55:47 --> File loaded: application/views/common/header.php
DEBUG - 2011-04-08 14:55:47 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-04-08 14:55:47 --> File loaded: application/views/common/footer.php
DEBUG - 2011-04-08 14:55:47 --> File loaded: application/views/layout/main.php
DEBUG - 2011-04-08 14:55:47 --> Final output sent to browser
DEBUG - 2011-04-08 14:55:47 --> Total execution time: 0.0306
DEBUG - 2011-04-08 14:55:48 --> Config Class Initialized
DEBUG - 2011-04-08 14:55:48 --> Hooks Class Initialized
DEBUG - 2011-04-08 14:55:48 --> Utf8 Class Initialized
DEBUG - 2011-04-08 14:55:48 --> UTF-8 Support Enabled
DEBUG - 2011-04-08 14:55:48 --> URI Class Initialized
DEBUG - 2011-04-08 14:55:48 --> Router Class Initialized
DEBUG - 2011-04-08 14:55:48 --> Output Class Initialized
DEBUG - 2011-04-08 14:55:48 --> Input Class Initialized
DEBUG - 2011-04-08 14:55:48 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-08 14:55:48 --> Language Class Initialized
DEBUG - 2011-04-08 14:55:48 --> Loader Class Initialized
DEBUG - 2011-04-08 14:55:48 --> Controller Class Initialized
DEBUG - 2011-04-08 14:55:48 --> Model Class Initialized
DEBUG - 2011-04-08 14:55:48 --> Model Class Initialized
DEBUG - 2011-04-08 14:55:48 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-08 14:55:48 --> Database Driver Class Initialized
DEBUG - 2011-04-08 14:55:48 --> Final output sent to browser
DEBUG - 2011-04-08 14:55:48 --> Total execution time: 0.5635
DEBUG - 2011-04-08 14:55:49 --> Config Class Initialized
DEBUG - 2011-04-08 14:55:49 --> Hooks Class Initialized
DEBUG - 2011-04-08 14:55:49 --> Utf8 Class Initialized
DEBUG - 2011-04-08 14:55:49 --> UTF-8 Support Enabled
DEBUG - 2011-04-08 14:55:49 --> URI Class Initialized
DEBUG - 2011-04-08 14:55:49 --> Router Class Initialized
DEBUG - 2011-04-08 14:55:49 --> Output Class Initialized
DEBUG - 2011-04-08 14:55:49 --> Input Class Initialized
DEBUG - 2011-04-08 14:55:49 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-08 14:55:49 --> Language Class Initialized
DEBUG - 2011-04-08 14:55:49 --> Loader Class Initialized
DEBUG - 2011-04-08 14:55:49 --> Controller Class Initialized
ERROR - 2011-04-08 14:55:49 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-04-08 14:55:49 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-04-08 14:55:49 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-04-08 14:55:49 --> Model Class Initialized
DEBUG - 2011-04-08 14:55:49 --> Model Class Initialized
DEBUG - 2011-04-08 14:55:49 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-08 14:55:49 --> Database Driver Class Initialized
DEBUG - 2011-04-08 14:55:49 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-04-08 14:55:49 --> Helper loaded: url_helper
DEBUG - 2011-04-08 14:55:49 --> File loaded: application/views/common/header.php
DEBUG - 2011-04-08 14:55:49 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-04-08 14:55:49 --> File loaded: application/views/common/footer.php
DEBUG - 2011-04-08 14:55:49 --> File loaded: application/views/layout/main.php
DEBUG - 2011-04-08 14:55:49 --> Final output sent to browser
DEBUG - 2011-04-08 14:55:49 --> Total execution time: 0.0290
DEBUG - 2011-04-08 14:55:50 --> Config Class Initialized
DEBUG - 2011-04-08 14:55:50 --> Hooks Class Initialized
DEBUG - 2011-04-08 14:55:50 --> Utf8 Class Initialized
DEBUG - 2011-04-08 14:55:50 --> UTF-8 Support Enabled
DEBUG - 2011-04-08 14:55:50 --> URI Class Initialized
DEBUG - 2011-04-08 14:55:50 --> Router Class Initialized
ERROR - 2011-04-08 14:55:50 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-04-08 14:56:03 --> Config Class Initialized
DEBUG - 2011-04-08 14:56:03 --> Hooks Class Initialized
DEBUG - 2011-04-08 14:56:03 --> Utf8 Class Initialized
DEBUG - 2011-04-08 14:56:03 --> UTF-8 Support Enabled
DEBUG - 2011-04-08 14:56:03 --> URI Class Initialized
DEBUG - 2011-04-08 14:56:03 --> Router Class Initialized
DEBUG - 2011-04-08 14:56:03 --> Output Class Initialized
DEBUG - 2011-04-08 14:56:03 --> Input Class Initialized
DEBUG - 2011-04-08 14:56:03 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-08 14:56:03 --> Language Class Initialized
DEBUG - 2011-04-08 14:56:03 --> Loader Class Initialized
DEBUG - 2011-04-08 14:56:03 --> Controller Class Initialized
ERROR - 2011-04-08 14:56:03 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-04-08 14:56:03 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-04-08 14:56:03 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-04-08 14:56:03 --> Model Class Initialized
DEBUG - 2011-04-08 14:56:03 --> Model Class Initialized
DEBUG - 2011-04-08 14:56:03 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-08 14:56:03 --> Database Driver Class Initialized
DEBUG - 2011-04-08 14:56:03 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-04-08 14:56:03 --> Helper loaded: url_helper
DEBUG - 2011-04-08 14:56:03 --> File loaded: application/views/common/header.php
DEBUG - 2011-04-08 14:56:03 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-04-08 14:56:03 --> File loaded: application/views/common/footer.php
DEBUG - 2011-04-08 14:56:03 --> File loaded: application/views/layout/main.php
DEBUG - 2011-04-08 14:56:03 --> Final output sent to browser
DEBUG - 2011-04-08 14:56:03 --> Total execution time: 0.0311
DEBUG - 2011-04-08 14:56:04 --> Config Class Initialized
DEBUG - 2011-04-08 14:56:04 --> Hooks Class Initialized
DEBUG - 2011-04-08 14:56:04 --> Utf8 Class Initialized
DEBUG - 2011-04-08 14:56:04 --> UTF-8 Support Enabled
DEBUG - 2011-04-08 14:56:04 --> URI Class Initialized
DEBUG - 2011-04-08 14:56:04 --> Router Class Initialized
DEBUG - 2011-04-08 14:56:04 --> Output Class Initialized
DEBUG - 2011-04-08 14:56:04 --> Input Class Initialized
DEBUG - 2011-04-08 14:56:04 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-08 14:56:04 --> Language Class Initialized
DEBUG - 2011-04-08 14:56:04 --> Loader Class Initialized
DEBUG - 2011-04-08 14:56:04 --> Controller Class Initialized
DEBUG - 2011-04-08 14:56:04 --> Model Class Initialized
DEBUG - 2011-04-08 14:56:04 --> Model Class Initialized
DEBUG - 2011-04-08 14:56:04 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-08 14:56:04 --> Database Driver Class Initialized
DEBUG - 2011-04-08 14:56:04 --> Final output sent to browser
DEBUG - 2011-04-08 14:56:04 --> Total execution time: 0.5444
DEBUG - 2011-04-08 14:56:07 --> Config Class Initialized
DEBUG - 2011-04-08 14:56:07 --> Hooks Class Initialized
DEBUG - 2011-04-08 14:56:07 --> Utf8 Class Initialized
DEBUG - 2011-04-08 14:56:07 --> UTF-8 Support Enabled
DEBUG - 2011-04-08 14:56:07 --> URI Class Initialized
DEBUG - 2011-04-08 14:56:07 --> Router Class Initialized
ERROR - 2011-04-08 14:56:07 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-04-08 14:56:18 --> Config Class Initialized
DEBUG - 2011-04-08 14:56:18 --> Hooks Class Initialized
DEBUG - 2011-04-08 14:56:18 --> Utf8 Class Initialized
DEBUG - 2011-04-08 14:56:18 --> UTF-8 Support Enabled
DEBUG - 2011-04-08 14:56:18 --> URI Class Initialized
DEBUG - 2011-04-08 14:56:18 --> Router Class Initialized
DEBUG - 2011-04-08 14:56:18 --> Output Class Initialized
DEBUG - 2011-04-08 14:56:18 --> Input Class Initialized
DEBUG - 2011-04-08 14:56:18 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-08 14:56:18 --> Language Class Initialized
DEBUG - 2011-04-08 14:56:18 --> Loader Class Initialized
DEBUG - 2011-04-08 14:56:18 --> Controller Class Initialized
ERROR - 2011-04-08 14:56:18 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-04-08 14:56:18 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-04-08 14:56:18 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-04-08 14:56:18 --> Model Class Initialized
DEBUG - 2011-04-08 14:56:18 --> Model Class Initialized
DEBUG - 2011-04-08 14:56:18 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-08 14:56:18 --> Database Driver Class Initialized
DEBUG - 2011-04-08 14:56:18 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-04-08 14:56:18 --> Helper loaded: url_helper
DEBUG - 2011-04-08 14:56:18 --> File loaded: application/views/common/header.php
DEBUG - 2011-04-08 14:56:18 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-04-08 14:56:18 --> File loaded: application/views/common/footer.php
DEBUG - 2011-04-08 14:56:18 --> File loaded: application/views/layout/main.php
DEBUG - 2011-04-08 14:56:18 --> Final output sent to browser
DEBUG - 2011-04-08 14:56:18 --> Total execution time: 0.0286
DEBUG - 2011-04-08 14:56:20 --> Config Class Initialized
DEBUG - 2011-04-08 14:56:20 --> Hooks Class Initialized
DEBUG - 2011-04-08 14:56:20 --> Utf8 Class Initialized
DEBUG - 2011-04-08 14:56:20 --> UTF-8 Support Enabled
DEBUG - 2011-04-08 14:56:20 --> URI Class Initialized
DEBUG - 2011-04-08 14:56:20 --> Router Class Initialized
DEBUG - 2011-04-08 14:56:20 --> Output Class Initialized
DEBUG - 2011-04-08 14:56:20 --> Input Class Initialized
DEBUG - 2011-04-08 14:56:20 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-08 14:56:20 --> Language Class Initialized
DEBUG - 2011-04-08 14:56:20 --> Loader Class Initialized
DEBUG - 2011-04-08 14:56:20 --> Controller Class Initialized
DEBUG - 2011-04-08 14:56:20 --> Model Class Initialized
DEBUG - 2011-04-08 14:56:20 --> Model Class Initialized
DEBUG - 2011-04-08 14:56:20 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-08 14:56:20 --> Database Driver Class Initialized
DEBUG - 2011-04-08 14:56:20 --> Final output sent to browser
DEBUG - 2011-04-08 14:56:20 --> Total execution time: 0.5026
DEBUG - 2011-04-08 14:56:22 --> Config Class Initialized
DEBUG - 2011-04-08 14:56:22 --> Hooks Class Initialized
DEBUG - 2011-04-08 14:56:22 --> Utf8 Class Initialized
DEBUG - 2011-04-08 14:56:22 --> UTF-8 Support Enabled
DEBUG - 2011-04-08 14:56:22 --> URI Class Initialized
DEBUG - 2011-04-08 14:56:22 --> Router Class Initialized
ERROR - 2011-04-08 14:56:22 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-04-08 14:56:30 --> Config Class Initialized
DEBUG - 2011-04-08 14:56:30 --> Hooks Class Initialized
DEBUG - 2011-04-08 14:56:30 --> Utf8 Class Initialized
DEBUG - 2011-04-08 14:56:30 --> UTF-8 Support Enabled
DEBUG - 2011-04-08 14:56:30 --> URI Class Initialized
DEBUG - 2011-04-08 14:56:30 --> Router Class Initialized
DEBUG - 2011-04-08 14:56:30 --> Output Class Initialized
DEBUG - 2011-04-08 14:56:30 --> Input Class Initialized
DEBUG - 2011-04-08 14:56:30 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-08 14:56:30 --> Language Class Initialized
DEBUG - 2011-04-08 14:56:30 --> Loader Class Initialized
DEBUG - 2011-04-08 14:56:30 --> Controller Class Initialized
ERROR - 2011-04-08 14:56:30 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-04-08 14:56:30 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-04-08 14:56:30 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-04-08 14:56:30 --> Model Class Initialized
DEBUG - 2011-04-08 14:56:30 --> Model Class Initialized
DEBUG - 2011-04-08 14:56:30 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-08 14:56:30 --> Database Driver Class Initialized
DEBUG - 2011-04-08 14:56:30 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-04-08 14:56:30 --> Helper loaded: url_helper
DEBUG - 2011-04-08 14:56:30 --> File loaded: application/views/common/header.php
DEBUG - 2011-04-08 14:56:30 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-04-08 14:56:30 --> File loaded: application/views/common/footer.php
DEBUG - 2011-04-08 14:56:30 --> File loaded: application/views/layout/main.php
DEBUG - 2011-04-08 14:56:30 --> Final output sent to browser
DEBUG - 2011-04-08 14:56:30 --> Total execution time: 0.0312
DEBUG - 2011-04-08 14:56:30 --> Config Class Initialized
DEBUG - 2011-04-08 14:56:30 --> Hooks Class Initialized
DEBUG - 2011-04-08 14:56:30 --> Utf8 Class Initialized
DEBUG - 2011-04-08 14:56:30 --> UTF-8 Support Enabled
DEBUG - 2011-04-08 14:56:30 --> URI Class Initialized
DEBUG - 2011-04-08 14:56:30 --> Router Class Initialized
DEBUG - 2011-04-08 14:56:30 --> Output Class Initialized
DEBUG - 2011-04-08 14:56:30 --> Input Class Initialized
DEBUG - 2011-04-08 14:56:30 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-08 14:56:30 --> Language Class Initialized
DEBUG - 2011-04-08 14:56:30 --> Loader Class Initialized
DEBUG - 2011-04-08 14:56:30 --> Controller Class Initialized
DEBUG - 2011-04-08 14:56:30 --> Model Class Initialized
DEBUG - 2011-04-08 14:56:30 --> Model Class Initialized
DEBUG - 2011-04-08 14:56:30 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-08 14:56:30 --> Database Driver Class Initialized
DEBUG - 2011-04-08 14:56:31 --> Final output sent to browser
DEBUG - 2011-04-08 14:56:31 --> Total execution time: 0.5476
DEBUG - 2011-04-08 14:56:31 --> Config Class Initialized
DEBUG - 2011-04-08 14:56:31 --> Hooks Class Initialized
DEBUG - 2011-04-08 14:56:31 --> Utf8 Class Initialized
DEBUG - 2011-04-08 14:56:31 --> UTF-8 Support Enabled
DEBUG - 2011-04-08 14:56:31 --> URI Class Initialized
DEBUG - 2011-04-08 14:56:31 --> Router Class Initialized
DEBUG - 2011-04-08 14:56:31 --> Output Class Initialized
DEBUG - 2011-04-08 14:56:31 --> Input Class Initialized
DEBUG - 2011-04-08 14:56:31 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-08 14:56:31 --> Language Class Initialized
DEBUG - 2011-04-08 14:56:31 --> Loader Class Initialized
DEBUG - 2011-04-08 14:56:31 --> Controller Class Initialized
ERROR - 2011-04-08 14:56:31 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-04-08 14:56:31 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-04-08 14:56:31 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-04-08 14:56:31 --> Model Class Initialized
DEBUG - 2011-04-08 14:56:31 --> Model Class Initialized
DEBUG - 2011-04-08 14:56:31 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-08 14:56:31 --> Database Driver Class Initialized
DEBUG - 2011-04-08 14:56:31 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-04-08 14:56:31 --> Helper loaded: url_helper
DEBUG - 2011-04-08 14:56:31 --> File loaded: application/views/common/header.php
DEBUG - 2011-04-08 14:56:31 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-04-08 14:56:31 --> File loaded: application/views/common/footer.php
DEBUG - 2011-04-08 14:56:31 --> File loaded: application/views/layout/main.php
DEBUG - 2011-04-08 14:56:31 --> Final output sent to browser
DEBUG - 2011-04-08 14:56:31 --> Total execution time: 0.0334
DEBUG - 2011-04-08 14:56:34 --> Config Class Initialized
DEBUG - 2011-04-08 14:56:34 --> Hooks Class Initialized
DEBUG - 2011-04-08 14:56:34 --> Utf8 Class Initialized
DEBUG - 2011-04-08 14:56:34 --> UTF-8 Support Enabled
DEBUG - 2011-04-08 14:56:34 --> URI Class Initialized
DEBUG - 2011-04-08 14:56:34 --> Router Class Initialized
ERROR - 2011-04-08 14:56:34 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-04-08 14:56:47 --> Config Class Initialized
DEBUG - 2011-04-08 14:56:47 --> Hooks Class Initialized
DEBUG - 2011-04-08 14:56:47 --> Utf8 Class Initialized
DEBUG - 2011-04-08 14:56:47 --> UTF-8 Support Enabled
DEBUG - 2011-04-08 14:56:47 --> URI Class Initialized
DEBUG - 2011-04-08 14:56:47 --> Router Class Initialized
DEBUG - 2011-04-08 14:56:47 --> Output Class Initialized
DEBUG - 2011-04-08 14:56:47 --> Input Class Initialized
DEBUG - 2011-04-08 14:56:47 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-08 14:56:47 --> Language Class Initialized
DEBUG - 2011-04-08 14:56:47 --> Loader Class Initialized
DEBUG - 2011-04-08 14:56:47 --> Controller Class Initialized
ERROR - 2011-04-08 14:56:47 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-04-08 14:56:47 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-04-08 14:56:47 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-04-08 14:56:47 --> Model Class Initialized
DEBUG - 2011-04-08 14:56:47 --> Model Class Initialized
DEBUG - 2011-04-08 14:56:47 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-08 14:56:47 --> Database Driver Class Initialized
DEBUG - 2011-04-08 14:56:47 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-04-08 14:56:47 --> Helper loaded: url_helper
DEBUG - 2011-04-08 14:56:47 --> File loaded: application/views/common/header.php
DEBUG - 2011-04-08 14:56:47 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-04-08 14:56:47 --> File loaded: application/views/common/footer.php
DEBUG - 2011-04-08 14:56:47 --> File loaded: application/views/layout/main.php
DEBUG - 2011-04-08 14:56:47 --> Final output sent to browser
DEBUG - 2011-04-08 14:56:47 --> Total execution time: 0.0336
DEBUG - 2011-04-08 14:56:48 --> Config Class Initialized
DEBUG - 2011-04-08 14:56:48 --> Hooks Class Initialized
DEBUG - 2011-04-08 14:56:48 --> Utf8 Class Initialized
DEBUG - 2011-04-08 14:56:48 --> UTF-8 Support Enabled
DEBUG - 2011-04-08 14:56:48 --> URI Class Initialized
DEBUG - 2011-04-08 14:56:48 --> Router Class Initialized
DEBUG - 2011-04-08 14:56:48 --> Output Class Initialized
DEBUG - 2011-04-08 14:56:48 --> Input Class Initialized
DEBUG - 2011-04-08 14:56:48 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-08 14:56:48 --> Language Class Initialized
DEBUG - 2011-04-08 14:56:48 --> Loader Class Initialized
DEBUG - 2011-04-08 14:56:48 --> Controller Class Initialized
DEBUG - 2011-04-08 14:56:48 --> Model Class Initialized
DEBUG - 2011-04-08 14:56:48 --> Model Class Initialized
DEBUG - 2011-04-08 14:56:48 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-08 14:56:48 --> Database Driver Class Initialized
DEBUG - 2011-04-08 14:56:48 --> Final output sent to browser
DEBUG - 2011-04-08 14:56:48 --> Total execution time: 0.4994
DEBUG - 2011-04-08 14:56:49 --> Config Class Initialized
DEBUG - 2011-04-08 14:56:49 --> Hooks Class Initialized
DEBUG - 2011-04-08 14:56:49 --> Utf8 Class Initialized
DEBUG - 2011-04-08 14:56:49 --> UTF-8 Support Enabled
DEBUG - 2011-04-08 14:56:49 --> URI Class Initialized
DEBUG - 2011-04-08 14:56:49 --> Router Class Initialized
DEBUG - 2011-04-08 14:56:49 --> Output Class Initialized
DEBUG - 2011-04-08 14:56:49 --> Input Class Initialized
DEBUG - 2011-04-08 14:56:49 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-08 14:56:49 --> Language Class Initialized
DEBUG - 2011-04-08 14:56:49 --> Loader Class Initialized
DEBUG - 2011-04-08 14:56:49 --> Controller Class Initialized
ERROR - 2011-04-08 14:56:49 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-04-08 14:56:49 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-04-08 14:56:49 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-04-08 14:56:49 --> Model Class Initialized
DEBUG - 2011-04-08 14:56:49 --> Model Class Initialized
DEBUG - 2011-04-08 14:56:49 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-08 14:56:49 --> Database Driver Class Initialized
DEBUG - 2011-04-08 14:56:49 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-04-08 14:56:49 --> Helper loaded: url_helper
DEBUG - 2011-04-08 14:56:49 --> File loaded: application/views/common/header.php
DEBUG - 2011-04-08 14:56:49 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-04-08 14:56:49 --> File loaded: application/views/common/footer.php
DEBUG - 2011-04-08 14:56:49 --> File loaded: application/views/layout/main.php
DEBUG - 2011-04-08 14:56:49 --> Final output sent to browser
DEBUG - 2011-04-08 14:56:49 --> Total execution time: 0.0283
DEBUG - 2011-04-08 14:56:50 --> Config Class Initialized
DEBUG - 2011-04-08 14:56:50 --> Hooks Class Initialized
DEBUG - 2011-04-08 14:56:50 --> Utf8 Class Initialized
DEBUG - 2011-04-08 14:56:50 --> UTF-8 Support Enabled
DEBUG - 2011-04-08 14:56:50 --> URI Class Initialized
DEBUG - 2011-04-08 14:56:50 --> Router Class Initialized
ERROR - 2011-04-08 14:56:50 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-04-08 14:57:00 --> Config Class Initialized
DEBUG - 2011-04-08 14:57:00 --> Hooks Class Initialized
DEBUG - 2011-04-08 14:57:00 --> Utf8 Class Initialized
DEBUG - 2011-04-08 14:57:00 --> UTF-8 Support Enabled
DEBUG - 2011-04-08 14:57:00 --> URI Class Initialized
DEBUG - 2011-04-08 14:57:00 --> Router Class Initialized
DEBUG - 2011-04-08 14:57:00 --> Output Class Initialized
DEBUG - 2011-04-08 14:57:00 --> Input Class Initialized
DEBUG - 2011-04-08 14:57:00 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-08 14:57:00 --> Language Class Initialized
DEBUG - 2011-04-08 14:57:00 --> Loader Class Initialized
DEBUG - 2011-04-08 14:57:00 --> Controller Class Initialized
ERROR - 2011-04-08 14:57:00 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-04-08 14:57:00 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-04-08 14:57:00 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-04-08 14:57:00 --> Model Class Initialized
DEBUG - 2011-04-08 14:57:00 --> Model Class Initialized
DEBUG - 2011-04-08 14:57:00 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-08 14:57:00 --> Database Driver Class Initialized
DEBUG - 2011-04-08 14:57:00 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-04-08 14:57:00 --> Helper loaded: url_helper
DEBUG - 2011-04-08 14:57:00 --> File loaded: application/views/common/header.php
DEBUG - 2011-04-08 14:57:00 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-04-08 14:57:00 --> File loaded: application/views/common/footer.php
DEBUG - 2011-04-08 14:57:00 --> File loaded: application/views/layout/main.php
DEBUG - 2011-04-08 14:57:00 --> Final output sent to browser
DEBUG - 2011-04-08 14:57:00 --> Total execution time: 0.0433
DEBUG - 2011-04-08 14:57:00 --> Config Class Initialized
DEBUG - 2011-04-08 14:57:00 --> Hooks Class Initialized
DEBUG - 2011-04-08 14:57:00 --> Utf8 Class Initialized
DEBUG - 2011-04-08 14:57:00 --> UTF-8 Support Enabled
DEBUG - 2011-04-08 14:57:00 --> URI Class Initialized
DEBUG - 2011-04-08 14:57:00 --> Router Class Initialized
DEBUG - 2011-04-08 14:57:00 --> Output Class Initialized
DEBUG - 2011-04-08 14:57:00 --> Input Class Initialized
DEBUG - 2011-04-08 14:57:00 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-08 14:57:00 --> Language Class Initialized
DEBUG - 2011-04-08 14:57:00 --> Loader Class Initialized
DEBUG - 2011-04-08 14:57:00 --> Controller Class Initialized
DEBUG - 2011-04-08 14:57:00 --> Model Class Initialized
DEBUG - 2011-04-08 14:57:00 --> Model Class Initialized
DEBUG - 2011-04-08 14:57:00 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-08 14:57:00 --> Database Driver Class Initialized
DEBUG - 2011-04-08 14:57:01 --> Final output sent to browser
DEBUG - 2011-04-08 14:57:01 --> Total execution time: 0.5118
DEBUG - 2011-04-08 14:57:02 --> Config Class Initialized
DEBUG - 2011-04-08 14:57:02 --> Hooks Class Initialized
DEBUG - 2011-04-08 14:57:02 --> Utf8 Class Initialized
DEBUG - 2011-04-08 14:57:02 --> UTF-8 Support Enabled
DEBUG - 2011-04-08 14:57:02 --> URI Class Initialized
DEBUG - 2011-04-08 14:57:02 --> Router Class Initialized
DEBUG - 2011-04-08 14:57:02 --> Output Class Initialized
DEBUG - 2011-04-08 14:57:02 --> Input Class Initialized
DEBUG - 2011-04-08 14:57:02 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-08 14:57:02 --> Language Class Initialized
DEBUG - 2011-04-08 14:57:02 --> Loader Class Initialized
DEBUG - 2011-04-08 14:57:02 --> Controller Class Initialized
ERROR - 2011-04-08 14:57:02 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-04-08 14:57:02 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-04-08 14:57:02 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-04-08 14:57:02 --> Model Class Initialized
DEBUG - 2011-04-08 14:57:02 --> Model Class Initialized
DEBUG - 2011-04-08 14:57:02 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-08 14:57:02 --> Database Driver Class Initialized
DEBUG - 2011-04-08 14:57:02 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-04-08 14:57:02 --> Helper loaded: url_helper
DEBUG - 2011-04-08 14:57:02 --> File loaded: application/views/common/header.php
DEBUG - 2011-04-08 14:57:02 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-04-08 14:57:02 --> File loaded: application/views/common/footer.php
DEBUG - 2011-04-08 14:57:02 --> File loaded: application/views/layout/main.php
DEBUG - 2011-04-08 14:57:02 --> Final output sent to browser
DEBUG - 2011-04-08 14:57:02 --> Total execution time: 0.0355
DEBUG - 2011-04-08 14:57:02 --> Config Class Initialized
DEBUG - 2011-04-08 14:57:02 --> Hooks Class Initialized
DEBUG - 2011-04-08 14:57:02 --> Utf8 Class Initialized
DEBUG - 2011-04-08 14:57:02 --> UTF-8 Support Enabled
DEBUG - 2011-04-08 14:57:02 --> URI Class Initialized
DEBUG - 2011-04-08 14:57:02 --> Router Class Initialized
ERROR - 2011-04-08 14:57:02 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-04-08 14:57:13 --> Config Class Initialized
DEBUG - 2011-04-08 14:57:13 --> Hooks Class Initialized
DEBUG - 2011-04-08 14:57:13 --> Utf8 Class Initialized
DEBUG - 2011-04-08 14:57:13 --> UTF-8 Support Enabled
DEBUG - 2011-04-08 14:57:13 --> URI Class Initialized
DEBUG - 2011-04-08 14:57:13 --> Router Class Initialized
DEBUG - 2011-04-08 14:57:13 --> Output Class Initialized
DEBUG - 2011-04-08 14:57:13 --> Input Class Initialized
DEBUG - 2011-04-08 14:57:13 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-08 14:57:13 --> Language Class Initialized
DEBUG - 2011-04-08 14:57:13 --> Loader Class Initialized
DEBUG - 2011-04-08 14:57:13 --> Controller Class Initialized
ERROR - 2011-04-08 14:57:13 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-04-08 14:57:13 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-04-08 14:57:13 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-04-08 14:57:13 --> Model Class Initialized
DEBUG - 2011-04-08 14:57:13 --> Model Class Initialized
DEBUG - 2011-04-08 14:57:13 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-08 14:57:13 --> Database Driver Class Initialized
DEBUG - 2011-04-08 14:57:13 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-04-08 14:57:13 --> Helper loaded: url_helper
DEBUG - 2011-04-08 14:57:13 --> File loaded: application/views/common/header.php
DEBUG - 2011-04-08 14:57:13 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-04-08 14:57:13 --> File loaded: application/views/common/footer.php
DEBUG - 2011-04-08 14:57:13 --> File loaded: application/views/layout/main.php
DEBUG - 2011-04-08 14:57:13 --> Final output sent to browser
DEBUG - 2011-04-08 14:57:13 --> Total execution time: 0.0306
DEBUG - 2011-04-08 14:57:19 --> Config Class Initialized
DEBUG - 2011-04-08 14:57:19 --> Hooks Class Initialized
DEBUG - 2011-04-08 14:57:19 --> Utf8 Class Initialized
DEBUG - 2011-04-08 14:57:19 --> UTF-8 Support Enabled
DEBUG - 2011-04-08 14:57:19 --> URI Class Initialized
DEBUG - 2011-04-08 14:57:19 --> Router Class Initialized
DEBUG - 2011-04-08 14:57:19 --> Output Class Initialized
DEBUG - 2011-04-08 14:57:19 --> Input Class Initialized
DEBUG - 2011-04-08 14:57:19 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-08 14:57:19 --> Language Class Initialized
DEBUG - 2011-04-08 14:57:19 --> Loader Class Initialized
DEBUG - 2011-04-08 14:57:19 --> Controller Class Initialized
ERROR - 2011-04-08 14:57:19 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-04-08 14:57:19 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-04-08 14:57:19 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-04-08 14:57:19 --> Model Class Initialized
DEBUG - 2011-04-08 14:57:19 --> Model Class Initialized
DEBUG - 2011-04-08 14:57:19 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-08 14:57:19 --> Database Driver Class Initialized
DEBUG - 2011-04-08 14:57:19 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-04-08 14:57:19 --> Helper loaded: url_helper
DEBUG - 2011-04-08 14:57:19 --> File loaded: application/views/common/header.php
DEBUG - 2011-04-08 14:57:19 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-04-08 14:57:19 --> File loaded: application/views/common/footer.php
DEBUG - 2011-04-08 14:57:19 --> File loaded: application/views/layout/main.php
DEBUG - 2011-04-08 14:57:19 --> Final output sent to browser
DEBUG - 2011-04-08 14:57:19 --> Total execution time: 0.0425
DEBUG - 2011-04-08 14:57:20 --> Config Class Initialized
DEBUG - 2011-04-08 14:57:20 --> Hooks Class Initialized
DEBUG - 2011-04-08 14:57:20 --> Utf8 Class Initialized
DEBUG - 2011-04-08 14:57:20 --> UTF-8 Support Enabled
DEBUG - 2011-04-08 14:57:20 --> URI Class Initialized
DEBUG - 2011-04-08 14:57:20 --> Router Class Initialized
DEBUG - 2011-04-08 14:57:20 --> Output Class Initialized
DEBUG - 2011-04-08 14:57:20 --> Input Class Initialized
DEBUG - 2011-04-08 14:57:20 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-08 14:57:20 --> Language Class Initialized
DEBUG - 2011-04-08 14:57:20 --> Loader Class Initialized
DEBUG - 2011-04-08 14:57:20 --> Controller Class Initialized
DEBUG - 2011-04-08 14:57:20 --> Model Class Initialized
DEBUG - 2011-04-08 14:57:20 --> Model Class Initialized
DEBUG - 2011-04-08 14:57:20 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-08 14:57:20 --> Database Driver Class Initialized
DEBUG - 2011-04-08 14:57:20 --> Final output sent to browser
DEBUG - 2011-04-08 14:57:20 --> Total execution time: 0.5767
DEBUG - 2011-04-08 14:57:23 --> Config Class Initialized
DEBUG - 2011-04-08 14:57:23 --> Hooks Class Initialized
DEBUG - 2011-04-08 14:57:23 --> Utf8 Class Initialized
DEBUG - 2011-04-08 14:57:23 --> UTF-8 Support Enabled
DEBUG - 2011-04-08 14:57:23 --> URI Class Initialized
DEBUG - 2011-04-08 14:57:23 --> Router Class Initialized
ERROR - 2011-04-08 14:57:23 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-04-08 16:56:40 --> Config Class Initialized
DEBUG - 2011-04-08 16:56:40 --> Hooks Class Initialized
DEBUG - 2011-04-08 16:56:40 --> Utf8 Class Initialized
DEBUG - 2011-04-08 16:56:40 --> UTF-8 Support Enabled
DEBUG - 2011-04-08 16:56:40 --> URI Class Initialized
DEBUG - 2011-04-08 16:56:40 --> Router Class Initialized
DEBUG - 2011-04-08 16:56:40 --> Output Class Initialized
DEBUG - 2011-04-08 16:56:40 --> Input Class Initialized
DEBUG - 2011-04-08 16:56:40 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-08 16:56:40 --> Language Class Initialized
DEBUG - 2011-04-08 16:56:40 --> Loader Class Initialized
DEBUG - 2011-04-08 16:56:40 --> Controller Class Initialized
ERROR - 2011-04-08 16:56:40 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-04-08 16:56:40 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-04-08 16:56:40 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-04-08 16:56:40 --> Model Class Initialized
DEBUG - 2011-04-08 16:56:40 --> Model Class Initialized
DEBUG - 2011-04-08 16:56:40 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-08 16:56:40 --> Database Driver Class Initialized
DEBUG - 2011-04-08 16:56:40 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-04-08 16:56:40 --> Helper loaded: url_helper
DEBUG - 2011-04-08 16:56:40 --> File loaded: application/views/common/header.php
DEBUG - 2011-04-08 16:56:40 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-04-08 16:56:40 --> File loaded: application/views/common/footer.php
DEBUG - 2011-04-08 16:56:40 --> File loaded: application/views/layout/main.php
DEBUG - 2011-04-08 16:56:40 --> Final output sent to browser
DEBUG - 2011-04-08 16:56:40 --> Total execution time: 0.4085
DEBUG - 2011-04-08 18:43:39 --> Config Class Initialized
DEBUG - 2011-04-08 18:43:39 --> Hooks Class Initialized
DEBUG - 2011-04-08 18:43:39 --> Utf8 Class Initialized
DEBUG - 2011-04-08 18:43:39 --> UTF-8 Support Enabled
DEBUG - 2011-04-08 18:43:39 --> URI Class Initialized
DEBUG - 2011-04-08 18:43:39 --> Router Class Initialized
DEBUG - 2011-04-08 18:43:39 --> No URI present. Default controller set.
DEBUG - 2011-04-08 18:43:39 --> Output Class Initialized
DEBUG - 2011-04-08 18:43:39 --> Input Class Initialized
DEBUG - 2011-04-08 18:43:39 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-08 18:43:39 --> Language Class Initialized
DEBUG - 2011-04-08 18:43:39 --> Loader Class Initialized
DEBUG - 2011-04-08 18:43:39 --> Controller Class Initialized
DEBUG - 2011-04-08 18:43:39 --> File loaded: application/views/splash/main.php
DEBUG - 2011-04-08 18:43:39 --> Helper loaded: url_helper
DEBUG - 2011-04-08 18:43:39 --> File loaded: application/views/common/header.php
DEBUG - 2011-04-08 18:43:39 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-04-08 18:43:39 --> File loaded: application/views/common/footer.php
DEBUG - 2011-04-08 18:43:39 --> File loaded: application/views/layout/main.php
DEBUG - 2011-04-08 18:43:39 --> Final output sent to browser
DEBUG - 2011-04-08 18:43:39 --> Total execution time: 0.3222
DEBUG - 2011-04-08 20:21:35 --> Config Class Initialized
DEBUG - 2011-04-08 20:21:35 --> Hooks Class Initialized
DEBUG - 2011-04-08 20:21:35 --> Utf8 Class Initialized
DEBUG - 2011-04-08 20:21:35 --> UTF-8 Support Enabled
DEBUG - 2011-04-08 20:21:35 --> URI Class Initialized
DEBUG - 2011-04-08 20:21:35 --> Router Class Initialized
DEBUG - 2011-04-08 20:21:35 --> Output Class Initialized
DEBUG - 2011-04-08 20:21:35 --> Input Class Initialized
DEBUG - 2011-04-08 20:21:35 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-08 20:21:35 --> Language Class Initialized
DEBUG - 2011-04-08 20:21:36 --> Loader Class Initialized
DEBUG - 2011-04-08 20:21:36 --> Controller Class Initialized
ERROR - 2011-04-08 20:21:36 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-04-08 20:21:36 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-04-08 20:21:36 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-04-08 20:21:36 --> Model Class Initialized
DEBUG - 2011-04-08 20:21:36 --> Model Class Initialized
DEBUG - 2011-04-08 20:21:36 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-08 20:21:36 --> Database Driver Class Initialized
DEBUG - 2011-04-08 20:21:36 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-04-08 20:21:36 --> Helper loaded: url_helper
DEBUG - 2011-04-08 20:21:36 --> File loaded: application/views/common/header.php
DEBUG - 2011-04-08 20:21:36 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-04-08 20:21:36 --> File loaded: application/views/common/footer.php
DEBUG - 2011-04-08 20:21:36 --> File loaded: application/views/layout/main.php
DEBUG - 2011-04-08 20:21:36 --> Final output sent to browser
DEBUG - 2011-04-08 20:21:36 --> Total execution time: 0.3638
DEBUG - 2011-04-08 20:21:36 --> Config Class Initialized
DEBUG - 2011-04-08 20:21:36 --> Hooks Class Initialized
DEBUG - 2011-04-08 20:21:36 --> Utf8 Class Initialized
DEBUG - 2011-04-08 20:21:36 --> UTF-8 Support Enabled
DEBUG - 2011-04-08 20:21:36 --> URI Class Initialized
DEBUG - 2011-04-08 20:21:36 --> Router Class Initialized
DEBUG - 2011-04-08 20:21:36 --> Output Class Initialized
DEBUG - 2011-04-08 20:21:36 --> Input Class Initialized
DEBUG - 2011-04-08 20:21:36 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-08 20:21:36 --> Language Class Initialized
DEBUG - 2011-04-08 20:21:36 --> Loader Class Initialized
DEBUG - 2011-04-08 20:21:36 --> Controller Class Initialized
DEBUG - 2011-04-08 20:21:36 --> Model Class Initialized
DEBUG - 2011-04-08 20:21:36 --> Model Class Initialized
DEBUG - 2011-04-08 20:21:36 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-08 20:21:36 --> Database Driver Class Initialized
DEBUG - 2011-04-08 20:21:37 --> Final output sent to browser
DEBUG - 2011-04-08 20:21:37 --> Total execution time: 0.6628
DEBUG - 2011-04-08 20:21:38 --> Config Class Initialized
DEBUG - 2011-04-08 20:21:38 --> Hooks Class Initialized
DEBUG - 2011-04-08 20:21:38 --> Utf8 Class Initialized
DEBUG - 2011-04-08 20:21:38 --> UTF-8 Support Enabled
DEBUG - 2011-04-08 20:21:38 --> URI Class Initialized
DEBUG - 2011-04-08 20:21:38 --> Router Class Initialized
ERROR - 2011-04-08 20:21:38 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-04-08 20:21:38 --> Config Class Initialized
DEBUG - 2011-04-08 20:21:38 --> Hooks Class Initialized
DEBUG - 2011-04-08 20:21:38 --> Utf8 Class Initialized
DEBUG - 2011-04-08 20:21:38 --> UTF-8 Support Enabled
DEBUG - 2011-04-08 20:21:38 --> URI Class Initialized
DEBUG - 2011-04-08 20:21:38 --> Router Class Initialized
ERROR - 2011-04-08 20:21:38 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-04-08 20:22:26 --> Config Class Initialized
DEBUG - 2011-04-08 20:22:26 --> Hooks Class Initialized
DEBUG - 2011-04-08 20:22:26 --> Utf8 Class Initialized
DEBUG - 2011-04-08 20:22:26 --> UTF-8 Support Enabled
DEBUG - 2011-04-08 20:22:26 --> URI Class Initialized
DEBUG - 2011-04-08 20:22:26 --> Router Class Initialized
DEBUG - 2011-04-08 20:22:26 --> Output Class Initialized
DEBUG - 2011-04-08 20:22:26 --> Input Class Initialized
DEBUG - 2011-04-08 20:22:26 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-08 20:22:26 --> Language Class Initialized
DEBUG - 2011-04-08 20:22:26 --> Loader Class Initialized
DEBUG - 2011-04-08 20:22:26 --> Controller Class Initialized
ERROR - 2011-04-08 20:22:26 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-04-08 20:22:26 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-04-08 20:22:26 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-04-08 20:22:26 --> Model Class Initialized
DEBUG - 2011-04-08 20:22:26 --> Model Class Initialized
DEBUG - 2011-04-08 20:22:26 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-08 20:22:26 --> Database Driver Class Initialized
DEBUG - 2011-04-08 20:22:26 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-04-08 20:22:26 --> Helper loaded: url_helper
DEBUG - 2011-04-08 20:22:26 --> File loaded: application/views/common/header.php
DEBUG - 2011-04-08 20:22:26 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-04-08 20:22:26 --> File loaded: application/views/common/footer.php
DEBUG - 2011-04-08 20:22:26 --> File loaded: application/views/layout/main.php
DEBUG - 2011-04-08 20:22:26 --> Final output sent to browser
DEBUG - 2011-04-08 20:22:26 --> Total execution time: 0.0383
DEBUG - 2011-04-08 20:22:26 --> Config Class Initialized
DEBUG - 2011-04-08 20:22:26 --> Hooks Class Initialized
DEBUG - 2011-04-08 20:22:26 --> Utf8 Class Initialized
DEBUG - 2011-04-08 20:22:26 --> UTF-8 Support Enabled
DEBUG - 2011-04-08 20:22:26 --> URI Class Initialized
DEBUG - 2011-04-08 20:22:26 --> Router Class Initialized
DEBUG - 2011-04-08 20:22:26 --> Output Class Initialized
DEBUG - 2011-04-08 20:22:26 --> Input Class Initialized
DEBUG - 2011-04-08 20:22:26 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-08 20:22:26 --> Language Class Initialized
DEBUG - 2011-04-08 20:22:26 --> Loader Class Initialized
DEBUG - 2011-04-08 20:22:26 --> Controller Class Initialized
DEBUG - 2011-04-08 20:22:26 --> Model Class Initialized
DEBUG - 2011-04-08 20:22:26 --> Model Class Initialized
DEBUG - 2011-04-08 20:22:26 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-08 20:22:26 --> Database Driver Class Initialized
DEBUG - 2011-04-08 20:22:27 --> Final output sent to browser
DEBUG - 2011-04-08 20:22:27 --> Total execution time: 0.5229
DEBUG - 2011-04-08 20:22:35 --> Config Class Initialized
DEBUG - 2011-04-08 20:22:35 --> Hooks Class Initialized
DEBUG - 2011-04-08 20:22:35 --> Utf8 Class Initialized
DEBUG - 2011-04-08 20:22:35 --> UTF-8 Support Enabled
DEBUG - 2011-04-08 20:22:35 --> URI Class Initialized
DEBUG - 2011-04-08 20:22:35 --> Router Class Initialized
DEBUG - 2011-04-08 20:22:35 --> Output Class Initialized
DEBUG - 2011-04-08 20:22:35 --> Input Class Initialized
DEBUG - 2011-04-08 20:22:35 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-08 20:22:35 --> Language Class Initialized
DEBUG - 2011-04-08 20:22:35 --> Loader Class Initialized
DEBUG - 2011-04-08 20:22:35 --> Controller Class Initialized
ERROR - 2011-04-08 20:22:35 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-04-08 20:22:35 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-04-08 20:22:35 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-04-08 20:22:35 --> Model Class Initialized
DEBUG - 2011-04-08 20:22:35 --> Model Class Initialized
DEBUG - 2011-04-08 20:22:35 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-08 20:22:35 --> Database Driver Class Initialized
DEBUG - 2011-04-08 20:22:35 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-04-08 20:22:35 --> Helper loaded: url_helper
DEBUG - 2011-04-08 20:22:35 --> File loaded: application/views/common/header.php
DEBUG - 2011-04-08 20:22:35 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-04-08 20:22:35 --> File loaded: application/views/common/footer.php
DEBUG - 2011-04-08 20:22:35 --> File loaded: application/views/layout/main.php
DEBUG - 2011-04-08 20:22:35 --> Final output sent to browser
DEBUG - 2011-04-08 20:22:35 --> Total execution time: 0.0281
DEBUG - 2011-04-08 20:22:36 --> Config Class Initialized
DEBUG - 2011-04-08 20:22:36 --> Hooks Class Initialized
DEBUG - 2011-04-08 20:22:36 --> Utf8 Class Initialized
DEBUG - 2011-04-08 20:22:36 --> UTF-8 Support Enabled
DEBUG - 2011-04-08 20:22:36 --> URI Class Initialized
DEBUG - 2011-04-08 20:22:36 --> Router Class Initialized
DEBUG - 2011-04-08 20:22:36 --> Output Class Initialized
DEBUG - 2011-04-08 20:22:36 --> Input Class Initialized
DEBUG - 2011-04-08 20:22:36 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-08 20:22:36 --> Language Class Initialized
DEBUG - 2011-04-08 20:22:36 --> Loader Class Initialized
DEBUG - 2011-04-08 20:22:36 --> Controller Class Initialized
DEBUG - 2011-04-08 20:22:36 --> Model Class Initialized
DEBUG - 2011-04-08 20:22:36 --> Model Class Initialized
DEBUG - 2011-04-08 20:22:36 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-08 20:22:36 --> Database Driver Class Initialized
DEBUG - 2011-04-08 20:22:36 --> Final output sent to browser
DEBUG - 2011-04-08 20:22:36 --> Total execution time: 0.7512
DEBUG - 2011-04-08 20:22:48 --> Config Class Initialized
DEBUG - 2011-04-08 20:22:48 --> Hooks Class Initialized
DEBUG - 2011-04-08 20:22:48 --> Utf8 Class Initialized
DEBUG - 2011-04-08 20:22:48 --> UTF-8 Support Enabled
DEBUG - 2011-04-08 20:22:48 --> URI Class Initialized
DEBUG - 2011-04-08 20:22:48 --> Router Class Initialized
DEBUG - 2011-04-08 20:22:48 --> Output Class Initialized
DEBUG - 2011-04-08 20:22:48 --> Input Class Initialized
DEBUG - 2011-04-08 20:22:48 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-08 20:22:48 --> Language Class Initialized
DEBUG - 2011-04-08 20:22:48 --> Loader Class Initialized
DEBUG - 2011-04-08 20:22:48 --> Controller Class Initialized
ERROR - 2011-04-08 20:22:48 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-04-08 20:22:48 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-04-08 20:22:48 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-04-08 20:22:48 --> Model Class Initialized
DEBUG - 2011-04-08 20:22:48 --> Model Class Initialized
DEBUG - 2011-04-08 20:22:48 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-08 20:22:48 --> Database Driver Class Initialized
DEBUG - 2011-04-08 20:22:48 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-04-08 20:22:48 --> Helper loaded: url_helper
DEBUG - 2011-04-08 20:22:48 --> File loaded: application/views/common/header.php
DEBUG - 2011-04-08 20:22:48 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-04-08 20:22:48 --> File loaded: application/views/common/footer.php
DEBUG - 2011-04-08 20:22:48 --> File loaded: application/views/layout/main.php
DEBUG - 2011-04-08 20:22:48 --> Final output sent to browser
DEBUG - 2011-04-08 20:22:48 --> Total execution time: 0.0583
DEBUG - 2011-04-08 20:22:48 --> Config Class Initialized
DEBUG - 2011-04-08 20:22:48 --> Hooks Class Initialized
DEBUG - 2011-04-08 20:22:48 --> Utf8 Class Initialized
DEBUG - 2011-04-08 20:22:48 --> UTF-8 Support Enabled
DEBUG - 2011-04-08 20:22:48 --> URI Class Initialized
DEBUG - 2011-04-08 20:22:48 --> Router Class Initialized
DEBUG - 2011-04-08 20:22:48 --> Output Class Initialized
DEBUG - 2011-04-08 20:22:48 --> Input Class Initialized
DEBUG - 2011-04-08 20:22:48 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-08 20:22:48 --> Language Class Initialized
DEBUG - 2011-04-08 20:22:48 --> Loader Class Initialized
DEBUG - 2011-04-08 20:22:48 --> Controller Class Initialized
DEBUG - 2011-04-08 20:22:48 --> Model Class Initialized
DEBUG - 2011-04-08 20:22:48 --> Model Class Initialized
DEBUG - 2011-04-08 20:22:48 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-08 20:22:48 --> Database Driver Class Initialized
DEBUG - 2011-04-08 20:22:49 --> Final output sent to browser
DEBUG - 2011-04-08 20:22:49 --> Total execution time: 0.6263
DEBUG - 2011-04-08 21:13:09 --> Config Class Initialized
DEBUG - 2011-04-08 21:13:09 --> Hooks Class Initialized
DEBUG - 2011-04-08 21:13:09 --> Utf8 Class Initialized
DEBUG - 2011-04-08 21:13:09 --> UTF-8 Support Enabled
DEBUG - 2011-04-08 21:13:09 --> URI Class Initialized
DEBUG - 2011-04-08 21:13:09 --> Router Class Initialized
ERROR - 2011-04-08 21:13:09 --> 404 Page Not Found --> robots.txt
DEBUG - 2011-04-08 21:14:54 --> Config Class Initialized
DEBUG - 2011-04-08 21:14:54 --> Hooks Class Initialized
DEBUG - 2011-04-08 21:14:54 --> Utf8 Class Initialized
DEBUG - 2011-04-08 21:14:54 --> UTF-8 Support Enabled
DEBUG - 2011-04-08 21:14:54 --> URI Class Initialized
DEBUG - 2011-04-08 21:14:54 --> Router Class Initialized
DEBUG - 2011-04-08 21:14:54 --> No URI present. Default controller set.
DEBUG - 2011-04-08 21:14:54 --> Output Class Initialized
DEBUG - 2011-04-08 21:14:54 --> Input Class Initialized
DEBUG - 2011-04-08 21:14:54 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-08 21:14:54 --> Language Class Initialized
DEBUG - 2011-04-08 21:14:54 --> Loader Class Initialized
DEBUG - 2011-04-08 21:14:54 --> Controller Class Initialized
DEBUG - 2011-04-08 21:14:54 --> File loaded: application/views/splash/main.php
DEBUG - 2011-04-08 21:14:54 --> Helper loaded: url_helper
DEBUG - 2011-04-08 21:14:54 --> File loaded: application/views/common/header.php
DEBUG - 2011-04-08 21:14:54 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-04-08 21:14:54 --> File loaded: application/views/common/footer.php
DEBUG - 2011-04-08 21:14:54 --> File loaded: application/views/layout/main.php
DEBUG - 2011-04-08 21:14:54 --> Final output sent to browser
DEBUG - 2011-04-08 21:14:54 --> Total execution time: 0.3864
DEBUG - 2011-04-08 23:22:42 --> Config Class Initialized
DEBUG - 2011-04-08 23:22:42 --> Hooks Class Initialized
DEBUG - 2011-04-08 23:22:42 --> Utf8 Class Initialized
DEBUG - 2011-04-08 23:22:42 --> UTF-8 Support Enabled
DEBUG - 2011-04-08 23:22:42 --> URI Class Initialized
DEBUG - 2011-04-08 23:22:42 --> Router Class Initialized
DEBUG - 2011-04-08 23:22:42 --> Output Class Initialized
DEBUG - 2011-04-08 23:22:42 --> Input Class Initialized
DEBUG - 2011-04-08 23:22:42 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-08 23:22:42 --> Language Class Initialized
DEBUG - 2011-04-08 23:22:42 --> Loader Class Initialized
DEBUG - 2011-04-08 23:22:42 --> Controller Class Initialized
ERROR - 2011-04-08 23:22:43 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-04-08 23:22:43 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-04-08 23:22:43 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-04-08 23:22:43 --> Model Class Initialized
DEBUG - 2011-04-08 23:22:43 --> Model Class Initialized
DEBUG - 2011-04-08 23:22:43 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-08 23:22:43 --> Database Driver Class Initialized
DEBUG - 2011-04-08 23:22:43 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-04-08 23:22:43 --> Helper loaded: url_helper
DEBUG - 2011-04-08 23:22:43 --> File loaded: application/views/common/header.php
DEBUG - 2011-04-08 23:22:43 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-04-08 23:22:43 --> File loaded: application/views/common/footer.php
DEBUG - 2011-04-08 23:22:43 --> File loaded: application/views/layout/main.php
DEBUG - 2011-04-08 23:22:43 --> Final output sent to browser
DEBUG - 2011-04-08 23:22:43 --> Total execution time: 0.3161
DEBUG - 2011-04-08 23:22:46 --> Config Class Initialized
DEBUG - 2011-04-08 23:22:46 --> Hooks Class Initialized
DEBUG - 2011-04-08 23:22:46 --> Utf8 Class Initialized
DEBUG - 2011-04-08 23:22:46 --> UTF-8 Support Enabled
DEBUG - 2011-04-08 23:22:46 --> URI Class Initialized
DEBUG - 2011-04-08 23:22:46 --> Router Class Initialized
DEBUG - 2011-04-08 23:22:46 --> Output Class Initialized
DEBUG - 2011-04-08 23:22:46 --> Input Class Initialized
DEBUG - 2011-04-08 23:22:46 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-08 23:22:46 --> Language Class Initialized
DEBUG - 2011-04-08 23:22:46 --> Loader Class Initialized
DEBUG - 2011-04-08 23:22:46 --> Controller Class Initialized
DEBUG - 2011-04-08 23:22:46 --> Model Class Initialized
DEBUG - 2011-04-08 23:22:46 --> Model Class Initialized
DEBUG - 2011-04-08 23:22:46 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-08 23:22:46 --> Database Driver Class Initialized
DEBUG - 2011-04-08 23:22:46 --> Final output sent to browser
DEBUG - 2011-04-08 23:22:46 --> Total execution time: 0.7145
DEBUG - 2011-04-08 23:22:51 --> Config Class Initialized
DEBUG - 2011-04-08 23:22:51 --> Hooks Class Initialized
DEBUG - 2011-04-08 23:22:51 --> Utf8 Class Initialized
DEBUG - 2011-04-08 23:22:51 --> UTF-8 Support Enabled
DEBUG - 2011-04-08 23:22:51 --> URI Class Initialized
DEBUG - 2011-04-08 23:22:51 --> Router Class Initialized
ERROR - 2011-04-08 23:22:51 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-04-08 23:23:06 --> Config Class Initialized
DEBUG - 2011-04-08 23:23:06 --> Hooks Class Initialized
DEBUG - 2011-04-08 23:23:06 --> Utf8 Class Initialized
DEBUG - 2011-04-08 23:23:06 --> UTF-8 Support Enabled
DEBUG - 2011-04-08 23:23:06 --> URI Class Initialized
DEBUG - 2011-04-08 23:23:06 --> Router Class Initialized
DEBUG - 2011-04-08 23:23:06 --> Output Class Initialized
DEBUG - 2011-04-08 23:23:06 --> Input Class Initialized
DEBUG - 2011-04-08 23:23:06 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-08 23:23:06 --> Language Class Initialized
DEBUG - 2011-04-08 23:23:06 --> Loader Class Initialized
DEBUG - 2011-04-08 23:23:06 --> Controller Class Initialized
ERROR - 2011-04-08 23:23:06 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-04-08 23:23:06 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-04-08 23:23:06 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-04-08 23:23:06 --> Model Class Initialized
DEBUG - 2011-04-08 23:23:06 --> Model Class Initialized
DEBUG - 2011-04-08 23:23:06 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-08 23:23:06 --> Database Driver Class Initialized
DEBUG - 2011-04-08 23:23:06 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-04-08 23:23:06 --> Helper loaded: url_helper
DEBUG - 2011-04-08 23:23:06 --> File loaded: application/views/common/header.php
DEBUG - 2011-04-08 23:23:06 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-04-08 23:23:06 --> File loaded: application/views/common/footer.php
DEBUG - 2011-04-08 23:23:06 --> File loaded: application/views/layout/main.php
DEBUG - 2011-04-08 23:23:06 --> Final output sent to browser
DEBUG - 2011-04-08 23:23:06 --> Total execution time: 0.0270
DEBUG - 2011-04-08 23:23:06 --> Config Class Initialized
DEBUG - 2011-04-08 23:23:06 --> Hooks Class Initialized
DEBUG - 2011-04-08 23:23:06 --> Utf8 Class Initialized
DEBUG - 2011-04-08 23:23:06 --> UTF-8 Support Enabled
DEBUG - 2011-04-08 23:23:06 --> URI Class Initialized
DEBUG - 2011-04-08 23:23:06 --> Router Class Initialized
DEBUG - 2011-04-08 23:23:06 --> Output Class Initialized
DEBUG - 2011-04-08 23:23:06 --> Input Class Initialized
DEBUG - 2011-04-08 23:23:06 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-08 23:23:06 --> Language Class Initialized
DEBUG - 2011-04-08 23:23:06 --> Loader Class Initialized
DEBUG - 2011-04-08 23:23:06 --> Controller Class Initialized
DEBUG - 2011-04-08 23:23:06 --> Model Class Initialized
DEBUG - 2011-04-08 23:23:06 --> Model Class Initialized
DEBUG - 2011-04-08 23:23:06 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-08 23:23:06 --> Database Driver Class Initialized
DEBUG - 2011-04-08 23:23:07 --> Final output sent to browser
DEBUG - 2011-04-08 23:23:07 --> Total execution time: 0.5841
DEBUG - 2011-04-08 23:23:09 --> Config Class Initialized
DEBUG - 2011-04-08 23:23:09 --> Hooks Class Initialized
DEBUG - 2011-04-08 23:23:09 --> Utf8 Class Initialized
DEBUG - 2011-04-08 23:23:09 --> UTF-8 Support Enabled
DEBUG - 2011-04-08 23:23:09 --> URI Class Initialized
DEBUG - 2011-04-08 23:23:09 --> Router Class Initialized
ERROR - 2011-04-08 23:23:09 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-04-08 23:54:36 --> Config Class Initialized
DEBUG - 2011-04-08 23:54:36 --> Hooks Class Initialized
DEBUG - 2011-04-08 23:54:36 --> Utf8 Class Initialized
DEBUG - 2011-04-08 23:54:36 --> UTF-8 Support Enabled
DEBUG - 2011-04-08 23:54:36 --> URI Class Initialized
DEBUG - 2011-04-08 23:54:36 --> Router Class Initialized
DEBUG - 2011-04-08 23:54:36 --> Output Class Initialized
DEBUG - 2011-04-08 23:54:36 --> Input Class Initialized
DEBUG - 2011-04-08 23:54:36 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-08 23:54:36 --> Language Class Initialized
DEBUG - 2011-04-08 23:54:36 --> Loader Class Initialized
DEBUG - 2011-04-08 23:54:36 --> Controller Class Initialized
ERROR - 2011-04-08 23:54:36 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-04-08 23:54:36 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-04-08 23:54:36 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-04-08 23:54:36 --> Model Class Initialized
DEBUG - 2011-04-08 23:54:36 --> Model Class Initialized
DEBUG - 2011-04-08 23:54:36 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-08 23:54:36 --> Database Driver Class Initialized
DEBUG - 2011-04-08 23:54:36 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-04-08 23:54:36 --> Helper loaded: url_helper
DEBUG - 2011-04-08 23:54:36 --> File loaded: application/views/common/header.php
DEBUG - 2011-04-08 23:54:36 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-04-08 23:54:36 --> File loaded: application/views/common/footer.php
DEBUG - 2011-04-08 23:54:36 --> File loaded: application/views/layout/main.php
DEBUG - 2011-04-08 23:54:36 --> Final output sent to browser
DEBUG - 2011-04-08 23:54:36 --> Total execution time: 0.0298
DEBUG - 2011-04-08 23:54:37 --> Config Class Initialized
DEBUG - 2011-04-08 23:54:37 --> Hooks Class Initialized
DEBUG - 2011-04-08 23:54:37 --> Utf8 Class Initialized
DEBUG - 2011-04-08 23:54:37 --> UTF-8 Support Enabled
DEBUG - 2011-04-08 23:54:37 --> URI Class Initialized
DEBUG - 2011-04-08 23:54:37 --> Router Class Initialized
DEBUG - 2011-04-08 23:54:37 --> Output Class Initialized
DEBUG - 2011-04-08 23:54:37 --> Input Class Initialized
DEBUG - 2011-04-08 23:54:37 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-08 23:54:37 --> Language Class Initialized
DEBUG - 2011-04-08 23:54:37 --> Loader Class Initialized
DEBUG - 2011-04-08 23:54:37 --> Controller Class Initialized
DEBUG - 2011-04-08 23:54:37 --> Model Class Initialized
DEBUG - 2011-04-08 23:54:37 --> Model Class Initialized
DEBUG - 2011-04-08 23:54:37 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-08 23:54:37 --> Database Driver Class Initialized
DEBUG - 2011-04-08 23:54:37 --> Final output sent to browser
DEBUG - 2011-04-08 23:54:37 --> Total execution time: 0.6578
DEBUG - 2011-04-08 23:54:38 --> Config Class Initialized
DEBUG - 2011-04-08 23:54:38 --> Hooks Class Initialized
DEBUG - 2011-04-08 23:54:38 --> Utf8 Class Initialized
DEBUG - 2011-04-08 23:54:38 --> UTF-8 Support Enabled
DEBUG - 2011-04-08 23:54:38 --> URI Class Initialized
DEBUG - 2011-04-08 23:54:38 --> Router Class Initialized
ERROR - 2011-04-08 23:54:38 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-04-08 23:54:39 --> Config Class Initialized
DEBUG - 2011-04-08 23:54:39 --> Hooks Class Initialized
DEBUG - 2011-04-08 23:54:39 --> Utf8 Class Initialized
DEBUG - 2011-04-08 23:54:39 --> UTF-8 Support Enabled
DEBUG - 2011-04-08 23:54:39 --> URI Class Initialized
DEBUG - 2011-04-08 23:54:39 --> Router Class Initialized
ERROR - 2011-04-08 23:54:39 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-04-08 23:54:49 --> Config Class Initialized
DEBUG - 2011-04-08 23:54:49 --> Hooks Class Initialized
DEBUG - 2011-04-08 23:54:49 --> Utf8 Class Initialized
DEBUG - 2011-04-08 23:54:49 --> UTF-8 Support Enabled
DEBUG - 2011-04-08 23:54:49 --> URI Class Initialized
DEBUG - 2011-04-08 23:54:49 --> Router Class Initialized
DEBUG - 2011-04-08 23:54:49 --> No URI present. Default controller set.
DEBUG - 2011-04-08 23:54:49 --> Output Class Initialized
DEBUG - 2011-04-08 23:54:49 --> Input Class Initialized
DEBUG - 2011-04-08 23:54:49 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-08 23:54:49 --> Language Class Initialized
DEBUG - 2011-04-08 23:54:49 --> Loader Class Initialized
DEBUG - 2011-04-08 23:54:49 --> Controller Class Initialized
DEBUG - 2011-04-08 23:54:49 --> File loaded: application/views/splash/main.php
DEBUG - 2011-04-08 23:54:49 --> Helper loaded: url_helper
DEBUG - 2011-04-08 23:54:49 --> File loaded: application/views/common/header.php
DEBUG - 2011-04-08 23:54:49 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-04-08 23:54:49 --> File loaded: application/views/common/footer.php
DEBUG - 2011-04-08 23:54:49 --> File loaded: application/views/layout/main.php
DEBUG - 2011-04-08 23:54:49 --> Final output sent to browser
DEBUG - 2011-04-08 23:54:49 --> Total execution time: 0.0953
DEBUG - 2011-04-08 23:54:52 --> Config Class Initialized
DEBUG - 2011-04-08 23:54:52 --> Hooks Class Initialized
DEBUG - 2011-04-08 23:54:52 --> Utf8 Class Initialized
DEBUG - 2011-04-08 23:54:52 --> UTF-8 Support Enabled
DEBUG - 2011-04-08 23:54:52 --> URI Class Initialized
DEBUG - 2011-04-08 23:54:52 --> Router Class Initialized
DEBUG - 2011-04-08 23:54:52 --> Output Class Initialized
DEBUG - 2011-04-08 23:54:52 --> Input Class Initialized
DEBUG - 2011-04-08 23:54:52 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-08 23:54:52 --> Language Class Initialized
DEBUG - 2011-04-08 23:54:52 --> Loader Class Initialized
DEBUG - 2011-04-08 23:54:52 --> Controller Class Initialized
DEBUG - 2011-04-08 23:54:52 --> Model Class Initialized
DEBUG - 2011-04-08 23:54:52 --> Model Class Initialized
DEBUG - 2011-04-08 23:54:52 --> Model Class Initialized
DEBUG - 2011-04-08 23:54:52 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-08 23:54:52 --> Database Driver Class Initialized
DEBUG - 2011-04-08 23:54:53 --> File loaded: application/views/table/main.php
DEBUG - 2011-04-08 23:54:53 --> Helper loaded: url_helper
DEBUG - 2011-04-08 23:54:53 --> File loaded: application/views/common/header.php
DEBUG - 2011-04-08 23:54:53 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-04-08 23:54:53 --> File loaded: application/views/common/footer.php
DEBUG - 2011-04-08 23:54:53 --> File loaded: application/views/layout/main.php
DEBUG - 2011-04-08 23:54:53 --> Final output sent to browser
DEBUG - 2011-04-08 23:54:53 --> Total execution time: 0.2543
DEBUG - 2011-04-08 23:54:54 --> Config Class Initialized
DEBUG - 2011-04-08 23:54:54 --> Hooks Class Initialized
DEBUG - 2011-04-08 23:54:54 --> Utf8 Class Initialized
DEBUG - 2011-04-08 23:54:54 --> UTF-8 Support Enabled
DEBUG - 2011-04-08 23:54:54 --> URI Class Initialized
DEBUG - 2011-04-08 23:54:54 --> Router Class Initialized
DEBUG - 2011-04-08 23:54:54 --> Output Class Initialized
DEBUG - 2011-04-08 23:54:54 --> Input Class Initialized
DEBUG - 2011-04-08 23:54:54 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-08 23:54:54 --> Language Class Initialized
DEBUG - 2011-04-08 23:54:54 --> Loader Class Initialized
DEBUG - 2011-04-08 23:54:54 --> Controller Class Initialized
DEBUG - 2011-04-08 23:54:54 --> Model Class Initialized
DEBUG - 2011-04-08 23:54:54 --> Model Class Initialized
DEBUG - 2011-04-08 23:54:54 --> Model Class Initialized
DEBUG - 2011-04-08 23:54:54 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-08 23:54:54 --> Database Driver Class Initialized
DEBUG - 2011-04-08 23:54:54 --> File loaded: application/views/table/main.php
DEBUG - 2011-04-08 23:54:54 --> Helper loaded: url_helper
DEBUG - 2011-04-08 23:54:54 --> File loaded: application/views/common/header.php
DEBUG - 2011-04-08 23:54:54 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-04-08 23:54:54 --> File loaded: application/views/common/footer.php
DEBUG - 2011-04-08 23:54:54 --> File loaded: application/views/layout/main.php
DEBUG - 2011-04-08 23:54:54 --> Final output sent to browser
DEBUG - 2011-04-08 23:54:54 --> Total execution time: 0.0545
DEBUG - 2011-04-08 23:55:17 --> Config Class Initialized
DEBUG - 2011-04-08 23:55:17 --> Hooks Class Initialized
DEBUG - 2011-04-08 23:55:17 --> Utf8 Class Initialized
DEBUG - 2011-04-08 23:55:17 --> UTF-8 Support Enabled
DEBUG - 2011-04-08 23:55:17 --> URI Class Initialized
DEBUG - 2011-04-08 23:55:17 --> Router Class Initialized
DEBUG - 2011-04-08 23:55:17 --> Output Class Initialized
DEBUG - 2011-04-08 23:55:17 --> Input Class Initialized
DEBUG - 2011-04-08 23:55:17 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-08 23:55:17 --> Language Class Initialized
DEBUG - 2011-04-08 23:55:17 --> Loader Class Initialized
DEBUG - 2011-04-08 23:55:17 --> Controller Class Initialized
ERROR - 2011-04-08 23:55:17 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-04-08 23:55:17 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-04-08 23:55:17 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-04-08 23:55:17 --> Model Class Initialized
DEBUG - 2011-04-08 23:55:17 --> Model Class Initialized
DEBUG - 2011-04-08 23:55:17 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-08 23:55:17 --> Database Driver Class Initialized
DEBUG - 2011-04-08 23:55:17 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-04-08 23:55:17 --> Helper loaded: url_helper
DEBUG - 2011-04-08 23:55:17 --> File loaded: application/views/common/header.php
DEBUG - 2011-04-08 23:55:17 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-04-08 23:55:17 --> File loaded: application/views/common/footer.php
DEBUG - 2011-04-08 23:55:17 --> File loaded: application/views/layout/main.php
DEBUG - 2011-04-08 23:55:17 --> Final output sent to browser
DEBUG - 2011-04-08 23:55:17 --> Total execution time: 0.0332
DEBUG - 2011-04-08 23:55:17 --> Config Class Initialized
DEBUG - 2011-04-08 23:55:17 --> Hooks Class Initialized
DEBUG - 2011-04-08 23:55:17 --> Utf8 Class Initialized
DEBUG - 2011-04-08 23:55:17 --> UTF-8 Support Enabled
DEBUG - 2011-04-08 23:55:17 --> URI Class Initialized
DEBUG - 2011-04-08 23:55:17 --> Router Class Initialized
DEBUG - 2011-04-08 23:55:17 --> Output Class Initialized
DEBUG - 2011-04-08 23:55:17 --> Input Class Initialized
DEBUG - 2011-04-08 23:55:17 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-08 23:55:17 --> Language Class Initialized
DEBUG - 2011-04-08 23:55:17 --> Loader Class Initialized
DEBUG - 2011-04-08 23:55:17 --> Controller Class Initialized
DEBUG - 2011-04-08 23:55:17 --> Model Class Initialized
DEBUG - 2011-04-08 23:55:17 --> Model Class Initialized
DEBUG - 2011-04-08 23:55:17 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-08 23:55:17 --> Database Driver Class Initialized
DEBUG - 2011-04-08 23:55:18 --> Final output sent to browser
DEBUG - 2011-04-08 23:55:18 --> Total execution time: 0.5437
DEBUG - 2011-04-08 23:55:45 --> Config Class Initialized
DEBUG - 2011-04-08 23:55:45 --> Hooks Class Initialized
DEBUG - 2011-04-08 23:55:45 --> Utf8 Class Initialized
DEBUG - 2011-04-08 23:55:45 --> UTF-8 Support Enabled
DEBUG - 2011-04-08 23:55:45 --> URI Class Initialized
DEBUG - 2011-04-08 23:55:45 --> Router Class Initialized
DEBUG - 2011-04-08 23:55:45 --> Output Class Initialized
DEBUG - 2011-04-08 23:55:45 --> Input Class Initialized
DEBUG - 2011-04-08 23:55:45 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-08 23:55:45 --> Language Class Initialized
DEBUG - 2011-04-08 23:55:45 --> Loader Class Initialized
DEBUG - 2011-04-08 23:55:45 --> Controller Class Initialized
ERROR - 2011-04-08 23:55:45 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-04-08 23:55:45 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-04-08 23:55:45 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-04-08 23:55:45 --> Model Class Initialized
DEBUG - 2011-04-08 23:55:45 --> Model Class Initialized
DEBUG - 2011-04-08 23:55:45 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-08 23:55:45 --> Database Driver Class Initialized
DEBUG - 2011-04-08 23:55:45 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-04-08 23:55:45 --> Helper loaded: url_helper
DEBUG - 2011-04-08 23:55:45 --> File loaded: application/views/common/header.php
DEBUG - 2011-04-08 23:55:45 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-04-08 23:55:45 --> File loaded: application/views/common/footer.php
DEBUG - 2011-04-08 23:55:45 --> File loaded: application/views/layout/main.php
DEBUG - 2011-04-08 23:55:45 --> Final output sent to browser
DEBUG - 2011-04-08 23:55:45 --> Total execution time: 0.0276
DEBUG - 2011-04-08 23:55:45 --> Config Class Initialized
DEBUG - 2011-04-08 23:55:45 --> Hooks Class Initialized
DEBUG - 2011-04-08 23:55:45 --> Utf8 Class Initialized
DEBUG - 2011-04-08 23:55:45 --> UTF-8 Support Enabled
DEBUG - 2011-04-08 23:55:45 --> URI Class Initialized
DEBUG - 2011-04-08 23:55:45 --> Router Class Initialized
DEBUG - 2011-04-08 23:55:45 --> Output Class Initialized
DEBUG - 2011-04-08 23:55:45 --> Input Class Initialized
DEBUG - 2011-04-08 23:55:45 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-08 23:55:45 --> Language Class Initialized
DEBUG - 2011-04-08 23:55:45 --> Loader Class Initialized
DEBUG - 2011-04-08 23:55:45 --> Controller Class Initialized
DEBUG - 2011-04-08 23:55:45 --> Model Class Initialized
DEBUG - 2011-04-08 23:55:45 --> Model Class Initialized
DEBUG - 2011-04-08 23:55:45 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-08 23:55:45 --> Database Driver Class Initialized
DEBUG - 2011-04-08 23:55:46 --> Final output sent to browser
DEBUG - 2011-04-08 23:55:46 --> Total execution time: 0.5029
DEBUG - 2011-04-08 23:55:58 --> Config Class Initialized
DEBUG - 2011-04-08 23:55:58 --> Hooks Class Initialized
DEBUG - 2011-04-08 23:55:58 --> Utf8 Class Initialized
DEBUG - 2011-04-08 23:55:58 --> UTF-8 Support Enabled
DEBUG - 2011-04-08 23:55:58 --> URI Class Initialized
DEBUG - 2011-04-08 23:55:58 --> Router Class Initialized
DEBUG - 2011-04-08 23:55:58 --> Output Class Initialized
DEBUG - 2011-04-08 23:55:58 --> Input Class Initialized
DEBUG - 2011-04-08 23:55:58 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-08 23:55:58 --> Language Class Initialized
DEBUG - 2011-04-08 23:55:58 --> Loader Class Initialized
DEBUG - 2011-04-08 23:55:58 --> Controller Class Initialized
ERROR - 2011-04-08 23:55:58 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-04-08 23:55:58 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-04-08 23:55:58 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-04-08 23:55:58 --> Model Class Initialized
DEBUG - 2011-04-08 23:55:58 --> Model Class Initialized
DEBUG - 2011-04-08 23:55:58 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-08 23:55:58 --> Database Driver Class Initialized
DEBUG - 2011-04-08 23:55:58 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-04-08 23:55:58 --> Helper loaded: url_helper
DEBUG - 2011-04-08 23:55:58 --> File loaded: application/views/common/header.php
DEBUG - 2011-04-08 23:55:58 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-04-08 23:55:58 --> File loaded: application/views/common/footer.php
DEBUG - 2011-04-08 23:55:58 --> File loaded: application/views/layout/main.php
DEBUG - 2011-04-08 23:55:58 --> Final output sent to browser
DEBUG - 2011-04-08 23:55:58 --> Total execution time: 0.0281
DEBUG - 2011-04-08 23:55:59 --> Config Class Initialized
DEBUG - 2011-04-08 23:55:59 --> Hooks Class Initialized
DEBUG - 2011-04-08 23:55:59 --> Utf8 Class Initialized
DEBUG - 2011-04-08 23:55:59 --> UTF-8 Support Enabled
DEBUG - 2011-04-08 23:55:59 --> URI Class Initialized
DEBUG - 2011-04-08 23:55:59 --> Router Class Initialized
DEBUG - 2011-04-08 23:55:59 --> Output Class Initialized
DEBUG - 2011-04-08 23:55:59 --> Input Class Initialized
DEBUG - 2011-04-08 23:55:59 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-08 23:55:59 --> Language Class Initialized
DEBUG - 2011-04-08 23:55:59 --> Loader Class Initialized
DEBUG - 2011-04-08 23:55:59 --> Controller Class Initialized
DEBUG - 2011-04-08 23:55:59 --> Model Class Initialized
DEBUG - 2011-04-08 23:55:59 --> Model Class Initialized
DEBUG - 2011-04-08 23:55:59 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-08 23:55:59 --> Database Driver Class Initialized
DEBUG - 2011-04-08 23:55:59 --> Final output sent to browser
DEBUG - 2011-04-08 23:55:59 --> Total execution time: 0.6759
DEBUG - 2011-04-08 23:56:05 --> Config Class Initialized
DEBUG - 2011-04-08 23:56:05 --> Hooks Class Initialized
DEBUG - 2011-04-08 23:56:05 --> Utf8 Class Initialized
DEBUG - 2011-04-08 23:56:05 --> UTF-8 Support Enabled
DEBUG - 2011-04-08 23:56:05 --> URI Class Initialized
DEBUG - 2011-04-08 23:56:05 --> Router Class Initialized
DEBUG - 2011-04-08 23:56:05 --> Output Class Initialized
DEBUG - 2011-04-08 23:56:05 --> Input Class Initialized
DEBUG - 2011-04-08 23:56:05 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-08 23:56:05 --> Language Class Initialized
DEBUG - 2011-04-08 23:56:05 --> Loader Class Initialized
DEBUG - 2011-04-08 23:56:05 --> Controller Class Initialized
ERROR - 2011-04-08 23:56:05 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-04-08 23:56:05 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-04-08 23:56:05 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-04-08 23:56:05 --> Model Class Initialized
DEBUG - 2011-04-08 23:56:05 --> Model Class Initialized
DEBUG - 2011-04-08 23:56:05 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-08 23:56:05 --> Database Driver Class Initialized
DEBUG - 2011-04-08 23:56:05 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-04-08 23:56:05 --> Helper loaded: url_helper
DEBUG - 2011-04-08 23:56:05 --> File loaded: application/views/common/header.php
DEBUG - 2011-04-08 23:56:05 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-04-08 23:56:05 --> File loaded: application/views/common/footer.php
DEBUG - 2011-04-08 23:56:05 --> File loaded: application/views/layout/main.php
DEBUG - 2011-04-08 23:56:05 --> Final output sent to browser
DEBUG - 2011-04-08 23:56:05 --> Total execution time: 0.0296
DEBUG - 2011-04-08 23:56:05 --> Config Class Initialized
DEBUG - 2011-04-08 23:56:05 --> Hooks Class Initialized
DEBUG - 2011-04-08 23:56:05 --> Utf8 Class Initialized
DEBUG - 2011-04-08 23:56:05 --> UTF-8 Support Enabled
DEBUG - 2011-04-08 23:56:05 --> URI Class Initialized
DEBUG - 2011-04-08 23:56:05 --> Router Class Initialized
DEBUG - 2011-04-08 23:56:05 --> Output Class Initialized
DEBUG - 2011-04-08 23:56:05 --> Input Class Initialized
DEBUG - 2011-04-08 23:56:05 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-08 23:56:05 --> Language Class Initialized
DEBUG - 2011-04-08 23:56:05 --> Loader Class Initialized
DEBUG - 2011-04-08 23:56:05 --> Controller Class Initialized
DEBUG - 2011-04-08 23:56:05 --> Model Class Initialized
DEBUG - 2011-04-08 23:56:05 --> Model Class Initialized
DEBUG - 2011-04-08 23:56:05 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-08 23:56:05 --> Database Driver Class Initialized
DEBUG - 2011-04-08 23:56:06 --> Final output sent to browser
DEBUG - 2011-04-08 23:56:06 --> Total execution time: 0.4924
DEBUG - 2011-04-08 23:56:16 --> Config Class Initialized
DEBUG - 2011-04-08 23:56:16 --> Hooks Class Initialized
DEBUG - 2011-04-08 23:56:16 --> Utf8 Class Initialized
DEBUG - 2011-04-08 23:56:16 --> UTF-8 Support Enabled
DEBUG - 2011-04-08 23:56:16 --> URI Class Initialized
DEBUG - 2011-04-08 23:56:16 --> Router Class Initialized
DEBUG - 2011-04-08 23:56:16 --> Output Class Initialized
DEBUG - 2011-04-08 23:56:16 --> Input Class Initialized
DEBUG - 2011-04-08 23:56:16 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-08 23:56:16 --> Language Class Initialized
DEBUG - 2011-04-08 23:56:16 --> Loader Class Initialized
DEBUG - 2011-04-08 23:56:16 --> Controller Class Initialized
ERROR - 2011-04-08 23:56:16 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-04-08 23:56:16 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-04-08 23:56:16 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-04-08 23:56:16 --> Model Class Initialized
DEBUG - 2011-04-08 23:56:16 --> Model Class Initialized
DEBUG - 2011-04-08 23:56:16 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-08 23:56:16 --> Database Driver Class Initialized
DEBUG - 2011-04-08 23:56:16 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-04-08 23:56:16 --> Helper loaded: url_helper
DEBUG - 2011-04-08 23:56:16 --> File loaded: application/views/common/header.php
DEBUG - 2011-04-08 23:56:16 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-04-08 23:56:16 --> File loaded: application/views/common/footer.php
DEBUG - 2011-04-08 23:56:16 --> File loaded: application/views/layout/main.php
DEBUG - 2011-04-08 23:56:16 --> Final output sent to browser
DEBUG - 2011-04-08 23:56:16 --> Total execution time: 0.0367
DEBUG - 2011-04-08 23:56:16 --> Config Class Initialized
DEBUG - 2011-04-08 23:56:16 --> Hooks Class Initialized
DEBUG - 2011-04-08 23:56:16 --> Utf8 Class Initialized
DEBUG - 2011-04-08 23:56:16 --> UTF-8 Support Enabled
DEBUG - 2011-04-08 23:56:16 --> URI Class Initialized
DEBUG - 2011-04-08 23:56:16 --> Router Class Initialized
DEBUG - 2011-04-08 23:56:16 --> Output Class Initialized
DEBUG - 2011-04-08 23:56:16 --> Input Class Initialized
DEBUG - 2011-04-08 23:56:16 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-08 23:56:16 --> Language Class Initialized
DEBUG - 2011-04-08 23:56:16 --> Loader Class Initialized
DEBUG - 2011-04-08 23:56:16 --> Controller Class Initialized
DEBUG - 2011-04-08 23:56:16 --> Model Class Initialized
DEBUG - 2011-04-08 23:56:16 --> Model Class Initialized
DEBUG - 2011-04-08 23:56:16 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-08 23:56:16 --> Database Driver Class Initialized
DEBUG - 2011-04-08 23:56:16 --> Final output sent to browser
DEBUG - 2011-04-08 23:56:16 --> Total execution time: 0.5537
DEBUG - 2011-04-08 23:56:25 --> Config Class Initialized
DEBUG - 2011-04-08 23:56:25 --> Hooks Class Initialized
DEBUG - 2011-04-08 23:56:25 --> Utf8 Class Initialized
DEBUG - 2011-04-08 23:56:25 --> UTF-8 Support Enabled
DEBUG - 2011-04-08 23:56:25 --> URI Class Initialized
DEBUG - 2011-04-08 23:56:25 --> Router Class Initialized
DEBUG - 2011-04-08 23:56:25 --> Output Class Initialized
DEBUG - 2011-04-08 23:56:25 --> Input Class Initialized
DEBUG - 2011-04-08 23:56:25 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-08 23:56:25 --> Language Class Initialized
DEBUG - 2011-04-08 23:56:25 --> Loader Class Initialized
DEBUG - 2011-04-08 23:56:25 --> Controller Class Initialized
ERROR - 2011-04-08 23:56:25 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-04-08 23:56:25 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-04-08 23:56:25 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-04-08 23:56:25 --> Model Class Initialized
DEBUG - 2011-04-08 23:56:25 --> Model Class Initialized
DEBUG - 2011-04-08 23:56:25 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-08 23:56:25 --> Database Driver Class Initialized
DEBUG - 2011-04-08 23:56:25 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-04-08 23:56:25 --> Helper loaded: url_helper
DEBUG - 2011-04-08 23:56:25 --> File loaded: application/views/common/header.php
DEBUG - 2011-04-08 23:56:25 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-04-08 23:56:25 --> File loaded: application/views/common/footer.php
DEBUG - 2011-04-08 23:56:25 --> File loaded: application/views/layout/main.php
DEBUG - 2011-04-08 23:56:25 --> Final output sent to browser
DEBUG - 2011-04-08 23:56:25 --> Total execution time: 0.0284
DEBUG - 2011-04-08 23:56:25 --> Config Class Initialized
DEBUG - 2011-04-08 23:56:25 --> Hooks Class Initialized
DEBUG - 2011-04-08 23:56:25 --> Utf8 Class Initialized
DEBUG - 2011-04-08 23:56:25 --> UTF-8 Support Enabled
DEBUG - 2011-04-08 23:56:25 --> URI Class Initialized
DEBUG - 2011-04-08 23:56:25 --> Router Class Initialized
DEBUG - 2011-04-08 23:56:25 --> Output Class Initialized
DEBUG - 2011-04-08 23:56:25 --> Input Class Initialized
DEBUG - 2011-04-08 23:56:25 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-08 23:56:25 --> Language Class Initialized
DEBUG - 2011-04-08 23:56:25 --> Loader Class Initialized
DEBUG - 2011-04-08 23:56:25 --> Controller Class Initialized
DEBUG - 2011-04-08 23:56:25 --> Model Class Initialized
DEBUG - 2011-04-08 23:56:25 --> Model Class Initialized
DEBUG - 2011-04-08 23:56:25 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-08 23:56:25 --> Database Driver Class Initialized
DEBUG - 2011-04-08 23:56:26 --> Final output sent to browser
DEBUG - 2011-04-08 23:56:26 --> Total execution time: 0.5586
DEBUG - 2011-04-08 23:56:32 --> Config Class Initialized
DEBUG - 2011-04-08 23:56:32 --> Hooks Class Initialized
DEBUG - 2011-04-08 23:56:32 --> Utf8 Class Initialized
DEBUG - 2011-04-08 23:56:32 --> UTF-8 Support Enabled
DEBUG - 2011-04-08 23:56:32 --> URI Class Initialized
DEBUG - 2011-04-08 23:56:32 --> Router Class Initialized
DEBUG - 2011-04-08 23:56:32 --> Output Class Initialized
DEBUG - 2011-04-08 23:56:32 --> Input Class Initialized
DEBUG - 2011-04-08 23:56:32 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-08 23:56:32 --> Language Class Initialized
DEBUG - 2011-04-08 23:56:32 --> Loader Class Initialized
DEBUG - 2011-04-08 23:56:32 --> Controller Class Initialized
ERROR - 2011-04-08 23:56:32 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-04-08 23:56:32 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-04-08 23:56:32 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-04-08 23:56:32 --> Model Class Initialized
DEBUG - 2011-04-08 23:56:32 --> Model Class Initialized
DEBUG - 2011-04-08 23:56:32 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-08 23:56:32 --> Database Driver Class Initialized
DEBUG - 2011-04-08 23:56:32 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-04-08 23:56:32 --> Helper loaded: url_helper
DEBUG - 2011-04-08 23:56:32 --> File loaded: application/views/common/header.php
DEBUG - 2011-04-08 23:56:32 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-04-08 23:56:32 --> File loaded: application/views/common/footer.php
DEBUG - 2011-04-08 23:56:32 --> File loaded: application/views/layout/main.php
DEBUG - 2011-04-08 23:56:32 --> Final output sent to browser
DEBUG - 2011-04-08 23:56:32 --> Total execution time: 0.0272
DEBUG - 2011-04-08 23:56:32 --> Config Class Initialized
DEBUG - 2011-04-08 23:56:32 --> Hooks Class Initialized
DEBUG - 2011-04-08 23:56:32 --> Utf8 Class Initialized
DEBUG - 2011-04-08 23:56:32 --> UTF-8 Support Enabled
DEBUG - 2011-04-08 23:56:32 --> URI Class Initialized
DEBUG - 2011-04-08 23:56:32 --> Router Class Initialized
DEBUG - 2011-04-08 23:56:32 --> Output Class Initialized
DEBUG - 2011-04-08 23:56:32 --> Input Class Initialized
DEBUG - 2011-04-08 23:56:32 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-08 23:56:32 --> Language Class Initialized
DEBUG - 2011-04-08 23:56:32 --> Loader Class Initialized
DEBUG - 2011-04-08 23:56:32 --> Controller Class Initialized
DEBUG - 2011-04-08 23:56:32 --> Model Class Initialized
DEBUG - 2011-04-08 23:56:32 --> Model Class Initialized
DEBUG - 2011-04-08 23:56:32 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-08 23:56:32 --> Database Driver Class Initialized
DEBUG - 2011-04-08 23:56:33 --> Final output sent to browser
DEBUG - 2011-04-08 23:56:33 --> Total execution time: 0.5136
DEBUG - 2011-04-08 23:56:38 --> Config Class Initialized
DEBUG - 2011-04-08 23:56:38 --> Hooks Class Initialized
DEBUG - 2011-04-08 23:56:38 --> Utf8 Class Initialized
DEBUG - 2011-04-08 23:56:38 --> UTF-8 Support Enabled
DEBUG - 2011-04-08 23:56:38 --> URI Class Initialized
DEBUG - 2011-04-08 23:56:38 --> Router Class Initialized
DEBUG - 2011-04-08 23:56:38 --> Output Class Initialized
DEBUG - 2011-04-08 23:56:38 --> Input Class Initialized
DEBUG - 2011-04-08 23:56:38 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-08 23:56:38 --> Language Class Initialized
DEBUG - 2011-04-08 23:56:38 --> Loader Class Initialized
DEBUG - 2011-04-08 23:56:38 --> Controller Class Initialized
ERROR - 2011-04-08 23:56:38 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-04-08 23:56:38 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-04-08 23:56:38 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-04-08 23:56:38 --> Model Class Initialized
DEBUG - 2011-04-08 23:56:38 --> Model Class Initialized
DEBUG - 2011-04-08 23:56:38 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-08 23:56:38 --> Database Driver Class Initialized
DEBUG - 2011-04-08 23:56:38 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-04-08 23:56:38 --> Helper loaded: url_helper
DEBUG - 2011-04-08 23:56:38 --> File loaded: application/views/common/header.php
DEBUG - 2011-04-08 23:56:38 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-04-08 23:56:38 --> File loaded: application/views/common/footer.php
DEBUG - 2011-04-08 23:56:38 --> File loaded: application/views/layout/main.php
DEBUG - 2011-04-08 23:56:38 --> Final output sent to browser
DEBUG - 2011-04-08 23:56:38 --> Total execution time: 0.0285
DEBUG - 2011-04-08 23:56:39 --> Config Class Initialized
DEBUG - 2011-04-08 23:56:39 --> Hooks Class Initialized
DEBUG - 2011-04-08 23:56:39 --> Utf8 Class Initialized
DEBUG - 2011-04-08 23:56:39 --> UTF-8 Support Enabled
DEBUG - 2011-04-08 23:56:39 --> URI Class Initialized
DEBUG - 2011-04-08 23:56:39 --> Router Class Initialized
DEBUG - 2011-04-08 23:56:39 --> Output Class Initialized
DEBUG - 2011-04-08 23:56:39 --> Input Class Initialized
DEBUG - 2011-04-08 23:56:39 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-08 23:56:39 --> Language Class Initialized
DEBUG - 2011-04-08 23:56:39 --> Loader Class Initialized
DEBUG - 2011-04-08 23:56:39 --> Controller Class Initialized
DEBUG - 2011-04-08 23:56:39 --> Model Class Initialized
DEBUG - 2011-04-08 23:56:39 --> Model Class Initialized
DEBUG - 2011-04-08 23:56:39 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-08 23:56:39 --> Database Driver Class Initialized
DEBUG - 2011-04-08 23:56:39 --> Final output sent to browser
DEBUG - 2011-04-08 23:56:39 --> Total execution time: 0.5802
DEBUG - 2011-04-08 23:56:44 --> Config Class Initialized
DEBUG - 2011-04-08 23:56:44 --> Hooks Class Initialized
DEBUG - 2011-04-08 23:56:44 --> Utf8 Class Initialized
DEBUG - 2011-04-08 23:56:44 --> UTF-8 Support Enabled
DEBUG - 2011-04-08 23:56:44 --> URI Class Initialized
DEBUG - 2011-04-08 23:56:44 --> Router Class Initialized
DEBUG - 2011-04-08 23:56:44 --> Output Class Initialized
DEBUG - 2011-04-08 23:56:44 --> Input Class Initialized
DEBUG - 2011-04-08 23:56:44 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-08 23:56:44 --> Language Class Initialized
DEBUG - 2011-04-08 23:56:44 --> Loader Class Initialized
DEBUG - 2011-04-08 23:56:44 --> Controller Class Initialized
ERROR - 2011-04-08 23:56:44 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-04-08 23:56:44 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-04-08 23:56:44 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-04-08 23:56:44 --> Model Class Initialized
DEBUG - 2011-04-08 23:56:44 --> Model Class Initialized
DEBUG - 2011-04-08 23:56:44 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-08 23:56:44 --> Database Driver Class Initialized
DEBUG - 2011-04-08 23:56:44 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-04-08 23:56:44 --> Helper loaded: url_helper
DEBUG - 2011-04-08 23:56:44 --> File loaded: application/views/common/header.php
DEBUG - 2011-04-08 23:56:44 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-04-08 23:56:44 --> File loaded: application/views/common/footer.php
DEBUG - 2011-04-08 23:56:44 --> File loaded: application/views/layout/main.php
DEBUG - 2011-04-08 23:56:44 --> Final output sent to browser
DEBUG - 2011-04-08 23:56:44 --> Total execution time: 0.0280
DEBUG - 2011-04-08 23:56:44 --> Config Class Initialized
DEBUG - 2011-04-08 23:56:44 --> Hooks Class Initialized
DEBUG - 2011-04-08 23:56:44 --> Utf8 Class Initialized
DEBUG - 2011-04-08 23:56:44 --> UTF-8 Support Enabled
DEBUG - 2011-04-08 23:56:44 --> URI Class Initialized
DEBUG - 2011-04-08 23:56:44 --> Router Class Initialized
DEBUG - 2011-04-08 23:56:44 --> Output Class Initialized
DEBUG - 2011-04-08 23:56:44 --> Input Class Initialized
DEBUG - 2011-04-08 23:56:44 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-08 23:56:44 --> Language Class Initialized
DEBUG - 2011-04-08 23:56:44 --> Loader Class Initialized
DEBUG - 2011-04-08 23:56:44 --> Controller Class Initialized
DEBUG - 2011-04-08 23:56:44 --> Model Class Initialized
DEBUG - 2011-04-08 23:56:44 --> Model Class Initialized
DEBUG - 2011-04-08 23:56:44 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-08 23:56:44 --> Database Driver Class Initialized
DEBUG - 2011-04-08 23:56:45 --> Final output sent to browser
DEBUG - 2011-04-08 23:56:45 --> Total execution time: 0.6081
DEBUG - 2011-04-08 23:56:48 --> Config Class Initialized
DEBUG - 2011-04-08 23:56:48 --> Hooks Class Initialized
DEBUG - 2011-04-08 23:56:48 --> Utf8 Class Initialized
DEBUG - 2011-04-08 23:56:48 --> UTF-8 Support Enabled
DEBUG - 2011-04-08 23:56:48 --> URI Class Initialized
DEBUG - 2011-04-08 23:56:48 --> Router Class Initialized
DEBUG - 2011-04-08 23:56:48 --> Output Class Initialized
DEBUG - 2011-04-08 23:56:48 --> Input Class Initialized
DEBUG - 2011-04-08 23:56:48 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-08 23:56:48 --> Language Class Initialized
DEBUG - 2011-04-08 23:56:48 --> Loader Class Initialized
DEBUG - 2011-04-08 23:56:48 --> Controller Class Initialized
ERROR - 2011-04-08 23:56:48 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-04-08 23:56:48 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-04-08 23:56:48 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-04-08 23:56:48 --> Model Class Initialized
DEBUG - 2011-04-08 23:56:48 --> Model Class Initialized
DEBUG - 2011-04-08 23:56:48 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-08 23:56:48 --> Database Driver Class Initialized
DEBUG - 2011-04-08 23:56:48 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-04-08 23:56:48 --> Helper loaded: url_helper
DEBUG - 2011-04-08 23:56:48 --> File loaded: application/views/common/header.php
DEBUG - 2011-04-08 23:56:48 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-04-08 23:56:48 --> File loaded: application/views/common/footer.php
DEBUG - 2011-04-08 23:56:48 --> File loaded: application/views/layout/main.php
DEBUG - 2011-04-08 23:56:48 --> Final output sent to browser
DEBUG - 2011-04-08 23:56:48 --> Total execution time: 0.0282
DEBUG - 2011-04-08 23:56:48 --> Config Class Initialized
DEBUG - 2011-04-08 23:56:48 --> Hooks Class Initialized
DEBUG - 2011-04-08 23:56:48 --> Utf8 Class Initialized
DEBUG - 2011-04-08 23:56:48 --> UTF-8 Support Enabled
DEBUG - 2011-04-08 23:56:48 --> URI Class Initialized
DEBUG - 2011-04-08 23:56:48 --> Router Class Initialized
DEBUG - 2011-04-08 23:56:48 --> Output Class Initialized
DEBUG - 2011-04-08 23:56:48 --> Input Class Initialized
DEBUG - 2011-04-08 23:56:48 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-08 23:56:48 --> Language Class Initialized
DEBUG - 2011-04-08 23:56:48 --> Loader Class Initialized
DEBUG - 2011-04-08 23:56:48 --> Controller Class Initialized
DEBUG - 2011-04-08 23:56:48 --> Model Class Initialized
DEBUG - 2011-04-08 23:56:48 --> Model Class Initialized
DEBUG - 2011-04-08 23:56:48 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-08 23:56:48 --> Database Driver Class Initialized
DEBUG - 2011-04-08 23:56:49 --> Final output sent to browser
DEBUG - 2011-04-08 23:56:49 --> Total execution time: 0.4685
DEBUG - 2011-04-08 23:56:52 --> Config Class Initialized
DEBUG - 2011-04-08 23:56:52 --> Hooks Class Initialized
DEBUG - 2011-04-08 23:56:52 --> Utf8 Class Initialized
DEBUG - 2011-04-08 23:56:52 --> UTF-8 Support Enabled
DEBUG - 2011-04-08 23:56:52 --> URI Class Initialized
DEBUG - 2011-04-08 23:56:52 --> Router Class Initialized
DEBUG - 2011-04-08 23:56:52 --> Output Class Initialized
DEBUG - 2011-04-08 23:56:52 --> Input Class Initialized
DEBUG - 2011-04-08 23:56:52 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-08 23:56:52 --> Language Class Initialized
DEBUG - 2011-04-08 23:56:52 --> Loader Class Initialized
DEBUG - 2011-04-08 23:56:52 --> Controller Class Initialized
ERROR - 2011-04-08 23:56:52 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-04-08 23:56:52 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-04-08 23:56:52 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-04-08 23:56:52 --> Model Class Initialized
DEBUG - 2011-04-08 23:56:52 --> Model Class Initialized
DEBUG - 2011-04-08 23:56:52 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-08 23:56:52 --> Database Driver Class Initialized
DEBUG - 2011-04-08 23:56:52 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-04-08 23:56:52 --> Helper loaded: url_helper
DEBUG - 2011-04-08 23:56:52 --> File loaded: application/views/common/header.php
DEBUG - 2011-04-08 23:56:52 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-04-08 23:56:52 --> File loaded: application/views/common/footer.php
DEBUG - 2011-04-08 23:56:52 --> File loaded: application/views/layout/main.php
DEBUG - 2011-04-08 23:56:52 --> Final output sent to browser
DEBUG - 2011-04-08 23:56:52 --> Total execution time: 0.0284
DEBUG - 2011-04-08 23:56:53 --> Config Class Initialized
DEBUG - 2011-04-08 23:56:53 --> Hooks Class Initialized
DEBUG - 2011-04-08 23:56:53 --> Utf8 Class Initialized
DEBUG - 2011-04-08 23:56:53 --> UTF-8 Support Enabled
DEBUG - 2011-04-08 23:56:53 --> URI Class Initialized
DEBUG - 2011-04-08 23:56:53 --> Router Class Initialized
DEBUG - 2011-04-08 23:56:53 --> Output Class Initialized
DEBUG - 2011-04-08 23:56:53 --> Input Class Initialized
DEBUG - 2011-04-08 23:56:53 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-08 23:56:53 --> Language Class Initialized
DEBUG - 2011-04-08 23:56:53 --> Loader Class Initialized
DEBUG - 2011-04-08 23:56:53 --> Controller Class Initialized
DEBUG - 2011-04-08 23:56:53 --> Model Class Initialized
DEBUG - 2011-04-08 23:56:53 --> Model Class Initialized
DEBUG - 2011-04-08 23:56:53 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-08 23:56:53 --> Database Driver Class Initialized
DEBUG - 2011-04-08 23:56:53 --> Final output sent to browser
DEBUG - 2011-04-08 23:56:53 --> Total execution time: 0.5292
DEBUG - 2011-04-08 23:57:02 --> Config Class Initialized
DEBUG - 2011-04-08 23:57:02 --> Hooks Class Initialized
DEBUG - 2011-04-08 23:57:02 --> Utf8 Class Initialized
DEBUG - 2011-04-08 23:57:02 --> UTF-8 Support Enabled
DEBUG - 2011-04-08 23:57:02 --> URI Class Initialized
DEBUG - 2011-04-08 23:57:02 --> Router Class Initialized
DEBUG - 2011-04-08 23:57:02 --> Output Class Initialized
DEBUG - 2011-04-08 23:57:02 --> Input Class Initialized
DEBUG - 2011-04-08 23:57:02 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-08 23:57:02 --> Language Class Initialized
DEBUG - 2011-04-08 23:57:02 --> Loader Class Initialized
DEBUG - 2011-04-08 23:57:02 --> Controller Class Initialized
ERROR - 2011-04-08 23:57:02 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-04-08 23:57:02 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-04-08 23:57:02 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-04-08 23:57:02 --> Model Class Initialized
DEBUG - 2011-04-08 23:57:02 --> Model Class Initialized
DEBUG - 2011-04-08 23:57:02 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-08 23:57:02 --> Database Driver Class Initialized
DEBUG - 2011-04-08 23:57:02 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-04-08 23:57:02 --> Helper loaded: url_helper
DEBUG - 2011-04-08 23:57:02 --> File loaded: application/views/common/header.php
DEBUG - 2011-04-08 23:57:02 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-04-08 23:57:02 --> File loaded: application/views/common/footer.php
DEBUG - 2011-04-08 23:57:02 --> File loaded: application/views/layout/main.php
DEBUG - 2011-04-08 23:57:02 --> Final output sent to browser
DEBUG - 2011-04-08 23:57:02 --> Total execution time: 0.0279
DEBUG - 2011-04-08 23:57:03 --> Config Class Initialized
DEBUG - 2011-04-08 23:57:03 --> Hooks Class Initialized
DEBUG - 2011-04-08 23:57:03 --> Utf8 Class Initialized
DEBUG - 2011-04-08 23:57:03 --> UTF-8 Support Enabled
DEBUG - 2011-04-08 23:57:03 --> URI Class Initialized
DEBUG - 2011-04-08 23:57:03 --> Router Class Initialized
DEBUG - 2011-04-08 23:57:03 --> Output Class Initialized
DEBUG - 2011-04-08 23:57:03 --> Input Class Initialized
DEBUG - 2011-04-08 23:57:03 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-08 23:57:03 --> Language Class Initialized
DEBUG - 2011-04-08 23:57:03 --> Loader Class Initialized
DEBUG - 2011-04-08 23:57:03 --> Controller Class Initialized
DEBUG - 2011-04-08 23:57:03 --> Model Class Initialized
DEBUG - 2011-04-08 23:57:03 --> Model Class Initialized
DEBUG - 2011-04-08 23:57:03 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-08 23:57:03 --> Database Driver Class Initialized
DEBUG - 2011-04-08 23:57:03 --> Final output sent to browser
DEBUG - 2011-04-08 23:57:03 --> Total execution time: 0.5182
DEBUG - 2011-04-08 23:57:18 --> Config Class Initialized
DEBUG - 2011-04-08 23:57:18 --> Hooks Class Initialized
DEBUG - 2011-04-08 23:57:18 --> Utf8 Class Initialized
DEBUG - 2011-04-08 23:57:18 --> UTF-8 Support Enabled
DEBUG - 2011-04-08 23:57:18 --> URI Class Initialized
DEBUG - 2011-04-08 23:57:18 --> Router Class Initialized
DEBUG - 2011-04-08 23:57:18 --> Output Class Initialized
DEBUG - 2011-04-08 23:57:19 --> Input Class Initialized
DEBUG - 2011-04-08 23:57:19 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-08 23:57:19 --> Language Class Initialized
DEBUG - 2011-04-08 23:57:19 --> Loader Class Initialized
DEBUG - 2011-04-08 23:57:19 --> Controller Class Initialized
ERROR - 2011-04-08 23:57:19 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-04-08 23:57:19 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-04-08 23:57:19 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-04-08 23:57:19 --> Model Class Initialized
DEBUG - 2011-04-08 23:57:19 --> Model Class Initialized
DEBUG - 2011-04-08 23:57:19 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-08 23:57:19 --> Database Driver Class Initialized
DEBUG - 2011-04-08 23:57:19 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-04-08 23:57:19 --> Helper loaded: url_helper
DEBUG - 2011-04-08 23:57:19 --> File loaded: application/views/common/header.php
DEBUG - 2011-04-08 23:57:19 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-04-08 23:57:19 --> File loaded: application/views/common/footer.php
DEBUG - 2011-04-08 23:57:19 --> File loaded: application/views/layout/main.php
DEBUG - 2011-04-08 23:57:19 --> Final output sent to browser
DEBUG - 2011-04-08 23:57:19 --> Total execution time: 0.0286
DEBUG - 2011-04-08 23:57:19 --> Config Class Initialized
DEBUG - 2011-04-08 23:57:19 --> Hooks Class Initialized
DEBUG - 2011-04-08 23:57:19 --> Utf8 Class Initialized
DEBUG - 2011-04-08 23:57:19 --> UTF-8 Support Enabled
DEBUG - 2011-04-08 23:57:19 --> URI Class Initialized
DEBUG - 2011-04-08 23:57:19 --> Router Class Initialized
DEBUG - 2011-04-08 23:57:19 --> Output Class Initialized
DEBUG - 2011-04-08 23:57:19 --> Input Class Initialized
DEBUG - 2011-04-08 23:57:19 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-08 23:57:19 --> Language Class Initialized
DEBUG - 2011-04-08 23:57:19 --> Loader Class Initialized
DEBUG - 2011-04-08 23:57:19 --> Controller Class Initialized
DEBUG - 2011-04-08 23:57:19 --> Model Class Initialized
DEBUG - 2011-04-08 23:57:19 --> Model Class Initialized
DEBUG - 2011-04-08 23:57:19 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-08 23:57:19 --> Database Driver Class Initialized
DEBUG - 2011-04-08 23:57:19 --> Final output sent to browser
DEBUG - 2011-04-08 23:57:19 --> Total execution time: 0.5387

<?php  if ( ! defined('BASEPATH')) exit('No direct script access allowed'); ?>

DEBUG - 2011-07-23 01:40:38 --> Config Class Initialized
DEBUG - 2011-07-23 01:40:38 --> Hooks Class Initialized
DEBUG - 2011-07-23 01:40:38 --> Utf8 Class Initialized
DEBUG - 2011-07-23 01:40:38 --> UTF-8 Support Enabled
DEBUG - 2011-07-23 01:40:38 --> URI Class Initialized
DEBUG - 2011-07-23 01:40:38 --> Router Class Initialized
DEBUG - 2011-07-23 01:40:38 --> Output Class Initialized
DEBUG - 2011-07-23 01:40:38 --> Input Class Initialized
DEBUG - 2011-07-23 01:40:38 --> Global POST and COOKIE data sanitized
DEBUG - 2011-07-23 01:40:38 --> Language Class Initialized
DEBUG - 2011-07-23 01:40:39 --> Loader Class Initialized
DEBUG - 2011-07-23 01:40:39 --> Controller Class Initialized
ERROR - 2011-07-23 01:40:39 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-07-23 01:40:39 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-07-23 01:40:39 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-07-23 01:40:39 --> Model Class Initialized
DEBUG - 2011-07-23 01:40:39 --> Model Class Initialized
DEBUG - 2011-07-23 01:40:39 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-07-23 01:40:39 --> Database Driver Class Initialized
DEBUG - 2011-07-23 01:40:39 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-07-23 01:40:39 --> Helper loaded: url_helper
DEBUG - 2011-07-23 01:40:39 --> File loaded: application/views/common/header.php
DEBUG - 2011-07-23 01:40:39 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-07-23 01:40:39 --> File loaded: application/views/common/footer.php
DEBUG - 2011-07-23 01:40:39 --> File loaded: application/views/layout/main.php
DEBUG - 2011-07-23 01:40:39 --> Final output sent to browser
DEBUG - 2011-07-23 01:40:39 --> Total execution time: 0.4005
DEBUG - 2011-07-23 01:40:41 --> Config Class Initialized
DEBUG - 2011-07-23 01:40:41 --> Hooks Class Initialized
DEBUG - 2011-07-23 01:40:41 --> Utf8 Class Initialized
DEBUG - 2011-07-23 01:40:41 --> UTF-8 Support Enabled
DEBUG - 2011-07-23 01:40:41 --> URI Class Initialized
DEBUG - 2011-07-23 01:40:41 --> Router Class Initialized
DEBUG - 2011-07-23 01:40:41 --> Output Class Initialized
DEBUG - 2011-07-23 01:40:41 --> Input Class Initialized
DEBUG - 2011-07-23 01:40:41 --> Global POST and COOKIE data sanitized
DEBUG - 2011-07-23 01:40:41 --> Language Class Initialized
DEBUG - 2011-07-23 01:40:41 --> Loader Class Initialized
DEBUG - 2011-07-23 01:40:41 --> Controller Class Initialized
DEBUG - 2011-07-23 01:40:41 --> Model Class Initialized
DEBUG - 2011-07-23 01:40:41 --> Model Class Initialized
DEBUG - 2011-07-23 01:40:41 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-07-23 01:40:41 --> Database Driver Class Initialized
DEBUG - 2011-07-23 01:40:43 --> Final output sent to browser
DEBUG - 2011-07-23 01:40:43 --> Total execution time: 1.7176
DEBUG - 2011-07-23 01:40:44 --> Config Class Initialized
DEBUG - 2011-07-23 01:40:44 --> Hooks Class Initialized
DEBUG - 2011-07-23 01:40:44 --> Utf8 Class Initialized
DEBUG - 2011-07-23 01:40:44 --> UTF-8 Support Enabled
DEBUG - 2011-07-23 01:40:44 --> URI Class Initialized
DEBUG - 2011-07-23 01:40:44 --> Router Class Initialized
ERROR - 2011-07-23 01:40:44 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-07-23 01:44:47 --> Config Class Initialized
DEBUG - 2011-07-23 01:44:47 --> Hooks Class Initialized
DEBUG - 2011-07-23 01:44:47 --> Utf8 Class Initialized
DEBUG - 2011-07-23 01:44:47 --> UTF-8 Support Enabled
DEBUG - 2011-07-23 01:44:47 --> URI Class Initialized
DEBUG - 2011-07-23 01:44:47 --> Router Class Initialized
DEBUG - 2011-07-23 01:44:47 --> Output Class Initialized
DEBUG - 2011-07-23 01:44:47 --> Input Class Initialized
DEBUG - 2011-07-23 01:44:47 --> Global POST and COOKIE data sanitized
DEBUG - 2011-07-23 01:44:47 --> Language Class Initialized
DEBUG - 2011-07-23 01:44:47 --> Loader Class Initialized
DEBUG - 2011-07-23 01:44:47 --> Controller Class Initialized
DEBUG - 2011-07-23 01:44:47 --> Model Class Initialized
DEBUG - 2011-07-23 01:44:47 --> Model Class Initialized
DEBUG - 2011-07-23 01:44:47 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-07-23 01:44:47 --> Database Driver Class Initialized
DEBUG - 2011-07-23 01:44:48 --> Final output sent to browser
DEBUG - 2011-07-23 01:44:48 --> Total execution time: 0.6049
DEBUG - 2011-07-23 07:57:42 --> Config Class Initialized
DEBUG - 2011-07-23 07:57:42 --> Hooks Class Initialized
DEBUG - 2011-07-23 07:57:42 --> Utf8 Class Initialized
DEBUG - 2011-07-23 07:57:42 --> UTF-8 Support Enabled
DEBUG - 2011-07-23 07:57:42 --> URI Class Initialized
DEBUG - 2011-07-23 07:57:42 --> Router Class Initialized
DEBUG - 2011-07-23 07:57:42 --> Output Class Initialized
DEBUG - 2011-07-23 07:57:42 --> Input Class Initialized
DEBUG - 2011-07-23 07:57:42 --> Global POST and COOKIE data sanitized
DEBUG - 2011-07-23 07:57:42 --> Language Class Initialized
DEBUG - 2011-07-23 07:57:42 --> Loader Class Initialized
DEBUG - 2011-07-23 07:57:42 --> Controller Class Initialized
DEBUG - 2011-07-23 07:57:42 --> Model Class Initialized
DEBUG - 2011-07-23 07:57:43 --> Model Class Initialized
DEBUG - 2011-07-23 07:57:43 --> Model Class Initialized
DEBUG - 2011-07-23 07:57:43 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-07-23 07:57:43 --> Database Driver Class Initialized
ERROR - 2011-07-23 07:57:43 --> Severity: Warning  --> mysql_pconnect() [<a href='function.mysql-pconnect'>function.mysql-pconnect</a>]: Can't connect to local MySQL server through socket '/var/lib/mysql/mysql.sock' (11) /home1/raptorsr/public_html/arsenaliststats/system/database/drivers/mysql/mysql_driver.php 88
ERROR - 2011-07-23 07:57:43 --> Unable to connect to the database
DEBUG - 2011-07-23 07:57:43 --> Language file loaded: language/english/db_lang.php
DEBUG - 2011-07-23 08:11:24 --> Config Class Initialized
DEBUG - 2011-07-23 08:11:24 --> Hooks Class Initialized
DEBUG - 2011-07-23 08:11:24 --> Utf8 Class Initialized
DEBUG - 2011-07-23 08:11:24 --> UTF-8 Support Enabled
DEBUG - 2011-07-23 08:11:24 --> URI Class Initialized
DEBUG - 2011-07-23 08:11:24 --> Router Class Initialized
DEBUG - 2011-07-23 08:11:24 --> Output Class Initialized
DEBUG - 2011-07-23 08:11:24 --> Input Class Initialized
DEBUG - 2011-07-23 08:11:24 --> Global POST and COOKIE data sanitized
DEBUG - 2011-07-23 08:11:24 --> Language Class Initialized
DEBUG - 2011-07-23 08:11:24 --> Loader Class Initialized
DEBUG - 2011-07-23 08:11:24 --> Controller Class Initialized
DEBUG - 2011-07-23 08:11:24 --> Model Class Initialized
DEBUG - 2011-07-23 08:11:24 --> Model Class Initialized
DEBUG - 2011-07-23 08:11:24 --> Model Class Initialized
DEBUG - 2011-07-23 08:11:24 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-07-23 08:11:24 --> Database Driver Class Initialized
ERROR - 2011-07-23 08:11:24 --> Severity: Warning  --> mysql_pconnect() [<a href='function.mysql-pconnect'>function.mysql-pconnect</a>]: Can't connect to local MySQL server through socket '/var/lib/mysql/mysql.sock' (11) /home1/raptorsr/public_html/arsenaliststats/system/database/drivers/mysql/mysql_driver.php 88
ERROR - 2011-07-23 08:11:24 --> Unable to connect to the database
DEBUG - 2011-07-23 08:11:24 --> Language file loaded: language/english/db_lang.php
DEBUG - 2011-07-23 08:21:04 --> Config Class Initialized
DEBUG - 2011-07-23 08:21:04 --> Hooks Class Initialized
DEBUG - 2011-07-23 08:21:04 --> Utf8 Class Initialized
DEBUG - 2011-07-23 08:21:04 --> UTF-8 Support Enabled
DEBUG - 2011-07-23 08:21:04 --> URI Class Initialized
DEBUG - 2011-07-23 08:21:04 --> Router Class Initialized
DEBUG - 2011-07-23 08:21:04 --> Output Class Initialized
DEBUG - 2011-07-23 08:21:04 --> Input Class Initialized
DEBUG - 2011-07-23 08:21:04 --> Global POST and COOKIE data sanitized
DEBUG - 2011-07-23 08:21:04 --> Language Class Initialized
DEBUG - 2011-07-23 08:21:04 --> Loader Class Initialized
DEBUG - 2011-07-23 08:21:04 --> Controller Class Initialized
ERROR - 2011-07-23 08:21:04 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-07-23 08:21:04 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-07-23 08:21:04 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-07-23 08:21:04 --> Model Class Initialized
DEBUG - 2011-07-23 08:21:04 --> Model Class Initialized
DEBUG - 2011-07-23 08:21:04 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-07-23 08:21:04 --> Database Driver Class Initialized
ERROR - 2011-07-23 08:21:04 --> Severity: Warning  --> mysql_pconnect() [<a href='function.mysql-pconnect'>function.mysql-pconnect</a>]: Can't connect to local MySQL server through socket '/var/lib/mysql/mysql.sock' (11) /home1/raptorsr/public_html/arsenaliststats/system/database/drivers/mysql/mysql_driver.php 88
ERROR - 2011-07-23 08:21:04 --> Unable to connect to the database
DEBUG - 2011-07-23 08:21:04 --> Language file loaded: language/english/db_lang.php
DEBUG - 2011-07-23 08:21:09 --> Config Class Initialized
DEBUG - 2011-07-23 08:21:09 --> Hooks Class Initialized
DEBUG - 2011-07-23 08:21:09 --> Utf8 Class Initialized
DEBUG - 2011-07-23 08:21:09 --> UTF-8 Support Enabled
DEBUG - 2011-07-23 08:21:09 --> URI Class Initialized
DEBUG - 2011-07-23 08:21:09 --> Router Class Initialized
ERROR - 2011-07-23 08:21:09 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-07-23 08:21:18 --> Config Class Initialized
DEBUG - 2011-07-23 08:21:18 --> Hooks Class Initialized
DEBUG - 2011-07-23 08:21:18 --> Utf8 Class Initialized
DEBUG - 2011-07-23 08:21:18 --> UTF-8 Support Enabled
DEBUG - 2011-07-23 08:21:18 --> URI Class Initialized
DEBUG - 2011-07-23 08:21:18 --> Router Class Initialized
DEBUG - 2011-07-23 08:21:18 --> Output Class Initialized
DEBUG - 2011-07-23 08:21:18 --> Input Class Initialized
DEBUG - 2011-07-23 08:21:18 --> Global POST and COOKIE data sanitized
DEBUG - 2011-07-23 08:21:18 --> Language Class Initialized
DEBUG - 2011-07-23 08:21:18 --> Loader Class Initialized
DEBUG - 2011-07-23 08:21:18 --> Controller Class Initialized
ERROR - 2011-07-23 08:21:18 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-07-23 08:21:18 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-07-23 08:21:18 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-07-23 08:21:18 --> Model Class Initialized
DEBUG - 2011-07-23 08:21:18 --> Model Class Initialized
DEBUG - 2011-07-23 08:21:18 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-07-23 08:21:18 --> Database Driver Class Initialized
ERROR - 2011-07-23 08:21:18 --> Severity: Warning  --> mysql_pconnect() [<a href='function.mysql-pconnect'>function.mysql-pconnect</a>]: Can't connect to local MySQL server through socket '/var/lib/mysql/mysql.sock' (11) /home1/raptorsr/public_html/arsenaliststats/system/database/drivers/mysql/mysql_driver.php 88
ERROR - 2011-07-23 08:21:18 --> Unable to connect to the database
DEBUG - 2011-07-23 08:21:18 --> Language file loaded: language/english/db_lang.php
DEBUG - 2011-07-23 08:45:58 --> Config Class Initialized
DEBUG - 2011-07-23 08:45:58 --> Hooks Class Initialized
DEBUG - 2011-07-23 08:45:58 --> Utf8 Class Initialized
DEBUG - 2011-07-23 08:45:58 --> UTF-8 Support Enabled
DEBUG - 2011-07-23 08:45:58 --> URI Class Initialized
DEBUG - 2011-07-23 08:45:58 --> Router Class Initialized
DEBUG - 2011-07-23 08:45:58 --> Output Class Initialized
DEBUG - 2011-07-23 08:45:58 --> Input Class Initialized
DEBUG - 2011-07-23 08:45:58 --> Global POST and COOKIE data sanitized
DEBUG - 2011-07-23 08:45:58 --> Language Class Initialized
DEBUG - 2011-07-23 08:45:58 --> Loader Class Initialized
DEBUG - 2011-07-23 08:45:58 --> Controller Class Initialized
ERROR - 2011-07-23 08:45:58 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-07-23 08:45:58 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-07-23 08:45:58 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-07-23 08:45:58 --> Model Class Initialized
DEBUG - 2011-07-23 08:45:58 --> Model Class Initialized
DEBUG - 2011-07-23 08:45:58 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-07-23 08:45:58 --> Database Driver Class Initialized
DEBUG - 2011-07-23 08:46:01 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-07-23 08:46:01 --> Helper loaded: url_helper
DEBUG - 2011-07-23 08:46:01 --> File loaded: application/views/common/header.php
DEBUG - 2011-07-23 08:46:01 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-07-23 08:46:01 --> File loaded: application/views/common/footer.php
DEBUG - 2011-07-23 08:46:01 --> File loaded: application/views/layout/main.php
DEBUG - 2011-07-23 08:46:01 --> Final output sent to browser
DEBUG - 2011-07-23 08:46:01 --> Total execution time: 3.0886
DEBUG - 2011-07-23 08:46:02 --> Config Class Initialized
DEBUG - 2011-07-23 08:46:02 --> Hooks Class Initialized
DEBUG - 2011-07-23 08:46:02 --> Utf8 Class Initialized
DEBUG - 2011-07-23 08:46:02 --> UTF-8 Support Enabled
DEBUG - 2011-07-23 08:46:02 --> URI Class Initialized
DEBUG - 2011-07-23 08:46:02 --> Router Class Initialized
DEBUG - 2011-07-23 08:46:02 --> Output Class Initialized
DEBUG - 2011-07-23 08:46:02 --> Input Class Initialized
DEBUG - 2011-07-23 08:46:02 --> Global POST and COOKIE data sanitized
DEBUG - 2011-07-23 08:46:02 --> Language Class Initialized
DEBUG - 2011-07-23 08:46:02 --> Loader Class Initialized
DEBUG - 2011-07-23 08:46:02 --> Controller Class Initialized
DEBUG - 2011-07-23 08:46:02 --> Model Class Initialized
DEBUG - 2011-07-23 08:46:02 --> Model Class Initialized
DEBUG - 2011-07-23 08:46:02 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-07-23 08:46:02 --> Database Driver Class Initialized
DEBUG - 2011-07-23 08:46:04 --> Final output sent to browser
DEBUG - 2011-07-23 08:46:04 --> Total execution time: 1.9983
DEBUG - 2011-07-23 08:46:06 --> Config Class Initialized
DEBUG - 2011-07-23 08:46:06 --> Hooks Class Initialized
DEBUG - 2011-07-23 08:46:06 --> Utf8 Class Initialized
DEBUG - 2011-07-23 08:46:06 --> UTF-8 Support Enabled
DEBUG - 2011-07-23 08:46:06 --> URI Class Initialized
DEBUG - 2011-07-23 08:46:06 --> Router Class Initialized
ERROR - 2011-07-23 08:46:06 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-07-23 08:49:45 --> Config Class Initialized
DEBUG - 2011-07-23 08:49:45 --> Hooks Class Initialized
DEBUG - 2011-07-23 08:49:45 --> Utf8 Class Initialized
DEBUG - 2011-07-23 08:49:45 --> UTF-8 Support Enabled
DEBUG - 2011-07-23 08:49:45 --> URI Class Initialized
DEBUG - 2011-07-23 08:49:45 --> Router Class Initialized
ERROR - 2011-07-23 08:49:45 --> 404 Page Not Found --> robots.txt
DEBUG - 2011-07-23 08:49:55 --> Config Class Initialized
DEBUG - 2011-07-23 08:49:55 --> Hooks Class Initialized
DEBUG - 2011-07-23 08:49:55 --> Utf8 Class Initialized
DEBUG - 2011-07-23 08:49:55 --> UTF-8 Support Enabled
DEBUG - 2011-07-23 08:49:55 --> URI Class Initialized
DEBUG - 2011-07-23 08:49:55 --> Router Class Initialized
DEBUG - 2011-07-23 08:49:55 --> Output Class Initialized
DEBUG - 2011-07-23 08:49:55 --> Input Class Initialized
DEBUG - 2011-07-23 08:49:55 --> Global POST and COOKIE data sanitized
DEBUG - 2011-07-23 08:49:55 --> Language Class Initialized
DEBUG - 2011-07-23 08:49:55 --> Loader Class Initialized
DEBUG - 2011-07-23 08:49:55 --> Controller Class Initialized
DEBUG - 2011-07-23 08:49:55 --> Model Class Initialized
DEBUG - 2011-07-23 08:49:55 --> Model Class Initialized
DEBUG - 2011-07-23 08:49:55 --> Model Class Initialized
DEBUG - 2011-07-23 08:49:55 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-07-23 08:49:55 --> Database Driver Class Initialized
DEBUG - 2011-07-23 08:49:58 --> File loaded: application/views/table/main.php
DEBUG - 2011-07-23 08:49:58 --> Helper loaded: url_helper
DEBUG - 2011-07-23 08:49:58 --> File loaded: application/views/common/header.php
DEBUG - 2011-07-23 08:49:58 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-07-23 08:49:58 --> File loaded: application/views/common/footer.php
DEBUG - 2011-07-23 08:49:58 --> File loaded: application/views/layout/main.php
DEBUG - 2011-07-23 08:49:58 --> Final output sent to browser
DEBUG - 2011-07-23 08:49:58 --> Total execution time: 2.4809
DEBUG - 2011-07-23 08:52:21 --> Config Class Initialized
DEBUG - 2011-07-23 08:52:21 --> Hooks Class Initialized
DEBUG - 2011-07-23 08:52:21 --> Utf8 Class Initialized
DEBUG - 2011-07-23 08:52:21 --> UTF-8 Support Enabled
DEBUG - 2011-07-23 08:52:21 --> URI Class Initialized
DEBUG - 2011-07-23 08:52:21 --> Router Class Initialized
DEBUG - 2011-07-23 08:52:21 --> Output Class Initialized
DEBUG - 2011-07-23 08:52:21 --> Input Class Initialized
DEBUG - 2011-07-23 08:52:21 --> Global POST and COOKIE data sanitized
DEBUG - 2011-07-23 08:52:21 --> Language Class Initialized
DEBUG - 2011-07-23 08:52:21 --> Loader Class Initialized
DEBUG - 2011-07-23 08:52:21 --> Controller Class Initialized
DEBUG - 2011-07-23 08:52:21 --> Model Class Initialized
DEBUG - 2011-07-23 08:52:21 --> Model Class Initialized
DEBUG - 2011-07-23 08:52:21 --> Model Class Initialized
DEBUG - 2011-07-23 08:52:21 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-07-23 08:52:21 --> Database Driver Class Initialized
DEBUG - 2011-07-23 08:52:21 --> File loaded: application/views/table/main.php
DEBUG - 2011-07-23 08:52:21 --> Helper loaded: url_helper
DEBUG - 2011-07-23 08:52:21 --> File loaded: application/views/common/header.php
DEBUG - 2011-07-23 08:52:21 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-07-23 08:52:21 --> File loaded: application/views/common/footer.php
DEBUG - 2011-07-23 08:52:21 --> File loaded: application/views/layout/main.php
DEBUG - 2011-07-23 08:52:21 --> Final output sent to browser
DEBUG - 2011-07-23 08:52:21 --> Total execution time: 0.0554
DEBUG - 2011-07-23 08:52:30 --> Config Class Initialized
DEBUG - 2011-07-23 08:52:30 --> Hooks Class Initialized
DEBUG - 2011-07-23 08:52:30 --> Utf8 Class Initialized
DEBUG - 2011-07-23 08:52:30 --> UTF-8 Support Enabled
DEBUG - 2011-07-23 08:52:30 --> URI Class Initialized
DEBUG - 2011-07-23 08:52:30 --> Router Class Initialized
ERROR - 2011-07-23 08:52:30 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-07-23 08:53:29 --> Config Class Initialized
DEBUG - 2011-07-23 08:53:29 --> Hooks Class Initialized
DEBUG - 2011-07-23 08:53:29 --> Utf8 Class Initialized
DEBUG - 2011-07-23 08:53:29 --> UTF-8 Support Enabled
DEBUG - 2011-07-23 08:53:29 --> URI Class Initialized
DEBUG - 2011-07-23 08:53:29 --> Router Class Initialized
DEBUG - 2011-07-23 08:53:29 --> Output Class Initialized
DEBUG - 2011-07-23 08:53:29 --> Input Class Initialized
DEBUG - 2011-07-23 08:53:29 --> Global POST and COOKIE data sanitized
DEBUG - 2011-07-23 08:53:29 --> Language Class Initialized
DEBUG - 2011-07-23 08:53:29 --> Loader Class Initialized
DEBUG - 2011-07-23 08:53:29 --> Controller Class Initialized
ERROR - 2011-07-23 08:53:29 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-07-23 08:53:29 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-07-23 08:53:29 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-07-23 08:53:29 --> Model Class Initialized
DEBUG - 2011-07-23 08:53:29 --> Model Class Initialized
DEBUG - 2011-07-23 08:53:29 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-07-23 08:53:29 --> Database Driver Class Initialized
DEBUG - 2011-07-23 08:53:29 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-07-23 08:53:29 --> Helper loaded: url_helper
DEBUG - 2011-07-23 08:53:29 --> File loaded: application/views/common/header.php
DEBUG - 2011-07-23 08:53:29 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-07-23 08:53:29 --> File loaded: application/views/common/footer.php
DEBUG - 2011-07-23 08:53:29 --> File loaded: application/views/layout/main.php
DEBUG - 2011-07-23 08:53:29 --> Final output sent to browser
DEBUG - 2011-07-23 08:53:29 --> Total execution time: 0.1547
DEBUG - 2011-07-23 09:26:29 --> Config Class Initialized
DEBUG - 2011-07-23 09:26:29 --> Hooks Class Initialized
DEBUG - 2011-07-23 09:26:29 --> Config Class Initialized
DEBUG - 2011-07-23 09:26:29 --> Hooks Class Initialized
DEBUG - 2011-07-23 09:26:29 --> Utf8 Class Initialized
DEBUG - 2011-07-23 09:26:29 --> UTF-8 Support Enabled
DEBUG - 2011-07-23 09:26:29 --> Utf8 Class Initialized
DEBUG - 2011-07-23 09:26:29 --> UTF-8 Support Enabled
DEBUG - 2011-07-23 09:26:29 --> URI Class Initialized
DEBUG - 2011-07-23 09:26:29 --> URI Class Initialized
DEBUG - 2011-07-23 09:26:29 --> Router Class Initialized
DEBUG - 2011-07-23 09:26:29 --> Router Class Initialized
DEBUG - 2011-07-23 09:26:29 --> No URI present. Default controller set.
DEBUG - 2011-07-23 09:26:29 --> No URI present. Default controller set.
DEBUG - 2011-07-23 09:26:29 --> Output Class Initialized
DEBUG - 2011-07-23 09:26:29 --> Output Class Initialized
DEBUG - 2011-07-23 09:26:29 --> Input Class Initialized
DEBUG - 2011-07-23 09:26:29 --> Global POST and COOKIE data sanitized
DEBUG - 2011-07-23 09:26:29 --> Input Class Initialized
DEBUG - 2011-07-23 09:26:29 --> Global POST and COOKIE data sanitized
DEBUG - 2011-07-23 09:26:29 --> Language Class Initialized
DEBUG - 2011-07-23 09:26:29 --> Language Class Initialized
DEBUG - 2011-07-23 09:26:29 --> Loader Class Initialized
DEBUG - 2011-07-23 09:26:29 --> Loader Class Initialized
DEBUG - 2011-07-23 09:26:29 --> Controller Class Initialized
DEBUG - 2011-07-23 09:26:29 --> Controller Class Initialized
DEBUG - 2011-07-23 09:26:29 --> File loaded: application/views/splash/main.php
DEBUG - 2011-07-23 09:26:29 --> File loaded: application/views/splash/main.php
DEBUG - 2011-07-23 09:26:29 --> Helper loaded: url_helper
DEBUG - 2011-07-23 09:26:29 --> File loaded: application/views/common/header.php
DEBUG - 2011-07-23 09:26:29 --> Helper loaded: url_helper
DEBUG - 2011-07-23 09:26:29 --> File loaded: application/views/common/header.php
DEBUG - 2011-07-23 09:26:29 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-07-23 09:26:29 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-07-23 09:26:29 --> File loaded: application/views/common/footer.php
DEBUG - 2011-07-23 09:26:29 --> File loaded: application/views/layout/main.php
DEBUG - 2011-07-23 09:26:29 --> Final output sent to browser
DEBUG - 2011-07-23 09:26:29 --> Total execution time: 0.3024
DEBUG - 2011-07-23 09:26:29 --> File loaded: application/views/common/footer.php
DEBUG - 2011-07-23 09:26:29 --> File loaded: application/views/layout/main.php
DEBUG - 2011-07-23 09:26:29 --> Final output sent to browser
DEBUG - 2011-07-23 09:26:29 --> Total execution time: 0.3052
DEBUG - 2011-07-23 09:33:50 --> Config Class Initialized
DEBUG - 2011-07-23 09:33:50 --> Hooks Class Initialized
DEBUG - 2011-07-23 09:33:50 --> Utf8 Class Initialized
DEBUG - 2011-07-23 09:33:50 --> UTF-8 Support Enabled
DEBUG - 2011-07-23 09:33:50 --> URI Class Initialized
DEBUG - 2011-07-23 09:33:50 --> Router Class Initialized
DEBUG - 2011-07-23 09:33:50 --> Output Class Initialized
DEBUG - 2011-07-23 09:33:50 --> Input Class Initialized
DEBUG - 2011-07-23 09:33:50 --> Global POST and COOKIE data sanitized
DEBUG - 2011-07-23 09:33:50 --> Language Class Initialized
DEBUG - 2011-07-23 09:33:50 --> Loader Class Initialized
DEBUG - 2011-07-23 09:33:50 --> Controller Class Initialized
DEBUG - 2011-07-23 09:33:50 --> Model Class Initialized
DEBUG - 2011-07-23 09:33:50 --> Model Class Initialized
DEBUG - 2011-07-23 09:33:50 --> Model Class Initialized
DEBUG - 2011-07-23 09:33:50 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-07-23 09:33:50 --> Database Driver Class Initialized
DEBUG - 2011-07-23 09:33:51 --> File loaded: application/views/table/main.php
DEBUG - 2011-07-23 09:33:51 --> Helper loaded: url_helper
DEBUG - 2011-07-23 09:33:51 --> File loaded: application/views/common/header.php
DEBUG - 2011-07-23 09:33:51 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-07-23 09:33:51 --> File loaded: application/views/common/footer.php
DEBUG - 2011-07-23 09:33:51 --> File loaded: application/views/layout/main.php
DEBUG - 2011-07-23 09:33:51 --> Final output sent to browser
DEBUG - 2011-07-23 09:33:51 --> Total execution time: 0.5752
DEBUG - 2011-07-23 09:33:55 --> Config Class Initialized
DEBUG - 2011-07-23 09:33:55 --> Hooks Class Initialized
DEBUG - 2011-07-23 09:33:55 --> Utf8 Class Initialized
DEBUG - 2011-07-23 09:33:55 --> UTF-8 Support Enabled
DEBUG - 2011-07-23 09:33:55 --> URI Class Initialized
DEBUG - 2011-07-23 09:33:55 --> Router Class Initialized
ERROR - 2011-07-23 09:33:55 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-07-23 09:34:15 --> Config Class Initialized
DEBUG - 2011-07-23 09:34:15 --> Hooks Class Initialized
DEBUG - 2011-07-23 09:34:15 --> Utf8 Class Initialized
DEBUG - 2011-07-23 09:34:15 --> UTF-8 Support Enabled
DEBUG - 2011-07-23 09:34:15 --> URI Class Initialized
DEBUG - 2011-07-23 09:34:15 --> Router Class Initialized
DEBUG - 2011-07-23 09:34:15 --> Output Class Initialized
DEBUG - 2011-07-23 09:34:15 --> Input Class Initialized
DEBUG - 2011-07-23 09:34:15 --> Global POST and COOKIE data sanitized
DEBUG - 2011-07-23 09:34:15 --> Language Class Initialized
DEBUG - 2011-07-23 09:34:15 --> Loader Class Initialized
DEBUG - 2011-07-23 09:34:15 --> Controller Class Initialized
DEBUG - 2011-07-23 09:34:15 --> Model Class Initialized
DEBUG - 2011-07-23 09:34:15 --> Model Class Initialized
DEBUG - 2011-07-23 09:34:15 --> Model Class Initialized
DEBUG - 2011-07-23 09:34:15 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-07-23 09:34:15 --> Database Driver Class Initialized
DEBUG - 2011-07-23 09:34:17 --> File loaded: application/views/table/main.php
DEBUG - 2011-07-23 09:34:17 --> Helper loaded: url_helper
DEBUG - 2011-07-23 09:34:17 --> File loaded: application/views/common/header.php
DEBUG - 2011-07-23 09:34:17 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-07-23 09:34:17 --> File loaded: application/views/common/footer.php
DEBUG - 2011-07-23 09:34:17 --> File loaded: application/views/layout/main.php
DEBUG - 2011-07-23 09:34:17 --> Final output sent to browser
DEBUG - 2011-07-23 09:34:17 --> Total execution time: 1.0869
DEBUG - 2011-07-23 09:34:19 --> Config Class Initialized
DEBUG - 2011-07-23 09:34:19 --> Hooks Class Initialized
DEBUG - 2011-07-23 09:34:19 --> Utf8 Class Initialized
DEBUG - 2011-07-23 09:34:19 --> UTF-8 Support Enabled
DEBUG - 2011-07-23 09:34:19 --> URI Class Initialized
DEBUG - 2011-07-23 09:34:19 --> Router Class Initialized
ERROR - 2011-07-23 09:34:19 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-07-23 09:34:19 --> Config Class Initialized
DEBUG - 2011-07-23 09:34:19 --> Hooks Class Initialized
DEBUG - 2011-07-23 09:34:19 --> Utf8 Class Initialized
DEBUG - 2011-07-23 09:34:19 --> UTF-8 Support Enabled
DEBUG - 2011-07-23 09:34:19 --> URI Class Initialized
DEBUG - 2011-07-23 09:34:19 --> Router Class Initialized
ERROR - 2011-07-23 09:34:19 --> 404 Page Not Found --> robots.txt
DEBUG - 2011-07-23 09:34:19 --> Config Class Initialized
DEBUG - 2011-07-23 09:34:19 --> Hooks Class Initialized
DEBUG - 2011-07-23 09:34:19 --> Utf8 Class Initialized
DEBUG - 2011-07-23 09:34:19 --> UTF-8 Support Enabled
DEBUG - 2011-07-23 09:34:19 --> URI Class Initialized
DEBUG - 2011-07-23 09:34:19 --> Router Class Initialized
DEBUG - 2011-07-23 09:34:19 --> Output Class Initialized
DEBUG - 2011-07-23 09:34:19 --> Input Class Initialized
DEBUG - 2011-07-23 09:34:19 --> Global POST and COOKIE data sanitized
DEBUG - 2011-07-23 09:34:19 --> Language Class Initialized
DEBUG - 2011-07-23 09:34:19 --> Loader Class Initialized
DEBUG - 2011-07-23 09:34:19 --> Controller Class Initialized
DEBUG - 2011-07-23 09:34:19 --> Model Class Initialized
DEBUG - 2011-07-23 09:34:19 --> Model Class Initialized
DEBUG - 2011-07-23 09:34:19 --> Model Class Initialized
DEBUG - 2011-07-23 09:34:19 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-07-23 09:34:19 --> Database Driver Class Initialized
DEBUG - 2011-07-23 09:34:19 --> File loaded: application/views/table/main.php
DEBUG - 2011-07-23 09:34:19 --> Helper loaded: url_helper
DEBUG - 2011-07-23 09:34:19 --> File loaded: application/views/common/header.php
DEBUG - 2011-07-23 09:34:19 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-07-23 09:34:19 --> File loaded: application/views/common/footer.php
DEBUG - 2011-07-23 09:34:19 --> File loaded: application/views/layout/main.php
DEBUG - 2011-07-23 09:34:19 --> Final output sent to browser
DEBUG - 2011-07-23 09:34:19 --> Total execution time: 0.0472
DEBUG - 2011-07-23 09:34:46 --> Config Class Initialized
DEBUG - 2011-07-23 09:34:46 --> Hooks Class Initialized
DEBUG - 2011-07-23 09:34:46 --> Utf8 Class Initialized
DEBUG - 2011-07-23 09:34:46 --> UTF-8 Support Enabled
DEBUG - 2011-07-23 09:34:46 --> URI Class Initialized
DEBUG - 2011-07-23 09:34:46 --> Router Class Initialized
DEBUG - 2011-07-23 09:34:46 --> Output Class Initialized
DEBUG - 2011-07-23 09:34:46 --> Input Class Initialized
DEBUG - 2011-07-23 09:34:46 --> Global POST and COOKIE data sanitized
DEBUG - 2011-07-23 09:34:46 --> Language Class Initialized
DEBUG - 2011-07-23 09:34:46 --> Loader Class Initialized
DEBUG - 2011-07-23 09:34:46 --> Controller Class Initialized
DEBUG - 2011-07-23 09:34:46 --> Model Class Initialized
DEBUG - 2011-07-23 09:34:46 --> Model Class Initialized
DEBUG - 2011-07-23 09:34:46 --> Model Class Initialized
DEBUG - 2011-07-23 09:34:46 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-07-23 09:34:46 --> Database Driver Class Initialized
DEBUG - 2011-07-23 09:34:48 --> File loaded: application/views/table/main.php
DEBUG - 2011-07-23 09:34:48 --> Helper loaded: url_helper
DEBUG - 2011-07-23 09:34:48 --> File loaded: application/views/common/header.php
DEBUG - 2011-07-23 09:34:48 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-07-23 09:34:48 --> File loaded: application/views/common/footer.php
DEBUG - 2011-07-23 09:34:48 --> File loaded: application/views/layout/main.php
DEBUG - 2011-07-23 09:34:48 --> Final output sent to browser
DEBUG - 2011-07-23 09:34:48 --> Total execution time: 1.4688
DEBUG - 2011-07-23 09:34:49 --> Config Class Initialized
DEBUG - 2011-07-23 09:34:49 --> Hooks Class Initialized
DEBUG - 2011-07-23 09:34:49 --> Utf8 Class Initialized
DEBUG - 2011-07-23 09:34:49 --> UTF-8 Support Enabled
DEBUG - 2011-07-23 09:34:49 --> URI Class Initialized
DEBUG - 2011-07-23 09:34:49 --> Router Class Initialized
ERROR - 2011-07-23 09:34:49 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-07-23 09:34:50 --> Config Class Initialized
DEBUG - 2011-07-23 09:34:50 --> Hooks Class Initialized
DEBUG - 2011-07-23 09:34:50 --> Utf8 Class Initialized
DEBUG - 2011-07-23 09:34:50 --> UTF-8 Support Enabled
DEBUG - 2011-07-23 09:34:50 --> URI Class Initialized
DEBUG - 2011-07-23 09:34:50 --> Router Class Initialized
DEBUG - 2011-07-23 09:34:50 --> Output Class Initialized
DEBUG - 2011-07-23 09:34:50 --> Input Class Initialized
DEBUG - 2011-07-23 09:34:50 --> Global POST and COOKIE data sanitized
DEBUG - 2011-07-23 09:34:50 --> Language Class Initialized
DEBUG - 2011-07-23 09:34:50 --> Loader Class Initialized
DEBUG - 2011-07-23 09:34:50 --> Controller Class Initialized
DEBUG - 2011-07-23 09:34:50 --> Model Class Initialized
DEBUG - 2011-07-23 09:34:50 --> Model Class Initialized
DEBUG - 2011-07-23 09:34:50 --> Model Class Initialized
DEBUG - 2011-07-23 09:34:50 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-07-23 09:34:50 --> Database Driver Class Initialized
DEBUG - 2011-07-23 09:34:50 --> File loaded: application/views/table/main.php
DEBUG - 2011-07-23 09:34:50 --> Helper loaded: url_helper
DEBUG - 2011-07-23 09:34:50 --> File loaded: application/views/common/header.php
DEBUG - 2011-07-23 09:34:50 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-07-23 09:34:50 --> File loaded: application/views/common/footer.php
DEBUG - 2011-07-23 09:34:50 --> File loaded: application/views/layout/main.php
DEBUG - 2011-07-23 09:34:50 --> Final output sent to browser
DEBUG - 2011-07-23 09:34:50 --> Total execution time: 0.0578
DEBUG - 2011-07-23 09:35:07 --> Config Class Initialized
DEBUG - 2011-07-23 09:35:07 --> Hooks Class Initialized
DEBUG - 2011-07-23 09:35:07 --> Utf8 Class Initialized
DEBUG - 2011-07-23 09:35:07 --> UTF-8 Support Enabled
DEBUG - 2011-07-23 09:35:07 --> URI Class Initialized
DEBUG - 2011-07-23 09:35:07 --> Router Class Initialized
DEBUG - 2011-07-23 09:35:07 --> Output Class Initialized
DEBUG - 2011-07-23 09:35:07 --> Input Class Initialized
DEBUG - 2011-07-23 09:35:07 --> Global POST and COOKIE data sanitized
DEBUG - 2011-07-23 09:35:07 --> Language Class Initialized
DEBUG - 2011-07-23 09:35:07 --> Loader Class Initialized
DEBUG - 2011-07-23 09:35:07 --> Controller Class Initialized
DEBUG - 2011-07-23 09:35:07 --> Model Class Initialized
DEBUG - 2011-07-23 09:35:07 --> Model Class Initialized
DEBUG - 2011-07-23 09:35:07 --> Model Class Initialized
DEBUG - 2011-07-23 09:35:07 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-07-23 09:35:07 --> Database Driver Class Initialized
DEBUG - 2011-07-23 09:35:07 --> File loaded: application/views/table/main.php
DEBUG - 2011-07-23 09:35:07 --> Helper loaded: url_helper
DEBUG - 2011-07-23 09:35:07 --> File loaded: application/views/common/header.php
DEBUG - 2011-07-23 09:35:07 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-07-23 09:35:07 --> File loaded: application/views/common/footer.php
DEBUG - 2011-07-23 09:35:07 --> File loaded: application/views/layout/main.php
DEBUG - 2011-07-23 09:35:07 --> Final output sent to browser
DEBUG - 2011-07-23 09:35:07 --> Total execution time: 0.4555
DEBUG - 2011-07-23 09:35:09 --> Config Class Initialized
DEBUG - 2011-07-23 09:35:09 --> Hooks Class Initialized
DEBUG - 2011-07-23 09:35:09 --> Utf8 Class Initialized
DEBUG - 2011-07-23 09:35:09 --> UTF-8 Support Enabled
DEBUG - 2011-07-23 09:35:09 --> URI Class Initialized
DEBUG - 2011-07-23 09:35:09 --> Router Class Initialized
DEBUG - 2011-07-23 09:35:09 --> Output Class Initialized
DEBUG - 2011-07-23 09:35:09 --> Input Class Initialized
DEBUG - 2011-07-23 09:35:09 --> Global POST and COOKIE data sanitized
DEBUG - 2011-07-23 09:35:09 --> Language Class Initialized
DEBUG - 2011-07-23 09:35:09 --> Loader Class Initialized
DEBUG - 2011-07-23 09:35:09 --> Controller Class Initialized
DEBUG - 2011-07-23 09:35:09 --> Model Class Initialized
DEBUG - 2011-07-23 09:35:09 --> Model Class Initialized
DEBUG - 2011-07-23 09:35:09 --> Model Class Initialized
DEBUG - 2011-07-23 09:35:09 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-07-23 09:35:09 --> Database Driver Class Initialized
DEBUG - 2011-07-23 09:35:09 --> File loaded: application/views/table/main.php
DEBUG - 2011-07-23 09:35:09 --> Helper loaded: url_helper
DEBUG - 2011-07-23 09:35:09 --> File loaded: application/views/common/header.php
DEBUG - 2011-07-23 09:35:09 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-07-23 09:35:09 --> File loaded: application/views/common/footer.php
DEBUG - 2011-07-23 09:35:09 --> File loaded: application/views/layout/main.php
DEBUG - 2011-07-23 09:35:09 --> Final output sent to browser
DEBUG - 2011-07-23 09:35:09 --> Total execution time: 0.0795
DEBUG - 2011-07-23 09:35:10 --> Config Class Initialized
DEBUG - 2011-07-23 09:35:10 --> Hooks Class Initialized
DEBUG - 2011-07-23 09:35:10 --> Utf8 Class Initialized
DEBUG - 2011-07-23 09:35:10 --> UTF-8 Support Enabled
DEBUG - 2011-07-23 09:35:10 --> URI Class Initialized
DEBUG - 2011-07-23 09:35:10 --> Router Class Initialized
ERROR - 2011-07-23 09:35:10 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-07-23 09:35:29 --> Config Class Initialized
DEBUG - 2011-07-23 09:35:29 --> Hooks Class Initialized
DEBUG - 2011-07-23 09:35:29 --> Utf8 Class Initialized
DEBUG - 2011-07-23 09:35:29 --> UTF-8 Support Enabled
DEBUG - 2011-07-23 09:35:29 --> URI Class Initialized
DEBUG - 2011-07-23 09:35:29 --> Router Class Initialized
DEBUG - 2011-07-23 09:35:29 --> Output Class Initialized
DEBUG - 2011-07-23 09:35:29 --> Input Class Initialized
DEBUG - 2011-07-23 09:35:29 --> Global POST and COOKIE data sanitized
DEBUG - 2011-07-23 09:35:29 --> Language Class Initialized
DEBUG - 2011-07-23 09:35:29 --> Loader Class Initialized
DEBUG - 2011-07-23 09:35:29 --> Controller Class Initialized
DEBUG - 2011-07-23 09:35:29 --> Model Class Initialized
DEBUG - 2011-07-23 09:35:29 --> Model Class Initialized
DEBUG - 2011-07-23 09:35:29 --> Model Class Initialized
DEBUG - 2011-07-23 09:35:29 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-07-23 09:35:29 --> Database Driver Class Initialized
DEBUG - 2011-07-23 09:35:30 --> File loaded: application/views/table/main.php
DEBUG - 2011-07-23 09:35:30 --> Helper loaded: url_helper
DEBUG - 2011-07-23 09:35:30 --> File loaded: application/views/common/header.php
DEBUG - 2011-07-23 09:35:30 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-07-23 09:35:30 --> File loaded: application/views/common/footer.php
DEBUG - 2011-07-23 09:35:30 --> File loaded: application/views/layout/main.php
DEBUG - 2011-07-23 09:35:30 --> Final output sent to browser
DEBUG - 2011-07-23 09:35:30 --> Total execution time: 0.9580
DEBUG - 2011-07-23 09:35:31 --> Config Class Initialized
DEBUG - 2011-07-23 09:35:31 --> Hooks Class Initialized
DEBUG - 2011-07-23 09:35:31 --> Utf8 Class Initialized
DEBUG - 2011-07-23 09:35:31 --> UTF-8 Support Enabled
DEBUG - 2011-07-23 09:35:31 --> URI Class Initialized
DEBUG - 2011-07-23 09:35:31 --> Router Class Initialized
DEBUG - 2011-07-23 09:35:31 --> Output Class Initialized
DEBUG - 2011-07-23 09:35:31 --> Input Class Initialized
DEBUG - 2011-07-23 09:35:31 --> Global POST and COOKIE data sanitized
DEBUG - 2011-07-23 09:35:31 --> Language Class Initialized
DEBUG - 2011-07-23 09:35:31 --> Loader Class Initialized
DEBUG - 2011-07-23 09:35:31 --> Controller Class Initialized
DEBUG - 2011-07-23 09:35:31 --> Model Class Initialized
DEBUG - 2011-07-23 09:35:31 --> Model Class Initialized
DEBUG - 2011-07-23 09:35:31 --> Model Class Initialized
DEBUG - 2011-07-23 09:35:31 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-07-23 09:35:31 --> Database Driver Class Initialized
DEBUG - 2011-07-23 09:35:31 --> File loaded: application/views/table/main.php
DEBUG - 2011-07-23 09:35:31 --> Helper loaded: url_helper
DEBUG - 2011-07-23 09:35:31 --> File loaded: application/views/common/header.php
DEBUG - 2011-07-23 09:35:31 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-07-23 09:35:31 --> File loaded: application/views/common/footer.php
DEBUG - 2011-07-23 09:35:31 --> File loaded: application/views/layout/main.php
DEBUG - 2011-07-23 09:35:31 --> Final output sent to browser
DEBUG - 2011-07-23 09:35:31 --> Total execution time: 0.0723
DEBUG - 2011-07-23 09:35:32 --> Config Class Initialized
DEBUG - 2011-07-23 09:35:32 --> Hooks Class Initialized
DEBUG - 2011-07-23 09:35:32 --> Utf8 Class Initialized
DEBUG - 2011-07-23 09:35:32 --> UTF-8 Support Enabled
DEBUG - 2011-07-23 09:35:32 --> URI Class Initialized
DEBUG - 2011-07-23 09:35:32 --> Router Class Initialized
ERROR - 2011-07-23 09:35:32 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-07-23 09:35:47 --> Config Class Initialized
DEBUG - 2011-07-23 09:35:47 --> Hooks Class Initialized
DEBUG - 2011-07-23 09:35:47 --> Utf8 Class Initialized
DEBUG - 2011-07-23 09:35:47 --> UTF-8 Support Enabled
DEBUG - 2011-07-23 09:35:47 --> URI Class Initialized
DEBUG - 2011-07-23 09:35:47 --> Router Class Initialized
DEBUG - 2011-07-23 09:35:47 --> Output Class Initialized
DEBUG - 2011-07-23 09:35:47 --> Input Class Initialized
DEBUG - 2011-07-23 09:35:47 --> Global POST and COOKIE data sanitized
DEBUG - 2011-07-23 09:35:47 --> Language Class Initialized
DEBUG - 2011-07-23 09:35:47 --> Loader Class Initialized
DEBUG - 2011-07-23 09:35:47 --> Controller Class Initialized
DEBUG - 2011-07-23 09:35:47 --> Model Class Initialized
DEBUG - 2011-07-23 09:35:47 --> Model Class Initialized
DEBUG - 2011-07-23 09:35:47 --> Model Class Initialized
DEBUG - 2011-07-23 09:35:47 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-07-23 09:35:47 --> Database Driver Class Initialized
DEBUG - 2011-07-23 09:35:47 --> File loaded: application/views/table/main.php
DEBUG - 2011-07-23 09:35:47 --> Helper loaded: url_helper
DEBUG - 2011-07-23 09:35:47 --> File loaded: application/views/common/header.php
DEBUG - 2011-07-23 09:35:47 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-07-23 09:35:47 --> File loaded: application/views/common/footer.php
DEBUG - 2011-07-23 09:35:47 --> File loaded: application/views/layout/main.php
DEBUG - 2011-07-23 09:35:47 --> Final output sent to browser
DEBUG - 2011-07-23 09:35:47 --> Total execution time: 0.0481
DEBUG - 2011-07-23 09:35:49 --> Config Class Initialized
DEBUG - 2011-07-23 09:35:49 --> Hooks Class Initialized
DEBUG - 2011-07-23 09:35:49 --> Utf8 Class Initialized
DEBUG - 2011-07-23 09:35:49 --> UTF-8 Support Enabled
DEBUG - 2011-07-23 09:35:49 --> URI Class Initialized
DEBUG - 2011-07-23 09:35:49 --> Router Class Initialized
ERROR - 2011-07-23 09:35:49 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-07-23 09:35:55 --> Config Class Initialized
DEBUG - 2011-07-23 09:35:55 --> Hooks Class Initialized
DEBUG - 2011-07-23 09:35:55 --> Utf8 Class Initialized
DEBUG - 2011-07-23 09:35:55 --> UTF-8 Support Enabled
DEBUG - 2011-07-23 09:35:55 --> URI Class Initialized
DEBUG - 2011-07-23 09:35:55 --> Router Class Initialized
DEBUG - 2011-07-23 09:35:55 --> Output Class Initialized
DEBUG - 2011-07-23 09:35:55 --> Input Class Initialized
DEBUG - 2011-07-23 09:35:55 --> Global POST and COOKIE data sanitized
DEBUG - 2011-07-23 09:35:55 --> Language Class Initialized
DEBUG - 2011-07-23 09:35:55 --> Loader Class Initialized
DEBUG - 2011-07-23 09:35:55 --> Controller Class Initialized
DEBUG - 2011-07-23 09:35:55 --> Model Class Initialized
DEBUG - 2011-07-23 09:35:55 --> Model Class Initialized
DEBUG - 2011-07-23 09:35:55 --> Model Class Initialized
DEBUG - 2011-07-23 09:35:55 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-07-23 09:35:55 --> Database Driver Class Initialized
DEBUG - 2011-07-23 09:35:55 --> File loaded: application/views/table/main.php
DEBUG - 2011-07-23 09:35:55 --> Helper loaded: url_helper
DEBUG - 2011-07-23 09:35:55 --> File loaded: application/views/common/header.php
DEBUG - 2011-07-23 09:35:55 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-07-23 09:35:55 --> File loaded: application/views/common/footer.php
DEBUG - 2011-07-23 09:35:55 --> File loaded: application/views/layout/main.php
DEBUG - 2011-07-23 09:35:55 --> Final output sent to browser
DEBUG - 2011-07-23 09:35:55 --> Total execution time: 0.2820
DEBUG - 2011-07-23 09:35:58 --> Config Class Initialized
DEBUG - 2011-07-23 09:35:58 --> Hooks Class Initialized
DEBUG - 2011-07-23 09:35:58 --> Utf8 Class Initialized
DEBUG - 2011-07-23 09:35:58 --> UTF-8 Support Enabled
DEBUG - 2011-07-23 09:35:58 --> URI Class Initialized
DEBUG - 2011-07-23 09:35:58 --> Router Class Initialized
DEBUG - 2011-07-23 09:35:58 --> Output Class Initialized
DEBUG - 2011-07-23 09:35:58 --> Input Class Initialized
DEBUG - 2011-07-23 09:35:58 --> Global POST and COOKIE data sanitized
DEBUG - 2011-07-23 09:35:58 --> Language Class Initialized
DEBUG - 2011-07-23 09:35:58 --> Loader Class Initialized
DEBUG - 2011-07-23 09:35:58 --> Controller Class Initialized
DEBUG - 2011-07-23 09:35:58 --> Model Class Initialized
DEBUG - 2011-07-23 09:35:58 --> Model Class Initialized
DEBUG - 2011-07-23 09:35:58 --> Model Class Initialized
DEBUG - 2011-07-23 09:35:58 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-07-23 09:35:58 --> Database Driver Class Initialized
DEBUG - 2011-07-23 09:35:58 --> File loaded: application/views/table/main.php
DEBUG - 2011-07-23 09:35:58 --> Helper loaded: url_helper
DEBUG - 2011-07-23 09:35:58 --> File loaded: application/views/common/header.php
DEBUG - 2011-07-23 09:35:58 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-07-23 09:35:58 --> File loaded: application/views/common/footer.php
DEBUG - 2011-07-23 09:35:58 --> File loaded: application/views/layout/main.php
DEBUG - 2011-07-23 09:35:58 --> Final output sent to browser
DEBUG - 2011-07-23 09:35:58 --> Total execution time: 0.3254
DEBUG - 2011-07-23 09:35:58 --> Config Class Initialized
DEBUG - 2011-07-23 09:35:58 --> Hooks Class Initialized
DEBUG - 2011-07-23 09:35:58 --> Utf8 Class Initialized
DEBUG - 2011-07-23 09:35:58 --> UTF-8 Support Enabled
DEBUG - 2011-07-23 09:35:58 --> URI Class Initialized
DEBUG - 2011-07-23 09:35:58 --> Router Class Initialized
ERROR - 2011-07-23 09:35:58 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-07-23 09:36:07 --> Config Class Initialized
DEBUG - 2011-07-23 09:36:07 --> Hooks Class Initialized
DEBUG - 2011-07-23 09:36:07 --> Utf8 Class Initialized
DEBUG - 2011-07-23 09:36:07 --> UTF-8 Support Enabled
DEBUG - 2011-07-23 09:36:07 --> URI Class Initialized
DEBUG - 2011-07-23 09:36:07 --> Router Class Initialized
DEBUG - 2011-07-23 09:36:07 --> Output Class Initialized
DEBUG - 2011-07-23 09:36:07 --> Input Class Initialized
DEBUG - 2011-07-23 09:36:07 --> Global POST and COOKIE data sanitized
DEBUG - 2011-07-23 09:36:07 --> Language Class Initialized
DEBUG - 2011-07-23 09:36:07 --> Loader Class Initialized
DEBUG - 2011-07-23 09:36:07 --> Controller Class Initialized
DEBUG - 2011-07-23 09:36:07 --> Model Class Initialized
DEBUG - 2011-07-23 09:36:07 --> Model Class Initialized
DEBUG - 2011-07-23 09:36:07 --> Model Class Initialized
DEBUG - 2011-07-23 09:36:07 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-07-23 09:36:07 --> Database Driver Class Initialized
DEBUG - 2011-07-23 09:36:07 --> File loaded: application/views/table/main.php
DEBUG - 2011-07-23 09:36:07 --> Helper loaded: url_helper
DEBUG - 2011-07-23 09:36:07 --> File loaded: application/views/common/header.php
DEBUG - 2011-07-23 09:36:07 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-07-23 09:36:07 --> File loaded: application/views/common/footer.php
DEBUG - 2011-07-23 09:36:07 --> File loaded: application/views/layout/main.php
DEBUG - 2011-07-23 09:36:07 --> Final output sent to browser
DEBUG - 2011-07-23 09:36:07 --> Total execution time: 0.2456
DEBUG - 2011-07-23 09:36:08 --> Config Class Initialized
DEBUG - 2011-07-23 09:36:08 --> Hooks Class Initialized
DEBUG - 2011-07-23 09:36:08 --> Utf8 Class Initialized
DEBUG - 2011-07-23 09:36:08 --> UTF-8 Support Enabled
DEBUG - 2011-07-23 09:36:08 --> URI Class Initialized
DEBUG - 2011-07-23 09:36:08 --> Router Class Initialized
DEBUG - 2011-07-23 09:36:08 --> Output Class Initialized
DEBUG - 2011-07-23 09:36:08 --> Input Class Initialized
DEBUG - 2011-07-23 09:36:08 --> Global POST and COOKIE data sanitized
DEBUG - 2011-07-23 09:36:08 --> Language Class Initialized
DEBUG - 2011-07-23 09:36:08 --> Loader Class Initialized
DEBUG - 2011-07-23 09:36:08 --> Controller Class Initialized
DEBUG - 2011-07-23 09:36:08 --> Model Class Initialized
DEBUG - 2011-07-23 09:36:08 --> Model Class Initialized
DEBUG - 2011-07-23 09:36:08 --> Model Class Initialized
DEBUG - 2011-07-23 09:36:08 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-07-23 09:36:08 --> Database Driver Class Initialized
DEBUG - 2011-07-23 09:36:08 --> File loaded: application/views/table/main.php
DEBUG - 2011-07-23 09:36:08 --> Helper loaded: url_helper
DEBUG - 2011-07-23 09:36:08 --> File loaded: application/views/common/header.php
DEBUG - 2011-07-23 09:36:08 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-07-23 09:36:08 --> File loaded: application/views/common/footer.php
DEBUG - 2011-07-23 09:36:08 --> File loaded: application/views/layout/main.php
DEBUG - 2011-07-23 09:36:08 --> Final output sent to browser
DEBUG - 2011-07-23 09:36:08 --> Total execution time: 0.0467
DEBUG - 2011-07-23 09:36:09 --> Config Class Initialized
DEBUG - 2011-07-23 09:36:09 --> Hooks Class Initialized
DEBUG - 2011-07-23 09:36:09 --> Utf8 Class Initialized
DEBUG - 2011-07-23 09:36:09 --> UTF-8 Support Enabled
DEBUG - 2011-07-23 09:36:09 --> URI Class Initialized
DEBUG - 2011-07-23 09:36:09 --> Router Class Initialized
ERROR - 2011-07-23 09:36:09 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-07-23 09:36:21 --> Config Class Initialized
DEBUG - 2011-07-23 09:36:21 --> Hooks Class Initialized
DEBUG - 2011-07-23 09:36:21 --> Utf8 Class Initialized
DEBUG - 2011-07-23 09:36:21 --> UTF-8 Support Enabled
DEBUG - 2011-07-23 09:36:21 --> URI Class Initialized
DEBUG - 2011-07-23 09:36:21 --> Router Class Initialized
DEBUG - 2011-07-23 09:36:21 --> Output Class Initialized
DEBUG - 2011-07-23 09:36:21 --> Input Class Initialized
DEBUG - 2011-07-23 09:36:21 --> Global POST and COOKIE data sanitized
DEBUG - 2011-07-23 09:36:21 --> Language Class Initialized
DEBUG - 2011-07-23 09:36:21 --> Loader Class Initialized
DEBUG - 2011-07-23 09:36:21 --> Controller Class Initialized
DEBUG - 2011-07-23 09:36:21 --> Model Class Initialized
DEBUG - 2011-07-23 09:36:21 --> Model Class Initialized
DEBUG - 2011-07-23 09:36:21 --> Model Class Initialized
DEBUG - 2011-07-23 09:36:21 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-07-23 09:36:21 --> Database Driver Class Initialized
DEBUG - 2011-07-23 09:36:22 --> File loaded: application/views/table/main.php
DEBUG - 2011-07-23 09:36:22 --> Helper loaded: url_helper
DEBUG - 2011-07-23 09:36:22 --> File loaded: application/views/common/header.php
DEBUG - 2011-07-23 09:36:22 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-07-23 09:36:22 --> File loaded: application/views/common/footer.php
DEBUG - 2011-07-23 09:36:22 --> File loaded: application/views/layout/main.php
DEBUG - 2011-07-23 09:36:22 --> Final output sent to browser
DEBUG - 2011-07-23 09:36:22 --> Total execution time: 0.5149
DEBUG - 2011-07-23 09:36:23 --> Config Class Initialized
DEBUG - 2011-07-23 09:36:23 --> Hooks Class Initialized
DEBUG - 2011-07-23 09:36:23 --> Utf8 Class Initialized
DEBUG - 2011-07-23 09:36:23 --> UTF-8 Support Enabled
DEBUG - 2011-07-23 09:36:23 --> URI Class Initialized
DEBUG - 2011-07-23 09:36:23 --> Router Class Initialized
DEBUG - 2011-07-23 09:36:23 --> Output Class Initialized
DEBUG - 2011-07-23 09:36:23 --> Input Class Initialized
DEBUG - 2011-07-23 09:36:23 --> Global POST and COOKIE data sanitized
DEBUG - 2011-07-23 09:36:23 --> Language Class Initialized
DEBUG - 2011-07-23 09:36:23 --> Loader Class Initialized
DEBUG - 2011-07-23 09:36:23 --> Controller Class Initialized
DEBUG - 2011-07-23 09:36:23 --> Model Class Initialized
DEBUG - 2011-07-23 09:36:23 --> Model Class Initialized
DEBUG - 2011-07-23 09:36:23 --> Model Class Initialized
DEBUG - 2011-07-23 09:36:23 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-07-23 09:36:23 --> Database Driver Class Initialized
DEBUG - 2011-07-23 09:36:23 --> File loaded: application/views/table/main.php
DEBUG - 2011-07-23 09:36:23 --> Helper loaded: url_helper
DEBUG - 2011-07-23 09:36:23 --> File loaded: application/views/common/header.php
DEBUG - 2011-07-23 09:36:23 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-07-23 09:36:23 --> File loaded: application/views/common/footer.php
DEBUG - 2011-07-23 09:36:23 --> File loaded: application/views/layout/main.php
DEBUG - 2011-07-23 09:36:23 --> Final output sent to browser
DEBUG - 2011-07-23 09:36:23 --> Total execution time: 0.0495
DEBUG - 2011-07-23 09:36:24 --> Config Class Initialized
DEBUG - 2011-07-23 09:36:24 --> Hooks Class Initialized
DEBUG - 2011-07-23 09:36:24 --> Utf8 Class Initialized
DEBUG - 2011-07-23 09:36:24 --> UTF-8 Support Enabled
DEBUG - 2011-07-23 09:36:24 --> URI Class Initialized
DEBUG - 2011-07-23 09:36:24 --> Router Class Initialized
ERROR - 2011-07-23 09:36:24 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-07-23 09:36:44 --> Config Class Initialized
DEBUG - 2011-07-23 09:36:44 --> Hooks Class Initialized
DEBUG - 2011-07-23 09:36:44 --> Utf8 Class Initialized
DEBUG - 2011-07-23 09:36:44 --> UTF-8 Support Enabled
DEBUG - 2011-07-23 09:36:44 --> URI Class Initialized
DEBUG - 2011-07-23 09:36:44 --> Router Class Initialized
DEBUG - 2011-07-23 09:36:44 --> Output Class Initialized
DEBUG - 2011-07-23 09:36:44 --> Input Class Initialized
DEBUG - 2011-07-23 09:36:44 --> Global POST and COOKIE data sanitized
DEBUG - 2011-07-23 09:36:44 --> Language Class Initialized
DEBUG - 2011-07-23 09:36:44 --> Loader Class Initialized
DEBUG - 2011-07-23 09:36:44 --> Controller Class Initialized
DEBUG - 2011-07-23 09:36:44 --> Model Class Initialized
DEBUG - 2011-07-23 09:36:44 --> Model Class Initialized
DEBUG - 2011-07-23 09:36:44 --> Model Class Initialized
DEBUG - 2011-07-23 09:36:44 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-07-23 09:36:44 --> Database Driver Class Initialized
DEBUG - 2011-07-23 09:36:45 --> File loaded: application/views/table/main.php
DEBUG - 2011-07-23 09:36:45 --> Helper loaded: url_helper
DEBUG - 2011-07-23 09:36:45 --> File loaded: application/views/common/header.php
DEBUG - 2011-07-23 09:36:45 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-07-23 09:36:45 --> File loaded: application/views/common/footer.php
DEBUG - 2011-07-23 09:36:45 --> File loaded: application/views/layout/main.php
DEBUG - 2011-07-23 09:36:45 --> Final output sent to browser
DEBUG - 2011-07-23 09:36:45 --> Total execution time: 0.5721
DEBUG - 2011-07-23 09:36:46 --> Config Class Initialized
DEBUG - 2011-07-23 09:36:46 --> Hooks Class Initialized
DEBUG - 2011-07-23 09:36:46 --> Utf8 Class Initialized
DEBUG - 2011-07-23 09:36:46 --> UTF-8 Support Enabled
DEBUG - 2011-07-23 09:36:46 --> URI Class Initialized
DEBUG - 2011-07-23 09:36:46 --> Router Class Initialized
DEBUG - 2011-07-23 09:36:46 --> Output Class Initialized
DEBUG - 2011-07-23 09:36:46 --> Input Class Initialized
DEBUG - 2011-07-23 09:36:46 --> Global POST and COOKIE data sanitized
DEBUG - 2011-07-23 09:36:46 --> Language Class Initialized
DEBUG - 2011-07-23 09:36:46 --> Loader Class Initialized
DEBUG - 2011-07-23 09:36:46 --> Controller Class Initialized
DEBUG - 2011-07-23 09:36:46 --> Model Class Initialized
DEBUG - 2011-07-23 09:36:46 --> Model Class Initialized
DEBUG - 2011-07-23 09:36:46 --> Model Class Initialized
DEBUG - 2011-07-23 09:36:46 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-07-23 09:36:46 --> Database Driver Class Initialized
DEBUG - 2011-07-23 09:36:46 --> File loaded: application/views/table/main.php
DEBUG - 2011-07-23 09:36:46 --> Helper loaded: url_helper
DEBUG - 2011-07-23 09:36:46 --> File loaded: application/views/common/header.php
DEBUG - 2011-07-23 09:36:46 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-07-23 09:36:46 --> File loaded: application/views/common/footer.php
DEBUG - 2011-07-23 09:36:46 --> File loaded: application/views/layout/main.php
DEBUG - 2011-07-23 09:36:46 --> Final output sent to browser
DEBUG - 2011-07-23 09:36:46 --> Total execution time: 0.0487
DEBUG - 2011-07-23 09:36:47 --> Config Class Initialized
DEBUG - 2011-07-23 09:36:47 --> Hooks Class Initialized
DEBUG - 2011-07-23 09:36:47 --> Utf8 Class Initialized
DEBUG - 2011-07-23 09:36:47 --> UTF-8 Support Enabled
DEBUG - 2011-07-23 09:36:47 --> URI Class Initialized
DEBUG - 2011-07-23 09:36:47 --> Router Class Initialized
ERROR - 2011-07-23 09:36:47 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-07-23 09:36:59 --> Config Class Initialized
DEBUG - 2011-07-23 09:36:59 --> Hooks Class Initialized
DEBUG - 2011-07-23 09:36:59 --> Utf8 Class Initialized
DEBUG - 2011-07-23 09:36:59 --> UTF-8 Support Enabled
DEBUG - 2011-07-23 09:36:59 --> URI Class Initialized
DEBUG - 2011-07-23 09:36:59 --> Router Class Initialized
DEBUG - 2011-07-23 09:36:59 --> Output Class Initialized
DEBUG - 2011-07-23 09:36:59 --> Input Class Initialized
DEBUG - 2011-07-23 09:36:59 --> Global POST and COOKIE data sanitized
DEBUG - 2011-07-23 09:36:59 --> Language Class Initialized
DEBUG - 2011-07-23 09:36:59 --> Loader Class Initialized
DEBUG - 2011-07-23 09:36:59 --> Controller Class Initialized
DEBUG - 2011-07-23 09:36:59 --> Model Class Initialized
DEBUG - 2011-07-23 09:36:59 --> Model Class Initialized
DEBUG - 2011-07-23 09:36:59 --> Model Class Initialized
DEBUG - 2011-07-23 09:36:59 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-07-23 09:36:59 --> Database Driver Class Initialized
DEBUG - 2011-07-23 09:36:59 --> File loaded: application/views/table/main.php
DEBUG - 2011-07-23 09:36:59 --> Helper loaded: url_helper
DEBUG - 2011-07-23 09:36:59 --> File loaded: application/views/common/header.php
DEBUG - 2011-07-23 09:36:59 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-07-23 09:36:59 --> File loaded: application/views/common/footer.php
DEBUG - 2011-07-23 09:36:59 --> File loaded: application/views/layout/main.php
DEBUG - 2011-07-23 09:36:59 --> Final output sent to browser
DEBUG - 2011-07-23 09:36:59 --> Total execution time: 0.3187
DEBUG - 2011-07-23 09:37:01 --> Config Class Initialized
DEBUG - 2011-07-23 09:37:01 --> Hooks Class Initialized
DEBUG - 2011-07-23 09:37:01 --> Utf8 Class Initialized
DEBUG - 2011-07-23 09:37:01 --> UTF-8 Support Enabled
DEBUG - 2011-07-23 09:37:01 --> URI Class Initialized
DEBUG - 2011-07-23 09:37:01 --> Router Class Initialized
DEBUG - 2011-07-23 09:37:01 --> Output Class Initialized
DEBUG - 2011-07-23 09:37:01 --> Input Class Initialized
DEBUG - 2011-07-23 09:37:01 --> Global POST and COOKIE data sanitized
DEBUG - 2011-07-23 09:37:01 --> Language Class Initialized
DEBUG - 2011-07-23 09:37:01 --> Loader Class Initialized
DEBUG - 2011-07-23 09:37:01 --> Controller Class Initialized
DEBUG - 2011-07-23 09:37:01 --> Model Class Initialized
DEBUG - 2011-07-23 09:37:01 --> Model Class Initialized
DEBUG - 2011-07-23 09:37:01 --> Model Class Initialized
DEBUG - 2011-07-23 09:37:01 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-07-23 09:37:01 --> Database Driver Class Initialized
DEBUG - 2011-07-23 09:37:01 --> File loaded: application/views/table/main.php
DEBUG - 2011-07-23 09:37:01 --> Helper loaded: url_helper
DEBUG - 2011-07-23 09:37:01 --> File loaded: application/views/common/header.php
DEBUG - 2011-07-23 09:37:01 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-07-23 09:37:01 --> File loaded: application/views/common/footer.php
DEBUG - 2011-07-23 09:37:01 --> File loaded: application/views/layout/main.php
DEBUG - 2011-07-23 09:37:01 --> Final output sent to browser
DEBUG - 2011-07-23 09:37:01 --> Total execution time: 0.1061
DEBUG - 2011-07-23 09:37:02 --> Config Class Initialized
DEBUG - 2011-07-23 09:37:02 --> Hooks Class Initialized
DEBUG - 2011-07-23 09:37:02 --> Utf8 Class Initialized
DEBUG - 2011-07-23 09:37:02 --> UTF-8 Support Enabled
DEBUG - 2011-07-23 09:37:02 --> URI Class Initialized
DEBUG - 2011-07-23 09:37:02 --> Router Class Initialized
ERROR - 2011-07-23 09:37:02 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-07-23 09:37:09 --> Config Class Initialized
DEBUG - 2011-07-23 09:37:09 --> Hooks Class Initialized
DEBUG - 2011-07-23 09:37:09 --> Utf8 Class Initialized
DEBUG - 2011-07-23 09:37:09 --> UTF-8 Support Enabled
DEBUG - 2011-07-23 09:37:09 --> URI Class Initialized
DEBUG - 2011-07-23 09:37:09 --> Router Class Initialized
DEBUG - 2011-07-23 09:37:09 --> Output Class Initialized
DEBUG - 2011-07-23 09:37:09 --> Input Class Initialized
DEBUG - 2011-07-23 09:37:09 --> Global POST and COOKIE data sanitized
DEBUG - 2011-07-23 09:37:09 --> Language Class Initialized
DEBUG - 2011-07-23 09:37:09 --> Loader Class Initialized
DEBUG - 2011-07-23 09:37:09 --> Controller Class Initialized
DEBUG - 2011-07-23 09:37:09 --> Model Class Initialized
DEBUG - 2011-07-23 09:37:09 --> Model Class Initialized
DEBUG - 2011-07-23 09:37:09 --> Model Class Initialized
DEBUG - 2011-07-23 09:37:09 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-07-23 09:37:09 --> Database Driver Class Initialized
DEBUG - 2011-07-23 09:37:10 --> File loaded: application/views/table/main.php
DEBUG - 2011-07-23 09:37:10 --> Helper loaded: url_helper
DEBUG - 2011-07-23 09:37:10 --> File loaded: application/views/common/header.php
DEBUG - 2011-07-23 09:37:10 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-07-23 09:37:10 --> File loaded: application/views/common/footer.php
DEBUG - 2011-07-23 09:37:10 --> File loaded: application/views/layout/main.php
DEBUG - 2011-07-23 09:37:10 --> Final output sent to browser
DEBUG - 2011-07-23 09:37:10 --> Total execution time: 0.4320
DEBUG - 2011-07-23 09:37:11 --> Config Class Initialized
DEBUG - 2011-07-23 09:37:11 --> Hooks Class Initialized
DEBUG - 2011-07-23 09:37:11 --> Utf8 Class Initialized
DEBUG - 2011-07-23 09:37:11 --> UTF-8 Support Enabled
DEBUG - 2011-07-23 09:37:11 --> URI Class Initialized
DEBUG - 2011-07-23 09:37:11 --> Router Class Initialized
DEBUG - 2011-07-23 09:37:11 --> Output Class Initialized
DEBUG - 2011-07-23 09:37:11 --> Input Class Initialized
DEBUG - 2011-07-23 09:37:11 --> Global POST and COOKIE data sanitized
DEBUG - 2011-07-23 09:37:11 --> Language Class Initialized
DEBUG - 2011-07-23 09:37:11 --> Loader Class Initialized
DEBUG - 2011-07-23 09:37:11 --> Controller Class Initialized
DEBUG - 2011-07-23 09:37:11 --> Model Class Initialized
DEBUG - 2011-07-23 09:37:11 --> Model Class Initialized
DEBUG - 2011-07-23 09:37:11 --> Model Class Initialized
DEBUG - 2011-07-23 09:37:11 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-07-23 09:37:11 --> Database Driver Class Initialized
DEBUG - 2011-07-23 09:37:11 --> File loaded: application/views/table/main.php
DEBUG - 2011-07-23 09:37:11 --> Helper loaded: url_helper
DEBUG - 2011-07-23 09:37:11 --> File loaded: application/views/common/header.php
DEBUG - 2011-07-23 09:37:11 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-07-23 09:37:11 --> File loaded: application/views/common/footer.php
DEBUG - 2011-07-23 09:37:11 --> File loaded: application/views/layout/main.php
DEBUG - 2011-07-23 09:37:11 --> Final output sent to browser
DEBUG - 2011-07-23 09:37:11 --> Total execution time: 0.0641
DEBUG - 2011-07-23 09:37:12 --> Config Class Initialized
DEBUG - 2011-07-23 09:37:12 --> Hooks Class Initialized
DEBUG - 2011-07-23 09:37:12 --> Utf8 Class Initialized
DEBUG - 2011-07-23 09:37:12 --> UTF-8 Support Enabled
DEBUG - 2011-07-23 09:37:12 --> URI Class Initialized
DEBUG - 2011-07-23 09:37:12 --> Router Class Initialized
ERROR - 2011-07-23 09:37:12 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-07-23 09:37:17 --> Config Class Initialized
DEBUG - 2011-07-23 09:37:17 --> Hooks Class Initialized
DEBUG - 2011-07-23 09:37:17 --> Utf8 Class Initialized
DEBUG - 2011-07-23 09:37:17 --> UTF-8 Support Enabled
DEBUG - 2011-07-23 09:37:17 --> URI Class Initialized
DEBUG - 2011-07-23 09:37:17 --> Router Class Initialized
DEBUG - 2011-07-23 09:37:17 --> Output Class Initialized
DEBUG - 2011-07-23 09:37:17 --> Input Class Initialized
DEBUG - 2011-07-23 09:37:17 --> Global POST and COOKIE data sanitized
DEBUG - 2011-07-23 09:37:17 --> Language Class Initialized
DEBUG - 2011-07-23 09:37:17 --> Loader Class Initialized
DEBUG - 2011-07-23 09:37:17 --> Controller Class Initialized
DEBUG - 2011-07-23 09:37:17 --> Model Class Initialized
DEBUG - 2011-07-23 09:37:17 --> Model Class Initialized
DEBUG - 2011-07-23 09:37:17 --> Model Class Initialized
DEBUG - 2011-07-23 09:37:17 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-07-23 09:37:17 --> Database Driver Class Initialized
DEBUG - 2011-07-23 09:37:18 --> File loaded: application/views/table/main.php
DEBUG - 2011-07-23 09:37:18 --> Helper loaded: url_helper
DEBUG - 2011-07-23 09:37:18 --> File loaded: application/views/common/header.php
DEBUG - 2011-07-23 09:37:18 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-07-23 09:37:18 --> File loaded: application/views/common/footer.php
DEBUG - 2011-07-23 09:37:18 --> File loaded: application/views/layout/main.php
DEBUG - 2011-07-23 09:37:18 --> Final output sent to browser
DEBUG - 2011-07-23 09:37:18 --> Total execution time: 0.8886
DEBUG - 2011-07-23 09:37:19 --> Config Class Initialized
DEBUG - 2011-07-23 09:37:19 --> Hooks Class Initialized
DEBUG - 2011-07-23 09:37:19 --> Utf8 Class Initialized
DEBUG - 2011-07-23 09:37:19 --> UTF-8 Support Enabled
DEBUG - 2011-07-23 09:37:19 --> URI Class Initialized
DEBUG - 2011-07-23 09:37:19 --> Router Class Initialized
DEBUG - 2011-07-23 09:37:19 --> Output Class Initialized
DEBUG - 2011-07-23 09:37:19 --> Input Class Initialized
DEBUG - 2011-07-23 09:37:19 --> Global POST and COOKIE data sanitized
DEBUG - 2011-07-23 09:37:19 --> Language Class Initialized
DEBUG - 2011-07-23 09:37:19 --> Loader Class Initialized
DEBUG - 2011-07-23 09:37:19 --> Controller Class Initialized
DEBUG - 2011-07-23 09:37:19 --> Model Class Initialized
DEBUG - 2011-07-23 09:37:19 --> Model Class Initialized
DEBUG - 2011-07-23 09:37:19 --> Model Class Initialized
DEBUG - 2011-07-23 09:37:19 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-07-23 09:37:19 --> Database Driver Class Initialized
DEBUG - 2011-07-23 09:37:19 --> File loaded: application/views/table/main.php
DEBUG - 2011-07-23 09:37:19 --> Helper loaded: url_helper
DEBUG - 2011-07-23 09:37:19 --> File loaded: application/views/common/header.php
DEBUG - 2011-07-23 09:37:19 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-07-23 09:37:19 --> File loaded: application/views/common/footer.php
DEBUG - 2011-07-23 09:37:19 --> File loaded: application/views/layout/main.php
DEBUG - 2011-07-23 09:37:19 --> Final output sent to browser
DEBUG - 2011-07-23 09:37:19 --> Total execution time: 0.0432
DEBUG - 2011-07-23 09:37:20 --> Config Class Initialized
DEBUG - 2011-07-23 09:37:20 --> Hooks Class Initialized
DEBUG - 2011-07-23 09:37:20 --> Utf8 Class Initialized
DEBUG - 2011-07-23 09:37:20 --> UTF-8 Support Enabled
DEBUG - 2011-07-23 09:37:20 --> URI Class Initialized
DEBUG - 2011-07-23 09:37:20 --> Router Class Initialized
ERROR - 2011-07-23 09:37:20 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-07-23 09:37:37 --> Config Class Initialized
DEBUG - 2011-07-23 09:37:37 --> Hooks Class Initialized
DEBUG - 2011-07-23 09:37:37 --> Utf8 Class Initialized
DEBUG - 2011-07-23 09:37:37 --> UTF-8 Support Enabled
DEBUG - 2011-07-23 09:37:37 --> URI Class Initialized
DEBUG - 2011-07-23 09:37:37 --> Router Class Initialized
DEBUG - 2011-07-23 09:37:37 --> Output Class Initialized
DEBUG - 2011-07-23 09:37:37 --> Input Class Initialized
DEBUG - 2011-07-23 09:37:37 --> Global POST and COOKIE data sanitized
DEBUG - 2011-07-23 09:37:37 --> Language Class Initialized
DEBUG - 2011-07-23 09:37:37 --> Loader Class Initialized
DEBUG - 2011-07-23 09:37:37 --> Controller Class Initialized
DEBUG - 2011-07-23 09:37:37 --> Model Class Initialized
DEBUG - 2011-07-23 09:37:37 --> Model Class Initialized
DEBUG - 2011-07-23 09:37:37 --> Model Class Initialized
DEBUG - 2011-07-23 09:37:37 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-07-23 09:37:37 --> Database Driver Class Initialized
DEBUG - 2011-07-23 09:37:37 --> File loaded: application/views/table/main.php
DEBUG - 2011-07-23 09:37:37 --> Helper loaded: url_helper
DEBUG - 2011-07-23 09:37:37 --> File loaded: application/views/common/header.php
DEBUG - 2011-07-23 09:37:37 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-07-23 09:37:37 --> File loaded: application/views/common/footer.php
DEBUG - 2011-07-23 09:37:37 --> File loaded: application/views/layout/main.php
DEBUG - 2011-07-23 09:37:37 --> Final output sent to browser
DEBUG - 2011-07-23 09:37:37 --> Total execution time: 0.4059
DEBUG - 2011-07-23 09:37:38 --> Config Class Initialized
DEBUG - 2011-07-23 09:37:38 --> Hooks Class Initialized
DEBUG - 2011-07-23 09:37:38 --> Utf8 Class Initialized
DEBUG - 2011-07-23 09:37:38 --> UTF-8 Support Enabled
DEBUG - 2011-07-23 09:37:38 --> URI Class Initialized
DEBUG - 2011-07-23 09:37:38 --> Router Class Initialized
DEBUG - 2011-07-23 09:37:38 --> Output Class Initialized
DEBUG - 2011-07-23 09:37:38 --> Input Class Initialized
DEBUG - 2011-07-23 09:37:38 --> Global POST and COOKIE data sanitized
DEBUG - 2011-07-23 09:37:38 --> Language Class Initialized
DEBUG - 2011-07-23 09:37:38 --> Loader Class Initialized
DEBUG - 2011-07-23 09:37:38 --> Controller Class Initialized
DEBUG - 2011-07-23 09:37:38 --> Model Class Initialized
DEBUG - 2011-07-23 09:37:38 --> Model Class Initialized
DEBUG - 2011-07-23 09:37:38 --> Model Class Initialized
DEBUG - 2011-07-23 09:37:38 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-07-23 09:37:38 --> Database Driver Class Initialized
DEBUG - 2011-07-23 09:37:38 --> File loaded: application/views/table/main.php
DEBUG - 2011-07-23 09:37:38 --> Helper loaded: url_helper
DEBUG - 2011-07-23 09:37:38 --> File loaded: application/views/common/header.php
DEBUG - 2011-07-23 09:37:38 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-07-23 09:37:38 --> File loaded: application/views/common/footer.php
DEBUG - 2011-07-23 09:37:38 --> File loaded: application/views/layout/main.php
DEBUG - 2011-07-23 09:37:38 --> Final output sent to browser
DEBUG - 2011-07-23 09:37:38 --> Total execution time: 0.1020
DEBUG - 2011-07-23 09:37:39 --> Config Class Initialized
DEBUG - 2011-07-23 09:37:39 --> Hooks Class Initialized
DEBUG - 2011-07-23 09:37:39 --> Utf8 Class Initialized
DEBUG - 2011-07-23 09:37:39 --> UTF-8 Support Enabled
DEBUG - 2011-07-23 09:37:39 --> URI Class Initialized
DEBUG - 2011-07-23 09:37:39 --> Router Class Initialized
ERROR - 2011-07-23 09:37:39 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-07-23 09:38:41 --> Config Class Initialized
DEBUG - 2011-07-23 09:38:41 --> Hooks Class Initialized
DEBUG - 2011-07-23 09:38:41 --> Utf8 Class Initialized
DEBUG - 2011-07-23 09:38:41 --> UTF-8 Support Enabled
DEBUG - 2011-07-23 09:38:41 --> URI Class Initialized
DEBUG - 2011-07-23 09:38:41 --> Router Class Initialized
DEBUG - 2011-07-23 09:38:41 --> Output Class Initialized
DEBUG - 2011-07-23 09:38:41 --> Input Class Initialized
DEBUG - 2011-07-23 09:38:41 --> Global POST and COOKIE data sanitized
DEBUG - 2011-07-23 09:38:41 --> Language Class Initialized
DEBUG - 2011-07-23 09:38:41 --> Loader Class Initialized
DEBUG - 2011-07-23 09:38:41 --> Controller Class Initialized
DEBUG - 2011-07-23 09:38:41 --> Model Class Initialized
DEBUG - 2011-07-23 09:38:41 --> Model Class Initialized
DEBUG - 2011-07-23 09:38:41 --> Model Class Initialized
DEBUG - 2011-07-23 09:38:41 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-07-23 09:38:41 --> Database Driver Class Initialized
DEBUG - 2011-07-23 09:38:41 --> File loaded: application/views/table/main.php
DEBUG - 2011-07-23 09:38:41 --> Helper loaded: url_helper
DEBUG - 2011-07-23 09:38:41 --> File loaded: application/views/common/header.php
DEBUG - 2011-07-23 09:38:41 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-07-23 09:38:41 --> File loaded: application/views/common/footer.php
DEBUG - 2011-07-23 09:38:41 --> File loaded: application/views/layout/main.php
DEBUG - 2011-07-23 09:38:41 --> Final output sent to browser
DEBUG - 2011-07-23 09:38:41 --> Total execution time: 0.4586
DEBUG - 2011-07-23 09:38:47 --> Config Class Initialized
DEBUG - 2011-07-23 09:38:47 --> Hooks Class Initialized
DEBUG - 2011-07-23 09:38:47 --> Utf8 Class Initialized
DEBUG - 2011-07-23 09:38:47 --> UTF-8 Support Enabled
DEBUG - 2011-07-23 09:38:47 --> URI Class Initialized
DEBUG - 2011-07-23 09:38:47 --> Router Class Initialized
DEBUG - 2011-07-23 09:38:47 --> Output Class Initialized
DEBUG - 2011-07-23 09:38:47 --> Input Class Initialized
DEBUG - 2011-07-23 09:38:47 --> Global POST and COOKIE data sanitized
DEBUG - 2011-07-23 09:38:47 --> Language Class Initialized
DEBUG - 2011-07-23 09:38:47 --> Loader Class Initialized
DEBUG - 2011-07-23 09:38:47 --> Controller Class Initialized
DEBUG - 2011-07-23 09:38:47 --> Model Class Initialized
DEBUG - 2011-07-23 09:38:47 --> Model Class Initialized
DEBUG - 2011-07-23 09:38:47 --> Model Class Initialized
DEBUG - 2011-07-23 09:38:47 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-07-23 09:38:47 --> Database Driver Class Initialized
DEBUG - 2011-07-23 09:38:47 --> File loaded: application/views/table/main.php
DEBUG - 2011-07-23 09:38:47 --> Helper loaded: url_helper
DEBUG - 2011-07-23 09:38:47 --> File loaded: application/views/common/header.php
DEBUG - 2011-07-23 09:38:47 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-07-23 09:38:47 --> File loaded: application/views/common/footer.php
DEBUG - 2011-07-23 09:38:47 --> File loaded: application/views/layout/main.php
DEBUG - 2011-07-23 09:38:47 --> Final output sent to browser
DEBUG - 2011-07-23 09:38:47 --> Total execution time: 0.0632
DEBUG - 2011-07-23 09:38:48 --> Config Class Initialized
DEBUG - 2011-07-23 09:38:48 --> Hooks Class Initialized
DEBUG - 2011-07-23 09:38:48 --> Utf8 Class Initialized
DEBUG - 2011-07-23 09:38:48 --> UTF-8 Support Enabled
DEBUG - 2011-07-23 09:38:48 --> URI Class Initialized
DEBUG - 2011-07-23 09:38:48 --> Router Class Initialized
DEBUG - 2011-07-23 09:38:48 --> Output Class Initialized
DEBUG - 2011-07-23 09:38:48 --> Input Class Initialized
DEBUG - 2011-07-23 09:38:48 --> Global POST and COOKIE data sanitized
DEBUG - 2011-07-23 09:38:48 --> Language Class Initialized
DEBUG - 2011-07-23 09:38:48 --> Loader Class Initialized
DEBUG - 2011-07-23 09:38:48 --> Controller Class Initialized
ERROR - 2011-07-23 09:38:49 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-07-23 09:38:49 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-07-23 09:38:49 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-07-23 09:38:49 --> Model Class Initialized
DEBUG - 2011-07-23 09:38:49 --> Model Class Initialized
DEBUG - 2011-07-23 09:38:49 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-07-23 09:38:49 --> Database Driver Class Initialized
DEBUG - 2011-07-23 09:38:49 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-07-23 09:38:49 --> Helper loaded: url_helper
DEBUG - 2011-07-23 09:38:49 --> File loaded: application/views/common/header.php
DEBUG - 2011-07-23 09:38:49 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-07-23 09:38:49 --> File loaded: application/views/common/footer.php
DEBUG - 2011-07-23 09:38:49 --> File loaded: application/views/layout/main.php
DEBUG - 2011-07-23 09:38:49 --> Final output sent to browser
DEBUG - 2011-07-23 09:38:49 --> Total execution time: 0.7584
DEBUG - 2011-07-23 09:38:54 --> Config Class Initialized
DEBUG - 2011-07-23 09:38:54 --> Hooks Class Initialized
DEBUG - 2011-07-23 09:38:54 --> Utf8 Class Initialized
DEBUG - 2011-07-23 09:38:54 --> UTF-8 Support Enabled
DEBUG - 2011-07-23 09:38:54 --> URI Class Initialized
DEBUG - 2011-07-23 09:38:54 --> Router Class Initialized
ERROR - 2011-07-23 09:38:54 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-07-23 09:38:57 --> Config Class Initialized
DEBUG - 2011-07-23 09:38:57 --> Hooks Class Initialized
DEBUG - 2011-07-23 09:38:57 --> Utf8 Class Initialized
DEBUG - 2011-07-23 09:38:57 --> UTF-8 Support Enabled
DEBUG - 2011-07-23 09:38:57 --> URI Class Initialized
DEBUG - 2011-07-23 09:38:57 --> Router Class Initialized
DEBUG - 2011-07-23 09:38:57 --> Output Class Initialized
DEBUG - 2011-07-23 09:38:57 --> Input Class Initialized
DEBUG - 2011-07-23 09:38:57 --> Global POST and COOKIE data sanitized
DEBUG - 2011-07-23 09:38:57 --> Language Class Initialized
DEBUG - 2011-07-23 09:38:57 --> Loader Class Initialized
DEBUG - 2011-07-23 09:38:57 --> Controller Class Initialized
DEBUG - 2011-07-23 09:38:57 --> Model Class Initialized
DEBUG - 2011-07-23 09:38:57 --> Model Class Initialized
DEBUG - 2011-07-23 09:38:57 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-07-23 09:38:57 --> Database Driver Class Initialized
DEBUG - 2011-07-23 09:38:58 --> Final output sent to browser
DEBUG - 2011-07-23 09:38:58 --> Total execution time: 0.9999
DEBUG - 2011-07-23 09:38:58 --> Config Class Initialized
DEBUG - 2011-07-23 09:38:58 --> Hooks Class Initialized
DEBUG - 2011-07-23 09:38:58 --> Utf8 Class Initialized
DEBUG - 2011-07-23 09:38:58 --> UTF-8 Support Enabled
DEBUG - 2011-07-23 09:38:58 --> URI Class Initialized
DEBUG - 2011-07-23 09:38:58 --> Router Class Initialized
ERROR - 2011-07-23 09:38:58 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-07-23 09:48:18 --> Config Class Initialized
DEBUG - 2011-07-23 09:48:18 --> Hooks Class Initialized
DEBUG - 2011-07-23 09:48:18 --> Utf8 Class Initialized
DEBUG - 2011-07-23 09:48:18 --> UTF-8 Support Enabled
DEBUG - 2011-07-23 09:48:18 --> URI Class Initialized
DEBUG - 2011-07-23 09:48:18 --> Router Class Initialized
DEBUG - 2011-07-23 09:48:18 --> Output Class Initialized
DEBUG - 2011-07-23 09:48:18 --> Input Class Initialized
DEBUG - 2011-07-23 09:48:18 --> Global POST and COOKIE data sanitized
DEBUG - 2011-07-23 09:48:18 --> Language Class Initialized
DEBUG - 2011-07-23 09:48:18 --> Loader Class Initialized
DEBUG - 2011-07-23 09:48:18 --> Controller Class Initialized
DEBUG - 2011-07-23 09:48:18 --> Model Class Initialized
DEBUG - 2011-07-23 09:48:18 --> Model Class Initialized
DEBUG - 2011-07-23 09:48:18 --> Model Class Initialized
DEBUG - 2011-07-23 09:48:18 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-07-23 09:48:18 --> Database Driver Class Initialized
DEBUG - 2011-07-23 09:48:18 --> File loaded: application/views/table/main.php
DEBUG - 2011-07-23 09:48:18 --> Helper loaded: url_helper
DEBUG - 2011-07-23 09:48:18 --> File loaded: application/views/common/header.php
DEBUG - 2011-07-23 09:48:18 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-07-23 09:48:18 --> File loaded: application/views/common/footer.php
DEBUG - 2011-07-23 09:48:18 --> File loaded: application/views/layout/main.php
DEBUG - 2011-07-23 09:48:18 --> Final output sent to browser
DEBUG - 2011-07-23 09:48:18 --> Total execution time: 0.0867
DEBUG - 2011-07-23 09:48:21 --> Config Class Initialized
DEBUG - 2011-07-23 09:48:21 --> Hooks Class Initialized
DEBUG - 2011-07-23 09:48:21 --> Utf8 Class Initialized
DEBUG - 2011-07-23 09:48:21 --> UTF-8 Support Enabled
DEBUG - 2011-07-23 09:48:21 --> URI Class Initialized
DEBUG - 2011-07-23 09:48:21 --> Router Class Initialized
ERROR - 2011-07-23 09:48:21 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-07-23 09:48:21 --> Config Class Initialized
DEBUG - 2011-07-23 09:48:21 --> Hooks Class Initialized
DEBUG - 2011-07-23 09:48:21 --> Utf8 Class Initialized
DEBUG - 2011-07-23 09:48:21 --> UTF-8 Support Enabled
DEBUG - 2011-07-23 09:48:21 --> URI Class Initialized
DEBUG - 2011-07-23 09:48:21 --> Router Class Initialized
ERROR - 2011-07-23 09:48:21 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-07-23 09:48:38 --> Config Class Initialized
DEBUG - 2011-07-23 09:48:38 --> Hooks Class Initialized
DEBUG - 2011-07-23 09:48:38 --> Utf8 Class Initialized
DEBUG - 2011-07-23 09:48:38 --> UTF-8 Support Enabled
DEBUG - 2011-07-23 09:48:38 --> URI Class Initialized
DEBUG - 2011-07-23 09:48:38 --> Router Class Initialized
DEBUG - 2011-07-23 09:48:38 --> Output Class Initialized
DEBUG - 2011-07-23 09:48:38 --> Input Class Initialized
DEBUG - 2011-07-23 09:48:38 --> Global POST and COOKIE data sanitized
DEBUG - 2011-07-23 09:48:38 --> Language Class Initialized
DEBUG - 2011-07-23 09:48:38 --> Loader Class Initialized
DEBUG - 2011-07-23 09:48:38 --> Controller Class Initialized
DEBUG - 2011-07-23 09:48:38 --> Model Class Initialized
DEBUG - 2011-07-23 09:48:38 --> Model Class Initialized
DEBUG - 2011-07-23 09:48:38 --> Model Class Initialized
DEBUG - 2011-07-23 09:48:38 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-07-23 09:48:38 --> Database Driver Class Initialized
DEBUG - 2011-07-23 09:48:38 --> File loaded: application/views/table/main.php
DEBUG - 2011-07-23 09:48:38 --> Helper loaded: url_helper
DEBUG - 2011-07-23 09:48:38 --> File loaded: application/views/common/header.php
DEBUG - 2011-07-23 09:48:38 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-07-23 09:48:38 --> File loaded: application/views/common/footer.php
DEBUG - 2011-07-23 09:48:38 --> File loaded: application/views/layout/main.php
DEBUG - 2011-07-23 09:48:38 --> Final output sent to browser
DEBUG - 2011-07-23 09:48:38 --> Total execution time: 0.2047
DEBUG - 2011-07-23 09:48:55 --> Config Class Initialized
DEBUG - 2011-07-23 09:48:55 --> Hooks Class Initialized
DEBUG - 2011-07-23 09:48:55 --> Utf8 Class Initialized
DEBUG - 2011-07-23 09:48:55 --> UTF-8 Support Enabled
DEBUG - 2011-07-23 09:48:55 --> URI Class Initialized
DEBUG - 2011-07-23 09:48:55 --> Router Class Initialized
DEBUG - 2011-07-23 09:48:55 --> Output Class Initialized
DEBUG - 2011-07-23 09:48:55 --> Input Class Initialized
DEBUG - 2011-07-23 09:48:55 --> Global POST and COOKIE data sanitized
DEBUG - 2011-07-23 09:48:55 --> Language Class Initialized
DEBUG - 2011-07-23 09:48:55 --> Loader Class Initialized
DEBUG - 2011-07-23 09:48:55 --> Controller Class Initialized
DEBUG - 2011-07-23 09:48:55 --> Model Class Initialized
DEBUG - 2011-07-23 09:48:55 --> Model Class Initialized
DEBUG - 2011-07-23 09:48:55 --> Model Class Initialized
DEBUG - 2011-07-23 09:48:55 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-07-23 09:48:55 --> Database Driver Class Initialized
DEBUG - 2011-07-23 09:48:55 --> File loaded: application/views/table/main.php
DEBUG - 2011-07-23 09:48:55 --> Helper loaded: url_helper
DEBUG - 2011-07-23 09:48:55 --> File loaded: application/views/common/header.php
DEBUG - 2011-07-23 09:48:55 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-07-23 09:48:55 --> File loaded: application/views/common/footer.php
DEBUG - 2011-07-23 09:48:55 --> File loaded: application/views/layout/main.php
DEBUG - 2011-07-23 09:48:55 --> Final output sent to browser
DEBUG - 2011-07-23 09:48:55 --> Total execution time: 0.6920
DEBUG - 2011-07-23 09:49:02 --> Config Class Initialized
DEBUG - 2011-07-23 09:49:02 --> Hooks Class Initialized
DEBUG - 2011-07-23 09:49:02 --> Utf8 Class Initialized
DEBUG - 2011-07-23 09:49:02 --> UTF-8 Support Enabled
DEBUG - 2011-07-23 09:49:02 --> URI Class Initialized
DEBUG - 2011-07-23 09:49:02 --> Router Class Initialized
DEBUG - 2011-07-23 09:49:02 --> Output Class Initialized
DEBUG - 2011-07-23 09:49:02 --> Input Class Initialized
DEBUG - 2011-07-23 09:49:02 --> Global POST and COOKIE data sanitized
DEBUG - 2011-07-23 09:49:02 --> Language Class Initialized
DEBUG - 2011-07-23 09:49:02 --> Loader Class Initialized
DEBUG - 2011-07-23 09:49:02 --> Controller Class Initialized
DEBUG - 2011-07-23 09:49:02 --> Model Class Initialized
DEBUG - 2011-07-23 09:49:02 --> Model Class Initialized
DEBUG - 2011-07-23 09:49:02 --> Model Class Initialized
DEBUG - 2011-07-23 09:49:02 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-07-23 09:49:02 --> Database Driver Class Initialized
DEBUG - 2011-07-23 09:49:03 --> File loaded: application/views/table/main.php
DEBUG - 2011-07-23 09:49:03 --> Helper loaded: url_helper
DEBUG - 2011-07-23 09:49:03 --> File loaded: application/views/common/header.php
DEBUG - 2011-07-23 09:49:03 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-07-23 09:49:03 --> File loaded: application/views/common/footer.php
DEBUG - 2011-07-23 09:49:03 --> File loaded: application/views/layout/main.php
DEBUG - 2011-07-23 09:49:03 --> Final output sent to browser
DEBUG - 2011-07-23 09:49:03 --> Total execution time: 0.4243
DEBUG - 2011-07-23 09:49:10 --> Config Class Initialized
DEBUG - 2011-07-23 09:49:10 --> Hooks Class Initialized
DEBUG - 2011-07-23 09:49:10 --> Utf8 Class Initialized
DEBUG - 2011-07-23 09:49:10 --> UTF-8 Support Enabled
DEBUG - 2011-07-23 09:49:10 --> URI Class Initialized
DEBUG - 2011-07-23 09:49:10 --> Router Class Initialized
DEBUG - 2011-07-23 09:49:10 --> Output Class Initialized
DEBUG - 2011-07-23 09:49:10 --> Input Class Initialized
DEBUG - 2011-07-23 09:49:10 --> Global POST and COOKIE data sanitized
DEBUG - 2011-07-23 09:49:10 --> Language Class Initialized
DEBUG - 2011-07-23 09:49:10 --> Loader Class Initialized
DEBUG - 2011-07-23 09:49:10 --> Controller Class Initialized
DEBUG - 2011-07-23 09:49:10 --> Model Class Initialized
DEBUG - 2011-07-23 09:49:10 --> Model Class Initialized
DEBUG - 2011-07-23 09:49:10 --> Model Class Initialized
DEBUG - 2011-07-23 09:49:10 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-07-23 09:49:10 --> Database Driver Class Initialized
DEBUG - 2011-07-23 09:49:11 --> File loaded: application/views/table/main.php
DEBUG - 2011-07-23 09:49:11 --> Helper loaded: url_helper
DEBUG - 2011-07-23 09:49:11 --> File loaded: application/views/common/header.php
DEBUG - 2011-07-23 09:49:11 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-07-23 09:49:11 --> File loaded: application/views/common/footer.php
DEBUG - 2011-07-23 09:49:11 --> File loaded: application/views/layout/main.php
DEBUG - 2011-07-23 09:49:11 --> Final output sent to browser
DEBUG - 2011-07-23 09:49:11 --> Total execution time: 1.1024
DEBUG - 2011-07-23 09:49:25 --> Config Class Initialized
DEBUG - 2011-07-23 09:49:25 --> Hooks Class Initialized
DEBUG - 2011-07-23 09:49:25 --> Utf8 Class Initialized
DEBUG - 2011-07-23 09:49:25 --> UTF-8 Support Enabled
DEBUG - 2011-07-23 09:49:25 --> URI Class Initialized
DEBUG - 2011-07-23 09:49:25 --> Router Class Initialized
DEBUG - 2011-07-23 09:49:25 --> Output Class Initialized
DEBUG - 2011-07-23 09:49:25 --> Input Class Initialized
DEBUG - 2011-07-23 09:49:25 --> Global POST and COOKIE data sanitized
DEBUG - 2011-07-23 09:49:25 --> Language Class Initialized
DEBUG - 2011-07-23 09:49:25 --> Loader Class Initialized
DEBUG - 2011-07-23 09:49:25 --> Controller Class Initialized
DEBUG - 2011-07-23 09:49:25 --> Model Class Initialized
DEBUG - 2011-07-23 09:49:25 --> Model Class Initialized
DEBUG - 2011-07-23 09:49:25 --> Model Class Initialized
DEBUG - 2011-07-23 09:49:25 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-07-23 09:49:25 --> Database Driver Class Initialized
DEBUG - 2011-07-23 09:49:26 --> File loaded: application/views/table/main.php
DEBUG - 2011-07-23 09:49:26 --> Helper loaded: url_helper
DEBUG - 2011-07-23 09:49:26 --> File loaded: application/views/common/header.php
DEBUG - 2011-07-23 09:49:26 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-07-23 09:49:26 --> File loaded: application/views/common/footer.php
DEBUG - 2011-07-23 09:49:26 --> File loaded: application/views/layout/main.php
DEBUG - 2011-07-23 09:49:26 --> Final output sent to browser
DEBUG - 2011-07-23 09:49:26 --> Total execution time: 0.7176
DEBUG - 2011-07-23 09:50:04 --> Config Class Initialized
DEBUG - 2011-07-23 09:50:04 --> Hooks Class Initialized
DEBUG - 2011-07-23 09:50:04 --> Utf8 Class Initialized
DEBUG - 2011-07-23 09:50:04 --> UTF-8 Support Enabled
DEBUG - 2011-07-23 09:50:04 --> URI Class Initialized
DEBUG - 2011-07-23 09:50:04 --> Router Class Initialized
DEBUG - 2011-07-23 09:50:04 --> Output Class Initialized
DEBUG - 2011-07-23 09:50:05 --> Input Class Initialized
DEBUG - 2011-07-23 09:50:05 --> Global POST and COOKIE data sanitized
DEBUG - 2011-07-23 09:50:05 --> Language Class Initialized
DEBUG - 2011-07-23 09:50:05 --> Loader Class Initialized
DEBUG - 2011-07-23 09:50:05 --> Controller Class Initialized
ERROR - 2011-07-23 09:50:05 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-07-23 09:50:05 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-07-23 09:50:05 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-07-23 09:50:05 --> Model Class Initialized
DEBUG - 2011-07-23 09:50:05 --> Model Class Initialized
DEBUG - 2011-07-23 09:50:05 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-07-23 09:50:05 --> Database Driver Class Initialized
DEBUG - 2011-07-23 09:50:05 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-07-23 09:50:05 --> Helper loaded: url_helper
DEBUG - 2011-07-23 09:50:05 --> File loaded: application/views/common/header.php
DEBUG - 2011-07-23 09:50:05 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-07-23 09:50:05 --> File loaded: application/views/common/footer.php
DEBUG - 2011-07-23 09:50:05 --> File loaded: application/views/layout/main.php
DEBUG - 2011-07-23 09:50:05 --> Final output sent to browser
DEBUG - 2011-07-23 09:50:05 --> Total execution time: 0.1605
DEBUG - 2011-07-23 09:50:06 --> Config Class Initialized
DEBUG - 2011-07-23 09:50:06 --> Hooks Class Initialized
DEBUG - 2011-07-23 09:50:06 --> Utf8 Class Initialized
DEBUG - 2011-07-23 09:50:06 --> UTF-8 Support Enabled
DEBUG - 2011-07-23 09:50:06 --> URI Class Initialized
DEBUG - 2011-07-23 09:50:06 --> Router Class Initialized
DEBUG - 2011-07-23 09:50:06 --> Output Class Initialized
DEBUG - 2011-07-23 09:50:06 --> Input Class Initialized
DEBUG - 2011-07-23 09:50:06 --> Global POST and COOKIE data sanitized
DEBUG - 2011-07-23 09:50:06 --> Language Class Initialized
DEBUG - 2011-07-23 09:50:06 --> Loader Class Initialized
DEBUG - 2011-07-23 09:50:06 --> Controller Class Initialized
DEBUG - 2011-07-23 09:50:06 --> Model Class Initialized
DEBUG - 2011-07-23 09:50:06 --> Model Class Initialized
DEBUG - 2011-07-23 09:50:06 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-07-23 09:50:06 --> Database Driver Class Initialized
DEBUG - 2011-07-23 09:50:07 --> Final output sent to browser
DEBUG - 2011-07-23 09:50:07 --> Total execution time: 0.5530
DEBUG - 2011-07-23 10:06:38 --> Config Class Initialized
DEBUG - 2011-07-23 10:06:38 --> Hooks Class Initialized
DEBUG - 2011-07-23 10:06:38 --> Utf8 Class Initialized
DEBUG - 2011-07-23 10:06:38 --> UTF-8 Support Enabled
DEBUG - 2011-07-23 10:06:38 --> URI Class Initialized
DEBUG - 2011-07-23 10:06:38 --> Router Class Initialized
DEBUG - 2011-07-23 10:06:38 --> Output Class Initialized
DEBUG - 2011-07-23 10:06:38 --> Input Class Initialized
DEBUG - 2011-07-23 10:06:38 --> Global POST and COOKIE data sanitized
DEBUG - 2011-07-23 10:06:38 --> Language Class Initialized
DEBUG - 2011-07-23 10:06:38 --> Loader Class Initialized
DEBUG - 2011-07-23 10:06:38 --> Controller Class Initialized
DEBUG - 2011-07-23 10:06:38 --> Model Class Initialized
DEBUG - 2011-07-23 10:06:38 --> Model Class Initialized
DEBUG - 2011-07-23 10:06:38 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-07-23 10:06:38 --> Database Driver Class Initialized
DEBUG - 2011-07-23 10:06:39 --> Final output sent to browser
DEBUG - 2011-07-23 10:06:39 --> Total execution time: 0.6210
DEBUG - 2011-07-23 10:24:25 --> Config Class Initialized
DEBUG - 2011-07-23 10:24:25 --> Hooks Class Initialized
DEBUG - 2011-07-23 10:24:25 --> Utf8 Class Initialized
DEBUG - 2011-07-23 10:24:25 --> UTF-8 Support Enabled
DEBUG - 2011-07-23 10:24:25 --> URI Class Initialized
DEBUG - 2011-07-23 10:24:25 --> Router Class Initialized
DEBUG - 2011-07-23 10:24:25 --> Output Class Initialized
DEBUG - 2011-07-23 10:24:25 --> Input Class Initialized
DEBUG - 2011-07-23 10:24:25 --> Global POST and COOKIE data sanitized
DEBUG - 2011-07-23 10:24:25 --> Language Class Initialized
DEBUG - 2011-07-23 10:24:25 --> Loader Class Initialized
DEBUG - 2011-07-23 10:24:25 --> Controller Class Initialized
ERROR - 2011-07-23 10:24:25 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-07-23 10:24:25 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-07-23 10:24:25 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-07-23 10:24:25 --> Model Class Initialized
DEBUG - 2011-07-23 10:24:25 --> Model Class Initialized
DEBUG - 2011-07-23 10:24:25 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-07-23 10:24:25 --> Database Driver Class Initialized
DEBUG - 2011-07-23 10:24:25 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-07-23 10:24:25 --> Helper loaded: url_helper
DEBUG - 2011-07-23 10:24:25 --> File loaded: application/views/common/header.php
DEBUG - 2011-07-23 10:24:25 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-07-23 10:24:25 --> File loaded: application/views/common/footer.php
DEBUG - 2011-07-23 10:24:25 --> File loaded: application/views/layout/main.php
DEBUG - 2011-07-23 10:24:25 --> Final output sent to browser
DEBUG - 2011-07-23 10:24:25 --> Total execution time: 0.2136
DEBUG - 2011-07-23 10:24:26 --> Config Class Initialized
DEBUG - 2011-07-23 10:24:26 --> Hooks Class Initialized
DEBUG - 2011-07-23 10:24:26 --> Utf8 Class Initialized
DEBUG - 2011-07-23 10:24:26 --> UTF-8 Support Enabled
DEBUG - 2011-07-23 10:24:26 --> URI Class Initialized
DEBUG - 2011-07-23 10:24:26 --> Router Class Initialized
DEBUG - 2011-07-23 10:24:26 --> Output Class Initialized
DEBUG - 2011-07-23 10:24:26 --> Input Class Initialized
DEBUG - 2011-07-23 10:24:26 --> Global POST and COOKIE data sanitized
DEBUG - 2011-07-23 10:24:26 --> Language Class Initialized
DEBUG - 2011-07-23 10:24:26 --> Loader Class Initialized
DEBUG - 2011-07-23 10:24:26 --> Controller Class Initialized
DEBUG - 2011-07-23 10:24:26 --> Model Class Initialized
DEBUG - 2011-07-23 10:24:26 --> Model Class Initialized
DEBUG - 2011-07-23 10:24:26 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-07-23 10:24:26 --> Database Driver Class Initialized
DEBUG - 2011-07-23 10:24:27 --> Final output sent to browser
DEBUG - 2011-07-23 10:24:27 --> Total execution time: 1.0361
DEBUG - 2011-07-23 10:24:28 --> Config Class Initialized
DEBUG - 2011-07-23 10:24:28 --> Hooks Class Initialized
DEBUG - 2011-07-23 10:24:28 --> Utf8 Class Initialized
DEBUG - 2011-07-23 10:24:28 --> UTF-8 Support Enabled
DEBUG - 2011-07-23 10:24:28 --> URI Class Initialized
DEBUG - 2011-07-23 10:24:28 --> Router Class Initialized
ERROR - 2011-07-23 10:24:28 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-07-23 10:24:28 --> Config Class Initialized
DEBUG - 2011-07-23 10:24:28 --> Hooks Class Initialized
DEBUG - 2011-07-23 10:24:28 --> Utf8 Class Initialized
DEBUG - 2011-07-23 10:24:28 --> UTF-8 Support Enabled
DEBUG - 2011-07-23 10:24:28 --> URI Class Initialized
DEBUG - 2011-07-23 10:24:28 --> Router Class Initialized
ERROR - 2011-07-23 10:24:28 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-07-23 10:24:51 --> Config Class Initialized
DEBUG - 2011-07-23 10:24:51 --> Hooks Class Initialized
DEBUG - 2011-07-23 10:24:51 --> Utf8 Class Initialized
DEBUG - 2011-07-23 10:24:51 --> UTF-8 Support Enabled
DEBUG - 2011-07-23 10:24:51 --> URI Class Initialized
DEBUG - 2011-07-23 10:24:51 --> Router Class Initialized
DEBUG - 2011-07-23 10:24:51 --> Output Class Initialized
DEBUG - 2011-07-23 10:24:51 --> Input Class Initialized
DEBUG - 2011-07-23 10:24:51 --> Global POST and COOKIE data sanitized
DEBUG - 2011-07-23 10:24:51 --> Language Class Initialized
DEBUG - 2011-07-23 10:24:51 --> Loader Class Initialized
DEBUG - 2011-07-23 10:24:51 --> Controller Class Initialized
ERROR - 2011-07-23 10:24:51 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-07-23 10:24:51 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-07-23 10:24:51 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-07-23 10:24:51 --> Model Class Initialized
DEBUG - 2011-07-23 10:24:51 --> Model Class Initialized
DEBUG - 2011-07-23 10:24:51 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-07-23 10:24:51 --> Database Driver Class Initialized
DEBUG - 2011-07-23 10:24:51 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-07-23 10:24:51 --> Helper loaded: url_helper
DEBUG - 2011-07-23 10:24:51 --> File loaded: application/views/common/header.php
DEBUG - 2011-07-23 10:24:51 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-07-23 10:24:51 --> File loaded: application/views/common/footer.php
DEBUG - 2011-07-23 10:24:51 --> File loaded: application/views/layout/main.php
DEBUG - 2011-07-23 10:24:51 --> Final output sent to browser
DEBUG - 2011-07-23 10:24:51 --> Total execution time: 0.0333
DEBUG - 2011-07-23 10:24:52 --> Config Class Initialized
DEBUG - 2011-07-23 10:24:52 --> Hooks Class Initialized
DEBUG - 2011-07-23 10:24:52 --> Utf8 Class Initialized
DEBUG - 2011-07-23 10:24:52 --> UTF-8 Support Enabled
DEBUG - 2011-07-23 10:24:52 --> URI Class Initialized
DEBUG - 2011-07-23 10:24:52 --> Router Class Initialized
DEBUG - 2011-07-23 10:24:52 --> Output Class Initialized
DEBUG - 2011-07-23 10:24:52 --> Input Class Initialized
DEBUG - 2011-07-23 10:24:52 --> Global POST and COOKIE data sanitized
DEBUG - 2011-07-23 10:24:52 --> Language Class Initialized
DEBUG - 2011-07-23 10:24:52 --> Loader Class Initialized
DEBUG - 2011-07-23 10:24:52 --> Controller Class Initialized
DEBUG - 2011-07-23 10:24:52 --> Model Class Initialized
DEBUG - 2011-07-23 10:24:52 --> Model Class Initialized
DEBUG - 2011-07-23 10:24:52 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-07-23 10:24:52 --> Database Driver Class Initialized
DEBUG - 2011-07-23 10:24:53 --> Final output sent to browser
DEBUG - 2011-07-23 10:24:53 --> Total execution time: 0.7239
DEBUG - 2011-07-23 11:40:02 --> Config Class Initialized
DEBUG - 2011-07-23 11:40:02 --> Hooks Class Initialized
DEBUG - 2011-07-23 11:40:02 --> Utf8 Class Initialized
DEBUG - 2011-07-23 11:40:02 --> UTF-8 Support Enabled
DEBUG - 2011-07-23 11:40:02 --> URI Class Initialized
DEBUG - 2011-07-23 11:40:02 --> Router Class Initialized
DEBUG - 2011-07-23 11:40:02 --> Output Class Initialized
DEBUG - 2011-07-23 11:40:02 --> Input Class Initialized
DEBUG - 2011-07-23 11:40:02 --> Global POST and COOKIE data sanitized
DEBUG - 2011-07-23 11:40:02 --> Language Class Initialized
DEBUG - 2011-07-23 11:40:02 --> Loader Class Initialized
DEBUG - 2011-07-23 11:40:02 --> Controller Class Initialized
DEBUG - 2011-07-23 11:40:02 --> Model Class Initialized
DEBUG - 2011-07-23 11:40:02 --> Model Class Initialized
DEBUG - 2011-07-23 11:40:02 --> Model Class Initialized
DEBUG - 2011-07-23 11:40:02 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-07-23 11:40:02 --> Database Driver Class Initialized
DEBUG - 2011-07-23 11:40:04 --> File loaded: application/views/table/main.php
DEBUG - 2011-07-23 11:40:04 --> Helper loaded: url_helper
DEBUG - 2011-07-23 11:40:04 --> File loaded: application/views/common/header.php
DEBUG - 2011-07-23 11:40:04 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-07-23 11:40:04 --> File loaded: application/views/common/footer.php
DEBUG - 2011-07-23 11:40:04 --> File loaded: application/views/layout/main.php
DEBUG - 2011-07-23 11:40:04 --> Final output sent to browser
DEBUG - 2011-07-23 11:40:04 --> Total execution time: 1.8543
DEBUG - 2011-07-23 11:40:31 --> Config Class Initialized
DEBUG - 2011-07-23 11:40:31 --> Hooks Class Initialized
DEBUG - 2011-07-23 11:40:31 --> Utf8 Class Initialized
DEBUG - 2011-07-23 11:40:31 --> UTF-8 Support Enabled
DEBUG - 2011-07-23 11:40:31 --> URI Class Initialized
DEBUG - 2011-07-23 11:40:31 --> Router Class Initialized
DEBUG - 2011-07-23 11:40:31 --> Output Class Initialized
DEBUG - 2011-07-23 11:40:31 --> Input Class Initialized
DEBUG - 2011-07-23 11:40:31 --> Global POST and COOKIE data sanitized
DEBUG - 2011-07-23 11:40:31 --> Language Class Initialized
DEBUG - 2011-07-23 11:40:31 --> Loader Class Initialized
DEBUG - 2011-07-23 11:40:31 --> Controller Class Initialized
DEBUG - 2011-07-23 11:40:31 --> Model Class Initialized
DEBUG - 2011-07-23 11:40:31 --> Model Class Initialized
DEBUG - 2011-07-23 11:40:31 --> Model Class Initialized
DEBUG - 2011-07-23 11:40:31 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-07-23 11:40:31 --> Database Driver Class Initialized
DEBUG - 2011-07-23 11:40:33 --> File loaded: application/views/table/main.php
DEBUG - 2011-07-23 11:40:33 --> Helper loaded: url_helper
DEBUG - 2011-07-23 11:40:33 --> File loaded: application/views/common/header.php
DEBUG - 2011-07-23 11:40:33 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-07-23 11:40:33 --> File loaded: application/views/common/footer.php
DEBUG - 2011-07-23 11:40:33 --> File loaded: application/views/layout/main.php
DEBUG - 2011-07-23 11:40:33 --> Final output sent to browser
DEBUG - 2011-07-23 11:40:33 --> Total execution time: 1.3490
DEBUG - 2011-07-23 11:40:36 --> Config Class Initialized
DEBUG - 2011-07-23 11:40:36 --> Hooks Class Initialized
DEBUG - 2011-07-23 11:40:36 --> Utf8 Class Initialized
DEBUG - 2011-07-23 11:40:36 --> UTF-8 Support Enabled
DEBUG - 2011-07-23 11:40:36 --> URI Class Initialized
DEBUG - 2011-07-23 11:40:36 --> Router Class Initialized
DEBUG - 2011-07-23 11:40:36 --> Output Class Initialized
DEBUG - 2011-07-23 11:40:36 --> Input Class Initialized
DEBUG - 2011-07-23 11:40:36 --> Global POST and COOKIE data sanitized
DEBUG - 2011-07-23 11:40:36 --> Language Class Initialized
DEBUG - 2011-07-23 11:40:36 --> Loader Class Initialized
DEBUG - 2011-07-23 11:40:36 --> Controller Class Initialized
DEBUG - 2011-07-23 11:40:36 --> Model Class Initialized
DEBUG - 2011-07-23 11:40:36 --> Model Class Initialized
DEBUG - 2011-07-23 11:40:36 --> Model Class Initialized
DEBUG - 2011-07-23 11:40:36 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-07-23 11:40:36 --> Database Driver Class Initialized
DEBUG - 2011-07-23 11:40:36 --> File loaded: application/views/table/main.php
DEBUG - 2011-07-23 11:40:36 --> Helper loaded: url_helper
DEBUG - 2011-07-23 11:40:36 --> File loaded: application/views/common/header.php
DEBUG - 2011-07-23 11:40:36 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-07-23 11:40:36 --> File loaded: application/views/common/footer.php
DEBUG - 2011-07-23 11:40:36 --> File loaded: application/views/layout/main.php
DEBUG - 2011-07-23 11:40:36 --> Final output sent to browser
DEBUG - 2011-07-23 11:40:36 --> Total execution time: 0.0829
DEBUG - 2011-07-23 11:40:50 --> Config Class Initialized
DEBUG - 2011-07-23 11:40:50 --> Hooks Class Initialized
DEBUG - 2011-07-23 11:40:50 --> Utf8 Class Initialized
DEBUG - 2011-07-23 11:40:50 --> UTF-8 Support Enabled
DEBUG - 2011-07-23 11:40:50 --> URI Class Initialized
DEBUG - 2011-07-23 11:40:50 --> Router Class Initialized
DEBUG - 2011-07-23 11:40:50 --> Output Class Initialized
DEBUG - 2011-07-23 11:40:51 --> Input Class Initialized
DEBUG - 2011-07-23 11:40:51 --> Global POST and COOKIE data sanitized
DEBUG - 2011-07-23 11:40:51 --> Language Class Initialized
DEBUG - 2011-07-23 11:40:51 --> Loader Class Initialized
DEBUG - 2011-07-23 11:40:51 --> Controller Class Initialized
DEBUG - 2011-07-23 11:40:51 --> Model Class Initialized
DEBUG - 2011-07-23 11:40:51 --> Model Class Initialized
DEBUG - 2011-07-23 11:40:51 --> Model Class Initialized
DEBUG - 2011-07-23 11:40:51 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-07-23 11:40:51 --> Database Driver Class Initialized
DEBUG - 2011-07-23 11:40:51 --> File loaded: application/views/table/main.php
DEBUG - 2011-07-23 11:40:51 --> Helper loaded: url_helper
DEBUG - 2011-07-23 11:40:51 --> File loaded: application/views/common/header.php
DEBUG - 2011-07-23 11:40:51 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-07-23 11:40:51 --> File loaded: application/views/common/footer.php
DEBUG - 2011-07-23 11:40:51 --> File loaded: application/views/layout/main.php
DEBUG - 2011-07-23 11:40:51 --> Final output sent to browser
DEBUG - 2011-07-23 11:40:51 --> Total execution time: 0.3498
DEBUG - 2011-07-23 11:40:53 --> Config Class Initialized
DEBUG - 2011-07-23 11:40:53 --> Hooks Class Initialized
DEBUG - 2011-07-23 11:40:53 --> Utf8 Class Initialized
DEBUG - 2011-07-23 11:40:53 --> UTF-8 Support Enabled
DEBUG - 2011-07-23 11:40:53 --> URI Class Initialized
DEBUG - 2011-07-23 11:40:53 --> Router Class Initialized
DEBUG - 2011-07-23 11:40:53 --> Output Class Initialized
DEBUG - 2011-07-23 11:40:53 --> Input Class Initialized
DEBUG - 2011-07-23 11:40:53 --> Global POST and COOKIE data sanitized
DEBUG - 2011-07-23 11:40:53 --> Language Class Initialized
DEBUG - 2011-07-23 11:40:53 --> Loader Class Initialized
DEBUG - 2011-07-23 11:40:53 --> Controller Class Initialized
DEBUG - 2011-07-23 11:40:53 --> Model Class Initialized
DEBUG - 2011-07-23 11:40:53 --> Model Class Initialized
DEBUG - 2011-07-23 11:40:53 --> Model Class Initialized
DEBUG - 2011-07-23 11:40:53 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-07-23 11:40:53 --> Database Driver Class Initialized
DEBUG - 2011-07-23 11:40:53 --> File loaded: application/views/table/main.php
DEBUG - 2011-07-23 11:40:53 --> Helper loaded: url_helper
DEBUG - 2011-07-23 11:40:53 --> File loaded: application/views/common/header.php
DEBUG - 2011-07-23 11:40:53 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-07-23 11:40:53 --> File loaded: application/views/common/footer.php
DEBUG - 2011-07-23 11:40:53 --> File loaded: application/views/layout/main.php
DEBUG - 2011-07-23 11:40:53 --> Final output sent to browser
DEBUG - 2011-07-23 11:40:53 --> Total execution time: 0.1673
DEBUG - 2011-07-23 11:41:02 --> Config Class Initialized
DEBUG - 2011-07-23 11:41:02 --> Hooks Class Initialized
DEBUG - 2011-07-23 11:41:02 --> Utf8 Class Initialized
DEBUG - 2011-07-23 11:41:02 --> UTF-8 Support Enabled
DEBUG - 2011-07-23 11:41:02 --> URI Class Initialized
DEBUG - 2011-07-23 11:41:02 --> Router Class Initialized
DEBUG - 2011-07-23 11:41:02 --> Output Class Initialized
DEBUG - 2011-07-23 11:41:02 --> Input Class Initialized
DEBUG - 2011-07-23 11:41:02 --> Global POST and COOKIE data sanitized
DEBUG - 2011-07-23 11:41:02 --> Language Class Initialized
DEBUG - 2011-07-23 11:41:02 --> Loader Class Initialized
DEBUG - 2011-07-23 11:41:02 --> Controller Class Initialized
DEBUG - 2011-07-23 11:41:02 --> Model Class Initialized
DEBUG - 2011-07-23 11:41:02 --> Model Class Initialized
DEBUG - 2011-07-23 11:41:02 --> Model Class Initialized
DEBUG - 2011-07-23 11:41:02 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-07-23 11:41:02 --> Database Driver Class Initialized
DEBUG - 2011-07-23 11:41:03 --> File loaded: application/views/table/main.php
DEBUG - 2011-07-23 11:41:03 --> Helper loaded: url_helper
DEBUG - 2011-07-23 11:41:03 --> File loaded: application/views/common/header.php
DEBUG - 2011-07-23 11:41:03 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-07-23 11:41:03 --> File loaded: application/views/common/footer.php
DEBUG - 2011-07-23 11:41:03 --> File loaded: application/views/layout/main.php
DEBUG - 2011-07-23 11:41:03 --> Final output sent to browser
DEBUG - 2011-07-23 11:41:03 --> Total execution time: 0.4917
DEBUG - 2011-07-23 11:41:05 --> Config Class Initialized
DEBUG - 2011-07-23 11:41:05 --> Hooks Class Initialized
DEBUG - 2011-07-23 11:41:05 --> Utf8 Class Initialized
DEBUG - 2011-07-23 11:41:05 --> UTF-8 Support Enabled
DEBUG - 2011-07-23 11:41:05 --> URI Class Initialized
DEBUG - 2011-07-23 11:41:05 --> Router Class Initialized
DEBUG - 2011-07-23 11:41:05 --> Output Class Initialized
DEBUG - 2011-07-23 11:41:05 --> Input Class Initialized
DEBUG - 2011-07-23 11:41:05 --> Global POST and COOKIE data sanitized
DEBUG - 2011-07-23 11:41:05 --> Language Class Initialized
DEBUG - 2011-07-23 11:41:05 --> Loader Class Initialized
DEBUG - 2011-07-23 11:41:05 --> Controller Class Initialized
DEBUG - 2011-07-23 11:41:05 --> Model Class Initialized
DEBUG - 2011-07-23 11:41:05 --> Model Class Initialized
DEBUG - 2011-07-23 11:41:05 --> Model Class Initialized
DEBUG - 2011-07-23 11:41:05 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-07-23 11:41:05 --> Database Driver Class Initialized
DEBUG - 2011-07-23 11:41:05 --> File loaded: application/views/table/main.php
DEBUG - 2011-07-23 11:41:05 --> Helper loaded: url_helper
DEBUG - 2011-07-23 11:41:05 --> File loaded: application/views/common/header.php
DEBUG - 2011-07-23 11:41:05 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-07-23 11:41:05 --> File loaded: application/views/common/footer.php
DEBUG - 2011-07-23 11:41:05 --> File loaded: application/views/layout/main.php
DEBUG - 2011-07-23 11:41:05 --> Final output sent to browser
DEBUG - 2011-07-23 11:41:05 --> Total execution time: 0.0715
DEBUG - 2011-07-23 11:41:17 --> Config Class Initialized
DEBUG - 2011-07-23 11:41:17 --> Hooks Class Initialized
DEBUG - 2011-07-23 11:41:17 --> Utf8 Class Initialized
DEBUG - 2011-07-23 11:41:17 --> UTF-8 Support Enabled
DEBUG - 2011-07-23 11:41:17 --> URI Class Initialized
DEBUG - 2011-07-23 11:41:17 --> Router Class Initialized
DEBUG - 2011-07-23 11:41:17 --> Output Class Initialized
DEBUG - 2011-07-23 11:41:17 --> Input Class Initialized
DEBUG - 2011-07-23 11:41:17 --> Global POST and COOKIE data sanitized
DEBUG - 2011-07-23 11:41:17 --> Language Class Initialized
DEBUG - 2011-07-23 11:41:17 --> Loader Class Initialized
DEBUG - 2011-07-23 11:41:17 --> Controller Class Initialized
DEBUG - 2011-07-23 11:41:17 --> Model Class Initialized
DEBUG - 2011-07-23 11:41:17 --> Model Class Initialized
DEBUG - 2011-07-23 11:41:17 --> Model Class Initialized
DEBUG - 2011-07-23 11:41:17 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-07-23 11:41:17 --> Database Driver Class Initialized
DEBUG - 2011-07-23 11:41:17 --> File loaded: application/views/table/main.php
DEBUG - 2011-07-23 11:41:17 --> Helper loaded: url_helper
DEBUG - 2011-07-23 11:41:17 --> File loaded: application/views/common/header.php
DEBUG - 2011-07-23 11:41:17 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-07-23 11:41:17 --> File loaded: application/views/common/footer.php
DEBUG - 2011-07-23 11:41:17 --> File loaded: application/views/layout/main.php
DEBUG - 2011-07-23 11:41:17 --> Final output sent to browser
DEBUG - 2011-07-23 11:41:17 --> Total execution time: 0.5091
DEBUG - 2011-07-23 11:41:20 --> Config Class Initialized
DEBUG - 2011-07-23 11:41:20 --> Hooks Class Initialized
DEBUG - 2011-07-23 11:41:20 --> Utf8 Class Initialized
DEBUG - 2011-07-23 11:41:20 --> UTF-8 Support Enabled
DEBUG - 2011-07-23 11:41:20 --> URI Class Initialized
DEBUG - 2011-07-23 11:41:20 --> Router Class Initialized
DEBUG - 2011-07-23 11:41:20 --> Output Class Initialized
DEBUG - 2011-07-23 11:41:20 --> Input Class Initialized
DEBUG - 2011-07-23 11:41:20 --> Global POST and COOKIE data sanitized
DEBUG - 2011-07-23 11:41:20 --> Language Class Initialized
DEBUG - 2011-07-23 11:41:20 --> Loader Class Initialized
DEBUG - 2011-07-23 11:41:20 --> Controller Class Initialized
DEBUG - 2011-07-23 11:41:20 --> Model Class Initialized
DEBUG - 2011-07-23 11:41:20 --> Model Class Initialized
DEBUG - 2011-07-23 11:41:20 --> Model Class Initialized
DEBUG - 2011-07-23 11:41:20 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-07-23 11:41:20 --> Database Driver Class Initialized
DEBUG - 2011-07-23 11:41:20 --> File loaded: application/views/table/main.php
DEBUG - 2011-07-23 11:41:20 --> Helper loaded: url_helper
DEBUG - 2011-07-23 11:41:20 --> File loaded: application/views/common/header.php
DEBUG - 2011-07-23 11:41:20 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-07-23 11:41:20 --> File loaded: application/views/common/footer.php
DEBUG - 2011-07-23 11:41:20 --> File loaded: application/views/layout/main.php
DEBUG - 2011-07-23 11:41:20 --> Final output sent to browser
DEBUG - 2011-07-23 11:41:20 --> Total execution time: 0.0713
DEBUG - 2011-07-23 11:41:27 --> Config Class Initialized
DEBUG - 2011-07-23 11:41:27 --> Hooks Class Initialized
DEBUG - 2011-07-23 11:41:27 --> Utf8 Class Initialized
DEBUG - 2011-07-23 11:41:27 --> UTF-8 Support Enabled
DEBUG - 2011-07-23 11:41:27 --> URI Class Initialized
DEBUG - 2011-07-23 11:41:27 --> Router Class Initialized
DEBUG - 2011-07-23 11:41:27 --> Output Class Initialized
DEBUG - 2011-07-23 11:41:27 --> Input Class Initialized
DEBUG - 2011-07-23 11:41:27 --> Global POST and COOKIE data sanitized
DEBUG - 2011-07-23 11:41:27 --> Language Class Initialized
DEBUG - 2011-07-23 11:41:27 --> Loader Class Initialized
DEBUG - 2011-07-23 11:41:27 --> Controller Class Initialized
DEBUG - 2011-07-23 11:41:27 --> Model Class Initialized
DEBUG - 2011-07-23 11:41:27 --> Model Class Initialized
DEBUG - 2011-07-23 11:41:27 --> Model Class Initialized
DEBUG - 2011-07-23 11:41:27 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-07-23 11:41:27 --> Database Driver Class Initialized
DEBUG - 2011-07-23 11:41:27 --> File loaded: application/views/table/main.php
DEBUG - 2011-07-23 11:41:27 --> Helper loaded: url_helper
DEBUG - 2011-07-23 11:41:27 --> File loaded: application/views/common/header.php
DEBUG - 2011-07-23 11:41:27 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-07-23 11:41:27 --> File loaded: application/views/common/footer.php
DEBUG - 2011-07-23 11:41:27 --> File loaded: application/views/layout/main.php
DEBUG - 2011-07-23 11:41:27 --> Final output sent to browser
DEBUG - 2011-07-23 11:41:27 --> Total execution time: 0.3509
DEBUG - 2011-07-23 11:48:43 --> Config Class Initialized
DEBUG - 2011-07-23 11:48:43 --> Hooks Class Initialized
DEBUG - 2011-07-23 11:48:43 --> Utf8 Class Initialized
DEBUG - 2011-07-23 11:48:43 --> UTF-8 Support Enabled
DEBUG - 2011-07-23 11:48:43 --> URI Class Initialized
DEBUG - 2011-07-23 11:48:43 --> Router Class Initialized
DEBUG - 2011-07-23 11:48:43 --> Output Class Initialized
DEBUG - 2011-07-23 11:48:43 --> Input Class Initialized
DEBUG - 2011-07-23 11:48:43 --> Global POST and COOKIE data sanitized
DEBUG - 2011-07-23 11:48:43 --> Language Class Initialized
DEBUG - 2011-07-23 11:48:43 --> Loader Class Initialized
DEBUG - 2011-07-23 11:48:43 --> Controller Class Initialized
DEBUG - 2011-07-23 11:48:43 --> Model Class Initialized
DEBUG - 2011-07-23 11:48:43 --> Model Class Initialized
DEBUG - 2011-07-23 11:48:43 --> Model Class Initialized
DEBUG - 2011-07-23 11:48:43 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-07-23 11:48:43 --> Database Driver Class Initialized
DEBUG - 2011-07-23 11:48:43 --> File loaded: application/views/table/main.php
DEBUG - 2011-07-23 11:48:43 --> Helper loaded: url_helper
DEBUG - 2011-07-23 11:48:43 --> File loaded: application/views/common/header.php
DEBUG - 2011-07-23 11:48:43 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-07-23 11:48:43 --> File loaded: application/views/common/footer.php
DEBUG - 2011-07-23 11:48:43 --> File loaded: application/views/layout/main.php
DEBUG - 2011-07-23 11:48:43 --> Final output sent to browser
DEBUG - 2011-07-23 11:48:43 --> Total execution time: 0.8557
DEBUG - 2011-07-23 11:48:46 --> Config Class Initialized
DEBUG - 2011-07-23 11:48:46 --> Hooks Class Initialized
DEBUG - 2011-07-23 11:48:46 --> Utf8 Class Initialized
DEBUG - 2011-07-23 11:48:46 --> UTF-8 Support Enabled
DEBUG - 2011-07-23 11:48:46 --> URI Class Initialized
DEBUG - 2011-07-23 11:48:46 --> Router Class Initialized
ERROR - 2011-07-23 11:48:46 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-07-23 11:48:58 --> Config Class Initialized
DEBUG - 2011-07-23 11:48:58 --> Hooks Class Initialized
DEBUG - 2011-07-23 11:48:58 --> Utf8 Class Initialized
DEBUG - 2011-07-23 11:48:58 --> UTF-8 Support Enabled
DEBUG - 2011-07-23 11:48:58 --> URI Class Initialized
DEBUG - 2011-07-23 11:48:58 --> Router Class Initialized
DEBUG - 2011-07-23 11:48:58 --> Output Class Initialized
DEBUG - 2011-07-23 11:48:58 --> Input Class Initialized
DEBUG - 2011-07-23 11:48:58 --> Global POST and COOKIE data sanitized
DEBUG - 2011-07-23 11:48:58 --> Language Class Initialized
DEBUG - 2011-07-23 11:48:58 --> Loader Class Initialized
DEBUG - 2011-07-23 11:48:58 --> Controller Class Initialized
DEBUG - 2011-07-23 11:48:58 --> Model Class Initialized
DEBUG - 2011-07-23 11:48:58 --> Model Class Initialized
DEBUG - 2011-07-23 11:48:58 --> Model Class Initialized
DEBUG - 2011-07-23 11:48:58 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-07-23 11:48:58 --> Database Driver Class Initialized
DEBUG - 2011-07-23 11:48:58 --> File loaded: application/views/table/main.php
DEBUG - 2011-07-23 11:48:58 --> Helper loaded: url_helper
DEBUG - 2011-07-23 11:48:58 --> File loaded: application/views/common/header.php
DEBUG - 2011-07-23 11:48:58 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-07-23 11:48:58 --> File loaded: application/views/common/footer.php
DEBUG - 2011-07-23 11:48:58 --> File loaded: application/views/layout/main.php
DEBUG - 2011-07-23 11:48:58 --> Final output sent to browser
DEBUG - 2011-07-23 11:48:58 --> Total execution time: 0.6407
DEBUG - 2011-07-23 11:49:00 --> Config Class Initialized
DEBUG - 2011-07-23 11:49:00 --> Hooks Class Initialized
DEBUG - 2011-07-23 11:49:00 --> Utf8 Class Initialized
DEBUG - 2011-07-23 11:49:00 --> UTF-8 Support Enabled
DEBUG - 2011-07-23 11:49:00 --> URI Class Initialized
DEBUG - 2011-07-23 11:49:00 --> Router Class Initialized
ERROR - 2011-07-23 11:49:00 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-07-23 11:49:00 --> Config Class Initialized
DEBUG - 2011-07-23 11:49:00 --> Hooks Class Initialized
DEBUG - 2011-07-23 11:49:00 --> Utf8 Class Initialized
DEBUG - 2011-07-23 11:49:00 --> UTF-8 Support Enabled
DEBUG - 2011-07-23 11:49:00 --> URI Class Initialized
DEBUG - 2011-07-23 11:49:00 --> Router Class Initialized
ERROR - 2011-07-23 11:49:00 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-07-23 11:49:19 --> Config Class Initialized
DEBUG - 2011-07-23 11:49:19 --> Hooks Class Initialized
DEBUG - 2011-07-23 11:49:19 --> Utf8 Class Initialized
DEBUG - 2011-07-23 11:49:19 --> UTF-8 Support Enabled
DEBUG - 2011-07-23 11:49:19 --> URI Class Initialized
DEBUG - 2011-07-23 11:49:19 --> Router Class Initialized
DEBUG - 2011-07-23 11:49:19 --> Output Class Initialized
DEBUG - 2011-07-23 11:49:19 --> Input Class Initialized
DEBUG - 2011-07-23 11:49:19 --> Global POST and COOKIE data sanitized
DEBUG - 2011-07-23 11:49:19 --> Language Class Initialized
DEBUG - 2011-07-23 11:49:19 --> Loader Class Initialized
DEBUG - 2011-07-23 11:49:19 --> Controller Class Initialized
DEBUG - 2011-07-23 11:49:19 --> Model Class Initialized
DEBUG - 2011-07-23 11:49:19 --> Model Class Initialized
DEBUG - 2011-07-23 11:49:19 --> Model Class Initialized
DEBUG - 2011-07-23 11:49:19 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-07-23 11:49:19 --> Database Driver Class Initialized
DEBUG - 2011-07-23 11:49:19 --> File loaded: application/views/table/main.php
DEBUG - 2011-07-23 11:49:19 --> Helper loaded: url_helper
DEBUG - 2011-07-23 11:49:19 --> File loaded: application/views/common/header.php
DEBUG - 2011-07-23 11:49:19 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-07-23 11:49:19 --> File loaded: application/views/common/footer.php
DEBUG - 2011-07-23 11:49:19 --> File loaded: application/views/layout/main.php
DEBUG - 2011-07-23 11:49:19 --> Final output sent to browser
DEBUG - 2011-07-23 11:49:19 --> Total execution time: 0.3199
DEBUG - 2011-07-23 11:49:20 --> Config Class Initialized
DEBUG - 2011-07-23 11:49:20 --> Hooks Class Initialized
DEBUG - 2011-07-23 11:49:20 --> Utf8 Class Initialized
DEBUG - 2011-07-23 11:49:20 --> UTF-8 Support Enabled
DEBUG - 2011-07-23 11:49:20 --> URI Class Initialized
DEBUG - 2011-07-23 11:49:20 --> Router Class Initialized
ERROR - 2011-07-23 11:49:20 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-07-23 11:49:22 --> Config Class Initialized
DEBUG - 2011-07-23 11:49:22 --> Hooks Class Initialized
DEBUG - 2011-07-23 11:49:22 --> Utf8 Class Initialized
DEBUG - 2011-07-23 11:49:22 --> UTF-8 Support Enabled
DEBUG - 2011-07-23 11:49:22 --> URI Class Initialized
DEBUG - 2011-07-23 11:49:22 --> Router Class Initialized
DEBUG - 2011-07-23 11:49:22 --> Output Class Initialized
DEBUG - 2011-07-23 11:49:22 --> Input Class Initialized
DEBUG - 2011-07-23 11:49:22 --> Global POST and COOKIE data sanitized
DEBUG - 2011-07-23 11:49:22 --> Language Class Initialized
DEBUG - 2011-07-23 11:49:22 --> Loader Class Initialized
DEBUG - 2011-07-23 11:49:22 --> Controller Class Initialized
DEBUG - 2011-07-23 11:49:22 --> Model Class Initialized
DEBUG - 2011-07-23 11:49:22 --> Model Class Initialized
DEBUG - 2011-07-23 11:49:22 --> Model Class Initialized
DEBUG - 2011-07-23 11:49:22 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-07-23 11:49:22 --> Database Driver Class Initialized
DEBUG - 2011-07-23 11:49:22 --> File loaded: application/views/table/main.php
DEBUG - 2011-07-23 11:49:22 --> Helper loaded: url_helper
DEBUG - 2011-07-23 11:49:22 --> File loaded: application/views/common/header.php
DEBUG - 2011-07-23 11:49:22 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-07-23 11:49:22 --> File loaded: application/views/common/footer.php
DEBUG - 2011-07-23 11:49:22 --> File loaded: application/views/layout/main.php
DEBUG - 2011-07-23 11:49:22 --> Final output sent to browser
DEBUG - 2011-07-23 11:49:22 --> Total execution time: 0.0531
DEBUG - 2011-07-23 11:52:27 --> Config Class Initialized
DEBUG - 2011-07-23 11:52:27 --> Hooks Class Initialized
DEBUG - 2011-07-23 11:52:27 --> Utf8 Class Initialized
DEBUG - 2011-07-23 11:52:27 --> UTF-8 Support Enabled
DEBUG - 2011-07-23 11:52:27 --> URI Class Initialized
DEBUG - 2011-07-23 11:52:27 --> Router Class Initialized
DEBUG - 2011-07-23 11:52:27 --> Output Class Initialized
DEBUG - 2011-07-23 11:52:27 --> Input Class Initialized
DEBUG - 2011-07-23 11:52:27 --> Global POST and COOKIE data sanitized
DEBUG - 2011-07-23 11:52:27 --> Language Class Initialized
DEBUG - 2011-07-23 11:52:27 --> Loader Class Initialized
DEBUG - 2011-07-23 11:52:27 --> Controller Class Initialized
DEBUG - 2011-07-23 11:52:27 --> Model Class Initialized
DEBUG - 2011-07-23 11:52:27 --> Model Class Initialized
DEBUG - 2011-07-23 11:52:27 --> Model Class Initialized
DEBUG - 2011-07-23 11:52:27 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-07-23 11:52:27 --> Database Driver Class Initialized
DEBUG - 2011-07-23 11:52:27 --> File loaded: application/views/table/main.php
DEBUG - 2011-07-23 11:52:27 --> Helper loaded: url_helper
DEBUG - 2011-07-23 11:52:27 --> File loaded: application/views/common/header.php
DEBUG - 2011-07-23 11:52:27 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-07-23 11:52:27 --> File loaded: application/views/common/footer.php
DEBUG - 2011-07-23 11:52:27 --> File loaded: application/views/layout/main.php
DEBUG - 2011-07-23 11:52:27 --> Final output sent to browser
DEBUG - 2011-07-23 11:52:27 --> Total execution time: 0.0698
DEBUG - 2011-07-23 11:52:49 --> Config Class Initialized
DEBUG - 2011-07-23 11:52:49 --> Hooks Class Initialized
DEBUG - 2011-07-23 11:52:49 --> Utf8 Class Initialized
DEBUG - 2011-07-23 11:52:49 --> UTF-8 Support Enabled
DEBUG - 2011-07-23 11:52:49 --> URI Class Initialized
DEBUG - 2011-07-23 11:52:49 --> Router Class Initialized
DEBUG - 2011-07-23 11:52:49 --> Output Class Initialized
DEBUG - 2011-07-23 11:52:49 --> Input Class Initialized
DEBUG - 2011-07-23 11:52:49 --> Global POST and COOKIE data sanitized
DEBUG - 2011-07-23 11:52:49 --> Language Class Initialized
DEBUG - 2011-07-23 11:52:49 --> Loader Class Initialized
DEBUG - 2011-07-23 11:52:49 --> Controller Class Initialized
DEBUG - 2011-07-23 11:52:49 --> Model Class Initialized
DEBUG - 2011-07-23 11:52:49 --> Model Class Initialized
DEBUG - 2011-07-23 11:52:49 --> Model Class Initialized
DEBUG - 2011-07-23 11:52:49 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-07-23 11:52:49 --> Database Driver Class Initialized
DEBUG - 2011-07-23 11:52:49 --> File loaded: application/views/table/main.php
DEBUG - 2011-07-23 11:52:49 --> Helper loaded: url_helper
DEBUG - 2011-07-23 11:52:49 --> File loaded: application/views/common/header.php
DEBUG - 2011-07-23 11:52:49 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-07-23 11:52:49 --> File loaded: application/views/common/footer.php
DEBUG - 2011-07-23 11:52:49 --> File loaded: application/views/layout/main.php
DEBUG - 2011-07-23 11:52:49 --> Final output sent to browser
DEBUG - 2011-07-23 11:52:49 --> Total execution time: 0.6217
DEBUG - 2011-07-23 11:52:52 --> Config Class Initialized
DEBUG - 2011-07-23 11:52:52 --> Hooks Class Initialized
DEBUG - 2011-07-23 11:52:52 --> Utf8 Class Initialized
DEBUG - 2011-07-23 11:52:52 --> UTF-8 Support Enabled
DEBUG - 2011-07-23 11:52:52 --> URI Class Initialized
DEBUG - 2011-07-23 11:52:52 --> Router Class Initialized
DEBUG - 2011-07-23 11:52:52 --> Output Class Initialized
DEBUG - 2011-07-23 11:52:52 --> Input Class Initialized
DEBUG - 2011-07-23 11:52:52 --> Global POST and COOKIE data sanitized
DEBUG - 2011-07-23 11:52:52 --> Language Class Initialized
DEBUG - 2011-07-23 11:52:52 --> Loader Class Initialized
DEBUG - 2011-07-23 11:52:52 --> Controller Class Initialized
DEBUG - 2011-07-23 11:52:52 --> Model Class Initialized
DEBUG - 2011-07-23 11:52:52 --> Model Class Initialized
DEBUG - 2011-07-23 11:52:52 --> Model Class Initialized
DEBUG - 2011-07-23 11:52:52 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-07-23 11:52:52 --> Database Driver Class Initialized
DEBUG - 2011-07-23 11:52:52 --> File loaded: application/views/table/main.php
DEBUG - 2011-07-23 11:52:52 --> Helper loaded: url_helper
DEBUG - 2011-07-23 11:52:52 --> File loaded: application/views/common/header.php
DEBUG - 2011-07-23 11:52:52 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-07-23 11:52:52 --> File loaded: application/views/common/footer.php
DEBUG - 2011-07-23 11:52:52 --> File loaded: application/views/layout/main.php
DEBUG - 2011-07-23 11:52:52 --> Final output sent to browser
DEBUG - 2011-07-23 11:52:52 --> Total execution time: 0.0564
DEBUG - 2011-07-23 12:02:22 --> Config Class Initialized
DEBUG - 2011-07-23 12:02:22 --> Hooks Class Initialized
DEBUG - 2011-07-23 12:02:22 --> Utf8 Class Initialized
DEBUG - 2011-07-23 12:02:22 --> UTF-8 Support Enabled
DEBUG - 2011-07-23 12:02:22 --> URI Class Initialized
DEBUG - 2011-07-23 12:02:22 --> Router Class Initialized
DEBUG - 2011-07-23 12:02:22 --> Output Class Initialized
DEBUG - 2011-07-23 12:02:22 --> Input Class Initialized
DEBUG - 2011-07-23 12:02:22 --> Global POST and COOKIE data sanitized
DEBUG - 2011-07-23 12:02:22 --> Language Class Initialized
DEBUG - 2011-07-23 12:02:22 --> Loader Class Initialized
DEBUG - 2011-07-23 12:02:22 --> Controller Class Initialized
ERROR - 2011-07-23 12:02:22 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-07-23 12:02:22 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-07-23 12:02:22 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-07-23 12:02:22 --> Model Class Initialized
DEBUG - 2011-07-23 12:02:22 --> Model Class Initialized
DEBUG - 2011-07-23 12:02:22 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-07-23 12:02:22 --> Database Driver Class Initialized
DEBUG - 2011-07-23 12:02:22 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-07-23 12:02:22 --> Helper loaded: url_helper
DEBUG - 2011-07-23 12:02:22 --> File loaded: application/views/common/header.php
DEBUG - 2011-07-23 12:02:22 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-07-23 12:02:22 --> File loaded: application/views/common/footer.php
DEBUG - 2011-07-23 12:02:22 --> File loaded: application/views/layout/main.php
DEBUG - 2011-07-23 12:02:22 --> Final output sent to browser
DEBUG - 2011-07-23 12:02:22 --> Total execution time: 0.1151
DEBUG - 2011-07-23 12:02:23 --> Config Class Initialized
DEBUG - 2011-07-23 12:02:23 --> Hooks Class Initialized
DEBUG - 2011-07-23 12:02:23 --> Utf8 Class Initialized
DEBUG - 2011-07-23 12:02:23 --> UTF-8 Support Enabled
DEBUG - 2011-07-23 12:02:23 --> URI Class Initialized
DEBUG - 2011-07-23 12:02:23 --> Router Class Initialized
DEBUG - 2011-07-23 12:02:23 --> Output Class Initialized
DEBUG - 2011-07-23 12:02:23 --> Input Class Initialized
DEBUG - 2011-07-23 12:02:23 --> Global POST and COOKIE data sanitized
DEBUG - 2011-07-23 12:02:23 --> Language Class Initialized
DEBUG - 2011-07-23 12:02:23 --> Loader Class Initialized
DEBUG - 2011-07-23 12:02:23 --> Controller Class Initialized
DEBUG - 2011-07-23 12:02:23 --> Model Class Initialized
DEBUG - 2011-07-23 12:02:23 --> Model Class Initialized
DEBUG - 2011-07-23 12:02:23 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-07-23 12:02:23 --> Database Driver Class Initialized
DEBUG - 2011-07-23 12:02:23 --> Final output sent to browser
DEBUG - 2011-07-23 12:02:23 --> Total execution time: 0.6761
DEBUG - 2011-07-23 12:04:07 --> Config Class Initialized
DEBUG - 2011-07-23 12:04:07 --> Hooks Class Initialized
DEBUG - 2011-07-23 12:04:07 --> Utf8 Class Initialized
DEBUG - 2011-07-23 12:04:07 --> UTF-8 Support Enabled
DEBUG - 2011-07-23 12:04:07 --> URI Class Initialized
DEBUG - 2011-07-23 12:04:07 --> Router Class Initialized
DEBUG - 2011-07-23 12:04:07 --> Output Class Initialized
DEBUG - 2011-07-23 12:04:07 --> Input Class Initialized
DEBUG - 2011-07-23 12:04:07 --> Global POST and COOKIE data sanitized
DEBUG - 2011-07-23 12:04:07 --> Language Class Initialized
DEBUG - 2011-07-23 12:04:07 --> Loader Class Initialized
DEBUG - 2011-07-23 12:04:07 --> Controller Class Initialized
ERROR - 2011-07-23 12:04:07 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-07-23 12:04:07 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-07-23 12:04:07 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-07-23 12:04:07 --> Model Class Initialized
DEBUG - 2011-07-23 12:04:07 --> Model Class Initialized
DEBUG - 2011-07-23 12:04:07 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-07-23 12:04:07 --> Database Driver Class Initialized
DEBUG - 2011-07-23 12:04:07 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-07-23 12:04:07 --> Helper loaded: url_helper
DEBUG - 2011-07-23 12:04:07 --> File loaded: application/views/common/header.php
DEBUG - 2011-07-23 12:04:07 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-07-23 12:04:07 --> File loaded: application/views/common/footer.php
DEBUG - 2011-07-23 12:04:07 --> File loaded: application/views/layout/main.php
DEBUG - 2011-07-23 12:04:07 --> Final output sent to browser
DEBUG - 2011-07-23 12:04:07 --> Total execution time: 0.0320
DEBUG - 2011-07-23 12:04:08 --> Config Class Initialized
DEBUG - 2011-07-23 12:04:08 --> Hooks Class Initialized
DEBUG - 2011-07-23 12:04:08 --> Utf8 Class Initialized
DEBUG - 2011-07-23 12:04:08 --> UTF-8 Support Enabled
DEBUG - 2011-07-23 12:04:08 --> URI Class Initialized
DEBUG - 2011-07-23 12:04:08 --> Router Class Initialized
DEBUG - 2011-07-23 12:04:08 --> Output Class Initialized
DEBUG - 2011-07-23 12:04:08 --> Input Class Initialized
DEBUG - 2011-07-23 12:04:08 --> Global POST and COOKIE data sanitized
DEBUG - 2011-07-23 12:04:08 --> Language Class Initialized
DEBUG - 2011-07-23 12:04:08 --> Loader Class Initialized
DEBUG - 2011-07-23 12:04:08 --> Controller Class Initialized
DEBUG - 2011-07-23 12:04:08 --> Model Class Initialized
DEBUG - 2011-07-23 12:04:08 --> Model Class Initialized
DEBUG - 2011-07-23 12:04:08 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-07-23 12:04:08 --> Database Driver Class Initialized
DEBUG - 2011-07-23 12:04:09 --> Final output sent to browser
DEBUG - 2011-07-23 12:04:09 --> Total execution time: 0.6926
DEBUG - 2011-07-23 12:19:09 --> Config Class Initialized
DEBUG - 2011-07-23 12:19:09 --> Hooks Class Initialized
DEBUG - 2011-07-23 12:19:09 --> Utf8 Class Initialized
DEBUG - 2011-07-23 12:19:09 --> UTF-8 Support Enabled
DEBUG - 2011-07-23 12:19:09 --> URI Class Initialized
DEBUG - 2011-07-23 12:19:09 --> Router Class Initialized
DEBUG - 2011-07-23 12:19:09 --> Output Class Initialized
DEBUG - 2011-07-23 12:19:09 --> Input Class Initialized
DEBUG - 2011-07-23 12:19:09 --> Global POST and COOKIE data sanitized
DEBUG - 2011-07-23 12:19:09 --> Language Class Initialized
DEBUG - 2011-07-23 12:19:09 --> Loader Class Initialized
DEBUG - 2011-07-23 12:19:09 --> Controller Class Initialized
ERROR - 2011-07-23 12:19:09 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-07-23 12:19:09 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-07-23 12:19:09 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-07-23 12:19:09 --> Model Class Initialized
DEBUG - 2011-07-23 12:19:09 --> Model Class Initialized
DEBUG - 2011-07-23 12:19:09 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-07-23 12:19:09 --> Database Driver Class Initialized
DEBUG - 2011-07-23 12:19:09 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-07-23 12:19:09 --> Helper loaded: url_helper
DEBUG - 2011-07-23 12:19:09 --> File loaded: application/views/common/header.php
DEBUG - 2011-07-23 12:19:09 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-07-23 12:19:09 --> File loaded: application/views/common/footer.php
DEBUG - 2011-07-23 12:19:09 --> File loaded: application/views/layout/main.php
DEBUG - 2011-07-23 12:19:09 --> Final output sent to browser
DEBUG - 2011-07-23 12:19:09 --> Total execution time: 0.0671
DEBUG - 2011-07-23 12:52:28 --> Config Class Initialized
DEBUG - 2011-07-23 12:52:28 --> Hooks Class Initialized
DEBUG - 2011-07-23 12:52:28 --> Utf8 Class Initialized
DEBUG - 2011-07-23 12:52:28 --> UTF-8 Support Enabled
DEBUG - 2011-07-23 12:52:28 --> URI Class Initialized
DEBUG - 2011-07-23 12:52:28 --> Router Class Initialized
DEBUG - 2011-07-23 12:52:28 --> Output Class Initialized
DEBUG - 2011-07-23 12:52:28 --> Input Class Initialized
DEBUG - 2011-07-23 12:52:28 --> Global POST and COOKIE data sanitized
DEBUG - 2011-07-23 12:52:28 --> Language Class Initialized
DEBUG - 2011-07-23 12:52:28 --> Loader Class Initialized
DEBUG - 2011-07-23 12:52:28 --> Controller Class Initialized
DEBUG - 2011-07-23 12:52:28 --> Model Class Initialized
DEBUG - 2011-07-23 12:52:28 --> Model Class Initialized
DEBUG - 2011-07-23 12:52:28 --> Model Class Initialized
DEBUG - 2011-07-23 12:52:28 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-07-23 12:52:29 --> Database Driver Class Initialized
DEBUG - 2011-07-23 12:52:29 --> File loaded: application/views/table/main.php
DEBUG - 2011-07-23 12:52:29 --> Helper loaded: url_helper
DEBUG - 2011-07-23 12:52:29 --> File loaded: application/views/common/header.php
DEBUG - 2011-07-23 12:52:29 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-07-23 12:52:29 --> File loaded: application/views/common/footer.php
DEBUG - 2011-07-23 12:52:29 --> File loaded: application/views/layout/main.php
DEBUG - 2011-07-23 12:52:29 --> Final output sent to browser
DEBUG - 2011-07-23 12:52:29 --> Total execution time: 0.6542
DEBUG - 2011-07-23 12:52:30 --> Config Class Initialized
DEBUG - 2011-07-23 12:52:30 --> Hooks Class Initialized
DEBUG - 2011-07-23 12:52:30 --> Utf8 Class Initialized
DEBUG - 2011-07-23 12:52:30 --> UTF-8 Support Enabled
DEBUG - 2011-07-23 12:52:30 --> URI Class Initialized
DEBUG - 2011-07-23 12:52:30 --> Router Class Initialized
ERROR - 2011-07-23 12:52:30 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-07-23 12:52:34 --> Config Class Initialized
DEBUG - 2011-07-23 12:52:34 --> Hooks Class Initialized
DEBUG - 2011-07-23 12:52:34 --> Utf8 Class Initialized
DEBUG - 2011-07-23 12:52:34 --> UTF-8 Support Enabled
DEBUG - 2011-07-23 12:52:34 --> URI Class Initialized
DEBUG - 2011-07-23 12:52:34 --> Router Class Initialized
DEBUG - 2011-07-23 12:52:34 --> Output Class Initialized
DEBUG - 2011-07-23 12:52:34 --> Input Class Initialized
DEBUG - 2011-07-23 12:52:34 --> Global POST and COOKIE data sanitized
DEBUG - 2011-07-23 12:52:34 --> Language Class Initialized
DEBUG - 2011-07-23 12:52:34 --> Loader Class Initialized
DEBUG - 2011-07-23 12:52:34 --> Controller Class Initialized
ERROR - 2011-07-23 12:52:34 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-07-23 12:52:34 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-07-23 12:52:34 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-07-23 12:52:34 --> Model Class Initialized
DEBUG - 2011-07-23 12:52:34 --> Model Class Initialized
DEBUG - 2011-07-23 12:52:34 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-07-23 12:52:34 --> Database Driver Class Initialized
DEBUG - 2011-07-23 12:52:34 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-07-23 12:52:34 --> Helper loaded: url_helper
DEBUG - 2011-07-23 12:52:34 --> File loaded: application/views/common/header.php
DEBUG - 2011-07-23 12:52:34 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-07-23 12:52:34 --> File loaded: application/views/common/footer.php
DEBUG - 2011-07-23 12:52:34 --> File loaded: application/views/layout/main.php
DEBUG - 2011-07-23 12:52:34 --> Final output sent to browser
DEBUG - 2011-07-23 12:52:34 --> Total execution time: 0.1068
DEBUG - 2011-07-23 12:52:34 --> Config Class Initialized
DEBUG - 2011-07-23 12:52:34 --> Hooks Class Initialized
DEBUG - 2011-07-23 12:52:34 --> Utf8 Class Initialized
DEBUG - 2011-07-23 12:52:34 --> UTF-8 Support Enabled
DEBUG - 2011-07-23 12:52:34 --> URI Class Initialized
DEBUG - 2011-07-23 12:52:34 --> Router Class Initialized
DEBUG - 2011-07-23 12:52:34 --> Output Class Initialized
DEBUG - 2011-07-23 12:52:34 --> Input Class Initialized
DEBUG - 2011-07-23 12:52:34 --> Global POST and COOKIE data sanitized
DEBUG - 2011-07-23 12:52:34 --> Language Class Initialized
DEBUG - 2011-07-23 12:52:34 --> Loader Class Initialized
DEBUG - 2011-07-23 12:52:34 --> Controller Class Initialized
DEBUG - 2011-07-23 12:52:34 --> Model Class Initialized
DEBUG - 2011-07-23 12:52:34 --> Model Class Initialized
DEBUG - 2011-07-23 12:52:34 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-07-23 12:52:34 --> Database Driver Class Initialized
DEBUG - 2011-07-23 12:52:35 --> Final output sent to browser
DEBUG - 2011-07-23 12:52:35 --> Total execution time: 0.5729
DEBUG - 2011-07-23 12:53:37 --> Config Class Initialized
DEBUG - 2011-07-23 12:53:37 --> Hooks Class Initialized
DEBUG - 2011-07-23 12:53:37 --> Utf8 Class Initialized
DEBUG - 2011-07-23 12:53:37 --> UTF-8 Support Enabled
DEBUG - 2011-07-23 12:53:37 --> URI Class Initialized
DEBUG - 2011-07-23 12:53:37 --> Router Class Initialized
DEBUG - 2011-07-23 12:53:37 --> Output Class Initialized
DEBUG - 2011-07-23 12:53:37 --> Input Class Initialized
DEBUG - 2011-07-23 12:53:37 --> Global POST and COOKIE data sanitized
DEBUG - 2011-07-23 12:53:37 --> Language Class Initialized
DEBUG - 2011-07-23 12:53:37 --> Loader Class Initialized
DEBUG - 2011-07-23 12:53:37 --> Controller Class Initialized
ERROR - 2011-07-23 12:53:37 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-07-23 12:53:37 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-07-23 12:53:37 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-07-23 12:53:37 --> Model Class Initialized
DEBUG - 2011-07-23 12:53:37 --> Model Class Initialized
DEBUG - 2011-07-23 12:53:37 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-07-23 12:53:37 --> Database Driver Class Initialized
DEBUG - 2011-07-23 12:53:37 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-07-23 12:53:37 --> Helper loaded: url_helper
DEBUG - 2011-07-23 12:53:37 --> File loaded: application/views/common/header.php
DEBUG - 2011-07-23 12:53:37 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-07-23 12:53:37 --> File loaded: application/views/common/footer.php
DEBUG - 2011-07-23 12:53:37 --> File loaded: application/views/layout/main.php
DEBUG - 2011-07-23 12:53:37 --> Final output sent to browser
DEBUG - 2011-07-23 12:53:37 --> Total execution time: 0.0275
DEBUG - 2011-07-23 12:53:37 --> Config Class Initialized
DEBUG - 2011-07-23 12:53:37 --> Hooks Class Initialized
DEBUG - 2011-07-23 12:53:37 --> Utf8 Class Initialized
DEBUG - 2011-07-23 12:53:37 --> UTF-8 Support Enabled
DEBUG - 2011-07-23 12:53:37 --> URI Class Initialized
DEBUG - 2011-07-23 12:53:37 --> Router Class Initialized
DEBUG - 2011-07-23 12:53:37 --> Output Class Initialized
DEBUG - 2011-07-23 12:53:37 --> Input Class Initialized
DEBUG - 2011-07-23 12:53:37 --> Global POST and COOKIE data sanitized
DEBUG - 2011-07-23 12:53:37 --> Language Class Initialized
DEBUG - 2011-07-23 12:53:37 --> Loader Class Initialized
DEBUG - 2011-07-23 12:53:37 --> Controller Class Initialized
DEBUG - 2011-07-23 12:53:37 --> Model Class Initialized
DEBUG - 2011-07-23 12:53:37 --> Model Class Initialized
DEBUG - 2011-07-23 12:53:37 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-07-23 12:53:37 --> Database Driver Class Initialized
DEBUG - 2011-07-23 12:53:38 --> Final output sent to browser
DEBUG - 2011-07-23 12:53:38 --> Total execution time: 0.6085
DEBUG - 2011-07-23 12:53:51 --> Config Class Initialized
DEBUG - 2011-07-23 12:53:51 --> Hooks Class Initialized
DEBUG - 2011-07-23 12:53:51 --> Utf8 Class Initialized
DEBUG - 2011-07-23 12:53:51 --> UTF-8 Support Enabled
DEBUG - 2011-07-23 12:53:51 --> URI Class Initialized
DEBUG - 2011-07-23 12:53:51 --> Router Class Initialized
DEBUG - 2011-07-23 12:53:51 --> Output Class Initialized
DEBUG - 2011-07-23 12:53:51 --> Input Class Initialized
DEBUG - 2011-07-23 12:53:51 --> Global POST and COOKIE data sanitized
DEBUG - 2011-07-23 12:53:51 --> Language Class Initialized
DEBUG - 2011-07-23 12:53:51 --> Loader Class Initialized
DEBUG - 2011-07-23 12:53:51 --> Controller Class Initialized
ERROR - 2011-07-23 12:53:51 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-07-23 12:53:51 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-07-23 12:53:51 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-07-23 12:53:51 --> Model Class Initialized
DEBUG - 2011-07-23 12:53:51 --> Model Class Initialized
DEBUG - 2011-07-23 12:53:51 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-07-23 12:53:51 --> Database Driver Class Initialized
DEBUG - 2011-07-23 12:53:51 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-07-23 12:53:51 --> Helper loaded: url_helper
DEBUG - 2011-07-23 12:53:51 --> File loaded: application/views/common/header.php
DEBUG - 2011-07-23 12:53:51 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-07-23 12:53:51 --> File loaded: application/views/common/footer.php
DEBUG - 2011-07-23 12:53:51 --> File loaded: application/views/layout/main.php
DEBUG - 2011-07-23 12:53:51 --> Final output sent to browser
DEBUG - 2011-07-23 12:53:51 --> Total execution time: 0.0293
DEBUG - 2011-07-23 12:53:52 --> Config Class Initialized
DEBUG - 2011-07-23 12:53:52 --> Hooks Class Initialized
DEBUG - 2011-07-23 12:53:52 --> Utf8 Class Initialized
DEBUG - 2011-07-23 12:53:52 --> UTF-8 Support Enabled
DEBUG - 2011-07-23 12:53:52 --> URI Class Initialized
DEBUG - 2011-07-23 12:53:52 --> Router Class Initialized
DEBUG - 2011-07-23 12:53:52 --> Output Class Initialized
DEBUG - 2011-07-23 12:53:52 --> Input Class Initialized
DEBUG - 2011-07-23 12:53:52 --> Global POST and COOKIE data sanitized
DEBUG - 2011-07-23 12:53:52 --> Language Class Initialized
DEBUG - 2011-07-23 12:53:52 --> Loader Class Initialized
DEBUG - 2011-07-23 12:53:52 --> Controller Class Initialized
DEBUG - 2011-07-23 12:53:52 --> Model Class Initialized
DEBUG - 2011-07-23 12:53:52 --> Model Class Initialized
DEBUG - 2011-07-23 12:53:52 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-07-23 12:53:52 --> Database Driver Class Initialized
DEBUG - 2011-07-23 12:53:52 --> Final output sent to browser
DEBUG - 2011-07-23 12:53:52 --> Total execution time: 0.5164
DEBUG - 2011-07-23 12:54:05 --> Config Class Initialized
DEBUG - 2011-07-23 12:54:05 --> Hooks Class Initialized
DEBUG - 2011-07-23 12:54:05 --> Utf8 Class Initialized
DEBUG - 2011-07-23 12:54:05 --> UTF-8 Support Enabled
DEBUG - 2011-07-23 12:54:05 --> URI Class Initialized
DEBUG - 2011-07-23 12:54:05 --> Router Class Initialized
DEBUG - 2011-07-23 12:54:05 --> Output Class Initialized
DEBUG - 2011-07-23 12:54:05 --> Input Class Initialized
DEBUG - 2011-07-23 12:54:05 --> Global POST and COOKIE data sanitized
DEBUG - 2011-07-23 12:54:05 --> Language Class Initialized
DEBUG - 2011-07-23 12:54:05 --> Loader Class Initialized
DEBUG - 2011-07-23 12:54:05 --> Controller Class Initialized
ERROR - 2011-07-23 12:54:05 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-07-23 12:54:05 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-07-23 12:54:05 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-07-23 12:54:05 --> Model Class Initialized
DEBUG - 2011-07-23 12:54:05 --> Model Class Initialized
DEBUG - 2011-07-23 12:54:05 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-07-23 12:54:05 --> Database Driver Class Initialized
DEBUG - 2011-07-23 12:54:05 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-07-23 12:54:05 --> Helper loaded: url_helper
DEBUG - 2011-07-23 12:54:05 --> File loaded: application/views/common/header.php
DEBUG - 2011-07-23 12:54:05 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-07-23 12:54:05 --> File loaded: application/views/common/footer.php
DEBUG - 2011-07-23 12:54:05 --> File loaded: application/views/layout/main.php
DEBUG - 2011-07-23 12:54:05 --> Final output sent to browser
DEBUG - 2011-07-23 12:54:05 --> Total execution time: 0.0312
DEBUG - 2011-07-23 12:54:05 --> Config Class Initialized
DEBUG - 2011-07-23 12:54:05 --> Hooks Class Initialized
DEBUG - 2011-07-23 12:54:05 --> Utf8 Class Initialized
DEBUG - 2011-07-23 12:54:05 --> UTF-8 Support Enabled
DEBUG - 2011-07-23 12:54:05 --> URI Class Initialized
DEBUG - 2011-07-23 12:54:05 --> Router Class Initialized
DEBUG - 2011-07-23 12:54:05 --> Output Class Initialized
DEBUG - 2011-07-23 12:54:05 --> Input Class Initialized
DEBUG - 2011-07-23 12:54:05 --> Global POST and COOKIE data sanitized
DEBUG - 2011-07-23 12:54:05 --> Language Class Initialized
DEBUG - 2011-07-23 12:54:05 --> Loader Class Initialized
DEBUG - 2011-07-23 12:54:05 --> Controller Class Initialized
DEBUG - 2011-07-23 12:54:05 --> Model Class Initialized
DEBUG - 2011-07-23 12:54:05 --> Model Class Initialized
DEBUG - 2011-07-23 12:54:05 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-07-23 12:54:05 --> Database Driver Class Initialized
DEBUG - 2011-07-23 12:54:06 --> Final output sent to browser
DEBUG - 2011-07-23 12:54:06 --> Total execution time: 0.5140
DEBUG - 2011-07-23 12:54:30 --> Config Class Initialized
DEBUG - 2011-07-23 12:54:30 --> Hooks Class Initialized
DEBUG - 2011-07-23 12:54:30 --> Utf8 Class Initialized
DEBUG - 2011-07-23 12:54:30 --> UTF-8 Support Enabled
DEBUG - 2011-07-23 12:54:30 --> URI Class Initialized
DEBUG - 2011-07-23 12:54:30 --> Router Class Initialized
DEBUG - 2011-07-23 12:54:30 --> Output Class Initialized
DEBUG - 2011-07-23 12:54:30 --> Input Class Initialized
DEBUG - 2011-07-23 12:54:30 --> Global POST and COOKIE data sanitized
DEBUG - 2011-07-23 12:54:30 --> Language Class Initialized
DEBUG - 2011-07-23 12:54:30 --> Loader Class Initialized
DEBUG - 2011-07-23 12:54:30 --> Controller Class Initialized
DEBUG - 2011-07-23 12:54:30 --> Model Class Initialized
DEBUG - 2011-07-23 12:54:30 --> Model Class Initialized
DEBUG - 2011-07-23 12:54:30 --> Model Class Initialized
DEBUG - 2011-07-23 12:54:30 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-07-23 12:54:30 --> Database Driver Class Initialized
DEBUG - 2011-07-23 12:54:30 --> File loaded: application/views/table/main.php
DEBUG - 2011-07-23 12:54:30 --> Helper loaded: url_helper
DEBUG - 2011-07-23 12:54:30 --> File loaded: application/views/common/header.php
DEBUG - 2011-07-23 12:54:30 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-07-23 12:54:30 --> File loaded: application/views/common/footer.php
DEBUG - 2011-07-23 12:54:30 --> File loaded: application/views/layout/main.php
DEBUG - 2011-07-23 12:54:30 --> Final output sent to browser
DEBUG - 2011-07-23 12:54:30 --> Total execution time: 0.0482
DEBUG - 2011-07-23 12:54:35 --> Config Class Initialized
DEBUG - 2011-07-23 12:54:35 --> Hooks Class Initialized
DEBUG - 2011-07-23 12:54:35 --> Utf8 Class Initialized
DEBUG - 2011-07-23 12:54:35 --> UTF-8 Support Enabled
DEBUG - 2011-07-23 12:54:35 --> URI Class Initialized
DEBUG - 2011-07-23 12:54:35 --> Router Class Initialized
DEBUG - 2011-07-23 12:54:35 --> Output Class Initialized
DEBUG - 2011-07-23 12:54:35 --> Input Class Initialized
DEBUG - 2011-07-23 12:54:35 --> Global POST and COOKIE data sanitized
DEBUG - 2011-07-23 12:54:35 --> Language Class Initialized
DEBUG - 2011-07-23 12:54:35 --> Loader Class Initialized
DEBUG - 2011-07-23 12:54:35 --> Controller Class Initialized
ERROR - 2011-07-23 12:54:35 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-07-23 12:54:35 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-07-23 12:54:35 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-07-23 12:54:35 --> Model Class Initialized
DEBUG - 2011-07-23 12:54:35 --> Model Class Initialized
DEBUG - 2011-07-23 12:54:35 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-07-23 12:54:35 --> Database Driver Class Initialized
DEBUG - 2011-07-23 12:54:35 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-07-23 12:54:35 --> Helper loaded: url_helper
DEBUG - 2011-07-23 12:54:35 --> File loaded: application/views/common/header.php
DEBUG - 2011-07-23 12:54:35 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-07-23 12:54:35 --> File loaded: application/views/common/footer.php
DEBUG - 2011-07-23 12:54:35 --> File loaded: application/views/layout/main.php
DEBUG - 2011-07-23 12:54:35 --> Final output sent to browser
DEBUG - 2011-07-23 12:54:35 --> Total execution time: 0.0281
DEBUG - 2011-07-23 12:54:36 --> Config Class Initialized
DEBUG - 2011-07-23 12:54:36 --> Hooks Class Initialized
DEBUG - 2011-07-23 12:54:36 --> Utf8 Class Initialized
DEBUG - 2011-07-23 12:54:36 --> UTF-8 Support Enabled
DEBUG - 2011-07-23 12:54:36 --> URI Class Initialized
DEBUG - 2011-07-23 12:54:36 --> Router Class Initialized
DEBUG - 2011-07-23 12:54:36 --> Output Class Initialized
DEBUG - 2011-07-23 12:54:36 --> Input Class Initialized
DEBUG - 2011-07-23 12:54:36 --> Global POST and COOKIE data sanitized
DEBUG - 2011-07-23 12:54:36 --> Language Class Initialized
DEBUG - 2011-07-23 12:54:36 --> Loader Class Initialized
DEBUG - 2011-07-23 12:54:36 --> Controller Class Initialized
DEBUG - 2011-07-23 12:54:36 --> Model Class Initialized
DEBUG - 2011-07-23 12:54:36 --> Model Class Initialized
DEBUG - 2011-07-23 12:54:36 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-07-23 12:54:36 --> Database Driver Class Initialized
DEBUG - 2011-07-23 12:54:36 --> Final output sent to browser
DEBUG - 2011-07-23 12:54:36 --> Total execution time: 0.5946
DEBUG - 2011-07-23 12:54:57 --> Config Class Initialized
DEBUG - 2011-07-23 12:54:57 --> Hooks Class Initialized
DEBUG - 2011-07-23 12:54:57 --> Utf8 Class Initialized
DEBUG - 2011-07-23 12:54:57 --> UTF-8 Support Enabled
DEBUG - 2011-07-23 12:54:57 --> URI Class Initialized
DEBUG - 2011-07-23 12:54:57 --> Router Class Initialized
DEBUG - 2011-07-23 12:54:57 --> Output Class Initialized
DEBUG - 2011-07-23 12:54:57 --> Input Class Initialized
DEBUG - 2011-07-23 12:54:57 --> Global POST and COOKIE data sanitized
DEBUG - 2011-07-23 12:54:57 --> Language Class Initialized
DEBUG - 2011-07-23 12:54:57 --> Loader Class Initialized
DEBUG - 2011-07-23 12:54:57 --> Controller Class Initialized
ERROR - 2011-07-23 12:54:57 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-07-23 12:54:57 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-07-23 12:54:57 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-07-23 12:54:57 --> Model Class Initialized
DEBUG - 2011-07-23 12:54:57 --> Model Class Initialized
DEBUG - 2011-07-23 12:54:57 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-07-23 12:54:57 --> Database Driver Class Initialized
DEBUG - 2011-07-23 12:54:57 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-07-23 12:54:57 --> Helper loaded: url_helper
DEBUG - 2011-07-23 12:54:57 --> File loaded: application/views/common/header.php
DEBUG - 2011-07-23 12:54:57 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-07-23 12:54:57 --> File loaded: application/views/common/footer.php
DEBUG - 2011-07-23 12:54:57 --> File loaded: application/views/layout/main.php
DEBUG - 2011-07-23 12:54:57 --> Final output sent to browser
DEBUG - 2011-07-23 12:54:57 --> Total execution time: 0.0431
DEBUG - 2011-07-23 12:54:58 --> Config Class Initialized
DEBUG - 2011-07-23 12:54:58 --> Hooks Class Initialized
DEBUG - 2011-07-23 12:54:58 --> Utf8 Class Initialized
DEBUG - 2011-07-23 12:54:58 --> UTF-8 Support Enabled
DEBUG - 2011-07-23 12:54:58 --> URI Class Initialized
DEBUG - 2011-07-23 12:54:58 --> Router Class Initialized
DEBUG - 2011-07-23 12:54:58 --> Output Class Initialized
DEBUG - 2011-07-23 12:54:58 --> Input Class Initialized
DEBUG - 2011-07-23 12:54:58 --> Global POST and COOKIE data sanitized
DEBUG - 2011-07-23 12:54:58 --> Language Class Initialized
DEBUG - 2011-07-23 12:54:58 --> Loader Class Initialized
DEBUG - 2011-07-23 12:54:58 --> Controller Class Initialized
DEBUG - 2011-07-23 12:54:58 --> Model Class Initialized
DEBUG - 2011-07-23 12:54:58 --> Model Class Initialized
DEBUG - 2011-07-23 12:54:58 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-07-23 12:54:58 --> Database Driver Class Initialized
DEBUG - 2011-07-23 12:54:59 --> Final output sent to browser
DEBUG - 2011-07-23 12:54:59 --> Total execution time: 0.9729
DEBUG - 2011-07-23 12:55:00 --> Config Class Initialized
DEBUG - 2011-07-23 12:55:00 --> Hooks Class Initialized
DEBUG - 2011-07-23 12:55:00 --> Utf8 Class Initialized
DEBUG - 2011-07-23 12:55:00 --> UTF-8 Support Enabled
DEBUG - 2011-07-23 12:55:00 --> URI Class Initialized
DEBUG - 2011-07-23 12:55:00 --> Router Class Initialized
DEBUG - 2011-07-23 12:55:00 --> Output Class Initialized
DEBUG - 2011-07-23 12:55:00 --> Input Class Initialized
DEBUG - 2011-07-23 12:55:00 --> Global POST and COOKIE data sanitized
DEBUG - 2011-07-23 12:55:00 --> Language Class Initialized
DEBUG - 2011-07-23 12:55:00 --> Loader Class Initialized
DEBUG - 2011-07-23 12:55:00 --> Controller Class Initialized
ERROR - 2011-07-23 12:55:00 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-07-23 12:55:00 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-07-23 12:55:00 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-07-23 12:55:00 --> Model Class Initialized
DEBUG - 2011-07-23 12:55:00 --> Model Class Initialized
DEBUG - 2011-07-23 12:55:00 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-07-23 12:55:00 --> Database Driver Class Initialized
DEBUG - 2011-07-23 12:55:00 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-07-23 12:55:00 --> Helper loaded: url_helper
DEBUG - 2011-07-23 12:55:00 --> File loaded: application/views/common/header.php
DEBUG - 2011-07-23 12:55:00 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-07-23 12:55:00 --> File loaded: application/views/common/footer.php
DEBUG - 2011-07-23 12:55:00 --> File loaded: application/views/layout/main.php
DEBUG - 2011-07-23 12:55:00 --> Final output sent to browser
DEBUG - 2011-07-23 12:55:00 --> Total execution time: 0.0733
DEBUG - 2011-07-23 12:55:10 --> Config Class Initialized
DEBUG - 2011-07-23 12:55:10 --> Hooks Class Initialized
DEBUG - 2011-07-23 12:55:10 --> Utf8 Class Initialized
DEBUG - 2011-07-23 12:55:10 --> UTF-8 Support Enabled
DEBUG - 2011-07-23 12:55:10 --> URI Class Initialized
DEBUG - 2011-07-23 12:55:10 --> Router Class Initialized
DEBUG - 2011-07-23 12:55:10 --> Output Class Initialized
DEBUG - 2011-07-23 12:55:10 --> Input Class Initialized
DEBUG - 2011-07-23 12:55:10 --> Global POST and COOKIE data sanitized
DEBUG - 2011-07-23 12:55:10 --> Language Class Initialized
DEBUG - 2011-07-23 12:55:10 --> Loader Class Initialized
DEBUG - 2011-07-23 12:55:10 --> Controller Class Initialized
ERROR - 2011-07-23 12:55:10 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-07-23 12:55:10 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-07-23 12:55:10 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-07-23 12:55:10 --> Model Class Initialized
DEBUG - 2011-07-23 12:55:10 --> Model Class Initialized
DEBUG - 2011-07-23 12:55:10 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-07-23 12:55:10 --> Database Driver Class Initialized
DEBUG - 2011-07-23 12:55:10 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-07-23 12:55:10 --> Helper loaded: url_helper
DEBUG - 2011-07-23 12:55:10 --> File loaded: application/views/common/header.php
DEBUG - 2011-07-23 12:55:10 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-07-23 12:55:10 --> File loaded: application/views/common/footer.php
DEBUG - 2011-07-23 12:55:10 --> File loaded: application/views/layout/main.php
DEBUG - 2011-07-23 12:55:10 --> Final output sent to browser
DEBUG - 2011-07-23 12:55:10 --> Total execution time: 0.0615
DEBUG - 2011-07-23 12:55:11 --> Config Class Initialized
DEBUG - 2011-07-23 12:55:11 --> Hooks Class Initialized
DEBUG - 2011-07-23 12:55:11 --> Utf8 Class Initialized
DEBUG - 2011-07-23 12:55:11 --> UTF-8 Support Enabled
DEBUG - 2011-07-23 12:55:11 --> URI Class Initialized
DEBUG - 2011-07-23 12:55:11 --> Router Class Initialized
DEBUG - 2011-07-23 12:55:11 --> Output Class Initialized
DEBUG - 2011-07-23 12:55:11 --> Input Class Initialized
DEBUG - 2011-07-23 12:55:11 --> Global POST and COOKIE data sanitized
DEBUG - 2011-07-23 12:55:11 --> Language Class Initialized
DEBUG - 2011-07-23 12:55:11 --> Loader Class Initialized
DEBUG - 2011-07-23 12:55:11 --> Controller Class Initialized
DEBUG - 2011-07-23 12:55:11 --> Model Class Initialized
DEBUG - 2011-07-23 12:55:11 --> Model Class Initialized
DEBUG - 2011-07-23 12:55:11 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-07-23 12:55:11 --> Database Driver Class Initialized
DEBUG - 2011-07-23 12:55:11 --> Final output sent to browser
DEBUG - 2011-07-23 12:55:11 --> Total execution time: 0.5544
DEBUG - 2011-07-23 12:55:11 --> Config Class Initialized
DEBUG - 2011-07-23 12:55:11 --> Hooks Class Initialized
DEBUG - 2011-07-23 12:55:11 --> Utf8 Class Initialized
DEBUG - 2011-07-23 12:55:11 --> UTF-8 Support Enabled
DEBUG - 2011-07-23 12:55:11 --> URI Class Initialized
DEBUG - 2011-07-23 12:55:11 --> Router Class Initialized
DEBUG - 2011-07-23 12:55:11 --> Output Class Initialized
DEBUG - 2011-07-23 12:55:11 --> Input Class Initialized
DEBUG - 2011-07-23 12:55:11 --> Global POST and COOKIE data sanitized
DEBUG - 2011-07-23 12:55:11 --> Language Class Initialized
DEBUG - 2011-07-23 12:55:11 --> Loader Class Initialized
DEBUG - 2011-07-23 12:55:11 --> Controller Class Initialized
ERROR - 2011-07-23 12:55:11 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-07-23 12:55:11 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-07-23 12:55:11 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-07-23 12:55:11 --> Model Class Initialized
DEBUG - 2011-07-23 12:55:11 --> Model Class Initialized
DEBUG - 2011-07-23 12:55:11 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-07-23 12:55:11 --> Database Driver Class Initialized
DEBUG - 2011-07-23 12:55:11 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-07-23 12:55:11 --> Helper loaded: url_helper
DEBUG - 2011-07-23 12:55:11 --> File loaded: application/views/common/header.php
DEBUG - 2011-07-23 12:55:11 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-07-23 12:55:11 --> File loaded: application/views/common/footer.php
DEBUG - 2011-07-23 12:55:11 --> File loaded: application/views/layout/main.php
DEBUG - 2011-07-23 12:55:11 --> Final output sent to browser
DEBUG - 2011-07-23 12:55:11 --> Total execution time: 0.0413
DEBUG - 2011-07-23 12:55:16 --> Config Class Initialized
DEBUG - 2011-07-23 12:55:16 --> Hooks Class Initialized
DEBUG - 2011-07-23 12:55:16 --> Utf8 Class Initialized
DEBUG - 2011-07-23 12:55:16 --> UTF-8 Support Enabled
DEBUG - 2011-07-23 12:55:16 --> URI Class Initialized
DEBUG - 2011-07-23 12:55:16 --> Router Class Initialized
DEBUG - 2011-07-23 12:55:16 --> Output Class Initialized
DEBUG - 2011-07-23 12:55:16 --> Input Class Initialized
DEBUG - 2011-07-23 12:55:16 --> Global POST and COOKIE data sanitized
DEBUG - 2011-07-23 12:55:16 --> Language Class Initialized
DEBUG - 2011-07-23 12:55:16 --> Loader Class Initialized
DEBUG - 2011-07-23 12:55:16 --> Controller Class Initialized
DEBUG - 2011-07-23 12:55:16 --> Model Class Initialized
DEBUG - 2011-07-23 12:55:16 --> Model Class Initialized
DEBUG - 2011-07-23 12:55:16 --> Model Class Initialized
DEBUG - 2011-07-23 12:55:16 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-07-23 12:55:16 --> Database Driver Class Initialized
DEBUG - 2011-07-23 12:55:16 --> File loaded: application/views/table/main.php
DEBUG - 2011-07-23 12:55:16 --> Helper loaded: url_helper
DEBUG - 2011-07-23 12:55:16 --> File loaded: application/views/common/header.php
DEBUG - 2011-07-23 12:55:16 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-07-23 12:55:16 --> File loaded: application/views/common/footer.php
DEBUG - 2011-07-23 12:55:16 --> File loaded: application/views/layout/main.php
DEBUG - 2011-07-23 12:55:16 --> Final output sent to browser
DEBUG - 2011-07-23 12:55:16 --> Total execution time: 0.1708
DEBUG - 2011-07-23 12:55:16 --> Config Class Initialized
DEBUG - 2011-07-23 12:55:16 --> Hooks Class Initialized
DEBUG - 2011-07-23 12:55:16 --> Utf8 Class Initialized
DEBUG - 2011-07-23 12:55:16 --> UTF-8 Support Enabled
DEBUG - 2011-07-23 12:55:16 --> URI Class Initialized
DEBUG - 2011-07-23 12:55:16 --> Router Class Initialized
DEBUG - 2011-07-23 12:55:16 --> Output Class Initialized
DEBUG - 2011-07-23 12:55:16 --> Input Class Initialized
DEBUG - 2011-07-23 12:55:16 --> Global POST and COOKIE data sanitized
DEBUG - 2011-07-23 12:55:16 --> Language Class Initialized
DEBUG - 2011-07-23 12:55:16 --> Loader Class Initialized
DEBUG - 2011-07-23 12:55:16 --> Controller Class Initialized
ERROR - 2011-07-23 12:55:16 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-07-23 12:55:16 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-07-23 12:55:16 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-07-23 12:55:16 --> Model Class Initialized
DEBUG - 2011-07-23 12:55:16 --> Model Class Initialized
DEBUG - 2011-07-23 12:55:16 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-07-23 12:55:16 --> Database Driver Class Initialized
DEBUG - 2011-07-23 12:55:16 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-07-23 12:55:16 --> Helper loaded: url_helper
DEBUG - 2011-07-23 12:55:16 --> File loaded: application/views/common/header.php
DEBUG - 2011-07-23 12:55:16 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-07-23 12:55:16 --> File loaded: application/views/common/footer.php
DEBUG - 2011-07-23 12:55:16 --> File loaded: application/views/layout/main.php
DEBUG - 2011-07-23 12:55:16 --> Final output sent to browser
DEBUG - 2011-07-23 12:55:16 --> Total execution time: 0.0284
DEBUG - 2011-07-23 12:55:17 --> Config Class Initialized
DEBUG - 2011-07-23 12:55:17 --> Hooks Class Initialized
DEBUG - 2011-07-23 12:55:17 --> Utf8 Class Initialized
DEBUG - 2011-07-23 12:55:17 --> UTF-8 Support Enabled
DEBUG - 2011-07-23 12:55:17 --> URI Class Initialized
DEBUG - 2011-07-23 12:55:17 --> Router Class Initialized
DEBUG - 2011-07-23 12:55:17 --> Output Class Initialized
DEBUG - 2011-07-23 12:55:17 --> Input Class Initialized
DEBUG - 2011-07-23 12:55:17 --> Global POST and COOKIE data sanitized
DEBUG - 2011-07-23 12:55:17 --> Language Class Initialized
DEBUG - 2011-07-23 12:55:17 --> Loader Class Initialized
DEBUG - 2011-07-23 12:55:17 --> Controller Class Initialized
DEBUG - 2011-07-23 12:55:17 --> Model Class Initialized
DEBUG - 2011-07-23 12:55:17 --> Model Class Initialized
DEBUG - 2011-07-23 12:55:17 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-07-23 12:55:17 --> Database Driver Class Initialized
DEBUG - 2011-07-23 12:55:18 --> Final output sent to browser
DEBUG - 2011-07-23 12:55:18 --> Total execution time: 0.5944
DEBUG - 2011-07-23 12:55:20 --> Config Class Initialized
DEBUG - 2011-07-23 12:55:20 --> Hooks Class Initialized
DEBUG - 2011-07-23 12:55:20 --> Utf8 Class Initialized
DEBUG - 2011-07-23 12:55:20 --> UTF-8 Support Enabled
DEBUG - 2011-07-23 12:55:20 --> URI Class Initialized
DEBUG - 2011-07-23 12:55:20 --> Router Class Initialized
ERROR - 2011-07-23 12:55:20 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-07-23 12:55:21 --> Config Class Initialized
DEBUG - 2011-07-23 12:55:21 --> Hooks Class Initialized
DEBUG - 2011-07-23 12:55:21 --> Utf8 Class Initialized
DEBUG - 2011-07-23 12:55:21 --> UTF-8 Support Enabled
DEBUG - 2011-07-23 12:55:21 --> URI Class Initialized
DEBUG - 2011-07-23 12:55:21 --> Router Class Initialized
ERROR - 2011-07-23 12:55:21 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-07-23 12:55:34 --> Config Class Initialized
DEBUG - 2011-07-23 12:55:34 --> Hooks Class Initialized
DEBUG - 2011-07-23 12:55:34 --> Utf8 Class Initialized
DEBUG - 2011-07-23 12:55:34 --> UTF-8 Support Enabled
DEBUG - 2011-07-23 12:55:34 --> URI Class Initialized
DEBUG - 2011-07-23 12:55:34 --> Router Class Initialized
DEBUG - 2011-07-23 12:55:34 --> Output Class Initialized
DEBUG - 2011-07-23 12:55:34 --> Input Class Initialized
DEBUG - 2011-07-23 12:55:34 --> Global POST and COOKIE data sanitized
DEBUG - 2011-07-23 12:55:34 --> Language Class Initialized
DEBUG - 2011-07-23 12:55:34 --> Loader Class Initialized
DEBUG - 2011-07-23 12:55:34 --> Controller Class Initialized
ERROR - 2011-07-23 12:55:34 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-07-23 12:55:34 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-07-23 12:55:34 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-07-23 12:55:34 --> Model Class Initialized
DEBUG - 2011-07-23 12:55:34 --> Model Class Initialized
DEBUG - 2011-07-23 12:55:34 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-07-23 12:55:34 --> Database Driver Class Initialized
DEBUG - 2011-07-23 12:55:34 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-07-23 12:55:34 --> Helper loaded: url_helper
DEBUG - 2011-07-23 12:55:34 --> File loaded: application/views/common/header.php
DEBUG - 2011-07-23 12:55:34 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-07-23 12:55:34 --> File loaded: application/views/common/footer.php
DEBUG - 2011-07-23 12:55:34 --> File loaded: application/views/layout/main.php
DEBUG - 2011-07-23 12:55:34 --> Final output sent to browser
DEBUG - 2011-07-23 12:55:34 --> Total execution time: 0.0277
DEBUG - 2011-07-23 12:55:34 --> Config Class Initialized
DEBUG - 2011-07-23 12:55:34 --> Hooks Class Initialized
DEBUG - 2011-07-23 12:55:34 --> Utf8 Class Initialized
DEBUG - 2011-07-23 12:55:34 --> UTF-8 Support Enabled
DEBUG - 2011-07-23 12:55:34 --> URI Class Initialized
DEBUG - 2011-07-23 12:55:34 --> Router Class Initialized
DEBUG - 2011-07-23 12:55:34 --> Output Class Initialized
DEBUG - 2011-07-23 12:55:34 --> Input Class Initialized
DEBUG - 2011-07-23 12:55:34 --> Global POST and COOKIE data sanitized
DEBUG - 2011-07-23 12:55:34 --> Language Class Initialized
DEBUG - 2011-07-23 12:55:34 --> Loader Class Initialized
DEBUG - 2011-07-23 12:55:34 --> Controller Class Initialized
DEBUG - 2011-07-23 12:55:34 --> Model Class Initialized
DEBUG - 2011-07-23 12:55:34 --> Model Class Initialized
DEBUG - 2011-07-23 12:55:34 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-07-23 12:55:34 --> Database Driver Class Initialized
DEBUG - 2011-07-23 12:55:35 --> Config Class Initialized
DEBUG - 2011-07-23 12:55:35 --> Hooks Class Initialized
DEBUG - 2011-07-23 12:55:35 --> Utf8 Class Initialized
DEBUG - 2011-07-23 12:55:35 --> UTF-8 Support Enabled
DEBUG - 2011-07-23 12:55:35 --> URI Class Initialized
DEBUG - 2011-07-23 12:55:35 --> Router Class Initialized
DEBUG - 2011-07-23 12:55:35 --> Output Class Initialized
DEBUG - 2011-07-23 12:55:35 --> Input Class Initialized
DEBUG - 2011-07-23 12:55:35 --> Global POST and COOKIE data sanitized
DEBUG - 2011-07-23 12:55:35 --> Language Class Initialized
DEBUG - 2011-07-23 12:55:35 --> Loader Class Initialized
DEBUG - 2011-07-23 12:55:35 --> Controller Class Initialized
ERROR - 2011-07-23 12:55:35 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-07-23 12:55:35 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-07-23 12:55:35 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-07-23 12:55:35 --> Model Class Initialized
DEBUG - 2011-07-23 12:55:35 --> Model Class Initialized
DEBUG - 2011-07-23 12:55:35 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-07-23 12:55:35 --> Database Driver Class Initialized
DEBUG - 2011-07-23 12:55:35 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-07-23 12:55:35 --> Helper loaded: url_helper
DEBUG - 2011-07-23 12:55:35 --> File loaded: application/views/common/header.php
DEBUG - 2011-07-23 12:55:35 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-07-23 12:55:35 --> File loaded: application/views/common/footer.php
DEBUG - 2011-07-23 12:55:35 --> File loaded: application/views/layout/main.php
DEBUG - 2011-07-23 12:55:35 --> Final output sent to browser
DEBUG - 2011-07-23 12:55:35 --> Total execution time: 0.0330
DEBUG - 2011-07-23 12:55:35 --> Final output sent to browser
DEBUG - 2011-07-23 12:55:35 --> Total execution time: 0.5374
DEBUG - 2011-07-23 13:57:05 --> Config Class Initialized
DEBUG - 2011-07-23 13:57:05 --> Hooks Class Initialized
DEBUG - 2011-07-23 13:57:05 --> Utf8 Class Initialized
DEBUG - 2011-07-23 13:57:05 --> UTF-8 Support Enabled
DEBUG - 2011-07-23 13:57:05 --> URI Class Initialized
DEBUG - 2011-07-23 13:57:05 --> Router Class Initialized
DEBUG - 2011-07-23 13:57:05 --> Output Class Initialized
DEBUG - 2011-07-23 13:57:05 --> Input Class Initialized
DEBUG - 2011-07-23 13:57:05 --> Global POST and COOKIE data sanitized
DEBUG - 2011-07-23 13:57:05 --> Language Class Initialized
DEBUG - 2011-07-23 13:57:05 --> Loader Class Initialized
DEBUG - 2011-07-23 13:57:05 --> Controller Class Initialized
ERROR - 2011-07-23 13:57:05 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-07-23 13:57:05 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-07-23 13:57:05 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-07-23 13:57:05 --> Model Class Initialized
DEBUG - 2011-07-23 13:57:05 --> Model Class Initialized
DEBUG - 2011-07-23 13:57:05 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-07-23 13:57:05 --> Database Driver Class Initialized
DEBUG - 2011-07-23 13:57:05 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-07-23 13:57:05 --> Helper loaded: url_helper
DEBUG - 2011-07-23 13:57:05 --> File loaded: application/views/common/header.php
DEBUG - 2011-07-23 13:57:05 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-07-23 13:57:05 --> File loaded: application/views/common/footer.php
DEBUG - 2011-07-23 13:57:05 --> File loaded: application/views/layout/main.php
DEBUG - 2011-07-23 13:57:05 --> Final output sent to browser
DEBUG - 2011-07-23 13:57:05 --> Total execution time: 0.3481
DEBUG - 2011-07-23 13:57:05 --> Config Class Initialized
DEBUG - 2011-07-23 13:57:05 --> Hooks Class Initialized
DEBUG - 2011-07-23 13:57:05 --> Utf8 Class Initialized
DEBUG - 2011-07-23 13:57:05 --> UTF-8 Support Enabled
DEBUG - 2011-07-23 13:57:05 --> URI Class Initialized
DEBUG - 2011-07-23 13:57:05 --> Router Class Initialized
DEBUG - 2011-07-23 13:57:05 --> Output Class Initialized
DEBUG - 2011-07-23 13:57:05 --> Input Class Initialized
DEBUG - 2011-07-23 13:57:05 --> Global POST and COOKIE data sanitized
DEBUG - 2011-07-23 13:57:05 --> Language Class Initialized
DEBUG - 2011-07-23 13:57:05 --> Loader Class Initialized
DEBUG - 2011-07-23 13:57:05 --> Controller Class Initialized
DEBUG - 2011-07-23 13:57:05 --> Model Class Initialized
DEBUG - 2011-07-23 13:57:05 --> Model Class Initialized
DEBUG - 2011-07-23 13:57:05 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-07-23 13:57:05 --> Database Driver Class Initialized
DEBUG - 2011-07-23 13:57:06 --> Final output sent to browser
DEBUG - 2011-07-23 13:57:06 --> Total execution time: 0.6962
DEBUG - 2011-07-23 14:10:19 --> Config Class Initialized
DEBUG - 2011-07-23 14:10:19 --> Hooks Class Initialized
DEBUG - 2011-07-23 14:10:19 --> Utf8 Class Initialized
DEBUG - 2011-07-23 14:10:19 --> UTF-8 Support Enabled
DEBUG - 2011-07-23 14:10:19 --> URI Class Initialized
DEBUG - 2011-07-23 14:10:19 --> Router Class Initialized
DEBUG - 2011-07-23 14:10:19 --> No URI present. Default controller set.
DEBUG - 2011-07-23 14:10:19 --> Output Class Initialized
DEBUG - 2011-07-23 14:10:19 --> Input Class Initialized
DEBUG - 2011-07-23 14:10:19 --> Global POST and COOKIE data sanitized
DEBUG - 2011-07-23 14:10:19 --> Language Class Initialized
DEBUG - 2011-07-23 14:10:19 --> Loader Class Initialized
DEBUG - 2011-07-23 14:10:19 --> Controller Class Initialized
DEBUG - 2011-07-23 14:10:19 --> File loaded: application/views/splash/main.php
DEBUG - 2011-07-23 14:10:19 --> Helper loaded: url_helper
DEBUG - 2011-07-23 14:10:19 --> File loaded: application/views/common/header.php
DEBUG - 2011-07-23 14:10:19 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-07-23 14:10:19 --> File loaded: application/views/common/footer.php
DEBUG - 2011-07-23 14:10:19 --> File loaded: application/views/layout/main.php
DEBUG - 2011-07-23 14:10:19 --> Final output sent to browser
DEBUG - 2011-07-23 14:10:19 --> Total execution time: 0.1019
DEBUG - 2011-07-23 14:10:21 --> Config Class Initialized
DEBUG - 2011-07-23 14:10:21 --> Hooks Class Initialized
DEBUG - 2011-07-23 14:10:21 --> Utf8 Class Initialized
DEBUG - 2011-07-23 14:10:21 --> UTF-8 Support Enabled
DEBUG - 2011-07-23 14:10:21 --> URI Class Initialized
DEBUG - 2011-07-23 14:10:21 --> Router Class Initialized
ERROR - 2011-07-23 14:10:21 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-07-23 14:10:24 --> Config Class Initialized
DEBUG - 2011-07-23 14:10:24 --> Hooks Class Initialized
DEBUG - 2011-07-23 14:10:24 --> Utf8 Class Initialized
DEBUG - 2011-07-23 14:10:24 --> UTF-8 Support Enabled
DEBUG - 2011-07-23 14:10:24 --> URI Class Initialized
DEBUG - 2011-07-23 14:10:24 --> Router Class Initialized
ERROR - 2011-07-23 14:10:24 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-07-23 14:10:24 --> Config Class Initialized
DEBUG - 2011-07-23 14:10:24 --> Hooks Class Initialized
DEBUG - 2011-07-23 14:10:24 --> Utf8 Class Initialized
DEBUG - 2011-07-23 14:10:24 --> UTF-8 Support Enabled
DEBUG - 2011-07-23 14:10:24 --> URI Class Initialized
DEBUG - 2011-07-23 14:10:24 --> Router Class Initialized
ERROR - 2011-07-23 14:10:24 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-07-23 14:17:23 --> Config Class Initialized
DEBUG - 2011-07-23 14:17:23 --> Hooks Class Initialized
DEBUG - 2011-07-23 14:17:23 --> Utf8 Class Initialized
DEBUG - 2011-07-23 14:17:23 --> UTF-8 Support Enabled
DEBUG - 2011-07-23 14:17:23 --> URI Class Initialized
DEBUG - 2011-07-23 14:17:23 --> Router Class Initialized
DEBUG - 2011-07-23 14:17:23 --> Output Class Initialized
DEBUG - 2011-07-23 14:17:23 --> Input Class Initialized
DEBUG - 2011-07-23 14:17:23 --> Global POST and COOKIE data sanitized
DEBUG - 2011-07-23 14:17:23 --> Language Class Initialized
DEBUG - 2011-07-23 14:17:23 --> Loader Class Initialized
DEBUG - 2011-07-23 14:17:23 --> Controller Class Initialized
ERROR - 2011-07-23 14:17:23 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-07-23 14:17:23 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-07-23 14:17:23 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-07-23 14:17:23 --> Model Class Initialized
DEBUG - 2011-07-23 14:17:23 --> Model Class Initialized
DEBUG - 2011-07-23 14:17:23 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-07-23 14:17:24 --> Database Driver Class Initialized
DEBUG - 2011-07-23 14:17:24 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-07-23 14:17:24 --> Helper loaded: url_helper
DEBUG - 2011-07-23 14:17:24 --> File loaded: application/views/common/header.php
DEBUG - 2011-07-23 14:17:24 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-07-23 14:17:24 --> File loaded: application/views/common/footer.php
DEBUG - 2011-07-23 14:17:24 --> File loaded: application/views/layout/main.php
DEBUG - 2011-07-23 14:17:24 --> Final output sent to browser
DEBUG - 2011-07-23 14:17:24 --> Total execution time: 0.0749
DEBUG - 2011-07-23 14:17:24 --> Config Class Initialized
DEBUG - 2011-07-23 14:17:24 --> Hooks Class Initialized
DEBUG - 2011-07-23 14:17:24 --> Utf8 Class Initialized
DEBUG - 2011-07-23 14:17:24 --> UTF-8 Support Enabled
DEBUG - 2011-07-23 14:17:24 --> URI Class Initialized
DEBUG - 2011-07-23 14:17:24 --> Router Class Initialized
DEBUG - 2011-07-23 14:17:24 --> Output Class Initialized
DEBUG - 2011-07-23 14:17:24 --> Input Class Initialized
DEBUG - 2011-07-23 14:17:24 --> Global POST and COOKIE data sanitized
DEBUG - 2011-07-23 14:17:24 --> Language Class Initialized
DEBUG - 2011-07-23 14:17:24 --> Loader Class Initialized
DEBUG - 2011-07-23 14:17:24 --> Controller Class Initialized
DEBUG - 2011-07-23 14:17:24 --> Model Class Initialized
DEBUG - 2011-07-23 14:17:24 --> Model Class Initialized
DEBUG - 2011-07-23 14:17:24 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-07-23 14:17:24 --> Database Driver Class Initialized
DEBUG - 2011-07-23 14:17:25 --> Final output sent to browser
DEBUG - 2011-07-23 14:17:25 --> Total execution time: 0.5282
DEBUG - 2011-07-23 14:17:27 --> Config Class Initialized
DEBUG - 2011-07-23 14:17:27 --> Hooks Class Initialized
DEBUG - 2011-07-23 14:17:27 --> Utf8 Class Initialized
DEBUG - 2011-07-23 14:17:27 --> UTF-8 Support Enabled
DEBUG - 2011-07-23 14:17:27 --> URI Class Initialized
DEBUG - 2011-07-23 14:17:27 --> Router Class Initialized
ERROR - 2011-07-23 14:17:27 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-07-23 14:17:53 --> Config Class Initialized
DEBUG - 2011-07-23 14:17:53 --> Hooks Class Initialized
DEBUG - 2011-07-23 14:17:53 --> Utf8 Class Initialized
DEBUG - 2011-07-23 14:17:53 --> UTF-8 Support Enabled
DEBUG - 2011-07-23 14:17:53 --> URI Class Initialized
DEBUG - 2011-07-23 14:17:53 --> Router Class Initialized
DEBUG - 2011-07-23 14:17:53 --> Output Class Initialized
DEBUG - 2011-07-23 14:17:53 --> Input Class Initialized
DEBUG - 2011-07-23 14:17:53 --> Global POST and COOKIE data sanitized
DEBUG - 2011-07-23 14:17:53 --> Language Class Initialized
DEBUG - 2011-07-23 14:17:53 --> Loader Class Initialized
DEBUG - 2011-07-23 14:17:53 --> Controller Class Initialized
ERROR - 2011-07-23 14:17:53 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-07-23 14:17:53 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-07-23 14:17:53 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-07-23 14:17:53 --> Model Class Initialized
DEBUG - 2011-07-23 14:17:53 --> Model Class Initialized
DEBUG - 2011-07-23 14:17:53 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-07-23 14:17:53 --> Database Driver Class Initialized
DEBUG - 2011-07-23 14:17:53 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-07-23 14:17:53 --> Helper loaded: url_helper
DEBUG - 2011-07-23 14:17:53 --> File loaded: application/views/common/header.php
DEBUG - 2011-07-23 14:17:53 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-07-23 14:17:53 --> File loaded: application/views/common/footer.php
DEBUG - 2011-07-23 14:17:53 --> File loaded: application/views/layout/main.php
DEBUG - 2011-07-23 14:17:53 --> Final output sent to browser
DEBUG - 2011-07-23 14:17:53 --> Total execution time: 0.0275
DEBUG - 2011-07-23 14:17:55 --> Config Class Initialized
DEBUG - 2011-07-23 14:17:55 --> Hooks Class Initialized
DEBUG - 2011-07-23 14:17:55 --> Utf8 Class Initialized
DEBUG - 2011-07-23 14:17:55 --> UTF-8 Support Enabled
DEBUG - 2011-07-23 14:17:55 --> URI Class Initialized
DEBUG - 2011-07-23 14:17:55 --> Router Class Initialized
DEBUG - 2011-07-23 14:17:55 --> Output Class Initialized
DEBUG - 2011-07-23 14:17:55 --> Input Class Initialized
DEBUG - 2011-07-23 14:17:55 --> Global POST and COOKIE data sanitized
DEBUG - 2011-07-23 14:17:55 --> Language Class Initialized
DEBUG - 2011-07-23 14:17:55 --> Loader Class Initialized
DEBUG - 2011-07-23 14:17:55 --> Controller Class Initialized
DEBUG - 2011-07-23 14:17:55 --> Model Class Initialized
DEBUG - 2011-07-23 14:17:55 --> Model Class Initialized
DEBUG - 2011-07-23 14:17:55 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-07-23 14:17:55 --> Database Driver Class Initialized
DEBUG - 2011-07-23 14:17:56 --> Final output sent to browser
DEBUG - 2011-07-23 14:17:56 --> Total execution time: 0.5825
DEBUG - 2011-07-23 14:17:58 --> Config Class Initialized
DEBUG - 2011-07-23 14:17:58 --> Hooks Class Initialized
DEBUG - 2011-07-23 14:17:58 --> Utf8 Class Initialized
DEBUG - 2011-07-23 14:17:58 --> UTF-8 Support Enabled
DEBUG - 2011-07-23 14:17:58 --> URI Class Initialized
DEBUG - 2011-07-23 14:17:58 --> Router Class Initialized
ERROR - 2011-07-23 14:17:58 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-07-23 14:18:04 --> Config Class Initialized
DEBUG - 2011-07-23 14:18:04 --> Hooks Class Initialized
DEBUG - 2011-07-23 14:18:04 --> Utf8 Class Initialized
DEBUG - 2011-07-23 14:18:04 --> UTF-8 Support Enabled
DEBUG - 2011-07-23 14:18:04 --> URI Class Initialized
DEBUG - 2011-07-23 14:18:04 --> Router Class Initialized
DEBUG - 2011-07-23 14:18:04 --> Output Class Initialized
DEBUG - 2011-07-23 14:18:04 --> Input Class Initialized
DEBUG - 2011-07-23 14:18:04 --> Global POST and COOKIE data sanitized
DEBUG - 2011-07-23 14:18:04 --> Language Class Initialized
DEBUG - 2011-07-23 14:18:04 --> Loader Class Initialized
DEBUG - 2011-07-23 14:18:04 --> Controller Class Initialized
ERROR - 2011-07-23 14:18:04 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-07-23 14:18:04 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-07-23 14:18:04 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-07-23 14:18:04 --> Model Class Initialized
DEBUG - 2011-07-23 14:18:04 --> Model Class Initialized
DEBUG - 2011-07-23 14:18:04 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-07-23 14:18:04 --> Database Driver Class Initialized
DEBUG - 2011-07-23 14:18:04 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-07-23 14:18:04 --> Helper loaded: url_helper
DEBUG - 2011-07-23 14:18:04 --> File loaded: application/views/common/header.php
DEBUG - 2011-07-23 14:18:04 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-07-23 14:18:04 --> File loaded: application/views/common/footer.php
DEBUG - 2011-07-23 14:18:04 --> File loaded: application/views/layout/main.php
DEBUG - 2011-07-23 14:18:04 --> Final output sent to browser
DEBUG - 2011-07-23 14:18:04 --> Total execution time: 0.0787
DEBUG - 2011-07-23 14:18:06 --> Config Class Initialized
DEBUG - 2011-07-23 14:18:06 --> Hooks Class Initialized
DEBUG - 2011-07-23 14:18:06 --> Utf8 Class Initialized
DEBUG - 2011-07-23 14:18:06 --> UTF-8 Support Enabled
DEBUG - 2011-07-23 14:18:06 --> URI Class Initialized
DEBUG - 2011-07-23 14:18:06 --> Router Class Initialized
DEBUG - 2011-07-23 14:18:06 --> Output Class Initialized
DEBUG - 2011-07-23 14:18:06 --> Input Class Initialized
DEBUG - 2011-07-23 14:18:06 --> Global POST and COOKIE data sanitized
DEBUG - 2011-07-23 14:18:06 --> Language Class Initialized
DEBUG - 2011-07-23 14:18:06 --> Loader Class Initialized
DEBUG - 2011-07-23 14:18:06 --> Controller Class Initialized
ERROR - 2011-07-23 14:18:06 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-07-23 14:18:06 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-07-23 14:18:06 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-07-23 14:18:06 --> Model Class Initialized
DEBUG - 2011-07-23 14:18:06 --> Model Class Initialized
DEBUG - 2011-07-23 14:18:06 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-07-23 14:18:06 --> Database Driver Class Initialized
DEBUG - 2011-07-23 14:18:06 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-07-23 14:18:06 --> Helper loaded: url_helper
DEBUG - 2011-07-23 14:18:06 --> File loaded: application/views/common/header.php
DEBUG - 2011-07-23 14:18:06 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-07-23 14:18:06 --> File loaded: application/views/common/footer.php
DEBUG - 2011-07-23 14:18:06 --> File loaded: application/views/layout/main.php
DEBUG - 2011-07-23 14:18:06 --> Final output sent to browser
DEBUG - 2011-07-23 14:18:06 --> Total execution time: 0.0748
DEBUG - 2011-07-23 14:18:07 --> Config Class Initialized
DEBUG - 2011-07-23 14:18:07 --> Hooks Class Initialized
DEBUG - 2011-07-23 14:18:07 --> Utf8 Class Initialized
DEBUG - 2011-07-23 14:18:07 --> UTF-8 Support Enabled
DEBUG - 2011-07-23 14:18:07 --> URI Class Initialized
DEBUG - 2011-07-23 14:18:07 --> Router Class Initialized
DEBUG - 2011-07-23 14:18:07 --> Output Class Initialized
DEBUG - 2011-07-23 14:18:07 --> Input Class Initialized
DEBUG - 2011-07-23 14:18:07 --> Global POST and COOKIE data sanitized
DEBUG - 2011-07-23 14:18:07 --> Language Class Initialized
DEBUG - 2011-07-23 14:18:07 --> Loader Class Initialized
DEBUG - 2011-07-23 14:18:07 --> Controller Class Initialized
DEBUG - 2011-07-23 14:18:07 --> Model Class Initialized
DEBUG - 2011-07-23 14:18:07 --> Model Class Initialized
DEBUG - 2011-07-23 14:18:07 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-07-23 14:18:07 --> Database Driver Class Initialized
DEBUG - 2011-07-23 14:18:07 --> Config Class Initialized
DEBUG - 2011-07-23 14:18:07 --> Hooks Class Initialized
DEBUG - 2011-07-23 14:18:07 --> Utf8 Class Initialized
DEBUG - 2011-07-23 14:18:07 --> UTF-8 Support Enabled
DEBUG - 2011-07-23 14:18:07 --> URI Class Initialized
DEBUG - 2011-07-23 14:18:07 --> Router Class Initialized
DEBUG - 2011-07-23 14:18:07 --> Output Class Initialized
DEBUG - 2011-07-23 14:18:07 --> Input Class Initialized
DEBUG - 2011-07-23 14:18:07 --> Global POST and COOKIE data sanitized
DEBUG - 2011-07-23 14:18:07 --> Language Class Initialized
DEBUG - 2011-07-23 14:18:07 --> Loader Class Initialized
DEBUG - 2011-07-23 14:18:07 --> Controller Class Initialized
ERROR - 2011-07-23 14:18:07 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-07-23 14:18:07 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-07-23 14:18:07 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-07-23 14:18:07 --> Model Class Initialized
DEBUG - 2011-07-23 14:18:07 --> Model Class Initialized
DEBUG - 2011-07-23 14:18:07 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-07-23 14:18:07 --> Database Driver Class Initialized
DEBUG - 2011-07-23 14:18:07 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-07-23 14:18:07 --> Helper loaded: url_helper
DEBUG - 2011-07-23 14:18:07 --> File loaded: application/views/common/header.php
DEBUG - 2011-07-23 14:18:07 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-07-23 14:18:07 --> File loaded: application/views/common/footer.php
DEBUG - 2011-07-23 14:18:07 --> File loaded: application/views/layout/main.php
DEBUG - 2011-07-23 14:18:07 --> Final output sent to browser
DEBUG - 2011-07-23 14:18:07 --> Total execution time: 0.0280
DEBUG - 2011-07-23 14:18:07 --> Final output sent to browser
DEBUG - 2011-07-23 14:18:07 --> Total execution time: 0.7927
DEBUG - 2011-07-23 14:18:09 --> Config Class Initialized
DEBUG - 2011-07-23 14:18:09 --> Hooks Class Initialized
DEBUG - 2011-07-23 14:18:09 --> Utf8 Class Initialized
DEBUG - 2011-07-23 14:18:09 --> UTF-8 Support Enabled
DEBUG - 2011-07-23 14:18:09 --> URI Class Initialized
DEBUG - 2011-07-23 14:18:09 --> Router Class Initialized
ERROR - 2011-07-23 14:18:09 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-07-23 14:18:16 --> Config Class Initialized
DEBUG - 2011-07-23 14:18:16 --> Hooks Class Initialized
DEBUG - 2011-07-23 14:18:16 --> Utf8 Class Initialized
DEBUG - 2011-07-23 14:18:16 --> UTF-8 Support Enabled
DEBUG - 2011-07-23 14:18:16 --> URI Class Initialized
DEBUG - 2011-07-23 14:18:16 --> Router Class Initialized
DEBUG - 2011-07-23 14:18:16 --> Output Class Initialized
DEBUG - 2011-07-23 14:18:16 --> Input Class Initialized
DEBUG - 2011-07-23 14:18:16 --> Global POST and COOKIE data sanitized
DEBUG - 2011-07-23 14:18:16 --> Language Class Initialized
DEBUG - 2011-07-23 14:18:16 --> Loader Class Initialized
DEBUG - 2011-07-23 14:18:16 --> Controller Class Initialized
ERROR - 2011-07-23 14:18:16 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-07-23 14:18:16 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-07-23 14:18:16 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-07-23 14:18:16 --> Model Class Initialized
DEBUG - 2011-07-23 14:18:16 --> Model Class Initialized
DEBUG - 2011-07-23 14:18:16 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-07-23 14:18:16 --> Database Driver Class Initialized
DEBUG - 2011-07-23 14:18:16 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-07-23 14:18:16 --> Helper loaded: url_helper
DEBUG - 2011-07-23 14:18:16 --> File loaded: application/views/common/header.php
DEBUG - 2011-07-23 14:18:16 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-07-23 14:18:16 --> File loaded: application/views/common/footer.php
DEBUG - 2011-07-23 14:18:16 --> File loaded: application/views/layout/main.php
DEBUG - 2011-07-23 14:18:16 --> Final output sent to browser
DEBUG - 2011-07-23 14:18:16 --> Total execution time: 0.0681
DEBUG - 2011-07-23 14:18:16 --> Config Class Initialized
DEBUG - 2011-07-23 14:18:16 --> Hooks Class Initialized
DEBUG - 2011-07-23 14:18:16 --> Utf8 Class Initialized
DEBUG - 2011-07-23 14:18:16 --> UTF-8 Support Enabled
DEBUG - 2011-07-23 14:18:16 --> URI Class Initialized
DEBUG - 2011-07-23 14:18:16 --> Router Class Initialized
DEBUG - 2011-07-23 14:18:16 --> Output Class Initialized
DEBUG - 2011-07-23 14:18:16 --> Input Class Initialized
DEBUG - 2011-07-23 14:18:16 --> Global POST and COOKIE data sanitized
DEBUG - 2011-07-23 14:18:16 --> Language Class Initialized
DEBUG - 2011-07-23 14:18:16 --> Loader Class Initialized
DEBUG - 2011-07-23 14:18:16 --> Controller Class Initialized
DEBUG - 2011-07-23 14:18:16 --> Model Class Initialized
DEBUG - 2011-07-23 14:18:16 --> Model Class Initialized
DEBUG - 2011-07-23 14:18:16 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-07-23 14:18:16 --> Database Driver Class Initialized
DEBUG - 2011-07-23 14:18:17 --> Final output sent to browser
DEBUG - 2011-07-23 14:18:17 --> Total execution time: 0.5935
DEBUG - 2011-07-23 14:18:19 --> Config Class Initialized
DEBUG - 2011-07-23 14:18:19 --> Hooks Class Initialized
DEBUG - 2011-07-23 14:18:19 --> Utf8 Class Initialized
DEBUG - 2011-07-23 14:18:19 --> UTF-8 Support Enabled
DEBUG - 2011-07-23 14:18:19 --> URI Class Initialized
DEBUG - 2011-07-23 14:18:19 --> Router Class Initialized
ERROR - 2011-07-23 14:18:19 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-07-23 14:25:00 --> Config Class Initialized
DEBUG - 2011-07-23 14:25:00 --> Hooks Class Initialized
DEBUG - 2011-07-23 14:25:00 --> Utf8 Class Initialized
DEBUG - 2011-07-23 14:25:00 --> UTF-8 Support Enabled
DEBUG - 2011-07-23 14:25:00 --> URI Class Initialized
DEBUG - 2011-07-23 14:25:00 --> Router Class Initialized
DEBUG - 2011-07-23 14:25:00 --> Output Class Initialized
DEBUG - 2011-07-23 14:25:00 --> Input Class Initialized
DEBUG - 2011-07-23 14:25:00 --> Global POST and COOKIE data sanitized
DEBUG - 2011-07-23 14:25:00 --> Language Class Initialized
DEBUG - 2011-07-23 14:25:00 --> Loader Class Initialized
DEBUG - 2011-07-23 14:25:00 --> Controller Class Initialized
DEBUG - 2011-07-23 14:25:00 --> Model Class Initialized
DEBUG - 2011-07-23 14:25:00 --> Model Class Initialized
DEBUG - 2011-07-23 14:25:00 --> Model Class Initialized
DEBUG - 2011-07-23 14:25:00 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-07-23 14:25:00 --> Database Driver Class Initialized
DEBUG - 2011-07-23 14:25:00 --> File loaded: application/views/table/main.php
DEBUG - 2011-07-23 14:25:00 --> Helper loaded: url_helper
DEBUG - 2011-07-23 14:25:00 --> File loaded: application/views/common/header.php
DEBUG - 2011-07-23 14:25:00 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-07-23 14:25:00 --> File loaded: application/views/common/footer.php
DEBUG - 2011-07-23 14:25:00 --> File loaded: application/views/layout/main.php
DEBUG - 2011-07-23 14:25:00 --> Final output sent to browser
DEBUG - 2011-07-23 14:25:00 --> Total execution time: 0.5161
DEBUG - 2011-07-23 14:26:31 --> Config Class Initialized
DEBUG - 2011-07-23 14:26:31 --> Hooks Class Initialized
DEBUG - 2011-07-23 14:26:31 --> Utf8 Class Initialized
DEBUG - 2011-07-23 14:26:31 --> UTF-8 Support Enabled
DEBUG - 2011-07-23 14:26:31 --> URI Class Initialized
DEBUG - 2011-07-23 14:26:31 --> Router Class Initialized
DEBUG - 2011-07-23 14:26:31 --> Output Class Initialized
DEBUG - 2011-07-23 14:26:31 --> Input Class Initialized
DEBUG - 2011-07-23 14:26:31 --> Global POST and COOKIE data sanitized
DEBUG - 2011-07-23 14:26:31 --> Language Class Initialized
DEBUG - 2011-07-23 14:26:31 --> Loader Class Initialized
DEBUG - 2011-07-23 14:26:31 --> Controller Class Initialized
ERROR - 2011-07-23 14:26:31 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-07-23 14:26:31 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-07-23 14:26:31 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-07-23 14:26:31 --> Model Class Initialized
DEBUG - 2011-07-23 14:26:31 --> Model Class Initialized
DEBUG - 2011-07-23 14:26:31 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-07-23 14:26:31 --> Database Driver Class Initialized
DEBUG - 2011-07-23 14:26:31 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-07-23 14:26:31 --> Helper loaded: url_helper
DEBUG - 2011-07-23 14:26:31 --> File loaded: application/views/common/header.php
DEBUG - 2011-07-23 14:26:31 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-07-23 14:26:31 --> File loaded: application/views/common/footer.php
DEBUG - 2011-07-23 14:26:31 --> File loaded: application/views/layout/main.php
DEBUG - 2011-07-23 14:26:31 --> Final output sent to browser
DEBUG - 2011-07-23 14:26:31 --> Total execution time: 0.0557
DEBUG - 2011-07-23 14:26:32 --> Config Class Initialized
DEBUG - 2011-07-23 14:26:32 --> Hooks Class Initialized
DEBUG - 2011-07-23 14:26:32 --> Utf8 Class Initialized
DEBUG - 2011-07-23 14:26:32 --> UTF-8 Support Enabled
DEBUG - 2011-07-23 14:26:32 --> URI Class Initialized
DEBUG - 2011-07-23 14:26:32 --> Router Class Initialized
DEBUG - 2011-07-23 14:26:32 --> Output Class Initialized
DEBUG - 2011-07-23 14:26:32 --> Input Class Initialized
DEBUG - 2011-07-23 14:26:32 --> Global POST and COOKIE data sanitized
DEBUG - 2011-07-23 14:26:32 --> Language Class Initialized
DEBUG - 2011-07-23 14:26:32 --> Loader Class Initialized
DEBUG - 2011-07-23 14:26:32 --> Controller Class Initialized
DEBUG - 2011-07-23 14:26:32 --> Model Class Initialized
DEBUG - 2011-07-23 14:26:32 --> Model Class Initialized
DEBUG - 2011-07-23 14:26:32 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-07-23 14:26:32 --> Database Driver Class Initialized
DEBUG - 2011-07-23 14:26:33 --> Final output sent to browser
DEBUG - 2011-07-23 14:26:33 --> Total execution time: 0.5656
DEBUG - 2011-07-23 14:26:34 --> Config Class Initialized
DEBUG - 2011-07-23 14:26:34 --> Hooks Class Initialized
DEBUG - 2011-07-23 14:26:34 --> Utf8 Class Initialized
DEBUG - 2011-07-23 14:26:34 --> UTF-8 Support Enabled
DEBUG - 2011-07-23 14:26:34 --> URI Class Initialized
DEBUG - 2011-07-23 14:26:34 --> Router Class Initialized
ERROR - 2011-07-23 14:26:34 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-07-23 14:27:24 --> Config Class Initialized
DEBUG - 2011-07-23 14:27:24 --> Hooks Class Initialized
DEBUG - 2011-07-23 14:27:24 --> Utf8 Class Initialized
DEBUG - 2011-07-23 14:27:24 --> UTF-8 Support Enabled
DEBUG - 2011-07-23 14:27:24 --> URI Class Initialized
DEBUG - 2011-07-23 14:27:24 --> Router Class Initialized
DEBUG - 2011-07-23 14:27:24 --> Output Class Initialized
DEBUG - 2011-07-23 14:27:24 --> Input Class Initialized
DEBUG - 2011-07-23 14:27:24 --> Global POST and COOKIE data sanitized
DEBUG - 2011-07-23 14:27:24 --> Language Class Initialized
DEBUG - 2011-07-23 14:27:24 --> Loader Class Initialized
DEBUG - 2011-07-23 14:27:24 --> Controller Class Initialized
ERROR - 2011-07-23 14:27:24 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-07-23 14:27:24 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-07-23 14:27:24 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-07-23 14:27:24 --> Model Class Initialized
DEBUG - 2011-07-23 14:27:24 --> Model Class Initialized
DEBUG - 2011-07-23 14:27:24 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-07-23 14:27:24 --> Database Driver Class Initialized
DEBUG - 2011-07-23 14:27:24 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-07-23 14:27:24 --> Helper loaded: url_helper
DEBUG - 2011-07-23 14:27:24 --> File loaded: application/views/common/header.php
DEBUG - 2011-07-23 14:27:24 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-07-23 14:27:24 --> File loaded: application/views/common/footer.php
DEBUG - 2011-07-23 14:27:24 --> File loaded: application/views/layout/main.php
DEBUG - 2011-07-23 14:27:24 --> Final output sent to browser
DEBUG - 2011-07-23 14:27:24 --> Total execution time: 0.0431
DEBUG - 2011-07-23 14:27:24 --> Config Class Initialized
DEBUG - 2011-07-23 14:27:24 --> Hooks Class Initialized
DEBUG - 2011-07-23 14:27:24 --> Utf8 Class Initialized
DEBUG - 2011-07-23 14:27:24 --> UTF-8 Support Enabled
DEBUG - 2011-07-23 14:27:24 --> URI Class Initialized
DEBUG - 2011-07-23 14:27:24 --> Router Class Initialized
DEBUG - 2011-07-23 14:27:24 --> Output Class Initialized
DEBUG - 2011-07-23 14:27:24 --> Input Class Initialized
DEBUG - 2011-07-23 14:27:24 --> Global POST and COOKIE data sanitized
DEBUG - 2011-07-23 14:27:24 --> Language Class Initialized
DEBUG - 2011-07-23 14:27:24 --> Loader Class Initialized
DEBUG - 2011-07-23 14:27:24 --> Controller Class Initialized
DEBUG - 2011-07-23 14:27:24 --> Model Class Initialized
DEBUG - 2011-07-23 14:27:24 --> Model Class Initialized
DEBUG - 2011-07-23 14:27:24 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-07-23 14:27:24 --> Database Driver Class Initialized
DEBUG - 2011-07-23 14:27:25 --> Final output sent to browser
DEBUG - 2011-07-23 14:27:25 --> Total execution time: 0.7722
DEBUG - 2011-07-23 14:27:26 --> Config Class Initialized
DEBUG - 2011-07-23 14:27:26 --> Hooks Class Initialized
DEBUG - 2011-07-23 14:27:26 --> Utf8 Class Initialized
DEBUG - 2011-07-23 14:27:26 --> UTF-8 Support Enabled
DEBUG - 2011-07-23 14:27:26 --> URI Class Initialized
DEBUG - 2011-07-23 14:27:26 --> Router Class Initialized
ERROR - 2011-07-23 14:27:26 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-07-23 14:27:34 --> Config Class Initialized
DEBUG - 2011-07-23 14:27:34 --> Hooks Class Initialized
DEBUG - 2011-07-23 14:27:34 --> Utf8 Class Initialized
DEBUG - 2011-07-23 14:27:34 --> UTF-8 Support Enabled
DEBUG - 2011-07-23 14:27:34 --> URI Class Initialized
DEBUG - 2011-07-23 14:27:34 --> Router Class Initialized
DEBUG - 2011-07-23 14:27:34 --> Output Class Initialized
DEBUG - 2011-07-23 14:27:34 --> Input Class Initialized
DEBUG - 2011-07-23 14:27:34 --> Global POST and COOKIE data sanitized
DEBUG - 2011-07-23 14:27:34 --> Language Class Initialized
DEBUG - 2011-07-23 14:27:34 --> Loader Class Initialized
DEBUG - 2011-07-23 14:27:34 --> Controller Class Initialized
ERROR - 2011-07-23 14:27:34 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-07-23 14:27:34 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-07-23 14:27:34 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-07-23 14:27:34 --> Model Class Initialized
DEBUG - 2011-07-23 14:27:34 --> Model Class Initialized
DEBUG - 2011-07-23 14:27:34 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-07-23 14:27:34 --> Database Driver Class Initialized
DEBUG - 2011-07-23 14:27:34 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-07-23 14:27:34 --> Helper loaded: url_helper
DEBUG - 2011-07-23 14:27:34 --> File loaded: application/views/common/header.php
DEBUG - 2011-07-23 14:27:34 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-07-23 14:27:34 --> File loaded: application/views/common/footer.php
DEBUG - 2011-07-23 14:27:34 --> File loaded: application/views/layout/main.php
DEBUG - 2011-07-23 14:27:34 --> Final output sent to browser
DEBUG - 2011-07-23 14:27:34 --> Total execution time: 0.0300
DEBUG - 2011-07-23 14:27:34 --> Config Class Initialized
DEBUG - 2011-07-23 14:27:34 --> Hooks Class Initialized
DEBUG - 2011-07-23 14:27:34 --> Utf8 Class Initialized
DEBUG - 2011-07-23 14:27:34 --> UTF-8 Support Enabled
DEBUG - 2011-07-23 14:27:34 --> URI Class Initialized
DEBUG - 2011-07-23 14:27:34 --> Router Class Initialized
DEBUG - 2011-07-23 14:27:34 --> Output Class Initialized
DEBUG - 2011-07-23 14:27:34 --> Input Class Initialized
DEBUG - 2011-07-23 14:27:34 --> Global POST and COOKIE data sanitized
DEBUG - 2011-07-23 14:27:34 --> Language Class Initialized
DEBUG - 2011-07-23 14:27:34 --> Loader Class Initialized
DEBUG - 2011-07-23 14:27:34 --> Controller Class Initialized
DEBUG - 2011-07-23 14:27:34 --> Model Class Initialized
DEBUG - 2011-07-23 14:27:34 --> Model Class Initialized
DEBUG - 2011-07-23 14:27:34 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-07-23 14:27:34 --> Database Driver Class Initialized
DEBUG - 2011-07-23 14:27:35 --> Final output sent to browser
DEBUG - 2011-07-23 14:27:35 --> Total execution time: 0.4696
DEBUG - 2011-07-23 14:27:36 --> Config Class Initialized
DEBUG - 2011-07-23 14:27:36 --> Hooks Class Initialized
DEBUG - 2011-07-23 14:27:36 --> Utf8 Class Initialized
DEBUG - 2011-07-23 14:27:36 --> UTF-8 Support Enabled
DEBUG - 2011-07-23 14:27:36 --> URI Class Initialized
DEBUG - 2011-07-23 14:27:36 --> Router Class Initialized
ERROR - 2011-07-23 14:27:36 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-07-23 14:27:57 --> Config Class Initialized
DEBUG - 2011-07-23 14:27:57 --> Hooks Class Initialized
DEBUG - 2011-07-23 14:27:57 --> Utf8 Class Initialized
DEBUG - 2011-07-23 14:27:57 --> UTF-8 Support Enabled
DEBUG - 2011-07-23 14:27:57 --> URI Class Initialized
DEBUG - 2011-07-23 14:27:57 --> Router Class Initialized
DEBUG - 2011-07-23 14:27:57 --> Output Class Initialized
DEBUG - 2011-07-23 14:27:57 --> Input Class Initialized
DEBUG - 2011-07-23 14:27:57 --> Global POST and COOKIE data sanitized
DEBUG - 2011-07-23 14:27:57 --> Language Class Initialized
DEBUG - 2011-07-23 14:27:57 --> Loader Class Initialized
DEBUG - 2011-07-23 14:27:57 --> Controller Class Initialized
ERROR - 2011-07-23 14:27:57 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-07-23 14:27:57 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-07-23 14:27:57 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-07-23 14:27:57 --> Model Class Initialized
DEBUG - 2011-07-23 14:27:57 --> Model Class Initialized
DEBUG - 2011-07-23 14:27:57 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-07-23 14:27:57 --> Database Driver Class Initialized
DEBUG - 2011-07-23 14:27:57 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-07-23 14:27:57 --> Helper loaded: url_helper
DEBUG - 2011-07-23 14:27:57 --> File loaded: application/views/common/header.php
DEBUG - 2011-07-23 14:27:57 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-07-23 14:27:57 --> File loaded: application/views/common/footer.php
DEBUG - 2011-07-23 14:27:57 --> File loaded: application/views/layout/main.php
DEBUG - 2011-07-23 14:27:57 --> Final output sent to browser
DEBUG - 2011-07-23 14:27:57 --> Total execution time: 0.0310
DEBUG - 2011-07-23 14:27:58 --> Config Class Initialized
DEBUG - 2011-07-23 14:27:58 --> Hooks Class Initialized
DEBUG - 2011-07-23 14:27:58 --> Utf8 Class Initialized
DEBUG - 2011-07-23 14:27:58 --> UTF-8 Support Enabled
DEBUG - 2011-07-23 14:27:58 --> URI Class Initialized
DEBUG - 2011-07-23 14:27:58 --> Router Class Initialized
DEBUG - 2011-07-23 14:27:58 --> Output Class Initialized
DEBUG - 2011-07-23 14:27:58 --> Input Class Initialized
DEBUG - 2011-07-23 14:27:58 --> Global POST and COOKIE data sanitized
DEBUG - 2011-07-23 14:27:58 --> Language Class Initialized
DEBUG - 2011-07-23 14:27:58 --> Loader Class Initialized
DEBUG - 2011-07-23 14:27:58 --> Controller Class Initialized
DEBUG - 2011-07-23 14:27:58 --> Model Class Initialized
DEBUG - 2011-07-23 14:27:58 --> Model Class Initialized
DEBUG - 2011-07-23 14:27:58 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-07-23 14:27:58 --> Database Driver Class Initialized
DEBUG - 2011-07-23 14:27:59 --> Final output sent to browser
DEBUG - 2011-07-23 14:27:59 --> Total execution time: 0.6184
DEBUG - 2011-07-23 14:28:00 --> Config Class Initialized
DEBUG - 2011-07-23 14:28:00 --> Hooks Class Initialized
DEBUG - 2011-07-23 14:28:00 --> Utf8 Class Initialized
DEBUG - 2011-07-23 14:28:00 --> UTF-8 Support Enabled
DEBUG - 2011-07-23 14:28:00 --> URI Class Initialized
DEBUG - 2011-07-23 14:28:00 --> Router Class Initialized
ERROR - 2011-07-23 14:28:00 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-07-23 14:28:07 --> Config Class Initialized
DEBUG - 2011-07-23 14:28:07 --> Hooks Class Initialized
DEBUG - 2011-07-23 14:28:07 --> Utf8 Class Initialized
DEBUG - 2011-07-23 14:28:07 --> UTF-8 Support Enabled
DEBUG - 2011-07-23 14:28:07 --> URI Class Initialized
DEBUG - 2011-07-23 14:28:07 --> Router Class Initialized
DEBUG - 2011-07-23 14:28:07 --> Output Class Initialized
DEBUG - 2011-07-23 14:28:07 --> Input Class Initialized
DEBUG - 2011-07-23 14:28:07 --> Global POST and COOKIE data sanitized
DEBUG - 2011-07-23 14:28:07 --> Language Class Initialized
DEBUG - 2011-07-23 14:28:07 --> Loader Class Initialized
DEBUG - 2011-07-23 14:28:07 --> Controller Class Initialized
ERROR - 2011-07-23 14:28:07 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-07-23 14:28:07 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-07-23 14:28:07 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-07-23 14:28:07 --> Model Class Initialized
DEBUG - 2011-07-23 14:28:07 --> Model Class Initialized
DEBUG - 2011-07-23 14:28:07 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-07-23 14:28:07 --> Database Driver Class Initialized
DEBUG - 2011-07-23 14:28:07 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-07-23 14:28:07 --> Helper loaded: url_helper
DEBUG - 2011-07-23 14:28:07 --> File loaded: application/views/common/header.php
DEBUG - 2011-07-23 14:28:07 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-07-23 14:28:07 --> File loaded: application/views/common/footer.php
DEBUG - 2011-07-23 14:28:07 --> File loaded: application/views/layout/main.php
DEBUG - 2011-07-23 14:28:07 --> Final output sent to browser
DEBUG - 2011-07-23 14:28:07 --> Total execution time: 0.0295
DEBUG - 2011-07-23 14:28:08 --> Config Class Initialized
DEBUG - 2011-07-23 14:28:08 --> Hooks Class Initialized
DEBUG - 2011-07-23 14:28:08 --> Utf8 Class Initialized
DEBUG - 2011-07-23 14:28:08 --> UTF-8 Support Enabled
DEBUG - 2011-07-23 14:28:08 --> URI Class Initialized
DEBUG - 2011-07-23 14:28:08 --> Router Class Initialized
DEBUG - 2011-07-23 14:28:08 --> Output Class Initialized
DEBUG - 2011-07-23 14:28:08 --> Input Class Initialized
DEBUG - 2011-07-23 14:28:08 --> Global POST and COOKIE data sanitized
DEBUG - 2011-07-23 14:28:08 --> Language Class Initialized
DEBUG - 2011-07-23 14:28:08 --> Loader Class Initialized
DEBUG - 2011-07-23 14:28:08 --> Controller Class Initialized
ERROR - 2011-07-23 14:28:08 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-07-23 14:28:08 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-07-23 14:28:08 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-07-23 14:28:08 --> Model Class Initialized
DEBUG - 2011-07-23 14:28:08 --> Model Class Initialized
DEBUG - 2011-07-23 14:28:08 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-07-23 14:28:08 --> Database Driver Class Initialized
DEBUG - 2011-07-23 14:28:08 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-07-23 14:28:08 --> Helper loaded: url_helper
DEBUG - 2011-07-23 14:28:08 --> File loaded: application/views/common/header.php
DEBUG - 2011-07-23 14:28:08 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-07-23 14:28:08 --> File loaded: application/views/common/footer.php
DEBUG - 2011-07-23 14:28:08 --> File loaded: application/views/layout/main.php
DEBUG - 2011-07-23 14:28:08 --> Final output sent to browser
DEBUG - 2011-07-23 14:28:08 --> Total execution time: 0.0333
DEBUG - 2011-07-23 14:28:08 --> Config Class Initialized
DEBUG - 2011-07-23 14:28:08 --> Hooks Class Initialized
DEBUG - 2011-07-23 14:28:08 --> Utf8 Class Initialized
DEBUG - 2011-07-23 14:28:08 --> UTF-8 Support Enabled
DEBUG - 2011-07-23 14:28:08 --> URI Class Initialized
DEBUG - 2011-07-23 14:28:08 --> Router Class Initialized
DEBUG - 2011-07-23 14:28:08 --> Output Class Initialized
DEBUG - 2011-07-23 14:28:08 --> Input Class Initialized
DEBUG - 2011-07-23 14:28:08 --> Global POST and COOKIE data sanitized
DEBUG - 2011-07-23 14:28:08 --> Language Class Initialized
DEBUG - 2011-07-23 14:28:08 --> Loader Class Initialized
DEBUG - 2011-07-23 14:28:08 --> Controller Class Initialized
DEBUG - 2011-07-23 14:28:08 --> Model Class Initialized
DEBUG - 2011-07-23 14:28:08 --> Model Class Initialized
DEBUG - 2011-07-23 14:28:08 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-07-23 14:28:08 --> Database Driver Class Initialized
DEBUG - 2011-07-23 14:28:09 --> Final output sent to browser
DEBUG - 2011-07-23 14:28:09 --> Total execution time: 0.5459
DEBUG - 2011-07-23 14:28:09 --> Config Class Initialized
DEBUG - 2011-07-23 14:28:09 --> Hooks Class Initialized
DEBUG - 2011-07-23 14:28:09 --> Utf8 Class Initialized
DEBUG - 2011-07-23 14:28:09 --> UTF-8 Support Enabled
DEBUG - 2011-07-23 14:28:09 --> URI Class Initialized
DEBUG - 2011-07-23 14:28:09 --> Router Class Initialized
DEBUG - 2011-07-23 14:28:09 --> Output Class Initialized
DEBUG - 2011-07-23 14:28:09 --> Input Class Initialized
DEBUG - 2011-07-23 14:28:09 --> Global POST and COOKIE data sanitized
DEBUG - 2011-07-23 14:28:09 --> Language Class Initialized
DEBUG - 2011-07-23 14:28:09 --> Loader Class Initialized
DEBUG - 2011-07-23 14:28:09 --> Controller Class Initialized
ERROR - 2011-07-23 14:28:09 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-07-23 14:28:09 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-07-23 14:28:09 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-07-23 14:28:09 --> Model Class Initialized
DEBUG - 2011-07-23 14:28:09 --> Model Class Initialized
DEBUG - 2011-07-23 14:28:09 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-07-23 14:28:09 --> Database Driver Class Initialized
DEBUG - 2011-07-23 14:28:09 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-07-23 14:28:09 --> Helper loaded: url_helper
DEBUG - 2011-07-23 14:28:09 --> File loaded: application/views/common/header.php
DEBUG - 2011-07-23 14:28:09 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-07-23 14:28:09 --> File loaded: application/views/common/footer.php
DEBUG - 2011-07-23 14:28:09 --> File loaded: application/views/layout/main.php
DEBUG - 2011-07-23 14:28:09 --> Final output sent to browser
DEBUG - 2011-07-23 14:28:09 --> Total execution time: 0.0280
DEBUG - 2011-07-23 14:28:10 --> Config Class Initialized
DEBUG - 2011-07-23 14:28:10 --> Hooks Class Initialized
DEBUG - 2011-07-23 14:28:10 --> Utf8 Class Initialized
DEBUG - 2011-07-23 14:28:10 --> UTF-8 Support Enabled
DEBUG - 2011-07-23 14:28:10 --> URI Class Initialized
DEBUG - 2011-07-23 14:28:10 --> Router Class Initialized
ERROR - 2011-07-23 14:28:10 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-07-23 14:28:21 --> Config Class Initialized
DEBUG - 2011-07-23 14:28:21 --> Hooks Class Initialized
DEBUG - 2011-07-23 14:28:21 --> Utf8 Class Initialized
DEBUG - 2011-07-23 14:28:21 --> UTF-8 Support Enabled
DEBUG - 2011-07-23 14:28:21 --> URI Class Initialized
DEBUG - 2011-07-23 14:28:21 --> Router Class Initialized
DEBUG - 2011-07-23 14:28:21 --> Output Class Initialized
DEBUG - 2011-07-23 14:28:21 --> Input Class Initialized
DEBUG - 2011-07-23 14:28:21 --> Global POST and COOKIE data sanitized
DEBUG - 2011-07-23 14:28:21 --> Language Class Initialized
DEBUG - 2011-07-23 14:28:21 --> Loader Class Initialized
DEBUG - 2011-07-23 14:28:21 --> Controller Class Initialized
ERROR - 2011-07-23 14:28:21 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-07-23 14:28:21 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-07-23 14:28:21 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-07-23 14:28:21 --> Model Class Initialized
DEBUG - 2011-07-23 14:28:21 --> Model Class Initialized
DEBUG - 2011-07-23 14:28:21 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-07-23 14:28:21 --> Database Driver Class Initialized
DEBUG - 2011-07-23 14:28:21 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-07-23 14:28:21 --> Helper loaded: url_helper
DEBUG - 2011-07-23 14:28:21 --> File loaded: application/views/common/header.php
DEBUG - 2011-07-23 14:28:21 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-07-23 14:28:21 --> File loaded: application/views/common/footer.php
DEBUG - 2011-07-23 14:28:21 --> File loaded: application/views/layout/main.php
DEBUG - 2011-07-23 14:28:21 --> Final output sent to browser
DEBUG - 2011-07-23 14:28:21 --> Total execution time: 0.0266
DEBUG - 2011-07-23 14:28:22 --> Config Class Initialized
DEBUG - 2011-07-23 14:28:22 --> Hooks Class Initialized
DEBUG - 2011-07-23 14:28:22 --> Utf8 Class Initialized
DEBUG - 2011-07-23 14:28:22 --> UTF-8 Support Enabled
DEBUG - 2011-07-23 14:28:22 --> URI Class Initialized
DEBUG - 2011-07-23 14:28:22 --> Router Class Initialized
DEBUG - 2011-07-23 14:28:22 --> Output Class Initialized
DEBUG - 2011-07-23 14:28:22 --> Input Class Initialized
DEBUG - 2011-07-23 14:28:22 --> Global POST and COOKIE data sanitized
DEBUG - 2011-07-23 14:28:22 --> Language Class Initialized
DEBUG - 2011-07-23 14:28:22 --> Loader Class Initialized
DEBUG - 2011-07-23 14:28:22 --> Controller Class Initialized
DEBUG - 2011-07-23 14:28:22 --> Model Class Initialized
DEBUG - 2011-07-23 14:28:22 --> Model Class Initialized
DEBUG - 2011-07-23 14:28:22 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-07-23 14:28:22 --> Database Driver Class Initialized
DEBUG - 2011-07-23 14:28:22 --> Final output sent to browser
DEBUG - 2011-07-23 14:28:22 --> Total execution time: 0.5587
DEBUG - 2011-07-23 14:28:24 --> Config Class Initialized
DEBUG - 2011-07-23 14:28:24 --> Hooks Class Initialized
DEBUG - 2011-07-23 14:28:24 --> Utf8 Class Initialized
DEBUG - 2011-07-23 14:28:24 --> UTF-8 Support Enabled
DEBUG - 2011-07-23 14:28:24 --> URI Class Initialized
DEBUG - 2011-07-23 14:28:24 --> Router Class Initialized
ERROR - 2011-07-23 14:28:24 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-07-23 14:28:36 --> Config Class Initialized
DEBUG - 2011-07-23 14:28:36 --> Hooks Class Initialized
DEBUG - 2011-07-23 14:28:36 --> Utf8 Class Initialized
DEBUG - 2011-07-23 14:28:36 --> UTF-8 Support Enabled
DEBUG - 2011-07-23 14:28:36 --> URI Class Initialized
DEBUG - 2011-07-23 14:28:36 --> Router Class Initialized
DEBUG - 2011-07-23 14:28:36 --> Output Class Initialized
DEBUG - 2011-07-23 14:28:36 --> Input Class Initialized
DEBUG - 2011-07-23 14:28:36 --> Global POST and COOKIE data sanitized
DEBUG - 2011-07-23 14:28:36 --> Language Class Initialized
DEBUG - 2011-07-23 14:28:36 --> Loader Class Initialized
DEBUG - 2011-07-23 14:28:36 --> Controller Class Initialized
ERROR - 2011-07-23 14:28:36 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-07-23 14:28:36 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-07-23 14:28:36 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-07-23 14:28:36 --> Model Class Initialized
DEBUG - 2011-07-23 14:28:36 --> Model Class Initialized
DEBUG - 2011-07-23 14:28:36 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-07-23 14:28:36 --> Database Driver Class Initialized
DEBUG - 2011-07-23 14:28:36 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-07-23 14:28:36 --> Helper loaded: url_helper
DEBUG - 2011-07-23 14:28:36 --> File loaded: application/views/common/header.php
DEBUG - 2011-07-23 14:28:36 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-07-23 14:28:36 --> File loaded: application/views/common/footer.php
DEBUG - 2011-07-23 14:28:36 --> File loaded: application/views/layout/main.php
DEBUG - 2011-07-23 14:28:36 --> Final output sent to browser
DEBUG - 2011-07-23 14:28:36 --> Total execution time: 0.0393
DEBUG - 2011-07-23 14:28:37 --> Config Class Initialized
DEBUG - 2011-07-23 14:28:37 --> Hooks Class Initialized
DEBUG - 2011-07-23 14:28:37 --> Utf8 Class Initialized
DEBUG - 2011-07-23 14:28:37 --> UTF-8 Support Enabled
DEBUG - 2011-07-23 14:28:37 --> URI Class Initialized
DEBUG - 2011-07-23 14:28:37 --> Router Class Initialized
DEBUG - 2011-07-23 14:28:37 --> Output Class Initialized
DEBUG - 2011-07-23 14:28:37 --> Input Class Initialized
DEBUG - 2011-07-23 14:28:37 --> Global POST and COOKIE data sanitized
DEBUG - 2011-07-23 14:28:37 --> Language Class Initialized
DEBUG - 2011-07-23 14:28:37 --> Loader Class Initialized
DEBUG - 2011-07-23 14:28:37 --> Controller Class Initialized
DEBUG - 2011-07-23 14:28:37 --> Model Class Initialized
DEBUG - 2011-07-23 14:28:37 --> Model Class Initialized
DEBUG - 2011-07-23 14:28:37 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-07-23 14:28:37 --> Database Driver Class Initialized
DEBUG - 2011-07-23 14:28:37 --> Config Class Initialized
DEBUG - 2011-07-23 14:28:37 --> Hooks Class Initialized
DEBUG - 2011-07-23 14:28:37 --> Utf8 Class Initialized
DEBUG - 2011-07-23 14:28:37 --> UTF-8 Support Enabled
DEBUG - 2011-07-23 14:28:37 --> URI Class Initialized
DEBUG - 2011-07-23 14:28:37 --> Router Class Initialized
DEBUG - 2011-07-23 14:28:37 --> Output Class Initialized
DEBUG - 2011-07-23 14:28:37 --> Input Class Initialized
DEBUG - 2011-07-23 14:28:37 --> Global POST and COOKIE data sanitized
DEBUG - 2011-07-23 14:28:37 --> Language Class Initialized
DEBUG - 2011-07-23 14:28:37 --> Loader Class Initialized
DEBUG - 2011-07-23 14:28:37 --> Controller Class Initialized
ERROR - 2011-07-23 14:28:37 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-07-23 14:28:37 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-07-23 14:28:37 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-07-23 14:28:37 --> Model Class Initialized
DEBUG - 2011-07-23 14:28:37 --> Model Class Initialized
DEBUG - 2011-07-23 14:28:37 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-07-23 14:28:37 --> Database Driver Class Initialized
DEBUG - 2011-07-23 14:28:37 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-07-23 14:28:37 --> Helper loaded: url_helper
DEBUG - 2011-07-23 14:28:37 --> File loaded: application/views/common/header.php
DEBUG - 2011-07-23 14:28:37 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-07-23 14:28:37 --> File loaded: application/views/common/footer.php
DEBUG - 2011-07-23 14:28:37 --> File loaded: application/views/layout/main.php
DEBUG - 2011-07-23 14:28:37 --> Final output sent to browser
DEBUG - 2011-07-23 14:28:37 --> Total execution time: 0.0277
DEBUG - 2011-07-23 14:28:37 --> Final output sent to browser
DEBUG - 2011-07-23 14:28:37 --> Total execution time: 0.5005
DEBUG - 2011-07-23 14:28:38 --> Config Class Initialized
DEBUG - 2011-07-23 14:28:38 --> Hooks Class Initialized
DEBUG - 2011-07-23 14:28:38 --> Utf8 Class Initialized
DEBUG - 2011-07-23 14:28:38 --> UTF-8 Support Enabled
DEBUG - 2011-07-23 14:28:38 --> URI Class Initialized
DEBUG - 2011-07-23 14:28:38 --> Router Class Initialized
DEBUG - 2011-07-23 14:28:38 --> Output Class Initialized
DEBUG - 2011-07-23 14:28:38 --> Input Class Initialized
DEBUG - 2011-07-23 14:28:38 --> Global POST and COOKIE data sanitized
DEBUG - 2011-07-23 14:28:38 --> Language Class Initialized
DEBUG - 2011-07-23 14:28:38 --> Loader Class Initialized
DEBUG - 2011-07-23 14:28:38 --> Controller Class Initialized
ERROR - 2011-07-23 14:28:38 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-07-23 14:28:38 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-07-23 14:28:38 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-07-23 14:28:38 --> Model Class Initialized
DEBUG - 2011-07-23 14:28:38 --> Model Class Initialized
DEBUG - 2011-07-23 14:28:38 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-07-23 14:28:38 --> Database Driver Class Initialized
DEBUG - 2011-07-23 14:28:38 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-07-23 14:28:38 --> Helper loaded: url_helper
DEBUG - 2011-07-23 14:28:38 --> File loaded: application/views/common/header.php
DEBUG - 2011-07-23 14:28:38 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-07-23 14:28:38 --> File loaded: application/views/common/footer.php
DEBUG - 2011-07-23 14:28:38 --> File loaded: application/views/layout/main.php
DEBUG - 2011-07-23 14:28:38 --> Final output sent to browser
DEBUG - 2011-07-23 14:28:38 --> Total execution time: 0.0274
DEBUG - 2011-07-23 14:28:39 --> Config Class Initialized
DEBUG - 2011-07-23 14:28:39 --> Hooks Class Initialized
DEBUG - 2011-07-23 14:28:39 --> Utf8 Class Initialized
DEBUG - 2011-07-23 14:28:39 --> UTF-8 Support Enabled
DEBUG - 2011-07-23 14:28:39 --> URI Class Initialized
DEBUG - 2011-07-23 14:28:39 --> Router Class Initialized
ERROR - 2011-07-23 14:28:39 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-07-23 14:28:43 --> Config Class Initialized
DEBUG - 2011-07-23 14:28:43 --> Hooks Class Initialized
DEBUG - 2011-07-23 14:28:43 --> Utf8 Class Initialized
DEBUG - 2011-07-23 14:28:43 --> UTF-8 Support Enabled
DEBUG - 2011-07-23 14:28:43 --> URI Class Initialized
DEBUG - 2011-07-23 14:28:43 --> Router Class Initialized
DEBUG - 2011-07-23 14:28:43 --> Output Class Initialized
DEBUG - 2011-07-23 14:28:43 --> Input Class Initialized
DEBUG - 2011-07-23 14:28:43 --> Global POST and COOKIE data sanitized
DEBUG - 2011-07-23 14:28:43 --> Language Class Initialized
DEBUG - 2011-07-23 14:28:43 --> Loader Class Initialized
DEBUG - 2011-07-23 14:28:43 --> Controller Class Initialized
ERROR - 2011-07-23 14:28:43 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-07-23 14:28:43 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-07-23 14:28:43 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-07-23 14:28:43 --> Model Class Initialized
DEBUG - 2011-07-23 14:28:43 --> Model Class Initialized
DEBUG - 2011-07-23 14:28:43 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-07-23 14:28:43 --> Database Driver Class Initialized
DEBUG - 2011-07-23 14:28:43 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-07-23 14:28:43 --> Helper loaded: url_helper
DEBUG - 2011-07-23 14:28:43 --> File loaded: application/views/common/header.php
DEBUG - 2011-07-23 14:28:43 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-07-23 14:28:43 --> File loaded: application/views/common/footer.php
DEBUG - 2011-07-23 14:28:43 --> File loaded: application/views/layout/main.php
DEBUG - 2011-07-23 14:28:43 --> Final output sent to browser
DEBUG - 2011-07-23 14:28:43 --> Total execution time: 0.0273
DEBUG - 2011-07-23 14:28:43 --> Config Class Initialized
DEBUG - 2011-07-23 14:28:43 --> Hooks Class Initialized
DEBUG - 2011-07-23 14:28:43 --> Utf8 Class Initialized
DEBUG - 2011-07-23 14:28:43 --> UTF-8 Support Enabled
DEBUG - 2011-07-23 14:28:43 --> URI Class Initialized
DEBUG - 2011-07-23 14:28:43 --> Router Class Initialized
DEBUG - 2011-07-23 14:28:43 --> Output Class Initialized
DEBUG - 2011-07-23 14:28:43 --> Input Class Initialized
DEBUG - 2011-07-23 14:28:43 --> Global POST and COOKIE data sanitized
DEBUG - 2011-07-23 14:28:43 --> Language Class Initialized
DEBUG - 2011-07-23 14:28:43 --> Loader Class Initialized
DEBUG - 2011-07-23 14:28:43 --> Controller Class Initialized
DEBUG - 2011-07-23 14:28:43 --> Model Class Initialized
DEBUG - 2011-07-23 14:28:43 --> Model Class Initialized
DEBUG - 2011-07-23 14:28:43 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-07-23 14:28:43 --> Database Driver Class Initialized
DEBUG - 2011-07-23 14:28:44 --> Final output sent to browser
DEBUG - 2011-07-23 14:28:44 --> Total execution time: 0.5770
DEBUG - 2011-07-23 14:28:45 --> Config Class Initialized
DEBUG - 2011-07-23 14:28:45 --> Hooks Class Initialized
DEBUG - 2011-07-23 14:28:45 --> Utf8 Class Initialized
DEBUG - 2011-07-23 14:28:45 --> UTF-8 Support Enabled
DEBUG - 2011-07-23 14:28:45 --> URI Class Initialized
DEBUG - 2011-07-23 14:28:45 --> Router Class Initialized
ERROR - 2011-07-23 14:28:45 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-07-23 14:28:49 --> Config Class Initialized
DEBUG - 2011-07-23 14:28:49 --> Hooks Class Initialized
DEBUG - 2011-07-23 14:28:49 --> Utf8 Class Initialized
DEBUG - 2011-07-23 14:28:49 --> UTF-8 Support Enabled
DEBUG - 2011-07-23 14:28:49 --> URI Class Initialized
DEBUG - 2011-07-23 14:28:49 --> Router Class Initialized
DEBUG - 2011-07-23 14:28:49 --> Output Class Initialized
DEBUG - 2011-07-23 14:28:49 --> Input Class Initialized
DEBUG - 2011-07-23 14:28:49 --> Global POST and COOKIE data sanitized
DEBUG - 2011-07-23 14:28:49 --> Language Class Initialized
DEBUG - 2011-07-23 14:28:49 --> Loader Class Initialized
DEBUG - 2011-07-23 14:28:49 --> Controller Class Initialized
ERROR - 2011-07-23 14:28:49 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-07-23 14:28:49 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-07-23 14:28:49 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-07-23 14:28:49 --> Model Class Initialized
DEBUG - 2011-07-23 14:28:49 --> Model Class Initialized
DEBUG - 2011-07-23 14:28:49 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-07-23 14:28:49 --> Database Driver Class Initialized
DEBUG - 2011-07-23 14:28:49 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-07-23 14:28:49 --> Helper loaded: url_helper
DEBUG - 2011-07-23 14:28:49 --> File loaded: application/views/common/header.php
DEBUG - 2011-07-23 14:28:49 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-07-23 14:28:49 --> File loaded: application/views/common/footer.php
DEBUG - 2011-07-23 14:28:49 --> File loaded: application/views/layout/main.php
DEBUG - 2011-07-23 14:28:49 --> Final output sent to browser
DEBUG - 2011-07-23 14:28:49 --> Total execution time: 0.0277
DEBUG - 2011-07-23 14:28:50 --> Config Class Initialized
DEBUG - 2011-07-23 14:28:50 --> Hooks Class Initialized
DEBUG - 2011-07-23 14:28:50 --> Utf8 Class Initialized
DEBUG - 2011-07-23 14:28:50 --> UTF-8 Support Enabled
DEBUG - 2011-07-23 14:28:50 --> URI Class Initialized
DEBUG - 2011-07-23 14:28:50 --> Router Class Initialized
DEBUG - 2011-07-23 14:28:50 --> Output Class Initialized
DEBUG - 2011-07-23 14:28:50 --> Input Class Initialized
DEBUG - 2011-07-23 14:28:50 --> Global POST and COOKIE data sanitized
DEBUG - 2011-07-23 14:28:50 --> Language Class Initialized
DEBUG - 2011-07-23 14:28:50 --> Loader Class Initialized
DEBUG - 2011-07-23 14:28:50 --> Controller Class Initialized
DEBUG - 2011-07-23 14:28:50 --> Model Class Initialized
DEBUG - 2011-07-23 14:28:50 --> Model Class Initialized
DEBUG - 2011-07-23 14:28:50 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-07-23 14:28:50 --> Database Driver Class Initialized
DEBUG - 2011-07-23 14:28:50 --> Final output sent to browser
DEBUG - 2011-07-23 14:28:50 --> Total execution time: 0.5179
DEBUG - 2011-07-23 14:28:51 --> Config Class Initialized
DEBUG - 2011-07-23 14:28:51 --> Hooks Class Initialized
DEBUG - 2011-07-23 14:28:51 --> Utf8 Class Initialized
DEBUG - 2011-07-23 14:28:51 --> UTF-8 Support Enabled
DEBUG - 2011-07-23 14:28:51 --> URI Class Initialized
DEBUG - 2011-07-23 14:28:51 --> Router Class Initialized
ERROR - 2011-07-23 14:28:51 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-07-23 14:28:57 --> Config Class Initialized
DEBUG - 2011-07-23 14:28:57 --> Hooks Class Initialized
DEBUG - 2011-07-23 14:28:57 --> Utf8 Class Initialized
DEBUG - 2011-07-23 14:28:57 --> UTF-8 Support Enabled
DEBUG - 2011-07-23 14:28:57 --> URI Class Initialized
DEBUG - 2011-07-23 14:28:57 --> Router Class Initialized
DEBUG - 2011-07-23 14:28:57 --> Output Class Initialized
DEBUG - 2011-07-23 14:28:57 --> Input Class Initialized
DEBUG - 2011-07-23 14:28:57 --> Global POST and COOKIE data sanitized
DEBUG - 2011-07-23 14:28:57 --> Language Class Initialized
DEBUG - 2011-07-23 14:28:57 --> Loader Class Initialized
DEBUG - 2011-07-23 14:28:57 --> Controller Class Initialized
ERROR - 2011-07-23 14:28:57 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-07-23 14:28:57 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-07-23 14:28:57 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-07-23 14:28:57 --> Model Class Initialized
DEBUG - 2011-07-23 14:28:57 --> Model Class Initialized
DEBUG - 2011-07-23 14:28:57 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-07-23 14:28:57 --> Database Driver Class Initialized
DEBUG - 2011-07-23 14:28:57 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-07-23 14:28:57 --> Helper loaded: url_helper
DEBUG - 2011-07-23 14:28:57 --> File loaded: application/views/common/header.php
DEBUG - 2011-07-23 14:28:57 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-07-23 14:28:57 --> File loaded: application/views/common/footer.php
DEBUG - 2011-07-23 14:28:57 --> File loaded: application/views/layout/main.php
DEBUG - 2011-07-23 14:28:57 --> Final output sent to browser
DEBUG - 2011-07-23 14:28:57 --> Total execution time: 0.0318
DEBUG - 2011-07-23 14:28:58 --> Config Class Initialized
DEBUG - 2011-07-23 14:28:58 --> Hooks Class Initialized
DEBUG - 2011-07-23 14:28:58 --> Utf8 Class Initialized
DEBUG - 2011-07-23 14:28:58 --> UTF-8 Support Enabled
DEBUG - 2011-07-23 14:28:58 --> URI Class Initialized
DEBUG - 2011-07-23 14:28:58 --> Config Class Initialized
DEBUG - 2011-07-23 14:28:58 --> Hooks Class Initialized
DEBUG - 2011-07-23 14:28:58 --> Utf8 Class Initialized
DEBUG - 2011-07-23 14:28:58 --> Router Class Initialized
DEBUG - 2011-07-23 14:28:58 --> UTF-8 Support Enabled
DEBUG - 2011-07-23 14:28:58 --> URI Class Initialized
DEBUG - 2011-07-23 14:28:58 --> Output Class Initialized
DEBUG - 2011-07-23 14:28:58 --> Router Class Initialized
DEBUG - 2011-07-23 14:28:58 --> Input Class Initialized
DEBUG - 2011-07-23 14:28:58 --> Global POST and COOKIE data sanitized
DEBUG - 2011-07-23 14:28:58 --> Language Class Initialized
DEBUG - 2011-07-23 14:28:58 --> Output Class Initialized
DEBUG - 2011-07-23 14:28:58 --> Input Class Initialized
DEBUG - 2011-07-23 14:28:58 --> Global POST and COOKIE data sanitized
DEBUG - 2011-07-23 14:28:58 --> Loader Class Initialized
DEBUG - 2011-07-23 14:28:58 --> Controller Class Initialized
DEBUG - 2011-07-23 14:28:58 --> Language Class Initialized
ERROR - 2011-07-23 14:28:58 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-07-23 14:28:58 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-07-23 14:28:58 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-07-23 14:28:58 --> Model Class Initialized
DEBUG - 2011-07-23 14:28:58 --> Model Class Initialized
DEBUG - 2011-07-23 14:28:58 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-07-23 14:28:58 --> Loader Class Initialized
DEBUG - 2011-07-23 14:28:58 --> Controller Class Initialized
DEBUG - 2011-07-23 14:28:58 --> Model Class Initialized
DEBUG - 2011-07-23 14:28:58 --> Model Class Initialized
DEBUG - 2011-07-23 14:28:58 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-07-23 14:28:58 --> Database Driver Class Initialized
DEBUG - 2011-07-23 14:28:58 --> Database Driver Class Initialized
DEBUG - 2011-07-23 14:28:58 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-07-23 14:28:58 --> Helper loaded: url_helper
DEBUG - 2011-07-23 14:28:58 --> File loaded: application/views/common/header.php
DEBUG - 2011-07-23 14:28:58 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-07-23 14:28:58 --> File loaded: application/views/common/footer.php
DEBUG - 2011-07-23 14:28:58 --> File loaded: application/views/layout/main.php
DEBUG - 2011-07-23 14:28:58 --> Final output sent to browser
DEBUG - 2011-07-23 14:28:58 --> Total execution time: 0.0268
DEBUG - 2011-07-23 14:28:58 --> Final output sent to browser
DEBUG - 2011-07-23 14:28:58 --> Total execution time: 0.5152
DEBUG - 2011-07-23 14:28:59 --> Config Class Initialized
DEBUG - 2011-07-23 14:28:59 --> Hooks Class Initialized
DEBUG - 2011-07-23 14:28:59 --> Utf8 Class Initialized
DEBUG - 2011-07-23 14:28:59 --> UTF-8 Support Enabled
DEBUG - 2011-07-23 14:28:59 --> URI Class Initialized
DEBUG - 2011-07-23 14:28:59 --> Router Class Initialized
ERROR - 2011-07-23 14:28:59 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-07-23 14:29:04 --> Config Class Initialized
DEBUG - 2011-07-23 14:29:04 --> Hooks Class Initialized
DEBUG - 2011-07-23 14:29:04 --> Utf8 Class Initialized
DEBUG - 2011-07-23 14:29:04 --> UTF-8 Support Enabled
DEBUG - 2011-07-23 14:29:04 --> URI Class Initialized
DEBUG - 2011-07-23 14:29:04 --> Router Class Initialized
DEBUG - 2011-07-23 14:29:04 --> Output Class Initialized
DEBUG - 2011-07-23 14:29:04 --> Input Class Initialized
DEBUG - 2011-07-23 14:29:04 --> Global POST and COOKIE data sanitized
DEBUG - 2011-07-23 14:29:04 --> Language Class Initialized
DEBUG - 2011-07-23 14:29:04 --> Loader Class Initialized
DEBUG - 2011-07-23 14:29:04 --> Controller Class Initialized
ERROR - 2011-07-23 14:29:04 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-07-23 14:29:04 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-07-23 14:29:04 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-07-23 14:29:04 --> Model Class Initialized
DEBUG - 2011-07-23 14:29:04 --> Model Class Initialized
DEBUG - 2011-07-23 14:29:04 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-07-23 14:29:04 --> Database Driver Class Initialized
DEBUG - 2011-07-23 14:29:04 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-07-23 14:29:04 --> Helper loaded: url_helper
DEBUG - 2011-07-23 14:29:04 --> File loaded: application/views/common/header.php
DEBUG - 2011-07-23 14:29:04 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-07-23 14:29:04 --> File loaded: application/views/common/footer.php
DEBUG - 2011-07-23 14:29:04 --> File loaded: application/views/layout/main.php
DEBUG - 2011-07-23 14:29:04 --> Final output sent to browser
DEBUG - 2011-07-23 14:29:04 --> Total execution time: 0.1071
DEBUG - 2011-07-23 14:29:04 --> Config Class Initialized
DEBUG - 2011-07-23 14:29:04 --> Hooks Class Initialized
DEBUG - 2011-07-23 14:29:04 --> Utf8 Class Initialized
DEBUG - 2011-07-23 14:29:04 --> UTF-8 Support Enabled
DEBUG - 2011-07-23 14:29:04 --> URI Class Initialized
DEBUG - 2011-07-23 14:29:04 --> Router Class Initialized
DEBUG - 2011-07-23 14:29:04 --> Output Class Initialized
DEBUG - 2011-07-23 14:29:04 --> Input Class Initialized
DEBUG - 2011-07-23 14:29:04 --> Global POST and COOKIE data sanitized
DEBUG - 2011-07-23 14:29:04 --> Language Class Initialized
DEBUG - 2011-07-23 14:29:04 --> Config Class Initialized
DEBUG - 2011-07-23 14:29:04 --> Hooks Class Initialized
DEBUG - 2011-07-23 14:29:04 --> Utf8 Class Initialized
DEBUG - 2011-07-23 14:29:04 --> Loader Class Initialized
DEBUG - 2011-07-23 14:29:04 --> UTF-8 Support Enabled
DEBUG - 2011-07-23 14:29:04 --> Controller Class Initialized
DEBUG - 2011-07-23 14:29:04 --> Model Class Initialized
DEBUG - 2011-07-23 14:29:04 --> URI Class Initialized
DEBUG - 2011-07-23 14:29:04 --> Model Class Initialized
DEBUG - 2011-07-23 14:29:04 --> Router Class Initialized
DEBUG - 2011-07-23 14:29:04 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-07-23 14:29:04 --> Output Class Initialized
DEBUG - 2011-07-23 14:29:04 --> Input Class Initialized
DEBUG - 2011-07-23 14:29:04 --> Global POST and COOKIE data sanitized
DEBUG - 2011-07-23 14:29:04 --> Language Class Initialized
DEBUG - 2011-07-23 14:29:04 --> Loader Class Initialized
DEBUG - 2011-07-23 14:29:04 --> Controller Class Initialized
ERROR - 2011-07-23 14:29:04 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-07-23 14:29:04 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-07-23 14:29:04 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-07-23 14:29:04 --> Model Class Initialized
DEBUG - 2011-07-23 14:29:04 --> Model Class Initialized
DEBUG - 2011-07-23 14:29:04 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-07-23 14:29:04 --> Database Driver Class Initialized
DEBUG - 2011-07-23 14:29:04 --> Database Driver Class Initialized
DEBUG - 2011-07-23 14:29:05 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-07-23 14:29:05 --> Helper loaded: url_helper
DEBUG - 2011-07-23 14:29:05 --> File loaded: application/views/common/header.php
DEBUG - 2011-07-23 14:29:05 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-07-23 14:29:05 --> File loaded: application/views/common/footer.php
DEBUG - 2011-07-23 14:29:05 --> File loaded: application/views/layout/main.php
DEBUG - 2011-07-23 14:29:05 --> Final output sent to browser
DEBUG - 2011-07-23 14:29:05 --> Total execution time: 0.0406
DEBUG - 2011-07-23 14:29:05 --> Final output sent to browser
DEBUG - 2011-07-23 14:29:05 --> Total execution time: 0.6482
DEBUG - 2011-07-23 14:29:06 --> Config Class Initialized
DEBUG - 2011-07-23 14:29:06 --> Hooks Class Initialized
DEBUG - 2011-07-23 14:29:06 --> Utf8 Class Initialized
DEBUG - 2011-07-23 14:29:06 --> UTF-8 Support Enabled
DEBUG - 2011-07-23 14:29:06 --> URI Class Initialized
DEBUG - 2011-07-23 14:29:06 --> Router Class Initialized
ERROR - 2011-07-23 14:29:06 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-07-23 14:29:16 --> Config Class Initialized
DEBUG - 2011-07-23 14:29:16 --> Hooks Class Initialized
DEBUG - 2011-07-23 14:29:16 --> Utf8 Class Initialized
DEBUG - 2011-07-23 14:29:16 --> UTF-8 Support Enabled
DEBUG - 2011-07-23 14:29:16 --> URI Class Initialized
DEBUG - 2011-07-23 14:29:16 --> Router Class Initialized
DEBUG - 2011-07-23 14:29:16 --> Output Class Initialized
DEBUG - 2011-07-23 14:29:16 --> Input Class Initialized
DEBUG - 2011-07-23 14:29:16 --> Global POST and COOKIE data sanitized
DEBUG - 2011-07-23 14:29:16 --> Language Class Initialized
DEBUG - 2011-07-23 14:29:16 --> Loader Class Initialized
DEBUG - 2011-07-23 14:29:16 --> Controller Class Initialized
ERROR - 2011-07-23 14:29:16 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-07-23 14:29:16 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-07-23 14:29:16 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-07-23 14:29:16 --> Model Class Initialized
DEBUG - 2011-07-23 14:29:16 --> Model Class Initialized
DEBUG - 2011-07-23 14:29:16 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-07-23 14:29:16 --> Database Driver Class Initialized
DEBUG - 2011-07-23 14:29:16 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-07-23 14:29:16 --> Helper loaded: url_helper
DEBUG - 2011-07-23 14:29:16 --> File loaded: application/views/common/header.php
DEBUG - 2011-07-23 14:29:16 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-07-23 14:29:16 --> File loaded: application/views/common/footer.php
DEBUG - 2011-07-23 14:29:16 --> File loaded: application/views/layout/main.php
DEBUG - 2011-07-23 14:29:16 --> Final output sent to browser
DEBUG - 2011-07-23 14:29:16 --> Total execution time: 0.0268
DEBUG - 2011-07-23 14:29:17 --> Config Class Initialized
DEBUG - 2011-07-23 14:29:17 --> Hooks Class Initialized
DEBUG - 2011-07-23 14:29:17 --> Utf8 Class Initialized
DEBUG - 2011-07-23 14:29:17 --> UTF-8 Support Enabled
DEBUG - 2011-07-23 14:29:17 --> URI Class Initialized
DEBUG - 2011-07-23 14:29:17 --> Router Class Initialized
DEBUG - 2011-07-23 14:29:17 --> Output Class Initialized
DEBUG - 2011-07-23 14:29:17 --> Input Class Initialized
DEBUG - 2011-07-23 14:29:17 --> Global POST and COOKIE data sanitized
DEBUG - 2011-07-23 14:29:17 --> Language Class Initialized
DEBUG - 2011-07-23 14:29:17 --> Loader Class Initialized
DEBUG - 2011-07-23 14:29:17 --> Controller Class Initialized
DEBUG - 2011-07-23 14:29:17 --> Model Class Initialized
DEBUG - 2011-07-23 14:29:17 --> Model Class Initialized
DEBUG - 2011-07-23 14:29:17 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-07-23 14:29:17 --> Database Driver Class Initialized
DEBUG - 2011-07-23 14:29:17 --> Final output sent to browser
DEBUG - 2011-07-23 14:29:17 --> Total execution time: 0.4905
DEBUG - 2011-07-23 14:29:17 --> Config Class Initialized
DEBUG - 2011-07-23 14:29:17 --> Hooks Class Initialized
DEBUG - 2011-07-23 14:29:17 --> Utf8 Class Initialized
DEBUG - 2011-07-23 14:29:17 --> UTF-8 Support Enabled
DEBUG - 2011-07-23 14:29:17 --> URI Class Initialized
DEBUG - 2011-07-23 14:29:17 --> Router Class Initialized
DEBUG - 2011-07-23 14:29:17 --> Output Class Initialized
DEBUG - 2011-07-23 14:29:17 --> Input Class Initialized
DEBUG - 2011-07-23 14:29:17 --> Global POST and COOKIE data sanitized
DEBUG - 2011-07-23 14:29:17 --> Language Class Initialized
DEBUG - 2011-07-23 14:29:17 --> Loader Class Initialized
DEBUG - 2011-07-23 14:29:17 --> Controller Class Initialized
ERROR - 2011-07-23 14:29:17 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-07-23 14:29:17 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-07-23 14:29:17 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-07-23 14:29:17 --> Model Class Initialized
DEBUG - 2011-07-23 14:29:17 --> Model Class Initialized
DEBUG - 2011-07-23 14:29:17 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-07-23 14:29:17 --> Database Driver Class Initialized
DEBUG - 2011-07-23 14:29:17 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-07-23 14:29:17 --> Helper loaded: url_helper
DEBUG - 2011-07-23 14:29:17 --> File loaded: application/views/common/header.php
DEBUG - 2011-07-23 14:29:17 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-07-23 14:29:17 --> File loaded: application/views/common/footer.php
DEBUG - 2011-07-23 14:29:17 --> File loaded: application/views/layout/main.php
DEBUG - 2011-07-23 14:29:17 --> Final output sent to browser
DEBUG - 2011-07-23 14:29:17 --> Total execution time: 0.0405
DEBUG - 2011-07-23 14:29:18 --> Config Class Initialized
DEBUG - 2011-07-23 14:29:18 --> Hooks Class Initialized
DEBUG - 2011-07-23 14:29:18 --> Utf8 Class Initialized
DEBUG - 2011-07-23 14:29:18 --> UTF-8 Support Enabled
DEBUG - 2011-07-23 14:29:18 --> URI Class Initialized
DEBUG - 2011-07-23 14:29:18 --> Router Class Initialized
ERROR - 2011-07-23 14:29:18 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-07-23 14:29:30 --> Config Class Initialized
DEBUG - 2011-07-23 14:29:30 --> Hooks Class Initialized
DEBUG - 2011-07-23 14:29:30 --> Utf8 Class Initialized
DEBUG - 2011-07-23 14:29:30 --> UTF-8 Support Enabled
DEBUG - 2011-07-23 14:29:30 --> URI Class Initialized
DEBUG - 2011-07-23 14:29:30 --> Router Class Initialized
DEBUG - 2011-07-23 14:29:30 --> Output Class Initialized
DEBUG - 2011-07-23 14:29:30 --> Input Class Initialized
DEBUG - 2011-07-23 14:29:30 --> Global POST and COOKIE data sanitized
DEBUG - 2011-07-23 14:29:30 --> Language Class Initialized
DEBUG - 2011-07-23 14:29:30 --> Loader Class Initialized
DEBUG - 2011-07-23 14:29:30 --> Controller Class Initialized
ERROR - 2011-07-23 14:29:30 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-07-23 14:29:30 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-07-23 14:29:30 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-07-23 14:29:30 --> Model Class Initialized
DEBUG - 2011-07-23 14:29:30 --> Model Class Initialized
DEBUG - 2011-07-23 14:29:30 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-07-23 14:29:30 --> Database Driver Class Initialized
DEBUG - 2011-07-23 14:29:30 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-07-23 14:29:30 --> Helper loaded: url_helper
DEBUG - 2011-07-23 14:29:30 --> File loaded: application/views/common/header.php
DEBUG - 2011-07-23 14:29:30 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-07-23 14:29:30 --> File loaded: application/views/common/footer.php
DEBUG - 2011-07-23 14:29:30 --> File loaded: application/views/layout/main.php
DEBUG - 2011-07-23 14:29:30 --> Final output sent to browser
DEBUG - 2011-07-23 14:29:30 --> Total execution time: 0.1408
DEBUG - 2011-07-23 14:29:31 --> Config Class Initialized
DEBUG - 2011-07-23 14:29:31 --> Hooks Class Initialized
DEBUG - 2011-07-23 14:29:31 --> Utf8 Class Initialized
DEBUG - 2011-07-23 14:29:31 --> UTF-8 Support Enabled
DEBUG - 2011-07-23 14:29:31 --> URI Class Initialized
DEBUG - 2011-07-23 14:29:31 --> Router Class Initialized
DEBUG - 2011-07-23 14:29:31 --> Output Class Initialized
DEBUG - 2011-07-23 14:29:31 --> Input Class Initialized
DEBUG - 2011-07-23 14:29:31 --> Global POST and COOKIE data sanitized
DEBUG - 2011-07-23 14:29:31 --> Language Class Initialized
DEBUG - 2011-07-23 14:29:31 --> Loader Class Initialized
DEBUG - 2011-07-23 14:29:31 --> Controller Class Initialized
DEBUG - 2011-07-23 14:29:31 --> Model Class Initialized
DEBUG - 2011-07-23 14:29:31 --> Model Class Initialized
DEBUG - 2011-07-23 14:29:31 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-07-23 14:29:31 --> Database Driver Class Initialized
DEBUG - 2011-07-23 14:29:31 --> Final output sent to browser
DEBUG - 2011-07-23 14:29:31 --> Total execution time: 0.6371
DEBUG - 2011-07-23 14:29:32 --> Config Class Initialized
DEBUG - 2011-07-23 14:29:32 --> Hooks Class Initialized
DEBUG - 2011-07-23 14:29:32 --> Utf8 Class Initialized
DEBUG - 2011-07-23 14:29:32 --> UTF-8 Support Enabled
DEBUG - 2011-07-23 14:29:32 --> URI Class Initialized
DEBUG - 2011-07-23 14:29:32 --> Router Class Initialized
ERROR - 2011-07-23 14:29:32 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-07-23 14:29:36 --> Config Class Initialized
DEBUG - 2011-07-23 14:29:36 --> Hooks Class Initialized
DEBUG - 2011-07-23 14:29:36 --> Utf8 Class Initialized
DEBUG - 2011-07-23 14:29:36 --> UTF-8 Support Enabled
DEBUG - 2011-07-23 14:29:36 --> URI Class Initialized
DEBUG - 2011-07-23 14:29:36 --> Router Class Initialized
DEBUG - 2011-07-23 14:29:36 --> Output Class Initialized
DEBUG - 2011-07-23 14:29:36 --> Input Class Initialized
DEBUG - 2011-07-23 14:29:36 --> Global POST and COOKIE data sanitized
DEBUG - 2011-07-23 14:29:36 --> Language Class Initialized
DEBUG - 2011-07-23 14:29:36 --> Loader Class Initialized
DEBUG - 2011-07-23 14:29:36 --> Controller Class Initialized
ERROR - 2011-07-23 14:29:36 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-07-23 14:29:36 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-07-23 14:29:36 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-07-23 14:29:36 --> Model Class Initialized
DEBUG - 2011-07-23 14:29:36 --> Model Class Initialized
DEBUG - 2011-07-23 14:29:36 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-07-23 14:29:36 --> Database Driver Class Initialized
DEBUG - 2011-07-23 14:29:36 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-07-23 14:29:36 --> Helper loaded: url_helper
DEBUG - 2011-07-23 14:29:36 --> File loaded: application/views/common/header.php
DEBUG - 2011-07-23 14:29:36 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-07-23 14:29:36 --> File loaded: application/views/common/footer.php
DEBUG - 2011-07-23 14:29:36 --> File loaded: application/views/layout/main.php
DEBUG - 2011-07-23 14:29:36 --> Final output sent to browser
DEBUG - 2011-07-23 14:29:36 --> Total execution time: 0.0324
DEBUG - 2011-07-23 14:29:37 --> Config Class Initialized
DEBUG - 2011-07-23 14:29:37 --> Hooks Class Initialized
DEBUG - 2011-07-23 14:29:37 --> Utf8 Class Initialized
DEBUG - 2011-07-23 14:29:37 --> UTF-8 Support Enabled
DEBUG - 2011-07-23 14:29:37 --> URI Class Initialized
DEBUG - 2011-07-23 14:29:37 --> Router Class Initialized
DEBUG - 2011-07-23 14:29:37 --> Output Class Initialized
DEBUG - 2011-07-23 14:29:37 --> Input Class Initialized
DEBUG - 2011-07-23 14:29:37 --> Global POST and COOKIE data sanitized
DEBUG - 2011-07-23 14:29:37 --> Language Class Initialized
DEBUG - 2011-07-23 14:29:37 --> Loader Class Initialized
DEBUG - 2011-07-23 14:29:37 --> Controller Class Initialized
DEBUG - 2011-07-23 14:29:37 --> Model Class Initialized
DEBUG - 2011-07-23 14:29:37 --> Model Class Initialized
DEBUG - 2011-07-23 14:29:37 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-07-23 14:29:37 --> Database Driver Class Initialized
DEBUG - 2011-07-23 14:29:37 --> Final output sent to browser
DEBUG - 2011-07-23 14:29:37 --> Total execution time: 0.4675
DEBUG - 2011-07-23 14:29:39 --> Config Class Initialized
DEBUG - 2011-07-23 14:29:39 --> Hooks Class Initialized
DEBUG - 2011-07-23 14:29:39 --> Utf8 Class Initialized
DEBUG - 2011-07-23 14:29:39 --> UTF-8 Support Enabled
DEBUG - 2011-07-23 14:29:39 --> URI Class Initialized
DEBUG - 2011-07-23 14:29:39 --> Router Class Initialized
ERROR - 2011-07-23 14:29:39 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-07-23 14:29:44 --> Config Class Initialized
DEBUG - 2011-07-23 14:29:44 --> Hooks Class Initialized
DEBUG - 2011-07-23 14:29:44 --> Utf8 Class Initialized
DEBUG - 2011-07-23 14:29:44 --> UTF-8 Support Enabled
DEBUG - 2011-07-23 14:29:44 --> URI Class Initialized
DEBUG - 2011-07-23 14:29:44 --> Router Class Initialized
DEBUG - 2011-07-23 14:29:44 --> Output Class Initialized
DEBUG - 2011-07-23 14:29:44 --> Input Class Initialized
DEBUG - 2011-07-23 14:29:44 --> Global POST and COOKIE data sanitized
DEBUG - 2011-07-23 14:29:44 --> Language Class Initialized
DEBUG - 2011-07-23 14:29:44 --> Loader Class Initialized
DEBUG - 2011-07-23 14:29:44 --> Controller Class Initialized
ERROR - 2011-07-23 14:29:44 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-07-23 14:29:44 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-07-23 14:29:44 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-07-23 14:29:44 --> Model Class Initialized
DEBUG - 2011-07-23 14:29:44 --> Model Class Initialized
DEBUG - 2011-07-23 14:29:44 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-07-23 14:29:44 --> Database Driver Class Initialized
DEBUG - 2011-07-23 14:29:44 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-07-23 14:29:44 --> Helper loaded: url_helper
DEBUG - 2011-07-23 14:29:44 --> File loaded: application/views/common/header.php
DEBUG - 2011-07-23 14:29:44 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-07-23 14:29:44 --> File loaded: application/views/common/footer.php
DEBUG - 2011-07-23 14:29:44 --> File loaded: application/views/layout/main.php
DEBUG - 2011-07-23 14:29:44 --> Final output sent to browser
DEBUG - 2011-07-23 14:29:44 --> Total execution time: 0.0389
DEBUG - 2011-07-23 14:29:44 --> Config Class Initialized
DEBUG - 2011-07-23 14:29:44 --> Hooks Class Initialized
DEBUG - 2011-07-23 14:29:44 --> Utf8 Class Initialized
DEBUG - 2011-07-23 14:29:44 --> UTF-8 Support Enabled
DEBUG - 2011-07-23 14:29:44 --> URI Class Initialized
DEBUG - 2011-07-23 14:29:44 --> Router Class Initialized
DEBUG - 2011-07-23 14:29:44 --> Output Class Initialized
DEBUG - 2011-07-23 14:29:44 --> Input Class Initialized
DEBUG - 2011-07-23 14:29:44 --> Global POST and COOKIE data sanitized
DEBUG - 2011-07-23 14:29:44 --> Language Class Initialized
DEBUG - 2011-07-23 14:29:44 --> Loader Class Initialized
DEBUG - 2011-07-23 14:29:44 --> Controller Class Initialized
DEBUG - 2011-07-23 14:29:44 --> Model Class Initialized
DEBUG - 2011-07-23 14:29:44 --> Model Class Initialized
DEBUG - 2011-07-23 14:29:44 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-07-23 14:29:44 --> Database Driver Class Initialized
DEBUG - 2011-07-23 14:29:45 --> Final output sent to browser
DEBUG - 2011-07-23 14:29:45 --> Total execution time: 0.5430
DEBUG - 2011-07-23 14:29:46 --> Config Class Initialized
DEBUG - 2011-07-23 14:29:46 --> Hooks Class Initialized
DEBUG - 2011-07-23 14:29:46 --> Utf8 Class Initialized
DEBUG - 2011-07-23 14:29:46 --> UTF-8 Support Enabled
DEBUG - 2011-07-23 14:29:46 --> URI Class Initialized
DEBUG - 2011-07-23 14:29:46 --> Router Class Initialized
ERROR - 2011-07-23 14:29:46 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-07-23 14:29:48 --> Config Class Initialized
DEBUG - 2011-07-23 14:29:48 --> Hooks Class Initialized
DEBUG - 2011-07-23 14:29:48 --> Utf8 Class Initialized
DEBUG - 2011-07-23 14:29:48 --> UTF-8 Support Enabled
DEBUG - 2011-07-23 14:29:48 --> URI Class Initialized
DEBUG - 2011-07-23 14:29:48 --> Router Class Initialized
DEBUG - 2011-07-23 14:29:48 --> Output Class Initialized
DEBUG - 2011-07-23 14:29:48 --> Input Class Initialized
DEBUG - 2011-07-23 14:29:48 --> Global POST and COOKIE data sanitized
DEBUG - 2011-07-23 14:29:48 --> Language Class Initialized
DEBUG - 2011-07-23 14:29:48 --> Loader Class Initialized
DEBUG - 2011-07-23 14:29:48 --> Controller Class Initialized
ERROR - 2011-07-23 14:29:48 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-07-23 14:29:48 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-07-23 14:29:48 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-07-23 14:29:48 --> Model Class Initialized
DEBUG - 2011-07-23 14:29:48 --> Model Class Initialized
DEBUG - 2011-07-23 14:29:48 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-07-23 14:29:48 --> Database Driver Class Initialized
DEBUG - 2011-07-23 14:29:48 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-07-23 14:29:48 --> Helper loaded: url_helper
DEBUG - 2011-07-23 14:29:48 --> File loaded: application/views/common/header.php
DEBUG - 2011-07-23 14:29:48 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-07-23 14:29:48 --> File loaded: application/views/common/footer.php
DEBUG - 2011-07-23 14:29:48 --> File loaded: application/views/layout/main.php
DEBUG - 2011-07-23 14:29:48 --> Final output sent to browser
DEBUG - 2011-07-23 14:29:48 --> Total execution time: 0.0264
DEBUG - 2011-07-23 14:29:48 --> Config Class Initialized
DEBUG - 2011-07-23 14:29:48 --> Hooks Class Initialized
DEBUG - 2011-07-23 14:29:48 --> Utf8 Class Initialized
DEBUG - 2011-07-23 14:29:48 --> UTF-8 Support Enabled
DEBUG - 2011-07-23 14:29:48 --> URI Class Initialized
DEBUG - 2011-07-23 14:29:48 --> Router Class Initialized
DEBUG - 2011-07-23 14:29:48 --> Output Class Initialized
DEBUG - 2011-07-23 14:29:48 --> Input Class Initialized
DEBUG - 2011-07-23 14:29:48 --> Global POST and COOKIE data sanitized
DEBUG - 2011-07-23 14:29:48 --> Language Class Initialized
DEBUG - 2011-07-23 14:29:48 --> Loader Class Initialized
DEBUG - 2011-07-23 14:29:48 --> Controller Class Initialized
DEBUG - 2011-07-23 14:29:48 --> Model Class Initialized
DEBUG - 2011-07-23 14:29:48 --> Model Class Initialized
DEBUG - 2011-07-23 14:29:48 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-07-23 14:29:48 --> Database Driver Class Initialized
DEBUG - 2011-07-23 14:29:49 --> Final output sent to browser
DEBUG - 2011-07-23 14:29:49 --> Total execution time: 0.6510
DEBUG - 2011-07-23 14:29:50 --> Config Class Initialized
DEBUG - 2011-07-23 14:29:50 --> Hooks Class Initialized
DEBUG - 2011-07-23 14:29:50 --> Utf8 Class Initialized
DEBUG - 2011-07-23 14:29:50 --> UTF-8 Support Enabled
DEBUG - 2011-07-23 14:29:50 --> URI Class Initialized
DEBUG - 2011-07-23 14:29:50 --> Router Class Initialized
ERROR - 2011-07-23 14:29:50 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-07-23 14:29:53 --> Config Class Initialized
DEBUG - 2011-07-23 14:29:53 --> Hooks Class Initialized
DEBUG - 2011-07-23 14:29:53 --> Utf8 Class Initialized
DEBUG - 2011-07-23 14:29:53 --> UTF-8 Support Enabled
DEBUG - 2011-07-23 14:29:53 --> URI Class Initialized
DEBUG - 2011-07-23 14:29:53 --> Router Class Initialized
DEBUG - 2011-07-23 14:29:53 --> Output Class Initialized
DEBUG - 2011-07-23 14:29:53 --> Input Class Initialized
DEBUG - 2011-07-23 14:29:53 --> Global POST and COOKIE data sanitized
DEBUG - 2011-07-23 14:29:53 --> Language Class Initialized
DEBUG - 2011-07-23 14:29:53 --> Loader Class Initialized
DEBUG - 2011-07-23 14:29:53 --> Controller Class Initialized
ERROR - 2011-07-23 14:29:53 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-07-23 14:29:53 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-07-23 14:29:53 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-07-23 14:29:53 --> Model Class Initialized
DEBUG - 2011-07-23 14:29:53 --> Model Class Initialized
DEBUG - 2011-07-23 14:29:53 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-07-23 14:29:53 --> Database Driver Class Initialized
DEBUG - 2011-07-23 14:29:53 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-07-23 14:29:53 --> Helper loaded: url_helper
DEBUG - 2011-07-23 14:29:53 --> File loaded: application/views/common/header.php
DEBUG - 2011-07-23 14:29:53 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-07-23 14:29:53 --> File loaded: application/views/common/footer.php
DEBUG - 2011-07-23 14:29:53 --> File loaded: application/views/layout/main.php
DEBUG - 2011-07-23 14:29:53 --> Final output sent to browser
DEBUG - 2011-07-23 14:29:53 --> Total execution time: 0.0305
DEBUG - 2011-07-23 14:29:54 --> Config Class Initialized
DEBUG - 2011-07-23 14:29:54 --> Hooks Class Initialized
DEBUG - 2011-07-23 14:29:54 --> Utf8 Class Initialized
DEBUG - 2011-07-23 14:29:54 --> UTF-8 Support Enabled
DEBUG - 2011-07-23 14:29:54 --> URI Class Initialized
DEBUG - 2011-07-23 14:29:54 --> Router Class Initialized
DEBUG - 2011-07-23 14:29:54 --> Output Class Initialized
DEBUG - 2011-07-23 14:29:54 --> Input Class Initialized
DEBUG - 2011-07-23 14:29:54 --> Global POST and COOKIE data sanitized
DEBUG - 2011-07-23 14:29:54 --> Language Class Initialized
DEBUG - 2011-07-23 14:29:54 --> Loader Class Initialized
DEBUG - 2011-07-23 14:29:54 --> Controller Class Initialized
DEBUG - 2011-07-23 14:29:54 --> Model Class Initialized
DEBUG - 2011-07-23 14:29:54 --> Model Class Initialized
DEBUG - 2011-07-23 14:29:54 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-07-23 14:29:54 --> Database Driver Class Initialized
DEBUG - 2011-07-23 14:29:55 --> Final output sent to browser
DEBUG - 2011-07-23 14:29:55 --> Total execution time: 0.5073
DEBUG - 2011-07-23 14:29:56 --> Config Class Initialized
DEBUG - 2011-07-23 14:29:56 --> Hooks Class Initialized
DEBUG - 2011-07-23 14:29:56 --> Utf8 Class Initialized
DEBUG - 2011-07-23 14:29:56 --> UTF-8 Support Enabled
DEBUG - 2011-07-23 14:29:56 --> URI Class Initialized
DEBUG - 2011-07-23 14:29:56 --> Router Class Initialized
ERROR - 2011-07-23 14:29:56 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-07-23 14:30:04 --> Config Class Initialized
DEBUG - 2011-07-23 14:30:04 --> Hooks Class Initialized
DEBUG - 2011-07-23 14:30:04 --> Utf8 Class Initialized
DEBUG - 2011-07-23 14:30:04 --> UTF-8 Support Enabled
DEBUG - 2011-07-23 14:30:04 --> URI Class Initialized
DEBUG - 2011-07-23 14:30:04 --> Router Class Initialized
DEBUG - 2011-07-23 14:30:04 --> Output Class Initialized
DEBUG - 2011-07-23 14:30:04 --> Input Class Initialized
DEBUG - 2011-07-23 14:30:04 --> Global POST and COOKIE data sanitized
DEBUG - 2011-07-23 14:30:04 --> Language Class Initialized
DEBUG - 2011-07-23 14:30:04 --> Loader Class Initialized
DEBUG - 2011-07-23 14:30:04 --> Controller Class Initialized
ERROR - 2011-07-23 14:30:04 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-07-23 14:30:04 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-07-23 14:30:04 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-07-23 14:30:04 --> Model Class Initialized
DEBUG - 2011-07-23 14:30:04 --> Model Class Initialized
DEBUG - 2011-07-23 14:30:04 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-07-23 14:30:04 --> Database Driver Class Initialized
DEBUG - 2011-07-23 14:30:04 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-07-23 14:30:04 --> Helper loaded: url_helper
DEBUG - 2011-07-23 14:30:04 --> File loaded: application/views/common/header.php
DEBUG - 2011-07-23 14:30:04 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-07-23 14:30:04 --> File loaded: application/views/common/footer.php
DEBUG - 2011-07-23 14:30:04 --> File loaded: application/views/layout/main.php
DEBUG - 2011-07-23 14:30:04 --> Final output sent to browser
DEBUG - 2011-07-23 14:30:04 --> Total execution time: 0.3516
DEBUG - 2011-07-23 14:30:05 --> Config Class Initialized
DEBUG - 2011-07-23 14:30:05 --> Hooks Class Initialized
DEBUG - 2011-07-23 14:30:05 --> Utf8 Class Initialized
DEBUG - 2011-07-23 14:30:05 --> UTF-8 Support Enabled
DEBUG - 2011-07-23 14:30:05 --> URI Class Initialized
DEBUG - 2011-07-23 14:30:05 --> Router Class Initialized
DEBUG - 2011-07-23 14:30:05 --> Output Class Initialized
DEBUG - 2011-07-23 14:30:05 --> Input Class Initialized
DEBUG - 2011-07-23 14:30:05 --> Global POST and COOKIE data sanitized
DEBUG - 2011-07-23 14:30:05 --> Language Class Initialized
DEBUG - 2011-07-23 14:30:05 --> Loader Class Initialized
DEBUG - 2011-07-23 14:30:05 --> Controller Class Initialized
DEBUG - 2011-07-23 14:30:05 --> Model Class Initialized
DEBUG - 2011-07-23 14:30:05 --> Model Class Initialized
DEBUG - 2011-07-23 14:30:05 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-07-23 14:30:05 --> Database Driver Class Initialized
DEBUG - 2011-07-23 14:30:05 --> Final output sent to browser
DEBUG - 2011-07-23 14:30:05 --> Total execution time: 0.5597
DEBUG - 2011-07-23 14:30:07 --> Config Class Initialized
DEBUG - 2011-07-23 14:30:07 --> Hooks Class Initialized
DEBUG - 2011-07-23 14:30:07 --> Utf8 Class Initialized
DEBUG - 2011-07-23 14:30:07 --> UTF-8 Support Enabled
DEBUG - 2011-07-23 14:30:07 --> URI Class Initialized
DEBUG - 2011-07-23 14:30:07 --> Router Class Initialized
ERROR - 2011-07-23 14:30:07 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-07-23 14:30:16 --> Config Class Initialized
DEBUG - 2011-07-23 14:30:16 --> Hooks Class Initialized
DEBUG - 2011-07-23 14:30:16 --> Utf8 Class Initialized
DEBUG - 2011-07-23 14:30:16 --> UTF-8 Support Enabled
DEBUG - 2011-07-23 14:30:16 --> URI Class Initialized
DEBUG - 2011-07-23 14:30:16 --> Router Class Initialized
DEBUG - 2011-07-23 14:30:16 --> Output Class Initialized
DEBUG - 2011-07-23 14:30:16 --> Input Class Initialized
DEBUG - 2011-07-23 14:30:16 --> Global POST and COOKIE data sanitized
DEBUG - 2011-07-23 14:30:16 --> Language Class Initialized
DEBUG - 2011-07-23 14:30:16 --> Loader Class Initialized
DEBUG - 2011-07-23 14:30:16 --> Controller Class Initialized
ERROR - 2011-07-23 14:30:16 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-07-23 14:30:16 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-07-23 14:30:16 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-07-23 14:30:16 --> Model Class Initialized
DEBUG - 2011-07-23 14:30:16 --> Model Class Initialized
DEBUG - 2011-07-23 14:30:16 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-07-23 14:30:16 --> Database Driver Class Initialized
DEBUG - 2011-07-23 14:30:16 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-07-23 14:30:16 --> Helper loaded: url_helper
DEBUG - 2011-07-23 14:30:16 --> File loaded: application/views/common/header.php
DEBUG - 2011-07-23 14:30:16 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-07-23 14:30:16 --> File loaded: application/views/common/footer.php
DEBUG - 2011-07-23 14:30:16 --> File loaded: application/views/layout/main.php
DEBUG - 2011-07-23 14:30:16 --> Final output sent to browser
DEBUG - 2011-07-23 14:30:16 --> Total execution time: 0.0624
DEBUG - 2011-07-23 14:30:16 --> Config Class Initialized
DEBUG - 2011-07-23 14:30:16 --> Hooks Class Initialized
DEBUG - 2011-07-23 14:30:16 --> Utf8 Class Initialized
DEBUG - 2011-07-23 14:30:16 --> UTF-8 Support Enabled
DEBUG - 2011-07-23 14:30:16 --> URI Class Initialized
DEBUG - 2011-07-23 14:30:16 --> Router Class Initialized
DEBUG - 2011-07-23 14:30:16 --> Output Class Initialized
DEBUG - 2011-07-23 14:30:16 --> Input Class Initialized
DEBUG - 2011-07-23 14:30:16 --> Global POST and COOKIE data sanitized
DEBUG - 2011-07-23 14:30:16 --> Language Class Initialized
DEBUG - 2011-07-23 14:30:16 --> Loader Class Initialized
DEBUG - 2011-07-23 14:30:16 --> Controller Class Initialized
DEBUG - 2011-07-23 14:30:16 --> Model Class Initialized
DEBUG - 2011-07-23 14:30:16 --> Model Class Initialized
DEBUG - 2011-07-23 14:30:16 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-07-23 14:30:16 --> Database Driver Class Initialized
DEBUG - 2011-07-23 14:30:17 --> Final output sent to browser
DEBUG - 2011-07-23 14:30:17 --> Total execution time: 0.4579
DEBUG - 2011-07-23 14:30:18 --> Config Class Initialized
DEBUG - 2011-07-23 14:30:18 --> Hooks Class Initialized
DEBUG - 2011-07-23 14:30:18 --> Utf8 Class Initialized
DEBUG - 2011-07-23 14:30:18 --> UTF-8 Support Enabled
DEBUG - 2011-07-23 14:30:18 --> URI Class Initialized
DEBUG - 2011-07-23 14:30:18 --> Router Class Initialized
ERROR - 2011-07-23 14:30:18 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-07-23 14:30:22 --> Config Class Initialized
DEBUG - 2011-07-23 14:30:22 --> Hooks Class Initialized
DEBUG - 2011-07-23 14:30:22 --> Utf8 Class Initialized
DEBUG - 2011-07-23 14:30:22 --> UTF-8 Support Enabled
DEBUG - 2011-07-23 14:30:22 --> URI Class Initialized
DEBUG - 2011-07-23 14:30:22 --> Router Class Initialized
DEBUG - 2011-07-23 14:30:22 --> Output Class Initialized
DEBUG - 2011-07-23 14:30:22 --> Input Class Initialized
DEBUG - 2011-07-23 14:30:22 --> Global POST and COOKIE data sanitized
DEBUG - 2011-07-23 14:30:22 --> Language Class Initialized
DEBUG - 2011-07-23 14:30:22 --> Loader Class Initialized
DEBUG - 2011-07-23 14:30:22 --> Controller Class Initialized
ERROR - 2011-07-23 14:30:22 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-07-23 14:30:22 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-07-23 14:30:22 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-07-23 14:30:22 --> Model Class Initialized
DEBUG - 2011-07-23 14:30:22 --> Model Class Initialized
DEBUG - 2011-07-23 14:30:22 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-07-23 14:30:22 --> Database Driver Class Initialized
DEBUG - 2011-07-23 14:30:22 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-07-23 14:30:22 --> Helper loaded: url_helper
DEBUG - 2011-07-23 14:30:22 --> File loaded: application/views/common/header.php
DEBUG - 2011-07-23 14:30:22 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-07-23 14:30:22 --> File loaded: application/views/common/footer.php
DEBUG - 2011-07-23 14:30:22 --> File loaded: application/views/layout/main.php
DEBUG - 2011-07-23 14:30:22 --> Final output sent to browser
DEBUG - 2011-07-23 14:30:22 --> Total execution time: 0.0281
DEBUG - 2011-07-23 14:30:23 --> Config Class Initialized
DEBUG - 2011-07-23 14:30:23 --> Hooks Class Initialized
DEBUG - 2011-07-23 14:30:23 --> Utf8 Class Initialized
DEBUG - 2011-07-23 14:30:23 --> UTF-8 Support Enabled
DEBUG - 2011-07-23 14:30:23 --> URI Class Initialized
DEBUG - 2011-07-23 14:30:23 --> Router Class Initialized
DEBUG - 2011-07-23 14:30:23 --> Output Class Initialized
DEBUG - 2011-07-23 14:30:23 --> Input Class Initialized
DEBUG - 2011-07-23 14:30:23 --> Global POST and COOKIE data sanitized
DEBUG - 2011-07-23 14:30:23 --> Language Class Initialized
DEBUG - 2011-07-23 14:30:23 --> Loader Class Initialized
DEBUG - 2011-07-23 14:30:23 --> Controller Class Initialized
DEBUG - 2011-07-23 14:30:23 --> Model Class Initialized
DEBUG - 2011-07-23 14:30:23 --> Model Class Initialized
DEBUG - 2011-07-23 14:30:23 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-07-23 14:30:23 --> Database Driver Class Initialized
DEBUG - 2011-07-23 14:30:23 --> Final output sent to browser
DEBUG - 2011-07-23 14:30:23 --> Total execution time: 0.4991
DEBUG - 2011-07-23 14:30:24 --> Config Class Initialized
DEBUG - 2011-07-23 14:30:24 --> Hooks Class Initialized
DEBUG - 2011-07-23 14:30:24 --> Utf8 Class Initialized
DEBUG - 2011-07-23 14:30:24 --> UTF-8 Support Enabled
DEBUG - 2011-07-23 14:30:24 --> URI Class Initialized
DEBUG - 2011-07-23 14:30:24 --> Router Class Initialized
ERROR - 2011-07-23 14:30:24 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-07-23 14:30:29 --> Config Class Initialized
DEBUG - 2011-07-23 14:30:29 --> Hooks Class Initialized
DEBUG - 2011-07-23 14:30:29 --> Utf8 Class Initialized
DEBUG - 2011-07-23 14:30:29 --> UTF-8 Support Enabled
DEBUG - 2011-07-23 14:30:29 --> URI Class Initialized
DEBUG - 2011-07-23 14:30:29 --> Router Class Initialized
DEBUG - 2011-07-23 14:30:29 --> Output Class Initialized
DEBUG - 2011-07-23 14:30:29 --> Input Class Initialized
DEBUG - 2011-07-23 14:30:29 --> Global POST and COOKIE data sanitized
DEBUG - 2011-07-23 14:30:29 --> Language Class Initialized
DEBUG - 2011-07-23 14:30:29 --> Loader Class Initialized
DEBUG - 2011-07-23 14:30:29 --> Controller Class Initialized
ERROR - 2011-07-23 14:30:29 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-07-23 14:30:29 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-07-23 14:30:29 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-07-23 14:30:29 --> Model Class Initialized
DEBUG - 2011-07-23 14:30:29 --> Model Class Initialized
DEBUG - 2011-07-23 14:30:29 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-07-23 14:30:30 --> Database Driver Class Initialized
DEBUG - 2011-07-23 14:30:30 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-07-23 14:30:30 --> Helper loaded: url_helper
DEBUG - 2011-07-23 14:30:30 --> File loaded: application/views/common/header.php
DEBUG - 2011-07-23 14:30:30 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-07-23 14:30:30 --> File loaded: application/views/common/footer.php
DEBUG - 2011-07-23 14:30:30 --> File loaded: application/views/layout/main.php
DEBUG - 2011-07-23 14:30:30 --> Final output sent to browser
DEBUG - 2011-07-23 14:30:30 --> Total execution time: 0.0349
DEBUG - 2011-07-23 14:30:30 --> Config Class Initialized
DEBUG - 2011-07-23 14:30:30 --> Hooks Class Initialized
DEBUG - 2011-07-23 14:30:30 --> Utf8 Class Initialized
DEBUG - 2011-07-23 14:30:30 --> UTF-8 Support Enabled
DEBUG - 2011-07-23 14:30:30 --> URI Class Initialized
DEBUG - 2011-07-23 14:30:30 --> Router Class Initialized
DEBUG - 2011-07-23 14:30:30 --> Output Class Initialized
DEBUG - 2011-07-23 14:30:30 --> Input Class Initialized
DEBUG - 2011-07-23 14:30:30 --> Global POST and COOKIE data sanitized
DEBUG - 2011-07-23 14:30:30 --> Language Class Initialized
DEBUG - 2011-07-23 14:30:30 --> Loader Class Initialized
DEBUG - 2011-07-23 14:30:30 --> Controller Class Initialized
DEBUG - 2011-07-23 14:30:30 --> Model Class Initialized
DEBUG - 2011-07-23 14:30:30 --> Model Class Initialized
DEBUG - 2011-07-23 14:30:30 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-07-23 14:30:30 --> Database Driver Class Initialized
DEBUG - 2011-07-23 14:30:31 --> Final output sent to browser
DEBUG - 2011-07-23 14:30:31 --> Total execution time: 0.5004
DEBUG - 2011-07-23 14:30:32 --> Config Class Initialized
DEBUG - 2011-07-23 14:30:32 --> Hooks Class Initialized
DEBUG - 2011-07-23 14:30:32 --> Utf8 Class Initialized
DEBUG - 2011-07-23 14:30:32 --> UTF-8 Support Enabled
DEBUG - 2011-07-23 14:30:32 --> URI Class Initialized
DEBUG - 2011-07-23 14:30:32 --> Router Class Initialized
ERROR - 2011-07-23 14:30:32 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-07-23 14:30:35 --> Config Class Initialized
DEBUG - 2011-07-23 14:30:35 --> Hooks Class Initialized
DEBUG - 2011-07-23 14:30:35 --> Utf8 Class Initialized
DEBUG - 2011-07-23 14:30:35 --> UTF-8 Support Enabled
DEBUG - 2011-07-23 14:30:35 --> URI Class Initialized
DEBUG - 2011-07-23 14:30:35 --> Router Class Initialized
DEBUG - 2011-07-23 14:30:35 --> Output Class Initialized
DEBUG - 2011-07-23 14:30:35 --> Input Class Initialized
DEBUG - 2011-07-23 14:30:35 --> Global POST and COOKIE data sanitized
DEBUG - 2011-07-23 14:30:35 --> Language Class Initialized
DEBUG - 2011-07-23 14:30:35 --> Loader Class Initialized
DEBUG - 2011-07-23 14:30:35 --> Controller Class Initialized
ERROR - 2011-07-23 14:30:35 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-07-23 14:30:35 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-07-23 14:30:35 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-07-23 14:30:35 --> Model Class Initialized
DEBUG - 2011-07-23 14:30:35 --> Model Class Initialized
DEBUG - 2011-07-23 14:30:35 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-07-23 14:30:35 --> Database Driver Class Initialized
DEBUG - 2011-07-23 14:30:35 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-07-23 14:30:35 --> Helper loaded: url_helper
DEBUG - 2011-07-23 14:30:35 --> File loaded: application/views/common/header.php
DEBUG - 2011-07-23 14:30:35 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-07-23 14:30:35 --> File loaded: application/views/common/footer.php
DEBUG - 2011-07-23 14:30:35 --> File loaded: application/views/layout/main.php
DEBUG - 2011-07-23 14:30:35 --> Final output sent to browser
DEBUG - 2011-07-23 14:30:35 --> Total execution time: 0.0280
DEBUG - 2011-07-23 14:30:36 --> Config Class Initialized
DEBUG - 2011-07-23 14:30:36 --> Hooks Class Initialized
DEBUG - 2011-07-23 14:30:36 --> Utf8 Class Initialized
DEBUG - 2011-07-23 14:30:36 --> UTF-8 Support Enabled
DEBUG - 2011-07-23 14:30:36 --> URI Class Initialized
DEBUG - 2011-07-23 14:30:36 --> Router Class Initialized
DEBUG - 2011-07-23 14:30:36 --> Output Class Initialized
DEBUG - 2011-07-23 14:30:36 --> Input Class Initialized
DEBUG - 2011-07-23 14:30:36 --> Global POST and COOKIE data sanitized
DEBUG - 2011-07-23 14:30:36 --> Language Class Initialized
DEBUG - 2011-07-23 14:30:36 --> Loader Class Initialized
DEBUG - 2011-07-23 14:30:36 --> Controller Class Initialized
DEBUG - 2011-07-23 14:30:36 --> Model Class Initialized
DEBUG - 2011-07-23 14:30:36 --> Model Class Initialized
DEBUG - 2011-07-23 14:30:36 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-07-23 14:30:36 --> Database Driver Class Initialized
DEBUG - 2011-07-23 14:30:36 --> Final output sent to browser
DEBUG - 2011-07-23 14:30:36 --> Total execution time: 0.5207
DEBUG - 2011-07-23 14:30:38 --> Config Class Initialized
DEBUG - 2011-07-23 14:30:38 --> Hooks Class Initialized
DEBUG - 2011-07-23 14:30:38 --> Utf8 Class Initialized
DEBUG - 2011-07-23 14:30:38 --> UTF-8 Support Enabled
DEBUG - 2011-07-23 14:30:38 --> URI Class Initialized
DEBUG - 2011-07-23 14:30:38 --> Router Class Initialized
ERROR - 2011-07-23 14:30:38 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-07-23 14:30:43 --> Config Class Initialized
DEBUG - 2011-07-23 14:30:43 --> Hooks Class Initialized
DEBUG - 2011-07-23 14:30:43 --> Utf8 Class Initialized
DEBUG - 2011-07-23 14:30:43 --> UTF-8 Support Enabled
DEBUG - 2011-07-23 14:30:43 --> URI Class Initialized
DEBUG - 2011-07-23 14:30:43 --> Router Class Initialized
DEBUG - 2011-07-23 14:30:43 --> Output Class Initialized
DEBUG - 2011-07-23 14:30:43 --> Input Class Initialized
DEBUG - 2011-07-23 14:30:43 --> Global POST and COOKIE data sanitized
DEBUG - 2011-07-23 14:30:43 --> Language Class Initialized
DEBUG - 2011-07-23 14:30:43 --> Loader Class Initialized
DEBUG - 2011-07-23 14:30:43 --> Controller Class Initialized
ERROR - 2011-07-23 14:30:43 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-07-23 14:30:43 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-07-23 14:30:43 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-07-23 14:30:43 --> Model Class Initialized
DEBUG - 2011-07-23 14:30:43 --> Model Class Initialized
DEBUG - 2011-07-23 14:30:43 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-07-23 14:30:43 --> Database Driver Class Initialized
DEBUG - 2011-07-23 14:30:43 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-07-23 14:30:43 --> Helper loaded: url_helper
DEBUG - 2011-07-23 14:30:43 --> File loaded: application/views/common/header.php
DEBUG - 2011-07-23 14:30:43 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-07-23 14:30:43 --> File loaded: application/views/common/footer.php
DEBUG - 2011-07-23 14:30:43 --> File loaded: application/views/layout/main.php
DEBUG - 2011-07-23 14:30:43 --> Final output sent to browser
DEBUG - 2011-07-23 14:30:43 --> Total execution time: 0.0273
DEBUG - 2011-07-23 14:30:44 --> Config Class Initialized
DEBUG - 2011-07-23 14:30:44 --> Hooks Class Initialized
DEBUG - 2011-07-23 14:30:44 --> Utf8 Class Initialized
DEBUG - 2011-07-23 14:30:44 --> UTF-8 Support Enabled
DEBUG - 2011-07-23 14:30:44 --> URI Class Initialized
DEBUG - 2011-07-23 14:30:44 --> Router Class Initialized
DEBUG - 2011-07-23 14:30:44 --> Output Class Initialized
DEBUG - 2011-07-23 14:30:44 --> Input Class Initialized
DEBUG - 2011-07-23 14:30:44 --> Global POST and COOKIE data sanitized
DEBUG - 2011-07-23 14:30:44 --> Language Class Initialized
DEBUG - 2011-07-23 14:30:44 --> Loader Class Initialized
DEBUG - 2011-07-23 14:30:44 --> Controller Class Initialized
DEBUG - 2011-07-23 14:30:44 --> Model Class Initialized
DEBUG - 2011-07-23 14:30:44 --> Model Class Initialized
DEBUG - 2011-07-23 14:30:44 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-07-23 14:30:44 --> Database Driver Class Initialized
DEBUG - 2011-07-23 14:30:44 --> Final output sent to browser
DEBUG - 2011-07-23 14:30:44 --> Total execution time: 0.5086
DEBUG - 2011-07-23 14:30:45 --> Config Class Initialized
DEBUG - 2011-07-23 14:30:45 --> Hooks Class Initialized
DEBUG - 2011-07-23 14:30:45 --> Utf8 Class Initialized
DEBUG - 2011-07-23 14:30:45 --> UTF-8 Support Enabled
DEBUG - 2011-07-23 14:30:45 --> URI Class Initialized
DEBUG - 2011-07-23 14:30:45 --> Router Class Initialized
ERROR - 2011-07-23 14:30:45 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-07-23 14:30:49 --> Config Class Initialized
DEBUG - 2011-07-23 14:30:49 --> Hooks Class Initialized
DEBUG - 2011-07-23 14:30:49 --> Utf8 Class Initialized
DEBUG - 2011-07-23 14:30:49 --> UTF-8 Support Enabled
DEBUG - 2011-07-23 14:30:49 --> URI Class Initialized
DEBUG - 2011-07-23 14:30:49 --> Router Class Initialized
DEBUG - 2011-07-23 14:30:49 --> Output Class Initialized
DEBUG - 2011-07-23 14:30:49 --> Input Class Initialized
DEBUG - 2011-07-23 14:30:49 --> Global POST and COOKIE data sanitized
DEBUG - 2011-07-23 14:30:49 --> Language Class Initialized
DEBUG - 2011-07-23 14:30:49 --> Loader Class Initialized
DEBUG - 2011-07-23 14:30:49 --> Controller Class Initialized
ERROR - 2011-07-23 14:30:49 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-07-23 14:30:49 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-07-23 14:30:49 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-07-23 14:30:49 --> Model Class Initialized
DEBUG - 2011-07-23 14:30:49 --> Model Class Initialized
DEBUG - 2011-07-23 14:30:49 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-07-23 14:30:49 --> Database Driver Class Initialized
DEBUG - 2011-07-23 14:30:49 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-07-23 14:30:49 --> Helper loaded: url_helper
DEBUG - 2011-07-23 14:30:49 --> File loaded: application/views/common/header.php
DEBUG - 2011-07-23 14:30:49 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-07-23 14:30:49 --> File loaded: application/views/common/footer.php
DEBUG - 2011-07-23 14:30:49 --> File loaded: application/views/layout/main.php
DEBUG - 2011-07-23 14:30:49 --> Final output sent to browser
DEBUG - 2011-07-23 14:30:49 --> Total execution time: 0.0277
DEBUG - 2011-07-23 14:30:49 --> Config Class Initialized
DEBUG - 2011-07-23 14:30:49 --> Hooks Class Initialized
DEBUG - 2011-07-23 14:30:49 --> Utf8 Class Initialized
DEBUG - 2011-07-23 14:30:49 --> UTF-8 Support Enabled
DEBUG - 2011-07-23 14:30:49 --> URI Class Initialized
DEBUG - 2011-07-23 14:30:49 --> Router Class Initialized
DEBUG - 2011-07-23 14:30:49 --> Output Class Initialized
DEBUG - 2011-07-23 14:30:49 --> Input Class Initialized
DEBUG - 2011-07-23 14:30:49 --> Global POST and COOKIE data sanitized
DEBUG - 2011-07-23 14:30:49 --> Language Class Initialized
DEBUG - 2011-07-23 14:30:49 --> Loader Class Initialized
DEBUG - 2011-07-23 14:30:49 --> Controller Class Initialized
DEBUG - 2011-07-23 14:30:49 --> Model Class Initialized
DEBUG - 2011-07-23 14:30:49 --> Model Class Initialized
DEBUG - 2011-07-23 14:30:49 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-07-23 14:30:49 --> Database Driver Class Initialized
DEBUG - 2011-07-23 14:30:50 --> Final output sent to browser
DEBUG - 2011-07-23 14:30:50 --> Total execution time: 0.5101
DEBUG - 2011-07-23 14:30:51 --> Config Class Initialized
DEBUG - 2011-07-23 14:30:51 --> Hooks Class Initialized
DEBUG - 2011-07-23 14:30:51 --> Utf8 Class Initialized
DEBUG - 2011-07-23 14:30:51 --> UTF-8 Support Enabled
DEBUG - 2011-07-23 14:30:51 --> URI Class Initialized
DEBUG - 2011-07-23 14:30:51 --> Router Class Initialized
ERROR - 2011-07-23 14:30:51 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-07-23 14:30:59 --> Config Class Initialized
DEBUG - 2011-07-23 14:30:59 --> Hooks Class Initialized
DEBUG - 2011-07-23 14:30:59 --> Utf8 Class Initialized
DEBUG - 2011-07-23 14:30:59 --> UTF-8 Support Enabled
DEBUG - 2011-07-23 14:30:59 --> URI Class Initialized
DEBUG - 2011-07-23 14:30:59 --> Router Class Initialized
DEBUG - 2011-07-23 14:30:59 --> Output Class Initialized
DEBUG - 2011-07-23 14:30:59 --> Input Class Initialized
DEBUG - 2011-07-23 14:30:59 --> Global POST and COOKIE data sanitized
DEBUG - 2011-07-23 14:30:59 --> Language Class Initialized
DEBUG - 2011-07-23 14:30:59 --> Loader Class Initialized
DEBUG - 2011-07-23 14:30:59 --> Controller Class Initialized
ERROR - 2011-07-23 14:30:59 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-07-23 14:30:59 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-07-23 14:30:59 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-07-23 14:30:59 --> Model Class Initialized
DEBUG - 2011-07-23 14:30:59 --> Model Class Initialized
DEBUG - 2011-07-23 14:30:59 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-07-23 14:30:59 --> Database Driver Class Initialized
DEBUG - 2011-07-23 14:30:59 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-07-23 14:30:59 --> Helper loaded: url_helper
DEBUG - 2011-07-23 14:30:59 --> File loaded: application/views/common/header.php
DEBUG - 2011-07-23 14:30:59 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-07-23 14:30:59 --> File loaded: application/views/common/footer.php
DEBUG - 2011-07-23 14:30:59 --> File loaded: application/views/layout/main.php
DEBUG - 2011-07-23 14:30:59 --> Final output sent to browser
DEBUG - 2011-07-23 14:30:59 --> Total execution time: 0.0286
DEBUG - 2011-07-23 14:31:00 --> Config Class Initialized
DEBUG - 2011-07-23 14:31:00 --> Hooks Class Initialized
DEBUG - 2011-07-23 14:31:00 --> Utf8 Class Initialized
DEBUG - 2011-07-23 14:31:00 --> UTF-8 Support Enabled
DEBUG - 2011-07-23 14:31:00 --> URI Class Initialized
DEBUG - 2011-07-23 14:31:00 --> Router Class Initialized
DEBUG - 2011-07-23 14:31:00 --> Output Class Initialized
DEBUG - 2011-07-23 14:31:00 --> Input Class Initialized
DEBUG - 2011-07-23 14:31:00 --> Global POST and COOKIE data sanitized
DEBUG - 2011-07-23 14:31:00 --> Language Class Initialized
DEBUG - 2011-07-23 14:31:00 --> Loader Class Initialized
DEBUG - 2011-07-23 14:31:00 --> Controller Class Initialized
DEBUG - 2011-07-23 14:31:00 --> Model Class Initialized
DEBUG - 2011-07-23 14:31:00 --> Model Class Initialized
DEBUG - 2011-07-23 14:31:00 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-07-23 14:31:00 --> Database Driver Class Initialized
DEBUG - 2011-07-23 14:31:00 --> Config Class Initialized
DEBUG - 2011-07-23 14:31:00 --> Hooks Class Initialized
DEBUG - 2011-07-23 14:31:00 --> Utf8 Class Initialized
DEBUG - 2011-07-23 14:31:00 --> UTF-8 Support Enabled
DEBUG - 2011-07-23 14:31:00 --> URI Class Initialized
DEBUG - 2011-07-23 14:31:00 --> Router Class Initialized
DEBUG - 2011-07-23 14:31:00 --> Output Class Initialized
DEBUG - 2011-07-23 14:31:00 --> Input Class Initialized
DEBUG - 2011-07-23 14:31:00 --> Global POST and COOKIE data sanitized
DEBUG - 2011-07-23 14:31:00 --> Language Class Initialized
DEBUG - 2011-07-23 14:31:00 --> Loader Class Initialized
DEBUG - 2011-07-23 14:31:00 --> Controller Class Initialized
ERROR - 2011-07-23 14:31:00 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-07-23 14:31:00 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-07-23 14:31:00 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-07-23 14:31:00 --> Model Class Initialized
DEBUG - 2011-07-23 14:31:00 --> Model Class Initialized
DEBUG - 2011-07-23 14:31:00 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-07-23 14:31:00 --> Database Driver Class Initialized
DEBUG - 2011-07-23 14:31:00 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-07-23 14:31:00 --> Helper loaded: url_helper
DEBUG - 2011-07-23 14:31:00 --> File loaded: application/views/common/header.php
DEBUG - 2011-07-23 14:31:00 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-07-23 14:31:00 --> File loaded: application/views/common/footer.php
DEBUG - 2011-07-23 14:31:00 --> File loaded: application/views/layout/main.php
DEBUG - 2011-07-23 14:31:00 --> Final output sent to browser
DEBUG - 2011-07-23 14:31:00 --> Total execution time: 0.0297
DEBUG - 2011-07-23 14:31:00 --> Final output sent to browser
DEBUG - 2011-07-23 14:31:00 --> Total execution time: 0.5470
DEBUG - 2011-07-23 14:31:02 --> Config Class Initialized
DEBUG - 2011-07-23 14:31:02 --> Hooks Class Initialized
DEBUG - 2011-07-23 14:31:02 --> Utf8 Class Initialized
DEBUG - 2011-07-23 14:31:02 --> UTF-8 Support Enabled
DEBUG - 2011-07-23 14:31:02 --> URI Class Initialized
DEBUG - 2011-07-23 14:31:02 --> Router Class Initialized
ERROR - 2011-07-23 14:31:02 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-07-23 14:33:34 --> Config Class Initialized
DEBUG - 2011-07-23 14:33:34 --> Hooks Class Initialized
DEBUG - 2011-07-23 14:33:34 --> Utf8 Class Initialized
DEBUG - 2011-07-23 14:33:34 --> UTF-8 Support Enabled
DEBUG - 2011-07-23 14:33:34 --> URI Class Initialized
DEBUG - 2011-07-23 14:33:34 --> Router Class Initialized
DEBUG - 2011-07-23 14:33:34 --> Output Class Initialized
DEBUG - 2011-07-23 14:33:34 --> Input Class Initialized
DEBUG - 2011-07-23 14:33:34 --> Global POST and COOKIE data sanitized
DEBUG - 2011-07-23 14:33:34 --> Language Class Initialized
DEBUG - 2011-07-23 14:33:34 --> Loader Class Initialized
DEBUG - 2011-07-23 14:33:34 --> Controller Class Initialized
ERROR - 2011-07-23 14:33:34 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-07-23 14:33:34 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-07-23 14:33:34 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-07-23 14:33:34 --> Model Class Initialized
DEBUG - 2011-07-23 14:33:34 --> Model Class Initialized
DEBUG - 2011-07-23 14:33:34 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-07-23 14:33:34 --> Database Driver Class Initialized
DEBUG - 2011-07-23 14:33:34 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-07-23 14:33:34 --> Helper loaded: url_helper
DEBUG - 2011-07-23 14:33:34 --> File loaded: application/views/common/header.php
DEBUG - 2011-07-23 14:33:34 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-07-23 14:33:34 --> File loaded: application/views/common/footer.php
DEBUG - 2011-07-23 14:33:34 --> File loaded: application/views/layout/main.php
DEBUG - 2011-07-23 14:33:34 --> Final output sent to browser
DEBUG - 2011-07-23 14:33:34 --> Total execution time: 0.0340
DEBUG - 2011-07-23 14:33:35 --> Config Class Initialized
DEBUG - 2011-07-23 14:33:35 --> Hooks Class Initialized
DEBUG - 2011-07-23 14:33:35 --> Utf8 Class Initialized
DEBUG - 2011-07-23 14:33:35 --> UTF-8 Support Enabled
DEBUG - 2011-07-23 14:33:35 --> URI Class Initialized
DEBUG - 2011-07-23 14:33:35 --> Router Class Initialized
DEBUG - 2011-07-23 14:33:35 --> Output Class Initialized
DEBUG - 2011-07-23 14:33:35 --> Input Class Initialized
DEBUG - 2011-07-23 14:33:35 --> Global POST and COOKIE data sanitized
DEBUG - 2011-07-23 14:33:35 --> Language Class Initialized
DEBUG - 2011-07-23 14:33:35 --> Loader Class Initialized
DEBUG - 2011-07-23 14:33:35 --> Controller Class Initialized
DEBUG - 2011-07-23 14:33:35 --> Model Class Initialized
DEBUG - 2011-07-23 14:33:35 --> Config Class Initialized
DEBUG - 2011-07-23 14:33:35 --> Hooks Class Initialized
DEBUG - 2011-07-23 14:33:35 --> Utf8 Class Initialized
DEBUG - 2011-07-23 14:33:35 --> UTF-8 Support Enabled
DEBUG - 2011-07-23 14:33:35 --> Model Class Initialized
DEBUG - 2011-07-23 14:33:35 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-07-23 14:33:35 --> URI Class Initialized
DEBUG - 2011-07-23 14:33:35 --> Router Class Initialized
DEBUG - 2011-07-23 14:33:35 --> Output Class Initialized
DEBUG - 2011-07-23 14:33:35 --> Input Class Initialized
DEBUG - 2011-07-23 14:33:35 --> Global POST and COOKIE data sanitized
DEBUG - 2011-07-23 14:33:35 --> Language Class Initialized
DEBUG - 2011-07-23 14:33:35 --> Loader Class Initialized
DEBUG - 2011-07-23 14:33:35 --> Controller Class Initialized
ERROR - 2011-07-23 14:33:35 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-07-23 14:33:35 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-07-23 14:33:35 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-07-23 14:33:35 --> Model Class Initialized
DEBUG - 2011-07-23 14:33:35 --> Model Class Initialized
DEBUG - 2011-07-23 14:33:35 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-07-23 14:33:35 --> Database Driver Class Initialized
DEBUG - 2011-07-23 14:33:35 --> Database Driver Class Initialized
DEBUG - 2011-07-23 14:33:35 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-07-23 14:33:35 --> Helper loaded: url_helper
DEBUG - 2011-07-23 14:33:35 --> File loaded: application/views/common/header.php
DEBUG - 2011-07-23 14:33:35 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-07-23 14:33:35 --> File loaded: application/views/common/footer.php
DEBUG - 2011-07-23 14:33:35 --> File loaded: application/views/layout/main.php
DEBUG - 2011-07-23 14:33:35 --> Final output sent to browser
DEBUG - 2011-07-23 14:33:35 --> Total execution time: 0.0656
DEBUG - 2011-07-23 14:33:35 --> Config Class Initialized
DEBUG - 2011-07-23 14:33:35 --> Hooks Class Initialized
DEBUG - 2011-07-23 14:33:35 --> Utf8 Class Initialized
DEBUG - 2011-07-23 14:33:35 --> UTF-8 Support Enabled
DEBUG - 2011-07-23 14:33:35 --> URI Class Initialized
DEBUG - 2011-07-23 14:33:35 --> Router Class Initialized
DEBUG - 2011-07-23 14:33:35 --> Output Class Initialized
DEBUG - 2011-07-23 14:33:35 --> Input Class Initialized
DEBUG - 2011-07-23 14:33:35 --> Global POST and COOKIE data sanitized
DEBUG - 2011-07-23 14:33:35 --> Language Class Initialized
DEBUG - 2011-07-23 14:33:35 --> Loader Class Initialized
DEBUG - 2011-07-23 14:33:35 --> Controller Class Initialized
ERROR - 2011-07-23 14:33:35 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-07-23 14:33:35 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-07-23 14:33:35 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-07-23 14:33:35 --> Model Class Initialized
DEBUG - 2011-07-23 14:33:35 --> Model Class Initialized
DEBUG - 2011-07-23 14:33:35 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-07-23 14:33:35 --> Database Driver Class Initialized
DEBUG - 2011-07-23 14:33:35 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-07-23 14:33:35 --> Helper loaded: url_helper
DEBUG - 2011-07-23 14:33:35 --> File loaded: application/views/common/header.php
DEBUG - 2011-07-23 14:33:35 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-07-23 14:33:35 --> File loaded: application/views/common/footer.php
DEBUG - 2011-07-23 14:33:35 --> File loaded: application/views/layout/main.php
DEBUG - 2011-07-23 14:33:35 --> Final output sent to browser
DEBUG - 2011-07-23 14:33:35 --> Total execution time: 0.0332
DEBUG - 2011-07-23 14:33:35 --> Final output sent to browser
DEBUG - 2011-07-23 14:33:35 --> Total execution time: 0.7806
DEBUG - 2011-07-23 14:33:36 --> Config Class Initialized
DEBUG - 2011-07-23 14:33:36 --> Hooks Class Initialized
DEBUG - 2011-07-23 14:33:36 --> Utf8 Class Initialized
DEBUG - 2011-07-23 14:33:36 --> UTF-8 Support Enabled
DEBUG - 2011-07-23 14:33:36 --> URI Class Initialized
DEBUG - 2011-07-23 14:33:36 --> Router Class Initialized
ERROR - 2011-07-23 14:33:36 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-07-23 14:53:41 --> Config Class Initialized
DEBUG - 2011-07-23 14:53:41 --> Hooks Class Initialized
DEBUG - 2011-07-23 14:53:41 --> Utf8 Class Initialized
DEBUG - 2011-07-23 14:53:41 --> UTF-8 Support Enabled
DEBUG - 2011-07-23 14:53:41 --> URI Class Initialized
DEBUG - 2011-07-23 14:53:41 --> Router Class Initialized
DEBUG - 2011-07-23 14:53:41 --> Output Class Initialized
DEBUG - 2011-07-23 14:53:41 --> Input Class Initialized
DEBUG - 2011-07-23 14:53:41 --> Global POST and COOKIE data sanitized
DEBUG - 2011-07-23 14:53:41 --> Language Class Initialized
DEBUG - 2011-07-23 14:53:41 --> Loader Class Initialized
DEBUG - 2011-07-23 14:53:41 --> Controller Class Initialized
DEBUG - 2011-07-23 14:53:41 --> Model Class Initialized
DEBUG - 2011-07-23 14:53:41 --> Model Class Initialized
DEBUG - 2011-07-23 14:53:41 --> Model Class Initialized
DEBUG - 2011-07-23 14:53:41 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-07-23 14:53:41 --> Database Driver Class Initialized
DEBUG - 2011-07-23 14:53:41 --> File loaded: application/views/table/main.php
DEBUG - 2011-07-23 14:53:41 --> Helper loaded: url_helper
DEBUG - 2011-07-23 14:53:41 --> File loaded: application/views/common/header.php
DEBUG - 2011-07-23 14:53:41 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-07-23 14:53:41 --> File loaded: application/views/common/footer.php
DEBUG - 2011-07-23 14:53:41 --> File loaded: application/views/layout/main.php
DEBUG - 2011-07-23 14:53:41 --> Final output sent to browser
DEBUG - 2011-07-23 14:53:41 --> Total execution time: 0.3473
DEBUG - 2011-07-23 15:44:11 --> Config Class Initialized
DEBUG - 2011-07-23 15:44:11 --> Hooks Class Initialized
DEBUG - 2011-07-23 15:44:11 --> Utf8 Class Initialized
DEBUG - 2011-07-23 15:44:11 --> UTF-8 Support Enabled
DEBUG - 2011-07-23 15:44:11 --> URI Class Initialized
DEBUG - 2011-07-23 15:44:11 --> Router Class Initialized
DEBUG - 2011-07-23 15:44:11 --> Output Class Initialized
DEBUG - 2011-07-23 15:44:11 --> Input Class Initialized
DEBUG - 2011-07-23 15:44:11 --> Global POST and COOKIE data sanitized
DEBUG - 2011-07-23 15:44:11 --> Language Class Initialized
DEBUG - 2011-07-23 15:44:11 --> Loader Class Initialized
DEBUG - 2011-07-23 15:44:11 --> Controller Class Initialized
ERROR - 2011-07-23 15:44:11 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-07-23 15:44:11 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-07-23 15:44:11 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-07-23 15:44:11 --> Model Class Initialized
DEBUG - 2011-07-23 15:44:11 --> Model Class Initialized
DEBUG - 2011-07-23 15:44:11 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-07-23 15:44:11 --> Database Driver Class Initialized
DEBUG - 2011-07-23 15:44:11 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-07-23 15:44:11 --> Helper loaded: url_helper
DEBUG - 2011-07-23 15:44:11 --> File loaded: application/views/common/header.php
DEBUG - 2011-07-23 15:44:11 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-07-23 15:44:12 --> File loaded: application/views/common/footer.php
DEBUG - 2011-07-23 15:44:12 --> File loaded: application/views/layout/main.php
DEBUG - 2011-07-23 15:44:12 --> Final output sent to browser
DEBUG - 2011-07-23 15:44:12 --> Total execution time: 0.3130
DEBUG - 2011-07-23 15:44:15 --> Config Class Initialized
DEBUG - 2011-07-23 15:44:15 --> Hooks Class Initialized
DEBUG - 2011-07-23 15:44:15 --> Utf8 Class Initialized
DEBUG - 2011-07-23 15:44:15 --> UTF-8 Support Enabled
DEBUG - 2011-07-23 15:44:15 --> URI Class Initialized
DEBUG - 2011-07-23 15:44:15 --> Router Class Initialized
DEBUG - 2011-07-23 15:44:15 --> Output Class Initialized
DEBUG - 2011-07-23 15:44:15 --> Input Class Initialized
DEBUG - 2011-07-23 15:44:15 --> Global POST and COOKIE data sanitized
DEBUG - 2011-07-23 15:44:15 --> Language Class Initialized
DEBUG - 2011-07-23 15:44:15 --> Loader Class Initialized
DEBUG - 2011-07-23 15:44:15 --> Controller Class Initialized
DEBUG - 2011-07-23 15:44:15 --> Model Class Initialized
DEBUG - 2011-07-23 15:44:15 --> Model Class Initialized
DEBUG - 2011-07-23 15:44:15 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-07-23 15:44:15 --> Database Driver Class Initialized
DEBUG - 2011-07-23 15:44:16 --> Final output sent to browser
DEBUG - 2011-07-23 15:44:16 --> Total execution time: 0.8147
DEBUG - 2011-07-23 15:44:18 --> Config Class Initialized
DEBUG - 2011-07-23 15:44:18 --> Hooks Class Initialized
DEBUG - 2011-07-23 15:44:18 --> Utf8 Class Initialized
DEBUG - 2011-07-23 15:44:18 --> UTF-8 Support Enabled
DEBUG - 2011-07-23 15:44:18 --> URI Class Initialized
DEBUG - 2011-07-23 15:44:18 --> Router Class Initialized
ERROR - 2011-07-23 15:44:18 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-07-23 15:44:19 --> Config Class Initialized
DEBUG - 2011-07-23 15:44:19 --> Hooks Class Initialized
DEBUG - 2011-07-23 15:44:19 --> Utf8 Class Initialized
DEBUG - 2011-07-23 15:44:19 --> UTF-8 Support Enabled
DEBUG - 2011-07-23 15:44:19 --> URI Class Initialized
DEBUG - 2011-07-23 15:44:19 --> Router Class Initialized
ERROR - 2011-07-23 15:44:19 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-07-23 15:44:45 --> Config Class Initialized
DEBUG - 2011-07-23 15:44:45 --> Hooks Class Initialized
DEBUG - 2011-07-23 15:44:45 --> Utf8 Class Initialized
DEBUG - 2011-07-23 15:44:45 --> UTF-8 Support Enabled
DEBUG - 2011-07-23 15:44:45 --> URI Class Initialized
DEBUG - 2011-07-23 15:44:45 --> Router Class Initialized
DEBUG - 2011-07-23 15:44:45 --> Output Class Initialized
DEBUG - 2011-07-23 15:44:45 --> Input Class Initialized
DEBUG - 2011-07-23 15:44:45 --> Global POST and COOKIE data sanitized
DEBUG - 2011-07-23 15:44:45 --> Language Class Initialized
DEBUG - 2011-07-23 15:44:45 --> Loader Class Initialized
DEBUG - 2011-07-23 15:44:45 --> Controller Class Initialized
ERROR - 2011-07-23 15:44:45 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-07-23 15:44:45 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-07-23 15:44:45 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-07-23 15:44:45 --> Model Class Initialized
DEBUG - 2011-07-23 15:44:45 --> Model Class Initialized
DEBUG - 2011-07-23 15:44:45 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-07-23 15:44:45 --> Database Driver Class Initialized
DEBUG - 2011-07-23 15:44:45 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-07-23 15:44:45 --> Helper loaded: url_helper
DEBUG - 2011-07-23 15:44:45 --> File loaded: application/views/common/header.php
DEBUG - 2011-07-23 15:44:45 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-07-23 15:44:45 --> File loaded: application/views/common/footer.php
DEBUG - 2011-07-23 15:44:45 --> File loaded: application/views/layout/main.php
DEBUG - 2011-07-23 15:44:45 --> Final output sent to browser
DEBUG - 2011-07-23 15:44:45 --> Total execution time: 0.0286
DEBUG - 2011-07-23 15:44:46 --> Config Class Initialized
DEBUG - 2011-07-23 15:44:46 --> Hooks Class Initialized
DEBUG - 2011-07-23 15:44:46 --> Utf8 Class Initialized
DEBUG - 2011-07-23 15:44:46 --> UTF-8 Support Enabled
DEBUG - 2011-07-23 15:44:46 --> URI Class Initialized
DEBUG - 2011-07-23 15:44:46 --> Router Class Initialized
DEBUG - 2011-07-23 15:44:46 --> Output Class Initialized
DEBUG - 2011-07-23 15:44:46 --> Input Class Initialized
DEBUG - 2011-07-23 15:44:46 --> Global POST and COOKIE data sanitized
DEBUG - 2011-07-23 15:44:46 --> Language Class Initialized
DEBUG - 2011-07-23 15:44:46 --> Loader Class Initialized
DEBUG - 2011-07-23 15:44:46 --> Controller Class Initialized
DEBUG - 2011-07-23 15:44:46 --> Model Class Initialized
DEBUG - 2011-07-23 15:44:46 --> Model Class Initialized
DEBUG - 2011-07-23 15:44:46 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-07-23 15:44:46 --> Database Driver Class Initialized
DEBUG - 2011-07-23 15:44:47 --> Final output sent to browser
DEBUG - 2011-07-23 15:44:47 --> Total execution time: 0.5937
DEBUG - 2011-07-23 15:44:48 --> Config Class Initialized
DEBUG - 2011-07-23 15:44:48 --> Hooks Class Initialized
DEBUG - 2011-07-23 15:44:48 --> Utf8 Class Initialized
DEBUG - 2011-07-23 15:44:48 --> UTF-8 Support Enabled
DEBUG - 2011-07-23 15:44:48 --> URI Class Initialized
DEBUG - 2011-07-23 15:44:48 --> Router Class Initialized
ERROR - 2011-07-23 15:44:48 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-07-23 15:44:55 --> Config Class Initialized
DEBUG - 2011-07-23 15:44:55 --> Hooks Class Initialized
DEBUG - 2011-07-23 15:44:55 --> Utf8 Class Initialized
DEBUG - 2011-07-23 15:44:55 --> UTF-8 Support Enabled
DEBUG - 2011-07-23 15:44:55 --> URI Class Initialized
DEBUG - 2011-07-23 15:44:55 --> Router Class Initialized
DEBUG - 2011-07-23 15:44:55 --> Output Class Initialized
DEBUG - 2011-07-23 15:44:55 --> Input Class Initialized
DEBUG - 2011-07-23 15:44:55 --> Global POST and COOKIE data sanitized
DEBUG - 2011-07-23 15:44:55 --> Language Class Initialized
DEBUG - 2011-07-23 15:44:55 --> Loader Class Initialized
DEBUG - 2011-07-23 15:44:55 --> Controller Class Initialized
ERROR - 2011-07-23 15:44:55 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-07-23 15:44:55 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-07-23 15:44:55 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-07-23 15:44:55 --> Model Class Initialized
DEBUG - 2011-07-23 15:44:55 --> Model Class Initialized
DEBUG - 2011-07-23 15:44:55 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-07-23 15:44:55 --> Database Driver Class Initialized
DEBUG - 2011-07-23 15:44:55 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-07-23 15:44:55 --> Helper loaded: url_helper
DEBUG - 2011-07-23 15:44:55 --> File loaded: application/views/common/header.php
DEBUG - 2011-07-23 15:44:55 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-07-23 15:44:55 --> File loaded: application/views/common/footer.php
DEBUG - 2011-07-23 15:44:55 --> File loaded: application/views/layout/main.php
DEBUG - 2011-07-23 15:44:55 --> Final output sent to browser
DEBUG - 2011-07-23 15:44:55 --> Total execution time: 0.0288
DEBUG - 2011-07-23 15:44:56 --> Config Class Initialized
DEBUG - 2011-07-23 15:44:56 --> Hooks Class Initialized
DEBUG - 2011-07-23 15:44:56 --> Utf8 Class Initialized
DEBUG - 2011-07-23 15:44:56 --> UTF-8 Support Enabled
DEBUG - 2011-07-23 15:44:56 --> URI Class Initialized
DEBUG - 2011-07-23 15:44:56 --> Router Class Initialized
DEBUG - 2011-07-23 15:44:56 --> Output Class Initialized
DEBUG - 2011-07-23 15:44:56 --> Input Class Initialized
DEBUG - 2011-07-23 15:44:56 --> Global POST and COOKIE data sanitized
DEBUG - 2011-07-23 15:44:56 --> Language Class Initialized
DEBUG - 2011-07-23 15:44:56 --> Loader Class Initialized
DEBUG - 2011-07-23 15:44:56 --> Controller Class Initialized
DEBUG - 2011-07-23 15:44:56 --> Model Class Initialized
DEBUG - 2011-07-23 15:44:56 --> Model Class Initialized
DEBUG - 2011-07-23 15:44:56 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-07-23 15:44:56 --> Database Driver Class Initialized
DEBUG - 2011-07-23 15:44:57 --> Final output sent to browser
DEBUG - 2011-07-23 15:44:57 --> Total execution time: 0.5380
DEBUG - 2011-07-23 15:44:58 --> Config Class Initialized
DEBUG - 2011-07-23 15:44:58 --> Hooks Class Initialized
DEBUG - 2011-07-23 15:44:58 --> Utf8 Class Initialized
DEBUG - 2011-07-23 15:44:58 --> UTF-8 Support Enabled
DEBUG - 2011-07-23 15:44:58 --> URI Class Initialized
DEBUG - 2011-07-23 15:44:58 --> Router Class Initialized
ERROR - 2011-07-23 15:44:58 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-07-23 15:44:59 --> Config Class Initialized
DEBUG - 2011-07-23 15:44:59 --> Hooks Class Initialized
DEBUG - 2011-07-23 15:44:59 --> Utf8 Class Initialized
DEBUG - 2011-07-23 15:44:59 --> UTF-8 Support Enabled
DEBUG - 2011-07-23 15:44:59 --> URI Class Initialized
DEBUG - 2011-07-23 15:44:59 --> Router Class Initialized
ERROR - 2011-07-23 15:44:59 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-07-23 15:45:08 --> Config Class Initialized
DEBUG - 2011-07-23 15:45:08 --> Hooks Class Initialized
DEBUG - 2011-07-23 15:45:08 --> Utf8 Class Initialized
DEBUG - 2011-07-23 15:45:08 --> UTF-8 Support Enabled
DEBUG - 2011-07-23 15:45:08 --> URI Class Initialized
DEBUG - 2011-07-23 15:45:08 --> Router Class Initialized
DEBUG - 2011-07-23 15:45:08 --> Output Class Initialized
DEBUG - 2011-07-23 15:45:08 --> Input Class Initialized
DEBUG - 2011-07-23 15:45:08 --> Global POST and COOKIE data sanitized
DEBUG - 2011-07-23 15:45:08 --> Language Class Initialized
DEBUG - 2011-07-23 15:45:08 --> Loader Class Initialized
DEBUG - 2011-07-23 15:45:08 --> Controller Class Initialized
ERROR - 2011-07-23 15:45:08 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-07-23 15:45:08 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-07-23 15:45:08 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-07-23 15:45:08 --> Model Class Initialized
DEBUG - 2011-07-23 15:45:08 --> Model Class Initialized
DEBUG - 2011-07-23 15:45:08 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-07-23 15:45:08 --> Database Driver Class Initialized
DEBUG - 2011-07-23 15:45:08 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-07-23 15:45:08 --> Helper loaded: url_helper
DEBUG - 2011-07-23 15:45:08 --> File loaded: application/views/common/header.php
DEBUG - 2011-07-23 15:45:08 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-07-23 15:45:08 --> File loaded: application/views/common/footer.php
DEBUG - 2011-07-23 15:45:08 --> File loaded: application/views/layout/main.php
DEBUG - 2011-07-23 15:45:08 --> Final output sent to browser
DEBUG - 2011-07-23 15:45:08 --> Total execution time: 0.0318
DEBUG - 2011-07-23 15:45:10 --> Config Class Initialized
DEBUG - 2011-07-23 15:45:10 --> Hooks Class Initialized
DEBUG - 2011-07-23 15:45:10 --> Utf8 Class Initialized
DEBUG - 2011-07-23 15:45:10 --> UTF-8 Support Enabled
DEBUG - 2011-07-23 15:45:10 --> URI Class Initialized
DEBUG - 2011-07-23 15:45:10 --> Router Class Initialized
DEBUG - 2011-07-23 15:45:10 --> Output Class Initialized
DEBUG - 2011-07-23 15:45:10 --> Input Class Initialized
DEBUG - 2011-07-23 15:45:10 --> Global POST and COOKIE data sanitized
DEBUG - 2011-07-23 15:45:10 --> Language Class Initialized
DEBUG - 2011-07-23 15:45:10 --> Loader Class Initialized
DEBUG - 2011-07-23 15:45:10 --> Controller Class Initialized
DEBUG - 2011-07-23 15:45:10 --> Model Class Initialized
DEBUG - 2011-07-23 15:45:10 --> Model Class Initialized
DEBUG - 2011-07-23 15:45:10 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-07-23 15:45:10 --> Database Driver Class Initialized
DEBUG - 2011-07-23 15:45:10 --> Final output sent to browser
DEBUG - 2011-07-23 15:45:10 --> Total execution time: 0.5167
DEBUG - 2011-07-23 15:45:11 --> Config Class Initialized
DEBUG - 2011-07-23 15:45:11 --> Hooks Class Initialized
DEBUG - 2011-07-23 15:45:11 --> Utf8 Class Initialized
DEBUG - 2011-07-23 15:45:11 --> UTF-8 Support Enabled
DEBUG - 2011-07-23 15:45:11 --> URI Class Initialized
DEBUG - 2011-07-23 15:45:11 --> Router Class Initialized
ERROR - 2011-07-23 15:45:11 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-07-23 15:45:12 --> Config Class Initialized
DEBUG - 2011-07-23 15:45:12 --> Hooks Class Initialized
DEBUG - 2011-07-23 15:45:12 --> Utf8 Class Initialized
DEBUG - 2011-07-23 15:45:12 --> UTF-8 Support Enabled
DEBUG - 2011-07-23 15:45:12 --> URI Class Initialized
DEBUG - 2011-07-23 15:45:12 --> Router Class Initialized
ERROR - 2011-07-23 15:45:12 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-07-23 15:45:30 --> Config Class Initialized
DEBUG - 2011-07-23 15:45:30 --> Hooks Class Initialized
DEBUG - 2011-07-23 15:45:30 --> Utf8 Class Initialized
DEBUG - 2011-07-23 15:45:30 --> UTF-8 Support Enabled
DEBUG - 2011-07-23 15:45:30 --> URI Class Initialized
DEBUG - 2011-07-23 15:45:30 --> Router Class Initialized
DEBUG - 2011-07-23 15:45:30 --> Output Class Initialized
DEBUG - 2011-07-23 15:45:30 --> Input Class Initialized
DEBUG - 2011-07-23 15:45:30 --> Global POST and COOKIE data sanitized
DEBUG - 2011-07-23 15:45:30 --> Language Class Initialized
DEBUG - 2011-07-23 15:45:30 --> Loader Class Initialized
DEBUG - 2011-07-23 15:45:30 --> Controller Class Initialized
ERROR - 2011-07-23 15:45:30 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-07-23 15:45:30 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-07-23 15:45:30 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-07-23 15:45:30 --> Model Class Initialized
DEBUG - 2011-07-23 15:45:30 --> Model Class Initialized
DEBUG - 2011-07-23 15:45:30 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-07-23 15:45:30 --> Database Driver Class Initialized
DEBUG - 2011-07-23 15:45:30 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-07-23 15:45:30 --> Helper loaded: url_helper
DEBUG - 2011-07-23 15:45:30 --> File loaded: application/views/common/header.php
DEBUG - 2011-07-23 15:45:30 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-07-23 15:45:30 --> File loaded: application/views/common/footer.php
DEBUG - 2011-07-23 15:45:30 --> File loaded: application/views/layout/main.php
DEBUG - 2011-07-23 15:45:30 --> Final output sent to browser
DEBUG - 2011-07-23 15:45:30 --> Total execution time: 0.0549
DEBUG - 2011-07-23 15:45:31 --> Config Class Initialized
DEBUG - 2011-07-23 15:45:31 --> Hooks Class Initialized
DEBUG - 2011-07-23 15:45:31 --> Utf8 Class Initialized
DEBUG - 2011-07-23 15:45:31 --> UTF-8 Support Enabled
DEBUG - 2011-07-23 15:45:31 --> URI Class Initialized
DEBUG - 2011-07-23 15:45:31 --> Router Class Initialized
DEBUG - 2011-07-23 15:45:31 --> Output Class Initialized
DEBUG - 2011-07-23 15:45:31 --> Input Class Initialized
DEBUG - 2011-07-23 15:45:31 --> Global POST and COOKIE data sanitized
DEBUG - 2011-07-23 15:45:31 --> Language Class Initialized
DEBUG - 2011-07-23 15:45:31 --> Loader Class Initialized
DEBUG - 2011-07-23 15:45:31 --> Controller Class Initialized
DEBUG - 2011-07-23 15:45:31 --> Model Class Initialized
DEBUG - 2011-07-23 15:45:31 --> Model Class Initialized
DEBUG - 2011-07-23 15:45:31 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-07-23 15:45:31 --> Database Driver Class Initialized
DEBUG - 2011-07-23 15:45:32 --> Final output sent to browser
DEBUG - 2011-07-23 15:45:32 --> Total execution time: 0.7523
DEBUG - 2011-07-23 15:45:33 --> Config Class Initialized
DEBUG - 2011-07-23 15:45:33 --> Hooks Class Initialized
DEBUG - 2011-07-23 15:45:33 --> Utf8 Class Initialized
DEBUG - 2011-07-23 15:45:33 --> UTF-8 Support Enabled
DEBUG - 2011-07-23 15:45:33 --> URI Class Initialized
DEBUG - 2011-07-23 15:45:33 --> Router Class Initialized
ERROR - 2011-07-23 15:45:33 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-07-23 15:45:43 --> Config Class Initialized
DEBUG - 2011-07-23 15:45:43 --> Hooks Class Initialized
DEBUG - 2011-07-23 15:45:43 --> Utf8 Class Initialized
DEBUG - 2011-07-23 15:45:43 --> UTF-8 Support Enabled
DEBUG - 2011-07-23 15:45:43 --> URI Class Initialized
DEBUG - 2011-07-23 15:45:43 --> Router Class Initialized
DEBUG - 2011-07-23 15:45:43 --> Output Class Initialized
DEBUG - 2011-07-23 15:45:43 --> Input Class Initialized
DEBUG - 2011-07-23 15:45:43 --> Global POST and COOKIE data sanitized
DEBUG - 2011-07-23 15:45:43 --> Language Class Initialized
DEBUG - 2011-07-23 15:45:43 --> Loader Class Initialized
DEBUG - 2011-07-23 15:45:43 --> Controller Class Initialized
ERROR - 2011-07-23 15:45:43 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-07-23 15:45:43 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-07-23 15:45:43 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-07-23 15:45:43 --> Model Class Initialized
DEBUG - 2011-07-23 15:45:43 --> Model Class Initialized
DEBUG - 2011-07-23 15:45:43 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-07-23 15:45:43 --> Database Driver Class Initialized
DEBUG - 2011-07-23 15:45:43 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-07-23 15:45:43 --> Helper loaded: url_helper
DEBUG - 2011-07-23 15:45:43 --> File loaded: application/views/common/header.php
DEBUG - 2011-07-23 15:45:43 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-07-23 15:45:43 --> File loaded: application/views/common/footer.php
DEBUG - 2011-07-23 15:45:43 --> File loaded: application/views/layout/main.php
DEBUG - 2011-07-23 15:45:43 --> Final output sent to browser
DEBUG - 2011-07-23 15:45:43 --> Total execution time: 0.0332
DEBUG - 2011-07-23 15:45:44 --> Config Class Initialized
DEBUG - 2011-07-23 15:45:44 --> Hooks Class Initialized
DEBUG - 2011-07-23 15:45:44 --> Utf8 Class Initialized
DEBUG - 2011-07-23 15:45:44 --> UTF-8 Support Enabled
DEBUG - 2011-07-23 15:45:44 --> URI Class Initialized
DEBUG - 2011-07-23 15:45:44 --> Router Class Initialized
DEBUG - 2011-07-23 15:45:44 --> Output Class Initialized
DEBUG - 2011-07-23 15:45:44 --> Input Class Initialized
DEBUG - 2011-07-23 15:45:44 --> Global POST and COOKIE data sanitized
DEBUG - 2011-07-23 15:45:44 --> Language Class Initialized
DEBUG - 2011-07-23 15:45:44 --> Loader Class Initialized
DEBUG - 2011-07-23 15:45:44 --> Controller Class Initialized
DEBUG - 2011-07-23 15:45:44 --> Model Class Initialized
DEBUG - 2011-07-23 15:45:44 --> Model Class Initialized
DEBUG - 2011-07-23 15:45:44 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-07-23 15:45:44 --> Database Driver Class Initialized
DEBUG - 2011-07-23 15:45:45 --> Final output sent to browser
DEBUG - 2011-07-23 15:45:45 --> Total execution time: 0.5876
DEBUG - 2011-07-23 15:45:46 --> Config Class Initialized
DEBUG - 2011-07-23 15:45:46 --> Hooks Class Initialized
DEBUG - 2011-07-23 15:45:46 --> Utf8 Class Initialized
DEBUG - 2011-07-23 15:45:46 --> UTF-8 Support Enabled
DEBUG - 2011-07-23 15:45:46 --> URI Class Initialized
DEBUG - 2011-07-23 15:45:46 --> Router Class Initialized
ERROR - 2011-07-23 15:45:46 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-07-23 15:45:59 --> Config Class Initialized
DEBUG - 2011-07-23 15:45:59 --> Hooks Class Initialized
DEBUG - 2011-07-23 15:45:59 --> Utf8 Class Initialized
DEBUG - 2011-07-23 15:45:59 --> UTF-8 Support Enabled
DEBUG - 2011-07-23 15:45:59 --> URI Class Initialized
DEBUG - 2011-07-23 15:45:59 --> Router Class Initialized
DEBUG - 2011-07-23 15:45:59 --> Output Class Initialized
DEBUG - 2011-07-23 15:45:59 --> Input Class Initialized
DEBUG - 2011-07-23 15:45:59 --> Global POST and COOKIE data sanitized
DEBUG - 2011-07-23 15:45:59 --> Language Class Initialized
DEBUG - 2011-07-23 15:45:59 --> Loader Class Initialized
DEBUG - 2011-07-23 15:45:59 --> Controller Class Initialized
ERROR - 2011-07-23 15:45:59 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-07-23 15:45:59 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-07-23 15:45:59 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-07-23 15:45:59 --> Model Class Initialized
DEBUG - 2011-07-23 15:45:59 --> Model Class Initialized
DEBUG - 2011-07-23 15:45:59 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-07-23 15:45:59 --> Database Driver Class Initialized
DEBUG - 2011-07-23 15:45:59 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-07-23 15:45:59 --> Helper loaded: url_helper
DEBUG - 2011-07-23 15:45:59 --> File loaded: application/views/common/header.php
DEBUG - 2011-07-23 15:45:59 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-07-23 15:45:59 --> File loaded: application/views/common/footer.php
DEBUG - 2011-07-23 15:45:59 --> File loaded: application/views/layout/main.php
DEBUG - 2011-07-23 15:45:59 --> Final output sent to browser
DEBUG - 2011-07-23 15:45:59 --> Total execution time: 0.0264
DEBUG - 2011-07-23 15:46:01 --> Config Class Initialized
DEBUG - 2011-07-23 15:46:01 --> Hooks Class Initialized
DEBUG - 2011-07-23 15:46:01 --> Utf8 Class Initialized
DEBUG - 2011-07-23 15:46:01 --> UTF-8 Support Enabled
DEBUG - 2011-07-23 15:46:01 --> URI Class Initialized
DEBUG - 2011-07-23 15:46:01 --> Router Class Initialized
DEBUG - 2011-07-23 15:46:01 --> Output Class Initialized
DEBUG - 2011-07-23 15:46:01 --> Input Class Initialized
DEBUG - 2011-07-23 15:46:01 --> Global POST and COOKIE data sanitized
DEBUG - 2011-07-23 15:46:01 --> Language Class Initialized
DEBUG - 2011-07-23 15:46:01 --> Loader Class Initialized
DEBUG - 2011-07-23 15:46:01 --> Controller Class Initialized
DEBUG - 2011-07-23 15:46:01 --> Model Class Initialized
DEBUG - 2011-07-23 15:46:01 --> Model Class Initialized
DEBUG - 2011-07-23 15:46:01 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-07-23 15:46:01 --> Database Driver Class Initialized
DEBUG - 2011-07-23 15:46:01 --> Final output sent to browser
DEBUG - 2011-07-23 15:46:01 --> Total execution time: 0.5604
DEBUG - 2011-07-23 15:46:03 --> Config Class Initialized
DEBUG - 2011-07-23 15:46:03 --> Hooks Class Initialized
DEBUG - 2011-07-23 15:46:03 --> Utf8 Class Initialized
DEBUG - 2011-07-23 15:46:03 --> UTF-8 Support Enabled
DEBUG - 2011-07-23 15:46:03 --> URI Class Initialized
DEBUG - 2011-07-23 15:46:03 --> Router Class Initialized
ERROR - 2011-07-23 15:46:03 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-07-23 15:46:14 --> Config Class Initialized
DEBUG - 2011-07-23 15:46:14 --> Hooks Class Initialized
DEBUG - 2011-07-23 15:46:14 --> Utf8 Class Initialized
DEBUG - 2011-07-23 15:46:14 --> UTF-8 Support Enabled
DEBUG - 2011-07-23 15:46:14 --> URI Class Initialized
DEBUG - 2011-07-23 15:46:14 --> Router Class Initialized
DEBUG - 2011-07-23 15:46:14 --> Output Class Initialized
DEBUG - 2011-07-23 15:46:14 --> Input Class Initialized
DEBUG - 2011-07-23 15:46:14 --> Global POST and COOKIE data sanitized
DEBUG - 2011-07-23 15:46:14 --> Language Class Initialized
DEBUG - 2011-07-23 15:46:14 --> Loader Class Initialized
DEBUG - 2011-07-23 15:46:14 --> Controller Class Initialized
ERROR - 2011-07-23 15:46:14 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-07-23 15:46:14 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-07-23 15:46:14 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-07-23 15:46:14 --> Model Class Initialized
DEBUG - 2011-07-23 15:46:14 --> Model Class Initialized
DEBUG - 2011-07-23 15:46:14 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-07-23 15:46:14 --> Database Driver Class Initialized
DEBUG - 2011-07-23 15:46:14 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-07-23 15:46:14 --> Helper loaded: url_helper
DEBUG - 2011-07-23 15:46:14 --> File loaded: application/views/common/header.php
DEBUG - 2011-07-23 15:46:14 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-07-23 15:46:14 --> File loaded: application/views/common/footer.php
DEBUG - 2011-07-23 15:46:14 --> File loaded: application/views/layout/main.php
DEBUG - 2011-07-23 15:46:14 --> Final output sent to browser
DEBUG - 2011-07-23 15:46:14 --> Total execution time: 0.0273
DEBUG - 2011-07-23 15:46:16 --> Config Class Initialized
DEBUG - 2011-07-23 15:46:16 --> Hooks Class Initialized
DEBUG - 2011-07-23 15:46:16 --> Utf8 Class Initialized
DEBUG - 2011-07-23 15:46:16 --> UTF-8 Support Enabled
DEBUG - 2011-07-23 15:46:16 --> URI Class Initialized
DEBUG - 2011-07-23 15:46:16 --> Router Class Initialized
DEBUG - 2011-07-23 15:46:16 --> Output Class Initialized
DEBUG - 2011-07-23 15:46:16 --> Input Class Initialized
DEBUG - 2011-07-23 15:46:16 --> Global POST and COOKIE data sanitized
DEBUG - 2011-07-23 15:46:16 --> Language Class Initialized
DEBUG - 2011-07-23 15:46:16 --> Loader Class Initialized
DEBUG - 2011-07-23 15:46:16 --> Controller Class Initialized
DEBUG - 2011-07-23 15:46:16 --> Model Class Initialized
DEBUG - 2011-07-23 15:46:16 --> Model Class Initialized
DEBUG - 2011-07-23 15:46:16 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-07-23 15:46:16 --> Database Driver Class Initialized
DEBUG - 2011-07-23 15:46:16 --> Final output sent to browser
DEBUG - 2011-07-23 15:46:16 --> Total execution time: 0.5637
DEBUG - 2011-07-23 15:46:18 --> Config Class Initialized
DEBUG - 2011-07-23 15:46:18 --> Hooks Class Initialized
DEBUG - 2011-07-23 15:46:18 --> Utf8 Class Initialized
DEBUG - 2011-07-23 15:46:18 --> UTF-8 Support Enabled
DEBUG - 2011-07-23 15:46:18 --> URI Class Initialized
DEBUG - 2011-07-23 15:46:18 --> Router Class Initialized
ERROR - 2011-07-23 15:46:18 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-07-23 15:46:26 --> Config Class Initialized
DEBUG - 2011-07-23 15:46:26 --> Hooks Class Initialized
DEBUG - 2011-07-23 15:46:26 --> Utf8 Class Initialized
DEBUG - 2011-07-23 15:46:26 --> UTF-8 Support Enabled
DEBUG - 2011-07-23 15:46:26 --> URI Class Initialized
DEBUG - 2011-07-23 15:46:26 --> Router Class Initialized
DEBUG - 2011-07-23 15:46:26 --> Output Class Initialized
DEBUG - 2011-07-23 15:46:26 --> Input Class Initialized
DEBUG - 2011-07-23 15:46:26 --> Global POST and COOKIE data sanitized
DEBUG - 2011-07-23 15:46:26 --> Language Class Initialized
DEBUG - 2011-07-23 15:46:26 --> Loader Class Initialized
DEBUG - 2011-07-23 15:46:26 --> Controller Class Initialized
ERROR - 2011-07-23 15:46:26 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-07-23 15:46:26 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-07-23 15:46:26 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-07-23 15:46:26 --> Model Class Initialized
DEBUG - 2011-07-23 15:46:26 --> Model Class Initialized
DEBUG - 2011-07-23 15:46:26 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-07-23 15:46:26 --> Database Driver Class Initialized
DEBUG - 2011-07-23 15:46:26 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-07-23 15:46:26 --> Helper loaded: url_helper
DEBUG - 2011-07-23 15:46:26 --> File loaded: application/views/common/header.php
DEBUG - 2011-07-23 15:46:26 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-07-23 15:46:26 --> File loaded: application/views/common/footer.php
DEBUG - 2011-07-23 15:46:26 --> File loaded: application/views/layout/main.php
DEBUG - 2011-07-23 15:46:26 --> Final output sent to browser
DEBUG - 2011-07-23 15:46:26 --> Total execution time: 0.0286
DEBUG - 2011-07-23 15:46:27 --> Config Class Initialized
DEBUG - 2011-07-23 15:46:27 --> Hooks Class Initialized
DEBUG - 2011-07-23 15:46:27 --> Utf8 Class Initialized
DEBUG - 2011-07-23 15:46:27 --> UTF-8 Support Enabled
DEBUG - 2011-07-23 15:46:27 --> URI Class Initialized
DEBUG - 2011-07-23 15:46:27 --> Router Class Initialized
DEBUG - 2011-07-23 15:46:27 --> Output Class Initialized
DEBUG - 2011-07-23 15:46:27 --> Input Class Initialized
DEBUG - 2011-07-23 15:46:27 --> Global POST and COOKIE data sanitized
DEBUG - 2011-07-23 15:46:27 --> Language Class Initialized
DEBUG - 2011-07-23 15:46:27 --> Loader Class Initialized
DEBUG - 2011-07-23 15:46:27 --> Controller Class Initialized
DEBUG - 2011-07-23 15:46:27 --> Model Class Initialized
DEBUG - 2011-07-23 15:46:27 --> Model Class Initialized
DEBUG - 2011-07-23 15:46:27 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-07-23 15:46:27 --> Database Driver Class Initialized
DEBUG - 2011-07-23 15:46:28 --> Final output sent to browser
DEBUG - 2011-07-23 15:46:28 --> Total execution time: 0.5163
DEBUG - 2011-07-23 15:46:29 --> Config Class Initialized
DEBUG - 2011-07-23 15:46:29 --> Hooks Class Initialized
DEBUG - 2011-07-23 15:46:29 --> Utf8 Class Initialized
DEBUG - 2011-07-23 15:46:29 --> UTF-8 Support Enabled
DEBUG - 2011-07-23 15:46:29 --> URI Class Initialized
DEBUG - 2011-07-23 15:46:29 --> Router Class Initialized
ERROR - 2011-07-23 15:46:29 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-07-23 15:46:35 --> Config Class Initialized
DEBUG - 2011-07-23 15:46:35 --> Hooks Class Initialized
DEBUG - 2011-07-23 15:46:35 --> Utf8 Class Initialized
DEBUG - 2011-07-23 15:46:35 --> UTF-8 Support Enabled
DEBUG - 2011-07-23 15:46:35 --> URI Class Initialized
DEBUG - 2011-07-23 15:46:35 --> Router Class Initialized
DEBUG - 2011-07-23 15:46:35 --> Output Class Initialized
DEBUG - 2011-07-23 15:46:35 --> Input Class Initialized
DEBUG - 2011-07-23 15:46:35 --> Global POST and COOKIE data sanitized
DEBUG - 2011-07-23 15:46:35 --> Language Class Initialized
DEBUG - 2011-07-23 15:46:35 --> Loader Class Initialized
DEBUG - 2011-07-23 15:46:35 --> Controller Class Initialized
ERROR - 2011-07-23 15:46:35 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-07-23 15:46:35 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-07-23 15:46:35 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-07-23 15:46:35 --> Model Class Initialized
DEBUG - 2011-07-23 15:46:35 --> Model Class Initialized
DEBUG - 2011-07-23 15:46:35 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-07-23 15:46:35 --> Database Driver Class Initialized
DEBUG - 2011-07-23 15:46:35 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-07-23 15:46:35 --> Helper loaded: url_helper
DEBUG - 2011-07-23 15:46:35 --> File loaded: application/views/common/header.php
DEBUG - 2011-07-23 15:46:35 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-07-23 15:46:35 --> File loaded: application/views/common/footer.php
DEBUG - 2011-07-23 15:46:35 --> File loaded: application/views/layout/main.php
DEBUG - 2011-07-23 15:46:35 --> Final output sent to browser
DEBUG - 2011-07-23 15:46:35 --> Total execution time: 0.0275
DEBUG - 2011-07-23 15:46:37 --> Config Class Initialized
DEBUG - 2011-07-23 15:46:37 --> Hooks Class Initialized
DEBUG - 2011-07-23 15:46:37 --> Utf8 Class Initialized
DEBUG - 2011-07-23 15:46:37 --> UTF-8 Support Enabled
DEBUG - 2011-07-23 15:46:37 --> URI Class Initialized
DEBUG - 2011-07-23 15:46:37 --> Router Class Initialized
DEBUG - 2011-07-23 15:46:37 --> Output Class Initialized
DEBUG - 2011-07-23 15:46:37 --> Input Class Initialized
DEBUG - 2011-07-23 15:46:37 --> Global POST and COOKIE data sanitized
DEBUG - 2011-07-23 15:46:37 --> Language Class Initialized
DEBUG - 2011-07-23 15:46:37 --> Loader Class Initialized
DEBUG - 2011-07-23 15:46:37 --> Controller Class Initialized
DEBUG - 2011-07-23 15:46:37 --> Model Class Initialized
DEBUG - 2011-07-23 15:46:37 --> Model Class Initialized
DEBUG - 2011-07-23 15:46:37 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-07-23 15:46:37 --> Database Driver Class Initialized
DEBUG - 2011-07-23 15:46:37 --> Final output sent to browser
DEBUG - 2011-07-23 15:46:37 --> Total execution time: 0.5348
DEBUG - 2011-07-23 15:46:38 --> Config Class Initialized
DEBUG - 2011-07-23 15:46:38 --> Hooks Class Initialized
DEBUG - 2011-07-23 15:46:38 --> Utf8 Class Initialized
DEBUG - 2011-07-23 15:46:38 --> UTF-8 Support Enabled
DEBUG - 2011-07-23 15:46:38 --> URI Class Initialized
DEBUG - 2011-07-23 15:46:38 --> Router Class Initialized
ERROR - 2011-07-23 15:46:38 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-07-23 15:46:42 --> Config Class Initialized
DEBUG - 2011-07-23 15:46:42 --> Hooks Class Initialized
DEBUG - 2011-07-23 15:46:42 --> Utf8 Class Initialized
DEBUG - 2011-07-23 15:46:42 --> UTF-8 Support Enabled
DEBUG - 2011-07-23 15:46:42 --> URI Class Initialized
DEBUG - 2011-07-23 15:46:42 --> Router Class Initialized
DEBUG - 2011-07-23 15:46:42 --> Output Class Initialized
DEBUG - 2011-07-23 15:46:42 --> Input Class Initialized
DEBUG - 2011-07-23 15:46:42 --> Global POST and COOKIE data sanitized
DEBUG - 2011-07-23 15:46:42 --> Language Class Initialized
DEBUG - 2011-07-23 15:46:42 --> Loader Class Initialized
DEBUG - 2011-07-23 15:46:42 --> Controller Class Initialized
ERROR - 2011-07-23 15:46:42 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-07-23 15:46:42 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-07-23 15:46:42 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-07-23 15:46:42 --> Model Class Initialized
DEBUG - 2011-07-23 15:46:42 --> Model Class Initialized
DEBUG - 2011-07-23 15:46:42 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-07-23 15:46:42 --> Database Driver Class Initialized
DEBUG - 2011-07-23 15:46:42 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-07-23 15:46:42 --> Helper loaded: url_helper
DEBUG - 2011-07-23 15:46:42 --> File loaded: application/views/common/header.php
DEBUG - 2011-07-23 15:46:42 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-07-23 15:46:42 --> File loaded: application/views/common/footer.php
DEBUG - 2011-07-23 15:46:42 --> File loaded: application/views/layout/main.php
DEBUG - 2011-07-23 15:46:42 --> Final output sent to browser
DEBUG - 2011-07-23 15:46:42 --> Total execution time: 0.0277
DEBUG - 2011-07-23 15:46:43 --> Config Class Initialized
DEBUG - 2011-07-23 15:46:43 --> Hooks Class Initialized
DEBUG - 2011-07-23 15:46:43 --> Utf8 Class Initialized
DEBUG - 2011-07-23 15:46:43 --> UTF-8 Support Enabled
DEBUG - 2011-07-23 15:46:43 --> URI Class Initialized
DEBUG - 2011-07-23 15:46:43 --> Router Class Initialized
DEBUG - 2011-07-23 15:46:43 --> Output Class Initialized
DEBUG - 2011-07-23 15:46:43 --> Input Class Initialized
DEBUG - 2011-07-23 15:46:43 --> Global POST and COOKIE data sanitized
DEBUG - 2011-07-23 15:46:43 --> Language Class Initialized
DEBUG - 2011-07-23 15:46:43 --> Loader Class Initialized
DEBUG - 2011-07-23 15:46:43 --> Controller Class Initialized
DEBUG - 2011-07-23 15:46:43 --> Model Class Initialized
DEBUG - 2011-07-23 15:46:43 --> Model Class Initialized
DEBUG - 2011-07-23 15:46:43 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-07-23 15:46:43 --> Database Driver Class Initialized
DEBUG - 2011-07-23 15:46:44 --> Final output sent to browser
DEBUG - 2011-07-23 15:46:44 --> Total execution time: 0.5284
DEBUG - 2011-07-23 15:46:45 --> Config Class Initialized
DEBUG - 2011-07-23 15:46:45 --> Hooks Class Initialized
DEBUG - 2011-07-23 15:46:45 --> Utf8 Class Initialized
DEBUG - 2011-07-23 15:46:45 --> UTF-8 Support Enabled
DEBUG - 2011-07-23 15:46:45 --> URI Class Initialized
DEBUG - 2011-07-23 15:46:45 --> Router Class Initialized
ERROR - 2011-07-23 15:46:45 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-07-23 15:46:50 --> Config Class Initialized
DEBUG - 2011-07-23 15:46:50 --> Hooks Class Initialized
DEBUG - 2011-07-23 15:46:50 --> Utf8 Class Initialized
DEBUG - 2011-07-23 15:46:50 --> UTF-8 Support Enabled
DEBUG - 2011-07-23 15:46:50 --> URI Class Initialized
DEBUG - 2011-07-23 15:46:50 --> Router Class Initialized
DEBUG - 2011-07-23 15:46:50 --> Output Class Initialized
DEBUG - 2011-07-23 15:46:50 --> Input Class Initialized
DEBUG - 2011-07-23 15:46:50 --> Global POST and COOKIE data sanitized
DEBUG - 2011-07-23 15:46:50 --> Language Class Initialized
DEBUG - 2011-07-23 15:46:50 --> Loader Class Initialized
DEBUG - 2011-07-23 15:46:50 --> Controller Class Initialized
ERROR - 2011-07-23 15:46:50 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-07-23 15:46:50 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-07-23 15:46:50 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-07-23 15:46:50 --> Model Class Initialized
DEBUG - 2011-07-23 15:46:50 --> Model Class Initialized
DEBUG - 2011-07-23 15:46:50 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-07-23 15:46:50 --> Database Driver Class Initialized
DEBUG - 2011-07-23 15:46:50 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-07-23 15:46:50 --> Helper loaded: url_helper
DEBUG - 2011-07-23 15:46:50 --> File loaded: application/views/common/header.php
DEBUG - 2011-07-23 15:46:50 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-07-23 15:46:50 --> File loaded: application/views/common/footer.php
DEBUG - 2011-07-23 15:46:50 --> File loaded: application/views/layout/main.php
DEBUG - 2011-07-23 15:46:50 --> Final output sent to browser
DEBUG - 2011-07-23 15:46:50 --> Total execution time: 0.0266
DEBUG - 2011-07-23 15:46:51 --> Config Class Initialized
DEBUG - 2011-07-23 15:46:51 --> Hooks Class Initialized
DEBUG - 2011-07-23 15:46:51 --> Utf8 Class Initialized
DEBUG - 2011-07-23 15:46:51 --> UTF-8 Support Enabled
DEBUG - 2011-07-23 15:46:51 --> URI Class Initialized
DEBUG - 2011-07-23 15:46:51 --> Router Class Initialized
DEBUG - 2011-07-23 15:46:51 --> Output Class Initialized
DEBUG - 2011-07-23 15:46:51 --> Input Class Initialized
DEBUG - 2011-07-23 15:46:51 --> Global POST and COOKIE data sanitized
DEBUG - 2011-07-23 15:46:51 --> Language Class Initialized
DEBUG - 2011-07-23 15:46:51 --> Loader Class Initialized
DEBUG - 2011-07-23 15:46:51 --> Controller Class Initialized
DEBUG - 2011-07-23 15:46:51 --> Model Class Initialized
DEBUG - 2011-07-23 15:46:51 --> Model Class Initialized
DEBUG - 2011-07-23 15:46:51 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-07-23 15:46:51 --> Database Driver Class Initialized
DEBUG - 2011-07-23 15:46:52 --> Final output sent to browser
DEBUG - 2011-07-23 15:46:52 --> Total execution time: 0.5065
DEBUG - 2011-07-23 15:46:53 --> Config Class Initialized
DEBUG - 2011-07-23 15:46:53 --> Hooks Class Initialized
DEBUG - 2011-07-23 15:46:53 --> Utf8 Class Initialized
DEBUG - 2011-07-23 15:46:53 --> UTF-8 Support Enabled
DEBUG - 2011-07-23 15:46:53 --> URI Class Initialized
DEBUG - 2011-07-23 15:46:53 --> Router Class Initialized
ERROR - 2011-07-23 15:46:53 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-07-23 15:47:00 --> Config Class Initialized
DEBUG - 2011-07-23 15:47:00 --> Hooks Class Initialized
DEBUG - 2011-07-23 15:47:00 --> Utf8 Class Initialized
DEBUG - 2011-07-23 15:47:00 --> UTF-8 Support Enabled
DEBUG - 2011-07-23 15:47:00 --> URI Class Initialized
DEBUG - 2011-07-23 15:47:00 --> Router Class Initialized
DEBUG - 2011-07-23 15:47:00 --> Output Class Initialized
DEBUG - 2011-07-23 15:47:00 --> Input Class Initialized
DEBUG - 2011-07-23 15:47:00 --> Global POST and COOKIE data sanitized
DEBUG - 2011-07-23 15:47:00 --> Language Class Initialized
DEBUG - 2011-07-23 15:47:00 --> Loader Class Initialized
DEBUG - 2011-07-23 15:47:00 --> Controller Class Initialized
ERROR - 2011-07-23 15:47:00 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-07-23 15:47:00 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-07-23 15:47:00 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-07-23 15:47:00 --> Model Class Initialized
DEBUG - 2011-07-23 15:47:00 --> Model Class Initialized
DEBUG - 2011-07-23 15:47:00 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-07-23 15:47:00 --> Database Driver Class Initialized
DEBUG - 2011-07-23 15:47:00 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-07-23 15:47:00 --> Helper loaded: url_helper
DEBUG - 2011-07-23 15:47:00 --> File loaded: application/views/common/header.php
DEBUG - 2011-07-23 15:47:00 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-07-23 15:47:00 --> File loaded: application/views/common/footer.php
DEBUG - 2011-07-23 15:47:00 --> File loaded: application/views/layout/main.php
DEBUG - 2011-07-23 15:47:00 --> Final output sent to browser
DEBUG - 2011-07-23 15:47:00 --> Total execution time: 0.0307
DEBUG - 2011-07-23 15:47:01 --> Config Class Initialized
DEBUG - 2011-07-23 15:47:01 --> Hooks Class Initialized
DEBUG - 2011-07-23 15:47:01 --> Utf8 Class Initialized
DEBUG - 2011-07-23 15:47:01 --> UTF-8 Support Enabled
DEBUG - 2011-07-23 15:47:01 --> URI Class Initialized
DEBUG - 2011-07-23 15:47:01 --> Router Class Initialized
DEBUG - 2011-07-23 15:47:01 --> Output Class Initialized
DEBUG - 2011-07-23 15:47:01 --> Input Class Initialized
DEBUG - 2011-07-23 15:47:01 --> Global POST and COOKIE data sanitized
DEBUG - 2011-07-23 15:47:01 --> Language Class Initialized
DEBUG - 2011-07-23 15:47:01 --> Loader Class Initialized
DEBUG - 2011-07-23 15:47:01 --> Controller Class Initialized
DEBUG - 2011-07-23 15:47:01 --> Model Class Initialized
DEBUG - 2011-07-23 15:47:01 --> Model Class Initialized
DEBUG - 2011-07-23 15:47:01 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-07-23 15:47:01 --> Database Driver Class Initialized
DEBUG - 2011-07-23 15:47:02 --> Final output sent to browser
DEBUG - 2011-07-23 15:47:02 --> Total execution time: 0.7488
DEBUG - 2011-07-23 15:47:04 --> Config Class Initialized
DEBUG - 2011-07-23 15:47:04 --> Hooks Class Initialized
DEBUG - 2011-07-23 15:47:04 --> Utf8 Class Initialized
DEBUG - 2011-07-23 15:47:04 --> UTF-8 Support Enabled
DEBUG - 2011-07-23 15:47:04 --> URI Class Initialized
DEBUG - 2011-07-23 15:47:04 --> Router Class Initialized
ERROR - 2011-07-23 15:47:04 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-07-23 15:47:11 --> Config Class Initialized
DEBUG - 2011-07-23 15:47:11 --> Hooks Class Initialized
DEBUG - 2011-07-23 15:47:11 --> Utf8 Class Initialized
DEBUG - 2011-07-23 15:47:11 --> UTF-8 Support Enabled
DEBUG - 2011-07-23 15:47:11 --> URI Class Initialized
DEBUG - 2011-07-23 15:47:11 --> Router Class Initialized
DEBUG - 2011-07-23 15:47:11 --> Output Class Initialized
DEBUG - 2011-07-23 15:47:11 --> Input Class Initialized
DEBUG - 2011-07-23 15:47:11 --> Global POST and COOKIE data sanitized
DEBUG - 2011-07-23 15:47:11 --> Language Class Initialized
DEBUG - 2011-07-23 15:47:11 --> Loader Class Initialized
DEBUG - 2011-07-23 15:47:11 --> Controller Class Initialized
ERROR - 2011-07-23 15:47:11 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-07-23 15:47:11 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-07-23 15:47:11 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-07-23 15:47:11 --> Model Class Initialized
DEBUG - 2011-07-23 15:47:11 --> Model Class Initialized
DEBUG - 2011-07-23 15:47:11 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-07-23 15:47:11 --> Database Driver Class Initialized
DEBUG - 2011-07-23 15:47:11 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-07-23 15:47:11 --> Helper loaded: url_helper
DEBUG - 2011-07-23 15:47:11 --> File loaded: application/views/common/header.php
DEBUG - 2011-07-23 15:47:11 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-07-23 15:47:11 --> File loaded: application/views/common/footer.php
DEBUG - 2011-07-23 15:47:11 --> File loaded: application/views/layout/main.php
DEBUG - 2011-07-23 15:47:11 --> Final output sent to browser
DEBUG - 2011-07-23 15:47:11 --> Total execution time: 0.0286
DEBUG - 2011-07-23 15:47:12 --> Config Class Initialized
DEBUG - 2011-07-23 15:47:12 --> Hooks Class Initialized
DEBUG - 2011-07-23 15:47:12 --> Utf8 Class Initialized
DEBUG - 2011-07-23 15:47:12 --> UTF-8 Support Enabled
DEBUG - 2011-07-23 15:47:12 --> URI Class Initialized
DEBUG - 2011-07-23 15:47:12 --> Router Class Initialized
DEBUG - 2011-07-23 15:47:13 --> Output Class Initialized
DEBUG - 2011-07-23 15:47:13 --> Input Class Initialized
DEBUG - 2011-07-23 15:47:13 --> Global POST and COOKIE data sanitized
DEBUG - 2011-07-23 15:47:13 --> Language Class Initialized
DEBUG - 2011-07-23 15:47:13 --> Loader Class Initialized
DEBUG - 2011-07-23 15:47:13 --> Controller Class Initialized
DEBUG - 2011-07-23 15:47:13 --> Model Class Initialized
DEBUG - 2011-07-23 15:47:13 --> Model Class Initialized
DEBUG - 2011-07-23 15:47:13 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-07-23 15:47:13 --> Database Driver Class Initialized
DEBUG - 2011-07-23 15:47:13 --> Final output sent to browser
DEBUG - 2011-07-23 15:47:13 --> Total execution time: 0.5599
DEBUG - 2011-07-23 15:47:14 --> Config Class Initialized
DEBUG - 2011-07-23 15:47:14 --> Hooks Class Initialized
DEBUG - 2011-07-23 15:47:14 --> Utf8 Class Initialized
DEBUG - 2011-07-23 15:47:14 --> UTF-8 Support Enabled
DEBUG - 2011-07-23 15:47:14 --> URI Class Initialized
DEBUG - 2011-07-23 15:47:14 --> Router Class Initialized
ERROR - 2011-07-23 15:47:14 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-07-23 16:54:35 --> Config Class Initialized
DEBUG - 2011-07-23 16:54:35 --> Hooks Class Initialized
DEBUG - 2011-07-23 16:54:35 --> Utf8 Class Initialized
DEBUG - 2011-07-23 16:54:35 --> UTF-8 Support Enabled
DEBUG - 2011-07-23 16:54:35 --> URI Class Initialized
DEBUG - 2011-07-23 16:54:35 --> Router Class Initialized
DEBUG - 2011-07-23 16:54:35 --> Output Class Initialized
DEBUG - 2011-07-23 16:54:35 --> Input Class Initialized
DEBUG - 2011-07-23 16:54:35 --> Global POST and COOKIE data sanitized
DEBUG - 2011-07-23 16:54:35 --> Language Class Initialized
DEBUG - 2011-07-23 16:54:35 --> Loader Class Initialized
DEBUG - 2011-07-23 16:54:35 --> Controller Class Initialized
DEBUG - 2011-07-23 16:54:35 --> Model Class Initialized
DEBUG - 2011-07-23 16:54:35 --> Model Class Initialized
DEBUG - 2011-07-23 16:54:35 --> Model Class Initialized
DEBUG - 2011-07-23 16:54:35 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-07-23 16:54:35 --> Database Driver Class Initialized
DEBUG - 2011-07-23 16:54:36 --> File loaded: application/views/table/main.php
DEBUG - 2011-07-23 16:54:36 --> Helper loaded: url_helper
DEBUG - 2011-07-23 16:54:36 --> File loaded: application/views/common/header.php
DEBUG - 2011-07-23 16:54:36 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-07-23 16:54:36 --> File loaded: application/views/common/footer.php
DEBUG - 2011-07-23 16:54:36 --> File loaded: application/views/layout/main.php
DEBUG - 2011-07-23 16:54:36 --> Final output sent to browser
DEBUG - 2011-07-23 16:54:36 --> Total execution time: 0.4911
DEBUG - 2011-07-23 16:54:37 --> Config Class Initialized
DEBUG - 2011-07-23 16:54:37 --> Hooks Class Initialized
DEBUG - 2011-07-23 16:54:37 --> Utf8 Class Initialized
DEBUG - 2011-07-23 16:54:37 --> UTF-8 Support Enabled
DEBUG - 2011-07-23 16:54:37 --> URI Class Initialized
DEBUG - 2011-07-23 16:54:37 --> Router Class Initialized
ERROR - 2011-07-23 16:54:37 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-07-23 16:54:44 --> Config Class Initialized
DEBUG - 2011-07-23 16:54:44 --> Hooks Class Initialized
DEBUG - 2011-07-23 16:54:44 --> Utf8 Class Initialized
DEBUG - 2011-07-23 16:54:44 --> UTF-8 Support Enabled
DEBUG - 2011-07-23 16:54:44 --> URI Class Initialized
DEBUG - 2011-07-23 16:54:44 --> Router Class Initialized
DEBUG - 2011-07-23 16:54:44 --> Output Class Initialized
DEBUG - 2011-07-23 16:54:44 --> Input Class Initialized
DEBUG - 2011-07-23 16:54:44 --> Global POST and COOKIE data sanitized
DEBUG - 2011-07-23 16:54:44 --> Language Class Initialized
DEBUG - 2011-07-23 16:54:44 --> Loader Class Initialized
DEBUG - 2011-07-23 16:54:44 --> Controller Class Initialized
DEBUG - 2011-07-23 16:54:44 --> Model Class Initialized
DEBUG - 2011-07-23 16:54:44 --> Model Class Initialized
DEBUG - 2011-07-23 16:54:44 --> Model Class Initialized
DEBUG - 2011-07-23 16:54:44 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-07-23 16:54:44 --> Database Driver Class Initialized
DEBUG - 2011-07-23 16:54:44 --> File loaded: application/views/table/main.php
DEBUG - 2011-07-23 16:54:44 --> Helper loaded: url_helper
DEBUG - 2011-07-23 16:54:44 --> File loaded: application/views/common/header.php
DEBUG - 2011-07-23 16:54:44 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-07-23 16:54:44 --> File loaded: application/views/common/footer.php
DEBUG - 2011-07-23 16:54:44 --> File loaded: application/views/layout/main.php
DEBUG - 2011-07-23 16:54:44 --> Final output sent to browser
DEBUG - 2011-07-23 16:54:44 --> Total execution time: 0.2405
DEBUG - 2011-07-23 16:54:45 --> Config Class Initialized
DEBUG - 2011-07-23 16:54:45 --> Hooks Class Initialized
DEBUG - 2011-07-23 16:54:45 --> Utf8 Class Initialized
DEBUG - 2011-07-23 16:54:45 --> UTF-8 Support Enabled
DEBUG - 2011-07-23 16:54:45 --> URI Class Initialized
DEBUG - 2011-07-23 16:54:45 --> Router Class Initialized
ERROR - 2011-07-23 16:54:45 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-07-23 16:54:46 --> Config Class Initialized
DEBUG - 2011-07-23 16:54:46 --> Hooks Class Initialized
DEBUG - 2011-07-23 16:54:46 --> Utf8 Class Initialized
DEBUG - 2011-07-23 16:54:46 --> UTF-8 Support Enabled
DEBUG - 2011-07-23 16:54:46 --> URI Class Initialized
DEBUG - 2011-07-23 16:54:46 --> Router Class Initialized
ERROR - 2011-07-23 16:54:46 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-07-23 16:54:54 --> Config Class Initialized
DEBUG - 2011-07-23 16:54:54 --> Hooks Class Initialized
DEBUG - 2011-07-23 16:54:54 --> Utf8 Class Initialized
DEBUG - 2011-07-23 16:54:54 --> UTF-8 Support Enabled
DEBUG - 2011-07-23 16:54:54 --> URI Class Initialized
DEBUG - 2011-07-23 16:54:54 --> Router Class Initialized
DEBUG - 2011-07-23 16:54:54 --> Output Class Initialized
DEBUG - 2011-07-23 16:54:54 --> Input Class Initialized
DEBUG - 2011-07-23 16:54:54 --> Global POST and COOKIE data sanitized
DEBUG - 2011-07-23 16:54:54 --> Language Class Initialized
DEBUG - 2011-07-23 16:54:54 --> Loader Class Initialized
DEBUG - 2011-07-23 16:54:54 --> Controller Class Initialized
DEBUG - 2011-07-23 16:54:54 --> Model Class Initialized
DEBUG - 2011-07-23 16:54:54 --> Model Class Initialized
DEBUG - 2011-07-23 16:54:54 --> Model Class Initialized
DEBUG - 2011-07-23 16:54:54 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-07-23 16:54:54 --> Database Driver Class Initialized
DEBUG - 2011-07-23 16:54:54 --> File loaded: application/views/table/main.php
DEBUG - 2011-07-23 16:54:54 --> Helper loaded: url_helper
DEBUG - 2011-07-23 16:54:54 --> File loaded: application/views/common/header.php
DEBUG - 2011-07-23 16:54:54 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-07-23 16:54:54 --> File loaded: application/views/common/footer.php
DEBUG - 2011-07-23 16:54:54 --> File loaded: application/views/layout/main.php
DEBUG - 2011-07-23 16:54:54 --> Final output sent to browser
DEBUG - 2011-07-23 16:54:54 --> Total execution time: 0.0445
DEBUG - 2011-07-23 16:54:54 --> Config Class Initialized
DEBUG - 2011-07-23 16:54:54 --> Hooks Class Initialized
DEBUG - 2011-07-23 16:54:54 --> Utf8 Class Initialized
DEBUG - 2011-07-23 16:54:54 --> UTF-8 Support Enabled
DEBUG - 2011-07-23 16:54:54 --> URI Class Initialized
DEBUG - 2011-07-23 16:54:54 --> Router Class Initialized
ERROR - 2011-07-23 16:54:54 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-07-23 16:54:55 --> Config Class Initialized
DEBUG - 2011-07-23 16:54:55 --> Hooks Class Initialized
DEBUG - 2011-07-23 16:54:55 --> Utf8 Class Initialized
DEBUG - 2011-07-23 16:54:55 --> UTF-8 Support Enabled
DEBUG - 2011-07-23 16:54:55 --> URI Class Initialized
DEBUG - 2011-07-23 16:54:55 --> Router Class Initialized
ERROR - 2011-07-23 16:54:55 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-07-23 16:54:57 --> Config Class Initialized
DEBUG - 2011-07-23 16:54:57 --> Hooks Class Initialized
DEBUG - 2011-07-23 16:54:57 --> Utf8 Class Initialized
DEBUG - 2011-07-23 16:54:57 --> UTF-8 Support Enabled
DEBUG - 2011-07-23 16:54:57 --> URI Class Initialized
DEBUG - 2011-07-23 16:54:57 --> Router Class Initialized
ERROR - 2011-07-23 16:54:57 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-07-23 16:55:03 --> Config Class Initialized
DEBUG - 2011-07-23 16:55:03 --> Hooks Class Initialized
DEBUG - 2011-07-23 16:55:03 --> Utf8 Class Initialized
DEBUG - 2011-07-23 16:55:03 --> UTF-8 Support Enabled
DEBUG - 2011-07-23 16:55:03 --> URI Class Initialized
DEBUG - 2011-07-23 16:55:03 --> Router Class Initialized
DEBUG - 2011-07-23 16:55:03 --> Output Class Initialized
DEBUG - 2011-07-23 16:55:03 --> Input Class Initialized
DEBUG - 2011-07-23 16:55:03 --> Global POST and COOKIE data sanitized
DEBUG - 2011-07-23 16:55:03 --> Language Class Initialized
DEBUG - 2011-07-23 16:55:03 --> Loader Class Initialized
DEBUG - 2011-07-23 16:55:03 --> Controller Class Initialized
DEBUG - 2011-07-23 16:55:03 --> Model Class Initialized
DEBUG - 2011-07-23 16:55:03 --> Model Class Initialized
DEBUG - 2011-07-23 16:55:03 --> Model Class Initialized
DEBUG - 2011-07-23 16:55:03 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-07-23 16:55:03 --> Database Driver Class Initialized
DEBUG - 2011-07-23 16:55:03 --> File loaded: application/views/table/main.php
DEBUG - 2011-07-23 16:55:03 --> Helper loaded: url_helper
DEBUG - 2011-07-23 16:55:03 --> File loaded: application/views/common/header.php
DEBUG - 2011-07-23 16:55:03 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-07-23 16:55:03 --> File loaded: application/views/common/footer.php
DEBUG - 2011-07-23 16:55:03 --> File loaded: application/views/layout/main.php
DEBUG - 2011-07-23 16:55:03 --> Final output sent to browser
DEBUG - 2011-07-23 16:55:03 --> Total execution time: 0.1981
DEBUG - 2011-07-23 16:55:23 --> Config Class Initialized
DEBUG - 2011-07-23 16:55:23 --> Hooks Class Initialized
DEBUG - 2011-07-23 16:55:23 --> Utf8 Class Initialized
DEBUG - 2011-07-23 16:55:23 --> UTF-8 Support Enabled
DEBUG - 2011-07-23 16:55:23 --> URI Class Initialized
DEBUG - 2011-07-23 16:55:23 --> Router Class Initialized
DEBUG - 2011-07-23 16:55:23 --> Output Class Initialized
DEBUG - 2011-07-23 16:55:23 --> Input Class Initialized
DEBUG - 2011-07-23 16:55:23 --> Global POST and COOKIE data sanitized
DEBUG - 2011-07-23 16:55:23 --> Language Class Initialized
DEBUG - 2011-07-23 16:55:23 --> Loader Class Initialized
DEBUG - 2011-07-23 16:55:23 --> Controller Class Initialized
DEBUG - 2011-07-23 16:55:23 --> Model Class Initialized
DEBUG - 2011-07-23 16:55:23 --> Model Class Initialized
DEBUG - 2011-07-23 16:55:23 --> Model Class Initialized
DEBUG - 2011-07-23 16:55:23 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-07-23 16:55:23 --> Database Driver Class Initialized
DEBUG - 2011-07-23 16:55:24 --> File loaded: application/views/table/main.php
DEBUG - 2011-07-23 16:55:24 --> Helper loaded: url_helper
DEBUG - 2011-07-23 16:55:24 --> File loaded: application/views/common/header.php
DEBUG - 2011-07-23 16:55:24 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-07-23 16:55:24 --> File loaded: application/views/common/footer.php
DEBUG - 2011-07-23 16:55:24 --> File loaded: application/views/layout/main.php
DEBUG - 2011-07-23 16:55:24 --> Final output sent to browser
DEBUG - 2011-07-23 16:55:24 --> Total execution time: 0.2366
DEBUG - 2011-07-23 16:55:41 --> Config Class Initialized
DEBUG - 2011-07-23 16:55:41 --> Hooks Class Initialized
DEBUG - 2011-07-23 16:55:41 --> Utf8 Class Initialized
DEBUG - 2011-07-23 16:55:41 --> UTF-8 Support Enabled
DEBUG - 2011-07-23 16:55:41 --> URI Class Initialized
DEBUG - 2011-07-23 16:55:41 --> Router Class Initialized
DEBUG - 2011-07-23 16:55:41 --> Output Class Initialized
DEBUG - 2011-07-23 16:55:41 --> Input Class Initialized
DEBUG - 2011-07-23 16:55:41 --> Global POST and COOKIE data sanitized
DEBUG - 2011-07-23 16:55:41 --> Language Class Initialized
DEBUG - 2011-07-23 16:55:41 --> Loader Class Initialized
DEBUG - 2011-07-23 16:55:41 --> Controller Class Initialized
DEBUG - 2011-07-23 16:55:41 --> Model Class Initialized
DEBUG - 2011-07-23 16:55:41 --> Model Class Initialized
DEBUG - 2011-07-23 16:55:41 --> Model Class Initialized
DEBUG - 2011-07-23 16:55:41 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-07-23 16:55:41 --> Database Driver Class Initialized
DEBUG - 2011-07-23 16:55:41 --> File loaded: application/views/table/main.php
DEBUG - 2011-07-23 16:55:41 --> Helper loaded: url_helper
DEBUG - 2011-07-23 16:55:41 --> File loaded: application/views/common/header.php
DEBUG - 2011-07-23 16:55:41 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-07-23 16:55:41 --> File loaded: application/views/common/footer.php
DEBUG - 2011-07-23 16:55:41 --> File loaded: application/views/layout/main.php
DEBUG - 2011-07-23 16:55:41 --> Final output sent to browser
DEBUG - 2011-07-23 16:55:41 --> Total execution time: 0.2906
DEBUG - 2011-07-23 16:55:42 --> Config Class Initialized
DEBUG - 2011-07-23 16:55:42 --> Hooks Class Initialized
DEBUG - 2011-07-23 16:55:42 --> Utf8 Class Initialized
DEBUG - 2011-07-23 16:55:42 --> UTF-8 Support Enabled
DEBUG - 2011-07-23 16:55:42 --> URI Class Initialized
DEBUG - 2011-07-23 16:55:42 --> Router Class Initialized
DEBUG - 2011-07-23 16:55:42 --> Output Class Initialized
DEBUG - 2011-07-23 16:55:42 --> Input Class Initialized
DEBUG - 2011-07-23 16:55:42 --> Global POST and COOKIE data sanitized
DEBUG - 2011-07-23 16:55:42 --> Language Class Initialized
DEBUG - 2011-07-23 16:55:42 --> Loader Class Initialized
DEBUG - 2011-07-23 16:55:42 --> Controller Class Initialized
DEBUG - 2011-07-23 16:55:42 --> Model Class Initialized
DEBUG - 2011-07-23 16:55:42 --> Model Class Initialized
DEBUG - 2011-07-23 16:55:42 --> Model Class Initialized
DEBUG - 2011-07-23 16:55:42 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-07-23 16:55:42 --> Database Driver Class Initialized
DEBUG - 2011-07-23 16:55:42 --> File loaded: application/views/table/main.php
DEBUG - 2011-07-23 16:55:42 --> Helper loaded: url_helper
DEBUG - 2011-07-23 16:55:42 --> File loaded: application/views/common/header.php
DEBUG - 2011-07-23 16:55:42 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-07-23 16:55:42 --> File loaded: application/views/common/footer.php
DEBUG - 2011-07-23 16:55:42 --> File loaded: application/views/layout/main.php
DEBUG - 2011-07-23 16:55:42 --> Final output sent to browser
DEBUG - 2011-07-23 16:55:42 --> Total execution time: 0.0443
DEBUG - 2011-07-23 16:55:54 --> Config Class Initialized
DEBUG - 2011-07-23 16:55:54 --> Hooks Class Initialized
DEBUG - 2011-07-23 16:55:54 --> Utf8 Class Initialized
DEBUG - 2011-07-23 16:55:54 --> UTF-8 Support Enabled
DEBUG - 2011-07-23 16:55:54 --> URI Class Initialized
DEBUG - 2011-07-23 16:55:54 --> Router Class Initialized
DEBUG - 2011-07-23 16:55:54 --> Output Class Initialized
DEBUG - 2011-07-23 16:55:54 --> Input Class Initialized
DEBUG - 2011-07-23 16:55:54 --> Global POST and COOKIE data sanitized
DEBUG - 2011-07-23 16:55:54 --> Language Class Initialized
DEBUG - 2011-07-23 16:55:54 --> Loader Class Initialized
DEBUG - 2011-07-23 16:55:54 --> Controller Class Initialized
DEBUG - 2011-07-23 16:55:54 --> Model Class Initialized
DEBUG - 2011-07-23 16:55:54 --> Model Class Initialized
DEBUG - 2011-07-23 16:55:54 --> Model Class Initialized
DEBUG - 2011-07-23 16:55:54 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-07-23 16:55:54 --> Database Driver Class Initialized
DEBUG - 2011-07-23 16:55:54 --> File loaded: application/views/table/main.php
DEBUG - 2011-07-23 16:55:54 --> Helper loaded: url_helper
DEBUG - 2011-07-23 16:55:54 --> File loaded: application/views/common/header.php
DEBUG - 2011-07-23 16:55:54 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-07-23 16:55:54 --> File loaded: application/views/common/footer.php
DEBUG - 2011-07-23 16:55:54 --> File loaded: application/views/layout/main.php
DEBUG - 2011-07-23 16:55:54 --> Final output sent to browser
DEBUG - 2011-07-23 16:55:54 --> Total execution time: 0.2087
DEBUG - 2011-07-23 16:56:04 --> Config Class Initialized
DEBUG - 2011-07-23 16:56:04 --> Hooks Class Initialized
DEBUG - 2011-07-23 16:56:04 --> Utf8 Class Initialized
DEBUG - 2011-07-23 16:56:04 --> UTF-8 Support Enabled
DEBUG - 2011-07-23 16:56:04 --> URI Class Initialized
DEBUG - 2011-07-23 16:56:04 --> Router Class Initialized
DEBUG - 2011-07-23 16:56:04 --> Output Class Initialized
DEBUG - 2011-07-23 16:56:04 --> Input Class Initialized
DEBUG - 2011-07-23 16:56:04 --> Global POST and COOKIE data sanitized
DEBUG - 2011-07-23 16:56:04 --> Language Class Initialized
DEBUG - 2011-07-23 16:56:04 --> Loader Class Initialized
DEBUG - 2011-07-23 16:56:04 --> Controller Class Initialized
DEBUG - 2011-07-23 16:56:04 --> Model Class Initialized
DEBUG - 2011-07-23 16:56:04 --> Model Class Initialized
DEBUG - 2011-07-23 16:56:04 --> Model Class Initialized
DEBUG - 2011-07-23 16:56:04 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-07-23 16:56:04 --> Database Driver Class Initialized
DEBUG - 2011-07-23 16:56:04 --> File loaded: application/views/table/main.php
DEBUG - 2011-07-23 16:56:04 --> Helper loaded: url_helper
DEBUG - 2011-07-23 16:56:04 --> File loaded: application/views/common/header.php
DEBUG - 2011-07-23 16:56:04 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-07-23 16:56:04 --> File loaded: application/views/common/footer.php
DEBUG - 2011-07-23 16:56:04 --> File loaded: application/views/layout/main.php
DEBUG - 2011-07-23 16:56:04 --> Final output sent to browser
DEBUG - 2011-07-23 16:56:04 --> Total execution time: 0.2225
DEBUG - 2011-07-23 16:56:17 --> Config Class Initialized
DEBUG - 2011-07-23 16:56:17 --> Hooks Class Initialized
DEBUG - 2011-07-23 16:56:17 --> Utf8 Class Initialized
DEBUG - 2011-07-23 16:56:17 --> UTF-8 Support Enabled
DEBUG - 2011-07-23 16:56:17 --> URI Class Initialized
DEBUG - 2011-07-23 16:56:17 --> Router Class Initialized
DEBUG - 2011-07-23 16:56:17 --> Output Class Initialized
DEBUG - 2011-07-23 16:56:17 --> Input Class Initialized
DEBUG - 2011-07-23 16:56:17 --> Global POST and COOKIE data sanitized
DEBUG - 2011-07-23 16:56:17 --> Language Class Initialized
DEBUG - 2011-07-23 16:56:17 --> Loader Class Initialized
DEBUG - 2011-07-23 16:56:17 --> Controller Class Initialized
DEBUG - 2011-07-23 16:56:17 --> Model Class Initialized
DEBUG - 2011-07-23 16:56:17 --> Model Class Initialized
DEBUG - 2011-07-23 16:56:17 --> Model Class Initialized
DEBUG - 2011-07-23 16:56:17 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-07-23 16:56:17 --> Database Driver Class Initialized
DEBUG - 2011-07-23 16:56:18 --> File loaded: application/views/table/main.php
DEBUG - 2011-07-23 16:56:18 --> Helper loaded: url_helper
DEBUG - 2011-07-23 16:56:18 --> File loaded: application/views/common/header.php
DEBUG - 2011-07-23 16:56:18 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-07-23 16:56:18 --> File loaded: application/views/common/footer.php
DEBUG - 2011-07-23 16:56:18 --> File loaded: application/views/layout/main.php
DEBUG - 2011-07-23 16:56:18 --> Final output sent to browser
DEBUG - 2011-07-23 16:56:18 --> Total execution time: 0.2873
DEBUG - 2011-07-23 16:56:28 --> Config Class Initialized
DEBUG - 2011-07-23 16:56:28 --> Hooks Class Initialized
DEBUG - 2011-07-23 16:56:28 --> Utf8 Class Initialized
DEBUG - 2011-07-23 16:56:28 --> UTF-8 Support Enabled
DEBUG - 2011-07-23 16:56:28 --> URI Class Initialized
DEBUG - 2011-07-23 16:56:28 --> Router Class Initialized
DEBUG - 2011-07-23 16:56:28 --> Output Class Initialized
DEBUG - 2011-07-23 16:56:28 --> Input Class Initialized
DEBUG - 2011-07-23 16:56:28 --> Global POST and COOKIE data sanitized
DEBUG - 2011-07-23 16:56:28 --> Language Class Initialized
DEBUG - 2011-07-23 16:56:28 --> Loader Class Initialized
DEBUG - 2011-07-23 16:56:28 --> Controller Class Initialized
DEBUG - 2011-07-23 16:56:28 --> Model Class Initialized
DEBUG - 2011-07-23 16:56:28 --> Model Class Initialized
DEBUG - 2011-07-23 16:56:28 --> Model Class Initialized
DEBUG - 2011-07-23 16:56:28 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-07-23 16:56:28 --> Database Driver Class Initialized
DEBUG - 2011-07-23 16:56:29 --> File loaded: application/views/table/main.php
DEBUG - 2011-07-23 16:56:29 --> Helper loaded: url_helper
DEBUG - 2011-07-23 16:56:29 --> File loaded: application/views/common/header.php
DEBUG - 2011-07-23 16:56:29 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-07-23 16:56:29 --> File loaded: application/views/common/footer.php
DEBUG - 2011-07-23 16:56:29 --> File loaded: application/views/layout/main.php
DEBUG - 2011-07-23 16:56:29 --> Final output sent to browser
DEBUG - 2011-07-23 16:56:29 --> Total execution time: 0.4588
DEBUG - 2011-07-23 16:56:45 --> Config Class Initialized
DEBUG - 2011-07-23 16:56:45 --> Hooks Class Initialized
DEBUG - 2011-07-23 16:56:45 --> Utf8 Class Initialized
DEBUG - 2011-07-23 16:56:45 --> UTF-8 Support Enabled
DEBUG - 2011-07-23 16:56:45 --> URI Class Initialized
DEBUG - 2011-07-23 16:56:45 --> Router Class Initialized
DEBUG - 2011-07-23 16:56:45 --> Output Class Initialized
DEBUG - 2011-07-23 16:56:45 --> Input Class Initialized
DEBUG - 2011-07-23 16:56:45 --> Global POST and COOKIE data sanitized
DEBUG - 2011-07-23 16:56:45 --> Language Class Initialized
DEBUG - 2011-07-23 16:56:45 --> Loader Class Initialized
DEBUG - 2011-07-23 16:56:45 --> Controller Class Initialized
DEBUG - 2011-07-23 16:56:45 --> Model Class Initialized
DEBUG - 2011-07-23 16:56:45 --> Model Class Initialized
DEBUG - 2011-07-23 16:56:45 --> Model Class Initialized
DEBUG - 2011-07-23 16:56:45 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-07-23 16:56:45 --> Database Driver Class Initialized
DEBUG - 2011-07-23 16:56:45 --> File loaded: application/views/table/main.php
DEBUG - 2011-07-23 16:56:45 --> Helper loaded: url_helper
DEBUG - 2011-07-23 16:56:45 --> File loaded: application/views/common/header.php
DEBUG - 2011-07-23 16:56:45 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-07-23 16:56:45 --> File loaded: application/views/common/footer.php
DEBUG - 2011-07-23 16:56:45 --> File loaded: application/views/layout/main.php
DEBUG - 2011-07-23 16:56:45 --> Final output sent to browser
DEBUG - 2011-07-23 16:56:45 --> Total execution time: 0.2389
DEBUG - 2011-07-23 17:07:00 --> Config Class Initialized
DEBUG - 2011-07-23 17:07:00 --> Hooks Class Initialized
DEBUG - 2011-07-23 17:07:00 --> Utf8 Class Initialized
DEBUG - 2011-07-23 17:07:00 --> UTF-8 Support Enabled
DEBUG - 2011-07-23 17:07:00 --> URI Class Initialized
DEBUG - 2011-07-23 17:07:00 --> Router Class Initialized
DEBUG - 2011-07-23 17:07:00 --> Output Class Initialized
DEBUG - 2011-07-23 17:07:00 --> Input Class Initialized
DEBUG - 2011-07-23 17:07:00 --> Global POST and COOKIE data sanitized
DEBUG - 2011-07-23 17:07:00 --> Language Class Initialized
DEBUG - 2011-07-23 17:07:00 --> Loader Class Initialized
DEBUG - 2011-07-23 17:07:00 --> Controller Class Initialized
DEBUG - 2011-07-23 17:07:00 --> Model Class Initialized
DEBUG - 2011-07-23 17:07:00 --> Model Class Initialized
DEBUG - 2011-07-23 17:07:00 --> Model Class Initialized
DEBUG - 2011-07-23 17:07:00 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-07-23 17:07:00 --> Database Driver Class Initialized
DEBUG - 2011-07-23 17:07:00 --> File loaded: application/views/table/main.php
DEBUG - 2011-07-23 17:07:00 --> Helper loaded: url_helper
DEBUG - 2011-07-23 17:07:00 --> File loaded: application/views/common/header.php
DEBUG - 2011-07-23 17:07:00 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-07-23 17:07:00 --> File loaded: application/views/common/footer.php
DEBUG - 2011-07-23 17:07:00 --> File loaded: application/views/layout/main.php
DEBUG - 2011-07-23 17:07:00 --> Final output sent to browser
DEBUG - 2011-07-23 17:07:00 --> Total execution time: 0.0526
DEBUG - 2011-07-23 17:07:01 --> Config Class Initialized
DEBUG - 2011-07-23 17:07:01 --> Hooks Class Initialized
DEBUG - 2011-07-23 17:07:01 --> Utf8 Class Initialized
DEBUG - 2011-07-23 17:07:01 --> UTF-8 Support Enabled
DEBUG - 2011-07-23 17:07:01 --> URI Class Initialized
DEBUG - 2011-07-23 17:07:01 --> Router Class Initialized
ERROR - 2011-07-23 17:07:01 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-07-23 17:07:01 --> Config Class Initialized
DEBUG - 2011-07-23 17:07:01 --> Hooks Class Initialized
DEBUG - 2011-07-23 17:07:01 --> Utf8 Class Initialized
DEBUG - 2011-07-23 17:07:01 --> UTF-8 Support Enabled
DEBUG - 2011-07-23 17:07:01 --> URI Class Initialized
DEBUG - 2011-07-23 17:07:01 --> Router Class Initialized
ERROR - 2011-07-23 17:07:01 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-07-23 17:07:04 --> Config Class Initialized
DEBUG - 2011-07-23 17:07:04 --> Hooks Class Initialized
DEBUG - 2011-07-23 17:07:04 --> Utf8 Class Initialized
DEBUG - 2011-07-23 17:07:04 --> UTF-8 Support Enabled
DEBUG - 2011-07-23 17:07:04 --> URI Class Initialized
DEBUG - 2011-07-23 17:07:04 --> Router Class Initialized
ERROR - 2011-07-23 17:07:04 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-07-23 17:39:37 --> Config Class Initialized
DEBUG - 2011-07-23 17:39:37 --> Hooks Class Initialized
DEBUG - 2011-07-23 17:39:37 --> Utf8 Class Initialized
DEBUG - 2011-07-23 17:39:37 --> UTF-8 Support Enabled
DEBUG - 2011-07-23 17:39:37 --> URI Class Initialized
DEBUG - 2011-07-23 17:39:37 --> Router Class Initialized
DEBUG - 2011-07-23 17:39:37 --> Output Class Initialized
DEBUG - 2011-07-23 17:39:37 --> Input Class Initialized
DEBUG - 2011-07-23 17:39:37 --> Global POST and COOKIE data sanitized
DEBUG - 2011-07-23 17:39:37 --> Language Class Initialized
DEBUG - 2011-07-23 17:39:37 --> Loader Class Initialized
DEBUG - 2011-07-23 17:39:37 --> Controller Class Initialized
ERROR - 2011-07-23 17:39:37 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-07-23 17:39:37 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-07-23 17:39:37 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-07-23 17:39:37 --> Model Class Initialized
DEBUG - 2011-07-23 17:39:37 --> Model Class Initialized
DEBUG - 2011-07-23 17:39:37 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-07-23 17:39:37 --> Database Driver Class Initialized
DEBUG - 2011-07-23 17:39:37 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-07-23 17:39:37 --> Helper loaded: url_helper
DEBUG - 2011-07-23 17:39:37 --> File loaded: application/views/common/header.php
DEBUG - 2011-07-23 17:39:37 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-07-23 17:39:37 --> File loaded: application/views/common/footer.php
DEBUG - 2011-07-23 17:39:37 --> File loaded: application/views/layout/main.php
DEBUG - 2011-07-23 17:39:37 --> Final output sent to browser
DEBUG - 2011-07-23 17:39:37 --> Total execution time: 0.2331
DEBUG - 2011-07-23 17:39:38 --> Config Class Initialized
DEBUG - 2011-07-23 17:39:38 --> Hooks Class Initialized
DEBUG - 2011-07-23 17:39:38 --> Utf8 Class Initialized
DEBUG - 2011-07-23 17:39:38 --> UTF-8 Support Enabled
DEBUG - 2011-07-23 17:39:38 --> URI Class Initialized
DEBUG - 2011-07-23 17:39:38 --> Router Class Initialized
DEBUG - 2011-07-23 17:39:38 --> Output Class Initialized
DEBUG - 2011-07-23 17:39:38 --> Input Class Initialized
DEBUG - 2011-07-23 17:39:38 --> Global POST and COOKIE data sanitized
DEBUG - 2011-07-23 17:39:38 --> Language Class Initialized
DEBUG - 2011-07-23 17:39:38 --> Loader Class Initialized
DEBUG - 2011-07-23 17:39:38 --> Controller Class Initialized
DEBUG - 2011-07-23 17:39:38 --> Model Class Initialized
DEBUG - 2011-07-23 17:39:38 --> Model Class Initialized
DEBUG - 2011-07-23 17:39:38 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-07-23 17:39:39 --> Database Driver Class Initialized
DEBUG - 2011-07-23 17:39:39 --> Final output sent to browser
DEBUG - 2011-07-23 17:39:39 --> Total execution time: 0.5915
DEBUG - 2011-07-23 19:34:52 --> Config Class Initialized
DEBUG - 2011-07-23 19:34:52 --> Hooks Class Initialized
DEBUG - 2011-07-23 19:34:52 --> Utf8 Class Initialized
DEBUG - 2011-07-23 19:34:52 --> UTF-8 Support Enabled
DEBUG - 2011-07-23 19:34:52 --> URI Class Initialized
DEBUG - 2011-07-23 19:34:52 --> Router Class Initialized
DEBUG - 2011-07-23 19:34:52 --> Output Class Initialized
DEBUG - 2011-07-23 19:34:52 --> Input Class Initialized
DEBUG - 2011-07-23 19:34:52 --> Global POST and COOKIE data sanitized
DEBUG - 2011-07-23 19:34:52 --> Language Class Initialized
DEBUG - 2011-07-23 19:34:52 --> Loader Class Initialized
DEBUG - 2011-07-23 19:34:52 --> Controller Class Initialized
DEBUG - 2011-07-23 19:34:52 --> Model Class Initialized
DEBUG - 2011-07-23 19:34:52 --> Model Class Initialized
DEBUG - 2011-07-23 19:34:52 --> Model Class Initialized
DEBUG - 2011-07-23 19:34:52 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-07-23 19:34:52 --> Database Driver Class Initialized
DEBUG - 2011-07-23 19:34:52 --> File loaded: application/views/table/main.php
DEBUG - 2011-07-23 19:34:52 --> Helper loaded: url_helper
DEBUG - 2011-07-23 19:34:52 --> File loaded: application/views/common/header.php
DEBUG - 2011-07-23 19:34:52 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-07-23 19:34:52 --> File loaded: application/views/common/footer.php
DEBUG - 2011-07-23 19:34:52 --> File loaded: application/views/layout/main.php
DEBUG - 2011-07-23 19:34:52 --> Final output sent to browser
DEBUG - 2011-07-23 19:34:52 --> Total execution time: 0.6409
DEBUG - 2011-07-23 19:34:56 --> Config Class Initialized
DEBUG - 2011-07-23 19:34:56 --> Hooks Class Initialized
DEBUG - 2011-07-23 19:34:56 --> Utf8 Class Initialized
DEBUG - 2011-07-23 19:34:56 --> UTF-8 Support Enabled
DEBUG - 2011-07-23 19:34:56 --> URI Class Initialized
DEBUG - 2011-07-23 19:34:56 --> Router Class Initialized
DEBUG - 2011-07-23 19:34:56 --> Config Class Initialized
DEBUG - 2011-07-23 19:34:56 --> Hooks Class Initialized
DEBUG - 2011-07-23 19:34:56 --> Utf8 Class Initialized
DEBUG - 2011-07-23 19:34:56 --> UTF-8 Support Enabled
DEBUG - 2011-07-23 19:34:56 --> URI Class Initialized
DEBUG - 2011-07-23 19:34:56 --> Router Class Initialized
DEBUG - 2011-07-23 19:34:56 --> Output Class Initialized
DEBUG - 2011-07-23 19:34:56 --> Input Class Initialized
DEBUG - 2011-07-23 19:34:56 --> Global POST and COOKIE data sanitized
DEBUG - 2011-07-23 19:34:56 --> Language Class Initialized
DEBUG - 2011-07-23 19:34:56 --> Loader Class Initialized
DEBUG - 2011-07-23 19:34:56 --> Controller Class Initialized
DEBUG - 2011-07-23 19:34:56 --> Model Class Initialized
DEBUG - 2011-07-23 19:34:56 --> Model Class Initialized
DEBUG - 2011-07-23 19:34:56 --> Model Class Initialized
ERROR - 2011-07-23 19:34:56 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-07-23 19:34:56 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-07-23 19:34:56 --> Database Driver Class Initialized
DEBUG - 2011-07-23 19:34:56 --> File loaded: application/views/table/main.php
DEBUG - 2011-07-23 19:34:56 --> Helper loaded: url_helper
DEBUG - 2011-07-23 19:34:56 --> File loaded: application/views/common/header.php
DEBUG - 2011-07-23 19:34:56 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-07-23 19:34:56 --> File loaded: application/views/common/footer.php
DEBUG - 2011-07-23 19:34:56 --> File loaded: application/views/layout/main.php
DEBUG - 2011-07-23 19:34:56 --> Final output sent to browser
DEBUG - 2011-07-23 19:34:56 --> Total execution time: 0.0504
DEBUG - 2011-07-23 19:34:57 --> Config Class Initialized
DEBUG - 2011-07-23 19:34:57 --> Hooks Class Initialized
DEBUG - 2011-07-23 19:34:57 --> Utf8 Class Initialized
DEBUG - 2011-07-23 19:34:57 --> UTF-8 Support Enabled
DEBUG - 2011-07-23 19:34:57 --> URI Class Initialized
DEBUG - 2011-07-23 19:34:57 --> Router Class Initialized
ERROR - 2011-07-23 19:34:57 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-07-23 19:34:58 --> Config Class Initialized
DEBUG - 2011-07-23 19:34:58 --> Hooks Class Initialized
DEBUG - 2011-07-23 19:34:58 --> Utf8 Class Initialized
DEBUG - 2011-07-23 19:34:58 --> UTF-8 Support Enabled
DEBUG - 2011-07-23 19:34:58 --> URI Class Initialized
DEBUG - 2011-07-23 19:34:58 --> Router Class Initialized
ERROR - 2011-07-23 19:34:58 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-07-23 20:19:54 --> Config Class Initialized
DEBUG - 2011-07-23 20:19:54 --> Hooks Class Initialized
DEBUG - 2011-07-23 20:19:54 --> Utf8 Class Initialized
DEBUG - 2011-07-23 20:19:54 --> UTF-8 Support Enabled
DEBUG - 2011-07-23 20:19:54 --> URI Class Initialized
DEBUG - 2011-07-23 20:19:54 --> Router Class Initialized
DEBUG - 2011-07-23 20:19:54 --> Output Class Initialized
DEBUG - 2011-07-23 20:19:54 --> Input Class Initialized
DEBUG - 2011-07-23 20:19:54 --> Global POST and COOKIE data sanitized
DEBUG - 2011-07-23 20:19:54 --> Language Class Initialized
DEBUG - 2011-07-23 20:19:54 --> Loader Class Initialized
DEBUG - 2011-07-23 20:19:54 --> Controller Class Initialized
ERROR - 2011-07-23 20:19:54 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-07-23 20:19:54 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-07-23 20:19:54 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-07-23 20:19:54 --> Model Class Initialized
DEBUG - 2011-07-23 20:19:54 --> Model Class Initialized
DEBUG - 2011-07-23 20:19:54 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-07-23 20:19:54 --> Database Driver Class Initialized
DEBUG - 2011-07-23 20:19:54 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-07-23 20:19:54 --> Helper loaded: url_helper
DEBUG - 2011-07-23 20:19:54 --> File loaded: application/views/common/header.php
DEBUG - 2011-07-23 20:19:54 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-07-23 20:19:54 --> File loaded: application/views/common/footer.php
DEBUG - 2011-07-23 20:19:54 --> File loaded: application/views/layout/main.php
DEBUG - 2011-07-23 20:19:54 --> Final output sent to browser
DEBUG - 2011-07-23 20:19:54 --> Total execution time: 0.2387
DEBUG - 2011-07-23 20:30:39 --> Config Class Initialized
DEBUG - 2011-07-23 20:30:39 --> Hooks Class Initialized
DEBUG - 2011-07-23 20:30:39 --> Utf8 Class Initialized
DEBUG - 2011-07-23 20:30:39 --> UTF-8 Support Enabled
DEBUG - 2011-07-23 20:30:39 --> URI Class Initialized
DEBUG - 2011-07-23 20:30:39 --> Router Class Initialized
DEBUG - 2011-07-23 20:30:39 --> Output Class Initialized
DEBUG - 2011-07-23 20:30:39 --> Input Class Initialized
DEBUG - 2011-07-23 20:30:39 --> Global POST and COOKIE data sanitized
DEBUG - 2011-07-23 20:30:39 --> Language Class Initialized
DEBUG - 2011-07-23 20:30:39 --> Loader Class Initialized
DEBUG - 2011-07-23 20:30:39 --> Controller Class Initialized
ERROR - 2011-07-23 20:30:39 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-07-23 20:30:39 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-07-23 20:30:39 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-07-23 20:30:39 --> Model Class Initialized
DEBUG - 2011-07-23 20:30:39 --> Model Class Initialized
DEBUG - 2011-07-23 20:30:39 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-07-23 20:30:39 --> Database Driver Class Initialized
DEBUG - 2011-07-23 20:30:39 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-07-23 20:30:39 --> Helper loaded: url_helper
DEBUG - 2011-07-23 20:30:39 --> File loaded: application/views/common/header.php
DEBUG - 2011-07-23 20:30:39 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-07-23 20:30:39 --> File loaded: application/views/common/footer.php
DEBUG - 2011-07-23 20:30:39 --> File loaded: application/views/layout/main.php
DEBUG - 2011-07-23 20:30:39 --> Final output sent to browser
DEBUG - 2011-07-23 20:30:39 --> Total execution time: 0.1173
DEBUG - 2011-07-23 20:30:40 --> Config Class Initialized
DEBUG - 2011-07-23 20:30:40 --> Hooks Class Initialized
DEBUG - 2011-07-23 20:30:40 --> Utf8 Class Initialized
DEBUG - 2011-07-23 20:30:40 --> UTF-8 Support Enabled
DEBUG - 2011-07-23 20:30:40 --> URI Class Initialized
DEBUG - 2011-07-23 20:30:40 --> Router Class Initialized
DEBUG - 2011-07-23 20:30:40 --> Output Class Initialized
DEBUG - 2011-07-23 20:30:40 --> Input Class Initialized
DEBUG - 2011-07-23 20:30:40 --> Global POST and COOKIE data sanitized
DEBUG - 2011-07-23 20:30:40 --> Language Class Initialized
DEBUG - 2011-07-23 20:30:40 --> Loader Class Initialized
DEBUG - 2011-07-23 20:30:40 --> Controller Class Initialized
DEBUG - 2011-07-23 20:30:40 --> Model Class Initialized
DEBUG - 2011-07-23 20:30:40 --> Model Class Initialized
DEBUG - 2011-07-23 20:30:40 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-07-23 20:30:40 --> Database Driver Class Initialized
DEBUG - 2011-07-23 20:30:41 --> Final output sent to browser
DEBUG - 2011-07-23 20:30:41 --> Total execution time: 0.6677
DEBUG - 2011-07-23 20:32:19 --> Config Class Initialized
DEBUG - 2011-07-23 20:32:19 --> Hooks Class Initialized
DEBUG - 2011-07-23 20:32:19 --> Utf8 Class Initialized
DEBUG - 2011-07-23 20:32:19 --> UTF-8 Support Enabled
DEBUG - 2011-07-23 20:32:19 --> URI Class Initialized
DEBUG - 2011-07-23 20:32:19 --> Router Class Initialized
DEBUG - 2011-07-23 20:32:19 --> Output Class Initialized
DEBUG - 2011-07-23 20:32:19 --> Input Class Initialized
DEBUG - 2011-07-23 20:32:19 --> Global POST and COOKIE data sanitized
DEBUG - 2011-07-23 20:32:19 --> Language Class Initialized
DEBUG - 2011-07-23 20:32:19 --> Loader Class Initialized
DEBUG - 2011-07-23 20:32:19 --> Controller Class Initialized
DEBUG - 2011-07-23 20:32:19 --> Model Class Initialized
DEBUG - 2011-07-23 20:32:19 --> Model Class Initialized
DEBUG - 2011-07-23 20:32:19 --> Model Class Initialized
DEBUG - 2011-07-23 20:32:19 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-07-23 20:32:19 --> Database Driver Class Initialized
DEBUG - 2011-07-23 20:32:19 --> File loaded: application/views/table/main.php
DEBUG - 2011-07-23 20:32:19 --> Helper loaded: url_helper
DEBUG - 2011-07-23 20:32:19 --> File loaded: application/views/common/header.php
DEBUG - 2011-07-23 20:32:19 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-07-23 20:32:19 --> File loaded: application/views/common/footer.php
DEBUG - 2011-07-23 20:32:19 --> File loaded: application/views/layout/main.php
DEBUG - 2011-07-23 20:32:19 --> Final output sent to browser
DEBUG - 2011-07-23 20:32:19 --> Total execution time: 0.2701
DEBUG - 2011-07-23 23:32:01 --> Config Class Initialized
DEBUG - 2011-07-23 23:32:01 --> Hooks Class Initialized
DEBUG - 2011-07-23 23:32:01 --> Utf8 Class Initialized
DEBUG - 2011-07-23 23:32:01 --> UTF-8 Support Enabled
DEBUG - 2011-07-23 23:32:01 --> URI Class Initialized
DEBUG - 2011-07-23 23:32:01 --> Router Class Initialized
ERROR - 2011-07-23 23:32:01 --> 404 Page Not Found --> robots.txt
DEBUG - 2011-07-23 23:33:48 --> Config Class Initialized
DEBUG - 2011-07-23 23:33:48 --> Hooks Class Initialized
DEBUG - 2011-07-23 23:33:48 --> Utf8 Class Initialized
DEBUG - 2011-07-23 23:33:48 --> UTF-8 Support Enabled
DEBUG - 2011-07-23 23:33:48 --> URI Class Initialized
DEBUG - 2011-07-23 23:33:48 --> Router Class Initialized
DEBUG - 2011-07-23 23:33:48 --> No URI present. Default controller set.
DEBUG - 2011-07-23 23:33:48 --> Output Class Initialized
DEBUG - 2011-07-23 23:33:48 --> Input Class Initialized
DEBUG - 2011-07-23 23:33:48 --> Global POST and COOKIE data sanitized
DEBUG - 2011-07-23 23:33:48 --> Language Class Initialized
DEBUG - 2011-07-23 23:33:48 --> Loader Class Initialized
DEBUG - 2011-07-23 23:33:48 --> Controller Class Initialized
DEBUG - 2011-07-23 23:33:48 --> File loaded: application/views/splash/main.php
DEBUG - 2011-07-23 23:33:48 --> Helper loaded: url_helper
DEBUG - 2011-07-23 23:33:48 --> File loaded: application/views/common/header.php
DEBUG - 2011-07-23 23:33:48 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-07-23 23:33:48 --> File loaded: application/views/common/footer.php
DEBUG - 2011-07-23 23:33:48 --> File loaded: application/views/layout/main.php
DEBUG - 2011-07-23 23:33:48 --> Final output sent to browser
DEBUG - 2011-07-23 23:33:48 --> Total execution time: 0.2064
DEBUG - 2011-07-23 23:35:42 --> Config Class Initialized
DEBUG - 2011-07-23 23:35:42 --> Hooks Class Initialized
DEBUG - 2011-07-23 23:35:42 --> Utf8 Class Initialized
DEBUG - 2011-07-23 23:35:42 --> UTF-8 Support Enabled
DEBUG - 2011-07-23 23:35:42 --> URI Class Initialized
DEBUG - 2011-07-23 23:35:42 --> Router Class Initialized
DEBUG - 2011-07-23 23:35:42 --> No URI present. Default controller set.
DEBUG - 2011-07-23 23:35:42 --> Output Class Initialized
DEBUG - 2011-07-23 23:35:42 --> Input Class Initialized
DEBUG - 2011-07-23 23:35:42 --> Global POST and COOKIE data sanitized
DEBUG - 2011-07-23 23:35:42 --> Language Class Initialized
DEBUG - 2011-07-23 23:35:42 --> Loader Class Initialized
DEBUG - 2011-07-23 23:35:42 --> Controller Class Initialized
DEBUG - 2011-07-23 23:35:42 --> File loaded: application/views/splash/main.php
DEBUG - 2011-07-23 23:35:42 --> Helper loaded: url_helper
DEBUG - 2011-07-23 23:35:42 --> File loaded: application/views/common/header.php
DEBUG - 2011-07-23 23:35:42 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-07-23 23:35:42 --> File loaded: application/views/common/footer.php
DEBUG - 2011-07-23 23:35:42 --> File loaded: application/views/layout/main.php
DEBUG - 2011-07-23 23:35:42 --> Final output sent to browser
DEBUG - 2011-07-23 23:35:42 --> Total execution time: 0.0690
DEBUG - 2011-07-23 23:35:42 --> Config Class Initialized
DEBUG - 2011-07-23 23:35:42 --> Hooks Class Initialized
DEBUG - 2011-07-23 23:35:42 --> Utf8 Class Initialized
DEBUG - 2011-07-23 23:35:42 --> UTF-8 Support Enabled
DEBUG - 2011-07-23 23:35:42 --> URI Class Initialized
DEBUG - 2011-07-23 23:35:42 --> Router Class Initialized
ERROR - 2011-07-23 23:35:42 --> 404 Page Not Found --> favicon.ico

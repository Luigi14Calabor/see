<?php  if ( ! defined('BASEPATH')) exit('No direct script access allowed'); ?>

DEBUG - 2011-04-23 00:03:47 --> Config Class Initialized
DEBUG - 2011-04-23 00:03:47 --> Hooks Class Initialized
DEBUG - 2011-04-23 00:03:47 --> Utf8 Class Initialized
DEBUG - 2011-04-23 00:03:47 --> UTF-8 Support Enabled
DEBUG - 2011-04-23 00:03:47 --> URI Class Initialized
DEBUG - 2011-04-23 00:03:47 --> Router Class Initialized
DEBUG - 2011-04-23 00:03:47 --> Output Class Initialized
DEBUG - 2011-04-23 00:03:47 --> Input Class Initialized
DEBUG - 2011-04-23 00:03:47 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-23 00:03:47 --> Language Class Initialized
DEBUG - 2011-04-23 00:03:47 --> Loader Class Initialized
DEBUG - 2011-04-23 00:03:47 --> Controller Class Initialized
DEBUG - 2011-04-23 00:03:47 --> Model Class Initialized
DEBUG - 2011-04-23 00:03:47 --> Model Class Initialized
DEBUG - 2011-04-23 00:03:47 --> Model Class Initialized
DEBUG - 2011-04-23 00:03:47 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-23 00:03:47 --> Database Driver Class Initialized
DEBUG - 2011-04-23 00:03:47 --> File loaded: application/views/table/main.php
DEBUG - 2011-04-23 00:03:47 --> Helper loaded: url_helper
DEBUG - 2011-04-23 00:03:47 --> File loaded: application/views/common/header.php
DEBUG - 2011-04-23 00:03:47 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-04-23 00:03:47 --> File loaded: application/views/common/footer.php
DEBUG - 2011-04-23 00:03:47 --> File loaded: application/views/layout/main.php
DEBUG - 2011-04-23 00:03:47 --> Final output sent to browser
DEBUG - 2011-04-23 00:03:47 --> Total execution time: 0.5196
DEBUG - 2011-04-23 01:37:23 --> Config Class Initialized
DEBUG - 2011-04-23 01:37:23 --> Hooks Class Initialized
DEBUG - 2011-04-23 01:37:23 --> Utf8 Class Initialized
DEBUG - 2011-04-23 01:37:23 --> UTF-8 Support Enabled
DEBUG - 2011-04-23 01:37:23 --> URI Class Initialized
DEBUG - 2011-04-23 01:37:23 --> Router Class Initialized
DEBUG - 2011-04-23 01:37:23 --> Output Class Initialized
DEBUG - 2011-04-23 01:37:23 --> Input Class Initialized
DEBUG - 2011-04-23 01:37:23 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-23 01:37:23 --> Language Class Initialized
DEBUG - 2011-04-23 01:37:23 --> Loader Class Initialized
DEBUG - 2011-04-23 01:37:23 --> Controller Class Initialized
ERROR - 2011-04-23 01:37:23 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-04-23 01:37:23 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-04-23 01:37:23 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-04-23 01:37:23 --> Model Class Initialized
DEBUG - 2011-04-23 01:37:23 --> Model Class Initialized
DEBUG - 2011-04-23 01:37:23 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-23 01:37:23 --> Database Driver Class Initialized
DEBUG - 2011-04-23 01:37:23 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-04-23 01:37:23 --> Helper loaded: url_helper
DEBUG - 2011-04-23 01:37:23 --> File loaded: application/views/common/header.php
DEBUG - 2011-04-23 01:37:23 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-04-23 01:37:23 --> File loaded: application/views/common/footer.php
DEBUG - 2011-04-23 01:37:23 --> File loaded: application/views/layout/main.php
DEBUG - 2011-04-23 01:37:23 --> Final output sent to browser
DEBUG - 2011-04-23 01:37:23 --> Total execution time: 0.5076
DEBUG - 2011-04-23 01:45:26 --> Config Class Initialized
DEBUG - 2011-04-23 01:45:26 --> Config Class Initialized
DEBUG - 2011-04-23 01:45:26 --> Hooks Class Initialized
DEBUG - 2011-04-23 01:45:26 --> Hooks Class Initialized
DEBUG - 2011-04-23 01:45:26 --> Utf8 Class Initialized
DEBUG - 2011-04-23 01:45:26 --> Utf8 Class Initialized
DEBUG - 2011-04-23 01:45:26 --> UTF-8 Support Enabled
DEBUG - 2011-04-23 01:45:26 --> UTF-8 Support Enabled
DEBUG - 2011-04-23 01:45:26 --> URI Class Initialized
DEBUG - 2011-04-23 01:45:26 --> URI Class Initialized
DEBUG - 2011-04-23 01:45:26 --> Router Class Initialized
DEBUG - 2011-04-23 01:45:26 --> Router Class Initialized
DEBUG - 2011-04-23 01:45:27 --> Output Class Initialized
DEBUG - 2011-04-23 01:45:27 --> Output Class Initialized
DEBUG - 2011-04-23 01:45:27 --> Input Class Initialized
DEBUG - 2011-04-23 01:45:27 --> Input Class Initialized
DEBUG - 2011-04-23 01:45:27 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-23 01:45:27 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-23 01:45:27 --> Language Class Initialized
DEBUG - 2011-04-23 01:45:27 --> Language Class Initialized
DEBUG - 2011-04-23 01:45:27 --> Loader Class Initialized
DEBUG - 2011-04-23 01:45:27 --> Loader Class Initialized
DEBUG - 2011-04-23 01:45:27 --> Controller Class Initialized
DEBUG - 2011-04-23 01:45:27 --> Controller Class Initialized
DEBUG - 2011-04-23 01:45:28 --> Model Class Initialized
DEBUG - 2011-04-23 01:45:28 --> Model Class Initialized
DEBUG - 2011-04-23 01:45:28 --> Model Class Initialized
DEBUG - 2011-04-23 01:45:28 --> Model Class Initialized
DEBUG - 2011-04-23 01:45:28 --> Model Class Initialized
DEBUG - 2011-04-23 01:45:28 --> Model Class Initialized
DEBUG - 2011-04-23 01:45:29 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-23 01:45:29 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-23 01:45:30 --> Database Driver Class Initialized
DEBUG - 2011-04-23 01:45:30 --> Database Driver Class Initialized
DEBUG - 2011-04-23 01:45:31 --> Config Class Initialized
DEBUG - 2011-04-23 01:45:31 --> Hooks Class Initialized
DEBUG - 2011-04-23 01:45:31 --> Utf8 Class Initialized
DEBUG - 2011-04-23 01:45:31 --> UTF-8 Support Enabled
DEBUG - 2011-04-23 01:45:31 --> URI Class Initialized
DEBUG - 2011-04-23 01:45:31 --> Router Class Initialized
DEBUG - 2011-04-23 01:45:31 --> Output Class Initialized
DEBUG - 2011-04-23 01:45:31 --> Input Class Initialized
DEBUG - 2011-04-23 01:45:31 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-23 01:45:31 --> Language Class Initialized
DEBUG - 2011-04-23 01:45:31 --> Loader Class Initialized
DEBUG - 2011-04-23 01:45:31 --> Controller Class Initialized
DEBUG - 2011-04-23 01:45:31 --> Model Class Initialized
DEBUG - 2011-04-23 01:45:31 --> Model Class Initialized
DEBUG - 2011-04-23 01:45:31 --> Model Class Initialized
DEBUG - 2011-04-23 01:45:31 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-23 01:45:31 --> Database Driver Class Initialized
DEBUG - 2011-04-23 01:45:33 --> File loaded: application/views/table/main.php
DEBUG - 2011-04-23 01:45:33 --> File loaded: application/views/table/main.php
DEBUG - 2011-04-23 01:45:33 --> Helper loaded: url_helper
DEBUG - 2011-04-23 01:45:33 --> File loaded: application/views/common/header.php
DEBUG - 2011-04-23 01:45:33 --> Helper loaded: url_helper
DEBUG - 2011-04-23 01:45:33 --> File loaded: application/views/common/header.php
DEBUG - 2011-04-23 01:45:33 --> File loaded: application/views/table/main.php
DEBUG - 2011-04-23 01:45:33 --> Helper loaded: url_helper
DEBUG - 2011-04-23 01:45:33 --> File loaded: application/views/common/header.php
DEBUG - 2011-04-23 01:45:33 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-04-23 01:45:33 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-04-23 01:45:33 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-04-23 01:45:33 --> File loaded: application/views/common/footer.php
DEBUG - 2011-04-23 01:45:33 --> File loaded: application/views/layout/main.php
DEBUG - 2011-04-23 01:45:33 --> Final output sent to browser
DEBUG - 2011-04-23 01:45:33 --> Total execution time: 2.6110
DEBUG - 2011-04-23 01:45:33 --> File loaded: application/views/common/footer.php
DEBUG - 2011-04-23 01:45:33 --> File loaded: application/views/layout/main.php
DEBUG - 2011-04-23 01:45:33 --> Final output sent to browser
DEBUG - 2011-04-23 01:45:33 --> Total execution time: 8.8235
DEBUG - 2011-04-23 01:45:33 --> File loaded: application/views/common/footer.php
DEBUG - 2011-04-23 01:45:33 --> File loaded: application/views/layout/main.php
DEBUG - 2011-04-23 01:45:33 --> Final output sent to browser
DEBUG - 2011-04-23 01:45:33 --> Total execution time: 8.8294
DEBUG - 2011-04-23 01:45:35 --> Config Class Initialized
DEBUG - 2011-04-23 01:45:35 --> Hooks Class Initialized
DEBUG - 2011-04-23 01:45:35 --> Utf8 Class Initialized
DEBUG - 2011-04-23 01:45:35 --> UTF-8 Support Enabled
DEBUG - 2011-04-23 01:45:35 --> URI Class Initialized
DEBUG - 2011-04-23 01:45:35 --> Router Class Initialized
DEBUG - 2011-04-23 01:45:35 --> Config Class Initialized
DEBUG - 2011-04-23 01:45:35 --> Hooks Class Initialized
DEBUG - 2011-04-23 01:45:35 --> Utf8 Class Initialized
DEBUG - 2011-04-23 01:45:35 --> UTF-8 Support Enabled
DEBUG - 2011-04-23 01:45:35 --> Output Class Initialized
DEBUG - 2011-04-23 01:45:35 --> URI Class Initialized
DEBUG - 2011-04-23 01:45:35 --> Input Class Initialized
DEBUG - 2011-04-23 01:45:35 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-23 01:45:35 --> Language Class Initialized
DEBUG - 2011-04-23 01:45:35 --> Loader Class Initialized
DEBUG - 2011-04-23 01:45:35 --> Controller Class Initialized
DEBUG - 2011-04-23 01:45:35 --> Model Class Initialized
DEBUG - 2011-04-23 01:45:35 --> Model Class Initialized
DEBUG - 2011-04-23 01:45:35 --> Router Class Initialized
DEBUG - 2011-04-23 01:45:35 --> Model Class Initialized
DEBUG - 2011-04-23 01:45:35 --> Database config for development environment is not found. Trying global config.
ERROR - 2011-04-23 01:45:35 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-04-23 01:45:35 --> Database Driver Class Initialized
DEBUG - 2011-04-23 01:45:35 --> File loaded: application/views/table/main.php
DEBUG - 2011-04-23 01:45:35 --> Helper loaded: url_helper
DEBUG - 2011-04-23 01:45:35 --> File loaded: application/views/common/header.php
DEBUG - 2011-04-23 01:45:35 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-04-23 01:45:35 --> File loaded: application/views/common/footer.php
DEBUG - 2011-04-23 01:45:35 --> File loaded: application/views/layout/main.php
DEBUG - 2011-04-23 01:45:35 --> Final output sent to browser
DEBUG - 2011-04-23 01:45:35 --> Total execution time: 0.1420
DEBUG - 2011-04-23 01:45:37 --> Config Class Initialized
DEBUG - 2011-04-23 01:45:37 --> Hooks Class Initialized
DEBUG - 2011-04-23 01:45:37 --> Utf8 Class Initialized
DEBUG - 2011-04-23 01:45:37 --> UTF-8 Support Enabled
DEBUG - 2011-04-23 01:45:37 --> URI Class Initialized
DEBUG - 2011-04-23 01:45:37 --> Router Class Initialized
ERROR - 2011-04-23 01:45:37 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-04-23 01:45:38 --> Config Class Initialized
DEBUG - 2011-04-23 01:45:38 --> Hooks Class Initialized
DEBUG - 2011-04-23 01:45:38 --> Utf8 Class Initialized
DEBUG - 2011-04-23 01:45:38 --> UTF-8 Support Enabled
DEBUG - 2011-04-23 01:45:38 --> URI Class Initialized
DEBUG - 2011-04-23 01:45:38 --> Router Class Initialized
DEBUG - 2011-04-23 01:45:38 --> Output Class Initialized
DEBUG - 2011-04-23 01:45:38 --> Input Class Initialized
DEBUG - 2011-04-23 01:45:38 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-23 01:45:38 --> Language Class Initialized
DEBUG - 2011-04-23 01:45:38 --> Loader Class Initialized
DEBUG - 2011-04-23 01:45:38 --> Controller Class Initialized
DEBUG - 2011-04-23 01:45:38 --> Model Class Initialized
DEBUG - 2011-04-23 01:45:38 --> Model Class Initialized
DEBUG - 2011-04-23 01:45:38 --> Model Class Initialized
DEBUG - 2011-04-23 01:45:38 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-23 01:45:38 --> Database Driver Class Initialized
DEBUG - 2011-04-23 01:45:38 --> File loaded: application/views/table/main.php
DEBUG - 2011-04-23 01:45:38 --> Helper loaded: url_helper
DEBUG - 2011-04-23 01:45:38 --> File loaded: application/views/common/header.php
DEBUG - 2011-04-23 01:45:38 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-04-23 01:45:38 --> File loaded: application/views/common/footer.php
DEBUG - 2011-04-23 01:45:38 --> File loaded: application/views/layout/main.php
DEBUG - 2011-04-23 01:45:38 --> Final output sent to browser
DEBUG - 2011-04-23 01:45:38 --> Total execution time: 0.0820
DEBUG - 2011-04-23 01:45:58 --> Config Class Initialized
DEBUG - 2011-04-23 01:45:58 --> Hooks Class Initialized
DEBUG - 2011-04-23 01:45:58 --> Utf8 Class Initialized
DEBUG - 2011-04-23 01:45:58 --> UTF-8 Support Enabled
DEBUG - 2011-04-23 01:45:58 --> URI Class Initialized
DEBUG - 2011-04-23 01:45:58 --> Router Class Initialized
DEBUG - 2011-04-23 01:45:58 --> Output Class Initialized
DEBUG - 2011-04-23 01:45:58 --> Input Class Initialized
DEBUG - 2011-04-23 01:45:58 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-23 01:45:58 --> Language Class Initialized
DEBUG - 2011-04-23 01:45:58 --> Loader Class Initialized
DEBUG - 2011-04-23 01:45:58 --> Controller Class Initialized
DEBUG - 2011-04-23 01:45:58 --> Model Class Initialized
DEBUG - 2011-04-23 01:45:58 --> Model Class Initialized
DEBUG - 2011-04-23 01:45:58 --> Model Class Initialized
DEBUG - 2011-04-23 01:45:58 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-23 01:45:58 --> Database Driver Class Initialized
DEBUG - 2011-04-23 01:46:01 --> File loaded: application/views/table/main.php
DEBUG - 2011-04-23 01:46:01 --> Helper loaded: url_helper
DEBUG - 2011-04-23 01:46:01 --> File loaded: application/views/common/header.php
DEBUG - 2011-04-23 01:46:01 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-04-23 01:46:01 --> File loaded: application/views/common/footer.php
DEBUG - 2011-04-23 01:46:01 --> File loaded: application/views/layout/main.php
DEBUG - 2011-04-23 01:46:01 --> Final output sent to browser
DEBUG - 2011-04-23 01:46:01 --> Total execution time: 3.1135
DEBUG - 2011-04-23 01:46:05 --> Config Class Initialized
DEBUG - 2011-04-23 01:46:05 --> Hooks Class Initialized
DEBUG - 2011-04-23 01:46:05 --> Utf8 Class Initialized
DEBUG - 2011-04-23 01:46:05 --> UTF-8 Support Enabled
DEBUG - 2011-04-23 01:46:05 --> URI Class Initialized
DEBUG - 2011-04-23 01:46:05 --> Router Class Initialized
DEBUG - 2011-04-23 01:46:05 --> Output Class Initialized
DEBUG - 2011-04-23 01:46:05 --> Input Class Initialized
DEBUG - 2011-04-23 01:46:05 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-23 01:46:05 --> Language Class Initialized
DEBUG - 2011-04-23 01:46:05 --> Loader Class Initialized
DEBUG - 2011-04-23 01:46:05 --> Controller Class Initialized
DEBUG - 2011-04-23 01:46:05 --> Model Class Initialized
DEBUG - 2011-04-23 01:46:05 --> Model Class Initialized
DEBUG - 2011-04-23 01:46:05 --> Model Class Initialized
DEBUG - 2011-04-23 01:46:05 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-23 01:46:05 --> Database Driver Class Initialized
DEBUG - 2011-04-23 01:46:05 --> File loaded: application/views/table/main.php
DEBUG - 2011-04-23 01:46:05 --> Helper loaded: url_helper
DEBUG - 2011-04-23 01:46:05 --> File loaded: application/views/common/header.php
DEBUG - 2011-04-23 01:46:05 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-04-23 01:46:05 --> File loaded: application/views/common/footer.php
DEBUG - 2011-04-23 01:46:05 --> File loaded: application/views/layout/main.php
DEBUG - 2011-04-23 01:46:05 --> Final output sent to browser
DEBUG - 2011-04-23 01:46:05 --> Total execution time: 0.0749
DEBUG - 2011-04-23 01:46:15 --> Config Class Initialized
DEBUG - 2011-04-23 01:46:15 --> Hooks Class Initialized
DEBUG - 2011-04-23 01:46:15 --> Utf8 Class Initialized
DEBUG - 2011-04-23 01:46:15 --> UTF-8 Support Enabled
DEBUG - 2011-04-23 01:46:15 --> URI Class Initialized
DEBUG - 2011-04-23 01:46:15 --> Router Class Initialized
DEBUG - 2011-04-23 01:46:15 --> Output Class Initialized
DEBUG - 2011-04-23 01:46:15 --> Input Class Initialized
DEBUG - 2011-04-23 01:46:15 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-23 01:46:15 --> Language Class Initialized
DEBUG - 2011-04-23 01:46:15 --> Loader Class Initialized
DEBUG - 2011-04-23 01:46:15 --> Controller Class Initialized
DEBUG - 2011-04-23 01:46:15 --> Model Class Initialized
DEBUG - 2011-04-23 01:46:15 --> Model Class Initialized
DEBUG - 2011-04-23 01:46:15 --> Model Class Initialized
DEBUG - 2011-04-23 01:46:15 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-23 01:46:15 --> Database Driver Class Initialized
DEBUG - 2011-04-23 01:46:16 --> File loaded: application/views/table/main.php
DEBUG - 2011-04-23 01:46:16 --> Helper loaded: url_helper
DEBUG - 2011-04-23 01:46:16 --> File loaded: application/views/common/header.php
DEBUG - 2011-04-23 01:46:16 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-04-23 01:46:16 --> File loaded: application/views/common/footer.php
DEBUG - 2011-04-23 01:46:16 --> File loaded: application/views/layout/main.php
DEBUG - 2011-04-23 01:46:16 --> Final output sent to browser
DEBUG - 2011-04-23 01:46:16 --> Total execution time: 0.5498
DEBUG - 2011-04-23 01:46:18 --> Config Class Initialized
DEBUG - 2011-04-23 01:46:18 --> Hooks Class Initialized
DEBUG - 2011-04-23 01:46:18 --> Utf8 Class Initialized
DEBUG - 2011-04-23 01:46:18 --> UTF-8 Support Enabled
DEBUG - 2011-04-23 01:46:18 --> URI Class Initialized
DEBUG - 2011-04-23 01:46:18 --> Router Class Initialized
DEBUG - 2011-04-23 01:46:18 --> Output Class Initialized
DEBUG - 2011-04-23 01:46:18 --> Input Class Initialized
DEBUG - 2011-04-23 01:46:18 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-23 01:46:18 --> Language Class Initialized
DEBUG - 2011-04-23 01:46:18 --> Loader Class Initialized
DEBUG - 2011-04-23 01:46:18 --> Controller Class Initialized
DEBUG - 2011-04-23 01:46:18 --> Model Class Initialized
DEBUG - 2011-04-23 01:46:18 --> Model Class Initialized
DEBUG - 2011-04-23 01:46:18 --> Model Class Initialized
DEBUG - 2011-04-23 01:46:18 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-23 01:46:18 --> Database Driver Class Initialized
DEBUG - 2011-04-23 01:46:18 --> File loaded: application/views/table/main.php
DEBUG - 2011-04-23 01:46:18 --> Helper loaded: url_helper
DEBUG - 2011-04-23 01:46:18 --> File loaded: application/views/common/header.php
DEBUG - 2011-04-23 01:46:18 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-04-23 01:46:18 --> File loaded: application/views/common/footer.php
DEBUG - 2011-04-23 01:46:18 --> File loaded: application/views/layout/main.php
DEBUG - 2011-04-23 01:46:18 --> Final output sent to browser
DEBUG - 2011-04-23 01:46:18 --> Total execution time: 0.0513
DEBUG - 2011-04-23 01:47:35 --> Config Class Initialized
DEBUG - 2011-04-23 01:47:35 --> Hooks Class Initialized
DEBUG - 2011-04-23 01:47:35 --> Utf8 Class Initialized
DEBUG - 2011-04-23 01:47:35 --> UTF-8 Support Enabled
DEBUG - 2011-04-23 01:47:35 --> URI Class Initialized
DEBUG - 2011-04-23 01:47:35 --> Router Class Initialized
DEBUG - 2011-04-23 01:47:35 --> Output Class Initialized
DEBUG - 2011-04-23 01:47:35 --> Input Class Initialized
DEBUG - 2011-04-23 01:47:35 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-23 01:47:35 --> Language Class Initialized
DEBUG - 2011-04-23 01:47:35 --> Loader Class Initialized
DEBUG - 2011-04-23 01:47:35 --> Controller Class Initialized
DEBUG - 2011-04-23 01:47:35 --> Model Class Initialized
DEBUG - 2011-04-23 01:47:35 --> Model Class Initialized
DEBUG - 2011-04-23 01:47:35 --> Model Class Initialized
DEBUG - 2011-04-23 01:47:35 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-23 01:47:35 --> Database Driver Class Initialized
DEBUG - 2011-04-23 01:47:38 --> File loaded: application/views/table/main.php
DEBUG - 2011-04-23 01:47:38 --> Helper loaded: url_helper
DEBUG - 2011-04-23 01:47:38 --> File loaded: application/views/common/header.php
DEBUG - 2011-04-23 01:47:38 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-04-23 01:47:38 --> File loaded: application/views/common/footer.php
DEBUG - 2011-04-23 01:47:38 --> File loaded: application/views/layout/main.php
DEBUG - 2011-04-23 01:47:38 --> Final output sent to browser
DEBUG - 2011-04-23 01:47:38 --> Total execution time: 3.5191
DEBUG - 2011-04-23 01:47:42 --> Config Class Initialized
DEBUG - 2011-04-23 01:47:42 --> Hooks Class Initialized
DEBUG - 2011-04-23 01:47:42 --> Utf8 Class Initialized
DEBUG - 2011-04-23 01:47:42 --> UTF-8 Support Enabled
DEBUG - 2011-04-23 01:47:42 --> URI Class Initialized
DEBUG - 2011-04-23 01:47:42 --> Router Class Initialized
DEBUG - 2011-04-23 01:47:42 --> Output Class Initialized
DEBUG - 2011-04-23 01:47:42 --> Input Class Initialized
DEBUG - 2011-04-23 01:47:42 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-23 01:47:42 --> Language Class Initialized
DEBUG - 2011-04-23 01:47:42 --> Loader Class Initialized
DEBUG - 2011-04-23 01:47:42 --> Controller Class Initialized
DEBUG - 2011-04-23 01:47:42 --> Model Class Initialized
DEBUG - 2011-04-23 01:47:42 --> Model Class Initialized
DEBUG - 2011-04-23 01:47:42 --> Model Class Initialized
DEBUG - 2011-04-23 01:47:42 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-23 01:47:43 --> Database Driver Class Initialized
DEBUG - 2011-04-23 01:47:43 --> File loaded: application/views/table/main.php
DEBUG - 2011-04-23 01:47:43 --> Helper loaded: url_helper
DEBUG - 2011-04-23 01:47:43 --> File loaded: application/views/common/header.php
DEBUG - 2011-04-23 01:47:43 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-04-23 01:47:43 --> File loaded: application/views/common/footer.php
DEBUG - 2011-04-23 01:47:43 --> File loaded: application/views/layout/main.php
DEBUG - 2011-04-23 01:47:43 --> Final output sent to browser
DEBUG - 2011-04-23 01:47:43 --> Total execution time: 0.1762
DEBUG - 2011-04-23 01:47:51 --> Config Class Initialized
DEBUG - 2011-04-23 01:47:51 --> Hooks Class Initialized
DEBUG - 2011-04-23 01:47:51 --> Utf8 Class Initialized
DEBUG - 2011-04-23 01:47:51 --> UTF-8 Support Enabled
DEBUG - 2011-04-23 01:47:51 --> URI Class Initialized
DEBUG - 2011-04-23 01:47:51 --> Router Class Initialized
DEBUG - 2011-04-23 01:47:51 --> Output Class Initialized
DEBUG - 2011-04-23 01:47:51 --> Input Class Initialized
DEBUG - 2011-04-23 01:47:51 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-23 01:47:51 --> Language Class Initialized
DEBUG - 2011-04-23 01:47:51 --> Loader Class Initialized
DEBUG - 2011-04-23 01:47:51 --> Controller Class Initialized
DEBUG - 2011-04-23 01:47:51 --> Model Class Initialized
DEBUG - 2011-04-23 01:47:51 --> Model Class Initialized
DEBUG - 2011-04-23 01:47:51 --> Model Class Initialized
DEBUG - 2011-04-23 01:47:51 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-23 01:47:51 --> Database Driver Class Initialized
DEBUG - 2011-04-23 01:47:53 --> File loaded: application/views/table/main.php
DEBUG - 2011-04-23 01:47:53 --> Helper loaded: url_helper
DEBUG - 2011-04-23 01:47:53 --> File loaded: application/views/common/header.php
DEBUG - 2011-04-23 01:47:53 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-04-23 01:47:53 --> File loaded: application/views/common/footer.php
DEBUG - 2011-04-23 01:47:53 --> File loaded: application/views/layout/main.php
DEBUG - 2011-04-23 01:47:53 --> Final output sent to browser
DEBUG - 2011-04-23 01:47:53 --> Total execution time: 1.9605
DEBUG - 2011-04-23 01:47:55 --> Config Class Initialized
DEBUG - 2011-04-23 01:47:55 --> Hooks Class Initialized
DEBUG - 2011-04-23 01:47:55 --> Utf8 Class Initialized
DEBUG - 2011-04-23 01:47:55 --> UTF-8 Support Enabled
DEBUG - 2011-04-23 01:47:55 --> URI Class Initialized
DEBUG - 2011-04-23 01:47:55 --> Router Class Initialized
DEBUG - 2011-04-23 01:47:55 --> Output Class Initialized
DEBUG - 2011-04-23 01:47:55 --> Input Class Initialized
DEBUG - 2011-04-23 01:47:55 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-23 01:47:55 --> Language Class Initialized
DEBUG - 2011-04-23 01:47:55 --> Loader Class Initialized
DEBUG - 2011-04-23 01:47:55 --> Controller Class Initialized
DEBUG - 2011-04-23 01:47:55 --> Model Class Initialized
DEBUG - 2011-04-23 01:47:55 --> Model Class Initialized
DEBUG - 2011-04-23 01:47:55 --> Model Class Initialized
DEBUG - 2011-04-23 01:47:55 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-23 01:47:55 --> Database Driver Class Initialized
DEBUG - 2011-04-23 01:47:55 --> File loaded: application/views/table/main.php
DEBUG - 2011-04-23 01:47:55 --> Helper loaded: url_helper
DEBUG - 2011-04-23 01:47:55 --> File loaded: application/views/common/header.php
DEBUG - 2011-04-23 01:47:55 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-04-23 01:47:55 --> File loaded: application/views/common/footer.php
DEBUG - 2011-04-23 01:47:55 --> File loaded: application/views/layout/main.php
DEBUG - 2011-04-23 01:47:55 --> Final output sent to browser
DEBUG - 2011-04-23 01:47:55 --> Total execution time: 0.0749
DEBUG - 2011-04-23 01:54:11 --> Config Class Initialized
DEBUG - 2011-04-23 01:54:11 --> Hooks Class Initialized
DEBUG - 2011-04-23 01:54:11 --> Utf8 Class Initialized
DEBUG - 2011-04-23 01:54:11 --> UTF-8 Support Enabled
DEBUG - 2011-04-23 01:54:11 --> URI Class Initialized
DEBUG - 2011-04-23 01:54:11 --> Router Class Initialized
DEBUG - 2011-04-23 01:54:11 --> Output Class Initialized
DEBUG - 2011-04-23 01:54:11 --> Input Class Initialized
DEBUG - 2011-04-23 01:54:11 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-23 01:54:11 --> Language Class Initialized
DEBUG - 2011-04-23 01:54:11 --> Loader Class Initialized
DEBUG - 2011-04-23 01:54:11 --> Controller Class Initialized
DEBUG - 2011-04-23 01:54:11 --> Model Class Initialized
DEBUG - 2011-04-23 01:54:11 --> Model Class Initialized
DEBUG - 2011-04-23 01:54:11 --> Model Class Initialized
DEBUG - 2011-04-23 01:54:11 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-23 01:54:11 --> Database Driver Class Initialized
DEBUG - 2011-04-23 01:54:12 --> File loaded: application/views/table/main.php
DEBUG - 2011-04-23 01:54:12 --> Helper loaded: url_helper
DEBUG - 2011-04-23 01:54:12 --> File loaded: application/views/common/header.php
DEBUG - 2011-04-23 01:54:12 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-04-23 01:54:12 --> File loaded: application/views/common/footer.php
DEBUG - 2011-04-23 01:54:12 --> File loaded: application/views/layout/main.php
DEBUG - 2011-04-23 01:54:12 --> Final output sent to browser
DEBUG - 2011-04-23 01:54:12 --> Total execution time: 0.5910
DEBUG - 2011-04-23 01:54:15 --> Config Class Initialized
DEBUG - 2011-04-23 01:54:15 --> Hooks Class Initialized
DEBUG - 2011-04-23 01:54:15 --> Utf8 Class Initialized
DEBUG - 2011-04-23 01:54:15 --> UTF-8 Support Enabled
DEBUG - 2011-04-23 01:54:15 --> URI Class Initialized
DEBUG - 2011-04-23 01:54:15 --> Router Class Initialized
DEBUG - 2011-04-23 01:54:15 --> Output Class Initialized
DEBUG - 2011-04-23 01:54:15 --> Input Class Initialized
DEBUG - 2011-04-23 01:54:15 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-23 01:54:15 --> Language Class Initialized
DEBUG - 2011-04-23 01:54:15 --> Loader Class Initialized
DEBUG - 2011-04-23 01:54:15 --> Controller Class Initialized
DEBUG - 2011-04-23 01:54:15 --> Model Class Initialized
DEBUG - 2011-04-23 01:54:15 --> Model Class Initialized
DEBUG - 2011-04-23 01:54:15 --> Model Class Initialized
DEBUG - 2011-04-23 01:54:15 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-23 01:54:15 --> Database Driver Class Initialized
DEBUG - 2011-04-23 01:54:15 --> File loaded: application/views/table/main.php
DEBUG - 2011-04-23 01:54:15 --> Helper loaded: url_helper
DEBUG - 2011-04-23 01:54:15 --> File loaded: application/views/common/header.php
DEBUG - 2011-04-23 01:54:15 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-04-23 01:54:15 --> File loaded: application/views/common/footer.php
DEBUG - 2011-04-23 01:54:15 --> File loaded: application/views/layout/main.php
DEBUG - 2011-04-23 01:54:15 --> Final output sent to browser
DEBUG - 2011-04-23 01:54:15 --> Total execution time: 0.0464
DEBUG - 2011-04-23 01:54:28 --> Config Class Initialized
DEBUG - 2011-04-23 01:54:28 --> Hooks Class Initialized
DEBUG - 2011-04-23 01:54:28 --> Utf8 Class Initialized
DEBUG - 2011-04-23 01:54:28 --> UTF-8 Support Enabled
DEBUG - 2011-04-23 01:54:28 --> URI Class Initialized
DEBUG - 2011-04-23 01:54:28 --> Router Class Initialized
DEBUG - 2011-04-23 01:54:28 --> Output Class Initialized
DEBUG - 2011-04-23 01:54:28 --> Input Class Initialized
DEBUG - 2011-04-23 01:54:28 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-23 01:54:28 --> Language Class Initialized
DEBUG - 2011-04-23 01:54:28 --> Loader Class Initialized
DEBUG - 2011-04-23 01:54:28 --> Controller Class Initialized
DEBUG - 2011-04-23 01:54:28 --> Model Class Initialized
DEBUG - 2011-04-23 01:54:28 --> Model Class Initialized
DEBUG - 2011-04-23 01:54:28 --> Model Class Initialized
DEBUG - 2011-04-23 01:54:28 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-23 01:54:28 --> Database Driver Class Initialized
DEBUG - 2011-04-23 01:54:34 --> File loaded: application/views/table/main.php
DEBUG - 2011-04-23 01:54:34 --> Helper loaded: url_helper
DEBUG - 2011-04-23 01:54:34 --> File loaded: application/views/common/header.php
DEBUG - 2011-04-23 01:54:34 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-04-23 01:54:34 --> File loaded: application/views/common/footer.php
DEBUG - 2011-04-23 01:54:34 --> File loaded: application/views/layout/main.php
DEBUG - 2011-04-23 01:54:34 --> Final output sent to browser
DEBUG - 2011-04-23 01:54:34 --> Total execution time: 5.1013
DEBUG - 2011-04-23 01:54:43 --> Config Class Initialized
DEBUG - 2011-04-23 01:54:43 --> Hooks Class Initialized
DEBUG - 2011-04-23 01:54:43 --> Utf8 Class Initialized
DEBUG - 2011-04-23 01:54:43 --> UTF-8 Support Enabled
DEBUG - 2011-04-23 01:54:43 --> URI Class Initialized
DEBUG - 2011-04-23 01:54:43 --> Router Class Initialized
DEBUG - 2011-04-23 01:54:43 --> Output Class Initialized
DEBUG - 2011-04-23 01:54:43 --> Input Class Initialized
DEBUG - 2011-04-23 01:54:43 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-23 01:54:43 --> Language Class Initialized
DEBUG - 2011-04-23 01:54:43 --> Loader Class Initialized
DEBUG - 2011-04-23 01:54:43 --> Controller Class Initialized
DEBUG - 2011-04-23 01:54:43 --> Model Class Initialized
DEBUG - 2011-04-23 01:54:43 --> Model Class Initialized
DEBUG - 2011-04-23 01:54:43 --> Model Class Initialized
DEBUG - 2011-04-23 01:54:43 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-23 01:54:43 --> Database Driver Class Initialized
DEBUG - 2011-04-23 01:54:43 --> File loaded: application/views/table/main.php
DEBUG - 2011-04-23 01:54:43 --> Helper loaded: url_helper
DEBUG - 2011-04-23 01:54:43 --> File loaded: application/views/common/header.php
DEBUG - 2011-04-23 01:54:43 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-04-23 01:54:43 --> File loaded: application/views/common/footer.php
DEBUG - 2011-04-23 01:54:43 --> File loaded: application/views/layout/main.php
DEBUG - 2011-04-23 01:54:43 --> Final output sent to browser
DEBUG - 2011-04-23 01:54:43 --> Total execution time: 0.2559
DEBUG - 2011-04-23 01:54:54 --> Config Class Initialized
DEBUG - 2011-04-23 01:54:54 --> Hooks Class Initialized
DEBUG - 2011-04-23 01:54:54 --> Utf8 Class Initialized
DEBUG - 2011-04-23 01:54:54 --> UTF-8 Support Enabled
DEBUG - 2011-04-23 01:54:54 --> URI Class Initialized
DEBUG - 2011-04-23 01:54:54 --> Router Class Initialized
DEBUG - 2011-04-23 01:54:54 --> Output Class Initialized
DEBUG - 2011-04-23 01:54:54 --> Input Class Initialized
DEBUG - 2011-04-23 01:54:54 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-23 01:54:54 --> Language Class Initialized
DEBUG - 2011-04-23 01:54:54 --> Loader Class Initialized
DEBUG - 2011-04-23 01:54:54 --> Controller Class Initialized
DEBUG - 2011-04-23 01:54:54 --> Model Class Initialized
DEBUG - 2011-04-23 01:54:54 --> Model Class Initialized
DEBUG - 2011-04-23 01:54:54 --> Model Class Initialized
DEBUG - 2011-04-23 01:54:54 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-23 01:54:54 --> Database Driver Class Initialized
DEBUG - 2011-04-23 01:54:57 --> File loaded: application/views/table/main.php
DEBUG - 2011-04-23 01:54:57 --> Helper loaded: url_helper
DEBUG - 2011-04-23 01:54:57 --> File loaded: application/views/common/header.php
DEBUG - 2011-04-23 01:54:57 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-04-23 01:54:57 --> File loaded: application/views/common/footer.php
DEBUG - 2011-04-23 01:54:57 --> File loaded: application/views/layout/main.php
DEBUG - 2011-04-23 01:54:57 --> Final output sent to browser
DEBUG - 2011-04-23 01:54:57 --> Total execution time: 2.2167
DEBUG - 2011-04-23 01:55:06 --> Config Class Initialized
DEBUG - 2011-04-23 01:55:06 --> Hooks Class Initialized
DEBUG - 2011-04-23 01:55:06 --> Utf8 Class Initialized
DEBUG - 2011-04-23 01:55:06 --> UTF-8 Support Enabled
DEBUG - 2011-04-23 01:55:06 --> URI Class Initialized
DEBUG - 2011-04-23 01:55:06 --> Router Class Initialized
DEBUG - 2011-04-23 01:55:06 --> Output Class Initialized
DEBUG - 2011-04-23 01:55:06 --> Input Class Initialized
DEBUG - 2011-04-23 01:55:06 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-23 01:55:06 --> Language Class Initialized
DEBUG - 2011-04-23 01:55:06 --> Loader Class Initialized
DEBUG - 2011-04-23 01:55:06 --> Controller Class Initialized
DEBUG - 2011-04-23 01:55:06 --> Model Class Initialized
DEBUG - 2011-04-23 01:55:06 --> Model Class Initialized
DEBUG - 2011-04-23 01:55:06 --> Model Class Initialized
DEBUG - 2011-04-23 01:55:06 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-23 01:55:06 --> Database Driver Class Initialized
DEBUG - 2011-04-23 01:55:06 --> File loaded: application/views/table/main.php
DEBUG - 2011-04-23 01:55:06 --> Helper loaded: url_helper
DEBUG - 2011-04-23 01:55:06 --> File loaded: application/views/common/header.php
DEBUG - 2011-04-23 01:55:06 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-04-23 01:55:06 --> File loaded: application/views/common/footer.php
DEBUG - 2011-04-23 01:55:06 --> File loaded: application/views/layout/main.php
DEBUG - 2011-04-23 01:55:06 --> Final output sent to browser
DEBUG - 2011-04-23 01:55:06 --> Total execution time: 0.0566
DEBUG - 2011-04-23 01:55:35 --> Config Class Initialized
DEBUG - 2011-04-23 01:55:35 --> Hooks Class Initialized
DEBUG - 2011-04-23 01:55:35 --> Utf8 Class Initialized
DEBUG - 2011-04-23 01:55:35 --> UTF-8 Support Enabled
DEBUG - 2011-04-23 01:55:35 --> URI Class Initialized
DEBUG - 2011-04-23 01:55:35 --> Router Class Initialized
DEBUG - 2011-04-23 01:55:35 --> Output Class Initialized
DEBUG - 2011-04-23 01:55:35 --> Input Class Initialized
DEBUG - 2011-04-23 01:55:35 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-23 01:55:35 --> Language Class Initialized
DEBUG - 2011-04-23 01:55:35 --> Loader Class Initialized
DEBUG - 2011-04-23 01:55:35 --> Controller Class Initialized
DEBUG - 2011-04-23 01:55:35 --> Model Class Initialized
DEBUG - 2011-04-23 01:55:35 --> Model Class Initialized
DEBUG - 2011-04-23 01:55:35 --> Model Class Initialized
DEBUG - 2011-04-23 01:55:35 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-23 01:55:35 --> Database Driver Class Initialized
DEBUG - 2011-04-23 01:55:48 --> File loaded: application/views/table/main.php
DEBUG - 2011-04-23 01:55:48 --> Helper loaded: url_helper
DEBUG - 2011-04-23 01:55:48 --> File loaded: application/views/common/header.php
DEBUG - 2011-04-23 01:55:48 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-04-23 01:55:48 --> File loaded: application/views/common/footer.php
DEBUG - 2011-04-23 01:55:48 --> File loaded: application/views/layout/main.php
DEBUG - 2011-04-23 01:55:48 --> Final output sent to browser
DEBUG - 2011-04-23 01:55:48 --> Total execution time: 12.8179
DEBUG - 2011-04-23 01:56:01 --> Config Class Initialized
DEBUG - 2011-04-23 01:56:01 --> Hooks Class Initialized
DEBUG - 2011-04-23 01:56:01 --> Utf8 Class Initialized
DEBUG - 2011-04-23 01:56:01 --> UTF-8 Support Enabled
DEBUG - 2011-04-23 01:56:01 --> URI Class Initialized
DEBUG - 2011-04-23 01:56:01 --> Router Class Initialized
DEBUG - 2011-04-23 01:56:01 --> Output Class Initialized
DEBUG - 2011-04-23 01:56:01 --> Input Class Initialized
DEBUG - 2011-04-23 01:56:01 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-23 01:56:01 --> Language Class Initialized
DEBUG - 2011-04-23 01:56:01 --> Loader Class Initialized
DEBUG - 2011-04-23 01:56:01 --> Controller Class Initialized
DEBUG - 2011-04-23 01:56:01 --> Model Class Initialized
DEBUG - 2011-04-23 01:56:01 --> Model Class Initialized
DEBUG - 2011-04-23 01:56:01 --> Model Class Initialized
DEBUG - 2011-04-23 01:56:01 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-23 01:56:01 --> Database Driver Class Initialized
DEBUG - 2011-04-23 01:56:02 --> Config Class Initialized
DEBUG - 2011-04-23 01:56:02 --> Hooks Class Initialized
DEBUG - 2011-04-23 01:56:02 --> Utf8 Class Initialized
DEBUG - 2011-04-23 01:56:02 --> UTF-8 Support Enabled
DEBUG - 2011-04-23 01:56:02 --> URI Class Initialized
DEBUG - 2011-04-23 01:56:02 --> Router Class Initialized
DEBUG - 2011-04-23 01:56:02 --> Output Class Initialized
DEBUG - 2011-04-23 01:56:02 --> Input Class Initialized
DEBUG - 2011-04-23 01:56:02 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-23 01:56:02 --> Language Class Initialized
DEBUG - 2011-04-23 01:56:02 --> Loader Class Initialized
DEBUG - 2011-04-23 01:56:02 --> Controller Class Initialized
DEBUG - 2011-04-23 01:56:02 --> Model Class Initialized
DEBUG - 2011-04-23 01:56:02 --> Model Class Initialized
DEBUG - 2011-04-23 01:56:02 --> Model Class Initialized
DEBUG - 2011-04-23 01:56:02 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-23 01:56:02 --> Database Driver Class Initialized
DEBUG - 2011-04-23 01:56:02 --> File loaded: application/views/table/main.php
DEBUG - 2011-04-23 01:56:02 --> Helper loaded: url_helper
DEBUG - 2011-04-23 01:56:02 --> File loaded: application/views/common/header.php
DEBUG - 2011-04-23 01:56:02 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-04-23 01:56:02 --> File loaded: application/views/common/footer.php
DEBUG - 2011-04-23 01:56:02 --> File loaded: application/views/layout/main.php
DEBUG - 2011-04-23 01:56:02 --> Final output sent to browser
DEBUG - 2011-04-23 01:56:02 --> Total execution time: 0.0616
DEBUG - 2011-04-23 01:56:15 --> File loaded: application/views/table/main.php
DEBUG - 2011-04-23 01:56:15 --> Helper loaded: url_helper
DEBUG - 2011-04-23 01:56:15 --> File loaded: application/views/common/header.php
DEBUG - 2011-04-23 01:56:15 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-04-23 01:56:15 --> File loaded: application/views/common/footer.php
DEBUG - 2011-04-23 01:56:15 --> File loaded: application/views/layout/main.php
DEBUG - 2011-04-23 01:56:15 --> Final output sent to browser
DEBUG - 2011-04-23 01:56:15 --> Total execution time: 14.2906
DEBUG - 2011-04-23 01:56:28 --> Config Class Initialized
DEBUG - 2011-04-23 01:56:28 --> Hooks Class Initialized
DEBUG - 2011-04-23 01:56:28 --> Utf8 Class Initialized
DEBUG - 2011-04-23 01:56:28 --> UTF-8 Support Enabled
DEBUG - 2011-04-23 01:56:28 --> URI Class Initialized
DEBUG - 2011-04-23 01:56:28 --> Router Class Initialized
DEBUG - 2011-04-23 01:56:28 --> Output Class Initialized
DEBUG - 2011-04-23 01:56:28 --> Input Class Initialized
DEBUG - 2011-04-23 01:56:28 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-23 01:56:28 --> Language Class Initialized
DEBUG - 2011-04-23 01:56:28 --> Loader Class Initialized
DEBUG - 2011-04-23 01:56:28 --> Controller Class Initialized
DEBUG - 2011-04-23 01:56:28 --> Model Class Initialized
DEBUG - 2011-04-23 01:56:28 --> Model Class Initialized
DEBUG - 2011-04-23 01:56:28 --> Model Class Initialized
DEBUG - 2011-04-23 01:56:28 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-23 01:56:28 --> Database Driver Class Initialized
DEBUG - 2011-04-23 01:56:28 --> File loaded: application/views/table/main.php
DEBUG - 2011-04-23 01:56:28 --> Helper loaded: url_helper
DEBUG - 2011-04-23 01:56:28 --> File loaded: application/views/common/header.php
DEBUG - 2011-04-23 01:56:28 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-04-23 01:56:28 --> File loaded: application/views/common/footer.php
DEBUG - 2011-04-23 01:56:28 --> File loaded: application/views/layout/main.php
DEBUG - 2011-04-23 01:56:28 --> Final output sent to browser
DEBUG - 2011-04-23 01:56:28 --> Total execution time: 0.0798
DEBUG - 2011-04-23 01:56:31 --> Config Class Initialized
DEBUG - 2011-04-23 01:56:31 --> Hooks Class Initialized
DEBUG - 2011-04-23 01:56:31 --> Utf8 Class Initialized
DEBUG - 2011-04-23 01:56:31 --> UTF-8 Support Enabled
DEBUG - 2011-04-23 01:56:31 --> URI Class Initialized
DEBUG - 2011-04-23 01:56:31 --> Router Class Initialized
DEBUG - 2011-04-23 01:56:31 --> Output Class Initialized
DEBUG - 2011-04-23 01:56:31 --> Input Class Initialized
DEBUG - 2011-04-23 01:56:31 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-23 01:56:31 --> Language Class Initialized
DEBUG - 2011-04-23 01:56:31 --> Loader Class Initialized
DEBUG - 2011-04-23 01:56:31 --> Controller Class Initialized
DEBUG - 2011-04-23 01:56:31 --> Model Class Initialized
DEBUG - 2011-04-23 01:56:31 --> Model Class Initialized
DEBUG - 2011-04-23 01:56:31 --> Model Class Initialized
DEBUG - 2011-04-23 01:56:31 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-23 01:56:31 --> Database Driver Class Initialized
DEBUG - 2011-04-23 01:56:39 --> File loaded: application/views/table/main.php
DEBUG - 2011-04-23 01:56:39 --> Helper loaded: url_helper
DEBUG - 2011-04-23 01:56:39 --> File loaded: application/views/common/header.php
DEBUG - 2011-04-23 01:56:39 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-04-23 01:56:39 --> File loaded: application/views/common/footer.php
DEBUG - 2011-04-23 01:56:39 --> File loaded: application/views/layout/main.php
DEBUG - 2011-04-23 01:56:39 --> Final output sent to browser
DEBUG - 2011-04-23 01:56:39 --> Total execution time: 7.2249
DEBUG - 2011-04-23 01:56:42 --> Config Class Initialized
DEBUG - 2011-04-23 01:56:42 --> Hooks Class Initialized
DEBUG - 2011-04-23 01:56:42 --> Utf8 Class Initialized
DEBUG - 2011-04-23 01:56:42 --> UTF-8 Support Enabled
DEBUG - 2011-04-23 01:56:42 --> URI Class Initialized
DEBUG - 2011-04-23 01:56:42 --> Router Class Initialized
DEBUG - 2011-04-23 01:56:42 --> Output Class Initialized
DEBUG - 2011-04-23 01:56:42 --> Input Class Initialized
DEBUG - 2011-04-23 01:56:42 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-23 01:56:42 --> Language Class Initialized
DEBUG - 2011-04-23 01:56:42 --> Loader Class Initialized
DEBUG - 2011-04-23 01:56:42 --> Controller Class Initialized
DEBUG - 2011-04-23 01:56:42 --> Model Class Initialized
DEBUG - 2011-04-23 01:56:42 --> Model Class Initialized
DEBUG - 2011-04-23 01:56:42 --> Model Class Initialized
DEBUG - 2011-04-23 01:56:42 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-23 01:56:42 --> Database Driver Class Initialized
DEBUG - 2011-04-23 01:56:45 --> File loaded: application/views/table/main.php
DEBUG - 2011-04-23 01:56:45 --> Helper loaded: url_helper
DEBUG - 2011-04-23 01:56:45 --> File loaded: application/views/common/header.php
DEBUG - 2011-04-23 01:56:45 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-04-23 01:56:45 --> File loaded: application/views/common/footer.php
DEBUG - 2011-04-23 01:56:45 --> File loaded: application/views/layout/main.php
DEBUG - 2011-04-23 01:56:45 --> Final output sent to browser
DEBUG - 2011-04-23 01:56:45 --> Total execution time: 3.1006
DEBUG - 2011-04-23 01:56:50 --> Config Class Initialized
DEBUG - 2011-04-23 01:56:50 --> Hooks Class Initialized
DEBUG - 2011-04-23 01:56:50 --> Utf8 Class Initialized
DEBUG - 2011-04-23 01:56:50 --> UTF-8 Support Enabled
DEBUG - 2011-04-23 01:56:50 --> URI Class Initialized
DEBUG - 2011-04-23 01:56:50 --> Router Class Initialized
DEBUG - 2011-04-23 01:56:50 --> Output Class Initialized
DEBUG - 2011-04-23 01:56:50 --> Input Class Initialized
DEBUG - 2011-04-23 01:56:50 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-23 01:56:50 --> Language Class Initialized
DEBUG - 2011-04-23 01:56:50 --> Loader Class Initialized
DEBUG - 2011-04-23 01:56:50 --> Controller Class Initialized
DEBUG - 2011-04-23 01:56:50 --> Model Class Initialized
DEBUG - 2011-04-23 01:56:50 --> Model Class Initialized
DEBUG - 2011-04-23 01:56:50 --> Model Class Initialized
DEBUG - 2011-04-23 01:56:50 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-23 01:56:50 --> Database Driver Class Initialized
DEBUG - 2011-04-23 01:56:55 --> File loaded: application/views/table/main.php
DEBUG - 2011-04-23 01:56:55 --> Helper loaded: url_helper
DEBUG - 2011-04-23 01:56:55 --> File loaded: application/views/common/header.php
DEBUG - 2011-04-23 01:56:55 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-04-23 01:56:55 --> File loaded: application/views/common/footer.php
DEBUG - 2011-04-23 01:56:55 --> File loaded: application/views/layout/main.php
DEBUG - 2011-04-23 01:56:55 --> Final output sent to browser
DEBUG - 2011-04-23 01:56:55 --> Total execution time: 4.4523
DEBUG - 2011-04-23 01:56:59 --> Config Class Initialized
DEBUG - 2011-04-23 01:56:59 --> Hooks Class Initialized
DEBUG - 2011-04-23 01:56:59 --> Utf8 Class Initialized
DEBUG - 2011-04-23 01:56:59 --> UTF-8 Support Enabled
DEBUG - 2011-04-23 01:56:59 --> URI Class Initialized
DEBUG - 2011-04-23 01:56:59 --> Router Class Initialized
DEBUG - 2011-04-23 01:56:59 --> Output Class Initialized
DEBUG - 2011-04-23 01:56:59 --> Input Class Initialized
DEBUG - 2011-04-23 01:56:59 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-23 01:56:59 --> Language Class Initialized
DEBUG - 2011-04-23 01:56:59 --> Loader Class Initialized
DEBUG - 2011-04-23 01:56:59 --> Controller Class Initialized
DEBUG - 2011-04-23 01:56:59 --> Model Class Initialized
DEBUG - 2011-04-23 01:56:59 --> Model Class Initialized
DEBUG - 2011-04-23 01:56:59 --> Model Class Initialized
DEBUG - 2011-04-23 01:56:59 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-23 01:56:59 --> Database Driver Class Initialized
DEBUG - 2011-04-23 01:56:59 --> File loaded: application/views/table/main.php
DEBUG - 2011-04-23 01:56:59 --> Helper loaded: url_helper
DEBUG - 2011-04-23 01:56:59 --> File loaded: application/views/common/header.php
DEBUG - 2011-04-23 01:56:59 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-04-23 01:56:59 --> File loaded: application/views/common/footer.php
DEBUG - 2011-04-23 01:56:59 --> File loaded: application/views/layout/main.php
DEBUG - 2011-04-23 01:56:59 --> Final output sent to browser
DEBUG - 2011-04-23 01:56:59 --> Total execution time: 0.0679
DEBUG - 2011-04-23 01:57:03 --> Config Class Initialized
DEBUG - 2011-04-23 01:57:03 --> Hooks Class Initialized
DEBUG - 2011-04-23 01:57:03 --> Utf8 Class Initialized
DEBUG - 2011-04-23 01:57:03 --> UTF-8 Support Enabled
DEBUG - 2011-04-23 01:57:03 --> URI Class Initialized
DEBUG - 2011-04-23 01:57:03 --> Router Class Initialized
DEBUG - 2011-04-23 01:57:03 --> Output Class Initialized
DEBUG - 2011-04-23 01:57:03 --> Input Class Initialized
DEBUG - 2011-04-23 01:57:03 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-23 01:57:03 --> Language Class Initialized
DEBUG - 2011-04-23 01:57:03 --> Loader Class Initialized
DEBUG - 2011-04-23 01:57:03 --> Controller Class Initialized
DEBUG - 2011-04-23 01:57:03 --> Model Class Initialized
DEBUG - 2011-04-23 01:57:03 --> Model Class Initialized
DEBUG - 2011-04-23 01:57:03 --> Model Class Initialized
DEBUG - 2011-04-23 01:57:03 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-23 01:57:03 --> Database Driver Class Initialized
DEBUG - 2011-04-23 01:57:05 --> File loaded: application/views/table/main.php
DEBUG - 2011-04-23 01:57:05 --> Helper loaded: url_helper
DEBUG - 2011-04-23 01:57:05 --> File loaded: application/views/common/header.php
DEBUG - 2011-04-23 01:57:05 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-04-23 01:57:05 --> File loaded: application/views/common/footer.php
DEBUG - 2011-04-23 01:57:05 --> File loaded: application/views/layout/main.php
DEBUG - 2011-04-23 01:57:05 --> Final output sent to browser
DEBUG - 2011-04-23 01:57:05 --> Total execution time: 2.3174
DEBUG - 2011-04-23 01:57:08 --> Config Class Initialized
DEBUG - 2011-04-23 01:57:08 --> Hooks Class Initialized
DEBUG - 2011-04-23 01:57:08 --> Utf8 Class Initialized
DEBUG - 2011-04-23 01:57:08 --> UTF-8 Support Enabled
DEBUG - 2011-04-23 01:57:08 --> URI Class Initialized
DEBUG - 2011-04-23 01:57:08 --> Router Class Initialized
DEBUG - 2011-04-23 01:57:08 --> Output Class Initialized
DEBUG - 2011-04-23 01:57:08 --> Input Class Initialized
DEBUG - 2011-04-23 01:57:08 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-23 01:57:08 --> Language Class Initialized
DEBUG - 2011-04-23 01:57:08 --> Loader Class Initialized
DEBUG - 2011-04-23 01:57:08 --> Controller Class Initialized
DEBUG - 2011-04-23 01:57:08 --> Model Class Initialized
DEBUG - 2011-04-23 01:57:08 --> Model Class Initialized
DEBUG - 2011-04-23 01:57:08 --> Model Class Initialized
DEBUG - 2011-04-23 01:57:08 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-23 01:57:08 --> Database Driver Class Initialized
DEBUG - 2011-04-23 01:57:08 --> File loaded: application/views/table/main.php
DEBUG - 2011-04-23 01:57:08 --> Helper loaded: url_helper
DEBUG - 2011-04-23 01:57:08 --> File loaded: application/views/common/header.php
DEBUG - 2011-04-23 01:57:08 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-04-23 01:57:08 --> File loaded: application/views/common/footer.php
DEBUG - 2011-04-23 01:57:08 --> File loaded: application/views/layout/main.php
DEBUG - 2011-04-23 01:57:08 --> Final output sent to browser
DEBUG - 2011-04-23 01:57:08 --> Total execution time: 0.0651
DEBUG - 2011-04-23 01:57:24 --> Config Class Initialized
DEBUG - 2011-04-23 01:57:24 --> Hooks Class Initialized
DEBUG - 2011-04-23 01:57:24 --> Utf8 Class Initialized
DEBUG - 2011-04-23 01:57:24 --> UTF-8 Support Enabled
DEBUG - 2011-04-23 01:57:24 --> URI Class Initialized
DEBUG - 2011-04-23 01:57:24 --> Router Class Initialized
DEBUG - 2011-04-23 01:57:24 --> Output Class Initialized
DEBUG - 2011-04-23 01:57:24 --> Input Class Initialized
DEBUG - 2011-04-23 01:57:24 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-23 01:57:24 --> Language Class Initialized
DEBUG - 2011-04-23 01:57:24 --> Loader Class Initialized
DEBUG - 2011-04-23 01:57:24 --> Controller Class Initialized
DEBUG - 2011-04-23 01:57:24 --> Model Class Initialized
DEBUG - 2011-04-23 01:57:24 --> Model Class Initialized
DEBUG - 2011-04-23 01:57:24 --> Model Class Initialized
DEBUG - 2011-04-23 01:57:24 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-23 01:57:24 --> Database Driver Class Initialized
DEBUG - 2011-04-23 01:57:25 --> File loaded: application/views/table/main.php
DEBUG - 2011-04-23 01:57:25 --> Helper loaded: url_helper
DEBUG - 2011-04-23 01:57:25 --> File loaded: application/views/common/header.php
DEBUG - 2011-04-23 01:57:25 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-04-23 01:57:25 --> File loaded: application/views/common/footer.php
DEBUG - 2011-04-23 01:57:25 --> File loaded: application/views/layout/main.php
DEBUG - 2011-04-23 01:57:25 --> Final output sent to browser
DEBUG - 2011-04-23 01:57:25 --> Total execution time: 1.1397
DEBUG - 2011-04-23 01:57:28 --> Config Class Initialized
DEBUG - 2011-04-23 01:57:28 --> Hooks Class Initialized
DEBUG - 2011-04-23 01:57:28 --> Utf8 Class Initialized
DEBUG - 2011-04-23 01:57:28 --> UTF-8 Support Enabled
DEBUG - 2011-04-23 01:57:28 --> URI Class Initialized
DEBUG - 2011-04-23 01:57:28 --> Router Class Initialized
DEBUG - 2011-04-23 01:57:28 --> Output Class Initialized
DEBUG - 2011-04-23 01:57:28 --> Input Class Initialized
DEBUG - 2011-04-23 01:57:28 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-23 01:57:28 --> Language Class Initialized
DEBUG - 2011-04-23 01:57:28 --> Loader Class Initialized
DEBUG - 2011-04-23 01:57:28 --> Controller Class Initialized
DEBUG - 2011-04-23 01:57:28 --> Model Class Initialized
DEBUG - 2011-04-23 01:57:28 --> Model Class Initialized
DEBUG - 2011-04-23 01:57:28 --> Model Class Initialized
DEBUG - 2011-04-23 01:57:28 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-23 01:57:28 --> Database Driver Class Initialized
DEBUG - 2011-04-23 01:57:28 --> File loaded: application/views/table/main.php
DEBUG - 2011-04-23 01:57:28 --> Helper loaded: url_helper
DEBUG - 2011-04-23 01:57:28 --> File loaded: application/views/common/header.php
DEBUG - 2011-04-23 01:57:28 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-04-23 01:57:28 --> File loaded: application/views/common/footer.php
DEBUG - 2011-04-23 01:57:28 --> File loaded: application/views/layout/main.php
DEBUG - 2011-04-23 01:57:28 --> Final output sent to browser
DEBUG - 2011-04-23 01:57:28 --> Total execution time: 0.0994
DEBUG - 2011-04-23 01:57:53 --> Config Class Initialized
DEBUG - 2011-04-23 01:57:53 --> Hooks Class Initialized
DEBUG - 2011-04-23 01:57:53 --> Utf8 Class Initialized
DEBUG - 2011-04-23 01:57:53 --> UTF-8 Support Enabled
DEBUG - 2011-04-23 01:57:53 --> URI Class Initialized
DEBUG - 2011-04-23 01:57:53 --> Router Class Initialized
DEBUG - 2011-04-23 01:57:53 --> Output Class Initialized
DEBUG - 2011-04-23 01:57:53 --> Input Class Initialized
DEBUG - 2011-04-23 01:57:53 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-23 01:57:53 --> Language Class Initialized
DEBUG - 2011-04-23 01:57:53 --> Loader Class Initialized
DEBUG - 2011-04-23 01:57:53 --> Controller Class Initialized
DEBUG - 2011-04-23 01:57:53 --> Model Class Initialized
DEBUG - 2011-04-23 01:57:53 --> Model Class Initialized
DEBUG - 2011-04-23 01:57:53 --> Model Class Initialized
DEBUG - 2011-04-23 01:57:53 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-23 01:57:53 --> Database Driver Class Initialized
DEBUG - 2011-04-23 01:57:53 --> File loaded: application/views/table/main.php
DEBUG - 2011-04-23 01:57:53 --> Helper loaded: url_helper
DEBUG - 2011-04-23 01:57:53 --> File loaded: application/views/common/header.php
DEBUG - 2011-04-23 01:57:53 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-04-23 01:57:53 --> File loaded: application/views/common/footer.php
DEBUG - 2011-04-23 01:57:53 --> File loaded: application/views/layout/main.php
DEBUG - 2011-04-23 01:57:53 --> Final output sent to browser
DEBUG - 2011-04-23 01:57:53 --> Total execution time: 0.0480
DEBUG - 2011-04-23 01:58:09 --> Config Class Initialized
DEBUG - 2011-04-23 01:58:09 --> Hooks Class Initialized
DEBUG - 2011-04-23 01:58:09 --> Utf8 Class Initialized
DEBUG - 2011-04-23 01:58:09 --> UTF-8 Support Enabled
DEBUG - 2011-04-23 01:58:09 --> URI Class Initialized
DEBUG - 2011-04-23 01:58:09 --> Router Class Initialized
DEBUG - 2011-04-23 01:58:09 --> Output Class Initialized
DEBUG - 2011-04-23 01:58:09 --> Input Class Initialized
DEBUG - 2011-04-23 01:58:09 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-23 01:58:09 --> Language Class Initialized
DEBUG - 2011-04-23 01:58:09 --> Loader Class Initialized
DEBUG - 2011-04-23 01:58:09 --> Controller Class Initialized
DEBUG - 2011-04-23 01:58:09 --> Model Class Initialized
DEBUG - 2011-04-23 01:58:09 --> Model Class Initialized
DEBUG - 2011-04-23 01:58:09 --> Model Class Initialized
DEBUG - 2011-04-23 01:58:09 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-23 01:58:09 --> Database Driver Class Initialized
DEBUG - 2011-04-23 01:58:09 --> File loaded: application/views/table/main.php
DEBUG - 2011-04-23 01:58:09 --> Helper loaded: url_helper
DEBUG - 2011-04-23 01:58:09 --> File loaded: application/views/common/header.php
DEBUG - 2011-04-23 01:58:09 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-04-23 01:58:09 --> File loaded: application/views/common/footer.php
DEBUG - 2011-04-23 01:58:09 --> File loaded: application/views/layout/main.php
DEBUG - 2011-04-23 01:58:09 --> Final output sent to browser
DEBUG - 2011-04-23 01:58:09 --> Total execution time: 0.0491
DEBUG - 2011-04-23 05:24:46 --> Config Class Initialized
DEBUG - 2011-04-23 05:24:46 --> Hooks Class Initialized
DEBUG - 2011-04-23 05:24:46 --> Utf8 Class Initialized
DEBUG - 2011-04-23 05:24:46 --> UTF-8 Support Enabled
DEBUG - 2011-04-23 05:24:46 --> URI Class Initialized
DEBUG - 2011-04-23 05:24:46 --> Router Class Initialized
DEBUG - 2011-04-23 05:24:46 --> Output Class Initialized
DEBUG - 2011-04-23 05:24:46 --> Input Class Initialized
DEBUG - 2011-04-23 05:24:46 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-23 05:24:46 --> Language Class Initialized
DEBUG - 2011-04-23 05:24:46 --> Loader Class Initialized
DEBUG - 2011-04-23 05:24:46 --> Controller Class Initialized
ERROR - 2011-04-23 05:24:46 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-04-23 05:24:46 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-04-23 05:24:46 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-04-23 05:24:46 --> Model Class Initialized
DEBUG - 2011-04-23 05:24:46 --> Model Class Initialized
DEBUG - 2011-04-23 05:24:46 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-23 05:24:46 --> Database Driver Class Initialized
DEBUG - 2011-04-23 05:24:46 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-04-23 05:24:46 --> Helper loaded: url_helper
DEBUG - 2011-04-23 05:24:46 --> File loaded: application/views/common/header.php
DEBUG - 2011-04-23 05:24:46 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-04-23 05:24:46 --> File loaded: application/views/common/footer.php
DEBUG - 2011-04-23 05:24:46 --> File loaded: application/views/layout/main.php
DEBUG - 2011-04-23 05:24:46 --> Final output sent to browser
DEBUG - 2011-04-23 05:24:46 --> Total execution time: 0.8138
DEBUG - 2011-04-23 05:24:48 --> Config Class Initialized
DEBUG - 2011-04-23 05:24:48 --> Hooks Class Initialized
DEBUG - 2011-04-23 05:24:48 --> Utf8 Class Initialized
DEBUG - 2011-04-23 05:24:48 --> UTF-8 Support Enabled
DEBUG - 2011-04-23 05:24:48 --> URI Class Initialized
DEBUG - 2011-04-23 05:24:48 --> Router Class Initialized
DEBUG - 2011-04-23 05:24:48 --> Output Class Initialized
DEBUG - 2011-04-23 05:24:48 --> Input Class Initialized
DEBUG - 2011-04-23 05:24:48 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-23 05:24:48 --> Language Class Initialized
DEBUG - 2011-04-23 05:24:48 --> Loader Class Initialized
DEBUG - 2011-04-23 05:24:48 --> Controller Class Initialized
DEBUG - 2011-04-23 05:24:48 --> Model Class Initialized
DEBUG - 2011-04-23 05:24:48 --> Model Class Initialized
DEBUG - 2011-04-23 05:24:48 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-23 05:24:48 --> Database Driver Class Initialized
DEBUG - 2011-04-23 05:24:49 --> Final output sent to browser
DEBUG - 2011-04-23 05:24:49 --> Total execution time: 0.8781
DEBUG - 2011-04-23 05:24:50 --> Config Class Initialized
DEBUG - 2011-04-23 05:24:50 --> Hooks Class Initialized
DEBUG - 2011-04-23 05:24:50 --> Utf8 Class Initialized
DEBUG - 2011-04-23 05:24:50 --> UTF-8 Support Enabled
DEBUG - 2011-04-23 05:24:50 --> URI Class Initialized
DEBUG - 2011-04-23 05:24:50 --> Router Class Initialized
ERROR - 2011-04-23 05:24:50 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-04-23 07:58:09 --> Config Class Initialized
DEBUG - 2011-04-23 07:58:09 --> Hooks Class Initialized
DEBUG - 2011-04-23 07:58:09 --> Utf8 Class Initialized
DEBUG - 2011-04-23 07:58:09 --> UTF-8 Support Enabled
DEBUG - 2011-04-23 07:58:09 --> URI Class Initialized
DEBUG - 2011-04-23 07:58:09 --> Router Class Initialized
DEBUG - 2011-04-23 07:58:09 --> Output Class Initialized
DEBUG - 2011-04-23 07:58:09 --> Input Class Initialized
DEBUG - 2011-04-23 07:58:09 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-23 07:58:09 --> Language Class Initialized
DEBUG - 2011-04-23 07:58:09 --> Loader Class Initialized
DEBUG - 2011-04-23 07:58:09 --> Controller Class Initialized
DEBUG - 2011-04-23 07:58:09 --> Model Class Initialized
DEBUG - 2011-04-23 07:58:09 --> Model Class Initialized
DEBUG - 2011-04-23 07:58:09 --> Model Class Initialized
DEBUG - 2011-04-23 07:58:09 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-23 07:58:09 --> Database Driver Class Initialized
DEBUG - 2011-04-23 07:58:09 --> File loaded: application/views/table/main.php
DEBUG - 2011-04-23 07:58:10 --> Helper loaded: url_helper
DEBUG - 2011-04-23 07:58:10 --> File loaded: application/views/common/header.php
DEBUG - 2011-04-23 07:58:10 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-04-23 07:58:10 --> File loaded: application/views/common/footer.php
DEBUG - 2011-04-23 07:58:10 --> File loaded: application/views/layout/main.php
DEBUG - 2011-04-23 07:58:10 --> Final output sent to browser
DEBUG - 2011-04-23 07:58:10 --> Total execution time: 0.9244
DEBUG - 2011-04-23 07:58:11 --> Config Class Initialized
DEBUG - 2011-04-23 07:58:11 --> Hooks Class Initialized
DEBUG - 2011-04-23 07:58:11 --> Utf8 Class Initialized
DEBUG - 2011-04-23 07:58:11 --> UTF-8 Support Enabled
DEBUG - 2011-04-23 07:58:11 --> URI Class Initialized
DEBUG - 2011-04-23 07:58:11 --> Router Class Initialized
DEBUG - 2011-04-23 07:58:11 --> Output Class Initialized
DEBUG - 2011-04-23 07:58:11 --> Input Class Initialized
DEBUG - 2011-04-23 07:58:11 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-23 07:58:11 --> Language Class Initialized
DEBUG - 2011-04-23 07:58:11 --> Loader Class Initialized
DEBUG - 2011-04-23 07:58:11 --> Controller Class Initialized
ERROR - 2011-04-23 07:58:11 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-04-23 07:58:11 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-04-23 07:58:11 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-04-23 07:58:11 --> Model Class Initialized
DEBUG - 2011-04-23 07:58:11 --> Model Class Initialized
DEBUG - 2011-04-23 07:58:11 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-23 07:58:11 --> Database Driver Class Initialized
DEBUG - 2011-04-23 07:58:11 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-04-23 07:58:11 --> Helper loaded: url_helper
DEBUG - 2011-04-23 07:58:11 --> File loaded: application/views/common/header.php
DEBUG - 2011-04-23 07:58:11 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-04-23 07:58:11 --> File loaded: application/views/common/footer.php
DEBUG - 2011-04-23 07:58:11 --> File loaded: application/views/layout/main.php
DEBUG - 2011-04-23 07:58:11 --> Final output sent to browser
DEBUG - 2011-04-23 07:58:11 --> Total execution time: 0.0961
DEBUG - 2011-04-23 11:11:05 --> Config Class Initialized
DEBUG - 2011-04-23 11:11:05 --> Hooks Class Initialized
DEBUG - 2011-04-23 11:11:05 --> Utf8 Class Initialized
DEBUG - 2011-04-23 11:11:05 --> UTF-8 Support Enabled
DEBUG - 2011-04-23 11:11:05 --> URI Class Initialized
DEBUG - 2011-04-23 11:11:05 --> Router Class Initialized
DEBUG - 2011-04-23 11:11:05 --> Output Class Initialized
DEBUG - 2011-04-23 11:11:05 --> Input Class Initialized
DEBUG - 2011-04-23 11:11:05 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-23 11:11:05 --> Language Class Initialized
DEBUG - 2011-04-23 11:11:05 --> Loader Class Initialized
DEBUG - 2011-04-23 11:11:05 --> Controller Class Initialized
ERROR - 2011-04-23 11:11:05 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-04-23 11:11:05 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-04-23 11:11:05 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-04-23 11:11:05 --> Model Class Initialized
DEBUG - 2011-04-23 11:11:05 --> Model Class Initialized
DEBUG - 2011-04-23 11:11:05 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-23 11:11:05 --> Database Driver Class Initialized
DEBUG - 2011-04-23 11:11:05 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-04-23 11:11:05 --> Helper loaded: url_helper
DEBUG - 2011-04-23 11:11:05 --> File loaded: application/views/common/header.php
DEBUG - 2011-04-23 11:11:05 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-04-23 11:11:05 --> File loaded: application/views/common/footer.php
DEBUG - 2011-04-23 11:11:05 --> File loaded: application/views/layout/main.php
DEBUG - 2011-04-23 11:11:05 --> Final output sent to browser
DEBUG - 2011-04-23 11:11:05 --> Total execution time: 0.4768
DEBUG - 2011-04-23 11:11:08 --> Config Class Initialized
DEBUG - 2011-04-23 11:11:08 --> Hooks Class Initialized
DEBUG - 2011-04-23 11:11:08 --> Utf8 Class Initialized
DEBUG - 2011-04-23 11:11:08 --> UTF-8 Support Enabled
DEBUG - 2011-04-23 11:11:08 --> URI Class Initialized
DEBUG - 2011-04-23 11:11:08 --> Router Class Initialized
DEBUG - 2011-04-23 11:11:08 --> Output Class Initialized
DEBUG - 2011-04-23 11:11:08 --> Input Class Initialized
DEBUG - 2011-04-23 11:11:08 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-23 11:11:08 --> Language Class Initialized
DEBUG - 2011-04-23 11:11:08 --> Loader Class Initialized
DEBUG - 2011-04-23 11:11:08 --> Controller Class Initialized
DEBUG - 2011-04-23 11:11:08 --> Model Class Initialized
DEBUG - 2011-04-23 11:11:08 --> Model Class Initialized
DEBUG - 2011-04-23 11:11:08 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-23 11:11:08 --> Database Driver Class Initialized
DEBUG - 2011-04-23 11:11:08 --> Final output sent to browser
DEBUG - 2011-04-23 11:11:08 --> Total execution time: 0.6650
DEBUG - 2011-04-23 11:11:13 --> Config Class Initialized
DEBUG - 2011-04-23 11:11:13 --> Hooks Class Initialized
DEBUG - 2011-04-23 11:11:13 --> Utf8 Class Initialized
DEBUG - 2011-04-23 11:11:13 --> UTF-8 Support Enabled
DEBUG - 2011-04-23 11:11:13 --> URI Class Initialized
DEBUG - 2011-04-23 11:11:13 --> Router Class Initialized
ERROR - 2011-04-23 11:11:13 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-04-23 11:11:17 --> Config Class Initialized
DEBUG - 2011-04-23 11:11:17 --> Hooks Class Initialized
DEBUG - 2011-04-23 11:11:17 --> Utf8 Class Initialized
DEBUG - 2011-04-23 11:11:17 --> UTF-8 Support Enabled
DEBUG - 2011-04-23 11:11:17 --> URI Class Initialized
DEBUG - 2011-04-23 11:11:17 --> Router Class Initialized
ERROR - 2011-04-23 11:11:17 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-04-23 11:11:53 --> Config Class Initialized
DEBUG - 2011-04-23 11:11:53 --> Hooks Class Initialized
DEBUG - 2011-04-23 11:11:53 --> Utf8 Class Initialized
DEBUG - 2011-04-23 11:11:53 --> UTF-8 Support Enabled
DEBUG - 2011-04-23 11:11:53 --> URI Class Initialized
DEBUG - 2011-04-23 11:11:53 --> Router Class Initialized
DEBUG - 2011-04-23 11:11:53 --> Output Class Initialized
DEBUG - 2011-04-23 11:11:53 --> Input Class Initialized
DEBUG - 2011-04-23 11:11:53 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-23 11:11:53 --> Language Class Initialized
DEBUG - 2011-04-23 11:11:53 --> Loader Class Initialized
DEBUG - 2011-04-23 11:11:53 --> Controller Class Initialized
ERROR - 2011-04-23 11:11:53 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-04-23 11:11:53 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-04-23 11:11:53 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-04-23 11:11:53 --> Model Class Initialized
DEBUG - 2011-04-23 11:11:53 --> Model Class Initialized
DEBUG - 2011-04-23 11:11:53 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-23 11:11:53 --> Database Driver Class Initialized
DEBUG - 2011-04-23 11:11:53 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-04-23 11:11:53 --> Helper loaded: url_helper
DEBUG - 2011-04-23 11:11:53 --> File loaded: application/views/common/header.php
DEBUG - 2011-04-23 11:11:53 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-04-23 11:11:53 --> File loaded: application/views/common/footer.php
DEBUG - 2011-04-23 11:11:53 --> File loaded: application/views/layout/main.php
DEBUG - 2011-04-23 11:11:53 --> Final output sent to browser
DEBUG - 2011-04-23 11:11:53 --> Total execution time: 0.0300
DEBUG - 2011-04-23 11:11:54 --> Config Class Initialized
DEBUG - 2011-04-23 11:11:54 --> Hooks Class Initialized
DEBUG - 2011-04-23 11:11:54 --> Utf8 Class Initialized
DEBUG - 2011-04-23 11:11:54 --> UTF-8 Support Enabled
DEBUG - 2011-04-23 11:11:54 --> URI Class Initialized
DEBUG - 2011-04-23 11:11:54 --> Router Class Initialized
DEBUG - 2011-04-23 11:11:54 --> Output Class Initialized
DEBUG - 2011-04-23 11:11:54 --> Input Class Initialized
DEBUG - 2011-04-23 11:11:54 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-23 11:11:54 --> Language Class Initialized
DEBUG - 2011-04-23 11:11:54 --> Loader Class Initialized
DEBUG - 2011-04-23 11:11:54 --> Controller Class Initialized
DEBUG - 2011-04-23 11:11:54 --> Model Class Initialized
DEBUG - 2011-04-23 11:11:54 --> Model Class Initialized
DEBUG - 2011-04-23 11:11:54 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-23 11:11:54 --> Database Driver Class Initialized
DEBUG - 2011-04-23 11:11:55 --> Final output sent to browser
DEBUG - 2011-04-23 11:11:55 --> Total execution time: 0.5647
DEBUG - 2011-04-23 11:12:15 --> Config Class Initialized
DEBUG - 2011-04-23 11:12:15 --> Hooks Class Initialized
DEBUG - 2011-04-23 11:12:15 --> Utf8 Class Initialized
DEBUG - 2011-04-23 11:12:15 --> UTF-8 Support Enabled
DEBUG - 2011-04-23 11:12:15 --> URI Class Initialized
DEBUG - 2011-04-23 11:12:15 --> Router Class Initialized
ERROR - 2011-04-23 11:12:15 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-04-23 11:35:35 --> Config Class Initialized
DEBUG - 2011-04-23 11:35:35 --> Hooks Class Initialized
DEBUG - 2011-04-23 11:35:35 --> Utf8 Class Initialized
DEBUG - 2011-04-23 11:35:35 --> UTF-8 Support Enabled
DEBUG - 2011-04-23 11:35:35 --> URI Class Initialized
DEBUG - 2011-04-23 11:35:35 --> Router Class Initialized
DEBUG - 2011-04-23 11:35:35 --> Output Class Initialized
DEBUG - 2011-04-23 11:35:35 --> Input Class Initialized
DEBUG - 2011-04-23 11:35:35 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-23 11:35:35 --> Language Class Initialized
DEBUG - 2011-04-23 11:35:35 --> Loader Class Initialized
DEBUG - 2011-04-23 11:35:35 --> Controller Class Initialized
DEBUG - 2011-04-23 11:35:35 --> Model Class Initialized
DEBUG - 2011-04-23 11:35:35 --> Model Class Initialized
DEBUG - 2011-04-23 11:35:35 --> Model Class Initialized
DEBUG - 2011-04-23 11:35:35 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-23 11:35:35 --> Database Driver Class Initialized
DEBUG - 2011-04-23 11:35:36 --> File loaded: application/views/table/main.php
DEBUG - 2011-04-23 11:35:36 --> Helper loaded: url_helper
DEBUG - 2011-04-23 11:35:36 --> File loaded: application/views/common/header.php
DEBUG - 2011-04-23 11:35:36 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-04-23 11:35:36 --> File loaded: application/views/common/footer.php
DEBUG - 2011-04-23 11:35:36 --> File loaded: application/views/layout/main.php
DEBUG - 2011-04-23 11:35:36 --> Final output sent to browser
DEBUG - 2011-04-23 11:35:36 --> Total execution time: 0.6781
DEBUG - 2011-04-23 12:31:59 --> Config Class Initialized
DEBUG - 2011-04-23 12:31:59 --> Hooks Class Initialized
DEBUG - 2011-04-23 12:31:59 --> Utf8 Class Initialized
DEBUG - 2011-04-23 12:31:59 --> UTF-8 Support Enabled
DEBUG - 2011-04-23 12:31:59 --> URI Class Initialized
DEBUG - 2011-04-23 12:31:59 --> Router Class Initialized
DEBUG - 2011-04-23 12:31:59 --> Output Class Initialized
DEBUG - 2011-04-23 12:31:59 --> Input Class Initialized
DEBUG - 2011-04-23 12:31:59 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-23 12:31:59 --> Language Class Initialized
DEBUG - 2011-04-23 12:31:59 --> Loader Class Initialized
DEBUG - 2011-04-23 12:31:59 --> Controller Class Initialized
DEBUG - 2011-04-23 12:31:59 --> Model Class Initialized
DEBUG - 2011-04-23 12:31:59 --> Model Class Initialized
DEBUG - 2011-04-23 12:31:59 --> Model Class Initialized
DEBUG - 2011-04-23 12:31:59 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-23 12:31:59 --> Database Driver Class Initialized
DEBUG - 2011-04-23 12:31:59 --> File loaded: application/views/table/main.php
DEBUG - 2011-04-23 12:32:00 --> Helper loaded: url_helper
DEBUG - 2011-04-23 12:32:00 --> File loaded: application/views/common/header.php
DEBUG - 2011-04-23 12:32:00 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-04-23 12:32:00 --> File loaded: application/views/common/footer.php
DEBUG - 2011-04-23 12:32:00 --> File loaded: application/views/layout/main.php
DEBUG - 2011-04-23 12:32:00 --> Final output sent to browser
DEBUG - 2011-04-23 12:32:00 --> Total execution time: 1.0369
DEBUG - 2011-04-23 12:32:02 --> Config Class Initialized
DEBUG - 2011-04-23 12:32:02 --> Hooks Class Initialized
DEBUG - 2011-04-23 12:32:02 --> Utf8 Class Initialized
DEBUG - 2011-04-23 12:32:02 --> UTF-8 Support Enabled
DEBUG - 2011-04-23 12:32:02 --> URI Class Initialized
DEBUG - 2011-04-23 12:32:02 --> Router Class Initialized
ERROR - 2011-04-23 12:32:02 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-04-23 12:32:03 --> Config Class Initialized
DEBUG - 2011-04-23 12:32:03 --> Hooks Class Initialized
DEBUG - 2011-04-23 12:32:03 --> Utf8 Class Initialized
DEBUG - 2011-04-23 12:32:03 --> UTF-8 Support Enabled
DEBUG - 2011-04-23 12:32:03 --> URI Class Initialized
DEBUG - 2011-04-23 12:32:03 --> Router Class Initialized
ERROR - 2011-04-23 12:32:03 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-04-23 12:32:04 --> Config Class Initialized
DEBUG - 2011-04-23 12:32:04 --> Hooks Class Initialized
DEBUG - 2011-04-23 12:32:04 --> Utf8 Class Initialized
DEBUG - 2011-04-23 12:32:04 --> UTF-8 Support Enabled
DEBUG - 2011-04-23 12:32:04 --> URI Class Initialized
DEBUG - 2011-04-23 12:32:04 --> Router Class Initialized
ERROR - 2011-04-23 12:32:04 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-04-23 12:32:12 --> Config Class Initialized
DEBUG - 2011-04-23 12:32:12 --> Hooks Class Initialized
DEBUG - 2011-04-23 12:32:12 --> Utf8 Class Initialized
DEBUG - 2011-04-23 12:32:12 --> UTF-8 Support Enabled
DEBUG - 2011-04-23 12:32:12 --> URI Class Initialized
DEBUG - 2011-04-23 12:32:12 --> Router Class Initialized
DEBUG - 2011-04-23 12:32:12 --> Output Class Initialized
DEBUG - 2011-04-23 12:32:12 --> Input Class Initialized
DEBUG - 2011-04-23 12:32:12 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-23 12:32:12 --> Language Class Initialized
DEBUG - 2011-04-23 12:32:12 --> Loader Class Initialized
DEBUG - 2011-04-23 12:32:12 --> Controller Class Initialized
DEBUG - 2011-04-23 12:32:12 --> Model Class Initialized
DEBUG - 2011-04-23 12:32:12 --> Model Class Initialized
DEBUG - 2011-04-23 12:32:12 --> Model Class Initialized
DEBUG - 2011-04-23 12:32:12 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-23 12:32:12 --> Database Driver Class Initialized
DEBUG - 2011-04-23 12:32:13 --> File loaded: application/views/table/main.php
DEBUG - 2011-04-23 12:32:13 --> Helper loaded: url_helper
DEBUG - 2011-04-23 12:32:13 --> File loaded: application/views/common/header.php
DEBUG - 2011-04-23 12:32:13 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-04-23 12:32:13 --> File loaded: application/views/common/footer.php
DEBUG - 2011-04-23 12:32:13 --> File loaded: application/views/layout/main.php
DEBUG - 2011-04-23 12:32:13 --> Final output sent to browser
DEBUG - 2011-04-23 12:32:13 --> Total execution time: 0.9386
DEBUG - 2011-04-23 12:32:16 --> Config Class Initialized
DEBUG - 2011-04-23 12:32:16 --> Hooks Class Initialized
DEBUG - 2011-04-23 12:32:16 --> Utf8 Class Initialized
DEBUG - 2011-04-23 12:32:16 --> UTF-8 Support Enabled
DEBUG - 2011-04-23 12:32:16 --> URI Class Initialized
DEBUG - 2011-04-23 12:32:16 --> Router Class Initialized
ERROR - 2011-04-23 12:32:16 --> 404 Page Not Found --> robots.txt
DEBUG - 2011-04-23 12:32:16 --> Config Class Initialized
DEBUG - 2011-04-23 12:32:16 --> Hooks Class Initialized
DEBUG - 2011-04-23 12:32:16 --> Utf8 Class Initialized
DEBUG - 2011-04-23 12:32:16 --> UTF-8 Support Enabled
DEBUG - 2011-04-23 12:32:16 --> URI Class Initialized
DEBUG - 2011-04-23 12:32:16 --> Router Class Initialized
DEBUG - 2011-04-23 12:32:16 --> Output Class Initialized
DEBUG - 2011-04-23 12:32:16 --> Input Class Initialized
DEBUG - 2011-04-23 12:32:16 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-23 12:32:16 --> Language Class Initialized
DEBUG - 2011-04-23 12:32:16 --> Loader Class Initialized
DEBUG - 2011-04-23 12:32:16 --> Controller Class Initialized
DEBUG - 2011-04-23 12:32:16 --> Model Class Initialized
DEBUG - 2011-04-23 12:32:16 --> Model Class Initialized
DEBUG - 2011-04-23 12:32:16 --> Model Class Initialized
DEBUG - 2011-04-23 12:32:16 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-23 12:32:16 --> Database Driver Class Initialized
DEBUG - 2011-04-23 12:32:16 --> File loaded: application/views/table/main.php
DEBUG - 2011-04-23 12:32:16 --> Helper loaded: url_helper
DEBUG - 2011-04-23 12:32:16 --> File loaded: application/views/common/header.php
DEBUG - 2011-04-23 12:32:16 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-04-23 12:32:16 --> File loaded: application/views/common/footer.php
DEBUG - 2011-04-23 12:32:16 --> File loaded: application/views/layout/main.php
DEBUG - 2011-04-23 12:32:16 --> Final output sent to browser
DEBUG - 2011-04-23 12:32:16 --> Total execution time: 0.0502
DEBUG - 2011-04-23 12:32:23 --> Config Class Initialized
DEBUG - 2011-04-23 12:32:23 --> Hooks Class Initialized
DEBUG - 2011-04-23 12:32:23 --> Utf8 Class Initialized
DEBUG - 2011-04-23 12:32:23 --> UTF-8 Support Enabled
DEBUG - 2011-04-23 12:32:23 --> URI Class Initialized
DEBUG - 2011-04-23 12:32:23 --> Router Class Initialized
DEBUG - 2011-04-23 12:32:23 --> Output Class Initialized
DEBUG - 2011-04-23 12:32:23 --> Input Class Initialized
DEBUG - 2011-04-23 12:32:23 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-23 12:32:23 --> Language Class Initialized
DEBUG - 2011-04-23 12:32:23 --> Loader Class Initialized
DEBUG - 2011-04-23 12:32:23 --> Controller Class Initialized
DEBUG - 2011-04-23 12:32:23 --> Model Class Initialized
DEBUG - 2011-04-23 12:32:23 --> Model Class Initialized
DEBUG - 2011-04-23 12:32:23 --> Model Class Initialized
DEBUG - 2011-04-23 12:32:23 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-23 12:32:23 --> Database Driver Class Initialized
DEBUG - 2011-04-23 12:32:23 --> File loaded: application/views/table/main.php
DEBUG - 2011-04-23 12:32:23 --> Helper loaded: url_helper
DEBUG - 2011-04-23 12:32:23 --> File loaded: application/views/common/header.php
DEBUG - 2011-04-23 12:32:23 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-04-23 12:32:23 --> File loaded: application/views/common/footer.php
DEBUG - 2011-04-23 12:32:23 --> File loaded: application/views/layout/main.php
DEBUG - 2011-04-23 12:32:23 --> Final output sent to browser
DEBUG - 2011-04-23 12:32:23 --> Total execution time: 0.1294
DEBUG - 2011-04-23 12:32:41 --> Config Class Initialized
DEBUG - 2011-04-23 12:32:41 --> Hooks Class Initialized
DEBUG - 2011-04-23 12:32:41 --> Utf8 Class Initialized
DEBUG - 2011-04-23 12:32:41 --> UTF-8 Support Enabled
DEBUG - 2011-04-23 12:32:41 --> URI Class Initialized
DEBUG - 2011-04-23 12:32:41 --> Router Class Initialized
DEBUG - 2011-04-23 12:32:41 --> Output Class Initialized
DEBUG - 2011-04-23 12:32:41 --> Input Class Initialized
DEBUG - 2011-04-23 12:32:41 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-23 12:32:41 --> Language Class Initialized
DEBUG - 2011-04-23 12:32:41 --> Loader Class Initialized
DEBUG - 2011-04-23 12:32:41 --> Controller Class Initialized
DEBUG - 2011-04-23 12:32:41 --> Model Class Initialized
DEBUG - 2011-04-23 12:32:41 --> Model Class Initialized
DEBUG - 2011-04-23 12:32:41 --> Model Class Initialized
DEBUG - 2011-04-23 12:32:41 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-23 12:32:41 --> Database Driver Class Initialized
DEBUG - 2011-04-23 12:32:41 --> File loaded: application/views/table/main.php
DEBUG - 2011-04-23 12:32:41 --> Helper loaded: url_helper
DEBUG - 2011-04-23 12:32:41 --> File loaded: application/views/common/header.php
DEBUG - 2011-04-23 12:32:41 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-04-23 12:32:41 --> File loaded: application/views/common/footer.php
DEBUG - 2011-04-23 12:32:41 --> File loaded: application/views/layout/main.php
DEBUG - 2011-04-23 12:32:41 --> Final output sent to browser
DEBUG - 2011-04-23 12:32:41 --> Total execution time: 0.3490
DEBUG - 2011-04-23 12:32:44 --> Config Class Initialized
DEBUG - 2011-04-23 12:32:44 --> Hooks Class Initialized
DEBUG - 2011-04-23 12:32:44 --> Utf8 Class Initialized
DEBUG - 2011-04-23 12:32:44 --> UTF-8 Support Enabled
DEBUG - 2011-04-23 12:32:44 --> URI Class Initialized
DEBUG - 2011-04-23 12:32:44 --> Router Class Initialized
DEBUG - 2011-04-23 12:32:44 --> Output Class Initialized
DEBUG - 2011-04-23 12:32:44 --> Input Class Initialized
DEBUG - 2011-04-23 12:32:44 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-23 12:32:44 --> Language Class Initialized
DEBUG - 2011-04-23 12:32:44 --> Loader Class Initialized
DEBUG - 2011-04-23 12:32:44 --> Controller Class Initialized
DEBUG - 2011-04-23 12:32:44 --> Model Class Initialized
DEBUG - 2011-04-23 12:32:44 --> Model Class Initialized
DEBUG - 2011-04-23 12:32:44 --> Model Class Initialized
DEBUG - 2011-04-23 12:32:44 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-23 12:32:44 --> Database Driver Class Initialized
DEBUG - 2011-04-23 12:32:44 --> File loaded: application/views/table/main.php
DEBUG - 2011-04-23 12:32:44 --> Helper loaded: url_helper
DEBUG - 2011-04-23 12:32:44 --> File loaded: application/views/common/header.php
DEBUG - 2011-04-23 12:32:44 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-04-23 12:32:44 --> File loaded: application/views/common/footer.php
DEBUG - 2011-04-23 12:32:44 --> File loaded: application/views/layout/main.php
DEBUG - 2011-04-23 12:32:44 --> Final output sent to browser
DEBUG - 2011-04-23 12:32:44 --> Total execution time: 0.1066
DEBUG - 2011-04-23 12:32:55 --> Config Class Initialized
DEBUG - 2011-04-23 12:32:55 --> Hooks Class Initialized
DEBUG - 2011-04-23 12:32:55 --> Utf8 Class Initialized
DEBUG - 2011-04-23 12:32:55 --> UTF-8 Support Enabled
DEBUG - 2011-04-23 12:32:55 --> URI Class Initialized
DEBUG - 2011-04-23 12:32:55 --> Router Class Initialized
DEBUG - 2011-04-23 12:32:55 --> Output Class Initialized
DEBUG - 2011-04-23 12:32:55 --> Input Class Initialized
DEBUG - 2011-04-23 12:32:55 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-23 12:32:55 --> Language Class Initialized
DEBUG - 2011-04-23 12:32:55 --> Loader Class Initialized
DEBUG - 2011-04-23 12:32:55 --> Controller Class Initialized
DEBUG - 2011-04-23 12:32:55 --> Model Class Initialized
DEBUG - 2011-04-23 12:32:55 --> Model Class Initialized
DEBUG - 2011-04-23 12:32:55 --> Model Class Initialized
DEBUG - 2011-04-23 12:32:55 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-23 12:32:55 --> Database Driver Class Initialized
DEBUG - 2011-04-23 12:32:56 --> File loaded: application/views/table/main.php
DEBUG - 2011-04-23 12:32:56 --> Helper loaded: url_helper
DEBUG - 2011-04-23 12:32:56 --> File loaded: application/views/common/header.php
DEBUG - 2011-04-23 12:32:56 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-04-23 12:32:56 --> File loaded: application/views/common/footer.php
DEBUG - 2011-04-23 12:32:56 --> File loaded: application/views/layout/main.php
DEBUG - 2011-04-23 12:32:56 --> Final output sent to browser
DEBUG - 2011-04-23 12:32:56 --> Total execution time: 0.2066
DEBUG - 2011-04-23 12:32:57 --> Config Class Initialized
DEBUG - 2011-04-23 12:32:57 --> Hooks Class Initialized
DEBUG - 2011-04-23 12:32:57 --> Utf8 Class Initialized
DEBUG - 2011-04-23 12:32:57 --> UTF-8 Support Enabled
DEBUG - 2011-04-23 12:32:57 --> URI Class Initialized
DEBUG - 2011-04-23 12:32:57 --> Router Class Initialized
DEBUG - 2011-04-23 12:32:57 --> Output Class Initialized
DEBUG - 2011-04-23 12:32:57 --> Input Class Initialized
DEBUG - 2011-04-23 12:32:57 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-23 12:32:57 --> Language Class Initialized
DEBUG - 2011-04-23 12:32:57 --> Loader Class Initialized
DEBUG - 2011-04-23 12:32:57 --> Controller Class Initialized
DEBUG - 2011-04-23 12:32:57 --> Model Class Initialized
DEBUG - 2011-04-23 12:32:57 --> Model Class Initialized
DEBUG - 2011-04-23 12:32:57 --> Model Class Initialized
DEBUG - 2011-04-23 12:32:57 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-23 12:32:57 --> Database Driver Class Initialized
DEBUG - 2011-04-23 12:32:57 --> File loaded: application/views/table/main.php
DEBUG - 2011-04-23 12:32:57 --> Helper loaded: url_helper
DEBUG - 2011-04-23 12:32:57 --> File loaded: application/views/common/header.php
DEBUG - 2011-04-23 12:32:57 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-04-23 12:32:57 --> File loaded: application/views/common/footer.php
DEBUG - 2011-04-23 12:32:57 --> File loaded: application/views/layout/main.php
DEBUG - 2011-04-23 12:32:57 --> Final output sent to browser
DEBUG - 2011-04-23 12:32:57 --> Total execution time: 0.0725
DEBUG - 2011-04-23 12:32:57 --> Config Class Initialized
DEBUG - 2011-04-23 12:32:57 --> Hooks Class Initialized
DEBUG - 2011-04-23 12:32:57 --> Utf8 Class Initialized
DEBUG - 2011-04-23 12:32:57 --> UTF-8 Support Enabled
DEBUG - 2011-04-23 12:32:57 --> URI Class Initialized
DEBUG - 2011-04-23 12:32:57 --> Router Class Initialized
DEBUG - 2011-04-23 12:32:57 --> Output Class Initialized
DEBUG - 2011-04-23 12:32:57 --> Input Class Initialized
DEBUG - 2011-04-23 12:32:57 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-23 12:32:57 --> Language Class Initialized
DEBUG - 2011-04-23 12:32:57 --> Loader Class Initialized
DEBUG - 2011-04-23 12:32:57 --> Controller Class Initialized
DEBUG - 2011-04-23 12:32:57 --> Model Class Initialized
DEBUG - 2011-04-23 12:32:57 --> Model Class Initialized
DEBUG - 2011-04-23 12:32:57 --> Model Class Initialized
DEBUG - 2011-04-23 12:32:57 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-23 12:32:57 --> Database Driver Class Initialized
DEBUG - 2011-04-23 12:32:57 --> File loaded: application/views/table/main.php
DEBUG - 2011-04-23 12:32:57 --> Helper loaded: url_helper
DEBUG - 2011-04-23 12:32:57 --> File loaded: application/views/common/header.php
DEBUG - 2011-04-23 12:32:57 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-04-23 12:32:57 --> File loaded: application/views/common/footer.php
DEBUG - 2011-04-23 12:32:57 --> File loaded: application/views/layout/main.php
DEBUG - 2011-04-23 12:32:57 --> Final output sent to browser
DEBUG - 2011-04-23 12:32:57 --> Total execution time: 0.0429
DEBUG - 2011-04-23 12:32:57 --> Config Class Initialized
DEBUG - 2011-04-23 12:32:57 --> Hooks Class Initialized
DEBUG - 2011-04-23 12:32:57 --> Utf8 Class Initialized
DEBUG - 2011-04-23 12:32:57 --> UTF-8 Support Enabled
DEBUG - 2011-04-23 12:32:57 --> URI Class Initialized
DEBUG - 2011-04-23 12:32:57 --> Router Class Initialized
DEBUG - 2011-04-23 12:32:57 --> Output Class Initialized
DEBUG - 2011-04-23 12:32:57 --> Input Class Initialized
DEBUG - 2011-04-23 12:32:57 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-23 12:32:57 --> Language Class Initialized
DEBUG - 2011-04-23 12:32:57 --> Loader Class Initialized
DEBUG - 2011-04-23 12:32:57 --> Controller Class Initialized
DEBUG - 2011-04-23 12:32:57 --> Model Class Initialized
DEBUG - 2011-04-23 12:32:57 --> Model Class Initialized
DEBUG - 2011-04-23 12:32:57 --> Model Class Initialized
DEBUG - 2011-04-23 12:32:57 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-23 12:32:57 --> Database Driver Class Initialized
DEBUG - 2011-04-23 12:32:57 --> File loaded: application/views/table/main.php
DEBUG - 2011-04-23 12:32:57 --> Helper loaded: url_helper
DEBUG - 2011-04-23 12:32:57 --> File loaded: application/views/common/header.php
DEBUG - 2011-04-23 12:32:57 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-04-23 12:32:57 --> File loaded: application/views/common/footer.php
DEBUG - 2011-04-23 12:32:57 --> File loaded: application/views/layout/main.php
DEBUG - 2011-04-23 12:32:57 --> Final output sent to browser
DEBUG - 2011-04-23 12:32:57 --> Total execution time: 0.0457
DEBUG - 2011-04-23 12:33:03 --> Config Class Initialized
DEBUG - 2011-04-23 12:33:03 --> Hooks Class Initialized
DEBUG - 2011-04-23 12:33:03 --> Utf8 Class Initialized
DEBUG - 2011-04-23 12:33:03 --> UTF-8 Support Enabled
DEBUG - 2011-04-23 12:33:03 --> URI Class Initialized
DEBUG - 2011-04-23 12:33:03 --> Router Class Initialized
DEBUG - 2011-04-23 12:33:03 --> Output Class Initialized
DEBUG - 2011-04-23 12:33:03 --> Input Class Initialized
DEBUG - 2011-04-23 12:33:03 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-23 12:33:03 --> Language Class Initialized
DEBUG - 2011-04-23 12:33:03 --> Loader Class Initialized
DEBUG - 2011-04-23 12:33:03 --> Controller Class Initialized
DEBUG - 2011-04-23 12:33:03 --> Model Class Initialized
DEBUG - 2011-04-23 12:33:03 --> Model Class Initialized
DEBUG - 2011-04-23 12:33:03 --> Model Class Initialized
DEBUG - 2011-04-23 12:33:03 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-23 12:33:03 --> Database Driver Class Initialized
DEBUG - 2011-04-23 12:33:03 --> File loaded: application/views/table/main.php
DEBUG - 2011-04-23 12:33:03 --> Helper loaded: url_helper
DEBUG - 2011-04-23 12:33:03 --> File loaded: application/views/common/header.php
DEBUG - 2011-04-23 12:33:03 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-04-23 12:33:03 --> File loaded: application/views/common/footer.php
DEBUG - 2011-04-23 12:33:03 --> File loaded: application/views/layout/main.php
DEBUG - 2011-04-23 12:33:03 --> Final output sent to browser
DEBUG - 2011-04-23 12:33:03 --> Total execution time: 0.2657
DEBUG - 2011-04-23 12:33:05 --> Config Class Initialized
DEBUG - 2011-04-23 12:33:05 --> Hooks Class Initialized
DEBUG - 2011-04-23 12:33:05 --> Utf8 Class Initialized
DEBUG - 2011-04-23 12:33:05 --> UTF-8 Support Enabled
DEBUG - 2011-04-23 12:33:05 --> URI Class Initialized
DEBUG - 2011-04-23 12:33:05 --> Router Class Initialized
DEBUG - 2011-04-23 12:33:05 --> Output Class Initialized
DEBUG - 2011-04-23 12:33:05 --> Input Class Initialized
DEBUG - 2011-04-23 12:33:05 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-23 12:33:05 --> Language Class Initialized
DEBUG - 2011-04-23 12:33:05 --> Loader Class Initialized
DEBUG - 2011-04-23 12:33:05 --> Controller Class Initialized
DEBUG - 2011-04-23 12:33:05 --> Model Class Initialized
DEBUG - 2011-04-23 12:33:05 --> Model Class Initialized
DEBUG - 2011-04-23 12:33:05 --> Model Class Initialized
DEBUG - 2011-04-23 12:33:05 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-23 12:33:05 --> Database Driver Class Initialized
DEBUG - 2011-04-23 12:33:05 --> File loaded: application/views/table/main.php
DEBUG - 2011-04-23 12:33:05 --> Helper loaded: url_helper
DEBUG - 2011-04-23 12:33:05 --> File loaded: application/views/common/header.php
DEBUG - 2011-04-23 12:33:05 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-04-23 12:33:05 --> File loaded: application/views/common/footer.php
DEBUG - 2011-04-23 12:33:05 --> File loaded: application/views/layout/main.php
DEBUG - 2011-04-23 12:33:05 --> Final output sent to browser
DEBUG - 2011-04-23 12:33:05 --> Total execution time: 0.0515
DEBUG - 2011-04-23 13:26:34 --> Config Class Initialized
DEBUG - 2011-04-23 13:26:34 --> Hooks Class Initialized
DEBUG - 2011-04-23 13:26:34 --> Utf8 Class Initialized
DEBUG - 2011-04-23 13:26:34 --> UTF-8 Support Enabled
DEBUG - 2011-04-23 13:26:34 --> URI Class Initialized
DEBUG - 2011-04-23 13:26:34 --> Router Class Initialized
DEBUG - 2011-04-23 13:26:34 --> Output Class Initialized
DEBUG - 2011-04-23 13:26:34 --> Input Class Initialized
DEBUG - 2011-04-23 13:26:34 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-23 13:26:34 --> Language Class Initialized
DEBUG - 2011-04-23 13:26:34 --> Loader Class Initialized
DEBUG - 2011-04-23 13:26:34 --> Controller Class Initialized
ERROR - 2011-04-23 13:26:34 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-04-23 13:26:34 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-04-23 13:26:34 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-04-23 13:26:34 --> Model Class Initialized
DEBUG - 2011-04-23 13:26:34 --> Model Class Initialized
DEBUG - 2011-04-23 13:26:34 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-23 13:26:34 --> Database Driver Class Initialized
DEBUG - 2011-04-23 13:26:34 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-04-23 13:26:34 --> Helper loaded: url_helper
DEBUG - 2011-04-23 13:26:34 --> File loaded: application/views/common/header.php
DEBUG - 2011-04-23 13:26:34 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-04-23 13:26:34 --> File loaded: application/views/common/footer.php
DEBUG - 2011-04-23 13:26:34 --> File loaded: application/views/layout/main.php
DEBUG - 2011-04-23 13:26:34 --> Final output sent to browser
DEBUG - 2011-04-23 13:26:34 --> Total execution time: 0.3681
DEBUG - 2011-04-23 13:26:39 --> Config Class Initialized
DEBUG - 2011-04-23 13:26:39 --> Hooks Class Initialized
DEBUG - 2011-04-23 13:26:39 --> Utf8 Class Initialized
DEBUG - 2011-04-23 13:26:39 --> UTF-8 Support Enabled
DEBUG - 2011-04-23 13:26:39 --> URI Class Initialized
DEBUG - 2011-04-23 13:26:39 --> Router Class Initialized
DEBUG - 2011-04-23 13:26:39 --> Output Class Initialized
DEBUG - 2011-04-23 13:26:39 --> Input Class Initialized
DEBUG - 2011-04-23 13:26:39 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-23 13:26:39 --> Language Class Initialized
DEBUG - 2011-04-23 13:26:39 --> Loader Class Initialized
DEBUG - 2011-04-23 13:26:39 --> Controller Class Initialized
DEBUG - 2011-04-23 13:26:40 --> Model Class Initialized
DEBUG - 2011-04-23 13:26:40 --> Model Class Initialized
DEBUG - 2011-04-23 13:26:40 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-23 13:26:40 --> Database Driver Class Initialized
DEBUG - 2011-04-23 13:26:40 --> Final output sent to browser
DEBUG - 2011-04-23 13:26:40 --> Total execution time: 0.9691
DEBUG - 2011-04-23 15:43:31 --> Config Class Initialized
DEBUG - 2011-04-23 15:43:31 --> Hooks Class Initialized
DEBUG - 2011-04-23 15:43:31 --> Utf8 Class Initialized
DEBUG - 2011-04-23 15:43:31 --> UTF-8 Support Enabled
DEBUG - 2011-04-23 15:43:31 --> URI Class Initialized
DEBUG - 2011-04-23 15:43:31 --> Router Class Initialized
ERROR - 2011-04-23 15:43:31 --> 404 Page Not Found --> robots.txt
DEBUG - 2011-04-23 15:44:19 --> Config Class Initialized
DEBUG - 2011-04-23 15:44:19 --> Hooks Class Initialized
DEBUG - 2011-04-23 15:44:19 --> Utf8 Class Initialized
DEBUG - 2011-04-23 15:44:19 --> UTF-8 Support Enabled
DEBUG - 2011-04-23 15:44:19 --> URI Class Initialized
DEBUG - 2011-04-23 15:44:19 --> Router Class Initialized
DEBUG - 2011-04-23 15:44:19 --> No URI present. Default controller set.
DEBUG - 2011-04-23 15:44:19 --> Output Class Initialized
DEBUG - 2011-04-23 15:44:19 --> Input Class Initialized
DEBUG - 2011-04-23 15:44:19 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-23 15:44:19 --> Language Class Initialized
DEBUG - 2011-04-23 15:44:19 --> Loader Class Initialized
DEBUG - 2011-04-23 15:44:19 --> Controller Class Initialized
DEBUG - 2011-04-23 15:44:19 --> File loaded: application/views/splash/main.php
DEBUG - 2011-04-23 15:44:19 --> Helper loaded: url_helper
DEBUG - 2011-04-23 15:44:19 --> File loaded: application/views/common/header.php
DEBUG - 2011-04-23 15:44:19 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-04-23 15:44:19 --> File loaded: application/views/common/footer.php
DEBUG - 2011-04-23 15:44:19 --> File loaded: application/views/layout/main.php
DEBUG - 2011-04-23 15:44:19 --> Final output sent to browser
DEBUG - 2011-04-23 15:44:19 --> Total execution time: 0.2071
DEBUG - 2011-04-23 16:57:44 --> Config Class Initialized
DEBUG - 2011-04-23 16:57:44 --> Hooks Class Initialized
DEBUG - 2011-04-23 16:57:44 --> Utf8 Class Initialized
DEBUG - 2011-04-23 16:57:44 --> UTF-8 Support Enabled
DEBUG - 2011-04-23 16:57:44 --> URI Class Initialized
DEBUG - 2011-04-23 16:57:44 --> Router Class Initialized
DEBUG - 2011-04-23 16:57:44 --> Output Class Initialized
DEBUG - 2011-04-23 16:57:44 --> Input Class Initialized
DEBUG - 2011-04-23 16:57:44 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-23 16:57:44 --> Language Class Initialized
DEBUG - 2011-04-23 16:57:44 --> Loader Class Initialized
DEBUG - 2011-04-23 16:57:44 --> Controller Class Initialized
DEBUG - 2011-04-23 16:57:44 --> Model Class Initialized
DEBUG - 2011-04-23 16:57:44 --> Model Class Initialized
DEBUG - 2011-04-23 16:57:44 --> Model Class Initialized
DEBUG - 2011-04-23 16:57:44 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-23 16:57:44 --> Database Driver Class Initialized
DEBUG - 2011-04-23 16:57:45 --> File loaded: application/views/table/main.php
DEBUG - 2011-04-23 16:57:45 --> Helper loaded: url_helper
DEBUG - 2011-04-23 16:57:45 --> File loaded: application/views/common/header.php
DEBUG - 2011-04-23 16:57:45 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-04-23 16:57:45 --> File loaded: application/views/common/footer.php
DEBUG - 2011-04-23 16:57:45 --> File loaded: application/views/layout/main.php
DEBUG - 2011-04-23 16:57:45 --> Final output sent to browser
DEBUG - 2011-04-23 16:57:45 --> Total execution time: 0.6082
DEBUG - 2011-04-23 16:57:45 --> Config Class Initialized
DEBUG - 2011-04-23 16:57:45 --> Hooks Class Initialized
DEBUG - 2011-04-23 16:57:45 --> Utf8 Class Initialized
DEBUG - 2011-04-23 16:57:45 --> UTF-8 Support Enabled
DEBUG - 2011-04-23 16:57:45 --> URI Class Initialized
DEBUG - 2011-04-23 16:57:45 --> Router Class Initialized
DEBUG - 2011-04-23 16:57:45 --> Output Class Initialized
DEBUG - 2011-04-23 16:57:45 --> Input Class Initialized
DEBUG - 2011-04-23 16:57:45 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-23 16:57:45 --> Language Class Initialized
DEBUG - 2011-04-23 16:57:45 --> Loader Class Initialized
DEBUG - 2011-04-23 16:57:45 --> Controller Class Initialized
ERROR - 2011-04-23 16:57:45 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-04-23 16:57:45 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-04-23 16:57:45 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-04-23 16:57:45 --> Model Class Initialized
DEBUG - 2011-04-23 16:57:45 --> Model Class Initialized
DEBUG - 2011-04-23 16:57:45 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-23 16:57:45 --> Database Driver Class Initialized
DEBUG - 2011-04-23 16:57:45 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-04-23 16:57:45 --> Helper loaded: url_helper
DEBUG - 2011-04-23 16:57:45 --> File loaded: application/views/common/header.php
DEBUG - 2011-04-23 16:57:45 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-04-23 16:57:45 --> File loaded: application/views/common/footer.php
DEBUG - 2011-04-23 16:57:45 --> File loaded: application/views/layout/main.php
DEBUG - 2011-04-23 16:57:45 --> Final output sent to browser
DEBUG - 2011-04-23 16:57:45 --> Total execution time: 0.0906
DEBUG - 2011-04-23 17:23:16 --> Config Class Initialized
DEBUG - 2011-04-23 17:23:16 --> Hooks Class Initialized
DEBUG - 2011-04-23 17:23:16 --> Utf8 Class Initialized
DEBUG - 2011-04-23 17:23:16 --> UTF-8 Support Enabled
DEBUG - 2011-04-23 17:23:16 --> URI Class Initialized
DEBUG - 2011-04-23 17:23:16 --> Router Class Initialized
DEBUG - 2011-04-23 17:23:16 --> Output Class Initialized
DEBUG - 2011-04-23 17:23:16 --> Input Class Initialized
DEBUG - 2011-04-23 17:23:16 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-23 17:23:16 --> Language Class Initialized
DEBUG - 2011-04-23 17:23:16 --> Loader Class Initialized
DEBUG - 2011-04-23 17:23:16 --> Controller Class Initialized
ERROR - 2011-04-23 17:23:16 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-04-23 17:23:16 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-04-23 17:23:16 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-04-23 17:23:16 --> Model Class Initialized
DEBUG - 2011-04-23 17:23:16 --> Model Class Initialized
DEBUG - 2011-04-23 17:23:16 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-23 17:23:16 --> Database Driver Class Initialized
DEBUG - 2011-04-23 17:23:16 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-04-23 17:23:16 --> Helper loaded: url_helper
DEBUG - 2011-04-23 17:23:16 --> File loaded: application/views/common/header.php
DEBUG - 2011-04-23 17:23:16 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-04-23 17:23:16 --> File loaded: application/views/common/footer.php
DEBUG - 2011-04-23 17:23:16 --> File loaded: application/views/layout/main.php
DEBUG - 2011-04-23 17:23:16 --> Final output sent to browser
DEBUG - 2011-04-23 17:23:16 --> Total execution time: 0.1268
DEBUG - 2011-04-23 17:23:16 --> Config Class Initialized
DEBUG - 2011-04-23 17:23:16 --> Hooks Class Initialized
DEBUG - 2011-04-23 17:23:16 --> Utf8 Class Initialized
DEBUG - 2011-04-23 17:23:16 --> UTF-8 Support Enabled
DEBUG - 2011-04-23 17:23:16 --> URI Class Initialized
DEBUG - 2011-04-23 17:23:16 --> Router Class Initialized
DEBUG - 2011-04-23 17:23:16 --> Output Class Initialized
DEBUG - 2011-04-23 17:23:16 --> Input Class Initialized
DEBUG - 2011-04-23 17:23:16 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-23 17:23:16 --> Language Class Initialized
DEBUG - 2011-04-23 17:23:16 --> Loader Class Initialized
DEBUG - 2011-04-23 17:23:16 --> Controller Class Initialized
DEBUG - 2011-04-23 17:23:16 --> Model Class Initialized
DEBUG - 2011-04-23 17:23:16 --> Model Class Initialized
DEBUG - 2011-04-23 17:23:16 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-23 17:23:16 --> Database Driver Class Initialized
DEBUG - 2011-04-23 17:23:17 --> Final output sent to browser
DEBUG - 2011-04-23 17:23:17 --> Total execution time: 0.5843
DEBUG - 2011-04-23 17:23:18 --> Config Class Initialized
DEBUG - 2011-04-23 17:23:18 --> Hooks Class Initialized
DEBUG - 2011-04-23 17:23:18 --> Utf8 Class Initialized
DEBUG - 2011-04-23 17:23:18 --> UTF-8 Support Enabled
DEBUG - 2011-04-23 17:23:18 --> URI Class Initialized
DEBUG - 2011-04-23 17:23:18 --> Router Class Initialized
ERROR - 2011-04-23 17:23:18 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-04-23 17:28:09 --> Config Class Initialized
DEBUG - 2011-04-23 17:28:09 --> Hooks Class Initialized
DEBUG - 2011-04-23 17:28:09 --> Utf8 Class Initialized
DEBUG - 2011-04-23 17:28:09 --> UTF-8 Support Enabled
DEBUG - 2011-04-23 17:28:09 --> URI Class Initialized
DEBUG - 2011-04-23 17:28:09 --> Router Class Initialized
DEBUG - 2011-04-23 17:28:09 --> Output Class Initialized
DEBUG - 2011-04-23 17:28:09 --> Input Class Initialized
DEBUG - 2011-04-23 17:28:09 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-23 17:28:09 --> Language Class Initialized
DEBUG - 2011-04-23 17:28:09 --> Loader Class Initialized
DEBUG - 2011-04-23 17:28:09 --> Controller Class Initialized
DEBUG - 2011-04-23 17:28:09 --> Model Class Initialized
DEBUG - 2011-04-23 17:28:09 --> Model Class Initialized
DEBUG - 2011-04-23 17:28:09 --> Model Class Initialized
DEBUG - 2011-04-23 17:28:09 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-23 17:28:09 --> Database Driver Class Initialized
DEBUG - 2011-04-23 17:28:09 --> File loaded: application/views/table/main.php
DEBUG - 2011-04-23 17:28:09 --> Helper loaded: url_helper
DEBUG - 2011-04-23 17:28:09 --> File loaded: application/views/common/header.php
DEBUG - 2011-04-23 17:28:09 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-04-23 17:28:09 --> File loaded: application/views/common/footer.php
DEBUG - 2011-04-23 17:28:09 --> File loaded: application/views/layout/main.php
DEBUG - 2011-04-23 17:28:09 --> Final output sent to browser
DEBUG - 2011-04-23 17:28:09 --> Total execution time: 0.2210
DEBUG - 2011-04-23 17:28:11 --> Config Class Initialized
DEBUG - 2011-04-23 17:28:11 --> Hooks Class Initialized
DEBUG - 2011-04-23 17:28:11 --> Utf8 Class Initialized
DEBUG - 2011-04-23 17:28:11 --> UTF-8 Support Enabled
DEBUG - 2011-04-23 17:28:11 --> URI Class Initialized
DEBUG - 2011-04-23 17:28:11 --> Router Class Initialized
ERROR - 2011-04-23 17:28:11 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-04-23 17:28:11 --> Config Class Initialized
DEBUG - 2011-04-23 17:28:11 --> Hooks Class Initialized
DEBUG - 2011-04-23 17:28:11 --> Utf8 Class Initialized
DEBUG - 2011-04-23 17:28:11 --> UTF-8 Support Enabled
DEBUG - 2011-04-23 17:28:11 --> URI Class Initialized
DEBUG - 2011-04-23 17:28:11 --> Router Class Initialized
ERROR - 2011-04-23 17:28:11 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-04-23 17:28:14 --> Config Class Initialized
DEBUG - 2011-04-23 17:28:14 --> Hooks Class Initialized
DEBUG - 2011-04-23 17:28:14 --> Utf8 Class Initialized
DEBUG - 2011-04-23 17:28:14 --> UTF-8 Support Enabled
DEBUG - 2011-04-23 17:28:14 --> URI Class Initialized
DEBUG - 2011-04-23 17:28:14 --> Router Class Initialized
ERROR - 2011-04-23 17:28:14 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-04-23 17:28:15 --> Config Class Initialized
DEBUG - 2011-04-23 17:28:15 --> Hooks Class Initialized
DEBUG - 2011-04-23 17:28:15 --> Utf8 Class Initialized
DEBUG - 2011-04-23 17:28:15 --> UTF-8 Support Enabled
DEBUG - 2011-04-23 17:28:15 --> URI Class Initialized
DEBUG - 2011-04-23 17:28:15 --> Router Class Initialized
DEBUG - 2011-04-23 17:28:15 --> Output Class Initialized
DEBUG - 2011-04-23 17:28:15 --> Input Class Initialized
DEBUG - 2011-04-23 17:28:15 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-23 17:28:15 --> Language Class Initialized
DEBUG - 2011-04-23 17:28:15 --> Loader Class Initialized
DEBUG - 2011-04-23 17:28:15 --> Controller Class Initialized
ERROR - 2011-04-23 17:28:15 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-04-23 17:28:15 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-04-23 17:28:15 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-04-23 17:28:15 --> Model Class Initialized
DEBUG - 2011-04-23 17:28:15 --> Model Class Initialized
DEBUG - 2011-04-23 17:28:15 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-23 17:28:15 --> Database Driver Class Initialized
DEBUG - 2011-04-23 17:28:15 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-04-23 17:28:15 --> Helper loaded: url_helper
DEBUG - 2011-04-23 17:28:15 --> File loaded: application/views/common/header.php
DEBUG - 2011-04-23 17:28:15 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-04-23 17:28:15 --> File loaded: application/views/common/footer.php
DEBUG - 2011-04-23 17:28:15 --> File loaded: application/views/layout/main.php
DEBUG - 2011-04-23 17:28:15 --> Final output sent to browser
DEBUG - 2011-04-23 17:28:15 --> Total execution time: 0.0281
DEBUG - 2011-04-23 17:28:15 --> Config Class Initialized
DEBUG - 2011-04-23 17:28:15 --> Hooks Class Initialized
DEBUG - 2011-04-23 17:28:15 --> Utf8 Class Initialized
DEBUG - 2011-04-23 17:28:15 --> UTF-8 Support Enabled
DEBUG - 2011-04-23 17:28:15 --> URI Class Initialized
DEBUG - 2011-04-23 17:28:15 --> Router Class Initialized
DEBUG - 2011-04-23 17:28:15 --> Output Class Initialized
DEBUG - 2011-04-23 17:28:15 --> Input Class Initialized
DEBUG - 2011-04-23 17:28:15 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-23 17:28:15 --> Language Class Initialized
DEBUG - 2011-04-23 17:28:15 --> Loader Class Initialized
DEBUG - 2011-04-23 17:28:15 --> Controller Class Initialized
DEBUG - 2011-04-23 17:28:15 --> Model Class Initialized
DEBUG - 2011-04-23 17:28:15 --> Model Class Initialized
DEBUG - 2011-04-23 17:28:15 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-23 17:28:15 --> Database Driver Class Initialized
DEBUG - 2011-04-23 17:28:16 --> Final output sent to browser
DEBUG - 2011-04-23 17:28:16 --> Total execution time: 0.6321
DEBUG - 2011-04-23 17:28:32 --> Config Class Initialized
DEBUG - 2011-04-23 17:28:32 --> Hooks Class Initialized
DEBUG - 2011-04-23 17:28:32 --> Utf8 Class Initialized
DEBUG - 2011-04-23 17:28:32 --> UTF-8 Support Enabled
DEBUG - 2011-04-23 17:28:32 --> URI Class Initialized
DEBUG - 2011-04-23 17:28:32 --> Router Class Initialized
DEBUG - 2011-04-23 17:28:32 --> Output Class Initialized
DEBUG - 2011-04-23 17:28:32 --> Input Class Initialized
DEBUG - 2011-04-23 17:28:32 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-23 17:28:32 --> Language Class Initialized
DEBUG - 2011-04-23 17:28:32 --> Loader Class Initialized
DEBUG - 2011-04-23 17:28:32 --> Controller Class Initialized
ERROR - 2011-04-23 17:28:32 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-04-23 17:28:32 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-04-23 17:28:32 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-04-23 17:28:32 --> Model Class Initialized
DEBUG - 2011-04-23 17:28:32 --> Model Class Initialized
DEBUG - 2011-04-23 17:28:32 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-23 17:28:32 --> Database Driver Class Initialized
DEBUG - 2011-04-23 17:28:32 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-04-23 17:28:32 --> Helper loaded: url_helper
DEBUG - 2011-04-23 17:28:32 --> File loaded: application/views/common/header.php
DEBUG - 2011-04-23 17:28:32 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-04-23 17:28:32 --> File loaded: application/views/common/footer.php
DEBUG - 2011-04-23 17:28:32 --> File loaded: application/views/layout/main.php
DEBUG - 2011-04-23 17:28:32 --> Final output sent to browser
DEBUG - 2011-04-23 17:28:32 --> Total execution time: 0.0294
DEBUG - 2011-04-23 17:28:32 --> Config Class Initialized
DEBUG - 2011-04-23 17:28:32 --> Hooks Class Initialized
DEBUG - 2011-04-23 17:28:32 --> Utf8 Class Initialized
DEBUG - 2011-04-23 17:28:32 --> UTF-8 Support Enabled
DEBUG - 2011-04-23 17:28:32 --> URI Class Initialized
DEBUG - 2011-04-23 17:28:32 --> Router Class Initialized
DEBUG - 2011-04-23 17:28:32 --> Output Class Initialized
DEBUG - 2011-04-23 17:28:32 --> Input Class Initialized
DEBUG - 2011-04-23 17:28:32 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-23 17:28:32 --> Language Class Initialized
DEBUG - 2011-04-23 17:28:32 --> Loader Class Initialized
DEBUG - 2011-04-23 17:28:32 --> Controller Class Initialized
DEBUG - 2011-04-23 17:28:32 --> Model Class Initialized
DEBUG - 2011-04-23 17:28:32 --> Model Class Initialized
DEBUG - 2011-04-23 17:28:32 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-23 17:28:32 --> Database Driver Class Initialized
DEBUG - 2011-04-23 17:28:33 --> Final output sent to browser
DEBUG - 2011-04-23 17:28:33 --> Total execution time: 0.6283
DEBUG - 2011-04-23 17:28:53 --> Config Class Initialized
DEBUG - 2011-04-23 17:28:53 --> Hooks Class Initialized
DEBUG - 2011-04-23 17:28:53 --> Utf8 Class Initialized
DEBUG - 2011-04-23 17:28:53 --> UTF-8 Support Enabled
DEBUG - 2011-04-23 17:28:53 --> URI Class Initialized
DEBUG - 2011-04-23 17:28:53 --> Router Class Initialized
DEBUG - 2011-04-23 17:28:53 --> Output Class Initialized
DEBUG - 2011-04-23 17:28:53 --> Input Class Initialized
DEBUG - 2011-04-23 17:28:53 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-23 17:28:53 --> Language Class Initialized
DEBUG - 2011-04-23 17:28:53 --> Loader Class Initialized
DEBUG - 2011-04-23 17:28:53 --> Controller Class Initialized
ERROR - 2011-04-23 17:28:53 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-04-23 17:28:53 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-04-23 17:28:53 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-04-23 17:28:53 --> Model Class Initialized
DEBUG - 2011-04-23 17:28:53 --> Model Class Initialized
DEBUG - 2011-04-23 17:28:53 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-23 17:28:53 --> Database Driver Class Initialized
DEBUG - 2011-04-23 17:28:53 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-04-23 17:28:53 --> Helper loaded: url_helper
DEBUG - 2011-04-23 17:28:53 --> File loaded: application/views/common/header.php
DEBUG - 2011-04-23 17:28:53 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-04-23 17:28:53 --> File loaded: application/views/common/footer.php
DEBUG - 2011-04-23 17:28:53 --> File loaded: application/views/layout/main.php
DEBUG - 2011-04-23 17:28:53 --> Final output sent to browser
DEBUG - 2011-04-23 17:28:53 --> Total execution time: 0.0370
DEBUG - 2011-04-23 17:28:53 --> Config Class Initialized
DEBUG - 2011-04-23 17:28:53 --> Hooks Class Initialized
DEBUG - 2011-04-23 17:28:53 --> Utf8 Class Initialized
DEBUG - 2011-04-23 17:28:53 --> UTF-8 Support Enabled
DEBUG - 2011-04-23 17:28:53 --> URI Class Initialized
DEBUG - 2011-04-23 17:28:53 --> Router Class Initialized
DEBUG - 2011-04-23 17:28:53 --> Output Class Initialized
DEBUG - 2011-04-23 17:28:53 --> Input Class Initialized
DEBUG - 2011-04-23 17:28:53 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-23 17:28:53 --> Language Class Initialized
DEBUG - 2011-04-23 17:28:53 --> Loader Class Initialized
DEBUG - 2011-04-23 17:28:53 --> Controller Class Initialized
DEBUG - 2011-04-23 17:28:53 --> Model Class Initialized
DEBUG - 2011-04-23 17:28:53 --> Model Class Initialized
DEBUG - 2011-04-23 17:28:53 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-23 17:28:53 --> Database Driver Class Initialized
DEBUG - 2011-04-23 17:28:54 --> Final output sent to browser
DEBUG - 2011-04-23 17:28:54 --> Total execution time: 0.6876
DEBUG - 2011-04-23 17:29:16 --> Config Class Initialized
DEBUG - 2011-04-23 17:29:16 --> Hooks Class Initialized
DEBUG - 2011-04-23 17:29:16 --> Utf8 Class Initialized
DEBUG - 2011-04-23 17:29:16 --> UTF-8 Support Enabled
DEBUG - 2011-04-23 17:29:16 --> URI Class Initialized
DEBUG - 2011-04-23 17:29:16 --> Router Class Initialized
DEBUG - 2011-04-23 17:29:16 --> Output Class Initialized
DEBUG - 2011-04-23 17:29:16 --> Input Class Initialized
DEBUG - 2011-04-23 17:29:16 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-23 17:29:16 --> Language Class Initialized
DEBUG - 2011-04-23 17:29:16 --> Loader Class Initialized
DEBUG - 2011-04-23 17:29:16 --> Controller Class Initialized
ERROR - 2011-04-23 17:29:16 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-04-23 17:29:16 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-04-23 17:29:16 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-04-23 17:29:16 --> Model Class Initialized
DEBUG - 2011-04-23 17:29:16 --> Model Class Initialized
DEBUG - 2011-04-23 17:29:16 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-23 17:29:16 --> Database Driver Class Initialized
DEBUG - 2011-04-23 17:29:16 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-04-23 17:29:16 --> Helper loaded: url_helper
DEBUG - 2011-04-23 17:29:16 --> File loaded: application/views/common/header.php
DEBUG - 2011-04-23 17:29:16 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-04-23 17:29:16 --> File loaded: application/views/common/footer.php
DEBUG - 2011-04-23 17:29:16 --> File loaded: application/views/layout/main.php
DEBUG - 2011-04-23 17:29:16 --> Final output sent to browser
DEBUG - 2011-04-23 17:29:16 --> Total execution time: 0.0297
DEBUG - 2011-04-23 17:29:16 --> Config Class Initialized
DEBUG - 2011-04-23 17:29:16 --> Hooks Class Initialized
DEBUG - 2011-04-23 17:29:16 --> Utf8 Class Initialized
DEBUG - 2011-04-23 17:29:16 --> UTF-8 Support Enabled
DEBUG - 2011-04-23 17:29:16 --> URI Class Initialized
DEBUG - 2011-04-23 17:29:16 --> Router Class Initialized
DEBUG - 2011-04-23 17:29:16 --> Output Class Initialized
DEBUG - 2011-04-23 17:29:16 --> Input Class Initialized
DEBUG - 2011-04-23 17:29:16 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-23 17:29:16 --> Language Class Initialized
DEBUG - 2011-04-23 17:29:16 --> Loader Class Initialized
DEBUG - 2011-04-23 17:29:16 --> Controller Class Initialized
DEBUG - 2011-04-23 17:29:16 --> Model Class Initialized
DEBUG - 2011-04-23 17:29:16 --> Model Class Initialized
DEBUG - 2011-04-23 17:29:16 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-23 17:29:16 --> Database Driver Class Initialized
DEBUG - 2011-04-23 17:29:17 --> Final output sent to browser
DEBUG - 2011-04-23 17:29:17 --> Total execution time: 0.5572
DEBUG - 2011-04-23 17:29:42 --> Config Class Initialized
DEBUG - 2011-04-23 17:29:42 --> Hooks Class Initialized
DEBUG - 2011-04-23 17:29:42 --> Utf8 Class Initialized
DEBUG - 2011-04-23 17:29:42 --> UTF-8 Support Enabled
DEBUG - 2011-04-23 17:29:42 --> URI Class Initialized
DEBUG - 2011-04-23 17:29:42 --> Router Class Initialized
DEBUG - 2011-04-23 17:29:42 --> Output Class Initialized
DEBUG - 2011-04-23 17:29:42 --> Input Class Initialized
DEBUG - 2011-04-23 17:29:42 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-23 17:29:42 --> Language Class Initialized
DEBUG - 2011-04-23 17:29:42 --> Loader Class Initialized
DEBUG - 2011-04-23 17:29:42 --> Controller Class Initialized
ERROR - 2011-04-23 17:29:42 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-04-23 17:29:42 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-04-23 17:29:42 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-04-23 17:29:42 --> Model Class Initialized
DEBUG - 2011-04-23 17:29:42 --> Model Class Initialized
DEBUG - 2011-04-23 17:29:42 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-23 17:29:42 --> Database Driver Class Initialized
DEBUG - 2011-04-23 17:29:42 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-04-23 17:29:42 --> Helper loaded: url_helper
DEBUG - 2011-04-23 17:29:42 --> File loaded: application/views/common/header.php
DEBUG - 2011-04-23 17:29:42 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-04-23 17:29:42 --> File loaded: application/views/common/footer.php
DEBUG - 2011-04-23 17:29:42 --> File loaded: application/views/layout/main.php
DEBUG - 2011-04-23 17:29:42 --> Final output sent to browser
DEBUG - 2011-04-23 17:29:42 --> Total execution time: 0.0313
DEBUG - 2011-04-23 17:29:43 --> Config Class Initialized
DEBUG - 2011-04-23 17:29:43 --> Hooks Class Initialized
DEBUG - 2011-04-23 17:29:43 --> Utf8 Class Initialized
DEBUG - 2011-04-23 17:29:43 --> UTF-8 Support Enabled
DEBUG - 2011-04-23 17:29:43 --> URI Class Initialized
DEBUG - 2011-04-23 17:29:43 --> Router Class Initialized
DEBUG - 2011-04-23 17:29:43 --> Output Class Initialized
DEBUG - 2011-04-23 17:29:43 --> Input Class Initialized
DEBUG - 2011-04-23 17:29:43 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-23 17:29:43 --> Language Class Initialized
DEBUG - 2011-04-23 17:29:43 --> Loader Class Initialized
DEBUG - 2011-04-23 17:29:43 --> Controller Class Initialized
DEBUG - 2011-04-23 17:29:43 --> Model Class Initialized
DEBUG - 2011-04-23 17:29:43 --> Model Class Initialized
DEBUG - 2011-04-23 17:29:43 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-23 17:29:43 --> Database Driver Class Initialized
DEBUG - 2011-04-23 17:29:43 --> Final output sent to browser
DEBUG - 2011-04-23 17:29:43 --> Total execution time: 0.6126
DEBUG - 2011-04-23 17:29:50 --> Config Class Initialized
DEBUG - 2011-04-23 17:29:50 --> Hooks Class Initialized
DEBUG - 2011-04-23 17:29:50 --> Utf8 Class Initialized
DEBUG - 2011-04-23 17:29:50 --> UTF-8 Support Enabled
DEBUG - 2011-04-23 17:29:50 --> URI Class Initialized
DEBUG - 2011-04-23 17:29:50 --> Router Class Initialized
DEBUG - 2011-04-23 17:29:50 --> Output Class Initialized
DEBUG - 2011-04-23 17:29:50 --> Input Class Initialized
DEBUG - 2011-04-23 17:29:50 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-23 17:29:50 --> Language Class Initialized
DEBUG - 2011-04-23 17:29:50 --> Loader Class Initialized
DEBUG - 2011-04-23 17:29:50 --> Controller Class Initialized
ERROR - 2011-04-23 17:29:50 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-04-23 17:29:50 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-04-23 17:29:50 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-04-23 17:29:50 --> Model Class Initialized
DEBUG - 2011-04-23 17:29:50 --> Model Class Initialized
DEBUG - 2011-04-23 17:29:50 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-23 17:29:50 --> Database Driver Class Initialized
DEBUG - 2011-04-23 17:29:50 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-04-23 17:29:50 --> Helper loaded: url_helper
DEBUG - 2011-04-23 17:29:50 --> File loaded: application/views/common/header.php
DEBUG - 2011-04-23 17:29:50 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-04-23 17:29:50 --> File loaded: application/views/common/footer.php
DEBUG - 2011-04-23 17:29:50 --> File loaded: application/views/layout/main.php
DEBUG - 2011-04-23 17:29:50 --> Final output sent to browser
DEBUG - 2011-04-23 17:29:50 --> Total execution time: 0.0395
DEBUG - 2011-04-23 17:29:51 --> Config Class Initialized
DEBUG - 2011-04-23 17:29:51 --> Hooks Class Initialized
DEBUG - 2011-04-23 17:29:51 --> Utf8 Class Initialized
DEBUG - 2011-04-23 17:29:51 --> UTF-8 Support Enabled
DEBUG - 2011-04-23 17:29:51 --> URI Class Initialized
DEBUG - 2011-04-23 17:29:51 --> Router Class Initialized
DEBUG - 2011-04-23 17:29:51 --> Output Class Initialized
DEBUG - 2011-04-23 17:29:51 --> Input Class Initialized
DEBUG - 2011-04-23 17:29:51 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-23 17:29:51 --> Language Class Initialized
DEBUG - 2011-04-23 17:29:51 --> Loader Class Initialized
DEBUG - 2011-04-23 17:29:51 --> Controller Class Initialized
DEBUG - 2011-04-23 17:29:51 --> Model Class Initialized
DEBUG - 2011-04-23 17:29:51 --> Model Class Initialized
DEBUG - 2011-04-23 17:29:51 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-23 17:29:51 --> Database Driver Class Initialized
DEBUG - 2011-04-23 17:29:51 --> Final output sent to browser
DEBUG - 2011-04-23 17:29:51 --> Total execution time: 0.5334
DEBUG - 2011-04-23 17:30:10 --> Config Class Initialized
DEBUG - 2011-04-23 17:30:10 --> Hooks Class Initialized
DEBUG - 2011-04-23 17:30:10 --> Utf8 Class Initialized
DEBUG - 2011-04-23 17:30:10 --> UTF-8 Support Enabled
DEBUG - 2011-04-23 17:30:10 --> URI Class Initialized
DEBUG - 2011-04-23 17:30:10 --> Router Class Initialized
DEBUG - 2011-04-23 17:30:10 --> Output Class Initialized
DEBUG - 2011-04-23 17:30:10 --> Input Class Initialized
DEBUG - 2011-04-23 17:30:10 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-23 17:30:10 --> Language Class Initialized
DEBUG - 2011-04-23 17:30:10 --> Loader Class Initialized
DEBUG - 2011-04-23 17:30:10 --> Controller Class Initialized
ERROR - 2011-04-23 17:30:10 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-04-23 17:30:10 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-04-23 17:30:10 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-04-23 17:30:10 --> Model Class Initialized
DEBUG - 2011-04-23 17:30:10 --> Model Class Initialized
DEBUG - 2011-04-23 17:30:10 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-23 17:30:10 --> Database Driver Class Initialized
DEBUG - 2011-04-23 17:30:10 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-04-23 17:30:10 --> Helper loaded: url_helper
DEBUG - 2011-04-23 17:30:10 --> File loaded: application/views/common/header.php
DEBUG - 2011-04-23 17:30:10 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-04-23 17:30:10 --> File loaded: application/views/common/footer.php
DEBUG - 2011-04-23 17:30:10 --> File loaded: application/views/layout/main.php
DEBUG - 2011-04-23 17:30:10 --> Final output sent to browser
DEBUG - 2011-04-23 17:30:10 --> Total execution time: 0.0272
DEBUG - 2011-04-23 17:30:11 --> Config Class Initialized
DEBUG - 2011-04-23 17:30:11 --> Hooks Class Initialized
DEBUG - 2011-04-23 17:30:11 --> Utf8 Class Initialized
DEBUG - 2011-04-23 17:30:11 --> UTF-8 Support Enabled
DEBUG - 2011-04-23 17:30:11 --> URI Class Initialized
DEBUG - 2011-04-23 17:30:11 --> Router Class Initialized
DEBUG - 2011-04-23 17:30:11 --> Output Class Initialized
DEBUG - 2011-04-23 17:30:11 --> Input Class Initialized
DEBUG - 2011-04-23 17:30:11 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-23 17:30:11 --> Language Class Initialized
DEBUG - 2011-04-23 17:30:11 --> Loader Class Initialized
DEBUG - 2011-04-23 17:30:11 --> Controller Class Initialized
DEBUG - 2011-04-23 17:30:11 --> Model Class Initialized
DEBUG - 2011-04-23 17:30:11 --> Model Class Initialized
DEBUG - 2011-04-23 17:30:11 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-23 17:30:11 --> Database Driver Class Initialized
DEBUG - 2011-04-23 17:30:12 --> Final output sent to browser
DEBUG - 2011-04-23 17:30:12 --> Total execution time: 0.9570
DEBUG - 2011-04-23 17:30:18 --> Config Class Initialized
DEBUG - 2011-04-23 17:30:18 --> Hooks Class Initialized
DEBUG - 2011-04-23 17:30:18 --> Utf8 Class Initialized
DEBUG - 2011-04-23 17:30:18 --> UTF-8 Support Enabled
DEBUG - 2011-04-23 17:30:18 --> URI Class Initialized
DEBUG - 2011-04-23 17:30:18 --> Router Class Initialized
DEBUG - 2011-04-23 17:30:18 --> Output Class Initialized
DEBUG - 2011-04-23 17:30:18 --> Input Class Initialized
DEBUG - 2011-04-23 17:30:18 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-23 17:30:18 --> Language Class Initialized
DEBUG - 2011-04-23 17:30:18 --> Loader Class Initialized
DEBUG - 2011-04-23 17:30:18 --> Controller Class Initialized
ERROR - 2011-04-23 17:30:18 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-04-23 17:30:18 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-04-23 17:30:18 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-04-23 17:30:18 --> Model Class Initialized
DEBUG - 2011-04-23 17:30:18 --> Model Class Initialized
DEBUG - 2011-04-23 17:30:18 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-23 17:30:18 --> Database Driver Class Initialized
DEBUG - 2011-04-23 17:30:18 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-04-23 17:30:18 --> Helper loaded: url_helper
DEBUG - 2011-04-23 17:30:18 --> File loaded: application/views/common/header.php
DEBUG - 2011-04-23 17:30:18 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-04-23 17:30:18 --> File loaded: application/views/common/footer.php
DEBUG - 2011-04-23 17:30:18 --> File loaded: application/views/layout/main.php
DEBUG - 2011-04-23 17:30:18 --> Final output sent to browser
DEBUG - 2011-04-23 17:30:18 --> Total execution time: 0.0297
DEBUG - 2011-04-23 17:30:19 --> Config Class Initialized
DEBUG - 2011-04-23 17:30:19 --> Hooks Class Initialized
DEBUG - 2011-04-23 17:30:19 --> Utf8 Class Initialized
DEBUG - 2011-04-23 17:30:19 --> UTF-8 Support Enabled
DEBUG - 2011-04-23 17:30:19 --> URI Class Initialized
DEBUG - 2011-04-23 17:30:19 --> Router Class Initialized
DEBUG - 2011-04-23 17:30:19 --> Output Class Initialized
DEBUG - 2011-04-23 17:30:19 --> Input Class Initialized
DEBUG - 2011-04-23 17:30:19 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-23 17:30:19 --> Language Class Initialized
DEBUG - 2011-04-23 17:30:19 --> Loader Class Initialized
DEBUG - 2011-04-23 17:30:19 --> Controller Class Initialized
DEBUG - 2011-04-23 17:30:19 --> Model Class Initialized
DEBUG - 2011-04-23 17:30:19 --> Model Class Initialized
DEBUG - 2011-04-23 17:30:19 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-23 17:30:19 --> Database Driver Class Initialized
DEBUG - 2011-04-23 17:30:19 --> Final output sent to browser
DEBUG - 2011-04-23 17:30:19 --> Total execution time: 0.5010
DEBUG - 2011-04-23 17:30:34 --> Config Class Initialized
DEBUG - 2011-04-23 17:30:34 --> Hooks Class Initialized
DEBUG - 2011-04-23 17:30:34 --> Utf8 Class Initialized
DEBUG - 2011-04-23 17:30:34 --> UTF-8 Support Enabled
DEBUG - 2011-04-23 17:30:34 --> URI Class Initialized
DEBUG - 2011-04-23 17:30:34 --> Router Class Initialized
DEBUG - 2011-04-23 17:30:34 --> Output Class Initialized
DEBUG - 2011-04-23 17:30:34 --> Input Class Initialized
DEBUG - 2011-04-23 17:30:34 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-23 17:30:34 --> Language Class Initialized
DEBUG - 2011-04-23 17:30:34 --> Loader Class Initialized
DEBUG - 2011-04-23 17:30:34 --> Controller Class Initialized
ERROR - 2011-04-23 17:30:34 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-04-23 17:30:34 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-04-23 17:30:34 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-04-23 17:30:34 --> Model Class Initialized
DEBUG - 2011-04-23 17:30:34 --> Model Class Initialized
DEBUG - 2011-04-23 17:30:34 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-23 17:30:34 --> Database Driver Class Initialized
DEBUG - 2011-04-23 17:30:34 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-04-23 17:30:34 --> Helper loaded: url_helper
DEBUG - 2011-04-23 17:30:34 --> File loaded: application/views/common/header.php
DEBUG - 2011-04-23 17:30:34 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-04-23 17:30:34 --> File loaded: application/views/common/footer.php
DEBUG - 2011-04-23 17:30:34 --> File loaded: application/views/layout/main.php
DEBUG - 2011-04-23 17:30:34 --> Final output sent to browser
DEBUG - 2011-04-23 17:30:34 --> Total execution time: 0.0288
DEBUG - 2011-04-23 17:30:34 --> Config Class Initialized
DEBUG - 2011-04-23 17:30:34 --> Hooks Class Initialized
DEBUG - 2011-04-23 17:30:34 --> Utf8 Class Initialized
DEBUG - 2011-04-23 17:30:34 --> UTF-8 Support Enabled
DEBUG - 2011-04-23 17:30:34 --> URI Class Initialized
DEBUG - 2011-04-23 17:30:34 --> Router Class Initialized
DEBUG - 2011-04-23 17:30:34 --> Output Class Initialized
DEBUG - 2011-04-23 17:30:34 --> Input Class Initialized
DEBUG - 2011-04-23 17:30:34 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-23 17:30:34 --> Language Class Initialized
DEBUG - 2011-04-23 17:30:34 --> Loader Class Initialized
DEBUG - 2011-04-23 17:30:34 --> Controller Class Initialized
DEBUG - 2011-04-23 17:30:34 --> Model Class Initialized
DEBUG - 2011-04-23 17:30:34 --> Model Class Initialized
DEBUG - 2011-04-23 17:30:34 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-23 17:30:34 --> Database Driver Class Initialized
DEBUG - 2011-04-23 17:30:35 --> Final output sent to browser
DEBUG - 2011-04-23 17:30:35 --> Total execution time: 0.5427
DEBUG - 2011-04-23 19:13:56 --> Config Class Initialized
DEBUG - 2011-04-23 19:13:56 --> Hooks Class Initialized
DEBUG - 2011-04-23 19:13:56 --> Utf8 Class Initialized
DEBUG - 2011-04-23 19:13:56 --> UTF-8 Support Enabled
DEBUG - 2011-04-23 19:13:56 --> URI Class Initialized
DEBUG - 2011-04-23 19:13:56 --> Router Class Initialized
DEBUG - 2011-04-23 19:13:56 --> Output Class Initialized
DEBUG - 2011-04-23 19:13:56 --> Input Class Initialized
DEBUG - 2011-04-23 19:13:56 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-23 19:13:56 --> Language Class Initialized
DEBUG - 2011-04-23 19:13:56 --> Loader Class Initialized
DEBUG - 2011-04-23 19:13:56 --> Controller Class Initialized
ERROR - 2011-04-23 19:13:56 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-04-23 19:13:56 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-04-23 19:13:56 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-04-23 19:13:56 --> Model Class Initialized
DEBUG - 2011-04-23 19:13:56 --> Model Class Initialized
DEBUG - 2011-04-23 19:13:56 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-23 19:13:57 --> Database Driver Class Initialized
DEBUG - 2011-04-23 19:13:57 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-04-23 19:13:57 --> Helper loaded: url_helper
DEBUG - 2011-04-23 19:13:57 --> File loaded: application/views/common/header.php
DEBUG - 2011-04-23 19:13:57 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-04-23 19:13:57 --> File loaded: application/views/common/footer.php
DEBUG - 2011-04-23 19:13:57 --> File loaded: application/views/layout/main.php
DEBUG - 2011-04-23 19:13:57 --> Final output sent to browser
DEBUG - 2011-04-23 19:13:57 --> Total execution time: 0.8104
DEBUG - 2011-04-23 19:13:58 --> Config Class Initialized
DEBUG - 2011-04-23 19:13:58 --> Hooks Class Initialized
DEBUG - 2011-04-23 19:13:58 --> Utf8 Class Initialized
DEBUG - 2011-04-23 19:13:58 --> UTF-8 Support Enabled
DEBUG - 2011-04-23 19:13:58 --> URI Class Initialized
DEBUG - 2011-04-23 19:13:58 --> Router Class Initialized
DEBUG - 2011-04-23 19:13:58 --> Output Class Initialized
DEBUG - 2011-04-23 19:13:58 --> Input Class Initialized
DEBUG - 2011-04-23 19:13:58 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-23 19:13:58 --> Language Class Initialized
DEBUG - 2011-04-23 19:13:58 --> Loader Class Initialized
DEBUG - 2011-04-23 19:13:58 --> Controller Class Initialized
DEBUG - 2011-04-23 19:13:58 --> Model Class Initialized
DEBUG - 2011-04-23 19:13:58 --> Model Class Initialized
DEBUG - 2011-04-23 19:13:58 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-23 19:13:58 --> Database Driver Class Initialized
DEBUG - 2011-04-23 19:13:59 --> Final output sent to browser
DEBUG - 2011-04-23 19:13:59 --> Total execution time: 1.0625
DEBUG - 2011-04-23 19:13:59 --> Config Class Initialized
DEBUG - 2011-04-23 19:13:59 --> Hooks Class Initialized
DEBUG - 2011-04-23 19:13:59 --> Utf8 Class Initialized
DEBUG - 2011-04-23 19:13:59 --> UTF-8 Support Enabled
DEBUG - 2011-04-23 19:13:59 --> URI Class Initialized
DEBUG - 2011-04-23 19:13:59 --> Router Class Initialized
ERROR - 2011-04-23 19:13:59 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-04-23 19:55:00 --> Config Class Initialized
DEBUG - 2011-04-23 19:55:00 --> Hooks Class Initialized
DEBUG - 2011-04-23 19:55:00 --> Utf8 Class Initialized
DEBUG - 2011-04-23 19:55:00 --> UTF-8 Support Enabled
DEBUG - 2011-04-23 19:55:00 --> URI Class Initialized
DEBUG - 2011-04-23 19:55:00 --> Router Class Initialized
DEBUG - 2011-04-23 19:55:00 --> Output Class Initialized
DEBUG - 2011-04-23 19:55:00 --> Input Class Initialized
DEBUG - 2011-04-23 19:55:00 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-23 19:55:00 --> Language Class Initialized
DEBUG - 2011-04-23 19:55:00 --> Loader Class Initialized
DEBUG - 2011-04-23 19:55:00 --> Controller Class Initialized
ERROR - 2011-04-23 19:55:01 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-04-23 19:55:01 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-04-23 19:55:01 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-04-23 19:55:01 --> Model Class Initialized
DEBUG - 2011-04-23 19:55:01 --> Model Class Initialized
DEBUG - 2011-04-23 19:55:01 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-23 19:55:01 --> Database Driver Class Initialized
DEBUG - 2011-04-23 19:55:01 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-04-23 19:55:01 --> Helper loaded: url_helper
DEBUG - 2011-04-23 19:55:01 --> File loaded: application/views/common/header.php
DEBUG - 2011-04-23 19:55:01 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-04-23 19:55:01 --> File loaded: application/views/common/footer.php
DEBUG - 2011-04-23 19:55:01 --> File loaded: application/views/layout/main.php
DEBUG - 2011-04-23 19:55:01 --> Final output sent to browser
DEBUG - 2011-04-23 19:55:01 --> Total execution time: 0.4320
DEBUG - 2011-04-23 19:55:02 --> Config Class Initialized
DEBUG - 2011-04-23 19:55:02 --> Hooks Class Initialized
DEBUG - 2011-04-23 19:55:02 --> Utf8 Class Initialized
DEBUG - 2011-04-23 19:55:02 --> UTF-8 Support Enabled
DEBUG - 2011-04-23 19:55:02 --> URI Class Initialized
DEBUG - 2011-04-23 19:55:02 --> Router Class Initialized
DEBUG - 2011-04-23 19:55:02 --> Output Class Initialized
DEBUG - 2011-04-23 19:55:02 --> Input Class Initialized
DEBUG - 2011-04-23 19:55:02 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-23 19:55:02 --> Language Class Initialized
DEBUG - 2011-04-23 19:55:02 --> Loader Class Initialized
DEBUG - 2011-04-23 19:55:02 --> Controller Class Initialized
DEBUG - 2011-04-23 19:55:02 --> Model Class Initialized
DEBUG - 2011-04-23 19:55:02 --> Model Class Initialized
DEBUG - 2011-04-23 19:55:02 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-23 19:55:02 --> Database Driver Class Initialized
DEBUG - 2011-04-23 19:55:03 --> Final output sent to browser
DEBUG - 2011-04-23 19:55:03 --> Total execution time: 0.8387
DEBUG - 2011-04-23 19:55:04 --> Config Class Initialized
DEBUG - 2011-04-23 19:55:04 --> Hooks Class Initialized
DEBUG - 2011-04-23 19:55:04 --> Utf8 Class Initialized
DEBUG - 2011-04-23 19:55:04 --> UTF-8 Support Enabled
DEBUG - 2011-04-23 19:55:04 --> URI Class Initialized
DEBUG - 2011-04-23 19:55:04 --> Router Class Initialized
ERROR - 2011-04-23 19:55:04 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-04-23 19:55:46 --> Config Class Initialized
DEBUG - 2011-04-23 19:55:46 --> Hooks Class Initialized
DEBUG - 2011-04-23 19:55:46 --> Utf8 Class Initialized
DEBUG - 2011-04-23 19:55:46 --> UTF-8 Support Enabled
DEBUG - 2011-04-23 19:55:46 --> URI Class Initialized
DEBUG - 2011-04-23 19:55:46 --> Router Class Initialized
DEBUG - 2011-04-23 19:55:46 --> Output Class Initialized
DEBUG - 2011-04-23 19:55:46 --> Input Class Initialized
DEBUG - 2011-04-23 19:55:46 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-23 19:55:46 --> Language Class Initialized
DEBUG - 2011-04-23 19:55:46 --> Loader Class Initialized
DEBUG - 2011-04-23 19:55:46 --> Controller Class Initialized
ERROR - 2011-04-23 19:55:46 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-04-23 19:55:46 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-04-23 19:55:46 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-04-23 19:55:46 --> Model Class Initialized
DEBUG - 2011-04-23 19:55:46 --> Model Class Initialized
DEBUG - 2011-04-23 19:55:46 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-23 19:55:46 --> Database Driver Class Initialized
DEBUG - 2011-04-23 19:55:46 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-04-23 19:55:46 --> Helper loaded: url_helper
DEBUG - 2011-04-23 19:55:46 --> File loaded: application/views/common/header.php
DEBUG - 2011-04-23 19:55:46 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-04-23 19:55:46 --> File loaded: application/views/common/footer.php
DEBUG - 2011-04-23 19:55:46 --> File loaded: application/views/layout/main.php
DEBUG - 2011-04-23 19:55:46 --> Final output sent to browser
DEBUG - 2011-04-23 19:55:46 --> Total execution time: 0.0292
DEBUG - 2011-04-23 19:55:47 --> Config Class Initialized
DEBUG - 2011-04-23 19:55:47 --> Hooks Class Initialized
DEBUG - 2011-04-23 19:55:47 --> Utf8 Class Initialized
DEBUG - 2011-04-23 19:55:47 --> UTF-8 Support Enabled
DEBUG - 2011-04-23 19:55:47 --> URI Class Initialized
DEBUG - 2011-04-23 19:55:47 --> Router Class Initialized
DEBUG - 2011-04-23 19:55:47 --> Output Class Initialized
DEBUG - 2011-04-23 19:55:47 --> Input Class Initialized
DEBUG - 2011-04-23 19:55:47 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-23 19:55:47 --> Language Class Initialized
DEBUG - 2011-04-23 19:55:47 --> Loader Class Initialized
DEBUG - 2011-04-23 19:55:47 --> Controller Class Initialized
DEBUG - 2011-04-23 19:55:47 --> Model Class Initialized
DEBUG - 2011-04-23 19:55:47 --> Model Class Initialized
DEBUG - 2011-04-23 19:55:47 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-23 19:55:47 --> Database Driver Class Initialized
DEBUG - 2011-04-23 19:55:47 --> Final output sent to browser
DEBUG - 2011-04-23 19:55:47 --> Total execution time: 0.5659
DEBUG - 2011-04-23 19:55:49 --> Config Class Initialized
DEBUG - 2011-04-23 19:55:49 --> Hooks Class Initialized
DEBUG - 2011-04-23 19:55:49 --> Utf8 Class Initialized
DEBUG - 2011-04-23 19:55:49 --> UTF-8 Support Enabled
DEBUG - 2011-04-23 19:55:49 --> URI Class Initialized
DEBUG - 2011-04-23 19:55:49 --> Router Class Initialized
ERROR - 2011-04-23 19:55:49 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-04-23 19:56:11 --> Config Class Initialized
DEBUG - 2011-04-23 19:56:11 --> Hooks Class Initialized
DEBUG - 2011-04-23 19:56:11 --> Utf8 Class Initialized
DEBUG - 2011-04-23 19:56:11 --> UTF-8 Support Enabled
DEBUG - 2011-04-23 19:56:11 --> URI Class Initialized
DEBUG - 2011-04-23 19:56:11 --> Router Class Initialized
DEBUG - 2011-04-23 19:56:11 --> Output Class Initialized
DEBUG - 2011-04-23 19:56:11 --> Input Class Initialized
DEBUG - 2011-04-23 19:56:11 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-23 19:56:11 --> Language Class Initialized
DEBUG - 2011-04-23 19:56:11 --> Loader Class Initialized
DEBUG - 2011-04-23 19:56:11 --> Controller Class Initialized
ERROR - 2011-04-23 19:56:11 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-04-23 19:56:11 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-04-23 19:56:11 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-04-23 19:56:11 --> Model Class Initialized
DEBUG - 2011-04-23 19:56:11 --> Model Class Initialized
DEBUG - 2011-04-23 19:56:11 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-23 19:56:11 --> Database Driver Class Initialized
DEBUG - 2011-04-23 19:56:11 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-04-23 19:56:11 --> Helper loaded: url_helper
DEBUG - 2011-04-23 19:56:11 --> File loaded: application/views/common/header.php
DEBUG - 2011-04-23 19:56:11 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-04-23 19:56:11 --> File loaded: application/views/common/footer.php
DEBUG - 2011-04-23 19:56:11 --> File loaded: application/views/layout/main.php
DEBUG - 2011-04-23 19:56:11 --> Final output sent to browser
DEBUG - 2011-04-23 19:56:11 --> Total execution time: 0.0363
DEBUG - 2011-04-23 19:56:12 --> Config Class Initialized
DEBUG - 2011-04-23 19:56:12 --> Hooks Class Initialized
DEBUG - 2011-04-23 19:56:12 --> Utf8 Class Initialized
DEBUG - 2011-04-23 19:56:12 --> UTF-8 Support Enabled
DEBUG - 2011-04-23 19:56:12 --> URI Class Initialized
DEBUG - 2011-04-23 19:56:12 --> Router Class Initialized
DEBUG - 2011-04-23 19:56:12 --> Output Class Initialized
DEBUG - 2011-04-23 19:56:12 --> Input Class Initialized
DEBUG - 2011-04-23 19:56:12 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-23 19:56:12 --> Language Class Initialized
DEBUG - 2011-04-23 19:56:12 --> Loader Class Initialized
DEBUG - 2011-04-23 19:56:12 --> Controller Class Initialized
DEBUG - 2011-04-23 19:56:12 --> Model Class Initialized
DEBUG - 2011-04-23 19:56:12 --> Model Class Initialized
DEBUG - 2011-04-23 19:56:12 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-23 19:56:12 --> Database Driver Class Initialized
DEBUG - 2011-04-23 19:56:13 --> Final output sent to browser
DEBUG - 2011-04-23 19:56:13 --> Total execution time: 0.8156
DEBUG - 2011-04-23 19:56:13 --> Config Class Initialized
DEBUG - 2011-04-23 19:56:13 --> Hooks Class Initialized
DEBUG - 2011-04-23 19:56:13 --> Utf8 Class Initialized
DEBUG - 2011-04-23 19:56:13 --> UTF-8 Support Enabled
DEBUG - 2011-04-23 19:56:13 --> URI Class Initialized
DEBUG - 2011-04-23 19:56:13 --> Router Class Initialized
DEBUG - 2011-04-23 19:56:13 --> Output Class Initialized
DEBUG - 2011-04-23 19:56:13 --> Input Class Initialized
DEBUG - 2011-04-23 19:56:13 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-23 19:56:13 --> Language Class Initialized
DEBUG - 2011-04-23 19:56:13 --> Loader Class Initialized
DEBUG - 2011-04-23 19:56:13 --> Controller Class Initialized
ERROR - 2011-04-23 19:56:13 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-04-23 19:56:13 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-04-23 19:56:13 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-04-23 19:56:13 --> Model Class Initialized
DEBUG - 2011-04-23 19:56:13 --> Model Class Initialized
DEBUG - 2011-04-23 19:56:13 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-23 19:56:13 --> Database Driver Class Initialized
DEBUG - 2011-04-23 19:56:13 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-04-23 19:56:13 --> Helper loaded: url_helper
DEBUG - 2011-04-23 19:56:13 --> File loaded: application/views/common/header.php
DEBUG - 2011-04-23 19:56:13 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-04-23 19:56:13 --> File loaded: application/views/common/footer.php
DEBUG - 2011-04-23 19:56:13 --> File loaded: application/views/layout/main.php
DEBUG - 2011-04-23 19:56:13 --> Final output sent to browser
DEBUG - 2011-04-23 19:56:13 --> Total execution time: 0.0298
DEBUG - 2011-04-23 19:56:14 --> Config Class Initialized
DEBUG - 2011-04-23 19:56:14 --> Hooks Class Initialized
DEBUG - 2011-04-23 19:56:14 --> Utf8 Class Initialized
DEBUG - 2011-04-23 19:56:14 --> UTF-8 Support Enabled
DEBUG - 2011-04-23 19:56:14 --> URI Class Initialized
DEBUG - 2011-04-23 19:56:14 --> Router Class Initialized
ERROR - 2011-04-23 19:56:14 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-04-23 19:56:19 --> Config Class Initialized
DEBUG - 2011-04-23 19:56:19 --> Hooks Class Initialized
DEBUG - 2011-04-23 19:56:19 --> Utf8 Class Initialized
DEBUG - 2011-04-23 19:56:19 --> UTF-8 Support Enabled
DEBUG - 2011-04-23 19:56:19 --> URI Class Initialized
DEBUG - 2011-04-23 19:56:19 --> Router Class Initialized
DEBUG - 2011-04-23 19:56:19 --> Output Class Initialized
DEBUG - 2011-04-23 19:56:19 --> Input Class Initialized
DEBUG - 2011-04-23 19:56:19 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-23 19:56:19 --> Language Class Initialized
DEBUG - 2011-04-23 19:56:19 --> Loader Class Initialized
DEBUG - 2011-04-23 19:56:19 --> Controller Class Initialized
ERROR - 2011-04-23 19:56:19 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-04-23 19:56:19 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-04-23 19:56:19 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-04-23 19:56:19 --> Model Class Initialized
DEBUG - 2011-04-23 19:56:19 --> Model Class Initialized
DEBUG - 2011-04-23 19:56:19 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-23 19:56:19 --> Database Driver Class Initialized
DEBUG - 2011-04-23 19:56:19 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-04-23 19:56:19 --> Helper loaded: url_helper
DEBUG - 2011-04-23 19:56:19 --> File loaded: application/views/common/header.php
DEBUG - 2011-04-23 19:56:19 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-04-23 19:56:19 --> File loaded: application/views/common/footer.php
DEBUG - 2011-04-23 19:56:19 --> File loaded: application/views/layout/main.php
DEBUG - 2011-04-23 19:56:19 --> Final output sent to browser
DEBUG - 2011-04-23 19:56:19 --> Total execution time: 0.0288
DEBUG - 2011-04-23 19:56:20 --> Config Class Initialized
DEBUG - 2011-04-23 19:56:20 --> Hooks Class Initialized
DEBUG - 2011-04-23 19:56:20 --> Utf8 Class Initialized
DEBUG - 2011-04-23 19:56:20 --> UTF-8 Support Enabled
DEBUG - 2011-04-23 19:56:20 --> URI Class Initialized
DEBUG - 2011-04-23 19:56:20 --> Router Class Initialized
DEBUG - 2011-04-23 19:56:20 --> Output Class Initialized
DEBUG - 2011-04-23 19:56:20 --> Input Class Initialized
DEBUG - 2011-04-23 19:56:20 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-23 19:56:20 --> Language Class Initialized
DEBUG - 2011-04-23 19:56:20 --> Loader Class Initialized
DEBUG - 2011-04-23 19:56:20 --> Controller Class Initialized
DEBUG - 2011-04-23 19:56:20 --> Model Class Initialized
DEBUG - 2011-04-23 19:56:20 --> Model Class Initialized
DEBUG - 2011-04-23 19:56:20 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-23 19:56:20 --> Database Driver Class Initialized
DEBUG - 2011-04-23 19:56:21 --> Config Class Initialized
DEBUG - 2011-04-23 19:56:21 --> Hooks Class Initialized
DEBUG - 2011-04-23 19:56:21 --> Utf8 Class Initialized
DEBUG - 2011-04-23 19:56:21 --> UTF-8 Support Enabled
DEBUG - 2011-04-23 19:56:21 --> URI Class Initialized
DEBUG - 2011-04-23 19:56:21 --> Router Class Initialized
DEBUG - 2011-04-23 19:56:21 --> Output Class Initialized
DEBUG - 2011-04-23 19:56:21 --> Input Class Initialized
DEBUG - 2011-04-23 19:56:21 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-23 19:56:21 --> Language Class Initialized
DEBUG - 2011-04-23 19:56:21 --> Loader Class Initialized
DEBUG - 2011-04-23 19:56:21 --> Controller Class Initialized
ERROR - 2011-04-23 19:56:21 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-04-23 19:56:21 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-04-23 19:56:21 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-04-23 19:56:21 --> Model Class Initialized
DEBUG - 2011-04-23 19:56:21 --> Model Class Initialized
DEBUG - 2011-04-23 19:56:21 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-23 19:56:21 --> Database Driver Class Initialized
DEBUG - 2011-04-23 19:56:21 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-04-23 19:56:21 --> Helper loaded: url_helper
DEBUG - 2011-04-23 19:56:21 --> File loaded: application/views/common/header.php
DEBUG - 2011-04-23 19:56:21 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-04-23 19:56:21 --> File loaded: application/views/common/footer.php
DEBUG - 2011-04-23 19:56:21 --> File loaded: application/views/layout/main.php
DEBUG - 2011-04-23 19:56:21 --> Final output sent to browser
DEBUG - 2011-04-23 19:56:21 --> Total execution time: 0.0301
DEBUG - 2011-04-23 19:56:21 --> Final output sent to browser
DEBUG - 2011-04-23 19:56:21 --> Total execution time: 0.5099
DEBUG - 2011-04-23 19:56:22 --> Config Class Initialized
DEBUG - 2011-04-23 19:56:22 --> Hooks Class Initialized
DEBUG - 2011-04-23 19:56:22 --> Utf8 Class Initialized
DEBUG - 2011-04-23 19:56:22 --> UTF-8 Support Enabled
DEBUG - 2011-04-23 19:56:22 --> URI Class Initialized
DEBUG - 2011-04-23 19:56:22 --> Router Class Initialized
ERROR - 2011-04-23 19:56:22 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-04-23 19:56:36 --> Config Class Initialized
DEBUG - 2011-04-23 19:56:36 --> Hooks Class Initialized
DEBUG - 2011-04-23 19:56:36 --> Utf8 Class Initialized
DEBUG - 2011-04-23 19:56:36 --> UTF-8 Support Enabled
DEBUG - 2011-04-23 19:56:36 --> URI Class Initialized
DEBUG - 2011-04-23 19:56:36 --> Router Class Initialized
ERROR - 2011-04-23 19:56:36 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-04-23 19:56:36 --> Config Class Initialized
DEBUG - 2011-04-23 19:56:36 --> Hooks Class Initialized
DEBUG - 2011-04-23 19:56:36 --> Utf8 Class Initialized
DEBUG - 2011-04-23 19:56:36 --> UTF-8 Support Enabled
DEBUG - 2011-04-23 19:56:36 --> URI Class Initialized
DEBUG - 2011-04-23 19:56:36 --> Router Class Initialized
ERROR - 2011-04-23 19:56:36 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-04-23 19:56:37 --> Config Class Initialized
DEBUG - 2011-04-23 19:56:37 --> Hooks Class Initialized
DEBUG - 2011-04-23 19:56:37 --> Utf8 Class Initialized
DEBUG - 2011-04-23 19:56:37 --> UTF-8 Support Enabled
DEBUG - 2011-04-23 19:56:37 --> URI Class Initialized
DEBUG - 2011-04-23 19:56:37 --> Router Class Initialized
ERROR - 2011-04-23 19:56:37 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-04-23 19:56:43 --> Config Class Initialized
DEBUG - 2011-04-23 19:56:43 --> Hooks Class Initialized
DEBUG - 2011-04-23 19:56:43 --> Utf8 Class Initialized
DEBUG - 2011-04-23 19:56:43 --> UTF-8 Support Enabled
DEBUG - 2011-04-23 19:56:43 --> URI Class Initialized
DEBUG - 2011-04-23 19:56:43 --> Router Class Initialized
DEBUG - 2011-04-23 19:56:43 --> Output Class Initialized
DEBUG - 2011-04-23 19:56:43 --> Input Class Initialized
DEBUG - 2011-04-23 19:56:43 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-23 19:56:43 --> Language Class Initialized
DEBUG - 2011-04-23 19:56:43 --> Loader Class Initialized
DEBUG - 2011-04-23 19:56:43 --> Controller Class Initialized
DEBUG - 2011-04-23 19:56:43 --> Model Class Initialized
DEBUG - 2011-04-23 19:56:43 --> Model Class Initialized
DEBUG - 2011-04-23 19:56:43 --> Model Class Initialized
DEBUG - 2011-04-23 19:56:43 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-23 19:56:43 --> Database Driver Class Initialized
DEBUG - 2011-04-23 19:56:43 --> File loaded: application/views/table/main.php
DEBUG - 2011-04-23 19:56:43 --> Helper loaded: url_helper
DEBUG - 2011-04-23 19:56:43 --> File loaded: application/views/common/header.php
DEBUG - 2011-04-23 19:56:43 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-04-23 19:56:43 --> File loaded: application/views/common/footer.php
DEBUG - 2011-04-23 19:56:43 --> File loaded: application/views/layout/main.php
DEBUG - 2011-04-23 19:56:43 --> Final output sent to browser
DEBUG - 2011-04-23 19:56:43 --> Total execution time: 0.3853
DEBUG - 2011-04-23 19:56:45 --> Config Class Initialized
DEBUG - 2011-04-23 19:56:45 --> Hooks Class Initialized
DEBUG - 2011-04-23 19:56:45 --> Utf8 Class Initialized
DEBUG - 2011-04-23 19:56:45 --> UTF-8 Support Enabled
DEBUG - 2011-04-23 19:56:45 --> URI Class Initialized
DEBUG - 2011-04-23 19:56:45 --> Router Class Initialized
ERROR - 2011-04-23 19:56:45 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-04-23 19:56:51 --> Config Class Initialized
DEBUG - 2011-04-23 19:56:51 --> Hooks Class Initialized
DEBUG - 2011-04-23 19:56:51 --> Utf8 Class Initialized
DEBUG - 2011-04-23 19:56:51 --> UTF-8 Support Enabled
DEBUG - 2011-04-23 19:56:51 --> URI Class Initialized
DEBUG - 2011-04-23 19:56:51 --> Router Class Initialized
DEBUG - 2011-04-23 19:56:51 --> Output Class Initialized
DEBUG - 2011-04-23 19:56:51 --> Input Class Initialized
DEBUG - 2011-04-23 19:56:51 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-23 19:56:51 --> Language Class Initialized
DEBUG - 2011-04-23 19:56:51 --> Loader Class Initialized
DEBUG - 2011-04-23 19:56:51 --> Controller Class Initialized
DEBUG - 2011-04-23 19:56:51 --> Model Class Initialized
DEBUG - 2011-04-23 19:56:51 --> Model Class Initialized
DEBUG - 2011-04-23 19:56:51 --> Model Class Initialized
DEBUG - 2011-04-23 19:56:51 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-23 19:56:51 --> Database Driver Class Initialized
DEBUG - 2011-04-23 19:56:52 --> File loaded: application/views/table/main.php
DEBUG - 2011-04-23 19:56:52 --> Helper loaded: url_helper
DEBUG - 2011-04-23 19:56:52 --> File loaded: application/views/common/header.php
DEBUG - 2011-04-23 19:56:52 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-04-23 19:56:52 --> File loaded: application/views/common/footer.php
DEBUG - 2011-04-23 19:56:52 --> File loaded: application/views/layout/main.php
DEBUG - 2011-04-23 19:56:52 --> Final output sent to browser
DEBUG - 2011-04-23 19:56:52 --> Total execution time: 1.4684
DEBUG - 2011-04-23 19:56:53 --> Config Class Initialized
DEBUG - 2011-04-23 19:56:53 --> Hooks Class Initialized
DEBUG - 2011-04-23 19:56:53 --> Utf8 Class Initialized
DEBUG - 2011-04-23 19:56:53 --> UTF-8 Support Enabled
DEBUG - 2011-04-23 19:56:53 --> URI Class Initialized
DEBUG - 2011-04-23 19:56:53 --> Router Class Initialized
DEBUG - 2011-04-23 19:56:53 --> Output Class Initialized
DEBUG - 2011-04-23 19:56:53 --> Input Class Initialized
DEBUG - 2011-04-23 19:56:53 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-23 19:56:53 --> Language Class Initialized
DEBUG - 2011-04-23 19:56:53 --> Loader Class Initialized
DEBUG - 2011-04-23 19:56:53 --> Controller Class Initialized
DEBUG - 2011-04-23 19:56:53 --> Model Class Initialized
DEBUG - 2011-04-23 19:56:53 --> Model Class Initialized
DEBUG - 2011-04-23 19:56:53 --> Model Class Initialized
DEBUG - 2011-04-23 19:56:53 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-23 19:56:53 --> Database Driver Class Initialized
DEBUG - 2011-04-23 19:56:53 --> File loaded: application/views/table/main.php
DEBUG - 2011-04-23 19:56:53 --> Helper loaded: url_helper
DEBUG - 2011-04-23 19:56:53 --> File loaded: application/views/common/header.php
DEBUG - 2011-04-23 19:56:53 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-04-23 19:56:53 --> File loaded: application/views/common/footer.php
DEBUG - 2011-04-23 19:56:53 --> File loaded: application/views/layout/main.php
DEBUG - 2011-04-23 19:56:53 --> Final output sent to browser
DEBUG - 2011-04-23 19:56:53 --> Total execution time: 0.0521
DEBUG - 2011-04-23 19:56:54 --> Config Class Initialized
DEBUG - 2011-04-23 19:56:54 --> Hooks Class Initialized
DEBUG - 2011-04-23 19:56:54 --> Utf8 Class Initialized
DEBUG - 2011-04-23 19:56:54 --> UTF-8 Support Enabled
DEBUG - 2011-04-23 19:56:54 --> URI Class Initialized
DEBUG - 2011-04-23 19:56:54 --> Router Class Initialized
DEBUG - 2011-04-23 19:56:54 --> Output Class Initialized
DEBUG - 2011-04-23 19:56:54 --> Input Class Initialized
DEBUG - 2011-04-23 19:56:54 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-23 19:56:54 --> Language Class Initialized
DEBUG - 2011-04-23 19:56:54 --> Loader Class Initialized
DEBUG - 2011-04-23 19:56:54 --> Controller Class Initialized
DEBUG - 2011-04-23 19:56:54 --> Model Class Initialized
DEBUG - 2011-04-23 19:56:54 --> Model Class Initialized
DEBUG - 2011-04-23 19:56:54 --> Model Class Initialized
DEBUG - 2011-04-23 19:56:54 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-23 19:56:54 --> Database Driver Class Initialized
DEBUG - 2011-04-23 19:56:54 --> File loaded: application/views/table/main.php
DEBUG - 2011-04-23 19:56:54 --> Helper loaded: url_helper
DEBUG - 2011-04-23 19:56:54 --> File loaded: application/views/common/header.php
DEBUG - 2011-04-23 19:56:54 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-04-23 19:56:54 --> File loaded: application/views/common/footer.php
DEBUG - 2011-04-23 19:56:54 --> File loaded: application/views/layout/main.php
DEBUG - 2011-04-23 19:56:54 --> Final output sent to browser
DEBUG - 2011-04-23 19:56:54 --> Total execution time: 0.0748
DEBUG - 2011-04-23 19:56:54 --> Config Class Initialized
DEBUG - 2011-04-23 19:56:54 --> Hooks Class Initialized
DEBUG - 2011-04-23 19:56:54 --> Utf8 Class Initialized
DEBUG - 2011-04-23 19:56:54 --> UTF-8 Support Enabled
DEBUG - 2011-04-23 19:56:54 --> URI Class Initialized
DEBUG - 2011-04-23 19:56:54 --> Router Class Initialized
ERROR - 2011-04-23 19:56:54 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-04-23 19:57:07 --> Config Class Initialized
DEBUG - 2011-04-23 19:57:07 --> Hooks Class Initialized
DEBUG - 2011-04-23 19:57:07 --> Utf8 Class Initialized
DEBUG - 2011-04-23 19:57:07 --> UTF-8 Support Enabled
DEBUG - 2011-04-23 19:57:07 --> URI Class Initialized
DEBUG - 2011-04-23 19:57:07 --> Router Class Initialized
DEBUG - 2011-04-23 19:57:07 --> Output Class Initialized
DEBUG - 2011-04-23 19:57:07 --> Input Class Initialized
DEBUG - 2011-04-23 19:57:07 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-23 19:57:07 --> Language Class Initialized
DEBUG - 2011-04-23 19:57:07 --> Loader Class Initialized
DEBUG - 2011-04-23 19:57:07 --> Controller Class Initialized
DEBUG - 2011-04-23 19:57:07 --> Model Class Initialized
DEBUG - 2011-04-23 19:57:07 --> Model Class Initialized
DEBUG - 2011-04-23 19:57:07 --> Model Class Initialized
DEBUG - 2011-04-23 19:57:07 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-23 19:57:07 --> Database Driver Class Initialized
DEBUG - 2011-04-23 19:57:07 --> File loaded: application/views/table/main.php
DEBUG - 2011-04-23 19:57:07 --> Helper loaded: url_helper
DEBUG - 2011-04-23 19:57:07 --> File loaded: application/views/common/header.php
DEBUG - 2011-04-23 19:57:07 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-04-23 19:57:07 --> File loaded: application/views/common/footer.php
DEBUG - 2011-04-23 19:57:07 --> File loaded: application/views/layout/main.php
DEBUG - 2011-04-23 19:57:07 --> Final output sent to browser
DEBUG - 2011-04-23 19:57:07 --> Total execution time: 0.2120
DEBUG - 2011-04-23 19:57:08 --> Config Class Initialized
DEBUG - 2011-04-23 19:57:08 --> Hooks Class Initialized
DEBUG - 2011-04-23 19:57:08 --> Utf8 Class Initialized
DEBUG - 2011-04-23 19:57:08 --> UTF-8 Support Enabled
DEBUG - 2011-04-23 19:57:08 --> URI Class Initialized
DEBUG - 2011-04-23 19:57:08 --> Router Class Initialized
DEBUG - 2011-04-23 19:57:08 --> Output Class Initialized
DEBUG - 2011-04-23 19:57:08 --> Input Class Initialized
DEBUG - 2011-04-23 19:57:08 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-23 19:57:08 --> Language Class Initialized
DEBUG - 2011-04-23 19:57:08 --> Loader Class Initialized
DEBUG - 2011-04-23 19:57:08 --> Controller Class Initialized
DEBUG - 2011-04-23 19:57:08 --> Model Class Initialized
DEBUG - 2011-04-23 19:57:08 --> Model Class Initialized
DEBUG - 2011-04-23 19:57:08 --> Model Class Initialized
DEBUG - 2011-04-23 19:57:08 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-23 19:57:08 --> Database Driver Class Initialized
DEBUG - 2011-04-23 19:57:08 --> File loaded: application/views/table/main.php
DEBUG - 2011-04-23 19:57:08 --> Helper loaded: url_helper
DEBUG - 2011-04-23 19:57:08 --> File loaded: application/views/common/header.php
DEBUG - 2011-04-23 19:57:08 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-04-23 19:57:08 --> File loaded: application/views/common/footer.php
DEBUG - 2011-04-23 19:57:08 --> File loaded: application/views/layout/main.php
DEBUG - 2011-04-23 19:57:08 --> Final output sent to browser
DEBUG - 2011-04-23 19:57:08 --> Total execution time: 0.0422
DEBUG - 2011-04-23 19:57:08 --> Config Class Initialized
DEBUG - 2011-04-23 19:57:08 --> Hooks Class Initialized
DEBUG - 2011-04-23 19:57:08 --> Utf8 Class Initialized
DEBUG - 2011-04-23 19:57:08 --> UTF-8 Support Enabled
DEBUG - 2011-04-23 19:57:08 --> URI Class Initialized
DEBUG - 2011-04-23 19:57:08 --> Router Class Initialized
ERROR - 2011-04-23 19:57:08 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-04-23 19:57:19 --> Config Class Initialized
DEBUG - 2011-04-23 19:57:19 --> Hooks Class Initialized
DEBUG - 2011-04-23 19:57:19 --> Utf8 Class Initialized
DEBUG - 2011-04-23 19:57:19 --> UTF-8 Support Enabled
DEBUG - 2011-04-23 19:57:19 --> URI Class Initialized
DEBUG - 2011-04-23 19:57:19 --> Router Class Initialized
DEBUG - 2011-04-23 19:57:19 --> Output Class Initialized
DEBUG - 2011-04-23 19:57:19 --> Input Class Initialized
DEBUG - 2011-04-23 19:57:19 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-23 19:57:19 --> Language Class Initialized
DEBUG - 2011-04-23 19:57:19 --> Loader Class Initialized
DEBUG - 2011-04-23 19:57:19 --> Controller Class Initialized
DEBUG - 2011-04-23 19:57:19 --> Model Class Initialized
DEBUG - 2011-04-23 19:57:19 --> Model Class Initialized
DEBUG - 2011-04-23 19:57:19 --> Model Class Initialized
DEBUG - 2011-04-23 19:57:19 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-23 19:57:19 --> Database Driver Class Initialized
DEBUG - 2011-04-23 19:57:20 --> File loaded: application/views/table/main.php
DEBUG - 2011-04-23 19:57:20 --> Helper loaded: url_helper
DEBUG - 2011-04-23 19:57:20 --> File loaded: application/views/common/header.php
DEBUG - 2011-04-23 19:57:20 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-04-23 19:57:20 --> File loaded: application/views/common/footer.php
DEBUG - 2011-04-23 19:57:20 --> File loaded: application/views/layout/main.php
DEBUG - 2011-04-23 19:57:20 --> Final output sent to browser
DEBUG - 2011-04-23 19:57:20 --> Total execution time: 0.4522
DEBUG - 2011-04-23 19:57:21 --> Config Class Initialized
DEBUG - 2011-04-23 19:57:21 --> Hooks Class Initialized
DEBUG - 2011-04-23 19:57:21 --> Utf8 Class Initialized
DEBUG - 2011-04-23 19:57:21 --> UTF-8 Support Enabled
DEBUG - 2011-04-23 19:57:21 --> URI Class Initialized
DEBUG - 2011-04-23 19:57:21 --> Router Class Initialized
ERROR - 2011-04-23 19:57:21 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-04-23 19:57:51 --> Config Class Initialized
DEBUG - 2011-04-23 19:57:51 --> Hooks Class Initialized
DEBUG - 2011-04-23 19:57:51 --> Utf8 Class Initialized
DEBUG - 2011-04-23 19:57:51 --> UTF-8 Support Enabled
DEBUG - 2011-04-23 19:57:51 --> URI Class Initialized
DEBUG - 2011-04-23 19:57:51 --> Router Class Initialized
DEBUG - 2011-04-23 19:57:51 --> Output Class Initialized
DEBUG - 2011-04-23 19:57:51 --> Input Class Initialized
DEBUG - 2011-04-23 19:57:51 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-23 19:57:51 --> Language Class Initialized
DEBUG - 2011-04-23 19:57:51 --> Loader Class Initialized
DEBUG - 2011-04-23 19:57:51 --> Controller Class Initialized
DEBUG - 2011-04-23 19:57:51 --> Model Class Initialized
DEBUG - 2011-04-23 19:57:51 --> Model Class Initialized
DEBUG - 2011-04-23 19:57:51 --> Model Class Initialized
DEBUG - 2011-04-23 19:57:51 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-23 19:57:51 --> Database Driver Class Initialized
DEBUG - 2011-04-23 19:57:51 --> File loaded: application/views/table/main.php
DEBUG - 2011-04-23 19:57:51 --> Helper loaded: url_helper
DEBUG - 2011-04-23 19:57:51 --> File loaded: application/views/common/header.php
DEBUG - 2011-04-23 19:57:51 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-04-23 19:57:51 --> File loaded: application/views/common/footer.php
DEBUG - 2011-04-23 19:57:51 --> File loaded: application/views/layout/main.php
DEBUG - 2011-04-23 19:57:51 --> Final output sent to browser
DEBUG - 2011-04-23 19:57:51 --> Total execution time: 0.3473
DEBUG - 2011-04-23 19:57:53 --> Config Class Initialized
DEBUG - 2011-04-23 19:57:53 --> Hooks Class Initialized
DEBUG - 2011-04-23 19:57:53 --> Utf8 Class Initialized
DEBUG - 2011-04-23 19:57:53 --> UTF-8 Support Enabled
DEBUG - 2011-04-23 19:57:53 --> URI Class Initialized
DEBUG - 2011-04-23 19:57:53 --> Router Class Initialized
ERROR - 2011-04-23 19:57:53 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-04-23 19:57:53 --> Config Class Initialized
DEBUG - 2011-04-23 19:57:53 --> Hooks Class Initialized
DEBUG - 2011-04-23 19:57:53 --> Utf8 Class Initialized
DEBUG - 2011-04-23 19:57:53 --> UTF-8 Support Enabled
DEBUG - 2011-04-23 19:57:53 --> URI Class Initialized
DEBUG - 2011-04-23 19:57:53 --> Router Class Initialized
DEBUG - 2011-04-23 19:57:53 --> Output Class Initialized
DEBUG - 2011-04-23 19:57:53 --> Input Class Initialized
DEBUG - 2011-04-23 19:57:53 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-23 19:57:53 --> Language Class Initialized
DEBUG - 2011-04-23 19:57:53 --> Loader Class Initialized
DEBUG - 2011-04-23 19:57:53 --> Controller Class Initialized
DEBUG - 2011-04-23 19:57:53 --> Model Class Initialized
DEBUG - 2011-04-23 19:57:53 --> Model Class Initialized
DEBUG - 2011-04-23 19:57:53 --> Model Class Initialized
DEBUG - 2011-04-23 19:57:53 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-23 19:57:53 --> Database Driver Class Initialized
DEBUG - 2011-04-23 19:57:53 --> File loaded: application/views/table/main.php
DEBUG - 2011-04-23 19:57:53 --> Helper loaded: url_helper
DEBUG - 2011-04-23 19:57:53 --> File loaded: application/views/common/header.php
DEBUG - 2011-04-23 19:57:53 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-04-23 19:57:53 --> File loaded: application/views/common/footer.php
DEBUG - 2011-04-23 19:57:53 --> File loaded: application/views/layout/main.php
DEBUG - 2011-04-23 19:57:53 --> Final output sent to browser
DEBUG - 2011-04-23 19:57:53 --> Total execution time: 0.0784
DEBUG - 2011-04-23 19:58:11 --> Config Class Initialized
DEBUG - 2011-04-23 19:58:11 --> Hooks Class Initialized
DEBUG - 2011-04-23 19:58:11 --> Utf8 Class Initialized
DEBUG - 2011-04-23 19:58:11 --> UTF-8 Support Enabled
DEBUG - 2011-04-23 19:58:11 --> URI Class Initialized
DEBUG - 2011-04-23 19:58:11 --> Router Class Initialized
DEBUG - 2011-04-23 19:58:11 --> Output Class Initialized
DEBUG - 2011-04-23 19:58:11 --> Input Class Initialized
DEBUG - 2011-04-23 19:58:11 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-23 19:58:11 --> Language Class Initialized
DEBUG - 2011-04-23 19:58:11 --> Loader Class Initialized
DEBUG - 2011-04-23 19:58:11 --> Controller Class Initialized
DEBUG - 2011-04-23 19:58:11 --> Model Class Initialized
DEBUG - 2011-04-23 19:58:11 --> Model Class Initialized
DEBUG - 2011-04-23 19:58:11 --> Model Class Initialized
DEBUG - 2011-04-23 19:58:11 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-23 19:58:11 --> Database Driver Class Initialized
DEBUG - 2011-04-23 19:58:11 --> File loaded: application/views/table/main.php
DEBUG - 2011-04-23 19:58:11 --> Helper loaded: url_helper
DEBUG - 2011-04-23 19:58:11 --> File loaded: application/views/common/header.php
DEBUG - 2011-04-23 19:58:11 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-04-23 19:58:11 --> File loaded: application/views/common/footer.php
DEBUG - 2011-04-23 19:58:11 --> File loaded: application/views/layout/main.php
DEBUG - 2011-04-23 19:58:11 --> Final output sent to browser
DEBUG - 2011-04-23 19:58:11 --> Total execution time: 0.0555
DEBUG - 2011-04-23 19:58:12 --> Config Class Initialized
DEBUG - 2011-04-23 19:58:12 --> Hooks Class Initialized
DEBUG - 2011-04-23 19:58:12 --> Utf8 Class Initialized
DEBUG - 2011-04-23 19:58:12 --> UTF-8 Support Enabled
DEBUG - 2011-04-23 19:58:12 --> URI Class Initialized
DEBUG - 2011-04-23 19:58:12 --> Router Class Initialized
ERROR - 2011-04-23 19:58:12 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-04-23 19:58:31 --> Config Class Initialized
DEBUG - 2011-04-23 19:58:31 --> Hooks Class Initialized
DEBUG - 2011-04-23 19:58:31 --> Utf8 Class Initialized
DEBUG - 2011-04-23 19:58:31 --> UTF-8 Support Enabled
DEBUG - 2011-04-23 19:58:31 --> URI Class Initialized
DEBUG - 2011-04-23 19:58:31 --> Router Class Initialized
DEBUG - 2011-04-23 19:58:31 --> Output Class Initialized
DEBUG - 2011-04-23 19:58:31 --> Input Class Initialized
DEBUG - 2011-04-23 19:58:31 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-23 19:58:31 --> Language Class Initialized
DEBUG - 2011-04-23 19:58:31 --> Loader Class Initialized
DEBUG - 2011-04-23 19:58:31 --> Controller Class Initialized
DEBUG - 2011-04-23 19:58:31 --> Model Class Initialized
DEBUG - 2011-04-23 19:58:31 --> Model Class Initialized
DEBUG - 2011-04-23 19:58:31 --> Model Class Initialized
DEBUG - 2011-04-23 19:58:31 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-23 19:58:31 --> Database Driver Class Initialized
DEBUG - 2011-04-23 19:58:31 --> File loaded: application/views/table/main.php
DEBUG - 2011-04-23 19:58:31 --> Helper loaded: url_helper
DEBUG - 2011-04-23 19:58:31 --> File loaded: application/views/common/header.php
DEBUG - 2011-04-23 19:58:31 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-04-23 19:58:31 --> File loaded: application/views/common/footer.php
DEBUG - 2011-04-23 19:58:31 --> File loaded: application/views/layout/main.php
DEBUG - 2011-04-23 19:58:31 --> Final output sent to browser
DEBUG - 2011-04-23 19:58:31 --> Total execution time: 0.3190
DEBUG - 2011-04-23 19:58:33 --> Config Class Initialized
DEBUG - 2011-04-23 19:58:33 --> Hooks Class Initialized
DEBUG - 2011-04-23 19:58:33 --> Utf8 Class Initialized
DEBUG - 2011-04-23 19:58:33 --> UTF-8 Support Enabled
DEBUG - 2011-04-23 19:58:33 --> URI Class Initialized
DEBUG - 2011-04-23 19:58:33 --> Router Class Initialized
ERROR - 2011-04-23 19:58:33 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-04-23 19:59:05 --> Config Class Initialized
DEBUG - 2011-04-23 19:59:05 --> Hooks Class Initialized
DEBUG - 2011-04-23 19:59:05 --> Utf8 Class Initialized
DEBUG - 2011-04-23 19:59:05 --> UTF-8 Support Enabled
DEBUG - 2011-04-23 19:59:05 --> URI Class Initialized
DEBUG - 2011-04-23 19:59:05 --> Router Class Initialized
DEBUG - 2011-04-23 19:59:05 --> Output Class Initialized
DEBUG - 2011-04-23 19:59:05 --> Input Class Initialized
DEBUG - 2011-04-23 19:59:05 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-23 19:59:05 --> Language Class Initialized
DEBUG - 2011-04-23 19:59:05 --> Loader Class Initialized
DEBUG - 2011-04-23 19:59:05 --> Controller Class Initialized
DEBUG - 2011-04-23 19:59:05 --> Model Class Initialized
DEBUG - 2011-04-23 19:59:05 --> Model Class Initialized
DEBUG - 2011-04-23 19:59:05 --> Model Class Initialized
DEBUG - 2011-04-23 19:59:05 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-23 19:59:05 --> Database Driver Class Initialized
DEBUG - 2011-04-23 19:59:06 --> File loaded: application/views/table/main.php
DEBUG - 2011-04-23 19:59:06 --> Helper loaded: url_helper
DEBUG - 2011-04-23 19:59:06 --> File loaded: application/views/common/header.php
DEBUG - 2011-04-23 19:59:06 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-04-23 19:59:06 --> File loaded: application/views/common/footer.php
DEBUG - 2011-04-23 19:59:06 --> File loaded: application/views/layout/main.php
DEBUG - 2011-04-23 19:59:06 --> Final output sent to browser
DEBUG - 2011-04-23 19:59:06 --> Total execution time: 0.7312
DEBUG - 2011-04-23 19:59:07 --> Config Class Initialized
DEBUG - 2011-04-23 19:59:07 --> Hooks Class Initialized
DEBUG - 2011-04-23 19:59:07 --> Utf8 Class Initialized
DEBUG - 2011-04-23 19:59:07 --> UTF-8 Support Enabled
DEBUG - 2011-04-23 19:59:07 --> URI Class Initialized
DEBUG - 2011-04-23 19:59:07 --> Router Class Initialized
DEBUG - 2011-04-23 19:59:07 --> Output Class Initialized
DEBUG - 2011-04-23 19:59:07 --> Input Class Initialized
DEBUG - 2011-04-23 19:59:07 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-23 19:59:07 --> Language Class Initialized
DEBUG - 2011-04-23 19:59:07 --> Loader Class Initialized
DEBUG - 2011-04-23 19:59:07 --> Controller Class Initialized
DEBUG - 2011-04-23 19:59:07 --> Model Class Initialized
DEBUG - 2011-04-23 19:59:07 --> Model Class Initialized
DEBUG - 2011-04-23 19:59:07 --> Model Class Initialized
DEBUG - 2011-04-23 19:59:07 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-23 19:59:07 --> Database Driver Class Initialized
DEBUG - 2011-04-23 19:59:07 --> File loaded: application/views/table/main.php
DEBUG - 2011-04-23 19:59:07 --> Helper loaded: url_helper
DEBUG - 2011-04-23 19:59:07 --> File loaded: application/views/common/header.php
DEBUG - 2011-04-23 19:59:07 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-04-23 19:59:07 --> File loaded: application/views/common/footer.php
DEBUG - 2011-04-23 19:59:07 --> File loaded: application/views/layout/main.php
DEBUG - 2011-04-23 19:59:07 --> Final output sent to browser
DEBUG - 2011-04-23 19:59:07 --> Total execution time: 0.0491
DEBUG - 2011-04-23 19:59:07 --> Config Class Initialized
DEBUG - 2011-04-23 19:59:07 --> Hooks Class Initialized
DEBUG - 2011-04-23 19:59:07 --> Utf8 Class Initialized
DEBUG - 2011-04-23 19:59:07 --> UTF-8 Support Enabled
DEBUG - 2011-04-23 19:59:07 --> URI Class Initialized
DEBUG - 2011-04-23 19:59:07 --> Router Class Initialized
DEBUG - 2011-04-23 19:59:07 --> Output Class Initialized
DEBUG - 2011-04-23 19:59:07 --> Input Class Initialized
DEBUG - 2011-04-23 19:59:07 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-23 19:59:07 --> Language Class Initialized
DEBUG - 2011-04-23 19:59:07 --> Loader Class Initialized
DEBUG - 2011-04-23 19:59:07 --> Controller Class Initialized
DEBUG - 2011-04-23 19:59:07 --> Model Class Initialized
DEBUG - 2011-04-23 19:59:07 --> Model Class Initialized
DEBUG - 2011-04-23 19:59:07 --> Model Class Initialized
DEBUG - 2011-04-23 19:59:07 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-23 19:59:07 --> Database Driver Class Initialized
DEBUG - 2011-04-23 19:59:07 --> File loaded: application/views/table/main.php
DEBUG - 2011-04-23 19:59:07 --> Helper loaded: url_helper
DEBUG - 2011-04-23 19:59:07 --> File loaded: application/views/common/header.php
DEBUG - 2011-04-23 19:59:07 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-04-23 19:59:07 --> File loaded: application/views/common/footer.php
DEBUG - 2011-04-23 19:59:07 --> File loaded: application/views/layout/main.php
DEBUG - 2011-04-23 19:59:07 --> Final output sent to browser
DEBUG - 2011-04-23 19:59:07 --> Total execution time: 0.0483
DEBUG - 2011-04-23 19:59:08 --> Config Class Initialized
DEBUG - 2011-04-23 19:59:08 --> Hooks Class Initialized
DEBUG - 2011-04-23 19:59:08 --> Utf8 Class Initialized
DEBUG - 2011-04-23 19:59:08 --> UTF-8 Support Enabled
DEBUG - 2011-04-23 19:59:08 --> URI Class Initialized
DEBUG - 2011-04-23 19:59:08 --> Router Class Initialized
DEBUG - 2011-04-23 19:59:08 --> Output Class Initialized
DEBUG - 2011-04-23 19:59:08 --> Input Class Initialized
DEBUG - 2011-04-23 19:59:08 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-23 19:59:08 --> Language Class Initialized
DEBUG - 2011-04-23 19:59:08 --> Loader Class Initialized
DEBUG - 2011-04-23 19:59:08 --> Controller Class Initialized
DEBUG - 2011-04-23 19:59:08 --> Model Class Initialized
DEBUG - 2011-04-23 19:59:08 --> Model Class Initialized
DEBUG - 2011-04-23 19:59:08 --> Model Class Initialized
DEBUG - 2011-04-23 19:59:08 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-23 19:59:08 --> Database Driver Class Initialized
DEBUG - 2011-04-23 19:59:08 --> File loaded: application/views/table/main.php
DEBUG - 2011-04-23 19:59:08 --> Helper loaded: url_helper
DEBUG - 2011-04-23 19:59:08 --> File loaded: application/views/common/header.php
DEBUG - 2011-04-23 19:59:08 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-04-23 19:59:08 --> File loaded: application/views/common/footer.php
DEBUG - 2011-04-23 19:59:08 --> File loaded: application/views/layout/main.php
DEBUG - 2011-04-23 19:59:08 --> Final output sent to browser
DEBUG - 2011-04-23 19:59:08 --> Total execution time: 0.0599
DEBUG - 2011-04-23 19:59:08 --> Config Class Initialized
DEBUG - 2011-04-23 19:59:08 --> Hooks Class Initialized
DEBUG - 2011-04-23 19:59:08 --> Utf8 Class Initialized
DEBUG - 2011-04-23 19:59:08 --> UTF-8 Support Enabled
DEBUG - 2011-04-23 19:59:08 --> URI Class Initialized
DEBUG - 2011-04-23 19:59:08 --> Router Class Initialized
ERROR - 2011-04-23 19:59:08 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-04-23 22:09:16 --> Config Class Initialized
DEBUG - 2011-04-23 22:09:16 --> Hooks Class Initialized
DEBUG - 2011-04-23 22:09:16 --> Utf8 Class Initialized
DEBUG - 2011-04-23 22:09:16 --> UTF-8 Support Enabled
DEBUG - 2011-04-23 22:09:16 --> URI Class Initialized
DEBUG - 2011-04-23 22:09:16 --> Router Class Initialized
DEBUG - 2011-04-23 22:09:16 --> Output Class Initialized
DEBUG - 2011-04-23 22:09:16 --> Input Class Initialized
DEBUG - 2011-04-23 22:09:16 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-23 22:09:16 --> Language Class Initialized
DEBUG - 2011-04-23 22:09:16 --> Loader Class Initialized
DEBUG - 2011-04-23 22:09:16 --> Controller Class Initialized
DEBUG - 2011-04-23 22:09:16 --> Model Class Initialized
DEBUG - 2011-04-23 22:09:16 --> Model Class Initialized
DEBUG - 2011-04-23 22:09:16 --> Model Class Initialized
DEBUG - 2011-04-23 22:09:16 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-23 22:09:16 --> Database Driver Class Initialized
DEBUG - 2011-04-23 22:09:16 --> File loaded: application/views/table/main.php
DEBUG - 2011-04-23 22:09:16 --> Helper loaded: url_helper
DEBUG - 2011-04-23 22:09:16 --> File loaded: application/views/common/header.php
DEBUG - 2011-04-23 22:09:16 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-04-23 22:09:16 --> File loaded: application/views/common/footer.php
DEBUG - 2011-04-23 22:09:16 --> File loaded: application/views/layout/main.php
DEBUG - 2011-04-23 22:09:16 --> Final output sent to browser
DEBUG - 2011-04-23 22:09:16 --> Total execution time: 0.4952
DEBUG - 2011-04-23 22:10:05 --> Config Class Initialized
DEBUG - 2011-04-23 22:10:05 --> Hooks Class Initialized
DEBUG - 2011-04-23 22:10:05 --> Utf8 Class Initialized
DEBUG - 2011-04-23 22:10:05 --> UTF-8 Support Enabled
DEBUG - 2011-04-23 22:10:05 --> URI Class Initialized
DEBUG - 2011-04-23 22:10:05 --> Router Class Initialized
DEBUG - 2011-04-23 22:10:05 --> Output Class Initialized
DEBUG - 2011-04-23 22:10:05 --> Input Class Initialized
DEBUG - 2011-04-23 22:10:05 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-23 22:10:05 --> Language Class Initialized
DEBUG - 2011-04-23 22:10:05 --> Loader Class Initialized
DEBUG - 2011-04-23 22:10:05 --> Controller Class Initialized
DEBUG - 2011-04-23 22:10:05 --> Model Class Initialized
DEBUG - 2011-04-23 22:10:05 --> Model Class Initialized
DEBUG - 2011-04-23 22:10:05 --> Model Class Initialized
DEBUG - 2011-04-23 22:10:05 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-23 22:10:05 --> Database Driver Class Initialized
DEBUG - 2011-04-23 22:10:05 --> File loaded: application/views/table/main.php
DEBUG - 2011-04-23 22:10:05 --> Helper loaded: url_helper
DEBUG - 2011-04-23 22:10:05 --> File loaded: application/views/common/header.php
DEBUG - 2011-04-23 22:10:05 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-04-23 22:10:05 --> File loaded: application/views/common/footer.php
DEBUG - 2011-04-23 22:10:05 --> File loaded: application/views/layout/main.php
DEBUG - 2011-04-23 22:10:05 --> Final output sent to browser
DEBUG - 2011-04-23 22:10:05 --> Total execution time: 0.2572
DEBUG - 2011-04-23 22:10:39 --> Config Class Initialized
DEBUG - 2011-04-23 22:10:39 --> Hooks Class Initialized
DEBUG - 2011-04-23 22:10:39 --> Utf8 Class Initialized
DEBUG - 2011-04-23 22:10:39 --> UTF-8 Support Enabled
DEBUG - 2011-04-23 22:10:39 --> URI Class Initialized
DEBUG - 2011-04-23 22:10:39 --> Router Class Initialized
DEBUG - 2011-04-23 22:10:39 --> Output Class Initialized
DEBUG - 2011-04-23 22:10:39 --> Input Class Initialized
DEBUG - 2011-04-23 22:10:39 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-23 22:10:39 --> Language Class Initialized
DEBUG - 2011-04-23 22:10:39 --> Loader Class Initialized
DEBUG - 2011-04-23 22:10:39 --> Controller Class Initialized
DEBUG - 2011-04-23 22:10:39 --> Model Class Initialized
DEBUG - 2011-04-23 22:10:39 --> Model Class Initialized
DEBUG - 2011-04-23 22:10:39 --> Model Class Initialized
DEBUG - 2011-04-23 22:10:39 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-23 22:10:39 --> Database Driver Class Initialized
DEBUG - 2011-04-23 22:10:39 --> File loaded: application/views/table/main.php
DEBUG - 2011-04-23 22:10:39 --> Helper loaded: url_helper
DEBUG - 2011-04-23 22:10:39 --> File loaded: application/views/common/header.php
DEBUG - 2011-04-23 22:10:39 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-04-23 22:10:39 --> File loaded: application/views/common/footer.php
DEBUG - 2011-04-23 22:10:39 --> File loaded: application/views/layout/main.php
DEBUG - 2011-04-23 22:10:39 --> Final output sent to browser
DEBUG - 2011-04-23 22:10:39 --> Total execution time: 0.2554
DEBUG - 2011-04-23 22:10:42 --> Config Class Initialized
DEBUG - 2011-04-23 22:10:42 --> Hooks Class Initialized
DEBUG - 2011-04-23 22:10:42 --> Utf8 Class Initialized
DEBUG - 2011-04-23 22:10:42 --> UTF-8 Support Enabled
DEBUG - 2011-04-23 22:10:42 --> URI Class Initialized
DEBUG - 2011-04-23 22:10:42 --> Router Class Initialized
DEBUG - 2011-04-23 22:10:42 --> Output Class Initialized
DEBUG - 2011-04-23 22:10:42 --> Input Class Initialized
DEBUG - 2011-04-23 22:10:42 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-23 22:10:42 --> Language Class Initialized
DEBUG - 2011-04-23 22:10:42 --> Loader Class Initialized
DEBUG - 2011-04-23 22:10:42 --> Controller Class Initialized
DEBUG - 2011-04-23 22:10:42 --> Model Class Initialized
DEBUG - 2011-04-23 22:10:42 --> Model Class Initialized
DEBUG - 2011-04-23 22:10:42 --> Model Class Initialized
DEBUG - 2011-04-23 22:10:42 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-23 22:10:42 --> Database Driver Class Initialized
DEBUG - 2011-04-23 22:10:42 --> File loaded: application/views/table/main.php
DEBUG - 2011-04-23 22:10:42 --> Helper loaded: url_helper
DEBUG - 2011-04-23 22:10:42 --> File loaded: application/views/common/header.php
DEBUG - 2011-04-23 22:10:42 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-04-23 22:10:42 --> File loaded: application/views/common/footer.php
DEBUG - 2011-04-23 22:10:42 --> File loaded: application/views/layout/main.php
DEBUG - 2011-04-23 22:10:42 --> Final output sent to browser
DEBUG - 2011-04-23 22:10:42 --> Total execution time: 0.0659
DEBUG - 2011-04-23 22:25:59 --> Config Class Initialized
DEBUG - 2011-04-23 22:25:59 --> Hooks Class Initialized
DEBUG - 2011-04-23 22:25:59 --> Utf8 Class Initialized
DEBUG - 2011-04-23 22:25:59 --> UTF-8 Support Enabled
DEBUG - 2011-04-23 22:25:59 --> URI Class Initialized
DEBUG - 2011-04-23 22:25:59 --> Router Class Initialized
DEBUG - 2011-04-23 22:25:59 --> No URI present. Default controller set.
DEBUG - 2011-04-23 22:25:59 --> Output Class Initialized
DEBUG - 2011-04-23 22:25:59 --> Input Class Initialized
DEBUG - 2011-04-23 22:25:59 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-23 22:25:59 --> Language Class Initialized
DEBUG - 2011-04-23 22:25:59 --> Loader Class Initialized
DEBUG - 2011-04-23 22:25:59 --> Controller Class Initialized
DEBUG - 2011-04-23 22:25:59 --> File loaded: application/views/splash/main.php
DEBUG - 2011-04-23 22:25:59 --> Helper loaded: url_helper
DEBUG - 2011-04-23 22:25:59 --> File loaded: application/views/common/header.php
DEBUG - 2011-04-23 22:25:59 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-04-23 22:25:59 --> File loaded: application/views/common/footer.php
DEBUG - 2011-04-23 22:25:59 --> File loaded: application/views/layout/main.php
DEBUG - 2011-04-23 22:25:59 --> Final output sent to browser
DEBUG - 2011-04-23 22:25:59 --> Total execution time: 0.0659
DEBUG - 2011-04-23 22:27:43 --> Config Class Initialized
DEBUG - 2011-04-23 22:27:43 --> Hooks Class Initialized
DEBUG - 2011-04-23 22:27:43 --> Utf8 Class Initialized
DEBUG - 2011-04-23 22:27:43 --> UTF-8 Support Enabled
DEBUG - 2011-04-23 22:27:43 --> URI Class Initialized
DEBUG - 2011-04-23 22:27:43 --> Router Class Initialized
DEBUG - 2011-04-23 22:27:43 --> No URI present. Default controller set.
DEBUG - 2011-04-23 22:27:43 --> Output Class Initialized
DEBUG - 2011-04-23 22:27:43 --> Input Class Initialized
DEBUG - 2011-04-23 22:27:43 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-23 22:27:43 --> Language Class Initialized
DEBUG - 2011-04-23 22:27:43 --> Loader Class Initialized
DEBUG - 2011-04-23 22:27:43 --> Controller Class Initialized
DEBUG - 2011-04-23 22:27:43 --> File loaded: application/views/splash/main.php
DEBUG - 2011-04-23 22:27:43 --> Helper loaded: url_helper
DEBUG - 2011-04-23 22:27:43 --> File loaded: application/views/common/header.php
DEBUG - 2011-04-23 22:27:43 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-04-23 22:27:43 --> File loaded: application/views/common/footer.php
DEBUG - 2011-04-23 22:27:43 --> File loaded: application/views/layout/main.php
DEBUG - 2011-04-23 22:27:43 --> Final output sent to browser
DEBUG - 2011-04-23 22:27:43 --> Total execution time: 0.0127
DEBUG - 2011-04-23 22:27:45 --> Config Class Initialized
DEBUG - 2011-04-23 22:27:45 --> Hooks Class Initialized
DEBUG - 2011-04-23 22:27:45 --> Utf8 Class Initialized
DEBUG - 2011-04-23 22:27:45 --> UTF-8 Support Enabled
DEBUG - 2011-04-23 22:27:45 --> URI Class Initialized
DEBUG - 2011-04-23 22:27:45 --> Router Class Initialized
DEBUG - 2011-04-23 22:27:45 --> No URI present. Default controller set.
DEBUG - 2011-04-23 22:27:45 --> Output Class Initialized
DEBUG - 2011-04-23 22:27:45 --> Input Class Initialized
DEBUG - 2011-04-23 22:27:45 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-23 22:27:45 --> Language Class Initialized
DEBUG - 2011-04-23 22:27:45 --> Loader Class Initialized
DEBUG - 2011-04-23 22:27:45 --> Controller Class Initialized
DEBUG - 2011-04-23 22:27:45 --> File loaded: application/views/splash/main.php
DEBUG - 2011-04-23 22:27:45 --> Helper loaded: url_helper
DEBUG - 2011-04-23 22:27:45 --> File loaded: application/views/common/header.php
DEBUG - 2011-04-23 22:27:45 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-04-23 22:27:45 --> File loaded: application/views/common/footer.php
DEBUG - 2011-04-23 22:27:45 --> File loaded: application/views/layout/main.php
DEBUG - 2011-04-23 22:27:45 --> Final output sent to browser
DEBUG - 2011-04-23 22:27:45 --> Total execution time: 0.0129
DEBUG - 2011-04-23 22:28:04 --> Config Class Initialized
DEBUG - 2011-04-23 22:28:04 --> Hooks Class Initialized
DEBUG - 2011-04-23 22:28:04 --> Utf8 Class Initialized
DEBUG - 2011-04-23 22:28:04 --> UTF-8 Support Enabled
DEBUG - 2011-04-23 22:28:04 --> URI Class Initialized
DEBUG - 2011-04-23 22:28:04 --> Router Class Initialized
DEBUG - 2011-04-23 22:28:04 --> Output Class Initialized
DEBUG - 2011-04-23 22:28:04 --> Input Class Initialized
DEBUG - 2011-04-23 22:28:04 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-23 22:28:04 --> Language Class Initialized
DEBUG - 2011-04-23 22:28:04 --> Loader Class Initialized
DEBUG - 2011-04-23 22:28:04 --> Controller Class Initialized
DEBUG - 2011-04-23 22:28:04 --> Model Class Initialized
DEBUG - 2011-04-23 22:28:04 --> Model Class Initialized
DEBUG - 2011-04-23 22:28:04 --> Model Class Initialized
DEBUG - 2011-04-23 22:28:04 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-23 22:28:04 --> Database Driver Class Initialized
DEBUG - 2011-04-23 22:28:04 --> File loaded: application/views/table/main.php
DEBUG - 2011-04-23 22:28:04 --> Helper loaded: url_helper
DEBUG - 2011-04-23 22:28:04 --> File loaded: application/views/common/header.php
DEBUG - 2011-04-23 22:28:04 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-04-23 22:28:04 --> File loaded: application/views/common/footer.php
DEBUG - 2011-04-23 22:28:04 --> File loaded: application/views/layout/main.php
DEBUG - 2011-04-23 22:28:04 --> Final output sent to browser
DEBUG - 2011-04-23 22:28:04 --> Total execution time: 0.0460
DEBUG - 2011-04-23 22:29:40 --> Config Class Initialized
DEBUG - 2011-04-23 22:29:40 --> Hooks Class Initialized
DEBUG - 2011-04-23 22:29:40 --> Utf8 Class Initialized
DEBUG - 2011-04-23 22:29:40 --> UTF-8 Support Enabled
DEBUG - 2011-04-23 22:29:40 --> URI Class Initialized
DEBUG - 2011-04-23 22:29:40 --> Router Class Initialized
DEBUG - 2011-04-23 22:29:40 --> No URI present. Default controller set.
DEBUG - 2011-04-23 22:29:40 --> Output Class Initialized
DEBUG - 2011-04-23 22:29:40 --> Input Class Initialized
DEBUG - 2011-04-23 22:29:40 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-23 22:29:40 --> Language Class Initialized
DEBUG - 2011-04-23 22:29:40 --> Loader Class Initialized
DEBUG - 2011-04-23 22:29:40 --> Controller Class Initialized
DEBUG - 2011-04-23 22:29:40 --> File loaded: application/views/splash/main.php
DEBUG - 2011-04-23 22:29:40 --> Helper loaded: url_helper
DEBUG - 2011-04-23 22:29:40 --> File loaded: application/views/common/header.php
DEBUG - 2011-04-23 22:29:40 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-04-23 22:29:40 --> File loaded: application/views/common/footer.php
DEBUG - 2011-04-23 22:29:40 --> File loaded: application/views/layout/main.php
DEBUG - 2011-04-23 22:29:40 --> Final output sent to browser
DEBUG - 2011-04-23 22:29:40 --> Total execution time: 0.0208
DEBUG - 2011-04-23 22:35:43 --> Config Class Initialized
DEBUG - 2011-04-23 22:35:43 --> Hooks Class Initialized
DEBUG - 2011-04-23 22:35:43 --> Utf8 Class Initialized
DEBUG - 2011-04-23 22:35:43 --> UTF-8 Support Enabled
DEBUG - 2011-04-23 22:35:43 --> URI Class Initialized
DEBUG - 2011-04-23 22:35:43 --> Router Class Initialized
DEBUG - 2011-04-23 22:35:43 --> Output Class Initialized
DEBUG - 2011-04-23 22:35:43 --> Input Class Initialized
DEBUG - 2011-04-23 22:35:43 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-23 22:35:43 --> Language Class Initialized
DEBUG - 2011-04-23 22:35:43 --> Loader Class Initialized
DEBUG - 2011-04-23 22:35:43 --> Controller Class Initialized
ERROR - 2011-04-23 22:35:43 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-04-23 22:35:43 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-04-23 22:35:43 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-04-23 22:35:43 --> Model Class Initialized
DEBUG - 2011-04-23 22:35:43 --> Model Class Initialized
DEBUG - 2011-04-23 22:35:43 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-23 22:35:43 --> Database Driver Class Initialized
DEBUG - 2011-04-23 22:35:43 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-04-23 22:35:43 --> Helper loaded: url_helper
DEBUG - 2011-04-23 22:35:43 --> File loaded: application/views/common/header.php
DEBUG - 2011-04-23 22:35:43 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-04-23 22:35:43 --> File loaded: application/views/common/footer.php
DEBUG - 2011-04-23 22:35:43 --> File loaded: application/views/layout/main.php
DEBUG - 2011-04-23 22:35:43 --> Final output sent to browser
DEBUG - 2011-04-23 22:35:43 --> Total execution time: 0.1456
DEBUG - 2011-04-23 22:35:43 --> Config Class Initialized
DEBUG - 2011-04-23 22:35:43 --> Hooks Class Initialized
DEBUG - 2011-04-23 22:35:43 --> Utf8 Class Initialized
DEBUG - 2011-04-23 22:35:43 --> UTF-8 Support Enabled
DEBUG - 2011-04-23 22:35:43 --> URI Class Initialized
DEBUG - 2011-04-23 22:35:43 --> Router Class Initialized
DEBUG - 2011-04-23 22:35:43 --> Output Class Initialized
DEBUG - 2011-04-23 22:35:43 --> Input Class Initialized
DEBUG - 2011-04-23 22:35:43 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-23 22:35:43 --> Language Class Initialized
DEBUG - 2011-04-23 22:35:43 --> Loader Class Initialized
DEBUG - 2011-04-23 22:35:43 --> Controller Class Initialized
DEBUG - 2011-04-23 22:35:43 --> Model Class Initialized
DEBUG - 2011-04-23 22:35:43 --> Model Class Initialized
DEBUG - 2011-04-23 22:35:43 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-23 22:35:43 --> Database Driver Class Initialized
DEBUG - 2011-04-23 22:35:44 --> Final output sent to browser
DEBUG - 2011-04-23 22:35:44 --> Total execution time: 0.8587
DEBUG - 2011-04-23 22:59:34 --> Config Class Initialized
DEBUG - 2011-04-23 22:59:34 --> Hooks Class Initialized
DEBUG - 2011-04-23 22:59:34 --> Utf8 Class Initialized
DEBUG - 2011-04-23 22:59:34 --> UTF-8 Support Enabled
DEBUG - 2011-04-23 22:59:34 --> URI Class Initialized
DEBUG - 2011-04-23 22:59:34 --> Router Class Initialized
DEBUG - 2011-04-23 22:59:34 --> Output Class Initialized
DEBUG - 2011-04-23 22:59:34 --> Input Class Initialized
DEBUG - 2011-04-23 22:59:34 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-23 22:59:34 --> Language Class Initialized
DEBUG - 2011-04-23 22:59:34 --> Loader Class Initialized
DEBUG - 2011-04-23 22:59:34 --> Controller Class Initialized
ERROR - 2011-04-23 22:59:34 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-04-23 22:59:34 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-04-23 22:59:34 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-04-23 22:59:34 --> Model Class Initialized
DEBUG - 2011-04-23 22:59:34 --> Model Class Initialized
DEBUG - 2011-04-23 22:59:34 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-23 22:59:34 --> Database Driver Class Initialized
DEBUG - 2011-04-23 22:59:34 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-04-23 22:59:34 --> Helper loaded: url_helper
DEBUG - 2011-04-23 22:59:34 --> File loaded: application/views/common/header.php
DEBUG - 2011-04-23 22:59:34 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-04-23 22:59:34 --> File loaded: application/views/common/footer.php
DEBUG - 2011-04-23 22:59:34 --> File loaded: application/views/layout/main.php
DEBUG - 2011-04-23 22:59:34 --> Final output sent to browser
DEBUG - 2011-04-23 22:59:34 --> Total execution time: 0.1136
DEBUG - 2011-04-23 22:59:36 --> Config Class Initialized
DEBUG - 2011-04-23 22:59:36 --> Hooks Class Initialized
DEBUG - 2011-04-23 22:59:36 --> Utf8 Class Initialized
DEBUG - 2011-04-23 22:59:36 --> UTF-8 Support Enabled
DEBUG - 2011-04-23 22:59:36 --> URI Class Initialized
DEBUG - 2011-04-23 22:59:36 --> Router Class Initialized
DEBUG - 2011-04-23 22:59:36 --> Output Class Initialized
DEBUG - 2011-04-23 22:59:36 --> Input Class Initialized
DEBUG - 2011-04-23 22:59:36 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-23 22:59:36 --> Language Class Initialized
DEBUG - 2011-04-23 22:59:36 --> Loader Class Initialized
DEBUG - 2011-04-23 22:59:36 --> Controller Class Initialized
DEBUG - 2011-04-23 22:59:36 --> Model Class Initialized
DEBUG - 2011-04-23 22:59:36 --> Model Class Initialized
DEBUG - 2011-04-23 22:59:36 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-23 22:59:36 --> Database Driver Class Initialized
DEBUG - 2011-04-23 22:59:36 --> Config Class Initialized
DEBUG - 2011-04-23 22:59:36 --> Hooks Class Initialized
DEBUG - 2011-04-23 22:59:36 --> Utf8 Class Initialized
DEBUG - 2011-04-23 22:59:36 --> UTF-8 Support Enabled
DEBUG - 2011-04-23 22:59:36 --> URI Class Initialized
DEBUG - 2011-04-23 22:59:36 --> Router Class Initialized
DEBUG - 2011-04-23 22:59:36 --> Output Class Initialized
DEBUG - 2011-04-23 22:59:36 --> Input Class Initialized
DEBUG - 2011-04-23 22:59:36 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-23 22:59:36 --> Language Class Initialized
DEBUG - 2011-04-23 22:59:36 --> Loader Class Initialized
DEBUG - 2011-04-23 22:59:36 --> Controller Class Initialized
ERROR - 2011-04-23 22:59:36 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-04-23 22:59:36 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-04-23 22:59:36 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-04-23 22:59:36 --> Model Class Initialized
DEBUG - 2011-04-23 22:59:36 --> Model Class Initialized
DEBUG - 2011-04-23 22:59:36 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-23 22:59:36 --> Database Driver Class Initialized
DEBUG - 2011-04-23 22:59:36 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-04-23 22:59:36 --> Helper loaded: url_helper
DEBUG - 2011-04-23 22:59:36 --> File loaded: application/views/common/header.php
DEBUG - 2011-04-23 22:59:36 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-04-23 22:59:36 --> File loaded: application/views/common/footer.php
DEBUG - 2011-04-23 22:59:36 --> File loaded: application/views/layout/main.php
DEBUG - 2011-04-23 22:59:36 --> Final output sent to browser
DEBUG - 2011-04-23 22:59:36 --> Total execution time: 0.0293
DEBUG - 2011-04-23 22:59:36 --> Final output sent to browser
DEBUG - 2011-04-23 22:59:36 --> Total execution time: 0.7514
DEBUG - 2011-04-23 22:59:45 --> Config Class Initialized
DEBUG - 2011-04-23 22:59:45 --> Hooks Class Initialized
DEBUG - 2011-04-23 22:59:45 --> Utf8 Class Initialized
DEBUG - 2011-04-23 22:59:45 --> UTF-8 Support Enabled
DEBUG - 2011-04-23 22:59:45 --> URI Class Initialized
DEBUG - 2011-04-23 22:59:45 --> Router Class Initialized
DEBUG - 2011-04-23 22:59:45 --> Output Class Initialized
DEBUG - 2011-04-23 22:59:45 --> Input Class Initialized
DEBUG - 2011-04-23 22:59:45 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-23 22:59:45 --> Language Class Initialized
DEBUG - 2011-04-23 22:59:45 --> Loader Class Initialized
DEBUG - 2011-04-23 22:59:45 --> Controller Class Initialized
ERROR - 2011-04-23 22:59:45 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-04-23 22:59:45 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-04-23 22:59:45 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-04-23 22:59:45 --> Model Class Initialized
DEBUG - 2011-04-23 22:59:45 --> Model Class Initialized
DEBUG - 2011-04-23 22:59:45 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-23 22:59:45 --> Database Driver Class Initialized
DEBUG - 2011-04-23 22:59:45 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-04-23 22:59:45 --> Helper loaded: url_helper
DEBUG - 2011-04-23 22:59:45 --> File loaded: application/views/common/header.php
DEBUG - 2011-04-23 22:59:45 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-04-23 22:59:45 --> File loaded: application/views/common/footer.php
DEBUG - 2011-04-23 22:59:45 --> File loaded: application/views/layout/main.php
DEBUG - 2011-04-23 22:59:45 --> Final output sent to browser
DEBUG - 2011-04-23 22:59:45 --> Total execution time: 0.0283
DEBUG - 2011-04-23 22:59:46 --> Config Class Initialized
DEBUG - 2011-04-23 22:59:46 --> Hooks Class Initialized
DEBUG - 2011-04-23 22:59:46 --> Utf8 Class Initialized
DEBUG - 2011-04-23 22:59:46 --> UTF-8 Support Enabled
DEBUG - 2011-04-23 22:59:46 --> URI Class Initialized
DEBUG - 2011-04-23 22:59:46 --> Router Class Initialized
DEBUG - 2011-04-23 22:59:46 --> Output Class Initialized
DEBUG - 2011-04-23 22:59:46 --> Input Class Initialized
DEBUG - 2011-04-23 22:59:46 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-23 22:59:46 --> Language Class Initialized
DEBUG - 2011-04-23 22:59:46 --> Loader Class Initialized
DEBUG - 2011-04-23 22:59:46 --> Controller Class Initialized
DEBUG - 2011-04-23 22:59:46 --> Model Class Initialized
DEBUG - 2011-04-23 22:59:46 --> Model Class Initialized
DEBUG - 2011-04-23 22:59:46 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-23 22:59:46 --> Database Driver Class Initialized
DEBUG - 2011-04-23 22:59:46 --> Config Class Initialized
DEBUG - 2011-04-23 22:59:46 --> Hooks Class Initialized
DEBUG - 2011-04-23 22:59:46 --> Utf8 Class Initialized
DEBUG - 2011-04-23 22:59:46 --> UTF-8 Support Enabled
DEBUG - 2011-04-23 22:59:46 --> URI Class Initialized
DEBUG - 2011-04-23 22:59:46 --> Router Class Initialized
DEBUG - 2011-04-23 22:59:46 --> Output Class Initialized
DEBUG - 2011-04-23 22:59:46 --> Input Class Initialized
DEBUG - 2011-04-23 22:59:46 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-23 22:59:46 --> Language Class Initialized
DEBUG - 2011-04-23 22:59:46 --> Loader Class Initialized
DEBUG - 2011-04-23 22:59:46 --> Controller Class Initialized
ERROR - 2011-04-23 22:59:46 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-04-23 22:59:46 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-04-23 22:59:46 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-04-23 22:59:46 --> Model Class Initialized
DEBUG - 2011-04-23 22:59:46 --> Model Class Initialized
DEBUG - 2011-04-23 22:59:46 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-23 22:59:46 --> Database Driver Class Initialized
DEBUG - 2011-04-23 22:59:46 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-04-23 22:59:46 --> Helper loaded: url_helper
DEBUG - 2011-04-23 22:59:46 --> File loaded: application/views/common/header.php
DEBUG - 2011-04-23 22:59:46 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-04-23 22:59:46 --> File loaded: application/views/common/footer.php
DEBUG - 2011-04-23 22:59:46 --> File loaded: application/views/layout/main.php
DEBUG - 2011-04-23 22:59:46 --> Final output sent to browser
DEBUG - 2011-04-23 22:59:46 --> Total execution time: 0.0283
DEBUG - 2011-04-23 22:59:46 --> Final output sent to browser
DEBUG - 2011-04-23 22:59:46 --> Total execution time: 0.5524
DEBUG - 2011-04-23 23:00:08 --> Config Class Initialized
DEBUG - 2011-04-23 23:00:08 --> Hooks Class Initialized
DEBUG - 2011-04-23 23:00:08 --> Utf8 Class Initialized
DEBUG - 2011-04-23 23:00:08 --> UTF-8 Support Enabled
DEBUG - 2011-04-23 23:00:08 --> URI Class Initialized
DEBUG - 2011-04-23 23:00:08 --> Router Class Initialized
DEBUG - 2011-04-23 23:00:08 --> Output Class Initialized
DEBUG - 2011-04-23 23:00:08 --> Input Class Initialized
DEBUG - 2011-04-23 23:00:08 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-23 23:00:08 --> Language Class Initialized
DEBUG - 2011-04-23 23:00:08 --> Loader Class Initialized
DEBUG - 2011-04-23 23:00:08 --> Controller Class Initialized
ERROR - 2011-04-23 23:00:08 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-04-23 23:00:08 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-04-23 23:00:08 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-04-23 23:00:08 --> Model Class Initialized
DEBUG - 2011-04-23 23:00:08 --> Model Class Initialized
DEBUG - 2011-04-23 23:00:08 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-23 23:00:08 --> Database Driver Class Initialized
DEBUG - 2011-04-23 23:00:08 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-04-23 23:00:08 --> Helper loaded: url_helper
DEBUG - 2011-04-23 23:00:08 --> File loaded: application/views/common/header.php
DEBUG - 2011-04-23 23:00:08 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-04-23 23:00:08 --> File loaded: application/views/common/footer.php
DEBUG - 2011-04-23 23:00:08 --> File loaded: application/views/layout/main.php
DEBUG - 2011-04-23 23:00:08 --> Final output sent to browser
DEBUG - 2011-04-23 23:00:08 --> Total execution time: 0.0371
DEBUG - 2011-04-23 23:00:10 --> Config Class Initialized
DEBUG - 2011-04-23 23:00:10 --> Hooks Class Initialized
DEBUG - 2011-04-23 23:00:10 --> Utf8 Class Initialized
DEBUG - 2011-04-23 23:00:10 --> UTF-8 Support Enabled
DEBUG - 2011-04-23 23:00:10 --> URI Class Initialized
DEBUG - 2011-04-23 23:00:10 --> Router Class Initialized
DEBUG - 2011-04-23 23:00:10 --> Output Class Initialized
DEBUG - 2011-04-23 23:00:10 --> Input Class Initialized
DEBUG - 2011-04-23 23:00:10 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-23 23:00:10 --> Language Class Initialized
DEBUG - 2011-04-23 23:00:10 --> Loader Class Initialized
DEBUG - 2011-04-23 23:00:10 --> Controller Class Initialized
DEBUG - 2011-04-23 23:00:10 --> Model Class Initialized
DEBUG - 2011-04-23 23:00:10 --> Model Class Initialized
DEBUG - 2011-04-23 23:00:10 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-23 23:00:10 --> Database Driver Class Initialized
DEBUG - 2011-04-23 23:00:10 --> Final output sent to browser
DEBUG - 2011-04-23 23:00:10 --> Total execution time: 0.4926
DEBUG - 2011-04-23 23:00:11 --> Config Class Initialized
DEBUG - 2011-04-23 23:00:11 --> Hooks Class Initialized
DEBUG - 2011-04-23 23:00:11 --> Utf8 Class Initialized
DEBUG - 2011-04-23 23:00:11 --> UTF-8 Support Enabled
DEBUG - 2011-04-23 23:00:11 --> URI Class Initialized
DEBUG - 2011-04-23 23:00:11 --> Router Class Initialized
DEBUG - 2011-04-23 23:00:11 --> Output Class Initialized
DEBUG - 2011-04-23 23:00:11 --> Input Class Initialized
DEBUG - 2011-04-23 23:00:11 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-23 23:00:11 --> Language Class Initialized
DEBUG - 2011-04-23 23:00:11 --> Loader Class Initialized
DEBUG - 2011-04-23 23:00:11 --> Controller Class Initialized
ERROR - 2011-04-23 23:00:11 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-04-23 23:00:11 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-04-23 23:00:11 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-04-23 23:00:11 --> Model Class Initialized
DEBUG - 2011-04-23 23:00:11 --> Model Class Initialized
DEBUG - 2011-04-23 23:00:11 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-23 23:00:11 --> Database Driver Class Initialized
DEBUG - 2011-04-23 23:00:11 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-04-23 23:00:11 --> Helper loaded: url_helper
DEBUG - 2011-04-23 23:00:11 --> File loaded: application/views/common/header.php
DEBUG - 2011-04-23 23:00:11 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-04-23 23:00:11 --> File loaded: application/views/common/footer.php
DEBUG - 2011-04-23 23:00:11 --> File loaded: application/views/layout/main.php
DEBUG - 2011-04-23 23:00:11 --> Final output sent to browser
DEBUG - 2011-04-23 23:00:11 --> Total execution time: 0.0294
DEBUG - 2011-04-23 23:01:12 --> Config Class Initialized
DEBUG - 2011-04-23 23:01:12 --> Hooks Class Initialized
DEBUG - 2011-04-23 23:01:12 --> Utf8 Class Initialized
DEBUG - 2011-04-23 23:01:12 --> UTF-8 Support Enabled
DEBUG - 2011-04-23 23:01:12 --> URI Class Initialized
DEBUG - 2011-04-23 23:01:12 --> Router Class Initialized
DEBUG - 2011-04-23 23:01:12 --> Output Class Initialized
DEBUG - 2011-04-23 23:01:12 --> Input Class Initialized
DEBUG - 2011-04-23 23:01:12 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-23 23:01:12 --> Language Class Initialized
DEBUG - 2011-04-23 23:01:12 --> Loader Class Initialized
DEBUG - 2011-04-23 23:01:12 --> Controller Class Initialized
ERROR - 2011-04-23 23:01:12 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-04-23 23:01:12 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-04-23 23:01:12 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-04-23 23:01:12 --> Model Class Initialized
DEBUG - 2011-04-23 23:01:12 --> Model Class Initialized
DEBUG - 2011-04-23 23:01:12 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-23 23:01:12 --> Database Driver Class Initialized
DEBUG - 2011-04-23 23:01:12 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-04-23 23:01:12 --> Helper loaded: url_helper
DEBUG - 2011-04-23 23:01:12 --> File loaded: application/views/common/header.php
DEBUG - 2011-04-23 23:01:12 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-04-23 23:01:12 --> File loaded: application/views/common/footer.php
DEBUG - 2011-04-23 23:01:12 --> File loaded: application/views/layout/main.php
DEBUG - 2011-04-23 23:01:12 --> Final output sent to browser
DEBUG - 2011-04-23 23:01:12 --> Total execution time: 0.0282
DEBUG - 2011-04-23 23:01:13 --> Config Class Initialized
DEBUG - 2011-04-23 23:01:13 --> Hooks Class Initialized
DEBUG - 2011-04-23 23:01:13 --> Utf8 Class Initialized
DEBUG - 2011-04-23 23:01:13 --> UTF-8 Support Enabled
DEBUG - 2011-04-23 23:01:13 --> URI Class Initialized
DEBUG - 2011-04-23 23:01:13 --> Router Class Initialized
DEBUG - 2011-04-23 23:01:13 --> Output Class Initialized
DEBUG - 2011-04-23 23:01:13 --> Input Class Initialized
DEBUG - 2011-04-23 23:01:13 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-23 23:01:13 --> Language Class Initialized
DEBUG - 2011-04-23 23:01:13 --> Loader Class Initialized
DEBUG - 2011-04-23 23:01:13 --> Controller Class Initialized
DEBUG - 2011-04-23 23:01:13 --> Model Class Initialized
DEBUG - 2011-04-23 23:01:13 --> Model Class Initialized
DEBUG - 2011-04-23 23:01:13 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-23 23:01:13 --> Database Driver Class Initialized
DEBUG - 2011-04-23 23:01:13 --> Final output sent to browser
DEBUG - 2011-04-23 23:01:13 --> Total execution time: 0.5908
DEBUG - 2011-04-23 23:01:14 --> Config Class Initialized
DEBUG - 2011-04-23 23:01:14 --> Hooks Class Initialized
DEBUG - 2011-04-23 23:01:14 --> Utf8 Class Initialized
DEBUG - 2011-04-23 23:01:14 --> UTF-8 Support Enabled
DEBUG - 2011-04-23 23:01:14 --> URI Class Initialized
DEBUG - 2011-04-23 23:01:14 --> Router Class Initialized
DEBUG - 2011-04-23 23:01:14 --> Output Class Initialized
DEBUG - 2011-04-23 23:01:14 --> Input Class Initialized
DEBUG - 2011-04-23 23:01:14 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-23 23:01:14 --> Language Class Initialized
DEBUG - 2011-04-23 23:01:14 --> Loader Class Initialized
DEBUG - 2011-04-23 23:01:14 --> Controller Class Initialized
ERROR - 2011-04-23 23:01:14 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-04-23 23:01:14 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-04-23 23:01:14 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-04-23 23:01:14 --> Model Class Initialized
DEBUG - 2011-04-23 23:01:14 --> Model Class Initialized
DEBUG - 2011-04-23 23:01:14 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-23 23:01:14 --> Database Driver Class Initialized
DEBUG - 2011-04-23 23:01:14 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-04-23 23:01:14 --> Helper loaded: url_helper
DEBUG - 2011-04-23 23:01:14 --> File loaded: application/views/common/header.php
DEBUG - 2011-04-23 23:01:14 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-04-23 23:01:14 --> File loaded: application/views/common/footer.php
DEBUG - 2011-04-23 23:01:14 --> File loaded: application/views/layout/main.php
DEBUG - 2011-04-23 23:01:14 --> Final output sent to browser
DEBUG - 2011-04-23 23:01:14 --> Total execution time: 0.0315
DEBUG - 2011-04-23 23:01:22 --> Config Class Initialized
DEBUG - 2011-04-23 23:01:22 --> Hooks Class Initialized
DEBUG - 2011-04-23 23:01:22 --> Utf8 Class Initialized
DEBUG - 2011-04-23 23:01:22 --> UTF-8 Support Enabled
DEBUG - 2011-04-23 23:01:22 --> URI Class Initialized
DEBUG - 2011-04-23 23:01:22 --> Router Class Initialized
DEBUG - 2011-04-23 23:01:22 --> Output Class Initialized
DEBUG - 2011-04-23 23:01:22 --> Input Class Initialized
DEBUG - 2011-04-23 23:01:22 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-23 23:01:22 --> Language Class Initialized
DEBUG - 2011-04-23 23:01:22 --> Loader Class Initialized
DEBUG - 2011-04-23 23:01:22 --> Controller Class Initialized
ERROR - 2011-04-23 23:01:22 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-04-23 23:01:22 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-04-23 23:01:22 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-04-23 23:01:22 --> Model Class Initialized
DEBUG - 2011-04-23 23:01:22 --> Model Class Initialized
DEBUG - 2011-04-23 23:01:22 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-23 23:01:22 --> Database Driver Class Initialized
DEBUG - 2011-04-23 23:01:22 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-04-23 23:01:22 --> Helper loaded: url_helper
DEBUG - 2011-04-23 23:01:22 --> File loaded: application/views/common/header.php
DEBUG - 2011-04-23 23:01:22 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-04-23 23:01:22 --> File loaded: application/views/common/footer.php
DEBUG - 2011-04-23 23:01:22 --> File loaded: application/views/layout/main.php
DEBUG - 2011-04-23 23:01:22 --> Final output sent to browser
DEBUG - 2011-04-23 23:01:22 --> Total execution time: 0.0314
DEBUG - 2011-04-23 23:01:23 --> Config Class Initialized
DEBUG - 2011-04-23 23:01:23 --> Hooks Class Initialized
DEBUG - 2011-04-23 23:01:23 --> Utf8 Class Initialized
DEBUG - 2011-04-23 23:01:23 --> UTF-8 Support Enabled
DEBUG - 2011-04-23 23:01:23 --> URI Class Initialized
DEBUG - 2011-04-23 23:01:23 --> Router Class Initialized
DEBUG - 2011-04-23 23:01:23 --> Output Class Initialized
DEBUG - 2011-04-23 23:01:23 --> Input Class Initialized
DEBUG - 2011-04-23 23:01:23 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-23 23:01:23 --> Language Class Initialized
DEBUG - 2011-04-23 23:01:23 --> Loader Class Initialized
DEBUG - 2011-04-23 23:01:23 --> Controller Class Initialized
DEBUG - 2011-04-23 23:01:23 --> Model Class Initialized
DEBUG - 2011-04-23 23:01:23 --> Model Class Initialized
DEBUG - 2011-04-23 23:01:23 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-23 23:01:23 --> Database Driver Class Initialized
DEBUG - 2011-04-23 23:01:23 --> Final output sent to browser
DEBUG - 2011-04-23 23:01:23 --> Total execution time: 0.5500
DEBUG - 2011-04-23 23:01:34 --> Config Class Initialized
DEBUG - 2011-04-23 23:01:34 --> Hooks Class Initialized
DEBUG - 2011-04-23 23:01:34 --> Utf8 Class Initialized
DEBUG - 2011-04-23 23:01:34 --> UTF-8 Support Enabled
DEBUG - 2011-04-23 23:01:34 --> URI Class Initialized
DEBUG - 2011-04-23 23:01:34 --> Router Class Initialized
DEBUG - 2011-04-23 23:01:34 --> Output Class Initialized
DEBUG - 2011-04-23 23:01:34 --> Input Class Initialized
DEBUG - 2011-04-23 23:01:34 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-23 23:01:34 --> Language Class Initialized
DEBUG - 2011-04-23 23:01:34 --> Loader Class Initialized
DEBUG - 2011-04-23 23:01:34 --> Controller Class Initialized
ERROR - 2011-04-23 23:01:34 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-04-23 23:01:34 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-04-23 23:01:34 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-04-23 23:01:34 --> Model Class Initialized
DEBUG - 2011-04-23 23:01:34 --> Model Class Initialized
DEBUG - 2011-04-23 23:01:34 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-23 23:01:34 --> Database Driver Class Initialized
DEBUG - 2011-04-23 23:01:34 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-04-23 23:01:34 --> Helper loaded: url_helper
DEBUG - 2011-04-23 23:01:34 --> File loaded: application/views/common/header.php
DEBUG - 2011-04-23 23:01:34 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-04-23 23:01:34 --> File loaded: application/views/common/footer.php
DEBUG - 2011-04-23 23:01:34 --> File loaded: application/views/layout/main.php
DEBUG - 2011-04-23 23:01:34 --> Final output sent to browser
DEBUG - 2011-04-23 23:01:34 --> Total execution time: 0.0287
DEBUG - 2011-04-23 23:01:44 --> Config Class Initialized
DEBUG - 2011-04-23 23:01:44 --> Hooks Class Initialized
DEBUG - 2011-04-23 23:01:44 --> Utf8 Class Initialized
DEBUG - 2011-04-23 23:01:44 --> UTF-8 Support Enabled
DEBUG - 2011-04-23 23:01:44 --> URI Class Initialized
DEBUG - 2011-04-23 23:01:44 --> Router Class Initialized
DEBUG - 2011-04-23 23:01:44 --> Output Class Initialized
DEBUG - 2011-04-23 23:01:44 --> Input Class Initialized
DEBUG - 2011-04-23 23:01:44 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-23 23:01:44 --> Language Class Initialized
DEBUG - 2011-04-23 23:01:44 --> Loader Class Initialized
DEBUG - 2011-04-23 23:01:44 --> Controller Class Initialized
DEBUG - 2011-04-23 23:01:44 --> Model Class Initialized
DEBUG - 2011-04-23 23:01:44 --> Model Class Initialized
DEBUG - 2011-04-23 23:01:44 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-23 23:01:44 --> Database Driver Class Initialized
DEBUG - 2011-04-23 23:01:44 --> Final output sent to browser
DEBUG - 2011-04-23 23:01:44 --> Total execution time: 0.5787
DEBUG - 2011-04-23 23:01:56 --> Config Class Initialized
DEBUG - 2011-04-23 23:01:56 --> Hooks Class Initialized
DEBUG - 2011-04-23 23:01:56 --> Utf8 Class Initialized
DEBUG - 2011-04-23 23:01:56 --> UTF-8 Support Enabled
DEBUG - 2011-04-23 23:01:56 --> URI Class Initialized
DEBUG - 2011-04-23 23:01:56 --> Router Class Initialized
DEBUG - 2011-04-23 23:01:56 --> Output Class Initialized
DEBUG - 2011-04-23 23:01:56 --> Input Class Initialized
DEBUG - 2011-04-23 23:01:56 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-23 23:01:56 --> Language Class Initialized
DEBUG - 2011-04-23 23:01:56 --> Loader Class Initialized
DEBUG - 2011-04-23 23:01:56 --> Controller Class Initialized
ERROR - 2011-04-23 23:01:56 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-04-23 23:01:56 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-04-23 23:01:56 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-04-23 23:01:56 --> Model Class Initialized
DEBUG - 2011-04-23 23:01:56 --> Model Class Initialized
DEBUG - 2011-04-23 23:01:56 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-23 23:01:56 --> Database Driver Class Initialized
DEBUG - 2011-04-23 23:01:56 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-04-23 23:01:56 --> Helper loaded: url_helper
DEBUG - 2011-04-23 23:01:56 --> File loaded: application/views/common/header.php
DEBUG - 2011-04-23 23:01:56 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-04-23 23:01:56 --> File loaded: application/views/common/footer.php
DEBUG - 2011-04-23 23:01:56 --> File loaded: application/views/layout/main.php
DEBUG - 2011-04-23 23:01:56 --> Final output sent to browser
DEBUG - 2011-04-23 23:01:56 --> Total execution time: 0.0289
DEBUG - 2011-04-23 23:01:57 --> Config Class Initialized
DEBUG - 2011-04-23 23:01:57 --> Hooks Class Initialized
DEBUG - 2011-04-23 23:01:57 --> Utf8 Class Initialized
DEBUG - 2011-04-23 23:01:57 --> UTF-8 Support Enabled
DEBUG - 2011-04-23 23:01:57 --> URI Class Initialized
DEBUG - 2011-04-23 23:01:57 --> Router Class Initialized
DEBUG - 2011-04-23 23:01:57 --> Output Class Initialized
DEBUG - 2011-04-23 23:01:57 --> Input Class Initialized
DEBUG - 2011-04-23 23:01:57 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-23 23:01:57 --> Language Class Initialized
DEBUG - 2011-04-23 23:01:57 --> Loader Class Initialized
DEBUG - 2011-04-23 23:01:57 --> Controller Class Initialized
DEBUG - 2011-04-23 23:01:57 --> Model Class Initialized
DEBUG - 2011-04-23 23:01:57 --> Model Class Initialized
DEBUG - 2011-04-23 23:01:57 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-23 23:01:57 --> Database Driver Class Initialized
DEBUG - 2011-04-23 23:01:58 --> Final output sent to browser
DEBUG - 2011-04-23 23:01:58 --> Total execution time: 0.5741
DEBUG - 2011-04-23 23:34:29 --> Config Class Initialized
DEBUG - 2011-04-23 23:34:29 --> Hooks Class Initialized
DEBUG - 2011-04-23 23:34:29 --> Utf8 Class Initialized
DEBUG - 2011-04-23 23:34:29 --> UTF-8 Support Enabled
DEBUG - 2011-04-23 23:34:29 --> URI Class Initialized
DEBUG - 2011-04-23 23:34:29 --> Router Class Initialized
ERROR - 2011-04-23 23:34:29 --> 404 Page Not Found --> robots.txt
DEBUG - 2011-04-23 23:51:55 --> Config Class Initialized
DEBUG - 2011-04-23 23:51:55 --> Hooks Class Initialized
DEBUG - 2011-04-23 23:51:55 --> Utf8 Class Initialized
DEBUG - 2011-04-23 23:51:55 --> UTF-8 Support Enabled
DEBUG - 2011-04-23 23:51:55 --> URI Class Initialized
DEBUG - 2011-04-23 23:51:55 --> Router Class Initialized
ERROR - 2011-04-23 23:51:55 --> 404 Page Not Found --> robots.txt
DEBUG - 2011-04-23 23:52:51 --> Config Class Initialized
DEBUG - 2011-04-23 23:52:51 --> Hooks Class Initialized
DEBUG - 2011-04-23 23:52:51 --> Utf8 Class Initialized
DEBUG - 2011-04-23 23:52:51 --> UTF-8 Support Enabled
DEBUG - 2011-04-23 23:52:51 --> URI Class Initialized
DEBUG - 2011-04-23 23:52:51 --> Router Class Initialized
DEBUG - 2011-04-23 23:52:51 --> Output Class Initialized
DEBUG - 2011-04-23 23:52:51 --> Input Class Initialized
DEBUG - 2011-04-23 23:52:51 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-23 23:52:51 --> Language Class Initialized
DEBUG - 2011-04-23 23:52:51 --> Loader Class Initialized
DEBUG - 2011-04-23 23:52:51 --> Controller Class Initialized
ERROR - 2011-04-23 23:52:51 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-04-23 23:52:51 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-04-23 23:52:51 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-04-23 23:52:51 --> Model Class Initialized
DEBUG - 2011-04-23 23:52:51 --> Model Class Initialized
DEBUG - 2011-04-23 23:52:51 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-23 23:52:51 --> Database Driver Class Initialized
DEBUG - 2011-04-23 23:52:51 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-04-23 23:52:51 --> Helper loaded: url_helper
DEBUG - 2011-04-23 23:52:51 --> File loaded: application/views/common/header.php
DEBUG - 2011-04-23 23:52:51 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-04-23 23:52:51 --> File loaded: application/views/common/footer.php
DEBUG - 2011-04-23 23:52:51 --> File loaded: application/views/layout/main.php
DEBUG - 2011-04-23 23:52:51 --> Final output sent to browser
DEBUG - 2011-04-23 23:52:51 --> Total execution time: 0.4841

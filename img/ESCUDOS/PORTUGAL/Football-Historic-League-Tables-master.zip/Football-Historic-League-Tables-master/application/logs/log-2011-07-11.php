<?php  if ( ! defined('BASEPATH')) exit('No direct script access allowed'); ?>

DEBUG - 2011-07-11 00:52:51 --> Config Class Initialized
DEBUG - 2011-07-11 00:52:51 --> Hooks Class Initialized
DEBUG - 2011-07-11 00:52:51 --> Utf8 Class Initialized
DEBUG - 2011-07-11 00:52:51 --> UTF-8 Support Enabled
DEBUG - 2011-07-11 00:52:51 --> URI Class Initialized
DEBUG - 2011-07-11 00:52:51 --> Router Class Initialized
DEBUG - 2011-07-11 00:52:51 --> No URI present. Default controller set.
DEBUG - 2011-07-11 00:52:51 --> Output Class Initialized
DEBUG - 2011-07-11 00:52:51 --> Input Class Initialized
DEBUG - 2011-07-11 00:52:51 --> Global POST and COOKIE data sanitized
DEBUG - 2011-07-11 00:52:51 --> Language Class Initialized
DEBUG - 2011-07-11 00:52:51 --> Loader Class Initialized
DEBUG - 2011-07-11 00:52:51 --> Controller Class Initialized
DEBUG - 2011-07-11 00:52:51 --> File loaded: application/views/splash/main.php
DEBUG - 2011-07-11 00:52:51 --> Helper loaded: url_helper
DEBUG - 2011-07-11 00:52:51 --> File loaded: application/views/common/header.php
DEBUG - 2011-07-11 00:52:51 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-07-11 00:52:51 --> File loaded: application/views/common/footer.php
DEBUG - 2011-07-11 00:52:51 --> File loaded: application/views/layout/main.php
DEBUG - 2011-07-11 00:52:51 --> Final output sent to browser
DEBUG - 2011-07-11 00:52:51 --> Total execution time: 0.3959
DEBUG - 2011-07-11 03:25:40 --> Config Class Initialized
DEBUG - 2011-07-11 03:25:40 --> Hooks Class Initialized
DEBUG - 2011-07-11 03:25:40 --> Utf8 Class Initialized
DEBUG - 2011-07-11 03:25:40 --> UTF-8 Support Enabled
DEBUG - 2011-07-11 03:25:40 --> URI Class Initialized
DEBUG - 2011-07-11 03:25:40 --> Router Class Initialized
DEBUG - 2011-07-11 03:25:41 --> No URI present. Default controller set.
DEBUG - 2011-07-11 03:25:41 --> Output Class Initialized
DEBUG - 2011-07-11 03:25:41 --> Input Class Initialized
DEBUG - 2011-07-11 03:25:41 --> Global POST and COOKIE data sanitized
DEBUG - 2011-07-11 03:25:41 --> Language Class Initialized
DEBUG - 2011-07-11 03:25:41 --> Loader Class Initialized
DEBUG - 2011-07-11 03:25:41 --> Controller Class Initialized
DEBUG - 2011-07-11 03:25:41 --> File loaded: application/views/splash/main.php
DEBUG - 2011-07-11 03:25:41 --> Helper loaded: url_helper
DEBUG - 2011-07-11 03:25:41 --> File loaded: application/views/common/header.php
DEBUG - 2011-07-11 03:25:41 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-07-11 03:25:41 --> File loaded: application/views/common/footer.php
DEBUG - 2011-07-11 03:25:41 --> File loaded: application/views/layout/main.php
DEBUG - 2011-07-11 03:25:41 --> Final output sent to browser
DEBUG - 2011-07-11 03:25:41 --> Total execution time: 0.3388
DEBUG - 2011-07-11 03:26:28 --> Config Class Initialized
DEBUG - 2011-07-11 03:26:28 --> Hooks Class Initialized
DEBUG - 2011-07-11 03:26:28 --> Utf8 Class Initialized
DEBUG - 2011-07-11 03:26:28 --> UTF-8 Support Enabled
DEBUG - 2011-07-11 03:26:28 --> URI Class Initialized
DEBUG - 2011-07-11 03:26:28 --> Router Class Initialized
DEBUG - 2011-07-11 03:26:28 --> Output Class Initialized
DEBUG - 2011-07-11 03:26:28 --> Input Class Initialized
DEBUG - 2011-07-11 03:26:28 --> Global POST and COOKIE data sanitized
DEBUG - 2011-07-11 03:26:28 --> Language Class Initialized
DEBUG - 2011-07-11 03:26:28 --> Loader Class Initialized
DEBUG - 2011-07-11 03:26:28 --> Controller Class Initialized
DEBUG - 2011-07-11 03:26:28 --> Model Class Initialized
DEBUG - 2011-07-11 03:26:28 --> Model Class Initialized
DEBUG - 2011-07-11 03:26:28 --> Model Class Initialized
DEBUG - 2011-07-11 03:26:28 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-07-11 03:26:28 --> Database Driver Class Initialized
DEBUG - 2011-07-11 03:26:31 --> File loaded: application/views/table/main.php
DEBUG - 2011-07-11 03:26:31 --> Helper loaded: url_helper
DEBUG - 2011-07-11 03:26:31 --> File loaded: application/views/common/header.php
DEBUG - 2011-07-11 03:26:31 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-07-11 03:26:31 --> File loaded: application/views/common/footer.php
DEBUG - 2011-07-11 03:26:31 --> File loaded: application/views/layout/main.php
DEBUG - 2011-07-11 03:26:31 --> Final output sent to browser
DEBUG - 2011-07-11 03:26:31 --> Total execution time: 3.7043
DEBUG - 2011-07-11 03:26:33 --> Config Class Initialized
DEBUG - 2011-07-11 03:26:33 --> Hooks Class Initialized
DEBUG - 2011-07-11 03:26:33 --> Utf8 Class Initialized
DEBUG - 2011-07-11 03:26:33 --> UTF-8 Support Enabled
DEBUG - 2011-07-11 03:26:33 --> URI Class Initialized
DEBUG - 2011-07-11 03:26:33 --> Router Class Initialized
DEBUG - 2011-07-11 03:26:33 --> Output Class Initialized
DEBUG - 2011-07-11 03:26:33 --> Input Class Initialized
DEBUG - 2011-07-11 03:26:33 --> Global POST and COOKIE data sanitized
DEBUG - 2011-07-11 03:26:33 --> Language Class Initialized
DEBUG - 2011-07-11 03:26:33 --> Loader Class Initialized
DEBUG - 2011-07-11 03:26:33 --> Controller Class Initialized
ERROR - 2011-07-11 03:26:33 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-07-11 03:26:33 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-07-11 03:26:33 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-07-11 03:26:33 --> Model Class Initialized
DEBUG - 2011-07-11 03:26:33 --> Model Class Initialized
DEBUG - 2011-07-11 03:26:33 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-07-11 03:26:33 --> Database Driver Class Initialized
DEBUG - 2011-07-11 03:26:33 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-07-11 03:26:33 --> Helper loaded: url_helper
DEBUG - 2011-07-11 03:26:33 --> File loaded: application/views/common/header.php
DEBUG - 2011-07-11 03:26:33 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-07-11 03:26:33 --> File loaded: application/views/common/footer.php
DEBUG - 2011-07-11 03:26:33 --> File loaded: application/views/layout/main.php
DEBUG - 2011-07-11 03:26:33 --> Final output sent to browser
DEBUG - 2011-07-11 03:26:33 --> Total execution time: 0.1694
DEBUG - 2011-07-11 04:15:32 --> Config Class Initialized
DEBUG - 2011-07-11 04:15:32 --> Hooks Class Initialized
DEBUG - 2011-07-11 04:15:32 --> Utf8 Class Initialized
DEBUG - 2011-07-11 04:15:32 --> UTF-8 Support Enabled
DEBUG - 2011-07-11 04:15:32 --> URI Class Initialized
DEBUG - 2011-07-11 04:15:32 --> Router Class Initialized
DEBUG - 2011-07-11 04:15:32 --> Output Class Initialized
DEBUG - 2011-07-11 04:15:32 --> Input Class Initialized
DEBUG - 2011-07-11 04:15:32 --> Global POST and COOKIE data sanitized
DEBUG - 2011-07-11 04:15:32 --> Language Class Initialized
DEBUG - 2011-07-11 04:15:32 --> Loader Class Initialized
DEBUG - 2011-07-11 04:15:32 --> Controller Class Initialized
DEBUG - 2011-07-11 04:15:32 --> Model Class Initialized
DEBUG - 2011-07-11 04:15:32 --> Model Class Initialized
DEBUG - 2011-07-11 04:15:32 --> Model Class Initialized
DEBUG - 2011-07-11 04:15:32 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-07-11 04:15:32 --> Database Driver Class Initialized
DEBUG - 2011-07-11 04:15:33 --> File loaded: application/views/table/main.php
DEBUG - 2011-07-11 04:15:33 --> Helper loaded: url_helper
DEBUG - 2011-07-11 04:15:33 --> File loaded: application/views/common/header.php
DEBUG - 2011-07-11 04:15:33 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-07-11 04:15:33 --> File loaded: application/views/common/footer.php
DEBUG - 2011-07-11 04:15:33 --> File loaded: application/views/layout/main.php
DEBUG - 2011-07-11 04:15:33 --> Final output sent to browser
DEBUG - 2011-07-11 04:15:33 --> Total execution time: 0.9392
DEBUG - 2011-07-11 04:15:36 --> Config Class Initialized
DEBUG - 2011-07-11 04:15:36 --> Hooks Class Initialized
DEBUG - 2011-07-11 04:15:36 --> Utf8 Class Initialized
DEBUG - 2011-07-11 04:15:36 --> UTF-8 Support Enabled
DEBUG - 2011-07-11 04:15:36 --> URI Class Initialized
DEBUG - 2011-07-11 04:15:36 --> Router Class Initialized
ERROR - 2011-07-11 04:15:36 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-07-11 04:15:36 --> Config Class Initialized
DEBUG - 2011-07-11 04:15:36 --> Hooks Class Initialized
DEBUG - 2011-07-11 04:15:36 --> Utf8 Class Initialized
DEBUG - 2011-07-11 04:15:36 --> UTF-8 Support Enabled
DEBUG - 2011-07-11 04:15:36 --> URI Class Initialized
DEBUG - 2011-07-11 04:15:36 --> Router Class Initialized
ERROR - 2011-07-11 04:15:36 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-07-11 04:15:36 --> Config Class Initialized
DEBUG - 2011-07-11 04:15:36 --> Hooks Class Initialized
DEBUG - 2011-07-11 04:15:36 --> Utf8 Class Initialized
DEBUG - 2011-07-11 04:15:36 --> UTF-8 Support Enabled
DEBUG - 2011-07-11 04:15:36 --> URI Class Initialized
DEBUG - 2011-07-11 04:15:36 --> Router Class Initialized
ERROR - 2011-07-11 04:15:36 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-07-11 04:15:48 --> Config Class Initialized
DEBUG - 2011-07-11 04:15:48 --> Hooks Class Initialized
DEBUG - 2011-07-11 04:15:48 --> Utf8 Class Initialized
DEBUG - 2011-07-11 04:15:48 --> UTF-8 Support Enabled
DEBUG - 2011-07-11 04:15:48 --> URI Class Initialized
DEBUG - 2011-07-11 04:15:48 --> Router Class Initialized
ERROR - 2011-07-11 04:15:48 --> 404 Page Not Found --> robots.txt
DEBUG - 2011-07-11 04:15:48 --> Config Class Initialized
DEBUG - 2011-07-11 04:15:48 --> Hooks Class Initialized
DEBUG - 2011-07-11 04:15:48 --> Utf8 Class Initialized
DEBUG - 2011-07-11 04:15:48 --> UTF-8 Support Enabled
DEBUG - 2011-07-11 04:15:48 --> URI Class Initialized
DEBUG - 2011-07-11 04:15:48 --> Router Class Initialized
DEBUG - 2011-07-11 04:15:48 --> Output Class Initialized
DEBUG - 2011-07-11 04:15:48 --> Input Class Initialized
DEBUG - 2011-07-11 04:15:48 --> Global POST and COOKIE data sanitized
DEBUG - 2011-07-11 04:15:48 --> Language Class Initialized
DEBUG - 2011-07-11 04:15:48 --> Loader Class Initialized
DEBUG - 2011-07-11 04:15:48 --> Controller Class Initialized
DEBUG - 2011-07-11 04:15:48 --> Model Class Initialized
DEBUG - 2011-07-11 04:15:48 --> Model Class Initialized
DEBUG - 2011-07-11 04:15:48 --> Model Class Initialized
DEBUG - 2011-07-11 04:15:48 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-07-11 04:15:48 --> Database Driver Class Initialized
DEBUG - 2011-07-11 04:15:48 --> File loaded: application/views/table/main.php
DEBUG - 2011-07-11 04:15:48 --> Helper loaded: url_helper
DEBUG - 2011-07-11 04:15:48 --> File loaded: application/views/common/header.php
DEBUG - 2011-07-11 04:15:48 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-07-11 04:15:48 --> File loaded: application/views/common/footer.php
DEBUG - 2011-07-11 04:15:48 --> File loaded: application/views/layout/main.php
DEBUG - 2011-07-11 04:15:48 --> Final output sent to browser
DEBUG - 2011-07-11 04:15:48 --> Total execution time: 0.0565
DEBUG - 2011-07-11 04:38:25 --> Config Class Initialized
DEBUG - 2011-07-11 04:38:25 --> Hooks Class Initialized
DEBUG - 2011-07-11 04:38:25 --> Utf8 Class Initialized
DEBUG - 2011-07-11 04:38:25 --> UTF-8 Support Enabled
DEBUG - 2011-07-11 04:38:25 --> URI Class Initialized
DEBUG - 2011-07-11 04:38:25 --> Router Class Initialized
DEBUG - 2011-07-11 04:38:25 --> Output Class Initialized
DEBUG - 2011-07-11 04:38:25 --> Input Class Initialized
DEBUG - 2011-07-11 04:38:25 --> Global POST and COOKIE data sanitized
DEBUG - 2011-07-11 04:38:25 --> Language Class Initialized
DEBUG - 2011-07-11 04:38:25 --> Loader Class Initialized
DEBUG - 2011-07-11 04:38:25 --> Controller Class Initialized
ERROR - 2011-07-11 04:38:25 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-07-11 04:38:25 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-07-11 04:38:25 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-07-11 04:38:25 --> Model Class Initialized
DEBUG - 2011-07-11 04:38:25 --> Model Class Initialized
DEBUG - 2011-07-11 04:38:25 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-07-11 04:38:25 --> Database Driver Class Initialized
DEBUG - 2011-07-11 04:38:25 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-07-11 04:38:25 --> Helper loaded: url_helper
DEBUG - 2011-07-11 04:38:25 --> File loaded: application/views/common/header.php
DEBUG - 2011-07-11 04:38:25 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-07-11 04:38:25 --> File loaded: application/views/common/footer.php
DEBUG - 2011-07-11 04:38:25 --> File loaded: application/views/layout/main.php
DEBUG - 2011-07-11 04:38:25 --> Final output sent to browser
DEBUG - 2011-07-11 04:38:25 --> Total execution time: 0.2519
DEBUG - 2011-07-11 04:38:27 --> Config Class Initialized
DEBUG - 2011-07-11 04:38:27 --> Hooks Class Initialized
DEBUG - 2011-07-11 04:38:27 --> Utf8 Class Initialized
DEBUG - 2011-07-11 04:38:27 --> UTF-8 Support Enabled
DEBUG - 2011-07-11 04:38:27 --> URI Class Initialized
DEBUG - 2011-07-11 04:38:27 --> Router Class Initialized
DEBUG - 2011-07-11 04:38:27 --> Output Class Initialized
DEBUG - 2011-07-11 04:38:27 --> Input Class Initialized
DEBUG - 2011-07-11 04:38:27 --> Global POST and COOKIE data sanitized
DEBUG - 2011-07-11 04:38:27 --> Language Class Initialized
DEBUG - 2011-07-11 04:38:27 --> Loader Class Initialized
DEBUG - 2011-07-11 04:38:27 --> Controller Class Initialized
DEBUG - 2011-07-11 04:38:27 --> Model Class Initialized
DEBUG - 2011-07-11 04:38:27 --> Model Class Initialized
DEBUG - 2011-07-11 04:38:27 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-07-11 04:38:27 --> Database Driver Class Initialized
DEBUG - 2011-07-11 04:38:28 --> Final output sent to browser
DEBUG - 2011-07-11 04:38:28 --> Total execution time: 1.3867
DEBUG - 2011-07-11 04:38:29 --> Config Class Initialized
DEBUG - 2011-07-11 04:38:29 --> Hooks Class Initialized
DEBUG - 2011-07-11 04:38:29 --> Utf8 Class Initialized
DEBUG - 2011-07-11 04:38:29 --> UTF-8 Support Enabled
DEBUG - 2011-07-11 04:38:29 --> URI Class Initialized
DEBUG - 2011-07-11 04:38:29 --> Router Class Initialized
ERROR - 2011-07-11 04:38:29 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-07-11 04:38:42 --> Config Class Initialized
DEBUG - 2011-07-11 04:38:42 --> Hooks Class Initialized
DEBUG - 2011-07-11 04:38:42 --> Utf8 Class Initialized
DEBUG - 2011-07-11 04:38:42 --> UTF-8 Support Enabled
DEBUG - 2011-07-11 04:38:42 --> URI Class Initialized
DEBUG - 2011-07-11 04:38:42 --> Router Class Initialized
DEBUG - 2011-07-11 04:38:42 --> Output Class Initialized
DEBUG - 2011-07-11 04:38:42 --> Input Class Initialized
DEBUG - 2011-07-11 04:38:42 --> Global POST and COOKIE data sanitized
DEBUG - 2011-07-11 04:38:42 --> Language Class Initialized
DEBUG - 2011-07-11 04:38:42 --> Loader Class Initialized
DEBUG - 2011-07-11 04:38:42 --> Controller Class Initialized
ERROR - 2011-07-11 04:38:42 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-07-11 04:38:42 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-07-11 04:38:42 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-07-11 04:38:42 --> Model Class Initialized
DEBUG - 2011-07-11 04:38:42 --> Model Class Initialized
DEBUG - 2011-07-11 04:38:42 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-07-11 04:38:42 --> Database Driver Class Initialized
DEBUG - 2011-07-11 04:38:42 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-07-11 04:38:42 --> Helper loaded: url_helper
DEBUG - 2011-07-11 04:38:42 --> File loaded: application/views/common/header.php
DEBUG - 2011-07-11 04:38:42 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-07-11 04:38:42 --> File loaded: application/views/common/footer.php
DEBUG - 2011-07-11 04:38:42 --> File loaded: application/views/layout/main.php
DEBUG - 2011-07-11 04:38:42 --> Final output sent to browser
DEBUG - 2011-07-11 04:38:42 --> Total execution time: 0.0312
DEBUG - 2011-07-11 04:38:46 --> Config Class Initialized
DEBUG - 2011-07-11 04:38:46 --> Hooks Class Initialized
DEBUG - 2011-07-11 04:38:46 --> Utf8 Class Initialized
DEBUG - 2011-07-11 04:38:46 --> UTF-8 Support Enabled
DEBUG - 2011-07-11 04:38:46 --> URI Class Initialized
DEBUG - 2011-07-11 04:38:46 --> Router Class Initialized
DEBUG - 2011-07-11 04:38:46 --> Output Class Initialized
DEBUG - 2011-07-11 04:38:46 --> Input Class Initialized
DEBUG - 2011-07-11 04:38:46 --> Global POST and COOKIE data sanitized
DEBUG - 2011-07-11 04:38:46 --> Language Class Initialized
DEBUG - 2011-07-11 04:38:46 --> Loader Class Initialized
DEBUG - 2011-07-11 04:38:46 --> Controller Class Initialized
ERROR - 2011-07-11 04:38:46 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-07-11 04:38:46 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-07-11 04:38:46 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-07-11 04:38:46 --> Model Class Initialized
DEBUG - 2011-07-11 04:38:46 --> Model Class Initialized
DEBUG - 2011-07-11 04:38:46 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-07-11 04:38:46 --> Database Driver Class Initialized
DEBUG - 2011-07-11 04:38:46 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-07-11 04:38:46 --> Helper loaded: url_helper
DEBUG - 2011-07-11 04:38:46 --> File loaded: application/views/common/header.php
DEBUG - 2011-07-11 04:38:46 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-07-11 04:38:46 --> File loaded: application/views/common/footer.php
DEBUG - 2011-07-11 04:38:46 --> File loaded: application/views/layout/main.php
DEBUG - 2011-07-11 04:38:46 --> Final output sent to browser
DEBUG - 2011-07-11 04:38:46 --> Total execution time: 0.0290
DEBUG - 2011-07-11 04:38:47 --> Config Class Initialized
DEBUG - 2011-07-11 04:38:47 --> Hooks Class Initialized
DEBUG - 2011-07-11 04:38:47 --> Utf8 Class Initialized
DEBUG - 2011-07-11 04:38:47 --> UTF-8 Support Enabled
DEBUG - 2011-07-11 04:38:47 --> URI Class Initialized
DEBUG - 2011-07-11 04:38:47 --> Router Class Initialized
DEBUG - 2011-07-11 04:38:47 --> Output Class Initialized
DEBUG - 2011-07-11 04:38:47 --> Input Class Initialized
DEBUG - 2011-07-11 04:38:47 --> Global POST and COOKIE data sanitized
DEBUG - 2011-07-11 04:38:47 --> Language Class Initialized
DEBUG - 2011-07-11 04:38:47 --> Loader Class Initialized
DEBUG - 2011-07-11 04:38:47 --> Controller Class Initialized
DEBUG - 2011-07-11 04:38:47 --> Model Class Initialized
DEBUG - 2011-07-11 04:38:47 --> Model Class Initialized
DEBUG - 2011-07-11 04:38:47 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-07-11 04:38:47 --> Database Driver Class Initialized
DEBUG - 2011-07-11 04:38:47 --> Final output sent to browser
DEBUG - 2011-07-11 04:38:47 --> Total execution time: 0.5849
DEBUG - 2011-07-11 04:38:55 --> Config Class Initialized
DEBUG - 2011-07-11 04:38:55 --> Hooks Class Initialized
DEBUG - 2011-07-11 04:38:55 --> Utf8 Class Initialized
DEBUG - 2011-07-11 04:38:55 --> UTF-8 Support Enabled
DEBUG - 2011-07-11 04:38:55 --> URI Class Initialized
DEBUG - 2011-07-11 04:38:55 --> Router Class Initialized
DEBUG - 2011-07-11 04:38:55 --> Output Class Initialized
DEBUG - 2011-07-11 04:38:55 --> Input Class Initialized
DEBUG - 2011-07-11 04:38:55 --> Global POST and COOKIE data sanitized
DEBUG - 2011-07-11 04:38:55 --> Language Class Initialized
DEBUG - 2011-07-11 04:38:55 --> Loader Class Initialized
DEBUG - 2011-07-11 04:38:55 --> Controller Class Initialized
ERROR - 2011-07-11 04:38:55 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-07-11 04:38:55 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-07-11 04:38:55 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-07-11 04:38:55 --> Model Class Initialized
DEBUG - 2011-07-11 04:38:55 --> Model Class Initialized
DEBUG - 2011-07-11 04:38:55 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-07-11 04:38:55 --> Database Driver Class Initialized
DEBUG - 2011-07-11 04:38:55 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-07-11 04:38:55 --> Helper loaded: url_helper
DEBUG - 2011-07-11 04:38:55 --> File loaded: application/views/common/header.php
DEBUG - 2011-07-11 04:38:55 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-07-11 04:38:55 --> File loaded: application/views/common/footer.php
DEBUG - 2011-07-11 04:38:55 --> File loaded: application/views/layout/main.php
DEBUG - 2011-07-11 04:38:55 --> Final output sent to browser
DEBUG - 2011-07-11 04:38:55 --> Total execution time: 0.0290
DEBUG - 2011-07-11 04:38:56 --> Config Class Initialized
DEBUG - 2011-07-11 04:38:56 --> Hooks Class Initialized
DEBUG - 2011-07-11 04:38:56 --> Utf8 Class Initialized
DEBUG - 2011-07-11 04:38:56 --> UTF-8 Support Enabled
DEBUG - 2011-07-11 04:38:56 --> URI Class Initialized
DEBUG - 2011-07-11 04:38:56 --> Router Class Initialized
DEBUG - 2011-07-11 04:38:56 --> Output Class Initialized
DEBUG - 2011-07-11 04:38:56 --> Input Class Initialized
DEBUG - 2011-07-11 04:38:56 --> Global POST and COOKIE data sanitized
DEBUG - 2011-07-11 04:38:56 --> Language Class Initialized
DEBUG - 2011-07-11 04:38:56 --> Loader Class Initialized
DEBUG - 2011-07-11 04:38:56 --> Controller Class Initialized
DEBUG - 2011-07-11 04:38:56 --> Model Class Initialized
DEBUG - 2011-07-11 04:38:56 --> Model Class Initialized
DEBUG - 2011-07-11 04:38:56 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-07-11 04:38:56 --> Database Driver Class Initialized
DEBUG - 2011-07-11 04:38:56 --> Final output sent to browser
DEBUG - 2011-07-11 04:38:56 --> Total execution time: 0.6031
DEBUG - 2011-07-11 04:39:02 --> Config Class Initialized
DEBUG - 2011-07-11 04:39:02 --> Hooks Class Initialized
DEBUG - 2011-07-11 04:39:02 --> Utf8 Class Initialized
DEBUG - 2011-07-11 04:39:02 --> UTF-8 Support Enabled
DEBUG - 2011-07-11 04:39:02 --> URI Class Initialized
DEBUG - 2011-07-11 04:39:02 --> Router Class Initialized
DEBUG - 2011-07-11 04:39:02 --> Output Class Initialized
DEBUG - 2011-07-11 04:39:02 --> Input Class Initialized
DEBUG - 2011-07-11 04:39:02 --> Global POST and COOKIE data sanitized
DEBUG - 2011-07-11 04:39:02 --> Language Class Initialized
DEBUG - 2011-07-11 04:39:02 --> Loader Class Initialized
DEBUG - 2011-07-11 04:39:02 --> Controller Class Initialized
ERROR - 2011-07-11 04:39:02 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-07-11 04:39:02 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-07-11 04:39:02 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-07-11 04:39:02 --> Model Class Initialized
DEBUG - 2011-07-11 04:39:02 --> Model Class Initialized
DEBUG - 2011-07-11 04:39:02 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-07-11 04:39:02 --> Database Driver Class Initialized
DEBUG - 2011-07-11 04:39:02 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-07-11 04:39:02 --> Helper loaded: url_helper
DEBUG - 2011-07-11 04:39:02 --> File loaded: application/views/common/header.php
DEBUG - 2011-07-11 04:39:02 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-07-11 04:39:02 --> File loaded: application/views/common/footer.php
DEBUG - 2011-07-11 04:39:02 --> File loaded: application/views/layout/main.php
DEBUG - 2011-07-11 04:39:02 --> Final output sent to browser
DEBUG - 2011-07-11 04:39:02 --> Total execution time: 0.0329
DEBUG - 2011-07-11 04:39:03 --> Config Class Initialized
DEBUG - 2011-07-11 04:39:03 --> Hooks Class Initialized
DEBUG - 2011-07-11 04:39:03 --> Utf8 Class Initialized
DEBUG - 2011-07-11 04:39:03 --> UTF-8 Support Enabled
DEBUG - 2011-07-11 04:39:03 --> URI Class Initialized
DEBUG - 2011-07-11 04:39:03 --> Router Class Initialized
DEBUG - 2011-07-11 04:39:03 --> Output Class Initialized
DEBUG - 2011-07-11 04:39:03 --> Input Class Initialized
DEBUG - 2011-07-11 04:39:03 --> Global POST and COOKIE data sanitized
DEBUG - 2011-07-11 04:39:03 --> Language Class Initialized
DEBUG - 2011-07-11 04:39:03 --> Loader Class Initialized
DEBUG - 2011-07-11 04:39:03 --> Controller Class Initialized
DEBUG - 2011-07-11 04:39:03 --> Model Class Initialized
DEBUG - 2011-07-11 04:39:03 --> Model Class Initialized
DEBUG - 2011-07-11 04:39:03 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-07-11 04:39:03 --> Database Driver Class Initialized
DEBUG - 2011-07-11 04:39:04 --> Final output sent to browser
DEBUG - 2011-07-11 04:39:04 --> Total execution time: 0.5148
DEBUG - 2011-07-11 04:39:06 --> Config Class Initialized
DEBUG - 2011-07-11 04:39:06 --> Hooks Class Initialized
DEBUG - 2011-07-11 04:39:06 --> Utf8 Class Initialized
DEBUG - 2011-07-11 04:39:06 --> UTF-8 Support Enabled
DEBUG - 2011-07-11 04:39:06 --> URI Class Initialized
DEBUG - 2011-07-11 04:39:06 --> Router Class Initialized
DEBUG - 2011-07-11 04:39:06 --> Output Class Initialized
DEBUG - 2011-07-11 04:39:06 --> Input Class Initialized
DEBUG - 2011-07-11 04:39:06 --> Global POST and COOKIE data sanitized
DEBUG - 2011-07-11 04:39:06 --> Language Class Initialized
DEBUG - 2011-07-11 04:39:06 --> Loader Class Initialized
DEBUG - 2011-07-11 04:39:06 --> Controller Class Initialized
ERROR - 2011-07-11 04:39:06 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-07-11 04:39:06 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-07-11 04:39:06 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-07-11 04:39:06 --> Model Class Initialized
DEBUG - 2011-07-11 04:39:06 --> Model Class Initialized
DEBUG - 2011-07-11 04:39:06 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-07-11 04:39:06 --> Database Driver Class Initialized
DEBUG - 2011-07-11 04:39:06 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-07-11 04:39:06 --> Helper loaded: url_helper
DEBUG - 2011-07-11 04:39:06 --> File loaded: application/views/common/header.php
DEBUG - 2011-07-11 04:39:06 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-07-11 04:39:06 --> File loaded: application/views/common/footer.php
DEBUG - 2011-07-11 04:39:06 --> File loaded: application/views/layout/main.php
DEBUG - 2011-07-11 04:39:06 --> Final output sent to browser
DEBUG - 2011-07-11 04:39:06 --> Total execution time: 0.0376
DEBUG - 2011-07-11 04:39:09 --> Config Class Initialized
DEBUG - 2011-07-11 04:39:09 --> Hooks Class Initialized
DEBUG - 2011-07-11 04:39:09 --> Utf8 Class Initialized
DEBUG - 2011-07-11 04:39:09 --> UTF-8 Support Enabled
DEBUG - 2011-07-11 04:39:09 --> URI Class Initialized
DEBUG - 2011-07-11 04:39:09 --> Router Class Initialized
DEBUG - 2011-07-11 04:39:09 --> Output Class Initialized
DEBUG - 2011-07-11 04:39:09 --> Input Class Initialized
DEBUG - 2011-07-11 04:39:09 --> Global POST and COOKIE data sanitized
DEBUG - 2011-07-11 04:39:09 --> Language Class Initialized
DEBUG - 2011-07-11 04:39:09 --> Loader Class Initialized
DEBUG - 2011-07-11 04:39:09 --> Controller Class Initialized
ERROR - 2011-07-11 04:39:09 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-07-11 04:39:09 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-07-11 04:39:09 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-07-11 04:39:09 --> Model Class Initialized
DEBUG - 2011-07-11 04:39:09 --> Model Class Initialized
DEBUG - 2011-07-11 04:39:09 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-07-11 04:39:09 --> Database Driver Class Initialized
DEBUG - 2011-07-11 04:39:09 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-07-11 04:39:09 --> Helper loaded: url_helper
DEBUG - 2011-07-11 04:39:09 --> File loaded: application/views/common/header.php
DEBUG - 2011-07-11 04:39:09 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-07-11 04:39:09 --> File loaded: application/views/common/footer.php
DEBUG - 2011-07-11 04:39:09 --> File loaded: application/views/layout/main.php
DEBUG - 2011-07-11 04:39:09 --> Final output sent to browser
DEBUG - 2011-07-11 04:39:09 --> Total execution time: 0.0271
DEBUG - 2011-07-11 04:39:10 --> Config Class Initialized
DEBUG - 2011-07-11 04:39:10 --> Hooks Class Initialized
DEBUG - 2011-07-11 04:39:10 --> Utf8 Class Initialized
DEBUG - 2011-07-11 04:39:10 --> UTF-8 Support Enabled
DEBUG - 2011-07-11 04:39:10 --> URI Class Initialized
DEBUG - 2011-07-11 04:39:10 --> Router Class Initialized
DEBUG - 2011-07-11 04:39:10 --> Output Class Initialized
DEBUG - 2011-07-11 04:39:10 --> Input Class Initialized
DEBUG - 2011-07-11 04:39:10 --> Global POST and COOKIE data sanitized
DEBUG - 2011-07-11 04:39:10 --> Language Class Initialized
DEBUG - 2011-07-11 04:39:10 --> Loader Class Initialized
DEBUG - 2011-07-11 04:39:10 --> Controller Class Initialized
DEBUG - 2011-07-11 04:39:10 --> Model Class Initialized
DEBUG - 2011-07-11 04:39:10 --> Model Class Initialized
DEBUG - 2011-07-11 04:39:10 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-07-11 04:39:10 --> Database Driver Class Initialized
DEBUG - 2011-07-11 04:39:10 --> Config Class Initialized
DEBUG - 2011-07-11 04:39:10 --> Hooks Class Initialized
DEBUG - 2011-07-11 04:39:10 --> Utf8 Class Initialized
DEBUG - 2011-07-11 04:39:10 --> UTF-8 Support Enabled
DEBUG - 2011-07-11 04:39:10 --> URI Class Initialized
DEBUG - 2011-07-11 04:39:10 --> Router Class Initialized
DEBUG - 2011-07-11 04:39:10 --> Output Class Initialized
DEBUG - 2011-07-11 04:39:10 --> Input Class Initialized
DEBUG - 2011-07-11 04:39:10 --> Global POST and COOKIE data sanitized
DEBUG - 2011-07-11 04:39:10 --> Language Class Initialized
DEBUG - 2011-07-11 04:39:10 --> Loader Class Initialized
DEBUG - 2011-07-11 04:39:10 --> Controller Class Initialized
ERROR - 2011-07-11 04:39:10 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-07-11 04:39:10 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-07-11 04:39:10 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-07-11 04:39:10 --> Model Class Initialized
DEBUG - 2011-07-11 04:39:10 --> Model Class Initialized
DEBUG - 2011-07-11 04:39:10 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-07-11 04:39:10 --> Database Driver Class Initialized
DEBUG - 2011-07-11 04:39:10 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-07-11 04:39:10 --> Helper loaded: url_helper
DEBUG - 2011-07-11 04:39:10 --> File loaded: application/views/common/header.php
DEBUG - 2011-07-11 04:39:10 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-07-11 04:39:10 --> File loaded: application/views/common/footer.php
DEBUG - 2011-07-11 04:39:10 --> File loaded: application/views/layout/main.php
DEBUG - 2011-07-11 04:39:10 --> Final output sent to browser
DEBUG - 2011-07-11 04:39:10 --> Total execution time: 0.0263
DEBUG - 2011-07-11 04:39:10 --> Config Class Initialized
DEBUG - 2011-07-11 04:39:10 --> Hooks Class Initialized
DEBUG - 2011-07-11 04:39:10 --> Utf8 Class Initialized
DEBUG - 2011-07-11 04:39:10 --> UTF-8 Support Enabled
DEBUG - 2011-07-11 04:39:10 --> URI Class Initialized
DEBUG - 2011-07-11 04:39:10 --> Router Class Initialized
DEBUG - 2011-07-11 04:39:10 --> Output Class Initialized
DEBUG - 2011-07-11 04:39:10 --> Input Class Initialized
DEBUG - 2011-07-11 04:39:10 --> Global POST and COOKIE data sanitized
DEBUG - 2011-07-11 04:39:10 --> Language Class Initialized
DEBUG - 2011-07-11 04:39:10 --> Loader Class Initialized
DEBUG - 2011-07-11 04:39:10 --> Controller Class Initialized
ERROR - 2011-07-11 04:39:10 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-07-11 04:39:10 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-07-11 04:39:10 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-07-11 04:39:10 --> Model Class Initialized
DEBUG - 2011-07-11 04:39:10 --> Model Class Initialized
DEBUG - 2011-07-11 04:39:10 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-07-11 04:39:10 --> Database Driver Class Initialized
DEBUG - 2011-07-11 04:39:10 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-07-11 04:39:10 --> Helper loaded: url_helper
DEBUG - 2011-07-11 04:39:10 --> File loaded: application/views/common/header.php
DEBUG - 2011-07-11 04:39:10 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-07-11 04:39:10 --> File loaded: application/views/common/footer.php
DEBUG - 2011-07-11 04:39:10 --> File loaded: application/views/layout/main.php
DEBUG - 2011-07-11 04:39:10 --> Final output sent to browser
DEBUG - 2011-07-11 04:39:10 --> Total execution time: 0.0263
DEBUG - 2011-07-11 04:39:11 --> Final output sent to browser
DEBUG - 2011-07-11 04:39:11 --> Total execution time: 0.8340
DEBUG - 2011-07-11 04:39:16 --> Config Class Initialized
DEBUG - 2011-07-11 04:39:16 --> Hooks Class Initialized
DEBUG - 2011-07-11 04:39:16 --> Utf8 Class Initialized
DEBUG - 2011-07-11 04:39:16 --> UTF-8 Support Enabled
DEBUG - 2011-07-11 04:39:16 --> URI Class Initialized
DEBUG - 2011-07-11 04:39:16 --> Router Class Initialized
DEBUG - 2011-07-11 04:39:16 --> Output Class Initialized
DEBUG - 2011-07-11 04:39:16 --> Input Class Initialized
DEBUG - 2011-07-11 04:39:16 --> Global POST and COOKIE data sanitized
DEBUG - 2011-07-11 04:39:16 --> Language Class Initialized
DEBUG - 2011-07-11 04:39:16 --> Loader Class Initialized
DEBUG - 2011-07-11 04:39:16 --> Controller Class Initialized
ERROR - 2011-07-11 04:39:16 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-07-11 04:39:16 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-07-11 04:39:16 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-07-11 04:39:16 --> Model Class Initialized
DEBUG - 2011-07-11 04:39:16 --> Model Class Initialized
DEBUG - 2011-07-11 04:39:16 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-07-11 04:39:16 --> Database Driver Class Initialized
DEBUG - 2011-07-11 04:39:16 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-07-11 04:39:16 --> Helper loaded: url_helper
DEBUG - 2011-07-11 04:39:16 --> File loaded: application/views/common/header.php
DEBUG - 2011-07-11 04:39:16 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-07-11 04:39:16 --> File loaded: application/views/common/footer.php
DEBUG - 2011-07-11 04:39:16 --> File loaded: application/views/layout/main.php
DEBUG - 2011-07-11 04:39:16 --> Final output sent to browser
DEBUG - 2011-07-11 04:39:16 --> Total execution time: 0.0303
DEBUG - 2011-07-11 04:39:17 --> Config Class Initialized
DEBUG - 2011-07-11 04:39:17 --> Hooks Class Initialized
DEBUG - 2011-07-11 04:39:17 --> Utf8 Class Initialized
DEBUG - 2011-07-11 04:39:17 --> UTF-8 Support Enabled
DEBUG - 2011-07-11 04:39:17 --> URI Class Initialized
DEBUG - 2011-07-11 04:39:17 --> Router Class Initialized
DEBUG - 2011-07-11 04:39:17 --> Output Class Initialized
DEBUG - 2011-07-11 04:39:17 --> Input Class Initialized
DEBUG - 2011-07-11 04:39:17 --> Global POST and COOKIE data sanitized
DEBUG - 2011-07-11 04:39:17 --> Language Class Initialized
DEBUG - 2011-07-11 04:39:17 --> Loader Class Initialized
DEBUG - 2011-07-11 04:39:17 --> Controller Class Initialized
DEBUG - 2011-07-11 04:39:17 --> Model Class Initialized
DEBUG - 2011-07-11 04:39:17 --> Model Class Initialized
DEBUG - 2011-07-11 04:39:17 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-07-11 04:39:17 --> Database Driver Class Initialized
DEBUG - 2011-07-11 04:39:17 --> Final output sent to browser
DEBUG - 2011-07-11 04:39:17 --> Total execution time: 0.5456
DEBUG - 2011-07-11 05:12:40 --> Config Class Initialized
DEBUG - 2011-07-11 05:12:40 --> Hooks Class Initialized
DEBUG - 2011-07-11 05:12:40 --> Utf8 Class Initialized
DEBUG - 2011-07-11 05:12:40 --> UTF-8 Support Enabled
DEBUG - 2011-07-11 05:12:40 --> URI Class Initialized
DEBUG - 2011-07-11 05:12:40 --> Router Class Initialized
DEBUG - 2011-07-11 05:12:40 --> Output Class Initialized
DEBUG - 2011-07-11 05:12:40 --> Input Class Initialized
DEBUG - 2011-07-11 05:12:40 --> Global POST and COOKIE data sanitized
DEBUG - 2011-07-11 05:12:40 --> Language Class Initialized
DEBUG - 2011-07-11 05:12:40 --> Loader Class Initialized
DEBUG - 2011-07-11 05:12:40 --> Controller Class Initialized
DEBUG - 2011-07-11 05:12:41 --> Model Class Initialized
DEBUG - 2011-07-11 05:12:41 --> Model Class Initialized
DEBUG - 2011-07-11 05:12:41 --> Model Class Initialized
DEBUG - 2011-07-11 05:12:41 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-07-11 05:12:41 --> Database Driver Class Initialized
DEBUG - 2011-07-11 05:12:41 --> File loaded: application/views/table/main.php
DEBUG - 2011-07-11 05:12:41 --> Helper loaded: url_helper
DEBUG - 2011-07-11 05:12:41 --> File loaded: application/views/common/header.php
DEBUG - 2011-07-11 05:12:41 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-07-11 05:12:41 --> File loaded: application/views/common/footer.php
DEBUG - 2011-07-11 05:12:41 --> File loaded: application/views/layout/main.php
DEBUG - 2011-07-11 05:12:41 --> Final output sent to browser
DEBUG - 2011-07-11 05:12:41 --> Total execution time: 0.5949
DEBUG - 2011-07-11 05:13:15 --> Config Class Initialized
DEBUG - 2011-07-11 05:13:15 --> Hooks Class Initialized
DEBUG - 2011-07-11 05:13:15 --> Utf8 Class Initialized
DEBUG - 2011-07-11 05:13:15 --> UTF-8 Support Enabled
DEBUG - 2011-07-11 05:13:15 --> URI Class Initialized
DEBUG - 2011-07-11 05:13:15 --> Router Class Initialized
ERROR - 2011-07-11 05:13:15 --> 404 Page Not Found --> robots.txt
DEBUG - 2011-07-11 05:15:11 --> Config Class Initialized
DEBUG - 2011-07-11 05:15:11 --> Hooks Class Initialized
DEBUG - 2011-07-11 05:15:11 --> Utf8 Class Initialized
DEBUG - 2011-07-11 05:15:11 --> UTF-8 Support Enabled
DEBUG - 2011-07-11 05:15:11 --> URI Class Initialized
DEBUG - 2011-07-11 05:15:11 --> Router Class Initialized
DEBUG - 2011-07-11 05:15:11 --> Output Class Initialized
DEBUG - 2011-07-11 05:15:11 --> Input Class Initialized
DEBUG - 2011-07-11 05:15:11 --> Global POST and COOKIE data sanitized
DEBUG - 2011-07-11 05:15:11 --> Language Class Initialized
DEBUG - 2011-07-11 05:15:11 --> Loader Class Initialized
DEBUG - 2011-07-11 05:15:11 --> Controller Class Initialized
DEBUG - 2011-07-11 05:15:11 --> Model Class Initialized
DEBUG - 2011-07-11 05:15:11 --> Model Class Initialized
DEBUG - 2011-07-11 05:15:11 --> Model Class Initialized
DEBUG - 2011-07-11 05:15:11 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-07-11 05:15:11 --> Database Driver Class Initialized
DEBUG - 2011-07-11 05:15:11 --> File loaded: application/views/table/main.php
DEBUG - 2011-07-11 05:15:11 --> Helper loaded: url_helper
DEBUG - 2011-07-11 05:15:11 --> File loaded: application/views/common/header.php
DEBUG - 2011-07-11 05:15:11 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-07-11 05:15:11 --> File loaded: application/views/common/footer.php
DEBUG - 2011-07-11 05:15:11 --> File loaded: application/views/layout/main.php
DEBUG - 2011-07-11 05:15:11 --> Final output sent to browser
DEBUG - 2011-07-11 05:15:11 --> Total execution time: 0.1135
DEBUG - 2011-07-11 05:33:21 --> Config Class Initialized
DEBUG - 2011-07-11 05:33:21 --> Hooks Class Initialized
DEBUG - 2011-07-11 05:33:21 --> Utf8 Class Initialized
DEBUG - 2011-07-11 05:33:21 --> UTF-8 Support Enabled
DEBUG - 2011-07-11 05:33:21 --> URI Class Initialized
DEBUG - 2011-07-11 05:33:21 --> Router Class Initialized
DEBUG - 2011-07-11 05:33:21 --> Output Class Initialized
DEBUG - 2011-07-11 05:33:21 --> Input Class Initialized
DEBUG - 2011-07-11 05:33:21 --> Global POST and COOKIE data sanitized
DEBUG - 2011-07-11 05:33:21 --> Language Class Initialized
DEBUG - 2011-07-11 05:33:21 --> Loader Class Initialized
DEBUG - 2011-07-11 05:33:21 --> Controller Class Initialized
DEBUG - 2011-07-11 05:33:21 --> Model Class Initialized
DEBUG - 2011-07-11 05:33:21 --> Model Class Initialized
DEBUG - 2011-07-11 05:33:21 --> Model Class Initialized
DEBUG - 2011-07-11 05:33:21 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-07-11 05:33:21 --> Database Driver Class Initialized
DEBUG - 2011-07-11 05:33:21 --> File loaded: application/views/table/main.php
DEBUG - 2011-07-11 05:33:21 --> Helper loaded: url_helper
DEBUG - 2011-07-11 05:33:21 --> File loaded: application/views/common/header.php
DEBUG - 2011-07-11 05:33:21 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-07-11 05:33:21 --> File loaded: application/views/common/footer.php
DEBUG - 2011-07-11 05:33:21 --> File loaded: application/views/layout/main.php
DEBUG - 2011-07-11 05:33:21 --> Final output sent to browser
DEBUG - 2011-07-11 05:33:21 --> Total execution time: 0.3688
DEBUG - 2011-07-11 05:33:22 --> Config Class Initialized
DEBUG - 2011-07-11 05:33:22 --> Hooks Class Initialized
DEBUG - 2011-07-11 05:33:22 --> Utf8 Class Initialized
DEBUG - 2011-07-11 05:33:22 --> UTF-8 Support Enabled
DEBUG - 2011-07-11 05:33:22 --> URI Class Initialized
DEBUG - 2011-07-11 05:33:22 --> Router Class Initialized
DEBUG - 2011-07-11 05:33:22 --> Output Class Initialized
DEBUG - 2011-07-11 05:33:22 --> Input Class Initialized
DEBUG - 2011-07-11 05:33:22 --> Global POST and COOKIE data sanitized
DEBUG - 2011-07-11 05:33:22 --> Language Class Initialized
DEBUG - 2011-07-11 05:33:22 --> Loader Class Initialized
DEBUG - 2011-07-11 05:33:22 --> Controller Class Initialized
ERROR - 2011-07-11 05:33:22 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-07-11 05:33:22 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-07-11 05:33:22 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-07-11 05:33:22 --> Model Class Initialized
DEBUG - 2011-07-11 05:33:22 --> Model Class Initialized
DEBUG - 2011-07-11 05:33:22 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-07-11 05:33:22 --> Database Driver Class Initialized
DEBUG - 2011-07-11 05:33:22 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-07-11 05:33:22 --> Helper loaded: url_helper
DEBUG - 2011-07-11 05:33:22 --> File loaded: application/views/common/header.php
DEBUG - 2011-07-11 05:33:22 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-07-11 05:33:22 --> File loaded: application/views/common/footer.php
DEBUG - 2011-07-11 05:33:22 --> File loaded: application/views/layout/main.php
DEBUG - 2011-07-11 05:33:22 --> Final output sent to browser
DEBUG - 2011-07-11 05:33:22 --> Total execution time: 0.1623
DEBUG - 2011-07-11 05:56:51 --> Config Class Initialized
DEBUG - 2011-07-11 05:56:51 --> Hooks Class Initialized
DEBUG - 2011-07-11 05:56:51 --> Utf8 Class Initialized
DEBUG - 2011-07-11 05:56:51 --> UTF-8 Support Enabled
DEBUG - 2011-07-11 05:56:51 --> URI Class Initialized
DEBUG - 2011-07-11 05:56:51 --> Router Class Initialized
DEBUG - 2011-07-11 05:56:51 --> No URI present. Default controller set.
DEBUG - 2011-07-11 05:56:51 --> Output Class Initialized
DEBUG - 2011-07-11 05:56:51 --> Input Class Initialized
DEBUG - 2011-07-11 05:56:51 --> Global POST and COOKIE data sanitized
DEBUG - 2011-07-11 05:56:51 --> Language Class Initialized
DEBUG - 2011-07-11 05:56:51 --> Loader Class Initialized
DEBUG - 2011-07-11 05:56:51 --> Controller Class Initialized
DEBUG - 2011-07-11 05:56:51 --> File loaded: application/views/splash/main.php
DEBUG - 2011-07-11 05:56:51 --> Helper loaded: url_helper
DEBUG - 2011-07-11 05:56:51 --> File loaded: application/views/common/header.php
DEBUG - 2011-07-11 05:56:51 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-07-11 05:56:51 --> File loaded: application/views/common/footer.php
DEBUG - 2011-07-11 05:56:51 --> File loaded: application/views/layout/main.php
DEBUG - 2011-07-11 05:56:51 --> Final output sent to browser
DEBUG - 2011-07-11 05:56:51 --> Total execution time: 0.3934
DEBUG - 2011-07-11 06:04:19 --> Config Class Initialized
DEBUG - 2011-07-11 06:04:19 --> Config Class Initialized
DEBUG - 2011-07-11 06:04:19 --> Hooks Class Initialized
DEBUG - 2011-07-11 06:04:19 --> Hooks Class Initialized
DEBUG - 2011-07-11 06:04:19 --> Utf8 Class Initialized
DEBUG - 2011-07-11 06:04:19 --> Utf8 Class Initialized
DEBUG - 2011-07-11 06:04:19 --> UTF-8 Support Enabled
DEBUG - 2011-07-11 06:04:19 --> UTF-8 Support Enabled
DEBUG - 2011-07-11 06:04:19 --> URI Class Initialized
DEBUG - 2011-07-11 06:04:19 --> URI Class Initialized
DEBUG - 2011-07-11 06:04:19 --> Router Class Initialized
DEBUG - 2011-07-11 06:04:19 --> Router Class Initialized
DEBUG - 2011-07-11 06:04:20 --> Output Class Initialized
DEBUG - 2011-07-11 06:04:20 --> Output Class Initialized
DEBUG - 2011-07-11 06:04:20 --> Input Class Initialized
DEBUG - 2011-07-11 06:04:20 --> Input Class Initialized
DEBUG - 2011-07-11 06:04:20 --> Global POST and COOKIE data sanitized
DEBUG - 2011-07-11 06:04:20 --> Global POST and COOKIE data sanitized
DEBUG - 2011-07-11 06:04:20 --> Language Class Initialized
DEBUG - 2011-07-11 06:04:20 --> Language Class Initialized
DEBUG - 2011-07-11 06:04:20 --> Loader Class Initialized
DEBUG - 2011-07-11 06:04:20 --> Controller Class Initialized
DEBUG - 2011-07-11 06:04:20 --> Loader Class Initialized
DEBUG - 2011-07-11 06:04:20 --> Controller Class Initialized
DEBUG - 2011-07-11 06:04:21 --> Model Class Initialized
DEBUG - 2011-07-11 06:04:21 --> Model Class Initialized
ERROR - 2011-07-11 06:04:21 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-07-11 06:04:21 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-07-11 06:04:21 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-07-11 06:04:21 --> Model Class Initialized
DEBUG - 2011-07-11 06:04:21 --> Model Class Initialized
DEBUG - 2011-07-11 06:04:21 --> Model Class Initialized
DEBUG - 2011-07-11 06:04:22 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-07-11 06:04:22 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-07-11 06:04:23 --> Database Driver Class Initialized
DEBUG - 2011-07-11 06:04:23 --> Database Driver Class Initialized
DEBUG - 2011-07-11 06:04:23 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-07-11 06:04:23 --> Helper loaded: url_helper
DEBUG - 2011-07-11 06:04:23 --> File loaded: application/views/common/header.php
DEBUG - 2011-07-11 06:04:23 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-07-11 06:04:23 --> File loaded: application/views/common/footer.php
DEBUG - 2011-07-11 06:04:23 --> File loaded: application/views/layout/main.php
DEBUG - 2011-07-11 06:04:23 --> Final output sent to browser
DEBUG - 2011-07-11 06:04:23 --> Total execution time: 5.2333
DEBUG - 2011-07-11 06:04:23 --> File loaded: application/views/table/main.php
DEBUG - 2011-07-11 06:04:23 --> Helper loaded: url_helper
DEBUG - 2011-07-11 06:04:23 --> File loaded: application/views/common/header.php
DEBUG - 2011-07-11 06:04:23 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-07-11 06:04:23 --> File loaded: application/views/common/footer.php
DEBUG - 2011-07-11 06:04:23 --> File loaded: application/views/layout/main.php
DEBUG - 2011-07-11 06:04:23 --> Final output sent to browser
DEBUG - 2011-07-11 06:04:23 --> Total execution time: 5.8910
DEBUG - 2011-07-11 06:22:12 --> Config Class Initialized
DEBUG - 2011-07-11 06:22:12 --> Hooks Class Initialized
DEBUG - 2011-07-11 06:22:12 --> Utf8 Class Initialized
DEBUG - 2011-07-11 06:22:12 --> UTF-8 Support Enabled
DEBUG - 2011-07-11 06:22:12 --> URI Class Initialized
DEBUG - 2011-07-11 06:22:12 --> Router Class Initialized
ERROR - 2011-07-11 06:22:12 --> 404 Page Not Found --> robots.txt
DEBUG - 2011-07-11 06:24:57 --> Config Class Initialized
DEBUG - 2011-07-11 06:24:57 --> Hooks Class Initialized
DEBUG - 2011-07-11 06:24:57 --> Utf8 Class Initialized
DEBUG - 2011-07-11 06:24:57 --> UTF-8 Support Enabled
DEBUG - 2011-07-11 06:24:57 --> URI Class Initialized
DEBUG - 2011-07-11 06:24:57 --> Router Class Initialized
DEBUG - 2011-07-11 06:24:57 --> Output Class Initialized
DEBUG - 2011-07-11 06:24:57 --> Input Class Initialized
DEBUG - 2011-07-11 06:24:57 --> Global POST and COOKIE data sanitized
DEBUG - 2011-07-11 06:24:57 --> Language Class Initialized
DEBUG - 2011-07-11 06:24:57 --> Loader Class Initialized
DEBUG - 2011-07-11 06:24:57 --> Controller Class Initialized
ERROR - 2011-07-11 06:24:57 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-07-11 06:24:57 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-07-11 06:24:57 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-07-11 06:24:57 --> Model Class Initialized
DEBUG - 2011-07-11 06:24:57 --> Model Class Initialized
DEBUG - 2011-07-11 06:24:57 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-07-11 06:24:58 --> Database Driver Class Initialized
DEBUG - 2011-07-11 06:24:58 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-07-11 06:24:58 --> Helper loaded: url_helper
DEBUG - 2011-07-11 06:24:58 --> File loaded: application/views/common/header.php
DEBUG - 2011-07-11 06:24:58 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-07-11 06:24:58 --> File loaded: application/views/common/footer.php
DEBUG - 2011-07-11 06:24:58 --> File loaded: application/views/layout/main.php
DEBUG - 2011-07-11 06:24:58 --> Final output sent to browser
DEBUG - 2011-07-11 06:24:58 --> Total execution time: 0.3650
DEBUG - 2011-07-11 06:25:00 --> Config Class Initialized
DEBUG - 2011-07-11 06:25:00 --> Hooks Class Initialized
DEBUG - 2011-07-11 06:25:00 --> Utf8 Class Initialized
DEBUG - 2011-07-11 06:25:00 --> UTF-8 Support Enabled
DEBUG - 2011-07-11 06:25:00 --> URI Class Initialized
DEBUG - 2011-07-11 06:25:00 --> Router Class Initialized
DEBUG - 2011-07-11 06:25:00 --> Output Class Initialized
DEBUG - 2011-07-11 06:25:00 --> Input Class Initialized
DEBUG - 2011-07-11 06:25:00 --> Global POST and COOKIE data sanitized
DEBUG - 2011-07-11 06:25:00 --> Language Class Initialized
DEBUG - 2011-07-11 06:25:00 --> Loader Class Initialized
DEBUG - 2011-07-11 06:25:00 --> Controller Class Initialized
DEBUG - 2011-07-11 06:25:00 --> Model Class Initialized
DEBUG - 2011-07-11 06:25:00 --> Model Class Initialized
DEBUG - 2011-07-11 06:25:00 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-07-11 06:25:00 --> Database Driver Class Initialized
DEBUG - 2011-07-11 06:25:02 --> Final output sent to browser
DEBUG - 2011-07-11 06:25:02 --> Total execution time: 1.3138
DEBUG - 2011-07-11 06:25:03 --> Config Class Initialized
DEBUG - 2011-07-11 06:25:03 --> Hooks Class Initialized
DEBUG - 2011-07-11 06:25:03 --> Utf8 Class Initialized
DEBUG - 2011-07-11 06:25:03 --> UTF-8 Support Enabled
DEBUG - 2011-07-11 06:25:03 --> URI Class Initialized
DEBUG - 2011-07-11 06:25:03 --> Router Class Initialized
ERROR - 2011-07-11 06:25:03 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-07-11 06:29:32 --> Config Class Initialized
DEBUG - 2011-07-11 06:29:32 --> Hooks Class Initialized
DEBUG - 2011-07-11 06:29:32 --> Utf8 Class Initialized
DEBUG - 2011-07-11 06:29:32 --> UTF-8 Support Enabled
DEBUG - 2011-07-11 06:29:32 --> URI Class Initialized
DEBUG - 2011-07-11 06:29:32 --> Router Class Initialized
DEBUG - 2011-07-11 06:29:32 --> Output Class Initialized
DEBUG - 2011-07-11 06:29:32 --> Input Class Initialized
DEBUG - 2011-07-11 06:29:32 --> Global POST and COOKIE data sanitized
DEBUG - 2011-07-11 06:29:32 --> Language Class Initialized
DEBUG - 2011-07-11 06:29:32 --> Loader Class Initialized
DEBUG - 2011-07-11 06:29:32 --> Controller Class Initialized
ERROR - 2011-07-11 06:29:32 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-07-11 06:29:32 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-07-11 06:29:32 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-07-11 06:29:32 --> Model Class Initialized
DEBUG - 2011-07-11 06:29:32 --> Model Class Initialized
DEBUG - 2011-07-11 06:29:32 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-07-11 06:29:32 --> Database Driver Class Initialized
DEBUG - 2011-07-11 06:29:32 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-07-11 06:29:32 --> Helper loaded: url_helper
DEBUG - 2011-07-11 06:29:32 --> File loaded: application/views/common/header.php
DEBUG - 2011-07-11 06:29:32 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-07-11 06:29:32 --> File loaded: application/views/common/footer.php
DEBUG - 2011-07-11 06:29:32 --> File loaded: application/views/layout/main.php
DEBUG - 2011-07-11 06:29:32 --> Final output sent to browser
DEBUG - 2011-07-11 06:29:32 --> Total execution time: 0.1101
DEBUG - 2011-07-11 06:32:10 --> Config Class Initialized
DEBUG - 2011-07-11 06:32:10 --> Hooks Class Initialized
DEBUG - 2011-07-11 06:32:10 --> Utf8 Class Initialized
DEBUG - 2011-07-11 06:32:10 --> UTF-8 Support Enabled
DEBUG - 2011-07-11 06:32:10 --> URI Class Initialized
DEBUG - 2011-07-11 06:32:10 --> Router Class Initialized
DEBUG - 2011-07-11 06:32:10 --> Output Class Initialized
DEBUG - 2011-07-11 06:32:10 --> Input Class Initialized
DEBUG - 2011-07-11 06:32:10 --> Global POST and COOKIE data sanitized
DEBUG - 2011-07-11 06:32:10 --> Language Class Initialized
DEBUG - 2011-07-11 06:32:10 --> Loader Class Initialized
DEBUG - 2011-07-11 06:32:10 --> Controller Class Initialized
ERROR - 2011-07-11 06:32:10 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-07-11 06:32:10 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-07-11 06:32:10 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-07-11 06:32:10 --> Model Class Initialized
DEBUG - 2011-07-11 06:32:10 --> Model Class Initialized
DEBUG - 2011-07-11 06:32:10 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-07-11 06:32:10 --> Database Driver Class Initialized
DEBUG - 2011-07-11 06:32:10 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-07-11 06:32:10 --> Helper loaded: url_helper
DEBUG - 2011-07-11 06:32:10 --> File loaded: application/views/common/header.php
DEBUG - 2011-07-11 06:32:10 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-07-11 06:32:10 --> File loaded: application/views/common/footer.php
DEBUG - 2011-07-11 06:32:10 --> File loaded: application/views/layout/main.php
DEBUG - 2011-07-11 06:32:10 --> Final output sent to browser
DEBUG - 2011-07-11 06:32:10 --> Total execution time: 0.1735
DEBUG - 2011-07-11 06:36:08 --> Config Class Initialized
DEBUG - 2011-07-11 06:36:08 --> Hooks Class Initialized
DEBUG - 2011-07-11 06:36:08 --> Utf8 Class Initialized
DEBUG - 2011-07-11 06:36:08 --> UTF-8 Support Enabled
DEBUG - 2011-07-11 06:36:08 --> URI Class Initialized
DEBUG - 2011-07-11 06:36:08 --> Router Class Initialized
DEBUG - 2011-07-11 06:36:08 --> Output Class Initialized
DEBUG - 2011-07-11 06:36:08 --> Input Class Initialized
DEBUG - 2011-07-11 06:36:08 --> Global POST and COOKIE data sanitized
DEBUG - 2011-07-11 06:36:08 --> Language Class Initialized
DEBUG - 2011-07-11 06:36:08 --> Loader Class Initialized
DEBUG - 2011-07-11 06:36:08 --> Controller Class Initialized
DEBUG - 2011-07-11 06:36:08 --> Model Class Initialized
DEBUG - 2011-07-11 06:36:08 --> Model Class Initialized
DEBUG - 2011-07-11 06:36:08 --> Model Class Initialized
DEBUG - 2011-07-11 06:36:08 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-07-11 06:36:08 --> Database Driver Class Initialized
DEBUG - 2011-07-11 06:36:08 --> File loaded: application/views/table/main.php
DEBUG - 2011-07-11 06:36:08 --> Helper loaded: url_helper
DEBUG - 2011-07-11 06:36:08 --> File loaded: application/views/common/header.php
DEBUG - 2011-07-11 06:36:08 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-07-11 06:36:08 --> File loaded: application/views/common/footer.php
DEBUG - 2011-07-11 06:36:08 --> File loaded: application/views/layout/main.php
DEBUG - 2011-07-11 06:36:08 --> Final output sent to browser
DEBUG - 2011-07-11 06:36:08 --> Total execution time: 0.6054
DEBUG - 2011-07-11 06:38:43 --> Config Class Initialized
DEBUG - 2011-07-11 06:38:43 --> Hooks Class Initialized
DEBUG - 2011-07-11 06:38:43 --> Utf8 Class Initialized
DEBUG - 2011-07-11 06:38:43 --> UTF-8 Support Enabled
DEBUG - 2011-07-11 06:38:43 --> URI Class Initialized
DEBUG - 2011-07-11 06:38:43 --> Router Class Initialized
DEBUG - 2011-07-11 06:38:43 --> Output Class Initialized
DEBUG - 2011-07-11 06:38:43 --> Input Class Initialized
DEBUG - 2011-07-11 06:38:43 --> Global POST and COOKIE data sanitized
DEBUG - 2011-07-11 06:38:43 --> Language Class Initialized
DEBUG - 2011-07-11 06:38:43 --> Loader Class Initialized
DEBUG - 2011-07-11 06:38:43 --> Controller Class Initialized
DEBUG - 2011-07-11 06:38:43 --> Model Class Initialized
DEBUG - 2011-07-11 06:38:43 --> Model Class Initialized
DEBUG - 2011-07-11 06:38:43 --> Model Class Initialized
DEBUG - 2011-07-11 06:38:43 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-07-11 06:38:43 --> Database Driver Class Initialized
DEBUG - 2011-07-11 06:38:44 --> File loaded: application/views/table/main.php
DEBUG - 2011-07-11 06:38:44 --> Helper loaded: url_helper
DEBUG - 2011-07-11 06:38:44 --> File loaded: application/views/common/header.php
DEBUG - 2011-07-11 06:38:44 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-07-11 06:38:44 --> File loaded: application/views/common/footer.php
DEBUG - 2011-07-11 06:38:44 --> File loaded: application/views/layout/main.php
DEBUG - 2011-07-11 06:38:44 --> Final output sent to browser
DEBUG - 2011-07-11 06:38:44 --> Total execution time: 0.2232
DEBUG - 2011-07-11 06:38:44 --> Config Class Initialized
DEBUG - 2011-07-11 06:38:44 --> Hooks Class Initialized
DEBUG - 2011-07-11 06:38:44 --> Utf8 Class Initialized
DEBUG - 2011-07-11 06:38:44 --> UTF-8 Support Enabled
DEBUG - 2011-07-11 06:38:44 --> URI Class Initialized
DEBUG - 2011-07-11 06:38:44 --> Router Class Initialized
DEBUG - 2011-07-11 06:38:44 --> Output Class Initialized
DEBUG - 2011-07-11 06:38:44 --> Input Class Initialized
DEBUG - 2011-07-11 06:38:44 --> Global POST and COOKIE data sanitized
DEBUG - 2011-07-11 06:38:44 --> Language Class Initialized
DEBUG - 2011-07-11 06:38:44 --> Loader Class Initialized
DEBUG - 2011-07-11 06:38:44 --> Controller Class Initialized
ERROR - 2011-07-11 06:38:44 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-07-11 06:38:44 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-07-11 06:38:44 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-07-11 06:38:44 --> Model Class Initialized
DEBUG - 2011-07-11 06:38:44 --> Model Class Initialized
DEBUG - 2011-07-11 06:38:44 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-07-11 06:38:44 --> Database Driver Class Initialized
DEBUG - 2011-07-11 06:38:44 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-07-11 06:38:45 --> Helper loaded: url_helper
DEBUG - 2011-07-11 06:38:45 --> File loaded: application/views/common/header.php
DEBUG - 2011-07-11 06:38:45 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-07-11 06:38:45 --> File loaded: application/views/common/footer.php
DEBUG - 2011-07-11 06:38:45 --> File loaded: application/views/layout/main.php
DEBUG - 2011-07-11 06:38:45 --> Final output sent to browser
DEBUG - 2011-07-11 06:38:45 --> Total execution time: 0.0852
DEBUG - 2011-07-11 06:51:45 --> Config Class Initialized
DEBUG - 2011-07-11 06:51:45 --> Hooks Class Initialized
DEBUG - 2011-07-11 06:51:45 --> Utf8 Class Initialized
DEBUG - 2011-07-11 06:51:45 --> UTF-8 Support Enabled
DEBUG - 2011-07-11 06:51:45 --> URI Class Initialized
DEBUG - 2011-07-11 06:51:45 --> Router Class Initialized
DEBUG - 2011-07-11 06:51:45 --> Output Class Initialized
DEBUG - 2011-07-11 06:51:45 --> Input Class Initialized
DEBUG - 2011-07-11 06:51:45 --> Global POST and COOKIE data sanitized
DEBUG - 2011-07-11 06:51:45 --> Language Class Initialized
DEBUG - 2011-07-11 06:51:45 --> Loader Class Initialized
DEBUG - 2011-07-11 06:51:45 --> Controller Class Initialized
ERROR - 2011-07-11 06:51:45 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-07-11 06:51:45 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-07-11 06:51:45 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-07-11 06:51:45 --> Model Class Initialized
DEBUG - 2011-07-11 06:51:45 --> Model Class Initialized
DEBUG - 2011-07-11 06:51:45 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-07-11 06:51:45 --> Database Driver Class Initialized
DEBUG - 2011-07-11 06:51:45 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-07-11 06:51:45 --> Helper loaded: url_helper
DEBUG - 2011-07-11 06:51:45 --> File loaded: application/views/common/header.php
DEBUG - 2011-07-11 06:51:45 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-07-11 06:51:45 --> File loaded: application/views/common/footer.php
DEBUG - 2011-07-11 06:51:45 --> File loaded: application/views/layout/main.php
DEBUG - 2011-07-11 06:51:45 --> Final output sent to browser
DEBUG - 2011-07-11 06:51:45 --> Total execution time: 0.2651
DEBUG - 2011-07-11 07:04:24 --> Config Class Initialized
DEBUG - 2011-07-11 07:04:24 --> Hooks Class Initialized
DEBUG - 2011-07-11 07:04:24 --> Utf8 Class Initialized
DEBUG - 2011-07-11 07:04:24 --> UTF-8 Support Enabled
DEBUG - 2011-07-11 07:04:24 --> URI Class Initialized
DEBUG - 2011-07-11 07:04:24 --> Router Class Initialized
DEBUG - 2011-07-11 07:04:24 --> Output Class Initialized
DEBUG - 2011-07-11 07:04:24 --> Input Class Initialized
DEBUG - 2011-07-11 07:04:24 --> Global POST and COOKIE data sanitized
DEBUG - 2011-07-11 07:04:24 --> Language Class Initialized
DEBUG - 2011-07-11 07:04:24 --> Loader Class Initialized
DEBUG - 2011-07-11 07:04:24 --> Controller Class Initialized
ERROR - 2011-07-11 07:04:24 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-07-11 07:04:24 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-07-11 07:04:24 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-07-11 07:04:24 --> Model Class Initialized
DEBUG - 2011-07-11 07:04:24 --> Model Class Initialized
DEBUG - 2011-07-11 07:04:24 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-07-11 07:04:24 --> Database Driver Class Initialized
DEBUG - 2011-07-11 07:04:24 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-07-11 07:04:24 --> Helper loaded: url_helper
DEBUG - 2011-07-11 07:04:24 --> File loaded: application/views/common/header.php
DEBUG - 2011-07-11 07:04:24 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-07-11 07:04:24 --> File loaded: application/views/common/footer.php
DEBUG - 2011-07-11 07:04:24 --> File loaded: application/views/layout/main.php
DEBUG - 2011-07-11 07:04:24 --> Final output sent to browser
DEBUG - 2011-07-11 07:04:24 --> Total execution time: 0.5508
DEBUG - 2011-07-11 08:18:33 --> Config Class Initialized
DEBUG - 2011-07-11 08:18:33 --> Hooks Class Initialized
DEBUG - 2011-07-11 08:18:33 --> Utf8 Class Initialized
DEBUG - 2011-07-11 08:18:33 --> UTF-8 Support Enabled
DEBUG - 2011-07-11 08:18:33 --> URI Class Initialized
DEBUG - 2011-07-11 08:18:33 --> Router Class Initialized
DEBUG - 2011-07-11 08:18:33 --> Output Class Initialized
DEBUG - 2011-07-11 08:18:33 --> Input Class Initialized
DEBUG - 2011-07-11 08:18:33 --> Global POST and COOKIE data sanitized
DEBUG - 2011-07-11 08:18:33 --> Language Class Initialized
DEBUG - 2011-07-11 08:18:33 --> Loader Class Initialized
DEBUG - 2011-07-11 08:18:33 --> Controller Class Initialized
DEBUG - 2011-07-11 08:18:33 --> Model Class Initialized
DEBUG - 2011-07-11 08:18:33 --> Model Class Initialized
DEBUG - 2011-07-11 08:18:33 --> Model Class Initialized
DEBUG - 2011-07-11 08:18:33 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-07-11 08:18:33 --> Database Driver Class Initialized
DEBUG - 2011-07-11 08:18:33 --> File loaded: application/views/table/main.php
DEBUG - 2011-07-11 08:18:33 --> Helper loaded: url_helper
DEBUG - 2011-07-11 08:18:33 --> File loaded: application/views/common/header.php
DEBUG - 2011-07-11 08:18:33 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-07-11 08:18:33 --> File loaded: application/views/common/footer.php
DEBUG - 2011-07-11 08:18:33 --> File loaded: application/views/layout/main.php
DEBUG - 2011-07-11 08:18:33 --> Final output sent to browser
DEBUG - 2011-07-11 08:18:33 --> Total execution time: 0.5959
DEBUG - 2011-07-11 08:18:36 --> Config Class Initialized
DEBUG - 2011-07-11 08:18:36 --> Hooks Class Initialized
DEBUG - 2011-07-11 08:18:36 --> Utf8 Class Initialized
DEBUG - 2011-07-11 08:18:36 --> UTF-8 Support Enabled
DEBUG - 2011-07-11 08:18:36 --> URI Class Initialized
DEBUG - 2011-07-11 08:18:36 --> Router Class Initialized
DEBUG - 2011-07-11 08:18:36 --> Output Class Initialized
DEBUG - 2011-07-11 08:18:36 --> Input Class Initialized
DEBUG - 2011-07-11 08:18:36 --> Global POST and COOKIE data sanitized
DEBUG - 2011-07-11 08:18:36 --> Language Class Initialized
DEBUG - 2011-07-11 08:18:36 --> Loader Class Initialized
DEBUG - 2011-07-11 08:18:36 --> Controller Class Initialized
ERROR - 2011-07-11 08:18:36 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-07-11 08:18:36 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-07-11 08:18:36 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-07-11 08:18:36 --> Model Class Initialized
DEBUG - 2011-07-11 08:18:36 --> Model Class Initialized
DEBUG - 2011-07-11 08:18:36 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-07-11 08:18:36 --> Database Driver Class Initialized
DEBUG - 2011-07-11 08:18:36 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-07-11 08:18:36 --> Helper loaded: url_helper
DEBUG - 2011-07-11 08:18:36 --> File loaded: application/views/common/header.php
DEBUG - 2011-07-11 08:18:36 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-07-11 08:18:36 --> File loaded: application/views/common/footer.php
DEBUG - 2011-07-11 08:18:36 --> File loaded: application/views/layout/main.php
DEBUG - 2011-07-11 08:18:36 --> Final output sent to browser
DEBUG - 2011-07-11 08:18:36 --> Total execution time: 0.1433
DEBUG - 2011-07-11 09:07:17 --> Config Class Initialized
DEBUG - 2011-07-11 09:07:17 --> Hooks Class Initialized
DEBUG - 2011-07-11 09:07:17 --> Utf8 Class Initialized
DEBUG - 2011-07-11 09:07:17 --> UTF-8 Support Enabled
DEBUG - 2011-07-11 09:07:17 --> URI Class Initialized
DEBUG - 2011-07-11 09:07:17 --> Router Class Initialized
DEBUG - 2011-07-11 09:07:17 --> Output Class Initialized
DEBUG - 2011-07-11 09:07:17 --> Input Class Initialized
DEBUG - 2011-07-11 09:07:17 --> Global POST and COOKIE data sanitized
DEBUG - 2011-07-11 09:07:17 --> Language Class Initialized
DEBUG - 2011-07-11 09:07:17 --> Loader Class Initialized
DEBUG - 2011-07-11 09:07:17 --> Controller Class Initialized
ERROR - 2011-07-11 09:07:17 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-07-11 09:07:17 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-07-11 09:07:17 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-07-11 09:07:17 --> Model Class Initialized
DEBUG - 2011-07-11 09:07:17 --> Model Class Initialized
DEBUG - 2011-07-11 09:07:17 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-07-11 09:07:17 --> Database Driver Class Initialized
DEBUG - 2011-07-11 09:07:17 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-07-11 09:07:17 --> Helper loaded: url_helper
DEBUG - 2011-07-11 09:07:17 --> File loaded: application/views/common/header.php
DEBUG - 2011-07-11 09:07:17 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-07-11 09:07:17 --> File loaded: application/views/common/footer.php
DEBUG - 2011-07-11 09:07:17 --> File loaded: application/views/layout/main.php
DEBUG - 2011-07-11 09:07:17 --> Final output sent to browser
DEBUG - 2011-07-11 09:07:17 --> Total execution time: 0.6393
DEBUG - 2011-07-11 10:08:45 --> Config Class Initialized
DEBUG - 2011-07-11 10:08:45 --> Hooks Class Initialized
DEBUG - 2011-07-11 10:08:45 --> Utf8 Class Initialized
DEBUG - 2011-07-11 10:08:45 --> UTF-8 Support Enabled
DEBUG - 2011-07-11 10:08:45 --> URI Class Initialized
DEBUG - 2011-07-11 10:08:45 --> Router Class Initialized
DEBUG - 2011-07-11 10:08:45 --> Output Class Initialized
DEBUG - 2011-07-11 10:08:45 --> Input Class Initialized
DEBUG - 2011-07-11 10:08:45 --> Global POST and COOKIE data sanitized
DEBUG - 2011-07-11 10:08:45 --> Language Class Initialized
DEBUG - 2011-07-11 10:08:45 --> Loader Class Initialized
DEBUG - 2011-07-11 10:08:45 --> Controller Class Initialized
DEBUG - 2011-07-11 10:08:45 --> Model Class Initialized
DEBUG - 2011-07-11 10:08:45 --> Model Class Initialized
DEBUG - 2011-07-11 10:08:45 --> Model Class Initialized
DEBUG - 2011-07-11 10:08:45 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-07-11 10:08:45 --> Database Driver Class Initialized
DEBUG - 2011-07-11 10:08:45 --> File loaded: application/views/table/main.php
DEBUG - 2011-07-11 10:08:45 --> Helper loaded: url_helper
DEBUG - 2011-07-11 10:08:45 --> File loaded: application/views/common/header.php
DEBUG - 2011-07-11 10:08:45 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-07-11 10:08:45 --> File loaded: application/views/common/footer.php
DEBUG - 2011-07-11 10:08:45 --> File loaded: application/views/layout/main.php
DEBUG - 2011-07-11 10:08:45 --> Final output sent to browser
DEBUG - 2011-07-11 10:08:45 --> Total execution time: 0.8759
DEBUG - 2011-07-11 10:08:46 --> Config Class Initialized
DEBUG - 2011-07-11 10:08:46 --> Hooks Class Initialized
DEBUG - 2011-07-11 10:08:46 --> Utf8 Class Initialized
DEBUG - 2011-07-11 10:08:46 --> UTF-8 Support Enabled
DEBUG - 2011-07-11 10:08:46 --> URI Class Initialized
DEBUG - 2011-07-11 10:08:46 --> Router Class Initialized
DEBUG - 2011-07-11 10:08:46 --> Output Class Initialized
DEBUG - 2011-07-11 10:08:46 --> Input Class Initialized
DEBUG - 2011-07-11 10:08:46 --> Global POST and COOKIE data sanitized
DEBUG - 2011-07-11 10:08:46 --> Language Class Initialized
DEBUG - 2011-07-11 10:08:46 --> Loader Class Initialized
DEBUG - 2011-07-11 10:08:46 --> Controller Class Initialized
ERROR - 2011-07-11 10:08:46 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-07-11 10:08:46 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-07-11 10:08:46 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-07-11 10:08:46 --> Model Class Initialized
DEBUG - 2011-07-11 10:08:46 --> Model Class Initialized
DEBUG - 2011-07-11 10:08:46 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-07-11 10:08:46 --> Database Driver Class Initialized
DEBUG - 2011-07-11 10:08:46 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-07-11 10:08:46 --> Helper loaded: url_helper
DEBUG - 2011-07-11 10:08:46 --> File loaded: application/views/common/header.php
DEBUG - 2011-07-11 10:08:46 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-07-11 10:08:46 --> File loaded: application/views/common/footer.php
DEBUG - 2011-07-11 10:08:46 --> File loaded: application/views/layout/main.php
DEBUG - 2011-07-11 10:08:46 --> Final output sent to browser
DEBUG - 2011-07-11 10:08:46 --> Total execution time: 0.1122
DEBUG - 2011-07-11 11:15:05 --> Config Class Initialized
DEBUG - 2011-07-11 11:15:05 --> Hooks Class Initialized
DEBUG - 2011-07-11 11:15:05 --> Utf8 Class Initialized
DEBUG - 2011-07-11 11:15:05 --> UTF-8 Support Enabled
DEBUG - 2011-07-11 11:15:05 --> URI Class Initialized
DEBUG - 2011-07-11 11:15:05 --> Router Class Initialized
DEBUG - 2011-07-11 11:15:05 --> Output Class Initialized
DEBUG - 2011-07-11 11:15:05 --> Input Class Initialized
DEBUG - 2011-07-11 11:15:05 --> Global POST and COOKIE data sanitized
DEBUG - 2011-07-11 11:15:05 --> Language Class Initialized
DEBUG - 2011-07-11 11:15:05 --> Loader Class Initialized
DEBUG - 2011-07-11 11:15:05 --> Controller Class Initialized
DEBUG - 2011-07-11 11:15:05 --> Model Class Initialized
DEBUG - 2011-07-11 11:15:05 --> Model Class Initialized
DEBUG - 2011-07-11 11:15:05 --> Model Class Initialized
DEBUG - 2011-07-11 11:15:05 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-07-11 11:15:05 --> Database Driver Class Initialized
DEBUG - 2011-07-11 11:15:06 --> File loaded: application/views/table/main.php
DEBUG - 2011-07-11 11:15:06 --> Helper loaded: url_helper
DEBUG - 2011-07-11 11:15:06 --> File loaded: application/views/common/header.php
DEBUG - 2011-07-11 11:15:06 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-07-11 11:15:06 --> File loaded: application/views/common/footer.php
DEBUG - 2011-07-11 11:15:06 --> File loaded: application/views/layout/main.php
DEBUG - 2011-07-11 11:15:06 --> Final output sent to browser
DEBUG - 2011-07-11 11:15:06 --> Total execution time: 1.4028
DEBUG - 2011-07-11 11:15:12 --> Config Class Initialized
DEBUG - 2011-07-11 11:15:12 --> Hooks Class Initialized
DEBUG - 2011-07-11 11:15:12 --> Utf8 Class Initialized
DEBUG - 2011-07-11 11:15:12 --> UTF-8 Support Enabled
DEBUG - 2011-07-11 11:15:12 --> URI Class Initialized
DEBUG - 2011-07-11 11:15:12 --> Router Class Initialized
DEBUG - 2011-07-11 11:15:12 --> Output Class Initialized
DEBUG - 2011-07-11 11:15:12 --> Input Class Initialized
DEBUG - 2011-07-11 11:15:12 --> Global POST and COOKIE data sanitized
DEBUG - 2011-07-11 11:15:12 --> Language Class Initialized
DEBUG - 2011-07-11 11:15:12 --> Loader Class Initialized
DEBUG - 2011-07-11 11:15:12 --> Controller Class Initialized
DEBUG - 2011-07-11 11:15:12 --> Model Class Initialized
DEBUG - 2011-07-11 11:15:12 --> Model Class Initialized
DEBUG - 2011-07-11 11:15:12 --> Model Class Initialized
DEBUG - 2011-07-11 11:15:12 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-07-11 11:15:12 --> Database Driver Class Initialized
DEBUG - 2011-07-11 11:15:12 --> File loaded: application/views/table/main.php
DEBUG - 2011-07-11 11:15:12 --> Helper loaded: url_helper
DEBUG - 2011-07-11 11:15:12 --> File loaded: application/views/common/header.php
DEBUG - 2011-07-11 11:15:12 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-07-11 11:15:12 --> File loaded: application/views/common/footer.php
DEBUG - 2011-07-11 11:15:12 --> File loaded: application/views/layout/main.php
DEBUG - 2011-07-11 11:15:12 --> Final output sent to browser
DEBUG - 2011-07-11 11:15:12 --> Total execution time: 0.0502
DEBUG - 2011-07-11 11:15:23 --> Config Class Initialized
DEBUG - 2011-07-11 11:15:23 --> Hooks Class Initialized
DEBUG - 2011-07-11 11:15:23 --> Utf8 Class Initialized
DEBUG - 2011-07-11 11:15:23 --> UTF-8 Support Enabled
DEBUG - 2011-07-11 11:15:23 --> URI Class Initialized
DEBUG - 2011-07-11 11:15:23 --> Router Class Initialized
DEBUG - 2011-07-11 11:15:23 --> Output Class Initialized
DEBUG - 2011-07-11 11:15:23 --> Input Class Initialized
DEBUG - 2011-07-11 11:15:23 --> Global POST and COOKIE data sanitized
DEBUG - 2011-07-11 11:15:23 --> Language Class Initialized
DEBUG - 2011-07-11 11:15:23 --> Loader Class Initialized
DEBUG - 2011-07-11 11:15:23 --> Controller Class Initialized
DEBUG - 2011-07-11 11:15:23 --> Model Class Initialized
DEBUG - 2011-07-11 11:15:23 --> Model Class Initialized
DEBUG - 2011-07-11 11:15:23 --> Model Class Initialized
DEBUG - 2011-07-11 11:15:23 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-07-11 11:15:23 --> Database Driver Class Initialized
DEBUG - 2011-07-11 11:15:23 --> File loaded: application/views/table/main.php
DEBUG - 2011-07-11 11:15:23 --> Helper loaded: url_helper
DEBUG - 2011-07-11 11:15:23 --> File loaded: application/views/common/header.php
DEBUG - 2011-07-11 11:15:23 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-07-11 11:15:23 --> File loaded: application/views/common/footer.php
DEBUG - 2011-07-11 11:15:23 --> File loaded: application/views/layout/main.php
DEBUG - 2011-07-11 11:15:23 --> Final output sent to browser
DEBUG - 2011-07-11 11:15:23 --> Total execution time: 0.2227
DEBUG - 2011-07-11 11:15:31 --> Config Class Initialized
DEBUG - 2011-07-11 11:15:31 --> Hooks Class Initialized
DEBUG - 2011-07-11 11:15:31 --> Utf8 Class Initialized
DEBUG - 2011-07-11 11:15:31 --> UTF-8 Support Enabled
DEBUG - 2011-07-11 11:15:31 --> URI Class Initialized
DEBUG - 2011-07-11 11:15:31 --> Router Class Initialized
DEBUG - 2011-07-11 11:15:31 --> Output Class Initialized
DEBUG - 2011-07-11 11:15:31 --> Input Class Initialized
DEBUG - 2011-07-11 11:15:31 --> Global POST and COOKIE data sanitized
DEBUG - 2011-07-11 11:15:31 --> Language Class Initialized
DEBUG - 2011-07-11 11:15:31 --> Loader Class Initialized
DEBUG - 2011-07-11 11:15:31 --> Controller Class Initialized
DEBUG - 2011-07-11 11:15:31 --> Model Class Initialized
DEBUG - 2011-07-11 11:15:31 --> Model Class Initialized
DEBUG - 2011-07-11 11:15:31 --> Model Class Initialized
DEBUG - 2011-07-11 11:15:31 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-07-11 11:15:31 --> Database Driver Class Initialized
DEBUG - 2011-07-11 11:15:32 --> File loaded: application/views/table/main.php
DEBUG - 2011-07-11 11:15:32 --> Helper loaded: url_helper
DEBUG - 2011-07-11 11:15:32 --> File loaded: application/views/common/header.php
DEBUG - 2011-07-11 11:15:32 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-07-11 11:15:32 --> File loaded: application/views/common/footer.php
DEBUG - 2011-07-11 11:15:32 --> File loaded: application/views/layout/main.php
DEBUG - 2011-07-11 11:15:32 --> Final output sent to browser
DEBUG - 2011-07-11 11:15:32 --> Total execution time: 0.4126
DEBUG - 2011-07-11 11:15:33 --> Config Class Initialized
DEBUG - 2011-07-11 11:15:33 --> Hooks Class Initialized
DEBUG - 2011-07-11 11:15:33 --> Utf8 Class Initialized
DEBUG - 2011-07-11 11:15:33 --> UTF-8 Support Enabled
DEBUG - 2011-07-11 11:15:33 --> URI Class Initialized
DEBUG - 2011-07-11 11:15:33 --> Router Class Initialized
DEBUG - 2011-07-11 11:15:33 --> Output Class Initialized
DEBUG - 2011-07-11 11:15:33 --> Input Class Initialized
DEBUG - 2011-07-11 11:15:33 --> Global POST and COOKIE data sanitized
DEBUG - 2011-07-11 11:15:33 --> Language Class Initialized
DEBUG - 2011-07-11 11:15:33 --> Loader Class Initialized
DEBUG - 2011-07-11 11:15:33 --> Controller Class Initialized
DEBUG - 2011-07-11 11:15:33 --> Model Class Initialized
DEBUG - 2011-07-11 11:15:33 --> Model Class Initialized
DEBUG - 2011-07-11 11:15:33 --> Model Class Initialized
DEBUG - 2011-07-11 11:15:33 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-07-11 11:15:33 --> Database Driver Class Initialized
DEBUG - 2011-07-11 11:15:33 --> File loaded: application/views/table/main.php
DEBUG - 2011-07-11 11:15:33 --> Helper loaded: url_helper
DEBUG - 2011-07-11 11:15:33 --> File loaded: application/views/common/header.php
DEBUG - 2011-07-11 11:15:33 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-07-11 11:15:33 --> File loaded: application/views/common/footer.php
DEBUG - 2011-07-11 11:15:33 --> File loaded: application/views/layout/main.php
DEBUG - 2011-07-11 11:15:33 --> Final output sent to browser
DEBUG - 2011-07-11 11:15:33 --> Total execution time: 0.0954
DEBUG - 2011-07-11 11:15:54 --> Config Class Initialized
DEBUG - 2011-07-11 11:15:54 --> Hooks Class Initialized
DEBUG - 2011-07-11 11:15:54 --> Utf8 Class Initialized
DEBUG - 2011-07-11 11:15:54 --> UTF-8 Support Enabled
DEBUG - 2011-07-11 11:15:54 --> URI Class Initialized
DEBUG - 2011-07-11 11:15:54 --> Router Class Initialized
DEBUG - 2011-07-11 11:15:54 --> Output Class Initialized
DEBUG - 2011-07-11 11:15:54 --> Input Class Initialized
DEBUG - 2011-07-11 11:15:54 --> Global POST and COOKIE data sanitized
DEBUG - 2011-07-11 11:15:54 --> Language Class Initialized
DEBUG - 2011-07-11 11:15:54 --> Loader Class Initialized
DEBUG - 2011-07-11 11:15:54 --> Controller Class Initialized
DEBUG - 2011-07-11 11:15:54 --> Model Class Initialized
DEBUG - 2011-07-11 11:15:54 --> Model Class Initialized
DEBUG - 2011-07-11 11:15:54 --> Model Class Initialized
DEBUG - 2011-07-11 11:15:54 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-07-11 11:15:54 --> Database Driver Class Initialized
DEBUG - 2011-07-11 11:15:54 --> File loaded: application/views/table/main.php
DEBUG - 2011-07-11 11:15:54 --> Helper loaded: url_helper
DEBUG - 2011-07-11 11:15:54 --> File loaded: application/views/common/header.php
DEBUG - 2011-07-11 11:15:54 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-07-11 11:15:54 --> File loaded: application/views/common/footer.php
DEBUG - 2011-07-11 11:15:54 --> File loaded: application/views/layout/main.php
DEBUG - 2011-07-11 11:15:54 --> Final output sent to browser
DEBUG - 2011-07-11 11:15:54 --> Total execution time: 0.0530
DEBUG - 2011-07-11 11:16:00 --> Config Class Initialized
DEBUG - 2011-07-11 11:16:00 --> Hooks Class Initialized
DEBUG - 2011-07-11 11:16:00 --> Utf8 Class Initialized
DEBUG - 2011-07-11 11:16:00 --> UTF-8 Support Enabled
DEBUG - 2011-07-11 11:16:00 --> URI Class Initialized
DEBUG - 2011-07-11 11:16:00 --> Router Class Initialized
DEBUG - 2011-07-11 11:16:00 --> Output Class Initialized
DEBUG - 2011-07-11 11:16:00 --> Input Class Initialized
DEBUG - 2011-07-11 11:16:00 --> Global POST and COOKIE data sanitized
DEBUG - 2011-07-11 11:16:00 --> Language Class Initialized
DEBUG - 2011-07-11 11:16:00 --> Loader Class Initialized
DEBUG - 2011-07-11 11:16:00 --> Controller Class Initialized
DEBUG - 2011-07-11 11:16:00 --> Model Class Initialized
DEBUG - 2011-07-11 11:16:00 --> Model Class Initialized
DEBUG - 2011-07-11 11:16:00 --> Model Class Initialized
DEBUG - 2011-07-11 11:16:00 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-07-11 11:16:00 --> Database Driver Class Initialized
DEBUG - 2011-07-11 11:16:00 --> File loaded: application/views/table/main.php
DEBUG - 2011-07-11 11:16:00 --> Helper loaded: url_helper
DEBUG - 2011-07-11 11:16:00 --> File loaded: application/views/common/header.php
DEBUG - 2011-07-11 11:16:00 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-07-11 11:16:00 --> File loaded: application/views/common/footer.php
DEBUG - 2011-07-11 11:16:00 --> File loaded: application/views/layout/main.php
DEBUG - 2011-07-11 11:16:00 --> Final output sent to browser
DEBUG - 2011-07-11 11:16:00 --> Total execution time: 0.0487
DEBUG - 2011-07-11 11:23:03 --> Config Class Initialized
DEBUG - 2011-07-11 11:23:03 --> Hooks Class Initialized
DEBUG - 2011-07-11 11:23:03 --> Utf8 Class Initialized
DEBUG - 2011-07-11 11:23:03 --> UTF-8 Support Enabled
DEBUG - 2011-07-11 11:23:03 --> URI Class Initialized
DEBUG - 2011-07-11 11:23:03 --> Router Class Initialized
DEBUG - 2011-07-11 11:23:03 --> Output Class Initialized
DEBUG - 2011-07-11 11:23:03 --> Input Class Initialized
DEBUG - 2011-07-11 11:23:03 --> Global POST and COOKIE data sanitized
DEBUG - 2011-07-11 11:23:03 --> Language Class Initialized
DEBUG - 2011-07-11 11:23:03 --> Loader Class Initialized
DEBUG - 2011-07-11 11:23:03 --> Controller Class Initialized
ERROR - 2011-07-11 11:23:03 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-07-11 11:23:03 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-07-11 11:23:03 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-07-11 11:23:03 --> Model Class Initialized
DEBUG - 2011-07-11 11:23:03 --> Model Class Initialized
DEBUG - 2011-07-11 11:23:03 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-07-11 11:23:03 --> Database Driver Class Initialized
DEBUG - 2011-07-11 11:23:03 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-07-11 11:23:03 --> Helper loaded: url_helper
DEBUG - 2011-07-11 11:23:03 --> File loaded: application/views/common/header.php
DEBUG - 2011-07-11 11:23:03 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-07-11 11:23:03 --> File loaded: application/views/common/footer.php
DEBUG - 2011-07-11 11:23:03 --> File loaded: application/views/layout/main.php
DEBUG - 2011-07-11 11:23:03 --> Final output sent to browser
DEBUG - 2011-07-11 11:23:03 --> Total execution time: 0.1596
DEBUG - 2011-07-11 11:23:04 --> Config Class Initialized
DEBUG - 2011-07-11 11:23:04 --> Hooks Class Initialized
DEBUG - 2011-07-11 11:23:04 --> Utf8 Class Initialized
DEBUG - 2011-07-11 11:23:04 --> UTF-8 Support Enabled
DEBUG - 2011-07-11 11:23:04 --> URI Class Initialized
DEBUG - 2011-07-11 11:23:04 --> Router Class Initialized
DEBUG - 2011-07-11 11:23:04 --> Output Class Initialized
DEBUG - 2011-07-11 11:23:04 --> Input Class Initialized
DEBUG - 2011-07-11 11:23:04 --> Global POST and COOKIE data sanitized
DEBUG - 2011-07-11 11:23:04 --> Language Class Initialized
DEBUG - 2011-07-11 11:23:04 --> Loader Class Initialized
DEBUG - 2011-07-11 11:23:04 --> Controller Class Initialized
DEBUG - 2011-07-11 11:23:04 --> Model Class Initialized
DEBUG - 2011-07-11 11:23:04 --> Model Class Initialized
DEBUG - 2011-07-11 11:23:04 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-07-11 11:23:04 --> Database Driver Class Initialized
DEBUG - 2011-07-11 11:23:04 --> Final output sent to browser
DEBUG - 2011-07-11 11:23:04 --> Total execution time: 0.7036
DEBUG - 2011-07-11 11:23:06 --> Config Class Initialized
DEBUG - 2011-07-11 11:23:06 --> Hooks Class Initialized
DEBUG - 2011-07-11 11:23:06 --> Utf8 Class Initialized
DEBUG - 2011-07-11 11:23:06 --> UTF-8 Support Enabled
DEBUG - 2011-07-11 11:23:06 --> URI Class Initialized
DEBUG - 2011-07-11 11:23:06 --> Router Class Initialized
ERROR - 2011-07-11 11:23:06 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-07-11 11:23:06 --> Config Class Initialized
DEBUG - 2011-07-11 11:23:06 --> Hooks Class Initialized
DEBUG - 2011-07-11 11:23:06 --> Utf8 Class Initialized
DEBUG - 2011-07-11 11:23:06 --> UTF-8 Support Enabled
DEBUG - 2011-07-11 11:23:06 --> URI Class Initialized
DEBUG - 2011-07-11 11:23:06 --> Router Class Initialized
ERROR - 2011-07-11 11:23:06 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-07-11 13:03:57 --> Config Class Initialized
DEBUG - 2011-07-11 13:03:57 --> Hooks Class Initialized
DEBUG - 2011-07-11 13:03:57 --> Utf8 Class Initialized
DEBUG - 2011-07-11 13:03:57 --> UTF-8 Support Enabled
DEBUG - 2011-07-11 13:03:57 --> URI Class Initialized
DEBUG - 2011-07-11 13:03:57 --> Router Class Initialized
ERROR - 2011-07-11 13:03:57 --> 404 Page Not Found --> robots.txt
DEBUG - 2011-07-11 13:03:57 --> Config Class Initialized
DEBUG - 2011-07-11 13:03:57 --> Hooks Class Initialized
DEBUG - 2011-07-11 13:03:57 --> Utf8 Class Initialized
DEBUG - 2011-07-11 13:03:57 --> UTF-8 Support Enabled
DEBUG - 2011-07-11 13:03:57 --> URI Class Initialized
DEBUG - 2011-07-11 13:03:57 --> Router Class Initialized
DEBUG - 2011-07-11 13:03:57 --> Output Class Initialized
DEBUG - 2011-07-11 13:03:57 --> Input Class Initialized
DEBUG - 2011-07-11 13:03:57 --> Global POST and COOKIE data sanitized
DEBUG - 2011-07-11 13:03:57 --> Language Class Initialized
DEBUG - 2011-07-11 13:03:57 --> Loader Class Initialized
DEBUG - 2011-07-11 13:03:57 --> Controller Class Initialized
ERROR - 2011-07-11 13:03:57 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-07-11 13:03:57 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-07-11 13:03:57 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-07-11 13:03:57 --> Model Class Initialized
DEBUG - 2011-07-11 13:03:57 --> Model Class Initialized
DEBUG - 2011-07-11 13:03:57 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-07-11 13:03:57 --> Database Driver Class Initialized
DEBUG - 2011-07-11 13:03:57 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-07-11 13:03:57 --> Helper loaded: url_helper
DEBUG - 2011-07-11 13:03:57 --> File loaded: application/views/common/header.php
DEBUG - 2011-07-11 13:03:57 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-07-11 13:03:57 --> File loaded: application/views/common/footer.php
DEBUG - 2011-07-11 13:03:57 --> File loaded: application/views/layout/main.php
DEBUG - 2011-07-11 13:03:57 --> Final output sent to browser
DEBUG - 2011-07-11 13:03:57 --> Total execution time: 0.2583
DEBUG - 2011-07-11 14:57:29 --> Config Class Initialized
DEBUG - 2011-07-11 14:57:29 --> Hooks Class Initialized
DEBUG - 2011-07-11 14:57:29 --> Utf8 Class Initialized
DEBUG - 2011-07-11 14:57:29 --> UTF-8 Support Enabled
DEBUG - 2011-07-11 14:57:29 --> URI Class Initialized
DEBUG - 2011-07-11 14:57:29 --> Router Class Initialized
DEBUG - 2011-07-11 14:57:29 --> Output Class Initialized
DEBUG - 2011-07-11 14:57:29 --> Input Class Initialized
DEBUG - 2011-07-11 14:57:29 --> Global POST and COOKIE data sanitized
DEBUG - 2011-07-11 14:57:29 --> Language Class Initialized
DEBUG - 2011-07-11 14:57:29 --> Loader Class Initialized
DEBUG - 2011-07-11 14:57:29 --> Controller Class Initialized
DEBUG - 2011-07-11 14:57:29 --> Model Class Initialized
DEBUG - 2011-07-11 14:57:29 --> Model Class Initialized
DEBUG - 2011-07-11 14:57:30 --> Model Class Initialized
DEBUG - 2011-07-11 14:57:30 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-07-11 14:57:30 --> Database Driver Class Initialized
DEBUG - 2011-07-11 14:57:30 --> File loaded: application/views/table/main.php
DEBUG - 2011-07-11 14:57:30 --> Helper loaded: url_helper
DEBUG - 2011-07-11 14:57:30 --> File loaded: application/views/common/header.php
DEBUG - 2011-07-11 14:57:30 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-07-11 14:57:30 --> File loaded: application/views/common/footer.php
DEBUG - 2011-07-11 14:57:30 --> File loaded: application/views/layout/main.php
DEBUG - 2011-07-11 14:57:30 --> Final output sent to browser
DEBUG - 2011-07-11 14:57:30 --> Total execution time: 0.5525
DEBUG - 2011-07-11 16:39:05 --> Config Class Initialized
DEBUG - 2011-07-11 16:39:05 --> Hooks Class Initialized
DEBUG - 2011-07-11 16:39:05 --> Utf8 Class Initialized
DEBUG - 2011-07-11 16:39:05 --> UTF-8 Support Enabled
DEBUG - 2011-07-11 16:39:05 --> URI Class Initialized
DEBUG - 2011-07-11 16:39:05 --> Router Class Initialized
DEBUG - 2011-07-11 16:39:05 --> Output Class Initialized
DEBUG - 2011-07-11 16:39:05 --> Input Class Initialized
DEBUG - 2011-07-11 16:39:05 --> Global POST and COOKIE data sanitized
DEBUG - 2011-07-11 16:39:05 --> Language Class Initialized
DEBUG - 2011-07-11 16:39:05 --> Loader Class Initialized
DEBUG - 2011-07-11 16:39:05 --> Controller Class Initialized
ERROR - 2011-07-11 16:39:05 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-07-11 16:39:05 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-07-11 16:39:05 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-07-11 16:39:05 --> Model Class Initialized
DEBUG - 2011-07-11 16:39:05 --> Model Class Initialized
DEBUG - 2011-07-11 16:39:05 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-07-11 16:39:05 --> Database Driver Class Initialized
DEBUG - 2011-07-11 16:39:05 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-07-11 16:39:05 --> Helper loaded: url_helper
DEBUG - 2011-07-11 16:39:05 --> File loaded: application/views/common/header.php
DEBUG - 2011-07-11 16:39:06 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-07-11 16:39:06 --> File loaded: application/views/common/footer.php
DEBUG - 2011-07-11 16:39:06 --> File loaded: application/views/layout/main.php
DEBUG - 2011-07-11 16:39:06 --> Final output sent to browser
DEBUG - 2011-07-11 16:39:06 --> Total execution time: 0.9688
DEBUG - 2011-07-11 16:39:06 --> Config Class Initialized
DEBUG - 2011-07-11 16:39:06 --> Hooks Class Initialized
DEBUG - 2011-07-11 16:39:06 --> Utf8 Class Initialized
DEBUG - 2011-07-11 16:39:06 --> UTF-8 Support Enabled
DEBUG - 2011-07-11 16:39:06 --> URI Class Initialized
DEBUG - 2011-07-11 16:39:06 --> Router Class Initialized
DEBUG - 2011-07-11 16:39:06 --> Output Class Initialized
DEBUG - 2011-07-11 16:39:06 --> Input Class Initialized
DEBUG - 2011-07-11 16:39:06 --> Global POST and COOKIE data sanitized
DEBUG - 2011-07-11 16:39:06 --> Language Class Initialized
DEBUG - 2011-07-11 16:39:06 --> Loader Class Initialized
DEBUG - 2011-07-11 16:39:06 --> Controller Class Initialized
DEBUG - 2011-07-11 16:39:06 --> Model Class Initialized
DEBUG - 2011-07-11 16:39:06 --> Model Class Initialized
DEBUG - 2011-07-11 16:39:06 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-07-11 16:39:06 --> Database Driver Class Initialized
DEBUG - 2011-07-11 16:39:08 --> Final output sent to browser
DEBUG - 2011-07-11 16:39:08 --> Total execution time: 1.3901
DEBUG - 2011-07-11 16:39:17 --> Config Class Initialized
DEBUG - 2011-07-11 16:39:17 --> Hooks Class Initialized
DEBUG - 2011-07-11 16:39:17 --> Utf8 Class Initialized
DEBUG - 2011-07-11 16:39:17 --> UTF-8 Support Enabled
DEBUG - 2011-07-11 16:39:17 --> URI Class Initialized
DEBUG - 2011-07-11 16:39:17 --> Router Class Initialized
ERROR - 2011-07-11 16:39:17 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-07-11 16:39:18 --> Config Class Initialized
DEBUG - 2011-07-11 16:39:18 --> Hooks Class Initialized
DEBUG - 2011-07-11 16:39:18 --> Utf8 Class Initialized
DEBUG - 2011-07-11 16:39:18 --> UTF-8 Support Enabled
DEBUG - 2011-07-11 16:39:18 --> URI Class Initialized
DEBUG - 2011-07-11 16:39:18 --> Router Class Initialized
ERROR - 2011-07-11 16:39:18 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-07-11 17:30:42 --> Config Class Initialized
DEBUG - 2011-07-11 17:30:42 --> Hooks Class Initialized
DEBUG - 2011-07-11 17:30:42 --> Utf8 Class Initialized
DEBUG - 2011-07-11 17:30:42 --> UTF-8 Support Enabled
DEBUG - 2011-07-11 17:30:42 --> URI Class Initialized
DEBUG - 2011-07-11 17:30:42 --> Router Class Initialized
DEBUG - 2011-07-11 17:30:42 --> Output Class Initialized
DEBUG - 2011-07-11 17:30:42 --> Input Class Initialized
DEBUG - 2011-07-11 17:30:42 --> Global POST and COOKIE data sanitized
DEBUG - 2011-07-11 17:30:42 --> Language Class Initialized
DEBUG - 2011-07-11 17:30:42 --> Loader Class Initialized
DEBUG - 2011-07-11 17:30:42 --> Controller Class Initialized
DEBUG - 2011-07-11 17:30:42 --> Model Class Initialized
DEBUG - 2011-07-11 17:30:42 --> Model Class Initialized
DEBUG - 2011-07-11 17:30:42 --> Model Class Initialized
DEBUG - 2011-07-11 17:30:42 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-07-11 17:30:42 --> Database Driver Class Initialized
DEBUG - 2011-07-11 17:30:43 --> File loaded: application/views/table/main.php
DEBUG - 2011-07-11 17:30:43 --> Helper loaded: url_helper
DEBUG - 2011-07-11 17:30:43 --> File loaded: application/views/common/header.php
DEBUG - 2011-07-11 17:30:43 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-07-11 17:30:43 --> File loaded: application/views/common/footer.php
DEBUG - 2011-07-11 17:30:43 --> File loaded: application/views/layout/main.php
DEBUG - 2011-07-11 17:30:43 --> Final output sent to browser
DEBUG - 2011-07-11 17:30:43 --> Total execution time: 1.1479
DEBUG - 2011-07-11 17:30:47 --> Config Class Initialized
DEBUG - 2011-07-11 17:30:47 --> Hooks Class Initialized
DEBUG - 2011-07-11 17:30:47 --> Utf8 Class Initialized
DEBUG - 2011-07-11 17:30:47 --> UTF-8 Support Enabled
DEBUG - 2011-07-11 17:30:47 --> URI Class Initialized
DEBUG - 2011-07-11 17:30:47 --> Router Class Initialized
ERROR - 2011-07-11 17:30:47 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-07-11 17:30:47 --> Config Class Initialized
DEBUG - 2011-07-11 17:30:47 --> Hooks Class Initialized
DEBUG - 2011-07-11 17:30:47 --> Utf8 Class Initialized
DEBUG - 2011-07-11 17:30:47 --> UTF-8 Support Enabled
DEBUG - 2011-07-11 17:30:47 --> URI Class Initialized
DEBUG - 2011-07-11 17:30:47 --> Router Class Initialized
ERROR - 2011-07-11 17:30:47 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-07-11 17:30:47 --> Config Class Initialized
DEBUG - 2011-07-11 17:30:47 --> Hooks Class Initialized
DEBUG - 2011-07-11 17:30:47 --> Utf8 Class Initialized
DEBUG - 2011-07-11 17:30:47 --> UTF-8 Support Enabled
DEBUG - 2011-07-11 17:30:47 --> URI Class Initialized
DEBUG - 2011-07-11 17:30:47 --> Router Class Initialized
ERROR - 2011-07-11 17:30:47 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-07-11 17:47:44 --> Config Class Initialized
DEBUG - 2011-07-11 17:47:44 --> Hooks Class Initialized
DEBUG - 2011-07-11 17:47:44 --> Utf8 Class Initialized
DEBUG - 2011-07-11 17:47:44 --> UTF-8 Support Enabled
DEBUG - 2011-07-11 17:47:44 --> URI Class Initialized
DEBUG - 2011-07-11 17:47:44 --> Router Class Initialized
DEBUG - 2011-07-11 17:47:44 --> Output Class Initialized
DEBUG - 2011-07-11 17:47:44 --> Input Class Initialized
DEBUG - 2011-07-11 17:47:44 --> Global POST and COOKIE data sanitized
DEBUG - 2011-07-11 17:47:44 --> Language Class Initialized
DEBUG - 2011-07-11 17:47:44 --> Loader Class Initialized
DEBUG - 2011-07-11 17:47:44 --> Controller Class Initialized
DEBUG - 2011-07-11 17:47:44 --> Model Class Initialized
DEBUG - 2011-07-11 17:47:44 --> Model Class Initialized
DEBUG - 2011-07-11 17:47:44 --> Model Class Initialized
DEBUG - 2011-07-11 17:47:44 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-07-11 17:47:44 --> Database Driver Class Initialized
DEBUG - 2011-07-11 17:47:44 --> File loaded: application/views/table/main.php
DEBUG - 2011-07-11 17:47:44 --> Helper loaded: url_helper
DEBUG - 2011-07-11 17:47:44 --> File loaded: application/views/common/header.php
DEBUG - 2011-07-11 17:47:44 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-07-11 17:47:44 --> File loaded: application/views/common/footer.php
DEBUG - 2011-07-11 17:47:44 --> File loaded: application/views/layout/main.php
DEBUG - 2011-07-11 17:47:44 --> Final output sent to browser
DEBUG - 2011-07-11 17:47:44 --> Total execution time: 0.6436
DEBUG - 2011-07-11 17:47:45 --> Config Class Initialized
DEBUG - 2011-07-11 17:47:45 --> Hooks Class Initialized
DEBUG - 2011-07-11 17:47:45 --> Utf8 Class Initialized
DEBUG - 2011-07-11 17:47:45 --> UTF-8 Support Enabled
DEBUG - 2011-07-11 17:47:45 --> URI Class Initialized
DEBUG - 2011-07-11 17:47:45 --> Router Class Initialized
DEBUG - 2011-07-11 17:47:45 --> Output Class Initialized
DEBUG - 2011-07-11 17:47:45 --> Input Class Initialized
DEBUG - 2011-07-11 17:47:45 --> Global POST and COOKIE data sanitized
DEBUG - 2011-07-11 17:47:45 --> Language Class Initialized
DEBUG - 2011-07-11 17:47:45 --> Loader Class Initialized
DEBUG - 2011-07-11 17:47:45 --> Controller Class Initialized
ERROR - 2011-07-11 17:47:45 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-07-11 17:47:45 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-07-11 17:47:45 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-07-11 17:47:45 --> Model Class Initialized
DEBUG - 2011-07-11 17:47:45 --> Model Class Initialized
DEBUG - 2011-07-11 17:47:45 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-07-11 17:47:45 --> Database Driver Class Initialized
DEBUG - 2011-07-11 17:47:45 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-07-11 17:47:45 --> Helper loaded: url_helper
DEBUG - 2011-07-11 17:47:45 --> File loaded: application/views/common/header.php
DEBUG - 2011-07-11 17:47:45 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-07-11 17:47:45 --> File loaded: application/views/common/footer.php
DEBUG - 2011-07-11 17:47:45 --> File loaded: application/views/layout/main.php
DEBUG - 2011-07-11 17:47:45 --> Final output sent to browser
DEBUG - 2011-07-11 17:47:45 --> Total execution time: 0.1249
DEBUG - 2011-07-11 17:52:32 --> Config Class Initialized
DEBUG - 2011-07-11 17:52:32 --> Hooks Class Initialized
DEBUG - 2011-07-11 17:52:32 --> Utf8 Class Initialized
DEBUG - 2011-07-11 17:52:32 --> UTF-8 Support Enabled
DEBUG - 2011-07-11 17:52:32 --> URI Class Initialized
DEBUG - 2011-07-11 17:52:32 --> Router Class Initialized
ERROR - 2011-07-11 17:52:32 --> 404 Page Not Found --> robots.txt
DEBUG - 2011-07-11 17:52:32 --> Config Class Initialized
DEBUG - 2011-07-11 17:52:32 --> Hooks Class Initialized
DEBUG - 2011-07-11 17:52:32 --> Utf8 Class Initialized
DEBUG - 2011-07-11 17:52:32 --> UTF-8 Support Enabled
DEBUG - 2011-07-11 17:52:32 --> URI Class Initialized
DEBUG - 2011-07-11 17:52:32 --> Router Class Initialized
DEBUG - 2011-07-11 17:52:32 --> Output Class Initialized
DEBUG - 2011-07-11 17:52:32 --> Input Class Initialized
DEBUG - 2011-07-11 17:52:32 --> Global POST and COOKIE data sanitized
DEBUG - 2011-07-11 17:52:32 --> Language Class Initialized
DEBUG - 2011-07-11 17:52:32 --> Loader Class Initialized
DEBUG - 2011-07-11 17:52:32 --> Controller Class Initialized
DEBUG - 2011-07-11 17:52:32 --> Model Class Initialized
DEBUG - 2011-07-11 17:52:32 --> Model Class Initialized
DEBUG - 2011-07-11 17:52:32 --> Model Class Initialized
DEBUG - 2011-07-11 17:52:32 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-07-11 17:52:32 --> Database Driver Class Initialized
DEBUG - 2011-07-11 17:52:32 --> File loaded: application/views/table/main.php
DEBUG - 2011-07-11 17:52:32 --> Helper loaded: url_helper
DEBUG - 2011-07-11 17:52:32 --> File loaded: application/views/common/header.php
DEBUG - 2011-07-11 17:52:32 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-07-11 17:52:32 --> File loaded: application/views/common/footer.php
DEBUG - 2011-07-11 17:52:32 --> File loaded: application/views/layout/main.php
DEBUG - 2011-07-11 17:52:32 --> Final output sent to browser
DEBUG - 2011-07-11 17:52:32 --> Total execution time: 0.1537
DEBUG - 2011-07-11 19:02:33 --> Config Class Initialized
DEBUG - 2011-07-11 19:02:33 --> Hooks Class Initialized
DEBUG - 2011-07-11 19:02:34 --> Utf8 Class Initialized
DEBUG - 2011-07-11 19:02:34 --> UTF-8 Support Enabled
DEBUG - 2011-07-11 19:02:34 --> URI Class Initialized
DEBUG - 2011-07-11 19:02:34 --> Router Class Initialized
ERROR - 2011-07-11 19:02:34 --> 404 Page Not Found --> robots.txt
DEBUG - 2011-07-11 21:21:54 --> Config Class Initialized
DEBUG - 2011-07-11 21:21:54 --> Hooks Class Initialized
DEBUG - 2011-07-11 21:21:54 --> Utf8 Class Initialized
DEBUG - 2011-07-11 21:21:54 --> UTF-8 Support Enabled
DEBUG - 2011-07-11 21:21:54 --> URI Class Initialized
DEBUG - 2011-07-11 21:21:54 --> Router Class Initialized
DEBUG - 2011-07-11 21:21:54 --> Output Class Initialized
DEBUG - 2011-07-11 21:21:54 --> Input Class Initialized
DEBUG - 2011-07-11 21:21:54 --> Global POST and COOKIE data sanitized
DEBUG - 2011-07-11 21:21:54 --> Language Class Initialized
DEBUG - 2011-07-11 21:21:54 --> Loader Class Initialized
DEBUG - 2011-07-11 21:21:54 --> Controller Class Initialized
ERROR - 2011-07-11 21:21:54 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-07-11 21:21:54 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-07-11 21:21:54 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-07-11 21:21:54 --> Model Class Initialized
DEBUG - 2011-07-11 21:21:55 --> Model Class Initialized
DEBUG - 2011-07-11 21:21:55 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-07-11 21:21:55 --> Database Driver Class Initialized
DEBUG - 2011-07-11 21:21:55 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-07-11 21:21:55 --> Helper loaded: url_helper
DEBUG - 2011-07-11 21:21:55 --> File loaded: application/views/common/header.php
DEBUG - 2011-07-11 21:21:55 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-07-11 21:21:55 --> File loaded: application/views/common/footer.php
DEBUG - 2011-07-11 21:21:55 --> File loaded: application/views/layout/main.php
DEBUG - 2011-07-11 21:21:55 --> Final output sent to browser
DEBUG - 2011-07-11 21:21:55 --> Total execution time: 0.4226
DEBUG - 2011-07-11 21:21:56 --> Config Class Initialized
DEBUG - 2011-07-11 21:21:56 --> Hooks Class Initialized
DEBUG - 2011-07-11 21:21:56 --> Utf8 Class Initialized
DEBUG - 2011-07-11 21:21:56 --> UTF-8 Support Enabled
DEBUG - 2011-07-11 21:21:56 --> URI Class Initialized
DEBUG - 2011-07-11 21:21:56 --> Router Class Initialized
DEBUG - 2011-07-11 21:21:56 --> Output Class Initialized
DEBUG - 2011-07-11 21:21:56 --> Input Class Initialized
DEBUG - 2011-07-11 21:21:56 --> Global POST and COOKIE data sanitized
DEBUG - 2011-07-11 21:21:56 --> Language Class Initialized
DEBUG - 2011-07-11 21:21:56 --> Loader Class Initialized
DEBUG - 2011-07-11 21:21:56 --> Controller Class Initialized
DEBUG - 2011-07-11 21:21:56 --> Model Class Initialized
DEBUG - 2011-07-11 21:21:56 --> Model Class Initialized
DEBUG - 2011-07-11 21:21:56 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-07-11 21:21:56 --> Database Driver Class Initialized
DEBUG - 2011-07-11 21:21:57 --> Final output sent to browser
DEBUG - 2011-07-11 21:21:57 --> Total execution time: 1.2531
DEBUG - 2011-07-11 21:21:58 --> Config Class Initialized
DEBUG - 2011-07-11 21:21:58 --> Hooks Class Initialized
DEBUG - 2011-07-11 21:21:58 --> Utf8 Class Initialized
DEBUG - 2011-07-11 21:21:58 --> UTF-8 Support Enabled
DEBUG - 2011-07-11 21:21:58 --> URI Class Initialized
DEBUG - 2011-07-11 21:21:58 --> Router Class Initialized
ERROR - 2011-07-11 21:21:58 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-07-11 21:21:58 --> Config Class Initialized
DEBUG - 2011-07-11 21:21:58 --> Hooks Class Initialized
DEBUG - 2011-07-11 21:21:58 --> Utf8 Class Initialized
DEBUG - 2011-07-11 21:21:58 --> UTF-8 Support Enabled
DEBUG - 2011-07-11 21:21:58 --> URI Class Initialized
DEBUG - 2011-07-11 21:21:58 --> Router Class Initialized
ERROR - 2011-07-11 21:21:58 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-07-11 21:21:59 --> Config Class Initialized
DEBUG - 2011-07-11 21:21:59 --> Hooks Class Initialized
DEBUG - 2011-07-11 21:21:59 --> Utf8 Class Initialized
DEBUG - 2011-07-11 21:21:59 --> UTF-8 Support Enabled
DEBUG - 2011-07-11 21:21:59 --> URI Class Initialized
DEBUG - 2011-07-11 21:21:59 --> Router Class Initialized
ERROR - 2011-07-11 21:21:59 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-07-11 21:22:22 --> Config Class Initialized
DEBUG - 2011-07-11 21:22:22 --> Hooks Class Initialized
DEBUG - 2011-07-11 21:22:22 --> Utf8 Class Initialized
DEBUG - 2011-07-11 21:22:22 --> UTF-8 Support Enabled
DEBUG - 2011-07-11 21:22:22 --> URI Class Initialized
DEBUG - 2011-07-11 21:22:22 --> Router Class Initialized
DEBUG - 2011-07-11 21:22:22 --> Output Class Initialized
DEBUG - 2011-07-11 21:22:22 --> Input Class Initialized
DEBUG - 2011-07-11 21:22:22 --> Global POST and COOKIE data sanitized
DEBUG - 2011-07-11 21:22:22 --> Language Class Initialized
DEBUG - 2011-07-11 21:22:22 --> Loader Class Initialized
DEBUG - 2011-07-11 21:22:22 --> Controller Class Initialized
ERROR - 2011-07-11 21:22:22 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-07-11 21:22:22 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-07-11 21:22:22 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-07-11 21:22:22 --> Model Class Initialized
DEBUG - 2011-07-11 21:22:22 --> Model Class Initialized
DEBUG - 2011-07-11 21:22:22 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-07-11 21:22:22 --> Database Driver Class Initialized
DEBUG - 2011-07-11 21:22:22 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-07-11 21:22:22 --> Helper loaded: url_helper
DEBUG - 2011-07-11 21:22:22 --> File loaded: application/views/common/header.php
DEBUG - 2011-07-11 21:22:22 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-07-11 21:22:22 --> File loaded: application/views/common/footer.php
DEBUG - 2011-07-11 21:22:22 --> File loaded: application/views/layout/main.php
DEBUG - 2011-07-11 21:22:22 --> Final output sent to browser
DEBUG - 2011-07-11 21:22:22 --> Total execution time: 0.0412
DEBUG - 2011-07-11 21:22:24 --> Config Class Initialized
DEBUG - 2011-07-11 21:22:24 --> Hooks Class Initialized
DEBUG - 2011-07-11 21:22:24 --> Utf8 Class Initialized
DEBUG - 2011-07-11 21:22:24 --> UTF-8 Support Enabled
DEBUG - 2011-07-11 21:22:24 --> URI Class Initialized
DEBUG - 2011-07-11 21:22:24 --> Router Class Initialized
DEBUG - 2011-07-11 21:22:24 --> Output Class Initialized
DEBUG - 2011-07-11 21:22:24 --> Input Class Initialized
DEBUG - 2011-07-11 21:22:24 --> Global POST and COOKIE data sanitized
DEBUG - 2011-07-11 21:22:24 --> Language Class Initialized
DEBUG - 2011-07-11 21:22:24 --> Loader Class Initialized
DEBUG - 2011-07-11 21:22:24 --> Controller Class Initialized
DEBUG - 2011-07-11 21:22:24 --> Model Class Initialized
DEBUG - 2011-07-11 21:22:24 --> Model Class Initialized
DEBUG - 2011-07-11 21:22:24 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-07-11 21:22:24 --> Database Driver Class Initialized
DEBUG - 2011-07-11 21:22:25 --> Final output sent to browser
DEBUG - 2011-07-11 21:22:25 --> Total execution time: 0.9896
DEBUG - 2011-07-11 21:22:36 --> Config Class Initialized
DEBUG - 2011-07-11 21:22:36 --> Hooks Class Initialized
DEBUG - 2011-07-11 21:22:36 --> Utf8 Class Initialized
DEBUG - 2011-07-11 21:22:36 --> UTF-8 Support Enabled
DEBUG - 2011-07-11 21:22:36 --> URI Class Initialized
DEBUG - 2011-07-11 21:22:36 --> Router Class Initialized
DEBUG - 2011-07-11 21:22:36 --> Output Class Initialized
DEBUG - 2011-07-11 21:22:36 --> Input Class Initialized
DEBUG - 2011-07-11 21:22:36 --> Global POST and COOKIE data sanitized
DEBUG - 2011-07-11 21:22:36 --> Language Class Initialized
DEBUG - 2011-07-11 21:22:36 --> Loader Class Initialized
DEBUG - 2011-07-11 21:22:36 --> Controller Class Initialized
ERROR - 2011-07-11 21:22:36 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-07-11 21:22:36 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-07-11 21:22:36 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-07-11 21:22:36 --> Model Class Initialized
DEBUG - 2011-07-11 21:22:36 --> Model Class Initialized
DEBUG - 2011-07-11 21:22:36 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-07-11 21:22:36 --> Database Driver Class Initialized
DEBUG - 2011-07-11 21:22:36 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-07-11 21:22:36 --> Helper loaded: url_helper
DEBUG - 2011-07-11 21:22:36 --> File loaded: application/views/common/header.php
DEBUG - 2011-07-11 21:22:36 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-07-11 21:22:36 --> File loaded: application/views/common/footer.php
DEBUG - 2011-07-11 21:22:36 --> File loaded: application/views/layout/main.php
DEBUG - 2011-07-11 21:22:36 --> Final output sent to browser
DEBUG - 2011-07-11 21:22:36 --> Total execution time: 0.0456
DEBUG - 2011-07-11 21:22:38 --> Config Class Initialized
DEBUG - 2011-07-11 21:22:38 --> Hooks Class Initialized
DEBUG - 2011-07-11 21:22:38 --> Utf8 Class Initialized
DEBUG - 2011-07-11 21:22:38 --> UTF-8 Support Enabled
DEBUG - 2011-07-11 21:22:38 --> URI Class Initialized
DEBUG - 2011-07-11 21:22:38 --> Router Class Initialized
DEBUG - 2011-07-11 21:22:38 --> Output Class Initialized
DEBUG - 2011-07-11 21:22:38 --> Input Class Initialized
DEBUG - 2011-07-11 21:22:38 --> Global POST and COOKIE data sanitized
DEBUG - 2011-07-11 21:22:38 --> Language Class Initialized
DEBUG - 2011-07-11 21:22:38 --> Loader Class Initialized
DEBUG - 2011-07-11 21:22:38 --> Controller Class Initialized
DEBUG - 2011-07-11 21:22:38 --> Model Class Initialized
DEBUG - 2011-07-11 21:22:38 --> Model Class Initialized
DEBUG - 2011-07-11 21:22:38 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-07-11 21:22:38 --> Database Driver Class Initialized
DEBUG - 2011-07-11 21:22:38 --> Final output sent to browser
DEBUG - 2011-07-11 21:22:38 --> Total execution time: 0.7140
DEBUG - 2011-07-11 21:22:46 --> Config Class Initialized
DEBUG - 2011-07-11 21:22:46 --> Hooks Class Initialized
DEBUG - 2011-07-11 21:22:46 --> Utf8 Class Initialized
DEBUG - 2011-07-11 21:22:46 --> UTF-8 Support Enabled
DEBUG - 2011-07-11 21:22:46 --> URI Class Initialized
DEBUG - 2011-07-11 21:22:46 --> Router Class Initialized
DEBUG - 2011-07-11 21:22:46 --> Output Class Initialized
DEBUG - 2011-07-11 21:22:46 --> Input Class Initialized
DEBUG - 2011-07-11 21:22:46 --> Global POST and COOKIE data sanitized
DEBUG - 2011-07-11 21:22:46 --> Language Class Initialized
DEBUG - 2011-07-11 21:22:46 --> Loader Class Initialized
DEBUG - 2011-07-11 21:22:46 --> Controller Class Initialized
ERROR - 2011-07-11 21:22:46 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-07-11 21:22:46 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-07-11 21:22:46 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-07-11 21:22:46 --> Model Class Initialized
DEBUG - 2011-07-11 21:22:46 --> Model Class Initialized
DEBUG - 2011-07-11 21:22:46 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-07-11 21:22:46 --> Database Driver Class Initialized
DEBUG - 2011-07-11 21:22:46 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-07-11 21:22:46 --> Helper loaded: url_helper
DEBUG - 2011-07-11 21:22:46 --> File loaded: application/views/common/header.php
DEBUG - 2011-07-11 21:22:46 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-07-11 21:22:46 --> File loaded: application/views/common/footer.php
DEBUG - 2011-07-11 21:22:46 --> File loaded: application/views/layout/main.php
DEBUG - 2011-07-11 21:22:46 --> Final output sent to browser
DEBUG - 2011-07-11 21:22:46 --> Total execution time: 0.0326
DEBUG - 2011-07-11 21:37:45 --> Config Class Initialized
DEBUG - 2011-07-11 21:37:45 --> Hooks Class Initialized
DEBUG - 2011-07-11 21:37:45 --> Utf8 Class Initialized
DEBUG - 2011-07-11 21:37:45 --> UTF-8 Support Enabled
DEBUG - 2011-07-11 21:37:45 --> URI Class Initialized
DEBUG - 2011-07-11 21:37:45 --> Router Class Initialized
DEBUG - 2011-07-11 21:37:45 --> Output Class Initialized
DEBUG - 2011-07-11 21:37:45 --> Input Class Initialized
DEBUG - 2011-07-11 21:37:45 --> Global POST and COOKIE data sanitized
DEBUG - 2011-07-11 21:37:45 --> Language Class Initialized
DEBUG - 2011-07-11 21:37:45 --> Loader Class Initialized
DEBUG - 2011-07-11 21:37:45 --> Controller Class Initialized
ERROR - 2011-07-11 21:37:45 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-07-11 21:37:45 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-07-11 21:37:45 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-07-11 21:37:45 --> Model Class Initialized
DEBUG - 2011-07-11 21:37:45 --> Model Class Initialized
DEBUG - 2011-07-11 21:37:45 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-07-11 21:37:45 --> Database Driver Class Initialized
DEBUG - 2011-07-11 21:37:45 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-07-11 21:37:45 --> Helper loaded: url_helper
DEBUG - 2011-07-11 21:37:45 --> File loaded: application/views/common/header.php
DEBUG - 2011-07-11 21:37:45 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-07-11 21:37:45 --> File loaded: application/views/common/footer.php
DEBUG - 2011-07-11 21:37:45 --> File loaded: application/views/layout/main.php
DEBUG - 2011-07-11 21:37:45 --> Final output sent to browser
DEBUG - 2011-07-11 21:37:45 --> Total execution time: 0.2490
DEBUG - 2011-07-11 21:37:48 --> Config Class Initialized
DEBUG - 2011-07-11 21:37:48 --> Hooks Class Initialized
DEBUG - 2011-07-11 21:37:48 --> Utf8 Class Initialized
DEBUG - 2011-07-11 21:37:48 --> UTF-8 Support Enabled
DEBUG - 2011-07-11 21:37:48 --> URI Class Initialized
DEBUG - 2011-07-11 21:37:48 --> Router Class Initialized
DEBUG - 2011-07-11 21:37:48 --> Output Class Initialized
DEBUG - 2011-07-11 21:37:48 --> Input Class Initialized
DEBUG - 2011-07-11 21:37:48 --> Global POST and COOKIE data sanitized
DEBUG - 2011-07-11 21:37:48 --> Language Class Initialized
DEBUG - 2011-07-11 21:37:48 --> Loader Class Initialized
DEBUG - 2011-07-11 21:37:48 --> Controller Class Initialized
DEBUG - 2011-07-11 21:37:48 --> Model Class Initialized
DEBUG - 2011-07-11 21:37:48 --> Model Class Initialized
DEBUG - 2011-07-11 21:37:48 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-07-11 21:37:48 --> Database Driver Class Initialized
DEBUG - 2011-07-11 21:37:49 --> Final output sent to browser
DEBUG - 2011-07-11 21:37:49 --> Total execution time: 0.7054
DEBUG - 2011-07-11 21:37:51 --> Config Class Initialized
DEBUG - 2011-07-11 21:37:51 --> Hooks Class Initialized
DEBUG - 2011-07-11 21:37:51 --> Utf8 Class Initialized
DEBUG - 2011-07-11 21:37:51 --> UTF-8 Support Enabled
DEBUG - 2011-07-11 21:37:51 --> URI Class Initialized
DEBUG - 2011-07-11 21:37:51 --> Router Class Initialized
ERROR - 2011-07-11 21:37:51 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-07-11 21:38:19 --> Config Class Initialized
DEBUG - 2011-07-11 21:38:19 --> Hooks Class Initialized
DEBUG - 2011-07-11 21:38:19 --> Utf8 Class Initialized
DEBUG - 2011-07-11 21:38:19 --> UTF-8 Support Enabled
DEBUG - 2011-07-11 21:38:19 --> URI Class Initialized
DEBUG - 2011-07-11 21:38:19 --> Router Class Initialized
DEBUG - 2011-07-11 21:38:19 --> Output Class Initialized
DEBUG - 2011-07-11 21:38:19 --> Input Class Initialized
DEBUG - 2011-07-11 21:38:19 --> Global POST and COOKIE data sanitized
DEBUG - 2011-07-11 21:38:19 --> Language Class Initialized
DEBUG - 2011-07-11 21:38:19 --> Loader Class Initialized
DEBUG - 2011-07-11 21:38:19 --> Controller Class Initialized
ERROR - 2011-07-11 21:38:19 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-07-11 21:38:19 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-07-11 21:38:19 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-07-11 21:38:19 --> Model Class Initialized
DEBUG - 2011-07-11 21:38:19 --> Model Class Initialized
DEBUG - 2011-07-11 21:38:19 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-07-11 21:38:19 --> Database Driver Class Initialized
DEBUG - 2011-07-11 21:38:19 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-07-11 21:38:19 --> Helper loaded: url_helper
DEBUG - 2011-07-11 21:38:19 --> File loaded: application/views/common/header.php
DEBUG - 2011-07-11 21:38:19 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-07-11 21:38:19 --> File loaded: application/views/common/footer.php
DEBUG - 2011-07-11 21:38:19 --> File loaded: application/views/layout/main.php
DEBUG - 2011-07-11 21:38:19 --> Final output sent to browser
DEBUG - 2011-07-11 21:38:19 --> Total execution time: 0.0287
DEBUG - 2011-07-11 21:38:20 --> Config Class Initialized
DEBUG - 2011-07-11 21:38:20 --> Hooks Class Initialized
DEBUG - 2011-07-11 21:38:20 --> Utf8 Class Initialized
DEBUG - 2011-07-11 21:38:20 --> UTF-8 Support Enabled
DEBUG - 2011-07-11 21:38:20 --> URI Class Initialized
DEBUG - 2011-07-11 21:38:20 --> Router Class Initialized
DEBUG - 2011-07-11 21:38:20 --> Output Class Initialized
DEBUG - 2011-07-11 21:38:20 --> Input Class Initialized
DEBUG - 2011-07-11 21:38:20 --> Global POST and COOKIE data sanitized
DEBUG - 2011-07-11 21:38:20 --> Language Class Initialized
DEBUG - 2011-07-11 21:38:20 --> Loader Class Initialized
DEBUG - 2011-07-11 21:38:20 --> Controller Class Initialized
ERROR - 2011-07-11 21:38:20 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-07-11 21:38:20 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-07-11 21:38:20 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-07-11 21:38:20 --> Model Class Initialized
DEBUG - 2011-07-11 21:38:20 --> Model Class Initialized
DEBUG - 2011-07-11 21:38:20 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-07-11 21:38:20 --> Database Driver Class Initialized
DEBUG - 2011-07-11 21:38:20 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-07-11 21:38:20 --> Helper loaded: url_helper
DEBUG - 2011-07-11 21:38:20 --> File loaded: application/views/common/header.php
DEBUG - 2011-07-11 21:38:20 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-07-11 21:38:20 --> File loaded: application/views/common/footer.php
DEBUG - 2011-07-11 21:38:20 --> File loaded: application/views/layout/main.php
DEBUG - 2011-07-11 21:38:20 --> Final output sent to browser
DEBUG - 2011-07-11 21:38:20 --> Total execution time: 0.0405
DEBUG - 2011-07-11 21:38:20 --> Config Class Initialized
DEBUG - 2011-07-11 21:38:20 --> Hooks Class Initialized
DEBUG - 2011-07-11 21:38:20 --> Utf8 Class Initialized
DEBUG - 2011-07-11 21:38:20 --> UTF-8 Support Enabled
DEBUG - 2011-07-11 21:38:20 --> URI Class Initialized
DEBUG - 2011-07-11 21:38:20 --> Router Class Initialized
DEBUG - 2011-07-11 21:38:20 --> Output Class Initialized
DEBUG - 2011-07-11 21:38:20 --> Input Class Initialized
DEBUG - 2011-07-11 21:38:20 --> Global POST and COOKIE data sanitized
DEBUG - 2011-07-11 21:38:20 --> Language Class Initialized
DEBUG - 2011-07-11 21:38:20 --> Loader Class Initialized
DEBUG - 2011-07-11 21:38:20 --> Controller Class Initialized
DEBUG - 2011-07-11 21:38:20 --> Model Class Initialized
DEBUG - 2011-07-11 21:38:20 --> Model Class Initialized
DEBUG - 2011-07-11 21:38:20 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-07-11 21:38:20 --> Database Driver Class Initialized
DEBUG - 2011-07-11 21:38:21 --> Final output sent to browser
DEBUG - 2011-07-11 21:38:21 --> Total execution time: 0.6906
DEBUG - 2011-07-11 21:38:22 --> Config Class Initialized
DEBUG - 2011-07-11 21:38:22 --> Hooks Class Initialized
DEBUG - 2011-07-11 21:38:22 --> Utf8 Class Initialized
DEBUG - 2011-07-11 21:38:22 --> UTF-8 Support Enabled
DEBUG - 2011-07-11 21:38:22 --> URI Class Initialized
DEBUG - 2011-07-11 21:38:22 --> Router Class Initialized
ERROR - 2011-07-11 21:38:22 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-07-11 21:38:41 --> Config Class Initialized
DEBUG - 2011-07-11 21:38:41 --> Hooks Class Initialized
DEBUG - 2011-07-11 21:38:41 --> Utf8 Class Initialized
DEBUG - 2011-07-11 21:38:41 --> UTF-8 Support Enabled
DEBUG - 2011-07-11 21:38:41 --> URI Class Initialized
DEBUG - 2011-07-11 21:38:41 --> Router Class Initialized
DEBUG - 2011-07-11 21:38:41 --> Output Class Initialized
DEBUG - 2011-07-11 21:38:41 --> Input Class Initialized
DEBUG - 2011-07-11 21:38:41 --> Global POST and COOKIE data sanitized
DEBUG - 2011-07-11 21:38:41 --> Language Class Initialized
DEBUG - 2011-07-11 21:38:41 --> Loader Class Initialized
DEBUG - 2011-07-11 21:38:41 --> Controller Class Initialized
ERROR - 2011-07-11 21:38:41 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-07-11 21:38:41 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-07-11 21:38:41 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-07-11 21:38:41 --> Model Class Initialized
DEBUG - 2011-07-11 21:38:41 --> Model Class Initialized
DEBUG - 2011-07-11 21:38:41 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-07-11 21:38:41 --> Database Driver Class Initialized
DEBUG - 2011-07-11 21:38:41 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-07-11 21:38:41 --> Helper loaded: url_helper
DEBUG - 2011-07-11 21:38:41 --> File loaded: application/views/common/header.php
DEBUG - 2011-07-11 21:38:41 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-07-11 21:38:41 --> File loaded: application/views/common/footer.php
DEBUG - 2011-07-11 21:38:41 --> File loaded: application/views/layout/main.php
DEBUG - 2011-07-11 21:38:41 --> Final output sent to browser
DEBUG - 2011-07-11 21:38:41 --> Total execution time: 0.0607
DEBUG - 2011-07-11 21:38:42 --> Config Class Initialized
DEBUG - 2011-07-11 21:38:42 --> Hooks Class Initialized
DEBUG - 2011-07-11 21:38:42 --> Utf8 Class Initialized
DEBUG - 2011-07-11 21:38:42 --> UTF-8 Support Enabled
DEBUG - 2011-07-11 21:38:42 --> URI Class Initialized
DEBUG - 2011-07-11 21:38:42 --> Router Class Initialized
DEBUG - 2011-07-11 21:38:42 --> Output Class Initialized
DEBUG - 2011-07-11 21:38:42 --> Input Class Initialized
DEBUG - 2011-07-11 21:38:42 --> Global POST and COOKIE data sanitized
DEBUG - 2011-07-11 21:38:42 --> Language Class Initialized
DEBUG - 2011-07-11 21:38:42 --> Loader Class Initialized
DEBUG - 2011-07-11 21:38:42 --> Controller Class Initialized
DEBUG - 2011-07-11 21:38:42 --> Model Class Initialized
DEBUG - 2011-07-11 21:38:42 --> Model Class Initialized
DEBUG - 2011-07-11 21:38:42 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-07-11 21:38:42 --> Database Driver Class Initialized
DEBUG - 2011-07-11 21:38:43 --> Final output sent to browser
DEBUG - 2011-07-11 21:38:43 --> Total execution time: 0.8033
DEBUG - 2011-07-11 21:38:45 --> Config Class Initialized
DEBUG - 2011-07-11 21:38:45 --> Hooks Class Initialized
DEBUG - 2011-07-11 21:38:45 --> Utf8 Class Initialized
DEBUG - 2011-07-11 21:38:45 --> UTF-8 Support Enabled
DEBUG - 2011-07-11 21:38:45 --> URI Class Initialized
DEBUG - 2011-07-11 21:38:45 --> Router Class Initialized
ERROR - 2011-07-11 21:38:45 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-07-11 23:59:55 --> Config Class Initialized
DEBUG - 2011-07-11 23:59:55 --> Hooks Class Initialized
DEBUG - 2011-07-11 23:59:55 --> Utf8 Class Initialized
DEBUG - 2011-07-11 23:59:55 --> UTF-8 Support Enabled
DEBUG - 2011-07-11 23:59:55 --> URI Class Initialized
DEBUG - 2011-07-11 23:59:55 --> Router Class Initialized
DEBUG - 2011-07-11 23:59:55 --> Output Class Initialized
DEBUG - 2011-07-11 23:59:55 --> Input Class Initialized
DEBUG - 2011-07-11 23:59:55 --> Global POST and COOKIE data sanitized
DEBUG - 2011-07-11 23:59:55 --> Language Class Initialized
DEBUG - 2011-07-11 23:59:55 --> Loader Class Initialized
DEBUG - 2011-07-11 23:59:55 --> Controller Class Initialized
DEBUG - 2011-07-11 23:59:56 --> Model Class Initialized
DEBUG - 2011-07-11 23:59:56 --> Model Class Initialized
DEBUG - 2011-07-11 23:59:56 --> Model Class Initialized
DEBUG - 2011-07-11 23:59:56 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-07-11 23:59:56 --> Database Driver Class Initialized
DEBUG - 2011-07-11 23:59:56 --> File loaded: application/views/table/main.php
DEBUG - 2011-07-11 23:59:56 --> Helper loaded: url_helper
DEBUG - 2011-07-11 23:59:56 --> File loaded: application/views/common/header.php
DEBUG - 2011-07-11 23:59:56 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-07-11 23:59:56 --> File loaded: application/views/common/footer.php
DEBUG - 2011-07-11 23:59:56 --> File loaded: application/views/layout/main.php
DEBUG - 2011-07-11 23:59:56 --> Final output sent to browser
DEBUG - 2011-07-11 23:59:56 --> Total execution time: 0.5652

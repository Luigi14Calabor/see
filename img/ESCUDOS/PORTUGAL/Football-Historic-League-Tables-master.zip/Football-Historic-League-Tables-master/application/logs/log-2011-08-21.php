<?php  if ( ! defined('BASEPATH')) exit('No direct script access allowed'); ?>

DEBUG - 2011-08-21 00:15:38 --> Config Class Initialized
DEBUG - 2011-08-21 00:15:38 --> Hooks Class Initialized
DEBUG - 2011-08-21 00:15:38 --> Utf8 Class Initialized
DEBUG - 2011-08-21 00:15:38 --> UTF-8 Support Enabled
DEBUG - 2011-08-21 00:15:38 --> URI Class Initialized
DEBUG - 2011-08-21 00:15:38 --> Router Class Initialized
DEBUG - 2011-08-21 00:15:38 --> Output Class Initialized
DEBUG - 2011-08-21 00:15:38 --> Input Class Initialized
DEBUG - 2011-08-21 00:15:38 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-21 00:15:38 --> Language Class Initialized
DEBUG - 2011-08-21 00:15:38 --> Loader Class Initialized
DEBUG - 2011-08-21 00:15:38 --> Controller Class Initialized
DEBUG - 2011-08-21 00:15:38 --> Model Class Initialized
DEBUG - 2011-08-21 00:15:38 --> Model Class Initialized
DEBUG - 2011-08-21 00:15:38 --> Model Class Initialized
DEBUG - 2011-08-21 00:15:38 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-21 00:15:38 --> Database Driver Class Initialized
DEBUG - 2011-08-21 00:15:38 --> File loaded: application/views/table/main.php
DEBUG - 2011-08-21 00:15:38 --> Helper loaded: url_helper
DEBUG - 2011-08-21 00:15:38 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-21 00:15:38 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-21 00:15:38 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-21 00:15:38 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-21 00:15:38 --> Final output sent to browser
DEBUG - 2011-08-21 00:15:38 --> Total execution time: 0.3672
DEBUG - 2011-08-21 00:15:39 --> Config Class Initialized
DEBUG - 2011-08-21 00:15:39 --> Hooks Class Initialized
DEBUG - 2011-08-21 00:15:39 --> Utf8 Class Initialized
DEBUG - 2011-08-21 00:15:39 --> UTF-8 Support Enabled
DEBUG - 2011-08-21 00:15:39 --> URI Class Initialized
DEBUG - 2011-08-21 00:15:39 --> Router Class Initialized
DEBUG - 2011-08-21 00:15:39 --> Output Class Initialized
DEBUG - 2011-08-21 00:15:39 --> Input Class Initialized
DEBUG - 2011-08-21 00:15:39 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-21 00:15:39 --> Language Class Initialized
DEBUG - 2011-08-21 00:15:39 --> Loader Class Initialized
DEBUG - 2011-08-21 00:15:39 --> Controller Class Initialized
ERROR - 2011-08-21 00:15:39 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-08-21 00:15:39 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-08-21 00:15:39 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-08-21 00:15:39 --> Model Class Initialized
DEBUG - 2011-08-21 00:15:39 --> Model Class Initialized
DEBUG - 2011-08-21 00:15:39 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-21 00:15:39 --> Database Driver Class Initialized
DEBUG - 2011-08-21 00:15:39 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-08-21 00:15:39 --> Helper loaded: url_helper
DEBUG - 2011-08-21 00:15:39 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-21 00:15:39 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-21 00:15:39 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-21 00:15:39 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-21 00:15:39 --> Final output sent to browser
DEBUG - 2011-08-21 00:15:39 --> Total execution time: 0.0397
DEBUG - 2011-08-21 00:45:35 --> Config Class Initialized
DEBUG - 2011-08-21 00:45:35 --> Hooks Class Initialized
DEBUG - 2011-08-21 00:45:35 --> Utf8 Class Initialized
DEBUG - 2011-08-21 00:45:35 --> UTF-8 Support Enabled
DEBUG - 2011-08-21 00:45:35 --> URI Class Initialized
DEBUG - 2011-08-21 00:45:35 --> Router Class Initialized
DEBUG - 2011-08-21 00:45:35 --> No URI present. Default controller set.
DEBUG - 2011-08-21 00:45:35 --> Output Class Initialized
DEBUG - 2011-08-21 00:45:35 --> Input Class Initialized
DEBUG - 2011-08-21 00:45:35 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-21 00:45:35 --> Language Class Initialized
DEBUG - 2011-08-21 00:45:35 --> Loader Class Initialized
DEBUG - 2011-08-21 00:45:35 --> Controller Class Initialized
DEBUG - 2011-08-21 00:45:35 --> File loaded: application/views/splash/main.php
DEBUG - 2011-08-21 00:45:35 --> Helper loaded: url_helper
DEBUG - 2011-08-21 00:45:35 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-21 00:45:35 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-21 00:45:35 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-21 00:45:35 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-21 00:45:35 --> Final output sent to browser
DEBUG - 2011-08-21 00:45:35 --> Total execution time: 0.0131
DEBUG - 2011-08-21 01:13:05 --> Config Class Initialized
DEBUG - 2011-08-21 01:13:05 --> Hooks Class Initialized
DEBUG - 2011-08-21 01:13:05 --> Utf8 Class Initialized
DEBUG - 2011-08-21 01:13:05 --> UTF-8 Support Enabled
DEBUG - 2011-08-21 01:13:05 --> URI Class Initialized
DEBUG - 2011-08-21 01:13:05 --> Router Class Initialized
DEBUG - 2011-08-21 01:13:05 --> Output Class Initialized
DEBUG - 2011-08-21 01:13:05 --> Input Class Initialized
DEBUG - 2011-08-21 01:13:05 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-21 01:13:05 --> Language Class Initialized
DEBUG - 2011-08-21 01:13:05 --> Loader Class Initialized
DEBUG - 2011-08-21 01:13:05 --> Controller Class Initialized
ERROR - 2011-08-21 01:13:05 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-08-21 01:13:05 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-08-21 01:13:05 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-08-21 01:13:05 --> Model Class Initialized
DEBUG - 2011-08-21 01:13:05 --> Model Class Initialized
DEBUG - 2011-08-21 01:13:05 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-21 01:13:05 --> Database Driver Class Initialized
DEBUG - 2011-08-21 01:13:05 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-08-21 01:13:05 --> Helper loaded: url_helper
DEBUG - 2011-08-21 01:13:05 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-21 01:13:05 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-21 01:13:05 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-21 01:13:05 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-21 01:13:05 --> Final output sent to browser
DEBUG - 2011-08-21 01:13:05 --> Total execution time: 0.0297
DEBUG - 2011-08-21 01:13:06 --> Config Class Initialized
DEBUG - 2011-08-21 01:13:06 --> Hooks Class Initialized
DEBUG - 2011-08-21 01:13:06 --> Utf8 Class Initialized
DEBUG - 2011-08-21 01:13:06 --> UTF-8 Support Enabled
DEBUG - 2011-08-21 01:13:06 --> URI Class Initialized
DEBUG - 2011-08-21 01:13:06 --> Router Class Initialized
DEBUG - 2011-08-21 01:13:06 --> Output Class Initialized
DEBUG - 2011-08-21 01:13:06 --> Input Class Initialized
DEBUG - 2011-08-21 01:13:06 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-21 01:13:06 --> Language Class Initialized
DEBUG - 2011-08-21 01:13:06 --> Loader Class Initialized
DEBUG - 2011-08-21 01:13:06 --> Controller Class Initialized
DEBUG - 2011-08-21 01:13:06 --> Model Class Initialized
DEBUG - 2011-08-21 01:13:06 --> Model Class Initialized
DEBUG - 2011-08-21 01:13:06 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-21 01:13:06 --> Database Driver Class Initialized
DEBUG - 2011-08-21 01:13:07 --> Final output sent to browser
DEBUG - 2011-08-21 01:13:07 --> Total execution time: 0.7294
DEBUG - 2011-08-21 01:13:09 --> Config Class Initialized
DEBUG - 2011-08-21 01:13:09 --> Hooks Class Initialized
DEBUG - 2011-08-21 01:13:09 --> Utf8 Class Initialized
DEBUG - 2011-08-21 01:13:09 --> UTF-8 Support Enabled
DEBUG - 2011-08-21 01:13:09 --> URI Class Initialized
DEBUG - 2011-08-21 01:13:09 --> Router Class Initialized
ERROR - 2011-08-21 01:13:09 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-08-21 01:13:14 --> Config Class Initialized
DEBUG - 2011-08-21 01:13:14 --> Hooks Class Initialized
DEBUG - 2011-08-21 01:13:14 --> Utf8 Class Initialized
DEBUG - 2011-08-21 01:13:14 --> UTF-8 Support Enabled
DEBUG - 2011-08-21 01:13:14 --> URI Class Initialized
DEBUG - 2011-08-21 01:13:14 --> Router Class Initialized
ERROR - 2011-08-21 01:13:14 --> 404 Page Not Found --> robots.txt
DEBUG - 2011-08-21 01:13:19 --> Config Class Initialized
DEBUG - 2011-08-21 01:13:19 --> Hooks Class Initialized
DEBUG - 2011-08-21 01:13:19 --> Utf8 Class Initialized
DEBUG - 2011-08-21 01:13:19 --> UTF-8 Support Enabled
DEBUG - 2011-08-21 01:13:19 --> URI Class Initialized
DEBUG - 2011-08-21 01:13:19 --> Router Class Initialized
DEBUG - 2011-08-21 01:13:19 --> No URI present. Default controller set.
DEBUG - 2011-08-21 01:13:19 --> Output Class Initialized
DEBUG - 2011-08-21 01:13:19 --> Input Class Initialized
DEBUG - 2011-08-21 01:13:19 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-21 01:13:19 --> Language Class Initialized
DEBUG - 2011-08-21 01:13:19 --> Loader Class Initialized
DEBUG - 2011-08-21 01:13:19 --> Controller Class Initialized
DEBUG - 2011-08-21 01:13:19 --> File loaded: application/views/splash/main.php
DEBUG - 2011-08-21 01:13:19 --> Helper loaded: url_helper
DEBUG - 2011-08-21 01:13:19 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-21 01:13:19 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-21 01:13:19 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-21 01:13:19 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-21 01:13:19 --> Final output sent to browser
DEBUG - 2011-08-21 01:13:19 --> Total execution time: 0.0129
DEBUG - 2011-08-21 01:48:07 --> Config Class Initialized
DEBUG - 2011-08-21 01:48:07 --> Hooks Class Initialized
DEBUG - 2011-08-21 01:48:07 --> Utf8 Class Initialized
DEBUG - 2011-08-21 01:48:07 --> UTF-8 Support Enabled
DEBUG - 2011-08-21 01:48:07 --> URI Class Initialized
DEBUG - 2011-08-21 01:48:07 --> Router Class Initialized
ERROR - 2011-08-21 01:48:07 --> 404 Page Not Found --> robots.txt
DEBUG - 2011-08-21 02:44:09 --> Config Class Initialized
DEBUG - 2011-08-21 02:44:09 --> Hooks Class Initialized
DEBUG - 2011-08-21 02:44:09 --> Utf8 Class Initialized
DEBUG - 2011-08-21 02:44:09 --> UTF-8 Support Enabled
DEBUG - 2011-08-21 02:44:09 --> URI Class Initialized
DEBUG - 2011-08-21 02:44:09 --> Router Class Initialized
DEBUG - 2011-08-21 02:44:09 --> Output Class Initialized
DEBUG - 2011-08-21 02:44:09 --> Input Class Initialized
DEBUG - 2011-08-21 02:44:09 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-21 02:44:09 --> Language Class Initialized
DEBUG - 2011-08-21 02:44:09 --> Loader Class Initialized
DEBUG - 2011-08-21 02:44:09 --> Controller Class Initialized
ERROR - 2011-08-21 02:44:09 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-08-21 02:44:09 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-08-21 02:44:09 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-08-21 02:44:09 --> Model Class Initialized
DEBUG - 2011-08-21 02:44:09 --> Model Class Initialized
DEBUG - 2011-08-21 02:44:09 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-21 02:44:09 --> Database Driver Class Initialized
DEBUG - 2011-08-21 02:44:09 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-08-21 02:44:09 --> Helper loaded: url_helper
DEBUG - 2011-08-21 02:44:09 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-21 02:44:09 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-21 02:44:09 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-21 02:44:09 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-21 02:44:09 --> Final output sent to browser
DEBUG - 2011-08-21 02:44:09 --> Total execution time: 0.7697
DEBUG - 2011-08-21 03:33:52 --> Config Class Initialized
DEBUG - 2011-08-21 03:33:52 --> Hooks Class Initialized
DEBUG - 2011-08-21 03:33:52 --> Utf8 Class Initialized
DEBUG - 2011-08-21 03:33:52 --> UTF-8 Support Enabled
DEBUG - 2011-08-21 03:33:52 --> URI Class Initialized
DEBUG - 2011-08-21 03:33:52 --> Router Class Initialized
DEBUG - 2011-08-21 03:33:52 --> Output Class Initialized
DEBUG - 2011-08-21 03:33:52 --> Input Class Initialized
DEBUG - 2011-08-21 03:33:52 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-21 03:33:52 --> Language Class Initialized
DEBUG - 2011-08-21 03:33:52 --> Loader Class Initialized
DEBUG - 2011-08-21 03:33:52 --> Controller Class Initialized
DEBUG - 2011-08-21 03:33:52 --> Model Class Initialized
DEBUG - 2011-08-21 03:33:52 --> Model Class Initialized
DEBUG - 2011-08-21 03:33:52 --> Model Class Initialized
DEBUG - 2011-08-21 03:33:52 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-21 03:33:52 --> Database Driver Class Initialized
DEBUG - 2011-08-21 03:34:02 --> File loaded: application/views/table/main.php
DEBUG - 2011-08-21 03:34:02 --> Helper loaded: url_helper
DEBUG - 2011-08-21 03:34:02 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-21 03:34:02 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-21 03:34:02 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-21 03:34:02 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-21 03:34:02 --> Final output sent to browser
DEBUG - 2011-08-21 03:34:02 --> Total execution time: 9.5880
DEBUG - 2011-08-21 03:34:06 --> Config Class Initialized
DEBUG - 2011-08-21 03:34:06 --> Hooks Class Initialized
DEBUG - 2011-08-21 03:34:06 --> Utf8 Class Initialized
DEBUG - 2011-08-21 03:34:06 --> UTF-8 Support Enabled
DEBUG - 2011-08-21 03:34:06 --> URI Class Initialized
DEBUG - 2011-08-21 03:34:06 --> Router Class Initialized
DEBUG - 2011-08-21 03:34:06 --> Output Class Initialized
DEBUG - 2011-08-21 03:34:06 --> Input Class Initialized
DEBUG - 2011-08-21 03:34:06 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-21 03:34:06 --> Language Class Initialized
DEBUG - 2011-08-21 03:34:06 --> Loader Class Initialized
DEBUG - 2011-08-21 03:34:06 --> Controller Class Initialized
ERROR - 2011-08-21 03:34:06 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-08-21 03:34:06 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-08-21 03:34:06 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-08-21 03:34:06 --> Model Class Initialized
DEBUG - 2011-08-21 03:34:06 --> Model Class Initialized
DEBUG - 2011-08-21 03:34:06 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-21 03:34:06 --> Database Driver Class Initialized
DEBUG - 2011-08-21 03:34:06 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-08-21 03:34:06 --> Helper loaded: url_helper
DEBUG - 2011-08-21 03:34:06 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-21 03:34:06 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-21 03:34:06 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-21 03:34:06 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-21 03:34:06 --> Final output sent to browser
DEBUG - 2011-08-21 03:34:06 --> Total execution time: 0.1069
DEBUG - 2011-08-21 04:16:00 --> Config Class Initialized
DEBUG - 2011-08-21 04:16:00 --> Hooks Class Initialized
DEBUG - 2011-08-21 04:16:00 --> Utf8 Class Initialized
DEBUG - 2011-08-21 04:16:00 --> UTF-8 Support Enabled
DEBUG - 2011-08-21 04:16:00 --> URI Class Initialized
DEBUG - 2011-08-21 04:16:00 --> Router Class Initialized
DEBUG - 2011-08-21 04:16:00 --> Output Class Initialized
DEBUG - 2011-08-21 04:16:00 --> Input Class Initialized
DEBUG - 2011-08-21 04:16:00 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-21 04:16:00 --> Language Class Initialized
DEBUG - 2011-08-21 04:16:00 --> Loader Class Initialized
DEBUG - 2011-08-21 04:16:00 --> Controller Class Initialized
DEBUG - 2011-08-21 04:16:00 --> Model Class Initialized
DEBUG - 2011-08-21 04:16:00 --> Model Class Initialized
DEBUG - 2011-08-21 04:16:00 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-21 04:16:00 --> Database Driver Class Initialized
DEBUG - 2011-08-21 04:16:01 --> Final output sent to browser
DEBUG - 2011-08-21 04:16:01 --> Total execution time: 0.7520
DEBUG - 2011-08-21 04:58:26 --> Config Class Initialized
DEBUG - 2011-08-21 04:58:26 --> Hooks Class Initialized
DEBUG - 2011-08-21 04:58:26 --> Utf8 Class Initialized
DEBUG - 2011-08-21 04:58:26 --> UTF-8 Support Enabled
DEBUG - 2011-08-21 04:58:26 --> URI Class Initialized
DEBUG - 2011-08-21 04:58:26 --> Router Class Initialized
DEBUG - 2011-08-21 04:58:26 --> Output Class Initialized
DEBUG - 2011-08-21 04:58:26 --> Input Class Initialized
DEBUG - 2011-08-21 04:58:26 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-21 04:58:26 --> Language Class Initialized
DEBUG - 2011-08-21 04:58:26 --> Loader Class Initialized
DEBUG - 2011-08-21 04:58:26 --> Controller Class Initialized
ERROR - 2011-08-21 04:58:26 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-08-21 04:58:26 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-08-21 04:58:26 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-08-21 04:58:26 --> Model Class Initialized
DEBUG - 2011-08-21 04:58:26 --> Model Class Initialized
DEBUG - 2011-08-21 04:58:26 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-21 04:58:26 --> Database Driver Class Initialized
DEBUG - 2011-08-21 04:58:26 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-08-21 04:58:26 --> Helper loaded: url_helper
DEBUG - 2011-08-21 04:58:26 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-21 04:58:26 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-21 04:58:26 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-21 04:58:26 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-21 04:58:26 --> Final output sent to browser
DEBUG - 2011-08-21 04:58:26 --> Total execution time: 0.3552
DEBUG - 2011-08-21 04:58:28 --> Config Class Initialized
DEBUG - 2011-08-21 04:58:28 --> Hooks Class Initialized
DEBUG - 2011-08-21 04:58:28 --> Utf8 Class Initialized
DEBUG - 2011-08-21 04:58:28 --> UTF-8 Support Enabled
DEBUG - 2011-08-21 04:58:28 --> URI Class Initialized
DEBUG - 2011-08-21 04:58:28 --> Router Class Initialized
DEBUG - 2011-08-21 04:58:28 --> Output Class Initialized
DEBUG - 2011-08-21 04:58:28 --> Input Class Initialized
DEBUG - 2011-08-21 04:58:28 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-21 04:58:28 --> Language Class Initialized
DEBUG - 2011-08-21 04:58:28 --> Loader Class Initialized
DEBUG - 2011-08-21 04:58:28 --> Controller Class Initialized
DEBUG - 2011-08-21 04:58:28 --> Model Class Initialized
DEBUG - 2011-08-21 04:58:28 --> Model Class Initialized
DEBUG - 2011-08-21 04:58:28 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-21 04:58:28 --> Database Driver Class Initialized
DEBUG - 2011-08-21 04:58:28 --> Final output sent to browser
DEBUG - 2011-08-21 04:58:28 --> Total execution time: 0.6657
DEBUG - 2011-08-21 04:58:47 --> Config Class Initialized
DEBUG - 2011-08-21 04:58:47 --> Hooks Class Initialized
DEBUG - 2011-08-21 04:58:47 --> Utf8 Class Initialized
DEBUG - 2011-08-21 04:58:47 --> UTF-8 Support Enabled
DEBUG - 2011-08-21 04:58:47 --> URI Class Initialized
DEBUG - 2011-08-21 04:58:47 --> Router Class Initialized
DEBUG - 2011-08-21 04:58:47 --> Output Class Initialized
DEBUG - 2011-08-21 04:58:47 --> Input Class Initialized
DEBUG - 2011-08-21 04:58:47 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-21 04:58:47 --> Language Class Initialized
DEBUG - 2011-08-21 04:58:47 --> Loader Class Initialized
DEBUG - 2011-08-21 04:58:47 --> Controller Class Initialized
ERROR - 2011-08-21 04:58:47 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-08-21 04:58:47 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-08-21 04:58:47 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-08-21 04:58:47 --> Model Class Initialized
DEBUG - 2011-08-21 04:58:47 --> Model Class Initialized
DEBUG - 2011-08-21 04:58:47 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-21 04:58:47 --> Database Driver Class Initialized
DEBUG - 2011-08-21 04:58:47 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-08-21 04:58:47 --> Helper loaded: url_helper
DEBUG - 2011-08-21 04:58:47 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-21 04:58:47 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-21 04:58:47 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-21 04:58:47 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-21 04:58:47 --> Final output sent to browser
DEBUG - 2011-08-21 04:58:47 --> Total execution time: 0.0287
DEBUG - 2011-08-21 04:58:49 --> Config Class Initialized
DEBUG - 2011-08-21 04:58:49 --> Hooks Class Initialized
DEBUG - 2011-08-21 04:58:49 --> Utf8 Class Initialized
DEBUG - 2011-08-21 04:58:49 --> UTF-8 Support Enabled
DEBUG - 2011-08-21 04:58:49 --> URI Class Initialized
DEBUG - 2011-08-21 04:58:49 --> Router Class Initialized
DEBUG - 2011-08-21 04:58:49 --> Output Class Initialized
DEBUG - 2011-08-21 04:58:49 --> Input Class Initialized
DEBUG - 2011-08-21 04:58:49 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-21 04:58:49 --> Language Class Initialized
DEBUG - 2011-08-21 04:58:49 --> Loader Class Initialized
DEBUG - 2011-08-21 04:58:49 --> Controller Class Initialized
DEBUG - 2011-08-21 04:58:49 --> Model Class Initialized
DEBUG - 2011-08-21 04:58:49 --> Model Class Initialized
DEBUG - 2011-08-21 04:58:49 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-21 04:58:49 --> Database Driver Class Initialized
DEBUG - 2011-08-21 04:58:49 --> Final output sent to browser
DEBUG - 2011-08-21 04:58:49 --> Total execution time: 0.5332
DEBUG - 2011-08-21 04:58:51 --> Config Class Initialized
DEBUG - 2011-08-21 04:58:51 --> Hooks Class Initialized
DEBUG - 2011-08-21 04:58:51 --> Utf8 Class Initialized
DEBUG - 2011-08-21 04:58:51 --> UTF-8 Support Enabled
DEBUG - 2011-08-21 04:58:51 --> URI Class Initialized
DEBUG - 2011-08-21 04:58:51 --> Router Class Initialized
ERROR - 2011-08-21 04:58:51 --> 404 Page Not Found --> robots.txt
DEBUG - 2011-08-21 04:58:51 --> Config Class Initialized
DEBUG - 2011-08-21 04:58:51 --> Hooks Class Initialized
DEBUG - 2011-08-21 04:58:51 --> Utf8 Class Initialized
DEBUG - 2011-08-21 04:58:51 --> UTF-8 Support Enabled
DEBUG - 2011-08-21 04:58:51 --> URI Class Initialized
DEBUG - 2011-08-21 04:58:51 --> Router Class Initialized
DEBUG - 2011-08-21 04:58:51 --> Output Class Initialized
DEBUG - 2011-08-21 04:58:51 --> Input Class Initialized
DEBUG - 2011-08-21 04:58:51 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-21 04:58:51 --> Language Class Initialized
DEBUG - 2011-08-21 04:58:51 --> Loader Class Initialized
DEBUG - 2011-08-21 04:58:51 --> Controller Class Initialized
ERROR - 2011-08-21 04:58:51 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-08-21 04:58:51 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-08-21 04:58:51 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-08-21 04:58:51 --> Model Class Initialized
DEBUG - 2011-08-21 04:58:51 --> Model Class Initialized
DEBUG - 2011-08-21 04:58:51 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-21 04:58:51 --> Database Driver Class Initialized
DEBUG - 2011-08-21 04:58:51 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-08-21 04:58:51 --> Helper loaded: url_helper
DEBUG - 2011-08-21 04:58:51 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-21 04:58:51 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-21 04:58:51 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-21 04:58:51 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-21 04:58:51 --> Final output sent to browser
DEBUG - 2011-08-21 04:58:51 --> Total execution time: 0.0265
DEBUG - 2011-08-21 04:58:57 --> Config Class Initialized
DEBUG - 2011-08-21 04:58:57 --> Hooks Class Initialized
DEBUG - 2011-08-21 04:58:57 --> Utf8 Class Initialized
DEBUG - 2011-08-21 04:58:57 --> UTF-8 Support Enabled
DEBUG - 2011-08-21 04:58:57 --> URI Class Initialized
DEBUG - 2011-08-21 04:58:57 --> Router Class Initialized
DEBUG - 2011-08-21 04:58:57 --> Output Class Initialized
DEBUG - 2011-08-21 04:58:57 --> Input Class Initialized
DEBUG - 2011-08-21 04:58:57 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-21 04:58:57 --> Language Class Initialized
DEBUG - 2011-08-21 04:58:57 --> Loader Class Initialized
DEBUG - 2011-08-21 04:58:57 --> Controller Class Initialized
ERROR - 2011-08-21 04:58:57 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-08-21 04:58:57 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-08-21 04:58:57 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-08-21 04:58:57 --> Model Class Initialized
DEBUG - 2011-08-21 04:58:57 --> Model Class Initialized
DEBUG - 2011-08-21 04:58:57 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-21 04:58:57 --> Database Driver Class Initialized
DEBUG - 2011-08-21 04:58:57 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-08-21 04:58:57 --> Helper loaded: url_helper
DEBUG - 2011-08-21 04:58:57 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-21 04:58:57 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-21 04:58:57 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-21 04:58:57 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-21 04:58:57 --> Final output sent to browser
DEBUG - 2011-08-21 04:58:57 --> Total execution time: 0.0335
DEBUG - 2011-08-21 04:58:58 --> Config Class Initialized
DEBUG - 2011-08-21 04:58:58 --> Hooks Class Initialized
DEBUG - 2011-08-21 04:58:58 --> Utf8 Class Initialized
DEBUG - 2011-08-21 04:58:58 --> UTF-8 Support Enabled
DEBUG - 2011-08-21 04:58:58 --> URI Class Initialized
DEBUG - 2011-08-21 04:58:58 --> Router Class Initialized
ERROR - 2011-08-21 04:58:58 --> 404 Page Not Found --> robots.txt
DEBUG - 2011-08-21 04:58:59 --> Config Class Initialized
DEBUG - 2011-08-21 04:58:59 --> Hooks Class Initialized
DEBUG - 2011-08-21 04:58:59 --> Utf8 Class Initialized
DEBUG - 2011-08-21 04:58:59 --> UTF-8 Support Enabled
DEBUG - 2011-08-21 04:58:59 --> URI Class Initialized
DEBUG - 2011-08-21 04:58:59 --> Router Class Initialized
DEBUG - 2011-08-21 04:58:59 --> Output Class Initialized
DEBUG - 2011-08-21 04:58:59 --> Input Class Initialized
DEBUG - 2011-08-21 04:58:59 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-21 04:58:59 --> Language Class Initialized
DEBUG - 2011-08-21 04:58:59 --> Loader Class Initialized
DEBUG - 2011-08-21 04:58:59 --> Controller Class Initialized
DEBUG - 2011-08-21 04:58:59 --> Model Class Initialized
DEBUG - 2011-08-21 04:58:59 --> Model Class Initialized
DEBUG - 2011-08-21 04:58:59 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-21 04:58:59 --> Database Driver Class Initialized
DEBUG - 2011-08-21 04:58:59 --> Final output sent to browser
DEBUG - 2011-08-21 04:58:59 --> Total execution time: 0.3202
DEBUG - 2011-08-21 05:49:36 --> Config Class Initialized
DEBUG - 2011-08-21 05:49:36 --> Hooks Class Initialized
DEBUG - 2011-08-21 05:49:36 --> Utf8 Class Initialized
DEBUG - 2011-08-21 05:49:36 --> UTF-8 Support Enabled
DEBUG - 2011-08-21 05:49:36 --> URI Class Initialized
DEBUG - 2011-08-21 05:49:36 --> Router Class Initialized
DEBUG - 2011-08-21 05:49:36 --> Output Class Initialized
DEBUG - 2011-08-21 05:49:36 --> Input Class Initialized
DEBUG - 2011-08-21 05:49:36 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-21 05:49:36 --> Language Class Initialized
DEBUG - 2011-08-21 05:49:36 --> Loader Class Initialized
DEBUG - 2011-08-21 05:49:36 --> Controller Class Initialized
ERROR - 2011-08-21 05:49:36 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-08-21 05:49:36 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-08-21 05:49:36 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-08-21 05:49:36 --> Model Class Initialized
DEBUG - 2011-08-21 05:49:36 --> Model Class Initialized
DEBUG - 2011-08-21 05:49:36 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-21 05:49:37 --> Database Driver Class Initialized
DEBUG - 2011-08-21 05:49:37 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-08-21 05:49:37 --> Helper loaded: url_helper
DEBUG - 2011-08-21 05:49:37 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-21 05:49:37 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-21 05:49:37 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-21 05:49:37 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-21 05:49:37 --> Final output sent to browser
DEBUG - 2011-08-21 05:49:37 --> Total execution time: 0.2250
DEBUG - 2011-08-21 05:49:38 --> Config Class Initialized
DEBUG - 2011-08-21 05:49:38 --> Hooks Class Initialized
DEBUG - 2011-08-21 05:49:38 --> Utf8 Class Initialized
DEBUG - 2011-08-21 05:49:38 --> UTF-8 Support Enabled
DEBUG - 2011-08-21 05:49:38 --> URI Class Initialized
DEBUG - 2011-08-21 05:49:38 --> Router Class Initialized
DEBUG - 2011-08-21 05:49:38 --> Output Class Initialized
DEBUG - 2011-08-21 05:49:38 --> Input Class Initialized
DEBUG - 2011-08-21 05:49:38 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-21 05:49:38 --> Language Class Initialized
DEBUG - 2011-08-21 05:49:38 --> Loader Class Initialized
DEBUG - 2011-08-21 05:49:38 --> Controller Class Initialized
DEBUG - 2011-08-21 05:49:38 --> Model Class Initialized
DEBUG - 2011-08-21 05:49:38 --> Model Class Initialized
DEBUG - 2011-08-21 05:49:38 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-21 05:49:38 --> Database Driver Class Initialized
DEBUG - 2011-08-21 05:49:38 --> Final output sent to browser
DEBUG - 2011-08-21 05:49:38 --> Total execution time: 0.5387
DEBUG - 2011-08-21 05:49:40 --> Config Class Initialized
DEBUG - 2011-08-21 05:49:40 --> Hooks Class Initialized
DEBUG - 2011-08-21 05:49:40 --> Utf8 Class Initialized
DEBUG - 2011-08-21 05:49:40 --> UTF-8 Support Enabled
DEBUG - 2011-08-21 05:49:40 --> URI Class Initialized
DEBUG - 2011-08-21 05:49:40 --> Router Class Initialized
ERROR - 2011-08-21 05:49:40 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-08-21 05:49:41 --> Config Class Initialized
DEBUG - 2011-08-21 05:49:41 --> Hooks Class Initialized
DEBUG - 2011-08-21 05:49:41 --> Utf8 Class Initialized
DEBUG - 2011-08-21 05:49:41 --> UTF-8 Support Enabled
DEBUG - 2011-08-21 05:49:41 --> URI Class Initialized
DEBUG - 2011-08-21 05:49:41 --> Router Class Initialized
ERROR - 2011-08-21 05:49:41 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-08-21 05:54:35 --> Config Class Initialized
DEBUG - 2011-08-21 05:54:35 --> Hooks Class Initialized
DEBUG - 2011-08-21 05:54:35 --> Utf8 Class Initialized
DEBUG - 2011-08-21 05:54:35 --> UTF-8 Support Enabled
DEBUG - 2011-08-21 05:54:35 --> URI Class Initialized
DEBUG - 2011-08-21 05:54:35 --> Router Class Initialized
DEBUG - 2011-08-21 05:54:35 --> Output Class Initialized
DEBUG - 2011-08-21 05:54:35 --> Input Class Initialized
DEBUG - 2011-08-21 05:54:35 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-21 05:54:35 --> Language Class Initialized
DEBUG - 2011-08-21 05:54:35 --> Loader Class Initialized
DEBUG - 2011-08-21 05:54:35 --> Controller Class Initialized
ERROR - 2011-08-21 05:54:35 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-08-21 05:54:35 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-08-21 05:54:35 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-08-21 05:54:35 --> Model Class Initialized
DEBUG - 2011-08-21 05:54:35 --> Model Class Initialized
DEBUG - 2011-08-21 05:54:35 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-21 05:54:35 --> Database Driver Class Initialized
DEBUG - 2011-08-21 05:54:35 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-08-21 05:54:35 --> Helper loaded: url_helper
DEBUG - 2011-08-21 05:54:35 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-21 05:54:35 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-21 05:54:35 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-21 05:54:35 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-21 05:54:35 --> Final output sent to browser
DEBUG - 2011-08-21 05:54:35 --> Total execution time: 0.3933
DEBUG - 2011-08-21 05:54:36 --> Config Class Initialized
DEBUG - 2011-08-21 05:54:36 --> Hooks Class Initialized
DEBUG - 2011-08-21 05:54:36 --> Utf8 Class Initialized
DEBUG - 2011-08-21 05:54:36 --> UTF-8 Support Enabled
DEBUG - 2011-08-21 05:54:36 --> URI Class Initialized
DEBUG - 2011-08-21 05:54:36 --> Router Class Initialized
DEBUG - 2011-08-21 05:54:36 --> Output Class Initialized
DEBUG - 2011-08-21 05:54:36 --> Input Class Initialized
DEBUG - 2011-08-21 05:54:36 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-21 05:54:36 --> Language Class Initialized
DEBUG - 2011-08-21 05:54:36 --> Loader Class Initialized
DEBUG - 2011-08-21 05:54:36 --> Controller Class Initialized
DEBUG - 2011-08-21 05:54:36 --> Model Class Initialized
DEBUG - 2011-08-21 05:54:37 --> Model Class Initialized
DEBUG - 2011-08-21 05:54:37 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-21 05:54:37 --> Database Driver Class Initialized
DEBUG - 2011-08-21 05:54:37 --> Final output sent to browser
DEBUG - 2011-08-21 05:54:37 --> Total execution time: 0.7383
DEBUG - 2011-08-21 05:54:38 --> Config Class Initialized
DEBUG - 2011-08-21 05:54:38 --> Hooks Class Initialized
DEBUG - 2011-08-21 05:54:38 --> Utf8 Class Initialized
DEBUG - 2011-08-21 05:54:38 --> UTF-8 Support Enabled
DEBUG - 2011-08-21 05:54:38 --> URI Class Initialized
DEBUG - 2011-08-21 05:54:38 --> Router Class Initialized
ERROR - 2011-08-21 05:54:38 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-08-21 07:02:51 --> Config Class Initialized
DEBUG - 2011-08-21 07:02:51 --> Hooks Class Initialized
DEBUG - 2011-08-21 07:02:51 --> Utf8 Class Initialized
DEBUG - 2011-08-21 07:02:51 --> UTF-8 Support Enabled
DEBUG - 2011-08-21 07:02:51 --> URI Class Initialized
DEBUG - 2011-08-21 07:02:51 --> Router Class Initialized
ERROR - 2011-08-21 07:02:51 --> 404 Page Not Found --> robots.txt
DEBUG - 2011-08-21 07:13:46 --> Config Class Initialized
DEBUG - 2011-08-21 07:13:46 --> Hooks Class Initialized
DEBUG - 2011-08-21 07:13:46 --> Utf8 Class Initialized
DEBUG - 2011-08-21 07:13:46 --> UTF-8 Support Enabled
DEBUG - 2011-08-21 07:13:46 --> URI Class Initialized
DEBUG - 2011-08-21 07:13:46 --> Router Class Initialized
DEBUG - 2011-08-21 07:13:46 --> Output Class Initialized
DEBUG - 2011-08-21 07:13:46 --> Input Class Initialized
DEBUG - 2011-08-21 07:13:46 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-21 07:13:46 --> Language Class Initialized
DEBUG - 2011-08-21 07:13:46 --> Loader Class Initialized
DEBUG - 2011-08-21 07:13:46 --> Controller Class Initialized
DEBUG - 2011-08-21 07:13:46 --> Model Class Initialized
DEBUG - 2011-08-21 07:13:46 --> Model Class Initialized
DEBUG - 2011-08-21 07:13:46 --> Model Class Initialized
DEBUG - 2011-08-21 07:13:46 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-21 07:13:46 --> Database Driver Class Initialized
DEBUG - 2011-08-21 07:13:46 --> File loaded: application/views/table/main.php
DEBUG - 2011-08-21 07:13:47 --> Helper loaded: url_helper
DEBUG - 2011-08-21 07:13:47 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-21 07:13:47 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-21 07:13:47 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-21 07:13:47 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-21 07:13:47 --> Final output sent to browser
DEBUG - 2011-08-21 07:13:47 --> Total execution time: 0.9364
DEBUG - 2011-08-21 07:13:52 --> Config Class Initialized
DEBUG - 2011-08-21 07:13:52 --> Hooks Class Initialized
DEBUG - 2011-08-21 07:13:52 --> Utf8 Class Initialized
DEBUG - 2011-08-21 07:13:52 --> UTF-8 Support Enabled
DEBUG - 2011-08-21 07:13:52 --> URI Class Initialized
DEBUG - 2011-08-21 07:13:52 --> Router Class Initialized
ERROR - 2011-08-21 07:13:52 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-08-21 07:13:59 --> Config Class Initialized
DEBUG - 2011-08-21 07:13:59 --> Hooks Class Initialized
DEBUG - 2011-08-21 07:13:59 --> Utf8 Class Initialized
DEBUG - 2011-08-21 07:13:59 --> UTF-8 Support Enabled
DEBUG - 2011-08-21 07:13:59 --> URI Class Initialized
DEBUG - 2011-08-21 07:13:59 --> Router Class Initialized
DEBUG - 2011-08-21 07:13:59 --> Output Class Initialized
DEBUG - 2011-08-21 07:13:59 --> Input Class Initialized
DEBUG - 2011-08-21 07:13:59 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-21 07:13:59 --> Language Class Initialized
DEBUG - 2011-08-21 07:13:59 --> Loader Class Initialized
DEBUG - 2011-08-21 07:13:59 --> Controller Class Initialized
DEBUG - 2011-08-21 07:13:59 --> Model Class Initialized
DEBUG - 2011-08-21 07:13:59 --> Model Class Initialized
DEBUG - 2011-08-21 07:13:59 --> Model Class Initialized
DEBUG - 2011-08-21 07:13:59 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-21 07:13:59 --> Database Driver Class Initialized
DEBUG - 2011-08-21 07:13:59 --> File loaded: application/views/table/main.php
DEBUG - 2011-08-21 07:13:59 --> Helper loaded: url_helper
DEBUG - 2011-08-21 07:13:59 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-21 07:13:59 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-21 07:13:59 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-21 07:13:59 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-21 07:13:59 --> Final output sent to browser
DEBUG - 2011-08-21 07:13:59 --> Total execution time: 0.3431
DEBUG - 2011-08-21 07:13:59 --> Config Class Initialized
DEBUG - 2011-08-21 07:13:59 --> Hooks Class Initialized
DEBUG - 2011-08-21 07:13:59 --> Utf8 Class Initialized
DEBUG - 2011-08-21 07:13:59 --> UTF-8 Support Enabled
DEBUG - 2011-08-21 07:13:59 --> URI Class Initialized
DEBUG - 2011-08-21 07:13:59 --> Router Class Initialized
DEBUG - 2011-08-21 07:13:59 --> Output Class Initialized
DEBUG - 2011-08-21 07:13:59 --> Input Class Initialized
DEBUG - 2011-08-21 07:13:59 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-21 07:13:59 --> Language Class Initialized
DEBUG - 2011-08-21 07:13:59 --> Loader Class Initialized
DEBUG - 2011-08-21 07:13:59 --> Controller Class Initialized
DEBUG - 2011-08-21 07:13:59 --> Model Class Initialized
DEBUG - 2011-08-21 07:13:59 --> Model Class Initialized
DEBUG - 2011-08-21 07:13:59 --> Model Class Initialized
DEBUG - 2011-08-21 07:13:59 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-21 07:13:59 --> Database Driver Class Initialized
DEBUG - 2011-08-21 07:13:59 --> File loaded: application/views/table/main.php
DEBUG - 2011-08-21 07:13:59 --> Helper loaded: url_helper
DEBUG - 2011-08-21 07:13:59 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-21 07:13:59 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-21 07:13:59 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-21 07:13:59 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-21 07:13:59 --> Final output sent to browser
DEBUG - 2011-08-21 07:13:59 --> Total execution time: 0.0495
DEBUG - 2011-08-21 07:14:00 --> Config Class Initialized
DEBUG - 2011-08-21 07:14:00 --> Hooks Class Initialized
DEBUG - 2011-08-21 07:14:00 --> Utf8 Class Initialized
DEBUG - 2011-08-21 07:14:00 --> UTF-8 Support Enabled
DEBUG - 2011-08-21 07:14:00 --> URI Class Initialized
DEBUG - 2011-08-21 07:14:00 --> Router Class Initialized
DEBUG - 2011-08-21 07:14:00 --> Output Class Initialized
DEBUG - 2011-08-21 07:14:00 --> Input Class Initialized
DEBUG - 2011-08-21 07:14:00 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-21 07:14:00 --> Language Class Initialized
DEBUG - 2011-08-21 07:14:00 --> Loader Class Initialized
DEBUG - 2011-08-21 07:14:00 --> Controller Class Initialized
DEBUG - 2011-08-21 07:14:00 --> Model Class Initialized
DEBUG - 2011-08-21 07:14:00 --> Model Class Initialized
DEBUG - 2011-08-21 07:14:00 --> Model Class Initialized
DEBUG - 2011-08-21 07:14:00 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-21 07:14:00 --> Database Driver Class Initialized
DEBUG - 2011-08-21 07:14:00 --> File loaded: application/views/table/main.php
DEBUG - 2011-08-21 07:14:00 --> Helper loaded: url_helper
DEBUG - 2011-08-21 07:14:00 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-21 07:14:00 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-21 07:14:00 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-21 07:14:00 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-21 07:14:00 --> Final output sent to browser
DEBUG - 2011-08-21 07:14:00 --> Total execution time: 0.0498
DEBUG - 2011-08-21 07:14:01 --> Config Class Initialized
DEBUG - 2011-08-21 07:14:01 --> Hooks Class Initialized
DEBUG - 2011-08-21 07:14:01 --> Utf8 Class Initialized
DEBUG - 2011-08-21 07:14:01 --> UTF-8 Support Enabled
DEBUG - 2011-08-21 07:14:01 --> URI Class Initialized
DEBUG - 2011-08-21 07:14:01 --> Router Class Initialized
ERROR - 2011-08-21 07:14:01 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-08-21 07:14:02 --> Config Class Initialized
DEBUG - 2011-08-21 07:14:02 --> Hooks Class Initialized
DEBUG - 2011-08-21 07:14:02 --> Utf8 Class Initialized
DEBUG - 2011-08-21 07:14:02 --> UTF-8 Support Enabled
DEBUG - 2011-08-21 07:14:02 --> URI Class Initialized
DEBUG - 2011-08-21 07:14:02 --> Router Class Initialized
DEBUG - 2011-08-21 07:14:02 --> Output Class Initialized
DEBUG - 2011-08-21 07:14:02 --> Input Class Initialized
DEBUG - 2011-08-21 07:14:02 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-21 07:14:02 --> Language Class Initialized
DEBUG - 2011-08-21 07:14:02 --> Loader Class Initialized
DEBUG - 2011-08-21 07:14:02 --> Controller Class Initialized
DEBUG - 2011-08-21 07:14:02 --> Model Class Initialized
DEBUG - 2011-08-21 07:14:02 --> Model Class Initialized
DEBUG - 2011-08-21 07:14:02 --> Model Class Initialized
DEBUG - 2011-08-21 07:14:02 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-21 07:14:02 --> Database Driver Class Initialized
DEBUG - 2011-08-21 07:14:02 --> File loaded: application/views/table/main.php
DEBUG - 2011-08-21 07:14:02 --> Helper loaded: url_helper
DEBUG - 2011-08-21 07:14:02 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-21 07:14:02 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-21 07:14:02 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-21 07:14:02 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-21 07:14:02 --> Final output sent to browser
DEBUG - 2011-08-21 07:14:02 --> Total execution time: 0.0569
DEBUG - 2011-08-21 07:14:08 --> Config Class Initialized
DEBUG - 2011-08-21 07:14:08 --> Hooks Class Initialized
DEBUG - 2011-08-21 07:14:08 --> Utf8 Class Initialized
DEBUG - 2011-08-21 07:14:08 --> UTF-8 Support Enabled
DEBUG - 2011-08-21 07:14:08 --> URI Class Initialized
DEBUG - 2011-08-21 07:14:08 --> Router Class Initialized
DEBUG - 2011-08-21 07:14:08 --> Output Class Initialized
DEBUG - 2011-08-21 07:14:08 --> Input Class Initialized
DEBUG - 2011-08-21 07:14:08 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-21 07:14:08 --> Language Class Initialized
DEBUG - 2011-08-21 07:14:08 --> Loader Class Initialized
DEBUG - 2011-08-21 07:14:08 --> Controller Class Initialized
DEBUG - 2011-08-21 07:14:08 --> Model Class Initialized
DEBUG - 2011-08-21 07:14:08 --> Model Class Initialized
DEBUG - 2011-08-21 07:14:08 --> Model Class Initialized
DEBUG - 2011-08-21 07:14:08 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-21 07:14:08 --> Database Driver Class Initialized
DEBUG - 2011-08-21 07:14:08 --> File loaded: application/views/table/main.php
DEBUG - 2011-08-21 07:14:08 --> Helper loaded: url_helper
DEBUG - 2011-08-21 07:14:08 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-21 07:14:08 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-21 07:14:08 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-21 07:14:08 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-21 07:14:08 --> Final output sent to browser
DEBUG - 2011-08-21 07:14:08 --> Total execution time: 0.2410
DEBUG - 2011-08-21 07:14:10 --> Config Class Initialized
DEBUG - 2011-08-21 07:14:10 --> Hooks Class Initialized
DEBUG - 2011-08-21 07:14:10 --> Utf8 Class Initialized
DEBUG - 2011-08-21 07:14:10 --> UTF-8 Support Enabled
DEBUG - 2011-08-21 07:14:10 --> URI Class Initialized
DEBUG - 2011-08-21 07:14:10 --> Router Class Initialized
ERROR - 2011-08-21 07:14:10 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-08-21 07:14:12 --> Config Class Initialized
DEBUG - 2011-08-21 07:14:12 --> Hooks Class Initialized
DEBUG - 2011-08-21 07:14:12 --> Utf8 Class Initialized
DEBUG - 2011-08-21 07:14:12 --> UTF-8 Support Enabled
DEBUG - 2011-08-21 07:14:12 --> URI Class Initialized
DEBUG - 2011-08-21 07:14:12 --> Router Class Initialized
DEBUG - 2011-08-21 07:14:12 --> Output Class Initialized
DEBUG - 2011-08-21 07:14:12 --> Input Class Initialized
DEBUG - 2011-08-21 07:14:12 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-21 07:14:12 --> Language Class Initialized
DEBUG - 2011-08-21 07:14:12 --> Loader Class Initialized
DEBUG - 2011-08-21 07:14:12 --> Controller Class Initialized
DEBUG - 2011-08-21 07:14:12 --> Model Class Initialized
DEBUG - 2011-08-21 07:14:12 --> Model Class Initialized
DEBUG - 2011-08-21 07:14:12 --> Model Class Initialized
DEBUG - 2011-08-21 07:14:12 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-21 07:14:12 --> Database Driver Class Initialized
DEBUG - 2011-08-21 07:14:12 --> File loaded: application/views/table/main.php
DEBUG - 2011-08-21 07:14:12 --> Helper loaded: url_helper
DEBUG - 2011-08-21 07:14:12 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-21 07:14:12 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-21 07:14:12 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-21 07:14:12 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-21 07:14:12 --> Final output sent to browser
DEBUG - 2011-08-21 07:14:12 --> Total execution time: 0.0705
DEBUG - 2011-08-21 07:54:53 --> Config Class Initialized
DEBUG - 2011-08-21 07:54:53 --> Hooks Class Initialized
DEBUG - 2011-08-21 07:54:53 --> Utf8 Class Initialized
DEBUG - 2011-08-21 07:54:53 --> UTF-8 Support Enabled
DEBUG - 2011-08-21 07:54:53 --> URI Class Initialized
DEBUG - 2011-08-21 07:54:53 --> Router Class Initialized
DEBUG - 2011-08-21 07:54:53 --> No URI present. Default controller set.
DEBUG - 2011-08-21 07:54:53 --> Output Class Initialized
DEBUG - 2011-08-21 07:54:53 --> Input Class Initialized
DEBUG - 2011-08-21 07:54:53 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-21 07:54:53 --> Language Class Initialized
DEBUG - 2011-08-21 07:54:53 --> Loader Class Initialized
DEBUG - 2011-08-21 07:54:53 --> Controller Class Initialized
DEBUG - 2011-08-21 07:54:53 --> File loaded: application/views/splash/main.php
DEBUG - 2011-08-21 07:54:53 --> Helper loaded: url_helper
DEBUG - 2011-08-21 07:54:53 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-21 07:54:53 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-21 07:54:53 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-21 07:54:53 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-21 07:54:53 --> Final output sent to browser
DEBUG - 2011-08-21 07:54:53 --> Total execution time: 0.2299
DEBUG - 2011-08-21 08:23:24 --> Config Class Initialized
DEBUG - 2011-08-21 08:23:24 --> Hooks Class Initialized
DEBUG - 2011-08-21 08:23:24 --> Utf8 Class Initialized
DEBUG - 2011-08-21 08:23:24 --> UTF-8 Support Enabled
DEBUG - 2011-08-21 08:23:24 --> URI Class Initialized
DEBUG - 2011-08-21 08:23:24 --> Router Class Initialized
DEBUG - 2011-08-21 08:23:24 --> Output Class Initialized
DEBUG - 2011-08-21 08:23:24 --> Input Class Initialized
DEBUG - 2011-08-21 08:23:24 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-21 08:23:24 --> Language Class Initialized
DEBUG - 2011-08-21 08:23:24 --> Loader Class Initialized
DEBUG - 2011-08-21 08:23:24 --> Controller Class Initialized
ERROR - 2011-08-21 08:23:24 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-08-21 08:23:24 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-08-21 08:23:24 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-08-21 08:23:24 --> Model Class Initialized
DEBUG - 2011-08-21 08:23:24 --> Model Class Initialized
DEBUG - 2011-08-21 08:23:24 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-21 08:23:24 --> Database Driver Class Initialized
DEBUG - 2011-08-21 08:23:24 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-08-21 08:23:24 --> Helper loaded: url_helper
DEBUG - 2011-08-21 08:23:24 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-21 08:23:24 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-21 08:23:24 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-21 08:23:24 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-21 08:23:24 --> Final output sent to browser
DEBUG - 2011-08-21 08:23:24 --> Total execution time: 0.1999
DEBUG - 2011-08-21 08:23:25 --> Config Class Initialized
DEBUG - 2011-08-21 08:23:25 --> Hooks Class Initialized
DEBUG - 2011-08-21 08:23:25 --> Utf8 Class Initialized
DEBUG - 2011-08-21 08:23:25 --> UTF-8 Support Enabled
DEBUG - 2011-08-21 08:23:26 --> URI Class Initialized
DEBUG - 2011-08-21 08:23:26 --> Router Class Initialized
DEBUG - 2011-08-21 08:23:26 --> Output Class Initialized
DEBUG - 2011-08-21 08:23:26 --> Input Class Initialized
DEBUG - 2011-08-21 08:23:26 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-21 08:23:26 --> Language Class Initialized
DEBUG - 2011-08-21 08:23:26 --> Loader Class Initialized
DEBUG - 2011-08-21 08:23:26 --> Controller Class Initialized
DEBUG - 2011-08-21 08:23:26 --> Model Class Initialized
DEBUG - 2011-08-21 08:23:26 --> Model Class Initialized
DEBUG - 2011-08-21 08:23:26 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-21 08:23:26 --> Database Driver Class Initialized
DEBUG - 2011-08-21 08:23:26 --> Final output sent to browser
DEBUG - 2011-08-21 08:23:26 --> Total execution time: 0.6847
DEBUG - 2011-08-21 08:23:27 --> Config Class Initialized
DEBUG - 2011-08-21 08:23:27 --> Hooks Class Initialized
DEBUG - 2011-08-21 08:23:27 --> Utf8 Class Initialized
DEBUG - 2011-08-21 08:23:27 --> UTF-8 Support Enabled
DEBUG - 2011-08-21 08:23:27 --> URI Class Initialized
DEBUG - 2011-08-21 08:23:27 --> Router Class Initialized
ERROR - 2011-08-21 08:23:27 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-08-21 08:23:28 --> Config Class Initialized
DEBUG - 2011-08-21 08:23:28 --> Hooks Class Initialized
DEBUG - 2011-08-21 08:23:28 --> Utf8 Class Initialized
DEBUG - 2011-08-21 08:23:28 --> UTF-8 Support Enabled
DEBUG - 2011-08-21 08:23:28 --> URI Class Initialized
DEBUG - 2011-08-21 08:23:28 --> Router Class Initialized
ERROR - 2011-08-21 08:23:28 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-08-21 08:23:28 --> Config Class Initialized
DEBUG - 2011-08-21 08:23:28 --> Hooks Class Initialized
DEBUG - 2011-08-21 08:23:28 --> Utf8 Class Initialized
DEBUG - 2011-08-21 08:23:28 --> UTF-8 Support Enabled
DEBUG - 2011-08-21 08:23:28 --> URI Class Initialized
DEBUG - 2011-08-21 08:23:28 --> Router Class Initialized
ERROR - 2011-08-21 08:23:28 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-08-21 08:24:03 --> Config Class Initialized
DEBUG - 2011-08-21 08:24:03 --> Hooks Class Initialized
DEBUG - 2011-08-21 08:24:03 --> Utf8 Class Initialized
DEBUG - 2011-08-21 08:24:03 --> UTF-8 Support Enabled
DEBUG - 2011-08-21 08:24:03 --> URI Class Initialized
DEBUG - 2011-08-21 08:24:03 --> Router Class Initialized
DEBUG - 2011-08-21 08:24:03 --> Output Class Initialized
DEBUG - 2011-08-21 08:24:03 --> Input Class Initialized
DEBUG - 2011-08-21 08:24:03 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-21 08:24:03 --> Language Class Initialized
DEBUG - 2011-08-21 08:24:03 --> Loader Class Initialized
DEBUG - 2011-08-21 08:24:03 --> Controller Class Initialized
ERROR - 2011-08-21 08:24:03 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-08-21 08:24:03 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-08-21 08:24:03 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-08-21 08:24:03 --> Model Class Initialized
DEBUG - 2011-08-21 08:24:03 --> Model Class Initialized
DEBUG - 2011-08-21 08:24:03 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-21 08:24:03 --> Database Driver Class Initialized
DEBUG - 2011-08-21 08:24:03 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-08-21 08:24:03 --> Helper loaded: url_helper
DEBUG - 2011-08-21 08:24:03 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-21 08:24:03 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-21 08:24:03 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-21 08:24:03 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-21 08:24:03 --> Final output sent to browser
DEBUG - 2011-08-21 08:24:03 --> Total execution time: 0.0286
DEBUG - 2011-08-21 08:24:03 --> Config Class Initialized
DEBUG - 2011-08-21 08:24:03 --> Hooks Class Initialized
DEBUG - 2011-08-21 08:24:03 --> Utf8 Class Initialized
DEBUG - 2011-08-21 08:24:03 --> UTF-8 Support Enabled
DEBUG - 2011-08-21 08:24:03 --> URI Class Initialized
DEBUG - 2011-08-21 08:24:03 --> Router Class Initialized
DEBUG - 2011-08-21 08:24:03 --> Output Class Initialized
DEBUG - 2011-08-21 08:24:03 --> Input Class Initialized
DEBUG - 2011-08-21 08:24:03 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-21 08:24:03 --> Language Class Initialized
DEBUG - 2011-08-21 08:24:03 --> Loader Class Initialized
DEBUG - 2011-08-21 08:24:03 --> Controller Class Initialized
DEBUG - 2011-08-21 08:24:03 --> Model Class Initialized
DEBUG - 2011-08-21 08:24:03 --> Model Class Initialized
DEBUG - 2011-08-21 08:24:03 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-21 08:24:03 --> Database Driver Class Initialized
DEBUG - 2011-08-21 08:24:04 --> Final output sent to browser
DEBUG - 2011-08-21 08:24:04 --> Total execution time: 0.6491
DEBUG - 2011-08-21 08:51:16 --> Config Class Initialized
DEBUG - 2011-08-21 08:51:16 --> Hooks Class Initialized
DEBUG - 2011-08-21 08:51:16 --> Utf8 Class Initialized
DEBUG - 2011-08-21 08:51:16 --> UTF-8 Support Enabled
DEBUG - 2011-08-21 08:51:16 --> URI Class Initialized
DEBUG - 2011-08-21 08:51:16 --> Router Class Initialized
DEBUG - 2011-08-21 08:51:16 --> Output Class Initialized
DEBUG - 2011-08-21 08:51:16 --> Input Class Initialized
DEBUG - 2011-08-21 08:51:16 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-21 08:51:16 --> Language Class Initialized
DEBUG - 2011-08-21 08:51:16 --> Loader Class Initialized
DEBUG - 2011-08-21 08:51:16 --> Controller Class Initialized
ERROR - 2011-08-21 08:51:16 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-08-21 08:51:16 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-08-21 08:51:16 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-08-21 08:51:16 --> Model Class Initialized
DEBUG - 2011-08-21 08:51:16 --> Model Class Initialized
DEBUG - 2011-08-21 08:51:16 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-21 08:51:16 --> Database Driver Class Initialized
DEBUG - 2011-08-21 08:51:16 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-08-21 08:51:16 --> Helper loaded: url_helper
DEBUG - 2011-08-21 08:51:16 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-21 08:51:16 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-21 08:51:16 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-21 08:51:16 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-21 08:51:16 --> Final output sent to browser
DEBUG - 2011-08-21 08:51:16 --> Total execution time: 0.1068
DEBUG - 2011-08-21 08:51:17 --> Config Class Initialized
DEBUG - 2011-08-21 08:51:17 --> Hooks Class Initialized
DEBUG - 2011-08-21 08:51:17 --> Utf8 Class Initialized
DEBUG - 2011-08-21 08:51:17 --> UTF-8 Support Enabled
DEBUG - 2011-08-21 08:51:17 --> URI Class Initialized
DEBUG - 2011-08-21 08:51:17 --> Router Class Initialized
DEBUG - 2011-08-21 08:51:17 --> Output Class Initialized
DEBUG - 2011-08-21 08:51:17 --> Input Class Initialized
DEBUG - 2011-08-21 08:51:17 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-21 08:51:17 --> Language Class Initialized
DEBUG - 2011-08-21 08:51:17 --> Loader Class Initialized
DEBUG - 2011-08-21 08:51:17 --> Controller Class Initialized
DEBUG - 2011-08-21 08:51:17 --> Model Class Initialized
DEBUG - 2011-08-21 08:51:17 --> Model Class Initialized
DEBUG - 2011-08-21 08:51:17 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-21 08:51:17 --> Database Driver Class Initialized
DEBUG - 2011-08-21 08:51:18 --> Final output sent to browser
DEBUG - 2011-08-21 08:51:18 --> Total execution time: 0.7051
DEBUG - 2011-08-21 08:51:18 --> Config Class Initialized
DEBUG - 2011-08-21 08:51:18 --> Hooks Class Initialized
DEBUG - 2011-08-21 08:51:18 --> Utf8 Class Initialized
DEBUG - 2011-08-21 08:51:18 --> UTF-8 Support Enabled
DEBUG - 2011-08-21 08:51:18 --> URI Class Initialized
DEBUG - 2011-08-21 08:51:18 --> Router Class Initialized
ERROR - 2011-08-21 08:51:18 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-08-21 08:51:19 --> Config Class Initialized
DEBUG - 2011-08-21 08:51:19 --> Hooks Class Initialized
DEBUG - 2011-08-21 08:51:19 --> Utf8 Class Initialized
DEBUG - 2011-08-21 08:51:19 --> UTF-8 Support Enabled
DEBUG - 2011-08-21 08:51:19 --> URI Class Initialized
DEBUG - 2011-08-21 08:51:19 --> Router Class Initialized
ERROR - 2011-08-21 08:51:19 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-08-21 08:51:19 --> Config Class Initialized
DEBUG - 2011-08-21 08:51:19 --> Hooks Class Initialized
DEBUG - 2011-08-21 08:51:19 --> Utf8 Class Initialized
DEBUG - 2011-08-21 08:51:19 --> UTF-8 Support Enabled
DEBUG - 2011-08-21 08:51:19 --> URI Class Initialized
DEBUG - 2011-08-21 08:51:19 --> Router Class Initialized
ERROR - 2011-08-21 08:51:19 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-08-21 10:01:40 --> Config Class Initialized
DEBUG - 2011-08-21 10:01:40 --> Hooks Class Initialized
DEBUG - 2011-08-21 10:01:40 --> Utf8 Class Initialized
DEBUG - 2011-08-21 10:01:40 --> UTF-8 Support Enabled
DEBUG - 2011-08-21 10:01:40 --> URI Class Initialized
DEBUG - 2011-08-21 10:01:40 --> Router Class Initialized
DEBUG - 2011-08-21 10:01:40 --> Output Class Initialized
DEBUG - 2011-08-21 10:01:40 --> Input Class Initialized
DEBUG - 2011-08-21 10:01:40 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-21 10:01:40 --> Language Class Initialized
DEBUG - 2011-08-21 10:01:40 --> Loader Class Initialized
DEBUG - 2011-08-21 10:01:40 --> Controller Class Initialized
ERROR - 2011-08-21 10:01:40 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-08-21 10:01:40 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-08-21 10:01:40 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-08-21 10:01:40 --> Model Class Initialized
DEBUG - 2011-08-21 10:01:40 --> Model Class Initialized
DEBUG - 2011-08-21 10:01:40 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-21 10:01:40 --> Database Driver Class Initialized
DEBUG - 2011-08-21 10:01:40 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-08-21 10:01:40 --> Helper loaded: url_helper
DEBUG - 2011-08-21 10:01:40 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-21 10:01:40 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-21 10:01:40 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-21 10:01:40 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-21 10:01:40 --> Final output sent to browser
DEBUG - 2011-08-21 10:01:40 --> Total execution time: 0.1036
DEBUG - 2011-08-21 10:01:43 --> Config Class Initialized
DEBUG - 2011-08-21 10:01:43 --> Hooks Class Initialized
DEBUG - 2011-08-21 10:01:43 --> Utf8 Class Initialized
DEBUG - 2011-08-21 10:01:43 --> UTF-8 Support Enabled
DEBUG - 2011-08-21 10:01:43 --> URI Class Initialized
DEBUG - 2011-08-21 10:01:43 --> Router Class Initialized
DEBUG - 2011-08-21 10:01:43 --> Output Class Initialized
DEBUG - 2011-08-21 10:01:43 --> Input Class Initialized
DEBUG - 2011-08-21 10:01:43 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-21 10:01:43 --> Language Class Initialized
DEBUG - 2011-08-21 10:01:43 --> Loader Class Initialized
DEBUG - 2011-08-21 10:01:43 --> Controller Class Initialized
DEBUG - 2011-08-21 10:01:43 --> Model Class Initialized
DEBUG - 2011-08-21 10:01:43 --> Model Class Initialized
DEBUG - 2011-08-21 10:01:43 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-21 10:01:43 --> Database Driver Class Initialized
DEBUG - 2011-08-21 10:01:44 --> Final output sent to browser
DEBUG - 2011-08-21 10:01:44 --> Total execution time: 0.6379
DEBUG - 2011-08-21 12:08:26 --> Config Class Initialized
DEBUG - 2011-08-21 12:08:26 --> Hooks Class Initialized
DEBUG - 2011-08-21 12:08:26 --> Utf8 Class Initialized
DEBUG - 2011-08-21 12:08:26 --> UTF-8 Support Enabled
DEBUG - 2011-08-21 12:08:26 --> URI Class Initialized
DEBUG - 2011-08-21 12:08:26 --> Router Class Initialized
ERROR - 2011-08-21 12:08:26 --> 404 Page Not Found --> robots.txt
DEBUG - 2011-08-21 13:00:32 --> Config Class Initialized
DEBUG - 2011-08-21 13:00:33 --> Hooks Class Initialized
DEBUG - 2011-08-21 13:00:33 --> Utf8 Class Initialized
DEBUG - 2011-08-21 13:00:33 --> UTF-8 Support Enabled
DEBUG - 2011-08-21 13:00:33 --> URI Class Initialized
DEBUG - 2011-08-21 13:00:33 --> Router Class Initialized
ERROR - 2011-08-21 13:00:33 --> 404 Page Not Found --> robots.txt
DEBUG - 2011-08-21 13:00:33 --> Config Class Initialized
DEBUG - 2011-08-21 13:00:33 --> Hooks Class Initialized
DEBUG - 2011-08-21 13:00:33 --> Utf8 Class Initialized
DEBUG - 2011-08-21 13:00:33 --> UTF-8 Support Enabled
DEBUG - 2011-08-21 13:00:33 --> URI Class Initialized
DEBUG - 2011-08-21 13:00:33 --> Router Class Initialized
ERROR - 2011-08-21 13:00:33 --> 404 Page Not Found --> sitemap.xml.gz
DEBUG - 2011-08-21 13:00:33 --> Config Class Initialized
DEBUG - 2011-08-21 13:00:33 --> Hooks Class Initialized
DEBUG - 2011-08-21 13:00:33 --> Utf8 Class Initialized
DEBUG - 2011-08-21 13:00:33 --> UTF-8 Support Enabled
DEBUG - 2011-08-21 13:00:33 --> URI Class Initialized
DEBUG - 2011-08-21 13:00:33 --> Router Class Initialized
ERROR - 2011-08-21 13:00:33 --> 404 Page Not Found --> sitemap.xml
DEBUG - 2011-08-21 14:51:04 --> Config Class Initialized
DEBUG - 2011-08-21 14:51:04 --> Hooks Class Initialized
DEBUG - 2011-08-21 14:51:04 --> Utf8 Class Initialized
DEBUG - 2011-08-21 14:51:04 --> UTF-8 Support Enabled
DEBUG - 2011-08-21 14:51:04 --> URI Class Initialized
DEBUG - 2011-08-21 14:51:04 --> Router Class Initialized
DEBUG - 2011-08-21 14:51:04 --> Output Class Initialized
DEBUG - 2011-08-21 14:51:04 --> Input Class Initialized
DEBUG - 2011-08-21 14:51:04 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-21 14:51:04 --> Language Class Initialized
DEBUG - 2011-08-21 14:51:04 --> Loader Class Initialized
DEBUG - 2011-08-21 14:51:04 --> Controller Class Initialized
ERROR - 2011-08-21 14:51:04 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-08-21 14:51:04 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-08-21 14:51:04 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-08-21 14:51:04 --> Model Class Initialized
DEBUG - 2011-08-21 14:51:04 --> Model Class Initialized
DEBUG - 2011-08-21 14:51:04 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-21 14:51:04 --> Database Driver Class Initialized
DEBUG - 2011-08-21 14:51:04 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-08-21 14:51:04 --> Helper loaded: url_helper
DEBUG - 2011-08-21 14:51:04 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-21 14:51:04 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-21 14:51:04 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-21 14:51:04 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-21 14:51:04 --> Final output sent to browser
DEBUG - 2011-08-21 14:51:04 --> Total execution time: 0.2753
DEBUG - 2011-08-21 14:51:05 --> Config Class Initialized
DEBUG - 2011-08-21 14:51:05 --> Hooks Class Initialized
DEBUG - 2011-08-21 14:51:05 --> Utf8 Class Initialized
DEBUG - 2011-08-21 14:51:05 --> UTF-8 Support Enabled
DEBUG - 2011-08-21 14:51:05 --> URI Class Initialized
DEBUG - 2011-08-21 14:51:05 --> Router Class Initialized
DEBUG - 2011-08-21 14:51:05 --> Output Class Initialized
DEBUG - 2011-08-21 14:51:05 --> Input Class Initialized
DEBUG - 2011-08-21 14:51:05 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-21 14:51:05 --> Language Class Initialized
DEBUG - 2011-08-21 14:51:05 --> Loader Class Initialized
DEBUG - 2011-08-21 14:51:05 --> Controller Class Initialized
DEBUG - 2011-08-21 14:51:05 --> Model Class Initialized
DEBUG - 2011-08-21 14:51:05 --> Model Class Initialized
DEBUG - 2011-08-21 14:51:05 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-21 14:51:05 --> Database Driver Class Initialized
DEBUG - 2011-08-21 14:51:06 --> Final output sent to browser
DEBUG - 2011-08-21 14:51:06 --> Total execution time: 0.6691
DEBUG - 2011-08-21 14:51:07 --> Config Class Initialized
DEBUG - 2011-08-21 14:51:07 --> Hooks Class Initialized
DEBUG - 2011-08-21 14:51:07 --> Utf8 Class Initialized
DEBUG - 2011-08-21 14:51:07 --> UTF-8 Support Enabled
DEBUG - 2011-08-21 14:51:07 --> URI Class Initialized
DEBUG - 2011-08-21 14:51:07 --> Router Class Initialized
ERROR - 2011-08-21 14:51:07 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-08-21 14:55:48 --> Config Class Initialized
DEBUG - 2011-08-21 14:55:48 --> Hooks Class Initialized
DEBUG - 2011-08-21 14:55:48 --> Utf8 Class Initialized
DEBUG - 2011-08-21 14:55:48 --> UTF-8 Support Enabled
DEBUG - 2011-08-21 14:55:48 --> URI Class Initialized
DEBUG - 2011-08-21 14:55:48 --> Router Class Initialized
DEBUG - 2011-08-21 14:55:48 --> Output Class Initialized
DEBUG - 2011-08-21 14:55:48 --> Input Class Initialized
DEBUG - 2011-08-21 14:55:48 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-21 14:55:48 --> Language Class Initialized
DEBUG - 2011-08-21 14:55:48 --> Loader Class Initialized
DEBUG - 2011-08-21 14:55:48 --> Controller Class Initialized
ERROR - 2011-08-21 14:55:48 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-08-21 14:55:48 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-08-21 14:55:48 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-08-21 14:55:48 --> Model Class Initialized
DEBUG - 2011-08-21 14:55:48 --> Model Class Initialized
DEBUG - 2011-08-21 14:55:48 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-21 14:55:48 --> Database Driver Class Initialized
DEBUG - 2011-08-21 14:55:48 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-08-21 14:55:48 --> Helper loaded: url_helper
DEBUG - 2011-08-21 14:55:48 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-21 14:55:48 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-21 14:55:48 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-21 14:55:48 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-21 14:55:48 --> Final output sent to browser
DEBUG - 2011-08-21 14:55:48 --> Total execution time: 0.0433
DEBUG - 2011-08-21 14:55:49 --> Config Class Initialized
DEBUG - 2011-08-21 14:55:49 --> Hooks Class Initialized
DEBUG - 2011-08-21 14:55:49 --> Utf8 Class Initialized
DEBUG - 2011-08-21 14:55:49 --> UTF-8 Support Enabled
DEBUG - 2011-08-21 14:55:49 --> URI Class Initialized
DEBUG - 2011-08-21 14:55:49 --> Router Class Initialized
DEBUG - 2011-08-21 14:55:49 --> Output Class Initialized
DEBUG - 2011-08-21 14:55:49 --> Input Class Initialized
DEBUG - 2011-08-21 14:55:49 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-21 14:55:49 --> Language Class Initialized
DEBUG - 2011-08-21 14:55:49 --> Loader Class Initialized
DEBUG - 2011-08-21 14:55:49 --> Controller Class Initialized
DEBUG - 2011-08-21 14:55:49 --> Model Class Initialized
DEBUG - 2011-08-21 14:55:49 --> Model Class Initialized
DEBUG - 2011-08-21 14:55:49 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-21 14:55:49 --> Database Driver Class Initialized
DEBUG - 2011-08-21 14:55:50 --> Final output sent to browser
DEBUG - 2011-08-21 14:55:50 --> Total execution time: 0.5808
DEBUG - 2011-08-21 14:55:50 --> Config Class Initialized
DEBUG - 2011-08-21 14:55:50 --> Hooks Class Initialized
DEBUG - 2011-08-21 14:55:50 --> Utf8 Class Initialized
DEBUG - 2011-08-21 14:55:50 --> UTF-8 Support Enabled
DEBUG - 2011-08-21 14:55:50 --> URI Class Initialized
DEBUG - 2011-08-21 14:55:50 --> Router Class Initialized
DEBUG - 2011-08-21 14:55:50 --> Output Class Initialized
DEBUG - 2011-08-21 14:55:50 --> Input Class Initialized
DEBUG - 2011-08-21 14:55:50 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-21 14:55:50 --> Language Class Initialized
DEBUG - 2011-08-21 14:55:50 --> Loader Class Initialized
DEBUG - 2011-08-21 14:55:50 --> Controller Class Initialized
DEBUG - 2011-08-21 14:55:50 --> Model Class Initialized
DEBUG - 2011-08-21 14:55:50 --> Model Class Initialized
DEBUG - 2011-08-21 14:55:50 --> Model Class Initialized
DEBUG - 2011-08-21 14:55:50 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-21 14:55:50 --> Database Driver Class Initialized
DEBUG - 2011-08-21 14:55:51 --> File loaded: application/views/table/main.php
DEBUG - 2011-08-21 14:55:51 --> Helper loaded: url_helper
DEBUG - 2011-08-21 14:55:51 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-21 14:55:51 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-21 14:55:51 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-21 14:55:51 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-21 14:55:51 --> Final output sent to browser
DEBUG - 2011-08-21 14:55:51 --> Total execution time: 0.3970
DEBUG - 2011-08-21 14:55:51 --> Config Class Initialized
DEBUG - 2011-08-21 14:55:51 --> Hooks Class Initialized
DEBUG - 2011-08-21 14:55:51 --> Utf8 Class Initialized
DEBUG - 2011-08-21 14:55:51 --> UTF-8 Support Enabled
DEBUG - 2011-08-21 14:55:51 --> URI Class Initialized
DEBUG - 2011-08-21 14:55:51 --> Router Class Initialized
ERROR - 2011-08-21 14:55:51 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-08-21 14:55:52 --> Config Class Initialized
DEBUG - 2011-08-21 14:55:52 --> Hooks Class Initialized
DEBUG - 2011-08-21 14:55:52 --> Utf8 Class Initialized
DEBUG - 2011-08-21 14:55:52 --> UTF-8 Support Enabled
DEBUG - 2011-08-21 14:55:52 --> URI Class Initialized
DEBUG - 2011-08-21 14:55:52 --> Router Class Initialized
ERROR - 2011-08-21 14:55:52 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-08-21 14:59:48 --> Config Class Initialized
DEBUG - 2011-08-21 14:59:48 --> Hooks Class Initialized
DEBUG - 2011-08-21 14:59:48 --> Utf8 Class Initialized
DEBUG - 2011-08-21 14:59:48 --> UTF-8 Support Enabled
DEBUG - 2011-08-21 14:59:48 --> URI Class Initialized
DEBUG - 2011-08-21 14:59:48 --> Router Class Initialized
DEBUG - 2011-08-21 14:59:48 --> Output Class Initialized
DEBUG - 2011-08-21 14:59:48 --> Input Class Initialized
DEBUG - 2011-08-21 14:59:48 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-21 14:59:48 --> Language Class Initialized
DEBUG - 2011-08-21 14:59:48 --> Loader Class Initialized
DEBUG - 2011-08-21 14:59:48 --> Controller Class Initialized
ERROR - 2011-08-21 14:59:48 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-08-21 14:59:48 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-08-21 14:59:48 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-08-21 14:59:48 --> Model Class Initialized
DEBUG - 2011-08-21 14:59:48 --> Model Class Initialized
DEBUG - 2011-08-21 14:59:48 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-21 14:59:48 --> Database Driver Class Initialized
DEBUG - 2011-08-21 14:59:48 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-08-21 14:59:48 --> Helper loaded: url_helper
DEBUG - 2011-08-21 14:59:48 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-21 14:59:48 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-21 14:59:48 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-21 14:59:48 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-21 14:59:48 --> Final output sent to browser
DEBUG - 2011-08-21 14:59:48 --> Total execution time: 0.0287
DEBUG - 2011-08-21 14:59:48 --> Config Class Initialized
DEBUG - 2011-08-21 14:59:48 --> Hooks Class Initialized
DEBUG - 2011-08-21 14:59:48 --> Utf8 Class Initialized
DEBUG - 2011-08-21 14:59:48 --> UTF-8 Support Enabled
DEBUG - 2011-08-21 14:59:48 --> URI Class Initialized
DEBUG - 2011-08-21 14:59:48 --> Router Class Initialized
DEBUG - 2011-08-21 14:59:48 --> Output Class Initialized
DEBUG - 2011-08-21 14:59:48 --> Input Class Initialized
DEBUG - 2011-08-21 14:59:48 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-21 14:59:48 --> Language Class Initialized
DEBUG - 2011-08-21 14:59:48 --> Loader Class Initialized
DEBUG - 2011-08-21 14:59:48 --> Controller Class Initialized
DEBUG - 2011-08-21 14:59:48 --> Model Class Initialized
DEBUG - 2011-08-21 14:59:48 --> Model Class Initialized
DEBUG - 2011-08-21 14:59:48 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-21 14:59:48 --> Database Driver Class Initialized
DEBUG - 2011-08-21 14:59:49 --> Final output sent to browser
DEBUG - 2011-08-21 14:59:49 --> Total execution time: 0.5520
DEBUG - 2011-08-21 14:59:50 --> Config Class Initialized
DEBUG - 2011-08-21 14:59:50 --> Hooks Class Initialized
DEBUG - 2011-08-21 14:59:50 --> Utf8 Class Initialized
DEBUG - 2011-08-21 14:59:50 --> UTF-8 Support Enabled
DEBUG - 2011-08-21 14:59:50 --> URI Class Initialized
DEBUG - 2011-08-21 14:59:50 --> Router Class Initialized
ERROR - 2011-08-21 14:59:50 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-08-21 14:59:51 --> Config Class Initialized
DEBUG - 2011-08-21 14:59:51 --> Hooks Class Initialized
DEBUG - 2011-08-21 14:59:51 --> Utf8 Class Initialized
DEBUG - 2011-08-21 14:59:51 --> UTF-8 Support Enabled
DEBUG - 2011-08-21 14:59:51 --> URI Class Initialized
DEBUG - 2011-08-21 14:59:51 --> Router Class Initialized
ERROR - 2011-08-21 14:59:51 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-08-21 15:01:04 --> Config Class Initialized
DEBUG - 2011-08-21 15:01:04 --> Hooks Class Initialized
DEBUG - 2011-08-21 15:01:04 --> Utf8 Class Initialized
DEBUG - 2011-08-21 15:01:04 --> UTF-8 Support Enabled
DEBUG - 2011-08-21 15:01:04 --> URI Class Initialized
DEBUG - 2011-08-21 15:01:04 --> Router Class Initialized
DEBUG - 2011-08-21 15:01:04 --> Output Class Initialized
DEBUG - 2011-08-21 15:01:04 --> Input Class Initialized
DEBUG - 2011-08-21 15:01:04 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-21 15:01:04 --> Language Class Initialized
DEBUG - 2011-08-21 15:01:04 --> Loader Class Initialized
DEBUG - 2011-08-21 15:01:04 --> Controller Class Initialized
ERROR - 2011-08-21 15:01:04 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-08-21 15:01:04 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-08-21 15:01:04 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-08-21 15:01:04 --> Model Class Initialized
DEBUG - 2011-08-21 15:01:04 --> Model Class Initialized
DEBUG - 2011-08-21 15:01:04 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-21 15:01:04 --> Database Driver Class Initialized
DEBUG - 2011-08-21 15:01:04 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-08-21 15:01:04 --> Helper loaded: url_helper
DEBUG - 2011-08-21 15:01:04 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-21 15:01:04 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-21 15:01:04 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-21 15:01:04 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-21 15:01:04 --> Final output sent to browser
DEBUG - 2011-08-21 15:01:04 --> Total execution time: 0.0284
DEBUG - 2011-08-21 15:01:05 --> Config Class Initialized
DEBUG - 2011-08-21 15:01:05 --> Hooks Class Initialized
DEBUG - 2011-08-21 15:01:05 --> Utf8 Class Initialized
DEBUG - 2011-08-21 15:01:05 --> UTF-8 Support Enabled
DEBUG - 2011-08-21 15:01:05 --> URI Class Initialized
DEBUG - 2011-08-21 15:01:05 --> Router Class Initialized
DEBUG - 2011-08-21 15:01:05 --> Output Class Initialized
DEBUG - 2011-08-21 15:01:05 --> Input Class Initialized
DEBUG - 2011-08-21 15:01:05 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-21 15:01:05 --> Language Class Initialized
DEBUG - 2011-08-21 15:01:05 --> Loader Class Initialized
DEBUG - 2011-08-21 15:01:05 --> Controller Class Initialized
DEBUG - 2011-08-21 15:01:05 --> Model Class Initialized
DEBUG - 2011-08-21 15:01:05 --> Model Class Initialized
DEBUG - 2011-08-21 15:01:05 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-21 15:01:05 --> Database Driver Class Initialized
DEBUG - 2011-08-21 15:01:06 --> Final output sent to browser
DEBUG - 2011-08-21 15:01:06 --> Total execution time: 1.2253
DEBUG - 2011-08-21 15:01:07 --> Config Class Initialized
DEBUG - 2011-08-21 15:01:07 --> Hooks Class Initialized
DEBUG - 2011-08-21 15:01:07 --> Utf8 Class Initialized
DEBUG - 2011-08-21 15:01:07 --> UTF-8 Support Enabled
DEBUG - 2011-08-21 15:01:07 --> URI Class Initialized
DEBUG - 2011-08-21 15:01:07 --> Router Class Initialized
ERROR - 2011-08-21 15:01:07 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-08-21 15:01:14 --> Config Class Initialized
DEBUG - 2011-08-21 15:01:14 --> Hooks Class Initialized
DEBUG - 2011-08-21 15:01:14 --> Utf8 Class Initialized
DEBUG - 2011-08-21 15:01:14 --> UTF-8 Support Enabled
DEBUG - 2011-08-21 15:01:14 --> URI Class Initialized
DEBUG - 2011-08-21 15:01:14 --> Router Class Initialized
ERROR - 2011-08-21 15:01:14 --> 404 Page Not Found --> robots.txt
DEBUG - 2011-08-21 15:01:14 --> Config Class Initialized
DEBUG - 2011-08-21 15:01:14 --> Hooks Class Initialized
DEBUG - 2011-08-21 15:01:14 --> Utf8 Class Initialized
DEBUG - 2011-08-21 15:01:14 --> UTF-8 Support Enabled
DEBUG - 2011-08-21 15:01:14 --> URI Class Initialized
DEBUG - 2011-08-21 15:01:14 --> Router Class Initialized
DEBUG - 2011-08-21 15:01:14 --> Output Class Initialized
DEBUG - 2011-08-21 15:01:14 --> Input Class Initialized
DEBUG - 2011-08-21 15:01:14 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-21 15:01:14 --> Language Class Initialized
DEBUG - 2011-08-21 15:01:14 --> Loader Class Initialized
DEBUG - 2011-08-21 15:01:14 --> Controller Class Initialized
ERROR - 2011-08-21 15:01:14 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-08-21 15:01:14 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-08-21 15:01:14 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-08-21 15:01:14 --> Model Class Initialized
DEBUG - 2011-08-21 15:01:14 --> Model Class Initialized
DEBUG - 2011-08-21 15:01:14 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-21 15:01:14 --> Database Driver Class Initialized
DEBUG - 2011-08-21 15:01:14 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-08-21 15:01:14 --> Helper loaded: url_helper
DEBUG - 2011-08-21 15:01:14 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-21 15:01:14 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-21 15:01:14 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-21 15:01:14 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-21 15:01:14 --> Final output sent to browser
DEBUG - 2011-08-21 15:01:14 --> Total execution time: 0.0281
DEBUG - 2011-08-21 15:01:14 --> Config Class Initialized
DEBUG - 2011-08-21 15:01:14 --> Hooks Class Initialized
DEBUG - 2011-08-21 15:01:14 --> Utf8 Class Initialized
DEBUG - 2011-08-21 15:01:14 --> UTF-8 Support Enabled
DEBUG - 2011-08-21 15:01:14 --> URI Class Initialized
DEBUG - 2011-08-21 15:01:14 --> Router Class Initialized
DEBUG - 2011-08-21 15:01:14 --> Output Class Initialized
DEBUG - 2011-08-21 15:01:14 --> Input Class Initialized
DEBUG - 2011-08-21 15:01:14 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-21 15:01:14 --> Language Class Initialized
DEBUG - 2011-08-21 15:01:14 --> Loader Class Initialized
DEBUG - 2011-08-21 15:01:14 --> Controller Class Initialized
ERROR - 2011-08-21 15:01:14 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-08-21 15:01:14 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-08-21 15:01:14 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-08-21 15:01:14 --> Model Class Initialized
DEBUG - 2011-08-21 15:01:14 --> Model Class Initialized
DEBUG - 2011-08-21 15:01:14 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-21 15:01:14 --> Database Driver Class Initialized
DEBUG - 2011-08-21 15:01:14 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-08-21 15:01:14 --> Helper loaded: url_helper
DEBUG - 2011-08-21 15:01:14 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-21 15:01:14 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-21 15:01:14 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-21 15:01:14 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-21 15:01:14 --> Final output sent to browser
DEBUG - 2011-08-21 15:01:14 --> Total execution time: 0.0294
DEBUG - 2011-08-21 15:01:15 --> Config Class Initialized
DEBUG - 2011-08-21 15:01:15 --> Hooks Class Initialized
DEBUG - 2011-08-21 15:01:15 --> Utf8 Class Initialized
DEBUG - 2011-08-21 15:01:15 --> UTF-8 Support Enabled
DEBUG - 2011-08-21 15:01:15 --> URI Class Initialized
DEBUG - 2011-08-21 15:01:15 --> Router Class Initialized
DEBUG - 2011-08-21 15:01:15 --> Output Class Initialized
DEBUG - 2011-08-21 15:01:15 --> Input Class Initialized
DEBUG - 2011-08-21 15:01:15 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-21 15:01:15 --> Language Class Initialized
DEBUG - 2011-08-21 15:01:15 --> Loader Class Initialized
DEBUG - 2011-08-21 15:01:15 --> Controller Class Initialized
DEBUG - 2011-08-21 15:01:15 --> Model Class Initialized
DEBUG - 2011-08-21 15:01:15 --> Model Class Initialized
DEBUG - 2011-08-21 15:01:15 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-21 15:01:15 --> Database Driver Class Initialized
DEBUG - 2011-08-21 15:01:15 --> Final output sent to browser
DEBUG - 2011-08-21 15:01:15 --> Total execution time: 0.5288
DEBUG - 2011-08-21 15:01:16 --> Config Class Initialized
DEBUG - 2011-08-21 15:01:16 --> Hooks Class Initialized
DEBUG - 2011-08-21 15:01:16 --> Utf8 Class Initialized
DEBUG - 2011-08-21 15:01:16 --> UTF-8 Support Enabled
DEBUG - 2011-08-21 15:01:16 --> URI Class Initialized
DEBUG - 2011-08-21 15:01:16 --> Router Class Initialized
ERROR - 2011-08-21 15:01:16 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-08-21 15:01:18 --> Config Class Initialized
DEBUG - 2011-08-21 15:01:18 --> Hooks Class Initialized
DEBUG - 2011-08-21 15:01:18 --> Utf8 Class Initialized
DEBUG - 2011-08-21 15:01:18 --> UTF-8 Support Enabled
DEBUG - 2011-08-21 15:01:18 --> URI Class Initialized
DEBUG - 2011-08-21 15:01:18 --> Router Class Initialized
ERROR - 2011-08-21 15:01:18 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-08-21 15:02:15 --> Config Class Initialized
DEBUG - 2011-08-21 15:02:15 --> Hooks Class Initialized
DEBUG - 2011-08-21 15:02:15 --> Utf8 Class Initialized
DEBUG - 2011-08-21 15:02:15 --> UTF-8 Support Enabled
DEBUG - 2011-08-21 15:02:15 --> URI Class Initialized
DEBUG - 2011-08-21 15:02:15 --> Router Class Initialized
DEBUG - 2011-08-21 15:02:15 --> No URI present. Default controller set.
DEBUG - 2011-08-21 15:02:15 --> Output Class Initialized
DEBUG - 2011-08-21 15:02:15 --> Input Class Initialized
DEBUG - 2011-08-21 15:02:15 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-21 15:02:15 --> Language Class Initialized
DEBUG - 2011-08-21 15:02:15 --> Loader Class Initialized
DEBUG - 2011-08-21 15:02:15 --> Controller Class Initialized
DEBUG - 2011-08-21 15:02:15 --> File loaded: application/views/splash/main.php
DEBUG - 2011-08-21 15:02:15 --> Helper loaded: url_helper
DEBUG - 2011-08-21 15:02:15 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-21 15:02:15 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-21 15:02:15 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-21 15:02:15 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-21 15:02:15 --> Final output sent to browser
DEBUG - 2011-08-21 15:02:15 --> Total execution time: 0.1983
DEBUG - 2011-08-21 15:15:30 --> Config Class Initialized
DEBUG - 2011-08-21 15:15:30 --> Hooks Class Initialized
DEBUG - 2011-08-21 15:15:30 --> Utf8 Class Initialized
DEBUG - 2011-08-21 15:15:30 --> UTF-8 Support Enabled
DEBUG - 2011-08-21 15:15:30 --> URI Class Initialized
DEBUG - 2011-08-21 15:15:30 --> Router Class Initialized
DEBUG - 2011-08-21 15:15:30 --> Output Class Initialized
DEBUG - 2011-08-21 15:15:30 --> Input Class Initialized
DEBUG - 2011-08-21 15:15:30 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-21 15:15:30 --> Language Class Initialized
DEBUG - 2011-08-21 15:15:30 --> Loader Class Initialized
DEBUG - 2011-08-21 15:15:30 --> Controller Class Initialized
DEBUG - 2011-08-21 15:15:30 --> Model Class Initialized
DEBUG - 2011-08-21 15:15:30 --> Model Class Initialized
DEBUG - 2011-08-21 15:15:30 --> Model Class Initialized
DEBUG - 2011-08-21 15:15:30 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-21 15:15:30 --> Database Driver Class Initialized
DEBUG - 2011-08-21 15:15:30 --> File loaded: application/views/table/main.php
DEBUG - 2011-08-21 15:15:30 --> Helper loaded: url_helper
DEBUG - 2011-08-21 15:15:30 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-21 15:15:30 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-21 15:15:30 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-21 15:15:30 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-21 15:15:30 --> Final output sent to browser
DEBUG - 2011-08-21 15:15:30 --> Total execution time: 0.3825
DEBUG - 2011-08-21 15:15:32 --> Config Class Initialized
DEBUG - 2011-08-21 15:15:32 --> Hooks Class Initialized
DEBUG - 2011-08-21 15:15:32 --> Utf8 Class Initialized
DEBUG - 2011-08-21 15:15:32 --> UTF-8 Support Enabled
DEBUG - 2011-08-21 15:15:32 --> URI Class Initialized
DEBUG - 2011-08-21 15:15:32 --> Router Class Initialized
ERROR - 2011-08-21 15:15:32 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-08-21 15:15:34 --> Config Class Initialized
DEBUG - 2011-08-21 15:15:34 --> Hooks Class Initialized
DEBUG - 2011-08-21 15:15:34 --> Utf8 Class Initialized
DEBUG - 2011-08-21 15:15:34 --> UTF-8 Support Enabled
DEBUG - 2011-08-21 15:15:34 --> URI Class Initialized
DEBUG - 2011-08-21 15:15:34 --> Router Class Initialized
ERROR - 2011-08-21 15:15:34 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-08-21 15:16:08 --> Config Class Initialized
DEBUG - 2011-08-21 15:16:08 --> Hooks Class Initialized
DEBUG - 2011-08-21 15:16:08 --> Utf8 Class Initialized
DEBUG - 2011-08-21 15:16:08 --> UTF-8 Support Enabled
DEBUG - 2011-08-21 15:16:08 --> URI Class Initialized
DEBUG - 2011-08-21 15:16:08 --> Router Class Initialized
DEBUG - 2011-08-21 15:16:08 --> Output Class Initialized
DEBUG - 2011-08-21 15:16:08 --> Input Class Initialized
DEBUG - 2011-08-21 15:16:08 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-21 15:16:08 --> Language Class Initialized
DEBUG - 2011-08-21 15:16:08 --> Loader Class Initialized
DEBUG - 2011-08-21 15:16:08 --> Controller Class Initialized
DEBUG - 2011-08-21 15:16:08 --> Model Class Initialized
DEBUG - 2011-08-21 15:16:08 --> Model Class Initialized
DEBUG - 2011-08-21 15:16:08 --> Model Class Initialized
DEBUG - 2011-08-21 15:16:08 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-21 15:16:08 --> Database Driver Class Initialized
DEBUG - 2011-08-21 15:16:08 --> File loaded: application/views/table/main.php
DEBUG - 2011-08-21 15:16:08 --> Helper loaded: url_helper
DEBUG - 2011-08-21 15:16:08 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-21 15:16:08 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-21 15:16:08 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-21 15:16:08 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-21 15:16:08 --> Final output sent to browser
DEBUG - 2011-08-21 15:16:08 --> Total execution time: 0.1935
DEBUG - 2011-08-21 15:16:54 --> Config Class Initialized
DEBUG - 2011-08-21 15:16:54 --> Hooks Class Initialized
DEBUG - 2011-08-21 15:16:54 --> Utf8 Class Initialized
DEBUG - 2011-08-21 15:16:54 --> UTF-8 Support Enabled
DEBUG - 2011-08-21 15:16:54 --> URI Class Initialized
DEBUG - 2011-08-21 15:16:54 --> Router Class Initialized
DEBUG - 2011-08-21 15:16:54 --> Output Class Initialized
DEBUG - 2011-08-21 15:16:54 --> Input Class Initialized
DEBUG - 2011-08-21 15:16:54 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-21 15:16:54 --> Language Class Initialized
DEBUG - 2011-08-21 15:16:54 --> Loader Class Initialized
DEBUG - 2011-08-21 15:16:54 --> Controller Class Initialized
DEBUG - 2011-08-21 15:16:54 --> Model Class Initialized
DEBUG - 2011-08-21 15:16:54 --> Model Class Initialized
DEBUG - 2011-08-21 15:16:54 --> Model Class Initialized
DEBUG - 2011-08-21 15:16:54 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-21 15:16:54 --> Database Driver Class Initialized
DEBUG - 2011-08-21 15:16:55 --> File loaded: application/views/table/main.php
DEBUG - 2011-08-21 15:16:55 --> Helper loaded: url_helper
DEBUG - 2011-08-21 15:16:55 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-21 15:16:55 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-21 15:16:55 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-21 15:16:55 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-21 15:16:55 --> Final output sent to browser
DEBUG - 2011-08-21 15:16:55 --> Total execution time: 0.3017
DEBUG - 2011-08-21 15:16:56 --> Config Class Initialized
DEBUG - 2011-08-21 15:16:56 --> Hooks Class Initialized
DEBUG - 2011-08-21 15:16:56 --> Utf8 Class Initialized
DEBUG - 2011-08-21 15:16:56 --> UTF-8 Support Enabled
DEBUG - 2011-08-21 15:16:56 --> URI Class Initialized
DEBUG - 2011-08-21 15:16:56 --> Router Class Initialized
DEBUG - 2011-08-21 15:16:56 --> Output Class Initialized
DEBUG - 2011-08-21 15:16:56 --> Input Class Initialized
DEBUG - 2011-08-21 15:16:56 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-21 15:16:56 --> Language Class Initialized
DEBUG - 2011-08-21 15:16:56 --> Loader Class Initialized
DEBUG - 2011-08-21 15:16:56 --> Controller Class Initialized
DEBUG - 2011-08-21 15:16:56 --> Model Class Initialized
DEBUG - 2011-08-21 15:16:56 --> Model Class Initialized
DEBUG - 2011-08-21 15:16:56 --> Model Class Initialized
DEBUG - 2011-08-21 15:16:56 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-21 15:16:56 --> Database Driver Class Initialized
DEBUG - 2011-08-21 15:16:56 --> File loaded: application/views/table/main.php
DEBUG - 2011-08-21 15:16:56 --> Helper loaded: url_helper
DEBUG - 2011-08-21 15:16:56 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-21 15:16:56 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-21 15:16:56 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-21 15:16:56 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-21 15:16:56 --> Final output sent to browser
DEBUG - 2011-08-21 15:16:56 --> Total execution time: 0.0444
DEBUG - 2011-08-21 15:17:19 --> Config Class Initialized
DEBUG - 2011-08-21 15:17:19 --> Hooks Class Initialized
DEBUG - 2011-08-21 15:17:19 --> Utf8 Class Initialized
DEBUG - 2011-08-21 15:17:19 --> UTF-8 Support Enabled
DEBUG - 2011-08-21 15:17:19 --> URI Class Initialized
DEBUG - 2011-08-21 15:17:19 --> Router Class Initialized
DEBUG - 2011-08-21 15:17:19 --> Output Class Initialized
DEBUG - 2011-08-21 15:17:19 --> Input Class Initialized
DEBUG - 2011-08-21 15:17:19 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-21 15:17:19 --> Language Class Initialized
DEBUG - 2011-08-21 15:17:19 --> Loader Class Initialized
DEBUG - 2011-08-21 15:17:19 --> Controller Class Initialized
DEBUG - 2011-08-21 15:17:19 --> Model Class Initialized
DEBUG - 2011-08-21 15:17:19 --> Model Class Initialized
DEBUG - 2011-08-21 15:17:19 --> Model Class Initialized
DEBUG - 2011-08-21 15:17:19 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-21 15:17:19 --> Database Driver Class Initialized
DEBUG - 2011-08-21 15:17:20 --> File loaded: application/views/table/main.php
DEBUG - 2011-08-21 15:17:20 --> Helper loaded: url_helper
DEBUG - 2011-08-21 15:17:20 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-21 15:17:20 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-21 15:17:20 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-21 15:17:20 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-21 15:17:20 --> Final output sent to browser
DEBUG - 2011-08-21 15:17:20 --> Total execution time: 0.6570
DEBUG - 2011-08-21 15:17:22 --> Config Class Initialized
DEBUG - 2011-08-21 15:17:22 --> Hooks Class Initialized
DEBUG - 2011-08-21 15:17:22 --> Utf8 Class Initialized
DEBUG - 2011-08-21 15:17:22 --> UTF-8 Support Enabled
DEBUG - 2011-08-21 15:17:22 --> URI Class Initialized
DEBUG - 2011-08-21 15:17:22 --> Router Class Initialized
DEBUG - 2011-08-21 15:17:22 --> Output Class Initialized
DEBUG - 2011-08-21 15:17:22 --> Input Class Initialized
DEBUG - 2011-08-21 15:17:22 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-21 15:17:22 --> Language Class Initialized
DEBUG - 2011-08-21 15:17:22 --> Loader Class Initialized
DEBUG - 2011-08-21 15:17:22 --> Controller Class Initialized
DEBUG - 2011-08-21 15:17:22 --> Model Class Initialized
DEBUG - 2011-08-21 15:17:22 --> Model Class Initialized
DEBUG - 2011-08-21 15:17:22 --> Model Class Initialized
DEBUG - 2011-08-21 15:17:22 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-21 15:17:22 --> Database Driver Class Initialized
DEBUG - 2011-08-21 15:17:22 --> File loaded: application/views/table/main.php
DEBUG - 2011-08-21 15:17:22 --> Helper loaded: url_helper
DEBUG - 2011-08-21 15:17:22 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-21 15:17:22 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-21 15:17:22 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-21 15:17:22 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-21 15:17:22 --> Final output sent to browser
DEBUG - 2011-08-21 15:17:22 --> Total execution time: 0.0420
DEBUG - 2011-08-21 15:17:45 --> Config Class Initialized
DEBUG - 2011-08-21 15:17:45 --> Hooks Class Initialized
DEBUG - 2011-08-21 15:17:45 --> Utf8 Class Initialized
DEBUG - 2011-08-21 15:17:45 --> UTF-8 Support Enabled
DEBUG - 2011-08-21 15:17:45 --> URI Class Initialized
DEBUG - 2011-08-21 15:17:45 --> Router Class Initialized
DEBUG - 2011-08-21 15:17:45 --> Output Class Initialized
DEBUG - 2011-08-21 15:17:45 --> Input Class Initialized
DEBUG - 2011-08-21 15:17:45 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-21 15:17:45 --> Language Class Initialized
DEBUG - 2011-08-21 15:17:45 --> Loader Class Initialized
DEBUG - 2011-08-21 15:17:45 --> Controller Class Initialized
DEBUG - 2011-08-21 15:17:45 --> Model Class Initialized
DEBUG - 2011-08-21 15:17:45 --> Model Class Initialized
DEBUG - 2011-08-21 15:17:45 --> Model Class Initialized
DEBUG - 2011-08-21 15:17:45 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-21 15:17:45 --> Database Driver Class Initialized
DEBUG - 2011-08-21 15:17:45 --> File loaded: application/views/table/main.php
DEBUG - 2011-08-21 15:17:45 --> Helper loaded: url_helper
DEBUG - 2011-08-21 15:17:45 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-21 15:17:45 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-21 15:17:45 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-21 15:17:45 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-21 15:17:45 --> Final output sent to browser
DEBUG - 2011-08-21 15:17:45 --> Total execution time: 0.1999
DEBUG - 2011-08-21 15:17:47 --> Config Class Initialized
DEBUG - 2011-08-21 15:17:47 --> Hooks Class Initialized
DEBUG - 2011-08-21 15:17:47 --> Utf8 Class Initialized
DEBUG - 2011-08-21 15:17:47 --> UTF-8 Support Enabled
DEBUG - 2011-08-21 15:17:47 --> URI Class Initialized
DEBUG - 2011-08-21 15:17:47 --> Router Class Initialized
DEBUG - 2011-08-21 15:17:47 --> Output Class Initialized
DEBUG - 2011-08-21 15:17:47 --> Input Class Initialized
DEBUG - 2011-08-21 15:17:47 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-21 15:17:47 --> Language Class Initialized
DEBUG - 2011-08-21 15:17:47 --> Loader Class Initialized
DEBUG - 2011-08-21 15:17:47 --> Controller Class Initialized
DEBUG - 2011-08-21 15:17:47 --> Model Class Initialized
DEBUG - 2011-08-21 15:17:47 --> Model Class Initialized
DEBUG - 2011-08-21 15:17:47 --> Model Class Initialized
DEBUG - 2011-08-21 15:17:47 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-21 15:17:47 --> Database Driver Class Initialized
DEBUG - 2011-08-21 15:17:47 --> File loaded: application/views/table/main.php
DEBUG - 2011-08-21 15:17:47 --> Helper loaded: url_helper
DEBUG - 2011-08-21 15:17:47 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-21 15:17:47 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-21 15:17:47 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-21 15:17:47 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-21 15:17:47 --> Final output sent to browser
DEBUG - 2011-08-21 15:17:47 --> Total execution time: 0.0627
DEBUG - 2011-08-21 15:18:07 --> Config Class Initialized
DEBUG - 2011-08-21 15:18:07 --> Hooks Class Initialized
DEBUG - 2011-08-21 15:18:07 --> Utf8 Class Initialized
DEBUG - 2011-08-21 15:18:07 --> UTF-8 Support Enabled
DEBUG - 2011-08-21 15:18:07 --> URI Class Initialized
DEBUG - 2011-08-21 15:18:07 --> Router Class Initialized
DEBUG - 2011-08-21 15:18:07 --> Output Class Initialized
DEBUG - 2011-08-21 15:18:07 --> Input Class Initialized
DEBUG - 2011-08-21 15:18:07 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-21 15:18:07 --> Language Class Initialized
DEBUG - 2011-08-21 15:18:07 --> Loader Class Initialized
DEBUG - 2011-08-21 15:18:07 --> Controller Class Initialized
DEBUG - 2011-08-21 15:18:07 --> Model Class Initialized
DEBUG - 2011-08-21 15:18:07 --> Model Class Initialized
DEBUG - 2011-08-21 15:18:07 --> Model Class Initialized
DEBUG - 2011-08-21 15:18:07 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-21 15:18:07 --> Database Driver Class Initialized
DEBUG - 2011-08-21 15:18:09 --> File loaded: application/views/table/main.php
DEBUG - 2011-08-21 15:18:09 --> Helper loaded: url_helper
DEBUG - 2011-08-21 15:18:09 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-21 15:18:09 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-21 15:18:09 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-21 15:18:09 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-21 15:18:09 --> Final output sent to browser
DEBUG - 2011-08-21 15:18:09 --> Total execution time: 1.5941
DEBUG - 2011-08-21 15:18:10 --> Config Class Initialized
DEBUG - 2011-08-21 15:18:10 --> Hooks Class Initialized
DEBUG - 2011-08-21 15:18:10 --> Utf8 Class Initialized
DEBUG - 2011-08-21 15:18:10 --> UTF-8 Support Enabled
DEBUG - 2011-08-21 15:18:10 --> URI Class Initialized
DEBUG - 2011-08-21 15:18:10 --> Router Class Initialized
DEBUG - 2011-08-21 15:18:10 --> Output Class Initialized
DEBUG - 2011-08-21 15:18:10 --> Input Class Initialized
DEBUG - 2011-08-21 15:18:10 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-21 15:18:10 --> Language Class Initialized
DEBUG - 2011-08-21 15:18:10 --> Loader Class Initialized
DEBUG - 2011-08-21 15:18:10 --> Controller Class Initialized
DEBUG - 2011-08-21 15:18:10 --> Model Class Initialized
DEBUG - 2011-08-21 15:18:10 --> Model Class Initialized
DEBUG - 2011-08-21 15:18:10 --> Model Class Initialized
DEBUG - 2011-08-21 15:18:10 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-21 15:18:10 --> Database Driver Class Initialized
DEBUG - 2011-08-21 15:18:10 --> File loaded: application/views/table/main.php
DEBUG - 2011-08-21 15:18:10 --> Helper loaded: url_helper
DEBUG - 2011-08-21 15:18:10 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-21 15:18:10 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-21 15:18:10 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-21 15:18:10 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-21 15:18:10 --> Final output sent to browser
DEBUG - 2011-08-21 15:18:10 --> Total execution time: 0.0720
DEBUG - 2011-08-21 15:18:11 --> Config Class Initialized
DEBUG - 2011-08-21 15:18:11 --> Hooks Class Initialized
DEBUG - 2011-08-21 15:18:11 --> Utf8 Class Initialized
DEBUG - 2011-08-21 15:18:11 --> UTF-8 Support Enabled
DEBUG - 2011-08-21 15:18:11 --> URI Class Initialized
DEBUG - 2011-08-21 15:18:11 --> Router Class Initialized
DEBUG - 2011-08-21 15:18:11 --> Output Class Initialized
DEBUG - 2011-08-21 15:18:11 --> Input Class Initialized
DEBUG - 2011-08-21 15:18:11 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-21 15:18:11 --> Language Class Initialized
DEBUG - 2011-08-21 15:18:11 --> Loader Class Initialized
DEBUG - 2011-08-21 15:18:11 --> Controller Class Initialized
DEBUG - 2011-08-21 15:18:11 --> Model Class Initialized
DEBUG - 2011-08-21 15:18:11 --> Model Class Initialized
DEBUG - 2011-08-21 15:18:11 --> Model Class Initialized
DEBUG - 2011-08-21 15:18:11 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-21 15:18:11 --> Database Driver Class Initialized
DEBUG - 2011-08-21 15:18:11 --> File loaded: application/views/table/main.php
DEBUG - 2011-08-21 15:18:11 --> Helper loaded: url_helper
DEBUG - 2011-08-21 15:18:11 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-21 15:18:11 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-21 15:18:11 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-21 15:18:11 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-21 15:18:11 --> Final output sent to browser
DEBUG - 2011-08-21 15:18:11 --> Total execution time: 0.0505
DEBUG - 2011-08-21 15:18:30 --> Config Class Initialized
DEBUG - 2011-08-21 15:18:30 --> Hooks Class Initialized
DEBUG - 2011-08-21 15:18:30 --> Utf8 Class Initialized
DEBUG - 2011-08-21 15:18:30 --> UTF-8 Support Enabled
DEBUG - 2011-08-21 15:18:30 --> URI Class Initialized
DEBUG - 2011-08-21 15:18:30 --> Router Class Initialized
DEBUG - 2011-08-21 15:18:30 --> Output Class Initialized
DEBUG - 2011-08-21 15:18:30 --> Input Class Initialized
DEBUG - 2011-08-21 15:18:30 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-21 15:18:30 --> Language Class Initialized
DEBUG - 2011-08-21 15:18:30 --> Loader Class Initialized
DEBUG - 2011-08-21 15:18:30 --> Controller Class Initialized
DEBUG - 2011-08-21 15:18:30 --> Model Class Initialized
DEBUG - 2011-08-21 15:18:30 --> Model Class Initialized
DEBUG - 2011-08-21 15:18:30 --> Model Class Initialized
DEBUG - 2011-08-21 15:18:30 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-21 15:18:30 --> Database Driver Class Initialized
DEBUG - 2011-08-21 15:18:30 --> File loaded: application/views/table/main.php
DEBUG - 2011-08-21 15:18:30 --> Helper loaded: url_helper
DEBUG - 2011-08-21 15:18:30 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-21 15:18:30 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-21 15:18:30 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-21 15:18:30 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-21 15:18:30 --> Final output sent to browser
DEBUG - 2011-08-21 15:18:30 --> Total execution time: 0.2043
DEBUG - 2011-08-21 15:19:20 --> Config Class Initialized
DEBUG - 2011-08-21 15:19:20 --> Hooks Class Initialized
DEBUG - 2011-08-21 15:19:20 --> Utf8 Class Initialized
DEBUG - 2011-08-21 15:19:20 --> UTF-8 Support Enabled
DEBUG - 2011-08-21 15:19:20 --> URI Class Initialized
DEBUG - 2011-08-21 15:19:20 --> Router Class Initialized
DEBUG - 2011-08-21 15:19:20 --> Output Class Initialized
DEBUG - 2011-08-21 15:19:20 --> Input Class Initialized
DEBUG - 2011-08-21 15:19:20 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-21 15:19:20 --> Language Class Initialized
DEBUG - 2011-08-21 15:19:20 --> Loader Class Initialized
DEBUG - 2011-08-21 15:19:20 --> Controller Class Initialized
DEBUG - 2011-08-21 15:19:20 --> Model Class Initialized
DEBUG - 2011-08-21 15:19:20 --> Model Class Initialized
DEBUG - 2011-08-21 15:19:20 --> Model Class Initialized
DEBUG - 2011-08-21 15:19:20 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-21 15:19:20 --> Database Driver Class Initialized
DEBUG - 2011-08-21 15:19:20 --> File loaded: application/views/table/main.php
DEBUG - 2011-08-21 15:19:20 --> Helper loaded: url_helper
DEBUG - 2011-08-21 15:19:20 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-21 15:19:20 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-21 15:19:20 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-21 15:19:20 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-21 15:19:20 --> Final output sent to browser
DEBUG - 2011-08-21 15:19:20 --> Total execution time: 0.2094
DEBUG - 2011-08-21 15:19:21 --> Config Class Initialized
DEBUG - 2011-08-21 15:19:21 --> Hooks Class Initialized
DEBUG - 2011-08-21 15:19:21 --> Utf8 Class Initialized
DEBUG - 2011-08-21 15:19:21 --> UTF-8 Support Enabled
DEBUG - 2011-08-21 15:19:21 --> URI Class Initialized
DEBUG - 2011-08-21 15:19:21 --> Router Class Initialized
DEBUG - 2011-08-21 15:19:21 --> Output Class Initialized
DEBUG - 2011-08-21 15:19:21 --> Input Class Initialized
DEBUG - 2011-08-21 15:19:21 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-21 15:19:21 --> Language Class Initialized
DEBUG - 2011-08-21 15:19:21 --> Loader Class Initialized
DEBUG - 2011-08-21 15:19:21 --> Controller Class Initialized
DEBUG - 2011-08-21 15:19:21 --> Model Class Initialized
DEBUG - 2011-08-21 15:19:21 --> Model Class Initialized
DEBUG - 2011-08-21 15:19:21 --> Model Class Initialized
DEBUG - 2011-08-21 15:19:21 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-21 15:19:21 --> Database Driver Class Initialized
DEBUG - 2011-08-21 15:19:21 --> File loaded: application/views/table/main.php
DEBUG - 2011-08-21 15:19:21 --> Helper loaded: url_helper
DEBUG - 2011-08-21 15:19:21 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-21 15:19:21 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-21 15:19:21 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-21 15:19:21 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-21 15:19:21 --> Final output sent to browser
DEBUG - 2011-08-21 15:19:21 --> Total execution time: 0.0779
DEBUG - 2011-08-21 15:19:45 --> Config Class Initialized
DEBUG - 2011-08-21 15:19:45 --> Hooks Class Initialized
DEBUG - 2011-08-21 15:19:45 --> Utf8 Class Initialized
DEBUG - 2011-08-21 15:19:45 --> UTF-8 Support Enabled
DEBUG - 2011-08-21 15:19:45 --> URI Class Initialized
DEBUG - 2011-08-21 15:19:45 --> Router Class Initialized
DEBUG - 2011-08-21 15:19:45 --> Output Class Initialized
DEBUG - 2011-08-21 15:19:45 --> Input Class Initialized
DEBUG - 2011-08-21 15:19:45 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-21 15:19:45 --> Language Class Initialized
DEBUG - 2011-08-21 15:19:45 --> Loader Class Initialized
DEBUG - 2011-08-21 15:19:45 --> Controller Class Initialized
DEBUG - 2011-08-21 15:19:45 --> Model Class Initialized
DEBUG - 2011-08-21 15:19:45 --> Model Class Initialized
DEBUG - 2011-08-21 15:19:45 --> Model Class Initialized
DEBUG - 2011-08-21 15:19:45 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-21 15:19:45 --> Database Driver Class Initialized
DEBUG - 2011-08-21 15:19:45 --> File loaded: application/views/table/main.php
DEBUG - 2011-08-21 15:19:45 --> Helper loaded: url_helper
DEBUG - 2011-08-21 15:19:45 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-21 15:19:45 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-21 15:19:45 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-21 15:19:45 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-21 15:19:45 --> Final output sent to browser
DEBUG - 2011-08-21 15:19:45 --> Total execution time: 0.2558
DEBUG - 2011-08-21 15:19:52 --> Config Class Initialized
DEBUG - 2011-08-21 15:19:52 --> Hooks Class Initialized
DEBUG - 2011-08-21 15:19:52 --> Utf8 Class Initialized
DEBUG - 2011-08-21 15:19:52 --> UTF-8 Support Enabled
DEBUG - 2011-08-21 15:19:52 --> URI Class Initialized
DEBUG - 2011-08-21 15:19:52 --> Router Class Initialized
DEBUG - 2011-08-21 15:19:52 --> Output Class Initialized
DEBUG - 2011-08-21 15:19:52 --> Input Class Initialized
DEBUG - 2011-08-21 15:19:52 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-21 15:19:52 --> Language Class Initialized
DEBUG - 2011-08-21 15:19:52 --> Loader Class Initialized
DEBUG - 2011-08-21 15:19:52 --> Controller Class Initialized
DEBUG - 2011-08-21 15:19:52 --> Model Class Initialized
DEBUG - 2011-08-21 15:19:52 --> Model Class Initialized
DEBUG - 2011-08-21 15:19:52 --> Model Class Initialized
DEBUG - 2011-08-21 15:19:52 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-21 15:19:52 --> Database Driver Class Initialized
DEBUG - 2011-08-21 15:19:52 --> File loaded: application/views/table/main.php
DEBUG - 2011-08-21 15:19:52 --> Helper loaded: url_helper
DEBUG - 2011-08-21 15:19:52 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-21 15:19:52 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-21 15:19:52 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-21 15:19:52 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-21 15:19:52 --> Final output sent to browser
DEBUG - 2011-08-21 15:19:52 --> Total execution time: 0.0516
DEBUG - 2011-08-21 15:23:51 --> Config Class Initialized
DEBUG - 2011-08-21 15:23:51 --> Hooks Class Initialized
DEBUG - 2011-08-21 15:23:51 --> Utf8 Class Initialized
DEBUG - 2011-08-21 15:23:51 --> UTF-8 Support Enabled
DEBUG - 2011-08-21 15:23:51 --> URI Class Initialized
DEBUG - 2011-08-21 15:23:51 --> Router Class Initialized
DEBUG - 2011-08-21 15:23:51 --> Output Class Initialized
DEBUG - 2011-08-21 15:23:51 --> Input Class Initialized
DEBUG - 2011-08-21 15:23:51 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-21 15:23:51 --> Language Class Initialized
DEBUG - 2011-08-21 15:23:51 --> Loader Class Initialized
DEBUG - 2011-08-21 15:23:51 --> Controller Class Initialized
DEBUG - 2011-08-21 15:23:51 --> Model Class Initialized
DEBUG - 2011-08-21 15:23:51 --> Model Class Initialized
DEBUG - 2011-08-21 15:23:51 --> Model Class Initialized
DEBUG - 2011-08-21 15:23:51 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-21 15:23:51 --> Database Driver Class Initialized
DEBUG - 2011-08-21 15:23:51 --> File loaded: application/views/table/main.php
DEBUG - 2011-08-21 15:23:51 --> Helper loaded: url_helper
DEBUG - 2011-08-21 15:23:51 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-21 15:23:51 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-21 15:23:51 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-21 15:23:51 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-21 15:23:51 --> Final output sent to browser
DEBUG - 2011-08-21 15:23:51 --> Total execution time: 0.2852
DEBUG - 2011-08-21 15:23:53 --> Config Class Initialized
DEBUG - 2011-08-21 15:23:53 --> Hooks Class Initialized
DEBUG - 2011-08-21 15:23:53 --> Utf8 Class Initialized
DEBUG - 2011-08-21 15:23:53 --> UTF-8 Support Enabled
DEBUG - 2011-08-21 15:23:53 --> URI Class Initialized
DEBUG - 2011-08-21 15:23:53 --> Router Class Initialized
DEBUG - 2011-08-21 15:23:53 --> Output Class Initialized
DEBUG - 2011-08-21 15:23:53 --> Input Class Initialized
DEBUG - 2011-08-21 15:23:53 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-21 15:23:53 --> Language Class Initialized
DEBUG - 2011-08-21 15:23:53 --> Loader Class Initialized
DEBUG - 2011-08-21 15:23:53 --> Controller Class Initialized
DEBUG - 2011-08-21 15:23:53 --> Model Class Initialized
DEBUG - 2011-08-21 15:23:53 --> Model Class Initialized
DEBUG - 2011-08-21 15:23:53 --> Model Class Initialized
DEBUG - 2011-08-21 15:23:53 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-21 15:23:53 --> Database Driver Class Initialized
DEBUG - 2011-08-21 15:23:53 --> File loaded: application/views/table/main.php
DEBUG - 2011-08-21 15:23:53 --> Helper loaded: url_helper
DEBUG - 2011-08-21 15:23:53 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-21 15:23:53 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-21 15:23:53 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-21 15:23:53 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-21 15:23:53 --> Final output sent to browser
DEBUG - 2011-08-21 15:23:53 --> Total execution time: 0.0455
DEBUG - 2011-08-21 15:24:35 --> Config Class Initialized
DEBUG - 2011-08-21 15:24:35 --> Hooks Class Initialized
DEBUG - 2011-08-21 15:24:35 --> Utf8 Class Initialized
DEBUG - 2011-08-21 15:24:35 --> UTF-8 Support Enabled
DEBUG - 2011-08-21 15:24:35 --> URI Class Initialized
DEBUG - 2011-08-21 15:24:35 --> Router Class Initialized
DEBUG - 2011-08-21 15:24:35 --> Output Class Initialized
DEBUG - 2011-08-21 15:24:35 --> Input Class Initialized
DEBUG - 2011-08-21 15:24:35 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-21 15:24:35 --> Language Class Initialized
DEBUG - 2011-08-21 15:24:35 --> Loader Class Initialized
DEBUG - 2011-08-21 15:24:35 --> Controller Class Initialized
DEBUG - 2011-08-21 15:24:35 --> Model Class Initialized
DEBUG - 2011-08-21 15:24:35 --> Model Class Initialized
DEBUG - 2011-08-21 15:24:35 --> Model Class Initialized
DEBUG - 2011-08-21 15:24:35 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-21 15:24:35 --> Database Driver Class Initialized
DEBUG - 2011-08-21 15:24:35 --> File loaded: application/views/table/main.php
DEBUG - 2011-08-21 15:24:35 --> Helper loaded: url_helper
DEBUG - 2011-08-21 15:24:35 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-21 15:24:35 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-21 15:24:35 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-21 15:24:35 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-21 15:24:35 --> Final output sent to browser
DEBUG - 2011-08-21 15:24:35 --> Total execution time: 0.2758
DEBUG - 2011-08-21 15:24:49 --> Config Class Initialized
DEBUG - 2011-08-21 15:24:49 --> Hooks Class Initialized
DEBUG - 2011-08-21 15:24:49 --> Utf8 Class Initialized
DEBUG - 2011-08-21 15:24:49 --> UTF-8 Support Enabled
DEBUG - 2011-08-21 15:24:49 --> URI Class Initialized
DEBUG - 2011-08-21 15:24:49 --> Router Class Initialized
DEBUG - 2011-08-21 15:24:49 --> Output Class Initialized
DEBUG - 2011-08-21 15:24:49 --> Input Class Initialized
DEBUG - 2011-08-21 15:24:49 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-21 15:24:49 --> Language Class Initialized
DEBUG - 2011-08-21 15:24:49 --> Loader Class Initialized
DEBUG - 2011-08-21 15:24:49 --> Controller Class Initialized
DEBUG - 2011-08-21 15:24:49 --> Model Class Initialized
DEBUG - 2011-08-21 15:24:49 --> Model Class Initialized
DEBUG - 2011-08-21 15:24:49 --> Model Class Initialized
DEBUG - 2011-08-21 15:24:49 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-21 15:24:49 --> Database Driver Class Initialized
DEBUG - 2011-08-21 15:24:49 --> File loaded: application/views/table/main.php
DEBUG - 2011-08-21 15:24:49 --> Helper loaded: url_helper
DEBUG - 2011-08-21 15:24:49 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-21 15:24:49 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-21 15:24:49 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-21 15:24:49 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-21 15:24:49 --> Final output sent to browser
DEBUG - 2011-08-21 15:24:49 --> Total execution time: 0.0472
DEBUG - 2011-08-21 15:28:19 --> Config Class Initialized
DEBUG - 2011-08-21 15:28:19 --> Hooks Class Initialized
DEBUG - 2011-08-21 15:28:19 --> Utf8 Class Initialized
DEBUG - 2011-08-21 15:28:19 --> UTF-8 Support Enabled
DEBUG - 2011-08-21 15:28:19 --> URI Class Initialized
DEBUG - 2011-08-21 15:28:19 --> Router Class Initialized
DEBUG - 2011-08-21 15:28:19 --> Output Class Initialized
DEBUG - 2011-08-21 15:28:19 --> Input Class Initialized
DEBUG - 2011-08-21 15:28:19 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-21 15:28:19 --> Language Class Initialized
DEBUG - 2011-08-21 15:28:19 --> Loader Class Initialized
DEBUG - 2011-08-21 15:28:19 --> Controller Class Initialized
DEBUG - 2011-08-21 15:28:19 --> Model Class Initialized
DEBUG - 2011-08-21 15:28:19 --> Model Class Initialized
DEBUG - 2011-08-21 15:28:19 --> Model Class Initialized
DEBUG - 2011-08-21 15:28:19 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-21 15:28:19 --> Database Driver Class Initialized
DEBUG - 2011-08-21 15:28:20 --> File loaded: application/views/table/main.php
DEBUG - 2011-08-21 15:28:20 --> Helper loaded: url_helper
DEBUG - 2011-08-21 15:28:20 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-21 15:28:20 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-21 15:28:20 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-21 15:28:20 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-21 15:28:20 --> Final output sent to browser
DEBUG - 2011-08-21 15:28:20 --> Total execution time: 0.8638
DEBUG - 2011-08-21 15:28:21 --> Config Class Initialized
DEBUG - 2011-08-21 15:28:21 --> Hooks Class Initialized
DEBUG - 2011-08-21 15:28:22 --> Utf8 Class Initialized
DEBUG - 2011-08-21 15:28:22 --> UTF-8 Support Enabled
DEBUG - 2011-08-21 15:28:22 --> URI Class Initialized
DEBUG - 2011-08-21 15:28:22 --> Router Class Initialized
DEBUG - 2011-08-21 15:28:22 --> Output Class Initialized
DEBUG - 2011-08-21 15:28:22 --> Input Class Initialized
DEBUG - 2011-08-21 15:28:22 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-21 15:28:22 --> Language Class Initialized
DEBUG - 2011-08-21 15:28:22 --> Loader Class Initialized
DEBUG - 2011-08-21 15:28:22 --> Controller Class Initialized
DEBUG - 2011-08-21 15:28:22 --> Model Class Initialized
DEBUG - 2011-08-21 15:28:22 --> Model Class Initialized
DEBUG - 2011-08-21 15:28:22 --> Model Class Initialized
DEBUG - 2011-08-21 15:28:22 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-21 15:28:22 --> Database Driver Class Initialized
DEBUG - 2011-08-21 15:28:22 --> File loaded: application/views/table/main.php
DEBUG - 2011-08-21 15:28:22 --> Helper loaded: url_helper
DEBUG - 2011-08-21 15:28:22 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-21 15:28:22 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-21 15:28:22 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-21 15:28:22 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-21 15:28:22 --> Final output sent to browser
DEBUG - 2011-08-21 15:28:22 --> Total execution time: 0.0579
DEBUG - 2011-08-21 15:29:13 --> Config Class Initialized
DEBUG - 2011-08-21 15:29:13 --> Hooks Class Initialized
DEBUG - 2011-08-21 15:29:13 --> Utf8 Class Initialized
DEBUG - 2011-08-21 15:29:13 --> UTF-8 Support Enabled
DEBUG - 2011-08-21 15:29:13 --> URI Class Initialized
DEBUG - 2011-08-21 15:29:13 --> Router Class Initialized
DEBUG - 2011-08-21 15:29:13 --> Output Class Initialized
DEBUG - 2011-08-21 15:29:13 --> Input Class Initialized
DEBUG - 2011-08-21 15:29:13 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-21 15:29:13 --> Language Class Initialized
DEBUG - 2011-08-21 15:29:13 --> Loader Class Initialized
DEBUG - 2011-08-21 15:29:13 --> Controller Class Initialized
DEBUG - 2011-08-21 15:29:13 --> Model Class Initialized
DEBUG - 2011-08-21 15:29:13 --> Model Class Initialized
DEBUG - 2011-08-21 15:29:13 --> Model Class Initialized
DEBUG - 2011-08-21 15:29:13 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-21 15:29:13 --> Database Driver Class Initialized
DEBUG - 2011-08-21 15:29:14 --> File loaded: application/views/table/main.php
DEBUG - 2011-08-21 15:29:14 --> Helper loaded: url_helper
DEBUG - 2011-08-21 15:29:14 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-21 15:29:14 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-21 15:29:14 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-21 15:29:14 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-21 15:29:14 --> Final output sent to browser
DEBUG - 2011-08-21 15:29:14 --> Total execution time: 0.2264
DEBUG - 2011-08-21 15:29:36 --> Config Class Initialized
DEBUG - 2011-08-21 15:29:36 --> Hooks Class Initialized
DEBUG - 2011-08-21 15:29:36 --> Utf8 Class Initialized
DEBUG - 2011-08-21 15:29:36 --> UTF-8 Support Enabled
DEBUG - 2011-08-21 15:29:36 --> URI Class Initialized
DEBUG - 2011-08-21 15:29:36 --> Router Class Initialized
DEBUG - 2011-08-21 15:29:36 --> Output Class Initialized
DEBUG - 2011-08-21 15:29:36 --> Input Class Initialized
DEBUG - 2011-08-21 15:29:36 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-21 15:29:36 --> Language Class Initialized
DEBUG - 2011-08-21 15:29:36 --> Loader Class Initialized
DEBUG - 2011-08-21 15:29:36 --> Controller Class Initialized
ERROR - 2011-08-21 15:29:36 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-08-21 15:29:36 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-08-21 15:29:36 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-08-21 15:29:36 --> Model Class Initialized
DEBUG - 2011-08-21 15:29:36 --> Model Class Initialized
DEBUG - 2011-08-21 15:29:36 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-21 15:29:36 --> Database Driver Class Initialized
DEBUG - 2011-08-21 15:29:36 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-08-21 15:29:36 --> Helper loaded: url_helper
DEBUG - 2011-08-21 15:29:36 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-21 15:29:36 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-21 15:29:36 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-21 15:29:36 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-21 15:29:36 --> Final output sent to browser
DEBUG - 2011-08-21 15:29:36 --> Total execution time: 0.0308
DEBUG - 2011-08-21 15:29:36 --> Config Class Initialized
DEBUG - 2011-08-21 15:29:36 --> Hooks Class Initialized
DEBUG - 2011-08-21 15:29:36 --> Utf8 Class Initialized
DEBUG - 2011-08-21 15:29:36 --> UTF-8 Support Enabled
DEBUG - 2011-08-21 15:29:36 --> URI Class Initialized
DEBUG - 2011-08-21 15:29:36 --> Router Class Initialized
DEBUG - 2011-08-21 15:29:36 --> Output Class Initialized
DEBUG - 2011-08-21 15:29:36 --> Input Class Initialized
DEBUG - 2011-08-21 15:29:36 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-21 15:29:36 --> Language Class Initialized
DEBUG - 2011-08-21 15:29:36 --> Loader Class Initialized
DEBUG - 2011-08-21 15:29:36 --> Controller Class Initialized
DEBUG - 2011-08-21 15:29:36 --> Model Class Initialized
DEBUG - 2011-08-21 15:29:36 --> Model Class Initialized
DEBUG - 2011-08-21 15:29:36 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-21 15:29:36 --> Database Driver Class Initialized
DEBUG - 2011-08-21 15:29:37 --> Final output sent to browser
DEBUG - 2011-08-21 15:29:37 --> Total execution time: 0.5633
DEBUG - 2011-08-21 15:29:49 --> Config Class Initialized
DEBUG - 2011-08-21 15:29:49 --> Hooks Class Initialized
DEBUG - 2011-08-21 15:29:49 --> Utf8 Class Initialized
DEBUG - 2011-08-21 15:29:49 --> UTF-8 Support Enabled
DEBUG - 2011-08-21 15:29:49 --> URI Class Initialized
DEBUG - 2011-08-21 15:29:49 --> Router Class Initialized
DEBUG - 2011-08-21 15:29:49 --> Output Class Initialized
DEBUG - 2011-08-21 15:29:49 --> Input Class Initialized
DEBUG - 2011-08-21 15:29:49 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-21 15:29:49 --> Language Class Initialized
DEBUG - 2011-08-21 15:29:49 --> Loader Class Initialized
DEBUG - 2011-08-21 15:29:49 --> Controller Class Initialized
DEBUG - 2011-08-21 15:29:49 --> Model Class Initialized
DEBUG - 2011-08-21 15:29:49 --> Model Class Initialized
DEBUG - 2011-08-21 15:29:49 --> Model Class Initialized
DEBUG - 2011-08-21 15:29:49 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-21 15:29:49 --> Database Driver Class Initialized
DEBUG - 2011-08-21 15:29:49 --> File loaded: application/views/table/main.php
DEBUG - 2011-08-21 15:29:49 --> Helper loaded: url_helper
DEBUG - 2011-08-21 15:29:49 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-21 15:29:49 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-21 15:29:49 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-21 15:29:49 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-21 15:29:49 --> Final output sent to browser
DEBUG - 2011-08-21 15:29:49 --> Total execution time: 0.0497
DEBUG - 2011-08-21 15:30:37 --> Config Class Initialized
DEBUG - 2011-08-21 15:30:37 --> Hooks Class Initialized
DEBUG - 2011-08-21 15:30:37 --> Utf8 Class Initialized
DEBUG - 2011-08-21 15:30:37 --> UTF-8 Support Enabled
DEBUG - 2011-08-21 15:30:37 --> URI Class Initialized
DEBUG - 2011-08-21 15:30:37 --> Router Class Initialized
DEBUG - 2011-08-21 15:30:37 --> Output Class Initialized
DEBUG - 2011-08-21 15:30:37 --> Input Class Initialized
DEBUG - 2011-08-21 15:30:37 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-21 15:30:37 --> Language Class Initialized
DEBUG - 2011-08-21 15:30:37 --> Loader Class Initialized
DEBUG - 2011-08-21 15:30:37 --> Controller Class Initialized
ERROR - 2011-08-21 15:30:37 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-08-21 15:30:37 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-08-21 15:30:37 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-08-21 15:30:37 --> Model Class Initialized
DEBUG - 2011-08-21 15:30:37 --> Model Class Initialized
DEBUG - 2011-08-21 15:30:37 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-21 15:30:37 --> Database Driver Class Initialized
DEBUG - 2011-08-21 15:30:37 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-08-21 15:30:37 --> Helper loaded: url_helper
DEBUG - 2011-08-21 15:30:37 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-21 15:30:37 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-21 15:30:37 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-21 15:30:37 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-21 15:30:37 --> Final output sent to browser
DEBUG - 2011-08-21 15:30:37 --> Total execution time: 0.0288
DEBUG - 2011-08-21 15:30:38 --> Config Class Initialized
DEBUG - 2011-08-21 15:30:38 --> Hooks Class Initialized
DEBUG - 2011-08-21 15:30:38 --> Utf8 Class Initialized
DEBUG - 2011-08-21 15:30:38 --> UTF-8 Support Enabled
DEBUG - 2011-08-21 15:30:38 --> URI Class Initialized
DEBUG - 2011-08-21 15:30:38 --> Router Class Initialized
DEBUG - 2011-08-21 15:30:38 --> Output Class Initialized
DEBUG - 2011-08-21 15:30:38 --> Input Class Initialized
DEBUG - 2011-08-21 15:30:38 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-21 15:30:38 --> Language Class Initialized
DEBUG - 2011-08-21 15:30:38 --> Loader Class Initialized
DEBUG - 2011-08-21 15:30:38 --> Controller Class Initialized
DEBUG - 2011-08-21 15:30:38 --> Model Class Initialized
DEBUG - 2011-08-21 15:30:38 --> Model Class Initialized
DEBUG - 2011-08-21 15:30:38 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-21 15:30:38 --> Database Driver Class Initialized
DEBUG - 2011-08-21 15:30:38 --> Final output sent to browser
DEBUG - 2011-08-21 15:30:38 --> Total execution time: 0.5558
DEBUG - 2011-08-21 15:30:39 --> Config Class Initialized
DEBUG - 2011-08-21 15:30:39 --> Hooks Class Initialized
DEBUG - 2011-08-21 15:30:39 --> Utf8 Class Initialized
DEBUG - 2011-08-21 15:30:39 --> UTF-8 Support Enabled
DEBUG - 2011-08-21 15:30:39 --> URI Class Initialized
DEBUG - 2011-08-21 15:30:39 --> Router Class Initialized
DEBUG - 2011-08-21 15:30:39 --> Output Class Initialized
DEBUG - 2011-08-21 15:30:39 --> Input Class Initialized
DEBUG - 2011-08-21 15:30:39 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-21 15:30:39 --> Language Class Initialized
DEBUG - 2011-08-21 15:30:39 --> Loader Class Initialized
DEBUG - 2011-08-21 15:30:39 --> Controller Class Initialized
ERROR - 2011-08-21 15:30:39 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-08-21 15:30:39 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-08-21 15:30:39 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-08-21 15:30:39 --> Model Class Initialized
DEBUG - 2011-08-21 15:30:39 --> Model Class Initialized
DEBUG - 2011-08-21 15:30:39 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-21 15:30:39 --> Database Driver Class Initialized
DEBUG - 2011-08-21 15:30:39 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-08-21 15:30:39 --> Helper loaded: url_helper
DEBUG - 2011-08-21 15:30:39 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-21 15:30:39 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-21 15:30:39 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-21 15:30:39 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-21 15:30:39 --> Final output sent to browser
DEBUG - 2011-08-21 15:30:39 --> Total execution time: 0.0327
DEBUG - 2011-08-21 15:31:23 --> Config Class Initialized
DEBUG - 2011-08-21 15:31:23 --> Hooks Class Initialized
DEBUG - 2011-08-21 15:31:23 --> Utf8 Class Initialized
DEBUG - 2011-08-21 15:31:23 --> UTF-8 Support Enabled
DEBUG - 2011-08-21 15:31:23 --> URI Class Initialized
DEBUG - 2011-08-21 15:31:23 --> Router Class Initialized
DEBUG - 2011-08-21 15:31:23 --> Output Class Initialized
DEBUG - 2011-08-21 15:31:23 --> Input Class Initialized
DEBUG - 2011-08-21 15:31:23 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-21 15:31:23 --> Language Class Initialized
DEBUG - 2011-08-21 15:31:23 --> Loader Class Initialized
DEBUG - 2011-08-21 15:31:23 --> Controller Class Initialized
ERROR - 2011-08-21 15:31:23 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-08-21 15:31:23 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-08-21 15:31:23 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-08-21 15:31:23 --> Model Class Initialized
DEBUG - 2011-08-21 15:31:23 --> Model Class Initialized
DEBUG - 2011-08-21 15:31:23 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-21 15:31:23 --> Database Driver Class Initialized
DEBUG - 2011-08-21 15:31:23 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-08-21 15:31:23 --> Helper loaded: url_helper
DEBUG - 2011-08-21 15:31:23 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-21 15:31:23 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-21 15:31:23 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-21 15:31:23 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-21 15:31:23 --> Final output sent to browser
DEBUG - 2011-08-21 15:31:23 --> Total execution time: 0.0415
DEBUG - 2011-08-21 15:31:24 --> Config Class Initialized
DEBUG - 2011-08-21 15:31:24 --> Hooks Class Initialized
DEBUG - 2011-08-21 15:31:24 --> Utf8 Class Initialized
DEBUG - 2011-08-21 15:31:24 --> UTF-8 Support Enabled
DEBUG - 2011-08-21 15:31:24 --> URI Class Initialized
DEBUG - 2011-08-21 15:31:24 --> Router Class Initialized
DEBUG - 2011-08-21 15:31:24 --> Output Class Initialized
DEBUG - 2011-08-21 15:31:24 --> Input Class Initialized
DEBUG - 2011-08-21 15:31:24 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-21 15:31:24 --> Language Class Initialized
DEBUG - 2011-08-21 15:31:24 --> Loader Class Initialized
DEBUG - 2011-08-21 15:31:24 --> Controller Class Initialized
DEBUG - 2011-08-21 15:31:24 --> Model Class Initialized
DEBUG - 2011-08-21 15:31:24 --> Model Class Initialized
DEBUG - 2011-08-21 15:31:24 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-21 15:31:24 --> Database Driver Class Initialized
DEBUG - 2011-08-21 15:31:24 --> Final output sent to browser
DEBUG - 2011-08-21 15:31:24 --> Total execution time: 0.5268
DEBUG - 2011-08-21 16:00:53 --> Config Class Initialized
DEBUG - 2011-08-21 16:00:53 --> Hooks Class Initialized
DEBUG - 2011-08-21 16:00:53 --> Utf8 Class Initialized
DEBUG - 2011-08-21 16:00:53 --> UTF-8 Support Enabled
DEBUG - 2011-08-21 16:00:53 --> URI Class Initialized
DEBUG - 2011-08-21 16:00:53 --> Router Class Initialized
DEBUG - 2011-08-21 16:00:53 --> Output Class Initialized
DEBUG - 2011-08-21 16:00:53 --> Input Class Initialized
DEBUG - 2011-08-21 16:00:53 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-21 16:00:53 --> Language Class Initialized
DEBUG - 2011-08-21 16:00:53 --> Loader Class Initialized
DEBUG - 2011-08-21 16:00:53 --> Controller Class Initialized
ERROR - 2011-08-21 16:00:53 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-08-21 16:00:53 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-08-21 16:00:53 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-08-21 16:00:53 --> Model Class Initialized
DEBUG - 2011-08-21 16:00:53 --> Model Class Initialized
DEBUG - 2011-08-21 16:00:53 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-21 16:00:53 --> Database Driver Class Initialized
DEBUG - 2011-08-21 16:00:53 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-08-21 16:00:53 --> Helper loaded: url_helper
DEBUG - 2011-08-21 16:00:53 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-21 16:00:53 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-21 16:00:53 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-21 16:00:53 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-21 16:00:53 --> Final output sent to browser
DEBUG - 2011-08-21 16:00:53 --> Total execution time: 0.0346
DEBUG - 2011-08-21 16:00:53 --> Config Class Initialized
DEBUG - 2011-08-21 16:00:53 --> Hooks Class Initialized
DEBUG - 2011-08-21 16:00:53 --> Utf8 Class Initialized
DEBUG - 2011-08-21 16:00:53 --> UTF-8 Support Enabled
DEBUG - 2011-08-21 16:00:53 --> URI Class Initialized
DEBUG - 2011-08-21 16:00:53 --> Router Class Initialized
DEBUG - 2011-08-21 16:00:53 --> Output Class Initialized
DEBUG - 2011-08-21 16:00:53 --> Input Class Initialized
DEBUG - 2011-08-21 16:00:53 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-21 16:00:53 --> Language Class Initialized
DEBUG - 2011-08-21 16:00:53 --> Loader Class Initialized
DEBUG - 2011-08-21 16:00:53 --> Controller Class Initialized
DEBUG - 2011-08-21 16:00:53 --> Model Class Initialized
DEBUG - 2011-08-21 16:00:53 --> Model Class Initialized
DEBUG - 2011-08-21 16:00:53 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-21 16:00:53 --> Database Driver Class Initialized
DEBUG - 2011-08-21 16:00:54 --> Final output sent to browser
DEBUG - 2011-08-21 16:00:54 --> Total execution time: 0.5356
DEBUG - 2011-08-21 16:00:55 --> Config Class Initialized
DEBUG - 2011-08-21 16:00:55 --> Hooks Class Initialized
DEBUG - 2011-08-21 16:00:55 --> Utf8 Class Initialized
DEBUG - 2011-08-21 16:00:55 --> UTF-8 Support Enabled
DEBUG - 2011-08-21 16:00:55 --> URI Class Initialized
DEBUG - 2011-08-21 16:00:55 --> Router Class Initialized
ERROR - 2011-08-21 16:00:55 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-08-21 16:00:56 --> Config Class Initialized
DEBUG - 2011-08-21 16:00:56 --> Hooks Class Initialized
DEBUG - 2011-08-21 16:00:56 --> Utf8 Class Initialized
DEBUG - 2011-08-21 16:00:56 --> UTF-8 Support Enabled
DEBUG - 2011-08-21 16:00:56 --> URI Class Initialized
DEBUG - 2011-08-21 16:00:56 --> Router Class Initialized
ERROR - 2011-08-21 16:00:56 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-08-21 16:00:56 --> Config Class Initialized
DEBUG - 2011-08-21 16:00:56 --> Hooks Class Initialized
DEBUG - 2011-08-21 16:00:56 --> Utf8 Class Initialized
DEBUG - 2011-08-21 16:00:56 --> UTF-8 Support Enabled
DEBUG - 2011-08-21 16:00:56 --> URI Class Initialized
DEBUG - 2011-08-21 16:00:56 --> Router Class Initialized
ERROR - 2011-08-21 16:00:56 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-08-21 17:19:12 --> Config Class Initialized
DEBUG - 2011-08-21 17:19:12 --> Hooks Class Initialized
DEBUG - 2011-08-21 17:19:12 --> Utf8 Class Initialized
DEBUG - 2011-08-21 17:19:12 --> UTF-8 Support Enabled
DEBUG - 2011-08-21 17:19:12 --> URI Class Initialized
DEBUG - 2011-08-21 17:19:12 --> Router Class Initialized
ERROR - 2011-08-21 17:19:12 --> 404 Page Not Found --> robots.txt
DEBUG - 2011-08-21 17:19:12 --> Config Class Initialized
DEBUG - 2011-08-21 17:19:12 --> Hooks Class Initialized
DEBUG - 2011-08-21 17:19:12 --> Utf8 Class Initialized
DEBUG - 2011-08-21 17:19:12 --> UTF-8 Support Enabled
DEBUG - 2011-08-21 17:19:12 --> URI Class Initialized
DEBUG - 2011-08-21 17:19:12 --> Router Class Initialized
DEBUG - 2011-08-21 17:19:12 --> Output Class Initialized
DEBUG - 2011-08-21 17:19:12 --> Input Class Initialized
DEBUG - 2011-08-21 17:19:12 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-21 17:19:12 --> Language Class Initialized
DEBUG - 2011-08-21 17:19:12 --> Loader Class Initialized
DEBUG - 2011-08-21 17:19:12 --> Controller Class Initialized
DEBUG - 2011-08-21 17:19:12 --> Model Class Initialized
DEBUG - 2011-08-21 17:19:12 --> Model Class Initialized
DEBUG - 2011-08-21 17:19:12 --> Model Class Initialized
DEBUG - 2011-08-21 17:19:12 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-21 17:19:12 --> Database Driver Class Initialized
DEBUG - 2011-08-21 17:19:12 --> File loaded: application/views/table/main.php
DEBUG - 2011-08-21 17:19:12 --> Helper loaded: url_helper
DEBUG - 2011-08-21 17:19:12 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-21 17:19:12 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-21 17:19:12 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-21 17:19:12 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-21 17:19:12 --> Final output sent to browser
DEBUG - 2011-08-21 17:19:12 --> Total execution time: 0.3389
DEBUG - 2011-08-21 17:20:04 --> Config Class Initialized
DEBUG - 2011-08-21 17:20:04 --> Hooks Class Initialized
DEBUG - 2011-08-21 17:20:04 --> Utf8 Class Initialized
DEBUG - 2011-08-21 17:20:04 --> UTF-8 Support Enabled
DEBUG - 2011-08-21 17:20:04 --> URI Class Initialized
DEBUG - 2011-08-21 17:20:04 --> Router Class Initialized
ERROR - 2011-08-21 17:20:04 --> 404 Page Not Found --> robots.txt
DEBUG - 2011-08-21 18:12:33 --> Config Class Initialized
DEBUG - 2011-08-21 18:12:33 --> Hooks Class Initialized
DEBUG - 2011-08-21 18:12:33 --> Utf8 Class Initialized
DEBUG - 2011-08-21 18:12:33 --> UTF-8 Support Enabled
DEBUG - 2011-08-21 18:12:33 --> URI Class Initialized
DEBUG - 2011-08-21 18:12:33 --> Router Class Initialized
DEBUG - 2011-08-21 18:12:33 --> Output Class Initialized
DEBUG - 2011-08-21 18:12:33 --> Input Class Initialized
DEBUG - 2011-08-21 18:12:33 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-21 18:12:33 --> Language Class Initialized
DEBUG - 2011-08-21 18:12:33 --> Loader Class Initialized
DEBUG - 2011-08-21 18:12:33 --> Controller Class Initialized
DEBUG - 2011-08-21 18:12:33 --> Model Class Initialized
DEBUG - 2011-08-21 18:12:33 --> Model Class Initialized
DEBUG - 2011-08-21 18:12:33 --> Model Class Initialized
DEBUG - 2011-08-21 18:12:33 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-21 18:12:33 --> Database Driver Class Initialized
DEBUG - 2011-08-21 18:12:33 --> File loaded: application/views/table/main.php
DEBUG - 2011-08-21 18:12:33 --> Helper loaded: url_helper
DEBUG - 2011-08-21 18:12:33 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-21 18:12:33 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-21 18:12:33 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-21 18:12:33 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-21 18:12:33 --> Final output sent to browser
DEBUG - 2011-08-21 18:12:33 --> Total execution time: 0.3047
DEBUG - 2011-08-21 18:12:39 --> Config Class Initialized
DEBUG - 2011-08-21 18:12:39 --> Hooks Class Initialized
DEBUG - 2011-08-21 18:12:39 --> Utf8 Class Initialized
DEBUG - 2011-08-21 18:12:39 --> UTF-8 Support Enabled
DEBUG - 2011-08-21 18:12:39 --> URI Class Initialized
DEBUG - 2011-08-21 18:12:39 --> Router Class Initialized
ERROR - 2011-08-21 18:12:39 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-08-21 18:13:09 --> Config Class Initialized
DEBUG - 2011-08-21 18:13:09 --> Hooks Class Initialized
DEBUG - 2011-08-21 18:13:09 --> Utf8 Class Initialized
DEBUG - 2011-08-21 18:13:09 --> UTF-8 Support Enabled
DEBUG - 2011-08-21 18:13:09 --> URI Class Initialized
DEBUG - 2011-08-21 18:13:09 --> Router Class Initialized
DEBUG - 2011-08-21 18:13:09 --> Output Class Initialized
DEBUG - 2011-08-21 18:13:09 --> Input Class Initialized
DEBUG - 2011-08-21 18:13:09 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-21 18:13:09 --> Language Class Initialized
DEBUG - 2011-08-21 18:13:09 --> Loader Class Initialized
DEBUG - 2011-08-21 18:13:09 --> Controller Class Initialized
DEBUG - 2011-08-21 18:13:09 --> Model Class Initialized
DEBUG - 2011-08-21 18:13:09 --> Model Class Initialized
DEBUG - 2011-08-21 18:13:09 --> Model Class Initialized
DEBUG - 2011-08-21 18:13:09 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-21 18:13:09 --> Database Driver Class Initialized
DEBUG - 2011-08-21 18:13:10 --> File loaded: application/views/table/main.php
DEBUG - 2011-08-21 18:13:10 --> Helper loaded: url_helper
DEBUG - 2011-08-21 18:13:10 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-21 18:13:10 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-21 18:13:10 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-21 18:13:10 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-21 18:13:10 --> Final output sent to browser
DEBUG - 2011-08-21 18:13:10 --> Total execution time: 0.8209
DEBUG - 2011-08-21 18:13:12 --> Config Class Initialized
DEBUG - 2011-08-21 18:13:12 --> Hooks Class Initialized
DEBUG - 2011-08-21 18:13:12 --> Utf8 Class Initialized
DEBUG - 2011-08-21 18:13:12 --> UTF-8 Support Enabled
DEBUG - 2011-08-21 18:13:12 --> URI Class Initialized
DEBUG - 2011-08-21 18:13:12 --> Router Class Initialized
ERROR - 2011-08-21 18:13:12 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-08-21 18:13:15 --> Config Class Initialized
DEBUG - 2011-08-21 18:13:15 --> Hooks Class Initialized
DEBUG - 2011-08-21 18:13:15 --> Utf8 Class Initialized
DEBUG - 2011-08-21 18:13:15 --> UTF-8 Support Enabled
DEBUG - 2011-08-21 18:13:15 --> URI Class Initialized
DEBUG - 2011-08-21 18:13:15 --> Router Class Initialized
ERROR - 2011-08-21 18:13:15 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-08-21 18:13:27 --> Config Class Initialized
DEBUG - 2011-08-21 18:13:27 --> Hooks Class Initialized
DEBUG - 2011-08-21 18:13:27 --> Utf8 Class Initialized
DEBUG - 2011-08-21 18:13:27 --> UTF-8 Support Enabled
DEBUG - 2011-08-21 18:13:27 --> URI Class Initialized
DEBUG - 2011-08-21 18:13:27 --> Router Class Initialized
DEBUG - 2011-08-21 18:13:27 --> Output Class Initialized
DEBUG - 2011-08-21 18:13:27 --> Input Class Initialized
DEBUG - 2011-08-21 18:13:27 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-21 18:13:27 --> Language Class Initialized
DEBUG - 2011-08-21 18:13:27 --> Loader Class Initialized
DEBUG - 2011-08-21 18:13:27 --> Controller Class Initialized
DEBUG - 2011-08-21 18:13:27 --> Model Class Initialized
DEBUG - 2011-08-21 18:13:27 --> Model Class Initialized
DEBUG - 2011-08-21 18:13:27 --> Model Class Initialized
DEBUG - 2011-08-21 18:13:27 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-21 18:13:27 --> Database Driver Class Initialized
DEBUG - 2011-08-21 18:13:27 --> File loaded: application/views/table/main.php
DEBUG - 2011-08-21 18:13:27 --> Helper loaded: url_helper
DEBUG - 2011-08-21 18:13:27 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-21 18:13:27 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-21 18:13:27 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-21 18:13:27 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-21 18:13:27 --> Final output sent to browser
DEBUG - 2011-08-21 18:13:27 --> Total execution time: 0.2783
DEBUG - 2011-08-21 18:13:29 --> Config Class Initialized
DEBUG - 2011-08-21 18:13:29 --> Hooks Class Initialized
DEBUG - 2011-08-21 18:13:29 --> Utf8 Class Initialized
DEBUG - 2011-08-21 18:13:29 --> UTF-8 Support Enabled
DEBUG - 2011-08-21 18:13:29 --> URI Class Initialized
DEBUG - 2011-08-21 18:13:29 --> Router Class Initialized
ERROR - 2011-08-21 18:13:29 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-08-21 18:14:03 --> Config Class Initialized
DEBUG - 2011-08-21 18:14:03 --> Hooks Class Initialized
DEBUG - 2011-08-21 18:14:03 --> Utf8 Class Initialized
DEBUG - 2011-08-21 18:14:03 --> UTF-8 Support Enabled
DEBUG - 2011-08-21 18:14:03 --> URI Class Initialized
DEBUG - 2011-08-21 18:14:03 --> Router Class Initialized
DEBUG - 2011-08-21 18:14:03 --> Output Class Initialized
DEBUG - 2011-08-21 18:14:03 --> Input Class Initialized
DEBUG - 2011-08-21 18:14:03 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-21 18:14:03 --> Language Class Initialized
DEBUG - 2011-08-21 18:14:03 --> Loader Class Initialized
DEBUG - 2011-08-21 18:14:03 --> Controller Class Initialized
DEBUG - 2011-08-21 18:14:03 --> Model Class Initialized
DEBUG - 2011-08-21 18:14:03 --> Model Class Initialized
DEBUG - 2011-08-21 18:14:03 --> Model Class Initialized
DEBUG - 2011-08-21 18:14:03 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-21 18:14:03 --> Database Driver Class Initialized
DEBUG - 2011-08-21 18:14:04 --> File loaded: application/views/table/main.php
DEBUG - 2011-08-21 18:14:04 --> Helper loaded: url_helper
DEBUG - 2011-08-21 18:14:04 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-21 18:14:04 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-21 18:14:04 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-21 18:14:04 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-21 18:14:04 --> Final output sent to browser
DEBUG - 2011-08-21 18:14:04 --> Total execution time: 0.5246
DEBUG - 2011-08-21 18:14:06 --> Config Class Initialized
DEBUG - 2011-08-21 18:14:06 --> Hooks Class Initialized
DEBUG - 2011-08-21 18:14:06 --> Utf8 Class Initialized
DEBUG - 2011-08-21 18:14:06 --> UTF-8 Support Enabled
DEBUG - 2011-08-21 18:14:06 --> URI Class Initialized
DEBUG - 2011-08-21 18:14:06 --> Router Class Initialized
ERROR - 2011-08-21 18:14:06 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-08-21 18:14:11 --> Config Class Initialized
DEBUG - 2011-08-21 18:14:11 --> Hooks Class Initialized
DEBUG - 2011-08-21 18:14:11 --> Utf8 Class Initialized
DEBUG - 2011-08-21 18:14:11 --> UTF-8 Support Enabled
DEBUG - 2011-08-21 18:14:11 --> URI Class Initialized
DEBUG - 2011-08-21 18:14:11 --> Router Class Initialized
DEBUG - 2011-08-21 18:14:11 --> Output Class Initialized
DEBUG - 2011-08-21 18:14:11 --> Input Class Initialized
DEBUG - 2011-08-21 18:14:11 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-21 18:14:11 --> Language Class Initialized
DEBUG - 2011-08-21 18:14:11 --> Loader Class Initialized
DEBUG - 2011-08-21 18:14:11 --> Controller Class Initialized
DEBUG - 2011-08-21 18:14:11 --> Model Class Initialized
DEBUG - 2011-08-21 18:14:11 --> Model Class Initialized
DEBUG - 2011-08-21 18:14:11 --> Model Class Initialized
DEBUG - 2011-08-21 18:14:11 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-21 18:14:11 --> Database Driver Class Initialized
DEBUG - 2011-08-21 18:14:11 --> File loaded: application/views/table/main.php
DEBUG - 2011-08-21 18:14:11 --> Helper loaded: url_helper
DEBUG - 2011-08-21 18:14:11 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-21 18:14:11 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-21 18:14:11 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-21 18:14:11 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-21 18:14:11 --> Final output sent to browser
DEBUG - 2011-08-21 18:14:11 --> Total execution time: 0.1927
DEBUG - 2011-08-21 18:14:14 --> Config Class Initialized
DEBUG - 2011-08-21 18:14:14 --> Hooks Class Initialized
DEBUG - 2011-08-21 18:14:14 --> Utf8 Class Initialized
DEBUG - 2011-08-21 18:14:14 --> UTF-8 Support Enabled
DEBUG - 2011-08-21 18:14:14 --> URI Class Initialized
DEBUG - 2011-08-21 18:14:14 --> Router Class Initialized
ERROR - 2011-08-21 18:14:14 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-08-21 18:14:23 --> Config Class Initialized
DEBUG - 2011-08-21 18:14:23 --> Hooks Class Initialized
DEBUG - 2011-08-21 18:14:23 --> Utf8 Class Initialized
DEBUG - 2011-08-21 18:14:23 --> UTF-8 Support Enabled
DEBUG - 2011-08-21 18:14:23 --> URI Class Initialized
DEBUG - 2011-08-21 18:14:23 --> Router Class Initialized
DEBUG - 2011-08-21 18:14:23 --> Output Class Initialized
DEBUG - 2011-08-21 18:14:23 --> Input Class Initialized
DEBUG - 2011-08-21 18:14:23 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-21 18:14:23 --> Language Class Initialized
DEBUG - 2011-08-21 18:14:23 --> Loader Class Initialized
DEBUG - 2011-08-21 18:14:23 --> Controller Class Initialized
DEBUG - 2011-08-21 18:14:23 --> Model Class Initialized
DEBUG - 2011-08-21 18:14:23 --> Model Class Initialized
DEBUG - 2011-08-21 18:14:23 --> Model Class Initialized
DEBUG - 2011-08-21 18:14:23 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-21 18:14:23 --> Database Driver Class Initialized
DEBUG - 2011-08-21 18:14:23 --> File loaded: application/views/table/main.php
DEBUG - 2011-08-21 18:14:23 --> Helper loaded: url_helper
DEBUG - 2011-08-21 18:14:23 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-21 18:14:23 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-21 18:14:23 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-21 18:14:23 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-21 18:14:23 --> Final output sent to browser
DEBUG - 2011-08-21 18:14:23 --> Total execution time: 0.2516
DEBUG - 2011-08-21 18:14:27 --> Config Class Initialized
DEBUG - 2011-08-21 18:14:27 --> Hooks Class Initialized
DEBUG - 2011-08-21 18:14:27 --> Utf8 Class Initialized
DEBUG - 2011-08-21 18:14:27 --> UTF-8 Support Enabled
DEBUG - 2011-08-21 18:14:27 --> URI Class Initialized
DEBUG - 2011-08-21 18:14:27 --> Router Class Initialized
ERROR - 2011-08-21 18:14:27 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-08-21 18:14:32 --> Config Class Initialized
DEBUG - 2011-08-21 18:14:32 --> Hooks Class Initialized
DEBUG - 2011-08-21 18:14:32 --> Utf8 Class Initialized
DEBUG - 2011-08-21 18:14:32 --> UTF-8 Support Enabled
DEBUG - 2011-08-21 18:14:32 --> URI Class Initialized
DEBUG - 2011-08-21 18:14:32 --> Router Class Initialized
DEBUG - 2011-08-21 18:14:32 --> Output Class Initialized
DEBUG - 2011-08-21 18:14:32 --> Input Class Initialized
DEBUG - 2011-08-21 18:14:32 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-21 18:14:32 --> Language Class Initialized
DEBUG - 2011-08-21 18:14:32 --> Loader Class Initialized
DEBUG - 2011-08-21 18:14:32 --> Controller Class Initialized
DEBUG - 2011-08-21 18:14:32 --> Model Class Initialized
DEBUG - 2011-08-21 18:14:32 --> Model Class Initialized
DEBUG - 2011-08-21 18:14:32 --> Model Class Initialized
DEBUG - 2011-08-21 18:14:32 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-21 18:14:32 --> Database Driver Class Initialized
DEBUG - 2011-08-21 18:14:32 --> File loaded: application/views/table/main.php
DEBUG - 2011-08-21 18:14:32 --> Helper loaded: url_helper
DEBUG - 2011-08-21 18:14:32 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-21 18:14:32 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-21 18:14:32 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-21 18:14:32 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-21 18:14:32 --> Final output sent to browser
DEBUG - 2011-08-21 18:14:32 --> Total execution time: 0.2092
DEBUG - 2011-08-21 18:14:33 --> Config Class Initialized
DEBUG - 2011-08-21 18:14:33 --> Hooks Class Initialized
DEBUG - 2011-08-21 18:14:33 --> Utf8 Class Initialized
DEBUG - 2011-08-21 18:14:33 --> UTF-8 Support Enabled
DEBUG - 2011-08-21 18:14:33 --> URI Class Initialized
DEBUG - 2011-08-21 18:14:33 --> Router Class Initialized
ERROR - 2011-08-21 18:14:33 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-08-21 18:14:34 --> Config Class Initialized
DEBUG - 2011-08-21 18:14:34 --> Hooks Class Initialized
DEBUG - 2011-08-21 18:14:34 --> Utf8 Class Initialized
DEBUG - 2011-08-21 18:14:34 --> UTF-8 Support Enabled
DEBUG - 2011-08-21 18:14:34 --> URI Class Initialized
DEBUG - 2011-08-21 18:14:34 --> Router Class Initialized
ERROR - 2011-08-21 18:14:34 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-08-21 18:14:38 --> Config Class Initialized
DEBUG - 2011-08-21 18:14:38 --> Hooks Class Initialized
DEBUG - 2011-08-21 18:14:38 --> Utf8 Class Initialized
DEBUG - 2011-08-21 18:14:38 --> UTF-8 Support Enabled
DEBUG - 2011-08-21 18:14:38 --> URI Class Initialized
DEBUG - 2011-08-21 18:14:38 --> Router Class Initialized
DEBUG - 2011-08-21 18:14:38 --> Output Class Initialized
DEBUG - 2011-08-21 18:14:38 --> Input Class Initialized
DEBUG - 2011-08-21 18:14:38 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-21 18:14:38 --> Language Class Initialized
DEBUG - 2011-08-21 18:14:38 --> Loader Class Initialized
DEBUG - 2011-08-21 18:14:38 --> Controller Class Initialized
DEBUG - 2011-08-21 18:14:38 --> Model Class Initialized
DEBUG - 2011-08-21 18:14:38 --> Model Class Initialized
DEBUG - 2011-08-21 18:14:38 --> Model Class Initialized
DEBUG - 2011-08-21 18:14:38 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-21 18:14:38 --> Database Driver Class Initialized
DEBUG - 2011-08-21 18:14:38 --> File loaded: application/views/table/main.php
DEBUG - 2011-08-21 18:14:38 --> Helper loaded: url_helper
DEBUG - 2011-08-21 18:14:38 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-21 18:14:38 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-21 18:14:38 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-21 18:14:38 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-21 18:14:38 --> Final output sent to browser
DEBUG - 2011-08-21 18:14:38 --> Total execution time: 0.2433
DEBUG - 2011-08-21 18:14:41 --> Config Class Initialized
DEBUG - 2011-08-21 18:14:41 --> Hooks Class Initialized
DEBUG - 2011-08-21 18:14:41 --> Utf8 Class Initialized
DEBUG - 2011-08-21 18:14:41 --> UTF-8 Support Enabled
DEBUG - 2011-08-21 18:14:41 --> URI Class Initialized
DEBUG - 2011-08-21 18:14:41 --> Router Class Initialized
ERROR - 2011-08-21 18:14:41 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-08-21 18:33:13 --> Config Class Initialized
DEBUG - 2011-08-21 18:33:13 --> Hooks Class Initialized
DEBUG - 2011-08-21 18:33:13 --> Utf8 Class Initialized
DEBUG - 2011-08-21 18:33:13 --> UTF-8 Support Enabled
DEBUG - 2011-08-21 18:33:13 --> URI Class Initialized
DEBUG - 2011-08-21 18:33:13 --> Router Class Initialized
DEBUG - 2011-08-21 18:33:13 --> No URI present. Default controller set.
DEBUG - 2011-08-21 18:33:13 --> Output Class Initialized
DEBUG - 2011-08-21 18:33:13 --> Input Class Initialized
DEBUG - 2011-08-21 18:33:13 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-21 18:33:13 --> Language Class Initialized
DEBUG - 2011-08-21 18:33:13 --> Loader Class Initialized
DEBUG - 2011-08-21 18:33:13 --> Controller Class Initialized
DEBUG - 2011-08-21 18:33:13 --> File loaded: application/views/splash/main.php
DEBUG - 2011-08-21 18:33:13 --> Helper loaded: url_helper
DEBUG - 2011-08-21 18:33:13 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-21 18:33:13 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-21 18:33:13 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-21 18:33:13 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-21 18:33:13 --> Final output sent to browser
DEBUG - 2011-08-21 18:33:13 --> Total execution time: 0.0461
DEBUG - 2011-08-21 21:21:30 --> Config Class Initialized
DEBUG - 2011-08-21 21:21:30 --> Hooks Class Initialized
DEBUG - 2011-08-21 21:21:30 --> Utf8 Class Initialized
DEBUG - 2011-08-21 21:21:30 --> UTF-8 Support Enabled
DEBUG - 2011-08-21 21:21:30 --> URI Class Initialized
DEBUG - 2011-08-21 21:21:30 --> Router Class Initialized
DEBUG - 2011-08-21 21:21:30 --> Output Class Initialized
DEBUG - 2011-08-21 21:21:30 --> Input Class Initialized
DEBUG - 2011-08-21 21:21:30 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-21 21:21:30 --> Language Class Initialized
DEBUG - 2011-08-21 21:21:30 --> Loader Class Initialized
DEBUG - 2011-08-21 21:21:30 --> Controller Class Initialized
ERROR - 2011-08-21 21:21:30 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-08-21 21:21:30 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-08-21 21:21:30 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-08-21 21:21:30 --> Model Class Initialized
DEBUG - 2011-08-21 21:21:30 --> Model Class Initialized
DEBUG - 2011-08-21 21:21:30 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-21 21:21:30 --> Database Driver Class Initialized
DEBUG - 2011-08-21 21:21:30 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-08-21 21:21:30 --> Helper loaded: url_helper
DEBUG - 2011-08-21 21:21:30 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-21 21:21:30 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-21 21:21:30 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-21 21:21:30 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-21 21:21:30 --> Final output sent to browser
DEBUG - 2011-08-21 21:21:30 --> Total execution time: 0.1474
DEBUG - 2011-08-21 21:32:27 --> Config Class Initialized
DEBUG - 2011-08-21 21:32:27 --> Hooks Class Initialized
DEBUG - 2011-08-21 21:32:27 --> Utf8 Class Initialized
DEBUG - 2011-08-21 21:32:27 --> UTF-8 Support Enabled
DEBUG - 2011-08-21 21:32:27 --> URI Class Initialized
DEBUG - 2011-08-21 21:32:27 --> Router Class Initialized
DEBUG - 2011-08-21 21:32:27 --> Output Class Initialized
DEBUG - 2011-08-21 21:32:27 --> Input Class Initialized
DEBUG - 2011-08-21 21:32:27 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-21 21:32:27 --> Language Class Initialized
DEBUG - 2011-08-21 21:32:27 --> Loader Class Initialized
DEBUG - 2011-08-21 21:32:27 --> Controller Class Initialized
DEBUG - 2011-08-21 21:32:27 --> Model Class Initialized
DEBUG - 2011-08-21 21:32:27 --> Model Class Initialized
DEBUG - 2011-08-21 21:32:27 --> Model Class Initialized
DEBUG - 2011-08-21 21:32:27 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-21 21:32:27 --> Database Driver Class Initialized
DEBUG - 2011-08-21 21:32:28 --> File loaded: application/views/table/main.php
DEBUG - 2011-08-21 21:32:28 --> Helper loaded: url_helper
DEBUG - 2011-08-21 21:32:28 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-21 21:32:28 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-21 21:32:28 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-21 21:32:28 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-21 21:32:28 --> Final output sent to browser
DEBUG - 2011-08-21 21:32:28 --> Total execution time: 1.0768
DEBUG - 2011-08-21 21:55:40 --> Config Class Initialized
DEBUG - 2011-08-21 21:55:40 --> Hooks Class Initialized
DEBUG - 2011-08-21 21:55:40 --> Utf8 Class Initialized
DEBUG - 2011-08-21 21:55:40 --> UTF-8 Support Enabled
DEBUG - 2011-08-21 21:55:40 --> URI Class Initialized
DEBUG - 2011-08-21 21:55:40 --> Router Class Initialized
DEBUG - 2011-08-21 21:55:40 --> Output Class Initialized
DEBUG - 2011-08-21 21:55:40 --> Input Class Initialized
DEBUG - 2011-08-21 21:55:40 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-21 21:55:40 --> Language Class Initialized
DEBUG - 2011-08-21 21:55:40 --> Loader Class Initialized
DEBUG - 2011-08-21 21:55:40 --> Controller Class Initialized
DEBUG - 2011-08-21 21:55:40 --> Model Class Initialized
DEBUG - 2011-08-21 21:55:40 --> Model Class Initialized
DEBUG - 2011-08-21 21:55:40 --> Model Class Initialized
DEBUG - 2011-08-21 21:55:40 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-21 21:55:40 --> Database Driver Class Initialized
DEBUG - 2011-08-21 21:55:40 --> File loaded: application/views/table/main.php
DEBUG - 2011-08-21 21:55:40 --> Helper loaded: url_helper
DEBUG - 2011-08-21 21:55:40 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-21 21:55:40 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-21 21:55:40 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-21 21:55:40 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-21 21:55:40 --> Final output sent to browser
DEBUG - 2011-08-21 21:55:40 --> Total execution time: 0.2876
DEBUG - 2011-08-21 21:55:48 --> Config Class Initialized
DEBUG - 2011-08-21 21:55:48 --> Hooks Class Initialized
DEBUG - 2011-08-21 21:55:48 --> Utf8 Class Initialized
DEBUG - 2011-08-21 21:55:48 --> UTF-8 Support Enabled
DEBUG - 2011-08-21 21:55:48 --> URI Class Initialized
DEBUG - 2011-08-21 21:55:48 --> Router Class Initialized
ERROR - 2011-08-21 21:55:48 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-08-21 22:29:39 --> Config Class Initialized
DEBUG - 2011-08-21 22:29:39 --> Hooks Class Initialized
DEBUG - 2011-08-21 22:29:39 --> Utf8 Class Initialized
DEBUG - 2011-08-21 22:29:39 --> UTF-8 Support Enabled
DEBUG - 2011-08-21 22:29:39 --> URI Class Initialized
DEBUG - 2011-08-21 22:29:39 --> Router Class Initialized
DEBUG - 2011-08-21 22:29:39 --> Output Class Initialized
DEBUG - 2011-08-21 22:29:39 --> Input Class Initialized
DEBUG - 2011-08-21 22:29:39 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-21 22:29:39 --> Language Class Initialized
DEBUG - 2011-08-21 22:29:39 --> Loader Class Initialized
DEBUG - 2011-08-21 22:29:39 --> Controller Class Initialized
ERROR - 2011-08-21 22:29:39 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-08-21 22:29:39 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-08-21 22:29:39 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-08-21 22:29:39 --> Model Class Initialized
DEBUG - 2011-08-21 22:29:39 --> Model Class Initialized
DEBUG - 2011-08-21 22:29:39 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-21 22:29:39 --> Database Driver Class Initialized
DEBUG - 2011-08-21 22:29:39 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-08-21 22:29:39 --> Helper loaded: url_helper
DEBUG - 2011-08-21 22:29:39 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-21 22:29:39 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-21 22:29:39 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-21 22:29:39 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-21 22:29:39 --> Final output sent to browser
DEBUG - 2011-08-21 22:29:39 --> Total execution time: 0.0303
DEBUG - 2011-08-21 22:30:00 --> Config Class Initialized
DEBUG - 2011-08-21 22:30:00 --> Hooks Class Initialized
DEBUG - 2011-08-21 22:30:00 --> Utf8 Class Initialized
DEBUG - 2011-08-21 22:30:00 --> UTF-8 Support Enabled
DEBUG - 2011-08-21 22:30:00 --> URI Class Initialized
DEBUG - 2011-08-21 22:30:00 --> Router Class Initialized
DEBUG - 2011-08-21 22:30:00 --> Output Class Initialized
DEBUG - 2011-08-21 22:30:00 --> Input Class Initialized
DEBUG - 2011-08-21 22:30:00 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-21 22:30:00 --> Language Class Initialized
DEBUG - 2011-08-21 22:30:00 --> Loader Class Initialized
DEBUG - 2011-08-21 22:30:00 --> Controller Class Initialized
DEBUG - 2011-08-21 22:30:00 --> Model Class Initialized
DEBUG - 2011-08-21 22:30:00 --> Model Class Initialized
DEBUG - 2011-08-21 22:30:00 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-21 22:30:00 --> Database Driver Class Initialized
DEBUG - 2011-08-21 22:30:00 --> Final output sent to browser
DEBUG - 2011-08-21 22:30:00 --> Total execution time: 0.5734
DEBUG - 2011-08-21 22:30:03 --> Config Class Initialized
DEBUG - 2011-08-21 22:30:03 --> Hooks Class Initialized
DEBUG - 2011-08-21 22:30:03 --> Utf8 Class Initialized
DEBUG - 2011-08-21 22:30:03 --> UTF-8 Support Enabled
DEBUG - 2011-08-21 22:30:03 --> URI Class Initialized
DEBUG - 2011-08-21 22:30:03 --> Router Class Initialized
DEBUG - 2011-08-21 22:30:03 --> Output Class Initialized
DEBUG - 2011-08-21 22:30:03 --> Input Class Initialized
DEBUG - 2011-08-21 22:30:03 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-21 22:30:03 --> Language Class Initialized
DEBUG - 2011-08-21 22:30:03 --> Loader Class Initialized
DEBUG - 2011-08-21 22:30:03 --> Controller Class Initialized
ERROR - 2011-08-21 22:30:03 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-08-21 22:30:03 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-08-21 22:30:03 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-08-21 22:30:03 --> Model Class Initialized
DEBUG - 2011-08-21 22:30:03 --> Model Class Initialized
DEBUG - 2011-08-21 22:30:03 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-21 22:30:03 --> Database Driver Class Initialized
DEBUG - 2011-08-21 22:30:03 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-08-21 22:30:03 --> Helper loaded: url_helper
DEBUG - 2011-08-21 22:30:03 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-21 22:30:03 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-21 22:30:03 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-21 22:30:03 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-21 22:30:03 --> Final output sent to browser
DEBUG - 2011-08-21 22:30:03 --> Total execution time: 0.1675
DEBUG - 2011-08-21 22:30:15 --> Config Class Initialized
DEBUG - 2011-08-21 22:30:15 --> Hooks Class Initialized
DEBUG - 2011-08-21 22:30:15 --> Utf8 Class Initialized
DEBUG - 2011-08-21 22:30:15 --> UTF-8 Support Enabled
DEBUG - 2011-08-21 22:30:15 --> URI Class Initialized
DEBUG - 2011-08-21 22:30:15 --> Router Class Initialized
ERROR - 2011-08-21 22:30:15 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-08-21 22:42:56 --> Config Class Initialized
DEBUG - 2011-08-21 22:42:56 --> Hooks Class Initialized
DEBUG - 2011-08-21 22:42:56 --> Utf8 Class Initialized
DEBUG - 2011-08-21 22:42:56 --> UTF-8 Support Enabled
DEBUG - 2011-08-21 22:42:56 --> URI Class Initialized
DEBUG - 2011-08-21 22:42:56 --> Router Class Initialized
ERROR - 2011-08-21 22:42:56 --> 404 Page Not Found --> robots.txt
DEBUG - 2011-08-21 22:43:16 --> Config Class Initialized
DEBUG - 2011-08-21 22:43:16 --> Hooks Class Initialized
DEBUG - 2011-08-21 22:43:16 --> Utf8 Class Initialized
DEBUG - 2011-08-21 22:43:16 --> UTF-8 Support Enabled
DEBUG - 2011-08-21 22:43:16 --> URI Class Initialized
DEBUG - 2011-08-21 22:43:16 --> Router Class Initialized
ERROR - 2011-08-21 22:43:16 --> 404 Page Not Found --> robots.txt
DEBUG - 2011-08-21 23:28:08 --> Config Class Initialized
DEBUG - 2011-08-21 23:28:08 --> Hooks Class Initialized
DEBUG - 2011-08-21 23:28:08 --> Utf8 Class Initialized
DEBUG - 2011-08-21 23:28:08 --> UTF-8 Support Enabled
DEBUG - 2011-08-21 23:28:08 --> URI Class Initialized
DEBUG - 2011-08-21 23:28:08 --> Router Class Initialized
DEBUG - 2011-08-21 23:28:08 --> No URI present. Default controller set.
DEBUG - 2011-08-21 23:28:08 --> Output Class Initialized
DEBUG - 2011-08-21 23:28:08 --> Input Class Initialized
DEBUG - 2011-08-21 23:28:08 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-21 23:28:08 --> Language Class Initialized
DEBUG - 2011-08-21 23:28:09 --> Loader Class Initialized
DEBUG - 2011-08-21 23:28:09 --> Controller Class Initialized
DEBUG - 2011-08-21 23:28:09 --> File loaded: application/views/splash/main.php
DEBUG - 2011-08-21 23:28:09 --> Helper loaded: url_helper
DEBUG - 2011-08-21 23:28:09 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-21 23:28:09 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-21 23:28:09 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-21 23:28:09 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-21 23:28:09 --> Final output sent to browser
DEBUG - 2011-08-21 23:28:09 --> Total execution time: 0.0496

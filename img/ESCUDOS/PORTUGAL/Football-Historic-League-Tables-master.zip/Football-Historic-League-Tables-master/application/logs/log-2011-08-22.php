<?php  if ( ! defined('BASEPATH')) exit('No direct script access allowed'); ?>

DEBUG - 2011-08-22 01:11:37 --> Config Class Initialized
DEBUG - 2011-08-22 01:11:37 --> Hooks Class Initialized
DEBUG - 2011-08-22 01:11:37 --> Utf8 Class Initialized
DEBUG - 2011-08-22 01:11:37 --> UTF-8 Support Enabled
DEBUG - 2011-08-22 01:11:37 --> URI Class Initialized
DEBUG - 2011-08-22 01:11:37 --> Router Class Initialized
DEBUG - 2011-08-22 01:11:37 --> Output Class Initialized
DEBUG - 2011-08-22 01:11:37 --> Input Class Initialized
DEBUG - 2011-08-22 01:11:37 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-22 01:11:37 --> Language Class Initialized
DEBUG - 2011-08-22 01:11:37 --> Loader Class Initialized
DEBUG - 2011-08-22 01:11:37 --> Controller Class Initialized
ERROR - 2011-08-22 01:11:37 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-08-22 01:11:37 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-08-22 01:11:37 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-08-22 01:11:37 --> Model Class Initialized
DEBUG - 2011-08-22 01:11:37 --> Model Class Initialized
DEBUG - 2011-08-22 01:11:37 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-22 01:11:37 --> Database Driver Class Initialized
DEBUG - 2011-08-22 01:11:37 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-08-22 01:11:37 --> Helper loaded: url_helper
DEBUG - 2011-08-22 01:11:37 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-22 01:11:37 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-22 01:11:37 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-22 01:11:37 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-22 01:11:37 --> Final output sent to browser
DEBUG - 2011-08-22 01:11:37 --> Total execution time: 0.0784
DEBUG - 2011-08-22 01:11:38 --> Config Class Initialized
DEBUG - 2011-08-22 01:11:38 --> Hooks Class Initialized
DEBUG - 2011-08-22 01:11:38 --> Utf8 Class Initialized
DEBUG - 2011-08-22 01:11:38 --> UTF-8 Support Enabled
DEBUG - 2011-08-22 01:11:38 --> URI Class Initialized
DEBUG - 2011-08-22 01:11:38 --> Router Class Initialized
DEBUG - 2011-08-22 01:11:38 --> Output Class Initialized
DEBUG - 2011-08-22 01:11:38 --> Input Class Initialized
DEBUG - 2011-08-22 01:11:38 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-22 01:11:38 --> Language Class Initialized
DEBUG - 2011-08-22 01:11:38 --> Loader Class Initialized
DEBUG - 2011-08-22 01:11:38 --> Controller Class Initialized
DEBUG - 2011-08-22 01:11:38 --> Model Class Initialized
DEBUG - 2011-08-22 01:11:38 --> Model Class Initialized
DEBUG - 2011-08-22 01:11:38 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-22 01:11:38 --> Database Driver Class Initialized
DEBUG - 2011-08-22 01:11:39 --> Final output sent to browser
DEBUG - 2011-08-22 01:11:39 --> Total execution time: 0.5539
DEBUG - 2011-08-22 01:11:40 --> Config Class Initialized
DEBUG - 2011-08-22 01:11:40 --> Hooks Class Initialized
DEBUG - 2011-08-22 01:11:40 --> Utf8 Class Initialized
DEBUG - 2011-08-22 01:11:40 --> UTF-8 Support Enabled
DEBUG - 2011-08-22 01:11:40 --> URI Class Initialized
DEBUG - 2011-08-22 01:11:40 --> Router Class Initialized
ERROR - 2011-08-22 01:11:40 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-08-22 01:11:40 --> Config Class Initialized
DEBUG - 2011-08-22 01:11:40 --> Hooks Class Initialized
DEBUG - 2011-08-22 01:11:40 --> Utf8 Class Initialized
DEBUG - 2011-08-22 01:11:40 --> UTF-8 Support Enabled
DEBUG - 2011-08-22 01:11:40 --> URI Class Initialized
DEBUG - 2011-08-22 01:11:40 --> Router Class Initialized
ERROR - 2011-08-22 01:11:40 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-08-22 01:11:40 --> Config Class Initialized
DEBUG - 2011-08-22 01:11:40 --> Hooks Class Initialized
DEBUG - 2011-08-22 01:11:40 --> Utf8 Class Initialized
DEBUG - 2011-08-22 01:11:40 --> UTF-8 Support Enabled
DEBUG - 2011-08-22 01:11:40 --> URI Class Initialized
DEBUG - 2011-08-22 01:11:40 --> Router Class Initialized
ERROR - 2011-08-22 01:11:40 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-08-22 02:06:02 --> Config Class Initialized
DEBUG - 2011-08-22 02:06:02 --> Hooks Class Initialized
DEBUG - 2011-08-22 02:06:02 --> Utf8 Class Initialized
DEBUG - 2011-08-22 02:06:02 --> UTF-8 Support Enabled
DEBUG - 2011-08-22 02:06:02 --> URI Class Initialized
DEBUG - 2011-08-22 02:06:02 --> Router Class Initialized
DEBUG - 2011-08-22 02:06:02 --> Output Class Initialized
DEBUG - 2011-08-22 02:06:02 --> Input Class Initialized
DEBUG - 2011-08-22 02:06:02 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-22 02:06:02 --> Language Class Initialized
DEBUG - 2011-08-22 02:06:02 --> Loader Class Initialized
DEBUG - 2011-08-22 02:06:02 --> Controller Class Initialized
DEBUG - 2011-08-22 02:06:02 --> Model Class Initialized
DEBUG - 2011-08-22 02:06:03 --> Model Class Initialized
DEBUG - 2011-08-22 02:06:03 --> Model Class Initialized
DEBUG - 2011-08-22 02:06:03 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-22 02:06:03 --> Database Driver Class Initialized
DEBUG - 2011-08-22 02:06:04 --> File loaded: application/views/table/main.php
DEBUG - 2011-08-22 02:06:04 --> Helper loaded: url_helper
DEBUG - 2011-08-22 02:06:04 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-22 02:06:04 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-22 02:06:04 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-22 02:06:04 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-22 02:06:04 --> Final output sent to browser
DEBUG - 2011-08-22 02:06:04 --> Total execution time: 1.6394
DEBUG - 2011-08-22 02:06:07 --> Config Class Initialized
DEBUG - 2011-08-22 02:06:07 --> Hooks Class Initialized
DEBUG - 2011-08-22 02:06:07 --> Utf8 Class Initialized
DEBUG - 2011-08-22 02:06:07 --> UTF-8 Support Enabled
DEBUG - 2011-08-22 02:06:07 --> URI Class Initialized
DEBUG - 2011-08-22 02:06:07 --> Router Class Initialized
ERROR - 2011-08-22 02:06:07 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-08-22 02:24:43 --> Config Class Initialized
DEBUG - 2011-08-22 02:24:43 --> Hooks Class Initialized
DEBUG - 2011-08-22 02:24:43 --> Utf8 Class Initialized
DEBUG - 2011-08-22 02:24:43 --> UTF-8 Support Enabled
DEBUG - 2011-08-22 02:24:43 --> URI Class Initialized
DEBUG - 2011-08-22 02:24:43 --> Router Class Initialized
DEBUG - 2011-08-22 02:24:43 --> Output Class Initialized
DEBUG - 2011-08-22 02:24:43 --> Input Class Initialized
DEBUG - 2011-08-22 02:24:43 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-22 02:24:43 --> Language Class Initialized
DEBUG - 2011-08-22 02:24:43 --> Loader Class Initialized
DEBUG - 2011-08-22 02:24:44 --> Controller Class Initialized
ERROR - 2011-08-22 02:24:44 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-08-22 02:24:44 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-08-22 02:24:44 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-08-22 02:24:44 --> Model Class Initialized
DEBUG - 2011-08-22 02:24:44 --> Model Class Initialized
DEBUG - 2011-08-22 02:24:44 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-22 02:24:44 --> Database Driver Class Initialized
DEBUG - 2011-08-22 02:24:44 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-08-22 02:24:44 --> Helper loaded: url_helper
DEBUG - 2011-08-22 02:24:44 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-22 02:24:44 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-22 02:24:44 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-22 02:24:44 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-22 02:24:44 --> Final output sent to browser
DEBUG - 2011-08-22 02:24:44 --> Total execution time: 0.3604
DEBUG - 2011-08-22 02:24:46 --> Config Class Initialized
DEBUG - 2011-08-22 02:24:46 --> Hooks Class Initialized
DEBUG - 2011-08-22 02:24:46 --> Utf8 Class Initialized
DEBUG - 2011-08-22 02:24:46 --> UTF-8 Support Enabled
DEBUG - 2011-08-22 02:24:46 --> URI Class Initialized
DEBUG - 2011-08-22 02:24:46 --> Router Class Initialized
DEBUG - 2011-08-22 02:24:46 --> Output Class Initialized
DEBUG - 2011-08-22 02:24:46 --> Input Class Initialized
DEBUG - 2011-08-22 02:24:46 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-22 02:24:46 --> Language Class Initialized
DEBUG - 2011-08-22 02:24:46 --> Loader Class Initialized
DEBUG - 2011-08-22 02:24:46 --> Controller Class Initialized
DEBUG - 2011-08-22 02:24:46 --> Model Class Initialized
DEBUG - 2011-08-22 02:24:46 --> Model Class Initialized
DEBUG - 2011-08-22 02:24:46 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-22 02:24:46 --> Database Driver Class Initialized
DEBUG - 2011-08-22 02:24:47 --> Final output sent to browser
DEBUG - 2011-08-22 02:24:47 --> Total execution time: 1.0297
DEBUG - 2011-08-22 02:24:48 --> Config Class Initialized
DEBUG - 2011-08-22 02:24:48 --> Hooks Class Initialized
DEBUG - 2011-08-22 02:24:48 --> Utf8 Class Initialized
DEBUG - 2011-08-22 02:24:48 --> UTF-8 Support Enabled
DEBUG - 2011-08-22 02:24:48 --> URI Class Initialized
DEBUG - 2011-08-22 02:24:48 --> Router Class Initialized
ERROR - 2011-08-22 02:24:48 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-08-22 02:36:29 --> Config Class Initialized
DEBUG - 2011-08-22 02:36:29 --> Hooks Class Initialized
DEBUG - 2011-08-22 02:36:29 --> Utf8 Class Initialized
DEBUG - 2011-08-22 02:36:29 --> UTF-8 Support Enabled
DEBUG - 2011-08-22 02:36:29 --> URI Class Initialized
DEBUG - 2011-08-22 02:36:29 --> Router Class Initialized
ERROR - 2011-08-22 02:36:29 --> 404 Page Not Found --> robots.txt
DEBUG - 2011-08-22 02:36:30 --> Config Class Initialized
DEBUG - 2011-08-22 02:36:30 --> Hooks Class Initialized
DEBUG - 2011-08-22 02:36:30 --> Utf8 Class Initialized
DEBUG - 2011-08-22 02:36:30 --> UTF-8 Support Enabled
DEBUG - 2011-08-22 02:36:30 --> URI Class Initialized
DEBUG - 2011-08-22 02:36:30 --> Router Class Initialized
DEBUG - 2011-08-22 02:36:30 --> No URI present. Default controller set.
DEBUG - 2011-08-22 02:36:30 --> Output Class Initialized
DEBUG - 2011-08-22 02:36:30 --> Input Class Initialized
DEBUG - 2011-08-22 02:36:30 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-22 02:36:30 --> Language Class Initialized
DEBUG - 2011-08-22 02:36:30 --> Loader Class Initialized
DEBUG - 2011-08-22 02:36:30 --> Controller Class Initialized
DEBUG - 2011-08-22 02:36:30 --> File loaded: application/views/splash/main.php
DEBUG - 2011-08-22 02:36:30 --> Helper loaded: url_helper
DEBUG - 2011-08-22 02:36:30 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-22 02:36:30 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-22 02:36:30 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-22 02:36:30 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-22 02:36:30 --> Final output sent to browser
DEBUG - 2011-08-22 02:36:30 --> Total execution time: 0.0840
DEBUG - 2011-08-22 02:36:58 --> Config Class Initialized
DEBUG - 2011-08-22 02:36:58 --> Hooks Class Initialized
DEBUG - 2011-08-22 02:36:58 --> Utf8 Class Initialized
DEBUG - 2011-08-22 02:36:58 --> UTF-8 Support Enabled
DEBUG - 2011-08-22 02:36:58 --> URI Class Initialized
DEBUG - 2011-08-22 02:36:58 --> Router Class Initialized
DEBUG - 2011-08-22 02:36:58 --> Output Class Initialized
DEBUG - 2011-08-22 02:36:58 --> Input Class Initialized
DEBUG - 2011-08-22 02:36:58 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-22 02:36:58 --> Language Class Initialized
DEBUG - 2011-08-22 02:36:58 --> Loader Class Initialized
DEBUG - 2011-08-22 02:36:58 --> Controller Class Initialized
DEBUG - 2011-08-22 02:36:58 --> Model Class Initialized
DEBUG - 2011-08-22 02:36:58 --> Model Class Initialized
DEBUG - 2011-08-22 02:36:58 --> Model Class Initialized
DEBUG - 2011-08-22 02:36:58 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-22 02:36:58 --> Database Driver Class Initialized
DEBUG - 2011-08-22 02:36:59 --> File loaded: application/views/table/main.php
DEBUG - 2011-08-22 02:36:59 --> Helper loaded: url_helper
DEBUG - 2011-08-22 02:36:59 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-22 02:36:59 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-22 02:36:59 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-22 02:36:59 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-22 02:36:59 --> Final output sent to browser
DEBUG - 2011-08-22 02:36:59 --> Total execution time: 0.8426
DEBUG - 2011-08-22 02:37:01 --> Config Class Initialized
DEBUG - 2011-08-22 02:37:01 --> Hooks Class Initialized
DEBUG - 2011-08-22 02:37:01 --> Utf8 Class Initialized
DEBUG - 2011-08-22 02:37:01 --> UTF-8 Support Enabled
DEBUG - 2011-08-22 02:37:01 --> URI Class Initialized
DEBUG - 2011-08-22 02:37:01 --> Router Class Initialized
ERROR - 2011-08-22 02:37:01 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-08-22 02:37:21 --> Config Class Initialized
DEBUG - 2011-08-22 02:37:21 --> Hooks Class Initialized
DEBUG - 2011-08-22 02:37:21 --> Utf8 Class Initialized
DEBUG - 2011-08-22 02:37:21 --> UTF-8 Support Enabled
DEBUG - 2011-08-22 02:37:21 --> URI Class Initialized
DEBUG - 2011-08-22 02:37:21 --> Router Class Initialized
DEBUG - 2011-08-22 02:37:21 --> Output Class Initialized
DEBUG - 2011-08-22 02:37:21 --> Input Class Initialized
DEBUG - 2011-08-22 02:37:21 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-22 02:37:21 --> Language Class Initialized
DEBUG - 2011-08-22 02:37:21 --> Loader Class Initialized
DEBUG - 2011-08-22 02:37:21 --> Controller Class Initialized
DEBUG - 2011-08-22 02:37:21 --> Model Class Initialized
DEBUG - 2011-08-22 02:37:21 --> Model Class Initialized
DEBUG - 2011-08-22 02:37:21 --> Model Class Initialized
DEBUG - 2011-08-22 02:37:21 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-22 02:37:21 --> Database Driver Class Initialized
DEBUG - 2011-08-22 02:37:33 --> File loaded: application/views/table/main.php
DEBUG - 2011-08-22 02:37:33 --> Helper loaded: url_helper
DEBUG - 2011-08-22 02:37:33 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-22 02:37:33 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-22 02:37:33 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-22 02:37:33 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-22 02:37:33 --> Final output sent to browser
DEBUG - 2011-08-22 02:37:33 --> Total execution time: 11.9450
DEBUG - 2011-08-22 02:37:35 --> Config Class Initialized
DEBUG - 2011-08-22 02:37:35 --> Hooks Class Initialized
DEBUG - 2011-08-22 02:37:35 --> Utf8 Class Initialized
DEBUG - 2011-08-22 02:37:35 --> UTF-8 Support Enabled
DEBUG - 2011-08-22 02:37:35 --> URI Class Initialized
DEBUG - 2011-08-22 02:37:35 --> Router Class Initialized
ERROR - 2011-08-22 02:37:35 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-08-22 02:37:37 --> Config Class Initialized
DEBUG - 2011-08-22 02:37:37 --> Hooks Class Initialized
DEBUG - 2011-08-22 02:37:37 --> Utf8 Class Initialized
DEBUG - 2011-08-22 02:37:37 --> UTF-8 Support Enabled
DEBUG - 2011-08-22 02:37:37 --> URI Class Initialized
DEBUG - 2011-08-22 02:37:37 --> Router Class Initialized
DEBUG - 2011-08-22 02:37:37 --> Output Class Initialized
DEBUG - 2011-08-22 02:37:37 --> Input Class Initialized
DEBUG - 2011-08-22 02:37:37 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-22 02:37:37 --> Language Class Initialized
DEBUG - 2011-08-22 02:37:37 --> Loader Class Initialized
DEBUG - 2011-08-22 02:37:37 --> Controller Class Initialized
DEBUG - 2011-08-22 02:37:37 --> Model Class Initialized
DEBUG - 2011-08-22 02:37:37 --> Model Class Initialized
DEBUG - 2011-08-22 02:37:37 --> Model Class Initialized
DEBUG - 2011-08-22 02:37:37 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-22 02:37:37 --> Database Driver Class Initialized
DEBUG - 2011-08-22 02:37:37 --> File loaded: application/views/table/main.php
DEBUG - 2011-08-22 02:37:37 --> Helper loaded: url_helper
DEBUG - 2011-08-22 02:37:37 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-22 02:37:37 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-22 02:37:37 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-22 02:37:37 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-22 02:37:37 --> Final output sent to browser
DEBUG - 2011-08-22 02:37:37 --> Total execution time: 0.0817
DEBUG - 2011-08-22 02:37:53 --> Config Class Initialized
DEBUG - 2011-08-22 02:37:53 --> Hooks Class Initialized
DEBUG - 2011-08-22 02:37:53 --> Utf8 Class Initialized
DEBUG - 2011-08-22 02:37:53 --> UTF-8 Support Enabled
DEBUG - 2011-08-22 02:37:53 --> URI Class Initialized
DEBUG - 2011-08-22 02:37:53 --> Router Class Initialized
DEBUG - 2011-08-22 02:37:53 --> Output Class Initialized
DEBUG - 2011-08-22 02:37:53 --> Input Class Initialized
DEBUG - 2011-08-22 02:37:53 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-22 02:37:53 --> Language Class Initialized
DEBUG - 2011-08-22 02:37:53 --> Loader Class Initialized
DEBUG - 2011-08-22 02:37:53 --> Controller Class Initialized
DEBUG - 2011-08-22 02:37:53 --> Model Class Initialized
DEBUG - 2011-08-22 02:37:53 --> Model Class Initialized
DEBUG - 2011-08-22 02:37:53 --> Model Class Initialized
DEBUG - 2011-08-22 02:37:53 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-22 02:37:53 --> Database Driver Class Initialized
DEBUG - 2011-08-22 02:37:53 --> File loaded: application/views/table/main.php
DEBUG - 2011-08-22 02:37:53 --> Helper loaded: url_helper
DEBUG - 2011-08-22 02:37:53 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-22 02:37:53 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-22 02:37:53 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-22 02:37:53 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-22 02:37:53 --> Final output sent to browser
DEBUG - 2011-08-22 02:37:53 --> Total execution time: 0.5174
DEBUG - 2011-08-22 02:37:54 --> Config Class Initialized
DEBUG - 2011-08-22 02:37:54 --> Hooks Class Initialized
DEBUG - 2011-08-22 02:37:54 --> Utf8 Class Initialized
DEBUG - 2011-08-22 02:37:54 --> UTF-8 Support Enabled
DEBUG - 2011-08-22 02:37:54 --> URI Class Initialized
DEBUG - 2011-08-22 02:37:54 --> Router Class Initialized
ERROR - 2011-08-22 02:37:54 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-08-22 02:37:54 --> Config Class Initialized
DEBUG - 2011-08-22 02:37:54 --> Hooks Class Initialized
DEBUG - 2011-08-22 02:37:54 --> Utf8 Class Initialized
DEBUG - 2011-08-22 02:37:54 --> UTF-8 Support Enabled
DEBUG - 2011-08-22 02:37:54 --> URI Class Initialized
DEBUG - 2011-08-22 02:37:54 --> Router Class Initialized
DEBUG - 2011-08-22 02:37:54 --> Output Class Initialized
DEBUG - 2011-08-22 02:37:54 --> Input Class Initialized
DEBUG - 2011-08-22 02:37:54 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-22 02:37:54 --> Language Class Initialized
DEBUG - 2011-08-22 02:37:54 --> Loader Class Initialized
DEBUG - 2011-08-22 02:37:54 --> Controller Class Initialized
DEBUG - 2011-08-22 02:37:54 --> Model Class Initialized
DEBUG - 2011-08-22 02:37:54 --> Model Class Initialized
DEBUG - 2011-08-22 02:37:54 --> Model Class Initialized
DEBUG - 2011-08-22 02:37:54 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-22 02:37:54 --> Database Driver Class Initialized
DEBUG - 2011-08-22 02:37:54 --> File loaded: application/views/table/main.php
DEBUG - 2011-08-22 02:37:54 --> Helper loaded: url_helper
DEBUG - 2011-08-22 02:37:54 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-22 02:37:54 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-22 02:37:54 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-22 02:37:54 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-22 02:37:54 --> Final output sent to browser
DEBUG - 2011-08-22 02:37:54 --> Total execution time: 0.1172
DEBUG - 2011-08-22 02:38:05 --> Config Class Initialized
DEBUG - 2011-08-22 02:38:05 --> Hooks Class Initialized
DEBUG - 2011-08-22 02:38:05 --> Utf8 Class Initialized
DEBUG - 2011-08-22 02:38:05 --> UTF-8 Support Enabled
DEBUG - 2011-08-22 02:38:05 --> URI Class Initialized
DEBUG - 2011-08-22 02:38:05 --> Router Class Initialized
DEBUG - 2011-08-22 02:38:05 --> Output Class Initialized
DEBUG - 2011-08-22 02:38:05 --> Input Class Initialized
DEBUG - 2011-08-22 02:38:05 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-22 02:38:05 --> Language Class Initialized
DEBUG - 2011-08-22 02:38:05 --> Loader Class Initialized
DEBUG - 2011-08-22 02:38:05 --> Controller Class Initialized
DEBUG - 2011-08-22 02:38:05 --> Model Class Initialized
DEBUG - 2011-08-22 02:38:05 --> Model Class Initialized
DEBUG - 2011-08-22 02:38:05 --> Model Class Initialized
DEBUG - 2011-08-22 02:38:05 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-22 02:38:05 --> Database Driver Class Initialized
DEBUG - 2011-08-22 02:38:09 --> File loaded: application/views/table/main.php
DEBUG - 2011-08-22 02:38:09 --> Helper loaded: url_helper
DEBUG - 2011-08-22 02:38:09 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-22 02:38:09 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-22 02:38:09 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-22 02:38:09 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-22 02:38:09 --> Final output sent to browser
DEBUG - 2011-08-22 02:38:09 --> Total execution time: 4.0208
DEBUG - 2011-08-22 02:38:10 --> Config Class Initialized
DEBUG - 2011-08-22 02:38:10 --> Hooks Class Initialized
DEBUG - 2011-08-22 02:38:10 --> Utf8 Class Initialized
DEBUG - 2011-08-22 02:38:10 --> UTF-8 Support Enabled
DEBUG - 2011-08-22 02:38:10 --> URI Class Initialized
DEBUG - 2011-08-22 02:38:10 --> Router Class Initialized
ERROR - 2011-08-22 02:38:10 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-08-22 02:38:11 --> Config Class Initialized
DEBUG - 2011-08-22 02:38:11 --> Hooks Class Initialized
DEBUG - 2011-08-22 02:38:11 --> Utf8 Class Initialized
DEBUG - 2011-08-22 02:38:11 --> UTF-8 Support Enabled
DEBUG - 2011-08-22 02:38:11 --> URI Class Initialized
DEBUG - 2011-08-22 02:38:11 --> Router Class Initialized
DEBUG - 2011-08-22 02:38:11 --> Output Class Initialized
DEBUG - 2011-08-22 02:38:11 --> Input Class Initialized
DEBUG - 2011-08-22 02:38:11 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-22 02:38:11 --> Language Class Initialized
DEBUG - 2011-08-22 02:38:11 --> Loader Class Initialized
DEBUG - 2011-08-22 02:38:11 --> Controller Class Initialized
DEBUG - 2011-08-22 02:38:11 --> Model Class Initialized
DEBUG - 2011-08-22 02:38:11 --> Model Class Initialized
DEBUG - 2011-08-22 02:38:11 --> Model Class Initialized
DEBUG - 2011-08-22 02:38:11 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-22 02:38:11 --> Database Driver Class Initialized
DEBUG - 2011-08-22 02:38:11 --> File loaded: application/views/table/main.php
DEBUG - 2011-08-22 02:38:11 --> Helper loaded: url_helper
DEBUG - 2011-08-22 02:38:11 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-22 02:38:11 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-22 02:38:11 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-22 02:38:11 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-22 02:38:11 --> Final output sent to browser
DEBUG - 2011-08-22 02:38:11 --> Total execution time: 0.1012
DEBUG - 2011-08-22 02:38:20 --> Config Class Initialized
DEBUG - 2011-08-22 02:38:20 --> Hooks Class Initialized
DEBUG - 2011-08-22 02:38:20 --> Utf8 Class Initialized
DEBUG - 2011-08-22 02:38:20 --> UTF-8 Support Enabled
DEBUG - 2011-08-22 02:38:20 --> URI Class Initialized
DEBUG - 2011-08-22 02:38:20 --> Router Class Initialized
DEBUG - 2011-08-22 02:38:20 --> Output Class Initialized
DEBUG - 2011-08-22 02:38:20 --> Input Class Initialized
DEBUG - 2011-08-22 02:38:20 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-22 02:38:20 --> Language Class Initialized
DEBUG - 2011-08-22 02:38:20 --> Loader Class Initialized
DEBUG - 2011-08-22 02:38:20 --> Controller Class Initialized
DEBUG - 2011-08-22 02:38:20 --> Model Class Initialized
DEBUG - 2011-08-22 02:38:20 --> Model Class Initialized
DEBUG - 2011-08-22 02:38:20 --> Model Class Initialized
DEBUG - 2011-08-22 02:38:20 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-22 02:38:20 --> Database Driver Class Initialized
DEBUG - 2011-08-22 02:38:21 --> File loaded: application/views/table/main.php
DEBUG - 2011-08-22 02:38:21 --> Helper loaded: url_helper
DEBUG - 2011-08-22 02:38:21 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-22 02:38:21 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-22 02:38:21 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-22 02:38:21 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-22 02:38:21 --> Final output sent to browser
DEBUG - 2011-08-22 02:38:21 --> Total execution time: 0.8269
DEBUG - 2011-08-22 02:38:22 --> Config Class Initialized
DEBUG - 2011-08-22 02:38:22 --> Hooks Class Initialized
DEBUG - 2011-08-22 02:38:22 --> Utf8 Class Initialized
DEBUG - 2011-08-22 02:38:22 --> UTF-8 Support Enabled
DEBUG - 2011-08-22 02:38:22 --> URI Class Initialized
DEBUG - 2011-08-22 02:38:22 --> Router Class Initialized
ERROR - 2011-08-22 02:38:22 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-08-22 02:38:24 --> Config Class Initialized
DEBUG - 2011-08-22 02:38:24 --> Hooks Class Initialized
DEBUG - 2011-08-22 02:38:24 --> Utf8 Class Initialized
DEBUG - 2011-08-22 02:38:24 --> UTF-8 Support Enabled
DEBUG - 2011-08-22 02:38:24 --> URI Class Initialized
DEBUG - 2011-08-22 02:38:24 --> Router Class Initialized
DEBUG - 2011-08-22 02:38:24 --> Output Class Initialized
DEBUG - 2011-08-22 02:38:24 --> Input Class Initialized
DEBUG - 2011-08-22 02:38:24 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-22 02:38:24 --> Language Class Initialized
DEBUG - 2011-08-22 02:38:24 --> Loader Class Initialized
DEBUG - 2011-08-22 02:38:24 --> Controller Class Initialized
DEBUG - 2011-08-22 02:38:24 --> Model Class Initialized
DEBUG - 2011-08-22 02:38:24 --> Model Class Initialized
DEBUG - 2011-08-22 02:38:24 --> Model Class Initialized
DEBUG - 2011-08-22 02:38:24 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-22 02:38:24 --> Database Driver Class Initialized
DEBUG - 2011-08-22 02:38:24 --> File loaded: application/views/table/main.php
DEBUG - 2011-08-22 02:38:24 --> Helper loaded: url_helper
DEBUG - 2011-08-22 02:38:24 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-22 02:38:24 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-22 02:38:24 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-22 02:38:24 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-22 02:38:24 --> Final output sent to browser
DEBUG - 2011-08-22 02:38:24 --> Total execution time: 0.0777
DEBUG - 2011-08-22 02:38:35 --> Config Class Initialized
DEBUG - 2011-08-22 02:38:35 --> Hooks Class Initialized
DEBUG - 2011-08-22 02:38:35 --> Utf8 Class Initialized
DEBUG - 2011-08-22 02:38:35 --> UTF-8 Support Enabled
DEBUG - 2011-08-22 02:38:35 --> URI Class Initialized
DEBUG - 2011-08-22 02:38:35 --> Router Class Initialized
DEBUG - 2011-08-22 02:38:35 --> Output Class Initialized
DEBUG - 2011-08-22 02:38:35 --> Input Class Initialized
DEBUG - 2011-08-22 02:38:35 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-22 02:38:35 --> Language Class Initialized
DEBUG - 2011-08-22 02:38:35 --> Loader Class Initialized
DEBUG - 2011-08-22 02:38:35 --> Controller Class Initialized
DEBUG - 2011-08-22 02:38:35 --> Model Class Initialized
DEBUG - 2011-08-22 02:38:35 --> Model Class Initialized
DEBUG - 2011-08-22 02:38:35 --> Model Class Initialized
DEBUG - 2011-08-22 02:38:35 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-22 02:38:35 --> Database Driver Class Initialized
DEBUG - 2011-08-22 02:38:36 --> File loaded: application/views/table/main.php
DEBUG - 2011-08-22 02:38:36 --> Helper loaded: url_helper
DEBUG - 2011-08-22 02:38:36 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-22 02:38:36 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-22 02:38:36 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-22 02:38:36 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-22 02:38:36 --> Final output sent to browser
DEBUG - 2011-08-22 02:38:36 --> Total execution time: 0.5338
DEBUG - 2011-08-22 02:38:37 --> Config Class Initialized
DEBUG - 2011-08-22 02:38:37 --> Hooks Class Initialized
DEBUG - 2011-08-22 02:38:37 --> Utf8 Class Initialized
DEBUG - 2011-08-22 02:38:37 --> UTF-8 Support Enabled
DEBUG - 2011-08-22 02:38:37 --> URI Class Initialized
DEBUG - 2011-08-22 02:38:37 --> Router Class Initialized
ERROR - 2011-08-22 02:38:37 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-08-22 02:38:41 --> Config Class Initialized
DEBUG - 2011-08-22 02:38:41 --> Hooks Class Initialized
DEBUG - 2011-08-22 02:38:41 --> Utf8 Class Initialized
DEBUG - 2011-08-22 02:38:41 --> UTF-8 Support Enabled
DEBUG - 2011-08-22 02:38:41 --> URI Class Initialized
DEBUG - 2011-08-22 02:38:41 --> Router Class Initialized
DEBUG - 2011-08-22 02:38:41 --> Output Class Initialized
DEBUG - 2011-08-22 02:38:41 --> Input Class Initialized
DEBUG - 2011-08-22 02:38:41 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-22 02:38:41 --> Language Class Initialized
DEBUG - 2011-08-22 02:38:41 --> Loader Class Initialized
DEBUG - 2011-08-22 02:38:41 --> Controller Class Initialized
DEBUG - 2011-08-22 02:38:41 --> Model Class Initialized
DEBUG - 2011-08-22 02:38:41 --> Model Class Initialized
DEBUG - 2011-08-22 02:38:41 --> Model Class Initialized
DEBUG - 2011-08-22 02:38:41 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-22 02:38:41 --> Database Driver Class Initialized
DEBUG - 2011-08-22 02:38:41 --> File loaded: application/views/table/main.php
DEBUG - 2011-08-22 02:38:41 --> Helper loaded: url_helper
DEBUG - 2011-08-22 02:38:41 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-22 02:38:41 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-22 02:38:41 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-22 02:38:41 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-22 02:38:41 --> Final output sent to browser
DEBUG - 2011-08-22 02:38:41 --> Total execution time: 0.0544
DEBUG - 2011-08-22 02:38:52 --> Config Class Initialized
DEBUG - 2011-08-22 02:38:52 --> Hooks Class Initialized
DEBUG - 2011-08-22 02:38:52 --> Utf8 Class Initialized
DEBUG - 2011-08-22 02:38:52 --> UTF-8 Support Enabled
DEBUG - 2011-08-22 02:38:52 --> URI Class Initialized
DEBUG - 2011-08-22 02:38:52 --> Router Class Initialized
DEBUG - 2011-08-22 02:38:52 --> Output Class Initialized
DEBUG - 2011-08-22 02:38:52 --> Input Class Initialized
DEBUG - 2011-08-22 02:38:52 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-22 02:38:52 --> Language Class Initialized
DEBUG - 2011-08-22 02:38:52 --> Loader Class Initialized
DEBUG - 2011-08-22 02:38:52 --> Controller Class Initialized
DEBUG - 2011-08-22 02:38:52 --> Model Class Initialized
DEBUG - 2011-08-22 02:38:52 --> Model Class Initialized
DEBUG - 2011-08-22 02:38:52 --> Model Class Initialized
DEBUG - 2011-08-22 02:38:52 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-22 02:38:52 --> Database Driver Class Initialized
DEBUG - 2011-08-22 02:38:56 --> File loaded: application/views/table/main.php
DEBUG - 2011-08-22 02:38:56 --> Helper loaded: url_helper
DEBUG - 2011-08-22 02:38:56 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-22 02:38:56 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-22 02:38:56 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-22 02:38:56 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-22 02:38:56 --> Final output sent to browser
DEBUG - 2011-08-22 02:38:56 --> Total execution time: 3.8359
DEBUG - 2011-08-22 02:38:58 --> Config Class Initialized
DEBUG - 2011-08-22 02:38:58 --> Hooks Class Initialized
DEBUG - 2011-08-22 02:38:58 --> Utf8 Class Initialized
DEBUG - 2011-08-22 02:38:58 --> UTF-8 Support Enabled
DEBUG - 2011-08-22 02:38:58 --> URI Class Initialized
DEBUG - 2011-08-22 02:38:58 --> Router Class Initialized
ERROR - 2011-08-22 02:38:58 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-08-22 02:38:59 --> Config Class Initialized
DEBUG - 2011-08-22 02:38:59 --> Hooks Class Initialized
DEBUG - 2011-08-22 02:38:59 --> Utf8 Class Initialized
DEBUG - 2011-08-22 02:38:59 --> UTF-8 Support Enabled
DEBUG - 2011-08-22 02:38:59 --> URI Class Initialized
DEBUG - 2011-08-22 02:38:59 --> Router Class Initialized
DEBUG - 2011-08-22 02:38:59 --> Output Class Initialized
DEBUG - 2011-08-22 02:38:59 --> Input Class Initialized
DEBUG - 2011-08-22 02:38:59 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-22 02:38:59 --> Language Class Initialized
DEBUG - 2011-08-22 02:38:59 --> Loader Class Initialized
DEBUG - 2011-08-22 02:38:59 --> Controller Class Initialized
DEBUG - 2011-08-22 02:38:59 --> Model Class Initialized
DEBUG - 2011-08-22 02:38:59 --> Model Class Initialized
DEBUG - 2011-08-22 02:38:59 --> Model Class Initialized
DEBUG - 2011-08-22 02:38:59 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-22 02:38:59 --> Database Driver Class Initialized
DEBUG - 2011-08-22 02:38:59 --> File loaded: application/views/table/main.php
DEBUG - 2011-08-22 02:38:59 --> Helper loaded: url_helper
DEBUG - 2011-08-22 02:38:59 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-22 02:38:59 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-22 02:38:59 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-22 02:38:59 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-22 02:38:59 --> Final output sent to browser
DEBUG - 2011-08-22 02:38:59 --> Total execution time: 0.2022
DEBUG - 2011-08-22 02:39:19 --> Config Class Initialized
DEBUG - 2011-08-22 02:39:19 --> Hooks Class Initialized
DEBUG - 2011-08-22 02:39:19 --> Utf8 Class Initialized
DEBUG - 2011-08-22 02:39:19 --> UTF-8 Support Enabled
DEBUG - 2011-08-22 02:39:19 --> URI Class Initialized
DEBUG - 2011-08-22 02:39:19 --> Router Class Initialized
DEBUG - 2011-08-22 02:39:19 --> Output Class Initialized
DEBUG - 2011-08-22 02:39:19 --> Input Class Initialized
DEBUG - 2011-08-22 02:39:19 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-22 02:39:19 --> Language Class Initialized
DEBUG - 2011-08-22 02:39:19 --> Loader Class Initialized
DEBUG - 2011-08-22 02:39:19 --> Controller Class Initialized
DEBUG - 2011-08-22 02:39:19 --> Model Class Initialized
DEBUG - 2011-08-22 02:39:19 --> Model Class Initialized
DEBUG - 2011-08-22 02:39:19 --> Model Class Initialized
DEBUG - 2011-08-22 02:39:19 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-22 02:39:19 --> Database Driver Class Initialized
DEBUG - 2011-08-22 02:39:19 --> File loaded: application/views/table/main.php
DEBUG - 2011-08-22 02:39:19 --> Helper loaded: url_helper
DEBUG - 2011-08-22 02:39:19 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-22 02:39:19 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-22 02:39:19 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-22 02:39:19 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-22 02:39:19 --> Final output sent to browser
DEBUG - 2011-08-22 02:39:19 --> Total execution time: 0.0513
DEBUG - 2011-08-22 02:39:20 --> Config Class Initialized
DEBUG - 2011-08-22 02:39:20 --> Hooks Class Initialized
DEBUG - 2011-08-22 02:39:20 --> Utf8 Class Initialized
DEBUG - 2011-08-22 02:39:20 --> UTF-8 Support Enabled
DEBUG - 2011-08-22 02:39:20 --> URI Class Initialized
DEBUG - 2011-08-22 02:39:20 --> Router Class Initialized
DEBUG - 2011-08-22 02:39:20 --> Output Class Initialized
DEBUG - 2011-08-22 02:39:20 --> Input Class Initialized
DEBUG - 2011-08-22 02:39:20 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-22 02:39:20 --> Language Class Initialized
DEBUG - 2011-08-22 02:39:20 --> Loader Class Initialized
DEBUG - 2011-08-22 02:39:20 --> Controller Class Initialized
DEBUG - 2011-08-22 02:39:20 --> Model Class Initialized
DEBUG - 2011-08-22 02:39:20 --> Model Class Initialized
DEBUG - 2011-08-22 02:39:20 --> Model Class Initialized
DEBUG - 2011-08-22 02:39:20 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-22 02:39:20 --> Database Driver Class Initialized
DEBUG - 2011-08-22 02:39:20 --> File loaded: application/views/table/main.php
DEBUG - 2011-08-22 02:39:20 --> Helper loaded: url_helper
DEBUG - 2011-08-22 02:39:20 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-22 02:39:20 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-22 02:39:20 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-22 02:39:20 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-22 02:39:20 --> Final output sent to browser
DEBUG - 2011-08-22 02:39:20 --> Total execution time: 0.1569
DEBUG - 2011-08-22 02:39:20 --> Config Class Initialized
DEBUG - 2011-08-22 02:39:20 --> Hooks Class Initialized
DEBUG - 2011-08-22 02:39:20 --> Utf8 Class Initialized
DEBUG - 2011-08-22 02:39:20 --> UTF-8 Support Enabled
DEBUG - 2011-08-22 02:39:20 --> URI Class Initialized
DEBUG - 2011-08-22 02:39:20 --> Router Class Initialized
ERROR - 2011-08-22 02:39:20 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-08-22 02:39:33 --> Config Class Initialized
DEBUG - 2011-08-22 02:39:33 --> Hooks Class Initialized
DEBUG - 2011-08-22 02:39:33 --> Utf8 Class Initialized
DEBUG - 2011-08-22 02:39:33 --> UTF-8 Support Enabled
DEBUG - 2011-08-22 02:39:33 --> URI Class Initialized
DEBUG - 2011-08-22 02:39:33 --> Router Class Initialized
DEBUG - 2011-08-22 02:39:33 --> Output Class Initialized
DEBUG - 2011-08-22 02:39:33 --> Input Class Initialized
DEBUG - 2011-08-22 02:39:33 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-22 02:39:33 --> Language Class Initialized
DEBUG - 2011-08-22 02:39:33 --> Loader Class Initialized
DEBUG - 2011-08-22 02:39:33 --> Controller Class Initialized
DEBUG - 2011-08-22 02:39:33 --> Model Class Initialized
DEBUG - 2011-08-22 02:39:33 --> Model Class Initialized
DEBUG - 2011-08-22 02:39:33 --> Model Class Initialized
DEBUG - 2011-08-22 02:39:33 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-22 02:39:33 --> Database Driver Class Initialized
DEBUG - 2011-08-22 02:39:33 --> File loaded: application/views/table/main.php
DEBUG - 2011-08-22 02:39:33 --> Helper loaded: url_helper
DEBUG - 2011-08-22 02:39:33 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-22 02:39:33 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-22 02:39:33 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-22 02:39:33 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-22 02:39:33 --> Final output sent to browser
DEBUG - 2011-08-22 02:39:33 --> Total execution time: 0.0486
DEBUG - 2011-08-22 02:39:35 --> Config Class Initialized
DEBUG - 2011-08-22 02:39:35 --> Hooks Class Initialized
DEBUG - 2011-08-22 02:39:35 --> Utf8 Class Initialized
DEBUG - 2011-08-22 02:39:35 --> UTF-8 Support Enabled
DEBUG - 2011-08-22 02:39:35 --> URI Class Initialized
DEBUG - 2011-08-22 02:39:35 --> Router Class Initialized
ERROR - 2011-08-22 02:39:35 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-08-22 02:39:43 --> Config Class Initialized
DEBUG - 2011-08-22 02:39:43 --> Hooks Class Initialized
DEBUG - 2011-08-22 02:39:43 --> Utf8 Class Initialized
DEBUG - 2011-08-22 02:39:43 --> UTF-8 Support Enabled
DEBUG - 2011-08-22 02:39:43 --> URI Class Initialized
DEBUG - 2011-08-22 02:39:43 --> Router Class Initialized
DEBUG - 2011-08-22 02:39:43 --> Output Class Initialized
DEBUG - 2011-08-22 02:39:43 --> Input Class Initialized
DEBUG - 2011-08-22 02:39:43 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-22 02:39:43 --> Language Class Initialized
DEBUG - 2011-08-22 02:39:43 --> Loader Class Initialized
DEBUG - 2011-08-22 02:39:43 --> Controller Class Initialized
DEBUG - 2011-08-22 02:39:43 --> Model Class Initialized
DEBUG - 2011-08-22 02:39:43 --> Model Class Initialized
DEBUG - 2011-08-22 02:39:43 --> Model Class Initialized
DEBUG - 2011-08-22 02:39:43 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-22 02:39:43 --> Database Driver Class Initialized
DEBUG - 2011-08-22 02:39:45 --> File loaded: application/views/table/main.php
DEBUG - 2011-08-22 02:39:45 --> Helper loaded: url_helper
DEBUG - 2011-08-22 02:39:45 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-22 02:39:45 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-22 02:39:45 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-22 02:39:45 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-22 02:39:45 --> Final output sent to browser
DEBUG - 2011-08-22 02:39:45 --> Total execution time: 1.6737
DEBUG - 2011-08-22 02:39:46 --> Config Class Initialized
DEBUG - 2011-08-22 02:39:46 --> Hooks Class Initialized
DEBUG - 2011-08-22 02:39:46 --> Utf8 Class Initialized
DEBUG - 2011-08-22 02:39:46 --> UTF-8 Support Enabled
DEBUG - 2011-08-22 02:39:46 --> URI Class Initialized
DEBUG - 2011-08-22 02:39:46 --> Router Class Initialized
ERROR - 2011-08-22 02:39:46 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-08-22 02:39:50 --> Config Class Initialized
DEBUG - 2011-08-22 02:39:50 --> Hooks Class Initialized
DEBUG - 2011-08-22 02:39:50 --> Utf8 Class Initialized
DEBUG - 2011-08-22 02:39:50 --> UTF-8 Support Enabled
DEBUG - 2011-08-22 02:39:50 --> URI Class Initialized
DEBUG - 2011-08-22 02:39:50 --> Router Class Initialized
DEBUG - 2011-08-22 02:39:50 --> Output Class Initialized
DEBUG - 2011-08-22 02:39:50 --> Input Class Initialized
DEBUG - 2011-08-22 02:39:50 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-22 02:39:50 --> Language Class Initialized
DEBUG - 2011-08-22 02:39:50 --> Loader Class Initialized
DEBUG - 2011-08-22 02:39:50 --> Controller Class Initialized
DEBUG - 2011-08-22 02:39:50 --> Model Class Initialized
DEBUG - 2011-08-22 02:39:50 --> Model Class Initialized
DEBUG - 2011-08-22 02:39:50 --> Model Class Initialized
DEBUG - 2011-08-22 02:39:50 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-22 02:39:50 --> Database Driver Class Initialized
DEBUG - 2011-08-22 02:39:50 --> File loaded: application/views/table/main.php
DEBUG - 2011-08-22 02:39:50 --> Helper loaded: url_helper
DEBUG - 2011-08-22 02:39:50 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-22 02:39:50 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-22 02:39:50 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-22 02:39:50 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-22 02:39:50 --> Final output sent to browser
DEBUG - 2011-08-22 02:39:50 --> Total execution time: 0.1383
DEBUG - 2011-08-22 02:39:56 --> Config Class Initialized
DEBUG - 2011-08-22 02:39:56 --> Hooks Class Initialized
DEBUG - 2011-08-22 02:39:56 --> Utf8 Class Initialized
DEBUG - 2011-08-22 02:39:56 --> UTF-8 Support Enabled
DEBUG - 2011-08-22 02:39:56 --> URI Class Initialized
DEBUG - 2011-08-22 02:39:56 --> Router Class Initialized
DEBUG - 2011-08-22 02:39:56 --> Output Class Initialized
DEBUG - 2011-08-22 02:39:56 --> Input Class Initialized
DEBUG - 2011-08-22 02:39:56 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-22 02:39:56 --> Language Class Initialized
DEBUG - 2011-08-22 02:39:56 --> Loader Class Initialized
DEBUG - 2011-08-22 02:39:56 --> Controller Class Initialized
DEBUG - 2011-08-22 02:39:56 --> Model Class Initialized
DEBUG - 2011-08-22 02:39:56 --> Model Class Initialized
DEBUG - 2011-08-22 02:39:56 --> Model Class Initialized
DEBUG - 2011-08-22 02:39:56 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-22 02:39:56 --> Database Driver Class Initialized
DEBUG - 2011-08-22 02:39:57 --> File loaded: application/views/table/main.php
DEBUG - 2011-08-22 02:39:57 --> Helper loaded: url_helper
DEBUG - 2011-08-22 02:39:57 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-22 02:39:57 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-22 02:39:57 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-22 02:39:57 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-22 02:39:57 --> Final output sent to browser
DEBUG - 2011-08-22 02:39:57 --> Total execution time: 1.2201
DEBUG - 2011-08-22 02:39:59 --> Config Class Initialized
DEBUG - 2011-08-22 02:39:59 --> Hooks Class Initialized
DEBUG - 2011-08-22 02:39:59 --> Utf8 Class Initialized
DEBUG - 2011-08-22 02:39:59 --> UTF-8 Support Enabled
DEBUG - 2011-08-22 02:39:59 --> URI Class Initialized
DEBUG - 2011-08-22 02:39:59 --> Router Class Initialized
DEBUG - 2011-08-22 02:39:59 --> Output Class Initialized
DEBUG - 2011-08-22 02:39:59 --> Input Class Initialized
DEBUG - 2011-08-22 02:39:59 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-22 02:39:59 --> Language Class Initialized
DEBUG - 2011-08-22 02:39:59 --> Loader Class Initialized
DEBUG - 2011-08-22 02:39:59 --> Controller Class Initialized
DEBUG - 2011-08-22 02:39:59 --> Model Class Initialized
DEBUG - 2011-08-22 02:39:59 --> Model Class Initialized
DEBUG - 2011-08-22 02:39:59 --> Model Class Initialized
DEBUG - 2011-08-22 02:39:59 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-22 02:39:59 --> Config Class Initialized
DEBUG - 2011-08-22 02:39:59 --> Hooks Class Initialized
DEBUG - 2011-08-22 02:39:59 --> Utf8 Class Initialized
DEBUG - 2011-08-22 02:39:59 --> UTF-8 Support Enabled
DEBUG - 2011-08-22 02:39:59 --> URI Class Initialized
DEBUG - 2011-08-22 02:39:59 --> Router Class Initialized
ERROR - 2011-08-22 02:39:59 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-08-22 02:39:59 --> Database Driver Class Initialized
DEBUG - 2011-08-22 02:40:01 --> File loaded: application/views/table/main.php
DEBUG - 2011-08-22 02:40:01 --> Helper loaded: url_helper
DEBUG - 2011-08-22 02:40:01 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-22 02:40:01 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-22 02:40:01 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-22 02:40:01 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-22 02:40:01 --> Final output sent to browser
DEBUG - 2011-08-22 02:40:01 --> Total execution time: 2.6052
DEBUG - 2011-08-22 02:40:06 --> Config Class Initialized
DEBUG - 2011-08-22 02:40:06 --> Hooks Class Initialized
DEBUG - 2011-08-22 02:40:06 --> Utf8 Class Initialized
DEBUG - 2011-08-22 02:40:06 --> UTF-8 Support Enabled
DEBUG - 2011-08-22 02:40:06 --> URI Class Initialized
DEBUG - 2011-08-22 02:40:06 --> Router Class Initialized
DEBUG - 2011-08-22 02:40:06 --> Output Class Initialized
DEBUG - 2011-08-22 02:40:06 --> Input Class Initialized
DEBUG - 2011-08-22 02:40:06 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-22 02:40:06 --> Language Class Initialized
DEBUG - 2011-08-22 02:40:06 --> Loader Class Initialized
DEBUG - 2011-08-22 02:40:06 --> Controller Class Initialized
DEBUG - 2011-08-22 02:40:06 --> Model Class Initialized
DEBUG - 2011-08-22 02:40:06 --> Model Class Initialized
DEBUG - 2011-08-22 02:40:06 --> Model Class Initialized
DEBUG - 2011-08-22 02:40:06 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-22 02:40:06 --> Database Driver Class Initialized
DEBUG - 2011-08-22 02:40:09 --> File loaded: application/views/table/main.php
DEBUG - 2011-08-22 02:40:09 --> Helper loaded: url_helper
DEBUG - 2011-08-22 02:40:09 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-22 02:40:09 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-22 02:40:09 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-22 02:40:09 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-22 02:40:09 --> Final output sent to browser
DEBUG - 2011-08-22 02:40:09 --> Total execution time: 2.2187
DEBUG - 2011-08-22 02:40:09 --> Config Class Initialized
DEBUG - 2011-08-22 02:40:09 --> Hooks Class Initialized
DEBUG - 2011-08-22 02:40:09 --> Utf8 Class Initialized
DEBUG - 2011-08-22 02:40:09 --> UTF-8 Support Enabled
DEBUG - 2011-08-22 02:40:09 --> URI Class Initialized
DEBUG - 2011-08-22 02:40:09 --> Router Class Initialized
DEBUG - 2011-08-22 02:40:09 --> Output Class Initialized
DEBUG - 2011-08-22 02:40:09 --> Input Class Initialized
DEBUG - 2011-08-22 02:40:09 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-22 02:40:09 --> Language Class Initialized
DEBUG - 2011-08-22 02:40:09 --> Loader Class Initialized
DEBUG - 2011-08-22 02:40:09 --> Controller Class Initialized
DEBUG - 2011-08-22 02:40:09 --> Model Class Initialized
DEBUG - 2011-08-22 02:40:09 --> Model Class Initialized
DEBUG - 2011-08-22 02:40:09 --> Model Class Initialized
DEBUG - 2011-08-22 02:40:09 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-22 02:40:09 --> Database Driver Class Initialized
DEBUG - 2011-08-22 02:40:09 --> File loaded: application/views/table/main.php
DEBUG - 2011-08-22 02:40:09 --> Helper loaded: url_helper
DEBUG - 2011-08-22 02:40:09 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-22 02:40:09 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-22 02:40:09 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-22 02:40:09 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-22 02:40:09 --> Final output sent to browser
DEBUG - 2011-08-22 02:40:09 --> Total execution time: 0.0655
DEBUG - 2011-08-22 02:40:10 --> Config Class Initialized
DEBUG - 2011-08-22 02:40:10 --> Hooks Class Initialized
DEBUG - 2011-08-22 02:40:10 --> Utf8 Class Initialized
DEBUG - 2011-08-22 02:40:10 --> UTF-8 Support Enabled
DEBUG - 2011-08-22 02:40:10 --> URI Class Initialized
DEBUG - 2011-08-22 02:40:10 --> Router Class Initialized
ERROR - 2011-08-22 02:40:10 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-08-22 02:40:19 --> Config Class Initialized
DEBUG - 2011-08-22 02:40:19 --> Hooks Class Initialized
DEBUG - 2011-08-22 02:40:19 --> Utf8 Class Initialized
DEBUG - 2011-08-22 02:40:19 --> UTF-8 Support Enabled
DEBUG - 2011-08-22 02:40:19 --> URI Class Initialized
DEBUG - 2011-08-22 02:40:19 --> Router Class Initialized
DEBUG - 2011-08-22 02:40:19 --> Output Class Initialized
DEBUG - 2011-08-22 02:40:19 --> Input Class Initialized
DEBUG - 2011-08-22 02:40:19 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-22 02:40:19 --> Language Class Initialized
DEBUG - 2011-08-22 02:40:19 --> Loader Class Initialized
DEBUG - 2011-08-22 02:40:19 --> Controller Class Initialized
DEBUG - 2011-08-22 02:40:19 --> Model Class Initialized
DEBUG - 2011-08-22 02:40:19 --> Model Class Initialized
DEBUG - 2011-08-22 02:40:19 --> Model Class Initialized
DEBUG - 2011-08-22 02:40:19 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-22 02:40:19 --> Database Driver Class Initialized
DEBUG - 2011-08-22 02:40:21 --> File loaded: application/views/table/main.php
DEBUG - 2011-08-22 02:40:21 --> Helper loaded: url_helper
DEBUG - 2011-08-22 02:40:21 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-22 02:40:21 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-22 02:40:21 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-22 02:40:21 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-22 02:40:21 --> Final output sent to browser
DEBUG - 2011-08-22 02:40:21 --> Total execution time: 1.5645
DEBUG - 2011-08-22 02:40:22 --> Config Class Initialized
DEBUG - 2011-08-22 02:40:22 --> Hooks Class Initialized
DEBUG - 2011-08-22 02:40:22 --> Utf8 Class Initialized
DEBUG - 2011-08-22 02:40:22 --> UTF-8 Support Enabled
DEBUG - 2011-08-22 02:40:22 --> URI Class Initialized
DEBUG - 2011-08-22 02:40:22 --> Router Class Initialized
ERROR - 2011-08-22 02:40:22 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-08-22 02:40:23 --> Config Class Initialized
DEBUG - 2011-08-22 02:40:23 --> Hooks Class Initialized
DEBUG - 2011-08-22 02:40:23 --> Utf8 Class Initialized
DEBUG - 2011-08-22 02:40:23 --> UTF-8 Support Enabled
DEBUG - 2011-08-22 02:40:23 --> URI Class Initialized
DEBUG - 2011-08-22 02:40:23 --> Router Class Initialized
DEBUG - 2011-08-22 02:40:23 --> Output Class Initialized
DEBUG - 2011-08-22 02:40:23 --> Input Class Initialized
DEBUG - 2011-08-22 02:40:23 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-22 02:40:23 --> Language Class Initialized
DEBUG - 2011-08-22 02:40:23 --> Loader Class Initialized
DEBUG - 2011-08-22 02:40:23 --> Controller Class Initialized
DEBUG - 2011-08-22 02:40:23 --> Model Class Initialized
DEBUG - 2011-08-22 02:40:23 --> Model Class Initialized
DEBUG - 2011-08-22 02:40:23 --> Model Class Initialized
DEBUG - 2011-08-22 02:40:23 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-22 02:40:23 --> Database Driver Class Initialized
DEBUG - 2011-08-22 02:40:23 --> File loaded: application/views/table/main.php
DEBUG - 2011-08-22 02:40:23 --> Helper loaded: url_helper
DEBUG - 2011-08-22 02:40:23 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-22 02:40:23 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-22 02:40:23 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-22 02:40:23 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-22 02:40:23 --> Final output sent to browser
DEBUG - 2011-08-22 02:40:23 --> Total execution time: 0.0479
DEBUG - 2011-08-22 02:40:29 --> Config Class Initialized
DEBUG - 2011-08-22 02:40:29 --> Hooks Class Initialized
DEBUG - 2011-08-22 02:40:29 --> Utf8 Class Initialized
DEBUG - 2011-08-22 02:40:29 --> UTF-8 Support Enabled
DEBUG - 2011-08-22 02:40:29 --> URI Class Initialized
DEBUG - 2011-08-22 02:40:29 --> Router Class Initialized
DEBUG - 2011-08-22 02:40:29 --> Output Class Initialized
DEBUG - 2011-08-22 02:40:29 --> Input Class Initialized
DEBUG - 2011-08-22 02:40:29 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-22 02:40:29 --> Language Class Initialized
DEBUG - 2011-08-22 02:40:29 --> Loader Class Initialized
DEBUG - 2011-08-22 02:40:29 --> Controller Class Initialized
DEBUG - 2011-08-22 02:40:29 --> Model Class Initialized
DEBUG - 2011-08-22 02:40:29 --> Model Class Initialized
DEBUG - 2011-08-22 02:40:29 --> Model Class Initialized
DEBUG - 2011-08-22 02:40:29 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-22 02:40:29 --> Database Driver Class Initialized
DEBUG - 2011-08-22 02:40:30 --> File loaded: application/views/table/main.php
DEBUG - 2011-08-22 02:40:30 --> Helper loaded: url_helper
DEBUG - 2011-08-22 02:40:30 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-22 02:40:30 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-22 02:40:30 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-22 02:40:30 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-22 02:40:30 --> Final output sent to browser
DEBUG - 2011-08-22 02:40:30 --> Total execution time: 1.0953
DEBUG - 2011-08-22 02:40:31 --> Config Class Initialized
DEBUG - 2011-08-22 02:40:31 --> Hooks Class Initialized
DEBUG - 2011-08-22 02:40:31 --> Utf8 Class Initialized
DEBUG - 2011-08-22 02:40:31 --> UTF-8 Support Enabled
DEBUG - 2011-08-22 02:40:31 --> URI Class Initialized
DEBUG - 2011-08-22 02:40:31 --> Router Class Initialized
ERROR - 2011-08-22 02:40:31 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-08-22 02:40:32 --> Config Class Initialized
DEBUG - 2011-08-22 02:40:32 --> Hooks Class Initialized
DEBUG - 2011-08-22 02:40:32 --> Utf8 Class Initialized
DEBUG - 2011-08-22 02:40:32 --> UTF-8 Support Enabled
DEBUG - 2011-08-22 02:40:32 --> URI Class Initialized
DEBUG - 2011-08-22 02:40:32 --> Router Class Initialized
DEBUG - 2011-08-22 02:40:32 --> Output Class Initialized
DEBUG - 2011-08-22 02:40:32 --> Input Class Initialized
DEBUG - 2011-08-22 02:40:32 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-22 02:40:32 --> Language Class Initialized
DEBUG - 2011-08-22 02:40:32 --> Loader Class Initialized
DEBUG - 2011-08-22 02:40:32 --> Controller Class Initialized
DEBUG - 2011-08-22 02:40:32 --> Model Class Initialized
DEBUG - 2011-08-22 02:40:32 --> Model Class Initialized
DEBUG - 2011-08-22 02:40:32 --> Model Class Initialized
DEBUG - 2011-08-22 02:40:32 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-22 02:40:32 --> Database Driver Class Initialized
DEBUG - 2011-08-22 02:40:32 --> File loaded: application/views/table/main.php
DEBUG - 2011-08-22 02:40:32 --> Helper loaded: url_helper
DEBUG - 2011-08-22 02:40:32 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-22 02:40:32 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-22 02:40:32 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-22 02:40:32 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-22 02:40:32 --> Final output sent to browser
DEBUG - 2011-08-22 02:40:32 --> Total execution time: 0.1781
DEBUG - 2011-08-22 02:40:39 --> Config Class Initialized
DEBUG - 2011-08-22 02:40:39 --> Hooks Class Initialized
DEBUG - 2011-08-22 02:40:39 --> Utf8 Class Initialized
DEBUG - 2011-08-22 02:40:39 --> UTF-8 Support Enabled
DEBUG - 2011-08-22 02:40:39 --> URI Class Initialized
DEBUG - 2011-08-22 02:40:39 --> Router Class Initialized
DEBUG - 2011-08-22 02:40:39 --> Output Class Initialized
DEBUG - 2011-08-22 02:40:39 --> Input Class Initialized
DEBUG - 2011-08-22 02:40:39 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-22 02:40:39 --> Language Class Initialized
DEBUG - 2011-08-22 02:40:39 --> Loader Class Initialized
DEBUG - 2011-08-22 02:40:39 --> Controller Class Initialized
DEBUG - 2011-08-22 02:40:39 --> Model Class Initialized
DEBUG - 2011-08-22 02:40:39 --> Model Class Initialized
DEBUG - 2011-08-22 02:40:39 --> Model Class Initialized
DEBUG - 2011-08-22 02:40:39 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-22 02:40:39 --> Database Driver Class Initialized
DEBUG - 2011-08-22 02:40:41 --> File loaded: application/views/table/main.php
DEBUG - 2011-08-22 02:40:41 --> Helper loaded: url_helper
DEBUG - 2011-08-22 02:40:41 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-22 02:40:41 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-22 02:40:41 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-22 02:40:41 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-22 02:40:41 --> Final output sent to browser
DEBUG - 2011-08-22 02:40:41 --> Total execution time: 1.9822
DEBUG - 2011-08-22 02:40:42 --> Config Class Initialized
DEBUG - 2011-08-22 02:40:42 --> Hooks Class Initialized
DEBUG - 2011-08-22 02:40:42 --> Utf8 Class Initialized
DEBUG - 2011-08-22 02:40:42 --> UTF-8 Support Enabled
DEBUG - 2011-08-22 02:40:42 --> URI Class Initialized
DEBUG - 2011-08-22 02:40:42 --> Router Class Initialized
DEBUG - 2011-08-22 02:40:42 --> Output Class Initialized
DEBUG - 2011-08-22 02:40:42 --> Input Class Initialized
DEBUG - 2011-08-22 02:40:42 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-22 02:40:42 --> Language Class Initialized
DEBUG - 2011-08-22 02:40:42 --> Loader Class Initialized
DEBUG - 2011-08-22 02:40:42 --> Controller Class Initialized
DEBUG - 2011-08-22 02:40:42 --> Model Class Initialized
DEBUG - 2011-08-22 02:40:42 --> Model Class Initialized
DEBUG - 2011-08-22 02:40:42 --> Model Class Initialized
DEBUG - 2011-08-22 02:40:42 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-22 02:40:42 --> Database Driver Class Initialized
DEBUG - 2011-08-22 02:40:42 --> File loaded: application/views/table/main.php
DEBUG - 2011-08-22 02:40:42 --> Helper loaded: url_helper
DEBUG - 2011-08-22 02:40:42 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-22 02:40:42 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-22 02:40:42 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-22 02:40:42 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-22 02:40:42 --> Final output sent to browser
DEBUG - 2011-08-22 02:40:42 --> Total execution time: 0.1220
DEBUG - 2011-08-22 02:40:42 --> Config Class Initialized
DEBUG - 2011-08-22 02:40:42 --> Hooks Class Initialized
DEBUG - 2011-08-22 02:40:42 --> Utf8 Class Initialized
DEBUG - 2011-08-22 02:40:42 --> UTF-8 Support Enabled
DEBUG - 2011-08-22 02:40:42 --> URI Class Initialized
DEBUG - 2011-08-22 02:40:42 --> Router Class Initialized
ERROR - 2011-08-22 02:40:42 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-08-22 02:40:47 --> Config Class Initialized
DEBUG - 2011-08-22 02:40:47 --> Hooks Class Initialized
DEBUG - 2011-08-22 02:40:47 --> Utf8 Class Initialized
DEBUG - 2011-08-22 02:40:47 --> UTF-8 Support Enabled
DEBUG - 2011-08-22 02:40:47 --> URI Class Initialized
DEBUG - 2011-08-22 02:40:47 --> Router Class Initialized
DEBUG - 2011-08-22 02:40:47 --> Output Class Initialized
DEBUG - 2011-08-22 02:40:47 --> Input Class Initialized
DEBUG - 2011-08-22 02:40:47 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-22 02:40:47 --> Language Class Initialized
DEBUG - 2011-08-22 02:40:47 --> Loader Class Initialized
DEBUG - 2011-08-22 02:40:47 --> Controller Class Initialized
DEBUG - 2011-08-22 02:40:47 --> Model Class Initialized
DEBUG - 2011-08-22 02:40:47 --> Model Class Initialized
DEBUG - 2011-08-22 02:40:47 --> Model Class Initialized
DEBUG - 2011-08-22 02:40:47 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-22 02:40:47 --> Database Driver Class Initialized
DEBUG - 2011-08-22 02:40:49 --> File loaded: application/views/table/main.php
DEBUG - 2011-08-22 02:40:49 --> Helper loaded: url_helper
DEBUG - 2011-08-22 02:40:49 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-22 02:40:49 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-22 02:40:49 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-22 02:40:49 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-22 02:40:49 --> Final output sent to browser
DEBUG - 2011-08-22 02:40:49 --> Total execution time: 1.1454
DEBUG - 2011-08-22 02:40:50 --> Config Class Initialized
DEBUG - 2011-08-22 02:40:50 --> Hooks Class Initialized
DEBUG - 2011-08-22 02:40:50 --> Utf8 Class Initialized
DEBUG - 2011-08-22 02:40:50 --> UTF-8 Support Enabled
DEBUG - 2011-08-22 02:40:50 --> URI Class Initialized
DEBUG - 2011-08-22 02:40:50 --> Router Class Initialized
DEBUG - 2011-08-22 02:40:50 --> Output Class Initialized
DEBUG - 2011-08-22 02:40:50 --> Input Class Initialized
DEBUG - 2011-08-22 02:40:50 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-22 02:40:50 --> Language Class Initialized
DEBUG - 2011-08-22 02:40:50 --> Loader Class Initialized
DEBUG - 2011-08-22 02:40:50 --> Controller Class Initialized
DEBUG - 2011-08-22 02:40:50 --> Model Class Initialized
DEBUG - 2011-08-22 02:40:50 --> Model Class Initialized
DEBUG - 2011-08-22 02:40:50 --> Model Class Initialized
DEBUG - 2011-08-22 02:40:50 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-22 02:40:50 --> Config Class Initialized
DEBUG - 2011-08-22 02:40:50 --> Hooks Class Initialized
DEBUG - 2011-08-22 02:40:50 --> Utf8 Class Initialized
DEBUG - 2011-08-22 02:40:50 --> UTF-8 Support Enabled
DEBUG - 2011-08-22 02:40:50 --> URI Class Initialized
DEBUG - 2011-08-22 02:40:50 --> Router Class Initialized
ERROR - 2011-08-22 02:40:50 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-08-22 02:40:50 --> Database Driver Class Initialized
DEBUG - 2011-08-22 02:40:50 --> File loaded: application/views/table/main.php
DEBUG - 2011-08-22 02:40:50 --> Helper loaded: url_helper
DEBUG - 2011-08-22 02:40:50 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-22 02:40:50 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-22 02:40:50 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-22 02:40:50 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-22 02:40:50 --> Final output sent to browser
DEBUG - 2011-08-22 02:40:50 --> Total execution time: 0.0922
DEBUG - 2011-08-22 02:40:59 --> Config Class Initialized
DEBUG - 2011-08-22 02:40:59 --> Hooks Class Initialized
DEBUG - 2011-08-22 02:40:59 --> Utf8 Class Initialized
DEBUG - 2011-08-22 02:40:59 --> UTF-8 Support Enabled
DEBUG - 2011-08-22 02:40:59 --> URI Class Initialized
DEBUG - 2011-08-22 02:40:59 --> Router Class Initialized
DEBUG - 2011-08-22 02:40:59 --> Output Class Initialized
DEBUG - 2011-08-22 02:40:59 --> Input Class Initialized
DEBUG - 2011-08-22 02:40:59 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-22 02:40:59 --> Language Class Initialized
DEBUG - 2011-08-22 02:40:59 --> Loader Class Initialized
DEBUG - 2011-08-22 02:40:59 --> Controller Class Initialized
DEBUG - 2011-08-22 02:40:59 --> Model Class Initialized
DEBUG - 2011-08-22 02:40:59 --> Model Class Initialized
DEBUG - 2011-08-22 02:40:59 --> Model Class Initialized
DEBUG - 2011-08-22 02:40:59 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-22 02:40:59 --> Database Driver Class Initialized
DEBUG - 2011-08-22 02:41:00 --> File loaded: application/views/table/main.php
DEBUG - 2011-08-22 02:41:00 --> Helper loaded: url_helper
DEBUG - 2011-08-22 02:41:00 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-22 02:41:00 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-22 02:41:00 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-22 02:41:00 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-22 02:41:00 --> Final output sent to browser
DEBUG - 2011-08-22 02:41:00 --> Total execution time: 0.9963
DEBUG - 2011-08-22 02:41:01 --> Config Class Initialized
DEBUG - 2011-08-22 02:41:01 --> Hooks Class Initialized
DEBUG - 2011-08-22 02:41:01 --> Utf8 Class Initialized
DEBUG - 2011-08-22 02:41:01 --> UTF-8 Support Enabled
DEBUG - 2011-08-22 02:41:01 --> URI Class Initialized
DEBUG - 2011-08-22 02:41:01 --> Router Class Initialized
ERROR - 2011-08-22 02:41:01 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-08-22 02:41:02 --> Config Class Initialized
DEBUG - 2011-08-22 02:41:02 --> Hooks Class Initialized
DEBUG - 2011-08-22 02:41:02 --> Utf8 Class Initialized
DEBUG - 2011-08-22 02:41:02 --> UTF-8 Support Enabled
DEBUG - 2011-08-22 02:41:02 --> URI Class Initialized
DEBUG - 2011-08-22 02:41:02 --> Router Class Initialized
DEBUG - 2011-08-22 02:41:02 --> Output Class Initialized
DEBUG - 2011-08-22 02:41:02 --> Input Class Initialized
DEBUG - 2011-08-22 02:41:02 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-22 02:41:02 --> Language Class Initialized
DEBUG - 2011-08-22 02:41:02 --> Loader Class Initialized
DEBUG - 2011-08-22 02:41:02 --> Controller Class Initialized
DEBUG - 2011-08-22 02:41:02 --> Model Class Initialized
DEBUG - 2011-08-22 02:41:02 --> Model Class Initialized
DEBUG - 2011-08-22 02:41:02 --> Model Class Initialized
DEBUG - 2011-08-22 02:41:02 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-22 02:41:02 --> Database Driver Class Initialized
DEBUG - 2011-08-22 02:41:02 --> File loaded: application/views/table/main.php
DEBUG - 2011-08-22 02:41:02 --> Helper loaded: url_helper
DEBUG - 2011-08-22 02:41:02 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-22 02:41:02 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-22 02:41:02 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-22 02:41:02 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-22 02:41:02 --> Final output sent to browser
DEBUG - 2011-08-22 02:41:02 --> Total execution time: 0.0523
DEBUG - 2011-08-22 02:41:12 --> Config Class Initialized
DEBUG - 2011-08-22 02:41:12 --> Hooks Class Initialized
DEBUG - 2011-08-22 02:41:12 --> Utf8 Class Initialized
DEBUG - 2011-08-22 02:41:12 --> UTF-8 Support Enabled
DEBUG - 2011-08-22 02:41:12 --> URI Class Initialized
DEBUG - 2011-08-22 02:41:12 --> Router Class Initialized
DEBUG - 2011-08-22 02:41:12 --> Output Class Initialized
DEBUG - 2011-08-22 02:41:12 --> Input Class Initialized
DEBUG - 2011-08-22 02:41:12 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-22 02:41:12 --> Language Class Initialized
DEBUG - 2011-08-22 02:41:12 --> Loader Class Initialized
DEBUG - 2011-08-22 02:41:12 --> Controller Class Initialized
DEBUG - 2011-08-22 02:41:12 --> Model Class Initialized
DEBUG - 2011-08-22 02:41:12 --> Model Class Initialized
DEBUG - 2011-08-22 02:41:12 --> Model Class Initialized
DEBUG - 2011-08-22 02:41:12 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-22 02:41:12 --> Database Driver Class Initialized
DEBUG - 2011-08-22 02:41:12 --> File loaded: application/views/table/main.php
DEBUG - 2011-08-22 02:41:12 --> Helper loaded: url_helper
DEBUG - 2011-08-22 02:41:12 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-22 02:41:12 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-22 02:41:12 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-22 02:41:12 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-22 02:41:12 --> Final output sent to browser
DEBUG - 2011-08-22 02:41:12 --> Total execution time: 0.6046
DEBUG - 2011-08-22 02:41:13 --> Config Class Initialized
DEBUG - 2011-08-22 02:41:13 --> Hooks Class Initialized
DEBUG - 2011-08-22 02:41:13 --> Utf8 Class Initialized
DEBUG - 2011-08-22 02:41:13 --> UTF-8 Support Enabled
DEBUG - 2011-08-22 02:41:13 --> URI Class Initialized
DEBUG - 2011-08-22 02:41:13 --> Router Class Initialized
DEBUG - 2011-08-22 02:41:13 --> Output Class Initialized
DEBUG - 2011-08-22 02:41:13 --> Input Class Initialized
DEBUG - 2011-08-22 02:41:13 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-22 02:41:13 --> Language Class Initialized
DEBUG - 2011-08-22 02:41:13 --> Loader Class Initialized
DEBUG - 2011-08-22 02:41:13 --> Controller Class Initialized
DEBUG - 2011-08-22 02:41:13 --> Model Class Initialized
DEBUG - 2011-08-22 02:41:13 --> Model Class Initialized
DEBUG - 2011-08-22 02:41:13 --> Model Class Initialized
DEBUG - 2011-08-22 02:41:13 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-22 02:41:13 --> Database Driver Class Initialized
DEBUG - 2011-08-22 02:41:13 --> File loaded: application/views/table/main.php
DEBUG - 2011-08-22 02:41:13 --> Helper loaded: url_helper
DEBUG - 2011-08-22 02:41:13 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-22 02:41:13 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-22 02:41:13 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-22 02:41:13 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-22 02:41:13 --> Final output sent to browser
DEBUG - 2011-08-22 02:41:13 --> Total execution time: 0.0521
DEBUG - 2011-08-22 02:41:13 --> Config Class Initialized
DEBUG - 2011-08-22 02:41:13 --> Hooks Class Initialized
DEBUG - 2011-08-22 02:41:13 --> Utf8 Class Initialized
DEBUG - 2011-08-22 02:41:13 --> UTF-8 Support Enabled
DEBUG - 2011-08-22 02:41:13 --> URI Class Initialized
DEBUG - 2011-08-22 02:41:13 --> Router Class Initialized
ERROR - 2011-08-22 02:41:13 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-08-22 02:41:23 --> Config Class Initialized
DEBUG - 2011-08-22 02:41:23 --> Hooks Class Initialized
DEBUG - 2011-08-22 02:41:23 --> Utf8 Class Initialized
DEBUG - 2011-08-22 02:41:23 --> UTF-8 Support Enabled
DEBUG - 2011-08-22 02:41:23 --> URI Class Initialized
DEBUG - 2011-08-22 02:41:23 --> Router Class Initialized
DEBUG - 2011-08-22 02:41:23 --> Output Class Initialized
DEBUG - 2011-08-22 02:41:23 --> Input Class Initialized
DEBUG - 2011-08-22 02:41:23 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-22 02:41:23 --> Language Class Initialized
DEBUG - 2011-08-22 02:41:23 --> Loader Class Initialized
DEBUG - 2011-08-22 02:41:23 --> Controller Class Initialized
DEBUG - 2011-08-22 02:41:23 --> Model Class Initialized
DEBUG - 2011-08-22 02:41:23 --> Model Class Initialized
DEBUG - 2011-08-22 02:41:23 --> Model Class Initialized
DEBUG - 2011-08-22 02:41:23 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-22 02:41:23 --> Database Driver Class Initialized
DEBUG - 2011-08-22 02:41:24 --> File loaded: application/views/table/main.php
DEBUG - 2011-08-22 02:41:24 --> Helper loaded: url_helper
DEBUG - 2011-08-22 02:41:24 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-22 02:41:24 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-22 02:41:24 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-22 02:41:24 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-22 02:41:24 --> Final output sent to browser
DEBUG - 2011-08-22 02:41:24 --> Total execution time: 0.7783
DEBUG - 2011-08-22 02:41:24 --> Config Class Initialized
DEBUG - 2011-08-22 02:41:24 --> Hooks Class Initialized
DEBUG - 2011-08-22 02:41:24 --> Utf8 Class Initialized
DEBUG - 2011-08-22 02:41:24 --> UTF-8 Support Enabled
DEBUG - 2011-08-22 02:41:24 --> URI Class Initialized
DEBUG - 2011-08-22 02:41:24 --> Router Class Initialized
DEBUG - 2011-08-22 02:41:24 --> Output Class Initialized
DEBUG - 2011-08-22 02:41:24 --> Input Class Initialized
DEBUG - 2011-08-22 02:41:24 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-22 02:41:24 --> Language Class Initialized
DEBUG - 2011-08-22 02:41:24 --> Loader Class Initialized
DEBUG - 2011-08-22 02:41:24 --> Controller Class Initialized
DEBUG - 2011-08-22 02:41:24 --> Model Class Initialized
DEBUG - 2011-08-22 02:41:24 --> Model Class Initialized
DEBUG - 2011-08-22 02:41:24 --> Model Class Initialized
DEBUG - 2011-08-22 02:41:24 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-22 02:41:24 --> Database Driver Class Initialized
DEBUG - 2011-08-22 02:41:24 --> File loaded: application/views/table/main.php
DEBUG - 2011-08-22 02:41:24 --> Helper loaded: url_helper
DEBUG - 2011-08-22 02:41:24 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-22 02:41:24 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-22 02:41:24 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-22 02:41:24 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-22 02:41:24 --> Final output sent to browser
DEBUG - 2011-08-22 02:41:24 --> Total execution time: 0.0514
DEBUG - 2011-08-22 02:41:25 --> Config Class Initialized
DEBUG - 2011-08-22 02:41:25 --> Hooks Class Initialized
DEBUG - 2011-08-22 02:41:25 --> Utf8 Class Initialized
DEBUG - 2011-08-22 02:41:25 --> UTF-8 Support Enabled
DEBUG - 2011-08-22 02:41:25 --> URI Class Initialized
DEBUG - 2011-08-22 02:41:25 --> Router Class Initialized
ERROR - 2011-08-22 02:41:25 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-08-22 02:41:41 --> Config Class Initialized
DEBUG - 2011-08-22 02:41:41 --> Hooks Class Initialized
DEBUG - 2011-08-22 02:41:41 --> Utf8 Class Initialized
DEBUG - 2011-08-22 02:41:41 --> UTF-8 Support Enabled
DEBUG - 2011-08-22 02:41:41 --> URI Class Initialized
DEBUG - 2011-08-22 02:41:41 --> Router Class Initialized
DEBUG - 2011-08-22 02:41:41 --> Output Class Initialized
DEBUG - 2011-08-22 02:41:41 --> Input Class Initialized
DEBUG - 2011-08-22 02:41:41 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-22 02:41:41 --> Language Class Initialized
DEBUG - 2011-08-22 02:41:41 --> Loader Class Initialized
DEBUG - 2011-08-22 02:41:41 --> Controller Class Initialized
DEBUG - 2011-08-22 02:41:41 --> Model Class Initialized
DEBUG - 2011-08-22 02:41:41 --> Model Class Initialized
DEBUG - 2011-08-22 02:41:41 --> Model Class Initialized
DEBUG - 2011-08-22 02:41:41 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-22 02:41:41 --> Database Driver Class Initialized
DEBUG - 2011-08-22 02:41:41 --> File loaded: application/views/table/main.php
DEBUG - 2011-08-22 02:41:41 --> Helper loaded: url_helper
DEBUG - 2011-08-22 02:41:41 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-22 02:41:41 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-22 02:41:41 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-22 02:41:41 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-22 02:41:41 --> Final output sent to browser
DEBUG - 2011-08-22 02:41:41 --> Total execution time: 0.0508
DEBUG - 2011-08-22 02:41:42 --> Config Class Initialized
DEBUG - 2011-08-22 02:41:42 --> Hooks Class Initialized
DEBUG - 2011-08-22 02:41:42 --> Utf8 Class Initialized
DEBUG - 2011-08-22 02:41:42 --> UTF-8 Support Enabled
DEBUG - 2011-08-22 02:41:42 --> URI Class Initialized
DEBUG - 2011-08-22 02:41:42 --> Router Class Initialized
ERROR - 2011-08-22 02:41:42 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-08-22 02:41:50 --> Config Class Initialized
DEBUG - 2011-08-22 02:41:50 --> Hooks Class Initialized
DEBUG - 2011-08-22 02:41:50 --> Utf8 Class Initialized
DEBUG - 2011-08-22 02:41:50 --> UTF-8 Support Enabled
DEBUG - 2011-08-22 02:41:50 --> URI Class Initialized
DEBUG - 2011-08-22 02:41:50 --> Router Class Initialized
DEBUG - 2011-08-22 02:41:50 --> Output Class Initialized
DEBUG - 2011-08-22 02:41:50 --> Input Class Initialized
DEBUG - 2011-08-22 02:41:50 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-22 02:41:50 --> Language Class Initialized
DEBUG - 2011-08-22 02:41:50 --> Loader Class Initialized
DEBUG - 2011-08-22 02:41:50 --> Controller Class Initialized
DEBUG - 2011-08-22 02:41:50 --> Model Class Initialized
DEBUG - 2011-08-22 02:41:50 --> Model Class Initialized
DEBUG - 2011-08-22 02:41:50 --> Model Class Initialized
DEBUG - 2011-08-22 02:41:50 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-22 02:41:50 --> Database Driver Class Initialized
DEBUG - 2011-08-22 02:41:50 --> File loaded: application/views/table/main.php
DEBUG - 2011-08-22 02:41:50 --> Helper loaded: url_helper
DEBUG - 2011-08-22 02:41:50 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-22 02:41:50 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-22 02:41:50 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-22 02:41:50 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-22 02:41:50 --> Final output sent to browser
DEBUG - 2011-08-22 02:41:50 --> Total execution time: 0.0799
DEBUG - 2011-08-22 02:41:51 --> Config Class Initialized
DEBUG - 2011-08-22 02:41:51 --> Hooks Class Initialized
DEBUG - 2011-08-22 02:41:51 --> Utf8 Class Initialized
DEBUG - 2011-08-22 02:41:51 --> UTF-8 Support Enabled
DEBUG - 2011-08-22 02:41:51 --> URI Class Initialized
DEBUG - 2011-08-22 02:41:51 --> Router Class Initialized
ERROR - 2011-08-22 02:41:51 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-08-22 02:41:59 --> Config Class Initialized
DEBUG - 2011-08-22 02:41:59 --> Hooks Class Initialized
DEBUG - 2011-08-22 02:41:59 --> Utf8 Class Initialized
DEBUG - 2011-08-22 02:41:59 --> UTF-8 Support Enabled
DEBUG - 2011-08-22 02:41:59 --> URI Class Initialized
DEBUG - 2011-08-22 02:41:59 --> Router Class Initialized
DEBUG - 2011-08-22 02:41:59 --> Output Class Initialized
DEBUG - 2011-08-22 02:41:59 --> Input Class Initialized
DEBUG - 2011-08-22 02:41:59 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-22 02:41:59 --> Language Class Initialized
DEBUG - 2011-08-22 02:41:59 --> Loader Class Initialized
DEBUG - 2011-08-22 02:41:59 --> Controller Class Initialized
DEBUG - 2011-08-22 02:41:59 --> Model Class Initialized
DEBUG - 2011-08-22 02:41:59 --> Model Class Initialized
DEBUG - 2011-08-22 02:41:59 --> Model Class Initialized
DEBUG - 2011-08-22 02:41:59 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-22 02:41:59 --> Database Driver Class Initialized
DEBUG - 2011-08-22 02:41:59 --> File loaded: application/views/table/main.php
DEBUG - 2011-08-22 02:41:59 --> Helper loaded: url_helper
DEBUG - 2011-08-22 02:41:59 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-22 02:41:59 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-22 02:41:59 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-22 02:41:59 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-22 02:41:59 --> Final output sent to browser
DEBUG - 2011-08-22 02:41:59 --> Total execution time: 0.1419
DEBUG - 2011-08-22 02:42:00 --> Config Class Initialized
DEBUG - 2011-08-22 02:42:00 --> Hooks Class Initialized
DEBUG - 2011-08-22 02:42:00 --> Utf8 Class Initialized
DEBUG - 2011-08-22 02:42:00 --> UTF-8 Support Enabled
DEBUG - 2011-08-22 02:42:00 --> URI Class Initialized
DEBUG - 2011-08-22 02:42:00 --> Router Class Initialized
ERROR - 2011-08-22 02:42:00 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-08-22 02:42:08 --> Config Class Initialized
DEBUG - 2011-08-22 02:42:08 --> Hooks Class Initialized
DEBUG - 2011-08-22 02:42:08 --> Utf8 Class Initialized
DEBUG - 2011-08-22 02:42:08 --> UTF-8 Support Enabled
DEBUG - 2011-08-22 02:42:08 --> URI Class Initialized
DEBUG - 2011-08-22 02:42:08 --> Router Class Initialized
DEBUG - 2011-08-22 02:42:08 --> Output Class Initialized
DEBUG - 2011-08-22 02:42:08 --> Input Class Initialized
DEBUG - 2011-08-22 02:42:08 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-22 02:42:08 --> Language Class Initialized
DEBUG - 2011-08-22 02:42:08 --> Loader Class Initialized
DEBUG - 2011-08-22 02:42:08 --> Controller Class Initialized
DEBUG - 2011-08-22 02:42:08 --> Model Class Initialized
DEBUG - 2011-08-22 02:42:08 --> Model Class Initialized
DEBUG - 2011-08-22 02:42:08 --> Model Class Initialized
DEBUG - 2011-08-22 02:42:08 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-22 02:42:08 --> Database Driver Class Initialized
DEBUG - 2011-08-22 02:42:10 --> File loaded: application/views/table/main.php
DEBUG - 2011-08-22 02:42:10 --> Helper loaded: url_helper
DEBUG - 2011-08-22 02:42:10 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-22 02:42:10 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-22 02:42:10 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-22 02:42:10 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-22 02:42:10 --> Final output sent to browser
DEBUG - 2011-08-22 02:42:10 --> Total execution time: 1.4185
DEBUG - 2011-08-22 02:42:11 --> Config Class Initialized
DEBUG - 2011-08-22 02:42:11 --> Hooks Class Initialized
DEBUG - 2011-08-22 02:42:11 --> Utf8 Class Initialized
DEBUG - 2011-08-22 02:42:11 --> UTF-8 Support Enabled
DEBUG - 2011-08-22 02:42:11 --> URI Class Initialized
DEBUG - 2011-08-22 02:42:11 --> Router Class Initialized
ERROR - 2011-08-22 02:42:11 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-08-22 02:42:11 --> Config Class Initialized
DEBUG - 2011-08-22 02:42:11 --> Hooks Class Initialized
DEBUG - 2011-08-22 02:42:11 --> Utf8 Class Initialized
DEBUG - 2011-08-22 02:42:11 --> UTF-8 Support Enabled
DEBUG - 2011-08-22 02:42:11 --> URI Class Initialized
DEBUG - 2011-08-22 02:42:11 --> Router Class Initialized
DEBUG - 2011-08-22 02:42:11 --> Output Class Initialized
DEBUG - 2011-08-22 02:42:11 --> Input Class Initialized
DEBUG - 2011-08-22 02:42:11 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-22 02:42:11 --> Language Class Initialized
DEBUG - 2011-08-22 02:42:11 --> Loader Class Initialized
DEBUG - 2011-08-22 02:42:11 --> Controller Class Initialized
DEBUG - 2011-08-22 02:42:11 --> Model Class Initialized
DEBUG - 2011-08-22 02:42:11 --> Model Class Initialized
DEBUG - 2011-08-22 02:42:11 --> Model Class Initialized
DEBUG - 2011-08-22 02:42:11 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-22 02:42:11 --> Database Driver Class Initialized
DEBUG - 2011-08-22 02:42:12 --> File loaded: application/views/table/main.php
DEBUG - 2011-08-22 02:42:12 --> Helper loaded: url_helper
DEBUG - 2011-08-22 02:42:12 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-22 02:42:12 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-22 02:42:12 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-22 02:42:12 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-22 02:42:12 --> Final output sent to browser
DEBUG - 2011-08-22 02:42:12 --> Total execution time: 0.1016
DEBUG - 2011-08-22 02:42:24 --> Config Class Initialized
DEBUG - 2011-08-22 02:42:24 --> Hooks Class Initialized
DEBUG - 2011-08-22 02:42:24 --> Utf8 Class Initialized
DEBUG - 2011-08-22 02:42:24 --> UTF-8 Support Enabled
DEBUG - 2011-08-22 02:42:24 --> URI Class Initialized
DEBUG - 2011-08-22 02:42:24 --> Router Class Initialized
DEBUG - 2011-08-22 02:42:24 --> Output Class Initialized
DEBUG - 2011-08-22 02:42:24 --> Input Class Initialized
DEBUG - 2011-08-22 02:42:24 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-22 02:42:24 --> Language Class Initialized
DEBUG - 2011-08-22 02:42:24 --> Loader Class Initialized
DEBUG - 2011-08-22 02:42:24 --> Controller Class Initialized
DEBUG - 2011-08-22 02:42:24 --> Model Class Initialized
DEBUG - 2011-08-22 02:42:24 --> Model Class Initialized
DEBUG - 2011-08-22 02:42:24 --> Model Class Initialized
DEBUG - 2011-08-22 02:42:24 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-22 02:42:24 --> Database Driver Class Initialized
DEBUG - 2011-08-22 02:42:24 --> File loaded: application/views/table/main.php
DEBUG - 2011-08-22 02:42:24 --> Helper loaded: url_helper
DEBUG - 2011-08-22 02:42:24 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-22 02:42:24 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-22 02:42:24 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-22 02:42:24 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-22 02:42:24 --> Final output sent to browser
DEBUG - 2011-08-22 02:42:24 --> Total execution time: 0.0559
DEBUG - 2011-08-22 02:42:26 --> Config Class Initialized
DEBUG - 2011-08-22 02:42:26 --> Hooks Class Initialized
DEBUG - 2011-08-22 02:42:26 --> Utf8 Class Initialized
DEBUG - 2011-08-22 02:42:26 --> UTF-8 Support Enabled
DEBUG - 2011-08-22 02:42:26 --> URI Class Initialized
DEBUG - 2011-08-22 02:42:26 --> Router Class Initialized
ERROR - 2011-08-22 02:42:26 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-08-22 02:42:38 --> Config Class Initialized
DEBUG - 2011-08-22 02:42:38 --> Hooks Class Initialized
DEBUG - 2011-08-22 02:42:38 --> Utf8 Class Initialized
DEBUG - 2011-08-22 02:42:38 --> UTF-8 Support Enabled
DEBUG - 2011-08-22 02:42:38 --> URI Class Initialized
DEBUG - 2011-08-22 02:42:38 --> Router Class Initialized
DEBUG - 2011-08-22 02:42:38 --> Output Class Initialized
DEBUG - 2011-08-22 02:42:38 --> Input Class Initialized
DEBUG - 2011-08-22 02:42:38 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-22 02:42:38 --> Language Class Initialized
DEBUG - 2011-08-22 02:42:38 --> Loader Class Initialized
DEBUG - 2011-08-22 02:42:38 --> Controller Class Initialized
DEBUG - 2011-08-22 02:42:38 --> Model Class Initialized
DEBUG - 2011-08-22 02:42:38 --> Model Class Initialized
DEBUG - 2011-08-22 02:42:38 --> Model Class Initialized
DEBUG - 2011-08-22 02:42:38 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-22 02:42:38 --> Database Driver Class Initialized
DEBUG - 2011-08-22 02:42:38 --> File loaded: application/views/table/main.php
DEBUG - 2011-08-22 02:42:38 --> Helper loaded: url_helper
DEBUG - 2011-08-22 02:42:38 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-22 02:42:38 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-22 02:42:38 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-22 02:42:38 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-22 02:42:38 --> Final output sent to browser
DEBUG - 2011-08-22 02:42:38 --> Total execution time: 0.0604
DEBUG - 2011-08-22 02:42:39 --> Config Class Initialized
DEBUG - 2011-08-22 02:42:39 --> Hooks Class Initialized
DEBUG - 2011-08-22 02:42:39 --> Utf8 Class Initialized
DEBUG - 2011-08-22 02:42:39 --> UTF-8 Support Enabled
DEBUG - 2011-08-22 02:42:39 --> URI Class Initialized
DEBUG - 2011-08-22 02:42:39 --> Router Class Initialized
ERROR - 2011-08-22 02:42:39 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-08-22 02:50:29 --> Config Class Initialized
DEBUG - 2011-08-22 02:50:29 --> Hooks Class Initialized
DEBUG - 2011-08-22 02:50:29 --> Utf8 Class Initialized
DEBUG - 2011-08-22 02:50:29 --> UTF-8 Support Enabled
DEBUG - 2011-08-22 02:50:29 --> URI Class Initialized
DEBUG - 2011-08-22 02:50:29 --> Router Class Initialized
DEBUG - 2011-08-22 02:50:29 --> Output Class Initialized
DEBUG - 2011-08-22 02:50:29 --> Input Class Initialized
DEBUG - 2011-08-22 02:50:29 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-22 02:50:29 --> Language Class Initialized
DEBUG - 2011-08-22 02:50:29 --> Loader Class Initialized
DEBUG - 2011-08-22 02:50:29 --> Controller Class Initialized
ERROR - 2011-08-22 02:50:29 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-08-22 02:50:29 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-08-22 02:50:29 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-08-22 02:50:29 --> Model Class Initialized
DEBUG - 2011-08-22 02:50:29 --> Model Class Initialized
DEBUG - 2011-08-22 02:50:29 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-22 02:50:30 --> Database Driver Class Initialized
DEBUG - 2011-08-22 02:50:30 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-08-22 02:50:30 --> Helper loaded: url_helper
DEBUG - 2011-08-22 02:50:30 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-22 02:50:30 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-22 02:50:30 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-22 02:50:30 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-22 02:50:30 --> Final output sent to browser
DEBUG - 2011-08-22 02:50:30 --> Total execution time: 0.0990
DEBUG - 2011-08-22 02:50:31 --> Config Class Initialized
DEBUG - 2011-08-22 02:50:31 --> Hooks Class Initialized
DEBUG - 2011-08-22 02:50:31 --> Utf8 Class Initialized
DEBUG - 2011-08-22 02:50:31 --> UTF-8 Support Enabled
DEBUG - 2011-08-22 02:50:31 --> URI Class Initialized
DEBUG - 2011-08-22 02:50:31 --> Router Class Initialized
DEBUG - 2011-08-22 02:50:31 --> Output Class Initialized
DEBUG - 2011-08-22 02:50:31 --> Input Class Initialized
DEBUG - 2011-08-22 02:50:31 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-22 02:50:31 --> Language Class Initialized
DEBUG - 2011-08-22 02:50:31 --> Loader Class Initialized
DEBUG - 2011-08-22 02:50:31 --> Controller Class Initialized
DEBUG - 2011-08-22 02:50:31 --> Model Class Initialized
DEBUG - 2011-08-22 02:50:31 --> Model Class Initialized
DEBUG - 2011-08-22 02:50:31 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-22 02:50:31 --> Database Driver Class Initialized
DEBUG - 2011-08-22 02:50:32 --> Final output sent to browser
DEBUG - 2011-08-22 02:50:32 --> Total execution time: 1.6276
DEBUG - 2011-08-22 02:50:34 --> Config Class Initialized
DEBUG - 2011-08-22 02:50:34 --> Hooks Class Initialized
DEBUG - 2011-08-22 02:50:34 --> Utf8 Class Initialized
DEBUG - 2011-08-22 02:50:34 --> UTF-8 Support Enabled
DEBUG - 2011-08-22 02:50:34 --> URI Class Initialized
DEBUG - 2011-08-22 02:50:34 --> Router Class Initialized
ERROR - 2011-08-22 02:50:34 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-08-22 02:51:56 --> Config Class Initialized
DEBUG - 2011-08-22 02:51:56 --> Hooks Class Initialized
DEBUG - 2011-08-22 02:51:56 --> Utf8 Class Initialized
DEBUG - 2011-08-22 02:51:56 --> UTF-8 Support Enabled
DEBUG - 2011-08-22 02:51:56 --> URI Class Initialized
DEBUG - 2011-08-22 02:51:56 --> Router Class Initialized
DEBUG - 2011-08-22 02:51:56 --> Output Class Initialized
DEBUG - 2011-08-22 02:51:56 --> Input Class Initialized
DEBUG - 2011-08-22 02:51:56 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-22 02:51:56 --> Language Class Initialized
DEBUG - 2011-08-22 02:51:56 --> Loader Class Initialized
DEBUG - 2011-08-22 02:51:56 --> Controller Class Initialized
ERROR - 2011-08-22 02:51:56 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-08-22 02:51:56 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-08-22 02:51:56 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-08-22 02:51:56 --> Model Class Initialized
DEBUG - 2011-08-22 02:51:56 --> Model Class Initialized
DEBUG - 2011-08-22 02:51:56 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-22 02:51:56 --> Database Driver Class Initialized
DEBUG - 2011-08-22 02:51:56 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-08-22 02:51:56 --> Helper loaded: url_helper
DEBUG - 2011-08-22 02:51:56 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-22 02:51:56 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-22 02:51:56 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-22 02:51:56 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-22 02:51:56 --> Final output sent to browser
DEBUG - 2011-08-22 02:51:56 --> Total execution time: 0.0473
DEBUG - 2011-08-22 02:51:57 --> Config Class Initialized
DEBUG - 2011-08-22 02:51:57 --> Hooks Class Initialized
DEBUG - 2011-08-22 02:51:57 --> Utf8 Class Initialized
DEBUG - 2011-08-22 02:51:57 --> UTF-8 Support Enabled
DEBUG - 2011-08-22 02:51:57 --> URI Class Initialized
DEBUG - 2011-08-22 02:51:57 --> Router Class Initialized
DEBUG - 2011-08-22 02:51:57 --> Output Class Initialized
DEBUG - 2011-08-22 02:51:57 --> Input Class Initialized
DEBUG - 2011-08-22 02:51:57 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-22 02:51:57 --> Language Class Initialized
DEBUG - 2011-08-22 02:51:57 --> Loader Class Initialized
DEBUG - 2011-08-22 02:51:57 --> Controller Class Initialized
DEBUG - 2011-08-22 02:51:57 --> Model Class Initialized
DEBUG - 2011-08-22 02:51:57 --> Model Class Initialized
DEBUG - 2011-08-22 02:51:57 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-22 02:51:57 --> Database Driver Class Initialized
DEBUG - 2011-08-22 02:51:57 --> Final output sent to browser
DEBUG - 2011-08-22 02:51:57 --> Total execution time: 0.6391
DEBUG - 2011-08-22 02:52:04 --> Config Class Initialized
DEBUG - 2011-08-22 02:52:04 --> Hooks Class Initialized
DEBUG - 2011-08-22 02:52:04 --> Utf8 Class Initialized
DEBUG - 2011-08-22 02:52:04 --> UTF-8 Support Enabled
DEBUG - 2011-08-22 02:52:04 --> URI Class Initialized
DEBUG - 2011-08-22 02:52:04 --> Router Class Initialized
DEBUG - 2011-08-22 02:52:04 --> Output Class Initialized
DEBUG - 2011-08-22 02:52:04 --> Input Class Initialized
DEBUG - 2011-08-22 02:52:04 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-22 02:52:04 --> Language Class Initialized
DEBUG - 2011-08-22 02:52:04 --> Loader Class Initialized
DEBUG - 2011-08-22 02:52:04 --> Controller Class Initialized
ERROR - 2011-08-22 02:52:04 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-08-22 02:52:04 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-08-22 02:52:04 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-08-22 02:52:04 --> Model Class Initialized
DEBUG - 2011-08-22 02:52:04 --> Model Class Initialized
DEBUG - 2011-08-22 02:52:04 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-22 02:52:04 --> Database Driver Class Initialized
DEBUG - 2011-08-22 02:52:04 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-08-22 02:52:04 --> Helper loaded: url_helper
DEBUG - 2011-08-22 02:52:04 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-22 02:52:04 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-22 02:52:04 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-22 02:52:04 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-22 02:52:04 --> Final output sent to browser
DEBUG - 2011-08-22 02:52:04 --> Total execution time: 0.0287
DEBUG - 2011-08-22 02:52:05 --> Config Class Initialized
DEBUG - 2011-08-22 02:52:05 --> Hooks Class Initialized
DEBUG - 2011-08-22 02:52:05 --> Utf8 Class Initialized
DEBUG - 2011-08-22 02:52:05 --> UTF-8 Support Enabled
DEBUG - 2011-08-22 02:52:05 --> URI Class Initialized
DEBUG - 2011-08-22 02:52:05 --> Router Class Initialized
DEBUG - 2011-08-22 02:52:05 --> Output Class Initialized
DEBUG - 2011-08-22 02:52:05 --> Input Class Initialized
DEBUG - 2011-08-22 02:52:05 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-22 02:52:05 --> Language Class Initialized
DEBUG - 2011-08-22 02:52:05 --> Loader Class Initialized
DEBUG - 2011-08-22 02:52:05 --> Controller Class Initialized
DEBUG - 2011-08-22 02:52:05 --> Model Class Initialized
DEBUG - 2011-08-22 02:52:05 --> Model Class Initialized
DEBUG - 2011-08-22 02:52:05 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-22 02:52:05 --> Database Driver Class Initialized
DEBUG - 2011-08-22 02:52:06 --> Final output sent to browser
DEBUG - 2011-08-22 02:52:06 --> Total execution time: 1.0771
DEBUG - 2011-08-22 02:52:09 --> Config Class Initialized
DEBUG - 2011-08-22 02:52:09 --> Hooks Class Initialized
DEBUG - 2011-08-22 02:52:09 --> Utf8 Class Initialized
DEBUG - 2011-08-22 02:52:09 --> UTF-8 Support Enabled
DEBUG - 2011-08-22 02:52:09 --> URI Class Initialized
DEBUG - 2011-08-22 02:52:09 --> Router Class Initialized
DEBUG - 2011-08-22 02:52:09 --> Output Class Initialized
DEBUG - 2011-08-22 02:52:09 --> Input Class Initialized
DEBUG - 2011-08-22 02:52:09 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-22 02:52:09 --> Language Class Initialized
DEBUG - 2011-08-22 02:52:09 --> Loader Class Initialized
DEBUG - 2011-08-22 02:52:09 --> Controller Class Initialized
ERROR - 2011-08-22 02:52:09 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-08-22 02:52:09 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-08-22 02:52:09 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-08-22 02:52:09 --> Model Class Initialized
DEBUG - 2011-08-22 02:52:09 --> Model Class Initialized
DEBUG - 2011-08-22 02:52:09 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-22 02:52:09 --> Database Driver Class Initialized
DEBUG - 2011-08-22 02:52:09 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-08-22 02:52:09 --> Helper loaded: url_helper
DEBUG - 2011-08-22 02:52:09 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-22 02:52:09 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-22 02:52:09 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-22 02:52:09 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-22 02:52:09 --> Final output sent to browser
DEBUG - 2011-08-22 02:52:09 --> Total execution time: 0.0318
DEBUG - 2011-08-22 02:52:20 --> Config Class Initialized
DEBUG - 2011-08-22 02:52:20 --> Hooks Class Initialized
DEBUG - 2011-08-22 02:52:20 --> Utf8 Class Initialized
DEBUG - 2011-08-22 02:52:20 --> UTF-8 Support Enabled
DEBUG - 2011-08-22 02:52:20 --> URI Class Initialized
DEBUG - 2011-08-22 02:52:20 --> Router Class Initialized
DEBUG - 2011-08-22 02:52:20 --> Output Class Initialized
DEBUG - 2011-08-22 02:52:20 --> Input Class Initialized
DEBUG - 2011-08-22 02:52:20 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-22 02:52:20 --> Language Class Initialized
DEBUG - 2011-08-22 02:52:20 --> Loader Class Initialized
DEBUG - 2011-08-22 02:52:20 --> Controller Class Initialized
ERROR - 2011-08-22 02:52:20 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-08-22 02:52:20 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-08-22 02:52:20 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-08-22 02:52:20 --> Model Class Initialized
DEBUG - 2011-08-22 02:52:20 --> Model Class Initialized
DEBUG - 2011-08-22 02:52:20 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-22 02:52:20 --> Database Driver Class Initialized
DEBUG - 2011-08-22 02:52:20 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-08-22 02:52:20 --> Helper loaded: url_helper
DEBUG - 2011-08-22 02:52:20 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-22 02:52:20 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-22 02:52:20 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-22 02:52:20 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-22 02:52:20 --> Final output sent to browser
DEBUG - 2011-08-22 02:52:20 --> Total execution time: 0.0325
DEBUG - 2011-08-22 02:52:21 --> Config Class Initialized
DEBUG - 2011-08-22 02:52:21 --> Hooks Class Initialized
DEBUG - 2011-08-22 02:52:21 --> Utf8 Class Initialized
DEBUG - 2011-08-22 02:52:21 --> UTF-8 Support Enabled
DEBUG - 2011-08-22 02:52:21 --> URI Class Initialized
DEBUG - 2011-08-22 02:52:21 --> Router Class Initialized
DEBUG - 2011-08-22 02:52:21 --> Output Class Initialized
DEBUG - 2011-08-22 02:52:21 --> Input Class Initialized
DEBUG - 2011-08-22 02:52:21 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-22 02:52:21 --> Language Class Initialized
DEBUG - 2011-08-22 02:52:21 --> Loader Class Initialized
DEBUG - 2011-08-22 02:52:21 --> Controller Class Initialized
DEBUG - 2011-08-22 02:52:21 --> Model Class Initialized
DEBUG - 2011-08-22 02:52:21 --> Model Class Initialized
DEBUG - 2011-08-22 02:52:21 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-22 02:52:21 --> Database Driver Class Initialized
DEBUG - 2011-08-22 02:52:21 --> Final output sent to browser
DEBUG - 2011-08-22 02:52:21 --> Total execution time: 0.4978
DEBUG - 2011-08-22 03:14:05 --> Config Class Initialized
DEBUG - 2011-08-22 03:14:05 --> Hooks Class Initialized
DEBUG - 2011-08-22 03:14:05 --> Utf8 Class Initialized
DEBUG - 2011-08-22 03:14:05 --> UTF-8 Support Enabled
DEBUG - 2011-08-22 03:14:05 --> URI Class Initialized
DEBUG - 2011-08-22 03:14:05 --> Router Class Initialized
DEBUG - 2011-08-22 03:14:05 --> Output Class Initialized
DEBUG - 2011-08-22 03:14:05 --> Input Class Initialized
DEBUG - 2011-08-22 03:14:05 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-22 03:14:05 --> Language Class Initialized
DEBUG - 2011-08-22 03:14:05 --> Loader Class Initialized
DEBUG - 2011-08-22 03:14:05 --> Controller Class Initialized
ERROR - 2011-08-22 03:14:05 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-08-22 03:14:05 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-08-22 03:14:05 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-08-22 03:14:05 --> Model Class Initialized
DEBUG - 2011-08-22 03:14:05 --> Model Class Initialized
DEBUG - 2011-08-22 03:14:05 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-22 03:14:05 --> Database Driver Class Initialized
DEBUG - 2011-08-22 03:14:06 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-08-22 03:14:06 --> Helper loaded: url_helper
DEBUG - 2011-08-22 03:14:06 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-22 03:14:06 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-22 03:14:06 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-22 03:14:06 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-22 03:14:06 --> Final output sent to browser
DEBUG - 2011-08-22 03:14:06 --> Total execution time: 0.5657
DEBUG - 2011-08-22 03:14:07 --> Config Class Initialized
DEBUG - 2011-08-22 03:14:07 --> Hooks Class Initialized
DEBUG - 2011-08-22 03:14:07 --> Utf8 Class Initialized
DEBUG - 2011-08-22 03:14:07 --> UTF-8 Support Enabled
DEBUG - 2011-08-22 03:14:07 --> URI Class Initialized
DEBUG - 2011-08-22 03:14:07 --> Router Class Initialized
DEBUG - 2011-08-22 03:14:07 --> Output Class Initialized
DEBUG - 2011-08-22 03:14:07 --> Input Class Initialized
DEBUG - 2011-08-22 03:14:07 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-22 03:14:07 --> Language Class Initialized
DEBUG - 2011-08-22 03:14:07 --> Loader Class Initialized
DEBUG - 2011-08-22 03:14:07 --> Controller Class Initialized
DEBUG - 2011-08-22 03:14:07 --> Model Class Initialized
DEBUG - 2011-08-22 03:14:07 --> Model Class Initialized
DEBUG - 2011-08-22 03:14:07 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-22 03:14:07 --> Database Driver Class Initialized
DEBUG - 2011-08-22 03:14:08 --> Final output sent to browser
DEBUG - 2011-08-22 03:14:08 --> Total execution time: 0.7742
DEBUG - 2011-08-22 03:14:09 --> Config Class Initialized
DEBUG - 2011-08-22 03:14:09 --> Hooks Class Initialized
DEBUG - 2011-08-22 03:14:09 --> Utf8 Class Initialized
DEBUG - 2011-08-22 03:14:09 --> UTF-8 Support Enabled
DEBUG - 2011-08-22 03:14:09 --> URI Class Initialized
DEBUG - 2011-08-22 03:14:09 --> Router Class Initialized
ERROR - 2011-08-22 03:14:09 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-08-22 03:15:11 --> Config Class Initialized
DEBUG - 2011-08-22 03:15:11 --> Hooks Class Initialized
DEBUG - 2011-08-22 03:15:11 --> Utf8 Class Initialized
DEBUG - 2011-08-22 03:15:11 --> UTF-8 Support Enabled
DEBUG - 2011-08-22 03:15:11 --> URI Class Initialized
DEBUG - 2011-08-22 03:15:11 --> Router Class Initialized
DEBUG - 2011-08-22 03:15:11 --> Output Class Initialized
DEBUG - 2011-08-22 03:15:11 --> Input Class Initialized
DEBUG - 2011-08-22 03:15:11 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-22 03:15:11 --> Language Class Initialized
DEBUG - 2011-08-22 03:15:11 --> Loader Class Initialized
DEBUG - 2011-08-22 03:15:11 --> Controller Class Initialized
ERROR - 2011-08-22 03:15:11 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-08-22 03:15:11 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-08-22 03:15:11 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-08-22 03:15:11 --> Model Class Initialized
DEBUG - 2011-08-22 03:15:11 --> Model Class Initialized
DEBUG - 2011-08-22 03:15:11 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-22 03:15:11 --> Database Driver Class Initialized
DEBUG - 2011-08-22 03:15:11 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-08-22 03:15:11 --> Helper loaded: url_helper
DEBUG - 2011-08-22 03:15:11 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-22 03:15:11 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-22 03:15:11 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-22 03:15:11 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-22 03:15:11 --> Final output sent to browser
DEBUG - 2011-08-22 03:15:11 --> Total execution time: 0.0609
DEBUG - 2011-08-22 03:15:12 --> Config Class Initialized
DEBUG - 2011-08-22 03:15:12 --> Hooks Class Initialized
DEBUG - 2011-08-22 03:15:12 --> Utf8 Class Initialized
DEBUG - 2011-08-22 03:15:12 --> UTF-8 Support Enabled
DEBUG - 2011-08-22 03:15:12 --> URI Class Initialized
DEBUG - 2011-08-22 03:15:12 --> Router Class Initialized
DEBUG - 2011-08-22 03:15:12 --> Output Class Initialized
DEBUG - 2011-08-22 03:15:12 --> Input Class Initialized
DEBUG - 2011-08-22 03:15:12 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-22 03:15:12 --> Language Class Initialized
DEBUG - 2011-08-22 03:15:12 --> Loader Class Initialized
DEBUG - 2011-08-22 03:15:12 --> Controller Class Initialized
DEBUG - 2011-08-22 03:15:12 --> Model Class Initialized
DEBUG - 2011-08-22 03:15:12 --> Model Class Initialized
DEBUG - 2011-08-22 03:15:12 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-22 03:15:12 --> Database Driver Class Initialized
DEBUG - 2011-08-22 03:15:13 --> Final output sent to browser
DEBUG - 2011-08-22 03:15:13 --> Total execution time: 0.5727
DEBUG - 2011-08-22 03:15:14 --> Config Class Initialized
DEBUG - 2011-08-22 03:15:14 --> Hooks Class Initialized
DEBUG - 2011-08-22 03:15:14 --> Utf8 Class Initialized
DEBUG - 2011-08-22 03:15:14 --> UTF-8 Support Enabled
DEBUG - 2011-08-22 03:15:14 --> URI Class Initialized
DEBUG - 2011-08-22 03:15:14 --> Router Class Initialized
ERROR - 2011-08-22 03:15:14 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-08-22 03:15:49 --> Config Class Initialized
DEBUG - 2011-08-22 03:15:49 --> Hooks Class Initialized
DEBUG - 2011-08-22 03:15:49 --> Utf8 Class Initialized
DEBUG - 2011-08-22 03:15:49 --> UTF-8 Support Enabled
DEBUG - 2011-08-22 03:15:49 --> URI Class Initialized
DEBUG - 2011-08-22 03:15:49 --> Router Class Initialized
DEBUG - 2011-08-22 03:15:49 --> Output Class Initialized
DEBUG - 2011-08-22 03:15:49 --> Input Class Initialized
DEBUG - 2011-08-22 03:15:49 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-22 03:15:49 --> Language Class Initialized
DEBUG - 2011-08-22 03:15:49 --> Loader Class Initialized
DEBUG - 2011-08-22 03:15:49 --> Controller Class Initialized
ERROR - 2011-08-22 03:15:49 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-08-22 03:15:49 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-08-22 03:15:49 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-08-22 03:15:49 --> Model Class Initialized
DEBUG - 2011-08-22 03:15:49 --> Model Class Initialized
DEBUG - 2011-08-22 03:15:49 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-22 03:15:49 --> Database Driver Class Initialized
DEBUG - 2011-08-22 03:15:49 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-08-22 03:15:49 --> Helper loaded: url_helper
DEBUG - 2011-08-22 03:15:49 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-22 03:15:49 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-22 03:15:49 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-22 03:15:49 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-22 03:15:49 --> Final output sent to browser
DEBUG - 2011-08-22 03:15:49 --> Total execution time: 0.0294
DEBUG - 2011-08-22 03:15:50 --> Config Class Initialized
DEBUG - 2011-08-22 03:15:50 --> Hooks Class Initialized
DEBUG - 2011-08-22 03:15:50 --> Utf8 Class Initialized
DEBUG - 2011-08-22 03:15:50 --> UTF-8 Support Enabled
DEBUG - 2011-08-22 03:15:50 --> URI Class Initialized
DEBUG - 2011-08-22 03:15:50 --> Router Class Initialized
DEBUG - 2011-08-22 03:15:50 --> Output Class Initialized
DEBUG - 2011-08-22 03:15:50 --> Input Class Initialized
DEBUG - 2011-08-22 03:15:50 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-22 03:15:50 --> Language Class Initialized
DEBUG - 2011-08-22 03:15:50 --> Loader Class Initialized
DEBUG - 2011-08-22 03:15:50 --> Controller Class Initialized
DEBUG - 2011-08-22 03:15:50 --> Model Class Initialized
DEBUG - 2011-08-22 03:15:50 --> Model Class Initialized
DEBUG - 2011-08-22 03:15:50 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-22 03:15:50 --> Database Driver Class Initialized
DEBUG - 2011-08-22 03:15:51 --> Final output sent to browser
DEBUG - 2011-08-22 03:15:51 --> Total execution time: 0.8397
DEBUG - 2011-08-22 03:15:52 --> Config Class Initialized
DEBUG - 2011-08-22 03:15:52 --> Hooks Class Initialized
DEBUG - 2011-08-22 03:15:52 --> Utf8 Class Initialized
DEBUG - 2011-08-22 03:15:52 --> UTF-8 Support Enabled
DEBUG - 2011-08-22 03:15:52 --> URI Class Initialized
DEBUG - 2011-08-22 03:15:52 --> Router Class Initialized
ERROR - 2011-08-22 03:15:52 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-08-22 03:16:08 --> Config Class Initialized
DEBUG - 2011-08-22 03:16:08 --> Hooks Class Initialized
DEBUG - 2011-08-22 03:16:08 --> Utf8 Class Initialized
DEBUG - 2011-08-22 03:16:08 --> UTF-8 Support Enabled
DEBUG - 2011-08-22 03:16:08 --> URI Class Initialized
DEBUG - 2011-08-22 03:16:08 --> Router Class Initialized
DEBUG - 2011-08-22 03:16:08 --> Output Class Initialized
DEBUG - 2011-08-22 03:16:08 --> Input Class Initialized
DEBUG - 2011-08-22 03:16:08 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-22 03:16:08 --> Language Class Initialized
DEBUG - 2011-08-22 03:16:08 --> Loader Class Initialized
DEBUG - 2011-08-22 03:16:08 --> Controller Class Initialized
ERROR - 2011-08-22 03:16:08 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-08-22 03:16:08 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-08-22 03:16:08 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-08-22 03:16:08 --> Model Class Initialized
DEBUG - 2011-08-22 03:16:08 --> Model Class Initialized
DEBUG - 2011-08-22 03:16:08 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-22 03:16:08 --> Database Driver Class Initialized
DEBUG - 2011-08-22 03:16:08 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-08-22 03:16:08 --> Helper loaded: url_helper
DEBUG - 2011-08-22 03:16:08 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-22 03:16:08 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-22 03:16:08 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-22 03:16:08 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-22 03:16:08 --> Final output sent to browser
DEBUG - 2011-08-22 03:16:08 --> Total execution time: 0.0297
DEBUG - 2011-08-22 03:16:09 --> Config Class Initialized
DEBUG - 2011-08-22 03:16:09 --> Hooks Class Initialized
DEBUG - 2011-08-22 03:16:09 --> Utf8 Class Initialized
DEBUG - 2011-08-22 03:16:09 --> UTF-8 Support Enabled
DEBUG - 2011-08-22 03:16:09 --> URI Class Initialized
DEBUG - 2011-08-22 03:16:09 --> Router Class Initialized
DEBUG - 2011-08-22 03:16:09 --> Output Class Initialized
DEBUG - 2011-08-22 03:16:09 --> Input Class Initialized
DEBUG - 2011-08-22 03:16:09 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-22 03:16:09 --> Language Class Initialized
DEBUG - 2011-08-22 03:16:09 --> Loader Class Initialized
DEBUG - 2011-08-22 03:16:09 --> Controller Class Initialized
DEBUG - 2011-08-22 03:16:09 --> Model Class Initialized
DEBUG - 2011-08-22 03:16:09 --> Model Class Initialized
DEBUG - 2011-08-22 03:16:09 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-22 03:16:09 --> Database Driver Class Initialized
DEBUG - 2011-08-22 03:16:10 --> Final output sent to browser
DEBUG - 2011-08-22 03:16:10 --> Total execution time: 0.7332
DEBUG - 2011-08-22 03:16:11 --> Config Class Initialized
DEBUG - 2011-08-22 03:16:11 --> Hooks Class Initialized
DEBUG - 2011-08-22 03:16:11 --> Utf8 Class Initialized
DEBUG - 2011-08-22 03:16:11 --> UTF-8 Support Enabled
DEBUG - 2011-08-22 03:16:11 --> URI Class Initialized
DEBUG - 2011-08-22 03:16:11 --> Router Class Initialized
ERROR - 2011-08-22 03:16:11 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-08-22 03:16:24 --> Config Class Initialized
DEBUG - 2011-08-22 03:16:24 --> Hooks Class Initialized
DEBUG - 2011-08-22 03:16:24 --> Utf8 Class Initialized
DEBUG - 2011-08-22 03:16:24 --> UTF-8 Support Enabled
DEBUG - 2011-08-22 03:16:24 --> URI Class Initialized
DEBUG - 2011-08-22 03:16:24 --> Router Class Initialized
DEBUG - 2011-08-22 03:16:24 --> Output Class Initialized
DEBUG - 2011-08-22 03:16:24 --> Input Class Initialized
DEBUG - 2011-08-22 03:16:24 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-22 03:16:24 --> Language Class Initialized
DEBUG - 2011-08-22 03:16:24 --> Loader Class Initialized
DEBUG - 2011-08-22 03:16:24 --> Controller Class Initialized
ERROR - 2011-08-22 03:16:24 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-08-22 03:16:24 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-08-22 03:16:24 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-08-22 03:16:24 --> Model Class Initialized
DEBUG - 2011-08-22 03:16:24 --> Model Class Initialized
DEBUG - 2011-08-22 03:16:24 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-22 03:16:24 --> Database Driver Class Initialized
DEBUG - 2011-08-22 03:16:24 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-08-22 03:16:24 --> Helper loaded: url_helper
DEBUG - 2011-08-22 03:16:24 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-22 03:16:24 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-22 03:16:24 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-22 03:16:24 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-22 03:16:24 --> Final output sent to browser
DEBUG - 2011-08-22 03:16:24 --> Total execution time: 0.0336
DEBUG - 2011-08-22 03:16:25 --> Config Class Initialized
DEBUG - 2011-08-22 03:16:25 --> Hooks Class Initialized
DEBUG - 2011-08-22 03:16:25 --> Utf8 Class Initialized
DEBUG - 2011-08-22 03:16:25 --> UTF-8 Support Enabled
DEBUG - 2011-08-22 03:16:25 --> URI Class Initialized
DEBUG - 2011-08-22 03:16:25 --> Router Class Initialized
DEBUG - 2011-08-22 03:16:25 --> Output Class Initialized
DEBUG - 2011-08-22 03:16:25 --> Input Class Initialized
DEBUG - 2011-08-22 03:16:25 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-22 03:16:25 --> Language Class Initialized
DEBUG - 2011-08-22 03:16:25 --> Loader Class Initialized
DEBUG - 2011-08-22 03:16:25 --> Controller Class Initialized
DEBUG - 2011-08-22 03:16:25 --> Model Class Initialized
DEBUG - 2011-08-22 03:16:25 --> Model Class Initialized
DEBUG - 2011-08-22 03:16:25 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-22 03:16:25 --> Database Driver Class Initialized
DEBUG - 2011-08-22 03:16:26 --> Final output sent to browser
DEBUG - 2011-08-22 03:16:26 --> Total execution time: 0.6473
DEBUG - 2011-08-22 03:16:27 --> Config Class Initialized
DEBUG - 2011-08-22 03:16:27 --> Hooks Class Initialized
DEBUG - 2011-08-22 03:16:27 --> Utf8 Class Initialized
DEBUG - 2011-08-22 03:16:27 --> UTF-8 Support Enabled
DEBUG - 2011-08-22 03:16:27 --> URI Class Initialized
DEBUG - 2011-08-22 03:16:27 --> Router Class Initialized
ERROR - 2011-08-22 03:16:27 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-08-22 03:16:38 --> Config Class Initialized
DEBUG - 2011-08-22 03:16:38 --> Hooks Class Initialized
DEBUG - 2011-08-22 03:16:38 --> Utf8 Class Initialized
DEBUG - 2011-08-22 03:16:38 --> UTF-8 Support Enabled
DEBUG - 2011-08-22 03:16:38 --> URI Class Initialized
DEBUG - 2011-08-22 03:16:38 --> Router Class Initialized
DEBUG - 2011-08-22 03:16:38 --> Output Class Initialized
DEBUG - 2011-08-22 03:16:38 --> Input Class Initialized
DEBUG - 2011-08-22 03:16:38 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-22 03:16:38 --> Language Class Initialized
DEBUG - 2011-08-22 03:16:38 --> Loader Class Initialized
DEBUG - 2011-08-22 03:16:38 --> Controller Class Initialized
ERROR - 2011-08-22 03:16:38 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-08-22 03:16:38 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-08-22 03:16:38 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-08-22 03:16:38 --> Model Class Initialized
DEBUG - 2011-08-22 03:16:38 --> Model Class Initialized
DEBUG - 2011-08-22 03:16:38 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-22 03:16:38 --> Database Driver Class Initialized
DEBUG - 2011-08-22 03:16:38 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-08-22 03:16:38 --> Helper loaded: url_helper
DEBUG - 2011-08-22 03:16:38 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-22 03:16:38 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-22 03:16:38 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-22 03:16:38 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-22 03:16:38 --> Final output sent to browser
DEBUG - 2011-08-22 03:16:38 --> Total execution time: 0.0555
DEBUG - 2011-08-22 03:16:40 --> Config Class Initialized
DEBUG - 2011-08-22 03:16:40 --> Hooks Class Initialized
DEBUG - 2011-08-22 03:16:40 --> Utf8 Class Initialized
DEBUG - 2011-08-22 03:16:40 --> UTF-8 Support Enabled
DEBUG - 2011-08-22 03:16:40 --> URI Class Initialized
DEBUG - 2011-08-22 03:16:40 --> Router Class Initialized
DEBUG - 2011-08-22 03:16:40 --> Output Class Initialized
DEBUG - 2011-08-22 03:16:40 --> Input Class Initialized
DEBUG - 2011-08-22 03:16:40 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-22 03:16:40 --> Language Class Initialized
DEBUG - 2011-08-22 03:16:40 --> Loader Class Initialized
DEBUG - 2011-08-22 03:16:40 --> Controller Class Initialized
DEBUG - 2011-08-22 03:16:40 --> Model Class Initialized
DEBUG - 2011-08-22 03:16:40 --> Model Class Initialized
DEBUG - 2011-08-22 03:16:40 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-22 03:16:40 --> Database Driver Class Initialized
DEBUG - 2011-08-22 03:16:40 --> Final output sent to browser
DEBUG - 2011-08-22 03:16:40 --> Total execution time: 0.5078
DEBUG - 2011-08-22 03:16:42 --> Config Class Initialized
DEBUG - 2011-08-22 03:16:42 --> Hooks Class Initialized
DEBUG - 2011-08-22 03:16:42 --> Utf8 Class Initialized
DEBUG - 2011-08-22 03:16:42 --> UTF-8 Support Enabled
DEBUG - 2011-08-22 03:16:42 --> URI Class Initialized
DEBUG - 2011-08-22 03:16:42 --> Router Class Initialized
ERROR - 2011-08-22 03:16:42 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-08-22 03:16:47 --> Config Class Initialized
DEBUG - 2011-08-22 03:16:47 --> Hooks Class Initialized
DEBUG - 2011-08-22 03:16:47 --> Utf8 Class Initialized
DEBUG - 2011-08-22 03:16:47 --> UTF-8 Support Enabled
DEBUG - 2011-08-22 03:16:47 --> URI Class Initialized
DEBUG - 2011-08-22 03:16:47 --> Router Class Initialized
DEBUG - 2011-08-22 03:16:47 --> Output Class Initialized
DEBUG - 2011-08-22 03:16:47 --> Input Class Initialized
DEBUG - 2011-08-22 03:16:47 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-22 03:16:47 --> Language Class Initialized
DEBUG - 2011-08-22 03:16:47 --> Loader Class Initialized
DEBUG - 2011-08-22 03:16:47 --> Controller Class Initialized
ERROR - 2011-08-22 03:16:47 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-08-22 03:16:47 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-08-22 03:16:47 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-08-22 03:16:47 --> Model Class Initialized
DEBUG - 2011-08-22 03:16:47 --> Model Class Initialized
DEBUG - 2011-08-22 03:16:47 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-22 03:16:47 --> Database Driver Class Initialized
DEBUG - 2011-08-22 03:16:47 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-08-22 03:16:47 --> Helper loaded: url_helper
DEBUG - 2011-08-22 03:16:47 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-22 03:16:47 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-22 03:16:47 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-22 03:16:47 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-22 03:16:47 --> Final output sent to browser
DEBUG - 2011-08-22 03:16:47 --> Total execution time: 0.0323
DEBUG - 2011-08-22 03:16:48 --> Config Class Initialized
DEBUG - 2011-08-22 03:16:48 --> Hooks Class Initialized
DEBUG - 2011-08-22 03:16:48 --> Utf8 Class Initialized
DEBUG - 2011-08-22 03:16:48 --> UTF-8 Support Enabled
DEBUG - 2011-08-22 03:16:48 --> URI Class Initialized
DEBUG - 2011-08-22 03:16:48 --> Router Class Initialized
DEBUG - 2011-08-22 03:16:48 --> Output Class Initialized
DEBUG - 2011-08-22 03:16:48 --> Input Class Initialized
DEBUG - 2011-08-22 03:16:48 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-22 03:16:48 --> Language Class Initialized
DEBUG - 2011-08-22 03:16:48 --> Loader Class Initialized
DEBUG - 2011-08-22 03:16:48 --> Controller Class Initialized
DEBUG - 2011-08-22 03:16:48 --> Model Class Initialized
DEBUG - 2011-08-22 03:16:48 --> Model Class Initialized
DEBUG - 2011-08-22 03:16:48 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-22 03:16:48 --> Database Driver Class Initialized
DEBUG - 2011-08-22 03:16:49 --> Final output sent to browser
DEBUG - 2011-08-22 03:16:49 --> Total execution time: 0.6910
DEBUG - 2011-08-22 03:16:50 --> Config Class Initialized
DEBUG - 2011-08-22 03:16:50 --> Hooks Class Initialized
DEBUG - 2011-08-22 03:16:50 --> Utf8 Class Initialized
DEBUG - 2011-08-22 03:16:50 --> UTF-8 Support Enabled
DEBUG - 2011-08-22 03:16:50 --> URI Class Initialized
DEBUG - 2011-08-22 03:16:50 --> Router Class Initialized
ERROR - 2011-08-22 03:16:50 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-08-22 03:17:01 --> Config Class Initialized
DEBUG - 2011-08-22 03:17:01 --> Hooks Class Initialized
DEBUG - 2011-08-22 03:17:01 --> Utf8 Class Initialized
DEBUG - 2011-08-22 03:17:01 --> UTF-8 Support Enabled
DEBUG - 2011-08-22 03:17:01 --> URI Class Initialized
DEBUG - 2011-08-22 03:17:01 --> Router Class Initialized
DEBUG - 2011-08-22 03:17:01 --> Output Class Initialized
DEBUG - 2011-08-22 03:17:01 --> Input Class Initialized
DEBUG - 2011-08-22 03:17:01 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-22 03:17:01 --> Language Class Initialized
DEBUG - 2011-08-22 03:17:01 --> Loader Class Initialized
DEBUG - 2011-08-22 03:17:01 --> Controller Class Initialized
ERROR - 2011-08-22 03:17:01 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-08-22 03:17:01 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-08-22 03:17:01 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-08-22 03:17:01 --> Model Class Initialized
DEBUG - 2011-08-22 03:17:01 --> Model Class Initialized
DEBUG - 2011-08-22 03:17:01 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-22 03:17:01 --> Database Driver Class Initialized
DEBUG - 2011-08-22 03:17:01 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-08-22 03:17:01 --> Helper loaded: url_helper
DEBUG - 2011-08-22 03:17:01 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-22 03:17:01 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-22 03:17:01 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-22 03:17:01 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-22 03:17:01 --> Final output sent to browser
DEBUG - 2011-08-22 03:17:01 --> Total execution time: 0.0425
DEBUG - 2011-08-22 03:17:02 --> Config Class Initialized
DEBUG - 2011-08-22 03:17:02 --> Hooks Class Initialized
DEBUG - 2011-08-22 03:17:02 --> Utf8 Class Initialized
DEBUG - 2011-08-22 03:17:02 --> UTF-8 Support Enabled
DEBUG - 2011-08-22 03:17:02 --> URI Class Initialized
DEBUG - 2011-08-22 03:17:02 --> Router Class Initialized
DEBUG - 2011-08-22 03:17:02 --> Output Class Initialized
DEBUG - 2011-08-22 03:17:02 --> Input Class Initialized
DEBUG - 2011-08-22 03:17:02 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-22 03:17:02 --> Language Class Initialized
DEBUG - 2011-08-22 03:17:02 --> Loader Class Initialized
DEBUG - 2011-08-22 03:17:02 --> Controller Class Initialized
DEBUG - 2011-08-22 03:17:02 --> Model Class Initialized
DEBUG - 2011-08-22 03:17:02 --> Model Class Initialized
DEBUG - 2011-08-22 03:17:02 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-22 03:17:02 --> Database Driver Class Initialized
DEBUG - 2011-08-22 03:17:03 --> Final output sent to browser
DEBUG - 2011-08-22 03:17:03 --> Total execution time: 0.7172
DEBUG - 2011-08-22 03:17:04 --> Config Class Initialized
DEBUG - 2011-08-22 03:17:04 --> Hooks Class Initialized
DEBUG - 2011-08-22 03:17:04 --> Utf8 Class Initialized
DEBUG - 2011-08-22 03:17:04 --> UTF-8 Support Enabled
DEBUG - 2011-08-22 03:17:04 --> URI Class Initialized
DEBUG - 2011-08-22 03:17:04 --> Router Class Initialized
ERROR - 2011-08-22 03:17:04 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-08-22 03:17:12 --> Config Class Initialized
DEBUG - 2011-08-22 03:17:12 --> Hooks Class Initialized
DEBUG - 2011-08-22 03:17:12 --> Utf8 Class Initialized
DEBUG - 2011-08-22 03:17:12 --> UTF-8 Support Enabled
DEBUG - 2011-08-22 03:17:12 --> URI Class Initialized
DEBUG - 2011-08-22 03:17:12 --> Router Class Initialized
DEBUG - 2011-08-22 03:17:12 --> Output Class Initialized
DEBUG - 2011-08-22 03:17:12 --> Input Class Initialized
DEBUG - 2011-08-22 03:17:12 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-22 03:17:12 --> Language Class Initialized
DEBUG - 2011-08-22 03:17:12 --> Loader Class Initialized
DEBUG - 2011-08-22 03:17:12 --> Controller Class Initialized
ERROR - 2011-08-22 03:17:12 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-08-22 03:17:12 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-08-22 03:17:12 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-08-22 03:17:12 --> Model Class Initialized
DEBUG - 2011-08-22 03:17:12 --> Model Class Initialized
DEBUG - 2011-08-22 03:17:12 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-22 03:17:12 --> Database Driver Class Initialized
DEBUG - 2011-08-22 03:17:12 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-08-22 03:17:12 --> Helper loaded: url_helper
DEBUG - 2011-08-22 03:17:12 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-22 03:17:12 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-22 03:17:12 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-22 03:17:12 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-22 03:17:12 --> Final output sent to browser
DEBUG - 2011-08-22 03:17:12 --> Total execution time: 0.0326
DEBUG - 2011-08-22 03:17:13 --> Config Class Initialized
DEBUG - 2011-08-22 03:17:13 --> Hooks Class Initialized
DEBUG - 2011-08-22 03:17:13 --> Utf8 Class Initialized
DEBUG - 2011-08-22 03:17:13 --> UTF-8 Support Enabled
DEBUG - 2011-08-22 03:17:13 --> URI Class Initialized
DEBUG - 2011-08-22 03:17:13 --> Router Class Initialized
DEBUG - 2011-08-22 03:17:13 --> Output Class Initialized
DEBUG - 2011-08-22 03:17:13 --> Input Class Initialized
DEBUG - 2011-08-22 03:17:13 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-22 03:17:13 --> Language Class Initialized
DEBUG - 2011-08-22 03:17:13 --> Loader Class Initialized
DEBUG - 2011-08-22 03:17:13 --> Controller Class Initialized
DEBUG - 2011-08-22 03:17:13 --> Model Class Initialized
DEBUG - 2011-08-22 03:17:13 --> Model Class Initialized
DEBUG - 2011-08-22 03:17:13 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-22 03:17:13 --> Database Driver Class Initialized
DEBUG - 2011-08-22 03:17:14 --> Final output sent to browser
DEBUG - 2011-08-22 03:17:14 --> Total execution time: 0.6511
DEBUG - 2011-08-22 03:17:15 --> Config Class Initialized
DEBUG - 2011-08-22 03:17:15 --> Hooks Class Initialized
DEBUG - 2011-08-22 03:17:15 --> Utf8 Class Initialized
DEBUG - 2011-08-22 03:17:15 --> UTF-8 Support Enabled
DEBUG - 2011-08-22 03:17:15 --> URI Class Initialized
DEBUG - 2011-08-22 03:17:15 --> Router Class Initialized
ERROR - 2011-08-22 03:17:15 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-08-22 03:17:27 --> Config Class Initialized
DEBUG - 2011-08-22 03:17:27 --> Hooks Class Initialized
DEBUG - 2011-08-22 03:17:27 --> Utf8 Class Initialized
DEBUG - 2011-08-22 03:17:27 --> UTF-8 Support Enabled
DEBUG - 2011-08-22 03:17:27 --> URI Class Initialized
DEBUG - 2011-08-22 03:17:27 --> Router Class Initialized
DEBUG - 2011-08-22 03:17:27 --> Output Class Initialized
DEBUG - 2011-08-22 03:17:27 --> Input Class Initialized
DEBUG - 2011-08-22 03:17:27 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-22 03:17:27 --> Language Class Initialized
DEBUG - 2011-08-22 03:17:27 --> Loader Class Initialized
DEBUG - 2011-08-22 03:17:27 --> Controller Class Initialized
ERROR - 2011-08-22 03:17:27 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-08-22 03:17:27 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-08-22 03:17:27 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-08-22 03:17:27 --> Model Class Initialized
DEBUG - 2011-08-22 03:17:27 --> Model Class Initialized
DEBUG - 2011-08-22 03:17:27 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-22 03:17:27 --> Database Driver Class Initialized
DEBUG - 2011-08-22 03:17:27 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-08-22 03:17:27 --> Helper loaded: url_helper
DEBUG - 2011-08-22 03:17:27 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-22 03:17:27 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-22 03:17:27 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-22 03:17:27 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-22 03:17:27 --> Final output sent to browser
DEBUG - 2011-08-22 03:17:27 --> Total execution time: 0.0473
DEBUG - 2011-08-22 03:17:27 --> Config Class Initialized
DEBUG - 2011-08-22 03:17:27 --> Hooks Class Initialized
DEBUG - 2011-08-22 03:17:27 --> Utf8 Class Initialized
DEBUG - 2011-08-22 03:17:27 --> UTF-8 Support Enabled
DEBUG - 2011-08-22 03:17:27 --> URI Class Initialized
DEBUG - 2011-08-22 03:17:27 --> Router Class Initialized
DEBUG - 2011-08-22 03:17:27 --> Output Class Initialized
DEBUG - 2011-08-22 03:17:27 --> Input Class Initialized
DEBUG - 2011-08-22 03:17:27 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-22 03:17:27 --> Language Class Initialized
DEBUG - 2011-08-22 03:17:27 --> Loader Class Initialized
DEBUG - 2011-08-22 03:17:27 --> Controller Class Initialized
DEBUG - 2011-08-22 03:17:27 --> Model Class Initialized
DEBUG - 2011-08-22 03:17:27 --> Model Class Initialized
DEBUG - 2011-08-22 03:17:27 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-22 03:17:27 --> Database Driver Class Initialized
DEBUG - 2011-08-22 03:17:28 --> Final output sent to browser
DEBUG - 2011-08-22 03:17:28 --> Total execution time: 0.4555
DEBUG - 2011-08-22 03:17:29 --> Config Class Initialized
DEBUG - 2011-08-22 03:17:29 --> Hooks Class Initialized
DEBUG - 2011-08-22 03:17:29 --> Utf8 Class Initialized
DEBUG - 2011-08-22 03:17:29 --> UTF-8 Support Enabled
DEBUG - 2011-08-22 03:17:29 --> URI Class Initialized
DEBUG - 2011-08-22 03:17:29 --> Router Class Initialized
ERROR - 2011-08-22 03:17:29 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-08-22 03:17:37 --> Config Class Initialized
DEBUG - 2011-08-22 03:17:37 --> Hooks Class Initialized
DEBUG - 2011-08-22 03:17:37 --> Utf8 Class Initialized
DEBUG - 2011-08-22 03:17:37 --> UTF-8 Support Enabled
DEBUG - 2011-08-22 03:17:37 --> URI Class Initialized
DEBUG - 2011-08-22 03:17:37 --> Router Class Initialized
DEBUG - 2011-08-22 03:17:37 --> Output Class Initialized
DEBUG - 2011-08-22 03:17:37 --> Input Class Initialized
DEBUG - 2011-08-22 03:17:37 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-22 03:17:37 --> Language Class Initialized
DEBUG - 2011-08-22 03:17:37 --> Loader Class Initialized
DEBUG - 2011-08-22 03:17:37 --> Controller Class Initialized
ERROR - 2011-08-22 03:17:37 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-08-22 03:17:37 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-08-22 03:17:37 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-08-22 03:17:37 --> Model Class Initialized
DEBUG - 2011-08-22 03:17:37 --> Model Class Initialized
DEBUG - 2011-08-22 03:17:37 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-22 03:17:37 --> Database Driver Class Initialized
DEBUG - 2011-08-22 03:17:37 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-08-22 03:17:37 --> Helper loaded: url_helper
DEBUG - 2011-08-22 03:17:37 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-22 03:17:37 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-22 03:17:37 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-22 03:17:37 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-22 03:17:37 --> Final output sent to browser
DEBUG - 2011-08-22 03:17:37 --> Total execution time: 0.1183
DEBUG - 2011-08-22 03:17:38 --> Config Class Initialized
DEBUG - 2011-08-22 03:17:38 --> Hooks Class Initialized
DEBUG - 2011-08-22 03:17:38 --> Utf8 Class Initialized
DEBUG - 2011-08-22 03:17:38 --> UTF-8 Support Enabled
DEBUG - 2011-08-22 03:17:38 --> URI Class Initialized
DEBUG - 2011-08-22 03:17:38 --> Router Class Initialized
DEBUG - 2011-08-22 03:17:38 --> Output Class Initialized
DEBUG - 2011-08-22 03:17:38 --> Input Class Initialized
DEBUG - 2011-08-22 03:17:38 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-22 03:17:38 --> Language Class Initialized
DEBUG - 2011-08-22 03:17:38 --> Loader Class Initialized
DEBUG - 2011-08-22 03:17:38 --> Controller Class Initialized
DEBUG - 2011-08-22 03:17:38 --> Model Class Initialized
DEBUG - 2011-08-22 03:17:38 --> Model Class Initialized
DEBUG - 2011-08-22 03:17:38 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-22 03:17:38 --> Database Driver Class Initialized
DEBUG - 2011-08-22 03:17:38 --> Final output sent to browser
DEBUG - 2011-08-22 03:17:38 --> Total execution time: 0.5886
DEBUG - 2011-08-22 03:17:39 --> Config Class Initialized
DEBUG - 2011-08-22 03:17:39 --> Hooks Class Initialized
DEBUG - 2011-08-22 03:17:39 --> Utf8 Class Initialized
DEBUG - 2011-08-22 03:17:39 --> UTF-8 Support Enabled
DEBUG - 2011-08-22 03:17:39 --> URI Class Initialized
DEBUG - 2011-08-22 03:17:39 --> Router Class Initialized
ERROR - 2011-08-22 03:17:39 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-08-22 03:18:02 --> Config Class Initialized
DEBUG - 2011-08-22 03:18:02 --> Hooks Class Initialized
DEBUG - 2011-08-22 03:18:02 --> Utf8 Class Initialized
DEBUG - 2011-08-22 03:18:02 --> UTF-8 Support Enabled
DEBUG - 2011-08-22 03:18:02 --> URI Class Initialized
DEBUG - 2011-08-22 03:18:02 --> Router Class Initialized
DEBUG - 2011-08-22 03:18:02 --> Output Class Initialized
DEBUG - 2011-08-22 03:18:02 --> Input Class Initialized
DEBUG - 2011-08-22 03:18:02 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-22 03:18:02 --> Language Class Initialized
DEBUG - 2011-08-22 03:18:02 --> Loader Class Initialized
DEBUG - 2011-08-22 03:18:02 --> Controller Class Initialized
ERROR - 2011-08-22 03:18:02 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-08-22 03:18:02 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-08-22 03:18:02 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-08-22 03:18:02 --> Model Class Initialized
DEBUG - 2011-08-22 03:18:02 --> Model Class Initialized
DEBUG - 2011-08-22 03:18:02 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-22 03:18:02 --> Database Driver Class Initialized
DEBUG - 2011-08-22 03:18:02 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-08-22 03:18:02 --> Helper loaded: url_helper
DEBUG - 2011-08-22 03:18:02 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-22 03:18:02 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-22 03:18:02 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-22 03:18:02 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-22 03:18:02 --> Final output sent to browser
DEBUG - 2011-08-22 03:18:02 --> Total execution time: 0.0675
DEBUG - 2011-08-22 03:18:03 --> Config Class Initialized
DEBUG - 2011-08-22 03:18:03 --> Hooks Class Initialized
DEBUG - 2011-08-22 03:18:03 --> Utf8 Class Initialized
DEBUG - 2011-08-22 03:18:03 --> UTF-8 Support Enabled
DEBUG - 2011-08-22 03:18:03 --> URI Class Initialized
DEBUG - 2011-08-22 03:18:03 --> Router Class Initialized
DEBUG - 2011-08-22 03:18:03 --> Output Class Initialized
DEBUG - 2011-08-22 03:18:03 --> Input Class Initialized
DEBUG - 2011-08-22 03:18:03 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-22 03:18:03 --> Language Class Initialized
DEBUG - 2011-08-22 03:18:03 --> Loader Class Initialized
DEBUG - 2011-08-22 03:18:03 --> Controller Class Initialized
DEBUG - 2011-08-22 03:18:03 --> Model Class Initialized
DEBUG - 2011-08-22 03:18:03 --> Model Class Initialized
DEBUG - 2011-08-22 03:18:03 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-22 03:18:03 --> Database Driver Class Initialized
DEBUG - 2011-08-22 03:18:04 --> Final output sent to browser
DEBUG - 2011-08-22 03:18:04 --> Total execution time: 0.5994
DEBUG - 2011-08-22 03:18:05 --> Config Class Initialized
DEBUG - 2011-08-22 03:18:05 --> Hooks Class Initialized
DEBUG - 2011-08-22 03:18:05 --> Utf8 Class Initialized
DEBUG - 2011-08-22 03:18:05 --> UTF-8 Support Enabled
DEBUG - 2011-08-22 03:18:05 --> URI Class Initialized
DEBUG - 2011-08-22 03:18:05 --> Router Class Initialized
ERROR - 2011-08-22 03:18:05 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-08-22 03:18:11 --> Config Class Initialized
DEBUG - 2011-08-22 03:18:11 --> Hooks Class Initialized
DEBUG - 2011-08-22 03:18:11 --> Utf8 Class Initialized
DEBUG - 2011-08-22 03:18:11 --> UTF-8 Support Enabled
DEBUG - 2011-08-22 03:18:11 --> URI Class Initialized
DEBUG - 2011-08-22 03:18:11 --> Router Class Initialized
ERROR - 2011-08-22 03:18:11 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-08-22 03:18:12 --> Config Class Initialized
DEBUG - 2011-08-22 03:18:12 --> Hooks Class Initialized
DEBUG - 2011-08-22 03:18:12 --> Utf8 Class Initialized
DEBUG - 2011-08-22 03:18:12 --> UTF-8 Support Enabled
DEBUG - 2011-08-22 03:18:12 --> URI Class Initialized
DEBUG - 2011-08-22 03:18:12 --> Router Class Initialized
ERROR - 2011-08-22 03:18:12 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-08-22 03:18:12 --> Config Class Initialized
DEBUG - 2011-08-22 03:18:12 --> Hooks Class Initialized
DEBUG - 2011-08-22 03:18:12 --> Utf8 Class Initialized
DEBUG - 2011-08-22 03:18:12 --> UTF-8 Support Enabled
DEBUG - 2011-08-22 03:18:12 --> URI Class Initialized
DEBUG - 2011-08-22 03:18:12 --> Router Class Initialized
ERROR - 2011-08-22 03:18:12 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-08-22 03:18:13 --> Config Class Initialized
DEBUG - 2011-08-22 03:18:13 --> Hooks Class Initialized
DEBUG - 2011-08-22 03:18:13 --> Utf8 Class Initialized
DEBUG - 2011-08-22 03:18:13 --> UTF-8 Support Enabled
DEBUG - 2011-08-22 03:18:13 --> URI Class Initialized
DEBUG - 2011-08-22 03:18:13 --> Router Class Initialized
ERROR - 2011-08-22 03:18:13 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-08-22 03:57:57 --> Config Class Initialized
DEBUG - 2011-08-22 03:57:57 --> Hooks Class Initialized
DEBUG - 2011-08-22 03:57:57 --> Utf8 Class Initialized
DEBUG - 2011-08-22 03:57:57 --> UTF-8 Support Enabled
DEBUG - 2011-08-22 03:57:57 --> URI Class Initialized
DEBUG - 2011-08-22 03:57:57 --> Router Class Initialized
ERROR - 2011-08-22 03:57:57 --> 404 Page Not Found --> robots.txt
DEBUG - 2011-08-22 03:58:04 --> Config Class Initialized
DEBUG - 2011-08-22 03:58:04 --> Hooks Class Initialized
DEBUG - 2011-08-22 03:58:04 --> Utf8 Class Initialized
DEBUG - 2011-08-22 03:58:04 --> UTF-8 Support Enabled
DEBUG - 2011-08-22 03:58:04 --> URI Class Initialized
DEBUG - 2011-08-22 03:58:04 --> Router Class Initialized
DEBUG - 2011-08-22 03:58:04 --> Output Class Initialized
DEBUG - 2011-08-22 03:58:04 --> Input Class Initialized
DEBUG - 2011-08-22 03:58:04 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-22 03:58:04 --> Language Class Initialized
DEBUG - 2011-08-22 03:58:04 --> Loader Class Initialized
DEBUG - 2011-08-22 03:58:04 --> Controller Class Initialized
ERROR - 2011-08-22 03:58:04 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-08-22 03:58:04 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-08-22 03:58:04 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-08-22 03:58:04 --> Model Class Initialized
DEBUG - 2011-08-22 03:58:04 --> Model Class Initialized
DEBUG - 2011-08-22 03:58:04 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-22 03:58:04 --> Database Driver Class Initialized
DEBUG - 2011-08-22 03:58:04 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-08-22 03:58:04 --> Helper loaded: url_helper
DEBUG - 2011-08-22 03:58:04 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-22 03:58:04 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-22 03:58:04 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-22 03:58:04 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-22 03:58:04 --> Final output sent to browser
DEBUG - 2011-08-22 03:58:04 --> Total execution time: 0.6947
DEBUG - 2011-08-22 03:58:06 --> Config Class Initialized
DEBUG - 2011-08-22 03:58:06 --> Hooks Class Initialized
DEBUG - 2011-08-22 03:58:06 --> Utf8 Class Initialized
DEBUG - 2011-08-22 03:58:06 --> UTF-8 Support Enabled
DEBUG - 2011-08-22 03:58:06 --> URI Class Initialized
DEBUG - 2011-08-22 03:58:06 --> Router Class Initialized
DEBUG - 2011-08-22 03:58:06 --> Output Class Initialized
DEBUG - 2011-08-22 03:58:06 --> Input Class Initialized
DEBUG - 2011-08-22 03:58:06 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-22 03:58:06 --> Language Class Initialized
DEBUG - 2011-08-22 03:58:06 --> Loader Class Initialized
DEBUG - 2011-08-22 03:58:06 --> Controller Class Initialized
DEBUG - 2011-08-22 03:58:06 --> Model Class Initialized
DEBUG - 2011-08-22 03:58:06 --> Model Class Initialized
DEBUG - 2011-08-22 03:58:06 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-22 03:58:06 --> Database Driver Class Initialized
DEBUG - 2011-08-22 03:58:07 --> Final output sent to browser
DEBUG - 2011-08-22 03:58:07 --> Total execution time: 0.8974
DEBUG - 2011-08-22 03:58:08 --> Config Class Initialized
DEBUG - 2011-08-22 03:58:08 --> Hooks Class Initialized
DEBUG - 2011-08-22 03:58:08 --> Utf8 Class Initialized
DEBUG - 2011-08-22 03:58:08 --> UTF-8 Support Enabled
DEBUG - 2011-08-22 03:58:08 --> URI Class Initialized
DEBUG - 2011-08-22 03:58:08 --> Router Class Initialized
ERROR - 2011-08-22 03:58:08 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-08-22 03:58:08 --> Config Class Initialized
DEBUG - 2011-08-22 03:58:08 --> Hooks Class Initialized
DEBUG - 2011-08-22 03:58:08 --> Utf8 Class Initialized
DEBUG - 2011-08-22 03:58:08 --> UTF-8 Support Enabled
DEBUG - 2011-08-22 03:58:08 --> URI Class Initialized
DEBUG - 2011-08-22 03:58:08 --> Router Class Initialized
ERROR - 2011-08-22 03:58:08 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-08-22 04:06:47 --> Config Class Initialized
DEBUG - 2011-08-22 04:06:47 --> Hooks Class Initialized
DEBUG - 2011-08-22 04:06:47 --> Utf8 Class Initialized
DEBUG - 2011-08-22 04:06:47 --> UTF-8 Support Enabled
DEBUG - 2011-08-22 04:06:47 --> URI Class Initialized
DEBUG - 2011-08-22 04:06:47 --> Router Class Initialized
DEBUG - 2011-08-22 04:06:47 --> Output Class Initialized
DEBUG - 2011-08-22 04:06:47 --> Input Class Initialized
DEBUG - 2011-08-22 04:06:47 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-22 04:06:47 --> Language Class Initialized
DEBUG - 2011-08-22 04:06:47 --> Loader Class Initialized
DEBUG - 2011-08-22 04:06:47 --> Controller Class Initialized
ERROR - 2011-08-22 04:06:47 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-08-22 04:06:47 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-08-22 04:06:47 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-08-22 04:06:47 --> Model Class Initialized
DEBUG - 2011-08-22 04:06:47 --> Model Class Initialized
DEBUG - 2011-08-22 04:06:47 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-22 04:06:47 --> Database Driver Class Initialized
DEBUG - 2011-08-22 04:06:47 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-08-22 04:06:47 --> Helper loaded: url_helper
DEBUG - 2011-08-22 04:06:47 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-22 04:06:47 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-22 04:06:47 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-22 04:06:47 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-22 04:06:47 --> Final output sent to browser
DEBUG - 2011-08-22 04:06:47 --> Total execution time: 0.1008
DEBUG - 2011-08-22 04:06:49 --> Config Class Initialized
DEBUG - 2011-08-22 04:06:49 --> Hooks Class Initialized
DEBUG - 2011-08-22 04:06:49 --> Utf8 Class Initialized
DEBUG - 2011-08-22 04:06:49 --> UTF-8 Support Enabled
DEBUG - 2011-08-22 04:06:49 --> URI Class Initialized
DEBUG - 2011-08-22 04:06:49 --> Router Class Initialized
DEBUG - 2011-08-22 04:06:49 --> Output Class Initialized
DEBUG - 2011-08-22 04:06:49 --> Input Class Initialized
DEBUG - 2011-08-22 04:06:49 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-22 04:06:49 --> Language Class Initialized
DEBUG - 2011-08-22 04:06:49 --> Loader Class Initialized
DEBUG - 2011-08-22 04:06:49 --> Controller Class Initialized
DEBUG - 2011-08-22 04:06:49 --> Model Class Initialized
DEBUG - 2011-08-22 04:06:49 --> Model Class Initialized
DEBUG - 2011-08-22 04:06:49 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-22 04:06:49 --> Database Driver Class Initialized
DEBUG - 2011-08-22 04:06:49 --> Final output sent to browser
DEBUG - 2011-08-22 04:06:49 --> Total execution time: 0.5095
DEBUG - 2011-08-22 04:06:51 --> Config Class Initialized
DEBUG - 2011-08-22 04:06:51 --> Hooks Class Initialized
DEBUG - 2011-08-22 04:06:51 --> Utf8 Class Initialized
DEBUG - 2011-08-22 04:06:51 --> UTF-8 Support Enabled
DEBUG - 2011-08-22 04:06:51 --> URI Class Initialized
DEBUG - 2011-08-22 04:06:51 --> Router Class Initialized
ERROR - 2011-08-22 04:06:51 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-08-22 04:18:55 --> Config Class Initialized
DEBUG - 2011-08-22 04:18:55 --> Hooks Class Initialized
DEBUG - 2011-08-22 04:18:55 --> Utf8 Class Initialized
DEBUG - 2011-08-22 04:18:55 --> UTF-8 Support Enabled
DEBUG - 2011-08-22 04:18:55 --> URI Class Initialized
DEBUG - 2011-08-22 04:18:55 --> Router Class Initialized
ERROR - 2011-08-22 04:18:55 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-08-22 04:19:49 --> Config Class Initialized
DEBUG - 2011-08-22 04:19:49 --> Hooks Class Initialized
DEBUG - 2011-08-22 04:19:49 --> Utf8 Class Initialized
DEBUG - 2011-08-22 04:19:49 --> UTF-8 Support Enabled
DEBUG - 2011-08-22 04:19:49 --> URI Class Initialized
DEBUG - 2011-08-22 04:19:49 --> Router Class Initialized
DEBUG - 2011-08-22 04:19:49 --> Output Class Initialized
DEBUG - 2011-08-22 04:19:49 --> Input Class Initialized
DEBUG - 2011-08-22 04:19:49 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-22 04:19:49 --> Language Class Initialized
DEBUG - 2011-08-22 04:19:49 --> Loader Class Initialized
DEBUG - 2011-08-22 04:19:49 --> Controller Class Initialized
DEBUG - 2011-08-22 04:19:49 --> Model Class Initialized
DEBUG - 2011-08-22 04:19:49 --> Model Class Initialized
DEBUG - 2011-08-22 04:19:49 --> Model Class Initialized
DEBUG - 2011-08-22 04:19:49 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-22 04:19:49 --> Database Driver Class Initialized
DEBUG - 2011-08-22 04:19:50 --> File loaded: application/views/table/main.php
DEBUG - 2011-08-22 04:19:50 --> Helper loaded: url_helper
DEBUG - 2011-08-22 04:19:50 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-22 04:19:50 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-22 04:19:50 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-22 04:19:50 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-22 04:19:50 --> Final output sent to browser
DEBUG - 2011-08-22 04:19:50 --> Total execution time: 1.0024
DEBUG - 2011-08-22 04:26:59 --> Config Class Initialized
DEBUG - 2011-08-22 04:26:59 --> Hooks Class Initialized
DEBUG - 2011-08-22 04:26:59 --> Utf8 Class Initialized
DEBUG - 2011-08-22 04:26:59 --> UTF-8 Support Enabled
DEBUG - 2011-08-22 04:26:59 --> URI Class Initialized
DEBUG - 2011-08-22 04:26:59 --> Router Class Initialized
DEBUG - 2011-08-22 04:26:59 --> Output Class Initialized
DEBUG - 2011-08-22 04:26:59 --> Input Class Initialized
DEBUG - 2011-08-22 04:26:59 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-22 04:26:59 --> Language Class Initialized
DEBUG - 2011-08-22 04:26:59 --> Loader Class Initialized
DEBUG - 2011-08-22 04:26:59 --> Controller Class Initialized
DEBUG - 2011-08-22 04:26:59 --> Model Class Initialized
DEBUG - 2011-08-22 04:26:59 --> Model Class Initialized
DEBUG - 2011-08-22 04:26:59 --> Model Class Initialized
DEBUG - 2011-08-22 04:26:59 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-22 04:26:59 --> Database Driver Class Initialized
DEBUG - 2011-08-22 04:26:59 --> File loaded: application/views/table/main.php
DEBUG - 2011-08-22 04:26:59 --> Helper loaded: url_helper
DEBUG - 2011-08-22 04:26:59 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-22 04:26:59 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-22 04:26:59 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-22 04:26:59 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-22 04:26:59 --> Final output sent to browser
DEBUG - 2011-08-22 04:26:59 --> Total execution time: 0.0606
DEBUG - 2011-08-22 04:27:15 --> Config Class Initialized
DEBUG - 2011-08-22 04:27:15 --> Hooks Class Initialized
DEBUG - 2011-08-22 04:27:15 --> Utf8 Class Initialized
DEBUG - 2011-08-22 04:27:15 --> UTF-8 Support Enabled
DEBUG - 2011-08-22 04:27:15 --> URI Class Initialized
DEBUG - 2011-08-22 04:27:15 --> Router Class Initialized
ERROR - 2011-08-22 04:27:15 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-08-22 04:27:17 --> Config Class Initialized
DEBUG - 2011-08-22 04:27:17 --> Hooks Class Initialized
DEBUG - 2011-08-22 04:27:17 --> Utf8 Class Initialized
DEBUG - 2011-08-22 04:27:17 --> UTF-8 Support Enabled
DEBUG - 2011-08-22 04:27:17 --> URI Class Initialized
DEBUG - 2011-08-22 04:27:17 --> Router Class Initialized
ERROR - 2011-08-22 04:27:17 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-08-22 05:32:51 --> Config Class Initialized
DEBUG - 2011-08-22 05:32:51 --> Hooks Class Initialized
DEBUG - 2011-08-22 05:32:51 --> Utf8 Class Initialized
DEBUG - 2011-08-22 05:32:51 --> UTF-8 Support Enabled
DEBUG - 2011-08-22 05:32:51 --> URI Class Initialized
DEBUG - 2011-08-22 05:32:51 --> Router Class Initialized
DEBUG - 2011-08-22 05:32:51 --> Output Class Initialized
DEBUG - 2011-08-22 05:32:51 --> Input Class Initialized
DEBUG - 2011-08-22 05:32:51 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-22 05:32:51 --> Language Class Initialized
DEBUG - 2011-08-22 05:32:51 --> Loader Class Initialized
DEBUG - 2011-08-22 05:32:51 --> Controller Class Initialized
ERROR - 2011-08-22 05:32:51 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-08-22 05:32:51 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-08-22 05:32:51 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-08-22 05:32:51 --> Model Class Initialized
DEBUG - 2011-08-22 05:32:51 --> Model Class Initialized
DEBUG - 2011-08-22 05:32:51 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-22 05:32:51 --> Database Driver Class Initialized
DEBUG - 2011-08-22 05:32:52 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-08-22 05:32:52 --> Helper loaded: url_helper
DEBUG - 2011-08-22 05:32:52 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-22 05:32:52 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-22 05:32:52 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-22 05:32:52 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-22 05:32:52 --> Final output sent to browser
DEBUG - 2011-08-22 05:32:52 --> Total execution time: 1.0108
DEBUG - 2011-08-22 05:32:54 --> Config Class Initialized
DEBUG - 2011-08-22 05:32:54 --> Hooks Class Initialized
DEBUG - 2011-08-22 05:32:54 --> Utf8 Class Initialized
DEBUG - 2011-08-22 05:32:54 --> UTF-8 Support Enabled
DEBUG - 2011-08-22 05:32:54 --> URI Class Initialized
DEBUG - 2011-08-22 05:32:54 --> Router Class Initialized
DEBUG - 2011-08-22 05:32:54 --> Output Class Initialized
DEBUG - 2011-08-22 05:32:54 --> Input Class Initialized
DEBUG - 2011-08-22 05:32:54 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-22 05:32:54 --> Language Class Initialized
DEBUG - 2011-08-22 05:32:54 --> Loader Class Initialized
DEBUG - 2011-08-22 05:32:54 --> Controller Class Initialized
DEBUG - 2011-08-22 05:32:54 --> Model Class Initialized
DEBUG - 2011-08-22 05:32:54 --> Model Class Initialized
DEBUG - 2011-08-22 05:32:54 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-22 05:32:54 --> Database Driver Class Initialized
DEBUG - 2011-08-22 05:32:55 --> Final output sent to browser
DEBUG - 2011-08-22 05:32:55 --> Total execution time: 0.6553
DEBUG - 2011-08-22 05:32:57 --> Config Class Initialized
DEBUG - 2011-08-22 05:32:57 --> Hooks Class Initialized
DEBUG - 2011-08-22 05:32:57 --> Utf8 Class Initialized
DEBUG - 2011-08-22 05:32:57 --> UTF-8 Support Enabled
DEBUG - 2011-08-22 05:32:57 --> URI Class Initialized
DEBUG - 2011-08-22 05:32:57 --> Router Class Initialized
ERROR - 2011-08-22 05:32:57 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-08-22 05:33:10 --> Config Class Initialized
DEBUG - 2011-08-22 05:33:10 --> Hooks Class Initialized
DEBUG - 2011-08-22 05:33:10 --> Utf8 Class Initialized
DEBUG - 2011-08-22 05:33:10 --> UTF-8 Support Enabled
DEBUG - 2011-08-22 05:33:10 --> URI Class Initialized
DEBUG - 2011-08-22 05:33:10 --> Router Class Initialized
DEBUG - 2011-08-22 05:33:10 --> Output Class Initialized
DEBUG - 2011-08-22 05:33:10 --> Input Class Initialized
DEBUG - 2011-08-22 05:33:10 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-22 05:33:10 --> Language Class Initialized
DEBUG - 2011-08-22 05:33:10 --> Loader Class Initialized
DEBUG - 2011-08-22 05:33:10 --> Controller Class Initialized
ERROR - 2011-08-22 05:33:10 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-08-22 05:33:10 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-08-22 05:33:10 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-08-22 05:33:10 --> Model Class Initialized
DEBUG - 2011-08-22 05:33:10 --> Model Class Initialized
DEBUG - 2011-08-22 05:33:10 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-22 05:33:10 --> Database Driver Class Initialized
DEBUG - 2011-08-22 05:33:10 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-08-22 05:33:10 --> Helper loaded: url_helper
DEBUG - 2011-08-22 05:33:10 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-22 05:33:10 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-22 05:33:10 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-22 05:33:10 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-22 05:33:10 --> Final output sent to browser
DEBUG - 2011-08-22 05:33:10 --> Total execution time: 0.0288
DEBUG - 2011-08-22 05:33:10 --> Config Class Initialized
DEBUG - 2011-08-22 05:33:10 --> Hooks Class Initialized
DEBUG - 2011-08-22 05:33:10 --> Utf8 Class Initialized
DEBUG - 2011-08-22 05:33:10 --> UTF-8 Support Enabled
DEBUG - 2011-08-22 05:33:10 --> URI Class Initialized
DEBUG - 2011-08-22 05:33:10 --> Router Class Initialized
DEBUG - 2011-08-22 05:33:10 --> Output Class Initialized
DEBUG - 2011-08-22 05:33:11 --> Input Class Initialized
DEBUG - 2011-08-22 05:33:11 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-22 05:33:11 --> Language Class Initialized
DEBUG - 2011-08-22 05:33:11 --> Loader Class Initialized
DEBUG - 2011-08-22 05:33:11 --> Controller Class Initialized
DEBUG - 2011-08-22 05:33:11 --> Model Class Initialized
DEBUG - 2011-08-22 05:33:11 --> Model Class Initialized
DEBUG - 2011-08-22 05:33:11 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-22 05:33:11 --> Database Driver Class Initialized
DEBUG - 2011-08-22 05:33:11 --> Final output sent to browser
DEBUG - 2011-08-22 05:33:11 --> Total execution time: 0.5114
DEBUG - 2011-08-22 05:33:30 --> Config Class Initialized
DEBUG - 2011-08-22 05:33:30 --> Hooks Class Initialized
DEBUG - 2011-08-22 05:33:30 --> Utf8 Class Initialized
DEBUG - 2011-08-22 05:33:30 --> UTF-8 Support Enabled
DEBUG - 2011-08-22 05:33:30 --> URI Class Initialized
DEBUG - 2011-08-22 05:33:30 --> Router Class Initialized
DEBUG - 2011-08-22 05:33:30 --> Output Class Initialized
DEBUG - 2011-08-22 05:33:30 --> Input Class Initialized
DEBUG - 2011-08-22 05:33:30 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-22 05:33:30 --> Language Class Initialized
DEBUG - 2011-08-22 05:33:30 --> Loader Class Initialized
DEBUG - 2011-08-22 05:33:30 --> Controller Class Initialized
ERROR - 2011-08-22 05:33:30 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-08-22 05:33:30 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-08-22 05:33:30 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-08-22 05:33:30 --> Model Class Initialized
DEBUG - 2011-08-22 05:33:30 --> Model Class Initialized
DEBUG - 2011-08-22 05:33:30 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-22 05:33:30 --> Database Driver Class Initialized
DEBUG - 2011-08-22 05:33:30 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-08-22 05:33:30 --> Helper loaded: url_helper
DEBUG - 2011-08-22 05:33:30 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-22 05:33:30 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-22 05:33:30 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-22 05:33:30 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-22 05:33:30 --> Final output sent to browser
DEBUG - 2011-08-22 05:33:30 --> Total execution time: 0.0301
DEBUG - 2011-08-22 05:33:31 --> Config Class Initialized
DEBUG - 2011-08-22 05:33:31 --> Hooks Class Initialized
DEBUG - 2011-08-22 05:33:31 --> Utf8 Class Initialized
DEBUG - 2011-08-22 05:33:31 --> UTF-8 Support Enabled
DEBUG - 2011-08-22 05:33:31 --> URI Class Initialized
DEBUG - 2011-08-22 05:33:31 --> Router Class Initialized
DEBUG - 2011-08-22 05:33:31 --> Output Class Initialized
DEBUG - 2011-08-22 05:33:31 --> Input Class Initialized
DEBUG - 2011-08-22 05:33:31 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-22 05:33:31 --> Language Class Initialized
DEBUG - 2011-08-22 05:33:31 --> Loader Class Initialized
DEBUG - 2011-08-22 05:33:31 --> Controller Class Initialized
DEBUG - 2011-08-22 05:33:31 --> Model Class Initialized
DEBUG - 2011-08-22 05:33:31 --> Model Class Initialized
DEBUG - 2011-08-22 05:33:31 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-22 05:33:31 --> Database Driver Class Initialized
DEBUG - 2011-08-22 05:33:31 --> Final output sent to browser
DEBUG - 2011-08-22 05:33:31 --> Total execution time: 0.5449
DEBUG - 2011-08-22 05:49:02 --> Config Class Initialized
DEBUG - 2011-08-22 05:49:02 --> Hooks Class Initialized
DEBUG - 2011-08-22 05:49:02 --> Utf8 Class Initialized
DEBUG - 2011-08-22 05:49:02 --> UTF-8 Support Enabled
DEBUG - 2011-08-22 05:49:02 --> URI Class Initialized
DEBUG - 2011-08-22 05:49:02 --> Router Class Initialized
DEBUG - 2011-08-22 05:49:02 --> No URI present. Default controller set.
DEBUG - 2011-08-22 05:49:02 --> Output Class Initialized
DEBUG - 2011-08-22 05:49:02 --> Input Class Initialized
DEBUG - 2011-08-22 05:49:02 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-22 05:49:02 --> Language Class Initialized
DEBUG - 2011-08-22 05:49:02 --> Loader Class Initialized
DEBUG - 2011-08-22 05:49:02 --> Controller Class Initialized
DEBUG - 2011-08-22 05:49:02 --> File loaded: application/views/splash/main.php
DEBUG - 2011-08-22 05:49:02 --> Helper loaded: url_helper
DEBUG - 2011-08-22 05:49:02 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-22 05:49:02 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-22 05:49:02 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-22 05:49:02 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-22 05:49:02 --> Final output sent to browser
DEBUG - 2011-08-22 05:49:02 --> Total execution time: 0.0693
DEBUG - 2011-08-22 06:00:34 --> Config Class Initialized
DEBUG - 2011-08-22 06:00:34 --> Hooks Class Initialized
DEBUG - 2011-08-22 06:00:34 --> Utf8 Class Initialized
DEBUG - 2011-08-22 06:00:34 --> UTF-8 Support Enabled
DEBUG - 2011-08-22 06:00:34 --> URI Class Initialized
DEBUG - 2011-08-22 06:00:34 --> Router Class Initialized
DEBUG - 2011-08-22 06:00:34 --> Output Class Initialized
DEBUG - 2011-08-22 06:00:34 --> Input Class Initialized
DEBUG - 2011-08-22 06:00:34 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-22 06:00:34 --> Language Class Initialized
DEBUG - 2011-08-22 06:00:34 --> Loader Class Initialized
DEBUG - 2011-08-22 06:00:34 --> Controller Class Initialized
ERROR - 2011-08-22 06:00:34 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-08-22 06:00:34 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-08-22 06:00:34 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-08-22 06:00:34 --> Model Class Initialized
DEBUG - 2011-08-22 06:00:34 --> Model Class Initialized
DEBUG - 2011-08-22 06:00:34 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-22 06:00:34 --> Config Class Initialized
DEBUG - 2011-08-22 06:00:34 --> Hooks Class Initialized
DEBUG - 2011-08-22 06:00:34 --> Utf8 Class Initialized
DEBUG - 2011-08-22 06:00:34 --> UTF-8 Support Enabled
DEBUG - 2011-08-22 06:00:34 --> URI Class Initialized
DEBUG - 2011-08-22 06:00:34 --> Router Class Initialized
DEBUG - 2011-08-22 06:00:34 --> Output Class Initialized
DEBUG - 2011-08-22 06:00:34 --> Database Driver Class Initialized
DEBUG - 2011-08-22 06:00:34 --> Input Class Initialized
DEBUG - 2011-08-22 06:00:34 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-22 06:00:34 --> Language Class Initialized
DEBUG - 2011-08-22 06:00:34 --> Loader Class Initialized
DEBUG - 2011-08-22 06:00:34 --> Controller Class Initialized
DEBUG - 2011-08-22 06:00:34 --> Model Class Initialized
DEBUG - 2011-08-22 06:00:34 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-08-22 06:00:34 --> Helper loaded: url_helper
DEBUG - 2011-08-22 06:00:34 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-22 06:00:34 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-22 06:00:34 --> Model Class Initialized
DEBUG - 2011-08-22 06:00:34 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-22 06:00:34 --> Model Class Initialized
DEBUG - 2011-08-22 06:00:34 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-22 06:00:34 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-22 06:00:34 --> Final output sent to browser
DEBUG - 2011-08-22 06:00:34 --> Total execution time: 0.1344
DEBUG - 2011-08-22 06:00:34 --> Database Driver Class Initialized
DEBUG - 2011-08-22 06:00:34 --> File loaded: application/views/table/main.php
DEBUG - 2011-08-22 06:00:34 --> Helper loaded: url_helper
DEBUG - 2011-08-22 06:00:34 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-22 06:00:34 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-22 06:00:34 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-22 06:00:34 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-22 06:00:34 --> Final output sent to browser
DEBUG - 2011-08-22 06:00:34 --> Total execution time: 0.3485
DEBUG - 2011-08-22 06:00:35 --> Config Class Initialized
DEBUG - 2011-08-22 06:00:35 --> Hooks Class Initialized
DEBUG - 2011-08-22 06:00:35 --> Utf8 Class Initialized
DEBUG - 2011-08-22 06:00:35 --> UTF-8 Support Enabled
DEBUG - 2011-08-22 06:00:35 --> URI Class Initialized
DEBUG - 2011-08-22 06:00:35 --> Router Class Initialized
ERROR - 2011-08-22 06:00:35 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-08-22 06:00:36 --> Config Class Initialized
DEBUG - 2011-08-22 06:00:36 --> Hooks Class Initialized
DEBUG - 2011-08-22 06:00:36 --> Utf8 Class Initialized
DEBUG - 2011-08-22 06:00:36 --> UTF-8 Support Enabled
DEBUG - 2011-08-22 06:00:36 --> URI Class Initialized
DEBUG - 2011-08-22 06:00:36 --> Router Class Initialized
DEBUG - 2011-08-22 06:00:36 --> Output Class Initialized
DEBUG - 2011-08-22 06:00:36 --> Input Class Initialized
DEBUG - 2011-08-22 06:00:36 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-22 06:00:36 --> Language Class Initialized
DEBUG - 2011-08-22 06:00:36 --> Loader Class Initialized
DEBUG - 2011-08-22 06:00:36 --> Controller Class Initialized
DEBUG - 2011-08-22 06:00:36 --> Model Class Initialized
DEBUG - 2011-08-22 06:00:36 --> Model Class Initialized
DEBUG - 2011-08-22 06:00:36 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-22 06:00:36 --> Database Driver Class Initialized
DEBUG - 2011-08-22 06:00:37 --> Final output sent to browser
DEBUG - 2011-08-22 06:00:37 --> Total execution time: 0.5761
DEBUG - 2011-08-22 06:49:43 --> Config Class Initialized
DEBUG - 2011-08-22 06:49:43 --> Hooks Class Initialized
DEBUG - 2011-08-22 06:49:43 --> Utf8 Class Initialized
DEBUG - 2011-08-22 06:49:43 --> UTF-8 Support Enabled
DEBUG - 2011-08-22 06:49:43 --> URI Class Initialized
DEBUG - 2011-08-22 06:49:43 --> Router Class Initialized
DEBUG - 2011-08-22 06:49:43 --> Output Class Initialized
DEBUG - 2011-08-22 06:49:43 --> Input Class Initialized
DEBUG - 2011-08-22 06:49:43 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-22 06:49:43 --> Language Class Initialized
DEBUG - 2011-08-22 06:49:43 --> Loader Class Initialized
DEBUG - 2011-08-22 06:49:43 --> Controller Class Initialized
ERROR - 2011-08-22 06:49:43 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-08-22 06:49:43 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-08-22 06:49:43 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-08-22 06:49:43 --> Model Class Initialized
DEBUG - 2011-08-22 06:49:43 --> Model Class Initialized
DEBUG - 2011-08-22 06:49:43 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-22 06:49:43 --> Database Driver Class Initialized
DEBUG - 2011-08-22 06:49:43 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-08-22 06:49:43 --> Helper loaded: url_helper
DEBUG - 2011-08-22 06:49:43 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-22 06:49:43 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-22 06:49:43 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-22 06:49:43 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-22 06:49:43 --> Final output sent to browser
DEBUG - 2011-08-22 06:49:43 --> Total execution time: 0.3399
DEBUG - 2011-08-22 06:49:45 --> Config Class Initialized
DEBUG - 2011-08-22 06:49:45 --> Hooks Class Initialized
DEBUG - 2011-08-22 06:49:45 --> Utf8 Class Initialized
DEBUG - 2011-08-22 06:49:45 --> UTF-8 Support Enabled
DEBUG - 2011-08-22 06:49:45 --> URI Class Initialized
DEBUG - 2011-08-22 06:49:45 --> Router Class Initialized
DEBUG - 2011-08-22 06:49:45 --> Output Class Initialized
DEBUG - 2011-08-22 06:49:45 --> Input Class Initialized
DEBUG - 2011-08-22 06:49:45 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-22 06:49:45 --> Language Class Initialized
DEBUG - 2011-08-22 06:49:45 --> Loader Class Initialized
DEBUG - 2011-08-22 06:49:45 --> Controller Class Initialized
DEBUG - 2011-08-22 06:49:45 --> Model Class Initialized
DEBUG - 2011-08-22 06:49:45 --> Model Class Initialized
DEBUG - 2011-08-22 06:49:45 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-22 06:49:45 --> Database Driver Class Initialized
DEBUG - 2011-08-22 06:49:46 --> Final output sent to browser
DEBUG - 2011-08-22 06:49:46 --> Total execution time: 0.5966
DEBUG - 2011-08-22 06:49:48 --> Config Class Initialized
DEBUG - 2011-08-22 06:49:48 --> Hooks Class Initialized
DEBUG - 2011-08-22 06:49:48 --> Utf8 Class Initialized
DEBUG - 2011-08-22 06:49:48 --> UTF-8 Support Enabled
DEBUG - 2011-08-22 06:49:48 --> URI Class Initialized
DEBUG - 2011-08-22 06:49:48 --> Router Class Initialized
ERROR - 2011-08-22 06:49:48 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-08-22 06:49:48 --> Config Class Initialized
DEBUG - 2011-08-22 06:49:48 --> Hooks Class Initialized
DEBUG - 2011-08-22 06:49:48 --> Utf8 Class Initialized
DEBUG - 2011-08-22 06:49:48 --> UTF-8 Support Enabled
DEBUG - 2011-08-22 06:49:48 --> URI Class Initialized
DEBUG - 2011-08-22 06:49:48 --> Router Class Initialized
ERROR - 2011-08-22 06:49:48 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-08-22 06:49:58 --> Config Class Initialized
DEBUG - 2011-08-22 06:49:58 --> Hooks Class Initialized
DEBUG - 2011-08-22 06:49:58 --> Utf8 Class Initialized
DEBUG - 2011-08-22 06:49:58 --> UTF-8 Support Enabled
DEBUG - 2011-08-22 06:49:58 --> URI Class Initialized
DEBUG - 2011-08-22 06:49:58 --> Router Class Initialized
DEBUG - 2011-08-22 06:49:58 --> Output Class Initialized
DEBUG - 2011-08-22 06:49:58 --> Input Class Initialized
DEBUG - 2011-08-22 06:49:58 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-22 06:49:58 --> Language Class Initialized
DEBUG - 2011-08-22 06:49:58 --> Loader Class Initialized
DEBUG - 2011-08-22 06:49:58 --> Controller Class Initialized
ERROR - 2011-08-22 06:49:58 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-08-22 06:49:58 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-08-22 06:49:58 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-08-22 06:49:58 --> Model Class Initialized
DEBUG - 2011-08-22 06:49:58 --> Model Class Initialized
DEBUG - 2011-08-22 06:49:58 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-22 06:49:58 --> Database Driver Class Initialized
DEBUG - 2011-08-22 06:49:58 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-08-22 06:49:58 --> Helper loaded: url_helper
DEBUG - 2011-08-22 06:49:58 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-22 06:49:58 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-22 06:49:58 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-22 06:49:58 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-22 06:49:58 --> Final output sent to browser
DEBUG - 2011-08-22 06:49:58 --> Total execution time: 0.0273
DEBUG - 2011-08-22 06:50:00 --> Config Class Initialized
DEBUG - 2011-08-22 06:50:00 --> Hooks Class Initialized
DEBUG - 2011-08-22 06:50:00 --> Utf8 Class Initialized
DEBUG - 2011-08-22 06:50:00 --> UTF-8 Support Enabled
DEBUG - 2011-08-22 06:50:00 --> URI Class Initialized
DEBUG - 2011-08-22 06:50:00 --> Router Class Initialized
DEBUG - 2011-08-22 06:50:00 --> Output Class Initialized
DEBUG - 2011-08-22 06:50:00 --> Input Class Initialized
DEBUG - 2011-08-22 06:50:00 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-22 06:50:00 --> Language Class Initialized
DEBUG - 2011-08-22 06:50:00 --> Loader Class Initialized
DEBUG - 2011-08-22 06:50:00 --> Controller Class Initialized
DEBUG - 2011-08-22 06:50:00 --> Model Class Initialized
DEBUG - 2011-08-22 06:50:00 --> Model Class Initialized
DEBUG - 2011-08-22 06:50:00 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-22 06:50:00 --> Database Driver Class Initialized
DEBUG - 2011-08-22 06:50:00 --> Final output sent to browser
DEBUG - 2011-08-22 06:50:00 --> Total execution time: 0.6665
DEBUG - 2011-08-22 06:50:15 --> Config Class Initialized
DEBUG - 2011-08-22 06:50:15 --> Hooks Class Initialized
DEBUG - 2011-08-22 06:50:15 --> Utf8 Class Initialized
DEBUG - 2011-08-22 06:50:15 --> UTF-8 Support Enabled
DEBUG - 2011-08-22 06:50:15 --> URI Class Initialized
DEBUG - 2011-08-22 06:50:15 --> Router Class Initialized
DEBUG - 2011-08-22 06:50:15 --> Output Class Initialized
DEBUG - 2011-08-22 06:50:15 --> Input Class Initialized
DEBUG - 2011-08-22 06:50:15 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-22 06:50:15 --> Language Class Initialized
DEBUG - 2011-08-22 06:50:15 --> Loader Class Initialized
DEBUG - 2011-08-22 06:50:15 --> Controller Class Initialized
ERROR - 2011-08-22 06:50:15 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-08-22 06:50:15 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-08-22 06:50:15 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-08-22 06:50:15 --> Model Class Initialized
DEBUG - 2011-08-22 06:50:15 --> Model Class Initialized
DEBUG - 2011-08-22 06:50:15 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-22 06:50:15 --> Database Driver Class Initialized
DEBUG - 2011-08-22 06:50:15 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-08-22 06:50:15 --> Helper loaded: url_helper
DEBUG - 2011-08-22 06:50:15 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-22 06:50:15 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-22 06:50:15 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-22 06:50:15 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-22 06:50:15 --> Final output sent to browser
DEBUG - 2011-08-22 06:50:15 --> Total execution time: 0.0347
DEBUG - 2011-08-22 06:50:16 --> Config Class Initialized
DEBUG - 2011-08-22 06:50:16 --> Hooks Class Initialized
DEBUG - 2011-08-22 06:50:16 --> Utf8 Class Initialized
DEBUG - 2011-08-22 06:50:16 --> UTF-8 Support Enabled
DEBUG - 2011-08-22 06:50:16 --> URI Class Initialized
DEBUG - 2011-08-22 06:50:16 --> Router Class Initialized
DEBUG - 2011-08-22 06:50:16 --> Output Class Initialized
DEBUG - 2011-08-22 06:50:16 --> Input Class Initialized
DEBUG - 2011-08-22 06:50:16 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-22 06:50:16 --> Language Class Initialized
DEBUG - 2011-08-22 06:50:16 --> Loader Class Initialized
DEBUG - 2011-08-22 06:50:16 --> Controller Class Initialized
DEBUG - 2011-08-22 06:50:16 --> Model Class Initialized
DEBUG - 2011-08-22 06:50:16 --> Model Class Initialized
DEBUG - 2011-08-22 06:50:16 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-22 06:50:16 --> Database Driver Class Initialized
DEBUG - 2011-08-22 06:50:17 --> Final output sent to browser
DEBUG - 2011-08-22 06:50:17 --> Total execution time: 0.4698
DEBUG - 2011-08-22 08:43:08 --> Config Class Initialized
DEBUG - 2011-08-22 08:43:08 --> Hooks Class Initialized
DEBUG - 2011-08-22 08:43:08 --> Utf8 Class Initialized
DEBUG - 2011-08-22 08:43:08 --> UTF-8 Support Enabled
DEBUG - 2011-08-22 08:43:08 --> URI Class Initialized
DEBUG - 2011-08-22 08:43:08 --> Router Class Initialized
DEBUG - 2011-08-22 08:43:08 --> Output Class Initialized
DEBUG - 2011-08-22 08:43:08 --> Input Class Initialized
DEBUG - 2011-08-22 08:43:08 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-22 08:43:08 --> Language Class Initialized
DEBUG - 2011-08-22 08:43:08 --> Loader Class Initialized
DEBUG - 2011-08-22 08:43:08 --> Controller Class Initialized
ERROR - 2011-08-22 08:43:08 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-08-22 08:43:08 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-08-22 08:43:08 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-08-22 08:43:08 --> Model Class Initialized
DEBUG - 2011-08-22 08:43:08 --> Model Class Initialized
DEBUG - 2011-08-22 08:43:08 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-22 08:43:08 --> Database Driver Class Initialized
DEBUG - 2011-08-22 08:43:08 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-08-22 08:43:08 --> Helper loaded: url_helper
DEBUG - 2011-08-22 08:43:08 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-22 08:43:08 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-22 08:43:08 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-22 08:43:08 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-22 08:43:08 --> Final output sent to browser
DEBUG - 2011-08-22 08:43:08 --> Total execution time: 0.3651
DEBUG - 2011-08-22 08:43:11 --> Config Class Initialized
DEBUG - 2011-08-22 08:43:11 --> Hooks Class Initialized
DEBUG - 2011-08-22 08:43:11 --> Utf8 Class Initialized
DEBUG - 2011-08-22 08:43:11 --> UTF-8 Support Enabled
DEBUG - 2011-08-22 08:43:11 --> URI Class Initialized
DEBUG - 2011-08-22 08:43:11 --> Router Class Initialized
DEBUG - 2011-08-22 08:43:11 --> Output Class Initialized
DEBUG - 2011-08-22 08:43:11 --> Input Class Initialized
DEBUG - 2011-08-22 08:43:11 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-22 08:43:11 --> Language Class Initialized
DEBUG - 2011-08-22 08:43:11 --> Loader Class Initialized
DEBUG - 2011-08-22 08:43:11 --> Controller Class Initialized
DEBUG - 2011-08-22 08:43:11 --> Model Class Initialized
DEBUG - 2011-08-22 08:43:11 --> Model Class Initialized
DEBUG - 2011-08-22 08:43:11 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-22 08:43:11 --> Database Driver Class Initialized
DEBUG - 2011-08-22 08:43:11 --> Final output sent to browser
DEBUG - 2011-08-22 08:43:11 --> Total execution time: 0.5416
DEBUG - 2011-08-22 08:43:53 --> Config Class Initialized
DEBUG - 2011-08-22 08:43:53 --> Hooks Class Initialized
DEBUG - 2011-08-22 08:43:53 --> Utf8 Class Initialized
DEBUG - 2011-08-22 08:43:53 --> UTF-8 Support Enabled
DEBUG - 2011-08-22 08:43:53 --> URI Class Initialized
DEBUG - 2011-08-22 08:43:53 --> Router Class Initialized
DEBUG - 2011-08-22 08:43:53 --> Output Class Initialized
DEBUG - 2011-08-22 08:43:53 --> Input Class Initialized
DEBUG - 2011-08-22 08:43:53 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-22 08:43:53 --> Language Class Initialized
DEBUG - 2011-08-22 08:43:53 --> Loader Class Initialized
DEBUG - 2011-08-22 08:43:53 --> Controller Class Initialized
ERROR - 2011-08-22 08:43:53 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-08-22 08:43:53 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-08-22 08:43:53 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-08-22 08:43:53 --> Model Class Initialized
DEBUG - 2011-08-22 08:43:53 --> Model Class Initialized
DEBUG - 2011-08-22 08:43:53 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-22 08:43:53 --> Database Driver Class Initialized
DEBUG - 2011-08-22 08:43:53 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-08-22 08:43:53 --> Helper loaded: url_helper
DEBUG - 2011-08-22 08:43:53 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-22 08:43:53 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-22 08:43:53 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-22 08:43:53 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-22 08:43:53 --> Final output sent to browser
DEBUG - 2011-08-22 08:43:53 --> Total execution time: 0.0295
DEBUG - 2011-08-22 08:43:54 --> Config Class Initialized
DEBUG - 2011-08-22 08:43:54 --> Hooks Class Initialized
DEBUG - 2011-08-22 08:43:54 --> Utf8 Class Initialized
DEBUG - 2011-08-22 08:43:54 --> UTF-8 Support Enabled
DEBUG - 2011-08-22 08:43:54 --> URI Class Initialized
DEBUG - 2011-08-22 08:43:54 --> Router Class Initialized
DEBUG - 2011-08-22 08:43:54 --> Output Class Initialized
DEBUG - 2011-08-22 08:43:54 --> Input Class Initialized
DEBUG - 2011-08-22 08:43:54 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-22 08:43:54 --> Language Class Initialized
DEBUG - 2011-08-22 08:43:54 --> Loader Class Initialized
DEBUG - 2011-08-22 08:43:54 --> Controller Class Initialized
DEBUG - 2011-08-22 08:43:54 --> Model Class Initialized
DEBUG - 2011-08-22 08:43:54 --> Model Class Initialized
DEBUG - 2011-08-22 08:43:54 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-22 08:43:54 --> Database Driver Class Initialized
DEBUG - 2011-08-22 08:43:54 --> Final output sent to browser
DEBUG - 2011-08-22 08:43:54 --> Total execution time: 0.5711
DEBUG - 2011-08-22 09:06:57 --> Config Class Initialized
DEBUG - 2011-08-22 09:06:57 --> Hooks Class Initialized
DEBUG - 2011-08-22 09:06:57 --> Utf8 Class Initialized
DEBUG - 2011-08-22 09:06:57 --> UTF-8 Support Enabled
DEBUG - 2011-08-22 09:06:57 --> URI Class Initialized
DEBUG - 2011-08-22 09:06:57 --> Router Class Initialized
ERROR - 2011-08-22 09:06:57 --> 404 Page Not Found --> robots.txt
DEBUG - 2011-08-22 10:30:48 --> Config Class Initialized
DEBUG - 2011-08-22 10:30:48 --> Hooks Class Initialized
DEBUG - 2011-08-22 10:30:48 --> Utf8 Class Initialized
DEBUG - 2011-08-22 10:30:48 --> UTF-8 Support Enabled
DEBUG - 2011-08-22 10:30:48 --> URI Class Initialized
DEBUG - 2011-08-22 10:30:48 --> Router Class Initialized
DEBUG - 2011-08-22 10:30:48 --> Output Class Initialized
DEBUG - 2011-08-22 10:30:48 --> Input Class Initialized
DEBUG - 2011-08-22 10:30:48 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-22 10:30:48 --> Language Class Initialized
DEBUG - 2011-08-22 10:30:48 --> Loader Class Initialized
DEBUG - 2011-08-22 10:30:48 --> Controller Class Initialized
ERROR - 2011-08-22 10:30:48 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-08-22 10:30:48 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-08-22 10:30:48 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-08-22 10:30:48 --> Model Class Initialized
DEBUG - 2011-08-22 10:30:48 --> Model Class Initialized
DEBUG - 2011-08-22 10:30:48 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-22 10:30:48 --> Database Driver Class Initialized
DEBUG - 2011-08-22 10:30:49 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-08-22 10:30:49 --> Helper loaded: url_helper
DEBUG - 2011-08-22 10:30:49 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-22 10:30:49 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-22 10:30:49 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-22 10:30:49 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-22 10:30:49 --> Final output sent to browser
DEBUG - 2011-08-22 10:30:49 --> Total execution time: 0.3187
DEBUG - 2011-08-22 10:30:50 --> Config Class Initialized
DEBUG - 2011-08-22 10:30:50 --> Hooks Class Initialized
DEBUG - 2011-08-22 10:30:50 --> Utf8 Class Initialized
DEBUG - 2011-08-22 10:30:50 --> UTF-8 Support Enabled
DEBUG - 2011-08-22 10:30:50 --> URI Class Initialized
DEBUG - 2011-08-22 10:30:50 --> Router Class Initialized
DEBUG - 2011-08-22 10:30:50 --> Output Class Initialized
DEBUG - 2011-08-22 10:30:50 --> Input Class Initialized
DEBUG - 2011-08-22 10:30:50 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-22 10:30:50 --> Language Class Initialized
DEBUG - 2011-08-22 10:30:50 --> Loader Class Initialized
DEBUG - 2011-08-22 10:30:50 --> Controller Class Initialized
DEBUG - 2011-08-22 10:30:50 --> Model Class Initialized
DEBUG - 2011-08-22 10:30:50 --> Model Class Initialized
DEBUG - 2011-08-22 10:30:50 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-22 10:30:50 --> Database Driver Class Initialized
DEBUG - 2011-08-22 10:30:51 --> Final output sent to browser
DEBUG - 2011-08-22 10:30:51 --> Total execution time: 0.5575
DEBUG - 2011-08-22 10:30:53 --> Config Class Initialized
DEBUG - 2011-08-22 10:30:53 --> Hooks Class Initialized
DEBUG - 2011-08-22 10:30:53 --> Utf8 Class Initialized
DEBUG - 2011-08-22 10:30:53 --> UTF-8 Support Enabled
DEBUG - 2011-08-22 10:30:53 --> URI Class Initialized
DEBUG - 2011-08-22 10:30:53 --> Router Class Initialized
ERROR - 2011-08-22 10:30:53 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-08-22 10:32:26 --> Config Class Initialized
DEBUG - 2011-08-22 10:32:26 --> Hooks Class Initialized
DEBUG - 2011-08-22 10:32:26 --> Utf8 Class Initialized
DEBUG - 2011-08-22 10:32:26 --> UTF-8 Support Enabled
DEBUG - 2011-08-22 10:32:26 --> URI Class Initialized
DEBUG - 2011-08-22 10:32:26 --> Router Class Initialized
DEBUG - 2011-08-22 10:32:26 --> Output Class Initialized
DEBUG - 2011-08-22 10:32:26 --> Input Class Initialized
DEBUG - 2011-08-22 10:32:26 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-22 10:32:26 --> Language Class Initialized
DEBUG - 2011-08-22 10:32:26 --> Loader Class Initialized
DEBUG - 2011-08-22 10:32:26 --> Controller Class Initialized
ERROR - 2011-08-22 10:32:26 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-08-22 10:32:26 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-08-22 10:32:26 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-08-22 10:32:26 --> Model Class Initialized
DEBUG - 2011-08-22 10:32:26 --> Model Class Initialized
DEBUG - 2011-08-22 10:32:26 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-22 10:32:26 --> Database Driver Class Initialized
DEBUG - 2011-08-22 10:32:26 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-08-22 10:32:26 --> Helper loaded: url_helper
DEBUG - 2011-08-22 10:32:26 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-22 10:32:26 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-22 10:32:26 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-22 10:32:26 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-22 10:32:26 --> Final output sent to browser
DEBUG - 2011-08-22 10:32:26 --> Total execution time: 0.0282
DEBUG - 2011-08-22 10:32:28 --> Config Class Initialized
DEBUG - 2011-08-22 10:32:28 --> Hooks Class Initialized
DEBUG - 2011-08-22 10:32:28 --> Utf8 Class Initialized
DEBUG - 2011-08-22 10:32:28 --> UTF-8 Support Enabled
DEBUG - 2011-08-22 10:32:28 --> URI Class Initialized
DEBUG - 2011-08-22 10:32:28 --> Router Class Initialized
DEBUG - 2011-08-22 10:32:28 --> Output Class Initialized
DEBUG - 2011-08-22 10:32:28 --> Input Class Initialized
DEBUG - 2011-08-22 10:32:28 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-22 10:32:28 --> Language Class Initialized
DEBUG - 2011-08-22 10:32:28 --> Loader Class Initialized
DEBUG - 2011-08-22 10:32:28 --> Controller Class Initialized
DEBUG - 2011-08-22 10:32:28 --> Model Class Initialized
DEBUG - 2011-08-22 10:32:28 --> Model Class Initialized
DEBUG - 2011-08-22 10:32:28 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-22 10:32:28 --> Database Driver Class Initialized
DEBUG - 2011-08-22 10:32:28 --> Final output sent to browser
DEBUG - 2011-08-22 10:32:28 --> Total execution time: 0.4304
DEBUG - 2011-08-22 10:32:42 --> Config Class Initialized
DEBUG - 2011-08-22 10:32:42 --> Hooks Class Initialized
DEBUG - 2011-08-22 10:32:42 --> Utf8 Class Initialized
DEBUG - 2011-08-22 10:32:42 --> UTF-8 Support Enabled
DEBUG - 2011-08-22 10:32:42 --> URI Class Initialized
DEBUG - 2011-08-22 10:32:42 --> Router Class Initialized
DEBUG - 2011-08-22 10:32:42 --> Output Class Initialized
DEBUG - 2011-08-22 10:32:42 --> Input Class Initialized
DEBUG - 2011-08-22 10:32:42 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-22 10:32:42 --> Language Class Initialized
DEBUG - 2011-08-22 10:32:42 --> Loader Class Initialized
DEBUG - 2011-08-22 10:32:42 --> Controller Class Initialized
ERROR - 2011-08-22 10:32:42 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-08-22 10:32:42 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-08-22 10:32:42 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-08-22 10:32:42 --> Model Class Initialized
DEBUG - 2011-08-22 10:32:42 --> Model Class Initialized
DEBUG - 2011-08-22 10:32:42 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-22 10:32:42 --> Database Driver Class Initialized
DEBUG - 2011-08-22 10:32:42 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-08-22 10:32:42 --> Helper loaded: url_helper
DEBUG - 2011-08-22 10:32:42 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-22 10:32:42 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-22 10:32:42 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-22 10:32:42 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-22 10:32:42 --> Final output sent to browser
DEBUG - 2011-08-22 10:32:42 --> Total execution time: 0.0435
DEBUG - 2011-08-22 10:32:44 --> Config Class Initialized
DEBUG - 2011-08-22 10:32:44 --> Hooks Class Initialized
DEBUG - 2011-08-22 10:32:44 --> Utf8 Class Initialized
DEBUG - 2011-08-22 10:32:44 --> UTF-8 Support Enabled
DEBUG - 2011-08-22 10:32:44 --> URI Class Initialized
DEBUG - 2011-08-22 10:32:44 --> Router Class Initialized
ERROR - 2011-08-22 10:32:44 --> 404 Page Not Found --> robots.txt
DEBUG - 2011-08-22 10:32:44 --> Config Class Initialized
DEBUG - 2011-08-22 10:32:44 --> Hooks Class Initialized
DEBUG - 2011-08-22 10:32:44 --> Utf8 Class Initialized
DEBUG - 2011-08-22 10:32:44 --> UTF-8 Support Enabled
DEBUG - 2011-08-22 10:32:44 --> URI Class Initialized
DEBUG - 2011-08-22 10:32:44 --> Router Class Initialized
DEBUG - 2011-08-22 10:32:44 --> Output Class Initialized
DEBUG - 2011-08-22 10:32:44 --> Input Class Initialized
DEBUG - 2011-08-22 10:32:44 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-22 10:32:44 --> Language Class Initialized
DEBUG - 2011-08-22 10:32:44 --> Loader Class Initialized
DEBUG - 2011-08-22 10:32:44 --> Controller Class Initialized
ERROR - 2011-08-22 10:32:44 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-08-22 10:32:44 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-08-22 10:32:44 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-08-22 10:32:44 --> Model Class Initialized
DEBUG - 2011-08-22 10:32:44 --> Model Class Initialized
DEBUG - 2011-08-22 10:32:44 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-22 10:32:44 --> Database Driver Class Initialized
DEBUG - 2011-08-22 10:32:44 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-08-22 10:32:44 --> Helper loaded: url_helper
DEBUG - 2011-08-22 10:32:44 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-22 10:32:44 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-22 10:32:44 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-22 10:32:44 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-22 10:32:44 --> Final output sent to browser
DEBUG - 2011-08-22 10:32:44 --> Total execution time: 0.0302
DEBUG - 2011-08-22 10:32:50 --> Config Class Initialized
DEBUG - 2011-08-22 10:32:50 --> Hooks Class Initialized
DEBUG - 2011-08-22 10:32:50 --> Utf8 Class Initialized
DEBUG - 2011-08-22 10:32:50 --> UTF-8 Support Enabled
DEBUG - 2011-08-22 10:32:50 --> URI Class Initialized
DEBUG - 2011-08-22 10:32:50 --> Router Class Initialized
DEBUG - 2011-08-22 10:32:50 --> Output Class Initialized
DEBUG - 2011-08-22 10:32:50 --> Input Class Initialized
DEBUG - 2011-08-22 10:32:50 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-22 10:32:50 --> Language Class Initialized
DEBUG - 2011-08-22 10:32:50 --> Loader Class Initialized
DEBUG - 2011-08-22 10:32:50 --> Controller Class Initialized
DEBUG - 2011-08-22 10:32:50 --> Model Class Initialized
DEBUG - 2011-08-22 10:32:50 --> Model Class Initialized
DEBUG - 2011-08-22 10:32:50 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-22 10:32:50 --> Database Driver Class Initialized
DEBUG - 2011-08-22 10:32:51 --> Final output sent to browser
DEBUG - 2011-08-22 10:32:51 --> Total execution time: 0.5115
DEBUG - 2011-08-22 10:34:03 --> Config Class Initialized
DEBUG - 2011-08-22 10:34:03 --> Hooks Class Initialized
DEBUG - 2011-08-22 10:34:03 --> Utf8 Class Initialized
DEBUG - 2011-08-22 10:34:03 --> UTF-8 Support Enabled
DEBUG - 2011-08-22 10:34:03 --> URI Class Initialized
DEBUG - 2011-08-22 10:34:03 --> Router Class Initialized
DEBUG - 2011-08-22 10:34:03 --> Output Class Initialized
DEBUG - 2011-08-22 10:34:03 --> Input Class Initialized
DEBUG - 2011-08-22 10:34:03 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-22 10:34:03 --> Language Class Initialized
DEBUG - 2011-08-22 10:34:03 --> Loader Class Initialized
DEBUG - 2011-08-22 10:34:03 --> Controller Class Initialized
ERROR - 2011-08-22 10:34:03 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-08-22 10:34:03 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-08-22 10:34:03 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-08-22 10:34:03 --> Model Class Initialized
DEBUG - 2011-08-22 10:34:03 --> Model Class Initialized
DEBUG - 2011-08-22 10:34:03 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-22 10:34:03 --> Database Driver Class Initialized
DEBUG - 2011-08-22 10:34:03 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-08-22 10:34:03 --> Helper loaded: url_helper
DEBUG - 2011-08-22 10:34:03 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-22 10:34:03 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-22 10:34:03 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-22 10:34:03 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-22 10:34:03 --> Final output sent to browser
DEBUG - 2011-08-22 10:34:03 --> Total execution time: 0.0283
DEBUG - 2011-08-22 10:34:05 --> Config Class Initialized
DEBUG - 2011-08-22 10:34:05 --> Hooks Class Initialized
DEBUG - 2011-08-22 10:34:05 --> Utf8 Class Initialized
DEBUG - 2011-08-22 10:34:05 --> UTF-8 Support Enabled
DEBUG - 2011-08-22 10:34:05 --> URI Class Initialized
DEBUG - 2011-08-22 10:34:05 --> Router Class Initialized
DEBUG - 2011-08-22 10:34:05 --> Output Class Initialized
DEBUG - 2011-08-22 10:34:05 --> Input Class Initialized
DEBUG - 2011-08-22 10:34:05 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-22 10:34:05 --> Language Class Initialized
DEBUG - 2011-08-22 10:34:05 --> Loader Class Initialized
DEBUG - 2011-08-22 10:34:05 --> Controller Class Initialized
DEBUG - 2011-08-22 10:34:05 --> Model Class Initialized
DEBUG - 2011-08-22 10:34:05 --> Model Class Initialized
DEBUG - 2011-08-22 10:34:05 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-22 10:34:05 --> Database Driver Class Initialized
DEBUG - 2011-08-22 10:34:06 --> Final output sent to browser
DEBUG - 2011-08-22 10:34:06 --> Total execution time: 0.5327
DEBUG - 2011-08-22 10:34:20 --> Config Class Initialized
DEBUG - 2011-08-22 10:34:20 --> Hooks Class Initialized
DEBUG - 2011-08-22 10:34:20 --> Utf8 Class Initialized
DEBUG - 2011-08-22 10:34:20 --> UTF-8 Support Enabled
DEBUG - 2011-08-22 10:34:20 --> URI Class Initialized
DEBUG - 2011-08-22 10:34:20 --> Router Class Initialized
DEBUG - 2011-08-22 10:34:20 --> Output Class Initialized
DEBUG - 2011-08-22 10:34:20 --> Input Class Initialized
DEBUG - 2011-08-22 10:34:20 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-22 10:34:20 --> Language Class Initialized
DEBUG - 2011-08-22 10:34:20 --> Loader Class Initialized
DEBUG - 2011-08-22 10:34:20 --> Controller Class Initialized
ERROR - 2011-08-22 10:34:20 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-08-22 10:34:20 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-08-22 10:34:20 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-08-22 10:34:20 --> Model Class Initialized
DEBUG - 2011-08-22 10:34:20 --> Model Class Initialized
DEBUG - 2011-08-22 10:34:20 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-22 10:34:20 --> Database Driver Class Initialized
DEBUG - 2011-08-22 10:34:20 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-08-22 10:34:20 --> Helper loaded: url_helper
DEBUG - 2011-08-22 10:34:20 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-22 10:34:20 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-22 10:34:20 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-22 10:34:20 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-22 10:34:20 --> Final output sent to browser
DEBUG - 2011-08-22 10:34:20 --> Total execution time: 0.0285
DEBUG - 2011-08-22 10:34:21 --> Config Class Initialized
DEBUG - 2011-08-22 10:34:21 --> Hooks Class Initialized
DEBUG - 2011-08-22 10:34:21 --> Utf8 Class Initialized
DEBUG - 2011-08-22 10:34:21 --> UTF-8 Support Enabled
DEBUG - 2011-08-22 10:34:21 --> URI Class Initialized
DEBUG - 2011-08-22 10:34:21 --> Router Class Initialized
DEBUG - 2011-08-22 10:34:21 --> Output Class Initialized
DEBUG - 2011-08-22 10:34:21 --> Input Class Initialized
DEBUG - 2011-08-22 10:34:21 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-22 10:34:21 --> Language Class Initialized
DEBUG - 2011-08-22 10:34:21 --> Loader Class Initialized
DEBUG - 2011-08-22 10:34:21 --> Controller Class Initialized
DEBUG - 2011-08-22 10:34:21 --> Model Class Initialized
DEBUG - 2011-08-22 10:34:21 --> Model Class Initialized
DEBUG - 2011-08-22 10:34:21 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-22 10:34:21 --> Database Driver Class Initialized
DEBUG - 2011-08-22 10:34:22 --> Final output sent to browser
DEBUG - 2011-08-22 10:34:22 --> Total execution time: 0.5292
DEBUG - 2011-08-22 10:34:31 --> Config Class Initialized
DEBUG - 2011-08-22 10:34:31 --> Hooks Class Initialized
DEBUG - 2011-08-22 10:34:31 --> Utf8 Class Initialized
DEBUG - 2011-08-22 10:34:31 --> UTF-8 Support Enabled
DEBUG - 2011-08-22 10:34:31 --> URI Class Initialized
DEBUG - 2011-08-22 10:34:31 --> Router Class Initialized
DEBUG - 2011-08-22 10:34:31 --> Output Class Initialized
DEBUG - 2011-08-22 10:34:31 --> Input Class Initialized
DEBUG - 2011-08-22 10:34:31 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-22 10:34:31 --> Language Class Initialized
DEBUG - 2011-08-22 10:34:31 --> Loader Class Initialized
DEBUG - 2011-08-22 10:34:31 --> Controller Class Initialized
ERROR - 2011-08-22 10:34:31 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-08-22 10:34:31 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-08-22 10:34:31 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-08-22 10:34:31 --> Model Class Initialized
DEBUG - 2011-08-22 10:34:31 --> Model Class Initialized
DEBUG - 2011-08-22 10:34:31 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-22 10:34:31 --> Database Driver Class Initialized
DEBUG - 2011-08-22 10:34:31 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-08-22 10:34:31 --> Helper loaded: url_helper
DEBUG - 2011-08-22 10:34:31 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-22 10:34:31 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-22 10:34:31 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-22 10:34:31 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-22 10:34:31 --> Final output sent to browser
DEBUG - 2011-08-22 10:34:31 --> Total execution time: 0.0335
DEBUG - 2011-08-22 10:35:46 --> Config Class Initialized
DEBUG - 2011-08-22 10:35:46 --> Hooks Class Initialized
DEBUG - 2011-08-22 10:35:46 --> Utf8 Class Initialized
DEBUG - 2011-08-22 10:35:46 --> UTF-8 Support Enabled
DEBUG - 2011-08-22 10:35:46 --> URI Class Initialized
DEBUG - 2011-08-22 10:35:46 --> Router Class Initialized
DEBUG - 2011-08-22 10:35:46 --> Output Class Initialized
DEBUG - 2011-08-22 10:35:46 --> Input Class Initialized
DEBUG - 2011-08-22 10:35:46 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-22 10:35:46 --> Language Class Initialized
DEBUG - 2011-08-22 10:35:46 --> Loader Class Initialized
DEBUG - 2011-08-22 10:35:46 --> Controller Class Initialized
ERROR - 2011-08-22 10:35:46 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-08-22 10:35:46 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-08-22 10:35:46 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-08-22 10:35:46 --> Model Class Initialized
DEBUG - 2011-08-22 10:35:46 --> Model Class Initialized
DEBUG - 2011-08-22 10:35:46 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-22 10:35:46 --> Database Driver Class Initialized
DEBUG - 2011-08-22 10:35:46 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-08-22 10:35:46 --> Helper loaded: url_helper
DEBUG - 2011-08-22 10:35:46 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-22 10:35:46 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-22 10:35:46 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-22 10:35:46 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-22 10:35:46 --> Final output sent to browser
DEBUG - 2011-08-22 10:35:46 --> Total execution time: 0.0313
DEBUG - 2011-08-22 10:35:47 --> Config Class Initialized
DEBUG - 2011-08-22 10:35:47 --> Hooks Class Initialized
DEBUG - 2011-08-22 10:35:47 --> Utf8 Class Initialized
DEBUG - 2011-08-22 10:35:47 --> UTF-8 Support Enabled
DEBUG - 2011-08-22 10:35:47 --> URI Class Initialized
DEBUG - 2011-08-22 10:35:47 --> Router Class Initialized
DEBUG - 2011-08-22 10:35:47 --> Output Class Initialized
DEBUG - 2011-08-22 10:35:47 --> Input Class Initialized
DEBUG - 2011-08-22 10:35:47 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-22 10:35:47 --> Language Class Initialized
DEBUG - 2011-08-22 10:35:47 --> Loader Class Initialized
DEBUG - 2011-08-22 10:35:47 --> Controller Class Initialized
DEBUG - 2011-08-22 10:35:47 --> Model Class Initialized
DEBUG - 2011-08-22 10:35:47 --> Model Class Initialized
DEBUG - 2011-08-22 10:35:47 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-22 10:35:47 --> Database Driver Class Initialized
DEBUG - 2011-08-22 10:35:48 --> Final output sent to browser
DEBUG - 2011-08-22 10:35:48 --> Total execution time: 0.5187
DEBUG - 2011-08-22 10:35:52 --> Config Class Initialized
DEBUG - 2011-08-22 10:35:52 --> Hooks Class Initialized
DEBUG - 2011-08-22 10:35:52 --> Utf8 Class Initialized
DEBUG - 2011-08-22 10:35:52 --> UTF-8 Support Enabled
DEBUG - 2011-08-22 10:35:52 --> URI Class Initialized
DEBUG - 2011-08-22 10:35:52 --> Router Class Initialized
DEBUG - 2011-08-22 10:35:52 --> Output Class Initialized
DEBUG - 2011-08-22 10:35:52 --> Input Class Initialized
DEBUG - 2011-08-22 10:35:52 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-22 10:35:52 --> Language Class Initialized
DEBUG - 2011-08-22 10:35:52 --> Loader Class Initialized
DEBUG - 2011-08-22 10:35:52 --> Controller Class Initialized
ERROR - 2011-08-22 10:35:52 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-08-22 10:35:52 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-08-22 10:35:52 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-08-22 10:35:52 --> Model Class Initialized
DEBUG - 2011-08-22 10:35:52 --> Model Class Initialized
DEBUG - 2011-08-22 10:35:52 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-22 10:35:52 --> Database Driver Class Initialized
DEBUG - 2011-08-22 10:35:52 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-08-22 10:35:52 --> Helper loaded: url_helper
DEBUG - 2011-08-22 10:35:52 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-22 10:35:52 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-22 10:35:52 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-22 10:35:52 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-22 10:35:52 --> Final output sent to browser
DEBUG - 2011-08-22 10:35:52 --> Total execution time: 0.0326
DEBUG - 2011-08-22 10:35:53 --> Config Class Initialized
DEBUG - 2011-08-22 10:35:53 --> Hooks Class Initialized
DEBUG - 2011-08-22 10:35:53 --> Utf8 Class Initialized
DEBUG - 2011-08-22 10:35:53 --> UTF-8 Support Enabled
DEBUG - 2011-08-22 10:35:53 --> URI Class Initialized
DEBUG - 2011-08-22 10:35:53 --> Router Class Initialized
DEBUG - 2011-08-22 10:35:53 --> Output Class Initialized
DEBUG - 2011-08-22 10:35:53 --> Input Class Initialized
DEBUG - 2011-08-22 10:35:53 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-22 10:35:53 --> Language Class Initialized
DEBUG - 2011-08-22 10:35:53 --> Loader Class Initialized
DEBUG - 2011-08-22 10:35:53 --> Controller Class Initialized
DEBUG - 2011-08-22 10:35:53 --> Model Class Initialized
DEBUG - 2011-08-22 10:35:53 --> Model Class Initialized
DEBUG - 2011-08-22 10:35:53 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-22 10:35:53 --> Database Driver Class Initialized
DEBUG - 2011-08-22 10:35:54 --> Final output sent to browser
DEBUG - 2011-08-22 10:35:54 --> Total execution time: 0.5477
DEBUG - 2011-08-22 10:56:14 --> Config Class Initialized
DEBUG - 2011-08-22 10:56:14 --> Hooks Class Initialized
DEBUG - 2011-08-22 10:56:14 --> Utf8 Class Initialized
DEBUG - 2011-08-22 10:56:14 --> UTF-8 Support Enabled
DEBUG - 2011-08-22 10:56:14 --> URI Class Initialized
DEBUG - 2011-08-22 10:56:14 --> Router Class Initialized
DEBUG - 2011-08-22 10:56:14 --> Output Class Initialized
DEBUG - 2011-08-22 10:56:14 --> Input Class Initialized
DEBUG - 2011-08-22 10:56:14 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-22 10:56:14 --> Language Class Initialized
DEBUG - 2011-08-22 10:56:14 --> Loader Class Initialized
DEBUG - 2011-08-22 10:56:14 --> Controller Class Initialized
ERROR - 2011-08-22 10:56:14 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-08-22 10:56:14 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-08-22 10:56:14 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-08-22 10:56:14 --> Model Class Initialized
DEBUG - 2011-08-22 10:56:14 --> Model Class Initialized
DEBUG - 2011-08-22 10:56:14 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-22 10:56:14 --> Database Driver Class Initialized
DEBUG - 2011-08-22 10:56:14 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-08-22 10:56:14 --> Helper loaded: url_helper
DEBUG - 2011-08-22 10:56:14 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-22 10:56:14 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-22 10:56:14 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-22 10:56:14 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-22 10:56:14 --> Final output sent to browser
DEBUG - 2011-08-22 10:56:14 --> Total execution time: 0.0849
DEBUG - 2011-08-22 10:56:16 --> Config Class Initialized
DEBUG - 2011-08-22 10:56:16 --> Hooks Class Initialized
DEBUG - 2011-08-22 10:56:16 --> Utf8 Class Initialized
DEBUG - 2011-08-22 10:56:16 --> UTF-8 Support Enabled
DEBUG - 2011-08-22 10:56:16 --> URI Class Initialized
DEBUG - 2011-08-22 10:56:16 --> Router Class Initialized
DEBUG - 2011-08-22 10:56:16 --> Output Class Initialized
DEBUG - 2011-08-22 10:56:16 --> Input Class Initialized
DEBUG - 2011-08-22 10:56:16 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-22 10:56:16 --> Language Class Initialized
DEBUG - 2011-08-22 10:56:16 --> Loader Class Initialized
DEBUG - 2011-08-22 10:56:16 --> Controller Class Initialized
DEBUG - 2011-08-22 10:56:16 --> Model Class Initialized
DEBUG - 2011-08-22 10:56:16 --> Model Class Initialized
DEBUG - 2011-08-22 10:56:16 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-22 10:56:16 --> Database Driver Class Initialized
DEBUG - 2011-08-22 10:56:17 --> Final output sent to browser
DEBUG - 2011-08-22 10:56:17 --> Total execution time: 0.5547
DEBUG - 2011-08-22 10:56:18 --> Config Class Initialized
DEBUG - 2011-08-22 10:56:18 --> Hooks Class Initialized
DEBUG - 2011-08-22 10:56:18 --> Utf8 Class Initialized
DEBUG - 2011-08-22 10:56:18 --> UTF-8 Support Enabled
DEBUG - 2011-08-22 10:56:18 --> URI Class Initialized
DEBUG - 2011-08-22 10:56:18 --> Router Class Initialized
ERROR - 2011-08-22 10:56:18 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-08-22 11:20:16 --> Config Class Initialized
DEBUG - 2011-08-22 11:20:16 --> Hooks Class Initialized
DEBUG - 2011-08-22 11:20:16 --> Utf8 Class Initialized
DEBUG - 2011-08-22 11:20:16 --> UTF-8 Support Enabled
DEBUG - 2011-08-22 11:20:16 --> URI Class Initialized
DEBUG - 2011-08-22 11:20:16 --> Router Class Initialized
ERROR - 2011-08-22 11:20:16 --> 404 Page Not Found --> robots.txt
DEBUG - 2011-08-22 12:38:55 --> Config Class Initialized
DEBUG - 2011-08-22 12:38:55 --> Hooks Class Initialized
DEBUG - 2011-08-22 12:38:55 --> Utf8 Class Initialized
DEBUG - 2011-08-22 12:38:55 --> UTF-8 Support Enabled
DEBUG - 2011-08-22 12:38:55 --> URI Class Initialized
DEBUG - 2011-08-22 12:38:55 --> Router Class Initialized
DEBUG - 2011-08-22 12:38:55 --> No URI present. Default controller set.
DEBUG - 2011-08-22 12:38:55 --> Output Class Initialized
DEBUG - 2011-08-22 12:38:55 --> Input Class Initialized
DEBUG - 2011-08-22 12:38:55 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-22 12:38:55 --> Language Class Initialized
DEBUG - 2011-08-22 12:38:55 --> Loader Class Initialized
DEBUG - 2011-08-22 12:38:55 --> Controller Class Initialized
DEBUG - 2011-08-22 12:38:55 --> File loaded: application/views/splash/main.php
DEBUG - 2011-08-22 12:38:55 --> Helper loaded: url_helper
DEBUG - 2011-08-22 12:38:55 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-22 12:38:55 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-22 12:38:55 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-22 12:38:55 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-22 12:38:55 --> Final output sent to browser
DEBUG - 2011-08-22 12:38:55 --> Total execution time: 0.3357
DEBUG - 2011-08-22 12:47:21 --> Config Class Initialized
DEBUG - 2011-08-22 12:47:21 --> Hooks Class Initialized
DEBUG - 2011-08-22 12:47:21 --> Utf8 Class Initialized
DEBUG - 2011-08-22 12:47:21 --> UTF-8 Support Enabled
DEBUG - 2011-08-22 12:47:21 --> URI Class Initialized
DEBUG - 2011-08-22 12:47:21 --> Router Class Initialized
DEBUG - 2011-08-22 12:47:21 --> Output Class Initialized
DEBUG - 2011-08-22 12:47:21 --> Input Class Initialized
DEBUG - 2011-08-22 12:47:21 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-22 12:47:21 --> Language Class Initialized
DEBUG - 2011-08-22 12:47:21 --> Loader Class Initialized
DEBUG - 2011-08-22 12:47:21 --> Controller Class Initialized
DEBUG - 2011-08-22 12:47:21 --> Model Class Initialized
DEBUG - 2011-08-22 12:47:21 --> Model Class Initialized
DEBUG - 2011-08-22 12:47:21 --> Model Class Initialized
DEBUG - 2011-08-22 12:47:21 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-22 12:47:22 --> Database Driver Class Initialized
DEBUG - 2011-08-22 12:47:23 --> File loaded: application/views/table/main.php
DEBUG - 2011-08-22 12:47:23 --> Helper loaded: url_helper
DEBUG - 2011-08-22 12:47:23 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-22 12:47:23 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-22 12:47:23 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-22 12:47:23 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-22 12:47:23 --> Final output sent to browser
DEBUG - 2011-08-22 12:47:23 --> Total execution time: 1.8335
DEBUG - 2011-08-22 12:47:26 --> Config Class Initialized
DEBUG - 2011-08-22 12:47:26 --> Hooks Class Initialized
DEBUG - 2011-08-22 12:47:26 --> Utf8 Class Initialized
DEBUG - 2011-08-22 12:47:26 --> UTF-8 Support Enabled
DEBUG - 2011-08-22 12:47:26 --> URI Class Initialized
DEBUG - 2011-08-22 12:47:26 --> Router Class Initialized
ERROR - 2011-08-22 12:47:26 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-08-22 12:47:27 --> Config Class Initialized
DEBUG - 2011-08-22 12:47:27 --> Hooks Class Initialized
DEBUG - 2011-08-22 12:47:27 --> Utf8 Class Initialized
DEBUG - 2011-08-22 12:47:27 --> UTF-8 Support Enabled
DEBUG - 2011-08-22 12:47:27 --> URI Class Initialized
DEBUG - 2011-08-22 12:47:27 --> Router Class Initialized
ERROR - 2011-08-22 12:47:27 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-08-22 12:47:37 --> Config Class Initialized
DEBUG - 2011-08-22 12:47:37 --> Hooks Class Initialized
DEBUG - 2011-08-22 12:47:37 --> Utf8 Class Initialized
DEBUG - 2011-08-22 12:47:37 --> UTF-8 Support Enabled
DEBUG - 2011-08-22 12:47:37 --> URI Class Initialized
DEBUG - 2011-08-22 12:47:37 --> Router Class Initialized
DEBUG - 2011-08-22 12:47:37 --> Output Class Initialized
DEBUG - 2011-08-22 12:47:37 --> Input Class Initialized
DEBUG - 2011-08-22 12:47:37 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-22 12:47:37 --> Language Class Initialized
DEBUG - 2011-08-22 12:47:37 --> Loader Class Initialized
DEBUG - 2011-08-22 12:47:37 --> Controller Class Initialized
DEBUG - 2011-08-22 12:47:37 --> Model Class Initialized
DEBUG - 2011-08-22 12:47:37 --> Model Class Initialized
DEBUG - 2011-08-22 12:47:37 --> Model Class Initialized
DEBUG - 2011-08-22 12:47:37 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-22 12:47:37 --> Database Driver Class Initialized
DEBUG - 2011-08-22 12:47:37 --> File loaded: application/views/table/main.php
DEBUG - 2011-08-22 12:47:37 --> Helper loaded: url_helper
DEBUG - 2011-08-22 12:47:37 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-22 12:47:37 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-22 12:47:37 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-22 12:47:37 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-22 12:47:37 --> Final output sent to browser
DEBUG - 2011-08-22 12:47:37 --> Total execution time: 0.4094
DEBUG - 2011-08-22 12:48:02 --> Config Class Initialized
DEBUG - 2011-08-22 12:48:02 --> Hooks Class Initialized
DEBUG - 2011-08-22 12:48:02 --> Utf8 Class Initialized
DEBUG - 2011-08-22 12:48:02 --> UTF-8 Support Enabled
DEBUG - 2011-08-22 12:48:02 --> URI Class Initialized
DEBUG - 2011-08-22 12:48:02 --> Router Class Initialized
DEBUG - 2011-08-22 12:48:02 --> Output Class Initialized
DEBUG - 2011-08-22 12:48:02 --> Input Class Initialized
DEBUG - 2011-08-22 12:48:02 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-22 12:48:02 --> Language Class Initialized
DEBUG - 2011-08-22 12:48:02 --> Loader Class Initialized
DEBUG - 2011-08-22 12:48:02 --> Controller Class Initialized
ERROR - 2011-08-22 12:48:02 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-08-22 12:48:02 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-08-22 12:48:02 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-08-22 12:48:02 --> Model Class Initialized
DEBUG - 2011-08-22 12:48:02 --> Model Class Initialized
DEBUG - 2011-08-22 12:48:02 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-22 12:48:02 --> Database Driver Class Initialized
DEBUG - 2011-08-22 12:48:02 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-08-22 12:48:02 --> Helper loaded: url_helper
DEBUG - 2011-08-22 12:48:02 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-22 12:48:02 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-22 12:48:02 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-22 12:48:02 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-22 12:48:02 --> Final output sent to browser
DEBUG - 2011-08-22 12:48:02 --> Total execution time: 0.0992
DEBUG - 2011-08-22 12:48:02 --> Config Class Initialized
DEBUG - 2011-08-22 12:48:02 --> Hooks Class Initialized
DEBUG - 2011-08-22 12:48:02 --> Utf8 Class Initialized
DEBUG - 2011-08-22 12:48:02 --> UTF-8 Support Enabled
DEBUG - 2011-08-22 12:48:02 --> URI Class Initialized
DEBUG - 2011-08-22 12:48:02 --> Router Class Initialized
DEBUG - 2011-08-22 12:48:02 --> Output Class Initialized
DEBUG - 2011-08-22 12:48:02 --> Input Class Initialized
DEBUG - 2011-08-22 12:48:02 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-22 12:48:02 --> Language Class Initialized
DEBUG - 2011-08-22 12:48:02 --> Loader Class Initialized
DEBUG - 2011-08-22 12:48:02 --> Controller Class Initialized
DEBUG - 2011-08-22 12:48:02 --> Model Class Initialized
DEBUG - 2011-08-22 12:48:03 --> Model Class Initialized
DEBUG - 2011-08-22 12:48:03 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-22 12:48:03 --> Database Driver Class Initialized
DEBUG - 2011-08-22 12:48:03 --> Final output sent to browser
DEBUG - 2011-08-22 12:48:03 --> Total execution time: 0.7029
DEBUG - 2011-08-22 12:48:16 --> Config Class Initialized
DEBUG - 2011-08-22 12:48:16 --> Hooks Class Initialized
DEBUG - 2011-08-22 12:48:16 --> Utf8 Class Initialized
DEBUG - 2011-08-22 12:48:16 --> UTF-8 Support Enabled
DEBUG - 2011-08-22 12:48:16 --> URI Class Initialized
DEBUG - 2011-08-22 12:48:16 --> Router Class Initialized
DEBUG - 2011-08-22 12:48:16 --> Output Class Initialized
DEBUG - 2011-08-22 12:48:16 --> Input Class Initialized
DEBUG - 2011-08-22 12:48:16 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-22 12:48:16 --> Language Class Initialized
DEBUG - 2011-08-22 12:48:16 --> Loader Class Initialized
DEBUG - 2011-08-22 12:48:16 --> Controller Class Initialized
ERROR - 2011-08-22 12:48:16 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-08-22 12:48:16 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-08-22 12:48:16 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-08-22 12:48:16 --> Model Class Initialized
DEBUG - 2011-08-22 12:48:16 --> Model Class Initialized
DEBUG - 2011-08-22 12:48:16 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-22 12:48:16 --> Database Driver Class Initialized
DEBUG - 2011-08-22 12:48:16 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-08-22 12:48:16 --> Helper loaded: url_helper
DEBUG - 2011-08-22 12:48:16 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-22 12:48:16 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-22 12:48:16 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-22 12:48:16 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-22 12:48:16 --> Final output sent to browser
DEBUG - 2011-08-22 12:48:16 --> Total execution time: 0.0966
DEBUG - 2011-08-22 12:48:17 --> Config Class Initialized
DEBUG - 2011-08-22 12:48:17 --> Hooks Class Initialized
DEBUG - 2011-08-22 12:48:17 --> Utf8 Class Initialized
DEBUG - 2011-08-22 12:48:17 --> UTF-8 Support Enabled
DEBUG - 2011-08-22 12:48:17 --> URI Class Initialized
DEBUG - 2011-08-22 12:48:17 --> Router Class Initialized
DEBUG - 2011-08-22 12:48:17 --> Output Class Initialized
DEBUG - 2011-08-22 12:48:17 --> Input Class Initialized
DEBUG - 2011-08-22 12:48:17 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-22 12:48:17 --> Language Class Initialized
DEBUG - 2011-08-22 12:48:17 --> Loader Class Initialized
DEBUG - 2011-08-22 12:48:17 --> Controller Class Initialized
DEBUG - 2011-08-22 12:48:17 --> Model Class Initialized
DEBUG - 2011-08-22 12:48:17 --> Model Class Initialized
DEBUG - 2011-08-22 12:48:17 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-22 12:48:17 --> Database Driver Class Initialized
DEBUG - 2011-08-22 12:48:17 --> Final output sent to browser
DEBUG - 2011-08-22 12:48:17 --> Total execution time: 0.8877
DEBUG - 2011-08-22 12:48:17 --> Config Class Initialized
DEBUG - 2011-08-22 12:48:17 --> Hooks Class Initialized
DEBUG - 2011-08-22 12:48:17 --> Utf8 Class Initialized
DEBUG - 2011-08-22 12:48:17 --> UTF-8 Support Enabled
DEBUG - 2011-08-22 12:48:17 --> URI Class Initialized
DEBUG - 2011-08-22 12:48:17 --> Router Class Initialized
DEBUG - 2011-08-22 12:48:17 --> Output Class Initialized
DEBUG - 2011-08-22 12:48:17 --> Input Class Initialized
DEBUG - 2011-08-22 12:48:17 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-22 12:48:17 --> Language Class Initialized
DEBUG - 2011-08-22 12:48:17 --> Loader Class Initialized
DEBUG - 2011-08-22 12:48:17 --> Controller Class Initialized
ERROR - 2011-08-22 12:48:17 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-08-22 12:48:17 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-08-22 12:48:17 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-08-22 12:48:17 --> Model Class Initialized
DEBUG - 2011-08-22 12:48:17 --> Model Class Initialized
DEBUG - 2011-08-22 12:48:17 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-22 12:48:17 --> Database Driver Class Initialized
DEBUG - 2011-08-22 12:48:17 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-08-22 12:48:17 --> Helper loaded: url_helper
DEBUG - 2011-08-22 12:48:17 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-22 12:48:17 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-22 12:48:17 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-22 12:48:17 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-22 12:48:17 --> Final output sent to browser
DEBUG - 2011-08-22 12:48:17 --> Total execution time: 0.0311
DEBUG - 2011-08-22 12:48:28 --> Config Class Initialized
DEBUG - 2011-08-22 12:48:28 --> Hooks Class Initialized
DEBUG - 2011-08-22 12:48:28 --> Utf8 Class Initialized
DEBUG - 2011-08-22 12:48:28 --> UTF-8 Support Enabled
DEBUG - 2011-08-22 12:48:28 --> URI Class Initialized
DEBUG - 2011-08-22 12:48:28 --> Router Class Initialized
DEBUG - 2011-08-22 12:48:28 --> Output Class Initialized
DEBUG - 2011-08-22 12:48:28 --> Input Class Initialized
DEBUG - 2011-08-22 12:48:28 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-22 12:48:28 --> Language Class Initialized
DEBUG - 2011-08-22 12:48:28 --> Loader Class Initialized
DEBUG - 2011-08-22 12:48:28 --> Controller Class Initialized
ERROR - 2011-08-22 12:48:28 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-08-22 12:48:28 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-08-22 12:48:28 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-08-22 12:48:28 --> Model Class Initialized
DEBUG - 2011-08-22 12:48:28 --> Model Class Initialized
DEBUG - 2011-08-22 12:48:28 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-22 12:48:28 --> Database Driver Class Initialized
DEBUG - 2011-08-22 12:48:28 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-08-22 12:48:28 --> Helper loaded: url_helper
DEBUG - 2011-08-22 12:48:28 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-22 12:48:28 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-22 12:48:28 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-22 12:48:28 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-22 12:48:28 --> Final output sent to browser
DEBUG - 2011-08-22 12:48:28 --> Total execution time: 0.0282
DEBUG - 2011-08-22 12:48:28 --> Config Class Initialized
DEBUG - 2011-08-22 12:48:28 --> Hooks Class Initialized
DEBUG - 2011-08-22 12:48:28 --> Utf8 Class Initialized
DEBUG - 2011-08-22 12:48:28 --> UTF-8 Support Enabled
DEBUG - 2011-08-22 12:48:28 --> URI Class Initialized
DEBUG - 2011-08-22 12:48:28 --> Router Class Initialized
DEBUG - 2011-08-22 12:48:28 --> Output Class Initialized
DEBUG - 2011-08-22 12:48:28 --> Input Class Initialized
DEBUG - 2011-08-22 12:48:28 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-22 12:48:28 --> Language Class Initialized
DEBUG - 2011-08-22 12:48:28 --> Loader Class Initialized
DEBUG - 2011-08-22 12:48:28 --> Controller Class Initialized
DEBUG - 2011-08-22 12:48:28 --> Model Class Initialized
DEBUG - 2011-08-22 12:48:28 --> Model Class Initialized
DEBUG - 2011-08-22 12:48:28 --> Model Class Initialized
DEBUG - 2011-08-22 12:48:28 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-22 12:48:28 --> Database Driver Class Initialized
DEBUG - 2011-08-22 12:48:28 --> File loaded: application/views/table/main.php
DEBUG - 2011-08-22 12:48:28 --> Helper loaded: url_helper
DEBUG - 2011-08-22 12:48:28 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-22 12:48:28 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-22 12:48:28 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-22 12:48:28 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-22 12:48:28 --> Final output sent to browser
DEBUG - 2011-08-22 12:48:28 --> Total execution time: 0.0459
DEBUG - 2011-08-22 12:48:29 --> Config Class Initialized
DEBUG - 2011-08-22 12:48:29 --> Hooks Class Initialized
DEBUG - 2011-08-22 12:48:29 --> Utf8 Class Initialized
DEBUG - 2011-08-22 12:48:29 --> UTF-8 Support Enabled
DEBUG - 2011-08-22 12:48:29 --> URI Class Initialized
DEBUG - 2011-08-22 12:48:29 --> Router Class Initialized
DEBUG - 2011-08-22 12:48:29 --> Output Class Initialized
DEBUG - 2011-08-22 12:48:29 --> Input Class Initialized
DEBUG - 2011-08-22 12:48:29 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-22 12:48:29 --> Language Class Initialized
DEBUG - 2011-08-22 12:48:29 --> Loader Class Initialized
DEBUG - 2011-08-22 12:48:29 --> Controller Class Initialized
DEBUG - 2011-08-22 12:48:29 --> Model Class Initialized
DEBUG - 2011-08-22 12:48:29 --> Model Class Initialized
DEBUG - 2011-08-22 12:48:29 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-22 12:48:29 --> Database Driver Class Initialized
DEBUG - 2011-08-22 12:48:29 --> Final output sent to browser
DEBUG - 2011-08-22 12:48:29 --> Total execution time: 0.5100
DEBUG - 2011-08-22 12:48:32 --> Config Class Initialized
DEBUG - 2011-08-22 12:48:32 --> Hooks Class Initialized
DEBUG - 2011-08-22 12:48:32 --> Utf8 Class Initialized
DEBUG - 2011-08-22 12:48:32 --> UTF-8 Support Enabled
DEBUG - 2011-08-22 12:48:32 --> URI Class Initialized
DEBUG - 2011-08-22 12:48:32 --> Router Class Initialized
ERROR - 2011-08-22 12:48:32 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-08-22 12:48:32 --> Config Class Initialized
DEBUG - 2011-08-22 12:48:32 --> Hooks Class Initialized
DEBUG - 2011-08-22 12:48:32 --> Utf8 Class Initialized
DEBUG - 2011-08-22 12:48:32 --> UTF-8 Support Enabled
DEBUG - 2011-08-22 12:48:32 --> URI Class Initialized
DEBUG - 2011-08-22 12:48:32 --> Router Class Initialized
ERROR - 2011-08-22 12:48:32 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-08-22 12:48:33 --> Config Class Initialized
DEBUG - 2011-08-22 12:48:33 --> Hooks Class Initialized
DEBUG - 2011-08-22 12:48:33 --> Utf8 Class Initialized
DEBUG - 2011-08-22 12:48:33 --> UTF-8 Support Enabled
DEBUG - 2011-08-22 12:48:33 --> URI Class Initialized
DEBUG - 2011-08-22 12:48:33 --> Router Class Initialized
ERROR - 2011-08-22 12:48:33 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-08-22 12:48:40 --> Config Class Initialized
DEBUG - 2011-08-22 12:48:40 --> Hooks Class Initialized
DEBUG - 2011-08-22 12:48:40 --> Utf8 Class Initialized
DEBUG - 2011-08-22 12:48:40 --> UTF-8 Support Enabled
DEBUG - 2011-08-22 12:48:40 --> URI Class Initialized
DEBUG - 2011-08-22 12:48:40 --> Router Class Initialized
DEBUG - 2011-08-22 12:48:40 --> Output Class Initialized
DEBUG - 2011-08-22 12:48:40 --> Input Class Initialized
DEBUG - 2011-08-22 12:48:40 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-22 12:48:40 --> Language Class Initialized
DEBUG - 2011-08-22 12:48:40 --> Loader Class Initialized
DEBUG - 2011-08-22 12:48:40 --> Controller Class Initialized
DEBUG - 2011-08-22 12:48:40 --> Model Class Initialized
DEBUG - 2011-08-22 12:48:40 --> Model Class Initialized
DEBUG - 2011-08-22 12:48:40 --> Model Class Initialized
DEBUG - 2011-08-22 12:48:40 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-22 12:48:40 --> Database Driver Class Initialized
DEBUG - 2011-08-22 12:48:41 --> File loaded: application/views/table/main.php
DEBUG - 2011-08-22 12:48:41 --> Helper loaded: url_helper
DEBUG - 2011-08-22 12:48:41 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-22 12:48:41 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-22 12:48:41 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-22 12:48:41 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-22 12:48:41 --> Final output sent to browser
DEBUG - 2011-08-22 12:48:41 --> Total execution time: 1.1118
DEBUG - 2011-08-22 12:48:54 --> Config Class Initialized
DEBUG - 2011-08-22 12:48:54 --> Hooks Class Initialized
DEBUG - 2011-08-22 12:48:54 --> Utf8 Class Initialized
DEBUG - 2011-08-22 12:48:54 --> UTF-8 Support Enabled
DEBUG - 2011-08-22 12:48:54 --> URI Class Initialized
DEBUG - 2011-08-22 12:48:54 --> Router Class Initialized
DEBUG - 2011-08-22 12:48:54 --> Output Class Initialized
DEBUG - 2011-08-22 12:48:54 --> Input Class Initialized
DEBUG - 2011-08-22 12:48:54 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-22 12:48:54 --> Language Class Initialized
DEBUG - 2011-08-22 12:48:54 --> Loader Class Initialized
DEBUG - 2011-08-22 12:48:54 --> Controller Class Initialized
DEBUG - 2011-08-22 12:48:54 --> Model Class Initialized
DEBUG - 2011-08-22 12:48:54 --> Model Class Initialized
DEBUG - 2011-08-22 12:48:54 --> Model Class Initialized
DEBUG - 2011-08-22 12:48:54 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-22 12:48:54 --> Database Driver Class Initialized
DEBUG - 2011-08-22 12:48:54 --> File loaded: application/views/table/main.php
DEBUG - 2011-08-22 12:48:54 --> Helper loaded: url_helper
DEBUG - 2011-08-22 12:48:54 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-22 12:48:54 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-22 12:48:54 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-22 12:48:54 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-22 12:48:54 --> Final output sent to browser
DEBUG - 2011-08-22 12:48:54 --> Total execution time: 0.2503
DEBUG - 2011-08-22 12:50:54 --> Config Class Initialized
DEBUG - 2011-08-22 12:50:54 --> Hooks Class Initialized
DEBUG - 2011-08-22 12:50:54 --> Utf8 Class Initialized
DEBUG - 2011-08-22 12:50:54 --> UTF-8 Support Enabled
DEBUG - 2011-08-22 12:50:54 --> URI Class Initialized
DEBUG - 2011-08-22 12:50:54 --> Router Class Initialized
DEBUG - 2011-08-22 12:50:54 --> Output Class Initialized
DEBUG - 2011-08-22 12:50:54 --> Input Class Initialized
DEBUG - 2011-08-22 12:50:54 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-22 12:50:54 --> Language Class Initialized
DEBUG - 2011-08-22 12:50:54 --> Loader Class Initialized
DEBUG - 2011-08-22 12:50:54 --> Controller Class Initialized
DEBUG - 2011-08-22 12:50:54 --> Model Class Initialized
DEBUG - 2011-08-22 12:50:54 --> Model Class Initialized
DEBUG - 2011-08-22 12:50:54 --> Model Class Initialized
DEBUG - 2011-08-22 12:50:54 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-22 12:50:54 --> Database Driver Class Initialized
DEBUG - 2011-08-22 12:50:54 --> File loaded: application/views/table/main.php
DEBUG - 2011-08-22 12:50:54 --> Helper loaded: url_helper
DEBUG - 2011-08-22 12:50:54 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-22 12:50:54 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-22 12:50:54 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-22 12:50:54 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-22 12:50:54 --> Final output sent to browser
DEBUG - 2011-08-22 12:50:54 --> Total execution time: 0.0483
DEBUG - 2011-08-22 12:51:19 --> Config Class Initialized
DEBUG - 2011-08-22 12:51:19 --> Hooks Class Initialized
DEBUG - 2011-08-22 12:51:19 --> Utf8 Class Initialized
DEBUG - 2011-08-22 12:51:19 --> UTF-8 Support Enabled
DEBUG - 2011-08-22 12:51:19 --> URI Class Initialized
DEBUG - 2011-08-22 12:51:19 --> Router Class Initialized
DEBUG - 2011-08-22 12:51:19 --> Output Class Initialized
DEBUG - 2011-08-22 12:51:19 --> Input Class Initialized
DEBUG - 2011-08-22 12:51:19 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-22 12:51:19 --> Language Class Initialized
DEBUG - 2011-08-22 12:51:19 --> Loader Class Initialized
DEBUG - 2011-08-22 12:51:19 --> Controller Class Initialized
DEBUG - 2011-08-22 12:51:19 --> Model Class Initialized
DEBUG - 2011-08-22 12:51:19 --> Model Class Initialized
DEBUG - 2011-08-22 12:51:19 --> Model Class Initialized
DEBUG - 2011-08-22 12:51:19 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-22 12:51:19 --> Database Driver Class Initialized
DEBUG - 2011-08-22 12:51:19 --> File loaded: application/views/table/main.php
DEBUG - 2011-08-22 12:51:19 --> Helper loaded: url_helper
DEBUG - 2011-08-22 12:51:19 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-22 12:51:19 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-22 12:51:19 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-22 12:51:19 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-22 12:51:19 --> Final output sent to browser
DEBUG - 2011-08-22 12:51:19 --> Total execution time: 0.0551
DEBUG - 2011-08-22 12:51:47 --> Config Class Initialized
DEBUG - 2011-08-22 12:51:47 --> Hooks Class Initialized
DEBUG - 2011-08-22 12:51:47 --> Utf8 Class Initialized
DEBUG - 2011-08-22 12:51:47 --> UTF-8 Support Enabled
DEBUG - 2011-08-22 12:51:47 --> URI Class Initialized
DEBUG - 2011-08-22 12:51:47 --> Router Class Initialized
DEBUG - 2011-08-22 12:51:47 --> Output Class Initialized
DEBUG - 2011-08-22 12:51:47 --> Input Class Initialized
DEBUG - 2011-08-22 12:51:47 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-22 12:51:47 --> Language Class Initialized
DEBUG - 2011-08-22 12:51:47 --> Loader Class Initialized
DEBUG - 2011-08-22 12:51:47 --> Controller Class Initialized
DEBUG - 2011-08-22 12:51:47 --> Model Class Initialized
DEBUG - 2011-08-22 12:51:47 --> Model Class Initialized
DEBUG - 2011-08-22 12:51:47 --> Model Class Initialized
DEBUG - 2011-08-22 12:51:47 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-22 12:51:47 --> Database Driver Class Initialized
DEBUG - 2011-08-22 12:51:47 --> File loaded: application/views/table/main.php
DEBUG - 2011-08-22 12:51:47 --> Helper loaded: url_helper
DEBUG - 2011-08-22 12:51:47 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-22 12:51:47 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-22 12:51:47 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-22 12:51:47 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-22 12:51:47 --> Final output sent to browser
DEBUG - 2011-08-22 12:51:47 --> Total execution time: 0.2558
DEBUG - 2011-08-22 12:51:47 --> Config Class Initialized
DEBUG - 2011-08-22 12:51:47 --> Hooks Class Initialized
DEBUG - 2011-08-22 12:51:47 --> Utf8 Class Initialized
DEBUG - 2011-08-22 12:51:47 --> UTF-8 Support Enabled
DEBUG - 2011-08-22 12:51:47 --> URI Class Initialized
DEBUG - 2011-08-22 12:51:47 --> Router Class Initialized
DEBUG - 2011-08-22 12:51:47 --> Output Class Initialized
DEBUG - 2011-08-22 12:51:47 --> Input Class Initialized
DEBUG - 2011-08-22 12:51:47 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-22 12:51:47 --> Language Class Initialized
DEBUG - 2011-08-22 12:51:47 --> Loader Class Initialized
DEBUG - 2011-08-22 12:51:47 --> Controller Class Initialized
DEBUG - 2011-08-22 12:51:47 --> Model Class Initialized
DEBUG - 2011-08-22 12:51:47 --> Model Class Initialized
DEBUG - 2011-08-22 12:51:47 --> Model Class Initialized
DEBUG - 2011-08-22 12:51:47 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-22 12:51:47 --> Database Driver Class Initialized
DEBUG - 2011-08-22 12:51:48 --> File loaded: application/views/table/main.php
DEBUG - 2011-08-22 12:51:48 --> Helper loaded: url_helper
DEBUG - 2011-08-22 12:51:48 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-22 12:51:48 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-22 12:51:48 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-22 12:51:48 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-22 12:51:48 --> Final output sent to browser
DEBUG - 2011-08-22 12:51:48 --> Total execution time: 0.2507
DEBUG - 2011-08-22 12:51:56 --> Config Class Initialized
DEBUG - 2011-08-22 12:51:56 --> Hooks Class Initialized
DEBUG - 2011-08-22 12:51:56 --> Utf8 Class Initialized
DEBUG - 2011-08-22 12:51:56 --> UTF-8 Support Enabled
DEBUG - 2011-08-22 12:51:56 --> URI Class Initialized
DEBUG - 2011-08-22 12:51:56 --> Router Class Initialized
DEBUG - 2011-08-22 12:51:56 --> Output Class Initialized
DEBUG - 2011-08-22 12:51:56 --> Input Class Initialized
DEBUG - 2011-08-22 12:51:56 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-22 12:51:56 --> Language Class Initialized
DEBUG - 2011-08-22 12:51:56 --> Loader Class Initialized
DEBUG - 2011-08-22 12:51:56 --> Controller Class Initialized
DEBUG - 2011-08-22 12:51:56 --> Model Class Initialized
DEBUG - 2011-08-22 12:51:56 --> Model Class Initialized
DEBUG - 2011-08-22 12:51:56 --> Model Class Initialized
DEBUG - 2011-08-22 12:51:56 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-22 12:51:56 --> Database Driver Class Initialized
DEBUG - 2011-08-22 12:51:56 --> File loaded: application/views/table/main.php
DEBUG - 2011-08-22 12:51:56 --> Helper loaded: url_helper
DEBUG - 2011-08-22 12:51:56 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-22 12:51:56 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-22 12:51:56 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-22 12:51:56 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-22 12:51:56 --> Final output sent to browser
DEBUG - 2011-08-22 12:51:56 --> Total execution time: 0.2516
DEBUG - 2011-08-22 12:52:03 --> Config Class Initialized
DEBUG - 2011-08-22 12:52:03 --> Hooks Class Initialized
DEBUG - 2011-08-22 12:52:03 --> Utf8 Class Initialized
DEBUG - 2011-08-22 12:52:03 --> UTF-8 Support Enabled
DEBUG - 2011-08-22 12:52:03 --> URI Class Initialized
DEBUG - 2011-08-22 12:52:03 --> Router Class Initialized
DEBUG - 2011-08-22 12:52:03 --> Output Class Initialized
DEBUG - 2011-08-22 12:52:03 --> Input Class Initialized
DEBUG - 2011-08-22 12:52:03 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-22 12:52:03 --> Language Class Initialized
DEBUG - 2011-08-22 12:52:03 --> Loader Class Initialized
DEBUG - 2011-08-22 12:52:03 --> Controller Class Initialized
DEBUG - 2011-08-22 12:52:03 --> Model Class Initialized
DEBUG - 2011-08-22 12:52:03 --> Model Class Initialized
DEBUG - 2011-08-22 12:52:03 --> Model Class Initialized
DEBUG - 2011-08-22 12:52:03 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-22 12:52:03 --> Database Driver Class Initialized
DEBUG - 2011-08-22 12:52:03 --> File loaded: application/views/table/main.php
DEBUG - 2011-08-22 12:52:03 --> Helper loaded: url_helper
DEBUG - 2011-08-22 12:52:03 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-22 12:52:03 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-22 12:52:03 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-22 12:52:03 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-22 12:52:03 --> Final output sent to browser
DEBUG - 2011-08-22 12:52:03 --> Total execution time: 0.3605
DEBUG - 2011-08-22 12:52:05 --> Config Class Initialized
DEBUG - 2011-08-22 12:52:05 --> Hooks Class Initialized
DEBUG - 2011-08-22 12:52:05 --> Utf8 Class Initialized
DEBUG - 2011-08-22 12:52:05 --> UTF-8 Support Enabled
DEBUG - 2011-08-22 12:52:05 --> URI Class Initialized
DEBUG - 2011-08-22 12:52:05 --> Router Class Initialized
DEBUG - 2011-08-22 12:52:05 --> Output Class Initialized
DEBUG - 2011-08-22 12:52:05 --> Input Class Initialized
DEBUG - 2011-08-22 12:52:05 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-22 12:52:05 --> Language Class Initialized
DEBUG - 2011-08-22 12:52:05 --> Loader Class Initialized
DEBUG - 2011-08-22 12:52:05 --> Controller Class Initialized
DEBUG - 2011-08-22 12:52:05 --> Model Class Initialized
DEBUG - 2011-08-22 12:52:05 --> Model Class Initialized
DEBUG - 2011-08-22 12:52:05 --> Model Class Initialized
DEBUG - 2011-08-22 12:52:05 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-22 12:52:05 --> Database Driver Class Initialized
DEBUG - 2011-08-22 12:52:05 --> File loaded: application/views/table/main.php
DEBUG - 2011-08-22 12:52:05 --> Helper loaded: url_helper
DEBUG - 2011-08-22 12:52:05 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-22 12:52:05 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-22 12:52:05 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-22 12:52:05 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-22 12:52:05 --> Final output sent to browser
DEBUG - 2011-08-22 12:52:05 --> Total execution time: 0.2185
DEBUG - 2011-08-22 12:52:15 --> Config Class Initialized
DEBUG - 2011-08-22 12:52:15 --> Hooks Class Initialized
DEBUG - 2011-08-22 12:52:15 --> Utf8 Class Initialized
DEBUG - 2011-08-22 12:52:15 --> UTF-8 Support Enabled
DEBUG - 2011-08-22 12:52:15 --> URI Class Initialized
DEBUG - 2011-08-22 12:52:15 --> Router Class Initialized
DEBUG - 2011-08-22 12:52:15 --> Output Class Initialized
DEBUG - 2011-08-22 12:52:15 --> Input Class Initialized
DEBUG - 2011-08-22 12:52:15 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-22 12:52:15 --> Language Class Initialized
DEBUG - 2011-08-22 12:52:15 --> Loader Class Initialized
DEBUG - 2011-08-22 12:52:15 --> Controller Class Initialized
DEBUG - 2011-08-22 12:52:15 --> Model Class Initialized
DEBUG - 2011-08-22 12:52:15 --> Model Class Initialized
DEBUG - 2011-08-22 12:52:15 --> Model Class Initialized
DEBUG - 2011-08-22 12:52:15 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-22 12:52:15 --> Database Driver Class Initialized
DEBUG - 2011-08-22 12:52:15 --> File loaded: application/views/table/main.php
DEBUG - 2011-08-22 12:52:15 --> Helper loaded: url_helper
DEBUG - 2011-08-22 12:52:15 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-22 12:52:15 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-22 12:52:15 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-22 12:52:15 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-22 12:52:15 --> Final output sent to browser
DEBUG - 2011-08-22 12:52:15 --> Total execution time: 0.0486
DEBUG - 2011-08-22 12:52:19 --> Config Class Initialized
DEBUG - 2011-08-22 12:52:19 --> Hooks Class Initialized
DEBUG - 2011-08-22 12:52:19 --> Utf8 Class Initialized
DEBUG - 2011-08-22 12:52:19 --> UTF-8 Support Enabled
DEBUG - 2011-08-22 12:52:19 --> URI Class Initialized
DEBUG - 2011-08-22 12:52:19 --> Router Class Initialized
DEBUG - 2011-08-22 12:52:19 --> Output Class Initialized
DEBUG - 2011-08-22 12:52:19 --> Input Class Initialized
DEBUG - 2011-08-22 12:52:19 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-22 12:52:19 --> Language Class Initialized
DEBUG - 2011-08-22 12:52:19 --> Loader Class Initialized
DEBUG - 2011-08-22 12:52:19 --> Controller Class Initialized
DEBUG - 2011-08-22 12:52:19 --> Model Class Initialized
DEBUG - 2011-08-22 12:52:19 --> Model Class Initialized
DEBUG - 2011-08-22 12:52:19 --> Model Class Initialized
DEBUG - 2011-08-22 12:52:19 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-22 12:52:19 --> Database Driver Class Initialized
DEBUG - 2011-08-22 12:52:19 --> File loaded: application/views/table/main.php
DEBUG - 2011-08-22 12:52:19 --> Helper loaded: url_helper
DEBUG - 2011-08-22 12:52:19 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-22 12:52:19 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-22 12:52:19 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-22 12:52:19 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-22 12:52:19 --> Final output sent to browser
DEBUG - 2011-08-22 12:52:19 --> Total execution time: 0.2647
DEBUG - 2011-08-22 12:52:26 --> Config Class Initialized
DEBUG - 2011-08-22 12:52:26 --> Hooks Class Initialized
DEBUG - 2011-08-22 12:52:26 --> Utf8 Class Initialized
DEBUG - 2011-08-22 12:52:26 --> UTF-8 Support Enabled
DEBUG - 2011-08-22 12:52:26 --> URI Class Initialized
DEBUG - 2011-08-22 12:52:26 --> Router Class Initialized
DEBUG - 2011-08-22 12:52:26 --> Output Class Initialized
DEBUG - 2011-08-22 12:52:26 --> Input Class Initialized
DEBUG - 2011-08-22 12:52:26 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-22 12:52:26 --> Language Class Initialized
DEBUG - 2011-08-22 12:52:26 --> Loader Class Initialized
DEBUG - 2011-08-22 12:52:26 --> Controller Class Initialized
DEBUG - 2011-08-22 12:52:26 --> Model Class Initialized
DEBUG - 2011-08-22 12:52:26 --> Model Class Initialized
DEBUG - 2011-08-22 12:52:26 --> Model Class Initialized
DEBUG - 2011-08-22 12:52:26 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-22 12:52:26 --> Database Driver Class Initialized
DEBUG - 2011-08-22 12:52:27 --> File loaded: application/views/table/main.php
DEBUG - 2011-08-22 12:52:27 --> Helper loaded: url_helper
DEBUG - 2011-08-22 12:52:27 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-22 12:52:27 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-22 12:52:27 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-22 12:52:27 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-22 12:52:27 --> Final output sent to browser
DEBUG - 2011-08-22 12:52:27 --> Total execution time: 0.0746
DEBUG - 2011-08-22 12:52:34 --> Config Class Initialized
DEBUG - 2011-08-22 12:52:34 --> Hooks Class Initialized
DEBUG - 2011-08-22 12:52:34 --> Utf8 Class Initialized
DEBUG - 2011-08-22 12:52:34 --> UTF-8 Support Enabled
DEBUG - 2011-08-22 12:52:34 --> URI Class Initialized
DEBUG - 2011-08-22 12:52:34 --> Router Class Initialized
DEBUG - 2011-08-22 12:52:34 --> Output Class Initialized
DEBUG - 2011-08-22 12:52:34 --> Input Class Initialized
DEBUG - 2011-08-22 12:52:34 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-22 12:52:34 --> Language Class Initialized
DEBUG - 2011-08-22 12:52:34 --> Loader Class Initialized
DEBUG - 2011-08-22 12:52:34 --> Controller Class Initialized
DEBUG - 2011-08-22 12:52:34 --> Model Class Initialized
DEBUG - 2011-08-22 12:52:34 --> Model Class Initialized
DEBUG - 2011-08-22 12:52:34 --> Model Class Initialized
DEBUG - 2011-08-22 12:52:34 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-22 12:52:34 --> Database Driver Class Initialized
DEBUG - 2011-08-22 12:52:34 --> File loaded: application/views/table/main.php
DEBUG - 2011-08-22 12:52:34 --> Helper loaded: url_helper
DEBUG - 2011-08-22 12:52:34 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-22 12:52:34 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-22 12:52:34 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-22 12:52:34 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-22 12:52:34 --> Final output sent to browser
DEBUG - 2011-08-22 12:52:34 --> Total execution time: 0.0534
DEBUG - 2011-08-22 12:52:42 --> Config Class Initialized
DEBUG - 2011-08-22 12:52:42 --> Hooks Class Initialized
DEBUG - 2011-08-22 12:52:42 --> Utf8 Class Initialized
DEBUG - 2011-08-22 12:52:42 --> UTF-8 Support Enabled
DEBUG - 2011-08-22 12:52:42 --> URI Class Initialized
DEBUG - 2011-08-22 12:52:42 --> Router Class Initialized
DEBUG - 2011-08-22 12:52:42 --> Output Class Initialized
DEBUG - 2011-08-22 12:52:42 --> Input Class Initialized
DEBUG - 2011-08-22 12:52:42 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-22 12:52:42 --> Language Class Initialized
DEBUG - 2011-08-22 12:52:42 --> Loader Class Initialized
DEBUG - 2011-08-22 12:52:42 --> Controller Class Initialized
DEBUG - 2011-08-22 12:52:42 --> Model Class Initialized
DEBUG - 2011-08-22 12:52:42 --> Model Class Initialized
DEBUG - 2011-08-22 12:52:42 --> Model Class Initialized
DEBUG - 2011-08-22 12:52:42 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-22 12:52:42 --> Database Driver Class Initialized
DEBUG - 2011-08-22 12:52:42 --> File loaded: application/views/table/main.php
DEBUG - 2011-08-22 12:52:42 --> Helper loaded: url_helper
DEBUG - 2011-08-22 12:52:42 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-22 12:52:42 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-22 12:52:42 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-22 12:52:42 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-22 12:52:42 --> Final output sent to browser
DEBUG - 2011-08-22 12:52:42 --> Total execution time: 0.0460
DEBUG - 2011-08-22 12:52:48 --> Config Class Initialized
DEBUG - 2011-08-22 12:52:48 --> Hooks Class Initialized
DEBUG - 2011-08-22 12:52:48 --> Utf8 Class Initialized
DEBUG - 2011-08-22 12:52:48 --> UTF-8 Support Enabled
DEBUG - 2011-08-22 12:52:48 --> URI Class Initialized
DEBUG - 2011-08-22 12:52:48 --> Router Class Initialized
DEBUG - 2011-08-22 12:52:48 --> Output Class Initialized
DEBUG - 2011-08-22 12:52:48 --> Input Class Initialized
DEBUG - 2011-08-22 12:52:48 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-22 12:52:48 --> Language Class Initialized
DEBUG - 2011-08-22 12:52:48 --> Loader Class Initialized
DEBUG - 2011-08-22 12:52:48 --> Controller Class Initialized
DEBUG - 2011-08-22 12:52:48 --> Model Class Initialized
DEBUG - 2011-08-22 12:52:48 --> Model Class Initialized
DEBUG - 2011-08-22 12:52:48 --> Model Class Initialized
DEBUG - 2011-08-22 12:52:48 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-22 12:52:48 --> Database Driver Class Initialized
DEBUG - 2011-08-22 12:52:48 --> File loaded: application/views/table/main.php
DEBUG - 2011-08-22 12:52:48 --> Helper loaded: url_helper
DEBUG - 2011-08-22 12:52:48 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-22 12:52:48 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-22 12:52:48 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-22 12:52:48 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-22 12:52:48 --> Final output sent to browser
DEBUG - 2011-08-22 12:52:48 --> Total execution time: 0.1185
DEBUG - 2011-08-22 12:53:00 --> Config Class Initialized
DEBUG - 2011-08-22 12:53:00 --> Hooks Class Initialized
DEBUG - 2011-08-22 12:53:00 --> Utf8 Class Initialized
DEBUG - 2011-08-22 12:53:00 --> UTF-8 Support Enabled
DEBUG - 2011-08-22 12:53:00 --> URI Class Initialized
DEBUG - 2011-08-22 12:53:00 --> Router Class Initialized
DEBUG - 2011-08-22 12:53:00 --> Output Class Initialized
DEBUG - 2011-08-22 12:53:00 --> Input Class Initialized
DEBUG - 2011-08-22 12:53:00 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-22 12:53:00 --> Language Class Initialized
DEBUG - 2011-08-22 12:53:00 --> Loader Class Initialized
DEBUG - 2011-08-22 12:53:00 --> Controller Class Initialized
DEBUG - 2011-08-22 12:53:00 --> Model Class Initialized
DEBUG - 2011-08-22 12:53:00 --> Model Class Initialized
DEBUG - 2011-08-22 12:53:00 --> Model Class Initialized
DEBUG - 2011-08-22 12:53:00 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-22 12:53:00 --> Database Driver Class Initialized
DEBUG - 2011-08-22 12:53:00 --> File loaded: application/views/table/main.php
DEBUG - 2011-08-22 12:53:00 --> Helper loaded: url_helper
DEBUG - 2011-08-22 12:53:00 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-22 12:53:00 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-22 12:53:00 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-22 12:53:00 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-22 12:53:00 --> Final output sent to browser
DEBUG - 2011-08-22 12:53:00 --> Total execution time: 0.2346
DEBUG - 2011-08-22 12:53:12 --> Config Class Initialized
DEBUG - 2011-08-22 12:53:12 --> Hooks Class Initialized
DEBUG - 2011-08-22 12:53:12 --> Utf8 Class Initialized
DEBUG - 2011-08-22 12:53:12 --> UTF-8 Support Enabled
DEBUG - 2011-08-22 12:53:12 --> URI Class Initialized
DEBUG - 2011-08-22 12:53:12 --> Router Class Initialized
DEBUG - 2011-08-22 12:53:12 --> Output Class Initialized
DEBUG - 2011-08-22 12:53:12 --> Input Class Initialized
DEBUG - 2011-08-22 12:53:12 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-22 12:53:12 --> Language Class Initialized
DEBUG - 2011-08-22 12:53:12 --> Loader Class Initialized
DEBUG - 2011-08-22 12:53:12 --> Controller Class Initialized
DEBUG - 2011-08-22 12:53:12 --> Model Class Initialized
DEBUG - 2011-08-22 12:53:12 --> Model Class Initialized
DEBUG - 2011-08-22 12:53:12 --> Model Class Initialized
DEBUG - 2011-08-22 12:53:12 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-22 12:53:12 --> Database Driver Class Initialized
DEBUG - 2011-08-22 12:53:13 --> File loaded: application/views/table/main.php
DEBUG - 2011-08-22 12:53:13 --> Helper loaded: url_helper
DEBUG - 2011-08-22 12:53:13 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-22 12:53:13 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-22 12:53:13 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-22 12:53:13 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-22 12:53:13 --> Final output sent to browser
DEBUG - 2011-08-22 12:53:13 --> Total execution time: 0.3851
DEBUG - 2011-08-22 12:53:15 --> Config Class Initialized
DEBUG - 2011-08-22 12:53:15 --> Hooks Class Initialized
DEBUG - 2011-08-22 12:53:15 --> Utf8 Class Initialized
DEBUG - 2011-08-22 12:53:15 --> UTF-8 Support Enabled
DEBUG - 2011-08-22 12:53:15 --> URI Class Initialized
DEBUG - 2011-08-22 12:53:15 --> Router Class Initialized
DEBUG - 2011-08-22 12:53:15 --> Output Class Initialized
DEBUG - 2011-08-22 12:53:15 --> Input Class Initialized
DEBUG - 2011-08-22 12:53:15 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-22 12:53:15 --> Language Class Initialized
DEBUG - 2011-08-22 12:53:15 --> Loader Class Initialized
DEBUG - 2011-08-22 12:53:15 --> Controller Class Initialized
DEBUG - 2011-08-22 12:53:15 --> Model Class Initialized
DEBUG - 2011-08-22 12:53:15 --> Model Class Initialized
DEBUG - 2011-08-22 12:53:15 --> Model Class Initialized
DEBUG - 2011-08-22 12:53:15 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-22 12:53:15 --> Database Driver Class Initialized
DEBUG - 2011-08-22 12:53:15 --> File loaded: application/views/table/main.php
DEBUG - 2011-08-22 12:53:15 --> Helper loaded: url_helper
DEBUG - 2011-08-22 12:53:15 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-22 12:53:15 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-22 12:53:15 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-22 12:53:15 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-22 12:53:15 --> Final output sent to browser
DEBUG - 2011-08-22 12:53:15 --> Total execution time: 0.0437
DEBUG - 2011-08-22 12:53:33 --> Config Class Initialized
DEBUG - 2011-08-22 12:53:33 --> Hooks Class Initialized
DEBUG - 2011-08-22 12:53:33 --> Utf8 Class Initialized
DEBUG - 2011-08-22 12:53:33 --> UTF-8 Support Enabled
DEBUG - 2011-08-22 12:53:33 --> URI Class Initialized
DEBUG - 2011-08-22 12:53:33 --> Router Class Initialized
DEBUG - 2011-08-22 12:53:33 --> Output Class Initialized
DEBUG - 2011-08-22 12:53:33 --> Input Class Initialized
DEBUG - 2011-08-22 12:53:33 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-22 12:53:33 --> Language Class Initialized
DEBUG - 2011-08-22 12:53:33 --> Loader Class Initialized
DEBUG - 2011-08-22 12:53:33 --> Controller Class Initialized
DEBUG - 2011-08-22 12:53:33 --> Model Class Initialized
DEBUG - 2011-08-22 12:53:33 --> Model Class Initialized
DEBUG - 2011-08-22 12:53:33 --> Model Class Initialized
DEBUG - 2011-08-22 12:53:33 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-22 12:53:33 --> Database Driver Class Initialized
DEBUG - 2011-08-22 12:53:34 --> File loaded: application/views/table/main.php
DEBUG - 2011-08-22 12:53:34 --> Helper loaded: url_helper
DEBUG - 2011-08-22 12:53:34 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-22 12:53:34 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-22 12:53:34 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-22 12:53:34 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-22 12:53:34 --> Final output sent to browser
DEBUG - 2011-08-22 12:53:34 --> Total execution time: 0.4080
DEBUG - 2011-08-22 12:53:51 --> Config Class Initialized
DEBUG - 2011-08-22 12:53:51 --> Hooks Class Initialized
DEBUG - 2011-08-22 12:53:51 --> Utf8 Class Initialized
DEBUG - 2011-08-22 12:53:51 --> UTF-8 Support Enabled
DEBUG - 2011-08-22 12:53:51 --> URI Class Initialized
DEBUG - 2011-08-22 12:53:51 --> Router Class Initialized
DEBUG - 2011-08-22 12:53:51 --> Output Class Initialized
DEBUG - 2011-08-22 12:53:51 --> Input Class Initialized
DEBUG - 2011-08-22 12:53:51 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-22 12:53:51 --> Language Class Initialized
DEBUG - 2011-08-22 12:53:51 --> Loader Class Initialized
DEBUG - 2011-08-22 12:53:51 --> Controller Class Initialized
DEBUG - 2011-08-22 12:53:51 --> Model Class Initialized
DEBUG - 2011-08-22 12:53:51 --> Model Class Initialized
DEBUG - 2011-08-22 12:53:51 --> Model Class Initialized
DEBUG - 2011-08-22 12:53:51 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-22 12:53:51 --> Database Driver Class Initialized
DEBUG - 2011-08-22 12:53:51 --> File loaded: application/views/table/main.php
DEBUG - 2011-08-22 12:53:51 --> Helper loaded: url_helper
DEBUG - 2011-08-22 12:53:51 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-22 12:53:51 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-22 12:53:51 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-22 12:53:51 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-22 12:53:51 --> Final output sent to browser
DEBUG - 2011-08-22 12:53:51 --> Total execution time: 0.0445
DEBUG - 2011-08-22 12:54:10 --> Config Class Initialized
DEBUG - 2011-08-22 12:54:10 --> Hooks Class Initialized
DEBUG - 2011-08-22 12:54:10 --> Utf8 Class Initialized
DEBUG - 2011-08-22 12:54:10 --> UTF-8 Support Enabled
DEBUG - 2011-08-22 12:54:10 --> URI Class Initialized
DEBUG - 2011-08-22 12:54:10 --> Router Class Initialized
DEBUG - 2011-08-22 12:54:10 --> Output Class Initialized
DEBUG - 2011-08-22 12:54:10 --> Input Class Initialized
DEBUG - 2011-08-22 12:54:10 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-22 12:54:10 --> Language Class Initialized
DEBUG - 2011-08-22 12:54:10 --> Loader Class Initialized
DEBUG - 2011-08-22 12:54:10 --> Controller Class Initialized
DEBUG - 2011-08-22 12:54:10 --> Model Class Initialized
DEBUG - 2011-08-22 12:54:10 --> Model Class Initialized
DEBUG - 2011-08-22 12:54:10 --> Model Class Initialized
DEBUG - 2011-08-22 12:54:10 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-22 12:54:10 --> Database Driver Class Initialized
DEBUG - 2011-08-22 12:54:10 --> File loaded: application/views/table/main.php
DEBUG - 2011-08-22 12:54:10 --> Helper loaded: url_helper
DEBUG - 2011-08-22 12:54:10 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-22 12:54:10 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-22 12:54:10 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-22 12:54:10 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-22 12:54:10 --> Final output sent to browser
DEBUG - 2011-08-22 12:54:10 --> Total execution time: 0.0448
DEBUG - 2011-08-22 12:55:08 --> Config Class Initialized
DEBUG - 2011-08-22 12:55:08 --> Hooks Class Initialized
DEBUG - 2011-08-22 12:55:08 --> Utf8 Class Initialized
DEBUG - 2011-08-22 12:55:08 --> UTF-8 Support Enabled
DEBUG - 2011-08-22 12:55:08 --> URI Class Initialized
DEBUG - 2011-08-22 12:55:08 --> Router Class Initialized
DEBUG - 2011-08-22 12:55:08 --> Output Class Initialized
DEBUG - 2011-08-22 12:55:08 --> Input Class Initialized
DEBUG - 2011-08-22 12:55:08 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-22 12:55:08 --> Language Class Initialized
DEBUG - 2011-08-22 12:55:08 --> Loader Class Initialized
DEBUG - 2011-08-22 12:55:08 --> Controller Class Initialized
ERROR - 2011-08-22 12:55:08 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-08-22 12:55:08 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-08-22 12:55:08 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-08-22 12:55:08 --> Model Class Initialized
DEBUG - 2011-08-22 12:55:08 --> Model Class Initialized
DEBUG - 2011-08-22 12:55:08 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-22 12:55:08 --> Database Driver Class Initialized
DEBUG - 2011-08-22 12:55:08 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-08-22 12:55:08 --> Helper loaded: url_helper
DEBUG - 2011-08-22 12:55:08 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-22 12:55:08 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-22 12:55:08 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-22 12:55:08 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-22 12:55:08 --> Final output sent to browser
DEBUG - 2011-08-22 12:55:08 --> Total execution time: 0.0434
DEBUG - 2011-08-22 12:55:09 --> Config Class Initialized
DEBUG - 2011-08-22 12:55:09 --> Hooks Class Initialized
DEBUG - 2011-08-22 12:55:09 --> Utf8 Class Initialized
DEBUG - 2011-08-22 12:55:09 --> UTF-8 Support Enabled
DEBUG - 2011-08-22 12:55:09 --> URI Class Initialized
DEBUG - 2011-08-22 12:55:09 --> Router Class Initialized
DEBUG - 2011-08-22 12:55:09 --> Output Class Initialized
DEBUG - 2011-08-22 12:55:09 --> Input Class Initialized
DEBUG - 2011-08-22 12:55:09 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-22 12:55:09 --> Language Class Initialized
DEBUG - 2011-08-22 12:55:09 --> Loader Class Initialized
DEBUG - 2011-08-22 12:55:09 --> Controller Class Initialized
DEBUG - 2011-08-22 12:55:09 --> Model Class Initialized
DEBUG - 2011-08-22 12:55:09 --> Model Class Initialized
DEBUG - 2011-08-22 12:55:09 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-22 12:55:09 --> Database Driver Class Initialized
DEBUG - 2011-08-22 12:55:10 --> Final output sent to browser
DEBUG - 2011-08-22 12:55:10 --> Total execution time: 1.2063
DEBUG - 2011-08-22 12:55:50 --> Config Class Initialized
DEBUG - 2011-08-22 12:55:50 --> Hooks Class Initialized
DEBUG - 2011-08-22 12:55:50 --> Utf8 Class Initialized
DEBUG - 2011-08-22 12:55:50 --> UTF-8 Support Enabled
DEBUG - 2011-08-22 12:55:50 --> URI Class Initialized
DEBUG - 2011-08-22 12:55:50 --> Router Class Initialized
DEBUG - 2011-08-22 12:55:50 --> Output Class Initialized
DEBUG - 2011-08-22 12:55:50 --> Input Class Initialized
DEBUG - 2011-08-22 12:55:50 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-22 12:55:50 --> Language Class Initialized
DEBUG - 2011-08-22 12:55:50 --> Loader Class Initialized
DEBUG - 2011-08-22 12:55:50 --> Controller Class Initialized
ERROR - 2011-08-22 12:55:50 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-08-22 12:55:50 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-08-22 12:55:50 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-08-22 12:55:50 --> Model Class Initialized
DEBUG - 2011-08-22 12:55:50 --> Model Class Initialized
DEBUG - 2011-08-22 12:55:50 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-22 12:55:50 --> Database Driver Class Initialized
DEBUG - 2011-08-22 12:55:50 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-08-22 12:55:50 --> Helper loaded: url_helper
DEBUG - 2011-08-22 12:55:50 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-22 12:55:50 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-22 12:55:50 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-22 12:55:50 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-22 12:55:50 --> Final output sent to browser
DEBUG - 2011-08-22 12:55:50 --> Total execution time: 0.0307
DEBUG - 2011-08-22 12:55:51 --> Config Class Initialized
DEBUG - 2011-08-22 12:55:51 --> Hooks Class Initialized
DEBUG - 2011-08-22 12:55:51 --> Utf8 Class Initialized
DEBUG - 2011-08-22 12:55:51 --> UTF-8 Support Enabled
DEBUG - 2011-08-22 12:55:51 --> URI Class Initialized
DEBUG - 2011-08-22 12:55:51 --> Router Class Initialized
DEBUG - 2011-08-22 12:55:51 --> Output Class Initialized
DEBUG - 2011-08-22 12:55:51 --> Input Class Initialized
DEBUG - 2011-08-22 12:55:51 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-22 12:55:51 --> Language Class Initialized
DEBUG - 2011-08-22 12:55:51 --> Loader Class Initialized
DEBUG - 2011-08-22 12:55:51 --> Controller Class Initialized
DEBUG - 2011-08-22 12:55:51 --> Model Class Initialized
DEBUG - 2011-08-22 12:55:51 --> Model Class Initialized
DEBUG - 2011-08-22 12:55:51 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-22 12:55:51 --> Database Driver Class Initialized
DEBUG - 2011-08-22 12:55:51 --> Final output sent to browser
DEBUG - 2011-08-22 12:55:51 --> Total execution time: 0.5670
DEBUG - 2011-08-22 12:56:07 --> Config Class Initialized
DEBUG - 2011-08-22 12:56:07 --> Hooks Class Initialized
DEBUG - 2011-08-22 12:56:07 --> Utf8 Class Initialized
DEBUG - 2011-08-22 12:56:07 --> UTF-8 Support Enabled
DEBUG - 2011-08-22 12:56:07 --> URI Class Initialized
DEBUG - 2011-08-22 12:56:07 --> Router Class Initialized
DEBUG - 2011-08-22 12:56:07 --> Output Class Initialized
DEBUG - 2011-08-22 12:56:07 --> Input Class Initialized
DEBUG - 2011-08-22 12:56:07 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-22 12:56:07 --> Language Class Initialized
DEBUG - 2011-08-22 12:56:07 --> Loader Class Initialized
DEBUG - 2011-08-22 12:56:07 --> Controller Class Initialized
ERROR - 2011-08-22 12:56:07 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-08-22 12:56:07 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-08-22 12:56:07 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-08-22 12:56:07 --> Model Class Initialized
DEBUG - 2011-08-22 12:56:07 --> Model Class Initialized
DEBUG - 2011-08-22 12:56:07 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-22 12:56:07 --> Database Driver Class Initialized
DEBUG - 2011-08-22 12:56:07 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-08-22 12:56:07 --> Helper loaded: url_helper
DEBUG - 2011-08-22 12:56:07 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-22 12:56:07 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-22 12:56:07 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-22 12:56:07 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-22 12:56:07 --> Final output sent to browser
DEBUG - 2011-08-22 12:56:07 --> Total execution time: 0.0295
DEBUG - 2011-08-22 12:56:08 --> Config Class Initialized
DEBUG - 2011-08-22 12:56:08 --> Hooks Class Initialized
DEBUG - 2011-08-22 12:56:08 --> Utf8 Class Initialized
DEBUG - 2011-08-22 12:56:08 --> UTF-8 Support Enabled
DEBUG - 2011-08-22 12:56:08 --> URI Class Initialized
DEBUG - 2011-08-22 12:56:08 --> Router Class Initialized
DEBUG - 2011-08-22 12:56:08 --> Output Class Initialized
DEBUG - 2011-08-22 12:56:08 --> Input Class Initialized
DEBUG - 2011-08-22 12:56:08 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-22 12:56:08 --> Language Class Initialized
DEBUG - 2011-08-22 12:56:08 --> Loader Class Initialized
DEBUG - 2011-08-22 12:56:08 --> Controller Class Initialized
DEBUG - 2011-08-22 12:56:08 --> Model Class Initialized
DEBUG - 2011-08-22 12:56:08 --> Model Class Initialized
DEBUG - 2011-08-22 12:56:08 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-22 12:56:08 --> Database Driver Class Initialized
DEBUG - 2011-08-22 12:56:10 --> Final output sent to browser
DEBUG - 2011-08-22 12:56:10 --> Total execution time: 1.2308
DEBUG - 2011-08-22 14:32:18 --> Config Class Initialized
DEBUG - 2011-08-22 14:32:18 --> Hooks Class Initialized
DEBUG - 2011-08-22 14:32:18 --> Utf8 Class Initialized
DEBUG - 2011-08-22 14:32:18 --> UTF-8 Support Enabled
DEBUG - 2011-08-22 14:32:18 --> URI Class Initialized
DEBUG - 2011-08-22 14:32:18 --> Router Class Initialized
ERROR - 2011-08-22 14:32:18 --> 404 Page Not Found --> robots.txt
DEBUG - 2011-08-22 14:37:34 --> Config Class Initialized
DEBUG - 2011-08-22 14:37:34 --> Hooks Class Initialized
DEBUG - 2011-08-22 14:37:34 --> Utf8 Class Initialized
DEBUG - 2011-08-22 14:37:34 --> UTF-8 Support Enabled
DEBUG - 2011-08-22 14:37:34 --> URI Class Initialized
DEBUG - 2011-08-22 14:37:34 --> Router Class Initialized
DEBUG - 2011-08-22 14:37:35 --> Output Class Initialized
DEBUG - 2011-08-22 14:37:35 --> Input Class Initialized
DEBUG - 2011-08-22 14:37:35 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-22 14:37:35 --> Language Class Initialized
DEBUG - 2011-08-22 14:37:35 --> Loader Class Initialized
DEBUG - 2011-08-22 14:37:35 --> Controller Class Initialized
DEBUG - 2011-08-22 14:37:35 --> Model Class Initialized
DEBUG - 2011-08-22 14:37:35 --> Model Class Initialized
DEBUG - 2011-08-22 14:37:35 --> Model Class Initialized
DEBUG - 2011-08-22 14:37:35 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-22 14:37:35 --> Database Driver Class Initialized
DEBUG - 2011-08-22 14:37:35 --> File loaded: application/views/table/main.php
DEBUG - 2011-08-22 14:37:35 --> Helper loaded: url_helper
DEBUG - 2011-08-22 14:37:35 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-22 14:37:35 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-22 14:37:35 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-22 14:37:35 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-22 14:37:35 --> Final output sent to browser
DEBUG - 2011-08-22 14:37:35 --> Total execution time: 1.4991
DEBUG - 2011-08-22 14:37:40 --> Config Class Initialized
DEBUG - 2011-08-22 14:37:40 --> Hooks Class Initialized
DEBUG - 2011-08-22 14:37:40 --> Utf8 Class Initialized
DEBUG - 2011-08-22 14:37:40 --> UTF-8 Support Enabled
DEBUG - 2011-08-22 14:37:40 --> URI Class Initialized
DEBUG - 2011-08-22 14:37:40 --> Router Class Initialized
ERROR - 2011-08-22 14:37:40 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-08-22 14:38:17 --> Config Class Initialized
DEBUG - 2011-08-22 14:38:17 --> Hooks Class Initialized
DEBUG - 2011-08-22 14:38:17 --> Utf8 Class Initialized
DEBUG - 2011-08-22 14:38:17 --> UTF-8 Support Enabled
DEBUG - 2011-08-22 14:38:17 --> URI Class Initialized
DEBUG - 2011-08-22 14:38:17 --> Router Class Initialized
DEBUG - 2011-08-22 14:38:17 --> Output Class Initialized
DEBUG - 2011-08-22 14:38:17 --> Input Class Initialized
DEBUG - 2011-08-22 14:38:17 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-22 14:38:17 --> Language Class Initialized
DEBUG - 2011-08-22 14:38:17 --> Loader Class Initialized
DEBUG - 2011-08-22 14:38:17 --> Controller Class Initialized
DEBUG - 2011-08-22 14:38:17 --> Model Class Initialized
DEBUG - 2011-08-22 14:38:17 --> Model Class Initialized
DEBUG - 2011-08-22 14:38:17 --> Model Class Initialized
DEBUG - 2011-08-22 14:38:17 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-22 14:38:17 --> Database Driver Class Initialized
DEBUG - 2011-08-22 14:38:17 --> File loaded: application/views/table/main.php
DEBUG - 2011-08-22 14:38:17 --> Helper loaded: url_helper
DEBUG - 2011-08-22 14:38:17 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-22 14:38:17 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-22 14:38:17 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-22 14:38:17 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-22 14:38:17 --> Final output sent to browser
DEBUG - 2011-08-22 14:38:17 --> Total execution time: 0.2847
DEBUG - 2011-08-22 14:38:19 --> Config Class Initialized
DEBUG - 2011-08-22 14:38:19 --> Hooks Class Initialized
DEBUG - 2011-08-22 14:38:19 --> Utf8 Class Initialized
DEBUG - 2011-08-22 14:38:19 --> UTF-8 Support Enabled
DEBUG - 2011-08-22 14:38:19 --> URI Class Initialized
DEBUG - 2011-08-22 14:38:19 --> Router Class Initialized
ERROR - 2011-08-22 14:38:19 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-08-22 14:38:32 --> Config Class Initialized
DEBUG - 2011-08-22 14:38:32 --> Hooks Class Initialized
DEBUG - 2011-08-22 14:38:32 --> Utf8 Class Initialized
DEBUG - 2011-08-22 14:38:32 --> UTF-8 Support Enabled
DEBUG - 2011-08-22 14:38:32 --> URI Class Initialized
DEBUG - 2011-08-22 14:38:32 --> Router Class Initialized
DEBUG - 2011-08-22 14:38:32 --> Output Class Initialized
DEBUG - 2011-08-22 14:38:32 --> Input Class Initialized
DEBUG - 2011-08-22 14:38:32 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-22 14:38:32 --> Language Class Initialized
DEBUG - 2011-08-22 14:38:32 --> Loader Class Initialized
DEBUG - 2011-08-22 14:38:32 --> Controller Class Initialized
DEBUG - 2011-08-22 14:38:32 --> Model Class Initialized
DEBUG - 2011-08-22 14:38:32 --> Model Class Initialized
DEBUG - 2011-08-22 14:38:32 --> Model Class Initialized
DEBUG - 2011-08-22 14:38:32 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-22 14:38:32 --> Database Driver Class Initialized
DEBUG - 2011-08-22 14:38:33 --> File loaded: application/views/table/main.php
DEBUG - 2011-08-22 14:38:33 --> Helper loaded: url_helper
DEBUG - 2011-08-22 14:38:33 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-22 14:38:33 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-22 14:38:33 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-22 14:38:33 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-22 14:38:33 --> Final output sent to browser
DEBUG - 2011-08-22 14:38:33 --> Total execution time: 0.4468
DEBUG - 2011-08-22 14:38:34 --> Config Class Initialized
DEBUG - 2011-08-22 14:38:34 --> Hooks Class Initialized
DEBUG - 2011-08-22 14:38:34 --> Utf8 Class Initialized
DEBUG - 2011-08-22 14:38:34 --> UTF-8 Support Enabled
DEBUG - 2011-08-22 14:38:35 --> URI Class Initialized
DEBUG - 2011-08-22 14:38:35 --> Router Class Initialized
ERROR - 2011-08-22 14:38:35 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-08-22 14:38:50 --> Config Class Initialized
DEBUG - 2011-08-22 14:38:50 --> Hooks Class Initialized
DEBUG - 2011-08-22 14:38:50 --> Utf8 Class Initialized
DEBUG - 2011-08-22 14:38:50 --> UTF-8 Support Enabled
DEBUG - 2011-08-22 14:38:50 --> URI Class Initialized
DEBUG - 2011-08-22 14:38:50 --> Router Class Initialized
DEBUG - 2011-08-22 14:38:50 --> Output Class Initialized
DEBUG - 2011-08-22 14:38:50 --> Input Class Initialized
DEBUG - 2011-08-22 14:38:50 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-22 14:38:50 --> Language Class Initialized
DEBUG - 2011-08-22 14:38:50 --> Loader Class Initialized
DEBUG - 2011-08-22 14:38:50 --> Controller Class Initialized
DEBUG - 2011-08-22 14:38:50 --> Model Class Initialized
DEBUG - 2011-08-22 14:38:50 --> Model Class Initialized
DEBUG - 2011-08-22 14:38:50 --> Model Class Initialized
DEBUG - 2011-08-22 14:38:50 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-22 14:38:50 --> Database Driver Class Initialized
DEBUG - 2011-08-22 14:38:50 --> File loaded: application/views/table/main.php
DEBUG - 2011-08-22 14:38:50 --> Helper loaded: url_helper
DEBUG - 2011-08-22 14:38:50 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-22 14:38:50 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-22 14:38:50 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-22 14:38:50 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-22 14:38:50 --> Final output sent to browser
DEBUG - 2011-08-22 14:38:50 --> Total execution time: 0.0499
DEBUG - 2011-08-22 14:38:51 --> Config Class Initialized
DEBUG - 2011-08-22 14:38:51 --> Hooks Class Initialized
DEBUG - 2011-08-22 14:38:51 --> Utf8 Class Initialized
DEBUG - 2011-08-22 14:38:51 --> UTF-8 Support Enabled
DEBUG - 2011-08-22 14:38:51 --> URI Class Initialized
DEBUG - 2011-08-22 14:38:51 --> Router Class Initialized
ERROR - 2011-08-22 14:38:51 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-08-22 16:01:28 --> Config Class Initialized
DEBUG - 2011-08-22 16:01:28 --> Hooks Class Initialized
DEBUG - 2011-08-22 16:01:28 --> Utf8 Class Initialized
DEBUG - 2011-08-22 16:01:28 --> UTF-8 Support Enabled
DEBUG - 2011-08-22 16:01:28 --> URI Class Initialized
DEBUG - 2011-08-22 16:01:28 --> Router Class Initialized
DEBUG - 2011-08-22 16:01:28 --> Output Class Initialized
DEBUG - 2011-08-22 16:01:28 --> Input Class Initialized
DEBUG - 2011-08-22 16:01:28 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-22 16:01:28 --> Language Class Initialized
DEBUG - 2011-08-22 16:01:28 --> Loader Class Initialized
DEBUG - 2011-08-22 16:01:28 --> Controller Class Initialized
ERROR - 2011-08-22 16:01:28 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-08-22 16:01:28 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-08-22 16:01:28 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-08-22 16:01:28 --> Model Class Initialized
DEBUG - 2011-08-22 16:01:28 --> Model Class Initialized
DEBUG - 2011-08-22 16:01:28 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-22 16:01:28 --> Database Driver Class Initialized
DEBUG - 2011-08-22 16:01:28 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-08-22 16:01:28 --> Helper loaded: url_helper
DEBUG - 2011-08-22 16:01:28 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-22 16:01:28 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-22 16:01:28 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-22 16:01:28 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-22 16:01:28 --> Final output sent to browser
DEBUG - 2011-08-22 16:01:28 --> Total execution time: 0.1517
DEBUG - 2011-08-22 16:07:21 --> Config Class Initialized
DEBUG - 2011-08-22 16:07:21 --> Hooks Class Initialized
DEBUG - 2011-08-22 16:07:21 --> Utf8 Class Initialized
DEBUG - 2011-08-22 16:07:21 --> UTF-8 Support Enabled
DEBUG - 2011-08-22 16:07:21 --> URI Class Initialized
DEBUG - 2011-08-22 16:07:21 --> Router Class Initialized
ERROR - 2011-08-22 16:07:21 --> 404 Page Not Found --> robots.txt
DEBUG - 2011-08-22 16:07:21 --> Config Class Initialized
DEBUG - 2011-08-22 16:07:21 --> Hooks Class Initialized
DEBUG - 2011-08-22 16:07:21 --> Utf8 Class Initialized
DEBUG - 2011-08-22 16:07:21 --> UTF-8 Support Enabled
DEBUG - 2011-08-22 16:07:21 --> URI Class Initialized
DEBUG - 2011-08-22 16:07:21 --> Router Class Initialized
DEBUG - 2011-08-22 16:07:21 --> Output Class Initialized
DEBUG - 2011-08-22 16:07:21 --> Input Class Initialized
DEBUG - 2011-08-22 16:07:21 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-22 16:07:21 --> Language Class Initialized
DEBUG - 2011-08-22 16:07:21 --> Loader Class Initialized
DEBUG - 2011-08-22 16:07:21 --> Controller Class Initialized
ERROR - 2011-08-22 16:07:21 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-08-22 16:07:21 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-08-22 16:07:21 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-08-22 16:07:21 --> Model Class Initialized
DEBUG - 2011-08-22 16:07:21 --> Model Class Initialized
DEBUG - 2011-08-22 16:07:21 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-22 16:07:21 --> Database Driver Class Initialized
DEBUG - 2011-08-22 16:07:21 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-08-22 16:07:21 --> Helper loaded: url_helper
DEBUG - 2011-08-22 16:07:21 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-22 16:07:21 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-22 16:07:21 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-22 16:07:21 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-22 16:07:21 --> Final output sent to browser
DEBUG - 2011-08-22 16:07:21 --> Total execution time: 0.0284
DEBUG - 2011-08-22 16:11:56 --> Config Class Initialized
DEBUG - 2011-08-22 16:11:56 --> Hooks Class Initialized
DEBUG - 2011-08-22 16:11:56 --> Utf8 Class Initialized
DEBUG - 2011-08-22 16:11:56 --> UTF-8 Support Enabled
DEBUG - 2011-08-22 16:11:56 --> URI Class Initialized
DEBUG - 2011-08-22 16:11:56 --> Router Class Initialized
DEBUG - 2011-08-22 16:11:56 --> Output Class Initialized
DEBUG - 2011-08-22 16:11:56 --> Input Class Initialized
DEBUG - 2011-08-22 16:11:56 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-22 16:11:56 --> Language Class Initialized
DEBUG - 2011-08-22 16:11:56 --> Loader Class Initialized
DEBUG - 2011-08-22 16:11:56 --> Controller Class Initialized
ERROR - 2011-08-22 16:11:56 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-08-22 16:11:56 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-08-22 16:11:56 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-08-22 16:11:56 --> Model Class Initialized
DEBUG - 2011-08-22 16:11:56 --> Model Class Initialized
DEBUG - 2011-08-22 16:11:56 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-22 16:11:56 --> Database Driver Class Initialized
DEBUG - 2011-08-22 16:11:56 --> Config Class Initialized
DEBUG - 2011-08-22 16:11:56 --> Hooks Class Initialized
DEBUG - 2011-08-22 16:11:56 --> Utf8 Class Initialized
DEBUG - 2011-08-22 16:11:56 --> UTF-8 Support Enabled
DEBUG - 2011-08-22 16:11:56 --> URI Class Initialized
DEBUG - 2011-08-22 16:11:56 --> Router Class Initialized
DEBUG - 2011-08-22 16:11:56 --> Output Class Initialized
DEBUG - 2011-08-22 16:11:56 --> Input Class Initialized
DEBUG - 2011-08-22 16:11:56 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-22 16:11:56 --> Language Class Initialized
DEBUG - 2011-08-22 16:11:56 --> Loader Class Initialized
DEBUG - 2011-08-22 16:11:56 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-08-22 16:11:56 --> Helper loaded: url_helper
DEBUG - 2011-08-22 16:11:56 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-22 16:11:56 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-22 16:11:56 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-22 16:11:56 --> Controller Class Initialized
ERROR - 2011-08-22 16:11:56 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-08-22 16:11:56 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-08-22 16:11:56 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-22 16:11:56 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-08-22 16:11:56 --> Final output sent to browser
DEBUG - 2011-08-22 16:11:56 --> Total execution time: 0.0630
DEBUG - 2011-08-22 16:11:56 --> Model Class Initialized
DEBUG - 2011-08-22 16:11:56 --> Model Class Initialized
DEBUG - 2011-08-22 16:11:56 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-22 16:11:56 --> Database Driver Class Initialized
DEBUG - 2011-08-22 16:11:56 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-08-22 16:11:56 --> Helper loaded: url_helper
DEBUG - 2011-08-22 16:11:56 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-22 16:11:56 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-22 16:11:56 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-22 16:11:56 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-22 16:11:56 --> Final output sent to browser
DEBUG - 2011-08-22 16:11:56 --> Total execution time: 0.0505
DEBUG - 2011-08-22 16:11:57 --> Config Class Initialized
DEBUG - 2011-08-22 16:11:57 --> Hooks Class Initialized
DEBUG - 2011-08-22 16:11:57 --> Utf8 Class Initialized
DEBUG - 2011-08-22 16:11:57 --> UTF-8 Support Enabled
DEBUG - 2011-08-22 16:11:57 --> URI Class Initialized
DEBUG - 2011-08-22 16:11:57 --> Router Class Initialized
DEBUG - 2011-08-22 16:11:57 --> Output Class Initialized
DEBUG - 2011-08-22 16:11:57 --> Input Class Initialized
DEBUG - 2011-08-22 16:11:57 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-22 16:11:57 --> Language Class Initialized
DEBUG - 2011-08-22 16:11:57 --> Loader Class Initialized
DEBUG - 2011-08-22 16:11:57 --> Controller Class Initialized
DEBUG - 2011-08-22 16:11:58 --> Model Class Initialized
DEBUG - 2011-08-22 16:11:58 --> Model Class Initialized
DEBUG - 2011-08-22 16:11:58 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-22 16:11:58 --> Database Driver Class Initialized
DEBUG - 2011-08-22 16:12:03 --> Final output sent to browser
DEBUG - 2011-08-22 16:12:03 --> Total execution time: 5.7215
DEBUG - 2011-08-22 16:12:05 --> Config Class Initialized
DEBUG - 2011-08-22 16:12:05 --> Hooks Class Initialized
DEBUG - 2011-08-22 16:12:05 --> Utf8 Class Initialized
DEBUG - 2011-08-22 16:12:05 --> UTF-8 Support Enabled
DEBUG - 2011-08-22 16:12:05 --> URI Class Initialized
DEBUG - 2011-08-22 16:12:05 --> Router Class Initialized
ERROR - 2011-08-22 16:12:05 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-08-22 16:46:23 --> Config Class Initialized
DEBUG - 2011-08-22 16:46:23 --> Hooks Class Initialized
DEBUG - 2011-08-22 16:46:23 --> Utf8 Class Initialized
DEBUG - 2011-08-22 16:46:23 --> UTF-8 Support Enabled
DEBUG - 2011-08-22 16:46:23 --> URI Class Initialized
DEBUG - 2011-08-22 16:46:23 --> Router Class Initialized
DEBUG - 2011-08-22 16:46:23 --> Output Class Initialized
DEBUG - 2011-08-22 16:46:23 --> Input Class Initialized
DEBUG - 2011-08-22 16:46:23 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-22 16:46:23 --> Language Class Initialized
DEBUG - 2011-08-22 16:46:23 --> Config Class Initialized
DEBUG - 2011-08-22 16:46:23 --> Hooks Class Initialized
DEBUG - 2011-08-22 16:46:23 --> Utf8 Class Initialized
DEBUG - 2011-08-22 16:46:23 --> UTF-8 Support Enabled
DEBUG - 2011-08-22 16:46:23 --> URI Class Initialized
DEBUG - 2011-08-22 16:46:23 --> Loader Class Initialized
DEBUG - 2011-08-22 16:46:23 --> Controller Class Initialized
DEBUG - 2011-08-22 16:46:23 --> Router Class Initialized
DEBUG - 2011-08-22 16:46:23 --> Model Class Initialized
DEBUG - 2011-08-22 16:46:23 --> Model Class Initialized
DEBUG - 2011-08-22 16:46:23 --> Model Class Initialized
DEBUG - 2011-08-22 16:46:23 --> Output Class Initialized
DEBUG - 2011-08-22 16:46:23 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-22 16:46:23 --> Input Class Initialized
DEBUG - 2011-08-22 16:46:23 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-22 16:46:23 --> Language Class Initialized
DEBUG - 2011-08-22 16:46:23 --> Loader Class Initialized
DEBUG - 2011-08-22 16:46:23 --> Controller Class Initialized
ERROR - 2011-08-22 16:46:23 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-08-22 16:46:23 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-08-22 16:46:23 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-08-22 16:46:23 --> Model Class Initialized
DEBUG - 2011-08-22 16:46:23 --> Model Class Initialized
DEBUG - 2011-08-22 16:46:23 --> Database Driver Class Initialized
DEBUG - 2011-08-22 16:46:23 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-22 16:46:23 --> Database Driver Class Initialized
DEBUG - 2011-08-22 16:46:23 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-08-22 16:46:23 --> Helper loaded: url_helper
DEBUG - 2011-08-22 16:46:23 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-22 16:46:23 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-22 16:46:23 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-22 16:46:23 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-22 16:46:23 --> Final output sent to browser
DEBUG - 2011-08-22 16:46:23 --> Total execution time: 0.0306
DEBUG - 2011-08-22 16:46:23 --> File loaded: application/views/table/main.php
DEBUG - 2011-08-22 16:46:23 --> Helper loaded: url_helper
DEBUG - 2011-08-22 16:46:23 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-22 16:46:23 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-22 16:46:23 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-22 16:46:23 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-22 16:46:23 --> Final output sent to browser
DEBUG - 2011-08-22 16:46:23 --> Total execution time: 0.1967
DEBUG - 2011-08-22 17:27:40 --> Config Class Initialized
DEBUG - 2011-08-22 17:27:40 --> Hooks Class Initialized
DEBUG - 2011-08-22 17:27:40 --> Utf8 Class Initialized
DEBUG - 2011-08-22 17:27:40 --> UTF-8 Support Enabled
DEBUG - 2011-08-22 17:27:40 --> URI Class Initialized
DEBUG - 2011-08-22 17:27:40 --> Router Class Initialized
DEBUG - 2011-08-22 17:27:40 --> Output Class Initialized
DEBUG - 2011-08-22 17:27:40 --> Input Class Initialized
DEBUG - 2011-08-22 17:27:40 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-22 17:27:40 --> Language Class Initialized
DEBUG - 2011-08-22 17:27:40 --> Loader Class Initialized
DEBUG - 2011-08-22 17:27:40 --> Controller Class Initialized
DEBUG - 2011-08-22 17:27:40 --> Model Class Initialized
DEBUG - 2011-08-22 17:27:40 --> Model Class Initialized
DEBUG - 2011-08-22 17:27:40 --> Model Class Initialized
DEBUG - 2011-08-22 17:27:40 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-22 17:27:40 --> Database Driver Class Initialized
DEBUG - 2011-08-22 17:27:41 --> File loaded: application/views/table/main.php
DEBUG - 2011-08-22 17:27:41 --> Helper loaded: url_helper
DEBUG - 2011-08-22 17:27:41 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-22 17:27:41 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-22 17:27:41 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-22 17:27:41 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-22 17:27:41 --> Final output sent to browser
DEBUG - 2011-08-22 17:27:41 --> Total execution time: 0.6202
DEBUG - 2011-08-22 17:27:43 --> Config Class Initialized
DEBUG - 2011-08-22 17:27:43 --> Hooks Class Initialized
DEBUG - 2011-08-22 17:27:43 --> Utf8 Class Initialized
DEBUG - 2011-08-22 17:27:43 --> UTF-8 Support Enabled
DEBUG - 2011-08-22 17:27:43 --> URI Class Initialized
DEBUG - 2011-08-22 17:27:43 --> Router Class Initialized
ERROR - 2011-08-22 17:27:43 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-08-22 17:27:44 --> Config Class Initialized
DEBUG - 2011-08-22 17:27:44 --> Hooks Class Initialized
DEBUG - 2011-08-22 17:27:44 --> Utf8 Class Initialized
DEBUG - 2011-08-22 17:27:44 --> UTF-8 Support Enabled
DEBUG - 2011-08-22 17:27:44 --> URI Class Initialized
DEBUG - 2011-08-22 17:27:44 --> Router Class Initialized
ERROR - 2011-08-22 17:27:44 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-08-22 17:28:11 --> Config Class Initialized
DEBUG - 2011-08-22 17:28:11 --> Hooks Class Initialized
DEBUG - 2011-08-22 17:28:11 --> Utf8 Class Initialized
DEBUG - 2011-08-22 17:28:11 --> UTF-8 Support Enabled
DEBUG - 2011-08-22 17:28:11 --> URI Class Initialized
DEBUG - 2011-08-22 17:28:11 --> Router Class Initialized
DEBUG - 2011-08-22 17:28:11 --> Output Class Initialized
DEBUG - 2011-08-22 17:28:11 --> Input Class Initialized
DEBUG - 2011-08-22 17:28:11 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-22 17:28:11 --> Language Class Initialized
DEBUG - 2011-08-22 17:28:11 --> Loader Class Initialized
DEBUG - 2011-08-22 17:28:11 --> Controller Class Initialized
DEBUG - 2011-08-22 17:28:11 --> Model Class Initialized
DEBUG - 2011-08-22 17:28:11 --> Model Class Initialized
DEBUG - 2011-08-22 17:28:11 --> Model Class Initialized
DEBUG - 2011-08-22 17:28:11 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-22 17:28:11 --> Database Driver Class Initialized
DEBUG - 2011-08-22 17:28:12 --> File loaded: application/views/table/main.php
DEBUG - 2011-08-22 17:28:12 --> Helper loaded: url_helper
DEBUG - 2011-08-22 17:28:12 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-22 17:28:12 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-22 17:28:12 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-22 17:28:12 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-22 17:28:12 --> Final output sent to browser
DEBUG - 2011-08-22 17:28:12 --> Total execution time: 0.4638
DEBUG - 2011-08-22 17:28:14 --> Config Class Initialized
DEBUG - 2011-08-22 17:28:14 --> Hooks Class Initialized
DEBUG - 2011-08-22 17:28:14 --> Utf8 Class Initialized
DEBUG - 2011-08-22 17:28:14 --> UTF-8 Support Enabled
DEBUG - 2011-08-22 17:28:14 --> URI Class Initialized
DEBUG - 2011-08-22 17:28:14 --> Router Class Initialized
DEBUG - 2011-08-22 17:28:14 --> Output Class Initialized
DEBUG - 2011-08-22 17:28:14 --> Input Class Initialized
DEBUG - 2011-08-22 17:28:14 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-22 17:28:14 --> Language Class Initialized
DEBUG - 2011-08-22 17:28:14 --> Loader Class Initialized
DEBUG - 2011-08-22 17:28:14 --> Controller Class Initialized
DEBUG - 2011-08-22 17:28:14 --> Model Class Initialized
DEBUG - 2011-08-22 17:28:14 --> Model Class Initialized
DEBUG - 2011-08-22 17:28:14 --> Model Class Initialized
DEBUG - 2011-08-22 17:28:14 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-22 17:28:14 --> Database Driver Class Initialized
DEBUG - 2011-08-22 17:28:14 --> File loaded: application/views/table/main.php
DEBUG - 2011-08-22 17:28:14 --> Helper loaded: url_helper
DEBUG - 2011-08-22 17:28:14 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-22 17:28:14 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-22 17:28:14 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-22 17:28:14 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-22 17:28:14 --> Final output sent to browser
DEBUG - 2011-08-22 17:28:14 --> Total execution time: 0.0823
DEBUG - 2011-08-22 17:28:25 --> Config Class Initialized
DEBUG - 2011-08-22 17:28:25 --> Hooks Class Initialized
DEBUG - 2011-08-22 17:28:25 --> Utf8 Class Initialized
DEBUG - 2011-08-22 17:28:25 --> UTF-8 Support Enabled
DEBUG - 2011-08-22 17:28:25 --> URI Class Initialized
DEBUG - 2011-08-22 17:28:25 --> Router Class Initialized
DEBUG - 2011-08-22 17:28:25 --> Output Class Initialized
DEBUG - 2011-08-22 17:28:25 --> Input Class Initialized
DEBUG - 2011-08-22 17:28:25 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-22 17:28:25 --> Language Class Initialized
DEBUG - 2011-08-22 17:28:25 --> Loader Class Initialized
DEBUG - 2011-08-22 17:28:25 --> Controller Class Initialized
DEBUG - 2011-08-22 17:28:25 --> Model Class Initialized
DEBUG - 2011-08-22 17:28:25 --> Model Class Initialized
DEBUG - 2011-08-22 17:28:25 --> Model Class Initialized
DEBUG - 2011-08-22 17:28:25 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-22 17:28:25 --> Database Driver Class Initialized
DEBUG - 2011-08-22 17:28:25 --> File loaded: application/views/table/main.php
DEBUG - 2011-08-22 17:28:25 --> Helper loaded: url_helper
DEBUG - 2011-08-22 17:28:25 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-22 17:28:25 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-22 17:28:25 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-22 17:28:25 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-22 17:28:25 --> Final output sent to browser
DEBUG - 2011-08-22 17:28:25 --> Total execution time: 0.2354
DEBUG - 2011-08-22 17:28:27 --> Config Class Initialized
DEBUG - 2011-08-22 17:28:27 --> Hooks Class Initialized
DEBUG - 2011-08-22 17:28:27 --> Utf8 Class Initialized
DEBUG - 2011-08-22 17:28:27 --> UTF-8 Support Enabled
DEBUG - 2011-08-22 17:28:27 --> URI Class Initialized
DEBUG - 2011-08-22 17:28:27 --> Router Class Initialized
DEBUG - 2011-08-22 17:28:27 --> Output Class Initialized
DEBUG - 2011-08-22 17:28:27 --> Input Class Initialized
DEBUG - 2011-08-22 17:28:27 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-22 17:28:27 --> Language Class Initialized
DEBUG - 2011-08-22 17:28:27 --> Loader Class Initialized
DEBUG - 2011-08-22 17:28:27 --> Controller Class Initialized
DEBUG - 2011-08-22 17:28:27 --> Model Class Initialized
DEBUG - 2011-08-22 17:28:27 --> Model Class Initialized
DEBUG - 2011-08-22 17:28:27 --> Model Class Initialized
DEBUG - 2011-08-22 17:28:27 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-22 17:28:27 --> Database Driver Class Initialized
DEBUG - 2011-08-22 17:28:27 --> File loaded: application/views/table/main.php
DEBUG - 2011-08-22 17:28:27 --> Helper loaded: url_helper
DEBUG - 2011-08-22 17:28:27 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-22 17:28:27 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-22 17:28:27 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-22 17:28:27 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-22 17:28:27 --> Final output sent to browser
DEBUG - 2011-08-22 17:28:27 --> Total execution time: 0.0717
DEBUG - 2011-08-22 17:28:42 --> Config Class Initialized
DEBUG - 2011-08-22 17:28:42 --> Hooks Class Initialized
DEBUG - 2011-08-22 17:28:42 --> Utf8 Class Initialized
DEBUG - 2011-08-22 17:28:42 --> UTF-8 Support Enabled
DEBUG - 2011-08-22 17:28:42 --> URI Class Initialized
DEBUG - 2011-08-22 17:28:42 --> Router Class Initialized
DEBUG - 2011-08-22 17:28:42 --> Output Class Initialized
DEBUG - 2011-08-22 17:28:42 --> Input Class Initialized
DEBUG - 2011-08-22 17:28:42 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-22 17:28:42 --> Language Class Initialized
DEBUG - 2011-08-22 17:28:42 --> Loader Class Initialized
DEBUG - 2011-08-22 17:28:42 --> Controller Class Initialized
DEBUG - 2011-08-22 17:28:42 --> Model Class Initialized
DEBUG - 2011-08-22 17:28:42 --> Model Class Initialized
DEBUG - 2011-08-22 17:28:42 --> Model Class Initialized
DEBUG - 2011-08-22 17:28:42 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-22 17:28:42 --> Database Driver Class Initialized
DEBUG - 2011-08-22 17:28:43 --> File loaded: application/views/table/main.php
DEBUG - 2011-08-22 17:28:43 --> Helper loaded: url_helper
DEBUG - 2011-08-22 17:28:43 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-22 17:28:43 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-22 17:28:43 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-22 17:28:43 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-22 17:28:43 --> Final output sent to browser
DEBUG - 2011-08-22 17:28:43 --> Total execution time: 0.2533
DEBUG - 2011-08-22 17:28:47 --> Config Class Initialized
DEBUG - 2011-08-22 17:28:47 --> Hooks Class Initialized
DEBUG - 2011-08-22 17:28:47 --> Utf8 Class Initialized
DEBUG - 2011-08-22 17:28:47 --> UTF-8 Support Enabled
DEBUG - 2011-08-22 17:28:47 --> URI Class Initialized
DEBUG - 2011-08-22 17:28:47 --> Router Class Initialized
DEBUG - 2011-08-22 17:28:47 --> Output Class Initialized
DEBUG - 2011-08-22 17:28:47 --> Input Class Initialized
DEBUG - 2011-08-22 17:28:47 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-22 17:28:47 --> Language Class Initialized
DEBUG - 2011-08-22 17:28:47 --> Loader Class Initialized
DEBUG - 2011-08-22 17:28:47 --> Controller Class Initialized
DEBUG - 2011-08-22 17:28:47 --> Model Class Initialized
DEBUG - 2011-08-22 17:28:47 --> Model Class Initialized
DEBUG - 2011-08-22 17:28:47 --> Model Class Initialized
DEBUG - 2011-08-22 17:28:47 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-22 17:28:47 --> Database Driver Class Initialized
DEBUG - 2011-08-22 17:28:47 --> File loaded: application/views/table/main.php
DEBUG - 2011-08-22 17:28:47 --> Helper loaded: url_helper
DEBUG - 2011-08-22 17:28:47 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-22 17:28:47 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-22 17:28:47 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-22 17:28:47 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-22 17:28:47 --> Final output sent to browser
DEBUG - 2011-08-22 17:28:47 --> Total execution time: 0.1279
DEBUG - 2011-08-22 17:28:47 --> Config Class Initialized
DEBUG - 2011-08-22 17:28:47 --> Hooks Class Initialized
DEBUG - 2011-08-22 17:28:47 --> Utf8 Class Initialized
DEBUG - 2011-08-22 17:28:47 --> UTF-8 Support Enabled
DEBUG - 2011-08-22 17:28:47 --> URI Class Initialized
DEBUG - 2011-08-22 17:28:47 --> Router Class Initialized
DEBUG - 2011-08-22 17:28:47 --> Output Class Initialized
DEBUG - 2011-08-22 17:28:47 --> Input Class Initialized
DEBUG - 2011-08-22 17:28:47 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-22 17:28:47 --> Language Class Initialized
DEBUG - 2011-08-22 17:28:47 --> Loader Class Initialized
DEBUG - 2011-08-22 17:28:47 --> Controller Class Initialized
DEBUG - 2011-08-22 17:28:47 --> Model Class Initialized
DEBUG - 2011-08-22 17:28:47 --> Model Class Initialized
DEBUG - 2011-08-22 17:28:47 --> Model Class Initialized
DEBUG - 2011-08-22 17:28:47 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-22 17:28:47 --> Database Driver Class Initialized
DEBUG - 2011-08-22 17:28:47 --> File loaded: application/views/table/main.php
DEBUG - 2011-08-22 17:28:47 --> Helper loaded: url_helper
DEBUG - 2011-08-22 17:28:47 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-22 17:28:47 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-22 17:28:47 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-22 17:28:47 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-22 17:28:47 --> Final output sent to browser
DEBUG - 2011-08-22 17:28:47 --> Total execution time: 0.1498
DEBUG - 2011-08-22 17:28:55 --> Config Class Initialized
DEBUG - 2011-08-22 17:28:55 --> Hooks Class Initialized
DEBUG - 2011-08-22 17:28:55 --> Utf8 Class Initialized
DEBUG - 2011-08-22 17:28:55 --> UTF-8 Support Enabled
DEBUG - 2011-08-22 17:28:55 --> URI Class Initialized
DEBUG - 2011-08-22 17:28:55 --> Router Class Initialized
DEBUG - 2011-08-22 17:28:55 --> Output Class Initialized
DEBUG - 2011-08-22 17:28:55 --> Input Class Initialized
DEBUG - 2011-08-22 17:28:55 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-22 17:28:55 --> Language Class Initialized
DEBUG - 2011-08-22 17:28:55 --> Loader Class Initialized
DEBUG - 2011-08-22 17:28:55 --> Controller Class Initialized
DEBUG - 2011-08-22 17:28:55 --> Model Class Initialized
DEBUG - 2011-08-22 17:28:55 --> Model Class Initialized
DEBUG - 2011-08-22 17:28:55 --> Model Class Initialized
DEBUG - 2011-08-22 17:28:55 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-22 17:28:55 --> Database Driver Class Initialized
DEBUG - 2011-08-22 17:28:56 --> File loaded: application/views/table/main.php
DEBUG - 2011-08-22 17:28:56 --> Helper loaded: url_helper
DEBUG - 2011-08-22 17:28:56 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-22 17:28:56 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-22 17:28:56 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-22 17:28:56 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-22 17:28:56 --> Final output sent to browser
DEBUG - 2011-08-22 17:28:56 --> Total execution time: 0.3115
DEBUG - 2011-08-22 17:29:02 --> Config Class Initialized
DEBUG - 2011-08-22 17:29:02 --> Hooks Class Initialized
DEBUG - 2011-08-22 17:29:02 --> Utf8 Class Initialized
DEBUG - 2011-08-22 17:29:02 --> UTF-8 Support Enabled
DEBUG - 2011-08-22 17:29:02 --> URI Class Initialized
DEBUG - 2011-08-22 17:29:02 --> Router Class Initialized
DEBUG - 2011-08-22 17:29:02 --> Output Class Initialized
DEBUG - 2011-08-22 17:29:02 --> Input Class Initialized
DEBUG - 2011-08-22 17:29:02 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-22 17:29:02 --> Language Class Initialized
DEBUG - 2011-08-22 17:29:02 --> Loader Class Initialized
DEBUG - 2011-08-22 17:29:02 --> Controller Class Initialized
DEBUG - 2011-08-22 17:29:02 --> Model Class Initialized
DEBUG - 2011-08-22 17:29:02 --> Model Class Initialized
DEBUG - 2011-08-22 17:29:02 --> Model Class Initialized
DEBUG - 2011-08-22 17:29:02 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-22 17:29:02 --> Database Driver Class Initialized
DEBUG - 2011-08-22 17:29:02 --> File loaded: application/views/table/main.php
DEBUG - 2011-08-22 17:29:02 --> Helper loaded: url_helper
DEBUG - 2011-08-22 17:29:02 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-22 17:29:02 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-22 17:29:02 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-22 17:29:02 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-22 17:29:02 --> Final output sent to browser
DEBUG - 2011-08-22 17:29:02 --> Total execution time: 0.1553
DEBUG - 2011-08-22 17:29:20 --> Config Class Initialized
DEBUG - 2011-08-22 17:29:20 --> Hooks Class Initialized
DEBUG - 2011-08-22 17:29:20 --> Utf8 Class Initialized
DEBUG - 2011-08-22 17:29:20 --> UTF-8 Support Enabled
DEBUG - 2011-08-22 17:29:20 --> URI Class Initialized
DEBUG - 2011-08-22 17:29:20 --> Router Class Initialized
DEBUG - 2011-08-22 17:29:20 --> Output Class Initialized
DEBUG - 2011-08-22 17:29:20 --> Input Class Initialized
DEBUG - 2011-08-22 17:29:20 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-22 17:29:20 --> Language Class Initialized
DEBUG - 2011-08-22 17:29:20 --> Loader Class Initialized
DEBUG - 2011-08-22 17:29:20 --> Controller Class Initialized
DEBUG - 2011-08-22 17:29:20 --> Model Class Initialized
DEBUG - 2011-08-22 17:29:20 --> Model Class Initialized
DEBUG - 2011-08-22 17:29:20 --> Model Class Initialized
DEBUG - 2011-08-22 17:29:20 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-22 17:29:20 --> Database Driver Class Initialized
DEBUG - 2011-08-22 17:29:20 --> File loaded: application/views/table/main.php
DEBUG - 2011-08-22 17:29:20 --> Helper loaded: url_helper
DEBUG - 2011-08-22 17:29:20 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-22 17:29:20 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-22 17:29:20 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-22 17:29:20 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-22 17:29:20 --> Final output sent to browser
DEBUG - 2011-08-22 17:29:20 --> Total execution time: 0.2531
DEBUG - 2011-08-22 17:29:21 --> Config Class Initialized
DEBUG - 2011-08-22 17:29:21 --> Hooks Class Initialized
DEBUG - 2011-08-22 17:29:21 --> Utf8 Class Initialized
DEBUG - 2011-08-22 17:29:21 --> UTF-8 Support Enabled
DEBUG - 2011-08-22 17:29:21 --> URI Class Initialized
DEBUG - 2011-08-22 17:29:21 --> Router Class Initialized
DEBUG - 2011-08-22 17:29:21 --> Output Class Initialized
DEBUG - 2011-08-22 17:29:21 --> Input Class Initialized
DEBUG - 2011-08-22 17:29:21 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-22 17:29:21 --> Language Class Initialized
DEBUG - 2011-08-22 17:29:21 --> Loader Class Initialized
DEBUG - 2011-08-22 17:29:21 --> Controller Class Initialized
DEBUG - 2011-08-22 17:29:21 --> Model Class Initialized
DEBUG - 2011-08-22 17:29:21 --> Model Class Initialized
DEBUG - 2011-08-22 17:29:21 --> Model Class Initialized
DEBUG - 2011-08-22 17:29:21 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-22 17:29:21 --> Database Driver Class Initialized
DEBUG - 2011-08-22 17:29:21 --> File loaded: application/views/table/main.php
DEBUG - 2011-08-22 17:29:21 --> Helper loaded: url_helper
DEBUG - 2011-08-22 17:29:21 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-22 17:29:21 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-22 17:29:21 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-22 17:29:21 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-22 17:29:21 --> Final output sent to browser
DEBUG - 2011-08-22 17:29:21 --> Total execution time: 0.0436
DEBUG - 2011-08-22 17:29:35 --> Config Class Initialized
DEBUG - 2011-08-22 17:29:35 --> Hooks Class Initialized
DEBUG - 2011-08-22 17:29:35 --> Utf8 Class Initialized
DEBUG - 2011-08-22 17:29:35 --> UTF-8 Support Enabled
DEBUG - 2011-08-22 17:29:35 --> URI Class Initialized
DEBUG - 2011-08-22 17:29:35 --> Router Class Initialized
DEBUG - 2011-08-22 17:29:35 --> Output Class Initialized
DEBUG - 2011-08-22 17:29:35 --> Input Class Initialized
DEBUG - 2011-08-22 17:29:35 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-22 17:29:35 --> Language Class Initialized
DEBUG - 2011-08-22 17:29:35 --> Loader Class Initialized
DEBUG - 2011-08-22 17:29:35 --> Controller Class Initialized
DEBUG - 2011-08-22 17:29:35 --> Model Class Initialized
DEBUG - 2011-08-22 17:29:35 --> Model Class Initialized
DEBUG - 2011-08-22 17:29:35 --> Model Class Initialized
DEBUG - 2011-08-22 17:29:35 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-22 17:29:35 --> Database Driver Class Initialized
DEBUG - 2011-08-22 17:29:35 --> File loaded: application/views/table/main.php
DEBUG - 2011-08-22 17:29:35 --> Helper loaded: url_helper
DEBUG - 2011-08-22 17:29:35 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-22 17:29:35 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-22 17:29:35 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-22 17:29:35 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-22 17:29:35 --> Final output sent to browser
DEBUG - 2011-08-22 17:29:35 --> Total execution time: 0.3141
DEBUG - 2011-08-22 17:29:36 --> Config Class Initialized
DEBUG - 2011-08-22 17:29:36 --> Hooks Class Initialized
DEBUG - 2011-08-22 17:29:36 --> Utf8 Class Initialized
DEBUG - 2011-08-22 17:29:36 --> UTF-8 Support Enabled
DEBUG - 2011-08-22 17:29:36 --> URI Class Initialized
DEBUG - 2011-08-22 17:29:36 --> Router Class Initialized
DEBUG - 2011-08-22 17:29:36 --> Output Class Initialized
DEBUG - 2011-08-22 17:29:36 --> Input Class Initialized
DEBUG - 2011-08-22 17:29:36 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-22 17:29:36 --> Language Class Initialized
DEBUG - 2011-08-22 17:29:36 --> Loader Class Initialized
DEBUG - 2011-08-22 17:29:36 --> Controller Class Initialized
DEBUG - 2011-08-22 17:29:36 --> Model Class Initialized
DEBUG - 2011-08-22 17:29:36 --> Model Class Initialized
DEBUG - 2011-08-22 17:29:36 --> Model Class Initialized
DEBUG - 2011-08-22 17:29:36 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-22 17:29:36 --> Database Driver Class Initialized
DEBUG - 2011-08-22 17:29:36 --> File loaded: application/views/table/main.php
DEBUG - 2011-08-22 17:29:36 --> Helper loaded: url_helper
DEBUG - 2011-08-22 17:29:36 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-22 17:29:36 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-22 17:29:36 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-22 17:29:36 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-22 17:29:36 --> Final output sent to browser
DEBUG - 2011-08-22 17:29:36 --> Total execution time: 0.0667
DEBUG - 2011-08-22 17:29:36 --> Config Class Initialized
DEBUG - 2011-08-22 17:29:36 --> Hooks Class Initialized
DEBUG - 2011-08-22 17:29:36 --> Utf8 Class Initialized
DEBUG - 2011-08-22 17:29:36 --> UTF-8 Support Enabled
DEBUG - 2011-08-22 17:29:36 --> URI Class Initialized
DEBUG - 2011-08-22 17:29:36 --> Router Class Initialized
DEBUG - 2011-08-22 17:29:36 --> Output Class Initialized
DEBUG - 2011-08-22 17:29:36 --> Input Class Initialized
DEBUG - 2011-08-22 17:29:36 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-22 17:29:36 --> Language Class Initialized
DEBUG - 2011-08-22 17:29:36 --> Loader Class Initialized
DEBUG - 2011-08-22 17:29:36 --> Controller Class Initialized
DEBUG - 2011-08-22 17:29:36 --> Model Class Initialized
DEBUG - 2011-08-22 17:29:36 --> Model Class Initialized
DEBUG - 2011-08-22 17:29:36 --> Model Class Initialized
DEBUG - 2011-08-22 17:29:36 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-22 17:29:36 --> Database Driver Class Initialized
DEBUG - 2011-08-22 17:29:36 --> File loaded: application/views/table/main.php
DEBUG - 2011-08-22 17:29:36 --> Helper loaded: url_helper
DEBUG - 2011-08-22 17:29:36 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-22 17:29:36 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-22 17:29:36 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-22 17:29:36 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-22 17:29:36 --> Final output sent to browser
DEBUG - 2011-08-22 17:29:36 --> Total execution time: 0.1223
DEBUG - 2011-08-22 17:29:38 --> Config Class Initialized
DEBUG - 2011-08-22 17:29:38 --> Hooks Class Initialized
DEBUG - 2011-08-22 17:29:38 --> Utf8 Class Initialized
DEBUG - 2011-08-22 17:29:38 --> UTF-8 Support Enabled
DEBUG - 2011-08-22 17:29:38 --> URI Class Initialized
DEBUG - 2011-08-22 17:29:38 --> Router Class Initialized
DEBUG - 2011-08-22 17:29:38 --> Output Class Initialized
DEBUG - 2011-08-22 17:29:38 --> Input Class Initialized
DEBUG - 2011-08-22 17:29:38 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-22 17:29:38 --> Language Class Initialized
DEBUG - 2011-08-22 17:29:38 --> Loader Class Initialized
DEBUG - 2011-08-22 17:29:38 --> Controller Class Initialized
DEBUG - 2011-08-22 17:29:38 --> Model Class Initialized
DEBUG - 2011-08-22 17:29:38 --> Model Class Initialized
DEBUG - 2011-08-22 17:29:38 --> Model Class Initialized
DEBUG - 2011-08-22 17:29:38 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-22 17:29:38 --> Database Driver Class Initialized
DEBUG - 2011-08-22 17:29:38 --> File loaded: application/views/table/main.php
DEBUG - 2011-08-22 17:29:38 --> Helper loaded: url_helper
DEBUG - 2011-08-22 17:29:38 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-22 17:29:38 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-22 17:29:38 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-22 17:29:38 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-22 17:29:38 --> Final output sent to browser
DEBUG - 2011-08-22 17:29:38 --> Total execution time: 0.0437
DEBUG - 2011-08-22 17:30:59 --> Config Class Initialized
DEBUG - 2011-08-22 17:30:59 --> Hooks Class Initialized
DEBUG - 2011-08-22 17:30:59 --> Utf8 Class Initialized
DEBUG - 2011-08-22 17:30:59 --> UTF-8 Support Enabled
DEBUG - 2011-08-22 17:30:59 --> URI Class Initialized
DEBUG - 2011-08-22 17:30:59 --> Router Class Initialized
DEBUG - 2011-08-22 17:30:59 --> Output Class Initialized
DEBUG - 2011-08-22 17:30:59 --> Input Class Initialized
DEBUG - 2011-08-22 17:30:59 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-22 17:30:59 --> Language Class Initialized
DEBUG - 2011-08-22 17:30:59 --> Loader Class Initialized
DEBUG - 2011-08-22 17:30:59 --> Controller Class Initialized
DEBUG - 2011-08-22 17:30:59 --> Model Class Initialized
DEBUG - 2011-08-22 17:30:59 --> Model Class Initialized
DEBUG - 2011-08-22 17:30:59 --> Model Class Initialized
DEBUG - 2011-08-22 17:30:59 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-22 17:30:59 --> Database Driver Class Initialized
DEBUG - 2011-08-22 17:30:59 --> File loaded: application/views/table/main.php
DEBUG - 2011-08-22 17:30:59 --> Helper loaded: url_helper
DEBUG - 2011-08-22 17:30:59 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-22 17:30:59 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-22 17:30:59 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-22 17:30:59 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-22 17:30:59 --> Final output sent to browser
DEBUG - 2011-08-22 17:30:59 --> Total execution time: 0.3135
DEBUG - 2011-08-22 17:31:02 --> Config Class Initialized
DEBUG - 2011-08-22 17:31:02 --> Hooks Class Initialized
DEBUG - 2011-08-22 17:31:02 --> Utf8 Class Initialized
DEBUG - 2011-08-22 17:31:02 --> UTF-8 Support Enabled
DEBUG - 2011-08-22 17:31:02 --> URI Class Initialized
DEBUG - 2011-08-22 17:31:02 --> Router Class Initialized
DEBUG - 2011-08-22 17:31:02 --> Output Class Initialized
DEBUG - 2011-08-22 17:31:02 --> Input Class Initialized
DEBUG - 2011-08-22 17:31:02 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-22 17:31:02 --> Language Class Initialized
DEBUG - 2011-08-22 17:31:02 --> Loader Class Initialized
DEBUG - 2011-08-22 17:31:02 --> Controller Class Initialized
DEBUG - 2011-08-22 17:31:02 --> Model Class Initialized
DEBUG - 2011-08-22 17:31:02 --> Model Class Initialized
DEBUG - 2011-08-22 17:31:02 --> Model Class Initialized
DEBUG - 2011-08-22 17:31:02 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-22 17:31:02 --> Database Driver Class Initialized
DEBUG - 2011-08-22 17:31:02 --> File loaded: application/views/table/main.php
DEBUG - 2011-08-22 17:31:02 --> Helper loaded: url_helper
DEBUG - 2011-08-22 17:31:02 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-22 17:31:02 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-22 17:31:02 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-22 17:31:02 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-22 17:31:02 --> Final output sent to browser
DEBUG - 2011-08-22 17:31:02 --> Total execution time: 0.0433
DEBUG - 2011-08-22 17:45:20 --> Config Class Initialized
DEBUG - 2011-08-22 17:45:20 --> Hooks Class Initialized
DEBUG - 2011-08-22 17:45:20 --> Utf8 Class Initialized
DEBUG - 2011-08-22 17:45:20 --> UTF-8 Support Enabled
DEBUG - 2011-08-22 17:45:20 --> URI Class Initialized
DEBUG - 2011-08-22 17:45:20 --> Router Class Initialized
DEBUG - 2011-08-22 17:45:20 --> Output Class Initialized
DEBUG - 2011-08-22 17:45:20 --> Input Class Initialized
DEBUG - 2011-08-22 17:45:20 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-22 17:45:20 --> Language Class Initialized
DEBUG - 2011-08-22 17:45:20 --> Loader Class Initialized
DEBUG - 2011-08-22 17:45:20 --> Controller Class Initialized
DEBUG - 2011-08-22 17:45:20 --> Model Class Initialized
DEBUG - 2011-08-22 17:45:20 --> Model Class Initialized
DEBUG - 2011-08-22 17:45:20 --> Model Class Initialized
DEBUG - 2011-08-22 17:45:20 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-22 17:45:20 --> Database Driver Class Initialized
DEBUG - 2011-08-22 17:45:20 --> File loaded: application/views/table/main.php
DEBUG - 2011-08-22 17:45:20 --> Helper loaded: url_helper
DEBUG - 2011-08-22 17:45:20 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-22 17:45:20 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-22 17:45:20 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-22 17:45:20 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-22 17:45:20 --> Final output sent to browser
DEBUG - 2011-08-22 17:45:20 --> Total execution time: 0.1775
DEBUG - 2011-08-22 17:45:22 --> Config Class Initialized
DEBUG - 2011-08-22 17:45:22 --> Hooks Class Initialized
DEBUG - 2011-08-22 17:45:22 --> Utf8 Class Initialized
DEBUG - 2011-08-22 17:45:22 --> UTF-8 Support Enabled
DEBUG - 2011-08-22 17:45:22 --> URI Class Initialized
DEBUG - 2011-08-22 17:45:22 --> Router Class Initialized
ERROR - 2011-08-22 17:45:22 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-08-22 17:45:49 --> Config Class Initialized
DEBUG - 2011-08-22 17:45:49 --> Hooks Class Initialized
DEBUG - 2011-08-22 17:45:49 --> Utf8 Class Initialized
DEBUG - 2011-08-22 17:45:49 --> UTF-8 Support Enabled
DEBUG - 2011-08-22 17:45:49 --> URI Class Initialized
DEBUG - 2011-08-22 17:45:49 --> Router Class Initialized
DEBUG - 2011-08-22 17:45:49 --> Output Class Initialized
DEBUG - 2011-08-22 17:45:49 --> Input Class Initialized
DEBUG - 2011-08-22 17:45:49 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-22 17:45:49 --> Language Class Initialized
DEBUG - 2011-08-22 17:45:49 --> Loader Class Initialized
DEBUG - 2011-08-22 17:45:49 --> Controller Class Initialized
DEBUG - 2011-08-22 17:45:49 --> Model Class Initialized
DEBUG - 2011-08-22 17:45:49 --> Model Class Initialized
DEBUG - 2011-08-22 17:45:49 --> Model Class Initialized
DEBUG - 2011-08-22 17:45:49 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-22 17:45:49 --> Database Driver Class Initialized
DEBUG - 2011-08-22 17:45:50 --> File loaded: application/views/table/main.php
DEBUG - 2011-08-22 17:45:50 --> Helper loaded: url_helper
DEBUG - 2011-08-22 17:45:50 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-22 17:45:50 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-22 17:45:50 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-22 17:45:50 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-22 17:45:50 --> Final output sent to browser
DEBUG - 2011-08-22 17:45:50 --> Total execution time: 1.3140
DEBUG - 2011-08-22 17:46:02 --> Config Class Initialized
DEBUG - 2011-08-22 17:46:02 --> Hooks Class Initialized
DEBUG - 2011-08-22 17:46:02 --> Utf8 Class Initialized
DEBUG - 2011-08-22 17:46:02 --> UTF-8 Support Enabled
DEBUG - 2011-08-22 17:46:02 --> URI Class Initialized
DEBUG - 2011-08-22 17:46:02 --> Router Class Initialized
DEBUG - 2011-08-22 17:46:02 --> Output Class Initialized
DEBUG - 2011-08-22 17:46:02 --> Input Class Initialized
DEBUG - 2011-08-22 17:46:02 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-22 17:46:02 --> Language Class Initialized
DEBUG - 2011-08-22 17:46:02 --> Loader Class Initialized
DEBUG - 2011-08-22 17:46:02 --> Controller Class Initialized
DEBUG - 2011-08-22 17:46:02 --> Model Class Initialized
DEBUG - 2011-08-22 17:46:02 --> Model Class Initialized
DEBUG - 2011-08-22 17:46:02 --> Model Class Initialized
DEBUG - 2011-08-22 17:46:02 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-22 17:46:02 --> Database Driver Class Initialized
DEBUG - 2011-08-22 17:46:02 --> File loaded: application/views/table/main.php
DEBUG - 2011-08-22 17:46:02 --> Helper loaded: url_helper
DEBUG - 2011-08-22 17:46:02 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-22 17:46:02 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-22 17:46:02 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-22 17:46:02 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-22 17:46:02 --> Final output sent to browser
DEBUG - 2011-08-22 17:46:02 --> Total execution time: 0.4284
DEBUG - 2011-08-22 17:46:18 --> Config Class Initialized
DEBUG - 2011-08-22 17:46:18 --> Hooks Class Initialized
DEBUG - 2011-08-22 17:46:18 --> Utf8 Class Initialized
DEBUG - 2011-08-22 17:46:18 --> UTF-8 Support Enabled
DEBUG - 2011-08-22 17:46:18 --> URI Class Initialized
DEBUG - 2011-08-22 17:46:18 --> Router Class Initialized
DEBUG - 2011-08-22 17:46:18 --> Output Class Initialized
DEBUG - 2011-08-22 17:46:18 --> Input Class Initialized
DEBUG - 2011-08-22 17:46:18 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-22 17:46:18 --> Language Class Initialized
DEBUG - 2011-08-22 17:46:18 --> Loader Class Initialized
DEBUG - 2011-08-22 17:46:18 --> Controller Class Initialized
DEBUG - 2011-08-22 17:46:18 --> Model Class Initialized
DEBUG - 2011-08-22 17:46:18 --> Model Class Initialized
DEBUG - 2011-08-22 17:46:18 --> Model Class Initialized
DEBUG - 2011-08-22 17:46:18 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-22 17:46:18 --> Database Driver Class Initialized
DEBUG - 2011-08-22 17:46:18 --> File loaded: application/views/table/main.php
DEBUG - 2011-08-22 17:46:18 --> Helper loaded: url_helper
DEBUG - 2011-08-22 17:46:18 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-22 17:46:18 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-22 17:46:18 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-22 17:46:18 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-22 17:46:18 --> Final output sent to browser
DEBUG - 2011-08-22 17:46:18 --> Total execution time: 0.2667
DEBUG - 2011-08-22 17:46:27 --> Config Class Initialized
DEBUG - 2011-08-22 17:46:27 --> Hooks Class Initialized
DEBUG - 2011-08-22 17:46:27 --> Utf8 Class Initialized
DEBUG - 2011-08-22 17:46:27 --> UTF-8 Support Enabled
DEBUG - 2011-08-22 17:46:27 --> URI Class Initialized
DEBUG - 2011-08-22 17:46:27 --> Router Class Initialized
DEBUG - 2011-08-22 17:46:27 --> Output Class Initialized
DEBUG - 2011-08-22 17:46:27 --> Input Class Initialized
DEBUG - 2011-08-22 17:46:27 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-22 17:46:27 --> Language Class Initialized
DEBUG - 2011-08-22 17:46:27 --> Loader Class Initialized
DEBUG - 2011-08-22 17:46:27 --> Controller Class Initialized
DEBUG - 2011-08-22 17:46:27 --> Model Class Initialized
DEBUG - 2011-08-22 17:46:27 --> Model Class Initialized
DEBUG - 2011-08-22 17:46:27 --> Model Class Initialized
DEBUG - 2011-08-22 17:46:27 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-22 17:46:27 --> Database Driver Class Initialized
DEBUG - 2011-08-22 17:46:28 --> File loaded: application/views/table/main.php
DEBUG - 2011-08-22 17:46:28 --> Helper loaded: url_helper
DEBUG - 2011-08-22 17:46:28 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-22 17:46:28 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-22 17:46:28 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-22 17:46:28 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-22 17:46:28 --> Final output sent to browser
DEBUG - 2011-08-22 17:46:28 --> Total execution time: 0.2522
DEBUG - 2011-08-22 17:46:37 --> Config Class Initialized
DEBUG - 2011-08-22 17:46:37 --> Hooks Class Initialized
DEBUG - 2011-08-22 17:46:37 --> Utf8 Class Initialized
DEBUG - 2011-08-22 17:46:37 --> UTF-8 Support Enabled
DEBUG - 2011-08-22 17:46:37 --> URI Class Initialized
DEBUG - 2011-08-22 17:46:37 --> Router Class Initialized
DEBUG - 2011-08-22 17:46:37 --> Output Class Initialized
DEBUG - 2011-08-22 17:46:37 --> Input Class Initialized
DEBUG - 2011-08-22 17:46:37 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-22 17:46:37 --> Language Class Initialized
DEBUG - 2011-08-22 17:46:37 --> Loader Class Initialized
DEBUG - 2011-08-22 17:46:37 --> Controller Class Initialized
DEBUG - 2011-08-22 17:46:37 --> Model Class Initialized
DEBUG - 2011-08-22 17:46:37 --> Model Class Initialized
DEBUG - 2011-08-22 17:46:37 --> Model Class Initialized
DEBUG - 2011-08-22 17:46:37 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-22 17:46:37 --> Database Driver Class Initialized
DEBUG - 2011-08-22 17:46:37 --> File loaded: application/views/table/main.php
DEBUG - 2011-08-22 17:46:37 --> Helper loaded: url_helper
DEBUG - 2011-08-22 17:46:37 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-22 17:46:37 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-22 17:46:37 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-22 17:46:37 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-22 17:46:37 --> Final output sent to browser
DEBUG - 2011-08-22 17:46:37 --> Total execution time: 0.2722
DEBUG - 2011-08-22 17:46:45 --> Config Class Initialized
DEBUG - 2011-08-22 17:46:45 --> Hooks Class Initialized
DEBUG - 2011-08-22 17:46:45 --> Utf8 Class Initialized
DEBUG - 2011-08-22 17:46:45 --> UTF-8 Support Enabled
DEBUG - 2011-08-22 17:46:45 --> URI Class Initialized
DEBUG - 2011-08-22 17:46:45 --> Router Class Initialized
DEBUG - 2011-08-22 17:46:45 --> Output Class Initialized
DEBUG - 2011-08-22 17:46:45 --> Input Class Initialized
DEBUG - 2011-08-22 17:46:45 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-22 17:46:45 --> Language Class Initialized
DEBUG - 2011-08-22 17:46:45 --> Loader Class Initialized
DEBUG - 2011-08-22 17:46:45 --> Controller Class Initialized
DEBUG - 2011-08-22 17:46:45 --> Model Class Initialized
DEBUG - 2011-08-22 17:46:45 --> Model Class Initialized
DEBUG - 2011-08-22 17:46:45 --> Model Class Initialized
DEBUG - 2011-08-22 17:46:45 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-22 17:46:45 --> Database Driver Class Initialized
DEBUG - 2011-08-22 17:46:45 --> File loaded: application/views/table/main.php
DEBUG - 2011-08-22 17:46:45 --> Helper loaded: url_helper
DEBUG - 2011-08-22 17:46:45 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-22 17:46:45 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-22 17:46:45 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-22 17:46:45 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-22 17:46:45 --> Final output sent to browser
DEBUG - 2011-08-22 17:46:45 --> Total execution time: 0.2659
DEBUG - 2011-08-22 17:46:55 --> Config Class Initialized
DEBUG - 2011-08-22 17:46:55 --> Hooks Class Initialized
DEBUG - 2011-08-22 17:46:55 --> Utf8 Class Initialized
DEBUG - 2011-08-22 17:46:55 --> UTF-8 Support Enabled
DEBUG - 2011-08-22 17:46:55 --> URI Class Initialized
DEBUG - 2011-08-22 17:46:55 --> Router Class Initialized
DEBUG - 2011-08-22 17:46:55 --> Output Class Initialized
DEBUG - 2011-08-22 17:46:55 --> Input Class Initialized
DEBUG - 2011-08-22 17:46:55 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-22 17:46:55 --> Language Class Initialized
DEBUG - 2011-08-22 17:46:55 --> Loader Class Initialized
DEBUG - 2011-08-22 17:46:55 --> Controller Class Initialized
DEBUG - 2011-08-22 17:46:55 --> Model Class Initialized
DEBUG - 2011-08-22 17:46:55 --> Model Class Initialized
DEBUG - 2011-08-22 17:46:55 --> Model Class Initialized
DEBUG - 2011-08-22 17:46:55 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-22 17:46:55 --> Database Driver Class Initialized
DEBUG - 2011-08-22 17:46:55 --> File loaded: application/views/table/main.php
DEBUG - 2011-08-22 17:46:55 --> Helper loaded: url_helper
DEBUG - 2011-08-22 17:46:55 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-22 17:46:55 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-22 17:46:55 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-22 17:46:55 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-22 17:46:55 --> Final output sent to browser
DEBUG - 2011-08-22 17:46:55 --> Total execution time: 0.2203
DEBUG - 2011-08-22 17:47:10 --> Config Class Initialized
DEBUG - 2011-08-22 17:47:10 --> Hooks Class Initialized
DEBUG - 2011-08-22 17:47:10 --> Utf8 Class Initialized
DEBUG - 2011-08-22 17:47:10 --> UTF-8 Support Enabled
DEBUG - 2011-08-22 17:47:10 --> URI Class Initialized
DEBUG - 2011-08-22 17:47:10 --> Router Class Initialized
DEBUG - 2011-08-22 17:47:10 --> Output Class Initialized
DEBUG - 2011-08-22 17:47:10 --> Input Class Initialized
DEBUG - 2011-08-22 17:47:10 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-22 17:47:10 --> Language Class Initialized
DEBUG - 2011-08-22 17:47:10 --> Loader Class Initialized
DEBUG - 2011-08-22 17:47:10 --> Controller Class Initialized
DEBUG - 2011-08-22 17:47:10 --> Model Class Initialized
DEBUG - 2011-08-22 17:47:10 --> Model Class Initialized
DEBUG - 2011-08-22 17:47:10 --> Model Class Initialized
DEBUG - 2011-08-22 17:47:10 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-22 17:47:10 --> Database Driver Class Initialized
DEBUG - 2011-08-22 17:47:10 --> File loaded: application/views/table/main.php
DEBUG - 2011-08-22 17:47:10 --> Helper loaded: url_helper
DEBUG - 2011-08-22 17:47:10 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-22 17:47:10 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-22 17:47:10 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-22 17:47:10 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-22 17:47:10 --> Final output sent to browser
DEBUG - 2011-08-22 17:47:10 --> Total execution time: 0.2584
DEBUG - 2011-08-22 17:47:34 --> Config Class Initialized
DEBUG - 2011-08-22 17:47:34 --> Hooks Class Initialized
DEBUG - 2011-08-22 17:47:34 --> Utf8 Class Initialized
DEBUG - 2011-08-22 17:47:34 --> UTF-8 Support Enabled
DEBUG - 2011-08-22 17:47:34 --> URI Class Initialized
DEBUG - 2011-08-22 17:47:34 --> Router Class Initialized
DEBUG - 2011-08-22 17:47:34 --> Output Class Initialized
DEBUG - 2011-08-22 17:47:34 --> Input Class Initialized
DEBUG - 2011-08-22 17:47:34 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-22 17:47:34 --> Language Class Initialized
DEBUG - 2011-08-22 17:47:34 --> Loader Class Initialized
DEBUG - 2011-08-22 17:47:34 --> Controller Class Initialized
DEBUG - 2011-08-22 17:47:34 --> Model Class Initialized
DEBUG - 2011-08-22 17:47:34 --> Model Class Initialized
DEBUG - 2011-08-22 17:47:34 --> Model Class Initialized
DEBUG - 2011-08-22 17:47:34 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-22 17:47:34 --> Database Driver Class Initialized
DEBUG - 2011-08-22 17:47:35 --> File loaded: application/views/table/main.php
DEBUG - 2011-08-22 17:47:35 --> Helper loaded: url_helper
DEBUG - 2011-08-22 17:47:35 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-22 17:47:35 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-22 17:47:35 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-22 17:47:35 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-22 17:47:35 --> Final output sent to browser
DEBUG - 2011-08-22 17:47:35 --> Total execution time: 0.5248
DEBUG - 2011-08-22 17:47:59 --> Config Class Initialized
DEBUG - 2011-08-22 17:47:59 --> Hooks Class Initialized
DEBUG - 2011-08-22 17:47:59 --> Utf8 Class Initialized
DEBUG - 2011-08-22 17:47:59 --> UTF-8 Support Enabled
DEBUG - 2011-08-22 17:47:59 --> URI Class Initialized
DEBUG - 2011-08-22 17:47:59 --> Router Class Initialized
DEBUG - 2011-08-22 17:47:59 --> Output Class Initialized
DEBUG - 2011-08-22 17:47:59 --> Input Class Initialized
DEBUG - 2011-08-22 17:47:59 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-22 17:47:59 --> Language Class Initialized
DEBUG - 2011-08-22 17:47:59 --> Loader Class Initialized
DEBUG - 2011-08-22 17:47:59 --> Controller Class Initialized
DEBUG - 2011-08-22 17:47:59 --> Model Class Initialized
DEBUG - 2011-08-22 17:47:59 --> Model Class Initialized
DEBUG - 2011-08-22 17:47:59 --> Model Class Initialized
DEBUG - 2011-08-22 17:47:59 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-22 17:47:59 --> Database Driver Class Initialized
DEBUG - 2011-08-22 17:47:59 --> File loaded: application/views/table/main.php
DEBUG - 2011-08-22 17:47:59 --> Helper loaded: url_helper
DEBUG - 2011-08-22 17:47:59 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-22 17:47:59 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-22 17:47:59 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-22 17:47:59 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-22 17:47:59 --> Final output sent to browser
DEBUG - 2011-08-22 17:47:59 --> Total execution time: 0.2138
DEBUG - 2011-08-22 17:48:19 --> Config Class Initialized
DEBUG - 2011-08-22 17:48:19 --> Hooks Class Initialized
DEBUG - 2011-08-22 17:48:19 --> Utf8 Class Initialized
DEBUG - 2011-08-22 17:48:19 --> UTF-8 Support Enabled
DEBUG - 2011-08-22 17:48:19 --> URI Class Initialized
DEBUG - 2011-08-22 17:48:19 --> Router Class Initialized
DEBUG - 2011-08-22 17:48:19 --> Output Class Initialized
DEBUG - 2011-08-22 17:48:19 --> Input Class Initialized
DEBUG - 2011-08-22 17:48:19 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-22 17:48:19 --> Language Class Initialized
DEBUG - 2011-08-22 17:48:19 --> Loader Class Initialized
DEBUG - 2011-08-22 17:48:19 --> Controller Class Initialized
DEBUG - 2011-08-22 17:48:19 --> Model Class Initialized
DEBUG - 2011-08-22 17:48:19 --> Model Class Initialized
DEBUG - 2011-08-22 17:48:19 --> Model Class Initialized
DEBUG - 2011-08-22 17:48:19 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-22 17:48:19 --> Database Driver Class Initialized
DEBUG - 2011-08-22 17:48:19 --> File loaded: application/views/table/main.php
DEBUG - 2011-08-22 17:48:19 --> Helper loaded: url_helper
DEBUG - 2011-08-22 17:48:19 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-22 17:48:19 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-22 17:48:19 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-22 17:48:19 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-22 17:48:19 --> Final output sent to browser
DEBUG - 2011-08-22 17:48:19 --> Total execution time: 0.2768
DEBUG - 2011-08-22 17:48:31 --> Config Class Initialized
DEBUG - 2011-08-22 17:48:31 --> Hooks Class Initialized
DEBUG - 2011-08-22 17:48:31 --> Utf8 Class Initialized
DEBUG - 2011-08-22 17:48:31 --> UTF-8 Support Enabled
DEBUG - 2011-08-22 17:48:31 --> URI Class Initialized
DEBUG - 2011-08-22 17:48:31 --> Router Class Initialized
DEBUG - 2011-08-22 17:48:31 --> Output Class Initialized
DEBUG - 2011-08-22 17:48:31 --> Input Class Initialized
DEBUG - 2011-08-22 17:48:31 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-22 17:48:31 --> Language Class Initialized
DEBUG - 2011-08-22 17:48:31 --> Loader Class Initialized
DEBUG - 2011-08-22 17:48:31 --> Controller Class Initialized
DEBUG - 2011-08-22 17:48:31 --> Model Class Initialized
DEBUG - 2011-08-22 17:48:31 --> Model Class Initialized
DEBUG - 2011-08-22 17:48:31 --> Model Class Initialized
DEBUG - 2011-08-22 17:48:31 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-22 17:48:31 --> Database Driver Class Initialized
DEBUG - 2011-08-22 17:48:32 --> File loaded: application/views/table/main.php
DEBUG - 2011-08-22 17:48:32 --> Helper loaded: url_helper
DEBUG - 2011-08-22 17:48:32 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-22 17:48:32 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-22 17:48:32 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-22 17:48:32 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-22 17:48:32 --> Final output sent to browser
DEBUG - 2011-08-22 17:48:32 --> Total execution time: 0.2677
DEBUG - 2011-08-22 17:49:00 --> Config Class Initialized
DEBUG - 2011-08-22 17:49:00 --> Hooks Class Initialized
DEBUG - 2011-08-22 17:49:00 --> Utf8 Class Initialized
DEBUG - 2011-08-22 17:49:00 --> UTF-8 Support Enabled
DEBUG - 2011-08-22 17:49:00 --> URI Class Initialized
DEBUG - 2011-08-22 17:49:00 --> Router Class Initialized
DEBUG - 2011-08-22 17:49:00 --> Output Class Initialized
DEBUG - 2011-08-22 17:49:00 --> Input Class Initialized
DEBUG - 2011-08-22 17:49:00 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-22 17:49:00 --> Language Class Initialized
DEBUG - 2011-08-22 17:49:00 --> Loader Class Initialized
DEBUG - 2011-08-22 17:49:00 --> Controller Class Initialized
DEBUG - 2011-08-22 17:49:00 --> Model Class Initialized
DEBUG - 2011-08-22 17:49:00 --> Model Class Initialized
DEBUG - 2011-08-22 17:49:00 --> Model Class Initialized
DEBUG - 2011-08-22 17:49:00 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-22 17:49:00 --> Database Driver Class Initialized
DEBUG - 2011-08-22 17:49:00 --> File loaded: application/views/table/main.php
DEBUG - 2011-08-22 17:49:00 --> Helper loaded: url_helper
DEBUG - 2011-08-22 17:49:00 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-22 17:49:00 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-22 17:49:00 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-22 17:49:00 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-22 17:49:00 --> Final output sent to browser
DEBUG - 2011-08-22 17:49:00 --> Total execution time: 0.1939
DEBUG - 2011-08-22 17:49:01 --> Config Class Initialized
DEBUG - 2011-08-22 17:49:01 --> Hooks Class Initialized
DEBUG - 2011-08-22 17:49:01 --> Utf8 Class Initialized
DEBUG - 2011-08-22 17:49:01 --> UTF-8 Support Enabled
DEBUG - 2011-08-22 17:49:01 --> URI Class Initialized
DEBUG - 2011-08-22 17:49:01 --> Router Class Initialized
DEBUG - 2011-08-22 17:49:01 --> Output Class Initialized
DEBUG - 2011-08-22 17:49:01 --> Input Class Initialized
DEBUG - 2011-08-22 17:49:01 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-22 17:49:01 --> Language Class Initialized
DEBUG - 2011-08-22 17:49:01 --> Loader Class Initialized
DEBUG - 2011-08-22 17:49:01 --> Controller Class Initialized
DEBUG - 2011-08-22 17:49:01 --> Model Class Initialized
DEBUG - 2011-08-22 17:49:01 --> Model Class Initialized
DEBUG - 2011-08-22 17:49:01 --> Model Class Initialized
DEBUG - 2011-08-22 17:49:01 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-22 17:49:01 --> Database Driver Class Initialized
DEBUG - 2011-08-22 17:49:01 --> File loaded: application/views/table/main.php
DEBUG - 2011-08-22 17:49:01 --> Helper loaded: url_helper
DEBUG - 2011-08-22 17:49:01 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-22 17:49:01 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-22 17:49:01 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-22 17:49:01 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-22 17:49:01 --> Final output sent to browser
DEBUG - 2011-08-22 17:49:01 --> Total execution time: 0.0477
DEBUG - 2011-08-22 17:59:03 --> Config Class Initialized
DEBUG - 2011-08-22 17:59:03 --> Hooks Class Initialized
DEBUG - 2011-08-22 17:59:03 --> Utf8 Class Initialized
DEBUG - 2011-08-22 17:59:03 --> UTF-8 Support Enabled
DEBUG - 2011-08-22 17:59:03 --> URI Class Initialized
DEBUG - 2011-08-22 17:59:03 --> Router Class Initialized
ERROR - 2011-08-22 17:59:03 --> 404 Page Not Found --> robots.txt
DEBUG - 2011-08-22 18:04:22 --> Config Class Initialized
DEBUG - 2011-08-22 18:04:22 --> Hooks Class Initialized
DEBUG - 2011-08-22 18:04:22 --> Utf8 Class Initialized
DEBUG - 2011-08-22 18:04:22 --> UTF-8 Support Enabled
DEBUG - 2011-08-22 18:04:22 --> URI Class Initialized
DEBUG - 2011-08-22 18:04:22 --> Router Class Initialized
DEBUG - 2011-08-22 18:04:22 --> No URI present. Default controller set.
DEBUG - 2011-08-22 18:04:22 --> Output Class Initialized
DEBUG - 2011-08-22 18:04:22 --> Input Class Initialized
DEBUG - 2011-08-22 18:04:22 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-22 18:04:22 --> Language Class Initialized
DEBUG - 2011-08-22 18:04:22 --> Loader Class Initialized
DEBUG - 2011-08-22 18:04:22 --> Controller Class Initialized
DEBUG - 2011-08-22 18:04:22 --> File loaded: application/views/splash/main.php
DEBUG - 2011-08-22 18:04:22 --> Helper loaded: url_helper
DEBUG - 2011-08-22 18:04:22 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-22 18:04:22 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-22 18:04:22 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-22 18:04:22 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-22 18:04:22 --> Final output sent to browser
DEBUG - 2011-08-22 18:04:22 --> Total execution time: 0.0955
DEBUG - 2011-08-22 18:09:48 --> Config Class Initialized
DEBUG - 2011-08-22 18:09:48 --> Hooks Class Initialized
DEBUG - 2011-08-22 18:09:48 --> Utf8 Class Initialized
DEBUG - 2011-08-22 18:09:48 --> UTF-8 Support Enabled
DEBUG - 2011-08-22 18:09:48 --> URI Class Initialized
DEBUG - 2011-08-22 18:09:48 --> Router Class Initialized
DEBUG - 2011-08-22 18:09:48 --> Output Class Initialized
DEBUG - 2011-08-22 18:09:48 --> Input Class Initialized
DEBUG - 2011-08-22 18:09:48 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-22 18:09:48 --> Language Class Initialized
DEBUG - 2011-08-22 18:09:48 --> Loader Class Initialized
DEBUG - 2011-08-22 18:09:48 --> Controller Class Initialized
ERROR - 2011-08-22 18:09:48 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-08-22 18:09:48 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-08-22 18:09:48 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-08-22 18:09:48 --> Model Class Initialized
DEBUG - 2011-08-22 18:09:48 --> Model Class Initialized
DEBUG - 2011-08-22 18:09:48 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-22 18:09:48 --> Database Driver Class Initialized
DEBUG - 2011-08-22 18:09:48 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-08-22 18:09:48 --> Helper loaded: url_helper
DEBUG - 2011-08-22 18:09:48 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-22 18:09:48 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-22 18:09:48 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-22 18:09:48 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-22 18:09:48 --> Final output sent to browser
DEBUG - 2011-08-22 18:09:48 --> Total execution time: 0.0321
DEBUG - 2011-08-22 18:09:49 --> Config Class Initialized
DEBUG - 2011-08-22 18:09:49 --> Hooks Class Initialized
DEBUG - 2011-08-22 18:09:49 --> Utf8 Class Initialized
DEBUG - 2011-08-22 18:09:49 --> UTF-8 Support Enabled
DEBUG - 2011-08-22 18:09:49 --> URI Class Initialized
DEBUG - 2011-08-22 18:09:49 --> Router Class Initialized
DEBUG - 2011-08-22 18:09:49 --> Output Class Initialized
DEBUG - 2011-08-22 18:09:49 --> Input Class Initialized
DEBUG - 2011-08-22 18:09:49 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-22 18:09:49 --> Language Class Initialized
DEBUG - 2011-08-22 18:09:49 --> Loader Class Initialized
DEBUG - 2011-08-22 18:09:49 --> Controller Class Initialized
DEBUG - 2011-08-22 18:09:49 --> Model Class Initialized
DEBUG - 2011-08-22 18:09:49 --> Model Class Initialized
DEBUG - 2011-08-22 18:09:49 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-22 18:09:49 --> Database Driver Class Initialized
DEBUG - 2011-08-22 18:09:50 --> Final output sent to browser
DEBUG - 2011-08-22 18:09:50 --> Total execution time: 0.5387
DEBUG - 2011-08-22 18:09:52 --> Config Class Initialized
DEBUG - 2011-08-22 18:09:52 --> Hooks Class Initialized
DEBUG - 2011-08-22 18:09:52 --> Utf8 Class Initialized
DEBUG - 2011-08-22 18:09:52 --> UTF-8 Support Enabled
DEBUG - 2011-08-22 18:09:52 --> URI Class Initialized
DEBUG - 2011-08-22 18:09:52 --> Router Class Initialized
ERROR - 2011-08-22 18:09:52 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-08-22 18:12:25 --> Config Class Initialized
DEBUG - 2011-08-22 18:12:25 --> Hooks Class Initialized
DEBUG - 2011-08-22 18:12:25 --> Utf8 Class Initialized
DEBUG - 2011-08-22 18:12:25 --> UTF-8 Support Enabled
DEBUG - 2011-08-22 18:12:25 --> URI Class Initialized
DEBUG - 2011-08-22 18:12:25 --> Router Class Initialized
DEBUG - 2011-08-22 18:12:25 --> No URI present. Default controller set.
DEBUG - 2011-08-22 18:12:25 --> Output Class Initialized
DEBUG - 2011-08-22 18:12:25 --> Input Class Initialized
DEBUG - 2011-08-22 18:12:25 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-22 18:12:25 --> Language Class Initialized
DEBUG - 2011-08-22 18:12:25 --> Loader Class Initialized
DEBUG - 2011-08-22 18:12:25 --> Controller Class Initialized
DEBUG - 2011-08-22 18:12:25 --> File loaded: application/views/splash/main.php
DEBUG - 2011-08-22 18:12:25 --> Helper loaded: url_helper
DEBUG - 2011-08-22 18:12:25 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-22 18:12:25 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-22 18:12:25 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-22 18:12:25 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-22 18:12:25 --> Final output sent to browser
DEBUG - 2011-08-22 18:12:25 --> Total execution time: 0.0143
DEBUG - 2011-08-22 18:16:15 --> Config Class Initialized
DEBUG - 2011-08-22 18:16:15 --> Hooks Class Initialized
DEBUG - 2011-08-22 18:16:15 --> Utf8 Class Initialized
DEBUG - 2011-08-22 18:16:15 --> UTF-8 Support Enabled
DEBUG - 2011-08-22 18:16:15 --> URI Class Initialized
DEBUG - 2011-08-22 18:16:15 --> Router Class Initialized
DEBUG - 2011-08-22 18:16:15 --> No URI present. Default controller set.
DEBUG - 2011-08-22 18:16:15 --> Output Class Initialized
DEBUG - 2011-08-22 18:16:15 --> Input Class Initialized
DEBUG - 2011-08-22 18:16:15 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-22 18:16:15 --> Language Class Initialized
DEBUG - 2011-08-22 18:16:15 --> Loader Class Initialized
DEBUG - 2011-08-22 18:16:15 --> Controller Class Initialized
DEBUG - 2011-08-22 18:16:15 --> File loaded: application/views/splash/main.php
DEBUG - 2011-08-22 18:16:15 --> Helper loaded: url_helper
DEBUG - 2011-08-22 18:16:15 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-22 18:16:15 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-22 18:16:15 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-22 18:16:15 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-22 18:16:15 --> Final output sent to browser
DEBUG - 2011-08-22 18:16:15 --> Total execution time: 0.0129
DEBUG - 2011-08-22 18:16:54 --> Config Class Initialized
DEBUG - 2011-08-22 18:16:54 --> Hooks Class Initialized
DEBUG - 2011-08-22 18:16:54 --> Utf8 Class Initialized
DEBUG - 2011-08-22 18:16:54 --> UTF-8 Support Enabled
DEBUG - 2011-08-22 18:16:54 --> URI Class Initialized
DEBUG - 2011-08-22 18:16:54 --> Router Class Initialized
DEBUG - 2011-08-22 18:16:54 --> Output Class Initialized
DEBUG - 2011-08-22 18:16:54 --> Input Class Initialized
DEBUG - 2011-08-22 18:16:54 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-22 18:16:54 --> Language Class Initialized
DEBUG - 2011-08-22 18:16:54 --> Loader Class Initialized
DEBUG - 2011-08-22 18:16:54 --> Controller Class Initialized
ERROR - 2011-08-22 18:16:54 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-08-22 18:16:54 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-08-22 18:16:54 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-08-22 18:16:54 --> Model Class Initialized
DEBUG - 2011-08-22 18:16:54 --> Model Class Initialized
DEBUG - 2011-08-22 18:16:54 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-22 18:16:54 --> Database Driver Class Initialized
DEBUG - 2011-08-22 18:16:54 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-08-22 18:16:54 --> Helper loaded: url_helper
DEBUG - 2011-08-22 18:16:54 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-22 18:16:54 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-22 18:16:54 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-22 18:16:54 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-22 18:16:54 --> Final output sent to browser
DEBUG - 2011-08-22 18:16:54 --> Total execution time: 0.0298
DEBUG - 2011-08-22 18:18:03 --> Config Class Initialized
DEBUG - 2011-08-22 18:18:03 --> Hooks Class Initialized
DEBUG - 2011-08-22 18:18:03 --> Utf8 Class Initialized
DEBUG - 2011-08-22 18:18:03 --> UTF-8 Support Enabled
DEBUG - 2011-08-22 18:18:03 --> URI Class Initialized
DEBUG - 2011-08-22 18:18:03 --> Router Class Initialized
DEBUG - 2011-08-22 18:18:03 --> Output Class Initialized
DEBUG - 2011-08-22 18:18:03 --> Input Class Initialized
DEBUG - 2011-08-22 18:18:03 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-22 18:18:03 --> Language Class Initialized
DEBUG - 2011-08-22 18:18:03 --> Loader Class Initialized
DEBUG - 2011-08-22 18:18:03 --> Controller Class Initialized
DEBUG - 2011-08-22 18:18:03 --> Model Class Initialized
DEBUG - 2011-08-22 18:18:03 --> Model Class Initialized
DEBUG - 2011-08-22 18:18:03 --> Model Class Initialized
DEBUG - 2011-08-22 18:18:03 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-22 18:18:03 --> Database Driver Class Initialized
DEBUG - 2011-08-22 18:18:03 --> File loaded: application/views/table/main.php
DEBUG - 2011-08-22 18:18:03 --> Helper loaded: url_helper
DEBUG - 2011-08-22 18:18:03 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-22 18:18:03 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-22 18:18:03 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-22 18:18:03 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-22 18:18:03 --> Final output sent to browser
DEBUG - 2011-08-22 18:18:03 --> Total execution time: 0.2321
DEBUG - 2011-08-22 18:18:10 --> Config Class Initialized
DEBUG - 2011-08-22 18:18:10 --> Hooks Class Initialized
DEBUG - 2011-08-22 18:18:10 --> Utf8 Class Initialized
DEBUG - 2011-08-22 18:18:10 --> UTF-8 Support Enabled
DEBUG - 2011-08-22 18:18:10 --> URI Class Initialized
DEBUG - 2011-08-22 18:18:10 --> Router Class Initialized
ERROR - 2011-08-22 18:18:10 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-08-22 18:18:10 --> Config Class Initialized
DEBUG - 2011-08-22 18:18:10 --> Hooks Class Initialized
DEBUG - 2011-08-22 18:18:10 --> Utf8 Class Initialized
DEBUG - 2011-08-22 18:18:10 --> UTF-8 Support Enabled
DEBUG - 2011-08-22 18:18:10 --> URI Class Initialized
DEBUG - 2011-08-22 18:18:10 --> Router Class Initialized
ERROR - 2011-08-22 18:18:10 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-08-22 18:18:11 --> Config Class Initialized
DEBUG - 2011-08-22 18:18:11 --> Hooks Class Initialized
DEBUG - 2011-08-22 18:18:11 --> Utf8 Class Initialized
DEBUG - 2011-08-22 18:18:11 --> UTF-8 Support Enabled
DEBUG - 2011-08-22 18:18:11 --> URI Class Initialized
DEBUG - 2011-08-22 18:18:11 --> Router Class Initialized
ERROR - 2011-08-22 18:18:11 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-08-22 18:18:15 --> Config Class Initialized
DEBUG - 2011-08-22 18:18:15 --> Hooks Class Initialized
DEBUG - 2011-08-22 18:18:15 --> Utf8 Class Initialized
DEBUG - 2011-08-22 18:18:15 --> UTF-8 Support Enabled
DEBUG - 2011-08-22 18:18:15 --> URI Class Initialized
DEBUG - 2011-08-22 18:18:15 --> Router Class Initialized
DEBUG - 2011-08-22 18:18:15 --> Output Class Initialized
DEBUG - 2011-08-22 18:18:15 --> Input Class Initialized
DEBUG - 2011-08-22 18:18:15 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-22 18:18:15 --> Language Class Initialized
DEBUG - 2011-08-22 18:18:15 --> Loader Class Initialized
DEBUG - 2011-08-22 18:18:15 --> Controller Class Initialized
ERROR - 2011-08-22 18:18:15 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-08-22 18:18:15 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-08-22 18:18:15 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-08-22 18:18:15 --> Model Class Initialized
DEBUG - 2011-08-22 18:18:15 --> Model Class Initialized
DEBUG - 2011-08-22 18:18:15 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-22 18:18:15 --> Database Driver Class Initialized
DEBUG - 2011-08-22 18:18:15 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-08-22 18:18:15 --> Helper loaded: url_helper
DEBUG - 2011-08-22 18:18:15 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-22 18:18:15 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-22 18:18:15 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-22 18:18:15 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-22 18:18:15 --> Final output sent to browser
DEBUG - 2011-08-22 18:18:15 --> Total execution time: 0.0281
DEBUG - 2011-08-22 18:18:16 --> Config Class Initialized
DEBUG - 2011-08-22 18:18:16 --> Hooks Class Initialized
DEBUG - 2011-08-22 18:18:16 --> Utf8 Class Initialized
DEBUG - 2011-08-22 18:18:16 --> UTF-8 Support Enabled
DEBUG - 2011-08-22 18:18:16 --> URI Class Initialized
DEBUG - 2011-08-22 18:18:16 --> Router Class Initialized
DEBUG - 2011-08-22 18:18:16 --> Output Class Initialized
DEBUG - 2011-08-22 18:18:16 --> Input Class Initialized
DEBUG - 2011-08-22 18:18:16 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-22 18:18:16 --> Language Class Initialized
DEBUG - 2011-08-22 18:18:16 --> Loader Class Initialized
DEBUG - 2011-08-22 18:18:16 --> Controller Class Initialized
DEBUG - 2011-08-22 18:18:16 --> Model Class Initialized
DEBUG - 2011-08-22 18:18:16 --> Model Class Initialized
DEBUG - 2011-08-22 18:18:16 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-22 18:18:16 --> Database Driver Class Initialized
DEBUG - 2011-08-22 18:18:17 --> Final output sent to browser
DEBUG - 2011-08-22 18:18:17 --> Total execution time: 0.6091
DEBUG - 2011-08-22 18:18:36 --> Config Class Initialized
DEBUG - 2011-08-22 18:18:36 --> Hooks Class Initialized
DEBUG - 2011-08-22 18:18:36 --> Utf8 Class Initialized
DEBUG - 2011-08-22 18:18:36 --> UTF-8 Support Enabled
DEBUG - 2011-08-22 18:18:36 --> URI Class Initialized
DEBUG - 2011-08-22 18:18:36 --> Router Class Initialized
DEBUG - 2011-08-22 18:18:36 --> Output Class Initialized
DEBUG - 2011-08-22 18:18:36 --> Input Class Initialized
DEBUG - 2011-08-22 18:18:36 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-22 18:18:36 --> Language Class Initialized
DEBUG - 2011-08-22 18:18:36 --> Loader Class Initialized
DEBUG - 2011-08-22 18:18:36 --> Controller Class Initialized
DEBUG - 2011-08-22 18:18:36 --> Model Class Initialized
DEBUG - 2011-08-22 18:18:36 --> Model Class Initialized
DEBUG - 2011-08-22 18:18:36 --> Model Class Initialized
DEBUG - 2011-08-22 18:18:36 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-22 18:18:36 --> Database Driver Class Initialized
DEBUG - 2011-08-22 18:18:36 --> File loaded: application/views/table/main.php
DEBUG - 2011-08-22 18:18:36 --> Helper loaded: url_helper
DEBUG - 2011-08-22 18:18:36 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-22 18:18:36 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-22 18:18:36 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-22 18:18:36 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-22 18:18:36 --> Final output sent to browser
DEBUG - 2011-08-22 18:18:36 --> Total execution time: 0.0896
DEBUG - 2011-08-22 18:19:33 --> Config Class Initialized
DEBUG - 2011-08-22 18:19:33 --> Hooks Class Initialized
DEBUG - 2011-08-22 18:19:33 --> Utf8 Class Initialized
DEBUG - 2011-08-22 18:19:33 --> UTF-8 Support Enabled
DEBUG - 2011-08-22 18:19:33 --> URI Class Initialized
DEBUG - 2011-08-22 18:19:33 --> Router Class Initialized
DEBUG - 2011-08-22 18:19:33 --> Output Class Initialized
DEBUG - 2011-08-22 18:19:33 --> Input Class Initialized
DEBUG - 2011-08-22 18:19:33 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-22 18:19:33 --> Language Class Initialized
DEBUG - 2011-08-22 18:19:33 --> Loader Class Initialized
DEBUG - 2011-08-22 18:19:33 --> Controller Class Initialized
DEBUG - 2011-08-22 18:19:33 --> Model Class Initialized
DEBUG - 2011-08-22 18:19:33 --> Model Class Initialized
DEBUG - 2011-08-22 18:19:33 --> Model Class Initialized
DEBUG - 2011-08-22 18:19:33 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-22 18:19:33 --> Database Driver Class Initialized
DEBUG - 2011-08-22 18:19:33 --> File loaded: application/views/table/main.php
DEBUG - 2011-08-22 18:19:33 --> Helper loaded: url_helper
DEBUG - 2011-08-22 18:19:33 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-22 18:19:33 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-22 18:19:33 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-22 18:19:33 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-22 18:19:33 --> Final output sent to browser
DEBUG - 2011-08-22 18:19:33 --> Total execution time: 0.3138
DEBUG - 2011-08-22 18:19:35 --> Config Class Initialized
DEBUG - 2011-08-22 18:19:35 --> Hooks Class Initialized
DEBUG - 2011-08-22 18:19:35 --> Utf8 Class Initialized
DEBUG - 2011-08-22 18:19:35 --> UTF-8 Support Enabled
DEBUG - 2011-08-22 18:19:35 --> URI Class Initialized
DEBUG - 2011-08-22 18:19:35 --> Router Class Initialized
DEBUG - 2011-08-22 18:19:35 --> Output Class Initialized
DEBUG - 2011-08-22 18:19:35 --> Input Class Initialized
DEBUG - 2011-08-22 18:19:35 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-22 18:19:35 --> Language Class Initialized
DEBUG - 2011-08-22 18:19:35 --> Loader Class Initialized
DEBUG - 2011-08-22 18:19:35 --> Controller Class Initialized
DEBUG - 2011-08-22 18:19:35 --> Model Class Initialized
DEBUG - 2011-08-22 18:19:35 --> Model Class Initialized
DEBUG - 2011-08-22 18:19:35 --> Model Class Initialized
DEBUG - 2011-08-22 18:19:35 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-22 18:19:35 --> Database Driver Class Initialized
DEBUG - 2011-08-22 18:19:35 --> File loaded: application/views/table/main.php
DEBUG - 2011-08-22 18:19:35 --> Helper loaded: url_helper
DEBUG - 2011-08-22 18:19:35 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-22 18:19:35 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-22 18:19:35 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-22 18:19:35 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-22 18:19:35 --> Final output sent to browser
DEBUG - 2011-08-22 18:19:35 --> Total execution time: 0.0655
DEBUG - 2011-08-22 18:19:45 --> Config Class Initialized
DEBUG - 2011-08-22 18:19:45 --> Hooks Class Initialized
DEBUG - 2011-08-22 18:19:45 --> Utf8 Class Initialized
DEBUG - 2011-08-22 18:19:45 --> UTF-8 Support Enabled
DEBUG - 2011-08-22 18:19:45 --> URI Class Initialized
DEBUG - 2011-08-22 18:19:45 --> Router Class Initialized
DEBUG - 2011-08-22 18:19:45 --> Output Class Initialized
DEBUG - 2011-08-22 18:19:45 --> Input Class Initialized
DEBUG - 2011-08-22 18:19:45 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-22 18:19:45 --> Language Class Initialized
DEBUG - 2011-08-22 18:19:45 --> Loader Class Initialized
DEBUG - 2011-08-22 18:19:45 --> Controller Class Initialized
DEBUG - 2011-08-22 18:19:45 --> Model Class Initialized
DEBUG - 2011-08-22 18:19:45 --> Model Class Initialized
DEBUG - 2011-08-22 18:19:45 --> Model Class Initialized
DEBUG - 2011-08-22 18:19:45 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-22 18:19:45 --> Database Driver Class Initialized
DEBUG - 2011-08-22 18:19:45 --> File loaded: application/views/table/main.php
DEBUG - 2011-08-22 18:19:45 --> Helper loaded: url_helper
DEBUG - 2011-08-22 18:19:45 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-22 18:19:45 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-22 18:19:45 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-22 18:19:45 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-22 18:19:45 --> Final output sent to browser
DEBUG - 2011-08-22 18:19:45 --> Total execution time: 0.2106
DEBUG - 2011-08-22 18:19:46 --> Config Class Initialized
DEBUG - 2011-08-22 18:19:46 --> Hooks Class Initialized
DEBUG - 2011-08-22 18:19:46 --> Utf8 Class Initialized
DEBUG - 2011-08-22 18:19:46 --> UTF-8 Support Enabled
DEBUG - 2011-08-22 18:19:46 --> URI Class Initialized
DEBUG - 2011-08-22 18:19:46 --> Router Class Initialized
DEBUG - 2011-08-22 18:19:46 --> Output Class Initialized
DEBUG - 2011-08-22 18:19:46 --> Input Class Initialized
DEBUG - 2011-08-22 18:19:46 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-22 18:19:46 --> Language Class Initialized
DEBUG - 2011-08-22 18:19:46 --> Loader Class Initialized
DEBUG - 2011-08-22 18:19:46 --> Controller Class Initialized
DEBUG - 2011-08-22 18:19:46 --> Model Class Initialized
DEBUG - 2011-08-22 18:19:46 --> Model Class Initialized
DEBUG - 2011-08-22 18:19:46 --> Model Class Initialized
DEBUG - 2011-08-22 18:19:46 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-22 18:19:46 --> Database Driver Class Initialized
DEBUG - 2011-08-22 18:19:46 --> File loaded: application/views/table/main.php
DEBUG - 2011-08-22 18:19:46 --> Helper loaded: url_helper
DEBUG - 2011-08-22 18:19:46 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-22 18:19:46 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-22 18:19:46 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-22 18:19:46 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-22 18:19:46 --> Final output sent to browser
DEBUG - 2011-08-22 18:19:46 --> Total execution time: 0.0431
DEBUG - 2011-08-22 18:19:46 --> Config Class Initialized
DEBUG - 2011-08-22 18:19:46 --> Hooks Class Initialized
DEBUG - 2011-08-22 18:19:46 --> Utf8 Class Initialized
DEBUG - 2011-08-22 18:19:46 --> UTF-8 Support Enabled
DEBUG - 2011-08-22 18:19:46 --> URI Class Initialized
DEBUG - 2011-08-22 18:19:46 --> Router Class Initialized
DEBUG - 2011-08-22 18:19:46 --> Output Class Initialized
DEBUG - 2011-08-22 18:19:46 --> Input Class Initialized
DEBUG - 2011-08-22 18:19:46 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-22 18:19:46 --> Language Class Initialized
DEBUG - 2011-08-22 18:19:46 --> Loader Class Initialized
DEBUG - 2011-08-22 18:19:46 --> Controller Class Initialized
DEBUG - 2011-08-22 18:19:46 --> Model Class Initialized
DEBUG - 2011-08-22 18:19:46 --> Model Class Initialized
DEBUG - 2011-08-22 18:19:46 --> Model Class Initialized
DEBUG - 2011-08-22 18:19:46 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-22 18:19:46 --> Database Driver Class Initialized
DEBUG - 2011-08-22 18:19:46 --> File loaded: application/views/table/main.php
DEBUG - 2011-08-22 18:19:46 --> Helper loaded: url_helper
DEBUG - 2011-08-22 18:19:46 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-22 18:19:46 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-22 18:19:46 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-22 18:19:46 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-22 18:19:46 --> Final output sent to browser
DEBUG - 2011-08-22 18:19:46 --> Total execution time: 0.0479
DEBUG - 2011-08-22 18:19:54 --> Config Class Initialized
DEBUG - 2011-08-22 18:19:54 --> Hooks Class Initialized
DEBUG - 2011-08-22 18:19:54 --> Utf8 Class Initialized
DEBUG - 2011-08-22 18:19:54 --> UTF-8 Support Enabled
DEBUG - 2011-08-22 18:19:54 --> URI Class Initialized
DEBUG - 2011-08-22 18:19:54 --> Router Class Initialized
DEBUG - 2011-08-22 18:19:54 --> Output Class Initialized
DEBUG - 2011-08-22 18:19:54 --> Input Class Initialized
DEBUG - 2011-08-22 18:19:54 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-22 18:19:54 --> Language Class Initialized
DEBUG - 2011-08-22 18:19:54 --> Loader Class Initialized
DEBUG - 2011-08-22 18:19:54 --> Controller Class Initialized
DEBUG - 2011-08-22 18:19:54 --> Model Class Initialized
DEBUG - 2011-08-22 18:19:54 --> Model Class Initialized
DEBUG - 2011-08-22 18:19:54 --> Model Class Initialized
DEBUG - 2011-08-22 18:19:54 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-22 18:19:54 --> Database Driver Class Initialized
DEBUG - 2011-08-22 18:19:55 --> File loaded: application/views/table/main.php
DEBUG - 2011-08-22 18:19:55 --> Helper loaded: url_helper
DEBUG - 2011-08-22 18:19:55 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-22 18:19:55 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-22 18:19:55 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-22 18:19:55 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-22 18:19:55 --> Final output sent to browser
DEBUG - 2011-08-22 18:19:55 --> Total execution time: 0.1863
DEBUG - 2011-08-22 18:19:55 --> Config Class Initialized
DEBUG - 2011-08-22 18:19:55 --> Hooks Class Initialized
DEBUG - 2011-08-22 18:19:55 --> Utf8 Class Initialized
DEBUG - 2011-08-22 18:19:55 --> UTF-8 Support Enabled
DEBUG - 2011-08-22 18:19:55 --> URI Class Initialized
DEBUG - 2011-08-22 18:19:55 --> Router Class Initialized
DEBUG - 2011-08-22 18:19:55 --> Output Class Initialized
DEBUG - 2011-08-22 18:19:55 --> Input Class Initialized
DEBUG - 2011-08-22 18:19:55 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-22 18:19:55 --> Language Class Initialized
DEBUG - 2011-08-22 18:19:55 --> Loader Class Initialized
DEBUG - 2011-08-22 18:19:55 --> Controller Class Initialized
DEBUG - 2011-08-22 18:19:55 --> Model Class Initialized
DEBUG - 2011-08-22 18:19:55 --> Model Class Initialized
DEBUG - 2011-08-22 18:19:55 --> Model Class Initialized
DEBUG - 2011-08-22 18:19:55 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-22 18:19:55 --> Database Driver Class Initialized
DEBUG - 2011-08-22 18:19:55 --> File loaded: application/views/table/main.php
DEBUG - 2011-08-22 18:19:55 --> Helper loaded: url_helper
DEBUG - 2011-08-22 18:19:55 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-22 18:19:55 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-22 18:19:55 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-22 18:19:55 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-22 18:19:55 --> Final output sent to browser
DEBUG - 2011-08-22 18:19:55 --> Total execution time: 0.0447
DEBUG - 2011-08-22 18:20:15 --> Config Class Initialized
DEBUG - 2011-08-22 18:20:15 --> Hooks Class Initialized
DEBUG - 2011-08-22 18:20:15 --> Utf8 Class Initialized
DEBUG - 2011-08-22 18:20:15 --> UTF-8 Support Enabled
DEBUG - 2011-08-22 18:20:15 --> URI Class Initialized
DEBUG - 2011-08-22 18:20:15 --> Router Class Initialized
DEBUG - 2011-08-22 18:20:15 --> Output Class Initialized
DEBUG - 2011-08-22 18:20:15 --> Input Class Initialized
DEBUG - 2011-08-22 18:20:15 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-22 18:20:15 --> Language Class Initialized
DEBUG - 2011-08-22 18:20:15 --> Loader Class Initialized
DEBUG - 2011-08-22 18:20:15 --> Controller Class Initialized
DEBUG - 2011-08-22 18:20:15 --> Model Class Initialized
DEBUG - 2011-08-22 18:20:15 --> Model Class Initialized
DEBUG - 2011-08-22 18:20:15 --> Model Class Initialized
DEBUG - 2011-08-22 18:20:15 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-22 18:20:15 --> Database Driver Class Initialized
DEBUG - 2011-08-22 18:20:15 --> File loaded: application/views/table/main.php
DEBUG - 2011-08-22 18:20:15 --> Helper loaded: url_helper
DEBUG - 2011-08-22 18:20:15 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-22 18:20:15 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-22 18:20:15 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-22 18:20:15 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-22 18:20:15 --> Final output sent to browser
DEBUG - 2011-08-22 18:20:15 --> Total execution time: 0.2423
DEBUG - 2011-08-22 18:20:17 --> Config Class Initialized
DEBUG - 2011-08-22 18:20:17 --> Hooks Class Initialized
DEBUG - 2011-08-22 18:20:17 --> Utf8 Class Initialized
DEBUG - 2011-08-22 18:20:17 --> UTF-8 Support Enabled
DEBUG - 2011-08-22 18:20:17 --> URI Class Initialized
DEBUG - 2011-08-22 18:20:17 --> Router Class Initialized
DEBUG - 2011-08-22 18:20:17 --> Output Class Initialized
DEBUG - 2011-08-22 18:20:17 --> Input Class Initialized
DEBUG - 2011-08-22 18:20:17 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-22 18:20:17 --> Language Class Initialized
DEBUG - 2011-08-22 18:20:17 --> Loader Class Initialized
DEBUG - 2011-08-22 18:20:17 --> Controller Class Initialized
DEBUG - 2011-08-22 18:20:17 --> Model Class Initialized
DEBUG - 2011-08-22 18:20:17 --> Model Class Initialized
DEBUG - 2011-08-22 18:20:17 --> Model Class Initialized
DEBUG - 2011-08-22 18:20:17 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-22 18:20:17 --> Database Driver Class Initialized
DEBUG - 2011-08-22 18:20:17 --> File loaded: application/views/table/main.php
DEBUG - 2011-08-22 18:20:17 --> Helper loaded: url_helper
DEBUG - 2011-08-22 18:20:17 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-22 18:20:17 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-22 18:20:17 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-22 18:20:17 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-22 18:20:17 --> Final output sent to browser
DEBUG - 2011-08-22 18:20:17 --> Total execution time: 0.0427
DEBUG - 2011-08-22 18:20:19 --> Config Class Initialized
DEBUG - 2011-08-22 18:20:19 --> Hooks Class Initialized
DEBUG - 2011-08-22 18:20:19 --> Utf8 Class Initialized
DEBUG - 2011-08-22 18:20:19 --> UTF-8 Support Enabled
DEBUG - 2011-08-22 18:20:19 --> URI Class Initialized
DEBUG - 2011-08-22 18:20:19 --> Router Class Initialized
DEBUG - 2011-08-22 18:20:19 --> Output Class Initialized
DEBUG - 2011-08-22 18:20:19 --> Input Class Initialized
DEBUG - 2011-08-22 18:20:19 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-22 18:20:19 --> Language Class Initialized
DEBUG - 2011-08-22 18:20:19 --> Loader Class Initialized
DEBUG - 2011-08-22 18:20:19 --> Controller Class Initialized
DEBUG - 2011-08-22 18:20:19 --> Model Class Initialized
DEBUG - 2011-08-22 18:20:19 --> Model Class Initialized
DEBUG - 2011-08-22 18:20:19 --> Model Class Initialized
DEBUG - 2011-08-22 18:20:19 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-22 18:20:19 --> Database Driver Class Initialized
DEBUG - 2011-08-22 18:20:19 --> File loaded: application/views/table/main.php
DEBUG - 2011-08-22 18:20:19 --> Helper loaded: url_helper
DEBUG - 2011-08-22 18:20:19 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-22 18:20:19 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-22 18:20:19 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-22 18:20:19 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-22 18:20:19 --> Final output sent to browser
DEBUG - 2011-08-22 18:20:19 --> Total execution time: 0.0432
DEBUG - 2011-08-22 18:32:35 --> Config Class Initialized
DEBUG - 2011-08-22 18:32:35 --> Hooks Class Initialized
DEBUG - 2011-08-22 18:32:35 --> Utf8 Class Initialized
DEBUG - 2011-08-22 18:32:35 --> UTF-8 Support Enabled
DEBUG - 2011-08-22 18:32:35 --> URI Class Initialized
DEBUG - 2011-08-22 18:32:35 --> Router Class Initialized
DEBUG - 2011-08-22 18:32:35 --> Output Class Initialized
DEBUG - 2011-08-22 18:32:35 --> Input Class Initialized
DEBUG - 2011-08-22 18:32:35 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-22 18:32:35 --> Language Class Initialized
DEBUG - 2011-08-22 18:32:35 --> Loader Class Initialized
DEBUG - 2011-08-22 18:32:35 --> Controller Class Initialized
DEBUG - 2011-08-22 18:32:35 --> Model Class Initialized
DEBUG - 2011-08-22 18:32:35 --> Model Class Initialized
DEBUG - 2011-08-22 18:32:35 --> Model Class Initialized
DEBUG - 2011-08-22 18:32:35 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-22 18:32:35 --> Database Driver Class Initialized
DEBUG - 2011-08-22 18:32:35 --> File loaded: application/views/table/main.php
DEBUG - 2011-08-22 18:32:35 --> Helper loaded: url_helper
DEBUG - 2011-08-22 18:32:35 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-22 18:32:35 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-22 18:32:35 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-22 18:32:35 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-22 18:32:35 --> Final output sent to browser
DEBUG - 2011-08-22 18:32:35 --> Total execution time: 0.0421
DEBUG - 2011-08-22 19:00:38 --> Config Class Initialized
DEBUG - 2011-08-22 19:00:38 --> Hooks Class Initialized
DEBUG - 2011-08-22 19:00:38 --> Utf8 Class Initialized
DEBUG - 2011-08-22 19:00:38 --> UTF-8 Support Enabled
DEBUG - 2011-08-22 19:00:38 --> URI Class Initialized
DEBUG - 2011-08-22 19:00:38 --> Router Class Initialized
DEBUG - 2011-08-22 19:00:38 --> Output Class Initialized
DEBUG - 2011-08-22 19:00:38 --> Input Class Initialized
DEBUG - 2011-08-22 19:00:38 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-22 19:00:38 --> Language Class Initialized
DEBUG - 2011-08-22 19:00:38 --> Loader Class Initialized
DEBUG - 2011-08-22 19:00:38 --> Controller Class Initialized
ERROR - 2011-08-22 19:00:38 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-08-22 19:00:38 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-08-22 19:00:38 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-08-22 19:00:38 --> Model Class Initialized
DEBUG - 2011-08-22 19:00:38 --> Model Class Initialized
DEBUG - 2011-08-22 19:00:38 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-22 19:00:38 --> Database Driver Class Initialized
DEBUG - 2011-08-22 19:00:38 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-08-22 19:00:38 --> Helper loaded: url_helper
DEBUG - 2011-08-22 19:00:38 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-22 19:00:38 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-22 19:00:38 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-22 19:00:38 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-22 19:00:38 --> Final output sent to browser
DEBUG - 2011-08-22 19:00:38 --> Total execution time: 0.0550
DEBUG - 2011-08-22 19:00:39 --> Config Class Initialized
DEBUG - 2011-08-22 19:00:39 --> Hooks Class Initialized
DEBUG - 2011-08-22 19:00:39 --> Utf8 Class Initialized
DEBUG - 2011-08-22 19:00:39 --> UTF-8 Support Enabled
DEBUG - 2011-08-22 19:00:39 --> URI Class Initialized
DEBUG - 2011-08-22 19:00:39 --> Router Class Initialized
DEBUG - 2011-08-22 19:00:39 --> Output Class Initialized
DEBUG - 2011-08-22 19:00:39 --> Input Class Initialized
DEBUG - 2011-08-22 19:00:39 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-22 19:00:39 --> Language Class Initialized
DEBUG - 2011-08-22 19:00:39 --> Loader Class Initialized
DEBUG - 2011-08-22 19:00:39 --> Controller Class Initialized
DEBUG - 2011-08-22 19:00:39 --> Model Class Initialized
DEBUG - 2011-08-22 19:00:39 --> Model Class Initialized
DEBUG - 2011-08-22 19:00:39 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-22 19:00:39 --> Database Driver Class Initialized
DEBUG - 2011-08-22 19:00:39 --> Final output sent to browser
DEBUG - 2011-08-22 19:00:39 --> Total execution time: 0.6674
DEBUG - 2011-08-22 19:00:40 --> Config Class Initialized
DEBUG - 2011-08-22 19:00:40 --> Hooks Class Initialized
DEBUG - 2011-08-22 19:00:40 --> Utf8 Class Initialized
DEBUG - 2011-08-22 19:00:40 --> UTF-8 Support Enabled
DEBUG - 2011-08-22 19:00:40 --> URI Class Initialized
DEBUG - 2011-08-22 19:00:40 --> Router Class Initialized
ERROR - 2011-08-22 19:00:40 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-08-22 19:00:40 --> Config Class Initialized
DEBUG - 2011-08-22 19:00:40 --> Hooks Class Initialized
DEBUG - 2011-08-22 19:00:40 --> Utf8 Class Initialized
DEBUG - 2011-08-22 19:00:40 --> UTF-8 Support Enabled
DEBUG - 2011-08-22 19:00:40 --> URI Class Initialized
DEBUG - 2011-08-22 19:00:40 --> Router Class Initialized
ERROR - 2011-08-22 19:00:40 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-08-22 19:01:18 --> Config Class Initialized
DEBUG - 2011-08-22 19:01:18 --> Hooks Class Initialized
DEBUG - 2011-08-22 19:01:18 --> Utf8 Class Initialized
DEBUG - 2011-08-22 19:01:18 --> UTF-8 Support Enabled
DEBUG - 2011-08-22 19:01:18 --> URI Class Initialized
DEBUG - 2011-08-22 19:01:18 --> Router Class Initialized
DEBUG - 2011-08-22 19:01:18 --> Output Class Initialized
DEBUG - 2011-08-22 19:01:18 --> Input Class Initialized
DEBUG - 2011-08-22 19:01:18 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-22 19:01:18 --> Language Class Initialized
DEBUG - 2011-08-22 19:01:18 --> Loader Class Initialized
DEBUG - 2011-08-22 19:01:18 --> Controller Class Initialized
ERROR - 2011-08-22 19:01:18 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-08-22 19:01:18 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-08-22 19:01:18 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-08-22 19:01:18 --> Model Class Initialized
DEBUG - 2011-08-22 19:01:18 --> Model Class Initialized
DEBUG - 2011-08-22 19:01:18 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-22 19:01:18 --> Database Driver Class Initialized
DEBUG - 2011-08-22 19:01:18 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-08-22 19:01:18 --> Helper loaded: url_helper
DEBUG - 2011-08-22 19:01:18 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-22 19:01:18 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-22 19:01:18 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-22 19:01:18 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-22 19:01:18 --> Final output sent to browser
DEBUG - 2011-08-22 19:01:18 --> Total execution time: 0.0686
DEBUG - 2011-08-22 19:01:19 --> Config Class Initialized
DEBUG - 2011-08-22 19:01:19 --> Hooks Class Initialized
DEBUG - 2011-08-22 19:01:19 --> Utf8 Class Initialized
DEBUG - 2011-08-22 19:01:19 --> UTF-8 Support Enabled
DEBUG - 2011-08-22 19:01:19 --> URI Class Initialized
DEBUG - 2011-08-22 19:01:19 --> Router Class Initialized
DEBUG - 2011-08-22 19:01:19 --> Output Class Initialized
DEBUG - 2011-08-22 19:01:19 --> Input Class Initialized
DEBUG - 2011-08-22 19:01:19 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-22 19:01:19 --> Language Class Initialized
DEBUG - 2011-08-22 19:01:19 --> Loader Class Initialized
DEBUG - 2011-08-22 19:01:19 --> Controller Class Initialized
DEBUG - 2011-08-22 19:01:19 --> Model Class Initialized
DEBUG - 2011-08-22 19:01:19 --> Model Class Initialized
DEBUG - 2011-08-22 19:01:19 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-22 19:01:19 --> Database Driver Class Initialized
DEBUG - 2011-08-22 19:01:19 --> Final output sent to browser
DEBUG - 2011-08-22 19:01:19 --> Total execution time: 0.5539
DEBUG - 2011-08-22 19:01:40 --> Config Class Initialized
DEBUG - 2011-08-22 19:01:40 --> Hooks Class Initialized
DEBUG - 2011-08-22 19:01:40 --> Utf8 Class Initialized
DEBUG - 2011-08-22 19:01:40 --> UTF-8 Support Enabled
DEBUG - 2011-08-22 19:01:40 --> URI Class Initialized
DEBUG - 2011-08-22 19:01:40 --> Router Class Initialized
DEBUG - 2011-08-22 19:01:40 --> Output Class Initialized
DEBUG - 2011-08-22 19:01:40 --> Input Class Initialized
DEBUG - 2011-08-22 19:01:40 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-22 19:01:40 --> Language Class Initialized
DEBUG - 2011-08-22 19:01:40 --> Loader Class Initialized
DEBUG - 2011-08-22 19:01:40 --> Controller Class Initialized
ERROR - 2011-08-22 19:01:40 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-08-22 19:01:40 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-08-22 19:01:40 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-08-22 19:01:40 --> Model Class Initialized
DEBUG - 2011-08-22 19:01:40 --> Model Class Initialized
DEBUG - 2011-08-22 19:01:40 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-22 19:01:40 --> Database Driver Class Initialized
DEBUG - 2011-08-22 19:01:40 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-08-22 19:01:40 --> Helper loaded: url_helper
DEBUG - 2011-08-22 19:01:40 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-22 19:01:40 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-22 19:01:40 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-22 19:01:40 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-22 19:01:40 --> Final output sent to browser
DEBUG - 2011-08-22 19:01:40 --> Total execution time: 0.0295
DEBUG - 2011-08-22 19:01:41 --> Config Class Initialized
DEBUG - 2011-08-22 19:01:41 --> Hooks Class Initialized
DEBUG - 2011-08-22 19:01:41 --> Utf8 Class Initialized
DEBUG - 2011-08-22 19:01:41 --> UTF-8 Support Enabled
DEBUG - 2011-08-22 19:01:41 --> URI Class Initialized
DEBUG - 2011-08-22 19:01:41 --> Router Class Initialized
DEBUG - 2011-08-22 19:01:41 --> Output Class Initialized
DEBUG - 2011-08-22 19:01:41 --> Input Class Initialized
DEBUG - 2011-08-22 19:01:41 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-22 19:01:41 --> Language Class Initialized
DEBUG - 2011-08-22 19:01:41 --> Loader Class Initialized
DEBUG - 2011-08-22 19:01:41 --> Controller Class Initialized
DEBUG - 2011-08-22 19:01:41 --> Model Class Initialized
DEBUG - 2011-08-22 19:01:41 --> Model Class Initialized
DEBUG - 2011-08-22 19:01:41 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-22 19:01:41 --> Database Driver Class Initialized
DEBUG - 2011-08-22 19:01:41 --> Final output sent to browser
DEBUG - 2011-08-22 19:01:41 --> Total execution time: 0.4804
DEBUG - 2011-08-22 19:01:45 --> Config Class Initialized
DEBUG - 2011-08-22 19:01:45 --> Hooks Class Initialized
DEBUG - 2011-08-22 19:01:45 --> Utf8 Class Initialized
DEBUG - 2011-08-22 19:01:45 --> UTF-8 Support Enabled
DEBUG - 2011-08-22 19:01:45 --> URI Class Initialized
DEBUG - 2011-08-22 19:01:45 --> Router Class Initialized
DEBUG - 2011-08-22 19:01:45 --> Output Class Initialized
DEBUG - 2011-08-22 19:01:45 --> Input Class Initialized
DEBUG - 2011-08-22 19:01:45 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-22 19:01:45 --> Language Class Initialized
DEBUG - 2011-08-22 19:01:45 --> Loader Class Initialized
DEBUG - 2011-08-22 19:01:45 --> Controller Class Initialized
ERROR - 2011-08-22 19:01:45 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-08-22 19:01:45 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-08-22 19:01:45 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-08-22 19:01:45 --> Model Class Initialized
DEBUG - 2011-08-22 19:01:45 --> Model Class Initialized
DEBUG - 2011-08-22 19:01:45 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-22 19:01:45 --> Database Driver Class Initialized
DEBUG - 2011-08-22 19:01:45 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-08-22 19:01:45 --> Helper loaded: url_helper
DEBUG - 2011-08-22 19:01:45 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-22 19:01:45 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-22 19:01:45 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-22 19:01:45 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-22 19:01:45 --> Final output sent to browser
DEBUG - 2011-08-22 19:01:45 --> Total execution time: 0.1085
DEBUG - 2011-08-22 19:01:45 --> Config Class Initialized
DEBUG - 2011-08-22 19:01:45 --> Hooks Class Initialized
DEBUG - 2011-08-22 19:01:45 --> Utf8 Class Initialized
DEBUG - 2011-08-22 19:01:45 --> UTF-8 Support Enabled
DEBUG - 2011-08-22 19:01:45 --> URI Class Initialized
DEBUG - 2011-08-22 19:01:45 --> Router Class Initialized
DEBUG - 2011-08-22 19:01:45 --> Output Class Initialized
DEBUG - 2011-08-22 19:01:45 --> Input Class Initialized
DEBUG - 2011-08-22 19:01:45 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-22 19:01:45 --> Language Class Initialized
DEBUG - 2011-08-22 19:01:45 --> Loader Class Initialized
DEBUG - 2011-08-22 19:01:45 --> Controller Class Initialized
DEBUG - 2011-08-22 19:01:45 --> Model Class Initialized
DEBUG - 2011-08-22 19:01:45 --> Model Class Initialized
DEBUG - 2011-08-22 19:01:45 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-22 19:01:45 --> Database Driver Class Initialized
DEBUG - 2011-08-22 19:01:46 --> Final output sent to browser
DEBUG - 2011-08-22 19:01:46 --> Total execution time: 0.4976
DEBUG - 2011-08-22 19:01:55 --> Config Class Initialized
DEBUG - 2011-08-22 19:01:55 --> Hooks Class Initialized
DEBUG - 2011-08-22 19:01:55 --> Utf8 Class Initialized
DEBUG - 2011-08-22 19:01:55 --> UTF-8 Support Enabled
DEBUG - 2011-08-22 19:01:55 --> URI Class Initialized
DEBUG - 2011-08-22 19:01:55 --> Router Class Initialized
DEBUG - 2011-08-22 19:01:55 --> Output Class Initialized
DEBUG - 2011-08-22 19:01:55 --> Input Class Initialized
DEBUG - 2011-08-22 19:01:55 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-22 19:01:55 --> Language Class Initialized
DEBUG - 2011-08-22 19:01:55 --> Loader Class Initialized
DEBUG - 2011-08-22 19:01:55 --> Controller Class Initialized
ERROR - 2011-08-22 19:01:55 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-08-22 19:01:55 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-08-22 19:01:55 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-08-22 19:01:55 --> Model Class Initialized
DEBUG - 2011-08-22 19:01:55 --> Model Class Initialized
DEBUG - 2011-08-22 19:01:55 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-22 19:01:55 --> Database Driver Class Initialized
DEBUG - 2011-08-22 19:01:55 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-08-22 19:01:55 --> Helper loaded: url_helper
DEBUG - 2011-08-22 19:01:55 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-22 19:01:55 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-22 19:01:55 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-22 19:01:55 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-22 19:01:55 --> Final output sent to browser
DEBUG - 2011-08-22 19:01:55 --> Total execution time: 0.0388
DEBUG - 2011-08-22 19:01:56 --> Config Class Initialized
DEBUG - 2011-08-22 19:01:56 --> Hooks Class Initialized
DEBUG - 2011-08-22 19:01:56 --> Utf8 Class Initialized
DEBUG - 2011-08-22 19:01:56 --> UTF-8 Support Enabled
DEBUG - 2011-08-22 19:01:56 --> URI Class Initialized
DEBUG - 2011-08-22 19:01:56 --> Router Class Initialized
DEBUG - 2011-08-22 19:01:56 --> Output Class Initialized
DEBUG - 2011-08-22 19:01:56 --> Input Class Initialized
DEBUG - 2011-08-22 19:01:56 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-22 19:01:56 --> Language Class Initialized
DEBUG - 2011-08-22 19:01:56 --> Loader Class Initialized
DEBUG - 2011-08-22 19:01:56 --> Controller Class Initialized
DEBUG - 2011-08-22 19:01:56 --> Model Class Initialized
DEBUG - 2011-08-22 19:01:56 --> Model Class Initialized
DEBUG - 2011-08-22 19:01:56 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-22 19:01:56 --> Database Driver Class Initialized
DEBUG - 2011-08-22 19:01:57 --> Final output sent to browser
DEBUG - 2011-08-22 19:01:57 --> Total execution time: 0.6687
DEBUG - 2011-08-22 19:21:51 --> Config Class Initialized
DEBUG - 2011-08-22 19:21:51 --> Hooks Class Initialized
DEBUG - 2011-08-22 19:21:51 --> Utf8 Class Initialized
DEBUG - 2011-08-22 19:21:51 --> UTF-8 Support Enabled
DEBUG - 2011-08-22 19:21:51 --> URI Class Initialized
DEBUG - 2011-08-22 19:21:51 --> Router Class Initialized
DEBUG - 2011-08-22 19:21:51 --> No URI present. Default controller set.
DEBUG - 2011-08-22 19:21:51 --> Output Class Initialized
DEBUG - 2011-08-22 19:21:51 --> Input Class Initialized
DEBUG - 2011-08-22 19:21:51 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-22 19:21:51 --> Language Class Initialized
DEBUG - 2011-08-22 19:21:51 --> Loader Class Initialized
DEBUG - 2011-08-22 19:21:51 --> Controller Class Initialized
DEBUG - 2011-08-22 19:21:51 --> File loaded: application/views/splash/main.php
DEBUG - 2011-08-22 19:21:51 --> Helper loaded: url_helper
DEBUG - 2011-08-22 19:21:51 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-22 19:21:51 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-22 19:21:51 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-22 19:21:51 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-22 19:21:51 --> Final output sent to browser
DEBUG - 2011-08-22 19:21:51 --> Total execution time: 0.0119
DEBUG - 2011-08-22 19:45:07 --> Config Class Initialized
DEBUG - 2011-08-22 19:45:07 --> Hooks Class Initialized
DEBUG - 2011-08-22 19:45:07 --> Utf8 Class Initialized
DEBUG - 2011-08-22 19:45:07 --> UTF-8 Support Enabled
DEBUG - 2011-08-22 19:45:07 --> URI Class Initialized
DEBUG - 2011-08-22 19:45:07 --> Router Class Initialized
ERROR - 2011-08-22 19:45:07 --> 404 Page Not Found --> robots.txt
DEBUG - 2011-08-22 19:46:45 --> Config Class Initialized
DEBUG - 2011-08-22 19:46:45 --> Hooks Class Initialized
DEBUG - 2011-08-22 19:46:45 --> Utf8 Class Initialized
DEBUG - 2011-08-22 19:46:45 --> UTF-8 Support Enabled
DEBUG - 2011-08-22 19:46:45 --> URI Class Initialized
DEBUG - 2011-08-22 19:46:45 --> Router Class Initialized
DEBUG - 2011-08-22 19:46:45 --> Output Class Initialized
DEBUG - 2011-08-22 19:46:45 --> Input Class Initialized
DEBUG - 2011-08-22 19:46:45 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-22 19:46:45 --> Language Class Initialized
DEBUG - 2011-08-22 19:46:45 --> Loader Class Initialized
DEBUG - 2011-08-22 19:46:45 --> Controller Class Initialized
DEBUG - 2011-08-22 19:46:45 --> Model Class Initialized
DEBUG - 2011-08-22 19:46:45 --> Model Class Initialized
DEBUG - 2011-08-22 19:46:45 --> Model Class Initialized
DEBUG - 2011-08-22 19:46:45 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-22 19:46:45 --> Database Driver Class Initialized
DEBUG - 2011-08-22 19:46:45 --> File loaded: application/views/table/main.php
DEBUG - 2011-08-22 19:46:45 --> Helper loaded: url_helper
DEBUG - 2011-08-22 19:46:45 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-22 19:46:45 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-22 19:46:45 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-22 19:46:45 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-22 19:46:45 --> Final output sent to browser
DEBUG - 2011-08-22 19:46:45 --> Total execution time: 0.2564
DEBUG - 2011-08-22 19:46:47 --> Config Class Initialized
DEBUG - 2011-08-22 19:46:47 --> Hooks Class Initialized
DEBUG - 2011-08-22 19:46:47 --> Utf8 Class Initialized
DEBUG - 2011-08-22 19:46:47 --> UTF-8 Support Enabled
DEBUG - 2011-08-22 19:46:47 --> URI Class Initialized
DEBUG - 2011-08-22 19:46:47 --> Router Class Initialized
ERROR - 2011-08-22 19:46:47 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-08-22 19:46:56 --> Config Class Initialized
DEBUG - 2011-08-22 19:46:56 --> Hooks Class Initialized
DEBUG - 2011-08-22 19:46:56 --> Utf8 Class Initialized
DEBUG - 2011-08-22 19:46:56 --> UTF-8 Support Enabled
DEBUG - 2011-08-22 19:46:56 --> URI Class Initialized
DEBUG - 2011-08-22 19:46:56 --> Router Class Initialized
DEBUG - 2011-08-22 19:46:56 --> Output Class Initialized
DEBUG - 2011-08-22 19:46:56 --> Input Class Initialized
DEBUG - 2011-08-22 19:46:56 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-22 19:46:56 --> Language Class Initialized
DEBUG - 2011-08-22 19:46:56 --> Loader Class Initialized
DEBUG - 2011-08-22 19:46:56 --> Controller Class Initialized
DEBUG - 2011-08-22 19:46:56 --> Model Class Initialized
DEBUG - 2011-08-22 19:46:56 --> Model Class Initialized
DEBUG - 2011-08-22 19:46:56 --> Model Class Initialized
DEBUG - 2011-08-22 19:46:56 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-22 19:46:56 --> Database Driver Class Initialized
DEBUG - 2011-08-22 19:46:56 --> File loaded: application/views/table/main.php
DEBUG - 2011-08-22 19:46:56 --> Helper loaded: url_helper
DEBUG - 2011-08-22 19:46:56 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-22 19:46:56 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-22 19:46:56 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-22 19:46:56 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-22 19:46:56 --> Final output sent to browser
DEBUG - 2011-08-22 19:46:56 --> Total execution time: 0.0444
DEBUG - 2011-08-22 19:46:57 --> Config Class Initialized
DEBUG - 2011-08-22 19:46:57 --> Hooks Class Initialized
DEBUG - 2011-08-22 19:46:57 --> Utf8 Class Initialized
DEBUG - 2011-08-22 19:46:57 --> UTF-8 Support Enabled
DEBUG - 2011-08-22 19:46:57 --> URI Class Initialized
DEBUG - 2011-08-22 19:46:57 --> Router Class Initialized
ERROR - 2011-08-22 19:46:57 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-08-22 21:54:57 --> Config Class Initialized
DEBUG - 2011-08-22 21:54:57 --> Hooks Class Initialized
DEBUG - 2011-08-22 21:54:57 --> Utf8 Class Initialized
DEBUG - 2011-08-22 21:54:57 --> UTF-8 Support Enabled
DEBUG - 2011-08-22 21:54:57 --> URI Class Initialized
DEBUG - 2011-08-22 21:54:57 --> Router Class Initialized
DEBUG - 2011-08-22 21:54:57 --> Output Class Initialized
DEBUG - 2011-08-22 21:54:57 --> Input Class Initialized
DEBUG - 2011-08-22 21:54:57 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-22 21:54:57 --> Language Class Initialized
DEBUG - 2011-08-22 21:54:57 --> Loader Class Initialized
DEBUG - 2011-08-22 21:54:57 --> Controller Class Initialized
ERROR - 2011-08-22 21:54:57 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-08-22 21:54:57 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-08-22 21:54:57 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-08-22 21:54:57 --> Model Class Initialized
DEBUG - 2011-08-22 21:54:57 --> Model Class Initialized
DEBUG - 2011-08-22 21:54:57 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-22 21:54:57 --> Database Driver Class Initialized
DEBUG - 2011-08-22 21:54:57 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-08-22 21:54:57 --> Helper loaded: url_helper
DEBUG - 2011-08-22 21:54:57 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-22 21:54:57 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-22 21:54:57 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-22 21:54:57 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-22 21:54:57 --> Final output sent to browser
DEBUG - 2011-08-22 21:54:57 --> Total execution time: 0.1214
DEBUG - 2011-08-22 21:55:00 --> Config Class Initialized
DEBUG - 2011-08-22 21:55:00 --> Hooks Class Initialized
DEBUG - 2011-08-22 21:55:00 --> Utf8 Class Initialized
DEBUG - 2011-08-22 21:55:00 --> UTF-8 Support Enabled
DEBUG - 2011-08-22 21:55:00 --> URI Class Initialized
DEBUG - 2011-08-22 21:55:00 --> Router Class Initialized
DEBUG - 2011-08-22 21:55:00 --> Output Class Initialized
DEBUG - 2011-08-22 21:55:00 --> Input Class Initialized
DEBUG - 2011-08-22 21:55:00 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-22 21:55:00 --> Language Class Initialized
DEBUG - 2011-08-22 21:55:00 --> Loader Class Initialized
DEBUG - 2011-08-22 21:55:00 --> Controller Class Initialized
DEBUG - 2011-08-22 21:55:00 --> Model Class Initialized
DEBUG - 2011-08-22 21:55:00 --> Model Class Initialized
DEBUG - 2011-08-22 21:55:00 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-22 21:55:00 --> Database Driver Class Initialized
DEBUG - 2011-08-22 21:55:01 --> Final output sent to browser
DEBUG - 2011-08-22 21:55:01 --> Total execution time: 0.7601
DEBUG - 2011-08-22 21:55:42 --> Config Class Initialized
DEBUG - 2011-08-22 21:55:42 --> Hooks Class Initialized
DEBUG - 2011-08-22 21:55:42 --> Utf8 Class Initialized
DEBUG - 2011-08-22 21:55:42 --> UTF-8 Support Enabled
DEBUG - 2011-08-22 21:55:42 --> URI Class Initialized
DEBUG - 2011-08-22 21:55:42 --> Router Class Initialized
DEBUG - 2011-08-22 21:55:42 --> Output Class Initialized
DEBUG - 2011-08-22 21:55:42 --> Input Class Initialized
DEBUG - 2011-08-22 21:55:42 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-22 21:55:42 --> Language Class Initialized
DEBUG - 2011-08-22 21:55:42 --> Loader Class Initialized
DEBUG - 2011-08-22 21:55:42 --> Controller Class Initialized
ERROR - 2011-08-22 21:55:42 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-08-22 21:55:42 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-08-22 21:55:42 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-08-22 21:55:42 --> Model Class Initialized
DEBUG - 2011-08-22 21:55:42 --> Model Class Initialized
DEBUG - 2011-08-22 21:55:42 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-22 21:55:42 --> Database Driver Class Initialized
DEBUG - 2011-08-22 21:55:42 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-08-22 21:55:42 --> Helper loaded: url_helper
DEBUG - 2011-08-22 21:55:42 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-22 21:55:42 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-22 21:55:42 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-22 21:55:42 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-22 21:55:42 --> Final output sent to browser
DEBUG - 2011-08-22 21:55:42 --> Total execution time: 0.0288
DEBUG - 2011-08-22 21:55:43 --> Config Class Initialized
DEBUG - 2011-08-22 21:55:43 --> Hooks Class Initialized
DEBUG - 2011-08-22 21:55:43 --> Utf8 Class Initialized
DEBUG - 2011-08-22 21:55:43 --> UTF-8 Support Enabled
DEBUG - 2011-08-22 21:55:43 --> URI Class Initialized
DEBUG - 2011-08-22 21:55:43 --> Router Class Initialized
DEBUG - 2011-08-22 21:55:43 --> Output Class Initialized
DEBUG - 2011-08-22 21:55:43 --> Input Class Initialized
DEBUG - 2011-08-22 21:55:43 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-22 21:55:43 --> Language Class Initialized
DEBUG - 2011-08-22 21:55:43 --> Loader Class Initialized
DEBUG - 2011-08-22 21:55:43 --> Controller Class Initialized
DEBUG - 2011-08-22 21:55:43 --> Model Class Initialized
DEBUG - 2011-08-22 21:55:43 --> Model Class Initialized
DEBUG - 2011-08-22 21:55:43 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-22 21:55:43 --> Database Driver Class Initialized
DEBUG - 2011-08-22 21:55:44 --> Final output sent to browser
DEBUG - 2011-08-22 21:55:44 --> Total execution time: 0.5974
DEBUG - 2011-08-22 21:55:56 --> Config Class Initialized
DEBUG - 2011-08-22 21:55:56 --> Hooks Class Initialized
DEBUG - 2011-08-22 21:55:56 --> Utf8 Class Initialized
DEBUG - 2011-08-22 21:55:56 --> UTF-8 Support Enabled
DEBUG - 2011-08-22 21:55:56 --> URI Class Initialized
DEBUG - 2011-08-22 21:55:56 --> Router Class Initialized
DEBUG - 2011-08-22 21:55:56 --> Output Class Initialized
DEBUG - 2011-08-22 21:55:56 --> Input Class Initialized
DEBUG - 2011-08-22 21:55:56 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-22 21:55:56 --> Language Class Initialized
DEBUG - 2011-08-22 21:55:56 --> Loader Class Initialized
DEBUG - 2011-08-22 21:55:56 --> Controller Class Initialized
DEBUG - 2011-08-22 21:55:56 --> Model Class Initialized
DEBUG - 2011-08-22 21:55:56 --> Model Class Initialized
DEBUG - 2011-08-22 21:55:56 --> Model Class Initialized
DEBUG - 2011-08-22 21:55:56 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-22 21:55:56 --> Database Driver Class Initialized
DEBUG - 2011-08-22 21:55:56 --> File loaded: application/views/table/main.php
DEBUG - 2011-08-22 21:55:56 --> Helper loaded: url_helper
DEBUG - 2011-08-22 21:55:56 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-22 21:55:56 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-22 21:55:56 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-22 21:55:56 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-22 21:55:56 --> Final output sent to browser
DEBUG - 2011-08-22 21:55:56 --> Total execution time: 0.3629
DEBUG - 2011-08-22 21:56:27 --> Config Class Initialized
DEBUG - 2011-08-22 21:56:27 --> Hooks Class Initialized
DEBUG - 2011-08-22 21:56:27 --> Utf8 Class Initialized
DEBUG - 2011-08-22 21:56:27 --> UTF-8 Support Enabled
DEBUG - 2011-08-22 21:56:27 --> URI Class Initialized
DEBUG - 2011-08-22 21:56:27 --> Router Class Initialized
DEBUG - 2011-08-22 21:56:27 --> Output Class Initialized
DEBUG - 2011-08-22 21:56:27 --> Input Class Initialized
DEBUG - 2011-08-22 21:56:27 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-22 21:56:27 --> Language Class Initialized
DEBUG - 2011-08-22 21:56:27 --> Loader Class Initialized
DEBUG - 2011-08-22 21:56:27 --> Controller Class Initialized
ERROR - 2011-08-22 21:56:27 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-08-22 21:56:27 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-08-22 21:56:27 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-08-22 21:56:27 --> Model Class Initialized
DEBUG - 2011-08-22 21:56:27 --> Model Class Initialized
DEBUG - 2011-08-22 21:56:27 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-22 21:56:27 --> Database Driver Class Initialized
DEBUG - 2011-08-22 21:56:27 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-08-22 21:56:27 --> Helper loaded: url_helper
DEBUG - 2011-08-22 21:56:27 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-22 21:56:27 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-22 21:56:27 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-22 21:56:27 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-22 21:56:27 --> Final output sent to browser
DEBUG - 2011-08-22 21:56:27 --> Total execution time: 0.0527
DEBUG - 2011-08-22 21:56:28 --> Config Class Initialized
DEBUG - 2011-08-22 21:56:28 --> Hooks Class Initialized
DEBUG - 2011-08-22 21:56:28 --> Utf8 Class Initialized
DEBUG - 2011-08-22 21:56:28 --> UTF-8 Support Enabled
DEBUG - 2011-08-22 21:56:28 --> URI Class Initialized
DEBUG - 2011-08-22 21:56:28 --> Router Class Initialized
DEBUG - 2011-08-22 21:56:28 --> Output Class Initialized
DEBUG - 2011-08-22 21:56:28 --> Input Class Initialized
DEBUG - 2011-08-22 21:56:28 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-22 21:56:28 --> Language Class Initialized
DEBUG - 2011-08-22 21:56:28 --> Loader Class Initialized
DEBUG - 2011-08-22 21:56:28 --> Controller Class Initialized
DEBUG - 2011-08-22 21:56:28 --> Model Class Initialized
DEBUG - 2011-08-22 21:56:28 --> Model Class Initialized
DEBUG - 2011-08-22 21:56:28 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-22 21:56:28 --> Database Driver Class Initialized
DEBUG - 2011-08-22 21:56:28 --> Final output sent to browser
DEBUG - 2011-08-22 21:56:28 --> Total execution time: 0.4772
DEBUG - 2011-08-22 21:56:30 --> Config Class Initialized
DEBUG - 2011-08-22 21:56:30 --> Hooks Class Initialized
DEBUG - 2011-08-22 21:56:30 --> Utf8 Class Initialized
DEBUG - 2011-08-22 21:56:30 --> UTF-8 Support Enabled
DEBUG - 2011-08-22 21:56:30 --> URI Class Initialized
DEBUG - 2011-08-22 21:56:30 --> Router Class Initialized
ERROR - 2011-08-22 21:56:30 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-08-22 21:56:30 --> Config Class Initialized
DEBUG - 2011-08-22 21:56:30 --> Hooks Class Initialized
DEBUG - 2011-08-22 21:56:30 --> Utf8 Class Initialized
DEBUG - 2011-08-22 21:56:30 --> UTF-8 Support Enabled
DEBUG - 2011-08-22 21:56:30 --> URI Class Initialized
DEBUG - 2011-08-22 21:56:30 --> Router Class Initialized
ERROR - 2011-08-22 21:56:30 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-08-22 21:56:31 --> Config Class Initialized
DEBUG - 2011-08-22 21:56:31 --> Hooks Class Initialized
DEBUG - 2011-08-22 21:56:31 --> Utf8 Class Initialized
DEBUG - 2011-08-22 21:56:31 --> UTF-8 Support Enabled
DEBUG - 2011-08-22 21:56:31 --> URI Class Initialized
DEBUG - 2011-08-22 21:56:31 --> Router Class Initialized
ERROR - 2011-08-22 21:56:31 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-08-22 21:57:02 --> Config Class Initialized
DEBUG - 2011-08-22 21:57:02 --> Hooks Class Initialized
DEBUG - 2011-08-22 21:57:02 --> Utf8 Class Initialized
DEBUG - 2011-08-22 21:57:02 --> UTF-8 Support Enabled
DEBUG - 2011-08-22 21:57:02 --> URI Class Initialized
DEBUG - 2011-08-22 21:57:02 --> Router Class Initialized
DEBUG - 2011-08-22 21:57:02 --> Output Class Initialized
DEBUG - 2011-08-22 21:57:02 --> Input Class Initialized
DEBUG - 2011-08-22 21:57:02 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-22 21:57:02 --> Language Class Initialized
DEBUG - 2011-08-22 21:57:02 --> Loader Class Initialized
DEBUG - 2011-08-22 21:57:02 --> Controller Class Initialized
ERROR - 2011-08-22 21:57:02 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-08-22 21:57:02 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-08-22 21:57:02 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-08-22 21:57:02 --> Model Class Initialized
DEBUG - 2011-08-22 21:57:02 --> Model Class Initialized
DEBUG - 2011-08-22 21:57:02 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-22 21:57:02 --> Database Driver Class Initialized
DEBUG - 2011-08-22 21:57:02 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-08-22 21:57:02 --> Helper loaded: url_helper
DEBUG - 2011-08-22 21:57:02 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-22 21:57:02 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-22 21:57:02 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-22 21:57:02 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-22 21:57:02 --> Final output sent to browser
DEBUG - 2011-08-22 21:57:02 --> Total execution time: 0.0304
DEBUG - 2011-08-22 21:57:03 --> Config Class Initialized
DEBUG - 2011-08-22 21:57:03 --> Hooks Class Initialized
DEBUG - 2011-08-22 21:57:03 --> Utf8 Class Initialized
DEBUG - 2011-08-22 21:57:03 --> UTF-8 Support Enabled
DEBUG - 2011-08-22 21:57:03 --> URI Class Initialized
DEBUG - 2011-08-22 21:57:03 --> Router Class Initialized
DEBUG - 2011-08-22 21:57:03 --> Output Class Initialized
DEBUG - 2011-08-22 21:57:03 --> Input Class Initialized
DEBUG - 2011-08-22 21:57:03 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-22 21:57:03 --> Language Class Initialized
DEBUG - 2011-08-22 21:57:03 --> Loader Class Initialized
DEBUG - 2011-08-22 21:57:03 --> Controller Class Initialized
DEBUG - 2011-08-22 21:57:03 --> Model Class Initialized
DEBUG - 2011-08-22 21:57:03 --> Model Class Initialized
DEBUG - 2011-08-22 21:57:03 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-22 21:57:03 --> Database Driver Class Initialized
DEBUG - 2011-08-22 21:57:03 --> Final output sent to browser
DEBUG - 2011-08-22 21:57:03 --> Total execution time: 0.4609
DEBUG - 2011-08-22 21:57:04 --> Config Class Initialized
DEBUG - 2011-08-22 21:57:04 --> Hooks Class Initialized
DEBUG - 2011-08-22 21:57:04 --> Utf8 Class Initialized
DEBUG - 2011-08-22 21:57:04 --> UTF-8 Support Enabled
DEBUG - 2011-08-22 21:57:04 --> URI Class Initialized
DEBUG - 2011-08-22 21:57:04 --> Router Class Initialized
DEBUG - 2011-08-22 21:57:04 --> Output Class Initialized
DEBUG - 2011-08-22 21:57:04 --> Input Class Initialized
DEBUG - 2011-08-22 21:57:04 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-22 21:57:04 --> Language Class Initialized
DEBUG - 2011-08-22 21:57:04 --> Loader Class Initialized
DEBUG - 2011-08-22 21:57:04 --> Controller Class Initialized
ERROR - 2011-08-22 21:57:04 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-08-22 21:57:04 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-08-22 21:57:04 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-08-22 21:57:04 --> Model Class Initialized
DEBUG - 2011-08-22 21:57:04 --> Model Class Initialized
DEBUG - 2011-08-22 21:57:04 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-22 21:57:04 --> Database Driver Class Initialized
DEBUG - 2011-08-22 21:57:04 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-08-22 21:57:04 --> Helper loaded: url_helper
DEBUG - 2011-08-22 21:57:04 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-22 21:57:04 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-22 21:57:04 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-22 21:57:04 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-22 21:57:04 --> Final output sent to browser
DEBUG - 2011-08-22 21:57:04 --> Total execution time: 0.0325
DEBUG - 2011-08-22 21:57:21 --> Config Class Initialized
DEBUG - 2011-08-22 21:57:21 --> Hooks Class Initialized
DEBUG - 2011-08-22 21:57:21 --> Utf8 Class Initialized
DEBUG - 2011-08-22 21:57:21 --> UTF-8 Support Enabled
DEBUG - 2011-08-22 21:57:21 --> URI Class Initialized
DEBUG - 2011-08-22 21:57:21 --> Router Class Initialized
DEBUG - 2011-08-22 21:57:21 --> Output Class Initialized
DEBUG - 2011-08-22 21:57:21 --> Input Class Initialized
DEBUG - 2011-08-22 21:57:21 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-22 21:57:21 --> Language Class Initialized
DEBUG - 2011-08-22 21:57:21 --> Loader Class Initialized
DEBUG - 2011-08-22 21:57:21 --> Controller Class Initialized
ERROR - 2011-08-22 21:57:21 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-08-22 21:57:21 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-08-22 21:57:21 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-08-22 21:57:21 --> Model Class Initialized
DEBUG - 2011-08-22 21:57:21 --> Model Class Initialized
DEBUG - 2011-08-22 21:57:21 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-22 21:57:21 --> Database Driver Class Initialized
DEBUG - 2011-08-22 21:57:21 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-08-22 21:57:21 --> Helper loaded: url_helper
DEBUG - 2011-08-22 21:57:21 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-22 21:57:21 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-22 21:57:21 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-22 21:57:21 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-22 21:57:21 --> Final output sent to browser
DEBUG - 2011-08-22 21:57:21 --> Total execution time: 0.1096
DEBUG - 2011-08-22 21:57:22 --> Config Class Initialized
DEBUG - 2011-08-22 21:57:22 --> Hooks Class Initialized
DEBUG - 2011-08-22 21:57:22 --> Utf8 Class Initialized
DEBUG - 2011-08-22 21:57:22 --> UTF-8 Support Enabled
DEBUG - 2011-08-22 21:57:22 --> URI Class Initialized
DEBUG - 2011-08-22 21:57:22 --> Router Class Initialized
DEBUG - 2011-08-22 21:57:22 --> Output Class Initialized
DEBUG - 2011-08-22 21:57:22 --> Input Class Initialized
DEBUG - 2011-08-22 21:57:22 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-22 21:57:22 --> Language Class Initialized
DEBUG - 2011-08-22 21:57:22 --> Loader Class Initialized
DEBUG - 2011-08-22 21:57:22 --> Controller Class Initialized
DEBUG - 2011-08-22 21:57:22 --> Model Class Initialized
DEBUG - 2011-08-22 21:57:22 --> Model Class Initialized
DEBUG - 2011-08-22 21:57:22 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-22 21:57:22 --> Database Driver Class Initialized
DEBUG - 2011-08-22 21:57:22 --> Final output sent to browser
DEBUG - 2011-08-22 21:57:22 --> Total execution time: 0.5412
DEBUG - 2011-08-22 22:05:23 --> Config Class Initialized
DEBUG - 2011-08-22 22:05:23 --> Hooks Class Initialized
DEBUG - 2011-08-22 22:05:23 --> Utf8 Class Initialized
DEBUG - 2011-08-22 22:05:23 --> UTF-8 Support Enabled
DEBUG - 2011-08-22 22:05:23 --> URI Class Initialized
DEBUG - 2011-08-22 22:05:23 --> Router Class Initialized
DEBUG - 2011-08-22 22:05:23 --> Output Class Initialized
DEBUG - 2011-08-22 22:05:23 --> Input Class Initialized
DEBUG - 2011-08-22 22:05:23 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-22 22:05:23 --> Language Class Initialized
DEBUG - 2011-08-22 22:05:23 --> Loader Class Initialized
DEBUG - 2011-08-22 22:05:23 --> Controller Class Initialized
DEBUG - 2011-08-22 22:05:23 --> Model Class Initialized
DEBUG - 2011-08-22 22:05:23 --> Model Class Initialized
DEBUG - 2011-08-22 22:05:23 --> Model Class Initialized
DEBUG - 2011-08-22 22:05:23 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-22 22:05:23 --> Database Driver Class Initialized
DEBUG - 2011-08-22 22:05:23 --> File loaded: application/views/table/main.php
DEBUG - 2011-08-22 22:05:23 --> Helper loaded: url_helper
DEBUG - 2011-08-22 22:05:23 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-22 22:05:23 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-22 22:05:23 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-22 22:05:23 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-22 22:05:23 --> Final output sent to browser
DEBUG - 2011-08-22 22:05:23 --> Total execution time: 0.0522
DEBUG - 2011-08-22 22:05:26 --> Config Class Initialized
DEBUG - 2011-08-22 22:05:26 --> Hooks Class Initialized
DEBUG - 2011-08-22 22:05:26 --> Utf8 Class Initialized
DEBUG - 2011-08-22 22:05:26 --> UTF-8 Support Enabled
DEBUG - 2011-08-22 22:05:26 --> URI Class Initialized
DEBUG - 2011-08-22 22:05:26 --> Router Class Initialized
ERROR - 2011-08-22 22:05:26 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-08-22 22:50:51 --> Config Class Initialized
DEBUG - 2011-08-22 22:50:51 --> Hooks Class Initialized
DEBUG - 2011-08-22 22:50:51 --> Utf8 Class Initialized
DEBUG - 2011-08-22 22:50:51 --> UTF-8 Support Enabled
DEBUG - 2011-08-22 22:50:51 --> URI Class Initialized
DEBUG - 2011-08-22 22:50:51 --> Router Class Initialized
DEBUG - 2011-08-22 22:50:51 --> No URI present. Default controller set.
DEBUG - 2011-08-22 22:50:51 --> Output Class Initialized
DEBUG - 2011-08-22 22:50:51 --> Input Class Initialized
DEBUG - 2011-08-22 22:50:51 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-22 22:50:51 --> Language Class Initialized
DEBUG - 2011-08-22 22:50:51 --> Loader Class Initialized
DEBUG - 2011-08-22 22:50:51 --> Controller Class Initialized
DEBUG - 2011-08-22 22:50:52 --> File loaded: application/views/splash/main.php
DEBUG - 2011-08-22 22:50:52 --> Helper loaded: url_helper
DEBUG - 2011-08-22 22:50:52 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-22 22:50:52 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-22 22:50:52 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-22 22:50:52 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-22 22:50:52 --> Final output sent to browser
DEBUG - 2011-08-22 22:50:52 --> Total execution time: 0.1077
DEBUG - 2011-08-22 23:30:56 --> Config Class Initialized
DEBUG - 2011-08-22 23:30:56 --> Hooks Class Initialized
DEBUG - 2011-08-22 23:30:56 --> Utf8 Class Initialized
DEBUG - 2011-08-22 23:30:56 --> UTF-8 Support Enabled
DEBUG - 2011-08-22 23:30:56 --> URI Class Initialized
DEBUG - 2011-08-22 23:30:56 --> Router Class Initialized
DEBUG - 2011-08-22 23:30:56 --> No URI present. Default controller set.
DEBUG - 2011-08-22 23:30:56 --> Output Class Initialized
DEBUG - 2011-08-22 23:30:56 --> Input Class Initialized
DEBUG - 2011-08-22 23:30:56 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-22 23:30:56 --> Language Class Initialized
DEBUG - 2011-08-22 23:30:56 --> Loader Class Initialized
DEBUG - 2011-08-22 23:30:56 --> Controller Class Initialized
DEBUG - 2011-08-22 23:30:56 --> File loaded: application/views/splash/main.php
DEBUG - 2011-08-22 23:30:56 --> Helper loaded: url_helper
DEBUG - 2011-08-22 23:30:56 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-22 23:30:56 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-22 23:30:56 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-22 23:30:56 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-22 23:30:56 --> Final output sent to browser
DEBUG - 2011-08-22 23:30:56 --> Total execution time: 0.0142
DEBUG - 2011-08-22 23:38:02 --> Config Class Initialized
DEBUG - 2011-08-22 23:38:02 --> Hooks Class Initialized
DEBUG - 2011-08-22 23:38:02 --> Utf8 Class Initialized
DEBUG - 2011-08-22 23:38:02 --> UTF-8 Support Enabled
DEBUG - 2011-08-22 23:38:02 --> URI Class Initialized
DEBUG - 2011-08-22 23:38:02 --> Router Class Initialized
ERROR - 2011-08-22 23:38:02 --> 404 Page Not Found --> robots.txt
DEBUG - 2011-08-22 23:40:19 --> Config Class Initialized
DEBUG - 2011-08-22 23:40:19 --> Hooks Class Initialized
DEBUG - 2011-08-22 23:40:19 --> Utf8 Class Initialized
DEBUG - 2011-08-22 23:40:19 --> UTF-8 Support Enabled
DEBUG - 2011-08-22 23:40:19 --> URI Class Initialized
DEBUG - 2011-08-22 23:40:19 --> Router Class Initialized
DEBUG - 2011-08-22 23:40:19 --> Output Class Initialized
DEBUG - 2011-08-22 23:40:19 --> Input Class Initialized
DEBUG - 2011-08-22 23:40:19 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-22 23:40:19 --> Language Class Initialized
DEBUG - 2011-08-22 23:40:19 --> Loader Class Initialized
DEBUG - 2011-08-22 23:40:19 --> Controller Class Initialized
DEBUG - 2011-08-22 23:40:19 --> Model Class Initialized
DEBUG - 2011-08-22 23:40:19 --> Model Class Initialized
DEBUG - 2011-08-22 23:40:19 --> Model Class Initialized
DEBUG - 2011-08-22 23:40:19 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-22 23:40:19 --> Database Driver Class Initialized
DEBUG - 2011-08-22 23:40:19 --> File loaded: application/views/table/main.php
DEBUG - 2011-08-22 23:40:19 --> Helper loaded: url_helper
DEBUG - 2011-08-22 23:40:19 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-22 23:40:19 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-22 23:40:19 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-22 23:40:19 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-22 23:40:19 --> Final output sent to browser
DEBUG - 2011-08-22 23:40:19 --> Total execution time: 0.5547
DEBUG - 2011-08-22 23:49:16 --> Config Class Initialized
DEBUG - 2011-08-22 23:49:16 --> Hooks Class Initialized
DEBUG - 2011-08-22 23:49:16 --> Utf8 Class Initialized
DEBUG - 2011-08-22 23:49:16 --> UTF-8 Support Enabled
DEBUG - 2011-08-22 23:49:16 --> URI Class Initialized
DEBUG - 2011-08-22 23:49:16 --> Router Class Initialized
DEBUG - 2011-08-22 23:49:16 --> Output Class Initialized
DEBUG - 2011-08-22 23:49:16 --> Input Class Initialized
DEBUG - 2011-08-22 23:49:16 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-22 23:49:16 --> Language Class Initialized
DEBUG - 2011-08-22 23:49:16 --> Loader Class Initialized
DEBUG - 2011-08-22 23:49:16 --> Controller Class Initialized
ERROR - 2011-08-22 23:49:16 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-08-22 23:49:16 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-08-22 23:49:16 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-08-22 23:49:16 --> Model Class Initialized
DEBUG - 2011-08-22 23:49:16 --> Model Class Initialized
DEBUG - 2011-08-22 23:49:16 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-22 23:49:16 --> Database Driver Class Initialized
DEBUG - 2011-08-22 23:49:16 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-08-22 23:49:16 --> Helper loaded: url_helper
DEBUG - 2011-08-22 23:49:16 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-22 23:49:16 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-22 23:49:16 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-22 23:49:16 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-22 23:49:16 --> Final output sent to browser
DEBUG - 2011-08-22 23:49:16 --> Total execution time: 0.0299
DEBUG - 2011-08-22 23:49:17 --> Config Class Initialized
DEBUG - 2011-08-22 23:49:17 --> Hooks Class Initialized
DEBUG - 2011-08-22 23:49:17 --> Utf8 Class Initialized
DEBUG - 2011-08-22 23:49:17 --> UTF-8 Support Enabled
DEBUG - 2011-08-22 23:49:17 --> URI Class Initialized
DEBUG - 2011-08-22 23:49:17 --> Router Class Initialized
DEBUG - 2011-08-22 23:49:17 --> Output Class Initialized
DEBUG - 2011-08-22 23:49:17 --> Input Class Initialized
DEBUG - 2011-08-22 23:49:17 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-22 23:49:17 --> Language Class Initialized
DEBUG - 2011-08-22 23:49:17 --> Loader Class Initialized
DEBUG - 2011-08-22 23:49:17 --> Controller Class Initialized
DEBUG - 2011-08-22 23:49:17 --> Model Class Initialized
DEBUG - 2011-08-22 23:49:17 --> Model Class Initialized
DEBUG - 2011-08-22 23:49:17 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-22 23:49:17 --> Database Driver Class Initialized
DEBUG - 2011-08-22 23:49:18 --> Final output sent to browser
DEBUG - 2011-08-22 23:49:18 --> Total execution time: 0.5146
DEBUG - 2011-08-22 23:49:23 --> Config Class Initialized
DEBUG - 2011-08-22 23:49:23 --> Hooks Class Initialized
DEBUG - 2011-08-22 23:49:23 --> Utf8 Class Initialized
DEBUG - 2011-08-22 23:49:23 --> UTF-8 Support Enabled
DEBUG - 2011-08-22 23:49:23 --> URI Class Initialized
DEBUG - 2011-08-22 23:49:23 --> Router Class Initialized
ERROR - 2011-08-22 23:49:23 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-08-22 23:49:23 --> Config Class Initialized
DEBUG - 2011-08-22 23:49:23 --> Hooks Class Initialized
DEBUG - 2011-08-22 23:49:23 --> Utf8 Class Initialized
DEBUG - 2011-08-22 23:49:23 --> UTF-8 Support Enabled
DEBUG - 2011-08-22 23:49:23 --> URI Class Initialized
DEBUG - 2011-08-22 23:49:23 --> Router Class Initialized
ERROR - 2011-08-22 23:49:23 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-08-22 23:52:14 --> Config Class Initialized
DEBUG - 2011-08-22 23:52:14 --> Hooks Class Initialized
DEBUG - 2011-08-22 23:52:14 --> Utf8 Class Initialized
DEBUG - 2011-08-22 23:52:14 --> UTF-8 Support Enabled
DEBUG - 2011-08-22 23:52:14 --> URI Class Initialized
DEBUG - 2011-08-22 23:52:14 --> Router Class Initialized
DEBUG - 2011-08-22 23:52:14 --> Output Class Initialized
DEBUG - 2011-08-22 23:52:14 --> Input Class Initialized
DEBUG - 2011-08-22 23:52:14 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-22 23:52:14 --> Language Class Initialized
DEBUG - 2011-08-22 23:52:14 --> Loader Class Initialized
DEBUG - 2011-08-22 23:52:14 --> Controller Class Initialized
DEBUG - 2011-08-22 23:52:14 --> Model Class Initialized
DEBUG - 2011-08-22 23:52:14 --> Model Class Initialized
DEBUG - 2011-08-22 23:52:14 --> Model Class Initialized
DEBUG - 2011-08-22 23:52:14 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-22 23:52:14 --> Database Driver Class Initialized
DEBUG - 2011-08-22 23:52:14 --> File loaded: application/views/table/main.php
DEBUG - 2011-08-22 23:52:14 --> Helper loaded: url_helper
DEBUG - 2011-08-22 23:52:14 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-22 23:52:14 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-22 23:52:14 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-22 23:52:14 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-22 23:52:14 --> Final output sent to browser
DEBUG - 2011-08-22 23:52:14 --> Total execution time: 0.0722
DEBUG - 2011-08-22 23:52:16 --> Config Class Initialized
DEBUG - 2011-08-22 23:52:16 --> Hooks Class Initialized
DEBUG - 2011-08-22 23:52:16 --> Utf8 Class Initialized
DEBUG - 2011-08-22 23:52:16 --> UTF-8 Support Enabled
DEBUG - 2011-08-22 23:52:16 --> URI Class Initialized
DEBUG - 2011-08-22 23:52:16 --> Router Class Initialized
ERROR - 2011-08-22 23:52:16 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-08-22 23:52:16 --> Config Class Initialized
DEBUG - 2011-08-22 23:52:16 --> Hooks Class Initialized
DEBUG - 2011-08-22 23:52:16 --> Utf8 Class Initialized
DEBUG - 2011-08-22 23:52:16 --> UTF-8 Support Enabled
DEBUG - 2011-08-22 23:52:16 --> URI Class Initialized
DEBUG - 2011-08-22 23:52:16 --> Router Class Initialized
ERROR - 2011-08-22 23:52:16 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-08-22 23:52:22 --> Config Class Initialized
DEBUG - 2011-08-22 23:52:22 --> Hooks Class Initialized
DEBUG - 2011-08-22 23:52:22 --> Utf8 Class Initialized
DEBUG - 2011-08-22 23:52:22 --> UTF-8 Support Enabled
DEBUG - 2011-08-22 23:52:22 --> URI Class Initialized
DEBUG - 2011-08-22 23:52:22 --> Router Class Initialized
DEBUG - 2011-08-22 23:52:22 --> Output Class Initialized
DEBUG - 2011-08-22 23:52:22 --> Input Class Initialized
DEBUG - 2011-08-22 23:52:22 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-22 23:52:22 --> Language Class Initialized
DEBUG - 2011-08-22 23:52:22 --> Loader Class Initialized
DEBUG - 2011-08-22 23:52:22 --> Controller Class Initialized
ERROR - 2011-08-22 23:52:22 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-08-22 23:52:22 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-08-22 23:52:22 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-08-22 23:52:22 --> Model Class Initialized
DEBUG - 2011-08-22 23:52:22 --> Model Class Initialized
DEBUG - 2011-08-22 23:52:22 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-22 23:52:22 --> Database Driver Class Initialized
DEBUG - 2011-08-22 23:52:22 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-08-22 23:52:22 --> Helper loaded: url_helper
DEBUG - 2011-08-22 23:52:22 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-22 23:52:22 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-22 23:52:22 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-22 23:52:22 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-22 23:52:22 --> Final output sent to browser
DEBUG - 2011-08-22 23:52:22 --> Total execution time: 0.0280
DEBUG - 2011-08-22 23:52:23 --> Config Class Initialized
DEBUG - 2011-08-22 23:52:23 --> Hooks Class Initialized
DEBUG - 2011-08-22 23:52:23 --> Utf8 Class Initialized
DEBUG - 2011-08-22 23:52:23 --> UTF-8 Support Enabled
DEBUG - 2011-08-22 23:52:23 --> URI Class Initialized
DEBUG - 2011-08-22 23:52:23 --> Router Class Initialized
DEBUG - 2011-08-22 23:52:23 --> Output Class Initialized
DEBUG - 2011-08-22 23:52:23 --> Input Class Initialized
DEBUG - 2011-08-22 23:52:23 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-22 23:52:23 --> Language Class Initialized
DEBUG - 2011-08-22 23:52:23 --> Loader Class Initialized
DEBUG - 2011-08-22 23:52:23 --> Controller Class Initialized
DEBUG - 2011-08-22 23:52:23 --> Model Class Initialized
DEBUG - 2011-08-22 23:52:23 --> Model Class Initialized
DEBUG - 2011-08-22 23:52:23 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-22 23:52:23 --> Database Driver Class Initialized
DEBUG - 2011-08-22 23:52:23 --> Final output sent to browser
DEBUG - 2011-08-22 23:52:23 --> Total execution time: 0.4513

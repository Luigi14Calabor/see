<?php  if ( ! defined('BASEPATH')) exit('No direct script access allowed'); ?>

DEBUG - 2011-10-03 00:14:15 --> Config Class Initialized
DEBUG - 2011-10-03 00:14:15 --> Hooks Class Initialized
DEBUG - 2011-10-03 00:14:15 --> Utf8 Class Initialized
DEBUG - 2011-10-03 00:14:15 --> UTF-8 Support Enabled
DEBUG - 2011-10-03 00:14:15 --> URI Class Initialized
DEBUG - 2011-10-03 00:14:15 --> Router Class Initialized
DEBUG - 2011-10-03 00:14:15 --> No URI present. Default controller set.
DEBUG - 2011-10-03 00:14:15 --> Output Class Initialized
DEBUG - 2011-10-03 00:14:15 --> Input Class Initialized
DEBUG - 2011-10-03 00:14:15 --> Global POST and COOKIE data sanitized
DEBUG - 2011-10-03 00:14:15 --> Language Class Initialized
DEBUG - 2011-10-03 00:14:15 --> Loader Class Initialized
DEBUG - 2011-10-03 00:14:15 --> Controller Class Initialized
DEBUG - 2011-10-03 00:14:15 --> File loaded: application/views/splash/main.php
DEBUG - 2011-10-03 00:14:15 --> Helper loaded: url_helper
DEBUG - 2011-10-03 00:14:15 --> File loaded: application/views/common/header.php
DEBUG - 2011-10-03 00:14:15 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-10-03 00:14:15 --> File loaded: application/views/common/footer.php
DEBUG - 2011-10-03 00:14:15 --> File loaded: application/views/layout/main.php
DEBUG - 2011-10-03 00:14:15 --> Final output sent to browser
DEBUG - 2011-10-03 00:14:15 --> Total execution time: 0.0855
DEBUG - 2011-10-03 00:49:15 --> Config Class Initialized
DEBUG - 2011-10-03 00:49:15 --> Hooks Class Initialized
DEBUG - 2011-10-03 00:49:15 --> Utf8 Class Initialized
DEBUG - 2011-10-03 00:49:15 --> UTF-8 Support Enabled
DEBUG - 2011-10-03 00:49:15 --> URI Class Initialized
DEBUG - 2011-10-03 00:49:15 --> Router Class Initialized
DEBUG - 2011-10-03 00:49:15 --> Output Class Initialized
DEBUG - 2011-10-03 00:49:15 --> Input Class Initialized
DEBUG - 2011-10-03 00:49:15 --> Global POST and COOKIE data sanitized
DEBUG - 2011-10-03 00:49:15 --> Language Class Initialized
DEBUG - 2011-10-03 00:49:15 --> Loader Class Initialized
DEBUG - 2011-10-03 00:49:15 --> Controller Class Initialized
ERROR - 2011-10-03 00:49:15 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-10-03 00:49:15 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-10-03 00:49:15 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-10-03 00:49:15 --> Model Class Initialized
DEBUG - 2011-10-03 00:49:15 --> Model Class Initialized
DEBUG - 2011-10-03 00:49:15 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-10-03 00:49:15 --> Database Driver Class Initialized
DEBUG - 2011-10-03 00:49:15 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-10-03 00:49:15 --> Helper loaded: url_helper
DEBUG - 2011-10-03 00:49:15 --> File loaded: application/views/common/header.php
DEBUG - 2011-10-03 00:49:15 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-10-03 00:49:15 --> File loaded: application/views/common/footer.php
DEBUG - 2011-10-03 00:49:15 --> File loaded: application/views/layout/main.php
DEBUG - 2011-10-03 00:49:15 --> Final output sent to browser
DEBUG - 2011-10-03 00:49:15 --> Total execution time: 0.2113
DEBUG - 2011-10-03 00:49:17 --> Config Class Initialized
DEBUG - 2011-10-03 00:49:17 --> Hooks Class Initialized
DEBUG - 2011-10-03 00:49:17 --> Utf8 Class Initialized
DEBUG - 2011-10-03 00:49:17 --> UTF-8 Support Enabled
DEBUG - 2011-10-03 00:49:17 --> URI Class Initialized
DEBUG - 2011-10-03 00:49:17 --> Router Class Initialized
DEBUG - 2011-10-03 00:49:17 --> Output Class Initialized
DEBUG - 2011-10-03 00:49:17 --> Input Class Initialized
DEBUG - 2011-10-03 00:49:17 --> Global POST and COOKIE data sanitized
DEBUG - 2011-10-03 00:49:17 --> Language Class Initialized
DEBUG - 2011-10-03 00:49:17 --> Loader Class Initialized
DEBUG - 2011-10-03 00:49:17 --> Controller Class Initialized
DEBUG - 2011-10-03 00:49:17 --> Model Class Initialized
DEBUG - 2011-10-03 00:49:17 --> Model Class Initialized
DEBUG - 2011-10-03 00:49:17 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-10-03 00:49:17 --> Database Driver Class Initialized
DEBUG - 2011-10-03 00:49:18 --> Final output sent to browser
DEBUG - 2011-10-03 00:49:18 --> Total execution time: 0.7769
DEBUG - 2011-10-03 00:49:19 --> Config Class Initialized
DEBUG - 2011-10-03 00:49:19 --> Hooks Class Initialized
DEBUG - 2011-10-03 00:49:19 --> Utf8 Class Initialized
DEBUG - 2011-10-03 00:49:19 --> UTF-8 Support Enabled
DEBUG - 2011-10-03 00:49:19 --> URI Class Initialized
DEBUG - 2011-10-03 00:49:19 --> Router Class Initialized
ERROR - 2011-10-03 00:49:19 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-10-03 00:49:48 --> Config Class Initialized
DEBUG - 2011-10-03 00:49:48 --> Hooks Class Initialized
DEBUG - 2011-10-03 00:49:48 --> Utf8 Class Initialized
DEBUG - 2011-10-03 00:49:48 --> UTF-8 Support Enabled
DEBUG - 2011-10-03 00:49:48 --> URI Class Initialized
DEBUG - 2011-10-03 00:49:48 --> Router Class Initialized
DEBUG - 2011-10-03 00:49:48 --> Output Class Initialized
DEBUG - 2011-10-03 00:49:48 --> Input Class Initialized
DEBUG - 2011-10-03 00:49:48 --> Global POST and COOKIE data sanitized
DEBUG - 2011-10-03 00:49:48 --> Language Class Initialized
DEBUG - 2011-10-03 00:49:48 --> Loader Class Initialized
DEBUG - 2011-10-03 00:49:48 --> Controller Class Initialized
ERROR - 2011-10-03 00:49:48 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-10-03 00:49:48 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-10-03 00:49:48 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-10-03 00:49:48 --> Model Class Initialized
DEBUG - 2011-10-03 00:49:48 --> Model Class Initialized
DEBUG - 2011-10-03 00:49:48 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-10-03 00:49:48 --> Database Driver Class Initialized
DEBUG - 2011-10-03 00:49:48 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-10-03 00:49:48 --> Helper loaded: url_helper
DEBUG - 2011-10-03 00:49:48 --> File loaded: application/views/common/header.php
DEBUG - 2011-10-03 00:49:48 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-10-03 00:49:48 --> File loaded: application/views/common/footer.php
DEBUG - 2011-10-03 00:49:48 --> File loaded: application/views/layout/main.php
DEBUG - 2011-10-03 00:49:48 --> Final output sent to browser
DEBUG - 2011-10-03 00:49:48 --> Total execution time: 0.0329
DEBUG - 2011-10-03 00:49:49 --> Config Class Initialized
DEBUG - 2011-10-03 00:49:49 --> Hooks Class Initialized
DEBUG - 2011-10-03 00:49:49 --> Utf8 Class Initialized
DEBUG - 2011-10-03 00:49:49 --> UTF-8 Support Enabled
DEBUG - 2011-10-03 00:49:49 --> URI Class Initialized
DEBUG - 2011-10-03 00:49:49 --> Router Class Initialized
DEBUG - 2011-10-03 00:49:49 --> Output Class Initialized
DEBUG - 2011-10-03 00:49:49 --> Input Class Initialized
DEBUG - 2011-10-03 00:49:49 --> Global POST and COOKIE data sanitized
DEBUG - 2011-10-03 00:49:49 --> Language Class Initialized
DEBUG - 2011-10-03 00:49:49 --> Loader Class Initialized
DEBUG - 2011-10-03 00:49:49 --> Controller Class Initialized
DEBUG - 2011-10-03 00:49:49 --> Model Class Initialized
DEBUG - 2011-10-03 00:49:49 --> Model Class Initialized
DEBUG - 2011-10-03 00:49:49 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-10-03 00:49:49 --> Database Driver Class Initialized
DEBUG - 2011-10-03 00:49:50 --> Final output sent to browser
DEBUG - 2011-10-03 00:49:50 --> Total execution time: 0.8858
DEBUG - 2011-10-03 00:49:51 --> Config Class Initialized
DEBUG - 2011-10-03 00:49:51 --> Hooks Class Initialized
DEBUG - 2011-10-03 00:49:51 --> Utf8 Class Initialized
DEBUG - 2011-10-03 00:49:51 --> UTF-8 Support Enabled
DEBUG - 2011-10-03 00:49:51 --> URI Class Initialized
DEBUG - 2011-10-03 00:49:51 --> Router Class Initialized
ERROR - 2011-10-03 00:49:51 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-10-03 00:49:57 --> Config Class Initialized
DEBUG - 2011-10-03 00:49:57 --> Hooks Class Initialized
DEBUG - 2011-10-03 00:49:57 --> Utf8 Class Initialized
DEBUG - 2011-10-03 00:49:57 --> UTF-8 Support Enabled
DEBUG - 2011-10-03 00:49:57 --> URI Class Initialized
DEBUG - 2011-10-03 00:49:57 --> Router Class Initialized
DEBUG - 2011-10-03 00:49:57 --> Output Class Initialized
DEBUG - 2011-10-03 00:49:57 --> Input Class Initialized
DEBUG - 2011-10-03 00:49:57 --> Global POST and COOKIE data sanitized
DEBUG - 2011-10-03 00:49:57 --> Language Class Initialized
DEBUG - 2011-10-03 00:49:57 --> Loader Class Initialized
DEBUG - 2011-10-03 00:49:57 --> Controller Class Initialized
ERROR - 2011-10-03 00:49:57 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-10-03 00:49:57 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-10-03 00:49:57 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-10-03 00:49:57 --> Model Class Initialized
DEBUG - 2011-10-03 00:49:57 --> Model Class Initialized
DEBUG - 2011-10-03 00:49:57 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-10-03 00:49:57 --> Database Driver Class Initialized
DEBUG - 2011-10-03 00:49:57 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-10-03 00:49:57 --> Helper loaded: url_helper
DEBUG - 2011-10-03 00:49:57 --> File loaded: application/views/common/header.php
DEBUG - 2011-10-03 00:49:57 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-10-03 00:49:57 --> File loaded: application/views/common/footer.php
DEBUG - 2011-10-03 00:49:57 --> File loaded: application/views/layout/main.php
DEBUG - 2011-10-03 00:49:57 --> Final output sent to browser
DEBUG - 2011-10-03 00:49:57 --> Total execution time: 0.0308
DEBUG - 2011-10-03 00:49:57 --> Config Class Initialized
DEBUG - 2011-10-03 00:49:57 --> Hooks Class Initialized
DEBUG - 2011-10-03 00:49:57 --> Utf8 Class Initialized
DEBUG - 2011-10-03 00:49:57 --> UTF-8 Support Enabled
DEBUG - 2011-10-03 00:49:57 --> URI Class Initialized
DEBUG - 2011-10-03 00:49:57 --> Router Class Initialized
DEBUG - 2011-10-03 00:49:57 --> Output Class Initialized
DEBUG - 2011-10-03 00:49:57 --> Input Class Initialized
DEBUG - 2011-10-03 00:49:57 --> Global POST and COOKIE data sanitized
DEBUG - 2011-10-03 00:49:57 --> Language Class Initialized
DEBUG - 2011-10-03 00:49:57 --> Loader Class Initialized
DEBUG - 2011-10-03 00:49:57 --> Controller Class Initialized
DEBUG - 2011-10-03 00:49:57 --> Model Class Initialized
DEBUG - 2011-10-03 00:49:57 --> Model Class Initialized
DEBUG - 2011-10-03 00:49:57 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-10-03 00:49:57 --> Database Driver Class Initialized
DEBUG - 2011-10-03 00:49:58 --> Final output sent to browser
DEBUG - 2011-10-03 00:49:58 --> Total execution time: 0.5664
DEBUG - 2011-10-03 00:49:59 --> Config Class Initialized
DEBUG - 2011-10-03 00:49:59 --> Hooks Class Initialized
DEBUG - 2011-10-03 00:49:59 --> Utf8 Class Initialized
DEBUG - 2011-10-03 00:49:59 --> UTF-8 Support Enabled
DEBUG - 2011-10-03 00:49:59 --> URI Class Initialized
DEBUG - 2011-10-03 00:49:59 --> Router Class Initialized
ERROR - 2011-10-03 00:49:59 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-10-03 00:50:05 --> Config Class Initialized
DEBUG - 2011-10-03 00:50:05 --> Hooks Class Initialized
DEBUG - 2011-10-03 00:50:05 --> Utf8 Class Initialized
DEBUG - 2011-10-03 00:50:05 --> UTF-8 Support Enabled
DEBUG - 2011-10-03 00:50:05 --> URI Class Initialized
DEBUG - 2011-10-03 00:50:05 --> Router Class Initialized
DEBUG - 2011-10-03 00:50:05 --> Output Class Initialized
DEBUG - 2011-10-03 00:50:05 --> Input Class Initialized
DEBUG - 2011-10-03 00:50:05 --> Global POST and COOKIE data sanitized
DEBUG - 2011-10-03 00:50:05 --> Language Class Initialized
DEBUG - 2011-10-03 00:50:05 --> Loader Class Initialized
DEBUG - 2011-10-03 00:50:05 --> Controller Class Initialized
ERROR - 2011-10-03 00:50:05 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-10-03 00:50:05 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-10-03 00:50:05 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-10-03 00:50:05 --> Model Class Initialized
DEBUG - 2011-10-03 00:50:05 --> Model Class Initialized
DEBUG - 2011-10-03 00:50:05 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-10-03 00:50:05 --> Database Driver Class Initialized
DEBUG - 2011-10-03 00:50:05 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-10-03 00:50:05 --> Helper loaded: url_helper
DEBUG - 2011-10-03 00:50:05 --> File loaded: application/views/common/header.php
DEBUG - 2011-10-03 00:50:05 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-10-03 00:50:05 --> File loaded: application/views/common/footer.php
DEBUG - 2011-10-03 00:50:05 --> File loaded: application/views/layout/main.php
DEBUG - 2011-10-03 00:50:05 --> Final output sent to browser
DEBUG - 2011-10-03 00:50:05 --> Total execution time: 0.0343
DEBUG - 2011-10-03 00:50:06 --> Config Class Initialized
DEBUG - 2011-10-03 00:50:06 --> Hooks Class Initialized
DEBUG - 2011-10-03 00:50:06 --> Utf8 Class Initialized
DEBUG - 2011-10-03 00:50:06 --> UTF-8 Support Enabled
DEBUG - 2011-10-03 00:50:06 --> URI Class Initialized
DEBUG - 2011-10-03 00:50:06 --> Router Class Initialized
DEBUG - 2011-10-03 00:50:06 --> Output Class Initialized
DEBUG - 2011-10-03 00:50:06 --> Input Class Initialized
DEBUG - 2011-10-03 00:50:06 --> Global POST and COOKIE data sanitized
DEBUG - 2011-10-03 00:50:06 --> Language Class Initialized
DEBUG - 2011-10-03 00:50:06 --> Loader Class Initialized
DEBUG - 2011-10-03 00:50:06 --> Controller Class Initialized
DEBUG - 2011-10-03 00:50:06 --> Model Class Initialized
DEBUG - 2011-10-03 00:50:06 --> Model Class Initialized
DEBUG - 2011-10-03 00:50:06 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-10-03 00:50:06 --> Database Driver Class Initialized
DEBUG - 2011-10-03 00:50:06 --> Final output sent to browser
DEBUG - 2011-10-03 00:50:06 --> Total execution time: 0.5427
DEBUG - 2011-10-03 00:50:07 --> Config Class Initialized
DEBUG - 2011-10-03 00:50:07 --> Hooks Class Initialized
DEBUG - 2011-10-03 00:50:07 --> Utf8 Class Initialized
DEBUG - 2011-10-03 00:50:07 --> UTF-8 Support Enabled
DEBUG - 2011-10-03 00:50:07 --> URI Class Initialized
DEBUG - 2011-10-03 00:50:07 --> Router Class Initialized
ERROR - 2011-10-03 00:50:07 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-10-03 00:50:14 --> Config Class Initialized
DEBUG - 2011-10-03 00:50:14 --> Hooks Class Initialized
DEBUG - 2011-10-03 00:50:14 --> Utf8 Class Initialized
DEBUG - 2011-10-03 00:50:14 --> UTF-8 Support Enabled
DEBUG - 2011-10-03 00:50:14 --> URI Class Initialized
DEBUG - 2011-10-03 00:50:14 --> Router Class Initialized
DEBUG - 2011-10-03 00:50:14 --> Output Class Initialized
DEBUG - 2011-10-03 00:50:14 --> Input Class Initialized
DEBUG - 2011-10-03 00:50:14 --> Global POST and COOKIE data sanitized
DEBUG - 2011-10-03 00:50:14 --> Language Class Initialized
DEBUG - 2011-10-03 00:50:14 --> Loader Class Initialized
DEBUG - 2011-10-03 00:50:14 --> Controller Class Initialized
ERROR - 2011-10-03 00:50:14 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-10-03 00:50:14 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-10-03 00:50:14 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-10-03 00:50:14 --> Model Class Initialized
DEBUG - 2011-10-03 00:50:14 --> Model Class Initialized
DEBUG - 2011-10-03 00:50:14 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-10-03 00:50:14 --> Database Driver Class Initialized
DEBUG - 2011-10-03 00:50:14 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-10-03 00:50:14 --> Helper loaded: url_helper
DEBUG - 2011-10-03 00:50:14 --> File loaded: application/views/common/header.php
DEBUG - 2011-10-03 00:50:14 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-10-03 00:50:14 --> File loaded: application/views/common/footer.php
DEBUG - 2011-10-03 00:50:14 --> File loaded: application/views/layout/main.php
DEBUG - 2011-10-03 00:50:14 --> Final output sent to browser
DEBUG - 2011-10-03 00:50:14 --> Total execution time: 0.0337
DEBUG - 2011-10-03 00:50:15 --> Config Class Initialized
DEBUG - 2011-10-03 00:50:15 --> Hooks Class Initialized
DEBUG - 2011-10-03 00:50:15 --> Utf8 Class Initialized
DEBUG - 2011-10-03 00:50:15 --> UTF-8 Support Enabled
DEBUG - 2011-10-03 00:50:15 --> URI Class Initialized
DEBUG - 2011-10-03 00:50:15 --> Router Class Initialized
DEBUG - 2011-10-03 00:50:15 --> Output Class Initialized
DEBUG - 2011-10-03 00:50:15 --> Input Class Initialized
DEBUG - 2011-10-03 00:50:15 --> Global POST and COOKIE data sanitized
DEBUG - 2011-10-03 00:50:15 --> Language Class Initialized
DEBUG - 2011-10-03 00:50:15 --> Loader Class Initialized
DEBUG - 2011-10-03 00:50:15 --> Controller Class Initialized
DEBUG - 2011-10-03 00:50:15 --> Model Class Initialized
DEBUG - 2011-10-03 00:50:15 --> Model Class Initialized
DEBUG - 2011-10-03 00:50:15 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-10-03 00:50:15 --> Database Driver Class Initialized
DEBUG - 2011-10-03 00:50:16 --> Final output sent to browser
DEBUG - 2011-10-03 00:50:16 --> Total execution time: 0.7702
DEBUG - 2011-10-03 00:50:17 --> Config Class Initialized
DEBUG - 2011-10-03 00:50:17 --> Hooks Class Initialized
DEBUG - 2011-10-03 00:50:17 --> Utf8 Class Initialized
DEBUG - 2011-10-03 00:50:17 --> UTF-8 Support Enabled
DEBUG - 2011-10-03 00:50:17 --> URI Class Initialized
DEBUG - 2011-10-03 00:50:17 --> Router Class Initialized
ERROR - 2011-10-03 00:50:17 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-10-03 00:50:34 --> Config Class Initialized
DEBUG - 2011-10-03 00:50:34 --> Hooks Class Initialized
DEBUG - 2011-10-03 00:50:34 --> Utf8 Class Initialized
DEBUG - 2011-10-03 00:50:34 --> UTF-8 Support Enabled
DEBUG - 2011-10-03 00:50:34 --> URI Class Initialized
DEBUG - 2011-10-03 00:50:34 --> Router Class Initialized
DEBUG - 2011-10-03 00:50:34 --> Output Class Initialized
DEBUG - 2011-10-03 00:50:34 --> Input Class Initialized
DEBUG - 2011-10-03 00:50:34 --> Global POST and COOKIE data sanitized
DEBUG - 2011-10-03 00:50:34 --> Language Class Initialized
DEBUG - 2011-10-03 00:50:34 --> Loader Class Initialized
DEBUG - 2011-10-03 00:50:34 --> Controller Class Initialized
ERROR - 2011-10-03 00:50:34 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-10-03 00:50:34 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-10-03 00:50:34 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-10-03 00:50:34 --> Model Class Initialized
DEBUG - 2011-10-03 00:50:34 --> Model Class Initialized
DEBUG - 2011-10-03 00:50:34 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-10-03 00:50:34 --> Database Driver Class Initialized
DEBUG - 2011-10-03 00:50:34 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-10-03 00:50:34 --> Helper loaded: url_helper
DEBUG - 2011-10-03 00:50:34 --> File loaded: application/views/common/header.php
DEBUG - 2011-10-03 00:50:34 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-10-03 00:50:34 --> File loaded: application/views/common/footer.php
DEBUG - 2011-10-03 00:50:34 --> File loaded: application/views/layout/main.php
DEBUG - 2011-10-03 00:50:34 --> Final output sent to browser
DEBUG - 2011-10-03 00:50:34 --> Total execution time: 0.0305
DEBUG - 2011-10-03 00:50:35 --> Config Class Initialized
DEBUG - 2011-10-03 00:50:35 --> Hooks Class Initialized
DEBUG - 2011-10-03 00:50:35 --> Utf8 Class Initialized
DEBUG - 2011-10-03 00:50:35 --> UTF-8 Support Enabled
DEBUG - 2011-10-03 00:50:35 --> URI Class Initialized
DEBUG - 2011-10-03 00:50:35 --> Router Class Initialized
DEBUG - 2011-10-03 00:50:35 --> Output Class Initialized
DEBUG - 2011-10-03 00:50:35 --> Input Class Initialized
DEBUG - 2011-10-03 00:50:35 --> Global POST and COOKIE data sanitized
DEBUG - 2011-10-03 00:50:35 --> Language Class Initialized
DEBUG - 2011-10-03 00:50:35 --> Loader Class Initialized
DEBUG - 2011-10-03 00:50:35 --> Controller Class Initialized
DEBUG - 2011-10-03 00:50:35 --> Model Class Initialized
DEBUG - 2011-10-03 00:50:35 --> Model Class Initialized
DEBUG - 2011-10-03 00:50:35 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-10-03 00:50:35 --> Database Driver Class Initialized
DEBUG - 2011-10-03 00:50:35 --> Final output sent to browser
DEBUG - 2011-10-03 00:50:35 --> Total execution time: 0.6779
DEBUG - 2011-10-03 00:50:37 --> Config Class Initialized
DEBUG - 2011-10-03 00:50:37 --> Hooks Class Initialized
DEBUG - 2011-10-03 00:50:37 --> Utf8 Class Initialized
DEBUG - 2011-10-03 00:50:37 --> UTF-8 Support Enabled
DEBUG - 2011-10-03 00:50:37 --> URI Class Initialized
DEBUG - 2011-10-03 00:50:37 --> Router Class Initialized
ERROR - 2011-10-03 00:50:37 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-10-03 00:50:58 --> Config Class Initialized
DEBUG - 2011-10-03 00:50:58 --> Hooks Class Initialized
DEBUG - 2011-10-03 00:50:58 --> Utf8 Class Initialized
DEBUG - 2011-10-03 00:50:58 --> UTF-8 Support Enabled
DEBUG - 2011-10-03 00:50:58 --> URI Class Initialized
DEBUG - 2011-10-03 00:50:58 --> Router Class Initialized
DEBUG - 2011-10-03 00:50:58 --> Output Class Initialized
DEBUG - 2011-10-03 00:50:58 --> Input Class Initialized
DEBUG - 2011-10-03 00:50:58 --> Global POST and COOKIE data sanitized
DEBUG - 2011-10-03 00:50:58 --> Language Class Initialized
DEBUG - 2011-10-03 00:50:58 --> Loader Class Initialized
DEBUG - 2011-10-03 00:50:58 --> Controller Class Initialized
ERROR - 2011-10-03 00:50:58 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-10-03 00:50:58 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-10-03 00:50:58 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-10-03 00:50:58 --> Model Class Initialized
DEBUG - 2011-10-03 00:50:58 --> Model Class Initialized
DEBUG - 2011-10-03 00:50:58 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-10-03 00:50:58 --> Database Driver Class Initialized
DEBUG - 2011-10-03 00:50:58 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-10-03 00:50:58 --> Helper loaded: url_helper
DEBUG - 2011-10-03 00:50:58 --> File loaded: application/views/common/header.php
DEBUG - 2011-10-03 00:50:58 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-10-03 00:50:58 --> File loaded: application/views/common/footer.php
DEBUG - 2011-10-03 00:50:58 --> File loaded: application/views/layout/main.php
DEBUG - 2011-10-03 00:50:58 --> Final output sent to browser
DEBUG - 2011-10-03 00:50:58 --> Total execution time: 0.0389
DEBUG - 2011-10-03 00:50:59 --> Config Class Initialized
DEBUG - 2011-10-03 00:50:59 --> Hooks Class Initialized
DEBUG - 2011-10-03 00:50:59 --> Utf8 Class Initialized
DEBUG - 2011-10-03 00:50:59 --> UTF-8 Support Enabled
DEBUG - 2011-10-03 00:50:59 --> URI Class Initialized
DEBUG - 2011-10-03 00:50:59 --> Router Class Initialized
DEBUG - 2011-10-03 00:50:59 --> Output Class Initialized
DEBUG - 2011-10-03 00:50:59 --> Input Class Initialized
DEBUG - 2011-10-03 00:50:59 --> Global POST and COOKIE data sanitized
DEBUG - 2011-10-03 00:50:59 --> Language Class Initialized
DEBUG - 2011-10-03 00:50:59 --> Loader Class Initialized
DEBUG - 2011-10-03 00:50:59 --> Controller Class Initialized
DEBUG - 2011-10-03 00:50:59 --> Model Class Initialized
DEBUG - 2011-10-03 00:50:59 --> Model Class Initialized
DEBUG - 2011-10-03 00:50:59 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-10-03 00:50:59 --> Database Driver Class Initialized
DEBUG - 2011-10-03 00:50:59 --> Final output sent to browser
DEBUG - 2011-10-03 00:50:59 --> Total execution time: 0.5706
DEBUG - 2011-10-03 00:51:00 --> Config Class Initialized
DEBUG - 2011-10-03 00:51:00 --> Hooks Class Initialized
DEBUG - 2011-10-03 00:51:00 --> Utf8 Class Initialized
DEBUG - 2011-10-03 00:51:00 --> UTF-8 Support Enabled
DEBUG - 2011-10-03 00:51:00 --> URI Class Initialized
DEBUG - 2011-10-03 00:51:00 --> Router Class Initialized
ERROR - 2011-10-03 00:51:00 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-10-03 00:51:10 --> Config Class Initialized
DEBUG - 2011-10-03 00:51:10 --> Hooks Class Initialized
DEBUG - 2011-10-03 00:51:10 --> Utf8 Class Initialized
DEBUG - 2011-10-03 00:51:10 --> UTF-8 Support Enabled
DEBUG - 2011-10-03 00:51:10 --> URI Class Initialized
DEBUG - 2011-10-03 00:51:10 --> Router Class Initialized
DEBUG - 2011-10-03 00:51:10 --> Output Class Initialized
DEBUG - 2011-10-03 00:51:10 --> Input Class Initialized
DEBUG - 2011-10-03 00:51:10 --> Global POST and COOKIE data sanitized
DEBUG - 2011-10-03 00:51:10 --> Language Class Initialized
DEBUG - 2011-10-03 00:51:10 --> Loader Class Initialized
DEBUG - 2011-10-03 00:51:10 --> Controller Class Initialized
ERROR - 2011-10-03 00:51:10 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-10-03 00:51:10 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-10-03 00:51:10 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-10-03 00:51:10 --> Model Class Initialized
DEBUG - 2011-10-03 00:51:10 --> Model Class Initialized
DEBUG - 2011-10-03 00:51:10 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-10-03 00:51:10 --> Database Driver Class Initialized
DEBUG - 2011-10-03 00:51:10 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-10-03 00:51:10 --> Helper loaded: url_helper
DEBUG - 2011-10-03 00:51:10 --> File loaded: application/views/common/header.php
DEBUG - 2011-10-03 00:51:10 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-10-03 00:51:10 --> File loaded: application/views/common/footer.php
DEBUG - 2011-10-03 00:51:10 --> File loaded: application/views/layout/main.php
DEBUG - 2011-10-03 00:51:10 --> Final output sent to browser
DEBUG - 2011-10-03 00:51:10 --> Total execution time: 0.0315
DEBUG - 2011-10-03 00:51:19 --> Config Class Initialized
DEBUG - 2011-10-03 00:51:19 --> Hooks Class Initialized
DEBUG - 2011-10-03 00:51:19 --> Utf8 Class Initialized
DEBUG - 2011-10-03 00:51:19 --> UTF-8 Support Enabled
DEBUG - 2011-10-03 00:51:19 --> URI Class Initialized
DEBUG - 2011-10-03 00:51:19 --> Router Class Initialized
DEBUG - 2011-10-03 00:51:19 --> Output Class Initialized
DEBUG - 2011-10-03 00:51:19 --> Input Class Initialized
DEBUG - 2011-10-03 00:51:19 --> Global POST and COOKIE data sanitized
DEBUG - 2011-10-03 00:51:19 --> Language Class Initialized
DEBUG - 2011-10-03 00:51:19 --> Loader Class Initialized
DEBUG - 2011-10-03 00:51:19 --> Controller Class Initialized
ERROR - 2011-10-03 00:51:19 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-10-03 00:51:19 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-10-03 00:51:19 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-10-03 00:51:19 --> Model Class Initialized
DEBUG - 2011-10-03 00:51:19 --> Model Class Initialized
DEBUG - 2011-10-03 00:51:19 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-10-03 00:51:19 --> Database Driver Class Initialized
DEBUG - 2011-10-03 00:51:19 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-10-03 00:51:19 --> Helper loaded: url_helper
DEBUG - 2011-10-03 00:51:19 --> File loaded: application/views/common/header.php
DEBUG - 2011-10-03 00:51:19 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-10-03 00:51:19 --> File loaded: application/views/common/footer.php
DEBUG - 2011-10-03 00:51:19 --> File loaded: application/views/layout/main.php
DEBUG - 2011-10-03 00:51:19 --> Final output sent to browser
DEBUG - 2011-10-03 00:51:19 --> Total execution time: 0.0299
DEBUG - 2011-10-03 02:10:21 --> Config Class Initialized
DEBUG - 2011-10-03 02:10:21 --> Hooks Class Initialized
DEBUG - 2011-10-03 02:10:21 --> Utf8 Class Initialized
DEBUG - 2011-10-03 02:10:21 --> UTF-8 Support Enabled
DEBUG - 2011-10-03 02:10:21 --> URI Class Initialized
DEBUG - 2011-10-03 02:10:21 --> Router Class Initialized
DEBUG - 2011-10-03 02:10:21 --> Output Class Initialized
DEBUG - 2011-10-03 02:10:21 --> Input Class Initialized
DEBUG - 2011-10-03 02:10:21 --> Global POST and COOKIE data sanitized
DEBUG - 2011-10-03 02:10:21 --> Language Class Initialized
DEBUG - 2011-10-03 02:10:21 --> Loader Class Initialized
DEBUG - 2011-10-03 02:10:21 --> Controller Class Initialized
DEBUG - 2011-10-03 02:10:21 --> Model Class Initialized
DEBUG - 2011-10-03 02:10:21 --> Model Class Initialized
DEBUG - 2011-10-03 02:10:22 --> Model Class Initialized
DEBUG - 2011-10-03 02:10:22 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-10-03 02:10:22 --> Database Driver Class Initialized
DEBUG - 2011-10-03 02:10:23 --> File loaded: application/views/table/main.php
DEBUG - 2011-10-03 02:10:23 --> Helper loaded: url_helper
DEBUG - 2011-10-03 02:10:23 --> File loaded: application/views/common/header.php
DEBUG - 2011-10-03 02:10:23 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-10-03 02:10:23 --> File loaded: application/views/common/footer.php
DEBUG - 2011-10-03 02:10:23 --> File loaded: application/views/layout/main.php
DEBUG - 2011-10-03 02:10:23 --> Final output sent to browser
DEBUG - 2011-10-03 02:10:23 --> Total execution time: 1.6935
DEBUG - 2011-10-03 02:10:37 --> Config Class Initialized
DEBUG - 2011-10-03 02:10:37 --> Hooks Class Initialized
DEBUG - 2011-10-03 02:10:37 --> Utf8 Class Initialized
DEBUG - 2011-10-03 02:10:37 --> UTF-8 Support Enabled
DEBUG - 2011-10-03 02:10:37 --> URI Class Initialized
DEBUG - 2011-10-03 02:10:37 --> Router Class Initialized
DEBUG - 2011-10-03 02:10:37 --> Output Class Initialized
DEBUG - 2011-10-03 02:10:37 --> Input Class Initialized
DEBUG - 2011-10-03 02:10:37 --> Global POST and COOKIE data sanitized
DEBUG - 2011-10-03 02:10:37 --> Language Class Initialized
DEBUG - 2011-10-03 02:10:37 --> Loader Class Initialized
DEBUG - 2011-10-03 02:10:37 --> Controller Class Initialized
DEBUG - 2011-10-03 02:10:37 --> Model Class Initialized
DEBUG - 2011-10-03 02:10:37 --> Model Class Initialized
DEBUG - 2011-10-03 02:10:37 --> Model Class Initialized
DEBUG - 2011-10-03 02:10:37 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-10-03 02:10:37 --> Database Driver Class Initialized
DEBUG - 2011-10-03 02:10:39 --> File loaded: application/views/table/main.php
DEBUG - 2011-10-03 02:10:39 --> Helper loaded: url_helper
DEBUG - 2011-10-03 02:10:39 --> File loaded: application/views/common/header.php
DEBUG - 2011-10-03 02:10:39 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-10-03 02:10:39 --> File loaded: application/views/common/footer.php
DEBUG - 2011-10-03 02:10:39 --> File loaded: application/views/layout/main.php
DEBUG - 2011-10-03 02:10:39 --> Final output sent to browser
DEBUG - 2011-10-03 02:10:39 --> Total execution time: 1.7583
DEBUG - 2011-10-03 02:10:40 --> Config Class Initialized
DEBUG - 2011-10-03 02:10:40 --> Hooks Class Initialized
DEBUG - 2011-10-03 02:10:40 --> Utf8 Class Initialized
DEBUG - 2011-10-03 02:10:40 --> UTF-8 Support Enabled
DEBUG - 2011-10-03 02:10:40 --> URI Class Initialized
DEBUG - 2011-10-03 02:10:40 --> Router Class Initialized
DEBUG - 2011-10-03 02:10:40 --> Output Class Initialized
DEBUG - 2011-10-03 02:10:40 --> Input Class Initialized
DEBUG - 2011-10-03 02:10:40 --> Global POST and COOKIE data sanitized
DEBUG - 2011-10-03 02:10:40 --> Language Class Initialized
DEBUG - 2011-10-03 02:10:40 --> Loader Class Initialized
DEBUG - 2011-10-03 02:10:40 --> Controller Class Initialized
DEBUG - 2011-10-03 02:10:40 --> Model Class Initialized
DEBUG - 2011-10-03 02:10:40 --> Model Class Initialized
DEBUG - 2011-10-03 02:10:40 --> Model Class Initialized
DEBUG - 2011-10-03 02:10:40 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-10-03 02:10:40 --> Database Driver Class Initialized
DEBUG - 2011-10-03 02:10:40 --> File loaded: application/views/table/main.php
DEBUG - 2011-10-03 02:10:40 --> Helper loaded: url_helper
DEBUG - 2011-10-03 02:10:40 --> File loaded: application/views/common/header.php
DEBUG - 2011-10-03 02:10:40 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-10-03 02:10:40 --> File loaded: application/views/common/footer.php
DEBUG - 2011-10-03 02:10:40 --> File loaded: application/views/layout/main.php
DEBUG - 2011-10-03 02:10:40 --> Final output sent to browser
DEBUG - 2011-10-03 02:10:40 --> Total execution time: 0.0882
DEBUG - 2011-10-03 02:10:41 --> Config Class Initialized
DEBUG - 2011-10-03 02:10:41 --> Hooks Class Initialized
DEBUG - 2011-10-03 02:10:41 --> Utf8 Class Initialized
DEBUG - 2011-10-03 02:10:41 --> UTF-8 Support Enabled
DEBUG - 2011-10-03 02:10:41 --> URI Class Initialized
DEBUG - 2011-10-03 02:10:41 --> Router Class Initialized
DEBUG - 2011-10-03 02:10:41 --> Output Class Initialized
DEBUG - 2011-10-03 02:10:41 --> Input Class Initialized
DEBUG - 2011-10-03 02:10:41 --> Global POST and COOKIE data sanitized
DEBUG - 2011-10-03 02:10:41 --> Language Class Initialized
DEBUG - 2011-10-03 02:10:41 --> Loader Class Initialized
DEBUG - 2011-10-03 02:10:41 --> Controller Class Initialized
DEBUG - 2011-10-03 02:10:41 --> Model Class Initialized
DEBUG - 2011-10-03 02:10:41 --> Model Class Initialized
DEBUG - 2011-10-03 02:10:41 --> Model Class Initialized
DEBUG - 2011-10-03 02:10:41 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-10-03 02:10:41 --> Database Driver Class Initialized
DEBUG - 2011-10-03 02:10:41 --> File loaded: application/views/table/main.php
DEBUG - 2011-10-03 02:10:41 --> Helper loaded: url_helper
DEBUG - 2011-10-03 02:10:41 --> File loaded: application/views/common/header.php
DEBUG - 2011-10-03 02:10:41 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-10-03 02:10:41 --> File loaded: application/views/common/footer.php
DEBUG - 2011-10-03 02:10:41 --> File loaded: application/views/layout/main.php
DEBUG - 2011-10-03 02:10:41 --> Final output sent to browser
DEBUG - 2011-10-03 02:10:41 --> Total execution time: 0.0735
DEBUG - 2011-10-03 02:10:58 --> Config Class Initialized
DEBUG - 2011-10-03 02:10:58 --> Hooks Class Initialized
DEBUG - 2011-10-03 02:10:58 --> Utf8 Class Initialized
DEBUG - 2011-10-03 02:10:58 --> UTF-8 Support Enabled
DEBUG - 2011-10-03 02:10:58 --> URI Class Initialized
DEBUG - 2011-10-03 02:10:58 --> Router Class Initialized
DEBUG - 2011-10-03 02:10:58 --> Output Class Initialized
DEBUG - 2011-10-03 02:10:58 --> Input Class Initialized
DEBUG - 2011-10-03 02:10:58 --> Global POST and COOKIE data sanitized
DEBUG - 2011-10-03 02:10:58 --> Language Class Initialized
DEBUG - 2011-10-03 02:10:58 --> Loader Class Initialized
DEBUG - 2011-10-03 02:10:58 --> Controller Class Initialized
DEBUG - 2011-10-03 02:10:58 --> Model Class Initialized
DEBUG - 2011-10-03 02:10:58 --> Model Class Initialized
DEBUG - 2011-10-03 02:10:58 --> Model Class Initialized
DEBUG - 2011-10-03 02:10:58 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-10-03 02:10:58 --> Database Driver Class Initialized
DEBUG - 2011-10-03 02:10:59 --> File loaded: application/views/table/main.php
DEBUG - 2011-10-03 02:10:59 --> Helper loaded: url_helper
DEBUG - 2011-10-03 02:10:59 --> File loaded: application/views/common/header.php
DEBUG - 2011-10-03 02:10:59 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-10-03 02:10:59 --> File loaded: application/views/common/footer.php
DEBUG - 2011-10-03 02:10:59 --> File loaded: application/views/layout/main.php
DEBUG - 2011-10-03 02:10:59 --> Final output sent to browser
DEBUG - 2011-10-03 02:10:59 --> Total execution time: 1.5300
DEBUG - 2011-10-03 02:11:03 --> Config Class Initialized
DEBUG - 2011-10-03 02:11:03 --> Hooks Class Initialized
DEBUG - 2011-10-03 02:11:03 --> Utf8 Class Initialized
DEBUG - 2011-10-03 02:11:03 --> UTF-8 Support Enabled
DEBUG - 2011-10-03 02:11:03 --> URI Class Initialized
DEBUG - 2011-10-03 02:11:03 --> Router Class Initialized
DEBUG - 2011-10-03 02:11:03 --> Output Class Initialized
DEBUG - 2011-10-03 02:11:03 --> Input Class Initialized
DEBUG - 2011-10-03 02:11:03 --> Global POST and COOKIE data sanitized
DEBUG - 2011-10-03 02:11:03 --> Language Class Initialized
DEBUG - 2011-10-03 02:11:03 --> Loader Class Initialized
DEBUG - 2011-10-03 02:11:03 --> Controller Class Initialized
DEBUG - 2011-10-03 02:11:03 --> Model Class Initialized
DEBUG - 2011-10-03 02:11:03 --> Model Class Initialized
DEBUG - 2011-10-03 02:11:03 --> Model Class Initialized
DEBUG - 2011-10-03 02:11:03 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-10-03 02:11:03 --> Database Driver Class Initialized
DEBUG - 2011-10-03 02:11:03 --> File loaded: application/views/table/main.php
DEBUG - 2011-10-03 02:11:03 --> Helper loaded: url_helper
DEBUG - 2011-10-03 02:11:03 --> File loaded: application/views/common/header.php
DEBUG - 2011-10-03 02:11:03 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-10-03 02:11:03 --> File loaded: application/views/common/footer.php
DEBUG - 2011-10-03 02:11:03 --> File loaded: application/views/layout/main.php
DEBUG - 2011-10-03 02:11:03 --> Final output sent to browser
DEBUG - 2011-10-03 02:11:03 --> Total execution time: 0.3277
DEBUG - 2011-10-03 02:32:05 --> Config Class Initialized
DEBUG - 2011-10-03 02:32:05 --> Hooks Class Initialized
DEBUG - 2011-10-03 02:32:05 --> Utf8 Class Initialized
DEBUG - 2011-10-03 02:32:05 --> UTF-8 Support Enabled
DEBUG - 2011-10-03 02:32:05 --> URI Class Initialized
DEBUG - 2011-10-03 02:32:05 --> Router Class Initialized
DEBUG - 2011-10-03 02:32:05 --> Output Class Initialized
DEBUG - 2011-10-03 02:32:05 --> Input Class Initialized
DEBUG - 2011-10-03 02:32:05 --> Global POST and COOKIE data sanitized
DEBUG - 2011-10-03 02:32:05 --> Language Class Initialized
DEBUG - 2011-10-03 02:32:05 --> Loader Class Initialized
DEBUG - 2011-10-03 02:32:05 --> Controller Class Initialized
DEBUG - 2011-10-03 02:32:05 --> Model Class Initialized
DEBUG - 2011-10-03 02:32:05 --> Model Class Initialized
DEBUG - 2011-10-03 02:32:05 --> Model Class Initialized
DEBUG - 2011-10-03 02:32:05 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-10-03 02:32:05 --> Database Driver Class Initialized
DEBUG - 2011-10-03 02:32:08 --> File loaded: application/views/table/main.php
DEBUG - 2011-10-03 02:32:08 --> Helper loaded: url_helper
DEBUG - 2011-10-03 02:32:08 --> File loaded: application/views/common/header.php
DEBUG - 2011-10-03 02:32:08 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-10-03 02:32:08 --> File loaded: application/views/common/footer.php
DEBUG - 2011-10-03 02:32:08 --> File loaded: application/views/layout/main.php
DEBUG - 2011-10-03 02:32:08 --> Final output sent to browser
DEBUG - 2011-10-03 02:32:08 --> Total execution time: 3.0627
DEBUG - 2011-10-03 02:32:09 --> Config Class Initialized
DEBUG - 2011-10-03 02:32:09 --> Hooks Class Initialized
DEBUG - 2011-10-03 02:32:09 --> Utf8 Class Initialized
DEBUG - 2011-10-03 02:32:09 --> UTF-8 Support Enabled
DEBUG - 2011-10-03 02:32:09 --> URI Class Initialized
DEBUG - 2011-10-03 02:32:09 --> Router Class Initialized
DEBUG - 2011-10-03 02:32:09 --> Output Class Initialized
DEBUG - 2011-10-03 02:32:09 --> Input Class Initialized
DEBUG - 2011-10-03 02:32:09 --> Global POST and COOKIE data sanitized
DEBUG - 2011-10-03 02:32:09 --> Language Class Initialized
DEBUG - 2011-10-03 02:32:09 --> Loader Class Initialized
DEBUG - 2011-10-03 02:32:09 --> Controller Class Initialized
ERROR - 2011-10-03 02:32:09 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-10-03 02:32:09 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-10-03 02:32:09 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-10-03 02:32:09 --> Model Class Initialized
DEBUG - 2011-10-03 02:32:09 --> Model Class Initialized
DEBUG - 2011-10-03 02:32:09 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-10-03 02:32:09 --> Database Driver Class Initialized
DEBUG - 2011-10-03 02:32:09 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-10-03 02:32:09 --> Helper loaded: url_helper
DEBUG - 2011-10-03 02:32:09 --> File loaded: application/views/common/header.php
DEBUG - 2011-10-03 02:32:09 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-10-03 02:32:09 --> File loaded: application/views/common/footer.php
DEBUG - 2011-10-03 02:32:09 --> File loaded: application/views/layout/main.php
DEBUG - 2011-10-03 02:32:09 --> Final output sent to browser
DEBUG - 2011-10-03 02:32:09 --> Total execution time: 0.1528
DEBUG - 2011-10-03 02:48:25 --> Config Class Initialized
DEBUG - 2011-10-03 02:48:25 --> Hooks Class Initialized
DEBUG - 2011-10-03 02:48:25 --> Utf8 Class Initialized
DEBUG - 2011-10-03 02:48:25 --> UTF-8 Support Enabled
DEBUG - 2011-10-03 02:48:25 --> URI Class Initialized
DEBUG - 2011-10-03 02:48:25 --> Router Class Initialized
DEBUG - 2011-10-03 02:48:25 --> Output Class Initialized
DEBUG - 2011-10-03 02:48:25 --> Input Class Initialized
DEBUG - 2011-10-03 02:48:25 --> Global POST and COOKIE data sanitized
DEBUG - 2011-10-03 02:48:25 --> Language Class Initialized
DEBUG - 2011-10-03 02:48:25 --> Loader Class Initialized
DEBUG - 2011-10-03 02:48:25 --> Controller Class Initialized
DEBUG - 2011-10-03 02:48:25 --> Model Class Initialized
DEBUG - 2011-10-03 02:48:25 --> Model Class Initialized
DEBUG - 2011-10-03 02:48:25 --> Model Class Initialized
DEBUG - 2011-10-03 02:48:25 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-10-03 02:48:25 --> Database Driver Class Initialized
DEBUG - 2011-10-03 02:48:25 --> File loaded: application/views/table/main.php
DEBUG - 2011-10-03 02:48:25 --> Helper loaded: url_helper
DEBUG - 2011-10-03 02:48:25 --> File loaded: application/views/common/header.php
DEBUG - 2011-10-03 02:48:25 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-10-03 02:48:25 --> File loaded: application/views/common/footer.php
DEBUG - 2011-10-03 02:48:25 --> File loaded: application/views/layout/main.php
DEBUG - 2011-10-03 02:48:25 --> Final output sent to browser
DEBUG - 2011-10-03 02:48:25 --> Total execution time: 0.1450
DEBUG - 2011-10-03 02:48:54 --> Config Class Initialized
DEBUG - 2011-10-03 02:48:54 --> Hooks Class Initialized
DEBUG - 2011-10-03 02:48:54 --> Utf8 Class Initialized
DEBUG - 2011-10-03 02:48:54 --> UTF-8 Support Enabled
DEBUG - 2011-10-03 02:48:54 --> URI Class Initialized
DEBUG - 2011-10-03 02:48:54 --> Router Class Initialized
DEBUG - 2011-10-03 02:48:54 --> Output Class Initialized
DEBUG - 2011-10-03 02:48:54 --> Input Class Initialized
DEBUG - 2011-10-03 02:48:54 --> Global POST and COOKIE data sanitized
DEBUG - 2011-10-03 02:48:54 --> Language Class Initialized
DEBUG - 2011-10-03 02:48:54 --> Loader Class Initialized
DEBUG - 2011-10-03 02:48:54 --> Controller Class Initialized
DEBUG - 2011-10-03 02:48:54 --> Model Class Initialized
DEBUG - 2011-10-03 02:48:54 --> Model Class Initialized
DEBUG - 2011-10-03 02:48:54 --> Model Class Initialized
DEBUG - 2011-10-03 02:48:54 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-10-03 02:48:54 --> Database Driver Class Initialized
DEBUG - 2011-10-03 02:48:55 --> File loaded: application/views/table/main.php
DEBUG - 2011-10-03 02:48:55 --> Helper loaded: url_helper
DEBUG - 2011-10-03 02:48:55 --> File loaded: application/views/common/header.php
DEBUG - 2011-10-03 02:48:55 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-10-03 02:48:55 --> File loaded: application/views/common/footer.php
DEBUG - 2011-10-03 02:48:55 --> File loaded: application/views/layout/main.php
DEBUG - 2011-10-03 02:48:55 --> Final output sent to browser
DEBUG - 2011-10-03 02:48:55 --> Total execution time: 1.3917
DEBUG - 2011-10-03 02:49:03 --> Config Class Initialized
DEBUG - 2011-10-03 02:49:03 --> Hooks Class Initialized
DEBUG - 2011-10-03 02:49:03 --> Utf8 Class Initialized
DEBUG - 2011-10-03 02:49:03 --> UTF-8 Support Enabled
DEBUG - 2011-10-03 02:49:03 --> URI Class Initialized
DEBUG - 2011-10-03 02:49:03 --> Router Class Initialized
DEBUG - 2011-10-03 02:49:03 --> Output Class Initialized
DEBUG - 2011-10-03 02:49:03 --> Input Class Initialized
DEBUG - 2011-10-03 02:49:03 --> Global POST and COOKIE data sanitized
DEBUG - 2011-10-03 02:49:03 --> Language Class Initialized
DEBUG - 2011-10-03 02:49:03 --> Loader Class Initialized
DEBUG - 2011-10-03 02:49:03 --> Controller Class Initialized
DEBUG - 2011-10-03 02:49:03 --> Model Class Initialized
DEBUG - 2011-10-03 02:49:03 --> Model Class Initialized
DEBUG - 2011-10-03 02:49:03 --> Model Class Initialized
DEBUG - 2011-10-03 02:49:03 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-10-03 02:49:03 --> Database Driver Class Initialized
DEBUG - 2011-10-03 02:49:03 --> File loaded: application/views/table/main.php
DEBUG - 2011-10-03 02:49:03 --> Helper loaded: url_helper
DEBUG - 2011-10-03 02:49:03 --> File loaded: application/views/common/header.php
DEBUG - 2011-10-03 02:49:03 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-10-03 02:49:03 --> File loaded: application/views/common/footer.php
DEBUG - 2011-10-03 02:49:03 --> File loaded: application/views/layout/main.php
DEBUG - 2011-10-03 02:49:03 --> Final output sent to browser
DEBUG - 2011-10-03 02:49:03 --> Total execution time: 0.2055
DEBUG - 2011-10-03 02:49:20 --> Config Class Initialized
DEBUG - 2011-10-03 02:49:20 --> Hooks Class Initialized
DEBUG - 2011-10-03 02:49:20 --> Utf8 Class Initialized
DEBUG - 2011-10-03 02:49:20 --> UTF-8 Support Enabled
DEBUG - 2011-10-03 02:49:20 --> URI Class Initialized
DEBUG - 2011-10-03 02:49:20 --> Router Class Initialized
DEBUG - 2011-10-03 02:49:20 --> Output Class Initialized
DEBUG - 2011-10-03 02:49:20 --> Input Class Initialized
DEBUG - 2011-10-03 02:49:20 --> Global POST and COOKIE data sanitized
DEBUG - 2011-10-03 02:49:20 --> Language Class Initialized
DEBUG - 2011-10-03 02:49:20 --> Loader Class Initialized
DEBUG - 2011-10-03 02:49:20 --> Controller Class Initialized
DEBUG - 2011-10-03 02:49:20 --> Model Class Initialized
DEBUG - 2011-10-03 02:49:20 --> Model Class Initialized
DEBUG - 2011-10-03 02:49:20 --> Model Class Initialized
DEBUG - 2011-10-03 02:49:20 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-10-03 02:49:20 --> Database Driver Class Initialized
DEBUG - 2011-10-03 02:49:21 --> File loaded: application/views/table/main.php
DEBUG - 2011-10-03 02:49:21 --> Helper loaded: url_helper
DEBUG - 2011-10-03 02:49:21 --> File loaded: application/views/common/header.php
DEBUG - 2011-10-03 02:49:21 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-10-03 02:49:21 --> File loaded: application/views/common/footer.php
DEBUG - 2011-10-03 02:49:21 --> File loaded: application/views/layout/main.php
DEBUG - 2011-10-03 02:49:21 --> Final output sent to browser
DEBUG - 2011-10-03 02:49:21 --> Total execution time: 0.7504
DEBUG - 2011-10-03 02:49:24 --> Config Class Initialized
DEBUG - 2011-10-03 02:49:24 --> Hooks Class Initialized
DEBUG - 2011-10-03 02:49:24 --> Utf8 Class Initialized
DEBUG - 2011-10-03 02:49:24 --> UTF-8 Support Enabled
DEBUG - 2011-10-03 02:49:24 --> URI Class Initialized
DEBUG - 2011-10-03 02:49:24 --> Router Class Initialized
DEBUG - 2011-10-03 02:49:24 --> Output Class Initialized
DEBUG - 2011-10-03 02:49:24 --> Input Class Initialized
DEBUG - 2011-10-03 02:49:24 --> Global POST and COOKIE data sanitized
DEBUG - 2011-10-03 02:49:24 --> Language Class Initialized
DEBUG - 2011-10-03 02:49:24 --> Loader Class Initialized
DEBUG - 2011-10-03 02:49:24 --> Controller Class Initialized
DEBUG - 2011-10-03 02:49:24 --> Model Class Initialized
DEBUG - 2011-10-03 02:49:24 --> Model Class Initialized
DEBUG - 2011-10-03 02:49:24 --> Model Class Initialized
DEBUG - 2011-10-03 02:49:24 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-10-03 02:49:24 --> Database Driver Class Initialized
DEBUG - 2011-10-03 02:49:24 --> File loaded: application/views/table/main.php
DEBUG - 2011-10-03 02:49:24 --> Helper loaded: url_helper
DEBUG - 2011-10-03 02:49:24 --> File loaded: application/views/common/header.php
DEBUG - 2011-10-03 02:49:24 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-10-03 02:49:24 --> File loaded: application/views/common/footer.php
DEBUG - 2011-10-03 02:49:24 --> File loaded: application/views/layout/main.php
DEBUG - 2011-10-03 02:49:24 --> Final output sent to browser
DEBUG - 2011-10-03 02:49:24 --> Total execution time: 0.1225
DEBUG - 2011-10-03 02:49:31 --> Config Class Initialized
DEBUG - 2011-10-03 02:49:31 --> Hooks Class Initialized
DEBUG - 2011-10-03 02:49:31 --> Utf8 Class Initialized
DEBUG - 2011-10-03 02:49:31 --> UTF-8 Support Enabled
DEBUG - 2011-10-03 02:49:31 --> URI Class Initialized
DEBUG - 2011-10-03 02:49:31 --> Router Class Initialized
DEBUG - 2011-10-03 02:49:31 --> Output Class Initialized
DEBUG - 2011-10-03 02:49:31 --> Input Class Initialized
DEBUG - 2011-10-03 02:49:31 --> Global POST and COOKIE data sanitized
DEBUG - 2011-10-03 02:49:31 --> Language Class Initialized
DEBUG - 2011-10-03 02:49:31 --> Loader Class Initialized
DEBUG - 2011-10-03 02:49:31 --> Controller Class Initialized
DEBUG - 2011-10-03 02:49:31 --> Model Class Initialized
DEBUG - 2011-10-03 02:49:31 --> Model Class Initialized
DEBUG - 2011-10-03 02:49:31 --> Model Class Initialized
DEBUG - 2011-10-03 02:49:31 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-10-03 02:49:31 --> Database Driver Class Initialized
DEBUG - 2011-10-03 02:49:34 --> File loaded: application/views/table/main.php
DEBUG - 2011-10-03 02:49:34 --> Helper loaded: url_helper
DEBUG - 2011-10-03 02:49:34 --> File loaded: application/views/common/header.php
DEBUG - 2011-10-03 02:49:34 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-10-03 02:49:34 --> File loaded: application/views/common/footer.php
DEBUG - 2011-10-03 02:49:34 --> File loaded: application/views/layout/main.php
DEBUG - 2011-10-03 02:49:34 --> Final output sent to browser
DEBUG - 2011-10-03 02:49:34 --> Total execution time: 2.9654
DEBUG - 2011-10-03 02:49:36 --> Config Class Initialized
DEBUG - 2011-10-03 02:49:36 --> Hooks Class Initialized
DEBUG - 2011-10-03 02:49:36 --> Utf8 Class Initialized
DEBUG - 2011-10-03 02:49:36 --> UTF-8 Support Enabled
DEBUG - 2011-10-03 02:49:36 --> URI Class Initialized
DEBUG - 2011-10-03 02:49:36 --> Router Class Initialized
DEBUG - 2011-10-03 02:49:36 --> Output Class Initialized
DEBUG - 2011-10-03 02:49:36 --> Input Class Initialized
DEBUG - 2011-10-03 02:49:36 --> Global POST and COOKIE data sanitized
DEBUG - 2011-10-03 02:49:36 --> Language Class Initialized
DEBUG - 2011-10-03 02:49:36 --> Loader Class Initialized
DEBUG - 2011-10-03 02:49:36 --> Controller Class Initialized
DEBUG - 2011-10-03 02:49:36 --> Model Class Initialized
DEBUG - 2011-10-03 02:49:36 --> Model Class Initialized
DEBUG - 2011-10-03 02:49:36 --> Model Class Initialized
DEBUG - 2011-10-03 02:49:36 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-10-03 02:49:36 --> Database Driver Class Initialized
DEBUG - 2011-10-03 02:49:37 --> File loaded: application/views/table/main.php
DEBUG - 2011-10-03 02:49:37 --> Helper loaded: url_helper
DEBUG - 2011-10-03 02:49:37 --> File loaded: application/views/common/header.php
DEBUG - 2011-10-03 02:49:37 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-10-03 02:49:37 --> File loaded: application/views/common/footer.php
DEBUG - 2011-10-03 02:49:37 --> File loaded: application/views/layout/main.php
DEBUG - 2011-10-03 02:49:37 --> Final output sent to browser
DEBUG - 2011-10-03 02:49:37 --> Total execution time: 0.1437
DEBUG - 2011-10-03 02:49:47 --> Config Class Initialized
DEBUG - 2011-10-03 02:49:47 --> Hooks Class Initialized
DEBUG - 2011-10-03 02:49:47 --> Utf8 Class Initialized
DEBUG - 2011-10-03 02:49:47 --> UTF-8 Support Enabled
DEBUG - 2011-10-03 02:49:47 --> URI Class Initialized
DEBUG - 2011-10-03 02:49:47 --> Router Class Initialized
DEBUG - 2011-10-03 02:49:47 --> Output Class Initialized
DEBUG - 2011-10-03 02:49:47 --> Input Class Initialized
DEBUG - 2011-10-03 02:49:47 --> Global POST and COOKIE data sanitized
DEBUG - 2011-10-03 02:49:47 --> Language Class Initialized
DEBUG - 2011-10-03 02:49:47 --> Loader Class Initialized
DEBUG - 2011-10-03 02:49:47 --> Controller Class Initialized
DEBUG - 2011-10-03 02:49:47 --> Model Class Initialized
DEBUG - 2011-10-03 02:49:47 --> Model Class Initialized
DEBUG - 2011-10-03 02:49:47 --> Model Class Initialized
DEBUG - 2011-10-03 02:49:47 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-10-03 02:49:47 --> Database Driver Class Initialized
DEBUG - 2011-10-03 02:49:49 --> File loaded: application/views/table/main.php
DEBUG - 2011-10-03 02:49:49 --> Helper loaded: url_helper
DEBUG - 2011-10-03 02:49:49 --> File loaded: application/views/common/header.php
DEBUG - 2011-10-03 02:49:49 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-10-03 02:49:49 --> File loaded: application/views/common/footer.php
DEBUG - 2011-10-03 02:49:49 --> File loaded: application/views/layout/main.php
DEBUG - 2011-10-03 02:49:49 --> Final output sent to browser
DEBUG - 2011-10-03 02:49:49 --> Total execution time: 1.3049
DEBUG - 2011-10-03 02:49:50 --> Config Class Initialized
DEBUG - 2011-10-03 02:49:50 --> Hooks Class Initialized
DEBUG - 2011-10-03 02:49:50 --> Utf8 Class Initialized
DEBUG - 2011-10-03 02:49:50 --> UTF-8 Support Enabled
DEBUG - 2011-10-03 02:49:50 --> URI Class Initialized
DEBUG - 2011-10-03 02:49:50 --> Router Class Initialized
DEBUG - 2011-10-03 02:49:50 --> Output Class Initialized
DEBUG - 2011-10-03 02:49:50 --> Input Class Initialized
DEBUG - 2011-10-03 02:49:50 --> Global POST and COOKIE data sanitized
DEBUG - 2011-10-03 02:49:50 --> Language Class Initialized
DEBUG - 2011-10-03 02:49:50 --> Loader Class Initialized
DEBUG - 2011-10-03 02:49:50 --> Controller Class Initialized
DEBUG - 2011-10-03 02:49:50 --> Model Class Initialized
DEBUG - 2011-10-03 02:49:50 --> Model Class Initialized
DEBUG - 2011-10-03 02:49:50 --> Model Class Initialized
DEBUG - 2011-10-03 02:49:50 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-10-03 02:49:50 --> Database Driver Class Initialized
DEBUG - 2011-10-03 02:49:50 --> File loaded: application/views/table/main.php
DEBUG - 2011-10-03 02:49:50 --> Helper loaded: url_helper
DEBUG - 2011-10-03 02:49:50 --> File loaded: application/views/common/header.php
DEBUG - 2011-10-03 02:49:50 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-10-03 02:49:50 --> File loaded: application/views/common/footer.php
DEBUG - 2011-10-03 02:49:50 --> File loaded: application/views/layout/main.php
DEBUG - 2011-10-03 02:49:50 --> Final output sent to browser
DEBUG - 2011-10-03 02:49:50 --> Total execution time: 0.1314
DEBUG - 2011-10-03 02:52:28 --> Config Class Initialized
DEBUG - 2011-10-03 02:52:28 --> Hooks Class Initialized
DEBUG - 2011-10-03 02:52:28 --> Utf8 Class Initialized
DEBUG - 2011-10-03 02:52:28 --> UTF-8 Support Enabled
DEBUG - 2011-10-03 02:52:28 --> URI Class Initialized
DEBUG - 2011-10-03 02:52:28 --> Router Class Initialized
DEBUG - 2011-10-03 02:52:28 --> Output Class Initialized
DEBUG - 2011-10-03 02:52:28 --> Input Class Initialized
DEBUG - 2011-10-03 02:52:28 --> Global POST and COOKIE data sanitized
DEBUG - 2011-10-03 02:52:28 --> Language Class Initialized
DEBUG - 2011-10-03 02:52:28 --> Loader Class Initialized
DEBUG - 2011-10-03 02:52:28 --> Controller Class Initialized
DEBUG - 2011-10-03 02:52:28 --> Model Class Initialized
DEBUG - 2011-10-03 02:52:28 --> Model Class Initialized
DEBUG - 2011-10-03 02:52:28 --> Model Class Initialized
DEBUG - 2011-10-03 02:52:28 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-10-03 02:52:28 --> Database Driver Class Initialized
DEBUG - 2011-10-03 02:52:28 --> File loaded: application/views/table/main.php
DEBUG - 2011-10-03 02:52:28 --> Helper loaded: url_helper
DEBUG - 2011-10-03 02:52:28 --> File loaded: application/views/common/header.php
DEBUG - 2011-10-03 02:52:28 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-10-03 02:52:28 --> File loaded: application/views/common/footer.php
DEBUG - 2011-10-03 02:52:28 --> File loaded: application/views/layout/main.php
DEBUG - 2011-10-03 02:52:28 --> Final output sent to browser
DEBUG - 2011-10-03 02:52:28 --> Total execution time: 0.2171
DEBUG - 2011-10-03 02:52:31 --> Config Class Initialized
DEBUG - 2011-10-03 02:52:31 --> Hooks Class Initialized
DEBUG - 2011-10-03 02:52:31 --> Utf8 Class Initialized
DEBUG - 2011-10-03 02:52:31 --> UTF-8 Support Enabled
DEBUG - 2011-10-03 02:52:31 --> URI Class Initialized
DEBUG - 2011-10-03 02:52:31 --> Router Class Initialized
ERROR - 2011-10-03 02:52:31 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-10-03 02:52:32 --> Config Class Initialized
DEBUG - 2011-10-03 02:52:32 --> Hooks Class Initialized
DEBUG - 2011-10-03 02:52:32 --> Utf8 Class Initialized
DEBUG - 2011-10-03 02:52:32 --> UTF-8 Support Enabled
DEBUG - 2011-10-03 02:52:32 --> URI Class Initialized
DEBUG - 2011-10-03 02:52:32 --> Router Class Initialized
ERROR - 2011-10-03 02:52:32 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-10-03 02:52:32 --> Config Class Initialized
DEBUG - 2011-10-03 02:52:32 --> Hooks Class Initialized
DEBUG - 2011-10-03 02:52:32 --> Utf8 Class Initialized
DEBUG - 2011-10-03 02:52:32 --> UTF-8 Support Enabled
DEBUG - 2011-10-03 02:52:32 --> URI Class Initialized
DEBUG - 2011-10-03 02:52:32 --> Router Class Initialized
ERROR - 2011-10-03 02:52:32 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-10-03 02:52:38 --> Config Class Initialized
DEBUG - 2011-10-03 02:52:38 --> Hooks Class Initialized
DEBUG - 2011-10-03 02:52:38 --> Utf8 Class Initialized
DEBUG - 2011-10-03 02:52:38 --> UTF-8 Support Enabled
DEBUG - 2011-10-03 02:52:38 --> URI Class Initialized
DEBUG - 2011-10-03 02:52:38 --> Router Class Initialized
DEBUG - 2011-10-03 02:52:38 --> Output Class Initialized
DEBUG - 2011-10-03 02:52:38 --> Input Class Initialized
DEBUG - 2011-10-03 02:52:38 --> Global POST and COOKIE data sanitized
DEBUG - 2011-10-03 02:52:38 --> Language Class Initialized
DEBUG - 2011-10-03 02:52:38 --> Loader Class Initialized
DEBUG - 2011-10-03 02:52:38 --> Controller Class Initialized
DEBUG - 2011-10-03 02:52:38 --> Model Class Initialized
DEBUG - 2011-10-03 02:52:38 --> Model Class Initialized
DEBUG - 2011-10-03 02:52:38 --> Model Class Initialized
DEBUG - 2011-10-03 02:52:38 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-10-03 02:52:38 --> Database Driver Class Initialized
DEBUG - 2011-10-03 02:52:38 --> File loaded: application/views/table/main.php
DEBUG - 2011-10-03 02:52:38 --> Helper loaded: url_helper
DEBUG - 2011-10-03 02:52:38 --> File loaded: application/views/common/header.php
DEBUG - 2011-10-03 02:52:38 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-10-03 02:52:38 --> File loaded: application/views/common/footer.php
DEBUG - 2011-10-03 02:52:38 --> File loaded: application/views/layout/main.php
DEBUG - 2011-10-03 02:52:38 --> Final output sent to browser
DEBUG - 2011-10-03 02:52:38 --> Total execution time: 0.0811
DEBUG - 2011-10-03 02:52:55 --> Config Class Initialized
DEBUG - 2011-10-03 02:52:55 --> Hooks Class Initialized
DEBUG - 2011-10-03 02:52:55 --> Utf8 Class Initialized
DEBUG - 2011-10-03 02:52:55 --> UTF-8 Support Enabled
DEBUG - 2011-10-03 02:52:55 --> URI Class Initialized
DEBUG - 2011-10-03 02:52:55 --> Router Class Initialized
DEBUG - 2011-10-03 02:52:55 --> Output Class Initialized
DEBUG - 2011-10-03 02:52:55 --> Input Class Initialized
DEBUG - 2011-10-03 02:52:55 --> Global POST and COOKIE data sanitized
DEBUG - 2011-10-03 02:52:55 --> Language Class Initialized
DEBUG - 2011-10-03 02:52:55 --> Loader Class Initialized
DEBUG - 2011-10-03 02:52:55 --> Controller Class Initialized
DEBUG - 2011-10-03 02:52:55 --> Model Class Initialized
DEBUG - 2011-10-03 02:52:55 --> Model Class Initialized
DEBUG - 2011-10-03 02:52:55 --> Model Class Initialized
DEBUG - 2011-10-03 02:52:55 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-10-03 02:52:55 --> Database Driver Class Initialized
DEBUG - 2011-10-03 02:52:56 --> File loaded: application/views/table/main.php
DEBUG - 2011-10-03 02:52:56 --> Helper loaded: url_helper
DEBUG - 2011-10-03 02:52:56 --> File loaded: application/views/common/header.php
DEBUG - 2011-10-03 02:52:56 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-10-03 02:52:56 --> File loaded: application/views/common/footer.php
DEBUG - 2011-10-03 02:52:56 --> File loaded: application/views/layout/main.php
DEBUG - 2011-10-03 02:52:56 --> Final output sent to browser
DEBUG - 2011-10-03 02:52:56 --> Total execution time: 1.2673
DEBUG - 2011-10-03 02:53:01 --> Config Class Initialized
DEBUG - 2011-10-03 02:53:01 --> Hooks Class Initialized
DEBUG - 2011-10-03 02:53:01 --> Utf8 Class Initialized
DEBUG - 2011-10-03 02:53:01 --> UTF-8 Support Enabled
DEBUG - 2011-10-03 02:53:01 --> URI Class Initialized
DEBUG - 2011-10-03 02:53:01 --> Router Class Initialized
DEBUG - 2011-10-03 02:53:01 --> Output Class Initialized
DEBUG - 2011-10-03 02:53:01 --> Input Class Initialized
DEBUG - 2011-10-03 02:53:01 --> Global POST and COOKIE data sanitized
DEBUG - 2011-10-03 02:53:01 --> Language Class Initialized
DEBUG - 2011-10-03 02:53:01 --> Loader Class Initialized
DEBUG - 2011-10-03 02:53:01 --> Controller Class Initialized
DEBUG - 2011-10-03 02:53:01 --> Model Class Initialized
DEBUG - 2011-10-03 02:53:01 --> Model Class Initialized
DEBUG - 2011-10-03 02:53:01 --> Model Class Initialized
DEBUG - 2011-10-03 02:53:01 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-10-03 02:53:01 --> Database Driver Class Initialized
DEBUG - 2011-10-03 02:53:01 --> File loaded: application/views/table/main.php
DEBUG - 2011-10-03 02:53:01 --> Helper loaded: url_helper
DEBUG - 2011-10-03 02:53:01 --> File loaded: application/views/common/header.php
DEBUG - 2011-10-03 02:53:01 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-10-03 02:53:01 --> File loaded: application/views/common/footer.php
DEBUG - 2011-10-03 02:53:01 --> File loaded: application/views/layout/main.php
DEBUG - 2011-10-03 02:53:01 --> Final output sent to browser
DEBUG - 2011-10-03 02:53:01 --> Total execution time: 0.0956
DEBUG - 2011-10-03 03:11:41 --> Config Class Initialized
DEBUG - 2011-10-03 03:11:41 --> Hooks Class Initialized
DEBUG - 2011-10-03 03:11:41 --> Utf8 Class Initialized
DEBUG - 2011-10-03 03:11:41 --> UTF-8 Support Enabled
DEBUG - 2011-10-03 03:11:41 --> URI Class Initialized
DEBUG - 2011-10-03 03:11:41 --> Router Class Initialized
DEBUG - 2011-10-03 03:11:41 --> Output Class Initialized
DEBUG - 2011-10-03 03:11:41 --> Input Class Initialized
DEBUG - 2011-10-03 03:11:41 --> Global POST and COOKIE data sanitized
DEBUG - 2011-10-03 03:11:41 --> Language Class Initialized
DEBUG - 2011-10-03 03:11:41 --> Loader Class Initialized
DEBUG - 2011-10-03 03:11:41 --> Controller Class Initialized
ERROR - 2011-10-03 03:11:42 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-10-03 03:11:42 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-10-03 03:11:42 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-10-03 03:11:42 --> Model Class Initialized
DEBUG - 2011-10-03 03:11:42 --> Model Class Initialized
DEBUG - 2011-10-03 03:11:42 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-10-03 03:11:42 --> Database Driver Class Initialized
DEBUG - 2011-10-03 03:11:46 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-10-03 03:11:46 --> Helper loaded: url_helper
DEBUG - 2011-10-03 03:11:46 --> File loaded: application/views/common/header.php
DEBUG - 2011-10-03 03:11:46 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-10-03 03:11:46 --> File loaded: application/views/common/footer.php
DEBUG - 2011-10-03 03:11:46 --> File loaded: application/views/layout/main.php
DEBUG - 2011-10-03 03:11:46 --> Final output sent to browser
DEBUG - 2011-10-03 03:11:46 --> Total execution time: 4.8757
DEBUG - 2011-10-03 03:11:48 --> Config Class Initialized
DEBUG - 2011-10-03 03:11:48 --> Hooks Class Initialized
DEBUG - 2011-10-03 03:11:48 --> Utf8 Class Initialized
DEBUG - 2011-10-03 03:11:48 --> UTF-8 Support Enabled
DEBUG - 2011-10-03 03:11:48 --> URI Class Initialized
DEBUG - 2011-10-03 03:11:48 --> Router Class Initialized
DEBUG - 2011-10-03 03:11:48 --> Output Class Initialized
DEBUG - 2011-10-03 03:11:48 --> Input Class Initialized
DEBUG - 2011-10-03 03:11:48 --> Global POST and COOKIE data sanitized
DEBUG - 2011-10-03 03:11:48 --> Language Class Initialized
DEBUG - 2011-10-03 03:11:48 --> Loader Class Initialized
DEBUG - 2011-10-03 03:11:48 --> Controller Class Initialized
DEBUG - 2011-10-03 03:11:48 --> Model Class Initialized
DEBUG - 2011-10-03 03:11:48 --> Model Class Initialized
DEBUG - 2011-10-03 03:11:48 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-10-03 03:11:48 --> Database Driver Class Initialized
DEBUG - 2011-10-03 03:11:50 --> Final output sent to browser
DEBUG - 2011-10-03 03:11:50 --> Total execution time: 2.7688
DEBUG - 2011-10-03 03:11:52 --> Config Class Initialized
DEBUG - 2011-10-03 03:11:52 --> Hooks Class Initialized
DEBUG - 2011-10-03 03:11:52 --> Utf8 Class Initialized
DEBUG - 2011-10-03 03:11:52 --> UTF-8 Support Enabled
DEBUG - 2011-10-03 03:11:52 --> URI Class Initialized
DEBUG - 2011-10-03 03:11:52 --> Router Class Initialized
ERROR - 2011-10-03 03:11:52 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-10-03 03:12:29 --> Config Class Initialized
DEBUG - 2011-10-03 03:12:29 --> Hooks Class Initialized
DEBUG - 2011-10-03 03:12:29 --> Utf8 Class Initialized
DEBUG - 2011-10-03 03:12:29 --> UTF-8 Support Enabled
DEBUG - 2011-10-03 03:12:29 --> URI Class Initialized
DEBUG - 2011-10-03 03:12:29 --> Router Class Initialized
DEBUG - 2011-10-03 03:12:29 --> Output Class Initialized
DEBUG - 2011-10-03 03:12:29 --> Input Class Initialized
DEBUG - 2011-10-03 03:12:29 --> Global POST and COOKIE data sanitized
DEBUG - 2011-10-03 03:12:29 --> Language Class Initialized
DEBUG - 2011-10-03 03:12:29 --> Loader Class Initialized
DEBUG - 2011-10-03 03:12:29 --> Controller Class Initialized
ERROR - 2011-10-03 03:12:29 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-10-03 03:12:29 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-10-03 03:12:29 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-10-03 03:12:29 --> Model Class Initialized
DEBUG - 2011-10-03 03:12:29 --> Model Class Initialized
DEBUG - 2011-10-03 03:12:29 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-10-03 03:12:29 --> Database Driver Class Initialized
DEBUG - 2011-10-03 03:12:29 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-10-03 03:12:29 --> Helper loaded: url_helper
DEBUG - 2011-10-03 03:12:29 --> File loaded: application/views/common/header.php
DEBUG - 2011-10-03 03:12:29 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-10-03 03:12:29 --> File loaded: application/views/common/footer.php
DEBUG - 2011-10-03 03:12:29 --> File loaded: application/views/layout/main.php
DEBUG - 2011-10-03 03:12:29 --> Final output sent to browser
DEBUG - 2011-10-03 03:12:29 --> Total execution time: 0.2342
DEBUG - 2011-10-03 03:12:30 --> Config Class Initialized
DEBUG - 2011-10-03 03:12:30 --> Hooks Class Initialized
DEBUG - 2011-10-03 03:12:30 --> Utf8 Class Initialized
DEBUG - 2011-10-03 03:12:30 --> UTF-8 Support Enabled
DEBUG - 2011-10-03 03:12:30 --> URI Class Initialized
DEBUG - 2011-10-03 03:12:30 --> Router Class Initialized
DEBUG - 2011-10-03 03:12:30 --> Output Class Initialized
DEBUG - 2011-10-03 03:12:30 --> Input Class Initialized
DEBUG - 2011-10-03 03:12:30 --> Global POST and COOKIE data sanitized
DEBUG - 2011-10-03 03:12:30 --> Language Class Initialized
DEBUG - 2011-10-03 03:12:30 --> Loader Class Initialized
DEBUG - 2011-10-03 03:12:30 --> Controller Class Initialized
DEBUG - 2011-10-03 03:12:30 --> Model Class Initialized
DEBUG - 2011-10-03 03:12:30 --> Model Class Initialized
DEBUG - 2011-10-03 03:12:30 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-10-03 03:12:30 --> Database Driver Class Initialized
DEBUG - 2011-10-03 03:12:31 --> Final output sent to browser
DEBUG - 2011-10-03 03:12:31 --> Total execution time: 0.9206
DEBUG - 2011-10-03 03:13:19 --> Config Class Initialized
DEBUG - 2011-10-03 03:13:19 --> Hooks Class Initialized
DEBUG - 2011-10-03 03:13:19 --> Utf8 Class Initialized
DEBUG - 2011-10-03 03:13:19 --> UTF-8 Support Enabled
DEBUG - 2011-10-03 03:13:19 --> URI Class Initialized
DEBUG - 2011-10-03 03:13:19 --> Router Class Initialized
DEBUG - 2011-10-03 03:13:19 --> Output Class Initialized
DEBUG - 2011-10-03 03:13:19 --> Input Class Initialized
DEBUG - 2011-10-03 03:13:19 --> Global POST and COOKIE data sanitized
DEBUG - 2011-10-03 03:13:19 --> Language Class Initialized
DEBUG - 2011-10-03 03:13:19 --> Loader Class Initialized
DEBUG - 2011-10-03 03:13:19 --> Controller Class Initialized
ERROR - 2011-10-03 03:13:19 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-10-03 03:13:19 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-10-03 03:13:19 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-10-03 03:13:19 --> Model Class Initialized
DEBUG - 2011-10-03 03:13:19 --> Model Class Initialized
DEBUG - 2011-10-03 03:13:19 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-10-03 03:13:19 --> Database Driver Class Initialized
DEBUG - 2011-10-03 03:13:19 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-10-03 03:13:19 --> Helper loaded: url_helper
DEBUG - 2011-10-03 03:13:19 --> File loaded: application/views/common/header.php
DEBUG - 2011-10-03 03:13:19 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-10-03 03:13:19 --> File loaded: application/views/common/footer.php
DEBUG - 2011-10-03 03:13:19 --> File loaded: application/views/layout/main.php
DEBUG - 2011-10-03 03:13:19 --> Final output sent to browser
DEBUG - 2011-10-03 03:13:19 --> Total execution time: 0.0446
DEBUG - 2011-10-03 03:13:30 --> Config Class Initialized
DEBUG - 2011-10-03 03:13:30 --> Hooks Class Initialized
DEBUG - 2011-10-03 03:13:30 --> Utf8 Class Initialized
DEBUG - 2011-10-03 03:13:30 --> UTF-8 Support Enabled
DEBUG - 2011-10-03 03:13:30 --> URI Class Initialized
DEBUG - 2011-10-03 03:13:30 --> Router Class Initialized
DEBUG - 2011-10-03 03:13:30 --> Output Class Initialized
DEBUG - 2011-10-03 03:13:30 --> Input Class Initialized
DEBUG - 2011-10-03 03:13:30 --> Global POST and COOKIE data sanitized
DEBUG - 2011-10-03 03:13:30 --> Language Class Initialized
DEBUG - 2011-10-03 03:13:30 --> Loader Class Initialized
DEBUG - 2011-10-03 03:13:30 --> Controller Class Initialized
DEBUG - 2011-10-03 03:13:30 --> Model Class Initialized
DEBUG - 2011-10-03 03:13:30 --> Model Class Initialized
DEBUG - 2011-10-03 03:13:30 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-10-03 03:13:30 --> Database Driver Class Initialized
DEBUG - 2011-10-03 03:13:31 --> Final output sent to browser
DEBUG - 2011-10-03 03:13:31 --> Total execution time: 0.8161
DEBUG - 2011-10-03 04:22:46 --> Config Class Initialized
DEBUG - 2011-10-03 04:22:46 --> Hooks Class Initialized
DEBUG - 2011-10-03 04:22:46 --> Utf8 Class Initialized
DEBUG - 2011-10-03 04:22:46 --> UTF-8 Support Enabled
DEBUG - 2011-10-03 04:22:46 --> URI Class Initialized
DEBUG - 2011-10-03 04:22:46 --> Router Class Initialized
DEBUG - 2011-10-03 04:22:46 --> Output Class Initialized
DEBUG - 2011-10-03 04:22:46 --> Input Class Initialized
DEBUG - 2011-10-03 04:22:46 --> Global POST and COOKIE data sanitized
DEBUG - 2011-10-03 04:22:46 --> Language Class Initialized
DEBUG - 2011-10-03 04:22:46 --> Loader Class Initialized
DEBUG - 2011-10-03 04:22:46 --> Controller Class Initialized
ERROR - 2011-10-03 04:22:46 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-10-03 04:22:46 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-10-03 04:22:46 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-10-03 04:22:46 --> Model Class Initialized
DEBUG - 2011-10-03 04:22:46 --> Model Class Initialized
DEBUG - 2011-10-03 04:22:46 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-10-03 04:22:46 --> Database Driver Class Initialized
DEBUG - 2011-10-03 04:22:47 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-10-03 04:22:47 --> Helper loaded: url_helper
DEBUG - 2011-10-03 04:22:47 --> File loaded: application/views/common/header.php
DEBUG - 2011-10-03 04:22:47 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-10-03 04:22:47 --> File loaded: application/views/common/footer.php
DEBUG - 2011-10-03 04:22:47 --> File loaded: application/views/layout/main.php
DEBUG - 2011-10-03 04:22:47 --> Final output sent to browser
DEBUG - 2011-10-03 04:22:47 --> Total execution time: 1.1982
DEBUG - 2011-10-03 04:22:48 --> Config Class Initialized
DEBUG - 2011-10-03 04:22:48 --> Hooks Class Initialized
DEBUG - 2011-10-03 04:22:48 --> Utf8 Class Initialized
DEBUG - 2011-10-03 04:22:48 --> UTF-8 Support Enabled
DEBUG - 2011-10-03 04:22:48 --> URI Class Initialized
DEBUG - 2011-10-03 04:22:48 --> Router Class Initialized
DEBUG - 2011-10-03 04:22:48 --> Output Class Initialized
DEBUG - 2011-10-03 04:22:48 --> Input Class Initialized
DEBUG - 2011-10-03 04:22:48 --> Global POST and COOKIE data sanitized
DEBUG - 2011-10-03 04:22:48 --> Language Class Initialized
DEBUG - 2011-10-03 04:22:48 --> Loader Class Initialized
DEBUG - 2011-10-03 04:22:48 --> Controller Class Initialized
DEBUG - 2011-10-03 04:22:48 --> Model Class Initialized
DEBUG - 2011-10-03 04:22:48 --> Model Class Initialized
DEBUG - 2011-10-03 04:22:48 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-10-03 04:22:48 --> Database Driver Class Initialized
DEBUG - 2011-10-03 04:22:49 --> Final output sent to browser
DEBUG - 2011-10-03 04:22:49 --> Total execution time: 1.3398
DEBUG - 2011-10-03 04:22:51 --> Config Class Initialized
DEBUG - 2011-10-03 04:22:51 --> Hooks Class Initialized
DEBUG - 2011-10-03 04:22:51 --> Utf8 Class Initialized
DEBUG - 2011-10-03 04:22:51 --> UTF-8 Support Enabled
DEBUG - 2011-10-03 04:22:51 --> URI Class Initialized
DEBUG - 2011-10-03 04:22:51 --> Router Class Initialized
ERROR - 2011-10-03 04:22:51 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-10-03 04:22:52 --> Config Class Initialized
DEBUG - 2011-10-03 04:22:52 --> Hooks Class Initialized
DEBUG - 2011-10-03 04:22:52 --> Utf8 Class Initialized
DEBUG - 2011-10-03 04:22:52 --> UTF-8 Support Enabled
DEBUG - 2011-10-03 04:22:52 --> URI Class Initialized
DEBUG - 2011-10-03 04:22:52 --> Router Class Initialized
ERROR - 2011-10-03 04:22:52 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-10-03 04:23:08 --> Config Class Initialized
DEBUG - 2011-10-03 04:23:08 --> Hooks Class Initialized
DEBUG - 2011-10-03 04:23:08 --> Utf8 Class Initialized
DEBUG - 2011-10-03 04:23:08 --> UTF-8 Support Enabled
DEBUG - 2011-10-03 04:23:08 --> URI Class Initialized
DEBUG - 2011-10-03 04:23:08 --> Router Class Initialized
DEBUG - 2011-10-03 04:23:08 --> Output Class Initialized
DEBUG - 2011-10-03 04:23:08 --> Input Class Initialized
DEBUG - 2011-10-03 04:23:08 --> Global POST and COOKIE data sanitized
DEBUG - 2011-10-03 04:23:08 --> Language Class Initialized
DEBUG - 2011-10-03 04:23:08 --> Loader Class Initialized
DEBUG - 2011-10-03 04:23:08 --> Controller Class Initialized
ERROR - 2011-10-03 04:23:08 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-10-03 04:23:08 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-10-03 04:23:08 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-10-03 04:23:08 --> Model Class Initialized
DEBUG - 2011-10-03 04:23:08 --> Model Class Initialized
DEBUG - 2011-10-03 04:23:08 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-10-03 04:23:08 --> Database Driver Class Initialized
DEBUG - 2011-10-03 04:23:08 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-10-03 04:23:08 --> Helper loaded: url_helper
DEBUG - 2011-10-03 04:23:08 --> File loaded: application/views/common/header.php
DEBUG - 2011-10-03 04:23:08 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-10-03 04:23:08 --> File loaded: application/views/common/footer.php
DEBUG - 2011-10-03 04:23:08 --> File loaded: application/views/layout/main.php
DEBUG - 2011-10-03 04:23:08 --> Final output sent to browser
DEBUG - 2011-10-03 04:23:08 --> Total execution time: 0.0333
DEBUG - 2011-10-03 04:23:18 --> Config Class Initialized
DEBUG - 2011-10-03 04:23:18 --> Hooks Class Initialized
DEBUG - 2011-10-03 04:23:18 --> Utf8 Class Initialized
DEBUG - 2011-10-03 04:23:18 --> UTF-8 Support Enabled
DEBUG - 2011-10-03 04:23:18 --> URI Class Initialized
DEBUG - 2011-10-03 04:23:18 --> Router Class Initialized
DEBUG - 2011-10-03 04:23:18 --> Output Class Initialized
DEBUG - 2011-10-03 04:23:18 --> Input Class Initialized
DEBUG - 2011-10-03 04:23:18 --> Global POST and COOKIE data sanitized
DEBUG - 2011-10-03 04:23:18 --> Language Class Initialized
DEBUG - 2011-10-03 04:23:18 --> Loader Class Initialized
DEBUG - 2011-10-03 04:23:18 --> Controller Class Initialized
DEBUG - 2011-10-03 04:23:18 --> Model Class Initialized
DEBUG - 2011-10-03 04:23:18 --> Model Class Initialized
DEBUG - 2011-10-03 04:23:18 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-10-03 04:23:18 --> Database Driver Class Initialized
DEBUG - 2011-10-03 04:23:18 --> Config Class Initialized
DEBUG - 2011-10-03 04:23:18 --> Hooks Class Initialized
DEBUG - 2011-10-03 04:23:18 --> Utf8 Class Initialized
DEBUG - 2011-10-03 04:23:18 --> UTF-8 Support Enabled
DEBUG - 2011-10-03 04:23:18 --> URI Class Initialized
DEBUG - 2011-10-03 04:23:18 --> Router Class Initialized
DEBUG - 2011-10-03 04:23:18 --> Output Class Initialized
DEBUG - 2011-10-03 04:23:18 --> Input Class Initialized
DEBUG - 2011-10-03 04:23:18 --> Global POST and COOKIE data sanitized
DEBUG - 2011-10-03 04:23:18 --> Language Class Initialized
DEBUG - 2011-10-03 04:23:18 --> Loader Class Initialized
DEBUG - 2011-10-03 04:23:18 --> Controller Class Initialized
ERROR - 2011-10-03 04:23:18 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-10-03 04:23:18 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-10-03 04:23:18 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-10-03 04:23:18 --> Model Class Initialized
DEBUG - 2011-10-03 04:23:18 --> Model Class Initialized
DEBUG - 2011-10-03 04:23:18 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-10-03 04:23:18 --> Database Driver Class Initialized
DEBUG - 2011-10-03 04:23:18 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-10-03 04:23:18 --> Helper loaded: url_helper
DEBUG - 2011-10-03 04:23:18 --> File loaded: application/views/common/header.php
DEBUG - 2011-10-03 04:23:18 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-10-03 04:23:18 --> File loaded: application/views/common/footer.php
DEBUG - 2011-10-03 04:23:18 --> File loaded: application/views/layout/main.php
DEBUG - 2011-10-03 04:23:18 --> Final output sent to browser
DEBUG - 2011-10-03 04:23:18 --> Total execution time: 0.0407
DEBUG - 2011-10-03 04:23:18 --> Final output sent to browser
DEBUG - 2011-10-03 04:23:18 --> Total execution time: 0.5688
DEBUG - 2011-10-03 04:23:20 --> Config Class Initialized
DEBUG - 2011-10-03 04:23:20 --> Hooks Class Initialized
DEBUG - 2011-10-03 04:23:20 --> Utf8 Class Initialized
DEBUG - 2011-10-03 04:23:20 --> UTF-8 Support Enabled
DEBUG - 2011-10-03 04:23:20 --> URI Class Initialized
DEBUG - 2011-10-03 04:23:20 --> Router Class Initialized
DEBUG - 2011-10-03 04:23:20 --> Output Class Initialized
DEBUG - 2011-10-03 04:23:20 --> Input Class Initialized
DEBUG - 2011-10-03 04:23:20 --> Global POST and COOKIE data sanitized
DEBUG - 2011-10-03 04:23:20 --> Language Class Initialized
DEBUG - 2011-10-03 04:23:20 --> Loader Class Initialized
DEBUG - 2011-10-03 04:23:20 --> Controller Class Initialized
DEBUG - 2011-10-03 04:23:20 --> Model Class Initialized
DEBUG - 2011-10-03 04:23:20 --> Model Class Initialized
DEBUG - 2011-10-03 04:23:20 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-10-03 04:23:20 --> Database Driver Class Initialized
DEBUG - 2011-10-03 04:23:20 --> Final output sent to browser
DEBUG - 2011-10-03 04:23:20 --> Total execution time: 0.3233
DEBUG - 2011-10-03 04:23:25 --> Config Class Initialized
DEBUG - 2011-10-03 04:23:25 --> Hooks Class Initialized
DEBUG - 2011-10-03 04:23:25 --> Utf8 Class Initialized
DEBUG - 2011-10-03 04:23:25 --> UTF-8 Support Enabled
DEBUG - 2011-10-03 04:23:25 --> URI Class Initialized
DEBUG - 2011-10-03 04:23:25 --> Router Class Initialized
ERROR - 2011-10-03 04:23:25 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-10-03 04:24:44 --> Config Class Initialized
DEBUG - 2011-10-03 04:24:44 --> Hooks Class Initialized
DEBUG - 2011-10-03 04:24:44 --> Utf8 Class Initialized
DEBUG - 2011-10-03 04:24:44 --> UTF-8 Support Enabled
DEBUG - 2011-10-03 04:24:44 --> URI Class Initialized
DEBUG - 2011-10-03 04:24:44 --> Router Class Initialized
DEBUG - 2011-10-03 04:24:44 --> Output Class Initialized
DEBUG - 2011-10-03 04:24:44 --> Input Class Initialized
DEBUG - 2011-10-03 04:24:44 --> Global POST and COOKIE data sanitized
DEBUG - 2011-10-03 04:24:44 --> Language Class Initialized
DEBUG - 2011-10-03 04:24:44 --> Loader Class Initialized
DEBUG - 2011-10-03 04:24:44 --> Controller Class Initialized
ERROR - 2011-10-03 04:24:44 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-10-03 04:24:44 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-10-03 04:24:44 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-10-03 04:24:44 --> Model Class Initialized
DEBUG - 2011-10-03 04:24:44 --> Model Class Initialized
DEBUG - 2011-10-03 04:24:44 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-10-03 04:24:44 --> Database Driver Class Initialized
DEBUG - 2011-10-03 04:24:44 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-10-03 04:24:44 --> Helper loaded: url_helper
DEBUG - 2011-10-03 04:24:44 --> File loaded: application/views/common/header.php
DEBUG - 2011-10-03 04:24:44 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-10-03 04:24:44 --> File loaded: application/views/common/footer.php
DEBUG - 2011-10-03 04:24:44 --> File loaded: application/views/layout/main.php
DEBUG - 2011-10-03 04:24:44 --> Final output sent to browser
DEBUG - 2011-10-03 04:24:44 --> Total execution time: 0.0465
DEBUG - 2011-10-03 04:24:45 --> Config Class Initialized
DEBUG - 2011-10-03 04:24:45 --> Hooks Class Initialized
DEBUG - 2011-10-03 04:24:45 --> Utf8 Class Initialized
DEBUG - 2011-10-03 04:24:45 --> UTF-8 Support Enabled
DEBUG - 2011-10-03 04:24:45 --> URI Class Initialized
DEBUG - 2011-10-03 04:24:45 --> Router Class Initialized
DEBUG - 2011-10-03 04:24:45 --> Output Class Initialized
DEBUG - 2011-10-03 04:24:45 --> Input Class Initialized
DEBUG - 2011-10-03 04:24:45 --> Global POST and COOKIE data sanitized
DEBUG - 2011-10-03 04:24:45 --> Language Class Initialized
DEBUG - 2011-10-03 04:24:45 --> Loader Class Initialized
DEBUG - 2011-10-03 04:24:45 --> Controller Class Initialized
DEBUG - 2011-10-03 04:24:45 --> Model Class Initialized
DEBUG - 2011-10-03 04:24:45 --> Model Class Initialized
DEBUG - 2011-10-03 04:24:45 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-10-03 04:24:45 --> Database Driver Class Initialized
DEBUG - 2011-10-03 04:24:46 --> Final output sent to browser
DEBUG - 2011-10-03 04:24:46 --> Total execution time: 0.8206
DEBUG - 2011-10-03 04:25:24 --> Config Class Initialized
DEBUG - 2011-10-03 04:25:24 --> Hooks Class Initialized
DEBUG - 2011-10-03 04:25:24 --> Utf8 Class Initialized
DEBUG - 2011-10-03 04:25:24 --> UTF-8 Support Enabled
DEBUG - 2011-10-03 04:25:24 --> URI Class Initialized
DEBUG - 2011-10-03 04:25:24 --> Router Class Initialized
DEBUG - 2011-10-03 04:25:24 --> Output Class Initialized
DEBUG - 2011-10-03 04:25:24 --> Input Class Initialized
DEBUG - 2011-10-03 04:25:24 --> Global POST and COOKIE data sanitized
DEBUG - 2011-10-03 04:25:24 --> Language Class Initialized
DEBUG - 2011-10-03 04:25:24 --> Loader Class Initialized
DEBUG - 2011-10-03 04:25:24 --> Controller Class Initialized
ERROR - 2011-10-03 04:25:24 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-10-03 04:25:24 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-10-03 04:25:24 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-10-03 04:25:24 --> Model Class Initialized
DEBUG - 2011-10-03 04:25:24 --> Model Class Initialized
DEBUG - 2011-10-03 04:25:24 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-10-03 04:25:24 --> Database Driver Class Initialized
DEBUG - 2011-10-03 04:25:24 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-10-03 04:25:24 --> Helper loaded: url_helper
DEBUG - 2011-10-03 04:25:24 --> File loaded: application/views/common/header.php
DEBUG - 2011-10-03 04:25:24 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-10-03 04:25:24 --> File loaded: application/views/common/footer.php
DEBUG - 2011-10-03 04:25:24 --> File loaded: application/views/layout/main.php
DEBUG - 2011-10-03 04:25:24 --> Final output sent to browser
DEBUG - 2011-10-03 04:25:24 --> Total execution time: 0.0575
DEBUG - 2011-10-03 04:25:25 --> Config Class Initialized
DEBUG - 2011-10-03 04:25:25 --> Hooks Class Initialized
DEBUG - 2011-10-03 04:25:25 --> Utf8 Class Initialized
DEBUG - 2011-10-03 04:25:25 --> UTF-8 Support Enabled
DEBUG - 2011-10-03 04:25:25 --> URI Class Initialized
DEBUG - 2011-10-03 04:25:25 --> Router Class Initialized
DEBUG - 2011-10-03 04:25:25 --> Output Class Initialized
DEBUG - 2011-10-03 04:25:25 --> Input Class Initialized
DEBUG - 2011-10-03 04:25:25 --> Global POST and COOKIE data sanitized
DEBUG - 2011-10-03 04:25:25 --> Language Class Initialized
DEBUG - 2011-10-03 04:25:25 --> Loader Class Initialized
DEBUG - 2011-10-03 04:25:25 --> Controller Class Initialized
DEBUG - 2011-10-03 04:25:25 --> Model Class Initialized
DEBUG - 2011-10-03 04:25:25 --> Model Class Initialized
DEBUG - 2011-10-03 04:25:25 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-10-03 04:25:25 --> Database Driver Class Initialized
DEBUG - 2011-10-03 04:25:26 --> Final output sent to browser
DEBUG - 2011-10-03 04:25:26 --> Total execution time: 0.7898
DEBUG - 2011-10-03 04:25:38 --> Config Class Initialized
DEBUG - 2011-10-03 04:25:38 --> Hooks Class Initialized
DEBUG - 2011-10-03 04:25:38 --> Utf8 Class Initialized
DEBUG - 2011-10-03 04:25:38 --> UTF-8 Support Enabled
DEBUG - 2011-10-03 04:25:38 --> URI Class Initialized
DEBUG - 2011-10-03 04:25:38 --> Router Class Initialized
DEBUG - 2011-10-03 04:25:38 --> Output Class Initialized
DEBUG - 2011-10-03 04:25:38 --> Input Class Initialized
DEBUG - 2011-10-03 04:25:38 --> Global POST and COOKIE data sanitized
DEBUG - 2011-10-03 04:25:38 --> Language Class Initialized
DEBUG - 2011-10-03 04:25:38 --> Loader Class Initialized
DEBUG - 2011-10-03 04:25:38 --> Controller Class Initialized
ERROR - 2011-10-03 04:25:38 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-10-03 04:25:38 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-10-03 04:25:38 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-10-03 04:25:38 --> Model Class Initialized
DEBUG - 2011-10-03 04:25:38 --> Model Class Initialized
DEBUG - 2011-10-03 04:25:38 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-10-03 04:25:38 --> Database Driver Class Initialized
DEBUG - 2011-10-03 04:25:38 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-10-03 04:25:38 --> Helper loaded: url_helper
DEBUG - 2011-10-03 04:25:38 --> File loaded: application/views/common/header.php
DEBUG - 2011-10-03 04:25:38 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-10-03 04:25:38 --> File loaded: application/views/common/footer.php
DEBUG - 2011-10-03 04:25:38 --> File loaded: application/views/layout/main.php
DEBUG - 2011-10-03 04:25:38 --> Final output sent to browser
DEBUG - 2011-10-03 04:25:38 --> Total execution time: 0.0580
DEBUG - 2011-10-03 04:25:39 --> Config Class Initialized
DEBUG - 2011-10-03 04:25:39 --> Hooks Class Initialized
DEBUG - 2011-10-03 04:25:39 --> Utf8 Class Initialized
DEBUG - 2011-10-03 04:25:39 --> UTF-8 Support Enabled
DEBUG - 2011-10-03 04:25:39 --> URI Class Initialized
DEBUG - 2011-10-03 04:25:39 --> Router Class Initialized
DEBUG - 2011-10-03 04:25:39 --> Output Class Initialized
DEBUG - 2011-10-03 04:25:39 --> Input Class Initialized
DEBUG - 2011-10-03 04:25:39 --> Global POST and COOKIE data sanitized
DEBUG - 2011-10-03 04:25:39 --> Language Class Initialized
DEBUG - 2011-10-03 04:25:39 --> Loader Class Initialized
DEBUG - 2011-10-03 04:25:39 --> Controller Class Initialized
DEBUG - 2011-10-03 04:25:39 --> Model Class Initialized
DEBUG - 2011-10-03 04:25:39 --> Model Class Initialized
DEBUG - 2011-10-03 04:25:39 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-10-03 04:25:39 --> Database Driver Class Initialized
DEBUG - 2011-10-03 04:25:40 --> Final output sent to browser
DEBUG - 2011-10-03 04:25:40 --> Total execution time: 0.9202
DEBUG - 2011-10-03 04:26:05 --> Config Class Initialized
DEBUG - 2011-10-03 04:26:05 --> Hooks Class Initialized
DEBUG - 2011-10-03 04:26:05 --> Utf8 Class Initialized
DEBUG - 2011-10-03 04:26:05 --> UTF-8 Support Enabled
DEBUG - 2011-10-03 04:26:05 --> URI Class Initialized
DEBUG - 2011-10-03 04:26:05 --> Router Class Initialized
DEBUG - 2011-10-03 04:26:05 --> Output Class Initialized
DEBUG - 2011-10-03 04:26:05 --> Input Class Initialized
DEBUG - 2011-10-03 04:26:05 --> Global POST and COOKIE data sanitized
DEBUG - 2011-10-03 04:26:05 --> Language Class Initialized
DEBUG - 2011-10-03 04:26:05 --> Loader Class Initialized
DEBUG - 2011-10-03 04:26:05 --> Controller Class Initialized
ERROR - 2011-10-03 04:26:05 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-10-03 04:26:05 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-10-03 04:26:05 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-10-03 04:26:05 --> Model Class Initialized
DEBUG - 2011-10-03 04:26:05 --> Model Class Initialized
DEBUG - 2011-10-03 04:26:05 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-10-03 04:26:05 --> Database Driver Class Initialized
DEBUG - 2011-10-03 04:26:05 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-10-03 04:26:05 --> Helper loaded: url_helper
DEBUG - 2011-10-03 04:26:05 --> File loaded: application/views/common/header.php
DEBUG - 2011-10-03 04:26:05 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-10-03 04:26:05 --> File loaded: application/views/common/footer.php
DEBUG - 2011-10-03 04:26:05 --> File loaded: application/views/layout/main.php
DEBUG - 2011-10-03 04:26:05 --> Final output sent to browser
DEBUG - 2011-10-03 04:26:05 --> Total execution time: 0.0886
DEBUG - 2011-10-03 04:26:06 --> Config Class Initialized
DEBUG - 2011-10-03 04:26:06 --> Hooks Class Initialized
DEBUG - 2011-10-03 04:26:06 --> Utf8 Class Initialized
DEBUG - 2011-10-03 04:26:06 --> UTF-8 Support Enabled
DEBUG - 2011-10-03 04:26:06 --> URI Class Initialized
DEBUG - 2011-10-03 04:26:06 --> Router Class Initialized
DEBUG - 2011-10-03 04:26:06 --> Output Class Initialized
DEBUG - 2011-10-03 04:26:06 --> Input Class Initialized
DEBUG - 2011-10-03 04:26:06 --> Global POST and COOKIE data sanitized
DEBUG - 2011-10-03 04:26:06 --> Language Class Initialized
DEBUG - 2011-10-03 04:26:06 --> Loader Class Initialized
DEBUG - 2011-10-03 04:26:06 --> Controller Class Initialized
DEBUG - 2011-10-03 04:26:06 --> Model Class Initialized
DEBUG - 2011-10-03 04:26:06 --> Model Class Initialized
DEBUG - 2011-10-03 04:26:06 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-10-03 04:26:06 --> Database Driver Class Initialized
DEBUG - 2011-10-03 04:26:07 --> Final output sent to browser
DEBUG - 2011-10-03 04:26:07 --> Total execution time: 0.9974
DEBUG - 2011-10-03 04:26:11 --> Config Class Initialized
DEBUG - 2011-10-03 04:26:11 --> Hooks Class Initialized
DEBUG - 2011-10-03 04:26:11 --> Utf8 Class Initialized
DEBUG - 2011-10-03 04:26:11 --> UTF-8 Support Enabled
DEBUG - 2011-10-03 04:26:11 --> URI Class Initialized
DEBUG - 2011-10-03 04:26:11 --> Router Class Initialized
DEBUG - 2011-10-03 04:26:11 --> Output Class Initialized
DEBUG - 2011-10-03 04:26:11 --> Input Class Initialized
DEBUG - 2011-10-03 04:26:11 --> Global POST and COOKIE data sanitized
DEBUG - 2011-10-03 04:26:11 --> Language Class Initialized
DEBUG - 2011-10-03 04:26:11 --> Loader Class Initialized
DEBUG - 2011-10-03 04:26:11 --> Controller Class Initialized
ERROR - 2011-10-03 04:26:11 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-10-03 04:26:11 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-10-03 04:26:11 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-10-03 04:26:11 --> Model Class Initialized
DEBUG - 2011-10-03 04:26:11 --> Model Class Initialized
DEBUG - 2011-10-03 04:26:11 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-10-03 04:26:11 --> Database Driver Class Initialized
DEBUG - 2011-10-03 04:26:11 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-10-03 04:26:11 --> Helper loaded: url_helper
DEBUG - 2011-10-03 04:26:11 --> File loaded: application/views/common/header.php
DEBUG - 2011-10-03 04:26:11 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-10-03 04:26:11 --> File loaded: application/views/common/footer.php
DEBUG - 2011-10-03 04:26:11 --> File loaded: application/views/layout/main.php
DEBUG - 2011-10-03 04:26:11 --> Final output sent to browser
DEBUG - 2011-10-03 04:26:11 --> Total execution time: 0.0338
DEBUG - 2011-10-03 04:26:12 --> Config Class Initialized
DEBUG - 2011-10-03 04:26:12 --> Hooks Class Initialized
DEBUG - 2011-10-03 04:26:12 --> Utf8 Class Initialized
DEBUG - 2011-10-03 04:26:12 --> UTF-8 Support Enabled
DEBUG - 2011-10-03 04:26:12 --> URI Class Initialized
DEBUG - 2011-10-03 04:26:12 --> Router Class Initialized
DEBUG - 2011-10-03 04:26:12 --> Output Class Initialized
DEBUG - 2011-10-03 04:26:12 --> Input Class Initialized
DEBUG - 2011-10-03 04:26:12 --> Global POST and COOKIE data sanitized
DEBUG - 2011-10-03 04:26:12 --> Language Class Initialized
DEBUG - 2011-10-03 04:26:12 --> Loader Class Initialized
DEBUG - 2011-10-03 04:26:12 --> Controller Class Initialized
DEBUG - 2011-10-03 04:26:12 --> Model Class Initialized
DEBUG - 2011-10-03 04:26:12 --> Model Class Initialized
DEBUG - 2011-10-03 04:26:12 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-10-03 04:26:12 --> Database Driver Class Initialized
DEBUG - 2011-10-03 04:26:14 --> Final output sent to browser
DEBUG - 2011-10-03 04:26:14 --> Total execution time: 2.3530
DEBUG - 2011-10-03 04:26:16 --> Config Class Initialized
DEBUG - 2011-10-03 04:26:16 --> Hooks Class Initialized
DEBUG - 2011-10-03 04:26:16 --> Utf8 Class Initialized
DEBUG - 2011-10-03 04:26:16 --> UTF-8 Support Enabled
DEBUG - 2011-10-03 04:26:16 --> URI Class Initialized
DEBUG - 2011-10-03 04:26:16 --> Router Class Initialized
DEBUG - 2011-10-03 04:26:16 --> Output Class Initialized
DEBUG - 2011-10-03 04:26:16 --> Input Class Initialized
DEBUG - 2011-10-03 04:26:16 --> Global POST and COOKIE data sanitized
DEBUG - 2011-10-03 04:26:16 --> Language Class Initialized
DEBUG - 2011-10-03 04:26:16 --> Loader Class Initialized
DEBUG - 2011-10-03 04:26:16 --> Controller Class Initialized
ERROR - 2011-10-03 04:26:16 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-10-03 04:26:16 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-10-03 04:26:16 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-10-03 04:26:16 --> Model Class Initialized
DEBUG - 2011-10-03 04:26:16 --> Model Class Initialized
DEBUG - 2011-10-03 04:26:16 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-10-03 04:26:16 --> Database Driver Class Initialized
DEBUG - 2011-10-03 04:26:16 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-10-03 04:26:16 --> Helper loaded: url_helper
DEBUG - 2011-10-03 04:26:16 --> File loaded: application/views/common/header.php
DEBUG - 2011-10-03 04:26:16 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-10-03 04:26:16 --> File loaded: application/views/common/footer.php
DEBUG - 2011-10-03 04:26:16 --> File loaded: application/views/layout/main.php
DEBUG - 2011-10-03 04:26:16 --> Final output sent to browser
DEBUG - 2011-10-03 04:26:16 --> Total execution time: 0.0300
DEBUG - 2011-10-03 04:26:18 --> Config Class Initialized
DEBUG - 2011-10-03 04:26:18 --> Hooks Class Initialized
DEBUG - 2011-10-03 04:26:18 --> Utf8 Class Initialized
DEBUG - 2011-10-03 04:26:18 --> UTF-8 Support Enabled
DEBUG - 2011-10-03 04:26:18 --> URI Class Initialized
DEBUG - 2011-10-03 04:26:18 --> Router Class Initialized
DEBUG - 2011-10-03 04:26:18 --> Output Class Initialized
DEBUG - 2011-10-03 04:26:18 --> Input Class Initialized
DEBUG - 2011-10-03 04:26:18 --> Global POST and COOKIE data sanitized
DEBUG - 2011-10-03 04:26:18 --> Language Class Initialized
DEBUG - 2011-10-03 04:26:18 --> Loader Class Initialized
DEBUG - 2011-10-03 04:26:18 --> Controller Class Initialized
DEBUG - 2011-10-03 04:26:18 --> Model Class Initialized
DEBUG - 2011-10-03 04:26:18 --> Model Class Initialized
DEBUG - 2011-10-03 04:26:18 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-10-03 04:26:18 --> Database Driver Class Initialized
DEBUG - 2011-10-03 04:26:19 --> Final output sent to browser
DEBUG - 2011-10-03 04:26:19 --> Total execution time: 1.4302
DEBUG - 2011-10-03 04:26:21 --> Config Class Initialized
DEBUG - 2011-10-03 04:26:21 --> Hooks Class Initialized
DEBUG - 2011-10-03 04:26:21 --> Utf8 Class Initialized
DEBUG - 2011-10-03 04:26:21 --> UTF-8 Support Enabled
DEBUG - 2011-10-03 04:26:21 --> URI Class Initialized
DEBUG - 2011-10-03 04:26:21 --> Router Class Initialized
DEBUG - 2011-10-03 04:26:21 --> Output Class Initialized
DEBUG - 2011-10-03 04:26:21 --> Input Class Initialized
DEBUG - 2011-10-03 04:26:21 --> Global POST and COOKIE data sanitized
DEBUG - 2011-10-03 04:26:21 --> Language Class Initialized
DEBUG - 2011-10-03 04:26:21 --> Loader Class Initialized
DEBUG - 2011-10-03 04:26:21 --> Controller Class Initialized
ERROR - 2011-10-03 04:26:21 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-10-03 04:26:21 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-10-03 04:26:21 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-10-03 04:26:21 --> Model Class Initialized
DEBUG - 2011-10-03 04:26:21 --> Model Class Initialized
DEBUG - 2011-10-03 04:26:21 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-10-03 04:26:21 --> Database Driver Class Initialized
DEBUG - 2011-10-03 04:26:21 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-10-03 04:26:21 --> Helper loaded: url_helper
DEBUG - 2011-10-03 04:26:21 --> File loaded: application/views/common/header.php
DEBUG - 2011-10-03 04:26:21 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-10-03 04:26:21 --> File loaded: application/views/common/footer.php
DEBUG - 2011-10-03 04:26:21 --> File loaded: application/views/layout/main.php
DEBUG - 2011-10-03 04:26:21 --> Final output sent to browser
DEBUG - 2011-10-03 04:26:21 --> Total execution time: 0.0330
DEBUG - 2011-10-03 04:26:22 --> Config Class Initialized
DEBUG - 2011-10-03 04:26:22 --> Hooks Class Initialized
DEBUG - 2011-10-03 04:26:22 --> Utf8 Class Initialized
DEBUG - 2011-10-03 04:26:22 --> UTF-8 Support Enabled
DEBUG - 2011-10-03 04:26:22 --> URI Class Initialized
DEBUG - 2011-10-03 04:26:22 --> Router Class Initialized
DEBUG - 2011-10-03 04:26:22 --> Output Class Initialized
DEBUG - 2011-10-03 04:26:22 --> Input Class Initialized
DEBUG - 2011-10-03 04:26:22 --> Global POST and COOKIE data sanitized
DEBUG - 2011-10-03 04:26:22 --> Language Class Initialized
DEBUG - 2011-10-03 04:26:22 --> Loader Class Initialized
DEBUG - 2011-10-03 04:26:22 --> Controller Class Initialized
DEBUG - 2011-10-03 04:26:22 --> Model Class Initialized
DEBUG - 2011-10-03 04:26:22 --> Model Class Initialized
DEBUG - 2011-10-03 04:26:22 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-10-03 04:26:22 --> Database Driver Class Initialized
DEBUG - 2011-10-03 04:26:31 --> Final output sent to browser
DEBUG - 2011-10-03 04:26:31 --> Total execution time: 9.6729
DEBUG - 2011-10-03 04:26:44 --> Config Class Initialized
DEBUG - 2011-10-03 04:26:44 --> Hooks Class Initialized
DEBUG - 2011-10-03 04:26:44 --> Utf8 Class Initialized
DEBUG - 2011-10-03 04:26:44 --> UTF-8 Support Enabled
DEBUG - 2011-10-03 04:26:44 --> URI Class Initialized
DEBUG - 2011-10-03 04:26:44 --> Router Class Initialized
DEBUG - 2011-10-03 04:26:44 --> Output Class Initialized
DEBUG - 2011-10-03 04:26:44 --> Input Class Initialized
DEBUG - 2011-10-03 04:26:44 --> Global POST and COOKIE data sanitized
DEBUG - 2011-10-03 04:26:44 --> Language Class Initialized
DEBUG - 2011-10-03 04:26:44 --> Loader Class Initialized
DEBUG - 2011-10-03 04:26:44 --> Controller Class Initialized
ERROR - 2011-10-03 04:26:44 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-10-03 04:26:44 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-10-03 04:26:44 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-10-03 04:26:44 --> Model Class Initialized
DEBUG - 2011-10-03 04:26:44 --> Model Class Initialized
DEBUG - 2011-10-03 04:26:44 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-10-03 04:26:44 --> Database Driver Class Initialized
DEBUG - 2011-10-03 04:26:44 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-10-03 04:26:44 --> Helper loaded: url_helper
DEBUG - 2011-10-03 04:26:44 --> File loaded: application/views/common/header.php
DEBUG - 2011-10-03 04:26:44 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-10-03 04:26:44 --> File loaded: application/views/common/footer.php
DEBUG - 2011-10-03 04:26:44 --> File loaded: application/views/layout/main.php
DEBUG - 2011-10-03 04:26:44 --> Final output sent to browser
DEBUG - 2011-10-03 04:26:44 --> Total execution time: 0.0559
DEBUG - 2011-10-03 04:26:44 --> Config Class Initialized
DEBUG - 2011-10-03 04:26:44 --> Hooks Class Initialized
DEBUG - 2011-10-03 04:26:44 --> Utf8 Class Initialized
DEBUG - 2011-10-03 04:26:44 --> UTF-8 Support Enabled
DEBUG - 2011-10-03 04:26:44 --> URI Class Initialized
DEBUG - 2011-10-03 04:26:44 --> Router Class Initialized
ERROR - 2011-10-03 04:26:44 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-10-03 04:26:46 --> Config Class Initialized
DEBUG - 2011-10-03 04:26:46 --> Hooks Class Initialized
DEBUG - 2011-10-03 04:26:46 --> Utf8 Class Initialized
DEBUG - 2011-10-03 04:26:46 --> UTF-8 Support Enabled
DEBUG - 2011-10-03 04:26:46 --> URI Class Initialized
DEBUG - 2011-10-03 04:26:46 --> Router Class Initialized
DEBUG - 2011-10-03 04:26:46 --> Output Class Initialized
DEBUG - 2011-10-03 04:26:46 --> Input Class Initialized
DEBUG - 2011-10-03 04:26:46 --> Global POST and COOKIE data sanitized
DEBUG - 2011-10-03 04:26:46 --> Language Class Initialized
DEBUG - 2011-10-03 04:26:46 --> Loader Class Initialized
DEBUG - 2011-10-03 04:26:46 --> Controller Class Initialized
DEBUG - 2011-10-03 04:26:46 --> Model Class Initialized
DEBUG - 2011-10-03 04:26:46 --> Model Class Initialized
DEBUG - 2011-10-03 04:26:46 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-10-03 04:26:46 --> Database Driver Class Initialized
DEBUG - 2011-10-03 04:26:47 --> Final output sent to browser
DEBUG - 2011-10-03 04:26:47 --> Total execution time: 0.8325
DEBUG - 2011-10-03 04:26:56 --> Config Class Initialized
DEBUG - 2011-10-03 04:26:56 --> Hooks Class Initialized
DEBUG - 2011-10-03 04:26:56 --> Utf8 Class Initialized
DEBUG - 2011-10-03 04:26:56 --> UTF-8 Support Enabled
DEBUG - 2011-10-03 04:26:56 --> URI Class Initialized
DEBUG - 2011-10-03 04:26:56 --> Router Class Initialized
ERROR - 2011-10-03 04:26:56 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-10-03 04:26:59 --> Config Class Initialized
DEBUG - 2011-10-03 04:26:59 --> Hooks Class Initialized
DEBUG - 2011-10-03 04:26:59 --> Utf8 Class Initialized
DEBUG - 2011-10-03 04:26:59 --> UTF-8 Support Enabled
DEBUG - 2011-10-03 04:26:59 --> URI Class Initialized
DEBUG - 2011-10-03 04:26:59 --> Router Class Initialized
DEBUG - 2011-10-03 04:26:59 --> Output Class Initialized
DEBUG - 2011-10-03 04:26:59 --> Input Class Initialized
DEBUG - 2011-10-03 04:26:59 --> Global POST and COOKIE data sanitized
DEBUG - 2011-10-03 04:26:59 --> Language Class Initialized
DEBUG - 2011-10-03 04:26:59 --> Loader Class Initialized
DEBUG - 2011-10-03 04:26:59 --> Controller Class Initialized
ERROR - 2011-10-03 04:26:59 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-10-03 04:26:59 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-10-03 04:26:59 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-10-03 04:26:59 --> Model Class Initialized
DEBUG - 2011-10-03 04:26:59 --> Model Class Initialized
DEBUG - 2011-10-03 04:26:59 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-10-03 04:26:59 --> Database Driver Class Initialized
DEBUG - 2011-10-03 04:26:59 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-10-03 04:26:59 --> Helper loaded: url_helper
DEBUG - 2011-10-03 04:26:59 --> File loaded: application/views/common/header.php
DEBUG - 2011-10-03 04:26:59 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-10-03 04:26:59 --> File loaded: application/views/common/footer.php
DEBUG - 2011-10-03 04:26:59 --> File loaded: application/views/layout/main.php
DEBUG - 2011-10-03 04:26:59 --> Final output sent to browser
DEBUG - 2011-10-03 04:26:59 --> Total execution time: 0.0322
DEBUG - 2011-10-03 04:27:03 --> Config Class Initialized
DEBUG - 2011-10-03 04:27:03 --> Hooks Class Initialized
DEBUG - 2011-10-03 04:27:03 --> Utf8 Class Initialized
DEBUG - 2011-10-03 04:27:03 --> UTF-8 Support Enabled
DEBUG - 2011-10-03 04:27:03 --> URI Class Initialized
DEBUG - 2011-10-03 04:27:03 --> Router Class Initialized
DEBUG - 2011-10-03 04:27:03 --> Output Class Initialized
DEBUG - 2011-10-03 04:27:03 --> Input Class Initialized
DEBUG - 2011-10-03 04:27:03 --> Global POST and COOKIE data sanitized
DEBUG - 2011-10-03 04:27:03 --> Language Class Initialized
DEBUG - 2011-10-03 04:27:03 --> Loader Class Initialized
DEBUG - 2011-10-03 04:27:03 --> Controller Class Initialized
DEBUG - 2011-10-03 04:27:03 --> Model Class Initialized
DEBUG - 2011-10-03 04:27:03 --> Model Class Initialized
DEBUG - 2011-10-03 04:27:03 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-10-03 04:27:03 --> Database Driver Class Initialized
DEBUG - 2011-10-03 04:27:03 --> Final output sent to browser
DEBUG - 2011-10-03 04:27:03 --> Total execution time: 0.8808
DEBUG - 2011-10-03 04:27:10 --> Config Class Initialized
DEBUG - 2011-10-03 04:27:10 --> Hooks Class Initialized
DEBUG - 2011-10-03 04:27:10 --> Utf8 Class Initialized
DEBUG - 2011-10-03 04:27:10 --> UTF-8 Support Enabled
DEBUG - 2011-10-03 04:27:10 --> URI Class Initialized
DEBUG - 2011-10-03 04:27:10 --> Router Class Initialized
ERROR - 2011-10-03 04:27:10 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-10-03 04:27:16 --> Config Class Initialized
DEBUG - 2011-10-03 04:27:16 --> Hooks Class Initialized
DEBUG - 2011-10-03 04:27:16 --> Utf8 Class Initialized
DEBUG - 2011-10-03 04:27:16 --> UTF-8 Support Enabled
DEBUG - 2011-10-03 04:27:16 --> URI Class Initialized
DEBUG - 2011-10-03 04:27:16 --> Router Class Initialized
DEBUG - 2011-10-03 04:27:16 --> Output Class Initialized
DEBUG - 2011-10-03 04:27:16 --> Input Class Initialized
DEBUG - 2011-10-03 04:27:16 --> Global POST and COOKIE data sanitized
DEBUG - 2011-10-03 04:27:16 --> Language Class Initialized
DEBUG - 2011-10-03 04:27:16 --> Loader Class Initialized
DEBUG - 2011-10-03 04:27:16 --> Controller Class Initialized
ERROR - 2011-10-03 04:27:16 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-10-03 04:27:16 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-10-03 04:27:16 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-10-03 04:27:16 --> Model Class Initialized
DEBUG - 2011-10-03 04:27:16 --> Model Class Initialized
DEBUG - 2011-10-03 04:27:16 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-10-03 04:27:16 --> Database Driver Class Initialized
DEBUG - 2011-10-03 04:27:16 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-10-03 04:27:16 --> Helper loaded: url_helper
DEBUG - 2011-10-03 04:27:16 --> File loaded: application/views/common/header.php
DEBUG - 2011-10-03 04:27:16 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-10-03 04:27:16 --> File loaded: application/views/common/footer.php
DEBUG - 2011-10-03 04:27:16 --> File loaded: application/views/layout/main.php
DEBUG - 2011-10-03 04:27:16 --> Final output sent to browser
DEBUG - 2011-10-03 04:27:16 --> Total execution time: 0.0421
DEBUG - 2011-10-03 04:27:21 --> Config Class Initialized
DEBUG - 2011-10-03 04:27:21 --> Hooks Class Initialized
DEBUG - 2011-10-03 04:27:21 --> Utf8 Class Initialized
DEBUG - 2011-10-03 04:27:21 --> UTF-8 Support Enabled
DEBUG - 2011-10-03 04:27:21 --> URI Class Initialized
DEBUG - 2011-10-03 04:27:21 --> Router Class Initialized
DEBUG - 2011-10-03 04:27:21 --> Output Class Initialized
DEBUG - 2011-10-03 04:27:21 --> Input Class Initialized
DEBUG - 2011-10-03 04:27:21 --> Global POST and COOKIE data sanitized
DEBUG - 2011-10-03 04:27:21 --> Language Class Initialized
DEBUG - 2011-10-03 04:27:21 --> Loader Class Initialized
DEBUG - 2011-10-03 04:27:21 --> Controller Class Initialized
DEBUG - 2011-10-03 04:27:21 --> Model Class Initialized
DEBUG - 2011-10-03 04:27:21 --> Model Class Initialized
DEBUG - 2011-10-03 04:27:21 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-10-03 04:27:21 --> Database Driver Class Initialized
DEBUG - 2011-10-03 04:27:21 --> Final output sent to browser
DEBUG - 2011-10-03 04:27:21 --> Total execution time: 0.4873
DEBUG - 2011-10-03 04:27:32 --> Config Class Initialized
DEBUG - 2011-10-03 04:27:32 --> Hooks Class Initialized
DEBUG - 2011-10-03 04:27:32 --> Utf8 Class Initialized
DEBUG - 2011-10-03 04:27:32 --> UTF-8 Support Enabled
DEBUG - 2011-10-03 04:27:32 --> URI Class Initialized
DEBUG - 2011-10-03 04:27:32 --> Router Class Initialized
ERROR - 2011-10-03 04:27:32 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-10-03 04:28:01 --> Config Class Initialized
DEBUG - 2011-10-03 04:28:01 --> Hooks Class Initialized
DEBUG - 2011-10-03 04:28:01 --> Utf8 Class Initialized
DEBUG - 2011-10-03 04:28:01 --> UTF-8 Support Enabled
DEBUG - 2011-10-03 04:28:01 --> URI Class Initialized
DEBUG - 2011-10-03 04:28:01 --> Router Class Initialized
DEBUG - 2011-10-03 04:28:01 --> Output Class Initialized
DEBUG - 2011-10-03 04:28:01 --> Input Class Initialized
DEBUG - 2011-10-03 04:28:01 --> Global POST and COOKIE data sanitized
DEBUG - 2011-10-03 04:28:01 --> Language Class Initialized
DEBUG - 2011-10-03 04:28:01 --> Loader Class Initialized
DEBUG - 2011-10-03 04:28:01 --> Controller Class Initialized
ERROR - 2011-10-03 04:28:01 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-10-03 04:28:01 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-10-03 04:28:01 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-10-03 04:28:01 --> Model Class Initialized
DEBUG - 2011-10-03 04:28:01 --> Model Class Initialized
DEBUG - 2011-10-03 04:28:01 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-10-03 04:28:01 --> Database Driver Class Initialized
DEBUG - 2011-10-03 04:28:01 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-10-03 04:28:01 --> Helper loaded: url_helper
DEBUG - 2011-10-03 04:28:01 --> File loaded: application/views/common/header.php
DEBUG - 2011-10-03 04:28:01 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-10-03 04:28:01 --> File loaded: application/views/common/footer.php
DEBUG - 2011-10-03 04:28:01 --> File loaded: application/views/layout/main.php
DEBUG - 2011-10-03 04:28:01 --> Final output sent to browser
DEBUG - 2011-10-03 04:28:01 --> Total execution time: 0.0639
DEBUG - 2011-10-03 04:28:08 --> Config Class Initialized
DEBUG - 2011-10-03 04:28:08 --> Hooks Class Initialized
DEBUG - 2011-10-03 04:28:08 --> Utf8 Class Initialized
DEBUG - 2011-10-03 04:28:08 --> UTF-8 Support Enabled
DEBUG - 2011-10-03 04:28:08 --> URI Class Initialized
DEBUG - 2011-10-03 04:28:08 --> Router Class Initialized
DEBUG - 2011-10-03 04:28:08 --> Output Class Initialized
DEBUG - 2011-10-03 04:28:08 --> Input Class Initialized
DEBUG - 2011-10-03 04:28:08 --> Global POST and COOKIE data sanitized
DEBUG - 2011-10-03 04:28:08 --> Language Class Initialized
DEBUG - 2011-10-03 04:28:08 --> Loader Class Initialized
DEBUG - 2011-10-03 04:28:08 --> Controller Class Initialized
DEBUG - 2011-10-03 04:28:08 --> Model Class Initialized
DEBUG - 2011-10-03 04:28:08 --> Model Class Initialized
DEBUG - 2011-10-03 04:28:08 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-10-03 04:28:08 --> Database Driver Class Initialized
DEBUG - 2011-10-03 04:28:09 --> Final output sent to browser
DEBUG - 2011-10-03 04:28:09 --> Total execution time: 0.9014
DEBUG - 2011-10-03 04:28:31 --> Config Class Initialized
DEBUG - 2011-10-03 04:28:31 --> Hooks Class Initialized
DEBUG - 2011-10-03 04:28:31 --> Utf8 Class Initialized
DEBUG - 2011-10-03 04:28:31 --> UTF-8 Support Enabled
DEBUG - 2011-10-03 04:28:31 --> URI Class Initialized
DEBUG - 2011-10-03 04:28:31 --> Router Class Initialized
ERROR - 2011-10-03 04:28:31 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-10-03 04:28:55 --> Config Class Initialized
DEBUG - 2011-10-03 04:28:55 --> Hooks Class Initialized
DEBUG - 2011-10-03 04:28:55 --> Utf8 Class Initialized
DEBUG - 2011-10-03 04:28:55 --> UTF-8 Support Enabled
DEBUG - 2011-10-03 04:28:55 --> URI Class Initialized
DEBUG - 2011-10-03 04:28:55 --> Router Class Initialized
DEBUG - 2011-10-03 04:28:55 --> Output Class Initialized
DEBUG - 2011-10-03 04:28:55 --> Input Class Initialized
DEBUG - 2011-10-03 04:28:55 --> Global POST and COOKIE data sanitized
DEBUG - 2011-10-03 04:28:55 --> Language Class Initialized
DEBUG - 2011-10-03 04:28:55 --> Loader Class Initialized
DEBUG - 2011-10-03 04:28:55 --> Controller Class Initialized
ERROR - 2011-10-03 04:28:55 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-10-03 04:28:55 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-10-03 04:28:55 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-10-03 04:28:55 --> Model Class Initialized
DEBUG - 2011-10-03 04:28:55 --> Model Class Initialized
DEBUG - 2011-10-03 04:28:55 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-10-03 04:28:55 --> Database Driver Class Initialized
DEBUG - 2011-10-03 04:28:55 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-10-03 04:28:55 --> Helper loaded: url_helper
DEBUG - 2011-10-03 04:28:55 --> File loaded: application/views/common/header.php
DEBUG - 2011-10-03 04:28:55 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-10-03 04:28:55 --> File loaded: application/views/common/footer.php
DEBUG - 2011-10-03 04:28:55 --> File loaded: application/views/layout/main.php
DEBUG - 2011-10-03 04:28:55 --> Final output sent to browser
DEBUG - 2011-10-03 04:28:55 --> Total execution time: 0.0945
DEBUG - 2011-10-03 04:29:02 --> Config Class Initialized
DEBUG - 2011-10-03 04:29:02 --> Hooks Class Initialized
DEBUG - 2011-10-03 04:29:02 --> Utf8 Class Initialized
DEBUG - 2011-10-03 04:29:02 --> UTF-8 Support Enabled
DEBUG - 2011-10-03 04:29:02 --> URI Class Initialized
DEBUG - 2011-10-03 04:29:02 --> Router Class Initialized
DEBUG - 2011-10-03 04:29:02 --> Output Class Initialized
DEBUG - 2011-10-03 04:29:02 --> Input Class Initialized
DEBUG - 2011-10-03 04:29:02 --> Global POST and COOKIE data sanitized
DEBUG - 2011-10-03 04:29:02 --> Language Class Initialized
DEBUG - 2011-10-03 04:29:02 --> Loader Class Initialized
DEBUG - 2011-10-03 04:29:02 --> Controller Class Initialized
DEBUG - 2011-10-03 04:29:02 --> Model Class Initialized
DEBUG - 2011-10-03 04:29:02 --> Model Class Initialized
DEBUG - 2011-10-03 04:29:02 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-10-03 04:29:02 --> Database Driver Class Initialized
DEBUG - 2011-10-03 04:29:04 --> Final output sent to browser
DEBUG - 2011-10-03 04:29:04 --> Total execution time: 2.1099
DEBUG - 2011-10-03 04:29:17 --> Config Class Initialized
DEBUG - 2011-10-03 04:29:17 --> Hooks Class Initialized
DEBUG - 2011-10-03 04:29:17 --> Utf8 Class Initialized
DEBUG - 2011-10-03 04:29:17 --> UTF-8 Support Enabled
DEBUG - 2011-10-03 04:29:17 --> URI Class Initialized
DEBUG - 2011-10-03 04:29:17 --> Router Class Initialized
DEBUG - 2011-10-03 04:29:17 --> Output Class Initialized
DEBUG - 2011-10-03 04:29:17 --> Input Class Initialized
DEBUG - 2011-10-03 04:29:17 --> Global POST and COOKIE data sanitized
DEBUG - 2011-10-03 04:29:17 --> Language Class Initialized
DEBUG - 2011-10-03 04:29:17 --> Loader Class Initialized
DEBUG - 2011-10-03 04:29:17 --> Controller Class Initialized
ERROR - 2011-10-03 04:29:17 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-10-03 04:29:17 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-10-03 04:29:17 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-10-03 04:29:17 --> Model Class Initialized
DEBUG - 2011-10-03 04:29:17 --> Model Class Initialized
DEBUG - 2011-10-03 04:29:17 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-10-03 04:29:17 --> Database Driver Class Initialized
DEBUG - 2011-10-03 04:29:17 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-10-03 04:29:17 --> Helper loaded: url_helper
DEBUG - 2011-10-03 04:29:17 --> File loaded: application/views/common/header.php
DEBUG - 2011-10-03 04:29:17 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-10-03 04:29:17 --> File loaded: application/views/common/footer.php
DEBUG - 2011-10-03 04:29:17 --> File loaded: application/views/layout/main.php
DEBUG - 2011-10-03 04:29:17 --> Final output sent to browser
DEBUG - 2011-10-03 04:29:17 --> Total execution time: 0.2047
DEBUG - 2011-10-03 04:29:25 --> Config Class Initialized
DEBUG - 2011-10-03 04:29:25 --> Hooks Class Initialized
DEBUG - 2011-10-03 04:29:25 --> Utf8 Class Initialized
DEBUG - 2011-10-03 04:29:25 --> UTF-8 Support Enabled
DEBUG - 2011-10-03 04:29:25 --> URI Class Initialized
DEBUG - 2011-10-03 04:29:25 --> Router Class Initialized
ERROR - 2011-10-03 04:29:25 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-10-03 04:29:26 --> Config Class Initialized
DEBUG - 2011-10-03 04:29:26 --> Hooks Class Initialized
DEBUG - 2011-10-03 04:29:26 --> Utf8 Class Initialized
DEBUG - 2011-10-03 04:29:26 --> UTF-8 Support Enabled
DEBUG - 2011-10-03 04:29:26 --> URI Class Initialized
DEBUG - 2011-10-03 04:29:26 --> Router Class Initialized
DEBUG - 2011-10-03 04:29:26 --> Output Class Initialized
DEBUG - 2011-10-03 04:29:26 --> Input Class Initialized
DEBUG - 2011-10-03 04:29:26 --> Global POST and COOKIE data sanitized
DEBUG - 2011-10-03 04:29:26 --> Language Class Initialized
DEBUG - 2011-10-03 04:29:26 --> Loader Class Initialized
DEBUG - 2011-10-03 04:29:26 --> Controller Class Initialized
ERROR - 2011-10-03 04:29:26 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-10-03 04:29:26 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-10-03 04:29:26 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-10-03 04:29:26 --> Model Class Initialized
DEBUG - 2011-10-03 04:29:26 --> Model Class Initialized
DEBUG - 2011-10-03 04:29:26 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-10-03 04:29:26 --> Database Driver Class Initialized
DEBUG - 2011-10-03 04:29:26 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-10-03 04:29:26 --> Helper loaded: url_helper
DEBUG - 2011-10-03 04:29:26 --> File loaded: application/views/common/header.php
DEBUG - 2011-10-03 04:29:26 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-10-03 04:29:26 --> File loaded: application/views/common/footer.php
DEBUG - 2011-10-03 04:29:26 --> File loaded: application/views/layout/main.php
DEBUG - 2011-10-03 04:29:26 --> Final output sent to browser
DEBUG - 2011-10-03 04:29:26 --> Total execution time: 0.0344
DEBUG - 2011-10-03 04:29:33 --> Config Class Initialized
DEBUG - 2011-10-03 04:29:33 --> Hooks Class Initialized
DEBUG - 2011-10-03 04:29:33 --> Utf8 Class Initialized
DEBUG - 2011-10-03 04:29:33 --> UTF-8 Support Enabled
DEBUG - 2011-10-03 04:29:33 --> URI Class Initialized
DEBUG - 2011-10-03 04:29:33 --> Router Class Initialized
DEBUG - 2011-10-03 04:29:33 --> Output Class Initialized
DEBUG - 2011-10-03 04:29:33 --> Input Class Initialized
DEBUG - 2011-10-03 04:29:33 --> Global POST and COOKIE data sanitized
DEBUG - 2011-10-03 04:29:33 --> Language Class Initialized
DEBUG - 2011-10-03 04:29:33 --> Loader Class Initialized
DEBUG - 2011-10-03 04:29:33 --> Controller Class Initialized
DEBUG - 2011-10-03 04:29:33 --> Model Class Initialized
DEBUG - 2011-10-03 04:29:33 --> Model Class Initialized
DEBUG - 2011-10-03 04:29:33 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-10-03 04:29:33 --> Database Driver Class Initialized
DEBUG - 2011-10-03 04:29:34 --> Final output sent to browser
DEBUG - 2011-10-03 04:29:34 --> Total execution time: 0.7869
DEBUG - 2011-10-03 04:29:54 --> Config Class Initialized
DEBUG - 2011-10-03 04:29:54 --> Hooks Class Initialized
DEBUG - 2011-10-03 04:29:54 --> Utf8 Class Initialized
DEBUG - 2011-10-03 04:29:54 --> UTF-8 Support Enabled
DEBUG - 2011-10-03 04:29:54 --> URI Class Initialized
DEBUG - 2011-10-03 04:29:54 --> Router Class Initialized
ERROR - 2011-10-03 04:29:54 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-10-03 05:03:00 --> Config Class Initialized
DEBUG - 2011-10-03 05:03:00 --> Hooks Class Initialized
DEBUG - 2011-10-03 05:03:00 --> Utf8 Class Initialized
DEBUG - 2011-10-03 05:03:00 --> UTF-8 Support Enabled
DEBUG - 2011-10-03 05:03:00 --> URI Class Initialized
DEBUG - 2011-10-03 05:03:00 --> Router Class Initialized
DEBUG - 2011-10-03 05:03:00 --> Output Class Initialized
DEBUG - 2011-10-03 05:03:00 --> Input Class Initialized
DEBUG - 2011-10-03 05:03:00 --> Global POST and COOKIE data sanitized
DEBUG - 2011-10-03 05:03:00 --> Language Class Initialized
DEBUG - 2011-10-03 05:03:00 --> Loader Class Initialized
DEBUG - 2011-10-03 05:03:00 --> Controller Class Initialized
DEBUG - 2011-10-03 05:03:00 --> Model Class Initialized
DEBUG - 2011-10-03 05:03:00 --> Model Class Initialized
DEBUG - 2011-10-03 05:03:00 --> Model Class Initialized
DEBUG - 2011-10-03 05:03:00 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-10-03 05:03:00 --> Database Driver Class Initialized
DEBUG - 2011-10-03 05:03:01 --> File loaded: application/views/table/main.php
DEBUG - 2011-10-03 05:03:01 --> Helper loaded: url_helper
DEBUG - 2011-10-03 05:03:01 --> File loaded: application/views/common/header.php
DEBUG - 2011-10-03 05:03:01 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-10-03 05:03:01 --> File loaded: application/views/common/footer.php
DEBUG - 2011-10-03 05:03:01 --> File loaded: application/views/layout/main.php
DEBUG - 2011-10-03 05:03:01 --> Final output sent to browser
DEBUG - 2011-10-03 05:03:01 --> Total execution time: 1.2323
DEBUG - 2011-10-03 05:03:03 --> Config Class Initialized
DEBUG - 2011-10-03 05:03:03 --> Hooks Class Initialized
DEBUG - 2011-10-03 05:03:03 --> Utf8 Class Initialized
DEBUG - 2011-10-03 05:03:03 --> UTF-8 Support Enabled
DEBUG - 2011-10-03 05:03:03 --> URI Class Initialized
DEBUG - 2011-10-03 05:03:03 --> Router Class Initialized
ERROR - 2011-10-03 05:03:03 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-10-03 05:03:15 --> Config Class Initialized
DEBUG - 2011-10-03 05:03:15 --> Hooks Class Initialized
DEBUG - 2011-10-03 05:03:15 --> Utf8 Class Initialized
DEBUG - 2011-10-03 05:03:15 --> UTF-8 Support Enabled
DEBUG - 2011-10-03 05:03:15 --> URI Class Initialized
DEBUG - 2011-10-03 05:03:15 --> Router Class Initialized
DEBUG - 2011-10-03 05:03:15 --> Output Class Initialized
DEBUG - 2011-10-03 05:03:15 --> Input Class Initialized
DEBUG - 2011-10-03 05:03:15 --> Global POST and COOKIE data sanitized
DEBUG - 2011-10-03 05:03:15 --> Language Class Initialized
DEBUG - 2011-10-03 05:03:15 --> Loader Class Initialized
DEBUG - 2011-10-03 05:03:15 --> Controller Class Initialized
DEBUG - 2011-10-03 05:03:15 --> Model Class Initialized
DEBUG - 2011-10-03 05:03:15 --> Model Class Initialized
DEBUG - 2011-10-03 05:03:15 --> Model Class Initialized
DEBUG - 2011-10-03 05:03:15 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-10-03 05:03:15 --> Database Driver Class Initialized
DEBUG - 2011-10-03 05:03:16 --> File loaded: application/views/table/main.php
DEBUG - 2011-10-03 05:03:16 --> Helper loaded: url_helper
DEBUG - 2011-10-03 05:03:16 --> File loaded: application/views/common/header.php
DEBUG - 2011-10-03 05:03:16 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-10-03 05:03:16 --> File loaded: application/views/common/footer.php
DEBUG - 2011-10-03 05:03:16 --> File loaded: application/views/layout/main.php
DEBUG - 2011-10-03 05:03:16 --> Final output sent to browser
DEBUG - 2011-10-03 05:03:16 --> Total execution time: 0.5636
DEBUG - 2011-10-03 05:03:18 --> Config Class Initialized
DEBUG - 2011-10-03 05:03:18 --> Hooks Class Initialized
DEBUG - 2011-10-03 05:03:18 --> Utf8 Class Initialized
DEBUG - 2011-10-03 05:03:18 --> UTF-8 Support Enabled
DEBUG - 2011-10-03 05:03:18 --> URI Class Initialized
DEBUG - 2011-10-03 05:03:18 --> Router Class Initialized
ERROR - 2011-10-03 05:03:18 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-10-03 05:03:23 --> Config Class Initialized
DEBUG - 2011-10-03 05:03:23 --> Hooks Class Initialized
DEBUG - 2011-10-03 05:03:23 --> Utf8 Class Initialized
DEBUG - 2011-10-03 05:03:23 --> UTF-8 Support Enabled
DEBUG - 2011-10-03 05:03:23 --> URI Class Initialized
DEBUG - 2011-10-03 05:03:23 --> Router Class Initialized
ERROR - 2011-10-03 05:03:23 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-10-03 05:03:27 --> Config Class Initialized
DEBUG - 2011-10-03 05:03:27 --> Hooks Class Initialized
DEBUG - 2011-10-03 05:03:27 --> Utf8 Class Initialized
DEBUG - 2011-10-03 05:03:27 --> UTF-8 Support Enabled
DEBUG - 2011-10-03 05:03:27 --> URI Class Initialized
DEBUG - 2011-10-03 05:03:27 --> Router Class Initialized
DEBUG - 2011-10-03 05:03:27 --> Output Class Initialized
DEBUG - 2011-10-03 05:03:27 --> Input Class Initialized
DEBUG - 2011-10-03 05:03:27 --> Global POST and COOKIE data sanitized
DEBUG - 2011-10-03 05:03:27 --> Language Class Initialized
DEBUG - 2011-10-03 05:03:27 --> Loader Class Initialized
DEBUG - 2011-10-03 05:03:27 --> Controller Class Initialized
ERROR - 2011-10-03 05:03:27 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-10-03 05:03:27 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-10-03 05:03:27 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-10-03 05:03:27 --> Model Class Initialized
DEBUG - 2011-10-03 05:03:27 --> Model Class Initialized
DEBUG - 2011-10-03 05:03:27 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-10-03 05:03:27 --> Database Driver Class Initialized
DEBUG - 2011-10-03 05:03:27 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-10-03 05:03:27 --> Helper loaded: url_helper
DEBUG - 2011-10-03 05:03:27 --> File loaded: application/views/common/header.php
DEBUG - 2011-10-03 05:03:27 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-10-03 05:03:27 --> File loaded: application/views/common/footer.php
DEBUG - 2011-10-03 05:03:27 --> File loaded: application/views/layout/main.php
DEBUG - 2011-10-03 05:03:27 --> Final output sent to browser
DEBUG - 2011-10-03 05:03:27 --> Total execution time: 0.1381
DEBUG - 2011-10-03 05:03:28 --> Config Class Initialized
DEBUG - 2011-10-03 05:03:28 --> Hooks Class Initialized
DEBUG - 2011-10-03 05:03:28 --> Utf8 Class Initialized
DEBUG - 2011-10-03 05:03:28 --> UTF-8 Support Enabled
DEBUG - 2011-10-03 05:03:28 --> URI Class Initialized
DEBUG - 2011-10-03 05:03:28 --> Router Class Initialized
DEBUG - 2011-10-03 05:03:28 --> Output Class Initialized
DEBUG - 2011-10-03 05:03:28 --> Input Class Initialized
DEBUG - 2011-10-03 05:03:28 --> Global POST and COOKIE data sanitized
DEBUG - 2011-10-03 05:03:28 --> Language Class Initialized
DEBUG - 2011-10-03 05:03:28 --> Loader Class Initialized
DEBUG - 2011-10-03 05:03:28 --> Controller Class Initialized
DEBUG - 2011-10-03 05:03:28 --> Model Class Initialized
DEBUG - 2011-10-03 05:03:28 --> Model Class Initialized
DEBUG - 2011-10-03 05:03:28 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-10-03 05:03:28 --> Database Driver Class Initialized
DEBUG - 2011-10-03 05:03:29 --> Final output sent to browser
DEBUG - 2011-10-03 05:03:29 --> Total execution time: 0.6337
DEBUG - 2011-10-03 05:03:31 --> Config Class Initialized
DEBUG - 2011-10-03 05:03:31 --> Hooks Class Initialized
DEBUG - 2011-10-03 05:03:31 --> Utf8 Class Initialized
DEBUG - 2011-10-03 05:03:31 --> UTF-8 Support Enabled
DEBUG - 2011-10-03 05:03:31 --> URI Class Initialized
DEBUG - 2011-10-03 05:03:31 --> Router Class Initialized
ERROR - 2011-10-03 05:03:31 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-10-03 05:03:39 --> Config Class Initialized
DEBUG - 2011-10-03 05:03:39 --> Hooks Class Initialized
DEBUG - 2011-10-03 05:03:39 --> Utf8 Class Initialized
DEBUG - 2011-10-03 05:03:39 --> UTF-8 Support Enabled
DEBUG - 2011-10-03 05:03:39 --> URI Class Initialized
DEBUG - 2011-10-03 05:03:39 --> Router Class Initialized
DEBUG - 2011-10-03 05:03:39 --> Output Class Initialized
DEBUG - 2011-10-03 05:03:39 --> Input Class Initialized
DEBUG - 2011-10-03 05:03:39 --> Global POST and COOKIE data sanitized
DEBUG - 2011-10-03 05:03:39 --> Language Class Initialized
DEBUG - 2011-10-03 05:03:39 --> Loader Class Initialized
DEBUG - 2011-10-03 05:03:39 --> Controller Class Initialized
ERROR - 2011-10-03 05:03:39 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-10-03 05:03:39 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-10-03 05:03:39 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-10-03 05:03:39 --> Model Class Initialized
DEBUG - 2011-10-03 05:03:39 --> Model Class Initialized
DEBUG - 2011-10-03 05:03:39 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-10-03 05:03:39 --> Database Driver Class Initialized
DEBUG - 2011-10-03 05:03:39 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-10-03 05:03:39 --> Helper loaded: url_helper
DEBUG - 2011-10-03 05:03:39 --> File loaded: application/views/common/header.php
DEBUG - 2011-10-03 05:03:39 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-10-03 05:03:39 --> File loaded: application/views/common/footer.php
DEBUG - 2011-10-03 05:03:39 --> File loaded: application/views/layout/main.php
DEBUG - 2011-10-03 05:03:39 --> Final output sent to browser
DEBUG - 2011-10-03 05:03:39 --> Total execution time: 0.0311
DEBUG - 2011-10-03 05:03:39 --> Config Class Initialized
DEBUG - 2011-10-03 05:03:39 --> Hooks Class Initialized
DEBUG - 2011-10-03 05:03:39 --> Utf8 Class Initialized
DEBUG - 2011-10-03 05:03:39 --> UTF-8 Support Enabled
DEBUG - 2011-10-03 05:03:39 --> URI Class Initialized
DEBUG - 2011-10-03 05:03:39 --> Router Class Initialized
DEBUG - 2011-10-03 05:03:39 --> Output Class Initialized
DEBUG - 2011-10-03 05:03:39 --> Input Class Initialized
DEBUG - 2011-10-03 05:03:39 --> Global POST and COOKIE data sanitized
DEBUG - 2011-10-03 05:03:39 --> Language Class Initialized
DEBUG - 2011-10-03 05:03:39 --> Loader Class Initialized
DEBUG - 2011-10-03 05:03:39 --> Controller Class Initialized
DEBUG - 2011-10-03 05:03:39 --> Model Class Initialized
DEBUG - 2011-10-03 05:03:39 --> Model Class Initialized
DEBUG - 2011-10-03 05:03:39 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-10-03 05:03:39 --> Database Driver Class Initialized
DEBUG - 2011-10-03 05:03:40 --> Final output sent to browser
DEBUG - 2011-10-03 05:03:40 --> Total execution time: 0.6469
DEBUG - 2011-10-03 05:03:41 --> Config Class Initialized
DEBUG - 2011-10-03 05:03:41 --> Hooks Class Initialized
DEBUG - 2011-10-03 05:03:41 --> Utf8 Class Initialized
DEBUG - 2011-10-03 05:03:41 --> UTF-8 Support Enabled
DEBUG - 2011-10-03 05:03:41 --> URI Class Initialized
DEBUG - 2011-10-03 05:03:41 --> Router Class Initialized
ERROR - 2011-10-03 05:03:41 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-10-03 05:03:50 --> Config Class Initialized
DEBUG - 2011-10-03 05:03:50 --> Hooks Class Initialized
DEBUG - 2011-10-03 05:03:50 --> Utf8 Class Initialized
DEBUG - 2011-10-03 05:03:50 --> UTF-8 Support Enabled
DEBUG - 2011-10-03 05:03:50 --> URI Class Initialized
DEBUG - 2011-10-03 05:03:50 --> Router Class Initialized
DEBUG - 2011-10-03 05:03:50 --> Output Class Initialized
DEBUG - 2011-10-03 05:03:50 --> Input Class Initialized
DEBUG - 2011-10-03 05:03:50 --> Global POST and COOKIE data sanitized
DEBUG - 2011-10-03 05:03:50 --> Language Class Initialized
DEBUG - 2011-10-03 05:03:50 --> Loader Class Initialized
DEBUG - 2011-10-03 05:03:50 --> Controller Class Initialized
ERROR - 2011-10-03 05:03:50 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-10-03 05:03:50 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-10-03 05:03:50 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-10-03 05:03:50 --> Model Class Initialized
DEBUG - 2011-10-03 05:03:50 --> Model Class Initialized
DEBUG - 2011-10-03 05:03:50 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-10-03 05:03:50 --> Database Driver Class Initialized
DEBUG - 2011-10-03 05:03:50 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-10-03 05:03:50 --> Helper loaded: url_helper
DEBUG - 2011-10-03 05:03:50 --> File loaded: application/views/common/header.php
DEBUG - 2011-10-03 05:03:50 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-10-03 05:03:50 --> File loaded: application/views/common/footer.php
DEBUG - 2011-10-03 05:03:50 --> File loaded: application/views/layout/main.php
DEBUG - 2011-10-03 05:03:50 --> Final output sent to browser
DEBUG - 2011-10-03 05:03:50 --> Total execution time: 0.0426
DEBUG - 2011-10-03 05:03:50 --> Config Class Initialized
DEBUG - 2011-10-03 05:03:50 --> Hooks Class Initialized
DEBUG - 2011-10-03 05:03:50 --> Utf8 Class Initialized
DEBUG - 2011-10-03 05:03:50 --> UTF-8 Support Enabled
DEBUG - 2011-10-03 05:03:50 --> URI Class Initialized
DEBUG - 2011-10-03 05:03:50 --> Router Class Initialized
DEBUG - 2011-10-03 05:03:50 --> Output Class Initialized
DEBUG - 2011-10-03 05:03:50 --> Input Class Initialized
DEBUG - 2011-10-03 05:03:50 --> Global POST and COOKIE data sanitized
DEBUG - 2011-10-03 05:03:50 --> Language Class Initialized
DEBUG - 2011-10-03 05:03:50 --> Loader Class Initialized
DEBUG - 2011-10-03 05:03:50 --> Controller Class Initialized
DEBUG - 2011-10-03 05:03:50 --> Model Class Initialized
DEBUG - 2011-10-03 05:03:50 --> Model Class Initialized
DEBUG - 2011-10-03 05:03:50 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-10-03 05:03:50 --> Database Driver Class Initialized
DEBUG - 2011-10-03 05:03:51 --> Final output sent to browser
DEBUG - 2011-10-03 05:03:51 --> Total execution time: 0.6856
DEBUG - 2011-10-03 05:03:53 --> Config Class Initialized
DEBUG - 2011-10-03 05:03:53 --> Hooks Class Initialized
DEBUG - 2011-10-03 05:03:53 --> Utf8 Class Initialized
DEBUG - 2011-10-03 05:03:53 --> UTF-8 Support Enabled
DEBUG - 2011-10-03 05:03:53 --> URI Class Initialized
DEBUG - 2011-10-03 05:03:53 --> Router Class Initialized
ERROR - 2011-10-03 05:03:53 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-10-03 05:04:16 --> Config Class Initialized
DEBUG - 2011-10-03 05:04:16 --> Hooks Class Initialized
DEBUG - 2011-10-03 05:04:16 --> Utf8 Class Initialized
DEBUG - 2011-10-03 05:04:16 --> UTF-8 Support Enabled
DEBUG - 2011-10-03 05:04:16 --> URI Class Initialized
DEBUG - 2011-10-03 05:04:16 --> Router Class Initialized
DEBUG - 2011-10-03 05:04:16 --> Output Class Initialized
DEBUG - 2011-10-03 05:04:16 --> Input Class Initialized
DEBUG - 2011-10-03 05:04:16 --> Global POST and COOKIE data sanitized
DEBUG - 2011-10-03 05:04:16 --> Language Class Initialized
DEBUG - 2011-10-03 05:04:16 --> Loader Class Initialized
DEBUG - 2011-10-03 05:04:16 --> Controller Class Initialized
ERROR - 2011-10-03 05:04:16 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-10-03 05:04:16 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-10-03 05:04:16 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-10-03 05:04:16 --> Model Class Initialized
DEBUG - 2011-10-03 05:04:16 --> Model Class Initialized
DEBUG - 2011-10-03 05:04:16 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-10-03 05:04:16 --> Database Driver Class Initialized
DEBUG - 2011-10-03 05:04:16 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-10-03 05:04:16 --> Helper loaded: url_helper
DEBUG - 2011-10-03 05:04:16 --> File loaded: application/views/common/header.php
DEBUG - 2011-10-03 05:04:16 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-10-03 05:04:16 --> File loaded: application/views/common/footer.php
DEBUG - 2011-10-03 05:04:16 --> File loaded: application/views/layout/main.php
DEBUG - 2011-10-03 05:04:16 --> Final output sent to browser
DEBUG - 2011-10-03 05:04:16 --> Total execution time: 0.0359
DEBUG - 2011-10-03 05:04:17 --> Config Class Initialized
DEBUG - 2011-10-03 05:04:17 --> Hooks Class Initialized
DEBUG - 2011-10-03 05:04:17 --> Utf8 Class Initialized
DEBUG - 2011-10-03 05:04:17 --> UTF-8 Support Enabled
DEBUG - 2011-10-03 05:04:17 --> URI Class Initialized
DEBUG - 2011-10-03 05:04:17 --> Router Class Initialized
DEBUG - 2011-10-03 05:04:17 --> Output Class Initialized
DEBUG - 2011-10-03 05:04:17 --> Input Class Initialized
DEBUG - 2011-10-03 05:04:17 --> Global POST and COOKIE data sanitized
DEBUG - 2011-10-03 05:04:17 --> Language Class Initialized
DEBUG - 2011-10-03 05:04:17 --> Loader Class Initialized
DEBUG - 2011-10-03 05:04:17 --> Controller Class Initialized
DEBUG - 2011-10-03 05:04:17 --> Model Class Initialized
DEBUG - 2011-10-03 05:04:17 --> Model Class Initialized
DEBUG - 2011-10-03 05:04:17 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-10-03 05:04:17 --> Database Driver Class Initialized
DEBUG - 2011-10-03 05:04:18 --> Final output sent to browser
DEBUG - 2011-10-03 05:04:18 --> Total execution time: 0.7969
DEBUG - 2011-10-03 05:04:20 --> Config Class Initialized
DEBUG - 2011-10-03 05:04:20 --> Hooks Class Initialized
DEBUG - 2011-10-03 05:04:20 --> Utf8 Class Initialized
DEBUG - 2011-10-03 05:04:20 --> UTF-8 Support Enabled
DEBUG - 2011-10-03 05:04:20 --> URI Class Initialized
DEBUG - 2011-10-03 05:04:20 --> Router Class Initialized
ERROR - 2011-10-03 05:04:20 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-10-03 05:04:31 --> Config Class Initialized
DEBUG - 2011-10-03 05:04:31 --> Hooks Class Initialized
DEBUG - 2011-10-03 05:04:31 --> Utf8 Class Initialized
DEBUG - 2011-10-03 05:04:31 --> UTF-8 Support Enabled
DEBUG - 2011-10-03 05:04:31 --> URI Class Initialized
DEBUG - 2011-10-03 05:04:31 --> Router Class Initialized
DEBUG - 2011-10-03 05:04:31 --> Output Class Initialized
DEBUG - 2011-10-03 05:04:31 --> Input Class Initialized
DEBUG - 2011-10-03 05:04:31 --> Global POST and COOKIE data sanitized
DEBUG - 2011-10-03 05:04:31 --> Language Class Initialized
DEBUG - 2011-10-03 05:04:31 --> Loader Class Initialized
DEBUG - 2011-10-03 05:04:31 --> Controller Class Initialized
ERROR - 2011-10-03 05:04:31 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-10-03 05:04:31 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-10-03 05:04:31 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-10-03 05:04:31 --> Model Class Initialized
DEBUG - 2011-10-03 05:04:31 --> Model Class Initialized
DEBUG - 2011-10-03 05:04:31 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-10-03 05:04:31 --> Database Driver Class Initialized
DEBUG - 2011-10-03 05:04:31 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-10-03 05:04:31 --> Helper loaded: url_helper
DEBUG - 2011-10-03 05:04:31 --> File loaded: application/views/common/header.php
DEBUG - 2011-10-03 05:04:31 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-10-03 05:04:31 --> File loaded: application/views/common/footer.php
DEBUG - 2011-10-03 05:04:31 --> File loaded: application/views/layout/main.php
DEBUG - 2011-10-03 05:04:31 --> Final output sent to browser
DEBUG - 2011-10-03 05:04:31 --> Total execution time: 0.1899
DEBUG - 2011-10-03 05:04:32 --> Config Class Initialized
DEBUG - 2011-10-03 05:04:32 --> Hooks Class Initialized
DEBUG - 2011-10-03 05:04:32 --> Utf8 Class Initialized
DEBUG - 2011-10-03 05:04:32 --> UTF-8 Support Enabled
DEBUG - 2011-10-03 05:04:32 --> URI Class Initialized
DEBUG - 2011-10-03 05:04:32 --> Router Class Initialized
DEBUG - 2011-10-03 05:04:32 --> Output Class Initialized
DEBUG - 2011-10-03 05:04:32 --> Input Class Initialized
DEBUG - 2011-10-03 05:04:32 --> Global POST and COOKIE data sanitized
DEBUG - 2011-10-03 05:04:32 --> Language Class Initialized
DEBUG - 2011-10-03 05:04:32 --> Loader Class Initialized
DEBUG - 2011-10-03 05:04:32 --> Controller Class Initialized
DEBUG - 2011-10-03 05:04:32 --> Model Class Initialized
DEBUG - 2011-10-03 05:04:32 --> Model Class Initialized
DEBUG - 2011-10-03 05:04:32 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-10-03 05:04:32 --> Database Driver Class Initialized
DEBUG - 2011-10-03 05:04:33 --> Final output sent to browser
DEBUG - 2011-10-03 05:04:33 --> Total execution time: 0.7900
DEBUG - 2011-10-03 05:04:35 --> Config Class Initialized
DEBUG - 2011-10-03 05:04:35 --> Hooks Class Initialized
DEBUG - 2011-10-03 05:04:35 --> Utf8 Class Initialized
DEBUG - 2011-10-03 05:04:35 --> UTF-8 Support Enabled
DEBUG - 2011-10-03 05:04:35 --> URI Class Initialized
DEBUG - 2011-10-03 05:04:35 --> Router Class Initialized
ERROR - 2011-10-03 05:04:35 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-10-03 05:06:03 --> Config Class Initialized
DEBUG - 2011-10-03 05:06:03 --> Hooks Class Initialized
DEBUG - 2011-10-03 05:06:03 --> Utf8 Class Initialized
DEBUG - 2011-10-03 05:06:03 --> UTF-8 Support Enabled
DEBUG - 2011-10-03 05:06:03 --> URI Class Initialized
DEBUG - 2011-10-03 05:06:03 --> Router Class Initialized
DEBUG - 2011-10-03 05:06:03 --> Output Class Initialized
DEBUG - 2011-10-03 05:06:03 --> Input Class Initialized
DEBUG - 2011-10-03 05:06:03 --> Global POST and COOKIE data sanitized
DEBUG - 2011-10-03 05:06:03 --> Language Class Initialized
DEBUG - 2011-10-03 05:06:03 --> Loader Class Initialized
DEBUG - 2011-10-03 05:06:03 --> Controller Class Initialized
DEBUG - 2011-10-03 05:06:03 --> Model Class Initialized
DEBUG - 2011-10-03 05:06:03 --> Model Class Initialized
DEBUG - 2011-10-03 05:06:03 --> Model Class Initialized
DEBUG - 2011-10-03 05:06:03 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-10-03 05:06:03 --> Database Driver Class Initialized
DEBUG - 2011-10-03 05:06:03 --> File loaded: application/views/table/main.php
DEBUG - 2011-10-03 05:06:03 --> Helper loaded: url_helper
DEBUG - 2011-10-03 05:06:03 --> File loaded: application/views/common/header.php
DEBUG - 2011-10-03 05:06:03 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-10-03 05:06:03 --> File loaded: application/views/common/footer.php
DEBUG - 2011-10-03 05:06:03 --> File loaded: application/views/layout/main.php
DEBUG - 2011-10-03 05:06:03 --> Final output sent to browser
DEBUG - 2011-10-03 05:06:03 --> Total execution time: 0.0478
DEBUG - 2011-10-03 05:06:07 --> Config Class Initialized
DEBUG - 2011-10-03 05:06:07 --> Hooks Class Initialized
DEBUG - 2011-10-03 05:06:07 --> Utf8 Class Initialized
DEBUG - 2011-10-03 05:06:07 --> UTF-8 Support Enabled
DEBUG - 2011-10-03 05:06:07 --> URI Class Initialized
DEBUG - 2011-10-03 05:06:07 --> Router Class Initialized
DEBUG - 2011-10-03 05:06:07 --> Output Class Initialized
DEBUG - 2011-10-03 05:06:07 --> Input Class Initialized
DEBUG - 2011-10-03 05:06:07 --> Global POST and COOKIE data sanitized
DEBUG - 2011-10-03 05:06:07 --> Language Class Initialized
DEBUG - 2011-10-03 05:06:07 --> Loader Class Initialized
DEBUG - 2011-10-03 05:06:07 --> Controller Class Initialized
ERROR - 2011-10-03 05:06:07 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-10-03 05:06:07 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-10-03 05:06:07 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-10-03 05:06:07 --> Model Class Initialized
DEBUG - 2011-10-03 05:06:07 --> Model Class Initialized
DEBUG - 2011-10-03 05:06:07 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-10-03 05:06:07 --> Database Driver Class Initialized
DEBUG - 2011-10-03 05:06:07 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-10-03 05:06:07 --> Helper loaded: url_helper
DEBUG - 2011-10-03 05:06:07 --> File loaded: application/views/common/header.php
DEBUG - 2011-10-03 05:06:07 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-10-03 05:06:07 --> File loaded: application/views/common/footer.php
DEBUG - 2011-10-03 05:06:07 --> File loaded: application/views/layout/main.php
DEBUG - 2011-10-03 05:06:07 --> Final output sent to browser
DEBUG - 2011-10-03 05:06:07 --> Total execution time: 0.0332
DEBUG - 2011-10-03 05:06:18 --> Config Class Initialized
DEBUG - 2011-10-03 05:06:18 --> Hooks Class Initialized
DEBUG - 2011-10-03 05:06:18 --> Utf8 Class Initialized
DEBUG - 2011-10-03 05:06:18 --> UTF-8 Support Enabled
DEBUG - 2011-10-03 05:06:18 --> URI Class Initialized
DEBUG - 2011-10-03 05:06:18 --> Router Class Initialized
DEBUG - 2011-10-03 05:06:18 --> Output Class Initialized
DEBUG - 2011-10-03 05:06:18 --> Input Class Initialized
DEBUG - 2011-10-03 05:06:18 --> Global POST and COOKIE data sanitized
DEBUG - 2011-10-03 05:06:18 --> Language Class Initialized
DEBUG - 2011-10-03 05:06:18 --> Loader Class Initialized
DEBUG - 2011-10-03 05:06:18 --> Controller Class Initialized
ERROR - 2011-10-03 05:06:18 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-10-03 05:06:18 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-10-03 05:06:18 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-10-03 05:06:18 --> Model Class Initialized
DEBUG - 2011-10-03 05:06:18 --> Model Class Initialized
DEBUG - 2011-10-03 05:06:18 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-10-03 05:06:18 --> Database Driver Class Initialized
DEBUG - 2011-10-03 05:06:18 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-10-03 05:06:18 --> Helper loaded: url_helper
DEBUG - 2011-10-03 05:06:18 --> File loaded: application/views/common/header.php
DEBUG - 2011-10-03 05:06:18 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-10-03 05:06:18 --> File loaded: application/views/common/footer.php
DEBUG - 2011-10-03 05:06:18 --> File loaded: application/views/layout/main.php
DEBUG - 2011-10-03 05:06:18 --> Final output sent to browser
DEBUG - 2011-10-03 05:06:18 --> Total execution time: 0.1156
DEBUG - 2011-10-03 05:30:58 --> Config Class Initialized
DEBUG - 2011-10-03 05:30:58 --> Hooks Class Initialized
DEBUG - 2011-10-03 05:30:58 --> Utf8 Class Initialized
DEBUG - 2011-10-03 05:30:58 --> UTF-8 Support Enabled
DEBUG - 2011-10-03 05:30:58 --> URI Class Initialized
DEBUG - 2011-10-03 05:30:58 --> Router Class Initialized
DEBUG - 2011-10-03 05:30:58 --> Output Class Initialized
DEBUG - 2011-10-03 05:30:58 --> Input Class Initialized
DEBUG - 2011-10-03 05:30:58 --> Global POST and COOKIE data sanitized
DEBUG - 2011-10-03 05:30:58 --> Language Class Initialized
DEBUG - 2011-10-03 05:30:58 --> Loader Class Initialized
DEBUG - 2011-10-03 05:30:58 --> Controller Class Initialized
ERROR - 2011-10-03 05:30:58 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-10-03 05:30:58 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-10-03 05:30:58 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-10-03 05:30:58 --> Model Class Initialized
DEBUG - 2011-10-03 05:30:58 --> Model Class Initialized
DEBUG - 2011-10-03 05:30:58 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-10-03 05:30:58 --> Database Driver Class Initialized
DEBUG - 2011-10-03 05:30:58 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-10-03 05:30:58 --> Helper loaded: url_helper
DEBUG - 2011-10-03 05:30:58 --> File loaded: application/views/common/header.php
DEBUG - 2011-10-03 05:30:58 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-10-03 05:30:58 --> File loaded: application/views/common/footer.php
DEBUG - 2011-10-03 05:30:58 --> File loaded: application/views/layout/main.php
DEBUG - 2011-10-03 05:30:58 --> Final output sent to browser
DEBUG - 2011-10-03 05:30:58 --> Total execution time: 0.0677
DEBUG - 2011-10-03 05:31:00 --> Config Class Initialized
DEBUG - 2011-10-03 05:31:00 --> Hooks Class Initialized
DEBUG - 2011-10-03 05:31:00 --> Utf8 Class Initialized
DEBUG - 2011-10-03 05:31:00 --> UTF-8 Support Enabled
DEBUG - 2011-10-03 05:31:00 --> URI Class Initialized
DEBUG - 2011-10-03 05:31:00 --> Router Class Initialized
DEBUG - 2011-10-03 05:31:00 --> Output Class Initialized
DEBUG - 2011-10-03 05:31:00 --> Input Class Initialized
DEBUG - 2011-10-03 05:31:00 --> Global POST and COOKIE data sanitized
DEBUG - 2011-10-03 05:31:00 --> Language Class Initialized
DEBUG - 2011-10-03 05:31:00 --> Loader Class Initialized
DEBUG - 2011-10-03 05:31:00 --> Controller Class Initialized
DEBUG - 2011-10-03 05:31:00 --> Model Class Initialized
DEBUG - 2011-10-03 05:31:00 --> Model Class Initialized
DEBUG - 2011-10-03 05:31:00 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-10-03 05:31:00 --> Database Driver Class Initialized
DEBUG - 2011-10-03 05:31:01 --> Final output sent to browser
DEBUG - 2011-10-03 05:31:01 --> Total execution time: 0.8990
DEBUG - 2011-10-03 05:31:03 --> Config Class Initialized
DEBUG - 2011-10-03 05:31:03 --> Hooks Class Initialized
DEBUG - 2011-10-03 05:31:03 --> Utf8 Class Initialized
DEBUG - 2011-10-03 05:31:03 --> UTF-8 Support Enabled
DEBUG - 2011-10-03 05:31:03 --> URI Class Initialized
DEBUG - 2011-10-03 05:31:03 --> Router Class Initialized
ERROR - 2011-10-03 05:31:03 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-10-03 05:31:07 --> Config Class Initialized
DEBUG - 2011-10-03 05:31:07 --> Hooks Class Initialized
DEBUG - 2011-10-03 05:31:07 --> Utf8 Class Initialized
DEBUG - 2011-10-03 05:31:07 --> UTF-8 Support Enabled
DEBUG - 2011-10-03 05:31:07 --> URI Class Initialized
DEBUG - 2011-10-03 05:31:07 --> Router Class Initialized
DEBUG - 2011-10-03 05:31:07 --> Output Class Initialized
DEBUG - 2011-10-03 05:31:07 --> Input Class Initialized
DEBUG - 2011-10-03 05:31:07 --> Global POST and COOKIE data sanitized
DEBUG - 2011-10-03 05:31:07 --> Language Class Initialized
DEBUG - 2011-10-03 05:31:07 --> Loader Class Initialized
DEBUG - 2011-10-03 05:31:07 --> Controller Class Initialized
DEBUG - 2011-10-03 05:31:07 --> Model Class Initialized
DEBUG - 2011-10-03 05:31:07 --> Model Class Initialized
DEBUG - 2011-10-03 05:31:07 --> Model Class Initialized
DEBUG - 2011-10-03 05:31:07 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-10-03 05:31:07 --> Database Driver Class Initialized
DEBUG - 2011-10-03 05:31:08 --> File loaded: application/views/table/main.php
DEBUG - 2011-10-03 05:31:08 --> Helper loaded: url_helper
DEBUG - 2011-10-03 05:31:08 --> File loaded: application/views/common/header.php
DEBUG - 2011-10-03 05:31:08 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-10-03 05:31:08 --> File loaded: application/views/common/footer.php
DEBUG - 2011-10-03 05:31:08 --> File loaded: application/views/layout/main.php
DEBUG - 2011-10-03 05:31:08 --> Final output sent to browser
DEBUG - 2011-10-03 05:31:08 --> Total execution time: 1.3565
DEBUG - 2011-10-03 05:31:11 --> Config Class Initialized
DEBUG - 2011-10-03 05:31:11 --> Hooks Class Initialized
DEBUG - 2011-10-03 05:31:11 --> Utf8 Class Initialized
DEBUG - 2011-10-03 05:31:11 --> UTF-8 Support Enabled
DEBUG - 2011-10-03 05:31:11 --> URI Class Initialized
DEBUG - 2011-10-03 05:31:11 --> Router Class Initialized
ERROR - 2011-10-03 05:31:11 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-10-03 05:31:34 --> Config Class Initialized
DEBUG - 2011-10-03 05:31:34 --> Hooks Class Initialized
DEBUG - 2011-10-03 05:31:34 --> Utf8 Class Initialized
DEBUG - 2011-10-03 05:31:34 --> UTF-8 Support Enabled
DEBUG - 2011-10-03 05:31:34 --> URI Class Initialized
DEBUG - 2011-10-03 05:31:34 --> Router Class Initialized
DEBUG - 2011-10-03 05:31:34 --> Output Class Initialized
DEBUG - 2011-10-03 05:31:34 --> Input Class Initialized
DEBUG - 2011-10-03 05:31:34 --> Global POST and COOKIE data sanitized
DEBUG - 2011-10-03 05:31:34 --> Language Class Initialized
DEBUG - 2011-10-03 05:31:34 --> Loader Class Initialized
DEBUG - 2011-10-03 05:31:34 --> Controller Class Initialized
DEBUG - 2011-10-03 05:31:34 --> Model Class Initialized
DEBUG - 2011-10-03 05:31:34 --> Model Class Initialized
DEBUG - 2011-10-03 05:31:34 --> Model Class Initialized
DEBUG - 2011-10-03 05:31:34 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-10-03 05:31:34 --> Database Driver Class Initialized
DEBUG - 2011-10-03 05:31:35 --> File loaded: application/views/table/main.php
DEBUG - 2011-10-03 05:31:35 --> Helper loaded: url_helper
DEBUG - 2011-10-03 05:31:35 --> File loaded: application/views/common/header.php
DEBUG - 2011-10-03 05:31:35 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-10-03 05:31:35 --> File loaded: application/views/common/footer.php
DEBUG - 2011-10-03 05:31:35 --> File loaded: application/views/layout/main.php
DEBUG - 2011-10-03 05:31:35 --> Final output sent to browser
DEBUG - 2011-10-03 05:31:35 --> Total execution time: 0.7313
DEBUG - 2011-10-03 05:31:37 --> Config Class Initialized
DEBUG - 2011-10-03 05:31:37 --> Hooks Class Initialized
DEBUG - 2011-10-03 05:31:37 --> Utf8 Class Initialized
DEBUG - 2011-10-03 05:31:37 --> UTF-8 Support Enabled
DEBUG - 2011-10-03 05:31:37 --> URI Class Initialized
DEBUG - 2011-10-03 05:31:37 --> Router Class Initialized
ERROR - 2011-10-03 05:31:37 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-10-03 05:31:41 --> Config Class Initialized
DEBUG - 2011-10-03 05:31:41 --> Hooks Class Initialized
DEBUG - 2011-10-03 05:31:41 --> Utf8 Class Initialized
DEBUG - 2011-10-03 05:31:41 --> UTF-8 Support Enabled
DEBUG - 2011-10-03 05:31:41 --> URI Class Initialized
DEBUG - 2011-10-03 05:31:41 --> Router Class Initialized
DEBUG - 2011-10-03 05:31:41 --> Output Class Initialized
DEBUG - 2011-10-03 05:31:41 --> Input Class Initialized
DEBUG - 2011-10-03 05:31:41 --> Global POST and COOKIE data sanitized
DEBUG - 2011-10-03 05:31:41 --> Language Class Initialized
DEBUG - 2011-10-03 05:31:41 --> Loader Class Initialized
DEBUG - 2011-10-03 05:31:41 --> Controller Class Initialized
DEBUG - 2011-10-03 05:31:41 --> Model Class Initialized
DEBUG - 2011-10-03 05:31:41 --> Model Class Initialized
DEBUG - 2011-10-03 05:31:41 --> Model Class Initialized
DEBUG - 2011-10-03 05:31:41 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-10-03 05:31:41 --> Database Driver Class Initialized
DEBUG - 2011-10-03 05:31:43 --> File loaded: application/views/table/main.php
DEBUG - 2011-10-03 05:31:43 --> Helper loaded: url_helper
DEBUG - 2011-10-03 05:31:43 --> File loaded: application/views/common/header.php
DEBUG - 2011-10-03 05:31:43 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-10-03 05:31:43 --> File loaded: application/views/common/footer.php
DEBUG - 2011-10-03 05:31:43 --> File loaded: application/views/layout/main.php
DEBUG - 2011-10-03 05:31:43 --> Final output sent to browser
DEBUG - 2011-10-03 05:31:43 --> Total execution time: 1.3430
DEBUG - 2011-10-03 05:31:45 --> Config Class Initialized
DEBUG - 2011-10-03 05:31:45 --> Hooks Class Initialized
DEBUG - 2011-10-03 05:31:45 --> Utf8 Class Initialized
DEBUG - 2011-10-03 05:31:45 --> UTF-8 Support Enabled
DEBUG - 2011-10-03 05:31:45 --> URI Class Initialized
DEBUG - 2011-10-03 05:31:45 --> Router Class Initialized
ERROR - 2011-10-03 05:31:45 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-10-03 05:31:47 --> Config Class Initialized
DEBUG - 2011-10-03 05:31:47 --> Hooks Class Initialized
DEBUG - 2011-10-03 05:31:47 --> Utf8 Class Initialized
DEBUG - 2011-10-03 05:31:47 --> UTF-8 Support Enabled
DEBUG - 2011-10-03 05:31:47 --> URI Class Initialized
DEBUG - 2011-10-03 05:31:47 --> Router Class Initialized
DEBUG - 2011-10-03 05:31:47 --> Output Class Initialized
DEBUG - 2011-10-03 05:31:47 --> Input Class Initialized
DEBUG - 2011-10-03 05:31:47 --> Global POST and COOKIE data sanitized
DEBUG - 2011-10-03 05:31:47 --> Language Class Initialized
DEBUG - 2011-10-03 05:31:47 --> Loader Class Initialized
DEBUG - 2011-10-03 05:31:47 --> Controller Class Initialized
DEBUG - 2011-10-03 05:31:47 --> Model Class Initialized
DEBUG - 2011-10-03 05:31:47 --> Model Class Initialized
DEBUG - 2011-10-03 05:31:47 --> Model Class Initialized
DEBUG - 2011-10-03 05:31:47 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-10-03 05:31:48 --> Database Driver Class Initialized
DEBUG - 2011-10-03 05:31:48 --> File loaded: application/views/table/main.php
DEBUG - 2011-10-03 05:31:48 --> Helper loaded: url_helper
DEBUG - 2011-10-03 05:31:48 --> File loaded: application/views/common/header.php
DEBUG - 2011-10-03 05:31:48 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-10-03 05:31:48 --> File loaded: application/views/common/footer.php
DEBUG - 2011-10-03 05:31:48 --> File loaded: application/views/layout/main.php
DEBUG - 2011-10-03 05:31:48 --> Final output sent to browser
DEBUG - 2011-10-03 05:31:48 --> Total execution time: 0.0458
DEBUG - 2011-10-03 05:31:51 --> Config Class Initialized
DEBUG - 2011-10-03 05:31:51 --> Hooks Class Initialized
DEBUG - 2011-10-03 05:31:51 --> Utf8 Class Initialized
DEBUG - 2011-10-03 05:31:51 --> UTF-8 Support Enabled
DEBUG - 2011-10-03 05:31:51 --> URI Class Initialized
DEBUG - 2011-10-03 05:31:51 --> Router Class Initialized
DEBUG - 2011-10-03 05:31:51 --> Output Class Initialized
DEBUG - 2011-10-03 05:31:51 --> Input Class Initialized
DEBUG - 2011-10-03 05:31:51 --> Global POST and COOKIE data sanitized
DEBUG - 2011-10-03 05:31:51 --> Language Class Initialized
DEBUG - 2011-10-03 05:31:51 --> Loader Class Initialized
DEBUG - 2011-10-03 05:31:51 --> Controller Class Initialized
DEBUG - 2011-10-03 05:31:51 --> Model Class Initialized
DEBUG - 2011-10-03 05:31:51 --> Model Class Initialized
DEBUG - 2011-10-03 05:31:51 --> Model Class Initialized
DEBUG - 2011-10-03 05:31:51 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-10-03 05:31:51 --> Database Driver Class Initialized
DEBUG - 2011-10-03 05:31:52 --> File loaded: application/views/table/main.php
DEBUG - 2011-10-03 05:31:52 --> Helper loaded: url_helper
DEBUG - 2011-10-03 05:31:52 --> File loaded: application/views/common/header.php
DEBUG - 2011-10-03 05:31:52 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-10-03 05:31:52 --> File loaded: application/views/common/footer.php
DEBUG - 2011-10-03 05:31:52 --> File loaded: application/views/layout/main.php
DEBUG - 2011-10-03 05:31:52 --> Final output sent to browser
DEBUG - 2011-10-03 05:31:52 --> Total execution time: 0.8396
DEBUG - 2011-10-03 05:31:54 --> Config Class Initialized
DEBUG - 2011-10-03 05:31:54 --> Hooks Class Initialized
DEBUG - 2011-10-03 05:31:54 --> Utf8 Class Initialized
DEBUG - 2011-10-03 05:31:54 --> UTF-8 Support Enabled
DEBUG - 2011-10-03 05:31:54 --> URI Class Initialized
DEBUG - 2011-10-03 05:31:54 --> Router Class Initialized
DEBUG - 2011-10-03 05:31:54 --> Output Class Initialized
DEBUG - 2011-10-03 05:31:54 --> Input Class Initialized
DEBUG - 2011-10-03 05:31:54 --> Global POST and COOKIE data sanitized
DEBUG - 2011-10-03 05:31:54 --> Language Class Initialized
DEBUG - 2011-10-03 05:31:54 --> Loader Class Initialized
DEBUG - 2011-10-03 05:31:54 --> Controller Class Initialized
DEBUG - 2011-10-03 05:31:54 --> Model Class Initialized
DEBUG - 2011-10-03 05:31:54 --> Model Class Initialized
DEBUG - 2011-10-03 05:31:54 --> Model Class Initialized
DEBUG - 2011-10-03 05:31:54 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-10-03 05:31:54 --> Database Driver Class Initialized
DEBUG - 2011-10-03 05:31:54 --> File loaded: application/views/table/main.php
DEBUG - 2011-10-03 05:31:54 --> Helper loaded: url_helper
DEBUG - 2011-10-03 05:31:54 --> File loaded: application/views/common/header.php
DEBUG - 2011-10-03 05:31:54 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-10-03 05:31:54 --> File loaded: application/views/common/footer.php
DEBUG - 2011-10-03 05:31:54 --> File loaded: application/views/layout/main.php
DEBUG - 2011-10-03 05:31:54 --> Final output sent to browser
DEBUG - 2011-10-03 05:31:54 --> Total execution time: 0.0577
DEBUG - 2011-10-03 05:31:54 --> Config Class Initialized
DEBUG - 2011-10-03 05:31:54 --> Hooks Class Initialized
DEBUG - 2011-10-03 05:31:54 --> Utf8 Class Initialized
DEBUG - 2011-10-03 05:31:54 --> UTF-8 Support Enabled
DEBUG - 2011-10-03 05:31:54 --> URI Class Initialized
DEBUG - 2011-10-03 05:31:54 --> Router Class Initialized
ERROR - 2011-10-03 05:31:54 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-10-03 05:31:58 --> Config Class Initialized
DEBUG - 2011-10-03 05:31:58 --> Hooks Class Initialized
DEBUG - 2011-10-03 05:31:58 --> Utf8 Class Initialized
DEBUG - 2011-10-03 05:31:58 --> UTF-8 Support Enabled
DEBUG - 2011-10-03 05:31:58 --> URI Class Initialized
DEBUG - 2011-10-03 05:31:58 --> Router Class Initialized
DEBUG - 2011-10-03 05:31:58 --> Output Class Initialized
DEBUG - 2011-10-03 05:31:58 --> Input Class Initialized
DEBUG - 2011-10-03 05:31:58 --> Global POST and COOKIE data sanitized
DEBUG - 2011-10-03 05:31:58 --> Language Class Initialized
DEBUG - 2011-10-03 05:31:58 --> Loader Class Initialized
DEBUG - 2011-10-03 05:31:58 --> Controller Class Initialized
DEBUG - 2011-10-03 05:31:58 --> Model Class Initialized
DEBUG - 2011-10-03 05:31:58 --> Model Class Initialized
DEBUG - 2011-10-03 05:31:58 --> Model Class Initialized
DEBUG - 2011-10-03 05:31:58 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-10-03 05:31:58 --> Database Driver Class Initialized
DEBUG - 2011-10-03 05:31:59 --> File loaded: application/views/table/main.php
DEBUG - 2011-10-03 05:31:59 --> Helper loaded: url_helper
DEBUG - 2011-10-03 05:31:59 --> File loaded: application/views/common/header.php
DEBUG - 2011-10-03 05:31:59 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-10-03 05:31:59 --> File loaded: application/views/common/footer.php
DEBUG - 2011-10-03 05:31:59 --> File loaded: application/views/layout/main.php
DEBUG - 2011-10-03 05:31:59 --> Final output sent to browser
DEBUG - 2011-10-03 05:31:59 --> Total execution time: 0.5898
DEBUG - 2011-10-03 05:32:00 --> Config Class Initialized
DEBUG - 2011-10-03 05:32:00 --> Hooks Class Initialized
DEBUG - 2011-10-03 05:32:00 --> Utf8 Class Initialized
DEBUG - 2011-10-03 05:32:00 --> UTF-8 Support Enabled
DEBUG - 2011-10-03 05:32:00 --> URI Class Initialized
DEBUG - 2011-10-03 05:32:00 --> Router Class Initialized
DEBUG - 2011-10-03 05:32:00 --> Output Class Initialized
DEBUG - 2011-10-03 05:32:00 --> Input Class Initialized
DEBUG - 2011-10-03 05:32:00 --> Global POST and COOKIE data sanitized
DEBUG - 2011-10-03 05:32:00 --> Language Class Initialized
DEBUG - 2011-10-03 05:32:00 --> Loader Class Initialized
DEBUG - 2011-10-03 05:32:00 --> Controller Class Initialized
DEBUG - 2011-10-03 05:32:00 --> Model Class Initialized
DEBUG - 2011-10-03 05:32:00 --> Model Class Initialized
DEBUG - 2011-10-03 05:32:00 --> Model Class Initialized
DEBUG - 2011-10-03 05:32:00 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-10-03 05:32:00 --> Database Driver Class Initialized
DEBUG - 2011-10-03 05:32:00 --> File loaded: application/views/table/main.php
DEBUG - 2011-10-03 05:32:00 --> Helper loaded: url_helper
DEBUG - 2011-10-03 05:32:00 --> File loaded: application/views/common/header.php
DEBUG - 2011-10-03 05:32:00 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-10-03 05:32:00 --> File loaded: application/views/common/footer.php
DEBUG - 2011-10-03 05:32:00 --> File loaded: application/views/layout/main.php
DEBUG - 2011-10-03 05:32:00 --> Final output sent to browser
DEBUG - 2011-10-03 05:32:00 --> Total execution time: 0.2081
DEBUG - 2011-10-03 05:32:01 --> Config Class Initialized
DEBUG - 2011-10-03 05:32:01 --> Hooks Class Initialized
DEBUG - 2011-10-03 05:32:01 --> Utf8 Class Initialized
DEBUG - 2011-10-03 05:32:01 --> UTF-8 Support Enabled
DEBUG - 2011-10-03 05:32:01 --> URI Class Initialized
DEBUG - 2011-10-03 05:32:01 --> Router Class Initialized
ERROR - 2011-10-03 05:32:01 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-10-03 05:32:05 --> Config Class Initialized
DEBUG - 2011-10-03 05:32:05 --> Hooks Class Initialized
DEBUG - 2011-10-03 05:32:05 --> Utf8 Class Initialized
DEBUG - 2011-10-03 05:32:05 --> UTF-8 Support Enabled
DEBUG - 2011-10-03 05:32:05 --> URI Class Initialized
DEBUG - 2011-10-03 05:32:05 --> Router Class Initialized
DEBUG - 2011-10-03 05:32:05 --> Output Class Initialized
DEBUG - 2011-10-03 05:32:05 --> Input Class Initialized
DEBUG - 2011-10-03 05:32:05 --> Global POST and COOKIE data sanitized
DEBUG - 2011-10-03 05:32:05 --> Language Class Initialized
DEBUG - 2011-10-03 05:32:05 --> Loader Class Initialized
DEBUG - 2011-10-03 05:32:05 --> Controller Class Initialized
DEBUG - 2011-10-03 05:32:05 --> Model Class Initialized
DEBUG - 2011-10-03 05:32:05 --> Model Class Initialized
DEBUG - 2011-10-03 05:32:05 --> Model Class Initialized
DEBUG - 2011-10-03 05:32:05 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-10-03 05:32:05 --> Database Driver Class Initialized
DEBUG - 2011-10-03 05:32:06 --> File loaded: application/views/table/main.php
DEBUG - 2011-10-03 05:32:06 --> Helper loaded: url_helper
DEBUG - 2011-10-03 05:32:06 --> File loaded: application/views/common/header.php
DEBUG - 2011-10-03 05:32:06 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-10-03 05:32:06 --> File loaded: application/views/common/footer.php
DEBUG - 2011-10-03 05:32:06 --> File loaded: application/views/layout/main.php
DEBUG - 2011-10-03 05:32:06 --> Final output sent to browser
DEBUG - 2011-10-03 05:32:06 --> Total execution time: 0.3321
DEBUG - 2011-10-03 05:32:07 --> Config Class Initialized
DEBUG - 2011-10-03 05:32:07 --> Hooks Class Initialized
DEBUG - 2011-10-03 05:32:07 --> Utf8 Class Initialized
DEBUG - 2011-10-03 05:32:07 --> UTF-8 Support Enabled
DEBUG - 2011-10-03 05:32:07 --> URI Class Initialized
DEBUG - 2011-10-03 05:32:07 --> Router Class Initialized
DEBUG - 2011-10-03 05:32:07 --> Output Class Initialized
DEBUG - 2011-10-03 05:32:07 --> Input Class Initialized
DEBUG - 2011-10-03 05:32:07 --> Global POST and COOKIE data sanitized
DEBUG - 2011-10-03 05:32:07 --> Language Class Initialized
DEBUG - 2011-10-03 05:32:07 --> Loader Class Initialized
DEBUG - 2011-10-03 05:32:07 --> Controller Class Initialized
DEBUG - 2011-10-03 05:32:07 --> Model Class Initialized
DEBUG - 2011-10-03 05:32:07 --> Model Class Initialized
DEBUG - 2011-10-03 05:32:07 --> Model Class Initialized
DEBUG - 2011-10-03 05:32:07 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-10-03 05:32:07 --> Database Driver Class Initialized
DEBUG - 2011-10-03 05:32:07 --> File loaded: application/views/table/main.php
DEBUG - 2011-10-03 05:32:07 --> Helper loaded: url_helper
DEBUG - 2011-10-03 05:32:07 --> File loaded: application/views/common/header.php
DEBUG - 2011-10-03 05:32:07 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-10-03 05:32:07 --> File loaded: application/views/common/footer.php
DEBUG - 2011-10-03 05:32:07 --> File loaded: application/views/layout/main.php
DEBUG - 2011-10-03 05:32:07 --> Final output sent to browser
DEBUG - 2011-10-03 05:32:07 --> Total execution time: 0.1328
DEBUG - 2011-10-03 05:32:07 --> Config Class Initialized
DEBUG - 2011-10-03 05:32:07 --> Hooks Class Initialized
DEBUG - 2011-10-03 05:32:07 --> Utf8 Class Initialized
DEBUG - 2011-10-03 05:32:07 --> UTF-8 Support Enabled
DEBUG - 2011-10-03 05:32:07 --> URI Class Initialized
DEBUG - 2011-10-03 05:32:07 --> Router Class Initialized
ERROR - 2011-10-03 05:32:07 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-10-03 05:32:14 --> Config Class Initialized
DEBUG - 2011-10-03 05:32:14 --> Hooks Class Initialized
DEBUG - 2011-10-03 05:32:14 --> Utf8 Class Initialized
DEBUG - 2011-10-03 05:32:14 --> UTF-8 Support Enabled
DEBUG - 2011-10-03 05:32:14 --> URI Class Initialized
DEBUG - 2011-10-03 05:32:14 --> Router Class Initialized
DEBUG - 2011-10-03 05:32:14 --> Output Class Initialized
DEBUG - 2011-10-03 05:32:14 --> Input Class Initialized
DEBUG - 2011-10-03 05:32:14 --> Global POST and COOKIE data sanitized
DEBUG - 2011-10-03 05:32:14 --> Language Class Initialized
DEBUG - 2011-10-03 05:32:14 --> Loader Class Initialized
DEBUG - 2011-10-03 05:32:14 --> Controller Class Initialized
DEBUG - 2011-10-03 05:32:14 --> Model Class Initialized
DEBUG - 2011-10-03 05:32:14 --> Model Class Initialized
DEBUG - 2011-10-03 05:32:14 --> Model Class Initialized
DEBUG - 2011-10-03 05:32:14 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-10-03 05:32:14 --> Database Driver Class Initialized
DEBUG - 2011-10-03 05:32:14 --> File loaded: application/views/table/main.php
DEBUG - 2011-10-03 05:32:14 --> Helper loaded: url_helper
DEBUG - 2011-10-03 05:32:14 --> File loaded: application/views/common/header.php
DEBUG - 2011-10-03 05:32:14 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-10-03 05:32:14 --> File loaded: application/views/common/footer.php
DEBUG - 2011-10-03 05:32:14 --> File loaded: application/views/layout/main.php
DEBUG - 2011-10-03 05:32:14 --> Final output sent to browser
DEBUG - 2011-10-03 05:32:14 --> Total execution time: 0.2602
DEBUG - 2011-10-03 05:32:15 --> Config Class Initialized
DEBUG - 2011-10-03 05:32:15 --> Hooks Class Initialized
DEBUG - 2011-10-03 05:32:15 --> Utf8 Class Initialized
DEBUG - 2011-10-03 05:32:15 --> UTF-8 Support Enabled
DEBUG - 2011-10-03 05:32:15 --> URI Class Initialized
DEBUG - 2011-10-03 05:32:15 --> Router Class Initialized
DEBUG - 2011-10-03 05:32:15 --> Output Class Initialized
DEBUG - 2011-10-03 05:32:15 --> Input Class Initialized
DEBUG - 2011-10-03 05:32:15 --> Global POST and COOKIE data sanitized
DEBUG - 2011-10-03 05:32:15 --> Language Class Initialized
DEBUG - 2011-10-03 05:32:15 --> Loader Class Initialized
DEBUG - 2011-10-03 05:32:15 --> Controller Class Initialized
DEBUG - 2011-10-03 05:32:15 --> Model Class Initialized
DEBUG - 2011-10-03 05:32:15 --> Model Class Initialized
DEBUG - 2011-10-03 05:32:15 --> Model Class Initialized
DEBUG - 2011-10-03 05:32:15 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-10-03 05:32:15 --> Database Driver Class Initialized
DEBUG - 2011-10-03 05:32:15 --> File loaded: application/views/table/main.php
DEBUG - 2011-10-03 05:32:15 --> Helper loaded: url_helper
DEBUG - 2011-10-03 05:32:15 --> File loaded: application/views/common/header.php
DEBUG - 2011-10-03 05:32:15 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-10-03 05:32:15 --> File loaded: application/views/common/footer.php
DEBUG - 2011-10-03 05:32:15 --> File loaded: application/views/layout/main.php
DEBUG - 2011-10-03 05:32:15 --> Final output sent to browser
DEBUG - 2011-10-03 05:32:15 --> Total execution time: 0.0557
DEBUG - 2011-10-03 05:32:16 --> Config Class Initialized
DEBUG - 2011-10-03 05:32:16 --> Hooks Class Initialized
DEBUG - 2011-10-03 05:32:16 --> Utf8 Class Initialized
DEBUG - 2011-10-03 05:32:16 --> UTF-8 Support Enabled
DEBUG - 2011-10-03 05:32:16 --> URI Class Initialized
DEBUG - 2011-10-03 05:32:16 --> Router Class Initialized
ERROR - 2011-10-03 05:32:16 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-10-03 05:32:21 --> Config Class Initialized
DEBUG - 2011-10-03 05:32:21 --> Hooks Class Initialized
DEBUG - 2011-10-03 05:32:21 --> Utf8 Class Initialized
DEBUG - 2011-10-03 05:32:21 --> UTF-8 Support Enabled
DEBUG - 2011-10-03 05:32:21 --> URI Class Initialized
DEBUG - 2011-10-03 05:32:21 --> Router Class Initialized
DEBUG - 2011-10-03 05:32:21 --> Output Class Initialized
DEBUG - 2011-10-03 05:32:21 --> Input Class Initialized
DEBUG - 2011-10-03 05:32:21 --> Global POST and COOKIE data sanitized
DEBUG - 2011-10-03 05:32:21 --> Language Class Initialized
DEBUG - 2011-10-03 05:32:21 --> Loader Class Initialized
DEBUG - 2011-10-03 05:32:21 --> Controller Class Initialized
DEBUG - 2011-10-03 05:32:21 --> Model Class Initialized
DEBUG - 2011-10-03 05:32:21 --> Model Class Initialized
DEBUG - 2011-10-03 05:32:21 --> Model Class Initialized
DEBUG - 2011-10-03 05:32:21 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-10-03 05:32:21 --> Database Driver Class Initialized
DEBUG - 2011-10-03 05:32:22 --> File loaded: application/views/table/main.php
DEBUG - 2011-10-03 05:32:22 --> Helper loaded: url_helper
DEBUG - 2011-10-03 05:32:22 --> File loaded: application/views/common/header.php
DEBUG - 2011-10-03 05:32:22 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-10-03 05:32:22 --> File loaded: application/views/common/footer.php
DEBUG - 2011-10-03 05:32:22 --> File loaded: application/views/layout/main.php
DEBUG - 2011-10-03 05:32:22 --> Final output sent to browser
DEBUG - 2011-10-03 05:32:22 --> Total execution time: 0.3874
DEBUG - 2011-10-03 05:32:24 --> Config Class Initialized
DEBUG - 2011-10-03 05:32:24 --> Hooks Class Initialized
DEBUG - 2011-10-03 05:32:24 --> Utf8 Class Initialized
DEBUG - 2011-10-03 05:32:24 --> UTF-8 Support Enabled
DEBUG - 2011-10-03 05:32:24 --> URI Class Initialized
DEBUG - 2011-10-03 05:32:24 --> Router Class Initialized
ERROR - 2011-10-03 05:32:24 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-10-03 05:32:27 --> Config Class Initialized
DEBUG - 2011-10-03 05:32:27 --> Hooks Class Initialized
DEBUG - 2011-10-03 05:32:27 --> Utf8 Class Initialized
DEBUG - 2011-10-03 05:32:27 --> UTF-8 Support Enabled
DEBUG - 2011-10-03 05:32:27 --> URI Class Initialized
DEBUG - 2011-10-03 05:32:27 --> Router Class Initialized
DEBUG - 2011-10-03 05:32:27 --> Output Class Initialized
DEBUG - 2011-10-03 05:32:27 --> Input Class Initialized
DEBUG - 2011-10-03 05:32:27 --> Global POST and COOKIE data sanitized
DEBUG - 2011-10-03 05:32:27 --> Language Class Initialized
DEBUG - 2011-10-03 05:32:27 --> Loader Class Initialized
DEBUG - 2011-10-03 05:32:27 --> Controller Class Initialized
ERROR - 2011-10-03 05:32:27 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-10-03 05:32:27 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-10-03 05:32:27 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-10-03 05:32:27 --> Model Class Initialized
DEBUG - 2011-10-03 05:32:27 --> Model Class Initialized
DEBUG - 2011-10-03 05:32:27 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-10-03 05:32:27 --> Database Driver Class Initialized
DEBUG - 2011-10-03 05:32:27 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-10-03 05:32:27 --> Helper loaded: url_helper
DEBUG - 2011-10-03 05:32:27 --> File loaded: application/views/common/header.php
DEBUG - 2011-10-03 05:32:27 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-10-03 05:32:27 --> File loaded: application/views/common/footer.php
DEBUG - 2011-10-03 05:32:27 --> File loaded: application/views/layout/main.php
DEBUG - 2011-10-03 05:32:27 --> Final output sent to browser
DEBUG - 2011-10-03 05:32:27 --> Total execution time: 0.0300
DEBUG - 2011-10-03 05:32:31 --> Config Class Initialized
DEBUG - 2011-10-03 05:32:31 --> Hooks Class Initialized
DEBUG - 2011-10-03 05:32:31 --> Utf8 Class Initialized
DEBUG - 2011-10-03 05:32:31 --> UTF-8 Support Enabled
DEBUG - 2011-10-03 05:32:31 --> URI Class Initialized
DEBUG - 2011-10-03 05:32:31 --> Router Class Initialized
DEBUG - 2011-10-03 05:32:31 --> Output Class Initialized
DEBUG - 2011-10-03 05:32:31 --> Input Class Initialized
DEBUG - 2011-10-03 05:32:31 --> Global POST and COOKIE data sanitized
DEBUG - 2011-10-03 05:32:31 --> Language Class Initialized
DEBUG - 2011-10-03 05:32:31 --> Loader Class Initialized
DEBUG - 2011-10-03 05:32:31 --> Controller Class Initialized
DEBUG - 2011-10-03 05:32:31 --> Model Class Initialized
DEBUG - 2011-10-03 05:32:31 --> Model Class Initialized
DEBUG - 2011-10-03 05:32:31 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-10-03 05:32:31 --> Database Driver Class Initialized
DEBUG - 2011-10-03 05:32:31 --> Final output sent to browser
DEBUG - 2011-10-03 05:32:31 --> Total execution time: 0.6950
DEBUG - 2011-10-03 05:32:33 --> Config Class Initialized
DEBUG - 2011-10-03 05:32:33 --> Hooks Class Initialized
DEBUG - 2011-10-03 05:32:33 --> Utf8 Class Initialized
DEBUG - 2011-10-03 05:32:33 --> UTF-8 Support Enabled
DEBUG - 2011-10-03 05:32:33 --> URI Class Initialized
DEBUG - 2011-10-03 05:32:33 --> Router Class Initialized
DEBUG - 2011-10-03 05:32:33 --> Output Class Initialized
DEBUG - 2011-10-03 05:32:33 --> Input Class Initialized
DEBUG - 2011-10-03 05:32:33 --> Global POST and COOKIE data sanitized
DEBUG - 2011-10-03 05:32:33 --> Language Class Initialized
DEBUG - 2011-10-03 05:32:33 --> Loader Class Initialized
DEBUG - 2011-10-03 05:32:33 --> Controller Class Initialized
ERROR - 2011-10-03 05:32:33 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-10-03 05:32:33 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-10-03 05:32:33 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-10-03 05:32:33 --> Model Class Initialized
DEBUG - 2011-10-03 05:32:33 --> Model Class Initialized
DEBUG - 2011-10-03 05:32:33 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-10-03 05:32:33 --> Database Driver Class Initialized
DEBUG - 2011-10-03 05:32:33 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-10-03 05:32:33 --> Helper loaded: url_helper
DEBUG - 2011-10-03 05:32:33 --> File loaded: application/views/common/header.php
DEBUG - 2011-10-03 05:32:33 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-10-03 05:32:33 --> File loaded: application/views/common/footer.php
DEBUG - 2011-10-03 05:32:33 --> File loaded: application/views/layout/main.php
DEBUG - 2011-10-03 05:32:33 --> Final output sent to browser
DEBUG - 2011-10-03 05:32:33 --> Total execution time: 0.1001
DEBUG - 2011-10-03 05:32:34 --> Config Class Initialized
DEBUG - 2011-10-03 05:32:34 --> Hooks Class Initialized
DEBUG - 2011-10-03 05:32:34 --> Utf8 Class Initialized
DEBUG - 2011-10-03 05:32:34 --> UTF-8 Support Enabled
DEBUG - 2011-10-03 05:32:34 --> URI Class Initialized
DEBUG - 2011-10-03 05:32:34 --> Router Class Initialized
DEBUG - 2011-10-03 05:32:34 --> Output Class Initialized
DEBUG - 2011-10-03 05:32:34 --> Input Class Initialized
DEBUG - 2011-10-03 05:32:34 --> Global POST and COOKIE data sanitized
DEBUG - 2011-10-03 05:32:34 --> Language Class Initialized
DEBUG - 2011-10-03 05:32:34 --> Loader Class Initialized
DEBUG - 2011-10-03 05:32:34 --> Controller Class Initialized
DEBUG - 2011-10-03 05:32:34 --> Model Class Initialized
DEBUG - 2011-10-03 05:32:34 --> Model Class Initialized
DEBUG - 2011-10-03 05:32:34 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-10-03 05:32:34 --> Database Driver Class Initialized
DEBUG - 2011-10-03 05:32:35 --> Final output sent to browser
DEBUG - 2011-10-03 05:32:35 --> Total execution time: 0.6136
DEBUG - 2011-10-03 05:32:37 --> Config Class Initialized
DEBUG - 2011-10-03 05:32:37 --> Hooks Class Initialized
DEBUG - 2011-10-03 05:32:37 --> Utf8 Class Initialized
DEBUG - 2011-10-03 05:32:37 --> UTF-8 Support Enabled
DEBUG - 2011-10-03 05:32:37 --> URI Class Initialized
DEBUG - 2011-10-03 05:32:37 --> Router Class Initialized
ERROR - 2011-10-03 05:32:37 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-10-03 05:33:04 --> Config Class Initialized
DEBUG - 2011-10-03 05:33:04 --> Hooks Class Initialized
DEBUG - 2011-10-03 05:33:04 --> Utf8 Class Initialized
DEBUG - 2011-10-03 05:33:04 --> UTF-8 Support Enabled
DEBUG - 2011-10-03 05:33:04 --> URI Class Initialized
DEBUG - 2011-10-03 05:33:04 --> Router Class Initialized
DEBUG - 2011-10-03 05:33:04 --> Output Class Initialized
DEBUG - 2011-10-03 05:33:04 --> Input Class Initialized
DEBUG - 2011-10-03 05:33:04 --> Global POST and COOKIE data sanitized
DEBUG - 2011-10-03 05:33:04 --> Language Class Initialized
DEBUG - 2011-10-03 05:33:04 --> Loader Class Initialized
DEBUG - 2011-10-03 05:33:04 --> Controller Class Initialized
DEBUG - 2011-10-03 05:33:04 --> Model Class Initialized
DEBUG - 2011-10-03 05:33:04 --> Model Class Initialized
DEBUG - 2011-10-03 05:33:04 --> Model Class Initialized
DEBUG - 2011-10-03 05:33:04 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-10-03 05:33:04 --> Database Driver Class Initialized
DEBUG - 2011-10-03 05:33:04 --> File loaded: application/views/table/main.php
DEBUG - 2011-10-03 05:33:04 --> Helper loaded: url_helper
DEBUG - 2011-10-03 05:33:04 --> File loaded: application/views/common/header.php
DEBUG - 2011-10-03 05:33:04 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-10-03 05:33:04 --> File loaded: application/views/common/footer.php
DEBUG - 2011-10-03 05:33:04 --> File loaded: application/views/layout/main.php
DEBUG - 2011-10-03 05:33:04 --> Final output sent to browser
DEBUG - 2011-10-03 05:33:04 --> Total execution time: 0.1384
DEBUG - 2011-10-03 05:59:12 --> Config Class Initialized
DEBUG - 2011-10-03 05:59:12 --> Hooks Class Initialized
DEBUG - 2011-10-03 05:59:12 --> Utf8 Class Initialized
DEBUG - 2011-10-03 05:59:12 --> UTF-8 Support Enabled
DEBUG - 2011-10-03 05:59:12 --> URI Class Initialized
DEBUG - 2011-10-03 05:59:12 --> Router Class Initialized
ERROR - 2011-10-03 05:59:12 --> 404 Page Not Found --> robots.txt
DEBUG - 2011-10-03 06:43:29 --> Config Class Initialized
DEBUG - 2011-10-03 06:43:29 --> Hooks Class Initialized
DEBUG - 2011-10-03 06:43:29 --> Utf8 Class Initialized
DEBUG - 2011-10-03 06:43:29 --> UTF-8 Support Enabled
DEBUG - 2011-10-03 06:43:29 --> URI Class Initialized
DEBUG - 2011-10-03 06:43:29 --> Router Class Initialized
DEBUG - 2011-10-03 06:43:29 --> Output Class Initialized
DEBUG - 2011-10-03 06:43:29 --> Input Class Initialized
DEBUG - 2011-10-03 06:43:29 --> Global POST and COOKIE data sanitized
DEBUG - 2011-10-03 06:43:29 --> Language Class Initialized
DEBUG - 2011-10-03 06:43:29 --> Loader Class Initialized
DEBUG - 2011-10-03 06:43:29 --> Controller Class Initialized
DEBUG - 2011-10-03 06:43:29 --> Model Class Initialized
DEBUG - 2011-10-03 06:43:29 --> Model Class Initialized
DEBUG - 2011-10-03 06:43:29 --> Model Class Initialized
DEBUG - 2011-10-03 06:43:29 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-10-03 06:43:29 --> Database Driver Class Initialized
DEBUG - 2011-10-03 06:43:36 --> File loaded: application/views/table/main.php
DEBUG - 2011-10-03 06:43:36 --> Helper loaded: url_helper
DEBUG - 2011-10-03 06:43:36 --> File loaded: application/views/common/header.php
DEBUG - 2011-10-03 06:43:36 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-10-03 06:43:36 --> File loaded: application/views/common/footer.php
DEBUG - 2011-10-03 06:43:36 --> File loaded: application/views/layout/main.php
DEBUG - 2011-10-03 06:43:36 --> Final output sent to browser
DEBUG - 2011-10-03 06:43:36 --> Total execution time: 7.3469
DEBUG - 2011-10-03 06:44:26 --> Config Class Initialized
DEBUG - 2011-10-03 06:44:26 --> Hooks Class Initialized
DEBUG - 2011-10-03 06:44:26 --> Utf8 Class Initialized
DEBUG - 2011-10-03 06:44:26 --> UTF-8 Support Enabled
DEBUG - 2011-10-03 06:44:26 --> URI Class Initialized
DEBUG - 2011-10-03 06:44:26 --> Router Class Initialized
DEBUG - 2011-10-03 06:44:26 --> Output Class Initialized
DEBUG - 2011-10-03 06:44:26 --> Input Class Initialized
DEBUG - 2011-10-03 06:44:26 --> Global POST and COOKIE data sanitized
DEBUG - 2011-10-03 06:44:26 --> Language Class Initialized
DEBUG - 2011-10-03 06:44:26 --> Loader Class Initialized
DEBUG - 2011-10-03 06:44:26 --> Controller Class Initialized
DEBUG - 2011-10-03 06:44:26 --> Model Class Initialized
DEBUG - 2011-10-03 06:44:26 --> Model Class Initialized
DEBUG - 2011-10-03 06:44:26 --> Model Class Initialized
DEBUG - 2011-10-03 06:44:26 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-10-03 06:44:26 --> Database Driver Class Initialized
DEBUG - 2011-10-03 06:44:26 --> File loaded: application/views/table/main.php
DEBUG - 2011-10-03 06:44:26 --> Helper loaded: url_helper
DEBUG - 2011-10-03 06:44:26 --> File loaded: application/views/common/header.php
DEBUG - 2011-10-03 06:44:26 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-10-03 06:44:26 --> File loaded: application/views/common/footer.php
DEBUG - 2011-10-03 06:44:26 --> File loaded: application/views/layout/main.php
DEBUG - 2011-10-03 06:44:26 --> Final output sent to browser
DEBUG - 2011-10-03 06:44:26 --> Total execution time: 0.3447
DEBUG - 2011-10-03 07:06:41 --> Config Class Initialized
DEBUG - 2011-10-03 07:06:41 --> Hooks Class Initialized
DEBUG - 2011-10-03 07:06:41 --> Utf8 Class Initialized
DEBUG - 2011-10-03 07:06:41 --> UTF-8 Support Enabled
DEBUG - 2011-10-03 07:06:41 --> URI Class Initialized
DEBUG - 2011-10-03 07:06:41 --> Router Class Initialized
DEBUG - 2011-10-03 07:06:41 --> No URI present. Default controller set.
DEBUG - 2011-10-03 07:06:41 --> Output Class Initialized
DEBUG - 2011-10-03 07:06:41 --> Input Class Initialized
DEBUG - 2011-10-03 07:06:41 --> Global POST and COOKIE data sanitized
DEBUG - 2011-10-03 07:06:42 --> Language Class Initialized
DEBUG - 2011-10-03 07:06:42 --> Loader Class Initialized
DEBUG - 2011-10-03 07:06:42 --> Controller Class Initialized
DEBUG - 2011-10-03 07:06:42 --> File loaded: application/views/splash/main.php
DEBUG - 2011-10-03 07:06:42 --> Helper loaded: url_helper
DEBUG - 2011-10-03 07:06:42 --> File loaded: application/views/common/header.php
DEBUG - 2011-10-03 07:06:42 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-10-03 07:06:42 --> File loaded: application/views/common/footer.php
DEBUG - 2011-10-03 07:06:42 --> File loaded: application/views/layout/main.php
DEBUG - 2011-10-03 07:06:42 --> Final output sent to browser
DEBUG - 2011-10-03 07:06:42 --> Total execution time: 1.7313
DEBUG - 2011-10-03 08:17:42 --> Config Class Initialized
DEBUG - 2011-10-03 08:17:42 --> Hooks Class Initialized
DEBUG - 2011-10-03 08:17:42 --> Utf8 Class Initialized
DEBUG - 2011-10-03 08:17:42 --> UTF-8 Support Enabled
DEBUG - 2011-10-03 08:17:42 --> URI Class Initialized
DEBUG - 2011-10-03 08:17:42 --> Router Class Initialized
DEBUG - 2011-10-03 08:17:42 --> Output Class Initialized
DEBUG - 2011-10-03 08:17:42 --> Input Class Initialized
DEBUG - 2011-10-03 08:17:42 --> Global POST and COOKIE data sanitized
DEBUG - 2011-10-03 08:17:42 --> Language Class Initialized
DEBUG - 2011-10-03 08:17:42 --> Loader Class Initialized
DEBUG - 2011-10-03 08:17:42 --> Controller Class Initialized
ERROR - 2011-10-03 08:17:42 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-10-03 08:17:42 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-10-03 08:17:42 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-10-03 08:17:42 --> Model Class Initialized
DEBUG - 2011-10-03 08:17:42 --> Model Class Initialized
DEBUG - 2011-10-03 08:17:42 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-10-03 08:17:42 --> Database Driver Class Initialized
DEBUG - 2011-10-03 08:17:43 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-10-03 08:17:43 --> Helper loaded: url_helper
DEBUG - 2011-10-03 08:17:43 --> File loaded: application/views/common/header.php
DEBUG - 2011-10-03 08:17:43 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-10-03 08:17:43 --> File loaded: application/views/common/footer.php
DEBUG - 2011-10-03 08:17:43 --> File loaded: application/views/layout/main.php
DEBUG - 2011-10-03 08:17:43 --> Final output sent to browser
DEBUG - 2011-10-03 08:17:43 --> Total execution time: 1.2634
DEBUG - 2011-10-03 08:17:44 --> Config Class Initialized
DEBUG - 2011-10-03 08:17:44 --> Hooks Class Initialized
DEBUG - 2011-10-03 08:17:44 --> Utf8 Class Initialized
DEBUG - 2011-10-03 08:17:44 --> UTF-8 Support Enabled
DEBUG - 2011-10-03 08:17:44 --> URI Class Initialized
DEBUG - 2011-10-03 08:17:44 --> Router Class Initialized
DEBUG - 2011-10-03 08:17:44 --> Output Class Initialized
DEBUG - 2011-10-03 08:17:44 --> Input Class Initialized
DEBUG - 2011-10-03 08:17:44 --> Global POST and COOKIE data sanitized
DEBUG - 2011-10-03 08:17:44 --> Language Class Initialized
DEBUG - 2011-10-03 08:17:44 --> Loader Class Initialized
DEBUG - 2011-10-03 08:17:44 --> Controller Class Initialized
DEBUG - 2011-10-03 08:17:44 --> Model Class Initialized
DEBUG - 2011-10-03 08:17:44 --> Model Class Initialized
DEBUG - 2011-10-03 08:17:44 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-10-03 08:17:44 --> Database Driver Class Initialized
DEBUG - 2011-10-03 08:17:46 --> Final output sent to browser
DEBUG - 2011-10-03 08:17:46 --> Total execution time: 2.2176
DEBUG - 2011-10-03 08:17:47 --> Config Class Initialized
DEBUG - 2011-10-03 08:17:47 --> Hooks Class Initialized
DEBUG - 2011-10-03 08:17:47 --> Utf8 Class Initialized
DEBUG - 2011-10-03 08:17:47 --> UTF-8 Support Enabled
DEBUG - 2011-10-03 08:17:47 --> URI Class Initialized
DEBUG - 2011-10-03 08:17:47 --> Router Class Initialized
ERROR - 2011-10-03 08:17:47 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-10-03 08:17:47 --> Config Class Initialized
DEBUG - 2011-10-03 08:17:47 --> Hooks Class Initialized
DEBUG - 2011-10-03 08:17:47 --> Utf8 Class Initialized
DEBUG - 2011-10-03 08:17:47 --> UTF-8 Support Enabled
DEBUG - 2011-10-03 08:17:47 --> URI Class Initialized
DEBUG - 2011-10-03 08:17:47 --> Router Class Initialized
ERROR - 2011-10-03 08:17:47 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-10-03 08:19:20 --> Config Class Initialized
DEBUG - 2011-10-03 08:19:20 --> Hooks Class Initialized
DEBUG - 2011-10-03 08:19:20 --> Utf8 Class Initialized
DEBUG - 2011-10-03 08:19:20 --> UTF-8 Support Enabled
DEBUG - 2011-10-03 08:19:20 --> URI Class Initialized
DEBUG - 2011-10-03 08:19:20 --> Router Class Initialized
ERROR - 2011-10-03 08:19:20 --> 404 Page Not Found --> robots.txt
DEBUG - 2011-10-03 08:20:32 --> Config Class Initialized
DEBUG - 2011-10-03 08:20:32 --> Hooks Class Initialized
DEBUG - 2011-10-03 08:20:32 --> Utf8 Class Initialized
DEBUG - 2011-10-03 08:20:32 --> UTF-8 Support Enabled
DEBUG - 2011-10-03 08:20:32 --> URI Class Initialized
DEBUG - 2011-10-03 08:20:32 --> Router Class Initialized
DEBUG - 2011-10-03 08:20:32 --> Output Class Initialized
DEBUG - 2011-10-03 08:20:32 --> Input Class Initialized
DEBUG - 2011-10-03 08:20:32 --> Global POST and COOKIE data sanitized
DEBUG - 2011-10-03 08:20:32 --> Language Class Initialized
DEBUG - 2011-10-03 08:20:32 --> Loader Class Initialized
DEBUG - 2011-10-03 08:20:32 --> Controller Class Initialized
DEBUG - 2011-10-03 08:20:32 --> Model Class Initialized
DEBUG - 2011-10-03 08:20:32 --> Model Class Initialized
DEBUG - 2011-10-03 08:20:32 --> Model Class Initialized
DEBUG - 2011-10-03 08:20:32 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-10-03 08:20:32 --> Database Driver Class Initialized
DEBUG - 2011-10-03 08:20:33 --> File loaded: application/views/table/main.php
DEBUG - 2011-10-03 08:20:33 --> Helper loaded: url_helper
DEBUG - 2011-10-03 08:20:33 --> File loaded: application/views/common/header.php
DEBUG - 2011-10-03 08:20:33 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-10-03 08:20:33 --> File loaded: application/views/common/footer.php
DEBUG - 2011-10-03 08:20:33 --> File loaded: application/views/layout/main.php
DEBUG - 2011-10-03 08:20:33 --> Final output sent to browser
DEBUG - 2011-10-03 08:20:33 --> Total execution time: 0.6367
DEBUG - 2011-10-03 08:42:37 --> Config Class Initialized
DEBUG - 2011-10-03 08:42:37 --> Hooks Class Initialized
DEBUG - 2011-10-03 08:42:37 --> Utf8 Class Initialized
DEBUG - 2011-10-03 08:42:37 --> UTF-8 Support Enabled
DEBUG - 2011-10-03 08:42:37 --> URI Class Initialized
DEBUG - 2011-10-03 08:42:37 --> Router Class Initialized
ERROR - 2011-10-03 08:42:37 --> 404 Page Not Found --> robots.txt
DEBUG - 2011-10-03 08:42:39 --> Config Class Initialized
DEBUG - 2011-10-03 08:42:39 --> Hooks Class Initialized
DEBUG - 2011-10-03 08:42:39 --> Utf8 Class Initialized
DEBUG - 2011-10-03 08:42:39 --> UTF-8 Support Enabled
DEBUG - 2011-10-03 08:42:39 --> URI Class Initialized
DEBUG - 2011-10-03 08:42:39 --> Router Class Initialized
DEBUG - 2011-10-03 08:42:39 --> Output Class Initialized
DEBUG - 2011-10-03 08:42:39 --> Input Class Initialized
DEBUG - 2011-10-03 08:42:39 --> Global POST and COOKIE data sanitized
DEBUG - 2011-10-03 08:42:39 --> Language Class Initialized
DEBUG - 2011-10-03 08:42:39 --> Loader Class Initialized
DEBUG - 2011-10-03 08:42:39 --> Controller Class Initialized
DEBUG - 2011-10-03 08:42:39 --> Model Class Initialized
DEBUG - 2011-10-03 08:42:39 --> Model Class Initialized
DEBUG - 2011-10-03 08:42:39 --> Model Class Initialized
DEBUG - 2011-10-03 08:42:39 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-10-03 08:42:39 --> Database Driver Class Initialized
DEBUG - 2011-10-03 08:42:39 --> File loaded: application/views/table/main.php
DEBUG - 2011-10-03 08:42:39 --> Helper loaded: url_helper
DEBUG - 2011-10-03 08:42:39 --> File loaded: application/views/common/header.php
DEBUG - 2011-10-03 08:42:39 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-10-03 08:42:39 --> File loaded: application/views/common/footer.php
DEBUG - 2011-10-03 08:42:39 --> File loaded: application/views/layout/main.php
DEBUG - 2011-10-03 08:42:39 --> Final output sent to browser
DEBUG - 2011-10-03 08:42:39 --> Total execution time: 0.4751
DEBUG - 2011-10-03 09:05:37 --> Config Class Initialized
DEBUG - 2011-10-03 09:05:37 --> Hooks Class Initialized
DEBUG - 2011-10-03 09:05:37 --> Utf8 Class Initialized
DEBUG - 2011-10-03 09:05:37 --> UTF-8 Support Enabled
DEBUG - 2011-10-03 09:05:37 --> URI Class Initialized
DEBUG - 2011-10-03 09:05:37 --> Router Class Initialized
DEBUG - 2011-10-03 09:05:37 --> Output Class Initialized
DEBUG - 2011-10-03 09:05:37 --> Input Class Initialized
DEBUG - 2011-10-03 09:05:37 --> Global POST and COOKIE data sanitized
DEBUG - 2011-10-03 09:05:37 --> Language Class Initialized
DEBUG - 2011-10-03 09:05:37 --> Loader Class Initialized
DEBUG - 2011-10-03 09:05:37 --> Controller Class Initialized
ERROR - 2011-10-03 09:05:37 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-10-03 09:05:37 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-10-03 09:05:37 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-10-03 09:05:37 --> Model Class Initialized
DEBUG - 2011-10-03 09:05:37 --> Model Class Initialized
DEBUG - 2011-10-03 09:05:37 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-10-03 09:05:37 --> Database Driver Class Initialized
DEBUG - 2011-10-03 09:05:37 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-10-03 09:05:37 --> Helper loaded: url_helper
DEBUG - 2011-10-03 09:05:37 --> File loaded: application/views/common/header.php
DEBUG - 2011-10-03 09:05:37 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-10-03 09:05:37 --> File loaded: application/views/common/footer.php
DEBUG - 2011-10-03 09:05:37 --> File loaded: application/views/layout/main.php
DEBUG - 2011-10-03 09:05:37 --> Final output sent to browser
DEBUG - 2011-10-03 09:05:37 --> Total execution time: 0.6401
DEBUG - 2011-10-03 10:11:10 --> Config Class Initialized
DEBUG - 2011-10-03 10:11:10 --> Hooks Class Initialized
DEBUG - 2011-10-03 10:11:10 --> Utf8 Class Initialized
DEBUG - 2011-10-03 10:11:10 --> UTF-8 Support Enabled
DEBUG - 2011-10-03 10:11:10 --> URI Class Initialized
DEBUG - 2011-10-03 10:11:10 --> Router Class Initialized
DEBUG - 2011-10-03 10:11:10 --> No URI present. Default controller set.
DEBUG - 2011-10-03 10:11:10 --> Output Class Initialized
DEBUG - 2011-10-03 10:11:10 --> Input Class Initialized
DEBUG - 2011-10-03 10:11:10 --> Global POST and COOKIE data sanitized
DEBUG - 2011-10-03 10:11:10 --> Language Class Initialized
DEBUG - 2011-10-03 10:11:10 --> Loader Class Initialized
DEBUG - 2011-10-03 10:11:10 --> Controller Class Initialized
DEBUG - 2011-10-03 10:11:10 --> File loaded: application/views/splash/main.php
DEBUG - 2011-10-03 10:11:10 --> Helper loaded: url_helper
DEBUG - 2011-10-03 10:11:10 --> File loaded: application/views/common/header.php
DEBUG - 2011-10-03 10:11:10 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-10-03 10:11:10 --> File loaded: application/views/common/footer.php
DEBUG - 2011-10-03 10:11:10 --> File loaded: application/views/layout/main.php
DEBUG - 2011-10-03 10:11:10 --> Final output sent to browser
DEBUG - 2011-10-03 10:11:10 --> Total execution time: 0.0717
DEBUG - 2011-10-03 10:49:20 --> Config Class Initialized
DEBUG - 2011-10-03 10:49:20 --> Hooks Class Initialized
DEBUG - 2011-10-03 10:49:20 --> Utf8 Class Initialized
DEBUG - 2011-10-03 10:49:20 --> UTF-8 Support Enabled
DEBUG - 2011-10-03 10:49:20 --> URI Class Initialized
DEBUG - 2011-10-03 10:49:20 --> Router Class Initialized
DEBUG - 2011-10-03 10:49:20 --> Output Class Initialized
DEBUG - 2011-10-03 10:49:20 --> Input Class Initialized
DEBUG - 2011-10-03 10:49:20 --> Global POST and COOKIE data sanitized
DEBUG - 2011-10-03 10:49:20 --> Language Class Initialized
DEBUG - 2011-10-03 10:49:20 --> Loader Class Initialized
DEBUG - 2011-10-03 10:49:20 --> Controller Class Initialized
DEBUG - 2011-10-03 10:49:20 --> Model Class Initialized
DEBUG - 2011-10-03 10:49:20 --> Model Class Initialized
DEBUG - 2011-10-03 10:49:20 --> Model Class Initialized
DEBUG - 2011-10-03 10:49:20 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-10-03 10:49:20 --> Database Driver Class Initialized
DEBUG - 2011-10-03 10:49:22 --> File loaded: application/views/table/main.php
DEBUG - 2011-10-03 10:49:22 --> Helper loaded: url_helper
DEBUG - 2011-10-03 10:49:22 --> File loaded: application/views/common/header.php
DEBUG - 2011-10-03 10:49:22 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-10-03 10:49:22 --> File loaded: application/views/common/footer.php
DEBUG - 2011-10-03 10:49:22 --> File loaded: application/views/layout/main.php
DEBUG - 2011-10-03 10:49:22 --> Final output sent to browser
DEBUG - 2011-10-03 10:49:22 --> Total execution time: 1.9118
DEBUG - 2011-10-03 10:49:23 --> Config Class Initialized
DEBUG - 2011-10-03 10:49:23 --> Hooks Class Initialized
DEBUG - 2011-10-03 10:49:23 --> Utf8 Class Initialized
DEBUG - 2011-10-03 10:49:23 --> UTF-8 Support Enabled
DEBUG - 2011-10-03 10:49:23 --> URI Class Initialized
DEBUG - 2011-10-03 10:49:23 --> Router Class Initialized
DEBUG - 2011-10-03 10:49:23 --> Output Class Initialized
DEBUG - 2011-10-03 10:49:23 --> Input Class Initialized
DEBUG - 2011-10-03 10:49:23 --> Global POST and COOKIE data sanitized
DEBUG - 2011-10-03 10:49:23 --> Language Class Initialized
DEBUG - 2011-10-03 10:49:23 --> Loader Class Initialized
DEBUG - 2011-10-03 10:49:23 --> Controller Class Initialized
ERROR - 2011-10-03 10:49:23 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-10-03 10:49:23 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-10-03 10:49:23 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-10-03 10:49:23 --> Model Class Initialized
DEBUG - 2011-10-03 10:49:23 --> Model Class Initialized
DEBUG - 2011-10-03 10:49:23 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-10-03 10:49:23 --> Database Driver Class Initialized
DEBUG - 2011-10-03 10:49:23 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-10-03 10:49:23 --> Helper loaded: url_helper
DEBUG - 2011-10-03 10:49:23 --> File loaded: application/views/common/header.php
DEBUG - 2011-10-03 10:49:23 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-10-03 10:49:23 --> File loaded: application/views/common/footer.php
DEBUG - 2011-10-03 10:49:23 --> File loaded: application/views/layout/main.php
DEBUG - 2011-10-03 10:49:23 --> Final output sent to browser
DEBUG - 2011-10-03 10:49:23 --> Total execution time: 0.0341
DEBUG - 2011-10-03 11:28:58 --> Config Class Initialized
DEBUG - 2011-10-03 11:28:58 --> Hooks Class Initialized
DEBUG - 2011-10-03 11:28:58 --> Utf8 Class Initialized
DEBUG - 2011-10-03 11:28:58 --> UTF-8 Support Enabled
DEBUG - 2011-10-03 11:28:58 --> URI Class Initialized
DEBUG - 2011-10-03 11:28:58 --> Router Class Initialized
ERROR - 2011-10-03 11:28:59 --> 404 Page Not Found --> robots.txt
DEBUG - 2011-10-03 11:29:40 --> Config Class Initialized
DEBUG - 2011-10-03 11:29:40 --> Hooks Class Initialized
DEBUG - 2011-10-03 11:29:40 --> Utf8 Class Initialized
DEBUG - 2011-10-03 11:29:40 --> UTF-8 Support Enabled
DEBUG - 2011-10-03 11:29:40 --> URI Class Initialized
DEBUG - 2011-10-03 11:29:40 --> Router Class Initialized
DEBUG - 2011-10-03 11:29:40 --> Output Class Initialized
DEBUG - 2011-10-03 11:29:40 --> Input Class Initialized
DEBUG - 2011-10-03 11:29:40 --> Global POST and COOKIE data sanitized
DEBUG - 2011-10-03 11:29:40 --> Language Class Initialized
DEBUG - 2011-10-03 11:29:40 --> Loader Class Initialized
DEBUG - 2011-10-03 11:29:40 --> Controller Class Initialized
DEBUG - 2011-10-03 11:29:40 --> Model Class Initialized
DEBUG - 2011-10-03 11:29:40 --> Model Class Initialized
DEBUG - 2011-10-03 11:29:40 --> Model Class Initialized
DEBUG - 2011-10-03 11:29:40 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-10-03 11:29:40 --> Database Driver Class Initialized
DEBUG - 2011-10-03 11:29:41 --> File loaded: application/views/table/main.php
DEBUG - 2011-10-03 11:29:41 --> Helper loaded: url_helper
DEBUG - 2011-10-03 11:29:41 --> File loaded: application/views/common/header.php
DEBUG - 2011-10-03 11:29:41 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-10-03 11:29:41 --> File loaded: application/views/common/footer.php
DEBUG - 2011-10-03 11:29:41 --> File loaded: application/views/layout/main.php
DEBUG - 2011-10-03 11:29:41 --> Final output sent to browser
DEBUG - 2011-10-03 11:29:41 --> Total execution time: 0.8674
DEBUG - 2011-10-03 12:01:54 --> Config Class Initialized
DEBUG - 2011-10-03 12:01:54 --> Hooks Class Initialized
DEBUG - 2011-10-03 12:01:54 --> Utf8 Class Initialized
DEBUG - 2011-10-03 12:01:54 --> UTF-8 Support Enabled
DEBUG - 2011-10-03 12:01:54 --> URI Class Initialized
DEBUG - 2011-10-03 12:01:54 --> Router Class Initialized
DEBUG - 2011-10-03 12:01:54 --> Output Class Initialized
DEBUG - 2011-10-03 12:01:54 --> Input Class Initialized
DEBUG - 2011-10-03 12:01:54 --> Global POST and COOKIE data sanitized
DEBUG - 2011-10-03 12:01:54 --> Language Class Initialized
DEBUG - 2011-10-03 12:01:54 --> Loader Class Initialized
DEBUG - 2011-10-03 12:01:54 --> Controller Class Initialized
ERROR - 2011-10-03 12:01:54 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-10-03 12:01:54 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-10-03 12:01:54 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-10-03 12:01:54 --> Model Class Initialized
DEBUG - 2011-10-03 12:01:54 --> Model Class Initialized
DEBUG - 2011-10-03 12:01:54 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-10-03 12:01:54 --> Database Driver Class Initialized
DEBUG - 2011-10-03 12:01:55 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-10-03 12:01:55 --> Helper loaded: url_helper
DEBUG - 2011-10-03 12:01:55 --> File loaded: application/views/common/header.php
DEBUG - 2011-10-03 12:01:55 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-10-03 12:01:55 --> File loaded: application/views/common/footer.php
DEBUG - 2011-10-03 12:01:55 --> File loaded: application/views/layout/main.php
DEBUG - 2011-10-03 12:01:55 --> Final output sent to browser
DEBUG - 2011-10-03 12:01:55 --> Total execution time: 0.9953
DEBUG - 2011-10-03 12:01:57 --> Config Class Initialized
DEBUG - 2011-10-03 12:01:57 --> Hooks Class Initialized
DEBUG - 2011-10-03 12:01:57 --> Utf8 Class Initialized
DEBUG - 2011-10-03 12:01:57 --> UTF-8 Support Enabled
DEBUG - 2011-10-03 12:01:57 --> URI Class Initialized
DEBUG - 2011-10-03 12:01:57 --> Router Class Initialized
DEBUG - 2011-10-03 12:01:57 --> Output Class Initialized
DEBUG - 2011-10-03 12:01:57 --> Input Class Initialized
DEBUG - 2011-10-03 12:01:57 --> Global POST and COOKIE data sanitized
DEBUG - 2011-10-03 12:01:57 --> Language Class Initialized
DEBUG - 2011-10-03 12:01:57 --> Loader Class Initialized
DEBUG - 2011-10-03 12:01:57 --> Controller Class Initialized
DEBUG - 2011-10-03 12:01:57 --> Model Class Initialized
DEBUG - 2011-10-03 12:01:57 --> Model Class Initialized
DEBUG - 2011-10-03 12:01:57 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-10-03 12:01:57 --> Database Driver Class Initialized
DEBUG - 2011-10-03 12:01:58 --> Final output sent to browser
DEBUG - 2011-10-03 12:01:58 --> Total execution time: 1.1184
DEBUG - 2011-10-03 12:02:01 --> Config Class Initialized
DEBUG - 2011-10-03 12:02:01 --> Hooks Class Initialized
DEBUG - 2011-10-03 12:02:01 --> Utf8 Class Initialized
DEBUG - 2011-10-03 12:02:01 --> UTF-8 Support Enabled
DEBUG - 2011-10-03 12:02:01 --> URI Class Initialized
DEBUG - 2011-10-03 12:02:01 --> Router Class Initialized
ERROR - 2011-10-03 12:02:01 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-10-03 12:02:03 --> Config Class Initialized
DEBUG - 2011-10-03 12:02:03 --> Hooks Class Initialized
DEBUG - 2011-10-03 12:02:03 --> Utf8 Class Initialized
DEBUG - 2011-10-03 12:02:03 --> UTF-8 Support Enabled
DEBUG - 2011-10-03 12:02:03 --> URI Class Initialized
DEBUG - 2011-10-03 12:02:03 --> Router Class Initialized
ERROR - 2011-10-03 12:02:03 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-10-03 12:02:03 --> Config Class Initialized
DEBUG - 2011-10-03 12:02:03 --> Hooks Class Initialized
DEBUG - 2011-10-03 12:02:03 --> Utf8 Class Initialized
DEBUG - 2011-10-03 12:02:03 --> UTF-8 Support Enabled
DEBUG - 2011-10-03 12:02:03 --> URI Class Initialized
DEBUG - 2011-10-03 12:02:03 --> Router Class Initialized
ERROR - 2011-10-03 12:02:03 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-10-03 12:02:06 --> Config Class Initialized
DEBUG - 2011-10-03 12:02:06 --> Hooks Class Initialized
DEBUG - 2011-10-03 12:02:06 --> Utf8 Class Initialized
DEBUG - 2011-10-03 12:02:06 --> UTF-8 Support Enabled
DEBUG - 2011-10-03 12:02:06 --> URI Class Initialized
DEBUG - 2011-10-03 12:02:06 --> Router Class Initialized
ERROR - 2011-10-03 12:02:06 --> 404 Page Not Found --> robots.txt
DEBUG - 2011-10-03 12:02:07 --> Config Class Initialized
DEBUG - 2011-10-03 12:02:07 --> Hooks Class Initialized
DEBUG - 2011-10-03 12:02:07 --> Utf8 Class Initialized
DEBUG - 2011-10-03 12:02:07 --> UTF-8 Support Enabled
DEBUG - 2011-10-03 12:02:07 --> URI Class Initialized
DEBUG - 2011-10-03 12:02:07 --> Router Class Initialized
DEBUG - 2011-10-03 12:02:07 --> Output Class Initialized
DEBUG - 2011-10-03 12:02:07 --> Input Class Initialized
DEBUG - 2011-10-03 12:02:07 --> Global POST and COOKIE data sanitized
DEBUG - 2011-10-03 12:02:07 --> Language Class Initialized
DEBUG - 2011-10-03 12:02:07 --> Loader Class Initialized
DEBUG - 2011-10-03 12:02:07 --> Controller Class Initialized
ERROR - 2011-10-03 12:02:07 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-10-03 12:02:07 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-10-03 12:02:07 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-10-03 12:02:07 --> Model Class Initialized
DEBUG - 2011-10-03 12:02:07 --> Model Class Initialized
DEBUG - 2011-10-03 12:02:07 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-10-03 12:02:07 --> Database Driver Class Initialized
DEBUG - 2011-10-03 12:02:07 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-10-03 12:02:07 --> Helper loaded: url_helper
DEBUG - 2011-10-03 12:02:07 --> File loaded: application/views/common/header.php
DEBUG - 2011-10-03 12:02:07 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-10-03 12:02:07 --> File loaded: application/views/common/footer.php
DEBUG - 2011-10-03 12:02:07 --> File loaded: application/views/layout/main.php
DEBUG - 2011-10-03 12:02:07 --> Final output sent to browser
DEBUG - 2011-10-03 12:02:07 --> Total execution time: 0.0508
DEBUG - 2011-10-03 12:03:59 --> Config Class Initialized
DEBUG - 2011-10-03 12:03:59 --> Hooks Class Initialized
DEBUG - 2011-10-03 12:03:59 --> Utf8 Class Initialized
DEBUG - 2011-10-03 12:03:59 --> UTF-8 Support Enabled
DEBUG - 2011-10-03 12:03:59 --> URI Class Initialized
DEBUG - 2011-10-03 12:03:59 --> Router Class Initialized
DEBUG - 2011-10-03 12:03:59 --> Output Class Initialized
DEBUG - 2011-10-03 12:03:59 --> Input Class Initialized
DEBUG - 2011-10-03 12:03:59 --> Global POST and COOKIE data sanitized
DEBUG - 2011-10-03 12:03:59 --> Language Class Initialized
DEBUG - 2011-10-03 12:03:59 --> Loader Class Initialized
DEBUG - 2011-10-03 12:03:59 --> Controller Class Initialized
ERROR - 2011-10-03 12:03:59 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-10-03 12:03:59 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-10-03 12:03:59 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-10-03 12:03:59 --> Model Class Initialized
DEBUG - 2011-10-03 12:03:59 --> Model Class Initialized
DEBUG - 2011-10-03 12:03:59 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-10-03 12:03:59 --> Database Driver Class Initialized
DEBUG - 2011-10-03 12:03:59 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-10-03 12:03:59 --> Helper loaded: url_helper
DEBUG - 2011-10-03 12:03:59 --> File loaded: application/views/common/header.php
DEBUG - 2011-10-03 12:03:59 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-10-03 12:03:59 --> File loaded: application/views/common/footer.php
DEBUG - 2011-10-03 12:03:59 --> File loaded: application/views/layout/main.php
DEBUG - 2011-10-03 12:03:59 --> Final output sent to browser
DEBUG - 2011-10-03 12:03:59 --> Total execution time: 0.0337
DEBUG - 2011-10-03 12:04:01 --> Config Class Initialized
DEBUG - 2011-10-03 12:04:01 --> Hooks Class Initialized
DEBUG - 2011-10-03 12:04:01 --> Utf8 Class Initialized
DEBUG - 2011-10-03 12:04:01 --> UTF-8 Support Enabled
DEBUG - 2011-10-03 12:04:01 --> URI Class Initialized
DEBUG - 2011-10-03 12:04:01 --> Router Class Initialized
DEBUG - 2011-10-03 12:04:01 --> Output Class Initialized
DEBUG - 2011-10-03 12:04:01 --> Input Class Initialized
DEBUG - 2011-10-03 12:04:01 --> Global POST and COOKIE data sanitized
DEBUG - 2011-10-03 12:04:01 --> Language Class Initialized
DEBUG - 2011-10-03 12:04:01 --> Loader Class Initialized
DEBUG - 2011-10-03 12:04:01 --> Controller Class Initialized
DEBUG - 2011-10-03 12:04:01 --> Model Class Initialized
DEBUG - 2011-10-03 12:04:01 --> Model Class Initialized
DEBUG - 2011-10-03 12:04:01 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-10-03 12:04:01 --> Database Driver Class Initialized
DEBUG - 2011-10-03 12:04:01 --> Final output sent to browser
DEBUG - 2011-10-03 12:04:01 --> Total execution time: 0.7306
DEBUG - 2011-10-03 12:05:53 --> Config Class Initialized
DEBUG - 2011-10-03 12:05:53 --> Hooks Class Initialized
DEBUG - 2011-10-03 12:05:53 --> Utf8 Class Initialized
DEBUG - 2011-10-03 12:05:53 --> UTF-8 Support Enabled
DEBUG - 2011-10-03 12:05:53 --> URI Class Initialized
DEBUG - 2011-10-03 12:05:53 --> Router Class Initialized
DEBUG - 2011-10-03 12:05:53 --> Output Class Initialized
DEBUG - 2011-10-03 12:05:53 --> Input Class Initialized
DEBUG - 2011-10-03 12:05:53 --> Global POST and COOKIE data sanitized
DEBUG - 2011-10-03 12:05:53 --> Language Class Initialized
DEBUG - 2011-10-03 12:05:53 --> Loader Class Initialized
DEBUG - 2011-10-03 12:05:53 --> Controller Class Initialized
ERROR - 2011-10-03 12:05:53 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-10-03 12:05:53 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-10-03 12:05:53 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-10-03 12:05:53 --> Model Class Initialized
DEBUG - 2011-10-03 12:05:53 --> Model Class Initialized
DEBUG - 2011-10-03 12:05:53 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-10-03 12:05:53 --> Database Driver Class Initialized
DEBUG - 2011-10-03 12:05:53 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-10-03 12:05:53 --> Helper loaded: url_helper
DEBUG - 2011-10-03 12:05:53 --> File loaded: application/views/common/header.php
DEBUG - 2011-10-03 12:05:53 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-10-03 12:05:53 --> File loaded: application/views/common/footer.php
DEBUG - 2011-10-03 12:05:53 --> File loaded: application/views/layout/main.php
DEBUG - 2011-10-03 12:05:53 --> Final output sent to browser
DEBUG - 2011-10-03 12:05:53 --> Total execution time: 0.0709
DEBUG - 2011-10-03 12:05:54 --> Config Class Initialized
DEBUG - 2011-10-03 12:05:54 --> Hooks Class Initialized
DEBUG - 2011-10-03 12:05:54 --> Utf8 Class Initialized
DEBUG - 2011-10-03 12:05:54 --> UTF-8 Support Enabled
DEBUG - 2011-10-03 12:05:54 --> URI Class Initialized
DEBUG - 2011-10-03 12:05:54 --> Router Class Initialized
DEBUG - 2011-10-03 12:05:54 --> Output Class Initialized
DEBUG - 2011-10-03 12:05:54 --> Input Class Initialized
DEBUG - 2011-10-03 12:05:54 --> Global POST and COOKIE data sanitized
DEBUG - 2011-10-03 12:05:54 --> Language Class Initialized
DEBUG - 2011-10-03 12:05:54 --> Loader Class Initialized
DEBUG - 2011-10-03 12:05:54 --> Controller Class Initialized
DEBUG - 2011-10-03 12:05:54 --> Model Class Initialized
DEBUG - 2011-10-03 12:05:54 --> Model Class Initialized
DEBUG - 2011-10-03 12:05:54 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-10-03 12:05:54 --> Database Driver Class Initialized
DEBUG - 2011-10-03 12:05:55 --> Final output sent to browser
DEBUG - 2011-10-03 12:05:55 --> Total execution time: 0.6168
DEBUG - 2011-10-03 12:06:27 --> Config Class Initialized
DEBUG - 2011-10-03 12:06:27 --> Hooks Class Initialized
DEBUG - 2011-10-03 12:06:27 --> Utf8 Class Initialized
DEBUG - 2011-10-03 12:06:27 --> UTF-8 Support Enabled
DEBUG - 2011-10-03 12:06:27 --> URI Class Initialized
DEBUG - 2011-10-03 12:06:27 --> Router Class Initialized
DEBUG - 2011-10-03 12:06:27 --> Output Class Initialized
DEBUG - 2011-10-03 12:06:27 --> Input Class Initialized
DEBUG - 2011-10-03 12:06:27 --> Global POST and COOKIE data sanitized
DEBUG - 2011-10-03 12:06:27 --> Language Class Initialized
DEBUG - 2011-10-03 12:06:27 --> Loader Class Initialized
DEBUG - 2011-10-03 12:06:27 --> Controller Class Initialized
DEBUG - 2011-10-03 12:06:27 --> Model Class Initialized
DEBUG - 2011-10-03 12:06:27 --> Model Class Initialized
DEBUG - 2011-10-03 12:06:27 --> Model Class Initialized
DEBUG - 2011-10-03 12:06:27 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-10-03 12:06:27 --> Database Driver Class Initialized
DEBUG - 2011-10-03 12:06:28 --> File loaded: application/views/table/main.php
DEBUG - 2011-10-03 12:06:28 --> Helper loaded: url_helper
DEBUG - 2011-10-03 12:06:28 --> File loaded: application/views/common/header.php
DEBUG - 2011-10-03 12:06:28 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-10-03 12:06:28 --> File loaded: application/views/common/footer.php
DEBUG - 2011-10-03 12:06:28 --> File loaded: application/views/layout/main.php
DEBUG - 2011-10-03 12:06:28 --> Final output sent to browser
DEBUG - 2011-10-03 12:06:28 --> Total execution time: 0.5523
DEBUG - 2011-10-03 12:06:51 --> Config Class Initialized
DEBUG - 2011-10-03 12:06:51 --> Hooks Class Initialized
DEBUG - 2011-10-03 12:06:51 --> Utf8 Class Initialized
DEBUG - 2011-10-03 12:06:51 --> UTF-8 Support Enabled
DEBUG - 2011-10-03 12:06:51 --> URI Class Initialized
DEBUG - 2011-10-03 12:06:51 --> Router Class Initialized
DEBUG - 2011-10-03 12:06:51 --> Output Class Initialized
DEBUG - 2011-10-03 12:06:51 --> Input Class Initialized
DEBUG - 2011-10-03 12:06:51 --> Global POST and COOKIE data sanitized
DEBUG - 2011-10-03 12:06:51 --> Language Class Initialized
DEBUG - 2011-10-03 12:06:51 --> Loader Class Initialized
DEBUG - 2011-10-03 12:06:51 --> Controller Class Initialized
DEBUG - 2011-10-03 12:06:51 --> Model Class Initialized
DEBUG - 2011-10-03 12:06:51 --> Model Class Initialized
DEBUG - 2011-10-03 12:06:51 --> Model Class Initialized
DEBUG - 2011-10-03 12:06:51 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-10-03 12:06:51 --> Database Driver Class Initialized
DEBUG - 2011-10-03 12:06:51 --> File loaded: application/views/table/main.php
DEBUG - 2011-10-03 12:06:51 --> Helper loaded: url_helper
DEBUG - 2011-10-03 12:06:51 --> File loaded: application/views/common/header.php
DEBUG - 2011-10-03 12:06:51 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-10-03 12:06:51 --> File loaded: application/views/common/footer.php
DEBUG - 2011-10-03 12:06:51 --> File loaded: application/views/layout/main.php
DEBUG - 2011-10-03 12:06:51 --> Final output sent to browser
DEBUG - 2011-10-03 12:06:51 --> Total execution time: 0.0676
DEBUG - 2011-10-03 12:07:08 --> Config Class Initialized
DEBUG - 2011-10-03 12:07:08 --> Hooks Class Initialized
DEBUG - 2011-10-03 12:07:08 --> Utf8 Class Initialized
DEBUG - 2011-10-03 12:07:08 --> UTF-8 Support Enabled
DEBUG - 2011-10-03 12:07:08 --> URI Class Initialized
DEBUG - 2011-10-03 12:07:08 --> Router Class Initialized
DEBUG - 2011-10-03 12:07:08 --> Output Class Initialized
DEBUG - 2011-10-03 12:07:08 --> Input Class Initialized
DEBUG - 2011-10-03 12:07:08 --> Global POST and COOKIE data sanitized
DEBUG - 2011-10-03 12:07:08 --> Language Class Initialized
DEBUG - 2011-10-03 12:07:08 --> Loader Class Initialized
DEBUG - 2011-10-03 12:07:08 --> Controller Class Initialized
DEBUG - 2011-10-03 12:07:08 --> Model Class Initialized
DEBUG - 2011-10-03 12:07:08 --> Model Class Initialized
DEBUG - 2011-10-03 12:07:08 --> Model Class Initialized
DEBUG - 2011-10-03 12:07:08 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-10-03 12:07:08 --> Database Driver Class Initialized
DEBUG - 2011-10-03 12:07:08 --> File loaded: application/views/table/main.php
DEBUG - 2011-10-03 12:07:08 --> Helper loaded: url_helper
DEBUG - 2011-10-03 12:07:08 --> File loaded: application/views/common/header.php
DEBUG - 2011-10-03 12:07:08 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-10-03 12:07:08 --> File loaded: application/views/common/footer.php
DEBUG - 2011-10-03 12:07:08 --> File loaded: application/views/layout/main.php
DEBUG - 2011-10-03 12:07:08 --> Final output sent to browser
DEBUG - 2011-10-03 12:07:08 --> Total execution time: 0.0550
DEBUG - 2011-10-03 12:07:50 --> Config Class Initialized
DEBUG - 2011-10-03 12:07:50 --> Hooks Class Initialized
DEBUG - 2011-10-03 12:07:50 --> Utf8 Class Initialized
DEBUG - 2011-10-03 12:07:50 --> UTF-8 Support Enabled
DEBUG - 2011-10-03 12:07:50 --> URI Class Initialized
DEBUG - 2011-10-03 12:07:50 --> Router Class Initialized
DEBUG - 2011-10-03 12:07:50 --> Output Class Initialized
DEBUG - 2011-10-03 12:07:50 --> Input Class Initialized
DEBUG - 2011-10-03 12:07:50 --> Global POST and COOKIE data sanitized
DEBUG - 2011-10-03 12:07:50 --> Language Class Initialized
DEBUG - 2011-10-03 12:07:50 --> Loader Class Initialized
DEBUG - 2011-10-03 12:07:50 --> Controller Class Initialized
DEBUG - 2011-10-03 12:07:50 --> Model Class Initialized
DEBUG - 2011-10-03 12:07:50 --> Model Class Initialized
DEBUG - 2011-10-03 12:07:50 --> Model Class Initialized
DEBUG - 2011-10-03 12:07:50 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-10-03 12:07:50 --> Database Driver Class Initialized
DEBUG - 2011-10-03 12:07:50 --> File loaded: application/views/table/main.php
DEBUG - 2011-10-03 12:07:50 --> Helper loaded: url_helper
DEBUG - 2011-10-03 12:07:50 --> File loaded: application/views/common/header.php
DEBUG - 2011-10-03 12:07:50 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-10-03 12:07:50 --> File loaded: application/views/common/footer.php
DEBUG - 2011-10-03 12:07:50 --> File loaded: application/views/layout/main.php
DEBUG - 2011-10-03 12:07:50 --> Final output sent to browser
DEBUG - 2011-10-03 12:07:50 --> Total execution time: 0.0510
DEBUG - 2011-10-03 12:48:37 --> Config Class Initialized
DEBUG - 2011-10-03 12:48:37 --> Hooks Class Initialized
DEBUG - 2011-10-03 12:48:37 --> Utf8 Class Initialized
DEBUG - 2011-10-03 12:48:37 --> UTF-8 Support Enabled
DEBUG - 2011-10-03 12:48:37 --> URI Class Initialized
DEBUG - 2011-10-03 12:48:37 --> Router Class Initialized
DEBUG - 2011-10-03 12:48:37 --> Output Class Initialized
DEBUG - 2011-10-03 12:48:37 --> Input Class Initialized
DEBUG - 2011-10-03 12:48:37 --> Global POST and COOKIE data sanitized
DEBUG - 2011-10-03 12:48:37 --> Language Class Initialized
DEBUG - 2011-10-03 12:48:37 --> Loader Class Initialized
DEBUG - 2011-10-03 12:48:37 --> Controller Class Initialized
ERROR - 2011-10-03 12:48:37 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-10-03 12:48:37 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-10-03 12:48:37 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-10-03 12:48:37 --> Model Class Initialized
DEBUG - 2011-10-03 12:48:37 --> Model Class Initialized
DEBUG - 2011-10-03 12:48:37 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-10-03 12:48:37 --> Database Driver Class Initialized
DEBUG - 2011-10-03 12:48:37 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-10-03 12:48:37 --> Helper loaded: url_helper
DEBUG - 2011-10-03 12:48:37 --> File loaded: application/views/common/header.php
DEBUG - 2011-10-03 12:48:37 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-10-03 12:48:37 --> File loaded: application/views/common/footer.php
DEBUG - 2011-10-03 12:48:37 --> File loaded: application/views/layout/main.php
DEBUG - 2011-10-03 12:48:37 --> Final output sent to browser
DEBUG - 2011-10-03 12:48:37 --> Total execution time: 0.3460
DEBUG - 2011-10-03 12:48:39 --> Config Class Initialized
DEBUG - 2011-10-03 12:48:39 --> Hooks Class Initialized
DEBUG - 2011-10-03 12:48:39 --> Utf8 Class Initialized
DEBUG - 2011-10-03 12:48:39 --> UTF-8 Support Enabled
DEBUG - 2011-10-03 12:48:39 --> URI Class Initialized
DEBUG - 2011-10-03 12:48:39 --> Router Class Initialized
DEBUG - 2011-10-03 12:48:39 --> Output Class Initialized
DEBUG - 2011-10-03 12:48:39 --> Input Class Initialized
DEBUG - 2011-10-03 12:48:39 --> Global POST and COOKIE data sanitized
DEBUG - 2011-10-03 12:48:39 --> Language Class Initialized
DEBUG - 2011-10-03 12:48:39 --> Loader Class Initialized
DEBUG - 2011-10-03 12:48:39 --> Controller Class Initialized
DEBUG - 2011-10-03 12:48:39 --> Model Class Initialized
DEBUG - 2011-10-03 12:48:39 --> Model Class Initialized
DEBUG - 2011-10-03 12:48:39 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-10-03 12:48:39 --> Database Driver Class Initialized
DEBUG - 2011-10-03 12:48:41 --> Final output sent to browser
DEBUG - 2011-10-03 12:48:41 --> Total execution time: 1.8708
DEBUG - 2011-10-03 12:48:42 --> Config Class Initialized
DEBUG - 2011-10-03 12:48:42 --> Hooks Class Initialized
DEBUG - 2011-10-03 12:48:42 --> Utf8 Class Initialized
DEBUG - 2011-10-03 12:48:42 --> UTF-8 Support Enabled
DEBUG - 2011-10-03 12:48:42 --> URI Class Initialized
DEBUG - 2011-10-03 12:48:42 --> Router Class Initialized
ERROR - 2011-10-03 12:48:42 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-10-03 12:48:47 --> Config Class Initialized
DEBUG - 2011-10-03 12:48:47 --> Hooks Class Initialized
DEBUG - 2011-10-03 12:48:47 --> Utf8 Class Initialized
DEBUG - 2011-10-03 12:48:47 --> UTF-8 Support Enabled
DEBUG - 2011-10-03 12:48:47 --> URI Class Initialized
DEBUG - 2011-10-03 12:48:47 --> Router Class Initialized
DEBUG - 2011-10-03 12:48:47 --> Output Class Initialized
DEBUG - 2011-10-03 12:48:47 --> Input Class Initialized
DEBUG - 2011-10-03 12:48:47 --> Global POST and COOKIE data sanitized
DEBUG - 2011-10-03 12:48:47 --> Language Class Initialized
DEBUG - 2011-10-03 12:48:47 --> Loader Class Initialized
DEBUG - 2011-10-03 12:48:47 --> Controller Class Initialized
ERROR - 2011-10-03 12:48:47 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-10-03 12:48:47 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-10-03 12:48:47 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-10-03 12:48:47 --> Model Class Initialized
DEBUG - 2011-10-03 12:48:47 --> Model Class Initialized
DEBUG - 2011-10-03 12:48:47 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-10-03 12:48:47 --> Database Driver Class Initialized
DEBUG - 2011-10-03 12:48:47 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-10-03 12:48:47 --> Helper loaded: url_helper
DEBUG - 2011-10-03 12:48:47 --> File loaded: application/views/common/header.php
DEBUG - 2011-10-03 12:48:47 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-10-03 12:48:47 --> File loaded: application/views/common/footer.php
DEBUG - 2011-10-03 12:48:47 --> File loaded: application/views/layout/main.php
DEBUG - 2011-10-03 12:48:47 --> Final output sent to browser
DEBUG - 2011-10-03 12:48:47 --> Total execution time: 0.0332
DEBUG - 2011-10-03 12:48:48 --> Config Class Initialized
DEBUG - 2011-10-03 12:48:48 --> Hooks Class Initialized
DEBUG - 2011-10-03 12:48:48 --> Utf8 Class Initialized
DEBUG - 2011-10-03 12:48:48 --> UTF-8 Support Enabled
DEBUG - 2011-10-03 12:48:48 --> URI Class Initialized
DEBUG - 2011-10-03 12:48:48 --> Router Class Initialized
DEBUG - 2011-10-03 12:48:48 --> Output Class Initialized
DEBUG - 2011-10-03 12:48:48 --> Input Class Initialized
DEBUG - 2011-10-03 12:48:48 --> Global POST and COOKIE data sanitized
DEBUG - 2011-10-03 12:48:48 --> Language Class Initialized
DEBUG - 2011-10-03 12:48:48 --> Loader Class Initialized
DEBUG - 2011-10-03 12:48:48 --> Controller Class Initialized
DEBUG - 2011-10-03 12:48:48 --> Model Class Initialized
DEBUG - 2011-10-03 12:48:48 --> Model Class Initialized
DEBUG - 2011-10-03 12:48:48 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-10-03 12:48:48 --> Database Driver Class Initialized
DEBUG - 2011-10-03 12:48:49 --> Final output sent to browser
DEBUG - 2011-10-03 12:48:49 --> Total execution time: 0.7860
DEBUG - 2011-10-03 12:48:50 --> Config Class Initialized
DEBUG - 2011-10-03 12:48:50 --> Hooks Class Initialized
DEBUG - 2011-10-03 12:48:50 --> Utf8 Class Initialized
DEBUG - 2011-10-03 12:48:50 --> UTF-8 Support Enabled
DEBUG - 2011-10-03 12:48:50 --> URI Class Initialized
DEBUG - 2011-10-03 12:48:50 --> Router Class Initialized
ERROR - 2011-10-03 12:48:50 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-10-03 12:48:51 --> Config Class Initialized
DEBUG - 2011-10-03 12:48:51 --> Hooks Class Initialized
DEBUG - 2011-10-03 12:48:51 --> Utf8 Class Initialized
DEBUG - 2011-10-03 12:48:51 --> UTF-8 Support Enabled
DEBUG - 2011-10-03 12:48:51 --> URI Class Initialized
DEBUG - 2011-10-03 12:48:51 --> Router Class Initialized
DEBUG - 2011-10-03 12:48:51 --> Output Class Initialized
DEBUG - 2011-10-03 12:48:51 --> Input Class Initialized
DEBUG - 2011-10-03 12:48:51 --> Global POST and COOKIE data sanitized
DEBUG - 2011-10-03 12:48:51 --> Language Class Initialized
DEBUG - 2011-10-03 12:48:51 --> Loader Class Initialized
DEBUG - 2011-10-03 12:48:51 --> Controller Class Initialized
ERROR - 2011-10-03 12:48:51 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-10-03 12:48:51 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-10-03 12:48:51 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-10-03 12:48:51 --> Model Class Initialized
DEBUG - 2011-10-03 12:48:51 --> Model Class Initialized
DEBUG - 2011-10-03 12:48:51 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-10-03 12:48:51 --> Database Driver Class Initialized
DEBUG - 2011-10-03 12:48:51 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-10-03 12:48:51 --> Helper loaded: url_helper
DEBUG - 2011-10-03 12:48:51 --> File loaded: application/views/common/header.php
DEBUG - 2011-10-03 12:48:51 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-10-03 12:48:51 --> File loaded: application/views/common/footer.php
DEBUG - 2011-10-03 12:48:51 --> File loaded: application/views/layout/main.php
DEBUG - 2011-10-03 12:48:51 --> Final output sent to browser
DEBUG - 2011-10-03 12:48:51 --> Total execution time: 0.0744
DEBUG - 2011-10-03 12:48:52 --> Config Class Initialized
DEBUG - 2011-10-03 12:48:52 --> Hooks Class Initialized
DEBUG - 2011-10-03 12:48:52 --> Utf8 Class Initialized
DEBUG - 2011-10-03 12:48:52 --> UTF-8 Support Enabled
DEBUG - 2011-10-03 12:48:52 --> URI Class Initialized
DEBUG - 2011-10-03 12:48:52 --> Router Class Initialized
DEBUG - 2011-10-03 12:48:52 --> Output Class Initialized
DEBUG - 2011-10-03 12:48:52 --> Input Class Initialized
DEBUG - 2011-10-03 12:48:52 --> Global POST and COOKIE data sanitized
DEBUG - 2011-10-03 12:48:52 --> Language Class Initialized
DEBUG - 2011-10-03 12:48:52 --> Loader Class Initialized
DEBUG - 2011-10-03 12:48:52 --> Controller Class Initialized
DEBUG - 2011-10-03 12:48:52 --> Model Class Initialized
DEBUG - 2011-10-03 12:48:52 --> Model Class Initialized
DEBUG - 2011-10-03 12:48:52 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-10-03 12:48:52 --> Database Driver Class Initialized
DEBUG - 2011-10-03 12:48:52 --> Final output sent to browser
DEBUG - 2011-10-03 12:48:52 --> Total execution time: 0.6716
DEBUG - 2011-10-03 12:48:53 --> Config Class Initialized
DEBUG - 2011-10-03 12:48:53 --> Hooks Class Initialized
DEBUG - 2011-10-03 12:48:53 --> Utf8 Class Initialized
DEBUG - 2011-10-03 12:48:53 --> UTF-8 Support Enabled
DEBUG - 2011-10-03 12:48:53 --> URI Class Initialized
DEBUG - 2011-10-03 12:48:53 --> Router Class Initialized
ERROR - 2011-10-03 12:48:53 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-10-03 13:05:23 --> Config Class Initialized
DEBUG - 2011-10-03 13:05:23 --> Hooks Class Initialized
DEBUG - 2011-10-03 13:05:23 --> Utf8 Class Initialized
DEBUG - 2011-10-03 13:05:23 --> UTF-8 Support Enabled
DEBUG - 2011-10-03 13:05:23 --> URI Class Initialized
DEBUG - 2011-10-03 13:05:23 --> Router Class Initialized
DEBUG - 2011-10-03 13:05:23 --> Output Class Initialized
DEBUG - 2011-10-03 13:05:23 --> Input Class Initialized
DEBUG - 2011-10-03 13:05:23 --> Global POST and COOKIE data sanitized
DEBUG - 2011-10-03 13:05:23 --> Language Class Initialized
DEBUG - 2011-10-03 13:05:23 --> Loader Class Initialized
DEBUG - 2011-10-03 13:05:23 --> Controller Class Initialized
DEBUG - 2011-10-03 13:05:23 --> Model Class Initialized
DEBUG - 2011-10-03 13:05:23 --> Model Class Initialized
DEBUG - 2011-10-03 13:05:23 --> Model Class Initialized
DEBUG - 2011-10-03 13:05:23 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-10-03 13:05:23 --> Database Driver Class Initialized
DEBUG - 2011-10-03 13:05:25 --> File loaded: application/views/table/main.php
DEBUG - 2011-10-03 13:05:25 --> Helper loaded: url_helper
DEBUG - 2011-10-03 13:05:25 --> File loaded: application/views/common/header.php
DEBUG - 2011-10-03 13:05:25 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-10-03 13:05:25 --> File loaded: application/views/common/footer.php
DEBUG - 2011-10-03 13:05:25 --> File loaded: application/views/layout/main.php
DEBUG - 2011-10-03 13:05:25 --> Final output sent to browser
DEBUG - 2011-10-03 13:05:25 --> Total execution time: 1.7829
DEBUG - 2011-10-03 13:06:14 --> Config Class Initialized
DEBUG - 2011-10-03 13:06:14 --> Hooks Class Initialized
DEBUG - 2011-10-03 13:06:14 --> Utf8 Class Initialized
DEBUG - 2011-10-03 13:06:14 --> UTF-8 Support Enabled
DEBUG - 2011-10-03 13:06:14 --> URI Class Initialized
DEBUG - 2011-10-03 13:06:14 --> Router Class Initialized
DEBUG - 2011-10-03 13:06:14 --> Output Class Initialized
DEBUG - 2011-10-03 13:06:14 --> Input Class Initialized
DEBUG - 2011-10-03 13:06:14 --> Global POST and COOKIE data sanitized
DEBUG - 2011-10-03 13:06:14 --> Language Class Initialized
DEBUG - 2011-10-03 13:06:14 --> Loader Class Initialized
DEBUG - 2011-10-03 13:06:14 --> Controller Class Initialized
DEBUG - 2011-10-03 13:06:14 --> Model Class Initialized
DEBUG - 2011-10-03 13:06:14 --> Model Class Initialized
DEBUG - 2011-10-03 13:06:14 --> Model Class Initialized
DEBUG - 2011-10-03 13:06:14 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-10-03 13:06:14 --> Database Driver Class Initialized
DEBUG - 2011-10-03 13:06:16 --> File loaded: application/views/table/main.php
DEBUG - 2011-10-03 13:06:16 --> Helper loaded: url_helper
DEBUG - 2011-10-03 13:06:16 --> File loaded: application/views/common/header.php
DEBUG - 2011-10-03 13:06:16 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-10-03 13:06:16 --> File loaded: application/views/common/footer.php
DEBUG - 2011-10-03 13:06:16 --> File loaded: application/views/layout/main.php
DEBUG - 2011-10-03 13:06:16 --> Final output sent to browser
DEBUG - 2011-10-03 13:06:16 --> Total execution time: 2.3345
DEBUG - 2011-10-03 13:06:17 --> Config Class Initialized
DEBUG - 2011-10-03 13:06:17 --> Hooks Class Initialized
DEBUG - 2011-10-03 13:06:17 --> Utf8 Class Initialized
DEBUG - 2011-10-03 13:06:17 --> UTF-8 Support Enabled
DEBUG - 2011-10-03 13:06:17 --> URI Class Initialized
DEBUG - 2011-10-03 13:06:17 --> Router Class Initialized
DEBUG - 2011-10-03 13:06:17 --> Output Class Initialized
DEBUG - 2011-10-03 13:06:17 --> Input Class Initialized
DEBUG - 2011-10-03 13:06:17 --> Global POST and COOKIE data sanitized
DEBUG - 2011-10-03 13:06:17 --> Language Class Initialized
DEBUG - 2011-10-03 13:06:17 --> Loader Class Initialized
DEBUG - 2011-10-03 13:06:17 --> Controller Class Initialized
DEBUG - 2011-10-03 13:06:17 --> Model Class Initialized
DEBUG - 2011-10-03 13:06:17 --> Model Class Initialized
DEBUG - 2011-10-03 13:06:17 --> Model Class Initialized
DEBUG - 2011-10-03 13:06:17 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-10-03 13:06:17 --> Database Driver Class Initialized
DEBUG - 2011-10-03 13:06:17 --> File loaded: application/views/table/main.php
DEBUG - 2011-10-03 13:06:17 --> Helper loaded: url_helper
DEBUG - 2011-10-03 13:06:17 --> File loaded: application/views/common/header.php
DEBUG - 2011-10-03 13:06:17 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-10-03 13:06:17 --> File loaded: application/views/common/footer.php
DEBUG - 2011-10-03 13:06:17 --> File loaded: application/views/layout/main.php
DEBUG - 2011-10-03 13:06:17 --> Final output sent to browser
DEBUG - 2011-10-03 13:06:17 --> Total execution time: 0.3671
DEBUG - 2011-10-03 13:06:18 --> Config Class Initialized
DEBUG - 2011-10-03 13:06:18 --> Hooks Class Initialized
DEBUG - 2011-10-03 13:06:18 --> Utf8 Class Initialized
DEBUG - 2011-10-03 13:06:18 --> UTF-8 Support Enabled
DEBUG - 2011-10-03 13:06:18 --> URI Class Initialized
DEBUG - 2011-10-03 13:06:18 --> Router Class Initialized
DEBUG - 2011-10-03 13:06:18 --> Output Class Initialized
DEBUG - 2011-10-03 13:06:18 --> Input Class Initialized
DEBUG - 2011-10-03 13:06:18 --> Global POST and COOKIE data sanitized
DEBUG - 2011-10-03 13:06:18 --> Language Class Initialized
DEBUG - 2011-10-03 13:06:18 --> Loader Class Initialized
DEBUG - 2011-10-03 13:06:18 --> Controller Class Initialized
DEBUG - 2011-10-03 13:06:18 --> Model Class Initialized
DEBUG - 2011-10-03 13:06:18 --> Model Class Initialized
DEBUG - 2011-10-03 13:06:18 --> Model Class Initialized
DEBUG - 2011-10-03 13:06:18 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-10-03 13:06:19 --> Database Driver Class Initialized
DEBUG - 2011-10-03 13:06:19 --> File loaded: application/views/table/main.php
DEBUG - 2011-10-03 13:06:19 --> Helper loaded: url_helper
DEBUG - 2011-10-03 13:06:19 --> File loaded: application/views/common/header.php
DEBUG - 2011-10-03 13:06:19 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-10-03 13:06:19 --> File loaded: application/views/common/footer.php
DEBUG - 2011-10-03 13:06:19 --> File loaded: application/views/layout/main.php
DEBUG - 2011-10-03 13:06:19 --> Final output sent to browser
DEBUG - 2011-10-03 13:06:19 --> Total execution time: 0.2947
DEBUG - 2011-10-03 13:06:19 --> Config Class Initialized
DEBUG - 2011-10-03 13:06:19 --> Hooks Class Initialized
DEBUG - 2011-10-03 13:06:19 --> Utf8 Class Initialized
DEBUG - 2011-10-03 13:06:19 --> UTF-8 Support Enabled
DEBUG - 2011-10-03 13:06:19 --> URI Class Initialized
DEBUG - 2011-10-03 13:06:19 --> Router Class Initialized
DEBUG - 2011-10-03 13:06:19 --> Output Class Initialized
DEBUG - 2011-10-03 13:06:19 --> Input Class Initialized
DEBUG - 2011-10-03 13:06:19 --> Global POST and COOKIE data sanitized
DEBUG - 2011-10-03 13:06:19 --> Language Class Initialized
DEBUG - 2011-10-03 13:06:19 --> Loader Class Initialized
DEBUG - 2011-10-03 13:06:19 --> Controller Class Initialized
DEBUG - 2011-10-03 13:06:19 --> Model Class Initialized
DEBUG - 2011-10-03 13:06:19 --> Model Class Initialized
DEBUG - 2011-10-03 13:06:19 --> Model Class Initialized
DEBUG - 2011-10-03 13:06:19 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-10-03 13:06:19 --> Database Driver Class Initialized
DEBUG - 2011-10-03 13:06:19 --> File loaded: application/views/table/main.php
DEBUG - 2011-10-03 13:06:19 --> Helper loaded: url_helper
DEBUG - 2011-10-03 13:06:19 --> File loaded: application/views/common/header.php
DEBUG - 2011-10-03 13:06:19 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-10-03 13:06:19 --> File loaded: application/views/common/footer.php
DEBUG - 2011-10-03 13:06:19 --> File loaded: application/views/layout/main.php
DEBUG - 2011-10-03 13:06:19 --> Final output sent to browser
DEBUG - 2011-10-03 13:06:19 --> Total execution time: 0.2015
DEBUG - 2011-10-03 13:06:36 --> Config Class Initialized
DEBUG - 2011-10-03 13:06:36 --> Hooks Class Initialized
DEBUG - 2011-10-03 13:06:36 --> Utf8 Class Initialized
DEBUG - 2011-10-03 13:06:36 --> UTF-8 Support Enabled
DEBUG - 2011-10-03 13:06:36 --> URI Class Initialized
DEBUG - 2011-10-03 13:06:36 --> Router Class Initialized
DEBUG - 2011-10-03 13:06:36 --> Output Class Initialized
DEBUG - 2011-10-03 13:06:36 --> Input Class Initialized
DEBUG - 2011-10-03 13:06:36 --> Global POST and COOKIE data sanitized
DEBUG - 2011-10-03 13:06:36 --> Language Class Initialized
DEBUG - 2011-10-03 13:06:36 --> Loader Class Initialized
DEBUG - 2011-10-03 13:06:36 --> Controller Class Initialized
DEBUG - 2011-10-03 13:06:36 --> Model Class Initialized
DEBUG - 2011-10-03 13:06:36 --> Model Class Initialized
DEBUG - 2011-10-03 13:06:36 --> Model Class Initialized
DEBUG - 2011-10-03 13:06:36 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-10-03 13:06:36 --> Database Driver Class Initialized
DEBUG - 2011-10-03 13:06:37 --> File loaded: application/views/table/main.php
DEBUG - 2011-10-03 13:06:37 --> Helper loaded: url_helper
DEBUG - 2011-10-03 13:06:37 --> File loaded: application/views/common/header.php
DEBUG - 2011-10-03 13:06:37 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-10-03 13:06:37 --> File loaded: application/views/common/footer.php
DEBUG - 2011-10-03 13:06:37 --> File loaded: application/views/layout/main.php
DEBUG - 2011-10-03 13:06:37 --> Final output sent to browser
DEBUG - 2011-10-03 13:06:37 --> Total execution time: 1.3025
DEBUG - 2011-10-03 13:06:43 --> Config Class Initialized
DEBUG - 2011-10-03 13:06:43 --> Hooks Class Initialized
DEBUG - 2011-10-03 13:06:43 --> Utf8 Class Initialized
DEBUG - 2011-10-03 13:06:43 --> UTF-8 Support Enabled
DEBUG - 2011-10-03 13:06:43 --> URI Class Initialized
DEBUG - 2011-10-03 13:06:43 --> Router Class Initialized
DEBUG - 2011-10-03 13:06:43 --> Output Class Initialized
DEBUG - 2011-10-03 13:06:43 --> Input Class Initialized
DEBUG - 2011-10-03 13:06:43 --> Global POST and COOKIE data sanitized
DEBUG - 2011-10-03 13:06:43 --> Language Class Initialized
DEBUG - 2011-10-03 13:06:43 --> Loader Class Initialized
DEBUG - 2011-10-03 13:06:43 --> Controller Class Initialized
DEBUG - 2011-10-03 13:06:43 --> Model Class Initialized
DEBUG - 2011-10-03 13:06:43 --> Model Class Initialized
DEBUG - 2011-10-03 13:06:43 --> Model Class Initialized
DEBUG - 2011-10-03 13:06:43 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-10-03 13:06:43 --> Database Driver Class Initialized
DEBUG - 2011-10-03 13:06:43 --> File loaded: application/views/table/main.php
DEBUG - 2011-10-03 13:06:43 --> Helper loaded: url_helper
DEBUG - 2011-10-03 13:06:43 --> File loaded: application/views/common/header.php
DEBUG - 2011-10-03 13:06:43 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-10-03 13:06:43 --> File loaded: application/views/common/footer.php
DEBUG - 2011-10-03 13:06:43 --> File loaded: application/views/layout/main.php
DEBUG - 2011-10-03 13:06:43 --> Final output sent to browser
DEBUG - 2011-10-03 13:06:43 --> Total execution time: 0.1650
DEBUG - 2011-10-03 13:58:29 --> Config Class Initialized
DEBUG - 2011-10-03 13:58:29 --> Hooks Class Initialized
DEBUG - 2011-10-03 13:58:29 --> Utf8 Class Initialized
DEBUG - 2011-10-03 13:58:29 --> UTF-8 Support Enabled
DEBUG - 2011-10-03 13:58:29 --> URI Class Initialized
DEBUG - 2011-10-03 13:58:29 --> Router Class Initialized
DEBUG - 2011-10-03 13:58:29 --> No URI present. Default controller set.
DEBUG - 2011-10-03 13:58:29 --> Output Class Initialized
DEBUG - 2011-10-03 13:58:29 --> Input Class Initialized
DEBUG - 2011-10-03 13:58:29 --> Global POST and COOKIE data sanitized
DEBUG - 2011-10-03 13:58:29 --> Language Class Initialized
DEBUG - 2011-10-03 13:58:29 --> Loader Class Initialized
DEBUG - 2011-10-03 13:58:29 --> Controller Class Initialized
DEBUG - 2011-10-03 13:58:29 --> File loaded: application/views/splash/main.php
DEBUG - 2011-10-03 13:58:29 --> Helper loaded: url_helper
DEBUG - 2011-10-03 13:58:29 --> File loaded: application/views/common/header.php
DEBUG - 2011-10-03 13:58:29 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-10-03 13:58:29 --> File loaded: application/views/common/footer.php
DEBUG - 2011-10-03 13:58:29 --> File loaded: application/views/layout/main.php
DEBUG - 2011-10-03 13:58:29 --> Final output sent to browser
DEBUG - 2011-10-03 13:58:29 --> Total execution time: 0.0506
DEBUG - 2011-10-03 15:30:06 --> Config Class Initialized
DEBUG - 2011-10-03 15:30:06 --> Hooks Class Initialized
DEBUG - 2011-10-03 15:30:06 --> Utf8 Class Initialized
DEBUG - 2011-10-03 15:30:06 --> UTF-8 Support Enabled
DEBUG - 2011-10-03 15:30:06 --> URI Class Initialized
DEBUG - 2011-10-03 15:30:06 --> Router Class Initialized
DEBUG - 2011-10-03 15:30:06 --> Output Class Initialized
DEBUG - 2011-10-03 15:30:06 --> Input Class Initialized
DEBUG - 2011-10-03 15:30:06 --> Global POST and COOKIE data sanitized
DEBUG - 2011-10-03 15:30:06 --> Language Class Initialized
DEBUG - 2011-10-03 15:30:06 --> Loader Class Initialized
DEBUG - 2011-10-03 15:30:06 --> Controller Class Initialized
ERROR - 2011-10-03 15:30:06 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-10-03 15:30:06 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-10-03 15:30:06 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-10-03 15:30:06 --> Model Class Initialized
DEBUG - 2011-10-03 15:30:06 --> Model Class Initialized
DEBUG - 2011-10-03 15:30:06 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-10-03 15:30:06 --> Database Driver Class Initialized
DEBUG - 2011-10-03 15:30:07 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-10-03 15:30:07 --> Helper loaded: url_helper
DEBUG - 2011-10-03 15:30:07 --> File loaded: application/views/common/header.php
DEBUG - 2011-10-03 15:30:07 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-10-03 15:30:07 --> File loaded: application/views/common/footer.php
DEBUG - 2011-10-03 15:30:07 --> File loaded: application/views/layout/main.php
DEBUG - 2011-10-03 15:30:07 --> Final output sent to browser
DEBUG - 2011-10-03 15:30:07 --> Total execution time: 0.5333
DEBUG - 2011-10-03 15:30:07 --> Config Class Initialized
DEBUG - 2011-10-03 15:30:07 --> Hooks Class Initialized
DEBUG - 2011-10-03 15:30:07 --> Utf8 Class Initialized
DEBUG - 2011-10-03 15:30:07 --> UTF-8 Support Enabled
DEBUG - 2011-10-03 15:30:07 --> URI Class Initialized
DEBUG - 2011-10-03 15:30:07 --> Router Class Initialized
DEBUG - 2011-10-03 15:30:07 --> Output Class Initialized
DEBUG - 2011-10-03 15:30:07 --> Input Class Initialized
DEBUG - 2011-10-03 15:30:07 --> Global POST and COOKIE data sanitized
DEBUG - 2011-10-03 15:30:07 --> Language Class Initialized
DEBUG - 2011-10-03 15:30:07 --> Loader Class Initialized
DEBUG - 2011-10-03 15:30:07 --> Controller Class Initialized
DEBUG - 2011-10-03 15:30:07 --> Model Class Initialized
DEBUG - 2011-10-03 15:30:07 --> Model Class Initialized
DEBUG - 2011-10-03 15:30:07 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-10-03 15:30:07 --> Database Driver Class Initialized
DEBUG - 2011-10-03 15:30:08 --> Final output sent to browser
DEBUG - 2011-10-03 15:30:08 --> Total execution time: 0.8555
DEBUG - 2011-10-03 15:30:11 --> Config Class Initialized
DEBUG - 2011-10-03 15:30:11 --> Hooks Class Initialized
DEBUG - 2011-10-03 15:30:11 --> Utf8 Class Initialized
DEBUG - 2011-10-03 15:30:11 --> UTF-8 Support Enabled
DEBUG - 2011-10-03 15:30:11 --> URI Class Initialized
DEBUG - 2011-10-03 15:30:11 --> Router Class Initialized
ERROR - 2011-10-03 15:30:11 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-10-03 15:30:12 --> Config Class Initialized
DEBUG - 2011-10-03 15:30:12 --> Hooks Class Initialized
DEBUG - 2011-10-03 15:30:12 --> Utf8 Class Initialized
DEBUG - 2011-10-03 15:30:12 --> UTF-8 Support Enabled
DEBUG - 2011-10-03 15:30:12 --> URI Class Initialized
DEBUG - 2011-10-03 15:30:12 --> Router Class Initialized
ERROR - 2011-10-03 15:30:12 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-10-03 15:30:12 --> Config Class Initialized
DEBUG - 2011-10-03 15:30:12 --> Hooks Class Initialized
DEBUG - 2011-10-03 15:30:12 --> Utf8 Class Initialized
DEBUG - 2011-10-03 15:30:12 --> UTF-8 Support Enabled
DEBUG - 2011-10-03 15:30:12 --> URI Class Initialized
DEBUG - 2011-10-03 15:30:12 --> Router Class Initialized
ERROR - 2011-10-03 15:30:12 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-10-03 15:31:00 --> Config Class Initialized
DEBUG - 2011-10-03 15:31:00 --> Hooks Class Initialized
DEBUG - 2011-10-03 15:31:00 --> Utf8 Class Initialized
DEBUG - 2011-10-03 15:31:00 --> UTF-8 Support Enabled
DEBUG - 2011-10-03 15:31:00 --> URI Class Initialized
DEBUG - 2011-10-03 15:31:00 --> Router Class Initialized
DEBUG - 2011-10-03 15:31:00 --> Output Class Initialized
DEBUG - 2011-10-03 15:31:00 --> Input Class Initialized
DEBUG - 2011-10-03 15:31:00 --> Global POST and COOKIE data sanitized
DEBUG - 2011-10-03 15:31:00 --> Language Class Initialized
DEBUG - 2011-10-03 15:31:00 --> Loader Class Initialized
DEBUG - 2011-10-03 15:31:00 --> Controller Class Initialized
ERROR - 2011-10-03 15:31:00 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-10-03 15:31:00 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-10-03 15:31:00 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-10-03 15:31:00 --> Model Class Initialized
DEBUG - 2011-10-03 15:31:00 --> Model Class Initialized
DEBUG - 2011-10-03 15:31:00 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-10-03 15:31:00 --> Database Driver Class Initialized
DEBUG - 2011-10-03 15:31:00 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-10-03 15:31:00 --> Helper loaded: url_helper
DEBUG - 2011-10-03 15:31:00 --> File loaded: application/views/common/header.php
DEBUG - 2011-10-03 15:31:00 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-10-03 15:31:00 --> File loaded: application/views/common/footer.php
DEBUG - 2011-10-03 15:31:00 --> File loaded: application/views/layout/main.php
DEBUG - 2011-10-03 15:31:00 --> Final output sent to browser
DEBUG - 2011-10-03 15:31:00 --> Total execution time: 0.0358
DEBUG - 2011-10-03 15:31:01 --> Config Class Initialized
DEBUG - 2011-10-03 15:31:01 --> Hooks Class Initialized
DEBUG - 2011-10-03 15:31:01 --> Utf8 Class Initialized
DEBUG - 2011-10-03 15:31:01 --> UTF-8 Support Enabled
DEBUG - 2011-10-03 15:31:01 --> URI Class Initialized
DEBUG - 2011-10-03 15:31:01 --> Router Class Initialized
DEBUG - 2011-10-03 15:31:01 --> Output Class Initialized
DEBUG - 2011-10-03 15:31:01 --> Input Class Initialized
DEBUG - 2011-10-03 15:31:01 --> Global POST and COOKIE data sanitized
DEBUG - 2011-10-03 15:31:01 --> Language Class Initialized
DEBUG - 2011-10-03 15:31:01 --> Loader Class Initialized
DEBUG - 2011-10-03 15:31:01 --> Controller Class Initialized
DEBUG - 2011-10-03 15:31:01 --> Model Class Initialized
DEBUG - 2011-10-03 15:31:01 --> Model Class Initialized
DEBUG - 2011-10-03 15:31:01 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-10-03 15:31:01 --> Database Driver Class Initialized
DEBUG - 2011-10-03 15:31:02 --> Final output sent to browser
DEBUG - 2011-10-03 15:31:02 --> Total execution time: 0.7555
DEBUG - 2011-10-03 15:35:23 --> Config Class Initialized
DEBUG - 2011-10-03 15:35:23 --> Hooks Class Initialized
DEBUG - 2011-10-03 15:35:23 --> Utf8 Class Initialized
DEBUG - 2011-10-03 15:35:23 --> UTF-8 Support Enabled
DEBUG - 2011-10-03 15:35:23 --> URI Class Initialized
DEBUG - 2011-10-03 15:35:23 --> Router Class Initialized
DEBUG - 2011-10-03 15:35:23 --> Output Class Initialized
DEBUG - 2011-10-03 15:35:23 --> Input Class Initialized
DEBUG - 2011-10-03 15:35:23 --> Global POST and COOKIE data sanitized
DEBUG - 2011-10-03 15:35:23 --> Language Class Initialized
DEBUG - 2011-10-03 15:35:23 --> Loader Class Initialized
DEBUG - 2011-10-03 15:35:23 --> Controller Class Initialized
ERROR - 2011-10-03 15:35:23 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-10-03 15:35:23 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-10-03 15:35:23 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-10-03 15:35:23 --> Model Class Initialized
DEBUG - 2011-10-03 15:35:23 --> Model Class Initialized
DEBUG - 2011-10-03 15:35:23 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-10-03 15:35:23 --> Database Driver Class Initialized
DEBUG - 2011-10-03 15:35:23 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-10-03 15:35:23 --> Helper loaded: url_helper
DEBUG - 2011-10-03 15:35:23 --> File loaded: application/views/common/header.php
DEBUG - 2011-10-03 15:35:23 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-10-03 15:35:23 --> File loaded: application/views/common/footer.php
DEBUG - 2011-10-03 15:35:23 --> File loaded: application/views/layout/main.php
DEBUG - 2011-10-03 15:35:23 --> Final output sent to browser
DEBUG - 2011-10-03 15:35:23 --> Total execution time: 0.0758
DEBUG - 2011-10-03 15:35:28 --> Config Class Initialized
DEBUG - 2011-10-03 15:35:28 --> Hooks Class Initialized
DEBUG - 2011-10-03 15:35:28 --> Utf8 Class Initialized
DEBUG - 2011-10-03 15:35:28 --> UTF-8 Support Enabled
DEBUG - 2011-10-03 15:35:28 --> URI Class Initialized
DEBUG - 2011-10-03 15:35:28 --> Router Class Initialized
DEBUG - 2011-10-03 15:35:28 --> Output Class Initialized
DEBUG - 2011-10-03 15:35:28 --> Input Class Initialized
DEBUG - 2011-10-03 15:35:28 --> Global POST and COOKIE data sanitized
DEBUG - 2011-10-03 15:35:28 --> Language Class Initialized
DEBUG - 2011-10-03 15:35:28 --> Loader Class Initialized
DEBUG - 2011-10-03 15:35:28 --> Controller Class Initialized
DEBUG - 2011-10-03 15:35:28 --> Model Class Initialized
DEBUG - 2011-10-03 15:35:28 --> Model Class Initialized
DEBUG - 2011-10-03 15:35:28 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-10-03 15:35:28 --> Database Driver Class Initialized
DEBUG - 2011-10-03 15:35:28 --> Final output sent to browser
DEBUG - 2011-10-03 15:35:28 --> Total execution time: 0.6313
DEBUG - 2011-10-03 15:35:35 --> Config Class Initialized
DEBUG - 2011-10-03 15:35:35 --> Hooks Class Initialized
DEBUG - 2011-10-03 15:35:35 --> Utf8 Class Initialized
DEBUG - 2011-10-03 15:35:35 --> UTF-8 Support Enabled
DEBUG - 2011-10-03 15:35:35 --> URI Class Initialized
DEBUG - 2011-10-03 15:35:35 --> Router Class Initialized
ERROR - 2011-10-03 15:35:35 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-10-03 15:35:36 --> Config Class Initialized
DEBUG - 2011-10-03 15:35:36 --> Hooks Class Initialized
DEBUG - 2011-10-03 15:35:36 --> Utf8 Class Initialized
DEBUG - 2011-10-03 15:35:36 --> UTF-8 Support Enabled
DEBUG - 2011-10-03 15:35:36 --> URI Class Initialized
DEBUG - 2011-10-03 15:35:36 --> Router Class Initialized
ERROR - 2011-10-03 15:35:36 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-10-03 15:36:16 --> Config Class Initialized
DEBUG - 2011-10-03 15:36:16 --> Hooks Class Initialized
DEBUG - 2011-10-03 15:36:16 --> Utf8 Class Initialized
DEBUG - 2011-10-03 15:36:16 --> UTF-8 Support Enabled
DEBUG - 2011-10-03 15:36:16 --> URI Class Initialized
DEBUG - 2011-10-03 15:36:16 --> Router Class Initialized
DEBUG - 2011-10-03 15:36:16 --> Output Class Initialized
DEBUG - 2011-10-03 15:36:16 --> Input Class Initialized
DEBUG - 2011-10-03 15:36:16 --> Global POST and COOKIE data sanitized
DEBUG - 2011-10-03 15:36:16 --> Language Class Initialized
DEBUG - 2011-10-03 15:36:16 --> Loader Class Initialized
DEBUG - 2011-10-03 15:36:16 --> Controller Class Initialized
ERROR - 2011-10-03 15:36:16 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-10-03 15:36:16 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-10-03 15:36:16 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-10-03 15:36:16 --> Model Class Initialized
DEBUG - 2011-10-03 15:36:16 --> Model Class Initialized
DEBUG - 2011-10-03 15:36:16 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-10-03 15:36:16 --> Database Driver Class Initialized
DEBUG - 2011-10-03 15:36:16 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-10-03 15:36:16 --> Helper loaded: url_helper
DEBUG - 2011-10-03 15:36:16 --> File loaded: application/views/common/header.php
DEBUG - 2011-10-03 15:36:16 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-10-03 15:36:16 --> File loaded: application/views/common/footer.php
DEBUG - 2011-10-03 15:36:16 --> File loaded: application/views/layout/main.php
DEBUG - 2011-10-03 15:36:16 --> Final output sent to browser
DEBUG - 2011-10-03 15:36:16 --> Total execution time: 0.0294
DEBUG - 2011-10-03 15:36:18 --> Config Class Initialized
DEBUG - 2011-10-03 15:36:18 --> Hooks Class Initialized
DEBUG - 2011-10-03 15:36:18 --> Utf8 Class Initialized
DEBUG - 2011-10-03 15:36:18 --> UTF-8 Support Enabled
DEBUG - 2011-10-03 15:36:18 --> URI Class Initialized
DEBUG - 2011-10-03 15:36:18 --> Router Class Initialized
DEBUG - 2011-10-03 15:36:18 --> Output Class Initialized
DEBUG - 2011-10-03 15:36:18 --> Input Class Initialized
DEBUG - 2011-10-03 15:36:18 --> Global POST and COOKIE data sanitized
DEBUG - 2011-10-03 15:36:18 --> Language Class Initialized
DEBUG - 2011-10-03 15:36:18 --> Loader Class Initialized
DEBUG - 2011-10-03 15:36:18 --> Controller Class Initialized
DEBUG - 2011-10-03 15:36:18 --> Model Class Initialized
DEBUG - 2011-10-03 15:36:18 --> Model Class Initialized
DEBUG - 2011-10-03 15:36:18 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-10-03 15:36:18 --> Database Driver Class Initialized
DEBUG - 2011-10-03 15:36:18 --> Final output sent to browser
DEBUG - 2011-10-03 15:36:18 --> Total execution time: 0.6408
DEBUG - 2011-10-03 15:36:21 --> Config Class Initialized
DEBUG - 2011-10-03 15:36:21 --> Hooks Class Initialized
DEBUG - 2011-10-03 15:36:21 --> Utf8 Class Initialized
DEBUG - 2011-10-03 15:36:21 --> UTF-8 Support Enabled
DEBUG - 2011-10-03 15:36:21 --> URI Class Initialized
DEBUG - 2011-10-03 15:36:21 --> Router Class Initialized
ERROR - 2011-10-03 15:36:21 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-10-03 15:42:25 --> Config Class Initialized
DEBUG - 2011-10-03 15:42:25 --> Hooks Class Initialized
DEBUG - 2011-10-03 15:42:25 --> Utf8 Class Initialized
DEBUG - 2011-10-03 15:42:25 --> UTF-8 Support Enabled
DEBUG - 2011-10-03 15:42:25 --> URI Class Initialized
DEBUG - 2011-10-03 15:42:25 --> Router Class Initialized
DEBUG - 2011-10-03 15:42:25 --> Output Class Initialized
DEBUG - 2011-10-03 15:42:25 --> Input Class Initialized
DEBUG - 2011-10-03 15:42:25 --> Global POST and COOKIE data sanitized
DEBUG - 2011-10-03 15:42:25 --> Language Class Initialized
DEBUG - 2011-10-03 15:42:25 --> Loader Class Initialized
DEBUG - 2011-10-03 15:42:25 --> Controller Class Initialized
ERROR - 2011-10-03 15:42:25 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-10-03 15:42:25 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-10-03 15:42:25 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-10-03 15:42:25 --> Model Class Initialized
DEBUG - 2011-10-03 15:42:25 --> Model Class Initialized
DEBUG - 2011-10-03 15:42:25 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-10-03 15:42:25 --> Database Driver Class Initialized
DEBUG - 2011-10-03 15:42:25 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-10-03 15:42:25 --> Helper loaded: url_helper
DEBUG - 2011-10-03 15:42:25 --> File loaded: application/views/common/header.php
DEBUG - 2011-10-03 15:42:25 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-10-03 15:42:25 --> File loaded: application/views/common/footer.php
DEBUG - 2011-10-03 15:42:25 --> File loaded: application/views/layout/main.php
DEBUG - 2011-10-03 15:42:25 --> Final output sent to browser
DEBUG - 2011-10-03 15:42:25 --> Total execution time: 0.0355
DEBUG - 2011-10-03 15:42:27 --> Config Class Initialized
DEBUG - 2011-10-03 15:42:27 --> Hooks Class Initialized
DEBUG - 2011-10-03 15:42:27 --> Utf8 Class Initialized
DEBUG - 2011-10-03 15:42:27 --> UTF-8 Support Enabled
DEBUG - 2011-10-03 15:42:27 --> URI Class Initialized
DEBUG - 2011-10-03 15:42:27 --> Router Class Initialized
DEBUG - 2011-10-03 15:42:27 --> Output Class Initialized
DEBUG - 2011-10-03 15:42:27 --> Input Class Initialized
DEBUG - 2011-10-03 15:42:27 --> Global POST and COOKIE data sanitized
DEBUG - 2011-10-03 15:42:27 --> Language Class Initialized
DEBUG - 2011-10-03 15:42:27 --> Loader Class Initialized
DEBUG - 2011-10-03 15:42:27 --> Controller Class Initialized
DEBUG - 2011-10-03 15:42:27 --> Model Class Initialized
DEBUG - 2011-10-03 15:42:27 --> Model Class Initialized
DEBUG - 2011-10-03 15:42:27 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-10-03 15:42:27 --> Database Driver Class Initialized
DEBUG - 2011-10-03 15:42:27 --> Final output sent to browser
DEBUG - 2011-10-03 15:42:27 --> Total execution time: 0.5210
DEBUG - 2011-10-03 15:42:29 --> Config Class Initialized
DEBUG - 2011-10-03 15:42:29 --> Hooks Class Initialized
DEBUG - 2011-10-03 15:42:29 --> Utf8 Class Initialized
DEBUG - 2011-10-03 15:42:29 --> UTF-8 Support Enabled
DEBUG - 2011-10-03 15:42:29 --> URI Class Initialized
DEBUG - 2011-10-03 15:42:29 --> Router Class Initialized
ERROR - 2011-10-03 15:42:29 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-10-03 15:42:58 --> Config Class Initialized
DEBUG - 2011-10-03 15:42:58 --> Hooks Class Initialized
DEBUG - 2011-10-03 15:42:58 --> Utf8 Class Initialized
DEBUG - 2011-10-03 15:42:58 --> UTF-8 Support Enabled
DEBUG - 2011-10-03 15:42:58 --> URI Class Initialized
DEBUG - 2011-10-03 15:42:58 --> Router Class Initialized
ERROR - 2011-10-03 15:42:58 --> 404 Page Not Found --> robots.txt
DEBUG - 2011-10-03 15:42:59 --> Config Class Initialized
DEBUG - 2011-10-03 15:42:59 --> Hooks Class Initialized
DEBUG - 2011-10-03 15:42:59 --> Utf8 Class Initialized
DEBUG - 2011-10-03 15:42:59 --> UTF-8 Support Enabled
DEBUG - 2011-10-03 15:42:59 --> URI Class Initialized
DEBUG - 2011-10-03 15:42:59 --> Router Class Initialized
DEBUG - 2011-10-03 15:42:59 --> Output Class Initialized
DEBUG - 2011-10-03 15:42:59 --> Input Class Initialized
DEBUG - 2011-10-03 15:42:59 --> Global POST and COOKIE data sanitized
DEBUG - 2011-10-03 15:42:59 --> Language Class Initialized
DEBUG - 2011-10-03 15:42:59 --> Loader Class Initialized
DEBUG - 2011-10-03 15:42:59 --> Controller Class Initialized
ERROR - 2011-10-03 15:42:59 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-10-03 15:42:59 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-10-03 15:42:59 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-10-03 15:42:59 --> Model Class Initialized
DEBUG - 2011-10-03 15:42:59 --> Model Class Initialized
DEBUG - 2011-10-03 15:42:59 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-10-03 15:42:59 --> Database Driver Class Initialized
DEBUG - 2011-10-03 15:42:59 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-10-03 15:42:59 --> Helper loaded: url_helper
DEBUG - 2011-10-03 15:42:59 --> File loaded: application/views/common/header.php
DEBUG - 2011-10-03 15:42:59 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-10-03 15:42:59 --> File loaded: application/views/common/footer.php
DEBUG - 2011-10-03 15:42:59 --> File loaded: application/views/layout/main.php
DEBUG - 2011-10-03 15:42:59 --> Final output sent to browser
DEBUG - 2011-10-03 15:42:59 --> Total execution time: 0.0353
DEBUG - 2011-10-03 15:42:59 --> Config Class Initialized
DEBUG - 2011-10-03 15:42:59 --> Hooks Class Initialized
DEBUG - 2011-10-03 15:42:59 --> Utf8 Class Initialized
DEBUG - 2011-10-03 15:42:59 --> UTF-8 Support Enabled
DEBUG - 2011-10-03 15:42:59 --> URI Class Initialized
DEBUG - 2011-10-03 15:42:59 --> Router Class Initialized
DEBUG - 2011-10-03 15:42:59 --> Output Class Initialized
DEBUG - 2011-10-03 15:42:59 --> Input Class Initialized
DEBUG - 2011-10-03 15:42:59 --> Global POST and COOKIE data sanitized
DEBUG - 2011-10-03 15:42:59 --> Language Class Initialized
DEBUG - 2011-10-03 15:42:59 --> Loader Class Initialized
DEBUG - 2011-10-03 15:42:59 --> Controller Class Initialized
DEBUG - 2011-10-03 15:42:59 --> Model Class Initialized
DEBUG - 2011-10-03 15:42:59 --> Model Class Initialized
DEBUG - 2011-10-03 15:42:59 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-10-03 15:42:59 --> Database Driver Class Initialized
DEBUG - 2011-10-03 15:42:59 --> Final output sent to browser
DEBUG - 2011-10-03 15:42:59 --> Total execution time: 0.3714
DEBUG - 2011-10-03 16:32:50 --> Config Class Initialized
DEBUG - 2011-10-03 16:32:50 --> Hooks Class Initialized
DEBUG - 2011-10-03 16:32:50 --> Utf8 Class Initialized
DEBUG - 2011-10-03 16:32:50 --> UTF-8 Support Enabled
DEBUG - 2011-10-03 16:32:50 --> URI Class Initialized
DEBUG - 2011-10-03 16:32:50 --> Router Class Initialized
DEBUG - 2011-10-03 16:32:50 --> Output Class Initialized
DEBUG - 2011-10-03 16:32:50 --> Input Class Initialized
DEBUG - 2011-10-03 16:32:50 --> Global POST and COOKIE data sanitized
DEBUG - 2011-10-03 16:32:50 --> Language Class Initialized
DEBUG - 2011-10-03 16:32:50 --> Loader Class Initialized
DEBUG - 2011-10-03 16:32:50 --> Controller Class Initialized
ERROR - 2011-10-03 16:32:50 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-10-03 16:32:50 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-10-03 16:32:50 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-10-03 16:32:50 --> Model Class Initialized
DEBUG - 2011-10-03 16:32:50 --> Model Class Initialized
DEBUG - 2011-10-03 16:32:50 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-10-03 16:32:50 --> Database Driver Class Initialized
DEBUG - 2011-10-03 16:32:50 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-10-03 16:32:50 --> Helper loaded: url_helper
DEBUG - 2011-10-03 16:32:50 --> File loaded: application/views/common/header.php
DEBUG - 2011-10-03 16:32:50 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-10-03 16:32:50 --> File loaded: application/views/common/footer.php
DEBUG - 2011-10-03 16:32:50 --> File loaded: application/views/layout/main.php
DEBUG - 2011-10-03 16:32:50 --> Final output sent to browser
DEBUG - 2011-10-03 16:32:50 --> Total execution time: 0.3720
DEBUG - 2011-10-03 16:32:52 --> Config Class Initialized
DEBUG - 2011-10-03 16:32:52 --> Hooks Class Initialized
DEBUG - 2011-10-03 16:32:52 --> Utf8 Class Initialized
DEBUG - 2011-10-03 16:32:52 --> UTF-8 Support Enabled
DEBUG - 2011-10-03 16:32:52 --> URI Class Initialized
DEBUG - 2011-10-03 16:32:52 --> Router Class Initialized
DEBUG - 2011-10-03 16:32:52 --> Output Class Initialized
DEBUG - 2011-10-03 16:32:52 --> Input Class Initialized
DEBUG - 2011-10-03 16:32:52 --> Global POST and COOKIE data sanitized
DEBUG - 2011-10-03 16:32:52 --> Language Class Initialized
DEBUG - 2011-10-03 16:32:52 --> Loader Class Initialized
DEBUG - 2011-10-03 16:32:52 --> Controller Class Initialized
DEBUG - 2011-10-03 16:32:52 --> Model Class Initialized
DEBUG - 2011-10-03 16:32:52 --> Model Class Initialized
DEBUG - 2011-10-03 16:32:52 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-10-03 16:32:52 --> Database Driver Class Initialized
DEBUG - 2011-10-03 16:32:53 --> Final output sent to browser
DEBUG - 2011-10-03 16:32:53 --> Total execution time: 1.1366
DEBUG - 2011-10-03 16:32:55 --> Config Class Initialized
DEBUG - 2011-10-03 16:32:55 --> Hooks Class Initialized
DEBUG - 2011-10-03 16:32:55 --> Utf8 Class Initialized
DEBUG - 2011-10-03 16:32:55 --> UTF-8 Support Enabled
DEBUG - 2011-10-03 16:32:55 --> URI Class Initialized
DEBUG - 2011-10-03 16:32:55 --> Router Class Initialized
ERROR - 2011-10-03 16:32:55 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-10-03 16:33:47 --> Config Class Initialized
DEBUG - 2011-10-03 16:33:47 --> Hooks Class Initialized
DEBUG - 2011-10-03 16:33:47 --> Utf8 Class Initialized
DEBUG - 2011-10-03 16:33:47 --> UTF-8 Support Enabled
DEBUG - 2011-10-03 16:33:47 --> URI Class Initialized
DEBUG - 2011-10-03 16:33:47 --> Router Class Initialized
ERROR - 2011-10-03 16:33:47 --> 404 Page Not Found --> robots.txt
DEBUG - 2011-10-03 16:34:32 --> Config Class Initialized
DEBUG - 2011-10-03 16:34:32 --> Hooks Class Initialized
DEBUG - 2011-10-03 16:34:32 --> Utf8 Class Initialized
DEBUG - 2011-10-03 16:34:32 --> UTF-8 Support Enabled
DEBUG - 2011-10-03 16:34:32 --> URI Class Initialized
DEBUG - 2011-10-03 16:34:32 --> Router Class Initialized
DEBUG - 2011-10-03 16:34:32 --> No URI present. Default controller set.
DEBUG - 2011-10-03 16:34:32 --> Output Class Initialized
DEBUG - 2011-10-03 16:34:32 --> Input Class Initialized
DEBUG - 2011-10-03 16:34:32 --> Global POST and COOKIE data sanitized
DEBUG - 2011-10-03 16:34:32 --> Language Class Initialized
DEBUG - 2011-10-03 16:34:32 --> Loader Class Initialized
DEBUG - 2011-10-03 16:34:32 --> Controller Class Initialized
DEBUG - 2011-10-03 16:34:32 --> File loaded: application/views/splash/main.php
DEBUG - 2011-10-03 16:34:32 --> Helper loaded: url_helper
DEBUG - 2011-10-03 16:34:32 --> File loaded: application/views/common/header.php
DEBUG - 2011-10-03 16:34:32 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-10-03 16:34:32 --> File loaded: application/views/common/footer.php
DEBUG - 2011-10-03 16:34:32 --> File loaded: application/views/layout/main.php
DEBUG - 2011-10-03 16:34:32 --> Final output sent to browser
DEBUG - 2011-10-03 16:34:32 --> Total execution time: 0.0784
DEBUG - 2011-10-03 17:11:31 --> Config Class Initialized
DEBUG - 2011-10-03 17:11:31 --> Hooks Class Initialized
DEBUG - 2011-10-03 17:11:31 --> Utf8 Class Initialized
DEBUG - 2011-10-03 17:11:31 --> UTF-8 Support Enabled
DEBUG - 2011-10-03 17:11:31 --> URI Class Initialized
DEBUG - 2011-10-03 17:11:31 --> Router Class Initialized
DEBUG - 2011-10-03 17:11:31 --> Output Class Initialized
DEBUG - 2011-10-03 17:11:31 --> Input Class Initialized
DEBUG - 2011-10-03 17:11:31 --> Global POST and COOKIE data sanitized
DEBUG - 2011-10-03 17:11:31 --> Language Class Initialized
DEBUG - 2011-10-03 17:11:31 --> Loader Class Initialized
DEBUG - 2011-10-03 17:11:31 --> Controller Class Initialized
ERROR - 2011-10-03 17:11:31 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-10-03 17:11:31 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-10-03 17:11:31 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-10-03 17:11:31 --> Model Class Initialized
DEBUG - 2011-10-03 17:11:31 --> Model Class Initialized
DEBUG - 2011-10-03 17:11:31 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-10-03 17:11:31 --> Database Driver Class Initialized
DEBUG - 2011-10-03 17:11:31 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-10-03 17:11:31 --> Helper loaded: url_helper
DEBUG - 2011-10-03 17:11:31 --> File loaded: application/views/common/header.php
DEBUG - 2011-10-03 17:11:31 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-10-03 17:11:31 --> File loaded: application/views/common/footer.php
DEBUG - 2011-10-03 17:11:31 --> File loaded: application/views/layout/main.php
DEBUG - 2011-10-03 17:11:31 --> Final output sent to browser
DEBUG - 2011-10-03 17:11:31 --> Total execution time: 0.5912
DEBUG - 2011-10-03 17:11:33 --> Config Class Initialized
DEBUG - 2011-10-03 17:11:33 --> Hooks Class Initialized
DEBUG - 2011-10-03 17:11:33 --> Utf8 Class Initialized
DEBUG - 2011-10-03 17:11:33 --> UTF-8 Support Enabled
DEBUG - 2011-10-03 17:11:33 --> URI Class Initialized
DEBUG - 2011-10-03 17:11:33 --> Router Class Initialized
DEBUG - 2011-10-03 17:11:33 --> Output Class Initialized
DEBUG - 2011-10-03 17:11:33 --> Input Class Initialized
DEBUG - 2011-10-03 17:11:33 --> Global POST and COOKIE data sanitized
DEBUG - 2011-10-03 17:11:33 --> Language Class Initialized
DEBUG - 2011-10-03 17:11:33 --> Loader Class Initialized
DEBUG - 2011-10-03 17:11:33 --> Controller Class Initialized
DEBUG - 2011-10-03 17:11:33 --> Model Class Initialized
DEBUG - 2011-10-03 17:11:33 --> Model Class Initialized
DEBUG - 2011-10-03 17:11:33 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-10-03 17:11:33 --> Database Driver Class Initialized
DEBUG - 2011-10-03 17:11:34 --> Final output sent to browser
DEBUG - 2011-10-03 17:11:34 --> Total execution time: 0.9341
DEBUG - 2011-10-03 17:11:36 --> Config Class Initialized
DEBUG - 2011-10-03 17:11:36 --> Hooks Class Initialized
DEBUG - 2011-10-03 17:11:36 --> Utf8 Class Initialized
DEBUG - 2011-10-03 17:11:36 --> UTF-8 Support Enabled
DEBUG - 2011-10-03 17:11:36 --> URI Class Initialized
DEBUG - 2011-10-03 17:11:36 --> Router Class Initialized
ERROR - 2011-10-03 17:11:36 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-10-03 17:11:41 --> Config Class Initialized
DEBUG - 2011-10-03 17:11:41 --> Hooks Class Initialized
DEBUG - 2011-10-03 17:11:41 --> Utf8 Class Initialized
DEBUG - 2011-10-03 17:11:41 --> UTF-8 Support Enabled
DEBUG - 2011-10-03 17:11:41 --> URI Class Initialized
DEBUG - 2011-10-03 17:11:41 --> Router Class Initialized
DEBUG - 2011-10-03 17:11:41 --> Output Class Initialized
DEBUG - 2011-10-03 17:11:41 --> Input Class Initialized
DEBUG - 2011-10-03 17:11:41 --> Global POST and COOKIE data sanitized
DEBUG - 2011-10-03 17:11:41 --> Language Class Initialized
DEBUG - 2011-10-03 17:11:41 --> Loader Class Initialized
DEBUG - 2011-10-03 17:11:41 --> Controller Class Initialized
ERROR - 2011-10-03 17:11:41 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-10-03 17:11:41 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-10-03 17:11:41 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-10-03 17:11:41 --> Model Class Initialized
DEBUG - 2011-10-03 17:11:41 --> Model Class Initialized
DEBUG - 2011-10-03 17:11:41 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-10-03 17:11:41 --> Database Driver Class Initialized
DEBUG - 2011-10-03 17:11:41 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-10-03 17:11:41 --> Helper loaded: url_helper
DEBUG - 2011-10-03 17:11:41 --> File loaded: application/views/common/header.php
DEBUG - 2011-10-03 17:11:41 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-10-03 17:11:41 --> File loaded: application/views/common/footer.php
DEBUG - 2011-10-03 17:11:41 --> File loaded: application/views/layout/main.php
DEBUG - 2011-10-03 17:11:41 --> Final output sent to browser
DEBUG - 2011-10-03 17:11:41 --> Total execution time: 0.0341
DEBUG - 2011-10-03 17:11:42 --> Config Class Initialized
DEBUG - 2011-10-03 17:11:42 --> Hooks Class Initialized
DEBUG - 2011-10-03 17:11:42 --> Utf8 Class Initialized
DEBUG - 2011-10-03 17:11:42 --> UTF-8 Support Enabled
DEBUG - 2011-10-03 17:11:42 --> URI Class Initialized
DEBUG - 2011-10-03 17:11:42 --> Router Class Initialized
DEBUG - 2011-10-03 17:11:42 --> Output Class Initialized
DEBUG - 2011-10-03 17:11:42 --> Input Class Initialized
DEBUG - 2011-10-03 17:11:42 --> Global POST and COOKIE data sanitized
DEBUG - 2011-10-03 17:11:42 --> Language Class Initialized
DEBUG - 2011-10-03 17:11:42 --> Loader Class Initialized
DEBUG - 2011-10-03 17:11:42 --> Controller Class Initialized
DEBUG - 2011-10-03 17:11:42 --> Model Class Initialized
DEBUG - 2011-10-03 17:11:42 --> Model Class Initialized
DEBUG - 2011-10-03 17:11:42 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-10-03 17:11:42 --> Database Driver Class Initialized
DEBUG - 2011-10-03 17:11:43 --> Final output sent to browser
DEBUG - 2011-10-03 17:11:43 --> Total execution time: 0.8227
DEBUG - 2011-10-03 17:11:45 --> Config Class Initialized
DEBUG - 2011-10-03 17:11:45 --> Hooks Class Initialized
DEBUG - 2011-10-03 17:11:45 --> Utf8 Class Initialized
DEBUG - 2011-10-03 17:11:45 --> UTF-8 Support Enabled
DEBUG - 2011-10-03 17:11:45 --> URI Class Initialized
DEBUG - 2011-10-03 17:11:45 --> Router Class Initialized
ERROR - 2011-10-03 17:11:45 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-10-03 17:11:52 --> Config Class Initialized
DEBUG - 2011-10-03 17:11:52 --> Hooks Class Initialized
DEBUG - 2011-10-03 17:11:52 --> Utf8 Class Initialized
DEBUG - 2011-10-03 17:11:52 --> UTF-8 Support Enabled
DEBUG - 2011-10-03 17:11:52 --> URI Class Initialized
DEBUG - 2011-10-03 17:11:52 --> Router Class Initialized
DEBUG - 2011-10-03 17:11:52 --> Output Class Initialized
DEBUG - 2011-10-03 17:11:52 --> Input Class Initialized
DEBUG - 2011-10-03 17:11:52 --> Global POST and COOKIE data sanitized
DEBUG - 2011-10-03 17:11:52 --> Language Class Initialized
DEBUG - 2011-10-03 17:11:52 --> Loader Class Initialized
DEBUG - 2011-10-03 17:11:52 --> Controller Class Initialized
ERROR - 2011-10-03 17:11:52 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-10-03 17:11:52 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-10-03 17:11:52 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-10-03 17:11:52 --> Model Class Initialized
DEBUG - 2011-10-03 17:11:52 --> Model Class Initialized
DEBUG - 2011-10-03 17:11:52 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-10-03 17:11:52 --> Database Driver Class Initialized
DEBUG - 2011-10-03 17:11:52 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-10-03 17:11:52 --> Helper loaded: url_helper
DEBUG - 2011-10-03 17:11:52 --> File loaded: application/views/common/header.php
DEBUG - 2011-10-03 17:11:52 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-10-03 17:11:52 --> File loaded: application/views/common/footer.php
DEBUG - 2011-10-03 17:11:52 --> File loaded: application/views/layout/main.php
DEBUG - 2011-10-03 17:11:52 --> Final output sent to browser
DEBUG - 2011-10-03 17:11:52 --> Total execution time: 0.0304
DEBUG - 2011-10-03 17:11:52 --> Config Class Initialized
DEBUG - 2011-10-03 17:11:52 --> Hooks Class Initialized
DEBUG - 2011-10-03 17:11:52 --> Utf8 Class Initialized
DEBUG - 2011-10-03 17:11:52 --> UTF-8 Support Enabled
DEBUG - 2011-10-03 17:11:52 --> URI Class Initialized
DEBUG - 2011-10-03 17:11:52 --> Router Class Initialized
DEBUG - 2011-10-03 17:11:52 --> Output Class Initialized
DEBUG - 2011-10-03 17:11:52 --> Input Class Initialized
DEBUG - 2011-10-03 17:11:52 --> Global POST and COOKIE data sanitized
DEBUG - 2011-10-03 17:11:52 --> Language Class Initialized
DEBUG - 2011-10-03 17:11:52 --> Loader Class Initialized
DEBUG - 2011-10-03 17:11:52 --> Controller Class Initialized
ERROR - 2011-10-03 17:11:52 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-10-03 17:11:52 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-10-03 17:11:52 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-10-03 17:11:52 --> Model Class Initialized
DEBUG - 2011-10-03 17:11:52 --> Model Class Initialized
DEBUG - 2011-10-03 17:11:52 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-10-03 17:11:52 --> Database Driver Class Initialized
DEBUG - 2011-10-03 17:11:52 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-10-03 17:11:52 --> Helper loaded: url_helper
DEBUG - 2011-10-03 17:11:52 --> File loaded: application/views/common/header.php
DEBUG - 2011-10-03 17:11:52 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-10-03 17:11:52 --> File loaded: application/views/common/footer.php
DEBUG - 2011-10-03 17:11:52 --> File loaded: application/views/layout/main.php
DEBUG - 2011-10-03 17:11:52 --> Final output sent to browser
DEBUG - 2011-10-03 17:11:52 --> Total execution time: 0.0336
DEBUG - 2011-10-03 17:11:53 --> Config Class Initialized
DEBUG - 2011-10-03 17:11:53 --> Hooks Class Initialized
DEBUG - 2011-10-03 17:11:53 --> Utf8 Class Initialized
DEBUG - 2011-10-03 17:11:53 --> UTF-8 Support Enabled
DEBUG - 2011-10-03 17:11:53 --> URI Class Initialized
DEBUG - 2011-10-03 17:11:53 --> Router Class Initialized
DEBUG - 2011-10-03 17:11:53 --> Output Class Initialized
DEBUG - 2011-10-03 17:11:53 --> Input Class Initialized
DEBUG - 2011-10-03 17:11:53 --> Global POST and COOKIE data sanitized
DEBUG - 2011-10-03 17:11:53 --> Language Class Initialized
DEBUG - 2011-10-03 17:11:53 --> Loader Class Initialized
DEBUG - 2011-10-03 17:11:53 --> Controller Class Initialized
DEBUG - 2011-10-03 17:11:53 --> Model Class Initialized
DEBUG - 2011-10-03 17:11:53 --> Model Class Initialized
DEBUG - 2011-10-03 17:11:53 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-10-03 17:11:53 --> Database Driver Class Initialized
DEBUG - 2011-10-03 17:11:54 --> Final output sent to browser
DEBUG - 2011-10-03 17:11:54 --> Total execution time: 1.0655
DEBUG - 2011-10-03 17:11:56 --> Config Class Initialized
DEBUG - 2011-10-03 17:11:56 --> Hooks Class Initialized
DEBUG - 2011-10-03 17:11:56 --> Utf8 Class Initialized
DEBUG - 2011-10-03 17:11:56 --> UTF-8 Support Enabled
DEBUG - 2011-10-03 17:11:56 --> URI Class Initialized
DEBUG - 2011-10-03 17:11:56 --> Router Class Initialized
ERROR - 2011-10-03 17:11:56 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-10-03 17:12:02 --> Config Class Initialized
DEBUG - 2011-10-03 17:12:02 --> Hooks Class Initialized
DEBUG - 2011-10-03 17:12:02 --> Utf8 Class Initialized
DEBUG - 2011-10-03 17:12:02 --> UTF-8 Support Enabled
DEBUG - 2011-10-03 17:12:02 --> URI Class Initialized
DEBUG - 2011-10-03 17:12:02 --> Router Class Initialized
DEBUG - 2011-10-03 17:12:02 --> Output Class Initialized
DEBUG - 2011-10-03 17:12:02 --> Input Class Initialized
DEBUG - 2011-10-03 17:12:02 --> Global POST and COOKIE data sanitized
DEBUG - 2011-10-03 17:12:02 --> Language Class Initialized
DEBUG - 2011-10-03 17:12:02 --> Loader Class Initialized
DEBUG - 2011-10-03 17:12:02 --> Controller Class Initialized
ERROR - 2011-10-03 17:12:02 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-10-03 17:12:02 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-10-03 17:12:02 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-10-03 17:12:02 --> Model Class Initialized
DEBUG - 2011-10-03 17:12:02 --> Model Class Initialized
DEBUG - 2011-10-03 17:12:02 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-10-03 17:12:02 --> Database Driver Class Initialized
DEBUG - 2011-10-03 17:12:02 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-10-03 17:12:02 --> Helper loaded: url_helper
DEBUG - 2011-10-03 17:12:02 --> File loaded: application/views/common/header.php
DEBUG - 2011-10-03 17:12:02 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-10-03 17:12:02 --> File loaded: application/views/common/footer.php
DEBUG - 2011-10-03 17:12:02 --> File loaded: application/views/layout/main.php
DEBUG - 2011-10-03 17:12:02 --> Final output sent to browser
DEBUG - 2011-10-03 17:12:02 --> Total execution time: 0.0366
DEBUG - 2011-10-03 17:12:02 --> Config Class Initialized
DEBUG - 2011-10-03 17:12:02 --> Hooks Class Initialized
DEBUG - 2011-10-03 17:12:02 --> Utf8 Class Initialized
DEBUG - 2011-10-03 17:12:02 --> UTF-8 Support Enabled
DEBUG - 2011-10-03 17:12:02 --> URI Class Initialized
DEBUG - 2011-10-03 17:12:02 --> Router Class Initialized
DEBUG - 2011-10-03 17:12:02 --> Output Class Initialized
DEBUG - 2011-10-03 17:12:02 --> Input Class Initialized
DEBUG - 2011-10-03 17:12:02 --> Global POST and COOKIE data sanitized
DEBUG - 2011-10-03 17:12:02 --> Language Class Initialized
DEBUG - 2011-10-03 17:12:02 --> Loader Class Initialized
DEBUG - 2011-10-03 17:12:02 --> Controller Class Initialized
DEBUG - 2011-10-03 17:12:02 --> Model Class Initialized
DEBUG - 2011-10-03 17:12:02 --> Model Class Initialized
DEBUG - 2011-10-03 17:12:02 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-10-03 17:12:02 --> Database Driver Class Initialized
DEBUG - 2011-10-03 17:12:03 --> Final output sent to browser
DEBUG - 2011-10-03 17:12:03 --> Total execution time: 0.7117
DEBUG - 2011-10-03 17:12:03 --> Config Class Initialized
DEBUG - 2011-10-03 17:12:03 --> Hooks Class Initialized
DEBUG - 2011-10-03 17:12:03 --> Utf8 Class Initialized
DEBUG - 2011-10-03 17:12:03 --> UTF-8 Support Enabled
DEBUG - 2011-10-03 17:12:03 --> URI Class Initialized
DEBUG - 2011-10-03 17:12:03 --> Router Class Initialized
DEBUG - 2011-10-03 17:12:03 --> Output Class Initialized
DEBUG - 2011-10-03 17:12:03 --> Input Class Initialized
DEBUG - 2011-10-03 17:12:03 --> Global POST and COOKIE data sanitized
DEBUG - 2011-10-03 17:12:03 --> Language Class Initialized
DEBUG - 2011-10-03 17:12:03 --> Loader Class Initialized
DEBUG - 2011-10-03 17:12:03 --> Controller Class Initialized
ERROR - 2011-10-03 17:12:03 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-10-03 17:12:03 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-10-03 17:12:03 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-10-03 17:12:03 --> Model Class Initialized
DEBUG - 2011-10-03 17:12:03 --> Model Class Initialized
DEBUG - 2011-10-03 17:12:03 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-10-03 17:12:03 --> Database Driver Class Initialized
DEBUG - 2011-10-03 17:12:04 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-10-03 17:12:04 --> Helper loaded: url_helper
DEBUG - 2011-10-03 17:12:04 --> File loaded: application/views/common/header.php
DEBUG - 2011-10-03 17:12:04 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-10-03 17:12:04 --> File loaded: application/views/common/footer.php
DEBUG - 2011-10-03 17:12:04 --> File loaded: application/views/layout/main.php
DEBUG - 2011-10-03 17:12:04 --> Final output sent to browser
DEBUG - 2011-10-03 17:12:04 --> Total execution time: 0.0406
DEBUG - 2011-10-03 17:12:05 --> Config Class Initialized
DEBUG - 2011-10-03 17:12:05 --> Hooks Class Initialized
DEBUG - 2011-10-03 17:12:05 --> Utf8 Class Initialized
DEBUG - 2011-10-03 17:12:05 --> UTF-8 Support Enabled
DEBUG - 2011-10-03 17:12:05 --> URI Class Initialized
DEBUG - 2011-10-03 17:12:05 --> Router Class Initialized
ERROR - 2011-10-03 17:12:05 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-10-03 17:12:14 --> Config Class Initialized
DEBUG - 2011-10-03 17:12:14 --> Hooks Class Initialized
DEBUG - 2011-10-03 17:12:14 --> Utf8 Class Initialized
DEBUG - 2011-10-03 17:12:14 --> UTF-8 Support Enabled
DEBUG - 2011-10-03 17:12:14 --> URI Class Initialized
DEBUG - 2011-10-03 17:12:14 --> Router Class Initialized
DEBUG - 2011-10-03 17:12:14 --> Output Class Initialized
DEBUG - 2011-10-03 17:12:14 --> Input Class Initialized
DEBUG - 2011-10-03 17:12:14 --> Global POST and COOKIE data sanitized
DEBUG - 2011-10-03 17:12:14 --> Language Class Initialized
DEBUG - 2011-10-03 17:12:14 --> Loader Class Initialized
DEBUG - 2011-10-03 17:12:14 --> Controller Class Initialized
ERROR - 2011-10-03 17:12:14 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-10-03 17:12:14 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-10-03 17:12:14 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-10-03 17:12:14 --> Model Class Initialized
DEBUG - 2011-10-03 17:12:14 --> Model Class Initialized
DEBUG - 2011-10-03 17:12:14 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-10-03 17:12:14 --> Database Driver Class Initialized
DEBUG - 2011-10-03 17:12:14 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-10-03 17:12:14 --> Helper loaded: url_helper
DEBUG - 2011-10-03 17:12:14 --> File loaded: application/views/common/header.php
DEBUG - 2011-10-03 17:12:14 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-10-03 17:12:14 --> File loaded: application/views/common/footer.php
DEBUG - 2011-10-03 17:12:14 --> File loaded: application/views/layout/main.php
DEBUG - 2011-10-03 17:12:14 --> Final output sent to browser
DEBUG - 2011-10-03 17:12:14 --> Total execution time: 0.0342
DEBUG - 2011-10-03 17:12:15 --> Config Class Initialized
DEBUG - 2011-10-03 17:12:15 --> Hooks Class Initialized
DEBUG - 2011-10-03 17:12:15 --> Utf8 Class Initialized
DEBUG - 2011-10-03 17:12:15 --> UTF-8 Support Enabled
DEBUG - 2011-10-03 17:12:15 --> URI Class Initialized
DEBUG - 2011-10-03 17:12:15 --> Router Class Initialized
DEBUG - 2011-10-03 17:12:15 --> Output Class Initialized
DEBUG - 2011-10-03 17:12:15 --> Input Class Initialized
DEBUG - 2011-10-03 17:12:15 --> Global POST and COOKIE data sanitized
DEBUG - 2011-10-03 17:12:15 --> Language Class Initialized
DEBUG - 2011-10-03 17:12:15 --> Loader Class Initialized
DEBUG - 2011-10-03 17:12:15 --> Controller Class Initialized
DEBUG - 2011-10-03 17:12:15 --> Model Class Initialized
DEBUG - 2011-10-03 17:12:15 --> Model Class Initialized
DEBUG - 2011-10-03 17:12:15 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-10-03 17:12:15 --> Database Driver Class Initialized
DEBUG - 2011-10-03 17:12:16 --> Final output sent to browser
DEBUG - 2011-10-03 17:12:16 --> Total execution time: 0.7406
DEBUG - 2011-10-03 17:12:18 --> Config Class Initialized
DEBUG - 2011-10-03 17:12:18 --> Hooks Class Initialized
DEBUG - 2011-10-03 17:12:18 --> Utf8 Class Initialized
DEBUG - 2011-10-03 17:12:18 --> UTF-8 Support Enabled
DEBUG - 2011-10-03 17:12:18 --> URI Class Initialized
DEBUG - 2011-10-03 17:12:18 --> Router Class Initialized
ERROR - 2011-10-03 17:12:18 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-10-03 17:12:25 --> Config Class Initialized
DEBUG - 2011-10-03 17:12:25 --> Hooks Class Initialized
DEBUG - 2011-10-03 17:12:25 --> Utf8 Class Initialized
DEBUG - 2011-10-03 17:12:25 --> UTF-8 Support Enabled
DEBUG - 2011-10-03 17:12:25 --> URI Class Initialized
DEBUG - 2011-10-03 17:12:25 --> Router Class Initialized
DEBUG - 2011-10-03 17:12:25 --> Output Class Initialized
DEBUG - 2011-10-03 17:12:25 --> Input Class Initialized
DEBUG - 2011-10-03 17:12:25 --> Global POST and COOKIE data sanitized
DEBUG - 2011-10-03 17:12:25 --> Language Class Initialized
DEBUG - 2011-10-03 17:12:25 --> Loader Class Initialized
DEBUG - 2011-10-03 17:12:25 --> Controller Class Initialized
ERROR - 2011-10-03 17:12:25 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-10-03 17:12:25 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-10-03 17:12:25 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-10-03 17:12:25 --> Model Class Initialized
DEBUG - 2011-10-03 17:12:25 --> Model Class Initialized
DEBUG - 2011-10-03 17:12:25 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-10-03 17:12:25 --> Database Driver Class Initialized
DEBUG - 2011-10-03 17:12:25 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-10-03 17:12:25 --> Helper loaded: url_helper
DEBUG - 2011-10-03 17:12:25 --> File loaded: application/views/common/header.php
DEBUG - 2011-10-03 17:12:25 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-10-03 17:12:25 --> File loaded: application/views/common/footer.php
DEBUG - 2011-10-03 17:12:25 --> File loaded: application/views/layout/main.php
DEBUG - 2011-10-03 17:12:25 --> Final output sent to browser
DEBUG - 2011-10-03 17:12:25 --> Total execution time: 0.1549
DEBUG - 2011-10-03 17:12:26 --> Config Class Initialized
DEBUG - 2011-10-03 17:12:26 --> Hooks Class Initialized
DEBUG - 2011-10-03 17:12:26 --> Utf8 Class Initialized
DEBUG - 2011-10-03 17:12:26 --> UTF-8 Support Enabled
DEBUG - 2011-10-03 17:12:26 --> URI Class Initialized
DEBUG - 2011-10-03 17:12:26 --> Router Class Initialized
DEBUG - 2011-10-03 17:12:26 --> Output Class Initialized
DEBUG - 2011-10-03 17:12:26 --> Input Class Initialized
DEBUG - 2011-10-03 17:12:26 --> Global POST and COOKIE data sanitized
DEBUG - 2011-10-03 17:12:26 --> Language Class Initialized
DEBUG - 2011-10-03 17:12:26 --> Loader Class Initialized
DEBUG - 2011-10-03 17:12:26 --> Controller Class Initialized
DEBUG - 2011-10-03 17:12:26 --> Model Class Initialized
DEBUG - 2011-10-03 17:12:26 --> Model Class Initialized
DEBUG - 2011-10-03 17:12:26 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-10-03 17:12:26 --> Database Driver Class Initialized
DEBUG - 2011-10-03 17:12:26 --> Final output sent to browser
DEBUG - 2011-10-03 17:12:26 --> Total execution time: 0.6247
DEBUG - 2011-10-03 17:12:29 --> Config Class Initialized
DEBUG - 2011-10-03 17:12:29 --> Hooks Class Initialized
DEBUG - 2011-10-03 17:12:29 --> Utf8 Class Initialized
DEBUG - 2011-10-03 17:12:29 --> UTF-8 Support Enabled
DEBUG - 2011-10-03 17:12:29 --> URI Class Initialized
DEBUG - 2011-10-03 17:12:29 --> Router Class Initialized
ERROR - 2011-10-03 17:12:29 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-10-03 17:12:38 --> Config Class Initialized
DEBUG - 2011-10-03 17:12:38 --> Hooks Class Initialized
DEBUG - 2011-10-03 17:12:38 --> Utf8 Class Initialized
DEBUG - 2011-10-03 17:12:38 --> UTF-8 Support Enabled
DEBUG - 2011-10-03 17:12:38 --> URI Class Initialized
DEBUG - 2011-10-03 17:12:38 --> Router Class Initialized
DEBUG - 2011-10-03 17:12:38 --> Output Class Initialized
DEBUG - 2011-10-03 17:12:38 --> Input Class Initialized
DEBUG - 2011-10-03 17:12:38 --> Global POST and COOKIE data sanitized
DEBUG - 2011-10-03 17:12:38 --> Language Class Initialized
DEBUG - 2011-10-03 17:12:38 --> Loader Class Initialized
DEBUG - 2011-10-03 17:12:38 --> Controller Class Initialized
ERROR - 2011-10-03 17:12:38 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-10-03 17:12:38 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-10-03 17:12:38 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-10-03 17:12:38 --> Model Class Initialized
DEBUG - 2011-10-03 17:12:38 --> Model Class Initialized
DEBUG - 2011-10-03 17:12:38 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-10-03 17:12:38 --> Database Driver Class Initialized
DEBUG - 2011-10-03 17:12:38 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-10-03 17:12:38 --> Helper loaded: url_helper
DEBUG - 2011-10-03 17:12:38 --> File loaded: application/views/common/header.php
DEBUG - 2011-10-03 17:12:38 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-10-03 17:12:38 --> File loaded: application/views/common/footer.php
DEBUG - 2011-10-03 17:12:38 --> File loaded: application/views/layout/main.php
DEBUG - 2011-10-03 17:12:38 --> Final output sent to browser
DEBUG - 2011-10-03 17:12:38 --> Total execution time: 0.0568
DEBUG - 2011-10-03 17:12:39 --> Config Class Initialized
DEBUG - 2011-10-03 17:12:39 --> Hooks Class Initialized
DEBUG - 2011-10-03 17:12:39 --> Utf8 Class Initialized
DEBUG - 2011-10-03 17:12:39 --> UTF-8 Support Enabled
DEBUG - 2011-10-03 17:12:39 --> URI Class Initialized
DEBUG - 2011-10-03 17:12:39 --> Router Class Initialized
DEBUG - 2011-10-03 17:12:39 --> Output Class Initialized
DEBUG - 2011-10-03 17:12:39 --> Input Class Initialized
DEBUG - 2011-10-03 17:12:39 --> Global POST and COOKIE data sanitized
DEBUG - 2011-10-03 17:12:39 --> Language Class Initialized
DEBUG - 2011-10-03 17:12:39 --> Loader Class Initialized
DEBUG - 2011-10-03 17:12:39 --> Controller Class Initialized
DEBUG - 2011-10-03 17:12:39 --> Model Class Initialized
DEBUG - 2011-10-03 17:12:39 --> Model Class Initialized
DEBUG - 2011-10-03 17:12:39 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-10-03 17:12:39 --> Database Driver Class Initialized
DEBUG - 2011-10-03 17:12:40 --> Final output sent to browser
DEBUG - 2011-10-03 17:12:40 --> Total execution time: 0.7781
DEBUG - 2011-10-03 17:12:41 --> Config Class Initialized
DEBUG - 2011-10-03 17:12:41 --> Hooks Class Initialized
DEBUG - 2011-10-03 17:12:41 --> Utf8 Class Initialized
DEBUG - 2011-10-03 17:12:41 --> UTF-8 Support Enabled
DEBUG - 2011-10-03 17:12:41 --> URI Class Initialized
DEBUG - 2011-10-03 17:12:41 --> Router Class Initialized
ERROR - 2011-10-03 17:12:41 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-10-03 17:12:49 --> Config Class Initialized
DEBUG - 2011-10-03 17:12:49 --> Hooks Class Initialized
DEBUG - 2011-10-03 17:12:49 --> Utf8 Class Initialized
DEBUG - 2011-10-03 17:12:49 --> UTF-8 Support Enabled
DEBUG - 2011-10-03 17:12:49 --> URI Class Initialized
DEBUG - 2011-10-03 17:12:49 --> Router Class Initialized
DEBUG - 2011-10-03 17:12:49 --> Output Class Initialized
DEBUG - 2011-10-03 17:12:49 --> Input Class Initialized
DEBUG - 2011-10-03 17:12:49 --> Global POST and COOKIE data sanitized
DEBUG - 2011-10-03 17:12:49 --> Language Class Initialized
DEBUG - 2011-10-03 17:12:49 --> Loader Class Initialized
DEBUG - 2011-10-03 17:12:49 --> Controller Class Initialized
ERROR - 2011-10-03 17:12:49 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-10-03 17:12:49 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-10-03 17:12:49 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-10-03 17:12:49 --> Model Class Initialized
DEBUG - 2011-10-03 17:12:49 --> Model Class Initialized
DEBUG - 2011-10-03 17:12:49 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-10-03 17:12:49 --> Database Driver Class Initialized
DEBUG - 2011-10-03 17:12:49 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-10-03 17:12:49 --> Helper loaded: url_helper
DEBUG - 2011-10-03 17:12:49 --> File loaded: application/views/common/header.php
DEBUG - 2011-10-03 17:12:49 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-10-03 17:12:49 --> File loaded: application/views/common/footer.php
DEBUG - 2011-10-03 17:12:49 --> File loaded: application/views/layout/main.php
DEBUG - 2011-10-03 17:12:49 --> Final output sent to browser
DEBUG - 2011-10-03 17:12:49 --> Total execution time: 0.0927
DEBUG - 2011-10-03 17:12:50 --> Config Class Initialized
DEBUG - 2011-10-03 17:12:50 --> Hooks Class Initialized
DEBUG - 2011-10-03 17:12:50 --> Utf8 Class Initialized
DEBUG - 2011-10-03 17:12:50 --> UTF-8 Support Enabled
DEBUG - 2011-10-03 17:12:50 --> URI Class Initialized
DEBUG - 2011-10-03 17:12:50 --> Router Class Initialized
DEBUG - 2011-10-03 17:12:50 --> Output Class Initialized
DEBUG - 2011-10-03 17:12:50 --> Input Class Initialized
DEBUG - 2011-10-03 17:12:50 --> Global POST and COOKIE data sanitized
DEBUG - 2011-10-03 17:12:50 --> Language Class Initialized
DEBUG - 2011-10-03 17:12:50 --> Loader Class Initialized
DEBUG - 2011-10-03 17:12:50 --> Controller Class Initialized
DEBUG - 2011-10-03 17:12:50 --> Model Class Initialized
DEBUG - 2011-10-03 17:12:50 --> Model Class Initialized
DEBUG - 2011-10-03 17:12:50 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-10-03 17:12:50 --> Database Driver Class Initialized
DEBUG - 2011-10-03 17:12:51 --> Final output sent to browser
DEBUG - 2011-10-03 17:12:51 --> Total execution time: 0.6353
DEBUG - 2011-10-03 17:12:53 --> Config Class Initialized
DEBUG - 2011-10-03 17:12:53 --> Hooks Class Initialized
DEBUG - 2011-10-03 17:12:53 --> Utf8 Class Initialized
DEBUG - 2011-10-03 17:12:53 --> UTF-8 Support Enabled
DEBUG - 2011-10-03 17:12:53 --> URI Class Initialized
DEBUG - 2011-10-03 17:12:53 --> Router Class Initialized
ERROR - 2011-10-03 17:12:53 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-10-03 17:13:02 --> Config Class Initialized
DEBUG - 2011-10-03 17:13:02 --> Hooks Class Initialized
DEBUG - 2011-10-03 17:13:02 --> Utf8 Class Initialized
DEBUG - 2011-10-03 17:13:02 --> UTF-8 Support Enabled
DEBUG - 2011-10-03 17:13:02 --> URI Class Initialized
DEBUG - 2011-10-03 17:13:02 --> Router Class Initialized
DEBUG - 2011-10-03 17:13:02 --> Output Class Initialized
DEBUG - 2011-10-03 17:13:02 --> Input Class Initialized
DEBUG - 2011-10-03 17:13:02 --> Global POST and COOKIE data sanitized
DEBUG - 2011-10-03 17:13:02 --> Language Class Initialized
DEBUG - 2011-10-03 17:13:02 --> Loader Class Initialized
DEBUG - 2011-10-03 17:13:02 --> Controller Class Initialized
ERROR - 2011-10-03 17:13:02 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-10-03 17:13:02 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-10-03 17:13:02 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-10-03 17:13:02 --> Model Class Initialized
DEBUG - 2011-10-03 17:13:02 --> Model Class Initialized
DEBUG - 2011-10-03 17:13:02 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-10-03 17:13:02 --> Database Driver Class Initialized
DEBUG - 2011-10-03 17:13:02 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-10-03 17:13:02 --> Helper loaded: url_helper
DEBUG - 2011-10-03 17:13:02 --> File loaded: application/views/common/header.php
DEBUG - 2011-10-03 17:13:02 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-10-03 17:13:02 --> File loaded: application/views/common/footer.php
DEBUG - 2011-10-03 17:13:02 --> File loaded: application/views/layout/main.php
DEBUG - 2011-10-03 17:13:02 --> Final output sent to browser
DEBUG - 2011-10-03 17:13:02 --> Total execution time: 0.0457
DEBUG - 2011-10-03 17:13:03 --> Config Class Initialized
DEBUG - 2011-10-03 17:13:03 --> Hooks Class Initialized
DEBUG - 2011-10-03 17:13:03 --> Utf8 Class Initialized
DEBUG - 2011-10-03 17:13:03 --> UTF-8 Support Enabled
DEBUG - 2011-10-03 17:13:03 --> URI Class Initialized
DEBUG - 2011-10-03 17:13:03 --> Router Class Initialized
DEBUG - 2011-10-03 17:13:03 --> Output Class Initialized
DEBUG - 2011-10-03 17:13:03 --> Input Class Initialized
DEBUG - 2011-10-03 17:13:03 --> Global POST and COOKIE data sanitized
DEBUG - 2011-10-03 17:13:03 --> Language Class Initialized
DEBUG - 2011-10-03 17:13:03 --> Loader Class Initialized
DEBUG - 2011-10-03 17:13:03 --> Controller Class Initialized
DEBUG - 2011-10-03 17:13:03 --> Model Class Initialized
DEBUG - 2011-10-03 17:13:03 --> Model Class Initialized
DEBUG - 2011-10-03 17:13:03 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-10-03 17:13:03 --> Database Driver Class Initialized
DEBUG - 2011-10-03 17:13:04 --> Final output sent to browser
DEBUG - 2011-10-03 17:13:04 --> Total execution time: 0.6260
DEBUG - 2011-10-03 17:13:06 --> Config Class Initialized
DEBUG - 2011-10-03 17:13:06 --> Hooks Class Initialized
DEBUG - 2011-10-03 17:13:06 --> Utf8 Class Initialized
DEBUG - 2011-10-03 17:13:06 --> UTF-8 Support Enabled
DEBUG - 2011-10-03 17:13:06 --> URI Class Initialized
DEBUG - 2011-10-03 17:13:06 --> Router Class Initialized
ERROR - 2011-10-03 17:13:06 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-10-03 17:54:58 --> Config Class Initialized
DEBUG - 2011-10-03 17:54:58 --> Hooks Class Initialized
DEBUG - 2011-10-03 17:54:58 --> Utf8 Class Initialized
DEBUG - 2011-10-03 17:54:58 --> UTF-8 Support Enabled
DEBUG - 2011-10-03 17:54:58 --> URI Class Initialized
DEBUG - 2011-10-03 17:54:58 --> Router Class Initialized
DEBUG - 2011-10-03 17:54:58 --> Output Class Initialized
DEBUG - 2011-10-03 17:54:58 --> Input Class Initialized
DEBUG - 2011-10-03 17:54:58 --> Global POST and COOKIE data sanitized
DEBUG - 2011-10-03 17:54:58 --> Language Class Initialized
DEBUG - 2011-10-03 17:54:58 --> Loader Class Initialized
DEBUG - 2011-10-03 17:54:58 --> Controller Class Initialized
DEBUG - 2011-10-03 17:54:58 --> Model Class Initialized
DEBUG - 2011-10-03 17:54:58 --> Model Class Initialized
DEBUG - 2011-10-03 17:54:58 --> Model Class Initialized
DEBUG - 2011-10-03 17:54:58 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-10-03 17:54:58 --> Database Driver Class Initialized
DEBUG - 2011-10-03 17:54:59 --> File loaded: application/views/table/main.php
DEBUG - 2011-10-03 17:54:59 --> Helper loaded: url_helper
DEBUG - 2011-10-03 17:54:59 --> File loaded: application/views/common/header.php
DEBUG - 2011-10-03 17:54:59 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-10-03 17:54:59 --> File loaded: application/views/common/footer.php
DEBUG - 2011-10-03 17:54:59 --> File loaded: application/views/layout/main.php
DEBUG - 2011-10-03 17:54:59 --> Final output sent to browser
DEBUG - 2011-10-03 17:54:59 --> Total execution time: 1.5103
DEBUG - 2011-10-03 17:55:04 --> Config Class Initialized
DEBUG - 2011-10-03 17:55:04 --> Hooks Class Initialized
DEBUG - 2011-10-03 17:55:04 --> Utf8 Class Initialized
DEBUG - 2011-10-03 17:55:04 --> UTF-8 Support Enabled
DEBUG - 2011-10-03 17:55:04 --> URI Class Initialized
DEBUG - 2011-10-03 17:55:04 --> Router Class Initialized
DEBUG - 2011-10-03 17:55:04 --> Output Class Initialized
DEBUG - 2011-10-03 17:55:04 --> Input Class Initialized
DEBUG - 2011-10-03 17:55:04 --> Global POST and COOKIE data sanitized
DEBUG - 2011-10-03 17:55:04 --> Language Class Initialized
DEBUG - 2011-10-03 17:55:04 --> Loader Class Initialized
DEBUG - 2011-10-03 17:55:04 --> Controller Class Initialized
ERROR - 2011-10-03 17:55:04 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-10-03 17:55:04 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-10-03 17:55:04 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-10-03 17:55:04 --> Model Class Initialized
DEBUG - 2011-10-03 17:55:04 --> Model Class Initialized
DEBUG - 2011-10-03 17:55:04 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-10-03 17:55:04 --> Database Driver Class Initialized
DEBUG - 2011-10-03 17:55:04 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-10-03 17:55:04 --> Helper loaded: url_helper
DEBUG - 2011-10-03 17:55:04 --> File loaded: application/views/common/header.php
DEBUG - 2011-10-03 17:55:04 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-10-03 17:55:04 --> File loaded: application/views/common/footer.php
DEBUG - 2011-10-03 17:55:04 --> File loaded: application/views/layout/main.php
DEBUG - 2011-10-03 17:55:04 --> Final output sent to browser
DEBUG - 2011-10-03 17:55:04 --> Total execution time: 0.0692
DEBUG - 2011-10-03 18:21:53 --> Config Class Initialized
DEBUG - 2011-10-03 18:21:53 --> Hooks Class Initialized
DEBUG - 2011-10-03 18:21:53 --> Utf8 Class Initialized
DEBUG - 2011-10-03 18:21:53 --> UTF-8 Support Enabled
DEBUG - 2011-10-03 18:21:53 --> URI Class Initialized
DEBUG - 2011-10-03 18:21:53 --> Router Class Initialized
DEBUG - 2011-10-03 18:21:53 --> Output Class Initialized
DEBUG - 2011-10-03 18:21:53 --> Input Class Initialized
DEBUG - 2011-10-03 18:21:53 --> Global POST and COOKIE data sanitized
DEBUG - 2011-10-03 18:21:53 --> Language Class Initialized
DEBUG - 2011-10-03 18:21:53 --> Loader Class Initialized
DEBUG - 2011-10-03 18:21:53 --> Controller Class Initialized
DEBUG - 2011-10-03 18:21:53 --> Model Class Initialized
DEBUG - 2011-10-03 18:21:53 --> Model Class Initialized
DEBUG - 2011-10-03 18:21:53 --> Model Class Initialized
DEBUG - 2011-10-03 18:21:53 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-10-03 18:21:53 --> Database Driver Class Initialized
DEBUG - 2011-10-03 18:21:53 --> File loaded: application/views/table/main.php
DEBUG - 2011-10-03 18:21:53 --> Helper loaded: url_helper
DEBUG - 2011-10-03 18:21:53 --> File loaded: application/views/common/header.php
DEBUG - 2011-10-03 18:21:53 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-10-03 18:21:53 --> File loaded: application/views/common/footer.php
DEBUG - 2011-10-03 18:21:53 --> File loaded: application/views/layout/main.php
DEBUG - 2011-10-03 18:21:53 --> Final output sent to browser
DEBUG - 2011-10-03 18:21:53 --> Total execution time: 0.2785
DEBUG - 2011-10-03 18:21:55 --> Config Class Initialized
DEBUG - 2011-10-03 18:21:55 --> Hooks Class Initialized
DEBUG - 2011-10-03 18:21:55 --> Utf8 Class Initialized
DEBUG - 2011-10-03 18:21:55 --> UTF-8 Support Enabled
DEBUG - 2011-10-03 18:21:55 --> URI Class Initialized
DEBUG - 2011-10-03 18:21:55 --> Router Class Initialized
ERROR - 2011-10-03 18:21:55 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-10-03 18:21:55 --> Config Class Initialized
DEBUG - 2011-10-03 18:21:55 --> Hooks Class Initialized
DEBUG - 2011-10-03 18:21:55 --> Utf8 Class Initialized
DEBUG - 2011-10-03 18:21:55 --> UTF-8 Support Enabled
DEBUG - 2011-10-03 18:21:55 --> URI Class Initialized
DEBUG - 2011-10-03 18:21:55 --> Router Class Initialized
ERROR - 2011-10-03 18:21:55 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-10-03 18:22:03 --> Config Class Initialized
DEBUG - 2011-10-03 18:22:03 --> Hooks Class Initialized
DEBUG - 2011-10-03 18:22:03 --> Utf8 Class Initialized
DEBUG - 2011-10-03 18:22:03 --> UTF-8 Support Enabled
DEBUG - 2011-10-03 18:22:03 --> URI Class Initialized
DEBUG - 2011-10-03 18:22:03 --> Router Class Initialized
DEBUG - 2011-10-03 18:22:03 --> Output Class Initialized
DEBUG - 2011-10-03 18:22:03 --> Input Class Initialized
DEBUG - 2011-10-03 18:22:03 --> Global POST and COOKIE data sanitized
DEBUG - 2011-10-03 18:22:03 --> Language Class Initialized
DEBUG - 2011-10-03 18:22:03 --> Loader Class Initialized
DEBUG - 2011-10-03 18:22:03 --> Controller Class Initialized
DEBUG - 2011-10-03 18:22:03 --> Model Class Initialized
DEBUG - 2011-10-03 18:22:03 --> Model Class Initialized
DEBUG - 2011-10-03 18:22:03 --> Model Class Initialized
DEBUG - 2011-10-03 18:22:03 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-10-03 18:22:03 --> Database Driver Class Initialized
DEBUG - 2011-10-03 18:22:05 --> File loaded: application/views/table/main.php
DEBUG - 2011-10-03 18:22:05 --> Helper loaded: url_helper
DEBUG - 2011-10-03 18:22:05 --> File loaded: application/views/common/header.php
DEBUG - 2011-10-03 18:22:05 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-10-03 18:22:05 --> File loaded: application/views/common/footer.php
DEBUG - 2011-10-03 18:22:05 --> File loaded: application/views/layout/main.php
DEBUG - 2011-10-03 18:22:05 --> Final output sent to browser
DEBUG - 2011-10-03 18:22:05 --> Total execution time: 1.3457
DEBUG - 2011-10-03 19:04:40 --> Config Class Initialized
DEBUG - 2011-10-03 19:04:40 --> Hooks Class Initialized
DEBUG - 2011-10-03 19:04:40 --> Utf8 Class Initialized
DEBUG - 2011-10-03 19:04:40 --> UTF-8 Support Enabled
DEBUG - 2011-10-03 19:04:40 --> URI Class Initialized
DEBUG - 2011-10-03 19:04:40 --> Router Class Initialized
DEBUG - 2011-10-03 19:04:40 --> Output Class Initialized
DEBUG - 2011-10-03 19:04:40 --> Input Class Initialized
DEBUG - 2011-10-03 19:04:40 --> Global POST and COOKIE data sanitized
DEBUG - 2011-10-03 19:04:40 --> Language Class Initialized
DEBUG - 2011-10-03 19:04:40 --> Loader Class Initialized
DEBUG - 2011-10-03 19:04:40 --> Controller Class Initialized
ERROR - 2011-10-03 19:04:40 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-10-03 19:04:40 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-10-03 19:04:40 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-10-03 19:04:40 --> Model Class Initialized
DEBUG - 2011-10-03 19:04:40 --> Model Class Initialized
DEBUG - 2011-10-03 19:04:40 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-10-03 19:04:40 --> Database Driver Class Initialized
DEBUG - 2011-10-03 19:04:41 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-10-03 19:04:41 --> Helper loaded: url_helper
DEBUG - 2011-10-03 19:04:41 --> File loaded: application/views/common/header.php
DEBUG - 2011-10-03 19:04:41 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-10-03 19:04:41 --> File loaded: application/views/common/footer.php
DEBUG - 2011-10-03 19:04:41 --> File loaded: application/views/layout/main.php
DEBUG - 2011-10-03 19:04:41 --> Final output sent to browser
DEBUG - 2011-10-03 19:04:41 --> Total execution time: 0.5460
DEBUG - 2011-10-03 19:04:43 --> Config Class Initialized
DEBUG - 2011-10-03 19:04:43 --> Hooks Class Initialized
DEBUG - 2011-10-03 19:04:43 --> Utf8 Class Initialized
DEBUG - 2011-10-03 19:04:43 --> UTF-8 Support Enabled
DEBUG - 2011-10-03 19:04:43 --> URI Class Initialized
DEBUG - 2011-10-03 19:04:43 --> Router Class Initialized
DEBUG - 2011-10-03 19:04:43 --> Output Class Initialized
DEBUG - 2011-10-03 19:04:43 --> Input Class Initialized
DEBUG - 2011-10-03 19:04:43 --> Global POST and COOKIE data sanitized
DEBUG - 2011-10-03 19:04:43 --> Language Class Initialized
DEBUG - 2011-10-03 19:04:43 --> Loader Class Initialized
DEBUG - 2011-10-03 19:04:43 --> Controller Class Initialized
DEBUG - 2011-10-03 19:04:43 --> Model Class Initialized
DEBUG - 2011-10-03 19:04:43 --> Model Class Initialized
DEBUG - 2011-10-03 19:04:43 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-10-03 19:04:43 --> Database Driver Class Initialized
DEBUG - 2011-10-03 19:04:45 --> Final output sent to browser
DEBUG - 2011-10-03 19:04:45 --> Total execution time: 1.6481
DEBUG - 2011-10-03 19:05:07 --> Config Class Initialized
DEBUG - 2011-10-03 19:05:07 --> Hooks Class Initialized
DEBUG - 2011-10-03 19:05:07 --> Utf8 Class Initialized
DEBUG - 2011-10-03 19:05:07 --> UTF-8 Support Enabled
DEBUG - 2011-10-03 19:05:07 --> URI Class Initialized
DEBUG - 2011-10-03 19:05:07 --> Router Class Initialized
ERROR - 2011-10-03 19:05:07 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-10-03 19:05:09 --> Config Class Initialized
DEBUG - 2011-10-03 19:05:09 --> Hooks Class Initialized
DEBUG - 2011-10-03 19:05:09 --> Utf8 Class Initialized
DEBUG - 2011-10-03 19:05:09 --> UTF-8 Support Enabled
DEBUG - 2011-10-03 19:05:09 --> URI Class Initialized
DEBUG - 2011-10-03 19:05:09 --> Router Class Initialized
ERROR - 2011-10-03 19:05:09 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-10-03 19:05:11 --> Config Class Initialized
DEBUG - 2011-10-03 19:05:11 --> Hooks Class Initialized
DEBUG - 2011-10-03 19:05:11 --> Utf8 Class Initialized
DEBUG - 2011-10-03 19:05:11 --> UTF-8 Support Enabled
DEBUG - 2011-10-03 19:05:11 --> URI Class Initialized
DEBUG - 2011-10-03 19:05:11 --> Router Class Initialized
ERROR - 2011-10-03 19:05:11 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-10-03 19:05:17 --> Config Class Initialized
DEBUG - 2011-10-03 19:05:17 --> Hooks Class Initialized
DEBUG - 2011-10-03 19:05:17 --> Utf8 Class Initialized
DEBUG - 2011-10-03 19:05:17 --> UTF-8 Support Enabled
DEBUG - 2011-10-03 19:05:17 --> URI Class Initialized
DEBUG - 2011-10-03 19:05:17 --> Router Class Initialized
DEBUG - 2011-10-03 19:05:17 --> Output Class Initialized
DEBUG - 2011-10-03 19:05:17 --> Input Class Initialized
DEBUG - 2011-10-03 19:05:17 --> Global POST and COOKIE data sanitized
DEBUG - 2011-10-03 19:05:17 --> Language Class Initialized
DEBUG - 2011-10-03 19:05:17 --> Loader Class Initialized
DEBUG - 2011-10-03 19:05:17 --> Controller Class Initialized
ERROR - 2011-10-03 19:05:17 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-10-03 19:05:17 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-10-03 19:05:17 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-10-03 19:05:17 --> Model Class Initialized
DEBUG - 2011-10-03 19:05:17 --> Model Class Initialized
DEBUG - 2011-10-03 19:05:17 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-10-03 19:05:17 --> Database Driver Class Initialized
DEBUG - 2011-10-03 19:05:17 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-10-03 19:05:17 --> Helper loaded: url_helper
DEBUG - 2011-10-03 19:05:17 --> File loaded: application/views/common/header.php
DEBUG - 2011-10-03 19:05:17 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-10-03 19:05:17 --> File loaded: application/views/common/footer.php
DEBUG - 2011-10-03 19:05:17 --> File loaded: application/views/layout/main.php
DEBUG - 2011-10-03 19:05:17 --> Final output sent to browser
DEBUG - 2011-10-03 19:05:17 --> Total execution time: 0.0475
DEBUG - 2011-10-03 19:05:21 --> Config Class Initialized
DEBUG - 2011-10-03 19:05:21 --> Hooks Class Initialized
DEBUG - 2011-10-03 19:05:21 --> Utf8 Class Initialized
DEBUG - 2011-10-03 19:05:21 --> UTF-8 Support Enabled
DEBUG - 2011-10-03 19:05:21 --> URI Class Initialized
DEBUG - 2011-10-03 19:05:21 --> Router Class Initialized
DEBUG - 2011-10-03 19:05:21 --> Output Class Initialized
DEBUG - 2011-10-03 19:05:21 --> Input Class Initialized
DEBUG - 2011-10-03 19:05:21 --> Global POST and COOKIE data sanitized
DEBUG - 2011-10-03 19:05:21 --> Language Class Initialized
DEBUG - 2011-10-03 19:05:21 --> Loader Class Initialized
DEBUG - 2011-10-03 19:05:21 --> Controller Class Initialized
DEBUG - 2011-10-03 19:05:21 --> Model Class Initialized
DEBUG - 2011-10-03 19:05:21 --> Model Class Initialized
DEBUG - 2011-10-03 19:05:21 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-10-03 19:05:21 --> Database Driver Class Initialized
DEBUG - 2011-10-03 19:05:22 --> Final output sent to browser
DEBUG - 2011-10-03 19:05:22 --> Total execution time: 0.7942
DEBUG - 2011-10-03 19:58:50 --> Config Class Initialized
DEBUG - 2011-10-03 19:58:50 --> Hooks Class Initialized
DEBUG - 2011-10-03 19:58:50 --> Utf8 Class Initialized
DEBUG - 2011-10-03 19:58:50 --> UTF-8 Support Enabled
DEBUG - 2011-10-03 19:58:50 --> URI Class Initialized
DEBUG - 2011-10-03 19:58:50 --> Router Class Initialized
DEBUG - 2011-10-03 19:58:50 --> Output Class Initialized
DEBUG - 2011-10-03 19:58:50 --> Input Class Initialized
DEBUG - 2011-10-03 19:58:50 --> Global POST and COOKIE data sanitized
DEBUG - 2011-10-03 19:58:50 --> Language Class Initialized
DEBUG - 2011-10-03 19:58:50 --> Loader Class Initialized
DEBUG - 2011-10-03 19:58:50 --> Controller Class Initialized
DEBUG - 2011-10-03 19:58:50 --> Model Class Initialized
DEBUG - 2011-10-03 19:58:50 --> Model Class Initialized
DEBUG - 2011-10-03 19:58:50 --> Model Class Initialized
DEBUG - 2011-10-03 19:58:50 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-10-03 19:58:50 --> Database Driver Class Initialized
DEBUG - 2011-10-03 19:58:51 --> File loaded: application/views/table/main.php
DEBUG - 2011-10-03 19:58:51 --> Helper loaded: url_helper
DEBUG - 2011-10-03 19:58:51 --> File loaded: application/views/common/header.php
DEBUG - 2011-10-03 19:58:51 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-10-03 19:58:51 --> File loaded: application/views/common/footer.php
DEBUG - 2011-10-03 19:58:51 --> File loaded: application/views/layout/main.php
DEBUG - 2011-10-03 19:58:51 --> Final output sent to browser
DEBUG - 2011-10-03 19:58:51 --> Total execution time: 1.0906
DEBUG - 2011-10-03 19:59:07 --> Config Class Initialized
DEBUG - 2011-10-03 19:59:07 --> Hooks Class Initialized
DEBUG - 2011-10-03 19:59:07 --> Utf8 Class Initialized
DEBUG - 2011-10-03 19:59:07 --> UTF-8 Support Enabled
DEBUG - 2011-10-03 19:59:07 --> URI Class Initialized
DEBUG - 2011-10-03 19:59:07 --> Router Class Initialized
DEBUG - 2011-10-03 19:59:07 --> Output Class Initialized
DEBUG - 2011-10-03 19:59:07 --> Input Class Initialized
DEBUG - 2011-10-03 19:59:07 --> Global POST and COOKIE data sanitized
DEBUG - 2011-10-03 19:59:07 --> Language Class Initialized
DEBUG - 2011-10-03 19:59:07 --> Loader Class Initialized
DEBUG - 2011-10-03 19:59:07 --> Controller Class Initialized
ERROR - 2011-10-03 19:59:07 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-10-03 19:59:07 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-10-03 19:59:07 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-10-03 19:59:07 --> Model Class Initialized
DEBUG - 2011-10-03 19:59:07 --> Model Class Initialized
DEBUG - 2011-10-03 19:59:07 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-10-03 19:59:07 --> Database Driver Class Initialized
DEBUG - 2011-10-03 19:59:07 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-10-03 19:59:07 --> Helper loaded: url_helper
DEBUG - 2011-10-03 19:59:07 --> File loaded: application/views/common/header.php
DEBUG - 2011-10-03 19:59:07 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-10-03 19:59:07 --> File loaded: application/views/common/footer.php
DEBUG - 2011-10-03 19:59:07 --> File loaded: application/views/layout/main.php
DEBUG - 2011-10-03 19:59:07 --> Final output sent to browser
DEBUG - 2011-10-03 19:59:07 --> Total execution time: 0.0725
DEBUG - 2011-10-03 20:28:51 --> Config Class Initialized
DEBUG - 2011-10-03 20:28:51 --> Hooks Class Initialized
DEBUG - 2011-10-03 20:28:51 --> Utf8 Class Initialized
DEBUG - 2011-10-03 20:28:51 --> UTF-8 Support Enabled
DEBUG - 2011-10-03 20:28:51 --> URI Class Initialized
DEBUG - 2011-10-03 20:28:51 --> Router Class Initialized
DEBUG - 2011-10-03 20:28:51 --> Output Class Initialized
DEBUG - 2011-10-03 20:28:51 --> Input Class Initialized
DEBUG - 2011-10-03 20:28:51 --> Global POST and COOKIE data sanitized
DEBUG - 2011-10-03 20:28:51 --> Language Class Initialized
DEBUG - 2011-10-03 20:28:51 --> Loader Class Initialized
DEBUG - 2011-10-03 20:28:51 --> Controller Class Initialized
DEBUG - 2011-10-03 20:28:51 --> Model Class Initialized
DEBUG - 2011-10-03 20:28:51 --> Model Class Initialized
DEBUG - 2011-10-03 20:28:51 --> Model Class Initialized
DEBUG - 2011-10-03 20:28:51 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-10-03 20:28:51 --> Database Driver Class Initialized
DEBUG - 2011-10-03 20:28:53 --> File loaded: application/views/table/main.php
DEBUG - 2011-10-03 20:28:53 --> Helper loaded: url_helper
DEBUG - 2011-10-03 20:28:53 --> File loaded: application/views/common/header.php
DEBUG - 2011-10-03 20:28:53 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-10-03 20:28:53 --> File loaded: application/views/common/footer.php
DEBUG - 2011-10-03 20:28:53 --> File loaded: application/views/layout/main.php
DEBUG - 2011-10-03 20:28:53 --> Final output sent to browser
DEBUG - 2011-10-03 20:28:53 --> Total execution time: 1.9195
DEBUG - 2011-10-03 20:28:55 --> Config Class Initialized
DEBUG - 2011-10-03 20:28:55 --> Hooks Class Initialized
DEBUG - 2011-10-03 20:28:55 --> Utf8 Class Initialized
DEBUG - 2011-10-03 20:28:55 --> UTF-8 Support Enabled
DEBUG - 2011-10-03 20:28:55 --> URI Class Initialized
DEBUG - 2011-10-03 20:28:55 --> Router Class Initialized
ERROR - 2011-10-03 20:28:55 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-10-03 20:29:06 --> Config Class Initialized
DEBUG - 2011-10-03 20:29:06 --> Hooks Class Initialized
DEBUG - 2011-10-03 20:29:06 --> Utf8 Class Initialized
DEBUG - 2011-10-03 20:29:06 --> UTF-8 Support Enabled
DEBUG - 2011-10-03 20:29:06 --> URI Class Initialized
DEBUG - 2011-10-03 20:29:06 --> Router Class Initialized
DEBUG - 2011-10-03 20:29:06 --> Output Class Initialized
DEBUG - 2011-10-03 20:29:06 --> Input Class Initialized
DEBUG - 2011-10-03 20:29:06 --> Global POST and COOKIE data sanitized
DEBUG - 2011-10-03 20:29:06 --> Language Class Initialized
DEBUG - 2011-10-03 20:29:06 --> Loader Class Initialized
DEBUG - 2011-10-03 20:29:06 --> Controller Class Initialized
DEBUG - 2011-10-03 20:29:06 --> Model Class Initialized
DEBUG - 2011-10-03 20:29:06 --> Model Class Initialized
DEBUG - 2011-10-03 20:29:06 --> Model Class Initialized
DEBUG - 2011-10-03 20:29:06 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-10-03 20:29:06 --> Database Driver Class Initialized
DEBUG - 2011-10-03 20:29:07 --> File loaded: application/views/table/main.php
DEBUG - 2011-10-03 20:29:07 --> Helper loaded: url_helper
DEBUG - 2011-10-03 20:29:07 --> File loaded: application/views/common/header.php
DEBUG - 2011-10-03 20:29:07 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-10-03 20:29:07 --> File loaded: application/views/common/footer.php
DEBUG - 2011-10-03 20:29:07 --> File loaded: application/views/layout/main.php
DEBUG - 2011-10-03 20:29:07 --> Final output sent to browser
DEBUG - 2011-10-03 20:29:07 --> Total execution time: 0.4275
DEBUG - 2011-10-03 20:29:08 --> Config Class Initialized
DEBUG - 2011-10-03 20:29:08 --> Hooks Class Initialized
DEBUG - 2011-10-03 20:29:08 --> Utf8 Class Initialized
DEBUG - 2011-10-03 20:29:08 --> UTF-8 Support Enabled
DEBUG - 2011-10-03 20:29:08 --> URI Class Initialized
DEBUG - 2011-10-03 20:29:08 --> Router Class Initialized
ERROR - 2011-10-03 20:29:08 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-10-03 20:29:13 --> Config Class Initialized
DEBUG - 2011-10-03 20:29:13 --> Hooks Class Initialized
DEBUG - 2011-10-03 20:29:13 --> Utf8 Class Initialized
DEBUG - 2011-10-03 20:29:13 --> UTF-8 Support Enabled
DEBUG - 2011-10-03 20:29:13 --> URI Class Initialized
DEBUG - 2011-10-03 20:29:13 --> Router Class Initialized
DEBUG - 2011-10-03 20:29:13 --> Output Class Initialized
DEBUG - 2011-10-03 20:29:13 --> Input Class Initialized
DEBUG - 2011-10-03 20:29:13 --> Global POST and COOKIE data sanitized
DEBUG - 2011-10-03 20:29:13 --> Language Class Initialized
DEBUG - 2011-10-03 20:29:13 --> Loader Class Initialized
DEBUG - 2011-10-03 20:29:13 --> Controller Class Initialized
DEBUG - 2011-10-03 20:29:13 --> Model Class Initialized
DEBUG - 2011-10-03 20:29:13 --> Model Class Initialized
DEBUG - 2011-10-03 20:29:13 --> Model Class Initialized
DEBUG - 2011-10-03 20:29:13 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-10-03 20:29:13 --> Database Driver Class Initialized
DEBUG - 2011-10-03 20:29:13 --> File loaded: application/views/table/main.php
DEBUG - 2011-10-03 20:29:13 --> Helper loaded: url_helper
DEBUG - 2011-10-03 20:29:13 --> File loaded: application/views/common/header.php
DEBUG - 2011-10-03 20:29:13 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-10-03 20:29:13 --> File loaded: application/views/common/footer.php
DEBUG - 2011-10-03 20:29:13 --> File loaded: application/views/layout/main.php
DEBUG - 2011-10-03 20:29:13 --> Final output sent to browser
DEBUG - 2011-10-03 20:29:13 --> Total execution time: 0.2420
DEBUG - 2011-10-03 20:29:15 --> Config Class Initialized
DEBUG - 2011-10-03 20:29:15 --> Hooks Class Initialized
DEBUG - 2011-10-03 20:29:15 --> Utf8 Class Initialized
DEBUG - 2011-10-03 20:29:15 --> UTF-8 Support Enabled
DEBUG - 2011-10-03 20:29:15 --> URI Class Initialized
DEBUG - 2011-10-03 20:29:15 --> Router Class Initialized
ERROR - 2011-10-03 20:29:15 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-10-03 20:29:17 --> Config Class Initialized
DEBUG - 2011-10-03 20:29:17 --> Hooks Class Initialized
DEBUG - 2011-10-03 20:29:17 --> Utf8 Class Initialized
DEBUG - 2011-10-03 20:29:17 --> UTF-8 Support Enabled
DEBUG - 2011-10-03 20:29:17 --> URI Class Initialized
DEBUG - 2011-10-03 20:29:17 --> Router Class Initialized
DEBUG - 2011-10-03 20:29:17 --> Output Class Initialized
DEBUG - 2011-10-03 20:29:17 --> Input Class Initialized
DEBUG - 2011-10-03 20:29:17 --> Global POST and COOKIE data sanitized
DEBUG - 2011-10-03 20:29:17 --> Language Class Initialized
DEBUG - 2011-10-03 20:29:17 --> Loader Class Initialized
DEBUG - 2011-10-03 20:29:17 --> Controller Class Initialized
DEBUG - 2011-10-03 20:29:17 --> Model Class Initialized
DEBUG - 2011-10-03 20:29:17 --> Model Class Initialized
DEBUG - 2011-10-03 20:29:17 --> Model Class Initialized
DEBUG - 2011-10-03 20:29:17 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-10-03 20:29:17 --> Database Driver Class Initialized
DEBUG - 2011-10-03 20:29:17 --> File loaded: application/views/table/main.php
DEBUG - 2011-10-03 20:29:17 --> Helper loaded: url_helper
DEBUG - 2011-10-03 20:29:17 --> File loaded: application/views/common/header.php
DEBUG - 2011-10-03 20:29:17 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-10-03 20:29:17 --> File loaded: application/views/common/footer.php
DEBUG - 2011-10-03 20:29:17 --> File loaded: application/views/layout/main.php
DEBUG - 2011-10-03 20:29:17 --> Final output sent to browser
DEBUG - 2011-10-03 20:29:17 --> Total execution time: 0.0971
DEBUG - 2011-10-03 20:29:20 --> Config Class Initialized
DEBUG - 2011-10-03 20:29:20 --> Hooks Class Initialized
DEBUG - 2011-10-03 20:29:20 --> Utf8 Class Initialized
DEBUG - 2011-10-03 20:29:20 --> UTF-8 Support Enabled
DEBUG - 2011-10-03 20:29:20 --> URI Class Initialized
DEBUG - 2011-10-03 20:29:20 --> Router Class Initialized
DEBUG - 2011-10-03 20:29:20 --> Output Class Initialized
DEBUG - 2011-10-03 20:29:20 --> Input Class Initialized
DEBUG - 2011-10-03 20:29:20 --> Global POST and COOKIE data sanitized
DEBUG - 2011-10-03 20:29:20 --> Language Class Initialized
DEBUG - 2011-10-03 20:29:20 --> Loader Class Initialized
DEBUG - 2011-10-03 20:29:20 --> Controller Class Initialized
DEBUG - 2011-10-03 20:29:20 --> Model Class Initialized
DEBUG - 2011-10-03 20:29:20 --> Model Class Initialized
DEBUG - 2011-10-03 20:29:20 --> Model Class Initialized
DEBUG - 2011-10-03 20:29:20 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-10-03 20:29:20 --> Database Driver Class Initialized
DEBUG - 2011-10-03 20:29:20 --> File loaded: application/views/table/main.php
DEBUG - 2011-10-03 20:29:20 --> Helper loaded: url_helper
DEBUG - 2011-10-03 20:29:20 --> File loaded: application/views/common/header.php
DEBUG - 2011-10-03 20:29:20 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-10-03 20:29:20 --> File loaded: application/views/common/footer.php
DEBUG - 2011-10-03 20:29:20 --> File loaded: application/views/layout/main.php
DEBUG - 2011-10-03 20:29:20 --> Final output sent to browser
DEBUG - 2011-10-03 20:29:20 --> Total execution time: 0.4443
DEBUG - 2011-10-03 20:29:21 --> Config Class Initialized
DEBUG - 2011-10-03 20:29:21 --> Hooks Class Initialized
DEBUG - 2011-10-03 20:29:21 --> Utf8 Class Initialized
DEBUG - 2011-10-03 20:29:21 --> UTF-8 Support Enabled
DEBUG - 2011-10-03 20:29:21 --> URI Class Initialized
DEBUG - 2011-10-03 20:29:21 --> Router Class Initialized
DEBUG - 2011-10-03 20:29:21 --> Output Class Initialized
DEBUG - 2011-10-03 20:29:21 --> Input Class Initialized
DEBUG - 2011-10-03 20:29:21 --> Global POST and COOKIE data sanitized
DEBUG - 2011-10-03 20:29:21 --> Language Class Initialized
DEBUG - 2011-10-03 20:29:21 --> Loader Class Initialized
DEBUG - 2011-10-03 20:29:21 --> Controller Class Initialized
DEBUG - 2011-10-03 20:29:21 --> Model Class Initialized
DEBUG - 2011-10-03 20:29:21 --> Model Class Initialized
DEBUG - 2011-10-03 20:29:21 --> Model Class Initialized
DEBUG - 2011-10-03 20:29:21 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-10-03 20:29:21 --> Database Driver Class Initialized
DEBUG - 2011-10-03 20:29:21 --> File loaded: application/views/table/main.php
DEBUG - 2011-10-03 20:29:21 --> Helper loaded: url_helper
DEBUG - 2011-10-03 20:29:21 --> File loaded: application/views/common/header.php
DEBUG - 2011-10-03 20:29:21 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-10-03 20:29:21 --> File loaded: application/views/common/footer.php
DEBUG - 2011-10-03 20:29:21 --> File loaded: application/views/layout/main.php
DEBUG - 2011-10-03 20:29:21 --> Final output sent to browser
DEBUG - 2011-10-03 20:29:21 --> Total execution time: 0.0559
DEBUG - 2011-10-03 20:29:21 --> Config Class Initialized
DEBUG - 2011-10-03 20:29:21 --> Hooks Class Initialized
DEBUG - 2011-10-03 20:29:21 --> Utf8 Class Initialized
DEBUG - 2011-10-03 20:29:21 --> UTF-8 Support Enabled
DEBUG - 2011-10-03 20:29:21 --> URI Class Initialized
DEBUG - 2011-10-03 20:29:21 --> Router Class Initialized
ERROR - 2011-10-03 20:29:21 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-10-03 20:29:28 --> Config Class Initialized
DEBUG - 2011-10-03 20:29:28 --> Hooks Class Initialized
DEBUG - 2011-10-03 20:29:28 --> Utf8 Class Initialized
DEBUG - 2011-10-03 20:29:28 --> UTF-8 Support Enabled
DEBUG - 2011-10-03 20:29:28 --> URI Class Initialized
DEBUG - 2011-10-03 20:29:28 --> Router Class Initialized
DEBUG - 2011-10-03 20:29:28 --> Output Class Initialized
DEBUG - 2011-10-03 20:29:28 --> Input Class Initialized
DEBUG - 2011-10-03 20:29:28 --> Global POST and COOKIE data sanitized
DEBUG - 2011-10-03 20:29:28 --> Language Class Initialized
DEBUG - 2011-10-03 20:29:28 --> Loader Class Initialized
DEBUG - 2011-10-03 20:29:28 --> Controller Class Initialized
DEBUG - 2011-10-03 20:29:28 --> Model Class Initialized
DEBUG - 2011-10-03 20:29:28 --> Model Class Initialized
DEBUG - 2011-10-03 20:29:28 --> Model Class Initialized
DEBUG - 2011-10-03 20:29:28 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-10-03 20:29:28 --> Database Driver Class Initialized
DEBUG - 2011-10-03 20:29:29 --> File loaded: application/views/table/main.php
DEBUG - 2011-10-03 20:29:29 --> Helper loaded: url_helper
DEBUG - 2011-10-03 20:29:29 --> File loaded: application/views/common/header.php
DEBUG - 2011-10-03 20:29:29 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-10-03 20:29:29 --> File loaded: application/views/common/footer.php
DEBUG - 2011-10-03 20:29:29 --> File loaded: application/views/layout/main.php
DEBUG - 2011-10-03 20:29:29 --> Final output sent to browser
DEBUG - 2011-10-03 20:29:29 --> Total execution time: 1.2933
DEBUG - 2011-10-03 20:29:30 --> Config Class Initialized
DEBUG - 2011-10-03 20:29:30 --> Hooks Class Initialized
DEBUG - 2011-10-03 20:29:30 --> Utf8 Class Initialized
DEBUG - 2011-10-03 20:29:30 --> UTF-8 Support Enabled
DEBUG - 2011-10-03 20:29:30 --> URI Class Initialized
DEBUG - 2011-10-03 20:29:30 --> Router Class Initialized
ERROR - 2011-10-03 20:29:30 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-10-03 20:29:31 --> Config Class Initialized
DEBUG - 2011-10-03 20:29:31 --> Hooks Class Initialized
DEBUG - 2011-10-03 20:29:31 --> Utf8 Class Initialized
DEBUG - 2011-10-03 20:29:31 --> UTF-8 Support Enabled
DEBUG - 2011-10-03 20:29:31 --> URI Class Initialized
DEBUG - 2011-10-03 20:29:31 --> Router Class Initialized
DEBUG - 2011-10-03 20:29:31 --> Output Class Initialized
DEBUG - 2011-10-03 20:29:31 --> Input Class Initialized
DEBUG - 2011-10-03 20:29:31 --> Global POST and COOKIE data sanitized
DEBUG - 2011-10-03 20:29:31 --> Language Class Initialized
DEBUG - 2011-10-03 20:29:31 --> Loader Class Initialized
DEBUG - 2011-10-03 20:29:31 --> Controller Class Initialized
DEBUG - 2011-10-03 20:29:31 --> Model Class Initialized
DEBUG - 2011-10-03 20:29:31 --> Model Class Initialized
DEBUG - 2011-10-03 20:29:31 --> Model Class Initialized
DEBUG - 2011-10-03 20:29:31 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-10-03 20:29:31 --> Database Driver Class Initialized
DEBUG - 2011-10-03 20:29:31 --> File loaded: application/views/table/main.php
DEBUG - 2011-10-03 20:29:31 --> Helper loaded: url_helper
DEBUG - 2011-10-03 20:29:31 --> File loaded: application/views/common/header.php
DEBUG - 2011-10-03 20:29:31 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-10-03 20:29:31 --> File loaded: application/views/common/footer.php
DEBUG - 2011-10-03 20:29:31 --> File loaded: application/views/layout/main.php
DEBUG - 2011-10-03 20:29:31 --> Final output sent to browser
DEBUG - 2011-10-03 20:29:31 --> Total execution time: 0.0810
DEBUG - 2011-10-03 20:29:36 --> Config Class Initialized
DEBUG - 2011-10-03 20:29:36 --> Hooks Class Initialized
DEBUG - 2011-10-03 20:29:36 --> Utf8 Class Initialized
DEBUG - 2011-10-03 20:29:36 --> UTF-8 Support Enabled
DEBUG - 2011-10-03 20:29:36 --> URI Class Initialized
DEBUG - 2011-10-03 20:29:36 --> Router Class Initialized
DEBUG - 2011-10-03 20:29:36 --> Output Class Initialized
DEBUG - 2011-10-03 20:29:36 --> Input Class Initialized
DEBUG - 2011-10-03 20:29:36 --> Global POST and COOKIE data sanitized
DEBUG - 2011-10-03 20:29:36 --> Language Class Initialized
DEBUG - 2011-10-03 20:29:36 --> Loader Class Initialized
DEBUG - 2011-10-03 20:29:36 --> Controller Class Initialized
DEBUG - 2011-10-03 20:29:36 --> Model Class Initialized
DEBUG - 2011-10-03 20:29:36 --> Model Class Initialized
DEBUG - 2011-10-03 20:29:36 --> Model Class Initialized
DEBUG - 2011-10-03 20:29:36 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-10-03 20:29:36 --> Database Driver Class Initialized
DEBUG - 2011-10-03 20:29:36 --> File loaded: application/views/table/main.php
DEBUG - 2011-10-03 20:29:36 --> Helper loaded: url_helper
DEBUG - 2011-10-03 20:29:36 --> File loaded: application/views/common/header.php
DEBUG - 2011-10-03 20:29:36 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-10-03 20:29:36 --> File loaded: application/views/common/footer.php
DEBUG - 2011-10-03 20:29:36 --> File loaded: application/views/layout/main.php
DEBUG - 2011-10-03 20:29:36 --> Final output sent to browser
DEBUG - 2011-10-03 20:29:36 --> Total execution time: 0.2366
DEBUG - 2011-10-03 20:29:37 --> Config Class Initialized
DEBUG - 2011-10-03 20:29:37 --> Hooks Class Initialized
DEBUG - 2011-10-03 20:29:37 --> Utf8 Class Initialized
DEBUG - 2011-10-03 20:29:37 --> UTF-8 Support Enabled
DEBUG - 2011-10-03 20:29:37 --> URI Class Initialized
DEBUG - 2011-10-03 20:29:37 --> Router Class Initialized
ERROR - 2011-10-03 20:29:37 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-10-03 20:29:42 --> Config Class Initialized
DEBUG - 2011-10-03 20:29:42 --> Hooks Class Initialized
DEBUG - 2011-10-03 20:29:42 --> Utf8 Class Initialized
DEBUG - 2011-10-03 20:29:42 --> UTF-8 Support Enabled
DEBUG - 2011-10-03 20:29:42 --> URI Class Initialized
DEBUG - 2011-10-03 20:29:42 --> Router Class Initialized
DEBUG - 2011-10-03 20:29:42 --> Output Class Initialized
DEBUG - 2011-10-03 20:29:42 --> Input Class Initialized
DEBUG - 2011-10-03 20:29:42 --> Global POST and COOKIE data sanitized
DEBUG - 2011-10-03 20:29:42 --> Language Class Initialized
DEBUG - 2011-10-03 20:29:42 --> Loader Class Initialized
DEBUG - 2011-10-03 20:29:42 --> Controller Class Initialized
DEBUG - 2011-10-03 20:29:42 --> Model Class Initialized
DEBUG - 2011-10-03 20:29:42 --> Model Class Initialized
DEBUG - 2011-10-03 20:29:42 --> Model Class Initialized
DEBUG - 2011-10-03 20:29:42 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-10-03 20:29:42 --> Database Driver Class Initialized
DEBUG - 2011-10-03 20:29:42 --> File loaded: application/views/table/main.php
DEBUG - 2011-10-03 20:29:42 --> Helper loaded: url_helper
DEBUG - 2011-10-03 20:29:42 --> File loaded: application/views/common/header.php
DEBUG - 2011-10-03 20:29:42 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-10-03 20:29:42 --> File loaded: application/views/common/footer.php
DEBUG - 2011-10-03 20:29:42 --> File loaded: application/views/layout/main.php
DEBUG - 2011-10-03 20:29:42 --> Final output sent to browser
DEBUG - 2011-10-03 20:29:42 --> Total execution time: 0.2649
DEBUG - 2011-10-03 20:29:43 --> Config Class Initialized
DEBUG - 2011-10-03 20:29:43 --> Hooks Class Initialized
DEBUG - 2011-10-03 20:29:43 --> Utf8 Class Initialized
DEBUG - 2011-10-03 20:29:43 --> UTF-8 Support Enabled
DEBUG - 2011-10-03 20:29:43 --> URI Class Initialized
DEBUG - 2011-10-03 20:29:43 --> Router Class Initialized
DEBUG - 2011-10-03 20:29:43 --> Output Class Initialized
DEBUG - 2011-10-03 20:29:43 --> Input Class Initialized
DEBUG - 2011-10-03 20:29:43 --> Global POST and COOKIE data sanitized
DEBUG - 2011-10-03 20:29:43 --> Language Class Initialized
DEBUG - 2011-10-03 20:29:43 --> Loader Class Initialized
DEBUG - 2011-10-03 20:29:43 --> Controller Class Initialized
DEBUG - 2011-10-03 20:29:43 --> Model Class Initialized
DEBUG - 2011-10-03 20:29:43 --> Model Class Initialized
DEBUG - 2011-10-03 20:29:43 --> Model Class Initialized
DEBUG - 2011-10-03 20:29:43 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-10-03 20:29:43 --> Database Driver Class Initialized
DEBUG - 2011-10-03 20:29:43 --> File loaded: application/views/table/main.php
DEBUG - 2011-10-03 20:29:43 --> Helper loaded: url_helper
DEBUG - 2011-10-03 20:29:43 --> File loaded: application/views/common/header.php
DEBUG - 2011-10-03 20:29:43 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-10-03 20:29:43 --> File loaded: application/views/common/footer.php
DEBUG - 2011-10-03 20:29:43 --> File loaded: application/views/layout/main.php
DEBUG - 2011-10-03 20:29:43 --> Final output sent to browser
DEBUG - 2011-10-03 20:29:43 --> Total execution time: 0.0491
DEBUG - 2011-10-03 20:29:44 --> Config Class Initialized
DEBUG - 2011-10-03 20:29:44 --> Hooks Class Initialized
DEBUG - 2011-10-03 20:29:44 --> Utf8 Class Initialized
DEBUG - 2011-10-03 20:29:44 --> UTF-8 Support Enabled
DEBUG - 2011-10-03 20:29:44 --> URI Class Initialized
DEBUG - 2011-10-03 20:29:44 --> Router Class Initialized
ERROR - 2011-10-03 20:29:44 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-10-03 20:29:49 --> Config Class Initialized
DEBUG - 2011-10-03 20:29:49 --> Hooks Class Initialized
DEBUG - 2011-10-03 20:29:49 --> Utf8 Class Initialized
DEBUG - 2011-10-03 20:29:49 --> UTF-8 Support Enabled
DEBUG - 2011-10-03 20:29:49 --> URI Class Initialized
DEBUG - 2011-10-03 20:29:49 --> Router Class Initialized
DEBUG - 2011-10-03 20:29:49 --> Output Class Initialized
DEBUG - 2011-10-03 20:29:49 --> Input Class Initialized
DEBUG - 2011-10-03 20:29:49 --> Global POST and COOKIE data sanitized
DEBUG - 2011-10-03 20:29:49 --> Language Class Initialized
DEBUG - 2011-10-03 20:29:49 --> Loader Class Initialized
DEBUG - 2011-10-03 20:29:49 --> Controller Class Initialized
DEBUG - 2011-10-03 20:29:49 --> Model Class Initialized
DEBUG - 2011-10-03 20:29:49 --> Model Class Initialized
DEBUG - 2011-10-03 20:29:49 --> Model Class Initialized
DEBUG - 2011-10-03 20:29:49 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-10-03 20:29:49 --> Database Driver Class Initialized
DEBUG - 2011-10-03 20:29:49 --> File loaded: application/views/table/main.php
DEBUG - 2011-10-03 20:29:49 --> Helper loaded: url_helper
DEBUG - 2011-10-03 20:29:49 --> File loaded: application/views/common/header.php
DEBUG - 2011-10-03 20:29:49 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-10-03 20:29:49 --> File loaded: application/views/common/footer.php
DEBUG - 2011-10-03 20:29:49 --> File loaded: application/views/layout/main.php
DEBUG - 2011-10-03 20:29:49 --> Final output sent to browser
DEBUG - 2011-10-03 20:29:49 --> Total execution time: 0.2366
DEBUG - 2011-10-03 20:29:50 --> Config Class Initialized
DEBUG - 2011-10-03 20:29:50 --> Hooks Class Initialized
DEBUG - 2011-10-03 20:29:50 --> Utf8 Class Initialized
DEBUG - 2011-10-03 20:29:50 --> UTF-8 Support Enabled
DEBUG - 2011-10-03 20:29:50 --> URI Class Initialized
DEBUG - 2011-10-03 20:29:50 --> Router Class Initialized
DEBUG - 2011-10-03 20:29:50 --> Output Class Initialized
DEBUG - 2011-10-03 20:29:50 --> Input Class Initialized
DEBUG - 2011-10-03 20:29:50 --> Global POST and COOKIE data sanitized
DEBUG - 2011-10-03 20:29:50 --> Language Class Initialized
DEBUG - 2011-10-03 20:29:50 --> Loader Class Initialized
DEBUG - 2011-10-03 20:29:50 --> Controller Class Initialized
DEBUG - 2011-10-03 20:29:50 --> Model Class Initialized
DEBUG - 2011-10-03 20:29:50 --> Model Class Initialized
DEBUG - 2011-10-03 20:29:50 --> Model Class Initialized
DEBUG - 2011-10-03 20:29:50 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-10-03 20:29:50 --> Database Driver Class Initialized
DEBUG - 2011-10-03 20:29:50 --> File loaded: application/views/table/main.php
DEBUG - 2011-10-03 20:29:50 --> Helper loaded: url_helper
DEBUG - 2011-10-03 20:29:50 --> File loaded: application/views/common/header.php
DEBUG - 2011-10-03 20:29:50 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-10-03 20:29:50 --> File loaded: application/views/common/footer.php
DEBUG - 2011-10-03 20:29:50 --> File loaded: application/views/layout/main.php
DEBUG - 2011-10-03 20:29:50 --> Final output sent to browser
DEBUG - 2011-10-03 20:29:50 --> Total execution time: 0.1085
DEBUG - 2011-10-03 20:29:50 --> Config Class Initialized
DEBUG - 2011-10-03 20:29:50 --> Hooks Class Initialized
DEBUG - 2011-10-03 20:29:50 --> Utf8 Class Initialized
DEBUG - 2011-10-03 20:29:50 --> UTF-8 Support Enabled
DEBUG - 2011-10-03 20:29:50 --> URI Class Initialized
DEBUG - 2011-10-03 20:29:50 --> Router Class Initialized
ERROR - 2011-10-03 20:29:50 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-10-03 20:29:55 --> Config Class Initialized
DEBUG - 2011-10-03 20:29:55 --> Hooks Class Initialized
DEBUG - 2011-10-03 20:29:55 --> Utf8 Class Initialized
DEBUG - 2011-10-03 20:29:55 --> UTF-8 Support Enabled
DEBUG - 2011-10-03 20:29:55 --> URI Class Initialized
DEBUG - 2011-10-03 20:29:55 --> Router Class Initialized
DEBUG - 2011-10-03 20:29:55 --> Output Class Initialized
DEBUG - 2011-10-03 20:29:55 --> Input Class Initialized
DEBUG - 2011-10-03 20:29:55 --> Global POST and COOKIE data sanitized
DEBUG - 2011-10-03 20:29:55 --> Language Class Initialized
DEBUG - 2011-10-03 20:29:55 --> Loader Class Initialized
DEBUG - 2011-10-03 20:29:55 --> Controller Class Initialized
DEBUG - 2011-10-03 20:29:55 --> Model Class Initialized
DEBUG - 2011-10-03 20:29:55 --> Model Class Initialized
DEBUG - 2011-10-03 20:29:55 --> Model Class Initialized
DEBUG - 2011-10-03 20:29:55 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-10-03 20:29:55 --> Database Driver Class Initialized
DEBUG - 2011-10-03 20:29:55 --> File loaded: application/views/table/main.php
DEBUG - 2011-10-03 20:29:55 --> Helper loaded: url_helper
DEBUG - 2011-10-03 20:29:55 --> File loaded: application/views/common/header.php
DEBUG - 2011-10-03 20:29:55 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-10-03 20:29:55 --> File loaded: application/views/common/footer.php
DEBUG - 2011-10-03 20:29:55 --> File loaded: application/views/layout/main.php
DEBUG - 2011-10-03 20:29:55 --> Final output sent to browser
DEBUG - 2011-10-03 20:29:55 --> Total execution time: 0.2898
DEBUG - 2011-10-03 20:29:56 --> Config Class Initialized
DEBUG - 2011-10-03 20:29:56 --> Hooks Class Initialized
DEBUG - 2011-10-03 20:29:56 --> Utf8 Class Initialized
DEBUG - 2011-10-03 20:29:56 --> UTF-8 Support Enabled
DEBUG - 2011-10-03 20:29:56 --> URI Class Initialized
DEBUG - 2011-10-03 20:29:56 --> Router Class Initialized
ERROR - 2011-10-03 20:29:56 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-10-03 20:52:59 --> Config Class Initialized
DEBUG - 2011-10-03 20:52:59 --> Hooks Class Initialized
DEBUG - 2011-10-03 20:52:59 --> Utf8 Class Initialized
DEBUG - 2011-10-03 20:52:59 --> UTF-8 Support Enabled
DEBUG - 2011-10-03 20:52:59 --> URI Class Initialized
DEBUG - 2011-10-03 20:52:59 --> Router Class Initialized
DEBUG - 2011-10-03 20:52:59 --> No URI present. Default controller set.
DEBUG - 2011-10-03 20:52:59 --> Output Class Initialized
DEBUG - 2011-10-03 20:52:59 --> Input Class Initialized
DEBUG - 2011-10-03 20:52:59 --> Global POST and COOKIE data sanitized
DEBUG - 2011-10-03 20:52:59 --> Language Class Initialized
DEBUG - 2011-10-03 20:52:59 --> Loader Class Initialized
DEBUG - 2011-10-03 20:52:59 --> Controller Class Initialized
DEBUG - 2011-10-03 20:52:59 --> File loaded: application/views/splash/main.php
DEBUG - 2011-10-03 20:52:59 --> Helper loaded: url_helper
DEBUG - 2011-10-03 20:52:59 --> File loaded: application/views/common/header.php
DEBUG - 2011-10-03 20:52:59 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-10-03 20:52:59 --> File loaded: application/views/common/footer.php
DEBUG - 2011-10-03 20:52:59 --> File loaded: application/views/layout/main.php
DEBUG - 2011-10-03 20:52:59 --> Final output sent to browser
DEBUG - 2011-10-03 20:52:59 --> Total execution time: 0.0472
DEBUG - 2011-10-03 22:46:15 --> Config Class Initialized
DEBUG - 2011-10-03 22:46:15 --> Hooks Class Initialized
DEBUG - 2011-10-03 22:46:15 --> Utf8 Class Initialized
DEBUG - 2011-10-03 22:46:15 --> UTF-8 Support Enabled
DEBUG - 2011-10-03 22:46:15 --> URI Class Initialized
DEBUG - 2011-10-03 22:46:15 --> Router Class Initialized
DEBUG - 2011-10-03 22:46:15 --> Output Class Initialized
DEBUG - 2011-10-03 22:46:15 --> Input Class Initialized
DEBUG - 2011-10-03 22:46:15 --> Global POST and COOKIE data sanitized
DEBUG - 2011-10-03 22:46:15 --> Language Class Initialized
DEBUG - 2011-10-03 22:46:15 --> Loader Class Initialized
DEBUG - 2011-10-03 22:46:15 --> Controller Class Initialized
DEBUG - 2011-10-03 22:46:15 --> Model Class Initialized
DEBUG - 2011-10-03 22:46:15 --> Model Class Initialized
DEBUG - 2011-10-03 22:46:15 --> Model Class Initialized
DEBUG - 2011-10-03 22:46:15 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-10-03 22:46:15 --> Database Driver Class Initialized
DEBUG - 2011-10-03 22:46:16 --> File loaded: application/views/table/main.php
DEBUG - 2011-10-03 22:46:16 --> Helper loaded: url_helper
DEBUG - 2011-10-03 22:46:16 --> File loaded: application/views/common/header.php
DEBUG - 2011-10-03 22:46:16 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-10-03 22:46:16 --> File loaded: application/views/common/footer.php
DEBUG - 2011-10-03 22:46:16 --> File loaded: application/views/layout/main.php
DEBUG - 2011-10-03 22:46:16 --> Final output sent to browser
DEBUG - 2011-10-03 22:46:16 --> Total execution time: 1.2691
DEBUG - 2011-10-03 22:46:19 --> Config Class Initialized
DEBUG - 2011-10-03 22:46:19 --> Hooks Class Initialized
DEBUG - 2011-10-03 22:46:19 --> Utf8 Class Initialized
DEBUG - 2011-10-03 22:46:19 --> UTF-8 Support Enabled
DEBUG - 2011-10-03 22:46:19 --> URI Class Initialized
DEBUG - 2011-10-03 22:46:19 --> Router Class Initialized
ERROR - 2011-10-03 22:46:19 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-10-03 22:46:19 --> Config Class Initialized
DEBUG - 2011-10-03 22:46:19 --> Hooks Class Initialized
DEBUG - 2011-10-03 22:46:19 --> Utf8 Class Initialized
DEBUG - 2011-10-03 22:46:19 --> UTF-8 Support Enabled
DEBUG - 2011-10-03 22:46:19 --> URI Class Initialized
DEBUG - 2011-10-03 22:46:19 --> Router Class Initialized
ERROR - 2011-10-03 22:46:19 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-10-03 22:46:20 --> Config Class Initialized
DEBUG - 2011-10-03 22:46:20 --> Hooks Class Initialized
DEBUG - 2011-10-03 22:46:20 --> Utf8 Class Initialized
DEBUG - 2011-10-03 22:46:20 --> UTF-8 Support Enabled
DEBUG - 2011-10-03 22:46:20 --> URI Class Initialized
DEBUG - 2011-10-03 22:46:20 --> Router Class Initialized
ERROR - 2011-10-03 22:46:20 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-10-03 22:46:26 --> Config Class Initialized
DEBUG - 2011-10-03 22:46:26 --> Hooks Class Initialized
DEBUG - 2011-10-03 22:46:26 --> Utf8 Class Initialized
DEBUG - 2011-10-03 22:46:26 --> UTF-8 Support Enabled
DEBUG - 2011-10-03 22:46:26 --> URI Class Initialized
DEBUG - 2011-10-03 22:46:26 --> Router Class Initialized
DEBUG - 2011-10-03 22:46:26 --> Output Class Initialized
DEBUG - 2011-10-03 22:46:26 --> Input Class Initialized
DEBUG - 2011-10-03 22:46:26 --> Global POST and COOKIE data sanitized
DEBUG - 2011-10-03 22:46:26 --> Language Class Initialized
DEBUG - 2011-10-03 22:46:26 --> Loader Class Initialized
DEBUG - 2011-10-03 22:46:26 --> Controller Class Initialized
DEBUG - 2011-10-03 22:46:26 --> Model Class Initialized
DEBUG - 2011-10-03 22:46:26 --> Model Class Initialized
DEBUG - 2011-10-03 22:46:26 --> Model Class Initialized
DEBUG - 2011-10-03 22:46:26 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-10-03 22:46:26 --> Database Driver Class Initialized
DEBUG - 2011-10-03 22:46:26 --> File loaded: application/views/table/main.php
DEBUG - 2011-10-03 22:46:26 --> Helper loaded: url_helper
DEBUG - 2011-10-03 22:46:26 --> File loaded: application/views/common/header.php
DEBUG - 2011-10-03 22:46:26 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-10-03 22:46:26 --> File loaded: application/views/common/footer.php
DEBUG - 2011-10-03 22:46:26 --> File loaded: application/views/layout/main.php
DEBUG - 2011-10-03 22:46:26 --> Final output sent to browser
DEBUG - 2011-10-03 22:46:26 --> Total execution time: 0.0551
DEBUG - 2011-10-03 22:46:39 --> Config Class Initialized
DEBUG - 2011-10-03 22:46:39 --> Hooks Class Initialized
DEBUG - 2011-10-03 22:46:39 --> Utf8 Class Initialized
DEBUG - 2011-10-03 22:46:39 --> UTF-8 Support Enabled
DEBUG - 2011-10-03 22:46:39 --> URI Class Initialized
DEBUG - 2011-10-03 22:46:39 --> Router Class Initialized
DEBUG - 2011-10-03 22:46:39 --> Output Class Initialized
DEBUG - 2011-10-03 22:46:39 --> Input Class Initialized
DEBUG - 2011-10-03 22:46:39 --> Global POST and COOKIE data sanitized
DEBUG - 2011-10-03 22:46:39 --> Language Class Initialized
DEBUG - 2011-10-03 22:46:39 --> Loader Class Initialized
DEBUG - 2011-10-03 22:46:39 --> Controller Class Initialized
DEBUG - 2011-10-03 22:46:39 --> Model Class Initialized
DEBUG - 2011-10-03 22:46:39 --> Model Class Initialized
DEBUG - 2011-10-03 22:46:39 --> Model Class Initialized
DEBUG - 2011-10-03 22:46:39 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-10-03 22:46:39 --> Database Driver Class Initialized
DEBUG - 2011-10-03 22:46:39 --> File loaded: application/views/table/main.php
DEBUG - 2011-10-03 22:46:39 --> Helper loaded: url_helper
DEBUG - 2011-10-03 22:46:39 --> File loaded: application/views/common/header.php
DEBUG - 2011-10-03 22:46:39 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-10-03 22:46:39 --> File loaded: application/views/common/footer.php
DEBUG - 2011-10-03 22:46:39 --> File loaded: application/views/layout/main.php
DEBUG - 2011-10-03 22:46:39 --> Final output sent to browser
DEBUG - 2011-10-03 22:46:39 --> Total execution time: 0.0511
DEBUG - 2011-10-03 23:19:10 --> Config Class Initialized
DEBUG - 2011-10-03 23:19:10 --> Hooks Class Initialized
DEBUG - 2011-10-03 23:19:10 --> Utf8 Class Initialized
DEBUG - 2011-10-03 23:19:10 --> UTF-8 Support Enabled
DEBUG - 2011-10-03 23:19:10 --> URI Class Initialized
DEBUG - 2011-10-03 23:19:10 --> Router Class Initialized
DEBUG - 2011-10-03 23:19:10 --> Output Class Initialized
DEBUG - 2011-10-03 23:19:10 --> Input Class Initialized
DEBUG - 2011-10-03 23:19:10 --> Global POST and COOKIE data sanitized
DEBUG - 2011-10-03 23:19:10 --> Language Class Initialized
DEBUG - 2011-10-03 23:19:10 --> Loader Class Initialized
DEBUG - 2011-10-03 23:19:10 --> Controller Class Initialized
DEBUG - 2011-10-03 23:19:10 --> Model Class Initialized
DEBUG - 2011-10-03 23:19:10 --> Model Class Initialized
DEBUG - 2011-10-03 23:19:10 --> Model Class Initialized
DEBUG - 2011-10-03 23:19:10 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-10-03 23:19:10 --> Database Driver Class Initialized
DEBUG - 2011-10-03 23:19:11 --> File loaded: application/views/table/main.php
DEBUG - 2011-10-03 23:19:11 --> Helper loaded: url_helper
DEBUG - 2011-10-03 23:19:11 --> File loaded: application/views/common/header.php
DEBUG - 2011-10-03 23:19:11 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-10-03 23:19:11 --> File loaded: application/views/common/footer.php
DEBUG - 2011-10-03 23:19:11 --> File loaded: application/views/layout/main.php
DEBUG - 2011-10-03 23:19:11 --> Final output sent to browser
DEBUG - 2011-10-03 23:19:11 --> Total execution time: 0.8172
DEBUG - 2011-10-03 23:19:11 --> Config Class Initialized
DEBUG - 2011-10-03 23:19:11 --> Hooks Class Initialized
DEBUG - 2011-10-03 23:19:11 --> Utf8 Class Initialized
DEBUG - 2011-10-03 23:19:11 --> UTF-8 Support Enabled
DEBUG - 2011-10-03 23:19:11 --> URI Class Initialized
DEBUG - 2011-10-03 23:19:11 --> Router Class Initialized
DEBUG - 2011-10-03 23:19:11 --> Output Class Initialized
DEBUG - 2011-10-03 23:19:11 --> Input Class Initialized
DEBUG - 2011-10-03 23:19:11 --> Global POST and COOKIE data sanitized
DEBUG - 2011-10-03 23:19:11 --> Language Class Initialized
DEBUG - 2011-10-03 23:19:11 --> Loader Class Initialized
DEBUG - 2011-10-03 23:19:11 --> Controller Class Initialized
ERROR - 2011-10-03 23:19:11 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-10-03 23:19:11 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-10-03 23:19:11 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-10-03 23:19:11 --> Model Class Initialized
DEBUG - 2011-10-03 23:19:11 --> Model Class Initialized
DEBUG - 2011-10-03 23:19:11 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-10-03 23:19:11 --> Database Driver Class Initialized
DEBUG - 2011-10-03 23:19:11 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-10-03 23:19:11 --> Helper loaded: url_helper
DEBUG - 2011-10-03 23:19:11 --> File loaded: application/views/common/header.php
DEBUG - 2011-10-03 23:19:11 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-10-03 23:19:11 --> File loaded: application/views/common/footer.php
DEBUG - 2011-10-03 23:19:11 --> File loaded: application/views/layout/main.php
DEBUG - 2011-10-03 23:19:11 --> Final output sent to browser
DEBUG - 2011-10-03 23:19:11 --> Total execution time: 0.0387

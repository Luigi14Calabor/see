<?php  if ( ! defined('BASEPATH')) exit('No direct script access allowed'); ?>

DEBUG - 2011-09-17 01:41:04 --> Config Class Initialized
DEBUG - 2011-09-17 01:41:04 --> Hooks Class Initialized
DEBUG - 2011-09-17 01:41:04 --> Utf8 Class Initialized
DEBUG - 2011-09-17 01:41:04 --> UTF-8 Support Enabled
DEBUG - 2011-09-17 01:41:04 --> URI Class Initialized
DEBUG - 2011-09-17 01:41:04 --> Router Class Initialized
DEBUG - 2011-09-17 01:41:04 --> Output Class Initialized
DEBUG - 2011-09-17 01:41:04 --> Input Class Initialized
DEBUG - 2011-09-17 01:41:04 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-17 01:41:04 --> Language Class Initialized
DEBUG - 2011-09-17 01:41:04 --> Loader Class Initialized
DEBUG - 2011-09-17 01:41:04 --> Controller Class Initialized
ERROR - 2011-09-17 01:41:04 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-09-17 01:41:04 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-09-17 01:41:04 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-09-17 01:41:04 --> Model Class Initialized
DEBUG - 2011-09-17 01:41:04 --> Model Class Initialized
DEBUG - 2011-09-17 01:41:04 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-17 01:41:04 --> Database Driver Class Initialized
DEBUG - 2011-09-17 01:41:13 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-09-17 01:41:13 --> Helper loaded: url_helper
DEBUG - 2011-09-17 01:41:13 --> File loaded: application/views/common/header.php
DEBUG - 2011-09-17 01:41:13 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-09-17 01:41:13 --> File loaded: application/views/common/footer.php
DEBUG - 2011-09-17 01:41:13 --> File loaded: application/views/layout/main.php
DEBUG - 2011-09-17 01:41:13 --> Final output sent to browser
DEBUG - 2011-09-17 01:41:13 --> Total execution time: 9.0035
DEBUG - 2011-09-17 01:41:14 --> Config Class Initialized
DEBUG - 2011-09-17 01:41:14 --> Hooks Class Initialized
DEBUG - 2011-09-17 01:41:14 --> Utf8 Class Initialized
DEBUG - 2011-09-17 01:41:14 --> UTF-8 Support Enabled
DEBUG - 2011-09-17 01:41:14 --> URI Class Initialized
DEBUG - 2011-09-17 01:41:14 --> Router Class Initialized
DEBUG - 2011-09-17 01:41:14 --> Output Class Initialized
DEBUG - 2011-09-17 01:41:14 --> Input Class Initialized
DEBUG - 2011-09-17 01:41:14 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-17 01:41:14 --> Language Class Initialized
DEBUG - 2011-09-17 01:41:14 --> Loader Class Initialized
DEBUG - 2011-09-17 01:41:14 --> Controller Class Initialized
DEBUG - 2011-09-17 01:41:14 --> Model Class Initialized
DEBUG - 2011-09-17 01:41:14 --> Model Class Initialized
DEBUG - 2011-09-17 01:41:14 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-17 01:41:14 --> Database Driver Class Initialized
DEBUG - 2011-09-17 01:41:16 --> Final output sent to browser
DEBUG - 2011-09-17 01:41:16 --> Total execution time: 1.5793
DEBUG - 2011-09-17 01:41:18 --> Config Class Initialized
DEBUG - 2011-09-17 01:41:18 --> Hooks Class Initialized
DEBUG - 2011-09-17 01:41:18 --> Utf8 Class Initialized
DEBUG - 2011-09-17 01:41:18 --> UTF-8 Support Enabled
DEBUG - 2011-09-17 01:41:18 --> URI Class Initialized
DEBUG - 2011-09-17 01:41:18 --> Router Class Initialized
ERROR - 2011-09-17 01:41:18 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-09-17 02:11:46 --> Config Class Initialized
DEBUG - 2011-09-17 02:11:46 --> Hooks Class Initialized
DEBUG - 2011-09-17 02:11:46 --> Utf8 Class Initialized
DEBUG - 2011-09-17 02:11:46 --> UTF-8 Support Enabled
DEBUG - 2011-09-17 02:11:46 --> URI Class Initialized
DEBUG - 2011-09-17 02:11:46 --> Router Class Initialized
DEBUG - 2011-09-17 02:11:46 --> Output Class Initialized
DEBUG - 2011-09-17 02:11:46 --> Input Class Initialized
DEBUG - 2011-09-17 02:11:46 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-17 02:11:46 --> Language Class Initialized
DEBUG - 2011-09-17 02:11:46 --> Loader Class Initialized
DEBUG - 2011-09-17 02:11:46 --> Controller Class Initialized
DEBUG - 2011-09-17 02:11:46 --> Model Class Initialized
DEBUG - 2011-09-17 02:11:46 --> Model Class Initialized
DEBUG - 2011-09-17 02:11:46 --> Model Class Initialized
DEBUG - 2011-09-17 02:11:46 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-17 02:11:46 --> Database Driver Class Initialized
DEBUG - 2011-09-17 02:11:49 --> File loaded: application/views/table/main.php
DEBUG - 2011-09-17 02:11:49 --> Helper loaded: url_helper
DEBUG - 2011-09-17 02:11:49 --> File loaded: application/views/common/header.php
DEBUG - 2011-09-17 02:11:49 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-09-17 02:11:49 --> File loaded: application/views/common/footer.php
DEBUG - 2011-09-17 02:11:49 --> File loaded: application/views/layout/main.php
DEBUG - 2011-09-17 02:11:49 --> Final output sent to browser
DEBUG - 2011-09-17 02:11:49 --> Total execution time: 2.6554
DEBUG - 2011-09-17 02:11:52 --> Config Class Initialized
DEBUG - 2011-09-17 02:11:52 --> Hooks Class Initialized
DEBUG - 2011-09-17 02:11:52 --> Utf8 Class Initialized
DEBUG - 2011-09-17 02:11:52 --> UTF-8 Support Enabled
DEBUG - 2011-09-17 02:11:52 --> URI Class Initialized
DEBUG - 2011-09-17 02:11:52 --> Router Class Initialized
ERROR - 2011-09-17 02:11:52 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-09-17 04:52:53 --> Config Class Initialized
DEBUG - 2011-09-17 04:52:53 --> Hooks Class Initialized
DEBUG - 2011-09-17 04:52:53 --> Utf8 Class Initialized
DEBUG - 2011-09-17 04:52:53 --> UTF-8 Support Enabled
DEBUG - 2011-09-17 04:52:53 --> URI Class Initialized
DEBUG - 2011-09-17 04:52:53 --> Router Class Initialized
ERROR - 2011-09-17 04:52:53 --> 404 Page Not Found --> robots.txt
DEBUG - 2011-09-17 04:52:54 --> Config Class Initialized
DEBUG - 2011-09-17 04:52:54 --> Hooks Class Initialized
DEBUG - 2011-09-17 04:52:54 --> Utf8 Class Initialized
DEBUG - 2011-09-17 04:52:54 --> UTF-8 Support Enabled
DEBUG - 2011-09-17 04:52:54 --> URI Class Initialized
DEBUG - 2011-09-17 04:52:54 --> Router Class Initialized
DEBUG - 2011-09-17 04:52:54 --> Output Class Initialized
DEBUG - 2011-09-17 04:52:54 --> Input Class Initialized
DEBUG - 2011-09-17 04:52:54 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-17 04:52:54 --> Language Class Initialized
DEBUG - 2011-09-17 04:52:54 --> Loader Class Initialized
DEBUG - 2011-09-17 04:52:54 --> Controller Class Initialized
DEBUG - 2011-09-17 04:52:54 --> Model Class Initialized
DEBUG - 2011-09-17 04:52:54 --> Model Class Initialized
DEBUG - 2011-09-17 04:52:54 --> Model Class Initialized
DEBUG - 2011-09-17 04:52:54 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-17 04:52:54 --> Database Driver Class Initialized
DEBUG - 2011-09-17 04:52:55 --> File loaded: application/views/table/main.php
DEBUG - 2011-09-17 04:52:55 --> Helper loaded: url_helper
DEBUG - 2011-09-17 04:52:55 --> File loaded: application/views/common/header.php
DEBUG - 2011-09-17 04:52:55 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-09-17 04:52:55 --> File loaded: application/views/common/footer.php
DEBUG - 2011-09-17 04:52:55 --> File loaded: application/views/layout/main.php
DEBUG - 2011-09-17 04:52:55 --> Final output sent to browser
DEBUG - 2011-09-17 04:52:55 --> Total execution time: 1.3734
DEBUG - 2011-09-17 05:58:41 --> Config Class Initialized
DEBUG - 2011-09-17 05:58:41 --> Hooks Class Initialized
DEBUG - 2011-09-17 05:58:41 --> Utf8 Class Initialized
DEBUG - 2011-09-17 05:58:41 --> UTF-8 Support Enabled
DEBUG - 2011-09-17 05:58:41 --> URI Class Initialized
DEBUG - 2011-09-17 05:58:41 --> Router Class Initialized
DEBUG - 2011-09-17 05:58:41 --> Output Class Initialized
DEBUG - 2011-09-17 05:58:41 --> Input Class Initialized
DEBUG - 2011-09-17 05:58:41 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-17 05:58:41 --> Language Class Initialized
DEBUG - 2011-09-17 05:58:41 --> Loader Class Initialized
DEBUG - 2011-09-17 05:58:41 --> Controller Class Initialized
ERROR - 2011-09-17 05:58:41 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-09-17 05:58:41 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-09-17 05:58:41 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-09-17 05:58:41 --> Model Class Initialized
DEBUG - 2011-09-17 05:58:41 --> Model Class Initialized
DEBUG - 2011-09-17 05:58:41 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-17 05:58:41 --> Database Driver Class Initialized
DEBUG - 2011-09-17 05:58:41 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-09-17 05:58:41 --> Helper loaded: url_helper
DEBUG - 2011-09-17 05:58:41 --> File loaded: application/views/common/header.php
DEBUG - 2011-09-17 05:58:41 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-09-17 05:58:41 --> File loaded: application/views/common/footer.php
DEBUG - 2011-09-17 05:58:41 --> File loaded: application/views/layout/main.php
DEBUG - 2011-09-17 05:58:41 --> Final output sent to browser
DEBUG - 2011-09-17 05:58:41 --> Total execution time: 0.2538
DEBUG - 2011-09-17 05:58:43 --> Config Class Initialized
DEBUG - 2011-09-17 05:58:43 --> Hooks Class Initialized
DEBUG - 2011-09-17 05:58:43 --> Utf8 Class Initialized
DEBUG - 2011-09-17 05:58:43 --> UTF-8 Support Enabled
DEBUG - 2011-09-17 05:58:43 --> URI Class Initialized
DEBUG - 2011-09-17 05:58:43 --> Router Class Initialized
DEBUG - 2011-09-17 05:58:43 --> Output Class Initialized
DEBUG - 2011-09-17 05:58:43 --> Input Class Initialized
DEBUG - 2011-09-17 05:58:43 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-17 05:58:43 --> Language Class Initialized
DEBUG - 2011-09-17 05:58:43 --> Loader Class Initialized
DEBUG - 2011-09-17 05:58:43 --> Controller Class Initialized
DEBUG - 2011-09-17 05:58:43 --> Model Class Initialized
DEBUG - 2011-09-17 05:58:43 --> Model Class Initialized
DEBUG - 2011-09-17 05:58:43 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-17 05:58:43 --> Database Driver Class Initialized
DEBUG - 2011-09-17 05:58:44 --> Final output sent to browser
DEBUG - 2011-09-17 05:58:44 --> Total execution time: 0.6991
DEBUG - 2011-09-17 05:59:02 --> Config Class Initialized
DEBUG - 2011-09-17 05:59:02 --> Hooks Class Initialized
DEBUG - 2011-09-17 05:59:02 --> Utf8 Class Initialized
DEBUG - 2011-09-17 05:59:02 --> UTF-8 Support Enabled
DEBUG - 2011-09-17 05:59:02 --> URI Class Initialized
DEBUG - 2011-09-17 05:59:02 --> Router Class Initialized
ERROR - 2011-09-17 05:59:02 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-09-17 05:59:03 --> Config Class Initialized
DEBUG - 2011-09-17 05:59:03 --> Hooks Class Initialized
DEBUG - 2011-09-17 05:59:03 --> Utf8 Class Initialized
DEBUG - 2011-09-17 05:59:03 --> UTF-8 Support Enabled
DEBUG - 2011-09-17 05:59:03 --> URI Class Initialized
DEBUG - 2011-09-17 05:59:03 --> Router Class Initialized
ERROR - 2011-09-17 05:59:03 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-09-17 06:04:46 --> Config Class Initialized
DEBUG - 2011-09-17 06:04:46 --> Hooks Class Initialized
DEBUG - 2011-09-17 06:04:46 --> Utf8 Class Initialized
DEBUG - 2011-09-17 06:04:46 --> UTF-8 Support Enabled
DEBUG - 2011-09-17 06:04:46 --> URI Class Initialized
DEBUG - 2011-09-17 06:04:46 --> Router Class Initialized
DEBUG - 2011-09-17 06:04:46 --> Output Class Initialized
DEBUG - 2011-09-17 06:04:46 --> Input Class Initialized
DEBUG - 2011-09-17 06:04:46 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-17 06:04:46 --> Language Class Initialized
DEBUG - 2011-09-17 06:04:46 --> Loader Class Initialized
DEBUG - 2011-09-17 06:04:46 --> Controller Class Initialized
ERROR - 2011-09-17 06:04:46 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-09-17 06:04:46 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-09-17 06:04:46 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-09-17 06:04:46 --> Model Class Initialized
DEBUG - 2011-09-17 06:04:46 --> Model Class Initialized
DEBUG - 2011-09-17 06:04:46 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-17 06:04:46 --> Database Driver Class Initialized
DEBUG - 2011-09-17 06:04:46 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-09-17 06:04:46 --> Helper loaded: url_helper
DEBUG - 2011-09-17 06:04:46 --> File loaded: application/views/common/header.php
DEBUG - 2011-09-17 06:04:46 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-09-17 06:04:46 --> File loaded: application/views/common/footer.php
DEBUG - 2011-09-17 06:04:46 --> File loaded: application/views/layout/main.php
DEBUG - 2011-09-17 06:04:46 --> Final output sent to browser
DEBUG - 2011-09-17 06:04:46 --> Total execution time: 0.0403
DEBUG - 2011-09-17 06:04:48 --> Config Class Initialized
DEBUG - 2011-09-17 06:04:48 --> Hooks Class Initialized
DEBUG - 2011-09-17 06:04:48 --> Utf8 Class Initialized
DEBUG - 2011-09-17 06:04:48 --> UTF-8 Support Enabled
DEBUG - 2011-09-17 06:04:48 --> URI Class Initialized
DEBUG - 2011-09-17 06:04:48 --> Router Class Initialized
DEBUG - 2011-09-17 06:04:48 --> Output Class Initialized
DEBUG - 2011-09-17 06:04:48 --> Input Class Initialized
DEBUG - 2011-09-17 06:04:48 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-17 06:04:48 --> Language Class Initialized
DEBUG - 2011-09-17 06:04:48 --> Loader Class Initialized
DEBUG - 2011-09-17 06:04:48 --> Controller Class Initialized
DEBUG - 2011-09-17 06:04:48 --> Model Class Initialized
DEBUG - 2011-09-17 06:04:48 --> Model Class Initialized
DEBUG - 2011-09-17 06:04:48 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-17 06:04:48 --> Database Driver Class Initialized
DEBUG - 2011-09-17 06:04:49 --> Final output sent to browser
DEBUG - 2011-09-17 06:04:49 --> Total execution time: 0.6153
DEBUG - 2011-09-17 06:04:53 --> Config Class Initialized
DEBUG - 2011-09-17 06:04:53 --> Hooks Class Initialized
DEBUG - 2011-09-17 06:04:53 --> Utf8 Class Initialized
DEBUG - 2011-09-17 06:04:53 --> UTF-8 Support Enabled
DEBUG - 2011-09-17 06:04:53 --> URI Class Initialized
DEBUG - 2011-09-17 06:04:53 --> Router Class Initialized
ERROR - 2011-09-17 06:04:53 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-09-17 06:08:25 --> Config Class Initialized
DEBUG - 2011-09-17 06:08:25 --> Hooks Class Initialized
DEBUG - 2011-09-17 06:08:25 --> Utf8 Class Initialized
DEBUG - 2011-09-17 06:08:25 --> UTF-8 Support Enabled
DEBUG - 2011-09-17 06:08:25 --> URI Class Initialized
DEBUG - 2011-09-17 06:08:25 --> Router Class Initialized
DEBUG - 2011-09-17 06:08:25 --> Output Class Initialized
DEBUG - 2011-09-17 06:08:25 --> Input Class Initialized
DEBUG - 2011-09-17 06:08:25 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-17 06:08:25 --> Language Class Initialized
DEBUG - 2011-09-17 06:08:25 --> Loader Class Initialized
DEBUG - 2011-09-17 06:08:25 --> Controller Class Initialized
ERROR - 2011-09-17 06:08:25 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-09-17 06:08:25 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-09-17 06:08:25 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-09-17 06:08:25 --> Model Class Initialized
DEBUG - 2011-09-17 06:08:25 --> Model Class Initialized
DEBUG - 2011-09-17 06:08:25 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-17 06:08:25 --> Database Driver Class Initialized
DEBUG - 2011-09-17 06:08:25 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-09-17 06:08:25 --> Helper loaded: url_helper
DEBUG - 2011-09-17 06:08:25 --> File loaded: application/views/common/header.php
DEBUG - 2011-09-17 06:08:25 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-09-17 06:08:25 --> File loaded: application/views/common/footer.php
DEBUG - 2011-09-17 06:08:25 --> File loaded: application/views/layout/main.php
DEBUG - 2011-09-17 06:08:25 --> Final output sent to browser
DEBUG - 2011-09-17 06:08:25 --> Total execution time: 0.0750
DEBUG - 2011-09-17 06:08:27 --> Config Class Initialized
DEBUG - 2011-09-17 06:08:27 --> Hooks Class Initialized
DEBUG - 2011-09-17 06:08:27 --> Utf8 Class Initialized
DEBUG - 2011-09-17 06:08:27 --> UTF-8 Support Enabled
DEBUG - 2011-09-17 06:08:27 --> URI Class Initialized
DEBUG - 2011-09-17 06:08:27 --> Router Class Initialized
DEBUG - 2011-09-17 06:08:27 --> Output Class Initialized
DEBUG - 2011-09-17 06:08:27 --> Input Class Initialized
DEBUG - 2011-09-17 06:08:27 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-17 06:08:27 --> Language Class Initialized
DEBUG - 2011-09-17 06:08:27 --> Loader Class Initialized
DEBUG - 2011-09-17 06:08:27 --> Controller Class Initialized
DEBUG - 2011-09-17 06:08:27 --> Model Class Initialized
DEBUG - 2011-09-17 06:08:27 --> Model Class Initialized
DEBUG - 2011-09-17 06:08:27 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-17 06:08:27 --> Database Driver Class Initialized
DEBUG - 2011-09-17 06:08:28 --> Final output sent to browser
DEBUG - 2011-09-17 06:08:28 --> Total execution time: 0.5485
DEBUG - 2011-09-17 06:08:30 --> Config Class Initialized
DEBUG - 2011-09-17 06:08:30 --> Hooks Class Initialized
DEBUG - 2011-09-17 06:08:30 --> Utf8 Class Initialized
DEBUG - 2011-09-17 06:08:30 --> UTF-8 Support Enabled
DEBUG - 2011-09-17 06:08:30 --> URI Class Initialized
DEBUG - 2011-09-17 06:08:30 --> Router Class Initialized
ERROR - 2011-09-17 06:08:30 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-09-17 06:15:18 --> Config Class Initialized
DEBUG - 2011-09-17 06:15:18 --> Hooks Class Initialized
DEBUG - 2011-09-17 06:15:18 --> Utf8 Class Initialized
DEBUG - 2011-09-17 06:15:18 --> UTF-8 Support Enabled
DEBUG - 2011-09-17 06:15:18 --> URI Class Initialized
DEBUG - 2011-09-17 06:15:18 --> Router Class Initialized
DEBUG - 2011-09-17 06:15:18 --> Output Class Initialized
DEBUG - 2011-09-17 06:15:18 --> Input Class Initialized
DEBUG - 2011-09-17 06:15:18 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-17 06:15:18 --> Language Class Initialized
DEBUG - 2011-09-17 06:15:18 --> Loader Class Initialized
DEBUG - 2011-09-17 06:15:18 --> Controller Class Initialized
DEBUG - 2011-09-17 06:15:18 --> Model Class Initialized
DEBUG - 2011-09-17 06:15:18 --> Model Class Initialized
DEBUG - 2011-09-17 06:15:18 --> Model Class Initialized
DEBUG - 2011-09-17 06:15:18 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-17 06:15:18 --> Database Driver Class Initialized
DEBUG - 2011-09-17 06:15:19 --> File loaded: application/views/table/main.php
DEBUG - 2011-09-17 06:15:19 --> Helper loaded: url_helper
DEBUG - 2011-09-17 06:15:19 --> File loaded: application/views/common/header.php
DEBUG - 2011-09-17 06:15:19 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-09-17 06:15:19 --> File loaded: application/views/common/footer.php
DEBUG - 2011-09-17 06:15:19 --> File loaded: application/views/layout/main.php
DEBUG - 2011-09-17 06:15:19 --> Final output sent to browser
DEBUG - 2011-09-17 06:15:19 --> Total execution time: 0.6600
DEBUG - 2011-09-17 06:15:20 --> Config Class Initialized
DEBUG - 2011-09-17 06:15:20 --> Hooks Class Initialized
DEBUG - 2011-09-17 06:15:20 --> Utf8 Class Initialized
DEBUG - 2011-09-17 06:15:20 --> UTF-8 Support Enabled
DEBUG - 2011-09-17 06:15:20 --> URI Class Initialized
DEBUG - 2011-09-17 06:15:20 --> Router Class Initialized
ERROR - 2011-09-17 06:15:20 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-09-17 06:15:21 --> Config Class Initialized
DEBUG - 2011-09-17 06:15:21 --> Hooks Class Initialized
DEBUG - 2011-09-17 06:15:21 --> Utf8 Class Initialized
DEBUG - 2011-09-17 06:15:21 --> UTF-8 Support Enabled
DEBUG - 2011-09-17 06:15:21 --> URI Class Initialized
DEBUG - 2011-09-17 06:15:21 --> Router Class Initialized
ERROR - 2011-09-17 06:15:21 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-09-17 06:15:21 --> Config Class Initialized
DEBUG - 2011-09-17 06:15:21 --> Hooks Class Initialized
DEBUG - 2011-09-17 06:15:21 --> Utf8 Class Initialized
DEBUG - 2011-09-17 06:15:21 --> UTF-8 Support Enabled
DEBUG - 2011-09-17 06:15:21 --> URI Class Initialized
DEBUG - 2011-09-17 06:15:21 --> Router Class Initialized
ERROR - 2011-09-17 06:15:21 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-09-17 06:17:51 --> Config Class Initialized
DEBUG - 2011-09-17 06:17:51 --> Hooks Class Initialized
DEBUG - 2011-09-17 06:17:51 --> Utf8 Class Initialized
DEBUG - 2011-09-17 06:17:51 --> UTF-8 Support Enabled
DEBUG - 2011-09-17 06:17:51 --> URI Class Initialized
DEBUG - 2011-09-17 06:17:51 --> Router Class Initialized
DEBUG - 2011-09-17 06:17:51 --> Output Class Initialized
DEBUG - 2011-09-17 06:17:51 --> Input Class Initialized
DEBUG - 2011-09-17 06:17:51 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-17 06:17:51 --> Language Class Initialized
DEBUG - 2011-09-17 06:17:51 --> Loader Class Initialized
DEBUG - 2011-09-17 06:17:51 --> Controller Class Initialized
ERROR - 2011-09-17 06:17:51 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-09-17 06:17:51 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-09-17 06:17:51 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-09-17 06:17:51 --> Model Class Initialized
DEBUG - 2011-09-17 06:17:51 --> Model Class Initialized
DEBUG - 2011-09-17 06:17:51 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-17 06:17:51 --> Database Driver Class Initialized
DEBUG - 2011-09-17 06:17:51 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-09-17 06:17:51 --> Helper loaded: url_helper
DEBUG - 2011-09-17 06:17:51 --> File loaded: application/views/common/header.php
DEBUG - 2011-09-17 06:17:51 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-09-17 06:17:51 --> File loaded: application/views/common/footer.php
DEBUG - 2011-09-17 06:17:51 --> File loaded: application/views/layout/main.php
DEBUG - 2011-09-17 06:17:51 --> Final output sent to browser
DEBUG - 2011-09-17 06:17:51 --> Total execution time: 0.0446
DEBUG - 2011-09-17 06:17:53 --> Config Class Initialized
DEBUG - 2011-09-17 06:17:53 --> Hooks Class Initialized
DEBUG - 2011-09-17 06:17:53 --> Utf8 Class Initialized
DEBUG - 2011-09-17 06:17:53 --> UTF-8 Support Enabled
DEBUG - 2011-09-17 06:17:53 --> URI Class Initialized
DEBUG - 2011-09-17 06:17:53 --> Router Class Initialized
DEBUG - 2011-09-17 06:17:53 --> Output Class Initialized
DEBUG - 2011-09-17 06:17:53 --> Input Class Initialized
DEBUG - 2011-09-17 06:17:53 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-17 06:17:53 --> Language Class Initialized
DEBUG - 2011-09-17 06:17:53 --> Loader Class Initialized
DEBUG - 2011-09-17 06:17:53 --> Controller Class Initialized
DEBUG - 2011-09-17 06:17:53 --> Model Class Initialized
DEBUG - 2011-09-17 06:17:53 --> Model Class Initialized
DEBUG - 2011-09-17 06:17:53 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-17 06:17:53 --> Database Driver Class Initialized
DEBUG - 2011-09-17 06:17:54 --> Final output sent to browser
DEBUG - 2011-09-17 06:17:54 --> Total execution time: 1.3186
DEBUG - 2011-09-17 06:18:17 --> Config Class Initialized
DEBUG - 2011-09-17 06:18:17 --> Hooks Class Initialized
DEBUG - 2011-09-17 06:18:17 --> Utf8 Class Initialized
DEBUG - 2011-09-17 06:18:17 --> UTF-8 Support Enabled
DEBUG - 2011-09-17 06:18:17 --> URI Class Initialized
DEBUG - 2011-09-17 06:18:17 --> Router Class Initialized
DEBUG - 2011-09-17 06:18:17 --> Output Class Initialized
DEBUG - 2011-09-17 06:18:17 --> Input Class Initialized
DEBUG - 2011-09-17 06:18:17 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-17 06:18:17 --> Language Class Initialized
DEBUG - 2011-09-17 06:18:17 --> Loader Class Initialized
DEBUG - 2011-09-17 06:18:17 --> Controller Class Initialized
ERROR - 2011-09-17 06:18:17 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-09-17 06:18:17 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-09-17 06:18:17 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-09-17 06:18:17 --> Model Class Initialized
DEBUG - 2011-09-17 06:18:17 --> Model Class Initialized
DEBUG - 2011-09-17 06:18:17 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-17 06:18:17 --> Database Driver Class Initialized
DEBUG - 2011-09-17 06:18:17 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-09-17 06:18:17 --> Helper loaded: url_helper
DEBUG - 2011-09-17 06:18:17 --> File loaded: application/views/common/header.php
DEBUG - 2011-09-17 06:18:17 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-09-17 06:18:17 --> File loaded: application/views/common/footer.php
DEBUG - 2011-09-17 06:18:17 --> File loaded: application/views/layout/main.php
DEBUG - 2011-09-17 06:18:17 --> Final output sent to browser
DEBUG - 2011-09-17 06:18:17 --> Total execution time: 0.0295
DEBUG - 2011-09-17 06:18:22 --> Config Class Initialized
DEBUG - 2011-09-17 06:18:22 --> Hooks Class Initialized
DEBUG - 2011-09-17 06:18:22 --> Utf8 Class Initialized
DEBUG - 2011-09-17 06:18:22 --> UTF-8 Support Enabled
DEBUG - 2011-09-17 06:18:22 --> URI Class Initialized
DEBUG - 2011-09-17 06:18:22 --> Router Class Initialized
DEBUG - 2011-09-17 06:18:22 --> Output Class Initialized
DEBUG - 2011-09-17 06:18:22 --> Input Class Initialized
DEBUG - 2011-09-17 06:18:22 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-17 06:18:22 --> Language Class Initialized
DEBUG - 2011-09-17 06:18:22 --> Loader Class Initialized
DEBUG - 2011-09-17 06:18:22 --> Controller Class Initialized
DEBUG - 2011-09-17 06:18:22 --> Model Class Initialized
DEBUG - 2011-09-17 06:18:22 --> Model Class Initialized
DEBUG - 2011-09-17 06:18:22 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-17 06:18:22 --> Database Driver Class Initialized
DEBUG - 2011-09-17 06:18:23 --> Final output sent to browser
DEBUG - 2011-09-17 06:18:23 --> Total execution time: 0.4995
DEBUG - 2011-09-17 06:22:26 --> Config Class Initialized
DEBUG - 2011-09-17 06:22:26 --> Hooks Class Initialized
DEBUG - 2011-09-17 06:22:26 --> Utf8 Class Initialized
DEBUG - 2011-09-17 06:22:26 --> UTF-8 Support Enabled
DEBUG - 2011-09-17 06:22:26 --> URI Class Initialized
DEBUG - 2011-09-17 06:22:26 --> Router Class Initialized
DEBUG - 2011-09-17 06:22:26 --> Output Class Initialized
DEBUG - 2011-09-17 06:22:26 --> Input Class Initialized
DEBUG - 2011-09-17 06:22:26 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-17 06:22:26 --> Language Class Initialized
DEBUG - 2011-09-17 06:22:26 --> Loader Class Initialized
DEBUG - 2011-09-17 06:22:26 --> Controller Class Initialized
ERROR - 2011-09-17 06:22:26 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-09-17 06:22:26 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-09-17 06:22:26 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-09-17 06:22:26 --> Model Class Initialized
DEBUG - 2011-09-17 06:22:26 --> Model Class Initialized
DEBUG - 2011-09-17 06:22:26 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-17 06:22:26 --> Database Driver Class Initialized
DEBUG - 2011-09-17 06:22:26 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-09-17 06:22:26 --> Helper loaded: url_helper
DEBUG - 2011-09-17 06:22:26 --> File loaded: application/views/common/header.php
DEBUG - 2011-09-17 06:22:26 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-09-17 06:22:26 --> File loaded: application/views/common/footer.php
DEBUG - 2011-09-17 06:22:26 --> File loaded: application/views/layout/main.php
DEBUG - 2011-09-17 06:22:26 --> Final output sent to browser
DEBUG - 2011-09-17 06:22:26 --> Total execution time: 0.0302
DEBUG - 2011-09-17 06:22:26 --> Config Class Initialized
DEBUG - 2011-09-17 06:22:26 --> Hooks Class Initialized
DEBUG - 2011-09-17 06:22:26 --> Utf8 Class Initialized
DEBUG - 2011-09-17 06:22:26 --> UTF-8 Support Enabled
DEBUG - 2011-09-17 06:22:26 --> URI Class Initialized
DEBUG - 2011-09-17 06:22:26 --> Router Class Initialized
DEBUG - 2011-09-17 06:22:26 --> Output Class Initialized
DEBUG - 2011-09-17 06:22:26 --> Input Class Initialized
DEBUG - 2011-09-17 06:22:26 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-17 06:22:26 --> Language Class Initialized
DEBUG - 2011-09-17 06:22:26 --> Loader Class Initialized
DEBUG - 2011-09-17 06:22:26 --> Controller Class Initialized
DEBUG - 2011-09-17 06:22:26 --> Model Class Initialized
DEBUG - 2011-09-17 06:22:26 --> Model Class Initialized
DEBUG - 2011-09-17 06:22:26 --> Model Class Initialized
DEBUG - 2011-09-17 06:22:26 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-17 06:22:26 --> Database Driver Class Initialized
DEBUG - 2011-09-17 06:22:26 --> File loaded: application/views/table/main.php
DEBUG - 2011-09-17 06:22:26 --> Helper loaded: url_helper
DEBUG - 2011-09-17 06:22:26 --> File loaded: application/views/common/header.php
DEBUG - 2011-09-17 06:22:26 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-09-17 06:22:26 --> File loaded: application/views/common/footer.php
DEBUG - 2011-09-17 06:22:26 --> File loaded: application/views/layout/main.php
DEBUG - 2011-09-17 06:22:26 --> Final output sent to browser
DEBUG - 2011-09-17 06:22:26 --> Total execution time: 0.0496
DEBUG - 2011-09-17 06:26:18 --> Config Class Initialized
DEBUG - 2011-09-17 06:26:18 --> Hooks Class Initialized
DEBUG - 2011-09-17 06:26:18 --> Utf8 Class Initialized
DEBUG - 2011-09-17 06:26:18 --> UTF-8 Support Enabled
DEBUG - 2011-09-17 06:26:18 --> URI Class Initialized
DEBUG - 2011-09-17 06:26:18 --> Router Class Initialized
DEBUG - 2011-09-17 06:26:18 --> Output Class Initialized
DEBUG - 2011-09-17 06:26:18 --> Input Class Initialized
DEBUG - 2011-09-17 06:26:18 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-17 06:26:18 --> Language Class Initialized
DEBUG - 2011-09-17 06:26:18 --> Loader Class Initialized
DEBUG - 2011-09-17 06:26:18 --> Controller Class Initialized
DEBUG - 2011-09-17 06:26:18 --> Model Class Initialized
DEBUG - 2011-09-17 06:26:18 --> Model Class Initialized
DEBUG - 2011-09-17 06:26:18 --> Model Class Initialized
DEBUG - 2011-09-17 06:26:18 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-17 06:26:18 --> Database Driver Class Initialized
DEBUG - 2011-09-17 06:26:18 --> File loaded: application/views/table/main.php
DEBUG - 2011-09-17 06:26:18 --> Helper loaded: url_helper
DEBUG - 2011-09-17 06:26:18 --> File loaded: application/views/common/header.php
DEBUG - 2011-09-17 06:26:18 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-09-17 06:26:18 --> File loaded: application/views/common/footer.php
DEBUG - 2011-09-17 06:26:18 --> File loaded: application/views/layout/main.php
DEBUG - 2011-09-17 06:26:18 --> Final output sent to browser
DEBUG - 2011-09-17 06:26:18 --> Total execution time: 0.0511
DEBUG - 2011-09-17 06:26:21 --> Config Class Initialized
DEBUG - 2011-09-17 06:26:21 --> Hooks Class Initialized
DEBUG - 2011-09-17 06:26:21 --> Utf8 Class Initialized
DEBUG - 2011-09-17 06:26:21 --> UTF-8 Support Enabled
DEBUG - 2011-09-17 06:26:21 --> URI Class Initialized
DEBUG - 2011-09-17 06:26:21 --> Router Class Initialized
ERROR - 2011-09-17 06:26:21 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-09-17 06:26:21 --> Config Class Initialized
DEBUG - 2011-09-17 06:26:21 --> Hooks Class Initialized
DEBUG - 2011-09-17 06:26:21 --> Utf8 Class Initialized
DEBUG - 2011-09-17 06:26:21 --> UTF-8 Support Enabled
DEBUG - 2011-09-17 06:26:21 --> URI Class Initialized
DEBUG - 2011-09-17 06:26:21 --> Router Class Initialized
ERROR - 2011-09-17 06:26:21 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-09-17 06:26:27 --> Config Class Initialized
DEBUG - 2011-09-17 06:26:27 --> Hooks Class Initialized
DEBUG - 2011-09-17 06:26:27 --> Utf8 Class Initialized
DEBUG - 2011-09-17 06:26:27 --> UTF-8 Support Enabled
DEBUG - 2011-09-17 06:26:27 --> URI Class Initialized
DEBUG - 2011-09-17 06:26:27 --> Router Class Initialized
DEBUG - 2011-09-17 06:26:27 --> Output Class Initialized
DEBUG - 2011-09-17 06:26:27 --> Input Class Initialized
DEBUG - 2011-09-17 06:26:27 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-17 06:26:27 --> Language Class Initialized
DEBUG - 2011-09-17 06:26:27 --> Loader Class Initialized
DEBUG - 2011-09-17 06:26:27 --> Controller Class Initialized
ERROR - 2011-09-17 06:26:27 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-09-17 06:26:27 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-09-17 06:26:27 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-09-17 06:26:27 --> Model Class Initialized
DEBUG - 2011-09-17 06:26:27 --> Model Class Initialized
DEBUG - 2011-09-17 06:26:27 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-17 06:26:27 --> Database Driver Class Initialized
DEBUG - 2011-09-17 06:26:27 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-09-17 06:26:27 --> Helper loaded: url_helper
DEBUG - 2011-09-17 06:26:27 --> File loaded: application/views/common/header.php
DEBUG - 2011-09-17 06:26:27 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-09-17 06:26:27 --> File loaded: application/views/common/footer.php
DEBUG - 2011-09-17 06:26:27 --> File loaded: application/views/layout/main.php
DEBUG - 2011-09-17 06:26:27 --> Final output sent to browser
DEBUG - 2011-09-17 06:26:27 --> Total execution time: 0.0294
DEBUG - 2011-09-17 06:26:27 --> Config Class Initialized
DEBUG - 2011-09-17 06:26:27 --> Hooks Class Initialized
DEBUG - 2011-09-17 06:26:27 --> Utf8 Class Initialized
DEBUG - 2011-09-17 06:26:27 --> UTF-8 Support Enabled
DEBUG - 2011-09-17 06:26:27 --> URI Class Initialized
DEBUG - 2011-09-17 06:26:27 --> Router Class Initialized
DEBUG - 2011-09-17 06:26:27 --> Output Class Initialized
DEBUG - 2011-09-17 06:26:27 --> Input Class Initialized
DEBUG - 2011-09-17 06:26:27 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-17 06:26:27 --> Language Class Initialized
DEBUG - 2011-09-17 06:26:27 --> Loader Class Initialized
DEBUG - 2011-09-17 06:26:27 --> Controller Class Initialized
ERROR - 2011-09-17 06:26:27 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-09-17 06:26:27 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-09-17 06:26:27 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-09-17 06:26:27 --> Model Class Initialized
DEBUG - 2011-09-17 06:26:27 --> Model Class Initialized
DEBUG - 2011-09-17 06:26:27 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-17 06:26:27 --> Database Driver Class Initialized
DEBUG - 2011-09-17 06:26:27 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-09-17 06:26:27 --> Helper loaded: url_helper
DEBUG - 2011-09-17 06:26:27 --> File loaded: application/views/common/header.php
DEBUG - 2011-09-17 06:26:27 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-09-17 06:26:27 --> File loaded: application/views/common/footer.php
DEBUG - 2011-09-17 06:26:27 --> File loaded: application/views/layout/main.php
DEBUG - 2011-09-17 06:26:27 --> Final output sent to browser
DEBUG - 2011-09-17 06:26:27 --> Total execution time: 0.0320
DEBUG - 2011-09-17 06:26:28 --> Config Class Initialized
DEBUG - 2011-09-17 06:26:28 --> Hooks Class Initialized
DEBUG - 2011-09-17 06:26:28 --> Utf8 Class Initialized
DEBUG - 2011-09-17 06:26:28 --> UTF-8 Support Enabled
DEBUG - 2011-09-17 06:26:28 --> URI Class Initialized
DEBUG - 2011-09-17 06:26:28 --> Router Class Initialized
DEBUG - 2011-09-17 06:26:28 --> Output Class Initialized
DEBUG - 2011-09-17 06:26:28 --> Input Class Initialized
DEBUG - 2011-09-17 06:26:28 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-17 06:26:28 --> Language Class Initialized
DEBUG - 2011-09-17 06:26:28 --> Loader Class Initialized
DEBUG - 2011-09-17 06:26:28 --> Controller Class Initialized
DEBUG - 2011-09-17 06:26:28 --> Model Class Initialized
DEBUG - 2011-09-17 06:26:28 --> Model Class Initialized
DEBUG - 2011-09-17 06:26:28 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-17 06:26:28 --> Database Driver Class Initialized
DEBUG - 2011-09-17 06:26:29 --> Final output sent to browser
DEBUG - 2011-09-17 06:26:29 --> Total execution time: 0.4891
DEBUG - 2011-09-17 06:28:56 --> Config Class Initialized
DEBUG - 2011-09-17 06:28:56 --> Hooks Class Initialized
DEBUG - 2011-09-17 06:28:56 --> Utf8 Class Initialized
DEBUG - 2011-09-17 06:28:56 --> UTF-8 Support Enabled
DEBUG - 2011-09-17 06:28:56 --> URI Class Initialized
DEBUG - 2011-09-17 06:28:56 --> Router Class Initialized
DEBUG - 2011-09-17 06:28:56 --> Output Class Initialized
DEBUG - 2011-09-17 06:28:56 --> Input Class Initialized
DEBUG - 2011-09-17 06:28:56 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-17 06:28:56 --> Language Class Initialized
DEBUG - 2011-09-17 06:28:56 --> Loader Class Initialized
DEBUG - 2011-09-17 06:28:56 --> Controller Class Initialized
DEBUG - 2011-09-17 06:28:56 --> Model Class Initialized
DEBUG - 2011-09-17 06:28:56 --> Model Class Initialized
DEBUG - 2011-09-17 06:28:56 --> Model Class Initialized
DEBUG - 2011-09-17 06:28:56 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-17 06:28:56 --> Database Driver Class Initialized
DEBUG - 2011-09-17 06:28:56 --> File loaded: application/views/table/main.php
DEBUG - 2011-09-17 06:28:56 --> Helper loaded: url_helper
DEBUG - 2011-09-17 06:28:56 --> File loaded: application/views/common/header.php
DEBUG - 2011-09-17 06:28:56 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-09-17 06:28:56 --> File loaded: application/views/common/footer.php
DEBUG - 2011-09-17 06:28:56 --> File loaded: application/views/layout/main.php
DEBUG - 2011-09-17 06:28:56 --> Final output sent to browser
DEBUG - 2011-09-17 06:28:56 --> Total execution time: 0.0498
DEBUG - 2011-09-17 06:29:17 --> Config Class Initialized
DEBUG - 2011-09-17 06:29:17 --> Hooks Class Initialized
DEBUG - 2011-09-17 06:29:17 --> Utf8 Class Initialized
DEBUG - 2011-09-17 06:29:17 --> UTF-8 Support Enabled
DEBUG - 2011-09-17 06:29:17 --> URI Class Initialized
DEBUG - 2011-09-17 06:29:17 --> Router Class Initialized
DEBUG - 2011-09-17 06:29:17 --> Output Class Initialized
DEBUG - 2011-09-17 06:29:17 --> Input Class Initialized
DEBUG - 2011-09-17 06:29:17 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-17 06:29:17 --> Language Class Initialized
DEBUG - 2011-09-17 06:29:17 --> Loader Class Initialized
DEBUG - 2011-09-17 06:29:17 --> Controller Class Initialized
ERROR - 2011-09-17 06:29:17 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-09-17 06:29:17 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-09-17 06:29:17 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-09-17 06:29:17 --> Model Class Initialized
DEBUG - 2011-09-17 06:29:17 --> Model Class Initialized
DEBUG - 2011-09-17 06:29:17 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-17 06:29:17 --> Database Driver Class Initialized
DEBUG - 2011-09-17 06:29:17 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-09-17 06:29:17 --> Helper loaded: url_helper
DEBUG - 2011-09-17 06:29:17 --> File loaded: application/views/common/header.php
DEBUG - 2011-09-17 06:29:17 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-09-17 06:29:17 --> File loaded: application/views/common/footer.php
DEBUG - 2011-09-17 06:29:17 --> File loaded: application/views/layout/main.php
DEBUG - 2011-09-17 06:29:17 --> Final output sent to browser
DEBUG - 2011-09-17 06:29:17 --> Total execution time: 0.0801
DEBUG - 2011-09-17 06:29:17 --> Config Class Initialized
DEBUG - 2011-09-17 06:29:17 --> Hooks Class Initialized
DEBUG - 2011-09-17 06:29:17 --> Utf8 Class Initialized
DEBUG - 2011-09-17 06:29:17 --> UTF-8 Support Enabled
DEBUG - 2011-09-17 06:29:17 --> URI Class Initialized
DEBUG - 2011-09-17 06:29:17 --> Router Class Initialized
ERROR - 2011-09-17 06:29:17 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-09-17 06:29:17 --> Config Class Initialized
DEBUG - 2011-09-17 06:29:17 --> Hooks Class Initialized
DEBUG - 2011-09-17 06:29:17 --> Utf8 Class Initialized
DEBUG - 2011-09-17 06:29:17 --> UTF-8 Support Enabled
DEBUG - 2011-09-17 06:29:17 --> URI Class Initialized
DEBUG - 2011-09-17 06:29:17 --> Router Class Initialized
DEBUG - 2011-09-17 06:29:17 --> Output Class Initialized
DEBUG - 2011-09-17 06:29:17 --> Input Class Initialized
DEBUG - 2011-09-17 06:29:17 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-17 06:29:17 --> Language Class Initialized
DEBUG - 2011-09-17 06:29:17 --> Loader Class Initialized
DEBUG - 2011-09-17 06:29:17 --> Controller Class Initialized
DEBUG - 2011-09-17 06:29:17 --> Model Class Initialized
DEBUG - 2011-09-17 06:29:17 --> Model Class Initialized
DEBUG - 2011-09-17 06:29:17 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-17 06:29:17 --> Database Driver Class Initialized
DEBUG - 2011-09-17 06:29:18 --> Final output sent to browser
DEBUG - 2011-09-17 06:29:18 --> Total execution time: 0.5360
DEBUG - 2011-09-17 06:29:19 --> Config Class Initialized
DEBUG - 2011-09-17 06:29:19 --> Hooks Class Initialized
DEBUG - 2011-09-17 06:29:19 --> Utf8 Class Initialized
DEBUG - 2011-09-17 06:29:19 --> UTF-8 Support Enabled
DEBUG - 2011-09-17 06:29:19 --> URI Class Initialized
DEBUG - 2011-09-17 06:29:19 --> Router Class Initialized
DEBUG - 2011-09-17 06:29:19 --> Output Class Initialized
DEBUG - 2011-09-17 06:29:19 --> Input Class Initialized
DEBUG - 2011-09-17 06:29:19 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-17 06:29:19 --> Language Class Initialized
DEBUG - 2011-09-17 06:29:19 --> Loader Class Initialized
DEBUG - 2011-09-17 06:29:19 --> Controller Class Initialized
DEBUG - 2011-09-17 06:29:19 --> Model Class Initialized
DEBUG - 2011-09-17 06:29:19 --> Model Class Initialized
DEBUG - 2011-09-17 06:29:19 --> Model Class Initialized
DEBUG - 2011-09-17 06:29:19 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-17 06:29:19 --> Database Driver Class Initialized
DEBUG - 2011-09-17 06:29:19 --> File loaded: application/views/table/main.php
DEBUG - 2011-09-17 06:29:19 --> Helper loaded: url_helper
DEBUG - 2011-09-17 06:29:19 --> File loaded: application/views/common/header.php
DEBUG - 2011-09-17 06:29:19 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-09-17 06:29:19 --> File loaded: application/views/common/footer.php
DEBUG - 2011-09-17 06:29:19 --> File loaded: application/views/layout/main.php
DEBUG - 2011-09-17 06:29:19 --> Final output sent to browser
DEBUG - 2011-09-17 06:29:19 --> Total execution time: 0.0523
DEBUG - 2011-09-17 06:29:29 --> Config Class Initialized
DEBUG - 2011-09-17 06:29:29 --> Hooks Class Initialized
DEBUG - 2011-09-17 06:29:29 --> Utf8 Class Initialized
DEBUG - 2011-09-17 06:29:29 --> UTF-8 Support Enabled
DEBUG - 2011-09-17 06:29:29 --> URI Class Initialized
DEBUG - 2011-09-17 06:29:29 --> Router Class Initialized
DEBUG - 2011-09-17 06:29:29 --> Output Class Initialized
DEBUG - 2011-09-17 06:29:29 --> Input Class Initialized
DEBUG - 2011-09-17 06:29:29 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-17 06:29:29 --> Language Class Initialized
DEBUG - 2011-09-17 06:29:29 --> Loader Class Initialized
DEBUG - 2011-09-17 06:29:29 --> Controller Class Initialized
ERROR - 2011-09-17 06:29:29 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-09-17 06:29:29 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-09-17 06:29:29 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-09-17 06:29:29 --> Model Class Initialized
DEBUG - 2011-09-17 06:29:29 --> Model Class Initialized
DEBUG - 2011-09-17 06:29:29 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-17 06:29:29 --> Database Driver Class Initialized
DEBUG - 2011-09-17 06:29:29 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-09-17 06:29:29 --> Helper loaded: url_helper
DEBUG - 2011-09-17 06:29:29 --> File loaded: application/views/common/header.php
DEBUG - 2011-09-17 06:29:29 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-09-17 06:29:29 --> File loaded: application/views/common/footer.php
DEBUG - 2011-09-17 06:29:29 --> File loaded: application/views/layout/main.php
DEBUG - 2011-09-17 06:29:29 --> Final output sent to browser
DEBUG - 2011-09-17 06:29:29 --> Total execution time: 0.0285
DEBUG - 2011-09-17 06:29:30 --> Config Class Initialized
DEBUG - 2011-09-17 06:29:30 --> Hooks Class Initialized
DEBUG - 2011-09-17 06:29:30 --> Utf8 Class Initialized
DEBUG - 2011-09-17 06:29:30 --> UTF-8 Support Enabled
DEBUG - 2011-09-17 06:29:30 --> URI Class Initialized
DEBUG - 2011-09-17 06:29:30 --> Router Class Initialized
DEBUG - 2011-09-17 06:29:30 --> Output Class Initialized
DEBUG - 2011-09-17 06:29:30 --> Input Class Initialized
DEBUG - 2011-09-17 06:29:30 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-17 06:29:30 --> Language Class Initialized
DEBUG - 2011-09-17 06:29:30 --> Loader Class Initialized
DEBUG - 2011-09-17 06:29:30 --> Controller Class Initialized
DEBUG - 2011-09-17 06:29:30 --> Model Class Initialized
DEBUG - 2011-09-17 06:29:30 --> Model Class Initialized
DEBUG - 2011-09-17 06:29:30 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-17 06:29:30 --> Database Driver Class Initialized
DEBUG - 2011-09-17 06:29:31 --> Final output sent to browser
DEBUG - 2011-09-17 06:29:31 --> Total execution time: 0.7410
DEBUG - 2011-09-17 06:29:42 --> Config Class Initialized
DEBUG - 2011-09-17 06:29:42 --> Hooks Class Initialized
DEBUG - 2011-09-17 06:29:42 --> Utf8 Class Initialized
DEBUG - 2011-09-17 06:29:42 --> UTF-8 Support Enabled
DEBUG - 2011-09-17 06:29:42 --> URI Class Initialized
DEBUG - 2011-09-17 06:29:42 --> Router Class Initialized
DEBUG - 2011-09-17 06:29:42 --> Output Class Initialized
DEBUG - 2011-09-17 06:29:42 --> Input Class Initialized
DEBUG - 2011-09-17 06:29:42 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-17 06:29:42 --> Language Class Initialized
DEBUG - 2011-09-17 06:29:42 --> Loader Class Initialized
DEBUG - 2011-09-17 06:29:42 --> Controller Class Initialized
ERROR - 2011-09-17 06:29:42 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-09-17 06:29:42 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-09-17 06:29:42 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-09-17 06:29:42 --> Model Class Initialized
DEBUG - 2011-09-17 06:29:42 --> Model Class Initialized
DEBUG - 2011-09-17 06:29:42 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-17 06:29:42 --> Database Driver Class Initialized
DEBUG - 2011-09-17 06:29:42 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-09-17 06:29:42 --> Helper loaded: url_helper
DEBUG - 2011-09-17 06:29:42 --> File loaded: application/views/common/header.php
DEBUG - 2011-09-17 06:29:42 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-09-17 06:29:42 --> File loaded: application/views/common/footer.php
DEBUG - 2011-09-17 06:29:42 --> File loaded: application/views/layout/main.php
DEBUG - 2011-09-17 06:29:42 --> Final output sent to browser
DEBUG - 2011-09-17 06:29:42 --> Total execution time: 0.0329
DEBUG - 2011-09-17 06:29:43 --> Config Class Initialized
DEBUG - 2011-09-17 06:29:43 --> Hooks Class Initialized
DEBUG - 2011-09-17 06:29:43 --> Utf8 Class Initialized
DEBUG - 2011-09-17 06:29:43 --> UTF-8 Support Enabled
DEBUG - 2011-09-17 06:29:43 --> URI Class Initialized
DEBUG - 2011-09-17 06:29:43 --> Router Class Initialized
DEBUG - 2011-09-17 06:29:43 --> Output Class Initialized
DEBUG - 2011-09-17 06:29:43 --> Input Class Initialized
DEBUG - 2011-09-17 06:29:43 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-17 06:29:43 --> Language Class Initialized
DEBUG - 2011-09-17 06:29:43 --> Loader Class Initialized
DEBUG - 2011-09-17 06:29:43 --> Controller Class Initialized
DEBUG - 2011-09-17 06:29:43 --> Model Class Initialized
DEBUG - 2011-09-17 06:29:43 --> Model Class Initialized
DEBUG - 2011-09-17 06:29:43 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-17 06:29:43 --> Database Driver Class Initialized
DEBUG - 2011-09-17 06:29:44 --> Final output sent to browser
DEBUG - 2011-09-17 06:29:44 --> Total execution time: 1.0447
DEBUG - 2011-09-17 06:30:00 --> Config Class Initialized
DEBUG - 2011-09-17 06:30:00 --> Hooks Class Initialized
DEBUG - 2011-09-17 06:30:00 --> Utf8 Class Initialized
DEBUG - 2011-09-17 06:30:00 --> UTF-8 Support Enabled
DEBUG - 2011-09-17 06:30:00 --> URI Class Initialized
DEBUG - 2011-09-17 06:30:00 --> Router Class Initialized
DEBUG - 2011-09-17 06:30:00 --> Output Class Initialized
DEBUG - 2011-09-17 06:30:00 --> Input Class Initialized
DEBUG - 2011-09-17 06:30:00 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-17 06:30:00 --> Language Class Initialized
DEBUG - 2011-09-17 06:30:00 --> Loader Class Initialized
DEBUG - 2011-09-17 06:30:00 --> Controller Class Initialized
ERROR - 2011-09-17 06:30:00 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-09-17 06:30:00 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-09-17 06:30:00 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-09-17 06:30:00 --> Model Class Initialized
DEBUG - 2011-09-17 06:30:00 --> Model Class Initialized
DEBUG - 2011-09-17 06:30:00 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-17 06:30:00 --> Database Driver Class Initialized
DEBUG - 2011-09-17 06:30:00 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-09-17 06:30:00 --> Helper loaded: url_helper
DEBUG - 2011-09-17 06:30:00 --> File loaded: application/views/common/header.php
DEBUG - 2011-09-17 06:30:00 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-09-17 06:30:00 --> File loaded: application/views/common/footer.php
DEBUG - 2011-09-17 06:30:00 --> File loaded: application/views/layout/main.php
DEBUG - 2011-09-17 06:30:00 --> Final output sent to browser
DEBUG - 2011-09-17 06:30:00 --> Total execution time: 0.0294
DEBUG - 2011-09-17 06:30:01 --> Config Class Initialized
DEBUG - 2011-09-17 06:30:01 --> Hooks Class Initialized
DEBUG - 2011-09-17 06:30:01 --> Utf8 Class Initialized
DEBUG - 2011-09-17 06:30:01 --> UTF-8 Support Enabled
DEBUG - 2011-09-17 06:30:01 --> URI Class Initialized
DEBUG - 2011-09-17 06:30:01 --> Router Class Initialized
DEBUG - 2011-09-17 06:30:01 --> Output Class Initialized
DEBUG - 2011-09-17 06:30:01 --> Input Class Initialized
DEBUG - 2011-09-17 06:30:01 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-17 06:30:01 --> Language Class Initialized
DEBUG - 2011-09-17 06:30:01 --> Loader Class Initialized
DEBUG - 2011-09-17 06:30:01 --> Controller Class Initialized
DEBUG - 2011-09-17 06:30:01 --> Model Class Initialized
DEBUG - 2011-09-17 06:30:01 --> Model Class Initialized
DEBUG - 2011-09-17 06:30:01 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-17 06:30:01 --> Database Driver Class Initialized
DEBUG - 2011-09-17 06:30:02 --> Final output sent to browser
DEBUG - 2011-09-17 06:30:02 --> Total execution time: 1.0496
DEBUG - 2011-09-17 06:30:18 --> Config Class Initialized
DEBUG - 2011-09-17 06:30:18 --> Hooks Class Initialized
DEBUG - 2011-09-17 06:30:18 --> Utf8 Class Initialized
DEBUG - 2011-09-17 06:30:18 --> UTF-8 Support Enabled
DEBUG - 2011-09-17 06:30:18 --> URI Class Initialized
DEBUG - 2011-09-17 06:30:18 --> Router Class Initialized
DEBUG - 2011-09-17 06:30:18 --> No URI present. Default controller set.
DEBUG - 2011-09-17 06:30:18 --> Output Class Initialized
DEBUG - 2011-09-17 06:30:18 --> Input Class Initialized
DEBUG - 2011-09-17 06:30:18 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-17 06:30:18 --> Language Class Initialized
DEBUG - 2011-09-17 06:30:18 --> Loader Class Initialized
DEBUG - 2011-09-17 06:30:18 --> Controller Class Initialized
DEBUG - 2011-09-17 06:30:18 --> File loaded: application/views/splash/main.php
DEBUG - 2011-09-17 06:30:18 --> Helper loaded: url_helper
DEBUG - 2011-09-17 06:30:18 --> File loaded: application/views/common/header.php
DEBUG - 2011-09-17 06:30:18 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-09-17 06:30:18 --> File loaded: application/views/common/footer.php
DEBUG - 2011-09-17 06:30:18 --> File loaded: application/views/layout/main.php
DEBUG - 2011-09-17 06:30:18 --> Final output sent to browser
DEBUG - 2011-09-17 06:30:18 --> Total execution time: 0.1594
DEBUG - 2011-09-17 06:31:11 --> Config Class Initialized
DEBUG - 2011-09-17 06:31:11 --> Hooks Class Initialized
DEBUG - 2011-09-17 06:31:11 --> Utf8 Class Initialized
DEBUG - 2011-09-17 06:31:11 --> UTF-8 Support Enabled
DEBUG - 2011-09-17 06:31:11 --> URI Class Initialized
DEBUG - 2011-09-17 06:31:11 --> Router Class Initialized
DEBUG - 2011-09-17 06:31:11 --> Output Class Initialized
DEBUG - 2011-09-17 06:31:11 --> Input Class Initialized
DEBUG - 2011-09-17 06:31:11 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-17 06:31:11 --> Language Class Initialized
DEBUG - 2011-09-17 06:31:11 --> Loader Class Initialized
DEBUG - 2011-09-17 06:31:11 --> Controller Class Initialized
DEBUG - 2011-09-17 06:31:11 --> Model Class Initialized
DEBUG - 2011-09-17 06:31:11 --> Model Class Initialized
DEBUG - 2011-09-17 06:31:11 --> Model Class Initialized
DEBUG - 2011-09-17 06:31:11 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-17 06:31:11 --> Database Driver Class Initialized
DEBUG - 2011-09-17 06:31:11 --> File loaded: application/views/table/main.php
DEBUG - 2011-09-17 06:31:11 --> Helper loaded: url_helper
DEBUG - 2011-09-17 06:31:11 --> File loaded: application/views/common/header.php
DEBUG - 2011-09-17 06:31:11 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-09-17 06:31:11 --> File loaded: application/views/common/footer.php
DEBUG - 2011-09-17 06:31:11 --> File loaded: application/views/layout/main.php
DEBUG - 2011-09-17 06:31:11 --> Final output sent to browser
DEBUG - 2011-09-17 06:31:11 --> Total execution time: 0.0695
DEBUG - 2011-09-17 06:33:06 --> Config Class Initialized
DEBUG - 2011-09-17 06:33:06 --> Hooks Class Initialized
DEBUG - 2011-09-17 06:33:06 --> Utf8 Class Initialized
DEBUG - 2011-09-17 06:33:06 --> UTF-8 Support Enabled
DEBUG - 2011-09-17 06:33:06 --> URI Class Initialized
DEBUG - 2011-09-17 06:33:06 --> Router Class Initialized
DEBUG - 2011-09-17 06:33:06 --> Output Class Initialized
DEBUG - 2011-09-17 06:33:06 --> Input Class Initialized
DEBUG - 2011-09-17 06:33:06 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-17 06:33:06 --> Language Class Initialized
DEBUG - 2011-09-17 06:33:06 --> Loader Class Initialized
DEBUG - 2011-09-17 06:33:06 --> Controller Class Initialized
ERROR - 2011-09-17 06:33:06 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-09-17 06:33:06 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-09-17 06:33:06 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-09-17 06:33:06 --> Model Class Initialized
DEBUG - 2011-09-17 06:33:06 --> Model Class Initialized
DEBUG - 2011-09-17 06:33:06 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-17 06:33:06 --> Database Driver Class Initialized
DEBUG - 2011-09-17 06:33:06 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-09-17 06:33:06 --> Helper loaded: url_helper
DEBUG - 2011-09-17 06:33:06 --> File loaded: application/views/common/header.php
DEBUG - 2011-09-17 06:33:06 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-09-17 06:33:06 --> File loaded: application/views/common/footer.php
DEBUG - 2011-09-17 06:33:06 --> File loaded: application/views/layout/main.php
DEBUG - 2011-09-17 06:33:06 --> Final output sent to browser
DEBUG - 2011-09-17 06:33:06 --> Total execution time: 0.0271
DEBUG - 2011-09-17 06:33:08 --> Config Class Initialized
DEBUG - 2011-09-17 06:33:08 --> Hooks Class Initialized
DEBUG - 2011-09-17 06:33:08 --> Utf8 Class Initialized
DEBUG - 2011-09-17 06:33:08 --> UTF-8 Support Enabled
DEBUG - 2011-09-17 06:33:08 --> URI Class Initialized
DEBUG - 2011-09-17 06:33:08 --> Router Class Initialized
DEBUG - 2011-09-17 06:33:08 --> Output Class Initialized
DEBUG - 2011-09-17 06:33:08 --> Input Class Initialized
DEBUG - 2011-09-17 06:33:08 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-17 06:33:08 --> Language Class Initialized
DEBUG - 2011-09-17 06:33:08 --> Loader Class Initialized
DEBUG - 2011-09-17 06:33:08 --> Controller Class Initialized
DEBUG - 2011-09-17 06:33:08 --> Model Class Initialized
DEBUG - 2011-09-17 06:33:08 --> Model Class Initialized
DEBUG - 2011-09-17 06:33:08 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-17 06:33:08 --> Database Driver Class Initialized
DEBUG - 2011-09-17 06:33:08 --> Final output sent to browser
DEBUG - 2011-09-17 06:33:08 --> Total execution time: 0.4949
DEBUG - 2011-09-17 06:43:23 --> Config Class Initialized
DEBUG - 2011-09-17 06:43:23 --> Hooks Class Initialized
DEBUG - 2011-09-17 06:43:23 --> Utf8 Class Initialized
DEBUG - 2011-09-17 06:43:23 --> UTF-8 Support Enabled
DEBUG - 2011-09-17 06:43:23 --> URI Class Initialized
DEBUG - 2011-09-17 06:43:23 --> Router Class Initialized
DEBUG - 2011-09-17 06:43:23 --> Output Class Initialized
DEBUG - 2011-09-17 06:43:23 --> Input Class Initialized
DEBUG - 2011-09-17 06:43:23 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-17 06:43:23 --> Language Class Initialized
DEBUG - 2011-09-17 06:43:23 --> Loader Class Initialized
DEBUG - 2011-09-17 06:43:23 --> Controller Class Initialized
ERROR - 2011-09-17 06:43:23 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-09-17 06:43:23 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-09-17 06:43:23 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-09-17 06:43:23 --> Model Class Initialized
DEBUG - 2011-09-17 06:43:23 --> Model Class Initialized
DEBUG - 2011-09-17 06:43:23 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-17 06:43:23 --> Database Driver Class Initialized
DEBUG - 2011-09-17 06:43:23 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-09-17 06:43:23 --> Helper loaded: url_helper
DEBUG - 2011-09-17 06:43:23 --> File loaded: application/views/common/header.php
DEBUG - 2011-09-17 06:43:23 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-09-17 06:43:23 --> File loaded: application/views/common/footer.php
DEBUG - 2011-09-17 06:43:23 --> File loaded: application/views/layout/main.php
DEBUG - 2011-09-17 06:43:23 --> Final output sent to browser
DEBUG - 2011-09-17 06:43:23 --> Total execution time: 0.0426
DEBUG - 2011-09-17 06:43:25 --> Config Class Initialized
DEBUG - 2011-09-17 06:43:25 --> Hooks Class Initialized
DEBUG - 2011-09-17 06:43:25 --> Utf8 Class Initialized
DEBUG - 2011-09-17 06:43:25 --> UTF-8 Support Enabled
DEBUG - 2011-09-17 06:43:25 --> URI Class Initialized
DEBUG - 2011-09-17 06:43:25 --> Router Class Initialized
DEBUG - 2011-09-17 06:43:25 --> Output Class Initialized
DEBUG - 2011-09-17 06:43:25 --> Input Class Initialized
DEBUG - 2011-09-17 06:43:25 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-17 06:43:25 --> Language Class Initialized
DEBUG - 2011-09-17 06:43:25 --> Loader Class Initialized
DEBUG - 2011-09-17 06:43:25 --> Controller Class Initialized
DEBUG - 2011-09-17 06:43:25 --> Model Class Initialized
DEBUG - 2011-09-17 06:43:25 --> Model Class Initialized
DEBUG - 2011-09-17 06:43:25 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-17 06:43:25 --> Database Driver Class Initialized
DEBUG - 2011-09-17 06:43:26 --> Final output sent to browser
DEBUG - 2011-09-17 06:43:26 --> Total execution time: 0.6362
DEBUG - 2011-09-17 06:43:28 --> Config Class Initialized
DEBUG - 2011-09-17 06:43:28 --> Hooks Class Initialized
DEBUG - 2011-09-17 06:43:28 --> Utf8 Class Initialized
DEBUG - 2011-09-17 06:43:28 --> UTF-8 Support Enabled
DEBUG - 2011-09-17 06:43:28 --> URI Class Initialized
DEBUG - 2011-09-17 06:43:28 --> Router Class Initialized
ERROR - 2011-09-17 06:43:28 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-09-17 06:43:43 --> Config Class Initialized
DEBUG - 2011-09-17 06:43:43 --> Hooks Class Initialized
DEBUG - 2011-09-17 06:43:43 --> Utf8 Class Initialized
DEBUG - 2011-09-17 06:43:43 --> UTF-8 Support Enabled
DEBUG - 2011-09-17 06:43:43 --> URI Class Initialized
DEBUG - 2011-09-17 06:43:43 --> Router Class Initialized
DEBUG - 2011-09-17 06:43:43 --> Output Class Initialized
DEBUG - 2011-09-17 06:43:43 --> Input Class Initialized
DEBUG - 2011-09-17 06:43:43 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-17 06:43:43 --> Language Class Initialized
DEBUG - 2011-09-17 06:43:43 --> Loader Class Initialized
DEBUG - 2011-09-17 06:43:43 --> Controller Class Initialized
ERROR - 2011-09-17 06:43:43 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-09-17 06:43:43 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-09-17 06:43:43 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-09-17 06:43:43 --> Model Class Initialized
DEBUG - 2011-09-17 06:43:43 --> Model Class Initialized
DEBUG - 2011-09-17 06:43:43 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-17 06:43:43 --> Database Driver Class Initialized
DEBUG - 2011-09-17 06:43:43 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-09-17 06:43:43 --> Helper loaded: url_helper
DEBUG - 2011-09-17 06:43:43 --> File loaded: application/views/common/header.php
DEBUG - 2011-09-17 06:43:43 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-09-17 06:43:43 --> File loaded: application/views/common/footer.php
DEBUG - 2011-09-17 06:43:43 --> File loaded: application/views/layout/main.php
DEBUG - 2011-09-17 06:43:43 --> Final output sent to browser
DEBUG - 2011-09-17 06:43:43 --> Total execution time: 0.0269
DEBUG - 2011-09-17 06:43:44 --> Config Class Initialized
DEBUG - 2011-09-17 06:43:44 --> Hooks Class Initialized
DEBUG - 2011-09-17 06:43:44 --> Utf8 Class Initialized
DEBUG - 2011-09-17 06:43:44 --> UTF-8 Support Enabled
DEBUG - 2011-09-17 06:43:44 --> URI Class Initialized
DEBUG - 2011-09-17 06:43:44 --> Router Class Initialized
DEBUG - 2011-09-17 06:43:44 --> Output Class Initialized
DEBUG - 2011-09-17 06:43:44 --> Input Class Initialized
DEBUG - 2011-09-17 06:43:44 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-17 06:43:44 --> Language Class Initialized
DEBUG - 2011-09-17 06:43:44 --> Loader Class Initialized
DEBUG - 2011-09-17 06:43:44 --> Controller Class Initialized
DEBUG - 2011-09-17 06:43:44 --> Model Class Initialized
DEBUG - 2011-09-17 06:43:44 --> Model Class Initialized
DEBUG - 2011-09-17 06:43:44 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-17 06:43:44 --> Database Driver Class Initialized
DEBUG - 2011-09-17 06:43:44 --> Final output sent to browser
DEBUG - 2011-09-17 06:43:44 --> Total execution time: 0.6099
DEBUG - 2011-09-17 06:43:46 --> Config Class Initialized
DEBUG - 2011-09-17 06:43:46 --> Hooks Class Initialized
DEBUG - 2011-09-17 06:43:46 --> Utf8 Class Initialized
DEBUG - 2011-09-17 06:43:46 --> UTF-8 Support Enabled
DEBUG - 2011-09-17 06:43:46 --> URI Class Initialized
DEBUG - 2011-09-17 06:43:46 --> Router Class Initialized
ERROR - 2011-09-17 06:43:46 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-09-17 06:44:02 --> Config Class Initialized
DEBUG - 2011-09-17 06:44:02 --> Hooks Class Initialized
DEBUG - 2011-09-17 06:44:02 --> Utf8 Class Initialized
DEBUG - 2011-09-17 06:44:02 --> UTF-8 Support Enabled
DEBUG - 2011-09-17 06:44:02 --> URI Class Initialized
DEBUG - 2011-09-17 06:44:02 --> Router Class Initialized
DEBUG - 2011-09-17 06:44:02 --> Output Class Initialized
DEBUG - 2011-09-17 06:44:02 --> Input Class Initialized
DEBUG - 2011-09-17 06:44:02 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-17 06:44:02 --> Language Class Initialized
DEBUG - 2011-09-17 06:44:02 --> Loader Class Initialized
DEBUG - 2011-09-17 06:44:02 --> Controller Class Initialized
ERROR - 2011-09-17 06:44:02 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-09-17 06:44:02 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-09-17 06:44:02 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-09-17 06:44:02 --> Model Class Initialized
DEBUG - 2011-09-17 06:44:02 --> Model Class Initialized
DEBUG - 2011-09-17 06:44:02 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-17 06:44:02 --> Database Driver Class Initialized
DEBUG - 2011-09-17 06:44:02 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-09-17 06:44:02 --> Helper loaded: url_helper
DEBUG - 2011-09-17 06:44:02 --> File loaded: application/views/common/header.php
DEBUG - 2011-09-17 06:44:02 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-09-17 06:44:02 --> File loaded: application/views/common/footer.php
DEBUG - 2011-09-17 06:44:02 --> File loaded: application/views/layout/main.php
DEBUG - 2011-09-17 06:44:02 --> Final output sent to browser
DEBUG - 2011-09-17 06:44:02 --> Total execution time: 0.0481
DEBUG - 2011-09-17 06:44:03 --> Config Class Initialized
DEBUG - 2011-09-17 06:44:03 --> Hooks Class Initialized
DEBUG - 2011-09-17 06:44:03 --> Utf8 Class Initialized
DEBUG - 2011-09-17 06:44:03 --> UTF-8 Support Enabled
DEBUG - 2011-09-17 06:44:03 --> URI Class Initialized
DEBUG - 2011-09-17 06:44:03 --> Router Class Initialized
DEBUG - 2011-09-17 06:44:03 --> Output Class Initialized
DEBUG - 2011-09-17 06:44:03 --> Input Class Initialized
DEBUG - 2011-09-17 06:44:03 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-17 06:44:03 --> Language Class Initialized
DEBUG - 2011-09-17 06:44:03 --> Loader Class Initialized
DEBUG - 2011-09-17 06:44:03 --> Controller Class Initialized
DEBUG - 2011-09-17 06:44:03 --> Model Class Initialized
DEBUG - 2011-09-17 06:44:03 --> Model Class Initialized
DEBUG - 2011-09-17 06:44:03 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-17 06:44:03 --> Database Driver Class Initialized
DEBUG - 2011-09-17 06:44:04 --> Final output sent to browser
DEBUG - 2011-09-17 06:44:04 --> Total execution time: 0.6042
DEBUG - 2011-09-17 06:44:08 --> Config Class Initialized
DEBUG - 2011-09-17 06:44:08 --> Hooks Class Initialized
DEBUG - 2011-09-17 06:44:08 --> Utf8 Class Initialized
DEBUG - 2011-09-17 06:44:08 --> UTF-8 Support Enabled
DEBUG - 2011-09-17 06:44:08 --> URI Class Initialized
DEBUG - 2011-09-17 06:44:08 --> Router Class Initialized
ERROR - 2011-09-17 06:44:08 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-09-17 06:44:11 --> Config Class Initialized
DEBUG - 2011-09-17 06:44:11 --> Hooks Class Initialized
DEBUG - 2011-09-17 06:44:11 --> Utf8 Class Initialized
DEBUG - 2011-09-17 06:44:11 --> UTF-8 Support Enabled
DEBUG - 2011-09-17 06:44:11 --> URI Class Initialized
DEBUG - 2011-09-17 06:44:11 --> Router Class Initialized
DEBUG - 2011-09-17 06:44:11 --> Output Class Initialized
DEBUG - 2011-09-17 06:44:11 --> Input Class Initialized
DEBUG - 2011-09-17 06:44:11 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-17 06:44:11 --> Language Class Initialized
DEBUG - 2011-09-17 06:44:11 --> Loader Class Initialized
DEBUG - 2011-09-17 06:44:11 --> Controller Class Initialized
ERROR - 2011-09-17 06:44:11 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-09-17 06:44:11 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-09-17 06:44:11 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-09-17 06:44:11 --> Model Class Initialized
DEBUG - 2011-09-17 06:44:11 --> Model Class Initialized
DEBUG - 2011-09-17 06:44:11 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-17 06:44:11 --> Database Driver Class Initialized
DEBUG - 2011-09-17 06:44:11 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-09-17 06:44:11 --> Helper loaded: url_helper
DEBUG - 2011-09-17 06:44:11 --> File loaded: application/views/common/header.php
DEBUG - 2011-09-17 06:44:11 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-09-17 06:44:11 --> File loaded: application/views/common/footer.php
DEBUG - 2011-09-17 06:44:11 --> File loaded: application/views/layout/main.php
DEBUG - 2011-09-17 06:44:11 --> Final output sent to browser
DEBUG - 2011-09-17 06:44:11 --> Total execution time: 0.0291
DEBUG - 2011-09-17 06:44:12 --> Config Class Initialized
DEBUG - 2011-09-17 06:44:12 --> Hooks Class Initialized
DEBUG - 2011-09-17 06:44:12 --> Utf8 Class Initialized
DEBUG - 2011-09-17 06:44:12 --> UTF-8 Support Enabled
DEBUG - 2011-09-17 06:44:12 --> URI Class Initialized
DEBUG - 2011-09-17 06:44:12 --> Router Class Initialized
DEBUG - 2011-09-17 06:44:12 --> Output Class Initialized
DEBUG - 2011-09-17 06:44:12 --> Input Class Initialized
DEBUG - 2011-09-17 06:44:12 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-17 06:44:12 --> Language Class Initialized
DEBUG - 2011-09-17 06:44:12 --> Loader Class Initialized
DEBUG - 2011-09-17 06:44:12 --> Controller Class Initialized
DEBUG - 2011-09-17 06:44:12 --> Model Class Initialized
DEBUG - 2011-09-17 06:44:12 --> Model Class Initialized
DEBUG - 2011-09-17 06:44:12 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-17 06:44:12 --> Database Driver Class Initialized
DEBUG - 2011-09-17 06:44:13 --> Final output sent to browser
DEBUG - 2011-09-17 06:44:13 --> Total execution time: 0.5891
DEBUG - 2011-09-17 06:44:15 --> Config Class Initialized
DEBUG - 2011-09-17 06:44:15 --> Hooks Class Initialized
DEBUG - 2011-09-17 06:44:15 --> Utf8 Class Initialized
DEBUG - 2011-09-17 06:44:15 --> UTF-8 Support Enabled
DEBUG - 2011-09-17 06:44:15 --> URI Class Initialized
DEBUG - 2011-09-17 06:44:15 --> Router Class Initialized
ERROR - 2011-09-17 06:44:15 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-09-17 07:20:11 --> Config Class Initialized
DEBUG - 2011-09-17 07:20:11 --> Hooks Class Initialized
DEBUG - 2011-09-17 07:20:11 --> Utf8 Class Initialized
DEBUG - 2011-09-17 07:20:11 --> UTF-8 Support Enabled
DEBUG - 2011-09-17 07:20:11 --> URI Class Initialized
DEBUG - 2011-09-17 07:20:11 --> Router Class Initialized
DEBUG - 2011-09-17 07:20:11 --> Output Class Initialized
DEBUG - 2011-09-17 07:20:11 --> Input Class Initialized
DEBUG - 2011-09-17 07:20:11 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-17 07:20:11 --> Language Class Initialized
DEBUG - 2011-09-17 07:20:11 --> Loader Class Initialized
DEBUG - 2011-09-17 07:20:11 --> Controller Class Initialized
ERROR - 2011-09-17 07:20:11 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-09-17 07:20:11 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-09-17 07:20:11 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-09-17 07:20:11 --> Model Class Initialized
DEBUG - 2011-09-17 07:20:11 --> Model Class Initialized
DEBUG - 2011-09-17 07:20:11 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-17 07:20:11 --> Database Driver Class Initialized
DEBUG - 2011-09-17 07:20:11 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-09-17 07:20:11 --> Helper loaded: url_helper
DEBUG - 2011-09-17 07:20:11 --> File loaded: application/views/common/header.php
DEBUG - 2011-09-17 07:20:11 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-09-17 07:20:11 --> File loaded: application/views/common/footer.php
DEBUG - 2011-09-17 07:20:11 --> File loaded: application/views/layout/main.php
DEBUG - 2011-09-17 07:20:11 --> Final output sent to browser
DEBUG - 2011-09-17 07:20:11 --> Total execution time: 0.3586
DEBUG - 2011-09-17 07:20:14 --> Config Class Initialized
DEBUG - 2011-09-17 07:20:14 --> Hooks Class Initialized
DEBUG - 2011-09-17 07:20:14 --> Utf8 Class Initialized
DEBUG - 2011-09-17 07:20:14 --> UTF-8 Support Enabled
DEBUG - 2011-09-17 07:20:14 --> URI Class Initialized
DEBUG - 2011-09-17 07:20:14 --> Router Class Initialized
DEBUG - 2011-09-17 07:20:14 --> Output Class Initialized
DEBUG - 2011-09-17 07:20:14 --> Input Class Initialized
DEBUG - 2011-09-17 07:20:14 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-17 07:20:14 --> Language Class Initialized
DEBUG - 2011-09-17 07:20:14 --> Loader Class Initialized
DEBUG - 2011-09-17 07:20:14 --> Controller Class Initialized
DEBUG - 2011-09-17 07:20:14 --> Model Class Initialized
DEBUG - 2011-09-17 07:20:14 --> Model Class Initialized
DEBUG - 2011-09-17 07:20:14 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-17 07:20:14 --> Database Driver Class Initialized
DEBUG - 2011-09-17 07:20:15 --> Final output sent to browser
DEBUG - 2011-09-17 07:20:15 --> Total execution time: 1.0353
DEBUG - 2011-09-17 07:20:18 --> Config Class Initialized
DEBUG - 2011-09-17 07:20:18 --> Hooks Class Initialized
DEBUG - 2011-09-17 07:20:18 --> Utf8 Class Initialized
DEBUG - 2011-09-17 07:20:18 --> UTF-8 Support Enabled
DEBUG - 2011-09-17 07:20:18 --> URI Class Initialized
DEBUG - 2011-09-17 07:20:18 --> Router Class Initialized
ERROR - 2011-09-17 07:20:18 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-09-17 07:42:43 --> Config Class Initialized
DEBUG - 2011-09-17 07:42:43 --> Hooks Class Initialized
DEBUG - 2011-09-17 07:42:43 --> Utf8 Class Initialized
DEBUG - 2011-09-17 07:42:43 --> UTF-8 Support Enabled
DEBUG - 2011-09-17 07:42:43 --> URI Class Initialized
DEBUG - 2011-09-17 07:42:43 --> Router Class Initialized
DEBUG - 2011-09-17 07:42:43 --> Output Class Initialized
DEBUG - 2011-09-17 07:42:43 --> Input Class Initialized
DEBUG - 2011-09-17 07:42:43 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-17 07:42:43 --> Language Class Initialized
DEBUG - 2011-09-17 07:42:43 --> Loader Class Initialized
DEBUG - 2011-09-17 07:42:43 --> Controller Class Initialized
DEBUG - 2011-09-17 07:42:43 --> Model Class Initialized
DEBUG - 2011-09-17 07:42:43 --> Model Class Initialized
DEBUG - 2011-09-17 07:42:43 --> Model Class Initialized
DEBUG - 2011-09-17 07:42:43 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-17 07:42:43 --> Database Driver Class Initialized
DEBUG - 2011-09-17 07:42:44 --> File loaded: application/views/table/main.php
DEBUG - 2011-09-17 07:42:44 --> Helper loaded: url_helper
DEBUG - 2011-09-17 07:42:44 --> File loaded: application/views/common/header.php
DEBUG - 2011-09-17 07:42:44 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-09-17 07:42:44 --> File loaded: application/views/common/footer.php
DEBUG - 2011-09-17 07:42:44 --> File loaded: application/views/layout/main.php
DEBUG - 2011-09-17 07:42:44 --> Final output sent to browser
DEBUG - 2011-09-17 07:42:44 --> Total execution time: 1.3739
DEBUG - 2011-09-17 07:42:47 --> Config Class Initialized
DEBUG - 2011-09-17 07:42:47 --> Hooks Class Initialized
DEBUG - 2011-09-17 07:42:47 --> Utf8 Class Initialized
DEBUG - 2011-09-17 07:42:47 --> UTF-8 Support Enabled
DEBUG - 2011-09-17 07:42:47 --> URI Class Initialized
DEBUG - 2011-09-17 07:42:47 --> Router Class Initialized
ERROR - 2011-09-17 07:42:47 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-09-17 07:42:47 --> Config Class Initialized
DEBUG - 2011-09-17 07:42:47 --> Hooks Class Initialized
DEBUG - 2011-09-17 07:42:47 --> Utf8 Class Initialized
DEBUG - 2011-09-17 07:42:47 --> UTF-8 Support Enabled
DEBUG - 2011-09-17 07:42:47 --> URI Class Initialized
DEBUG - 2011-09-17 07:42:47 --> Router Class Initialized
ERROR - 2011-09-17 07:42:47 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-09-17 07:42:48 --> Config Class Initialized
DEBUG - 2011-09-17 07:42:48 --> Hooks Class Initialized
DEBUG - 2011-09-17 07:42:48 --> Utf8 Class Initialized
DEBUG - 2011-09-17 07:42:48 --> UTF-8 Support Enabled
DEBUG - 2011-09-17 07:42:48 --> URI Class Initialized
DEBUG - 2011-09-17 07:42:48 --> Router Class Initialized
ERROR - 2011-09-17 07:42:48 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-09-17 07:46:23 --> Config Class Initialized
DEBUG - 2011-09-17 07:46:23 --> Hooks Class Initialized
DEBUG - 2011-09-17 07:46:23 --> Utf8 Class Initialized
DEBUG - 2011-09-17 07:46:23 --> UTF-8 Support Enabled
DEBUG - 2011-09-17 07:46:23 --> URI Class Initialized
DEBUG - 2011-09-17 07:46:23 --> Router Class Initialized
DEBUG - 2011-09-17 07:46:23 --> Output Class Initialized
DEBUG - 2011-09-17 07:46:23 --> Input Class Initialized
DEBUG - 2011-09-17 07:46:23 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-17 07:46:23 --> Language Class Initialized
DEBUG - 2011-09-17 07:46:23 --> Loader Class Initialized
DEBUG - 2011-09-17 07:46:23 --> Controller Class Initialized
ERROR - 2011-09-17 07:46:23 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-09-17 07:46:23 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-09-17 07:46:23 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-09-17 07:46:23 --> Model Class Initialized
DEBUG - 2011-09-17 07:46:23 --> Model Class Initialized
DEBUG - 2011-09-17 07:46:23 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-17 07:46:23 --> Database Driver Class Initialized
DEBUG - 2011-09-17 07:46:23 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-09-17 07:46:23 --> Helper loaded: url_helper
DEBUG - 2011-09-17 07:46:23 --> File loaded: application/views/common/header.php
DEBUG - 2011-09-17 07:46:23 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-09-17 07:46:23 --> File loaded: application/views/common/footer.php
DEBUG - 2011-09-17 07:46:23 --> File loaded: application/views/layout/main.php
DEBUG - 2011-09-17 07:46:23 --> Final output sent to browser
DEBUG - 2011-09-17 07:46:23 --> Total execution time: 0.0570
DEBUG - 2011-09-17 07:46:24 --> Config Class Initialized
DEBUG - 2011-09-17 07:46:24 --> Hooks Class Initialized
DEBUG - 2011-09-17 07:46:24 --> Utf8 Class Initialized
DEBUG - 2011-09-17 07:46:24 --> UTF-8 Support Enabled
DEBUG - 2011-09-17 07:46:24 --> URI Class Initialized
DEBUG - 2011-09-17 07:46:24 --> Router Class Initialized
DEBUG - 2011-09-17 07:46:24 --> Output Class Initialized
DEBUG - 2011-09-17 07:46:24 --> Input Class Initialized
DEBUG - 2011-09-17 07:46:24 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-17 07:46:24 --> Language Class Initialized
DEBUG - 2011-09-17 07:46:24 --> Loader Class Initialized
DEBUG - 2011-09-17 07:46:24 --> Controller Class Initialized
DEBUG - 2011-09-17 07:46:24 --> Model Class Initialized
DEBUG - 2011-09-17 07:46:24 --> Model Class Initialized
DEBUG - 2011-09-17 07:46:24 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-17 07:46:24 --> Database Driver Class Initialized
DEBUG - 2011-09-17 07:46:25 --> Final output sent to browser
DEBUG - 2011-09-17 07:46:25 --> Total execution time: 0.5571
DEBUG - 2011-09-17 07:46:26 --> Config Class Initialized
DEBUG - 2011-09-17 07:46:26 --> Hooks Class Initialized
DEBUG - 2011-09-17 07:46:26 --> Utf8 Class Initialized
DEBUG - 2011-09-17 07:46:26 --> UTF-8 Support Enabled
DEBUG - 2011-09-17 07:46:26 --> URI Class Initialized
DEBUG - 2011-09-17 07:46:26 --> Router Class Initialized
ERROR - 2011-09-17 07:46:26 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-09-17 07:46:42 --> Config Class Initialized
DEBUG - 2011-09-17 07:46:42 --> Hooks Class Initialized
DEBUG - 2011-09-17 07:46:42 --> Utf8 Class Initialized
DEBUG - 2011-09-17 07:46:42 --> UTF-8 Support Enabled
DEBUG - 2011-09-17 07:46:42 --> URI Class Initialized
DEBUG - 2011-09-17 07:46:42 --> Router Class Initialized
DEBUG - 2011-09-17 07:46:42 --> Output Class Initialized
DEBUG - 2011-09-17 07:46:42 --> Input Class Initialized
DEBUG - 2011-09-17 07:46:42 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-17 07:46:42 --> Language Class Initialized
DEBUG - 2011-09-17 07:46:42 --> Loader Class Initialized
DEBUG - 2011-09-17 07:46:42 --> Controller Class Initialized
ERROR - 2011-09-17 07:46:42 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-09-17 07:46:42 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-09-17 07:46:42 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-09-17 07:46:42 --> Model Class Initialized
DEBUG - 2011-09-17 07:46:42 --> Model Class Initialized
DEBUG - 2011-09-17 07:46:42 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-17 07:46:42 --> Database Driver Class Initialized
DEBUG - 2011-09-17 07:46:42 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-09-17 07:46:42 --> Helper loaded: url_helper
DEBUG - 2011-09-17 07:46:42 --> File loaded: application/views/common/header.php
DEBUG - 2011-09-17 07:46:42 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-09-17 07:46:42 --> File loaded: application/views/common/footer.php
DEBUG - 2011-09-17 07:46:42 --> File loaded: application/views/layout/main.php
DEBUG - 2011-09-17 07:46:42 --> Final output sent to browser
DEBUG - 2011-09-17 07:46:42 --> Total execution time: 0.0297
DEBUG - 2011-09-17 07:46:42 --> Config Class Initialized
DEBUG - 2011-09-17 07:46:42 --> Hooks Class Initialized
DEBUG - 2011-09-17 07:46:42 --> Utf8 Class Initialized
DEBUG - 2011-09-17 07:46:42 --> UTF-8 Support Enabled
DEBUG - 2011-09-17 07:46:42 --> URI Class Initialized
DEBUG - 2011-09-17 07:46:42 --> Router Class Initialized
DEBUG - 2011-09-17 07:46:42 --> Output Class Initialized
DEBUG - 2011-09-17 07:46:42 --> Input Class Initialized
DEBUG - 2011-09-17 07:46:42 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-17 07:46:42 --> Language Class Initialized
DEBUG - 2011-09-17 07:46:42 --> Loader Class Initialized
DEBUG - 2011-09-17 07:46:42 --> Controller Class Initialized
DEBUG - 2011-09-17 07:46:42 --> Model Class Initialized
DEBUG - 2011-09-17 07:46:42 --> Model Class Initialized
DEBUG - 2011-09-17 07:46:42 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-17 07:46:42 --> Database Driver Class Initialized
DEBUG - 2011-09-17 07:46:43 --> Final output sent to browser
DEBUG - 2011-09-17 07:46:43 --> Total execution time: 0.6158
DEBUG - 2011-09-17 07:46:44 --> Config Class Initialized
DEBUG - 2011-09-17 07:46:44 --> Hooks Class Initialized
DEBUG - 2011-09-17 07:46:44 --> Utf8 Class Initialized
DEBUG - 2011-09-17 07:46:44 --> UTF-8 Support Enabled
DEBUG - 2011-09-17 07:46:44 --> URI Class Initialized
DEBUG - 2011-09-17 07:46:44 --> Router Class Initialized
ERROR - 2011-09-17 07:46:44 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-09-17 07:46:59 --> Config Class Initialized
DEBUG - 2011-09-17 07:46:59 --> Hooks Class Initialized
DEBUG - 2011-09-17 07:47:00 --> Utf8 Class Initialized
DEBUG - 2011-09-17 07:47:00 --> UTF-8 Support Enabled
DEBUG - 2011-09-17 07:47:00 --> URI Class Initialized
DEBUG - 2011-09-17 07:47:00 --> Router Class Initialized
DEBUG - 2011-09-17 07:47:00 --> Output Class Initialized
DEBUG - 2011-09-17 07:47:00 --> Input Class Initialized
DEBUG - 2011-09-17 07:47:00 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-17 07:47:00 --> Language Class Initialized
DEBUG - 2011-09-17 07:47:00 --> Loader Class Initialized
DEBUG - 2011-09-17 07:47:00 --> Controller Class Initialized
ERROR - 2011-09-17 07:47:00 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-09-17 07:47:00 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-09-17 07:47:00 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-09-17 07:47:00 --> Model Class Initialized
DEBUG - 2011-09-17 07:47:00 --> Model Class Initialized
DEBUG - 2011-09-17 07:47:00 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-17 07:47:00 --> Database Driver Class Initialized
DEBUG - 2011-09-17 07:47:00 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-09-17 07:47:00 --> Helper loaded: url_helper
DEBUG - 2011-09-17 07:47:00 --> File loaded: application/views/common/header.php
DEBUG - 2011-09-17 07:47:00 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-09-17 07:47:00 --> File loaded: application/views/common/footer.php
DEBUG - 2011-09-17 07:47:00 --> File loaded: application/views/layout/main.php
DEBUG - 2011-09-17 07:47:00 --> Final output sent to browser
DEBUG - 2011-09-17 07:47:00 --> Total execution time: 0.0470
DEBUG - 2011-09-17 07:47:00 --> Config Class Initialized
DEBUG - 2011-09-17 07:47:00 --> Hooks Class Initialized
DEBUG - 2011-09-17 07:47:00 --> Utf8 Class Initialized
DEBUG - 2011-09-17 07:47:00 --> UTF-8 Support Enabled
DEBUG - 2011-09-17 07:47:00 --> URI Class Initialized
DEBUG - 2011-09-17 07:47:00 --> Router Class Initialized
DEBUG - 2011-09-17 07:47:00 --> Output Class Initialized
DEBUG - 2011-09-17 07:47:00 --> Input Class Initialized
DEBUG - 2011-09-17 07:47:00 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-17 07:47:00 --> Language Class Initialized
DEBUG - 2011-09-17 07:47:00 --> Loader Class Initialized
DEBUG - 2011-09-17 07:47:00 --> Controller Class Initialized
DEBUG - 2011-09-17 07:47:00 --> Model Class Initialized
DEBUG - 2011-09-17 07:47:00 --> Model Class Initialized
DEBUG - 2011-09-17 07:47:00 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-17 07:47:00 --> Database Driver Class Initialized
DEBUG - 2011-09-17 07:47:01 --> Final output sent to browser
DEBUG - 2011-09-17 07:47:01 --> Total execution time: 0.5810
DEBUG - 2011-09-17 07:47:02 --> Config Class Initialized
DEBUG - 2011-09-17 07:47:02 --> Hooks Class Initialized
DEBUG - 2011-09-17 07:47:02 --> Utf8 Class Initialized
DEBUG - 2011-09-17 07:47:02 --> UTF-8 Support Enabled
DEBUG - 2011-09-17 07:47:02 --> URI Class Initialized
DEBUG - 2011-09-17 07:47:02 --> Router Class Initialized
ERROR - 2011-09-17 07:47:02 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-09-17 07:47:15 --> Config Class Initialized
DEBUG - 2011-09-17 07:47:15 --> Hooks Class Initialized
DEBUG - 2011-09-17 07:47:15 --> Utf8 Class Initialized
DEBUG - 2011-09-17 07:47:15 --> UTF-8 Support Enabled
DEBUG - 2011-09-17 07:47:15 --> URI Class Initialized
DEBUG - 2011-09-17 07:47:15 --> Router Class Initialized
DEBUG - 2011-09-17 07:47:15 --> Output Class Initialized
DEBUG - 2011-09-17 07:47:15 --> Input Class Initialized
DEBUG - 2011-09-17 07:47:15 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-17 07:47:15 --> Language Class Initialized
DEBUG - 2011-09-17 07:47:15 --> Loader Class Initialized
DEBUG - 2011-09-17 07:47:15 --> Controller Class Initialized
ERROR - 2011-09-17 07:47:15 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-09-17 07:47:15 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-09-17 07:47:15 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-09-17 07:47:15 --> Model Class Initialized
DEBUG - 2011-09-17 07:47:15 --> Model Class Initialized
DEBUG - 2011-09-17 07:47:15 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-17 07:47:15 --> Database Driver Class Initialized
DEBUG - 2011-09-17 07:47:15 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-09-17 07:47:15 --> Helper loaded: url_helper
DEBUG - 2011-09-17 07:47:15 --> File loaded: application/views/common/header.php
DEBUG - 2011-09-17 07:47:15 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-09-17 07:47:15 --> File loaded: application/views/common/footer.php
DEBUG - 2011-09-17 07:47:15 --> File loaded: application/views/layout/main.php
DEBUG - 2011-09-17 07:47:15 --> Final output sent to browser
DEBUG - 2011-09-17 07:47:15 --> Total execution time: 0.0322
DEBUG - 2011-09-17 07:47:16 --> Config Class Initialized
DEBUG - 2011-09-17 07:47:16 --> Hooks Class Initialized
DEBUG - 2011-09-17 07:47:16 --> Utf8 Class Initialized
DEBUG - 2011-09-17 07:47:16 --> UTF-8 Support Enabled
DEBUG - 2011-09-17 07:47:16 --> URI Class Initialized
DEBUG - 2011-09-17 07:47:16 --> Router Class Initialized
DEBUG - 2011-09-17 07:47:16 --> Output Class Initialized
DEBUG - 2011-09-17 07:47:16 --> Input Class Initialized
DEBUG - 2011-09-17 07:47:16 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-17 07:47:16 --> Language Class Initialized
DEBUG - 2011-09-17 07:47:16 --> Loader Class Initialized
DEBUG - 2011-09-17 07:47:16 --> Controller Class Initialized
DEBUG - 2011-09-17 07:47:16 --> Model Class Initialized
DEBUG - 2011-09-17 07:47:16 --> Model Class Initialized
DEBUG - 2011-09-17 07:47:16 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-17 07:47:16 --> Database Driver Class Initialized
DEBUG - 2011-09-17 07:47:17 --> Final output sent to browser
DEBUG - 2011-09-17 07:47:17 --> Total execution time: 0.7771
DEBUG - 2011-09-17 07:47:17 --> Config Class Initialized
DEBUG - 2011-09-17 07:47:17 --> Hooks Class Initialized
DEBUG - 2011-09-17 07:47:17 --> Utf8 Class Initialized
DEBUG - 2011-09-17 07:47:17 --> UTF-8 Support Enabled
DEBUG - 2011-09-17 07:47:17 --> URI Class Initialized
DEBUG - 2011-09-17 07:47:17 --> Router Class Initialized
ERROR - 2011-09-17 07:47:17 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-09-17 07:47:30 --> Config Class Initialized
DEBUG - 2011-09-17 07:47:30 --> Hooks Class Initialized
DEBUG - 2011-09-17 07:47:30 --> Utf8 Class Initialized
DEBUG - 2011-09-17 07:47:30 --> UTF-8 Support Enabled
DEBUG - 2011-09-17 07:47:30 --> URI Class Initialized
DEBUG - 2011-09-17 07:47:30 --> Router Class Initialized
DEBUG - 2011-09-17 07:47:30 --> Output Class Initialized
DEBUG - 2011-09-17 07:47:30 --> Input Class Initialized
DEBUG - 2011-09-17 07:47:30 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-17 07:47:30 --> Language Class Initialized
DEBUG - 2011-09-17 07:47:30 --> Loader Class Initialized
DEBUG - 2011-09-17 07:47:30 --> Controller Class Initialized
ERROR - 2011-09-17 07:47:30 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-09-17 07:47:30 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-09-17 07:47:30 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-09-17 07:47:30 --> Model Class Initialized
DEBUG - 2011-09-17 07:47:30 --> Model Class Initialized
DEBUG - 2011-09-17 07:47:30 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-17 07:47:30 --> Database Driver Class Initialized
DEBUG - 2011-09-17 07:47:30 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-09-17 07:47:30 --> Helper loaded: url_helper
DEBUG - 2011-09-17 07:47:30 --> File loaded: application/views/common/header.php
DEBUG - 2011-09-17 07:47:30 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-09-17 07:47:30 --> File loaded: application/views/common/footer.php
DEBUG - 2011-09-17 07:47:30 --> File loaded: application/views/layout/main.php
DEBUG - 2011-09-17 07:47:30 --> Final output sent to browser
DEBUG - 2011-09-17 07:47:30 --> Total execution time: 0.0575
DEBUG - 2011-09-17 07:47:30 --> Config Class Initialized
DEBUG - 2011-09-17 07:47:30 --> Hooks Class Initialized
DEBUG - 2011-09-17 07:47:30 --> Utf8 Class Initialized
DEBUG - 2011-09-17 07:47:30 --> UTF-8 Support Enabled
DEBUG - 2011-09-17 07:47:30 --> URI Class Initialized
DEBUG - 2011-09-17 07:47:30 --> Router Class Initialized
DEBUG - 2011-09-17 07:47:30 --> Output Class Initialized
DEBUG - 2011-09-17 07:47:30 --> Input Class Initialized
DEBUG - 2011-09-17 07:47:30 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-17 07:47:30 --> Language Class Initialized
DEBUG - 2011-09-17 07:47:30 --> Loader Class Initialized
DEBUG - 2011-09-17 07:47:30 --> Controller Class Initialized
DEBUG - 2011-09-17 07:47:30 --> Model Class Initialized
DEBUG - 2011-09-17 07:47:30 --> Model Class Initialized
DEBUG - 2011-09-17 07:47:30 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-17 07:47:30 --> Database Driver Class Initialized
DEBUG - 2011-09-17 07:47:31 --> Final output sent to browser
DEBUG - 2011-09-17 07:47:31 --> Total execution time: 0.5596
DEBUG - 2011-09-17 07:47:31 --> Config Class Initialized
DEBUG - 2011-09-17 07:47:31 --> Hooks Class Initialized
DEBUG - 2011-09-17 07:47:31 --> Utf8 Class Initialized
DEBUG - 2011-09-17 07:47:31 --> UTF-8 Support Enabled
DEBUG - 2011-09-17 07:47:31 --> URI Class Initialized
DEBUG - 2011-09-17 07:47:31 --> Router Class Initialized
ERROR - 2011-09-17 07:47:31 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-09-17 07:47:40 --> Config Class Initialized
DEBUG - 2011-09-17 07:47:40 --> Hooks Class Initialized
DEBUG - 2011-09-17 07:47:40 --> Utf8 Class Initialized
DEBUG - 2011-09-17 07:47:40 --> UTF-8 Support Enabled
DEBUG - 2011-09-17 07:47:40 --> URI Class Initialized
DEBUG - 2011-09-17 07:47:40 --> Router Class Initialized
DEBUG - 2011-09-17 07:47:40 --> Output Class Initialized
DEBUG - 2011-09-17 07:47:40 --> Input Class Initialized
DEBUG - 2011-09-17 07:47:40 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-17 07:47:40 --> Language Class Initialized
DEBUG - 2011-09-17 07:47:40 --> Loader Class Initialized
DEBUG - 2011-09-17 07:47:40 --> Controller Class Initialized
ERROR - 2011-09-17 07:47:40 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-09-17 07:47:40 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-09-17 07:47:40 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-09-17 07:47:40 --> Model Class Initialized
DEBUG - 2011-09-17 07:47:40 --> Model Class Initialized
DEBUG - 2011-09-17 07:47:40 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-17 07:47:40 --> Database Driver Class Initialized
DEBUG - 2011-09-17 07:47:40 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-09-17 07:47:40 --> Helper loaded: url_helper
DEBUG - 2011-09-17 07:47:40 --> File loaded: application/views/common/header.php
DEBUG - 2011-09-17 07:47:40 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-09-17 07:47:40 --> File loaded: application/views/common/footer.php
DEBUG - 2011-09-17 07:47:40 --> File loaded: application/views/layout/main.php
DEBUG - 2011-09-17 07:47:40 --> Final output sent to browser
DEBUG - 2011-09-17 07:47:40 --> Total execution time: 0.0326
DEBUG - 2011-09-17 07:47:40 --> Config Class Initialized
DEBUG - 2011-09-17 07:47:40 --> Hooks Class Initialized
DEBUG - 2011-09-17 07:47:40 --> Utf8 Class Initialized
DEBUG - 2011-09-17 07:47:40 --> UTF-8 Support Enabled
DEBUG - 2011-09-17 07:47:40 --> URI Class Initialized
DEBUG - 2011-09-17 07:47:40 --> Router Class Initialized
DEBUG - 2011-09-17 07:47:40 --> Output Class Initialized
DEBUG - 2011-09-17 07:47:40 --> Input Class Initialized
DEBUG - 2011-09-17 07:47:40 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-17 07:47:40 --> Language Class Initialized
DEBUG - 2011-09-17 07:47:40 --> Loader Class Initialized
DEBUG - 2011-09-17 07:47:40 --> Controller Class Initialized
DEBUG - 2011-09-17 07:47:40 --> Model Class Initialized
DEBUG - 2011-09-17 07:47:40 --> Model Class Initialized
DEBUG - 2011-09-17 07:47:40 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-17 07:47:40 --> Database Driver Class Initialized
DEBUG - 2011-09-17 07:47:41 --> Final output sent to browser
DEBUG - 2011-09-17 07:47:41 --> Total execution time: 0.5137
DEBUG - 2011-09-17 07:47:42 --> Config Class Initialized
DEBUG - 2011-09-17 07:47:42 --> Hooks Class Initialized
DEBUG - 2011-09-17 07:47:42 --> Utf8 Class Initialized
DEBUG - 2011-09-17 07:47:42 --> UTF-8 Support Enabled
DEBUG - 2011-09-17 07:47:42 --> URI Class Initialized
DEBUG - 2011-09-17 07:47:42 --> Router Class Initialized
ERROR - 2011-09-17 07:47:42 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-09-17 07:47:56 --> Config Class Initialized
DEBUG - 2011-09-17 07:47:56 --> Hooks Class Initialized
DEBUG - 2011-09-17 07:47:56 --> Utf8 Class Initialized
DEBUG - 2011-09-17 07:47:56 --> UTF-8 Support Enabled
DEBUG - 2011-09-17 07:47:56 --> URI Class Initialized
DEBUG - 2011-09-17 07:47:56 --> Router Class Initialized
DEBUG - 2011-09-17 07:47:56 --> Output Class Initialized
DEBUG - 2011-09-17 07:47:56 --> Input Class Initialized
DEBUG - 2011-09-17 07:47:56 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-17 07:47:56 --> Language Class Initialized
DEBUG - 2011-09-17 07:47:56 --> Loader Class Initialized
DEBUG - 2011-09-17 07:47:56 --> Controller Class Initialized
ERROR - 2011-09-17 07:47:56 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-09-17 07:47:56 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-09-17 07:47:56 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-09-17 07:47:56 --> Model Class Initialized
DEBUG - 2011-09-17 07:47:56 --> Model Class Initialized
DEBUG - 2011-09-17 07:47:56 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-17 07:47:56 --> Database Driver Class Initialized
DEBUG - 2011-09-17 07:47:56 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-09-17 07:47:56 --> Helper loaded: url_helper
DEBUG - 2011-09-17 07:47:56 --> File loaded: application/views/common/header.php
DEBUG - 2011-09-17 07:47:56 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-09-17 07:47:56 --> File loaded: application/views/common/footer.php
DEBUG - 2011-09-17 07:47:56 --> File loaded: application/views/layout/main.php
DEBUG - 2011-09-17 07:47:56 --> Final output sent to browser
DEBUG - 2011-09-17 07:47:56 --> Total execution time: 0.0452
DEBUG - 2011-09-17 07:47:56 --> Config Class Initialized
DEBUG - 2011-09-17 07:47:56 --> Hooks Class Initialized
DEBUG - 2011-09-17 07:47:56 --> Utf8 Class Initialized
DEBUG - 2011-09-17 07:47:56 --> UTF-8 Support Enabled
DEBUG - 2011-09-17 07:47:56 --> URI Class Initialized
DEBUG - 2011-09-17 07:47:56 --> Router Class Initialized
DEBUG - 2011-09-17 07:47:57 --> Output Class Initialized
DEBUG - 2011-09-17 07:47:57 --> Input Class Initialized
DEBUG - 2011-09-17 07:47:57 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-17 07:47:57 --> Language Class Initialized
DEBUG - 2011-09-17 07:47:57 --> Loader Class Initialized
DEBUG - 2011-09-17 07:47:57 --> Controller Class Initialized
DEBUG - 2011-09-17 07:47:57 --> Model Class Initialized
DEBUG - 2011-09-17 07:47:57 --> Model Class Initialized
DEBUG - 2011-09-17 07:47:57 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-17 07:47:57 --> Database Driver Class Initialized
DEBUG - 2011-09-17 07:47:57 --> Final output sent to browser
DEBUG - 2011-09-17 07:47:57 --> Total execution time: 0.6045
DEBUG - 2011-09-17 07:47:58 --> Config Class Initialized
DEBUG - 2011-09-17 07:47:58 --> Hooks Class Initialized
DEBUG - 2011-09-17 07:47:58 --> Utf8 Class Initialized
DEBUG - 2011-09-17 07:47:58 --> UTF-8 Support Enabled
DEBUG - 2011-09-17 07:47:58 --> URI Class Initialized
DEBUG - 2011-09-17 07:47:58 --> Router Class Initialized
ERROR - 2011-09-17 07:47:58 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-09-17 07:48:06 --> Config Class Initialized
DEBUG - 2011-09-17 07:48:06 --> Hooks Class Initialized
DEBUG - 2011-09-17 07:48:06 --> Utf8 Class Initialized
DEBUG - 2011-09-17 07:48:06 --> UTF-8 Support Enabled
DEBUG - 2011-09-17 07:48:06 --> URI Class Initialized
DEBUG - 2011-09-17 07:48:06 --> Router Class Initialized
DEBUG - 2011-09-17 07:48:06 --> Output Class Initialized
DEBUG - 2011-09-17 07:48:06 --> Input Class Initialized
DEBUG - 2011-09-17 07:48:06 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-17 07:48:06 --> Language Class Initialized
DEBUG - 2011-09-17 07:48:06 --> Loader Class Initialized
DEBUG - 2011-09-17 07:48:06 --> Controller Class Initialized
ERROR - 2011-09-17 07:48:06 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-09-17 07:48:06 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-09-17 07:48:06 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-09-17 07:48:06 --> Model Class Initialized
DEBUG - 2011-09-17 07:48:06 --> Model Class Initialized
DEBUG - 2011-09-17 07:48:06 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-17 07:48:06 --> Database Driver Class Initialized
DEBUG - 2011-09-17 07:48:06 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-09-17 07:48:06 --> Helper loaded: url_helper
DEBUG - 2011-09-17 07:48:06 --> File loaded: application/views/common/header.php
DEBUG - 2011-09-17 07:48:06 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-09-17 07:48:06 --> File loaded: application/views/common/footer.php
DEBUG - 2011-09-17 07:48:06 --> File loaded: application/views/layout/main.php
DEBUG - 2011-09-17 07:48:06 --> Final output sent to browser
DEBUG - 2011-09-17 07:48:06 --> Total execution time: 0.0325
DEBUG - 2011-09-17 07:48:06 --> Config Class Initialized
DEBUG - 2011-09-17 07:48:06 --> Hooks Class Initialized
DEBUG - 2011-09-17 07:48:06 --> Utf8 Class Initialized
DEBUG - 2011-09-17 07:48:06 --> UTF-8 Support Enabled
DEBUG - 2011-09-17 07:48:06 --> URI Class Initialized
DEBUG - 2011-09-17 07:48:06 --> Router Class Initialized
DEBUG - 2011-09-17 07:48:06 --> Output Class Initialized
DEBUG - 2011-09-17 07:48:06 --> Input Class Initialized
DEBUG - 2011-09-17 07:48:06 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-17 07:48:06 --> Language Class Initialized
DEBUG - 2011-09-17 07:48:06 --> Loader Class Initialized
DEBUG - 2011-09-17 07:48:06 --> Controller Class Initialized
DEBUG - 2011-09-17 07:48:06 --> Model Class Initialized
DEBUG - 2011-09-17 07:48:06 --> Model Class Initialized
DEBUG - 2011-09-17 07:48:06 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-17 07:48:06 --> Database Driver Class Initialized
DEBUG - 2011-09-17 07:48:07 --> Final output sent to browser
DEBUG - 2011-09-17 07:48:07 --> Total execution time: 0.6445
DEBUG - 2011-09-17 07:48:08 --> Config Class Initialized
DEBUG - 2011-09-17 07:48:08 --> Hooks Class Initialized
DEBUG - 2011-09-17 07:48:08 --> Utf8 Class Initialized
DEBUG - 2011-09-17 07:48:08 --> UTF-8 Support Enabled
DEBUG - 2011-09-17 07:48:08 --> URI Class Initialized
DEBUG - 2011-09-17 07:48:08 --> Router Class Initialized
ERROR - 2011-09-17 07:48:08 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-09-17 07:48:29 --> Config Class Initialized
DEBUG - 2011-09-17 07:48:29 --> Hooks Class Initialized
DEBUG - 2011-09-17 07:48:29 --> Utf8 Class Initialized
DEBUG - 2011-09-17 07:48:29 --> UTF-8 Support Enabled
DEBUG - 2011-09-17 07:48:29 --> URI Class Initialized
DEBUG - 2011-09-17 07:48:29 --> Router Class Initialized
DEBUG - 2011-09-17 07:48:29 --> Output Class Initialized
DEBUG - 2011-09-17 07:48:29 --> Input Class Initialized
DEBUG - 2011-09-17 07:48:29 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-17 07:48:29 --> Language Class Initialized
DEBUG - 2011-09-17 07:48:29 --> Loader Class Initialized
DEBUG - 2011-09-17 07:48:29 --> Controller Class Initialized
ERROR - 2011-09-17 07:48:29 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-09-17 07:48:29 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-09-17 07:48:29 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-09-17 07:48:29 --> Model Class Initialized
DEBUG - 2011-09-17 07:48:29 --> Model Class Initialized
DEBUG - 2011-09-17 07:48:29 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-17 07:48:29 --> Database Driver Class Initialized
DEBUG - 2011-09-17 07:48:29 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-09-17 07:48:29 --> Helper loaded: url_helper
DEBUG - 2011-09-17 07:48:29 --> File loaded: application/views/common/header.php
DEBUG - 2011-09-17 07:48:29 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-09-17 07:48:29 --> File loaded: application/views/common/footer.php
DEBUG - 2011-09-17 07:48:29 --> File loaded: application/views/layout/main.php
DEBUG - 2011-09-17 07:48:29 --> Final output sent to browser
DEBUG - 2011-09-17 07:48:29 --> Total execution time: 0.0287
DEBUG - 2011-09-17 07:48:30 --> Config Class Initialized
DEBUG - 2011-09-17 07:48:30 --> Hooks Class Initialized
DEBUG - 2011-09-17 07:48:30 --> Utf8 Class Initialized
DEBUG - 2011-09-17 07:48:30 --> UTF-8 Support Enabled
DEBUG - 2011-09-17 07:48:30 --> URI Class Initialized
DEBUG - 2011-09-17 07:48:30 --> Router Class Initialized
DEBUG - 2011-09-17 07:48:30 --> Output Class Initialized
DEBUG - 2011-09-17 07:48:30 --> Input Class Initialized
DEBUG - 2011-09-17 07:48:30 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-17 07:48:30 --> Language Class Initialized
DEBUG - 2011-09-17 07:48:30 --> Loader Class Initialized
DEBUG - 2011-09-17 07:48:30 --> Controller Class Initialized
DEBUG - 2011-09-17 07:48:30 --> Model Class Initialized
DEBUG - 2011-09-17 07:48:30 --> Model Class Initialized
DEBUG - 2011-09-17 07:48:30 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-17 07:48:30 --> Database Driver Class Initialized
DEBUG - 2011-09-17 07:48:30 --> Final output sent to browser
DEBUG - 2011-09-17 07:48:30 --> Total execution time: 0.6096
DEBUG - 2011-09-17 07:48:31 --> Config Class Initialized
DEBUG - 2011-09-17 07:48:31 --> Hooks Class Initialized
DEBUG - 2011-09-17 07:48:31 --> Utf8 Class Initialized
DEBUG - 2011-09-17 07:48:31 --> UTF-8 Support Enabled
DEBUG - 2011-09-17 07:48:31 --> URI Class Initialized
DEBUG - 2011-09-17 07:48:31 --> Router Class Initialized
ERROR - 2011-09-17 07:48:31 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-09-17 07:48:43 --> Config Class Initialized
DEBUG - 2011-09-17 07:48:43 --> Hooks Class Initialized
DEBUG - 2011-09-17 07:48:43 --> Utf8 Class Initialized
DEBUG - 2011-09-17 07:48:43 --> UTF-8 Support Enabled
DEBUG - 2011-09-17 07:48:43 --> URI Class Initialized
DEBUG - 2011-09-17 07:48:43 --> Router Class Initialized
DEBUG - 2011-09-17 07:48:43 --> Output Class Initialized
DEBUG - 2011-09-17 07:48:43 --> Input Class Initialized
DEBUG - 2011-09-17 07:48:43 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-17 07:48:43 --> Language Class Initialized
DEBUG - 2011-09-17 07:48:43 --> Loader Class Initialized
DEBUG - 2011-09-17 07:48:43 --> Controller Class Initialized
ERROR - 2011-09-17 07:48:43 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-09-17 07:48:43 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-09-17 07:48:43 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-09-17 07:48:43 --> Model Class Initialized
DEBUG - 2011-09-17 07:48:43 --> Model Class Initialized
DEBUG - 2011-09-17 07:48:43 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-17 07:48:43 --> Database Driver Class Initialized
DEBUG - 2011-09-17 07:48:43 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-09-17 07:48:43 --> Helper loaded: url_helper
DEBUG - 2011-09-17 07:48:43 --> File loaded: application/views/common/header.php
DEBUG - 2011-09-17 07:48:43 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-09-17 07:48:43 --> File loaded: application/views/common/footer.php
DEBUG - 2011-09-17 07:48:43 --> File loaded: application/views/layout/main.php
DEBUG - 2011-09-17 07:48:43 --> Final output sent to browser
DEBUG - 2011-09-17 07:48:43 --> Total execution time: 0.0439
DEBUG - 2011-09-17 07:48:43 --> Config Class Initialized
DEBUG - 2011-09-17 07:48:43 --> Hooks Class Initialized
DEBUG - 2011-09-17 07:48:43 --> Utf8 Class Initialized
DEBUG - 2011-09-17 07:48:43 --> UTF-8 Support Enabled
DEBUG - 2011-09-17 07:48:43 --> URI Class Initialized
DEBUG - 2011-09-17 07:48:43 --> Router Class Initialized
DEBUG - 2011-09-17 07:48:43 --> Output Class Initialized
DEBUG - 2011-09-17 07:48:43 --> Input Class Initialized
DEBUG - 2011-09-17 07:48:43 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-17 07:48:43 --> Language Class Initialized
DEBUG - 2011-09-17 07:48:43 --> Loader Class Initialized
DEBUG - 2011-09-17 07:48:43 --> Controller Class Initialized
DEBUG - 2011-09-17 07:48:43 --> Model Class Initialized
DEBUG - 2011-09-17 07:48:43 --> Model Class Initialized
DEBUG - 2011-09-17 07:48:43 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-17 07:48:43 --> Database Driver Class Initialized
DEBUG - 2011-09-17 07:48:44 --> Final output sent to browser
DEBUG - 2011-09-17 07:48:44 --> Total execution time: 0.5772
DEBUG - 2011-09-17 07:48:45 --> Config Class Initialized
DEBUG - 2011-09-17 07:48:45 --> Hooks Class Initialized
DEBUG - 2011-09-17 07:48:45 --> Utf8 Class Initialized
DEBUG - 2011-09-17 07:48:45 --> UTF-8 Support Enabled
DEBUG - 2011-09-17 07:48:45 --> URI Class Initialized
DEBUG - 2011-09-17 07:48:45 --> Router Class Initialized
ERROR - 2011-09-17 07:48:45 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-09-17 07:48:53 --> Config Class Initialized
DEBUG - 2011-09-17 07:48:53 --> Hooks Class Initialized
DEBUG - 2011-09-17 07:48:53 --> Utf8 Class Initialized
DEBUG - 2011-09-17 07:48:53 --> UTF-8 Support Enabled
DEBUG - 2011-09-17 07:48:53 --> URI Class Initialized
DEBUG - 2011-09-17 07:48:53 --> Router Class Initialized
DEBUG - 2011-09-17 07:48:53 --> Output Class Initialized
DEBUG - 2011-09-17 07:48:53 --> Input Class Initialized
DEBUG - 2011-09-17 07:48:53 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-17 07:48:53 --> Language Class Initialized
DEBUG - 2011-09-17 07:48:53 --> Loader Class Initialized
DEBUG - 2011-09-17 07:48:53 --> Controller Class Initialized
ERROR - 2011-09-17 07:48:53 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-09-17 07:48:53 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-09-17 07:48:53 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-09-17 07:48:53 --> Model Class Initialized
DEBUG - 2011-09-17 07:48:53 --> Model Class Initialized
DEBUG - 2011-09-17 07:48:53 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-17 07:48:53 --> Database Driver Class Initialized
DEBUG - 2011-09-17 07:48:53 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-09-17 07:48:53 --> Helper loaded: url_helper
DEBUG - 2011-09-17 07:48:53 --> File loaded: application/views/common/header.php
DEBUG - 2011-09-17 07:48:53 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-09-17 07:48:53 --> File loaded: application/views/common/footer.php
DEBUG - 2011-09-17 07:48:53 --> File loaded: application/views/layout/main.php
DEBUG - 2011-09-17 07:48:53 --> Final output sent to browser
DEBUG - 2011-09-17 07:48:53 --> Total execution time: 0.0308
DEBUG - 2011-09-17 07:48:54 --> Config Class Initialized
DEBUG - 2011-09-17 07:48:54 --> Hooks Class Initialized
DEBUG - 2011-09-17 07:48:54 --> Utf8 Class Initialized
DEBUG - 2011-09-17 07:48:54 --> UTF-8 Support Enabled
DEBUG - 2011-09-17 07:48:54 --> URI Class Initialized
DEBUG - 2011-09-17 07:48:54 --> Router Class Initialized
DEBUG - 2011-09-17 07:48:54 --> Output Class Initialized
DEBUG - 2011-09-17 07:48:54 --> Input Class Initialized
DEBUG - 2011-09-17 07:48:54 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-17 07:48:54 --> Language Class Initialized
DEBUG - 2011-09-17 07:48:54 --> Loader Class Initialized
DEBUG - 2011-09-17 07:48:54 --> Controller Class Initialized
DEBUG - 2011-09-17 07:48:54 --> Model Class Initialized
DEBUG - 2011-09-17 07:48:54 --> Model Class Initialized
DEBUG - 2011-09-17 07:48:54 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-17 07:48:54 --> Database Driver Class Initialized
DEBUG - 2011-09-17 07:48:54 --> Final output sent to browser
DEBUG - 2011-09-17 07:48:54 --> Total execution time: 0.6185
DEBUG - 2011-09-17 07:48:55 --> Config Class Initialized
DEBUG - 2011-09-17 07:48:55 --> Hooks Class Initialized
DEBUG - 2011-09-17 07:48:55 --> Utf8 Class Initialized
DEBUG - 2011-09-17 07:48:55 --> UTF-8 Support Enabled
DEBUG - 2011-09-17 07:48:55 --> URI Class Initialized
DEBUG - 2011-09-17 07:48:55 --> Router Class Initialized
ERROR - 2011-09-17 07:48:55 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-09-17 07:49:03 --> Config Class Initialized
DEBUG - 2011-09-17 07:49:03 --> Hooks Class Initialized
DEBUG - 2011-09-17 07:49:03 --> Utf8 Class Initialized
DEBUG - 2011-09-17 07:49:03 --> UTF-8 Support Enabled
DEBUG - 2011-09-17 07:49:03 --> URI Class Initialized
DEBUG - 2011-09-17 07:49:03 --> Router Class Initialized
DEBUG - 2011-09-17 07:49:03 --> Output Class Initialized
DEBUG - 2011-09-17 07:49:03 --> Input Class Initialized
DEBUG - 2011-09-17 07:49:03 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-17 07:49:03 --> Language Class Initialized
DEBUG - 2011-09-17 07:49:03 --> Loader Class Initialized
DEBUG - 2011-09-17 07:49:03 --> Controller Class Initialized
ERROR - 2011-09-17 07:49:03 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-09-17 07:49:03 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-09-17 07:49:03 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-09-17 07:49:03 --> Model Class Initialized
DEBUG - 2011-09-17 07:49:03 --> Model Class Initialized
DEBUG - 2011-09-17 07:49:03 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-17 07:49:03 --> Database Driver Class Initialized
DEBUG - 2011-09-17 07:49:03 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-09-17 07:49:03 --> Helper loaded: url_helper
DEBUG - 2011-09-17 07:49:03 --> File loaded: application/views/common/header.php
DEBUG - 2011-09-17 07:49:03 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-09-17 07:49:03 --> File loaded: application/views/common/footer.php
DEBUG - 2011-09-17 07:49:03 --> File loaded: application/views/layout/main.php
DEBUG - 2011-09-17 07:49:03 --> Final output sent to browser
DEBUG - 2011-09-17 07:49:03 --> Total execution time: 0.0369
DEBUG - 2011-09-17 07:49:04 --> Config Class Initialized
DEBUG - 2011-09-17 07:49:04 --> Hooks Class Initialized
DEBUG - 2011-09-17 07:49:04 --> Utf8 Class Initialized
DEBUG - 2011-09-17 07:49:04 --> UTF-8 Support Enabled
DEBUG - 2011-09-17 07:49:04 --> URI Class Initialized
DEBUG - 2011-09-17 07:49:04 --> Router Class Initialized
DEBUG - 2011-09-17 07:49:04 --> Output Class Initialized
DEBUG - 2011-09-17 07:49:04 --> Input Class Initialized
DEBUG - 2011-09-17 07:49:04 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-17 07:49:04 --> Language Class Initialized
DEBUG - 2011-09-17 07:49:04 --> Loader Class Initialized
DEBUG - 2011-09-17 07:49:04 --> Controller Class Initialized
DEBUG - 2011-09-17 07:49:04 --> Model Class Initialized
DEBUG - 2011-09-17 07:49:04 --> Model Class Initialized
DEBUG - 2011-09-17 07:49:04 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-17 07:49:04 --> Database Driver Class Initialized
DEBUG - 2011-09-17 07:49:05 --> Final output sent to browser
DEBUG - 2011-09-17 07:49:05 --> Total execution time: 1.2201
DEBUG - 2011-09-17 07:49:06 --> Config Class Initialized
DEBUG - 2011-09-17 07:49:06 --> Hooks Class Initialized
DEBUG - 2011-09-17 07:49:06 --> Utf8 Class Initialized
DEBUG - 2011-09-17 07:49:06 --> UTF-8 Support Enabled
DEBUG - 2011-09-17 07:49:06 --> URI Class Initialized
DEBUG - 2011-09-17 07:49:06 --> Router Class Initialized
ERROR - 2011-09-17 07:49:06 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-09-17 07:49:09 --> Config Class Initialized
DEBUG - 2011-09-17 07:49:09 --> Hooks Class Initialized
DEBUG - 2011-09-17 07:49:09 --> Utf8 Class Initialized
DEBUG - 2011-09-17 07:49:09 --> UTF-8 Support Enabled
DEBUG - 2011-09-17 07:49:09 --> URI Class Initialized
DEBUG - 2011-09-17 07:49:09 --> Router Class Initialized
DEBUG - 2011-09-17 07:49:09 --> Output Class Initialized
DEBUG - 2011-09-17 07:49:09 --> Input Class Initialized
DEBUG - 2011-09-17 07:49:09 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-17 07:49:09 --> Language Class Initialized
DEBUG - 2011-09-17 07:49:09 --> Loader Class Initialized
DEBUG - 2011-09-17 07:49:09 --> Controller Class Initialized
ERROR - 2011-09-17 07:49:09 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-09-17 07:49:09 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-09-17 07:49:09 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-09-17 07:49:09 --> Model Class Initialized
DEBUG - 2011-09-17 07:49:09 --> Model Class Initialized
DEBUG - 2011-09-17 07:49:09 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-17 07:49:09 --> Database Driver Class Initialized
DEBUG - 2011-09-17 07:49:09 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-09-17 07:49:09 --> Helper loaded: url_helper
DEBUG - 2011-09-17 07:49:09 --> File loaded: application/views/common/header.php
DEBUG - 2011-09-17 07:49:09 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-09-17 07:49:09 --> File loaded: application/views/common/footer.php
DEBUG - 2011-09-17 07:49:09 --> File loaded: application/views/layout/main.php
DEBUG - 2011-09-17 07:49:09 --> Final output sent to browser
DEBUG - 2011-09-17 07:49:09 --> Total execution time: 0.0288
DEBUG - 2011-09-17 07:49:10 --> Config Class Initialized
DEBUG - 2011-09-17 07:49:10 --> Hooks Class Initialized
DEBUG - 2011-09-17 07:49:10 --> Utf8 Class Initialized
DEBUG - 2011-09-17 07:49:10 --> UTF-8 Support Enabled
DEBUG - 2011-09-17 07:49:10 --> URI Class Initialized
DEBUG - 2011-09-17 07:49:10 --> Router Class Initialized
DEBUG - 2011-09-17 07:49:10 --> Output Class Initialized
DEBUG - 2011-09-17 07:49:10 --> Input Class Initialized
DEBUG - 2011-09-17 07:49:10 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-17 07:49:10 --> Language Class Initialized
DEBUG - 2011-09-17 07:49:10 --> Loader Class Initialized
DEBUG - 2011-09-17 07:49:10 --> Controller Class Initialized
DEBUG - 2011-09-17 07:49:10 --> Model Class Initialized
DEBUG - 2011-09-17 07:49:10 --> Model Class Initialized
DEBUG - 2011-09-17 07:49:10 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-17 07:49:10 --> Database Driver Class Initialized
DEBUG - 2011-09-17 07:49:10 --> Final output sent to browser
DEBUG - 2011-09-17 07:49:10 --> Total execution time: 0.3984
DEBUG - 2011-09-17 07:49:10 --> Config Class Initialized
DEBUG - 2011-09-17 07:49:10 --> Hooks Class Initialized
DEBUG - 2011-09-17 07:49:10 --> Utf8 Class Initialized
DEBUG - 2011-09-17 07:49:10 --> UTF-8 Support Enabled
DEBUG - 2011-09-17 07:49:10 --> URI Class Initialized
DEBUG - 2011-09-17 07:49:10 --> Router Class Initialized
ERROR - 2011-09-17 07:49:10 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-09-17 07:49:11 --> Config Class Initialized
DEBUG - 2011-09-17 07:49:11 --> Hooks Class Initialized
DEBUG - 2011-09-17 07:49:11 --> Utf8 Class Initialized
DEBUG - 2011-09-17 07:49:11 --> UTF-8 Support Enabled
DEBUG - 2011-09-17 07:49:11 --> URI Class Initialized
DEBUG - 2011-09-17 07:49:11 --> Router Class Initialized
DEBUG - 2011-09-17 07:49:11 --> Output Class Initialized
DEBUG - 2011-09-17 07:49:11 --> Input Class Initialized
DEBUG - 2011-09-17 07:49:11 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-17 07:49:11 --> Language Class Initialized
DEBUG - 2011-09-17 07:49:11 --> Loader Class Initialized
DEBUG - 2011-09-17 07:49:11 --> Controller Class Initialized
DEBUG - 2011-09-17 07:49:11 --> Model Class Initialized
DEBUG - 2011-09-17 07:49:11 --> Model Class Initialized
DEBUG - 2011-09-17 07:49:11 --> Model Class Initialized
DEBUG - 2011-09-17 07:49:11 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-17 07:49:11 --> Database Driver Class Initialized
DEBUG - 2011-09-17 07:49:11 --> File loaded: application/views/table/main.php
DEBUG - 2011-09-17 07:49:11 --> Helper loaded: url_helper
DEBUG - 2011-09-17 07:49:11 --> File loaded: application/views/common/header.php
DEBUG - 2011-09-17 07:49:11 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-09-17 07:49:11 --> File loaded: application/views/common/footer.php
DEBUG - 2011-09-17 07:49:11 --> File loaded: application/views/layout/main.php
DEBUG - 2011-09-17 07:49:11 --> Final output sent to browser
DEBUG - 2011-09-17 07:49:11 --> Total execution time: 0.0680
DEBUG - 2011-09-17 07:49:13 --> Config Class Initialized
DEBUG - 2011-09-17 07:49:13 --> Hooks Class Initialized
DEBUG - 2011-09-17 07:49:13 --> Utf8 Class Initialized
DEBUG - 2011-09-17 07:49:13 --> UTF-8 Support Enabled
DEBUG - 2011-09-17 07:49:13 --> URI Class Initialized
DEBUG - 2011-09-17 07:49:13 --> Router Class Initialized
ERROR - 2011-09-17 07:49:13 --> 404 Page Not Found --> robots.txt
DEBUG - 2011-09-17 07:49:13 --> Config Class Initialized
DEBUG - 2011-09-17 07:49:13 --> Hooks Class Initialized
DEBUG - 2011-09-17 07:49:13 --> Utf8 Class Initialized
DEBUG - 2011-09-17 07:49:13 --> UTF-8 Support Enabled
DEBUG - 2011-09-17 07:49:13 --> URI Class Initialized
DEBUG - 2011-09-17 07:49:13 --> Router Class Initialized
DEBUG - 2011-09-17 07:49:13 --> Output Class Initialized
DEBUG - 2011-09-17 07:49:13 --> Input Class Initialized
DEBUG - 2011-09-17 07:49:13 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-17 07:49:13 --> Language Class Initialized
DEBUG - 2011-09-17 07:49:13 --> Loader Class Initialized
DEBUG - 2011-09-17 07:49:13 --> Controller Class Initialized
ERROR - 2011-09-17 07:49:13 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-09-17 07:49:13 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-09-17 07:49:13 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-09-17 07:49:13 --> Model Class Initialized
DEBUG - 2011-09-17 07:49:13 --> Model Class Initialized
DEBUG - 2011-09-17 07:49:13 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-17 07:49:13 --> Database Driver Class Initialized
DEBUG - 2011-09-17 07:49:13 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-09-17 07:49:13 --> Helper loaded: url_helper
DEBUG - 2011-09-17 07:49:13 --> File loaded: application/views/common/header.php
DEBUG - 2011-09-17 07:49:13 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-09-17 07:49:13 --> File loaded: application/views/common/footer.php
DEBUG - 2011-09-17 07:49:13 --> File loaded: application/views/layout/main.php
DEBUG - 2011-09-17 07:49:13 --> Final output sent to browser
DEBUG - 2011-09-17 07:49:13 --> Total execution time: 0.0300
DEBUG - 2011-09-17 07:49:14 --> Config Class Initialized
DEBUG - 2011-09-17 07:49:14 --> Hooks Class Initialized
DEBUG - 2011-09-17 07:49:14 --> Utf8 Class Initialized
DEBUG - 2011-09-17 07:49:14 --> UTF-8 Support Enabled
DEBUG - 2011-09-17 07:49:14 --> URI Class Initialized
DEBUG - 2011-09-17 07:49:14 --> Router Class Initialized
DEBUG - 2011-09-17 07:49:14 --> Output Class Initialized
DEBUG - 2011-09-17 07:49:14 --> Input Class Initialized
DEBUG - 2011-09-17 07:49:14 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-17 07:49:14 --> Language Class Initialized
DEBUG - 2011-09-17 07:49:14 --> Loader Class Initialized
DEBUG - 2011-09-17 07:49:14 --> Controller Class Initialized
ERROR - 2011-09-17 07:49:14 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-09-17 07:49:14 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-09-17 07:49:14 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-09-17 07:49:14 --> Model Class Initialized
DEBUG - 2011-09-17 07:49:14 --> Model Class Initialized
DEBUG - 2011-09-17 07:49:14 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-17 07:49:14 --> Database Driver Class Initialized
DEBUG - 2011-09-17 07:49:14 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-09-17 07:49:14 --> Helper loaded: url_helper
DEBUG - 2011-09-17 07:49:14 --> File loaded: application/views/common/header.php
DEBUG - 2011-09-17 07:49:14 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-09-17 07:49:14 --> File loaded: application/views/common/footer.php
DEBUG - 2011-09-17 07:49:14 --> File loaded: application/views/layout/main.php
DEBUG - 2011-09-17 07:49:14 --> Final output sent to browser
DEBUG - 2011-09-17 07:49:14 --> Total execution time: 0.0488
DEBUG - 2011-09-17 07:49:14 --> Config Class Initialized
DEBUG - 2011-09-17 07:49:14 --> Hooks Class Initialized
DEBUG - 2011-09-17 07:49:14 --> Utf8 Class Initialized
DEBUG - 2011-09-17 07:49:14 --> UTF-8 Support Enabled
DEBUG - 2011-09-17 07:49:14 --> URI Class Initialized
DEBUG - 2011-09-17 07:49:14 --> Router Class Initialized
DEBUG - 2011-09-17 07:49:14 --> Output Class Initialized
DEBUG - 2011-09-17 07:49:14 --> Input Class Initialized
DEBUG - 2011-09-17 07:49:14 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-17 07:49:14 --> Language Class Initialized
DEBUG - 2011-09-17 07:49:14 --> Loader Class Initialized
DEBUG - 2011-09-17 07:49:14 --> Controller Class Initialized
DEBUG - 2011-09-17 07:49:14 --> Model Class Initialized
DEBUG - 2011-09-17 07:49:14 --> Model Class Initialized
DEBUG - 2011-09-17 07:49:14 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-17 07:49:14 --> Database Driver Class Initialized
DEBUG - 2011-09-17 07:49:15 --> Final output sent to browser
DEBUG - 2011-09-17 07:49:15 --> Total execution time: 0.7240
DEBUG - 2011-09-17 07:49:15 --> Config Class Initialized
DEBUG - 2011-09-17 07:49:15 --> Hooks Class Initialized
DEBUG - 2011-09-17 07:49:15 --> Utf8 Class Initialized
DEBUG - 2011-09-17 07:49:15 --> UTF-8 Support Enabled
DEBUG - 2011-09-17 07:49:15 --> URI Class Initialized
DEBUG - 2011-09-17 07:49:15 --> Router Class Initialized
ERROR - 2011-09-17 07:49:15 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-09-17 07:49:16 --> Config Class Initialized
DEBUG - 2011-09-17 07:49:16 --> Hooks Class Initialized
DEBUG - 2011-09-17 07:49:16 --> Utf8 Class Initialized
DEBUG - 2011-09-17 07:49:16 --> UTF-8 Support Enabled
DEBUG - 2011-09-17 07:49:16 --> URI Class Initialized
DEBUG - 2011-09-17 07:49:16 --> Router Class Initialized
DEBUG - 2011-09-17 07:49:16 --> Output Class Initialized
DEBUG - 2011-09-17 07:49:16 --> Input Class Initialized
DEBUG - 2011-09-17 07:49:16 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-17 07:49:16 --> Language Class Initialized
DEBUG - 2011-09-17 07:49:16 --> Loader Class Initialized
DEBUG - 2011-09-17 07:49:16 --> Controller Class Initialized
ERROR - 2011-09-17 07:49:16 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-09-17 07:49:16 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-09-17 07:49:16 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-09-17 07:49:16 --> Model Class Initialized
DEBUG - 2011-09-17 07:49:16 --> Model Class Initialized
DEBUG - 2011-09-17 07:49:16 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-17 07:49:16 --> Database Driver Class Initialized
DEBUG - 2011-09-17 07:49:16 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-09-17 07:49:16 --> Helper loaded: url_helper
DEBUG - 2011-09-17 07:49:16 --> File loaded: application/views/common/header.php
DEBUG - 2011-09-17 07:49:16 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-09-17 07:49:16 --> File loaded: application/views/common/footer.php
DEBUG - 2011-09-17 07:49:16 --> File loaded: application/views/layout/main.php
DEBUG - 2011-09-17 07:49:16 --> Final output sent to browser
DEBUG - 2011-09-17 07:49:16 --> Total execution time: 0.0268
DEBUG - 2011-09-17 07:49:19 --> Config Class Initialized
DEBUG - 2011-09-17 07:49:19 --> Hooks Class Initialized
DEBUG - 2011-09-17 07:49:19 --> Utf8 Class Initialized
DEBUG - 2011-09-17 07:49:19 --> UTF-8 Support Enabled
DEBUG - 2011-09-17 07:49:19 --> URI Class Initialized
DEBUG - 2011-09-17 07:49:19 --> Router Class Initialized
DEBUG - 2011-09-17 07:49:19 --> Output Class Initialized
DEBUG - 2011-09-17 07:49:19 --> Input Class Initialized
DEBUG - 2011-09-17 07:49:19 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-17 07:49:19 --> Language Class Initialized
DEBUG - 2011-09-17 07:49:19 --> Loader Class Initialized
DEBUG - 2011-09-17 07:49:19 --> Controller Class Initialized
ERROR - 2011-09-17 07:49:19 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-09-17 07:49:19 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-09-17 07:49:19 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-09-17 07:49:19 --> Model Class Initialized
DEBUG - 2011-09-17 07:49:19 --> Model Class Initialized
DEBUG - 2011-09-17 07:49:19 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-17 07:49:19 --> Database Driver Class Initialized
DEBUG - 2011-09-17 07:49:19 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-09-17 07:49:19 --> Helper loaded: url_helper
DEBUG - 2011-09-17 07:49:19 --> File loaded: application/views/common/header.php
DEBUG - 2011-09-17 07:49:19 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-09-17 07:49:19 --> File loaded: application/views/common/footer.php
DEBUG - 2011-09-17 07:49:19 --> File loaded: application/views/layout/main.php
DEBUG - 2011-09-17 07:49:19 --> Final output sent to browser
DEBUG - 2011-09-17 07:49:19 --> Total execution time: 0.0913
DEBUG - 2011-09-17 07:49:20 --> Config Class Initialized
DEBUG - 2011-09-17 07:49:20 --> Hooks Class Initialized
DEBUG - 2011-09-17 07:49:20 --> Utf8 Class Initialized
DEBUG - 2011-09-17 07:49:20 --> UTF-8 Support Enabled
DEBUG - 2011-09-17 07:49:20 --> URI Class Initialized
DEBUG - 2011-09-17 07:49:20 --> Router Class Initialized
DEBUG - 2011-09-17 07:49:20 --> Output Class Initialized
DEBUG - 2011-09-17 07:49:20 --> Input Class Initialized
DEBUG - 2011-09-17 07:49:20 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-17 07:49:20 --> Language Class Initialized
DEBUG - 2011-09-17 07:49:20 --> Loader Class Initialized
DEBUG - 2011-09-17 07:49:20 --> Controller Class Initialized
DEBUG - 2011-09-17 07:49:20 --> Model Class Initialized
DEBUG - 2011-09-17 07:49:20 --> Model Class Initialized
DEBUG - 2011-09-17 07:49:20 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-17 07:49:20 --> Database Driver Class Initialized
DEBUG - 2011-09-17 07:49:20 --> Final output sent to browser
DEBUG - 2011-09-17 07:49:20 --> Total execution time: 0.4306
DEBUG - 2011-09-17 07:49:20 --> Config Class Initialized
DEBUG - 2011-09-17 07:49:20 --> Hooks Class Initialized
DEBUG - 2011-09-17 07:49:20 --> Utf8 Class Initialized
DEBUG - 2011-09-17 07:49:20 --> UTF-8 Support Enabled
DEBUG - 2011-09-17 07:49:20 --> URI Class Initialized
DEBUG - 2011-09-17 07:49:20 --> Router Class Initialized
DEBUG - 2011-09-17 07:49:20 --> Output Class Initialized
DEBUG - 2011-09-17 07:49:20 --> Input Class Initialized
DEBUG - 2011-09-17 07:49:20 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-17 07:49:20 --> Language Class Initialized
DEBUG - 2011-09-17 07:49:20 --> Loader Class Initialized
DEBUG - 2011-09-17 07:49:20 --> Controller Class Initialized
ERROR - 2011-09-17 07:49:20 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-09-17 07:49:20 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-09-17 07:49:20 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-09-17 07:49:20 --> Model Class Initialized
DEBUG - 2011-09-17 07:49:20 --> Model Class Initialized
DEBUG - 2011-09-17 07:49:20 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-17 07:49:20 --> Database Driver Class Initialized
DEBUG - 2011-09-17 07:49:20 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-09-17 07:49:20 --> Helper loaded: url_helper
DEBUG - 2011-09-17 07:49:20 --> File loaded: application/views/common/header.php
DEBUG - 2011-09-17 07:49:20 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-09-17 07:49:20 --> File loaded: application/views/common/footer.php
DEBUG - 2011-09-17 07:49:20 --> File loaded: application/views/layout/main.php
DEBUG - 2011-09-17 07:49:20 --> Final output sent to browser
DEBUG - 2011-09-17 07:49:20 --> Total execution time: 0.0320
DEBUG - 2011-09-17 07:49:28 --> Config Class Initialized
DEBUG - 2011-09-17 07:49:28 --> Hooks Class Initialized
DEBUG - 2011-09-17 07:49:28 --> Utf8 Class Initialized
DEBUG - 2011-09-17 07:49:28 --> UTF-8 Support Enabled
DEBUG - 2011-09-17 07:49:28 --> URI Class Initialized
DEBUG - 2011-09-17 07:49:28 --> Router Class Initialized
DEBUG - 2011-09-17 07:49:28 --> Output Class Initialized
DEBUG - 2011-09-17 07:49:28 --> Input Class Initialized
DEBUG - 2011-09-17 07:49:28 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-17 07:49:28 --> Language Class Initialized
DEBUG - 2011-09-17 07:49:28 --> Loader Class Initialized
DEBUG - 2011-09-17 07:49:28 --> Controller Class Initialized
ERROR - 2011-09-17 07:49:28 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-09-17 07:49:28 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-09-17 07:49:28 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-09-17 07:49:28 --> Model Class Initialized
DEBUG - 2011-09-17 07:49:28 --> Model Class Initialized
DEBUG - 2011-09-17 07:49:28 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-17 07:49:28 --> Database Driver Class Initialized
DEBUG - 2011-09-17 07:49:29 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-09-17 07:49:29 --> Helper loaded: url_helper
DEBUG - 2011-09-17 07:49:29 --> File loaded: application/views/common/header.php
DEBUG - 2011-09-17 07:49:29 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-09-17 07:49:29 --> File loaded: application/views/common/footer.php
DEBUG - 2011-09-17 07:49:29 --> File loaded: application/views/layout/main.php
DEBUG - 2011-09-17 07:49:29 --> Final output sent to browser
DEBUG - 2011-09-17 07:49:29 --> Total execution time: 0.0367
DEBUG - 2011-09-17 07:49:29 --> Config Class Initialized
DEBUG - 2011-09-17 07:49:29 --> Hooks Class Initialized
DEBUG - 2011-09-17 07:49:29 --> Utf8 Class Initialized
DEBUG - 2011-09-17 07:49:29 --> UTF-8 Support Enabled
DEBUG - 2011-09-17 07:49:29 --> URI Class Initialized
DEBUG - 2011-09-17 07:49:29 --> Router Class Initialized
ERROR - 2011-09-17 07:49:29 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-09-17 07:49:29 --> Config Class Initialized
DEBUG - 2011-09-17 07:49:29 --> Hooks Class Initialized
DEBUG - 2011-09-17 07:49:29 --> Utf8 Class Initialized
DEBUG - 2011-09-17 07:49:29 --> UTF-8 Support Enabled
DEBUG - 2011-09-17 07:49:29 --> URI Class Initialized
DEBUG - 2011-09-17 07:49:29 --> Router Class Initialized
DEBUG - 2011-09-17 07:49:29 --> Output Class Initialized
DEBUG - 2011-09-17 07:49:29 --> Input Class Initialized
DEBUG - 2011-09-17 07:49:29 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-17 07:49:29 --> Language Class Initialized
DEBUG - 2011-09-17 07:49:29 --> Loader Class Initialized
DEBUG - 2011-09-17 07:49:29 --> Controller Class Initialized
DEBUG - 2011-09-17 07:49:29 --> Model Class Initialized
DEBUG - 2011-09-17 07:49:29 --> Model Class Initialized
DEBUG - 2011-09-17 07:49:29 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-17 07:49:29 --> Database Driver Class Initialized
DEBUG - 2011-09-17 07:49:30 --> Final output sent to browser
DEBUG - 2011-09-17 07:49:30 --> Total execution time: 0.5301
DEBUG - 2011-09-17 07:49:30 --> Config Class Initialized
DEBUG - 2011-09-17 07:49:30 --> Hooks Class Initialized
DEBUG - 2011-09-17 07:49:30 --> Utf8 Class Initialized
DEBUG - 2011-09-17 07:49:30 --> UTF-8 Support Enabled
DEBUG - 2011-09-17 07:49:30 --> URI Class Initialized
DEBUG - 2011-09-17 07:49:30 --> Router Class Initialized
ERROR - 2011-09-17 07:49:30 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-09-17 07:49:35 --> Config Class Initialized
DEBUG - 2011-09-17 07:49:35 --> Hooks Class Initialized
DEBUG - 2011-09-17 07:49:35 --> Utf8 Class Initialized
DEBUG - 2011-09-17 07:49:35 --> UTF-8 Support Enabled
DEBUG - 2011-09-17 07:49:35 --> URI Class Initialized
DEBUG - 2011-09-17 07:49:35 --> Router Class Initialized
DEBUG - 2011-09-17 07:49:35 --> Output Class Initialized
DEBUG - 2011-09-17 07:49:35 --> Input Class Initialized
DEBUG - 2011-09-17 07:49:35 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-17 07:49:35 --> Language Class Initialized
DEBUG - 2011-09-17 07:49:35 --> Loader Class Initialized
DEBUG - 2011-09-17 07:49:35 --> Controller Class Initialized
ERROR - 2011-09-17 07:49:35 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-09-17 07:49:35 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-09-17 07:49:35 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-09-17 07:49:35 --> Model Class Initialized
DEBUG - 2011-09-17 07:49:35 --> Model Class Initialized
DEBUG - 2011-09-17 07:49:35 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-17 07:49:35 --> Database Driver Class Initialized
DEBUG - 2011-09-17 07:49:35 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-09-17 07:49:35 --> Helper loaded: url_helper
DEBUG - 2011-09-17 07:49:35 --> File loaded: application/views/common/header.php
DEBUG - 2011-09-17 07:49:35 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-09-17 07:49:35 --> File loaded: application/views/common/footer.php
DEBUG - 2011-09-17 07:49:35 --> File loaded: application/views/layout/main.php
DEBUG - 2011-09-17 07:49:35 --> Final output sent to browser
DEBUG - 2011-09-17 07:49:35 --> Total execution time: 0.0279
DEBUG - 2011-09-17 07:49:36 --> Config Class Initialized
DEBUG - 2011-09-17 07:49:36 --> Hooks Class Initialized
DEBUG - 2011-09-17 07:49:36 --> Utf8 Class Initialized
DEBUG - 2011-09-17 07:49:36 --> UTF-8 Support Enabled
DEBUG - 2011-09-17 07:49:36 --> URI Class Initialized
DEBUG - 2011-09-17 07:49:36 --> Router Class Initialized
DEBUG - 2011-09-17 07:49:36 --> Output Class Initialized
DEBUG - 2011-09-17 07:49:36 --> Input Class Initialized
DEBUG - 2011-09-17 07:49:36 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-17 07:49:36 --> Language Class Initialized
DEBUG - 2011-09-17 07:49:36 --> Loader Class Initialized
DEBUG - 2011-09-17 07:49:36 --> Controller Class Initialized
DEBUG - 2011-09-17 07:49:36 --> Model Class Initialized
DEBUG - 2011-09-17 07:49:36 --> Model Class Initialized
DEBUG - 2011-09-17 07:49:36 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-17 07:49:36 --> Database Driver Class Initialized
DEBUG - 2011-09-17 07:49:36 --> Final output sent to browser
DEBUG - 2011-09-17 07:49:36 --> Total execution time: 0.4618
DEBUG - 2011-09-17 07:49:37 --> Config Class Initialized
DEBUG - 2011-09-17 07:49:37 --> Hooks Class Initialized
DEBUG - 2011-09-17 07:49:37 --> Utf8 Class Initialized
DEBUG - 2011-09-17 07:49:37 --> UTF-8 Support Enabled
DEBUG - 2011-09-17 07:49:37 --> URI Class Initialized
DEBUG - 2011-09-17 07:49:37 --> Router Class Initialized
ERROR - 2011-09-17 07:49:37 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-09-17 07:49:47 --> Config Class Initialized
DEBUG - 2011-09-17 07:49:47 --> Hooks Class Initialized
DEBUG - 2011-09-17 07:49:47 --> Utf8 Class Initialized
DEBUG - 2011-09-17 07:49:47 --> UTF-8 Support Enabled
DEBUG - 2011-09-17 07:49:47 --> URI Class Initialized
DEBUG - 2011-09-17 07:49:47 --> Router Class Initialized
DEBUG - 2011-09-17 07:49:47 --> Output Class Initialized
DEBUG - 2011-09-17 07:49:47 --> Input Class Initialized
DEBUG - 2011-09-17 07:49:47 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-17 07:49:47 --> Language Class Initialized
DEBUG - 2011-09-17 07:49:47 --> Loader Class Initialized
DEBUG - 2011-09-17 07:49:47 --> Controller Class Initialized
ERROR - 2011-09-17 07:49:47 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-09-17 07:49:47 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-09-17 07:49:47 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-09-17 07:49:47 --> Model Class Initialized
DEBUG - 2011-09-17 07:49:47 --> Model Class Initialized
DEBUG - 2011-09-17 07:49:47 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-17 07:49:47 --> Database Driver Class Initialized
DEBUG - 2011-09-17 07:49:47 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-09-17 07:49:47 --> Helper loaded: url_helper
DEBUG - 2011-09-17 07:49:47 --> File loaded: application/views/common/header.php
DEBUG - 2011-09-17 07:49:47 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-09-17 07:49:47 --> File loaded: application/views/common/footer.php
DEBUG - 2011-09-17 07:49:47 --> File loaded: application/views/layout/main.php
DEBUG - 2011-09-17 07:49:47 --> Final output sent to browser
DEBUG - 2011-09-17 07:49:47 --> Total execution time: 0.0275
DEBUG - 2011-09-17 07:49:48 --> Config Class Initialized
DEBUG - 2011-09-17 07:49:48 --> Hooks Class Initialized
DEBUG - 2011-09-17 07:49:48 --> Utf8 Class Initialized
DEBUG - 2011-09-17 07:49:48 --> UTF-8 Support Enabled
DEBUG - 2011-09-17 07:49:48 --> URI Class Initialized
DEBUG - 2011-09-17 07:49:48 --> Router Class Initialized
DEBUG - 2011-09-17 07:49:48 --> Output Class Initialized
DEBUG - 2011-09-17 07:49:48 --> Input Class Initialized
DEBUG - 2011-09-17 07:49:48 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-17 07:49:48 --> Language Class Initialized
DEBUG - 2011-09-17 07:49:48 --> Loader Class Initialized
DEBUG - 2011-09-17 07:49:48 --> Controller Class Initialized
DEBUG - 2011-09-17 07:49:48 --> Model Class Initialized
DEBUG - 2011-09-17 07:49:48 --> Model Class Initialized
DEBUG - 2011-09-17 07:49:48 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-17 07:49:48 --> Database Driver Class Initialized
DEBUG - 2011-09-17 07:49:48 --> Final output sent to browser
DEBUG - 2011-09-17 07:49:48 --> Total execution time: 0.4953
DEBUG - 2011-09-17 07:49:49 --> Config Class Initialized
DEBUG - 2011-09-17 07:49:49 --> Hooks Class Initialized
DEBUG - 2011-09-17 07:49:49 --> Utf8 Class Initialized
DEBUG - 2011-09-17 07:49:49 --> UTF-8 Support Enabled
DEBUG - 2011-09-17 07:49:49 --> URI Class Initialized
DEBUG - 2011-09-17 07:49:49 --> Router Class Initialized
DEBUG - 2011-09-17 07:49:49 --> Output Class Initialized
DEBUG - 2011-09-17 07:49:49 --> Input Class Initialized
DEBUG - 2011-09-17 07:49:49 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-17 07:49:49 --> Language Class Initialized
DEBUG - 2011-09-17 07:49:49 --> Loader Class Initialized
DEBUG - 2011-09-17 07:49:49 --> Controller Class Initialized
DEBUG - 2011-09-17 07:49:49 --> Model Class Initialized
DEBUG - 2011-09-17 07:49:49 --> Model Class Initialized
DEBUG - 2011-09-17 07:49:49 --> Model Class Initialized
DEBUG - 2011-09-17 07:49:49 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-17 07:49:49 --> Database Driver Class Initialized
DEBUG - 2011-09-17 07:49:49 --> Config Class Initialized
DEBUG - 2011-09-17 07:49:49 --> Hooks Class Initialized
DEBUG - 2011-09-17 07:49:49 --> Utf8 Class Initialized
DEBUG - 2011-09-17 07:49:49 --> UTF-8 Support Enabled
DEBUG - 2011-09-17 07:49:49 --> URI Class Initialized
DEBUG - 2011-09-17 07:49:49 --> Router Class Initialized
ERROR - 2011-09-17 07:49:49 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-09-17 07:49:49 --> File loaded: application/views/table/main.php
DEBUG - 2011-09-17 07:49:49 --> Helper loaded: url_helper
DEBUG - 2011-09-17 07:49:49 --> File loaded: application/views/common/header.php
DEBUG - 2011-09-17 07:49:49 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-09-17 07:49:49 --> File loaded: application/views/common/footer.php
DEBUG - 2011-09-17 07:49:49 --> File loaded: application/views/layout/main.php
DEBUG - 2011-09-17 07:49:49 --> Final output sent to browser
DEBUG - 2011-09-17 07:49:49 --> Total execution time: 0.5929
DEBUG - 2011-09-17 07:49:52 --> Config Class Initialized
DEBUG - 2011-09-17 07:49:52 --> Hooks Class Initialized
DEBUG - 2011-09-17 07:49:52 --> Utf8 Class Initialized
DEBUG - 2011-09-17 07:49:52 --> UTF-8 Support Enabled
DEBUG - 2011-09-17 07:49:52 --> URI Class Initialized
DEBUG - 2011-09-17 07:49:52 --> Router Class Initialized
DEBUG - 2011-09-17 07:49:52 --> Output Class Initialized
DEBUG - 2011-09-17 07:49:52 --> Input Class Initialized
DEBUG - 2011-09-17 07:49:52 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-17 07:49:52 --> Language Class Initialized
DEBUG - 2011-09-17 07:49:52 --> Loader Class Initialized
DEBUG - 2011-09-17 07:49:52 --> Controller Class Initialized
DEBUG - 2011-09-17 07:49:52 --> Model Class Initialized
DEBUG - 2011-09-17 07:49:52 --> Model Class Initialized
DEBUG - 2011-09-17 07:49:52 --> Model Class Initialized
DEBUG - 2011-09-17 07:49:52 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-17 07:49:52 --> Database Driver Class Initialized
DEBUG - 2011-09-17 07:49:52 --> File loaded: application/views/table/main.php
DEBUG - 2011-09-17 07:49:52 --> Helper loaded: url_helper
DEBUG - 2011-09-17 07:49:52 --> File loaded: application/views/common/header.php
DEBUG - 2011-09-17 07:49:52 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-09-17 07:49:52 --> File loaded: application/views/common/footer.php
DEBUG - 2011-09-17 07:49:52 --> File loaded: application/views/layout/main.php
DEBUG - 2011-09-17 07:49:52 --> Final output sent to browser
DEBUG - 2011-09-17 07:49:52 --> Total execution time: 0.0466
DEBUG - 2011-09-17 07:50:00 --> Config Class Initialized
DEBUG - 2011-09-17 07:50:00 --> Hooks Class Initialized
DEBUG - 2011-09-17 07:50:00 --> Utf8 Class Initialized
DEBUG - 2011-09-17 07:50:00 --> UTF-8 Support Enabled
DEBUG - 2011-09-17 07:50:00 --> URI Class Initialized
DEBUG - 2011-09-17 07:50:00 --> Router Class Initialized
DEBUG - 2011-09-17 07:50:00 --> Output Class Initialized
DEBUG - 2011-09-17 07:50:00 --> Input Class Initialized
DEBUG - 2011-09-17 07:50:00 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-17 07:50:00 --> Language Class Initialized
DEBUG - 2011-09-17 07:50:00 --> Loader Class Initialized
DEBUG - 2011-09-17 07:50:00 --> Controller Class Initialized
DEBUG - 2011-09-17 07:50:00 --> Model Class Initialized
DEBUG - 2011-09-17 07:50:00 --> Model Class Initialized
DEBUG - 2011-09-17 07:50:00 --> Model Class Initialized
DEBUG - 2011-09-17 07:50:00 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-17 07:50:01 --> Database Driver Class Initialized
DEBUG - 2011-09-17 07:50:01 --> File loaded: application/views/table/main.php
DEBUG - 2011-09-17 07:50:01 --> Helper loaded: url_helper
DEBUG - 2011-09-17 07:50:01 --> File loaded: application/views/common/header.php
DEBUG - 2011-09-17 07:50:01 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-09-17 07:50:01 --> File loaded: application/views/common/footer.php
DEBUG - 2011-09-17 07:50:01 --> File loaded: application/views/layout/main.php
DEBUG - 2011-09-17 07:50:01 --> Final output sent to browser
DEBUG - 2011-09-17 07:50:01 --> Total execution time: 0.6908
DEBUG - 2011-09-17 07:50:12 --> Config Class Initialized
DEBUG - 2011-09-17 07:50:12 --> Hooks Class Initialized
DEBUG - 2011-09-17 07:50:12 --> Utf8 Class Initialized
DEBUG - 2011-09-17 07:50:12 --> UTF-8 Support Enabled
DEBUG - 2011-09-17 07:50:12 --> URI Class Initialized
DEBUG - 2011-09-17 07:50:12 --> Router Class Initialized
DEBUG - 2011-09-17 07:50:12 --> Output Class Initialized
DEBUG - 2011-09-17 07:50:12 --> Input Class Initialized
DEBUG - 2011-09-17 07:50:12 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-17 07:50:12 --> Language Class Initialized
DEBUG - 2011-09-17 07:50:12 --> Loader Class Initialized
DEBUG - 2011-09-17 07:50:12 --> Controller Class Initialized
DEBUG - 2011-09-17 07:50:12 --> Model Class Initialized
DEBUG - 2011-09-17 07:50:12 --> Model Class Initialized
DEBUG - 2011-09-17 07:50:12 --> Model Class Initialized
DEBUG - 2011-09-17 07:50:12 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-17 07:50:13 --> Database Driver Class Initialized
DEBUG - 2011-09-17 07:50:13 --> File loaded: application/views/table/main.php
DEBUG - 2011-09-17 07:50:13 --> Helper loaded: url_helper
DEBUG - 2011-09-17 07:50:13 --> File loaded: application/views/common/header.php
DEBUG - 2011-09-17 07:50:13 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-09-17 07:50:13 --> File loaded: application/views/common/footer.php
DEBUG - 2011-09-17 07:50:13 --> File loaded: application/views/layout/main.php
DEBUG - 2011-09-17 07:50:13 --> Final output sent to browser
DEBUG - 2011-09-17 07:50:13 --> Total execution time: 0.0674
DEBUG - 2011-09-17 07:50:46 --> Config Class Initialized
DEBUG - 2011-09-17 07:50:46 --> Hooks Class Initialized
DEBUG - 2011-09-17 07:50:46 --> Utf8 Class Initialized
DEBUG - 2011-09-17 07:50:46 --> UTF-8 Support Enabled
DEBUG - 2011-09-17 07:50:46 --> URI Class Initialized
DEBUG - 2011-09-17 07:50:46 --> Router Class Initialized
DEBUG - 2011-09-17 07:50:46 --> Output Class Initialized
DEBUG - 2011-09-17 07:50:46 --> Input Class Initialized
DEBUG - 2011-09-17 07:50:46 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-17 07:50:46 --> Language Class Initialized
DEBUG - 2011-09-17 07:50:46 --> Loader Class Initialized
DEBUG - 2011-09-17 07:50:46 --> Controller Class Initialized
DEBUG - 2011-09-17 07:50:46 --> Model Class Initialized
DEBUG - 2011-09-17 07:50:46 --> Model Class Initialized
DEBUG - 2011-09-17 07:50:46 --> Model Class Initialized
DEBUG - 2011-09-17 07:50:46 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-17 07:50:46 --> Database Driver Class Initialized
DEBUG - 2011-09-17 07:50:47 --> File loaded: application/views/table/main.php
DEBUG - 2011-09-17 07:50:47 --> Helper loaded: url_helper
DEBUG - 2011-09-17 07:50:47 --> File loaded: application/views/common/header.php
DEBUG - 2011-09-17 07:50:47 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-09-17 07:50:47 --> File loaded: application/views/common/footer.php
DEBUG - 2011-09-17 07:50:47 --> File loaded: application/views/layout/main.php
DEBUG - 2011-09-17 07:50:47 --> Final output sent to browser
DEBUG - 2011-09-17 07:50:47 --> Total execution time: 0.6500
DEBUG - 2011-09-17 07:50:52 --> Config Class Initialized
DEBUG - 2011-09-17 07:50:52 --> Hooks Class Initialized
DEBUG - 2011-09-17 07:50:52 --> Utf8 Class Initialized
DEBUG - 2011-09-17 07:50:52 --> UTF-8 Support Enabled
DEBUG - 2011-09-17 07:50:52 --> URI Class Initialized
DEBUG - 2011-09-17 07:50:52 --> Router Class Initialized
DEBUG - 2011-09-17 07:50:52 --> Output Class Initialized
DEBUG - 2011-09-17 07:50:52 --> Input Class Initialized
DEBUG - 2011-09-17 07:50:52 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-17 07:50:52 --> Language Class Initialized
DEBUG - 2011-09-17 07:50:52 --> Loader Class Initialized
DEBUG - 2011-09-17 07:50:52 --> Controller Class Initialized
DEBUG - 2011-09-17 07:50:52 --> Model Class Initialized
DEBUG - 2011-09-17 07:50:52 --> Model Class Initialized
DEBUG - 2011-09-17 07:50:52 --> Model Class Initialized
DEBUG - 2011-09-17 07:50:52 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-17 07:50:52 --> Database Driver Class Initialized
DEBUG - 2011-09-17 07:50:52 --> File loaded: application/views/table/main.php
DEBUG - 2011-09-17 07:50:52 --> Helper loaded: url_helper
DEBUG - 2011-09-17 07:50:52 --> File loaded: application/views/common/header.php
DEBUG - 2011-09-17 07:50:52 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-09-17 07:50:52 --> File loaded: application/views/common/footer.php
DEBUG - 2011-09-17 07:50:52 --> File loaded: application/views/layout/main.php
DEBUG - 2011-09-17 07:50:52 --> Final output sent to browser
DEBUG - 2011-09-17 07:50:52 --> Total execution time: 0.2902
DEBUG - 2011-09-17 07:51:00 --> Config Class Initialized
DEBUG - 2011-09-17 07:51:00 --> Hooks Class Initialized
DEBUG - 2011-09-17 07:51:00 --> Utf8 Class Initialized
DEBUG - 2011-09-17 07:51:00 --> UTF-8 Support Enabled
DEBUG - 2011-09-17 07:51:00 --> URI Class Initialized
DEBUG - 2011-09-17 07:51:00 --> Router Class Initialized
DEBUG - 2011-09-17 07:51:00 --> Output Class Initialized
DEBUG - 2011-09-17 07:51:00 --> Input Class Initialized
DEBUG - 2011-09-17 07:51:00 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-17 07:51:00 --> Language Class Initialized
DEBUG - 2011-09-17 07:51:00 --> Loader Class Initialized
DEBUG - 2011-09-17 07:51:00 --> Controller Class Initialized
DEBUG - 2011-09-17 07:51:00 --> Model Class Initialized
DEBUG - 2011-09-17 07:51:00 --> Model Class Initialized
DEBUG - 2011-09-17 07:51:00 --> Model Class Initialized
DEBUG - 2011-09-17 07:51:00 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-17 07:51:01 --> Database Driver Class Initialized
DEBUG - 2011-09-17 07:51:01 --> File loaded: application/views/table/main.php
DEBUG - 2011-09-17 07:51:01 --> Helper loaded: url_helper
DEBUG - 2011-09-17 07:51:01 --> File loaded: application/views/common/header.php
DEBUG - 2011-09-17 07:51:01 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-09-17 07:51:01 --> File loaded: application/views/common/footer.php
DEBUG - 2011-09-17 07:51:01 --> File loaded: application/views/layout/main.php
DEBUG - 2011-09-17 07:51:01 --> Final output sent to browser
DEBUG - 2011-09-17 07:51:01 --> Total execution time: 0.6506
DEBUG - 2011-09-17 07:51:03 --> Config Class Initialized
DEBUG - 2011-09-17 07:51:03 --> Hooks Class Initialized
DEBUG - 2011-09-17 07:51:03 --> Utf8 Class Initialized
DEBUG - 2011-09-17 07:51:03 --> UTF-8 Support Enabled
DEBUG - 2011-09-17 07:51:03 --> URI Class Initialized
DEBUG - 2011-09-17 07:51:03 --> Router Class Initialized
DEBUG - 2011-09-17 07:51:03 --> Output Class Initialized
DEBUG - 2011-09-17 07:51:03 --> Input Class Initialized
DEBUG - 2011-09-17 07:51:03 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-17 07:51:03 --> Language Class Initialized
DEBUG - 2011-09-17 07:51:03 --> Loader Class Initialized
DEBUG - 2011-09-17 07:51:03 --> Controller Class Initialized
DEBUG - 2011-09-17 07:51:03 --> Model Class Initialized
DEBUG - 2011-09-17 07:51:03 --> Model Class Initialized
DEBUG - 2011-09-17 07:51:03 --> Model Class Initialized
DEBUG - 2011-09-17 07:51:03 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-17 07:51:03 --> Database Driver Class Initialized
DEBUG - 2011-09-17 07:51:03 --> File loaded: application/views/table/main.php
DEBUG - 2011-09-17 07:51:03 --> Helper loaded: url_helper
DEBUG - 2011-09-17 07:51:03 --> File loaded: application/views/common/header.php
DEBUG - 2011-09-17 07:51:03 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-09-17 07:51:03 --> File loaded: application/views/common/footer.php
DEBUG - 2011-09-17 07:51:03 --> File loaded: application/views/layout/main.php
DEBUG - 2011-09-17 07:51:03 --> Final output sent to browser
DEBUG - 2011-09-17 07:51:03 --> Total execution time: 0.0979
DEBUG - 2011-09-17 07:51:15 --> Config Class Initialized
DEBUG - 2011-09-17 07:51:15 --> Hooks Class Initialized
DEBUG - 2011-09-17 07:51:15 --> Utf8 Class Initialized
DEBUG - 2011-09-17 07:51:15 --> UTF-8 Support Enabled
DEBUG - 2011-09-17 07:51:15 --> URI Class Initialized
DEBUG - 2011-09-17 07:51:15 --> Router Class Initialized
DEBUG - 2011-09-17 07:51:15 --> Output Class Initialized
DEBUG - 2011-09-17 07:51:15 --> Input Class Initialized
DEBUG - 2011-09-17 07:51:15 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-17 07:51:15 --> Language Class Initialized
DEBUG - 2011-09-17 07:51:15 --> Loader Class Initialized
DEBUG - 2011-09-17 07:51:15 --> Controller Class Initialized
DEBUG - 2011-09-17 07:51:15 --> Model Class Initialized
DEBUG - 2011-09-17 07:51:15 --> Model Class Initialized
DEBUG - 2011-09-17 07:51:15 --> Model Class Initialized
DEBUG - 2011-09-17 07:51:15 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-17 07:51:15 --> Database Driver Class Initialized
DEBUG - 2011-09-17 07:51:16 --> File loaded: application/views/table/main.php
DEBUG - 2011-09-17 07:51:16 --> Helper loaded: url_helper
DEBUG - 2011-09-17 07:51:16 --> File loaded: application/views/common/header.php
DEBUG - 2011-09-17 07:51:16 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-09-17 07:51:16 --> File loaded: application/views/common/footer.php
DEBUG - 2011-09-17 07:51:16 --> File loaded: application/views/layout/main.php
DEBUG - 2011-09-17 07:51:16 --> Final output sent to browser
DEBUG - 2011-09-17 07:51:16 --> Total execution time: 0.4433
DEBUG - 2011-09-17 07:51:16 --> Config Class Initialized
DEBUG - 2011-09-17 07:51:16 --> Hooks Class Initialized
DEBUG - 2011-09-17 07:51:16 --> Utf8 Class Initialized
DEBUG - 2011-09-17 07:51:16 --> UTF-8 Support Enabled
DEBUG - 2011-09-17 07:51:16 --> URI Class Initialized
DEBUG - 2011-09-17 07:51:16 --> Router Class Initialized
DEBUG - 2011-09-17 07:51:16 --> Output Class Initialized
DEBUG - 2011-09-17 07:51:16 --> Input Class Initialized
DEBUG - 2011-09-17 07:51:16 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-17 07:51:16 --> Language Class Initialized
DEBUG - 2011-09-17 07:51:16 --> Loader Class Initialized
DEBUG - 2011-09-17 07:51:16 --> Controller Class Initialized
DEBUG - 2011-09-17 07:51:16 --> Model Class Initialized
DEBUG - 2011-09-17 07:51:16 --> Model Class Initialized
DEBUG - 2011-09-17 07:51:16 --> Model Class Initialized
DEBUG - 2011-09-17 07:51:16 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-17 07:51:16 --> Database Driver Class Initialized
DEBUG - 2011-09-17 07:51:16 --> File loaded: application/views/table/main.php
DEBUG - 2011-09-17 07:51:16 --> Helper loaded: url_helper
DEBUG - 2011-09-17 07:51:16 --> File loaded: application/views/common/header.php
DEBUG - 2011-09-17 07:51:16 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-09-17 07:51:16 --> File loaded: application/views/common/footer.php
DEBUG - 2011-09-17 07:51:16 --> File loaded: application/views/layout/main.php
DEBUG - 2011-09-17 07:51:16 --> Final output sent to browser
DEBUG - 2011-09-17 07:51:16 --> Total execution time: 0.1853
DEBUG - 2011-09-17 07:51:19 --> Config Class Initialized
DEBUG - 2011-09-17 07:51:19 --> Hooks Class Initialized
DEBUG - 2011-09-17 07:51:19 --> Utf8 Class Initialized
DEBUG - 2011-09-17 07:51:19 --> UTF-8 Support Enabled
DEBUG - 2011-09-17 07:51:19 --> URI Class Initialized
DEBUG - 2011-09-17 07:51:19 --> Router Class Initialized
ERROR - 2011-09-17 07:51:19 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-09-17 07:51:27 --> Config Class Initialized
DEBUG - 2011-09-17 07:51:27 --> Hooks Class Initialized
DEBUG - 2011-09-17 07:51:27 --> Utf8 Class Initialized
DEBUG - 2011-09-17 07:51:27 --> UTF-8 Support Enabled
DEBUG - 2011-09-17 07:51:27 --> URI Class Initialized
DEBUG - 2011-09-17 07:51:27 --> Router Class Initialized
DEBUG - 2011-09-17 07:51:27 --> Output Class Initialized
DEBUG - 2011-09-17 07:51:27 --> Input Class Initialized
DEBUG - 2011-09-17 07:51:27 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-17 07:51:27 --> Language Class Initialized
DEBUG - 2011-09-17 07:51:27 --> Loader Class Initialized
DEBUG - 2011-09-17 07:51:27 --> Controller Class Initialized
DEBUG - 2011-09-17 07:51:27 --> Model Class Initialized
DEBUG - 2011-09-17 07:51:27 --> Model Class Initialized
DEBUG - 2011-09-17 07:51:27 --> Model Class Initialized
DEBUG - 2011-09-17 07:51:27 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-17 07:51:27 --> Database Driver Class Initialized
DEBUG - 2011-09-17 07:51:27 --> File loaded: application/views/table/main.php
DEBUG - 2011-09-17 07:51:27 --> Helper loaded: url_helper
DEBUG - 2011-09-17 07:51:27 --> File loaded: application/views/common/header.php
DEBUG - 2011-09-17 07:51:27 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-09-17 07:51:27 --> File loaded: application/views/common/footer.php
DEBUG - 2011-09-17 07:51:27 --> File loaded: application/views/layout/main.php
DEBUG - 2011-09-17 07:51:27 --> Final output sent to browser
DEBUG - 2011-09-17 07:51:27 --> Total execution time: 0.0740
DEBUG - 2011-09-17 07:58:48 --> Config Class Initialized
DEBUG - 2011-09-17 07:58:48 --> Hooks Class Initialized
DEBUG - 2011-09-17 07:58:48 --> Utf8 Class Initialized
DEBUG - 2011-09-17 07:58:48 --> UTF-8 Support Enabled
DEBUG - 2011-09-17 07:58:48 --> URI Class Initialized
DEBUG - 2011-09-17 07:58:48 --> Router Class Initialized
DEBUG - 2011-09-17 07:58:48 --> Output Class Initialized
DEBUG - 2011-09-17 07:58:48 --> Input Class Initialized
DEBUG - 2011-09-17 07:58:48 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-17 07:58:48 --> Language Class Initialized
DEBUG - 2011-09-17 07:58:48 --> Loader Class Initialized
DEBUG - 2011-09-17 07:58:48 --> Controller Class Initialized
DEBUG - 2011-09-17 07:58:48 --> Model Class Initialized
DEBUG - 2011-09-17 07:58:48 --> Model Class Initialized
DEBUG - 2011-09-17 07:58:48 --> Model Class Initialized
DEBUG - 2011-09-17 07:58:48 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-17 07:58:48 --> Database Driver Class Initialized
DEBUG - 2011-09-17 07:58:48 --> File loaded: application/views/table/main.php
DEBUG - 2011-09-17 07:58:48 --> Helper loaded: url_helper
DEBUG - 2011-09-17 07:58:48 --> File loaded: application/views/common/header.php
DEBUG - 2011-09-17 07:58:48 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-09-17 07:58:48 --> File loaded: application/views/common/footer.php
DEBUG - 2011-09-17 07:58:48 --> File loaded: application/views/layout/main.php
DEBUG - 2011-09-17 07:58:48 --> Final output sent to browser
DEBUG - 2011-09-17 07:58:48 --> Total execution time: 0.0634
DEBUG - 2011-09-17 07:58:49 --> Config Class Initialized
DEBUG - 2011-09-17 07:58:49 --> Hooks Class Initialized
DEBUG - 2011-09-17 07:58:49 --> Utf8 Class Initialized
DEBUG - 2011-09-17 07:58:49 --> UTF-8 Support Enabled
DEBUG - 2011-09-17 07:58:49 --> URI Class Initialized
DEBUG - 2011-09-17 07:58:49 --> Router Class Initialized
DEBUG - 2011-09-17 07:58:49 --> Output Class Initialized
DEBUG - 2011-09-17 07:58:49 --> Input Class Initialized
DEBUG - 2011-09-17 07:58:49 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-17 07:58:49 --> Language Class Initialized
DEBUG - 2011-09-17 07:58:49 --> Loader Class Initialized
DEBUG - 2011-09-17 07:58:49 --> Controller Class Initialized
DEBUG - 2011-09-17 07:58:49 --> Model Class Initialized
DEBUG - 2011-09-17 07:58:49 --> Model Class Initialized
DEBUG - 2011-09-17 07:58:49 --> Model Class Initialized
DEBUG - 2011-09-17 07:58:49 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-17 07:58:49 --> Database Driver Class Initialized
DEBUG - 2011-09-17 07:58:49 --> File loaded: application/views/table/main.php
DEBUG - 2011-09-17 07:58:49 --> Helper loaded: url_helper
DEBUG - 2011-09-17 07:58:49 --> File loaded: application/views/common/header.php
DEBUG - 2011-09-17 07:58:49 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-09-17 07:58:49 --> File loaded: application/views/common/footer.php
DEBUG - 2011-09-17 07:58:49 --> File loaded: application/views/layout/main.php
DEBUG - 2011-09-17 07:58:49 --> Final output sent to browser
DEBUG - 2011-09-17 07:58:49 --> Total execution time: 0.0468
DEBUG - 2011-09-17 07:58:55 --> Config Class Initialized
DEBUG - 2011-09-17 07:58:55 --> Hooks Class Initialized
DEBUG - 2011-09-17 07:58:55 --> Utf8 Class Initialized
DEBUG - 2011-09-17 07:58:55 --> UTF-8 Support Enabled
DEBUG - 2011-09-17 07:58:55 --> URI Class Initialized
DEBUG - 2011-09-17 07:58:55 --> Router Class Initialized
ERROR - 2011-09-17 07:58:55 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-09-17 07:58:58 --> Config Class Initialized
DEBUG - 2011-09-17 07:58:58 --> Hooks Class Initialized
DEBUG - 2011-09-17 07:58:58 --> Utf8 Class Initialized
DEBUG - 2011-09-17 07:58:58 --> UTF-8 Support Enabled
DEBUG - 2011-09-17 07:58:58 --> URI Class Initialized
DEBUG - 2011-09-17 07:58:58 --> Router Class Initialized
ERROR - 2011-09-17 07:58:58 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-09-17 07:59:19 --> Config Class Initialized
DEBUG - 2011-09-17 07:59:19 --> Hooks Class Initialized
DEBUG - 2011-09-17 07:59:19 --> Utf8 Class Initialized
DEBUG - 2011-09-17 07:59:19 --> UTF-8 Support Enabled
DEBUG - 2011-09-17 07:59:19 --> URI Class Initialized
DEBUG - 2011-09-17 07:59:19 --> Router Class Initialized
ERROR - 2011-09-17 07:59:19 --> 404 Page Not Found --> robots.txt
DEBUG - 2011-09-17 07:59:20 --> Config Class Initialized
DEBUG - 2011-09-17 07:59:20 --> Hooks Class Initialized
DEBUG - 2011-09-17 07:59:20 --> Utf8 Class Initialized
DEBUG - 2011-09-17 07:59:20 --> UTF-8 Support Enabled
DEBUG - 2011-09-17 07:59:20 --> URI Class Initialized
DEBUG - 2011-09-17 07:59:20 --> Router Class Initialized
DEBUG - 2011-09-17 07:59:20 --> Output Class Initialized
DEBUG - 2011-09-17 07:59:20 --> Input Class Initialized
DEBUG - 2011-09-17 07:59:20 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-17 07:59:20 --> Language Class Initialized
DEBUG - 2011-09-17 07:59:20 --> Loader Class Initialized
DEBUG - 2011-09-17 07:59:20 --> Controller Class Initialized
DEBUG - 2011-09-17 07:59:20 --> Model Class Initialized
DEBUG - 2011-09-17 07:59:20 --> Model Class Initialized
DEBUG - 2011-09-17 07:59:20 --> Model Class Initialized
DEBUG - 2011-09-17 07:59:20 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-17 07:59:20 --> Database Driver Class Initialized
DEBUG - 2011-09-17 07:59:20 --> File loaded: application/views/table/main.php
DEBUG - 2011-09-17 07:59:20 --> Helper loaded: url_helper
DEBUG - 2011-09-17 07:59:20 --> File loaded: application/views/common/header.php
DEBUG - 2011-09-17 07:59:20 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-09-17 07:59:20 --> File loaded: application/views/common/footer.php
DEBUG - 2011-09-17 07:59:20 --> File loaded: application/views/layout/main.php
DEBUG - 2011-09-17 07:59:20 --> Final output sent to browser
DEBUG - 2011-09-17 07:59:20 --> Total execution time: 0.0555
DEBUG - 2011-09-17 08:00:20 --> Config Class Initialized
DEBUG - 2011-09-17 08:00:20 --> Hooks Class Initialized
DEBUG - 2011-09-17 08:00:20 --> Utf8 Class Initialized
DEBUG - 2011-09-17 08:00:20 --> UTF-8 Support Enabled
DEBUG - 2011-09-17 08:00:20 --> URI Class Initialized
DEBUG - 2011-09-17 08:00:20 --> Router Class Initialized
DEBUG - 2011-09-17 08:00:20 --> Output Class Initialized
DEBUG - 2011-09-17 08:00:20 --> Input Class Initialized
DEBUG - 2011-09-17 08:00:20 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-17 08:00:20 --> Language Class Initialized
DEBUG - 2011-09-17 08:00:20 --> Loader Class Initialized
DEBUG - 2011-09-17 08:00:20 --> Controller Class Initialized
DEBUG - 2011-09-17 08:00:20 --> Model Class Initialized
DEBUG - 2011-09-17 08:00:20 --> Model Class Initialized
DEBUG - 2011-09-17 08:00:20 --> Model Class Initialized
DEBUG - 2011-09-17 08:00:20 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-17 08:00:20 --> Database Driver Class Initialized
DEBUG - 2011-09-17 08:00:21 --> File loaded: application/views/table/main.php
DEBUG - 2011-09-17 08:00:21 --> Helper loaded: url_helper
DEBUG - 2011-09-17 08:00:21 --> File loaded: application/views/common/header.php
DEBUG - 2011-09-17 08:00:21 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-09-17 08:00:21 --> File loaded: application/views/common/footer.php
DEBUG - 2011-09-17 08:00:21 --> File loaded: application/views/layout/main.php
DEBUG - 2011-09-17 08:00:21 --> Final output sent to browser
DEBUG - 2011-09-17 08:00:21 --> Total execution time: 1.2544
DEBUG - 2011-09-17 08:00:25 --> Config Class Initialized
DEBUG - 2011-09-17 08:00:25 --> Hooks Class Initialized
DEBUG - 2011-09-17 08:00:25 --> Utf8 Class Initialized
DEBUG - 2011-09-17 08:00:25 --> UTF-8 Support Enabled
DEBUG - 2011-09-17 08:00:25 --> URI Class Initialized
DEBUG - 2011-09-17 08:00:25 --> Router Class Initialized
DEBUG - 2011-09-17 08:00:25 --> Output Class Initialized
DEBUG - 2011-09-17 08:00:25 --> Input Class Initialized
DEBUG - 2011-09-17 08:00:25 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-17 08:00:25 --> Language Class Initialized
DEBUG - 2011-09-17 08:00:25 --> Loader Class Initialized
DEBUG - 2011-09-17 08:00:25 --> Controller Class Initialized
DEBUG - 2011-09-17 08:00:25 --> Model Class Initialized
DEBUG - 2011-09-17 08:00:25 --> Model Class Initialized
DEBUG - 2011-09-17 08:00:25 --> Model Class Initialized
DEBUG - 2011-09-17 08:00:25 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-17 08:00:25 --> Database Driver Class Initialized
DEBUG - 2011-09-17 08:00:25 --> File loaded: application/views/table/main.php
DEBUG - 2011-09-17 08:00:25 --> Helper loaded: url_helper
DEBUG - 2011-09-17 08:00:25 --> File loaded: application/views/common/header.php
DEBUG - 2011-09-17 08:00:25 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-09-17 08:00:25 --> File loaded: application/views/common/footer.php
DEBUG - 2011-09-17 08:00:25 --> File loaded: application/views/layout/main.php
DEBUG - 2011-09-17 08:00:25 --> Final output sent to browser
DEBUG - 2011-09-17 08:00:25 --> Total execution time: 0.0820
DEBUG - 2011-09-17 08:00:50 --> Config Class Initialized
DEBUG - 2011-09-17 08:00:50 --> Hooks Class Initialized
DEBUG - 2011-09-17 08:00:50 --> Utf8 Class Initialized
DEBUG - 2011-09-17 08:00:50 --> UTF-8 Support Enabled
DEBUG - 2011-09-17 08:00:50 --> URI Class Initialized
DEBUG - 2011-09-17 08:00:50 --> Router Class Initialized
DEBUG - 2011-09-17 08:00:50 --> Output Class Initialized
DEBUG - 2011-09-17 08:00:50 --> Input Class Initialized
DEBUG - 2011-09-17 08:00:50 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-17 08:00:50 --> Language Class Initialized
DEBUG - 2011-09-17 08:00:50 --> Loader Class Initialized
DEBUG - 2011-09-17 08:00:50 --> Controller Class Initialized
DEBUG - 2011-09-17 08:00:50 --> Model Class Initialized
DEBUG - 2011-09-17 08:00:50 --> Model Class Initialized
DEBUG - 2011-09-17 08:00:50 --> Model Class Initialized
DEBUG - 2011-09-17 08:00:50 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-17 08:00:50 --> Database Driver Class Initialized
DEBUG - 2011-09-17 08:00:51 --> File loaded: application/views/table/main.php
DEBUG - 2011-09-17 08:00:51 --> Helper loaded: url_helper
DEBUG - 2011-09-17 08:00:51 --> File loaded: application/views/common/header.php
DEBUG - 2011-09-17 08:00:51 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-09-17 08:00:51 --> File loaded: application/views/common/footer.php
DEBUG - 2011-09-17 08:00:51 --> File loaded: application/views/layout/main.php
DEBUG - 2011-09-17 08:00:51 --> Final output sent to browser
DEBUG - 2011-09-17 08:00:51 --> Total execution time: 0.2819
DEBUG - 2011-09-17 08:00:56 --> Config Class Initialized
DEBUG - 2011-09-17 08:00:56 --> Hooks Class Initialized
DEBUG - 2011-09-17 08:00:56 --> Utf8 Class Initialized
DEBUG - 2011-09-17 08:00:56 --> UTF-8 Support Enabled
DEBUG - 2011-09-17 08:00:56 --> URI Class Initialized
DEBUG - 2011-09-17 08:00:56 --> Router Class Initialized
DEBUG - 2011-09-17 08:00:56 --> Output Class Initialized
DEBUG - 2011-09-17 08:00:56 --> Input Class Initialized
DEBUG - 2011-09-17 08:00:56 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-17 08:00:56 --> Language Class Initialized
DEBUG - 2011-09-17 08:00:56 --> Loader Class Initialized
DEBUG - 2011-09-17 08:00:56 --> Controller Class Initialized
DEBUG - 2011-09-17 08:00:56 --> Model Class Initialized
DEBUG - 2011-09-17 08:00:56 --> Model Class Initialized
DEBUG - 2011-09-17 08:00:56 --> Model Class Initialized
DEBUG - 2011-09-17 08:00:56 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-17 08:00:56 --> Database Driver Class Initialized
DEBUG - 2011-09-17 08:00:56 --> File loaded: application/views/table/main.php
DEBUG - 2011-09-17 08:00:56 --> Helper loaded: url_helper
DEBUG - 2011-09-17 08:00:56 --> File loaded: application/views/common/header.php
DEBUG - 2011-09-17 08:00:56 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-09-17 08:00:56 --> File loaded: application/views/common/footer.php
DEBUG - 2011-09-17 08:00:56 --> File loaded: application/views/layout/main.php
DEBUG - 2011-09-17 08:00:56 --> Final output sent to browser
DEBUG - 2011-09-17 08:00:56 --> Total execution time: 0.0980
DEBUG - 2011-09-17 08:10:49 --> Config Class Initialized
DEBUG - 2011-09-17 08:10:49 --> Hooks Class Initialized
DEBUG - 2011-09-17 08:10:49 --> Utf8 Class Initialized
DEBUG - 2011-09-17 08:10:49 --> UTF-8 Support Enabled
DEBUG - 2011-09-17 08:10:49 --> URI Class Initialized
DEBUG - 2011-09-17 08:10:49 --> Router Class Initialized
DEBUG - 2011-09-17 08:10:49 --> Output Class Initialized
DEBUG - 2011-09-17 08:10:49 --> Input Class Initialized
DEBUG - 2011-09-17 08:10:49 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-17 08:10:49 --> Language Class Initialized
DEBUG - 2011-09-17 08:10:49 --> Loader Class Initialized
DEBUG - 2011-09-17 08:10:49 --> Controller Class Initialized
DEBUG - 2011-09-17 08:10:49 --> Model Class Initialized
DEBUG - 2011-09-17 08:10:49 --> Model Class Initialized
DEBUG - 2011-09-17 08:10:49 --> Model Class Initialized
DEBUG - 2011-09-17 08:10:49 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-17 08:10:49 --> Database Driver Class Initialized
DEBUG - 2011-09-17 08:10:49 --> File loaded: application/views/table/main.php
DEBUG - 2011-09-17 08:10:49 --> Helper loaded: url_helper
DEBUG - 2011-09-17 08:10:49 --> File loaded: application/views/common/header.php
DEBUG - 2011-09-17 08:10:49 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-09-17 08:10:49 --> File loaded: application/views/common/footer.php
DEBUG - 2011-09-17 08:10:49 --> File loaded: application/views/layout/main.php
DEBUG - 2011-09-17 08:10:49 --> Final output sent to browser
DEBUG - 2011-09-17 08:10:49 --> Total execution time: 0.1199
DEBUG - 2011-09-17 08:11:04 --> Config Class Initialized
DEBUG - 2011-09-17 08:11:04 --> Hooks Class Initialized
DEBUG - 2011-09-17 08:11:04 --> Utf8 Class Initialized
DEBUG - 2011-09-17 08:11:04 --> UTF-8 Support Enabled
DEBUG - 2011-09-17 08:11:04 --> URI Class Initialized
DEBUG - 2011-09-17 08:11:04 --> Router Class Initialized
DEBUG - 2011-09-17 08:11:04 --> Output Class Initialized
DEBUG - 2011-09-17 08:11:04 --> Input Class Initialized
DEBUG - 2011-09-17 08:11:04 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-17 08:11:04 --> Language Class Initialized
DEBUG - 2011-09-17 08:11:04 --> Loader Class Initialized
DEBUG - 2011-09-17 08:11:04 --> Controller Class Initialized
DEBUG - 2011-09-17 08:11:04 --> Model Class Initialized
DEBUG - 2011-09-17 08:11:04 --> Model Class Initialized
DEBUG - 2011-09-17 08:11:04 --> Model Class Initialized
DEBUG - 2011-09-17 08:11:04 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-17 08:11:04 --> Database Driver Class Initialized
DEBUG - 2011-09-17 08:11:05 --> File loaded: application/views/table/main.php
DEBUG - 2011-09-17 08:11:05 --> Helper loaded: url_helper
DEBUG - 2011-09-17 08:11:05 --> File loaded: application/views/common/header.php
DEBUG - 2011-09-17 08:11:05 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-09-17 08:11:05 --> File loaded: application/views/common/footer.php
DEBUG - 2011-09-17 08:11:05 --> File loaded: application/views/layout/main.php
DEBUG - 2011-09-17 08:11:05 --> Final output sent to browser
DEBUG - 2011-09-17 08:11:05 --> Total execution time: 0.5056
DEBUG - 2011-09-17 08:19:58 --> Config Class Initialized
DEBUG - 2011-09-17 08:19:58 --> Hooks Class Initialized
DEBUG - 2011-09-17 08:19:58 --> Utf8 Class Initialized
DEBUG - 2011-09-17 08:19:58 --> UTF-8 Support Enabled
DEBUG - 2011-09-17 08:19:58 --> URI Class Initialized
DEBUG - 2011-09-17 08:19:58 --> Router Class Initialized
DEBUG - 2011-09-17 08:19:58 --> Output Class Initialized
DEBUG - 2011-09-17 08:19:58 --> Input Class Initialized
DEBUG - 2011-09-17 08:19:58 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-17 08:19:58 --> Language Class Initialized
DEBUG - 2011-09-17 08:19:58 --> Loader Class Initialized
DEBUG - 2011-09-17 08:19:58 --> Controller Class Initialized
DEBUG - 2011-09-17 08:19:58 --> Model Class Initialized
DEBUG - 2011-09-17 08:19:58 --> Model Class Initialized
DEBUG - 2011-09-17 08:19:58 --> Model Class Initialized
DEBUG - 2011-09-17 08:19:58 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-17 08:19:58 --> Database Driver Class Initialized
DEBUG - 2011-09-17 08:19:58 --> File loaded: application/views/table/main.php
DEBUG - 2011-09-17 08:19:58 --> Helper loaded: url_helper
DEBUG - 2011-09-17 08:19:58 --> File loaded: application/views/common/header.php
DEBUG - 2011-09-17 08:19:58 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-09-17 08:19:58 --> File loaded: application/views/common/footer.php
DEBUG - 2011-09-17 08:19:58 --> File loaded: application/views/layout/main.php
DEBUG - 2011-09-17 08:19:58 --> Final output sent to browser
DEBUG - 2011-09-17 08:19:58 --> Total execution time: 0.0492
DEBUG - 2011-09-17 08:19:59 --> Config Class Initialized
DEBUG - 2011-09-17 08:19:59 --> Hooks Class Initialized
DEBUG - 2011-09-17 08:19:59 --> Utf8 Class Initialized
DEBUG - 2011-09-17 08:19:59 --> UTF-8 Support Enabled
DEBUG - 2011-09-17 08:19:59 --> URI Class Initialized
DEBUG - 2011-09-17 08:19:59 --> Router Class Initialized
ERROR - 2011-09-17 08:19:59 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-09-17 08:20:03 --> Config Class Initialized
DEBUG - 2011-09-17 08:20:03 --> Hooks Class Initialized
DEBUG - 2011-09-17 08:20:03 --> Utf8 Class Initialized
DEBUG - 2011-09-17 08:20:03 --> UTF-8 Support Enabled
DEBUG - 2011-09-17 08:20:03 --> URI Class Initialized
DEBUG - 2011-09-17 08:20:03 --> Router Class Initialized
ERROR - 2011-09-17 08:20:03 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-09-17 08:20:05 --> Config Class Initialized
DEBUG - 2011-09-17 08:20:05 --> Hooks Class Initialized
DEBUG - 2011-09-17 08:20:05 --> Utf8 Class Initialized
DEBUG - 2011-09-17 08:20:05 --> UTF-8 Support Enabled
DEBUG - 2011-09-17 08:20:05 --> URI Class Initialized
DEBUG - 2011-09-17 08:20:05 --> Router Class Initialized
DEBUG - 2011-09-17 08:20:05 --> Output Class Initialized
DEBUG - 2011-09-17 08:20:05 --> Input Class Initialized
DEBUG - 2011-09-17 08:20:05 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-17 08:20:05 --> Language Class Initialized
DEBUG - 2011-09-17 08:20:05 --> Loader Class Initialized
DEBUG - 2011-09-17 08:20:05 --> Controller Class Initialized
ERROR - 2011-09-17 08:20:05 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-09-17 08:20:05 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-09-17 08:20:05 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-09-17 08:20:05 --> Model Class Initialized
DEBUG - 2011-09-17 08:20:05 --> Model Class Initialized
DEBUG - 2011-09-17 08:20:05 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-17 08:20:05 --> Database Driver Class Initialized
DEBUG - 2011-09-17 08:20:05 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-09-17 08:20:05 --> Helper loaded: url_helper
DEBUG - 2011-09-17 08:20:05 --> File loaded: application/views/common/header.php
DEBUG - 2011-09-17 08:20:05 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-09-17 08:20:05 --> File loaded: application/views/common/footer.php
DEBUG - 2011-09-17 08:20:05 --> File loaded: application/views/layout/main.php
DEBUG - 2011-09-17 08:20:05 --> Final output sent to browser
DEBUG - 2011-09-17 08:20:05 --> Total execution time: 0.0313
DEBUG - 2011-09-17 08:20:06 --> Config Class Initialized
DEBUG - 2011-09-17 08:20:06 --> Hooks Class Initialized
DEBUG - 2011-09-17 08:20:06 --> Utf8 Class Initialized
DEBUG - 2011-09-17 08:20:06 --> UTF-8 Support Enabled
DEBUG - 2011-09-17 08:20:06 --> URI Class Initialized
DEBUG - 2011-09-17 08:20:06 --> Router Class Initialized
DEBUG - 2011-09-17 08:20:06 --> Output Class Initialized
DEBUG - 2011-09-17 08:20:06 --> Input Class Initialized
DEBUG - 2011-09-17 08:20:06 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-17 08:20:06 --> Language Class Initialized
DEBUG - 2011-09-17 08:20:06 --> Loader Class Initialized
DEBUG - 2011-09-17 08:20:06 --> Controller Class Initialized
DEBUG - 2011-09-17 08:20:06 --> Model Class Initialized
DEBUG - 2011-09-17 08:20:06 --> Model Class Initialized
DEBUG - 2011-09-17 08:20:06 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-17 08:20:06 --> Database Driver Class Initialized
DEBUG - 2011-09-17 08:20:07 --> Final output sent to browser
DEBUG - 2011-09-17 08:20:07 --> Total execution time: 0.6133
DEBUG - 2011-09-17 08:24:08 --> Config Class Initialized
DEBUG - 2011-09-17 08:24:08 --> Hooks Class Initialized
DEBUG - 2011-09-17 08:24:08 --> Utf8 Class Initialized
DEBUG - 2011-09-17 08:24:08 --> UTF-8 Support Enabled
DEBUG - 2011-09-17 08:24:08 --> URI Class Initialized
DEBUG - 2011-09-17 08:24:08 --> Router Class Initialized
DEBUG - 2011-09-17 08:24:08 --> Output Class Initialized
DEBUG - 2011-09-17 08:24:08 --> Input Class Initialized
DEBUG - 2011-09-17 08:24:08 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-17 08:24:08 --> Language Class Initialized
DEBUG - 2011-09-17 08:24:08 --> Loader Class Initialized
DEBUG - 2011-09-17 08:24:08 --> Controller Class Initialized
DEBUG - 2011-09-17 08:24:08 --> Model Class Initialized
DEBUG - 2011-09-17 08:24:08 --> Model Class Initialized
DEBUG - 2011-09-17 08:24:08 --> Model Class Initialized
DEBUG - 2011-09-17 08:24:08 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-17 08:24:08 --> Database Driver Class Initialized
DEBUG - 2011-09-17 08:24:08 --> File loaded: application/views/table/main.php
DEBUG - 2011-09-17 08:24:08 --> Helper loaded: url_helper
DEBUG - 2011-09-17 08:24:08 --> File loaded: application/views/common/header.php
DEBUG - 2011-09-17 08:24:08 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-09-17 08:24:08 --> File loaded: application/views/common/footer.php
DEBUG - 2011-09-17 08:24:08 --> File loaded: application/views/layout/main.php
DEBUG - 2011-09-17 08:24:08 --> Final output sent to browser
DEBUG - 2011-09-17 08:24:08 --> Total execution time: 0.0568
DEBUG - 2011-09-17 08:24:45 --> Config Class Initialized
DEBUG - 2011-09-17 08:24:45 --> Hooks Class Initialized
DEBUG - 2011-09-17 08:24:45 --> Utf8 Class Initialized
DEBUG - 2011-09-17 08:24:45 --> UTF-8 Support Enabled
DEBUG - 2011-09-17 08:24:45 --> URI Class Initialized
DEBUG - 2011-09-17 08:24:45 --> Router Class Initialized
DEBUG - 2011-09-17 08:24:45 --> Output Class Initialized
DEBUG - 2011-09-17 08:24:45 --> Input Class Initialized
DEBUG - 2011-09-17 08:24:45 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-17 08:24:45 --> Language Class Initialized
DEBUG - 2011-09-17 08:24:45 --> Loader Class Initialized
DEBUG - 2011-09-17 08:24:45 --> Controller Class Initialized
DEBUG - 2011-09-17 08:24:45 --> Model Class Initialized
DEBUG - 2011-09-17 08:24:45 --> Model Class Initialized
DEBUG - 2011-09-17 08:24:45 --> Model Class Initialized
DEBUG - 2011-09-17 08:24:45 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-17 08:24:45 --> Database Driver Class Initialized
DEBUG - 2011-09-17 08:24:45 --> File loaded: application/views/table/main.php
DEBUG - 2011-09-17 08:24:45 --> Helper loaded: url_helper
DEBUG - 2011-09-17 08:24:45 --> File loaded: application/views/common/header.php
DEBUG - 2011-09-17 08:24:45 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-09-17 08:24:45 --> File loaded: application/views/common/footer.php
DEBUG - 2011-09-17 08:24:45 --> File loaded: application/views/layout/main.php
DEBUG - 2011-09-17 08:24:45 --> Final output sent to browser
DEBUG - 2011-09-17 08:24:45 --> Total execution time: 0.1352
DEBUG - 2011-09-17 08:25:19 --> Config Class Initialized
DEBUG - 2011-09-17 08:25:19 --> Hooks Class Initialized
DEBUG - 2011-09-17 08:25:19 --> Utf8 Class Initialized
DEBUG - 2011-09-17 08:25:19 --> UTF-8 Support Enabled
DEBUG - 2011-09-17 08:25:19 --> URI Class Initialized
DEBUG - 2011-09-17 08:25:19 --> Router Class Initialized
DEBUG - 2011-09-17 08:25:19 --> Output Class Initialized
DEBUG - 2011-09-17 08:25:19 --> Input Class Initialized
DEBUG - 2011-09-17 08:25:19 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-17 08:25:19 --> Language Class Initialized
DEBUG - 2011-09-17 08:25:19 --> Loader Class Initialized
DEBUG - 2011-09-17 08:25:19 --> Controller Class Initialized
DEBUG - 2011-09-17 08:25:19 --> Model Class Initialized
DEBUG - 2011-09-17 08:25:19 --> Model Class Initialized
DEBUG - 2011-09-17 08:25:19 --> Model Class Initialized
DEBUG - 2011-09-17 08:25:19 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-17 08:25:19 --> Database Driver Class Initialized
DEBUG - 2011-09-17 08:25:19 --> File loaded: application/views/table/main.php
DEBUG - 2011-09-17 08:25:19 --> Helper loaded: url_helper
DEBUG - 2011-09-17 08:25:19 --> File loaded: application/views/common/header.php
DEBUG - 2011-09-17 08:25:19 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-09-17 08:25:19 --> File loaded: application/views/common/footer.php
DEBUG - 2011-09-17 08:25:19 --> File loaded: application/views/layout/main.php
DEBUG - 2011-09-17 08:25:19 --> Final output sent to browser
DEBUG - 2011-09-17 08:25:19 --> Total execution time: 0.4293
DEBUG - 2011-09-17 08:25:42 --> Config Class Initialized
DEBUG - 2011-09-17 08:25:42 --> Hooks Class Initialized
DEBUG - 2011-09-17 08:25:42 --> Utf8 Class Initialized
DEBUG - 2011-09-17 08:25:42 --> UTF-8 Support Enabled
DEBUG - 2011-09-17 08:25:42 --> URI Class Initialized
DEBUG - 2011-09-17 08:25:42 --> Router Class Initialized
DEBUG - 2011-09-17 08:25:42 --> Output Class Initialized
DEBUG - 2011-09-17 08:25:42 --> Input Class Initialized
DEBUG - 2011-09-17 08:25:42 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-17 08:25:42 --> Language Class Initialized
DEBUG - 2011-09-17 08:25:42 --> Loader Class Initialized
DEBUG - 2011-09-17 08:25:42 --> Controller Class Initialized
DEBUG - 2011-09-17 08:25:42 --> Model Class Initialized
DEBUG - 2011-09-17 08:25:42 --> Model Class Initialized
DEBUG - 2011-09-17 08:25:42 --> Model Class Initialized
DEBUG - 2011-09-17 08:25:42 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-17 08:25:42 --> Database Driver Class Initialized
DEBUG - 2011-09-17 08:25:42 --> File loaded: application/views/table/main.php
DEBUG - 2011-09-17 08:25:42 --> Helper loaded: url_helper
DEBUG - 2011-09-17 08:25:42 --> File loaded: application/views/common/header.php
DEBUG - 2011-09-17 08:25:42 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-09-17 08:25:42 --> File loaded: application/views/common/footer.php
DEBUG - 2011-09-17 08:25:42 --> File loaded: application/views/layout/main.php
DEBUG - 2011-09-17 08:25:42 --> Final output sent to browser
DEBUG - 2011-09-17 08:25:42 --> Total execution time: 0.2416
DEBUG - 2011-09-17 08:41:24 --> Config Class Initialized
DEBUG - 2011-09-17 08:41:24 --> Hooks Class Initialized
DEBUG - 2011-09-17 08:41:24 --> Utf8 Class Initialized
DEBUG - 2011-09-17 08:41:24 --> UTF-8 Support Enabled
DEBUG - 2011-09-17 08:41:24 --> URI Class Initialized
DEBUG - 2011-09-17 08:41:24 --> Router Class Initialized
ERROR - 2011-09-17 08:41:24 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-09-17 08:41:25 --> Config Class Initialized
DEBUG - 2011-09-17 08:41:25 --> Hooks Class Initialized
DEBUG - 2011-09-17 08:41:25 --> Utf8 Class Initialized
DEBUG - 2011-09-17 08:41:25 --> UTF-8 Support Enabled
DEBUG - 2011-09-17 08:41:25 --> URI Class Initialized
DEBUG - 2011-09-17 08:41:25 --> Router Class Initialized
ERROR - 2011-09-17 08:41:25 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-09-17 08:41:28 --> Config Class Initialized
DEBUG - 2011-09-17 08:41:28 --> Hooks Class Initialized
DEBUG - 2011-09-17 08:41:28 --> Utf8 Class Initialized
DEBUG - 2011-09-17 08:41:28 --> UTF-8 Support Enabled
DEBUG - 2011-09-17 08:41:28 --> URI Class Initialized
DEBUG - 2011-09-17 08:41:28 --> Router Class Initialized
ERROR - 2011-09-17 08:41:28 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-09-17 08:53:16 --> Config Class Initialized
DEBUG - 2011-09-17 08:53:16 --> Hooks Class Initialized
DEBUG - 2011-09-17 08:53:16 --> Utf8 Class Initialized
DEBUG - 2011-09-17 08:53:16 --> UTF-8 Support Enabled
DEBUG - 2011-09-17 08:53:16 --> URI Class Initialized
DEBUG - 2011-09-17 08:53:16 --> Router Class Initialized
DEBUG - 2011-09-17 08:53:16 --> Output Class Initialized
DEBUG - 2011-09-17 08:53:16 --> Input Class Initialized
DEBUG - 2011-09-17 08:53:16 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-17 08:53:16 --> Language Class Initialized
DEBUG - 2011-09-17 08:53:16 --> Loader Class Initialized
DEBUG - 2011-09-17 08:53:16 --> Controller Class Initialized
ERROR - 2011-09-17 08:53:16 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-09-17 08:53:16 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-09-17 08:53:16 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-09-17 08:53:16 --> Model Class Initialized
DEBUG - 2011-09-17 08:53:16 --> Model Class Initialized
DEBUG - 2011-09-17 08:53:16 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-17 08:53:16 --> Database Driver Class Initialized
DEBUG - 2011-09-17 08:53:17 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-09-17 08:53:17 --> Helper loaded: url_helper
DEBUG - 2011-09-17 08:53:17 --> File loaded: application/views/common/header.php
DEBUG - 2011-09-17 08:53:17 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-09-17 08:53:17 --> File loaded: application/views/common/footer.php
DEBUG - 2011-09-17 08:53:17 --> File loaded: application/views/layout/main.php
DEBUG - 2011-09-17 08:53:17 --> Final output sent to browser
DEBUG - 2011-09-17 08:53:17 --> Total execution time: 1.0688
DEBUG - 2011-09-17 08:53:25 --> Config Class Initialized
DEBUG - 2011-09-17 08:53:25 --> Hooks Class Initialized
DEBUG - 2011-09-17 08:53:25 --> Utf8 Class Initialized
DEBUG - 2011-09-17 08:53:25 --> UTF-8 Support Enabled
DEBUG - 2011-09-17 08:53:25 --> URI Class Initialized
DEBUG - 2011-09-17 08:53:25 --> Router Class Initialized
DEBUG - 2011-09-17 08:53:25 --> Output Class Initialized
DEBUG - 2011-09-17 08:53:25 --> Input Class Initialized
DEBUG - 2011-09-17 08:53:25 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-17 08:53:25 --> Language Class Initialized
DEBUG - 2011-09-17 08:53:25 --> Loader Class Initialized
DEBUG - 2011-09-17 08:53:25 --> Controller Class Initialized
DEBUG - 2011-09-17 08:53:25 --> Model Class Initialized
DEBUG - 2011-09-17 08:53:25 --> Model Class Initialized
DEBUG - 2011-09-17 08:53:25 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-17 08:53:25 --> Database Driver Class Initialized
DEBUG - 2011-09-17 08:53:26 --> Final output sent to browser
DEBUG - 2011-09-17 08:53:26 --> Total execution time: 0.7691
DEBUG - 2011-09-17 08:53:40 --> Config Class Initialized
DEBUG - 2011-09-17 08:53:40 --> Hooks Class Initialized
DEBUG - 2011-09-17 08:53:40 --> Utf8 Class Initialized
DEBUG - 2011-09-17 08:53:40 --> UTF-8 Support Enabled
DEBUG - 2011-09-17 08:53:40 --> URI Class Initialized
DEBUG - 2011-09-17 08:53:40 --> Router Class Initialized
DEBUG - 2011-09-17 08:53:40 --> Output Class Initialized
DEBUG - 2011-09-17 08:53:40 --> Input Class Initialized
DEBUG - 2011-09-17 08:53:40 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-17 08:53:40 --> Language Class Initialized
DEBUG - 2011-09-17 08:53:40 --> Loader Class Initialized
DEBUG - 2011-09-17 08:53:40 --> Controller Class Initialized
ERROR - 2011-09-17 08:53:40 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-09-17 08:53:40 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-09-17 08:53:40 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-09-17 08:53:40 --> Model Class Initialized
DEBUG - 2011-09-17 08:53:40 --> Model Class Initialized
DEBUG - 2011-09-17 08:53:40 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-17 08:53:40 --> Database Driver Class Initialized
DEBUG - 2011-09-17 08:53:40 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-09-17 08:53:40 --> Helper loaded: url_helper
DEBUG - 2011-09-17 08:53:40 --> File loaded: application/views/common/header.php
DEBUG - 2011-09-17 08:53:40 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-09-17 08:53:40 --> File loaded: application/views/common/footer.php
DEBUG - 2011-09-17 08:53:40 --> File loaded: application/views/layout/main.php
DEBUG - 2011-09-17 08:53:40 --> Final output sent to browser
DEBUG - 2011-09-17 08:53:40 --> Total execution time: 0.0320
DEBUG - 2011-09-17 08:53:46 --> Config Class Initialized
DEBUG - 2011-09-17 08:53:46 --> Hooks Class Initialized
DEBUG - 2011-09-17 08:53:46 --> Utf8 Class Initialized
DEBUG - 2011-09-17 08:53:46 --> UTF-8 Support Enabled
DEBUG - 2011-09-17 08:53:46 --> URI Class Initialized
DEBUG - 2011-09-17 08:53:46 --> Router Class Initialized
DEBUG - 2011-09-17 08:53:46 --> Output Class Initialized
DEBUG - 2011-09-17 08:53:46 --> Input Class Initialized
DEBUG - 2011-09-17 08:53:46 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-17 08:53:46 --> Language Class Initialized
DEBUG - 2011-09-17 08:53:46 --> Loader Class Initialized
DEBUG - 2011-09-17 08:53:46 --> Controller Class Initialized
DEBUG - 2011-09-17 08:53:46 --> Model Class Initialized
DEBUG - 2011-09-17 08:53:46 --> Model Class Initialized
DEBUG - 2011-09-17 08:53:46 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-17 08:53:46 --> Database Driver Class Initialized
DEBUG - 2011-09-17 08:53:46 --> Final output sent to browser
DEBUG - 2011-09-17 08:53:46 --> Total execution time: 0.6211
DEBUG - 2011-09-17 08:54:43 --> Config Class Initialized
DEBUG - 2011-09-17 08:54:43 --> Hooks Class Initialized
DEBUG - 2011-09-17 08:54:43 --> Utf8 Class Initialized
DEBUG - 2011-09-17 08:54:43 --> UTF-8 Support Enabled
DEBUG - 2011-09-17 08:54:43 --> URI Class Initialized
DEBUG - 2011-09-17 08:54:43 --> Router Class Initialized
DEBUG - 2011-09-17 08:54:43 --> Output Class Initialized
DEBUG - 2011-09-17 08:54:43 --> Input Class Initialized
DEBUG - 2011-09-17 08:54:43 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-17 08:54:43 --> Language Class Initialized
DEBUG - 2011-09-17 08:54:43 --> Loader Class Initialized
DEBUG - 2011-09-17 08:54:43 --> Controller Class Initialized
ERROR - 2011-09-17 08:54:43 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-09-17 08:54:43 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-09-17 08:54:43 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-09-17 08:54:43 --> Model Class Initialized
DEBUG - 2011-09-17 08:54:43 --> Model Class Initialized
DEBUG - 2011-09-17 08:54:43 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-17 08:54:43 --> Database Driver Class Initialized
DEBUG - 2011-09-17 08:54:43 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-09-17 08:54:43 --> Helper loaded: url_helper
DEBUG - 2011-09-17 08:54:43 --> File loaded: application/views/common/header.php
DEBUG - 2011-09-17 08:54:43 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-09-17 08:54:43 --> File loaded: application/views/common/footer.php
DEBUG - 2011-09-17 08:54:43 --> File loaded: application/views/layout/main.php
DEBUG - 2011-09-17 08:54:43 --> Final output sent to browser
DEBUG - 2011-09-17 08:54:43 --> Total execution time: 0.0338
DEBUG - 2011-09-17 08:54:47 --> Config Class Initialized
DEBUG - 2011-09-17 08:54:47 --> Hooks Class Initialized
DEBUG - 2011-09-17 08:54:47 --> Utf8 Class Initialized
DEBUG - 2011-09-17 08:54:47 --> UTF-8 Support Enabled
DEBUG - 2011-09-17 08:54:47 --> URI Class Initialized
DEBUG - 2011-09-17 08:54:47 --> Router Class Initialized
DEBUG - 2011-09-17 08:54:47 --> Output Class Initialized
DEBUG - 2011-09-17 08:54:47 --> Input Class Initialized
DEBUG - 2011-09-17 08:54:47 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-17 08:54:47 --> Language Class Initialized
DEBUG - 2011-09-17 08:54:47 --> Loader Class Initialized
DEBUG - 2011-09-17 08:54:47 --> Controller Class Initialized
DEBUG - 2011-09-17 08:54:47 --> Model Class Initialized
DEBUG - 2011-09-17 08:54:47 --> Model Class Initialized
DEBUG - 2011-09-17 08:54:47 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-17 08:54:47 --> Database Driver Class Initialized
DEBUG - 2011-09-17 08:54:48 --> Final output sent to browser
DEBUG - 2011-09-17 08:54:48 --> Total execution time: 0.6348
DEBUG - 2011-09-17 08:55:15 --> Config Class Initialized
DEBUG - 2011-09-17 08:55:15 --> Hooks Class Initialized
DEBUG - 2011-09-17 08:55:15 --> Utf8 Class Initialized
DEBUG - 2011-09-17 08:55:15 --> UTF-8 Support Enabled
DEBUG - 2011-09-17 08:55:15 --> URI Class Initialized
DEBUG - 2011-09-17 08:55:15 --> Router Class Initialized
DEBUG - 2011-09-17 08:55:15 --> Output Class Initialized
DEBUG - 2011-09-17 08:55:15 --> Input Class Initialized
DEBUG - 2011-09-17 08:55:15 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-17 08:55:15 --> Language Class Initialized
DEBUG - 2011-09-17 08:55:15 --> Loader Class Initialized
DEBUG - 2011-09-17 08:55:15 --> Controller Class Initialized
ERROR - 2011-09-17 08:55:15 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-09-17 08:55:15 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-09-17 08:55:15 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-09-17 08:55:15 --> Model Class Initialized
DEBUG - 2011-09-17 08:55:15 --> Model Class Initialized
DEBUG - 2011-09-17 08:55:15 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-17 08:55:15 --> Database Driver Class Initialized
DEBUG - 2011-09-17 08:55:15 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-09-17 08:55:15 --> Helper loaded: url_helper
DEBUG - 2011-09-17 08:55:15 --> File loaded: application/views/common/header.php
DEBUG - 2011-09-17 08:55:15 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-09-17 08:55:15 --> File loaded: application/views/common/footer.php
DEBUG - 2011-09-17 08:55:15 --> File loaded: application/views/layout/main.php
DEBUG - 2011-09-17 08:55:15 --> Final output sent to browser
DEBUG - 2011-09-17 08:55:15 --> Total execution time: 0.0266
DEBUG - 2011-09-17 08:55:19 --> Config Class Initialized
DEBUG - 2011-09-17 08:55:19 --> Hooks Class Initialized
DEBUG - 2011-09-17 08:55:19 --> Utf8 Class Initialized
DEBUG - 2011-09-17 08:55:19 --> UTF-8 Support Enabled
DEBUG - 2011-09-17 08:55:19 --> URI Class Initialized
DEBUG - 2011-09-17 08:55:19 --> Router Class Initialized
DEBUG - 2011-09-17 08:55:19 --> Output Class Initialized
DEBUG - 2011-09-17 08:55:19 --> Input Class Initialized
DEBUG - 2011-09-17 08:55:19 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-17 08:55:19 --> Language Class Initialized
DEBUG - 2011-09-17 08:55:19 --> Loader Class Initialized
DEBUG - 2011-09-17 08:55:19 --> Controller Class Initialized
DEBUG - 2011-09-17 08:55:19 --> Model Class Initialized
DEBUG - 2011-09-17 08:55:19 --> Model Class Initialized
DEBUG - 2011-09-17 08:55:19 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-17 08:55:19 --> Database Driver Class Initialized
DEBUG - 2011-09-17 08:55:21 --> Final output sent to browser
DEBUG - 2011-09-17 08:55:21 --> Total execution time: 1.5760
DEBUG - 2011-09-17 08:55:47 --> Config Class Initialized
DEBUG - 2011-09-17 08:55:47 --> Hooks Class Initialized
DEBUG - 2011-09-17 08:55:47 --> Utf8 Class Initialized
DEBUG - 2011-09-17 08:55:47 --> UTF-8 Support Enabled
DEBUG - 2011-09-17 08:55:47 --> URI Class Initialized
DEBUG - 2011-09-17 08:55:47 --> Router Class Initialized
DEBUG - 2011-09-17 08:55:47 --> Output Class Initialized
DEBUG - 2011-09-17 08:55:47 --> Input Class Initialized
DEBUG - 2011-09-17 08:55:47 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-17 08:55:47 --> Language Class Initialized
DEBUG - 2011-09-17 08:55:47 --> Loader Class Initialized
DEBUG - 2011-09-17 08:55:47 --> Controller Class Initialized
ERROR - 2011-09-17 08:55:47 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-09-17 08:55:47 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-09-17 08:55:47 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-09-17 08:55:47 --> Model Class Initialized
DEBUG - 2011-09-17 08:55:47 --> Model Class Initialized
DEBUG - 2011-09-17 08:55:47 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-17 08:55:47 --> Database Driver Class Initialized
DEBUG - 2011-09-17 08:55:47 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-09-17 08:55:47 --> Helper loaded: url_helper
DEBUG - 2011-09-17 08:55:47 --> File loaded: application/views/common/header.php
DEBUG - 2011-09-17 08:55:47 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-09-17 08:55:47 --> File loaded: application/views/common/footer.php
DEBUG - 2011-09-17 08:55:47 --> File loaded: application/views/layout/main.php
DEBUG - 2011-09-17 08:55:47 --> Final output sent to browser
DEBUG - 2011-09-17 08:55:47 --> Total execution time: 0.0297
DEBUG - 2011-09-17 08:55:51 --> Config Class Initialized
DEBUG - 2011-09-17 08:55:51 --> Hooks Class Initialized
DEBUG - 2011-09-17 08:55:51 --> Utf8 Class Initialized
DEBUG - 2011-09-17 08:55:51 --> UTF-8 Support Enabled
DEBUG - 2011-09-17 08:55:51 --> URI Class Initialized
DEBUG - 2011-09-17 08:55:51 --> Router Class Initialized
DEBUG - 2011-09-17 08:55:51 --> Output Class Initialized
DEBUG - 2011-09-17 08:55:51 --> Input Class Initialized
DEBUG - 2011-09-17 08:55:51 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-17 08:55:51 --> Language Class Initialized
DEBUG - 2011-09-17 08:55:51 --> Loader Class Initialized
DEBUG - 2011-09-17 08:55:51 --> Controller Class Initialized
DEBUG - 2011-09-17 08:55:51 --> Model Class Initialized
DEBUG - 2011-09-17 08:55:51 --> Model Class Initialized
DEBUG - 2011-09-17 08:55:51 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-17 08:55:51 --> Database Driver Class Initialized
DEBUG - 2011-09-17 08:55:52 --> Final output sent to browser
DEBUG - 2011-09-17 08:55:52 --> Total execution time: 0.5661
DEBUG - 2011-09-17 08:56:07 --> Config Class Initialized
DEBUG - 2011-09-17 08:56:07 --> Hooks Class Initialized
DEBUG - 2011-09-17 08:56:07 --> Utf8 Class Initialized
DEBUG - 2011-09-17 08:56:07 --> UTF-8 Support Enabled
DEBUG - 2011-09-17 08:56:07 --> URI Class Initialized
DEBUG - 2011-09-17 08:56:07 --> Router Class Initialized
DEBUG - 2011-09-17 08:56:07 --> Output Class Initialized
DEBUG - 2011-09-17 08:56:07 --> Input Class Initialized
DEBUG - 2011-09-17 08:56:07 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-17 08:56:07 --> Language Class Initialized
DEBUG - 2011-09-17 08:56:07 --> Loader Class Initialized
DEBUG - 2011-09-17 08:56:07 --> Controller Class Initialized
ERROR - 2011-09-17 08:56:07 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-09-17 08:56:07 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-09-17 08:56:07 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-09-17 08:56:07 --> Model Class Initialized
DEBUG - 2011-09-17 08:56:07 --> Model Class Initialized
DEBUG - 2011-09-17 08:56:07 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-17 08:56:07 --> Database Driver Class Initialized
DEBUG - 2011-09-17 08:56:08 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-09-17 08:56:08 --> Helper loaded: url_helper
DEBUG - 2011-09-17 08:56:08 --> File loaded: application/views/common/header.php
DEBUG - 2011-09-17 08:56:08 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-09-17 08:56:08 --> File loaded: application/views/common/footer.php
DEBUG - 2011-09-17 08:56:08 --> File loaded: application/views/layout/main.php
DEBUG - 2011-09-17 08:56:08 --> Final output sent to browser
DEBUG - 2011-09-17 08:56:08 --> Total execution time: 0.0389
DEBUG - 2011-09-17 08:56:12 --> Config Class Initialized
DEBUG - 2011-09-17 08:56:12 --> Hooks Class Initialized
DEBUG - 2011-09-17 08:56:12 --> Utf8 Class Initialized
DEBUG - 2011-09-17 08:56:12 --> UTF-8 Support Enabled
DEBUG - 2011-09-17 08:56:12 --> URI Class Initialized
DEBUG - 2011-09-17 08:56:12 --> Router Class Initialized
DEBUG - 2011-09-17 08:56:12 --> Output Class Initialized
DEBUG - 2011-09-17 08:56:12 --> Input Class Initialized
DEBUG - 2011-09-17 08:56:12 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-17 08:56:12 --> Language Class Initialized
DEBUG - 2011-09-17 08:56:12 --> Loader Class Initialized
DEBUG - 2011-09-17 08:56:12 --> Controller Class Initialized
DEBUG - 2011-09-17 08:56:12 --> Model Class Initialized
DEBUG - 2011-09-17 08:56:12 --> Model Class Initialized
DEBUG - 2011-09-17 08:56:12 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-17 08:56:12 --> Database Driver Class Initialized
DEBUG - 2011-09-17 08:56:13 --> Final output sent to browser
DEBUG - 2011-09-17 08:56:13 --> Total execution time: 0.5447
DEBUG - 2011-09-17 08:56:13 --> Config Class Initialized
DEBUG - 2011-09-17 08:56:13 --> Hooks Class Initialized
DEBUG - 2011-09-17 08:56:13 --> Utf8 Class Initialized
DEBUG - 2011-09-17 08:56:13 --> UTF-8 Support Enabled
DEBUG - 2011-09-17 08:56:13 --> URI Class Initialized
DEBUG - 2011-09-17 08:56:13 --> Router Class Initialized
DEBUG - 2011-09-17 08:56:13 --> Output Class Initialized
DEBUG - 2011-09-17 08:56:13 --> Input Class Initialized
DEBUG - 2011-09-17 08:56:13 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-17 08:56:13 --> Language Class Initialized
DEBUG - 2011-09-17 08:56:13 --> Loader Class Initialized
DEBUG - 2011-09-17 08:56:13 --> Controller Class Initialized
ERROR - 2011-09-17 08:56:13 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-09-17 08:56:13 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-09-17 08:56:13 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-09-17 08:56:13 --> Model Class Initialized
DEBUG - 2011-09-17 08:56:13 --> Model Class Initialized
DEBUG - 2011-09-17 08:56:13 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-17 08:56:13 --> Database Driver Class Initialized
DEBUG - 2011-09-17 08:56:13 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-09-17 08:56:13 --> Helper loaded: url_helper
DEBUG - 2011-09-17 08:56:13 --> File loaded: application/views/common/header.php
DEBUG - 2011-09-17 08:56:13 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-09-17 08:56:13 --> File loaded: application/views/common/footer.php
DEBUG - 2011-09-17 08:56:13 --> File loaded: application/views/layout/main.php
DEBUG - 2011-09-17 08:56:13 --> Final output sent to browser
DEBUG - 2011-09-17 08:56:13 --> Total execution time: 0.0274
DEBUG - 2011-09-17 08:56:29 --> Config Class Initialized
DEBUG - 2011-09-17 08:56:29 --> Hooks Class Initialized
DEBUG - 2011-09-17 08:56:29 --> Utf8 Class Initialized
DEBUG - 2011-09-17 08:56:29 --> UTF-8 Support Enabled
DEBUG - 2011-09-17 08:56:29 --> URI Class Initialized
DEBUG - 2011-09-17 08:56:29 --> Router Class Initialized
DEBUG - 2011-09-17 08:56:29 --> Output Class Initialized
DEBUG - 2011-09-17 08:56:29 --> Input Class Initialized
DEBUG - 2011-09-17 08:56:29 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-17 08:56:29 --> Language Class Initialized
DEBUG - 2011-09-17 08:56:29 --> Loader Class Initialized
DEBUG - 2011-09-17 08:56:29 --> Controller Class Initialized
ERROR - 2011-09-17 08:56:29 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-09-17 08:56:29 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-09-17 08:56:29 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-09-17 08:56:29 --> Model Class Initialized
DEBUG - 2011-09-17 08:56:29 --> Model Class Initialized
DEBUG - 2011-09-17 08:56:29 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-17 08:56:29 --> Database Driver Class Initialized
DEBUG - 2011-09-17 08:56:29 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-09-17 08:56:29 --> Helper loaded: url_helper
DEBUG - 2011-09-17 08:56:29 --> File loaded: application/views/common/header.php
DEBUG - 2011-09-17 08:56:29 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-09-17 08:56:29 --> File loaded: application/views/common/footer.php
DEBUG - 2011-09-17 08:56:29 --> File loaded: application/views/layout/main.php
DEBUG - 2011-09-17 08:56:29 --> Final output sent to browser
DEBUG - 2011-09-17 08:56:29 --> Total execution time: 0.0291
DEBUG - 2011-09-17 08:56:32 --> Config Class Initialized
DEBUG - 2011-09-17 08:56:32 --> Hooks Class Initialized
DEBUG - 2011-09-17 08:56:32 --> Utf8 Class Initialized
DEBUG - 2011-09-17 08:56:32 --> UTF-8 Support Enabled
DEBUG - 2011-09-17 08:56:32 --> URI Class Initialized
DEBUG - 2011-09-17 08:56:32 --> Router Class Initialized
DEBUG - 2011-09-17 08:56:32 --> Output Class Initialized
DEBUG - 2011-09-17 08:56:32 --> Input Class Initialized
DEBUG - 2011-09-17 08:56:32 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-17 08:56:32 --> Language Class Initialized
DEBUG - 2011-09-17 08:56:32 --> Loader Class Initialized
DEBUG - 2011-09-17 08:56:32 --> Controller Class Initialized
ERROR - 2011-09-17 08:56:32 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-09-17 08:56:32 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-09-17 08:56:32 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-09-17 08:56:32 --> Model Class Initialized
DEBUG - 2011-09-17 08:56:32 --> Model Class Initialized
DEBUG - 2011-09-17 08:56:32 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-17 08:56:32 --> Database Driver Class Initialized
DEBUG - 2011-09-17 08:56:32 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-09-17 08:56:32 --> Helper loaded: url_helper
DEBUG - 2011-09-17 08:56:32 --> File loaded: application/views/common/header.php
DEBUG - 2011-09-17 08:56:32 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-09-17 08:56:32 --> File loaded: application/views/common/footer.php
DEBUG - 2011-09-17 08:56:32 --> File loaded: application/views/layout/main.php
DEBUG - 2011-09-17 08:56:32 --> Final output sent to browser
DEBUG - 2011-09-17 08:56:32 --> Total execution time: 0.0406
DEBUG - 2011-09-17 08:56:33 --> Config Class Initialized
DEBUG - 2011-09-17 08:56:33 --> Hooks Class Initialized
DEBUG - 2011-09-17 08:56:33 --> Utf8 Class Initialized
DEBUG - 2011-09-17 08:56:33 --> UTF-8 Support Enabled
DEBUG - 2011-09-17 08:56:33 --> URI Class Initialized
DEBUG - 2011-09-17 08:56:33 --> Router Class Initialized
DEBUG - 2011-09-17 08:56:33 --> Output Class Initialized
DEBUG - 2011-09-17 08:56:33 --> Input Class Initialized
DEBUG - 2011-09-17 08:56:33 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-17 08:56:33 --> Language Class Initialized
DEBUG - 2011-09-17 08:56:33 --> Loader Class Initialized
DEBUG - 2011-09-17 08:56:33 --> Controller Class Initialized
DEBUG - 2011-09-17 08:56:33 --> Model Class Initialized
DEBUG - 2011-09-17 08:56:33 --> Model Class Initialized
DEBUG - 2011-09-17 08:56:33 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-17 08:56:33 --> Database Driver Class Initialized
DEBUG - 2011-09-17 08:56:34 --> Final output sent to browser
DEBUG - 2011-09-17 08:56:34 --> Total execution time: 0.5828
DEBUG - 2011-09-17 08:56:54 --> Config Class Initialized
DEBUG - 2011-09-17 08:56:54 --> Hooks Class Initialized
DEBUG - 2011-09-17 08:56:54 --> Utf8 Class Initialized
DEBUG - 2011-09-17 08:56:54 --> UTF-8 Support Enabled
DEBUG - 2011-09-17 08:56:54 --> URI Class Initialized
DEBUG - 2011-09-17 08:56:54 --> Router Class Initialized
DEBUG - 2011-09-17 08:56:54 --> Output Class Initialized
DEBUG - 2011-09-17 08:56:54 --> Input Class Initialized
DEBUG - 2011-09-17 08:56:54 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-17 08:56:54 --> Language Class Initialized
DEBUG - 2011-09-17 08:56:54 --> Loader Class Initialized
DEBUG - 2011-09-17 08:56:54 --> Controller Class Initialized
ERROR - 2011-09-17 08:56:54 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-09-17 08:56:54 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-09-17 08:56:54 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-09-17 08:56:54 --> Model Class Initialized
DEBUG - 2011-09-17 08:56:54 --> Model Class Initialized
DEBUG - 2011-09-17 08:56:54 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-17 08:56:54 --> Database Driver Class Initialized
DEBUG - 2011-09-17 08:56:54 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-09-17 08:56:54 --> Helper loaded: url_helper
DEBUG - 2011-09-17 08:56:54 --> File loaded: application/views/common/header.php
DEBUG - 2011-09-17 08:56:54 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-09-17 08:56:54 --> File loaded: application/views/common/footer.php
DEBUG - 2011-09-17 08:56:54 --> File loaded: application/views/layout/main.php
DEBUG - 2011-09-17 08:56:54 --> Final output sent to browser
DEBUG - 2011-09-17 08:56:54 --> Total execution time: 0.0282
DEBUG - 2011-09-17 08:57:01 --> Config Class Initialized
DEBUG - 2011-09-17 08:57:01 --> Hooks Class Initialized
DEBUG - 2011-09-17 08:57:01 --> Utf8 Class Initialized
DEBUG - 2011-09-17 08:57:01 --> UTF-8 Support Enabled
DEBUG - 2011-09-17 08:57:01 --> URI Class Initialized
DEBUG - 2011-09-17 08:57:01 --> Router Class Initialized
DEBUG - 2011-09-17 08:57:01 --> Output Class Initialized
DEBUG - 2011-09-17 08:57:01 --> Input Class Initialized
DEBUG - 2011-09-17 08:57:01 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-17 08:57:01 --> Language Class Initialized
DEBUG - 2011-09-17 08:57:01 --> Loader Class Initialized
DEBUG - 2011-09-17 08:57:01 --> Controller Class Initialized
DEBUG - 2011-09-17 08:57:01 --> Model Class Initialized
DEBUG - 2011-09-17 08:57:01 --> Model Class Initialized
DEBUG - 2011-09-17 08:57:01 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-17 08:57:01 --> Database Driver Class Initialized
DEBUG - 2011-09-17 08:57:02 --> Final output sent to browser
DEBUG - 2011-09-17 08:57:02 --> Total execution time: 0.6725
DEBUG - 2011-09-17 08:57:21 --> Config Class Initialized
DEBUG - 2011-09-17 08:57:21 --> Hooks Class Initialized
DEBUG - 2011-09-17 08:57:21 --> Utf8 Class Initialized
DEBUG - 2011-09-17 08:57:21 --> UTF-8 Support Enabled
DEBUG - 2011-09-17 08:57:21 --> URI Class Initialized
DEBUG - 2011-09-17 08:57:21 --> Router Class Initialized
DEBUG - 2011-09-17 08:57:21 --> Output Class Initialized
DEBUG - 2011-09-17 08:57:21 --> Input Class Initialized
DEBUG - 2011-09-17 08:57:21 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-17 08:57:21 --> Language Class Initialized
DEBUG - 2011-09-17 08:57:21 --> Loader Class Initialized
DEBUG - 2011-09-17 08:57:21 --> Controller Class Initialized
ERROR - 2011-09-17 08:57:21 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-09-17 08:57:21 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-09-17 08:57:21 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-09-17 08:57:21 --> Model Class Initialized
DEBUG - 2011-09-17 08:57:21 --> Model Class Initialized
DEBUG - 2011-09-17 08:57:21 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-17 08:57:21 --> Database Driver Class Initialized
DEBUG - 2011-09-17 08:57:21 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-09-17 08:57:21 --> Helper loaded: url_helper
DEBUG - 2011-09-17 08:57:21 --> File loaded: application/views/common/header.php
DEBUG - 2011-09-17 08:57:21 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-09-17 08:57:21 --> File loaded: application/views/common/footer.php
DEBUG - 2011-09-17 08:57:21 --> File loaded: application/views/layout/main.php
DEBUG - 2011-09-17 08:57:21 --> Final output sent to browser
DEBUG - 2011-09-17 08:57:21 --> Total execution time: 0.0336
DEBUG - 2011-09-17 08:57:25 --> Config Class Initialized
DEBUG - 2011-09-17 08:57:25 --> Hooks Class Initialized
DEBUG - 2011-09-17 08:57:25 --> Utf8 Class Initialized
DEBUG - 2011-09-17 08:57:25 --> UTF-8 Support Enabled
DEBUG - 2011-09-17 08:57:25 --> URI Class Initialized
DEBUG - 2011-09-17 08:57:25 --> Router Class Initialized
DEBUG - 2011-09-17 08:57:25 --> Output Class Initialized
DEBUG - 2011-09-17 08:57:25 --> Input Class Initialized
DEBUG - 2011-09-17 08:57:25 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-17 08:57:25 --> Language Class Initialized
DEBUG - 2011-09-17 08:57:25 --> Loader Class Initialized
DEBUG - 2011-09-17 08:57:25 --> Controller Class Initialized
DEBUG - 2011-09-17 08:57:25 --> Model Class Initialized
DEBUG - 2011-09-17 08:57:25 --> Model Class Initialized
DEBUG - 2011-09-17 08:57:25 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-17 08:57:25 --> Database Driver Class Initialized
DEBUG - 2011-09-17 08:57:26 --> Final output sent to browser
DEBUG - 2011-09-17 08:57:26 --> Total execution time: 0.5576
DEBUG - 2011-09-17 08:57:55 --> Config Class Initialized
DEBUG - 2011-09-17 08:57:55 --> Hooks Class Initialized
DEBUG - 2011-09-17 08:57:55 --> Utf8 Class Initialized
DEBUG - 2011-09-17 08:57:55 --> UTF-8 Support Enabled
DEBUG - 2011-09-17 08:57:55 --> URI Class Initialized
DEBUG - 2011-09-17 08:57:55 --> Router Class Initialized
DEBUG - 2011-09-17 08:57:55 --> Output Class Initialized
DEBUG - 2011-09-17 08:57:55 --> Input Class Initialized
DEBUG - 2011-09-17 08:57:55 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-17 08:57:55 --> Language Class Initialized
DEBUG - 2011-09-17 08:57:55 --> Loader Class Initialized
DEBUG - 2011-09-17 08:57:55 --> Controller Class Initialized
ERROR - 2011-09-17 08:57:55 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-09-17 08:57:55 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-09-17 08:57:55 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-09-17 08:57:55 --> Model Class Initialized
DEBUG - 2011-09-17 08:57:55 --> Model Class Initialized
DEBUG - 2011-09-17 08:57:55 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-17 08:57:55 --> Database Driver Class Initialized
DEBUG - 2011-09-17 08:57:55 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-09-17 08:57:55 --> Helper loaded: url_helper
DEBUG - 2011-09-17 08:57:55 --> File loaded: application/views/common/header.php
DEBUG - 2011-09-17 08:57:55 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-09-17 08:57:55 --> File loaded: application/views/common/footer.php
DEBUG - 2011-09-17 08:57:55 --> File loaded: application/views/layout/main.php
DEBUG - 2011-09-17 08:57:55 --> Final output sent to browser
DEBUG - 2011-09-17 08:57:55 --> Total execution time: 0.0289
DEBUG - 2011-09-17 08:58:01 --> Config Class Initialized
DEBUG - 2011-09-17 08:58:01 --> Hooks Class Initialized
DEBUG - 2011-09-17 08:58:01 --> Utf8 Class Initialized
DEBUG - 2011-09-17 08:58:01 --> UTF-8 Support Enabled
DEBUG - 2011-09-17 08:58:01 --> URI Class Initialized
DEBUG - 2011-09-17 08:58:01 --> Router Class Initialized
DEBUG - 2011-09-17 08:58:01 --> Output Class Initialized
DEBUG - 2011-09-17 08:58:01 --> Input Class Initialized
DEBUG - 2011-09-17 08:58:01 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-17 08:58:01 --> Language Class Initialized
DEBUG - 2011-09-17 08:58:01 --> Loader Class Initialized
DEBUG - 2011-09-17 08:58:01 --> Controller Class Initialized
DEBUG - 2011-09-17 08:58:01 --> Model Class Initialized
DEBUG - 2011-09-17 08:58:01 --> Model Class Initialized
DEBUG - 2011-09-17 08:58:01 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-17 08:58:01 --> Database Driver Class Initialized
DEBUG - 2011-09-17 08:58:01 --> Final output sent to browser
DEBUG - 2011-09-17 08:58:01 --> Total execution time: 0.7762
DEBUG - 2011-09-17 08:59:03 --> Config Class Initialized
DEBUG - 2011-09-17 08:59:03 --> Hooks Class Initialized
DEBUG - 2011-09-17 08:59:03 --> Utf8 Class Initialized
DEBUG - 2011-09-17 08:59:03 --> UTF-8 Support Enabled
DEBUG - 2011-09-17 08:59:03 --> URI Class Initialized
DEBUG - 2011-09-17 08:59:03 --> Router Class Initialized
DEBUG - 2011-09-17 08:59:03 --> Output Class Initialized
DEBUG - 2011-09-17 08:59:03 --> Input Class Initialized
DEBUG - 2011-09-17 08:59:03 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-17 08:59:03 --> Language Class Initialized
DEBUG - 2011-09-17 08:59:03 --> Loader Class Initialized
DEBUG - 2011-09-17 08:59:03 --> Controller Class Initialized
ERROR - 2011-09-17 08:59:03 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-09-17 08:59:03 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-09-17 08:59:03 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-09-17 08:59:03 --> Model Class Initialized
DEBUG - 2011-09-17 08:59:03 --> Model Class Initialized
DEBUG - 2011-09-17 08:59:03 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-17 08:59:03 --> Database Driver Class Initialized
DEBUG - 2011-09-17 08:59:03 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-09-17 08:59:03 --> Helper loaded: url_helper
DEBUG - 2011-09-17 08:59:03 --> File loaded: application/views/common/header.php
DEBUG - 2011-09-17 08:59:03 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-09-17 08:59:03 --> File loaded: application/views/common/footer.php
DEBUG - 2011-09-17 08:59:03 --> File loaded: application/views/layout/main.php
DEBUG - 2011-09-17 08:59:03 --> Final output sent to browser
DEBUG - 2011-09-17 08:59:03 --> Total execution time: 0.0932
DEBUG - 2011-09-17 08:59:08 --> Config Class Initialized
DEBUG - 2011-09-17 08:59:08 --> Hooks Class Initialized
DEBUG - 2011-09-17 08:59:08 --> Utf8 Class Initialized
DEBUG - 2011-09-17 08:59:08 --> UTF-8 Support Enabled
DEBUG - 2011-09-17 08:59:08 --> URI Class Initialized
DEBUG - 2011-09-17 08:59:08 --> Router Class Initialized
DEBUG - 2011-09-17 08:59:08 --> Output Class Initialized
DEBUG - 2011-09-17 08:59:08 --> Input Class Initialized
DEBUG - 2011-09-17 08:59:08 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-17 08:59:08 --> Language Class Initialized
DEBUG - 2011-09-17 08:59:08 --> Loader Class Initialized
DEBUG - 2011-09-17 08:59:08 --> Controller Class Initialized
DEBUG - 2011-09-17 08:59:08 --> Model Class Initialized
DEBUG - 2011-09-17 08:59:08 --> Model Class Initialized
DEBUG - 2011-09-17 08:59:08 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-17 08:59:08 --> Database Driver Class Initialized
DEBUG - 2011-09-17 08:59:08 --> Config Class Initialized
DEBUG - 2011-09-17 08:59:08 --> Hooks Class Initialized
DEBUG - 2011-09-17 08:59:08 --> Utf8 Class Initialized
DEBUG - 2011-09-17 08:59:08 --> UTF-8 Support Enabled
DEBUG - 2011-09-17 08:59:08 --> URI Class Initialized
DEBUG - 2011-09-17 08:59:08 --> Router Class Initialized
DEBUG - 2011-09-17 08:59:08 --> Output Class Initialized
DEBUG - 2011-09-17 08:59:08 --> Input Class Initialized
DEBUG - 2011-09-17 08:59:08 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-17 08:59:08 --> Language Class Initialized
DEBUG - 2011-09-17 08:59:08 --> Loader Class Initialized
DEBUG - 2011-09-17 08:59:08 --> Controller Class Initialized
ERROR - 2011-09-17 08:59:08 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-09-17 08:59:08 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-09-17 08:59:08 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-09-17 08:59:08 --> Model Class Initialized
DEBUG - 2011-09-17 08:59:08 --> Model Class Initialized
DEBUG - 2011-09-17 08:59:08 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-17 08:59:08 --> Database Driver Class Initialized
DEBUG - 2011-09-17 08:59:08 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-09-17 08:59:08 --> Helper loaded: url_helper
DEBUG - 2011-09-17 08:59:08 --> File loaded: application/views/common/header.php
DEBUG - 2011-09-17 08:59:08 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-09-17 08:59:08 --> File loaded: application/views/common/footer.php
DEBUG - 2011-09-17 08:59:08 --> File loaded: application/views/layout/main.php
DEBUG - 2011-09-17 08:59:08 --> Final output sent to browser
DEBUG - 2011-09-17 08:59:08 --> Total execution time: 0.0333
DEBUG - 2011-09-17 08:59:09 --> Final output sent to browser
DEBUG - 2011-09-17 08:59:09 --> Total execution time: 0.6098
DEBUG - 2011-09-17 08:59:47 --> Config Class Initialized
DEBUG - 2011-09-17 08:59:47 --> Hooks Class Initialized
DEBUG - 2011-09-17 08:59:47 --> Utf8 Class Initialized
DEBUG - 2011-09-17 08:59:47 --> UTF-8 Support Enabled
DEBUG - 2011-09-17 08:59:47 --> URI Class Initialized
DEBUG - 2011-09-17 08:59:47 --> Router Class Initialized
DEBUG - 2011-09-17 08:59:47 --> Output Class Initialized
DEBUG - 2011-09-17 08:59:47 --> Input Class Initialized
DEBUG - 2011-09-17 08:59:47 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-17 08:59:47 --> Language Class Initialized
DEBUG - 2011-09-17 08:59:47 --> Loader Class Initialized
DEBUG - 2011-09-17 08:59:47 --> Controller Class Initialized
ERROR - 2011-09-17 08:59:47 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-09-17 08:59:47 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-09-17 08:59:47 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-09-17 08:59:47 --> Model Class Initialized
DEBUG - 2011-09-17 08:59:47 --> Model Class Initialized
DEBUG - 2011-09-17 08:59:47 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-17 08:59:47 --> Database Driver Class Initialized
DEBUG - 2011-09-17 08:59:47 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-09-17 08:59:47 --> Helper loaded: url_helper
DEBUG - 2011-09-17 08:59:47 --> File loaded: application/views/common/header.php
DEBUG - 2011-09-17 08:59:47 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-09-17 08:59:47 --> File loaded: application/views/common/footer.php
DEBUG - 2011-09-17 08:59:47 --> File loaded: application/views/layout/main.php
DEBUG - 2011-09-17 08:59:47 --> Final output sent to browser
DEBUG - 2011-09-17 08:59:47 --> Total execution time: 0.0297
DEBUG - 2011-09-17 08:59:51 --> Config Class Initialized
DEBUG - 2011-09-17 08:59:51 --> Hooks Class Initialized
DEBUG - 2011-09-17 08:59:51 --> Utf8 Class Initialized
DEBUG - 2011-09-17 08:59:51 --> UTF-8 Support Enabled
DEBUG - 2011-09-17 08:59:51 --> URI Class Initialized
DEBUG - 2011-09-17 08:59:51 --> Router Class Initialized
DEBUG - 2011-09-17 08:59:51 --> Output Class Initialized
DEBUG - 2011-09-17 08:59:51 --> Input Class Initialized
DEBUG - 2011-09-17 08:59:51 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-17 08:59:51 --> Language Class Initialized
DEBUG - 2011-09-17 08:59:51 --> Loader Class Initialized
DEBUG - 2011-09-17 08:59:51 --> Controller Class Initialized
ERROR - 2011-09-17 08:59:51 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-09-17 08:59:51 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-09-17 08:59:51 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-09-17 08:59:51 --> Model Class Initialized
DEBUG - 2011-09-17 08:59:51 --> Model Class Initialized
DEBUG - 2011-09-17 08:59:51 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-17 08:59:51 --> Database Driver Class Initialized
DEBUG - 2011-09-17 08:59:51 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-09-17 08:59:51 --> Helper loaded: url_helper
DEBUG - 2011-09-17 08:59:51 --> File loaded: application/views/common/header.php
DEBUG - 2011-09-17 08:59:51 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-09-17 08:59:51 --> File loaded: application/views/common/footer.php
DEBUG - 2011-09-17 08:59:51 --> File loaded: application/views/layout/main.php
DEBUG - 2011-09-17 08:59:51 --> Final output sent to browser
DEBUG - 2011-09-17 08:59:51 --> Total execution time: 0.0289
DEBUG - 2011-09-17 08:59:52 --> Config Class Initialized
DEBUG - 2011-09-17 08:59:52 --> Hooks Class Initialized
DEBUG - 2011-09-17 08:59:52 --> Utf8 Class Initialized
DEBUG - 2011-09-17 08:59:52 --> UTF-8 Support Enabled
DEBUG - 2011-09-17 08:59:52 --> URI Class Initialized
DEBUG - 2011-09-17 08:59:52 --> Router Class Initialized
DEBUG - 2011-09-17 08:59:52 --> Output Class Initialized
DEBUG - 2011-09-17 08:59:52 --> Input Class Initialized
DEBUG - 2011-09-17 08:59:52 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-17 08:59:52 --> Language Class Initialized
DEBUG - 2011-09-17 08:59:52 --> Loader Class Initialized
DEBUG - 2011-09-17 08:59:52 --> Controller Class Initialized
DEBUG - 2011-09-17 08:59:52 --> Model Class Initialized
DEBUG - 2011-09-17 08:59:52 --> Model Class Initialized
DEBUG - 2011-09-17 08:59:52 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-17 08:59:52 --> Database Driver Class Initialized
DEBUG - 2011-09-17 08:59:53 --> Final output sent to browser
DEBUG - 2011-09-17 08:59:53 --> Total execution time: 0.6286
DEBUG - 2011-09-17 09:00:15 --> Config Class Initialized
DEBUG - 2011-09-17 09:00:15 --> Hooks Class Initialized
DEBUG - 2011-09-17 09:00:15 --> Utf8 Class Initialized
DEBUG - 2011-09-17 09:00:15 --> UTF-8 Support Enabled
DEBUG - 2011-09-17 09:00:15 --> URI Class Initialized
DEBUG - 2011-09-17 09:00:15 --> Router Class Initialized
DEBUG - 2011-09-17 09:00:15 --> Output Class Initialized
DEBUG - 2011-09-17 09:00:15 --> Input Class Initialized
DEBUG - 2011-09-17 09:00:15 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-17 09:00:15 --> Language Class Initialized
DEBUG - 2011-09-17 09:00:15 --> Loader Class Initialized
DEBUG - 2011-09-17 09:00:15 --> Controller Class Initialized
ERROR - 2011-09-17 09:00:15 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-09-17 09:00:15 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-09-17 09:00:15 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-09-17 09:00:15 --> Model Class Initialized
DEBUG - 2011-09-17 09:00:15 --> Model Class Initialized
DEBUG - 2011-09-17 09:00:15 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-17 09:00:15 --> Database Driver Class Initialized
DEBUG - 2011-09-17 09:00:15 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-09-17 09:00:15 --> Helper loaded: url_helper
DEBUG - 2011-09-17 09:00:15 --> File loaded: application/views/common/header.php
DEBUG - 2011-09-17 09:00:15 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-09-17 09:00:15 --> File loaded: application/views/common/footer.php
DEBUG - 2011-09-17 09:00:15 --> File loaded: application/views/layout/main.php
DEBUG - 2011-09-17 09:00:15 --> Final output sent to browser
DEBUG - 2011-09-17 09:00:15 --> Total execution time: 0.0551
DEBUG - 2011-09-17 09:00:20 --> Config Class Initialized
DEBUG - 2011-09-17 09:00:20 --> Hooks Class Initialized
DEBUG - 2011-09-17 09:00:20 --> Utf8 Class Initialized
DEBUG - 2011-09-17 09:00:20 --> UTF-8 Support Enabled
DEBUG - 2011-09-17 09:00:20 --> URI Class Initialized
DEBUG - 2011-09-17 09:00:20 --> Router Class Initialized
DEBUG - 2011-09-17 09:00:20 --> Output Class Initialized
DEBUG - 2011-09-17 09:00:20 --> Input Class Initialized
DEBUG - 2011-09-17 09:00:20 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-17 09:00:20 --> Language Class Initialized
DEBUG - 2011-09-17 09:00:20 --> Loader Class Initialized
DEBUG - 2011-09-17 09:00:20 --> Controller Class Initialized
DEBUG - 2011-09-17 09:00:20 --> Model Class Initialized
DEBUG - 2011-09-17 09:00:20 --> Model Class Initialized
DEBUG - 2011-09-17 09:00:20 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-17 09:00:20 --> Database Driver Class Initialized
DEBUG - 2011-09-17 09:00:21 --> Final output sent to browser
DEBUG - 2011-09-17 09:00:21 --> Total execution time: 0.5758
DEBUG - 2011-09-17 09:00:48 --> Config Class Initialized
DEBUG - 2011-09-17 09:00:48 --> Hooks Class Initialized
DEBUG - 2011-09-17 09:00:48 --> Utf8 Class Initialized
DEBUG - 2011-09-17 09:00:48 --> UTF-8 Support Enabled
DEBUG - 2011-09-17 09:00:48 --> URI Class Initialized
DEBUG - 2011-09-17 09:00:48 --> Router Class Initialized
DEBUG - 2011-09-17 09:00:48 --> Output Class Initialized
DEBUG - 2011-09-17 09:00:48 --> Input Class Initialized
DEBUG - 2011-09-17 09:00:48 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-17 09:00:48 --> Language Class Initialized
DEBUG - 2011-09-17 09:00:48 --> Loader Class Initialized
DEBUG - 2011-09-17 09:00:48 --> Controller Class Initialized
ERROR - 2011-09-17 09:00:48 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-09-17 09:00:48 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-09-17 09:00:48 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-09-17 09:00:48 --> Model Class Initialized
DEBUG - 2011-09-17 09:00:48 --> Model Class Initialized
DEBUG - 2011-09-17 09:00:48 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-17 09:00:48 --> Database Driver Class Initialized
DEBUG - 2011-09-17 09:00:48 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-09-17 09:00:48 --> Helper loaded: url_helper
DEBUG - 2011-09-17 09:00:48 --> File loaded: application/views/common/header.php
DEBUG - 2011-09-17 09:00:48 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-09-17 09:00:48 --> File loaded: application/views/common/footer.php
DEBUG - 2011-09-17 09:00:48 --> File loaded: application/views/layout/main.php
DEBUG - 2011-09-17 09:00:48 --> Final output sent to browser
DEBUG - 2011-09-17 09:00:48 --> Total execution time: 0.0268
DEBUG - 2011-09-17 09:00:53 --> Config Class Initialized
DEBUG - 2011-09-17 09:00:53 --> Hooks Class Initialized
DEBUG - 2011-09-17 09:00:53 --> Utf8 Class Initialized
DEBUG - 2011-09-17 09:00:53 --> UTF-8 Support Enabled
DEBUG - 2011-09-17 09:00:53 --> URI Class Initialized
DEBUG - 2011-09-17 09:00:53 --> Router Class Initialized
DEBUG - 2011-09-17 09:00:53 --> Output Class Initialized
DEBUG - 2011-09-17 09:00:53 --> Input Class Initialized
DEBUG - 2011-09-17 09:00:53 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-17 09:00:53 --> Language Class Initialized
DEBUG - 2011-09-17 09:00:53 --> Loader Class Initialized
DEBUG - 2011-09-17 09:00:53 --> Controller Class Initialized
DEBUG - 2011-09-17 09:00:53 --> Model Class Initialized
DEBUG - 2011-09-17 09:00:53 --> Model Class Initialized
DEBUG - 2011-09-17 09:00:53 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-17 09:00:53 --> Database Driver Class Initialized
DEBUG - 2011-09-17 09:00:54 --> Final output sent to browser
DEBUG - 2011-09-17 09:00:54 --> Total execution time: 0.5759
DEBUG - 2011-09-17 09:06:27 --> Config Class Initialized
DEBUG - 2011-09-17 09:06:27 --> Hooks Class Initialized
DEBUG - 2011-09-17 09:06:27 --> Utf8 Class Initialized
DEBUG - 2011-09-17 09:06:27 --> UTF-8 Support Enabled
DEBUG - 2011-09-17 09:06:27 --> URI Class Initialized
DEBUG - 2011-09-17 09:06:27 --> Router Class Initialized
DEBUG - 2011-09-17 09:06:27 --> Output Class Initialized
DEBUG - 2011-09-17 09:06:27 --> Input Class Initialized
DEBUG - 2011-09-17 09:06:27 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-17 09:06:27 --> Language Class Initialized
DEBUG - 2011-09-17 09:06:27 --> Loader Class Initialized
DEBUG - 2011-09-17 09:06:27 --> Controller Class Initialized
DEBUG - 2011-09-17 09:06:27 --> Model Class Initialized
DEBUG - 2011-09-17 09:06:27 --> Model Class Initialized
DEBUG - 2011-09-17 09:06:27 --> Model Class Initialized
DEBUG - 2011-09-17 09:06:27 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-17 09:06:27 --> Database Driver Class Initialized
DEBUG - 2011-09-17 09:06:28 --> File loaded: application/views/table/main.php
DEBUG - 2011-09-17 09:06:28 --> Helper loaded: url_helper
DEBUG - 2011-09-17 09:06:28 --> File loaded: application/views/common/header.php
DEBUG - 2011-09-17 09:06:28 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-09-17 09:06:28 --> File loaded: application/views/common/footer.php
DEBUG - 2011-09-17 09:06:28 --> File loaded: application/views/layout/main.php
DEBUG - 2011-09-17 09:06:28 --> Final output sent to browser
DEBUG - 2011-09-17 09:06:28 --> Total execution time: 0.4981
DEBUG - 2011-09-17 09:06:30 --> Config Class Initialized
DEBUG - 2011-09-17 09:06:30 --> Hooks Class Initialized
DEBUG - 2011-09-17 09:06:30 --> Utf8 Class Initialized
DEBUG - 2011-09-17 09:06:30 --> UTF-8 Support Enabled
DEBUG - 2011-09-17 09:06:30 --> URI Class Initialized
DEBUG - 2011-09-17 09:06:30 --> Router Class Initialized
ERROR - 2011-09-17 09:06:30 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-09-17 09:06:50 --> Config Class Initialized
DEBUG - 2011-09-17 09:06:50 --> Hooks Class Initialized
DEBUG - 2011-09-17 09:06:50 --> Utf8 Class Initialized
DEBUG - 2011-09-17 09:06:50 --> UTF-8 Support Enabled
DEBUG - 2011-09-17 09:06:50 --> URI Class Initialized
DEBUG - 2011-09-17 09:06:50 --> Router Class Initialized
DEBUG - 2011-09-17 09:06:50 --> Output Class Initialized
DEBUG - 2011-09-17 09:06:50 --> Input Class Initialized
DEBUG - 2011-09-17 09:06:50 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-17 09:06:50 --> Language Class Initialized
DEBUG - 2011-09-17 09:06:50 --> Loader Class Initialized
DEBUG - 2011-09-17 09:06:50 --> Controller Class Initialized
DEBUG - 2011-09-17 09:06:50 --> Model Class Initialized
DEBUG - 2011-09-17 09:06:50 --> Model Class Initialized
DEBUG - 2011-09-17 09:06:50 --> Model Class Initialized
DEBUG - 2011-09-17 09:06:50 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-17 09:06:50 --> Database Driver Class Initialized
DEBUG - 2011-09-17 09:06:50 --> File loaded: application/views/table/main.php
DEBUG - 2011-09-17 09:06:50 --> Helper loaded: url_helper
DEBUG - 2011-09-17 09:06:50 --> File loaded: application/views/common/header.php
DEBUG - 2011-09-17 09:06:50 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-09-17 09:06:50 --> File loaded: application/views/common/footer.php
DEBUG - 2011-09-17 09:06:50 --> File loaded: application/views/layout/main.php
DEBUG - 2011-09-17 09:06:50 --> Final output sent to browser
DEBUG - 2011-09-17 09:06:50 --> Total execution time: 0.2637
DEBUG - 2011-09-17 09:06:56 --> Config Class Initialized
DEBUG - 2011-09-17 09:06:56 --> Hooks Class Initialized
DEBUG - 2011-09-17 09:06:56 --> Utf8 Class Initialized
DEBUG - 2011-09-17 09:06:56 --> UTF-8 Support Enabled
DEBUG - 2011-09-17 09:06:56 --> URI Class Initialized
DEBUG - 2011-09-17 09:06:56 --> Router Class Initialized
DEBUG - 2011-09-17 09:06:56 --> Output Class Initialized
DEBUG - 2011-09-17 09:06:56 --> Input Class Initialized
DEBUG - 2011-09-17 09:06:56 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-17 09:06:56 --> Language Class Initialized
DEBUG - 2011-09-17 09:06:56 --> Loader Class Initialized
DEBUG - 2011-09-17 09:06:56 --> Controller Class Initialized
DEBUG - 2011-09-17 09:06:56 --> Model Class Initialized
DEBUG - 2011-09-17 09:06:56 --> Model Class Initialized
DEBUG - 2011-09-17 09:06:56 --> Model Class Initialized
DEBUG - 2011-09-17 09:06:56 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-17 09:06:56 --> Database Driver Class Initialized
DEBUG - 2011-09-17 09:06:57 --> File loaded: application/views/table/main.php
DEBUG - 2011-09-17 09:06:57 --> Helper loaded: url_helper
DEBUG - 2011-09-17 09:06:57 --> File loaded: application/views/common/header.php
DEBUG - 2011-09-17 09:06:57 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-09-17 09:06:57 --> File loaded: application/views/common/footer.php
DEBUG - 2011-09-17 09:06:57 --> File loaded: application/views/layout/main.php
DEBUG - 2011-09-17 09:06:57 --> Final output sent to browser
DEBUG - 2011-09-17 09:06:57 --> Total execution time: 0.2950
DEBUG - 2011-09-17 09:06:58 --> Config Class Initialized
DEBUG - 2011-09-17 09:06:58 --> Hooks Class Initialized
DEBUG - 2011-09-17 09:06:58 --> Utf8 Class Initialized
DEBUG - 2011-09-17 09:06:58 --> UTF-8 Support Enabled
DEBUG - 2011-09-17 09:06:58 --> URI Class Initialized
DEBUG - 2011-09-17 09:06:58 --> Router Class Initialized
DEBUG - 2011-09-17 09:06:58 --> Output Class Initialized
DEBUG - 2011-09-17 09:06:58 --> Input Class Initialized
DEBUG - 2011-09-17 09:06:58 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-17 09:06:58 --> Language Class Initialized
DEBUG - 2011-09-17 09:06:58 --> Loader Class Initialized
DEBUG - 2011-09-17 09:06:58 --> Controller Class Initialized
DEBUG - 2011-09-17 09:06:58 --> Model Class Initialized
DEBUG - 2011-09-17 09:06:58 --> Model Class Initialized
DEBUG - 2011-09-17 09:06:58 --> Model Class Initialized
DEBUG - 2011-09-17 09:06:58 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-17 09:06:58 --> Database Driver Class Initialized
DEBUG - 2011-09-17 09:06:58 --> File loaded: application/views/table/main.php
DEBUG - 2011-09-17 09:06:58 --> Helper loaded: url_helper
DEBUG - 2011-09-17 09:06:58 --> File loaded: application/views/common/header.php
DEBUG - 2011-09-17 09:06:58 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-09-17 09:06:58 --> File loaded: application/views/common/footer.php
DEBUG - 2011-09-17 09:06:58 --> File loaded: application/views/layout/main.php
DEBUG - 2011-09-17 09:06:58 --> Final output sent to browser
DEBUG - 2011-09-17 09:06:58 --> Total execution time: 0.0490
DEBUG - 2011-09-17 09:07:01 --> Config Class Initialized
DEBUG - 2011-09-17 09:07:01 --> Hooks Class Initialized
DEBUG - 2011-09-17 09:07:01 --> Utf8 Class Initialized
DEBUG - 2011-09-17 09:07:01 --> UTF-8 Support Enabled
DEBUG - 2011-09-17 09:07:01 --> URI Class Initialized
DEBUG - 2011-09-17 09:07:01 --> Router Class Initialized
DEBUG - 2011-09-17 09:07:01 --> Output Class Initialized
DEBUG - 2011-09-17 09:07:01 --> Input Class Initialized
DEBUG - 2011-09-17 09:07:01 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-17 09:07:01 --> Language Class Initialized
DEBUG - 2011-09-17 09:07:01 --> Loader Class Initialized
DEBUG - 2011-09-17 09:07:01 --> Controller Class Initialized
DEBUG - 2011-09-17 09:07:01 --> Model Class Initialized
DEBUG - 2011-09-17 09:07:01 --> Model Class Initialized
DEBUG - 2011-09-17 09:07:01 --> Model Class Initialized
DEBUG - 2011-09-17 09:07:01 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-17 09:07:01 --> Database Driver Class Initialized
DEBUG - 2011-09-17 09:07:02 --> File loaded: application/views/table/main.php
DEBUG - 2011-09-17 09:07:02 --> Helper loaded: url_helper
DEBUG - 2011-09-17 09:07:02 --> File loaded: application/views/common/header.php
DEBUG - 2011-09-17 09:07:02 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-09-17 09:07:02 --> File loaded: application/views/common/footer.php
DEBUG - 2011-09-17 09:07:02 --> File loaded: application/views/layout/main.php
DEBUG - 2011-09-17 09:07:02 --> Final output sent to browser
DEBUG - 2011-09-17 09:07:02 --> Total execution time: 0.7602
DEBUG - 2011-09-17 09:07:06 --> Config Class Initialized
DEBUG - 2011-09-17 09:07:06 --> Hooks Class Initialized
DEBUG - 2011-09-17 09:07:06 --> Utf8 Class Initialized
DEBUG - 2011-09-17 09:07:06 --> UTF-8 Support Enabled
DEBUG - 2011-09-17 09:07:06 --> URI Class Initialized
DEBUG - 2011-09-17 09:07:06 --> Router Class Initialized
DEBUG - 2011-09-17 09:07:06 --> Output Class Initialized
DEBUG - 2011-09-17 09:07:06 --> Input Class Initialized
DEBUG - 2011-09-17 09:07:06 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-17 09:07:06 --> Language Class Initialized
DEBUG - 2011-09-17 09:07:06 --> Loader Class Initialized
DEBUG - 2011-09-17 09:07:06 --> Controller Class Initialized
DEBUG - 2011-09-17 09:07:06 --> Model Class Initialized
DEBUG - 2011-09-17 09:07:06 --> Model Class Initialized
DEBUG - 2011-09-17 09:07:06 --> Model Class Initialized
DEBUG - 2011-09-17 09:07:06 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-17 09:07:06 --> Database Driver Class Initialized
DEBUG - 2011-09-17 09:07:06 --> File loaded: application/views/table/main.php
DEBUG - 2011-09-17 09:07:06 --> Helper loaded: url_helper
DEBUG - 2011-09-17 09:07:06 --> File loaded: application/views/common/header.php
DEBUG - 2011-09-17 09:07:06 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-09-17 09:07:06 --> File loaded: application/views/common/footer.php
DEBUG - 2011-09-17 09:07:06 --> File loaded: application/views/layout/main.php
DEBUG - 2011-09-17 09:07:06 --> Final output sent to browser
DEBUG - 2011-09-17 09:07:06 --> Total execution time: 0.0620
DEBUG - 2011-09-17 09:07:15 --> Config Class Initialized
DEBUG - 2011-09-17 09:07:15 --> Hooks Class Initialized
DEBUG - 2011-09-17 09:07:15 --> Utf8 Class Initialized
DEBUG - 2011-09-17 09:07:15 --> UTF-8 Support Enabled
DEBUG - 2011-09-17 09:07:15 --> URI Class Initialized
DEBUG - 2011-09-17 09:07:15 --> Router Class Initialized
DEBUG - 2011-09-17 09:07:15 --> Output Class Initialized
DEBUG - 2011-09-17 09:07:15 --> Input Class Initialized
DEBUG - 2011-09-17 09:07:15 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-17 09:07:15 --> Language Class Initialized
DEBUG - 2011-09-17 09:07:15 --> Loader Class Initialized
DEBUG - 2011-09-17 09:07:15 --> Controller Class Initialized
DEBUG - 2011-09-17 09:07:15 --> Model Class Initialized
DEBUG - 2011-09-17 09:07:15 --> Model Class Initialized
DEBUG - 2011-09-17 09:07:15 --> Model Class Initialized
DEBUG - 2011-09-17 09:07:15 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-17 09:07:15 --> Database Driver Class Initialized
DEBUG - 2011-09-17 09:07:17 --> File loaded: application/views/table/main.php
DEBUG - 2011-09-17 09:07:17 --> Helper loaded: url_helper
DEBUG - 2011-09-17 09:07:17 --> File loaded: application/views/common/header.php
DEBUG - 2011-09-17 09:07:17 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-09-17 09:07:17 --> File loaded: application/views/common/footer.php
DEBUG - 2011-09-17 09:07:17 --> File loaded: application/views/layout/main.php
DEBUG - 2011-09-17 09:07:17 --> Final output sent to browser
DEBUG - 2011-09-17 09:07:17 --> Total execution time: 1.6254
DEBUG - 2011-09-17 09:07:18 --> Config Class Initialized
DEBUG - 2011-09-17 09:07:18 --> Hooks Class Initialized
DEBUG - 2011-09-17 09:07:18 --> Utf8 Class Initialized
DEBUG - 2011-09-17 09:07:18 --> UTF-8 Support Enabled
DEBUG - 2011-09-17 09:07:18 --> URI Class Initialized
DEBUG - 2011-09-17 09:07:18 --> Router Class Initialized
DEBUG - 2011-09-17 09:07:18 --> Output Class Initialized
DEBUG - 2011-09-17 09:07:18 --> Input Class Initialized
DEBUG - 2011-09-17 09:07:18 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-17 09:07:18 --> Language Class Initialized
DEBUG - 2011-09-17 09:07:18 --> Loader Class Initialized
DEBUG - 2011-09-17 09:07:18 --> Controller Class Initialized
DEBUG - 2011-09-17 09:07:18 --> Model Class Initialized
DEBUG - 2011-09-17 09:07:18 --> Model Class Initialized
DEBUG - 2011-09-17 09:07:18 --> Model Class Initialized
DEBUG - 2011-09-17 09:07:18 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-17 09:07:18 --> Database Driver Class Initialized
DEBUG - 2011-09-17 09:07:18 --> File loaded: application/views/table/main.php
DEBUG - 2011-09-17 09:07:18 --> Helper loaded: url_helper
DEBUG - 2011-09-17 09:07:18 --> File loaded: application/views/common/header.php
DEBUG - 2011-09-17 09:07:18 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-09-17 09:07:18 --> File loaded: application/views/common/footer.php
DEBUG - 2011-09-17 09:07:18 --> File loaded: application/views/layout/main.php
DEBUG - 2011-09-17 09:07:18 --> Final output sent to browser
DEBUG - 2011-09-17 09:07:18 --> Total execution time: 0.0925
DEBUG - 2011-09-17 09:07:24 --> Config Class Initialized
DEBUG - 2011-09-17 09:07:24 --> Hooks Class Initialized
DEBUG - 2011-09-17 09:07:24 --> Utf8 Class Initialized
DEBUG - 2011-09-17 09:07:24 --> UTF-8 Support Enabled
DEBUG - 2011-09-17 09:07:24 --> URI Class Initialized
DEBUG - 2011-09-17 09:07:24 --> Router Class Initialized
DEBUG - 2011-09-17 09:07:24 --> Output Class Initialized
DEBUG - 2011-09-17 09:07:24 --> Input Class Initialized
DEBUG - 2011-09-17 09:07:24 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-17 09:07:24 --> Language Class Initialized
DEBUG - 2011-09-17 09:07:24 --> Loader Class Initialized
DEBUG - 2011-09-17 09:07:24 --> Controller Class Initialized
DEBUG - 2011-09-17 09:07:24 --> Model Class Initialized
DEBUG - 2011-09-17 09:07:24 --> Model Class Initialized
DEBUG - 2011-09-17 09:07:24 --> Model Class Initialized
DEBUG - 2011-09-17 09:07:24 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-17 09:07:24 --> Database Driver Class Initialized
DEBUG - 2011-09-17 09:07:24 --> File loaded: application/views/table/main.php
DEBUG - 2011-09-17 09:07:24 --> Helper loaded: url_helper
DEBUG - 2011-09-17 09:07:24 --> File loaded: application/views/common/header.php
DEBUG - 2011-09-17 09:07:24 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-09-17 09:07:24 --> File loaded: application/views/common/footer.php
DEBUG - 2011-09-17 09:07:24 --> File loaded: application/views/layout/main.php
DEBUG - 2011-09-17 09:07:24 --> Final output sent to browser
DEBUG - 2011-09-17 09:07:24 --> Total execution time: 0.5939
DEBUG - 2011-09-17 09:07:34 --> Config Class Initialized
DEBUG - 2011-09-17 09:07:34 --> Hooks Class Initialized
DEBUG - 2011-09-17 09:07:34 --> Utf8 Class Initialized
DEBUG - 2011-09-17 09:07:34 --> UTF-8 Support Enabled
DEBUG - 2011-09-17 09:07:34 --> URI Class Initialized
DEBUG - 2011-09-17 09:07:34 --> Router Class Initialized
DEBUG - 2011-09-17 09:07:34 --> Output Class Initialized
DEBUG - 2011-09-17 09:07:34 --> Input Class Initialized
DEBUG - 2011-09-17 09:07:34 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-17 09:07:34 --> Language Class Initialized
DEBUG - 2011-09-17 09:07:34 --> Loader Class Initialized
DEBUG - 2011-09-17 09:07:34 --> Controller Class Initialized
DEBUG - 2011-09-17 09:07:34 --> Model Class Initialized
DEBUG - 2011-09-17 09:07:34 --> Model Class Initialized
DEBUG - 2011-09-17 09:07:34 --> Model Class Initialized
DEBUG - 2011-09-17 09:07:34 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-17 09:07:34 --> Database Driver Class Initialized
DEBUG - 2011-09-17 09:07:34 --> File loaded: application/views/table/main.php
DEBUG - 2011-09-17 09:07:34 --> Helper loaded: url_helper
DEBUG - 2011-09-17 09:07:34 --> File loaded: application/views/common/header.php
DEBUG - 2011-09-17 09:07:34 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-09-17 09:07:34 --> File loaded: application/views/common/footer.php
DEBUG - 2011-09-17 09:07:34 --> File loaded: application/views/layout/main.php
DEBUG - 2011-09-17 09:07:34 --> Final output sent to browser
DEBUG - 2011-09-17 09:07:34 --> Total execution time: 0.3725
DEBUG - 2011-09-17 09:07:38 --> Config Class Initialized
DEBUG - 2011-09-17 09:07:38 --> Hooks Class Initialized
DEBUG - 2011-09-17 09:07:38 --> Utf8 Class Initialized
DEBUG - 2011-09-17 09:07:38 --> UTF-8 Support Enabled
DEBUG - 2011-09-17 09:07:38 --> URI Class Initialized
DEBUG - 2011-09-17 09:07:38 --> Router Class Initialized
DEBUG - 2011-09-17 09:07:38 --> Output Class Initialized
DEBUG - 2011-09-17 09:07:38 --> Input Class Initialized
DEBUG - 2011-09-17 09:07:38 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-17 09:07:38 --> Language Class Initialized
DEBUG - 2011-09-17 09:07:38 --> Loader Class Initialized
DEBUG - 2011-09-17 09:07:38 --> Controller Class Initialized
DEBUG - 2011-09-17 09:07:38 --> Model Class Initialized
DEBUG - 2011-09-17 09:07:38 --> Model Class Initialized
DEBUG - 2011-09-17 09:07:38 --> Model Class Initialized
DEBUG - 2011-09-17 09:07:38 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-17 09:07:38 --> Database Driver Class Initialized
DEBUG - 2011-09-17 09:07:38 --> File loaded: application/views/table/main.php
DEBUG - 2011-09-17 09:07:38 --> Helper loaded: url_helper
DEBUG - 2011-09-17 09:07:38 --> File loaded: application/views/common/header.php
DEBUG - 2011-09-17 09:07:38 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-09-17 09:07:38 --> File loaded: application/views/common/footer.php
DEBUG - 2011-09-17 09:07:38 --> File loaded: application/views/layout/main.php
DEBUG - 2011-09-17 09:07:38 --> Final output sent to browser
DEBUG - 2011-09-17 09:07:38 --> Total execution time: 0.0541
DEBUG - 2011-09-17 09:07:51 --> Config Class Initialized
DEBUG - 2011-09-17 09:07:51 --> Hooks Class Initialized
DEBUG - 2011-09-17 09:07:51 --> Utf8 Class Initialized
DEBUG - 2011-09-17 09:07:51 --> UTF-8 Support Enabled
DEBUG - 2011-09-17 09:07:51 --> URI Class Initialized
DEBUG - 2011-09-17 09:07:51 --> Router Class Initialized
DEBUG - 2011-09-17 09:07:51 --> Output Class Initialized
DEBUG - 2011-09-17 09:07:51 --> Input Class Initialized
DEBUG - 2011-09-17 09:07:51 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-17 09:07:51 --> Language Class Initialized
DEBUG - 2011-09-17 09:07:51 --> Loader Class Initialized
DEBUG - 2011-09-17 09:07:51 --> Controller Class Initialized
DEBUG - 2011-09-17 09:07:51 --> Model Class Initialized
DEBUG - 2011-09-17 09:07:51 --> Model Class Initialized
DEBUG - 2011-09-17 09:07:51 --> Model Class Initialized
DEBUG - 2011-09-17 09:07:51 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-17 09:07:51 --> Database Driver Class Initialized
DEBUG - 2011-09-17 09:07:51 --> File loaded: application/views/table/main.php
DEBUG - 2011-09-17 09:07:51 --> Helper loaded: url_helper
DEBUG - 2011-09-17 09:07:51 --> File loaded: application/views/common/header.php
DEBUG - 2011-09-17 09:07:51 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-09-17 09:07:51 --> File loaded: application/views/common/footer.php
DEBUG - 2011-09-17 09:07:51 --> File loaded: application/views/layout/main.php
DEBUG - 2011-09-17 09:07:51 --> Final output sent to browser
DEBUG - 2011-09-17 09:07:51 --> Total execution time: 0.0528
DEBUG - 2011-09-17 09:07:52 --> Config Class Initialized
DEBUG - 2011-09-17 09:07:52 --> Hooks Class Initialized
DEBUG - 2011-09-17 09:07:52 --> Utf8 Class Initialized
DEBUG - 2011-09-17 09:07:52 --> UTF-8 Support Enabled
DEBUG - 2011-09-17 09:07:52 --> URI Class Initialized
DEBUG - 2011-09-17 09:07:52 --> Router Class Initialized
DEBUG - 2011-09-17 09:07:52 --> Output Class Initialized
DEBUG - 2011-09-17 09:07:52 --> Input Class Initialized
DEBUG - 2011-09-17 09:07:52 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-17 09:07:52 --> Language Class Initialized
DEBUG - 2011-09-17 09:07:52 --> Loader Class Initialized
DEBUG - 2011-09-17 09:07:52 --> Controller Class Initialized
DEBUG - 2011-09-17 09:07:52 --> Model Class Initialized
DEBUG - 2011-09-17 09:07:52 --> Model Class Initialized
DEBUG - 2011-09-17 09:07:52 --> Model Class Initialized
DEBUG - 2011-09-17 09:07:52 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-17 09:07:52 --> Database Driver Class Initialized
DEBUG - 2011-09-17 09:07:52 --> File loaded: application/views/table/main.php
DEBUG - 2011-09-17 09:07:52 --> Helper loaded: url_helper
DEBUG - 2011-09-17 09:07:52 --> File loaded: application/views/common/header.php
DEBUG - 2011-09-17 09:07:52 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-09-17 09:07:52 --> File loaded: application/views/common/footer.php
DEBUG - 2011-09-17 09:07:52 --> File loaded: application/views/layout/main.php
DEBUG - 2011-09-17 09:07:52 --> Final output sent to browser
DEBUG - 2011-09-17 09:07:52 --> Total execution time: 0.0733
DEBUG - 2011-09-17 09:07:58 --> Config Class Initialized
DEBUG - 2011-09-17 09:07:58 --> Hooks Class Initialized
DEBUG - 2011-09-17 09:07:58 --> Utf8 Class Initialized
DEBUG - 2011-09-17 09:07:58 --> UTF-8 Support Enabled
DEBUG - 2011-09-17 09:07:58 --> URI Class Initialized
DEBUG - 2011-09-17 09:07:58 --> Router Class Initialized
DEBUG - 2011-09-17 09:07:58 --> Output Class Initialized
DEBUG - 2011-09-17 09:07:58 --> Input Class Initialized
DEBUG - 2011-09-17 09:07:58 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-17 09:07:58 --> Language Class Initialized
DEBUG - 2011-09-17 09:07:58 --> Loader Class Initialized
DEBUG - 2011-09-17 09:07:58 --> Controller Class Initialized
DEBUG - 2011-09-17 09:07:58 --> Model Class Initialized
DEBUG - 2011-09-17 09:07:58 --> Model Class Initialized
DEBUG - 2011-09-17 09:07:58 --> Model Class Initialized
DEBUG - 2011-09-17 09:07:58 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-17 09:07:58 --> Database Driver Class Initialized
DEBUG - 2011-09-17 09:07:58 --> File loaded: application/views/table/main.php
DEBUG - 2011-09-17 09:07:58 --> Helper loaded: url_helper
DEBUG - 2011-09-17 09:07:58 --> File loaded: application/views/common/header.php
DEBUG - 2011-09-17 09:07:58 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-09-17 09:07:58 --> File loaded: application/views/common/footer.php
DEBUG - 2011-09-17 09:07:58 --> File loaded: application/views/layout/main.php
DEBUG - 2011-09-17 09:07:58 --> Final output sent to browser
DEBUG - 2011-09-17 09:07:58 --> Total execution time: 0.4246
DEBUG - 2011-09-17 09:08:03 --> Config Class Initialized
DEBUG - 2011-09-17 09:08:03 --> Hooks Class Initialized
DEBUG - 2011-09-17 09:08:03 --> Utf8 Class Initialized
DEBUG - 2011-09-17 09:08:03 --> UTF-8 Support Enabled
DEBUG - 2011-09-17 09:08:03 --> URI Class Initialized
DEBUG - 2011-09-17 09:08:03 --> Router Class Initialized
DEBUG - 2011-09-17 09:08:03 --> Output Class Initialized
DEBUG - 2011-09-17 09:08:03 --> Input Class Initialized
DEBUG - 2011-09-17 09:08:03 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-17 09:08:03 --> Language Class Initialized
DEBUG - 2011-09-17 09:08:03 --> Loader Class Initialized
DEBUG - 2011-09-17 09:08:03 --> Controller Class Initialized
DEBUG - 2011-09-17 09:08:03 --> Model Class Initialized
DEBUG - 2011-09-17 09:08:03 --> Model Class Initialized
DEBUG - 2011-09-17 09:08:03 --> Model Class Initialized
DEBUG - 2011-09-17 09:08:03 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-17 09:08:03 --> Database Driver Class Initialized
DEBUG - 2011-09-17 09:08:04 --> File loaded: application/views/table/main.php
DEBUG - 2011-09-17 09:08:04 --> Helper loaded: url_helper
DEBUG - 2011-09-17 09:08:04 --> File loaded: application/views/common/header.php
DEBUG - 2011-09-17 09:08:04 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-09-17 09:08:04 --> File loaded: application/views/common/footer.php
DEBUG - 2011-09-17 09:08:04 --> File loaded: application/views/layout/main.php
DEBUG - 2011-09-17 09:08:04 --> Final output sent to browser
DEBUG - 2011-09-17 09:08:04 --> Total execution time: 0.3467
DEBUG - 2011-09-17 09:08:05 --> Config Class Initialized
DEBUG - 2011-09-17 09:08:05 --> Hooks Class Initialized
DEBUG - 2011-09-17 09:08:05 --> Utf8 Class Initialized
DEBUG - 2011-09-17 09:08:05 --> UTF-8 Support Enabled
DEBUG - 2011-09-17 09:08:05 --> URI Class Initialized
DEBUG - 2011-09-17 09:08:05 --> Router Class Initialized
DEBUG - 2011-09-17 09:08:05 --> Output Class Initialized
DEBUG - 2011-09-17 09:08:05 --> Input Class Initialized
DEBUG - 2011-09-17 09:08:05 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-17 09:08:05 --> Language Class Initialized
DEBUG - 2011-09-17 09:08:05 --> Loader Class Initialized
DEBUG - 2011-09-17 09:08:05 --> Controller Class Initialized
DEBUG - 2011-09-17 09:08:05 --> Model Class Initialized
DEBUG - 2011-09-17 09:08:05 --> Model Class Initialized
DEBUG - 2011-09-17 09:08:05 --> Model Class Initialized
DEBUG - 2011-09-17 09:08:05 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-17 09:08:05 --> Database Driver Class Initialized
DEBUG - 2011-09-17 09:08:05 --> File loaded: application/views/table/main.php
DEBUG - 2011-09-17 09:08:05 --> Helper loaded: url_helper
DEBUG - 2011-09-17 09:08:05 --> File loaded: application/views/common/header.php
DEBUG - 2011-09-17 09:08:05 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-09-17 09:08:05 --> File loaded: application/views/common/footer.php
DEBUG - 2011-09-17 09:08:05 --> File loaded: application/views/layout/main.php
DEBUG - 2011-09-17 09:08:05 --> Final output sent to browser
DEBUG - 2011-09-17 09:08:05 --> Total execution time: 0.0657
DEBUG - 2011-09-17 09:08:09 --> Config Class Initialized
DEBUG - 2011-09-17 09:08:09 --> Hooks Class Initialized
DEBUG - 2011-09-17 09:08:09 --> Utf8 Class Initialized
DEBUG - 2011-09-17 09:08:09 --> UTF-8 Support Enabled
DEBUG - 2011-09-17 09:08:09 --> URI Class Initialized
DEBUG - 2011-09-17 09:08:09 --> Router Class Initialized
DEBUG - 2011-09-17 09:08:09 --> Output Class Initialized
DEBUG - 2011-09-17 09:08:09 --> Input Class Initialized
DEBUG - 2011-09-17 09:08:09 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-17 09:08:09 --> Language Class Initialized
DEBUG - 2011-09-17 09:08:09 --> Loader Class Initialized
DEBUG - 2011-09-17 09:08:09 --> Controller Class Initialized
DEBUG - 2011-09-17 09:08:09 --> Model Class Initialized
DEBUG - 2011-09-17 09:08:09 --> Model Class Initialized
DEBUG - 2011-09-17 09:08:09 --> Model Class Initialized
DEBUG - 2011-09-17 09:08:09 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-17 09:08:09 --> Database Driver Class Initialized
DEBUG - 2011-09-17 09:08:09 --> File loaded: application/views/table/main.php
DEBUG - 2011-09-17 09:08:09 --> Helper loaded: url_helper
DEBUG - 2011-09-17 09:08:09 --> File loaded: application/views/common/header.php
DEBUG - 2011-09-17 09:08:09 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-09-17 09:08:09 --> File loaded: application/views/common/footer.php
DEBUG - 2011-09-17 09:08:09 --> File loaded: application/views/layout/main.php
DEBUG - 2011-09-17 09:08:09 --> Final output sent to browser
DEBUG - 2011-09-17 09:08:09 --> Total execution time: 0.2430
DEBUG - 2011-09-17 09:08:10 --> Config Class Initialized
DEBUG - 2011-09-17 09:08:10 --> Hooks Class Initialized
DEBUG - 2011-09-17 09:08:10 --> Utf8 Class Initialized
DEBUG - 2011-09-17 09:08:10 --> UTF-8 Support Enabled
DEBUG - 2011-09-17 09:08:10 --> URI Class Initialized
DEBUG - 2011-09-17 09:08:10 --> Router Class Initialized
DEBUG - 2011-09-17 09:08:10 --> Output Class Initialized
DEBUG - 2011-09-17 09:08:10 --> Input Class Initialized
DEBUG - 2011-09-17 09:08:10 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-17 09:08:10 --> Language Class Initialized
DEBUG - 2011-09-17 09:08:10 --> Loader Class Initialized
DEBUG - 2011-09-17 09:08:10 --> Controller Class Initialized
DEBUG - 2011-09-17 09:08:10 --> Model Class Initialized
DEBUG - 2011-09-17 09:08:10 --> Model Class Initialized
DEBUG - 2011-09-17 09:08:10 --> Model Class Initialized
DEBUG - 2011-09-17 09:08:10 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-17 09:08:10 --> Database Driver Class Initialized
DEBUG - 2011-09-17 09:08:10 --> File loaded: application/views/table/main.php
DEBUG - 2011-09-17 09:08:10 --> Helper loaded: url_helper
DEBUG - 2011-09-17 09:08:10 --> File loaded: application/views/common/header.php
DEBUG - 2011-09-17 09:08:10 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-09-17 09:08:10 --> File loaded: application/views/common/footer.php
DEBUG - 2011-09-17 09:08:10 --> File loaded: application/views/layout/main.php
DEBUG - 2011-09-17 09:08:10 --> Final output sent to browser
DEBUG - 2011-09-17 09:08:10 --> Total execution time: 0.0443
DEBUG - 2011-09-17 09:08:15 --> Config Class Initialized
DEBUG - 2011-09-17 09:08:15 --> Hooks Class Initialized
DEBUG - 2011-09-17 09:08:15 --> Utf8 Class Initialized
DEBUG - 2011-09-17 09:08:15 --> UTF-8 Support Enabled
DEBUG - 2011-09-17 09:08:15 --> URI Class Initialized
DEBUG - 2011-09-17 09:08:15 --> Router Class Initialized
DEBUG - 2011-09-17 09:08:15 --> Output Class Initialized
DEBUG - 2011-09-17 09:08:15 --> Input Class Initialized
DEBUG - 2011-09-17 09:08:15 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-17 09:08:15 --> Language Class Initialized
DEBUG - 2011-09-17 09:08:15 --> Loader Class Initialized
DEBUG - 2011-09-17 09:08:15 --> Controller Class Initialized
DEBUG - 2011-09-17 09:08:15 --> Model Class Initialized
DEBUG - 2011-09-17 09:08:15 --> Model Class Initialized
DEBUG - 2011-09-17 09:08:15 --> Model Class Initialized
DEBUG - 2011-09-17 09:08:15 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-17 09:08:15 --> Database Driver Class Initialized
DEBUG - 2011-09-17 09:08:15 --> File loaded: application/views/table/main.php
DEBUG - 2011-09-17 09:08:15 --> Helper loaded: url_helper
DEBUG - 2011-09-17 09:08:15 --> File loaded: application/views/common/header.php
DEBUG - 2011-09-17 09:08:15 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-09-17 09:08:15 --> File loaded: application/views/common/footer.php
DEBUG - 2011-09-17 09:08:15 --> File loaded: application/views/layout/main.php
DEBUG - 2011-09-17 09:08:15 --> Final output sent to browser
DEBUG - 2011-09-17 09:08:15 --> Total execution time: 0.3062
DEBUG - 2011-09-17 09:08:16 --> Config Class Initialized
DEBUG - 2011-09-17 09:08:16 --> Hooks Class Initialized
DEBUG - 2011-09-17 09:08:16 --> Utf8 Class Initialized
DEBUG - 2011-09-17 09:08:16 --> UTF-8 Support Enabled
DEBUG - 2011-09-17 09:08:16 --> URI Class Initialized
DEBUG - 2011-09-17 09:08:16 --> Router Class Initialized
DEBUG - 2011-09-17 09:08:16 --> Output Class Initialized
DEBUG - 2011-09-17 09:08:16 --> Input Class Initialized
DEBUG - 2011-09-17 09:08:16 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-17 09:08:16 --> Language Class Initialized
DEBUG - 2011-09-17 09:08:16 --> Loader Class Initialized
DEBUG - 2011-09-17 09:08:16 --> Controller Class Initialized
DEBUG - 2011-09-17 09:08:16 --> Model Class Initialized
DEBUG - 2011-09-17 09:08:16 --> Model Class Initialized
DEBUG - 2011-09-17 09:08:16 --> Model Class Initialized
DEBUG - 2011-09-17 09:08:16 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-17 09:08:16 --> Database Driver Class Initialized
DEBUG - 2011-09-17 09:08:16 --> File loaded: application/views/table/main.php
DEBUG - 2011-09-17 09:08:16 --> Helper loaded: url_helper
DEBUG - 2011-09-17 09:08:16 --> File loaded: application/views/common/header.php
DEBUG - 2011-09-17 09:08:16 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-09-17 09:08:16 --> File loaded: application/views/common/footer.php
DEBUG - 2011-09-17 09:08:16 --> File loaded: application/views/layout/main.php
DEBUG - 2011-09-17 09:08:16 --> Final output sent to browser
DEBUG - 2011-09-17 09:08:16 --> Total execution time: 0.1098
DEBUG - 2011-09-17 09:08:22 --> Config Class Initialized
DEBUG - 2011-09-17 09:08:22 --> Hooks Class Initialized
DEBUG - 2011-09-17 09:08:22 --> Utf8 Class Initialized
DEBUG - 2011-09-17 09:08:22 --> UTF-8 Support Enabled
DEBUG - 2011-09-17 09:08:22 --> URI Class Initialized
DEBUG - 2011-09-17 09:08:22 --> Router Class Initialized
DEBUG - 2011-09-17 09:08:22 --> Output Class Initialized
DEBUG - 2011-09-17 09:08:22 --> Input Class Initialized
DEBUG - 2011-09-17 09:08:22 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-17 09:08:22 --> Language Class Initialized
DEBUG - 2011-09-17 09:08:22 --> Loader Class Initialized
DEBUG - 2011-09-17 09:08:22 --> Controller Class Initialized
DEBUG - 2011-09-17 09:08:22 --> Model Class Initialized
DEBUG - 2011-09-17 09:08:22 --> Model Class Initialized
DEBUG - 2011-09-17 09:08:22 --> Model Class Initialized
DEBUG - 2011-09-17 09:08:22 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-17 09:08:22 --> Database Driver Class Initialized
DEBUG - 2011-09-17 09:08:22 --> File loaded: application/views/table/main.php
DEBUG - 2011-09-17 09:08:22 --> Helper loaded: url_helper
DEBUG - 2011-09-17 09:08:22 --> File loaded: application/views/common/header.php
DEBUG - 2011-09-17 09:08:22 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-09-17 09:08:22 --> File loaded: application/views/common/footer.php
DEBUG - 2011-09-17 09:08:22 --> File loaded: application/views/layout/main.php
DEBUG - 2011-09-17 09:08:22 --> Final output sent to browser
DEBUG - 2011-09-17 09:08:22 --> Total execution time: 0.0462
DEBUG - 2011-09-17 09:08:27 --> Config Class Initialized
DEBUG - 2011-09-17 09:08:27 --> Hooks Class Initialized
DEBUG - 2011-09-17 09:08:27 --> Utf8 Class Initialized
DEBUG - 2011-09-17 09:08:27 --> UTF-8 Support Enabled
DEBUG - 2011-09-17 09:08:27 --> URI Class Initialized
DEBUG - 2011-09-17 09:08:27 --> Router Class Initialized
DEBUG - 2011-09-17 09:08:27 --> Output Class Initialized
DEBUG - 2011-09-17 09:08:27 --> Input Class Initialized
DEBUG - 2011-09-17 09:08:27 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-17 09:08:27 --> Language Class Initialized
DEBUG - 2011-09-17 09:08:27 --> Loader Class Initialized
DEBUG - 2011-09-17 09:08:27 --> Controller Class Initialized
DEBUG - 2011-09-17 09:08:27 --> Model Class Initialized
DEBUG - 2011-09-17 09:08:27 --> Model Class Initialized
DEBUG - 2011-09-17 09:08:27 --> Model Class Initialized
DEBUG - 2011-09-17 09:08:27 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-17 09:08:27 --> Database Driver Class Initialized
DEBUG - 2011-09-17 09:08:27 --> File loaded: application/views/table/main.php
DEBUG - 2011-09-17 09:08:27 --> Helper loaded: url_helper
DEBUG - 2011-09-17 09:08:27 --> File loaded: application/views/common/header.php
DEBUG - 2011-09-17 09:08:27 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-09-17 09:08:27 --> File loaded: application/views/common/footer.php
DEBUG - 2011-09-17 09:08:27 --> File loaded: application/views/layout/main.php
DEBUG - 2011-09-17 09:08:27 --> Final output sent to browser
DEBUG - 2011-09-17 09:08:27 --> Total execution time: 0.0508
DEBUG - 2011-09-17 09:09:38 --> Config Class Initialized
DEBUG - 2011-09-17 09:09:38 --> Hooks Class Initialized
DEBUG - 2011-09-17 09:09:38 --> Utf8 Class Initialized
DEBUG - 2011-09-17 09:09:38 --> UTF-8 Support Enabled
DEBUG - 2011-09-17 09:09:38 --> URI Class Initialized
DEBUG - 2011-09-17 09:09:38 --> Router Class Initialized
DEBUG - 2011-09-17 09:09:38 --> Output Class Initialized
DEBUG - 2011-09-17 09:09:38 --> Input Class Initialized
DEBUG - 2011-09-17 09:09:38 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-17 09:09:38 --> Language Class Initialized
DEBUG - 2011-09-17 09:09:38 --> Loader Class Initialized
DEBUG - 2011-09-17 09:09:38 --> Controller Class Initialized
DEBUG - 2011-09-17 09:09:38 --> Model Class Initialized
DEBUG - 2011-09-17 09:09:38 --> Model Class Initialized
DEBUG - 2011-09-17 09:09:38 --> Model Class Initialized
DEBUG - 2011-09-17 09:09:38 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-17 09:09:38 --> Database Driver Class Initialized
DEBUG - 2011-09-17 09:09:38 --> File loaded: application/views/table/main.php
DEBUG - 2011-09-17 09:09:38 --> Helper loaded: url_helper
DEBUG - 2011-09-17 09:09:38 --> File loaded: application/views/common/header.php
DEBUG - 2011-09-17 09:09:38 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-09-17 09:09:38 --> File loaded: application/views/common/footer.php
DEBUG - 2011-09-17 09:09:38 --> File loaded: application/views/layout/main.php
DEBUG - 2011-09-17 09:09:38 --> Final output sent to browser
DEBUG - 2011-09-17 09:09:38 --> Total execution time: 0.0522
DEBUG - 2011-09-17 09:09:39 --> Config Class Initialized
DEBUG - 2011-09-17 09:09:39 --> Hooks Class Initialized
DEBUG - 2011-09-17 09:09:39 --> Utf8 Class Initialized
DEBUG - 2011-09-17 09:09:39 --> UTF-8 Support Enabled
DEBUG - 2011-09-17 09:09:39 --> URI Class Initialized
DEBUG - 2011-09-17 09:09:39 --> Router Class Initialized
ERROR - 2011-09-17 09:09:39 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-09-17 09:09:40 --> Config Class Initialized
DEBUG - 2011-09-17 09:09:40 --> Hooks Class Initialized
DEBUG - 2011-09-17 09:09:40 --> Utf8 Class Initialized
DEBUG - 2011-09-17 09:09:40 --> UTF-8 Support Enabled
DEBUG - 2011-09-17 09:09:40 --> URI Class Initialized
DEBUG - 2011-09-17 09:09:40 --> Router Class Initialized
ERROR - 2011-09-17 09:09:40 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-09-17 09:10:07 --> Config Class Initialized
DEBUG - 2011-09-17 09:10:07 --> Hooks Class Initialized
DEBUG - 2011-09-17 09:10:07 --> Utf8 Class Initialized
DEBUG - 2011-09-17 09:10:07 --> UTF-8 Support Enabled
DEBUG - 2011-09-17 09:10:07 --> URI Class Initialized
DEBUG - 2011-09-17 09:10:07 --> Router Class Initialized
DEBUG - 2011-09-17 09:10:07 --> Output Class Initialized
DEBUG - 2011-09-17 09:10:07 --> Input Class Initialized
DEBUG - 2011-09-17 09:10:07 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-17 09:10:07 --> Language Class Initialized
DEBUG - 2011-09-17 09:10:07 --> Loader Class Initialized
DEBUG - 2011-09-17 09:10:07 --> Controller Class Initialized
DEBUG - 2011-09-17 09:10:07 --> Model Class Initialized
DEBUG - 2011-09-17 09:10:07 --> Model Class Initialized
DEBUG - 2011-09-17 09:10:07 --> Model Class Initialized
DEBUG - 2011-09-17 09:10:07 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-17 09:10:07 --> Database Driver Class Initialized
DEBUG - 2011-09-17 09:10:07 --> File loaded: application/views/table/main.php
DEBUG - 2011-09-17 09:10:07 --> Helper loaded: url_helper
DEBUG - 2011-09-17 09:10:07 --> File loaded: application/views/common/header.php
DEBUG - 2011-09-17 09:10:07 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-09-17 09:10:07 --> File loaded: application/views/common/footer.php
DEBUG - 2011-09-17 09:10:07 --> File loaded: application/views/layout/main.php
DEBUG - 2011-09-17 09:10:07 --> Final output sent to browser
DEBUG - 2011-09-17 09:10:07 --> Total execution time: 0.1170
DEBUG - 2011-09-17 09:16:36 --> Config Class Initialized
DEBUG - 2011-09-17 09:16:36 --> Hooks Class Initialized
DEBUG - 2011-09-17 09:16:36 --> Utf8 Class Initialized
DEBUG - 2011-09-17 09:16:36 --> UTF-8 Support Enabled
DEBUG - 2011-09-17 09:16:36 --> URI Class Initialized
DEBUG - 2011-09-17 09:16:36 --> Router Class Initialized
DEBUG - 2011-09-17 09:16:36 --> No URI present. Default controller set.
DEBUG - 2011-09-17 09:16:36 --> Output Class Initialized
DEBUG - 2011-09-17 09:16:36 --> Input Class Initialized
DEBUG - 2011-09-17 09:16:36 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-17 09:16:36 --> Language Class Initialized
DEBUG - 2011-09-17 09:16:36 --> Loader Class Initialized
DEBUG - 2011-09-17 09:16:36 --> Controller Class Initialized
DEBUG - 2011-09-17 09:16:36 --> File loaded: application/views/splash/main.php
DEBUG - 2011-09-17 09:16:36 --> Helper loaded: url_helper
DEBUG - 2011-09-17 09:16:36 --> File loaded: application/views/common/header.php
DEBUG - 2011-09-17 09:16:36 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-09-17 09:16:36 --> File loaded: application/views/common/footer.php
DEBUG - 2011-09-17 09:16:36 --> File loaded: application/views/layout/main.php
DEBUG - 2011-09-17 09:16:36 --> Final output sent to browser
DEBUG - 2011-09-17 09:16:36 --> Total execution time: 0.0553
DEBUG - 2011-09-17 09:26:30 --> Config Class Initialized
DEBUG - 2011-09-17 09:26:30 --> Hooks Class Initialized
DEBUG - 2011-09-17 09:26:30 --> Utf8 Class Initialized
DEBUG - 2011-09-17 09:26:30 --> UTF-8 Support Enabled
DEBUG - 2011-09-17 09:26:30 --> URI Class Initialized
DEBUG - 2011-09-17 09:26:30 --> Router Class Initialized
DEBUG - 2011-09-17 09:26:30 --> Output Class Initialized
DEBUG - 2011-09-17 09:26:30 --> Input Class Initialized
DEBUG - 2011-09-17 09:26:30 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-17 09:26:30 --> Language Class Initialized
DEBUG - 2011-09-17 09:26:30 --> Loader Class Initialized
DEBUG - 2011-09-17 09:26:30 --> Controller Class Initialized
ERROR - 2011-09-17 09:26:30 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-09-17 09:26:30 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-09-17 09:26:30 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-09-17 09:26:30 --> Model Class Initialized
DEBUG - 2011-09-17 09:26:30 --> Model Class Initialized
DEBUG - 2011-09-17 09:26:30 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-17 09:26:30 --> Database Driver Class Initialized
DEBUG - 2011-09-17 09:26:30 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-09-17 09:26:30 --> Helper loaded: url_helper
DEBUG - 2011-09-17 09:26:30 --> File loaded: application/views/common/header.php
DEBUG - 2011-09-17 09:26:30 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-09-17 09:26:30 --> File loaded: application/views/common/footer.php
DEBUG - 2011-09-17 09:26:30 --> File loaded: application/views/layout/main.php
DEBUG - 2011-09-17 09:26:30 --> Final output sent to browser
DEBUG - 2011-09-17 09:26:30 --> Total execution time: 0.0359
DEBUG - 2011-09-17 09:26:32 --> Config Class Initialized
DEBUG - 2011-09-17 09:26:32 --> Hooks Class Initialized
DEBUG - 2011-09-17 09:26:32 --> Utf8 Class Initialized
DEBUG - 2011-09-17 09:26:32 --> UTF-8 Support Enabled
DEBUG - 2011-09-17 09:26:32 --> URI Class Initialized
DEBUG - 2011-09-17 09:26:32 --> Router Class Initialized
DEBUG - 2011-09-17 09:26:32 --> Output Class Initialized
DEBUG - 2011-09-17 09:26:32 --> Input Class Initialized
DEBUG - 2011-09-17 09:26:32 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-17 09:26:32 --> Language Class Initialized
DEBUG - 2011-09-17 09:26:32 --> Loader Class Initialized
DEBUG - 2011-09-17 09:26:32 --> Controller Class Initialized
ERROR - 2011-09-17 09:26:32 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-09-17 09:26:32 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-09-17 09:26:32 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-09-17 09:26:32 --> Model Class Initialized
DEBUG - 2011-09-17 09:26:32 --> Model Class Initialized
DEBUG - 2011-09-17 09:26:32 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-17 09:26:32 --> Database Driver Class Initialized
DEBUG - 2011-09-17 09:26:32 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-09-17 09:26:32 --> Helper loaded: url_helper
DEBUG - 2011-09-17 09:26:32 --> File loaded: application/views/common/header.php
DEBUG - 2011-09-17 09:26:32 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-09-17 09:26:32 --> File loaded: application/views/common/footer.php
DEBUG - 2011-09-17 09:26:32 --> File loaded: application/views/layout/main.php
DEBUG - 2011-09-17 09:26:32 --> Final output sent to browser
DEBUG - 2011-09-17 09:26:32 --> Total execution time: 0.0301
DEBUG - 2011-09-17 09:26:36 --> Config Class Initialized
DEBUG - 2011-09-17 09:26:36 --> Hooks Class Initialized
DEBUG - 2011-09-17 09:26:36 --> Utf8 Class Initialized
DEBUG - 2011-09-17 09:26:36 --> UTF-8 Support Enabled
DEBUG - 2011-09-17 09:26:36 --> URI Class Initialized
DEBUG - 2011-09-17 09:26:36 --> Router Class Initialized
DEBUG - 2011-09-17 09:26:36 --> Output Class Initialized
DEBUG - 2011-09-17 09:26:36 --> Input Class Initialized
DEBUG - 2011-09-17 09:26:36 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-17 09:26:36 --> Language Class Initialized
DEBUG - 2011-09-17 09:26:36 --> Loader Class Initialized
DEBUG - 2011-09-17 09:26:36 --> Controller Class Initialized
DEBUG - 2011-09-17 09:26:36 --> Model Class Initialized
DEBUG - 2011-09-17 09:26:36 --> Model Class Initialized
DEBUG - 2011-09-17 09:26:36 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-17 09:26:36 --> Database Driver Class Initialized
DEBUG - 2011-09-17 09:26:36 --> Config Class Initialized
DEBUG - 2011-09-17 09:26:36 --> Hooks Class Initialized
DEBUG - 2011-09-17 09:26:36 --> Utf8 Class Initialized
DEBUG - 2011-09-17 09:26:36 --> UTF-8 Support Enabled
DEBUG - 2011-09-17 09:26:36 --> URI Class Initialized
DEBUG - 2011-09-17 09:26:36 --> Router Class Initialized
DEBUG - 2011-09-17 09:26:36 --> Output Class Initialized
DEBUG - 2011-09-17 09:26:36 --> Input Class Initialized
DEBUG - 2011-09-17 09:26:36 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-17 09:26:36 --> Language Class Initialized
DEBUG - 2011-09-17 09:26:36 --> Loader Class Initialized
DEBUG - 2011-09-17 09:26:36 --> Controller Class Initialized
DEBUG - 2011-09-17 09:26:36 --> Model Class Initialized
DEBUG - 2011-09-17 09:26:36 --> Model Class Initialized
DEBUG - 2011-09-17 09:26:36 --> Model Class Initialized
DEBUG - 2011-09-17 09:26:36 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-17 09:26:36 --> Database Driver Class Initialized
DEBUG - 2011-09-17 09:26:36 --> File loaded: application/views/table/main.php
DEBUG - 2011-09-17 09:26:36 --> Helper loaded: url_helper
DEBUG - 2011-09-17 09:26:36 --> File loaded: application/views/common/header.php
DEBUG - 2011-09-17 09:26:36 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-09-17 09:26:36 --> File loaded: application/views/common/footer.php
DEBUG - 2011-09-17 09:26:36 --> File loaded: application/views/layout/main.php
DEBUG - 2011-09-17 09:26:36 --> Final output sent to browser
DEBUG - 2011-09-17 09:26:36 --> Total execution time: 0.2011
DEBUG - 2011-09-17 09:26:36 --> Final output sent to browser
DEBUG - 2011-09-17 09:26:36 --> Total execution time: 0.6367
DEBUG - 2011-09-17 09:26:41 --> Config Class Initialized
DEBUG - 2011-09-17 09:26:41 --> Hooks Class Initialized
DEBUG - 2011-09-17 09:26:41 --> Utf8 Class Initialized
DEBUG - 2011-09-17 09:26:41 --> UTF-8 Support Enabled
DEBUG - 2011-09-17 09:26:41 --> URI Class Initialized
DEBUG - 2011-09-17 09:26:41 --> Router Class Initialized
ERROR - 2011-09-17 09:26:41 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-09-17 09:26:42 --> Config Class Initialized
DEBUG - 2011-09-17 09:26:42 --> Hooks Class Initialized
DEBUG - 2011-09-17 09:26:42 --> Utf8 Class Initialized
DEBUG - 2011-09-17 09:26:42 --> UTF-8 Support Enabled
DEBUG - 2011-09-17 09:26:42 --> URI Class Initialized
DEBUG - 2011-09-17 09:26:42 --> Router Class Initialized
ERROR - 2011-09-17 09:26:42 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-09-17 09:27:13 --> Config Class Initialized
DEBUG - 2011-09-17 09:27:13 --> Hooks Class Initialized
DEBUG - 2011-09-17 09:27:13 --> Utf8 Class Initialized
DEBUG - 2011-09-17 09:27:13 --> UTF-8 Support Enabled
DEBUG - 2011-09-17 09:27:13 --> URI Class Initialized
DEBUG - 2011-09-17 09:27:13 --> Router Class Initialized
DEBUG - 2011-09-17 09:27:13 --> Output Class Initialized
DEBUG - 2011-09-17 09:27:13 --> Input Class Initialized
DEBUG - 2011-09-17 09:27:13 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-17 09:27:13 --> Language Class Initialized
DEBUG - 2011-09-17 09:27:13 --> Loader Class Initialized
DEBUG - 2011-09-17 09:27:13 --> Controller Class Initialized
ERROR - 2011-09-17 09:27:13 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-09-17 09:27:13 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-09-17 09:27:13 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-09-17 09:27:13 --> Model Class Initialized
DEBUG - 2011-09-17 09:27:13 --> Model Class Initialized
DEBUG - 2011-09-17 09:27:13 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-17 09:27:13 --> Database Driver Class Initialized
DEBUG - 2011-09-17 09:27:13 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-09-17 09:27:13 --> Helper loaded: url_helper
DEBUG - 2011-09-17 09:27:13 --> File loaded: application/views/common/header.php
DEBUG - 2011-09-17 09:27:13 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-09-17 09:27:13 --> File loaded: application/views/common/footer.php
DEBUG - 2011-09-17 09:27:13 --> File loaded: application/views/layout/main.php
DEBUG - 2011-09-17 09:27:13 --> Final output sent to browser
DEBUG - 2011-09-17 09:27:13 --> Total execution time: 0.0299
DEBUG - 2011-09-17 09:27:14 --> Config Class Initialized
DEBUG - 2011-09-17 09:27:14 --> Hooks Class Initialized
DEBUG - 2011-09-17 09:27:14 --> Utf8 Class Initialized
DEBUG - 2011-09-17 09:27:14 --> UTF-8 Support Enabled
DEBUG - 2011-09-17 09:27:14 --> URI Class Initialized
DEBUG - 2011-09-17 09:27:14 --> Router Class Initialized
DEBUG - 2011-09-17 09:27:14 --> Output Class Initialized
DEBUG - 2011-09-17 09:27:14 --> Input Class Initialized
DEBUG - 2011-09-17 09:27:14 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-17 09:27:14 --> Language Class Initialized
DEBUG - 2011-09-17 09:27:14 --> Loader Class Initialized
DEBUG - 2011-09-17 09:27:14 --> Controller Class Initialized
DEBUG - 2011-09-17 09:27:14 --> Model Class Initialized
DEBUG - 2011-09-17 09:27:14 --> Model Class Initialized
DEBUG - 2011-09-17 09:27:14 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-17 09:27:14 --> Database Driver Class Initialized
DEBUG - 2011-09-17 09:27:15 --> Final output sent to browser
DEBUG - 2011-09-17 09:27:15 --> Total execution time: 1.2385
DEBUG - 2011-09-17 09:27:18 --> Config Class Initialized
DEBUG - 2011-09-17 09:27:18 --> Hooks Class Initialized
DEBUG - 2011-09-17 09:27:18 --> Utf8 Class Initialized
DEBUG - 2011-09-17 09:27:18 --> UTF-8 Support Enabled
DEBUG - 2011-09-17 09:27:18 --> URI Class Initialized
DEBUG - 2011-09-17 09:27:18 --> Router Class Initialized
ERROR - 2011-09-17 09:27:18 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-09-17 09:27:21 --> Config Class Initialized
DEBUG - 2011-09-17 09:27:21 --> Hooks Class Initialized
DEBUG - 2011-09-17 09:27:21 --> Utf8 Class Initialized
DEBUG - 2011-09-17 09:27:21 --> UTF-8 Support Enabled
DEBUG - 2011-09-17 09:27:21 --> URI Class Initialized
DEBUG - 2011-09-17 09:27:21 --> Router Class Initialized
DEBUG - 2011-09-17 09:27:21 --> Output Class Initialized
DEBUG - 2011-09-17 09:27:21 --> Input Class Initialized
DEBUG - 2011-09-17 09:27:21 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-17 09:27:21 --> Language Class Initialized
DEBUG - 2011-09-17 09:27:21 --> Loader Class Initialized
DEBUG - 2011-09-17 09:27:21 --> Controller Class Initialized
ERROR - 2011-09-17 09:27:21 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-09-17 09:27:21 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-09-17 09:27:21 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-09-17 09:27:21 --> Model Class Initialized
DEBUG - 2011-09-17 09:27:21 --> Model Class Initialized
DEBUG - 2011-09-17 09:27:21 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-17 09:27:21 --> Database Driver Class Initialized
DEBUG - 2011-09-17 09:27:22 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-09-17 09:27:22 --> Helper loaded: url_helper
DEBUG - 2011-09-17 09:27:22 --> File loaded: application/views/common/header.php
DEBUG - 2011-09-17 09:27:22 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-09-17 09:27:22 --> File loaded: application/views/common/footer.php
DEBUG - 2011-09-17 09:27:22 --> File loaded: application/views/layout/main.php
DEBUG - 2011-09-17 09:27:22 --> Final output sent to browser
DEBUG - 2011-09-17 09:27:22 --> Total execution time: 0.0687
DEBUG - 2011-09-17 09:27:23 --> Config Class Initialized
DEBUG - 2011-09-17 09:27:23 --> Hooks Class Initialized
DEBUG - 2011-09-17 09:27:23 --> Utf8 Class Initialized
DEBUG - 2011-09-17 09:27:23 --> UTF-8 Support Enabled
DEBUG - 2011-09-17 09:27:23 --> URI Class Initialized
DEBUG - 2011-09-17 09:27:23 --> Router Class Initialized
DEBUG - 2011-09-17 09:27:23 --> Output Class Initialized
DEBUG - 2011-09-17 09:27:23 --> Input Class Initialized
DEBUG - 2011-09-17 09:27:23 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-17 09:27:23 --> Language Class Initialized
DEBUG - 2011-09-17 09:27:23 --> Loader Class Initialized
DEBUG - 2011-09-17 09:27:23 --> Controller Class Initialized
DEBUG - 2011-09-17 09:27:23 --> Model Class Initialized
DEBUG - 2011-09-17 09:27:23 --> Model Class Initialized
DEBUG - 2011-09-17 09:27:23 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-17 09:27:23 --> Database Driver Class Initialized
DEBUG - 2011-09-17 09:27:24 --> Final output sent to browser
DEBUG - 2011-09-17 09:27:24 --> Total execution time: 0.5674
DEBUG - 2011-09-17 09:27:26 --> Config Class Initialized
DEBUG - 2011-09-17 09:27:26 --> Hooks Class Initialized
DEBUG - 2011-09-17 09:27:26 --> Utf8 Class Initialized
DEBUG - 2011-09-17 09:27:26 --> UTF-8 Support Enabled
DEBUG - 2011-09-17 09:27:26 --> URI Class Initialized
DEBUG - 2011-09-17 09:27:26 --> Router Class Initialized
ERROR - 2011-09-17 09:27:26 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-09-17 09:30:14 --> Config Class Initialized
DEBUG - 2011-09-17 09:30:14 --> Hooks Class Initialized
DEBUG - 2011-09-17 09:30:14 --> Utf8 Class Initialized
DEBUG - 2011-09-17 09:30:14 --> UTF-8 Support Enabled
DEBUG - 2011-09-17 09:30:14 --> URI Class Initialized
DEBUG - 2011-09-17 09:30:14 --> Router Class Initialized
DEBUG - 2011-09-17 09:30:14 --> Output Class Initialized
DEBUG - 2011-09-17 09:30:14 --> Input Class Initialized
DEBUG - 2011-09-17 09:30:14 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-17 09:30:14 --> Language Class Initialized
DEBUG - 2011-09-17 09:30:14 --> Loader Class Initialized
DEBUG - 2011-09-17 09:30:14 --> Controller Class Initialized
DEBUG - 2011-09-17 09:30:14 --> Model Class Initialized
DEBUG - 2011-09-17 09:30:14 --> Model Class Initialized
DEBUG - 2011-09-17 09:30:14 --> Model Class Initialized
DEBUG - 2011-09-17 09:30:14 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-17 09:30:14 --> Database Driver Class Initialized
DEBUG - 2011-09-17 09:30:14 --> File loaded: application/views/table/main.php
DEBUG - 2011-09-17 09:30:14 --> Helper loaded: url_helper
DEBUG - 2011-09-17 09:30:14 --> File loaded: application/views/common/header.php
DEBUG - 2011-09-17 09:30:14 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-09-17 09:30:14 --> File loaded: application/views/common/footer.php
DEBUG - 2011-09-17 09:30:14 --> File loaded: application/views/layout/main.php
DEBUG - 2011-09-17 09:30:14 --> Final output sent to browser
DEBUG - 2011-09-17 09:30:14 --> Total execution time: 0.2572
DEBUG - 2011-09-17 09:30:55 --> Config Class Initialized
DEBUG - 2011-09-17 09:30:55 --> Hooks Class Initialized
DEBUG - 2011-09-17 09:30:55 --> Utf8 Class Initialized
DEBUG - 2011-09-17 09:30:55 --> UTF-8 Support Enabled
DEBUG - 2011-09-17 09:30:55 --> URI Class Initialized
DEBUG - 2011-09-17 09:30:55 --> Router Class Initialized
DEBUG - 2011-09-17 09:30:55 --> Output Class Initialized
DEBUG - 2011-09-17 09:30:55 --> Input Class Initialized
DEBUG - 2011-09-17 09:30:55 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-17 09:30:55 --> Language Class Initialized
DEBUG - 2011-09-17 09:30:55 --> Loader Class Initialized
DEBUG - 2011-09-17 09:30:55 --> Controller Class Initialized
DEBUG - 2011-09-17 09:30:55 --> Model Class Initialized
DEBUG - 2011-09-17 09:30:55 --> Model Class Initialized
DEBUG - 2011-09-17 09:30:55 --> Model Class Initialized
DEBUG - 2011-09-17 09:30:55 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-17 09:30:55 --> Database Driver Class Initialized
DEBUG - 2011-09-17 09:30:55 --> File loaded: application/views/table/main.php
DEBUG - 2011-09-17 09:30:55 --> Helper loaded: url_helper
DEBUG - 2011-09-17 09:30:55 --> File loaded: application/views/common/header.php
DEBUG - 2011-09-17 09:30:55 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-09-17 09:30:55 --> File loaded: application/views/common/footer.php
DEBUG - 2011-09-17 09:30:55 --> File loaded: application/views/layout/main.php
DEBUG - 2011-09-17 09:30:55 --> Final output sent to browser
DEBUG - 2011-09-17 09:30:55 --> Total execution time: 0.6306
DEBUG - 2011-09-17 09:31:07 --> Config Class Initialized
DEBUG - 2011-09-17 09:31:07 --> Hooks Class Initialized
DEBUG - 2011-09-17 09:31:07 --> Utf8 Class Initialized
DEBUG - 2011-09-17 09:31:07 --> UTF-8 Support Enabled
DEBUG - 2011-09-17 09:31:07 --> URI Class Initialized
DEBUG - 2011-09-17 09:31:07 --> Router Class Initialized
DEBUG - 2011-09-17 09:31:07 --> Output Class Initialized
DEBUG - 2011-09-17 09:31:07 --> Input Class Initialized
DEBUG - 2011-09-17 09:31:07 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-17 09:31:07 --> Language Class Initialized
DEBUG - 2011-09-17 09:31:07 --> Loader Class Initialized
DEBUG - 2011-09-17 09:31:07 --> Controller Class Initialized
DEBUG - 2011-09-17 09:31:07 --> Model Class Initialized
DEBUG - 2011-09-17 09:31:07 --> Model Class Initialized
DEBUG - 2011-09-17 09:31:07 --> Model Class Initialized
DEBUG - 2011-09-17 09:31:07 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-17 09:31:07 --> Database Driver Class Initialized
DEBUG - 2011-09-17 09:31:07 --> File loaded: application/views/table/main.php
DEBUG - 2011-09-17 09:31:07 --> Helper loaded: url_helper
DEBUG - 2011-09-17 09:31:07 --> File loaded: application/views/common/header.php
DEBUG - 2011-09-17 09:31:07 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-09-17 09:31:07 --> File loaded: application/views/common/footer.php
DEBUG - 2011-09-17 09:31:07 --> File loaded: application/views/layout/main.php
DEBUG - 2011-09-17 09:31:07 --> Final output sent to browser
DEBUG - 2011-09-17 09:31:07 --> Total execution time: 0.0455
DEBUG - 2011-09-17 09:31:24 --> Config Class Initialized
DEBUG - 2011-09-17 09:31:24 --> Hooks Class Initialized
DEBUG - 2011-09-17 09:31:24 --> Utf8 Class Initialized
DEBUG - 2011-09-17 09:31:24 --> UTF-8 Support Enabled
DEBUG - 2011-09-17 09:31:24 --> URI Class Initialized
DEBUG - 2011-09-17 09:31:24 --> Router Class Initialized
DEBUG - 2011-09-17 09:31:24 --> Output Class Initialized
DEBUG - 2011-09-17 09:31:24 --> Input Class Initialized
DEBUG - 2011-09-17 09:31:24 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-17 09:31:24 --> Language Class Initialized
DEBUG - 2011-09-17 09:31:24 --> Loader Class Initialized
DEBUG - 2011-09-17 09:31:24 --> Controller Class Initialized
DEBUG - 2011-09-17 09:31:24 --> Model Class Initialized
DEBUG - 2011-09-17 09:31:24 --> Model Class Initialized
DEBUG - 2011-09-17 09:31:24 --> Model Class Initialized
DEBUG - 2011-09-17 09:31:24 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-17 09:31:24 --> Database Driver Class Initialized
DEBUG - 2011-09-17 09:31:24 --> File loaded: application/views/table/main.php
DEBUG - 2011-09-17 09:31:24 --> Helper loaded: url_helper
DEBUG - 2011-09-17 09:31:24 --> File loaded: application/views/common/header.php
DEBUG - 2011-09-17 09:31:24 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-09-17 09:31:24 --> File loaded: application/views/common/footer.php
DEBUG - 2011-09-17 09:31:24 --> File loaded: application/views/layout/main.php
DEBUG - 2011-09-17 09:31:24 --> Final output sent to browser
DEBUG - 2011-09-17 09:31:24 --> Total execution time: 0.0787
DEBUG - 2011-09-17 09:31:42 --> Config Class Initialized
DEBUG - 2011-09-17 09:31:42 --> Hooks Class Initialized
DEBUG - 2011-09-17 09:31:42 --> Utf8 Class Initialized
DEBUG - 2011-09-17 09:31:42 --> UTF-8 Support Enabled
DEBUG - 2011-09-17 09:31:42 --> URI Class Initialized
DEBUG - 2011-09-17 09:31:42 --> Router Class Initialized
DEBUG - 2011-09-17 09:31:42 --> Output Class Initialized
DEBUG - 2011-09-17 09:31:42 --> Input Class Initialized
DEBUG - 2011-09-17 09:31:42 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-17 09:31:42 --> Language Class Initialized
DEBUG - 2011-09-17 09:31:42 --> Loader Class Initialized
DEBUG - 2011-09-17 09:31:42 --> Controller Class Initialized
DEBUG - 2011-09-17 09:31:42 --> Model Class Initialized
DEBUG - 2011-09-17 09:31:42 --> Model Class Initialized
DEBUG - 2011-09-17 09:31:42 --> Model Class Initialized
DEBUG - 2011-09-17 09:31:42 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-17 09:31:42 --> Database Driver Class Initialized
DEBUG - 2011-09-17 09:31:42 --> File loaded: application/views/table/main.php
DEBUG - 2011-09-17 09:31:42 --> Helper loaded: url_helper
DEBUG - 2011-09-17 09:31:42 --> File loaded: application/views/common/header.php
DEBUG - 2011-09-17 09:31:42 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-09-17 09:31:42 --> File loaded: application/views/common/footer.php
DEBUG - 2011-09-17 09:31:42 --> File loaded: application/views/layout/main.php
DEBUG - 2011-09-17 09:31:42 --> Final output sent to browser
DEBUG - 2011-09-17 09:31:42 --> Total execution time: 0.0852
DEBUG - 2011-09-17 09:31:59 --> Config Class Initialized
DEBUG - 2011-09-17 09:31:59 --> Hooks Class Initialized
DEBUG - 2011-09-17 09:31:59 --> Utf8 Class Initialized
DEBUG - 2011-09-17 09:31:59 --> UTF-8 Support Enabled
DEBUG - 2011-09-17 09:31:59 --> URI Class Initialized
DEBUG - 2011-09-17 09:31:59 --> Router Class Initialized
DEBUG - 2011-09-17 09:31:59 --> Output Class Initialized
DEBUG - 2011-09-17 09:31:59 --> Input Class Initialized
DEBUG - 2011-09-17 09:31:59 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-17 09:31:59 --> Language Class Initialized
DEBUG - 2011-09-17 09:31:59 --> Loader Class Initialized
DEBUG - 2011-09-17 09:31:59 --> Controller Class Initialized
DEBUG - 2011-09-17 09:31:59 --> Model Class Initialized
DEBUG - 2011-09-17 09:31:59 --> Model Class Initialized
DEBUG - 2011-09-17 09:31:59 --> Model Class Initialized
DEBUG - 2011-09-17 09:31:59 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-17 09:31:59 --> Database Driver Class Initialized
DEBUG - 2011-09-17 09:31:59 --> File loaded: application/views/table/main.php
DEBUG - 2011-09-17 09:31:59 --> Helper loaded: url_helper
DEBUG - 2011-09-17 09:31:59 --> File loaded: application/views/common/header.php
DEBUG - 2011-09-17 09:31:59 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-09-17 09:31:59 --> File loaded: application/views/common/footer.php
DEBUG - 2011-09-17 09:31:59 --> File loaded: application/views/layout/main.php
DEBUG - 2011-09-17 09:31:59 --> Final output sent to browser
DEBUG - 2011-09-17 09:31:59 --> Total execution time: 0.0923
DEBUG - 2011-09-17 09:32:03 --> Config Class Initialized
DEBUG - 2011-09-17 09:32:03 --> Hooks Class Initialized
DEBUG - 2011-09-17 09:32:03 --> Utf8 Class Initialized
DEBUG - 2011-09-17 09:32:03 --> UTF-8 Support Enabled
DEBUG - 2011-09-17 09:32:03 --> URI Class Initialized
DEBUG - 2011-09-17 09:32:03 --> Router Class Initialized
DEBUG - 2011-09-17 09:32:03 --> Output Class Initialized
DEBUG - 2011-09-17 09:32:03 --> Input Class Initialized
DEBUG - 2011-09-17 09:32:03 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-17 09:32:03 --> Language Class Initialized
DEBUG - 2011-09-17 09:32:03 --> Loader Class Initialized
DEBUG - 2011-09-17 09:32:03 --> Controller Class Initialized
DEBUG - 2011-09-17 09:32:03 --> Model Class Initialized
DEBUG - 2011-09-17 09:32:03 --> Model Class Initialized
DEBUG - 2011-09-17 09:32:03 --> Model Class Initialized
DEBUG - 2011-09-17 09:32:03 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-17 09:32:03 --> Database Driver Class Initialized
DEBUG - 2011-09-17 09:32:04 --> File loaded: application/views/table/main.php
DEBUG - 2011-09-17 09:32:04 --> Helper loaded: url_helper
DEBUG - 2011-09-17 09:32:04 --> File loaded: application/views/common/header.php
DEBUG - 2011-09-17 09:32:04 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-09-17 09:32:04 --> File loaded: application/views/common/footer.php
DEBUG - 2011-09-17 09:32:04 --> File loaded: application/views/layout/main.php
DEBUG - 2011-09-17 09:32:04 --> Final output sent to browser
DEBUG - 2011-09-17 09:32:04 --> Total execution time: 0.7726
DEBUG - 2011-09-17 09:32:07 --> Config Class Initialized
DEBUG - 2011-09-17 09:32:07 --> Hooks Class Initialized
DEBUG - 2011-09-17 09:32:07 --> Utf8 Class Initialized
DEBUG - 2011-09-17 09:32:07 --> UTF-8 Support Enabled
DEBUG - 2011-09-17 09:32:07 --> URI Class Initialized
DEBUG - 2011-09-17 09:32:07 --> Router Class Initialized
ERROR - 2011-09-17 09:32:07 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-09-17 09:32:14 --> Config Class Initialized
DEBUG - 2011-09-17 09:32:14 --> Hooks Class Initialized
DEBUG - 2011-09-17 09:32:14 --> Utf8 Class Initialized
DEBUG - 2011-09-17 09:32:14 --> UTF-8 Support Enabled
DEBUG - 2011-09-17 09:32:14 --> URI Class Initialized
DEBUG - 2011-09-17 09:32:14 --> Router Class Initialized
DEBUG - 2011-09-17 09:32:14 --> Output Class Initialized
DEBUG - 2011-09-17 09:32:14 --> Input Class Initialized
DEBUG - 2011-09-17 09:32:14 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-17 09:32:14 --> Language Class Initialized
DEBUG - 2011-09-17 09:32:14 --> Loader Class Initialized
DEBUG - 2011-09-17 09:32:14 --> Controller Class Initialized
DEBUG - 2011-09-17 09:32:14 --> Model Class Initialized
DEBUG - 2011-09-17 09:32:14 --> Model Class Initialized
DEBUG - 2011-09-17 09:32:14 --> Model Class Initialized
DEBUG - 2011-09-17 09:32:14 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-17 09:32:14 --> Database Driver Class Initialized
DEBUG - 2011-09-17 09:32:15 --> File loaded: application/views/table/main.php
DEBUG - 2011-09-17 09:32:15 --> Helper loaded: url_helper
DEBUG - 2011-09-17 09:32:15 --> File loaded: application/views/common/header.php
DEBUG - 2011-09-17 09:32:15 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-09-17 09:32:15 --> File loaded: application/views/common/footer.php
DEBUG - 2011-09-17 09:32:15 --> File loaded: application/views/layout/main.php
DEBUG - 2011-09-17 09:32:15 --> Final output sent to browser
DEBUG - 2011-09-17 09:32:15 --> Total execution time: 1.3875
DEBUG - 2011-09-17 09:32:16 --> Config Class Initialized
DEBUG - 2011-09-17 09:32:16 --> Hooks Class Initialized
DEBUG - 2011-09-17 09:32:16 --> Utf8 Class Initialized
DEBUG - 2011-09-17 09:32:16 --> UTF-8 Support Enabled
DEBUG - 2011-09-17 09:32:16 --> URI Class Initialized
DEBUG - 2011-09-17 09:32:16 --> Router Class Initialized
DEBUG - 2011-09-17 09:32:16 --> Output Class Initialized
DEBUG - 2011-09-17 09:32:16 --> Input Class Initialized
DEBUG - 2011-09-17 09:32:16 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-17 09:32:16 --> Language Class Initialized
DEBUG - 2011-09-17 09:32:16 --> Loader Class Initialized
DEBUG - 2011-09-17 09:32:16 --> Controller Class Initialized
DEBUG - 2011-09-17 09:32:16 --> Model Class Initialized
DEBUG - 2011-09-17 09:32:16 --> Model Class Initialized
DEBUG - 2011-09-17 09:32:16 --> Model Class Initialized
DEBUG - 2011-09-17 09:32:16 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-17 09:32:16 --> Database Driver Class Initialized
DEBUG - 2011-09-17 09:32:17 --> File loaded: application/views/table/main.php
DEBUG - 2011-09-17 09:32:17 --> Helper loaded: url_helper
DEBUG - 2011-09-17 09:32:17 --> File loaded: application/views/common/header.php
DEBUG - 2011-09-17 09:32:17 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-09-17 09:32:17 --> File loaded: application/views/common/footer.php
DEBUG - 2011-09-17 09:32:17 --> File loaded: application/views/layout/main.php
DEBUG - 2011-09-17 09:32:17 --> Final output sent to browser
DEBUG - 2011-09-17 09:32:17 --> Total execution time: 0.5029
DEBUG - 2011-09-17 09:32:17 --> Config Class Initialized
DEBUG - 2011-09-17 09:32:17 --> Hooks Class Initialized
DEBUG - 2011-09-17 09:32:17 --> Utf8 Class Initialized
DEBUG - 2011-09-17 09:32:17 --> UTF-8 Support Enabled
DEBUG - 2011-09-17 09:32:17 --> URI Class Initialized
DEBUG - 2011-09-17 09:32:17 --> Router Class Initialized
ERROR - 2011-09-17 09:32:17 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-09-17 09:32:35 --> Config Class Initialized
DEBUG - 2011-09-17 09:32:35 --> Hooks Class Initialized
DEBUG - 2011-09-17 09:32:35 --> Utf8 Class Initialized
DEBUG - 2011-09-17 09:32:35 --> UTF-8 Support Enabled
DEBUG - 2011-09-17 09:32:35 --> URI Class Initialized
DEBUG - 2011-09-17 09:32:35 --> Router Class Initialized
DEBUG - 2011-09-17 09:32:35 --> Output Class Initialized
DEBUG - 2011-09-17 09:32:35 --> Input Class Initialized
DEBUG - 2011-09-17 09:32:35 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-17 09:32:35 --> Language Class Initialized
DEBUG - 2011-09-17 09:32:35 --> Loader Class Initialized
DEBUG - 2011-09-17 09:32:35 --> Controller Class Initialized
DEBUG - 2011-09-17 09:32:35 --> Model Class Initialized
DEBUG - 2011-09-17 09:32:35 --> Model Class Initialized
DEBUG - 2011-09-17 09:32:35 --> Model Class Initialized
DEBUG - 2011-09-17 09:32:35 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-17 09:32:35 --> Database Driver Class Initialized
DEBUG - 2011-09-17 09:32:36 --> File loaded: application/views/table/main.php
DEBUG - 2011-09-17 09:32:36 --> Helper loaded: url_helper
DEBUG - 2011-09-17 09:32:36 --> File loaded: application/views/common/header.php
DEBUG - 2011-09-17 09:32:36 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-09-17 09:32:36 --> File loaded: application/views/common/footer.php
DEBUG - 2011-09-17 09:32:36 --> File loaded: application/views/layout/main.php
DEBUG - 2011-09-17 09:32:36 --> Final output sent to browser
DEBUG - 2011-09-17 09:32:36 --> Total execution time: 0.5171
DEBUG - 2011-09-17 09:32:37 --> Config Class Initialized
DEBUG - 2011-09-17 09:32:37 --> Hooks Class Initialized
DEBUG - 2011-09-17 09:32:37 --> Utf8 Class Initialized
DEBUG - 2011-09-17 09:32:37 --> UTF-8 Support Enabled
DEBUG - 2011-09-17 09:32:37 --> URI Class Initialized
DEBUG - 2011-09-17 09:32:37 --> Router Class Initialized
DEBUG - 2011-09-17 09:32:37 --> Output Class Initialized
DEBUG - 2011-09-17 09:32:37 --> Input Class Initialized
DEBUG - 2011-09-17 09:32:37 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-17 09:32:37 --> Language Class Initialized
DEBUG - 2011-09-17 09:32:37 --> Loader Class Initialized
DEBUG - 2011-09-17 09:32:37 --> Controller Class Initialized
DEBUG - 2011-09-17 09:32:37 --> Model Class Initialized
DEBUG - 2011-09-17 09:32:37 --> Model Class Initialized
DEBUG - 2011-09-17 09:32:37 --> Model Class Initialized
DEBUG - 2011-09-17 09:32:37 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-17 09:32:37 --> Database Driver Class Initialized
DEBUG - 2011-09-17 09:32:37 --> File loaded: application/views/table/main.php
DEBUG - 2011-09-17 09:32:37 --> Helper loaded: url_helper
DEBUG - 2011-09-17 09:32:37 --> File loaded: application/views/common/header.php
DEBUG - 2011-09-17 09:32:37 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-09-17 09:32:37 --> File loaded: application/views/common/footer.php
DEBUG - 2011-09-17 09:32:37 --> File loaded: application/views/layout/main.php
DEBUG - 2011-09-17 09:32:37 --> Final output sent to browser
DEBUG - 2011-09-17 09:32:37 --> Total execution time: 0.0576
DEBUG - 2011-09-17 09:32:37 --> Config Class Initialized
DEBUG - 2011-09-17 09:32:37 --> Hooks Class Initialized
DEBUG - 2011-09-17 09:32:37 --> Utf8 Class Initialized
DEBUG - 2011-09-17 09:32:37 --> UTF-8 Support Enabled
DEBUG - 2011-09-17 09:32:37 --> URI Class Initialized
DEBUG - 2011-09-17 09:32:37 --> Router Class Initialized
DEBUG - 2011-09-17 09:32:37 --> Output Class Initialized
DEBUG - 2011-09-17 09:32:37 --> Input Class Initialized
DEBUG - 2011-09-17 09:32:37 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-17 09:32:37 --> Language Class Initialized
DEBUG - 2011-09-17 09:32:37 --> Loader Class Initialized
DEBUG - 2011-09-17 09:32:37 --> Controller Class Initialized
DEBUG - 2011-09-17 09:32:37 --> Model Class Initialized
DEBUG - 2011-09-17 09:32:37 --> Model Class Initialized
DEBUG - 2011-09-17 09:32:37 --> Model Class Initialized
DEBUG - 2011-09-17 09:32:37 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-17 09:32:37 --> Database Driver Class Initialized
DEBUG - 2011-09-17 09:32:38 --> File loaded: application/views/table/main.php
DEBUG - 2011-09-17 09:32:38 --> Helper loaded: url_helper
DEBUG - 2011-09-17 09:32:38 --> File loaded: application/views/common/header.php
DEBUG - 2011-09-17 09:32:38 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-09-17 09:32:38 --> File loaded: application/views/common/footer.php
DEBUG - 2011-09-17 09:32:38 --> File loaded: application/views/layout/main.php
DEBUG - 2011-09-17 09:32:38 --> Final output sent to browser
DEBUG - 2011-09-17 09:32:38 --> Total execution time: 0.0619
DEBUG - 2011-09-17 09:32:38 --> Config Class Initialized
DEBUG - 2011-09-17 09:32:38 --> Hooks Class Initialized
DEBUG - 2011-09-17 09:32:38 --> Utf8 Class Initialized
DEBUG - 2011-09-17 09:32:38 --> UTF-8 Support Enabled
DEBUG - 2011-09-17 09:32:38 --> URI Class Initialized
DEBUG - 2011-09-17 09:32:38 --> Router Class Initialized
ERROR - 2011-09-17 09:32:38 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-09-17 09:32:56 --> Config Class Initialized
DEBUG - 2011-09-17 09:32:56 --> Hooks Class Initialized
DEBUG - 2011-09-17 09:32:56 --> Utf8 Class Initialized
DEBUG - 2011-09-17 09:32:56 --> UTF-8 Support Enabled
DEBUG - 2011-09-17 09:32:56 --> URI Class Initialized
DEBUG - 2011-09-17 09:32:56 --> Router Class Initialized
DEBUG - 2011-09-17 09:32:56 --> Output Class Initialized
DEBUG - 2011-09-17 09:32:56 --> Input Class Initialized
DEBUG - 2011-09-17 09:32:56 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-17 09:32:56 --> Language Class Initialized
DEBUG - 2011-09-17 09:32:56 --> Loader Class Initialized
DEBUG - 2011-09-17 09:32:56 --> Controller Class Initialized
DEBUG - 2011-09-17 09:32:56 --> Model Class Initialized
DEBUG - 2011-09-17 09:32:56 --> Model Class Initialized
DEBUG - 2011-09-17 09:32:56 --> Model Class Initialized
DEBUG - 2011-09-17 09:32:56 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-17 09:32:56 --> Database Driver Class Initialized
DEBUG - 2011-09-17 09:32:56 --> File loaded: application/views/table/main.php
DEBUG - 2011-09-17 09:32:56 --> Helper loaded: url_helper
DEBUG - 2011-09-17 09:32:56 --> File loaded: application/views/common/header.php
DEBUG - 2011-09-17 09:32:56 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-09-17 09:32:56 --> File loaded: application/views/common/footer.php
DEBUG - 2011-09-17 09:32:56 --> File loaded: application/views/layout/main.php
DEBUG - 2011-09-17 09:32:56 --> Final output sent to browser
DEBUG - 2011-09-17 09:32:56 --> Total execution time: 0.2220
DEBUG - 2011-09-17 09:33:11 --> Config Class Initialized
DEBUG - 2011-09-17 09:33:11 --> Hooks Class Initialized
DEBUG - 2011-09-17 09:33:11 --> Utf8 Class Initialized
DEBUG - 2011-09-17 09:33:11 --> UTF-8 Support Enabled
DEBUG - 2011-09-17 09:33:11 --> URI Class Initialized
DEBUG - 2011-09-17 09:33:11 --> Router Class Initialized
DEBUG - 2011-09-17 09:33:11 --> Output Class Initialized
DEBUG - 2011-09-17 09:33:11 --> Input Class Initialized
DEBUG - 2011-09-17 09:33:11 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-17 09:33:11 --> Language Class Initialized
DEBUG - 2011-09-17 09:33:11 --> Loader Class Initialized
DEBUG - 2011-09-17 09:33:11 --> Controller Class Initialized
DEBUG - 2011-09-17 09:33:11 --> Model Class Initialized
DEBUG - 2011-09-17 09:33:11 --> Model Class Initialized
DEBUG - 2011-09-17 09:33:11 --> Model Class Initialized
DEBUG - 2011-09-17 09:33:11 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-17 09:33:11 --> Database Driver Class Initialized
DEBUG - 2011-09-17 09:33:11 --> File loaded: application/views/table/main.php
DEBUG - 2011-09-17 09:33:11 --> Helper loaded: url_helper
DEBUG - 2011-09-17 09:33:11 --> File loaded: application/views/common/header.php
DEBUG - 2011-09-17 09:33:11 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-09-17 09:33:11 --> File loaded: application/views/common/footer.php
DEBUG - 2011-09-17 09:33:11 --> File loaded: application/views/layout/main.php
DEBUG - 2011-09-17 09:33:11 --> Final output sent to browser
DEBUG - 2011-09-17 09:33:11 --> Total execution time: 0.0454
DEBUG - 2011-09-17 09:33:27 --> Config Class Initialized
DEBUG - 2011-09-17 09:33:27 --> Hooks Class Initialized
DEBUG - 2011-09-17 09:33:27 --> Utf8 Class Initialized
DEBUG - 2011-09-17 09:33:27 --> UTF-8 Support Enabled
DEBUG - 2011-09-17 09:33:27 --> URI Class Initialized
DEBUG - 2011-09-17 09:33:27 --> Router Class Initialized
DEBUG - 2011-09-17 09:33:27 --> Output Class Initialized
DEBUG - 2011-09-17 09:33:27 --> Input Class Initialized
DEBUG - 2011-09-17 09:33:27 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-17 09:33:27 --> Language Class Initialized
DEBUG - 2011-09-17 09:33:27 --> Loader Class Initialized
DEBUG - 2011-09-17 09:33:27 --> Controller Class Initialized
DEBUG - 2011-09-17 09:33:27 --> Model Class Initialized
DEBUG - 2011-09-17 09:33:27 --> Model Class Initialized
DEBUG - 2011-09-17 09:33:27 --> Model Class Initialized
DEBUG - 2011-09-17 09:33:27 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-17 09:33:27 --> Database Driver Class Initialized
DEBUG - 2011-09-17 09:33:27 --> Config Class Initialized
DEBUG - 2011-09-17 09:33:27 --> Hooks Class Initialized
DEBUG - 2011-09-17 09:33:27 --> Utf8 Class Initialized
DEBUG - 2011-09-17 09:33:27 --> UTF-8 Support Enabled
DEBUG - 2011-09-17 09:33:27 --> URI Class Initialized
DEBUG - 2011-09-17 09:33:27 --> Router Class Initialized
DEBUG - 2011-09-17 09:33:27 --> Output Class Initialized
DEBUG - 2011-09-17 09:33:27 --> Input Class Initialized
DEBUG - 2011-09-17 09:33:27 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-17 09:33:27 --> Language Class Initialized
DEBUG - 2011-09-17 09:33:27 --> Loader Class Initialized
DEBUG - 2011-09-17 09:33:27 --> Controller Class Initialized
ERROR - 2011-09-17 09:33:27 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-09-17 09:33:27 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-09-17 09:33:27 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-09-17 09:33:27 --> Model Class Initialized
DEBUG - 2011-09-17 09:33:27 --> Model Class Initialized
DEBUG - 2011-09-17 09:33:27 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-17 09:33:27 --> Database Driver Class Initialized
DEBUG - 2011-09-17 09:33:27 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-09-17 09:33:27 --> Helper loaded: url_helper
DEBUG - 2011-09-17 09:33:27 --> File loaded: application/views/common/header.php
DEBUG - 2011-09-17 09:33:27 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-09-17 09:33:27 --> File loaded: application/views/common/footer.php
DEBUG - 2011-09-17 09:33:27 --> File loaded: application/views/layout/main.php
DEBUG - 2011-09-17 09:33:27 --> Final output sent to browser
DEBUG - 2011-09-17 09:33:27 --> Total execution time: 0.0486
DEBUG - 2011-09-17 09:33:28 --> File loaded: application/views/table/main.php
DEBUG - 2011-09-17 09:33:28 --> Helper loaded: url_helper
DEBUG - 2011-09-17 09:33:28 --> File loaded: application/views/common/header.php
DEBUG - 2011-09-17 09:33:28 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-09-17 09:33:28 --> File loaded: application/views/common/footer.php
DEBUG - 2011-09-17 09:33:28 --> File loaded: application/views/layout/main.php
DEBUG - 2011-09-17 09:33:28 --> Final output sent to browser
DEBUG - 2011-09-17 09:33:28 --> Total execution time: 0.8482
DEBUG - 2011-09-17 09:33:28 --> Config Class Initialized
DEBUG - 2011-09-17 09:33:28 --> Hooks Class Initialized
DEBUG - 2011-09-17 09:33:28 --> Utf8 Class Initialized
DEBUG - 2011-09-17 09:33:28 --> UTF-8 Support Enabled
DEBUG - 2011-09-17 09:33:28 --> URI Class Initialized
DEBUG - 2011-09-17 09:33:28 --> Router Class Initialized
DEBUG - 2011-09-17 09:33:28 --> Output Class Initialized
DEBUG - 2011-09-17 09:33:28 --> Input Class Initialized
DEBUG - 2011-09-17 09:33:28 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-17 09:33:28 --> Language Class Initialized
DEBUG - 2011-09-17 09:33:28 --> Loader Class Initialized
DEBUG - 2011-09-17 09:33:28 --> Controller Class Initialized
DEBUG - 2011-09-17 09:33:28 --> Model Class Initialized
DEBUG - 2011-09-17 09:33:28 --> Model Class Initialized
DEBUG - 2011-09-17 09:33:28 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-17 09:33:28 --> Database Driver Class Initialized
DEBUG - 2011-09-17 09:33:30 --> Final output sent to browser
DEBUG - 2011-09-17 09:33:30 --> Total execution time: 1.6977
DEBUG - 2011-09-17 09:33:31 --> Config Class Initialized
DEBUG - 2011-09-17 09:33:31 --> Hooks Class Initialized
DEBUG - 2011-09-17 09:33:31 --> Utf8 Class Initialized
DEBUG - 2011-09-17 09:33:31 --> UTF-8 Support Enabled
DEBUG - 2011-09-17 09:33:31 --> URI Class Initialized
DEBUG - 2011-09-17 09:33:31 --> Router Class Initialized
ERROR - 2011-09-17 09:33:31 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-09-17 09:33:44 --> Config Class Initialized
DEBUG - 2011-09-17 09:33:44 --> Hooks Class Initialized
DEBUG - 2011-09-17 09:33:44 --> Utf8 Class Initialized
DEBUG - 2011-09-17 09:33:44 --> UTF-8 Support Enabled
DEBUG - 2011-09-17 09:33:44 --> URI Class Initialized
DEBUG - 2011-09-17 09:33:44 --> Router Class Initialized
DEBUG - 2011-09-17 09:33:44 --> Output Class Initialized
DEBUG - 2011-09-17 09:33:44 --> Input Class Initialized
DEBUG - 2011-09-17 09:33:44 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-17 09:33:44 --> Language Class Initialized
DEBUG - 2011-09-17 09:33:44 --> Loader Class Initialized
DEBUG - 2011-09-17 09:33:44 --> Controller Class Initialized
DEBUG - 2011-09-17 09:33:44 --> Model Class Initialized
DEBUG - 2011-09-17 09:33:44 --> Model Class Initialized
DEBUG - 2011-09-17 09:33:44 --> Model Class Initialized
DEBUG - 2011-09-17 09:33:44 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-17 09:33:44 --> Database Driver Class Initialized
DEBUG - 2011-09-17 09:33:44 --> File loaded: application/views/table/main.php
DEBUG - 2011-09-17 09:33:44 --> Helper loaded: url_helper
DEBUG - 2011-09-17 09:33:44 --> File loaded: application/views/common/header.php
DEBUG - 2011-09-17 09:33:44 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-09-17 09:33:44 --> File loaded: application/views/common/footer.php
DEBUG - 2011-09-17 09:33:44 --> File loaded: application/views/layout/main.php
DEBUG - 2011-09-17 09:33:44 --> Final output sent to browser
DEBUG - 2011-09-17 09:33:44 --> Total execution time: 0.2879
DEBUG - 2011-09-17 09:33:58 --> Config Class Initialized
DEBUG - 2011-09-17 09:33:58 --> Hooks Class Initialized
DEBUG - 2011-09-17 09:33:58 --> Utf8 Class Initialized
DEBUG - 2011-09-17 09:33:58 --> UTF-8 Support Enabled
DEBUG - 2011-09-17 09:33:58 --> URI Class Initialized
DEBUG - 2011-09-17 09:33:58 --> Router Class Initialized
DEBUG - 2011-09-17 09:33:58 --> Output Class Initialized
DEBUG - 2011-09-17 09:33:58 --> Input Class Initialized
DEBUG - 2011-09-17 09:33:58 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-17 09:33:58 --> Language Class Initialized
DEBUG - 2011-09-17 09:33:58 --> Loader Class Initialized
DEBUG - 2011-09-17 09:33:58 --> Controller Class Initialized
DEBUG - 2011-09-17 09:33:58 --> Model Class Initialized
DEBUG - 2011-09-17 09:33:58 --> Model Class Initialized
DEBUG - 2011-09-17 09:33:58 --> Model Class Initialized
DEBUG - 2011-09-17 09:33:58 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-17 09:33:58 --> Database Driver Class Initialized
DEBUG - 2011-09-17 09:33:58 --> File loaded: application/views/table/main.php
DEBUG - 2011-09-17 09:33:58 --> Helper loaded: url_helper
DEBUG - 2011-09-17 09:33:58 --> File loaded: application/views/common/header.php
DEBUG - 2011-09-17 09:33:58 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-09-17 09:33:58 --> File loaded: application/views/common/footer.php
DEBUG - 2011-09-17 09:33:58 --> File loaded: application/views/layout/main.php
DEBUG - 2011-09-17 09:33:58 --> Final output sent to browser
DEBUG - 2011-09-17 09:33:58 --> Total execution time: 0.0525
DEBUG - 2011-09-17 09:34:00 --> Config Class Initialized
DEBUG - 2011-09-17 09:34:00 --> Hooks Class Initialized
DEBUG - 2011-09-17 09:34:00 --> Utf8 Class Initialized
DEBUG - 2011-09-17 09:34:00 --> UTF-8 Support Enabled
DEBUG - 2011-09-17 09:34:00 --> URI Class Initialized
DEBUG - 2011-09-17 09:34:00 --> Router Class Initialized
DEBUG - 2011-09-17 09:34:00 --> Output Class Initialized
DEBUG - 2011-09-17 09:34:00 --> Input Class Initialized
DEBUG - 2011-09-17 09:34:00 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-17 09:34:00 --> Language Class Initialized
DEBUG - 2011-09-17 09:34:00 --> Loader Class Initialized
DEBUG - 2011-09-17 09:34:00 --> Controller Class Initialized
ERROR - 2011-09-17 09:34:00 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-09-17 09:34:00 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-09-17 09:34:00 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-09-17 09:34:00 --> Model Class Initialized
DEBUG - 2011-09-17 09:34:00 --> Model Class Initialized
DEBUG - 2011-09-17 09:34:00 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-17 09:34:00 --> Database Driver Class Initialized
DEBUG - 2011-09-17 09:34:00 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-09-17 09:34:00 --> Helper loaded: url_helper
DEBUG - 2011-09-17 09:34:00 --> File loaded: application/views/common/header.php
DEBUG - 2011-09-17 09:34:00 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-09-17 09:34:00 --> File loaded: application/views/common/footer.php
DEBUG - 2011-09-17 09:34:00 --> File loaded: application/views/layout/main.php
DEBUG - 2011-09-17 09:34:00 --> Final output sent to browser
DEBUG - 2011-09-17 09:34:00 --> Total execution time: 0.0298
DEBUG - 2011-09-17 09:34:00 --> Config Class Initialized
DEBUG - 2011-09-17 09:34:00 --> Hooks Class Initialized
DEBUG - 2011-09-17 09:34:00 --> Utf8 Class Initialized
DEBUG - 2011-09-17 09:34:00 --> UTF-8 Support Enabled
DEBUG - 2011-09-17 09:34:00 --> URI Class Initialized
DEBUG - 2011-09-17 09:34:00 --> Router Class Initialized
DEBUG - 2011-09-17 09:34:00 --> Output Class Initialized
DEBUG - 2011-09-17 09:34:00 --> Input Class Initialized
DEBUG - 2011-09-17 09:34:00 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-17 09:34:00 --> Language Class Initialized
DEBUG - 2011-09-17 09:34:00 --> Loader Class Initialized
DEBUG - 2011-09-17 09:34:00 --> Controller Class Initialized
DEBUG - 2011-09-17 09:34:00 --> Model Class Initialized
DEBUG - 2011-09-17 09:34:00 --> Model Class Initialized
DEBUG - 2011-09-17 09:34:00 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-17 09:34:00 --> Database Driver Class Initialized
DEBUG - 2011-09-17 09:34:01 --> Final output sent to browser
DEBUG - 2011-09-17 09:34:01 --> Total execution time: 0.6334
DEBUG - 2011-09-17 09:34:02 --> Config Class Initialized
DEBUG - 2011-09-17 09:34:02 --> Hooks Class Initialized
DEBUG - 2011-09-17 09:34:02 --> Utf8 Class Initialized
DEBUG - 2011-09-17 09:34:02 --> UTF-8 Support Enabled
DEBUG - 2011-09-17 09:34:02 --> URI Class Initialized
DEBUG - 2011-09-17 09:34:02 --> Router Class Initialized
ERROR - 2011-09-17 09:34:02 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-09-17 09:34:29 --> Config Class Initialized
DEBUG - 2011-09-17 09:34:29 --> Hooks Class Initialized
DEBUG - 2011-09-17 09:34:29 --> Utf8 Class Initialized
DEBUG - 2011-09-17 09:34:29 --> UTF-8 Support Enabled
DEBUG - 2011-09-17 09:34:29 --> URI Class Initialized
DEBUG - 2011-09-17 09:34:29 --> Router Class Initialized
DEBUG - 2011-09-17 09:34:29 --> Output Class Initialized
DEBUG - 2011-09-17 09:34:29 --> Input Class Initialized
DEBUG - 2011-09-17 09:34:29 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-17 09:34:29 --> Language Class Initialized
DEBUG - 2011-09-17 09:34:29 --> Loader Class Initialized
DEBUG - 2011-09-17 09:34:29 --> Controller Class Initialized
ERROR - 2011-09-17 09:34:29 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-09-17 09:34:29 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-09-17 09:34:29 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-09-17 09:34:29 --> Model Class Initialized
DEBUG - 2011-09-17 09:34:29 --> Model Class Initialized
DEBUG - 2011-09-17 09:34:29 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-17 09:34:29 --> Database Driver Class Initialized
DEBUG - 2011-09-17 09:34:29 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-09-17 09:34:29 --> Helper loaded: url_helper
DEBUG - 2011-09-17 09:34:29 --> File loaded: application/views/common/header.php
DEBUG - 2011-09-17 09:34:29 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-09-17 09:34:29 --> File loaded: application/views/common/footer.php
DEBUG - 2011-09-17 09:34:29 --> File loaded: application/views/layout/main.php
DEBUG - 2011-09-17 09:34:29 --> Final output sent to browser
DEBUG - 2011-09-17 09:34:29 --> Total execution time: 0.0349
DEBUG - 2011-09-17 09:34:29 --> Config Class Initialized
DEBUG - 2011-09-17 09:34:29 --> Hooks Class Initialized
DEBUG - 2011-09-17 09:34:29 --> Utf8 Class Initialized
DEBUG - 2011-09-17 09:34:29 --> UTF-8 Support Enabled
DEBUG - 2011-09-17 09:34:29 --> URI Class Initialized
DEBUG - 2011-09-17 09:34:29 --> Router Class Initialized
DEBUG - 2011-09-17 09:34:29 --> Output Class Initialized
DEBUG - 2011-09-17 09:34:29 --> Input Class Initialized
DEBUG - 2011-09-17 09:34:29 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-17 09:34:29 --> Language Class Initialized
DEBUG - 2011-09-17 09:34:29 --> Loader Class Initialized
DEBUG - 2011-09-17 09:34:29 --> Controller Class Initialized
DEBUG - 2011-09-17 09:34:29 --> Model Class Initialized
DEBUG - 2011-09-17 09:34:29 --> Model Class Initialized
DEBUG - 2011-09-17 09:34:29 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-17 09:34:29 --> Database Driver Class Initialized
DEBUG - 2011-09-17 09:34:30 --> Final output sent to browser
DEBUG - 2011-09-17 09:34:30 --> Total execution time: 0.4509
DEBUG - 2011-09-17 09:34:31 --> Config Class Initialized
DEBUG - 2011-09-17 09:34:31 --> Hooks Class Initialized
DEBUG - 2011-09-17 09:34:31 --> Utf8 Class Initialized
DEBUG - 2011-09-17 09:34:31 --> UTF-8 Support Enabled
DEBUG - 2011-09-17 09:34:31 --> URI Class Initialized
DEBUG - 2011-09-17 09:34:31 --> Router Class Initialized
ERROR - 2011-09-17 09:34:31 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-09-17 09:34:39 --> Config Class Initialized
DEBUG - 2011-09-17 09:34:39 --> Hooks Class Initialized
DEBUG - 2011-09-17 09:34:39 --> Utf8 Class Initialized
DEBUG - 2011-09-17 09:34:39 --> UTF-8 Support Enabled
DEBUG - 2011-09-17 09:34:39 --> URI Class Initialized
DEBUG - 2011-09-17 09:34:39 --> Router Class Initialized
DEBUG - 2011-09-17 09:34:39 --> Output Class Initialized
DEBUG - 2011-09-17 09:34:39 --> Input Class Initialized
DEBUG - 2011-09-17 09:34:39 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-17 09:34:39 --> Language Class Initialized
DEBUG - 2011-09-17 09:34:39 --> Loader Class Initialized
DEBUG - 2011-09-17 09:34:39 --> Controller Class Initialized
ERROR - 2011-09-17 09:34:39 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-09-17 09:34:39 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-09-17 09:34:39 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-09-17 09:34:39 --> Model Class Initialized
DEBUG - 2011-09-17 09:34:39 --> Model Class Initialized
DEBUG - 2011-09-17 09:34:39 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-17 09:34:39 --> Database Driver Class Initialized
DEBUG - 2011-09-17 09:34:39 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-09-17 09:34:39 --> Helper loaded: url_helper
DEBUG - 2011-09-17 09:34:39 --> File loaded: application/views/common/header.php
DEBUG - 2011-09-17 09:34:39 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-09-17 09:34:39 --> File loaded: application/views/common/footer.php
DEBUG - 2011-09-17 09:34:39 --> File loaded: application/views/layout/main.php
DEBUG - 2011-09-17 09:34:39 --> Final output sent to browser
DEBUG - 2011-09-17 09:34:39 --> Total execution time: 0.0306
DEBUG - 2011-09-17 09:34:39 --> Config Class Initialized
DEBUG - 2011-09-17 09:34:39 --> Hooks Class Initialized
DEBUG - 2011-09-17 09:34:39 --> Utf8 Class Initialized
DEBUG - 2011-09-17 09:34:39 --> UTF-8 Support Enabled
DEBUG - 2011-09-17 09:34:39 --> URI Class Initialized
DEBUG - 2011-09-17 09:34:39 --> Router Class Initialized
DEBUG - 2011-09-17 09:34:39 --> Output Class Initialized
DEBUG - 2011-09-17 09:34:39 --> Input Class Initialized
DEBUG - 2011-09-17 09:34:39 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-17 09:34:39 --> Language Class Initialized
DEBUG - 2011-09-17 09:34:39 --> Loader Class Initialized
DEBUG - 2011-09-17 09:34:39 --> Controller Class Initialized
DEBUG - 2011-09-17 09:34:39 --> Model Class Initialized
DEBUG - 2011-09-17 09:34:39 --> Model Class Initialized
DEBUG - 2011-09-17 09:34:39 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-17 09:34:39 --> Database Driver Class Initialized
DEBUG - 2011-09-17 09:34:40 --> Final output sent to browser
DEBUG - 2011-09-17 09:34:40 --> Total execution time: 0.5518
DEBUG - 2011-09-17 09:34:41 --> Config Class Initialized
DEBUG - 2011-09-17 09:34:41 --> Hooks Class Initialized
DEBUG - 2011-09-17 09:34:41 --> Utf8 Class Initialized
DEBUG - 2011-09-17 09:34:41 --> UTF-8 Support Enabled
DEBUG - 2011-09-17 09:34:41 --> URI Class Initialized
DEBUG - 2011-09-17 09:34:41 --> Router Class Initialized
ERROR - 2011-09-17 09:34:41 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-09-17 09:34:44 --> Config Class Initialized
DEBUG - 2011-09-17 09:34:44 --> Hooks Class Initialized
DEBUG - 2011-09-17 09:34:44 --> Utf8 Class Initialized
DEBUG - 2011-09-17 09:34:44 --> UTF-8 Support Enabled
DEBUG - 2011-09-17 09:34:44 --> URI Class Initialized
DEBUG - 2011-09-17 09:34:44 --> Router Class Initialized
DEBUG - 2011-09-17 09:34:44 --> Output Class Initialized
DEBUG - 2011-09-17 09:34:44 --> Input Class Initialized
DEBUG - 2011-09-17 09:34:44 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-17 09:34:44 --> Language Class Initialized
DEBUG - 2011-09-17 09:34:44 --> Loader Class Initialized
DEBUG - 2011-09-17 09:34:44 --> Controller Class Initialized
ERROR - 2011-09-17 09:34:44 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-09-17 09:34:44 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-09-17 09:34:44 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-09-17 09:34:44 --> Model Class Initialized
DEBUG - 2011-09-17 09:34:44 --> Model Class Initialized
DEBUG - 2011-09-17 09:34:44 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-17 09:34:44 --> Database Driver Class Initialized
DEBUG - 2011-09-17 09:34:44 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-09-17 09:34:44 --> Helper loaded: url_helper
DEBUG - 2011-09-17 09:34:44 --> File loaded: application/views/common/header.php
DEBUG - 2011-09-17 09:34:44 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-09-17 09:34:44 --> File loaded: application/views/common/footer.php
DEBUG - 2011-09-17 09:34:44 --> File loaded: application/views/layout/main.php
DEBUG - 2011-09-17 09:34:44 --> Final output sent to browser
DEBUG - 2011-09-17 09:34:44 --> Total execution time: 0.0343
DEBUG - 2011-09-17 09:34:46 --> Config Class Initialized
DEBUG - 2011-09-17 09:34:46 --> Hooks Class Initialized
DEBUG - 2011-09-17 09:34:46 --> Utf8 Class Initialized
DEBUG - 2011-09-17 09:34:46 --> UTF-8 Support Enabled
DEBUG - 2011-09-17 09:34:46 --> URI Class Initialized
DEBUG - 2011-09-17 09:34:46 --> Router Class Initialized
DEBUG - 2011-09-17 09:34:46 --> Output Class Initialized
DEBUG - 2011-09-17 09:34:46 --> Input Class Initialized
DEBUG - 2011-09-17 09:34:46 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-17 09:34:46 --> Language Class Initialized
DEBUG - 2011-09-17 09:34:46 --> Loader Class Initialized
DEBUG - 2011-09-17 09:34:46 --> Controller Class Initialized
DEBUG - 2011-09-17 09:34:46 --> Model Class Initialized
DEBUG - 2011-09-17 09:34:46 --> Model Class Initialized
DEBUG - 2011-09-17 09:34:46 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-17 09:34:46 --> Database Driver Class Initialized
DEBUG - 2011-09-17 09:34:46 --> Final output sent to browser
DEBUG - 2011-09-17 09:34:46 --> Total execution time: 0.5390
DEBUG - 2011-09-17 09:34:48 --> Config Class Initialized
DEBUG - 2011-09-17 09:34:48 --> Hooks Class Initialized
DEBUG - 2011-09-17 09:34:48 --> Utf8 Class Initialized
DEBUG - 2011-09-17 09:34:48 --> UTF-8 Support Enabled
DEBUG - 2011-09-17 09:34:48 --> URI Class Initialized
DEBUG - 2011-09-17 09:34:48 --> Router Class Initialized
DEBUG - 2011-09-17 09:34:48 --> Output Class Initialized
DEBUG - 2011-09-17 09:34:48 --> Input Class Initialized
DEBUG - 2011-09-17 09:34:48 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-17 09:34:48 --> Language Class Initialized
DEBUG - 2011-09-17 09:34:48 --> Loader Class Initialized
DEBUG - 2011-09-17 09:34:48 --> Controller Class Initialized
ERROR - 2011-09-17 09:34:48 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-09-17 09:34:48 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-09-17 09:34:48 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-09-17 09:34:48 --> Model Class Initialized
DEBUG - 2011-09-17 09:34:48 --> Model Class Initialized
DEBUG - 2011-09-17 09:34:48 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-17 09:34:48 --> Database Driver Class Initialized
DEBUG - 2011-09-17 09:34:48 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-09-17 09:34:48 --> Helper loaded: url_helper
DEBUG - 2011-09-17 09:34:48 --> File loaded: application/views/common/header.php
DEBUG - 2011-09-17 09:34:48 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-09-17 09:34:48 --> File loaded: application/views/common/footer.php
DEBUG - 2011-09-17 09:34:48 --> File loaded: application/views/layout/main.php
DEBUG - 2011-09-17 09:34:48 --> Final output sent to browser
DEBUG - 2011-09-17 09:34:48 --> Total execution time: 0.1165
DEBUG - 2011-09-17 09:34:48 --> Config Class Initialized
DEBUG - 2011-09-17 09:34:48 --> Hooks Class Initialized
DEBUG - 2011-09-17 09:34:48 --> Utf8 Class Initialized
DEBUG - 2011-09-17 09:34:48 --> UTF-8 Support Enabled
DEBUG - 2011-09-17 09:34:48 --> URI Class Initialized
DEBUG - 2011-09-17 09:34:48 --> Router Class Initialized
ERROR - 2011-09-17 09:34:48 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-09-17 09:34:49 --> Config Class Initialized
DEBUG - 2011-09-17 09:34:49 --> Hooks Class Initialized
DEBUG - 2011-09-17 09:34:49 --> Utf8 Class Initialized
DEBUG - 2011-09-17 09:34:49 --> UTF-8 Support Enabled
DEBUG - 2011-09-17 09:34:49 --> URI Class Initialized
DEBUG - 2011-09-17 09:34:49 --> Router Class Initialized
ERROR - 2011-09-17 09:34:49 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-09-17 09:34:49 --> Config Class Initialized
DEBUG - 2011-09-17 09:34:49 --> Hooks Class Initialized
DEBUG - 2011-09-17 09:34:49 --> Utf8 Class Initialized
DEBUG - 2011-09-17 09:34:49 --> UTF-8 Support Enabled
DEBUG - 2011-09-17 09:34:49 --> URI Class Initialized
DEBUG - 2011-09-17 09:34:49 --> Router Class Initialized
DEBUG - 2011-09-17 09:34:49 --> Output Class Initialized
DEBUG - 2011-09-17 09:34:49 --> Input Class Initialized
DEBUG - 2011-09-17 09:34:49 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-17 09:34:49 --> Language Class Initialized
DEBUG - 2011-09-17 09:34:49 --> Loader Class Initialized
DEBUG - 2011-09-17 09:34:49 --> Controller Class Initialized
DEBUG - 2011-09-17 09:34:49 --> Model Class Initialized
DEBUG - 2011-09-17 09:34:49 --> Model Class Initialized
DEBUG - 2011-09-17 09:34:49 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-17 09:34:49 --> Database Driver Class Initialized
DEBUG - 2011-09-17 09:34:49 --> Config Class Initialized
DEBUG - 2011-09-17 09:34:49 --> Hooks Class Initialized
DEBUG - 2011-09-17 09:34:49 --> Utf8 Class Initialized
DEBUG - 2011-09-17 09:34:49 --> UTF-8 Support Enabled
DEBUG - 2011-09-17 09:34:49 --> URI Class Initialized
DEBUG - 2011-09-17 09:34:49 --> Router Class Initialized
ERROR - 2011-09-17 09:34:49 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-09-17 09:34:49 --> Final output sent to browser
DEBUG - 2011-09-17 09:34:49 --> Total execution time: 0.8356
DEBUG - 2011-09-17 09:34:50 --> Config Class Initialized
DEBUG - 2011-09-17 09:34:50 --> Hooks Class Initialized
DEBUG - 2011-09-17 09:34:50 --> Utf8 Class Initialized
DEBUG - 2011-09-17 09:34:50 --> UTF-8 Support Enabled
DEBUG - 2011-09-17 09:34:50 --> URI Class Initialized
DEBUG - 2011-09-17 09:34:50 --> Router Class Initialized
ERROR - 2011-09-17 09:34:50 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-09-17 09:34:54 --> Config Class Initialized
DEBUG - 2011-09-17 09:34:54 --> Hooks Class Initialized
DEBUG - 2011-09-17 09:34:54 --> Utf8 Class Initialized
DEBUG - 2011-09-17 09:34:54 --> UTF-8 Support Enabled
DEBUG - 2011-09-17 09:34:54 --> URI Class Initialized
DEBUG - 2011-09-17 09:34:54 --> Router Class Initialized
DEBUG - 2011-09-17 09:34:54 --> Output Class Initialized
DEBUG - 2011-09-17 09:34:54 --> Input Class Initialized
DEBUG - 2011-09-17 09:34:54 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-17 09:34:54 --> Language Class Initialized
DEBUG - 2011-09-17 09:34:54 --> Loader Class Initialized
DEBUG - 2011-09-17 09:34:54 --> Controller Class Initialized
ERROR - 2011-09-17 09:34:54 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-09-17 09:34:54 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-09-17 09:34:54 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-09-17 09:34:54 --> Model Class Initialized
DEBUG - 2011-09-17 09:34:54 --> Model Class Initialized
DEBUG - 2011-09-17 09:34:54 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-17 09:34:54 --> Database Driver Class Initialized
DEBUG - 2011-09-17 09:34:54 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-09-17 09:34:54 --> Helper loaded: url_helper
DEBUG - 2011-09-17 09:34:54 --> File loaded: application/views/common/header.php
DEBUG - 2011-09-17 09:34:54 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-09-17 09:34:54 --> File loaded: application/views/common/footer.php
DEBUG - 2011-09-17 09:34:54 --> File loaded: application/views/layout/main.php
DEBUG - 2011-09-17 09:34:54 --> Final output sent to browser
DEBUG - 2011-09-17 09:34:54 --> Total execution time: 0.0937
DEBUG - 2011-09-17 09:34:54 --> Config Class Initialized
DEBUG - 2011-09-17 09:34:54 --> Hooks Class Initialized
DEBUG - 2011-09-17 09:34:54 --> Utf8 Class Initialized
DEBUG - 2011-09-17 09:34:54 --> UTF-8 Support Enabled
DEBUG - 2011-09-17 09:34:54 --> URI Class Initialized
DEBUG - 2011-09-17 09:34:54 --> Router Class Initialized
DEBUG - 2011-09-17 09:34:54 --> Output Class Initialized
DEBUG - 2011-09-17 09:34:54 --> Input Class Initialized
DEBUG - 2011-09-17 09:34:54 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-17 09:34:54 --> Language Class Initialized
DEBUG - 2011-09-17 09:34:54 --> Loader Class Initialized
DEBUG - 2011-09-17 09:34:54 --> Controller Class Initialized
DEBUG - 2011-09-17 09:34:54 --> Model Class Initialized
DEBUG - 2011-09-17 09:34:54 --> Model Class Initialized
DEBUG - 2011-09-17 09:34:54 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-17 09:34:54 --> Database Driver Class Initialized
DEBUG - 2011-09-17 09:34:55 --> Final output sent to browser
DEBUG - 2011-09-17 09:34:55 --> Total execution time: 0.6419
DEBUG - 2011-09-17 09:34:56 --> Config Class Initialized
DEBUG - 2011-09-17 09:34:56 --> Hooks Class Initialized
DEBUG - 2011-09-17 09:34:56 --> Utf8 Class Initialized
DEBUG - 2011-09-17 09:34:56 --> UTF-8 Support Enabled
DEBUG - 2011-09-17 09:34:56 --> URI Class Initialized
DEBUG - 2011-09-17 09:34:56 --> Router Class Initialized
ERROR - 2011-09-17 09:34:56 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-09-17 09:34:58 --> Config Class Initialized
DEBUG - 2011-09-17 09:34:58 --> Hooks Class Initialized
DEBUG - 2011-09-17 09:34:58 --> Utf8 Class Initialized
DEBUG - 2011-09-17 09:34:58 --> UTF-8 Support Enabled
DEBUG - 2011-09-17 09:34:58 --> URI Class Initialized
DEBUG - 2011-09-17 09:34:58 --> Router Class Initialized
DEBUG - 2011-09-17 09:34:58 --> Output Class Initialized
DEBUG - 2011-09-17 09:34:58 --> Input Class Initialized
DEBUG - 2011-09-17 09:34:58 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-17 09:34:58 --> Language Class Initialized
DEBUG - 2011-09-17 09:34:58 --> Loader Class Initialized
DEBUG - 2011-09-17 09:34:58 --> Controller Class Initialized
ERROR - 2011-09-17 09:34:58 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-09-17 09:34:58 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-09-17 09:34:58 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-09-17 09:34:58 --> Model Class Initialized
DEBUG - 2011-09-17 09:34:58 --> Model Class Initialized
DEBUG - 2011-09-17 09:34:58 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-17 09:34:58 --> Database Driver Class Initialized
DEBUG - 2011-09-17 09:34:58 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-09-17 09:34:58 --> Helper loaded: url_helper
DEBUG - 2011-09-17 09:34:58 --> File loaded: application/views/common/header.php
DEBUG - 2011-09-17 09:34:58 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-09-17 09:34:58 --> File loaded: application/views/common/footer.php
DEBUG - 2011-09-17 09:34:58 --> File loaded: application/views/layout/main.php
DEBUG - 2011-09-17 09:34:58 --> Final output sent to browser
DEBUG - 2011-09-17 09:34:58 --> Total execution time: 0.0294
DEBUG - 2011-09-17 09:34:58 --> Config Class Initialized
DEBUG - 2011-09-17 09:34:58 --> Hooks Class Initialized
DEBUG - 2011-09-17 09:34:58 --> Utf8 Class Initialized
DEBUG - 2011-09-17 09:34:58 --> UTF-8 Support Enabled
DEBUG - 2011-09-17 09:34:58 --> URI Class Initialized
DEBUG - 2011-09-17 09:34:58 --> Router Class Initialized
DEBUG - 2011-09-17 09:34:58 --> Output Class Initialized
DEBUG - 2011-09-17 09:34:58 --> Input Class Initialized
DEBUG - 2011-09-17 09:34:58 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-17 09:34:58 --> Language Class Initialized
DEBUG - 2011-09-17 09:34:58 --> Loader Class Initialized
DEBUG - 2011-09-17 09:34:58 --> Controller Class Initialized
DEBUG - 2011-09-17 09:34:58 --> Model Class Initialized
DEBUG - 2011-09-17 09:34:58 --> Model Class Initialized
DEBUG - 2011-09-17 09:34:58 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-17 09:34:58 --> Database Driver Class Initialized
DEBUG - 2011-09-17 09:34:59 --> Final output sent to browser
DEBUG - 2011-09-17 09:34:59 --> Total execution time: 0.7375
DEBUG - 2011-09-17 09:35:02 --> Config Class Initialized
DEBUG - 2011-09-17 09:35:02 --> Hooks Class Initialized
DEBUG - 2011-09-17 09:35:02 --> Utf8 Class Initialized
DEBUG - 2011-09-17 09:35:02 --> UTF-8 Support Enabled
DEBUG - 2011-09-17 09:35:02 --> URI Class Initialized
DEBUG - 2011-09-17 09:35:02 --> Router Class Initialized
DEBUG - 2011-09-17 09:35:02 --> Output Class Initialized
DEBUG - 2011-09-17 09:35:02 --> Input Class Initialized
DEBUG - 2011-09-17 09:35:02 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-17 09:35:02 --> Language Class Initialized
DEBUG - 2011-09-17 09:35:02 --> Loader Class Initialized
DEBUG - 2011-09-17 09:35:02 --> Controller Class Initialized
ERROR - 2011-09-17 09:35:02 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-09-17 09:35:02 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-09-17 09:35:02 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-09-17 09:35:02 --> Model Class Initialized
DEBUG - 2011-09-17 09:35:02 --> Model Class Initialized
DEBUG - 2011-09-17 09:35:02 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-17 09:35:02 --> Database Driver Class Initialized
DEBUG - 2011-09-17 09:35:02 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-09-17 09:35:02 --> Helper loaded: url_helper
DEBUG - 2011-09-17 09:35:02 --> File loaded: application/views/common/header.php
DEBUG - 2011-09-17 09:35:02 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-09-17 09:35:02 --> File loaded: application/views/common/footer.php
DEBUG - 2011-09-17 09:35:02 --> File loaded: application/views/layout/main.php
DEBUG - 2011-09-17 09:35:02 --> Final output sent to browser
DEBUG - 2011-09-17 09:35:02 --> Total execution time: 0.0462
DEBUG - 2011-09-17 09:35:02 --> Config Class Initialized
DEBUG - 2011-09-17 09:35:02 --> Hooks Class Initialized
DEBUG - 2011-09-17 09:35:02 --> Utf8 Class Initialized
DEBUG - 2011-09-17 09:35:02 --> UTF-8 Support Enabled
DEBUG - 2011-09-17 09:35:02 --> URI Class Initialized
DEBUG - 2011-09-17 09:35:02 --> Router Class Initialized
DEBUG - 2011-09-17 09:35:02 --> Output Class Initialized
DEBUG - 2011-09-17 09:35:02 --> Input Class Initialized
DEBUG - 2011-09-17 09:35:02 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-17 09:35:02 --> Language Class Initialized
DEBUG - 2011-09-17 09:35:02 --> Loader Class Initialized
DEBUG - 2011-09-17 09:35:02 --> Controller Class Initialized
DEBUG - 2011-09-17 09:35:02 --> Model Class Initialized
DEBUG - 2011-09-17 09:35:02 --> Model Class Initialized
DEBUG - 2011-09-17 09:35:02 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-17 09:35:02 --> Database Driver Class Initialized
DEBUG - 2011-09-17 09:35:03 --> Final output sent to browser
DEBUG - 2011-09-17 09:35:03 --> Total execution time: 0.5982
DEBUG - 2011-09-17 09:35:04 --> Config Class Initialized
DEBUG - 2011-09-17 09:35:04 --> Hooks Class Initialized
DEBUG - 2011-09-17 09:35:04 --> Utf8 Class Initialized
DEBUG - 2011-09-17 09:35:04 --> UTF-8 Support Enabled
DEBUG - 2011-09-17 09:35:04 --> URI Class Initialized
DEBUG - 2011-09-17 09:35:04 --> Router Class Initialized
ERROR - 2011-09-17 09:35:04 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-09-17 09:35:09 --> Config Class Initialized
DEBUG - 2011-09-17 09:35:09 --> Hooks Class Initialized
DEBUG - 2011-09-17 09:35:09 --> Utf8 Class Initialized
DEBUG - 2011-09-17 09:35:09 --> UTF-8 Support Enabled
DEBUG - 2011-09-17 09:35:09 --> URI Class Initialized
DEBUG - 2011-09-17 09:35:09 --> Router Class Initialized
DEBUG - 2011-09-17 09:35:09 --> Output Class Initialized
DEBUG - 2011-09-17 09:35:09 --> Input Class Initialized
DEBUG - 2011-09-17 09:35:09 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-17 09:35:09 --> Language Class Initialized
DEBUG - 2011-09-17 09:35:09 --> Loader Class Initialized
DEBUG - 2011-09-17 09:35:09 --> Controller Class Initialized
ERROR - 2011-09-17 09:35:09 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-09-17 09:35:09 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-09-17 09:35:09 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-09-17 09:35:09 --> Model Class Initialized
DEBUG - 2011-09-17 09:35:09 --> Model Class Initialized
DEBUG - 2011-09-17 09:35:09 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-17 09:35:09 --> Database Driver Class Initialized
DEBUG - 2011-09-17 09:35:09 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-09-17 09:35:09 --> Helper loaded: url_helper
DEBUG - 2011-09-17 09:35:09 --> File loaded: application/views/common/header.php
DEBUG - 2011-09-17 09:35:09 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-09-17 09:35:09 --> File loaded: application/views/common/footer.php
DEBUG - 2011-09-17 09:35:09 --> File loaded: application/views/layout/main.php
DEBUG - 2011-09-17 09:35:09 --> Final output sent to browser
DEBUG - 2011-09-17 09:35:09 --> Total execution time: 0.0523
DEBUG - 2011-09-17 09:35:10 --> Config Class Initialized
DEBUG - 2011-09-17 09:35:10 --> Hooks Class Initialized
DEBUG - 2011-09-17 09:35:10 --> Utf8 Class Initialized
DEBUG - 2011-09-17 09:35:10 --> UTF-8 Support Enabled
DEBUG - 2011-09-17 09:35:10 --> URI Class Initialized
DEBUG - 2011-09-17 09:35:10 --> Router Class Initialized
DEBUG - 2011-09-17 09:35:10 --> Output Class Initialized
DEBUG - 2011-09-17 09:35:10 --> Input Class Initialized
DEBUG - 2011-09-17 09:35:10 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-17 09:35:10 --> Language Class Initialized
DEBUG - 2011-09-17 09:35:10 --> Loader Class Initialized
DEBUG - 2011-09-17 09:35:10 --> Controller Class Initialized
DEBUG - 2011-09-17 09:35:10 --> Model Class Initialized
DEBUG - 2011-09-17 09:35:10 --> Model Class Initialized
DEBUG - 2011-09-17 09:35:10 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-17 09:35:10 --> Database Driver Class Initialized
DEBUG - 2011-09-17 09:35:11 --> Final output sent to browser
DEBUG - 2011-09-17 09:35:11 --> Total execution time: 0.6706
DEBUG - 2011-09-17 09:35:12 --> Config Class Initialized
DEBUG - 2011-09-17 09:35:12 --> Hooks Class Initialized
DEBUG - 2011-09-17 09:35:12 --> Utf8 Class Initialized
DEBUG - 2011-09-17 09:35:12 --> UTF-8 Support Enabled
DEBUG - 2011-09-17 09:35:12 --> URI Class Initialized
DEBUG - 2011-09-17 09:35:12 --> Router Class Initialized
DEBUG - 2011-09-17 09:35:12 --> Output Class Initialized
DEBUG - 2011-09-17 09:35:12 --> Input Class Initialized
DEBUG - 2011-09-17 09:35:12 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-17 09:35:12 --> Language Class Initialized
DEBUG - 2011-09-17 09:35:12 --> Loader Class Initialized
DEBUG - 2011-09-17 09:35:12 --> Controller Class Initialized
DEBUG - 2011-09-17 09:35:12 --> Model Class Initialized
DEBUG - 2011-09-17 09:35:12 --> Model Class Initialized
DEBUG - 2011-09-17 09:35:12 --> Model Class Initialized
DEBUG - 2011-09-17 09:35:12 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-17 09:35:12 --> Database Driver Class Initialized
DEBUG - 2011-09-17 09:35:12 --> Config Class Initialized
DEBUG - 2011-09-17 09:35:12 --> Hooks Class Initialized
DEBUG - 2011-09-17 09:35:12 --> Utf8 Class Initialized
DEBUG - 2011-09-17 09:35:12 --> UTF-8 Support Enabled
DEBUG - 2011-09-17 09:35:12 --> URI Class Initialized
DEBUG - 2011-09-17 09:35:12 --> Router Class Initialized
ERROR - 2011-09-17 09:35:12 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-09-17 09:35:12 --> File loaded: application/views/table/main.php
DEBUG - 2011-09-17 09:35:12 --> Helper loaded: url_helper
DEBUG - 2011-09-17 09:35:12 --> File loaded: application/views/common/header.php
DEBUG - 2011-09-17 09:35:12 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-09-17 09:35:12 --> File loaded: application/views/common/footer.php
DEBUG - 2011-09-17 09:35:12 --> File loaded: application/views/layout/main.php
DEBUG - 2011-09-17 09:35:12 --> Final output sent to browser
DEBUG - 2011-09-17 09:35:12 --> Total execution time: 0.0968
DEBUG - 2011-09-17 09:35:21 --> Config Class Initialized
DEBUG - 2011-09-17 09:35:21 --> Hooks Class Initialized
DEBUG - 2011-09-17 09:35:21 --> Utf8 Class Initialized
DEBUG - 2011-09-17 09:35:21 --> UTF-8 Support Enabled
DEBUG - 2011-09-17 09:35:21 --> URI Class Initialized
DEBUG - 2011-09-17 09:35:21 --> Router Class Initialized
DEBUG - 2011-09-17 09:35:21 --> Output Class Initialized
DEBUG - 2011-09-17 09:35:21 --> Input Class Initialized
DEBUG - 2011-09-17 09:35:21 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-17 09:35:21 --> Language Class Initialized
DEBUG - 2011-09-17 09:35:21 --> Loader Class Initialized
DEBUG - 2011-09-17 09:35:21 --> Controller Class Initialized
ERROR - 2011-09-17 09:35:21 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-09-17 09:35:21 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-09-17 09:35:21 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-09-17 09:35:21 --> Model Class Initialized
DEBUG - 2011-09-17 09:35:21 --> Model Class Initialized
DEBUG - 2011-09-17 09:35:21 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-17 09:35:21 --> Database Driver Class Initialized
DEBUG - 2011-09-17 09:35:21 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-09-17 09:35:21 --> Helper loaded: url_helper
DEBUG - 2011-09-17 09:35:21 --> File loaded: application/views/common/header.php
DEBUG - 2011-09-17 09:35:21 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-09-17 09:35:21 --> File loaded: application/views/common/footer.php
DEBUG - 2011-09-17 09:35:21 --> File loaded: application/views/layout/main.php
DEBUG - 2011-09-17 09:35:21 --> Final output sent to browser
DEBUG - 2011-09-17 09:35:21 --> Total execution time: 0.0357
DEBUG - 2011-09-17 09:35:21 --> Config Class Initialized
DEBUG - 2011-09-17 09:35:21 --> Hooks Class Initialized
DEBUG - 2011-09-17 09:35:21 --> Utf8 Class Initialized
DEBUG - 2011-09-17 09:35:21 --> UTF-8 Support Enabled
DEBUG - 2011-09-17 09:35:21 --> URI Class Initialized
DEBUG - 2011-09-17 09:35:21 --> Router Class Initialized
DEBUG - 2011-09-17 09:35:21 --> Output Class Initialized
DEBUG - 2011-09-17 09:35:21 --> Input Class Initialized
DEBUG - 2011-09-17 09:35:21 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-17 09:35:21 --> Language Class Initialized
DEBUG - 2011-09-17 09:35:21 --> Loader Class Initialized
DEBUG - 2011-09-17 09:35:21 --> Controller Class Initialized
DEBUG - 2011-09-17 09:35:21 --> Model Class Initialized
DEBUG - 2011-09-17 09:35:21 --> Model Class Initialized
DEBUG - 2011-09-17 09:35:21 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-17 09:35:21 --> Database Driver Class Initialized
DEBUG - 2011-09-17 09:35:22 --> Final output sent to browser
DEBUG - 2011-09-17 09:35:22 --> Total execution time: 0.5283
DEBUG - 2011-09-17 09:35:22 --> Config Class Initialized
DEBUG - 2011-09-17 09:35:22 --> Hooks Class Initialized
DEBUG - 2011-09-17 09:35:22 --> Utf8 Class Initialized
DEBUG - 2011-09-17 09:35:22 --> UTF-8 Support Enabled
DEBUG - 2011-09-17 09:35:22 --> URI Class Initialized
DEBUG - 2011-09-17 09:35:22 --> Router Class Initialized
ERROR - 2011-09-17 09:35:22 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-09-17 09:35:26 --> Config Class Initialized
DEBUG - 2011-09-17 09:35:26 --> Hooks Class Initialized
DEBUG - 2011-09-17 09:35:26 --> Utf8 Class Initialized
DEBUG - 2011-09-17 09:35:26 --> UTF-8 Support Enabled
DEBUG - 2011-09-17 09:35:26 --> URI Class Initialized
DEBUG - 2011-09-17 09:35:26 --> Router Class Initialized
DEBUG - 2011-09-17 09:35:26 --> Output Class Initialized
DEBUG - 2011-09-17 09:35:26 --> Input Class Initialized
DEBUG - 2011-09-17 09:35:26 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-17 09:35:26 --> Language Class Initialized
DEBUG - 2011-09-17 09:35:26 --> Loader Class Initialized
DEBUG - 2011-09-17 09:35:26 --> Controller Class Initialized
DEBUG - 2011-09-17 09:35:26 --> Model Class Initialized
DEBUG - 2011-09-17 09:35:26 --> Model Class Initialized
DEBUG - 2011-09-17 09:35:26 --> Model Class Initialized
DEBUG - 2011-09-17 09:35:26 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-17 09:35:26 --> Database Driver Class Initialized
DEBUG - 2011-09-17 09:35:26 --> File loaded: application/views/table/main.php
DEBUG - 2011-09-17 09:35:26 --> Helper loaded: url_helper
DEBUG - 2011-09-17 09:35:26 --> File loaded: application/views/common/header.php
DEBUG - 2011-09-17 09:35:26 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-09-17 09:35:26 --> File loaded: application/views/common/footer.php
DEBUG - 2011-09-17 09:35:26 --> File loaded: application/views/layout/main.php
DEBUG - 2011-09-17 09:35:26 --> Final output sent to browser
DEBUG - 2011-09-17 09:35:26 --> Total execution time: 0.0519
DEBUG - 2011-09-17 09:35:28 --> Config Class Initialized
DEBUG - 2011-09-17 09:35:28 --> Hooks Class Initialized
DEBUG - 2011-09-17 09:35:28 --> Utf8 Class Initialized
DEBUG - 2011-09-17 09:35:28 --> UTF-8 Support Enabled
DEBUG - 2011-09-17 09:35:28 --> URI Class Initialized
DEBUG - 2011-09-17 09:35:28 --> Router Class Initialized
DEBUG - 2011-09-17 09:35:28 --> Output Class Initialized
DEBUG - 2011-09-17 09:35:28 --> Input Class Initialized
DEBUG - 2011-09-17 09:35:28 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-17 09:35:28 --> Language Class Initialized
DEBUG - 2011-09-17 09:35:28 --> Loader Class Initialized
DEBUG - 2011-09-17 09:35:28 --> Controller Class Initialized
ERROR - 2011-09-17 09:35:28 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-09-17 09:35:28 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-09-17 09:35:28 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-09-17 09:35:28 --> Model Class Initialized
DEBUG - 2011-09-17 09:35:28 --> Model Class Initialized
DEBUG - 2011-09-17 09:35:28 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-17 09:35:28 --> Database Driver Class Initialized
DEBUG - 2011-09-17 09:35:28 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-09-17 09:35:28 --> Helper loaded: url_helper
DEBUG - 2011-09-17 09:35:28 --> File loaded: application/views/common/header.php
DEBUG - 2011-09-17 09:35:28 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-09-17 09:35:28 --> File loaded: application/views/common/footer.php
DEBUG - 2011-09-17 09:35:28 --> File loaded: application/views/layout/main.php
DEBUG - 2011-09-17 09:35:28 --> Final output sent to browser
DEBUG - 2011-09-17 09:35:28 --> Total execution time: 0.0276
DEBUG - 2011-09-17 09:35:29 --> Config Class Initialized
DEBUG - 2011-09-17 09:35:29 --> Hooks Class Initialized
DEBUG - 2011-09-17 09:35:29 --> Utf8 Class Initialized
DEBUG - 2011-09-17 09:35:29 --> UTF-8 Support Enabled
DEBUG - 2011-09-17 09:35:29 --> URI Class Initialized
DEBUG - 2011-09-17 09:35:29 --> Router Class Initialized
DEBUG - 2011-09-17 09:35:29 --> Output Class Initialized
DEBUG - 2011-09-17 09:35:29 --> Input Class Initialized
DEBUG - 2011-09-17 09:35:29 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-17 09:35:29 --> Language Class Initialized
DEBUG - 2011-09-17 09:35:29 --> Loader Class Initialized
DEBUG - 2011-09-17 09:35:29 --> Controller Class Initialized
DEBUG - 2011-09-17 09:35:29 --> Model Class Initialized
DEBUG - 2011-09-17 09:35:29 --> Model Class Initialized
DEBUG - 2011-09-17 09:35:29 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-17 09:35:29 --> Database Driver Class Initialized
DEBUG - 2011-09-17 09:35:29 --> Final output sent to browser
DEBUG - 2011-09-17 09:35:29 --> Total execution time: 0.6051
DEBUG - 2011-09-17 09:35:30 --> Config Class Initialized
DEBUG - 2011-09-17 09:35:30 --> Hooks Class Initialized
DEBUG - 2011-09-17 09:35:30 --> Utf8 Class Initialized
DEBUG - 2011-09-17 09:35:30 --> UTF-8 Support Enabled
DEBUG - 2011-09-17 09:35:30 --> URI Class Initialized
DEBUG - 2011-09-17 09:35:30 --> Router Class Initialized
ERROR - 2011-09-17 09:35:30 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-09-17 09:35:49 --> Config Class Initialized
DEBUG - 2011-09-17 09:35:49 --> Hooks Class Initialized
DEBUG - 2011-09-17 09:35:49 --> Utf8 Class Initialized
DEBUG - 2011-09-17 09:35:49 --> UTF-8 Support Enabled
DEBUG - 2011-09-17 09:35:49 --> URI Class Initialized
DEBUG - 2011-09-17 09:35:49 --> Router Class Initialized
DEBUG - 2011-09-17 09:35:49 --> Output Class Initialized
DEBUG - 2011-09-17 09:35:49 --> Input Class Initialized
DEBUG - 2011-09-17 09:35:49 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-17 09:35:49 --> Language Class Initialized
DEBUG - 2011-09-17 09:35:49 --> Loader Class Initialized
DEBUG - 2011-09-17 09:35:49 --> Controller Class Initialized
ERROR - 2011-09-17 09:35:49 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-09-17 09:35:49 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-09-17 09:35:49 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-09-17 09:35:49 --> Model Class Initialized
DEBUG - 2011-09-17 09:35:49 --> Model Class Initialized
DEBUG - 2011-09-17 09:35:49 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-17 09:35:49 --> Database Driver Class Initialized
DEBUG - 2011-09-17 09:35:49 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-09-17 09:35:49 --> Helper loaded: url_helper
DEBUG - 2011-09-17 09:35:49 --> File loaded: application/views/common/header.php
DEBUG - 2011-09-17 09:35:49 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-09-17 09:35:49 --> File loaded: application/views/common/footer.php
DEBUG - 2011-09-17 09:35:49 --> File loaded: application/views/layout/main.php
DEBUG - 2011-09-17 09:35:49 --> Final output sent to browser
DEBUG - 2011-09-17 09:35:49 --> Total execution time: 0.1086
DEBUG - 2011-09-17 09:35:50 --> Config Class Initialized
DEBUG - 2011-09-17 09:35:50 --> Hooks Class Initialized
DEBUG - 2011-09-17 09:35:50 --> Utf8 Class Initialized
DEBUG - 2011-09-17 09:35:50 --> UTF-8 Support Enabled
DEBUG - 2011-09-17 09:35:50 --> URI Class Initialized
DEBUG - 2011-09-17 09:35:50 --> Router Class Initialized
DEBUG - 2011-09-17 09:35:50 --> Output Class Initialized
DEBUG - 2011-09-17 09:35:50 --> Input Class Initialized
DEBUG - 2011-09-17 09:35:50 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-17 09:35:50 --> Language Class Initialized
DEBUG - 2011-09-17 09:35:50 --> Loader Class Initialized
DEBUG - 2011-09-17 09:35:50 --> Controller Class Initialized
DEBUG - 2011-09-17 09:35:50 --> Model Class Initialized
DEBUG - 2011-09-17 09:35:50 --> Model Class Initialized
DEBUG - 2011-09-17 09:35:50 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-17 09:35:50 --> Database Driver Class Initialized
DEBUG - 2011-09-17 09:35:51 --> Final output sent to browser
DEBUG - 2011-09-17 09:35:51 --> Total execution time: 0.7748
DEBUG - 2011-09-17 09:35:52 --> Config Class Initialized
DEBUG - 2011-09-17 09:35:52 --> Hooks Class Initialized
DEBUG - 2011-09-17 09:35:52 --> Utf8 Class Initialized
DEBUG - 2011-09-17 09:35:52 --> UTF-8 Support Enabled
DEBUG - 2011-09-17 09:35:52 --> URI Class Initialized
DEBUG - 2011-09-17 09:35:52 --> Router Class Initialized
ERROR - 2011-09-17 09:35:52 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-09-17 09:35:54 --> Config Class Initialized
DEBUG - 2011-09-17 09:35:54 --> Hooks Class Initialized
DEBUG - 2011-09-17 09:35:54 --> Utf8 Class Initialized
DEBUG - 2011-09-17 09:35:54 --> UTF-8 Support Enabled
DEBUG - 2011-09-17 09:35:54 --> URI Class Initialized
DEBUG - 2011-09-17 09:35:54 --> Router Class Initialized
DEBUG - 2011-09-17 09:35:54 --> Output Class Initialized
DEBUG - 2011-09-17 09:35:54 --> Input Class Initialized
DEBUG - 2011-09-17 09:35:54 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-17 09:35:54 --> Language Class Initialized
DEBUG - 2011-09-17 09:35:54 --> Loader Class Initialized
DEBUG - 2011-09-17 09:35:54 --> Controller Class Initialized
ERROR - 2011-09-17 09:35:54 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-09-17 09:35:54 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-09-17 09:35:54 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-09-17 09:35:54 --> Model Class Initialized
DEBUG - 2011-09-17 09:35:54 --> Model Class Initialized
DEBUG - 2011-09-17 09:35:54 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-17 09:35:54 --> Database Driver Class Initialized
DEBUG - 2011-09-17 09:35:54 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-09-17 09:35:54 --> Helper loaded: url_helper
DEBUG - 2011-09-17 09:35:54 --> File loaded: application/views/common/header.php
DEBUG - 2011-09-17 09:35:54 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-09-17 09:35:54 --> File loaded: application/views/common/footer.php
DEBUG - 2011-09-17 09:35:54 --> File loaded: application/views/layout/main.php
DEBUG - 2011-09-17 09:35:54 --> Final output sent to browser
DEBUG - 2011-09-17 09:35:54 --> Total execution time: 0.0554
DEBUG - 2011-09-17 09:35:55 --> Config Class Initialized
DEBUG - 2011-09-17 09:35:55 --> Hooks Class Initialized
DEBUG - 2011-09-17 09:35:55 --> Utf8 Class Initialized
DEBUG - 2011-09-17 09:35:55 --> UTF-8 Support Enabled
DEBUG - 2011-09-17 09:35:55 --> URI Class Initialized
DEBUG - 2011-09-17 09:35:55 --> Router Class Initialized
DEBUG - 2011-09-17 09:35:55 --> Output Class Initialized
DEBUG - 2011-09-17 09:35:55 --> Input Class Initialized
DEBUG - 2011-09-17 09:35:55 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-17 09:35:55 --> Language Class Initialized
DEBUG - 2011-09-17 09:35:55 --> Loader Class Initialized
DEBUG - 2011-09-17 09:35:55 --> Controller Class Initialized
DEBUG - 2011-09-17 09:35:55 --> Model Class Initialized
DEBUG - 2011-09-17 09:35:55 --> Model Class Initialized
DEBUG - 2011-09-17 09:35:55 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-17 09:35:55 --> Database Driver Class Initialized
DEBUG - 2011-09-17 09:35:55 --> Final output sent to browser
DEBUG - 2011-09-17 09:35:55 --> Total execution time: 0.6361
DEBUG - 2011-09-17 09:35:56 --> Config Class Initialized
DEBUG - 2011-09-17 09:35:56 --> Hooks Class Initialized
DEBUG - 2011-09-17 09:35:56 --> Utf8 Class Initialized
DEBUG - 2011-09-17 09:35:56 --> UTF-8 Support Enabled
DEBUG - 2011-09-17 09:35:56 --> URI Class Initialized
DEBUG - 2011-09-17 09:35:56 --> Router Class Initialized
ERROR - 2011-09-17 09:35:56 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-09-17 09:36:03 --> Config Class Initialized
DEBUG - 2011-09-17 09:36:03 --> Hooks Class Initialized
DEBUG - 2011-09-17 09:36:03 --> Utf8 Class Initialized
DEBUG - 2011-09-17 09:36:03 --> UTF-8 Support Enabled
DEBUG - 2011-09-17 09:36:03 --> URI Class Initialized
DEBUG - 2011-09-17 09:36:03 --> Router Class Initialized
DEBUG - 2011-09-17 09:36:03 --> Output Class Initialized
DEBUG - 2011-09-17 09:36:03 --> Input Class Initialized
DEBUG - 2011-09-17 09:36:03 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-17 09:36:03 --> Language Class Initialized
DEBUG - 2011-09-17 09:36:03 --> Loader Class Initialized
DEBUG - 2011-09-17 09:36:03 --> Controller Class Initialized
ERROR - 2011-09-17 09:36:03 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-09-17 09:36:03 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-09-17 09:36:03 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-09-17 09:36:03 --> Model Class Initialized
DEBUG - 2011-09-17 09:36:03 --> Model Class Initialized
DEBUG - 2011-09-17 09:36:03 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-17 09:36:03 --> Database Driver Class Initialized
DEBUG - 2011-09-17 09:36:03 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-09-17 09:36:03 --> Helper loaded: url_helper
DEBUG - 2011-09-17 09:36:03 --> File loaded: application/views/common/header.php
DEBUG - 2011-09-17 09:36:03 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-09-17 09:36:03 --> File loaded: application/views/common/footer.php
DEBUG - 2011-09-17 09:36:03 --> File loaded: application/views/layout/main.php
DEBUG - 2011-09-17 09:36:03 --> Final output sent to browser
DEBUG - 2011-09-17 09:36:03 --> Total execution time: 0.0428
DEBUG - 2011-09-17 09:36:03 --> Config Class Initialized
DEBUG - 2011-09-17 09:36:03 --> Hooks Class Initialized
DEBUG - 2011-09-17 09:36:03 --> Utf8 Class Initialized
DEBUG - 2011-09-17 09:36:03 --> UTF-8 Support Enabled
DEBUG - 2011-09-17 09:36:03 --> URI Class Initialized
DEBUG - 2011-09-17 09:36:03 --> Router Class Initialized
DEBUG - 2011-09-17 09:36:03 --> Output Class Initialized
DEBUG - 2011-09-17 09:36:03 --> Input Class Initialized
DEBUG - 2011-09-17 09:36:03 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-17 09:36:03 --> Language Class Initialized
DEBUG - 2011-09-17 09:36:03 --> Loader Class Initialized
DEBUG - 2011-09-17 09:36:03 --> Controller Class Initialized
DEBUG - 2011-09-17 09:36:03 --> Model Class Initialized
DEBUG - 2011-09-17 09:36:03 --> Model Class Initialized
DEBUG - 2011-09-17 09:36:03 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-17 09:36:03 --> Database Driver Class Initialized
DEBUG - 2011-09-17 09:36:04 --> Final output sent to browser
DEBUG - 2011-09-17 09:36:04 --> Total execution time: 0.5563
DEBUG - 2011-09-17 09:36:05 --> Config Class Initialized
DEBUG - 2011-09-17 09:36:05 --> Hooks Class Initialized
DEBUG - 2011-09-17 09:36:05 --> Utf8 Class Initialized
DEBUG - 2011-09-17 09:36:05 --> UTF-8 Support Enabled
DEBUG - 2011-09-17 09:36:05 --> URI Class Initialized
DEBUG - 2011-09-17 09:36:05 --> Router Class Initialized
ERROR - 2011-09-17 09:36:05 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-09-17 09:36:12 --> Config Class Initialized
DEBUG - 2011-09-17 09:36:12 --> Hooks Class Initialized
DEBUG - 2011-09-17 09:36:12 --> Utf8 Class Initialized
DEBUG - 2011-09-17 09:36:12 --> UTF-8 Support Enabled
DEBUG - 2011-09-17 09:36:12 --> URI Class Initialized
DEBUG - 2011-09-17 09:36:12 --> Router Class Initialized
DEBUG - 2011-09-17 09:36:12 --> Output Class Initialized
DEBUG - 2011-09-17 09:36:12 --> Input Class Initialized
DEBUG - 2011-09-17 09:36:12 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-17 09:36:12 --> Language Class Initialized
DEBUG - 2011-09-17 09:36:12 --> Loader Class Initialized
DEBUG - 2011-09-17 09:36:12 --> Controller Class Initialized
ERROR - 2011-09-17 09:36:12 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-09-17 09:36:12 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-09-17 09:36:12 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-09-17 09:36:12 --> Model Class Initialized
DEBUG - 2011-09-17 09:36:12 --> Model Class Initialized
DEBUG - 2011-09-17 09:36:12 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-17 09:36:12 --> Database Driver Class Initialized
DEBUG - 2011-09-17 09:36:12 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-09-17 09:36:12 --> Helper loaded: url_helper
DEBUG - 2011-09-17 09:36:12 --> File loaded: application/views/common/header.php
DEBUG - 2011-09-17 09:36:12 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-09-17 09:36:12 --> File loaded: application/views/common/footer.php
DEBUG - 2011-09-17 09:36:12 --> File loaded: application/views/layout/main.php
DEBUG - 2011-09-17 09:36:12 --> Final output sent to browser
DEBUG - 2011-09-17 09:36:12 --> Total execution time: 0.0567
DEBUG - 2011-09-17 09:36:12 --> Config Class Initialized
DEBUG - 2011-09-17 09:36:12 --> Hooks Class Initialized
DEBUG - 2011-09-17 09:36:12 --> Utf8 Class Initialized
DEBUG - 2011-09-17 09:36:12 --> UTF-8 Support Enabled
DEBUG - 2011-09-17 09:36:12 --> URI Class Initialized
DEBUG - 2011-09-17 09:36:12 --> Router Class Initialized
DEBUG - 2011-09-17 09:36:12 --> Output Class Initialized
DEBUG - 2011-09-17 09:36:12 --> Input Class Initialized
DEBUG - 2011-09-17 09:36:12 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-17 09:36:12 --> Language Class Initialized
DEBUG - 2011-09-17 09:36:12 --> Loader Class Initialized
DEBUG - 2011-09-17 09:36:12 --> Controller Class Initialized
DEBUG - 2011-09-17 09:36:12 --> Model Class Initialized
DEBUG - 2011-09-17 09:36:12 --> Model Class Initialized
DEBUG - 2011-09-17 09:36:12 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-17 09:36:12 --> Database Driver Class Initialized
DEBUG - 2011-09-17 09:36:13 --> Final output sent to browser
DEBUG - 2011-09-17 09:36:13 --> Total execution time: 0.6601
DEBUG - 2011-09-17 09:36:14 --> Config Class Initialized
DEBUG - 2011-09-17 09:36:14 --> Hooks Class Initialized
DEBUG - 2011-09-17 09:36:14 --> Utf8 Class Initialized
DEBUG - 2011-09-17 09:36:14 --> UTF-8 Support Enabled
DEBUG - 2011-09-17 09:36:14 --> URI Class Initialized
DEBUG - 2011-09-17 09:36:14 --> Router Class Initialized
ERROR - 2011-09-17 09:36:14 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-09-17 09:36:21 --> Config Class Initialized
DEBUG - 2011-09-17 09:36:21 --> Hooks Class Initialized
DEBUG - 2011-09-17 09:36:21 --> Utf8 Class Initialized
DEBUG - 2011-09-17 09:36:21 --> UTF-8 Support Enabled
DEBUG - 2011-09-17 09:36:21 --> URI Class Initialized
DEBUG - 2011-09-17 09:36:21 --> Router Class Initialized
DEBUG - 2011-09-17 09:36:21 --> Output Class Initialized
DEBUG - 2011-09-17 09:36:21 --> Input Class Initialized
DEBUG - 2011-09-17 09:36:21 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-17 09:36:21 --> Language Class Initialized
DEBUG - 2011-09-17 09:36:21 --> Loader Class Initialized
DEBUG - 2011-09-17 09:36:21 --> Controller Class Initialized
ERROR - 2011-09-17 09:36:21 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-09-17 09:36:21 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-09-17 09:36:21 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-09-17 09:36:21 --> Model Class Initialized
DEBUG - 2011-09-17 09:36:21 --> Model Class Initialized
DEBUG - 2011-09-17 09:36:21 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-17 09:36:21 --> Database Driver Class Initialized
DEBUG - 2011-09-17 09:36:21 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-09-17 09:36:21 --> Helper loaded: url_helper
DEBUG - 2011-09-17 09:36:21 --> File loaded: application/views/common/header.php
DEBUG - 2011-09-17 09:36:21 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-09-17 09:36:21 --> File loaded: application/views/common/footer.php
DEBUG - 2011-09-17 09:36:21 --> File loaded: application/views/layout/main.php
DEBUG - 2011-09-17 09:36:21 --> Final output sent to browser
DEBUG - 2011-09-17 09:36:21 --> Total execution time: 0.0532
DEBUG - 2011-09-17 09:36:22 --> Config Class Initialized
DEBUG - 2011-09-17 09:36:22 --> Hooks Class Initialized
DEBUG - 2011-09-17 09:36:22 --> Utf8 Class Initialized
DEBUG - 2011-09-17 09:36:22 --> UTF-8 Support Enabled
DEBUG - 2011-09-17 09:36:22 --> URI Class Initialized
DEBUG - 2011-09-17 09:36:22 --> Router Class Initialized
DEBUG - 2011-09-17 09:36:22 --> Output Class Initialized
DEBUG - 2011-09-17 09:36:22 --> Input Class Initialized
DEBUG - 2011-09-17 09:36:22 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-17 09:36:22 --> Language Class Initialized
DEBUG - 2011-09-17 09:36:22 --> Loader Class Initialized
DEBUG - 2011-09-17 09:36:22 --> Controller Class Initialized
DEBUG - 2011-09-17 09:36:22 --> Model Class Initialized
DEBUG - 2011-09-17 09:36:22 --> Model Class Initialized
DEBUG - 2011-09-17 09:36:22 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-17 09:36:22 --> Database Driver Class Initialized
DEBUG - 2011-09-17 09:36:22 --> Final output sent to browser
DEBUG - 2011-09-17 09:36:22 --> Total execution time: 0.5616
DEBUG - 2011-09-17 09:36:23 --> Config Class Initialized
DEBUG - 2011-09-17 09:36:23 --> Hooks Class Initialized
DEBUG - 2011-09-17 09:36:23 --> Utf8 Class Initialized
DEBUG - 2011-09-17 09:36:23 --> UTF-8 Support Enabled
DEBUG - 2011-09-17 09:36:23 --> URI Class Initialized
DEBUG - 2011-09-17 09:36:23 --> Router Class Initialized
ERROR - 2011-09-17 09:36:23 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-09-17 09:36:32 --> Config Class Initialized
DEBUG - 2011-09-17 09:36:32 --> Hooks Class Initialized
DEBUG - 2011-09-17 09:36:32 --> Utf8 Class Initialized
DEBUG - 2011-09-17 09:36:32 --> UTF-8 Support Enabled
DEBUG - 2011-09-17 09:36:32 --> URI Class Initialized
DEBUG - 2011-09-17 09:36:32 --> Router Class Initialized
DEBUG - 2011-09-17 09:36:32 --> Output Class Initialized
DEBUG - 2011-09-17 09:36:32 --> Input Class Initialized
DEBUG - 2011-09-17 09:36:32 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-17 09:36:32 --> Language Class Initialized
DEBUG - 2011-09-17 09:36:33 --> Loader Class Initialized
DEBUG - 2011-09-17 09:36:33 --> Controller Class Initialized
ERROR - 2011-09-17 09:36:33 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-09-17 09:36:33 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-09-17 09:36:33 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-09-17 09:36:33 --> Model Class Initialized
DEBUG - 2011-09-17 09:36:33 --> Model Class Initialized
DEBUG - 2011-09-17 09:36:33 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-17 09:36:33 --> Database Driver Class Initialized
DEBUG - 2011-09-17 09:36:33 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-09-17 09:36:33 --> Helper loaded: url_helper
DEBUG - 2011-09-17 09:36:33 --> File loaded: application/views/common/header.php
DEBUG - 2011-09-17 09:36:33 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-09-17 09:36:33 --> File loaded: application/views/common/footer.php
DEBUG - 2011-09-17 09:36:33 --> File loaded: application/views/layout/main.php
DEBUG - 2011-09-17 09:36:33 --> Final output sent to browser
DEBUG - 2011-09-17 09:36:33 --> Total execution time: 0.2182
DEBUG - 2011-09-17 09:36:33 --> Config Class Initialized
DEBUG - 2011-09-17 09:36:33 --> Hooks Class Initialized
DEBUG - 2011-09-17 09:36:33 --> Utf8 Class Initialized
DEBUG - 2011-09-17 09:36:33 --> UTF-8 Support Enabled
DEBUG - 2011-09-17 09:36:33 --> URI Class Initialized
DEBUG - 2011-09-17 09:36:33 --> Router Class Initialized
DEBUG - 2011-09-17 09:36:33 --> Output Class Initialized
DEBUG - 2011-09-17 09:36:33 --> Input Class Initialized
DEBUG - 2011-09-17 09:36:33 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-17 09:36:33 --> Language Class Initialized
DEBUG - 2011-09-17 09:36:33 --> Loader Class Initialized
DEBUG - 2011-09-17 09:36:33 --> Controller Class Initialized
DEBUG - 2011-09-17 09:36:33 --> Model Class Initialized
DEBUG - 2011-09-17 09:36:33 --> Model Class Initialized
DEBUG - 2011-09-17 09:36:33 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-17 09:36:33 --> Database Driver Class Initialized
DEBUG - 2011-09-17 09:36:34 --> Final output sent to browser
DEBUG - 2011-09-17 09:36:34 --> Total execution time: 0.6620
DEBUG - 2011-09-17 09:36:35 --> Config Class Initialized
DEBUG - 2011-09-17 09:36:35 --> Hooks Class Initialized
DEBUG - 2011-09-17 09:36:35 --> Utf8 Class Initialized
DEBUG - 2011-09-17 09:36:35 --> UTF-8 Support Enabled
DEBUG - 2011-09-17 09:36:35 --> URI Class Initialized
DEBUG - 2011-09-17 09:36:35 --> Router Class Initialized
ERROR - 2011-09-17 09:36:35 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-09-17 09:36:52 --> Config Class Initialized
DEBUG - 2011-09-17 09:36:52 --> Hooks Class Initialized
DEBUG - 2011-09-17 09:36:52 --> Utf8 Class Initialized
DEBUG - 2011-09-17 09:36:52 --> UTF-8 Support Enabled
DEBUG - 2011-09-17 09:36:52 --> URI Class Initialized
DEBUG - 2011-09-17 09:36:52 --> Router Class Initialized
DEBUG - 2011-09-17 09:36:52 --> Output Class Initialized
DEBUG - 2011-09-17 09:36:52 --> Input Class Initialized
DEBUG - 2011-09-17 09:36:52 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-17 09:36:52 --> Language Class Initialized
DEBUG - 2011-09-17 09:36:52 --> Loader Class Initialized
DEBUG - 2011-09-17 09:36:52 --> Controller Class Initialized
ERROR - 2011-09-17 09:36:52 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-09-17 09:36:52 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-09-17 09:36:52 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-09-17 09:36:52 --> Model Class Initialized
DEBUG - 2011-09-17 09:36:52 --> Model Class Initialized
DEBUG - 2011-09-17 09:36:52 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-17 09:36:52 --> Database Driver Class Initialized
DEBUG - 2011-09-17 09:36:52 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-09-17 09:36:52 --> Helper loaded: url_helper
DEBUG - 2011-09-17 09:36:52 --> File loaded: application/views/common/header.php
DEBUG - 2011-09-17 09:36:52 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-09-17 09:36:52 --> File loaded: application/views/common/footer.php
DEBUG - 2011-09-17 09:36:52 --> File loaded: application/views/layout/main.php
DEBUG - 2011-09-17 09:36:52 --> Final output sent to browser
DEBUG - 2011-09-17 09:36:52 --> Total execution time: 0.0295
DEBUG - 2011-09-17 09:36:53 --> Config Class Initialized
DEBUG - 2011-09-17 09:36:53 --> Hooks Class Initialized
DEBUG - 2011-09-17 09:36:53 --> Utf8 Class Initialized
DEBUG - 2011-09-17 09:36:53 --> UTF-8 Support Enabled
DEBUG - 2011-09-17 09:36:53 --> URI Class Initialized
DEBUG - 2011-09-17 09:36:53 --> Router Class Initialized
DEBUG - 2011-09-17 09:36:53 --> Output Class Initialized
DEBUG - 2011-09-17 09:36:53 --> Input Class Initialized
DEBUG - 2011-09-17 09:36:53 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-17 09:36:53 --> Language Class Initialized
DEBUG - 2011-09-17 09:36:53 --> Loader Class Initialized
DEBUG - 2011-09-17 09:36:53 --> Controller Class Initialized
DEBUG - 2011-09-17 09:36:53 --> Model Class Initialized
DEBUG - 2011-09-17 09:36:53 --> Model Class Initialized
DEBUG - 2011-09-17 09:36:53 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-17 09:36:53 --> Database Driver Class Initialized
DEBUG - 2011-09-17 09:36:53 --> Final output sent to browser
DEBUG - 2011-09-17 09:36:53 --> Total execution time: 0.5910
DEBUG - 2011-09-17 09:36:54 --> Config Class Initialized
DEBUG - 2011-09-17 09:36:54 --> Hooks Class Initialized
DEBUG - 2011-09-17 09:36:54 --> Utf8 Class Initialized
DEBUG - 2011-09-17 09:36:54 --> UTF-8 Support Enabled
DEBUG - 2011-09-17 09:36:54 --> URI Class Initialized
DEBUG - 2011-09-17 09:36:54 --> Router Class Initialized
ERROR - 2011-09-17 09:36:54 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-09-17 09:49:04 --> Config Class Initialized
DEBUG - 2011-09-17 09:49:04 --> Hooks Class Initialized
DEBUG - 2011-09-17 09:49:04 --> Utf8 Class Initialized
DEBUG - 2011-09-17 09:49:04 --> UTF-8 Support Enabled
DEBUG - 2011-09-17 09:49:04 --> URI Class Initialized
DEBUG - 2011-09-17 09:49:04 --> Router Class Initialized
DEBUG - 2011-09-17 09:49:04 --> Output Class Initialized
DEBUG - 2011-09-17 09:49:04 --> Input Class Initialized
DEBUG - 2011-09-17 09:49:04 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-17 09:49:04 --> Language Class Initialized
DEBUG - 2011-09-17 09:49:04 --> Loader Class Initialized
DEBUG - 2011-09-17 09:49:04 --> Controller Class Initialized
DEBUG - 2011-09-17 09:49:04 --> Model Class Initialized
DEBUG - 2011-09-17 09:49:04 --> Model Class Initialized
DEBUG - 2011-09-17 09:49:04 --> Model Class Initialized
DEBUG - 2011-09-17 09:49:04 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-17 09:49:04 --> Database Driver Class Initialized
DEBUG - 2011-09-17 09:49:04 --> File loaded: application/views/table/main.php
DEBUG - 2011-09-17 09:49:04 --> Helper loaded: url_helper
DEBUG - 2011-09-17 09:49:04 --> File loaded: application/views/common/header.php
DEBUG - 2011-09-17 09:49:04 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-09-17 09:49:04 --> File loaded: application/views/common/footer.php
DEBUG - 2011-09-17 09:49:04 --> File loaded: application/views/layout/main.php
DEBUG - 2011-09-17 09:49:04 --> Final output sent to browser
DEBUG - 2011-09-17 09:49:04 --> Total execution time: 0.0474
DEBUG - 2011-09-17 09:49:28 --> Config Class Initialized
DEBUG - 2011-09-17 09:49:28 --> Hooks Class Initialized
DEBUG - 2011-09-17 09:49:28 --> Utf8 Class Initialized
DEBUG - 2011-09-17 09:49:28 --> UTF-8 Support Enabled
DEBUG - 2011-09-17 09:49:28 --> URI Class Initialized
DEBUG - 2011-09-17 09:49:28 --> Router Class Initialized
ERROR - 2011-09-17 09:49:28 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-09-17 09:49:29 --> Config Class Initialized
DEBUG - 2011-09-17 09:49:29 --> Hooks Class Initialized
DEBUG - 2011-09-17 09:49:29 --> Utf8 Class Initialized
DEBUG - 2011-09-17 09:49:29 --> UTF-8 Support Enabled
DEBUG - 2011-09-17 09:49:29 --> URI Class Initialized
DEBUG - 2011-09-17 09:49:29 --> Router Class Initialized
ERROR - 2011-09-17 09:49:29 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-09-17 10:11:18 --> Config Class Initialized
DEBUG - 2011-09-17 10:11:18 --> Hooks Class Initialized
DEBUG - 2011-09-17 10:11:18 --> Utf8 Class Initialized
DEBUG - 2011-09-17 10:11:18 --> UTF-8 Support Enabled
DEBUG - 2011-09-17 10:11:18 --> URI Class Initialized
DEBUG - 2011-09-17 10:11:18 --> Router Class Initialized
DEBUG - 2011-09-17 10:11:18 --> Output Class Initialized
DEBUG - 2011-09-17 10:11:18 --> Input Class Initialized
DEBUG - 2011-09-17 10:11:18 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-17 10:11:18 --> Language Class Initialized
DEBUG - 2011-09-17 10:11:18 --> Loader Class Initialized
DEBUG - 2011-09-17 10:11:18 --> Controller Class Initialized
ERROR - 2011-09-17 10:11:18 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-09-17 10:11:18 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-09-17 10:11:18 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-09-17 10:11:18 --> Model Class Initialized
DEBUG - 2011-09-17 10:11:18 --> Model Class Initialized
DEBUG - 2011-09-17 10:11:18 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-17 10:11:18 --> Database Driver Class Initialized
DEBUG - 2011-09-17 10:11:18 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-09-17 10:11:18 --> Helper loaded: url_helper
DEBUG - 2011-09-17 10:11:18 --> File loaded: application/views/common/header.php
DEBUG - 2011-09-17 10:11:18 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-09-17 10:11:18 --> File loaded: application/views/common/footer.php
DEBUG - 2011-09-17 10:11:18 --> File loaded: application/views/layout/main.php
DEBUG - 2011-09-17 10:11:18 --> Final output sent to browser
DEBUG - 2011-09-17 10:11:18 --> Total execution time: 0.0503
DEBUG - 2011-09-17 10:11:19 --> Config Class Initialized
DEBUG - 2011-09-17 10:11:19 --> Hooks Class Initialized
DEBUG - 2011-09-17 10:11:19 --> Utf8 Class Initialized
DEBUG - 2011-09-17 10:11:19 --> UTF-8 Support Enabled
DEBUG - 2011-09-17 10:11:19 --> URI Class Initialized
DEBUG - 2011-09-17 10:11:19 --> Router Class Initialized
DEBUG - 2011-09-17 10:11:19 --> Output Class Initialized
DEBUG - 2011-09-17 10:11:19 --> Input Class Initialized
DEBUG - 2011-09-17 10:11:19 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-17 10:11:19 --> Language Class Initialized
DEBUG - 2011-09-17 10:11:19 --> Loader Class Initialized
DEBUG - 2011-09-17 10:11:19 --> Controller Class Initialized
DEBUG - 2011-09-17 10:11:19 --> Model Class Initialized
DEBUG - 2011-09-17 10:11:19 --> Model Class Initialized
DEBUG - 2011-09-17 10:11:19 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-17 10:11:19 --> Database Driver Class Initialized
DEBUG - 2011-09-17 10:11:20 --> Final output sent to browser
DEBUG - 2011-09-17 10:11:20 --> Total execution time: 0.7976
DEBUG - 2011-09-17 10:11:20 --> Config Class Initialized
DEBUG - 2011-09-17 10:11:20 --> Hooks Class Initialized
DEBUG - 2011-09-17 10:11:20 --> Utf8 Class Initialized
DEBUG - 2011-09-17 10:11:20 --> UTF-8 Support Enabled
DEBUG - 2011-09-17 10:11:20 --> URI Class Initialized
DEBUG - 2011-09-17 10:11:20 --> Router Class Initialized
ERROR - 2011-09-17 10:11:20 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-09-17 10:11:34 --> Config Class Initialized
DEBUG - 2011-09-17 10:11:34 --> Hooks Class Initialized
DEBUG - 2011-09-17 10:11:34 --> Utf8 Class Initialized
DEBUG - 2011-09-17 10:11:34 --> UTF-8 Support Enabled
DEBUG - 2011-09-17 10:11:34 --> URI Class Initialized
DEBUG - 2011-09-17 10:11:34 --> Router Class Initialized
DEBUG - 2011-09-17 10:11:34 --> Output Class Initialized
DEBUG - 2011-09-17 10:11:34 --> Input Class Initialized
DEBUG - 2011-09-17 10:11:34 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-17 10:11:34 --> Language Class Initialized
DEBUG - 2011-09-17 10:11:34 --> Loader Class Initialized
DEBUG - 2011-09-17 10:11:34 --> Controller Class Initialized
ERROR - 2011-09-17 10:11:34 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-09-17 10:11:34 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-09-17 10:11:34 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-09-17 10:11:34 --> Model Class Initialized
DEBUG - 2011-09-17 10:11:34 --> Model Class Initialized
DEBUG - 2011-09-17 10:11:34 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-17 10:11:35 --> Database Driver Class Initialized
DEBUG - 2011-09-17 10:11:35 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-09-17 10:11:35 --> Helper loaded: url_helper
DEBUG - 2011-09-17 10:11:35 --> File loaded: application/views/common/header.php
DEBUG - 2011-09-17 10:11:35 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-09-17 10:11:35 --> File loaded: application/views/common/footer.php
DEBUG - 2011-09-17 10:11:35 --> File loaded: application/views/layout/main.php
DEBUG - 2011-09-17 10:11:35 --> Final output sent to browser
DEBUG - 2011-09-17 10:11:35 --> Total execution time: 0.0296
DEBUG - 2011-09-17 10:11:35 --> Config Class Initialized
DEBUG - 2011-09-17 10:11:35 --> Hooks Class Initialized
DEBUG - 2011-09-17 10:11:35 --> Utf8 Class Initialized
DEBUG - 2011-09-17 10:11:35 --> UTF-8 Support Enabled
DEBUG - 2011-09-17 10:11:35 --> URI Class Initialized
DEBUG - 2011-09-17 10:11:35 --> Router Class Initialized
DEBUG - 2011-09-17 10:11:35 --> Output Class Initialized
DEBUG - 2011-09-17 10:11:35 --> Input Class Initialized
DEBUG - 2011-09-17 10:11:35 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-17 10:11:35 --> Language Class Initialized
DEBUG - 2011-09-17 10:11:35 --> Loader Class Initialized
DEBUG - 2011-09-17 10:11:35 --> Controller Class Initialized
DEBUG - 2011-09-17 10:11:35 --> Model Class Initialized
DEBUG - 2011-09-17 10:11:35 --> Model Class Initialized
DEBUG - 2011-09-17 10:11:35 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-17 10:11:35 --> Database Driver Class Initialized
DEBUG - 2011-09-17 10:11:36 --> Final output sent to browser
DEBUG - 2011-09-17 10:11:36 --> Total execution time: 0.7238
DEBUG - 2011-09-17 10:11:37 --> Config Class Initialized
DEBUG - 2011-09-17 10:11:37 --> Hooks Class Initialized
DEBUG - 2011-09-17 10:11:37 --> Utf8 Class Initialized
DEBUG - 2011-09-17 10:11:37 --> UTF-8 Support Enabled
DEBUG - 2011-09-17 10:11:37 --> URI Class Initialized
DEBUG - 2011-09-17 10:11:37 --> Router Class Initialized
ERROR - 2011-09-17 10:11:37 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-09-17 10:15:19 --> Config Class Initialized
DEBUG - 2011-09-17 10:15:19 --> Hooks Class Initialized
DEBUG - 2011-09-17 10:15:19 --> Utf8 Class Initialized
DEBUG - 2011-09-17 10:15:19 --> UTF-8 Support Enabled
DEBUG - 2011-09-17 10:15:19 --> URI Class Initialized
DEBUG - 2011-09-17 10:15:19 --> Router Class Initialized
DEBUG - 2011-09-17 10:15:19 --> Output Class Initialized
DEBUG - 2011-09-17 10:15:19 --> Input Class Initialized
DEBUG - 2011-09-17 10:15:19 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-17 10:15:19 --> Language Class Initialized
DEBUG - 2011-09-17 10:15:19 --> Loader Class Initialized
DEBUG - 2011-09-17 10:15:19 --> Controller Class Initialized
ERROR - 2011-09-17 10:15:19 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-09-17 10:15:19 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-09-17 10:15:19 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-09-17 10:15:19 --> Model Class Initialized
DEBUG - 2011-09-17 10:15:19 --> Model Class Initialized
DEBUG - 2011-09-17 10:15:19 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-17 10:15:19 --> Database Driver Class Initialized
DEBUG - 2011-09-17 10:15:19 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-09-17 10:15:19 --> Helper loaded: url_helper
DEBUG - 2011-09-17 10:15:19 --> File loaded: application/views/common/header.php
DEBUG - 2011-09-17 10:15:19 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-09-17 10:15:19 --> File loaded: application/views/common/footer.php
DEBUG - 2011-09-17 10:15:19 --> File loaded: application/views/layout/main.php
DEBUG - 2011-09-17 10:15:19 --> Final output sent to browser
DEBUG - 2011-09-17 10:15:19 --> Total execution time: 0.0292
DEBUG - 2011-09-17 10:15:21 --> Config Class Initialized
DEBUG - 2011-09-17 10:15:21 --> Hooks Class Initialized
DEBUG - 2011-09-17 10:15:21 --> Utf8 Class Initialized
DEBUG - 2011-09-17 10:15:21 --> UTF-8 Support Enabled
DEBUG - 2011-09-17 10:15:21 --> URI Class Initialized
DEBUG - 2011-09-17 10:15:21 --> Router Class Initialized
DEBUG - 2011-09-17 10:15:21 --> Output Class Initialized
DEBUG - 2011-09-17 10:15:21 --> Input Class Initialized
DEBUG - 2011-09-17 10:15:21 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-17 10:15:21 --> Language Class Initialized
DEBUG - 2011-09-17 10:15:21 --> Loader Class Initialized
DEBUG - 2011-09-17 10:15:21 --> Controller Class Initialized
DEBUG - 2011-09-17 10:15:21 --> Model Class Initialized
DEBUG - 2011-09-17 10:15:21 --> Model Class Initialized
DEBUG - 2011-09-17 10:15:21 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-17 10:15:21 --> Database Driver Class Initialized
DEBUG - 2011-09-17 10:15:21 --> Config Class Initialized
DEBUG - 2011-09-17 10:15:21 --> Hooks Class Initialized
DEBUG - 2011-09-17 10:15:21 --> Utf8 Class Initialized
DEBUG - 2011-09-17 10:15:21 --> UTF-8 Support Enabled
DEBUG - 2011-09-17 10:15:21 --> URI Class Initialized
DEBUG - 2011-09-17 10:15:21 --> Router Class Initialized
ERROR - 2011-09-17 10:15:21 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-09-17 10:15:21 --> Final output sent to browser
DEBUG - 2011-09-17 10:15:21 --> Total execution time: 0.5685
DEBUG - 2011-09-17 10:15:26 --> Config Class Initialized
DEBUG - 2011-09-17 10:15:26 --> Hooks Class Initialized
DEBUG - 2011-09-17 10:15:26 --> Utf8 Class Initialized
DEBUG - 2011-09-17 10:15:26 --> UTF-8 Support Enabled
DEBUG - 2011-09-17 10:15:26 --> URI Class Initialized
DEBUG - 2011-09-17 10:15:26 --> Router Class Initialized
DEBUG - 2011-09-17 10:15:26 --> Output Class Initialized
DEBUG - 2011-09-17 10:15:26 --> Input Class Initialized
DEBUG - 2011-09-17 10:15:26 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-17 10:15:26 --> Language Class Initialized
DEBUG - 2011-09-17 10:15:26 --> Loader Class Initialized
DEBUG - 2011-09-17 10:15:26 --> Controller Class Initialized
ERROR - 2011-09-17 10:15:26 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-09-17 10:15:26 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-09-17 10:15:26 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-09-17 10:15:26 --> Model Class Initialized
DEBUG - 2011-09-17 10:15:26 --> Model Class Initialized
DEBUG - 2011-09-17 10:15:26 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-17 10:15:26 --> Database Driver Class Initialized
DEBUG - 2011-09-17 10:15:26 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-09-17 10:15:26 --> Helper loaded: url_helper
DEBUG - 2011-09-17 10:15:26 --> File loaded: application/views/common/header.php
DEBUG - 2011-09-17 10:15:26 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-09-17 10:15:26 --> File loaded: application/views/common/footer.php
DEBUG - 2011-09-17 10:15:26 --> File loaded: application/views/layout/main.php
DEBUG - 2011-09-17 10:15:26 --> Final output sent to browser
DEBUG - 2011-09-17 10:15:26 --> Total execution time: 0.0313
DEBUG - 2011-09-17 10:15:27 --> Config Class Initialized
DEBUG - 2011-09-17 10:15:27 --> Hooks Class Initialized
DEBUG - 2011-09-17 10:15:27 --> Utf8 Class Initialized
DEBUG - 2011-09-17 10:15:27 --> UTF-8 Support Enabled
DEBUG - 2011-09-17 10:15:27 --> URI Class Initialized
DEBUG - 2011-09-17 10:15:27 --> Router Class Initialized
DEBUG - 2011-09-17 10:15:27 --> Output Class Initialized
DEBUG - 2011-09-17 10:15:27 --> Input Class Initialized
DEBUG - 2011-09-17 10:15:27 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-17 10:15:27 --> Language Class Initialized
DEBUG - 2011-09-17 10:15:27 --> Loader Class Initialized
DEBUG - 2011-09-17 10:15:27 --> Controller Class Initialized
DEBUG - 2011-09-17 10:15:27 --> Model Class Initialized
DEBUG - 2011-09-17 10:15:27 --> Model Class Initialized
DEBUG - 2011-09-17 10:15:27 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-17 10:15:27 --> Database Driver Class Initialized
DEBUG - 2011-09-17 10:15:28 --> Final output sent to browser
DEBUG - 2011-09-17 10:15:28 --> Total execution time: 0.5129
DEBUG - 2011-09-17 10:39:28 --> Config Class Initialized
DEBUG - 2011-09-17 10:39:28 --> Hooks Class Initialized
DEBUG - 2011-09-17 10:39:28 --> Utf8 Class Initialized
DEBUG - 2011-09-17 10:39:28 --> UTF-8 Support Enabled
DEBUG - 2011-09-17 10:39:28 --> URI Class Initialized
DEBUG - 2011-09-17 10:39:28 --> Router Class Initialized
ERROR - 2011-09-17 10:39:28 --> 404 Page Not Found --> robots.txt
DEBUG - 2011-09-17 10:39:29 --> Config Class Initialized
DEBUG - 2011-09-17 10:39:29 --> Hooks Class Initialized
DEBUG - 2011-09-17 10:39:29 --> Utf8 Class Initialized
DEBUG - 2011-09-17 10:39:29 --> UTF-8 Support Enabled
DEBUG - 2011-09-17 10:39:29 --> URI Class Initialized
DEBUG - 2011-09-17 10:39:29 --> Router Class Initialized
DEBUG - 2011-09-17 10:39:29 --> Output Class Initialized
DEBUG - 2011-09-17 10:39:29 --> Input Class Initialized
DEBUG - 2011-09-17 10:39:29 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-17 10:39:29 --> Language Class Initialized
DEBUG - 2011-09-17 10:39:29 --> Loader Class Initialized
DEBUG - 2011-09-17 10:39:29 --> Controller Class Initialized
DEBUG - 2011-09-17 10:39:29 --> Model Class Initialized
DEBUG - 2011-09-17 10:39:29 --> Model Class Initialized
DEBUG - 2011-09-17 10:39:29 --> Model Class Initialized
DEBUG - 2011-09-17 10:39:29 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-17 10:39:29 --> Database Driver Class Initialized
DEBUG - 2011-09-17 10:39:30 --> File loaded: application/views/table/main.php
DEBUG - 2011-09-17 10:39:30 --> Helper loaded: url_helper
DEBUG - 2011-09-17 10:39:30 --> File loaded: application/views/common/header.php
DEBUG - 2011-09-17 10:39:30 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-09-17 10:39:30 --> File loaded: application/views/common/footer.php
DEBUG - 2011-09-17 10:39:30 --> File loaded: application/views/layout/main.php
DEBUG - 2011-09-17 10:39:30 --> Final output sent to browser
DEBUG - 2011-09-17 10:39:30 --> Total execution time: 0.9955
DEBUG - 2011-09-17 10:49:17 --> Config Class Initialized
DEBUG - 2011-09-17 10:49:17 --> Hooks Class Initialized
DEBUG - 2011-09-17 10:49:17 --> Utf8 Class Initialized
DEBUG - 2011-09-17 10:49:17 --> UTF-8 Support Enabled
DEBUG - 2011-09-17 10:49:17 --> URI Class Initialized
DEBUG - 2011-09-17 10:49:17 --> Router Class Initialized
DEBUG - 2011-09-17 10:49:17 --> Output Class Initialized
DEBUG - 2011-09-17 10:49:17 --> Input Class Initialized
DEBUG - 2011-09-17 10:49:17 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-17 10:49:17 --> Language Class Initialized
DEBUG - 2011-09-17 10:49:17 --> Loader Class Initialized
DEBUG - 2011-09-17 10:49:17 --> Controller Class Initialized
DEBUG - 2011-09-17 10:49:17 --> Model Class Initialized
DEBUG - 2011-09-17 10:49:17 --> Model Class Initialized
DEBUG - 2011-09-17 10:49:17 --> Model Class Initialized
DEBUG - 2011-09-17 10:49:17 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-17 10:49:17 --> Database Driver Class Initialized
DEBUG - 2011-09-17 10:49:17 --> File loaded: application/views/table/main.php
DEBUG - 2011-09-17 10:49:17 --> Helper loaded: url_helper
DEBUG - 2011-09-17 10:49:17 --> File loaded: application/views/common/header.php
DEBUG - 2011-09-17 10:49:17 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-09-17 10:49:17 --> File loaded: application/views/common/footer.php
DEBUG - 2011-09-17 10:49:17 --> File loaded: application/views/layout/main.php
DEBUG - 2011-09-17 10:49:17 --> Final output sent to browser
DEBUG - 2011-09-17 10:49:17 --> Total execution time: 0.0679
DEBUG - 2011-09-17 10:49:20 --> Config Class Initialized
DEBUG - 2011-09-17 10:49:20 --> Hooks Class Initialized
DEBUG - 2011-09-17 10:49:20 --> Utf8 Class Initialized
DEBUG - 2011-09-17 10:49:20 --> UTF-8 Support Enabled
DEBUG - 2011-09-17 10:49:20 --> URI Class Initialized
DEBUG - 2011-09-17 10:49:20 --> Router Class Initialized
ERROR - 2011-09-17 10:49:20 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-09-17 10:50:24 --> Config Class Initialized
DEBUG - 2011-09-17 10:50:24 --> Hooks Class Initialized
DEBUG - 2011-09-17 10:50:24 --> Utf8 Class Initialized
DEBUG - 2011-09-17 10:50:24 --> UTF-8 Support Enabled
DEBUG - 2011-09-17 10:50:24 --> URI Class Initialized
DEBUG - 2011-09-17 10:50:24 --> Router Class Initialized
DEBUG - 2011-09-17 10:50:24 --> Output Class Initialized
DEBUG - 2011-09-17 10:50:24 --> Input Class Initialized
DEBUG - 2011-09-17 10:50:24 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-17 10:50:24 --> Language Class Initialized
DEBUG - 2011-09-17 10:50:24 --> Loader Class Initialized
DEBUG - 2011-09-17 10:50:24 --> Controller Class Initialized
ERROR - 2011-09-17 10:50:24 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-09-17 10:50:24 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-09-17 10:50:24 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-09-17 10:50:24 --> Model Class Initialized
DEBUG - 2011-09-17 10:50:24 --> Model Class Initialized
DEBUG - 2011-09-17 10:50:24 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-17 10:50:24 --> Database Driver Class Initialized
DEBUG - 2011-09-17 10:50:24 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-09-17 10:50:24 --> Helper loaded: url_helper
DEBUG - 2011-09-17 10:50:24 --> File loaded: application/views/common/header.php
DEBUG - 2011-09-17 10:50:24 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-09-17 10:50:24 --> File loaded: application/views/common/footer.php
DEBUG - 2011-09-17 10:50:24 --> File loaded: application/views/layout/main.php
DEBUG - 2011-09-17 10:50:24 --> Final output sent to browser
DEBUG - 2011-09-17 10:50:24 --> Total execution time: 0.0336
DEBUG - 2011-09-17 10:50:26 --> Config Class Initialized
DEBUG - 2011-09-17 10:50:26 --> Hooks Class Initialized
DEBUG - 2011-09-17 10:50:26 --> Utf8 Class Initialized
DEBUG - 2011-09-17 10:50:26 --> UTF-8 Support Enabled
DEBUG - 2011-09-17 10:50:26 --> URI Class Initialized
DEBUG - 2011-09-17 10:50:26 --> Router Class Initialized
DEBUG - 2011-09-17 10:50:26 --> Output Class Initialized
DEBUG - 2011-09-17 10:50:26 --> Input Class Initialized
DEBUG - 2011-09-17 10:50:26 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-17 10:50:26 --> Language Class Initialized
DEBUG - 2011-09-17 10:50:26 --> Loader Class Initialized
DEBUG - 2011-09-17 10:50:26 --> Controller Class Initialized
DEBUG - 2011-09-17 10:50:26 --> Model Class Initialized
DEBUG - 2011-09-17 10:50:26 --> Model Class Initialized
DEBUG - 2011-09-17 10:50:26 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-17 10:50:26 --> Database Driver Class Initialized
DEBUG - 2011-09-17 10:50:27 --> Final output sent to browser
DEBUG - 2011-09-17 10:50:27 --> Total execution time: 1.0697
DEBUG - 2011-09-17 10:50:53 --> Config Class Initialized
DEBUG - 2011-09-17 10:50:53 --> Hooks Class Initialized
DEBUG - 2011-09-17 10:50:53 --> Utf8 Class Initialized
DEBUG - 2011-09-17 10:50:53 --> UTF-8 Support Enabled
DEBUG - 2011-09-17 10:50:53 --> URI Class Initialized
DEBUG - 2011-09-17 10:50:53 --> Router Class Initialized
DEBUG - 2011-09-17 10:50:53 --> Output Class Initialized
DEBUG - 2011-09-17 10:50:53 --> Input Class Initialized
DEBUG - 2011-09-17 10:50:53 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-17 10:50:53 --> Language Class Initialized
DEBUG - 2011-09-17 10:50:53 --> Loader Class Initialized
DEBUG - 2011-09-17 10:50:53 --> Controller Class Initialized
ERROR - 2011-09-17 10:50:53 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-09-17 10:50:53 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-09-17 10:50:53 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-09-17 10:50:53 --> Model Class Initialized
DEBUG - 2011-09-17 10:50:53 --> Model Class Initialized
DEBUG - 2011-09-17 10:50:53 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-17 10:50:53 --> Database Driver Class Initialized
DEBUG - 2011-09-17 10:50:53 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-09-17 10:50:53 --> Helper loaded: url_helper
DEBUG - 2011-09-17 10:50:53 --> File loaded: application/views/common/header.php
DEBUG - 2011-09-17 10:50:53 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-09-17 10:50:53 --> File loaded: application/views/common/footer.php
DEBUG - 2011-09-17 10:50:53 --> File loaded: application/views/layout/main.php
DEBUG - 2011-09-17 10:50:53 --> Final output sent to browser
DEBUG - 2011-09-17 10:50:53 --> Total execution time: 0.0366
DEBUG - 2011-09-17 10:50:54 --> Config Class Initialized
DEBUG - 2011-09-17 10:50:54 --> Hooks Class Initialized
DEBUG - 2011-09-17 10:50:54 --> Utf8 Class Initialized
DEBUG - 2011-09-17 10:50:54 --> UTF-8 Support Enabled
DEBUG - 2011-09-17 10:50:54 --> URI Class Initialized
DEBUG - 2011-09-17 10:50:54 --> Router Class Initialized
DEBUG - 2011-09-17 10:50:54 --> Output Class Initialized
DEBUG - 2011-09-17 10:50:54 --> Input Class Initialized
DEBUG - 2011-09-17 10:50:54 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-17 10:50:54 --> Language Class Initialized
DEBUG - 2011-09-17 10:50:54 --> Loader Class Initialized
DEBUG - 2011-09-17 10:50:54 --> Controller Class Initialized
DEBUG - 2011-09-17 10:50:54 --> Model Class Initialized
DEBUG - 2011-09-17 10:50:54 --> Model Class Initialized
DEBUG - 2011-09-17 10:50:54 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-17 10:50:54 --> Database Driver Class Initialized
DEBUG - 2011-09-17 10:50:54 --> Final output sent to browser
DEBUG - 2011-09-17 10:50:54 --> Total execution time: 0.5066
DEBUG - 2011-09-17 10:51:16 --> Config Class Initialized
DEBUG - 2011-09-17 10:51:16 --> Hooks Class Initialized
DEBUG - 2011-09-17 10:51:16 --> Utf8 Class Initialized
DEBUG - 2011-09-17 10:51:16 --> UTF-8 Support Enabled
DEBUG - 2011-09-17 10:51:16 --> URI Class Initialized
DEBUG - 2011-09-17 10:51:16 --> Router Class Initialized
DEBUG - 2011-09-17 10:51:16 --> Output Class Initialized
DEBUG - 2011-09-17 10:51:16 --> Input Class Initialized
DEBUG - 2011-09-17 10:51:16 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-17 10:51:16 --> Language Class Initialized
DEBUG - 2011-09-17 10:51:16 --> Loader Class Initialized
DEBUG - 2011-09-17 10:51:16 --> Controller Class Initialized
ERROR - 2011-09-17 10:51:16 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-09-17 10:51:16 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-09-17 10:51:16 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-09-17 10:51:16 --> Model Class Initialized
DEBUG - 2011-09-17 10:51:16 --> Model Class Initialized
DEBUG - 2011-09-17 10:51:16 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-17 10:51:16 --> Database Driver Class Initialized
DEBUG - 2011-09-17 10:51:16 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-09-17 10:51:16 --> Helper loaded: url_helper
DEBUG - 2011-09-17 10:51:16 --> File loaded: application/views/common/header.php
DEBUG - 2011-09-17 10:51:16 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-09-17 10:51:16 --> File loaded: application/views/common/footer.php
DEBUG - 2011-09-17 10:51:16 --> File loaded: application/views/layout/main.php
DEBUG - 2011-09-17 10:51:16 --> Final output sent to browser
DEBUG - 2011-09-17 10:51:16 --> Total execution time: 0.0309
DEBUG - 2011-09-17 10:51:17 --> Config Class Initialized
DEBUG - 2011-09-17 10:51:17 --> Hooks Class Initialized
DEBUG - 2011-09-17 10:51:17 --> Utf8 Class Initialized
DEBUG - 2011-09-17 10:51:17 --> UTF-8 Support Enabled
DEBUG - 2011-09-17 10:51:17 --> URI Class Initialized
DEBUG - 2011-09-17 10:51:17 --> Router Class Initialized
DEBUG - 2011-09-17 10:51:17 --> Output Class Initialized
DEBUG - 2011-09-17 10:51:17 --> Input Class Initialized
DEBUG - 2011-09-17 10:51:17 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-17 10:51:17 --> Language Class Initialized
DEBUG - 2011-09-17 10:51:17 --> Loader Class Initialized
DEBUG - 2011-09-17 10:51:17 --> Controller Class Initialized
DEBUG - 2011-09-17 10:51:17 --> Model Class Initialized
DEBUG - 2011-09-17 10:51:17 --> Model Class Initialized
DEBUG - 2011-09-17 10:51:17 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-17 10:51:17 --> Database Driver Class Initialized
DEBUG - 2011-09-17 10:51:17 --> Final output sent to browser
DEBUG - 2011-09-17 10:51:17 --> Total execution time: 0.5069
DEBUG - 2011-09-17 10:59:03 --> Config Class Initialized
DEBUG - 2011-09-17 10:59:03 --> Hooks Class Initialized
DEBUG - 2011-09-17 10:59:03 --> Utf8 Class Initialized
DEBUG - 2011-09-17 10:59:03 --> UTF-8 Support Enabled
DEBUG - 2011-09-17 10:59:03 --> URI Class Initialized
DEBUG - 2011-09-17 10:59:03 --> Router Class Initialized
DEBUG - 2011-09-17 10:59:03 --> Output Class Initialized
DEBUG - 2011-09-17 10:59:03 --> Input Class Initialized
DEBUG - 2011-09-17 10:59:03 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-17 10:59:03 --> Language Class Initialized
DEBUG - 2011-09-17 10:59:03 --> Loader Class Initialized
DEBUG - 2011-09-17 10:59:03 --> Controller Class Initialized
DEBUG - 2011-09-17 10:59:03 --> Model Class Initialized
DEBUG - 2011-09-17 10:59:03 --> Model Class Initialized
DEBUG - 2011-09-17 10:59:03 --> Model Class Initialized
DEBUG - 2011-09-17 10:59:03 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-17 10:59:03 --> Database Driver Class Initialized
DEBUG - 2011-09-17 10:59:03 --> File loaded: application/views/table/main.php
DEBUG - 2011-09-17 10:59:03 --> Helper loaded: url_helper
DEBUG - 2011-09-17 10:59:03 --> File loaded: application/views/common/header.php
DEBUG - 2011-09-17 10:59:03 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-09-17 10:59:03 --> File loaded: application/views/common/footer.php
DEBUG - 2011-09-17 10:59:03 --> File loaded: application/views/layout/main.php
DEBUG - 2011-09-17 10:59:03 --> Final output sent to browser
DEBUG - 2011-09-17 10:59:03 --> Total execution time: 0.0965
DEBUG - 2011-09-17 10:59:04 --> Config Class Initialized
DEBUG - 2011-09-17 10:59:04 --> Hooks Class Initialized
DEBUG - 2011-09-17 10:59:04 --> Utf8 Class Initialized
DEBUG - 2011-09-17 10:59:04 --> UTF-8 Support Enabled
DEBUG - 2011-09-17 10:59:04 --> URI Class Initialized
DEBUG - 2011-09-17 10:59:04 --> Router Class Initialized
DEBUG - 2011-09-17 10:59:04 --> Output Class Initialized
DEBUG - 2011-09-17 10:59:04 --> Input Class Initialized
DEBUG - 2011-09-17 10:59:04 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-17 10:59:04 --> Language Class Initialized
DEBUG - 2011-09-17 10:59:04 --> Loader Class Initialized
DEBUG - 2011-09-17 10:59:04 --> Controller Class Initialized
ERROR - 2011-09-17 10:59:04 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-09-17 10:59:04 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-09-17 10:59:04 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-09-17 10:59:04 --> Model Class Initialized
DEBUG - 2011-09-17 10:59:04 --> Model Class Initialized
DEBUG - 2011-09-17 10:59:04 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-17 10:59:04 --> Database Driver Class Initialized
DEBUG - 2011-09-17 10:59:04 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-09-17 10:59:04 --> Helper loaded: url_helper
DEBUG - 2011-09-17 10:59:04 --> File loaded: application/views/common/header.php
DEBUG - 2011-09-17 10:59:04 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-09-17 10:59:04 --> File loaded: application/views/common/footer.php
DEBUG - 2011-09-17 10:59:04 --> File loaded: application/views/layout/main.php
DEBUG - 2011-09-17 10:59:04 --> Final output sent to browser
DEBUG - 2011-09-17 10:59:04 --> Total execution time: 0.0311
DEBUG - 2011-09-17 11:14:45 --> Config Class Initialized
DEBUG - 2011-09-17 11:14:45 --> Hooks Class Initialized
DEBUG - 2011-09-17 11:14:45 --> Utf8 Class Initialized
DEBUG - 2011-09-17 11:14:45 --> UTF-8 Support Enabled
DEBUG - 2011-09-17 11:14:45 --> URI Class Initialized
DEBUG - 2011-09-17 11:14:45 --> Router Class Initialized
DEBUG - 2011-09-17 11:14:45 --> Output Class Initialized
DEBUG - 2011-09-17 11:14:45 --> Input Class Initialized
DEBUG - 2011-09-17 11:14:45 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-17 11:14:45 --> Language Class Initialized
DEBUG - 2011-09-17 11:14:45 --> Loader Class Initialized
DEBUG - 2011-09-17 11:14:45 --> Controller Class Initialized
ERROR - 2011-09-17 11:14:45 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-09-17 11:14:45 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-09-17 11:14:45 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-09-17 11:14:45 --> Model Class Initialized
DEBUG - 2011-09-17 11:14:45 --> Model Class Initialized
DEBUG - 2011-09-17 11:14:45 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-17 11:14:45 --> Database Driver Class Initialized
DEBUG - 2011-09-17 11:14:45 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-09-17 11:14:45 --> Helper loaded: url_helper
DEBUG - 2011-09-17 11:14:45 --> File loaded: application/views/common/header.php
DEBUG - 2011-09-17 11:14:45 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-09-17 11:14:45 --> File loaded: application/views/common/footer.php
DEBUG - 2011-09-17 11:14:45 --> File loaded: application/views/layout/main.php
DEBUG - 2011-09-17 11:14:45 --> Final output sent to browser
DEBUG - 2011-09-17 11:14:45 --> Total execution time: 0.0306
DEBUG - 2011-09-17 11:14:47 --> Config Class Initialized
DEBUG - 2011-09-17 11:14:47 --> Hooks Class Initialized
DEBUG - 2011-09-17 11:14:47 --> Utf8 Class Initialized
DEBUG - 2011-09-17 11:14:47 --> UTF-8 Support Enabled
DEBUG - 2011-09-17 11:14:47 --> URI Class Initialized
DEBUG - 2011-09-17 11:14:47 --> Router Class Initialized
DEBUG - 2011-09-17 11:14:47 --> Output Class Initialized
DEBUG - 2011-09-17 11:14:47 --> Input Class Initialized
DEBUG - 2011-09-17 11:14:47 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-17 11:14:47 --> Language Class Initialized
DEBUG - 2011-09-17 11:14:47 --> Loader Class Initialized
DEBUG - 2011-09-17 11:14:47 --> Controller Class Initialized
DEBUG - 2011-09-17 11:14:47 --> Model Class Initialized
DEBUG - 2011-09-17 11:14:47 --> Model Class Initialized
DEBUG - 2011-09-17 11:14:47 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-17 11:14:47 --> Database Driver Class Initialized
DEBUG - 2011-09-17 11:14:48 --> Final output sent to browser
DEBUG - 2011-09-17 11:14:48 --> Total execution time: 1.1604
DEBUG - 2011-09-17 11:14:49 --> Config Class Initialized
DEBUG - 2011-09-17 11:14:49 --> Hooks Class Initialized
DEBUG - 2011-09-17 11:14:49 --> Utf8 Class Initialized
DEBUG - 2011-09-17 11:14:49 --> UTF-8 Support Enabled
DEBUG - 2011-09-17 11:14:49 --> URI Class Initialized
DEBUG - 2011-09-17 11:14:49 --> Router Class Initialized
ERROR - 2011-09-17 11:14:49 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-09-17 11:14:55 --> Config Class Initialized
DEBUG - 2011-09-17 11:14:55 --> Hooks Class Initialized
DEBUG - 2011-09-17 11:14:55 --> Utf8 Class Initialized
DEBUG - 2011-09-17 11:14:55 --> UTF-8 Support Enabled
DEBUG - 2011-09-17 11:14:55 --> URI Class Initialized
DEBUG - 2011-09-17 11:14:55 --> Router Class Initialized
DEBUG - 2011-09-17 11:14:55 --> Output Class Initialized
DEBUG - 2011-09-17 11:14:55 --> Input Class Initialized
DEBUG - 2011-09-17 11:14:55 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-17 11:14:55 --> Language Class Initialized
DEBUG - 2011-09-17 11:14:55 --> Loader Class Initialized
DEBUG - 2011-09-17 11:14:55 --> Controller Class Initialized
ERROR - 2011-09-17 11:14:55 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-09-17 11:14:55 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-09-17 11:14:55 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-09-17 11:14:55 --> Model Class Initialized
DEBUG - 2011-09-17 11:14:55 --> Model Class Initialized
DEBUG - 2011-09-17 11:14:55 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-17 11:14:55 --> Database Driver Class Initialized
DEBUG - 2011-09-17 11:14:55 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-09-17 11:14:55 --> Helper loaded: url_helper
DEBUG - 2011-09-17 11:14:55 --> File loaded: application/views/common/header.php
DEBUG - 2011-09-17 11:14:55 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-09-17 11:14:55 --> File loaded: application/views/common/footer.php
DEBUG - 2011-09-17 11:14:55 --> File loaded: application/views/layout/main.php
DEBUG - 2011-09-17 11:14:55 --> Final output sent to browser
DEBUG - 2011-09-17 11:14:55 --> Total execution time: 0.0307
DEBUG - 2011-09-17 11:14:56 --> Config Class Initialized
DEBUG - 2011-09-17 11:14:56 --> Hooks Class Initialized
DEBUG - 2011-09-17 11:14:56 --> Utf8 Class Initialized
DEBUG - 2011-09-17 11:14:56 --> UTF-8 Support Enabled
DEBUG - 2011-09-17 11:14:56 --> URI Class Initialized
DEBUG - 2011-09-17 11:14:56 --> Router Class Initialized
DEBUG - 2011-09-17 11:14:56 --> Output Class Initialized
DEBUG - 2011-09-17 11:14:56 --> Input Class Initialized
DEBUG - 2011-09-17 11:14:56 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-17 11:14:56 --> Language Class Initialized
DEBUG - 2011-09-17 11:14:56 --> Loader Class Initialized
DEBUG - 2011-09-17 11:14:56 --> Controller Class Initialized
DEBUG - 2011-09-17 11:14:56 --> Model Class Initialized
DEBUG - 2011-09-17 11:14:56 --> Model Class Initialized
DEBUG - 2011-09-17 11:14:56 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-17 11:14:56 --> Database Driver Class Initialized
DEBUG - 2011-09-17 11:14:56 --> Final output sent to browser
DEBUG - 2011-09-17 11:14:56 --> Total execution time: 0.5981
DEBUG - 2011-09-17 11:14:57 --> Config Class Initialized
DEBUG - 2011-09-17 11:14:57 --> Hooks Class Initialized
DEBUG - 2011-09-17 11:14:57 --> Utf8 Class Initialized
DEBUG - 2011-09-17 11:14:57 --> UTF-8 Support Enabled
DEBUG - 2011-09-17 11:14:57 --> URI Class Initialized
DEBUG - 2011-09-17 11:14:57 --> Router Class Initialized
ERROR - 2011-09-17 11:14:57 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-09-17 11:15:17 --> Config Class Initialized
DEBUG - 2011-09-17 11:15:17 --> Hooks Class Initialized
DEBUG - 2011-09-17 11:15:17 --> Utf8 Class Initialized
DEBUG - 2011-09-17 11:15:17 --> UTF-8 Support Enabled
DEBUG - 2011-09-17 11:15:17 --> URI Class Initialized
DEBUG - 2011-09-17 11:15:17 --> Router Class Initialized
DEBUG - 2011-09-17 11:15:17 --> Output Class Initialized
DEBUG - 2011-09-17 11:15:17 --> Input Class Initialized
DEBUG - 2011-09-17 11:15:17 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-17 11:15:17 --> Language Class Initialized
DEBUG - 2011-09-17 11:15:17 --> Loader Class Initialized
DEBUG - 2011-09-17 11:15:17 --> Controller Class Initialized
ERROR - 2011-09-17 11:15:17 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-09-17 11:15:17 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-09-17 11:15:17 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-09-17 11:15:17 --> Model Class Initialized
DEBUG - 2011-09-17 11:15:17 --> Model Class Initialized
DEBUG - 2011-09-17 11:15:17 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-17 11:15:17 --> Database Driver Class Initialized
DEBUG - 2011-09-17 11:15:17 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-09-17 11:15:17 --> Helper loaded: url_helper
DEBUG - 2011-09-17 11:15:17 --> File loaded: application/views/common/header.php
DEBUG - 2011-09-17 11:15:17 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-09-17 11:15:17 --> File loaded: application/views/common/footer.php
DEBUG - 2011-09-17 11:15:17 --> File loaded: application/views/layout/main.php
DEBUG - 2011-09-17 11:15:17 --> Final output sent to browser
DEBUG - 2011-09-17 11:15:17 --> Total execution time: 0.0614
DEBUG - 2011-09-17 11:15:17 --> Config Class Initialized
DEBUG - 2011-09-17 11:15:17 --> Hooks Class Initialized
DEBUG - 2011-09-17 11:15:17 --> Utf8 Class Initialized
DEBUG - 2011-09-17 11:15:17 --> UTF-8 Support Enabled
DEBUG - 2011-09-17 11:15:17 --> URI Class Initialized
DEBUG - 2011-09-17 11:15:17 --> Router Class Initialized
DEBUG - 2011-09-17 11:15:17 --> Output Class Initialized
DEBUG - 2011-09-17 11:15:17 --> Input Class Initialized
DEBUG - 2011-09-17 11:15:17 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-17 11:15:17 --> Language Class Initialized
DEBUG - 2011-09-17 11:15:17 --> Loader Class Initialized
DEBUG - 2011-09-17 11:15:17 --> Controller Class Initialized
DEBUG - 2011-09-17 11:15:17 --> Model Class Initialized
DEBUG - 2011-09-17 11:15:17 --> Model Class Initialized
DEBUG - 2011-09-17 11:15:17 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-17 11:15:17 --> Database Driver Class Initialized
DEBUG - 2011-09-17 11:15:18 --> Final output sent to browser
DEBUG - 2011-09-17 11:15:18 --> Total execution time: 0.8073
DEBUG - 2011-09-17 11:15:19 --> Config Class Initialized
DEBUG - 2011-09-17 11:15:19 --> Hooks Class Initialized
DEBUG - 2011-09-17 11:15:19 --> Utf8 Class Initialized
DEBUG - 2011-09-17 11:15:19 --> UTF-8 Support Enabled
DEBUG - 2011-09-17 11:15:19 --> URI Class Initialized
DEBUG - 2011-09-17 11:15:19 --> Router Class Initialized
ERROR - 2011-09-17 11:15:19 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-09-17 11:15:32 --> Config Class Initialized
DEBUG - 2011-09-17 11:15:32 --> Hooks Class Initialized
DEBUG - 2011-09-17 11:15:32 --> Utf8 Class Initialized
DEBUG - 2011-09-17 11:15:32 --> UTF-8 Support Enabled
DEBUG - 2011-09-17 11:15:32 --> URI Class Initialized
DEBUG - 2011-09-17 11:15:32 --> Router Class Initialized
DEBUG - 2011-09-17 11:15:32 --> Output Class Initialized
DEBUG - 2011-09-17 11:15:32 --> Input Class Initialized
DEBUG - 2011-09-17 11:15:32 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-17 11:15:32 --> Language Class Initialized
DEBUG - 2011-09-17 11:15:32 --> Loader Class Initialized
DEBUG - 2011-09-17 11:15:32 --> Controller Class Initialized
ERROR - 2011-09-17 11:15:32 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-09-17 11:15:32 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-09-17 11:15:32 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-09-17 11:15:32 --> Model Class Initialized
DEBUG - 2011-09-17 11:15:32 --> Model Class Initialized
DEBUG - 2011-09-17 11:15:32 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-17 11:15:32 --> Database Driver Class Initialized
DEBUG - 2011-09-17 11:15:32 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-09-17 11:15:32 --> Helper loaded: url_helper
DEBUG - 2011-09-17 11:15:32 --> File loaded: application/views/common/header.php
DEBUG - 2011-09-17 11:15:32 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-09-17 11:15:32 --> File loaded: application/views/common/footer.php
DEBUG - 2011-09-17 11:15:32 --> File loaded: application/views/layout/main.php
DEBUG - 2011-09-17 11:15:32 --> Final output sent to browser
DEBUG - 2011-09-17 11:15:32 --> Total execution time: 0.0291
DEBUG - 2011-09-17 11:15:32 --> Config Class Initialized
DEBUG - 2011-09-17 11:15:32 --> Hooks Class Initialized
DEBUG - 2011-09-17 11:15:32 --> Utf8 Class Initialized
DEBUG - 2011-09-17 11:15:32 --> UTF-8 Support Enabled
DEBUG - 2011-09-17 11:15:32 --> URI Class Initialized
DEBUG - 2011-09-17 11:15:32 --> Router Class Initialized
DEBUG - 2011-09-17 11:15:32 --> Output Class Initialized
DEBUG - 2011-09-17 11:15:32 --> Input Class Initialized
DEBUG - 2011-09-17 11:15:32 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-17 11:15:32 --> Language Class Initialized
DEBUG - 2011-09-17 11:15:32 --> Loader Class Initialized
DEBUG - 2011-09-17 11:15:32 --> Controller Class Initialized
DEBUG - 2011-09-17 11:15:32 --> Model Class Initialized
DEBUG - 2011-09-17 11:15:32 --> Model Class Initialized
DEBUG - 2011-09-17 11:15:32 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-17 11:15:32 --> Database Driver Class Initialized
DEBUG - 2011-09-17 11:15:34 --> Final output sent to browser
DEBUG - 2011-09-17 11:15:34 --> Total execution time: 1.4256
DEBUG - 2011-09-17 11:15:34 --> Config Class Initialized
DEBUG - 2011-09-17 11:15:34 --> Hooks Class Initialized
DEBUG - 2011-09-17 11:15:34 --> Utf8 Class Initialized
DEBUG - 2011-09-17 11:15:34 --> UTF-8 Support Enabled
DEBUG - 2011-09-17 11:15:34 --> URI Class Initialized
DEBUG - 2011-09-17 11:15:34 --> Router Class Initialized
ERROR - 2011-09-17 11:15:34 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-09-17 11:15:47 --> Config Class Initialized
DEBUG - 2011-09-17 11:15:47 --> Hooks Class Initialized
DEBUG - 2011-09-17 11:15:47 --> Utf8 Class Initialized
DEBUG - 2011-09-17 11:15:47 --> UTF-8 Support Enabled
DEBUG - 2011-09-17 11:15:47 --> URI Class Initialized
DEBUG - 2011-09-17 11:15:47 --> Router Class Initialized
DEBUG - 2011-09-17 11:15:47 --> Output Class Initialized
DEBUG - 2011-09-17 11:15:47 --> Input Class Initialized
DEBUG - 2011-09-17 11:15:47 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-17 11:15:47 --> Language Class Initialized
DEBUG - 2011-09-17 11:15:47 --> Loader Class Initialized
DEBUG - 2011-09-17 11:15:47 --> Controller Class Initialized
ERROR - 2011-09-17 11:15:47 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-09-17 11:15:47 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-09-17 11:15:47 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-09-17 11:15:47 --> Model Class Initialized
DEBUG - 2011-09-17 11:15:47 --> Model Class Initialized
DEBUG - 2011-09-17 11:15:47 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-17 11:15:47 --> Database Driver Class Initialized
DEBUG - 2011-09-17 11:15:47 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-09-17 11:15:47 --> Helper loaded: url_helper
DEBUG - 2011-09-17 11:15:47 --> File loaded: application/views/common/header.php
DEBUG - 2011-09-17 11:15:47 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-09-17 11:15:47 --> File loaded: application/views/common/footer.php
DEBUG - 2011-09-17 11:15:47 --> File loaded: application/views/layout/main.php
DEBUG - 2011-09-17 11:15:47 --> Final output sent to browser
DEBUG - 2011-09-17 11:15:47 --> Total execution time: 0.0298
DEBUG - 2011-09-17 11:15:47 --> Config Class Initialized
DEBUG - 2011-09-17 11:15:47 --> Hooks Class Initialized
DEBUG - 2011-09-17 11:15:47 --> Utf8 Class Initialized
DEBUG - 2011-09-17 11:15:47 --> UTF-8 Support Enabled
DEBUG - 2011-09-17 11:15:47 --> URI Class Initialized
DEBUG - 2011-09-17 11:15:47 --> Router Class Initialized
DEBUG - 2011-09-17 11:15:47 --> Output Class Initialized
DEBUG - 2011-09-17 11:15:47 --> Input Class Initialized
DEBUG - 2011-09-17 11:15:47 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-17 11:15:47 --> Language Class Initialized
DEBUG - 2011-09-17 11:15:47 --> Loader Class Initialized
DEBUG - 2011-09-17 11:15:47 --> Controller Class Initialized
DEBUG - 2011-09-17 11:15:47 --> Model Class Initialized
DEBUG - 2011-09-17 11:15:47 --> Model Class Initialized
DEBUG - 2011-09-17 11:15:47 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-17 11:15:47 --> Database Driver Class Initialized
DEBUG - 2011-09-17 11:15:48 --> Config Class Initialized
DEBUG - 2011-09-17 11:15:48 --> Hooks Class Initialized
DEBUG - 2011-09-17 11:15:48 --> Utf8 Class Initialized
DEBUG - 2011-09-17 11:15:48 --> UTF-8 Support Enabled
DEBUG - 2011-09-17 11:15:48 --> URI Class Initialized
DEBUG - 2011-09-17 11:15:48 --> Router Class Initialized
DEBUG - 2011-09-17 11:15:48 --> Output Class Initialized
DEBUG - 2011-09-17 11:15:48 --> Input Class Initialized
DEBUG - 2011-09-17 11:15:48 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-17 11:15:48 --> Language Class Initialized
DEBUG - 2011-09-17 11:15:48 --> Loader Class Initialized
DEBUG - 2011-09-17 11:15:48 --> Controller Class Initialized
ERROR - 2011-09-17 11:15:48 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-09-17 11:15:48 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-09-17 11:15:48 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-09-17 11:15:48 --> Model Class Initialized
DEBUG - 2011-09-17 11:15:48 --> Model Class Initialized
DEBUG - 2011-09-17 11:15:48 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-17 11:15:48 --> Database Driver Class Initialized
DEBUG - 2011-09-17 11:15:48 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-09-17 11:15:48 --> Helper loaded: url_helper
DEBUG - 2011-09-17 11:15:48 --> File loaded: application/views/common/header.php
DEBUG - 2011-09-17 11:15:48 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-09-17 11:15:48 --> File loaded: application/views/common/footer.php
DEBUG - 2011-09-17 11:15:48 --> File loaded: application/views/layout/main.php
DEBUG - 2011-09-17 11:15:48 --> Final output sent to browser
DEBUG - 2011-09-17 11:15:48 --> Total execution time: 0.0306
DEBUG - 2011-09-17 11:15:48 --> Final output sent to browser
DEBUG - 2011-09-17 11:15:48 --> Total execution time: 0.7024
DEBUG - 2011-09-17 11:15:49 --> Config Class Initialized
DEBUG - 2011-09-17 11:15:49 --> Hooks Class Initialized
DEBUG - 2011-09-17 11:15:49 --> Utf8 Class Initialized
DEBUG - 2011-09-17 11:15:49 --> UTF-8 Support Enabled
DEBUG - 2011-09-17 11:15:49 --> URI Class Initialized
DEBUG - 2011-09-17 11:15:49 --> Router Class Initialized
ERROR - 2011-09-17 11:15:49 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-09-17 11:15:57 --> Config Class Initialized
DEBUG - 2011-09-17 11:15:57 --> Hooks Class Initialized
DEBUG - 2011-09-17 11:15:57 --> Utf8 Class Initialized
DEBUG - 2011-09-17 11:15:57 --> UTF-8 Support Enabled
DEBUG - 2011-09-17 11:15:57 --> URI Class Initialized
DEBUG - 2011-09-17 11:15:57 --> Router Class Initialized
DEBUG - 2011-09-17 11:15:57 --> Output Class Initialized
DEBUG - 2011-09-17 11:15:57 --> Input Class Initialized
DEBUG - 2011-09-17 11:15:57 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-17 11:15:57 --> Language Class Initialized
DEBUG - 2011-09-17 11:15:57 --> Loader Class Initialized
DEBUG - 2011-09-17 11:15:57 --> Controller Class Initialized
ERROR - 2011-09-17 11:15:57 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-09-17 11:15:57 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-09-17 11:15:57 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-09-17 11:15:57 --> Model Class Initialized
DEBUG - 2011-09-17 11:15:57 --> Model Class Initialized
DEBUG - 2011-09-17 11:15:57 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-17 11:15:57 --> Database Driver Class Initialized
DEBUG - 2011-09-17 11:15:57 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-09-17 11:15:57 --> Helper loaded: url_helper
DEBUG - 2011-09-17 11:15:57 --> File loaded: application/views/common/header.php
DEBUG - 2011-09-17 11:15:57 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-09-17 11:15:57 --> File loaded: application/views/common/footer.php
DEBUG - 2011-09-17 11:15:57 --> File loaded: application/views/layout/main.php
DEBUG - 2011-09-17 11:15:57 --> Final output sent to browser
DEBUG - 2011-09-17 11:15:57 --> Total execution time: 0.0330
DEBUG - 2011-09-17 11:15:58 --> Config Class Initialized
DEBUG - 2011-09-17 11:15:58 --> Hooks Class Initialized
DEBUG - 2011-09-17 11:15:58 --> Utf8 Class Initialized
DEBUG - 2011-09-17 11:15:58 --> UTF-8 Support Enabled
DEBUG - 2011-09-17 11:15:58 --> URI Class Initialized
DEBUG - 2011-09-17 11:15:58 --> Router Class Initialized
DEBUG - 2011-09-17 11:15:58 --> Output Class Initialized
DEBUG - 2011-09-17 11:15:58 --> Input Class Initialized
DEBUG - 2011-09-17 11:15:58 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-17 11:15:58 --> Language Class Initialized
DEBUG - 2011-09-17 11:15:58 --> Loader Class Initialized
DEBUG - 2011-09-17 11:15:58 --> Controller Class Initialized
DEBUG - 2011-09-17 11:15:58 --> Model Class Initialized
DEBUG - 2011-09-17 11:15:58 --> Model Class Initialized
DEBUG - 2011-09-17 11:15:58 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-17 11:15:58 --> Database Driver Class Initialized
DEBUG - 2011-09-17 11:15:58 --> Final output sent to browser
DEBUG - 2011-09-17 11:15:58 --> Total execution time: 0.5533
DEBUG - 2011-09-17 11:15:59 --> Config Class Initialized
DEBUG - 2011-09-17 11:15:59 --> Hooks Class Initialized
DEBUG - 2011-09-17 11:15:59 --> Utf8 Class Initialized
DEBUG - 2011-09-17 11:15:59 --> UTF-8 Support Enabled
DEBUG - 2011-09-17 11:15:59 --> URI Class Initialized
DEBUG - 2011-09-17 11:15:59 --> Router Class Initialized
ERROR - 2011-09-17 11:15:59 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-09-17 11:16:06 --> Config Class Initialized
DEBUG - 2011-09-17 11:16:06 --> Hooks Class Initialized
DEBUG - 2011-09-17 11:16:06 --> Utf8 Class Initialized
DEBUG - 2011-09-17 11:16:06 --> UTF-8 Support Enabled
DEBUG - 2011-09-17 11:16:06 --> URI Class Initialized
DEBUG - 2011-09-17 11:16:06 --> Router Class Initialized
DEBUG - 2011-09-17 11:16:06 --> Output Class Initialized
DEBUG - 2011-09-17 11:16:06 --> Input Class Initialized
DEBUG - 2011-09-17 11:16:06 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-17 11:16:06 --> Language Class Initialized
DEBUG - 2011-09-17 11:16:06 --> Loader Class Initialized
DEBUG - 2011-09-17 11:16:06 --> Controller Class Initialized
ERROR - 2011-09-17 11:16:06 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-09-17 11:16:06 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-09-17 11:16:06 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-09-17 11:16:06 --> Model Class Initialized
DEBUG - 2011-09-17 11:16:06 --> Model Class Initialized
DEBUG - 2011-09-17 11:16:06 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-17 11:16:06 --> Database Driver Class Initialized
DEBUG - 2011-09-17 11:16:06 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-09-17 11:16:06 --> Helper loaded: url_helper
DEBUG - 2011-09-17 11:16:06 --> File loaded: application/views/common/header.php
DEBUG - 2011-09-17 11:16:06 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-09-17 11:16:06 --> File loaded: application/views/common/footer.php
DEBUG - 2011-09-17 11:16:07 --> File loaded: application/views/layout/main.php
DEBUG - 2011-09-17 11:16:07 --> Final output sent to browser
DEBUG - 2011-09-17 11:16:07 --> Total execution time: 0.0587
DEBUG - 2011-09-17 11:16:07 --> Config Class Initialized
DEBUG - 2011-09-17 11:16:07 --> Hooks Class Initialized
DEBUG - 2011-09-17 11:16:07 --> Utf8 Class Initialized
DEBUG - 2011-09-17 11:16:07 --> UTF-8 Support Enabled
DEBUG - 2011-09-17 11:16:07 --> URI Class Initialized
DEBUG - 2011-09-17 11:16:07 --> Router Class Initialized
DEBUG - 2011-09-17 11:16:07 --> Output Class Initialized
DEBUG - 2011-09-17 11:16:07 --> Input Class Initialized
DEBUG - 2011-09-17 11:16:07 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-17 11:16:07 --> Language Class Initialized
DEBUG - 2011-09-17 11:16:07 --> Loader Class Initialized
DEBUG - 2011-09-17 11:16:07 --> Controller Class Initialized
DEBUG - 2011-09-17 11:16:07 --> Model Class Initialized
DEBUG - 2011-09-17 11:16:07 --> Model Class Initialized
DEBUG - 2011-09-17 11:16:07 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-17 11:16:07 --> Database Driver Class Initialized
DEBUG - 2011-09-17 11:16:08 --> Config Class Initialized
DEBUG - 2011-09-17 11:16:08 --> Hooks Class Initialized
DEBUG - 2011-09-17 11:16:08 --> Utf8 Class Initialized
DEBUG - 2011-09-17 11:16:08 --> UTF-8 Support Enabled
DEBUG - 2011-09-17 11:16:08 --> URI Class Initialized
DEBUG - 2011-09-17 11:16:08 --> Router Class Initialized
DEBUG - 2011-09-17 11:16:08 --> Output Class Initialized
DEBUG - 2011-09-17 11:16:08 --> Final output sent to browser
DEBUG - 2011-09-17 11:16:08 --> Total execution time: 0.5458
DEBUG - 2011-09-17 11:16:08 --> Input Class Initialized
DEBUG - 2011-09-17 11:16:08 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-17 11:16:08 --> Language Class Initialized
DEBUG - 2011-09-17 11:16:08 --> Loader Class Initialized
DEBUG - 2011-09-17 11:16:08 --> Controller Class Initialized
ERROR - 2011-09-17 11:16:08 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-09-17 11:16:08 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-09-17 11:16:08 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-09-17 11:16:08 --> Model Class Initialized
DEBUG - 2011-09-17 11:16:08 --> Model Class Initialized
DEBUG - 2011-09-17 11:16:08 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-17 11:16:08 --> Database Driver Class Initialized
DEBUG - 2011-09-17 11:16:08 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-09-17 11:16:08 --> Helper loaded: url_helper
DEBUG - 2011-09-17 11:16:08 --> File loaded: application/views/common/header.php
DEBUG - 2011-09-17 11:16:08 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-09-17 11:16:08 --> File loaded: application/views/common/footer.php
DEBUG - 2011-09-17 11:16:08 --> File loaded: application/views/layout/main.php
DEBUG - 2011-09-17 11:16:08 --> Final output sent to browser
DEBUG - 2011-09-17 11:16:08 --> Total execution time: 0.1055
DEBUG - 2011-09-17 11:16:08 --> Config Class Initialized
DEBUG - 2011-09-17 11:16:08 --> Hooks Class Initialized
DEBUG - 2011-09-17 11:16:08 --> Utf8 Class Initialized
DEBUG - 2011-09-17 11:16:08 --> UTF-8 Support Enabled
DEBUG - 2011-09-17 11:16:08 --> URI Class Initialized
DEBUG - 2011-09-17 11:16:08 --> Router Class Initialized
ERROR - 2011-09-17 11:16:08 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-09-17 11:16:13 --> Config Class Initialized
DEBUG - 2011-09-17 11:16:13 --> Hooks Class Initialized
DEBUG - 2011-09-17 11:16:13 --> Utf8 Class Initialized
DEBUG - 2011-09-17 11:16:13 --> UTF-8 Support Enabled
DEBUG - 2011-09-17 11:16:13 --> URI Class Initialized
DEBUG - 2011-09-17 11:16:13 --> Router Class Initialized
DEBUG - 2011-09-17 11:16:13 --> Output Class Initialized
DEBUG - 2011-09-17 11:16:13 --> Input Class Initialized
DEBUG - 2011-09-17 11:16:13 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-17 11:16:13 --> Language Class Initialized
DEBUG - 2011-09-17 11:16:13 --> Loader Class Initialized
DEBUG - 2011-09-17 11:16:13 --> Controller Class Initialized
ERROR - 2011-09-17 11:16:13 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-09-17 11:16:13 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-09-17 11:16:13 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-09-17 11:16:13 --> Model Class Initialized
DEBUG - 2011-09-17 11:16:13 --> Model Class Initialized
DEBUG - 2011-09-17 11:16:13 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-17 11:16:13 --> Database Driver Class Initialized
DEBUG - 2011-09-17 11:16:13 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-09-17 11:16:13 --> Helper loaded: url_helper
DEBUG - 2011-09-17 11:16:13 --> File loaded: application/views/common/header.php
DEBUG - 2011-09-17 11:16:13 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-09-17 11:16:13 --> File loaded: application/views/common/footer.php
DEBUG - 2011-09-17 11:16:13 --> File loaded: application/views/layout/main.php
DEBUG - 2011-09-17 11:16:13 --> Final output sent to browser
DEBUG - 2011-09-17 11:16:13 --> Total execution time: 0.2289
DEBUG - 2011-09-17 11:16:13 --> Config Class Initialized
DEBUG - 2011-09-17 11:16:13 --> Hooks Class Initialized
DEBUG - 2011-09-17 11:16:13 --> Utf8 Class Initialized
DEBUG - 2011-09-17 11:16:13 --> UTF-8 Support Enabled
DEBUG - 2011-09-17 11:16:13 --> URI Class Initialized
DEBUG - 2011-09-17 11:16:13 --> Router Class Initialized
DEBUG - 2011-09-17 11:16:13 --> Output Class Initialized
DEBUG - 2011-09-17 11:16:13 --> Input Class Initialized
DEBUG - 2011-09-17 11:16:13 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-17 11:16:13 --> Language Class Initialized
DEBUG - 2011-09-17 11:16:13 --> Loader Class Initialized
DEBUG - 2011-09-17 11:16:13 --> Controller Class Initialized
DEBUG - 2011-09-17 11:16:13 --> Model Class Initialized
DEBUG - 2011-09-17 11:16:13 --> Model Class Initialized
DEBUG - 2011-09-17 11:16:13 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-17 11:16:13 --> Database Driver Class Initialized
DEBUG - 2011-09-17 11:16:14 --> Final output sent to browser
DEBUG - 2011-09-17 11:16:14 --> Total execution time: 0.6246
DEBUG - 2011-09-17 11:16:15 --> Config Class Initialized
DEBUG - 2011-09-17 11:16:15 --> Hooks Class Initialized
DEBUG - 2011-09-17 11:16:15 --> Utf8 Class Initialized
DEBUG - 2011-09-17 11:16:15 --> UTF-8 Support Enabled
DEBUG - 2011-09-17 11:16:15 --> URI Class Initialized
DEBUG - 2011-09-17 11:16:15 --> Router Class Initialized
ERROR - 2011-09-17 11:16:15 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-09-17 11:17:41 --> Config Class Initialized
DEBUG - 2011-09-17 11:17:41 --> Hooks Class Initialized
DEBUG - 2011-09-17 11:17:41 --> Utf8 Class Initialized
DEBUG - 2011-09-17 11:17:41 --> UTF-8 Support Enabled
DEBUG - 2011-09-17 11:17:41 --> URI Class Initialized
DEBUG - 2011-09-17 11:17:41 --> Router Class Initialized
DEBUG - 2011-09-17 11:17:41 --> Output Class Initialized
DEBUG - 2011-09-17 11:17:41 --> Input Class Initialized
DEBUG - 2011-09-17 11:17:41 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-17 11:17:41 --> Language Class Initialized
DEBUG - 2011-09-17 11:17:41 --> Loader Class Initialized
DEBUG - 2011-09-17 11:17:41 --> Controller Class Initialized
ERROR - 2011-09-17 11:17:41 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-09-17 11:17:41 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-09-17 11:17:41 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-09-17 11:17:41 --> Model Class Initialized
DEBUG - 2011-09-17 11:17:41 --> Model Class Initialized
DEBUG - 2011-09-17 11:17:41 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-17 11:17:41 --> Database Driver Class Initialized
DEBUG - 2011-09-17 11:17:41 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-09-17 11:17:41 --> Helper loaded: url_helper
DEBUG - 2011-09-17 11:17:41 --> File loaded: application/views/common/header.php
DEBUG - 2011-09-17 11:17:41 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-09-17 11:17:41 --> File loaded: application/views/common/footer.php
DEBUG - 2011-09-17 11:17:41 --> File loaded: application/views/layout/main.php
DEBUG - 2011-09-17 11:17:41 --> Final output sent to browser
DEBUG - 2011-09-17 11:17:41 --> Total execution time: 0.0275
DEBUG - 2011-09-17 11:17:42 --> Config Class Initialized
DEBUG - 2011-09-17 11:17:42 --> Hooks Class Initialized
DEBUG - 2011-09-17 11:17:42 --> Utf8 Class Initialized
DEBUG - 2011-09-17 11:17:42 --> UTF-8 Support Enabled
DEBUG - 2011-09-17 11:17:42 --> URI Class Initialized
DEBUG - 2011-09-17 11:17:42 --> Router Class Initialized
DEBUG - 2011-09-17 11:17:42 --> Output Class Initialized
DEBUG - 2011-09-17 11:17:42 --> Input Class Initialized
DEBUG - 2011-09-17 11:17:42 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-17 11:17:42 --> Language Class Initialized
DEBUG - 2011-09-17 11:17:42 --> Loader Class Initialized
DEBUG - 2011-09-17 11:17:42 --> Controller Class Initialized
DEBUG - 2011-09-17 11:17:42 --> Model Class Initialized
DEBUG - 2011-09-17 11:17:42 --> Model Class Initialized
DEBUG - 2011-09-17 11:17:42 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-17 11:17:42 --> Database Driver Class Initialized
DEBUG - 2011-09-17 11:17:42 --> Final output sent to browser
DEBUG - 2011-09-17 11:17:42 --> Total execution time: 0.5479
DEBUG - 2011-09-17 11:17:42 --> Config Class Initialized
DEBUG - 2011-09-17 11:17:42 --> Hooks Class Initialized
DEBUG - 2011-09-17 11:17:42 --> Utf8 Class Initialized
DEBUG - 2011-09-17 11:17:42 --> UTF-8 Support Enabled
DEBUG - 2011-09-17 11:17:42 --> URI Class Initialized
DEBUG - 2011-09-17 11:17:42 --> Router Class Initialized
DEBUG - 2011-09-17 11:17:42 --> Output Class Initialized
DEBUG - 2011-09-17 11:17:42 --> Input Class Initialized
DEBUG - 2011-09-17 11:17:42 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-17 11:17:42 --> Language Class Initialized
DEBUG - 2011-09-17 11:17:42 --> Loader Class Initialized
DEBUG - 2011-09-17 11:17:42 --> Controller Class Initialized
ERROR - 2011-09-17 11:17:42 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-09-17 11:17:42 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-09-17 11:17:42 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-09-17 11:17:42 --> Model Class Initialized
DEBUG - 2011-09-17 11:17:42 --> Model Class Initialized
DEBUG - 2011-09-17 11:17:42 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-17 11:17:42 --> Database Driver Class Initialized
DEBUG - 2011-09-17 11:17:42 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-09-17 11:17:42 --> Helper loaded: url_helper
DEBUG - 2011-09-17 11:17:42 --> File loaded: application/views/common/header.php
DEBUG - 2011-09-17 11:17:42 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-09-17 11:17:42 --> File loaded: application/views/common/footer.php
DEBUG - 2011-09-17 11:17:42 --> File loaded: application/views/layout/main.php
DEBUG - 2011-09-17 11:17:42 --> Final output sent to browser
DEBUG - 2011-09-17 11:17:42 --> Total execution time: 0.0270
DEBUG - 2011-09-17 11:17:43 --> Config Class Initialized
DEBUG - 2011-09-17 11:17:43 --> Hooks Class Initialized
DEBUG - 2011-09-17 11:17:43 --> Utf8 Class Initialized
DEBUG - 2011-09-17 11:17:43 --> UTF-8 Support Enabled
DEBUG - 2011-09-17 11:17:43 --> URI Class Initialized
DEBUG - 2011-09-17 11:17:43 --> Router Class Initialized
ERROR - 2011-09-17 11:17:43 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-09-17 11:29:00 --> Config Class Initialized
DEBUG - 2011-09-17 11:29:00 --> Hooks Class Initialized
DEBUG - 2011-09-17 11:29:00 --> Utf8 Class Initialized
DEBUG - 2011-09-17 11:29:00 --> UTF-8 Support Enabled
DEBUG - 2011-09-17 11:29:00 --> URI Class Initialized
DEBUG - 2011-09-17 11:29:00 --> Router Class Initialized
DEBUG - 2011-09-17 11:29:00 --> Output Class Initialized
DEBUG - 2011-09-17 11:29:00 --> Input Class Initialized
DEBUG - 2011-09-17 11:29:00 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-17 11:29:00 --> Language Class Initialized
DEBUG - 2011-09-17 11:29:00 --> Loader Class Initialized
DEBUG - 2011-09-17 11:29:00 --> Controller Class Initialized
ERROR - 2011-09-17 11:29:00 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-09-17 11:29:00 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-09-17 11:29:00 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-09-17 11:29:00 --> Model Class Initialized
DEBUG - 2011-09-17 11:29:00 --> Model Class Initialized
DEBUG - 2011-09-17 11:29:00 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-17 11:29:00 --> Database Driver Class Initialized
DEBUG - 2011-09-17 11:29:00 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-09-17 11:29:00 --> Helper loaded: url_helper
DEBUG - 2011-09-17 11:29:00 --> File loaded: application/views/common/header.php
DEBUG - 2011-09-17 11:29:00 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-09-17 11:29:00 --> File loaded: application/views/common/footer.php
DEBUG - 2011-09-17 11:29:00 --> File loaded: application/views/layout/main.php
DEBUG - 2011-09-17 11:29:00 --> Final output sent to browser
DEBUG - 2011-09-17 11:29:00 --> Total execution time: 0.1828
DEBUG - 2011-09-17 11:29:04 --> Config Class Initialized
DEBUG - 2011-09-17 11:29:04 --> Hooks Class Initialized
DEBUG - 2011-09-17 11:29:04 --> Utf8 Class Initialized
DEBUG - 2011-09-17 11:29:04 --> UTF-8 Support Enabled
DEBUG - 2011-09-17 11:29:04 --> URI Class Initialized
DEBUG - 2011-09-17 11:29:04 --> Router Class Initialized
DEBUG - 2011-09-17 11:29:04 --> Output Class Initialized
DEBUG - 2011-09-17 11:29:04 --> Input Class Initialized
DEBUG - 2011-09-17 11:29:04 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-17 11:29:04 --> Language Class Initialized
DEBUG - 2011-09-17 11:29:04 --> Loader Class Initialized
DEBUG - 2011-09-17 11:29:04 --> Controller Class Initialized
DEBUG - 2011-09-17 11:29:04 --> Model Class Initialized
DEBUG - 2011-09-17 11:29:04 --> Model Class Initialized
DEBUG - 2011-09-17 11:29:04 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-17 11:29:04 --> Database Driver Class Initialized
DEBUG - 2011-09-17 11:29:05 --> Final output sent to browser
DEBUG - 2011-09-17 11:29:05 --> Total execution time: 1.4760
DEBUG - 2011-09-17 11:29:08 --> Config Class Initialized
DEBUG - 2011-09-17 11:29:08 --> Hooks Class Initialized
DEBUG - 2011-09-17 11:29:08 --> Utf8 Class Initialized
DEBUG - 2011-09-17 11:29:08 --> UTF-8 Support Enabled
DEBUG - 2011-09-17 11:29:08 --> URI Class Initialized
DEBUG - 2011-09-17 11:29:08 --> Router Class Initialized
ERROR - 2011-09-17 11:29:08 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-09-17 11:29:37 --> Config Class Initialized
DEBUG - 2011-09-17 11:29:37 --> Hooks Class Initialized
DEBUG - 2011-09-17 11:29:37 --> Utf8 Class Initialized
DEBUG - 2011-09-17 11:29:37 --> UTF-8 Support Enabled
DEBUG - 2011-09-17 11:29:37 --> URI Class Initialized
DEBUG - 2011-09-17 11:29:37 --> Router Class Initialized
DEBUG - 2011-09-17 11:29:37 --> Output Class Initialized
DEBUG - 2011-09-17 11:29:37 --> Input Class Initialized
DEBUG - 2011-09-17 11:29:37 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-17 11:29:37 --> Language Class Initialized
DEBUG - 2011-09-17 11:29:37 --> Loader Class Initialized
DEBUG - 2011-09-17 11:29:37 --> Controller Class Initialized
ERROR - 2011-09-17 11:29:37 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-09-17 11:29:37 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-09-17 11:29:37 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-09-17 11:29:37 --> Model Class Initialized
DEBUG - 2011-09-17 11:29:37 --> Model Class Initialized
DEBUG - 2011-09-17 11:29:37 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-17 11:29:37 --> Database Driver Class Initialized
DEBUG - 2011-09-17 11:29:37 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-09-17 11:29:37 --> Helper loaded: url_helper
DEBUG - 2011-09-17 11:29:37 --> File loaded: application/views/common/header.php
DEBUG - 2011-09-17 11:29:37 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-09-17 11:29:37 --> File loaded: application/views/common/footer.php
DEBUG - 2011-09-17 11:29:37 --> File loaded: application/views/layout/main.php
DEBUG - 2011-09-17 11:29:37 --> Final output sent to browser
DEBUG - 2011-09-17 11:29:37 --> Total execution time: 0.0286
DEBUG - 2011-09-17 11:29:39 --> Config Class Initialized
DEBUG - 2011-09-17 11:29:39 --> Hooks Class Initialized
DEBUG - 2011-09-17 11:29:39 --> Utf8 Class Initialized
DEBUG - 2011-09-17 11:29:39 --> UTF-8 Support Enabled
DEBUG - 2011-09-17 11:29:39 --> URI Class Initialized
DEBUG - 2011-09-17 11:29:39 --> Router Class Initialized
DEBUG - 2011-09-17 11:29:39 --> Output Class Initialized
DEBUG - 2011-09-17 11:29:39 --> Input Class Initialized
DEBUG - 2011-09-17 11:29:39 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-17 11:29:39 --> Language Class Initialized
DEBUG - 2011-09-17 11:29:39 --> Loader Class Initialized
DEBUG - 2011-09-17 11:29:39 --> Controller Class Initialized
DEBUG - 2011-09-17 11:29:39 --> Model Class Initialized
DEBUG - 2011-09-17 11:29:39 --> Model Class Initialized
DEBUG - 2011-09-17 11:29:39 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-17 11:29:39 --> Database Driver Class Initialized
DEBUG - 2011-09-17 11:29:40 --> Final output sent to browser
DEBUG - 2011-09-17 11:29:40 --> Total execution time: 0.4882
DEBUG - 2011-09-17 11:29:42 --> Config Class Initialized
DEBUG - 2011-09-17 11:29:42 --> Hooks Class Initialized
DEBUG - 2011-09-17 11:29:42 --> Utf8 Class Initialized
DEBUG - 2011-09-17 11:29:42 --> UTF-8 Support Enabled
DEBUG - 2011-09-17 11:29:42 --> URI Class Initialized
DEBUG - 2011-09-17 11:29:42 --> Router Class Initialized
ERROR - 2011-09-17 11:29:42 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-09-17 11:54:59 --> Config Class Initialized
DEBUG - 2011-09-17 11:54:59 --> Hooks Class Initialized
DEBUG - 2011-09-17 11:54:59 --> Utf8 Class Initialized
DEBUG - 2011-09-17 11:54:59 --> UTF-8 Support Enabled
DEBUG - 2011-09-17 11:54:59 --> URI Class Initialized
DEBUG - 2011-09-17 11:54:59 --> Router Class Initialized
DEBUG - 2011-09-17 11:54:59 --> Output Class Initialized
DEBUG - 2011-09-17 11:54:59 --> Input Class Initialized
DEBUG - 2011-09-17 11:54:59 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-17 11:54:59 --> Language Class Initialized
DEBUG - 2011-09-17 11:54:59 --> Loader Class Initialized
DEBUG - 2011-09-17 11:54:59 --> Controller Class Initialized
DEBUG - 2011-09-17 11:54:59 --> Model Class Initialized
DEBUG - 2011-09-17 11:54:59 --> Model Class Initialized
DEBUG - 2011-09-17 11:54:59 --> Model Class Initialized
DEBUG - 2011-09-17 11:54:59 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-17 11:54:59 --> Database Driver Class Initialized
DEBUG - 2011-09-17 11:55:00 --> File loaded: application/views/table/main.php
DEBUG - 2011-09-17 11:55:00 --> Helper loaded: url_helper
DEBUG - 2011-09-17 11:55:00 --> File loaded: application/views/common/header.php
DEBUG - 2011-09-17 11:55:00 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-09-17 11:55:00 --> File loaded: application/views/common/footer.php
DEBUG - 2011-09-17 11:55:00 --> File loaded: application/views/layout/main.php
DEBUG - 2011-09-17 11:55:00 --> Final output sent to browser
DEBUG - 2011-09-17 11:55:00 --> Total execution time: 0.7894
DEBUG - 2011-09-17 11:55:05 --> Config Class Initialized
DEBUG - 2011-09-17 11:55:05 --> Hooks Class Initialized
DEBUG - 2011-09-17 11:55:05 --> Utf8 Class Initialized
DEBUG - 2011-09-17 11:55:05 --> UTF-8 Support Enabled
DEBUG - 2011-09-17 11:55:05 --> URI Class Initialized
DEBUG - 2011-09-17 11:55:05 --> Router Class Initialized
ERROR - 2011-09-17 11:55:05 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-09-17 11:55:07 --> Config Class Initialized
DEBUG - 2011-09-17 11:55:07 --> Hooks Class Initialized
DEBUG - 2011-09-17 11:55:07 --> Utf8 Class Initialized
DEBUG - 2011-09-17 11:55:07 --> UTF-8 Support Enabled
DEBUG - 2011-09-17 11:55:07 --> URI Class Initialized
DEBUG - 2011-09-17 11:55:07 --> Router Class Initialized
ERROR - 2011-09-17 11:55:07 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-09-17 11:55:23 --> Config Class Initialized
DEBUG - 2011-09-17 11:55:23 --> Hooks Class Initialized
DEBUG - 2011-09-17 11:55:23 --> Utf8 Class Initialized
DEBUG - 2011-09-17 11:55:23 --> UTF-8 Support Enabled
DEBUG - 2011-09-17 11:55:23 --> URI Class Initialized
DEBUG - 2011-09-17 11:55:23 --> Router Class Initialized
DEBUG - 2011-09-17 11:55:23 --> Output Class Initialized
DEBUG - 2011-09-17 11:55:23 --> Input Class Initialized
DEBUG - 2011-09-17 11:55:23 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-17 11:55:23 --> Language Class Initialized
DEBUG - 2011-09-17 11:55:23 --> Loader Class Initialized
DEBUG - 2011-09-17 11:55:23 --> Controller Class Initialized
DEBUG - 2011-09-17 11:55:23 --> Model Class Initialized
DEBUG - 2011-09-17 11:55:23 --> Model Class Initialized
DEBUG - 2011-09-17 11:55:23 --> Model Class Initialized
DEBUG - 2011-09-17 11:55:23 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-17 11:55:23 --> Database Driver Class Initialized
DEBUG - 2011-09-17 11:55:24 --> File loaded: application/views/table/main.php
DEBUG - 2011-09-17 11:55:24 --> Helper loaded: url_helper
DEBUG - 2011-09-17 11:55:24 --> File loaded: application/views/common/header.php
DEBUG - 2011-09-17 11:55:24 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-09-17 11:55:24 --> File loaded: application/views/common/footer.php
DEBUG - 2011-09-17 11:55:24 --> File loaded: application/views/layout/main.php
DEBUG - 2011-09-17 11:55:24 --> Final output sent to browser
DEBUG - 2011-09-17 11:55:24 --> Total execution time: 1.0540
DEBUG - 2011-09-17 11:55:47 --> Config Class Initialized
DEBUG - 2011-09-17 11:55:47 --> Hooks Class Initialized
DEBUG - 2011-09-17 11:55:47 --> Utf8 Class Initialized
DEBUG - 2011-09-17 11:55:47 --> UTF-8 Support Enabled
DEBUG - 2011-09-17 11:55:47 --> URI Class Initialized
DEBUG - 2011-09-17 11:55:47 --> Router Class Initialized
DEBUG - 2011-09-17 11:55:47 --> Output Class Initialized
DEBUG - 2011-09-17 11:55:47 --> Input Class Initialized
DEBUG - 2011-09-17 11:55:47 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-17 11:55:47 --> Language Class Initialized
DEBUG - 2011-09-17 11:55:47 --> Loader Class Initialized
DEBUG - 2011-09-17 11:55:47 --> Controller Class Initialized
DEBUG - 2011-09-17 11:55:47 --> Model Class Initialized
DEBUG - 2011-09-17 11:55:47 --> Model Class Initialized
DEBUG - 2011-09-17 11:55:47 --> Model Class Initialized
DEBUG - 2011-09-17 11:55:47 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-17 11:55:47 --> Database Driver Class Initialized
DEBUG - 2011-09-17 11:55:47 --> File loaded: application/views/table/main.php
DEBUG - 2011-09-17 11:55:47 --> Helper loaded: url_helper
DEBUG - 2011-09-17 11:55:47 --> File loaded: application/views/common/header.php
DEBUG - 2011-09-17 11:55:47 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-09-17 11:55:47 --> File loaded: application/views/common/footer.php
DEBUG - 2011-09-17 11:55:47 --> File loaded: application/views/layout/main.php
DEBUG - 2011-09-17 11:55:47 --> Final output sent to browser
DEBUG - 2011-09-17 11:55:47 --> Total execution time: 0.2895
DEBUG - 2011-09-17 11:56:04 --> Config Class Initialized
DEBUG - 2011-09-17 11:56:04 --> Hooks Class Initialized
DEBUG - 2011-09-17 11:56:04 --> Utf8 Class Initialized
DEBUG - 2011-09-17 11:56:04 --> UTF-8 Support Enabled
DEBUG - 2011-09-17 11:56:04 --> URI Class Initialized
DEBUG - 2011-09-17 11:56:04 --> Router Class Initialized
DEBUG - 2011-09-17 11:56:04 --> Output Class Initialized
DEBUG - 2011-09-17 11:56:04 --> Input Class Initialized
DEBUG - 2011-09-17 11:56:04 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-17 11:56:04 --> Language Class Initialized
DEBUG - 2011-09-17 11:56:04 --> Loader Class Initialized
DEBUG - 2011-09-17 11:56:04 --> Controller Class Initialized
DEBUG - 2011-09-17 11:56:04 --> Model Class Initialized
DEBUG - 2011-09-17 11:56:04 --> Model Class Initialized
DEBUG - 2011-09-17 11:56:04 --> Model Class Initialized
DEBUG - 2011-09-17 11:56:04 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-17 11:56:04 --> Database Driver Class Initialized
DEBUG - 2011-09-17 11:56:04 --> File loaded: application/views/table/main.php
DEBUG - 2011-09-17 11:56:04 --> Helper loaded: url_helper
DEBUG - 2011-09-17 11:56:04 --> File loaded: application/views/common/header.php
DEBUG - 2011-09-17 11:56:04 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-09-17 11:56:04 --> File loaded: application/views/common/footer.php
DEBUG - 2011-09-17 11:56:04 --> File loaded: application/views/layout/main.php
DEBUG - 2011-09-17 11:56:04 --> Final output sent to browser
DEBUG - 2011-09-17 11:56:04 --> Total execution time: 0.5742
DEBUG - 2011-09-17 11:56:22 --> Config Class Initialized
DEBUG - 2011-09-17 11:56:22 --> Hooks Class Initialized
DEBUG - 2011-09-17 11:56:22 --> Utf8 Class Initialized
DEBUG - 2011-09-17 11:56:22 --> UTF-8 Support Enabled
DEBUG - 2011-09-17 11:56:22 --> URI Class Initialized
DEBUG - 2011-09-17 11:56:22 --> Router Class Initialized
DEBUG - 2011-09-17 11:56:22 --> Output Class Initialized
DEBUG - 2011-09-17 11:56:22 --> Input Class Initialized
DEBUG - 2011-09-17 11:56:22 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-17 11:56:22 --> Language Class Initialized
DEBUG - 2011-09-17 11:56:22 --> Loader Class Initialized
DEBUG - 2011-09-17 11:56:22 --> Controller Class Initialized
DEBUG - 2011-09-17 11:56:22 --> Model Class Initialized
DEBUG - 2011-09-17 11:56:22 --> Model Class Initialized
DEBUG - 2011-09-17 11:56:22 --> Model Class Initialized
DEBUG - 2011-09-17 11:56:22 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-17 11:56:22 --> Database Driver Class Initialized
DEBUG - 2011-09-17 11:56:23 --> File loaded: application/views/table/main.php
DEBUG - 2011-09-17 11:56:23 --> Helper loaded: url_helper
DEBUG - 2011-09-17 11:56:23 --> File loaded: application/views/common/header.php
DEBUG - 2011-09-17 11:56:23 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-09-17 11:56:23 --> File loaded: application/views/common/footer.php
DEBUG - 2011-09-17 11:56:23 --> File loaded: application/views/layout/main.php
DEBUG - 2011-09-17 11:56:23 --> Final output sent to browser
DEBUG - 2011-09-17 11:56:23 --> Total execution time: 0.9737
DEBUG - 2011-09-17 11:56:28 --> Config Class Initialized
DEBUG - 2011-09-17 11:56:28 --> Hooks Class Initialized
DEBUG - 2011-09-17 11:56:28 --> Utf8 Class Initialized
DEBUG - 2011-09-17 11:56:28 --> UTF-8 Support Enabled
DEBUG - 2011-09-17 11:56:28 --> URI Class Initialized
DEBUG - 2011-09-17 11:56:28 --> Router Class Initialized
DEBUG - 2011-09-17 11:56:28 --> Output Class Initialized
DEBUG - 2011-09-17 11:56:28 --> Input Class Initialized
DEBUG - 2011-09-17 11:56:28 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-17 11:56:28 --> Language Class Initialized
DEBUG - 2011-09-17 11:56:28 --> Loader Class Initialized
DEBUG - 2011-09-17 11:56:28 --> Controller Class Initialized
DEBUG - 2011-09-17 11:56:28 --> Model Class Initialized
DEBUG - 2011-09-17 11:56:28 --> Model Class Initialized
DEBUG - 2011-09-17 11:56:28 --> Model Class Initialized
DEBUG - 2011-09-17 11:56:28 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-17 11:56:28 --> Database Driver Class Initialized
DEBUG - 2011-09-17 11:56:28 --> File loaded: application/views/table/main.php
DEBUG - 2011-09-17 11:56:28 --> Helper loaded: url_helper
DEBUG - 2011-09-17 11:56:28 --> File loaded: application/views/common/header.php
DEBUG - 2011-09-17 11:56:28 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-09-17 11:56:28 --> File loaded: application/views/common/footer.php
DEBUG - 2011-09-17 11:56:28 --> File loaded: application/views/layout/main.php
DEBUG - 2011-09-17 11:56:28 --> Final output sent to browser
DEBUG - 2011-09-17 11:56:28 --> Total execution time: 0.0454
DEBUG - 2011-09-17 12:35:37 --> Config Class Initialized
DEBUG - 2011-09-17 12:35:37 --> Hooks Class Initialized
DEBUG - 2011-09-17 12:35:37 --> Utf8 Class Initialized
DEBUG - 2011-09-17 12:35:37 --> UTF-8 Support Enabled
DEBUG - 2011-09-17 12:35:37 --> URI Class Initialized
DEBUG - 2011-09-17 12:35:37 --> Router Class Initialized
DEBUG - 2011-09-17 12:35:37 --> Output Class Initialized
DEBUG - 2011-09-17 12:35:37 --> Input Class Initialized
DEBUG - 2011-09-17 12:35:37 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-17 12:35:37 --> Language Class Initialized
DEBUG - 2011-09-17 12:35:37 --> Loader Class Initialized
DEBUG - 2011-09-17 12:35:37 --> Controller Class Initialized
DEBUG - 2011-09-17 12:35:37 --> Model Class Initialized
DEBUG - 2011-09-17 12:35:37 --> Model Class Initialized
DEBUG - 2011-09-17 12:35:37 --> Model Class Initialized
DEBUG - 2011-09-17 12:35:37 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-17 12:35:37 --> Database Driver Class Initialized
DEBUG - 2011-09-17 12:35:38 --> File loaded: application/views/table/main.php
DEBUG - 2011-09-17 12:35:38 --> Helper loaded: url_helper
DEBUG - 2011-09-17 12:35:38 --> File loaded: application/views/common/header.php
DEBUG - 2011-09-17 12:35:38 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-09-17 12:35:38 --> File loaded: application/views/common/footer.php
DEBUG - 2011-09-17 12:35:38 --> File loaded: application/views/layout/main.php
DEBUG - 2011-09-17 12:35:38 --> Final output sent to browser
DEBUG - 2011-09-17 12:35:38 --> Total execution time: 1.0664
DEBUG - 2011-09-17 12:40:44 --> Config Class Initialized
DEBUG - 2011-09-17 12:40:44 --> Hooks Class Initialized
DEBUG - 2011-09-17 12:40:44 --> Utf8 Class Initialized
DEBUG - 2011-09-17 12:40:44 --> UTF-8 Support Enabled
DEBUG - 2011-09-17 12:40:44 --> URI Class Initialized
DEBUG - 2011-09-17 12:40:44 --> Router Class Initialized
DEBUG - 2011-09-17 12:40:44 --> Output Class Initialized
DEBUG - 2011-09-17 12:40:44 --> Input Class Initialized
DEBUG - 2011-09-17 12:40:44 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-17 12:40:44 --> Language Class Initialized
DEBUG - 2011-09-17 12:40:44 --> Loader Class Initialized
DEBUG - 2011-09-17 12:40:44 --> Controller Class Initialized
DEBUG - 2011-09-17 12:40:44 --> Model Class Initialized
DEBUG - 2011-09-17 12:40:44 --> Model Class Initialized
DEBUG - 2011-09-17 12:40:44 --> Model Class Initialized
DEBUG - 2011-09-17 12:40:44 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-17 12:40:44 --> Database Driver Class Initialized
DEBUG - 2011-09-17 12:40:44 --> File loaded: application/views/table/main.php
DEBUG - 2011-09-17 12:40:44 --> Helper loaded: url_helper
DEBUG - 2011-09-17 12:40:44 --> File loaded: application/views/common/header.php
DEBUG - 2011-09-17 12:40:44 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-09-17 12:40:44 --> File loaded: application/views/common/footer.php
DEBUG - 2011-09-17 12:40:44 --> File loaded: application/views/layout/main.php
DEBUG - 2011-09-17 12:40:44 --> Final output sent to browser
DEBUG - 2011-09-17 12:40:44 --> Total execution time: 0.0497
DEBUG - 2011-09-17 12:40:46 --> Config Class Initialized
DEBUG - 2011-09-17 12:40:46 --> Hooks Class Initialized
DEBUG - 2011-09-17 12:40:46 --> Utf8 Class Initialized
DEBUG - 2011-09-17 12:40:46 --> UTF-8 Support Enabled
DEBUG - 2011-09-17 12:40:46 --> URI Class Initialized
DEBUG - 2011-09-17 12:40:46 --> Router Class Initialized
ERROR - 2011-09-17 12:40:46 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-09-17 12:41:01 --> Config Class Initialized
DEBUG - 2011-09-17 12:41:01 --> Hooks Class Initialized
DEBUG - 2011-09-17 12:41:01 --> Utf8 Class Initialized
DEBUG - 2011-09-17 12:41:01 --> UTF-8 Support Enabled
DEBUG - 2011-09-17 12:41:01 --> URI Class Initialized
DEBUG - 2011-09-17 12:41:01 --> Router Class Initialized
DEBUG - 2011-09-17 12:41:01 --> Output Class Initialized
DEBUG - 2011-09-17 12:41:01 --> Input Class Initialized
DEBUG - 2011-09-17 12:41:01 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-17 12:41:01 --> Language Class Initialized
DEBUG - 2011-09-17 12:41:01 --> Loader Class Initialized
DEBUG - 2011-09-17 12:41:01 --> Controller Class Initialized
DEBUG - 2011-09-17 12:41:01 --> Model Class Initialized
DEBUG - 2011-09-17 12:41:01 --> Model Class Initialized
DEBUG - 2011-09-17 12:41:01 --> Model Class Initialized
DEBUG - 2011-09-17 12:41:01 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-17 12:41:01 --> Database Driver Class Initialized
DEBUG - 2011-09-17 12:41:01 --> File loaded: application/views/table/main.php
DEBUG - 2011-09-17 12:41:01 --> Helper loaded: url_helper
DEBUG - 2011-09-17 12:41:01 --> File loaded: application/views/common/header.php
DEBUG - 2011-09-17 12:41:01 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-09-17 12:41:01 --> File loaded: application/views/common/footer.php
DEBUG - 2011-09-17 12:41:01 --> File loaded: application/views/layout/main.php
DEBUG - 2011-09-17 12:41:01 --> Final output sent to browser
DEBUG - 2011-09-17 12:41:01 --> Total execution time: 0.3314
DEBUG - 2011-09-17 12:41:02 --> Config Class Initialized
DEBUG - 2011-09-17 12:41:02 --> Hooks Class Initialized
DEBUG - 2011-09-17 12:41:02 --> Utf8 Class Initialized
DEBUG - 2011-09-17 12:41:02 --> UTF-8 Support Enabled
DEBUG - 2011-09-17 12:41:02 --> URI Class Initialized
DEBUG - 2011-09-17 12:41:02 --> Router Class Initialized
ERROR - 2011-09-17 12:41:02 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-09-17 12:41:03 --> Config Class Initialized
DEBUG - 2011-09-17 12:41:03 --> Hooks Class Initialized
DEBUG - 2011-09-17 12:41:03 --> Utf8 Class Initialized
DEBUG - 2011-09-17 12:41:03 --> UTF-8 Support Enabled
DEBUG - 2011-09-17 12:41:03 --> URI Class Initialized
DEBUG - 2011-09-17 12:41:03 --> Router Class Initialized
DEBUG - 2011-09-17 12:41:03 --> Output Class Initialized
DEBUG - 2011-09-17 12:41:03 --> Input Class Initialized
DEBUG - 2011-09-17 12:41:03 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-17 12:41:03 --> Language Class Initialized
DEBUG - 2011-09-17 12:41:03 --> Loader Class Initialized
DEBUG - 2011-09-17 12:41:03 --> Controller Class Initialized
DEBUG - 2011-09-17 12:41:03 --> Model Class Initialized
DEBUG - 2011-09-17 12:41:03 --> Model Class Initialized
DEBUG - 2011-09-17 12:41:03 --> Model Class Initialized
DEBUG - 2011-09-17 12:41:03 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-17 12:41:03 --> Database Driver Class Initialized
DEBUG - 2011-09-17 12:41:03 --> File loaded: application/views/table/main.php
DEBUG - 2011-09-17 12:41:03 --> Helper loaded: url_helper
DEBUG - 2011-09-17 12:41:03 --> File loaded: application/views/common/header.php
DEBUG - 2011-09-17 12:41:03 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-09-17 12:41:03 --> File loaded: application/views/common/footer.php
DEBUG - 2011-09-17 12:41:03 --> File loaded: application/views/layout/main.php
DEBUG - 2011-09-17 12:41:03 --> Final output sent to browser
DEBUG - 2011-09-17 12:41:03 --> Total execution time: 0.0508
DEBUG - 2011-09-17 12:52:06 --> Config Class Initialized
DEBUG - 2011-09-17 12:52:06 --> Hooks Class Initialized
DEBUG - 2011-09-17 12:52:06 --> Utf8 Class Initialized
DEBUG - 2011-09-17 12:52:06 --> UTF-8 Support Enabled
DEBUG - 2011-09-17 12:52:06 --> URI Class Initialized
DEBUG - 2011-09-17 12:52:06 --> Router Class Initialized
DEBUG - 2011-09-17 12:52:06 --> Output Class Initialized
DEBUG - 2011-09-17 12:52:06 --> Input Class Initialized
DEBUG - 2011-09-17 12:52:06 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-17 12:52:06 --> Language Class Initialized
DEBUG - 2011-09-17 12:52:06 --> Loader Class Initialized
DEBUG - 2011-09-17 12:52:06 --> Controller Class Initialized
DEBUG - 2011-09-17 12:52:06 --> Model Class Initialized
DEBUG - 2011-09-17 12:52:06 --> Model Class Initialized
DEBUG - 2011-09-17 12:52:06 --> Model Class Initialized
DEBUG - 2011-09-17 12:52:06 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-17 12:52:06 --> Database Driver Class Initialized
DEBUG - 2011-09-17 12:52:06 --> File loaded: application/views/table/main.php
DEBUG - 2011-09-17 12:52:06 --> Helper loaded: url_helper
DEBUG - 2011-09-17 12:52:06 --> File loaded: application/views/common/header.php
DEBUG - 2011-09-17 12:52:06 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-09-17 12:52:06 --> File loaded: application/views/common/footer.php
DEBUG - 2011-09-17 12:52:06 --> File loaded: application/views/layout/main.php
DEBUG - 2011-09-17 12:52:06 --> Final output sent to browser
DEBUG - 2011-09-17 12:52:06 --> Total execution time: 0.0455
DEBUG - 2011-09-17 12:52:09 --> Config Class Initialized
DEBUG - 2011-09-17 12:52:09 --> Hooks Class Initialized
DEBUG - 2011-09-17 12:52:09 --> Utf8 Class Initialized
DEBUG - 2011-09-17 12:52:09 --> UTF-8 Support Enabled
DEBUG - 2011-09-17 12:52:09 --> URI Class Initialized
DEBUG - 2011-09-17 12:52:09 --> Router Class Initialized
ERROR - 2011-09-17 12:52:09 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-09-17 12:52:47 --> Config Class Initialized
DEBUG - 2011-09-17 12:52:47 --> Hooks Class Initialized
DEBUG - 2011-09-17 12:52:47 --> Utf8 Class Initialized
DEBUG - 2011-09-17 12:52:47 --> UTF-8 Support Enabled
DEBUG - 2011-09-17 12:52:47 --> URI Class Initialized
DEBUG - 2011-09-17 12:52:47 --> Router Class Initialized
DEBUG - 2011-09-17 12:52:47 --> No URI present. Default controller set.
DEBUG - 2011-09-17 12:52:47 --> Output Class Initialized
DEBUG - 2011-09-17 12:52:47 --> Input Class Initialized
DEBUG - 2011-09-17 12:52:47 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-17 12:52:47 --> Language Class Initialized
DEBUG - 2011-09-17 12:52:47 --> Loader Class Initialized
DEBUG - 2011-09-17 12:52:47 --> Controller Class Initialized
DEBUG - 2011-09-17 12:52:47 --> File loaded: application/views/splash/main.php
DEBUG - 2011-09-17 12:52:47 --> Helper loaded: url_helper
DEBUG - 2011-09-17 12:52:47 --> File loaded: application/views/common/header.php
DEBUG - 2011-09-17 12:52:47 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-09-17 12:52:47 --> File loaded: application/views/common/footer.php
DEBUG - 2011-09-17 12:52:47 --> File loaded: application/views/layout/main.php
DEBUG - 2011-09-17 12:52:47 --> Final output sent to browser
DEBUG - 2011-09-17 12:52:47 --> Total execution time: 0.0894
DEBUG - 2011-09-17 13:02:26 --> Config Class Initialized
DEBUG - 2011-09-17 13:02:26 --> Hooks Class Initialized
DEBUG - 2011-09-17 13:02:26 --> Utf8 Class Initialized
DEBUG - 2011-09-17 13:02:26 --> UTF-8 Support Enabled
DEBUG - 2011-09-17 13:02:26 --> URI Class Initialized
DEBUG - 2011-09-17 13:02:26 --> Router Class Initialized
ERROR - 2011-09-17 13:02:26 --> 404 Page Not Found --> robots.txt
DEBUG - 2011-09-17 13:04:12 --> Config Class Initialized
DEBUG - 2011-09-17 13:04:12 --> Hooks Class Initialized
DEBUG - 2011-09-17 13:04:12 --> Utf8 Class Initialized
DEBUG - 2011-09-17 13:04:12 --> UTF-8 Support Enabled
DEBUG - 2011-09-17 13:04:12 --> URI Class Initialized
DEBUG - 2011-09-17 13:04:12 --> Router Class Initialized
DEBUG - 2011-09-17 13:04:12 --> Output Class Initialized
DEBUG - 2011-09-17 13:04:12 --> Input Class Initialized
DEBUG - 2011-09-17 13:04:12 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-17 13:04:12 --> Language Class Initialized
DEBUG - 2011-09-17 13:04:12 --> Loader Class Initialized
DEBUG - 2011-09-17 13:04:12 --> Controller Class Initialized
ERROR - 2011-09-17 13:04:12 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-09-17 13:04:12 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-09-17 13:04:12 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-09-17 13:04:12 --> Model Class Initialized
DEBUG - 2011-09-17 13:04:12 --> Model Class Initialized
DEBUG - 2011-09-17 13:04:12 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-17 13:04:12 --> Database Driver Class Initialized
DEBUG - 2011-09-17 13:04:12 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-09-17 13:04:12 --> Helper loaded: url_helper
DEBUG - 2011-09-17 13:04:12 --> File loaded: application/views/common/header.php
DEBUG - 2011-09-17 13:04:12 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-09-17 13:04:12 --> File loaded: application/views/common/footer.php
DEBUG - 2011-09-17 13:04:12 --> File loaded: application/views/layout/main.php
DEBUG - 2011-09-17 13:04:12 --> Final output sent to browser
DEBUG - 2011-09-17 13:04:12 --> Total execution time: 0.0732
DEBUG - 2011-09-17 13:04:16 --> Config Class Initialized
DEBUG - 2011-09-17 13:04:16 --> Hooks Class Initialized
DEBUG - 2011-09-17 13:04:16 --> Utf8 Class Initialized
DEBUG - 2011-09-17 13:04:16 --> UTF-8 Support Enabled
DEBUG - 2011-09-17 13:04:16 --> URI Class Initialized
DEBUG - 2011-09-17 13:04:16 --> Router Class Initialized
DEBUG - 2011-09-17 13:04:16 --> Output Class Initialized
DEBUG - 2011-09-17 13:04:16 --> Input Class Initialized
DEBUG - 2011-09-17 13:04:16 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-17 13:04:16 --> Language Class Initialized
DEBUG - 2011-09-17 13:04:16 --> Loader Class Initialized
DEBUG - 2011-09-17 13:04:16 --> Controller Class Initialized
DEBUG - 2011-09-17 13:04:16 --> Model Class Initialized
DEBUG - 2011-09-17 13:04:16 --> Model Class Initialized
DEBUG - 2011-09-17 13:04:16 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-17 13:04:16 --> Database Driver Class Initialized
DEBUG - 2011-09-17 13:04:16 --> Final output sent to browser
DEBUG - 2011-09-17 13:04:16 --> Total execution time: 0.6064
DEBUG - 2011-09-17 13:04:18 --> Config Class Initialized
DEBUG - 2011-09-17 13:04:18 --> Hooks Class Initialized
DEBUG - 2011-09-17 13:04:18 --> Utf8 Class Initialized
DEBUG - 2011-09-17 13:04:18 --> UTF-8 Support Enabled
DEBUG - 2011-09-17 13:04:18 --> URI Class Initialized
DEBUG - 2011-09-17 13:04:18 --> Router Class Initialized
ERROR - 2011-09-17 13:04:18 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-09-17 13:04:35 --> Config Class Initialized
DEBUG - 2011-09-17 13:04:35 --> Hooks Class Initialized
DEBUG - 2011-09-17 13:04:35 --> Utf8 Class Initialized
DEBUG - 2011-09-17 13:04:35 --> UTF-8 Support Enabled
DEBUG - 2011-09-17 13:04:35 --> URI Class Initialized
DEBUG - 2011-09-17 13:04:35 --> Router Class Initialized
DEBUG - 2011-09-17 13:04:35 --> Output Class Initialized
DEBUG - 2011-09-17 13:04:35 --> Input Class Initialized
DEBUG - 2011-09-17 13:04:35 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-17 13:04:35 --> Language Class Initialized
DEBUG - 2011-09-17 13:04:35 --> Loader Class Initialized
DEBUG - 2011-09-17 13:04:35 --> Controller Class Initialized
ERROR - 2011-09-17 13:04:35 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-09-17 13:04:35 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-09-17 13:04:35 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-09-17 13:04:35 --> Model Class Initialized
DEBUG - 2011-09-17 13:04:35 --> Model Class Initialized
DEBUG - 2011-09-17 13:04:35 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-17 13:04:35 --> Database Driver Class Initialized
DEBUG - 2011-09-17 13:04:35 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-09-17 13:04:35 --> Helper loaded: url_helper
DEBUG - 2011-09-17 13:04:35 --> File loaded: application/views/common/header.php
DEBUG - 2011-09-17 13:04:35 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-09-17 13:04:35 --> File loaded: application/views/common/footer.php
DEBUG - 2011-09-17 13:04:35 --> File loaded: application/views/layout/main.php
DEBUG - 2011-09-17 13:04:35 --> Final output sent to browser
DEBUG - 2011-09-17 13:04:35 --> Total execution time: 0.0316
DEBUG - 2011-09-17 13:04:35 --> Config Class Initialized
DEBUG - 2011-09-17 13:04:35 --> Hooks Class Initialized
DEBUG - 2011-09-17 13:04:35 --> Utf8 Class Initialized
DEBUG - 2011-09-17 13:04:35 --> UTF-8 Support Enabled
DEBUG - 2011-09-17 13:04:35 --> URI Class Initialized
DEBUG - 2011-09-17 13:04:35 --> Router Class Initialized
DEBUG - 2011-09-17 13:04:35 --> Output Class Initialized
DEBUG - 2011-09-17 13:04:35 --> Input Class Initialized
DEBUG - 2011-09-17 13:04:35 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-17 13:04:35 --> Language Class Initialized
DEBUG - 2011-09-17 13:04:35 --> Loader Class Initialized
DEBUG - 2011-09-17 13:04:35 --> Controller Class Initialized
DEBUG - 2011-09-17 13:04:35 --> Model Class Initialized
DEBUG - 2011-09-17 13:04:35 --> Model Class Initialized
DEBUG - 2011-09-17 13:04:35 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-17 13:04:35 --> Database Driver Class Initialized
DEBUG - 2011-09-17 13:04:36 --> Final output sent to browser
DEBUG - 2011-09-17 13:04:36 --> Total execution time: 0.8284
DEBUG - 2011-09-17 13:04:51 --> Config Class Initialized
DEBUG - 2011-09-17 13:04:51 --> Hooks Class Initialized
DEBUG - 2011-09-17 13:04:51 --> Utf8 Class Initialized
DEBUG - 2011-09-17 13:04:51 --> UTF-8 Support Enabled
DEBUG - 2011-09-17 13:04:51 --> URI Class Initialized
DEBUG - 2011-09-17 13:04:51 --> Router Class Initialized
DEBUG - 2011-09-17 13:04:51 --> Output Class Initialized
DEBUG - 2011-09-17 13:04:51 --> Input Class Initialized
DEBUG - 2011-09-17 13:04:51 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-17 13:04:51 --> Language Class Initialized
DEBUG - 2011-09-17 13:04:51 --> Loader Class Initialized
DEBUG - 2011-09-17 13:04:51 --> Controller Class Initialized
ERROR - 2011-09-17 13:04:51 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-09-17 13:04:51 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-09-17 13:04:51 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-09-17 13:04:51 --> Model Class Initialized
DEBUG - 2011-09-17 13:04:51 --> Model Class Initialized
DEBUG - 2011-09-17 13:04:51 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-17 13:04:51 --> Database Driver Class Initialized
DEBUG - 2011-09-17 13:04:51 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-09-17 13:04:51 --> Helper loaded: url_helper
DEBUG - 2011-09-17 13:04:51 --> File loaded: application/views/common/header.php
DEBUG - 2011-09-17 13:04:51 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-09-17 13:04:51 --> File loaded: application/views/common/footer.php
DEBUG - 2011-09-17 13:04:51 --> File loaded: application/views/layout/main.php
DEBUG - 2011-09-17 13:04:51 --> Final output sent to browser
DEBUG - 2011-09-17 13:04:51 --> Total execution time: 0.0320
DEBUG - 2011-09-17 13:04:51 --> Config Class Initialized
DEBUG - 2011-09-17 13:04:51 --> Hooks Class Initialized
DEBUG - 2011-09-17 13:04:51 --> Utf8 Class Initialized
DEBUG - 2011-09-17 13:04:51 --> UTF-8 Support Enabled
DEBUG - 2011-09-17 13:04:51 --> URI Class Initialized
DEBUG - 2011-09-17 13:04:51 --> Router Class Initialized
DEBUG - 2011-09-17 13:04:51 --> Output Class Initialized
DEBUG - 2011-09-17 13:04:51 --> Input Class Initialized
DEBUG - 2011-09-17 13:04:51 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-17 13:04:51 --> Language Class Initialized
DEBUG - 2011-09-17 13:04:51 --> Loader Class Initialized
DEBUG - 2011-09-17 13:04:51 --> Controller Class Initialized
DEBUG - 2011-09-17 13:04:51 --> Model Class Initialized
DEBUG - 2011-09-17 13:04:51 --> Model Class Initialized
DEBUG - 2011-09-17 13:04:51 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-17 13:04:51 --> Database Driver Class Initialized
DEBUG - 2011-09-17 13:04:52 --> Final output sent to browser
DEBUG - 2011-09-17 13:04:52 --> Total execution time: 0.6755
DEBUG - 2011-09-17 13:04:57 --> Config Class Initialized
DEBUG - 2011-09-17 13:04:57 --> Hooks Class Initialized
DEBUG - 2011-09-17 13:04:57 --> Utf8 Class Initialized
DEBUG - 2011-09-17 13:04:57 --> UTF-8 Support Enabled
DEBUG - 2011-09-17 13:04:57 --> URI Class Initialized
DEBUG - 2011-09-17 13:04:57 --> Router Class Initialized
DEBUG - 2011-09-17 13:04:57 --> Output Class Initialized
DEBUG - 2011-09-17 13:04:57 --> Input Class Initialized
DEBUG - 2011-09-17 13:04:57 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-17 13:04:57 --> Language Class Initialized
DEBUG - 2011-09-17 13:04:57 --> Loader Class Initialized
DEBUG - 2011-09-17 13:04:57 --> Controller Class Initialized
ERROR - 2011-09-17 13:04:57 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-09-17 13:04:57 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-09-17 13:04:57 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-09-17 13:04:57 --> Model Class Initialized
DEBUG - 2011-09-17 13:04:57 --> Model Class Initialized
DEBUG - 2011-09-17 13:04:57 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-17 13:04:57 --> Database Driver Class Initialized
DEBUG - 2011-09-17 13:04:57 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-09-17 13:04:57 --> Helper loaded: url_helper
DEBUG - 2011-09-17 13:04:57 --> File loaded: application/views/common/header.php
DEBUG - 2011-09-17 13:04:57 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-09-17 13:04:57 --> File loaded: application/views/common/footer.php
DEBUG - 2011-09-17 13:04:57 --> File loaded: application/views/layout/main.php
DEBUG - 2011-09-17 13:04:57 --> Final output sent to browser
DEBUG - 2011-09-17 13:04:57 --> Total execution time: 0.0396
DEBUG - 2011-09-17 13:04:57 --> Config Class Initialized
DEBUG - 2011-09-17 13:04:57 --> Hooks Class Initialized
DEBUG - 2011-09-17 13:04:57 --> Utf8 Class Initialized
DEBUG - 2011-09-17 13:04:57 --> UTF-8 Support Enabled
DEBUG - 2011-09-17 13:04:57 --> URI Class Initialized
DEBUG - 2011-09-17 13:04:57 --> Router Class Initialized
DEBUG - 2011-09-17 13:04:57 --> Output Class Initialized
DEBUG - 2011-09-17 13:04:57 --> Input Class Initialized
DEBUG - 2011-09-17 13:04:57 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-17 13:04:57 --> Language Class Initialized
DEBUG - 2011-09-17 13:04:57 --> Loader Class Initialized
DEBUG - 2011-09-17 13:04:57 --> Controller Class Initialized
DEBUG - 2011-09-17 13:04:57 --> Model Class Initialized
DEBUG - 2011-09-17 13:04:57 --> Model Class Initialized
DEBUG - 2011-09-17 13:04:57 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-17 13:04:57 --> Database Driver Class Initialized
DEBUG - 2011-09-17 13:04:58 --> Final output sent to browser
DEBUG - 2011-09-17 13:04:58 --> Total execution time: 0.6006
DEBUG - 2011-09-17 13:05:08 --> Config Class Initialized
DEBUG - 2011-09-17 13:05:08 --> Hooks Class Initialized
DEBUG - 2011-09-17 13:05:08 --> Utf8 Class Initialized
DEBUG - 2011-09-17 13:05:08 --> UTF-8 Support Enabled
DEBUG - 2011-09-17 13:05:08 --> URI Class Initialized
DEBUG - 2011-09-17 13:05:08 --> Router Class Initialized
DEBUG - 2011-09-17 13:05:08 --> Output Class Initialized
DEBUG - 2011-09-17 13:05:08 --> Input Class Initialized
DEBUG - 2011-09-17 13:05:08 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-17 13:05:08 --> Language Class Initialized
DEBUG - 2011-09-17 13:05:08 --> Loader Class Initialized
DEBUG - 2011-09-17 13:05:08 --> Controller Class Initialized
ERROR - 2011-09-17 13:05:08 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-09-17 13:05:08 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-09-17 13:05:08 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-09-17 13:05:08 --> Model Class Initialized
DEBUG - 2011-09-17 13:05:08 --> Model Class Initialized
DEBUG - 2011-09-17 13:05:08 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-17 13:05:08 --> Database Driver Class Initialized
DEBUG - 2011-09-17 13:05:08 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-09-17 13:05:08 --> Helper loaded: url_helper
DEBUG - 2011-09-17 13:05:08 --> File loaded: application/views/common/header.php
DEBUG - 2011-09-17 13:05:08 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-09-17 13:05:08 --> File loaded: application/views/common/footer.php
DEBUG - 2011-09-17 13:05:08 --> File loaded: application/views/layout/main.php
DEBUG - 2011-09-17 13:05:08 --> Final output sent to browser
DEBUG - 2011-09-17 13:05:08 --> Total execution time: 0.0335
DEBUG - 2011-09-17 13:05:09 --> Config Class Initialized
DEBUG - 2011-09-17 13:05:09 --> Hooks Class Initialized
DEBUG - 2011-09-17 13:05:09 --> Utf8 Class Initialized
DEBUG - 2011-09-17 13:05:09 --> UTF-8 Support Enabled
DEBUG - 2011-09-17 13:05:09 --> URI Class Initialized
DEBUG - 2011-09-17 13:05:09 --> Router Class Initialized
DEBUG - 2011-09-17 13:05:09 --> Output Class Initialized
DEBUG - 2011-09-17 13:05:09 --> Input Class Initialized
DEBUG - 2011-09-17 13:05:09 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-17 13:05:09 --> Language Class Initialized
DEBUG - 2011-09-17 13:05:09 --> Loader Class Initialized
DEBUG - 2011-09-17 13:05:09 --> Controller Class Initialized
DEBUG - 2011-09-17 13:05:09 --> Model Class Initialized
DEBUG - 2011-09-17 13:05:09 --> Model Class Initialized
DEBUG - 2011-09-17 13:05:09 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-17 13:05:09 --> Database Driver Class Initialized
DEBUG - 2011-09-17 13:05:10 --> Final output sent to browser
DEBUG - 2011-09-17 13:05:10 --> Total execution time: 0.7699
DEBUG - 2011-09-17 13:05:12 --> Config Class Initialized
DEBUG - 2011-09-17 13:05:12 --> Hooks Class Initialized
DEBUG - 2011-09-17 13:05:12 --> Utf8 Class Initialized
DEBUG - 2011-09-17 13:05:12 --> UTF-8 Support Enabled
DEBUG - 2011-09-17 13:05:12 --> URI Class Initialized
DEBUG - 2011-09-17 13:05:12 --> Router Class Initialized
DEBUG - 2011-09-17 13:05:12 --> Output Class Initialized
DEBUG - 2011-09-17 13:05:12 --> Input Class Initialized
DEBUG - 2011-09-17 13:05:12 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-17 13:05:12 --> Language Class Initialized
DEBUG - 2011-09-17 13:05:12 --> Loader Class Initialized
DEBUG - 2011-09-17 13:05:12 --> Controller Class Initialized
ERROR - 2011-09-17 13:05:12 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-09-17 13:05:12 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-09-17 13:05:12 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-09-17 13:05:12 --> Model Class Initialized
DEBUG - 2011-09-17 13:05:12 --> Model Class Initialized
DEBUG - 2011-09-17 13:05:12 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-17 13:05:12 --> Database Driver Class Initialized
DEBUG - 2011-09-17 13:05:12 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-09-17 13:05:12 --> Helper loaded: url_helper
DEBUG - 2011-09-17 13:05:12 --> File loaded: application/views/common/header.php
DEBUG - 2011-09-17 13:05:12 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-09-17 13:05:12 --> File loaded: application/views/common/footer.php
DEBUG - 2011-09-17 13:05:12 --> File loaded: application/views/layout/main.php
DEBUG - 2011-09-17 13:05:12 --> Final output sent to browser
DEBUG - 2011-09-17 13:05:12 --> Total execution time: 0.0495
DEBUG - 2011-09-17 13:05:13 --> Config Class Initialized
DEBUG - 2011-09-17 13:05:13 --> Hooks Class Initialized
DEBUG - 2011-09-17 13:05:13 --> Utf8 Class Initialized
DEBUG - 2011-09-17 13:05:13 --> UTF-8 Support Enabled
DEBUG - 2011-09-17 13:05:13 --> URI Class Initialized
DEBUG - 2011-09-17 13:05:13 --> Router Class Initialized
DEBUG - 2011-09-17 13:05:13 --> Output Class Initialized
DEBUG - 2011-09-17 13:05:13 --> Input Class Initialized
DEBUG - 2011-09-17 13:05:13 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-17 13:05:13 --> Language Class Initialized
DEBUG - 2011-09-17 13:05:13 --> Loader Class Initialized
DEBUG - 2011-09-17 13:05:13 --> Controller Class Initialized
DEBUG - 2011-09-17 13:05:13 --> Model Class Initialized
DEBUG - 2011-09-17 13:05:13 --> Model Class Initialized
DEBUG - 2011-09-17 13:05:13 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-17 13:05:13 --> Database Driver Class Initialized
DEBUG - 2011-09-17 13:05:13 --> Final output sent to browser
DEBUG - 2011-09-17 13:05:13 --> Total execution time: 0.6228
DEBUG - 2011-09-17 13:05:24 --> Config Class Initialized
DEBUG - 2011-09-17 13:05:24 --> Hooks Class Initialized
DEBUG - 2011-09-17 13:05:24 --> Utf8 Class Initialized
DEBUG - 2011-09-17 13:05:24 --> UTF-8 Support Enabled
DEBUG - 2011-09-17 13:05:24 --> URI Class Initialized
DEBUG - 2011-09-17 13:05:24 --> Router Class Initialized
DEBUG - 2011-09-17 13:05:24 --> Output Class Initialized
DEBUG - 2011-09-17 13:05:24 --> Input Class Initialized
DEBUG - 2011-09-17 13:05:24 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-17 13:05:24 --> Language Class Initialized
DEBUG - 2011-09-17 13:05:24 --> Loader Class Initialized
DEBUG - 2011-09-17 13:05:24 --> Controller Class Initialized
ERROR - 2011-09-17 13:05:24 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-09-17 13:05:24 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-09-17 13:05:24 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-09-17 13:05:24 --> Model Class Initialized
DEBUG - 2011-09-17 13:05:24 --> Model Class Initialized
DEBUG - 2011-09-17 13:05:24 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-17 13:05:24 --> Database Driver Class Initialized
DEBUG - 2011-09-17 13:05:24 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-09-17 13:05:24 --> Helper loaded: url_helper
DEBUG - 2011-09-17 13:05:24 --> File loaded: application/views/common/header.php
DEBUG - 2011-09-17 13:05:24 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-09-17 13:05:24 --> File loaded: application/views/common/footer.php
DEBUG - 2011-09-17 13:05:24 --> File loaded: application/views/layout/main.php
DEBUG - 2011-09-17 13:05:24 --> Final output sent to browser
DEBUG - 2011-09-17 13:05:24 --> Total execution time: 0.0288
DEBUG - 2011-09-17 13:05:25 --> Config Class Initialized
DEBUG - 2011-09-17 13:05:25 --> Hooks Class Initialized
DEBUG - 2011-09-17 13:05:25 --> Utf8 Class Initialized
DEBUG - 2011-09-17 13:05:25 --> UTF-8 Support Enabled
DEBUG - 2011-09-17 13:05:25 --> URI Class Initialized
DEBUG - 2011-09-17 13:05:25 --> Router Class Initialized
DEBUG - 2011-09-17 13:05:25 --> Output Class Initialized
DEBUG - 2011-09-17 13:05:25 --> Input Class Initialized
DEBUG - 2011-09-17 13:05:25 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-17 13:05:25 --> Language Class Initialized
DEBUG - 2011-09-17 13:05:25 --> Loader Class Initialized
DEBUG - 2011-09-17 13:05:25 --> Controller Class Initialized
DEBUG - 2011-09-17 13:05:25 --> Model Class Initialized
DEBUG - 2011-09-17 13:05:25 --> Model Class Initialized
DEBUG - 2011-09-17 13:05:25 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-17 13:05:25 --> Database Driver Class Initialized
DEBUG - 2011-09-17 13:05:26 --> Final output sent to browser
DEBUG - 2011-09-17 13:05:26 --> Total execution time: 0.5614
DEBUG - 2011-09-17 13:05:26 --> Config Class Initialized
DEBUG - 2011-09-17 13:05:26 --> Hooks Class Initialized
DEBUG - 2011-09-17 13:05:26 --> Utf8 Class Initialized
DEBUG - 2011-09-17 13:05:26 --> UTF-8 Support Enabled
DEBUG - 2011-09-17 13:05:26 --> URI Class Initialized
DEBUG - 2011-09-17 13:05:26 --> Router Class Initialized
DEBUG - 2011-09-17 13:05:26 --> Output Class Initialized
DEBUG - 2011-09-17 13:05:26 --> Input Class Initialized
DEBUG - 2011-09-17 13:05:26 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-17 13:05:26 --> Language Class Initialized
DEBUG - 2011-09-17 13:05:26 --> Loader Class Initialized
DEBUG - 2011-09-17 13:05:26 --> Controller Class Initialized
ERROR - 2011-09-17 13:05:26 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-09-17 13:05:26 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-09-17 13:05:26 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-09-17 13:05:26 --> Model Class Initialized
DEBUG - 2011-09-17 13:05:26 --> Model Class Initialized
DEBUG - 2011-09-17 13:05:26 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-17 13:05:26 --> Database Driver Class Initialized
DEBUG - 2011-09-17 13:05:26 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-09-17 13:05:26 --> Helper loaded: url_helper
DEBUG - 2011-09-17 13:05:26 --> File loaded: application/views/common/header.php
DEBUG - 2011-09-17 13:05:26 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-09-17 13:05:26 --> File loaded: application/views/common/footer.php
DEBUG - 2011-09-17 13:05:26 --> File loaded: application/views/layout/main.php
DEBUG - 2011-09-17 13:05:26 --> Final output sent to browser
DEBUG - 2011-09-17 13:05:26 --> Total execution time: 0.0280
DEBUG - 2011-09-17 13:05:42 --> Config Class Initialized
DEBUG - 2011-09-17 13:05:42 --> Hooks Class Initialized
DEBUG - 2011-09-17 13:05:42 --> Utf8 Class Initialized
DEBUG - 2011-09-17 13:05:42 --> UTF-8 Support Enabled
DEBUG - 2011-09-17 13:05:42 --> URI Class Initialized
DEBUG - 2011-09-17 13:05:42 --> Router Class Initialized
DEBUG - 2011-09-17 13:05:42 --> Output Class Initialized
DEBUG - 2011-09-17 13:05:42 --> Input Class Initialized
DEBUG - 2011-09-17 13:05:42 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-17 13:05:42 --> Language Class Initialized
DEBUG - 2011-09-17 13:05:42 --> Loader Class Initialized
DEBUG - 2011-09-17 13:05:42 --> Controller Class Initialized
ERROR - 2011-09-17 13:05:42 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-09-17 13:05:42 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-09-17 13:05:42 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-09-17 13:05:42 --> Model Class Initialized
DEBUG - 2011-09-17 13:05:42 --> Model Class Initialized
DEBUG - 2011-09-17 13:05:42 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-17 13:05:42 --> Database Driver Class Initialized
DEBUG - 2011-09-17 13:05:42 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-09-17 13:05:42 --> Helper loaded: url_helper
DEBUG - 2011-09-17 13:05:42 --> File loaded: application/views/common/header.php
DEBUG - 2011-09-17 13:05:42 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-09-17 13:05:42 --> File loaded: application/views/common/footer.php
DEBUG - 2011-09-17 13:05:42 --> File loaded: application/views/layout/main.php
DEBUG - 2011-09-17 13:05:42 --> Final output sent to browser
DEBUG - 2011-09-17 13:05:42 --> Total execution time: 0.0294
DEBUG - 2011-09-17 13:05:43 --> Config Class Initialized
DEBUG - 2011-09-17 13:05:43 --> Hooks Class Initialized
DEBUG - 2011-09-17 13:05:43 --> Utf8 Class Initialized
DEBUG - 2011-09-17 13:05:43 --> UTF-8 Support Enabled
DEBUG - 2011-09-17 13:05:43 --> URI Class Initialized
DEBUG - 2011-09-17 13:05:43 --> Router Class Initialized
DEBUG - 2011-09-17 13:05:43 --> Output Class Initialized
DEBUG - 2011-09-17 13:05:43 --> Input Class Initialized
DEBUG - 2011-09-17 13:05:43 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-17 13:05:43 --> Language Class Initialized
DEBUG - 2011-09-17 13:05:43 --> Loader Class Initialized
DEBUG - 2011-09-17 13:05:43 --> Controller Class Initialized
DEBUG - 2011-09-17 13:05:43 --> Model Class Initialized
DEBUG - 2011-09-17 13:05:43 --> Model Class Initialized
DEBUG - 2011-09-17 13:05:43 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-17 13:05:43 --> Database Driver Class Initialized
DEBUG - 2011-09-17 13:05:43 --> Final output sent to browser
DEBUG - 2011-09-17 13:05:43 --> Total execution time: 0.4465
DEBUG - 2011-09-17 13:05:43 --> Config Class Initialized
DEBUG - 2011-09-17 13:05:43 --> Hooks Class Initialized
DEBUG - 2011-09-17 13:05:43 --> Utf8 Class Initialized
DEBUG - 2011-09-17 13:05:43 --> UTF-8 Support Enabled
DEBUG - 2011-09-17 13:05:43 --> URI Class Initialized
DEBUG - 2011-09-17 13:05:43 --> Router Class Initialized
DEBUG - 2011-09-17 13:05:43 --> Output Class Initialized
DEBUG - 2011-09-17 13:05:43 --> Input Class Initialized
DEBUG - 2011-09-17 13:05:43 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-17 13:05:43 --> Language Class Initialized
DEBUG - 2011-09-17 13:05:43 --> Loader Class Initialized
DEBUG - 2011-09-17 13:05:43 --> Controller Class Initialized
ERROR - 2011-09-17 13:05:43 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-09-17 13:05:43 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-09-17 13:05:43 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-09-17 13:05:43 --> Model Class Initialized
DEBUG - 2011-09-17 13:05:43 --> Model Class Initialized
DEBUG - 2011-09-17 13:05:43 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-17 13:05:43 --> Database Driver Class Initialized
DEBUG - 2011-09-17 13:05:43 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-09-17 13:05:43 --> Helper loaded: url_helper
DEBUG - 2011-09-17 13:05:43 --> File loaded: application/views/common/header.php
DEBUG - 2011-09-17 13:05:43 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-09-17 13:05:43 --> File loaded: application/views/common/footer.php
DEBUG - 2011-09-17 13:05:43 --> File loaded: application/views/layout/main.php
DEBUG - 2011-09-17 13:05:43 --> Final output sent to browser
DEBUG - 2011-09-17 13:05:43 --> Total execution time: 0.0490
DEBUG - 2011-09-17 13:05:52 --> Config Class Initialized
DEBUG - 2011-09-17 13:05:52 --> Hooks Class Initialized
DEBUG - 2011-09-17 13:05:52 --> Utf8 Class Initialized
DEBUG - 2011-09-17 13:05:52 --> UTF-8 Support Enabled
DEBUG - 2011-09-17 13:05:52 --> URI Class Initialized
DEBUG - 2011-09-17 13:05:52 --> Router Class Initialized
DEBUG - 2011-09-17 13:05:52 --> Output Class Initialized
DEBUG - 2011-09-17 13:05:52 --> Input Class Initialized
DEBUG - 2011-09-17 13:05:52 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-17 13:05:52 --> Language Class Initialized
DEBUG - 2011-09-17 13:05:52 --> Loader Class Initialized
DEBUG - 2011-09-17 13:05:52 --> Controller Class Initialized
ERROR - 2011-09-17 13:05:52 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-09-17 13:05:52 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-09-17 13:05:52 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-09-17 13:05:52 --> Model Class Initialized
DEBUG - 2011-09-17 13:05:52 --> Model Class Initialized
DEBUG - 2011-09-17 13:05:52 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-17 13:05:52 --> Database Driver Class Initialized
DEBUG - 2011-09-17 13:05:52 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-09-17 13:05:52 --> Helper loaded: url_helper
DEBUG - 2011-09-17 13:05:52 --> File loaded: application/views/common/header.php
DEBUG - 2011-09-17 13:05:52 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-09-17 13:05:52 --> File loaded: application/views/common/footer.php
DEBUG - 2011-09-17 13:05:52 --> File loaded: application/views/layout/main.php
DEBUG - 2011-09-17 13:05:52 --> Final output sent to browser
DEBUG - 2011-09-17 13:05:52 --> Total execution time: 0.0343
DEBUG - 2011-09-17 13:05:53 --> Config Class Initialized
DEBUG - 2011-09-17 13:05:53 --> Hooks Class Initialized
DEBUG - 2011-09-17 13:05:53 --> Utf8 Class Initialized
DEBUG - 2011-09-17 13:05:53 --> UTF-8 Support Enabled
DEBUG - 2011-09-17 13:05:53 --> URI Class Initialized
DEBUG - 2011-09-17 13:05:53 --> Router Class Initialized
DEBUG - 2011-09-17 13:05:53 --> Output Class Initialized
DEBUG - 2011-09-17 13:05:53 --> Input Class Initialized
DEBUG - 2011-09-17 13:05:53 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-17 13:05:53 --> Language Class Initialized
DEBUG - 2011-09-17 13:05:53 --> Loader Class Initialized
DEBUG - 2011-09-17 13:05:53 --> Controller Class Initialized
DEBUG - 2011-09-17 13:05:53 --> Model Class Initialized
DEBUG - 2011-09-17 13:05:53 --> Model Class Initialized
DEBUG - 2011-09-17 13:05:53 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-17 13:05:53 --> Database Driver Class Initialized
DEBUG - 2011-09-17 13:05:53 --> Final output sent to browser
DEBUG - 2011-09-17 13:05:53 --> Total execution time: 0.4903
DEBUG - 2011-09-17 13:06:10 --> Config Class Initialized
DEBUG - 2011-09-17 13:06:10 --> Hooks Class Initialized
DEBUG - 2011-09-17 13:06:10 --> Utf8 Class Initialized
DEBUG - 2011-09-17 13:06:10 --> UTF-8 Support Enabled
DEBUG - 2011-09-17 13:06:10 --> URI Class Initialized
DEBUG - 2011-09-17 13:06:10 --> Router Class Initialized
DEBUG - 2011-09-17 13:06:10 --> Output Class Initialized
DEBUG - 2011-09-17 13:06:10 --> Input Class Initialized
DEBUG - 2011-09-17 13:06:10 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-17 13:06:10 --> Language Class Initialized
DEBUG - 2011-09-17 13:06:10 --> Loader Class Initialized
DEBUG - 2011-09-17 13:06:10 --> Controller Class Initialized
ERROR - 2011-09-17 13:06:10 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-09-17 13:06:10 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-09-17 13:06:10 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-09-17 13:06:10 --> Model Class Initialized
DEBUG - 2011-09-17 13:06:10 --> Model Class Initialized
DEBUG - 2011-09-17 13:06:10 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-17 13:06:11 --> Database Driver Class Initialized
DEBUG - 2011-09-17 13:06:11 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-09-17 13:06:11 --> Helper loaded: url_helper
DEBUG - 2011-09-17 13:06:11 --> File loaded: application/views/common/header.php
DEBUG - 2011-09-17 13:06:11 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-09-17 13:06:11 --> File loaded: application/views/common/footer.php
DEBUG - 2011-09-17 13:06:11 --> File loaded: application/views/layout/main.php
DEBUG - 2011-09-17 13:06:11 --> Final output sent to browser
DEBUG - 2011-09-17 13:06:11 --> Total execution time: 0.0325
DEBUG - 2011-09-17 13:06:11 --> Config Class Initialized
DEBUG - 2011-09-17 13:06:11 --> Hooks Class Initialized
DEBUG - 2011-09-17 13:06:11 --> Utf8 Class Initialized
DEBUG - 2011-09-17 13:06:11 --> UTF-8 Support Enabled
DEBUG - 2011-09-17 13:06:11 --> URI Class Initialized
DEBUG - 2011-09-17 13:06:11 --> Router Class Initialized
DEBUG - 2011-09-17 13:06:11 --> Output Class Initialized
DEBUG - 2011-09-17 13:06:11 --> Input Class Initialized
DEBUG - 2011-09-17 13:06:11 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-17 13:06:11 --> Language Class Initialized
DEBUG - 2011-09-17 13:06:11 --> Loader Class Initialized
DEBUG - 2011-09-17 13:06:11 --> Controller Class Initialized
DEBUG - 2011-09-17 13:06:11 --> Model Class Initialized
DEBUG - 2011-09-17 13:06:11 --> Model Class Initialized
DEBUG - 2011-09-17 13:06:11 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-17 13:06:11 --> Database Driver Class Initialized
DEBUG - 2011-09-17 13:06:12 --> Final output sent to browser
DEBUG - 2011-09-17 13:06:12 --> Total execution time: 0.4848
DEBUG - 2011-09-17 13:06:17 --> Config Class Initialized
DEBUG - 2011-09-17 13:06:17 --> Hooks Class Initialized
DEBUG - 2011-09-17 13:06:17 --> Utf8 Class Initialized
DEBUG - 2011-09-17 13:06:17 --> UTF-8 Support Enabled
DEBUG - 2011-09-17 13:06:17 --> URI Class Initialized
DEBUG - 2011-09-17 13:06:17 --> Router Class Initialized
DEBUG - 2011-09-17 13:06:17 --> Output Class Initialized
DEBUG - 2011-09-17 13:06:17 --> Input Class Initialized
DEBUG - 2011-09-17 13:06:17 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-17 13:06:17 --> Language Class Initialized
DEBUG - 2011-09-17 13:06:17 --> Loader Class Initialized
DEBUG - 2011-09-17 13:06:17 --> Controller Class Initialized
ERROR - 2011-09-17 13:06:17 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-09-17 13:06:17 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-09-17 13:06:17 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-09-17 13:06:17 --> Model Class Initialized
DEBUG - 2011-09-17 13:06:17 --> Model Class Initialized
DEBUG - 2011-09-17 13:06:17 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-17 13:06:17 --> Database Driver Class Initialized
DEBUG - 2011-09-17 13:06:17 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-09-17 13:06:17 --> Helper loaded: url_helper
DEBUG - 2011-09-17 13:06:17 --> File loaded: application/views/common/header.php
DEBUG - 2011-09-17 13:06:17 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-09-17 13:06:17 --> File loaded: application/views/common/footer.php
DEBUG - 2011-09-17 13:06:17 --> File loaded: application/views/layout/main.php
DEBUG - 2011-09-17 13:06:17 --> Final output sent to browser
DEBUG - 2011-09-17 13:06:17 --> Total execution time: 0.0286
DEBUG - 2011-09-17 13:06:18 --> Config Class Initialized
DEBUG - 2011-09-17 13:06:18 --> Hooks Class Initialized
DEBUG - 2011-09-17 13:06:18 --> Utf8 Class Initialized
DEBUG - 2011-09-17 13:06:18 --> UTF-8 Support Enabled
DEBUG - 2011-09-17 13:06:18 --> URI Class Initialized
DEBUG - 2011-09-17 13:06:18 --> Router Class Initialized
DEBUG - 2011-09-17 13:06:18 --> Output Class Initialized
DEBUG - 2011-09-17 13:06:18 --> Input Class Initialized
DEBUG - 2011-09-17 13:06:18 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-17 13:06:18 --> Language Class Initialized
DEBUG - 2011-09-17 13:06:18 --> Loader Class Initialized
DEBUG - 2011-09-17 13:06:18 --> Controller Class Initialized
ERROR - 2011-09-17 13:06:18 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-09-17 13:06:18 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-09-17 13:06:18 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-09-17 13:06:18 --> Model Class Initialized
DEBUG - 2011-09-17 13:06:18 --> Model Class Initialized
DEBUG - 2011-09-17 13:06:18 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-17 13:06:18 --> Database Driver Class Initialized
DEBUG - 2011-09-17 13:06:18 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-09-17 13:06:18 --> Helper loaded: url_helper
DEBUG - 2011-09-17 13:06:18 --> File loaded: application/views/common/header.php
DEBUG - 2011-09-17 13:06:18 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-09-17 13:06:18 --> File loaded: application/views/common/footer.php
DEBUG - 2011-09-17 13:06:18 --> File loaded: application/views/layout/main.php
DEBUG - 2011-09-17 13:06:18 --> Final output sent to browser
DEBUG - 2011-09-17 13:06:18 --> Total execution time: 0.0458
DEBUG - 2011-09-17 13:06:23 --> Config Class Initialized
DEBUG - 2011-09-17 13:06:23 --> Hooks Class Initialized
DEBUG - 2011-09-17 13:06:23 --> Utf8 Class Initialized
DEBUG - 2011-09-17 13:06:23 --> UTF-8 Support Enabled
DEBUG - 2011-09-17 13:06:23 --> URI Class Initialized
DEBUG - 2011-09-17 13:06:23 --> Router Class Initialized
DEBUG - 2011-09-17 13:06:23 --> Output Class Initialized
DEBUG - 2011-09-17 13:06:23 --> Input Class Initialized
DEBUG - 2011-09-17 13:06:23 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-17 13:06:23 --> Language Class Initialized
DEBUG - 2011-09-17 13:06:23 --> Loader Class Initialized
DEBUG - 2011-09-17 13:06:23 --> Controller Class Initialized
ERROR - 2011-09-17 13:06:23 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-09-17 13:06:23 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-09-17 13:06:23 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-09-17 13:06:23 --> Model Class Initialized
DEBUG - 2011-09-17 13:06:23 --> Model Class Initialized
DEBUG - 2011-09-17 13:06:23 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-17 13:06:23 --> Database Driver Class Initialized
DEBUG - 2011-09-17 13:06:23 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-09-17 13:06:23 --> Helper loaded: url_helper
DEBUG - 2011-09-17 13:06:23 --> File loaded: application/views/common/header.php
DEBUG - 2011-09-17 13:06:23 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-09-17 13:06:23 --> File loaded: application/views/common/footer.php
DEBUG - 2011-09-17 13:06:23 --> File loaded: application/views/layout/main.php
DEBUG - 2011-09-17 13:06:23 --> Final output sent to browser
DEBUG - 2011-09-17 13:06:23 --> Total execution time: 0.0299
DEBUG - 2011-09-17 13:06:23 --> Config Class Initialized
DEBUG - 2011-09-17 13:06:23 --> Hooks Class Initialized
DEBUG - 2011-09-17 13:06:23 --> Utf8 Class Initialized
DEBUG - 2011-09-17 13:06:23 --> UTF-8 Support Enabled
DEBUG - 2011-09-17 13:06:23 --> URI Class Initialized
DEBUG - 2011-09-17 13:06:23 --> Router Class Initialized
DEBUG - 2011-09-17 13:06:23 --> Output Class Initialized
DEBUG - 2011-09-17 13:06:23 --> Input Class Initialized
DEBUG - 2011-09-17 13:06:23 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-17 13:06:23 --> Language Class Initialized
DEBUG - 2011-09-17 13:06:23 --> Loader Class Initialized
DEBUG - 2011-09-17 13:06:23 --> Controller Class Initialized
DEBUG - 2011-09-17 13:06:23 --> Model Class Initialized
DEBUG - 2011-09-17 13:06:23 --> Model Class Initialized
DEBUG - 2011-09-17 13:06:23 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-17 13:06:23 --> Database Driver Class Initialized
DEBUG - 2011-09-17 13:06:23 --> Final output sent to browser
DEBUG - 2011-09-17 13:06:23 --> Total execution time: 0.5252
DEBUG - 2011-09-17 13:06:24 --> Config Class Initialized
DEBUG - 2011-09-17 13:06:24 --> Hooks Class Initialized
DEBUG - 2011-09-17 13:06:24 --> Utf8 Class Initialized
DEBUG - 2011-09-17 13:06:24 --> UTF-8 Support Enabled
DEBUG - 2011-09-17 13:06:24 --> URI Class Initialized
DEBUG - 2011-09-17 13:06:24 --> Router Class Initialized
DEBUG - 2011-09-17 13:06:24 --> Output Class Initialized
DEBUG - 2011-09-17 13:06:24 --> Input Class Initialized
DEBUG - 2011-09-17 13:06:24 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-17 13:06:24 --> Language Class Initialized
DEBUG - 2011-09-17 13:06:24 --> Loader Class Initialized
DEBUG - 2011-09-17 13:06:24 --> Controller Class Initialized
ERROR - 2011-09-17 13:06:24 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-09-17 13:06:24 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-09-17 13:06:24 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-09-17 13:06:24 --> Model Class Initialized
DEBUG - 2011-09-17 13:06:24 --> Model Class Initialized
DEBUG - 2011-09-17 13:06:24 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-17 13:06:24 --> Database Driver Class Initialized
DEBUG - 2011-09-17 13:06:24 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-09-17 13:06:24 --> Helper loaded: url_helper
DEBUG - 2011-09-17 13:06:24 --> File loaded: application/views/common/header.php
DEBUG - 2011-09-17 13:06:24 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-09-17 13:06:24 --> File loaded: application/views/common/footer.php
DEBUG - 2011-09-17 13:06:24 --> File loaded: application/views/layout/main.php
DEBUG - 2011-09-17 13:06:24 --> Final output sent to browser
DEBUG - 2011-09-17 13:06:24 --> Total execution time: 0.0288
DEBUG - 2011-09-17 13:06:35 --> Config Class Initialized
DEBUG - 2011-09-17 13:06:35 --> Hooks Class Initialized
DEBUG - 2011-09-17 13:06:35 --> Utf8 Class Initialized
DEBUG - 2011-09-17 13:06:35 --> UTF-8 Support Enabled
DEBUG - 2011-09-17 13:06:35 --> URI Class Initialized
DEBUG - 2011-09-17 13:06:35 --> Router Class Initialized
DEBUG - 2011-09-17 13:06:35 --> Output Class Initialized
DEBUG - 2011-09-17 13:06:35 --> Input Class Initialized
DEBUG - 2011-09-17 13:06:35 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-17 13:06:35 --> Language Class Initialized
DEBUG - 2011-09-17 13:06:35 --> Loader Class Initialized
DEBUG - 2011-09-17 13:06:35 --> Controller Class Initialized
ERROR - 2011-09-17 13:06:35 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-09-17 13:06:35 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-09-17 13:06:35 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-09-17 13:06:35 --> Model Class Initialized
DEBUG - 2011-09-17 13:06:35 --> Model Class Initialized
DEBUG - 2011-09-17 13:06:35 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-17 13:06:35 --> Database Driver Class Initialized
DEBUG - 2011-09-17 13:06:35 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-09-17 13:06:35 --> Helper loaded: url_helper
DEBUG - 2011-09-17 13:06:35 --> File loaded: application/views/common/header.php
DEBUG - 2011-09-17 13:06:35 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-09-17 13:06:35 --> File loaded: application/views/common/footer.php
DEBUG - 2011-09-17 13:06:35 --> File loaded: application/views/layout/main.php
DEBUG - 2011-09-17 13:06:35 --> Final output sent to browser
DEBUG - 2011-09-17 13:06:35 --> Total execution time: 0.0334
DEBUG - 2011-09-17 13:06:35 --> Config Class Initialized
DEBUG - 2011-09-17 13:06:35 --> Hooks Class Initialized
DEBUG - 2011-09-17 13:06:35 --> Utf8 Class Initialized
DEBUG - 2011-09-17 13:06:35 --> UTF-8 Support Enabled
DEBUG - 2011-09-17 13:06:35 --> URI Class Initialized
DEBUG - 2011-09-17 13:06:35 --> Router Class Initialized
DEBUG - 2011-09-17 13:06:35 --> Output Class Initialized
DEBUG - 2011-09-17 13:06:35 --> Input Class Initialized
DEBUG - 2011-09-17 13:06:35 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-17 13:06:35 --> Language Class Initialized
DEBUG - 2011-09-17 13:06:35 --> Loader Class Initialized
DEBUG - 2011-09-17 13:06:35 --> Controller Class Initialized
DEBUG - 2011-09-17 13:06:35 --> Model Class Initialized
DEBUG - 2011-09-17 13:06:35 --> Model Class Initialized
DEBUG - 2011-09-17 13:06:35 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-17 13:06:35 --> Database Driver Class Initialized
DEBUG - 2011-09-17 13:06:36 --> Final output sent to browser
DEBUG - 2011-09-17 13:06:36 --> Total execution time: 0.5078
DEBUG - 2011-09-17 13:07:10 --> Config Class Initialized
DEBUG - 2011-09-17 13:07:10 --> Hooks Class Initialized
DEBUG - 2011-09-17 13:07:10 --> Utf8 Class Initialized
DEBUG - 2011-09-17 13:07:10 --> UTF-8 Support Enabled
DEBUG - 2011-09-17 13:07:10 --> URI Class Initialized
DEBUG - 2011-09-17 13:07:10 --> Router Class Initialized
DEBUG - 2011-09-17 13:07:10 --> Output Class Initialized
DEBUG - 2011-09-17 13:07:10 --> Input Class Initialized
DEBUG - 2011-09-17 13:07:10 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-17 13:07:10 --> Language Class Initialized
DEBUG - 2011-09-17 13:07:10 --> Loader Class Initialized
DEBUG - 2011-09-17 13:07:10 --> Controller Class Initialized
DEBUG - 2011-09-17 13:07:10 --> Model Class Initialized
DEBUG - 2011-09-17 13:07:10 --> Model Class Initialized
DEBUG - 2011-09-17 13:07:10 --> Model Class Initialized
DEBUG - 2011-09-17 13:07:10 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-17 13:07:10 --> Database Driver Class Initialized
DEBUG - 2011-09-17 13:07:10 --> File loaded: application/views/table/main.php
DEBUG - 2011-09-17 13:07:10 --> Helper loaded: url_helper
DEBUG - 2011-09-17 13:07:10 --> File loaded: application/views/common/header.php
DEBUG - 2011-09-17 13:07:10 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-09-17 13:07:10 --> File loaded: application/views/common/footer.php
DEBUG - 2011-09-17 13:07:10 --> File loaded: application/views/layout/main.php
DEBUG - 2011-09-17 13:07:10 --> Final output sent to browser
DEBUG - 2011-09-17 13:07:10 --> Total execution time: 0.0535
DEBUG - 2011-09-17 13:27:37 --> Config Class Initialized
DEBUG - 2011-09-17 13:27:37 --> Hooks Class Initialized
DEBUG - 2011-09-17 13:27:37 --> Utf8 Class Initialized
DEBUG - 2011-09-17 13:27:37 --> UTF-8 Support Enabled
DEBUG - 2011-09-17 13:27:37 --> URI Class Initialized
DEBUG - 2011-09-17 13:27:37 --> Router Class Initialized
DEBUG - 2011-09-17 13:27:37 --> No URI present. Default controller set.
DEBUG - 2011-09-17 13:27:37 --> Output Class Initialized
DEBUG - 2011-09-17 13:27:37 --> Input Class Initialized
DEBUG - 2011-09-17 13:27:37 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-17 13:27:37 --> Language Class Initialized
DEBUG - 2011-09-17 13:27:37 --> Loader Class Initialized
DEBUG - 2011-09-17 13:27:37 --> Controller Class Initialized
DEBUG - 2011-09-17 13:27:37 --> File loaded: application/views/splash/main.php
DEBUG - 2011-09-17 13:27:37 --> Helper loaded: url_helper
DEBUG - 2011-09-17 13:27:37 --> File loaded: application/views/common/header.php
DEBUG - 2011-09-17 13:27:37 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-09-17 13:27:37 --> File loaded: application/views/common/footer.php
DEBUG - 2011-09-17 13:27:37 --> File loaded: application/views/layout/main.php
DEBUG - 2011-09-17 13:27:37 --> Final output sent to browser
DEBUG - 2011-09-17 13:27:37 --> Total execution time: 0.0143
DEBUG - 2011-09-17 13:32:23 --> Config Class Initialized
DEBUG - 2011-09-17 13:32:23 --> Hooks Class Initialized
DEBUG - 2011-09-17 13:32:23 --> Utf8 Class Initialized
DEBUG - 2011-09-17 13:32:23 --> UTF-8 Support Enabled
DEBUG - 2011-09-17 13:32:23 --> URI Class Initialized
DEBUG - 2011-09-17 13:32:23 --> Router Class Initialized
DEBUG - 2011-09-17 13:32:23 --> Output Class Initialized
DEBUG - 2011-09-17 13:32:23 --> Input Class Initialized
DEBUG - 2011-09-17 13:32:23 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-17 13:32:23 --> Language Class Initialized
DEBUG - 2011-09-17 13:32:23 --> Loader Class Initialized
DEBUG - 2011-09-17 13:32:23 --> Controller Class Initialized
DEBUG - 2011-09-17 13:32:23 --> Model Class Initialized
DEBUG - 2011-09-17 13:32:23 --> Model Class Initialized
DEBUG - 2011-09-17 13:32:23 --> Model Class Initialized
DEBUG - 2011-09-17 13:32:23 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-17 13:32:23 --> Database Driver Class Initialized
DEBUG - 2011-09-17 13:32:23 --> File loaded: application/views/table/main.php
DEBUG - 2011-09-17 13:32:23 --> Helper loaded: url_helper
DEBUG - 2011-09-17 13:32:23 --> File loaded: application/views/common/header.php
DEBUG - 2011-09-17 13:32:23 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-09-17 13:32:23 --> File loaded: application/views/common/footer.php
DEBUG - 2011-09-17 13:32:23 --> File loaded: application/views/layout/main.php
DEBUG - 2011-09-17 13:32:23 --> Final output sent to browser
DEBUG - 2011-09-17 13:32:23 --> Total execution time: 0.5375
DEBUG - 2011-09-17 13:32:59 --> Config Class Initialized
DEBUG - 2011-09-17 13:32:59 --> Hooks Class Initialized
DEBUG - 2011-09-17 13:32:59 --> Utf8 Class Initialized
DEBUG - 2011-09-17 13:32:59 --> UTF-8 Support Enabled
DEBUG - 2011-09-17 13:32:59 --> URI Class Initialized
DEBUG - 2011-09-17 13:32:59 --> Router Class Initialized
ERROR - 2011-09-17 13:32:59 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-09-17 13:33:16 --> Config Class Initialized
DEBUG - 2011-09-17 13:33:16 --> Hooks Class Initialized
DEBUG - 2011-09-17 13:33:16 --> Utf8 Class Initialized
DEBUG - 2011-09-17 13:33:16 --> UTF-8 Support Enabled
DEBUG - 2011-09-17 13:33:16 --> URI Class Initialized
DEBUG - 2011-09-17 13:33:16 --> Router Class Initialized
DEBUG - 2011-09-17 13:33:16 --> Output Class Initialized
DEBUG - 2011-09-17 13:33:16 --> Input Class Initialized
DEBUG - 2011-09-17 13:33:16 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-17 13:33:16 --> Language Class Initialized
DEBUG - 2011-09-17 13:33:16 --> Loader Class Initialized
DEBUG - 2011-09-17 13:33:16 --> Controller Class Initialized
DEBUG - 2011-09-17 13:33:16 --> Model Class Initialized
DEBUG - 2011-09-17 13:33:16 --> Model Class Initialized
DEBUG - 2011-09-17 13:33:16 --> Model Class Initialized
DEBUG - 2011-09-17 13:33:16 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-17 13:33:16 --> Database Driver Class Initialized
DEBUG - 2011-09-17 13:33:17 --> File loaded: application/views/table/main.php
DEBUG - 2011-09-17 13:33:17 --> Helper loaded: url_helper
DEBUG - 2011-09-17 13:33:17 --> File loaded: application/views/common/header.php
DEBUG - 2011-09-17 13:33:17 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-09-17 13:33:17 --> File loaded: application/views/common/footer.php
DEBUG - 2011-09-17 13:33:17 --> File loaded: application/views/layout/main.php
DEBUG - 2011-09-17 13:33:17 --> Final output sent to browser
DEBUG - 2011-09-17 13:33:17 --> Total execution time: 1.2549
DEBUG - 2011-09-17 13:33:38 --> Config Class Initialized
DEBUG - 2011-09-17 13:33:38 --> Hooks Class Initialized
DEBUG - 2011-09-17 13:33:38 --> Utf8 Class Initialized
DEBUG - 2011-09-17 13:33:38 --> UTF-8 Support Enabled
DEBUG - 2011-09-17 13:33:38 --> URI Class Initialized
DEBUG - 2011-09-17 13:33:38 --> Router Class Initialized
DEBUG - 2011-09-17 13:33:38 --> Output Class Initialized
DEBUG - 2011-09-17 13:33:38 --> Input Class Initialized
DEBUG - 2011-09-17 13:33:38 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-17 13:33:38 --> Language Class Initialized
DEBUG - 2011-09-17 13:33:38 --> Loader Class Initialized
DEBUG - 2011-09-17 13:33:38 --> Controller Class Initialized
DEBUG - 2011-09-17 13:33:38 --> Model Class Initialized
DEBUG - 2011-09-17 13:33:38 --> Model Class Initialized
DEBUG - 2011-09-17 13:33:38 --> Model Class Initialized
DEBUG - 2011-09-17 13:33:38 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-17 13:33:38 --> Database Driver Class Initialized
DEBUG - 2011-09-17 13:33:38 --> File loaded: application/views/table/main.php
DEBUG - 2011-09-17 13:33:38 --> Helper loaded: url_helper
DEBUG - 2011-09-17 13:33:38 --> File loaded: application/views/common/header.php
DEBUG - 2011-09-17 13:33:38 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-09-17 13:33:38 --> File loaded: application/views/common/footer.php
DEBUG - 2011-09-17 13:33:38 --> File loaded: application/views/layout/main.php
DEBUG - 2011-09-17 13:33:38 --> Final output sent to browser
DEBUG - 2011-09-17 13:33:38 --> Total execution time: 0.2656
DEBUG - 2011-09-17 13:34:27 --> Config Class Initialized
DEBUG - 2011-09-17 13:34:27 --> Hooks Class Initialized
DEBUG - 2011-09-17 13:34:27 --> Utf8 Class Initialized
DEBUG - 2011-09-17 13:34:27 --> UTF-8 Support Enabled
DEBUG - 2011-09-17 13:34:27 --> URI Class Initialized
DEBUG - 2011-09-17 13:34:27 --> Router Class Initialized
DEBUG - 2011-09-17 13:34:27 --> Output Class Initialized
DEBUG - 2011-09-17 13:34:27 --> Input Class Initialized
DEBUG - 2011-09-17 13:34:27 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-17 13:34:27 --> Language Class Initialized
DEBUG - 2011-09-17 13:34:27 --> Loader Class Initialized
DEBUG - 2011-09-17 13:34:27 --> Controller Class Initialized
DEBUG - 2011-09-17 13:34:27 --> Model Class Initialized
DEBUG - 2011-09-17 13:34:27 --> Model Class Initialized
DEBUG - 2011-09-17 13:34:27 --> Model Class Initialized
DEBUG - 2011-09-17 13:34:27 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-17 13:34:27 --> Database Driver Class Initialized
DEBUG - 2011-09-17 13:34:27 --> File loaded: application/views/table/main.php
DEBUG - 2011-09-17 13:34:27 --> Helper loaded: url_helper
DEBUG - 2011-09-17 13:34:27 --> File loaded: application/views/common/header.php
DEBUG - 2011-09-17 13:34:27 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-09-17 13:34:27 --> File loaded: application/views/common/footer.php
DEBUG - 2011-09-17 13:34:27 --> File loaded: application/views/layout/main.php
DEBUG - 2011-09-17 13:34:27 --> Final output sent to browser
DEBUG - 2011-09-17 13:34:27 --> Total execution time: 0.0423
DEBUG - 2011-09-17 13:34:42 --> Config Class Initialized
DEBUG - 2011-09-17 13:34:42 --> Hooks Class Initialized
DEBUG - 2011-09-17 13:34:42 --> Utf8 Class Initialized
DEBUG - 2011-09-17 13:34:42 --> UTF-8 Support Enabled
DEBUG - 2011-09-17 13:34:42 --> URI Class Initialized
DEBUG - 2011-09-17 13:34:42 --> Router Class Initialized
DEBUG - 2011-09-17 13:34:42 --> Output Class Initialized
DEBUG - 2011-09-17 13:34:42 --> Input Class Initialized
DEBUG - 2011-09-17 13:34:42 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-17 13:34:42 --> Language Class Initialized
DEBUG - 2011-09-17 13:34:42 --> Loader Class Initialized
DEBUG - 2011-09-17 13:34:42 --> Controller Class Initialized
ERROR - 2011-09-17 13:34:42 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-09-17 13:34:42 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-09-17 13:34:42 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-09-17 13:34:42 --> Model Class Initialized
DEBUG - 2011-09-17 13:34:42 --> Model Class Initialized
DEBUG - 2011-09-17 13:34:42 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-17 13:34:42 --> Database Driver Class Initialized
DEBUG - 2011-09-17 13:34:42 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-09-17 13:34:42 --> Helper loaded: url_helper
DEBUG - 2011-09-17 13:34:42 --> File loaded: application/views/common/header.php
DEBUG - 2011-09-17 13:34:42 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-09-17 13:34:42 --> File loaded: application/views/common/footer.php
DEBUG - 2011-09-17 13:34:42 --> File loaded: application/views/layout/main.php
DEBUG - 2011-09-17 13:34:42 --> Final output sent to browser
DEBUG - 2011-09-17 13:34:42 --> Total execution time: 0.0286
DEBUG - 2011-09-17 13:34:44 --> Config Class Initialized
DEBUG - 2011-09-17 13:34:44 --> Hooks Class Initialized
DEBUG - 2011-09-17 13:34:44 --> Utf8 Class Initialized
DEBUG - 2011-09-17 13:34:44 --> UTF-8 Support Enabled
DEBUG - 2011-09-17 13:34:44 --> URI Class Initialized
DEBUG - 2011-09-17 13:34:44 --> Router Class Initialized
DEBUG - 2011-09-17 13:34:44 --> Output Class Initialized
DEBUG - 2011-09-17 13:34:44 --> Input Class Initialized
DEBUG - 2011-09-17 13:34:44 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-17 13:34:44 --> Language Class Initialized
DEBUG - 2011-09-17 13:34:44 --> Loader Class Initialized
DEBUG - 2011-09-17 13:34:44 --> Controller Class Initialized
DEBUG - 2011-09-17 13:34:44 --> Model Class Initialized
DEBUG - 2011-09-17 13:34:44 --> Model Class Initialized
DEBUG - 2011-09-17 13:34:44 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-17 13:34:44 --> Database Driver Class Initialized
DEBUG - 2011-09-17 13:34:44 --> Final output sent to browser
DEBUG - 2011-09-17 13:34:44 --> Total execution time: 0.5482
DEBUG - 2011-09-17 13:36:14 --> Config Class Initialized
DEBUG - 2011-09-17 13:36:14 --> Hooks Class Initialized
DEBUG - 2011-09-17 13:36:14 --> Utf8 Class Initialized
DEBUG - 2011-09-17 13:36:14 --> UTF-8 Support Enabled
DEBUG - 2011-09-17 13:36:14 --> URI Class Initialized
DEBUG - 2011-09-17 13:36:14 --> Router Class Initialized
DEBUG - 2011-09-17 13:36:14 --> Output Class Initialized
DEBUG - 2011-09-17 13:36:14 --> Input Class Initialized
DEBUG - 2011-09-17 13:36:14 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-17 13:36:14 --> Language Class Initialized
DEBUG - 2011-09-17 13:36:14 --> Loader Class Initialized
DEBUG - 2011-09-17 13:36:14 --> Controller Class Initialized
ERROR - 2011-09-17 13:36:14 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-09-17 13:36:14 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-09-17 13:36:14 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-09-17 13:36:14 --> Model Class Initialized
DEBUG - 2011-09-17 13:36:14 --> Model Class Initialized
DEBUG - 2011-09-17 13:36:14 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-17 13:36:14 --> Database Driver Class Initialized
DEBUG - 2011-09-17 13:36:14 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-09-17 13:36:14 --> Helper loaded: url_helper
DEBUG - 2011-09-17 13:36:14 --> File loaded: application/views/common/header.php
DEBUG - 2011-09-17 13:36:14 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-09-17 13:36:14 --> File loaded: application/views/common/footer.php
DEBUG - 2011-09-17 13:36:14 --> File loaded: application/views/layout/main.php
DEBUG - 2011-09-17 13:36:14 --> Final output sent to browser
DEBUG - 2011-09-17 13:36:14 --> Total execution time: 0.0309
DEBUG - 2011-09-17 13:36:17 --> Config Class Initialized
DEBUG - 2011-09-17 13:36:17 --> Hooks Class Initialized
DEBUG - 2011-09-17 13:36:17 --> Utf8 Class Initialized
DEBUG - 2011-09-17 13:36:17 --> UTF-8 Support Enabled
DEBUG - 2011-09-17 13:36:17 --> URI Class Initialized
DEBUG - 2011-09-17 13:36:17 --> Router Class Initialized
DEBUG - 2011-09-17 13:36:17 --> Output Class Initialized
DEBUG - 2011-09-17 13:36:17 --> Input Class Initialized
DEBUG - 2011-09-17 13:36:17 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-17 13:36:17 --> Language Class Initialized
DEBUG - 2011-09-17 13:36:17 --> Loader Class Initialized
DEBUG - 2011-09-17 13:36:17 --> Controller Class Initialized
DEBUG - 2011-09-17 13:36:17 --> Model Class Initialized
DEBUG - 2011-09-17 13:36:17 --> Model Class Initialized
DEBUG - 2011-09-17 13:36:17 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-17 13:36:17 --> Database Driver Class Initialized
DEBUG - 2011-09-17 13:36:18 --> Final output sent to browser
DEBUG - 2011-09-17 13:36:18 --> Total execution time: 0.6426
DEBUG - 2011-09-17 13:36:21 --> Config Class Initialized
DEBUG - 2011-09-17 13:36:21 --> Hooks Class Initialized
DEBUG - 2011-09-17 13:36:21 --> Utf8 Class Initialized
DEBUG - 2011-09-17 13:36:21 --> UTF-8 Support Enabled
DEBUG - 2011-09-17 13:36:21 --> URI Class Initialized
DEBUG - 2011-09-17 13:36:21 --> Router Class Initialized
DEBUG - 2011-09-17 13:36:21 --> Output Class Initialized
DEBUG - 2011-09-17 13:36:21 --> Input Class Initialized
DEBUG - 2011-09-17 13:36:21 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-17 13:36:21 --> Language Class Initialized
DEBUG - 2011-09-17 13:36:21 --> Loader Class Initialized
DEBUG - 2011-09-17 13:36:21 --> Controller Class Initialized
ERROR - 2011-09-17 13:36:21 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-09-17 13:36:21 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-09-17 13:36:21 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-09-17 13:36:21 --> Model Class Initialized
DEBUG - 2011-09-17 13:36:21 --> Model Class Initialized
DEBUG - 2011-09-17 13:36:21 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-17 13:36:21 --> Database Driver Class Initialized
DEBUG - 2011-09-17 13:36:21 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-09-17 13:36:21 --> Helper loaded: url_helper
DEBUG - 2011-09-17 13:36:21 --> File loaded: application/views/common/header.php
DEBUG - 2011-09-17 13:36:21 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-09-17 13:36:21 --> File loaded: application/views/common/footer.php
DEBUG - 2011-09-17 13:36:21 --> File loaded: application/views/layout/main.php
DEBUG - 2011-09-17 13:36:21 --> Final output sent to browser
DEBUG - 2011-09-17 13:36:21 --> Total execution time: 0.1525
DEBUG - 2011-09-17 13:50:25 --> Config Class Initialized
DEBUG - 2011-09-17 13:50:25 --> Hooks Class Initialized
DEBUG - 2011-09-17 13:50:25 --> Utf8 Class Initialized
DEBUG - 2011-09-17 13:50:25 --> UTF-8 Support Enabled
DEBUG - 2011-09-17 13:50:25 --> URI Class Initialized
DEBUG - 2011-09-17 13:50:25 --> Router Class Initialized
DEBUG - 2011-09-17 13:50:25 --> Output Class Initialized
DEBUG - 2011-09-17 13:50:25 --> Input Class Initialized
DEBUG - 2011-09-17 13:50:25 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-17 13:50:25 --> Language Class Initialized
DEBUG - 2011-09-17 13:50:25 --> Loader Class Initialized
DEBUG - 2011-09-17 13:50:25 --> Controller Class Initialized
DEBUG - 2011-09-17 13:50:25 --> Model Class Initialized
DEBUG - 2011-09-17 13:50:25 --> Model Class Initialized
DEBUG - 2011-09-17 13:50:25 --> Model Class Initialized
DEBUG - 2011-09-17 13:50:25 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-17 13:50:25 --> Database Driver Class Initialized
DEBUG - 2011-09-17 13:50:26 --> File loaded: application/views/table/main.php
DEBUG - 2011-09-17 13:50:26 --> Helper loaded: url_helper
DEBUG - 2011-09-17 13:50:26 --> File loaded: application/views/common/header.php
DEBUG - 2011-09-17 13:50:26 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-09-17 13:50:26 --> File loaded: application/views/common/footer.php
DEBUG - 2011-09-17 13:50:26 --> File loaded: application/views/layout/main.php
DEBUG - 2011-09-17 13:50:26 --> Final output sent to browser
DEBUG - 2011-09-17 13:50:26 --> Total execution time: 0.3541
DEBUG - 2011-09-17 13:50:28 --> Config Class Initialized
DEBUG - 2011-09-17 13:50:28 --> Hooks Class Initialized
DEBUG - 2011-09-17 13:50:28 --> Utf8 Class Initialized
DEBUG - 2011-09-17 13:50:28 --> UTF-8 Support Enabled
DEBUG - 2011-09-17 13:50:28 --> URI Class Initialized
DEBUG - 2011-09-17 13:50:28 --> Router Class Initialized
ERROR - 2011-09-17 13:50:28 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-09-17 13:50:48 --> Config Class Initialized
DEBUG - 2011-09-17 13:50:48 --> Hooks Class Initialized
DEBUG - 2011-09-17 13:50:48 --> Utf8 Class Initialized
DEBUG - 2011-09-17 13:50:48 --> UTF-8 Support Enabled
DEBUG - 2011-09-17 13:50:48 --> URI Class Initialized
DEBUG - 2011-09-17 13:50:48 --> Router Class Initialized
DEBUG - 2011-09-17 13:50:48 --> Output Class Initialized
DEBUG - 2011-09-17 13:50:48 --> Input Class Initialized
DEBUG - 2011-09-17 13:50:48 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-17 13:50:48 --> Language Class Initialized
DEBUG - 2011-09-17 13:50:48 --> Loader Class Initialized
DEBUG - 2011-09-17 13:50:48 --> Controller Class Initialized
DEBUG - 2011-09-17 13:50:48 --> Model Class Initialized
DEBUG - 2011-09-17 13:50:48 --> Model Class Initialized
DEBUG - 2011-09-17 13:50:48 --> Model Class Initialized
DEBUG - 2011-09-17 13:50:48 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-17 13:50:48 --> Database Driver Class Initialized
DEBUG - 2011-09-17 13:50:49 --> File loaded: application/views/table/main.php
DEBUG - 2011-09-17 13:50:49 --> Helper loaded: url_helper
DEBUG - 2011-09-17 13:50:49 --> File loaded: application/views/common/header.php
DEBUG - 2011-09-17 13:50:49 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-09-17 13:50:49 --> File loaded: application/views/common/footer.php
DEBUG - 2011-09-17 13:50:49 --> File loaded: application/views/layout/main.php
DEBUG - 2011-09-17 13:50:49 --> Final output sent to browser
DEBUG - 2011-09-17 13:50:49 --> Total execution time: 0.4660
DEBUG - 2011-09-17 13:50:50 --> Config Class Initialized
DEBUG - 2011-09-17 13:50:50 --> Hooks Class Initialized
DEBUG - 2011-09-17 13:50:50 --> Utf8 Class Initialized
DEBUG - 2011-09-17 13:50:50 --> UTF-8 Support Enabled
DEBUG - 2011-09-17 13:50:50 --> URI Class Initialized
DEBUG - 2011-09-17 13:50:50 --> Router Class Initialized
ERROR - 2011-09-17 13:50:50 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-09-17 13:54:34 --> Config Class Initialized
DEBUG - 2011-09-17 13:54:34 --> Hooks Class Initialized
DEBUG - 2011-09-17 13:54:34 --> Utf8 Class Initialized
DEBUG - 2011-09-17 13:54:34 --> UTF-8 Support Enabled
DEBUG - 2011-09-17 13:54:34 --> URI Class Initialized
DEBUG - 2011-09-17 13:54:34 --> Router Class Initialized
DEBUG - 2011-09-17 13:54:34 --> Output Class Initialized
DEBUG - 2011-09-17 13:54:34 --> Input Class Initialized
DEBUG - 2011-09-17 13:54:34 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-17 13:54:34 --> Language Class Initialized
DEBUG - 2011-09-17 13:54:34 --> Loader Class Initialized
DEBUG - 2011-09-17 13:54:34 --> Controller Class Initialized
ERROR - 2011-09-17 13:54:34 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-09-17 13:54:34 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-09-17 13:54:34 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-09-17 13:54:34 --> Model Class Initialized
DEBUG - 2011-09-17 13:54:34 --> Model Class Initialized
DEBUG - 2011-09-17 13:54:34 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-17 13:54:34 --> Database Driver Class Initialized
DEBUG - 2011-09-17 13:54:34 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-09-17 13:54:34 --> Helper loaded: url_helper
DEBUG - 2011-09-17 13:54:34 --> File loaded: application/views/common/header.php
DEBUG - 2011-09-17 13:54:34 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-09-17 13:54:34 --> File loaded: application/views/common/footer.php
DEBUG - 2011-09-17 13:54:34 --> File loaded: application/views/layout/main.php
DEBUG - 2011-09-17 13:54:34 --> Final output sent to browser
DEBUG - 2011-09-17 13:54:34 --> Total execution time: 0.0359
DEBUG - 2011-09-17 13:54:35 --> Config Class Initialized
DEBUG - 2011-09-17 13:54:35 --> Hooks Class Initialized
DEBUG - 2011-09-17 13:54:35 --> Utf8 Class Initialized
DEBUG - 2011-09-17 13:54:35 --> UTF-8 Support Enabled
DEBUG - 2011-09-17 13:54:35 --> URI Class Initialized
DEBUG - 2011-09-17 13:54:35 --> Router Class Initialized
DEBUG - 2011-09-17 13:54:35 --> Output Class Initialized
DEBUG - 2011-09-17 13:54:35 --> Input Class Initialized
DEBUG - 2011-09-17 13:54:35 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-17 13:54:35 --> Language Class Initialized
DEBUG - 2011-09-17 13:54:35 --> Loader Class Initialized
DEBUG - 2011-09-17 13:54:35 --> Controller Class Initialized
DEBUG - 2011-09-17 13:54:35 --> Model Class Initialized
DEBUG - 2011-09-17 13:54:35 --> Model Class Initialized
DEBUG - 2011-09-17 13:54:35 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-17 13:54:35 --> Database Driver Class Initialized
DEBUG - 2011-09-17 13:54:36 --> Final output sent to browser
DEBUG - 2011-09-17 13:54:36 --> Total execution time: 0.6306
DEBUG - 2011-09-17 13:54:37 --> Config Class Initialized
DEBUG - 2011-09-17 13:54:37 --> Hooks Class Initialized
DEBUG - 2011-09-17 13:54:37 --> Utf8 Class Initialized
DEBUG - 2011-09-17 13:54:37 --> UTF-8 Support Enabled
DEBUG - 2011-09-17 13:54:37 --> URI Class Initialized
DEBUG - 2011-09-17 13:54:37 --> Router Class Initialized
ERROR - 2011-09-17 13:54:37 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-09-17 14:03:49 --> Config Class Initialized
DEBUG - 2011-09-17 14:03:49 --> Hooks Class Initialized
DEBUG - 2011-09-17 14:03:49 --> Utf8 Class Initialized
DEBUG - 2011-09-17 14:03:49 --> UTF-8 Support Enabled
DEBUG - 2011-09-17 14:03:49 --> URI Class Initialized
DEBUG - 2011-09-17 14:03:49 --> Router Class Initialized
DEBUG - 2011-09-17 14:03:49 --> Output Class Initialized
DEBUG - 2011-09-17 14:03:49 --> Input Class Initialized
DEBUG - 2011-09-17 14:03:49 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-17 14:03:49 --> Language Class Initialized
DEBUG - 2011-09-17 14:03:49 --> Loader Class Initialized
DEBUG - 2011-09-17 14:03:49 --> Controller Class Initialized
DEBUG - 2011-09-17 14:03:49 --> Model Class Initialized
DEBUG - 2011-09-17 14:03:49 --> Model Class Initialized
DEBUG - 2011-09-17 14:03:49 --> Model Class Initialized
DEBUG - 2011-09-17 14:03:49 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-17 14:03:49 --> Database Driver Class Initialized
DEBUG - 2011-09-17 14:03:49 --> File loaded: application/views/table/main.php
DEBUG - 2011-09-17 14:03:49 --> Helper loaded: url_helper
DEBUG - 2011-09-17 14:03:49 --> File loaded: application/views/common/header.php
DEBUG - 2011-09-17 14:03:49 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-09-17 14:03:49 --> File loaded: application/views/common/footer.php
DEBUG - 2011-09-17 14:03:49 --> File loaded: application/views/layout/main.php
DEBUG - 2011-09-17 14:03:49 --> Final output sent to browser
DEBUG - 2011-09-17 14:03:49 --> Total execution time: 0.0665
DEBUG - 2011-09-17 14:03:52 --> Config Class Initialized
DEBUG - 2011-09-17 14:03:52 --> Hooks Class Initialized
DEBUG - 2011-09-17 14:03:52 --> Utf8 Class Initialized
DEBUG - 2011-09-17 14:03:52 --> UTF-8 Support Enabled
DEBUG - 2011-09-17 14:03:52 --> URI Class Initialized
DEBUG - 2011-09-17 14:03:52 --> Router Class Initialized
ERROR - 2011-09-17 14:03:52 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-09-17 14:04:19 --> Config Class Initialized
DEBUG - 2011-09-17 14:04:19 --> Hooks Class Initialized
DEBUG - 2011-09-17 14:04:19 --> Utf8 Class Initialized
DEBUG - 2011-09-17 14:04:19 --> UTF-8 Support Enabled
DEBUG - 2011-09-17 14:04:19 --> URI Class Initialized
DEBUG - 2011-09-17 14:04:19 --> Router Class Initialized
DEBUG - 2011-09-17 14:04:19 --> Output Class Initialized
DEBUG - 2011-09-17 14:04:19 --> Input Class Initialized
DEBUG - 2011-09-17 14:04:19 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-17 14:04:19 --> Language Class Initialized
DEBUG - 2011-09-17 14:04:19 --> Loader Class Initialized
DEBUG - 2011-09-17 14:04:19 --> Controller Class Initialized
DEBUG - 2011-09-17 14:04:19 --> Model Class Initialized
DEBUG - 2011-09-17 14:04:19 --> Model Class Initialized
DEBUG - 2011-09-17 14:04:19 --> Model Class Initialized
DEBUG - 2011-09-17 14:04:19 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-17 14:04:19 --> Database Driver Class Initialized
DEBUG - 2011-09-17 14:04:19 --> File loaded: application/views/table/main.php
DEBUG - 2011-09-17 14:04:19 --> Helper loaded: url_helper
DEBUG - 2011-09-17 14:04:19 --> File loaded: application/views/common/header.php
DEBUG - 2011-09-17 14:04:19 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-09-17 14:04:19 --> File loaded: application/views/common/footer.php
DEBUG - 2011-09-17 14:04:19 --> File loaded: application/views/layout/main.php
DEBUG - 2011-09-17 14:04:19 --> Final output sent to browser
DEBUG - 2011-09-17 14:04:19 --> Total execution time: 0.2359
DEBUG - 2011-09-17 14:04:21 --> Config Class Initialized
DEBUG - 2011-09-17 14:04:21 --> Hooks Class Initialized
DEBUG - 2011-09-17 14:04:21 --> Utf8 Class Initialized
DEBUG - 2011-09-17 14:04:21 --> UTF-8 Support Enabled
DEBUG - 2011-09-17 14:04:21 --> URI Class Initialized
DEBUG - 2011-09-17 14:04:21 --> Router Class Initialized
ERROR - 2011-09-17 14:04:21 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-09-17 14:04:34 --> Config Class Initialized
DEBUG - 2011-09-17 14:04:34 --> Hooks Class Initialized
DEBUG - 2011-09-17 14:04:34 --> Utf8 Class Initialized
DEBUG - 2011-09-17 14:04:34 --> UTF-8 Support Enabled
DEBUG - 2011-09-17 14:04:34 --> URI Class Initialized
DEBUG - 2011-09-17 14:04:34 --> Router Class Initialized
DEBUG - 2011-09-17 14:04:34 --> Output Class Initialized
DEBUG - 2011-09-17 14:04:34 --> Input Class Initialized
DEBUG - 2011-09-17 14:04:34 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-17 14:04:34 --> Language Class Initialized
DEBUG - 2011-09-17 14:04:34 --> Loader Class Initialized
DEBUG - 2011-09-17 14:04:34 --> Controller Class Initialized
DEBUG - 2011-09-17 14:04:34 --> Model Class Initialized
DEBUG - 2011-09-17 14:04:34 --> Model Class Initialized
DEBUG - 2011-09-17 14:04:34 --> Model Class Initialized
DEBUG - 2011-09-17 14:04:34 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-17 14:04:34 --> Database Driver Class Initialized
DEBUG - 2011-09-17 14:04:34 --> File loaded: application/views/table/main.php
DEBUG - 2011-09-17 14:04:34 --> Helper loaded: url_helper
DEBUG - 2011-09-17 14:04:34 --> File loaded: application/views/common/header.php
DEBUG - 2011-09-17 14:04:34 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-09-17 14:04:34 --> File loaded: application/views/common/footer.php
DEBUG - 2011-09-17 14:04:34 --> File loaded: application/views/layout/main.php
DEBUG - 2011-09-17 14:04:34 --> Final output sent to browser
DEBUG - 2011-09-17 14:04:34 --> Total execution time: 0.3317
DEBUG - 2011-09-17 14:04:36 --> Config Class Initialized
DEBUG - 2011-09-17 14:04:36 --> Hooks Class Initialized
DEBUG - 2011-09-17 14:04:36 --> Utf8 Class Initialized
DEBUG - 2011-09-17 14:04:36 --> UTF-8 Support Enabled
DEBUG - 2011-09-17 14:04:36 --> URI Class Initialized
DEBUG - 2011-09-17 14:04:36 --> Router Class Initialized
ERROR - 2011-09-17 14:04:36 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-09-17 14:04:54 --> Config Class Initialized
DEBUG - 2011-09-17 14:04:54 --> Hooks Class Initialized
DEBUG - 2011-09-17 14:04:54 --> Utf8 Class Initialized
DEBUG - 2011-09-17 14:04:54 --> UTF-8 Support Enabled
DEBUG - 2011-09-17 14:04:54 --> URI Class Initialized
DEBUG - 2011-09-17 14:04:54 --> Router Class Initialized
DEBUG - 2011-09-17 14:04:54 --> Output Class Initialized
DEBUG - 2011-09-17 14:04:54 --> Input Class Initialized
DEBUG - 2011-09-17 14:04:54 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-17 14:04:54 --> Language Class Initialized
DEBUG - 2011-09-17 14:04:54 --> Loader Class Initialized
DEBUG - 2011-09-17 14:04:54 --> Controller Class Initialized
DEBUG - 2011-09-17 14:04:54 --> Model Class Initialized
DEBUG - 2011-09-17 14:04:54 --> Model Class Initialized
DEBUG - 2011-09-17 14:04:54 --> Model Class Initialized
DEBUG - 2011-09-17 14:04:54 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-17 14:04:54 --> Database Driver Class Initialized
DEBUG - 2011-09-17 14:04:54 --> File loaded: application/views/table/main.php
DEBUG - 2011-09-17 14:04:54 --> Helper loaded: url_helper
DEBUG - 2011-09-17 14:04:54 --> File loaded: application/views/common/header.php
DEBUG - 2011-09-17 14:04:54 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-09-17 14:04:54 --> File loaded: application/views/common/footer.php
DEBUG - 2011-09-17 14:04:54 --> File loaded: application/views/layout/main.php
DEBUG - 2011-09-17 14:04:54 --> Final output sent to browser
DEBUG - 2011-09-17 14:04:54 --> Total execution time: 0.2828
DEBUG - 2011-09-17 14:04:56 --> Config Class Initialized
DEBUG - 2011-09-17 14:04:56 --> Hooks Class Initialized
DEBUG - 2011-09-17 14:04:56 --> Utf8 Class Initialized
DEBUG - 2011-09-17 14:04:56 --> UTF-8 Support Enabled
DEBUG - 2011-09-17 14:04:56 --> URI Class Initialized
DEBUG - 2011-09-17 14:04:56 --> Router Class Initialized
ERROR - 2011-09-17 14:04:56 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-09-17 14:05:10 --> Config Class Initialized
DEBUG - 2011-09-17 14:05:10 --> Hooks Class Initialized
DEBUG - 2011-09-17 14:05:10 --> Utf8 Class Initialized
DEBUG - 2011-09-17 14:05:10 --> UTF-8 Support Enabled
DEBUG - 2011-09-17 14:05:10 --> URI Class Initialized
DEBUG - 2011-09-17 14:05:10 --> Router Class Initialized
DEBUG - 2011-09-17 14:05:10 --> Output Class Initialized
DEBUG - 2011-09-17 14:05:10 --> Input Class Initialized
DEBUG - 2011-09-17 14:05:10 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-17 14:05:10 --> Language Class Initialized
DEBUG - 2011-09-17 14:05:10 --> Loader Class Initialized
DEBUG - 2011-09-17 14:05:10 --> Controller Class Initialized
DEBUG - 2011-09-17 14:05:10 --> Model Class Initialized
DEBUG - 2011-09-17 14:05:10 --> Model Class Initialized
DEBUG - 2011-09-17 14:05:10 --> Model Class Initialized
DEBUG - 2011-09-17 14:05:10 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-17 14:05:10 --> Database Driver Class Initialized
DEBUG - 2011-09-17 14:05:11 --> File loaded: application/views/table/main.php
DEBUG - 2011-09-17 14:05:11 --> Helper loaded: url_helper
DEBUG - 2011-09-17 14:05:11 --> File loaded: application/views/common/header.php
DEBUG - 2011-09-17 14:05:11 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-09-17 14:05:11 --> File loaded: application/views/common/footer.php
DEBUG - 2011-09-17 14:05:11 --> File loaded: application/views/layout/main.php
DEBUG - 2011-09-17 14:05:11 --> Final output sent to browser
DEBUG - 2011-09-17 14:05:11 --> Total execution time: 0.4786
DEBUG - 2011-09-17 14:05:13 --> Config Class Initialized
DEBUG - 2011-09-17 14:05:13 --> Hooks Class Initialized
DEBUG - 2011-09-17 14:05:13 --> Utf8 Class Initialized
DEBUG - 2011-09-17 14:05:13 --> UTF-8 Support Enabled
DEBUG - 2011-09-17 14:05:13 --> URI Class Initialized
DEBUG - 2011-09-17 14:05:13 --> Router Class Initialized
ERROR - 2011-09-17 14:05:13 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-09-17 14:05:21 --> Config Class Initialized
DEBUG - 2011-09-17 14:05:21 --> Hooks Class Initialized
DEBUG - 2011-09-17 14:05:21 --> Utf8 Class Initialized
DEBUG - 2011-09-17 14:05:21 --> UTF-8 Support Enabled
DEBUG - 2011-09-17 14:05:21 --> URI Class Initialized
DEBUG - 2011-09-17 14:05:21 --> Router Class Initialized
DEBUG - 2011-09-17 14:05:21 --> Output Class Initialized
DEBUG - 2011-09-17 14:05:21 --> Input Class Initialized
DEBUG - 2011-09-17 14:05:21 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-17 14:05:21 --> Language Class Initialized
DEBUG - 2011-09-17 14:05:21 --> Loader Class Initialized
DEBUG - 2011-09-17 14:05:21 --> Controller Class Initialized
DEBUG - 2011-09-17 14:05:21 --> Model Class Initialized
DEBUG - 2011-09-17 14:05:21 --> Model Class Initialized
DEBUG - 2011-09-17 14:05:21 --> Model Class Initialized
DEBUG - 2011-09-17 14:05:21 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-17 14:05:21 --> Database Driver Class Initialized
DEBUG - 2011-09-17 14:05:23 --> File loaded: application/views/table/main.php
DEBUG - 2011-09-17 14:05:23 --> Helper loaded: url_helper
DEBUG - 2011-09-17 14:05:23 --> File loaded: application/views/common/header.php
DEBUG - 2011-09-17 14:05:23 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-09-17 14:05:23 --> File loaded: application/views/common/footer.php
DEBUG - 2011-09-17 14:05:23 --> File loaded: application/views/layout/main.php
DEBUG - 2011-09-17 14:05:23 --> Final output sent to browser
DEBUG - 2011-09-17 14:05:23 --> Total execution time: 1.8139
DEBUG - 2011-09-17 14:05:25 --> Config Class Initialized
DEBUG - 2011-09-17 14:05:25 --> Hooks Class Initialized
DEBUG - 2011-09-17 14:05:25 --> Utf8 Class Initialized
DEBUG - 2011-09-17 14:05:25 --> UTF-8 Support Enabled
DEBUG - 2011-09-17 14:05:25 --> URI Class Initialized
DEBUG - 2011-09-17 14:05:25 --> Router Class Initialized
ERROR - 2011-09-17 14:05:25 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-09-17 14:05:32 --> Config Class Initialized
DEBUG - 2011-09-17 14:05:32 --> Hooks Class Initialized
DEBUG - 2011-09-17 14:05:32 --> Utf8 Class Initialized
DEBUG - 2011-09-17 14:05:32 --> UTF-8 Support Enabled
DEBUG - 2011-09-17 14:05:32 --> URI Class Initialized
DEBUG - 2011-09-17 14:05:32 --> Router Class Initialized
DEBUG - 2011-09-17 14:05:32 --> Output Class Initialized
DEBUG - 2011-09-17 14:05:32 --> Input Class Initialized
DEBUG - 2011-09-17 14:05:32 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-17 14:05:32 --> Language Class Initialized
DEBUG - 2011-09-17 14:05:32 --> Loader Class Initialized
DEBUG - 2011-09-17 14:05:32 --> Controller Class Initialized
DEBUG - 2011-09-17 14:05:32 --> Model Class Initialized
DEBUG - 2011-09-17 14:05:32 --> Model Class Initialized
DEBUG - 2011-09-17 14:05:32 --> Model Class Initialized
DEBUG - 2011-09-17 14:05:32 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-17 14:05:32 --> Database Driver Class Initialized
DEBUG - 2011-09-17 14:05:33 --> File loaded: application/views/table/main.php
DEBUG - 2011-09-17 14:05:33 --> Helper loaded: url_helper
DEBUG - 2011-09-17 14:05:33 --> File loaded: application/views/common/header.php
DEBUG - 2011-09-17 14:05:33 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-09-17 14:05:33 --> File loaded: application/views/common/footer.php
DEBUG - 2011-09-17 14:05:33 --> File loaded: application/views/layout/main.php
DEBUG - 2011-09-17 14:05:33 --> Final output sent to browser
DEBUG - 2011-09-17 14:05:33 --> Total execution time: 0.5415
DEBUG - 2011-09-17 14:05:35 --> Config Class Initialized
DEBUG - 2011-09-17 14:05:35 --> Hooks Class Initialized
DEBUG - 2011-09-17 14:05:35 --> Utf8 Class Initialized
DEBUG - 2011-09-17 14:05:35 --> UTF-8 Support Enabled
DEBUG - 2011-09-17 14:05:35 --> URI Class Initialized
DEBUG - 2011-09-17 14:05:35 --> Router Class Initialized
ERROR - 2011-09-17 14:05:35 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-09-17 14:05:43 --> Config Class Initialized
DEBUG - 2011-09-17 14:05:43 --> Hooks Class Initialized
DEBUG - 2011-09-17 14:05:43 --> Utf8 Class Initialized
DEBUG - 2011-09-17 14:05:43 --> UTF-8 Support Enabled
DEBUG - 2011-09-17 14:05:43 --> URI Class Initialized
DEBUG - 2011-09-17 14:05:43 --> Router Class Initialized
DEBUG - 2011-09-17 14:05:43 --> Output Class Initialized
DEBUG - 2011-09-17 14:05:43 --> Input Class Initialized
DEBUG - 2011-09-17 14:05:43 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-17 14:05:43 --> Language Class Initialized
DEBUG - 2011-09-17 14:05:43 --> Loader Class Initialized
DEBUG - 2011-09-17 14:05:43 --> Controller Class Initialized
DEBUG - 2011-09-17 14:05:43 --> Model Class Initialized
DEBUG - 2011-09-17 14:05:43 --> Model Class Initialized
DEBUG - 2011-09-17 14:05:43 --> Model Class Initialized
DEBUG - 2011-09-17 14:05:43 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-17 14:05:43 --> Database Driver Class Initialized
DEBUG - 2011-09-17 14:05:43 --> File loaded: application/views/table/main.php
DEBUG - 2011-09-17 14:05:43 --> Helper loaded: url_helper
DEBUG - 2011-09-17 14:05:43 --> File loaded: application/views/common/header.php
DEBUG - 2011-09-17 14:05:43 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-09-17 14:05:43 --> File loaded: application/views/common/footer.php
DEBUG - 2011-09-17 14:05:43 --> File loaded: application/views/layout/main.php
DEBUG - 2011-09-17 14:05:43 --> Final output sent to browser
DEBUG - 2011-09-17 14:05:43 --> Total execution time: 0.2729
DEBUG - 2011-09-17 14:05:45 --> Config Class Initialized
DEBUG - 2011-09-17 14:05:45 --> Hooks Class Initialized
DEBUG - 2011-09-17 14:05:45 --> Utf8 Class Initialized
DEBUG - 2011-09-17 14:05:45 --> UTF-8 Support Enabled
DEBUG - 2011-09-17 14:05:45 --> URI Class Initialized
DEBUG - 2011-09-17 14:05:45 --> Router Class Initialized
ERROR - 2011-09-17 14:05:45 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-09-17 14:05:56 --> Config Class Initialized
DEBUG - 2011-09-17 14:05:56 --> Hooks Class Initialized
DEBUG - 2011-09-17 14:05:56 --> Utf8 Class Initialized
DEBUG - 2011-09-17 14:05:56 --> UTF-8 Support Enabled
DEBUG - 2011-09-17 14:05:56 --> URI Class Initialized
DEBUG - 2011-09-17 14:05:56 --> Router Class Initialized
DEBUG - 2011-09-17 14:05:56 --> Output Class Initialized
DEBUG - 2011-09-17 14:05:56 --> Input Class Initialized
DEBUG - 2011-09-17 14:05:56 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-17 14:05:56 --> Language Class Initialized
DEBUG - 2011-09-17 14:05:56 --> Loader Class Initialized
DEBUG - 2011-09-17 14:05:56 --> Controller Class Initialized
DEBUG - 2011-09-17 14:05:56 --> Model Class Initialized
DEBUG - 2011-09-17 14:05:56 --> Model Class Initialized
DEBUG - 2011-09-17 14:05:56 --> Model Class Initialized
DEBUG - 2011-09-17 14:05:56 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-17 14:05:56 --> Database Driver Class Initialized
DEBUG - 2011-09-17 14:05:56 --> File loaded: application/views/table/main.php
DEBUG - 2011-09-17 14:05:56 --> Helper loaded: url_helper
DEBUG - 2011-09-17 14:05:56 --> File loaded: application/views/common/header.php
DEBUG - 2011-09-17 14:05:56 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-09-17 14:05:56 --> File loaded: application/views/common/footer.php
DEBUG - 2011-09-17 14:05:56 --> File loaded: application/views/layout/main.php
DEBUG - 2011-09-17 14:05:56 --> Final output sent to browser
DEBUG - 2011-09-17 14:05:56 --> Total execution time: 0.4410
DEBUG - 2011-09-17 14:05:58 --> Config Class Initialized
DEBUG - 2011-09-17 14:05:58 --> Hooks Class Initialized
DEBUG - 2011-09-17 14:05:58 --> Utf8 Class Initialized
DEBUG - 2011-09-17 14:05:58 --> UTF-8 Support Enabled
DEBUG - 2011-09-17 14:05:58 --> URI Class Initialized
DEBUG - 2011-09-17 14:05:58 --> Router Class Initialized
ERROR - 2011-09-17 14:05:58 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-09-17 14:08:26 --> Config Class Initialized
DEBUG - 2011-09-17 14:08:26 --> Hooks Class Initialized
DEBUG - 2011-09-17 14:08:26 --> Utf8 Class Initialized
DEBUG - 2011-09-17 14:08:26 --> UTF-8 Support Enabled
DEBUG - 2011-09-17 14:08:26 --> URI Class Initialized
DEBUG - 2011-09-17 14:08:26 --> Router Class Initialized
DEBUG - 2011-09-17 14:08:26 --> Output Class Initialized
DEBUG - 2011-09-17 14:08:26 --> Input Class Initialized
DEBUG - 2011-09-17 14:08:26 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-17 14:08:26 --> Language Class Initialized
DEBUG - 2011-09-17 14:08:26 --> Loader Class Initialized
DEBUG - 2011-09-17 14:08:26 --> Controller Class Initialized
ERROR - 2011-09-17 14:08:26 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-09-17 14:08:26 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-09-17 14:08:26 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-09-17 14:08:26 --> Model Class Initialized
DEBUG - 2011-09-17 14:08:26 --> Model Class Initialized
DEBUG - 2011-09-17 14:08:26 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-17 14:08:26 --> Database Driver Class Initialized
DEBUG - 2011-09-17 14:08:26 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-09-17 14:08:26 --> Helper loaded: url_helper
DEBUG - 2011-09-17 14:08:26 --> File loaded: application/views/common/header.php
DEBUG - 2011-09-17 14:08:26 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-09-17 14:08:26 --> File loaded: application/views/common/footer.php
DEBUG - 2011-09-17 14:08:26 --> File loaded: application/views/layout/main.php
DEBUG - 2011-09-17 14:08:26 --> Final output sent to browser
DEBUG - 2011-09-17 14:08:26 --> Total execution time: 0.0319
DEBUG - 2011-09-17 14:08:27 --> Config Class Initialized
DEBUG - 2011-09-17 14:08:27 --> Hooks Class Initialized
DEBUG - 2011-09-17 14:08:27 --> Utf8 Class Initialized
DEBUG - 2011-09-17 14:08:27 --> UTF-8 Support Enabled
DEBUG - 2011-09-17 14:08:27 --> URI Class Initialized
DEBUG - 2011-09-17 14:08:27 --> Router Class Initialized
DEBUG - 2011-09-17 14:08:27 --> Output Class Initialized
DEBUG - 2011-09-17 14:08:27 --> Input Class Initialized
DEBUG - 2011-09-17 14:08:27 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-17 14:08:27 --> Language Class Initialized
DEBUG - 2011-09-17 14:08:27 --> Loader Class Initialized
DEBUG - 2011-09-17 14:08:27 --> Controller Class Initialized
DEBUG - 2011-09-17 14:08:27 --> Model Class Initialized
DEBUG - 2011-09-17 14:08:27 --> Model Class Initialized
DEBUG - 2011-09-17 14:08:27 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-17 14:08:27 --> Database Driver Class Initialized
DEBUG - 2011-09-17 14:08:27 --> Final output sent to browser
DEBUG - 2011-09-17 14:08:27 --> Total execution time: 0.6933
DEBUG - 2011-09-17 14:08:28 --> Config Class Initialized
DEBUG - 2011-09-17 14:08:28 --> Hooks Class Initialized
DEBUG - 2011-09-17 14:08:28 --> Utf8 Class Initialized
DEBUG - 2011-09-17 14:08:28 --> UTF-8 Support Enabled
DEBUG - 2011-09-17 14:08:28 --> URI Class Initialized
DEBUG - 2011-09-17 14:08:28 --> Router Class Initialized
ERROR - 2011-09-17 14:08:28 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-09-17 14:08:28 --> Config Class Initialized
DEBUG - 2011-09-17 14:08:28 --> Hooks Class Initialized
DEBUG - 2011-09-17 14:08:28 --> Utf8 Class Initialized
DEBUG - 2011-09-17 14:08:28 --> UTF-8 Support Enabled
DEBUG - 2011-09-17 14:08:28 --> URI Class Initialized
DEBUG - 2011-09-17 14:08:28 --> Router Class Initialized
ERROR - 2011-09-17 14:08:28 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-09-17 14:09:04 --> Config Class Initialized
DEBUG - 2011-09-17 14:09:04 --> Hooks Class Initialized
DEBUG - 2011-09-17 14:09:04 --> Utf8 Class Initialized
DEBUG - 2011-09-17 14:09:04 --> UTF-8 Support Enabled
DEBUG - 2011-09-17 14:09:04 --> URI Class Initialized
DEBUG - 2011-09-17 14:09:04 --> Router Class Initialized
DEBUG - 2011-09-17 14:09:04 --> Output Class Initialized
DEBUG - 2011-09-17 14:09:04 --> Input Class Initialized
DEBUG - 2011-09-17 14:09:04 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-17 14:09:04 --> Language Class Initialized
DEBUG - 2011-09-17 14:09:04 --> Loader Class Initialized
DEBUG - 2011-09-17 14:09:04 --> Controller Class Initialized
ERROR - 2011-09-17 14:09:04 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-09-17 14:09:04 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-09-17 14:09:04 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-09-17 14:09:04 --> Model Class Initialized
DEBUG - 2011-09-17 14:09:04 --> Model Class Initialized
DEBUG - 2011-09-17 14:09:04 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-17 14:09:04 --> Database Driver Class Initialized
DEBUG - 2011-09-17 14:09:04 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-09-17 14:09:04 --> Helper loaded: url_helper
DEBUG - 2011-09-17 14:09:04 --> File loaded: application/views/common/header.php
DEBUG - 2011-09-17 14:09:04 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-09-17 14:09:04 --> File loaded: application/views/common/footer.php
DEBUG - 2011-09-17 14:09:04 --> File loaded: application/views/layout/main.php
DEBUG - 2011-09-17 14:09:04 --> Final output sent to browser
DEBUG - 2011-09-17 14:09:04 --> Total execution time: 0.1713
DEBUG - 2011-09-17 14:09:05 --> Config Class Initialized
DEBUG - 2011-09-17 14:09:05 --> Hooks Class Initialized
DEBUG - 2011-09-17 14:09:05 --> Utf8 Class Initialized
DEBUG - 2011-09-17 14:09:05 --> UTF-8 Support Enabled
DEBUG - 2011-09-17 14:09:05 --> URI Class Initialized
DEBUG - 2011-09-17 14:09:05 --> Router Class Initialized
DEBUG - 2011-09-17 14:09:05 --> Output Class Initialized
DEBUG - 2011-09-17 14:09:05 --> Input Class Initialized
DEBUG - 2011-09-17 14:09:05 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-17 14:09:05 --> Language Class Initialized
DEBUG - 2011-09-17 14:09:05 --> Loader Class Initialized
DEBUG - 2011-09-17 14:09:05 --> Controller Class Initialized
DEBUG - 2011-09-17 14:09:05 --> Model Class Initialized
DEBUG - 2011-09-17 14:09:05 --> Model Class Initialized
DEBUG - 2011-09-17 14:09:05 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-17 14:09:05 --> Database Driver Class Initialized
DEBUG - 2011-09-17 14:09:06 --> Final output sent to browser
DEBUG - 2011-09-17 14:09:06 --> Total execution time: 0.6772
DEBUG - 2011-09-17 14:09:26 --> Config Class Initialized
DEBUG - 2011-09-17 14:09:26 --> Hooks Class Initialized
DEBUG - 2011-09-17 14:09:26 --> Utf8 Class Initialized
DEBUG - 2011-09-17 14:09:26 --> UTF-8 Support Enabled
DEBUG - 2011-09-17 14:09:26 --> URI Class Initialized
DEBUG - 2011-09-17 14:09:26 --> Router Class Initialized
DEBUG - 2011-09-17 14:09:26 --> Output Class Initialized
DEBUG - 2011-09-17 14:09:26 --> Input Class Initialized
DEBUG - 2011-09-17 14:09:26 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-17 14:09:26 --> Language Class Initialized
DEBUG - 2011-09-17 14:09:26 --> Loader Class Initialized
DEBUG - 2011-09-17 14:09:26 --> Controller Class Initialized
ERROR - 2011-09-17 14:09:26 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-09-17 14:09:26 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-09-17 14:09:26 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-09-17 14:09:26 --> Model Class Initialized
DEBUG - 2011-09-17 14:09:26 --> Model Class Initialized
DEBUG - 2011-09-17 14:09:26 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-17 14:09:26 --> Database Driver Class Initialized
DEBUG - 2011-09-17 14:09:26 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-09-17 14:09:26 --> Helper loaded: url_helper
DEBUG - 2011-09-17 14:09:26 --> File loaded: application/views/common/header.php
DEBUG - 2011-09-17 14:09:26 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-09-17 14:09:26 --> File loaded: application/views/common/footer.php
DEBUG - 2011-09-17 14:09:26 --> File loaded: application/views/layout/main.php
DEBUG - 2011-09-17 14:09:26 --> Final output sent to browser
DEBUG - 2011-09-17 14:09:26 --> Total execution time: 0.0493
DEBUG - 2011-09-17 14:09:26 --> Config Class Initialized
DEBUG - 2011-09-17 14:09:26 --> Hooks Class Initialized
DEBUG - 2011-09-17 14:09:26 --> Utf8 Class Initialized
DEBUG - 2011-09-17 14:09:26 --> UTF-8 Support Enabled
DEBUG - 2011-09-17 14:09:26 --> URI Class Initialized
DEBUG - 2011-09-17 14:09:26 --> Router Class Initialized
DEBUG - 2011-09-17 14:09:26 --> Output Class Initialized
DEBUG - 2011-09-17 14:09:26 --> Input Class Initialized
DEBUG - 2011-09-17 14:09:26 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-17 14:09:26 --> Language Class Initialized
DEBUG - 2011-09-17 14:09:26 --> Loader Class Initialized
DEBUG - 2011-09-17 14:09:26 --> Controller Class Initialized
DEBUG - 2011-09-17 14:09:26 --> Model Class Initialized
DEBUG - 2011-09-17 14:09:26 --> Model Class Initialized
DEBUG - 2011-09-17 14:09:26 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-17 14:09:26 --> Database Driver Class Initialized
DEBUG - 2011-09-17 14:09:27 --> Final output sent to browser
DEBUG - 2011-09-17 14:09:27 --> Total execution time: 0.7110
DEBUG - 2011-09-17 14:12:02 --> Config Class Initialized
DEBUG - 2011-09-17 14:12:02 --> Hooks Class Initialized
DEBUG - 2011-09-17 14:12:02 --> Utf8 Class Initialized
DEBUG - 2011-09-17 14:12:02 --> UTF-8 Support Enabled
DEBUG - 2011-09-17 14:12:02 --> URI Class Initialized
DEBUG - 2011-09-17 14:12:02 --> Router Class Initialized
DEBUG - 2011-09-17 14:12:02 --> Output Class Initialized
DEBUG - 2011-09-17 14:12:02 --> Input Class Initialized
DEBUG - 2011-09-17 14:12:02 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-17 14:12:02 --> Language Class Initialized
DEBUG - 2011-09-17 14:12:02 --> Loader Class Initialized
DEBUG - 2011-09-17 14:12:02 --> Controller Class Initialized
ERROR - 2011-09-17 14:12:02 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-09-17 14:12:02 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-09-17 14:12:02 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-09-17 14:12:02 --> Model Class Initialized
DEBUG - 2011-09-17 14:12:02 --> Model Class Initialized
DEBUG - 2011-09-17 14:12:02 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-17 14:12:02 --> Database Driver Class Initialized
DEBUG - 2011-09-17 14:12:02 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-09-17 14:12:02 --> Helper loaded: url_helper
DEBUG - 2011-09-17 14:12:02 --> File loaded: application/views/common/header.php
DEBUG - 2011-09-17 14:12:02 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-09-17 14:12:02 --> File loaded: application/views/common/footer.php
DEBUG - 2011-09-17 14:12:02 --> File loaded: application/views/layout/main.php
DEBUG - 2011-09-17 14:12:02 --> Final output sent to browser
DEBUG - 2011-09-17 14:12:02 --> Total execution time: 0.0284
DEBUG - 2011-09-17 14:12:03 --> Config Class Initialized
DEBUG - 2011-09-17 14:12:03 --> Hooks Class Initialized
DEBUG - 2011-09-17 14:12:03 --> Utf8 Class Initialized
DEBUG - 2011-09-17 14:12:03 --> UTF-8 Support Enabled
DEBUG - 2011-09-17 14:12:03 --> URI Class Initialized
DEBUG - 2011-09-17 14:12:03 --> Router Class Initialized
DEBUG - 2011-09-17 14:12:03 --> Output Class Initialized
DEBUG - 2011-09-17 14:12:03 --> Input Class Initialized
DEBUG - 2011-09-17 14:12:03 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-17 14:12:03 --> Language Class Initialized
DEBUG - 2011-09-17 14:12:03 --> Loader Class Initialized
DEBUG - 2011-09-17 14:12:03 --> Controller Class Initialized
DEBUG - 2011-09-17 14:12:03 --> Model Class Initialized
DEBUG - 2011-09-17 14:12:03 --> Model Class Initialized
DEBUG - 2011-09-17 14:12:03 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-17 14:12:03 --> Database Driver Class Initialized
DEBUG - 2011-09-17 14:12:03 --> Final output sent to browser
DEBUG - 2011-09-17 14:12:03 --> Total execution time: 0.7266
DEBUG - 2011-09-17 14:12:13 --> Config Class Initialized
DEBUG - 2011-09-17 14:12:13 --> Hooks Class Initialized
DEBUG - 2011-09-17 14:12:13 --> Utf8 Class Initialized
DEBUG - 2011-09-17 14:12:13 --> UTF-8 Support Enabled
DEBUG - 2011-09-17 14:12:13 --> URI Class Initialized
DEBUG - 2011-09-17 14:12:13 --> Router Class Initialized
DEBUG - 2011-09-17 14:12:13 --> Output Class Initialized
DEBUG - 2011-09-17 14:12:13 --> Input Class Initialized
DEBUG - 2011-09-17 14:12:13 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-17 14:12:13 --> Language Class Initialized
DEBUG - 2011-09-17 14:12:13 --> Loader Class Initialized
DEBUG - 2011-09-17 14:12:13 --> Controller Class Initialized
ERROR - 2011-09-17 14:12:13 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-09-17 14:12:13 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-09-17 14:12:13 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-09-17 14:12:13 --> Model Class Initialized
DEBUG - 2011-09-17 14:12:13 --> Model Class Initialized
DEBUG - 2011-09-17 14:12:13 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-17 14:12:13 --> Database Driver Class Initialized
DEBUG - 2011-09-17 14:12:13 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-09-17 14:12:13 --> Helper loaded: url_helper
DEBUG - 2011-09-17 14:12:13 --> File loaded: application/views/common/header.php
DEBUG - 2011-09-17 14:12:13 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-09-17 14:12:13 --> File loaded: application/views/common/footer.php
DEBUG - 2011-09-17 14:12:13 --> File loaded: application/views/layout/main.php
DEBUG - 2011-09-17 14:12:13 --> Final output sent to browser
DEBUG - 2011-09-17 14:12:13 --> Total execution time: 0.0282
DEBUG - 2011-09-17 14:12:13 --> Config Class Initialized
DEBUG - 2011-09-17 14:12:13 --> Hooks Class Initialized
DEBUG - 2011-09-17 14:12:13 --> Utf8 Class Initialized
DEBUG - 2011-09-17 14:12:13 --> UTF-8 Support Enabled
DEBUG - 2011-09-17 14:12:13 --> URI Class Initialized
DEBUG - 2011-09-17 14:12:13 --> Router Class Initialized
DEBUG - 2011-09-17 14:12:13 --> Output Class Initialized
DEBUG - 2011-09-17 14:12:13 --> Input Class Initialized
DEBUG - 2011-09-17 14:12:13 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-17 14:12:13 --> Language Class Initialized
DEBUG - 2011-09-17 14:12:13 --> Loader Class Initialized
DEBUG - 2011-09-17 14:12:13 --> Controller Class Initialized
DEBUG - 2011-09-17 14:12:13 --> Model Class Initialized
DEBUG - 2011-09-17 14:12:13 --> Model Class Initialized
DEBUG - 2011-09-17 14:12:13 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-17 14:12:13 --> Database Driver Class Initialized
DEBUG - 2011-09-17 14:12:14 --> Final output sent to browser
DEBUG - 2011-09-17 14:12:14 --> Total execution time: 0.6905
DEBUG - 2011-09-17 14:12:27 --> Config Class Initialized
DEBUG - 2011-09-17 14:12:27 --> Hooks Class Initialized
DEBUG - 2011-09-17 14:12:27 --> Utf8 Class Initialized
DEBUG - 2011-09-17 14:12:27 --> UTF-8 Support Enabled
DEBUG - 2011-09-17 14:12:27 --> URI Class Initialized
DEBUG - 2011-09-17 14:12:27 --> Router Class Initialized
DEBUG - 2011-09-17 14:12:27 --> Output Class Initialized
DEBUG - 2011-09-17 14:12:27 --> Input Class Initialized
DEBUG - 2011-09-17 14:12:27 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-17 14:12:27 --> Language Class Initialized
DEBUG - 2011-09-17 14:12:27 --> Loader Class Initialized
DEBUG - 2011-09-17 14:12:27 --> Controller Class Initialized
ERROR - 2011-09-17 14:12:27 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-09-17 14:12:27 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-09-17 14:12:27 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-09-17 14:12:27 --> Model Class Initialized
DEBUG - 2011-09-17 14:12:27 --> Model Class Initialized
DEBUG - 2011-09-17 14:12:27 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-17 14:12:27 --> Database Driver Class Initialized
DEBUG - 2011-09-17 14:12:27 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-09-17 14:12:27 --> Helper loaded: url_helper
DEBUG - 2011-09-17 14:12:27 --> File loaded: application/views/common/header.php
DEBUG - 2011-09-17 14:12:27 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-09-17 14:12:27 --> File loaded: application/views/common/footer.php
DEBUG - 2011-09-17 14:12:27 --> File loaded: application/views/layout/main.php
DEBUG - 2011-09-17 14:12:27 --> Final output sent to browser
DEBUG - 2011-09-17 14:12:27 --> Total execution time: 0.0281
DEBUG - 2011-09-17 14:12:27 --> Config Class Initialized
DEBUG - 2011-09-17 14:12:27 --> Hooks Class Initialized
DEBUG - 2011-09-17 14:12:27 --> Utf8 Class Initialized
DEBUG - 2011-09-17 14:12:27 --> UTF-8 Support Enabled
DEBUG - 2011-09-17 14:12:27 --> URI Class Initialized
DEBUG - 2011-09-17 14:12:27 --> Router Class Initialized
DEBUG - 2011-09-17 14:12:27 --> Output Class Initialized
DEBUG - 2011-09-17 14:12:27 --> Input Class Initialized
DEBUG - 2011-09-17 14:12:27 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-17 14:12:27 --> Language Class Initialized
DEBUG - 2011-09-17 14:12:27 --> Loader Class Initialized
DEBUG - 2011-09-17 14:12:27 --> Controller Class Initialized
DEBUG - 2011-09-17 14:12:27 --> Model Class Initialized
DEBUG - 2011-09-17 14:12:27 --> Model Class Initialized
DEBUG - 2011-09-17 14:12:27 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-17 14:12:27 --> Database Driver Class Initialized
DEBUG - 2011-09-17 14:12:28 --> Final output sent to browser
DEBUG - 2011-09-17 14:12:28 --> Total execution time: 0.5786
DEBUG - 2011-09-17 14:12:34 --> Config Class Initialized
DEBUG - 2011-09-17 14:12:34 --> Hooks Class Initialized
DEBUG - 2011-09-17 14:12:34 --> Utf8 Class Initialized
DEBUG - 2011-09-17 14:12:34 --> UTF-8 Support Enabled
DEBUG - 2011-09-17 14:12:34 --> URI Class Initialized
DEBUG - 2011-09-17 14:12:34 --> Router Class Initialized
DEBUG - 2011-09-17 14:12:34 --> Output Class Initialized
DEBUG - 2011-09-17 14:12:34 --> Input Class Initialized
DEBUG - 2011-09-17 14:12:34 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-17 14:12:34 --> Language Class Initialized
DEBUG - 2011-09-17 14:12:34 --> Loader Class Initialized
DEBUG - 2011-09-17 14:12:34 --> Controller Class Initialized
ERROR - 2011-09-17 14:12:34 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-09-17 14:12:34 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-09-17 14:12:34 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-09-17 14:12:34 --> Model Class Initialized
DEBUG - 2011-09-17 14:12:34 --> Model Class Initialized
DEBUG - 2011-09-17 14:12:34 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-17 14:12:34 --> Database Driver Class Initialized
DEBUG - 2011-09-17 14:12:34 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-09-17 14:12:34 --> Helper loaded: url_helper
DEBUG - 2011-09-17 14:12:34 --> File loaded: application/views/common/header.php
DEBUG - 2011-09-17 14:12:34 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-09-17 14:12:34 --> File loaded: application/views/common/footer.php
DEBUG - 2011-09-17 14:12:34 --> File loaded: application/views/layout/main.php
DEBUG - 2011-09-17 14:12:34 --> Final output sent to browser
DEBUG - 2011-09-17 14:12:34 --> Total execution time: 0.0393
DEBUG - 2011-09-17 14:12:34 --> Config Class Initialized
DEBUG - 2011-09-17 14:12:34 --> Hooks Class Initialized
DEBUG - 2011-09-17 14:12:34 --> Utf8 Class Initialized
DEBUG - 2011-09-17 14:12:34 --> UTF-8 Support Enabled
DEBUG - 2011-09-17 14:12:34 --> URI Class Initialized
DEBUG - 2011-09-17 14:12:34 --> Router Class Initialized
DEBUG - 2011-09-17 14:12:34 --> Output Class Initialized
DEBUG - 2011-09-17 14:12:34 --> Input Class Initialized
DEBUG - 2011-09-17 14:12:34 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-17 14:12:34 --> Language Class Initialized
DEBUG - 2011-09-17 14:12:34 --> Loader Class Initialized
DEBUG - 2011-09-17 14:12:34 --> Controller Class Initialized
DEBUG - 2011-09-17 14:12:34 --> Model Class Initialized
DEBUG - 2011-09-17 14:12:34 --> Model Class Initialized
DEBUG - 2011-09-17 14:12:34 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-17 14:12:34 --> Database Driver Class Initialized
DEBUG - 2011-09-17 14:12:35 --> Final output sent to browser
DEBUG - 2011-09-17 14:12:35 --> Total execution time: 0.5249
DEBUG - 2011-09-17 14:12:49 --> Config Class Initialized
DEBUG - 2011-09-17 14:12:49 --> Hooks Class Initialized
DEBUG - 2011-09-17 14:12:49 --> Utf8 Class Initialized
DEBUG - 2011-09-17 14:12:49 --> UTF-8 Support Enabled
DEBUG - 2011-09-17 14:12:49 --> URI Class Initialized
DEBUG - 2011-09-17 14:12:49 --> Router Class Initialized
DEBUG - 2011-09-17 14:12:49 --> Output Class Initialized
DEBUG - 2011-09-17 14:12:49 --> Input Class Initialized
DEBUG - 2011-09-17 14:12:49 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-17 14:12:49 --> Language Class Initialized
DEBUG - 2011-09-17 14:12:49 --> Loader Class Initialized
DEBUG - 2011-09-17 14:12:49 --> Controller Class Initialized
ERROR - 2011-09-17 14:12:49 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-09-17 14:12:49 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-09-17 14:12:49 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-09-17 14:12:49 --> Model Class Initialized
DEBUG - 2011-09-17 14:12:49 --> Model Class Initialized
DEBUG - 2011-09-17 14:12:49 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-17 14:12:49 --> Database Driver Class Initialized
DEBUG - 2011-09-17 14:12:49 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-09-17 14:12:49 --> Helper loaded: url_helper
DEBUG - 2011-09-17 14:12:49 --> File loaded: application/views/common/header.php
DEBUG - 2011-09-17 14:12:49 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-09-17 14:12:49 --> File loaded: application/views/common/footer.php
DEBUG - 2011-09-17 14:12:49 --> File loaded: application/views/layout/main.php
DEBUG - 2011-09-17 14:12:49 --> Final output sent to browser
DEBUG - 2011-09-17 14:12:49 --> Total execution time: 0.0313
DEBUG - 2011-09-17 14:12:50 --> Config Class Initialized
DEBUG - 2011-09-17 14:12:50 --> Hooks Class Initialized
DEBUG - 2011-09-17 14:12:50 --> Utf8 Class Initialized
DEBUG - 2011-09-17 14:12:50 --> UTF-8 Support Enabled
DEBUG - 2011-09-17 14:12:50 --> URI Class Initialized
DEBUG - 2011-09-17 14:12:50 --> Router Class Initialized
DEBUG - 2011-09-17 14:12:50 --> Output Class Initialized
DEBUG - 2011-09-17 14:12:50 --> Input Class Initialized
DEBUG - 2011-09-17 14:12:50 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-17 14:12:50 --> Language Class Initialized
DEBUG - 2011-09-17 14:12:50 --> Loader Class Initialized
DEBUG - 2011-09-17 14:12:50 --> Controller Class Initialized
DEBUG - 2011-09-17 14:12:50 --> Model Class Initialized
DEBUG - 2011-09-17 14:12:50 --> Model Class Initialized
DEBUG - 2011-09-17 14:12:50 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-17 14:12:50 --> Database Driver Class Initialized
DEBUG - 2011-09-17 14:12:50 --> Final output sent to browser
DEBUG - 2011-09-17 14:12:50 --> Total execution time: 0.5085
DEBUG - 2011-09-17 14:24:38 --> Config Class Initialized
DEBUG - 2011-09-17 14:24:38 --> Hooks Class Initialized
DEBUG - 2011-09-17 14:24:38 --> Utf8 Class Initialized
DEBUG - 2011-09-17 14:24:38 --> UTF-8 Support Enabled
DEBUG - 2011-09-17 14:24:38 --> URI Class Initialized
DEBUG - 2011-09-17 14:24:38 --> Router Class Initialized
DEBUG - 2011-09-17 14:24:38 --> Output Class Initialized
DEBUG - 2011-09-17 14:24:38 --> Input Class Initialized
DEBUG - 2011-09-17 14:24:38 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-17 14:24:38 --> Language Class Initialized
DEBUG - 2011-09-17 14:24:38 --> Loader Class Initialized
DEBUG - 2011-09-17 14:24:38 --> Controller Class Initialized
DEBUG - 2011-09-17 14:24:38 --> Model Class Initialized
DEBUG - 2011-09-17 14:24:38 --> Model Class Initialized
DEBUG - 2011-09-17 14:24:38 --> Model Class Initialized
DEBUG - 2011-09-17 14:24:38 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-17 14:24:38 --> Database Driver Class Initialized
DEBUG - 2011-09-17 14:24:38 --> File loaded: application/views/table/main.php
DEBUG - 2011-09-17 14:24:38 --> Helper loaded: url_helper
DEBUG - 2011-09-17 14:24:38 --> File loaded: application/views/common/header.php
DEBUG - 2011-09-17 14:24:38 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-09-17 14:24:38 --> File loaded: application/views/common/footer.php
DEBUG - 2011-09-17 14:24:38 --> File loaded: application/views/layout/main.php
DEBUG - 2011-09-17 14:24:38 --> Final output sent to browser
DEBUG - 2011-09-17 14:24:38 --> Total execution time: 0.3968
DEBUG - 2011-09-17 14:24:44 --> Config Class Initialized
DEBUG - 2011-09-17 14:24:44 --> Hooks Class Initialized
DEBUG - 2011-09-17 14:24:44 --> Utf8 Class Initialized
DEBUG - 2011-09-17 14:24:44 --> UTF-8 Support Enabled
DEBUG - 2011-09-17 14:24:44 --> URI Class Initialized
DEBUG - 2011-09-17 14:24:44 --> Router Class Initialized
ERROR - 2011-09-17 14:24:44 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-09-17 14:24:45 --> Config Class Initialized
DEBUG - 2011-09-17 14:24:45 --> Hooks Class Initialized
DEBUG - 2011-09-17 14:24:45 --> Utf8 Class Initialized
DEBUG - 2011-09-17 14:24:45 --> UTF-8 Support Enabled
DEBUG - 2011-09-17 14:24:45 --> URI Class Initialized
DEBUG - 2011-09-17 14:24:45 --> Router Class Initialized
ERROR - 2011-09-17 14:24:45 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-09-17 14:25:53 --> Config Class Initialized
DEBUG - 2011-09-17 14:25:53 --> Hooks Class Initialized
DEBUG - 2011-09-17 14:25:53 --> Utf8 Class Initialized
DEBUG - 2011-09-17 14:25:53 --> UTF-8 Support Enabled
DEBUG - 2011-09-17 14:25:53 --> URI Class Initialized
DEBUG - 2011-09-17 14:25:53 --> Router Class Initialized
DEBUG - 2011-09-17 14:25:53 --> Output Class Initialized
DEBUG - 2011-09-17 14:25:53 --> Input Class Initialized
DEBUG - 2011-09-17 14:25:53 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-17 14:25:53 --> Language Class Initialized
DEBUG - 2011-09-17 14:25:53 --> Loader Class Initialized
DEBUG - 2011-09-17 14:25:53 --> Controller Class Initialized
DEBUG - 2011-09-17 14:25:53 --> Model Class Initialized
DEBUG - 2011-09-17 14:25:53 --> Model Class Initialized
DEBUG - 2011-09-17 14:25:53 --> Model Class Initialized
DEBUG - 2011-09-17 14:25:53 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-17 14:25:53 --> Database Driver Class Initialized
DEBUG - 2011-09-17 14:25:54 --> File loaded: application/views/table/main.php
DEBUG - 2011-09-17 14:25:54 --> Helper loaded: url_helper
DEBUG - 2011-09-17 14:25:54 --> File loaded: application/views/common/header.php
DEBUG - 2011-09-17 14:25:54 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-09-17 14:25:54 --> File loaded: application/views/common/footer.php
DEBUG - 2011-09-17 14:25:54 --> File loaded: application/views/layout/main.php
DEBUG - 2011-09-17 14:25:54 --> Final output sent to browser
DEBUG - 2011-09-17 14:25:54 --> Total execution time: 0.4824
DEBUG - 2011-09-17 14:25:57 --> Config Class Initialized
DEBUG - 2011-09-17 14:25:57 --> Hooks Class Initialized
DEBUG - 2011-09-17 14:25:57 --> Utf8 Class Initialized
DEBUG - 2011-09-17 14:25:57 --> UTF-8 Support Enabled
DEBUG - 2011-09-17 14:25:57 --> URI Class Initialized
DEBUG - 2011-09-17 14:25:57 --> Router Class Initialized
DEBUG - 2011-09-17 14:25:57 --> Output Class Initialized
DEBUG - 2011-09-17 14:25:57 --> Input Class Initialized
DEBUG - 2011-09-17 14:25:57 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-17 14:25:57 --> Language Class Initialized
DEBUG - 2011-09-17 14:25:57 --> Loader Class Initialized
DEBUG - 2011-09-17 14:25:57 --> Controller Class Initialized
DEBUG - 2011-09-17 14:25:57 --> Model Class Initialized
DEBUG - 2011-09-17 14:25:57 --> Model Class Initialized
DEBUG - 2011-09-17 14:25:57 --> Model Class Initialized
DEBUG - 2011-09-17 14:25:57 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-17 14:25:57 --> Database Driver Class Initialized
DEBUG - 2011-09-17 14:25:57 --> File loaded: application/views/table/main.php
DEBUG - 2011-09-17 14:25:57 --> Helper loaded: url_helper
DEBUG - 2011-09-17 14:25:57 --> File loaded: application/views/common/header.php
DEBUG - 2011-09-17 14:25:57 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-09-17 14:25:57 --> File loaded: application/views/common/footer.php
DEBUG - 2011-09-17 14:25:57 --> File loaded: application/views/layout/main.php
DEBUG - 2011-09-17 14:25:57 --> Final output sent to browser
DEBUG - 2011-09-17 14:25:57 --> Total execution time: 0.0505
DEBUG - 2011-09-17 14:26:04 --> Config Class Initialized
DEBUG - 2011-09-17 14:26:04 --> Hooks Class Initialized
DEBUG - 2011-09-17 14:26:04 --> Utf8 Class Initialized
DEBUG - 2011-09-17 14:26:04 --> UTF-8 Support Enabled
DEBUG - 2011-09-17 14:26:04 --> URI Class Initialized
DEBUG - 2011-09-17 14:26:04 --> Router Class Initialized
DEBUG - 2011-09-17 14:26:04 --> Output Class Initialized
DEBUG - 2011-09-17 14:26:04 --> Input Class Initialized
DEBUG - 2011-09-17 14:26:04 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-17 14:26:04 --> Language Class Initialized
DEBUG - 2011-09-17 14:26:04 --> Loader Class Initialized
DEBUG - 2011-09-17 14:26:04 --> Controller Class Initialized
DEBUG - 2011-09-17 14:26:04 --> Model Class Initialized
DEBUG - 2011-09-17 14:26:04 --> Model Class Initialized
DEBUG - 2011-09-17 14:26:04 --> Model Class Initialized
DEBUG - 2011-09-17 14:26:04 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-17 14:26:04 --> Database Driver Class Initialized
DEBUG - 2011-09-17 14:26:04 --> File loaded: application/views/table/main.php
DEBUG - 2011-09-17 14:26:04 --> Helper loaded: url_helper
DEBUG - 2011-09-17 14:26:04 --> File loaded: application/views/common/header.php
DEBUG - 2011-09-17 14:26:04 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-09-17 14:26:04 --> File loaded: application/views/common/footer.php
DEBUG - 2011-09-17 14:26:04 --> File loaded: application/views/layout/main.php
DEBUG - 2011-09-17 14:26:04 --> Final output sent to browser
DEBUG - 2011-09-17 14:26:04 --> Total execution time: 0.6031
DEBUG - 2011-09-17 14:26:53 --> Config Class Initialized
DEBUG - 2011-09-17 14:26:53 --> Hooks Class Initialized
DEBUG - 2011-09-17 14:26:53 --> Utf8 Class Initialized
DEBUG - 2011-09-17 14:26:53 --> UTF-8 Support Enabled
DEBUG - 2011-09-17 14:26:53 --> URI Class Initialized
DEBUG - 2011-09-17 14:26:53 --> Router Class Initialized
DEBUG - 2011-09-17 14:26:53 --> Output Class Initialized
DEBUG - 2011-09-17 14:26:53 --> Input Class Initialized
DEBUG - 2011-09-17 14:26:53 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-17 14:26:53 --> Language Class Initialized
DEBUG - 2011-09-17 14:26:53 --> Loader Class Initialized
DEBUG - 2011-09-17 14:26:53 --> Controller Class Initialized
DEBUG - 2011-09-17 14:26:53 --> Model Class Initialized
DEBUG - 2011-09-17 14:26:53 --> Model Class Initialized
DEBUG - 2011-09-17 14:26:53 --> Model Class Initialized
DEBUG - 2011-09-17 14:26:53 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-17 14:26:53 --> Database Driver Class Initialized
DEBUG - 2011-09-17 14:26:54 --> File loaded: application/views/table/main.php
DEBUG - 2011-09-17 14:26:54 --> Helper loaded: url_helper
DEBUG - 2011-09-17 14:26:54 --> File loaded: application/views/common/header.php
DEBUG - 2011-09-17 14:26:54 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-09-17 14:26:54 --> File loaded: application/views/common/footer.php
DEBUG - 2011-09-17 14:26:54 --> File loaded: application/views/layout/main.php
DEBUG - 2011-09-17 14:26:54 --> Final output sent to browser
DEBUG - 2011-09-17 14:26:54 --> Total execution time: 0.9343
DEBUG - 2011-09-17 14:32:41 --> Config Class Initialized
DEBUG - 2011-09-17 14:32:41 --> Hooks Class Initialized
DEBUG - 2011-09-17 14:32:41 --> Utf8 Class Initialized
DEBUG - 2011-09-17 14:32:41 --> UTF-8 Support Enabled
DEBUG - 2011-09-17 14:32:41 --> URI Class Initialized
DEBUG - 2011-09-17 14:32:41 --> Router Class Initialized
DEBUG - 2011-09-17 14:32:41 --> Output Class Initialized
DEBUG - 2011-09-17 14:32:41 --> Input Class Initialized
DEBUG - 2011-09-17 14:32:41 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-17 14:32:41 --> Language Class Initialized
DEBUG - 2011-09-17 14:32:41 --> Loader Class Initialized
DEBUG - 2011-09-17 14:32:41 --> Controller Class Initialized
DEBUG - 2011-09-17 14:32:41 --> Model Class Initialized
DEBUG - 2011-09-17 14:32:41 --> Model Class Initialized
DEBUG - 2011-09-17 14:32:41 --> Model Class Initialized
DEBUG - 2011-09-17 14:32:41 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-17 14:32:41 --> Database Driver Class Initialized
DEBUG - 2011-09-17 14:32:42 --> File loaded: application/views/table/main.php
DEBUG - 2011-09-17 14:32:42 --> Helper loaded: url_helper
DEBUG - 2011-09-17 14:32:42 --> File loaded: application/views/common/header.php
DEBUG - 2011-09-17 14:32:42 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-09-17 14:32:42 --> File loaded: application/views/common/footer.php
DEBUG - 2011-09-17 14:32:42 --> File loaded: application/views/layout/main.php
DEBUG - 2011-09-17 14:32:42 --> Final output sent to browser
DEBUG - 2011-09-17 14:32:42 --> Total execution time: 0.2021
DEBUG - 2011-09-17 14:32:51 --> Config Class Initialized
DEBUG - 2011-09-17 14:32:51 --> Hooks Class Initialized
DEBUG - 2011-09-17 14:32:51 --> Utf8 Class Initialized
DEBUG - 2011-09-17 14:32:51 --> UTF-8 Support Enabled
DEBUG - 2011-09-17 14:32:51 --> URI Class Initialized
DEBUG - 2011-09-17 14:32:51 --> Router Class Initialized
DEBUG - 2011-09-17 14:32:51 --> Output Class Initialized
DEBUG - 2011-09-17 14:32:51 --> Input Class Initialized
DEBUG - 2011-09-17 14:32:51 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-17 14:32:51 --> Language Class Initialized
DEBUG - 2011-09-17 14:32:51 --> Loader Class Initialized
DEBUG - 2011-09-17 14:32:51 --> Controller Class Initialized
DEBUG - 2011-09-17 14:32:51 --> Model Class Initialized
DEBUG - 2011-09-17 14:32:51 --> Model Class Initialized
DEBUG - 2011-09-17 14:32:51 --> Model Class Initialized
DEBUG - 2011-09-17 14:32:51 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-17 14:32:51 --> Database Driver Class Initialized
DEBUG - 2011-09-17 14:32:52 --> File loaded: application/views/table/main.php
DEBUG - 2011-09-17 14:32:52 --> Helper loaded: url_helper
DEBUG - 2011-09-17 14:32:52 --> File loaded: application/views/common/header.php
DEBUG - 2011-09-17 14:32:52 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-09-17 14:32:52 --> File loaded: application/views/common/footer.php
DEBUG - 2011-09-17 14:32:52 --> File loaded: application/views/layout/main.php
DEBUG - 2011-09-17 14:32:52 --> Final output sent to browser
DEBUG - 2011-09-17 14:32:52 --> Total execution time: 0.2551
DEBUG - 2011-09-17 14:33:01 --> Config Class Initialized
DEBUG - 2011-09-17 14:33:01 --> Hooks Class Initialized
DEBUG - 2011-09-17 14:33:01 --> Utf8 Class Initialized
DEBUG - 2011-09-17 14:33:01 --> UTF-8 Support Enabled
DEBUG - 2011-09-17 14:33:01 --> URI Class Initialized
DEBUG - 2011-09-17 14:33:01 --> Router Class Initialized
DEBUG - 2011-09-17 14:33:01 --> Output Class Initialized
DEBUG - 2011-09-17 14:33:01 --> Input Class Initialized
DEBUG - 2011-09-17 14:33:01 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-17 14:33:01 --> Language Class Initialized
DEBUG - 2011-09-17 14:33:01 --> Loader Class Initialized
DEBUG - 2011-09-17 14:33:01 --> Controller Class Initialized
DEBUG - 2011-09-17 14:33:01 --> Model Class Initialized
DEBUG - 2011-09-17 14:33:01 --> Model Class Initialized
DEBUG - 2011-09-17 14:33:01 --> Model Class Initialized
DEBUG - 2011-09-17 14:33:01 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-17 14:33:01 --> Database Driver Class Initialized
DEBUG - 2011-09-17 14:33:02 --> File loaded: application/views/table/main.php
DEBUG - 2011-09-17 14:33:02 --> Helper loaded: url_helper
DEBUG - 2011-09-17 14:33:02 --> File loaded: application/views/common/header.php
DEBUG - 2011-09-17 14:33:02 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-09-17 14:33:02 --> File loaded: application/views/common/footer.php
DEBUG - 2011-09-17 14:33:02 --> File loaded: application/views/layout/main.php
DEBUG - 2011-09-17 14:33:02 --> Final output sent to browser
DEBUG - 2011-09-17 14:33:02 --> Total execution time: 0.8526
DEBUG - 2011-09-17 14:33:11 --> Config Class Initialized
DEBUG - 2011-09-17 14:33:11 --> Hooks Class Initialized
DEBUG - 2011-09-17 14:33:11 --> Utf8 Class Initialized
DEBUG - 2011-09-17 14:33:11 --> UTF-8 Support Enabled
DEBUG - 2011-09-17 14:33:11 --> URI Class Initialized
DEBUG - 2011-09-17 14:33:11 --> Router Class Initialized
DEBUG - 2011-09-17 14:33:11 --> Output Class Initialized
DEBUG - 2011-09-17 14:33:11 --> Input Class Initialized
DEBUG - 2011-09-17 14:33:11 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-17 14:33:11 --> Language Class Initialized
DEBUG - 2011-09-17 14:33:11 --> Loader Class Initialized
DEBUG - 2011-09-17 14:33:11 --> Controller Class Initialized
DEBUG - 2011-09-17 14:33:11 --> Model Class Initialized
DEBUG - 2011-09-17 14:33:11 --> Model Class Initialized
DEBUG - 2011-09-17 14:33:11 --> Model Class Initialized
DEBUG - 2011-09-17 14:33:11 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-17 14:33:11 --> Database Driver Class Initialized
DEBUG - 2011-09-17 14:33:11 --> File loaded: application/views/table/main.php
DEBUG - 2011-09-17 14:33:11 --> Helper loaded: url_helper
DEBUG - 2011-09-17 14:33:11 --> File loaded: application/views/common/header.php
DEBUG - 2011-09-17 14:33:11 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-09-17 14:33:11 --> File loaded: application/views/common/footer.php
DEBUG - 2011-09-17 14:33:11 --> File loaded: application/views/layout/main.php
DEBUG - 2011-09-17 14:33:11 --> Final output sent to browser
DEBUG - 2011-09-17 14:33:11 --> Total execution time: 0.6597
DEBUG - 2011-09-17 14:33:19 --> Config Class Initialized
DEBUG - 2011-09-17 14:33:19 --> Hooks Class Initialized
DEBUG - 2011-09-17 14:33:19 --> Utf8 Class Initialized
DEBUG - 2011-09-17 14:33:19 --> UTF-8 Support Enabled
DEBUG - 2011-09-17 14:33:19 --> URI Class Initialized
DEBUG - 2011-09-17 14:33:19 --> Router Class Initialized
DEBUG - 2011-09-17 14:33:19 --> Output Class Initialized
DEBUG - 2011-09-17 14:33:19 --> Input Class Initialized
DEBUG - 2011-09-17 14:33:19 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-17 14:33:19 --> Language Class Initialized
DEBUG - 2011-09-17 14:33:19 --> Loader Class Initialized
DEBUG - 2011-09-17 14:33:19 --> Controller Class Initialized
DEBUG - 2011-09-17 14:33:19 --> Model Class Initialized
DEBUG - 2011-09-17 14:33:19 --> Model Class Initialized
DEBUG - 2011-09-17 14:33:19 --> Model Class Initialized
DEBUG - 2011-09-17 14:33:19 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-17 14:33:19 --> Database Driver Class Initialized
DEBUG - 2011-09-17 14:33:20 --> File loaded: application/views/table/main.php
DEBUG - 2011-09-17 14:33:20 --> Helper loaded: url_helper
DEBUG - 2011-09-17 14:33:20 --> File loaded: application/views/common/header.php
DEBUG - 2011-09-17 14:33:20 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-09-17 14:33:20 --> File loaded: application/views/common/footer.php
DEBUG - 2011-09-17 14:33:20 --> File loaded: application/views/layout/main.php
DEBUG - 2011-09-17 14:33:20 --> Final output sent to browser
DEBUG - 2011-09-17 14:33:20 --> Total execution time: 0.3173
DEBUG - 2011-09-17 14:33:23 --> Config Class Initialized
DEBUG - 2011-09-17 14:33:23 --> Hooks Class Initialized
DEBUG - 2011-09-17 14:33:23 --> Utf8 Class Initialized
DEBUG - 2011-09-17 14:33:23 --> UTF-8 Support Enabled
DEBUG - 2011-09-17 14:33:23 --> URI Class Initialized
DEBUG - 2011-09-17 14:33:23 --> Router Class Initialized
DEBUG - 2011-09-17 14:33:23 --> Output Class Initialized
DEBUG - 2011-09-17 14:33:23 --> Input Class Initialized
DEBUG - 2011-09-17 14:33:23 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-17 14:33:23 --> Language Class Initialized
DEBUG - 2011-09-17 14:33:23 --> Loader Class Initialized
DEBUG - 2011-09-17 14:33:23 --> Controller Class Initialized
DEBUG - 2011-09-17 14:33:23 --> Model Class Initialized
DEBUG - 2011-09-17 14:33:23 --> Model Class Initialized
DEBUG - 2011-09-17 14:33:23 --> Model Class Initialized
DEBUG - 2011-09-17 14:33:23 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-17 14:33:23 --> Database Driver Class Initialized
DEBUG - 2011-09-17 14:33:23 --> File loaded: application/views/table/main.php
DEBUG - 2011-09-17 14:33:23 --> Helper loaded: url_helper
DEBUG - 2011-09-17 14:33:23 --> File loaded: application/views/common/header.php
DEBUG - 2011-09-17 14:33:23 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-09-17 14:33:23 --> File loaded: application/views/common/footer.php
DEBUG - 2011-09-17 14:33:23 --> File loaded: application/views/layout/main.php
DEBUG - 2011-09-17 14:33:23 --> Final output sent to browser
DEBUG - 2011-09-17 14:33:23 --> Total execution time: 0.1677
DEBUG - 2011-09-17 14:33:28 --> Config Class Initialized
DEBUG - 2011-09-17 14:33:28 --> Hooks Class Initialized
DEBUG - 2011-09-17 14:33:28 --> Utf8 Class Initialized
DEBUG - 2011-09-17 14:33:28 --> UTF-8 Support Enabled
DEBUG - 2011-09-17 14:33:28 --> URI Class Initialized
DEBUG - 2011-09-17 14:33:28 --> Router Class Initialized
DEBUG - 2011-09-17 14:33:28 --> Output Class Initialized
DEBUG - 2011-09-17 14:33:28 --> Input Class Initialized
DEBUG - 2011-09-17 14:33:28 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-17 14:33:28 --> Language Class Initialized
DEBUG - 2011-09-17 14:33:28 --> Loader Class Initialized
DEBUG - 2011-09-17 14:33:28 --> Controller Class Initialized
DEBUG - 2011-09-17 14:33:28 --> Model Class Initialized
DEBUG - 2011-09-17 14:33:28 --> Model Class Initialized
DEBUG - 2011-09-17 14:33:28 --> Model Class Initialized
DEBUG - 2011-09-17 14:33:28 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-17 14:33:28 --> Database Driver Class Initialized
DEBUG - 2011-09-17 14:33:28 --> File loaded: application/views/table/main.php
DEBUG - 2011-09-17 14:33:28 --> Helper loaded: url_helper
DEBUG - 2011-09-17 14:33:28 --> File loaded: application/views/common/header.php
DEBUG - 2011-09-17 14:33:28 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-09-17 14:33:28 --> File loaded: application/views/common/footer.php
DEBUG - 2011-09-17 14:33:28 --> File loaded: application/views/layout/main.php
DEBUG - 2011-09-17 14:33:28 --> Final output sent to browser
DEBUG - 2011-09-17 14:33:28 --> Total execution time: 0.2777
DEBUG - 2011-09-17 14:33:31 --> Config Class Initialized
DEBUG - 2011-09-17 14:33:31 --> Hooks Class Initialized
DEBUG - 2011-09-17 14:33:31 --> Utf8 Class Initialized
DEBUG - 2011-09-17 14:33:31 --> UTF-8 Support Enabled
DEBUG - 2011-09-17 14:33:31 --> URI Class Initialized
DEBUG - 2011-09-17 14:33:31 --> Router Class Initialized
DEBUG - 2011-09-17 14:33:31 --> Output Class Initialized
DEBUG - 2011-09-17 14:33:31 --> Input Class Initialized
DEBUG - 2011-09-17 14:33:31 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-17 14:33:31 --> Language Class Initialized
DEBUG - 2011-09-17 14:33:31 --> Loader Class Initialized
DEBUG - 2011-09-17 14:33:31 --> Controller Class Initialized
DEBUG - 2011-09-17 14:33:31 --> Model Class Initialized
DEBUG - 2011-09-17 14:33:31 --> Model Class Initialized
DEBUG - 2011-09-17 14:33:31 --> Model Class Initialized
DEBUG - 2011-09-17 14:33:31 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-17 14:33:31 --> Database Driver Class Initialized
DEBUG - 2011-09-17 14:33:31 --> File loaded: application/views/table/main.php
DEBUG - 2011-09-17 14:33:31 --> Helper loaded: url_helper
DEBUG - 2011-09-17 14:33:31 --> File loaded: application/views/common/header.php
DEBUG - 2011-09-17 14:33:31 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-09-17 14:33:31 --> File loaded: application/views/common/footer.php
DEBUG - 2011-09-17 14:33:31 --> File loaded: application/views/layout/main.php
DEBUG - 2011-09-17 14:33:31 --> Final output sent to browser
DEBUG - 2011-09-17 14:33:31 --> Total execution time: 0.0442
DEBUG - 2011-09-17 14:33:34 --> Config Class Initialized
DEBUG - 2011-09-17 14:33:34 --> Hooks Class Initialized
DEBUG - 2011-09-17 14:33:34 --> Utf8 Class Initialized
DEBUG - 2011-09-17 14:33:34 --> UTF-8 Support Enabled
DEBUG - 2011-09-17 14:33:34 --> URI Class Initialized
DEBUG - 2011-09-17 14:33:34 --> Router Class Initialized
DEBUG - 2011-09-17 14:33:34 --> Output Class Initialized
DEBUG - 2011-09-17 14:33:34 --> Input Class Initialized
DEBUG - 2011-09-17 14:33:34 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-17 14:33:34 --> Language Class Initialized
DEBUG - 2011-09-17 14:33:34 --> Loader Class Initialized
DEBUG - 2011-09-17 14:33:34 --> Controller Class Initialized
DEBUG - 2011-09-17 14:33:34 --> Model Class Initialized
DEBUG - 2011-09-17 14:33:34 --> Model Class Initialized
DEBUG - 2011-09-17 14:33:34 --> Model Class Initialized
DEBUG - 2011-09-17 14:33:34 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-17 14:33:34 --> Database Driver Class Initialized
DEBUG - 2011-09-17 14:33:34 --> File loaded: application/views/table/main.php
DEBUG - 2011-09-17 14:33:34 --> Helper loaded: url_helper
DEBUG - 2011-09-17 14:33:34 --> File loaded: application/views/common/header.php
DEBUG - 2011-09-17 14:33:34 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-09-17 14:33:34 --> File loaded: application/views/common/footer.php
DEBUG - 2011-09-17 14:33:34 --> File loaded: application/views/layout/main.php
DEBUG - 2011-09-17 14:33:34 --> Final output sent to browser
DEBUG - 2011-09-17 14:33:34 --> Total execution time: 0.2261
DEBUG - 2011-09-17 14:34:32 --> Config Class Initialized
DEBUG - 2011-09-17 14:34:32 --> Hooks Class Initialized
DEBUG - 2011-09-17 14:34:32 --> Utf8 Class Initialized
DEBUG - 2011-09-17 14:34:32 --> UTF-8 Support Enabled
DEBUG - 2011-09-17 14:34:32 --> URI Class Initialized
DEBUG - 2011-09-17 14:34:32 --> Router Class Initialized
DEBUG - 2011-09-17 14:34:32 --> Output Class Initialized
DEBUG - 2011-09-17 14:34:32 --> Input Class Initialized
DEBUG - 2011-09-17 14:34:32 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-17 14:34:32 --> Language Class Initialized
DEBUG - 2011-09-17 14:34:32 --> Loader Class Initialized
DEBUG - 2011-09-17 14:34:32 --> Controller Class Initialized
DEBUG - 2011-09-17 14:34:32 --> Model Class Initialized
DEBUG - 2011-09-17 14:34:32 --> Model Class Initialized
DEBUG - 2011-09-17 14:34:32 --> Model Class Initialized
DEBUG - 2011-09-17 14:34:32 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-17 14:34:32 --> Database Driver Class Initialized
DEBUG - 2011-09-17 14:34:32 --> File loaded: application/views/table/main.php
DEBUG - 2011-09-17 14:34:32 --> Helper loaded: url_helper
DEBUG - 2011-09-17 14:34:32 --> File loaded: application/views/common/header.php
DEBUG - 2011-09-17 14:34:32 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-09-17 14:34:32 --> File loaded: application/views/common/footer.php
DEBUG - 2011-09-17 14:34:32 --> File loaded: application/views/layout/main.php
DEBUG - 2011-09-17 14:34:32 --> Final output sent to browser
DEBUG - 2011-09-17 14:34:32 --> Total execution time: 0.2417
DEBUG - 2011-09-17 14:35:01 --> Config Class Initialized
DEBUG - 2011-09-17 14:35:01 --> Hooks Class Initialized
DEBUG - 2011-09-17 14:35:01 --> Utf8 Class Initialized
DEBUG - 2011-09-17 14:35:01 --> UTF-8 Support Enabled
DEBUG - 2011-09-17 14:35:01 --> URI Class Initialized
DEBUG - 2011-09-17 14:35:01 --> Router Class Initialized
DEBUG - 2011-09-17 14:35:01 --> Output Class Initialized
DEBUG - 2011-09-17 14:35:01 --> Input Class Initialized
DEBUG - 2011-09-17 14:35:01 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-17 14:35:01 --> Language Class Initialized
DEBUG - 2011-09-17 14:35:01 --> Loader Class Initialized
DEBUG - 2011-09-17 14:35:01 --> Controller Class Initialized
DEBUG - 2011-09-17 14:35:01 --> Model Class Initialized
DEBUG - 2011-09-17 14:35:01 --> Model Class Initialized
DEBUG - 2011-09-17 14:35:01 --> Model Class Initialized
DEBUG - 2011-09-17 14:35:01 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-17 14:35:01 --> Database Driver Class Initialized
DEBUG - 2011-09-17 14:35:01 --> File loaded: application/views/table/main.php
DEBUG - 2011-09-17 14:35:01 --> Helper loaded: url_helper
DEBUG - 2011-09-17 14:35:01 --> File loaded: application/views/common/header.php
DEBUG - 2011-09-17 14:35:01 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-09-17 14:35:01 --> File loaded: application/views/common/footer.php
DEBUG - 2011-09-17 14:35:01 --> File loaded: application/views/layout/main.php
DEBUG - 2011-09-17 14:35:01 --> Final output sent to browser
DEBUG - 2011-09-17 14:35:01 --> Total execution time: 0.0842
DEBUG - 2011-09-17 14:35:15 --> Config Class Initialized
DEBUG - 2011-09-17 14:35:15 --> Hooks Class Initialized
DEBUG - 2011-09-17 14:35:15 --> Utf8 Class Initialized
DEBUG - 2011-09-17 14:35:15 --> UTF-8 Support Enabled
DEBUG - 2011-09-17 14:35:15 --> URI Class Initialized
DEBUG - 2011-09-17 14:35:15 --> Router Class Initialized
DEBUG - 2011-09-17 14:35:15 --> Output Class Initialized
DEBUG - 2011-09-17 14:35:15 --> Input Class Initialized
DEBUG - 2011-09-17 14:35:15 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-17 14:35:15 --> Language Class Initialized
DEBUG - 2011-09-17 14:35:15 --> Loader Class Initialized
DEBUG - 2011-09-17 14:35:15 --> Controller Class Initialized
DEBUG - 2011-09-17 14:35:15 --> Model Class Initialized
DEBUG - 2011-09-17 14:35:15 --> Model Class Initialized
DEBUG - 2011-09-17 14:35:15 --> Model Class Initialized
DEBUG - 2011-09-17 14:35:15 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-17 14:35:15 --> Database Driver Class Initialized
DEBUG - 2011-09-17 14:35:15 --> File loaded: application/views/table/main.php
DEBUG - 2011-09-17 14:35:15 --> Helper loaded: url_helper
DEBUG - 2011-09-17 14:35:15 --> File loaded: application/views/common/header.php
DEBUG - 2011-09-17 14:35:15 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-09-17 14:35:15 --> File loaded: application/views/common/footer.php
DEBUG - 2011-09-17 14:35:15 --> File loaded: application/views/layout/main.php
DEBUG - 2011-09-17 14:35:15 --> Final output sent to browser
DEBUG - 2011-09-17 14:35:15 --> Total execution time: 0.3337
DEBUG - 2011-09-17 14:35:45 --> Config Class Initialized
DEBUG - 2011-09-17 14:35:45 --> Hooks Class Initialized
DEBUG - 2011-09-17 14:35:45 --> Utf8 Class Initialized
DEBUG - 2011-09-17 14:35:45 --> UTF-8 Support Enabled
DEBUG - 2011-09-17 14:35:45 --> URI Class Initialized
DEBUG - 2011-09-17 14:35:45 --> Router Class Initialized
DEBUG - 2011-09-17 14:35:45 --> Output Class Initialized
DEBUG - 2011-09-17 14:35:45 --> Input Class Initialized
DEBUG - 2011-09-17 14:35:45 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-17 14:35:45 --> Language Class Initialized
DEBUG - 2011-09-17 14:35:45 --> Loader Class Initialized
DEBUG - 2011-09-17 14:35:45 --> Controller Class Initialized
DEBUG - 2011-09-17 14:35:45 --> Model Class Initialized
DEBUG - 2011-09-17 14:35:45 --> Model Class Initialized
DEBUG - 2011-09-17 14:35:45 --> Model Class Initialized
DEBUG - 2011-09-17 14:35:45 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-17 14:35:45 --> Database Driver Class Initialized
DEBUG - 2011-09-17 14:35:45 --> File loaded: application/views/table/main.php
DEBUG - 2011-09-17 14:35:45 --> Helper loaded: url_helper
DEBUG - 2011-09-17 14:35:45 --> File loaded: application/views/common/header.php
DEBUG - 2011-09-17 14:35:45 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-09-17 14:35:45 --> File loaded: application/views/common/footer.php
DEBUG - 2011-09-17 14:35:45 --> File loaded: application/views/layout/main.php
DEBUG - 2011-09-17 14:35:45 --> Final output sent to browser
DEBUG - 2011-09-17 14:35:45 --> Total execution time: 0.1011
DEBUG - 2011-09-17 14:47:14 --> Config Class Initialized
DEBUG - 2011-09-17 14:47:14 --> Hooks Class Initialized
DEBUG - 2011-09-17 14:47:14 --> Utf8 Class Initialized
DEBUG - 2011-09-17 14:47:14 --> UTF-8 Support Enabled
DEBUG - 2011-09-17 14:47:14 --> URI Class Initialized
DEBUG - 2011-09-17 14:47:14 --> Router Class Initialized
DEBUG - 2011-09-17 14:47:14 --> Output Class Initialized
DEBUG - 2011-09-17 14:47:14 --> Input Class Initialized
DEBUG - 2011-09-17 14:47:14 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-17 14:47:14 --> Language Class Initialized
DEBUG - 2011-09-17 14:47:14 --> Loader Class Initialized
DEBUG - 2011-09-17 14:47:14 --> Controller Class Initialized
DEBUG - 2011-09-17 14:47:14 --> Model Class Initialized
DEBUG - 2011-09-17 14:47:14 --> Model Class Initialized
DEBUG - 2011-09-17 14:47:14 --> Model Class Initialized
DEBUG - 2011-09-17 14:47:14 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-17 14:47:14 --> Database Driver Class Initialized
DEBUG - 2011-09-17 14:47:15 --> File loaded: application/views/table/main.php
DEBUG - 2011-09-17 14:47:15 --> Helper loaded: url_helper
DEBUG - 2011-09-17 14:47:15 --> File loaded: application/views/common/header.php
DEBUG - 2011-09-17 14:47:15 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-09-17 14:47:15 --> File loaded: application/views/common/footer.php
DEBUG - 2011-09-17 14:47:15 --> File loaded: application/views/layout/main.php
DEBUG - 2011-09-17 14:47:15 --> Final output sent to browser
DEBUG - 2011-09-17 14:47:15 --> Total execution time: 0.2010
DEBUG - 2011-09-17 14:47:16 --> Config Class Initialized
DEBUG - 2011-09-17 14:47:16 --> Hooks Class Initialized
DEBUG - 2011-09-17 14:47:16 --> Utf8 Class Initialized
DEBUG - 2011-09-17 14:47:16 --> UTF-8 Support Enabled
DEBUG - 2011-09-17 14:47:16 --> URI Class Initialized
DEBUG - 2011-09-17 14:47:16 --> Router Class Initialized
DEBUG - 2011-09-17 14:47:16 --> Output Class Initialized
DEBUG - 2011-09-17 14:47:16 --> Input Class Initialized
DEBUG - 2011-09-17 14:47:16 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-17 14:47:16 --> Language Class Initialized
DEBUG - 2011-09-17 14:47:16 --> Loader Class Initialized
DEBUG - 2011-09-17 14:47:16 --> Controller Class Initialized
ERROR - 2011-09-17 14:47:16 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-09-17 14:47:16 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-09-17 14:47:16 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-09-17 14:47:16 --> Model Class Initialized
DEBUG - 2011-09-17 14:47:16 --> Model Class Initialized
DEBUG - 2011-09-17 14:47:16 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-17 14:47:16 --> Database Driver Class Initialized
DEBUG - 2011-09-17 14:47:16 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-09-17 14:47:16 --> Helper loaded: url_helper
DEBUG - 2011-09-17 14:47:16 --> File loaded: application/views/common/header.php
DEBUG - 2011-09-17 14:47:16 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-09-17 14:47:16 --> File loaded: application/views/common/footer.php
DEBUG - 2011-09-17 14:47:16 --> File loaded: application/views/layout/main.php
DEBUG - 2011-09-17 14:47:16 --> Final output sent to browser
DEBUG - 2011-09-17 14:47:16 --> Total execution time: 0.0287
DEBUG - 2011-09-17 14:47:18 --> Config Class Initialized
DEBUG - 2011-09-17 14:47:18 --> Hooks Class Initialized
DEBUG - 2011-09-17 14:47:18 --> Utf8 Class Initialized
DEBUG - 2011-09-17 14:47:18 --> UTF-8 Support Enabled
DEBUG - 2011-09-17 14:47:18 --> URI Class Initialized
DEBUG - 2011-09-17 14:47:18 --> Router Class Initialized
DEBUG - 2011-09-17 14:47:18 --> Output Class Initialized
DEBUG - 2011-09-17 14:47:18 --> Input Class Initialized
DEBUG - 2011-09-17 14:47:18 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-17 14:47:18 --> Language Class Initialized
DEBUG - 2011-09-17 14:47:18 --> Loader Class Initialized
DEBUG - 2011-09-17 14:47:18 --> Controller Class Initialized
DEBUG - 2011-09-17 14:47:18 --> Model Class Initialized
DEBUG - 2011-09-17 14:47:18 --> Model Class Initialized
DEBUG - 2011-09-17 14:47:18 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-17 14:47:18 --> Database Driver Class Initialized
DEBUG - 2011-09-17 14:47:19 --> Final output sent to browser
DEBUG - 2011-09-17 14:47:19 --> Total execution time: 0.5132
DEBUG - 2011-09-17 14:47:23 --> Config Class Initialized
DEBUG - 2011-09-17 14:47:23 --> Hooks Class Initialized
DEBUG - 2011-09-17 14:47:23 --> Utf8 Class Initialized
DEBUG - 2011-09-17 14:47:23 --> UTF-8 Support Enabled
DEBUG - 2011-09-17 14:47:23 --> URI Class Initialized
DEBUG - 2011-09-17 14:47:23 --> Router Class Initialized
ERROR - 2011-09-17 14:47:23 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-09-17 14:47:24 --> Config Class Initialized
DEBUG - 2011-09-17 14:47:24 --> Hooks Class Initialized
DEBUG - 2011-09-17 14:47:24 --> Utf8 Class Initialized
DEBUG - 2011-09-17 14:47:24 --> UTF-8 Support Enabled
DEBUG - 2011-09-17 14:47:24 --> URI Class Initialized
DEBUG - 2011-09-17 14:47:24 --> Router Class Initialized
ERROR - 2011-09-17 14:47:24 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-09-17 14:47:33 --> Config Class Initialized
DEBUG - 2011-09-17 14:47:33 --> Hooks Class Initialized
DEBUG - 2011-09-17 14:47:33 --> Utf8 Class Initialized
DEBUG - 2011-09-17 14:47:33 --> UTF-8 Support Enabled
DEBUG - 2011-09-17 14:47:33 --> URI Class Initialized
DEBUG - 2011-09-17 14:47:33 --> Router Class Initialized
DEBUG - 2011-09-17 14:47:33 --> Output Class Initialized
DEBUG - 2011-09-17 14:47:33 --> Input Class Initialized
DEBUG - 2011-09-17 14:47:33 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-17 14:47:33 --> Language Class Initialized
DEBUG - 2011-09-17 14:47:33 --> Loader Class Initialized
DEBUG - 2011-09-17 14:47:33 --> Controller Class Initialized
ERROR - 2011-09-17 14:47:33 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-09-17 14:47:33 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-09-17 14:47:33 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-09-17 14:47:33 --> Model Class Initialized
DEBUG - 2011-09-17 14:47:33 --> Model Class Initialized
DEBUG - 2011-09-17 14:47:33 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-17 14:47:33 --> Database Driver Class Initialized
DEBUG - 2011-09-17 14:47:33 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-09-17 14:47:33 --> Helper loaded: url_helper
DEBUG - 2011-09-17 14:47:33 --> File loaded: application/views/common/header.php
DEBUG - 2011-09-17 14:47:33 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-09-17 14:47:33 --> File loaded: application/views/common/footer.php
DEBUG - 2011-09-17 14:47:33 --> File loaded: application/views/layout/main.php
DEBUG - 2011-09-17 14:47:33 --> Final output sent to browser
DEBUG - 2011-09-17 14:47:33 --> Total execution time: 0.0317
DEBUG - 2011-09-17 14:47:34 --> Config Class Initialized
DEBUG - 2011-09-17 14:47:34 --> Hooks Class Initialized
DEBUG - 2011-09-17 14:47:34 --> Utf8 Class Initialized
DEBUG - 2011-09-17 14:47:34 --> UTF-8 Support Enabled
DEBUG - 2011-09-17 14:47:34 --> URI Class Initialized
DEBUG - 2011-09-17 14:47:34 --> Router Class Initialized
DEBUG - 2011-09-17 14:47:34 --> Output Class Initialized
DEBUG - 2011-09-17 14:47:34 --> Input Class Initialized
DEBUG - 2011-09-17 14:47:34 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-17 14:47:34 --> Language Class Initialized
DEBUG - 2011-09-17 14:47:34 --> Loader Class Initialized
DEBUG - 2011-09-17 14:47:34 --> Controller Class Initialized
DEBUG - 2011-09-17 14:47:34 --> Model Class Initialized
DEBUG - 2011-09-17 14:47:34 --> Model Class Initialized
DEBUG - 2011-09-17 14:47:34 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-17 14:47:34 --> Database Driver Class Initialized
DEBUG - 2011-09-17 14:47:35 --> Final output sent to browser
DEBUG - 2011-09-17 14:47:35 --> Total execution time: 0.5704
DEBUG - 2011-09-17 14:47:37 --> Config Class Initialized
DEBUG - 2011-09-17 14:47:37 --> Hooks Class Initialized
DEBUG - 2011-09-17 14:47:37 --> Utf8 Class Initialized
DEBUG - 2011-09-17 14:47:37 --> UTF-8 Support Enabled
DEBUG - 2011-09-17 14:47:37 --> URI Class Initialized
DEBUG - 2011-09-17 14:47:37 --> Router Class Initialized
ERROR - 2011-09-17 14:47:37 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-09-17 14:47:46 --> Config Class Initialized
DEBUG - 2011-09-17 14:47:46 --> Hooks Class Initialized
DEBUG - 2011-09-17 14:47:46 --> Utf8 Class Initialized
DEBUG - 2011-09-17 14:47:46 --> UTF-8 Support Enabled
DEBUG - 2011-09-17 14:47:46 --> URI Class Initialized
DEBUG - 2011-09-17 14:47:46 --> Router Class Initialized
ERROR - 2011-09-17 14:47:46 --> 404 Page Not Found --> robots.txt
DEBUG - 2011-09-17 14:47:47 --> Config Class Initialized
DEBUG - 2011-09-17 14:47:47 --> Hooks Class Initialized
DEBUG - 2011-09-17 14:47:47 --> Utf8 Class Initialized
DEBUG - 2011-09-17 14:47:47 --> UTF-8 Support Enabled
DEBUG - 2011-09-17 14:47:47 --> URI Class Initialized
DEBUG - 2011-09-17 14:47:47 --> Router Class Initialized
DEBUG - 2011-09-17 14:47:47 --> Output Class Initialized
DEBUG - 2011-09-17 14:47:47 --> Input Class Initialized
DEBUG - 2011-09-17 14:47:47 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-17 14:47:47 --> Language Class Initialized
DEBUG - 2011-09-17 14:47:47 --> Loader Class Initialized
DEBUG - 2011-09-17 14:47:47 --> Controller Class Initialized
ERROR - 2011-09-17 14:47:47 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-09-17 14:47:47 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-09-17 14:47:47 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-09-17 14:47:47 --> Model Class Initialized
DEBUG - 2011-09-17 14:47:47 --> Model Class Initialized
DEBUG - 2011-09-17 14:47:47 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-17 14:47:47 --> Database Driver Class Initialized
DEBUG - 2011-09-17 14:47:47 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-09-17 14:47:47 --> Helper loaded: url_helper
DEBUG - 2011-09-17 14:47:47 --> File loaded: application/views/common/header.php
DEBUG - 2011-09-17 14:47:47 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-09-17 14:47:47 --> File loaded: application/views/common/footer.php
DEBUG - 2011-09-17 14:47:47 --> File loaded: application/views/layout/main.php
DEBUG - 2011-09-17 14:47:47 --> Final output sent to browser
DEBUG - 2011-09-17 14:47:47 --> Total execution time: 0.0271
DEBUG - 2011-09-17 14:47:50 --> Config Class Initialized
DEBUG - 2011-09-17 14:47:50 --> Hooks Class Initialized
DEBUG - 2011-09-17 14:47:50 --> Utf8 Class Initialized
DEBUG - 2011-09-17 14:47:50 --> UTF-8 Support Enabled
DEBUG - 2011-09-17 14:47:50 --> URI Class Initialized
DEBUG - 2011-09-17 14:47:50 --> Router Class Initialized
ERROR - 2011-09-17 14:47:50 --> 404 Page Not Found --> robots.txt
DEBUG - 2011-09-17 14:47:50 --> Config Class Initialized
DEBUG - 2011-09-17 14:47:50 --> Hooks Class Initialized
DEBUG - 2011-09-17 14:47:50 --> Utf8 Class Initialized
DEBUG - 2011-09-17 14:47:50 --> UTF-8 Support Enabled
DEBUG - 2011-09-17 14:47:50 --> URI Class Initialized
DEBUG - 2011-09-17 14:47:50 --> Router Class Initialized
DEBUG - 2011-09-17 14:47:50 --> Output Class Initialized
DEBUG - 2011-09-17 14:47:50 --> Input Class Initialized
DEBUG - 2011-09-17 14:47:50 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-17 14:47:50 --> Language Class Initialized
DEBUG - 2011-09-17 14:47:50 --> Loader Class Initialized
DEBUG - 2011-09-17 14:47:50 --> Controller Class Initialized
DEBUG - 2011-09-17 14:47:50 --> Model Class Initialized
DEBUG - 2011-09-17 14:47:50 --> Model Class Initialized
DEBUG - 2011-09-17 14:47:50 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-17 14:47:50 --> Database Driver Class Initialized
DEBUG - 2011-09-17 14:47:50 --> Final output sent to browser
DEBUG - 2011-09-17 14:47:50 --> Total execution time: 0.3177
DEBUG - 2011-09-17 14:48:11 --> Config Class Initialized
DEBUG - 2011-09-17 14:48:11 --> Hooks Class Initialized
DEBUG - 2011-09-17 14:48:11 --> Utf8 Class Initialized
DEBUG - 2011-09-17 14:48:11 --> UTF-8 Support Enabled
DEBUG - 2011-09-17 14:48:11 --> URI Class Initialized
DEBUG - 2011-09-17 14:48:11 --> Router Class Initialized
DEBUG - 2011-09-17 14:48:11 --> Output Class Initialized
DEBUG - 2011-09-17 14:48:11 --> Input Class Initialized
DEBUG - 2011-09-17 14:48:11 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-17 14:48:11 --> Language Class Initialized
DEBUG - 2011-09-17 14:48:11 --> Loader Class Initialized
DEBUG - 2011-09-17 14:48:11 --> Controller Class Initialized
ERROR - 2011-09-17 14:48:11 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-09-17 14:48:11 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-09-17 14:48:11 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-09-17 14:48:11 --> Model Class Initialized
DEBUG - 2011-09-17 14:48:11 --> Model Class Initialized
DEBUG - 2011-09-17 14:48:11 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-17 14:48:11 --> Database Driver Class Initialized
DEBUG - 2011-09-17 14:48:11 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-09-17 14:48:11 --> Helper loaded: url_helper
DEBUG - 2011-09-17 14:48:11 --> File loaded: application/views/common/header.php
DEBUG - 2011-09-17 14:48:11 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-09-17 14:48:11 --> File loaded: application/views/common/footer.php
DEBUG - 2011-09-17 14:48:11 --> File loaded: application/views/layout/main.php
DEBUG - 2011-09-17 14:48:11 --> Final output sent to browser
DEBUG - 2011-09-17 14:48:11 --> Total execution time: 0.0310
DEBUG - 2011-09-17 14:48:13 --> Config Class Initialized
DEBUG - 2011-09-17 14:48:13 --> Hooks Class Initialized
DEBUG - 2011-09-17 14:48:13 --> Utf8 Class Initialized
DEBUG - 2011-09-17 14:48:13 --> UTF-8 Support Enabled
DEBUG - 2011-09-17 14:48:13 --> URI Class Initialized
DEBUG - 2011-09-17 14:48:13 --> Router Class Initialized
DEBUG - 2011-09-17 14:48:13 --> Output Class Initialized
DEBUG - 2011-09-17 14:48:13 --> Input Class Initialized
DEBUG - 2011-09-17 14:48:13 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-17 14:48:13 --> Language Class Initialized
DEBUG - 2011-09-17 14:48:13 --> Loader Class Initialized
DEBUG - 2011-09-17 14:48:13 --> Controller Class Initialized
DEBUG - 2011-09-17 14:48:13 --> Model Class Initialized
DEBUG - 2011-09-17 14:48:13 --> Model Class Initialized
DEBUG - 2011-09-17 14:48:13 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-17 14:48:13 --> Database Driver Class Initialized
DEBUG - 2011-09-17 14:48:13 --> Final output sent to browser
DEBUG - 2011-09-17 14:48:13 --> Total execution time: 0.4931
DEBUG - 2011-09-17 14:48:15 --> Config Class Initialized
DEBUG - 2011-09-17 14:48:15 --> Hooks Class Initialized
DEBUG - 2011-09-17 14:48:15 --> Utf8 Class Initialized
DEBUG - 2011-09-17 14:48:15 --> UTF-8 Support Enabled
DEBUG - 2011-09-17 14:48:15 --> URI Class Initialized
DEBUG - 2011-09-17 14:48:15 --> Router Class Initialized
ERROR - 2011-09-17 14:48:15 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-09-17 14:48:24 --> Config Class Initialized
DEBUG - 2011-09-17 14:48:24 --> Hooks Class Initialized
DEBUG - 2011-09-17 14:48:24 --> Utf8 Class Initialized
DEBUG - 2011-09-17 14:48:24 --> UTF-8 Support Enabled
DEBUG - 2011-09-17 14:48:24 --> URI Class Initialized
DEBUG - 2011-09-17 14:48:24 --> Router Class Initialized
DEBUG - 2011-09-17 14:48:24 --> Output Class Initialized
DEBUG - 2011-09-17 14:48:24 --> Input Class Initialized
DEBUG - 2011-09-17 14:48:24 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-17 14:48:24 --> Language Class Initialized
DEBUG - 2011-09-17 14:48:24 --> Loader Class Initialized
DEBUG - 2011-09-17 14:48:24 --> Controller Class Initialized
ERROR - 2011-09-17 14:48:24 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-09-17 14:48:24 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-09-17 14:48:24 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-09-17 14:48:24 --> Model Class Initialized
DEBUG - 2011-09-17 14:48:24 --> Model Class Initialized
DEBUG - 2011-09-17 14:48:24 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-17 14:48:24 --> Database Driver Class Initialized
DEBUG - 2011-09-17 14:48:24 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-09-17 14:48:24 --> Helper loaded: url_helper
DEBUG - 2011-09-17 14:48:24 --> File loaded: application/views/common/header.php
DEBUG - 2011-09-17 14:48:24 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-09-17 14:48:24 --> File loaded: application/views/common/footer.php
DEBUG - 2011-09-17 14:48:24 --> File loaded: application/views/layout/main.php
DEBUG - 2011-09-17 14:48:24 --> Final output sent to browser
DEBUG - 2011-09-17 14:48:24 --> Total execution time: 0.0321
DEBUG - 2011-09-17 14:48:25 --> Config Class Initialized
DEBUG - 2011-09-17 14:48:25 --> Hooks Class Initialized
DEBUG - 2011-09-17 14:48:25 --> Utf8 Class Initialized
DEBUG - 2011-09-17 14:48:25 --> UTF-8 Support Enabled
DEBUG - 2011-09-17 14:48:25 --> URI Class Initialized
DEBUG - 2011-09-17 14:48:25 --> Router Class Initialized
DEBUG - 2011-09-17 14:48:25 --> Output Class Initialized
DEBUG - 2011-09-17 14:48:25 --> Input Class Initialized
DEBUG - 2011-09-17 14:48:25 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-17 14:48:25 --> Language Class Initialized
DEBUG - 2011-09-17 14:48:26 --> Loader Class Initialized
DEBUG - 2011-09-17 14:48:26 --> Controller Class Initialized
DEBUG - 2011-09-17 14:48:26 --> Model Class Initialized
DEBUG - 2011-09-17 14:48:26 --> Model Class Initialized
DEBUG - 2011-09-17 14:48:26 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-17 14:48:26 --> Database Driver Class Initialized
DEBUG - 2011-09-17 14:48:26 --> Final output sent to browser
DEBUG - 2011-09-17 14:48:26 --> Total execution time: 0.6340
DEBUG - 2011-09-17 14:48:28 --> Config Class Initialized
DEBUG - 2011-09-17 14:48:28 --> Hooks Class Initialized
DEBUG - 2011-09-17 14:48:28 --> Utf8 Class Initialized
DEBUG - 2011-09-17 14:48:28 --> UTF-8 Support Enabled
DEBUG - 2011-09-17 14:48:28 --> URI Class Initialized
DEBUG - 2011-09-17 14:48:28 --> Router Class Initialized
ERROR - 2011-09-17 14:48:28 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-09-17 14:48:34 --> Config Class Initialized
DEBUG - 2011-09-17 14:48:34 --> Hooks Class Initialized
DEBUG - 2011-09-17 14:48:34 --> Utf8 Class Initialized
DEBUG - 2011-09-17 14:48:34 --> UTF-8 Support Enabled
DEBUG - 2011-09-17 14:48:34 --> URI Class Initialized
DEBUG - 2011-09-17 14:48:34 --> Router Class Initialized
DEBUG - 2011-09-17 14:48:34 --> Output Class Initialized
DEBUG - 2011-09-17 14:48:34 --> Input Class Initialized
DEBUG - 2011-09-17 14:48:34 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-17 14:48:34 --> Language Class Initialized
DEBUG - 2011-09-17 14:48:34 --> Loader Class Initialized
DEBUG - 2011-09-17 14:48:34 --> Controller Class Initialized
ERROR - 2011-09-17 14:48:34 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-09-17 14:48:34 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-09-17 14:48:34 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-09-17 14:48:34 --> Model Class Initialized
DEBUG - 2011-09-17 14:48:34 --> Model Class Initialized
DEBUG - 2011-09-17 14:48:34 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-17 14:48:34 --> Database Driver Class Initialized
DEBUG - 2011-09-17 14:48:34 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-09-17 14:48:34 --> Helper loaded: url_helper
DEBUG - 2011-09-17 14:48:34 --> File loaded: application/views/common/header.php
DEBUG - 2011-09-17 14:48:34 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-09-17 14:48:34 --> File loaded: application/views/common/footer.php
DEBUG - 2011-09-17 14:48:34 --> File loaded: application/views/layout/main.php
DEBUG - 2011-09-17 14:48:34 --> Final output sent to browser
DEBUG - 2011-09-17 14:48:34 --> Total execution time: 0.0302
DEBUG - 2011-09-17 14:48:36 --> Config Class Initialized
DEBUG - 2011-09-17 14:48:36 --> Hooks Class Initialized
DEBUG - 2011-09-17 14:48:36 --> Utf8 Class Initialized
DEBUG - 2011-09-17 14:48:36 --> UTF-8 Support Enabled
DEBUG - 2011-09-17 14:48:36 --> URI Class Initialized
DEBUG - 2011-09-17 14:48:36 --> Router Class Initialized
DEBUG - 2011-09-17 14:48:36 --> Output Class Initialized
DEBUG - 2011-09-17 14:48:36 --> Input Class Initialized
DEBUG - 2011-09-17 14:48:36 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-17 14:48:36 --> Language Class Initialized
DEBUG - 2011-09-17 14:48:36 --> Loader Class Initialized
DEBUG - 2011-09-17 14:48:36 --> Controller Class Initialized
DEBUG - 2011-09-17 14:48:36 --> Model Class Initialized
DEBUG - 2011-09-17 14:48:36 --> Model Class Initialized
DEBUG - 2011-09-17 14:48:36 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-17 14:48:36 --> Database Driver Class Initialized
DEBUG - 2011-09-17 14:48:36 --> Final output sent to browser
DEBUG - 2011-09-17 14:48:36 --> Total execution time: 0.5420
DEBUG - 2011-09-17 14:48:38 --> Config Class Initialized
DEBUG - 2011-09-17 14:48:38 --> Hooks Class Initialized
DEBUG - 2011-09-17 14:48:38 --> Utf8 Class Initialized
DEBUG - 2011-09-17 14:48:38 --> UTF-8 Support Enabled
DEBUG - 2011-09-17 14:48:38 --> URI Class Initialized
DEBUG - 2011-09-17 14:48:38 --> Router Class Initialized
ERROR - 2011-09-17 14:48:38 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-09-17 14:48:52 --> Config Class Initialized
DEBUG - 2011-09-17 14:48:52 --> Hooks Class Initialized
DEBUG - 2011-09-17 14:48:52 --> Utf8 Class Initialized
DEBUG - 2011-09-17 14:48:52 --> UTF-8 Support Enabled
DEBUG - 2011-09-17 14:48:52 --> URI Class Initialized
DEBUG - 2011-09-17 14:48:52 --> Router Class Initialized
DEBUG - 2011-09-17 14:48:52 --> Output Class Initialized
DEBUG - 2011-09-17 14:48:52 --> Input Class Initialized
DEBUG - 2011-09-17 14:48:52 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-17 14:48:52 --> Language Class Initialized
DEBUG - 2011-09-17 14:48:52 --> Loader Class Initialized
DEBUG - 2011-09-17 14:48:52 --> Controller Class Initialized
ERROR - 2011-09-17 14:48:52 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-09-17 14:48:52 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-09-17 14:48:52 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-09-17 14:48:52 --> Model Class Initialized
DEBUG - 2011-09-17 14:48:52 --> Model Class Initialized
DEBUG - 2011-09-17 14:48:52 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-17 14:48:52 --> Database Driver Class Initialized
DEBUG - 2011-09-17 14:48:52 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-09-17 14:48:52 --> Helper loaded: url_helper
DEBUG - 2011-09-17 14:48:52 --> File loaded: application/views/common/header.php
DEBUG - 2011-09-17 14:48:52 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-09-17 14:48:52 --> File loaded: application/views/common/footer.php
DEBUG - 2011-09-17 14:48:52 --> File loaded: application/views/layout/main.php
DEBUG - 2011-09-17 14:48:52 --> Final output sent to browser
DEBUG - 2011-09-17 14:48:52 --> Total execution time: 0.0370
DEBUG - 2011-09-17 14:48:53 --> Config Class Initialized
DEBUG - 2011-09-17 14:48:53 --> Hooks Class Initialized
DEBUG - 2011-09-17 14:48:53 --> Utf8 Class Initialized
DEBUG - 2011-09-17 14:48:53 --> UTF-8 Support Enabled
DEBUG - 2011-09-17 14:48:53 --> URI Class Initialized
DEBUG - 2011-09-17 14:48:53 --> Router Class Initialized
DEBUG - 2011-09-17 14:48:53 --> Output Class Initialized
DEBUG - 2011-09-17 14:48:53 --> Input Class Initialized
DEBUG - 2011-09-17 14:48:53 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-17 14:48:53 --> Language Class Initialized
DEBUG - 2011-09-17 14:48:53 --> Loader Class Initialized
DEBUG - 2011-09-17 14:48:53 --> Controller Class Initialized
DEBUG - 2011-09-17 14:48:53 --> Model Class Initialized
DEBUG - 2011-09-17 14:48:53 --> Model Class Initialized
DEBUG - 2011-09-17 14:48:53 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-17 14:48:53 --> Database Driver Class Initialized
DEBUG - 2011-09-17 14:48:53 --> Final output sent to browser
DEBUG - 2011-09-17 14:48:53 --> Total execution time: 0.4189
DEBUG - 2011-09-17 14:48:55 --> Config Class Initialized
DEBUG - 2011-09-17 14:48:55 --> Hooks Class Initialized
DEBUG - 2011-09-17 14:48:55 --> Utf8 Class Initialized
DEBUG - 2011-09-17 14:48:55 --> UTF-8 Support Enabled
DEBUG - 2011-09-17 14:48:55 --> URI Class Initialized
DEBUG - 2011-09-17 14:48:55 --> Router Class Initialized
DEBUG - 2011-09-17 14:48:55 --> Output Class Initialized
DEBUG - 2011-09-17 14:48:55 --> Input Class Initialized
DEBUG - 2011-09-17 14:48:55 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-17 14:48:55 --> Language Class Initialized
DEBUG - 2011-09-17 14:48:55 --> Loader Class Initialized
DEBUG - 2011-09-17 14:48:55 --> Controller Class Initialized
ERROR - 2011-09-17 14:48:55 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-09-17 14:48:55 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-09-17 14:48:55 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-09-17 14:48:55 --> Model Class Initialized
DEBUG - 2011-09-17 14:48:55 --> Model Class Initialized
DEBUG - 2011-09-17 14:48:55 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-17 14:48:55 --> Database Driver Class Initialized
DEBUG - 2011-09-17 14:48:55 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-09-17 14:48:55 --> Helper loaded: url_helper
DEBUG - 2011-09-17 14:48:55 --> File loaded: application/views/common/header.php
DEBUG - 2011-09-17 14:48:55 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-09-17 14:48:55 --> File loaded: application/views/common/footer.php
DEBUG - 2011-09-17 14:48:55 --> File loaded: application/views/layout/main.php
DEBUG - 2011-09-17 14:48:55 --> Final output sent to browser
DEBUG - 2011-09-17 14:48:55 --> Total execution time: 0.0294
DEBUG - 2011-09-17 14:48:55 --> Config Class Initialized
DEBUG - 2011-09-17 14:48:55 --> Hooks Class Initialized
DEBUG - 2011-09-17 14:48:55 --> Utf8 Class Initialized
DEBUG - 2011-09-17 14:48:55 --> UTF-8 Support Enabled
DEBUG - 2011-09-17 14:48:55 --> URI Class Initialized
DEBUG - 2011-09-17 14:48:55 --> Router Class Initialized
ERROR - 2011-09-17 14:48:55 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-09-17 14:49:17 --> Config Class Initialized
DEBUG - 2011-09-17 14:49:17 --> Hooks Class Initialized
DEBUG - 2011-09-17 14:49:17 --> Utf8 Class Initialized
DEBUG - 2011-09-17 14:49:17 --> UTF-8 Support Enabled
DEBUG - 2011-09-17 14:49:17 --> URI Class Initialized
DEBUG - 2011-09-17 14:49:17 --> Router Class Initialized
DEBUG - 2011-09-17 14:49:17 --> Output Class Initialized
DEBUG - 2011-09-17 14:49:17 --> Input Class Initialized
DEBUG - 2011-09-17 14:49:17 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-17 14:49:17 --> Language Class Initialized
DEBUG - 2011-09-17 14:49:17 --> Loader Class Initialized
DEBUG - 2011-09-17 14:49:17 --> Controller Class Initialized
ERROR - 2011-09-17 14:49:17 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-09-17 14:49:17 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-09-17 14:49:17 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-09-17 14:49:17 --> Model Class Initialized
DEBUG - 2011-09-17 14:49:17 --> Model Class Initialized
DEBUG - 2011-09-17 14:49:17 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-17 14:49:17 --> Database Driver Class Initialized
DEBUG - 2011-09-17 14:49:17 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-09-17 14:49:17 --> Helper loaded: url_helper
DEBUG - 2011-09-17 14:49:17 --> File loaded: application/views/common/header.php
DEBUG - 2011-09-17 14:49:17 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-09-17 14:49:17 --> File loaded: application/views/common/footer.php
DEBUG - 2011-09-17 14:49:17 --> File loaded: application/views/layout/main.php
DEBUG - 2011-09-17 14:49:17 --> Final output sent to browser
DEBUG - 2011-09-17 14:49:17 --> Total execution time: 0.0556
DEBUG - 2011-09-17 14:49:19 --> Config Class Initialized
DEBUG - 2011-09-17 14:49:19 --> Hooks Class Initialized
DEBUG - 2011-09-17 14:49:19 --> Utf8 Class Initialized
DEBUG - 2011-09-17 14:49:19 --> UTF-8 Support Enabled
DEBUG - 2011-09-17 14:49:19 --> URI Class Initialized
DEBUG - 2011-09-17 14:49:19 --> Router Class Initialized
DEBUG - 2011-09-17 14:49:19 --> Output Class Initialized
DEBUG - 2011-09-17 14:49:19 --> Input Class Initialized
DEBUG - 2011-09-17 14:49:19 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-17 14:49:19 --> Language Class Initialized
DEBUG - 2011-09-17 14:49:19 --> Loader Class Initialized
DEBUG - 2011-09-17 14:49:19 --> Controller Class Initialized
DEBUG - 2011-09-17 14:49:19 --> Model Class Initialized
DEBUG - 2011-09-17 14:49:19 --> Model Class Initialized
DEBUG - 2011-09-17 14:49:19 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-17 14:49:19 --> Database Driver Class Initialized
DEBUG - 2011-09-17 14:49:20 --> Final output sent to browser
DEBUG - 2011-09-17 14:49:20 --> Total execution time: 0.5417
DEBUG - 2011-09-17 14:49:21 --> Config Class Initialized
DEBUG - 2011-09-17 14:49:21 --> Hooks Class Initialized
DEBUG - 2011-09-17 14:49:21 --> Utf8 Class Initialized
DEBUG - 2011-09-17 14:49:21 --> UTF-8 Support Enabled
DEBUG - 2011-09-17 14:49:21 --> URI Class Initialized
DEBUG - 2011-09-17 14:49:21 --> Router Class Initialized
ERROR - 2011-09-17 14:49:21 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-09-17 14:49:23 --> Config Class Initialized
DEBUG - 2011-09-17 14:49:23 --> Hooks Class Initialized
DEBUG - 2011-09-17 14:49:23 --> Utf8 Class Initialized
DEBUG - 2011-09-17 14:49:23 --> UTF-8 Support Enabled
DEBUG - 2011-09-17 14:49:23 --> URI Class Initialized
DEBUG - 2011-09-17 14:49:23 --> Router Class Initialized
DEBUG - 2011-09-17 14:49:23 --> Output Class Initialized
DEBUG - 2011-09-17 14:49:23 --> Input Class Initialized
DEBUG - 2011-09-17 14:49:23 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-17 14:49:23 --> Language Class Initialized
DEBUG - 2011-09-17 14:49:23 --> Loader Class Initialized
DEBUG - 2011-09-17 14:49:23 --> Controller Class Initialized
ERROR - 2011-09-17 14:49:23 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-09-17 14:49:23 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-09-17 14:49:23 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-09-17 14:49:23 --> Model Class Initialized
DEBUG - 2011-09-17 14:49:23 --> Model Class Initialized
DEBUG - 2011-09-17 14:49:23 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-17 14:49:23 --> Database Driver Class Initialized
DEBUG - 2011-09-17 14:49:23 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-09-17 14:49:23 --> Helper loaded: url_helper
DEBUG - 2011-09-17 14:49:23 --> File loaded: application/views/common/header.php
DEBUG - 2011-09-17 14:49:23 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-09-17 14:49:23 --> File loaded: application/views/common/footer.php
DEBUG - 2011-09-17 14:49:23 --> File loaded: application/views/layout/main.php
DEBUG - 2011-09-17 14:49:23 --> Final output sent to browser
DEBUG - 2011-09-17 14:49:23 --> Total execution time: 0.0284
DEBUG - 2011-09-17 14:49:42 --> Config Class Initialized
DEBUG - 2011-09-17 14:49:42 --> Hooks Class Initialized
DEBUG - 2011-09-17 14:49:42 --> Utf8 Class Initialized
DEBUG - 2011-09-17 14:49:42 --> UTF-8 Support Enabled
DEBUG - 2011-09-17 14:49:42 --> URI Class Initialized
DEBUG - 2011-09-17 14:49:42 --> Router Class Initialized
DEBUG - 2011-09-17 14:49:42 --> Output Class Initialized
DEBUG - 2011-09-17 14:49:42 --> Input Class Initialized
DEBUG - 2011-09-17 14:49:42 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-17 14:49:42 --> Language Class Initialized
DEBUG - 2011-09-17 14:49:42 --> Loader Class Initialized
DEBUG - 2011-09-17 14:49:42 --> Controller Class Initialized
ERROR - 2011-09-17 14:49:42 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-09-17 14:49:42 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-09-17 14:49:42 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-09-17 14:49:42 --> Model Class Initialized
DEBUG - 2011-09-17 14:49:42 --> Model Class Initialized
DEBUG - 2011-09-17 14:49:42 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-17 14:49:42 --> Database Driver Class Initialized
DEBUG - 2011-09-17 14:49:42 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-09-17 14:49:42 --> Helper loaded: url_helper
DEBUG - 2011-09-17 14:49:42 --> File loaded: application/views/common/header.php
DEBUG - 2011-09-17 14:49:42 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-09-17 14:49:42 --> File loaded: application/views/common/footer.php
DEBUG - 2011-09-17 14:49:42 --> File loaded: application/views/layout/main.php
DEBUG - 2011-09-17 14:49:42 --> Final output sent to browser
DEBUG - 2011-09-17 14:49:42 --> Total execution time: 0.0301
DEBUG - 2011-09-17 14:49:43 --> Config Class Initialized
DEBUG - 2011-09-17 14:49:43 --> Hooks Class Initialized
DEBUG - 2011-09-17 14:49:43 --> Utf8 Class Initialized
DEBUG - 2011-09-17 14:49:43 --> UTF-8 Support Enabled
DEBUG - 2011-09-17 14:49:43 --> URI Class Initialized
DEBUG - 2011-09-17 14:49:43 --> Router Class Initialized
DEBUG - 2011-09-17 14:49:43 --> Output Class Initialized
DEBUG - 2011-09-17 14:49:43 --> Input Class Initialized
DEBUG - 2011-09-17 14:49:43 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-17 14:49:43 --> Language Class Initialized
DEBUG - 2011-09-17 14:49:43 --> Loader Class Initialized
DEBUG - 2011-09-17 14:49:43 --> Controller Class Initialized
DEBUG - 2011-09-17 14:49:43 --> Model Class Initialized
DEBUG - 2011-09-17 14:49:43 --> Model Class Initialized
DEBUG - 2011-09-17 14:49:43 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-17 14:49:43 --> Database Driver Class Initialized
DEBUG - 2011-09-17 14:49:44 --> Final output sent to browser
DEBUG - 2011-09-17 14:49:44 --> Total execution time: 0.5401
DEBUG - 2011-09-17 14:49:45 --> Config Class Initialized
DEBUG - 2011-09-17 14:49:45 --> Hooks Class Initialized
DEBUG - 2011-09-17 14:49:45 --> Utf8 Class Initialized
DEBUG - 2011-09-17 14:49:45 --> UTF-8 Support Enabled
DEBUG - 2011-09-17 14:49:45 --> URI Class Initialized
DEBUG - 2011-09-17 14:49:45 --> Router Class Initialized
ERROR - 2011-09-17 14:49:45 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-09-17 14:50:19 --> Config Class Initialized
DEBUG - 2011-09-17 14:50:19 --> Hooks Class Initialized
DEBUG - 2011-09-17 14:50:19 --> Utf8 Class Initialized
DEBUG - 2011-09-17 14:50:19 --> UTF-8 Support Enabled
DEBUG - 2011-09-17 14:50:19 --> URI Class Initialized
DEBUG - 2011-09-17 14:50:19 --> Router Class Initialized
DEBUG - 2011-09-17 14:50:19 --> Output Class Initialized
DEBUG - 2011-09-17 14:50:19 --> Input Class Initialized
DEBUG - 2011-09-17 14:50:19 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-17 14:50:19 --> Language Class Initialized
DEBUG - 2011-09-17 14:50:19 --> Loader Class Initialized
DEBUG - 2011-09-17 14:50:19 --> Controller Class Initialized
DEBUG - 2011-09-17 14:50:19 --> Model Class Initialized
DEBUG - 2011-09-17 14:50:19 --> Model Class Initialized
DEBUG - 2011-09-17 14:50:19 --> Model Class Initialized
DEBUG - 2011-09-17 14:50:19 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-17 14:50:19 --> Database Driver Class Initialized
DEBUG - 2011-09-17 14:50:19 --> File loaded: application/views/table/main.php
DEBUG - 2011-09-17 14:50:19 --> Helper loaded: url_helper
DEBUG - 2011-09-17 14:50:19 --> File loaded: application/views/common/header.php
DEBUG - 2011-09-17 14:50:19 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-09-17 14:50:19 --> File loaded: application/views/common/footer.php
DEBUG - 2011-09-17 14:50:19 --> File loaded: application/views/layout/main.php
DEBUG - 2011-09-17 14:50:19 --> Final output sent to browser
DEBUG - 2011-09-17 14:50:19 --> Total execution time: 0.2627
DEBUG - 2011-09-17 14:50:21 --> Config Class Initialized
DEBUG - 2011-09-17 14:50:21 --> Hooks Class Initialized
DEBUG - 2011-09-17 14:50:21 --> Utf8 Class Initialized
DEBUG - 2011-09-17 14:50:21 --> UTF-8 Support Enabled
DEBUG - 2011-09-17 14:50:21 --> URI Class Initialized
DEBUG - 2011-09-17 14:50:21 --> Router Class Initialized
DEBUG - 2011-09-17 14:50:21 --> Output Class Initialized
DEBUG - 2011-09-17 14:50:21 --> Input Class Initialized
DEBUG - 2011-09-17 14:50:21 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-17 14:50:21 --> Language Class Initialized
DEBUG - 2011-09-17 14:50:21 --> Loader Class Initialized
DEBUG - 2011-09-17 14:50:21 --> Controller Class Initialized
DEBUG - 2011-09-17 14:50:21 --> Model Class Initialized
DEBUG - 2011-09-17 14:50:21 --> Model Class Initialized
DEBUG - 2011-09-17 14:50:21 --> Model Class Initialized
DEBUG - 2011-09-17 14:50:21 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-17 14:50:21 --> Database Driver Class Initialized
DEBUG - 2011-09-17 14:50:21 --> File loaded: application/views/table/main.php
DEBUG - 2011-09-17 14:50:21 --> Helper loaded: url_helper
DEBUG - 2011-09-17 14:50:21 --> File loaded: application/views/common/header.php
DEBUG - 2011-09-17 14:50:21 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-09-17 14:50:21 --> File loaded: application/views/common/footer.php
DEBUG - 2011-09-17 14:50:21 --> File loaded: application/views/layout/main.php
DEBUG - 2011-09-17 14:50:21 --> Final output sent to browser
DEBUG - 2011-09-17 14:50:21 --> Total execution time: 0.0452
DEBUG - 2011-09-17 14:50:22 --> Config Class Initialized
DEBUG - 2011-09-17 14:50:22 --> Hooks Class Initialized
DEBUG - 2011-09-17 14:50:22 --> Utf8 Class Initialized
DEBUG - 2011-09-17 14:50:22 --> UTF-8 Support Enabled
DEBUG - 2011-09-17 14:50:22 --> URI Class Initialized
DEBUG - 2011-09-17 14:50:22 --> Router Class Initialized
ERROR - 2011-09-17 14:50:22 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-09-17 16:53:17 --> Config Class Initialized
DEBUG - 2011-09-17 16:53:17 --> Hooks Class Initialized
DEBUG - 2011-09-17 16:53:17 --> Utf8 Class Initialized
DEBUG - 2011-09-17 16:53:17 --> UTF-8 Support Enabled
DEBUG - 2011-09-17 16:53:17 --> URI Class Initialized
DEBUG - 2011-09-17 16:53:17 --> Router Class Initialized
DEBUG - 2011-09-17 16:53:17 --> Output Class Initialized
DEBUG - 2011-09-17 16:53:17 --> Input Class Initialized
DEBUG - 2011-09-17 16:53:17 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-17 16:53:17 --> Language Class Initialized
DEBUG - 2011-09-17 16:53:17 --> Loader Class Initialized
DEBUG - 2011-09-17 16:53:17 --> Controller Class Initialized
DEBUG - 2011-09-17 16:53:17 --> Model Class Initialized
DEBUG - 2011-09-17 16:53:17 --> Model Class Initialized
DEBUG - 2011-09-17 16:53:17 --> Model Class Initialized
DEBUG - 2011-09-17 16:53:17 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-17 16:53:17 --> Database Driver Class Initialized
DEBUG - 2011-09-17 16:53:22 --> File loaded: application/views/table/main.php
DEBUG - 2011-09-17 16:53:22 --> Helper loaded: url_helper
DEBUG - 2011-09-17 16:53:22 --> File loaded: application/views/common/header.php
DEBUG - 2011-09-17 16:53:22 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-09-17 16:53:22 --> File loaded: application/views/common/footer.php
DEBUG - 2011-09-17 16:53:22 --> File loaded: application/views/layout/main.php
DEBUG - 2011-09-17 16:53:22 --> Final output sent to browser
DEBUG - 2011-09-17 16:53:22 --> Total execution time: 5.4741
DEBUG - 2011-09-17 16:53:24 --> Config Class Initialized
DEBUG - 2011-09-17 16:53:24 --> Hooks Class Initialized
DEBUG - 2011-09-17 16:53:24 --> Utf8 Class Initialized
DEBUG - 2011-09-17 16:53:24 --> UTF-8 Support Enabled
DEBUG - 2011-09-17 16:53:24 --> URI Class Initialized
DEBUG - 2011-09-17 16:53:24 --> Router Class Initialized
ERROR - 2011-09-17 16:53:24 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-09-17 16:54:08 --> Config Class Initialized
DEBUG - 2011-09-17 16:54:08 --> Hooks Class Initialized
DEBUG - 2011-09-17 16:54:08 --> Utf8 Class Initialized
DEBUG - 2011-09-17 16:54:08 --> UTF-8 Support Enabled
DEBUG - 2011-09-17 16:54:08 --> URI Class Initialized
DEBUG - 2011-09-17 16:54:08 --> Router Class Initialized
DEBUG - 2011-09-17 16:54:08 --> Output Class Initialized
DEBUG - 2011-09-17 16:54:08 --> Input Class Initialized
DEBUG - 2011-09-17 16:54:08 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-17 16:54:08 --> Language Class Initialized
DEBUG - 2011-09-17 16:54:08 --> Loader Class Initialized
DEBUG - 2011-09-17 16:54:08 --> Controller Class Initialized
ERROR - 2011-09-17 16:54:08 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-09-17 16:54:08 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-09-17 16:54:08 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-09-17 16:54:08 --> Model Class Initialized
DEBUG - 2011-09-17 16:54:08 --> Model Class Initialized
DEBUG - 2011-09-17 16:54:08 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-17 16:54:08 --> Database Driver Class Initialized
DEBUG - 2011-09-17 16:54:08 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-09-17 16:54:08 --> Helper loaded: url_helper
DEBUG - 2011-09-17 16:54:08 --> File loaded: application/views/common/header.php
DEBUG - 2011-09-17 16:54:08 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-09-17 16:54:08 --> File loaded: application/views/common/footer.php
DEBUG - 2011-09-17 16:54:08 --> File loaded: application/views/layout/main.php
DEBUG - 2011-09-17 16:54:08 --> Final output sent to browser
DEBUG - 2011-09-17 16:54:08 --> Total execution time: 0.0706
DEBUG - 2011-09-17 16:54:08 --> Config Class Initialized
DEBUG - 2011-09-17 16:54:08 --> Hooks Class Initialized
DEBUG - 2011-09-17 16:54:08 --> Utf8 Class Initialized
DEBUG - 2011-09-17 16:54:08 --> UTF-8 Support Enabled
DEBUG - 2011-09-17 16:54:08 --> URI Class Initialized
DEBUG - 2011-09-17 16:54:08 --> Router Class Initialized
DEBUG - 2011-09-17 16:54:08 --> Output Class Initialized
DEBUG - 2011-09-17 16:54:08 --> Input Class Initialized
DEBUG - 2011-09-17 16:54:08 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-17 16:54:08 --> Language Class Initialized
DEBUG - 2011-09-17 16:54:08 --> Loader Class Initialized
DEBUG - 2011-09-17 16:54:08 --> Controller Class Initialized
DEBUG - 2011-09-17 16:54:08 --> Model Class Initialized
DEBUG - 2011-09-17 16:54:08 --> Model Class Initialized
DEBUG - 2011-09-17 16:54:08 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-17 16:54:08 --> Database Driver Class Initialized
DEBUG - 2011-09-17 16:54:09 --> Final output sent to browser
DEBUG - 2011-09-17 16:54:09 --> Total execution time: 0.6947
DEBUG - 2011-09-17 16:54:10 --> Config Class Initialized
DEBUG - 2011-09-17 16:54:10 --> Hooks Class Initialized
DEBUG - 2011-09-17 16:54:10 --> Utf8 Class Initialized
DEBUG - 2011-09-17 16:54:10 --> UTF-8 Support Enabled
DEBUG - 2011-09-17 16:54:10 --> URI Class Initialized
DEBUG - 2011-09-17 16:54:10 --> Router Class Initialized
ERROR - 2011-09-17 16:54:10 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-09-17 16:54:24 --> Config Class Initialized
DEBUG - 2011-09-17 16:54:24 --> Hooks Class Initialized
DEBUG - 2011-09-17 16:54:24 --> Utf8 Class Initialized
DEBUG - 2011-09-17 16:54:24 --> UTF-8 Support Enabled
DEBUG - 2011-09-17 16:54:24 --> URI Class Initialized
DEBUG - 2011-09-17 16:54:24 --> Router Class Initialized
DEBUG - 2011-09-17 16:54:24 --> Output Class Initialized
DEBUG - 2011-09-17 16:54:24 --> Input Class Initialized
DEBUG - 2011-09-17 16:54:24 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-17 16:54:24 --> Language Class Initialized
DEBUG - 2011-09-17 16:54:24 --> Loader Class Initialized
DEBUG - 2011-09-17 16:54:24 --> Controller Class Initialized
ERROR - 2011-09-17 16:54:24 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-09-17 16:54:24 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-09-17 16:54:24 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-09-17 16:54:24 --> Model Class Initialized
DEBUG - 2011-09-17 16:54:24 --> Model Class Initialized
DEBUG - 2011-09-17 16:54:24 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-17 16:54:24 --> Database Driver Class Initialized
DEBUG - 2011-09-17 16:54:24 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-09-17 16:54:24 --> Helper loaded: url_helper
DEBUG - 2011-09-17 16:54:24 --> File loaded: application/views/common/header.php
DEBUG - 2011-09-17 16:54:24 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-09-17 16:54:24 --> File loaded: application/views/common/footer.php
DEBUG - 2011-09-17 16:54:24 --> File loaded: application/views/layout/main.php
DEBUG - 2011-09-17 16:54:24 --> Final output sent to browser
DEBUG - 2011-09-17 16:54:24 --> Total execution time: 0.0286
DEBUG - 2011-09-17 16:54:24 --> Config Class Initialized
DEBUG - 2011-09-17 16:54:24 --> Hooks Class Initialized
DEBUG - 2011-09-17 16:54:24 --> Utf8 Class Initialized
DEBUG - 2011-09-17 16:54:24 --> UTF-8 Support Enabled
DEBUG - 2011-09-17 16:54:24 --> URI Class Initialized
DEBUG - 2011-09-17 16:54:24 --> Router Class Initialized
DEBUG - 2011-09-17 16:54:24 --> Output Class Initialized
DEBUG - 2011-09-17 16:54:24 --> Input Class Initialized
DEBUG - 2011-09-17 16:54:24 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-17 16:54:24 --> Language Class Initialized
DEBUG - 2011-09-17 16:54:24 --> Loader Class Initialized
DEBUG - 2011-09-17 16:54:24 --> Controller Class Initialized
DEBUG - 2011-09-17 16:54:24 --> Model Class Initialized
DEBUG - 2011-09-17 16:54:24 --> Model Class Initialized
DEBUG - 2011-09-17 16:54:24 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-17 16:54:24 --> Database Driver Class Initialized
DEBUG - 2011-09-17 16:54:25 --> Final output sent to browser
DEBUG - 2011-09-17 16:54:25 --> Total execution time: 0.7071
DEBUG - 2011-09-17 16:54:26 --> Config Class Initialized
DEBUG - 2011-09-17 16:54:26 --> Hooks Class Initialized
DEBUG - 2011-09-17 16:54:26 --> Utf8 Class Initialized
DEBUG - 2011-09-17 16:54:26 --> UTF-8 Support Enabled
DEBUG - 2011-09-17 16:54:26 --> URI Class Initialized
DEBUG - 2011-09-17 16:54:26 --> Router Class Initialized
ERROR - 2011-09-17 16:54:26 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-09-17 16:54:39 --> Config Class Initialized
DEBUG - 2011-09-17 16:54:39 --> Hooks Class Initialized
DEBUG - 2011-09-17 16:54:39 --> Utf8 Class Initialized
DEBUG - 2011-09-17 16:54:39 --> UTF-8 Support Enabled
DEBUG - 2011-09-17 16:54:39 --> URI Class Initialized
DEBUG - 2011-09-17 16:54:39 --> Router Class Initialized
DEBUG - 2011-09-17 16:54:39 --> Output Class Initialized
DEBUG - 2011-09-17 16:54:39 --> Input Class Initialized
DEBUG - 2011-09-17 16:54:39 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-17 16:54:39 --> Language Class Initialized
DEBUG - 2011-09-17 16:54:39 --> Loader Class Initialized
DEBUG - 2011-09-17 16:54:39 --> Controller Class Initialized
ERROR - 2011-09-17 16:54:39 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-09-17 16:54:39 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-09-17 16:54:39 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-09-17 16:54:39 --> Model Class Initialized
DEBUG - 2011-09-17 16:54:39 --> Model Class Initialized
DEBUG - 2011-09-17 16:54:39 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-17 16:54:39 --> Database Driver Class Initialized
DEBUG - 2011-09-17 16:54:39 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-09-17 16:54:39 --> Helper loaded: url_helper
DEBUG - 2011-09-17 16:54:39 --> File loaded: application/views/common/header.php
DEBUG - 2011-09-17 16:54:39 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-09-17 16:54:39 --> File loaded: application/views/common/footer.php
DEBUG - 2011-09-17 16:54:39 --> File loaded: application/views/layout/main.php
DEBUG - 2011-09-17 16:54:39 --> Final output sent to browser
DEBUG - 2011-09-17 16:54:39 --> Total execution time: 0.0304
DEBUG - 2011-09-17 16:54:40 --> Config Class Initialized
DEBUG - 2011-09-17 16:54:40 --> Hooks Class Initialized
DEBUG - 2011-09-17 16:54:40 --> Utf8 Class Initialized
DEBUG - 2011-09-17 16:54:40 --> UTF-8 Support Enabled
DEBUG - 2011-09-17 16:54:40 --> URI Class Initialized
DEBUG - 2011-09-17 16:54:40 --> Router Class Initialized
DEBUG - 2011-09-17 16:54:40 --> Output Class Initialized
DEBUG - 2011-09-17 16:54:40 --> Input Class Initialized
DEBUG - 2011-09-17 16:54:40 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-17 16:54:40 --> Language Class Initialized
DEBUG - 2011-09-17 16:54:40 --> Loader Class Initialized
DEBUG - 2011-09-17 16:54:40 --> Controller Class Initialized
DEBUG - 2011-09-17 16:54:40 --> Model Class Initialized
DEBUG - 2011-09-17 16:54:40 --> Model Class Initialized
DEBUG - 2011-09-17 16:54:40 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-17 16:54:40 --> Database Driver Class Initialized
DEBUG - 2011-09-17 16:54:40 --> Final output sent to browser
DEBUG - 2011-09-17 16:54:40 --> Total execution time: 0.5419
DEBUG - 2011-09-17 16:54:41 --> Config Class Initialized
DEBUG - 2011-09-17 16:54:41 --> Hooks Class Initialized
DEBUG - 2011-09-17 16:54:41 --> Utf8 Class Initialized
DEBUG - 2011-09-17 16:54:41 --> UTF-8 Support Enabled
DEBUG - 2011-09-17 16:54:41 --> URI Class Initialized
DEBUG - 2011-09-17 16:54:41 --> Router Class Initialized
ERROR - 2011-09-17 16:54:41 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-09-17 16:55:43 --> Config Class Initialized
DEBUG - 2011-09-17 16:55:43 --> Hooks Class Initialized
DEBUG - 2011-09-17 16:55:43 --> Utf8 Class Initialized
DEBUG - 2011-09-17 16:55:43 --> UTF-8 Support Enabled
DEBUG - 2011-09-17 16:55:43 --> URI Class Initialized
DEBUG - 2011-09-17 16:55:43 --> Router Class Initialized
DEBUG - 2011-09-17 16:55:43 --> Output Class Initialized
DEBUG - 2011-09-17 16:55:43 --> Input Class Initialized
DEBUG - 2011-09-17 16:55:43 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-17 16:55:43 --> Language Class Initialized
DEBUG - 2011-09-17 16:55:43 --> Loader Class Initialized
DEBUG - 2011-09-17 16:55:43 --> Controller Class Initialized
ERROR - 2011-09-17 16:55:43 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-09-17 16:55:43 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-09-17 16:55:43 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-09-17 16:55:43 --> Model Class Initialized
DEBUG - 2011-09-17 16:55:43 --> Model Class Initialized
DEBUG - 2011-09-17 16:55:43 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-17 16:55:43 --> Database Driver Class Initialized
DEBUG - 2011-09-17 16:55:43 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-09-17 16:55:43 --> Helper loaded: url_helper
DEBUG - 2011-09-17 16:55:43 --> File loaded: application/views/common/header.php
DEBUG - 2011-09-17 16:55:43 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-09-17 16:55:43 --> File loaded: application/views/common/footer.php
DEBUG - 2011-09-17 16:55:43 --> File loaded: application/views/layout/main.php
DEBUG - 2011-09-17 16:55:43 --> Final output sent to browser
DEBUG - 2011-09-17 16:55:43 --> Total execution time: 0.0282
DEBUG - 2011-09-17 16:55:44 --> Config Class Initialized
DEBUG - 2011-09-17 16:55:44 --> Hooks Class Initialized
DEBUG - 2011-09-17 16:55:44 --> Utf8 Class Initialized
DEBUG - 2011-09-17 16:55:44 --> UTF-8 Support Enabled
DEBUG - 2011-09-17 16:55:44 --> URI Class Initialized
DEBUG - 2011-09-17 16:55:44 --> Router Class Initialized
DEBUG - 2011-09-17 16:55:44 --> Output Class Initialized
DEBUG - 2011-09-17 16:55:44 --> Input Class Initialized
DEBUG - 2011-09-17 16:55:44 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-17 16:55:44 --> Language Class Initialized
DEBUG - 2011-09-17 16:55:44 --> Loader Class Initialized
DEBUG - 2011-09-17 16:55:44 --> Controller Class Initialized
DEBUG - 2011-09-17 16:55:44 --> Model Class Initialized
DEBUG - 2011-09-17 16:55:44 --> Model Class Initialized
DEBUG - 2011-09-17 16:55:44 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-17 16:55:44 --> Database Driver Class Initialized
DEBUG - 2011-09-17 16:55:45 --> Final output sent to browser
DEBUG - 2011-09-17 16:55:45 --> Total execution time: 0.5421
DEBUG - 2011-09-17 16:55:46 --> Config Class Initialized
DEBUG - 2011-09-17 16:55:46 --> Hooks Class Initialized
DEBUG - 2011-09-17 16:55:46 --> Utf8 Class Initialized
DEBUG - 2011-09-17 16:55:46 --> UTF-8 Support Enabled
DEBUG - 2011-09-17 16:55:46 --> URI Class Initialized
DEBUG - 2011-09-17 16:55:46 --> Router Class Initialized
ERROR - 2011-09-17 16:55:46 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-09-17 16:55:53 --> Config Class Initialized
DEBUG - 2011-09-17 16:55:53 --> Hooks Class Initialized
DEBUG - 2011-09-17 16:55:53 --> Utf8 Class Initialized
DEBUG - 2011-09-17 16:55:53 --> UTF-8 Support Enabled
DEBUG - 2011-09-17 16:55:53 --> URI Class Initialized
DEBUG - 2011-09-17 16:55:53 --> Router Class Initialized
DEBUG - 2011-09-17 16:55:53 --> Output Class Initialized
DEBUG - 2011-09-17 16:55:53 --> Input Class Initialized
DEBUG - 2011-09-17 16:55:53 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-17 16:55:53 --> Language Class Initialized
DEBUG - 2011-09-17 16:55:53 --> Loader Class Initialized
DEBUG - 2011-09-17 16:55:53 --> Controller Class Initialized
ERROR - 2011-09-17 16:55:53 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-09-17 16:55:53 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-09-17 16:55:53 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-09-17 16:55:53 --> Model Class Initialized
DEBUG - 2011-09-17 16:55:53 --> Model Class Initialized
DEBUG - 2011-09-17 16:55:53 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-17 16:55:53 --> Database Driver Class Initialized
DEBUG - 2011-09-17 16:55:53 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-09-17 16:55:53 --> Helper loaded: url_helper
DEBUG - 2011-09-17 16:55:53 --> File loaded: application/views/common/header.php
DEBUG - 2011-09-17 16:55:53 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-09-17 16:55:53 --> File loaded: application/views/common/footer.php
DEBUG - 2011-09-17 16:55:53 --> File loaded: application/views/layout/main.php
DEBUG - 2011-09-17 16:55:53 --> Final output sent to browser
DEBUG - 2011-09-17 16:55:53 --> Total execution time: 0.0298
DEBUG - 2011-09-17 16:55:54 --> Config Class Initialized
DEBUG - 2011-09-17 16:55:54 --> Hooks Class Initialized
DEBUG - 2011-09-17 16:55:54 --> Utf8 Class Initialized
DEBUG - 2011-09-17 16:55:54 --> UTF-8 Support Enabled
DEBUG - 2011-09-17 16:55:54 --> URI Class Initialized
DEBUG - 2011-09-17 16:55:54 --> Router Class Initialized
DEBUG - 2011-09-17 16:55:54 --> Output Class Initialized
DEBUG - 2011-09-17 16:55:54 --> Input Class Initialized
DEBUG - 2011-09-17 16:55:54 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-17 16:55:54 --> Language Class Initialized
DEBUG - 2011-09-17 16:55:54 --> Loader Class Initialized
DEBUG - 2011-09-17 16:55:54 --> Controller Class Initialized
DEBUG - 2011-09-17 16:55:54 --> Model Class Initialized
DEBUG - 2011-09-17 16:55:54 --> Model Class Initialized
DEBUG - 2011-09-17 16:55:54 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-17 16:55:54 --> Database Driver Class Initialized
DEBUG - 2011-09-17 16:55:54 --> Final output sent to browser
DEBUG - 2011-09-17 16:55:54 --> Total execution time: 0.4881
DEBUG - 2011-09-17 16:55:55 --> Config Class Initialized
DEBUG - 2011-09-17 16:55:55 --> Hooks Class Initialized
DEBUG - 2011-09-17 16:55:55 --> Utf8 Class Initialized
DEBUG - 2011-09-17 16:55:55 --> UTF-8 Support Enabled
DEBUG - 2011-09-17 16:55:55 --> URI Class Initialized
DEBUG - 2011-09-17 16:55:55 --> Router Class Initialized
ERROR - 2011-09-17 16:55:55 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-09-17 16:56:07 --> Config Class Initialized
DEBUG - 2011-09-17 16:56:07 --> Hooks Class Initialized
DEBUG - 2011-09-17 16:56:07 --> Utf8 Class Initialized
DEBUG - 2011-09-17 16:56:07 --> UTF-8 Support Enabled
DEBUG - 2011-09-17 16:56:07 --> URI Class Initialized
DEBUG - 2011-09-17 16:56:07 --> Router Class Initialized
DEBUG - 2011-09-17 16:56:07 --> Output Class Initialized
DEBUG - 2011-09-17 16:56:07 --> Input Class Initialized
DEBUG - 2011-09-17 16:56:07 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-17 16:56:07 --> Language Class Initialized
DEBUG - 2011-09-17 16:56:07 --> Loader Class Initialized
DEBUG - 2011-09-17 16:56:07 --> Controller Class Initialized
ERROR - 2011-09-17 16:56:07 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-09-17 16:56:07 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-09-17 16:56:07 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-09-17 16:56:07 --> Model Class Initialized
DEBUG - 2011-09-17 16:56:07 --> Model Class Initialized
DEBUG - 2011-09-17 16:56:07 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-17 16:56:07 --> Database Driver Class Initialized
DEBUG - 2011-09-17 16:56:07 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-09-17 16:56:07 --> Helper loaded: url_helper
DEBUG - 2011-09-17 16:56:07 --> File loaded: application/views/common/header.php
DEBUG - 2011-09-17 16:56:07 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-09-17 16:56:07 --> File loaded: application/views/common/footer.php
DEBUG - 2011-09-17 16:56:07 --> File loaded: application/views/layout/main.php
DEBUG - 2011-09-17 16:56:07 --> Final output sent to browser
DEBUG - 2011-09-17 16:56:07 --> Total execution time: 0.0273
DEBUG - 2011-09-17 16:56:07 --> Config Class Initialized
DEBUG - 2011-09-17 16:56:07 --> Hooks Class Initialized
DEBUG - 2011-09-17 16:56:07 --> Utf8 Class Initialized
DEBUG - 2011-09-17 16:56:07 --> UTF-8 Support Enabled
DEBUG - 2011-09-17 16:56:07 --> URI Class Initialized
DEBUG - 2011-09-17 16:56:07 --> Router Class Initialized
DEBUG - 2011-09-17 16:56:07 --> Output Class Initialized
DEBUG - 2011-09-17 16:56:07 --> Input Class Initialized
DEBUG - 2011-09-17 16:56:07 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-17 16:56:07 --> Language Class Initialized
DEBUG - 2011-09-17 16:56:07 --> Loader Class Initialized
DEBUG - 2011-09-17 16:56:07 --> Controller Class Initialized
DEBUG - 2011-09-17 16:56:07 --> Model Class Initialized
DEBUG - 2011-09-17 16:56:07 --> Model Class Initialized
DEBUG - 2011-09-17 16:56:07 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-17 16:56:07 --> Database Driver Class Initialized
DEBUG - 2011-09-17 16:56:08 --> Final output sent to browser
DEBUG - 2011-09-17 16:56:08 --> Total execution time: 0.5774
DEBUG - 2011-09-17 16:56:08 --> Config Class Initialized
DEBUG - 2011-09-17 16:56:08 --> Hooks Class Initialized
DEBUG - 2011-09-17 16:56:08 --> Utf8 Class Initialized
DEBUG - 2011-09-17 16:56:08 --> UTF-8 Support Enabled
DEBUG - 2011-09-17 16:56:08 --> URI Class Initialized
DEBUG - 2011-09-17 16:56:08 --> Router Class Initialized
DEBUG - 2011-09-17 16:56:08 --> Output Class Initialized
DEBUG - 2011-09-17 16:56:08 --> Input Class Initialized
DEBUG - 2011-09-17 16:56:08 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-17 16:56:08 --> Language Class Initialized
DEBUG - 2011-09-17 16:56:08 --> Loader Class Initialized
DEBUG - 2011-09-17 16:56:08 --> Controller Class Initialized
ERROR - 2011-09-17 16:56:08 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-09-17 16:56:08 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-09-17 16:56:08 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-09-17 16:56:08 --> Model Class Initialized
DEBUG - 2011-09-17 16:56:08 --> Model Class Initialized
DEBUG - 2011-09-17 16:56:08 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-17 16:56:08 --> Database Driver Class Initialized
DEBUG - 2011-09-17 16:56:08 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-09-17 16:56:08 --> Helper loaded: url_helper
DEBUG - 2011-09-17 16:56:08 --> File loaded: application/views/common/header.php
DEBUG - 2011-09-17 16:56:08 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-09-17 16:56:08 --> File loaded: application/views/common/footer.php
DEBUG - 2011-09-17 16:56:08 --> File loaded: application/views/layout/main.php
DEBUG - 2011-09-17 16:56:08 --> Final output sent to browser
DEBUG - 2011-09-17 16:56:08 --> Total execution time: 0.0271
DEBUG - 2011-09-17 16:56:09 --> Config Class Initialized
DEBUG - 2011-09-17 16:56:09 --> Hooks Class Initialized
DEBUG - 2011-09-17 16:56:09 --> Utf8 Class Initialized
DEBUG - 2011-09-17 16:56:09 --> UTF-8 Support Enabled
DEBUG - 2011-09-17 16:56:09 --> URI Class Initialized
DEBUG - 2011-09-17 16:56:09 --> Router Class Initialized
ERROR - 2011-09-17 16:56:09 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-09-17 16:56:17 --> Config Class Initialized
DEBUG - 2011-09-17 16:56:17 --> Hooks Class Initialized
DEBUG - 2011-09-17 16:56:17 --> Utf8 Class Initialized
DEBUG - 2011-09-17 16:56:17 --> UTF-8 Support Enabled
DEBUG - 2011-09-17 16:56:17 --> URI Class Initialized
DEBUG - 2011-09-17 16:56:17 --> Router Class Initialized
DEBUG - 2011-09-17 16:56:17 --> Output Class Initialized
DEBUG - 2011-09-17 16:56:17 --> Input Class Initialized
DEBUG - 2011-09-17 16:56:17 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-17 16:56:17 --> Language Class Initialized
DEBUG - 2011-09-17 16:56:17 --> Loader Class Initialized
DEBUG - 2011-09-17 16:56:17 --> Controller Class Initialized
ERROR - 2011-09-17 16:56:17 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-09-17 16:56:17 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-09-17 16:56:17 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-09-17 16:56:17 --> Model Class Initialized
DEBUG - 2011-09-17 16:56:17 --> Model Class Initialized
DEBUG - 2011-09-17 16:56:17 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-17 16:56:17 --> Database Driver Class Initialized
DEBUG - 2011-09-17 16:56:17 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-09-17 16:56:17 --> Helper loaded: url_helper
DEBUG - 2011-09-17 16:56:17 --> File loaded: application/views/common/header.php
DEBUG - 2011-09-17 16:56:17 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-09-17 16:56:17 --> File loaded: application/views/common/footer.php
DEBUG - 2011-09-17 16:56:17 --> File loaded: application/views/layout/main.php
DEBUG - 2011-09-17 16:56:17 --> Final output sent to browser
DEBUG - 2011-09-17 16:56:17 --> Total execution time: 0.0289
DEBUG - 2011-09-17 16:56:18 --> Config Class Initialized
DEBUG - 2011-09-17 16:56:18 --> Hooks Class Initialized
DEBUG - 2011-09-17 16:56:18 --> Utf8 Class Initialized
DEBUG - 2011-09-17 16:56:18 --> UTF-8 Support Enabled
DEBUG - 2011-09-17 16:56:18 --> URI Class Initialized
DEBUG - 2011-09-17 16:56:18 --> Router Class Initialized
DEBUG - 2011-09-17 16:56:18 --> Output Class Initialized
DEBUG - 2011-09-17 16:56:18 --> Input Class Initialized
DEBUG - 2011-09-17 16:56:18 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-17 16:56:18 --> Language Class Initialized
DEBUG - 2011-09-17 16:56:18 --> Loader Class Initialized
DEBUG - 2011-09-17 16:56:18 --> Controller Class Initialized
DEBUG - 2011-09-17 16:56:18 --> Model Class Initialized
DEBUG - 2011-09-17 16:56:18 --> Model Class Initialized
DEBUG - 2011-09-17 16:56:18 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-17 16:56:18 --> Database Driver Class Initialized
DEBUG - 2011-09-17 16:56:19 --> Final output sent to browser
DEBUG - 2011-09-17 16:56:19 --> Total execution time: 0.5746
DEBUG - 2011-09-17 16:56:20 --> Config Class Initialized
DEBUG - 2011-09-17 16:56:20 --> Hooks Class Initialized
DEBUG - 2011-09-17 16:56:20 --> Utf8 Class Initialized
DEBUG - 2011-09-17 16:56:20 --> UTF-8 Support Enabled
DEBUG - 2011-09-17 16:56:20 --> URI Class Initialized
DEBUG - 2011-09-17 16:56:20 --> Router Class Initialized
ERROR - 2011-09-17 16:56:20 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-09-17 16:56:29 --> Config Class Initialized
DEBUG - 2011-09-17 16:56:29 --> Hooks Class Initialized
DEBUG - 2011-09-17 16:56:29 --> Utf8 Class Initialized
DEBUG - 2011-09-17 16:56:29 --> UTF-8 Support Enabled
DEBUG - 2011-09-17 16:56:29 --> URI Class Initialized
DEBUG - 2011-09-17 16:56:29 --> Router Class Initialized
DEBUG - 2011-09-17 16:56:29 --> Output Class Initialized
DEBUG - 2011-09-17 16:56:29 --> Input Class Initialized
DEBUG - 2011-09-17 16:56:29 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-17 16:56:29 --> Language Class Initialized
DEBUG - 2011-09-17 16:56:29 --> Loader Class Initialized
DEBUG - 2011-09-17 16:56:29 --> Controller Class Initialized
ERROR - 2011-09-17 16:56:29 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-09-17 16:56:29 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-09-17 16:56:29 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-09-17 16:56:29 --> Model Class Initialized
DEBUG - 2011-09-17 16:56:29 --> Model Class Initialized
DEBUG - 2011-09-17 16:56:29 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-17 16:56:29 --> Database Driver Class Initialized
DEBUG - 2011-09-17 16:56:29 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-09-17 16:56:29 --> Helper loaded: url_helper
DEBUG - 2011-09-17 16:56:29 --> File loaded: application/views/common/header.php
DEBUG - 2011-09-17 16:56:29 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-09-17 16:56:29 --> File loaded: application/views/common/footer.php
DEBUG - 2011-09-17 16:56:29 --> File loaded: application/views/layout/main.php
DEBUG - 2011-09-17 16:56:29 --> Final output sent to browser
DEBUG - 2011-09-17 16:56:29 --> Total execution time: 0.0295
DEBUG - 2011-09-17 16:56:29 --> Config Class Initialized
DEBUG - 2011-09-17 16:56:29 --> Hooks Class Initialized
DEBUG - 2011-09-17 16:56:29 --> Utf8 Class Initialized
DEBUG - 2011-09-17 16:56:29 --> UTF-8 Support Enabled
DEBUG - 2011-09-17 16:56:29 --> URI Class Initialized
DEBUG - 2011-09-17 16:56:29 --> Router Class Initialized
DEBUG - 2011-09-17 16:56:29 --> Output Class Initialized
DEBUG - 2011-09-17 16:56:29 --> Input Class Initialized
DEBUG - 2011-09-17 16:56:29 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-17 16:56:29 --> Language Class Initialized
DEBUG - 2011-09-17 16:56:29 --> Loader Class Initialized
DEBUG - 2011-09-17 16:56:29 --> Controller Class Initialized
DEBUG - 2011-09-17 16:56:29 --> Model Class Initialized
DEBUG - 2011-09-17 16:56:29 --> Model Class Initialized
DEBUG - 2011-09-17 16:56:29 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-17 16:56:29 --> Database Driver Class Initialized
DEBUG - 2011-09-17 16:56:30 --> Final output sent to browser
DEBUG - 2011-09-17 16:56:30 --> Total execution time: 0.5775
DEBUG - 2011-09-17 16:56:32 --> Config Class Initialized
DEBUG - 2011-09-17 16:56:32 --> Hooks Class Initialized
DEBUG - 2011-09-17 16:56:32 --> Utf8 Class Initialized
DEBUG - 2011-09-17 16:56:32 --> UTF-8 Support Enabled
DEBUG - 2011-09-17 16:56:32 --> URI Class Initialized
DEBUG - 2011-09-17 16:56:32 --> Router Class Initialized
ERROR - 2011-09-17 16:56:32 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-09-17 16:56:39 --> Config Class Initialized
DEBUG - 2011-09-17 16:56:39 --> Hooks Class Initialized
DEBUG - 2011-09-17 16:56:39 --> Utf8 Class Initialized
DEBUG - 2011-09-17 16:56:39 --> UTF-8 Support Enabled
DEBUG - 2011-09-17 16:56:39 --> URI Class Initialized
DEBUG - 2011-09-17 16:56:39 --> Router Class Initialized
DEBUG - 2011-09-17 16:56:39 --> Output Class Initialized
DEBUG - 2011-09-17 16:56:39 --> Input Class Initialized
DEBUG - 2011-09-17 16:56:39 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-17 16:56:39 --> Language Class Initialized
DEBUG - 2011-09-17 16:56:39 --> Loader Class Initialized
DEBUG - 2011-09-17 16:56:39 --> Controller Class Initialized
ERROR - 2011-09-17 16:56:39 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-09-17 16:56:39 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-09-17 16:56:39 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-09-17 16:56:39 --> Model Class Initialized
DEBUG - 2011-09-17 16:56:39 --> Model Class Initialized
DEBUG - 2011-09-17 16:56:39 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-17 16:56:39 --> Database Driver Class Initialized
DEBUG - 2011-09-17 16:56:39 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-09-17 16:56:39 --> Helper loaded: url_helper
DEBUG - 2011-09-17 16:56:39 --> File loaded: application/views/common/header.php
DEBUG - 2011-09-17 16:56:39 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-09-17 16:56:39 --> File loaded: application/views/common/footer.php
DEBUG - 2011-09-17 16:56:39 --> File loaded: application/views/layout/main.php
DEBUG - 2011-09-17 16:56:39 --> Final output sent to browser
DEBUG - 2011-09-17 16:56:39 --> Total execution time: 0.0272
DEBUG - 2011-09-17 16:56:40 --> Config Class Initialized
DEBUG - 2011-09-17 16:56:40 --> Hooks Class Initialized
DEBUG - 2011-09-17 16:56:40 --> Utf8 Class Initialized
DEBUG - 2011-09-17 16:56:40 --> UTF-8 Support Enabled
DEBUG - 2011-09-17 16:56:40 --> URI Class Initialized
DEBUG - 2011-09-17 16:56:40 --> Router Class Initialized
DEBUG - 2011-09-17 16:56:40 --> Output Class Initialized
DEBUG - 2011-09-17 16:56:40 --> Input Class Initialized
DEBUG - 2011-09-17 16:56:40 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-17 16:56:40 --> Language Class Initialized
DEBUG - 2011-09-17 16:56:40 --> Loader Class Initialized
DEBUG - 2011-09-17 16:56:40 --> Controller Class Initialized
DEBUG - 2011-09-17 16:56:40 --> Model Class Initialized
DEBUG - 2011-09-17 16:56:40 --> Model Class Initialized
DEBUG - 2011-09-17 16:56:40 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-17 16:56:40 --> Database Driver Class Initialized
DEBUG - 2011-09-17 16:56:40 --> Final output sent to browser
DEBUG - 2011-09-17 16:56:40 --> Total execution time: 0.5064
DEBUG - 2011-09-17 16:56:41 --> Config Class Initialized
DEBUG - 2011-09-17 16:56:41 --> Hooks Class Initialized
DEBUG - 2011-09-17 16:56:41 --> Utf8 Class Initialized
DEBUG - 2011-09-17 16:56:41 --> UTF-8 Support Enabled
DEBUG - 2011-09-17 16:56:41 --> URI Class Initialized
DEBUG - 2011-09-17 16:56:41 --> Router Class Initialized
ERROR - 2011-09-17 16:56:41 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-09-17 16:56:46 --> Config Class Initialized
DEBUG - 2011-09-17 16:56:46 --> Hooks Class Initialized
DEBUG - 2011-09-17 16:56:46 --> Utf8 Class Initialized
DEBUG - 2011-09-17 16:56:46 --> UTF-8 Support Enabled
DEBUG - 2011-09-17 16:56:46 --> URI Class Initialized
DEBUG - 2011-09-17 16:56:46 --> Router Class Initialized
DEBUG - 2011-09-17 16:56:46 --> Output Class Initialized
DEBUG - 2011-09-17 16:56:46 --> Input Class Initialized
DEBUG - 2011-09-17 16:56:46 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-17 16:56:46 --> Language Class Initialized
DEBUG - 2011-09-17 16:56:46 --> Loader Class Initialized
DEBUG - 2011-09-17 16:56:46 --> Controller Class Initialized
ERROR - 2011-09-17 16:56:46 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-09-17 16:56:46 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-09-17 16:56:46 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-09-17 16:56:46 --> Model Class Initialized
DEBUG - 2011-09-17 16:56:46 --> Model Class Initialized
DEBUG - 2011-09-17 16:56:46 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-17 16:56:46 --> Database Driver Class Initialized
DEBUG - 2011-09-17 16:56:46 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-09-17 16:56:46 --> Helper loaded: url_helper
DEBUG - 2011-09-17 16:56:46 --> File loaded: application/views/common/header.php
DEBUG - 2011-09-17 16:56:46 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-09-17 16:56:46 --> File loaded: application/views/common/footer.php
DEBUG - 2011-09-17 16:56:46 --> File loaded: application/views/layout/main.php
DEBUG - 2011-09-17 16:56:46 --> Final output sent to browser
DEBUG - 2011-09-17 16:56:46 --> Total execution time: 0.0301
DEBUG - 2011-09-17 16:56:47 --> Config Class Initialized
DEBUG - 2011-09-17 16:56:47 --> Hooks Class Initialized
DEBUG - 2011-09-17 16:56:47 --> Utf8 Class Initialized
DEBUG - 2011-09-17 16:56:47 --> UTF-8 Support Enabled
DEBUG - 2011-09-17 16:56:47 --> URI Class Initialized
DEBUG - 2011-09-17 16:56:47 --> Router Class Initialized
DEBUG - 2011-09-17 16:56:47 --> Output Class Initialized
DEBUG - 2011-09-17 16:56:47 --> Input Class Initialized
DEBUG - 2011-09-17 16:56:47 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-17 16:56:47 --> Language Class Initialized
DEBUG - 2011-09-17 16:56:47 --> Loader Class Initialized
DEBUG - 2011-09-17 16:56:47 --> Controller Class Initialized
DEBUG - 2011-09-17 16:56:47 --> Model Class Initialized
DEBUG - 2011-09-17 16:56:47 --> Model Class Initialized
DEBUG - 2011-09-17 16:56:47 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-17 16:56:47 --> Database Driver Class Initialized
DEBUG - 2011-09-17 16:56:47 --> Final output sent to browser
DEBUG - 2011-09-17 16:56:47 --> Total execution time: 0.4963
DEBUG - 2011-09-17 16:56:49 --> Config Class Initialized
DEBUG - 2011-09-17 16:56:49 --> Hooks Class Initialized
DEBUG - 2011-09-17 16:56:49 --> Utf8 Class Initialized
DEBUG - 2011-09-17 16:56:49 --> UTF-8 Support Enabled
DEBUG - 2011-09-17 16:56:49 --> URI Class Initialized
DEBUG - 2011-09-17 16:56:49 --> Router Class Initialized
ERROR - 2011-09-17 16:56:49 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-09-17 16:56:56 --> Config Class Initialized
DEBUG - 2011-09-17 16:56:56 --> Hooks Class Initialized
DEBUG - 2011-09-17 16:56:56 --> Utf8 Class Initialized
DEBUG - 2011-09-17 16:56:56 --> UTF-8 Support Enabled
DEBUG - 2011-09-17 16:56:56 --> URI Class Initialized
DEBUG - 2011-09-17 16:56:56 --> Router Class Initialized
DEBUG - 2011-09-17 16:56:56 --> Output Class Initialized
DEBUG - 2011-09-17 16:56:56 --> Input Class Initialized
DEBUG - 2011-09-17 16:56:56 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-17 16:56:56 --> Language Class Initialized
DEBUG - 2011-09-17 16:56:56 --> Loader Class Initialized
DEBUG - 2011-09-17 16:56:56 --> Controller Class Initialized
ERROR - 2011-09-17 16:56:56 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-09-17 16:56:56 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-09-17 16:56:56 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-09-17 16:56:56 --> Model Class Initialized
DEBUG - 2011-09-17 16:56:56 --> Model Class Initialized
DEBUG - 2011-09-17 16:56:56 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-17 16:56:56 --> Database Driver Class Initialized
DEBUG - 2011-09-17 16:56:56 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-09-17 16:56:56 --> Helper loaded: url_helper
DEBUG - 2011-09-17 16:56:56 --> File loaded: application/views/common/header.php
DEBUG - 2011-09-17 16:56:56 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-09-17 16:56:56 --> File loaded: application/views/common/footer.php
DEBUG - 2011-09-17 16:56:56 --> File loaded: application/views/layout/main.php
DEBUG - 2011-09-17 16:56:56 --> Final output sent to browser
DEBUG - 2011-09-17 16:56:56 --> Total execution time: 0.0323
DEBUG - 2011-09-17 16:56:57 --> Config Class Initialized
DEBUG - 2011-09-17 16:56:57 --> Hooks Class Initialized
DEBUG - 2011-09-17 16:56:57 --> Utf8 Class Initialized
DEBUG - 2011-09-17 16:56:57 --> UTF-8 Support Enabled
DEBUG - 2011-09-17 16:56:57 --> URI Class Initialized
DEBUG - 2011-09-17 16:56:57 --> Router Class Initialized
DEBUG - 2011-09-17 16:56:57 --> Output Class Initialized
DEBUG - 2011-09-17 16:56:57 --> Input Class Initialized
DEBUG - 2011-09-17 16:56:57 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-17 16:56:57 --> Language Class Initialized
DEBUG - 2011-09-17 16:56:57 --> Loader Class Initialized
DEBUG - 2011-09-17 16:56:57 --> Controller Class Initialized
DEBUG - 2011-09-17 16:56:57 --> Model Class Initialized
DEBUG - 2011-09-17 16:56:57 --> Model Class Initialized
DEBUG - 2011-09-17 16:56:57 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-17 16:56:57 --> Database Driver Class Initialized
DEBUG - 2011-09-17 16:56:58 --> Final output sent to browser
DEBUG - 2011-09-17 16:56:58 --> Total execution time: 0.4979
DEBUG - 2011-09-17 16:56:59 --> Config Class Initialized
DEBUG - 2011-09-17 16:56:59 --> Hooks Class Initialized
DEBUG - 2011-09-17 16:56:59 --> Utf8 Class Initialized
DEBUG - 2011-09-17 16:56:59 --> UTF-8 Support Enabled
DEBUG - 2011-09-17 16:56:59 --> URI Class Initialized
DEBUG - 2011-09-17 16:56:59 --> Router Class Initialized
ERROR - 2011-09-17 16:56:59 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-09-17 16:57:05 --> Config Class Initialized
DEBUG - 2011-09-17 16:57:05 --> Hooks Class Initialized
DEBUG - 2011-09-17 16:57:05 --> Utf8 Class Initialized
DEBUG - 2011-09-17 16:57:05 --> UTF-8 Support Enabled
DEBUG - 2011-09-17 16:57:05 --> URI Class Initialized
DEBUG - 2011-09-17 16:57:05 --> Router Class Initialized
DEBUG - 2011-09-17 16:57:05 --> Output Class Initialized
DEBUG - 2011-09-17 16:57:05 --> Input Class Initialized
DEBUG - 2011-09-17 16:57:05 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-17 16:57:05 --> Language Class Initialized
DEBUG - 2011-09-17 16:57:05 --> Loader Class Initialized
DEBUG - 2011-09-17 16:57:05 --> Controller Class Initialized
ERROR - 2011-09-17 16:57:05 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-09-17 16:57:05 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-09-17 16:57:05 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-09-17 16:57:05 --> Model Class Initialized
DEBUG - 2011-09-17 16:57:05 --> Model Class Initialized
DEBUG - 2011-09-17 16:57:05 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-17 16:57:05 --> Database Driver Class Initialized
DEBUG - 2011-09-17 16:57:05 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-09-17 16:57:05 --> Helper loaded: url_helper
DEBUG - 2011-09-17 16:57:05 --> File loaded: application/views/common/header.php
DEBUG - 2011-09-17 16:57:05 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-09-17 16:57:05 --> File loaded: application/views/common/footer.php
DEBUG - 2011-09-17 16:57:05 --> File loaded: application/views/layout/main.php
DEBUG - 2011-09-17 16:57:05 --> Final output sent to browser
DEBUG - 2011-09-17 16:57:05 --> Total execution time: 0.0273
DEBUG - 2011-09-17 16:57:06 --> Config Class Initialized
DEBUG - 2011-09-17 16:57:06 --> Hooks Class Initialized
DEBUG - 2011-09-17 16:57:06 --> Utf8 Class Initialized
DEBUG - 2011-09-17 16:57:06 --> UTF-8 Support Enabled
DEBUG - 2011-09-17 16:57:06 --> URI Class Initialized
DEBUG - 2011-09-17 16:57:06 --> Router Class Initialized
DEBUG - 2011-09-17 16:57:06 --> Output Class Initialized
DEBUG - 2011-09-17 16:57:06 --> Input Class Initialized
DEBUG - 2011-09-17 16:57:06 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-17 16:57:06 --> Language Class Initialized
DEBUG - 2011-09-17 16:57:06 --> Loader Class Initialized
DEBUG - 2011-09-17 16:57:06 --> Controller Class Initialized
DEBUG - 2011-09-17 16:57:06 --> Model Class Initialized
DEBUG - 2011-09-17 16:57:06 --> Model Class Initialized
DEBUG - 2011-09-17 16:57:06 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-17 16:57:06 --> Database Driver Class Initialized
DEBUG - 2011-09-17 16:57:06 --> Final output sent to browser
DEBUG - 2011-09-17 16:57:06 --> Total execution time: 0.5048
DEBUG - 2011-09-17 16:57:08 --> Config Class Initialized
DEBUG - 2011-09-17 16:57:08 --> Hooks Class Initialized
DEBUG - 2011-09-17 16:57:08 --> Utf8 Class Initialized
DEBUG - 2011-09-17 16:57:08 --> UTF-8 Support Enabled
DEBUG - 2011-09-17 16:57:08 --> URI Class Initialized
DEBUG - 2011-09-17 16:57:08 --> Router Class Initialized
ERROR - 2011-09-17 16:57:08 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-09-17 16:57:13 --> Config Class Initialized
DEBUG - 2011-09-17 16:57:13 --> Hooks Class Initialized
DEBUG - 2011-09-17 16:57:13 --> Utf8 Class Initialized
DEBUG - 2011-09-17 16:57:13 --> UTF-8 Support Enabled
DEBUG - 2011-09-17 16:57:13 --> URI Class Initialized
DEBUG - 2011-09-17 16:57:13 --> Router Class Initialized
DEBUG - 2011-09-17 16:57:13 --> Output Class Initialized
DEBUG - 2011-09-17 16:57:13 --> Input Class Initialized
DEBUG - 2011-09-17 16:57:13 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-17 16:57:13 --> Language Class Initialized
DEBUG - 2011-09-17 16:57:13 --> Loader Class Initialized
DEBUG - 2011-09-17 16:57:13 --> Controller Class Initialized
ERROR - 2011-09-17 16:57:13 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-09-17 16:57:13 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-09-17 16:57:13 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-09-17 16:57:13 --> Model Class Initialized
DEBUG - 2011-09-17 16:57:13 --> Model Class Initialized
DEBUG - 2011-09-17 16:57:13 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-17 16:57:13 --> Database Driver Class Initialized
DEBUG - 2011-09-17 16:57:13 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-09-17 16:57:13 --> Helper loaded: url_helper
DEBUG - 2011-09-17 16:57:13 --> File loaded: application/views/common/header.php
DEBUG - 2011-09-17 16:57:13 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-09-17 16:57:13 --> File loaded: application/views/common/footer.php
DEBUG - 2011-09-17 16:57:13 --> File loaded: application/views/layout/main.php
DEBUG - 2011-09-17 16:57:13 --> Final output sent to browser
DEBUG - 2011-09-17 16:57:13 --> Total execution time: 0.0299
DEBUG - 2011-09-17 16:57:14 --> Config Class Initialized
DEBUG - 2011-09-17 16:57:14 --> Hooks Class Initialized
DEBUG - 2011-09-17 16:57:14 --> Utf8 Class Initialized
DEBUG - 2011-09-17 16:57:14 --> UTF-8 Support Enabled
DEBUG - 2011-09-17 16:57:14 --> URI Class Initialized
DEBUG - 2011-09-17 16:57:14 --> Router Class Initialized
DEBUG - 2011-09-17 16:57:14 --> Output Class Initialized
DEBUG - 2011-09-17 16:57:14 --> Input Class Initialized
DEBUG - 2011-09-17 16:57:14 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-17 16:57:14 --> Language Class Initialized
DEBUG - 2011-09-17 16:57:14 --> Loader Class Initialized
DEBUG - 2011-09-17 16:57:14 --> Controller Class Initialized
DEBUG - 2011-09-17 16:57:14 --> Model Class Initialized
DEBUG - 2011-09-17 16:57:14 --> Model Class Initialized
DEBUG - 2011-09-17 16:57:14 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-17 16:57:14 --> Database Driver Class Initialized
DEBUG - 2011-09-17 16:57:14 --> Final output sent to browser
DEBUG - 2011-09-17 16:57:14 --> Total execution time: 0.6115
DEBUG - 2011-09-17 16:57:16 --> Config Class Initialized
DEBUG - 2011-09-17 16:57:16 --> Hooks Class Initialized
DEBUG - 2011-09-17 16:57:16 --> Utf8 Class Initialized
DEBUG - 2011-09-17 16:57:16 --> UTF-8 Support Enabled
DEBUG - 2011-09-17 16:57:16 --> URI Class Initialized
DEBUG - 2011-09-17 16:57:16 --> Router Class Initialized
ERROR - 2011-09-17 16:57:16 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-09-17 16:57:23 --> Config Class Initialized
DEBUG - 2011-09-17 16:57:23 --> Hooks Class Initialized
DEBUG - 2011-09-17 16:57:23 --> Utf8 Class Initialized
DEBUG - 2011-09-17 16:57:23 --> UTF-8 Support Enabled
DEBUG - 2011-09-17 16:57:23 --> URI Class Initialized
DEBUG - 2011-09-17 16:57:23 --> Router Class Initialized
DEBUG - 2011-09-17 16:57:23 --> Output Class Initialized
DEBUG - 2011-09-17 16:57:23 --> Input Class Initialized
DEBUG - 2011-09-17 16:57:23 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-17 16:57:23 --> Language Class Initialized
DEBUG - 2011-09-17 16:57:23 --> Loader Class Initialized
DEBUG - 2011-09-17 16:57:23 --> Controller Class Initialized
ERROR - 2011-09-17 16:57:23 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-09-17 16:57:23 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-09-17 16:57:23 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-09-17 16:57:23 --> Model Class Initialized
DEBUG - 2011-09-17 16:57:23 --> Model Class Initialized
DEBUG - 2011-09-17 16:57:23 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-17 16:57:23 --> Database Driver Class Initialized
DEBUG - 2011-09-17 16:57:23 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-09-17 16:57:23 --> Helper loaded: url_helper
DEBUG - 2011-09-17 16:57:23 --> File loaded: application/views/common/header.php
DEBUG - 2011-09-17 16:57:23 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-09-17 16:57:23 --> File loaded: application/views/common/footer.php
DEBUG - 2011-09-17 16:57:23 --> File loaded: application/views/layout/main.php
DEBUG - 2011-09-17 16:57:23 --> Final output sent to browser
DEBUG - 2011-09-17 16:57:23 --> Total execution time: 0.0295
DEBUG - 2011-09-17 16:57:24 --> Config Class Initialized
DEBUG - 2011-09-17 16:57:24 --> Hooks Class Initialized
DEBUG - 2011-09-17 16:57:24 --> Utf8 Class Initialized
DEBUG - 2011-09-17 16:57:24 --> UTF-8 Support Enabled
DEBUG - 2011-09-17 16:57:24 --> URI Class Initialized
DEBUG - 2011-09-17 16:57:24 --> Router Class Initialized
DEBUG - 2011-09-17 16:57:24 --> Output Class Initialized
DEBUG - 2011-09-17 16:57:24 --> Input Class Initialized
DEBUG - 2011-09-17 16:57:24 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-17 16:57:24 --> Language Class Initialized
DEBUG - 2011-09-17 16:57:24 --> Loader Class Initialized
DEBUG - 2011-09-17 16:57:24 --> Controller Class Initialized
DEBUG - 2011-09-17 16:57:24 --> Model Class Initialized
DEBUG - 2011-09-17 16:57:24 --> Model Class Initialized
DEBUG - 2011-09-17 16:57:24 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-17 16:57:24 --> Database Driver Class Initialized
DEBUG - 2011-09-17 16:57:25 --> Final output sent to browser
DEBUG - 2011-09-17 16:57:25 --> Total execution time: 0.6119
DEBUG - 2011-09-17 16:57:26 --> Config Class Initialized
DEBUG - 2011-09-17 16:57:26 --> Hooks Class Initialized
DEBUG - 2011-09-17 16:57:26 --> Utf8 Class Initialized
DEBUG - 2011-09-17 16:57:26 --> UTF-8 Support Enabled
DEBUG - 2011-09-17 16:57:26 --> URI Class Initialized
DEBUG - 2011-09-17 16:57:26 --> Router Class Initialized
ERROR - 2011-09-17 16:57:26 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-09-17 16:57:31 --> Config Class Initialized
DEBUG - 2011-09-17 16:57:31 --> Hooks Class Initialized
DEBUG - 2011-09-17 16:57:31 --> Utf8 Class Initialized
DEBUG - 2011-09-17 16:57:31 --> UTF-8 Support Enabled
DEBUG - 2011-09-17 16:57:31 --> URI Class Initialized
DEBUG - 2011-09-17 16:57:31 --> Router Class Initialized
DEBUG - 2011-09-17 16:57:31 --> Output Class Initialized
DEBUG - 2011-09-17 16:57:31 --> Input Class Initialized
DEBUG - 2011-09-17 16:57:31 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-17 16:57:31 --> Language Class Initialized
DEBUG - 2011-09-17 16:57:31 --> Loader Class Initialized
DEBUG - 2011-09-17 16:57:31 --> Controller Class Initialized
ERROR - 2011-09-17 16:57:31 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-09-17 16:57:31 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-09-17 16:57:31 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-09-17 16:57:31 --> Model Class Initialized
DEBUG - 2011-09-17 16:57:31 --> Model Class Initialized
DEBUG - 2011-09-17 16:57:31 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-17 16:57:31 --> Database Driver Class Initialized
DEBUG - 2011-09-17 16:57:31 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-09-17 16:57:31 --> Helper loaded: url_helper
DEBUG - 2011-09-17 16:57:31 --> File loaded: application/views/common/header.php
DEBUG - 2011-09-17 16:57:31 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-09-17 16:57:31 --> File loaded: application/views/common/footer.php
DEBUG - 2011-09-17 16:57:31 --> File loaded: application/views/layout/main.php
DEBUG - 2011-09-17 16:57:31 --> Final output sent to browser
DEBUG - 2011-09-17 16:57:31 --> Total execution time: 0.0290
DEBUG - 2011-09-17 16:57:31 --> Config Class Initialized
DEBUG - 2011-09-17 16:57:31 --> Hooks Class Initialized
DEBUG - 2011-09-17 16:57:31 --> Utf8 Class Initialized
DEBUG - 2011-09-17 16:57:31 --> UTF-8 Support Enabled
DEBUG - 2011-09-17 16:57:31 --> URI Class Initialized
DEBUG - 2011-09-17 16:57:31 --> Router Class Initialized
DEBUG - 2011-09-17 16:57:31 --> Output Class Initialized
DEBUG - 2011-09-17 16:57:31 --> Input Class Initialized
DEBUG - 2011-09-17 16:57:31 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-17 16:57:31 --> Language Class Initialized
DEBUG - 2011-09-17 16:57:31 --> Loader Class Initialized
DEBUG - 2011-09-17 16:57:31 --> Controller Class Initialized
DEBUG - 2011-09-17 16:57:31 --> Model Class Initialized
DEBUG - 2011-09-17 16:57:31 --> Model Class Initialized
DEBUG - 2011-09-17 16:57:31 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-17 16:57:31 --> Database Driver Class Initialized
DEBUG - 2011-09-17 16:57:32 --> Final output sent to browser
DEBUG - 2011-09-17 16:57:32 --> Total execution time: 0.5448
DEBUG - 2011-09-17 16:57:33 --> Config Class Initialized
DEBUG - 2011-09-17 16:57:33 --> Hooks Class Initialized
DEBUG - 2011-09-17 16:57:33 --> Utf8 Class Initialized
DEBUG - 2011-09-17 16:57:33 --> UTF-8 Support Enabled
DEBUG - 2011-09-17 16:57:33 --> URI Class Initialized
DEBUG - 2011-09-17 16:57:33 --> Router Class Initialized
ERROR - 2011-09-17 16:57:33 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-09-17 16:57:39 --> Config Class Initialized
DEBUG - 2011-09-17 16:57:39 --> Hooks Class Initialized
DEBUG - 2011-09-17 16:57:39 --> Utf8 Class Initialized
DEBUG - 2011-09-17 16:57:39 --> UTF-8 Support Enabled
DEBUG - 2011-09-17 16:57:39 --> URI Class Initialized
DEBUG - 2011-09-17 16:57:39 --> Router Class Initialized
DEBUG - 2011-09-17 16:57:39 --> Output Class Initialized
DEBUG - 2011-09-17 16:57:39 --> Input Class Initialized
DEBUG - 2011-09-17 16:57:39 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-17 16:57:39 --> Language Class Initialized
DEBUG - 2011-09-17 16:57:39 --> Loader Class Initialized
DEBUG - 2011-09-17 16:57:39 --> Controller Class Initialized
ERROR - 2011-09-17 16:57:39 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-09-17 16:57:39 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-09-17 16:57:39 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-09-17 16:57:39 --> Model Class Initialized
DEBUG - 2011-09-17 16:57:39 --> Model Class Initialized
DEBUG - 2011-09-17 16:57:39 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-17 16:57:39 --> Database Driver Class Initialized
DEBUG - 2011-09-17 16:57:39 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-09-17 16:57:39 --> Helper loaded: url_helper
DEBUG - 2011-09-17 16:57:39 --> File loaded: application/views/common/header.php
DEBUG - 2011-09-17 16:57:39 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-09-17 16:57:39 --> File loaded: application/views/common/footer.php
DEBUG - 2011-09-17 16:57:39 --> File loaded: application/views/layout/main.php
DEBUG - 2011-09-17 16:57:39 --> Final output sent to browser
DEBUG - 2011-09-17 16:57:39 --> Total execution time: 0.0339
DEBUG - 2011-09-17 16:57:40 --> Config Class Initialized
DEBUG - 2011-09-17 16:57:40 --> Hooks Class Initialized
DEBUG - 2011-09-17 16:57:40 --> Utf8 Class Initialized
DEBUG - 2011-09-17 16:57:40 --> UTF-8 Support Enabled
DEBUG - 2011-09-17 16:57:40 --> URI Class Initialized
DEBUG - 2011-09-17 16:57:40 --> Router Class Initialized
DEBUG - 2011-09-17 16:57:40 --> Output Class Initialized
DEBUG - 2011-09-17 16:57:40 --> Input Class Initialized
DEBUG - 2011-09-17 16:57:40 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-17 16:57:40 --> Language Class Initialized
DEBUG - 2011-09-17 16:57:40 --> Loader Class Initialized
DEBUG - 2011-09-17 16:57:40 --> Controller Class Initialized
DEBUG - 2011-09-17 16:57:40 --> Model Class Initialized
DEBUG - 2011-09-17 16:57:40 --> Model Class Initialized
DEBUG - 2011-09-17 16:57:40 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-17 16:57:40 --> Database Driver Class Initialized
DEBUG - 2011-09-17 16:57:40 --> Final output sent to browser
DEBUG - 2011-09-17 16:57:40 --> Total execution time: 0.5187
DEBUG - 2011-09-17 16:57:42 --> Config Class Initialized
DEBUG - 2011-09-17 16:57:42 --> Hooks Class Initialized
DEBUG - 2011-09-17 16:57:42 --> Utf8 Class Initialized
DEBUG - 2011-09-17 16:57:42 --> UTF-8 Support Enabled
DEBUG - 2011-09-17 16:57:42 --> URI Class Initialized
DEBUG - 2011-09-17 16:57:42 --> Router Class Initialized
ERROR - 2011-09-17 16:57:42 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-09-17 16:57:46 --> Config Class Initialized
DEBUG - 2011-09-17 16:57:46 --> Hooks Class Initialized
DEBUG - 2011-09-17 16:57:46 --> Utf8 Class Initialized
DEBUG - 2011-09-17 16:57:46 --> UTF-8 Support Enabled
DEBUG - 2011-09-17 16:57:46 --> URI Class Initialized
DEBUG - 2011-09-17 16:57:47 --> Router Class Initialized
DEBUG - 2011-09-17 16:57:47 --> Output Class Initialized
DEBUG - 2011-09-17 16:57:47 --> Input Class Initialized
DEBUG - 2011-09-17 16:57:47 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-17 16:57:47 --> Language Class Initialized
DEBUG - 2011-09-17 16:57:47 --> Loader Class Initialized
DEBUG - 2011-09-17 16:57:47 --> Controller Class Initialized
ERROR - 2011-09-17 16:57:47 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-09-17 16:57:47 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-09-17 16:57:47 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-09-17 16:57:47 --> Model Class Initialized
DEBUG - 2011-09-17 16:57:47 --> Model Class Initialized
DEBUG - 2011-09-17 16:57:47 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-17 16:57:47 --> Database Driver Class Initialized
DEBUG - 2011-09-17 16:57:47 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-09-17 16:57:47 --> Helper loaded: url_helper
DEBUG - 2011-09-17 16:57:47 --> File loaded: application/views/common/header.php
DEBUG - 2011-09-17 16:57:47 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-09-17 16:57:47 --> File loaded: application/views/common/footer.php
DEBUG - 2011-09-17 16:57:47 --> File loaded: application/views/layout/main.php
DEBUG - 2011-09-17 16:57:47 --> Final output sent to browser
DEBUG - 2011-09-17 16:57:47 --> Total execution time: 0.0293
DEBUG - 2011-09-17 16:57:47 --> Config Class Initialized
DEBUG - 2011-09-17 16:57:47 --> Hooks Class Initialized
DEBUG - 2011-09-17 16:57:47 --> Utf8 Class Initialized
DEBUG - 2011-09-17 16:57:47 --> UTF-8 Support Enabled
DEBUG - 2011-09-17 16:57:47 --> URI Class Initialized
DEBUG - 2011-09-17 16:57:47 --> Router Class Initialized
DEBUG - 2011-09-17 16:57:47 --> Output Class Initialized
DEBUG - 2011-09-17 16:57:47 --> Input Class Initialized
DEBUG - 2011-09-17 16:57:47 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-17 16:57:47 --> Language Class Initialized
DEBUG - 2011-09-17 16:57:47 --> Loader Class Initialized
DEBUG - 2011-09-17 16:57:47 --> Controller Class Initialized
DEBUG - 2011-09-17 16:57:47 --> Model Class Initialized
DEBUG - 2011-09-17 16:57:47 --> Model Class Initialized
DEBUG - 2011-09-17 16:57:47 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-17 16:57:47 --> Database Driver Class Initialized
DEBUG - 2011-09-17 16:57:48 --> Final output sent to browser
DEBUG - 2011-09-17 16:57:48 --> Total execution time: 0.5233
DEBUG - 2011-09-17 16:57:49 --> Config Class Initialized
DEBUG - 2011-09-17 16:57:49 --> Hooks Class Initialized
DEBUG - 2011-09-17 16:57:49 --> Utf8 Class Initialized
DEBUG - 2011-09-17 16:57:49 --> UTF-8 Support Enabled
DEBUG - 2011-09-17 16:57:49 --> URI Class Initialized
DEBUG - 2011-09-17 16:57:49 --> Router Class Initialized
ERROR - 2011-09-17 16:57:49 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-09-17 16:57:53 --> Config Class Initialized
DEBUG - 2011-09-17 16:57:53 --> Hooks Class Initialized
DEBUG - 2011-09-17 16:57:53 --> Utf8 Class Initialized
DEBUG - 2011-09-17 16:57:53 --> UTF-8 Support Enabled
DEBUG - 2011-09-17 16:57:53 --> URI Class Initialized
DEBUG - 2011-09-17 16:57:53 --> Router Class Initialized
DEBUG - 2011-09-17 16:57:53 --> Output Class Initialized
DEBUG - 2011-09-17 16:57:53 --> Input Class Initialized
DEBUG - 2011-09-17 16:57:53 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-17 16:57:53 --> Language Class Initialized
DEBUG - 2011-09-17 16:57:53 --> Loader Class Initialized
DEBUG - 2011-09-17 16:57:53 --> Controller Class Initialized
ERROR - 2011-09-17 16:57:53 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-09-17 16:57:53 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-09-17 16:57:53 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-09-17 16:57:53 --> Model Class Initialized
DEBUG - 2011-09-17 16:57:53 --> Model Class Initialized
DEBUG - 2011-09-17 16:57:53 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-17 16:57:53 --> Database Driver Class Initialized
DEBUG - 2011-09-17 16:57:53 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-09-17 16:57:53 --> Helper loaded: url_helper
DEBUG - 2011-09-17 16:57:53 --> File loaded: application/views/common/header.php
DEBUG - 2011-09-17 16:57:53 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-09-17 16:57:53 --> File loaded: application/views/common/footer.php
DEBUG - 2011-09-17 16:57:53 --> File loaded: application/views/layout/main.php
DEBUG - 2011-09-17 16:57:53 --> Final output sent to browser
DEBUG - 2011-09-17 16:57:53 --> Total execution time: 0.0285
DEBUG - 2011-09-17 16:57:54 --> Config Class Initialized
DEBUG - 2011-09-17 16:57:54 --> Hooks Class Initialized
DEBUG - 2011-09-17 16:57:54 --> Utf8 Class Initialized
DEBUG - 2011-09-17 16:57:54 --> UTF-8 Support Enabled
DEBUG - 2011-09-17 16:57:54 --> URI Class Initialized
DEBUG - 2011-09-17 16:57:54 --> Router Class Initialized
DEBUG - 2011-09-17 16:57:54 --> Output Class Initialized
DEBUG - 2011-09-17 16:57:54 --> Input Class Initialized
DEBUG - 2011-09-17 16:57:54 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-17 16:57:54 --> Language Class Initialized
DEBUG - 2011-09-17 16:57:54 --> Loader Class Initialized
DEBUG - 2011-09-17 16:57:54 --> Controller Class Initialized
DEBUG - 2011-09-17 16:57:54 --> Model Class Initialized
DEBUG - 2011-09-17 16:57:54 --> Model Class Initialized
DEBUG - 2011-09-17 16:57:54 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-17 16:57:54 --> Database Driver Class Initialized
DEBUG - 2011-09-17 16:57:54 --> Final output sent to browser
DEBUG - 2011-09-17 16:57:54 --> Total execution time: 0.5039
DEBUG - 2011-09-17 16:57:56 --> Config Class Initialized
DEBUG - 2011-09-17 16:57:56 --> Hooks Class Initialized
DEBUG - 2011-09-17 16:57:56 --> Utf8 Class Initialized
DEBUG - 2011-09-17 16:57:56 --> UTF-8 Support Enabled
DEBUG - 2011-09-17 16:57:56 --> URI Class Initialized
DEBUG - 2011-09-17 16:57:56 --> Router Class Initialized
ERROR - 2011-09-17 16:57:56 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-09-17 16:58:00 --> Config Class Initialized
DEBUG - 2011-09-17 16:58:00 --> Hooks Class Initialized
DEBUG - 2011-09-17 16:58:00 --> Utf8 Class Initialized
DEBUG - 2011-09-17 16:58:00 --> UTF-8 Support Enabled
DEBUG - 2011-09-17 16:58:00 --> URI Class Initialized
DEBUG - 2011-09-17 16:58:00 --> Router Class Initialized
DEBUG - 2011-09-17 16:58:00 --> Output Class Initialized
DEBUG - 2011-09-17 16:58:00 --> Input Class Initialized
DEBUG - 2011-09-17 16:58:00 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-17 16:58:00 --> Language Class Initialized
DEBUG - 2011-09-17 16:58:00 --> Loader Class Initialized
DEBUG - 2011-09-17 16:58:00 --> Controller Class Initialized
ERROR - 2011-09-17 16:58:00 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-09-17 16:58:00 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-09-17 16:58:00 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-09-17 16:58:00 --> Model Class Initialized
DEBUG - 2011-09-17 16:58:00 --> Model Class Initialized
DEBUG - 2011-09-17 16:58:00 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-17 16:58:00 --> Database Driver Class Initialized
DEBUG - 2011-09-17 16:58:00 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-09-17 16:58:00 --> Helper loaded: url_helper
DEBUG - 2011-09-17 16:58:00 --> File loaded: application/views/common/header.php
DEBUG - 2011-09-17 16:58:00 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-09-17 16:58:00 --> File loaded: application/views/common/footer.php
DEBUG - 2011-09-17 16:58:00 --> File loaded: application/views/layout/main.php
DEBUG - 2011-09-17 16:58:00 --> Final output sent to browser
DEBUG - 2011-09-17 16:58:00 --> Total execution time: 0.0278
DEBUG - 2011-09-17 16:58:01 --> Config Class Initialized
DEBUG - 2011-09-17 16:58:01 --> Hooks Class Initialized
DEBUG - 2011-09-17 16:58:01 --> Utf8 Class Initialized
DEBUG - 2011-09-17 16:58:01 --> UTF-8 Support Enabled
DEBUG - 2011-09-17 16:58:01 --> URI Class Initialized
DEBUG - 2011-09-17 16:58:01 --> Router Class Initialized
DEBUG - 2011-09-17 16:58:01 --> Output Class Initialized
DEBUG - 2011-09-17 16:58:01 --> Input Class Initialized
DEBUG - 2011-09-17 16:58:01 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-17 16:58:01 --> Language Class Initialized
DEBUG - 2011-09-17 16:58:01 --> Loader Class Initialized
DEBUG - 2011-09-17 16:58:01 --> Controller Class Initialized
DEBUG - 2011-09-17 16:58:01 --> Model Class Initialized
DEBUG - 2011-09-17 16:58:01 --> Model Class Initialized
DEBUG - 2011-09-17 16:58:01 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-17 16:58:01 --> Database Driver Class Initialized
DEBUG - 2011-09-17 16:58:02 --> Final output sent to browser
DEBUG - 2011-09-17 16:58:02 --> Total execution time: 0.5215
DEBUG - 2011-09-17 16:58:03 --> Config Class Initialized
DEBUG - 2011-09-17 16:58:03 --> Hooks Class Initialized
DEBUG - 2011-09-17 16:58:03 --> Utf8 Class Initialized
DEBUG - 2011-09-17 16:58:03 --> UTF-8 Support Enabled
DEBUG - 2011-09-17 16:58:03 --> URI Class Initialized
DEBUG - 2011-09-17 16:58:03 --> Router Class Initialized
ERROR - 2011-09-17 16:58:03 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-09-17 16:58:08 --> Config Class Initialized
DEBUG - 2011-09-17 16:58:08 --> Hooks Class Initialized
DEBUG - 2011-09-17 16:58:08 --> Utf8 Class Initialized
DEBUG - 2011-09-17 16:58:08 --> UTF-8 Support Enabled
DEBUG - 2011-09-17 16:58:08 --> URI Class Initialized
DEBUG - 2011-09-17 16:58:08 --> Router Class Initialized
DEBUG - 2011-09-17 16:58:08 --> Output Class Initialized
DEBUG - 2011-09-17 16:58:08 --> Input Class Initialized
DEBUG - 2011-09-17 16:58:08 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-17 16:58:08 --> Language Class Initialized
DEBUG - 2011-09-17 16:58:08 --> Loader Class Initialized
DEBUG - 2011-09-17 16:58:08 --> Controller Class Initialized
ERROR - 2011-09-17 16:58:08 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-09-17 16:58:08 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-09-17 16:58:08 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-09-17 16:58:08 --> Model Class Initialized
DEBUG - 2011-09-17 16:58:08 --> Model Class Initialized
DEBUG - 2011-09-17 16:58:08 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-17 16:58:08 --> Database Driver Class Initialized
DEBUG - 2011-09-17 16:58:08 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-09-17 16:58:08 --> Helper loaded: url_helper
DEBUG - 2011-09-17 16:58:08 --> File loaded: application/views/common/header.php
DEBUG - 2011-09-17 16:58:08 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-09-17 16:58:08 --> File loaded: application/views/common/footer.php
DEBUG - 2011-09-17 16:58:08 --> File loaded: application/views/layout/main.php
DEBUG - 2011-09-17 16:58:08 --> Final output sent to browser
DEBUG - 2011-09-17 16:58:08 --> Total execution time: 0.0276
DEBUG - 2011-09-17 16:58:09 --> Config Class Initialized
DEBUG - 2011-09-17 16:58:09 --> Hooks Class Initialized
DEBUG - 2011-09-17 16:58:09 --> Utf8 Class Initialized
DEBUG - 2011-09-17 16:58:09 --> UTF-8 Support Enabled
DEBUG - 2011-09-17 16:58:09 --> URI Class Initialized
DEBUG - 2011-09-17 16:58:09 --> Router Class Initialized
DEBUG - 2011-09-17 16:58:09 --> Output Class Initialized
DEBUG - 2011-09-17 16:58:09 --> Input Class Initialized
DEBUG - 2011-09-17 16:58:09 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-17 16:58:09 --> Language Class Initialized
DEBUG - 2011-09-17 16:58:09 --> Loader Class Initialized
DEBUG - 2011-09-17 16:58:09 --> Controller Class Initialized
DEBUG - 2011-09-17 16:58:09 --> Model Class Initialized
DEBUG - 2011-09-17 16:58:09 --> Model Class Initialized
DEBUG - 2011-09-17 16:58:09 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-17 16:58:09 --> Database Driver Class Initialized
DEBUG - 2011-09-17 16:58:10 --> Final output sent to browser
DEBUG - 2011-09-17 16:58:10 --> Total execution time: 0.5436
DEBUG - 2011-09-17 16:58:11 --> Config Class Initialized
DEBUG - 2011-09-17 16:58:11 --> Hooks Class Initialized
DEBUG - 2011-09-17 16:58:11 --> Utf8 Class Initialized
DEBUG - 2011-09-17 16:58:11 --> UTF-8 Support Enabled
DEBUG - 2011-09-17 16:58:11 --> URI Class Initialized
DEBUG - 2011-09-17 16:58:11 --> Router Class Initialized
ERROR - 2011-09-17 16:58:11 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-09-17 16:58:16 --> Config Class Initialized
DEBUG - 2011-09-17 16:58:16 --> Hooks Class Initialized
DEBUG - 2011-09-17 16:58:16 --> Utf8 Class Initialized
DEBUG - 2011-09-17 16:58:16 --> UTF-8 Support Enabled
DEBUG - 2011-09-17 16:58:16 --> URI Class Initialized
DEBUG - 2011-09-17 16:58:16 --> Router Class Initialized
DEBUG - 2011-09-17 16:58:16 --> Output Class Initialized
DEBUG - 2011-09-17 16:58:16 --> Input Class Initialized
DEBUG - 2011-09-17 16:58:16 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-17 16:58:16 --> Language Class Initialized
DEBUG - 2011-09-17 16:58:16 --> Loader Class Initialized
DEBUG - 2011-09-17 16:58:16 --> Controller Class Initialized
ERROR - 2011-09-17 16:58:16 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-09-17 16:58:16 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-09-17 16:58:16 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-09-17 16:58:16 --> Model Class Initialized
DEBUG - 2011-09-17 16:58:16 --> Model Class Initialized
DEBUG - 2011-09-17 16:58:16 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-17 16:58:16 --> Database Driver Class Initialized
DEBUG - 2011-09-17 16:58:16 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-09-17 16:58:16 --> Helper loaded: url_helper
DEBUG - 2011-09-17 16:58:16 --> File loaded: application/views/common/header.php
DEBUG - 2011-09-17 16:58:16 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-09-17 16:58:16 --> File loaded: application/views/common/footer.php
DEBUG - 2011-09-17 16:58:16 --> File loaded: application/views/layout/main.php
DEBUG - 2011-09-17 16:58:16 --> Final output sent to browser
DEBUG - 2011-09-17 16:58:16 --> Total execution time: 0.0285
DEBUG - 2011-09-17 16:58:17 --> Config Class Initialized
DEBUG - 2011-09-17 16:58:17 --> Hooks Class Initialized
DEBUG - 2011-09-17 16:58:17 --> Utf8 Class Initialized
DEBUG - 2011-09-17 16:58:17 --> UTF-8 Support Enabled
DEBUG - 2011-09-17 16:58:17 --> URI Class Initialized
DEBUG - 2011-09-17 16:58:17 --> Router Class Initialized
DEBUG - 2011-09-17 16:58:17 --> Output Class Initialized
DEBUG - 2011-09-17 16:58:17 --> Input Class Initialized
DEBUG - 2011-09-17 16:58:17 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-17 16:58:17 --> Language Class Initialized
DEBUG - 2011-09-17 16:58:17 --> Loader Class Initialized
DEBUG - 2011-09-17 16:58:17 --> Controller Class Initialized
DEBUG - 2011-09-17 16:58:17 --> Model Class Initialized
DEBUG - 2011-09-17 16:58:17 --> Model Class Initialized
DEBUG - 2011-09-17 16:58:17 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-17 16:58:17 --> Database Driver Class Initialized
DEBUG - 2011-09-17 16:58:17 --> Final output sent to browser
DEBUG - 2011-09-17 16:58:17 --> Total execution time: 0.5607
DEBUG - 2011-09-17 16:58:19 --> Config Class Initialized
DEBUG - 2011-09-17 16:58:19 --> Hooks Class Initialized
DEBUG - 2011-09-17 16:58:19 --> Utf8 Class Initialized
DEBUG - 2011-09-17 16:58:19 --> UTF-8 Support Enabled
DEBUG - 2011-09-17 16:58:19 --> URI Class Initialized
DEBUG - 2011-09-17 16:58:19 --> Router Class Initialized
ERROR - 2011-09-17 16:58:19 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-09-17 16:58:24 --> Config Class Initialized
DEBUG - 2011-09-17 16:58:24 --> Hooks Class Initialized
DEBUG - 2011-09-17 16:58:24 --> Utf8 Class Initialized
DEBUG - 2011-09-17 16:58:24 --> UTF-8 Support Enabled
DEBUG - 2011-09-17 16:58:24 --> URI Class Initialized
DEBUG - 2011-09-17 16:58:24 --> Router Class Initialized
DEBUG - 2011-09-17 16:58:24 --> Output Class Initialized
DEBUG - 2011-09-17 16:58:24 --> Input Class Initialized
DEBUG - 2011-09-17 16:58:24 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-17 16:58:24 --> Language Class Initialized
DEBUG - 2011-09-17 16:58:24 --> Loader Class Initialized
DEBUG - 2011-09-17 16:58:24 --> Controller Class Initialized
ERROR - 2011-09-17 16:58:24 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-09-17 16:58:24 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-09-17 16:58:24 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-09-17 16:58:24 --> Model Class Initialized
DEBUG - 2011-09-17 16:58:24 --> Model Class Initialized
DEBUG - 2011-09-17 16:58:24 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-17 16:58:24 --> Database Driver Class Initialized
DEBUG - 2011-09-17 16:58:24 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-09-17 16:58:24 --> Helper loaded: url_helper
DEBUG - 2011-09-17 16:58:24 --> File loaded: application/views/common/header.php
DEBUG - 2011-09-17 16:58:24 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-09-17 16:58:24 --> File loaded: application/views/common/footer.php
DEBUG - 2011-09-17 16:58:24 --> File loaded: application/views/layout/main.php
DEBUG - 2011-09-17 16:58:24 --> Final output sent to browser
DEBUG - 2011-09-17 16:58:24 --> Total execution time: 0.0285
DEBUG - 2011-09-17 16:58:25 --> Config Class Initialized
DEBUG - 2011-09-17 16:58:25 --> Hooks Class Initialized
DEBUG - 2011-09-17 16:58:25 --> Utf8 Class Initialized
DEBUG - 2011-09-17 16:58:25 --> UTF-8 Support Enabled
DEBUG - 2011-09-17 16:58:25 --> URI Class Initialized
DEBUG - 2011-09-17 16:58:25 --> Router Class Initialized
DEBUG - 2011-09-17 16:58:25 --> Output Class Initialized
DEBUG - 2011-09-17 16:58:25 --> Input Class Initialized
DEBUG - 2011-09-17 16:58:25 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-17 16:58:25 --> Language Class Initialized
DEBUG - 2011-09-17 16:58:25 --> Loader Class Initialized
DEBUG - 2011-09-17 16:58:25 --> Controller Class Initialized
DEBUG - 2011-09-17 16:58:25 --> Model Class Initialized
DEBUG - 2011-09-17 16:58:25 --> Model Class Initialized
DEBUG - 2011-09-17 16:58:25 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-17 16:58:25 --> Database Driver Class Initialized
DEBUG - 2011-09-17 16:58:26 --> Final output sent to browser
DEBUG - 2011-09-17 16:58:26 --> Total execution time: 0.5444
DEBUG - 2011-09-17 16:58:27 --> Config Class Initialized
DEBUG - 2011-09-17 16:58:27 --> Hooks Class Initialized
DEBUG - 2011-09-17 16:58:27 --> Utf8 Class Initialized
DEBUG - 2011-09-17 16:58:27 --> UTF-8 Support Enabled
DEBUG - 2011-09-17 16:58:27 --> URI Class Initialized
DEBUG - 2011-09-17 16:58:27 --> Router Class Initialized
ERROR - 2011-09-17 16:58:27 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-09-17 16:58:31 --> Config Class Initialized
DEBUG - 2011-09-17 16:58:31 --> Hooks Class Initialized
DEBUG - 2011-09-17 16:58:31 --> Utf8 Class Initialized
DEBUG - 2011-09-17 16:58:31 --> UTF-8 Support Enabled
DEBUG - 2011-09-17 16:58:31 --> URI Class Initialized
DEBUG - 2011-09-17 16:58:31 --> Router Class Initialized
DEBUG - 2011-09-17 16:58:31 --> Output Class Initialized
DEBUG - 2011-09-17 16:58:31 --> Input Class Initialized
DEBUG - 2011-09-17 16:58:31 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-17 16:58:31 --> Language Class Initialized
DEBUG - 2011-09-17 16:58:31 --> Loader Class Initialized
DEBUG - 2011-09-17 16:58:31 --> Controller Class Initialized
ERROR - 2011-09-17 16:58:31 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-09-17 16:58:31 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-09-17 16:58:31 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-09-17 16:58:31 --> Model Class Initialized
DEBUG - 2011-09-17 16:58:31 --> Model Class Initialized
DEBUG - 2011-09-17 16:58:31 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-17 16:58:31 --> Database Driver Class Initialized
DEBUG - 2011-09-17 16:58:31 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-09-17 16:58:31 --> Helper loaded: url_helper
DEBUG - 2011-09-17 16:58:31 --> File loaded: application/views/common/header.php
DEBUG - 2011-09-17 16:58:31 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-09-17 16:58:31 --> File loaded: application/views/common/footer.php
DEBUG - 2011-09-17 16:58:31 --> File loaded: application/views/layout/main.php
DEBUG - 2011-09-17 16:58:31 --> Final output sent to browser
DEBUG - 2011-09-17 16:58:31 --> Total execution time: 0.0270
DEBUG - 2011-09-17 16:58:35 --> Config Class Initialized
DEBUG - 2011-09-17 16:58:35 --> Hooks Class Initialized
DEBUG - 2011-09-17 16:58:35 --> Utf8 Class Initialized
DEBUG - 2011-09-17 16:58:35 --> UTF-8 Support Enabled
DEBUG - 2011-09-17 16:58:35 --> URI Class Initialized
DEBUG - 2011-09-17 16:58:35 --> Router Class Initialized
DEBUG - 2011-09-17 16:58:35 --> Output Class Initialized
DEBUG - 2011-09-17 16:58:36 --> Input Class Initialized
DEBUG - 2011-09-17 16:58:36 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-17 16:58:36 --> Language Class Initialized
DEBUG - 2011-09-17 16:58:36 --> Loader Class Initialized
DEBUG - 2011-09-17 16:58:36 --> Controller Class Initialized
ERROR - 2011-09-17 16:58:36 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-09-17 16:58:36 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-09-17 16:58:36 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-09-17 16:58:36 --> Model Class Initialized
DEBUG - 2011-09-17 16:58:36 --> Model Class Initialized
DEBUG - 2011-09-17 16:58:36 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-17 16:58:36 --> Database Driver Class Initialized
DEBUG - 2011-09-17 16:58:36 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-09-17 16:58:36 --> Helper loaded: url_helper
DEBUG - 2011-09-17 16:58:36 --> File loaded: application/views/common/header.php
DEBUG - 2011-09-17 16:58:36 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-09-17 16:58:36 --> File loaded: application/views/common/footer.php
DEBUG - 2011-09-17 16:58:36 --> File loaded: application/views/layout/main.php
DEBUG - 2011-09-17 16:58:36 --> Final output sent to browser
DEBUG - 2011-09-17 16:58:36 --> Total execution time: 0.0278
DEBUG - 2011-09-17 16:58:36 --> Config Class Initialized
DEBUG - 2011-09-17 16:58:36 --> Hooks Class Initialized
DEBUG - 2011-09-17 16:58:36 --> Utf8 Class Initialized
DEBUG - 2011-09-17 16:58:36 --> UTF-8 Support Enabled
DEBUG - 2011-09-17 16:58:36 --> URI Class Initialized
DEBUG - 2011-09-17 16:58:36 --> Router Class Initialized
DEBUG - 2011-09-17 16:58:36 --> Output Class Initialized
DEBUG - 2011-09-17 16:58:36 --> Input Class Initialized
DEBUG - 2011-09-17 16:58:36 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-17 16:58:36 --> Language Class Initialized
DEBUG - 2011-09-17 16:58:36 --> Loader Class Initialized
DEBUG - 2011-09-17 16:58:36 --> Controller Class Initialized
DEBUG - 2011-09-17 16:58:36 --> Model Class Initialized
DEBUG - 2011-09-17 16:58:36 --> Model Class Initialized
DEBUG - 2011-09-17 16:58:36 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-17 16:58:36 --> Database Driver Class Initialized
DEBUG - 2011-09-17 16:58:37 --> Final output sent to browser
DEBUG - 2011-09-17 16:58:37 --> Total execution time: 0.5836
DEBUG - 2011-09-17 16:58:38 --> Config Class Initialized
DEBUG - 2011-09-17 16:58:38 --> Hooks Class Initialized
DEBUG - 2011-09-17 16:58:38 --> Utf8 Class Initialized
DEBUG - 2011-09-17 16:58:38 --> UTF-8 Support Enabled
DEBUG - 2011-09-17 16:58:38 --> URI Class Initialized
DEBUG - 2011-09-17 16:58:38 --> Router Class Initialized
ERROR - 2011-09-17 16:58:38 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-09-17 16:58:51 --> Config Class Initialized
DEBUG - 2011-09-17 16:58:51 --> Hooks Class Initialized
DEBUG - 2011-09-17 16:58:51 --> Utf8 Class Initialized
DEBUG - 2011-09-17 16:58:51 --> UTF-8 Support Enabled
DEBUG - 2011-09-17 16:58:51 --> URI Class Initialized
DEBUG - 2011-09-17 16:58:51 --> Router Class Initialized
DEBUG - 2011-09-17 16:58:51 --> Output Class Initialized
DEBUG - 2011-09-17 16:58:51 --> Input Class Initialized
DEBUG - 2011-09-17 16:58:51 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-17 16:58:51 --> Language Class Initialized
DEBUG - 2011-09-17 16:58:51 --> Loader Class Initialized
DEBUG - 2011-09-17 16:58:51 --> Controller Class Initialized
ERROR - 2011-09-17 16:58:51 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-09-17 16:58:51 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-09-17 16:58:51 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-09-17 16:58:51 --> Model Class Initialized
DEBUG - 2011-09-17 16:58:51 --> Model Class Initialized
DEBUG - 2011-09-17 16:58:51 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-17 16:58:51 --> Database Driver Class Initialized
DEBUG - 2011-09-17 16:58:51 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-09-17 16:58:51 --> Helper loaded: url_helper
DEBUG - 2011-09-17 16:58:51 --> File loaded: application/views/common/header.php
DEBUG - 2011-09-17 16:58:51 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-09-17 16:58:51 --> File loaded: application/views/common/footer.php
DEBUG - 2011-09-17 16:58:51 --> File loaded: application/views/layout/main.php
DEBUG - 2011-09-17 16:58:51 --> Final output sent to browser
DEBUG - 2011-09-17 16:58:51 --> Total execution time: 0.0301
DEBUG - 2011-09-17 16:58:52 --> Config Class Initialized
DEBUG - 2011-09-17 16:58:52 --> Hooks Class Initialized
DEBUG - 2011-09-17 16:58:52 --> Utf8 Class Initialized
DEBUG - 2011-09-17 16:58:52 --> UTF-8 Support Enabled
DEBUG - 2011-09-17 16:58:52 --> URI Class Initialized
DEBUG - 2011-09-17 16:58:52 --> Router Class Initialized
DEBUG - 2011-09-17 16:58:52 --> Output Class Initialized
DEBUG - 2011-09-17 16:58:52 --> Input Class Initialized
DEBUG - 2011-09-17 16:58:52 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-17 16:58:52 --> Language Class Initialized
DEBUG - 2011-09-17 16:58:52 --> Loader Class Initialized
DEBUG - 2011-09-17 16:58:52 --> Controller Class Initialized
DEBUG - 2011-09-17 16:58:52 --> Model Class Initialized
DEBUG - 2011-09-17 16:58:52 --> Model Class Initialized
DEBUG - 2011-09-17 16:58:52 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-17 16:58:52 --> Database Driver Class Initialized
DEBUG - 2011-09-17 16:58:53 --> Final output sent to browser
DEBUG - 2011-09-17 16:58:53 --> Total execution time: 0.6738
DEBUG - 2011-09-17 16:58:54 --> Config Class Initialized
DEBUG - 2011-09-17 16:58:54 --> Hooks Class Initialized
DEBUG - 2011-09-17 16:58:54 --> Utf8 Class Initialized
DEBUG - 2011-09-17 16:58:54 --> UTF-8 Support Enabled
DEBUG - 2011-09-17 16:58:54 --> URI Class Initialized
DEBUG - 2011-09-17 16:58:54 --> Router Class Initialized
ERROR - 2011-09-17 16:58:54 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-09-17 16:59:10 --> Config Class Initialized
DEBUG - 2011-09-17 16:59:10 --> Hooks Class Initialized
DEBUG - 2011-09-17 16:59:10 --> Utf8 Class Initialized
DEBUG - 2011-09-17 16:59:10 --> UTF-8 Support Enabled
DEBUG - 2011-09-17 16:59:10 --> URI Class Initialized
DEBUG - 2011-09-17 16:59:10 --> Router Class Initialized
DEBUG - 2011-09-17 16:59:10 --> Output Class Initialized
DEBUG - 2011-09-17 16:59:10 --> Input Class Initialized
DEBUG - 2011-09-17 16:59:10 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-17 16:59:10 --> Language Class Initialized
DEBUG - 2011-09-17 16:59:10 --> Loader Class Initialized
DEBUG - 2011-09-17 16:59:10 --> Controller Class Initialized
ERROR - 2011-09-17 16:59:10 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-09-17 16:59:10 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-09-17 16:59:10 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-09-17 16:59:10 --> Model Class Initialized
DEBUG - 2011-09-17 16:59:10 --> Model Class Initialized
DEBUG - 2011-09-17 16:59:10 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-17 16:59:10 --> Database Driver Class Initialized
DEBUG - 2011-09-17 16:59:10 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-09-17 16:59:10 --> Helper loaded: url_helper
DEBUG - 2011-09-17 16:59:10 --> File loaded: application/views/common/header.php
DEBUG - 2011-09-17 16:59:10 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-09-17 16:59:10 --> File loaded: application/views/common/footer.php
DEBUG - 2011-09-17 16:59:10 --> File loaded: application/views/layout/main.php
DEBUG - 2011-09-17 16:59:10 --> Final output sent to browser
DEBUG - 2011-09-17 16:59:10 --> Total execution time: 0.0269
DEBUG - 2011-09-17 16:59:11 --> Config Class Initialized
DEBUG - 2011-09-17 16:59:11 --> Hooks Class Initialized
DEBUG - 2011-09-17 16:59:11 --> Utf8 Class Initialized
DEBUG - 2011-09-17 16:59:11 --> UTF-8 Support Enabled
DEBUG - 2011-09-17 16:59:11 --> URI Class Initialized
DEBUG - 2011-09-17 16:59:11 --> Router Class Initialized
DEBUG - 2011-09-17 16:59:11 --> Output Class Initialized
DEBUG - 2011-09-17 16:59:11 --> Input Class Initialized
DEBUG - 2011-09-17 16:59:11 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-17 16:59:11 --> Language Class Initialized
DEBUG - 2011-09-17 16:59:11 --> Loader Class Initialized
DEBUG - 2011-09-17 16:59:11 --> Controller Class Initialized
DEBUG - 2011-09-17 16:59:11 --> Model Class Initialized
DEBUG - 2011-09-17 16:59:11 --> Model Class Initialized
DEBUG - 2011-09-17 16:59:11 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-17 16:59:11 --> Database Driver Class Initialized
DEBUG - 2011-09-17 16:59:12 --> Final output sent to browser
DEBUG - 2011-09-17 16:59:12 --> Total execution time: 0.5838
DEBUG - 2011-09-17 16:59:13 --> Config Class Initialized
DEBUG - 2011-09-17 16:59:13 --> Hooks Class Initialized
DEBUG - 2011-09-17 16:59:13 --> Utf8 Class Initialized
DEBUG - 2011-09-17 16:59:13 --> UTF-8 Support Enabled
DEBUG - 2011-09-17 16:59:13 --> URI Class Initialized
DEBUG - 2011-09-17 16:59:13 --> Router Class Initialized
ERROR - 2011-09-17 16:59:13 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-09-17 16:59:20 --> Config Class Initialized
DEBUG - 2011-09-17 16:59:20 --> Hooks Class Initialized
DEBUG - 2011-09-17 16:59:20 --> Utf8 Class Initialized
DEBUG - 2011-09-17 16:59:20 --> UTF-8 Support Enabled
DEBUG - 2011-09-17 16:59:20 --> URI Class Initialized
DEBUG - 2011-09-17 16:59:20 --> Router Class Initialized
DEBUG - 2011-09-17 16:59:20 --> Output Class Initialized
DEBUG - 2011-09-17 16:59:20 --> Input Class Initialized
DEBUG - 2011-09-17 16:59:20 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-17 16:59:20 --> Language Class Initialized
DEBUG - 2011-09-17 16:59:20 --> Loader Class Initialized
DEBUG - 2011-09-17 16:59:20 --> Controller Class Initialized
ERROR - 2011-09-17 16:59:20 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-09-17 16:59:20 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-09-17 16:59:20 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-09-17 16:59:20 --> Model Class Initialized
DEBUG - 2011-09-17 16:59:20 --> Model Class Initialized
DEBUG - 2011-09-17 16:59:20 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-17 16:59:20 --> Database Driver Class Initialized
DEBUG - 2011-09-17 16:59:20 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-09-17 16:59:20 --> Helper loaded: url_helper
DEBUG - 2011-09-17 16:59:20 --> File loaded: application/views/common/header.php
DEBUG - 2011-09-17 16:59:20 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-09-17 16:59:20 --> File loaded: application/views/common/footer.php
DEBUG - 2011-09-17 16:59:20 --> File loaded: application/views/layout/main.php
DEBUG - 2011-09-17 16:59:20 --> Final output sent to browser
DEBUG - 2011-09-17 16:59:20 --> Total execution time: 0.0296
DEBUG - 2011-09-17 16:59:20 --> Config Class Initialized
DEBUG - 2011-09-17 16:59:20 --> Hooks Class Initialized
DEBUG - 2011-09-17 16:59:20 --> Utf8 Class Initialized
DEBUG - 2011-09-17 16:59:20 --> UTF-8 Support Enabled
DEBUG - 2011-09-17 16:59:20 --> URI Class Initialized
DEBUG - 2011-09-17 16:59:20 --> Router Class Initialized
DEBUG - 2011-09-17 16:59:20 --> Output Class Initialized
DEBUG - 2011-09-17 16:59:20 --> Input Class Initialized
DEBUG - 2011-09-17 16:59:20 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-17 16:59:20 --> Language Class Initialized
DEBUG - 2011-09-17 16:59:20 --> Loader Class Initialized
DEBUG - 2011-09-17 16:59:20 --> Controller Class Initialized
DEBUG - 2011-09-17 16:59:20 --> Model Class Initialized
DEBUG - 2011-09-17 16:59:20 --> Model Class Initialized
DEBUG - 2011-09-17 16:59:20 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-17 16:59:20 --> Database Driver Class Initialized
DEBUG - 2011-09-17 16:59:21 --> Final output sent to browser
DEBUG - 2011-09-17 16:59:21 --> Total execution time: 0.5080
DEBUG - 2011-09-17 16:59:22 --> Config Class Initialized
DEBUG - 2011-09-17 16:59:22 --> Hooks Class Initialized
DEBUG - 2011-09-17 16:59:22 --> Utf8 Class Initialized
DEBUG - 2011-09-17 16:59:22 --> UTF-8 Support Enabled
DEBUG - 2011-09-17 16:59:22 --> URI Class Initialized
DEBUG - 2011-09-17 16:59:22 --> Router Class Initialized
ERROR - 2011-09-17 16:59:22 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-09-17 17:16:25 --> Config Class Initialized
DEBUG - 2011-09-17 17:16:25 --> Hooks Class Initialized
DEBUG - 2011-09-17 17:16:25 --> Utf8 Class Initialized
DEBUG - 2011-09-17 17:16:25 --> UTF-8 Support Enabled
DEBUG - 2011-09-17 17:16:25 --> URI Class Initialized
DEBUG - 2011-09-17 17:16:25 --> Router Class Initialized
DEBUG - 2011-09-17 17:16:25 --> Output Class Initialized
DEBUG - 2011-09-17 17:16:25 --> Input Class Initialized
DEBUG - 2011-09-17 17:16:25 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-17 17:16:25 --> Language Class Initialized
DEBUG - 2011-09-17 17:16:25 --> Loader Class Initialized
DEBUG - 2011-09-17 17:16:25 --> Controller Class Initialized
DEBUG - 2011-09-17 17:16:25 --> Model Class Initialized
DEBUG - 2011-09-17 17:16:25 --> Model Class Initialized
DEBUG - 2011-09-17 17:16:25 --> Model Class Initialized
DEBUG - 2011-09-17 17:16:25 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-17 17:16:25 --> Database Driver Class Initialized
DEBUG - 2011-09-17 17:16:26 --> File loaded: application/views/table/main.php
DEBUG - 2011-09-17 17:16:26 --> Helper loaded: url_helper
DEBUG - 2011-09-17 17:16:26 --> File loaded: application/views/common/header.php
DEBUG - 2011-09-17 17:16:26 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-09-17 17:16:26 --> File loaded: application/views/common/footer.php
DEBUG - 2011-09-17 17:16:26 --> File loaded: application/views/layout/main.php
DEBUG - 2011-09-17 17:16:26 --> Final output sent to browser
DEBUG - 2011-09-17 17:16:26 --> Total execution time: 0.6955
DEBUG - 2011-09-17 17:16:39 --> Config Class Initialized
DEBUG - 2011-09-17 17:16:39 --> Hooks Class Initialized
DEBUG - 2011-09-17 17:16:39 --> Utf8 Class Initialized
DEBUG - 2011-09-17 17:16:39 --> UTF-8 Support Enabled
DEBUG - 2011-09-17 17:16:39 --> URI Class Initialized
DEBUG - 2011-09-17 17:16:39 --> Router Class Initialized
ERROR - 2011-09-17 17:16:39 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-09-17 17:16:49 --> Config Class Initialized
DEBUG - 2011-09-17 17:16:49 --> Hooks Class Initialized
DEBUG - 2011-09-17 17:16:49 --> Utf8 Class Initialized
DEBUG - 2011-09-17 17:16:49 --> UTF-8 Support Enabled
DEBUG - 2011-09-17 17:16:49 --> URI Class Initialized
DEBUG - 2011-09-17 17:16:49 --> Router Class Initialized
DEBUG - 2011-09-17 17:16:49 --> Output Class Initialized
DEBUG - 2011-09-17 17:16:49 --> Input Class Initialized
DEBUG - 2011-09-17 17:16:49 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-17 17:16:49 --> Language Class Initialized
DEBUG - 2011-09-17 17:16:49 --> Loader Class Initialized
DEBUG - 2011-09-17 17:16:49 --> Controller Class Initialized
DEBUG - 2011-09-17 17:16:49 --> Model Class Initialized
DEBUG - 2011-09-17 17:16:49 --> Model Class Initialized
DEBUG - 2011-09-17 17:16:49 --> Model Class Initialized
DEBUG - 2011-09-17 17:16:49 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-17 17:16:49 --> Database Driver Class Initialized
DEBUG - 2011-09-17 17:16:50 --> File loaded: application/views/table/main.php
DEBUG - 2011-09-17 17:16:50 --> Helper loaded: url_helper
DEBUG - 2011-09-17 17:16:50 --> File loaded: application/views/common/header.php
DEBUG - 2011-09-17 17:16:50 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-09-17 17:16:50 --> File loaded: application/views/common/footer.php
DEBUG - 2011-09-17 17:16:50 --> File loaded: application/views/layout/main.php
DEBUG - 2011-09-17 17:16:50 --> Final output sent to browser
DEBUG - 2011-09-17 17:16:50 --> Total execution time: 0.3350
DEBUG - 2011-09-17 17:16:53 --> Config Class Initialized
DEBUG - 2011-09-17 17:16:53 --> Hooks Class Initialized
DEBUG - 2011-09-17 17:16:53 --> Utf8 Class Initialized
DEBUG - 2011-09-17 17:16:53 --> UTF-8 Support Enabled
DEBUG - 2011-09-17 17:16:53 --> URI Class Initialized
DEBUG - 2011-09-17 17:16:53 --> Router Class Initialized
ERROR - 2011-09-17 17:16:53 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-09-17 17:17:08 --> Config Class Initialized
DEBUG - 2011-09-17 17:17:08 --> Hooks Class Initialized
DEBUG - 2011-09-17 17:17:08 --> Utf8 Class Initialized
DEBUG - 2011-09-17 17:17:08 --> UTF-8 Support Enabled
DEBUG - 2011-09-17 17:17:08 --> URI Class Initialized
DEBUG - 2011-09-17 17:17:08 --> Router Class Initialized
DEBUG - 2011-09-17 17:17:08 --> Output Class Initialized
DEBUG - 2011-09-17 17:17:08 --> Input Class Initialized
DEBUG - 2011-09-17 17:17:08 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-17 17:17:08 --> Language Class Initialized
DEBUG - 2011-09-17 17:17:08 --> Loader Class Initialized
DEBUG - 2011-09-17 17:17:08 --> Controller Class Initialized
DEBUG - 2011-09-17 17:17:08 --> Model Class Initialized
DEBUG - 2011-09-17 17:17:08 --> Model Class Initialized
DEBUG - 2011-09-17 17:17:08 --> Model Class Initialized
DEBUG - 2011-09-17 17:17:08 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-17 17:17:08 --> Database Driver Class Initialized
DEBUG - 2011-09-17 17:17:08 --> File loaded: application/views/table/main.php
DEBUG - 2011-09-17 17:17:08 --> Helper loaded: url_helper
DEBUG - 2011-09-17 17:17:08 --> File loaded: application/views/common/header.php
DEBUG - 2011-09-17 17:17:08 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-09-17 17:17:08 --> File loaded: application/views/common/footer.php
DEBUG - 2011-09-17 17:17:08 --> File loaded: application/views/layout/main.php
DEBUG - 2011-09-17 17:17:08 --> Final output sent to browser
DEBUG - 2011-09-17 17:17:08 --> Total execution time: 0.2465
DEBUG - 2011-09-17 17:17:13 --> Config Class Initialized
DEBUG - 2011-09-17 17:17:13 --> Hooks Class Initialized
DEBUG - 2011-09-17 17:17:13 --> Utf8 Class Initialized
DEBUG - 2011-09-17 17:17:13 --> UTF-8 Support Enabled
DEBUG - 2011-09-17 17:17:13 --> URI Class Initialized
DEBUG - 2011-09-17 17:17:13 --> Router Class Initialized
DEBUG - 2011-09-17 17:17:13 --> Output Class Initialized
DEBUG - 2011-09-17 17:17:13 --> Input Class Initialized
DEBUG - 2011-09-17 17:17:13 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-17 17:17:13 --> Language Class Initialized
DEBUG - 2011-09-17 17:17:13 --> Loader Class Initialized
DEBUG - 2011-09-17 17:17:13 --> Controller Class Initialized
DEBUG - 2011-09-17 17:17:13 --> Model Class Initialized
DEBUG - 2011-09-17 17:17:13 --> Model Class Initialized
DEBUG - 2011-09-17 17:17:13 --> Model Class Initialized
DEBUG - 2011-09-17 17:17:13 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-17 17:17:13 --> Database Driver Class Initialized
DEBUG - 2011-09-17 17:17:13 --> File loaded: application/views/table/main.php
DEBUG - 2011-09-17 17:17:13 --> Helper loaded: url_helper
DEBUG - 2011-09-17 17:17:13 --> File loaded: application/views/common/header.php
DEBUG - 2011-09-17 17:17:13 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-09-17 17:17:13 --> File loaded: application/views/common/footer.php
DEBUG - 2011-09-17 17:17:13 --> File loaded: application/views/layout/main.php
DEBUG - 2011-09-17 17:17:13 --> Final output sent to browser
DEBUG - 2011-09-17 17:17:13 --> Total execution time: 0.0668
DEBUG - 2011-09-17 17:17:13 --> Config Class Initialized
DEBUG - 2011-09-17 17:17:13 --> Hooks Class Initialized
DEBUG - 2011-09-17 17:17:13 --> Utf8 Class Initialized
DEBUG - 2011-09-17 17:17:13 --> UTF-8 Support Enabled
DEBUG - 2011-09-17 17:17:13 --> URI Class Initialized
DEBUG - 2011-09-17 17:17:13 --> Router Class Initialized
ERROR - 2011-09-17 17:17:13 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-09-17 17:29:03 --> Config Class Initialized
DEBUG - 2011-09-17 17:29:03 --> Hooks Class Initialized
DEBUG - 2011-09-17 17:29:03 --> Utf8 Class Initialized
DEBUG - 2011-09-17 17:29:03 --> UTF-8 Support Enabled
DEBUG - 2011-09-17 17:29:03 --> URI Class Initialized
DEBUG - 2011-09-17 17:29:03 --> Router Class Initialized
ERROR - 2011-09-17 17:29:03 --> 404 Page Not Found --> robots.txt
DEBUG - 2011-09-17 18:15:17 --> Config Class Initialized
DEBUG - 2011-09-17 18:15:17 --> Hooks Class Initialized
DEBUG - 2011-09-17 18:15:17 --> Utf8 Class Initialized
DEBUG - 2011-09-17 18:15:17 --> UTF-8 Support Enabled
DEBUG - 2011-09-17 18:15:17 --> URI Class Initialized
DEBUG - 2011-09-17 18:15:17 --> Router Class Initialized
ERROR - 2011-09-17 18:15:17 --> 404 Page Not Found --> robots.txt
DEBUG - 2011-09-17 18:15:17 --> Config Class Initialized
DEBUG - 2011-09-17 18:15:17 --> Hooks Class Initialized
DEBUG - 2011-09-17 18:15:17 --> Utf8 Class Initialized
DEBUG - 2011-09-17 18:15:17 --> UTF-8 Support Enabled
DEBUG - 2011-09-17 18:15:17 --> URI Class Initialized
DEBUG - 2011-09-17 18:15:17 --> Router Class Initialized
DEBUG - 2011-09-17 18:15:17 --> No URI present. Default controller set.
DEBUG - 2011-09-17 18:15:17 --> Output Class Initialized
DEBUG - 2011-09-17 18:15:17 --> Input Class Initialized
DEBUG - 2011-09-17 18:15:17 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-17 18:15:17 --> Language Class Initialized
DEBUG - 2011-09-17 18:15:17 --> Loader Class Initialized
DEBUG - 2011-09-17 18:15:17 --> Controller Class Initialized
DEBUG - 2011-09-17 18:15:17 --> File loaded: application/views/splash/main.php
DEBUG - 2011-09-17 18:15:17 --> Helper loaded: url_helper
DEBUG - 2011-09-17 18:15:17 --> File loaded: application/views/common/header.php
DEBUG - 2011-09-17 18:15:17 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-09-17 18:15:17 --> File loaded: application/views/common/footer.php
DEBUG - 2011-09-17 18:15:17 --> File loaded: application/views/layout/main.php
DEBUG - 2011-09-17 18:15:17 --> Final output sent to browser
DEBUG - 2011-09-17 18:15:17 --> Total execution time: 0.1457
DEBUG - 2011-09-17 20:12:21 --> Config Class Initialized
DEBUG - 2011-09-17 20:12:21 --> Hooks Class Initialized
DEBUG - 2011-09-17 20:12:21 --> Utf8 Class Initialized
DEBUG - 2011-09-17 20:12:21 --> UTF-8 Support Enabled
DEBUG - 2011-09-17 20:12:21 --> URI Class Initialized
DEBUG - 2011-09-17 20:12:21 --> Router Class Initialized
DEBUG - 2011-09-17 20:12:21 --> Output Class Initialized
DEBUG - 2011-09-17 20:12:21 --> Input Class Initialized
DEBUG - 2011-09-17 20:12:21 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-17 20:12:21 --> Language Class Initialized
DEBUG - 2011-09-17 20:12:21 --> Loader Class Initialized
DEBUG - 2011-09-17 20:12:21 --> Controller Class Initialized
DEBUG - 2011-09-17 20:12:21 --> Model Class Initialized
DEBUG - 2011-09-17 20:12:21 --> Model Class Initialized
DEBUG - 2011-09-17 20:12:21 --> Model Class Initialized
DEBUG - 2011-09-17 20:12:21 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-17 20:12:21 --> Database Driver Class Initialized
DEBUG - 2011-09-17 20:12:22 --> File loaded: application/views/table/main.php
DEBUG - 2011-09-17 20:12:22 --> Helper loaded: url_helper
DEBUG - 2011-09-17 20:12:22 --> File loaded: application/views/common/header.php
DEBUG - 2011-09-17 20:12:22 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-09-17 20:12:22 --> File loaded: application/views/common/footer.php
DEBUG - 2011-09-17 20:12:22 --> File loaded: application/views/layout/main.php
DEBUG - 2011-09-17 20:12:22 --> Final output sent to browser
DEBUG - 2011-09-17 20:12:22 --> Total execution time: 1.2638
DEBUG - 2011-09-17 20:30:42 --> Config Class Initialized
DEBUG - 2011-09-17 20:30:42 --> Hooks Class Initialized
DEBUG - 2011-09-17 20:30:42 --> Utf8 Class Initialized
DEBUG - 2011-09-17 20:30:42 --> UTF-8 Support Enabled
DEBUG - 2011-09-17 20:30:42 --> URI Class Initialized
DEBUG - 2011-09-17 20:30:42 --> Router Class Initialized
DEBUG - 2011-09-17 20:30:42 --> No URI present. Default controller set.
DEBUG - 2011-09-17 20:30:42 --> Output Class Initialized
DEBUG - 2011-09-17 20:30:42 --> Input Class Initialized
DEBUG - 2011-09-17 20:30:42 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-17 20:30:42 --> Language Class Initialized
DEBUG - 2011-09-17 20:30:42 --> Loader Class Initialized
DEBUG - 2011-09-17 20:30:42 --> Controller Class Initialized
DEBUG - 2011-09-17 20:30:42 --> File loaded: application/views/splash/main.php
DEBUG - 2011-09-17 20:30:42 --> Helper loaded: url_helper
DEBUG - 2011-09-17 20:30:42 --> File loaded: application/views/common/header.php
DEBUG - 2011-09-17 20:30:42 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-09-17 20:30:42 --> File loaded: application/views/common/footer.php
DEBUG - 2011-09-17 20:30:42 --> File loaded: application/views/layout/main.php
DEBUG - 2011-09-17 20:30:42 --> Final output sent to browser
DEBUG - 2011-09-17 20:30:42 --> Total execution time: 0.0295
DEBUG - 2011-09-17 20:50:12 --> Config Class Initialized
DEBUG - 2011-09-17 20:50:12 --> Hooks Class Initialized
DEBUG - 2011-09-17 20:50:12 --> Utf8 Class Initialized
DEBUG - 2011-09-17 20:50:12 --> UTF-8 Support Enabled
DEBUG - 2011-09-17 20:50:12 --> URI Class Initialized
DEBUG - 2011-09-17 20:50:12 --> Router Class Initialized
DEBUG - 2011-09-17 20:50:12 --> No URI present. Default controller set.
DEBUG - 2011-09-17 20:50:12 --> Output Class Initialized
DEBUG - 2011-09-17 20:50:12 --> Input Class Initialized
DEBUG - 2011-09-17 20:50:12 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-17 20:50:12 --> Language Class Initialized
DEBUG - 2011-09-17 20:50:12 --> Loader Class Initialized
DEBUG - 2011-09-17 20:50:12 --> Controller Class Initialized
DEBUG - 2011-09-17 20:50:12 --> File loaded: application/views/splash/main.php
DEBUG - 2011-09-17 20:50:12 --> Helper loaded: url_helper
DEBUG - 2011-09-17 20:50:12 --> File loaded: application/views/common/header.php
DEBUG - 2011-09-17 20:50:12 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-09-17 20:50:12 --> File loaded: application/views/common/footer.php
DEBUG - 2011-09-17 20:50:12 --> File loaded: application/views/layout/main.php
DEBUG - 2011-09-17 20:50:12 --> Final output sent to browser
DEBUG - 2011-09-17 20:50:12 --> Total execution time: 0.0135
DEBUG - 2011-09-17 21:51:26 --> Config Class Initialized
DEBUG - 2011-09-17 21:51:26 --> Hooks Class Initialized
DEBUG - 2011-09-17 21:51:26 --> Utf8 Class Initialized
DEBUG - 2011-09-17 21:51:26 --> UTF-8 Support Enabled
DEBUG - 2011-09-17 21:51:26 --> URI Class Initialized
DEBUG - 2011-09-17 21:51:26 --> Router Class Initialized
DEBUG - 2011-09-17 21:51:26 --> Output Class Initialized
DEBUG - 2011-09-17 21:51:26 --> Input Class Initialized
DEBUG - 2011-09-17 21:51:26 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-17 21:51:26 --> Language Class Initialized
DEBUG - 2011-09-17 21:51:26 --> Loader Class Initialized
DEBUG - 2011-09-17 21:51:26 --> Controller Class Initialized
DEBUG - 2011-09-17 21:51:26 --> Model Class Initialized
DEBUG - 2011-09-17 21:51:26 --> Model Class Initialized
DEBUG - 2011-09-17 21:51:26 --> Model Class Initialized
DEBUG - 2011-09-17 21:51:26 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-17 21:51:26 --> Database Driver Class Initialized
DEBUG - 2011-09-17 21:51:27 --> File loaded: application/views/table/main.php
DEBUG - 2011-09-17 21:51:27 --> Helper loaded: url_helper
DEBUG - 2011-09-17 21:51:27 --> File loaded: application/views/common/header.php
DEBUG - 2011-09-17 21:51:27 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-09-17 21:51:27 --> File loaded: application/views/common/footer.php
DEBUG - 2011-09-17 21:51:27 --> File loaded: application/views/layout/main.php
DEBUG - 2011-09-17 21:51:27 --> Final output sent to browser
DEBUG - 2011-09-17 21:51:27 --> Total execution time: 0.6508
DEBUG - 2011-09-17 21:51:32 --> Config Class Initialized
DEBUG - 2011-09-17 21:51:32 --> Hooks Class Initialized
DEBUG - 2011-09-17 21:51:32 --> Utf8 Class Initialized
DEBUG - 2011-09-17 21:51:32 --> UTF-8 Support Enabled
DEBUG - 2011-09-17 21:51:32 --> URI Class Initialized
DEBUG - 2011-09-17 21:51:32 --> Router Class Initialized
ERROR - 2011-09-17 21:51:32 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-09-17 21:51:45 --> Config Class Initialized
DEBUG - 2011-09-17 21:51:45 --> Hooks Class Initialized
DEBUG - 2011-09-17 21:51:45 --> Utf8 Class Initialized
DEBUG - 2011-09-17 21:51:45 --> UTF-8 Support Enabled
DEBUG - 2011-09-17 21:51:45 --> URI Class Initialized
DEBUG - 2011-09-17 21:51:45 --> Router Class Initialized
DEBUG - 2011-09-17 21:51:45 --> Output Class Initialized
DEBUG - 2011-09-17 21:51:45 --> Input Class Initialized
DEBUG - 2011-09-17 21:51:45 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-17 21:51:45 --> Language Class Initialized
DEBUG - 2011-09-17 21:51:45 --> Loader Class Initialized
DEBUG - 2011-09-17 21:51:45 --> Controller Class Initialized
ERROR - 2011-09-17 21:51:45 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-09-17 21:51:45 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-09-17 21:51:45 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-09-17 21:51:45 --> Model Class Initialized
DEBUG - 2011-09-17 21:51:45 --> Model Class Initialized
DEBUG - 2011-09-17 21:51:45 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-17 21:51:45 --> Database Driver Class Initialized
DEBUG - 2011-09-17 21:51:45 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-09-17 21:51:45 --> Helper loaded: url_helper
DEBUG - 2011-09-17 21:51:45 --> File loaded: application/views/common/header.php
DEBUG - 2011-09-17 21:51:45 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-09-17 21:51:45 --> File loaded: application/views/common/footer.php
DEBUG - 2011-09-17 21:51:45 --> File loaded: application/views/layout/main.php
DEBUG - 2011-09-17 21:51:45 --> Final output sent to browser
DEBUG - 2011-09-17 21:51:45 --> Total execution time: 0.1238
DEBUG - 2011-09-17 21:51:46 --> Config Class Initialized
DEBUG - 2011-09-17 21:51:46 --> Hooks Class Initialized
DEBUG - 2011-09-17 21:51:46 --> Utf8 Class Initialized
DEBUG - 2011-09-17 21:51:46 --> UTF-8 Support Enabled
DEBUG - 2011-09-17 21:51:46 --> URI Class Initialized
DEBUG - 2011-09-17 21:51:46 --> Router Class Initialized
DEBUG - 2011-09-17 21:51:46 --> Output Class Initialized
DEBUG - 2011-09-17 21:51:46 --> Input Class Initialized
DEBUG - 2011-09-17 21:51:46 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-17 21:51:46 --> Language Class Initialized
DEBUG - 2011-09-17 21:51:46 --> Loader Class Initialized
DEBUG - 2011-09-17 21:51:46 --> Controller Class Initialized
DEBUG - 2011-09-17 21:51:46 --> Model Class Initialized
DEBUG - 2011-09-17 21:51:46 --> Model Class Initialized
DEBUG - 2011-09-17 21:51:46 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-17 21:51:46 --> Database Driver Class Initialized
DEBUG - 2011-09-17 21:51:47 --> Final output sent to browser
DEBUG - 2011-09-17 21:51:47 --> Total execution time: 0.6237
DEBUG - 2011-09-17 21:51:52 --> Config Class Initialized
DEBUG - 2011-09-17 21:51:52 --> Hooks Class Initialized
DEBUG - 2011-09-17 21:51:52 --> Utf8 Class Initialized
DEBUG - 2011-09-17 21:51:52 --> UTF-8 Support Enabled
DEBUG - 2011-09-17 21:51:52 --> URI Class Initialized
DEBUG - 2011-09-17 21:51:52 --> Router Class Initialized
ERROR - 2011-09-17 21:51:52 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-09-17 21:52:02 --> Config Class Initialized
DEBUG - 2011-09-17 21:52:02 --> Hooks Class Initialized
DEBUG - 2011-09-17 21:52:02 --> Utf8 Class Initialized
DEBUG - 2011-09-17 21:52:02 --> UTF-8 Support Enabled
DEBUG - 2011-09-17 21:52:02 --> URI Class Initialized
DEBUG - 2011-09-17 21:52:02 --> Router Class Initialized
DEBUG - 2011-09-17 21:52:02 --> Output Class Initialized
DEBUG - 2011-09-17 21:52:02 --> Input Class Initialized
DEBUG - 2011-09-17 21:52:02 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-17 21:52:02 --> Language Class Initialized
DEBUG - 2011-09-17 21:52:02 --> Loader Class Initialized
DEBUG - 2011-09-17 21:52:02 --> Controller Class Initialized
ERROR - 2011-09-17 21:52:02 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-09-17 21:52:02 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-09-17 21:52:02 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-09-17 21:52:02 --> Model Class Initialized
DEBUG - 2011-09-17 21:52:02 --> Model Class Initialized
DEBUG - 2011-09-17 21:52:02 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-17 21:52:02 --> Database Driver Class Initialized
DEBUG - 2011-09-17 21:52:02 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-09-17 21:52:02 --> Helper loaded: url_helper
DEBUG - 2011-09-17 21:52:02 --> File loaded: application/views/common/header.php
DEBUG - 2011-09-17 21:52:02 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-09-17 21:52:02 --> File loaded: application/views/common/footer.php
DEBUG - 2011-09-17 21:52:02 --> File loaded: application/views/layout/main.php
DEBUG - 2011-09-17 21:52:02 --> Final output sent to browser
DEBUG - 2011-09-17 21:52:02 --> Total execution time: 0.0556
DEBUG - 2011-09-17 21:52:02 --> Config Class Initialized
DEBUG - 2011-09-17 21:52:02 --> Hooks Class Initialized
DEBUG - 2011-09-17 21:52:02 --> Utf8 Class Initialized
DEBUG - 2011-09-17 21:52:02 --> UTF-8 Support Enabled
DEBUG - 2011-09-17 21:52:02 --> URI Class Initialized
DEBUG - 2011-09-17 21:52:02 --> Router Class Initialized
DEBUG - 2011-09-17 21:52:02 --> Output Class Initialized
DEBUG - 2011-09-17 21:52:02 --> Input Class Initialized
DEBUG - 2011-09-17 21:52:02 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-17 21:52:02 --> Language Class Initialized
DEBUG - 2011-09-17 21:52:02 --> Loader Class Initialized
DEBUG - 2011-09-17 21:52:02 --> Controller Class Initialized
DEBUG - 2011-09-17 21:52:02 --> Model Class Initialized
DEBUG - 2011-09-17 21:52:02 --> Model Class Initialized
DEBUG - 2011-09-17 21:52:03 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-17 21:52:03 --> Database Driver Class Initialized
DEBUG - 2011-09-17 21:52:03 --> Final output sent to browser
DEBUG - 2011-09-17 21:52:03 --> Total execution time: 0.5915
DEBUG - 2011-09-17 21:52:08 --> Config Class Initialized
DEBUG - 2011-09-17 21:52:08 --> Hooks Class Initialized
DEBUG - 2011-09-17 21:52:08 --> Utf8 Class Initialized
DEBUG - 2011-09-17 21:52:08 --> UTF-8 Support Enabled
DEBUG - 2011-09-17 21:52:08 --> URI Class Initialized
DEBUG - 2011-09-17 21:52:08 --> Router Class Initialized
ERROR - 2011-09-17 21:52:08 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-09-17 21:52:17 --> Config Class Initialized
DEBUG - 2011-09-17 21:52:17 --> Hooks Class Initialized
DEBUG - 2011-09-17 21:52:17 --> Utf8 Class Initialized
DEBUG - 2011-09-17 21:52:17 --> UTF-8 Support Enabled
DEBUG - 2011-09-17 21:52:17 --> URI Class Initialized
DEBUG - 2011-09-17 21:52:17 --> Router Class Initialized
DEBUG - 2011-09-17 21:52:17 --> Output Class Initialized
DEBUG - 2011-09-17 21:52:17 --> Input Class Initialized
DEBUG - 2011-09-17 21:52:17 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-17 21:52:17 --> Language Class Initialized
DEBUG - 2011-09-17 21:52:17 --> Loader Class Initialized
DEBUG - 2011-09-17 21:52:17 --> Controller Class Initialized
ERROR - 2011-09-17 21:52:17 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-09-17 21:52:17 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-09-17 21:52:17 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-09-17 21:52:17 --> Model Class Initialized
DEBUG - 2011-09-17 21:52:17 --> Model Class Initialized
DEBUG - 2011-09-17 21:52:17 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-17 21:52:17 --> Database Driver Class Initialized
DEBUG - 2011-09-17 21:52:17 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-09-17 21:52:17 --> Helper loaded: url_helper
DEBUG - 2011-09-17 21:52:17 --> File loaded: application/views/common/header.php
DEBUG - 2011-09-17 21:52:17 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-09-17 21:52:17 --> File loaded: application/views/common/footer.php
DEBUG - 2011-09-17 21:52:17 --> File loaded: application/views/layout/main.php
DEBUG - 2011-09-17 21:52:17 --> Final output sent to browser
DEBUG - 2011-09-17 21:52:17 --> Total execution time: 0.0288
DEBUG - 2011-09-17 21:52:18 --> Config Class Initialized
DEBUG - 2011-09-17 21:52:18 --> Hooks Class Initialized
DEBUG - 2011-09-17 21:52:18 --> Utf8 Class Initialized
DEBUG - 2011-09-17 21:52:18 --> UTF-8 Support Enabled
DEBUG - 2011-09-17 21:52:18 --> URI Class Initialized
DEBUG - 2011-09-17 21:52:18 --> Router Class Initialized
DEBUG - 2011-09-17 21:52:18 --> Output Class Initialized
DEBUG - 2011-09-17 21:52:18 --> Input Class Initialized
DEBUG - 2011-09-17 21:52:18 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-17 21:52:18 --> Language Class Initialized
DEBUG - 2011-09-17 21:52:18 --> Loader Class Initialized
DEBUG - 2011-09-17 21:52:18 --> Controller Class Initialized
DEBUG - 2011-09-17 21:52:18 --> Model Class Initialized
DEBUG - 2011-09-17 21:52:18 --> Model Class Initialized
DEBUG - 2011-09-17 21:52:18 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-17 21:52:18 --> Database Driver Class Initialized
DEBUG - 2011-09-17 21:52:18 --> Final output sent to browser
DEBUG - 2011-09-17 21:52:18 --> Total execution time: 0.5846
DEBUG - 2011-09-17 21:52:21 --> Config Class Initialized
DEBUG - 2011-09-17 21:52:21 --> Hooks Class Initialized
DEBUG - 2011-09-17 21:52:21 --> Utf8 Class Initialized
DEBUG - 2011-09-17 21:52:21 --> UTF-8 Support Enabled
DEBUG - 2011-09-17 21:52:21 --> URI Class Initialized
DEBUG - 2011-09-17 21:52:21 --> Router Class Initialized
ERROR - 2011-09-17 21:52:21 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-09-17 21:52:26 --> Config Class Initialized
DEBUG - 2011-09-17 21:52:26 --> Hooks Class Initialized
DEBUG - 2011-09-17 21:52:26 --> Utf8 Class Initialized
DEBUG - 2011-09-17 21:52:26 --> UTF-8 Support Enabled
DEBUG - 2011-09-17 21:52:26 --> URI Class Initialized
DEBUG - 2011-09-17 21:52:26 --> Router Class Initialized
DEBUG - 2011-09-17 21:52:26 --> Output Class Initialized
DEBUG - 2011-09-17 21:52:26 --> Input Class Initialized
DEBUG - 2011-09-17 21:52:26 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-17 21:52:26 --> Language Class Initialized
DEBUG - 2011-09-17 21:52:26 --> Loader Class Initialized
DEBUG - 2011-09-17 21:52:26 --> Controller Class Initialized
ERROR - 2011-09-17 21:52:26 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-09-17 21:52:26 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-09-17 21:52:26 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-09-17 21:52:26 --> Model Class Initialized
DEBUG - 2011-09-17 21:52:26 --> Model Class Initialized
DEBUG - 2011-09-17 21:52:26 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-17 21:52:26 --> Database Driver Class Initialized
DEBUG - 2011-09-17 21:52:26 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-09-17 21:52:26 --> Helper loaded: url_helper
DEBUG - 2011-09-17 21:52:26 --> File loaded: application/views/common/header.php
DEBUG - 2011-09-17 21:52:26 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-09-17 21:52:26 --> File loaded: application/views/common/footer.php
DEBUG - 2011-09-17 21:52:26 --> File loaded: application/views/layout/main.php
DEBUG - 2011-09-17 21:52:26 --> Final output sent to browser
DEBUG - 2011-09-17 21:52:26 --> Total execution time: 0.0307
DEBUG - 2011-09-17 21:52:26 --> Config Class Initialized
DEBUG - 2011-09-17 21:52:26 --> Hooks Class Initialized
DEBUG - 2011-09-17 21:52:26 --> Utf8 Class Initialized
DEBUG - 2011-09-17 21:52:26 --> UTF-8 Support Enabled
DEBUG - 2011-09-17 21:52:26 --> URI Class Initialized
DEBUG - 2011-09-17 21:52:26 --> Router Class Initialized
DEBUG - 2011-09-17 21:52:26 --> Output Class Initialized
DEBUG - 2011-09-17 21:52:26 --> Input Class Initialized
DEBUG - 2011-09-17 21:52:26 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-17 21:52:26 --> Language Class Initialized
DEBUG - 2011-09-17 21:52:26 --> Loader Class Initialized
DEBUG - 2011-09-17 21:52:26 --> Controller Class Initialized
DEBUG - 2011-09-17 21:52:26 --> Model Class Initialized
DEBUG - 2011-09-17 21:52:26 --> Model Class Initialized
DEBUG - 2011-09-17 21:52:26 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-17 21:52:26 --> Database Driver Class Initialized
DEBUG - 2011-09-17 21:52:27 --> Final output sent to browser
DEBUG - 2011-09-17 21:52:27 --> Total execution time: 0.6575
DEBUG - 2011-09-17 21:52:30 --> Config Class Initialized
DEBUG - 2011-09-17 21:52:30 --> Hooks Class Initialized
DEBUG - 2011-09-17 21:52:30 --> Utf8 Class Initialized
DEBUG - 2011-09-17 21:52:30 --> UTF-8 Support Enabled
DEBUG - 2011-09-17 21:52:30 --> URI Class Initialized
DEBUG - 2011-09-17 21:52:30 --> Router Class Initialized
ERROR - 2011-09-17 21:52:30 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-09-17 21:52:40 --> Config Class Initialized
DEBUG - 2011-09-17 21:52:40 --> Hooks Class Initialized
DEBUG - 2011-09-17 21:52:40 --> Utf8 Class Initialized
DEBUG - 2011-09-17 21:52:40 --> UTF-8 Support Enabled
DEBUG - 2011-09-17 21:52:40 --> URI Class Initialized
DEBUG - 2011-09-17 21:52:40 --> Router Class Initialized
DEBUG - 2011-09-17 21:52:40 --> Output Class Initialized
DEBUG - 2011-09-17 21:52:40 --> Input Class Initialized
DEBUG - 2011-09-17 21:52:40 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-17 21:52:40 --> Language Class Initialized
DEBUG - 2011-09-17 21:52:40 --> Loader Class Initialized
DEBUG - 2011-09-17 21:52:40 --> Controller Class Initialized
ERROR - 2011-09-17 21:52:40 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-09-17 21:52:40 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-09-17 21:52:40 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-09-17 21:52:40 --> Model Class Initialized
DEBUG - 2011-09-17 21:52:40 --> Model Class Initialized
DEBUG - 2011-09-17 21:52:40 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-17 21:52:40 --> Database Driver Class Initialized
DEBUG - 2011-09-17 21:52:40 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-09-17 21:52:40 --> Helper loaded: url_helper
DEBUG - 2011-09-17 21:52:40 --> File loaded: application/views/common/header.php
DEBUG - 2011-09-17 21:52:40 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-09-17 21:52:40 --> File loaded: application/views/common/footer.php
DEBUG - 2011-09-17 21:52:40 --> File loaded: application/views/layout/main.php
DEBUG - 2011-09-17 21:52:40 --> Final output sent to browser
DEBUG - 2011-09-17 21:52:40 --> Total execution time: 0.0304
DEBUG - 2011-09-17 21:52:41 --> Config Class Initialized
DEBUG - 2011-09-17 21:52:41 --> Hooks Class Initialized
DEBUG - 2011-09-17 21:52:41 --> Utf8 Class Initialized
DEBUG - 2011-09-17 21:52:41 --> UTF-8 Support Enabled
DEBUG - 2011-09-17 21:52:41 --> URI Class Initialized
DEBUG - 2011-09-17 21:52:41 --> Router Class Initialized
DEBUG - 2011-09-17 21:52:41 --> Output Class Initialized
DEBUG - 2011-09-17 21:52:41 --> Input Class Initialized
DEBUG - 2011-09-17 21:52:41 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-17 21:52:41 --> Language Class Initialized
DEBUG - 2011-09-17 21:52:41 --> Loader Class Initialized
DEBUG - 2011-09-17 21:52:41 --> Controller Class Initialized
DEBUG - 2011-09-17 21:52:41 --> Model Class Initialized
DEBUG - 2011-09-17 21:52:41 --> Model Class Initialized
DEBUG - 2011-09-17 21:52:41 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-17 21:52:41 --> Database Driver Class Initialized
DEBUG - 2011-09-17 21:52:41 --> Config Class Initialized
DEBUG - 2011-09-17 21:52:41 --> Hooks Class Initialized
DEBUG - 2011-09-17 21:52:41 --> Utf8 Class Initialized
DEBUG - 2011-09-17 21:52:41 --> UTF-8 Support Enabled
DEBUG - 2011-09-17 21:52:41 --> URI Class Initialized
DEBUG - 2011-09-17 21:52:41 --> Router Class Initialized
ERROR - 2011-09-17 21:52:41 --> 404 Page Not Found --> robots.txt
DEBUG - 2011-09-17 21:52:41 --> Final output sent to browser
DEBUG - 2011-09-17 21:52:41 --> Total execution time: 0.6404
DEBUG - 2011-09-17 21:52:41 --> Config Class Initialized
DEBUG - 2011-09-17 21:52:41 --> Hooks Class Initialized
DEBUG - 2011-09-17 21:52:41 --> Utf8 Class Initialized
DEBUG - 2011-09-17 21:52:41 --> UTF-8 Support Enabled
DEBUG - 2011-09-17 21:52:41 --> URI Class Initialized
DEBUG - 2011-09-17 21:52:41 --> Router Class Initialized
DEBUG - 2011-09-17 21:52:41 --> Output Class Initialized
DEBUG - 2011-09-17 21:52:41 --> Input Class Initialized
DEBUG - 2011-09-17 21:52:41 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-17 21:52:41 --> Language Class Initialized
DEBUG - 2011-09-17 21:52:41 --> Loader Class Initialized
DEBUG - 2011-09-17 21:52:41 --> Controller Class Initialized
ERROR - 2011-09-17 21:52:41 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-09-17 21:52:41 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-09-17 21:52:41 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-09-17 21:52:41 --> Model Class Initialized
DEBUG - 2011-09-17 21:52:41 --> Model Class Initialized
DEBUG - 2011-09-17 21:52:41 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-17 21:52:41 --> Database Driver Class Initialized
DEBUG - 2011-09-17 21:52:41 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-09-17 21:52:41 --> Helper loaded: url_helper
DEBUG - 2011-09-17 21:52:41 --> File loaded: application/views/common/header.php
DEBUG - 2011-09-17 21:52:41 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-09-17 21:52:41 --> File loaded: application/views/common/footer.php
DEBUG - 2011-09-17 21:52:41 --> File loaded: application/views/layout/main.php
DEBUG - 2011-09-17 21:52:41 --> Final output sent to browser
DEBUG - 2011-09-17 21:52:41 --> Total execution time: 0.0266
DEBUG - 2011-09-17 21:52:43 --> Config Class Initialized
DEBUG - 2011-09-17 21:52:43 --> Hooks Class Initialized
DEBUG - 2011-09-17 21:52:43 --> Utf8 Class Initialized
DEBUG - 2011-09-17 21:52:43 --> UTF-8 Support Enabled
DEBUG - 2011-09-17 21:52:43 --> URI Class Initialized
DEBUG - 2011-09-17 21:52:43 --> Router Class Initialized
ERROR - 2011-09-17 21:52:43 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-09-17 21:52:56 --> Config Class Initialized
DEBUG - 2011-09-17 21:52:56 --> Hooks Class Initialized
DEBUG - 2011-09-17 21:52:56 --> Utf8 Class Initialized
DEBUG - 2011-09-17 21:52:56 --> UTF-8 Support Enabled
DEBUG - 2011-09-17 21:52:56 --> URI Class Initialized
DEBUG - 2011-09-17 21:52:56 --> Router Class Initialized
DEBUG - 2011-09-17 21:52:56 --> Output Class Initialized
DEBUG - 2011-09-17 21:52:56 --> Input Class Initialized
DEBUG - 2011-09-17 21:52:56 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-17 21:52:56 --> Language Class Initialized
DEBUG - 2011-09-17 21:52:56 --> Loader Class Initialized
DEBUG - 2011-09-17 21:52:56 --> Controller Class Initialized
ERROR - 2011-09-17 21:52:56 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-09-17 21:52:56 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-09-17 21:52:56 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-09-17 21:52:56 --> Model Class Initialized
DEBUG - 2011-09-17 21:52:56 --> Model Class Initialized
DEBUG - 2011-09-17 21:52:56 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-17 21:52:56 --> Database Driver Class Initialized
DEBUG - 2011-09-17 21:52:56 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-09-17 21:52:56 --> Helper loaded: url_helper
DEBUG - 2011-09-17 21:52:56 --> File loaded: application/views/common/header.php
DEBUG - 2011-09-17 21:52:56 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-09-17 21:52:56 --> File loaded: application/views/common/footer.php
DEBUG - 2011-09-17 21:52:56 --> File loaded: application/views/layout/main.php
DEBUG - 2011-09-17 21:52:56 --> Final output sent to browser
DEBUG - 2011-09-17 21:52:56 --> Total execution time: 0.0310
DEBUG - 2011-09-17 21:52:56 --> Config Class Initialized
DEBUG - 2011-09-17 21:52:56 --> Hooks Class Initialized
DEBUG - 2011-09-17 21:52:56 --> Utf8 Class Initialized
DEBUG - 2011-09-17 21:52:56 --> UTF-8 Support Enabled
DEBUG - 2011-09-17 21:52:56 --> URI Class Initialized
DEBUG - 2011-09-17 21:52:56 --> Router Class Initialized
DEBUG - 2011-09-17 21:52:56 --> Output Class Initialized
DEBUG - 2011-09-17 21:52:56 --> Input Class Initialized
DEBUG - 2011-09-17 21:52:56 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-17 21:52:56 --> Language Class Initialized
DEBUG - 2011-09-17 21:52:56 --> Loader Class Initialized
DEBUG - 2011-09-17 21:52:56 --> Controller Class Initialized
DEBUG - 2011-09-17 21:52:56 --> Model Class Initialized
DEBUG - 2011-09-17 21:52:56 --> Model Class Initialized
DEBUG - 2011-09-17 21:52:56 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-17 21:52:56 --> Database Driver Class Initialized
DEBUG - 2011-09-17 21:52:57 --> Final output sent to browser
DEBUG - 2011-09-17 21:52:57 --> Total execution time: 0.6675
DEBUG - 2011-09-17 21:52:59 --> Config Class Initialized
DEBUG - 2011-09-17 21:52:59 --> Hooks Class Initialized
DEBUG - 2011-09-17 21:52:59 --> Utf8 Class Initialized
DEBUG - 2011-09-17 21:52:59 --> UTF-8 Support Enabled
DEBUG - 2011-09-17 21:52:59 --> URI Class Initialized
DEBUG - 2011-09-17 21:52:59 --> Router Class Initialized
ERROR - 2011-09-17 21:52:59 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-09-17 22:04:03 --> Config Class Initialized
DEBUG - 2011-09-17 22:04:03 --> Hooks Class Initialized
DEBUG - 2011-09-17 22:04:03 --> Utf8 Class Initialized
DEBUG - 2011-09-17 22:04:03 --> UTF-8 Support Enabled
DEBUG - 2011-09-17 22:04:03 --> URI Class Initialized
DEBUG - 2011-09-17 22:04:03 --> Router Class Initialized
DEBUG - 2011-09-17 22:04:03 --> Output Class Initialized
DEBUG - 2011-09-17 22:04:03 --> Input Class Initialized
DEBUG - 2011-09-17 22:04:03 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-17 22:04:03 --> Language Class Initialized
DEBUG - 2011-09-17 22:04:03 --> Loader Class Initialized
DEBUG - 2011-09-17 22:04:03 --> Controller Class Initialized
DEBUG - 2011-09-17 22:04:03 --> Model Class Initialized
DEBUG - 2011-09-17 22:04:03 --> Model Class Initialized
DEBUG - 2011-09-17 22:04:03 --> Model Class Initialized
DEBUG - 2011-09-17 22:04:03 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-17 22:04:03 --> Database Driver Class Initialized
DEBUG - 2011-09-17 22:04:03 --> File loaded: application/views/table/main.php
DEBUG - 2011-09-17 22:04:03 --> Helper loaded: url_helper
DEBUG - 2011-09-17 22:04:03 --> File loaded: application/views/common/header.php
DEBUG - 2011-09-17 22:04:03 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-09-17 22:04:03 --> File loaded: application/views/common/footer.php
DEBUG - 2011-09-17 22:04:03 --> File loaded: application/views/layout/main.php
DEBUG - 2011-09-17 22:04:03 --> Final output sent to browser
DEBUG - 2011-09-17 22:04:03 --> Total execution time: 0.0453
DEBUG - 2011-09-17 22:06:37 --> Config Class Initialized
DEBUG - 2011-09-17 22:06:37 --> Hooks Class Initialized
DEBUG - 2011-09-17 22:06:37 --> Utf8 Class Initialized
DEBUG - 2011-09-17 22:06:37 --> UTF-8 Support Enabled
DEBUG - 2011-09-17 22:06:37 --> URI Class Initialized
DEBUG - 2011-09-17 22:06:37 --> Router Class Initialized
DEBUG - 2011-09-17 22:06:37 --> Output Class Initialized
DEBUG - 2011-09-17 22:06:37 --> Input Class Initialized
DEBUG - 2011-09-17 22:06:37 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-17 22:06:37 --> Language Class Initialized
DEBUG - 2011-09-17 22:06:37 --> Loader Class Initialized
DEBUG - 2011-09-17 22:06:37 --> Controller Class Initialized
DEBUG - 2011-09-17 22:06:37 --> Model Class Initialized
DEBUG - 2011-09-17 22:06:37 --> Model Class Initialized
DEBUG - 2011-09-17 22:06:37 --> Model Class Initialized
DEBUG - 2011-09-17 22:06:37 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-17 22:06:37 --> Database Driver Class Initialized
DEBUG - 2011-09-17 22:06:37 --> File loaded: application/views/table/main.php
DEBUG - 2011-09-17 22:06:37 --> Helper loaded: url_helper
DEBUG - 2011-09-17 22:06:37 --> File loaded: application/views/common/header.php
DEBUG - 2011-09-17 22:06:37 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-09-17 22:06:37 --> File loaded: application/views/common/footer.php
DEBUG - 2011-09-17 22:06:37 --> File loaded: application/views/layout/main.php
DEBUG - 2011-09-17 22:06:37 --> Final output sent to browser
DEBUG - 2011-09-17 22:06:37 --> Total execution time: 0.0449
DEBUG - 2011-09-17 22:06:49 --> Config Class Initialized
DEBUG - 2011-09-17 22:06:49 --> Hooks Class Initialized
DEBUG - 2011-09-17 22:06:49 --> Utf8 Class Initialized
DEBUG - 2011-09-17 22:06:49 --> UTF-8 Support Enabled
DEBUG - 2011-09-17 22:06:49 --> URI Class Initialized
DEBUG - 2011-09-17 22:06:49 --> Router Class Initialized
ERROR - 2011-09-17 22:06:49 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-09-17 22:06:49 --> Config Class Initialized
DEBUG - 2011-09-17 22:06:49 --> Hooks Class Initialized
DEBUG - 2011-09-17 22:06:49 --> Utf8 Class Initialized
DEBUG - 2011-09-17 22:06:49 --> UTF-8 Support Enabled
DEBUG - 2011-09-17 22:06:49 --> URI Class Initialized
DEBUG - 2011-09-17 22:06:49 --> Router Class Initialized
ERROR - 2011-09-17 22:06:49 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-09-17 22:06:51 --> Config Class Initialized
DEBUG - 2011-09-17 22:06:51 --> Hooks Class Initialized
DEBUG - 2011-09-17 22:06:51 --> Utf8 Class Initialized
DEBUG - 2011-09-17 22:06:51 --> UTF-8 Support Enabled
DEBUG - 2011-09-17 22:06:51 --> URI Class Initialized
DEBUG - 2011-09-17 22:06:51 --> Router Class Initialized
ERROR - 2011-09-17 22:06:51 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-09-17 22:07:11 --> Config Class Initialized
DEBUG - 2011-09-17 22:07:11 --> Hooks Class Initialized
DEBUG - 2011-09-17 22:07:11 --> Utf8 Class Initialized
DEBUG - 2011-09-17 22:07:11 --> UTF-8 Support Enabled
DEBUG - 2011-09-17 22:07:11 --> URI Class Initialized
DEBUG - 2011-09-17 22:07:11 --> Router Class Initialized
DEBUG - 2011-09-17 22:07:11 --> Output Class Initialized
DEBUG - 2011-09-17 22:07:11 --> Input Class Initialized
DEBUG - 2011-09-17 22:07:11 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-17 22:07:11 --> Language Class Initialized
DEBUG - 2011-09-17 22:07:11 --> Loader Class Initialized
DEBUG - 2011-09-17 22:07:11 --> Controller Class Initialized
DEBUG - 2011-09-17 22:07:11 --> Model Class Initialized
DEBUG - 2011-09-17 22:07:11 --> Model Class Initialized
DEBUG - 2011-09-17 22:07:11 --> Model Class Initialized
DEBUG - 2011-09-17 22:07:11 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-17 22:07:11 --> Database Driver Class Initialized
DEBUG - 2011-09-17 22:07:11 --> File loaded: application/views/table/main.php
DEBUG - 2011-09-17 22:07:11 --> Helper loaded: url_helper
DEBUG - 2011-09-17 22:07:11 --> File loaded: application/views/common/header.php
DEBUG - 2011-09-17 22:07:11 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-09-17 22:07:11 --> File loaded: application/views/common/footer.php
DEBUG - 2011-09-17 22:07:11 --> File loaded: application/views/layout/main.php
DEBUG - 2011-09-17 22:07:11 --> Final output sent to browser
DEBUG - 2011-09-17 22:07:11 --> Total execution time: 0.1380
DEBUG - 2011-09-17 23:23:54 --> Config Class Initialized
DEBUG - 2011-09-17 23:23:54 --> Hooks Class Initialized
DEBUG - 2011-09-17 23:23:54 --> Utf8 Class Initialized
DEBUG - 2011-09-17 23:23:54 --> UTF-8 Support Enabled
DEBUG - 2011-09-17 23:23:54 --> URI Class Initialized
DEBUG - 2011-09-17 23:23:54 --> Router Class Initialized
DEBUG - 2011-09-17 23:23:54 --> Output Class Initialized
DEBUG - 2011-09-17 23:23:54 --> Input Class Initialized
DEBUG - 2011-09-17 23:23:54 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-17 23:23:54 --> Language Class Initialized
DEBUG - 2011-09-17 23:23:54 --> Loader Class Initialized
DEBUG - 2011-09-17 23:23:54 --> Controller Class Initialized
ERROR - 2011-09-17 23:23:54 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-09-17 23:23:54 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-09-17 23:23:54 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-09-17 23:23:54 --> Model Class Initialized
DEBUG - 2011-09-17 23:23:54 --> Model Class Initialized
DEBUG - 2011-09-17 23:23:54 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-17 23:23:54 --> Database Driver Class Initialized
DEBUG - 2011-09-17 23:23:55 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-09-17 23:23:55 --> Helper loaded: url_helper
DEBUG - 2011-09-17 23:23:55 --> File loaded: application/views/common/header.php
DEBUG - 2011-09-17 23:23:55 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-09-17 23:23:55 --> File loaded: application/views/common/footer.php
DEBUG - 2011-09-17 23:23:55 --> File loaded: application/views/layout/main.php
DEBUG - 2011-09-17 23:23:55 --> Final output sent to browser
DEBUG - 2011-09-17 23:23:55 --> Total execution time: 0.2280
DEBUG - 2011-09-17 23:23:59 --> Config Class Initialized
DEBUG - 2011-09-17 23:23:59 --> Hooks Class Initialized
DEBUG - 2011-09-17 23:23:59 --> Utf8 Class Initialized
DEBUG - 2011-09-17 23:23:59 --> UTF-8 Support Enabled
DEBUG - 2011-09-17 23:23:59 --> URI Class Initialized
DEBUG - 2011-09-17 23:23:59 --> Router Class Initialized
DEBUG - 2011-09-17 23:23:59 --> Output Class Initialized
DEBUG - 2011-09-17 23:23:59 --> Input Class Initialized
DEBUG - 2011-09-17 23:23:59 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-17 23:23:59 --> Language Class Initialized
DEBUG - 2011-09-17 23:23:59 --> Loader Class Initialized
DEBUG - 2011-09-17 23:23:59 --> Controller Class Initialized
DEBUG - 2011-09-17 23:23:59 --> Model Class Initialized
DEBUG - 2011-09-17 23:23:59 --> Model Class Initialized
DEBUG - 2011-09-17 23:23:59 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-17 23:23:59 --> Database Driver Class Initialized
DEBUG - 2011-09-17 23:24:00 --> Final output sent to browser
DEBUG - 2011-09-17 23:24:00 --> Total execution time: 0.6385
DEBUG - 2011-09-17 23:24:08 --> Config Class Initialized
DEBUG - 2011-09-17 23:24:08 --> Hooks Class Initialized
DEBUG - 2011-09-17 23:24:08 --> Utf8 Class Initialized
DEBUG - 2011-09-17 23:24:08 --> UTF-8 Support Enabled
DEBUG - 2011-09-17 23:24:08 --> URI Class Initialized
DEBUG - 2011-09-17 23:24:08 --> Router Class Initialized
ERROR - 2011-09-17 23:24:08 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-09-17 23:24:17 --> Config Class Initialized
DEBUG - 2011-09-17 23:24:17 --> Hooks Class Initialized
DEBUG - 2011-09-17 23:24:17 --> Utf8 Class Initialized
DEBUG - 2011-09-17 23:24:17 --> UTF-8 Support Enabled
DEBUG - 2011-09-17 23:24:17 --> URI Class Initialized
DEBUG - 2011-09-17 23:24:17 --> Router Class Initialized
DEBUG - 2011-09-17 23:24:17 --> Output Class Initialized
DEBUG - 2011-09-17 23:24:17 --> Input Class Initialized
DEBUG - 2011-09-17 23:24:17 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-17 23:24:17 --> Language Class Initialized
DEBUG - 2011-09-17 23:24:17 --> Loader Class Initialized
DEBUG - 2011-09-17 23:24:17 --> Controller Class Initialized
ERROR - 2011-09-17 23:24:17 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-09-17 23:24:17 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-09-17 23:24:17 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-09-17 23:24:17 --> Model Class Initialized
DEBUG - 2011-09-17 23:24:17 --> Model Class Initialized
DEBUG - 2011-09-17 23:24:17 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-17 23:24:17 --> Database Driver Class Initialized
DEBUG - 2011-09-17 23:24:17 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-09-17 23:24:17 --> Helper loaded: url_helper
DEBUG - 2011-09-17 23:24:17 --> File loaded: application/views/common/header.php
DEBUG - 2011-09-17 23:24:17 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-09-17 23:24:17 --> File loaded: application/views/common/footer.php
DEBUG - 2011-09-17 23:24:17 --> File loaded: application/views/layout/main.php
DEBUG - 2011-09-17 23:24:17 --> Final output sent to browser
DEBUG - 2011-09-17 23:24:17 --> Total execution time: 0.0305
DEBUG - 2011-09-17 23:24:17 --> Config Class Initialized
DEBUG - 2011-09-17 23:24:17 --> Hooks Class Initialized
DEBUG - 2011-09-17 23:24:17 --> Utf8 Class Initialized
DEBUG - 2011-09-17 23:24:17 --> UTF-8 Support Enabled
DEBUG - 2011-09-17 23:24:17 --> URI Class Initialized
DEBUG - 2011-09-17 23:24:17 --> Router Class Initialized
DEBUG - 2011-09-17 23:24:17 --> Output Class Initialized
DEBUG - 2011-09-17 23:24:17 --> Input Class Initialized
DEBUG - 2011-09-17 23:24:17 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-17 23:24:17 --> Language Class Initialized
DEBUG - 2011-09-17 23:24:17 --> Loader Class Initialized
DEBUG - 2011-09-17 23:24:17 --> Controller Class Initialized
DEBUG - 2011-09-17 23:24:17 --> Model Class Initialized
DEBUG - 2011-09-17 23:24:17 --> Model Class Initialized
DEBUG - 2011-09-17 23:24:17 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-17 23:24:17 --> Database Driver Class Initialized
DEBUG - 2011-09-17 23:24:18 --> Config Class Initialized
DEBUG - 2011-09-17 23:24:18 --> Hooks Class Initialized
DEBUG - 2011-09-17 23:24:18 --> Utf8 Class Initialized
DEBUG - 2011-09-17 23:24:18 --> UTF-8 Support Enabled
DEBUG - 2011-09-17 23:24:18 --> URI Class Initialized
DEBUG - 2011-09-17 23:24:18 --> Router Class Initialized
DEBUG - 2011-09-17 23:24:18 --> Output Class Initialized
DEBUG - 2011-09-17 23:24:18 --> Input Class Initialized
DEBUG - 2011-09-17 23:24:18 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-17 23:24:18 --> Language Class Initialized
DEBUG - 2011-09-17 23:24:18 --> Loader Class Initialized
DEBUG - 2011-09-17 23:24:18 --> Controller Class Initialized
ERROR - 2011-09-17 23:24:18 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-09-17 23:24:18 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-09-17 23:24:18 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-09-17 23:24:18 --> Model Class Initialized
DEBUG - 2011-09-17 23:24:18 --> Model Class Initialized
DEBUG - 2011-09-17 23:24:18 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-17 23:24:18 --> Database Driver Class Initialized
DEBUG - 2011-09-17 23:24:18 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-09-17 23:24:18 --> Helper loaded: url_helper
DEBUG - 2011-09-17 23:24:18 --> File loaded: application/views/common/header.php
DEBUG - 2011-09-17 23:24:18 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-09-17 23:24:18 --> File loaded: application/views/common/footer.php
DEBUG - 2011-09-17 23:24:18 --> File loaded: application/views/layout/main.php
DEBUG - 2011-09-17 23:24:18 --> Final output sent to browser
DEBUG - 2011-09-17 23:24:18 --> Total execution time: 0.0307
DEBUG - 2011-09-17 23:24:18 --> Final output sent to browser
DEBUG - 2011-09-17 23:24:18 --> Total execution time: 0.5398
DEBUG - 2011-09-17 23:24:20 --> Config Class Initialized
DEBUG - 2011-09-17 23:24:20 --> Hooks Class Initialized
DEBUG - 2011-09-17 23:24:20 --> Utf8 Class Initialized
DEBUG - 2011-09-17 23:24:20 --> UTF-8 Support Enabled
DEBUG - 2011-09-17 23:24:20 --> URI Class Initialized
DEBUG - 2011-09-17 23:24:20 --> Router Class Initialized
ERROR - 2011-09-17 23:24:20 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-09-17 23:56:07 --> Config Class Initialized
DEBUG - 2011-09-17 23:56:07 --> Hooks Class Initialized
DEBUG - 2011-09-17 23:56:07 --> Utf8 Class Initialized
DEBUG - 2011-09-17 23:56:07 --> UTF-8 Support Enabled
DEBUG - 2011-09-17 23:56:07 --> URI Class Initialized
DEBUG - 2011-09-17 23:56:07 --> Router Class Initialized
DEBUG - 2011-09-17 23:56:07 --> Output Class Initialized
DEBUG - 2011-09-17 23:56:07 --> Input Class Initialized
DEBUG - 2011-09-17 23:56:07 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-17 23:56:07 --> Language Class Initialized
DEBUG - 2011-09-17 23:56:07 --> Loader Class Initialized
DEBUG - 2011-09-17 23:56:07 --> Controller Class Initialized
DEBUG - 2011-09-17 23:56:07 --> Model Class Initialized
DEBUG - 2011-09-17 23:56:07 --> Model Class Initialized
DEBUG - 2011-09-17 23:56:07 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-17 23:56:07 --> Database Driver Class Initialized
DEBUG - 2011-09-17 23:56:08 --> Final output sent to browser
DEBUG - 2011-09-17 23:56:08 --> Total execution time: 0.5423
